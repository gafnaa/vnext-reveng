// lib: , url: package:flutter/src/rendering/proxy_box.dart

// class id: 1049038, size: 0x8
class :: {
}

// class id: 4303, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class CustomClipper<X0> extends Listenable {

  _ removeListener(/* No info */) {
    // ** addr: 0xd01414, size: 0x44
    // 0xd01414: EnterFrame
    //     0xd01414: stp             fp, lr, [SP, #-0x10]!
    //     0xd01418: mov             fp, SP
    // 0xd0141c: CheckStackOverflow
    //     0xd0141c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01420: cmp             SP, x16
    //     0xd01424: b.ls            #0xd01450
    // 0xd01428: LoadField: r0 = r1->field_b
    //     0xd01428: ldur            w0, [x1, #0xb]
    // 0xd0142c: DecompressPointer r0
    //     0xd0142c: add             x0, x0, HEAP, lsl #32
    // 0xd01430: cmp             w0, NULL
    // 0xd01434: b.eq            #0xd01440
    // 0xd01438: mov             x1, x0
    // 0xd0143c: r0 = removeListener()
    //     0xd0143c: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xd01440: r0 = Null
    //     0xd01440: mov             x0, NULL
    // 0xd01444: LeaveFrame
    //     0xd01444: mov             SP, fp
    //     0xd01448: ldp             fp, lr, [SP], #0x10
    // 0xd0144c: ret
    //     0xd0144c: ret             
    // 0xd01450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01454: b               #0xd01428
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd049c4, size: 0x44
    // 0xd049c4: EnterFrame
    //     0xd049c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd049c8: mov             fp, SP
    // 0xd049cc: CheckStackOverflow
    //     0xd049cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd049d0: cmp             SP, x16
    //     0xd049d4: b.ls            #0xd04a00
    // 0xd049d8: LoadField: r0 = r1->field_b
    //     0xd049d8: ldur            w0, [x1, #0xb]
    // 0xd049dc: DecompressPointer r0
    //     0xd049dc: add             x0, x0, HEAP, lsl #32
    // 0xd049e0: cmp             w0, NULL
    // 0xd049e4: b.eq            #0xd049f0
    // 0xd049e8: mov             x1, x0
    // 0xd049ec: r0 = addListener()
    //     0xd049ec: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xd049f0: r0 = Null
    //     0xd049f0: mov             x0, NULL
    // 0xd049f4: LeaveFrame
    //     0xd049f4: mov             SP, fp
    //     0xd049f8: ldp             fp, lr, [SP], #0x10
    // 0xd049fc: ret
    //     0xd049fc: ret             
    // 0xd04a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04a00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd04a04: b               #0xd049d8
  }
}

// class id: 4308, size: 0x18, field offset: 0x10
//   const constructor, 
class ShapeBorderClipper extends CustomClipper<dynamic> {

  RoundedRectangleBorder field_10;

  _ shouldReclip(/* No info */) {
    // ** addr: 0x119db94, size: 0x120
    // 0x119db94: EnterFrame
    //     0x119db94: stp             fp, lr, [SP, #-0x10]!
    //     0x119db98: mov             fp, SP
    // 0x119db9c: AllocStack(0x20)
    //     0x119db9c: sub             SP, SP, #0x20
    // 0x119dba0: SetupParameters(ShapeBorderClipper this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119dba0: mov             x0, x2
    //     0x119dba4: stur            x1, [fp, #-8]
    //     0x119dba8: stur            x2, [fp, #-0x10]
    // 0x119dbac: CheckStackOverflow
    //     0x119dbac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119dbb0: cmp             SP, x16
    //     0x119dbb4: b.ls            #0x119dcac
    // 0x119dbb8: str             x0, [SP]
    // 0x119dbbc: r0 = runtimeType()
    //     0x119dbbc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x119dbc0: r1 = LoadClassIdInstr(r0)
    //     0x119dbc0: ldur            x1, [x0, #-1]
    //     0x119dbc4: ubfx            x1, x1, #0xc, #0x14
    // 0x119dbc8: r16 = ShapeBorderClipper
    //     0x119dbc8: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a640] Type: ShapeBorderClipper
    //     0x119dbcc: ldr             x16, [x16, #0x640]
    // 0x119dbd0: stp             x16, x0, [SP]
    // 0x119dbd4: mov             x0, x1
    // 0x119dbd8: mov             lr, x0
    // 0x119dbdc: ldr             lr, [x21, lr, lsl #3]
    // 0x119dbe0: blr             lr
    // 0x119dbe4: tbz             w0, #4, #0x119dbf8
    // 0x119dbe8: r0 = true
    //     0x119dbe8: add             x0, NULL, #0x20  ; true
    // 0x119dbec: LeaveFrame
    //     0x119dbec: mov             SP, fp
    //     0x119dbf0: ldp             fp, lr, [SP], #0x10
    // 0x119dbf4: ret
    //     0x119dbf4: ret             
    // 0x119dbf8: ldur            x4, [fp, #-8]
    // 0x119dbfc: ldur            x3, [fp, #-0x10]
    // 0x119dc00: mov             x0, x3
    // 0x119dc04: r2 = Null
    //     0x119dc04: mov             x2, NULL
    // 0x119dc08: r1 = Null
    //     0x119dc08: mov             x1, NULL
    // 0x119dc0c: r4 = LoadClassIdInstr(r0)
    //     0x119dc0c: ldur            x4, [x0, #-1]
    //     0x119dc10: ubfx            x4, x4, #0xc, #0x14
    // 0x119dc14: r17 = 4308
    //     0x119dc14: mov             x17, #0x10d4
    // 0x119dc18: cmp             x4, x17
    // 0x119dc1c: b.eq            #0x119dc34
    // 0x119dc20: r8 = ShapeBorderClipper
    //     0x119dc20: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a640] Type: ShapeBorderClipper
    //     0x119dc24: ldr             x8, [x8, #0x640]
    // 0x119dc28: r3 = Null
    //     0x119dc28: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a648] Null
    //     0x119dc2c: ldr             x3, [x3, #0x648]
    // 0x119dc30: r0 = DefaultTypeTest()
    //     0x119dc30: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x119dc34: ldur            x1, [fp, #-0x10]
    // 0x119dc38: LoadField: r0 = r1->field_f
    //     0x119dc38: ldur            w0, [x1, #0xf]
    // 0x119dc3c: DecompressPointer r0
    //     0x119dc3c: add             x0, x0, HEAP, lsl #32
    // 0x119dc40: ldur            x2, [fp, #-8]
    // 0x119dc44: LoadField: r3 = r2->field_f
    //     0x119dc44: ldur            w3, [x2, #0xf]
    // 0x119dc48: DecompressPointer r3
    //     0x119dc48: add             x3, x3, HEAP, lsl #32
    // 0x119dc4c: r4 = LoadClassIdInstr(r0)
    //     0x119dc4c: ldur            x4, [x0, #-1]
    //     0x119dc50: ubfx            x4, x4, #0xc, #0x14
    // 0x119dc54: stp             x3, x0, [SP]
    // 0x119dc58: mov             x0, x4
    // 0x119dc5c: mov             lr, x0
    // 0x119dc60: ldr             lr, [x21, lr, lsl #3]
    // 0x119dc64: blr             lr
    // 0x119dc68: tbz             w0, #4, #0x119dc74
    // 0x119dc6c: r0 = true
    //     0x119dc6c: add             x0, NULL, #0x20  ; true
    // 0x119dc70: b               #0x119dca0
    // 0x119dc74: ldur            x2, [fp, #-8]
    // 0x119dc78: ldur            x1, [fp, #-0x10]
    // 0x119dc7c: LoadField: r3 = r1->field_13
    //     0x119dc7c: ldur            w3, [x1, #0x13]
    // 0x119dc80: DecompressPointer r3
    //     0x119dc80: add             x3, x3, HEAP, lsl #32
    // 0x119dc84: LoadField: r1 = r2->field_13
    //     0x119dc84: ldur            w1, [x2, #0x13]
    // 0x119dc88: DecompressPointer r1
    //     0x119dc88: add             x1, x1, HEAP, lsl #32
    // 0x119dc8c: cmp             w3, w1
    // 0x119dc90: r16 = true
    //     0x119dc90: add             x16, NULL, #0x20  ; true
    // 0x119dc94: r17 = false
    //     0x119dc94: add             x17, NULL, #0x30  ; false
    // 0x119dc98: csel            x2, x16, x17, ne
    // 0x119dc9c: mov             x0, x2
    // 0x119dca0: LeaveFrame
    //     0x119dca0: mov             SP, fp
    //     0x119dca4: ldp             fp, lr, [SP], #0x10
    // 0x119dca8: ret
    //     0x119dca8: ret             
    // 0x119dcac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119dcac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119dcb0: b               #0x119dbb8
  }
  _ getClip(/* No info */) {
    // ** addr: 0x11d6370, size: 0x88
    // 0x11d6370: EnterFrame
    //     0x11d6370: stp             fp, lr, [SP, #-0x10]!
    //     0x11d6374: mov             fp, SP
    // 0x11d6378: AllocStack(0x18)
    //     0x11d6378: sub             SP, SP, #0x18
    // 0x11d637c: SetupParameters(ShapeBorderClipper this /* r1 => r0, fp-0x10 */)
    //     0x11d637c: mov             x0, x1
    //     0x11d6380: stur            x1, [fp, #-0x10]
    // 0x11d6384: CheckStackOverflow
    //     0x11d6384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d6388: cmp             SP, x16
    //     0x11d638c: b.ls            #0x11d63f0
    // 0x11d6390: LoadField: r3 = r0->field_f
    //     0x11d6390: ldur            w3, [x0, #0xf]
    // 0x11d6394: DecompressPointer r3
    //     0x11d6394: add             x3, x3, HEAP, lsl #32
    // 0x11d6398: stur            x3, [fp, #-8]
    // 0x11d639c: r1 = Instance_Offset
    //     0x11d639c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11d63a0: r0 = &()
    //     0x11d63a0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x11d63a4: mov             x1, x0
    // 0x11d63a8: ldur            x0, [fp, #-0x10]
    // 0x11d63ac: LoadField: r2 = r0->field_13
    //     0x11d63ac: ldur            w2, [x0, #0x13]
    // 0x11d63b0: DecompressPointer r2
    //     0x11d63b0: add             x2, x2, HEAP, lsl #32
    // 0x11d63b4: ldur            x0, [fp, #-8]
    // 0x11d63b8: r3 = LoadClassIdInstr(r0)
    //     0x11d63b8: ldur            x3, [x0, #-1]
    //     0x11d63bc: ubfx            x3, x3, #0xc, #0x14
    // 0x11d63c0: str             x2, [SP]
    // 0x11d63c4: mov             x2, x1
    // 0x11d63c8: mov             x1, x0
    // 0x11d63cc: mov             x0, x3
    // 0x11d63d0: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x11d63d0: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x11d63d4: ldr             x4, [x4, #0x638]
    // 0x11d63d8: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x11d63d8: sub             lr, x0, #0xfc1
    //     0x11d63dc: ldr             lr, [x21, lr, lsl #3]
    //     0x11d63e0: blr             lr
    // 0x11d63e4: LeaveFrame
    //     0x11d63e4: mov             SP, fp
    //     0x11d63e8: ldp             fp, lr, [SP], #0x10
    // 0x11d63ec: ret
    //     0x11d63ec: ret             
    // 0x11d63f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d63f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d63f4: b               #0x11d6390
  }
}

// class id: 4644, size: 0xc, field offset: 0xc
abstract class RenderProxyBoxMixin<X0 bound RenderBox> extends _MixinApplication9&RenderBox&RenderObjectWithChildMixin<X0 bound RenderBox> {
}

// class id: 4708, size: 0x4c, field offset: 0x4c
abstract class RenderAnimatedOpacityMixin<X0 bound RenderObject> extends RenderObjectWithChildMixin<X0 bound RenderObject> {
}

// class id: 4897, size: 0x54, field offset: 0x54
abstract class RenderProxyBox extends _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin {
}

// class id: 4914, size: 0x68, field offset: 0x54
class RenderAnnotatedRegion<X0> extends RenderProxyBox {

  _ dispose(/* No info */) {
    // ** addr: 0xc02b08, size: 0x50
    // 0xc02b08: EnterFrame
    //     0xc02b08: stp             fp, lr, [SP, #-0x10]!
    //     0xc02b0c: mov             fp, SP
    // 0xc02b10: AllocStack(0x8)
    //     0xc02b10: sub             SP, SP, #8
    // 0xc02b14: SetupParameters(RenderAnnotatedRegion<X0> this /* r1 => r0, fp-0x8 */)
    //     0xc02b14: mov             x0, x1
    //     0xc02b18: stur            x1, [fp, #-8]
    // 0xc02b1c: CheckStackOverflow
    //     0xc02b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02b20: cmp             SP, x16
    //     0xc02b24: b.ls            #0xc02b50
    // 0xc02b28: LoadField: r1 = r0->field_5f
    //     0xc02b28: ldur            w1, [x0, #0x5f]
    // 0xc02b2c: DecompressPointer r1
    //     0xc02b2c: add             x1, x1, HEAP, lsl #32
    // 0xc02b30: r2 = Null
    //     0xc02b30: mov             x2, NULL
    // 0xc02b34: r0 = layer=()
    //     0xc02b34: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc02b38: ldur            x1, [fp, #-8]
    // 0xc02b3c: r0 = dispose()
    //     0xc02b3c: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc02b40: r0 = Null
    //     0xc02b40: mov             x0, NULL
    // 0xc02b44: LeaveFrame
    //     0xc02b44: mov             SP, fp
    //     0xc02b48: ldp             fp, lr, [SP], #0x10
    // 0xc02b4c: ret
    //     0xc02b4c: ret             
    // 0xc02b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02b50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02b54: b               #0xc02b28
  }
  X0 dyn:get:value(RenderAnnotatedRegion<X0>) {
    // ** addr: 0xc02b70, size: 0x28
    // 0xc02b70: ldr             x1, [SP]
    // 0xc02b74: LoadField: r0 = r1->field_57
    //     0xc02b74: ldur            w0, [x1, #0x57]
    // 0xc02b78: DecompressPointer r0
    //     0xc02b78: add             x0, x0, HEAP, lsl #32
    // 0xc02b7c: ret
    //     0xc02b7c: ret             
  }
  void dyn:set:value(RenderAnnotatedRegion<X0>, X0) {
    // ** addr: 0xc02b98, size: 0x4c
    // 0xc02b98: EnterFrame
    //     0xc02b98: stp             fp, lr, [SP, #-0x10]!
    //     0xc02b9c: mov             fp, SP
    // 0xc02ba0: CheckStackOverflow
    //     0xc02ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02ba4: cmp             SP, x16
    //     0xc02ba8: b.ls            #0xc02bc4
    // 0xc02bac: ldr             x1, [fp, #0x18]
    // 0xc02bb0: ldr             x2, [fp, #0x10]
    // 0xc02bb4: r0 = value=()
    //     0xc02bb4: bl              #0xc02bcc  ; [package:flutter/src/rendering/proxy_box.dart] RenderAnnotatedRegion::value=
    // 0xc02bb8: LeaveFrame
    //     0xc02bb8: mov             SP, fp
    //     0xc02bbc: ldp             fp, lr, [SP], #0x10
    // 0xc02bc0: ret
    //     0xc02bc0: ret             
    // 0xc02bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02bc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02bc8: b               #0xc02bac
  }
  set void value=(RenderAnnotatedRegion<X0>, X0) {
    // ** addr: 0xc02bcc, size: 0xec
    // 0xc02bcc: EnterFrame
    //     0xc02bcc: stp             fp, lr, [SP, #-0x10]!
    //     0xc02bd0: mov             fp, SP
    // 0xc02bd4: AllocStack(0x20)
    //     0xc02bd4: sub             SP, SP, #0x20
    // 0xc02bd8: SetupParameters(RenderAnnotatedRegion<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc02bd8: mov             x4, x1
    //     0xc02bdc: mov             x3, x2
    //     0xc02be0: stur            x1, [fp, #-8]
    //     0xc02be4: stur            x2, [fp, #-0x10]
    // 0xc02be8: CheckStackOverflow
    //     0xc02be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02bec: cmp             SP, x16
    //     0xc02bf0: b.ls            #0xc02cb0
    // 0xc02bf4: LoadField: r2 = r4->field_53
    //     0xc02bf4: ldur            w2, [x4, #0x53]
    // 0xc02bf8: DecompressPointer r2
    //     0xc02bf8: add             x2, x2, HEAP, lsl #32
    // 0xc02bfc: mov             x0, x3
    // 0xc02c00: r1 = Null
    //     0xc02c00: mov             x1, NULL
    // 0xc02c04: cmp             w2, NULL
    // 0xc02c08: b.eq            #0xc02c2c
    // 0xc02c0c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc02c0c: ldur            w4, [x2, #0x17]
    // 0xc02c10: DecompressPointer r4
    //     0xc02c10: add             x4, x4, HEAP, lsl #32
    // 0xc02c14: r8 = X0
    //     0xc02c14: add             x8, PP, #0x26, lsl #12  ; [pp+0x267c8] TypeParameter: X0
    //     0xc02c18: ldr             x8, [x8, #0x7c8]
    // 0xc02c1c: LoadField: r9 = r4->field_7
    //     0xc02c1c: ldur            x9, [x4, #7]
    // 0xc02c20: r3 = Null
    //     0xc02c20: add             x3, PP, #0x26, lsl #12  ; [pp+0x267d0] Null
    //     0xc02c24: ldr             x3, [x3, #0x7d0]
    // 0xc02c28: blr             x9
    // 0xc02c2c: ldur            x1, [fp, #-8]
    // 0xc02c30: LoadField: r0 = r1->field_57
    //     0xc02c30: ldur            w0, [x1, #0x57]
    // 0xc02c34: DecompressPointer r0
    //     0xc02c34: add             x0, x0, HEAP, lsl #32
    // 0xc02c38: r2 = 60
    //     0xc02c38: mov             x2, #0x3c
    // 0xc02c3c: branchIfSmi(r0, 0xc02c48)
    //     0xc02c3c: tbz             w0, #0, #0xc02c48
    // 0xc02c40: r2 = LoadClassIdInstr(r0)
    //     0xc02c40: ldur            x2, [x0, #-1]
    //     0xc02c44: ubfx            x2, x2, #0xc, #0x14
    // 0xc02c48: ldur            x16, [fp, #-0x10]
    // 0xc02c4c: stp             x16, x0, [SP]
    // 0xc02c50: mov             x0, x2
    // 0xc02c54: mov             lr, x0
    // 0xc02c58: ldr             lr, [x21, lr, lsl #3]
    // 0xc02c5c: blr             lr
    // 0xc02c60: tbnz            w0, #4, #0xc02c74
    // 0xc02c64: r0 = Null
    //     0xc02c64: mov             x0, NULL
    // 0xc02c68: LeaveFrame
    //     0xc02c68: mov             SP, fp
    //     0xc02c6c: ldp             fp, lr, [SP], #0x10
    // 0xc02c70: ret
    //     0xc02c70: ret             
    // 0xc02c74: ldur            x1, [fp, #-8]
    // 0xc02c78: ldur            x0, [fp, #-0x10]
    // 0xc02c7c: StoreField: r1->field_57 = r0
    //     0xc02c7c: stur            w0, [x1, #0x57]
    //     0xc02c80: tbz             w0, #0, #0xc02c9c
    //     0xc02c84: ldurb           w16, [x1, #-1]
    //     0xc02c88: ldurb           w17, [x0, #-1]
    //     0xc02c8c: and             x16, x17, x16, lsr #2
    //     0xc02c90: tst             x16, HEAP, lsr #32
    //     0xc02c94: b.eq            #0xc02c9c
    //     0xc02c98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc02c9c: r0 = markNeedsPaint()
    //     0xc02c9c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xc02ca0: r0 = Null
    //     0xc02ca0: mov             x0, NULL
    // 0xc02ca4: LeaveFrame
    //     0xc02ca4: mov             SP, fp
    //     0xc02ca8: ldp             fp, lr, [SP], #0x10
    // 0xc02cac: ret
    //     0xc02cac: ret             
    // 0xc02cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02cb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02cb4: b               #0xc02bf4
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1d818, size: 0xdc
    // 0xc1d818: EnterFrame
    //     0xc1d818: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d81c: mov             fp, SP
    // 0xc1d820: AllocStack(0x30)
    //     0xc1d820: sub             SP, SP, #0x30
    // 0xc1d824: SetupParameters(RenderAnnotatedRegion<X0> this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */)
    //     0xc1d824: mov             x0, x2
    //     0xc1d828: stur            x2, [fp, #-0x18]
    //     0xc1d82c: mov             x2, x1
    //     0xc1d830: mov             x5, x3
    //     0xc1d834: stur            x1, [fp, #-0x10]
    //     0xc1d838: stur            x3, [fp, #-0x20]
    // 0xc1d83c: CheckStackOverflow
    //     0xc1d83c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d840: cmp             SP, x16
    //     0xc1d844: b.ls            #0xc1d8ec
    // 0xc1d848: LoadField: r3 = r2->field_57
    //     0xc1d848: ldur            w3, [x2, #0x57]
    // 0xc1d84c: DecompressPointer r3
    //     0xc1d84c: add             x3, x3, HEAP, lsl #32
    // 0xc1d850: mov             x1, x2
    // 0xc1d854: stur            x3, [fp, #-8]
    // 0xc1d858: r0 = size()
    //     0xc1d858: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1d85c: ldur            x2, [fp, #-0x10]
    // 0xc1d860: stur            x0, [fp, #-0x28]
    // 0xc1d864: LoadField: r1 = r2->field_53
    //     0xc1d864: ldur            w1, [x2, #0x53]
    // 0xc1d868: DecompressPointer r1
    //     0xc1d868: add             x1, x1, HEAP, lsl #32
    // 0xc1d86c: r0 = AnnotatedRegionLayer()
    //     0xc1d86c: bl              #0xc1d8f4  ; AllocateAnnotatedRegionLayerStub -> AnnotatedRegionLayer<X0> (size=0x5c)
    // 0xc1d870: mov             x2, x0
    // 0xc1d874: ldur            x0, [fp, #-8]
    // 0xc1d878: stur            x2, [fp, #-0x30]
    // 0xc1d87c: StoreField: r2->field_4b = r0
    //     0xc1d87c: stur            w0, [x2, #0x4b]
    // 0xc1d880: ldur            x0, [fp, #-0x28]
    // 0xc1d884: StoreField: r2->field_4f = r0
    //     0xc1d884: stur            w0, [x2, #0x4f]
    // 0xc1d888: r0 = false
    //     0xc1d888: add             x0, NULL, #0x30  ; false
    // 0xc1d88c: StoreField: r2->field_57 = r0
    //     0xc1d88c: stur            w0, [x2, #0x57]
    // 0xc1d890: ldur            x5, [fp, #-0x20]
    // 0xc1d894: StoreField: r2->field_53 = r5
    //     0xc1d894: stur            w5, [x2, #0x53]
    // 0xc1d898: mov             x1, x2
    // 0xc1d89c: r0 = Layer()
    //     0xc1d89c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1d8a0: ldur            x0, [fp, #-0x10]
    // 0xc1d8a4: LoadField: r1 = r0->field_5f
    //     0xc1d8a4: ldur            w1, [x0, #0x5f]
    // 0xc1d8a8: DecompressPointer r1
    //     0xc1d8a8: add             x1, x1, HEAP, lsl #32
    // 0xc1d8ac: ldur            x2, [fp, #-0x30]
    // 0xc1d8b0: r0 = layer=()
    //     0xc1d8b0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1d8b4: ldur            x2, [fp, #-0x10]
    // 0xc1d8b8: r1 = Function 'paint':.
    //     0xc1d8b8: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1d8bc: ldr             x1, [x1, #0x4e0]
    // 0xc1d8c0: r0 = AllocateClosure()
    //     0xc1d8c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1d8c4: ldur            x1, [fp, #-0x18]
    // 0xc1d8c8: ldur            x2, [fp, #-0x30]
    // 0xc1d8cc: mov             x3, x0
    // 0xc1d8d0: ldur            x5, [fp, #-0x20]
    // 0xc1d8d4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc1d8d4: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc1d8d8: r0 = pushLayer()
    //     0xc1d8d8: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1d8dc: r0 = Null
    //     0xc1d8dc: mov             x0, NULL
    // 0xc1d8e0: LeaveFrame
    //     0xc1d8e0: mov             SP, fp
    //     0xc1d8e4: ldp             fp, lr, [SP], #0x10
    // 0xc1d8e8: ret
    //     0xc1d8e8: ret             
    // 0xc1d8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d8f0: b               #0xc1d848
  }
  _ RenderAnnotatedRegion(/* No info */) {
    // ** addr: 0x11d0148, size: 0xe4
    // 0x11d0148: EnterFrame
    //     0x11d0148: stp             fp, lr, [SP, #-0x10]!
    //     0x11d014c: mov             fp, SP
    // 0x11d0150: AllocStack(0x8)
    //     0x11d0150: sub             SP, SP, #8
    // 0x11d0154: r3 = true
    //     0x11d0154: add             x3, NULL, #0x20  ; true
    // 0x11d0158: mov             x4, x1
    // 0x11d015c: mov             x0, x2
    // 0x11d0160: stur            x1, [fp, #-8]
    // 0x11d0164: CheckStackOverflow
    //     0x11d0164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0168: cmp             SP, x16
    //     0x11d016c: b.ls            #0x11d0224
    // 0x11d0170: StoreField: r4->field_63 = r3
    //     0x11d0170: stur            w3, [x4, #0x63]
    // 0x11d0174: StoreField: r4->field_57 = r0
    //     0x11d0174: stur            w0, [x4, #0x57]
    //     0x11d0178: ldurb           w16, [x4, #-1]
    //     0x11d017c: ldurb           w17, [x0, #-1]
    //     0x11d0180: and             x16, x17, x16, lsr #2
    //     0x11d0184: tst             x16, HEAP, lsr #32
    //     0x11d0188: b.eq            #0x11d0190
    //     0x11d018c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d0190: StoreField: r4->field_5b = r3
    //     0x11d0190: stur            w3, [x4, #0x5b]
    // 0x11d0194: LoadField: r2 = r4->field_53
    //     0x11d0194: ldur            w2, [x4, #0x53]
    // 0x11d0198: DecompressPointer r2
    //     0x11d0198: add             x2, x2, HEAP, lsl #32
    // 0x11d019c: r1 = Null
    //     0x11d019c: mov             x1, NULL
    // 0x11d01a0: r3 = <AnnotatedRegionLayer<X0>>
    //     0x11d01a0: add             x3, PP, #0x26, lsl #12  ; [pp+0x267e0] TypeArguments: <AnnotatedRegionLayer<X0>>
    //     0x11d01a4: ldr             x3, [x3, #0x7e0]
    // 0x11d01a8: r30 = InstantiateTypeArgumentsStub
    //     0x11d01a8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x11d01ac: LoadField: r30 = r30->field_7
    //     0x11d01ac: ldur            lr, [lr, #7]
    // 0x11d01b0: blr             lr
    // 0x11d01b4: mov             x1, x0
    // 0x11d01b8: r0 = LayerHandle()
    //     0x11d01b8: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11d01bc: ldur            x1, [fp, #-8]
    // 0x11d01c0: StoreField: r1->field_5f = r0
    //     0x11d01c0: stur            w0, [x1, #0x5f]
    //     0x11d01c4: ldurb           w16, [x1, #-1]
    //     0x11d01c8: ldurb           w17, [x0, #-1]
    //     0x11d01cc: and             x16, x17, x16, lsr #2
    //     0x11d01d0: tst             x16, HEAP, lsr #32
    //     0x11d01d4: b.eq            #0x11d01dc
    //     0x11d01d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d01dc: r0 = _LayoutCacheStorage()
    //     0x11d01dc: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d01e0: ldur            x2, [fp, #-8]
    // 0x11d01e4: StoreField: r2->field_47 = r0
    //     0x11d01e4: stur            w0, [x2, #0x47]
    //     0x11d01e8: ldurb           w16, [x2, #-1]
    //     0x11d01ec: ldurb           w17, [x0, #-1]
    //     0x11d01f0: and             x16, x17, x16, lsr #2
    //     0x11d01f4: tst             x16, HEAP, lsr #32
    //     0x11d01f8: b.eq            #0x11d0200
    //     0x11d01fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0200: mov             x1, x2
    // 0x11d0204: r0 = RenderObject()
    //     0x11d0204: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d0208: ldur            x1, [fp, #-8]
    // 0x11d020c: r2 = Null
    //     0x11d020c: mov             x2, NULL
    // 0x11d0210: r0 = child=()
    //     0x11d0210: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d0214: r0 = Null
    //     0x11d0214: mov             x0, NULL
    // 0x11d0218: LeaveFrame
    //     0x11d0218: mov             SP, fp
    //     0x11d021c: ldp             fp, lr, [SP], #0x10
    // 0x11d0220: ret
    //     0x11d0220: ret             
    // 0x11d0224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0228: b               #0x11d0170
  }
}

// class id: 4915, size: 0x68, field offset: 0x54
class RenderFollowerLayer extends RenderProxyBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf9424, size: 0x60
    // 0xaf9424: EnterFrame
    //     0xaf9424: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9428: mov             fp, SP
    // 0xaf942c: CheckStackOverflow
    //     0xaf942c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9430: cmp             SP, x16
    //     0xaf9434: b.ls            #0xaf947c
    // 0xaf9438: LoadField: r0 = r1->field_53
    //     0xaf9438: ldur            w0, [x1, #0x53]
    // 0xaf943c: DecompressPointer r0
    //     0xaf943c: add             x0, x0, HEAP, lsl #32
    // 0xaf9440: LoadField: r4 = r0->field_7
    //     0xaf9440: ldur            w4, [x0, #7]
    // 0xaf9444: DecompressPointer r4
    //     0xaf9444: add             x4, x4, HEAP, lsl #32
    // 0xaf9448: cmp             w4, NULL
    // 0xaf944c: b.ne            #0xaf946c
    // 0xaf9450: LoadField: r0 = r1->field_57
    //     0xaf9450: ldur            w0, [x1, #0x57]
    // 0xaf9454: DecompressPointer r0
    //     0xaf9454: add             x0, x0, HEAP, lsl #32
    // 0xaf9458: tbz             w0, #4, #0xaf946c
    // 0xaf945c: r0 = false
    //     0xaf945c: add             x0, NULL, #0x30  ; false
    // 0xaf9460: LeaveFrame
    //     0xaf9460: mov             SP, fp
    //     0xaf9464: ldp             fp, lr, [SP], #0x10
    // 0xaf9468: ret
    //     0xaf9468: ret             
    // 0xaf946c: r0 = hitTestChildren()
    //     0xaf946c: bl              #0x10e984c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren
    // 0xaf9470: LeaveFrame
    //     0xaf9470: mov             SP, fp
    //     0xaf9474: ldp             fp, lr, [SP], #0x10
    // 0xaf9478: ret
    //     0xaf9478: ret             
    // 0xaf947c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf947c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9480: b               #0xaf9438
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1308, size: 0x8c
    // 0xbf1308: EnterFrame
    //     0xbf1308: stp             fp, lr, [SP, #-0x10]!
    //     0xbf130c: mov             fp, SP
    // 0xbf1310: AllocStack(0x10)
    //     0xbf1310: sub             SP, SP, #0x10
    // 0xbf1314: SetupParameters(RenderFollowerLayer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf1314: mov             x4, x1
    //     0xbf1318: mov             x0, x2
    //     0xbf131c: stur            x1, [fp, #-8]
    //     0xbf1320: stur            x3, [fp, #-0x10]
    // 0xbf1324: CheckStackOverflow
    //     0xbf1324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1328: cmp             SP, x16
    //     0xbf132c: b.ls            #0xbf138c
    // 0xbf1330: r2 = Null
    //     0xbf1330: mov             x2, NULL
    // 0xbf1334: r1 = Null
    //     0xbf1334: mov             x1, NULL
    // 0xbf1338: r4 = 60
    //     0xbf1338: mov             x4, #0x3c
    // 0xbf133c: branchIfSmi(r0, 0xbf1348)
    //     0xbf133c: tbz             w0, #0, #0xbf1348
    // 0xbf1340: r4 = LoadClassIdInstr(r0)
    //     0xbf1340: ldur            x4, [x0, #-1]
    //     0xbf1344: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1348: r17 = -4710
    //     0xbf1348: mov             x17, #-0x1266
    // 0xbf134c: add             x4, x4, x17
    // 0xbf1350: cmp             x4, #0x109
    // 0xbf1354: b.ls            #0xbf1368
    // 0xbf1358: r8 = RenderBox
    //     0xbf1358: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf135c: r3 = Null
    //     0xbf135c: add             x3, PP, #0x85, lsl #12  ; [pp+0x854f0] Null
    //     0xbf1360: ldr             x3, [x3, #0x4f0]
    // 0xbf1364: r0 = RenderBox()
    //     0xbf1364: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf1368: ldur            x1, [fp, #-8]
    // 0xbf136c: r0 = getCurrentTransform()
    //     0xbf136c: bl              #0xbf1394  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::getCurrentTransform
    // 0xbf1370: ldur            x1, [fp, #-0x10]
    // 0xbf1374: mov             x2, x0
    // 0xbf1378: r0 = multiply()
    //     0xbf1378: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf137c: r0 = Null
    //     0xbf137c: mov             x0, NULL
    // 0xbf1380: LeaveFrame
    //     0xbf1380: mov             SP, fp
    //     0xbf1384: ldp             fp, lr, [SP], #0x10
    // 0xbf1388: ret
    //     0xbf1388: ret             
    // 0xbf138c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf138c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1390: b               #0xbf1330
  }
  _ getCurrentTransform(/* No info */) {
    // ** addr: 0xbf1394, size: 0x78
    // 0xbf1394: EnterFrame
    //     0xbf1394: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1398: mov             fp, SP
    // 0xbf139c: AllocStack(0x8)
    //     0xbf139c: sub             SP, SP, #8
    // 0xbf13a0: CheckStackOverflow
    //     0xbf13a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf13a4: cmp             SP, x16
    //     0xbf13a8: b.ls            #0xbf1404
    // 0xbf13ac: r0 = layer()
    //     0xbf13ac: bl              #0xbf14c0  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::layer
    // 0xbf13b0: cmp             w0, NULL
    // 0xbf13b4: b.ne            #0xbf13c0
    // 0xbf13b8: r0 = Null
    //     0xbf13b8: mov             x0, NULL
    // 0xbf13bc: b               #0xbf13c8
    // 0xbf13c0: mov             x1, x0
    // 0xbf13c4: r0 = getLastTransform()
    //     0xbf13c4: bl              #0xbf140c  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::getLastTransform
    // 0xbf13c8: cmp             w0, NULL
    // 0xbf13cc: b.ne            #0xbf13f8
    // 0xbf13d0: r0 = Matrix4()
    //     0xbf13d0: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xbf13d4: r4 = 32
    //     0xbf13d4: mov             x4, #0x20
    // 0xbf13d8: stur            x0, [fp, #-8]
    // 0xbf13dc: r0 = AllocateFloat64Array()
    //     0xbf13dc: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xbf13e0: mov             x1, x0
    // 0xbf13e4: ldur            x0, [fp, #-8]
    // 0xbf13e8: StoreField: r0->field_7 = r1
    //     0xbf13e8: stur            w1, [x0, #7]
    // 0xbf13ec: mov             x1, x0
    // 0xbf13f0: r0 = setIdentity()
    //     0xbf13f0: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xbf13f4: ldur            x0, [fp, #-8]
    // 0xbf13f8: LeaveFrame
    //     0xbf13f8: mov             SP, fp
    //     0xbf13fc: ldp             fp, lr, [SP], #0x10
    // 0xbf1400: ret
    //     0xbf1400: ret             
    // 0xbf1404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1408: b               #0xbf13ac
  }
  get _ layer(/* No info */) {
    // ** addr: 0xbf14c0, size: 0x64
    // 0xbf14c0: EnterFrame
    //     0xbf14c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf14c4: mov             fp, SP
    // 0xbf14c8: AllocStack(0x8)
    //     0xbf14c8: sub             SP, SP, #8
    // 0xbf14cc: LoadField: r0 = r1->field_2f
    //     0xbf14cc: ldur            w0, [x1, #0x2f]
    // 0xbf14d0: DecompressPointer r0
    //     0xbf14d0: add             x0, x0, HEAP, lsl #32
    // 0xbf14d4: LoadField: r3 = r0->field_b
    //     0xbf14d4: ldur            w3, [x0, #0xb]
    // 0xbf14d8: DecompressPointer r3
    //     0xbf14d8: add             x3, x3, HEAP, lsl #32
    // 0xbf14dc: mov             x0, x3
    // 0xbf14e0: stur            x3, [fp, #-8]
    // 0xbf14e4: r2 = Null
    //     0xbf14e4: mov             x2, NULL
    // 0xbf14e8: r1 = Null
    //     0xbf14e8: mov             x1, NULL
    // 0xbf14ec: r4 = LoadClassIdInstr(r0)
    //     0xbf14ec: ldur            x4, [x0, #-1]
    //     0xbf14f0: ubfx            x4, x4, #0xc, #0x14
    // 0xbf14f4: r17 = 4651
    //     0xbf14f4: mov             x17, #0x122b
    // 0xbf14f8: cmp             x4, x17
    // 0xbf14fc: b.eq            #0xbf1514
    // 0xbf1500: r8 = FollowerLayer?
    //     0xbf1500: add             x8, PP, #0x85, lsl #12  ; [pp+0x85500] Type: FollowerLayer?
    //     0xbf1504: ldr             x8, [x8, #0x500]
    // 0xbf1508: r3 = Null
    //     0xbf1508: add             x3, PP, #0x85, lsl #12  ; [pp+0x85508] Null
    //     0xbf150c: ldr             x3, [x3, #0x508]
    // 0xbf1510: r0 = DefaultNullableTypeTest()
    //     0xbf1510: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xbf1514: ldur            x0, [fp, #-8]
    // 0xbf1518: LeaveFrame
    //     0xbf1518: mov             SP, fp
    //     0xbf151c: ldp             fp, lr, [SP], #0x10
    // 0xbf1520: ret
    //     0xbf1520: ret             
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05e28, size: 0x50
    // 0xc05e28: EnterFrame
    //     0xc05e28: stp             fp, lr, [SP, #-0x10]!
    //     0xc05e2c: mov             fp, SP
    // 0xc05e30: AllocStack(0x8)
    //     0xc05e30: sub             SP, SP, #8
    // 0xc05e34: SetupParameters(RenderFollowerLayer this /* r1 => r0, fp-0x8 */)
    //     0xc05e34: mov             x0, x1
    //     0xc05e38: stur            x1, [fp, #-8]
    // 0xc05e3c: CheckStackOverflow
    //     0xc05e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05e40: cmp             SP, x16
    //     0xc05e44: b.ls            #0xc05e70
    // 0xc05e48: LoadField: r1 = r0->field_2f
    //     0xc05e48: ldur            w1, [x0, #0x2f]
    // 0xc05e4c: DecompressPointer r1
    //     0xc05e4c: add             x1, x1, HEAP, lsl #32
    // 0xc05e50: r2 = Null
    //     0xc05e50: mov             x2, NULL
    // 0xc05e54: r0 = layer=()
    //     0xc05e54: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc05e58: ldur            x1, [fp, #-8]
    // 0xc05e5c: r0 = detach()
    //     0xc05e5c: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc05e60: r0 = Null
    //     0xc05e60: mov             x0, NULL
    // 0xc05e64: LeaveFrame
    //     0xc05e64: mov             SP, fp
    //     0xc05e68: ldp             fp, lr, [SP], #0x10
    // 0xc05e6c: ret
    //     0xc05e6c: ret             
    // 0xc05e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05e70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05e74: b               #0xc05e48
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1d570, size: 0x29c
    // 0xc1d570: EnterFrame
    //     0xc1d570: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d574: mov             fp, SP
    // 0xc1d578: AllocStack(0x50)
    //     0xc1d578: sub             SP, SP, #0x50
    // 0xc1d57c: SetupParameters(RenderFollowerLayer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc1d57c: mov             x4, x1
    //     0xc1d580: mov             x0, x3
    //     0xc1d584: stur            x3, [fp, #-0x18]
    //     0xc1d588: mov             x3, x2
    //     0xc1d58c: stur            x1, [fp, #-8]
    //     0xc1d590: stur            x2, [fp, #-0x10]
    // 0xc1d594: CheckStackOverflow
    //     0xc1d594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d598: cmp             SP, x16
    //     0xc1d59c: b.ls            #0xc1d800
    // 0xc1d5a0: LoadField: r1 = r4->field_53
    //     0xc1d5a0: ldur            w1, [x4, #0x53]
    // 0xc1d5a4: DecompressPointer r1
    //     0xc1d5a4: add             x1, x1, HEAP, lsl #32
    // 0xc1d5a8: LoadField: r2 = r1->field_b
    //     0xc1d5a8: ldur            w2, [x1, #0xb]
    // 0xc1d5ac: DecompressPointer r2
    //     0xc1d5ac: add             x2, x2, HEAP, lsl #32
    // 0xc1d5b0: cmp             w2, NULL
    // 0xc1d5b4: b.ne            #0xc1d5cc
    // 0xc1d5b8: LoadField: r1 = r4->field_5b
    //     0xc1d5b8: ldur            w1, [x4, #0x5b]
    // 0xc1d5bc: DecompressPointer r1
    //     0xc1d5bc: add             x1, x1, HEAP, lsl #32
    // 0xc1d5c0: mov             x3, x4
    // 0xc1d5c4: mov             x4, x1
    // 0xc1d5c8: b               #0xc1d61c
    // 0xc1d5cc: r1 = Instance_Alignment
    //     0xc1d5cc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xc1d5d0: ldr             x1, [x1, #0x510]
    // 0xc1d5d4: r0 = alongOffset()
    //     0xc1d5d4: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xc1d5d8: ldur            x1, [fp, #-8]
    // 0xc1d5dc: stur            x0, [fp, #-0x20]
    // 0xc1d5e0: r0 = size()
    //     0xc1d5e0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1d5e4: mov             x2, x0
    // 0xc1d5e8: r1 = Instance_Alignment
    //     0xc1d5e8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xc1d5ec: ldr             x1, [x1, #0x510]
    // 0xc1d5f0: r0 = alongOffset()
    //     0xc1d5f0: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xc1d5f4: ldur            x1, [fp, #-0x20]
    // 0xc1d5f8: mov             x2, x0
    // 0xc1d5fc: r0 = -()
    //     0xc1d5fc: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xc1d600: mov             x1, x0
    // 0xc1d604: ldur            x0, [fp, #-8]
    // 0xc1d608: LoadField: r2 = r0->field_5b
    //     0xc1d608: ldur            w2, [x0, #0x5b]
    // 0xc1d60c: DecompressPointer r2
    //     0xc1d60c: add             x2, x2, HEAP, lsl #32
    // 0xc1d610: r0 = +()
    //     0xc1d610: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc1d614: mov             x4, x0
    // 0xc1d618: ldur            x3, [fp, #-8]
    // 0xc1d61c: stur            x4, [fp, #-0x30]
    // 0xc1d620: LoadField: r5 = r3->field_2f
    //     0xc1d620: ldur            w5, [x3, #0x2f]
    // 0xc1d624: DecompressPointer r5
    //     0xc1d624: add             x5, x5, HEAP, lsl #32
    // 0xc1d628: stur            x5, [fp, #-0x28]
    // 0xc1d62c: LoadField: r6 = r5->field_b
    //     0xc1d62c: ldur            w6, [x5, #0xb]
    // 0xc1d630: DecompressPointer r6
    //     0xc1d630: add             x6, x6, HEAP, lsl #32
    // 0xc1d634: mov             x0, x6
    // 0xc1d638: stur            x6, [fp, #-0x20]
    // 0xc1d63c: r2 = Null
    //     0xc1d63c: mov             x2, NULL
    // 0xc1d640: r1 = Null
    //     0xc1d640: mov             x1, NULL
    // 0xc1d644: r4 = LoadClassIdInstr(r0)
    //     0xc1d644: ldur            x4, [x0, #-1]
    //     0xc1d648: ubfx            x4, x4, #0xc, #0x14
    // 0xc1d64c: r17 = 4651
    //     0xc1d64c: mov             x17, #0x122b
    // 0xc1d650: cmp             x4, x17
    // 0xc1d654: b.eq            #0xc1d66c
    // 0xc1d658: r8 = FollowerLayer?
    //     0xc1d658: add             x8, PP, #0x85, lsl #12  ; [pp+0x85500] Type: FollowerLayer?
    //     0xc1d65c: ldr             x8, [x8, #0x500]
    // 0xc1d660: r3 = Null
    //     0xc1d660: add             x3, PP, #0x85, lsl #12  ; [pp+0x85518] Null
    //     0xc1d664: ldr             x3, [x3, #0x518]
    // 0xc1d668: r0 = DefaultNullableTypeTest()
    //     0xc1d668: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1d66c: ldur            x1, [fp, #-0x20]
    // 0xc1d670: cmp             w1, NULL
    // 0xc1d674: b.ne            #0xc1d6ec
    // 0xc1d678: ldur            x1, [fp, #-8]
    // 0xc1d67c: ldur            x2, [fp, #-0x18]
    // 0xc1d680: ldur            x0, [fp, #-0x30]
    // 0xc1d684: LoadField: r3 = r1->field_53
    //     0xc1d684: ldur            w3, [x1, #0x53]
    // 0xc1d688: DecompressPointer r3
    //     0xc1d688: add             x3, x3, HEAP, lsl #32
    // 0xc1d68c: stur            x3, [fp, #-0x40]
    // 0xc1d690: LoadField: r4 = r1->field_57
    //     0xc1d690: ldur            w4, [x1, #0x57]
    // 0xc1d694: DecompressPointer r4
    //     0xc1d694: add             x4, x4, HEAP, lsl #32
    // 0xc1d698: stur            x4, [fp, #-0x38]
    // 0xc1d69c: r0 = FollowerLayer()
    //     0xc1d69c: bl              #0xc1d80c  ; AllocateFollowerLayerStub -> FollowerLayer (size=0x68)
    // 0xc1d6a0: mov             x2, x0
    // 0xc1d6a4: r0 = true
    //     0xc1d6a4: add             x0, NULL, #0x20  ; true
    // 0xc1d6a8: stur            x2, [fp, #-0x48]
    // 0xc1d6ac: StoreField: r2->field_63 = r0
    //     0xc1d6ac: stur            w0, [x2, #0x63]
    // 0xc1d6b0: ldur            x0, [fp, #-0x40]
    // 0xc1d6b4: StoreField: r2->field_47 = r0
    //     0xc1d6b4: stur            w0, [x2, #0x47]
    // 0xc1d6b8: ldur            x0, [fp, #-0x38]
    // 0xc1d6bc: StoreField: r2->field_4b = r0
    //     0xc1d6bc: stur            w0, [x2, #0x4b]
    // 0xc1d6c0: ldur            x3, [fp, #-0x18]
    // 0xc1d6c4: StoreField: r2->field_4f = r3
    //     0xc1d6c4: stur            w3, [x2, #0x4f]
    // 0xc1d6c8: ldur            x4, [fp, #-0x30]
    // 0xc1d6cc: StoreField: r2->field_53 = r4
    //     0xc1d6cc: stur            w4, [x2, #0x53]
    // 0xc1d6d0: mov             x1, x2
    // 0xc1d6d4: r0 = Layer()
    //     0xc1d6d4: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1d6d8: ldur            x1, [fp, #-8]
    // 0xc1d6dc: ldur            x2, [fp, #-0x48]
    // 0xc1d6e0: r0 = layer=()
    //     0xc1d6e0: bl              #0xc05e78  ; [package:flutter/src/rendering/object.dart] RenderObject::layer=
    // 0xc1d6e4: ldur            x5, [fp, #-8]
    // 0xc1d6e8: b               #0xc1d768
    // 0xc1d6ec: ldur            x5, [fp, #-8]
    // 0xc1d6f0: ldur            x3, [fp, #-0x18]
    // 0xc1d6f4: ldur            x4, [fp, #-0x30]
    // 0xc1d6f8: LoadField: r0 = r5->field_53
    //     0xc1d6f8: ldur            w0, [x5, #0x53]
    // 0xc1d6fc: DecompressPointer r0
    //     0xc1d6fc: add             x0, x0, HEAP, lsl #32
    // 0xc1d700: StoreField: r1->field_47 = r0
    //     0xc1d700: stur            w0, [x1, #0x47]
    //     0xc1d704: ldurb           w16, [x1, #-1]
    //     0xc1d708: ldurb           w17, [x0, #-1]
    //     0xc1d70c: and             x16, x17, x16, lsr #2
    //     0xc1d710: tst             x16, HEAP, lsr #32
    //     0xc1d714: b.eq            #0xc1d71c
    //     0xc1d718: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1d71c: LoadField: r0 = r5->field_57
    //     0xc1d71c: ldur            w0, [x5, #0x57]
    // 0xc1d720: DecompressPointer r0
    //     0xc1d720: add             x0, x0, HEAP, lsl #32
    // 0xc1d724: StoreField: r1->field_4b = r0
    //     0xc1d724: stur            w0, [x1, #0x4b]
    // 0xc1d728: mov             x0, x4
    // 0xc1d72c: StoreField: r1->field_53 = r0
    //     0xc1d72c: stur            w0, [x1, #0x53]
    //     0xc1d730: ldurb           w16, [x1, #-1]
    //     0xc1d734: ldurb           w17, [x0, #-1]
    //     0xc1d738: and             x16, x17, x16, lsr #2
    //     0xc1d73c: tst             x16, HEAP, lsr #32
    //     0xc1d740: b.eq            #0xc1d748
    //     0xc1d744: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1d748: mov             x0, x3
    // 0xc1d74c: StoreField: r1->field_4f = r0
    //     0xc1d74c: stur            w0, [x1, #0x4f]
    //     0xc1d750: ldurb           w16, [x1, #-1]
    //     0xc1d754: ldurb           w17, [x0, #-1]
    //     0xc1d758: and             x16, x17, x16, lsr #2
    //     0xc1d75c: tst             x16, HEAP, lsr #32
    //     0xc1d760: b.eq            #0xc1d768
    //     0xc1d764: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1d768: ldur            x0, [fp, #-0x28]
    // 0xc1d76c: LoadField: r3 = r0->field_b
    //     0xc1d76c: ldur            w3, [x0, #0xb]
    // 0xc1d770: DecompressPointer r3
    //     0xc1d770: add             x3, x3, HEAP, lsl #32
    // 0xc1d774: mov             x0, x3
    // 0xc1d778: stur            x3, [fp, #-0x18]
    // 0xc1d77c: r2 = Null
    //     0xc1d77c: mov             x2, NULL
    // 0xc1d780: r1 = Null
    //     0xc1d780: mov             x1, NULL
    // 0xc1d784: r4 = LoadClassIdInstr(r0)
    //     0xc1d784: ldur            x4, [x0, #-1]
    //     0xc1d788: ubfx            x4, x4, #0xc, #0x14
    // 0xc1d78c: r17 = 4651
    //     0xc1d78c: mov             x17, #0x122b
    // 0xc1d790: cmp             x4, x17
    // 0xc1d794: b.eq            #0xc1d7ac
    // 0xc1d798: r8 = FollowerLayer?
    //     0xc1d798: add             x8, PP, #0x85, lsl #12  ; [pp+0x85500] Type: FollowerLayer?
    //     0xc1d79c: ldr             x8, [x8, #0x500]
    // 0xc1d7a0: r3 = Null
    //     0xc1d7a0: add             x3, PP, #0x85, lsl #12  ; [pp+0x85528] Null
    //     0xc1d7a4: ldr             x3, [x3, #0x528]
    // 0xc1d7a8: r0 = DefaultNullableTypeTest()
    //     0xc1d7a8: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1d7ac: ldur            x0, [fp, #-0x18]
    // 0xc1d7b0: cmp             w0, NULL
    // 0xc1d7b4: b.eq            #0xc1d808
    // 0xc1d7b8: ldur            x2, [fp, #-8]
    // 0xc1d7bc: r1 = Function 'paint':.
    //     0xc1d7bc: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1d7c0: ldr             x1, [x1, #0x4e0]
    // 0xc1d7c4: r0 = AllocateClosure()
    //     0xc1d7c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1d7c8: r16 = Instance_Rect
    //     0xc1d7c8: add             x16, PP, #0x85, lsl #12  ; [pp+0x85538] Obj!Rect@12a7481
    //     0xc1d7cc: ldr             x16, [x16, #0x538]
    // 0xc1d7d0: str             x16, [SP]
    // 0xc1d7d4: ldur            x1, [fp, #-0x10]
    // 0xc1d7d8: ldur            x2, [fp, #-0x18]
    // 0xc1d7dc: mov             x3, x0
    // 0xc1d7e0: r5 = Instance_Offset
    //     0xc1d7e0: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1d7e4: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc1d7e4: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc1d7e8: ldr             x4, [x4, #0x540]
    // 0xc1d7ec: r0 = pushLayer()
    //     0xc1d7ec: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1d7f0: r0 = Null
    //     0xc1d7f0: mov             x0, NULL
    // 0xc1d7f4: LeaveFrame
    //     0xc1d7f4: mov             SP, fp
    //     0xc1d7f8: ldp             fp, lr, [SP], #0x10
    // 0xc1d7fc: ret
    //     0xc1d7fc: ret             
    // 0xc1d800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d800: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d804: b               #0xc1d5a0
    // 0xc1d808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1d808: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ followerAnchor=(/* No info */) {
    // ** addr: 0xcf7268, size: 0x74
    // 0xcf7268: EnterFrame
    //     0xcf7268: stp             fp, lr, [SP, #-0x10]!
    //     0xcf726c: mov             fp, SP
    // 0xcf7270: AllocStack(0x18)
    //     0xcf7270: sub             SP, SP, #0x18
    // 0xcf7274: SetupParameters(RenderFollowerLayer this /* r1 => r1, fp-0x8 */)
    //     0xcf7274: stur            x1, [fp, #-8]
    // 0xcf7278: CheckStackOverflow
    //     0xcf7278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf727c: cmp             SP, x16
    //     0xcf7280: b.ls            #0xcf72d4
    // 0xcf7284: r16 = Instance_Alignment
    //     0xcf7284: add             x16, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf7288: ldr             x16, [x16, #0x510]
    // 0xcf728c: r30 = Instance_Alignment
    //     0xcf728c: add             lr, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf7290: ldr             lr, [lr, #0x510]
    // 0xcf7294: stp             lr, x16, [SP]
    // 0xcf7298: r0 = ==()
    //     0xcf7298: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xcf729c: tbnz            w0, #4, #0xcf72b0
    // 0xcf72a0: r0 = Null
    //     0xcf72a0: mov             x0, NULL
    // 0xcf72a4: LeaveFrame
    //     0xcf72a4: mov             SP, fp
    //     0xcf72a8: ldp             fp, lr, [SP], #0x10
    // 0xcf72ac: ret
    //     0xcf72ac: ret             
    // 0xcf72b0: ldur            x1, [fp, #-8]
    // 0xcf72b4: r0 = Instance_Alignment
    //     0xcf72b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf72b8: ldr             x0, [x0, #0x510]
    // 0xcf72bc: StoreField: r1->field_63 = r0
    //     0xcf72bc: stur            w0, [x1, #0x63]
    // 0xcf72c0: r0 = markNeedsPaint()
    //     0xcf72c0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf72c4: r0 = Null
    //     0xcf72c4: mov             x0, NULL
    // 0xcf72c8: LeaveFrame
    //     0xcf72c8: mov             SP, fp
    //     0xcf72cc: ldp             fp, lr, [SP], #0x10
    // 0xcf72d0: ret
    //     0xcf72d0: ret             
    // 0xcf72d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf72d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf72d8: b               #0xcf7284
  }
  set _ leaderAnchor=(/* No info */) {
    // ** addr: 0xcf72dc, size: 0x74
    // 0xcf72dc: EnterFrame
    //     0xcf72dc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf72e0: mov             fp, SP
    // 0xcf72e4: AllocStack(0x18)
    //     0xcf72e4: sub             SP, SP, #0x18
    // 0xcf72e8: SetupParameters(RenderFollowerLayer this /* r1 => r1, fp-0x8 */)
    //     0xcf72e8: stur            x1, [fp, #-8]
    // 0xcf72ec: CheckStackOverflow
    //     0xcf72ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf72f0: cmp             SP, x16
    //     0xcf72f4: b.ls            #0xcf7348
    // 0xcf72f8: r16 = Instance_Alignment
    //     0xcf72f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf72fc: ldr             x16, [x16, #0x510]
    // 0xcf7300: r30 = Instance_Alignment
    //     0xcf7300: add             lr, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf7304: ldr             lr, [lr, #0x510]
    // 0xcf7308: stp             lr, x16, [SP]
    // 0xcf730c: r0 = ==()
    //     0xcf730c: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xcf7310: tbnz            w0, #4, #0xcf7324
    // 0xcf7314: r0 = Null
    //     0xcf7314: mov             x0, NULL
    // 0xcf7318: LeaveFrame
    //     0xcf7318: mov             SP, fp
    //     0xcf731c: ldp             fp, lr, [SP], #0x10
    // 0xcf7320: ret
    //     0xcf7320: ret             
    // 0xcf7324: ldur            x1, [fp, #-8]
    // 0xcf7328: r0 = Instance_Alignment
    //     0xcf7328: add             x0, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf732c: ldr             x0, [x0, #0x510]
    // 0xcf7330: StoreField: r1->field_5f = r0
    //     0xcf7330: stur            w0, [x1, #0x5f]
    // 0xcf7334: r0 = markNeedsPaint()
    //     0xcf7334: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf7338: r0 = Null
    //     0xcf7338: mov             x0, NULL
    // 0xcf733c: LeaveFrame
    //     0xcf733c: mov             SP, fp
    //     0xcf7340: ldp             fp, lr, [SP], #0x10
    // 0xcf7344: ret
    //     0xcf7344: ret             
    // 0xcf7348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf734c: b               #0xcf72f8
  }
  set _ offset=(/* No info */) {
    // ** addr: 0xcf7350, size: 0x88
    // 0xcf7350: EnterFrame
    //     0xcf7350: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7354: mov             fp, SP
    // 0xcf7358: AllocStack(0x20)
    //     0xcf7358: sub             SP, SP, #0x20
    // 0xcf735c: SetupParameters(RenderFollowerLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf735c: mov             x0, x2
    //     0xcf7360: stur            x1, [fp, #-8]
    //     0xcf7364: stur            x2, [fp, #-0x10]
    // 0xcf7368: CheckStackOverflow
    //     0xcf7368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf736c: cmp             SP, x16
    //     0xcf7370: b.ls            #0xcf73d0
    // 0xcf7374: LoadField: r2 = r1->field_5b
    //     0xcf7374: ldur            w2, [x1, #0x5b]
    // 0xcf7378: DecompressPointer r2
    //     0xcf7378: add             x2, x2, HEAP, lsl #32
    // 0xcf737c: stp             x0, x2, [SP]
    // 0xcf7380: r0 = ==()
    //     0xcf7380: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xcf7384: tbnz            w0, #4, #0xcf7398
    // 0xcf7388: r0 = Null
    //     0xcf7388: mov             x0, NULL
    // 0xcf738c: LeaveFrame
    //     0xcf738c: mov             SP, fp
    //     0xcf7390: ldp             fp, lr, [SP], #0x10
    // 0xcf7394: ret
    //     0xcf7394: ret             
    // 0xcf7398: ldur            x1, [fp, #-8]
    // 0xcf739c: ldur            x0, [fp, #-0x10]
    // 0xcf73a0: StoreField: r1->field_5b = r0
    //     0xcf73a0: stur            w0, [x1, #0x5b]
    //     0xcf73a4: ldurb           w16, [x1, #-1]
    //     0xcf73a8: ldurb           w17, [x0, #-1]
    //     0xcf73ac: and             x16, x17, x16, lsr #2
    //     0xcf73b0: tst             x16, HEAP, lsr #32
    //     0xcf73b4: b.eq            #0xcf73bc
    //     0xcf73b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf73bc: r0 = markNeedsPaint()
    //     0xcf73bc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf73c0: r0 = Null
    //     0xcf73c0: mov             x0, NULL
    // 0xcf73c4: LeaveFrame
    //     0xcf73c4: mov             SP, fp
    //     0xcf73c8: ldp             fp, lr, [SP], #0x10
    // 0xcf73cc: ret
    //     0xcf73cc: ret             
    // 0xcf73d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf73d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf73d4: b               #0xcf7374
  }
  set _ showWhenUnlinked=(/* No info */) {
    // ** addr: 0xcf73d8, size: 0x54
    // 0xcf73d8: EnterFrame
    //     0xcf73d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf73dc: mov             fp, SP
    // 0xcf73e0: CheckStackOverflow
    //     0xcf73e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf73e4: cmp             SP, x16
    //     0xcf73e8: b.ls            #0xcf7424
    // 0xcf73ec: LoadField: r0 = r1->field_57
    //     0xcf73ec: ldur            w0, [x1, #0x57]
    // 0xcf73f0: DecompressPointer r0
    //     0xcf73f0: add             x0, x0, HEAP, lsl #32
    // 0xcf73f4: cmp             w0, w2
    // 0xcf73f8: b.ne            #0xcf740c
    // 0xcf73fc: r0 = Null
    //     0xcf73fc: mov             x0, NULL
    // 0xcf7400: LeaveFrame
    //     0xcf7400: mov             SP, fp
    //     0xcf7404: ldp             fp, lr, [SP], #0x10
    // 0xcf7408: ret
    //     0xcf7408: ret             
    // 0xcf740c: StoreField: r1->field_57 = r2
    //     0xcf740c: stur            w2, [x1, #0x57]
    // 0xcf7410: r0 = markNeedsPaint()
    //     0xcf7410: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf7414: r0 = Null
    //     0xcf7414: mov             x0, NULL
    // 0xcf7418: LeaveFrame
    //     0xcf7418: mov             SP, fp
    //     0xcf741c: ldp             fp, lr, [SP], #0x10
    // 0xcf7420: ret
    //     0xcf7420: ret             
    // 0xcf7424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7428: b               #0xcf73ec
  }
  set _ link=(/* No info */) {
    // ** addr: 0xcf742c, size: 0x70
    // 0xcf742c: EnterFrame
    //     0xcf742c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7430: mov             fp, SP
    // 0xcf7434: mov             x0, x2
    // 0xcf7438: CheckStackOverflow
    //     0xcf7438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf743c: cmp             SP, x16
    //     0xcf7440: b.ls            #0xcf7494
    // 0xcf7444: LoadField: r2 = r1->field_53
    //     0xcf7444: ldur            w2, [x1, #0x53]
    // 0xcf7448: DecompressPointer r2
    //     0xcf7448: add             x2, x2, HEAP, lsl #32
    // 0xcf744c: cmp             w2, w0
    // 0xcf7450: b.ne            #0xcf7464
    // 0xcf7454: r0 = Null
    //     0xcf7454: mov             x0, NULL
    // 0xcf7458: LeaveFrame
    //     0xcf7458: mov             SP, fp
    //     0xcf745c: ldp             fp, lr, [SP], #0x10
    // 0xcf7460: ret
    //     0xcf7460: ret             
    // 0xcf7464: StoreField: r1->field_53 = r0
    //     0xcf7464: stur            w0, [x1, #0x53]
    //     0xcf7468: ldurb           w16, [x1, #-1]
    //     0xcf746c: ldurb           w17, [x0, #-1]
    //     0xcf7470: and             x16, x17, x16, lsr #2
    //     0xcf7474: tst             x16, HEAP, lsr #32
    //     0xcf7478: b.eq            #0xcf7480
    //     0xcf747c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7480: r0 = markNeedsPaint()
    //     0xcf7480: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf7484: r0 = Null
    //     0xcf7484: mov             x0, NULL
    // 0xcf7488: LeaveFrame
    //     0xcf7488: mov             SP, fp
    //     0xcf748c: ldp             fp, lr, [SP], #0x10
    // 0xcf7490: ret
    //     0xcf7490: ret             
    // 0xcf7494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7498: b               #0xcf7444
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x10e95dc, size: 0x4c
    // 0x10e95dc: EnterFrame
    //     0x10e95dc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e95e0: mov             fp, SP
    // 0x10e95e4: ldr             x0, [fp, #0x20]
    // 0x10e95e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e95e8: ldur            w1, [x0, #0x17]
    // 0x10e95ec: DecompressPointer r1
    //     0x10e95ec: add             x1, x1, HEAP, lsl #32
    // 0x10e95f0: CheckStackOverflow
    //     0x10e95f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e95f4: cmp             SP, x16
    //     0x10e95f8: b.ls            #0x10e9620
    // 0x10e95fc: LoadField: r0 = r1->field_f
    //     0x10e95fc: ldur            w0, [x1, #0xf]
    // 0x10e9600: DecompressPointer r0
    //     0x10e9600: add             x0, x0, HEAP, lsl #32
    // 0x10e9604: mov             x1, x0
    // 0x10e9608: ldr             x2, [fp, #0x18]
    // 0x10e960c: ldr             x3, [fp, #0x10]
    // 0x10e9610: r0 = hitTestChildren()
    //     0x10e9610: bl              #0x10e9bac  ; [package:syncfusion_flutter_charts/src/charts/common/element_widget.dart] CustomRenderLayoutBuilder::hitTestChildren
    // 0x10e9614: LeaveFrame
    //     0x10e9614: mov             SP, fp
    //     0x10e9618: ldp             fp, lr, [SP], #0x10
    // 0x10e961c: ret
    //     0x10e961c: ret             
    // 0x10e9620: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9620: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9624: b               #0x10e95fc
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e984c, size: 0x80
    // 0x10e984c: EnterFrame
    //     0x10e984c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e9850: mov             fp, SP
    // 0x10e9854: AllocStack(0x20)
    //     0x10e9854: sub             SP, SP, #0x20
    // 0x10e9858: SetupParameters(RenderFollowerLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10e9858: mov             x0, x1
    //     0x10e985c: stur            x1, [fp, #-8]
    //     0x10e9860: mov             x1, x2
    //     0x10e9864: stur            x2, [fp, #-0x10]
    //     0x10e9868: stur            x3, [fp, #-0x18]
    // 0x10e986c: CheckStackOverflow
    //     0x10e986c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e9870: cmp             SP, x16
    //     0x10e9874: b.ls            #0x10e98c4
    // 0x10e9878: r1 = 1
    //     0x10e9878: mov             x1, #1
    // 0x10e987c: r0 = AllocateContext()
    //     0x10e987c: bl              #0x13de838  ; AllocateContextStub
    // 0x10e9880: ldur            x1, [fp, #-8]
    // 0x10e9884: stur            x0, [fp, #-0x20]
    // 0x10e9888: StoreField: r0->field_f = r1
    //     0x10e9888: stur            w1, [x0, #0xf]
    // 0x10e988c: r0 = getCurrentTransform()
    //     0x10e988c: bl              #0xbf1394  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::getCurrentTransform
    // 0x10e9890: ldur            x2, [fp, #-0x20]
    // 0x10e9894: r1 = Function '<anonymous closure>':.
    //     0x10e9894: add             x1, PP, #0x85, lsl #12  ; [pp+0x85548] AnonymousClosure: (0x10e95dc), in [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren (0x10e984c)
    //     0x10e9898: ldr             x1, [x1, #0x548]
    // 0x10e989c: stur            x0, [fp, #-8]
    // 0x10e98a0: r0 = AllocateClosure()
    //     0x10e98a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e98a4: ldur            x1, [fp, #-0x10]
    // 0x10e98a8: mov             x2, x0
    // 0x10e98ac: ldur            x3, [fp, #-0x18]
    // 0x10e98b0: ldur            x5, [fp, #-8]
    // 0x10e98b4: r0 = addWithPaintTransform()
    //     0x10e98b4: bl              #0x10e8cac  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x10e98b8: LeaveFrame
    //     0x10e98b8: mov             SP, fp
    //     0x10e98bc: ldp             fp, lr, [SP], #0x10
    // 0x10e98c0: ret
    //     0x10e98c0: ret             
    // 0x10e98c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e98c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e98c8: b               #0x10e9878
  }
  _ RenderFollowerLayer(/* No info */) {
    // ** addr: 0x11d0e98, size: 0xc8
    // 0x11d0e98: EnterFrame
    //     0x11d0e98: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0e9c: mov             fp, SP
    // 0x11d0ea0: AllocStack(0x8)
    //     0x11d0ea0: sub             SP, SP, #8
    // 0x11d0ea4: r4 = Instance_Alignment
    //     0x11d0ea4: add             x4, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0x11d0ea8: ldr             x4, [x4, #0x510]
    // 0x11d0eac: mov             x0, x2
    // 0x11d0eb0: mov             x2, x1
    // 0x11d0eb4: stur            x1, [fp, #-8]
    // 0x11d0eb8: mov             x1, x3
    // 0x11d0ebc: CheckStackOverflow
    //     0x11d0ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0ec0: cmp             SP, x16
    //     0x11d0ec4: b.ls            #0x11d0f58
    // 0x11d0ec8: StoreField: r2->field_53 = r0
    //     0x11d0ec8: stur            w0, [x2, #0x53]
    //     0x11d0ecc: ldurb           w16, [x2, #-1]
    //     0x11d0ed0: ldurb           w17, [x0, #-1]
    //     0x11d0ed4: and             x16, x17, x16, lsr #2
    //     0x11d0ed8: tst             x16, HEAP, lsr #32
    //     0x11d0edc: b.eq            #0x11d0ee4
    //     0x11d0ee0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0ee4: StoreField: r2->field_57 = r5
    //     0x11d0ee4: stur            w5, [x2, #0x57]
    // 0x11d0ee8: mov             x0, x1
    // 0x11d0eec: StoreField: r2->field_5b = r0
    //     0x11d0eec: stur            w0, [x2, #0x5b]
    //     0x11d0ef0: ldurb           w16, [x2, #-1]
    //     0x11d0ef4: ldurb           w17, [x0, #-1]
    //     0x11d0ef8: and             x16, x17, x16, lsr #2
    //     0x11d0efc: tst             x16, HEAP, lsr #32
    //     0x11d0f00: b.eq            #0x11d0f08
    //     0x11d0f04: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0f08: StoreField: r2->field_5f = r4
    //     0x11d0f08: stur            w4, [x2, #0x5f]
    // 0x11d0f0c: StoreField: r2->field_63 = r4
    //     0x11d0f0c: stur            w4, [x2, #0x63]
    // 0x11d0f10: r0 = _LayoutCacheStorage()
    //     0x11d0f10: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d0f14: ldur            x2, [fp, #-8]
    // 0x11d0f18: StoreField: r2->field_47 = r0
    //     0x11d0f18: stur            w0, [x2, #0x47]
    //     0x11d0f1c: ldurb           w16, [x2, #-1]
    //     0x11d0f20: ldurb           w17, [x0, #-1]
    //     0x11d0f24: and             x16, x17, x16, lsr #2
    //     0x11d0f28: tst             x16, HEAP, lsr #32
    //     0x11d0f2c: b.eq            #0x11d0f34
    //     0x11d0f30: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0f34: mov             x1, x2
    // 0x11d0f38: r0 = RenderObject()
    //     0x11d0f38: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d0f3c: ldur            x1, [fp, #-8]
    // 0x11d0f40: r2 = Null
    //     0x11d0f40: mov             x2, NULL
    // 0x11d0f44: r0 = child=()
    //     0x11d0f44: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d0f48: r0 = Null
    //     0x11d0f48: mov             x0, NULL
    // 0x11d0f4c: LeaveFrame
    //     0x11d0f4c: mov             SP, fp
    //     0x11d0f50: ldp             fp, lr, [SP], #0x10
    // 0x11d0f54: ret
    //     0x11d0f54: ret             
    // 0x11d0f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0f5c: b               #0x11d0ec8
  }
}

// class id: 4916, size: 0x5c, field offset: 0x54
class RenderLeaderLayer extends RenderProxyBox {

  _ performLayout(/* No info */) {
    // ** addr: 0xbb99a4, size: 0x98
    // 0xbb99a4: EnterFrame
    //     0xbb99a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbb99a8: mov             fp, SP
    // 0xbb99ac: AllocStack(0x10)
    //     0xbb99ac: sub             SP, SP, #0x10
    // 0xbb99b0: SetupParameters(RenderLeaderLayer this /* r1 => r0, fp-0x8 */)
    //     0xbb99b0: mov             x0, x1
    //     0xbb99b4: stur            x1, [fp, #-8]
    // 0xbb99b8: CheckStackOverflow
    //     0xbb99b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb99bc: cmp             SP, x16
    //     0xbb99c0: b.ls            #0xbb9a34
    // 0xbb99c4: mov             x1, x0
    // 0xbb99c8: r0 = performLayout()
    //     0xbb99c8: bl              #0xbba2a4  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0xbb99cc: ldur            x1, [fp, #-8]
    // 0xbb99d0: r0 = size()
    //     0xbb99d0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb99d4: ldur            x1, [fp, #-8]
    // 0xbb99d8: StoreField: r1->field_57 = r0
    //     0xbb99d8: stur            w0, [x1, #0x57]
    //     0xbb99dc: ldurb           w16, [x1, #-1]
    //     0xbb99e0: ldurb           w17, [x0, #-1]
    //     0xbb99e4: and             x16, x17, x16, lsr #2
    //     0xbb99e8: tst             x16, HEAP, lsr #32
    //     0xbb99ec: b.eq            #0xbb99f4
    //     0xbb99f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb99f4: LoadField: r0 = r1->field_53
    //     0xbb99f4: ldur            w0, [x1, #0x53]
    // 0xbb99f8: DecompressPointer r0
    //     0xbb99f8: add             x0, x0, HEAP, lsl #32
    // 0xbb99fc: stur            x0, [fp, #-0x10]
    // 0xbb9a00: r0 = size()
    //     0xbb9a00: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb9a04: ldur            x1, [fp, #-0x10]
    // 0xbb9a08: StoreField: r1->field_b = r0
    //     0xbb9a08: stur            w0, [x1, #0xb]
    //     0xbb9a0c: ldurb           w16, [x1, #-1]
    //     0xbb9a10: ldurb           w17, [x0, #-1]
    //     0xbb9a14: and             x16, x17, x16, lsr #2
    //     0xbb9a18: tst             x16, HEAP, lsr #32
    //     0xbb9a1c: b.eq            #0xbb9a24
    //     0xbb9a20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb9a24: r0 = Null
    //     0xbb9a24: mov             x0, NULL
    // 0xbb9a28: LeaveFrame
    //     0xbb9a28: mov             SP, fp
    //     0xbb9a2c: ldp             fp, lr, [SP], #0x10
    // 0xbb9a30: ret
    //     0xbb9a30: ret             
    // 0xbb9a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9a34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb9a38: b               #0xbb99c4
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1d2b0, size: 0x148
    // 0xc1d2b0: EnterFrame
    //     0xc1d2b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d2b4: mov             fp, SP
    // 0xc1d2b8: AllocStack(0x38)
    //     0xc1d2b8: sub             SP, SP, #0x38
    // 0xc1d2bc: SetupParameters(RenderLeaderLayer this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x20 */, dynamic _ /* r3 => r2, fp-0x28 */)
    //     0xc1d2bc: mov             x0, x1
    //     0xc1d2c0: stur            x1, [fp, #-0x18]
    //     0xc1d2c4: mov             x1, x2
    //     0xc1d2c8: stur            x2, [fp, #-0x20]
    //     0xc1d2cc: mov             x2, x3
    //     0xc1d2d0: stur            x3, [fp, #-0x28]
    // 0xc1d2d4: CheckStackOverflow
    //     0xc1d2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d2d8: cmp             SP, x16
    //     0xc1d2dc: b.ls            #0xc1d3ec
    // 0xc1d2e0: LoadField: r3 = r0->field_2f
    //     0xc1d2e0: ldur            w3, [x0, #0x2f]
    // 0xc1d2e4: DecompressPointer r3
    //     0xc1d2e4: add             x3, x3, HEAP, lsl #32
    // 0xc1d2e8: stur            x3, [fp, #-0x10]
    // 0xc1d2ec: LoadField: r4 = r3->field_b
    //     0xc1d2ec: ldur            w4, [x3, #0xb]
    // 0xc1d2f0: DecompressPointer r4
    //     0xc1d2f0: add             x4, x4, HEAP, lsl #32
    // 0xc1d2f4: stur            x4, [fp, #-0x38]
    // 0xc1d2f8: cmp             w4, NULL
    // 0xc1d2fc: b.ne            #0xc1d340
    // 0xc1d300: LoadField: r4 = r0->field_53
    //     0xc1d300: ldur            w4, [x0, #0x53]
    // 0xc1d304: DecompressPointer r4
    //     0xc1d304: add             x4, x4, HEAP, lsl #32
    // 0xc1d308: stur            x4, [fp, #-8]
    // 0xc1d30c: r0 = LeaderLayer()
    //     0xc1d30c: bl              #0xc1d564  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0xc1d310: mov             x2, x0
    // 0xc1d314: ldur            x0, [fp, #-8]
    // 0xc1d318: stur            x2, [fp, #-0x30]
    // 0xc1d31c: StoreField: r2->field_47 = r0
    //     0xc1d31c: stur            w0, [x2, #0x47]
    // 0xc1d320: ldur            x3, [fp, #-0x28]
    // 0xc1d324: StoreField: r2->field_4b = r3
    //     0xc1d324: stur            w3, [x2, #0x4b]
    // 0xc1d328: mov             x1, x2
    // 0xc1d32c: r0 = Layer()
    //     0xc1d32c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1d330: ldur            x1, [fp, #-0x10]
    // 0xc1d334: ldur            x2, [fp, #-0x30]
    // 0xc1d338: r0 = layer=()
    //     0xc1d338: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1d33c: b               #0xc1d39c
    // 0xc1d340: mov             x5, x0
    // 0xc1d344: mov             x3, x2
    // 0xc1d348: mov             x0, x4
    // 0xc1d34c: r2 = Null
    //     0xc1d34c: mov             x2, NULL
    // 0xc1d350: r1 = Null
    //     0xc1d350: mov             x1, NULL
    // 0xc1d354: r4 = LoadClassIdInstr(r0)
    //     0xc1d354: ldur            x4, [x0, #-1]
    //     0xc1d358: ubfx            x4, x4, #0xc, #0x14
    // 0xc1d35c: r17 = 4652
    //     0xc1d35c: mov             x17, #0x122c
    // 0xc1d360: cmp             x4, x17
    // 0xc1d364: b.eq            #0xc1d37c
    // 0xc1d368: r8 = LeaderLayer
    //     0xc1d368: add             x8, PP, #0xae, lsl #12  ; [pp+0xae140] Type: LeaderLayer
    //     0xc1d36c: ldr             x8, [x8, #0x140]
    // 0xc1d370: r3 = Null
    //     0xc1d370: add             x3, PP, #0xae, lsl #12  ; [pp+0xae148] Null
    //     0xc1d374: ldr             x3, [x3, #0x148]
    // 0xc1d378: r0 = DefaultTypeTest()
    //     0xc1d378: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc1d37c: ldur            x0, [fp, #-0x18]
    // 0xc1d380: LoadField: r2 = r0->field_53
    //     0xc1d380: ldur            w2, [x0, #0x53]
    // 0xc1d384: DecompressPointer r2
    //     0xc1d384: add             x2, x2, HEAP, lsl #32
    // 0xc1d388: ldur            x1, [fp, #-0x38]
    // 0xc1d38c: r0 = link=()
    //     0xc1d38c: bl              #0xc1d480  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::link=
    // 0xc1d390: ldur            x1, [fp, #-0x38]
    // 0xc1d394: ldur            x2, [fp, #-0x28]
    // 0xc1d398: r0 = offset=()
    //     0xc1d398: bl              #0xc1d3f8  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::offset=
    // 0xc1d39c: ldur            x0, [fp, #-0x10]
    // 0xc1d3a0: LoadField: r3 = r0->field_b
    //     0xc1d3a0: ldur            w3, [x0, #0xb]
    // 0xc1d3a4: DecompressPointer r3
    //     0xc1d3a4: add             x3, x3, HEAP, lsl #32
    // 0xc1d3a8: stur            x3, [fp, #-8]
    // 0xc1d3ac: cmp             w3, NULL
    // 0xc1d3b0: b.eq            #0xc1d3f4
    // 0xc1d3b4: ldur            x2, [fp, #-0x18]
    // 0xc1d3b8: r1 = Function 'paint':.
    //     0xc1d3b8: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1d3bc: ldr             x1, [x1, #0x4e0]
    // 0xc1d3c0: r0 = AllocateClosure()
    //     0xc1d3c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1d3c4: ldur            x1, [fp, #-0x20]
    // 0xc1d3c8: ldur            x2, [fp, #-8]
    // 0xc1d3cc: mov             x3, x0
    // 0xc1d3d0: r5 = Instance_Offset
    //     0xc1d3d0: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1d3d4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc1d3d4: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc1d3d8: r0 = pushLayer()
    //     0xc1d3d8: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1d3dc: r0 = Null
    //     0xc1d3dc: mov             x0, NULL
    // 0xc1d3e0: LeaveFrame
    //     0xc1d3e0: mov             SP, fp
    //     0xc1d3e4: ldp             fp, lr, [SP], #0x10
    // 0xc1d3e8: ret
    //     0xc1d3e8: ret             
    // 0xc1d3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d3ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d3f0: b               #0xc1d2e0
    // 0xc1d3f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1d3f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ link=(/* No info */) {
    // ** addr: 0xcf70e4, size: 0xb0
    // 0xcf70e4: EnterFrame
    //     0xcf70e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf70e8: mov             fp, SP
    // 0xcf70ec: mov             x16, x2
    // 0xcf70f0: mov             x2, x1
    // 0xcf70f4: mov             x1, x16
    // 0xcf70f8: CheckStackOverflow
    //     0xcf70f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf70fc: cmp             SP, x16
    //     0xcf7100: b.ls            #0xcf718c
    // 0xcf7104: LoadField: r0 = r2->field_53
    //     0xcf7104: ldur            w0, [x2, #0x53]
    // 0xcf7108: DecompressPointer r0
    //     0xcf7108: add             x0, x0, HEAP, lsl #32
    // 0xcf710c: cmp             w0, w1
    // 0xcf7110: b.ne            #0xcf7124
    // 0xcf7114: r0 = Null
    //     0xcf7114: mov             x0, NULL
    // 0xcf7118: LeaveFrame
    //     0xcf7118: mov             SP, fp
    //     0xcf711c: ldp             fp, lr, [SP], #0x10
    // 0xcf7120: ret
    //     0xcf7120: ret             
    // 0xcf7124: StoreField: r0->field_b = rNULL
    //     0xcf7124: stur            NULL, [x0, #0xb]
    // 0xcf7128: mov             x0, x1
    // 0xcf712c: StoreField: r2->field_53 = r0
    //     0xcf712c: stur            w0, [x2, #0x53]
    //     0xcf7130: ldurb           w16, [x2, #-1]
    //     0xcf7134: ldurb           w17, [x0, #-1]
    //     0xcf7138: and             x16, x17, x16, lsr #2
    //     0xcf713c: tst             x16, HEAP, lsr #32
    //     0xcf7140: b.eq            #0xcf7148
    //     0xcf7144: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf7148: LoadField: r0 = r2->field_57
    //     0xcf7148: ldur            w0, [x2, #0x57]
    // 0xcf714c: DecompressPointer r0
    //     0xcf714c: add             x0, x0, HEAP, lsl #32
    // 0xcf7150: cmp             w0, NULL
    // 0xcf7154: b.eq            #0xcf7174
    // 0xcf7158: StoreField: r1->field_b = r0
    //     0xcf7158: stur            w0, [x1, #0xb]
    //     0xcf715c: ldurb           w16, [x1, #-1]
    //     0xcf7160: ldurb           w17, [x0, #-1]
    //     0xcf7164: and             x16, x17, x16, lsr #2
    //     0xcf7168: tst             x16, HEAP, lsr #32
    //     0xcf716c: b.eq            #0xcf7174
    //     0xcf7170: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7174: mov             x1, x2
    // 0xcf7178: r0 = markNeedsPaint()
    //     0xcf7178: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf717c: r0 = Null
    //     0xcf717c: mov             x0, NULL
    // 0xcf7180: LeaveFrame
    //     0xcf7180: mov             SP, fp
    //     0xcf7184: ldp             fp, lr, [SP], #0x10
    // 0xcf7188: ret
    //     0xcf7188: ret             
    // 0xcf718c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf718c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7190: b               #0xcf7104
  }
}

// class id: 4917, size: 0x5c, field offset: 0x54
class RenderIndexedSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf61e8, size: 0x60
    // 0xbf61e8: r3 = true
    //     0xbf61e8: add             x3, NULL, #0x20  ; true
    // 0xbf61ec: LoadField: r4 = r1->field_53
    //     0xbf61ec: ldur            x4, [x1, #0x53]
    // 0xbf61f0: r0 = BoxInt64Instr(r4)
    //     0xbf61f0: sbfiz           x0, x4, #1, #0x1f
    //     0xbf61f4: cmp             x4, x0, asr #1
    //     0xbf61f8: b.eq            #0xbf6214
    //     0xbf61fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6200: mov             fp, SP
    //     0xbf6204: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf6208: mov             SP, fp
    //     0xbf620c: ldp             fp, lr, [SP], #0x10
    //     0xbf6210: stur            x4, [x0, #7]
    // 0xbf6214: StoreField: r2->field_37 = r0
    //     0xbf6214: stur            w0, [x2, #0x37]
    //     0xbf6218: tbz             w0, #0, #0xbf623c
    //     0xbf621c: ldurb           w16, [x2, #-1]
    //     0xbf6220: ldurb           w17, [x0, #-1]
    //     0xbf6224: and             x16, x17, x16, lsr #2
    //     0xbf6228: tst             x16, HEAP, lsr #32
    //     0xbf622c: b.eq            #0xbf623c
    //     0xbf6230: str             lr, [SP, #-8]!
    //     0xbf6234: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    //     0xbf6238: ldr             lr, [SP], #8
    // 0xbf623c: StoreField: r2->field_1f = r3
    //     0xbf623c: stur            w3, [x2, #0x1f]
    // 0xbf6240: r0 = Null
    //     0xbf6240: mov             x0, NULL
    // 0xbf6244: ret
    //     0xbf6244: ret             
  }
  set _ index=(/* No info */) {
    // ** addr: 0xcf9af8, size: 0x50
    // 0xcf9af8: EnterFrame
    //     0xcf9af8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9afc: mov             fp, SP
    // 0xcf9b00: CheckStackOverflow
    //     0xcf9b00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9b04: cmp             SP, x16
    //     0xcf9b08: b.ls            #0xcf9b40
    // 0xcf9b0c: LoadField: r0 = r1->field_53
    //     0xcf9b0c: ldur            x0, [x1, #0x53]
    // 0xcf9b10: cmp             x2, x0
    // 0xcf9b14: b.ne            #0xcf9b28
    // 0xcf9b18: r0 = Null
    //     0xcf9b18: mov             x0, NULL
    // 0xcf9b1c: LeaveFrame
    //     0xcf9b1c: mov             SP, fp
    //     0xcf9b20: ldp             fp, lr, [SP], #0x10
    // 0xcf9b24: ret
    //     0xcf9b24: ret             
    // 0xcf9b28: StoreField: r1->field_53 = r2
    //     0xcf9b28: stur            x2, [x1, #0x53]
    // 0xcf9b2c: r0 = markNeedsSemanticsUpdate()
    //     0xcf9b2c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf9b30: r0 = Null
    //     0xcf9b30: mov             x0, NULL
    // 0xcf9b34: LeaveFrame
    //     0xcf9b34: mov             SP, fp
    //     0xcf9b38: ldp             fp, lr, [SP], #0x10
    // 0xcf9b3c: ret
    //     0xcf9b3c: ret             
    // 0xcf9b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9b40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9b44: b               #0xcf9b0c
  }
  _ RenderIndexedSemantics(/* No info */) {
    // ** addr: 0x11d2a6c, size: 0x70
    // 0x11d2a6c: EnterFrame
    //     0x11d2a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2a70: mov             fp, SP
    // 0x11d2a74: AllocStack(0x8)
    //     0x11d2a74: sub             SP, SP, #8
    // 0x11d2a78: SetupParameters(RenderIndexedSemantics this /* r1 => r1, fp-0x8 */)
    //     0x11d2a78: stur            x1, [fp, #-8]
    // 0x11d2a7c: CheckStackOverflow
    //     0x11d2a7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2a80: cmp             SP, x16
    //     0x11d2a84: b.ls            #0x11d2ad4
    // 0x11d2a88: StoreField: r1->field_53 = r2
    //     0x11d2a88: stur            x2, [x1, #0x53]
    // 0x11d2a8c: r0 = _LayoutCacheStorage()
    //     0x11d2a8c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d2a90: ldur            x2, [fp, #-8]
    // 0x11d2a94: StoreField: r2->field_47 = r0
    //     0x11d2a94: stur            w0, [x2, #0x47]
    //     0x11d2a98: ldurb           w16, [x2, #-1]
    //     0x11d2a9c: ldurb           w17, [x0, #-1]
    //     0x11d2aa0: and             x16, x17, x16, lsr #2
    //     0x11d2aa4: tst             x16, HEAP, lsr #32
    //     0x11d2aa8: b.eq            #0x11d2ab0
    //     0x11d2aac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d2ab0: mov             x1, x2
    // 0x11d2ab4: r0 = RenderObject()
    //     0x11d2ab4: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d2ab8: ldur            x1, [fp, #-8]
    // 0x11d2abc: r2 = Null
    //     0x11d2abc: mov             x2, NULL
    // 0x11d2ac0: r0 = child=()
    //     0x11d2ac0: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d2ac4: r0 = Null
    //     0x11d2ac4: mov             x0, NULL
    // 0x11d2ac8: LeaveFrame
    //     0x11d2ac8: mov             SP, fp
    //     0x11d2acc: ldp             fp, lr, [SP], #0x10
    // 0x11d2ad0: ret
    //     0x11d2ad0: ret             
    // 0x11d2ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2ad8: b               #0x11d2a88
  }
}

// class id: 4918, size: 0x58, field offset: 0x54
class RenderExcludeSemantics extends RenderProxyBox {

  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbeb9f4, size: 0x4c
    // 0xbeb9f4: EnterFrame
    //     0xbeb9f4: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb9f8: mov             fp, SP
    // 0xbeb9fc: CheckStackOverflow
    //     0xbeb9fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeba00: cmp             SP, x16
    //     0xbeba04: b.ls            #0xbeba38
    // 0xbeba08: LoadField: r0 = r1->field_53
    //     0xbeba08: ldur            w0, [x1, #0x53]
    // 0xbeba0c: DecompressPointer r0
    //     0xbeba0c: add             x0, x0, HEAP, lsl #32
    // 0xbeba10: tbnz            w0, #4, #0xbeba24
    // 0xbeba14: r0 = Null
    //     0xbeba14: mov             x0, NULL
    // 0xbeba18: LeaveFrame
    //     0xbeba18: mov             SP, fp
    //     0xbeba1c: ldp             fp, lr, [SP], #0x10
    // 0xbeba20: ret
    //     0xbeba20: ret             
    // 0xbeba24: r0 = visitChildren()
    //     0xbeba24: bl              #0xbee950  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::visitChildren
    // 0xbeba28: r0 = Null
    //     0xbeba28: mov             x0, NULL
    // 0xbeba2c: LeaveFrame
    //     0xbeba2c: mov             SP, fp
    //     0xbeba30: ldp             fp, lr, [SP], #0x10
    // 0xbeba34: ret
    //     0xbeba34: ret             
    // 0xbeba38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeba38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeba3c: b               #0xbeba08
  }
}

// class id: 4919, size: 0x54, field offset: 0x54
class RenderMergeSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf618c, size: 0x48
    // 0xbf618c: EnterFrame
    //     0xbf618c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6190: mov             fp, SP
    // 0xbf6194: r0 = true
    //     0xbf6194: add             x0, NULL, #0x20  ; true
    // 0xbf6198: mov             x16, x2
    // 0xbf619c: mov             x2, x1
    // 0xbf61a0: mov             x1, x16
    // 0xbf61a4: CheckStackOverflow
    //     0xbf61a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf61a8: cmp             SP, x16
    //     0xbf61ac: b.ls            #0xbf61cc
    // 0xbf61b0: StoreField: r1->field_7 = r0
    //     0xbf61b0: stur            w0, [x1, #7]
    // 0xbf61b4: mov             x2, x0
    // 0xbf61b8: r0 = isMergingSemanticsOfDescendants=()
    //     0xbf61b8: bl              #0xbf61d4  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isMergingSemanticsOfDescendants=
    // 0xbf61bc: r0 = Null
    //     0xbf61bc: mov             x0, NULL
    // 0xbf61c0: LeaveFrame
    //     0xbf61c0: mov             SP, fp
    //     0xbf61c4: ldp             fp, lr, [SP], #0x10
    // 0xbf61c8: ret
    //     0xbf61c8: ret             
    // 0xbf61cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf61cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf61d0: b               #0xbf61b0
  }
}

// class id: 4920, size: 0x58, field offset: 0x54
class RenderBlockSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf617c, size: 0x10
    // 0xbf617c: r3 = true
    //     0xbf617c: add             x3, NULL, #0x20  ; true
    // 0xbf6180: StoreField: r2->field_1b = r3
    //     0xbf6180: stur            w3, [x2, #0x1b]
    // 0xbf6184: r0 = Null
    //     0xbf6184: mov             x0, NULL
    // 0xbf6188: ret
    //     0xbf6188: ret             
  }
}

// class id: 4921, size: 0x5c, field offset: 0x54
class RenderAbsorbPointer extends RenderProxyBox {

  set _ absorbing=(/* No info */) {
    // ** addr: 0x8c8fdc, size: 0x54
    // 0x8c8fdc: EnterFrame
    //     0x8c8fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c8fe0: mov             fp, SP
    // 0x8c8fe4: CheckStackOverflow
    //     0x8c8fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8fe8: cmp             SP, x16
    //     0x8c8fec: b.ls            #0x8c9028
    // 0x8c8ff0: LoadField: r0 = r1->field_53
    //     0x8c8ff0: ldur            w0, [x1, #0x53]
    // 0x8c8ff4: DecompressPointer r0
    //     0x8c8ff4: add             x0, x0, HEAP, lsl #32
    // 0x8c8ff8: cmp             w0, w2
    // 0x8c8ffc: b.ne            #0x8c9010
    // 0x8c9000: r0 = Null
    //     0x8c9000: mov             x0, NULL
    // 0x8c9004: LeaveFrame
    //     0x8c9004: mov             SP, fp
    //     0x8c9008: ldp             fp, lr, [SP], #0x10
    // 0x8c900c: ret
    //     0x8c900c: ret             
    // 0x8c9010: StoreField: r1->field_53 = r2
    //     0x8c9010: stur            w2, [x1, #0x53]
    // 0x8c9014: r0 = markNeedsSemanticsUpdate()
    //     0x8c9014: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x8c9018: r0 = Null
    //     0x8c9018: mov             x0, NULL
    // 0x8c901c: LeaveFrame
    //     0x8c901c: mov             SP, fp
    //     0x8c9020: ldp             fp, lr, [SP], #0x10
    // 0x8c9024: ret
    //     0x8c9024: ret             
    // 0x8c9028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c9028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c902c: b               #0x8c8ff0
  }
  _ hitTest(/* No info */) {
    // ** addr: 0xaf93c0, size: 0x64
    // 0xaf93c0: EnterFrame
    //     0xaf93c0: stp             fp, lr, [SP, #-0x10]!
    //     0xaf93c4: mov             fp, SP
    // 0xaf93c8: AllocStack(0x8)
    //     0xaf93c8: sub             SP, SP, #8
    // 0xaf93cc: SetupParameters(dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x8 */)
    //     0xaf93cc: mov             x0, x2
    //     0xaf93d0: mov             x2, x3
    //     0xaf93d4: stur            x3, [fp, #-8]
    // 0xaf93d8: CheckStackOverflow
    //     0xaf93d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf93dc: cmp             SP, x16
    //     0xaf93e0: b.ls            #0xaf941c
    // 0xaf93e4: LoadField: r3 = r1->field_53
    //     0xaf93e4: ldur            w3, [x1, #0x53]
    // 0xaf93e8: DecompressPointer r3
    //     0xaf93e8: add             x3, x3, HEAP, lsl #32
    // 0xaf93ec: tbnz            w3, #4, #0xaf9404
    // 0xaf93f0: r0 = size()
    //     0xaf93f0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xaf93f4: mov             x1, x0
    // 0xaf93f8: ldur            x2, [fp, #-8]
    // 0xaf93fc: r0 = contains()
    //     0xaf93fc: bl              #0x81d498  ; [dart:ui] Size::contains
    // 0xaf9400: b               #0xaf9410
    // 0xaf9404: mov             x2, x0
    // 0xaf9408: ldur            x3, [fp, #-8]
    // 0xaf940c: r0 = hitTest()
    //     0xaf940c: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf9410: LeaveFrame
    //     0xaf9410: mov             SP, fp
    //     0xaf9414: ldp             fp, lr, [SP], #0x10
    // 0xaf9418: ret
    //     0xaf9418: ret             
    // 0xaf941c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf941c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9420: b               #0xaf93e4
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbeb9c4, size: 0x30
    // 0xbeb9c4: EnterFrame
    //     0xbeb9c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb9c8: mov             fp, SP
    // 0xbeb9cc: CheckStackOverflow
    //     0xbeb9cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb9d0: cmp             SP, x16
    //     0xbeb9d4: b.ls            #0xbeb9ec
    // 0xbeb9d8: r0 = visitChildren()
    //     0xbeb9d8: bl              #0xbee950  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::visitChildren
    // 0xbeb9dc: r0 = Null
    //     0xbeb9dc: mov             x0, NULL
    // 0xbeb9e0: LeaveFrame
    //     0xbeb9e0: mov             SP, fp
    //     0xbeb9e4: ldp             fp, lr, [SP], #0x10
    // 0xbeb9e8: ret
    //     0xbeb9e8: ret             
    // 0xbeb9ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb9ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb9f0: b               #0xbeb9d8
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf6158, size: 0x24
    // 0xbf6158: LoadField: r3 = r1->field_53
    //     0xbf6158: ldur            w3, [x1, #0x53]
    // 0xbf615c: DecompressPointer r3
    //     0xbf615c: add             x3, x3, HEAP, lsl #32
    // 0xbf6160: tbnz            w3, #4, #0xbf616c
    // 0xbf6164: r1 = true
    //     0xbf6164: add             x1, NULL, #0x20  ; true
    // 0xbf6168: b               #0xbf6170
    // 0xbf616c: r1 = false
    //     0xbf616c: add             x1, NULL, #0x30  ; false
    // 0xbf6170: StoreField: r2->field_13 = r1
    //     0xbf6170: stur            w1, [x2, #0x13]
    // 0xbf6174: r0 = Null
    //     0xbf6174: mov             x0, NULL
    // 0xbf6178: ret
    //     0xbf6178: ret             
  }
  _ RenderAbsorbPointer(/* No info */) {
    // ** addr: 0x11d1c80, size: 0x70
    // 0x11d1c80: EnterFrame
    //     0x11d1c80: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1c84: mov             fp, SP
    // 0x11d1c88: AllocStack(0x8)
    //     0x11d1c88: sub             SP, SP, #8
    // 0x11d1c8c: SetupParameters(RenderAbsorbPointer this /* r1 => r1, fp-0x8 */)
    //     0x11d1c8c: stur            x1, [fp, #-8]
    // 0x11d1c90: CheckStackOverflow
    //     0x11d1c90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1c94: cmp             SP, x16
    //     0x11d1c98: b.ls            #0x11d1ce8
    // 0x11d1c9c: StoreField: r1->field_53 = r2
    //     0x11d1c9c: stur            w2, [x1, #0x53]
    // 0x11d1ca0: r0 = _LayoutCacheStorage()
    //     0x11d1ca0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1ca4: ldur            x2, [fp, #-8]
    // 0x11d1ca8: StoreField: r2->field_47 = r0
    //     0x11d1ca8: stur            w0, [x2, #0x47]
    //     0x11d1cac: ldurb           w16, [x2, #-1]
    //     0x11d1cb0: ldurb           w17, [x0, #-1]
    //     0x11d1cb4: and             x16, x17, x16, lsr #2
    //     0x11d1cb8: tst             x16, HEAP, lsr #32
    //     0x11d1cbc: b.eq            #0x11d1cc4
    //     0x11d1cc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d1cc4: mov             x1, x2
    // 0x11d1cc8: r0 = RenderObject()
    //     0x11d1cc8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1ccc: ldur            x1, [fp, #-8]
    // 0x11d1cd0: r2 = Null
    //     0x11d1cd0: mov             x2, NULL
    // 0x11d1cd4: r0 = child=()
    //     0x11d1cd4: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1cd8: r0 = Null
    //     0x11d1cd8: mov             x0, NULL
    // 0x11d1cdc: LeaveFrame
    //     0x11d1cdc: mov             SP, fp
    //     0x11d1ce0: ldp             fp, lr, [SP], #0x10
    // 0x11d1ce4: ret
    //     0x11d1ce4: ret             
    // 0x11d1ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1ce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1cec: b               #0x11d1c9c
  }
}

// class id: 4922, size: 0x58, field offset: 0x54
class RenderOffstage extends RenderProxyBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf9380, size: 0x40
    // 0xaf9380: EnterFrame
    //     0xaf9380: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9384: mov             fp, SP
    // 0xaf9388: CheckStackOverflow
    //     0xaf9388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf938c: cmp             SP, x16
    //     0xaf9390: b.ls            #0xaf93b8
    // 0xaf9394: LoadField: r0 = r1->field_53
    //     0xaf9394: ldur            w0, [x1, #0x53]
    // 0xaf9398: DecompressPointer r0
    //     0xaf9398: add             x0, x0, HEAP, lsl #32
    // 0xaf939c: tbz             w0, #4, #0xaf93a8
    // 0xaf93a0: r0 = hitTest()
    //     0xaf93a0: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf93a4: b               #0xaf93ac
    // 0xaf93a8: r0 = false
    //     0xaf93a8: add             x0, NULL, #0x30  ; false
    // 0xaf93ac: LeaveFrame
    //     0xaf93ac: mov             SP, fp
    //     0xaf93b0: ldp             fp, lr, [SP], #0x10
    // 0xaf93b4: ret
    //     0xaf93b4: ret             
    // 0xaf93b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf93b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf93bc: b               #0xaf9394
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16a1c, size: 0x24
    // 0xb16a1c: EnterFrame
    //     0xb16a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16a20: mov             fp, SP
    // 0xb16a24: ldr             x2, [fp, #0x10]
    // 0xb16a28: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16a28: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43b0] AnonymousClosure: (0xb16a40), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicWidth (0xb16ab8)
    //     0xb16a2c: ldr             x1, [x1, #0x3b0]
    // 0xb16a30: r0 = AllocateClosure()
    //     0xb16a30: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16a34: LeaveFrame
    //     0xb16a34: mov             SP, fp
    //     0xb16a38: ldp             fp, lr, [SP], #0x10
    // 0xb16a3c: ret
    //     0xb16a3c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16a40, size: 0x78
    // 0xb16a40: EnterFrame
    //     0xb16a40: stp             fp, lr, [SP, #-0x10]!
    //     0xb16a44: mov             fp, SP
    // 0xb16a48: ldr             x0, [fp, #0x18]
    // 0xb16a4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16a4c: ldur            w1, [x0, #0x17]
    // 0xb16a50: DecompressPointer r1
    //     0xb16a50: add             x1, x1, HEAP, lsl #32
    // 0xb16a54: CheckStackOverflow
    //     0xb16a54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16a58: cmp             SP, x16
    //     0xb16a5c: b.ls            #0xb16aa0
    // 0xb16a60: ldr             x2, [fp, #0x10]
    // 0xb16a64: r0 = computeMinIntrinsicWidth()
    //     0xb16a64: bl              #0xb16ab8  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicWidth
    // 0xb16a68: r0 = inline_Allocate_Double()
    //     0xb16a68: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16a6c: add             x0, x0, #0x10
    //     0xb16a70: cmp             x1, x0
    //     0xb16a74: b.ls            #0xb16aa8
    //     0xb16a78: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16a7c: sub             x0, x0, #0xf
    //     0xb16a80: mov             x1, #0xe19c
    //     0xb16a84: movk            x1, #3, lsl #16
    //     0xb16a88: stur            x1, [x0, #-1]
    // 0xb16a8c: dmb             ishst
    // 0xb16a90: StoreField: r0->field_7 = d0
    //     0xb16a90: stur            d0, [x0, #7]
    // 0xb16a94: LeaveFrame
    //     0xb16a94: mov             SP, fp
    //     0xb16a98: ldp             fp, lr, [SP], #0x10
    // 0xb16a9c: ret
    //     0xb16a9c: ret             
    // 0xb16aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16aa0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16aa4: b               #0xb16a60
    // 0xb16aa8: SaveReg d0
    //     0xb16aa8: str             q0, [SP, #-0x10]!
    // 0xb16aac: r0 = AllocateDouble()
    //     0xb16aac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16ab0: RestoreReg d0
    //     0xb16ab0: ldr             q0, [SP], #0x10
    // 0xb16ab4: b               #0xb16a90
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16ab8, size: 0x48
    // 0xb16ab8: EnterFrame
    //     0xb16ab8: stp             fp, lr, [SP, #-0x10]!
    //     0xb16abc: mov             fp, SP
    // 0xb16ac0: CheckStackOverflow
    //     0xb16ac0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16ac4: cmp             SP, x16
    //     0xb16ac8: b.ls            #0xb16af8
    // 0xb16acc: LoadField: r0 = r1->field_53
    //     0xb16acc: ldur            w0, [x1, #0x53]
    // 0xb16ad0: DecompressPointer r0
    //     0xb16ad0: add             x0, x0, HEAP, lsl #32
    // 0xb16ad4: tbnz            w0, #4, #0xb16ae8
    // 0xb16ad8: d0 = 0.000000
    //     0xb16ad8: eor             v0.16b, v0.16b, v0.16b
    // 0xb16adc: LeaveFrame
    //     0xb16adc: mov             SP, fp
    //     0xb16ae0: ldp             fp, lr, [SP], #0x10
    // 0xb16ae4: ret
    //     0xb16ae4: ret             
    // 0xb16ae8: r0 = computeMinIntrinsicWidth()
    //     0xb16ae8: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb16aec: LeaveFrame
    //     0xb16aec: mov             SP, fp
    //     0xb16af0: ldp             fp, lr, [SP], #0x10
    // 0xb16af4: ret
    //     0xb16af4: ret             
    // 0xb16af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16af8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16afc: b               #0xb16acc
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb22e68, size: 0x48
    // 0xb22e68: EnterFrame
    //     0xb22e68: stp             fp, lr, [SP, #-0x10]!
    //     0xb22e6c: mov             fp, SP
    // 0xb22e70: CheckStackOverflow
    //     0xb22e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22e74: cmp             SP, x16
    //     0xb22e78: b.ls            #0xb22ea8
    // 0xb22e7c: LoadField: r0 = r1->field_53
    //     0xb22e7c: ldur            w0, [x1, #0x53]
    // 0xb22e80: DecompressPointer r0
    //     0xb22e80: add             x0, x0, HEAP, lsl #32
    // 0xb22e84: tbnz            w0, #4, #0xb22e98
    // 0xb22e88: d0 = 0.000000
    //     0xb22e88: eor             v0.16b, v0.16b, v0.16b
    // 0xb22e8c: LeaveFrame
    //     0xb22e8c: mov             SP, fp
    //     0xb22e90: ldp             fp, lr, [SP], #0x10
    // 0xb22e94: ret
    //     0xb22e94: ret             
    // 0xb22e98: r0 = computeMinIntrinsicHeight()
    //     0xb22e98: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb22e9c: LeaveFrame
    //     0xb22e9c: mov             SP, fp
    //     0xb22ea0: ldp             fp, lr, [SP], #0x10
    // 0xb22ea4: ret
    //     0xb22ea4: ret             
    // 0xb22ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22eac: b               #0xb22e7c
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb22eb0, size: 0x78
    // 0xb22eb0: EnterFrame
    //     0xb22eb0: stp             fp, lr, [SP, #-0x10]!
    //     0xb22eb4: mov             fp, SP
    // 0xb22eb8: ldr             x0, [fp, #0x18]
    // 0xb22ebc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb22ebc: ldur            w1, [x0, #0x17]
    // 0xb22ec0: DecompressPointer r1
    //     0xb22ec0: add             x1, x1, HEAP, lsl #32
    // 0xb22ec4: CheckStackOverflow
    //     0xb22ec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22ec8: cmp             SP, x16
    //     0xb22ecc: b.ls            #0xb22f10
    // 0xb22ed0: ldr             x2, [fp, #0x10]
    // 0xb22ed4: r0 = computeMinIntrinsicHeight()
    //     0xb22ed4: bl              #0xb22e68  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicHeight
    // 0xb22ed8: r0 = inline_Allocate_Double()
    //     0xb22ed8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22edc: add             x0, x0, #0x10
    //     0xb22ee0: cmp             x1, x0
    //     0xb22ee4: b.ls            #0xb22f18
    //     0xb22ee8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22eec: sub             x0, x0, #0xf
    //     0xb22ef0: mov             x1, #0xe19c
    //     0xb22ef4: movk            x1, #3, lsl #16
    //     0xb22ef8: stur            x1, [x0, #-1]
    // 0xb22efc: dmb             ishst
    // 0xb22f00: StoreField: r0->field_7 = d0
    //     0xb22f00: stur            d0, [x0, #7]
    // 0xb22f04: LeaveFrame
    //     0xb22f04: mov             SP, fp
    //     0xb22f08: ldp             fp, lr, [SP], #0x10
    // 0xb22f0c: ret
    //     0xb22f0c: ret             
    // 0xb22f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22f10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22f14: b               #0xb22ed0
    // 0xb22f18: SaveReg d0
    //     0xb22f18: str             q0, [SP, #-0x10]!
    // 0xb22f1c: r0 = AllocateDouble()
    //     0xb22f1c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22f20: RestoreReg d0
    //     0xb22f20: ldr             q0, [SP], #0x10
    // 0xb22f24: b               #0xb22f00
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29a78, size: 0x48
    // 0xb29a78: EnterFrame
    //     0xb29a78: stp             fp, lr, [SP, #-0x10]!
    //     0xb29a7c: mov             fp, SP
    // 0xb29a80: CheckStackOverflow
    //     0xb29a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29a84: cmp             SP, x16
    //     0xb29a88: b.ls            #0xb29ab8
    // 0xb29a8c: LoadField: r0 = r1->field_53
    //     0xb29a8c: ldur            w0, [x1, #0x53]
    // 0xb29a90: DecompressPointer r0
    //     0xb29a90: add             x0, x0, HEAP, lsl #32
    // 0xb29a94: tbnz            w0, #4, #0xb29aa8
    // 0xb29a98: d0 = 0.000000
    //     0xb29a98: eor             v0.16b, v0.16b, v0.16b
    // 0xb29a9c: LeaveFrame
    //     0xb29a9c: mov             SP, fp
    //     0xb29aa0: ldp             fp, lr, [SP], #0x10
    // 0xb29aa4: ret
    //     0xb29aa4: ret             
    // 0xb29aa8: r0 = computeMaxIntrinsicHeight()
    //     0xb29aa8: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb29aac: LeaveFrame
    //     0xb29aac: mov             SP, fp
    //     0xb29ab0: ldp             fp, lr, [SP], #0x10
    // 0xb29ab4: ret
    //     0xb29ab4: ret             
    // 0xb29ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29abc: b               #0xb29a8c
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29ac0, size: 0x78
    // 0xb29ac0: EnterFrame
    //     0xb29ac0: stp             fp, lr, [SP, #-0x10]!
    //     0xb29ac4: mov             fp, SP
    // 0xb29ac8: ldr             x0, [fp, #0x18]
    // 0xb29acc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29acc: ldur            w1, [x0, #0x17]
    // 0xb29ad0: DecompressPointer r1
    //     0xb29ad0: add             x1, x1, HEAP, lsl #32
    // 0xb29ad4: CheckStackOverflow
    //     0xb29ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29ad8: cmp             SP, x16
    //     0xb29adc: b.ls            #0xb29b20
    // 0xb29ae0: ldr             x2, [fp, #0x10]
    // 0xb29ae4: r0 = computeMaxIntrinsicHeight()
    //     0xb29ae4: bl              #0xb29a78  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicHeight
    // 0xb29ae8: r0 = inline_Allocate_Double()
    //     0xb29ae8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29aec: add             x0, x0, #0x10
    //     0xb29af0: cmp             x1, x0
    //     0xb29af4: b.ls            #0xb29b28
    //     0xb29af8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29afc: sub             x0, x0, #0xf
    //     0xb29b00: mov             x1, #0xe19c
    //     0xb29b04: movk            x1, #3, lsl #16
    //     0xb29b08: stur            x1, [x0, #-1]
    // 0xb29b0c: dmb             ishst
    // 0xb29b10: StoreField: r0->field_7 = d0
    //     0xb29b10: stur            d0, [x0, #7]
    // 0xb29b14: LeaveFrame
    //     0xb29b14: mov             SP, fp
    //     0xb29b18: ldp             fp, lr, [SP], #0x10
    // 0xb29b1c: ret
    //     0xb29b1c: ret             
    // 0xb29b20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29b20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29b24: b               #0xb29ae0
    // 0xb29b28: SaveReg d0
    //     0xb29b28: str             q0, [SP, #-0x10]!
    // 0xb29b2c: r0 = AllocateDouble()
    //     0xb29b2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29b30: RestoreReg d0
    //     0xb29b30: ldr             q0, [SP], #0x10
    // 0xb29b34: b               #0xb29b10
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2cea4, size: 0x48
    // 0xb2cea4: EnterFrame
    //     0xb2cea4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cea8: mov             fp, SP
    // 0xb2ceac: CheckStackOverflow
    //     0xb2ceac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ceb0: cmp             SP, x16
    //     0xb2ceb4: b.ls            #0xb2cee4
    // 0xb2ceb8: LoadField: r0 = r1->field_53
    //     0xb2ceb8: ldur            w0, [x1, #0x53]
    // 0xb2cebc: DecompressPointer r0
    //     0xb2cebc: add             x0, x0, HEAP, lsl #32
    // 0xb2cec0: tbnz            w0, #4, #0xb2ced4
    // 0xb2cec4: d0 = 0.000000
    //     0xb2cec4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2cec8: LeaveFrame
    //     0xb2cec8: mov             SP, fp
    //     0xb2cecc: ldp             fp, lr, [SP], #0x10
    // 0xb2ced0: ret
    //     0xb2ced0: ret             
    // 0xb2ced4: r0 = computeMaxIntrinsicWidth()
    //     0xb2ced4: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2ced8: LeaveFrame
    //     0xb2ced8: mov             SP, fp
    //     0xb2cedc: ldp             fp, lr, [SP], #0x10
    // 0xb2cee0: ret
    //     0xb2cee0: ret             
    // 0xb2cee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2cee4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2cee8: b               #0xb2ceb8
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2ceec, size: 0x78
    // 0xb2ceec: EnterFrame
    //     0xb2ceec: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cef0: mov             fp, SP
    // 0xb2cef4: ldr             x0, [fp, #0x18]
    // 0xb2cef8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2cef8: ldur            w1, [x0, #0x17]
    // 0xb2cefc: DecompressPointer r1
    //     0xb2cefc: add             x1, x1, HEAP, lsl #32
    // 0xb2cf00: CheckStackOverflow
    //     0xb2cf00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cf04: cmp             SP, x16
    //     0xb2cf08: b.ls            #0xb2cf4c
    // 0xb2cf0c: ldr             x2, [fp, #0x10]
    // 0xb2cf10: r0 = computeMaxIntrinsicWidth()
    //     0xb2cf10: bl              #0xb2cea4  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicWidth
    // 0xb2cf14: r0 = inline_Allocate_Double()
    //     0xb2cf14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2cf18: add             x0, x0, #0x10
    //     0xb2cf1c: cmp             x1, x0
    //     0xb2cf20: b.ls            #0xb2cf54
    //     0xb2cf24: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2cf28: sub             x0, x0, #0xf
    //     0xb2cf2c: mov             x1, #0xe19c
    //     0xb2cf30: movk            x1, #3, lsl #16
    //     0xb2cf34: stur            x1, [x0, #-1]
    // 0xb2cf38: dmb             ishst
    // 0xb2cf3c: StoreField: r0->field_7 = d0
    //     0xb2cf3c: stur            d0, [x0, #7]
    // 0xb2cf40: LeaveFrame
    //     0xb2cf40: mov             SP, fp
    //     0xb2cf44: ldp             fp, lr, [SP], #0x10
    // 0xb2cf48: ret
    //     0xb2cf48: ret             
    // 0xb2cf4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2cf4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2cf50: b               #0xb2cf0c
    // 0xb2cf54: SaveReg d0
    //     0xb2cf54: str             q0, [SP, #-0x10]!
    // 0xb2cf58: r0 = AllocateDouble()
    //     0xb2cf58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2cf5c: RestoreReg d0
    //     0xb2cf5c: ldr             q0, [SP], #0x10
    // 0xb2cf60: b               #0xb2cf3c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4ae7c, size: 0x58
    // 0xb4ae7c: EnterFrame
    //     0xb4ae7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ae80: mov             fp, SP
    // 0xb4ae84: mov             x0, x1
    // 0xb4ae88: mov             x1, x2
    // 0xb4ae8c: CheckStackOverflow
    //     0xb4ae8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ae90: cmp             SP, x16
    //     0xb4ae94: b.ls            #0xb4aecc
    // 0xb4ae98: LoadField: r2 = r0->field_53
    //     0xb4ae98: ldur            w2, [x0, #0x53]
    // 0xb4ae9c: DecompressPointer r2
    //     0xb4ae9c: add             x2, x2, HEAP, lsl #32
    // 0xb4aea0: tbnz            w2, #4, #0xb4aeb4
    // 0xb4aea4: r0 = smallest()
    //     0xb4aea4: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4aea8: LeaveFrame
    //     0xb4aea8: mov             SP, fp
    //     0xb4aeac: ldp             fp, lr, [SP], #0x10
    // 0xb4aeb0: ret
    //     0xb4aeb0: ret             
    // 0xb4aeb4: mov             x2, x1
    // 0xb4aeb8: mov             x1, x0
    // 0xb4aebc: r0 = computeDryLayout()
    //     0xb4aebc: bl              #0xb4ce18  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeDryLayout
    // 0xb4aec0: LeaveFrame
    //     0xb4aec0: mov             SP, fp
    //     0xb4aec4: ldp             fp, lr, [SP], #0x10
    // 0xb4aec8: ret
    //     0xb4aec8: ret             
    // 0xb4aecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4aecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4aed0: b               #0xb4ae98
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58130, size: 0x24
    // 0xb58130: EnterFrame
    //     0xb58130: stp             fp, lr, [SP, #-0x10]!
    //     0xb58134: mov             fp, SP
    // 0xb58138: ldr             x2, [fp, #0x10]
    // 0xb5813c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb5813c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43a8] AnonymousClosure: (0xb2ceec), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicWidth (0xb2cea4)
    //     0xb58140: ldr             x1, [x1, #0x3a8]
    // 0xb58144: r0 = AllocateClosure()
    //     0xb58144: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58148: LeaveFrame
    //     0xb58148: mov             SP, fp
    //     0xb5814c: ldp             fp, lr, [SP], #0x10
    // 0xb58150: ret
    //     0xb58150: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5a5f0, size: 0x48
    // 0xb5a5f0: EnterFrame
    //     0xb5a5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5a5f4: mov             fp, SP
    // 0xb5a5f8: CheckStackOverflow
    //     0xb5a5f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5a5fc: cmp             SP, x16
    //     0xb5a600: b.ls            #0xb5a630
    // 0xb5a604: LoadField: r0 = r1->field_53
    //     0xb5a604: ldur            w0, [x1, #0x53]
    // 0xb5a608: DecompressPointer r0
    //     0xb5a608: add             x0, x0, HEAP, lsl #32
    // 0xb5a60c: tbnz            w0, #4, #0xb5a620
    // 0xb5a610: r0 = Null
    //     0xb5a610: mov             x0, NULL
    // 0xb5a614: LeaveFrame
    //     0xb5a614: mov             SP, fp
    //     0xb5a618: ldp             fp, lr, [SP], #0x10
    // 0xb5a61c: ret
    //     0xb5a61c: ret             
    // 0xb5a620: r0 = computeDistanceToActualBaseline()
    //     0xb5a620: bl              #0xb5a670  ; [package:flutter_widget_from_html_core/src/widgets/html_layout_builder.dart] _RenderLayoutBuilder::computeDistanceToActualBaseline
    // 0xb5a624: LeaveFrame
    //     0xb5a624: mov             SP, fp
    //     0xb5a628: ldp             fp, lr, [SP], #0x10
    // 0xb5a62c: ret
    //     0xb5a62c: ret             
    // 0xb5a630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5a630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5a634: b               #0xb5a604
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e2f0, size: 0x24
    // 0xb5e2f0: EnterFrame
    //     0xb5e2f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e2f4: mov             fp, SP
    // 0xb5e2f8: ldr             x2, [fp, #0x10]
    // 0xb5e2fc: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e2fc: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a5b8] AnonymousClosure: (0xb29ac0), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicHeight (0xb29a78)
    //     0xb5e300: ldr             x1, [x1, #0x5b8]
    // 0xb5e304: r0 = AllocateClosure()
    //     0xb5e304: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e308: LeaveFrame
    //     0xb5e308: mov             SP, fp
    //     0xb5e30c: ldp             fp, lr, [SP], #0x10
    // 0xb5e310: ret
    //     0xb5e310: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f9fc, size: 0x9c
    // 0xb5f9fc: EnterFrame
    //     0xb5f9fc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5fa00: mov             fp, SP
    // 0xb5fa04: AllocStack(0x18)
    //     0xb5fa04: sub             SP, SP, #0x18
    // 0xb5fa08: SetupParameters(RenderOffstage this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5fa08: mov             x5, x1
    //     0xb5fa0c: mov             x4, x2
    //     0xb5fa10: stur            x1, [fp, #-8]
    //     0xb5fa14: stur            x2, [fp, #-0x10]
    //     0xb5fa18: stur            x3, [fp, #-0x18]
    // 0xb5fa1c: CheckStackOverflow
    //     0xb5fa1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5fa20: cmp             SP, x16
    //     0xb5fa24: b.ls            #0xb5fa90
    // 0xb5fa28: mov             x0, x4
    // 0xb5fa2c: r2 = Null
    //     0xb5fa2c: mov             x2, NULL
    // 0xb5fa30: r1 = Null
    //     0xb5fa30: mov             x1, NULL
    // 0xb5fa34: r4 = 60
    //     0xb5fa34: mov             x4, #0x3c
    // 0xb5fa38: branchIfSmi(r0, 0xb5fa44)
    //     0xb5fa38: tbz             w0, #0, #0xb5fa44
    // 0xb5fa3c: r4 = LoadClassIdInstr(r0)
    //     0xb5fa3c: ldur            x4, [x0, #-1]
    //     0xb5fa40: ubfx            x4, x4, #0xc, #0x14
    // 0xb5fa44: sub             x4, x4, #0xb46
    // 0xb5fa48: cmp             x4, #1
    // 0xb5fa4c: b.ls            #0xb5fa60
    // 0xb5fa50: r8 = BoxConstraints
    //     0xb5fa50: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5fa54: r3 = Null
    //     0xb5fa54: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a5d0] Null
    //     0xb5fa58: ldr             x3, [x3, #0x5d0]
    // 0xb5fa5c: r0 = BoxConstraints()
    //     0xb5fa5c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5fa60: ldur            x1, [fp, #-8]
    // 0xb5fa64: LoadField: r0 = r1->field_53
    //     0xb5fa64: ldur            w0, [x1, #0x53]
    // 0xb5fa68: DecompressPointer r0
    //     0xb5fa68: add             x0, x0, HEAP, lsl #32
    // 0xb5fa6c: tbnz            w0, #4, #0xb5fa78
    // 0xb5fa70: r0 = Null
    //     0xb5fa70: mov             x0, NULL
    // 0xb5fa74: b               #0xb5fa84
    // 0xb5fa78: ldur            x2, [fp, #-0x10]
    // 0xb5fa7c: ldur            x3, [fp, #-0x18]
    // 0xb5fa80: r0 = computeDryBaseline()
    //     0xb5fa80: bl              #0xb5fa98  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeDryBaseline
    // 0xb5fa84: LeaveFrame
    //     0xb5fa84: mov             SP, fp
    //     0xb5fa88: ldp             fp, lr, [SP], #0x10
    // 0xb5fa8c: ret
    //     0xb5fa8c: ret             
    // 0xb5fa90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5fa90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5fa94: b               #0xb5fa28
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb98c8, size: 0xdc
    // 0xbb98c8: EnterFrame
    //     0xbb98c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbb98cc: mov             fp, SP
    // 0xbb98d0: AllocStack(0x10)
    //     0xbb98d0: sub             SP, SP, #0x10
    // 0xbb98d4: CheckStackOverflow
    //     0xbb98d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb98d8: cmp             SP, x16
    //     0xbb98dc: b.ls            #0xbb999c
    // 0xbb98e0: LoadField: r0 = r1->field_53
    //     0xbb98e0: ldur            w0, [x1, #0x53]
    // 0xbb98e4: DecompressPointer r0
    //     0xbb98e4: add             x0, x0, HEAP, lsl #32
    // 0xbb98e8: tbnz            w0, #4, #0xbb996c
    // 0xbb98ec: LoadField: r3 = r1->field_4f
    //     0xbb98ec: ldur            w3, [x1, #0x4f]
    // 0xbb98f0: DecompressPointer r3
    //     0xbb98f0: add             x3, x3, HEAP, lsl #32
    // 0xbb98f4: stur            x3, [fp, #-0x10]
    // 0xbb98f8: cmp             w3, NULL
    // 0xbb98fc: b.eq            #0xbb9970
    // 0xbb9900: LoadField: r4 = r1->field_27
    //     0xbb9900: ldur            w4, [x1, #0x27]
    // 0xbb9904: DecompressPointer r4
    //     0xbb9904: add             x4, x4, HEAP, lsl #32
    // 0xbb9908: stur            x4, [fp, #-8]
    // 0xbb990c: cmp             w4, NULL
    // 0xbb9910: b.eq            #0xbb9980
    // 0xbb9914: mov             x0, x4
    // 0xbb9918: r2 = Null
    //     0xbb9918: mov             x2, NULL
    // 0xbb991c: r1 = Null
    //     0xbb991c: mov             x1, NULL
    // 0xbb9920: r4 = LoadClassIdInstr(r0)
    //     0xbb9920: ldur            x4, [x0, #-1]
    //     0xbb9924: ubfx            x4, x4, #0xc, #0x14
    // 0xbb9928: sub             x4, x4, #0xb46
    // 0xbb992c: cmp             x4, #1
    // 0xbb9930: b.ls            #0xbb9944
    // 0xbb9934: r8 = BoxConstraints
    //     0xbb9934: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb9938: r3 = Null
    //     0xbb9938: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a5c0] Null
    //     0xbb993c: ldr             x3, [x3, #0x5c0]
    // 0xbb9940: r0 = BoxConstraints()
    //     0xbb9940: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb9944: ldur            x1, [fp, #-0x10]
    // 0xbb9948: r0 = LoadClassIdInstr(r1)
    //     0xbb9948: ldur            x0, [x1, #-1]
    //     0xbb994c: ubfx            x0, x0, #0xc, #0x14
    // 0xbb9950: ldur            x2, [fp, #-8]
    // 0xbb9954: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbb9954: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbb9958: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb9958: mov             x17, #0xe6b9
    //     0xbb995c: add             lr, x0, x17
    //     0xbb9960: ldr             lr, [x21, lr, lsl #3]
    //     0xbb9964: blr             lr
    // 0xbb9968: b               #0xbb9970
    // 0xbb996c: r0 = performLayout()
    //     0xbb996c: bl              #0xbba2a4  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0xbb9970: r0 = Null
    //     0xbb9970: mov             x0, NULL
    // 0xbb9974: LeaveFrame
    //     0xbb9974: mov             SP, fp
    //     0xbb9978: ldp             fp, lr, [SP], #0x10
    // 0xbb997c: ret
    //     0xbb997c: ret             
    // 0xbb9980: r0 = StateError()
    //     0xbb9980: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9984: mov             x1, x0
    // 0xbb9988: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9988: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb998c: StoreField: r1->field_b = r0
    //     0xbb998c: stur            w0, [x1, #0xb]
    // 0xbb9990: mov             x0, x1
    // 0xbb9994: r0 = Throw()
    //     0xbb9994: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9998: brk             #0
    // 0xbb999c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb999c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb99a0: b               #0xbb98e0
  }
  get _ sizedByParent(/* No info */) {
    // ** addr: 0xbeb7a4, size: 0xc
    // 0xbeb7a4: LoadField: r0 = r1->field_53
    //     0xbeb7a4: ldur            w0, [x1, #0x53]
    // 0xbeb7a8: DecompressPointer r0
    //     0xbeb7a8: add             x0, x0, HEAP, lsl #32
    // 0xbeb7ac: ret
    //     0xbeb7ac: ret             
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0xbf2ca0, size: 0x70
    // 0xbf2ca0: EnterFrame
    //     0xbf2ca0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2ca4: mov             fp, SP
    // 0xbf2ca8: AllocStack(0x8)
    //     0xbf2ca8: sub             SP, SP, #8
    // 0xbf2cac: SetupParameters(RenderOffstage this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xbf2cac: mov             x0, x2
    //     0xbf2cb0: mov             x4, x1
    //     0xbf2cb4: mov             x3, x2
    //     0xbf2cb8: stur            x1, [fp, #-8]
    // 0xbf2cbc: r2 = Null
    //     0xbf2cbc: mov             x2, NULL
    // 0xbf2cc0: r1 = Null
    //     0xbf2cc0: mov             x1, NULL
    // 0xbf2cc4: r4 = 60
    //     0xbf2cc4: mov             x4, #0x3c
    // 0xbf2cc8: branchIfSmi(r0, 0xbf2cd4)
    //     0xbf2cc8: tbz             w0, #0, #0xbf2cd4
    // 0xbf2ccc: r4 = LoadClassIdInstr(r0)
    //     0xbf2ccc: ldur            x4, [x0, #-1]
    //     0xbf2cd0: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2cd4: r17 = -4710
    //     0xbf2cd4: mov             x17, #-0x1266
    // 0xbf2cd8: add             x4, x4, x17
    // 0xbf2cdc: cmp             x4, #0x109
    // 0xbf2ce0: b.ls            #0xbf2cf4
    // 0xbf2ce4: r8 = RenderBox
    //     0xbf2ce4: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2ce8: r3 = Null
    //     0xbf2ce8: add             x3, PP, #0xae, lsl #12  ; [pp+0xae118] Null
    //     0xbf2cec: ldr             x3, [x3, #0x118]
    // 0xbf2cf0: r0 = RenderBox()
    //     0xbf2cf0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf2cf4: ldur            x1, [fp, #-8]
    // 0xbf2cf8: LoadField: r2 = r1->field_53
    //     0xbf2cf8: ldur            w2, [x1, #0x53]
    // 0xbf2cfc: DecompressPointer r2
    //     0xbf2cfc: add             x2, x2, HEAP, lsl #32
    // 0xbf2d00: eor             x0, x2, #0x10
    // 0xbf2d04: LeaveFrame
    //     0xbf2d04: mov             SP, fp
    //     0xbf2d08: ldp             fp, lr, [SP], #0x10
    // 0xbf2d0c: ret
    //     0xbf2d0c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1d264, size: 0x4c
    // 0xc1d264: EnterFrame
    //     0xc1d264: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d268: mov             fp, SP
    // 0xc1d26c: CheckStackOverflow
    //     0xc1d26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d270: cmp             SP, x16
    //     0xc1d274: b.ls            #0xc1d2a8
    // 0xc1d278: LoadField: r0 = r1->field_53
    //     0xc1d278: ldur            w0, [x1, #0x53]
    // 0xc1d27c: DecompressPointer r0
    //     0xc1d27c: add             x0, x0, HEAP, lsl #32
    // 0xc1d280: tbnz            w0, #4, #0xc1d294
    // 0xc1d284: r0 = Null
    //     0xc1d284: mov             x0, NULL
    // 0xc1d288: LeaveFrame
    //     0xc1d288: mov             SP, fp
    //     0xc1d28c: ldp             fp, lr, [SP], #0x10
    // 0xc1d290: ret
    //     0xc1d290: ret             
    // 0xc1d294: r0 = paint()
    //     0xc1d294: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1d298: r0 = Null
    //     0xc1d298: mov             x0, NULL
    // 0xc1d29c: LeaveFrame
    //     0xc1d29c: mov             SP, fp
    //     0xc1d2a0: ldp             fp, lr, [SP], #0x10
    // 0xc1d2a4: ret
    //     0xc1d2a4: ret             
    // 0xc1d2a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d2a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d2ac: b               #0xc1d278
  }
  _ performResize(/* No info */) {
    // ** addr: 0xcceff8, size: 0x30
    // 0xcceff8: EnterFrame
    //     0xcceff8: stp             fp, lr, [SP, #-0x10]!
    //     0xcceffc: mov             fp, SP
    // 0xccf000: CheckStackOverflow
    //     0xccf000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf004: cmp             SP, x16
    //     0xccf008: b.ls            #0xccf020
    // 0xccf00c: r0 = performResize()
    //     0xccf00c: bl              #0xccfb6c  ; [package:flutter/src/rendering/box.dart] RenderBox::performResize
    // 0xccf010: r0 = Null
    //     0xccf010: mov             x0, NULL
    // 0xccf014: LeaveFrame
    //     0xccf014: mov             SP, fp
    //     0xccf018: ldp             fp, lr, [SP], #0x10
    // 0xccf01c: ret
    //     0xccf01c: ret             
    // 0xccf020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf024: b               #0xccf00c
  }
  set _ offstage=(/* No info */) {
    // ** addr: 0xcf8940, size: 0x54
    // 0xcf8940: EnterFrame
    //     0xcf8940: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8944: mov             fp, SP
    // 0xcf8948: CheckStackOverflow
    //     0xcf8948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf894c: cmp             SP, x16
    //     0xcf8950: b.ls            #0xcf898c
    // 0xcf8954: LoadField: r0 = r1->field_53
    //     0xcf8954: ldur            w0, [x1, #0x53]
    // 0xcf8958: DecompressPointer r0
    //     0xcf8958: add             x0, x0, HEAP, lsl #32
    // 0xcf895c: cmp             w2, w0
    // 0xcf8960: b.ne            #0xcf8974
    // 0xcf8964: r0 = Null
    //     0xcf8964: mov             x0, NULL
    // 0xcf8968: LeaveFrame
    //     0xcf8968: mov             SP, fp
    //     0xcf896c: ldp             fp, lr, [SP], #0x10
    // 0xcf8970: ret
    //     0xcf8970: ret             
    // 0xcf8974: StoreField: r1->field_53 = r2
    //     0xcf8974: stur            w2, [x1, #0x53]
    // 0xcf8978: r0 = markNeedsLayoutForSizedByParentChange()
    //     0xcf8978: bl              #0xcf8994  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayoutForSizedByParentChange
    // 0xcf897c: r0 = Null
    //     0xcf897c: mov             x0, NULL
    // 0xcf8980: LeaveFrame
    //     0xcf8980: mov             SP, fp
    //     0xcf8984: ldp             fp, lr, [SP], #0x10
    // 0xcf8988: ret
    //     0xcf8988: ret             
    // 0xcf898c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf898c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8990: b               #0xcf8954
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efad8, size: 0x24
    // 0x10efad8: EnterFrame
    //     0x10efad8: stp             fp, lr, [SP, #-0x10]!
    //     0x10efadc: mov             fp, SP
    // 0x10efae0: ldr             x2, [fp, #0x10]
    // 0x10efae4: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efae4: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43a0] AnonymousClosure: (0xb22eb0), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicHeight (0xb22e68)
    //     0x10efae8: ldr             x1, [x1, #0x3a0]
    // 0x10efaec: r0 = AllocateClosure()
    //     0x10efaec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efaf0: LeaveFrame
    //     0x10efaf0: mov             SP, fp
    //     0x10efaf4: ldp             fp, lr, [SP], #0x10
    // 0x10efaf8: ret
    //     0x10efaf8: ret             
  }
}

// class id: 4923, size: 0x5c, field offset: 0x54
class RenderIgnorePointer extends RenderProxyBox {

  set _ ignoring=(/* No info */) {
    // ** addr: 0x86fb34, size: 0x54
    // 0x86fb34: EnterFrame
    //     0x86fb34: stp             fp, lr, [SP, #-0x10]!
    //     0x86fb38: mov             fp, SP
    // 0x86fb3c: CheckStackOverflow
    //     0x86fb3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86fb40: cmp             SP, x16
    //     0x86fb44: b.ls            #0x86fb80
    // 0x86fb48: LoadField: r0 = r1->field_53
    //     0x86fb48: ldur            w0, [x1, #0x53]
    // 0x86fb4c: DecompressPointer r0
    //     0x86fb4c: add             x0, x0, HEAP, lsl #32
    // 0x86fb50: cmp             w2, w0
    // 0x86fb54: b.ne            #0x86fb68
    // 0x86fb58: r0 = Null
    //     0x86fb58: mov             x0, NULL
    // 0x86fb5c: LeaveFrame
    //     0x86fb5c: mov             SP, fp
    //     0x86fb60: ldp             fp, lr, [SP], #0x10
    // 0x86fb64: ret
    //     0x86fb64: ret             
    // 0x86fb68: StoreField: r1->field_53 = r2
    //     0x86fb68: stur            w2, [x1, #0x53]
    // 0x86fb6c: r0 = markNeedsSemanticsUpdate()
    //     0x86fb6c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x86fb70: r0 = Null
    //     0x86fb70: mov             x0, NULL
    // 0x86fb74: LeaveFrame
    //     0x86fb74: mov             SP, fp
    //     0x86fb78: ldp             fp, lr, [SP], #0x10
    // 0x86fb7c: ret
    //     0x86fb7c: ret             
    // 0x86fb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86fb80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86fb84: b               #0x86fb48
  }
}

// class id: 4924, size: 0x54, field offset: 0x54
class RenderRepaintBoundary extends RenderProxyBox {
}

// class id: 4925, size: 0x5c, field offset: 0x54
class RenderFractionalTranslation extends RenderProxyBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf9354, size: 0x2c
    // 0xaf9354: EnterFrame
    //     0xaf9354: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9358: mov             fp, SP
    // 0xaf935c: CheckStackOverflow
    //     0xaf935c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9360: cmp             SP, x16
    //     0xaf9364: b.ls            #0xaf9378
    // 0xaf9368: r0 = hitTestChildren()
    //     0xaf9368: bl              #0x10e974c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFractionalTranslation::hitTestChildren
    // 0xaf936c: LeaveFrame
    //     0xaf936c: mov             SP, fp
    //     0xaf9370: ldp             fp, lr, [SP], #0x10
    // 0xaf9374: ret
    //     0xaf9374: ret             
    // 0xaf9378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf937c: b               #0xaf9368
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1230, size: 0xd8
    // 0xbf1230: EnterFrame
    //     0xbf1230: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1234: mov             fp, SP
    // 0xbf1238: AllocStack(0x20)
    //     0xbf1238: sub             SP, SP, #0x20
    // 0xbf123c: SetupParameters(RenderFractionalTranslation this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf123c: mov             x4, x1
    //     0xbf1240: mov             x0, x2
    //     0xbf1244: stur            x1, [fp, #-8]
    //     0xbf1248: stur            x3, [fp, #-0x10]
    // 0xbf124c: CheckStackOverflow
    //     0xbf124c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1250: cmp             SP, x16
    //     0xbf1254: b.ls            #0xbf1300
    // 0xbf1258: r2 = Null
    //     0xbf1258: mov             x2, NULL
    // 0xbf125c: r1 = Null
    //     0xbf125c: mov             x1, NULL
    // 0xbf1260: r4 = 60
    //     0xbf1260: mov             x4, #0x3c
    // 0xbf1264: branchIfSmi(r0, 0xbf1270)
    //     0xbf1264: tbz             w0, #0, #0xbf1270
    // 0xbf1268: r4 = LoadClassIdInstr(r0)
    //     0xbf1268: ldur            x4, [x0, #-1]
    //     0xbf126c: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1270: r17 = -4710
    //     0xbf1270: mov             x17, #-0x1266
    // 0xbf1274: add             x4, x4, x17
    // 0xbf1278: cmp             x4, #0x109
    // 0xbf127c: b.ls            #0xbf1290
    // 0xbf1280: r8 = RenderBox
    //     0xbf1280: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf1284: r3 = Null
    //     0xbf1284: add             x3, PP, #0xae, lsl #12  ; [pp+0xae220] Null
    //     0xbf1288: ldr             x3, [x3, #0x220]
    // 0xbf128c: r0 = RenderBox()
    //     0xbf128c: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf1290: ldur            x0, [fp, #-8]
    // 0xbf1294: LoadField: r1 = r0->field_53
    //     0xbf1294: ldur            w1, [x0, #0x53]
    // 0xbf1298: DecompressPointer r1
    //     0xbf1298: add             x1, x1, HEAP, lsl #32
    // 0xbf129c: LoadField: d0 = r1->field_7
    //     0xbf129c: ldur            d0, [x1, #7]
    // 0xbf12a0: mov             x1, x0
    // 0xbf12a4: stur            d0, [fp, #-0x18]
    // 0xbf12a8: r0 = size()
    //     0xbf12a8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf12ac: LoadField: d0 = r0->field_7
    //     0xbf12ac: ldur            d0, [x0, #7]
    // 0xbf12b0: ldur            d1, [fp, #-0x18]
    // 0xbf12b4: fmul            d2, d1, d0
    // 0xbf12b8: ldur            x1, [fp, #-8]
    // 0xbf12bc: stur            d2, [fp, #-0x20]
    // 0xbf12c0: LoadField: r0 = r1->field_53
    //     0xbf12c0: ldur            w0, [x1, #0x53]
    // 0xbf12c4: DecompressPointer r0
    //     0xbf12c4: add             x0, x0, HEAP, lsl #32
    // 0xbf12c8: LoadField: d0 = r0->field_f
    //     0xbf12c8: ldur            d0, [x0, #0xf]
    // 0xbf12cc: stur            d0, [fp, #-0x18]
    // 0xbf12d0: r0 = size()
    //     0xbf12d0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf12d4: LoadField: d0 = r0->field_f
    //     0xbf12d4: ldur            d0, [x0, #0xf]
    // 0xbf12d8: ldur            d1, [fp, #-0x18]
    // 0xbf12dc: fmul            d2, d1, d0
    // 0xbf12e0: ldur            x1, [fp, #-0x10]
    // 0xbf12e4: ldur            d0, [fp, #-0x20]
    // 0xbf12e8: mov             v1.16b, v2.16b
    // 0xbf12ec: r0 = translateByDouble()
    //     0xbf12ec: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf12f0: r0 = Null
    //     0xbf12f0: mov             x0, NULL
    // 0xbf12f4: LeaveFrame
    //     0xbf12f4: mov             SP, fp
    //     0xbf12f8: ldp             fp, lr, [SP], #0x10
    // 0xbf12fc: ret
    //     0xbf12fc: ret             
    // 0xbf1300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1304: b               #0xbf1258
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1d178, size: 0xec
    // 0xc1d178: EnterFrame
    //     0xc1d178: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d17c: mov             fp, SP
    // 0xc1d180: AllocStack(0x30)
    //     0xc1d180: sub             SP, SP, #0x30
    // 0xc1d184: SetupParameters(RenderFractionalTranslation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1d184: mov             x0, x1
    //     0xc1d188: stur            x1, [fp, #-8]
    //     0xc1d18c: stur            x2, [fp, #-0x10]
    //     0xc1d190: stur            x3, [fp, #-0x18]
    // 0xc1d194: CheckStackOverflow
    //     0xc1d194: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d198: cmp             SP, x16
    //     0xc1d19c: b.ls            #0xc1d25c
    // 0xc1d1a0: LoadField: r1 = r0->field_4f
    //     0xc1d1a0: ldur            w1, [x0, #0x4f]
    // 0xc1d1a4: DecompressPointer r1
    //     0xc1d1a4: add             x1, x1, HEAP, lsl #32
    // 0xc1d1a8: cmp             w1, NULL
    // 0xc1d1ac: b.eq            #0xc1d24c
    // 0xc1d1b0: LoadField: d0 = r3->field_7
    //     0xc1d1b0: ldur            d0, [x3, #7]
    // 0xc1d1b4: stur            d0, [fp, #-0x28]
    // 0xc1d1b8: LoadField: r1 = r0->field_53
    //     0xc1d1b8: ldur            w1, [x0, #0x53]
    // 0xc1d1bc: DecompressPointer r1
    //     0xc1d1bc: add             x1, x1, HEAP, lsl #32
    // 0xc1d1c0: LoadField: d1 = r1->field_7
    //     0xc1d1c0: ldur            d1, [x1, #7]
    // 0xc1d1c4: mov             x1, x0
    // 0xc1d1c8: stur            d1, [fp, #-0x20]
    // 0xc1d1cc: r0 = size()
    //     0xc1d1cc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1d1d0: LoadField: d0 = r0->field_7
    //     0xc1d1d0: ldur            d0, [x0, #7]
    // 0xc1d1d4: ldur            d1, [fp, #-0x20]
    // 0xc1d1d8: fmul            d2, d1, d0
    // 0xc1d1dc: ldur            d0, [fp, #-0x28]
    // 0xc1d1e0: fadd            d1, d0, d2
    // 0xc1d1e4: ldur            x0, [fp, #-0x18]
    // 0xc1d1e8: stur            d1, [fp, #-0x30]
    // 0xc1d1ec: LoadField: d0 = r0->field_f
    //     0xc1d1ec: ldur            d0, [x0, #0xf]
    // 0xc1d1f0: ldur            x0, [fp, #-8]
    // 0xc1d1f4: stur            d0, [fp, #-0x28]
    // 0xc1d1f8: LoadField: r1 = r0->field_53
    //     0xc1d1f8: ldur            w1, [x0, #0x53]
    // 0xc1d1fc: DecompressPointer r1
    //     0xc1d1fc: add             x1, x1, HEAP, lsl #32
    // 0xc1d200: LoadField: d2 = r1->field_f
    //     0xc1d200: ldur            d2, [x1, #0xf]
    // 0xc1d204: mov             x1, x0
    // 0xc1d208: stur            d2, [fp, #-0x20]
    // 0xc1d20c: r0 = size()
    //     0xc1d20c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1d210: LoadField: d0 = r0->field_f
    //     0xc1d210: ldur            d0, [x0, #0xf]
    // 0xc1d214: ldur            d1, [fp, #-0x20]
    // 0xc1d218: fmul            d2, d1, d0
    // 0xc1d21c: ldur            d0, [fp, #-0x28]
    // 0xc1d220: fadd            d1, d0, d2
    // 0xc1d224: stur            d1, [fp, #-0x20]
    // 0xc1d228: r0 = Offset()
    //     0xc1d228: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc1d22c: ldur            d0, [fp, #-0x30]
    // 0xc1d230: StoreField: r0->field_7 = d0
    //     0xc1d230: stur            d0, [x0, #7]
    // 0xc1d234: ldur            d0, [fp, #-0x20]
    // 0xc1d238: StoreField: r0->field_f = d0
    //     0xc1d238: stur            d0, [x0, #0xf]
    // 0xc1d23c: ldur            x1, [fp, #-8]
    // 0xc1d240: ldur            x2, [fp, #-0x10]
    // 0xc1d244: mov             x3, x0
    // 0xc1d248: r0 = paint()
    //     0xc1d248: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1d24c: r0 = Null
    //     0xc1d24c: mov             x0, NULL
    // 0xc1d250: LeaveFrame
    //     0xc1d250: mov             SP, fp
    //     0xc1d254: ldp             fp, lr, [SP], #0x10
    // 0xc1d258: ret
    //     0xc1d258: ret             
    // 0xc1d25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d25c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d260: b               #0xc1d1a0
  }
  set _ translation=(/* No info */) {
    // ** addr: 0xcf7880, size: 0x94
    // 0xcf7880: EnterFrame
    //     0xcf7880: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7884: mov             fp, SP
    // 0xcf7888: AllocStack(0x20)
    //     0xcf7888: sub             SP, SP, #0x20
    // 0xcf788c: SetupParameters(RenderFractionalTranslation this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf788c: mov             x0, x2
    //     0xcf7890: stur            x1, [fp, #-8]
    //     0xcf7894: stur            x2, [fp, #-0x10]
    // 0xcf7898: CheckStackOverflow
    //     0xcf7898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf789c: cmp             SP, x16
    //     0xcf78a0: b.ls            #0xcf790c
    // 0xcf78a4: LoadField: r2 = r1->field_53
    //     0xcf78a4: ldur            w2, [x1, #0x53]
    // 0xcf78a8: DecompressPointer r2
    //     0xcf78a8: add             x2, x2, HEAP, lsl #32
    // 0xcf78ac: stp             x0, x2, [SP]
    // 0xcf78b0: r0 = ==()
    //     0xcf78b0: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xcf78b4: tbnz            w0, #4, #0xcf78c8
    // 0xcf78b8: r0 = Null
    //     0xcf78b8: mov             x0, NULL
    // 0xcf78bc: LeaveFrame
    //     0xcf78bc: mov             SP, fp
    //     0xcf78c0: ldp             fp, lr, [SP], #0x10
    // 0xcf78c4: ret
    //     0xcf78c4: ret             
    // 0xcf78c8: ldur            x2, [fp, #-8]
    // 0xcf78cc: ldur            x0, [fp, #-0x10]
    // 0xcf78d0: StoreField: r2->field_53 = r0
    //     0xcf78d0: stur            w0, [x2, #0x53]
    //     0xcf78d4: ldurb           w16, [x2, #-1]
    //     0xcf78d8: ldurb           w17, [x0, #-1]
    //     0xcf78dc: and             x16, x17, x16, lsr #2
    //     0xcf78e0: tst             x16, HEAP, lsr #32
    //     0xcf78e4: b.eq            #0xcf78ec
    //     0xcf78e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf78ec: mov             x1, x2
    // 0xcf78f0: r0 = markNeedsPaint()
    //     0xcf78f0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf78f4: ldur            x1, [fp, #-8]
    // 0xcf78f8: r0 = markNeedsSemanticsUpdate()
    //     0xcf78f8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf78fc: r0 = Null
    //     0xcf78fc: mov             x0, NULL
    // 0xcf7900: LeaveFrame
    //     0xcf7900: mov             SP, fp
    //     0xcf7904: ldp             fp, lr, [SP], #0x10
    // 0xcf7908: ret
    //     0xcf7908: ret             
    // 0xcf790c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf790c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7910: b               #0xcf78a4
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e974c, size: 0x100
    // 0x10e974c: EnterFrame
    //     0x10e974c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e9750: mov             fp, SP
    // 0x10e9754: AllocStack(0x38)
    //     0x10e9754: sub             SP, SP, #0x38
    // 0x10e9758: SetupParameters(RenderFractionalTranslation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x10e9758: mov             x0, x1
    //     0x10e975c: stur            x1, [fp, #-8]
    //     0x10e9760: mov             x1, x2
    //     0x10e9764: mov             x5, x3
    //     0x10e9768: stur            x2, [fp, #-0x10]
    //     0x10e976c: stur            x3, [fp, #-0x18]
    // 0x10e9770: CheckStackOverflow
    //     0x10e9770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e9774: cmp             SP, x16
    //     0x10e9778: b.ls            #0x10e9844
    // 0x10e977c: r1 = 1
    //     0x10e977c: mov             x1, #1
    // 0x10e9780: r0 = AllocateContext()
    //     0x10e9780: bl              #0x13de838  ; AllocateContextStub
    // 0x10e9784: mov             x2, x0
    // 0x10e9788: ldur            x0, [fp, #-8]
    // 0x10e978c: stur            x2, [fp, #-0x20]
    // 0x10e9790: StoreField: r2->field_f = r0
    //     0x10e9790: stur            w0, [x2, #0xf]
    // 0x10e9794: LoadField: r1 = r0->field_57
    //     0x10e9794: ldur            w1, [x0, #0x57]
    // 0x10e9798: DecompressPointer r1
    //     0x10e9798: add             x1, x1, HEAP, lsl #32
    // 0x10e979c: tbnz            w1, #4, #0x10e980c
    // 0x10e97a0: LoadField: r1 = r0->field_53
    //     0x10e97a0: ldur            w1, [x0, #0x53]
    // 0x10e97a4: DecompressPointer r1
    //     0x10e97a4: add             x1, x1, HEAP, lsl #32
    // 0x10e97a8: LoadField: d0 = r1->field_7
    //     0x10e97a8: ldur            d0, [x1, #7]
    // 0x10e97ac: mov             x1, x0
    // 0x10e97b0: stur            d0, [fp, #-0x28]
    // 0x10e97b4: r0 = size()
    //     0x10e97b4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e97b8: LoadField: d0 = r0->field_7
    //     0x10e97b8: ldur            d0, [x0, #7]
    // 0x10e97bc: ldur            d1, [fp, #-0x28]
    // 0x10e97c0: fmul            d2, d1, d0
    // 0x10e97c4: ldur            x1, [fp, #-8]
    // 0x10e97c8: stur            d2, [fp, #-0x30]
    // 0x10e97cc: LoadField: r0 = r1->field_53
    //     0x10e97cc: ldur            w0, [x1, #0x53]
    // 0x10e97d0: DecompressPointer r0
    //     0x10e97d0: add             x0, x0, HEAP, lsl #32
    // 0x10e97d4: LoadField: d0 = r0->field_f
    //     0x10e97d4: ldur            d0, [x0, #0xf]
    // 0x10e97d8: stur            d0, [fp, #-0x28]
    // 0x10e97dc: r0 = size()
    //     0x10e97dc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e97e0: LoadField: d0 = r0->field_f
    //     0x10e97e0: ldur            d0, [x0, #0xf]
    // 0x10e97e4: ldur            d1, [fp, #-0x28]
    // 0x10e97e8: fmul            d2, d1, d0
    // 0x10e97ec: stur            d2, [fp, #-0x38]
    // 0x10e97f0: r0 = Offset()
    //     0x10e97f0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x10e97f4: ldur            d0, [fp, #-0x30]
    // 0x10e97f8: StoreField: r0->field_7 = d0
    //     0x10e97f8: stur            d0, [x0, #7]
    // 0x10e97fc: ldur            d0, [fp, #-0x38]
    // 0x10e9800: StoreField: r0->field_f = d0
    //     0x10e9800: stur            d0, [x0, #0xf]
    // 0x10e9804: mov             x3, x0
    // 0x10e9808: b               #0x10e9810
    // 0x10e980c: r3 = Null
    //     0x10e980c: mov             x3, NULL
    // 0x10e9810: ldur            x2, [fp, #-0x20]
    // 0x10e9814: stur            x3, [fp, #-8]
    // 0x10e9818: r1 = Function '<anonymous closure>':.
    //     0x10e9818: add             x1, PP, #0xae, lsl #12  ; [pp+0xae230] AnonymousClosure: (0x10e95dc), in [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren (0x10e984c)
    //     0x10e981c: ldr             x1, [x1, #0x230]
    // 0x10e9820: r0 = AllocateClosure()
    //     0x10e9820: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e9824: ldur            x1, [fp, #-0x10]
    // 0x10e9828: mov             x2, x0
    // 0x10e982c: ldur            x3, [fp, #-8]
    // 0x10e9830: ldur            x5, [fp, #-0x18]
    // 0x10e9834: r0 = addWithPaintOffset()
    //     0x10e9834: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10e9838: LeaveFrame
    //     0x10e9838: mov             SP, fp
    //     0x10e983c: ldp             fp, lr, [SP], #0x10
    // 0x10e9840: ret
    //     0x10e9840: ret             
    // 0x10e9844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9848: b               #0x10e977c
  }
  _ RenderFractionalTranslation(/* No info */) {
    // ** addr: 0x11d1138, size: 0x90
    // 0x11d1138: EnterFrame
    //     0x11d1138: stp             fp, lr, [SP, #-0x10]!
    //     0x11d113c: mov             fp, SP
    // 0x11d1140: AllocStack(0x8)
    //     0x11d1140: sub             SP, SP, #8
    // 0x11d1144: SetupParameters(RenderFractionalTranslation this /* r1 => r1, fp-0x8 */, dynamic _ /* r3 => r0 */)
    //     0x11d1144: mov             x0, x3
    //     0x11d1148: stur            x1, [fp, #-8]
    // 0x11d114c: CheckStackOverflow
    //     0x11d114c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1150: cmp             SP, x16
    //     0x11d1154: b.ls            #0x11d11c0
    // 0x11d1158: StoreField: r1->field_57 = r2
    //     0x11d1158: stur            w2, [x1, #0x57]
    // 0x11d115c: StoreField: r1->field_53 = r0
    //     0x11d115c: stur            w0, [x1, #0x53]
    //     0x11d1160: ldurb           w16, [x1, #-1]
    //     0x11d1164: ldurb           w17, [x0, #-1]
    //     0x11d1168: and             x16, x17, x16, lsr #2
    //     0x11d116c: tst             x16, HEAP, lsr #32
    //     0x11d1170: b.eq            #0x11d1178
    //     0x11d1174: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d1178: r0 = _LayoutCacheStorage()
    //     0x11d1178: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d117c: ldur            x2, [fp, #-8]
    // 0x11d1180: StoreField: r2->field_47 = r0
    //     0x11d1180: stur            w0, [x2, #0x47]
    //     0x11d1184: ldurb           w16, [x2, #-1]
    //     0x11d1188: ldurb           w17, [x0, #-1]
    //     0x11d118c: and             x16, x17, x16, lsr #2
    //     0x11d1190: tst             x16, HEAP, lsr #32
    //     0x11d1194: b.eq            #0x11d119c
    //     0x11d1198: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d119c: mov             x1, x2
    // 0x11d11a0: r0 = RenderObject()
    //     0x11d11a0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d11a4: ldur            x1, [fp, #-8]
    // 0x11d11a8: r2 = Null
    //     0x11d11a8: mov             x2, NULL
    // 0x11d11ac: r0 = child=()
    //     0x11d11ac: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d11b0: r0 = Null
    //     0x11d11b0: mov             x0, NULL
    // 0x11d11b4: LeaveFrame
    //     0x11d11b4: mov             SP, fp
    //     0x11d11b8: ldp             fp, lr, [SP], #0x10
    // 0x11d11bc: ret
    //     0x11d11bc: ret             
    // 0x11d11c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d11c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d11c4: b               #0x11d1158
  }
}

// class id: 4926, size: 0x70, field offset: 0x54
class RenderFittedBox extends RenderProxyBox {

  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4ad70, size: 0xc8
    // 0xb4ad70: EnterFrame
    //     0xb4ad70: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ad74: mov             fp, SP
    // 0xb4ad78: AllocStack(0x18)
    //     0xb4ad78: sub             SP, SP, #0x18
    // 0xb4ad7c: SetupParameters(RenderFittedBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4ad7c: mov             x3, x1
    //     0xb4ad80: mov             x0, x2
    //     0xb4ad84: stur            x1, [fp, #-8]
    //     0xb4ad88: stur            x2, [fp, #-0x10]
    // 0xb4ad8c: CheckStackOverflow
    //     0xb4ad8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ad90: cmp             SP, x16
    //     0xb4ad94: b.ls            #0xb4ae30
    // 0xb4ad98: LoadField: r1 = r3->field_4f
    //     0xb4ad98: ldur            w1, [x3, #0x4f]
    // 0xb4ad9c: DecompressPointer r1
    //     0xb4ad9c: add             x1, x1, HEAP, lsl #32
    // 0xb4ada0: cmp             w1, NULL
    // 0xb4ada4: b.eq            #0xb4ae1c
    // 0xb4ada8: r2 = Instance_BoxConstraints
    //     0xb4ada8: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xb4adac: ldr             x2, [x2, #0xf0]
    // 0xb4adb0: r0 = getDryLayout()
    //     0xb4adb0: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4adb4: mov             x2, x0
    // 0xb4adb8: ldur            x0, [fp, #-8]
    // 0xb4adbc: stur            x2, [fp, #-0x18]
    // 0xb4adc0: LoadField: r1 = r0->field_57
    //     0xb4adc0: ldur            w1, [x0, #0x57]
    // 0xb4adc4: DecompressPointer r1
    //     0xb4adc4: add             x1, x1, HEAP, lsl #32
    // 0xb4adc8: LoadField: r0 = r1->field_7
    //     0xb4adc8: ldur            x0, [x1, #7]
    // 0xb4adcc: cmp             x0, #3
    // 0xb4add0: b.le            #0xb4addc
    // 0xb4add4: cmp             x0, #5
    // 0xb4add8: b.gt            #0xb4adf0
    // 0xb4addc: ldur            x1, [fp, #-0x10]
    // 0xb4ade0: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xb4ade0: bl              #0xb212f8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xb4ade4: LeaveFrame
    //     0xb4ade4: mov             SP, fp
    //     0xb4ade8: ldp             fp, lr, [SP], #0x10
    // 0xb4adec: ret
    //     0xb4adec: ret             
    // 0xb4adf0: ldur            x1, [fp, #-0x10]
    // 0xb4adf4: r0 = loosen()
    //     0xb4adf4: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb4adf8: mov             x1, x0
    // 0xb4adfc: ldur            x2, [fp, #-0x18]
    // 0xb4ae00: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xb4ae00: bl              #0xb212f8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xb4ae04: ldur            x1, [fp, #-0x10]
    // 0xb4ae08: mov             x2, x0
    // 0xb4ae0c: r0 = constrain()
    //     0xb4ae0c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4ae10: LeaveFrame
    //     0xb4ae10: mov             SP, fp
    //     0xb4ae14: ldp             fp, lr, [SP], #0x10
    // 0xb4ae18: ret
    //     0xb4ae18: ret             
    // 0xb4ae1c: ldur            x1, [fp, #-0x10]
    // 0xb4ae20: r0 = smallest()
    //     0xb4ae20: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4ae24: LeaveFrame
    //     0xb4ae24: mov             SP, fp
    //     0xb4ae28: ldp             fp, lr, [SP], #0x10
    // 0xb4ae2c: ret
    //     0xb4ae2c: ret             
    // 0xb4ae30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4ae30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4ae34: b               #0xb4ad98
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f960, size: 0x9c
    // 0xb5f960: EnterFrame
    //     0xb5f960: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f964: mov             fp, SP
    // 0xb5f968: AllocStack(0x10)
    //     0xb5f968: sub             SP, SP, #0x10
    // 0xb5f96c: SetupParameters(RenderFittedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xb5f96c: mov             x4, x1
    //     0xb5f970: mov             x0, x2
    //     0xb5f974: stur            x1, [fp, #-8]
    //     0xb5f978: stur            x3, [fp, #-0x10]
    // 0xb5f97c: CheckStackOverflow
    //     0xb5f97c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f980: cmp             SP, x16
    //     0xb5f984: b.ls            #0xb5f9f4
    // 0xb5f988: r2 = Null
    //     0xb5f988: mov             x2, NULL
    // 0xb5f98c: r1 = Null
    //     0xb5f98c: mov             x1, NULL
    // 0xb5f990: r4 = 60
    //     0xb5f990: mov             x4, #0x3c
    // 0xb5f994: branchIfSmi(r0, 0xb5f9a0)
    //     0xb5f994: tbz             w0, #0, #0xb5f9a0
    // 0xb5f998: r4 = LoadClassIdInstr(r0)
    //     0xb5f998: ldur            x4, [x0, #-1]
    //     0xb5f99c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f9a0: sub             x4, x4, #0xb46
    // 0xb5f9a4: cmp             x4, #1
    // 0xb5f9a8: b.ls            #0xb5f9bc
    // 0xb5f9ac: r8 = BoxConstraints
    //     0xb5f9ac: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5f9b0: r3 = Null
    //     0xb5f9b0: add             x3, PP, #0xae, lsl #12  ; [pp+0xae210] Null
    //     0xb5f9b4: ldr             x3, [x3, #0x210]
    // 0xb5f9b8: r0 = BoxConstraints()
    //     0xb5f9b8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5f9bc: ldur            x0, [fp, #-8]
    // 0xb5f9c0: LoadField: r1 = r0->field_4f
    //     0xb5f9c0: ldur            w1, [x0, #0x4f]
    // 0xb5f9c4: DecompressPointer r1
    //     0xb5f9c4: add             x1, x1, HEAP, lsl #32
    // 0xb5f9c8: cmp             w1, NULL
    // 0xb5f9cc: b.ne            #0xb5f9d8
    // 0xb5f9d0: r0 = Null
    //     0xb5f9d0: mov             x0, NULL
    // 0xb5f9d4: b               #0xb5f9e8
    // 0xb5f9d8: ldur            x3, [fp, #-0x10]
    // 0xb5f9dc: r2 = Instance_BoxConstraints
    //     0xb5f9dc: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xb5f9e0: ldr             x2, [x2, #0xf0]
    // 0xb5f9e4: r0 = getDryBaseline()
    //     0xb5f9e4: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb5f9e8: LeaveFrame
    //     0xb5f9e8: mov             SP, fp
    //     0xb5f9ec: ldp             fp, lr, [SP], #0x10
    // 0xb5f9f0: ret
    //     0xb5f9f0: ret             
    // 0xb5f9f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f9f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f9f8: b               #0xb5f988
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb95a4, size: 0x314
    // 0xbb95a4: EnterFrame
    //     0xbb95a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbb95a8: mov             fp, SP
    // 0xbb95ac: AllocStack(0x20)
    //     0xbb95ac: sub             SP, SP, #0x20
    // 0xbb95b0: SetupParameters(RenderFittedBox this /* r1 => r3, fp-0x8 */)
    //     0xbb95b0: mov             x3, x1
    //     0xbb95b4: stur            x1, [fp, #-8]
    // 0xbb95b8: CheckStackOverflow
    //     0xbb95b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb95bc: cmp             SP, x16
    //     0xbb95c0: b.ls            #0xbb98a8
    // 0xbb95c4: LoadField: r1 = r3->field_4f
    //     0xbb95c4: ldur            w1, [x3, #0x4f]
    // 0xbb95c8: DecompressPointer r1
    //     0xbb95c8: add             x1, x1, HEAP, lsl #32
    // 0xbb95cc: cmp             w1, NULL
    // 0xbb95d0: b.eq            #0xbb97b0
    // 0xbb95d4: r0 = LoadClassIdInstr(r1)
    //     0xbb95d4: ldur            x0, [x1, #-1]
    //     0xbb95d8: ubfx            x0, x0, #0xc, #0x14
    // 0xbb95dc: r16 = true
    //     0xbb95dc: add             x16, NULL, #0x20  ; true
    // 0xbb95e0: str             x16, [SP]
    // 0xbb95e4: r2 = Instance_BoxConstraints
    //     0xbb95e4: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xbb95e8: ldr             x2, [x2, #0xf0]
    // 0xbb95ec: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbb95ec: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbb95f0: ldr             x4, [x4, #0xed0]
    // 0xbb95f4: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb95f4: mov             x17, #0xe6b9
    //     0xbb95f8: add             lr, x0, x17
    //     0xbb95fc: ldr             lr, [x21, lr, lsl #3]
    //     0xbb9600: blr             lr
    // 0xbb9604: ldur            x3, [fp, #-8]
    // 0xbb9608: LoadField: r0 = r3->field_57
    //     0xbb9608: ldur            w0, [x3, #0x57]
    // 0xbb960c: DecompressPointer r0
    //     0xbb960c: add             x0, x0, HEAP, lsl #32
    // 0xbb9610: LoadField: r1 = r0->field_7
    //     0xbb9610: ldur            x1, [x0, #7]
    // 0xbb9614: cmp             x1, #3
    // 0xbb9618: b.le            #0xbb9624
    // 0xbb961c: cmp             x1, #5
    // 0xbb9620: b.gt            #0xbb96b0
    // 0xbb9624: LoadField: r4 = r3->field_27
    //     0xbb9624: ldur            w4, [x3, #0x27]
    // 0xbb9628: DecompressPointer r4
    //     0xbb9628: add             x4, x4, HEAP, lsl #32
    // 0xbb962c: stur            x4, [fp, #-0x10]
    // 0xbb9630: cmp             w4, NULL
    // 0xbb9634: b.eq            #0xbb982c
    // 0xbb9638: mov             x0, x4
    // 0xbb963c: r2 = Null
    //     0xbb963c: mov             x2, NULL
    // 0xbb9640: r1 = Null
    //     0xbb9640: mov             x1, NULL
    // 0xbb9644: r4 = LoadClassIdInstr(r0)
    //     0xbb9644: ldur            x4, [x0, #-1]
    //     0xbb9648: ubfx            x4, x4, #0xc, #0x14
    // 0xbb964c: sub             x4, x4, #0xb46
    // 0xbb9650: cmp             x4, #1
    // 0xbb9654: b.ls            #0xbb9668
    // 0xbb9658: r8 = BoxConstraints
    //     0xbb9658: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb965c: r3 = Null
    //     0xbb965c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae1d0] Null
    //     0xbb9660: ldr             x3, [x3, #0x1d0]
    // 0xbb9664: r0 = BoxConstraints()
    //     0xbb9664: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb9668: ldur            x0, [fp, #-8]
    // 0xbb966c: LoadField: r1 = r0->field_4f
    //     0xbb966c: ldur            w1, [x0, #0x4f]
    // 0xbb9670: DecompressPointer r1
    //     0xbb9670: add             x1, x1, HEAP, lsl #32
    // 0xbb9674: cmp             w1, NULL
    // 0xbb9678: b.eq            #0xbb98b0
    // 0xbb967c: r0 = size()
    //     0xbb967c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb9680: ldur            x1, [fp, #-0x10]
    // 0xbb9684: mov             x2, x0
    // 0xbb9688: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xbb9688: bl              #0xb212f8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xbb968c: ldur            x3, [fp, #-8]
    // 0xbb9690: StoreField: r3->field_4b = r0
    //     0xbb9690: stur            w0, [x3, #0x4b]
    //     0xbb9694: ldurb           w16, [x3, #-1]
    //     0xbb9698: ldurb           w17, [x0, #-1]
    //     0xbb969c: and             x16, x17, x16, lsr #2
    //     0xbb96a0: tst             x16, HEAP, lsr #32
    //     0xbb96a4: b.eq            #0xbb96ac
    //     0xbb96a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbb96ac: b               #0xbb97a4
    // 0xbb96b0: LoadField: r4 = r3->field_27
    //     0xbb96b0: ldur            w4, [x3, #0x27]
    // 0xbb96b4: DecompressPointer r4
    //     0xbb96b4: add             x4, x4, HEAP, lsl #32
    // 0xbb96b8: stur            x4, [fp, #-0x10]
    // 0xbb96bc: cmp             w4, NULL
    // 0xbb96c0: b.eq            #0xbb9848
    // 0xbb96c4: mov             x0, x4
    // 0xbb96c8: r2 = Null
    //     0xbb96c8: mov             x2, NULL
    // 0xbb96cc: r1 = Null
    //     0xbb96cc: mov             x1, NULL
    // 0xbb96d0: r4 = LoadClassIdInstr(r0)
    //     0xbb96d0: ldur            x4, [x0, #-1]
    //     0xbb96d4: ubfx            x4, x4, #0xc, #0x14
    // 0xbb96d8: sub             x4, x4, #0xb46
    // 0xbb96dc: cmp             x4, #1
    // 0xbb96e0: b.ls            #0xbb96f4
    // 0xbb96e4: r8 = BoxConstraints
    //     0xbb96e4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb96e8: r3 = Null
    //     0xbb96e8: add             x3, PP, #0xae, lsl #12  ; [pp+0xae1e0] Null
    //     0xbb96ec: ldr             x3, [x3, #0x1e0]
    // 0xbb96f0: r0 = BoxConstraints()
    //     0xbb96f0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb96f4: ldur            x1, [fp, #-0x10]
    // 0xbb96f8: r0 = loosen()
    //     0xbb96f8: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xbb96fc: mov             x2, x0
    // 0xbb9700: ldur            x0, [fp, #-8]
    // 0xbb9704: stur            x2, [fp, #-0x10]
    // 0xbb9708: LoadField: r1 = r0->field_4f
    //     0xbb9708: ldur            w1, [x0, #0x4f]
    // 0xbb970c: DecompressPointer r1
    //     0xbb970c: add             x1, x1, HEAP, lsl #32
    // 0xbb9710: cmp             w1, NULL
    // 0xbb9714: b.eq            #0xbb98b4
    // 0xbb9718: r0 = size()
    //     0xbb9718: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb971c: ldur            x1, [fp, #-0x10]
    // 0xbb9720: mov             x2, x0
    // 0xbb9724: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xbb9724: bl              #0xb212f8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xbb9728: mov             x4, x0
    // 0xbb972c: ldur            x3, [fp, #-8]
    // 0xbb9730: stur            x4, [fp, #-0x18]
    // 0xbb9734: LoadField: r5 = r3->field_27
    //     0xbb9734: ldur            w5, [x3, #0x27]
    // 0xbb9738: DecompressPointer r5
    //     0xbb9738: add             x5, x5, HEAP, lsl #32
    // 0xbb973c: stur            x5, [fp, #-0x10]
    // 0xbb9740: cmp             w5, NULL
    // 0xbb9744: b.eq            #0xbb9868
    // 0xbb9748: mov             x0, x5
    // 0xbb974c: r2 = Null
    //     0xbb974c: mov             x2, NULL
    // 0xbb9750: r1 = Null
    //     0xbb9750: mov             x1, NULL
    // 0xbb9754: r4 = LoadClassIdInstr(r0)
    //     0xbb9754: ldur            x4, [x0, #-1]
    //     0xbb9758: ubfx            x4, x4, #0xc, #0x14
    // 0xbb975c: sub             x4, x4, #0xb46
    // 0xbb9760: cmp             x4, #1
    // 0xbb9764: b.ls            #0xbb9778
    // 0xbb9768: r8 = BoxConstraints
    //     0xbb9768: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb976c: r3 = Null
    //     0xbb976c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae1f0] Null
    //     0xbb9770: ldr             x3, [x3, #0x1f0]
    // 0xbb9774: r0 = BoxConstraints()
    //     0xbb9774: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb9778: ldur            x1, [fp, #-0x10]
    // 0xbb977c: ldur            x2, [fp, #-0x18]
    // 0xbb9780: r0 = constrain()
    //     0xbb9780: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbb9784: ldur            x3, [fp, #-8]
    // 0xbb9788: StoreField: r3->field_4b = r0
    //     0xbb9788: stur            w0, [x3, #0x4b]
    //     0xbb978c: ldurb           w16, [x3, #-1]
    //     0xbb9790: ldurb           w17, [x0, #-1]
    //     0xbb9794: and             x16, x17, x16, lsr #2
    //     0xbb9798: tst             x16, HEAP, lsr #32
    //     0xbb979c: b.eq            #0xbb97a4
    //     0xbb97a0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbb97a4: mov             x1, x3
    // 0xbb97a8: r0 = _clearPaintData()
    //     0xbb97a8: bl              #0xbb98b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0xbb97ac: b               #0xbb981c
    // 0xbb97b0: LoadField: r4 = r3->field_27
    //     0xbb97b0: ldur            w4, [x3, #0x27]
    // 0xbb97b4: DecompressPointer r4
    //     0xbb97b4: add             x4, x4, HEAP, lsl #32
    // 0xbb97b8: stur            x4, [fp, #-0x10]
    // 0xbb97bc: cmp             w4, NULL
    // 0xbb97c0: b.eq            #0xbb9888
    // 0xbb97c4: mov             x0, x4
    // 0xbb97c8: r2 = Null
    //     0xbb97c8: mov             x2, NULL
    // 0xbb97cc: r1 = Null
    //     0xbb97cc: mov             x1, NULL
    // 0xbb97d0: r4 = LoadClassIdInstr(r0)
    //     0xbb97d0: ldur            x4, [x0, #-1]
    //     0xbb97d4: ubfx            x4, x4, #0xc, #0x14
    // 0xbb97d8: sub             x4, x4, #0xb46
    // 0xbb97dc: cmp             x4, #1
    // 0xbb97e0: b.ls            #0xbb97f4
    // 0xbb97e4: r8 = BoxConstraints
    //     0xbb97e4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb97e8: r3 = Null
    //     0xbb97e8: add             x3, PP, #0xae, lsl #12  ; [pp+0xae200] Null
    //     0xbb97ec: ldr             x3, [x3, #0x200]
    // 0xbb97f0: r0 = BoxConstraints()
    //     0xbb97f0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb97f4: ldur            x1, [fp, #-0x10]
    // 0xbb97f8: r0 = smallest()
    //     0xbb97f8: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbb97fc: ldur            x1, [fp, #-8]
    // 0xbb9800: StoreField: r1->field_4b = r0
    //     0xbb9800: stur            w0, [x1, #0x4b]
    //     0xbb9804: ldurb           w16, [x1, #-1]
    //     0xbb9808: ldurb           w17, [x0, #-1]
    //     0xbb980c: and             x16, x17, x16, lsr #2
    //     0xbb9810: tst             x16, HEAP, lsr #32
    //     0xbb9814: b.eq            #0xbb981c
    //     0xbb9818: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb981c: r0 = Null
    //     0xbb981c: mov             x0, NULL
    // 0xbb9820: LeaveFrame
    //     0xbb9820: mov             SP, fp
    //     0xbb9824: ldp             fp, lr, [SP], #0x10
    // 0xbb9828: ret
    //     0xbb9828: ret             
    // 0xbb982c: r0 = StateError()
    //     0xbb982c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9830: mov             x1, x0
    // 0xbb9834: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9834: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9838: StoreField: r1->field_b = r0
    //     0xbb9838: stur            w0, [x1, #0xb]
    // 0xbb983c: mov             x0, x1
    // 0xbb9840: r0 = Throw()
    //     0xbb9840: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9844: brk             #0
    // 0xbb9848: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9848: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb984c: r0 = StateError()
    //     0xbb984c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9850: mov             x1, x0
    // 0xbb9854: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9854: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9858: StoreField: r1->field_b = r0
    //     0xbb9858: stur            w0, [x1, #0xb]
    // 0xbb985c: mov             x0, x1
    // 0xbb9860: r0 = Throw()
    //     0xbb9860: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9864: brk             #0
    // 0xbb9868: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9868: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb986c: r0 = StateError()
    //     0xbb986c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9870: mov             x1, x0
    // 0xbb9874: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9874: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9878: StoreField: r1->field_b = r0
    //     0xbb9878: stur            w0, [x1, #0xb]
    // 0xbb987c: mov             x0, x1
    // 0xbb9880: r0 = Throw()
    //     0xbb9880: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9884: brk             #0
    // 0xbb9888: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9888: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb988c: r0 = StateError()
    //     0xbb988c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9890: mov             x1, x0
    // 0xbb9894: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9894: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9898: StoreField: r1->field_b = r0
    //     0xbb9898: stur            w0, [x1, #0xb]
    // 0xbb989c: mov             x0, x1
    // 0xbb98a0: r0 = Throw()
    //     0xbb98a0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb98a4: brk             #0
    // 0xbb98a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb98a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb98ac: b               #0xbb95c4
    // 0xbb98b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb98b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb98b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb98b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clearPaintData(/* No info */) {
    // ** addr: 0xbb98b8, size: 0x10
    // 0xbb98b8: StoreField: r1->field_63 = rNULL
    //     0xbb98b8: stur            NULL, [x1, #0x63]
    // 0xbb98bc: StoreField: r1->field_67 = rNULL
    //     0xbb98bc: stur            NULL, [x1, #0x67]
    // 0xbb98c0: r0 = Null
    //     0xbb98c0: mov             x0, NULL
    // 0xbb98c4: ret
    //     0xbb98c4: ret             
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf0e60, size: 0xc8
    // 0xbf0e60: EnterFrame
    //     0xbf0e60: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0e64: mov             fp, SP
    // 0xbf0e68: AllocStack(0x18)
    //     0xbf0e68: sub             SP, SP, #0x18
    // 0xbf0e6c: SetupParameters(RenderFittedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf0e6c: mov             x5, x1
    //     0xbf0e70: mov             x4, x2
    //     0xbf0e74: stur            x1, [fp, #-8]
    //     0xbf0e78: stur            x2, [fp, #-0x10]
    //     0xbf0e7c: stur            x3, [fp, #-0x18]
    // 0xbf0e80: CheckStackOverflow
    //     0xbf0e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0e84: cmp             SP, x16
    //     0xbf0e88: b.ls            #0xbf0f1c
    // 0xbf0e8c: mov             x0, x4
    // 0xbf0e90: r2 = Null
    //     0xbf0e90: mov             x2, NULL
    // 0xbf0e94: r1 = Null
    //     0xbf0e94: mov             x1, NULL
    // 0xbf0e98: r4 = 60
    //     0xbf0e98: mov             x4, #0x3c
    // 0xbf0e9c: branchIfSmi(r0, 0xbf0ea8)
    //     0xbf0e9c: tbz             w0, #0, #0xbf0ea8
    // 0xbf0ea0: r4 = LoadClassIdInstr(r0)
    //     0xbf0ea0: ldur            x4, [x0, #-1]
    //     0xbf0ea4: ubfx            x4, x4, #0xc, #0x14
    // 0xbf0ea8: r17 = -4710
    //     0xbf0ea8: mov             x17, #-0x1266
    // 0xbf0eac: add             x4, x4, x17
    // 0xbf0eb0: cmp             x4, #0x109
    // 0xbf0eb4: b.ls            #0xbf0ec8
    // 0xbf0eb8: r8 = RenderBox
    //     0xbf0eb8: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf0ebc: r3 = Null
    //     0xbf0ebc: add             x3, PP, #0xae, lsl #12  ; [pp+0xae168] Null
    //     0xbf0ec0: ldr             x3, [x3, #0x168]
    // 0xbf0ec4: r0 = RenderBox()
    //     0xbf0ec4: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf0ec8: ldur            x1, [fp, #-8]
    // 0xbf0ecc: ldur            x2, [fp, #-0x10]
    // 0xbf0ed0: r0 = paintsChild()
    //     0xbf0ed0: bl              #0xbf2bb4  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::paintsChild
    // 0xbf0ed4: tbz             w0, #4, #0xbf0ee4
    // 0xbf0ed8: ldur            x1, [fp, #-0x18]
    // 0xbf0edc: r0 = setZero()
    //     0xbf0edc: bl              #0x881d94  ; [package:vector_math/vector_math_64.dart] Matrix4::setZero
    // 0xbf0ee0: b               #0xbf0f0c
    // 0xbf0ee4: ldur            x0, [fp, #-8]
    // 0xbf0ee8: mov             x1, x0
    // 0xbf0eec: r0 = _updatePaintData()
    //     0xbf0eec: bl              #0xbf0f28  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0xbf0ef0: ldur            x0, [fp, #-8]
    // 0xbf0ef4: LoadField: r2 = r0->field_67
    //     0xbf0ef4: ldur            w2, [x0, #0x67]
    // 0xbf0ef8: DecompressPointer r2
    //     0xbf0ef8: add             x2, x2, HEAP, lsl #32
    // 0xbf0efc: cmp             w2, NULL
    // 0xbf0f00: b.eq            #0xbf0f24
    // 0xbf0f04: ldur            x1, [fp, #-0x18]
    // 0xbf0f08: r0 = multiply()
    //     0xbf0f08: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf0f0c: r0 = Null
    //     0xbf0f0c: mov             x0, NULL
    // 0xbf0f10: LeaveFrame
    //     0xbf0f10: mov             SP, fp
    //     0xbf0f14: ldp             fp, lr, [SP], #0x10
    // 0xbf0f18: ret
    //     0xbf0f18: ret             
    // 0xbf0f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0f1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0f20: b               #0xbf0e8c
    // 0xbf0f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0f24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updatePaintData(/* No info */) {
    // ** addr: 0xbf0f28, size: 0x260
    // 0xbf0f28: EnterFrame
    //     0xbf0f28: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0f2c: mov             fp, SP
    // 0xbf0f30: AllocStack(0x38)
    //     0xbf0f30: sub             SP, SP, #0x38
    // 0xbf0f34: SetupParameters(RenderFittedBox this /* r1 => r1, fp-0x8 */)
    //     0xbf0f34: stur            x1, [fp, #-8]
    // 0xbf0f38: CheckStackOverflow
    //     0xbf0f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0f3c: cmp             SP, x16
    //     0xbf0f40: b.ls            #0xbf117c
    // 0xbf0f44: LoadField: r0 = r1->field_67
    //     0xbf0f44: ldur            w0, [x1, #0x67]
    // 0xbf0f48: DecompressPointer r0
    //     0xbf0f48: add             x0, x0, HEAP, lsl #32
    // 0xbf0f4c: cmp             w0, NULL
    // 0xbf0f50: b.eq            #0xbf0f64
    // 0xbf0f54: r0 = Null
    //     0xbf0f54: mov             x0, NULL
    // 0xbf0f58: LeaveFrame
    //     0xbf0f58: mov             SP, fp
    //     0xbf0f5c: ldp             fp, lr, [SP], #0x10
    // 0xbf0f60: ret
    //     0xbf0f60: ret             
    // 0xbf0f64: LoadField: r0 = r1->field_4f
    //     0xbf0f64: ldur            w0, [x1, #0x4f]
    // 0xbf0f68: DecompressPointer r0
    //     0xbf0f68: add             x0, x0, HEAP, lsl #32
    // 0xbf0f6c: cmp             w0, NULL
    // 0xbf0f70: b.ne            #0xbf0fc8
    // 0xbf0f74: r0 = false
    //     0xbf0f74: add             x0, NULL, #0x30  ; false
    // 0xbf0f78: StoreField: r1->field_63 = r0
    //     0xbf0f78: stur            w0, [x1, #0x63]
    // 0xbf0f7c: r0 = Matrix4()
    //     0xbf0f7c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xbf0f80: r4 = 32
    //     0xbf0f80: mov             x4, #0x20
    // 0xbf0f84: stur            x0, [fp, #-0x10]
    // 0xbf0f88: r0 = AllocateFloat64Array()
    //     0xbf0f88: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xbf0f8c: mov             x1, x0
    // 0xbf0f90: ldur            x0, [fp, #-0x10]
    // 0xbf0f94: StoreField: r0->field_7 = r1
    //     0xbf0f94: stur            w1, [x0, #7]
    // 0xbf0f98: mov             x1, x0
    // 0xbf0f9c: r0 = setIdentity()
    //     0xbf0f9c: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xbf0fa0: ldur            x0, [fp, #-0x10]
    // 0xbf0fa4: ldur            x2, [fp, #-8]
    // 0xbf0fa8: StoreField: r2->field_67 = r0
    //     0xbf0fa8: stur            w0, [x2, #0x67]
    //     0xbf0fac: ldurb           w16, [x2, #-1]
    //     0xbf0fb0: ldurb           w17, [x0, #-1]
    //     0xbf0fb4: and             x16, x17, x16, lsr #2
    //     0xbf0fb8: tst             x16, HEAP, lsr #32
    //     0xbf0fbc: b.eq            #0xbf0fc4
    //     0xbf0fc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbf0fc4: b               #0xbf116c
    // 0xbf0fc8: mov             x2, x1
    // 0xbf0fcc: mov             x1, x2
    // 0xbf0fd0: r0 = _resolve()
    //     0xbf0fd0: bl              #0xbf1200  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_resolve
    // 0xbf0fd4: ldur            x0, [fp, #-8]
    // 0xbf0fd8: LoadField: r1 = r0->field_4f
    //     0xbf0fd8: ldur            w1, [x0, #0x4f]
    // 0xbf0fdc: DecompressPointer r1
    //     0xbf0fdc: add             x1, x1, HEAP, lsl #32
    // 0xbf0fe0: cmp             w1, NULL
    // 0xbf0fe4: b.eq            #0xbf1184
    // 0xbf0fe8: r0 = size()
    //     0xbf0fe8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf0fec: mov             x2, x0
    // 0xbf0ff0: ldur            x0, [fp, #-8]
    // 0xbf0ff4: stur            x2, [fp, #-0x18]
    // 0xbf0ff8: LoadField: r3 = r0->field_57
    //     0xbf0ff8: ldur            w3, [x0, #0x57]
    // 0xbf0ffc: DecompressPointer r3
    //     0xbf0ffc: add             x3, x3, HEAP, lsl #32
    // 0xbf1000: mov             x1, x0
    // 0xbf1004: stur            x3, [fp, #-0x10]
    // 0xbf1008: r0 = size()
    //     0xbf1008: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf100c: ldur            x1, [fp, #-0x10]
    // 0xbf1010: ldur            x2, [fp, #-0x18]
    // 0xbf1014: mov             x3, x0
    // 0xbf1018: r0 = applyBoxFit()
    //     0xbf1018: bl              #0xb8aba4  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0xbf101c: LoadField: r3 = r0->field_b
    //     0xbf101c: ldur            w3, [x0, #0xb]
    // 0xbf1020: DecompressPointer r3
    //     0xbf1020: add             x3, x3, HEAP, lsl #32
    // 0xbf1024: stur            x3, [fp, #-0x20]
    // 0xbf1028: LoadField: d0 = r3->field_7
    //     0xbf1028: ldur            d0, [x3, #7]
    // 0xbf102c: LoadField: r4 = r0->field_7
    //     0xbf102c: ldur            w4, [x0, #7]
    // 0xbf1030: DecompressPointer r4
    //     0xbf1030: add             x4, x4, HEAP, lsl #32
    // 0xbf1034: stur            x4, [fp, #-0x10]
    // 0xbf1038: LoadField: d1 = r4->field_7
    //     0xbf1038: ldur            d1, [x4, #7]
    // 0xbf103c: fdiv            d2, d0, d1
    // 0xbf1040: stur            d2, [fp, #-0x30]
    // 0xbf1044: LoadField: d0 = r3->field_f
    //     0xbf1044: ldur            d0, [x3, #0xf]
    // 0xbf1048: LoadField: d1 = r4->field_f
    //     0xbf1048: ldur            d1, [x4, #0xf]
    // 0xbf104c: fdiv            d3, d0, d1
    // 0xbf1050: ldur            x2, [fp, #-0x18]
    // 0xbf1054: stur            d3, [fp, #-0x28]
    // 0xbf1058: r1 = Instance_Offset
    //     0xbf1058: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbf105c: r0 = &()
    //     0xbf105c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbf1060: ldur            x2, [fp, #-0x10]
    // 0xbf1064: mov             x3, x0
    // 0xbf1068: r1 = Instance_Alignment
    //     0xbf1068: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbf106c: ldr             x1, [x1, #0xb80]
    // 0xbf1070: r0 = inscribe()
    //     0xbf1070: bl              #0xb7da30  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0xbf1074: ldur            x1, [fp, #-8]
    // 0xbf1078: stur            x0, [fp, #-0x10]
    // 0xbf107c: r0 = size()
    //     0xbf107c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf1080: mov             x2, x0
    // 0xbf1084: r1 = Instance_Offset
    //     0xbf1084: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbf1088: r0 = &()
    //     0xbf1088: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbf108c: ldur            x2, [fp, #-0x20]
    // 0xbf1090: mov             x3, x0
    // 0xbf1094: r1 = Instance_Alignment
    //     0xbf1094: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbf1098: ldr             x1, [x1, #0xb80]
    // 0xbf109c: r0 = inscribe()
    //     0xbf109c: bl              #0xb7da30  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0xbf10a0: mov             x1, x0
    // 0xbf10a4: ldur            x0, [fp, #-0x10]
    // 0xbf10a8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbf10a8: ldur            d0, [x0, #0x17]
    // 0xbf10ac: LoadField: d2 = r0->field_7
    //     0xbf10ac: ldur            d2, [x0, #7]
    // 0xbf10b0: stur            d2, [fp, #-0x38]
    // 0xbf10b4: fsub            d1, d0, d2
    // 0xbf10b8: ldur            x2, [fp, #-0x18]
    // 0xbf10bc: LoadField: d0 = r2->field_7
    //     0xbf10bc: ldur            d0, [x2, #7]
    // 0xbf10c0: fcmp            d0, d1
    // 0xbf10c4: b.le            #0xbf10d0
    // 0xbf10c8: r3 = true
    //     0xbf10c8: add             x3, NULL, #0x20  ; true
    // 0xbf10cc: b               #0xbf10f4
    // 0xbf10d0: LoadField: d0 = r0->field_1f
    //     0xbf10d0: ldur            d0, [x0, #0x1f]
    // 0xbf10d4: LoadField: d1 = r0->field_f
    //     0xbf10d4: ldur            d1, [x0, #0xf]
    // 0xbf10d8: fsub            d3, d0, d1
    // 0xbf10dc: LoadField: d0 = r2->field_f
    //     0xbf10dc: ldur            d0, [x2, #0xf]
    // 0xbf10e0: fcmp            d0, d3
    // 0xbf10e4: r16 = true
    //     0xbf10e4: add             x16, NULL, #0x20  ; true
    // 0xbf10e8: r17 = false
    //     0xbf10e8: add             x17, NULL, #0x30  ; false
    // 0xbf10ec: csel            x2, x16, x17, gt
    // 0xbf10f0: mov             x3, x2
    // 0xbf10f4: ldur            x2, [fp, #-8]
    // 0xbf10f8: StoreField: r2->field_63 = r3
    //     0xbf10f8: stur            w3, [x2, #0x63]
    // 0xbf10fc: LoadField: d0 = r1->field_7
    //     0xbf10fc: ldur            d0, [x1, #7]
    // 0xbf1100: LoadField: d1 = r1->field_f
    //     0xbf1100: ldur            d1, [x1, #0xf]
    // 0xbf1104: r1 = Null
    //     0xbf1104: mov             x1, NULL
    // 0xbf1108: r0 = Matrix4.translationValues()
    //     0xbf1108: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xbf110c: mov             x1, x0
    // 0xbf1110: ldur            d0, [fp, #-0x30]
    // 0xbf1114: ldur            d1, [fp, #-0x28]
    // 0xbf1118: d2 = 1.000000
    //     0xbf1118: fmov            d2, #1.00000000
    // 0xbf111c: stur            x0, [fp, #-0x18]
    // 0xbf1120: r0 = scaleByDouble()
    //     0xbf1120: bl              #0x832ce4  ; [package:vector_math/vector_math_64.dart] Matrix4::scaleByDouble
    // 0xbf1124: ldur            d0, [fp, #-0x38]
    // 0xbf1128: fneg            d1, d0
    // 0xbf112c: ldur            x0, [fp, #-0x10]
    // 0xbf1130: LoadField: d0 = r0->field_f
    //     0xbf1130: ldur            d0, [x0, #0xf]
    // 0xbf1134: fneg            d2, d0
    // 0xbf1138: ldur            x1, [fp, #-0x18]
    // 0xbf113c: mov             v0.16b, v1.16b
    // 0xbf1140: mov             v1.16b, v2.16b
    // 0xbf1144: r0 = translateByDouble()
    //     0xbf1144: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf1148: ldur            x0, [fp, #-0x18]
    // 0xbf114c: ldur            x1, [fp, #-8]
    // 0xbf1150: StoreField: r1->field_67 = r0
    //     0xbf1150: stur            w0, [x1, #0x67]
    //     0xbf1154: ldurb           w16, [x1, #-1]
    //     0xbf1158: ldurb           w17, [x0, #-1]
    //     0xbf115c: and             x16, x17, x16, lsr #2
    //     0xbf1160: tst             x16, HEAP, lsr #32
    //     0xbf1164: b.eq            #0xbf116c
    //     0xbf1168: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbf116c: r0 = Null
    //     0xbf116c: mov             x0, NULL
    // 0xbf1170: LeaveFrame
    //     0xbf1170: mov             SP, fp
    //     0xbf1174: ldp             fp, lr, [SP], #0x10
    // 0xbf1178: ret
    //     0xbf1178: ret             
    // 0xbf117c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf117c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1180: b               #0xbf0f44
    // 0xbf1184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolve(/* No info */) {
    // ** addr: 0xbf1200, size: 0x30
    // 0xbf1200: LoadField: r2 = r1->field_53
    //     0xbf1200: ldur            w2, [x1, #0x53]
    // 0xbf1204: DecompressPointer r2
    //     0xbf1204: add             x2, x2, HEAP, lsl #32
    // 0xbf1208: cmp             w2, NULL
    // 0xbf120c: b.ne            #0xbf1228
    // 0xbf1210: r3 = Instance_Alignment
    //     0xbf1210: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbf1214: ldr             x3, [x3, #0xb80]
    // 0xbf1218: StoreField: r1->field_53 = r3
    //     0xbf1218: stur            w3, [x1, #0x53]
    // 0xbf121c: r0 = Instance_Alignment
    //     0xbf121c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbf1220: ldr             x0, [x0, #0xb80]
    // 0xbf1224: b               #0xbf122c
    // 0xbf1228: mov             x0, x2
    // 0xbf122c: ret
    //     0xbf122c: ret             
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0xbf2bb4, size: 0xec
    // 0xbf2bb4: EnterFrame
    //     0xbf2bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2bb8: mov             fp, SP
    // 0xbf2bbc: AllocStack(0x10)
    //     0xbf2bbc: sub             SP, SP, #0x10
    // 0xbf2bc0: SetupParameters(RenderFittedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xbf2bc0: mov             x4, x1
    //     0xbf2bc4: mov             x3, x2
    //     0xbf2bc8: stur            x1, [fp, #-8]
    //     0xbf2bcc: stur            x2, [fp, #-0x10]
    // 0xbf2bd0: CheckStackOverflow
    //     0xbf2bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf2bd4: cmp             SP, x16
    //     0xbf2bd8: b.ls            #0xbf2c98
    // 0xbf2bdc: mov             x0, x3
    // 0xbf2be0: r2 = Null
    //     0xbf2be0: mov             x2, NULL
    // 0xbf2be4: r1 = Null
    //     0xbf2be4: mov             x1, NULL
    // 0xbf2be8: r4 = 60
    //     0xbf2be8: mov             x4, #0x3c
    // 0xbf2bec: branchIfSmi(r0, 0xbf2bf8)
    //     0xbf2bec: tbz             w0, #0, #0xbf2bf8
    // 0xbf2bf0: r4 = LoadClassIdInstr(r0)
    //     0xbf2bf0: ldur            x4, [x0, #-1]
    //     0xbf2bf4: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2bf8: r17 = -4710
    //     0xbf2bf8: mov             x17, #-0x1266
    // 0xbf2bfc: add             x4, x4, x17
    // 0xbf2c00: cmp             x4, #0x109
    // 0xbf2c04: b.ls            #0xbf2c18
    // 0xbf2c08: r8 = RenderBox
    //     0xbf2c08: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2c0c: r3 = Null
    //     0xbf2c0c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae178] Null
    //     0xbf2c10: ldr             x3, [x3, #0x178]
    // 0xbf2c14: r0 = RenderBox()
    //     0xbf2c14: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf2c18: ldur            x1, [fp, #-8]
    // 0xbf2c1c: r0 = size()
    //     0xbf2c1c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf2c20: LoadField: d0 = r0->field_7
    //     0xbf2c20: ldur            d0, [x0, #7]
    // 0xbf2c24: d1 = 0.000000
    //     0xbf2c24: eor             v1.16b, v1.16b, v1.16b
    // 0xbf2c28: fcmp            d1, d0
    // 0xbf2c2c: b.ge            #0xbf2c88
    // 0xbf2c30: LoadField: d0 = r0->field_f
    //     0xbf2c30: ldur            d0, [x0, #0xf]
    // 0xbf2c34: fcmp            d1, d0
    // 0xbf2c38: r16 = true
    //     0xbf2c38: add             x16, NULL, #0x20  ; true
    // 0xbf2c3c: r17 = false
    //     0xbf2c3c: add             x17, NULL, #0x30  ; false
    // 0xbf2c40: csel            x0, x16, x17, ge
    // 0xbf2c44: tbz             w0, #4, #0xbf2c88
    // 0xbf2c48: ldur            x1, [fp, #-0x10]
    // 0xbf2c4c: r0 = size()
    //     0xbf2c4c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf2c50: LoadField: d0 = r0->field_7
    //     0xbf2c50: ldur            d0, [x0, #7]
    // 0xbf2c54: d1 = 0.000000
    //     0xbf2c54: eor             v1.16b, v1.16b, v1.16b
    // 0xbf2c58: fcmp            d1, d0
    // 0xbf2c5c: b.lt            #0xbf2c68
    // 0xbf2c60: r1 = true
    //     0xbf2c60: add             x1, NULL, #0x20  ; true
    // 0xbf2c64: b               #0xbf2c7c
    // 0xbf2c68: LoadField: d0 = r0->field_f
    //     0xbf2c68: ldur            d0, [x0, #0xf]
    // 0xbf2c6c: fcmp            d1, d0
    // 0xbf2c70: r16 = true
    //     0xbf2c70: add             x16, NULL, #0x20  ; true
    // 0xbf2c74: r17 = false
    //     0xbf2c74: add             x17, NULL, #0x30  ; false
    // 0xbf2c78: csel            x1, x16, x17, ge
    // 0xbf2c7c: eor             x2, x1, #0x10
    // 0xbf2c80: mov             x0, x2
    // 0xbf2c84: b               #0xbf2c8c
    // 0xbf2c88: r0 = false
    //     0xbf2c88: add             x0, NULL, #0x30  ; false
    // 0xbf2c8c: LeaveFrame
    //     0xbf2c8c: mov             SP, fp
    //     0xbf2c90: ldp             fp, lr, [SP], #0x10
    // 0xbf2c94: ret
    //     0xbf2c94: ret             
    // 0xbf2c98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2c98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2c9c: b               #0xbf2bdc
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1cd84, size: 0x248
    // 0xc1cd84: EnterFrame
    //     0xc1cd84: stp             fp, lr, [SP, #-0x10]!
    //     0xc1cd88: mov             fp, SP
    // 0xc1cd8c: AllocStack(0x50)
    //     0xc1cd8c: sub             SP, SP, #0x50
    // 0xc1cd90: SetupParameters(RenderFittedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1cd90: mov             x0, x2
    //     0xc1cd94: stur            x2, [fp, #-0x10]
    //     0xc1cd98: mov             x2, x1
    //     0xc1cd9c: stur            x1, [fp, #-8]
    //     0xc1cda0: stur            x3, [fp, #-0x18]
    // 0xc1cda4: CheckStackOverflow
    //     0xc1cda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1cda8: cmp             SP, x16
    //     0xc1cdac: b.ls            #0xc1cfb0
    // 0xc1cdb0: LoadField: r1 = r2->field_4f
    //     0xc1cdb0: ldur            w1, [x2, #0x4f]
    // 0xc1cdb4: DecompressPointer r1
    //     0xc1cdb4: add             x1, x1, HEAP, lsl #32
    // 0xc1cdb8: cmp             w1, NULL
    // 0xc1cdbc: b.eq            #0xc1ce18
    // 0xc1cdc0: mov             x1, x2
    // 0xc1cdc4: r0 = size()
    //     0xc1cdc4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1cdc8: LoadField: d0 = r0->field_7
    //     0xc1cdc8: ldur            d0, [x0, #7]
    // 0xc1cdcc: d1 = 0.000000
    //     0xc1cdcc: eor             v1.16b, v1.16b, v1.16b
    // 0xc1cdd0: fcmp            d1, d0
    // 0xc1cdd4: b.ge            #0xc1ce18
    // 0xc1cdd8: LoadField: d0 = r0->field_f
    //     0xc1cdd8: ldur            d0, [x0, #0xf]
    // 0xc1cddc: fcmp            d1, d0
    // 0xc1cde0: b.ge            #0xc1ce18
    // 0xc1cde4: ldur            x0, [fp, #-8]
    // 0xc1cde8: LoadField: r1 = r0->field_4f
    //     0xc1cde8: ldur            w1, [x0, #0x4f]
    // 0xc1cdec: DecompressPointer r1
    //     0xc1cdec: add             x1, x1, HEAP, lsl #32
    // 0xc1cdf0: cmp             w1, NULL
    // 0xc1cdf4: b.eq            #0xc1cfb8
    // 0xc1cdf8: r0 = size()
    //     0xc1cdf8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1cdfc: LoadField: d0 = r0->field_7
    //     0xc1cdfc: ldur            d0, [x0, #7]
    // 0xc1ce00: d1 = 0.000000
    //     0xc1ce00: eor             v1.16b, v1.16b, v1.16b
    // 0xc1ce04: fcmp            d1, d0
    // 0xc1ce08: b.ge            #0xc1ce18
    // 0xc1ce0c: LoadField: d0 = r0->field_f
    //     0xc1ce0c: ldur            d0, [x0, #0xf]
    // 0xc1ce10: fcmp            d1, d0
    // 0xc1ce14: b.lt            #0xc1ce28
    // 0xc1ce18: r0 = Null
    //     0xc1ce18: mov             x0, NULL
    // 0xc1ce1c: LeaveFrame
    //     0xc1ce1c: mov             SP, fp
    //     0xc1ce20: ldp             fp, lr, [SP], #0x10
    // 0xc1ce24: ret
    //     0xc1ce24: ret             
    // 0xc1ce28: ldur            x0, [fp, #-8]
    // 0xc1ce2c: mov             x1, x0
    // 0xc1ce30: r0 = _updatePaintData()
    //     0xc1ce30: bl              #0xbf0f28  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0xc1ce34: ldur            x0, [fp, #-8]
    // 0xc1ce38: LoadField: r1 = r0->field_63
    //     0xc1ce38: ldur            w1, [x0, #0x63]
    // 0xc1ce3c: DecompressPointer r1
    //     0xc1ce3c: add             x1, x1, HEAP, lsl #32
    // 0xc1ce40: cmp             w1, NULL
    // 0xc1ce44: b.eq            #0xc1cfbc
    // 0xc1ce48: tbnz            w1, #4, #0xc1cf70
    // 0xc1ce4c: LoadField: r1 = r0->field_6b
    //     0xc1ce4c: ldur            w1, [x0, #0x6b]
    // 0xc1ce50: DecompressPointer r1
    //     0xc1ce50: add             x1, x1, HEAP, lsl #32
    // 0xc1ce54: r16 = Instance_Clip
    //     0xc1ce54: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1ce58: ldr             x16, [x16, #0x840]
    // 0xc1ce5c: cmp             w1, w16
    // 0xc1ce60: b.eq            #0xc1cf70
    // 0xc1ce64: LoadField: r2 = r0->field_37
    //     0xc1ce64: ldur            w2, [x0, #0x37]
    // 0xc1ce68: DecompressPointer r2
    //     0xc1ce68: add             x2, x2, HEAP, lsl #32
    // 0xc1ce6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1ce70: cmp             w2, w16
    // 0xc1ce74: b.eq            #0xc1cfc0
    // 0xc1ce78: mov             x1, x0
    // 0xc1ce7c: stur            x2, [fp, #-0x20]
    // 0xc1ce80: r0 = size()
    //     0xc1ce80: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1ce84: mov             x2, x0
    // 0xc1ce88: r1 = Instance_Offset
    //     0xc1ce88: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1ce8c: r0 = &()
    //     0xc1ce8c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1ce90: mov             x4, x0
    // 0xc1ce94: ldur            x3, [fp, #-8]
    // 0xc1ce98: stur            x4, [fp, #-0x38]
    // 0xc1ce9c: LoadField: r5 = r3->field_2f
    //     0xc1ce9c: ldur            w5, [x3, #0x2f]
    // 0xc1cea0: DecompressPointer r5
    //     0xc1cea0: add             x5, x5, HEAP, lsl #32
    // 0xc1cea4: stur            x5, [fp, #-0x30]
    // 0xc1cea8: LoadField: r6 = r5->field_b
    //     0xc1cea8: ldur            w6, [x5, #0xb]
    // 0xc1ceac: DecompressPointer r6
    //     0xc1ceac: add             x6, x6, HEAP, lsl #32
    // 0xc1ceb0: stur            x6, [fp, #-0x28]
    // 0xc1ceb4: r0 = LoadClassIdInstr(r6)
    //     0xc1ceb4: ldur            x0, [x6, #-1]
    //     0xc1ceb8: ubfx            x0, x0, #0xc, #0x14
    // 0xc1cebc: r17 = 4659
    //     0xc1cebc: mov             x17, #0x1233
    // 0xc1cec0: cmp             x0, x17
    // 0xc1cec4: b.ne            #0xc1cf0c
    // 0xc1cec8: cmp             w6, NULL
    // 0xc1cecc: b.eq            #0xc1cfc8
    // 0xc1ced0: mov             x0, x6
    // 0xc1ced4: r2 = Null
    //     0xc1ced4: mov             x2, NULL
    // 0xc1ced8: r1 = Null
    //     0xc1ced8: mov             x1, NULL
    // 0xc1cedc: r4 = LoadClassIdInstr(r0)
    //     0xc1cedc: ldur            x4, [x0, #-1]
    //     0xc1cee0: ubfx            x4, x4, #0xc, #0x14
    // 0xc1cee4: r17 = 4659
    //     0xc1cee4: mov             x17, #0x1233
    // 0xc1cee8: cmp             x4, x17
    // 0xc1ceec: b.eq            #0xc1cf04
    // 0xc1cef0: r8 = ClipRectLayer
    //     0xc1cef0: add             x8, PP, #0xae, lsl #12  ; [pp+0xae190] Type: ClipRectLayer
    //     0xc1cef4: ldr             x8, [x8, #0x190]
    // 0xc1cef8: r3 = Null
    //     0xc1cef8: add             x3, PP, #0xae, lsl #12  ; [pp+0xae198] Null
    //     0xc1cefc: ldr             x3, [x3, #0x198]
    // 0xc1cf00: r0 = DefaultTypeTest()
    //     0xc1cf00: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc1cf04: ldur            x3, [fp, #-0x28]
    // 0xc1cf08: b               #0xc1cf10
    // 0xc1cf0c: r3 = Null
    //     0xc1cf0c: mov             x3, NULL
    // 0xc1cf10: ldur            x0, [fp, #-8]
    // 0xc1cf14: stur            x3, [fp, #-0x40]
    // 0xc1cf18: LoadField: r4 = r0->field_6b
    //     0xc1cf18: ldur            w4, [x0, #0x6b]
    // 0xc1cf1c: DecompressPointer r4
    //     0xc1cf1c: add             x4, x4, HEAP, lsl #32
    // 0xc1cf20: mov             x2, x0
    // 0xc1cf24: stur            x4, [fp, #-0x28]
    // 0xc1cf28: r1 = Function '_paintChildWithTransform@37160605':.
    //     0xc1cf28: add             x1, PP, #0xae, lsl #12  ; [pp+0xae1a8] AnonymousClosure: (0xc1d138), in [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform (0xc1cfcc)
    //     0xc1cf2c: ldr             x1, [x1, #0x1a8]
    // 0xc1cf30: r0 = AllocateClosure()
    //     0xc1cf30: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1cf34: ldur            x16, [fp, #-0x40]
    // 0xc1cf38: ldur            lr, [fp, #-0x28]
    // 0xc1cf3c: stp             lr, x16, [SP]
    // 0xc1cf40: ldur            x1, [fp, #-0x10]
    // 0xc1cf44: ldur            x2, [fp, #-0x20]
    // 0xc1cf48: ldur            x3, [fp, #-0x18]
    // 0xc1cf4c: ldur            x5, [fp, #-0x38]
    // 0xc1cf50: mov             x6, x0
    // 0xc1cf54: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x6, oldLayer, 0x5, null]
    //     0xc1cf54: add             x4, PP, #0xae, lsl #12  ; [pp+0xae1b0] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x6, "oldLayer", 0x5, Null]
    //     0xc1cf58: ldr             x4, [x4, #0x1b0]
    // 0xc1cf5c: r0 = pushClipRect()
    //     0xc1cf5c: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc1cf60: ldur            x1, [fp, #-0x30]
    // 0xc1cf64: mov             x2, x0
    // 0xc1cf68: r0 = layer=()
    //     0xc1cf68: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1cf6c: b               #0xc1cfa0
    // 0xc1cf70: mov             x1, x0
    // 0xc1cf74: ldur            x2, [fp, #-0x10]
    // 0xc1cf78: ldur            x3, [fp, #-0x18]
    // 0xc1cf7c: r0 = _paintChildWithTransform()
    //     0xc1cf7c: bl              #0xc1cfcc  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform
    // 0xc1cf80: mov             x1, x0
    // 0xc1cf84: ldur            x0, [fp, #-8]
    // 0xc1cf88: LoadField: r2 = r0->field_2f
    //     0xc1cf88: ldur            w2, [x0, #0x2f]
    // 0xc1cf8c: DecompressPointer r2
    //     0xc1cf8c: add             x2, x2, HEAP, lsl #32
    // 0xc1cf90: mov             x16, x1
    // 0xc1cf94: mov             x1, x2
    // 0xc1cf98: mov             x2, x16
    // 0xc1cf9c: r0 = layer=()
    //     0xc1cf9c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1cfa0: r0 = Null
    //     0xc1cfa0: mov             x0, NULL
    // 0xc1cfa4: LeaveFrame
    //     0xc1cfa4: mov             SP, fp
    //     0xc1cfa8: ldp             fp, lr, [SP], #0x10
    // 0xc1cfac: ret
    //     0xc1cfac: ret             
    // 0xc1cfb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1cfb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1cfb4: b               #0xc1cdb0
    // 0xc1cfb8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc1cfb8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc1cfbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1cfbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1cfc0: r9 = _needsCompositing
    //     0xc1cfc0: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1cfc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1cfc4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1cfc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1cfc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintChildWithTransform(/* No info */) {
    // ** addr: 0xc1cfcc, size: 0x16c
    // 0xc1cfcc: EnterFrame
    //     0xc1cfcc: stp             fp, lr, [SP, #-0x10]!
    //     0xc1cfd0: mov             fp, SP
    // 0xc1cfd4: AllocStack(0x30)
    //     0xc1cfd4: sub             SP, SP, #0x30
    // 0xc1cfd8: SetupParameters(RenderFittedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1cfd8: mov             x0, x2
    //     0xc1cfdc: stur            x2, [fp, #-0x10]
    //     0xc1cfe0: mov             x2, x1
    //     0xc1cfe4: stur            x1, [fp, #-8]
    //     0xc1cfe8: stur            x3, [fp, #-0x18]
    // 0xc1cfec: CheckStackOverflow
    //     0xc1cfec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1cff0: cmp             SP, x16
    //     0xc1cff4: b.ls            #0xc1d11c
    // 0xc1cff8: LoadField: r1 = r2->field_67
    //     0xc1cff8: ldur            w1, [x2, #0x67]
    // 0xc1cffc: DecompressPointer r1
    //     0xc1cffc: add             x1, x1, HEAP, lsl #32
    // 0xc1d000: cmp             w1, NULL
    // 0xc1d004: b.eq            #0xc1d124
    // 0xc1d008: r0 = getAsTranslation()
    //     0xc1d008: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xc1d00c: cmp             w0, NULL
    // 0xc1d010: b.ne            #0xc1d0f0
    // 0xc1d014: ldur            x3, [fp, #-8]
    // 0xc1d018: LoadField: r4 = r3->field_37
    //     0xc1d018: ldur            w4, [x3, #0x37]
    // 0xc1d01c: DecompressPointer r4
    //     0xc1d01c: add             x4, x4, HEAP, lsl #32
    // 0xc1d020: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1d024: cmp             w4, w16
    // 0xc1d028: b.eq            #0xc1d128
    // 0xc1d02c: stur            x4, [fp, #-0x30]
    // 0xc1d030: LoadField: r5 = r3->field_67
    //     0xc1d030: ldur            w5, [x3, #0x67]
    // 0xc1d034: DecompressPointer r5
    //     0xc1d034: add             x5, x5, HEAP, lsl #32
    // 0xc1d038: stur            x5, [fp, #-0x28]
    // 0xc1d03c: cmp             w5, NULL
    // 0xc1d040: b.eq            #0xc1d130
    // 0xc1d044: LoadField: r0 = r3->field_2f
    //     0xc1d044: ldur            w0, [x3, #0x2f]
    // 0xc1d048: DecompressPointer r0
    //     0xc1d048: add             x0, x0, HEAP, lsl #32
    // 0xc1d04c: LoadField: r6 = r0->field_b
    //     0xc1d04c: ldur            w6, [x0, #0xb]
    // 0xc1d050: DecompressPointer r6
    //     0xc1d050: add             x6, x6, HEAP, lsl #32
    // 0xc1d054: stur            x6, [fp, #-0x20]
    // 0xc1d058: r0 = LoadClassIdInstr(r6)
    //     0xc1d058: ldur            x0, [x6, #-1]
    //     0xc1d05c: ubfx            x0, x0, #0xc, #0x14
    // 0xc1d060: r17 = 4662
    //     0xc1d060: mov             x17, #0x1236
    // 0xc1d064: cmp             x0, x17
    // 0xc1d068: b.ne            #0xc1d0b0
    // 0xc1d06c: cmp             w6, NULL
    // 0xc1d070: b.eq            #0xc1d134
    // 0xc1d074: mov             x0, x6
    // 0xc1d078: r2 = Null
    //     0xc1d078: mov             x2, NULL
    // 0xc1d07c: r1 = Null
    //     0xc1d07c: mov             x1, NULL
    // 0xc1d080: r4 = LoadClassIdInstr(r0)
    //     0xc1d080: ldur            x4, [x0, #-1]
    //     0xc1d084: ubfx            x4, x4, #0xc, #0x14
    // 0xc1d088: r17 = 4662
    //     0xc1d088: mov             x17, #0x1236
    // 0xc1d08c: cmp             x4, x17
    // 0xc1d090: b.eq            #0xc1d0a8
    // 0xc1d094: r8 = TransformLayer
    //     0xc1d094: add             x8, PP, #0xae, lsl #12  ; [pp+0xae1b8] Type: TransformLayer
    //     0xc1d098: ldr             x8, [x8, #0x1b8]
    // 0xc1d09c: r3 = Null
    //     0xc1d09c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae1c0] Null
    //     0xc1d0a0: ldr             x3, [x3, #0x1c0]
    // 0xc1d0a4: r0 = DefaultTypeTest()
    //     0xc1d0a4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc1d0a8: ldur            x7, [fp, #-0x20]
    // 0xc1d0ac: b               #0xc1d0b4
    // 0xc1d0b0: r7 = Null
    //     0xc1d0b0: mov             x7, NULL
    // 0xc1d0b4: ldur            x2, [fp, #-8]
    // 0xc1d0b8: stur            x7, [fp, #-0x20]
    // 0xc1d0bc: r1 = Function 'paint':.
    //     0xc1d0bc: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1d0c0: ldr             x1, [x1, #0x4e0]
    // 0xc1d0c4: r0 = AllocateClosure()
    //     0xc1d0c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1d0c8: ldur            x1, [fp, #-0x10]
    // 0xc1d0cc: ldur            x2, [fp, #-0x30]
    // 0xc1d0d0: ldur            x3, [fp, #-0x18]
    // 0xc1d0d4: ldur            x5, [fp, #-0x28]
    // 0xc1d0d8: mov             x6, x0
    // 0xc1d0dc: ldur            x7, [fp, #-0x20]
    // 0xc1d0e0: r0 = pushTransform()
    //     0xc1d0e0: bl              #0xc1c818  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0xc1d0e4: LeaveFrame
    //     0xc1d0e4: mov             SP, fp
    //     0xc1d0e8: ldp             fp, lr, [SP], #0x10
    // 0xc1d0ec: ret
    //     0xc1d0ec: ret             
    // 0xc1d0f0: ldur            x1, [fp, #-0x18]
    // 0xc1d0f4: mov             x2, x0
    // 0xc1d0f8: r0 = +()
    //     0xc1d0f8: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc1d0fc: ldur            x1, [fp, #-8]
    // 0xc1d100: ldur            x2, [fp, #-0x10]
    // 0xc1d104: mov             x3, x0
    // 0xc1d108: r0 = paint()
    //     0xc1d108: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1d10c: r0 = Null
    //     0xc1d10c: mov             x0, NULL
    // 0xc1d110: LeaveFrame
    //     0xc1d110: mov             SP, fp
    //     0xc1d114: ldp             fp, lr, [SP], #0x10
    // 0xc1d118: ret
    //     0xc1d118: ret             
    // 0xc1d11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d11c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d120: b               #0xc1cff8
    // 0xc1d124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1d124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1d128: r9 = _needsCompositing
    //     0xc1d128: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1d12c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1d12c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1d130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1d130: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1d134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1d134: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] TransformLayer? _paintChildWithTransform(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc1d138, size: 0x40
    // 0xc1d138: EnterFrame
    //     0xc1d138: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d13c: mov             fp, SP
    // 0xc1d140: ldr             x0, [fp, #0x20]
    // 0xc1d144: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1d144: ldur            w1, [x0, #0x17]
    // 0xc1d148: DecompressPointer r1
    //     0xc1d148: add             x1, x1, HEAP, lsl #32
    // 0xc1d14c: CheckStackOverflow
    //     0xc1d14c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d150: cmp             SP, x16
    //     0xc1d154: b.ls            #0xc1d170
    // 0xc1d158: ldr             x2, [fp, #0x18]
    // 0xc1d15c: ldr             x3, [fp, #0x10]
    // 0xc1d160: r0 = _paintChildWithTransform()
    //     0xc1d160: bl              #0xc1cfcc  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform
    // 0xc1d164: LeaveFrame
    //     0xc1d164: mov             SP, fp
    //     0xc1d168: ldp             fp, lr, [SP], #0x10
    // 0xc1d16c: ret
    //     0xc1d16c: ret             
    // 0xc1d170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d170: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d174: b               #0xc1d158
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0xcf7568, size: 0x78
    // 0xcf7568: EnterFrame
    //     0xcf7568: stp             fp, lr, [SP, #-0x10]!
    //     0xcf756c: mov             fp, SP
    // 0xcf7570: AllocStack(0x8)
    //     0xcf7570: sub             SP, SP, #8
    // 0xcf7574: SetupParameters(RenderFittedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcf7574: mov             x0, x2
    //     0xcf7578: mov             x2, x1
    //     0xcf757c: stur            x1, [fp, #-8]
    // 0xcf7580: CheckStackOverflow
    //     0xcf7580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7584: cmp             SP, x16
    //     0xcf7588: b.ls            #0xcf75d8
    // 0xcf758c: LoadField: r1 = r2->field_6b
    //     0xcf758c: ldur            w1, [x2, #0x6b]
    // 0xcf7590: DecompressPointer r1
    //     0xcf7590: add             x1, x1, HEAP, lsl #32
    // 0xcf7594: cmp             w0, w1
    // 0xcf7598: b.eq            #0xcf75c8
    // 0xcf759c: StoreField: r2->field_6b = r0
    //     0xcf759c: stur            w0, [x2, #0x6b]
    //     0xcf75a0: ldurb           w16, [x2, #-1]
    //     0xcf75a4: ldurb           w17, [x0, #-1]
    //     0xcf75a8: and             x16, x17, x16, lsr #2
    //     0xcf75ac: tst             x16, HEAP, lsr #32
    //     0xcf75b0: b.eq            #0xcf75b8
    //     0xcf75b4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf75b8: mov             x1, x2
    // 0xcf75bc: r0 = markNeedsPaint()
    //     0xcf75bc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf75c0: ldur            x1, [fp, #-8]
    // 0xcf75c4: r0 = markNeedsSemanticsUpdate()
    //     0xcf75c4: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf75c8: r0 = Null
    //     0xcf75c8: mov             x0, NULL
    // 0xcf75cc: LeaveFrame
    //     0xcf75cc: mov             SP, fp
    //     0xcf75d0: ldp             fp, lr, [SP], #0x10
    // 0xcf75d4: ret
    //     0xcf75d4: ret             
    // 0xcf75d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf75d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf75dc: b               #0xcf758c
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf75e0, size: 0x88
    // 0xcf75e0: EnterFrame
    //     0xcf75e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf75e4: mov             fp, SP
    // 0xcf75e8: AllocStack(0x8)
    //     0xcf75e8: sub             SP, SP, #8
    // 0xcf75ec: SetupParameters(RenderFittedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcf75ec: mov             x0, x2
    //     0xcf75f0: mov             x2, x1
    //     0xcf75f4: stur            x1, [fp, #-8]
    // 0xcf75f8: CheckStackOverflow
    //     0xcf75f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf75fc: cmp             SP, x16
    //     0xcf7600: b.ls            #0xcf7660
    // 0xcf7604: LoadField: r1 = r2->field_5f
    //     0xcf7604: ldur            w1, [x2, #0x5f]
    // 0xcf7608: DecompressPointer r1
    //     0xcf7608: add             x1, x1, HEAP, lsl #32
    // 0xcf760c: cmp             w1, w0
    // 0xcf7610: b.ne            #0xcf7624
    // 0xcf7614: r0 = Null
    //     0xcf7614: mov             x0, NULL
    // 0xcf7618: LeaveFrame
    //     0xcf7618: mov             SP, fp
    //     0xcf761c: ldp             fp, lr, [SP], #0x10
    // 0xcf7620: ret
    //     0xcf7620: ret             
    // 0xcf7624: StoreField: r2->field_5f = r0
    //     0xcf7624: stur            w0, [x2, #0x5f]
    //     0xcf7628: ldurb           w16, [x2, #-1]
    //     0xcf762c: ldurb           w17, [x0, #-1]
    //     0xcf7630: and             x16, x17, x16, lsr #2
    //     0xcf7634: tst             x16, HEAP, lsr #32
    //     0xcf7638: b.eq            #0xcf7640
    //     0xcf763c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf7640: mov             x1, x2
    // 0xcf7644: r0 = _clearPaintData()
    //     0xcf7644: bl              #0xbb98b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0xcf7648: ldur            x1, [fp, #-8]
    // 0xcf764c: r0 = _markNeedResolution()
    //     0xcf764c: bl              #0xcf7668  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_markNeedResolution
    // 0xcf7650: r0 = Null
    //     0xcf7650: mov             x0, NULL
    // 0xcf7654: LeaveFrame
    //     0xcf7654: mov             SP, fp
    //     0xcf7658: ldp             fp, lr, [SP], #0x10
    // 0xcf765c: ret
    //     0xcf765c: ret             
    // 0xcf7660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7664: b               #0xcf7604
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0xcf7668, size: 0x34
    // 0xcf7668: EnterFrame
    //     0xcf7668: stp             fp, lr, [SP, #-0x10]!
    //     0xcf766c: mov             fp, SP
    // 0xcf7670: CheckStackOverflow
    //     0xcf7670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7674: cmp             SP, x16
    //     0xcf7678: b.ls            #0xcf7694
    // 0xcf767c: StoreField: r1->field_53 = rNULL
    //     0xcf767c: stur            NULL, [x1, #0x53]
    // 0xcf7680: r0 = markNeedsPaint()
    //     0xcf7680: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf7684: r0 = Null
    //     0xcf7684: mov             x0, NULL
    // 0xcf7688: LeaveFrame
    //     0xcf7688: mov             SP, fp
    //     0xcf768c: ldp             fp, lr, [SP], #0x10
    // 0xcf7690: ret
    //     0xcf7690: ret             
    // 0xcf7694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7694: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7698: b               #0xcf767c
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0xcf769c, size: 0x80
    // 0xcf769c: EnterFrame
    //     0xcf769c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf76a0: mov             fp, SP
    // 0xcf76a4: AllocStack(0x18)
    //     0xcf76a4: sub             SP, SP, #0x18
    // 0xcf76a8: SetupParameters(RenderFittedBox this /* r1 => r1, fp-0x8 */)
    //     0xcf76a8: stur            x1, [fp, #-8]
    // 0xcf76ac: CheckStackOverflow
    //     0xcf76ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf76b0: cmp             SP, x16
    //     0xcf76b4: b.ls            #0xcf7714
    // 0xcf76b8: r16 = Instance_Alignment
    //     0xcf76b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xcf76bc: ldr             x16, [x16, #0xb80]
    // 0xcf76c0: r30 = Instance_Alignment
    //     0xcf76c0: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xcf76c4: ldr             lr, [lr, #0xb80]
    // 0xcf76c8: stp             lr, x16, [SP]
    // 0xcf76cc: r0 = ==()
    //     0xcf76cc: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xcf76d0: tbnz            w0, #4, #0xcf76e4
    // 0xcf76d4: r0 = Null
    //     0xcf76d4: mov             x0, NULL
    // 0xcf76d8: LeaveFrame
    //     0xcf76d8: mov             SP, fp
    //     0xcf76dc: ldp             fp, lr, [SP], #0x10
    // 0xcf76e0: ret
    //     0xcf76e0: ret             
    // 0xcf76e4: ldur            x0, [fp, #-8]
    // 0xcf76e8: r1 = Instance_Alignment
    //     0xcf76e8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xcf76ec: ldr             x1, [x1, #0xb80]
    // 0xcf76f0: StoreField: r0->field_5b = r1
    //     0xcf76f0: stur            w1, [x0, #0x5b]
    // 0xcf76f4: mov             x1, x0
    // 0xcf76f8: r0 = _clearPaintData()
    //     0xcf76f8: bl              #0xbb98b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0xcf76fc: ldur            x1, [fp, #-8]
    // 0xcf7700: r0 = _markNeedResolution()
    //     0xcf7700: bl              #0xcf7668  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_markNeedResolution
    // 0xcf7704: r0 = Null
    //     0xcf7704: mov             x0, NULL
    // 0xcf7708: LeaveFrame
    //     0xcf7708: mov             SP, fp
    //     0xcf770c: ldp             fp, lr, [SP], #0x10
    // 0xcf7710: ret
    //     0xcf7710: ret             
    // 0xcf7714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7718: b               #0xcf76b8
  }
  set _ fit=(/* No info */) {
    // ** addr: 0xcf771c, size: 0xc4
    // 0xcf771c: EnterFrame
    //     0xcf771c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7720: mov             fp, SP
    // 0xcf7724: AllocStack(0x8)
    //     0xcf7724: sub             SP, SP, #8
    // 0xcf7728: SetupParameters(RenderFittedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xcf7728: stur            x1, [fp, #-8]
    //     0xcf772c: mov             x16, x2
    //     0xcf7730: mov             x2, x1
    //     0xcf7734: mov             x1, x16
    // 0xcf7738: CheckStackOverflow
    //     0xcf7738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf773c: cmp             SP, x16
    //     0xcf7740: b.ls            #0xcf77d8
    // 0xcf7744: LoadField: r3 = r2->field_57
    //     0xcf7744: ldur            w3, [x2, #0x57]
    // 0xcf7748: DecompressPointer r3
    //     0xcf7748: add             x3, x3, HEAP, lsl #32
    // 0xcf774c: cmp             w3, w1
    // 0xcf7750: b.ne            #0xcf7764
    // 0xcf7754: r0 = Null
    //     0xcf7754: mov             x0, NULL
    // 0xcf7758: LeaveFrame
    //     0xcf7758: mov             SP, fp
    //     0xcf775c: ldp             fp, lr, [SP], #0x10
    // 0xcf7760: ret
    //     0xcf7760: ret             
    // 0xcf7764: mov             x0, x1
    // 0xcf7768: StoreField: r2->field_57 = r0
    //     0xcf7768: stur            w0, [x2, #0x57]
    //     0xcf776c: ldurb           w16, [x2, #-1]
    //     0xcf7770: ldurb           w17, [x0, #-1]
    //     0xcf7774: and             x16, x17, x16, lsr #2
    //     0xcf7778: tst             x16, HEAP, lsr #32
    //     0xcf777c: b.eq            #0xcf7784
    //     0xcf7780: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf7784: LoadField: r0 = r3->field_7
    //     0xcf7784: ldur            x0, [x3, #7]
    // 0xcf7788: cmp             x0, #3
    // 0xcf778c: b.le            #0xcf7798
    // 0xcf7790: cmp             x0, #5
    // 0xcf7794: b.gt            #0xcf77c0
    // 0xcf7798: LoadField: r0 = r1->field_7
    //     0xcf7798: ldur            x0, [x1, #7]
    // 0xcf779c: cmp             x0, #3
    // 0xcf77a0: b.le            #0xcf77ac
    // 0xcf77a4: cmp             x0, #5
    // 0xcf77a8: b.gt            #0xcf77c0
    // 0xcf77ac: mov             x1, x2
    // 0xcf77b0: r0 = _clearPaintData()
    //     0xcf77b0: bl              #0xbb98b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0xcf77b4: ldur            x1, [fp, #-8]
    // 0xcf77b8: r0 = markNeedsPaint()
    //     0xcf77b8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf77bc: b               #0xcf77c8
    // 0xcf77c0: ldur            x1, [fp, #-8]
    // 0xcf77c4: r0 = markNeedsLayout()
    //     0xcf77c4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf77c8: r0 = Null
    //     0xcf77c8: mov             x0, NULL
    // 0xcf77cc: LeaveFrame
    //     0xcf77cc: mov             SP, fp
    //     0xcf77d0: ldp             fp, lr, [SP], #0x10
    // 0xcf77d4: ret
    //     0xcf77d4: ret             
    // 0xcf77d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf77d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf77dc: b               #0xcf7744
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e9628, size: 0x124
    // 0x10e9628: EnterFrame
    //     0x10e9628: stp             fp, lr, [SP, #-0x10]!
    //     0x10e962c: mov             fp, SP
    // 0x10e9630: AllocStack(0x28)
    //     0x10e9630: sub             SP, SP, #0x28
    // 0x10e9634: SetupParameters(RenderFittedBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10e9634: mov             x0, x1
    //     0x10e9638: stur            x1, [fp, #-8]
    //     0x10e963c: mov             x1, x2
    //     0x10e9640: stur            x2, [fp, #-0x10]
    //     0x10e9644: stur            x3, [fp, #-0x18]
    // 0x10e9648: CheckStackOverflow
    //     0x10e9648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e964c: cmp             SP, x16
    //     0x10e9650: b.ls            #0x10e9744
    // 0x10e9654: r1 = 1
    //     0x10e9654: mov             x1, #1
    // 0x10e9658: r0 = AllocateContext()
    //     0x10e9658: bl              #0x13de838  ; AllocateContextStub
    // 0x10e965c: mov             x2, x0
    // 0x10e9660: ldur            x0, [fp, #-8]
    // 0x10e9664: stur            x2, [fp, #-0x20]
    // 0x10e9668: StoreField: r2->field_f = r0
    //     0x10e9668: stur            w0, [x2, #0xf]
    // 0x10e966c: mov             x1, x0
    // 0x10e9670: r0 = size()
    //     0x10e9670: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e9674: LoadField: d0 = r0->field_7
    //     0x10e9674: ldur            d0, [x0, #7]
    // 0x10e9678: d1 = 0.000000
    //     0x10e9678: eor             v1.16b, v1.16b, v1.16b
    // 0x10e967c: fcmp            d1, d0
    // 0x10e9680: b.ge            #0x10e96e8
    // 0x10e9684: LoadField: d0 = r0->field_f
    //     0x10e9684: ldur            d0, [x0, #0xf]
    // 0x10e9688: fcmp            d1, d0
    // 0x10e968c: b.ge            #0x10e96e8
    // 0x10e9690: ldur            x0, [fp, #-8]
    // 0x10e9694: LoadField: r1 = r0->field_4f
    //     0x10e9694: ldur            w1, [x0, #0x4f]
    // 0x10e9698: DecompressPointer r1
    //     0x10e9698: add             x1, x1, HEAP, lsl #32
    // 0x10e969c: cmp             w1, NULL
    // 0x10e96a0: b.ne            #0x10e96ac
    // 0x10e96a4: r0 = Null
    //     0x10e96a4: mov             x0, NULL
    // 0x10e96a8: b               #0x10e96dc
    // 0x10e96ac: r0 = size()
    //     0x10e96ac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e96b0: LoadField: d0 = r0->field_7
    //     0x10e96b0: ldur            d0, [x0, #7]
    // 0x10e96b4: d1 = 0.000000
    //     0x10e96b4: eor             v1.16b, v1.16b, v1.16b
    // 0x10e96b8: fcmp            d1, d0
    // 0x10e96bc: b.lt            #0x10e96c8
    // 0x10e96c0: r0 = true
    //     0x10e96c0: add             x0, NULL, #0x20  ; true
    // 0x10e96c4: b               #0x10e96dc
    // 0x10e96c8: LoadField: d0 = r0->field_f
    //     0x10e96c8: ldur            d0, [x0, #0xf]
    // 0x10e96cc: fcmp            d1, d0
    // 0x10e96d0: r16 = true
    //     0x10e96d0: add             x16, NULL, #0x20  ; true
    // 0x10e96d4: r17 = false
    //     0x10e96d4: add             x17, NULL, #0x30  ; false
    // 0x10e96d8: csel            x0, x16, x17, ge
    // 0x10e96dc: cmp             w0, NULL
    // 0x10e96e0: b.eq            #0x10e96f8
    // 0x10e96e4: tbnz            w0, #4, #0x10e96f8
    // 0x10e96e8: r0 = false
    //     0x10e96e8: add             x0, NULL, #0x30  ; false
    // 0x10e96ec: LeaveFrame
    //     0x10e96ec: mov             SP, fp
    //     0x10e96f0: ldp             fp, lr, [SP], #0x10
    // 0x10e96f4: ret
    //     0x10e96f4: ret             
    // 0x10e96f8: ldur            x0, [fp, #-8]
    // 0x10e96fc: mov             x1, x0
    // 0x10e9700: r0 = _updatePaintData()
    //     0x10e9700: bl              #0xbf0f28  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0x10e9704: ldur            x0, [fp, #-8]
    // 0x10e9708: LoadField: r5 = r0->field_67
    //     0x10e9708: ldur            w5, [x0, #0x67]
    // 0x10e970c: DecompressPointer r5
    //     0x10e970c: add             x5, x5, HEAP, lsl #32
    // 0x10e9710: ldur            x2, [fp, #-0x20]
    // 0x10e9714: stur            x5, [fp, #-0x28]
    // 0x10e9718: r1 = Function '<anonymous closure>':.
    //     0x10e9718: add             x1, PP, #0xae, lsl #12  ; [pp+0xae188] AnonymousClosure: (0x10e95dc), in [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren (0x10e984c)
    //     0x10e971c: ldr             x1, [x1, #0x188]
    // 0x10e9720: r0 = AllocateClosure()
    //     0x10e9720: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e9724: ldur            x1, [fp, #-0x10]
    // 0x10e9728: mov             x2, x0
    // 0x10e972c: ldur            x3, [fp, #-0x18]
    // 0x10e9730: ldur            x5, [fp, #-0x28]
    // 0x10e9734: r0 = addWithPaintTransform()
    //     0x10e9734: bl              #0x10e8cac  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x10e9738: LeaveFrame
    //     0x10e9738: mov             SP, fp
    //     0x10e973c: ldp             fp, lr, [SP], #0x10
    // 0x10e9740: ret
    //     0x10e9740: ret             
    // 0x10e9744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9744: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9748: b               #0x10e9654
  }
  _ RenderFittedBox(/* No info */) {
    // ** addr: 0x11d0fec, size: 0xe0
    // 0x11d0fec: EnterFrame
    //     0x11d0fec: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0ff0: mov             fp, SP
    // 0x11d0ff4: AllocStack(0x8)
    //     0x11d0ff4: sub             SP, SP, #8
    // 0x11d0ff8: r4 = Instance_Alignment
    //     0x11d0ff8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x11d0ffc: ldr             x4, [x4, #0xb80]
    // 0x11d1000: mov             x0, x3
    // 0x11d1004: mov             x3, x1
    // 0x11d1008: stur            x1, [fp, #-8]
    // 0x11d100c: mov             x1, x5
    // 0x11d1010: CheckStackOverflow
    //     0x11d1010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1014: cmp             SP, x16
    //     0x11d1018: b.ls            #0x11d10c4
    // 0x11d101c: StoreField: r3->field_57 = r0
    //     0x11d101c: stur            w0, [x3, #0x57]
    //     0x11d1020: ldurb           w16, [x3, #-1]
    //     0x11d1024: ldurb           w17, [x0, #-1]
    //     0x11d1028: and             x16, x17, x16, lsr #2
    //     0x11d102c: tst             x16, HEAP, lsr #32
    //     0x11d1030: b.eq            #0x11d1038
    //     0x11d1034: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d1038: StoreField: r3->field_5b = r4
    //     0x11d1038: stur            w4, [x3, #0x5b]
    // 0x11d103c: mov             x0, x1
    // 0x11d1040: StoreField: r3->field_5f = r0
    //     0x11d1040: stur            w0, [x3, #0x5f]
    //     0x11d1044: ldurb           w16, [x3, #-1]
    //     0x11d1048: ldurb           w17, [x0, #-1]
    //     0x11d104c: and             x16, x17, x16, lsr #2
    //     0x11d1050: tst             x16, HEAP, lsr #32
    //     0x11d1054: b.eq            #0x11d105c
    //     0x11d1058: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d105c: mov             x0, x2
    // 0x11d1060: StoreField: r3->field_6b = r0
    //     0x11d1060: stur            w0, [x3, #0x6b]
    //     0x11d1064: ldurb           w16, [x3, #-1]
    //     0x11d1068: ldurb           w17, [x0, #-1]
    //     0x11d106c: and             x16, x17, x16, lsr #2
    //     0x11d1070: tst             x16, HEAP, lsr #32
    //     0x11d1074: b.eq            #0x11d107c
    //     0x11d1078: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d107c: r0 = _LayoutCacheStorage()
    //     0x11d107c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1080: ldur            x2, [fp, #-8]
    // 0x11d1084: StoreField: r2->field_47 = r0
    //     0x11d1084: stur            w0, [x2, #0x47]
    //     0x11d1088: ldurb           w16, [x2, #-1]
    //     0x11d108c: ldurb           w17, [x0, #-1]
    //     0x11d1090: and             x16, x17, x16, lsr #2
    //     0x11d1094: tst             x16, HEAP, lsr #32
    //     0x11d1098: b.eq            #0x11d10a0
    //     0x11d109c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d10a0: mov             x1, x2
    // 0x11d10a4: r0 = RenderObject()
    //     0x11d10a4: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d10a8: ldur            x1, [fp, #-8]
    // 0x11d10ac: r2 = Null
    //     0x11d10ac: mov             x2, NULL
    // 0x11d10b0: r0 = child=()
    //     0x11d10b0: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d10b4: r0 = Null
    //     0x11d10b4: mov             x0, NULL
    // 0x11d10b8: LeaveFrame
    //     0x11d10b8: mov             SP, fp
    //     0x11d10bc: ldp             fp, lr, [SP], #0x10
    // 0x11d10c0: ret
    //     0x11d10c0: ret             
    // 0x11d10c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d10c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d10c8: b               #0x11d101c
  }
}

// class id: 4927, size: 0x6c, field offset: 0x54
class RenderTransform extends RenderProxyBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf9328, size: 0x2c
    // 0xaf9328: EnterFrame
    //     0xaf9328: stp             fp, lr, [SP, #-0x10]!
    //     0xaf932c: mov             fp, SP
    // 0xaf9330: CheckStackOverflow
    //     0xaf9330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9334: cmp             SP, x16
    //     0xaf9338: b.ls            #0xaf934c
    // 0xaf933c: r0 = hitTestChildren()
    //     0xaf933c: bl              #0x10e8c14  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren
    // 0xaf9340: LeaveFrame
    //     0xaf9340: mov             SP, fp
    //     0xaf9344: ldp             fp, lr, [SP], #0x10
    // 0xaf9348: ret
    //     0xaf9348: ret             
    // 0xaf934c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf934c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9350: b               #0xaf933c
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf0b24, size: 0x98
    // 0xbf0b24: EnterFrame
    //     0xbf0b24: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0b28: mov             fp, SP
    // 0xbf0b2c: AllocStack(0x10)
    //     0xbf0b2c: sub             SP, SP, #0x10
    // 0xbf0b30: SetupParameters(RenderTransform this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf0b30: mov             x4, x1
    //     0xbf0b34: mov             x0, x2
    //     0xbf0b38: stur            x1, [fp, #-8]
    //     0xbf0b3c: stur            x3, [fp, #-0x10]
    // 0xbf0b40: CheckStackOverflow
    //     0xbf0b40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0b44: cmp             SP, x16
    //     0xbf0b48: b.ls            #0xbf0bb0
    // 0xbf0b4c: r2 = Null
    //     0xbf0b4c: mov             x2, NULL
    // 0xbf0b50: r1 = Null
    //     0xbf0b50: mov             x1, NULL
    // 0xbf0b54: r4 = 60
    //     0xbf0b54: mov             x4, #0x3c
    // 0xbf0b58: branchIfSmi(r0, 0xbf0b64)
    //     0xbf0b58: tbz             w0, #0, #0xbf0b64
    // 0xbf0b5c: r4 = LoadClassIdInstr(r0)
    //     0xbf0b5c: ldur            x4, [x0, #-1]
    //     0xbf0b60: ubfx            x4, x4, #0xc, #0x14
    // 0xbf0b64: r17 = -4710
    //     0xbf0b64: mov             x17, #-0x1266
    // 0xbf0b68: add             x4, x4, x17
    // 0xbf0b6c: cmp             x4, #0x109
    // 0xbf0b70: b.ls            #0xbf0b84
    // 0xbf0b74: r8 = RenderBox
    //     0xbf0b74: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf0b78: r3 = Null
    //     0xbf0b78: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a6a0] Null
    //     0xbf0b7c: ldr             x3, [x3, #0x6a0]
    // 0xbf0b80: r0 = RenderBox()
    //     0xbf0b80: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf0b84: ldur            x1, [fp, #-8]
    // 0xbf0b88: r0 = _effectiveTransform()
    //     0xbf0b88: bl              #0xbf0bbc  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0xbf0b8c: cmp             w0, NULL
    // 0xbf0b90: b.eq            #0xbf0bb8
    // 0xbf0b94: ldur            x1, [fp, #-0x10]
    // 0xbf0b98: mov             x2, x0
    // 0xbf0b9c: r0 = multiply()
    //     0xbf0b9c: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf0ba0: r0 = Null
    //     0xbf0ba0: mov             x0, NULL
    // 0xbf0ba4: LeaveFrame
    //     0xbf0ba4: mov             SP, fp
    //     0xbf0ba8: ldp             fp, lr, [SP], #0x10
    // 0xbf0bac: ret
    //     0xbf0bac: ret             
    // 0xbf0bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0bb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0bb4: b               #0xbf0b4c
    // 0xbf0bb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0bb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveTransform(/* No info */) {
    // ** addr: 0xbf0bbc, size: 0x2a4
    // 0xbf0bbc: EnterFrame
    //     0xbf0bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0bc0: mov             fp, SP
    // 0xbf0bc4: AllocStack(0x30)
    //     0xbf0bc4: sub             SP, SP, #0x30
    // 0xbf0bc8: SetupParameters(RenderTransform this /* r1 => r1, fp-0x8 */)
    //     0xbf0bc8: stur            x1, [fp, #-8]
    // 0xbf0bcc: CheckStackOverflow
    //     0xbf0bcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0bd0: cmp             SP, x16
    //     0xbf0bd4: b.ls            #0xbf0e48
    // 0xbf0bd8: LoadField: r0 = r1->field_57
    //     0xbf0bd8: ldur            w0, [x1, #0x57]
    // 0xbf0bdc: DecompressPointer r0
    //     0xbf0bdc: add             x0, x0, HEAP, lsl #32
    // 0xbf0be0: cmp             w0, NULL
    // 0xbf0be4: b.ne            #0xbf0bf0
    // 0xbf0be8: r0 = Null
    //     0xbf0be8: mov             x0, NULL
    // 0xbf0bec: b               #0xbf0cf0
    // 0xbf0bf0: LoadField: r2 = r1->field_5b
    //     0xbf0bf0: ldur            w2, [x1, #0x5b]
    // 0xbf0bf4: DecompressPointer r2
    //     0xbf0bf4: add             x2, x2, HEAP, lsl #32
    // 0xbf0bf8: r3 = LoadClassIdInstr(r0)
    //     0xbf0bf8: ldur            x3, [x0, #-1]
    //     0xbf0bfc: ubfx            x3, x3, #0xc, #0x14
    // 0xbf0c00: sub             x16, x3, #0xb8e
    // 0xbf0c04: cmp             x16, #1
    // 0xbf0c08: b.ls            #0xbf0cec
    // 0xbf0c0c: cmp             x3, #0xb8c
    // 0xbf0c10: b.ne            #0xbf0c88
    // 0xbf0c14: cmp             w2, NULL
    // 0xbf0c18: b.eq            #0xbf0e50
    // 0xbf0c1c: LoadField: r3 = r2->field_7
    //     0xbf0c1c: ldur            x3, [x2, #7]
    // 0xbf0c20: cmp             x3, #0
    // 0xbf0c24: b.gt            #0xbf0c58
    // 0xbf0c28: LoadField: d0 = r0->field_7
    //     0xbf0c28: ldur            d0, [x0, #7]
    // 0xbf0c2c: LoadField: d1 = r0->field_f
    //     0xbf0c2c: ldur            d1, [x0, #0xf]
    // 0xbf0c30: fsub            d2, d0, d1
    // 0xbf0c34: stur            d2, [fp, #-0x30]
    // 0xbf0c38: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbf0c38: ldur            d0, [x0, #0x17]
    // 0xbf0c3c: stur            d0, [fp, #-0x28]
    // 0xbf0c40: r0 = Alignment()
    //     0xbf0c40: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbf0c44: ldur            d0, [fp, #-0x30]
    // 0xbf0c48: StoreField: r0->field_7 = d0
    //     0xbf0c48: stur            d0, [x0, #7]
    // 0xbf0c4c: ldur            d0, [fp, #-0x28]
    // 0xbf0c50: StoreField: r0->field_f = d0
    //     0xbf0c50: stur            d0, [x0, #0xf]
    // 0xbf0c54: b               #0xbf0cec
    // 0xbf0c58: LoadField: d0 = r0->field_7
    //     0xbf0c58: ldur            d0, [x0, #7]
    // 0xbf0c5c: LoadField: d1 = r0->field_f
    //     0xbf0c5c: ldur            d1, [x0, #0xf]
    // 0xbf0c60: fadd            d2, d0, d1
    // 0xbf0c64: stur            d2, [fp, #-0x30]
    // 0xbf0c68: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbf0c68: ldur            d0, [x0, #0x17]
    // 0xbf0c6c: stur            d0, [fp, #-0x28]
    // 0xbf0c70: r0 = Alignment()
    //     0xbf0c70: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbf0c74: ldur            d0, [fp, #-0x30]
    // 0xbf0c78: StoreField: r0->field_7 = d0
    //     0xbf0c78: stur            d0, [x0, #7]
    // 0xbf0c7c: ldur            d0, [fp, #-0x28]
    // 0xbf0c80: StoreField: r0->field_f = d0
    //     0xbf0c80: stur            d0, [x0, #0xf]
    // 0xbf0c84: b               #0xbf0cec
    // 0xbf0c88: cmp             w2, NULL
    // 0xbf0c8c: b.eq            #0xbf0e54
    // 0xbf0c90: LoadField: r1 = r2->field_7
    //     0xbf0c90: ldur            x1, [x2, #7]
    // 0xbf0c94: cmp             x1, #0
    // 0xbf0c98: b.gt            #0xbf0cc8
    // 0xbf0c9c: LoadField: d0 = r0->field_7
    //     0xbf0c9c: ldur            d0, [x0, #7]
    // 0xbf0ca0: fneg            d1, d0
    // 0xbf0ca4: stur            d1, [fp, #-0x30]
    // 0xbf0ca8: LoadField: d0 = r0->field_f
    //     0xbf0ca8: ldur            d0, [x0, #0xf]
    // 0xbf0cac: stur            d0, [fp, #-0x28]
    // 0xbf0cb0: r0 = Alignment()
    //     0xbf0cb0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbf0cb4: ldur            d0, [fp, #-0x30]
    // 0xbf0cb8: StoreField: r0->field_7 = d0
    //     0xbf0cb8: stur            d0, [x0, #7]
    // 0xbf0cbc: ldur            d0, [fp, #-0x28]
    // 0xbf0cc0: StoreField: r0->field_f = d0
    //     0xbf0cc0: stur            d0, [x0, #0xf]
    // 0xbf0cc4: b               #0xbf0cec
    // 0xbf0cc8: LoadField: d0 = r0->field_7
    //     0xbf0cc8: ldur            d0, [x0, #7]
    // 0xbf0ccc: stur            d0, [fp, #-0x30]
    // 0xbf0cd0: LoadField: d1 = r0->field_f
    //     0xbf0cd0: ldur            d1, [x0, #0xf]
    // 0xbf0cd4: stur            d1, [fp, #-0x28]
    // 0xbf0cd8: r0 = Alignment()
    //     0xbf0cd8: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbf0cdc: ldur            d0, [fp, #-0x30]
    // 0xbf0ce0: StoreField: r0->field_7 = d0
    //     0xbf0ce0: stur            d0, [x0, #7]
    // 0xbf0ce4: ldur            d0, [fp, #-0x28]
    // 0xbf0ce8: StoreField: r0->field_f = d0
    //     0xbf0ce8: stur            d0, [x0, #0xf]
    // 0xbf0cec: ldur            x1, [fp, #-8]
    // 0xbf0cf0: stur            x0, [fp, #-0x10]
    // 0xbf0cf4: LoadField: r2 = r1->field_53
    //     0xbf0cf4: ldur            w2, [x1, #0x53]
    // 0xbf0cf8: DecompressPointer r2
    //     0xbf0cf8: add             x2, x2, HEAP, lsl #32
    // 0xbf0cfc: cmp             w2, NULL
    // 0xbf0d00: b.ne            #0xbf0d20
    // 0xbf0d04: cmp             w0, NULL
    // 0xbf0d08: b.ne            #0xbf0d20
    // 0xbf0d0c: LoadField: r0 = r1->field_63
    //     0xbf0d0c: ldur            w0, [x1, #0x63]
    // 0xbf0d10: DecompressPointer r0
    //     0xbf0d10: add             x0, x0, HEAP, lsl #32
    // 0xbf0d14: LeaveFrame
    //     0xbf0d14: mov             SP, fp
    //     0xbf0d18: ldp             fp, lr, [SP], #0x10
    // 0xbf0d1c: ret
    //     0xbf0d1c: ret             
    // 0xbf0d20: r0 = Matrix4()
    //     0xbf0d20: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xbf0d24: r4 = 32
    //     0xbf0d24: mov             x4, #0x20
    // 0xbf0d28: stur            x0, [fp, #-0x18]
    // 0xbf0d2c: r0 = AllocateFloat64Array()
    //     0xbf0d2c: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xbf0d30: mov             x1, x0
    // 0xbf0d34: ldur            x0, [fp, #-0x18]
    // 0xbf0d38: StoreField: r0->field_7 = r1
    //     0xbf0d38: stur            w1, [x0, #7]
    // 0xbf0d3c: mov             x1, x0
    // 0xbf0d40: r0 = setIdentity()
    //     0xbf0d40: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xbf0d44: ldur            x0, [fp, #-8]
    // 0xbf0d48: LoadField: r1 = r0->field_53
    //     0xbf0d48: ldur            w1, [x0, #0x53]
    // 0xbf0d4c: DecompressPointer r1
    //     0xbf0d4c: add             x1, x1, HEAP, lsl #32
    // 0xbf0d50: cmp             w1, NULL
    // 0xbf0d54: b.eq            #0xbf0d68
    // 0xbf0d58: LoadField: d0 = r1->field_7
    //     0xbf0d58: ldur            d0, [x1, #7]
    // 0xbf0d5c: LoadField: d1 = r1->field_f
    //     0xbf0d5c: ldur            d1, [x1, #0xf]
    // 0xbf0d60: ldur            x1, [fp, #-0x18]
    // 0xbf0d64: r0 = translateByDouble()
    //     0xbf0d64: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf0d68: ldur            x0, [fp, #-0x10]
    // 0xbf0d6c: cmp             w0, NULL
    // 0xbf0d70: b.eq            #0xbf0da4
    // 0xbf0d74: ldur            x1, [fp, #-8]
    // 0xbf0d78: r0 = size()
    //     0xbf0d78: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf0d7c: ldur            x1, [fp, #-0x10]
    // 0xbf0d80: mov             x2, x0
    // 0xbf0d84: r0 = alongOffset()
    //     0xbf0d84: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbf0d88: stur            x0, [fp, #-0x20]
    // 0xbf0d8c: LoadField: d0 = r0->field_7
    //     0xbf0d8c: ldur            d0, [x0, #7]
    // 0xbf0d90: LoadField: d1 = r0->field_f
    //     0xbf0d90: ldur            d1, [x0, #0xf]
    // 0xbf0d94: ldur            x1, [fp, #-0x18]
    // 0xbf0d98: r0 = translateByDouble()
    //     0xbf0d98: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf0d9c: ldur            x4, [fp, #-0x20]
    // 0xbf0da0: b               #0xbf0da8
    // 0xbf0da4: r4 = Null
    //     0xbf0da4: mov             x4, NULL
    // 0xbf0da8: ldur            x3, [fp, #-8]
    // 0xbf0dac: ldur            x0, [fp, #-0x10]
    // 0xbf0db0: stur            x4, [fp, #-0x20]
    // 0xbf0db4: LoadField: r2 = r3->field_63
    //     0xbf0db4: ldur            w2, [x3, #0x63]
    // 0xbf0db8: DecompressPointer r2
    //     0xbf0db8: add             x2, x2, HEAP, lsl #32
    // 0xbf0dbc: cmp             w2, NULL
    // 0xbf0dc0: b.eq            #0xbf0e58
    // 0xbf0dc4: ldur            x1, [fp, #-0x18]
    // 0xbf0dc8: r0 = multiply()
    //     0xbf0dc8: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf0dcc: ldur            x0, [fp, #-0x10]
    // 0xbf0dd0: cmp             w0, NULL
    // 0xbf0dd4: b.eq            #0xbf0e04
    // 0xbf0dd8: ldur            x0, [fp, #-0x20]
    // 0xbf0ddc: cmp             w0, NULL
    // 0xbf0de0: b.eq            #0xbf0e5c
    // 0xbf0de4: LoadField: d0 = r0->field_7
    //     0xbf0de4: ldur            d0, [x0, #7]
    // 0xbf0de8: fneg            d1, d0
    // 0xbf0dec: LoadField: d0 = r0->field_f
    //     0xbf0dec: ldur            d0, [x0, #0xf]
    // 0xbf0df0: fneg            d2, d0
    // 0xbf0df4: ldur            x1, [fp, #-0x18]
    // 0xbf0df8: mov             v0.16b, v1.16b
    // 0xbf0dfc: mov             v1.16b, v2.16b
    // 0xbf0e00: r0 = translateByDouble()
    //     0xbf0e00: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf0e04: ldur            x0, [fp, #-8]
    // 0xbf0e08: LoadField: r1 = r0->field_53
    //     0xbf0e08: ldur            w1, [x0, #0x53]
    // 0xbf0e0c: DecompressPointer r1
    //     0xbf0e0c: add             x1, x1, HEAP, lsl #32
    // 0xbf0e10: cmp             w1, NULL
    // 0xbf0e14: b.eq            #0xbf0e38
    // 0xbf0e18: LoadField: d0 = r1->field_7
    //     0xbf0e18: ldur            d0, [x1, #7]
    // 0xbf0e1c: fneg            d1, d0
    // 0xbf0e20: LoadField: d0 = r1->field_f
    //     0xbf0e20: ldur            d0, [x1, #0xf]
    // 0xbf0e24: fneg            d2, d0
    // 0xbf0e28: ldur            x1, [fp, #-0x18]
    // 0xbf0e2c: mov             v0.16b, v1.16b
    // 0xbf0e30: mov             v1.16b, v2.16b
    // 0xbf0e34: r0 = translateByDouble()
    //     0xbf0e34: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf0e38: ldur            x0, [fp, #-0x18]
    // 0xbf0e3c: LeaveFrame
    //     0xbf0e3c: mov             SP, fp
    //     0xbf0e40: ldp             fp, lr, [SP], #0x10
    // 0xbf0e44: ret
    //     0xbf0e44: ret             
    // 0xbf0e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0e48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0e4c: b               #0xbf0bd8
    // 0xbf0e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0e50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0e54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0e54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0e58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0e58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0e5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ alwaysNeedsCompositing(/* No info */) {
    // ** addr: 0xc05658, size: 0x38
    // 0xc05658: LoadField: r2 = r1->field_4f
    //     0xc05658: ldur            w2, [x1, #0x4f]
    // 0xc0565c: DecompressPointer r2
    //     0xc0565c: add             x2, x2, HEAP, lsl #32
    // 0xc05660: cmp             w2, NULL
    // 0xc05664: b.eq            #0xc05688
    // 0xc05668: LoadField: r2 = r1->field_67
    //     0xc05668: ldur            w2, [x1, #0x67]
    // 0xc0566c: DecompressPointer r2
    //     0xc0566c: add             x2, x2, HEAP, lsl #32
    // 0xc05670: cmp             w2, NULL
    // 0xc05674: r16 = true
    //     0xc05674: add             x16, NULL, #0x20  ; true
    // 0xc05678: r17 = false
    //     0xc05678: add             x17, NULL, #0x30  ; false
    // 0xc0567c: csel            x1, x16, x17, ne
    // 0xc05680: mov             x0, x1
    // 0xc05684: b               #0xc0568c
    // 0xc05688: r0 = false
    //     0xc05688: add             x0, NULL, #0x30  ; false
    // 0xc0568c: ret
    //     0xc0568c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1c0b0, size: 0x338
    // 0xc1c0b0: EnterFrame
    //     0xc1c0b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c0b4: mov             fp, SP
    // 0xc1c0b8: AllocStack(0x50)
    //     0xc1c0b8: sub             SP, SP, #0x50
    // 0xc1c0bc: SetupParameters(RenderTransform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1c0bc: mov             x0, x2
    //     0xc1c0c0: stur            x2, [fp, #-0x10]
    //     0xc1c0c4: mov             x2, x1
    //     0xc1c0c8: stur            x1, [fp, #-8]
    //     0xc1c0cc: stur            x3, [fp, #-0x18]
    // 0xc1c0d0: CheckStackOverflow
    //     0xc1c0d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1c0d4: cmp             SP, x16
    //     0xc1c0d8: b.ls            #0xc1c3cc
    // 0xc1c0dc: LoadField: r1 = r2->field_4f
    //     0xc1c0dc: ldur            w1, [x2, #0x4f]
    // 0xc1c0e0: DecompressPointer r1
    //     0xc1c0e0: add             x1, x1, HEAP, lsl #32
    // 0xc1c0e4: cmp             w1, NULL
    // 0xc1c0e8: b.eq            #0xc1c3bc
    // 0xc1c0ec: mov             x1, x2
    // 0xc1c0f0: r0 = _effectiveTransform()
    //     0xc1c0f0: bl              #0xbf0bbc  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0xc1c0f4: stur            x0, [fp, #-0x20]
    // 0xc1c0f8: cmp             w0, NULL
    // 0xc1c0fc: b.eq            #0xc1c3d4
    // 0xc1c100: ldur            x2, [fp, #-8]
    // 0xc1c104: LoadField: r1 = r2->field_67
    //     0xc1c104: ldur            w1, [x2, #0x67]
    // 0xc1c108: DecompressPointer r1
    //     0xc1c108: add             x1, x1, HEAP, lsl #32
    // 0xc1c10c: cmp             w1, NULL
    // 0xc1c110: b.ne            #0xc1c27c
    // 0xc1c114: mov             x1, x0
    // 0xc1c118: r0 = getAsTranslation()
    //     0xc1c118: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xc1c11c: cmp             w0, NULL
    // 0xc1c120: b.ne            #0xc1c244
    // 0xc1c124: ldur            x1, [fp, #-0x20]
    // 0xc1c128: r0 = determinant()
    //     0xc1c128: bl              #0xc1cb78  ; [package:vector_math/vector_math_64.dart] Matrix4::determinant
    // 0xc1c12c: mov             v1.16b, v0.16b
    // 0xc1c130: d0 = 0.000000
    //     0xc1c130: eor             v0.16b, v0.16b, v0.16b
    // 0xc1c134: fcmp            d1, d0
    // 0xc1c138: b.eq            #0xc1c220
    // 0xc1c13c: mov             x0, v1.d[0]
    // 0xc1c140: and             x0, x0, #0x7fffffffffffffff
    // 0xc1c144: r17 = 9218868437227405312
    //     0xc1c144: mov             x17, #0x7ff0000000000000
    // 0xc1c148: cmp             x0, x17
    // 0xc1c14c: b.eq            #0xc1c220
    // 0xc1c150: fcmp            d1, d1
    // 0xc1c154: b.vs            #0xc1c220
    // 0xc1c158: ldur            x3, [fp, #-8]
    // 0xc1c15c: LoadField: r4 = r3->field_37
    //     0xc1c15c: ldur            w4, [x3, #0x37]
    // 0xc1c160: DecompressPointer r4
    //     0xc1c160: add             x4, x4, HEAP, lsl #32
    // 0xc1c164: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1c168: cmp             w4, w16
    // 0xc1c16c: b.eq            #0xc1c3d8
    // 0xc1c170: stur            x4, [fp, #-0x38]
    // 0xc1c174: LoadField: r5 = r3->field_2f
    //     0xc1c174: ldur            w5, [x3, #0x2f]
    // 0xc1c178: DecompressPointer r5
    //     0xc1c178: add             x5, x5, HEAP, lsl #32
    // 0xc1c17c: stur            x5, [fp, #-0x30]
    // 0xc1c180: LoadField: r6 = r5->field_b
    //     0xc1c180: ldur            w6, [x5, #0xb]
    // 0xc1c184: DecompressPointer r6
    //     0xc1c184: add             x6, x6, HEAP, lsl #32
    // 0xc1c188: stur            x6, [fp, #-0x28]
    // 0xc1c18c: r0 = LoadClassIdInstr(r6)
    //     0xc1c18c: ldur            x0, [x6, #-1]
    //     0xc1c190: ubfx            x0, x0, #0xc, #0x14
    // 0xc1c194: r17 = 4662
    //     0xc1c194: mov             x17, #0x1236
    // 0xc1c198: cmp             x0, x17
    // 0xc1c19c: b.ne            #0xc1c1dc
    // 0xc1c1a0: mov             x0, x6
    // 0xc1c1a4: r2 = Null
    //     0xc1c1a4: mov             x2, NULL
    // 0xc1c1a8: r1 = Null
    //     0xc1c1a8: mov             x1, NULL
    // 0xc1c1ac: r4 = LoadClassIdInstr(r0)
    //     0xc1c1ac: ldur            x4, [x0, #-1]
    //     0xc1c1b0: ubfx            x4, x4, #0xc, #0x14
    // 0xc1c1b4: r17 = 4662
    //     0xc1c1b4: mov             x17, #0x1236
    // 0xc1c1b8: cmp             x4, x17
    // 0xc1c1bc: b.eq            #0xc1c1d4
    // 0xc1c1c0: r8 = TransformLayer?
    //     0xc1c1c0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96ab8] Type: TransformLayer?
    //     0xc1c1c4: ldr             x8, [x8, #0xab8]
    // 0xc1c1c8: r3 = Null
    //     0xc1c1c8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a6b0] Null
    //     0xc1c1cc: ldr             x3, [x3, #0x6b0]
    // 0xc1c1d0: r0 = DefaultNullableTypeTest()
    //     0xc1c1d0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1c1d4: ldur            x7, [fp, #-0x28]
    // 0xc1c1d8: b               #0xc1c1e0
    // 0xc1c1dc: r7 = Null
    //     0xc1c1dc: mov             x7, NULL
    // 0xc1c1e0: ldur            x2, [fp, #-8]
    // 0xc1c1e4: stur            x7, [fp, #-0x28]
    // 0xc1c1e8: r1 = Function 'paint':.
    //     0xc1c1e8: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1c1ec: ldr             x1, [x1, #0x4e0]
    // 0xc1c1f0: r0 = AllocateClosure()
    //     0xc1c1f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1c1f4: ldur            x1, [fp, #-0x10]
    // 0xc1c1f8: ldur            x2, [fp, #-0x38]
    // 0xc1c1fc: ldur            x3, [fp, #-0x18]
    // 0xc1c200: ldur            x5, [fp, #-0x20]
    // 0xc1c204: mov             x6, x0
    // 0xc1c208: ldur            x7, [fp, #-0x28]
    // 0xc1c20c: r0 = pushTransform()
    //     0xc1c20c: bl              #0xc1c818  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0xc1c210: ldur            x1, [fp, #-0x30]
    // 0xc1c214: mov             x2, x0
    // 0xc1c218: r0 = layer=()
    //     0xc1c218: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1c21c: b               #0xc1c3bc
    // 0xc1c220: ldur            x3, [fp, #-8]
    // 0xc1c224: LoadField: r1 = r3->field_2f
    //     0xc1c224: ldur            w1, [x3, #0x2f]
    // 0xc1c228: DecompressPointer r1
    //     0xc1c228: add             x1, x1, HEAP, lsl #32
    // 0xc1c22c: r2 = Null
    //     0xc1c22c: mov             x2, NULL
    // 0xc1c230: r0 = layer=()
    //     0xc1c230: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1c234: r0 = Null
    //     0xc1c234: mov             x0, NULL
    // 0xc1c238: LeaveFrame
    //     0xc1c238: mov             SP, fp
    //     0xc1c23c: ldp             fp, lr, [SP], #0x10
    // 0xc1c240: ret
    //     0xc1c240: ret             
    // 0xc1c244: ldur            x3, [fp, #-8]
    // 0xc1c248: ldur            x1, [fp, #-0x18]
    // 0xc1c24c: mov             x2, x0
    // 0xc1c250: r0 = +()
    //     0xc1c250: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc1c254: ldur            x1, [fp, #-8]
    // 0xc1c258: ldur            x2, [fp, #-0x10]
    // 0xc1c25c: mov             x3, x0
    // 0xc1c260: r0 = paint()
    //     0xc1c260: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1c264: ldur            x2, [fp, #-8]
    // 0xc1c268: LoadField: r1 = r2->field_2f
    //     0xc1c268: ldur            w1, [x2, #0x2f]
    // 0xc1c26c: DecompressPointer r1
    //     0xc1c26c: add             x1, x1, HEAP, lsl #32
    // 0xc1c270: r2 = Null
    //     0xc1c270: mov             x2, NULL
    // 0xc1c274: r0 = layer=()
    //     0xc1c274: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1c278: b               #0xc1c3bc
    // 0xc1c27c: ldur            x5, [fp, #-0x18]
    // 0xc1c280: LoadField: d2 = r5->field_7
    //     0xc1c280: ldur            d2, [x5, #7]
    // 0xc1c284: stur            d2, [fp, #-0x48]
    // 0xc1c288: LoadField: d3 = r5->field_f
    //     0xc1c288: ldur            d3, [x5, #0xf]
    // 0xc1c28c: mov             v0.16b, v2.16b
    // 0xc1c290: mov             v1.16b, v3.16b
    // 0xc1c294: stur            d3, [fp, #-0x40]
    // 0xc1c298: r1 = Null
    //     0xc1c298: mov             x1, NULL
    // 0xc1c29c: r0 = Matrix4.translationValues()
    //     0xc1c29c: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xc1c2a0: mov             x1, x0
    // 0xc1c2a4: ldur            x2, [fp, #-0x20]
    // 0xc1c2a8: stur            x0, [fp, #-0x20]
    // 0xc1c2ac: r0 = multiply()
    //     0xc1c2ac: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xc1c2b0: ldur            d0, [fp, #-0x48]
    // 0xc1c2b4: fneg            d1, d0
    // 0xc1c2b8: ldur            d0, [fp, #-0x40]
    // 0xc1c2bc: fneg            d2, d0
    // 0xc1c2c0: ldur            x1, [fp, #-0x20]
    // 0xc1c2c4: mov             v0.16b, v1.16b
    // 0xc1c2c8: mov             v1.16b, v2.16b
    // 0xc1c2cc: r0 = translateByDouble()
    //     0xc1c2cc: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xc1c2d0: ldur            x0, [fp, #-0x20]
    // 0xc1c2d4: LoadField: r2 = r0->field_7
    //     0xc1c2d4: ldur            w2, [x0, #7]
    // 0xc1c2d8: DecompressPointer r2
    //     0xc1c2d8: add             x2, x2, HEAP, lsl #32
    // 0xc1c2dc: ldur            x0, [fp, #-8]
    // 0xc1c2e0: LoadField: r1 = r0->field_67
    //     0xc1c2e0: ldur            w1, [x0, #0x67]
    // 0xc1c2e4: DecompressPointer r1
    //     0xc1c2e4: add             x1, x1, HEAP, lsl #32
    // 0xc1c2e8: cmp             w1, NULL
    // 0xc1c2ec: b.eq            #0xc1c3e0
    // 0xc1c2f0: str             x1, [SP]
    // 0xc1c2f4: r1 = Null
    //     0xc1c2f4: mov             x1, NULL
    // 0xc1c2f8: r4 = const [0, 0x3, 0x1, 0x2, filterQuality, 0x2, null]
    //     0xc1c2f8: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a6c0] List(7) [0, 0x3, 0x1, 0x2, "filterQuality", 0x2, Null]
    //     0xc1c2fc: ldr             x4, [x4, #0x6c0]
    // 0xc1c300: r0 = ImageFilter.matrix()
    //     0xc1c300: bl              #0xc1c3e8  ; [dart:ui] ImageFilter::ImageFilter.matrix
    // 0xc1c304: mov             x1, x0
    // 0xc1c308: ldur            x0, [fp, #-8]
    // 0xc1c30c: stur            x1, [fp, #-0x28]
    // 0xc1c310: LoadField: r3 = r0->field_2f
    //     0xc1c310: ldur            w3, [x0, #0x2f]
    // 0xc1c314: DecompressPointer r3
    //     0xc1c314: add             x3, x3, HEAP, lsl #32
    // 0xc1c318: stur            x3, [fp, #-0x20]
    // 0xc1c31c: LoadField: r2 = r3->field_b
    //     0xc1c31c: ldur            w2, [x3, #0xb]
    // 0xc1c320: DecompressPointer r2
    //     0xc1c320: add             x2, x2, HEAP, lsl #32
    // 0xc1c324: r4 = LoadClassIdInstr(r2)
    //     0xc1c324: ldur            x4, [x2, #-1]
    //     0xc1c328: ubfx            x4, x4, #0xc, #0x14
    // 0xc1c32c: r17 = 4663
    //     0xc1c32c: mov             x17, #0x1237
    // 0xc1c330: cmp             x4, x17
    // 0xc1c334: b.ne            #0xc1c34c
    // 0xc1c338: mov             x16, x1
    // 0xc1c33c: mov             x1, x2
    // 0xc1c340: mov             x2, x16
    // 0xc1c344: r0 = imageFilter=()
    //     0xc1c344: bl              #0xbed35c  ; [package:flutter/src/rendering/layer.dart] ImageFilterLayer::imageFilter=
    // 0xc1c348: b               #0xc1c37c
    // 0xc1c34c: r0 = ImageFilterLayer()
    //     0xc1c34c: bl              #0xbed3f0  ; AllocateImageFilterLayerStub -> ImageFilterLayer (size=0x50)
    // 0xc1c350: mov             x2, x0
    // 0xc1c354: ldur            x0, [fp, #-0x28]
    // 0xc1c358: stur            x2, [fp, #-0x30]
    // 0xc1c35c: StoreField: r2->field_4b = r0
    //     0xc1c35c: stur            w0, [x2, #0x4b]
    // 0xc1c360: r0 = Instance_Offset
    //     0xc1c360: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1c364: StoreField: r2->field_47 = r0
    //     0xc1c364: stur            w0, [x2, #0x47]
    // 0xc1c368: mov             x1, x2
    // 0xc1c36c: r0 = Layer()
    //     0xc1c36c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1c370: ldur            x1, [fp, #-0x20]
    // 0xc1c374: ldur            x2, [fp, #-0x30]
    // 0xc1c378: r0 = layer=()
    //     0xc1c378: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1c37c: ldur            x0, [fp, #-0x20]
    // 0xc1c380: LoadField: r3 = r0->field_b
    //     0xc1c380: ldur            w3, [x0, #0xb]
    // 0xc1c384: DecompressPointer r3
    //     0xc1c384: add             x3, x3, HEAP, lsl #32
    // 0xc1c388: stur            x3, [fp, #-0x28]
    // 0xc1c38c: cmp             w3, NULL
    // 0xc1c390: b.eq            #0xc1c3e4
    // 0xc1c394: ldur            x2, [fp, #-8]
    // 0xc1c398: r1 = Function 'paint':.
    //     0xc1c398: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1c39c: ldr             x1, [x1, #0x4e0]
    // 0xc1c3a0: r0 = AllocateClosure()
    //     0xc1c3a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1c3a4: ldur            x1, [fp, #-0x10]
    // 0xc1c3a8: ldur            x2, [fp, #-0x28]
    // 0xc1c3ac: mov             x3, x0
    // 0xc1c3b0: ldur            x5, [fp, #-0x18]
    // 0xc1c3b4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc1c3b4: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc1c3b8: r0 = pushLayer()
    //     0xc1c3b8: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1c3bc: r0 = Null
    //     0xc1c3bc: mov             x0, NULL
    // 0xc1c3c0: LeaveFrame
    //     0xc1c3c0: mov             SP, fp
    //     0xc1c3c4: ldp             fp, lr, [SP], #0x10
    // 0xc1c3c8: ret
    //     0xc1c3c8: ret             
    // 0xc1c3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c3cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c3d0: b               #0xc1c0dc
    // 0xc1c3d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1c3d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1c3d8: r9 = _needsCompositing
    //     0xc1c3d8: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1c3dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1c3dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1c3e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1c3e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1c3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1c3e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ filterQuality=(/* No info */) {
    // ** addr: 0xcf6cc8, size: 0xd8
    // 0xcf6cc8: EnterFrame
    //     0xcf6cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6ccc: mov             fp, SP
    // 0xcf6cd0: AllocStack(0x10)
    //     0xcf6cd0: sub             SP, SP, #0x10
    // 0xcf6cd4: SetupParameters(RenderTransform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf6cd4: mov             x0, x2
    //     0xcf6cd8: stur            x2, [fp, #-0x10]
    //     0xcf6cdc: mov             x2, x1
    //     0xcf6ce0: stur            x1, [fp, #-8]
    // 0xcf6ce4: CheckStackOverflow
    //     0xcf6ce4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6ce8: cmp             SP, x16
    //     0xcf6cec: b.ls            #0xcf6d98
    // 0xcf6cf0: LoadField: r1 = r2->field_67
    //     0xcf6cf0: ldur            w1, [x2, #0x67]
    // 0xcf6cf4: DecompressPointer r1
    //     0xcf6cf4: add             x1, x1, HEAP, lsl #32
    // 0xcf6cf8: cmp             w1, w0
    // 0xcf6cfc: b.ne            #0xcf6d10
    // 0xcf6d00: r0 = Null
    //     0xcf6d00: mov             x0, NULL
    // 0xcf6d04: LeaveFrame
    //     0xcf6d04: mov             SP, fp
    //     0xcf6d08: ldp             fp, lr, [SP], #0x10
    // 0xcf6d0c: ret
    //     0xcf6d0c: ret             
    // 0xcf6d10: mov             x1, x2
    // 0xcf6d14: r0 = alwaysNeedsCompositing()
    //     0xcf6d14: bl              #0xc05658  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::alwaysNeedsCompositing
    // 0xcf6d18: mov             x1, x0
    // 0xcf6d1c: ldur            x0, [fp, #-0x10]
    // 0xcf6d20: ldur            x2, [fp, #-8]
    // 0xcf6d24: StoreField: r2->field_67 = r0
    //     0xcf6d24: stur            w0, [x2, #0x67]
    //     0xcf6d28: ldurb           w16, [x2, #-1]
    //     0xcf6d2c: ldurb           w17, [x0, #-1]
    //     0xcf6d30: and             x16, x17, x16, lsr #2
    //     0xcf6d34: tst             x16, HEAP, lsr #32
    //     0xcf6d38: b.eq            #0xcf6d40
    //     0xcf6d3c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6d40: LoadField: r0 = r2->field_4f
    //     0xcf6d40: ldur            w0, [x2, #0x4f]
    // 0xcf6d44: DecompressPointer r0
    //     0xcf6d44: add             x0, x0, HEAP, lsl #32
    // 0xcf6d48: cmp             w0, NULL
    // 0xcf6d4c: b.eq            #0xcf6d6c
    // 0xcf6d50: ldur            x0, [fp, #-0x10]
    // 0xcf6d54: cmp             w0, NULL
    // 0xcf6d58: r16 = true
    //     0xcf6d58: add             x16, NULL, #0x20  ; true
    // 0xcf6d5c: r17 = false
    //     0xcf6d5c: add             x17, NULL, #0x30  ; false
    // 0xcf6d60: csel            x3, x16, x17, ne
    // 0xcf6d64: mov             x0, x3
    // 0xcf6d68: b               #0xcf6d70
    // 0xcf6d6c: r0 = false
    //     0xcf6d6c: add             x0, NULL, #0x30  ; false
    // 0xcf6d70: cmp             w1, w0
    // 0xcf6d74: b.eq            #0xcf6d80
    // 0xcf6d78: mov             x1, x2
    // 0xcf6d7c: r0 = markNeedsCompositingBitsUpdate()
    //     0xcf6d7c: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xcf6d80: ldur            x1, [fp, #-8]
    // 0xcf6d84: r0 = markNeedsPaint()
    //     0xcf6d84: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6d88: r0 = Null
    //     0xcf6d88: mov             x0, NULL
    // 0xcf6d8c: LeaveFrame
    //     0xcf6d8c: mov             SP, fp
    //     0xcf6d90: ldp             fp, lr, [SP], #0x10
    // 0xcf6d94: ret
    //     0xcf6d94: ret             
    // 0xcf6d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6d98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6d9c: b               #0xcf6cf0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf6da0, size: 0x88
    // 0xcf6da0: EnterFrame
    //     0xcf6da0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6da4: mov             fp, SP
    // 0xcf6da8: AllocStack(0x8)
    //     0xcf6da8: sub             SP, SP, #8
    // 0xcf6dac: SetupParameters(RenderTransform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcf6dac: mov             x0, x2
    //     0xcf6db0: mov             x2, x1
    //     0xcf6db4: stur            x1, [fp, #-8]
    // 0xcf6db8: CheckStackOverflow
    //     0xcf6db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6dbc: cmp             SP, x16
    //     0xcf6dc0: b.ls            #0xcf6e20
    // 0xcf6dc4: LoadField: r1 = r2->field_5b
    //     0xcf6dc4: ldur            w1, [x2, #0x5b]
    // 0xcf6dc8: DecompressPointer r1
    //     0xcf6dc8: add             x1, x1, HEAP, lsl #32
    // 0xcf6dcc: cmp             w1, w0
    // 0xcf6dd0: b.ne            #0xcf6de4
    // 0xcf6dd4: r0 = Null
    //     0xcf6dd4: mov             x0, NULL
    // 0xcf6dd8: LeaveFrame
    //     0xcf6dd8: mov             SP, fp
    //     0xcf6ddc: ldp             fp, lr, [SP], #0x10
    // 0xcf6de0: ret
    //     0xcf6de0: ret             
    // 0xcf6de4: StoreField: r2->field_5b = r0
    //     0xcf6de4: stur            w0, [x2, #0x5b]
    //     0xcf6de8: ldurb           w16, [x2, #-1]
    //     0xcf6dec: ldurb           w17, [x0, #-1]
    //     0xcf6df0: and             x16, x17, x16, lsr #2
    //     0xcf6df4: tst             x16, HEAP, lsr #32
    //     0xcf6df8: b.eq            #0xcf6e00
    //     0xcf6dfc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6e00: mov             x1, x2
    // 0xcf6e04: r0 = markNeedsPaint()
    //     0xcf6e04: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6e08: ldur            x1, [fp, #-8]
    // 0xcf6e0c: r0 = markNeedsSemanticsUpdate()
    //     0xcf6e0c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf6e10: r0 = Null
    //     0xcf6e10: mov             x0, NULL
    // 0xcf6e14: LeaveFrame
    //     0xcf6e14: mov             SP, fp
    //     0xcf6e18: ldp             fp, lr, [SP], #0x10
    // 0xcf6e1c: ret
    //     0xcf6e1c: ret             
    // 0xcf6e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6e24: b               #0xcf6dc4
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0xcf6e28, size: 0xb0
    // 0xcf6e28: EnterFrame
    //     0xcf6e28: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6e2c: mov             fp, SP
    // 0xcf6e30: AllocStack(0x20)
    //     0xcf6e30: sub             SP, SP, #0x20
    // 0xcf6e34: SetupParameters(RenderTransform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf6e34: stur            x1, [fp, #-8]
    //     0xcf6e38: mov             x16, x2
    //     0xcf6e3c: mov             x2, x1
    //     0xcf6e40: mov             x1, x16
    //     0xcf6e44: stur            x1, [fp, #-0x10]
    // 0xcf6e48: CheckStackOverflow
    //     0xcf6e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6e4c: cmp             SP, x16
    //     0xcf6e50: b.ls            #0xcf6ed0
    // 0xcf6e54: LoadField: r0 = r2->field_57
    //     0xcf6e54: ldur            w0, [x2, #0x57]
    // 0xcf6e58: DecompressPointer r0
    //     0xcf6e58: add             x0, x0, HEAP, lsl #32
    // 0xcf6e5c: r3 = LoadClassIdInstr(r0)
    //     0xcf6e5c: ldur            x3, [x0, #-1]
    //     0xcf6e60: ubfx            x3, x3, #0xc, #0x14
    // 0xcf6e64: stp             x1, x0, [SP]
    // 0xcf6e68: mov             x0, x3
    // 0xcf6e6c: mov             lr, x0
    // 0xcf6e70: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6e74: blr             lr
    // 0xcf6e78: tbnz            w0, #4, #0xcf6e8c
    // 0xcf6e7c: r0 = Null
    //     0xcf6e7c: mov             x0, NULL
    // 0xcf6e80: LeaveFrame
    //     0xcf6e80: mov             SP, fp
    //     0xcf6e84: ldp             fp, lr, [SP], #0x10
    // 0xcf6e88: ret
    //     0xcf6e88: ret             
    // 0xcf6e8c: ldur            x2, [fp, #-8]
    // 0xcf6e90: ldur            x0, [fp, #-0x10]
    // 0xcf6e94: StoreField: r2->field_57 = r0
    //     0xcf6e94: stur            w0, [x2, #0x57]
    //     0xcf6e98: ldurb           w16, [x2, #-1]
    //     0xcf6e9c: ldurb           w17, [x0, #-1]
    //     0xcf6ea0: and             x16, x17, x16, lsr #2
    //     0xcf6ea4: tst             x16, HEAP, lsr #32
    //     0xcf6ea8: b.eq            #0xcf6eb0
    //     0xcf6eac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6eb0: mov             x1, x2
    // 0xcf6eb4: r0 = markNeedsPaint()
    //     0xcf6eb4: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6eb8: ldur            x1, [fp, #-8]
    // 0xcf6ebc: r0 = markNeedsSemanticsUpdate()
    //     0xcf6ebc: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf6ec0: r0 = Null
    //     0xcf6ec0: mov             x0, NULL
    // 0xcf6ec4: LeaveFrame
    //     0xcf6ec4: mov             SP, fp
    //     0xcf6ec8: ldp             fp, lr, [SP], #0x10
    // 0xcf6ecc: ret
    //     0xcf6ecc: ret             
    // 0xcf6ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6ed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6ed4: b               #0xcf6e54
  }
  set _ origin=(/* No info */) {
    // ** addr: 0xcf6ed8, size: 0xb0
    // 0xcf6ed8: EnterFrame
    //     0xcf6ed8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6edc: mov             fp, SP
    // 0xcf6ee0: AllocStack(0x20)
    //     0xcf6ee0: sub             SP, SP, #0x20
    // 0xcf6ee4: SetupParameters(RenderTransform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf6ee4: stur            x1, [fp, #-8]
    //     0xcf6ee8: mov             x16, x2
    //     0xcf6eec: mov             x2, x1
    //     0xcf6ef0: mov             x1, x16
    //     0xcf6ef4: stur            x1, [fp, #-0x10]
    // 0xcf6ef8: CheckStackOverflow
    //     0xcf6ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6efc: cmp             SP, x16
    //     0xcf6f00: b.ls            #0xcf6f80
    // 0xcf6f04: LoadField: r0 = r2->field_53
    //     0xcf6f04: ldur            w0, [x2, #0x53]
    // 0xcf6f08: DecompressPointer r0
    //     0xcf6f08: add             x0, x0, HEAP, lsl #32
    // 0xcf6f0c: r3 = LoadClassIdInstr(r0)
    //     0xcf6f0c: ldur            x3, [x0, #-1]
    //     0xcf6f10: ubfx            x3, x3, #0xc, #0x14
    // 0xcf6f14: stp             x1, x0, [SP]
    // 0xcf6f18: mov             x0, x3
    // 0xcf6f1c: mov             lr, x0
    // 0xcf6f20: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6f24: blr             lr
    // 0xcf6f28: tbnz            w0, #4, #0xcf6f3c
    // 0xcf6f2c: r0 = Null
    //     0xcf6f2c: mov             x0, NULL
    // 0xcf6f30: LeaveFrame
    //     0xcf6f30: mov             SP, fp
    //     0xcf6f34: ldp             fp, lr, [SP], #0x10
    // 0xcf6f38: ret
    //     0xcf6f38: ret             
    // 0xcf6f3c: ldur            x2, [fp, #-8]
    // 0xcf6f40: ldur            x0, [fp, #-0x10]
    // 0xcf6f44: StoreField: r2->field_53 = r0
    //     0xcf6f44: stur            w0, [x2, #0x53]
    //     0xcf6f48: ldurb           w16, [x2, #-1]
    //     0xcf6f4c: ldurb           w17, [x0, #-1]
    //     0xcf6f50: and             x16, x17, x16, lsr #2
    //     0xcf6f54: tst             x16, HEAP, lsr #32
    //     0xcf6f58: b.eq            #0xcf6f60
    //     0xcf6f5c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6f60: mov             x1, x2
    // 0xcf6f64: r0 = markNeedsPaint()
    //     0xcf6f64: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6f68: ldur            x1, [fp, #-8]
    // 0xcf6f6c: r0 = markNeedsSemanticsUpdate()
    //     0xcf6f6c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf6f70: r0 = Null
    //     0xcf6f70: mov             x0, NULL
    // 0xcf6f74: LeaveFrame
    //     0xcf6f74: mov             SP, fp
    //     0xcf6f78: ldp             fp, lr, [SP], #0x10
    // 0xcf6f7c: ret
    //     0xcf6f7c: ret             
    // 0xcf6f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6f80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6f84: b               #0xcf6f04
  }
  set _ transform=(/* No info */) {
    // ** addr: 0xcf6f88, size: 0xd0
    // 0xcf6f88: EnterFrame
    //     0xcf6f88: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6f8c: mov             fp, SP
    // 0xcf6f90: AllocStack(0x28)
    //     0xcf6f90: sub             SP, SP, #0x28
    // 0xcf6f94: SetupParameters(RenderTransform this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xcf6f94: stur            x1, [fp, #-8]
    //     0xcf6f98: stur            x2, [fp, #-0x10]
    // 0xcf6f9c: CheckStackOverflow
    //     0xcf6f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6fa0: cmp             SP, x16
    //     0xcf6fa4: b.ls            #0xcf7050
    // 0xcf6fa8: LoadField: r0 = r1->field_63
    //     0xcf6fa8: ldur            w0, [x1, #0x63]
    // 0xcf6fac: DecompressPointer r0
    //     0xcf6fac: add             x0, x0, HEAP, lsl #32
    // 0xcf6fb0: r3 = LoadClassIdInstr(r0)
    //     0xcf6fb0: ldur            x3, [x0, #-1]
    //     0xcf6fb4: ubfx            x3, x3, #0xc, #0x14
    // 0xcf6fb8: stp             x2, x0, [SP]
    // 0xcf6fbc: mov             x0, x3
    // 0xcf6fc0: mov             lr, x0
    // 0xcf6fc4: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6fc8: blr             lr
    // 0xcf6fcc: tbnz            w0, #4, #0xcf6fe0
    // 0xcf6fd0: r0 = Null
    //     0xcf6fd0: mov             x0, NULL
    // 0xcf6fd4: LeaveFrame
    //     0xcf6fd4: mov             SP, fp
    //     0xcf6fd8: ldp             fp, lr, [SP], #0x10
    // 0xcf6fdc: ret
    //     0xcf6fdc: ret             
    // 0xcf6fe0: ldur            x1, [fp, #-8]
    // 0xcf6fe4: r0 = Matrix4()
    //     0xcf6fe4: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xcf6fe8: r4 = 32
    //     0xcf6fe8: mov             x4, #0x20
    // 0xcf6fec: stur            x0, [fp, #-0x18]
    // 0xcf6ff0: r0 = AllocateFloat64Array()
    //     0xcf6ff0: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xcf6ff4: mov             x1, x0
    // 0xcf6ff8: ldur            x0, [fp, #-0x18]
    // 0xcf6ffc: StoreField: r0->field_7 = r1
    //     0xcf6ffc: stur            w1, [x0, #7]
    // 0xcf7000: mov             x1, x0
    // 0xcf7004: ldur            x2, [fp, #-0x10]
    // 0xcf7008: r0 = setFrom()
    //     0xcf7008: bl              #0x832b8c  ; [package:vector_math/vector_math_64.dart] Matrix4::setFrom
    // 0xcf700c: ldur            x0, [fp, #-0x18]
    // 0xcf7010: ldur            x2, [fp, #-8]
    // 0xcf7014: StoreField: r2->field_63 = r0
    //     0xcf7014: stur            w0, [x2, #0x63]
    //     0xcf7018: ldurb           w16, [x2, #-1]
    //     0xcf701c: ldurb           w17, [x0, #-1]
    //     0xcf7020: and             x16, x17, x16, lsr #2
    //     0xcf7024: tst             x16, HEAP, lsr #32
    //     0xcf7028: b.eq            #0xcf7030
    //     0xcf702c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf7030: mov             x1, x2
    // 0xcf7034: r0 = markNeedsPaint()
    //     0xcf7034: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf7038: ldur            x1, [fp, #-8]
    // 0xcf703c: r0 = markNeedsSemanticsUpdate()
    //     0xcf703c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf7040: r0 = Null
    //     0xcf7040: mov             x0, NULL
    // 0xcf7044: LeaveFrame
    //     0xcf7044: mov             SP, fp
    //     0xcf7048: ldp             fp, lr, [SP], #0x10
    // 0xcf704c: ret
    //     0xcf704c: ret             
    // 0xcf7050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7050: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7054: b               #0xcf6fa8
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e8c14, size: 0x98
    // 0x10e8c14: EnterFrame
    //     0x10e8c14: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8c18: mov             fp, SP
    // 0x10e8c1c: AllocStack(0x20)
    //     0x10e8c1c: sub             SP, SP, #0x20
    // 0x10e8c20: SetupParameters(RenderTransform this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10e8c20: mov             x0, x1
    //     0x10e8c24: stur            x1, [fp, #-8]
    //     0x10e8c28: mov             x1, x2
    //     0x10e8c2c: stur            x2, [fp, #-0x10]
    //     0x10e8c30: stur            x3, [fp, #-0x18]
    // 0x10e8c34: CheckStackOverflow
    //     0x10e8c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8c38: cmp             SP, x16
    //     0x10e8c3c: b.ls            #0x10e8ca4
    // 0x10e8c40: r1 = 1
    //     0x10e8c40: mov             x1, #1
    // 0x10e8c44: r0 = AllocateContext()
    //     0x10e8c44: bl              #0x13de838  ; AllocateContextStub
    // 0x10e8c48: ldur            x1, [fp, #-8]
    // 0x10e8c4c: stur            x0, [fp, #-0x20]
    // 0x10e8c50: StoreField: r0->field_f = r1
    //     0x10e8c50: stur            w1, [x0, #0xf]
    // 0x10e8c54: LoadField: r2 = r1->field_5f
    //     0x10e8c54: ldur            w2, [x1, #0x5f]
    // 0x10e8c58: DecompressPointer r2
    //     0x10e8c58: add             x2, x2, HEAP, lsl #32
    // 0x10e8c5c: tbnz            w2, #4, #0x10e8c6c
    // 0x10e8c60: r0 = _effectiveTransform()
    //     0x10e8c60: bl              #0xbf0bbc  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0x10e8c64: mov             x5, x0
    // 0x10e8c68: b               #0x10e8c70
    // 0x10e8c6c: r5 = Null
    //     0x10e8c6c: mov             x5, NULL
    // 0x10e8c70: ldur            x2, [fp, #-0x20]
    // 0x10e8c74: stur            x5, [fp, #-8]
    // 0x10e8c78: r1 = Function '<anonymous closure>':.
    //     0x10e8c78: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a6c8] AnonymousClosure: (0x10e95dc), in [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren (0x10e984c)
    //     0x10e8c7c: ldr             x1, [x1, #0x6c8]
    // 0x10e8c80: r0 = AllocateClosure()
    //     0x10e8c80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e8c84: ldur            x1, [fp, #-0x10]
    // 0x10e8c88: mov             x2, x0
    // 0x10e8c8c: ldur            x3, [fp, #-0x18]
    // 0x10e8c90: ldur            x5, [fp, #-8]
    // 0x10e8c94: r0 = addWithPaintTransform()
    //     0x10e8c94: bl              #0x10e8cac  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x10e8c98: LeaveFrame
    //     0x10e8c98: mov             SP, fp
    //     0x10e8c9c: ldp             fp, lr, [SP], #0x10
    // 0x10e8ca0: ret
    //     0x10e8ca0: ret             
    // 0x10e8ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8ca4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8ca8: b               #0x10e8c40
  }
  _ RenderTransform(/* No info */) {
    // ** addr: 0x11d0ce4, size: 0xdc
    // 0x11d0ce4: EnterFrame
    //     0x11d0ce4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0ce8: mov             fp, SP
    // 0x11d0cec: AllocStack(0x30)
    //     0x11d0cec: sub             SP, SP, #0x30
    // 0x11d0cf0: SetupParameters(RenderTransform this /* r1 => r5, fp-0x10 */, dynamic _ /* r5 => r1, fp-0x28 */, [dynamic _ /* r2, fp-0x30 */, dynamic _ /* fp-0x18 */])
    //     0x11d0cf0: stur            x1, [fp, #-8]
    //     0x11d0cf4: mov             x16, x5
    //     0x11d0cf8: mov             x5, x1
    //     0x11d0cfc: mov             x1, x16
    //     0x11d0d00: mov             x4, x2
    //     0x11d0d04: mov             x0, x6
    //     0x11d0d08: stur            x2, [fp, #-0x10]
    //     0x11d0d0c: mov             x2, x7
    //     0x11d0d10: stur            x3, [fp, #-0x18]
    //     0x11d0d14: stur            x1, [fp, #-0x20]
    //     0x11d0d18: stur            x6, [fp, #-0x28]
    //     0x11d0d1c: stur            x7, [fp, #-0x30]
    // 0x11d0d20: CheckStackOverflow
    //     0x11d0d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0d24: cmp             SP, x16
    //     0x11d0d28: b.ls            #0x11d0db8
    // 0x11d0d2c: ldr             x6, [fp, #0x10]
    // 0x11d0d30: StoreField: r5->field_5f = r6
    //     0x11d0d30: stur            w6, [x5, #0x5f]
    // 0x11d0d34: r0 = _LayoutCacheStorage()
    //     0x11d0d34: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d0d38: ldur            x2, [fp, #-8]
    // 0x11d0d3c: StoreField: r2->field_47 = r0
    //     0x11d0d3c: stur            w0, [x2, #0x47]
    //     0x11d0d40: ldurb           w16, [x2, #-1]
    //     0x11d0d44: ldurb           w17, [x0, #-1]
    //     0x11d0d48: and             x16, x17, x16, lsr #2
    //     0x11d0d4c: tst             x16, HEAP, lsr #32
    //     0x11d0d50: b.eq            #0x11d0d58
    //     0x11d0d54: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0d58: mov             x1, x2
    // 0x11d0d5c: r0 = RenderObject()
    //     0x11d0d5c: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d0d60: ldur            x1, [fp, #-8]
    // 0x11d0d64: r2 = Null
    //     0x11d0d64: mov             x2, NULL
    // 0x11d0d68: r0 = child=()
    //     0x11d0d68: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d0d6c: ldur            x1, [fp, #-8]
    // 0x11d0d70: ldur            x2, [fp, #-0x30]
    // 0x11d0d74: r0 = transform=()
    //     0x11d0d74: bl              #0xcf6f88  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::transform=
    // 0x11d0d78: ldur            x1, [fp, #-8]
    // 0x11d0d7c: ldur            x2, [fp, #-0x10]
    // 0x11d0d80: r0 = alignment=()
    //     0x11d0d80: bl              #0xcf6e28  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::alignment=
    // 0x11d0d84: ldur            x1, [fp, #-8]
    // 0x11d0d88: ldur            x2, [fp, #-0x28]
    // 0x11d0d8c: r0 = textDirection=()
    //     0x11d0d8c: bl              #0xcf6da0  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::textDirection=
    // 0x11d0d90: ldur            x1, [fp, #-8]
    // 0x11d0d94: ldur            x2, [fp, #-0x18]
    // 0x11d0d98: r0 = filterQuality=()
    //     0x11d0d98: bl              #0xcf6cc8  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::filterQuality=
    // 0x11d0d9c: ldur            x1, [fp, #-8]
    // 0x11d0da0: ldur            x2, [fp, #-0x20]
    // 0x11d0da4: r0 = origin=()
    //     0x11d0da4: bl              #0xcf6ed8  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::origin=
    // 0x11d0da8: r0 = Null
    //     0x11d0da8: mov             x0, NULL
    // 0x11d0dac: LeaveFrame
    //     0x11d0dac: mov             SP, fp
    //     0x11d0db0: ldp             fp, lr, [SP], #0x10
    // 0x11d0db4: ret
    //     0x11d0db4: ret             
    // 0x11d0db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0dbc: b               #0x11d0d2c
  }
}

// class id: 4928, size: 0x64, field offset: 0x54
class RenderDecoratedBox extends RenderProxyBox {

  _ hitTestSelf(/* No info */) {
    // ** addr: 0xb5d230, size: 0x12c
    // 0xb5d230: EnterFrame
    //     0xb5d230: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d234: mov             fp, SP
    // 0xb5d238: AllocStack(0x28)
    //     0xb5d238: sub             SP, SP, #0x28
    // 0xb5d23c: SetupParameters(RenderDecoratedBox this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb5d23c: mov             x0, x1
    //     0xb5d240: stur            x1, [fp, #-0x10]
    //     0xb5d244: stur            x2, [fp, #-0x18]
    // 0xb5d248: CheckStackOverflow
    //     0xb5d248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5d24c: cmp             SP, x16
    //     0xb5d250: b.ls            #0xb5d354
    // 0xb5d254: LoadField: r3 = r0->field_57
    //     0xb5d254: ldur            w3, [x0, #0x57]
    // 0xb5d258: DecompressPointer r3
    //     0xb5d258: add             x3, x3, HEAP, lsl #32
    // 0xb5d25c: mov             x1, x0
    // 0xb5d260: stur            x3, [fp, #-8]
    // 0xb5d264: r0 = size()
    //     0xb5d264: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb5d268: mov             x1, x0
    // 0xb5d26c: ldur            x0, [fp, #-0x10]
    // 0xb5d270: LoadField: r2 = r0->field_5f
    //     0xb5d270: ldur            w2, [x0, #0x5f]
    // 0xb5d274: DecompressPointer r2
    //     0xb5d274: add             x2, x2, HEAP, lsl #32
    // 0xb5d278: LoadField: r5 = r2->field_13
    //     0xb5d278: ldur            w5, [x2, #0x13]
    // 0xb5d27c: DecompressPointer r5
    //     0xb5d27c: add             x5, x5, HEAP, lsl #32
    // 0xb5d280: ldur            x0, [fp, #-8]
    // 0xb5d284: stur            x5, [fp, #-0x20]
    // 0xb5d288: r2 = LoadClassIdInstr(r0)
    //     0xb5d288: ldur            x2, [x0, #-1]
    //     0xb5d28c: ubfx            x2, x2, #0xc, #0x14
    // 0xb5d290: r17 = -5239
    //     0xb5d290: mov             x17, #-0x1477
    // 0xb5d294: add             x16, x2, x17
    // 0xb5d298: cmp             x16, #1
    // 0xb5d29c: b.hi            #0xb5d2a8
    // 0xb5d2a0: r0 = true
    //     0xb5d2a0: add             x0, NULL, #0x20  ; true
    // 0xb5d2a4: b               #0xb5d348
    // 0xb5d2a8: r17 = 5237
    //     0xb5d2a8: mov             x17, #0x1475
    // 0xb5d2ac: cmp             x2, x17
    // 0xb5d2b0: b.ne            #0xb5d310
    // 0xb5d2b4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb5d2b4: ldur            w3, [x0, #0x17]
    // 0xb5d2b8: DecompressPointer r3
    //     0xb5d2b8: add             x3, x3, HEAP, lsl #32
    // 0xb5d2bc: mov             x2, x1
    // 0xb5d2c0: stur            x3, [fp, #-0x10]
    // 0xb5d2c4: r1 = Instance_Offset
    //     0xb5d2c4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb5d2c8: r0 = &()
    //     0xb5d2c8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb5d2cc: ldur            x1, [fp, #-0x10]
    // 0xb5d2d0: r2 = LoadClassIdInstr(r1)
    //     0xb5d2d0: ldur            x2, [x1, #-1]
    //     0xb5d2d4: ubfx            x2, x2, #0xc, #0x14
    // 0xb5d2d8: ldur            x16, [fp, #-0x20]
    // 0xb5d2dc: str             x16, [SP]
    // 0xb5d2e0: mov             x16, x0
    // 0xb5d2e4: mov             x0, x2
    // 0xb5d2e8: mov             x2, x16
    // 0xb5d2ec: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0xb5d2ec: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0xb5d2f0: ldr             x4, [x4, #0x638]
    // 0xb5d2f4: r0 = GDT[cid_x0 + -0xfc1]()
    //     0xb5d2f4: sub             lr, x0, #0xfc1
    //     0xb5d2f8: ldr             lr, [x21, lr, lsl #3]
    //     0xb5d2fc: blr             lr
    // 0xb5d300: mov             x1, x0
    // 0xb5d304: ldur            x2, [fp, #-0x18]
    // 0xb5d308: r0 = contains()
    //     0xb5d308: bl              #0xaf9104  ; [dart:ui] _NativePath::contains
    // 0xb5d30c: b               #0xb5d348
    // 0xb5d310: r2 = LoadClassIdInstr(r0)
    //     0xb5d310: ldur            x2, [x0, #-1]
    //     0xb5d314: ubfx            x2, x2, #0xc, #0x14
    // 0xb5d318: mov             x16, x1
    // 0xb5d31c: mov             x1, x2
    // 0xb5d320: mov             x2, x16
    // 0xb5d324: mov             x16, x0
    // 0xb5d328: mov             x0, x1
    // 0xb5d32c: mov             x1, x16
    // 0xb5d330: ldur            x3, [fp, #-0x18]
    // 0xb5d334: ldur            x5, [fp, #-0x20]
    // 0xb5d338: r0 = GDT[cid_x0 + 0x1ae7]()
    //     0xb5d338: mov             x17, #0x1ae7
    //     0xb5d33c: add             lr, x0, x17
    //     0xb5d340: ldr             lr, [x21, lr, lsl #3]
    //     0xb5d344: blr             lr
    // 0xb5d348: LeaveFrame
    //     0xb5d348: mov             SP, fp
    //     0xb5d34c: ldp             fp, lr, [SP], #0x10
    // 0xb5d350: ret
    //     0xb5d350: ret             
    // 0xb5d354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d358: b               #0xb5d254
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc02a50, size: 0xb8
    // 0xc02a50: EnterFrame
    //     0xc02a50: stp             fp, lr, [SP, #-0x10]!
    //     0xc02a54: mov             fp, SP
    // 0xc02a58: AllocStack(0x8)
    //     0xc02a58: sub             SP, SP, #8
    // 0xc02a5c: SetupParameters(RenderDecoratedBox this /* r1 => r2, fp-0x8 */)
    //     0xc02a5c: mov             x2, x1
    //     0xc02a60: stur            x1, [fp, #-8]
    // 0xc02a64: CheckStackOverflow
    //     0xc02a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02a68: cmp             SP, x16
    //     0xc02a6c: b.ls            #0xc02b00
    // 0xc02a70: LoadField: r0 = r2->field_53
    //     0xc02a70: ldur            w0, [x2, #0x53]
    // 0xc02a74: DecompressPointer r0
    //     0xc02a74: add             x0, x0, HEAP, lsl #32
    // 0xc02a78: cmp             w0, NULL
    // 0xc02a7c: b.eq            #0xc02ae8
    // 0xc02a80: r1 = LoadClassIdInstr(r0)
    //     0xc02a80: ldur            x1, [x0, #-1]
    //     0xc02a84: ubfx            x1, x1, #0xc, #0x14
    // 0xc02a88: sub             x16, x1, #0xcbb
    // 0xc02a8c: cmp             x16, #1
    // 0xc02a90: b.ls            #0xc02ae8
    // 0xc02a94: cmp             x1, #0xcb9
    // 0xc02a98: b.ne            #0xc02ac4
    // 0xc02a9c: LoadField: r1 = r0->field_33
    //     0xc02a9c: ldur            w1, [x0, #0x33]
    // 0xc02aa0: DecompressPointer r1
    //     0xc02aa0: add             x1, x1, HEAP, lsl #32
    // 0xc02aa4: cmp             w1, NULL
    // 0xc02aa8: b.eq            #0xc02ae8
    // 0xc02aac: r0 = LoadClassIdInstr(r1)
    //     0xc02aac: ldur            x0, [x1, #-1]
    //     0xc02ab0: ubfx            x0, x0, #0xc, #0x14
    // 0xc02ab4: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc02ab4: sub             lr, x0, #0xfb9
    //     0xc02ab8: ldr             lr, [x21, lr, lsl #3]
    //     0xc02abc: blr             lr
    // 0xc02ac0: b               #0xc02ae8
    // 0xc02ac4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc02ac4: ldur            w1, [x0, #0x17]
    // 0xc02ac8: DecompressPointer r1
    //     0xc02ac8: add             x1, x1, HEAP, lsl #32
    // 0xc02acc: cmp             w1, NULL
    // 0xc02ad0: b.eq            #0xc02ae8
    // 0xc02ad4: r0 = LoadClassIdInstr(r1)
    //     0xc02ad4: ldur            x0, [x1, #-1]
    //     0xc02ad8: ubfx            x0, x0, #0xc, #0x14
    // 0xc02adc: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc02adc: sub             lr, x0, #0xfb9
    //     0xc02ae0: ldr             lr, [x21, lr, lsl #3]
    //     0xc02ae4: blr             lr
    // 0xc02ae8: ldur            x1, [fp, #-8]
    // 0xc02aec: r0 = dispose()
    //     0xc02aec: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc02af0: r0 = Null
    //     0xc02af0: mov             x0, NULL
    // 0xc02af4: LeaveFrame
    //     0xc02af4: mov             SP, fp
    //     0xc02af8: ldp             fp, lr, [SP], #0x10
    // 0xc02afc: ret
    //     0xc02afc: ret             
    // 0xc02b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02b00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02b04: b               #0xc02a70
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05d58, size: 0xd0
    // 0xc05d58: EnterFrame
    //     0xc05d58: stp             fp, lr, [SP, #-0x10]!
    //     0xc05d5c: mov             fp, SP
    // 0xc05d60: AllocStack(0x8)
    //     0xc05d60: sub             SP, SP, #8
    // 0xc05d64: SetupParameters(RenderDecoratedBox this /* r1 => r2, fp-0x8 */)
    //     0xc05d64: mov             x2, x1
    //     0xc05d68: stur            x1, [fp, #-8]
    // 0xc05d6c: CheckStackOverflow
    //     0xc05d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05d70: cmp             SP, x16
    //     0xc05d74: b.ls            #0xc05e20
    // 0xc05d78: LoadField: r0 = r2->field_53
    //     0xc05d78: ldur            w0, [x2, #0x53]
    // 0xc05d7c: DecompressPointer r0
    //     0xc05d7c: add             x0, x0, HEAP, lsl #32
    // 0xc05d80: cmp             w0, NULL
    // 0xc05d84: b.ne            #0xc05d90
    // 0xc05d88: mov             x0, x2
    // 0xc05d8c: b               #0xc05dfc
    // 0xc05d90: r1 = LoadClassIdInstr(r0)
    //     0xc05d90: ldur            x1, [x0, #-1]
    //     0xc05d94: ubfx            x1, x1, #0xc, #0x14
    // 0xc05d98: sub             x16, x1, #0xcbb
    // 0xc05d9c: cmp             x16, #1
    // 0xc05da0: b.ls            #0xc05df8
    // 0xc05da4: cmp             x1, #0xcb9
    // 0xc05da8: b.ne            #0xc05dd4
    // 0xc05dac: LoadField: r1 = r0->field_33
    //     0xc05dac: ldur            w1, [x0, #0x33]
    // 0xc05db0: DecompressPointer r1
    //     0xc05db0: add             x1, x1, HEAP, lsl #32
    // 0xc05db4: cmp             w1, NULL
    // 0xc05db8: b.eq            #0xc05df8
    // 0xc05dbc: r0 = LoadClassIdInstr(r1)
    //     0xc05dbc: ldur            x0, [x1, #-1]
    //     0xc05dc0: ubfx            x0, x0, #0xc, #0x14
    // 0xc05dc4: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc05dc4: sub             lr, x0, #0xfb9
    //     0xc05dc8: ldr             lr, [x21, lr, lsl #3]
    //     0xc05dcc: blr             lr
    // 0xc05dd0: b               #0xc05df8
    // 0xc05dd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc05dd4: ldur            w1, [x0, #0x17]
    // 0xc05dd8: DecompressPointer r1
    //     0xc05dd8: add             x1, x1, HEAP, lsl #32
    // 0xc05ddc: cmp             w1, NULL
    // 0xc05de0: b.eq            #0xc05df8
    // 0xc05de4: r0 = LoadClassIdInstr(r1)
    //     0xc05de4: ldur            x0, [x1, #-1]
    //     0xc05de8: ubfx            x0, x0, #0xc, #0x14
    // 0xc05dec: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc05dec: sub             lr, x0, #0xfb9
    //     0xc05df0: ldr             lr, [x21, lr, lsl #3]
    //     0xc05df4: blr             lr
    // 0xc05df8: ldur            x0, [fp, #-8]
    // 0xc05dfc: StoreField: r0->field_53 = rNULL
    //     0xc05dfc: stur            NULL, [x0, #0x53]
    // 0xc05e00: mov             x1, x0
    // 0xc05e04: r0 = detach()
    //     0xc05e04: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc05e08: ldur            x1, [fp, #-8]
    // 0xc05e0c: r0 = markNeedsPaint()
    //     0xc05e0c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xc05e10: r0 = Null
    //     0xc05e10: mov             x0, NULL
    // 0xc05e14: LeaveFrame
    //     0xc05e14: mov             SP, fp
    //     0xc05e18: ldp             fp, lr, [SP], #0x10
    // 0xc05e1c: ret
    //     0xc05e1c: ret             
    // 0xc05e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05e24: b               #0xc05d78
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1bcbc, size: 0x340
    // 0xc1bcbc: EnterFrame
    //     0xc1bcbc: stp             fp, lr, [SP, #-0x10]!
    //     0xc1bcc0: mov             fp, SP
    // 0xc1bcc4: AllocStack(0x30)
    //     0xc1bcc4: sub             SP, SP, #0x30
    // 0xc1bcc8: SetupParameters(RenderDecoratedBox this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xc1bcc8: mov             x4, x1
    //     0xc1bccc: mov             x0, x2
    //     0xc1bcd0: stur            x1, [fp, #-0x10]
    //     0xc1bcd4: stur            x2, [fp, #-0x18]
    //     0xc1bcd8: stur            x3, [fp, #-0x20]
    // 0xc1bcdc: CheckStackOverflow
    //     0xc1bcdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1bce0: cmp             SP, x16
    //     0xc1bce4: b.ls            #0xc1bfec
    // 0xc1bce8: LoadField: r1 = r4->field_53
    //     0xc1bce8: ldur            w1, [x4, #0x53]
    // 0xc1bcec: DecompressPointer r1
    //     0xc1bcec: add             x1, x1, HEAP, lsl #32
    // 0xc1bcf0: cmp             w1, NULL
    // 0xc1bcf4: b.ne            #0xc1be1c
    // 0xc1bcf8: LoadField: r5 = r4->field_57
    //     0xc1bcf8: ldur            w5, [x4, #0x57]
    // 0xc1bcfc: DecompressPointer r5
    //     0xc1bcfc: add             x5, x5, HEAP, lsl #32
    // 0xc1bd00: mov             x2, x4
    // 0xc1bd04: stur            x5, [fp, #-8]
    // 0xc1bd08: r1 = Function 'markNeedsPaint':.
    //     0xc1bd08: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc1bd0c: ldr             x1, [x1, #0x1f0]
    // 0xc1bd10: r0 = AllocateClosure()
    //     0xc1bd10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1bd14: mov             x1, x0
    // 0xc1bd18: ldur            x0, [fp, #-8]
    // 0xc1bd1c: stur            x1, [fp, #-0x28]
    // 0xc1bd20: r2 = LoadClassIdInstr(r0)
    //     0xc1bd20: ldur            x2, [x0, #-1]
    //     0xc1bd24: ubfx            x2, x2, #0xc, #0x14
    // 0xc1bd28: r17 = 5237
    //     0xc1bd28: mov             x17, #0x1475
    // 0xc1bd2c: cmp             x2, x17
    // 0xc1bd30: b.ne            #0xc1bd68
    // 0xc1bd34: r0 = _ShapeDecorationPainter()
    //     0xc1bd34: bl              #0xb7a684  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0xc1bd38: mov             x1, x0
    // 0xc1bd3c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1bd40: ArrayStore: r1[0] = r0  ; List_4
    //     0xc1bd40: stur            w0, [x1, #0x17]
    // 0xc1bd44: StoreField: r1->field_27 = r0
    //     0xc1bd44: stur            w0, [x1, #0x27]
    // 0xc1bd48: StoreField: r1->field_2b = r0
    //     0xc1bd48: stur            w0, [x1, #0x2b]
    // 0xc1bd4c: StoreField: r1->field_2f = r0
    //     0xc1bd4c: stur            w0, [x1, #0x2f]
    // 0xc1bd50: ldur            x0, [fp, #-8]
    // 0xc1bd54: StoreField: r1->field_b = r0
    //     0xc1bd54: stur            w0, [x1, #0xb]
    // 0xc1bd58: ldur            x3, [fp, #-0x28]
    // 0xc1bd5c: StoreField: r1->field_7 = r3
    //     0xc1bd5c: stur            w3, [x1, #7]
    // 0xc1bd60: mov             x0, x1
    // 0xc1bd64: b               #0xc1bdf8
    // 0xc1bd68: mov             x3, x1
    // 0xc1bd6c: r17 = 5238
    //     0xc1bd6c: mov             x17, #0x1476
    // 0xc1bd70: cmp             x2, x17
    // 0xc1bd74: b.ne            #0xc1bd98
    // 0xc1bd78: r0 = _BoxDecorationPainter()
    //     0xc1bd78: bl              #0xb7a678  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0xc1bd7c: mov             x1, x0
    // 0xc1bd80: ldur            x0, [fp, #-8]
    // 0xc1bd84: StoreField: r1->field_b = r0
    //     0xc1bd84: stur            w0, [x1, #0xb]
    // 0xc1bd88: ldur            x3, [fp, #-0x28]
    // 0xc1bd8c: StoreField: r1->field_7 = r3
    //     0xc1bd8c: stur            w3, [x1, #7]
    // 0xc1bd90: mov             x0, x1
    // 0xc1bd94: b               #0xc1bdf8
    // 0xc1bd98: r17 = 5239
    //     0xc1bd98: mov             x17, #0x1477
    // 0xc1bd9c: cmp             x2, x17
    // 0xc1bda0: b.ne            #0xc1bdd8
    // 0xc1bda4: LoadField: r1 = r0->field_7
    //     0xc1bda4: ldur            w1, [x0, #7]
    // 0xc1bda8: DecompressPointer r1
    //     0xc1bda8: add             x1, x1, HEAP, lsl #32
    // 0xc1bdac: stur            x1, [fp, #-0x30]
    // 0xc1bdb0: r0 = _UnderlinePainter()
    //     0xc1bdb0: bl              #0xb7a66c  ; Allocate_UnderlinePainterStub -> _UnderlinePainter (size=0x14)
    // 0xc1bdb4: mov             x1, x0
    // 0xc1bdb8: ldur            x0, [fp, #-8]
    // 0xc1bdbc: StoreField: r1->field_b = r0
    //     0xc1bdbc: stur            w0, [x1, #0xb]
    // 0xc1bdc0: ldur            x0, [fp, #-0x30]
    // 0xc1bdc4: StoreField: r1->field_f = r0
    //     0xc1bdc4: stur            w0, [x1, #0xf]
    // 0xc1bdc8: ldur            x2, [fp, #-0x28]
    // 0xc1bdcc: StoreField: r1->field_7 = r2
    //     0xc1bdcc: stur            w2, [x1, #7]
    // 0xc1bdd0: mov             x0, x1
    // 0xc1bdd4: b               #0xc1bdf8
    // 0xc1bdd8: mov             x2, x3
    // 0xc1bddc: r0 = _CupertinoEdgeShadowPainter()
    //     0xc1bddc: bl              #0xb7a660  ; Allocate_CupertinoEdgeShadowPainterStub -> _CupertinoEdgeShadowPainter (size=0x10)
    // 0xc1bde0: mov             x1, x0
    // 0xc1bde4: ldur            x0, [fp, #-8]
    // 0xc1bde8: StoreField: r1->field_b = r0
    //     0xc1bde8: stur            w0, [x1, #0xb]
    // 0xc1bdec: ldur            x0, [fp, #-0x28]
    // 0xc1bdf0: StoreField: r1->field_7 = r0
    //     0xc1bdf0: stur            w0, [x1, #7]
    // 0xc1bdf4: mov             x0, x1
    // 0xc1bdf8: ldur            x2, [fp, #-0x10]
    // 0xc1bdfc: StoreField: r2->field_53 = r0
    //     0xc1bdfc: stur            w0, [x2, #0x53]
    //     0xc1be00: ldurb           w16, [x2, #-1]
    //     0xc1be04: ldurb           w17, [x0, #-1]
    //     0xc1be08: and             x16, x17, x16, lsr #2
    //     0xc1be0c: tst             x16, HEAP, lsr #32
    //     0xc1be10: b.eq            #0xc1be18
    //     0xc1be14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc1be18: b               #0xc1be20
    // 0xc1be1c: mov             x2, x4
    // 0xc1be20: LoadField: r0 = r2->field_5f
    //     0xc1be20: ldur            w0, [x2, #0x5f]
    // 0xc1be24: DecompressPointer r0
    //     0xc1be24: add             x0, x0, HEAP, lsl #32
    // 0xc1be28: mov             x1, x2
    // 0xc1be2c: stur            x0, [fp, #-8]
    // 0xc1be30: r0 = size()
    //     0xc1be30: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1be34: ldur            x1, [fp, #-8]
    // 0xc1be38: mov             x2, x0
    // 0xc1be3c: r0 = copyWith()
    //     0xc1be3c: bl              #0xb6d728  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::copyWith
    // 0xc1be40: mov             x2, x0
    // 0xc1be44: ldur            x0, [fp, #-0x10]
    // 0xc1be48: stur            x2, [fp, #-0x28]
    // 0xc1be4c: LoadField: r1 = r0->field_5b
    //     0xc1be4c: ldur            w1, [x0, #0x5b]
    // 0xc1be50: DecompressPointer r1
    //     0xc1be50: add             x1, x1, HEAP, lsl #32
    // 0xc1be54: r16 = Instance_DecorationPosition
    //     0xc1be54: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xc1be58: ldr             x16, [x16, #0xef0]
    // 0xc1be5c: cmp             w1, w16
    // 0xc1be60: b.ne            #0xc1bf08
    // 0xc1be64: LoadField: r3 = r0->field_53
    //     0xc1be64: ldur            w3, [x0, #0x53]
    // 0xc1be68: DecompressPointer r3
    //     0xc1be68: add             x3, x3, HEAP, lsl #32
    // 0xc1be6c: stur            x3, [fp, #-8]
    // 0xc1be70: cmp             w3, NULL
    // 0xc1be74: b.eq            #0xc1bff4
    // 0xc1be78: ldur            x1, [fp, #-0x18]
    // 0xc1be7c: r0 = canvas()
    //     0xc1be7c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1be80: ldur            x1, [fp, #-8]
    // 0xc1be84: r2 = LoadClassIdInstr(r1)
    //     0xc1be84: ldur            x2, [x1, #-1]
    //     0xc1be88: ubfx            x2, x2, #0xc, #0x14
    // 0xc1be8c: mov             x16, x0
    // 0xc1be90: mov             x0, x2
    // 0xc1be94: mov             x2, x16
    // 0xc1be98: ldur            x3, [fp, #-0x20]
    // 0xc1be9c: ldur            x5, [fp, #-0x28]
    // 0xc1bea0: r0 = GDT[cid_x0 + -0xffc]()
    //     0xc1bea0: sub             lr, x0, #0xffc
    //     0xc1bea4: ldr             lr, [x21, lr, lsl #3]
    //     0xc1bea8: blr             lr
    // 0xc1beac: ldur            x0, [fp, #-0x10]
    // 0xc1beb0: LoadField: r1 = r0->field_57
    //     0xc1beb0: ldur            w1, [x0, #0x57]
    // 0xc1beb4: DecompressPointer r1
    //     0xc1beb4: add             x1, x1, HEAP, lsl #32
    // 0xc1beb8: r2 = LoadClassIdInstr(r1)
    //     0xc1beb8: ldur            x2, [x1, #-1]
    //     0xc1bebc: ubfx            x2, x2, #0xc, #0x14
    // 0xc1bec0: r17 = -5239
    //     0xc1bec0: mov             x17, #-0x1477
    // 0xc1bec4: add             x16, x2, x17
    // 0xc1bec8: cmp             x16, #1
    // 0xc1becc: b.ls            #0xc1bf08
    // 0xc1bed0: r17 = 5237
    //     0xc1bed0: mov             x17, #0x1475
    // 0xc1bed4: cmp             x2, x17
    // 0xc1bed8: b.ne            #0xc1bef0
    // 0xc1bedc: LoadField: r2 = r1->field_13
    //     0xc1bedc: ldur            w2, [x1, #0x13]
    // 0xc1bee0: DecompressPointer r2
    //     0xc1bee0: add             x2, x2, HEAP, lsl #32
    // 0xc1bee4: cmp             w2, NULL
    // 0xc1bee8: b.eq            #0xc1bf08
    // 0xc1beec: b               #0xc1bf00
    // 0xc1bef0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xc1bef0: ldur            w2, [x1, #0x17]
    // 0xc1bef4: DecompressPointer r2
    //     0xc1bef4: add             x2, x2, HEAP, lsl #32
    // 0xc1bef8: cmp             w2, NULL
    // 0xc1befc: b.eq            #0xc1bf08
    // 0xc1bf00: ldur            x1, [fp, #-0x18]
    // 0xc1bf04: r0 = setIsComplexHint()
    //     0xc1bf04: bl              #0xc1bffc  ; [package:flutter/src/rendering/object.dart] PaintingContext::setIsComplexHint
    // 0xc1bf08: ldur            x0, [fp, #-0x10]
    // 0xc1bf0c: mov             x1, x0
    // 0xc1bf10: ldur            x2, [fp, #-0x18]
    // 0xc1bf14: ldur            x3, [fp, #-0x20]
    // 0xc1bf18: r0 = paint()
    //     0xc1bf18: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1bf1c: ldur            x0, [fp, #-0x10]
    // 0xc1bf20: LoadField: r1 = r0->field_5b
    //     0xc1bf20: ldur            w1, [x0, #0x5b]
    // 0xc1bf24: DecompressPointer r1
    //     0xc1bf24: add             x1, x1, HEAP, lsl #32
    // 0xc1bf28: r16 = Instance_DecorationPosition
    //     0xc1bf28: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ef8] Obj!DecorationPosition@12c4361
    //     0xc1bf2c: ldr             x16, [x16, #0xef8]
    // 0xc1bf30: cmp             w1, w16
    // 0xc1bf34: b.ne            #0xc1bfdc
    // 0xc1bf38: LoadField: r2 = r0->field_53
    //     0xc1bf38: ldur            w2, [x0, #0x53]
    // 0xc1bf3c: DecompressPointer r2
    //     0xc1bf3c: add             x2, x2, HEAP, lsl #32
    // 0xc1bf40: stur            x2, [fp, #-8]
    // 0xc1bf44: cmp             w2, NULL
    // 0xc1bf48: b.eq            #0xc1bff8
    // 0xc1bf4c: ldur            x1, [fp, #-0x18]
    // 0xc1bf50: r0 = canvas()
    //     0xc1bf50: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1bf54: ldur            x1, [fp, #-8]
    // 0xc1bf58: r2 = LoadClassIdInstr(r1)
    //     0xc1bf58: ldur            x2, [x1, #-1]
    //     0xc1bf5c: ubfx            x2, x2, #0xc, #0x14
    // 0xc1bf60: mov             x16, x0
    // 0xc1bf64: mov             x0, x2
    // 0xc1bf68: mov             x2, x16
    // 0xc1bf6c: ldur            x3, [fp, #-0x20]
    // 0xc1bf70: ldur            x5, [fp, #-0x28]
    // 0xc1bf74: r0 = GDT[cid_x0 + -0xffc]()
    //     0xc1bf74: sub             lr, x0, #0xffc
    //     0xc1bf78: ldr             lr, [x21, lr, lsl #3]
    //     0xc1bf7c: blr             lr
    // 0xc1bf80: ldur            x0, [fp, #-0x10]
    // 0xc1bf84: LoadField: r1 = r0->field_57
    //     0xc1bf84: ldur            w1, [x0, #0x57]
    // 0xc1bf88: DecompressPointer r1
    //     0xc1bf88: add             x1, x1, HEAP, lsl #32
    // 0xc1bf8c: r0 = LoadClassIdInstr(r1)
    //     0xc1bf8c: ldur            x0, [x1, #-1]
    //     0xc1bf90: ubfx            x0, x0, #0xc, #0x14
    // 0xc1bf94: r17 = -5239
    //     0xc1bf94: mov             x17, #-0x1477
    // 0xc1bf98: add             x16, x0, x17
    // 0xc1bf9c: cmp             x16, #1
    // 0xc1bfa0: b.ls            #0xc1bfdc
    // 0xc1bfa4: r17 = 5237
    //     0xc1bfa4: mov             x17, #0x1475
    // 0xc1bfa8: cmp             x0, x17
    // 0xc1bfac: b.ne            #0xc1bfc4
    // 0xc1bfb0: LoadField: r0 = r1->field_13
    //     0xc1bfb0: ldur            w0, [x1, #0x13]
    // 0xc1bfb4: DecompressPointer r0
    //     0xc1bfb4: add             x0, x0, HEAP, lsl #32
    // 0xc1bfb8: cmp             w0, NULL
    // 0xc1bfbc: b.eq            #0xc1bfdc
    // 0xc1bfc0: b               #0xc1bfd4
    // 0xc1bfc4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xc1bfc4: ldur            w0, [x1, #0x17]
    // 0xc1bfc8: DecompressPointer r0
    //     0xc1bfc8: add             x0, x0, HEAP, lsl #32
    // 0xc1bfcc: cmp             w0, NULL
    // 0xc1bfd0: b.eq            #0xc1bfdc
    // 0xc1bfd4: ldur            x1, [fp, #-0x18]
    // 0xc1bfd8: r0 = setIsComplexHint()
    //     0xc1bfd8: bl              #0xc1bffc  ; [package:flutter/src/rendering/object.dart] PaintingContext::setIsComplexHint
    // 0xc1bfdc: r0 = Null
    //     0xc1bfdc: mov             x0, NULL
    // 0xc1bfe0: LeaveFrame
    //     0xc1bfe0: mov             SP, fp
    //     0xc1bfe4: ldp             fp, lr, [SP], #0x10
    // 0xc1bfe8: ret
    //     0xc1bfe8: ret             
    // 0xc1bfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1bfec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1bff0: b               #0xc1bce8
    // 0xc1bff4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1bff4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1bff8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1bff8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ position=(/* No info */) {
    // ** addr: 0xcf9d3c, size: 0x70
    // 0xcf9d3c: EnterFrame
    //     0xcf9d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9d40: mov             fp, SP
    // 0xcf9d44: mov             x0, x2
    // 0xcf9d48: CheckStackOverflow
    //     0xcf9d48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9d4c: cmp             SP, x16
    //     0xcf9d50: b.ls            #0xcf9da4
    // 0xcf9d54: LoadField: r2 = r1->field_5b
    //     0xcf9d54: ldur            w2, [x1, #0x5b]
    // 0xcf9d58: DecompressPointer r2
    //     0xcf9d58: add             x2, x2, HEAP, lsl #32
    // 0xcf9d5c: cmp             w0, w2
    // 0xcf9d60: b.ne            #0xcf9d74
    // 0xcf9d64: r0 = Null
    //     0xcf9d64: mov             x0, NULL
    // 0xcf9d68: LeaveFrame
    //     0xcf9d68: mov             SP, fp
    //     0xcf9d6c: ldp             fp, lr, [SP], #0x10
    // 0xcf9d70: ret
    //     0xcf9d70: ret             
    // 0xcf9d74: StoreField: r1->field_5b = r0
    //     0xcf9d74: stur            w0, [x1, #0x5b]
    //     0xcf9d78: ldurb           w16, [x1, #-1]
    //     0xcf9d7c: ldurb           w17, [x0, #-1]
    //     0xcf9d80: and             x16, x17, x16, lsr #2
    //     0xcf9d84: tst             x16, HEAP, lsr #32
    //     0xcf9d88: b.eq            #0xcf9d90
    //     0xcf9d8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf9d90: r0 = markNeedsPaint()
    //     0xcf9d90: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf9d94: r0 = Null
    //     0xcf9d94: mov             x0, NULL
    // 0xcf9d98: LeaveFrame
    //     0xcf9d98: mov             SP, fp
    //     0xcf9d9c: ldp             fp, lr, [SP], #0x10
    // 0xcf9da0: ret
    //     0xcf9da0: ret             
    // 0xcf9da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9da4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9da8: b               #0xcf9d54
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0xcf9dac, size: 0x88
    // 0xcf9dac: EnterFrame
    //     0xcf9dac: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9db0: mov             fp, SP
    // 0xcf9db4: AllocStack(0x20)
    //     0xcf9db4: sub             SP, SP, #0x20
    // 0xcf9db8: SetupParameters(RenderDecoratedBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf9db8: mov             x0, x2
    //     0xcf9dbc: stur            x1, [fp, #-8]
    //     0xcf9dc0: stur            x2, [fp, #-0x10]
    // 0xcf9dc4: CheckStackOverflow
    //     0xcf9dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9dc8: cmp             SP, x16
    //     0xcf9dcc: b.ls            #0xcf9e2c
    // 0xcf9dd0: LoadField: r2 = r1->field_5f
    //     0xcf9dd0: ldur            w2, [x1, #0x5f]
    // 0xcf9dd4: DecompressPointer r2
    //     0xcf9dd4: add             x2, x2, HEAP, lsl #32
    // 0xcf9dd8: stp             x2, x0, [SP]
    // 0xcf9ddc: r0 = ==()
    //     0xcf9ddc: bl              #0x1299204  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0xcf9de0: tbnz            w0, #4, #0xcf9df4
    // 0xcf9de4: r0 = Null
    //     0xcf9de4: mov             x0, NULL
    // 0xcf9de8: LeaveFrame
    //     0xcf9de8: mov             SP, fp
    //     0xcf9dec: ldp             fp, lr, [SP], #0x10
    // 0xcf9df0: ret
    //     0xcf9df0: ret             
    // 0xcf9df4: ldur            x1, [fp, #-8]
    // 0xcf9df8: ldur            x0, [fp, #-0x10]
    // 0xcf9dfc: StoreField: r1->field_5f = r0
    //     0xcf9dfc: stur            w0, [x1, #0x5f]
    //     0xcf9e00: ldurb           w16, [x1, #-1]
    //     0xcf9e04: ldurb           w17, [x0, #-1]
    //     0xcf9e08: and             x16, x17, x16, lsr #2
    //     0xcf9e0c: tst             x16, HEAP, lsr #32
    //     0xcf9e10: b.eq            #0xcf9e18
    //     0xcf9e14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf9e18: r0 = markNeedsPaint()
    //     0xcf9e18: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf9e1c: r0 = Null
    //     0xcf9e1c: mov             x0, NULL
    // 0xcf9e20: LeaveFrame
    //     0xcf9e20: mov             SP, fp
    //     0xcf9e24: ldp             fp, lr, [SP], #0x10
    // 0xcf9e28: ret
    //     0xcf9e28: ret             
    // 0xcf9e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9e30: b               #0xcf9dd0
  }
  set _ decoration=(/* No info */) {
    // ** addr: 0xcfa068, size: 0x1ec
    // 0xcfa068: EnterFrame
    //     0xcfa068: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa06c: mov             fp, SP
    // 0xcfa070: AllocStack(0x28)
    //     0xcfa070: sub             SP, SP, #0x28
    // 0xcfa074: SetupParameters(RenderDecoratedBox this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcfa074: mov             x0, x2
    //     0xcfa078: stur            x1, [fp, #-0x10]
    //     0xcfa07c: stur            x2, [fp, #-0x18]
    // 0xcfa080: CheckStackOverflow
    //     0xcfa080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfa084: cmp             SP, x16
    //     0xcfa088: b.ls            #0xcfa24c
    // 0xcfa08c: LoadField: r2 = r1->field_57
    //     0xcfa08c: ldur            w2, [x1, #0x57]
    // 0xcfa090: DecompressPointer r2
    //     0xcfa090: add             x2, x2, HEAP, lsl #32
    // 0xcfa094: stur            x2, [fp, #-8]
    // 0xcfa098: r3 = LoadClassIdInstr(r0)
    //     0xcfa098: ldur            x3, [x0, #-1]
    //     0xcfa09c: ubfx            x3, x3, #0xc, #0x14
    // 0xcfa0a0: r17 = 5239
    //     0xcfa0a0: mov             x17, #0x1477
    // 0xcfa0a4: cmp             x3, x17
    // 0xcfa0a8: b.ne            #0xcfa0bc
    // 0xcfa0ac: cmp             w0, w2
    // 0xcfa0b0: b.eq            #0xcfa17c
    // 0xcfa0b4: mov             x2, x1
    // 0xcfa0b8: b               #0xcfa190
    // 0xcfa0bc: r17 = 5240
    //     0xcfa0bc: mov             x17, #0x1478
    // 0xcfa0c0: cmp             x3, x17
    // 0xcfa0c4: b.ne            #0xcfa154
    // 0xcfa0c8: str             x2, [SP]
    // 0xcfa0cc: r0 = runtimeType()
    //     0xcfa0cc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xcfa0d0: r1 = LoadClassIdInstr(r0)
    //     0xcfa0d0: ldur            x1, [x0, #-1]
    //     0xcfa0d4: ubfx            x1, x1, #0xc, #0x14
    // 0xcfa0d8: r16 = _CupertinoEdgeShadowDecoration
    //     0xcfa0d8: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d188] Type: _CupertinoEdgeShadowDecoration
    //     0xcfa0dc: ldr             x16, [x16, #0x188]
    // 0xcfa0e0: stp             x16, x0, [SP]
    // 0xcfa0e4: mov             x0, x1
    // 0xcfa0e8: mov             lr, x0
    // 0xcfa0ec: ldr             lr, [x21, lr, lsl #3]
    // 0xcfa0f0: blr             lr
    // 0xcfa0f4: tbz             w0, #4, #0xcfa100
    // 0xcfa0f8: ldur            x2, [fp, #-0x10]
    // 0xcfa0fc: b               #0xcfa190
    // 0xcfa100: ldur            x0, [fp, #-8]
    // 0xcfa104: r1 = LoadClassIdInstr(r0)
    //     0xcfa104: ldur            x1, [x0, #-1]
    //     0xcfa108: ubfx            x1, x1, #0xc, #0x14
    // 0xcfa10c: r17 = 5240
    //     0xcfa10c: mov             x17, #0x1478
    // 0xcfa110: cmp             x1, x17
    // 0xcfa114: b.ne            #0xcfa14c
    // 0xcfa118: ldur            x1, [fp, #-0x18]
    // 0xcfa11c: LoadField: r2 = r0->field_7
    //     0xcfa11c: ldur            w2, [x0, #7]
    // 0xcfa120: DecompressPointer r2
    //     0xcfa120: add             x2, x2, HEAP, lsl #32
    // 0xcfa124: LoadField: r0 = r1->field_7
    //     0xcfa124: ldur            w0, [x1, #7]
    // 0xcfa128: DecompressPointer r0
    //     0xcfa128: add             x0, x0, HEAP, lsl #32
    // 0xcfa12c: r3 = LoadClassIdInstr(r2)
    //     0xcfa12c: ldur            x3, [x2, #-1]
    //     0xcfa130: ubfx            x3, x3, #0xc, #0x14
    // 0xcfa134: stp             x0, x2, [SP]
    // 0xcfa138: mov             x0, x3
    // 0xcfa13c: mov             lr, x0
    // 0xcfa140: ldr             lr, [x21, lr, lsl #3]
    // 0xcfa144: blr             lr
    // 0xcfa148: tbz             w0, #4, #0xcfa17c
    // 0xcfa14c: ldur            x2, [fp, #-0x10]
    // 0xcfa150: b               #0xcfa190
    // 0xcfa154: mov             x1, x0
    // 0xcfa158: mov             x0, x2
    // 0xcfa15c: r2 = LoadClassIdInstr(r1)
    //     0xcfa15c: ldur            x2, [x1, #-1]
    //     0xcfa160: ubfx            x2, x2, #0xc, #0x14
    // 0xcfa164: stp             x0, x1, [SP]
    // 0xcfa168: mov             x0, x2
    // 0xcfa16c: mov             lr, x0
    // 0xcfa170: ldr             lr, [x21, lr, lsl #3]
    // 0xcfa174: blr             lr
    // 0xcfa178: tbnz            w0, #4, #0xcfa18c
    // 0xcfa17c: r0 = Null
    //     0xcfa17c: mov             x0, NULL
    // 0xcfa180: LeaveFrame
    //     0xcfa180: mov             SP, fp
    //     0xcfa184: ldp             fp, lr, [SP], #0x10
    // 0xcfa188: ret
    //     0xcfa188: ret             
    // 0xcfa18c: ldur            x2, [fp, #-0x10]
    // 0xcfa190: LoadField: r0 = r2->field_53
    //     0xcfa190: ldur            w0, [x2, #0x53]
    // 0xcfa194: DecompressPointer r0
    //     0xcfa194: add             x0, x0, HEAP, lsl #32
    // 0xcfa198: cmp             w0, NULL
    // 0xcfa19c: b.ne            #0xcfa1a8
    // 0xcfa1a0: mov             x1, x2
    // 0xcfa1a4: b               #0xcfa214
    // 0xcfa1a8: r1 = LoadClassIdInstr(r0)
    //     0xcfa1a8: ldur            x1, [x0, #-1]
    //     0xcfa1ac: ubfx            x1, x1, #0xc, #0x14
    // 0xcfa1b0: sub             x16, x1, #0xcbb
    // 0xcfa1b4: cmp             x16, #1
    // 0xcfa1b8: b.ls            #0xcfa210
    // 0xcfa1bc: cmp             x1, #0xcb9
    // 0xcfa1c0: b.ne            #0xcfa1ec
    // 0xcfa1c4: LoadField: r1 = r0->field_33
    //     0xcfa1c4: ldur            w1, [x0, #0x33]
    // 0xcfa1c8: DecompressPointer r1
    //     0xcfa1c8: add             x1, x1, HEAP, lsl #32
    // 0xcfa1cc: cmp             w1, NULL
    // 0xcfa1d0: b.eq            #0xcfa210
    // 0xcfa1d4: r0 = LoadClassIdInstr(r1)
    //     0xcfa1d4: ldur            x0, [x1, #-1]
    //     0xcfa1d8: ubfx            x0, x0, #0xc, #0x14
    // 0xcfa1dc: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xcfa1dc: sub             lr, x0, #0xfb9
    //     0xcfa1e0: ldr             lr, [x21, lr, lsl #3]
    //     0xcfa1e4: blr             lr
    // 0xcfa1e8: b               #0xcfa210
    // 0xcfa1ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcfa1ec: ldur            w1, [x0, #0x17]
    // 0xcfa1f0: DecompressPointer r1
    //     0xcfa1f0: add             x1, x1, HEAP, lsl #32
    // 0xcfa1f4: cmp             w1, NULL
    // 0xcfa1f8: b.eq            #0xcfa210
    // 0xcfa1fc: r0 = LoadClassIdInstr(r1)
    //     0xcfa1fc: ldur            x0, [x1, #-1]
    //     0xcfa200: ubfx            x0, x0, #0xc, #0x14
    // 0xcfa204: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xcfa204: sub             lr, x0, #0xfb9
    //     0xcfa208: ldr             lr, [x21, lr, lsl #3]
    //     0xcfa20c: blr             lr
    // 0xcfa210: ldur            x1, [fp, #-0x10]
    // 0xcfa214: StoreField: r1->field_53 = rNULL
    //     0xcfa214: stur            NULL, [x1, #0x53]
    // 0xcfa218: ldur            x0, [fp, #-0x18]
    // 0xcfa21c: StoreField: r1->field_57 = r0
    //     0xcfa21c: stur            w0, [x1, #0x57]
    //     0xcfa220: ldurb           w16, [x1, #-1]
    //     0xcfa224: ldurb           w17, [x0, #-1]
    //     0xcfa228: and             x16, x17, x16, lsr #2
    //     0xcfa22c: tst             x16, HEAP, lsr #32
    //     0xcfa230: b.eq            #0xcfa238
    //     0xcfa234: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfa238: r0 = markNeedsPaint()
    //     0xcfa238: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcfa23c: r0 = Null
    //     0xcfa23c: mov             x0, NULL
    // 0xcfa240: LeaveFrame
    //     0xcfa240: mov             SP, fp
    //     0xcfa244: ldp             fp, lr, [SP], #0x10
    // 0xcfa248: ret
    //     0xcfa248: ret             
    // 0xcfa24c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa24c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa250: b               #0xcfa08c
  }
  _ RenderDecoratedBox(/* No info */) {
    // ** addr: 0x11d2be0, size: 0xd4
    // 0x11d2be0: EnterFrame
    //     0x11d2be0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2be4: mov             fp, SP
    // 0x11d2be8: AllocStack(0x8)
    //     0x11d2be8: sub             SP, SP, #8
    // 0x11d2bec: SetupParameters(RenderDecoratedBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r3 => r0 */, dynamic _ /* r5 => r1 */)
    //     0x11d2bec: mov             x0, x3
    //     0x11d2bf0: mov             x3, x1
    //     0x11d2bf4: stur            x1, [fp, #-8]
    //     0x11d2bf8: mov             x1, x5
    // 0x11d2bfc: CheckStackOverflow
    //     0x11d2bfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2c00: cmp             SP, x16
    //     0x11d2c04: b.ls            #0x11d2cac
    // 0x11d2c08: StoreField: r3->field_57 = r0
    //     0x11d2c08: stur            w0, [x3, #0x57]
    //     0x11d2c0c: ldurb           w16, [x3, #-1]
    //     0x11d2c10: ldurb           w17, [x0, #-1]
    //     0x11d2c14: and             x16, x17, x16, lsr #2
    //     0x11d2c18: tst             x16, HEAP, lsr #32
    //     0x11d2c1c: b.eq            #0x11d2c24
    //     0x11d2c20: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d2c24: mov             x0, x1
    // 0x11d2c28: StoreField: r3->field_5b = r0
    //     0x11d2c28: stur            w0, [x3, #0x5b]
    //     0x11d2c2c: ldurb           w16, [x3, #-1]
    //     0x11d2c30: ldurb           w17, [x0, #-1]
    //     0x11d2c34: and             x16, x17, x16, lsr #2
    //     0x11d2c38: tst             x16, HEAP, lsr #32
    //     0x11d2c3c: b.eq            #0x11d2c44
    //     0x11d2c40: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d2c44: mov             x0, x2
    // 0x11d2c48: StoreField: r3->field_5f = r0
    //     0x11d2c48: stur            w0, [x3, #0x5f]
    //     0x11d2c4c: ldurb           w16, [x3, #-1]
    //     0x11d2c50: ldurb           w17, [x0, #-1]
    //     0x11d2c54: and             x16, x17, x16, lsr #2
    //     0x11d2c58: tst             x16, HEAP, lsr #32
    //     0x11d2c5c: b.eq            #0x11d2c64
    //     0x11d2c60: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d2c64: r0 = _LayoutCacheStorage()
    //     0x11d2c64: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d2c68: ldur            x2, [fp, #-8]
    // 0x11d2c6c: StoreField: r2->field_47 = r0
    //     0x11d2c6c: stur            w0, [x2, #0x47]
    //     0x11d2c70: ldurb           w16, [x2, #-1]
    //     0x11d2c74: ldurb           w17, [x0, #-1]
    //     0x11d2c78: and             x16, x17, x16, lsr #2
    //     0x11d2c7c: tst             x16, HEAP, lsr #32
    //     0x11d2c80: b.eq            #0x11d2c88
    //     0x11d2c84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d2c88: mov             x1, x2
    // 0x11d2c8c: r0 = RenderObject()
    //     0x11d2c8c: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d2c90: ldur            x1, [fp, #-8]
    // 0x11d2c94: r2 = Null
    //     0x11d2c94: mov             x2, NULL
    // 0x11d2c98: r0 = child=()
    //     0x11d2c98: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d2c9c: r0 = Null
    //     0x11d2c9c: mov             x0, NULL
    // 0x11d2ca0: LeaveFrame
    //     0x11d2ca0: mov             SP, fp
    //     0x11d2ca4: ldp             fp, lr, [SP], #0x10
    // 0x11d2ca8: ret
    //     0x11d2ca8: ret             
    // 0x11d2cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2cac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2cb0: b               #0x11d2c08
  }
}

// class id: 4929, size: 0x68, field offset: 0x54
abstract class _RenderCustomClip<X0> extends RenderProxyBox {

  _ _updateClip(/* No info */) {
    // ** addr: 0xaf847c, size: 0xe0
    // 0xaf847c: EnterFrame
    //     0xaf847c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8480: mov             fp, SP
    // 0xaf8484: AllocStack(0x10)
    //     0xaf8484: sub             SP, SP, #0x10
    // 0xaf8488: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x10 */)
    //     0xaf8488: mov             x0, x1
    //     0xaf848c: stur            x1, [fp, #-0x10]
    // 0xaf8490: CheckStackOverflow
    //     0xaf8490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8494: cmp             SP, x16
    //     0xaf8498: b.ls            #0xaf8554
    // 0xaf849c: LoadField: r1 = r0->field_5b
    //     0xaf849c: ldur            w1, [x0, #0x5b]
    // 0xaf84a0: DecompressPointer r1
    //     0xaf84a0: add             x1, x1, HEAP, lsl #32
    // 0xaf84a4: cmp             w1, NULL
    // 0xaf84a8: b.ne            #0xaf8544
    // 0xaf84ac: LoadField: r2 = r0->field_57
    //     0xaf84ac: ldur            w2, [x0, #0x57]
    // 0xaf84b0: DecompressPointer r2
    //     0xaf84b0: add             x2, x2, HEAP, lsl #32
    // 0xaf84b4: stur            x2, [fp, #-8]
    // 0xaf84b8: cmp             w2, NULL
    // 0xaf84bc: b.ne            #0xaf84c8
    // 0xaf84c0: r0 = Null
    //     0xaf84c0: mov             x0, NULL
    // 0xaf84c4: b               #0xaf84f8
    // 0xaf84c8: mov             x1, x0
    // 0xaf84cc: r0 = size()
    //     0xaf84cc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xaf84d0: ldur            x1, [fp, #-8]
    // 0xaf84d4: r2 = LoadClassIdInstr(r1)
    //     0xaf84d4: ldur            x2, [x1, #-1]
    //     0xaf84d8: ubfx            x2, x2, #0xc, #0x14
    // 0xaf84dc: mov             x16, x0
    // 0xaf84e0: mov             x0, x2
    // 0xaf84e4: mov             x2, x16
    // 0xaf84e8: r0 = GDT[cid_x0 + 0x1a4c]()
    //     0xaf84e8: mov             x17, #0x1a4c
    //     0xaf84ec: add             lr, x0, x17
    //     0xaf84f0: ldr             lr, [x21, lr, lsl #3]
    //     0xaf84f4: blr             lr
    // 0xaf84f8: cmp             w0, NULL
    // 0xaf84fc: b.ne            #0xaf8520
    // 0xaf8500: ldur            x2, [fp, #-0x10]
    // 0xaf8504: r0 = LoadClassIdInstr(r2)
    //     0xaf8504: ldur            x0, [x2, #-1]
    //     0xaf8508: ubfx            x0, x0, #0xc, #0x14
    // 0xaf850c: mov             x1, x2
    // 0xaf8510: r0 = GDT[cid_x0 + 0x3eda]()
    //     0xaf8510: mov             x17, #0x3eda
    //     0xaf8514: add             lr, x0, x17
    //     0xaf8518: ldr             lr, [x21, lr, lsl #3]
    //     0xaf851c: blr             lr
    // 0xaf8520: ldur            x1, [fp, #-0x10]
    // 0xaf8524: StoreField: r1->field_5b = r0
    //     0xaf8524: stur            w0, [x1, #0x5b]
    //     0xaf8528: tbz             w0, #0, #0xaf8544
    //     0xaf852c: ldurb           w16, [x1, #-1]
    //     0xaf8530: ldurb           w17, [x0, #-1]
    //     0xaf8534: and             x16, x17, x16, lsr #2
    //     0xaf8538: tst             x16, HEAP, lsr #32
    //     0xaf853c: b.eq            #0xaf8544
    //     0xaf8540: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xaf8544: r0 = Null
    //     0xaf8544: mov             x0, NULL
    // 0xaf8548: LeaveFrame
    //     0xaf8548: mov             SP, fp
    //     0xaf854c: ldp             fp, lr, [SP], #0x10
    // 0xaf8550: ret
    //     0xaf8550: ret             
    // 0xaf8554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8554: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8558: b               #0xaf849c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb9508, size: 0x9c
    // 0xbb9508: EnterFrame
    //     0xbb9508: stp             fp, lr, [SP, #-0x10]!
    //     0xbb950c: mov             fp, SP
    // 0xbb9510: AllocStack(0x20)
    //     0xbb9510: sub             SP, SP, #0x20
    // 0xbb9514: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x8 */)
    //     0xbb9514: mov             x0, x1
    //     0xbb9518: stur            x1, [fp, #-8]
    // 0xbb951c: CheckStackOverflow
    //     0xbb951c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9520: cmp             SP, x16
    //     0xbb9524: b.ls            #0xbb959c
    // 0xbb9528: LoadField: r1 = r0->field_4b
    //     0xbb9528: ldur            w1, [x0, #0x4b]
    // 0xbb952c: DecompressPointer r1
    //     0xbb952c: add             x1, x1, HEAP, lsl #32
    // 0xbb9530: cmp             w1, NULL
    // 0xbb9534: b.eq            #0xbb9544
    // 0xbb9538: mov             x1, x0
    // 0xbb953c: r0 = size()
    //     0xbb953c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb9540: b               #0xbb9548
    // 0xbb9544: r0 = Null
    //     0xbb9544: mov             x0, NULL
    // 0xbb9548: ldur            x1, [fp, #-8]
    // 0xbb954c: stur            x0, [fp, #-0x10]
    // 0xbb9550: r0 = performLayout()
    //     0xbb9550: bl              #0xbba2a4  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0xbb9554: ldur            x1, [fp, #-8]
    // 0xbb9558: r0 = size()
    //     0xbb9558: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb955c: mov             x1, x0
    // 0xbb9560: ldur            x0, [fp, #-0x10]
    // 0xbb9564: r2 = LoadClassIdInstr(r0)
    //     0xbb9564: ldur            x2, [x0, #-1]
    //     0xbb9568: ubfx            x2, x2, #0xc, #0x14
    // 0xbb956c: stp             x1, x0, [SP]
    // 0xbb9570: mov             x0, x2
    // 0xbb9574: mov             lr, x0
    // 0xbb9578: ldr             lr, [x21, lr, lsl #3]
    // 0xbb957c: blr             lr
    // 0xbb9580: tbz             w0, #4, #0xbb958c
    // 0xbb9584: ldur            x1, [fp, #-8]
    // 0xbb9588: StoreField: r1->field_5b = rNULL
    //     0xbb9588: stur            NULL, [x1, #0x5b]
    // 0xbb958c: r0 = Null
    //     0xbb958c: mov             x0, NULL
    // 0xbb9590: LeaveFrame
    //     0xbb9590: mov             SP, fp
    //     0xbb9594: ldp             fp, lr, [SP], #0x10
    // 0xbb9598: ret
    //     0xbb9598: ret             
    // 0xbb959c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb959c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb95a0: b               #0xbb9528
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc02a1c, size: 0x34
    // 0xc02a1c: EnterFrame
    //     0xc02a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc02a20: mov             fp, SP
    // 0xc02a24: CheckStackOverflow
    //     0xc02a24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02a28: cmp             SP, x16
    //     0xc02a2c: b.ls            #0xc02a48
    // 0xc02a30: StoreField: r1->field_63 = rNULL
    //     0xc02a30: stur            NULL, [x1, #0x63]
    // 0xc02a34: r0 = dispose()
    //     0xc02a34: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc02a38: r0 = Null
    //     0xc02a38: mov             x0, NULL
    // 0xc02a3c: LeaveFrame
    //     0xc02a3c: mov             SP, fp
    //     0xc02a40: ldp             fp, lr, [SP], #0x10
    // 0xc02a44: ret
    //     0xc02a44: ret             
    // 0xc02a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc02a48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02a4c: b               #0xc02a30
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05c64, size: 0x70
    // 0xc05c64: EnterFrame
    //     0xc05c64: stp             fp, lr, [SP, #-0x10]!
    //     0xc05c68: mov             fp, SP
    // 0xc05c6c: AllocStack(0x10)
    //     0xc05c6c: sub             SP, SP, #0x10
    // 0xc05c70: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x10 */)
    //     0xc05c70: mov             x0, x1
    //     0xc05c74: stur            x1, [fp, #-0x10]
    // 0xc05c78: CheckStackOverflow
    //     0xc05c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05c7c: cmp             SP, x16
    //     0xc05c80: b.ls            #0xc05ccc
    // 0xc05c84: LoadField: r3 = r0->field_57
    //     0xc05c84: ldur            w3, [x0, #0x57]
    // 0xc05c88: DecompressPointer r3
    //     0xc05c88: add             x3, x3, HEAP, lsl #32
    // 0xc05c8c: stur            x3, [fp, #-8]
    // 0xc05c90: cmp             w3, NULL
    // 0xc05c94: b.eq            #0xc05cb4
    // 0xc05c98: mov             x2, x0
    // 0xc05c9c: r1 = Function '_markNeedsClip@37160605':.
    //     0xc05c9c: add             x1, PP, #0x85, lsl #12  ; [pp+0x850a0] AnonymousClosure: (0xc05cd4), in [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip (0xc05d0c)
    //     0xc05ca0: ldr             x1, [x1, #0xa0]
    // 0xc05ca4: r0 = AllocateClosure()
    //     0xc05ca4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc05ca8: ldur            x1, [fp, #-8]
    // 0xc05cac: mov             x2, x0
    // 0xc05cb0: r0 = removeListener()
    //     0xc05cb0: bl              #0xd01414  ; [package:flutter/src/rendering/proxy_box.dart] CustomClipper::removeListener
    // 0xc05cb4: ldur            x1, [fp, #-0x10]
    // 0xc05cb8: r0 = detach()
    //     0xc05cb8: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc05cbc: r0 = Null
    //     0xc05cbc: mov             x0, NULL
    // 0xc05cc0: LeaveFrame
    //     0xc05cc0: mov             SP, fp
    //     0xc05cc4: ldp             fp, lr, [SP], #0x10
    // 0xc05cc8: ret
    //     0xc05cc8: ret             
    // 0xc05ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05cd0: b               #0xc05c84
  }
  [closure] void _markNeedsClip(dynamic) {
    // ** addr: 0xc05cd4, size: 0x38
    // 0xc05cd4: EnterFrame
    //     0xc05cd4: stp             fp, lr, [SP, #-0x10]!
    //     0xc05cd8: mov             fp, SP
    // 0xc05cdc: ldr             x0, [fp, #0x10]
    // 0xc05ce0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc05ce0: ldur            w1, [x0, #0x17]
    // 0xc05ce4: DecompressPointer r1
    //     0xc05ce4: add             x1, x1, HEAP, lsl #32
    // 0xc05ce8: CheckStackOverflow
    //     0xc05ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05cec: cmp             SP, x16
    //     0xc05cf0: b.ls            #0xc05d04
    // 0xc05cf4: r0 = _markNeedsClip()
    //     0xc05cf4: bl              #0xc05d0c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0xc05cf8: LeaveFrame
    //     0xc05cf8: mov             SP, fp
    //     0xc05cfc: ldp             fp, lr, [SP], #0x10
    // 0xc05d00: ret
    //     0xc05d00: ret             
    // 0xc05d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05d04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05d08: b               #0xc05cf4
  }
  _ _markNeedsClip(/* No info */) {
    // ** addr: 0xc05d0c, size: 0x4c
    // 0xc05d0c: EnterFrame
    //     0xc05d0c: stp             fp, lr, [SP, #-0x10]!
    //     0xc05d10: mov             fp, SP
    // 0xc05d14: AllocStack(0x8)
    //     0xc05d14: sub             SP, SP, #8
    // 0xc05d18: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x8 */)
    //     0xc05d18: mov             x0, x1
    //     0xc05d1c: stur            x1, [fp, #-8]
    // 0xc05d20: CheckStackOverflow
    //     0xc05d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05d24: cmp             SP, x16
    //     0xc05d28: b.ls            #0xc05d50
    // 0xc05d2c: StoreField: r0->field_5b = rNULL
    //     0xc05d2c: stur            NULL, [x0, #0x5b]
    // 0xc05d30: mov             x1, x0
    // 0xc05d34: r0 = markNeedsPaint()
    //     0xc05d34: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xc05d38: ldur            x1, [fp, #-8]
    // 0xc05d3c: r0 = markNeedsSemanticsUpdate()
    //     0xc05d3c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc05d40: r0 = Null
    //     0xc05d40: mov             x0, NULL
    // 0xc05d44: LeaveFrame
    //     0xc05d44: mov             SP, fp
    //     0xc05d48: ldp             fp, lr, [SP], #0x10
    // 0xc05d4c: ret
    //     0xc05d4c: ret             
    // 0xc05d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05d50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05d54: b               #0xc05d2c
  }
  _ attach(/* No info */) {
    // ** addr: 0xc097a8, size: 0x70
    // 0xc097a8: EnterFrame
    //     0xc097a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc097ac: mov             fp, SP
    // 0xc097b0: AllocStack(0x10)
    //     0xc097b0: sub             SP, SP, #0x10
    // 0xc097b4: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x8 */)
    //     0xc097b4: mov             x0, x1
    //     0xc097b8: stur            x1, [fp, #-8]
    // 0xc097bc: CheckStackOverflow
    //     0xc097bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc097c0: cmp             SP, x16
    //     0xc097c4: b.ls            #0xc09810
    // 0xc097c8: mov             x1, x0
    // 0xc097cc: r0 = attach()
    //     0xc097cc: bl              #0xc09a60  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::attach
    // 0xc097d0: ldur            x2, [fp, #-8]
    // 0xc097d4: LoadField: r0 = r2->field_57
    //     0xc097d4: ldur            w0, [x2, #0x57]
    // 0xc097d8: DecompressPointer r0
    //     0xc097d8: add             x0, x0, HEAP, lsl #32
    // 0xc097dc: stur            x0, [fp, #-0x10]
    // 0xc097e0: cmp             w0, NULL
    // 0xc097e4: b.eq            #0xc09800
    // 0xc097e8: r1 = Function '_markNeedsClip@37160605':.
    //     0xc097e8: add             x1, PP, #0x85, lsl #12  ; [pp+0x850a0] AnonymousClosure: (0xc05cd4), in [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip (0xc05d0c)
    //     0xc097ec: ldr             x1, [x1, #0xa0]
    // 0xc097f0: r0 = AllocateClosure()
    //     0xc097f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc097f4: ldur            x1, [fp, #-0x10]
    // 0xc097f8: mov             x2, x0
    // 0xc097fc: r0 = addListener()
    //     0xc097fc: bl              #0xd049c4  ; [package:flutter/src/rendering/proxy_box.dart] CustomClipper::addListener
    // 0xc09800: r0 = Null
    //     0xc09800: mov             x0, NULL
    // 0xc09804: LeaveFrame
    //     0xc09804: mov             SP, fp
    //     0xc09808: ldp             fp, lr, [SP], #0x10
    // 0xc0980c: ret
    //     0xc0980c: ret             
    // 0xc09810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09814: b               #0xc097c8
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0xccdc6c, size: 0xa8
    // 0xccdc6c: EnterFrame
    //     0xccdc6c: stp             fp, lr, [SP, #-0x10]!
    //     0xccdc70: mov             fp, SP
    // 0xccdc74: AllocStack(0x8)
    //     0xccdc74: sub             SP, SP, #8
    // 0xccdc78: SetupParameters(_RenderCustomClip<X0> this /* r1 => r0, fp-0x8 */)
    //     0xccdc78: mov             x0, x1
    //     0xccdc7c: stur            x1, [fp, #-8]
    // 0xccdc80: CheckStackOverflow
    //     0xccdc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccdc84: cmp             SP, x16
    //     0xccdc88: b.ls            #0xccdd0c
    // 0xccdc8c: LoadField: r1 = r0->field_5f
    //     0xccdc8c: ldur            w1, [x0, #0x5f]
    // 0xccdc90: DecompressPointer r1
    //     0xccdc90: add             x1, x1, HEAP, lsl #32
    // 0xccdc94: LoadField: r2 = r1->field_7
    //     0xccdc94: ldur            x2, [x1, #7]
    // 0xccdc98: cmp             x2, #1
    // 0xccdc9c: b.gt            #0xccdcb8
    // 0xccdca0: cmp             x2, #0
    // 0xccdca4: b.gt            #0xccdcb8
    // 0xccdca8: r0 = Null
    //     0xccdca8: mov             x0, NULL
    // 0xccdcac: LeaveFrame
    //     0xccdcac: mov             SP, fp
    //     0xccdcb0: ldp             fp, lr, [SP], #0x10
    // 0xccdcb4: ret
    //     0xccdcb4: ret             
    // 0xccdcb8: LoadField: r1 = r0->field_57
    //     0xccdcb8: ldur            w1, [x0, #0x57]
    // 0xccdcbc: DecompressPointer r1
    //     0xccdcbc: add             x1, x1, HEAP, lsl #32
    // 0xccdcc0: cmp             w1, NULL
    // 0xccdcc4: b.ne            #0xccdcd0
    // 0xccdcc8: r0 = Null
    //     0xccdcc8: mov             x0, NULL
    // 0xccdccc: b               #0xccdce4
    // 0xccdcd0: mov             x1, x0
    // 0xccdcd4: r0 = size()
    //     0xccdcd4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xccdcd8: mov             x2, x0
    // 0xccdcdc: r1 = Instance_Offset
    //     0xccdcdc: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xccdce0: r0 = &()
    //     0xccdce0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xccdce4: cmp             w0, NULL
    // 0xccdce8: b.ne            #0xccdd00
    // 0xccdcec: ldur            x1, [fp, #-8]
    // 0xccdcf0: r0 = size()
    //     0xccdcf0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xccdcf4: mov             x2, x0
    // 0xccdcf8: r1 = Instance_Offset
    //     0xccdcf8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xccdcfc: r0 = &()
    //     0xccdcfc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xccdd00: LeaveFrame
    //     0xccdd00: mov             SP, fp
    //     0xccdd04: ldp             fp, lr, [SP], #0x10
    // 0xccdd08: ret
    //     0xccdd08: ret             
    // 0xccdd0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccdd0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccdd10: b               #0xccdc8c
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0xcf6040, size: 0x60
    // 0xcf6040: EnterFrame
    //     0xcf6040: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6044: mov             fp, SP
    // 0xcf6048: mov             x0, x2
    // 0xcf604c: CheckStackOverflow
    //     0xcf604c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6050: cmp             SP, x16
    //     0xcf6054: b.ls            #0xcf6098
    // 0xcf6058: LoadField: r2 = r1->field_5f
    //     0xcf6058: ldur            w2, [x1, #0x5f]
    // 0xcf605c: DecompressPointer r2
    //     0xcf605c: add             x2, x2, HEAP, lsl #32
    // 0xcf6060: cmp             w0, w2
    // 0xcf6064: b.eq            #0xcf6088
    // 0xcf6068: StoreField: r1->field_5f = r0
    //     0xcf6068: stur            w0, [x1, #0x5f]
    //     0xcf606c: ldurb           w16, [x1, #-1]
    //     0xcf6070: ldurb           w17, [x0, #-1]
    //     0xcf6074: and             x16, x17, x16, lsr #2
    //     0xcf6078: tst             x16, HEAP, lsr #32
    //     0xcf607c: b.eq            #0xcf6084
    //     0xcf6080: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6084: r0 = markNeedsPaint()
    //     0xcf6084: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6088: r0 = Null
    //     0xcf6088: mov             x0, NULL
    // 0xcf608c: LeaveFrame
    //     0xcf608c: mov             SP, fp
    //     0xcf6090: ldp             fp, lr, [SP], #0x10
    // 0xcf6094: ret
    //     0xcf6094: ret             
    // 0xcf6098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf609c: b               #0xcf6058
  }
  set _ clipper=(/* No info */) {
    // ** addr: 0xcf60a0, size: 0x18c
    // 0xcf60a0: EnterFrame
    //     0xcf60a0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf60a4: mov             fp, SP
    // 0xcf60a8: AllocStack(0x28)
    //     0xcf60a8: sub             SP, SP, #0x28
    // 0xcf60ac: SetupParameters(_RenderCustomClip<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xcf60ac: mov             x4, x1
    //     0xcf60b0: mov             x3, x2
    //     0xcf60b4: stur            x1, [fp, #-8]
    //     0xcf60b8: stur            x2, [fp, #-0x10]
    // 0xcf60bc: CheckStackOverflow
    //     0xcf60bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf60c0: cmp             SP, x16
    //     0xcf60c4: b.ls            #0xcf6224
    // 0xcf60c8: LoadField: r2 = r4->field_53
    //     0xcf60c8: ldur            w2, [x4, #0x53]
    // 0xcf60cc: DecompressPointer r2
    //     0xcf60cc: add             x2, x2, HEAP, lsl #32
    // 0xcf60d0: mov             x0, x3
    // 0xcf60d4: r1 = Null
    //     0xcf60d4: mov             x1, NULL
    // 0xcf60d8: r8 = CustomClipper<X0>?
    //     0xcf60d8: add             x8, PP, #0x85, lsl #12  ; [pp+0x85088] Type: CustomClipper<X0>?
    //     0xcf60dc: ldr             x8, [x8, #0x88]
    // 0xcf60e0: LoadField: r9 = r8->field_7
    //     0xcf60e0: ldur            x9, [x8, #7]
    // 0xcf60e4: r3 = Null
    //     0xcf60e4: add             x3, PP, #0x85, lsl #12  ; [pp+0x85090] Null
    //     0xcf60e8: ldr             x3, [x3, #0x90]
    // 0xcf60ec: blr             x9
    // 0xcf60f0: ldur            x1, [fp, #-8]
    // 0xcf60f4: LoadField: r0 = r1->field_57
    //     0xcf60f4: ldur            w0, [x1, #0x57]
    // 0xcf60f8: DecompressPointer r0
    //     0xcf60f8: add             x0, x0, HEAP, lsl #32
    // 0xcf60fc: r2 = LoadClassIdInstr(r0)
    //     0xcf60fc: ldur            x2, [x0, #-1]
    //     0xcf6100: ubfx            x2, x2, #0xc, #0x14
    // 0xcf6104: ldur            x16, [fp, #-0x10]
    // 0xcf6108: stp             x16, x0, [SP]
    // 0xcf610c: mov             x0, x2
    // 0xcf6110: mov             lr, x0
    // 0xcf6114: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6118: blr             lr
    // 0xcf611c: tbnz            w0, #4, #0xcf6130
    // 0xcf6120: r0 = Null
    //     0xcf6120: mov             x0, NULL
    // 0xcf6124: LeaveFrame
    //     0xcf6124: mov             SP, fp
    //     0xcf6128: ldp             fp, lr, [SP], #0x10
    // 0xcf612c: ret
    //     0xcf612c: ret             
    // 0xcf6130: ldur            x1, [fp, #-8]
    // 0xcf6134: ldur            x2, [fp, #-0x10]
    // 0xcf6138: LoadField: r3 = r1->field_57
    //     0xcf6138: ldur            w3, [x1, #0x57]
    // 0xcf613c: DecompressPointer r3
    //     0xcf613c: add             x3, x3, HEAP, lsl #32
    // 0xcf6140: mov             x0, x2
    // 0xcf6144: stur            x3, [fp, #-0x18]
    // 0xcf6148: StoreField: r1->field_57 = r0
    //     0xcf6148: stur            w0, [x1, #0x57]
    //     0xcf614c: ldurb           w16, [x1, #-1]
    //     0xcf6150: ldurb           w17, [x0, #-1]
    //     0xcf6154: and             x16, x17, x16, lsr #2
    //     0xcf6158: tst             x16, HEAP, lsr #32
    //     0xcf615c: b.eq            #0xcf6164
    //     0xcf6160: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6164: cmp             w2, NULL
    // 0xcf6168: b.eq            #0xcf61a8
    // 0xcf616c: cmp             w3, NULL
    // 0xcf6170: b.eq            #0xcf61a8
    // 0xcf6174: stp             x3, x2, [SP]
    // 0xcf6178: r0 = _haveSameRuntimeType()
    //     0xcf6178: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcf617c: tbnz            w0, #4, #0xcf61a8
    // 0xcf6180: ldur            x3, [fp, #-0x10]
    // 0xcf6184: r0 = LoadClassIdInstr(r3)
    //     0xcf6184: ldur            x0, [x3, #-1]
    //     0xcf6188: ubfx            x0, x0, #0xc, #0x14
    // 0xcf618c: mov             x1, x3
    // 0xcf6190: ldur            x2, [fp, #-0x18]
    // 0xcf6194: r0 = GDT[cid_x0 + 0x2b1c]()
    //     0xcf6194: mov             x17, #0x2b1c
    //     0xcf6198: add             lr, x0, x17
    //     0xcf619c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf61a0: blr             lr
    // 0xcf61a4: tbnz            w0, #4, #0xcf61b0
    // 0xcf61a8: ldur            x1, [fp, #-8]
    // 0xcf61ac: r0 = _markNeedsClip()
    //     0xcf61ac: bl              #0xc05d0c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0xcf61b0: ldur            x0, [fp, #-8]
    // 0xcf61b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcf61b4: ldur            w1, [x0, #0x17]
    // 0xcf61b8: DecompressPointer r1
    //     0xcf61b8: add             x1, x1, HEAP, lsl #32
    // 0xcf61bc: cmp             w1, NULL
    // 0xcf61c0: b.eq            #0xcf6214
    // 0xcf61c4: ldur            x3, [fp, #-0x18]
    // 0xcf61c8: cmp             w3, NULL
    // 0xcf61cc: b.eq            #0xcf61ec
    // 0xcf61d0: mov             x2, x0
    // 0xcf61d4: r1 = Function '_markNeedsClip@37160605':.
    //     0xcf61d4: add             x1, PP, #0x85, lsl #12  ; [pp+0x850a0] AnonymousClosure: (0xc05cd4), in [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip (0xc05d0c)
    //     0xcf61d8: ldr             x1, [x1, #0xa0]
    // 0xcf61dc: r0 = AllocateClosure()
    //     0xcf61dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf61e0: ldur            x1, [fp, #-0x18]
    // 0xcf61e4: mov             x2, x0
    // 0xcf61e8: r0 = removeListener()
    //     0xcf61e8: bl              #0xd01414  ; [package:flutter/src/rendering/proxy_box.dart] CustomClipper::removeListener
    // 0xcf61ec: ldur            x0, [fp, #-0x10]
    // 0xcf61f0: cmp             w0, NULL
    // 0xcf61f4: b.eq            #0xcf6214
    // 0xcf61f8: ldur            x2, [fp, #-8]
    // 0xcf61fc: r1 = Function '_markNeedsClip@37160605':.
    //     0xcf61fc: add             x1, PP, #0x85, lsl #12  ; [pp+0x850a0] AnonymousClosure: (0xc05cd4), in [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip (0xc05d0c)
    //     0xcf6200: ldr             x1, [x1, #0xa0]
    // 0xcf6204: r0 = AllocateClosure()
    //     0xcf6204: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf6208: ldur            x1, [fp, #-0x10]
    // 0xcf620c: mov             x2, x0
    // 0xcf6210: r0 = addListener()
    //     0xcf6210: bl              #0xd049c4  ; [package:flutter/src/rendering/proxy_box.dart] CustomClipper::addListener
    // 0xcf6214: r0 = Null
    //     0xcf6214: mov             x0, NULL
    // 0xcf6218: LeaveFrame
    //     0xcf6218: mov             SP, fp
    //     0xcf621c: ldp             fp, lr, [SP], #0x10
    // 0xcf6220: ret
    //     0xcf6220: ret             
    // 0xcf6224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6228: b               #0xcf60c8
  }
  _ _RenderCustomClip(/* No info */) {
    // ** addr: 0x11d0760, size: 0xb8
    // 0x11d0760: EnterFrame
    //     0x11d0760: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0764: mov             fp, SP
    // 0x11d0768: AllocStack(0x8)
    //     0x11d0768: sub             SP, SP, #8
    // 0x11d076c: SetupParameters(_RenderCustomClip<X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x11d076c: stur            x1, [fp, #-8]
    //     0x11d0770: mov             x16, x2
    //     0x11d0774: mov             x2, x1
    //     0x11d0778: mov             x1, x16
    //     0x11d077c: mov             x0, x3
    // 0x11d0780: CheckStackOverflow
    //     0x11d0780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0784: cmp             SP, x16
    //     0x11d0788: b.ls            #0x11d0810
    // 0x11d078c: StoreField: r2->field_57 = r0
    //     0x11d078c: stur            w0, [x2, #0x57]
    //     0x11d0790: ldurb           w16, [x2, #-1]
    //     0x11d0794: ldurb           w17, [x0, #-1]
    //     0x11d0798: and             x16, x17, x16, lsr #2
    //     0x11d079c: tst             x16, HEAP, lsr #32
    //     0x11d07a0: b.eq            #0x11d07a8
    //     0x11d07a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d07a8: mov             x0, x1
    // 0x11d07ac: StoreField: r2->field_5f = r0
    //     0x11d07ac: stur            w0, [x2, #0x5f]
    //     0x11d07b0: ldurb           w16, [x2, #-1]
    //     0x11d07b4: ldurb           w17, [x0, #-1]
    //     0x11d07b8: and             x16, x17, x16, lsr #2
    //     0x11d07bc: tst             x16, HEAP, lsr #32
    //     0x11d07c0: b.eq            #0x11d07c8
    //     0x11d07c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d07c8: r0 = _LayoutCacheStorage()
    //     0x11d07c8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d07cc: ldur            x2, [fp, #-8]
    // 0x11d07d0: StoreField: r2->field_47 = r0
    //     0x11d07d0: stur            w0, [x2, #0x47]
    //     0x11d07d4: ldurb           w16, [x2, #-1]
    //     0x11d07d8: ldurb           w17, [x0, #-1]
    //     0x11d07dc: and             x16, x17, x16, lsr #2
    //     0x11d07e0: tst             x16, HEAP, lsr #32
    //     0x11d07e4: b.eq            #0x11d07ec
    //     0x11d07e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d07ec: mov             x1, x2
    // 0x11d07f0: r0 = RenderObject()
    //     0x11d07f0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d07f4: ldur            x1, [fp, #-8]
    // 0x11d07f8: r2 = Null
    //     0x11d07f8: mov             x2, NULL
    // 0x11d07fc: r0 = child=()
    //     0x11d07fc: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d0800: r0 = Null
    //     0x11d0800: mov             x0, NULL
    // 0x11d0804: LeaveFrame
    //     0x11d0804: mov             SP, fp
    //     0x11d0808: ldp             fp, lr, [SP], #0x10
    // 0x11d080c: ret
    //     0x11d080c: ret             
    // 0x11d0810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0814: b               #0x11d078c
  }
}

// class id: 4930, size: 0x78, field offset: 0x68
abstract class _RenderPhysicalModelBase<X0> extends _RenderCustomClip<X0> {

  set _ elevation=(/* No info */) {
    // ** addr: 0xcf6888, size: 0x50
    // 0xcf6888: EnterFrame
    //     0xcf6888: stp             fp, lr, [SP, #-0x10]!
    //     0xcf688c: mov             fp, SP
    // 0xcf6890: CheckStackOverflow
    //     0xcf6890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6894: cmp             SP, x16
    //     0xcf6898: b.ls            #0xcf68d0
    // 0xcf689c: LoadField: d1 = r1->field_67
    //     0xcf689c: ldur            d1, [x1, #0x67]
    // 0xcf68a0: fcmp            d1, d0
    // 0xcf68a4: b.ne            #0xcf68b8
    // 0xcf68a8: r0 = Null
    //     0xcf68a8: mov             x0, NULL
    // 0xcf68ac: LeaveFrame
    //     0xcf68ac: mov             SP, fp
    //     0xcf68b0: ldp             fp, lr, [SP], #0x10
    // 0xcf68b4: ret
    //     0xcf68b4: ret             
    // 0xcf68b8: StoreField: r1->field_67 = d0
    //     0xcf68b8: stur            d0, [x1, #0x67]
    // 0xcf68bc: r0 = markNeedsPaint()
    //     0xcf68bc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf68c0: r0 = Null
    //     0xcf68c0: mov             x0, NULL
    // 0xcf68c4: LeaveFrame
    //     0xcf68c4: mov             SP, fp
    //     0xcf68c8: ldp             fp, lr, [SP], #0x10
    // 0xcf68cc: ret
    //     0xcf68cc: ret             
    // 0xcf68d0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf68d0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf68d4: b               #0xcf689c
  }
  set _ shadowColor=(/* No info */) {
    // ** addr: 0xcf68d8, size: 0xa4
    // 0xcf68d8: EnterFrame
    //     0xcf68d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf68dc: mov             fp, SP
    // 0xcf68e0: AllocStack(0x20)
    //     0xcf68e0: sub             SP, SP, #0x20
    // 0xcf68e4: SetupParameters(_RenderPhysicalModelBase<X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf68e4: stur            x1, [fp, #-8]
    //     0xcf68e8: mov             x16, x2
    //     0xcf68ec: mov             x2, x1
    //     0xcf68f0: mov             x1, x16
    //     0xcf68f4: stur            x1, [fp, #-0x10]
    // 0xcf68f8: CheckStackOverflow
    //     0xcf68f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf68fc: cmp             SP, x16
    //     0xcf6900: b.ls            #0xcf6974
    // 0xcf6904: LoadField: r0 = r2->field_6f
    //     0xcf6904: ldur            w0, [x2, #0x6f]
    // 0xcf6908: DecompressPointer r0
    //     0xcf6908: add             x0, x0, HEAP, lsl #32
    // 0xcf690c: r3 = LoadClassIdInstr(r0)
    //     0xcf690c: ldur            x3, [x0, #-1]
    //     0xcf6910: ubfx            x3, x3, #0xc, #0x14
    // 0xcf6914: stp             x1, x0, [SP]
    // 0xcf6918: mov             x0, x3
    // 0xcf691c: mov             lr, x0
    // 0xcf6920: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6924: blr             lr
    // 0xcf6928: tbnz            w0, #4, #0xcf693c
    // 0xcf692c: r0 = Null
    //     0xcf692c: mov             x0, NULL
    // 0xcf6930: LeaveFrame
    //     0xcf6930: mov             SP, fp
    //     0xcf6934: ldp             fp, lr, [SP], #0x10
    // 0xcf6938: ret
    //     0xcf6938: ret             
    // 0xcf693c: ldur            x1, [fp, #-8]
    // 0xcf6940: ldur            x0, [fp, #-0x10]
    // 0xcf6944: StoreField: r1->field_6f = r0
    //     0xcf6944: stur            w0, [x1, #0x6f]
    //     0xcf6948: ldurb           w16, [x1, #-1]
    //     0xcf694c: ldurb           w17, [x0, #-1]
    //     0xcf6950: and             x16, x17, x16, lsr #2
    //     0xcf6954: tst             x16, HEAP, lsr #32
    //     0xcf6958: b.eq            #0xcf6960
    //     0xcf695c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6960: r0 = markNeedsPaint()
    //     0xcf6960: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6964: r0 = Null
    //     0xcf6964: mov             x0, NULL
    // 0xcf6968: LeaveFrame
    //     0xcf6968: mov             SP, fp
    //     0xcf696c: ldp             fp, lr, [SP], #0x10
    // 0xcf6970: ret
    //     0xcf6970: ret             
    // 0xcf6974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6978: b               #0xcf6904
  }
  set _ color=(/* No info */) {
    // ** addr: 0xcf697c, size: 0xa4
    // 0xcf697c: EnterFrame
    //     0xcf697c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6980: mov             fp, SP
    // 0xcf6984: AllocStack(0x20)
    //     0xcf6984: sub             SP, SP, #0x20
    // 0xcf6988: SetupParameters(_RenderPhysicalModelBase<X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf6988: stur            x1, [fp, #-8]
    //     0xcf698c: mov             x16, x2
    //     0xcf6990: mov             x2, x1
    //     0xcf6994: mov             x1, x16
    //     0xcf6998: stur            x1, [fp, #-0x10]
    // 0xcf699c: CheckStackOverflow
    //     0xcf699c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf69a0: cmp             SP, x16
    //     0xcf69a4: b.ls            #0xcf6a18
    // 0xcf69a8: LoadField: r0 = r2->field_73
    //     0xcf69a8: ldur            w0, [x2, #0x73]
    // 0xcf69ac: DecompressPointer r0
    //     0xcf69ac: add             x0, x0, HEAP, lsl #32
    // 0xcf69b0: r3 = LoadClassIdInstr(r0)
    //     0xcf69b0: ldur            x3, [x0, #-1]
    //     0xcf69b4: ubfx            x3, x3, #0xc, #0x14
    // 0xcf69b8: stp             x1, x0, [SP]
    // 0xcf69bc: mov             x0, x3
    // 0xcf69c0: mov             lr, x0
    // 0xcf69c4: ldr             lr, [x21, lr, lsl #3]
    // 0xcf69c8: blr             lr
    // 0xcf69cc: tbnz            w0, #4, #0xcf69e0
    // 0xcf69d0: r0 = Null
    //     0xcf69d0: mov             x0, NULL
    // 0xcf69d4: LeaveFrame
    //     0xcf69d4: mov             SP, fp
    //     0xcf69d8: ldp             fp, lr, [SP], #0x10
    // 0xcf69dc: ret
    //     0xcf69dc: ret             
    // 0xcf69e0: ldur            x1, [fp, #-8]
    // 0xcf69e4: ldur            x0, [fp, #-0x10]
    // 0xcf69e8: StoreField: r1->field_73 = r0
    //     0xcf69e8: stur            w0, [x1, #0x73]
    //     0xcf69ec: ldurb           w16, [x1, #-1]
    //     0xcf69f0: ldurb           w17, [x0, #-1]
    //     0xcf69f4: and             x16, x17, x16, lsr #2
    //     0xcf69f8: tst             x16, HEAP, lsr #32
    //     0xcf69fc: b.eq            #0xcf6a04
    //     0xcf6a00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6a04: r0 = markNeedsPaint()
    //     0xcf6a04: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6a08: r0 = Null
    //     0xcf6a08: mov             x0, NULL
    // 0xcf6a0c: LeaveFrame
    //     0xcf6a0c: mov             SP, fp
    //     0xcf6a10: ldp             fp, lr, [SP], #0x10
    // 0xcf6a14: ret
    //     0xcf6a14: ret             
    // 0xcf6a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6a18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6a1c: b               #0xcf69a8
  }
}

// class id: 4931, size: 0x78, field offset: 0x78
class RenderPhysicalShape extends _RenderPhysicalModelBase<dynamic> {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf9040, size: 0xa0
    // 0xaf9040: EnterFrame
    //     0xaf9040: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9044: mov             fp, SP
    // 0xaf9048: AllocStack(0x18)
    //     0xaf9048: sub             SP, SP, #0x18
    // 0xaf904c: SetupParameters(RenderPhysicalShape this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xaf904c: mov             x0, x2
    //     0xaf9050: stur            x2, [fp, #-0x10]
    //     0xaf9054: mov             x2, x3
    //     0xaf9058: stur            x3, [fp, #-0x18]
    //     0xaf905c: mov             x3, x1
    //     0xaf9060: stur            x1, [fp, #-8]
    // 0xaf9064: CheckStackOverflow
    //     0xaf9064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9068: cmp             SP, x16
    //     0xaf906c: b.ls            #0xaf90d4
    // 0xaf9070: LoadField: r1 = r3->field_57
    //     0xaf9070: ldur            w1, [x3, #0x57]
    // 0xaf9074: DecompressPointer r1
    //     0xaf9074: add             x1, x1, HEAP, lsl #32
    // 0xaf9078: cmp             w1, NULL
    // 0xaf907c: b.eq            #0xaf90b8
    // 0xaf9080: mov             x1, x3
    // 0xaf9084: r0 = _updateClip()
    //     0xaf9084: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xaf9088: ldur            x0, [fp, #-8]
    // 0xaf908c: LoadField: r1 = r0->field_5b
    //     0xaf908c: ldur            w1, [x0, #0x5b]
    // 0xaf9090: DecompressPointer r1
    //     0xaf9090: add             x1, x1, HEAP, lsl #32
    // 0xaf9094: cmp             w1, NULL
    // 0xaf9098: b.eq            #0xaf90dc
    // 0xaf909c: ldur            x2, [fp, #-0x18]
    // 0xaf90a0: r0 = contains()
    //     0xaf90a0: bl              #0xaf9104  ; [dart:ui] _NativePath::contains
    // 0xaf90a4: tbz             w0, #4, #0xaf90b8
    // 0xaf90a8: r0 = false
    //     0xaf90a8: add             x0, NULL, #0x30  ; false
    // 0xaf90ac: LeaveFrame
    //     0xaf90ac: mov             SP, fp
    //     0xaf90b0: ldp             fp, lr, [SP], #0x10
    // 0xaf90b4: ret
    //     0xaf90b4: ret             
    // 0xaf90b8: ldur            x1, [fp, #-8]
    // 0xaf90bc: ldur            x2, [fp, #-0x10]
    // 0xaf90c0: ldur            x3, [fp, #-0x18]
    // 0xaf90c4: r0 = hitTest()
    //     0xaf90c4: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf90c8: LeaveFrame
    //     0xaf90c8: mov             SP, fp
    //     0xaf90cc: ldp             fp, lr, [SP], #0x10
    // 0xaf90d0: ret
    //     0xaf90d0: ret             
    // 0xaf90d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf90d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf90d8: b               #0xaf9070
    // 0xaf90dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf90dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc1b694, size: 0x118
    // 0xc1b694: EnterFrame
    //     0xc1b694: stp             fp, lr, [SP, #-0x10]!
    //     0xc1b698: mov             fp, SP
    // 0xc1b69c: AllocStack(0x40)
    //     0xc1b69c: sub             SP, SP, #0x40
    // 0xc1b6a0: SetupParameters([dynamic _ /* r0 */])
    //     0xc1b6a0: ldr             x0, [fp, #0x20]
    //     0xc1b6a4: ldur            w2, [x0, #0x17]
    //     0xc1b6a8: add             x2, x2, HEAP, lsl #32
    //     0xc1b6ac: stur            x2, [fp, #-8]
    // 0xc1b6b0: CheckStackOverflow
    //     0xc1b6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1b6b4: cmp             SP, x16
    //     0xc1b6b8: b.ls            #0xc1b7a0
    // 0xc1b6bc: LoadField: r0 = r2->field_13
    //     0xc1b6bc: ldur            w0, [x2, #0x13]
    // 0xc1b6c0: DecompressPointer r0
    //     0xc1b6c0: add             x0, x0, HEAP, lsl #32
    // 0xc1b6c4: tbnz            w0, #4, #0xc1b768
    // 0xc1b6c8: ldr             x1, [fp, #0x18]
    // 0xc1b6cc: r0 = canvas()
    //     0xc1b6cc: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1b6d0: stur            x0, [fp, #-0x10]
    // 0xc1b6d4: r16 = 136
    //     0xc1b6d4: mov             x16, #0x88
    // 0xc1b6d8: stp             x16, NULL, [SP]
    // 0xc1b6dc: r0 = ByteData()
    //     0xc1b6dc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc1b6e0: stur            x0, [fp, #-0x18]
    // 0xc1b6e4: r0 = Paint()
    //     0xc1b6e4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1b6e8: ldur            x3, [fp, #-0x18]
    // 0xc1b6ec: stur            x0, [fp, #-0x20]
    // 0xc1b6f0: StoreField: r0->field_7 = r3
    //     0xc1b6f0: stur            w3, [x0, #7]
    // 0xc1b6f4: ldur            x4, [fp, #-8]
    // 0xc1b6f8: LoadField: r1 = r4->field_f
    //     0xc1b6f8: ldur            w1, [x4, #0xf]
    // 0xc1b6fc: DecompressPointer r1
    //     0xc1b6fc: add             x1, x1, HEAP, lsl #32
    // 0xc1b700: LoadField: r2 = r1->field_73
    //     0xc1b700: ldur            w2, [x1, #0x73]
    // 0xc1b704: DecompressPointer r2
    //     0xc1b704: add             x2, x2, HEAP, lsl #32
    // 0xc1b708: mov             x1, x0
    // 0xc1b70c: r0 = color=()
    //     0xc1b70c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc1b710: ldur            x0, [fp, #-0x20]
    // 0xc1b714: LoadField: r2 = r0->field_b
    //     0xc1b714: ldur            w2, [x0, #0xb]
    // 0xc1b718: DecompressPointer r2
    //     0xc1b718: add             x2, x2, HEAP, lsl #32
    // 0xc1b71c: ldur            x0, [fp, #-0x10]
    // 0xc1b720: stur            x2, [fp, #-0x30]
    // 0xc1b724: LoadField: r1 = r0->field_7
    //     0xc1b724: ldur            w1, [x0, #7]
    // 0xc1b728: DecompressPointer r1
    //     0xc1b728: add             x1, x1, HEAP, lsl #32
    // 0xc1b72c: cmp             w1, NULL
    // 0xc1b730: b.eq            #0xc1b7a8
    // 0xc1b734: LoadField: r3 = r1->field_7
    //     0xc1b734: ldur            x3, [x1, #7]
    // 0xc1b738: ldr             x1, [x3]
    // 0xc1b73c: cbz             x1, #0xc1b790
    // 0xc1b740: mov             x3, x1
    // 0xc1b744: stur            x3, [fp, #-0x28]
    // 0xc1b748: r1 = <Never>
    //     0xc1b748: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1b74c: r0 = Pointer()
    //     0xc1b74c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1b750: mov             x1, x0
    // 0xc1b754: ldur            x0, [fp, #-0x28]
    // 0xc1b758: StoreField: r1->field_7 = r0
    //     0xc1b758: stur            x0, [x1, #7]
    // 0xc1b75c: ldur            x2, [fp, #-0x30]
    // 0xc1b760: ldur            x3, [fp, #-0x18]
    // 0xc1b764: r0 = __drawPaint$Method$FfiNative()
    //     0xc1b764: bl              #0xc1b7ac  ; [dart:ui] _NativeCanvas::__drawPaint$Method$FfiNative
    // 0xc1b768: ldur            x0, [fp, #-8]
    // 0xc1b76c: LoadField: r1 = r0->field_f
    //     0xc1b76c: ldur            w1, [x0, #0xf]
    // 0xc1b770: DecompressPointer r1
    //     0xc1b770: add             x1, x1, HEAP, lsl #32
    // 0xc1b774: ldr             x2, [fp, #0x18]
    // 0xc1b778: ldr             x3, [fp, #0x10]
    // 0xc1b77c: r0 = paint()
    //     0xc1b77c: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1b780: r0 = Null
    //     0xc1b780: mov             x0, NULL
    // 0xc1b784: LeaveFrame
    //     0xc1b784: mov             SP, fp
    //     0xc1b788: ldp             fp, lr, [SP], #0x10
    // 0xc1b78c: ret
    //     0xc1b78c: ret             
    // 0xc1b790: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1b790: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1b794: str             x16, [SP]
    // 0xc1b798: r0 = _throwNew()
    //     0xc1b798: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1b79c: brk             #0
    // 0xc1b7a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1b7a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1b7a4: b               #0xc1b6bc
    // 0xc1b7a8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1b7a8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1b968, size: 0x354
    // 0xc1b968: EnterFrame
    //     0xc1b968: stp             fp, lr, [SP, #-0x10]!
    //     0xc1b96c: mov             fp, SP
    // 0xc1b970: AllocStack(0x70)
    //     0xc1b970: sub             SP, SP, #0x70
    // 0xc1b974: SetupParameters(RenderPhysicalShape this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xc1b974: mov             x0, x1
    //     0xc1b978: stur            x1, [fp, #-8]
    //     0xc1b97c: mov             x1, x2
    //     0xc1b980: stur            x2, [fp, #-0x10]
    //     0xc1b984: mov             x2, x3
    //     0xc1b988: stur            x3, [fp, #-0x18]
    // 0xc1b98c: CheckStackOverflow
    //     0xc1b98c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1b990: cmp             SP, x16
    //     0xc1b994: b.ls            #0xc1bc9c
    // 0xc1b998: r1 = 2
    //     0xc1b998: mov             x1, #2
    // 0xc1b99c: r0 = AllocateContext()
    //     0xc1b99c: bl              #0x13de838  ; AllocateContextStub
    // 0xc1b9a0: mov             x2, x0
    // 0xc1b9a4: ldur            x0, [fp, #-8]
    // 0xc1b9a8: stur            x2, [fp, #-0x20]
    // 0xc1b9ac: StoreField: r2->field_f = r0
    //     0xc1b9ac: stur            w0, [x2, #0xf]
    // 0xc1b9b0: LoadField: r1 = r0->field_4f
    //     0xc1b9b0: ldur            w1, [x0, #0x4f]
    // 0xc1b9b4: DecompressPointer r1
    //     0xc1b9b4: add             x1, x1, HEAP, lsl #32
    // 0xc1b9b8: cmp             w1, NULL
    // 0xc1b9bc: b.ne            #0xc1b9e0
    // 0xc1b9c0: LoadField: r1 = r0->field_2f
    //     0xc1b9c0: ldur            w1, [x0, #0x2f]
    // 0xc1b9c4: DecompressPointer r1
    //     0xc1b9c4: add             x1, x1, HEAP, lsl #32
    // 0xc1b9c8: r2 = Null
    //     0xc1b9c8: mov             x2, NULL
    // 0xc1b9cc: r0 = layer=()
    //     0xc1b9cc: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b9d0: r0 = Null
    //     0xc1b9d0: mov             x0, NULL
    // 0xc1b9d4: LeaveFrame
    //     0xc1b9d4: mov             SP, fp
    //     0xc1b9d8: ldp             fp, lr, [SP], #0x10
    // 0xc1b9dc: ret
    //     0xc1b9dc: ret             
    // 0xc1b9e0: mov             x1, x0
    // 0xc1b9e4: r0 = _updateClip()
    //     0xc1b9e4: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1b9e8: ldur            x0, [fp, #-8]
    // 0xc1b9ec: LoadField: r1 = r0->field_5b
    //     0xc1b9ec: ldur            w1, [x0, #0x5b]
    // 0xc1b9f0: DecompressPointer r1
    //     0xc1b9f0: add             x1, x1, HEAP, lsl #32
    // 0xc1b9f4: cmp             w1, NULL
    // 0xc1b9f8: b.eq            #0xc1bca4
    // 0xc1b9fc: ldur            x2, [fp, #-0x18]
    // 0xc1ba00: r0 = shift()
    //     0xc1ba00: bl              #0xc1ad40  ; [dart:ui] _NativePath::shift
    // 0xc1ba04: ldur            x1, [fp, #-0x10]
    // 0xc1ba08: stur            x0, [fp, #-0x28]
    // 0xc1ba0c: r0 = canvas()
    //     0xc1ba0c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1ba10: mov             x3, x0
    // 0xc1ba14: ldur            x2, [fp, #-8]
    // 0xc1ba18: stur            x3, [fp, #-0x38]
    // 0xc1ba1c: LoadField: d0 = r2->field_67
    //     0xc1ba1c: ldur            d0, [x2, #0x67]
    // 0xc1ba20: stur            d0, [fp, #-0x60]
    // 0xc1ba24: d1 = 0.000000
    //     0xc1ba24: eor             v1.16b, v1.16b, v1.16b
    // 0xc1ba28: fcmp            d0, d1
    // 0xc1ba2c: b.eq            #0xc1ba7c
    // 0xc1ba30: LoadField: r4 = r2->field_6f
    //     0xc1ba30: ldur            w4, [x2, #0x6f]
    // 0xc1ba34: DecompressPointer r4
    //     0xc1ba34: add             x4, x4, HEAP, lsl #32
    // 0xc1ba38: stur            x4, [fp, #-0x30]
    // 0xc1ba3c: LoadField: r1 = r2->field_73
    //     0xc1ba3c: ldur            w1, [x2, #0x73]
    // 0xc1ba40: DecompressPointer r1
    //     0xc1ba40: add             x1, x1, HEAP, lsl #32
    // 0xc1ba44: r0 = LoadClassIdInstr(r1)
    //     0xc1ba44: ldur            x0, [x1, #-1]
    //     0xc1ba48: ubfx            x0, x0, #0xc, #0x14
    // 0xc1ba4c: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xc1ba4c: sub             lr, x0, #0xfc0
    //     0xc1ba50: ldr             lr, [x21, lr, lsl #3]
    //     0xc1ba54: blr             lr
    // 0xc1ba58: cmp             x0, #0xff
    // 0xc1ba5c: r16 = true
    //     0xc1ba5c: add             x16, NULL, #0x20  ; true
    // 0xc1ba60: r17 = false
    //     0xc1ba60: add             x17, NULL, #0x30  ; false
    // 0xc1ba64: csel            x5, x16, x17, ne
    // 0xc1ba68: ldur            x1, [fp, #-0x38]
    // 0xc1ba6c: ldur            x2, [fp, #-0x28]
    // 0xc1ba70: ldur            x3, [fp, #-0x30]
    // 0xc1ba74: ldur            d0, [fp, #-0x60]
    // 0xc1ba78: r0 = drawShadow()
    //     0xc1ba78: bl              #0xb742dc  ; [dart:ui] _NativeCanvas::drawShadow
    // 0xc1ba7c: ldur            x1, [fp, #-8]
    // 0xc1ba80: ldur            x2, [fp, #-0x20]
    // 0xc1ba84: LoadField: r0 = r1->field_5f
    //     0xc1ba84: ldur            w0, [x1, #0x5f]
    // 0xc1ba88: DecompressPointer r0
    //     0xc1ba88: add             x0, x0, HEAP, lsl #32
    // 0xc1ba8c: r16 = Instance_Clip
    //     0xc1ba8c: add             x16, PP, #0x90, lsl #12  ; [pp+0x906a8] Obj!Clip@12c8121
    //     0xc1ba90: ldr             x16, [x16, #0x6a8]
    // 0xc1ba94: cmp             w0, w16
    // 0xc1ba98: r16 = true
    //     0xc1ba98: add             x16, NULL, #0x20  ; true
    // 0xc1ba9c: r17 = false
    //     0xc1ba9c: add             x17, NULL, #0x30  ; false
    // 0xc1baa0: csel            x3, x16, x17, eq
    // 0xc1baa4: StoreField: r2->field_13 = r3
    //     0xc1baa4: stur            w3, [x2, #0x13]
    // 0xc1baa8: tbz             w3, #4, #0xc1bb84
    // 0xc1baac: ldur            x0, [fp, #-0x38]
    // 0xc1bab0: r16 = 136
    //     0xc1bab0: mov             x16, #0x88
    // 0xc1bab4: stp             x16, NULL, [SP]
    // 0xc1bab8: r0 = ByteData()
    //     0xc1bab8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc1babc: stur            x0, [fp, #-0x30]
    // 0xc1bac0: r0 = Paint()
    //     0xc1bac0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1bac4: ldur            x5, [fp, #-0x30]
    // 0xc1bac8: stur            x0, [fp, #-0x40]
    // 0xc1bacc: StoreField: r0->field_7 = r5
    //     0xc1bacc: stur            w5, [x0, #7]
    // 0xc1bad0: ldur            x3, [fp, #-8]
    // 0xc1bad4: LoadField: r2 = r3->field_73
    //     0xc1bad4: ldur            w2, [x3, #0x73]
    // 0xc1bad8: DecompressPointer r2
    //     0xc1bad8: add             x2, x2, HEAP, lsl #32
    // 0xc1badc: mov             x1, x0
    // 0xc1bae0: r0 = color=()
    //     0xc1bae0: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc1bae4: ldur            x0, [fp, #-0x40]
    // 0xc1bae8: LoadField: r3 = r0->field_b
    //     0xc1bae8: ldur            w3, [x0, #0xb]
    // 0xc1baec: DecompressPointer r3
    //     0xc1baec: add             x3, x3, HEAP, lsl #32
    // 0xc1baf0: ldur            x0, [fp, #-0x38]
    // 0xc1baf4: stur            x3, [fp, #-0x50]
    // 0xc1baf8: LoadField: r1 = r0->field_7
    //     0xc1baf8: ldur            w1, [x0, #7]
    // 0xc1bafc: DecompressPointer r1
    //     0xc1bafc: add             x1, x1, HEAP, lsl #32
    // 0xc1bb00: cmp             w1, NULL
    // 0xc1bb04: b.eq            #0xc1bca8
    // 0xc1bb08: LoadField: r2 = r1->field_7
    //     0xc1bb08: ldur            x2, [x1, #7]
    // 0xc1bb0c: ldr             x1, [x2]
    // 0xc1bb10: cbz             x1, #0xc1bc8c
    // 0xc1bb14: ldur            x2, [fp, #-0x28]
    // 0xc1bb18: mov             x4, x1
    // 0xc1bb1c: stur            x4, [fp, #-0x48]
    // 0xc1bb20: r1 = <Never>
    //     0xc1bb20: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1bb24: r0 = Pointer()
    //     0xc1bb24: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1bb28: mov             x2, x0
    // 0xc1bb2c: ldur            x0, [fp, #-0x48]
    // 0xc1bb30: stur            x2, [fp, #-0x40]
    // 0xc1bb34: StoreField: r2->field_7 = r0
    //     0xc1bb34: stur            x0, [x2, #7]
    // 0xc1bb38: ldur            x0, [fp, #-0x28]
    // 0xc1bb3c: LoadField: r1 = r0->field_7
    //     0xc1bb3c: ldur            w1, [x0, #7]
    // 0xc1bb40: DecompressPointer r1
    //     0xc1bb40: add             x1, x1, HEAP, lsl #32
    // 0xc1bb44: cmp             w1, NULL
    // 0xc1bb48: b.eq            #0xc1bcac
    // 0xc1bb4c: LoadField: r3 = r1->field_7
    //     0xc1bb4c: ldur            x3, [x1, #7]
    // 0xc1bb50: ldr             x1, [x3]
    // 0xc1bb54: mov             x3, x1
    // 0xc1bb58: stur            x3, [fp, #-0x48]
    // 0xc1bb5c: r1 = <Never>
    //     0xc1bb5c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1bb60: r0 = Pointer()
    //     0xc1bb60: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1bb64: mov             x1, x0
    // 0xc1bb68: ldur            x0, [fp, #-0x48]
    // 0xc1bb6c: StoreField: r1->field_7 = r0
    //     0xc1bb6c: stur            x0, [x1, #7]
    // 0xc1bb70: mov             x2, x1
    // 0xc1bb74: ldur            x1, [fp, #-0x40]
    // 0xc1bb78: ldur            x3, [fp, #-0x50]
    // 0xc1bb7c: ldur            x5, [fp, #-0x30]
    // 0xc1bb80: r0 = __drawPath$Method$FfiNative()
    //     0xc1bb80: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xc1bb84: ldur            x0, [fp, #-8]
    // 0xc1bb88: LoadField: r2 = r0->field_37
    //     0xc1bb88: ldur            w2, [x0, #0x37]
    // 0xc1bb8c: DecompressPointer r2
    //     0xc1bb8c: add             x2, x2, HEAP, lsl #32
    // 0xc1bb90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1bb94: cmp             w2, w16
    // 0xc1bb98: b.eq            #0xc1bcb0
    // 0xc1bb9c: mov             x1, x0
    // 0xc1bba0: stur            x2, [fp, #-0x28]
    // 0xc1bba4: r0 = size()
    //     0xc1bba4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1bba8: mov             x2, x0
    // 0xc1bbac: r1 = Instance_Offset
    //     0xc1bbac: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1bbb0: r0 = &()
    //     0xc1bbb0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1bbb4: mov             x4, x0
    // 0xc1bbb8: ldur            x3, [fp, #-8]
    // 0xc1bbbc: stur            x4, [fp, #-0x50]
    // 0xc1bbc0: LoadField: r6 = r3->field_5b
    //     0xc1bbc0: ldur            w6, [x3, #0x5b]
    // 0xc1bbc4: DecompressPointer r6
    //     0xc1bbc4: add             x6, x6, HEAP, lsl #32
    // 0xc1bbc8: stur            x6, [fp, #-0x40]
    // 0xc1bbcc: cmp             w6, NULL
    // 0xc1bbd0: b.eq            #0xc1bcb8
    // 0xc1bbd4: LoadField: r5 = r3->field_2f
    //     0xc1bbd4: ldur            w5, [x3, #0x2f]
    // 0xc1bbd8: DecompressPointer r5
    //     0xc1bbd8: add             x5, x5, HEAP, lsl #32
    // 0xc1bbdc: stur            x5, [fp, #-0x38]
    // 0xc1bbe0: LoadField: r7 = r5->field_b
    //     0xc1bbe0: ldur            w7, [x5, #0xb]
    // 0xc1bbe4: DecompressPointer r7
    //     0xc1bbe4: add             x7, x7, HEAP, lsl #32
    // 0xc1bbe8: mov             x0, x7
    // 0xc1bbec: stur            x7, [fp, #-0x30]
    // 0xc1bbf0: r2 = Null
    //     0xc1bbf0: mov             x2, NULL
    // 0xc1bbf4: r1 = Null
    //     0xc1bbf4: mov             x1, NULL
    // 0xc1bbf8: r4 = LoadClassIdInstr(r0)
    //     0xc1bbf8: ldur            x4, [x0, #-1]
    //     0xc1bbfc: ubfx            x4, x4, #0xc, #0x14
    // 0xc1bc00: r17 = 4656
    //     0xc1bc00: mov             x17, #0x1230
    // 0xc1bc04: cmp             x4, x17
    // 0xc1bc08: b.eq            #0xc1bc20
    // 0xc1bc0c: r8 = ClipPathLayer?
    //     0xc1bc0c: add             x8, PP, #0x90, lsl #12  ; [pp+0x90b50] Type: ClipPathLayer?
    //     0xc1bc10: ldr             x8, [x8, #0xb50]
    // 0xc1bc14: r3 = Null
    //     0xc1bc14: add             x3, PP, #0xae, lsl #12  ; [pp+0xae128] Null
    //     0xc1bc18: ldr             x3, [x3, #0x128]
    // 0xc1bc1c: r0 = DefaultNullableTypeTest()
    //     0xc1bc1c: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1bc20: ldur            x0, [fp, #-8]
    // 0xc1bc24: LoadField: r3 = r0->field_5f
    //     0xc1bc24: ldur            w3, [x0, #0x5f]
    // 0xc1bc28: DecompressPointer r3
    //     0xc1bc28: add             x3, x3, HEAP, lsl #32
    // 0xc1bc2c: ldur            x2, [fp, #-0x20]
    // 0xc1bc30: stur            x3, [fp, #-0x58]
    // 0xc1bc34: r1 = Function '<anonymous closure>':.
    //     0xc1bc34: add             x1, PP, #0xae, lsl #12  ; [pp+0xae138] AnonymousClosure: (0xc1b694), in [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalShape::paint (0xc1b968)
    //     0xc1bc38: ldr             x1, [x1, #0x138]
    // 0xc1bc3c: r0 = AllocateClosure()
    //     0xc1bc3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1bc40: ldur            x16, [fp, #-0x30]
    // 0xc1bc44: ldur            lr, [fp, #-0x58]
    // 0xc1bc48: stp             lr, x16, [SP]
    // 0xc1bc4c: ldur            x1, [fp, #-0x10]
    // 0xc1bc50: ldur            x2, [fp, #-0x28]
    // 0xc1bc54: ldur            x3, [fp, #-0x18]
    // 0xc1bc58: ldur            x5, [fp, #-0x50]
    // 0xc1bc5c: ldur            x6, [fp, #-0x40]
    // 0xc1bc60: mov             x7, x0
    // 0xc1bc64: r4 = const [0, 0x8, 0x2, 0x7, clipBehavior, 0x7, null]
    //     0xc1bc64: add             x4, PP, #0x90, lsl #12  ; [pp+0x90b68] List(7) [0, 0x8, 0x2, 0x7, "clipBehavior", 0x7, Null]
    //     0xc1bc68: ldr             x4, [x4, #0xb68]
    // 0xc1bc6c: r0 = pushClipPath()
    //     0xc1bc6c: bl              #0xc1a8a8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0xc1bc70: ldur            x1, [fp, #-0x38]
    // 0xc1bc74: mov             x2, x0
    // 0xc1bc78: r0 = layer=()
    //     0xc1bc78: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1bc7c: r0 = Null
    //     0xc1bc7c: mov             x0, NULL
    // 0xc1bc80: LeaveFrame
    //     0xc1bc80: mov             SP, fp
    //     0xc1bc84: ldp             fp, lr, [SP], #0x10
    // 0xc1bc88: ret
    //     0xc1bc88: ret             
    // 0xc1bc8c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1bc8c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1bc90: str             x16, [SP]
    // 0xc1bc94: r0 = _throwNew()
    //     0xc1bc94: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1bc98: brk             #0
    // 0xc1bc9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1bc9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1bca0: b               #0xc1b998
    // 0xc1bca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1bca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1bca8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1bca8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1bcac: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1bcac: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1bcb0: r9 = _needsCompositing
    //     0xc1bcb0: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1bcb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1bcb4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1bcb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1bcb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0x116e968, size: 0xdc
    // 0x116e968: EnterFrame
    //     0x116e968: stp             fp, lr, [SP, #-0x10]!
    //     0x116e96c: mov             fp, SP
    // 0x116e970: AllocStack(0x40)
    //     0x116e970: sub             SP, SP, #0x40
    // 0x116e974: SetupParameters(RenderPhysicalShape this /* r1 => r1, fp-0x8 */)
    //     0x116e974: stur            x1, [fp, #-8]
    // 0x116e978: CheckStackOverflow
    //     0x116e978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116e97c: cmp             SP, x16
    //     0x116e980: b.ls            #0x116ea38
    // 0x116e984: r0 = _NativePath()
    //     0x116e984: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x116e988: mov             x1, x0
    // 0x116e98c: stur            x0, [fp, #-0x10]
    // 0x116e990: r0 = __constructor$Method$FfiNative()
    //     0x116e990: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x116e994: ldur            x1, [fp, #-8]
    // 0x116e998: r0 = size()
    //     0x116e998: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x116e99c: mov             x2, x0
    // 0x116e9a0: r1 = Instance_Offset
    //     0x116e9a0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116e9a4: r0 = &()
    //     0x116e9a4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x116e9a8: LoadField: d0 = r0->field_7
    //     0x116e9a8: ldur            d0, [x0, #7]
    // 0x116e9ac: stur            d0, [fp, #-0x38]
    // 0x116e9b0: LoadField: d1 = r0->field_f
    //     0x116e9b0: ldur            d1, [x0, #0xf]
    // 0x116e9b4: stur            d1, [fp, #-0x30]
    // 0x116e9b8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x116e9b8: ldur            d2, [x0, #0x17]
    // 0x116e9bc: stur            d2, [fp, #-0x28]
    // 0x116e9c0: LoadField: d3 = r0->field_1f
    //     0x116e9c0: ldur            d3, [x0, #0x1f]
    // 0x116e9c4: ldur            x0, [fp, #-0x10]
    // 0x116e9c8: stur            d3, [fp, #-0x20]
    // 0x116e9cc: LoadField: r1 = r0->field_7
    //     0x116e9cc: ldur            w1, [x0, #7]
    // 0x116e9d0: DecompressPointer r1
    //     0x116e9d0: add             x1, x1, HEAP, lsl #32
    // 0x116e9d4: cmp             w1, NULL
    // 0x116e9d8: b.eq            #0x116ea40
    // 0x116e9dc: LoadField: r2 = r1->field_7
    //     0x116e9dc: ldur            x2, [x1, #7]
    // 0x116e9e0: ldr             x1, [x2]
    // 0x116e9e4: cbz             x1, #0x116ea28
    // 0x116e9e8: mov             x2, x1
    // 0x116e9ec: stur            x2, [fp, #-0x18]
    // 0x116e9f0: r1 = <Never>
    //     0x116e9f0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x116e9f4: r0 = Pointer()
    //     0x116e9f4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x116e9f8: mov             x1, x0
    // 0x116e9fc: ldur            x0, [fp, #-0x18]
    // 0x116ea00: StoreField: r1->field_7 = r0
    //     0x116ea00: stur            x0, [x1, #7]
    // 0x116ea04: ldur            d0, [fp, #-0x38]
    // 0x116ea08: ldur            d1, [fp, #-0x30]
    // 0x116ea0c: ldur            d2, [fp, #-0x28]
    // 0x116ea10: ldur            d3, [fp, #-0x20]
    // 0x116ea14: r0 = __addRect$Method$FfiNative()
    //     0x116ea14: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0x116ea18: ldur            x0, [fp, #-0x10]
    // 0x116ea1c: LeaveFrame
    //     0x116ea1c: mov             SP, fp
    //     0x116ea20: ldp             fp, lr, [SP], #0x10
    // 0x116ea24: ret
    //     0x116ea24: ret             
    // 0x116ea28: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x116ea28: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x116ea2c: str             x16, [SP]
    // 0x116ea30: r0 = _throwNew()
    //     0x116ea30: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x116ea34: brk             #0
    // 0x116ea38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ea38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ea3c: b               #0x116e984
    // 0x116ea40: r0 = NullErrorSharedWithFPURegs()
    //     0x116ea40: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 4932, size: 0x80, field offset: 0x78
class RenderPhysicalModel extends _RenderPhysicalModelBase<dynamic> {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf8b58, size: 0xa0
    // 0xaf8b58: EnterFrame
    //     0xaf8b58: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8b5c: mov             fp, SP
    // 0xaf8b60: AllocStack(0x18)
    //     0xaf8b60: sub             SP, SP, #0x18
    // 0xaf8b64: SetupParameters(RenderPhysicalModel this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xaf8b64: mov             x0, x2
    //     0xaf8b68: stur            x2, [fp, #-0x10]
    //     0xaf8b6c: mov             x2, x3
    //     0xaf8b70: stur            x3, [fp, #-0x18]
    //     0xaf8b74: mov             x3, x1
    //     0xaf8b78: stur            x1, [fp, #-8]
    // 0xaf8b7c: CheckStackOverflow
    //     0xaf8b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8b80: cmp             SP, x16
    //     0xaf8b84: b.ls            #0xaf8bec
    // 0xaf8b88: LoadField: r1 = r3->field_57
    //     0xaf8b88: ldur            w1, [x3, #0x57]
    // 0xaf8b8c: DecompressPointer r1
    //     0xaf8b8c: add             x1, x1, HEAP, lsl #32
    // 0xaf8b90: cmp             w1, NULL
    // 0xaf8b94: b.eq            #0xaf8bd0
    // 0xaf8b98: mov             x1, x3
    // 0xaf8b9c: r0 = _updateClip()
    //     0xaf8b9c: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xaf8ba0: ldur            x0, [fp, #-8]
    // 0xaf8ba4: LoadField: r1 = r0->field_5b
    //     0xaf8ba4: ldur            w1, [x0, #0x5b]
    // 0xaf8ba8: DecompressPointer r1
    //     0xaf8ba8: add             x1, x1, HEAP, lsl #32
    // 0xaf8bac: cmp             w1, NULL
    // 0xaf8bb0: b.eq            #0xaf8bf4
    // 0xaf8bb4: ldur            x2, [fp, #-0x18]
    // 0xaf8bb8: r0 = contains()
    //     0xaf8bb8: bl              #0xaf8c9c  ; [dart:ui] RRect::contains
    // 0xaf8bbc: tbz             w0, #4, #0xaf8bd0
    // 0xaf8bc0: r0 = false
    //     0xaf8bc0: add             x0, NULL, #0x30  ; false
    // 0xaf8bc4: LeaveFrame
    //     0xaf8bc4: mov             SP, fp
    //     0xaf8bc8: ldp             fp, lr, [SP], #0x10
    // 0xaf8bcc: ret
    //     0xaf8bcc: ret             
    // 0xaf8bd0: ldur            x1, [fp, #-8]
    // 0xaf8bd4: ldur            x2, [fp, #-0x10]
    // 0xaf8bd8: ldur            x3, [fp, #-0x18]
    // 0xaf8bdc: r0 = hitTest()
    //     0xaf8bdc: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf8be0: LeaveFrame
    //     0xaf8be0: mov             SP, fp
    //     0xaf8be4: ldp             fp, lr, [SP], #0x10
    // 0xaf8be8: ret
    //     0xaf8be8: ret             
    // 0xaf8bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8bec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8bf0: b               #0xaf8b88
    // 0xaf8bf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf8bf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1b2d8, size: 0x3bc
    // 0xc1b2d8: EnterFrame
    //     0xc1b2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1b2dc: mov             fp, SP
    // 0xc1b2e0: AllocStack(0x70)
    //     0xc1b2e0: sub             SP, SP, #0x70
    // 0xc1b2e4: SetupParameters(RenderPhysicalModel this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xc1b2e4: mov             x0, x1
    //     0xc1b2e8: stur            x1, [fp, #-8]
    //     0xc1b2ec: mov             x1, x2
    //     0xc1b2f0: stur            x2, [fp, #-0x10]
    //     0xc1b2f4: mov             x2, x3
    //     0xc1b2f8: stur            x3, [fp, #-0x18]
    // 0xc1b2fc: CheckStackOverflow
    //     0xc1b2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1b300: cmp             SP, x16
    //     0xc1b304: b.ls            #0xc1b678
    // 0xc1b308: r1 = 2
    //     0xc1b308: mov             x1, #2
    // 0xc1b30c: r0 = AllocateContext()
    //     0xc1b30c: bl              #0x13de838  ; AllocateContextStub
    // 0xc1b310: mov             x2, x0
    // 0xc1b314: ldur            x0, [fp, #-8]
    // 0xc1b318: stur            x2, [fp, #-0x20]
    // 0xc1b31c: StoreField: r2->field_f = r0
    //     0xc1b31c: stur            w0, [x2, #0xf]
    // 0xc1b320: LoadField: r1 = r0->field_4f
    //     0xc1b320: ldur            w1, [x0, #0x4f]
    // 0xc1b324: DecompressPointer r1
    //     0xc1b324: add             x1, x1, HEAP, lsl #32
    // 0xc1b328: cmp             w1, NULL
    // 0xc1b32c: b.ne            #0xc1b350
    // 0xc1b330: LoadField: r1 = r0->field_2f
    //     0xc1b330: ldur            w1, [x0, #0x2f]
    // 0xc1b334: DecompressPointer r1
    //     0xc1b334: add             x1, x1, HEAP, lsl #32
    // 0xc1b338: r2 = Null
    //     0xc1b338: mov             x2, NULL
    // 0xc1b33c: r0 = layer=()
    //     0xc1b33c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b340: r0 = Null
    //     0xc1b340: mov             x0, NULL
    // 0xc1b344: LeaveFrame
    //     0xc1b344: mov             SP, fp
    //     0xc1b348: ldp             fp, lr, [SP], #0x10
    // 0xc1b34c: ret
    //     0xc1b34c: ret             
    // 0xc1b350: mov             x1, x0
    // 0xc1b354: r0 = _updateClip()
    //     0xc1b354: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1b358: ldur            x0, [fp, #-8]
    // 0xc1b35c: LoadField: r1 = r0->field_5b
    //     0xc1b35c: ldur            w1, [x0, #0x5b]
    // 0xc1b360: DecompressPointer r1
    //     0xc1b360: add             x1, x1, HEAP, lsl #32
    // 0xc1b364: cmp             w1, NULL
    // 0xc1b368: b.eq            #0xc1b680
    // 0xc1b36c: ldur            x2, [fp, #-0x18]
    // 0xc1b370: r0 = shift()
    //     0xc1b370: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xc1b374: stur            x0, [fp, #-0x28]
    // 0xc1b378: r0 = _NativePath()
    //     0xc1b378: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xc1b37c: mov             x1, x0
    // 0xc1b380: stur            x0, [fp, #-0x30]
    // 0xc1b384: r0 = __constructor$Method$FfiNative()
    //     0xc1b384: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xc1b388: ldur            x2, [fp, #-0x28]
    // 0xc1b38c: LoadField: d0 = r2->field_b
    //     0xc1b38c: ldur            d0, [x2, #0xb]
    // 0xc1b390: fcvt            s1, d0
    // 0xc1b394: stur            d1, [fp, #-0x60]
    // 0xc1b398: r4 = 24
    //     0xc1b398: mov             x4, #0x18
    // 0xc1b39c: r0 = AllocateFloat32Array()
    //     0xc1b39c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xc1b3a0: ldur            d0, [fp, #-0x60]
    // 0xc1b3a4: stur            x0, [fp, #-0x40]
    // 0xc1b3a8: ArrayStore: r0[0] = d0  ; List_8
    //     0xc1b3a8: stur            s0, [x0, #0x17]
    // 0xc1b3ac: ldur            x2, [fp, #-0x28]
    // 0xc1b3b0: LoadField: d0 = r2->field_13
    //     0xc1b3b0: ldur            d0, [x2, #0x13]
    // 0xc1b3b4: fcvt            s1, d0
    // 0xc1b3b8: StoreField: r0->field_1b = d1
    //     0xc1b3b8: stur            s1, [x0, #0x1b]
    // 0xc1b3bc: LoadField: d0 = r2->field_1b
    //     0xc1b3bc: ldur            d0, [x2, #0x1b]
    // 0xc1b3c0: fcvt            s1, d0
    // 0xc1b3c4: StoreField: r0->field_1f = d1
    //     0xc1b3c4: stur            s1, [x0, #0x1f]
    // 0xc1b3c8: LoadField: d0 = r2->field_23
    //     0xc1b3c8: ldur            d0, [x2, #0x23]
    // 0xc1b3cc: fcvt            s1, d0
    // 0xc1b3d0: StoreField: r0->field_23 = d1
    //     0xc1b3d0: stur            s1, [x0, #0x23]
    // 0xc1b3d4: LoadField: d0 = r2->field_2b
    //     0xc1b3d4: ldur            d0, [x2, #0x2b]
    // 0xc1b3d8: fcvt            s1, d0
    // 0xc1b3dc: StoreField: r0->field_27 = d1
    //     0xc1b3dc: stur            s1, [x0, #0x27]
    // 0xc1b3e0: LoadField: d0 = r2->field_33
    //     0xc1b3e0: ldur            d0, [x2, #0x33]
    // 0xc1b3e4: fcvt            s1, d0
    // 0xc1b3e8: StoreField: r0->field_2b = d1
    //     0xc1b3e8: stur            s1, [x0, #0x2b]
    // 0xc1b3ec: LoadField: d0 = r2->field_3b
    //     0xc1b3ec: ldur            d0, [x2, #0x3b]
    // 0xc1b3f0: fcvt            s1, d0
    // 0xc1b3f4: StoreField: r0->field_2f = d1
    //     0xc1b3f4: stur            s1, [x0, #0x2f]
    // 0xc1b3f8: LoadField: d0 = r2->field_43
    //     0xc1b3f8: ldur            d0, [x2, #0x43]
    // 0xc1b3fc: fcvt            s1, d0
    // 0xc1b400: StoreField: r0->field_33 = d1
    //     0xc1b400: stur            s1, [x0, #0x33]
    // 0xc1b404: LoadField: d0 = r2->field_4b
    //     0xc1b404: ldur            d0, [x2, #0x4b]
    // 0xc1b408: fcvt            s1, d0
    // 0xc1b40c: StoreField: r0->field_37 = d1
    //     0xc1b40c: stur            s1, [x0, #0x37]
    // 0xc1b410: LoadField: d0 = r2->field_53
    //     0xc1b410: ldur            d0, [x2, #0x53]
    // 0xc1b414: fcvt            s1, d0
    // 0xc1b418: StoreField: r0->field_3b = d1
    //     0xc1b418: stur            s1, [x0, #0x3b]
    // 0xc1b41c: LoadField: d0 = r2->field_5b
    //     0xc1b41c: ldur            d0, [x2, #0x5b]
    // 0xc1b420: fcvt            s1, d0
    // 0xc1b424: StoreField: r0->field_3f = d1
    //     0xc1b424: stur            s1, [x0, #0x3f]
    // 0xc1b428: LoadField: d0 = r2->field_63
    //     0xc1b428: ldur            d0, [x2, #0x63]
    // 0xc1b42c: fcvt            s1, d0
    // 0xc1b430: StoreField: r0->field_43 = d1
    //     0xc1b430: stur            s1, [x0, #0x43]
    // 0xc1b434: ldur            x3, [fp, #-0x30]
    // 0xc1b438: LoadField: r1 = r3->field_7
    //     0xc1b438: ldur            w1, [x3, #7]
    // 0xc1b43c: DecompressPointer r1
    //     0xc1b43c: add             x1, x1, HEAP, lsl #32
    // 0xc1b440: cmp             w1, NULL
    // 0xc1b444: b.eq            #0xc1b684
    // 0xc1b448: LoadField: r4 = r1->field_7
    //     0xc1b448: ldur            x4, [x1, #7]
    // 0xc1b44c: ldr             x1, [x4]
    // 0xc1b450: cbz             x1, #0xc1b668
    // 0xc1b454: ldur            x4, [fp, #-8]
    // 0xc1b458: mov             x5, x1
    // 0xc1b45c: stur            x5, [fp, #-0x38]
    // 0xc1b460: r1 = <Never>
    //     0xc1b460: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1b464: r0 = Pointer()
    //     0xc1b464: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1b468: mov             x1, x0
    // 0xc1b46c: ldur            x0, [fp, #-0x38]
    // 0xc1b470: StoreField: r1->field_7 = r0
    //     0xc1b470: stur            x0, [x1, #7]
    // 0xc1b474: ldur            x2, [fp, #-0x40]
    // 0xc1b478: r0 = __addRRect$Method$FfiNative()
    //     0xc1b478: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xc1b47c: ldur            x1, [fp, #-0x10]
    // 0xc1b480: r0 = canvas()
    //     0xc1b480: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1b484: mov             x3, x0
    // 0xc1b488: ldur            x2, [fp, #-8]
    // 0xc1b48c: stur            x3, [fp, #-0x48]
    // 0xc1b490: LoadField: d0 = r2->field_67
    //     0xc1b490: ldur            d0, [x2, #0x67]
    // 0xc1b494: stur            d0, [fp, #-0x60]
    // 0xc1b498: d1 = 0.000000
    //     0xc1b498: eor             v1.16b, v1.16b, v1.16b
    // 0xc1b49c: fcmp            d0, d1
    // 0xc1b4a0: b.eq            #0xc1b4f0
    // 0xc1b4a4: LoadField: r4 = r2->field_6f
    //     0xc1b4a4: ldur            w4, [x2, #0x6f]
    // 0xc1b4a8: DecompressPointer r4
    //     0xc1b4a8: add             x4, x4, HEAP, lsl #32
    // 0xc1b4ac: stur            x4, [fp, #-0x40]
    // 0xc1b4b0: LoadField: r1 = r2->field_73
    //     0xc1b4b0: ldur            w1, [x2, #0x73]
    // 0xc1b4b4: DecompressPointer r1
    //     0xc1b4b4: add             x1, x1, HEAP, lsl #32
    // 0xc1b4b8: r0 = LoadClassIdInstr(r1)
    //     0xc1b4b8: ldur            x0, [x1, #-1]
    //     0xc1b4bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc1b4c0: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xc1b4c0: sub             lr, x0, #0xfc0
    //     0xc1b4c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc1b4c8: blr             lr
    // 0xc1b4cc: cmp             x0, #0xff
    // 0xc1b4d0: r16 = true
    //     0xc1b4d0: add             x16, NULL, #0x20  ; true
    // 0xc1b4d4: r17 = false
    //     0xc1b4d4: add             x17, NULL, #0x30  ; false
    // 0xc1b4d8: csel            x5, x16, x17, ne
    // 0xc1b4dc: ldur            x1, [fp, #-0x48]
    // 0xc1b4e0: ldur            x2, [fp, #-0x30]
    // 0xc1b4e4: ldur            x3, [fp, #-0x40]
    // 0xc1b4e8: ldur            d0, [fp, #-0x60]
    // 0xc1b4ec: r0 = drawShadow()
    //     0xc1b4ec: bl              #0xb742dc  ; [dart:ui] _NativeCanvas::drawShadow
    // 0xc1b4f0: ldur            x1, [fp, #-8]
    // 0xc1b4f4: ldur            x2, [fp, #-0x20]
    // 0xc1b4f8: LoadField: r0 = r1->field_5f
    //     0xc1b4f8: ldur            w0, [x1, #0x5f]
    // 0xc1b4fc: DecompressPointer r0
    //     0xc1b4fc: add             x0, x0, HEAP, lsl #32
    // 0xc1b500: r16 = Instance_Clip
    //     0xc1b500: add             x16, PP, #0x90, lsl #12  ; [pp+0x906a8] Obj!Clip@12c8121
    //     0xc1b504: ldr             x16, [x16, #0x6a8]
    // 0xc1b508: cmp             w0, w16
    // 0xc1b50c: r16 = true
    //     0xc1b50c: add             x16, NULL, #0x20  ; true
    // 0xc1b510: r17 = false
    //     0xc1b510: add             x17, NULL, #0x30  ; false
    // 0xc1b514: csel            x3, x16, x17, eq
    // 0xc1b518: StoreField: r2->field_13 = r3
    //     0xc1b518: stur            w3, [x2, #0x13]
    // 0xc1b51c: tbz             w3, #4, #0xc1b568
    // 0xc1b520: r16 = 136
    //     0xc1b520: mov             x16, #0x88
    // 0xc1b524: stp             x16, NULL, [SP]
    // 0xc1b528: r0 = ByteData()
    //     0xc1b528: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc1b52c: stur            x0, [fp, #-0x30]
    // 0xc1b530: r0 = Paint()
    //     0xc1b530: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1b534: mov             x3, x0
    // 0xc1b538: ldur            x0, [fp, #-0x30]
    // 0xc1b53c: stur            x3, [fp, #-0x40]
    // 0xc1b540: StoreField: r3->field_7 = r0
    //     0xc1b540: stur            w0, [x3, #7]
    // 0xc1b544: ldur            x0, [fp, #-8]
    // 0xc1b548: LoadField: r2 = r0->field_73
    //     0xc1b548: ldur            w2, [x0, #0x73]
    // 0xc1b54c: DecompressPointer r2
    //     0xc1b54c: add             x2, x2, HEAP, lsl #32
    // 0xc1b550: mov             x1, x3
    // 0xc1b554: r0 = color=()
    //     0xc1b554: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc1b558: ldur            x1, [fp, #-0x48]
    // 0xc1b55c: ldur            x2, [fp, #-0x28]
    // 0xc1b560: ldur            x3, [fp, #-0x40]
    // 0xc1b564: r0 = drawRRect()
    //     0xc1b564: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc1b568: ldur            x0, [fp, #-8]
    // 0xc1b56c: LoadField: r2 = r0->field_37
    //     0xc1b56c: ldur            w2, [x0, #0x37]
    // 0xc1b570: DecompressPointer r2
    //     0xc1b570: add             x2, x2, HEAP, lsl #32
    // 0xc1b574: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1b578: cmp             w2, w16
    // 0xc1b57c: b.eq            #0xc1b688
    // 0xc1b580: mov             x1, x0
    // 0xc1b584: stur            x2, [fp, #-0x28]
    // 0xc1b588: r0 = size()
    //     0xc1b588: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1b58c: mov             x2, x0
    // 0xc1b590: r1 = Instance_Offset
    //     0xc1b590: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1b594: r0 = &()
    //     0xc1b594: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1b598: mov             x4, x0
    // 0xc1b59c: ldur            x3, [fp, #-8]
    // 0xc1b5a0: stur            x4, [fp, #-0x50]
    // 0xc1b5a4: LoadField: r6 = r3->field_5b
    //     0xc1b5a4: ldur            w6, [x3, #0x5b]
    // 0xc1b5a8: DecompressPointer r6
    //     0xc1b5a8: add             x6, x6, HEAP, lsl #32
    // 0xc1b5ac: stur            x6, [fp, #-0x48]
    // 0xc1b5b0: cmp             w6, NULL
    // 0xc1b5b4: b.eq            #0xc1b690
    // 0xc1b5b8: LoadField: r5 = r3->field_2f
    //     0xc1b5b8: ldur            w5, [x3, #0x2f]
    // 0xc1b5bc: DecompressPointer r5
    //     0xc1b5bc: add             x5, x5, HEAP, lsl #32
    // 0xc1b5c0: stur            x5, [fp, #-0x40]
    // 0xc1b5c4: LoadField: r7 = r5->field_b
    //     0xc1b5c4: ldur            w7, [x5, #0xb]
    // 0xc1b5c8: DecompressPointer r7
    //     0xc1b5c8: add             x7, x7, HEAP, lsl #32
    // 0xc1b5cc: mov             x0, x7
    // 0xc1b5d0: stur            x7, [fp, #-0x30]
    // 0xc1b5d4: r2 = Null
    //     0xc1b5d4: mov             x2, NULL
    // 0xc1b5d8: r1 = Null
    //     0xc1b5d8: mov             x1, NULL
    // 0xc1b5dc: r4 = LoadClassIdInstr(r0)
    //     0xc1b5dc: ldur            x4, [x0, #-1]
    //     0xc1b5e0: ubfx            x4, x4, #0xc, #0x14
    // 0xc1b5e4: r17 = 4658
    //     0xc1b5e4: mov             x17, #0x1232
    // 0xc1b5e8: cmp             x4, x17
    // 0xc1b5ec: b.eq            #0xc1b604
    // 0xc1b5f0: r8 = ClipRRectLayer?
    //     0xc1b5f0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90bf0] Type: ClipRRectLayer?
    //     0xc1b5f4: ldr             x8, [x8, #0xbf0]
    // 0xc1b5f8: r3 = Null
    //     0xc1b5f8: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd8f8] Null
    //     0xc1b5fc: ldr             x3, [x3, #0x8f8]
    // 0xc1b600: r0 = DefaultNullableTypeTest()
    //     0xc1b600: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1b604: ldur            x0, [fp, #-8]
    // 0xc1b608: LoadField: r3 = r0->field_5f
    //     0xc1b608: ldur            w3, [x0, #0x5f]
    // 0xc1b60c: DecompressPointer r3
    //     0xc1b60c: add             x3, x3, HEAP, lsl #32
    // 0xc1b610: ldur            x2, [fp, #-0x20]
    // 0xc1b614: stur            x3, [fp, #-0x58]
    // 0xc1b618: r1 = Function '<anonymous closure>':.
    //     0xc1b618: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd908] AnonymousClosure: (0xc1b694), in [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalShape::paint (0xc1b968)
    //     0xc1b61c: ldr             x1, [x1, #0x908]
    // 0xc1b620: r0 = AllocateClosure()
    //     0xc1b620: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1b624: ldur            x16, [fp, #-0x58]
    // 0xc1b628: ldur            lr, [fp, #-0x30]
    // 0xc1b62c: stp             lr, x16, [SP]
    // 0xc1b630: ldur            x1, [fp, #-0x10]
    // 0xc1b634: ldur            x2, [fp, #-0x28]
    // 0xc1b638: ldur            x3, [fp, #-0x18]
    // 0xc1b63c: ldur            x5, [fp, #-0x50]
    // 0xc1b640: ldur            x6, [fp, #-0x48]
    // 0xc1b644: mov             x7, x0
    // 0xc1b648: r0 = pushClipRRect()
    //     0xc1b648: bl              #0xc19c70  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRRect
    // 0xc1b64c: ldur            x1, [fp, #-0x40]
    // 0xc1b650: mov             x2, x0
    // 0xc1b654: r0 = layer=()
    //     0xc1b654: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b658: r0 = Null
    //     0xc1b658: mov             x0, NULL
    // 0xc1b65c: LeaveFrame
    //     0xc1b65c: mov             SP, fp
    //     0xc1b660: ldp             fp, lr, [SP], #0x10
    // 0xc1b664: ret
    //     0xc1b664: ret             
    // 0xc1b668: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1b668: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1b66c: str             x16, [SP]
    // 0xc1b670: r0 = _throwNew()
    //     0xc1b670: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1b674: brk             #0
    // 0xc1b678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1b678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1b67c: b               #0xc1b308
    // 0xc1b680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1b680: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1b684: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1b684: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1b688: r9 = _needsCompositing
    //     0xc1b688: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1b68c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1b68c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1b690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1b690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ borderRadius=(/* No info */) {
    // ** addr: 0xcf6a20, size: 0xa4
    // 0xcf6a20: EnterFrame
    //     0xcf6a20: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6a24: mov             fp, SP
    // 0xcf6a28: AllocStack(0x20)
    //     0xcf6a28: sub             SP, SP, #0x20
    // 0xcf6a2c: SetupParameters(RenderPhysicalModel this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf6a2c: stur            x1, [fp, #-8]
    //     0xcf6a30: mov             x16, x2
    //     0xcf6a34: mov             x2, x1
    //     0xcf6a38: mov             x1, x16
    //     0xcf6a3c: stur            x1, [fp, #-0x10]
    // 0xcf6a40: CheckStackOverflow
    //     0xcf6a40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6a44: cmp             SP, x16
    //     0xcf6a48: b.ls            #0xcf6abc
    // 0xcf6a4c: LoadField: r0 = r2->field_7b
    //     0xcf6a4c: ldur            w0, [x2, #0x7b]
    // 0xcf6a50: DecompressPointer r0
    //     0xcf6a50: add             x0, x0, HEAP, lsl #32
    // 0xcf6a54: r3 = LoadClassIdInstr(r0)
    //     0xcf6a54: ldur            x3, [x0, #-1]
    //     0xcf6a58: ubfx            x3, x3, #0xc, #0x14
    // 0xcf6a5c: stp             x1, x0, [SP]
    // 0xcf6a60: mov             x0, x3
    // 0xcf6a64: mov             lr, x0
    // 0xcf6a68: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6a6c: blr             lr
    // 0xcf6a70: tbnz            w0, #4, #0xcf6a84
    // 0xcf6a74: r0 = Null
    //     0xcf6a74: mov             x0, NULL
    // 0xcf6a78: LeaveFrame
    //     0xcf6a78: mov             SP, fp
    //     0xcf6a7c: ldp             fp, lr, [SP], #0x10
    // 0xcf6a80: ret
    //     0xcf6a80: ret             
    // 0xcf6a84: ldur            x1, [fp, #-8]
    // 0xcf6a88: ldur            x0, [fp, #-0x10]
    // 0xcf6a8c: StoreField: r1->field_7b = r0
    //     0xcf6a8c: stur            w0, [x1, #0x7b]
    //     0xcf6a90: ldurb           w16, [x1, #-1]
    //     0xcf6a94: ldurb           w17, [x0, #-1]
    //     0xcf6a98: and             x16, x17, x16, lsr #2
    //     0xcf6a9c: tst             x16, HEAP, lsr #32
    //     0xcf6aa0: b.eq            #0xcf6aa8
    //     0xcf6aa4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6aa8: r0 = _markNeedsClip()
    //     0xcf6aa8: bl              #0xc05d0c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0xcf6aac: r0 = Null
    //     0xcf6aac: mov             x0, NULL
    // 0xcf6ab0: LeaveFrame
    //     0xcf6ab0: mov             SP, fp
    //     0xcf6ab4: ldp             fp, lr, [SP], #0x10
    // 0xcf6ab8: ret
    //     0xcf6ab8: ret             
    // 0xcf6abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6abc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6ac0: b               #0xcf6a4c
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0x116e844, size: 0xdc
    // 0x116e844: EnterFrame
    //     0x116e844: stp             fp, lr, [SP, #-0x10]!
    //     0x116e848: mov             fp, SP
    // 0x116e84c: AllocStack(0x20)
    //     0x116e84c: sub             SP, SP, #0x20
    // 0x116e850: SetupParameters(RenderPhysicalModel this /* r1 => r0, fp-0x8 */)
    //     0x116e850: mov             x0, x1
    //     0x116e854: stur            x1, [fp, #-8]
    // 0x116e858: CheckStackOverflow
    //     0x116e858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116e85c: cmp             SP, x16
    //     0x116e860: b.ls            #0x116e918
    // 0x116e864: mov             x1, x0
    // 0x116e868: r0 = size()
    //     0x116e868: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x116e86c: mov             x2, x0
    // 0x116e870: r1 = Instance_Offset
    //     0x116e870: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116e874: r0 = &()
    //     0x116e874: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x116e878: mov             x2, x0
    // 0x116e87c: ldur            x0, [fp, #-8]
    // 0x116e880: stur            x2, [fp, #-0x10]
    // 0x116e884: LoadField: r1 = r0->field_77
    //     0x116e884: ldur            w1, [x0, #0x77]
    // 0x116e888: DecompressPointer r1
    //     0x116e888: add             x1, x1, HEAP, lsl #32
    // 0x116e88c: LoadField: r3 = r1->field_7
    //     0x116e88c: ldur            x3, [x1, #7]
    // 0x116e890: cmp             x3, #0
    // 0x116e894: b.gt            #0x116e8b8
    // 0x116e898: LoadField: r1 = r0->field_7b
    //     0x116e898: ldur            w1, [x0, #0x7b]
    // 0x116e89c: DecompressPointer r1
    //     0x116e89c: add             x1, x1, HEAP, lsl #32
    // 0x116e8a0: cmp             w1, NULL
    // 0x116e8a4: b.ne            #0x116e8b0
    // 0x116e8a8: r1 = Instance_BorderRadius
    //     0x116e8a8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x116e8ac: ldr             x1, [x1, #0x508]
    // 0x116e8b0: r0 = toRRect()
    //     0x116e8b0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x116e8b4: b               #0x116e90c
    // 0x116e8b8: d0 = 2.000000
    //     0x116e8b8: fmov            d0, #2.00000000
    // 0x116e8bc: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x116e8bc: ldur            d1, [x2, #0x17]
    // 0x116e8c0: LoadField: d2 = r2->field_7
    //     0x116e8c0: ldur            d2, [x2, #7]
    // 0x116e8c4: fsub            d3, d1, d2
    // 0x116e8c8: fdiv            d1, d3, d0
    // 0x116e8cc: stur            d1, [fp, #-0x20]
    // 0x116e8d0: LoadField: d2 = r2->field_1f
    //     0x116e8d0: ldur            d2, [x2, #0x1f]
    // 0x116e8d4: LoadField: d3 = r2->field_f
    //     0x116e8d4: ldur            d3, [x2, #0xf]
    // 0x116e8d8: fsub            d4, d2, d3
    // 0x116e8dc: fdiv            d2, d4, d0
    // 0x116e8e0: stur            d2, [fp, #-0x18]
    // 0x116e8e4: r1 = <RRect>
    //     0x116e8e4: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x116e8e8: ldr             x1, [x1, #0x108]
    // 0x116e8ec: r0 = RRect()
    //     0x116e8ec: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x116e8f0: mov             x1, x0
    // 0x116e8f4: ldur            x2, [fp, #-0x10]
    // 0x116e8f8: ldur            d0, [fp, #-0x20]
    // 0x116e8fc: ldur            d1, [fp, #-0x18]
    // 0x116e900: stur            x0, [fp, #-8]
    // 0x116e904: r0 = RRect.fromRectXY()
    //     0x116e904: bl              #0x116e920  ; [dart:ui] RRect::RRect.fromRectXY
    // 0x116e908: ldur            x0, [fp, #-8]
    // 0x116e90c: LeaveFrame
    //     0x116e90c: mov             SP, fp
    //     0x116e910: ldp             fp, lr, [SP], #0x10
    // 0x116e914: ret
    //     0x116e914: ret             
    // 0x116e918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116e918: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116e91c: b               #0x116e864
  }
  _ RenderPhysicalModel(/* No info */) {
    // ** addr: 0x11d0abc, size: 0xbc
    // 0x11d0abc: EnterFrame
    //     0x11d0abc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0ac0: mov             fp, SP
    // 0x11d0ac4: r0 = Instance_BoxShape
    //     0x11d0ac4: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0x11d0ac8: ldr             x0, [x0, #0x1f8]
    // 0x11d0acc: mov             x4, x2
    // 0x11d0ad0: mov             x2, x5
    // 0x11d0ad4: mov             x5, x1
    // 0x11d0ad8: mov             x1, x6
    // 0x11d0adc: CheckStackOverflow
    //     0x11d0adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0ae0: cmp             SP, x16
    //     0x11d0ae4: b.ls            #0x11d0b70
    // 0x11d0ae8: StoreField: r5->field_77 = r0
    //     0x11d0ae8: stur            w0, [x5, #0x77]
    // 0x11d0aec: mov             x0, x4
    // 0x11d0af0: StoreField: r5->field_7b = r0
    //     0x11d0af0: stur            w0, [x5, #0x7b]
    //     0x11d0af4: ldurb           w16, [x5, #-1]
    //     0x11d0af8: ldurb           w17, [x0, #-1]
    //     0x11d0afc: and             x16, x17, x16, lsr #2
    //     0x11d0b00: tst             x16, HEAP, lsr #32
    //     0x11d0b04: b.eq            #0x11d0b0c
    //     0x11d0b08: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d0b0c: StoreField: r5->field_67 = d0
    //     0x11d0b0c: stur            d0, [x5, #0x67]
    // 0x11d0b10: mov             x0, x2
    // 0x11d0b14: StoreField: r5->field_73 = r0
    //     0x11d0b14: stur            w0, [x5, #0x73]
    //     0x11d0b18: ldurb           w16, [x5, #-1]
    //     0x11d0b1c: ldurb           w17, [x0, #-1]
    //     0x11d0b20: and             x16, x17, x16, lsr #2
    //     0x11d0b24: tst             x16, HEAP, lsr #32
    //     0x11d0b28: b.eq            #0x11d0b30
    //     0x11d0b2c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d0b30: mov             x0, x1
    // 0x11d0b34: StoreField: r5->field_6f = r0
    //     0x11d0b34: stur            w0, [x5, #0x6f]
    //     0x11d0b38: ldurb           w16, [x5, #-1]
    //     0x11d0b3c: ldurb           w17, [x0, #-1]
    //     0x11d0b40: and             x16, x17, x16, lsr #2
    //     0x11d0b44: tst             x16, HEAP, lsr #32
    //     0x11d0b48: b.eq            #0x11d0b50
    //     0x11d0b4c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d0b50: mov             x1, x5
    // 0x11d0b54: mov             x2, x3
    // 0x11d0b58: r3 = Null
    //     0x11d0b58: mov             x3, NULL
    // 0x11d0b5c: r0 = _RenderCustomClip()
    //     0x11d0b5c: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0b60: r0 = Null
    //     0x11d0b60: mov             x0, NULL
    // 0x11d0b64: LeaveFrame
    //     0x11d0b64: mov             SP, fp
    //     0x11d0b68: ldp             fp, lr, [SP], #0x10
    // 0x11d0b6c: ret
    //     0x11d0b6c: ret             
    // 0x11d0b70: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d0b70: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d0b74: b               #0x11d0ae8
  }
}

// class id: 4933, size: 0x68, field offset: 0x68
class RenderClipPath extends _RenderCustomClip<dynamic> {

  _ paint(/* No info */) {
    // ** addr: 0xc1b120, size: 0x1b8
    // 0xc1b120: EnterFrame
    //     0xc1b120: stp             fp, lr, [SP, #-0x10]!
    //     0xc1b124: mov             fp, SP
    // 0xc1b128: AllocStack(0x58)
    //     0xc1b128: sub             SP, SP, #0x58
    // 0xc1b12c: SetupParameters(RenderClipPath this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1b12c: mov             x0, x2
    //     0xc1b130: stur            x2, [fp, #-0x10]
    //     0xc1b134: mov             x2, x1
    //     0xc1b138: stur            x1, [fp, #-8]
    //     0xc1b13c: stur            x3, [fp, #-0x18]
    // 0xc1b140: CheckStackOverflow
    //     0xc1b140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1b144: cmp             SP, x16
    //     0xc1b148: b.ls            #0xc1b2c4
    // 0xc1b14c: LoadField: r1 = r2->field_4f
    //     0xc1b14c: ldur            w1, [x2, #0x4f]
    // 0xc1b150: DecompressPointer r1
    //     0xc1b150: add             x1, x1, HEAP, lsl #32
    // 0xc1b154: cmp             w1, NULL
    // 0xc1b158: b.eq            #0xc1b2a0
    // 0xc1b15c: LoadField: r4 = r2->field_5f
    //     0xc1b15c: ldur            w4, [x2, #0x5f]
    // 0xc1b160: DecompressPointer r4
    //     0xc1b160: add             x4, x4, HEAP, lsl #32
    // 0xc1b164: r16 = Instance_Clip
    //     0xc1b164: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1b168: ldr             x16, [x16, #0x840]
    // 0xc1b16c: cmp             w4, w16
    // 0xc1b170: b.eq            #0xc1b274
    // 0xc1b174: mov             x1, x2
    // 0xc1b178: r0 = _updateClip()
    //     0xc1b178: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1b17c: ldur            x0, [fp, #-8]
    // 0xc1b180: LoadField: r2 = r0->field_37
    //     0xc1b180: ldur            w2, [x0, #0x37]
    // 0xc1b184: DecompressPointer r2
    //     0xc1b184: add             x2, x2, HEAP, lsl #32
    // 0xc1b188: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1b18c: cmp             w2, w16
    // 0xc1b190: b.eq            #0xc1b2cc
    // 0xc1b194: mov             x1, x0
    // 0xc1b198: stur            x2, [fp, #-0x20]
    // 0xc1b19c: r0 = size()
    //     0xc1b19c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1b1a0: mov             x2, x0
    // 0xc1b1a4: r1 = Instance_Offset
    //     0xc1b1a4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1b1a8: r0 = &()
    //     0xc1b1a8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1b1ac: mov             x4, x0
    // 0xc1b1b0: ldur            x3, [fp, #-8]
    // 0xc1b1b4: stur            x4, [fp, #-0x48]
    // 0xc1b1b8: LoadField: r6 = r3->field_5b
    //     0xc1b1b8: ldur            w6, [x3, #0x5b]
    // 0xc1b1bc: DecompressPointer r6
    //     0xc1b1bc: add             x6, x6, HEAP, lsl #32
    // 0xc1b1c0: stur            x6, [fp, #-0x40]
    // 0xc1b1c4: cmp             w6, NULL
    // 0xc1b1c8: b.eq            #0xc1b2d4
    // 0xc1b1cc: LoadField: r5 = r3->field_5f
    //     0xc1b1cc: ldur            w5, [x3, #0x5f]
    // 0xc1b1d0: DecompressPointer r5
    //     0xc1b1d0: add             x5, x5, HEAP, lsl #32
    // 0xc1b1d4: stur            x5, [fp, #-0x38]
    // 0xc1b1d8: LoadField: r7 = r3->field_2f
    //     0xc1b1d8: ldur            w7, [x3, #0x2f]
    // 0xc1b1dc: DecompressPointer r7
    //     0xc1b1dc: add             x7, x7, HEAP, lsl #32
    // 0xc1b1e0: stur            x7, [fp, #-0x30]
    // 0xc1b1e4: LoadField: r8 = r7->field_b
    //     0xc1b1e4: ldur            w8, [x7, #0xb]
    // 0xc1b1e8: DecompressPointer r8
    //     0xc1b1e8: add             x8, x8, HEAP, lsl #32
    // 0xc1b1ec: mov             x0, x8
    // 0xc1b1f0: stur            x8, [fp, #-0x28]
    // 0xc1b1f4: r2 = Null
    //     0xc1b1f4: mov             x2, NULL
    // 0xc1b1f8: r1 = Null
    //     0xc1b1f8: mov             x1, NULL
    // 0xc1b1fc: r4 = LoadClassIdInstr(r0)
    //     0xc1b1fc: ldur            x4, [x0, #-1]
    //     0xc1b200: ubfx            x4, x4, #0xc, #0x14
    // 0xc1b204: r17 = 4656
    //     0xc1b204: mov             x17, #0x1230
    // 0xc1b208: cmp             x4, x17
    // 0xc1b20c: b.eq            #0xc1b224
    // 0xc1b210: r8 = ClipPathLayer?
    //     0xc1b210: add             x8, PP, #0x90, lsl #12  ; [pp+0x90b50] Type: ClipPathLayer?
    //     0xc1b214: ldr             x8, [x8, #0xb50]
    // 0xc1b218: r3 = Null
    //     0xc1b218: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a5e0] Null
    //     0xc1b21c: ldr             x3, [x3, #0x5e0]
    // 0xc1b220: r0 = DefaultNullableTypeTest()
    //     0xc1b220: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1b224: ldur            x2, [fp, #-8]
    // 0xc1b228: r1 = Function 'paint':.
    //     0xc1b228: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1b22c: ldr             x1, [x1, #0x4e0]
    // 0xc1b230: r0 = AllocateClosure()
    //     0xc1b230: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1b234: ldur            x16, [fp, #-0x28]
    // 0xc1b238: ldur            lr, [fp, #-0x38]
    // 0xc1b23c: stp             lr, x16, [SP]
    // 0xc1b240: ldur            x1, [fp, #-0x10]
    // 0xc1b244: ldur            x2, [fp, #-0x20]
    // 0xc1b248: ldur            x3, [fp, #-0x18]
    // 0xc1b24c: ldur            x5, [fp, #-0x48]
    // 0xc1b250: ldur            x6, [fp, #-0x40]
    // 0xc1b254: mov             x7, x0
    // 0xc1b258: r4 = const [0, 0x8, 0x2, 0x7, clipBehavior, 0x7, null]
    //     0xc1b258: add             x4, PP, #0x90, lsl #12  ; [pp+0x90b68] List(7) [0, 0x8, 0x2, 0x7, "clipBehavior", 0x7, Null]
    //     0xc1b25c: ldr             x4, [x4, #0xb68]
    // 0xc1b260: r0 = pushClipPath()
    //     0xc1b260: bl              #0xc1a8a8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0xc1b264: ldur            x1, [fp, #-0x30]
    // 0xc1b268: mov             x2, x0
    // 0xc1b26c: r0 = layer=()
    //     0xc1b26c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b270: b               #0xc1b2b4
    // 0xc1b274: mov             x0, x2
    // 0xc1b278: mov             x2, x1
    // 0xc1b27c: ldur            x1, [fp, #-0x10]
    // 0xc1b280: ldur            x3, [fp, #-0x18]
    // 0xc1b284: r0 = paintChild()
    //     0xc1b284: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc1b288: ldur            x0, [fp, #-8]
    // 0xc1b28c: LoadField: r1 = r0->field_2f
    //     0xc1b28c: ldur            w1, [x0, #0x2f]
    // 0xc1b290: DecompressPointer r1
    //     0xc1b290: add             x1, x1, HEAP, lsl #32
    // 0xc1b294: r2 = Null
    //     0xc1b294: mov             x2, NULL
    // 0xc1b298: r0 = layer=()
    //     0xc1b298: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b29c: b               #0xc1b2b4
    // 0xc1b2a0: mov             x0, x2
    // 0xc1b2a4: LoadField: r1 = r0->field_2f
    //     0xc1b2a4: ldur            w1, [x0, #0x2f]
    // 0xc1b2a8: DecompressPointer r1
    //     0xc1b2a8: add             x1, x1, HEAP, lsl #32
    // 0xc1b2ac: r2 = Null
    //     0xc1b2ac: mov             x2, NULL
    // 0xc1b2b0: r0 = layer=()
    //     0xc1b2b0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1b2b4: r0 = Null
    //     0xc1b2b4: mov             x0, NULL
    // 0xc1b2b8: LeaveFrame
    //     0xc1b2b8: mov             SP, fp
    //     0xc1b2bc: ldp             fp, lr, [SP], #0x10
    // 0xc1b2c0: ret
    //     0xc1b2c0: ret             
    // 0xc1b2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1b2c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1b2c8: b               #0xc1b14c
    // 0xc1b2cc: r9 = _needsCompositing
    //     0xc1b2cc: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1b2d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1b2d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1b2d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1b2d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4934, size: 0x70, field offset: 0x68
class RenderClipOval extends _RenderCustomClip<dynamic> {

  late Path _cachedPath; // offset: 0x6c

  _ hitTest(/* No info */) {
    // ** addr: 0xaf8a74, size: 0xe4
    // 0xaf8a74: EnterFrame
    //     0xaf8a74: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8a78: mov             fp, SP
    // 0xaf8a7c: AllocStack(0x18)
    //     0xaf8a7c: sub             SP, SP, #0x18
    // 0xaf8a80: SetupParameters(RenderClipOval this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xaf8a80: mov             x0, x1
    //     0xaf8a84: stur            x1, [fp, #-8]
    //     0xaf8a88: stur            x2, [fp, #-0x10]
    //     0xaf8a8c: stur            x3, [fp, #-0x18]
    // 0xaf8a90: CheckStackOverflow
    //     0xaf8a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8a94: cmp             SP, x16
    //     0xaf8a98: b.ls            #0xaf8b48
    // 0xaf8a9c: mov             x1, x0
    // 0xaf8aa0: r0 = _updateClip()
    //     0xaf8aa0: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xaf8aa4: ldur            x0, [fp, #-8]
    // 0xaf8aa8: LoadField: r1 = r0->field_5b
    //     0xaf8aa8: ldur            w1, [x0, #0x5b]
    // 0xaf8aac: DecompressPointer r1
    //     0xaf8aac: add             x1, x1, HEAP, lsl #32
    // 0xaf8ab0: cmp             w1, NULL
    // 0xaf8ab4: b.eq            #0xaf8b50
    // 0xaf8ab8: r0 = center()
    //     0xaf8ab8: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xaf8abc: ldur            x3, [fp, #-0x18]
    // 0xaf8ac0: LoadField: d0 = r3->field_7
    //     0xaf8ac0: ldur            d0, [x3, #7]
    // 0xaf8ac4: LoadField: d1 = r0->field_7
    //     0xaf8ac4: ldur            d1, [x0, #7]
    // 0xaf8ac8: fsub            d2, d0, d1
    // 0xaf8acc: ldur            x1, [fp, #-8]
    // 0xaf8ad0: LoadField: r2 = r1->field_5b
    //     0xaf8ad0: ldur            w2, [x1, #0x5b]
    // 0xaf8ad4: DecompressPointer r2
    //     0xaf8ad4: add             x2, x2, HEAP, lsl #32
    // 0xaf8ad8: cmp             w2, NULL
    // 0xaf8adc: b.eq            #0xaf8b54
    // 0xaf8ae0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xaf8ae0: ldur            d0, [x2, #0x17]
    // 0xaf8ae4: LoadField: d1 = r2->field_7
    //     0xaf8ae4: ldur            d1, [x2, #7]
    // 0xaf8ae8: fsub            d3, d0, d1
    // 0xaf8aec: fdiv            d0, d2, d3
    // 0xaf8af0: LoadField: d1 = r3->field_f
    //     0xaf8af0: ldur            d1, [x3, #0xf]
    // 0xaf8af4: LoadField: d2 = r0->field_f
    //     0xaf8af4: ldur            d2, [x0, #0xf]
    // 0xaf8af8: fsub            d3, d1, d2
    // 0xaf8afc: LoadField: d1 = r2->field_1f
    //     0xaf8afc: ldur            d1, [x2, #0x1f]
    // 0xaf8b00: LoadField: d2 = r2->field_f
    //     0xaf8b00: ldur            d2, [x2, #0xf]
    // 0xaf8b04: fsub            d4, d1, d2
    // 0xaf8b08: fdiv            d1, d3, d4
    // 0xaf8b0c: fmul            d2, d0, d0
    // 0xaf8b10: fmul            d0, d1, d1
    // 0xaf8b14: fadd            d1, d2, d0
    // 0xaf8b18: d0 = 0.250000
    //     0xaf8b18: fmov            d0, #0.25000000
    // 0xaf8b1c: fcmp            d1, d0
    // 0xaf8b20: b.le            #0xaf8b34
    // 0xaf8b24: r0 = false
    //     0xaf8b24: add             x0, NULL, #0x30  ; false
    // 0xaf8b28: LeaveFrame
    //     0xaf8b28: mov             SP, fp
    //     0xaf8b2c: ldp             fp, lr, [SP], #0x10
    // 0xaf8b30: ret
    //     0xaf8b30: ret             
    // 0xaf8b34: ldur            x2, [fp, #-0x10]
    // 0xaf8b38: r0 = hitTest()
    //     0xaf8b38: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf8b3c: LeaveFrame
    //     0xaf8b3c: mov             SP, fp
    //     0xaf8b40: ldp             fp, lr, [SP], #0x10
    // 0xaf8b44: ret
    //     0xaf8b44: ret             
    // 0xaf8b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8b4c: b               #0xaf8a9c
    // 0xaf8b50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf8b50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaf8b54: r0 = NullCastErrorSharedWithFPURegs()
    //     0xaf8b54: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1a6f8, size: 0x1b0
    // 0xc1a6f8: EnterFrame
    //     0xc1a6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a6fc: mov             fp, SP
    // 0xc1a700: AllocStack(0x58)
    //     0xc1a700: sub             SP, SP, #0x58
    // 0xc1a704: SetupParameters(RenderClipOval this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1a704: mov             x0, x2
    //     0xc1a708: stur            x2, [fp, #-0x10]
    //     0xc1a70c: mov             x2, x1
    //     0xc1a710: stur            x1, [fp, #-8]
    //     0xc1a714: stur            x3, [fp, #-0x18]
    // 0xc1a718: CheckStackOverflow
    //     0xc1a718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a71c: cmp             SP, x16
    //     0xc1a720: b.ls            #0xc1a894
    // 0xc1a724: LoadField: r1 = r2->field_4f
    //     0xc1a724: ldur            w1, [x2, #0x4f]
    // 0xc1a728: DecompressPointer r1
    //     0xc1a728: add             x1, x1, HEAP, lsl #32
    // 0xc1a72c: cmp             w1, NULL
    // 0xc1a730: b.eq            #0xc1a870
    // 0xc1a734: LoadField: r4 = r2->field_5f
    //     0xc1a734: ldur            w4, [x2, #0x5f]
    // 0xc1a738: DecompressPointer r4
    //     0xc1a738: add             x4, x4, HEAP, lsl #32
    // 0xc1a73c: r16 = Instance_Clip
    //     0xc1a73c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1a740: ldr             x16, [x16, #0x840]
    // 0xc1a744: cmp             w4, w16
    // 0xc1a748: b.eq            #0xc1a844
    // 0xc1a74c: mov             x1, x2
    // 0xc1a750: r0 = _updateClip()
    //     0xc1a750: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1a754: ldur            x0, [fp, #-8]
    // 0xc1a758: LoadField: r3 = r0->field_37
    //     0xc1a758: ldur            w3, [x0, #0x37]
    // 0xc1a75c: DecompressPointer r3
    //     0xc1a75c: add             x3, x3, HEAP, lsl #32
    // 0xc1a760: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1a764: cmp             w3, w16
    // 0xc1a768: b.eq            #0xc1a89c
    // 0xc1a76c: stur            x3, [fp, #-0x28]
    // 0xc1a770: LoadField: r4 = r0->field_5b
    //     0xc1a770: ldur            w4, [x0, #0x5b]
    // 0xc1a774: DecompressPointer r4
    //     0xc1a774: add             x4, x4, HEAP, lsl #32
    // 0xc1a778: stur            x4, [fp, #-0x20]
    // 0xc1a77c: cmp             w4, NULL
    // 0xc1a780: b.eq            #0xc1a8a4
    // 0xc1a784: mov             x1, x0
    // 0xc1a788: mov             x2, x4
    // 0xc1a78c: r0 = _getClipPath()
    //     0xc1a78c: bl              #0xc1afb8  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipOval::_getClipPath
    // 0xc1a790: mov             x4, x0
    // 0xc1a794: ldur            x3, [fp, #-8]
    // 0xc1a798: stur            x4, [fp, #-0x48]
    // 0xc1a79c: LoadField: r5 = r3->field_5f
    //     0xc1a79c: ldur            w5, [x3, #0x5f]
    // 0xc1a7a0: DecompressPointer r5
    //     0xc1a7a0: add             x5, x5, HEAP, lsl #32
    // 0xc1a7a4: stur            x5, [fp, #-0x40]
    // 0xc1a7a8: LoadField: r6 = r3->field_2f
    //     0xc1a7a8: ldur            w6, [x3, #0x2f]
    // 0xc1a7ac: DecompressPointer r6
    //     0xc1a7ac: add             x6, x6, HEAP, lsl #32
    // 0xc1a7b0: stur            x6, [fp, #-0x38]
    // 0xc1a7b4: LoadField: r7 = r6->field_b
    //     0xc1a7b4: ldur            w7, [x6, #0xb]
    // 0xc1a7b8: DecompressPointer r7
    //     0xc1a7b8: add             x7, x7, HEAP, lsl #32
    // 0xc1a7bc: mov             x0, x7
    // 0xc1a7c0: stur            x7, [fp, #-0x30]
    // 0xc1a7c4: r2 = Null
    //     0xc1a7c4: mov             x2, NULL
    // 0xc1a7c8: r1 = Null
    //     0xc1a7c8: mov             x1, NULL
    // 0xc1a7cc: r4 = LoadClassIdInstr(r0)
    //     0xc1a7cc: ldur            x4, [x0, #-1]
    //     0xc1a7d0: ubfx            x4, x4, #0xc, #0x14
    // 0xc1a7d4: r17 = 4656
    //     0xc1a7d4: mov             x17, #0x1230
    // 0xc1a7d8: cmp             x4, x17
    // 0xc1a7dc: b.eq            #0xc1a7f4
    // 0xc1a7e0: r8 = ClipPathLayer?
    //     0xc1a7e0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90b50] Type: ClipPathLayer?
    //     0xc1a7e4: ldr             x8, [x8, #0xb50]
    // 0xc1a7e8: r3 = Null
    //     0xc1a7e8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90b58] Null
    //     0xc1a7ec: ldr             x3, [x3, #0xb58]
    // 0xc1a7f0: r0 = DefaultNullableTypeTest()
    //     0xc1a7f0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1a7f4: ldur            x2, [fp, #-8]
    // 0xc1a7f8: r1 = Function 'paint':.
    //     0xc1a7f8: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1a7fc: ldr             x1, [x1, #0x4e0]
    // 0xc1a800: r0 = AllocateClosure()
    //     0xc1a800: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1a804: ldur            x16, [fp, #-0x30]
    // 0xc1a808: ldur            lr, [fp, #-0x40]
    // 0xc1a80c: stp             lr, x16, [SP]
    // 0xc1a810: ldur            x1, [fp, #-0x10]
    // 0xc1a814: ldur            x2, [fp, #-0x28]
    // 0xc1a818: ldur            x3, [fp, #-0x18]
    // 0xc1a81c: ldur            x5, [fp, #-0x20]
    // 0xc1a820: ldur            x6, [fp, #-0x48]
    // 0xc1a824: mov             x7, x0
    // 0xc1a828: r4 = const [0, 0x8, 0x2, 0x7, clipBehavior, 0x7, null]
    //     0xc1a828: add             x4, PP, #0x90, lsl #12  ; [pp+0x90b68] List(7) [0, 0x8, 0x2, 0x7, "clipBehavior", 0x7, Null]
    //     0xc1a82c: ldr             x4, [x4, #0xb68]
    // 0xc1a830: r0 = pushClipPath()
    //     0xc1a830: bl              #0xc1a8a8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0xc1a834: ldur            x1, [fp, #-0x38]
    // 0xc1a838: mov             x2, x0
    // 0xc1a83c: r0 = layer=()
    //     0xc1a83c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a840: b               #0xc1a884
    // 0xc1a844: mov             x0, x2
    // 0xc1a848: mov             x2, x1
    // 0xc1a84c: ldur            x1, [fp, #-0x10]
    // 0xc1a850: ldur            x3, [fp, #-0x18]
    // 0xc1a854: r0 = paintChild()
    //     0xc1a854: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc1a858: ldur            x0, [fp, #-8]
    // 0xc1a85c: LoadField: r1 = r0->field_2f
    //     0xc1a85c: ldur            w1, [x0, #0x2f]
    // 0xc1a860: DecompressPointer r1
    //     0xc1a860: add             x1, x1, HEAP, lsl #32
    // 0xc1a864: r2 = Null
    //     0xc1a864: mov             x2, NULL
    // 0xc1a868: r0 = layer=()
    //     0xc1a868: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a86c: b               #0xc1a884
    // 0xc1a870: mov             x0, x2
    // 0xc1a874: LoadField: r1 = r0->field_2f
    //     0xc1a874: ldur            w1, [x0, #0x2f]
    // 0xc1a878: DecompressPointer r1
    //     0xc1a878: add             x1, x1, HEAP, lsl #32
    // 0xc1a87c: r2 = Null
    //     0xc1a87c: mov             x2, NULL
    // 0xc1a880: r0 = layer=()
    //     0xc1a880: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a884: r0 = Null
    //     0xc1a884: mov             x0, NULL
    // 0xc1a888: LeaveFrame
    //     0xc1a888: mov             SP, fp
    //     0xc1a88c: ldp             fp, lr, [SP], #0x10
    // 0xc1a890: ret
    //     0xc1a890: ret             
    // 0xc1a894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a894: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a898: b               #0xc1a724
    // 0xc1a89c: r9 = _needsCompositing
    //     0xc1a89c: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1a8a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1a8a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1a8a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1a8a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getClipPath(/* No info */) {
    // ** addr: 0xc1afb8, size: 0x168
    // 0xc1afb8: EnterFrame
    //     0xc1afb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1afbc: mov             fp, SP
    // 0xc1afc0: AllocStack(0x48)
    //     0xc1afc0: sub             SP, SP, #0x48
    // 0xc1afc4: SetupParameters(RenderClipOval this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1afc4: mov             x0, x2
    //     0xc1afc8: stur            x1, [fp, #-8]
    //     0xc1afcc: stur            x2, [fp, #-0x10]
    // 0xc1afd0: CheckStackOverflow
    //     0xc1afd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1afd4: cmp             SP, x16
    //     0xc1afd8: b.ls            #0xc1b104
    // 0xc1afdc: LoadField: r2 = r1->field_67
    //     0xc1afdc: ldur            w2, [x1, #0x67]
    // 0xc1afe0: DecompressPointer r2
    //     0xc1afe0: add             x2, x2, HEAP, lsl #32
    // 0xc1afe4: stp             x2, x0, [SP]
    // 0xc1afe8: r0 = ==()
    //     0xc1afe8: bl              #0x128bdfc  ; [dart:ui] Rect::==
    // 0xc1afec: tbz             w0, #4, #0xc1b0d0
    // 0xc1aff0: ldur            x1, [fp, #-8]
    // 0xc1aff4: ldur            x0, [fp, #-0x10]
    // 0xc1aff8: StoreField: r1->field_67 = r0
    //     0xc1aff8: stur            w0, [x1, #0x67]
    //     0xc1affc: ldurb           w16, [x1, #-1]
    //     0xc1b000: ldurb           w17, [x0, #-1]
    //     0xc1b004: and             x16, x17, x16, lsr #2
    //     0xc1b008: tst             x16, HEAP, lsr #32
    //     0xc1b00c: b.eq            #0xc1b014
    //     0xc1b010: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1b014: r0 = _NativePath()
    //     0xc1b014: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xc1b018: mov             x1, x0
    // 0xc1b01c: stur            x0, [fp, #-0x10]
    // 0xc1b020: r0 = __constructor$Method$FfiNative()
    //     0xc1b020: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xc1b024: ldur            x0, [fp, #-8]
    // 0xc1b028: LoadField: r1 = r0->field_67
    //     0xc1b028: ldur            w1, [x0, #0x67]
    // 0xc1b02c: DecompressPointer r1
    //     0xc1b02c: add             x1, x1, HEAP, lsl #32
    // 0xc1b030: cmp             w1, NULL
    // 0xc1b034: b.eq            #0xc1b10c
    // 0xc1b038: LoadField: d0 = r1->field_7
    //     0xc1b038: ldur            d0, [x1, #7]
    // 0xc1b03c: stur            d0, [fp, #-0x38]
    // 0xc1b040: LoadField: d1 = r1->field_f
    //     0xc1b040: ldur            d1, [x1, #0xf]
    // 0xc1b044: stur            d1, [fp, #-0x30]
    // 0xc1b048: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xc1b048: ldur            d2, [x1, #0x17]
    // 0xc1b04c: stur            d2, [fp, #-0x28]
    // 0xc1b050: LoadField: d3 = r1->field_1f
    //     0xc1b050: ldur            d3, [x1, #0x1f]
    // 0xc1b054: ldur            x2, [fp, #-0x10]
    // 0xc1b058: stur            d3, [fp, #-0x20]
    // 0xc1b05c: LoadField: r1 = r2->field_7
    //     0xc1b05c: ldur            w1, [x2, #7]
    // 0xc1b060: DecompressPointer r1
    //     0xc1b060: add             x1, x1, HEAP, lsl #32
    // 0xc1b064: cmp             w1, NULL
    // 0xc1b068: b.eq            #0xc1b110
    // 0xc1b06c: LoadField: r3 = r1->field_7
    //     0xc1b06c: ldur            x3, [x1, #7]
    // 0xc1b070: ldr             x1, [x3]
    // 0xc1b074: cbz             x1, #0xc1b0f4
    // 0xc1b078: mov             x3, x1
    // 0xc1b07c: stur            x3, [fp, #-0x18]
    // 0xc1b080: r1 = <Never>
    //     0xc1b080: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1b084: r0 = Pointer()
    //     0xc1b084: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1b088: mov             x1, x0
    // 0xc1b08c: ldur            x0, [fp, #-0x18]
    // 0xc1b090: StoreField: r1->field_7 = r0
    //     0xc1b090: stur            x0, [x1, #7]
    // 0xc1b094: ldur            d0, [fp, #-0x38]
    // 0xc1b098: ldur            d1, [fp, #-0x30]
    // 0xc1b09c: ldur            d2, [fp, #-0x28]
    // 0xc1b0a0: ldur            d3, [fp, #-0x20]
    // 0xc1b0a4: r0 = __addOval$Method$FfiNative()
    //     0xc1b0a4: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xc1b0a8: ldur            x0, [fp, #-0x10]
    // 0xc1b0ac: ldur            x1, [fp, #-8]
    // 0xc1b0b0: StoreField: r1->field_6b = r0
    //     0xc1b0b0: stur            w0, [x1, #0x6b]
    //     0xc1b0b4: ldurb           w16, [x1, #-1]
    //     0xc1b0b8: ldurb           w17, [x0, #-1]
    //     0xc1b0bc: and             x16, x17, x16, lsr #2
    //     0xc1b0c0: tst             x16, HEAP, lsr #32
    //     0xc1b0c4: b.eq            #0xc1b0cc
    //     0xc1b0c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1b0cc: b               #0xc1b0d4
    // 0xc1b0d0: ldur            x1, [fp, #-8]
    // 0xc1b0d4: LoadField: r0 = r1->field_6b
    //     0xc1b0d4: ldur            w0, [x1, #0x6b]
    // 0xc1b0d8: DecompressPointer r0
    //     0xc1b0d8: add             x0, x0, HEAP, lsl #32
    // 0xc1b0dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1b0e0: cmp             w0, w16
    // 0xc1b0e4: b.eq            #0xc1b114
    // 0xc1b0e8: LeaveFrame
    //     0xc1b0e8: mov             SP, fp
    //     0xc1b0ec: ldp             fp, lr, [SP], #0x10
    // 0xc1b0f0: ret
    //     0xc1b0f0: ret             
    // 0xc1b0f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1b0f4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1b0f8: str             x16, [SP]
    // 0xc1b0fc: r0 = _throwNew()
    //     0xc1b0fc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1b100: brk             #0
    // 0xc1b104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1b104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1b108: b               #0xc1afdc
    // 0xc1b10c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1b10c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1b110: r0 = NullErrorSharedWithFPURegs()
    //     0xc1b110: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc1b114: r9 = _cachedPath
    //     0xc1b114: add             x9, PP, #0x90, lsl #12  ; [pp+0x90ba0] Field <RenderClipOval._cachedPath@37160605>: late (offset: 0x6c)
    //     0xc1b118: ldr             x9, [x9, #0xba0]
    // 0xc1b11c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1b11c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0x116e80c, size: 0x38
    // 0x116e80c: EnterFrame
    //     0x116e80c: stp             fp, lr, [SP, #-0x10]!
    //     0x116e810: mov             fp, SP
    // 0x116e814: CheckStackOverflow
    //     0x116e814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116e818: cmp             SP, x16
    //     0x116e81c: b.ls            #0x116e83c
    // 0x116e820: r0 = size()
    //     0x116e820: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x116e824: mov             x2, x0
    // 0x116e828: r1 = Instance_Offset
    //     0x116e828: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116e82c: r0 = &()
    //     0x116e82c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x116e830: LeaveFrame
    //     0x116e830: mov             SP, fp
    //     0x116e834: ldp             fp, lr, [SP], #0x10
    // 0x116e838: ret
    //     0x116e838: ret             
    // 0x116e83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116e83c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116e840: b               #0x116e820
  }
}

// class id: 4935, size: 0x70, field offset: 0x68
class RenderClipRSuperellipse extends _RenderCustomClip<dynamic> {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf855c, size: 0xa8
    // 0xaf855c: EnterFrame
    //     0xaf855c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8560: mov             fp, SP
    // 0xaf8564: AllocStack(0x18)
    //     0xaf8564: sub             SP, SP, #0x18
    // 0xaf8568: SetupParameters(RenderClipRSuperellipse this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xaf8568: mov             x0, x2
    //     0xaf856c: stur            x2, [fp, #-0x10]
    //     0xaf8570: mov             x2, x3
    //     0xaf8574: stur            x3, [fp, #-0x18]
    //     0xaf8578: mov             x3, x1
    //     0xaf857c: stur            x1, [fp, #-8]
    // 0xaf8580: CheckStackOverflow
    //     0xaf8580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8584: cmp             SP, x16
    //     0xaf8588: b.ls            #0xaf85f8
    // 0xaf858c: LoadField: r1 = r3->field_57
    //     0xaf858c: ldur            w1, [x3, #0x57]
    // 0xaf8590: DecompressPointer r1
    //     0xaf8590: add             x1, x1, HEAP, lsl #32
    // 0xaf8594: cmp             w1, NULL
    // 0xaf8598: b.eq            #0xaf85dc
    // 0xaf859c: mov             x1, x3
    // 0xaf85a0: r0 = _updateClip()
    //     0xaf85a0: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xaf85a4: ldur            x0, [fp, #-8]
    // 0xaf85a8: LoadField: r1 = r0->field_5b
    //     0xaf85a8: ldur            w1, [x0, #0x5b]
    // 0xaf85ac: DecompressPointer r1
    //     0xaf85ac: add             x1, x1, HEAP, lsl #32
    // 0xaf85b0: cmp             w1, NULL
    // 0xaf85b4: b.eq            #0xaf8600
    // 0xaf85b8: r0 = outerRect()
    //     0xaf85b8: bl              #0xaf8a18  ; [dart:ui] _RRectLike::outerRect
    // 0xaf85bc: mov             x1, x0
    // 0xaf85c0: ldur            x2, [fp, #-0x18]
    // 0xaf85c4: r0 = contains()
    //     0xaf85c4: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xaf85c8: tbz             w0, #4, #0xaf85dc
    // 0xaf85cc: r0 = false
    //     0xaf85cc: add             x0, NULL, #0x30  ; false
    // 0xaf85d0: LeaveFrame
    //     0xaf85d0: mov             SP, fp
    //     0xaf85d4: ldp             fp, lr, [SP], #0x10
    // 0xaf85d8: ret
    //     0xaf85d8: ret             
    // 0xaf85dc: ldur            x1, [fp, #-8]
    // 0xaf85e0: ldur            x2, [fp, #-0x10]
    // 0xaf85e4: ldur            x3, [fp, #-0x18]
    // 0xaf85e8: r0 = hitTest()
    //     0xaf85e8: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf85ec: LeaveFrame
    //     0xaf85ec: mov             SP, fp
    //     0xaf85f0: ldp             fp, lr, [SP], #0x10
    // 0xaf85f4: ret
    //     0xaf85f4: ret             
    // 0xaf85f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf85f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf85fc: b               #0xaf858c
    // 0xaf8600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf8600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1a09c, size: 0x1b4
    // 0xc1a09c: EnterFrame
    //     0xc1a09c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a0a0: mov             fp, SP
    // 0xc1a0a4: AllocStack(0x58)
    //     0xc1a0a4: sub             SP, SP, #0x58
    // 0xc1a0a8: SetupParameters(RenderClipRSuperellipse this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1a0a8: mov             x0, x2
    //     0xc1a0ac: stur            x2, [fp, #-0x10]
    //     0xc1a0b0: mov             x2, x1
    //     0xc1a0b4: stur            x1, [fp, #-8]
    //     0xc1a0b8: stur            x3, [fp, #-0x18]
    // 0xc1a0bc: CheckStackOverflow
    //     0xc1a0bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a0c0: cmp             SP, x16
    //     0xc1a0c4: b.ls            #0xc1a238
    // 0xc1a0c8: LoadField: r1 = r2->field_4f
    //     0xc1a0c8: ldur            w1, [x2, #0x4f]
    // 0xc1a0cc: DecompressPointer r1
    //     0xc1a0cc: add             x1, x1, HEAP, lsl #32
    // 0xc1a0d0: cmp             w1, NULL
    // 0xc1a0d4: b.eq            #0xc1a214
    // 0xc1a0d8: LoadField: r4 = r2->field_5f
    //     0xc1a0d8: ldur            w4, [x2, #0x5f]
    // 0xc1a0dc: DecompressPointer r4
    //     0xc1a0dc: add             x4, x4, HEAP, lsl #32
    // 0xc1a0e0: r16 = Instance_Clip
    //     0xc1a0e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1a0e4: ldr             x16, [x16, #0x840]
    // 0xc1a0e8: cmp             w4, w16
    // 0xc1a0ec: b.eq            #0xc1a1e8
    // 0xc1a0f0: mov             x1, x2
    // 0xc1a0f4: r0 = _updateClip()
    //     0xc1a0f4: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1a0f8: ldur            x2, [fp, #-8]
    // 0xc1a0fc: LoadField: r0 = r2->field_37
    //     0xc1a0fc: ldur            w0, [x2, #0x37]
    // 0xc1a100: DecompressPointer r0
    //     0xc1a100: add             x0, x0, HEAP, lsl #32
    // 0xc1a104: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1a108: cmp             w0, w16
    // 0xc1a10c: b.eq            #0xc1a240
    // 0xc1a110: stur            x0, [fp, #-0x20]
    // 0xc1a114: LoadField: r1 = r2->field_5b
    //     0xc1a114: ldur            w1, [x2, #0x5b]
    // 0xc1a118: DecompressPointer r1
    //     0xc1a118: add             x1, x1, HEAP, lsl #32
    // 0xc1a11c: cmp             w1, NULL
    // 0xc1a120: b.eq            #0xc1a248
    // 0xc1a124: r0 = outerRect()
    //     0xc1a124: bl              #0xaf8a18  ; [dart:ui] _RRectLike::outerRect
    // 0xc1a128: mov             x4, x0
    // 0xc1a12c: ldur            x3, [fp, #-8]
    // 0xc1a130: stur            x4, [fp, #-0x48]
    // 0xc1a134: LoadField: r6 = r3->field_5b
    //     0xc1a134: ldur            w6, [x3, #0x5b]
    // 0xc1a138: DecompressPointer r6
    //     0xc1a138: add             x6, x6, HEAP, lsl #32
    // 0xc1a13c: stur            x6, [fp, #-0x40]
    // 0xc1a140: cmp             w6, NULL
    // 0xc1a144: b.eq            #0xc1a24c
    // 0xc1a148: LoadField: r5 = r3->field_5f
    //     0xc1a148: ldur            w5, [x3, #0x5f]
    // 0xc1a14c: DecompressPointer r5
    //     0xc1a14c: add             x5, x5, HEAP, lsl #32
    // 0xc1a150: stur            x5, [fp, #-0x38]
    // 0xc1a154: LoadField: r7 = r3->field_2f
    //     0xc1a154: ldur            w7, [x3, #0x2f]
    // 0xc1a158: DecompressPointer r7
    //     0xc1a158: add             x7, x7, HEAP, lsl #32
    // 0xc1a15c: stur            x7, [fp, #-0x30]
    // 0xc1a160: LoadField: r8 = r7->field_b
    //     0xc1a160: ldur            w8, [x7, #0xb]
    // 0xc1a164: DecompressPointer r8
    //     0xc1a164: add             x8, x8, HEAP, lsl #32
    // 0xc1a168: mov             x0, x8
    // 0xc1a16c: stur            x8, [fp, #-0x28]
    // 0xc1a170: r2 = Null
    //     0xc1a170: mov             x2, NULL
    // 0xc1a174: r1 = Null
    //     0xc1a174: mov             x1, NULL
    // 0xc1a178: r4 = LoadClassIdInstr(r0)
    //     0xc1a178: ldur            x4, [x0, #-1]
    //     0xc1a17c: ubfx            x4, x4, #0xc, #0x14
    // 0xc1a180: r17 = 4657
    //     0xc1a180: mov             x17, #0x1231
    // 0xc1a184: cmp             x4, x17
    // 0xc1a188: b.eq            #0xc1a1a0
    // 0xc1a18c: r8 = ClipRSuperellipseLayer?
    //     0xc1a18c: add             x8, PP, #0xd1, lsl #12  ; [pp+0xd1e68] Type: ClipRSuperellipseLayer?
    //     0xc1a190: ldr             x8, [x8, #0xe68]
    // 0xc1a194: r3 = Null
    //     0xc1a194: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1e70] Null
    //     0xc1a198: ldr             x3, [x3, #0xe70]
    // 0xc1a19c: r0 = DefaultNullableTypeTest()
    //     0xc1a19c: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc1a1a0: ldur            x2, [fp, #-8]
    // 0xc1a1a4: r1 = Function 'paint':.
    //     0xc1a1a4: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc1a1a8: ldr             x1, [x1, #0x4e0]
    // 0xc1a1ac: r0 = AllocateClosure()
    //     0xc1a1ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1a1b0: ldur            x16, [fp, #-0x38]
    // 0xc1a1b4: ldur            lr, [fp, #-0x28]
    // 0xc1a1b8: stp             lr, x16, [SP]
    // 0xc1a1bc: ldur            x1, [fp, #-0x10]
    // 0xc1a1c0: ldur            x2, [fp, #-0x20]
    // 0xc1a1c4: ldur            x3, [fp, #-0x18]
    // 0xc1a1c8: ldur            x5, [fp, #-0x48]
    // 0xc1a1cc: ldur            x6, [fp, #-0x40]
    // 0xc1a1d0: mov             x7, x0
    // 0xc1a1d4: r0 = pushClipRSuperellipse()
    //     0xc1a1d4: bl              #0xc1a250  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRSuperellipse
    // 0xc1a1d8: ldur            x1, [fp, #-0x30]
    // 0xc1a1dc: mov             x2, x0
    // 0xc1a1e0: r0 = layer=()
    //     0xc1a1e0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a1e4: b               #0xc1a228
    // 0xc1a1e8: mov             x0, x2
    // 0xc1a1ec: mov             x2, x1
    // 0xc1a1f0: ldur            x1, [fp, #-0x10]
    // 0xc1a1f4: ldur            x3, [fp, #-0x18]
    // 0xc1a1f8: r0 = paintChild()
    //     0xc1a1f8: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc1a1fc: ldur            x0, [fp, #-8]
    // 0xc1a200: LoadField: r1 = r0->field_2f
    //     0xc1a200: ldur            w1, [x0, #0x2f]
    // 0xc1a204: DecompressPointer r1
    //     0xc1a204: add             x1, x1, HEAP, lsl #32
    // 0xc1a208: r2 = Null
    //     0xc1a208: mov             x2, NULL
    // 0xc1a20c: r0 = layer=()
    //     0xc1a20c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a210: b               #0xc1a228
    // 0xc1a214: mov             x0, x2
    // 0xc1a218: LoadField: r1 = r0->field_2f
    //     0xc1a218: ldur            w1, [x0, #0x2f]
    // 0xc1a21c: DecompressPointer r1
    //     0xc1a21c: add             x1, x1, HEAP, lsl #32
    // 0xc1a220: r2 = Null
    //     0xc1a220: mov             x2, NULL
    // 0xc1a224: r0 = layer=()
    //     0xc1a224: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1a228: r0 = Null
    //     0xc1a228: mov             x0, NULL
    // 0xc1a22c: LeaveFrame
    //     0xc1a22c: mov             SP, fp
    //     0xc1a230: ldp             fp, lr, [SP], #0x10
    // 0xc1a234: ret
    //     0xc1a234: ret             
    // 0xc1a238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a23c: b               #0xc1a0c8
    // 0xc1a240: r9 = _needsCompositing
    //     0xc1a240: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1a244: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1a244: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1a248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1a248: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1a24c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1a24c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf641c, size: 0x70
    // 0xcf641c: EnterFrame
    //     0xcf641c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6420: mov             fp, SP
    // 0xcf6424: mov             x0, x2
    // 0xcf6428: CheckStackOverflow
    //     0xcf6428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf642c: cmp             SP, x16
    //     0xcf6430: b.ls            #0xcf6484
    // 0xcf6434: LoadField: r2 = r1->field_6b
    //     0xcf6434: ldur            w2, [x1, #0x6b]
    // 0xcf6438: DecompressPointer r2
    //     0xcf6438: add             x2, x2, HEAP, lsl #32
    // 0xcf643c: cmp             w2, w0
    // 0xcf6440: b.ne            #0xcf6454
    // 0xcf6444: r0 = Null
    //     0xcf6444: mov             x0, NULL
    // 0xcf6448: LeaveFrame
    //     0xcf6448: mov             SP, fp
    //     0xcf644c: ldp             fp, lr, [SP], #0x10
    // 0xcf6450: ret
    //     0xcf6450: ret             
    // 0xcf6454: StoreField: r1->field_6b = r0
    //     0xcf6454: stur            w0, [x1, #0x6b]
    //     0xcf6458: ldurb           w16, [x1, #-1]
    //     0xcf645c: ldurb           w17, [x0, #-1]
    //     0xcf6460: and             x16, x17, x16, lsr #2
    //     0xcf6464: tst             x16, HEAP, lsr #32
    //     0xcf6468: b.eq            #0xcf6470
    //     0xcf646c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf6470: r0 = _markNeedsClip()
    //     0xcf6470: bl              #0xc05d0c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0xcf6474: r0 = Null
    //     0xcf6474: mov             x0, NULL
    // 0xcf6478: LeaveFrame
    //     0xcf6478: mov             SP, fp
    //     0xcf647c: ldp             fp, lr, [SP], #0x10
    // 0xcf6480: ret
    //     0xcf6480: ret             
    // 0xcf6484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6488: b               #0xcf6434
  }
  set _ borderRadius=(/* No info */) {
    // ** addr: 0xcf648c, size: 0x88
    // 0xcf648c: EnterFrame
    //     0xcf648c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6490: mov             fp, SP
    // 0xcf6494: AllocStack(0x20)
    //     0xcf6494: sub             SP, SP, #0x20
    // 0xcf6498: SetupParameters(RenderClipRSuperellipse this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf6498: mov             x0, x2
    //     0xcf649c: stur            x1, [fp, #-8]
    //     0xcf64a0: stur            x2, [fp, #-0x10]
    // 0xcf64a4: CheckStackOverflow
    //     0xcf64a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf64a8: cmp             SP, x16
    //     0xcf64ac: b.ls            #0xcf650c
    // 0xcf64b0: LoadField: r2 = r1->field_67
    //     0xcf64b0: ldur            w2, [x1, #0x67]
    // 0xcf64b4: DecompressPointer r2
    //     0xcf64b4: add             x2, x2, HEAP, lsl #32
    // 0xcf64b8: stp             x0, x2, [SP]
    // 0xcf64bc: r0 = ==()
    //     0xcf64bc: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xcf64c0: tbnz            w0, #4, #0xcf64d4
    // 0xcf64c4: r0 = Null
    //     0xcf64c4: mov             x0, NULL
    // 0xcf64c8: LeaveFrame
    //     0xcf64c8: mov             SP, fp
    //     0xcf64cc: ldp             fp, lr, [SP], #0x10
    // 0xcf64d0: ret
    //     0xcf64d0: ret             
    // 0xcf64d4: ldur            x1, [fp, #-8]
    // 0xcf64d8: ldur            x0, [fp, #-0x10]
    // 0xcf64dc: StoreField: r1->field_67 = r0
    //     0xcf64dc: stur            w0, [x1, #0x67]
    //     0xcf64e0: ldurb           w16, [x1, #-1]
    //     0xcf64e4: ldurb           w17, [x0, #-1]
    //     0xcf64e8: and             x16, x17, x16, lsr #2
    //     0xcf64ec: tst             x16, HEAP, lsr #32
    //     0xcf64f0: b.eq            #0xcf64f8
    //     0xcf64f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf64f8: r0 = _markNeedsClip()
    //     0xcf64f8: bl              #0xc05d0c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0xcf64fc: r0 = Null
    //     0xcf64fc: mov             x0, NULL
    // 0xcf6500: LeaveFrame
    //     0xcf6500: mov             SP, fp
    //     0xcf6504: ldp             fp, lr, [SP], #0x10
    // 0xcf6508: ret
    //     0xcf6508: ret             
    // 0xcf650c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf650c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6510: b               #0xcf64b0
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0x116e7b8, size: 0x54
    // 0x116e7b8: EnterFrame
    //     0x116e7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x116e7bc: mov             fp, SP
    // 0x116e7c0: AllocStack(0x8)
    //     0x116e7c0: sub             SP, SP, #8
    // 0x116e7c4: CheckStackOverflow
    //     0x116e7c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116e7c8: cmp             SP, x16
    //     0x116e7cc: b.ls            #0x116e804
    // 0x116e7d0: LoadField: r0 = r1->field_67
    //     0x116e7d0: ldur            w0, [x1, #0x67]
    // 0x116e7d4: DecompressPointer r0
    //     0x116e7d4: add             x0, x0, HEAP, lsl #32
    // 0x116e7d8: stur            x0, [fp, #-8]
    // 0x116e7dc: r0 = size()
    //     0x116e7dc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x116e7e0: mov             x2, x0
    // 0x116e7e4: r1 = Instance_Offset
    //     0x116e7e4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116e7e8: r0 = &()
    //     0x116e7e8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x116e7ec: ldur            x1, [fp, #-8]
    // 0x116e7f0: mov             x2, x0
    // 0x116e7f4: r0 = toRSuperellipse()
    //     0x116e7f4: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x116e7f8: LeaveFrame
    //     0x116e7f8: mov             SP, fp
    //     0x116e7fc: ldp             fp, lr, [SP], #0x10
    // 0x116e800: ret
    //     0x116e800: ret             
    // 0x116e804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116e804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116e808: b               #0x116e7d0
  }
}

// class id: 4936, size: 0x70, field offset: 0x68
class RenderClipRRect extends _RenderCustomClip<dynamic> {

  _ paint(/* No info */) {
    // ** addr: 0xc19abc, size: 0x1b4
    // 0xc19abc: EnterFrame
    //     0xc19abc: stp             fp, lr, [SP, #-0x10]!
    //     0xc19ac0: mov             fp, SP
    // 0xc19ac4: AllocStack(0x58)
    //     0xc19ac4: sub             SP, SP, #0x58
    // 0xc19ac8: SetupParameters(RenderClipRRect this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc19ac8: mov             x0, x2
    //     0xc19acc: stur            x2, [fp, #-0x10]
    //     0xc19ad0: mov             x2, x1
    //     0xc19ad4: stur            x1, [fp, #-8]
    //     0xc19ad8: stur            x3, [fp, #-0x18]
    // 0xc19adc: CheckStackOverflow
    //     0xc19adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19ae0: cmp             SP, x16
    //     0xc19ae4: b.ls            #0xc19c58
    // 0xc19ae8: LoadField: r1 = r2->field_4f
    //     0xc19ae8: ldur            w1, [x2, #0x4f]
    // 0xc19aec: DecompressPointer r1
    //     0xc19aec: add             x1, x1, HEAP, lsl #32
    // 0xc19af0: cmp             w1, NULL
    // 0xc19af4: b.eq            #0xc19c34
    // 0xc19af8: LoadField: r4 = r2->field_5f
    //     0xc19af8: ldur            w4, [x2, #0x5f]
    // 0xc19afc: DecompressPointer r4
    //     0xc19afc: add             x4, x4, HEAP, lsl #32
    // 0xc19b00: r16 = Instance_Clip
    //     0xc19b00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc19b04: ldr             x16, [x16, #0x840]
    // 0xc19b08: cmp             w4, w16
    // 0xc19b0c: b.eq            #0xc19c08
    // 0xc19b10: mov             x1, x2
    // 0xc19b14: r0 = _updateClip()
    //     0xc19b14: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc19b18: ldur            x2, [fp, #-8]
    // 0xc19b1c: LoadField: r0 = r2->field_37
    //     0xc19b1c: ldur            w0, [x2, #0x37]
    // 0xc19b20: DecompressPointer r0
    //     0xc19b20: add             x0, x0, HEAP, lsl #32
    // 0xc19b24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc19b28: cmp             w0, w16
    // 0xc19b2c: b.eq            #0xc19c60
    // 0xc19b30: stur            x0, [fp, #-0x20]
    // 0xc19b34: LoadField: r1 = r2->field_5b
    //     0xc19b34: ldur            w1, [x2, #0x5b]
    // 0xc19b38: DecompressPointer r1
    //     0xc19b38: add             x1, x1, HEAP, lsl #32
    // 0xc19b3c: cmp             w1, NULL
    // 0xc19b40: b.eq            #0xc19c68
    // 0xc19b44: r0 = outerRect()
    //     0xc19b44: bl              #0xaf8a18  ; [dart:ui] _RRectLike::outerRect
    // 0xc19b48: mov             x4, x0
    // 0xc19b4c: ldur            x3, [fp, #-8]
    // 0xc19b50: stur            x4, [fp, #-0x48]
    // 0xc19b54: LoadField: r6 = r3->field_5b
    //     0xc19b54: ldur            w6, [x3, #0x5b]
    // 0xc19b58: DecompressPointer r6
    //     0xc19b58: add             x6, x6, HEAP, lsl #32
    // 0xc19b5c: stur            x6, [fp, #-0x40]
    // 0xc19b60: cmp             w6, NULL
    // 0xc19b64: b.eq            #0xc19c6c
    // 0xc19b68: LoadField: r5 = r3->field_5f
    //     0xc19b68: ldur            w5, [x3, #0x5f]
    // 0xc19b6c: DecompressPointer r5
    //     0xc19b6c: add             x5, x5, HEAP, lsl #32
    // 0xc19b70: stur            x5, [fp, #-0x38]
    // 0xc19b74: LoadField: r7 = r3->field_2f
    //     0xc19b74: ldur            w7, [x3, #0x2f]
    // 0xc19b78: DecompressPointer r7
    //     0xc19b78: add             x7, x7, HEAP, lsl #32
    // 0xc19b7c: stur            x7, [fp, #-0x30]
    // 0xc19b80: LoadField: r8 = r7->field_b
    //     0xc19b80: ldur            w8, [x7, #0xb]
    // 0xc19b84: DecompressPointer r8
    //     0xc19b84: add             x8, x8, HEAP, lsl #32
    // 0xc19b88: mov             x0, x8
    // 0xc19b8c: stur            x8, [fp, #-0x28]
    // 0xc19b90: r2 = Null
    //     0xc19b90: mov             x2, NULL
    // 0xc19b94: r1 = Null
    //     0xc19b94: mov             x1, NULL
    // 0xc19b98: r4 = LoadClassIdInstr(r0)
    //     0xc19b98: ldur            x4, [x0, #-1]
    //     0xc19b9c: ubfx            x4, x4, #0xc, #0x14
    // 0xc19ba0: r17 = 4658
    //     0xc19ba0: mov             x17, #0x1232
    // 0xc19ba4: cmp             x4, x17
    // 0xc19ba8: b.eq            #0xc19bc0
    // 0xc19bac: r8 = ClipRRectLayer?
    //     0xc19bac: add             x8, PP, #0x90, lsl #12  ; [pp+0x90bf0] Type: ClipRRectLayer?
    //     0xc19bb0: ldr             x8, [x8, #0xbf0]
    // 0xc19bb4: r3 = Null
    //     0xc19bb4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90bf8] Null
    //     0xc19bb8: ldr             x3, [x3, #0xbf8]
    // 0xc19bbc: r0 = DefaultNullableTypeTest()
    //     0xc19bbc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc19bc0: ldur            x2, [fp, #-8]
    // 0xc19bc4: r1 = Function 'paint':.
    //     0xc19bc4: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc19bc8: ldr             x1, [x1, #0x4e0]
    // 0xc19bcc: r0 = AllocateClosure()
    //     0xc19bcc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc19bd0: ldur            x16, [fp, #-0x38]
    // 0xc19bd4: ldur            lr, [fp, #-0x28]
    // 0xc19bd8: stp             lr, x16, [SP]
    // 0xc19bdc: ldur            x1, [fp, #-0x10]
    // 0xc19be0: ldur            x2, [fp, #-0x20]
    // 0xc19be4: ldur            x3, [fp, #-0x18]
    // 0xc19be8: ldur            x5, [fp, #-0x48]
    // 0xc19bec: ldur            x6, [fp, #-0x40]
    // 0xc19bf0: mov             x7, x0
    // 0xc19bf4: r0 = pushClipRRect()
    //     0xc19bf4: bl              #0xc19c70  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRRect
    // 0xc19bf8: ldur            x1, [fp, #-0x30]
    // 0xc19bfc: mov             x2, x0
    // 0xc19c00: r0 = layer=()
    //     0xc19c00: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc19c04: b               #0xc19c48
    // 0xc19c08: mov             x0, x2
    // 0xc19c0c: mov             x2, x1
    // 0xc19c10: ldur            x1, [fp, #-0x10]
    // 0xc19c14: ldur            x3, [fp, #-0x18]
    // 0xc19c18: r0 = paintChild()
    //     0xc19c18: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc19c1c: ldur            x0, [fp, #-8]
    // 0xc19c20: LoadField: r1 = r0->field_2f
    //     0xc19c20: ldur            w1, [x0, #0x2f]
    // 0xc19c24: DecompressPointer r1
    //     0xc19c24: add             x1, x1, HEAP, lsl #32
    // 0xc19c28: r2 = Null
    //     0xc19c28: mov             x2, NULL
    // 0xc19c2c: r0 = layer=()
    //     0xc19c2c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc19c30: b               #0xc19c48
    // 0xc19c34: mov             x0, x2
    // 0xc19c38: LoadField: r1 = r0->field_2f
    //     0xc19c38: ldur            w1, [x0, #0x2f]
    // 0xc19c3c: DecompressPointer r1
    //     0xc19c3c: add             x1, x1, HEAP, lsl #32
    // 0xc19c40: r2 = Null
    //     0xc19c40: mov             x2, NULL
    // 0xc19c44: r0 = layer=()
    //     0xc19c44: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc19c48: r0 = Null
    //     0xc19c48: mov             x0, NULL
    // 0xc19c4c: LeaveFrame
    //     0xc19c4c: mov             SP, fp
    //     0xc19c50: ldp             fp, lr, [SP], #0x10
    // 0xc19c54: ret
    //     0xc19c54: ret             
    // 0xc19c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19c58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19c5c: b               #0xc19ae8
    // 0xc19c60: r9 = _needsCompositing
    //     0xc19c60: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc19c64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc19c64: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc19c68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc19c68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc19c6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc19c6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0x116e644, size: 0x174
    // 0x116e644: EnterFrame
    //     0x116e644: stp             fp, lr, [SP, #-0x10]!
    //     0x116e648: mov             fp, SP
    // 0x116e64c: AllocStack(0x28)
    //     0x116e64c: sub             SP, SP, #0x28
    // 0x116e650: SetupParameters(RenderClipRRect this /* r1 => r1, fp-0x28 */)
    //     0x116e650: stur            x1, [fp, #-0x28]
    // 0x116e654: CheckStackOverflow
    //     0x116e654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116e658: cmp             SP, x16
    //     0x116e65c: b.ls            #0x116e7ac
    // 0x116e660: LoadField: r0 = r1->field_67
    //     0x116e660: ldur            w0, [x1, #0x67]
    // 0x116e664: DecompressPointer r0
    //     0x116e664: add             x0, x0, HEAP, lsl #32
    // 0x116e668: LoadField: r2 = r1->field_6b
    //     0x116e668: ldur            w2, [x1, #0x6b]
    // 0x116e66c: DecompressPointer r2
    //     0x116e66c: add             x2, x2, HEAP, lsl #32
    // 0x116e670: r3 = LoadClassIdInstr(r0)
    //     0x116e670: ldur            x3, [x0, #-1]
    //     0x116e674: ubfx            x3, x3, #0xc, #0x14
    // 0x116e678: cmp             x3, #0xb88
    // 0x116e67c: b.ne            #0x116e754
    // 0x116e680: cmp             w2, NULL
    // 0x116e684: b.eq            #0x116e7b4
    // 0x116e688: LoadField: r3 = r2->field_7
    //     0x116e688: ldur            x3, [x2, #7]
    // 0x116e68c: cmp             x3, #0
    // 0x116e690: b.gt            #0x116e6f4
    // 0x116e694: LoadField: r2 = r0->field_b
    //     0x116e694: ldur            w2, [x0, #0xb]
    // 0x116e698: DecompressPointer r2
    //     0x116e698: add             x2, x2, HEAP, lsl #32
    // 0x116e69c: stur            x2, [fp, #-0x20]
    // 0x116e6a0: LoadField: r3 = r0->field_7
    //     0x116e6a0: ldur            w3, [x0, #7]
    // 0x116e6a4: DecompressPointer r3
    //     0x116e6a4: add             x3, x3, HEAP, lsl #32
    // 0x116e6a8: stur            x3, [fp, #-0x18]
    // 0x116e6ac: LoadField: r4 = r0->field_13
    //     0x116e6ac: ldur            w4, [x0, #0x13]
    // 0x116e6b0: DecompressPointer r4
    //     0x116e6b0: add             x4, x4, HEAP, lsl #32
    // 0x116e6b4: stur            x4, [fp, #-0x10]
    // 0x116e6b8: LoadField: r5 = r0->field_f
    //     0x116e6b8: ldur            w5, [x0, #0xf]
    // 0x116e6bc: DecompressPointer r5
    //     0x116e6bc: add             x5, x5, HEAP, lsl #32
    // 0x116e6c0: stur            x5, [fp, #-8]
    // 0x116e6c4: r0 = BorderRadius()
    //     0x116e6c4: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x116e6c8: mov             x1, x0
    // 0x116e6cc: ldur            x0, [fp, #-0x20]
    // 0x116e6d0: StoreField: r1->field_7 = r0
    //     0x116e6d0: stur            w0, [x1, #7]
    // 0x116e6d4: ldur            x0, [fp, #-0x18]
    // 0x116e6d8: StoreField: r1->field_b = r0
    //     0x116e6d8: stur            w0, [x1, #0xb]
    // 0x116e6dc: ldur            x0, [fp, #-0x10]
    // 0x116e6e0: StoreField: r1->field_f = r0
    //     0x116e6e0: stur            w0, [x1, #0xf]
    // 0x116e6e4: ldur            x0, [fp, #-8]
    // 0x116e6e8: StoreField: r1->field_13 = r0
    //     0x116e6e8: stur            w0, [x1, #0x13]
    // 0x116e6ec: mov             x0, x1
    // 0x116e6f0: b               #0x116e77c
    // 0x116e6f4: LoadField: r1 = r0->field_7
    //     0x116e6f4: ldur            w1, [x0, #7]
    // 0x116e6f8: DecompressPointer r1
    //     0x116e6f8: add             x1, x1, HEAP, lsl #32
    // 0x116e6fc: stur            x1, [fp, #-0x20]
    // 0x116e700: LoadField: r2 = r0->field_b
    //     0x116e700: ldur            w2, [x0, #0xb]
    // 0x116e704: DecompressPointer r2
    //     0x116e704: add             x2, x2, HEAP, lsl #32
    // 0x116e708: stur            x2, [fp, #-0x18]
    // 0x116e70c: LoadField: r3 = r0->field_f
    //     0x116e70c: ldur            w3, [x0, #0xf]
    // 0x116e710: DecompressPointer r3
    //     0x116e710: add             x3, x3, HEAP, lsl #32
    // 0x116e714: stur            x3, [fp, #-0x10]
    // 0x116e718: LoadField: r4 = r0->field_13
    //     0x116e718: ldur            w4, [x0, #0x13]
    // 0x116e71c: DecompressPointer r4
    //     0x116e71c: add             x4, x4, HEAP, lsl #32
    // 0x116e720: stur            x4, [fp, #-8]
    // 0x116e724: r0 = BorderRadius()
    //     0x116e724: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x116e728: mov             x1, x0
    // 0x116e72c: ldur            x0, [fp, #-0x20]
    // 0x116e730: StoreField: r1->field_7 = r0
    //     0x116e730: stur            w0, [x1, #7]
    // 0x116e734: ldur            x0, [fp, #-0x18]
    // 0x116e738: StoreField: r1->field_b = r0
    //     0x116e738: stur            w0, [x1, #0xb]
    // 0x116e73c: ldur            x0, [fp, #-0x10]
    // 0x116e740: StoreField: r1->field_f = r0
    //     0x116e740: stur            w0, [x1, #0xf]
    // 0x116e744: ldur            x0, [fp, #-8]
    // 0x116e748: StoreField: r1->field_13 = r0
    //     0x116e748: stur            w0, [x1, #0x13]
    // 0x116e74c: mov             x0, x1
    // 0x116e750: b               #0x116e77c
    // 0x116e754: cmp             x3, #0xb89
    // 0x116e758: b.eq            #0x116e77c
    // 0x116e75c: r1 = LoadClassIdInstr(r0)
    //     0x116e75c: ldur            x1, [x0, #-1]
    //     0x116e760: ubfx            x1, x1, #0xc, #0x14
    // 0x116e764: mov             x16, x0
    // 0x116e768: mov             x0, x1
    // 0x116e76c: mov             x1, x16
    // 0x116e770: r0 = GDT[cid_x0 + -0x1000]()
    //     0x116e770: sub             lr, x0, #1, lsl #12
    //     0x116e774: ldr             lr, [x21, lr, lsl #3]
    //     0x116e778: blr             lr
    // 0x116e77c: ldur            x1, [fp, #-0x28]
    // 0x116e780: stur            x0, [fp, #-8]
    // 0x116e784: r0 = size()
    //     0x116e784: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x116e788: mov             x2, x0
    // 0x116e78c: r1 = Instance_Offset
    //     0x116e78c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116e790: r0 = &()
    //     0x116e790: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x116e794: ldur            x1, [fp, #-8]
    // 0x116e798: mov             x2, x0
    // 0x116e79c: r0 = toRRect()
    //     0x116e79c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x116e7a0: LeaveFrame
    //     0x116e7a0: mov             SP, fp
    //     0x116e7a4: ldp             fp, lr, [SP], #0x10
    // 0x116e7a8: ret
    //     0x116e7a8: ret             
    // 0x116e7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116e7ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116e7b0: b               #0x116e660
    // 0x116e7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116e7b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4937, size: 0x68, field offset: 0x68
class RenderClipRect extends _RenderCustomClip<dynamic> {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf83dc, size: 0xa0
    // 0xaf83dc: EnterFrame
    //     0xaf83dc: stp             fp, lr, [SP, #-0x10]!
    //     0xaf83e0: mov             fp, SP
    // 0xaf83e4: AllocStack(0x18)
    //     0xaf83e4: sub             SP, SP, #0x18
    // 0xaf83e8: SetupParameters(RenderClipRect this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xaf83e8: mov             x0, x2
    //     0xaf83ec: stur            x2, [fp, #-0x10]
    //     0xaf83f0: mov             x2, x3
    //     0xaf83f4: stur            x3, [fp, #-0x18]
    //     0xaf83f8: mov             x3, x1
    //     0xaf83fc: stur            x1, [fp, #-8]
    // 0xaf8400: CheckStackOverflow
    //     0xaf8400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8404: cmp             SP, x16
    //     0xaf8408: b.ls            #0xaf8470
    // 0xaf840c: LoadField: r1 = r3->field_57
    //     0xaf840c: ldur            w1, [x3, #0x57]
    // 0xaf8410: DecompressPointer r1
    //     0xaf8410: add             x1, x1, HEAP, lsl #32
    // 0xaf8414: cmp             w1, NULL
    // 0xaf8418: b.eq            #0xaf8454
    // 0xaf841c: mov             x1, x3
    // 0xaf8420: r0 = _updateClip()
    //     0xaf8420: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xaf8424: ldur            x0, [fp, #-8]
    // 0xaf8428: LoadField: r1 = r0->field_5b
    //     0xaf8428: ldur            w1, [x0, #0x5b]
    // 0xaf842c: DecompressPointer r1
    //     0xaf842c: add             x1, x1, HEAP, lsl #32
    // 0xaf8430: cmp             w1, NULL
    // 0xaf8434: b.eq            #0xaf8478
    // 0xaf8438: ldur            x2, [fp, #-0x18]
    // 0xaf843c: r0 = contains()
    //     0xaf843c: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xaf8440: tbz             w0, #4, #0xaf8454
    // 0xaf8444: r0 = false
    //     0xaf8444: add             x0, NULL, #0x30  ; false
    // 0xaf8448: LeaveFrame
    //     0xaf8448: mov             SP, fp
    //     0xaf844c: ldp             fp, lr, [SP], #0x10
    // 0xaf8450: ret
    //     0xaf8450: ret             
    // 0xaf8454: ldur            x1, [fp, #-8]
    // 0xaf8458: ldur            x2, [fp, #-0x10]
    // 0xaf845c: ldur            x3, [fp, #-0x18]
    // 0xaf8460: r0 = hitTest()
    //     0xaf8460: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf8464: LeaveFrame
    //     0xaf8464: mov             SP, fp
    //     0xaf8468: ldp             fp, lr, [SP], #0x10
    // 0xaf846c: ret
    //     0xaf846c: ret             
    // 0xaf8470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8474: b               #0xaf840c
    // 0xaf8478: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf8478: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc19000, size: 0x194
    // 0xc19000: EnterFrame
    //     0xc19000: stp             fp, lr, [SP, #-0x10]!
    //     0xc19004: mov             fp, SP
    // 0xc19008: AllocStack(0x50)
    //     0xc19008: sub             SP, SP, #0x50
    // 0xc1900c: SetupParameters(RenderClipRect this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1900c: mov             x0, x2
    //     0xc19010: stur            x2, [fp, #-0x10]
    //     0xc19014: mov             x2, x1
    //     0xc19018: stur            x1, [fp, #-8]
    //     0xc1901c: stur            x3, [fp, #-0x18]
    // 0xc19020: CheckStackOverflow
    //     0xc19020: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19024: cmp             SP, x16
    //     0xc19028: b.ls            #0xc19180
    // 0xc1902c: LoadField: r1 = r2->field_4f
    //     0xc1902c: ldur            w1, [x2, #0x4f]
    // 0xc19030: DecompressPointer r1
    //     0xc19030: add             x1, x1, HEAP, lsl #32
    // 0xc19034: cmp             w1, NULL
    // 0xc19038: b.eq            #0xc1915c
    // 0xc1903c: LoadField: r4 = r2->field_5f
    //     0xc1903c: ldur            w4, [x2, #0x5f]
    // 0xc19040: DecompressPointer r4
    //     0xc19040: add             x4, x4, HEAP, lsl #32
    // 0xc19044: r16 = Instance_Clip
    //     0xc19044: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc19048: ldr             x16, [x16, #0x840]
    // 0xc1904c: cmp             w4, w16
    // 0xc19050: b.eq            #0xc19130
    // 0xc19054: mov             x1, x2
    // 0xc19058: r0 = _updateClip()
    //     0xc19058: bl              #0xaf847c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0xc1905c: ldur            x3, [fp, #-8]
    // 0xc19060: LoadField: r4 = r3->field_37
    //     0xc19060: ldur            w4, [x3, #0x37]
    // 0xc19064: DecompressPointer r4
    //     0xc19064: add             x4, x4, HEAP, lsl #32
    // 0xc19068: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1906c: cmp             w4, w16
    // 0xc19070: b.eq            #0xc19188
    // 0xc19074: stur            x4, [fp, #-0x40]
    // 0xc19078: LoadField: r5 = r3->field_5b
    //     0xc19078: ldur            w5, [x3, #0x5b]
    // 0xc1907c: DecompressPointer r5
    //     0xc1907c: add             x5, x5, HEAP, lsl #32
    // 0xc19080: stur            x5, [fp, #-0x38]
    // 0xc19084: cmp             w5, NULL
    // 0xc19088: b.eq            #0xc19190
    // 0xc1908c: LoadField: r6 = r3->field_5f
    //     0xc1908c: ldur            w6, [x3, #0x5f]
    // 0xc19090: DecompressPointer r6
    //     0xc19090: add             x6, x6, HEAP, lsl #32
    // 0xc19094: stur            x6, [fp, #-0x30]
    // 0xc19098: LoadField: r7 = r3->field_2f
    //     0xc19098: ldur            w7, [x3, #0x2f]
    // 0xc1909c: DecompressPointer r7
    //     0xc1909c: add             x7, x7, HEAP, lsl #32
    // 0xc190a0: stur            x7, [fp, #-0x28]
    // 0xc190a4: LoadField: r8 = r7->field_b
    //     0xc190a4: ldur            w8, [x7, #0xb]
    // 0xc190a8: DecompressPointer r8
    //     0xc190a8: add             x8, x8, HEAP, lsl #32
    // 0xc190ac: mov             x0, x8
    // 0xc190b0: stur            x8, [fp, #-0x20]
    // 0xc190b4: r2 = Null
    //     0xc190b4: mov             x2, NULL
    // 0xc190b8: r1 = Null
    //     0xc190b8: mov             x1, NULL
    // 0xc190bc: r4 = LoadClassIdInstr(r0)
    //     0xc190bc: ldur            x4, [x0, #-1]
    //     0xc190c0: ubfx            x4, x4, #0xc, #0x14
    // 0xc190c4: r17 = 4659
    //     0xc190c4: mov             x17, #0x1233
    // 0xc190c8: cmp             x4, x17
    // 0xc190cc: b.eq            #0xc190e4
    // 0xc190d0: r8 = ClipRectLayer?
    //     0xc190d0: add             x8, PP, #0xa4, lsl #12  ; [pp+0xa4418] Type: ClipRectLayer?
    //     0xc190d4: ldr             x8, [x8, #0x418]
    // 0xc190d8: r3 = Null
    //     0xc190d8: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4420] Null
    //     0xc190dc: ldr             x3, [x3, #0x420]
    // 0xc190e0: r0 = DefaultNullableTypeTest()
    //     0xc190e0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc190e4: ldur            x2, [fp, #-8]
    // 0xc190e8: r1 = Function 'paint':.
    //     0xc190e8: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc190ec: ldr             x1, [x1, #0x4e0]
    // 0xc190f0: r0 = AllocateClosure()
    //     0xc190f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc190f4: ldur            x16, [fp, #-0x30]
    // 0xc190f8: ldur            lr, [fp, #-0x20]
    // 0xc190fc: stp             lr, x16, [SP]
    // 0xc19100: ldur            x1, [fp, #-0x10]
    // 0xc19104: ldur            x2, [fp, #-0x40]
    // 0xc19108: ldur            x3, [fp, #-0x18]
    // 0xc1910c: ldur            x5, [fp, #-0x38]
    // 0xc19110: mov             x6, x0
    // 0xc19114: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc19114: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc19118: ldr             x4, [x4, #0x688]
    // 0xc1911c: r0 = pushClipRect()
    //     0xc1911c: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc19120: ldur            x1, [fp, #-0x28]
    // 0xc19124: mov             x2, x0
    // 0xc19128: r0 = layer=()
    //     0xc19128: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1912c: b               #0xc19170
    // 0xc19130: mov             x0, x2
    // 0xc19134: mov             x2, x1
    // 0xc19138: ldur            x1, [fp, #-0x10]
    // 0xc1913c: ldur            x3, [fp, #-0x18]
    // 0xc19140: r0 = paintChild()
    //     0xc19140: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc19144: ldur            x0, [fp, #-8]
    // 0xc19148: LoadField: r1 = r0->field_2f
    //     0xc19148: ldur            w1, [x0, #0x2f]
    // 0xc1914c: DecompressPointer r1
    //     0xc1914c: add             x1, x1, HEAP, lsl #32
    // 0xc19150: r2 = Null
    //     0xc19150: mov             x2, NULL
    // 0xc19154: r0 = layer=()
    //     0xc19154: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc19158: b               #0xc19170
    // 0xc1915c: mov             x0, x2
    // 0xc19160: LoadField: r1 = r0->field_2f
    //     0xc19160: ldur            w1, [x0, #0x2f]
    // 0xc19164: DecompressPointer r1
    //     0xc19164: add             x1, x1, HEAP, lsl #32
    // 0xc19168: r2 = Null
    //     0xc19168: mov             x2, NULL
    // 0xc1916c: r0 = layer=()
    //     0xc1916c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc19170: r0 = Null
    //     0xc19170: mov             x0, NULL
    // 0xc19174: LeaveFrame
    //     0xc19174: mov             SP, fp
    //     0xc19178: ldp             fp, lr, [SP], #0x10
    // 0xc1917c: ret
    //     0xc1917c: ret             
    // 0xc19180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19180: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19184: b               #0xc1902c
    // 0xc19188: r9 = _needsCompositing
    //     0xc19188: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1918c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1918c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc19190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc19190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ RenderClipRect(/* No info */) {
    // ** addr: 0x11d072c, size: 0x34
    // 0x11d072c: EnterFrame
    //     0x11d072c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0730: mov             fp, SP
    // 0x11d0734: CheckStackOverflow
    //     0x11d0734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0738: cmp             SP, x16
    //     0x11d073c: b.ls            #0x11d0758
    // 0x11d0740: r3 = Null
    //     0x11d0740: mov             x3, NULL
    // 0x11d0744: r0 = _RenderCustomClip()
    //     0x11d0744: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0748: r0 = Null
    //     0x11d0748: mov             x0, NULL
    // 0x11d074c: LeaveFrame
    //     0x11d074c: mov             SP, fp
    //     0x11d0750: ldp             fp, lr, [SP], #0x10
    // 0x11d0754: ret
    //     0x11d0754: ret             
    // 0x11d0758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d075c: b               #0x11d0740
  }
}

// class id: 4938, size: 0x64, field offset: 0x54
class RenderBackdropFilter extends RenderProxyBox {

  _ paint(/* No info */) {
    // ** addr: 0xc18a74, size: 0x32c
    // 0xc18a74: EnterFrame
    //     0xc18a74: stp             fp, lr, [SP, #-0x10]!
    //     0xc18a78: mov             fp, SP
    // 0xc18a7c: AllocStack(0x30)
    //     0xc18a7c: sub             SP, SP, #0x30
    // 0xc18a80: SetupParameters(RenderBackdropFilter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0xc18a80: mov             x0, x3
    //     0xc18a84: stur            x3, [fp, #-0x20]
    //     0xc18a88: mov             x3, x1
    //     0xc18a8c: stur            x1, [fp, #-0x10]
    //     0xc18a90: stur            x2, [fp, #-0x18]
    // 0xc18a94: CheckStackOverflow
    //     0xc18a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18a98: cmp             SP, x16
    //     0xc18a9c: b.ls            #0xc18d88
    // 0xc18aa0: LoadField: r4 = r3->field_57
    //     0xc18aa0: ldur            w4, [x3, #0x57]
    // 0xc18aa4: DecompressPointer r4
    //     0xc18aa4: add             x4, x4, HEAP, lsl #32
    // 0xc18aa8: mov             x1, x3
    // 0xc18aac: stur            x4, [fp, #-8]
    // 0xc18ab0: r0 = size()
    //     0xc18ab0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc18ab4: ldur            x1, [fp, #-0x20]
    // 0xc18ab8: mov             x2, x0
    // 0xc18abc: r0 = &()
    //     0xc18abc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc18ac0: ldur            x0, [fp, #-8]
    // 0xc18ac4: r1 = LoadClassIdInstr(r0)
    //     0xc18ac4: ldur            x1, [x0, #-1]
    //     0xc18ac8: ubfx            x1, x1, #0xc, #0x14
    // 0xc18acc: cmp             x1, #0xb37
    // 0xc18ad0: b.ne            #0xc18b34
    // 0xc18ad4: LoadField: r1 = r0->field_7
    //     0xc18ad4: ldur            w1, [x0, #7]
    // 0xc18ad8: DecompressPointer r1
    //     0xc18ad8: add             x1, x1, HEAP, lsl #32
    // 0xc18adc: stur            x1, [fp, #-0x28]
    // 0xc18ae0: r0 = ImageFilterContext()
    //     0xc18ae0: bl              #0xc18ff4  ; AllocateImageFilterContextStub -> ImageFilterContext (size=0x8)
    // 0xc18ae4: ldur            x1, [fp, #-0x28]
    // 0xc18ae8: mov             x2, x0
    // 0xc18aec: r0 = resolve()
    //     0xc18aec: bl              #0x13082b8  ; [package:flutter/src/rendering/image_filter_config.dart] _BlurImageFilterConfig::resolve
    // 0xc18af0: mov             x1, x0
    // 0xc18af4: ldur            x0, [fp, #-8]
    // 0xc18af8: stur            x1, [fp, #-0x30]
    // 0xc18afc: LoadField: r2 = r0->field_b
    //     0xc18afc: ldur            w2, [x0, #0xb]
    // 0xc18b00: DecompressPointer r2
    //     0xc18b00: add             x2, x2, HEAP, lsl #32
    // 0xc18b04: LoadField: r0 = r2->field_7
    //     0xc18b04: ldur            w0, [x2, #7]
    // 0xc18b08: DecompressPointer r0
    //     0xc18b08: add             x0, x0, HEAP, lsl #32
    // 0xc18b0c: stur            x0, [fp, #-0x28]
    // 0xc18b10: r0 = _ComposeImageFilter()
    //     0xc18b10: bl              #0xc18fe8  ; Allocate_ComposeImageFilterStub -> _ComposeImageFilter (size=0x14)
    // 0xc18b14: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xc18b18: StoreField: r0->field_f = r2
    //     0xc18b18: stur            w2, [x0, #0xf]
    // 0xc18b1c: ldur            x1, [fp, #-0x28]
    // 0xc18b20: StoreField: r0->field_7 = r1
    //     0xc18b20: stur            w1, [x0, #7]
    // 0xc18b24: ldur            x1, [fp, #-0x30]
    // 0xc18b28: StoreField: r0->field_b = r1
    //     0xc18b28: stur            w1, [x0, #0xb]
    // 0xc18b2c: mov             x4, x0
    // 0xc18b30: b               #0xc18b7c
    // 0xc18b34: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xc18b38: cmp             x1, #0xb38
    // 0xc18b3c: b.ne            #0xc18b70
    // 0xc18b40: r0 = _GaussianBlurImageFilter()
    //     0xc18b40: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xc18b44: mov             x1, x0
    // 0xc18b48: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xc18b4c: StoreField: r1->field_1f = r0
    //     0xc18b4c: stur            w0, [x1, #0x1f]
    // 0xc18b50: d0 = 30.000000
    //     0xc18b50: fmov            d0, #30.00000000
    // 0xc18b54: StoreField: r1->field_7 = d0
    //     0xc18b54: stur            d0, [x1, #7]
    // 0xc18b58: StoreField: r1->field_f = d0
    //     0xc18b58: stur            d0, [x1, #0xf]
    // 0xc18b5c: r0 = Instance_TileMode
    //     0xc18b5c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0xc18b60: ldr             x0, [x0, #0x900]
    // 0xc18b64: ArrayStore: r1[0] = r0  ; List_4
    //     0xc18b64: stur            w0, [x1, #0x17]
    // 0xc18b68: mov             x4, x1
    // 0xc18b6c: b               #0xc18b7c
    // 0xc18b70: LoadField: r1 = r0->field_7
    //     0xc18b70: ldur            w1, [x0, #7]
    // 0xc18b74: DecompressPointer r1
    //     0xc18b74: add             x1, x1, HEAP, lsl #32
    // 0xc18b78: mov             x4, x1
    // 0xc18b7c: ldur            x3, [fp, #-0x10]
    // 0xc18b80: stur            x4, [fp, #-0x30]
    // 0xc18b84: LoadField: r0 = r3->field_4f
    //     0xc18b84: ldur            w0, [x3, #0x4f]
    // 0xc18b88: DecompressPointer r0
    //     0xc18b88: add             x0, x0, HEAP, lsl #32
    // 0xc18b8c: cmp             w0, NULL
    // 0xc18b90: b.eq            #0xc18d64
    // 0xc18b94: LoadField: r5 = r3->field_2f
    //     0xc18b94: ldur            w5, [x3, #0x2f]
    // 0xc18b98: DecompressPointer r5
    //     0xc18b98: add             x5, x5, HEAP, lsl #32
    // 0xc18b9c: stur            x5, [fp, #-0x28]
    // 0xc18ba0: LoadField: r6 = r5->field_b
    //     0xc18ba0: ldur            w6, [x5, #0xb]
    // 0xc18ba4: DecompressPointer r6
    //     0xc18ba4: add             x6, x6, HEAP, lsl #32
    // 0xc18ba8: mov             x0, x6
    // 0xc18bac: stur            x6, [fp, #-8]
    // 0xc18bb0: r2 = Null
    //     0xc18bb0: mov             x2, NULL
    // 0xc18bb4: r1 = Null
    //     0xc18bb4: mov             x1, NULL
    // 0xc18bb8: r4 = LoadClassIdInstr(r0)
    //     0xc18bb8: ldur            x4, [x0, #-1]
    //     0xc18bbc: ubfx            x4, x4, #0xc, #0x14
    // 0xc18bc0: r17 = 4653
    //     0xc18bc0: mov             x17, #0x122d
    // 0xc18bc4: cmp             x4, x17
    // 0xc18bc8: b.eq            #0xc18be0
    // 0xc18bcc: r8 = BackdropFilterLayer?
    //     0xc18bcc: add             x8, PP, #0x90, lsl #12  ; [pp+0x90c30] Type: BackdropFilterLayer?
    //     0xc18bd0: ldr             x8, [x8, #0xc30]
    // 0xc18bd4: r3 = Null
    //     0xc18bd4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c38] Null
    //     0xc18bd8: ldr             x3, [x3, #0xc38]
    // 0xc18bdc: r0 = DefaultNullableTypeTest()
    //     0xc18bdc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18be0: ldur            x0, [fp, #-8]
    // 0xc18be4: cmp             w0, NULL
    // 0xc18be8: b.ne            #0xc18c14
    // 0xc18bec: r0 = BackdropFilterLayer()
    //     0xc18bec: bl              #0xc18fdc  ; AllocateBackdropFilterLayerStub -> BackdropFilterLayer (size=0x54)
    // 0xc18bf0: r2 = Instance_BlendMode
    //     0xc18bf0: add             x2, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xc18bf4: ldr             x2, [x2, #0xeb8]
    // 0xc18bf8: stur            x0, [fp, #-8]
    // 0xc18bfc: StoreField: r0->field_4b = r2
    //     0xc18bfc: stur            w2, [x0, #0x4b]
    // 0xc18c00: mov             x1, x0
    // 0xc18c04: r0 = Layer()
    //     0xc18c04: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc18c08: ldur            x1, [fp, #-0x28]
    // 0xc18c0c: ldur            x2, [fp, #-8]
    // 0xc18c10: r0 = layer=()
    //     0xc18c10: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc18c14: ldur            x0, [fp, #-0x28]
    // 0xc18c18: ldur            x1, [fp, #-0x10]
    // 0xc18c1c: r0 = layer()
    //     0xc18c1c: bl              #0xc18f78  ; [package:flutter/src/rendering/proxy_box.dart] RenderBackdropFilter::layer
    // 0xc18c20: cmp             w0, NULL
    // 0xc18c24: b.eq            #0xc18d90
    // 0xc18c28: mov             x1, x0
    // 0xc18c2c: ldur            x2, [fp, #-0x30]
    // 0xc18c30: r0 = filter=()
    //     0xc18c30: bl              #0xc18ee4  ; [package:flutter/src/rendering/layer.dart] BackdropFilterLayer::filter=
    // 0xc18c34: ldur            x3, [fp, #-0x28]
    // 0xc18c38: LoadField: r4 = r3->field_b
    //     0xc18c38: ldur            w4, [x3, #0xb]
    // 0xc18c3c: DecompressPointer r4
    //     0xc18c3c: add             x4, x4, HEAP, lsl #32
    // 0xc18c40: mov             x0, x4
    // 0xc18c44: stur            x4, [fp, #-8]
    // 0xc18c48: r2 = Null
    //     0xc18c48: mov             x2, NULL
    // 0xc18c4c: r1 = Null
    //     0xc18c4c: mov             x1, NULL
    // 0xc18c50: r4 = LoadClassIdInstr(r0)
    //     0xc18c50: ldur            x4, [x0, #-1]
    //     0xc18c54: ubfx            x4, x4, #0xc, #0x14
    // 0xc18c58: r17 = 4653
    //     0xc18c58: mov             x17, #0x122d
    // 0xc18c5c: cmp             x4, x17
    // 0xc18c60: b.eq            #0xc18c78
    // 0xc18c64: r8 = BackdropFilterLayer?
    //     0xc18c64: add             x8, PP, #0x90, lsl #12  ; [pp+0x90c30] Type: BackdropFilterLayer?
    //     0xc18c68: ldr             x8, [x8, #0xc30]
    // 0xc18c6c: r3 = Null
    //     0xc18c6c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c48] Null
    //     0xc18c70: ldr             x3, [x3, #0xc48]
    // 0xc18c74: r0 = DefaultNullableTypeTest()
    //     0xc18c74: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18c78: ldur            x1, [fp, #-8]
    // 0xc18c7c: cmp             w1, NULL
    // 0xc18c80: b.eq            #0xc18d94
    // 0xc18c84: r2 = Instance_BlendMode
    //     0xc18c84: add             x2, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xc18c88: ldr             x2, [x2, #0xeb8]
    // 0xc18c8c: r0 = Shader._()
    //     0xc18c8c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xc18c90: ldur            x3, [fp, #-0x28]
    // 0xc18c94: LoadField: r4 = r3->field_b
    //     0xc18c94: ldur            w4, [x3, #0xb]
    // 0xc18c98: DecompressPointer r4
    //     0xc18c98: add             x4, x4, HEAP, lsl #32
    // 0xc18c9c: mov             x0, x4
    // 0xc18ca0: stur            x4, [fp, #-8]
    // 0xc18ca4: r2 = Null
    //     0xc18ca4: mov             x2, NULL
    // 0xc18ca8: r1 = Null
    //     0xc18ca8: mov             x1, NULL
    // 0xc18cac: r4 = LoadClassIdInstr(r0)
    //     0xc18cac: ldur            x4, [x0, #-1]
    //     0xc18cb0: ubfx            x4, x4, #0xc, #0x14
    // 0xc18cb4: r17 = 4653
    //     0xc18cb4: mov             x17, #0x122d
    // 0xc18cb8: cmp             x4, x17
    // 0xc18cbc: b.eq            #0xc18cd4
    // 0xc18cc0: r8 = BackdropFilterLayer?
    //     0xc18cc0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90c30] Type: BackdropFilterLayer?
    //     0xc18cc4: ldr             x8, [x8, #0xc30]
    // 0xc18cc8: r3 = Null
    //     0xc18cc8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c58] Null
    //     0xc18ccc: ldr             x3, [x3, #0xc58]
    // 0xc18cd0: r0 = DefaultNullableTypeTest()
    //     0xc18cd0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18cd4: ldur            x1, [fp, #-8]
    // 0xc18cd8: cmp             w1, NULL
    // 0xc18cdc: b.eq            #0xc18d98
    // 0xc18ce0: r2 = Null
    //     0xc18ce0: mov             x2, NULL
    // 0xc18ce4: r0 = Shader._()
    //     0xc18ce4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xc18ce8: ldur            x0, [fp, #-0x28]
    // 0xc18cec: LoadField: r3 = r0->field_b
    //     0xc18cec: ldur            w3, [x0, #0xb]
    // 0xc18cf0: DecompressPointer r3
    //     0xc18cf0: add             x3, x3, HEAP, lsl #32
    // 0xc18cf4: mov             x0, x3
    // 0xc18cf8: stur            x3, [fp, #-8]
    // 0xc18cfc: r2 = Null
    //     0xc18cfc: mov             x2, NULL
    // 0xc18d00: r1 = Null
    //     0xc18d00: mov             x1, NULL
    // 0xc18d04: r4 = LoadClassIdInstr(r0)
    //     0xc18d04: ldur            x4, [x0, #-1]
    //     0xc18d08: ubfx            x4, x4, #0xc, #0x14
    // 0xc18d0c: r17 = 4653
    //     0xc18d0c: mov             x17, #0x122d
    // 0xc18d10: cmp             x4, x17
    // 0xc18d14: b.eq            #0xc18d2c
    // 0xc18d18: r8 = BackdropFilterLayer?
    //     0xc18d18: add             x8, PP, #0x90, lsl #12  ; [pp+0x90c30] Type: BackdropFilterLayer?
    //     0xc18d1c: ldr             x8, [x8, #0xc30]
    // 0xc18d20: r3 = Null
    //     0xc18d20: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c68] Null
    //     0xc18d24: ldr             x3, [x3, #0xc68]
    // 0xc18d28: r0 = DefaultNullableTypeTest()
    //     0xc18d28: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18d2c: ldur            x0, [fp, #-8]
    // 0xc18d30: cmp             w0, NULL
    // 0xc18d34: b.eq            #0xc18d9c
    // 0xc18d38: ldur            x2, [fp, #-0x10]
    // 0xc18d3c: r1 = Function 'paint':.
    //     0xc18d3c: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc18d40: ldr             x1, [x1, #0x4e0]
    // 0xc18d44: r0 = AllocateClosure()
    //     0xc18d44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc18d48: ldur            x1, [fp, #-0x18]
    // 0xc18d4c: ldur            x2, [fp, #-8]
    // 0xc18d50: mov             x3, x0
    // 0xc18d54: ldur            x5, [fp, #-0x20]
    // 0xc18d58: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc18d58: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc18d5c: r0 = pushLayer()
    //     0xc18d5c: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc18d60: b               #0xc18d78
    // 0xc18d64: mov             x0, x3
    // 0xc18d68: LoadField: r1 = r0->field_2f
    //     0xc18d68: ldur            w1, [x0, #0x2f]
    // 0xc18d6c: DecompressPointer r1
    //     0xc18d6c: add             x1, x1, HEAP, lsl #32
    // 0xc18d70: r2 = Null
    //     0xc18d70: mov             x2, NULL
    // 0xc18d74: r0 = layer=()
    //     0xc18d74: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc18d78: r0 = Null
    //     0xc18d78: mov             x0, NULL
    // 0xc18d7c: LeaveFrame
    //     0xc18d7c: mov             SP, fp
    //     0xc18d80: ldp             fp, lr, [SP], #0x10
    // 0xc18d84: ret
    //     0xc18d84: ret             
    // 0xc18d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18d88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18d8c: b               #0xc18aa0
    // 0xc18d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18d90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc18d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18d94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc18d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18d98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc18d9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18d9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layer(/* No info */) {
    // ** addr: 0xc18f78, size: 0x64
    // 0xc18f78: EnterFrame
    //     0xc18f78: stp             fp, lr, [SP, #-0x10]!
    //     0xc18f7c: mov             fp, SP
    // 0xc18f80: AllocStack(0x8)
    //     0xc18f80: sub             SP, SP, #8
    // 0xc18f84: LoadField: r0 = r1->field_2f
    //     0xc18f84: ldur            w0, [x1, #0x2f]
    // 0xc18f88: DecompressPointer r0
    //     0xc18f88: add             x0, x0, HEAP, lsl #32
    // 0xc18f8c: LoadField: r3 = r0->field_b
    //     0xc18f8c: ldur            w3, [x0, #0xb]
    // 0xc18f90: DecompressPointer r3
    //     0xc18f90: add             x3, x3, HEAP, lsl #32
    // 0xc18f94: mov             x0, x3
    // 0xc18f98: stur            x3, [fp, #-8]
    // 0xc18f9c: r2 = Null
    //     0xc18f9c: mov             x2, NULL
    // 0xc18fa0: r1 = Null
    //     0xc18fa0: mov             x1, NULL
    // 0xc18fa4: r4 = LoadClassIdInstr(r0)
    //     0xc18fa4: ldur            x4, [x0, #-1]
    //     0xc18fa8: ubfx            x4, x4, #0xc, #0x14
    // 0xc18fac: r17 = 4653
    //     0xc18fac: mov             x17, #0x122d
    // 0xc18fb0: cmp             x4, x17
    // 0xc18fb4: b.eq            #0xc18fcc
    // 0xc18fb8: r8 = BackdropFilterLayer?
    //     0xc18fb8: add             x8, PP, #0x90, lsl #12  ; [pp+0x90c30] Type: BackdropFilterLayer?
    //     0xc18fbc: ldr             x8, [x8, #0xc30]
    // 0xc18fc0: r3 = Null
    //     0xc18fc0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c78] Null
    //     0xc18fc4: ldr             x3, [x3, #0xc78]
    // 0xc18fc8: r0 = DefaultNullableTypeTest()
    //     0xc18fc8: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18fcc: ldur            x0, [fp, #-8]
    // 0xc18fd0: LeaveFrame
    //     0xc18fd0: mov             SP, fp
    //     0xc18fd4: ldp             fp, lr, [SP], #0x10
    // 0xc18fd8: ret
    //     0xc18fd8: ret             
  }
  set _ filterConfig=(/* No info */) {
    // ** addr: 0xcf5910, size: 0x138
    // 0xcf5910: EnterFrame
    //     0xcf5910: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5914: mov             fp, SP
    // 0xcf5918: AllocStack(0x28)
    //     0xcf5918: sub             SP, SP, #0x28
    // 0xcf591c: SetupParameters(RenderBackdropFilter this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf591c: mov             x0, x2
    //     0xcf5920: stur            x1, [fp, #-0x10]
    //     0xcf5924: stur            x2, [fp, #-0x18]
    // 0xcf5928: CheckStackOverflow
    //     0xcf5928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf592c: cmp             SP, x16
    //     0xcf5930: b.ls            #0xcf5a40
    // 0xcf5934: LoadField: r2 = r1->field_57
    //     0xcf5934: ldur            w2, [x1, #0x57]
    // 0xcf5938: DecompressPointer r2
    //     0xcf5938: add             x2, x2, HEAP, lsl #32
    // 0xcf593c: stur            x2, [fp, #-8]
    // 0xcf5940: r3 = LoadClassIdInstr(r2)
    //     0xcf5940: ldur            x3, [x2, #-1]
    //     0xcf5944: ubfx            x3, x3, #0xc, #0x14
    // 0xcf5948: cmp             x3, #0xb39
    // 0xcf594c: b.ne            #0xcf59d0
    // 0xcf5950: cmp             w2, w0
    // 0xcf5954: b.eq            #0xcf59f8
    // 0xcf5958: str             x0, [SP]
    // 0xcf595c: r0 = runtimeType()
    //     0xcf595c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xcf5960: r1 = LoadClassIdInstr(r0)
    //     0xcf5960: ldur            x1, [x0, #-1]
    //     0xcf5964: ubfx            x1, x1, #0xc, #0x14
    // 0xcf5968: r16 = _DirectImageFilterConfig
    //     0xcf5968: add             x16, PP, #0x85, lsl #12  ; [pp+0x850d0] Type: _DirectImageFilterConfig
    //     0xcf596c: ldr             x16, [x16, #0xd0]
    // 0xcf5970: stp             x16, x0, [SP]
    // 0xcf5974: mov             x0, x1
    // 0xcf5978: mov             lr, x0
    // 0xcf597c: ldr             lr, [x21, lr, lsl #3]
    // 0xcf5980: blr             lr
    // 0xcf5984: tbnz            w0, #4, #0xcf5a08
    // 0xcf5988: ldur            x1, [fp, #-0x18]
    // 0xcf598c: r0 = LoadClassIdInstr(r1)
    //     0xcf598c: ldur            x0, [x1, #-1]
    //     0xcf5990: ubfx            x0, x0, #0xc, #0x14
    // 0xcf5994: cmp             x0, #0xb39
    // 0xcf5998: b.ne            #0xcf5a08
    // 0xcf599c: ldur            x0, [fp, #-8]
    // 0xcf59a0: LoadField: r2 = r1->field_7
    //     0xcf59a0: ldur            w2, [x1, #7]
    // 0xcf59a4: DecompressPointer r2
    //     0xcf59a4: add             x2, x2, HEAP, lsl #32
    // 0xcf59a8: LoadField: r3 = r0->field_7
    //     0xcf59a8: ldur            w3, [x0, #7]
    // 0xcf59ac: DecompressPointer r3
    //     0xcf59ac: add             x3, x3, HEAP, lsl #32
    // 0xcf59b0: r0 = LoadClassIdInstr(r2)
    //     0xcf59b0: ldur            x0, [x2, #-1]
    //     0xcf59b4: ubfx            x0, x0, #0xc, #0x14
    // 0xcf59b8: stp             x3, x2, [SP]
    // 0xcf59bc: mov             lr, x0
    // 0xcf59c0: ldr             lr, [x21, lr, lsl #3]
    // 0xcf59c4: blr             lr
    // 0xcf59c8: tbnz            w0, #4, #0xcf5a08
    // 0xcf59cc: b               #0xcf59f8
    // 0xcf59d0: mov             x0, x2
    // 0xcf59d4: r1 = LoadClassIdInstr(r0)
    //     0xcf59d4: ldur            x1, [x0, #-1]
    //     0xcf59d8: ubfx            x1, x1, #0xc, #0x14
    // 0xcf59dc: ldur            x16, [fp, #-0x18]
    // 0xcf59e0: stp             x16, x0, [SP]
    // 0xcf59e4: mov             x0, x1
    // 0xcf59e8: mov             lr, x0
    // 0xcf59ec: ldr             lr, [x21, lr, lsl #3]
    // 0xcf59f0: blr             lr
    // 0xcf59f4: tbnz            w0, #4, #0xcf5a08
    // 0xcf59f8: r0 = Null
    //     0xcf59f8: mov             x0, NULL
    // 0xcf59fc: LeaveFrame
    //     0xcf59fc: mov             SP, fp
    //     0xcf5a00: ldp             fp, lr, [SP], #0x10
    // 0xcf5a04: ret
    //     0xcf5a04: ret             
    // 0xcf5a08: ldur            x1, [fp, #-0x10]
    // 0xcf5a0c: ldur            x0, [fp, #-0x18]
    // 0xcf5a10: StoreField: r1->field_57 = r0
    //     0xcf5a10: stur            w0, [x1, #0x57]
    //     0xcf5a14: ldurb           w16, [x1, #-1]
    //     0xcf5a18: ldurb           w17, [x0, #-1]
    //     0xcf5a1c: and             x16, x17, x16, lsr #2
    //     0xcf5a20: tst             x16, HEAP, lsr #32
    //     0xcf5a24: b.eq            #0xcf5a2c
    //     0xcf5a28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5a2c: r0 = markNeedsPaint()
    //     0xcf5a2c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf5a30: r0 = Null
    //     0xcf5a30: mov             x0, NULL
    // 0xcf5a34: LeaveFrame
    //     0xcf5a34: mov             SP, fp
    //     0xcf5a38: ldp             fp, lr, [SP], #0x10
    // 0xcf5a3c: ret
    //     0xcf5a3c: ret             
    // 0xcf5a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5a40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5a44: b               #0xcf5934
  }
  _ RenderBackdropFilter(/* No info */) {
    // ** addr: 0x11d04c4, size: 0xa0
    // 0x11d04c4: EnterFrame
    //     0x11d04c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d04c8: mov             fp, SP
    // 0x11d04cc: AllocStack(0x8)
    //     0x11d04cc: sub             SP, SP, #8
    // 0x11d04d0: r4 = true
    //     0x11d04d0: add             x4, NULL, #0x20  ; true
    // 0x11d04d4: r3 = Instance_BlendMode
    //     0x11d04d4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0x11d04d8: ldr             x3, [x3, #0xeb8]
    // 0x11d04dc: mov             x0, x2
    // 0x11d04e0: stur            x1, [fp, #-8]
    // 0x11d04e4: CheckStackOverflow
    //     0x11d04e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d04e8: cmp             SP, x16
    //     0x11d04ec: b.ls            #0x11d055c
    // 0x11d04f0: StoreField: r1->field_57 = r0
    //     0x11d04f0: stur            w0, [x1, #0x57]
    //     0x11d04f4: ldurb           w16, [x1, #-1]
    //     0x11d04f8: ldurb           w17, [x0, #-1]
    //     0x11d04fc: and             x16, x17, x16, lsr #2
    //     0x11d0500: tst             x16, HEAP, lsr #32
    //     0x11d0504: b.eq            #0x11d050c
    //     0x11d0508: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d050c: StoreField: r1->field_53 = r4
    //     0x11d050c: stur            w4, [x1, #0x53]
    // 0x11d0510: StoreField: r1->field_5b = r3
    //     0x11d0510: stur            w3, [x1, #0x5b]
    // 0x11d0514: r0 = _LayoutCacheStorage()
    //     0x11d0514: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d0518: ldur            x2, [fp, #-8]
    // 0x11d051c: StoreField: r2->field_47 = r0
    //     0x11d051c: stur            w0, [x2, #0x47]
    //     0x11d0520: ldurb           w16, [x2, #-1]
    //     0x11d0524: ldurb           w17, [x0, #-1]
    //     0x11d0528: and             x16, x17, x16, lsr #2
    //     0x11d052c: tst             x16, HEAP, lsr #32
    //     0x11d0530: b.eq            #0x11d0538
    //     0x11d0534: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0538: mov             x1, x2
    // 0x11d053c: r0 = RenderObject()
    //     0x11d053c: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d0540: ldur            x1, [fp, #-8]
    // 0x11d0544: r2 = Null
    //     0x11d0544: mov             x2, NULL
    // 0x11d0548: r0 = child=()
    //     0x11d0548: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d054c: r0 = Null
    //     0x11d054c: mov             x0, NULL
    // 0x11d0550: LeaveFrame
    //     0x11d0550: mov             SP, fp
    //     0x11d0554: ldp             fp, lr, [SP], #0x10
    // 0x11d0558: ret
    //     0x11d0558: ret             
    // 0x11d055c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d055c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0560: b               #0x11d04f0
  }
}

// class id: 4939, size: 0x5c, field offset: 0x54
class RenderShaderMask extends RenderProxyBox {

  _ paint(/* No info */) {
    // ** addr: 0xc18550, size: 0x1f0
    // 0xc18550: EnterFrame
    //     0xc18550: stp             fp, lr, [SP, #-0x10]!
    //     0xc18554: mov             fp, SP
    // 0xc18558: AllocStack(0x38)
    //     0xc18558: sub             SP, SP, #0x38
    // 0xc1855c: SetupParameters(RenderShaderMask this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r4, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0xc1855c: mov             x5, x1
    //     0xc18560: mov             x4, x2
    //     0xc18564: stur            x1, [fp, #-0x18]
    //     0xc18568: stur            x2, [fp, #-0x20]
    //     0xc1856c: stur            x3, [fp, #-0x28]
    // 0xc18570: CheckStackOverflow
    //     0xc18570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18574: cmp             SP, x16
    //     0xc18578: b.ls            #0xc18730
    // 0xc1857c: LoadField: r0 = r5->field_4f
    //     0xc1857c: ldur            w0, [x5, #0x4f]
    // 0xc18580: DecompressPointer r0
    //     0xc18580: add             x0, x0, HEAP, lsl #32
    // 0xc18584: cmp             w0, NULL
    // 0xc18588: b.eq            #0xc1870c
    // 0xc1858c: LoadField: r6 = r5->field_2f
    //     0xc1858c: ldur            w6, [x5, #0x2f]
    // 0xc18590: DecompressPointer r6
    //     0xc18590: add             x6, x6, HEAP, lsl #32
    // 0xc18594: stur            x6, [fp, #-0x10]
    // 0xc18598: LoadField: r7 = r6->field_b
    //     0xc18598: ldur            w7, [x6, #0xb]
    // 0xc1859c: DecompressPointer r7
    //     0xc1859c: add             x7, x7, HEAP, lsl #32
    // 0xc185a0: mov             x0, x7
    // 0xc185a4: stur            x7, [fp, #-8]
    // 0xc185a8: r2 = Null
    //     0xc185a8: mov             x2, NULL
    // 0xc185ac: r1 = Null
    //     0xc185ac: mov             x1, NULL
    // 0xc185b0: r4 = LoadClassIdInstr(r0)
    //     0xc185b0: ldur            x4, [x0, #-1]
    //     0xc185b4: ubfx            x4, x4, #0xc, #0x14
    // 0xc185b8: r17 = 4654
    //     0xc185b8: mov             x17, #0x122e
    // 0xc185bc: cmp             x4, x17
    // 0xc185c0: b.eq            #0xc185d8
    // 0xc185c4: r8 = ShaderMaskLayer?
    //     0xc185c4: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a700] Type: ShaderMaskLayer?
    //     0xc185c8: ldr             x8, [x8, #0x700]
    // 0xc185cc: r3 = Null
    //     0xc185cc: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a708] Null
    //     0xc185d0: ldr             x3, [x3, #0x708]
    // 0xc185d4: r0 = DefaultNullableTypeTest()
    //     0xc185d4: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc185d8: ldur            x0, [fp, #-8]
    // 0xc185dc: cmp             w0, NULL
    // 0xc185e0: b.ne            #0xc18600
    // 0xc185e4: r0 = ShaderMaskLayer()
    //     0xc185e4: bl              #0xc18a28  ; AllocateShaderMaskLayerStub -> ShaderMaskLayer (size=0x54)
    // 0xc185e8: mov             x1, x0
    // 0xc185ec: stur            x0, [fp, #-8]
    // 0xc185f0: r0 = Layer()
    //     0xc185f0: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc185f4: ldur            x1, [fp, #-0x10]
    // 0xc185f8: ldur            x2, [fp, #-8]
    // 0xc185fc: r0 = layer=()
    //     0xc185fc: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc18600: ldur            x0, [fp, #-0x18]
    // 0xc18604: ldur            x2, [fp, #-0x10]
    // 0xc18608: mov             x1, x0
    // 0xc1860c: r0 = layer()
    //     0xc1860c: bl              #0xc189c4  ; [package:flutter/src/rendering/proxy_box.dart] RenderShaderMask::layer
    // 0xc18610: stur            x0, [fp, #-8]
    // 0xc18614: cmp             w0, NULL
    // 0xc18618: b.eq            #0xc18738
    // 0xc1861c: ldur            x1, [fp, #-0x18]
    // 0xc18620: r0 = size()
    //     0xc18620: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc18624: mov             x2, x0
    // 0xc18628: r1 = Instance_Offset
    //     0xc18628: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1862c: r0 = &()
    //     0xc1862c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc18630: ldur            x1, [fp, #-0x18]
    // 0xc18634: LoadField: r2 = r1->field_53
    //     0xc18634: ldur            w2, [x1, #0x53]
    // 0xc18638: DecompressPointer r2
    //     0xc18638: add             x2, x2, HEAP, lsl #32
    // 0xc1863c: stp             x0, x2, [SP]
    // 0xc18640: mov             x0, x2
    // 0xc18644: ClosureCall
    //     0xc18644: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc18648: ldur            x2, [x0, #0x1f]
    //     0xc1864c: blr             x2
    // 0xc18650: ldur            x1, [fp, #-8]
    // 0xc18654: mov             x2, x0
    // 0xc18658: r0 = clipPath=()
    //     0xc18658: bl              #0xc18964  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipPath=
    // 0xc1865c: ldur            x1, [fp, #-0x18]
    // 0xc18660: r0 = size()
    //     0xc18660: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc18664: ldur            x1, [fp, #-0x28]
    // 0xc18668: mov             x2, x0
    // 0xc1866c: r0 = &()
    //     0xc1866c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc18670: ldur            x1, [fp, #-8]
    // 0xc18674: mov             x2, x0
    // 0xc18678: r0 = maskRect=()
    //     0xc18678: bl              #0xc188ec  ; [package:flutter/src/rendering/layer.dart] ShaderMaskLayer::maskRect=
    // 0xc1867c: ldur            x0, [fp, #-0x18]
    // 0xc18680: LoadField: r2 = r0->field_57
    //     0xc18680: ldur            w2, [x0, #0x57]
    // 0xc18684: DecompressPointer r2
    //     0xc18684: add             x2, x2, HEAP, lsl #32
    // 0xc18688: ldur            x1, [fp, #-8]
    // 0xc1868c: r0 = blendMode=()
    //     0xc1868c: bl              #0xc1888c  ; [package:flutter/src/rendering/layer.dart] ShaderMaskLayer::blendMode=
    // 0xc18690: ldur            x0, [fp, #-0x10]
    // 0xc18694: LoadField: r3 = r0->field_b
    //     0xc18694: ldur            w3, [x0, #0xb]
    // 0xc18698: DecompressPointer r3
    //     0xc18698: add             x3, x3, HEAP, lsl #32
    // 0xc1869c: mov             x0, x3
    // 0xc186a0: stur            x3, [fp, #-8]
    // 0xc186a4: r2 = Null
    //     0xc186a4: mov             x2, NULL
    // 0xc186a8: r1 = Null
    //     0xc186a8: mov             x1, NULL
    // 0xc186ac: r4 = LoadClassIdInstr(r0)
    //     0xc186ac: ldur            x4, [x0, #-1]
    //     0xc186b0: ubfx            x4, x4, #0xc, #0x14
    // 0xc186b4: r17 = 4654
    //     0xc186b4: mov             x17, #0x122e
    // 0xc186b8: cmp             x4, x17
    // 0xc186bc: b.eq            #0xc186d4
    // 0xc186c0: r8 = ShaderMaskLayer?
    //     0xc186c0: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a700] Type: ShaderMaskLayer?
    //     0xc186c4: ldr             x8, [x8, #0x700]
    // 0xc186c8: r3 = Null
    //     0xc186c8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a718] Null
    //     0xc186cc: ldr             x3, [x3, #0x718]
    // 0xc186d0: r0 = DefaultNullableTypeTest()
    //     0xc186d0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc186d4: ldur            x0, [fp, #-8]
    // 0xc186d8: cmp             w0, NULL
    // 0xc186dc: b.eq            #0xc1873c
    // 0xc186e0: ldur            x2, [fp, #-0x18]
    // 0xc186e4: r1 = Function 'paint':.
    //     0xc186e4: add             x1, PP, #0x85, lsl #12  ; [pp+0x854e0] AnonymousClosure: (0xc18a34), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint (0xc1faf0)
    //     0xc186e8: ldr             x1, [x1, #0x4e0]
    // 0xc186ec: r0 = AllocateClosure()
    //     0xc186ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc186f0: ldur            x1, [fp, #-0x20]
    // 0xc186f4: ldur            x2, [fp, #-8]
    // 0xc186f8: mov             x3, x0
    // 0xc186fc: ldur            x5, [fp, #-0x28]
    // 0xc18700: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc18700: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc18704: r0 = pushLayer()
    //     0xc18704: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc18708: b               #0xc18720
    // 0xc1870c: mov             x0, x5
    // 0xc18710: LoadField: r1 = r0->field_2f
    //     0xc18710: ldur            w1, [x0, #0x2f]
    // 0xc18714: DecompressPointer r1
    //     0xc18714: add             x1, x1, HEAP, lsl #32
    // 0xc18718: r2 = Null
    //     0xc18718: mov             x2, NULL
    // 0xc1871c: r0 = layer=()
    //     0xc1871c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc18720: r0 = Null
    //     0xc18720: mov             x0, NULL
    // 0xc18724: LeaveFrame
    //     0xc18724: mov             SP, fp
    //     0xc18728: ldp             fp, lr, [SP], #0x10
    // 0xc1872c: ret
    //     0xc1872c: ret             
    // 0xc18730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18734: b               #0xc1857c
    // 0xc18738: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18738: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1873c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1873c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layer(/* No info */) {
    // ** addr: 0xc189c4, size: 0x64
    // 0xc189c4: EnterFrame
    //     0xc189c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc189c8: mov             fp, SP
    // 0xc189cc: AllocStack(0x8)
    //     0xc189cc: sub             SP, SP, #8
    // 0xc189d0: LoadField: r0 = r1->field_2f
    //     0xc189d0: ldur            w0, [x1, #0x2f]
    // 0xc189d4: DecompressPointer r0
    //     0xc189d4: add             x0, x0, HEAP, lsl #32
    // 0xc189d8: LoadField: r3 = r0->field_b
    //     0xc189d8: ldur            w3, [x0, #0xb]
    // 0xc189dc: DecompressPointer r3
    //     0xc189dc: add             x3, x3, HEAP, lsl #32
    // 0xc189e0: mov             x0, x3
    // 0xc189e4: stur            x3, [fp, #-8]
    // 0xc189e8: r2 = Null
    //     0xc189e8: mov             x2, NULL
    // 0xc189ec: r1 = Null
    //     0xc189ec: mov             x1, NULL
    // 0xc189f0: r4 = LoadClassIdInstr(r0)
    //     0xc189f0: ldur            x4, [x0, #-1]
    //     0xc189f4: ubfx            x4, x4, #0xc, #0x14
    // 0xc189f8: r17 = 4654
    //     0xc189f8: mov             x17, #0x122e
    // 0xc189fc: cmp             x4, x17
    // 0xc18a00: b.eq            #0xc18a18
    // 0xc18a04: r8 = ShaderMaskLayer?
    //     0xc18a04: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a700] Type: ShaderMaskLayer?
    //     0xc18a08: ldr             x8, [x8, #0x700]
    // 0xc18a0c: r3 = Null
    //     0xc18a0c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a728] Null
    //     0xc18a10: ldr             x3, [x3, #0x728]
    // 0xc18a14: r0 = DefaultNullableTypeTest()
    //     0xc18a14: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc18a18: ldur            x0, [fp, #-8]
    // 0xc18a1c: LeaveFrame
    //     0xc18a1c: mov             SP, fp
    //     0xc18a20: ldp             fp, lr, [SP], #0x10
    // 0xc18a24: ret
    //     0xc18a24: ret             
  }
  set _ blendMode=(/* No info */) {
    // ** addr: 0xcf5764, size: 0x70
    // 0xcf5764: EnterFrame
    //     0xcf5764: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5768: mov             fp, SP
    // 0xcf576c: mov             x0, x2
    // 0xcf5770: CheckStackOverflow
    //     0xcf5770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5774: cmp             SP, x16
    //     0xcf5778: b.ls            #0xcf57cc
    // 0xcf577c: LoadField: r2 = r1->field_57
    //     0xcf577c: ldur            w2, [x1, #0x57]
    // 0xcf5780: DecompressPointer r2
    //     0xcf5780: add             x2, x2, HEAP, lsl #32
    // 0xcf5784: cmp             w2, w0
    // 0xcf5788: b.ne            #0xcf579c
    // 0xcf578c: r0 = Null
    //     0xcf578c: mov             x0, NULL
    // 0xcf5790: LeaveFrame
    //     0xcf5790: mov             SP, fp
    //     0xcf5794: ldp             fp, lr, [SP], #0x10
    // 0xcf5798: ret
    //     0xcf5798: ret             
    // 0xcf579c: StoreField: r1->field_57 = r0
    //     0xcf579c: stur            w0, [x1, #0x57]
    //     0xcf57a0: ldurb           w16, [x1, #-1]
    //     0xcf57a4: ldurb           w17, [x0, #-1]
    //     0xcf57a8: and             x16, x17, x16, lsr #2
    //     0xcf57ac: tst             x16, HEAP, lsr #32
    //     0xcf57b0: b.eq            #0xcf57b8
    //     0xcf57b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf57b8: r0 = markNeedsPaint()
    //     0xcf57b8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf57bc: r0 = Null
    //     0xcf57bc: mov             x0, NULL
    // 0xcf57c0: LeaveFrame
    //     0xcf57c0: mov             SP, fp
    //     0xcf57c4: ldp             fp, lr, [SP], #0x10
    // 0xcf57c8: ret
    //     0xcf57c8: ret             
    // 0xcf57cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf57cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf57d0: b               #0xcf577c
  }
  set _ shaderCallback=(/* No info */) {
    // ** addr: 0xcf57d4, size: 0x88
    // 0xcf57d4: EnterFrame
    //     0xcf57d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf57d8: mov             fp, SP
    // 0xcf57dc: AllocStack(0x20)
    //     0xcf57dc: sub             SP, SP, #0x20
    // 0xcf57e0: SetupParameters(RenderShaderMask this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf57e0: mov             x0, x2
    //     0xcf57e4: stur            x1, [fp, #-8]
    //     0xcf57e8: stur            x2, [fp, #-0x10]
    // 0xcf57ec: CheckStackOverflow
    //     0xcf57ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf57f0: cmp             SP, x16
    //     0xcf57f4: b.ls            #0xcf5854
    // 0xcf57f8: LoadField: r2 = r1->field_53
    //     0xcf57f8: ldur            w2, [x1, #0x53]
    // 0xcf57fc: DecompressPointer r2
    //     0xcf57fc: add             x2, x2, HEAP, lsl #32
    // 0xcf5800: stp             x0, x2, [SP]
    // 0xcf5804: r0 = ==()
    //     0xcf5804: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xcf5808: tbnz            w0, #4, #0xcf581c
    // 0xcf580c: r0 = Null
    //     0xcf580c: mov             x0, NULL
    // 0xcf5810: LeaveFrame
    //     0xcf5810: mov             SP, fp
    //     0xcf5814: ldp             fp, lr, [SP], #0x10
    // 0xcf5818: ret
    //     0xcf5818: ret             
    // 0xcf581c: ldur            x1, [fp, #-8]
    // 0xcf5820: ldur            x0, [fp, #-0x10]
    // 0xcf5824: StoreField: r1->field_53 = r0
    //     0xcf5824: stur            w0, [x1, #0x53]
    //     0xcf5828: ldurb           w16, [x1, #-1]
    //     0xcf582c: ldurb           w17, [x0, #-1]
    //     0xcf5830: and             x16, x17, x16, lsr #2
    //     0xcf5834: tst             x16, HEAP, lsr #32
    //     0xcf5838: b.eq            #0xcf5840
    //     0xcf583c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5840: r0 = markNeedsPaint()
    //     0xcf5840: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf5844: r0 = Null
    //     0xcf5844: mov             x0, NULL
    // 0xcf5848: LeaveFrame
    //     0xcf5848: mov             SP, fp
    //     0xcf584c: ldp             fp, lr, [SP], #0x10
    // 0xcf5850: ret
    //     0xcf5850: ret             
    // 0xcf5854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5858: b               #0xcf57f8
  }
  _ RenderShaderMask(/* No info */) {
    // ** addr: 0x11d0374, size: 0xb8
    // 0x11d0374: EnterFrame
    //     0x11d0374: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0378: mov             fp, SP
    // 0x11d037c: AllocStack(0x8)
    //     0x11d037c: sub             SP, SP, #8
    // 0x11d0380: SetupParameters(RenderShaderMask this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x11d0380: stur            x1, [fp, #-8]
    //     0x11d0384: mov             x16, x2
    //     0x11d0388: mov             x2, x1
    //     0x11d038c: mov             x1, x16
    //     0x11d0390: mov             x0, x3
    // 0x11d0394: CheckStackOverflow
    //     0x11d0394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0398: cmp             SP, x16
    //     0x11d039c: b.ls            #0x11d0424
    // 0x11d03a0: StoreField: r2->field_53 = r0
    //     0x11d03a0: stur            w0, [x2, #0x53]
    //     0x11d03a4: ldurb           w16, [x2, #-1]
    //     0x11d03a8: ldurb           w17, [x0, #-1]
    //     0x11d03ac: and             x16, x17, x16, lsr #2
    //     0x11d03b0: tst             x16, HEAP, lsr #32
    //     0x11d03b4: b.eq            #0x11d03bc
    //     0x11d03b8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d03bc: mov             x0, x1
    // 0x11d03c0: StoreField: r2->field_57 = r0
    //     0x11d03c0: stur            w0, [x2, #0x57]
    //     0x11d03c4: ldurb           w16, [x2, #-1]
    //     0x11d03c8: ldurb           w17, [x0, #-1]
    //     0x11d03cc: and             x16, x17, x16, lsr #2
    //     0x11d03d0: tst             x16, HEAP, lsr #32
    //     0x11d03d4: b.eq            #0x11d03dc
    //     0x11d03d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d03dc: r0 = _LayoutCacheStorage()
    //     0x11d03dc: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d03e0: ldur            x2, [fp, #-8]
    // 0x11d03e4: StoreField: r2->field_47 = r0
    //     0x11d03e4: stur            w0, [x2, #0x47]
    //     0x11d03e8: ldurb           w16, [x2, #-1]
    //     0x11d03ec: ldurb           w17, [x0, #-1]
    //     0x11d03f0: and             x16, x17, x16, lsr #2
    //     0x11d03f4: tst             x16, HEAP, lsr #32
    //     0x11d03f8: b.eq            #0x11d0400
    //     0x11d03fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d0400: mov             x1, x2
    // 0x11d0404: r0 = RenderObject()
    //     0x11d0404: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d0408: ldur            x1, [fp, #-8]
    // 0x11d040c: r2 = Null
    //     0x11d040c: mov             x2, NULL
    // 0x11d0410: r0 = child=()
    //     0x11d0410: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d0414: r0 = Null
    //     0x11d0414: mov             x0, NULL
    // 0x11d0418: LeaveFrame
    //     0x11d0418: mov             SP, fp
    //     0x11d041c: ldp             fp, lr, [SP], #0x10
    // 0x11d0420: ret
    //     0x11d0420: ret             
    // 0x11d0424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0428: b               #0x11d03a0
  }
}

// class id: 4940, size: 0x68, field offset: 0x54
class RenderOpacity extends RenderProxyBox {

  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbeb968, size: 0x5c
    // 0xbeb968: EnterFrame
    //     0xbeb968: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb96c: mov             fp, SP
    // 0xbeb970: AllocStack(0x10)
    //     0xbeb970: sub             SP, SP, #0x10
    // 0xbeb974: SetupParameters(dynamic _ /* r2 => r0 */)
    //     0xbeb974: mov             x0, x2
    // 0xbeb978: CheckStackOverflow
    //     0xbeb978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb97c: cmp             SP, x16
    //     0xbeb980: b.ls            #0xbeb9bc
    // 0xbeb984: LoadField: r2 = r1->field_4f
    //     0xbeb984: ldur            w2, [x1, #0x4f]
    // 0xbeb988: DecompressPointer r2
    //     0xbeb988: add             x2, x2, HEAP, lsl #32
    // 0xbeb98c: cmp             w2, NULL
    // 0xbeb990: b.eq            #0xbeb9ac
    // 0xbeb994: LoadField: r3 = r1->field_53
    //     0xbeb994: ldur            x3, [x1, #0x53]
    // 0xbeb998: cbz             x3, #0xbeb9ac
    // 0xbeb99c: stp             x2, x0, [SP]
    // 0xbeb9a0: ClosureCall
    //     0xbeb9a0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbeb9a4: ldur            x2, [x0, #0x1f]
    //     0xbeb9a8: blr             x2
    // 0xbeb9ac: r0 = Null
    //     0xbeb9ac: mov             x0, NULL
    // 0xbeb9b0: LeaveFrame
    //     0xbeb9b0: mov             SP, fp
    //     0xbeb9b4: ldp             fp, lr, [SP], #0x10
    // 0xbeb9b8: ret
    //     0xbeb9b8: ret             
    // 0xbeb9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb9bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb9c0: b               #0xbeb984
  }
  _ updateCompositedLayer(/* No info */) {
    // ** addr: 0xbed1b8, size: 0xdc
    // 0xbed1b8: EnterFrame
    //     0xbed1b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbed1bc: mov             fp, SP
    // 0xbed1c0: AllocStack(0x18)
    //     0xbed1c0: sub             SP, SP, #0x18
    // 0xbed1c4: SetupParameters(RenderOpacity this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xbed1c4: mov             x4, x1
    //     0xbed1c8: mov             x3, x2
    //     0xbed1cc: stur            x1, [fp, #-8]
    //     0xbed1d0: stur            x2, [fp, #-0x10]
    // 0xbed1d4: CheckStackOverflow
    //     0xbed1d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbed1d8: cmp             SP, x16
    //     0xbed1dc: b.ls            #0xbed28c
    // 0xbed1e0: mov             x0, x3
    // 0xbed1e4: r2 = Null
    //     0xbed1e4: mov             x2, NULL
    // 0xbed1e8: r1 = Null
    //     0xbed1e8: mov             x1, NULL
    // 0xbed1ec: r4 = 60
    //     0xbed1ec: mov             x4, #0x3c
    // 0xbed1f0: branchIfSmi(r0, 0xbed1fc)
    //     0xbed1f0: tbz             w0, #0, #0xbed1fc
    // 0xbed1f4: r4 = LoadClassIdInstr(r0)
    //     0xbed1f4: ldur            x4, [x0, #-1]
    //     0xbed1f8: ubfx            x4, x4, #0xc, #0x14
    // 0xbed1fc: r17 = 4661
    //     0xbed1fc: mov             x17, #0x1235
    // 0xbed200: cmp             x4, x17
    // 0xbed204: b.eq            #0xbed21c
    // 0xbed208: r8 = OpacityLayer?
    //     0xbed208: add             x8, PP, #0x85, lsl #12  ; [pp+0x858d8] Type: OpacityLayer?
    //     0xbed20c: ldr             x8, [x8, #0x8d8]
    // 0xbed210: r3 = Null
    //     0xbed210: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a668] Null
    //     0xbed214: ldr             x3, [x3, #0x668]
    // 0xbed218: r0 = DefaultNullableTypeTest()
    //     0xbed218: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xbed21c: ldur            x0, [fp, #-0x10]
    // 0xbed220: cmp             w0, NULL
    // 0xbed224: b.ne            #0xbed24c
    // 0xbed228: r0 = OpacityLayer()
    //     0xbed228: bl              #0xbed1ac  ; AllocateOpacityLayerStub -> OpacityLayer (size=0x50)
    // 0xbed22c: mov             x2, x0
    // 0xbed230: r0 = Instance_Offset
    //     0xbed230: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbed234: stur            x2, [fp, #-0x18]
    // 0xbed238: StoreField: r2->field_47 = r0
    //     0xbed238: stur            w0, [x2, #0x47]
    // 0xbed23c: mov             x1, x2
    // 0xbed240: r0 = Layer()
    //     0xbed240: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xbed244: ldur            x3, [fp, #-0x18]
    // 0xbed248: b               #0xbed250
    // 0xbed24c: mov             x3, x0
    // 0xbed250: ldur            x0, [fp, #-8]
    // 0xbed254: stur            x3, [fp, #-0x10]
    // 0xbed258: LoadField: r2 = r0->field_53
    //     0xbed258: ldur            x2, [x0, #0x53]
    // 0xbed25c: r0 = BoxInt64Instr(r2)
    //     0xbed25c: sbfiz           x0, x2, #1, #0x1f
    //     0xbed260: cmp             x2, x0, asr #1
    //     0xbed264: b.eq            #0xbed270
    //     0xbed268: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbed26c: stur            x2, [x0, #7]
    // 0xbed270: mov             x1, x3
    // 0xbed274: mov             x2, x0
    // 0xbed278: r0 = alpha=()
    //     0xbed278: bl              #0xbecedc  ; [package:flutter/src/rendering/layer.dart] OpacityLayer::alpha=
    // 0xbed27c: ldur            x0, [fp, #-0x10]
    // 0xbed280: LeaveFrame
    //     0xbed280: mov             SP, fp
    //     0xbed284: ldp             fp, lr, [SP], #0x10
    // 0xbed288: ret
    //     0xbed288: ret             
    // 0xbed28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed28c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed290: b               #0xbed1e0
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0xbf2b3c, size: 0x78
    // 0xbf2b3c: EnterFrame
    //     0xbf2b3c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2b40: mov             fp, SP
    // 0xbf2b44: AllocStack(0x8)
    //     0xbf2b44: sub             SP, SP, #8
    // 0xbf2b48: SetupParameters(RenderOpacity this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xbf2b48: mov             x0, x2
    //     0xbf2b4c: mov             x4, x1
    //     0xbf2b50: mov             x3, x2
    //     0xbf2b54: stur            x1, [fp, #-8]
    // 0xbf2b58: r2 = Null
    //     0xbf2b58: mov             x2, NULL
    // 0xbf2b5c: r1 = Null
    //     0xbf2b5c: mov             x1, NULL
    // 0xbf2b60: r4 = 60
    //     0xbf2b60: mov             x4, #0x3c
    // 0xbf2b64: branchIfSmi(r0, 0xbf2b70)
    //     0xbf2b64: tbz             w0, #0, #0xbf2b70
    // 0xbf2b68: r4 = LoadClassIdInstr(r0)
    //     0xbf2b68: ldur            x4, [x0, #-1]
    //     0xbf2b6c: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2b70: r17 = -4710
    //     0xbf2b70: mov             x17, #-0x1266
    // 0xbf2b74: add             x4, x4, x17
    // 0xbf2b78: cmp             x4, #0x109
    // 0xbf2b7c: b.ls            #0xbf2b90
    // 0xbf2b80: r8 = RenderBox
    //     0xbf2b80: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2b84: r3 = Null
    //     0xbf2b84: add             x3, PP, #0xae, lsl #12  ; [pp+0xae158] Null
    //     0xbf2b88: ldr             x3, [x3, #0x158]
    // 0xbf2b8c: r0 = RenderBox()
    //     0xbf2b8c: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf2b90: ldur            x1, [fp, #-8]
    // 0xbf2b94: LoadField: r2 = r1->field_53
    //     0xbf2b94: ldur            x2, [x1, #0x53]
    // 0xbf2b98: cmp             x2, #0
    // 0xbf2b9c: r16 = true
    //     0xbf2b9c: add             x16, NULL, #0x20  ; true
    // 0xbf2ba0: r17 = false
    //     0xbf2ba0: add             x17, NULL, #0x30  ; false
    // 0xbf2ba4: csel            x0, x16, x17, gt
    // 0xbf2ba8: LeaveFrame
    //     0xbf2ba8: mov             SP, fp
    //     0xbf2bac: ldp             fp, lr, [SP], #0x10
    // 0xbf2bb0: ret
    //     0xbf2bb0: ret             
  }
  get _ alwaysNeedsCompositing(/* No info */) {
    // ** addr: 0xc05624, size: 0x34
    // 0xc05624: LoadField: r2 = r1->field_4f
    //     0xc05624: ldur            w2, [x1, #0x4f]
    // 0xc05628: DecompressPointer r2
    //     0xc05628: add             x2, x2, HEAP, lsl #32
    // 0xc0562c: cmp             w2, NULL
    // 0xc05630: b.eq            #0xc05650
    // 0xc05634: LoadField: r2 = r1->field_53
    //     0xc05634: ldur            x2, [x1, #0x53]
    // 0xc05638: cmp             x2, #0
    // 0xc0563c: r16 = true
    //     0xc0563c: add             x16, NULL, #0x20  ; true
    // 0xc05640: r17 = false
    //     0xc05640: add             x17, NULL, #0x30  ; false
    // 0xc05644: csel            x1, x16, x17, gt
    // 0xc05648: mov             x0, x1
    // 0xc0564c: b               #0xc05654
    // 0xc05650: r0 = false
    //     0xc05650: add             x0, NULL, #0x30  ; false
    // 0xc05654: ret
    //     0xc05654: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc184f8, size: 0x58
    // 0xc184f8: EnterFrame
    //     0xc184f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc184fc: mov             fp, SP
    // 0xc18500: CheckStackOverflow
    //     0xc18500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18504: cmp             SP, x16
    //     0xc18508: b.ls            #0xc18548
    // 0xc1850c: LoadField: r0 = r1->field_4f
    //     0xc1850c: ldur            w0, [x1, #0x4f]
    // 0xc18510: DecompressPointer r0
    //     0xc18510: add             x0, x0, HEAP, lsl #32
    // 0xc18514: cmp             w0, NULL
    // 0xc18518: b.eq            #0xc18524
    // 0xc1851c: LoadField: r0 = r1->field_53
    //     0xc1851c: ldur            x0, [x1, #0x53]
    // 0xc18520: cbnz            x0, #0xc18534
    // 0xc18524: r0 = Null
    //     0xc18524: mov             x0, NULL
    // 0xc18528: LeaveFrame
    //     0xc18528: mov             SP, fp
    //     0xc1852c: ldp             fp, lr, [SP], #0x10
    // 0xc18530: ret
    //     0xc18530: ret             
    // 0xc18534: r0 = paint()
    //     0xc18534: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc18538: r0 = Null
    //     0xc18538: mov             x0, NULL
    // 0xc1853c: LeaveFrame
    //     0xc1853c: mov             SP, fp
    //     0xc18540: ldp             fp, lr, [SP], #0x10
    // 0xc18544: ret
    //     0xc18544: ret             
    // 0xc18548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1854c: b               #0xc1850c
  }
  set _ opacity=(/* No info */) {
    // ** addr: 0xcf55b8, size: 0x10c
    // 0xcf55b8: EnterFrame
    //     0xcf55b8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf55bc: mov             fp, SP
    // 0xcf55c0: AllocStack(0x20)
    //     0xcf55c0: sub             SP, SP, #0x20
    // 0xcf55c4: SetupParameters(RenderOpacity this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0xcf55c4: mov             x0, x1
    //     0xcf55c8: stur            x1, [fp, #-8]
    //     0xcf55cc: stur            d0, [fp, #-0x20]
    // 0xcf55d0: CheckStackOverflow
    //     0xcf55d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf55d4: cmp             SP, x16
    //     0xcf55d8: b.ls            #0xcf56bc
    // 0xcf55dc: LoadField: d1 = r0->field_5b
    //     0xcf55dc: ldur            d1, [x0, #0x5b]
    // 0xcf55e0: fcmp            d1, d0
    // 0xcf55e4: b.ne            #0xcf55f8
    // 0xcf55e8: r0 = Null
    //     0xcf55e8: mov             x0, NULL
    // 0xcf55ec: LeaveFrame
    //     0xcf55ec: mov             SP, fp
    //     0xcf55f0: ldp             fp, lr, [SP], #0x10
    // 0xcf55f4: ret
    //     0xcf55f4: ret             
    // 0xcf55f8: mov             x1, x0
    // 0xcf55fc: r0 = alwaysNeedsCompositing()
    //     0xcf55fc: bl              #0xc05624  ; [package:flutter/src/rendering/proxy_box.dart] RenderOpacity::alwaysNeedsCompositing
    // 0xcf5600: ldur            x1, [fp, #-8]
    // 0xcf5604: stur            x0, [fp, #-0x18]
    // 0xcf5608: LoadField: r2 = r1->field_53
    //     0xcf5608: ldur            x2, [x1, #0x53]
    // 0xcf560c: cbnz            x2, #0xcf5618
    // 0xcf5610: r3 = false
    //     0xcf5610: add             x3, NULL, #0x30  ; false
    // 0xcf5614: b               #0xcf561c
    // 0xcf5618: r3 = true
    //     0xcf5618: add             x3, NULL, #0x20  ; true
    // 0xcf561c: ldur            d0, [fp, #-0x20]
    // 0xcf5620: stur            x3, [fp, #-0x10]
    // 0xcf5624: StoreField: r1->field_5b = d0
    //     0xcf5624: stur            d0, [x1, #0x5b]
    // 0xcf5628: r0 = getAlphaFromOpacity()
    //     0xcf5628: bl              #0xc05a78  ; [dart:ui] Color::getAlphaFromOpacity
    // 0xcf562c: mov             x1, x0
    // 0xcf5630: ldur            x0, [fp, #-8]
    // 0xcf5634: StoreField: r0->field_53 = r1
    //     0xcf5634: stur            x1, [x0, #0x53]
    // 0xcf5638: LoadField: r2 = r0->field_4f
    //     0xcf5638: ldur            w2, [x0, #0x4f]
    // 0xcf563c: DecompressPointer r2
    //     0xcf563c: add             x2, x2, HEAP, lsl #32
    // 0xcf5640: cmp             w2, NULL
    // 0xcf5644: b.eq            #0xcf565c
    // 0xcf5648: cmp             x1, #0
    // 0xcf564c: r16 = true
    //     0xcf564c: add             x16, NULL, #0x20  ; true
    // 0xcf5650: r17 = false
    //     0xcf5650: add             x17, NULL, #0x30  ; false
    // 0xcf5654: csel            x2, x16, x17, gt
    // 0xcf5658: b               #0xcf5660
    // 0xcf565c: r2 = false
    //     0xcf565c: add             x2, NULL, #0x30  ; false
    // 0xcf5660: ldur            x1, [fp, #-0x18]
    // 0xcf5664: cmp             w1, w2
    // 0xcf5668: b.eq            #0xcf5674
    // 0xcf566c: mov             x1, x0
    // 0xcf5670: r0 = markNeedsCompositingBitsUpdate()
    //     0xcf5670: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xcf5674: ldur            x0, [fp, #-8]
    // 0xcf5678: ldur            x2, [fp, #-0x10]
    // 0xcf567c: mov             x1, x0
    // 0xcf5680: r0 = markNeedsCompositedLayerUpdate()
    //     0xcf5680: bl              #0xc05908  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositedLayerUpdate
    // 0xcf5684: ldur            x1, [fp, #-8]
    // 0xcf5688: LoadField: r0 = r1->field_53
    //     0xcf5688: ldur            x0, [x1, #0x53]
    // 0xcf568c: cbnz            x0, #0xcf5698
    // 0xcf5690: r2 = false
    //     0xcf5690: add             x2, NULL, #0x30  ; false
    // 0xcf5694: b               #0xcf569c
    // 0xcf5698: r2 = true
    //     0xcf5698: add             x2, NULL, #0x20  ; true
    // 0xcf569c: ldur            x0, [fp, #-0x10]
    // 0xcf56a0: cmp             w0, w2
    // 0xcf56a4: b.eq            #0xcf56ac
    // 0xcf56a8: r0 = markNeedsSemanticsUpdate()
    //     0xcf56a8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf56ac: r0 = Null
    //     0xcf56ac: mov             x0, NULL
    // 0xcf56b0: LeaveFrame
    //     0xcf56b0: mov             SP, fp
    //     0xcf56b4: ldp             fp, lr, [SP], #0x10
    // 0xcf56b8: ret
    //     0xcf56b8: ret             
    // 0xcf56bc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf56bc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf56c0: b               #0xcf55dc
  }
  _ RenderOpacity(/* No info */) {
    // ** addr: 0x11d0284, size: 0x84
    // 0x11d0284: EnterFrame
    //     0x11d0284: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0288: mov             fp, SP
    // 0x11d028c: AllocStack(0x8)
    //     0x11d028c: sub             SP, SP, #8
    // 0x11d0290: r0 = false
    //     0x11d0290: add             x0, NULL, #0x30  ; false
    // 0x11d0294: stur            x1, [fp, #-8]
    // 0x11d0298: CheckStackOverflow
    //     0x11d0298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d029c: cmp             SP, x16
    //     0x11d02a0: b.ls            #0x11d0300
    // 0x11d02a4: StoreField: r1->field_5b = d0
    //     0x11d02a4: stur            d0, [x1, #0x5b]
    // 0x11d02a8: StoreField: r1->field_63 = r0
    //     0x11d02a8: stur            w0, [x1, #0x63]
    // 0x11d02ac: r0 = getAlphaFromOpacity()
    //     0x11d02ac: bl              #0xc05a78  ; [dart:ui] Color::getAlphaFromOpacity
    // 0x11d02b0: ldur            x1, [fp, #-8]
    // 0x11d02b4: StoreField: r1->field_53 = r0
    //     0x11d02b4: stur            x0, [x1, #0x53]
    // 0x11d02b8: r0 = _LayoutCacheStorage()
    //     0x11d02b8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d02bc: ldur            x2, [fp, #-8]
    // 0x11d02c0: StoreField: r2->field_47 = r0
    //     0x11d02c0: stur            w0, [x2, #0x47]
    //     0x11d02c4: ldurb           w16, [x2, #-1]
    //     0x11d02c8: ldurb           w17, [x0, #-1]
    //     0x11d02cc: and             x16, x17, x16, lsr #2
    //     0x11d02d0: tst             x16, HEAP, lsr #32
    //     0x11d02d4: b.eq            #0x11d02dc
    //     0x11d02d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d02dc: mov             x1, x2
    // 0x11d02e0: r0 = RenderObject()
    //     0x11d02e0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d02e4: ldur            x1, [fp, #-8]
    // 0x11d02e8: r2 = Null
    //     0x11d02e8: mov             x2, NULL
    // 0x11d02ec: r0 = child=()
    //     0x11d02ec: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d02f0: r0 = Null
    //     0x11d02f0: mov             x0, NULL
    // 0x11d02f4: LeaveFrame
    //     0x11d02f4: mov             SP, fp
    //     0x11d02f8: ldp             fp, lr, [SP], #0x10
    // 0x11d02fc: ret
    //     0x11d02fc: ret             
    // 0x11d0300: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d0300: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d0304: b               #0x11d02a4
  }
}

// class id: 4943, size: 0x54, field offset: 0x54
class RenderIntrinsicHeight extends RenderProxyBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1681c, size: 0x24
    // 0xb1681c: EnterFrame
    //     0xb1681c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16820: mov             fp, SP
    // 0xb16824: ldr             x2, [fp, #0x10]
    // 0xb16828: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16828: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43c8] AnonymousClosure: (0xb16840), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::computeMinIntrinsicWidth (0xb168b8)
    //     0xb1682c: ldr             x1, [x1, #0x3c8]
    // 0xb16830: r0 = AllocateClosure()
    //     0xb16830: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16834: LeaveFrame
    //     0xb16834: mov             SP, fp
    //     0xb16838: ldp             fp, lr, [SP], #0x10
    // 0xb1683c: ret
    //     0xb1683c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16840, size: 0x78
    // 0xb16840: EnterFrame
    //     0xb16840: stp             fp, lr, [SP, #-0x10]!
    //     0xb16844: mov             fp, SP
    // 0xb16848: ldr             x0, [fp, #0x18]
    // 0xb1684c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1684c: ldur            w1, [x0, #0x17]
    // 0xb16850: DecompressPointer r1
    //     0xb16850: add             x1, x1, HEAP, lsl #32
    // 0xb16854: CheckStackOverflow
    //     0xb16854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16858: cmp             SP, x16
    //     0xb1685c: b.ls            #0xb168a0
    // 0xb16860: ldr             x2, [fp, #0x10]
    // 0xb16864: r0 = computeMinIntrinsicWidth()
    //     0xb16864: bl              #0xb168b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::computeMinIntrinsicWidth
    // 0xb16868: r0 = inline_Allocate_Double()
    //     0xb16868: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1686c: add             x0, x0, #0x10
    //     0xb16870: cmp             x1, x0
    //     0xb16874: b.ls            #0xb168a8
    //     0xb16878: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1687c: sub             x0, x0, #0xf
    //     0xb16880: mov             x1, #0xe19c
    //     0xb16884: movk            x1, #3, lsl #16
    //     0xb16888: stur            x1, [x0, #-1]
    // 0xb1688c: dmb             ishst
    // 0xb16890: StoreField: r0->field_7 = d0
    //     0xb16890: stur            d0, [x0, #7]
    // 0xb16894: LeaveFrame
    //     0xb16894: mov             SP, fp
    //     0xb16898: ldp             fp, lr, [SP], #0x10
    // 0xb1689c: ret
    //     0xb1689c: ret             
    // 0xb168a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb168a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb168a4: b               #0xb16860
    // 0xb168a8: SaveReg d0
    //     0xb168a8: str             q0, [SP, #-0x10]!
    // 0xb168ac: r0 = AllocateDouble()
    //     0xb168ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb168b0: RestoreReg d0
    //     0xb168b0: ldr             q0, [SP], #0x10
    // 0xb168b4: b               #0xb16890
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb168b8, size: 0x98
    // 0xb168b8: EnterFrame
    //     0xb168b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb168bc: mov             fp, SP
    // 0xb168c0: AllocStack(0x8)
    //     0xb168c0: sub             SP, SP, #8
    // 0xb168c4: SetupParameters(RenderIntrinsicHeight this /* r1 => r0, fp-0x8 */)
    //     0xb168c4: mov             x0, x1
    //     0xb168c8: stur            x1, [fp, #-8]
    // 0xb168cc: CheckStackOverflow
    //     0xb168cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb168d0: cmp             SP, x16
    //     0xb168d4: b.ls            #0xb16944
    // 0xb168d8: LoadField: r1 = r0->field_4f
    //     0xb168d8: ldur            w1, [x0, #0x4f]
    // 0xb168dc: DecompressPointer r1
    //     0xb168dc: add             x1, x1, HEAP, lsl #32
    // 0xb168e0: cmp             w1, NULL
    // 0xb168e4: b.ne            #0xb168f8
    // 0xb168e8: d0 = 0.000000
    //     0xb168e8: eor             v0.16b, v0.16b, v0.16b
    // 0xb168ec: LeaveFrame
    //     0xb168ec: mov             SP, fp
    //     0xb168f0: ldp             fp, lr, [SP], #0x10
    // 0xb168f4: ret
    //     0xb168f4: ret             
    // 0xb168f8: LoadField: d0 = r2->field_7
    //     0xb168f8: ldur            d0, [x2, #7]
    // 0xb168fc: mov             x2, v0.d[0]
    // 0xb16900: and             x2, x2, #0x7fffffffffffffff
    // 0xb16904: r17 = 9218868437227405312
    //     0xb16904: mov             x17, #0x7ff0000000000000
    // 0xb16908: cmp             x2, x17
    // 0xb1690c: b.eq            #0xb16918
    // 0xb16910: fcmp            d0, d0
    // 0xb16914: b.vc            #0xb16924
    // 0xb16918: d0 = inf
    //     0xb16918: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb1691c: r0 = getMaxIntrinsicHeight()
    //     0xb1691c: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb16920: ldur            x0, [fp, #-8]
    // 0xb16924: LoadField: r1 = r0->field_4f
    //     0xb16924: ldur            w1, [x0, #0x4f]
    // 0xb16928: DecompressPointer r1
    //     0xb16928: add             x1, x1, HEAP, lsl #32
    // 0xb1692c: cmp             w1, NULL
    // 0xb16930: b.eq            #0xb1694c
    // 0xb16934: r0 = getMinIntrinsicWidth()
    //     0xb16934: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb16938: LeaveFrame
    //     0xb16938: mov             SP, fp
    //     0xb1693c: ldp             fp, lr, [SP], #0x10
    // 0xb16940: ret
    //     0xb16940: ret             
    // 0xb16944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16944: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16948: b               #0xb168d8
    // 0xb1694c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb1694c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2509c, size: 0x7c
    // 0xb2509c: EnterFrame
    //     0xb2509c: stp             fp, lr, [SP, #-0x10]!
    //     0xb250a0: mov             fp, SP
    // 0xb250a4: ldr             x0, [fp, #0x18]
    // 0xb250a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb250a8: ldur            w1, [x0, #0x17]
    // 0xb250ac: DecompressPointer r1
    //     0xb250ac: add             x1, x1, HEAP, lsl #32
    // 0xb250b0: CheckStackOverflow
    //     0xb250b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb250b4: cmp             SP, x16
    //     0xb250b8: b.ls            #0xb25100
    // 0xb250bc: ldr             x0, [fp, #0x10]
    // 0xb250c0: LoadField: d0 = r0->field_7
    //     0xb250c0: ldur            d0, [x0, #7]
    // 0xb250c4: r0 = getMaxIntrinsicHeight()
    //     0xb250c4: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb250c8: r0 = inline_Allocate_Double()
    //     0xb250c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb250cc: add             x0, x0, #0x10
    //     0xb250d0: cmp             x1, x0
    //     0xb250d4: b.ls            #0xb25108
    //     0xb250d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb250dc: sub             x0, x0, #0xf
    //     0xb250e0: mov             x1, #0xe19c
    //     0xb250e4: movk            x1, #3, lsl #16
    //     0xb250e8: stur            x1, [x0, #-1]
    // 0xb250ec: dmb             ishst
    // 0xb250f0: StoreField: r0->field_7 = d0
    //     0xb250f0: stur            d0, [x0, #7]
    // 0xb250f4: LeaveFrame
    //     0xb250f4: mov             SP, fp
    //     0xb250f8: ldp             fp, lr, [SP], #0x10
    // 0xb250fc: ret
    //     0xb250fc: ret             
    // 0xb25100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25104: b               #0xb250bc
    // 0xb25108: SaveReg d0
    //     0xb25108: str             q0, [SP, #-0x10]!
    // 0xb2510c: r0 = AllocateDouble()
    //     0xb2510c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb25110: RestoreReg d0
    //     0xb25110: ldr             q0, [SP], #0x10
    // 0xb25114: b               #0xb250f0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2cd94, size: 0x98
    // 0xb2cd94: EnterFrame
    //     0xb2cd94: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cd98: mov             fp, SP
    // 0xb2cd9c: AllocStack(0x8)
    //     0xb2cd9c: sub             SP, SP, #8
    // 0xb2cda0: SetupParameters(RenderIntrinsicHeight this /* r1 => r0, fp-0x8 */)
    //     0xb2cda0: mov             x0, x1
    //     0xb2cda4: stur            x1, [fp, #-8]
    // 0xb2cda8: CheckStackOverflow
    //     0xb2cda8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cdac: cmp             SP, x16
    //     0xb2cdb0: b.ls            #0xb2ce20
    // 0xb2cdb4: LoadField: r1 = r0->field_4f
    //     0xb2cdb4: ldur            w1, [x0, #0x4f]
    // 0xb2cdb8: DecompressPointer r1
    //     0xb2cdb8: add             x1, x1, HEAP, lsl #32
    // 0xb2cdbc: cmp             w1, NULL
    // 0xb2cdc0: b.ne            #0xb2cdd4
    // 0xb2cdc4: d0 = 0.000000
    //     0xb2cdc4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2cdc8: LeaveFrame
    //     0xb2cdc8: mov             SP, fp
    //     0xb2cdcc: ldp             fp, lr, [SP], #0x10
    // 0xb2cdd0: ret
    //     0xb2cdd0: ret             
    // 0xb2cdd4: LoadField: d0 = r2->field_7
    //     0xb2cdd4: ldur            d0, [x2, #7]
    // 0xb2cdd8: mov             x2, v0.d[0]
    // 0xb2cddc: and             x2, x2, #0x7fffffffffffffff
    // 0xb2cde0: r17 = 9218868437227405312
    //     0xb2cde0: mov             x17, #0x7ff0000000000000
    // 0xb2cde4: cmp             x2, x17
    // 0xb2cde8: b.eq            #0xb2cdf4
    // 0xb2cdec: fcmp            d0, d0
    // 0xb2cdf0: b.vc            #0xb2ce00
    // 0xb2cdf4: d0 = inf
    //     0xb2cdf4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2cdf8: r0 = getMaxIntrinsicHeight()
    //     0xb2cdf8: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2cdfc: ldur            x0, [fp, #-8]
    // 0xb2ce00: LoadField: r1 = r0->field_4f
    //     0xb2ce00: ldur            w1, [x0, #0x4f]
    // 0xb2ce04: DecompressPointer r1
    //     0xb2ce04: add             x1, x1, HEAP, lsl #32
    // 0xb2ce08: cmp             w1, NULL
    // 0xb2ce0c: b.eq            #0xb2ce28
    // 0xb2ce10: r0 = getMaxIntrinsicWidth()
    //     0xb2ce10: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2ce14: LeaveFrame
    //     0xb2ce14: mov             SP, fp
    //     0xb2ce18: ldp             fp, lr, [SP], #0x10
    // 0xb2ce1c: ret
    //     0xb2ce1c: ret             
    // 0xb2ce20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ce20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ce24: b               #0xb2cdb4
    // 0xb2ce28: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2ce28: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2ce2c, size: 0x78
    // 0xb2ce2c: EnterFrame
    //     0xb2ce2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ce30: mov             fp, SP
    // 0xb2ce34: ldr             x0, [fp, #0x18]
    // 0xb2ce38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ce38: ldur            w1, [x0, #0x17]
    // 0xb2ce3c: DecompressPointer r1
    //     0xb2ce3c: add             x1, x1, HEAP, lsl #32
    // 0xb2ce40: CheckStackOverflow
    //     0xb2ce40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ce44: cmp             SP, x16
    //     0xb2ce48: b.ls            #0xb2ce8c
    // 0xb2ce4c: ldr             x2, [fp, #0x10]
    // 0xb2ce50: r0 = computeMaxIntrinsicWidth()
    //     0xb2ce50: bl              #0xb2cd94  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::computeMaxIntrinsicWidth
    // 0xb2ce54: r0 = inline_Allocate_Double()
    //     0xb2ce54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ce58: add             x0, x0, #0x10
    //     0xb2ce5c: cmp             x1, x0
    //     0xb2ce60: b.ls            #0xb2ce94
    //     0xb2ce64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ce68: sub             x0, x0, #0xf
    //     0xb2ce6c: mov             x1, #0xe19c
    //     0xb2ce70: movk            x1, #3, lsl #16
    //     0xb2ce74: stur            x1, [x0, #-1]
    // 0xb2ce78: dmb             ishst
    // 0xb2ce7c: StoreField: r0->field_7 = d0
    //     0xb2ce7c: stur            d0, [x0, #7]
    // 0xb2ce80: LeaveFrame
    //     0xb2ce80: mov             SP, fp
    //     0xb2ce84: ldp             fp, lr, [SP], #0x10
    // 0xb2ce88: ret
    //     0xb2ce88: ret             
    // 0xb2ce8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ce8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ce90: b               #0xb2ce4c
    // 0xb2ce94: SaveReg d0
    //     0xb2ce94: str             q0, [SP, #-0x10]!
    // 0xb2ce98: r0 = AllocateDouble()
    //     0xb2ce98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ce9c: RestoreReg d0
    //     0xb2ce9c: ldr             q0, [SP], #0x10
    // 0xb2cea0: b               #0xb2ce7c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4ac08, size: 0x34
    // 0xb4ac08: EnterFrame
    //     0xb4ac08: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ac0c: mov             fp, SP
    // 0xb4ac10: CheckStackOverflow
    //     0xb4ac10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ac14: cmp             SP, x16
    //     0xb4ac18: b.ls            #0xb4ac34
    // 0xb4ac1c: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4ac1c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4ac20: ldr             x3, [x3, #0x700]
    // 0xb4ac24: r0 = _computeSize()
    //     0xb4ac24: bl              #0xb4ac3c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::_computeSize
    // 0xb4ac28: LeaveFrame
    //     0xb4ac28: mov             SP, fp
    //     0xb4ac2c: ldp             fp, lr, [SP], #0x10
    // 0xb4ac30: ret
    //     0xb4ac30: ret             
    // 0xb4ac34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4ac34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4ac38: b               #0xb4ac1c
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0xb4ac3c, size: 0x8c
    // 0xb4ac3c: EnterFrame
    //     0xb4ac3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ac40: mov             fp, SP
    // 0xb4ac44: AllocStack(0x28)
    //     0xb4ac44: sub             SP, SP, #0x28
    // 0xb4ac48: SetupParameters(RenderIntrinsicHeight this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xb4ac48: mov             x16, x2
    //     0xb4ac4c: mov             x2, x1
    //     0xb4ac50: mov             x1, x16
    //     0xb4ac54: mov             x0, x3
    //     0xb4ac58: stur            x3, [fp, #-0x10]
    // 0xb4ac5c: CheckStackOverflow
    //     0xb4ac5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ac60: cmp             SP, x16
    //     0xb4ac64: b.ls            #0xb4acc0
    // 0xb4ac68: LoadField: r4 = r2->field_4f
    //     0xb4ac68: ldur            w4, [x2, #0x4f]
    // 0xb4ac6c: DecompressPointer r4
    //     0xb4ac6c: add             x4, x4, HEAP, lsl #32
    // 0xb4ac70: stur            x4, [fp, #-8]
    // 0xb4ac74: cmp             w4, NULL
    // 0xb4ac78: b.ne            #0xb4ac84
    // 0xb4ac7c: r0 = smallest()
    //     0xb4ac7c: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4ac80: b               #0xb4acb4
    // 0xb4ac84: mov             x3, x1
    // 0xb4ac88: mov             x1, x2
    // 0xb4ac8c: mov             x2, x4
    // 0xb4ac90: r0 = _childConstraints()
    //     0xb4ac90: bl              #0xb4acc8  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::_childConstraints
    // 0xb4ac94: ldur            x16, [fp, #-0x10]
    // 0xb4ac98: ldur            lr, [fp, #-8]
    // 0xb4ac9c: stp             lr, x16, [SP, #8]
    // 0xb4aca0: str             x0, [SP]
    // 0xb4aca4: ldur            x0, [fp, #-0x10]
    // 0xb4aca8: ClosureCall
    //     0xb4aca8: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb4acac: ldur            x2, [x0, #0x1f]
    //     0xb4acb0: blr             x2
    // 0xb4acb4: LeaveFrame
    //     0xb4acb4: mov             SP, fp
    //     0xb4acb8: ldp             fp, lr, [SP], #0x10
    // 0xb4acbc: ret
    //     0xb4acbc: ret             
    // 0xb4acc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4acc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4acc4: b               #0xb4ac68
  }
  _ _childConstraints(/* No info */) {
    // ** addr: 0xb4acc8, size: 0xa8
    // 0xb4acc8: EnterFrame
    //     0xb4acc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4accc: mov             fp, SP
    // 0xb4acd0: AllocStack(0x10)
    //     0xb4acd0: sub             SP, SP, #0x10
    // 0xb4acd4: SetupParameters(RenderIntrinsicHeight this /* r1 => r0 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xb4acd4: mov             x0, x1
    //     0xb4acd8: mov             x1, x2
    //     0xb4acdc: stur            x3, [fp, #-8]
    // 0xb4ace0: CheckStackOverflow
    //     0xb4ace0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ace4: cmp             SP, x16
    //     0xb4ace8: b.ls            #0xb4ad58
    // 0xb4acec: ArrayLoad: d0 = r3[0]  ; List_8
    //     0xb4acec: ldur            d0, [x3, #0x17]
    // 0xb4acf0: LoadField: d1 = r3->field_1f
    //     0xb4acf0: ldur            d1, [x3, #0x1f]
    // 0xb4acf4: fcmp            d0, d1
    // 0xb4acf8: b.lt            #0xb4ad04
    // 0xb4acfc: mov             x0, x3
    // 0xb4ad00: b               #0xb4ad4c
    // 0xb4ad04: LoadField: d0 = r3->field_f
    //     0xb4ad04: ldur            d0, [x3, #0xf]
    // 0xb4ad08: r0 = getMaxIntrinsicHeight()
    //     0xb4ad08: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb4ad0c: r0 = inline_Allocate_Double()
    //     0xb4ad0c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb4ad10: add             x0, x0, #0x10
    //     0xb4ad14: cmp             x1, x0
    //     0xb4ad18: b.ls            #0xb4ad60
    //     0xb4ad1c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4ad20: sub             x0, x0, #0xf
    //     0xb4ad24: mov             x1, #0xe19c
    //     0xb4ad28: movk            x1, #3, lsl #16
    //     0xb4ad2c: stur            x1, [x0, #-1]
    // 0xb4ad30: dmb             ishst
    // 0xb4ad34: StoreField: r0->field_7 = d0
    //     0xb4ad34: stur            d0, [x0, #7]
    // 0xb4ad38: str             x0, [SP]
    // 0xb4ad3c: ldur            x1, [fp, #-8]
    // 0xb4ad40: r4 = const [0, 0x2, 0x1, 0x1, height, 0x1, null]
    //     0xb4ad40: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f1a0] List(7) [0, 0x2, 0x1, 0x1, "height", 0x1, Null]
    //     0xb4ad44: ldr             x4, [x4, #0x1a0]
    // 0xb4ad48: r0 = tighten()
    //     0xb4ad48: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xb4ad4c: LeaveFrame
    //     0xb4ad4c: mov             SP, fp
    //     0xb4ad50: ldp             fp, lr, [SP], #0x10
    // 0xb4ad54: ret
    //     0xb4ad54: ret             
    // 0xb4ad58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4ad58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4ad5c: b               #0xb4acec
    // 0xb4ad60: SaveReg d0
    //     0xb4ad60: str             q0, [SP, #-0x10]!
    // 0xb4ad64: r0 = AllocateDouble()
    //     0xb4ad64: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4ad68: RestoreReg d0
    //     0xb4ad68: ldr             q0, [SP], #0x10
    // 0xb4ad6c: b               #0xb4ad34
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb57f94, size: 0x24
    // 0xb57f94: EnterFrame
    //     0xb57f94: stp             fp, lr, [SP, #-0x10]!
    //     0xb57f98: mov             fp, SP
    // 0xb57f9c: ldr             x2, [fp, #0x10]
    // 0xb57fa0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb57fa0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43c0] AnonymousClosure: (0xb2ce2c), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::computeMaxIntrinsicWidth (0xb2cd94)
    //     0xb57fa4: ldr             x1, [x1, #0x3c0]
    // 0xb57fa8: r0 = AllocateClosure()
    //     0xb57fa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57fac: LeaveFrame
    //     0xb57fac: mov             SP, fp
    //     0xb57fb0: ldp             fp, lr, [SP], #0x10
    // 0xb57fb4: ret
    //     0xb57fb4: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f8ac, size: 0xb4
    // 0xb5f8ac: EnterFrame
    //     0xb5f8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f8b0: mov             fp, SP
    // 0xb5f8b4: AllocStack(0x20)
    //     0xb5f8b4: sub             SP, SP, #0x20
    // 0xb5f8b8: SetupParameters(RenderIntrinsicHeight this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5f8b8: mov             x5, x1
    //     0xb5f8bc: mov             x4, x2
    //     0xb5f8c0: stur            x1, [fp, #-8]
    //     0xb5f8c4: stur            x2, [fp, #-0x10]
    //     0xb5f8c8: stur            x3, [fp, #-0x18]
    // 0xb5f8cc: CheckStackOverflow
    //     0xb5f8cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f8d0: cmp             SP, x16
    //     0xb5f8d4: b.ls            #0xb5f958
    // 0xb5f8d8: mov             x0, x4
    // 0xb5f8dc: r2 = Null
    //     0xb5f8dc: mov             x2, NULL
    // 0xb5f8e0: r1 = Null
    //     0xb5f8e0: mov             x1, NULL
    // 0xb5f8e4: r4 = 60
    //     0xb5f8e4: mov             x4, #0x3c
    // 0xb5f8e8: branchIfSmi(r0, 0xb5f8f4)
    //     0xb5f8e8: tbz             w0, #0, #0xb5f8f4
    // 0xb5f8ec: r4 = LoadClassIdInstr(r0)
    //     0xb5f8ec: ldur            x4, [x0, #-1]
    //     0xb5f8f0: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f8f4: sub             x4, x4, #0xb46
    // 0xb5f8f8: cmp             x4, #1
    // 0xb5f8fc: b.ls            #0xb5f910
    // 0xb5f900: r8 = BoxConstraints
    //     0xb5f900: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5f904: r3 = Null
    //     0xb5f904: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a600] Null
    //     0xb5f908: ldr             x3, [x3, #0x600]
    // 0xb5f90c: r0 = BoxConstraints()
    //     0xb5f90c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5f910: ldur            x1, [fp, #-8]
    // 0xb5f914: LoadField: r0 = r1->field_4f
    //     0xb5f914: ldur            w0, [x1, #0x4f]
    // 0xb5f918: DecompressPointer r0
    //     0xb5f918: add             x0, x0, HEAP, lsl #32
    // 0xb5f91c: stur            x0, [fp, #-0x20]
    // 0xb5f920: cmp             w0, NULL
    // 0xb5f924: b.ne            #0xb5f930
    // 0xb5f928: r0 = Null
    //     0xb5f928: mov             x0, NULL
    // 0xb5f92c: b               #0xb5f94c
    // 0xb5f930: mov             x2, x0
    // 0xb5f934: ldur            x3, [fp, #-0x10]
    // 0xb5f938: r0 = _childConstraints()
    //     0xb5f938: bl              #0xb4acc8  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::_childConstraints
    // 0xb5f93c: ldur            x1, [fp, #-0x20]
    // 0xb5f940: mov             x2, x0
    // 0xb5f944: ldur            x3, [fp, #-0x18]
    // 0xb5f948: r0 = getDryBaseline()
    //     0xb5f948: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb5f94c: LeaveFrame
    //     0xb5f94c: mov             SP, fp
    //     0xb5f950: ldp             fp, lr, [SP], #0x10
    // 0xb5f954: ret
    //     0xb5f954: ret             
    // 0xb5f958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f95c: b               #0xb5f8d8
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb943c, size: 0xcc
    // 0xbb943c: EnterFrame
    //     0xbb943c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb9440: mov             fp, SP
    // 0xbb9444: AllocStack(0x10)
    //     0xbb9444: sub             SP, SP, #0x10
    // 0xbb9448: SetupParameters(RenderIntrinsicHeight this /* r1 => r3, fp-0x10 */)
    //     0xbb9448: mov             x3, x1
    //     0xbb944c: stur            x1, [fp, #-0x10]
    // 0xbb9450: CheckStackOverflow
    //     0xbb9450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9454: cmp             SP, x16
    //     0xbb9458: b.ls            #0xbb9500
    // 0xbb945c: LoadField: r4 = r3->field_27
    //     0xbb945c: ldur            w4, [x3, #0x27]
    // 0xbb9460: DecompressPointer r4
    //     0xbb9460: add             x4, x4, HEAP, lsl #32
    // 0xbb9464: stur            x4, [fp, #-8]
    // 0xbb9468: cmp             w4, NULL
    // 0xbb946c: b.eq            #0xbb94e4
    // 0xbb9470: mov             x0, x4
    // 0xbb9474: r2 = Null
    //     0xbb9474: mov             x2, NULL
    // 0xbb9478: r1 = Null
    //     0xbb9478: mov             x1, NULL
    // 0xbb947c: r4 = LoadClassIdInstr(r0)
    //     0xbb947c: ldur            x4, [x0, #-1]
    //     0xbb9480: ubfx            x4, x4, #0xc, #0x14
    // 0xbb9484: sub             x4, x4, #0xb46
    // 0xbb9488: cmp             x4, #1
    // 0xbb948c: b.ls            #0xbb94a0
    // 0xbb9490: r8 = BoxConstraints
    //     0xbb9490: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb9494: r3 = Null
    //     0xbb9494: add             x3, PP, #0x90, lsl #12  ; [pp+0x90bb8] Null
    //     0xbb9498: ldr             x3, [x3, #0xbb8]
    // 0xbb949c: r0 = BoxConstraints()
    //     0xbb949c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb94a0: ldur            x1, [fp, #-0x10]
    // 0xbb94a4: ldur            x2, [fp, #-8]
    // 0xbb94a8: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbb94a8: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbb94ac: ldr             x3, [x3, #0x4f8]
    // 0xbb94b0: r0 = _computeSize()
    //     0xbb94b0: bl              #0xb4ac3c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicHeight::_computeSize
    // 0xbb94b4: ldur            x1, [fp, #-0x10]
    // 0xbb94b8: StoreField: r1->field_4b = r0
    //     0xbb94b8: stur            w0, [x1, #0x4b]
    //     0xbb94bc: ldurb           w16, [x1, #-1]
    //     0xbb94c0: ldurb           w17, [x0, #-1]
    //     0xbb94c4: and             x16, x17, x16, lsr #2
    //     0xbb94c8: tst             x16, HEAP, lsr #32
    //     0xbb94cc: b.eq            #0xbb94d4
    //     0xbb94d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb94d4: r0 = Null
    //     0xbb94d4: mov             x0, NULL
    // 0xbb94d8: LeaveFrame
    //     0xbb94d8: mov             SP, fp
    //     0xbb94dc: ldp             fp, lr, [SP], #0x10
    // 0xbb94e0: ret
    //     0xbb94e0: ret             
    // 0xbb94e4: r0 = StateError()
    //     0xbb94e4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb94e8: mov             x1, x0
    // 0xbb94ec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb94ec: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb94f0: StoreField: r1->field_b = r0
    //     0xbb94f0: stur            w0, [x1, #0xb]
    // 0xbb94f4: mov             x0, x1
    // 0xbb94f8: r0 = Throw()
    //     0xbb94f8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb94fc: brk             #0
    // 0xbb9500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb9504: b               #0xbb945c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efab4, size: 0x24
    // 0x10efab4: EnterFrame
    //     0x10efab4: stp             fp, lr, [SP, #-0x10]!
    //     0x10efab8: mov             fp, SP
    // 0x10efabc: ldr             x2, [fp, #0x10]
    // 0x10efac0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efac0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43b8] AnonymousClosure: (0xb2509c), in [package:flutter/src/rendering/editable.dart] RenderEditable::computeMinIntrinsicHeight (0xb2506c)
    //     0x10efac4: ldr             x1, [x1, #0x3b8]
    // 0x10efac8: r0 = AllocateClosure()
    //     0x10efac8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efacc: LeaveFrame
    //     0x10efacc: mov             SP, fp
    //     0x10efad0: ldp             fp, lr, [SP], #0x10
    // 0x10efad4: ret
    //     0x10efad4: ret             
  }
}

// class id: 4944, size: 0x5c, field offset: 0x54
class RenderIntrinsicWidth extends RenderProxyBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb166b0, size: 0x24
    // 0xb166b0: EnterFrame
    //     0xb166b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb166b4: mov             fp, SP
    // 0xb166b8: ldr             x2, [fp, #0x10]
    // 0xb166bc: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb166bc: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4410] AnonymousClosure: (0xb166d4), of [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth
    //     0xb166c0: ldr             x1, [x1, #0x410]
    // 0xb166c4: r0 = AllocateClosure()
    //     0xb166c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb166c8: LeaveFrame
    //     0xb166c8: mov             SP, fp
    //     0xb166cc: ldp             fp, lr, [SP], #0x10
    // 0xb166d0: ret
    //     0xb166d0: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb166d4, size: 0x7c
    // 0xb166d4: EnterFrame
    //     0xb166d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb166d8: mov             fp, SP
    // 0xb166dc: ldr             x0, [fp, #0x18]
    // 0xb166e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb166e0: ldur            w1, [x0, #0x17]
    // 0xb166e4: DecompressPointer r1
    //     0xb166e4: add             x1, x1, HEAP, lsl #32
    // 0xb166e8: CheckStackOverflow
    //     0xb166e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb166ec: cmp             SP, x16
    //     0xb166f0: b.ls            #0xb16738
    // 0xb166f4: ldr             x0, [fp, #0x10]
    // 0xb166f8: LoadField: d0 = r0->field_7
    //     0xb166f8: ldur            d0, [x0, #7]
    // 0xb166fc: r0 = getMaxIntrinsicWidth()
    //     0xb166fc: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb16700: r0 = inline_Allocate_Double()
    //     0xb16700: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16704: add             x0, x0, #0x10
    //     0xb16708: cmp             x1, x0
    //     0xb1670c: b.ls            #0xb16740
    //     0xb16710: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16714: sub             x0, x0, #0xf
    //     0xb16718: mov             x1, #0xe19c
    //     0xb1671c: movk            x1, #3, lsl #16
    //     0xb16720: stur            x1, [x0, #-1]
    // 0xb16724: dmb             ishst
    // 0xb16728: StoreField: r0->field_7 = d0
    //     0xb16728: stur            d0, [x0, #7]
    // 0xb1672c: LeaveFrame
    //     0xb1672c: mov             SP, fp
    //     0xb16730: ldp             fp, lr, [SP], #0x10
    // 0xb16734: ret
    //     0xb16734: ret             
    // 0xb16738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16738: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1673c: b               #0xb166f4
    // 0xb16740: SaveReg d0
    //     0xb16740: str             q0, [SP, #-0x10]!
    // 0xb16744: r0 = AllocateDouble()
    //     0xb16744: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16748: RestoreReg d0
    //     0xb16748: ldr             q0, [SP], #0x10
    // 0xb1674c: b               #0xb16728
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb22d54, size: 0x9c
    // 0xb22d54: EnterFrame
    //     0xb22d54: stp             fp, lr, [SP, #-0x10]!
    //     0xb22d58: mov             fp, SP
    // 0xb22d5c: AllocStack(0x8)
    //     0xb22d5c: sub             SP, SP, #8
    // 0xb22d60: SetupParameters(RenderIntrinsicWidth this /* r1 => r0, fp-0x8 */)
    //     0xb22d60: mov             x0, x1
    //     0xb22d64: stur            x1, [fp, #-8]
    // 0xb22d68: CheckStackOverflow
    //     0xb22d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22d6c: cmp             SP, x16
    //     0xb22d70: b.ls            #0xb22de4
    // 0xb22d74: LoadField: r1 = r0->field_4f
    //     0xb22d74: ldur            w1, [x0, #0x4f]
    // 0xb22d78: DecompressPointer r1
    //     0xb22d78: add             x1, x1, HEAP, lsl #32
    // 0xb22d7c: cmp             w1, NULL
    // 0xb22d80: b.ne            #0xb22d94
    // 0xb22d84: d0 = 0.000000
    //     0xb22d84: eor             v0.16b, v0.16b, v0.16b
    // 0xb22d88: LeaveFrame
    //     0xb22d88: mov             SP, fp
    //     0xb22d8c: ldp             fp, lr, [SP], #0x10
    // 0xb22d90: ret
    //     0xb22d90: ret             
    // 0xb22d94: LoadField: d0 = r2->field_7
    //     0xb22d94: ldur            d0, [x2, #7]
    // 0xb22d98: mov             x1, v0.d[0]
    // 0xb22d9c: and             x1, x1, #0x7fffffffffffffff
    // 0xb22da0: r17 = 9218868437227405312
    //     0xb22da0: mov             x17, #0x7ff0000000000000
    // 0xb22da4: cmp             x1, x17
    // 0xb22da8: b.eq            #0xb22db4
    // 0xb22dac: fcmp            d0, d0
    // 0xb22db0: b.vc            #0xb22dc4
    // 0xb22db4: mov             x1, x0
    // 0xb22db8: d0 = inf
    //     0xb22db8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb22dbc: r0 = getMaxIntrinsicWidth()
    //     0xb22dbc: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb22dc0: ldur            x0, [fp, #-8]
    // 0xb22dc4: LoadField: r1 = r0->field_4f
    //     0xb22dc4: ldur            w1, [x0, #0x4f]
    // 0xb22dc8: DecompressPointer r1
    //     0xb22dc8: add             x1, x1, HEAP, lsl #32
    // 0xb22dcc: cmp             w1, NULL
    // 0xb22dd0: b.eq            #0xb22dec
    // 0xb22dd4: r0 = getMinIntrinsicHeight()
    //     0xb22dd4: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb22dd8: LeaveFrame
    //     0xb22dd8: mov             SP, fp
    //     0xb22ddc: ldp             fp, lr, [SP], #0x10
    // 0xb22de0: ret
    //     0xb22de0: ret             
    // 0xb22de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22de8: b               #0xb22d74
    // 0xb22dec: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb22dec: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb22df0, size: 0x78
    // 0xb22df0: EnterFrame
    //     0xb22df0: stp             fp, lr, [SP, #-0x10]!
    //     0xb22df4: mov             fp, SP
    // 0xb22df8: ldr             x0, [fp, #0x18]
    // 0xb22dfc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb22dfc: ldur            w1, [x0, #0x17]
    // 0xb22e00: DecompressPointer r1
    //     0xb22e00: add             x1, x1, HEAP, lsl #32
    // 0xb22e04: CheckStackOverflow
    //     0xb22e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22e08: cmp             SP, x16
    //     0xb22e0c: b.ls            #0xb22e50
    // 0xb22e10: ldr             x2, [fp, #0x10]
    // 0xb22e14: r0 = computeMinIntrinsicHeight()
    //     0xb22e14: bl              #0xb22d54  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMinIntrinsicHeight
    // 0xb22e18: r0 = inline_Allocate_Double()
    //     0xb22e18: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22e1c: add             x0, x0, #0x10
    //     0xb22e20: cmp             x1, x0
    //     0xb22e24: b.ls            #0xb22e58
    //     0xb22e28: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22e2c: sub             x0, x0, #0xf
    //     0xb22e30: mov             x1, #0xe19c
    //     0xb22e34: movk            x1, #3, lsl #16
    //     0xb22e38: stur            x1, [x0, #-1]
    // 0xb22e3c: dmb             ishst
    // 0xb22e40: StoreField: r0->field_7 = d0
    //     0xb22e40: stur            d0, [x0, #7]
    // 0xb22e44: LeaveFrame
    //     0xb22e44: mov             SP, fp
    //     0xb22e48: ldp             fp, lr, [SP], #0x10
    // 0xb22e4c: ret
    //     0xb22e4c: ret             
    // 0xb22e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22e50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22e54: b               #0xb22e10
    // 0xb22e58: SaveReg d0
    //     0xb22e58: str             q0, [SP, #-0x10]!
    // 0xb22e5c: r0 = AllocateDouble()
    //     0xb22e5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22e60: RestoreReg d0
    //     0xb22e60: ldr             q0, [SP], #0x10
    // 0xb22e64: b               #0xb22e40
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29964, size: 0x9c
    // 0xb29964: EnterFrame
    //     0xb29964: stp             fp, lr, [SP, #-0x10]!
    //     0xb29968: mov             fp, SP
    // 0xb2996c: AllocStack(0x8)
    //     0xb2996c: sub             SP, SP, #8
    // 0xb29970: SetupParameters(RenderIntrinsicWidth this /* r1 => r0, fp-0x8 */)
    //     0xb29970: mov             x0, x1
    //     0xb29974: stur            x1, [fp, #-8]
    // 0xb29978: CheckStackOverflow
    //     0xb29978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2997c: cmp             SP, x16
    //     0xb29980: b.ls            #0xb299f4
    // 0xb29984: LoadField: r1 = r0->field_4f
    //     0xb29984: ldur            w1, [x0, #0x4f]
    // 0xb29988: DecompressPointer r1
    //     0xb29988: add             x1, x1, HEAP, lsl #32
    // 0xb2998c: cmp             w1, NULL
    // 0xb29990: b.ne            #0xb299a4
    // 0xb29994: d0 = 0.000000
    //     0xb29994: eor             v0.16b, v0.16b, v0.16b
    // 0xb29998: LeaveFrame
    //     0xb29998: mov             SP, fp
    //     0xb2999c: ldp             fp, lr, [SP], #0x10
    // 0xb299a0: ret
    //     0xb299a0: ret             
    // 0xb299a4: LoadField: d0 = r2->field_7
    //     0xb299a4: ldur            d0, [x2, #7]
    // 0xb299a8: mov             x1, v0.d[0]
    // 0xb299ac: and             x1, x1, #0x7fffffffffffffff
    // 0xb299b0: r17 = 9218868437227405312
    //     0xb299b0: mov             x17, #0x7ff0000000000000
    // 0xb299b4: cmp             x1, x17
    // 0xb299b8: b.eq            #0xb299c4
    // 0xb299bc: fcmp            d0, d0
    // 0xb299c0: b.vc            #0xb299d4
    // 0xb299c4: mov             x1, x0
    // 0xb299c8: d0 = inf
    //     0xb299c8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb299cc: r0 = getMaxIntrinsicWidth()
    //     0xb299cc: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb299d0: ldur            x0, [fp, #-8]
    // 0xb299d4: LoadField: r1 = r0->field_4f
    //     0xb299d4: ldur            w1, [x0, #0x4f]
    // 0xb299d8: DecompressPointer r1
    //     0xb299d8: add             x1, x1, HEAP, lsl #32
    // 0xb299dc: cmp             w1, NULL
    // 0xb299e0: b.eq            #0xb299fc
    // 0xb299e4: r0 = getMaxIntrinsicHeight()
    //     0xb299e4: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb299e8: LeaveFrame
    //     0xb299e8: mov             SP, fp
    //     0xb299ec: ldp             fp, lr, [SP], #0x10
    // 0xb299f0: ret
    //     0xb299f0: ret             
    // 0xb299f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb299f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb299f8: b               #0xb29984
    // 0xb299fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb299fc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29a00, size: 0x78
    // 0xb29a00: EnterFrame
    //     0xb29a00: stp             fp, lr, [SP, #-0x10]!
    //     0xb29a04: mov             fp, SP
    // 0xb29a08: ldr             x0, [fp, #0x18]
    // 0xb29a0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29a0c: ldur            w1, [x0, #0x17]
    // 0xb29a10: DecompressPointer r1
    //     0xb29a10: add             x1, x1, HEAP, lsl #32
    // 0xb29a14: CheckStackOverflow
    //     0xb29a14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29a18: cmp             SP, x16
    //     0xb29a1c: b.ls            #0xb29a60
    // 0xb29a20: ldr             x2, [fp, #0x10]
    // 0xb29a24: r0 = computeMaxIntrinsicHeight()
    //     0xb29a24: bl              #0xb29964  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicHeight
    // 0xb29a28: r0 = inline_Allocate_Double()
    //     0xb29a28: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29a2c: add             x0, x0, #0x10
    //     0xb29a30: cmp             x1, x0
    //     0xb29a34: b.ls            #0xb29a68
    //     0xb29a38: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29a3c: sub             x0, x0, #0xf
    //     0xb29a40: mov             x1, #0xe19c
    //     0xb29a44: movk            x1, #3, lsl #16
    //     0xb29a48: stur            x1, [x0, #-1]
    // 0xb29a4c: dmb             ishst
    // 0xb29a50: StoreField: r0->field_7 = d0
    //     0xb29a50: stur            d0, [x0, #7]
    // 0xb29a54: LeaveFrame
    //     0xb29a54: mov             SP, fp
    //     0xb29a58: ldp             fp, lr, [SP], #0x10
    // 0xb29a5c: ret
    //     0xb29a5c: ret             
    // 0xb29a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29a60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29a64: b               #0xb29a20
    // 0xb29a68: SaveReg d0
    //     0xb29a68: str             q0, [SP, #-0x10]!
    // 0xb29a6c: r0 = AllocateDouble()
    //     0xb29a6c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29a70: RestoreReg d0
    //     0xb29a70: ldr             q0, [SP], #0x10
    // 0xb29a74: b               #0xb29a50
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2cc50, size: 0xcc
    // 0xb2cc50: EnterFrame
    //     0xb2cc50: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cc54: mov             fp, SP
    // 0xb2cc58: AllocStack(0x8)
    //     0xb2cc58: sub             SP, SP, #8
    // 0xb2cc5c: SetupParameters(RenderIntrinsicWidth this /* r1 => r0, fp-0x8 */)
    //     0xb2cc5c: mov             x0, x1
    //     0xb2cc60: stur            x1, [fp, #-8]
    // 0xb2cc64: CheckStackOverflow
    //     0xb2cc64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cc68: cmp             SP, x16
    //     0xb2cc6c: b.ls            #0xb2ccf4
    // 0xb2cc70: LoadField: r1 = r0->field_4f
    //     0xb2cc70: ldur            w1, [x0, #0x4f]
    // 0xb2cc74: DecompressPointer r1
    //     0xb2cc74: add             x1, x1, HEAP, lsl #32
    // 0xb2cc78: cmp             w1, NULL
    // 0xb2cc7c: b.ne            #0xb2cc90
    // 0xb2cc80: d0 = 0.000000
    //     0xb2cc80: eor             v0.16b, v0.16b, v0.16b
    // 0xb2cc84: LeaveFrame
    //     0xb2cc84: mov             SP, fp
    //     0xb2cc88: ldp             fp, lr, [SP], #0x10
    // 0xb2cc8c: ret
    //     0xb2cc8c: ret             
    // 0xb2cc90: LoadField: d0 = r2->field_7
    //     0xb2cc90: ldur            d0, [x2, #7]
    // 0xb2cc94: r0 = getMaxIntrinsicWidth()
    //     0xb2cc94: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2cc98: ldur            x0, [fp, #-8]
    // 0xb2cc9c: LoadField: r1 = r0->field_53
    //     0xb2cc9c: ldur            w1, [x0, #0x53]
    // 0xb2cca0: DecompressPointer r1
    //     0xb2cca0: add             x1, x1, HEAP, lsl #32
    // 0xb2cca4: cmp             w1, NULL
    // 0xb2cca8: b.eq            #0xb2cce8
    // 0xb2ccac: LoadField: d1 = r1->field_7
    //     0xb2ccac: ldur            d1, [x1, #7]
    // 0xb2ccb0: fdiv            d2, d0, d1
    // 0xb2ccb4: fcmp            d2, d2
    // 0xb2ccb8: b.vs            #0xb2ccfc
    // 0xb2ccbc: fcvtps          x0, d2
    // 0xb2ccc0: asr             x16, x0, #0x1e
    // 0xb2ccc4: cmp             x16, x0, asr #63
    // 0xb2ccc8: b.ne            #0xb2ccfc
    // 0xb2cccc: lsl             x0, x0, #1
    // 0xb2ccd0: r1 = LoadInt32Instr(r0)
    //     0xb2ccd0: sbfx            x1, x0, #1, #0x1f
    //     0xb2ccd4: tbz             w0, #0, #0xb2ccdc
    //     0xb2ccd8: ldur            x1, [x0, #7]
    // 0xb2ccdc: scvtf           d2, x1
    // 0xb2cce0: fmul            d3, d2, d1
    // 0xb2cce4: mov             v0.16b, v3.16b
    // 0xb2cce8: LeaveFrame
    //     0xb2cce8: mov             SP, fp
    //     0xb2ccec: ldp             fp, lr, [SP], #0x10
    // 0xb2ccf0: ret
    //     0xb2ccf0: ret             
    // 0xb2ccf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ccf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ccf8: b               #0xb2cc70
    // 0xb2ccfc: stp             q1, q2, [SP, #-0x20]!
    // 0xb2cd00: d0 = 0.000000
    //     0xb2cd00: fmov            d0, d2
    // 0xb2cd04: r0 = 66
    //     0xb2cd04: mov             x0, #0x42
    // 0xb2cd08: r30 = DoubleToIntegerStub
    //     0xb2cd08: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb2cd0c: LoadField: r30 = r30->field_7
    //     0xb2cd0c: ldur            lr, [lr, #7]
    // 0xb2cd10: blr             lr
    // 0xb2cd14: ldp             q1, q2, [SP], #0x20
    // 0xb2cd18: b               #0xb2ccd0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2cd1c, size: 0x78
    // 0xb2cd1c: EnterFrame
    //     0xb2cd1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cd20: mov             fp, SP
    // 0xb2cd24: ldr             x0, [fp, #0x18]
    // 0xb2cd28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2cd28: ldur            w1, [x0, #0x17]
    // 0xb2cd2c: DecompressPointer r1
    //     0xb2cd2c: add             x1, x1, HEAP, lsl #32
    // 0xb2cd30: CheckStackOverflow
    //     0xb2cd30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cd34: cmp             SP, x16
    //     0xb2cd38: b.ls            #0xb2cd7c
    // 0xb2cd3c: ldr             x2, [fp, #0x10]
    // 0xb2cd40: r0 = computeMaxIntrinsicWidth()
    //     0xb2cd40: bl              #0xb2cc50  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth
    // 0xb2cd44: r0 = inline_Allocate_Double()
    //     0xb2cd44: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2cd48: add             x0, x0, #0x10
    //     0xb2cd4c: cmp             x1, x0
    //     0xb2cd50: b.ls            #0xb2cd84
    //     0xb2cd54: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2cd58: sub             x0, x0, #0xf
    //     0xb2cd5c: mov             x1, #0xe19c
    //     0xb2cd60: movk            x1, #3, lsl #16
    //     0xb2cd64: stur            x1, [x0, #-1]
    // 0xb2cd68: dmb             ishst
    // 0xb2cd6c: StoreField: r0->field_7 = d0
    //     0xb2cd6c: stur            d0, [x0, #7]
    // 0xb2cd70: LeaveFrame
    //     0xb2cd70: mov             SP, fp
    //     0xb2cd74: ldp             fp, lr, [SP], #0x10
    // 0xb2cd78: ret
    //     0xb2cd78: ret             
    // 0xb2cd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2cd7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2cd80: b               #0xb2cd3c
    // 0xb2cd84: SaveReg d0
    //     0xb2cd84: str             q0, [SP, #-0x10]!
    // 0xb2cd88: r0 = AllocateDouble()
    //     0xb2cd88: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2cd8c: RestoreReg d0
    //     0xb2cd8c: ldr             q0, [SP], #0x10
    // 0xb2cd90: b               #0xb2cd6c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4a840, size: 0x34
    // 0xb4a840: EnterFrame
    //     0xb4a840: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a844: mov             fp, SP
    // 0xb4a848: CheckStackOverflow
    //     0xb4a848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a84c: cmp             SP, x16
    //     0xb4a850: b.ls            #0xb4a86c
    // 0xb4a854: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4a854: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4a858: ldr             x3, [x3, #0x700]
    // 0xb4a85c: r0 = _computeSize()
    //     0xb4a85c: bl              #0xb4a874  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_computeSize
    // 0xb4a860: LeaveFrame
    //     0xb4a860: mov             SP, fp
    //     0xb4a864: ldp             fp, lr, [SP], #0x10
    // 0xb4a868: ret
    //     0xb4a868: ret             
    // 0xb4a86c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a86c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a870: b               #0xb4a854
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0xb4a874, size: 0x8c
    // 0xb4a874: EnterFrame
    //     0xb4a874: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a878: mov             fp, SP
    // 0xb4a87c: AllocStack(0x28)
    //     0xb4a87c: sub             SP, SP, #0x28
    // 0xb4a880: SetupParameters(RenderIntrinsicWidth this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xb4a880: mov             x16, x2
    //     0xb4a884: mov             x2, x1
    //     0xb4a888: mov             x1, x16
    //     0xb4a88c: mov             x0, x3
    //     0xb4a890: stur            x3, [fp, #-0x10]
    // 0xb4a894: CheckStackOverflow
    //     0xb4a894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a898: cmp             SP, x16
    //     0xb4a89c: b.ls            #0xb4a8f8
    // 0xb4a8a0: LoadField: r4 = r2->field_4f
    //     0xb4a8a0: ldur            w4, [x2, #0x4f]
    // 0xb4a8a4: DecompressPointer r4
    //     0xb4a8a4: add             x4, x4, HEAP, lsl #32
    // 0xb4a8a8: stur            x4, [fp, #-8]
    // 0xb4a8ac: cmp             w4, NULL
    // 0xb4a8b0: b.ne            #0xb4a8bc
    // 0xb4a8b4: r0 = smallest()
    //     0xb4a8b4: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4a8b8: b               #0xb4a8ec
    // 0xb4a8bc: mov             x3, x1
    // 0xb4a8c0: mov             x1, x2
    // 0xb4a8c4: mov             x2, x4
    // 0xb4a8c8: r0 = _childConstraints()
    //     0xb4a8c8: bl              #0xb4a900  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_childConstraints
    // 0xb4a8cc: ldur            x16, [fp, #-0x10]
    // 0xb4a8d0: ldur            lr, [fp, #-8]
    // 0xb4a8d4: stp             lr, x16, [SP, #8]
    // 0xb4a8d8: str             x0, [SP]
    // 0xb4a8dc: ldur            x0, [fp, #-0x10]
    // 0xb4a8e0: ClosureCall
    //     0xb4a8e0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb4a8e4: ldur            x2, [x0, #0x1f]
    //     0xb4a8e8: blr             x2
    // 0xb4a8ec: LeaveFrame
    //     0xb4a8ec: mov             SP, fp
    //     0xb4a8f0: ldp             fp, lr, [SP], #0x10
    // 0xb4a8f4: ret
    //     0xb4a8f4: ret             
    // 0xb4a8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a8f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a8fc: b               #0xb4a8a0
  }
  _ _childConstraints(/* No info */) {
    // ** addr: 0xb4a900, size: 0x124
    // 0xb4a900: EnterFrame
    //     0xb4a900: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a904: mov             fp, SP
    // 0xb4a908: AllocStack(0x20)
    //     0xb4a908: sub             SP, SP, #0x20
    // 0xb4a90c: SetupParameters(RenderIntrinsicWidth this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xb4a90c: stur            x1, [fp, #-8]
    //     0xb4a910: mov             x16, x2
    //     0xb4a914: mov             x2, x1
    //     0xb4a918: mov             x1, x16
    //     0xb4a91c: mov             x0, x3
    //     0xb4a920: stur            x3, [fp, #-0x10]
    // 0xb4a924: CheckStackOverflow
    //     0xb4a924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a928: cmp             SP, x16
    //     0xb4a92c: b.ls            #0xb4a9ec
    // 0xb4a930: LoadField: d0 = r0->field_7
    //     0xb4a930: ldur            d0, [x0, #7]
    // 0xb4a934: LoadField: d1 = r0->field_f
    //     0xb4a934: ldur            d1, [x0, #0xf]
    // 0xb4a938: fcmp            d0, d1
    // 0xb4a93c: b.lt            #0xb4a948
    // 0xb4a940: r0 = Null
    //     0xb4a940: mov             x0, NULL
    // 0xb4a944: b               #0xb4a9cc
    // 0xb4a948: LoadField: d0 = r0->field_1f
    //     0xb4a948: ldur            d0, [x0, #0x1f]
    // 0xb4a94c: r0 = getMaxIntrinsicWidth()
    //     0xb4a94c: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb4a950: ldur            x0, [fp, #-8]
    // 0xb4a954: LoadField: r1 = r0->field_53
    //     0xb4a954: ldur            w1, [x0, #0x53]
    // 0xb4a958: DecompressPointer r1
    //     0xb4a958: add             x1, x1, HEAP, lsl #32
    // 0xb4a95c: cmp             w1, NULL
    // 0xb4a960: b.eq            #0xb4a9a0
    // 0xb4a964: LoadField: d1 = r1->field_7
    //     0xb4a964: ldur            d1, [x1, #7]
    // 0xb4a968: fdiv            d2, d0, d1
    // 0xb4a96c: fcmp            d2, d2
    // 0xb4a970: b.vs            #0xb4a9f4
    // 0xb4a974: fcvtps          x0, d2
    // 0xb4a978: asr             x16, x0, #0x1e
    // 0xb4a97c: cmp             x16, x0, asr #63
    // 0xb4a980: b.ne            #0xb4a9f4
    // 0xb4a984: lsl             x0, x0, #1
    // 0xb4a988: r1 = LoadInt32Instr(r0)
    //     0xb4a988: sbfx            x1, x0, #1, #0x1f
    //     0xb4a98c: tbz             w0, #0, #0xb4a994
    //     0xb4a990: ldur            x1, [x0, #7]
    // 0xb4a994: scvtf           d0, x1
    // 0xb4a998: fmul            d2, d0, d1
    // 0xb4a99c: mov             v0.16b, v2.16b
    // 0xb4a9a0: r0 = inline_Allocate_Double()
    //     0xb4a9a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb4a9a4: add             x0, x0, #0x10
    //     0xb4a9a8: cmp             x1, x0
    //     0xb4a9ac: b.ls            #0xb4aa14
    //     0xb4a9b0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4a9b4: sub             x0, x0, #0xf
    //     0xb4a9b8: mov             x1, #0xe19c
    //     0xb4a9bc: movk            x1, #3, lsl #16
    //     0xb4a9c0: stur            x1, [x0, #-1]
    // 0xb4a9c4: dmb             ishst
    // 0xb4a9c8: StoreField: r0->field_7 = d0
    //     0xb4a9c8: stur            d0, [x0, #7]
    // 0xb4a9cc: stp             NULL, x0, [SP]
    // 0xb4a9d0: ldur            x1, [fp, #-0x10]
    // 0xb4a9d4: r4 = const [0, 0x3, 0x2, 0x1, height, 0x2, width, 0x1, null]
    //     0xb4a9d4: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a6e8] List(9) [0, 0x3, 0x2, 0x1, "height", 0x2, "width", 0x1, Null]
    //     0xb4a9d8: ldr             x4, [x4, #0x6e8]
    // 0xb4a9dc: r0 = tighten()
    //     0xb4a9dc: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xb4a9e0: LeaveFrame
    //     0xb4a9e0: mov             SP, fp
    //     0xb4a9e4: ldp             fp, lr, [SP], #0x10
    // 0xb4a9e8: ret
    //     0xb4a9e8: ret             
    // 0xb4a9ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a9ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a9f0: b               #0xb4a930
    // 0xb4a9f4: stp             q1, q2, [SP, #-0x20]!
    // 0xb4a9f8: d0 = 0.000000
    //     0xb4a9f8: fmov            d0, d2
    // 0xb4a9fc: r0 = 66
    //     0xb4a9fc: mov             x0, #0x42
    // 0xb4aa00: r30 = DoubleToIntegerStub
    //     0xb4aa00: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb4aa04: LoadField: r30 = r30->field_7
    //     0xb4aa04: ldur            lr, [lr, #7]
    // 0xb4aa08: blr             lr
    // 0xb4aa0c: ldp             q1, q2, [SP], #0x20
    // 0xb4aa10: b               #0xb4a988
    // 0xb4aa14: SaveReg d0
    //     0xb4aa14: str             q0, [SP, #-0x10]!
    // 0xb4aa18: r0 = AllocateDouble()
    //     0xb4aa18: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4aa1c: RestoreReg d0
    //     0xb4aa1c: ldr             q0, [SP], #0x10
    // 0xb4aa20: b               #0xb4a9c8
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb57f70, size: 0x24
    // 0xb57f70: EnterFrame
    //     0xb57f70: stp             fp, lr, [SP, #-0x10]!
    //     0xb57f74: mov             fp, SP
    // 0xb57f78: ldr             x2, [fp, #0x10]
    // 0xb57f7c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb57f7c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4408] AnonymousClosure: (0xb2cd1c), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth (0xb2cc50)
    //     0xb57f80: ldr             x1, [x1, #0x408]
    // 0xb57f84: r0 = AllocateClosure()
    //     0xb57f84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57f88: LeaveFrame
    //     0xb57f88: mov             SP, fp
    //     0xb57f8c: ldp             fp, lr, [SP], #0x10
    // 0xb57f90: ret
    //     0xb57f90: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e284, size: 0x24
    // 0xb5e284: EnterFrame
    //     0xb5e284: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e288: mov             fp, SP
    // 0xb5e28c: ldr             x2, [fp, #0x10]
    // 0xb5e290: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e290: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a6d0] AnonymousClosure: (0xb29a00), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicHeight (0xb29964)
    //     0xb5e294: ldr             x1, [x1, #0x6d0]
    // 0xb5e298: r0 = AllocateClosure()
    //     0xb5e298: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e29c: LeaveFrame
    //     0xb5e29c: mov             SP, fp
    //     0xb5e2a0: ldp             fp, lr, [SP], #0x10
    // 0xb5e2a4: ret
    //     0xb5e2a4: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f7f8, size: 0xb4
    // 0xb5f7f8: EnterFrame
    //     0xb5f7f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f7fc: mov             fp, SP
    // 0xb5f800: AllocStack(0x20)
    //     0xb5f800: sub             SP, SP, #0x20
    // 0xb5f804: SetupParameters(RenderIntrinsicWidth this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5f804: mov             x5, x1
    //     0xb5f808: mov             x4, x2
    //     0xb5f80c: stur            x1, [fp, #-8]
    //     0xb5f810: stur            x2, [fp, #-0x10]
    //     0xb5f814: stur            x3, [fp, #-0x18]
    // 0xb5f818: CheckStackOverflow
    //     0xb5f818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f81c: cmp             SP, x16
    //     0xb5f820: b.ls            #0xb5f8a4
    // 0xb5f824: mov             x0, x4
    // 0xb5f828: r2 = Null
    //     0xb5f828: mov             x2, NULL
    // 0xb5f82c: r1 = Null
    //     0xb5f82c: mov             x1, NULL
    // 0xb5f830: r4 = 60
    //     0xb5f830: mov             x4, #0x3c
    // 0xb5f834: branchIfSmi(r0, 0xb5f840)
    //     0xb5f834: tbz             w0, #0, #0xb5f840
    // 0xb5f838: r4 = LoadClassIdInstr(r0)
    //     0xb5f838: ldur            x4, [x0, #-1]
    //     0xb5f83c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f840: sub             x4, x4, #0xb46
    // 0xb5f844: cmp             x4, #1
    // 0xb5f848: b.ls            #0xb5f85c
    // 0xb5f84c: r8 = BoxConstraints
    //     0xb5f84c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5f850: r3 = Null
    //     0xb5f850: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a6f0] Null
    //     0xb5f854: ldr             x3, [x3, #0x6f0]
    // 0xb5f858: r0 = BoxConstraints()
    //     0xb5f858: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5f85c: ldur            x1, [fp, #-8]
    // 0xb5f860: LoadField: r0 = r1->field_4f
    //     0xb5f860: ldur            w0, [x1, #0x4f]
    // 0xb5f864: DecompressPointer r0
    //     0xb5f864: add             x0, x0, HEAP, lsl #32
    // 0xb5f868: stur            x0, [fp, #-0x20]
    // 0xb5f86c: cmp             w0, NULL
    // 0xb5f870: b.ne            #0xb5f87c
    // 0xb5f874: r0 = Null
    //     0xb5f874: mov             x0, NULL
    // 0xb5f878: b               #0xb5f898
    // 0xb5f87c: mov             x2, x0
    // 0xb5f880: ldur            x3, [fp, #-0x10]
    // 0xb5f884: r0 = _childConstraints()
    //     0xb5f884: bl              #0xb4a900  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_childConstraints
    // 0xb5f888: ldur            x1, [fp, #-0x20]
    // 0xb5f88c: mov             x2, x0
    // 0xb5f890: ldur            x3, [fp, #-0x18]
    // 0xb5f894: r0 = getDryBaseline()
    //     0xb5f894: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb5f898: LeaveFrame
    //     0xb5f898: mov             SP, fp
    //     0xb5f89c: ldp             fp, lr, [SP], #0x10
    // 0xb5f8a0: ret
    //     0xb5f8a0: ret             
    // 0xb5f8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f8a8: b               #0xb5f824
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb9370, size: 0xcc
    // 0xbb9370: EnterFrame
    //     0xbb9370: stp             fp, lr, [SP, #-0x10]!
    //     0xbb9374: mov             fp, SP
    // 0xbb9378: AllocStack(0x10)
    //     0xbb9378: sub             SP, SP, #0x10
    // 0xbb937c: SetupParameters(RenderIntrinsicWidth this /* r1 => r3, fp-0x10 */)
    //     0xbb937c: mov             x3, x1
    //     0xbb9380: stur            x1, [fp, #-0x10]
    // 0xbb9384: CheckStackOverflow
    //     0xbb9384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9388: cmp             SP, x16
    //     0xbb938c: b.ls            #0xbb9434
    // 0xbb9390: LoadField: r4 = r3->field_27
    //     0xbb9390: ldur            w4, [x3, #0x27]
    // 0xbb9394: DecompressPointer r4
    //     0xbb9394: add             x4, x4, HEAP, lsl #32
    // 0xbb9398: stur            x4, [fp, #-8]
    // 0xbb939c: cmp             w4, NULL
    // 0xbb93a0: b.eq            #0xbb9418
    // 0xbb93a4: mov             x0, x4
    // 0xbb93a8: r2 = Null
    //     0xbb93a8: mov             x2, NULL
    // 0xbb93ac: r1 = Null
    //     0xbb93ac: mov             x1, NULL
    // 0xbb93b0: r4 = LoadClassIdInstr(r0)
    //     0xbb93b0: ldur            x4, [x0, #-1]
    //     0xbb93b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbb93b8: sub             x4, x4, #0xb46
    // 0xbb93bc: cmp             x4, #1
    // 0xbb93c0: b.ls            #0xbb93d4
    // 0xbb93c4: r8 = BoxConstraints
    //     0xbb93c4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb93c8: r3 = Null
    //     0xbb93c8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a6d8] Null
    //     0xbb93cc: ldr             x3, [x3, #0x6d8]
    // 0xbb93d0: r0 = BoxConstraints()
    //     0xbb93d0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb93d4: ldur            x1, [fp, #-0x10]
    // 0xbb93d8: ldur            x2, [fp, #-8]
    // 0xbb93dc: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbb93dc: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbb93e0: ldr             x3, [x3, #0x4f8]
    // 0xbb93e4: r0 = _computeSize()
    //     0xbb93e4: bl              #0xb4a874  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_computeSize
    // 0xbb93e8: ldur            x1, [fp, #-0x10]
    // 0xbb93ec: StoreField: r1->field_4b = r0
    //     0xbb93ec: stur            w0, [x1, #0x4b]
    //     0xbb93f0: ldurb           w16, [x1, #-1]
    //     0xbb93f4: ldurb           w17, [x0, #-1]
    //     0xbb93f8: and             x16, x17, x16, lsr #2
    //     0xbb93fc: tst             x16, HEAP, lsr #32
    //     0xbb9400: b.eq            #0xbb9408
    //     0xbb9404: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb9408: r0 = Null
    //     0xbb9408: mov             x0, NULL
    // 0xbb940c: LeaveFrame
    //     0xbb940c: mov             SP, fp
    //     0xbb9410: ldp             fp, lr, [SP], #0x10
    // 0xbb9414: ret
    //     0xbb9414: ret             
    // 0xbb9418: r0 = StateError()
    //     0xbb9418: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb941c: mov             x1, x0
    // 0xbb9420: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9420: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9424: StoreField: r1->field_b = r0
    //     0xbb9424: stur            w0, [x1, #0xb]
    // 0xbb9428: mov             x0, x1
    // 0xbb942c: r0 = Throw()
    //     0xbb942c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9430: brk             #0
    // 0xbb9434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb9438: b               #0xbb9390
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efa90, size: 0x24
    // 0x10efa90: EnterFrame
    //     0x10efa90: stp             fp, lr, [SP, #-0x10]!
    //     0x10efa94: mov             fp, SP
    // 0x10efa98: ldr             x2, [fp, #0x10]
    // 0x10efa9c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efa9c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4400] AnonymousClosure: (0xb22df0), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMinIntrinsicHeight (0xb22d54)
    //     0x10efaa0: ldr             x1, [x1, #0x400]
    // 0x10efaa4: r0 = AllocateClosure()
    //     0x10efaa4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efaa8: LeaveFrame
    //     0x10efaa8: mov             SP, fp
    //     0x10efaac: ldp             fp, lr, [SP], #0x10
    // 0x10efab0: ret
    //     0x10efab0: ret             
  }
  _ RenderIntrinsicWidth(/* No info */) {
    // ** addr: 0x11bf530, size: 0x8c
    // 0x11bf530: EnterFrame
    //     0x11bf530: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf534: mov             fp, SP
    // 0x11bf538: AllocStack(0x8)
    //     0x11bf538: sub             SP, SP, #8
    // 0x11bf53c: SetupParameters(RenderIntrinsicWidth this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0x11bf53c: mov             x0, x2
    //     0x11bf540: stur            x1, [fp, #-8]
    // 0x11bf544: CheckStackOverflow
    //     0x11bf544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf548: cmp             SP, x16
    //     0x11bf54c: b.ls            #0x11bf5b4
    // 0x11bf550: StoreField: r1->field_53 = r0
    //     0x11bf550: stur            w0, [x1, #0x53]
    //     0x11bf554: ldurb           w16, [x1, #-1]
    //     0x11bf558: ldurb           w17, [x0, #-1]
    //     0x11bf55c: and             x16, x17, x16, lsr #2
    //     0x11bf560: tst             x16, HEAP, lsr #32
    //     0x11bf564: b.eq            #0x11bf56c
    //     0x11bf568: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bf56c: r0 = _LayoutCacheStorage()
    //     0x11bf56c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11bf570: ldur            x2, [fp, #-8]
    // 0x11bf574: StoreField: r2->field_47 = r0
    //     0x11bf574: stur            w0, [x2, #0x47]
    //     0x11bf578: ldurb           w16, [x2, #-1]
    //     0x11bf57c: ldurb           w17, [x0, #-1]
    //     0x11bf580: and             x16, x17, x16, lsr #2
    //     0x11bf584: tst             x16, HEAP, lsr #32
    //     0x11bf588: b.eq            #0x11bf590
    //     0x11bf58c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11bf590: mov             x1, x2
    // 0x11bf594: r0 = RenderObject()
    //     0x11bf594: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11bf598: ldur            x1, [fp, #-8]
    // 0x11bf59c: r2 = Null
    //     0x11bf59c: mov             x2, NULL
    // 0x11bf5a0: r0 = child=()
    //     0x11bf5a0: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11bf5a4: r0 = Null
    //     0x11bf5a4: mov             x0, NULL
    // 0x11bf5a8: LeaveFrame
    //     0x11bf5a8: mov             SP, fp
    //     0x11bf5ac: ldp             fp, lr, [SP], #0x10
    // 0x11bf5b0: ret
    //     0x11bf5b0: ret             
    // 0x11bf5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf5b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf5b8: b               #0x11bf550
  }
}

// class id: 4945, size: 0x5c, field offset: 0x54
class RenderAspectRatio extends RenderProxyBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16540, size: 0x24
    // 0xb16540: EnterFrame
    //     0xb16540: stp             fp, lr, [SP, #-0x10]!
    //     0xb16544: mov             fp, SP
    // 0xb16548: ldr             x2, [fp, #0x10]
    // 0xb1654c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1654c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43f8] AnonymousClosure: (0xb16564), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicWidth (0xb165dc)
    //     0xb16550: ldr             x1, [x1, #0x3f8]
    // 0xb16554: r0 = AllocateClosure()
    //     0xb16554: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16558: LeaveFrame
    //     0xb16558: mov             SP, fp
    //     0xb1655c: ldp             fp, lr, [SP], #0x10
    // 0xb16560: ret
    //     0xb16560: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16564, size: 0x78
    // 0xb16564: EnterFrame
    //     0xb16564: stp             fp, lr, [SP, #-0x10]!
    //     0xb16568: mov             fp, SP
    // 0xb1656c: ldr             x0, [fp, #0x18]
    // 0xb16570: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16570: ldur            w1, [x0, #0x17]
    // 0xb16574: DecompressPointer r1
    //     0xb16574: add             x1, x1, HEAP, lsl #32
    // 0xb16578: CheckStackOverflow
    //     0xb16578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1657c: cmp             SP, x16
    //     0xb16580: b.ls            #0xb165c4
    // 0xb16584: ldr             x2, [fp, #0x10]
    // 0xb16588: r0 = computeMinIntrinsicWidth()
    //     0xb16588: bl              #0xb165dc  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicWidth
    // 0xb1658c: r0 = inline_Allocate_Double()
    //     0xb1658c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16590: add             x0, x0, #0x10
    //     0xb16594: cmp             x1, x0
    //     0xb16598: b.ls            #0xb165cc
    //     0xb1659c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb165a0: sub             x0, x0, #0xf
    //     0xb165a4: mov             x1, #0xe19c
    //     0xb165a8: movk            x1, #3, lsl #16
    //     0xb165ac: stur            x1, [x0, #-1]
    // 0xb165b0: dmb             ishst
    // 0xb165b4: StoreField: r0->field_7 = d0
    //     0xb165b4: stur            d0, [x0, #7]
    // 0xb165b8: LeaveFrame
    //     0xb165b8: mov             SP, fp
    //     0xb165bc: ldp             fp, lr, [SP], #0x10
    // 0xb165c0: ret
    //     0xb165c0: ret             
    // 0xb165c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb165c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb165c8: b               #0xb16584
    // 0xb165cc: SaveReg d0
    //     0xb165cc: str             q0, [SP, #-0x10]!
    // 0xb165d0: r0 = AllocateDouble()
    //     0xb165d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb165d4: RestoreReg d0
    //     0xb165d4: ldr             q0, [SP], #0x10
    // 0xb165d8: b               #0xb165b4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb165dc, size: 0xd4
    // 0xb165dc: EnterFrame
    //     0xb165dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb165e0: mov             fp, SP
    // 0xb165e4: CheckStackOverflow
    //     0xb165e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb165e8: cmp             SP, x16
    //     0xb165ec: b.ls            #0xb16698
    // 0xb165f0: LoadField: d0 = r2->field_7
    //     0xb165f0: ldur            d0, [x2, #7]
    // 0xb165f4: mov             x0, v0.d[0]
    // 0xb165f8: and             x0, x0, #0x7fffffffffffffff
    // 0xb165fc: r17 = 9218868437227405312
    //     0xb165fc: mov             x17, #0x7ff0000000000000
    // 0xb16600: cmp             x0, x17
    // 0xb16604: b.eq            #0xb16628
    // 0xb16608: fcmp            d0, d0
    // 0xb1660c: b.vs            #0xb16628
    // 0xb16610: LoadField: d1 = r1->field_53
    //     0xb16610: ldur            d1, [x1, #0x53]
    // 0xb16614: fmul            d2, d0, d1
    // 0xb16618: mov             v0.16b, v2.16b
    // 0xb1661c: LeaveFrame
    //     0xb1661c: mov             SP, fp
    //     0xb16620: ldp             fp, lr, [SP], #0x10
    // 0xb16624: ret
    //     0xb16624: ret             
    // 0xb16628: LoadField: r0 = r1->field_4f
    //     0xb16628: ldur            w0, [x1, #0x4f]
    // 0xb1662c: DecompressPointer r0
    //     0xb1662c: add             x0, x0, HEAP, lsl #32
    // 0xb16630: cmp             w0, NULL
    // 0xb16634: b.ne            #0xb16640
    // 0xb16638: r0 = Null
    //     0xb16638: mov             x0, NULL
    // 0xb1663c: b               #0xb16674
    // 0xb16640: mov             x1, x0
    // 0xb16644: r0 = getMinIntrinsicWidth()
    //     0xb16644: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb16648: r0 = inline_Allocate_Double()
    //     0xb16648: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1664c: add             x0, x0, #0x10
    //     0xb16650: cmp             x1, x0
    //     0xb16654: b.ls            #0xb166a0
    //     0xb16658: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1665c: sub             x0, x0, #0xf
    //     0xb16660: mov             x1, #0xe19c
    //     0xb16664: movk            x1, #3, lsl #16
    //     0xb16668: stur            x1, [x0, #-1]
    // 0xb1666c: dmb             ishst
    // 0xb16670: StoreField: r0->field_7 = d0
    //     0xb16670: stur            d0, [x0, #7]
    // 0xb16674: cmp             w0, NULL
    // 0xb16678: b.ne            #0xb16684
    // 0xb1667c: d0 = 0.000000
    //     0xb1667c: eor             v0.16b, v0.16b, v0.16b
    // 0xb16680: b               #0xb1668c
    // 0xb16684: LoadField: d1 = r0->field_7
    //     0xb16684: ldur            d1, [x0, #7]
    // 0xb16688: mov             v0.16b, v1.16b
    // 0xb1668c: LeaveFrame
    //     0xb1668c: mov             SP, fp
    //     0xb16690: ldp             fp, lr, [SP], #0x10
    // 0xb16694: ret
    //     0xb16694: ret             
    // 0xb16698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16698: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1669c: b               #0xb165f0
    // 0xb166a0: SaveReg d0
    //     0xb166a0: str             q0, [SP, #-0x10]!
    // 0xb166a4: r0 = AllocateDouble()
    //     0xb166a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb166a8: RestoreReg d0
    //     0xb166a8: ldr             q0, [SP], #0x10
    // 0xb166ac: b               #0xb16670
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb22c08, size: 0xd4
    // 0xb22c08: EnterFrame
    //     0xb22c08: stp             fp, lr, [SP, #-0x10]!
    //     0xb22c0c: mov             fp, SP
    // 0xb22c10: CheckStackOverflow
    //     0xb22c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22c14: cmp             SP, x16
    //     0xb22c18: b.ls            #0xb22cc4
    // 0xb22c1c: LoadField: d0 = r2->field_7
    //     0xb22c1c: ldur            d0, [x2, #7]
    // 0xb22c20: mov             x0, v0.d[0]
    // 0xb22c24: and             x0, x0, #0x7fffffffffffffff
    // 0xb22c28: r17 = 9218868437227405312
    //     0xb22c28: mov             x17, #0x7ff0000000000000
    // 0xb22c2c: cmp             x0, x17
    // 0xb22c30: b.eq            #0xb22c54
    // 0xb22c34: fcmp            d0, d0
    // 0xb22c38: b.vs            #0xb22c54
    // 0xb22c3c: LoadField: d1 = r1->field_53
    //     0xb22c3c: ldur            d1, [x1, #0x53]
    // 0xb22c40: fdiv            d2, d0, d1
    // 0xb22c44: mov             v0.16b, v2.16b
    // 0xb22c48: LeaveFrame
    //     0xb22c48: mov             SP, fp
    //     0xb22c4c: ldp             fp, lr, [SP], #0x10
    // 0xb22c50: ret
    //     0xb22c50: ret             
    // 0xb22c54: LoadField: r0 = r1->field_4f
    //     0xb22c54: ldur            w0, [x1, #0x4f]
    // 0xb22c58: DecompressPointer r0
    //     0xb22c58: add             x0, x0, HEAP, lsl #32
    // 0xb22c5c: cmp             w0, NULL
    // 0xb22c60: b.ne            #0xb22c6c
    // 0xb22c64: r0 = Null
    //     0xb22c64: mov             x0, NULL
    // 0xb22c68: b               #0xb22ca0
    // 0xb22c6c: mov             x1, x0
    // 0xb22c70: r0 = getMinIntrinsicHeight()
    //     0xb22c70: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb22c74: r0 = inline_Allocate_Double()
    //     0xb22c74: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22c78: add             x0, x0, #0x10
    //     0xb22c7c: cmp             x1, x0
    //     0xb22c80: b.ls            #0xb22ccc
    //     0xb22c84: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22c88: sub             x0, x0, #0xf
    //     0xb22c8c: mov             x1, #0xe19c
    //     0xb22c90: movk            x1, #3, lsl #16
    //     0xb22c94: stur            x1, [x0, #-1]
    // 0xb22c98: dmb             ishst
    // 0xb22c9c: StoreField: r0->field_7 = d0
    //     0xb22c9c: stur            d0, [x0, #7]
    // 0xb22ca0: cmp             w0, NULL
    // 0xb22ca4: b.ne            #0xb22cb0
    // 0xb22ca8: d0 = 0.000000
    //     0xb22ca8: eor             v0.16b, v0.16b, v0.16b
    // 0xb22cac: b               #0xb22cb8
    // 0xb22cb0: LoadField: d1 = r0->field_7
    //     0xb22cb0: ldur            d1, [x0, #7]
    // 0xb22cb4: mov             v0.16b, v1.16b
    // 0xb22cb8: LeaveFrame
    //     0xb22cb8: mov             SP, fp
    //     0xb22cbc: ldp             fp, lr, [SP], #0x10
    // 0xb22cc0: ret
    //     0xb22cc0: ret             
    // 0xb22cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22cc8: b               #0xb22c1c
    // 0xb22ccc: SaveReg d0
    //     0xb22ccc: str             q0, [SP, #-0x10]!
    // 0xb22cd0: r0 = AllocateDouble()
    //     0xb22cd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22cd4: RestoreReg d0
    //     0xb22cd4: ldr             q0, [SP], #0x10
    // 0xb22cd8: b               #0xb22c9c
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb22cdc, size: 0x78
    // 0xb22cdc: EnterFrame
    //     0xb22cdc: stp             fp, lr, [SP, #-0x10]!
    //     0xb22ce0: mov             fp, SP
    // 0xb22ce4: ldr             x0, [fp, #0x18]
    // 0xb22ce8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb22ce8: ldur            w1, [x0, #0x17]
    // 0xb22cec: DecompressPointer r1
    //     0xb22cec: add             x1, x1, HEAP, lsl #32
    // 0xb22cf0: CheckStackOverflow
    //     0xb22cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22cf4: cmp             SP, x16
    //     0xb22cf8: b.ls            #0xb22d3c
    // 0xb22cfc: ldr             x2, [fp, #0x10]
    // 0xb22d00: r0 = computeMinIntrinsicHeight()
    //     0xb22d00: bl              #0xb22c08  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicHeight
    // 0xb22d04: r0 = inline_Allocate_Double()
    //     0xb22d04: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22d08: add             x0, x0, #0x10
    //     0xb22d0c: cmp             x1, x0
    //     0xb22d10: b.ls            #0xb22d44
    //     0xb22d14: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22d18: sub             x0, x0, #0xf
    //     0xb22d1c: mov             x1, #0xe19c
    //     0xb22d20: movk            x1, #3, lsl #16
    //     0xb22d24: stur            x1, [x0, #-1]
    // 0xb22d28: dmb             ishst
    // 0xb22d2c: StoreField: r0->field_7 = d0
    //     0xb22d2c: stur            d0, [x0, #7]
    // 0xb22d30: LeaveFrame
    //     0xb22d30: mov             SP, fp
    //     0xb22d34: ldp             fp, lr, [SP], #0x10
    // 0xb22d38: ret
    //     0xb22d38: ret             
    // 0xb22d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22d3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22d40: b               #0xb22cfc
    // 0xb22d44: SaveReg d0
    //     0xb22d44: str             q0, [SP, #-0x10]!
    // 0xb22d48: r0 = AllocateDouble()
    //     0xb22d48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22d4c: RestoreReg d0
    //     0xb22d4c: ldr             q0, [SP], #0x10
    // 0xb22d50: b               #0xb22d2c
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29818, size: 0xd4
    // 0xb29818: EnterFrame
    //     0xb29818: stp             fp, lr, [SP, #-0x10]!
    //     0xb2981c: mov             fp, SP
    // 0xb29820: CheckStackOverflow
    //     0xb29820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29824: cmp             SP, x16
    //     0xb29828: b.ls            #0xb298d4
    // 0xb2982c: LoadField: d0 = r2->field_7
    //     0xb2982c: ldur            d0, [x2, #7]
    // 0xb29830: mov             x0, v0.d[0]
    // 0xb29834: and             x0, x0, #0x7fffffffffffffff
    // 0xb29838: r17 = 9218868437227405312
    //     0xb29838: mov             x17, #0x7ff0000000000000
    // 0xb2983c: cmp             x0, x17
    // 0xb29840: b.eq            #0xb29864
    // 0xb29844: fcmp            d0, d0
    // 0xb29848: b.vs            #0xb29864
    // 0xb2984c: LoadField: d1 = r1->field_53
    //     0xb2984c: ldur            d1, [x1, #0x53]
    // 0xb29850: fdiv            d2, d0, d1
    // 0xb29854: mov             v0.16b, v2.16b
    // 0xb29858: LeaveFrame
    //     0xb29858: mov             SP, fp
    //     0xb2985c: ldp             fp, lr, [SP], #0x10
    // 0xb29860: ret
    //     0xb29860: ret             
    // 0xb29864: LoadField: r0 = r1->field_4f
    //     0xb29864: ldur            w0, [x1, #0x4f]
    // 0xb29868: DecompressPointer r0
    //     0xb29868: add             x0, x0, HEAP, lsl #32
    // 0xb2986c: cmp             w0, NULL
    // 0xb29870: b.ne            #0xb2987c
    // 0xb29874: r0 = Null
    //     0xb29874: mov             x0, NULL
    // 0xb29878: b               #0xb298b0
    // 0xb2987c: mov             x1, x0
    // 0xb29880: r0 = getMaxIntrinsicHeight()
    //     0xb29880: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb29884: r0 = inline_Allocate_Double()
    //     0xb29884: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29888: add             x0, x0, #0x10
    //     0xb2988c: cmp             x1, x0
    //     0xb29890: b.ls            #0xb298dc
    //     0xb29894: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29898: sub             x0, x0, #0xf
    //     0xb2989c: mov             x1, #0xe19c
    //     0xb298a0: movk            x1, #3, lsl #16
    //     0xb298a4: stur            x1, [x0, #-1]
    // 0xb298a8: dmb             ishst
    // 0xb298ac: StoreField: r0->field_7 = d0
    //     0xb298ac: stur            d0, [x0, #7]
    // 0xb298b0: cmp             w0, NULL
    // 0xb298b4: b.ne            #0xb298c0
    // 0xb298b8: d0 = 0.000000
    //     0xb298b8: eor             v0.16b, v0.16b, v0.16b
    // 0xb298bc: b               #0xb298c8
    // 0xb298c0: LoadField: d1 = r0->field_7
    //     0xb298c0: ldur            d1, [x0, #7]
    // 0xb298c4: mov             v0.16b, v1.16b
    // 0xb298c8: LeaveFrame
    //     0xb298c8: mov             SP, fp
    //     0xb298cc: ldp             fp, lr, [SP], #0x10
    // 0xb298d0: ret
    //     0xb298d0: ret             
    // 0xb298d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb298d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb298d8: b               #0xb2982c
    // 0xb298dc: SaveReg d0
    //     0xb298dc: str             q0, [SP, #-0x10]!
    // 0xb298e0: r0 = AllocateDouble()
    //     0xb298e0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb298e4: RestoreReg d0
    //     0xb298e4: ldr             q0, [SP], #0x10
    // 0xb298e8: b               #0xb298ac
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb298ec, size: 0x78
    // 0xb298ec: EnterFrame
    //     0xb298ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb298f0: mov             fp, SP
    // 0xb298f4: ldr             x0, [fp, #0x18]
    // 0xb298f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb298f8: ldur            w1, [x0, #0x17]
    // 0xb298fc: DecompressPointer r1
    //     0xb298fc: add             x1, x1, HEAP, lsl #32
    // 0xb29900: CheckStackOverflow
    //     0xb29900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29904: cmp             SP, x16
    //     0xb29908: b.ls            #0xb2994c
    // 0xb2990c: ldr             x2, [fp, #0x10]
    // 0xb29910: r0 = computeMaxIntrinsicHeight()
    //     0xb29910: bl              #0xb29818  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicHeight
    // 0xb29914: r0 = inline_Allocate_Double()
    //     0xb29914: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29918: add             x0, x0, #0x10
    //     0xb2991c: cmp             x1, x0
    //     0xb29920: b.ls            #0xb29954
    //     0xb29924: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29928: sub             x0, x0, #0xf
    //     0xb2992c: mov             x1, #0xe19c
    //     0xb29930: movk            x1, #3, lsl #16
    //     0xb29934: stur            x1, [x0, #-1]
    // 0xb29938: dmb             ishst
    // 0xb2993c: StoreField: r0->field_7 = d0
    //     0xb2993c: stur            d0, [x0, #7]
    // 0xb29940: LeaveFrame
    //     0xb29940: mov             SP, fp
    //     0xb29944: ldp             fp, lr, [SP], #0x10
    // 0xb29948: ret
    //     0xb29948: ret             
    // 0xb2994c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2994c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29950: b               #0xb2990c
    // 0xb29954: SaveReg d0
    //     0xb29954: str             q0, [SP, #-0x10]!
    // 0xb29958: r0 = AllocateDouble()
    //     0xb29958: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2995c: RestoreReg d0
    //     0xb2995c: ldr             q0, [SP], #0x10
    // 0xb29960: b               #0xb2993c
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2cb04, size: 0xd4
    // 0xb2cb04: EnterFrame
    //     0xb2cb04: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cb08: mov             fp, SP
    // 0xb2cb0c: CheckStackOverflow
    //     0xb2cb0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cb10: cmp             SP, x16
    //     0xb2cb14: b.ls            #0xb2cbc0
    // 0xb2cb18: LoadField: d0 = r2->field_7
    //     0xb2cb18: ldur            d0, [x2, #7]
    // 0xb2cb1c: mov             x0, v0.d[0]
    // 0xb2cb20: and             x0, x0, #0x7fffffffffffffff
    // 0xb2cb24: r17 = 9218868437227405312
    //     0xb2cb24: mov             x17, #0x7ff0000000000000
    // 0xb2cb28: cmp             x0, x17
    // 0xb2cb2c: b.eq            #0xb2cb50
    // 0xb2cb30: fcmp            d0, d0
    // 0xb2cb34: b.vs            #0xb2cb50
    // 0xb2cb38: LoadField: d1 = r1->field_53
    //     0xb2cb38: ldur            d1, [x1, #0x53]
    // 0xb2cb3c: fmul            d2, d0, d1
    // 0xb2cb40: mov             v0.16b, v2.16b
    // 0xb2cb44: LeaveFrame
    //     0xb2cb44: mov             SP, fp
    //     0xb2cb48: ldp             fp, lr, [SP], #0x10
    // 0xb2cb4c: ret
    //     0xb2cb4c: ret             
    // 0xb2cb50: LoadField: r0 = r1->field_4f
    //     0xb2cb50: ldur            w0, [x1, #0x4f]
    // 0xb2cb54: DecompressPointer r0
    //     0xb2cb54: add             x0, x0, HEAP, lsl #32
    // 0xb2cb58: cmp             w0, NULL
    // 0xb2cb5c: b.ne            #0xb2cb68
    // 0xb2cb60: r0 = Null
    //     0xb2cb60: mov             x0, NULL
    // 0xb2cb64: b               #0xb2cb9c
    // 0xb2cb68: mov             x1, x0
    // 0xb2cb6c: r0 = getMaxIntrinsicWidth()
    //     0xb2cb6c: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2cb70: r0 = inline_Allocate_Double()
    //     0xb2cb70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2cb74: add             x0, x0, #0x10
    //     0xb2cb78: cmp             x1, x0
    //     0xb2cb7c: b.ls            #0xb2cbc8
    //     0xb2cb80: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2cb84: sub             x0, x0, #0xf
    //     0xb2cb88: mov             x1, #0xe19c
    //     0xb2cb8c: movk            x1, #3, lsl #16
    //     0xb2cb90: stur            x1, [x0, #-1]
    // 0xb2cb94: dmb             ishst
    // 0xb2cb98: StoreField: r0->field_7 = d0
    //     0xb2cb98: stur            d0, [x0, #7]
    // 0xb2cb9c: cmp             w0, NULL
    // 0xb2cba0: b.ne            #0xb2cbac
    // 0xb2cba4: d0 = 0.000000
    //     0xb2cba4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2cba8: b               #0xb2cbb4
    // 0xb2cbac: LoadField: d1 = r0->field_7
    //     0xb2cbac: ldur            d1, [x0, #7]
    // 0xb2cbb0: mov             v0.16b, v1.16b
    // 0xb2cbb4: LeaveFrame
    //     0xb2cbb4: mov             SP, fp
    //     0xb2cbb8: ldp             fp, lr, [SP], #0x10
    // 0xb2cbbc: ret
    //     0xb2cbbc: ret             
    // 0xb2cbc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2cbc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2cbc4: b               #0xb2cb18
    // 0xb2cbc8: SaveReg d0
    //     0xb2cbc8: str             q0, [SP, #-0x10]!
    // 0xb2cbcc: r0 = AllocateDouble()
    //     0xb2cbcc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2cbd0: RestoreReg d0
    //     0xb2cbd0: ldr             q0, [SP], #0x10
    // 0xb2cbd4: b               #0xb2cb98
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2cbd8, size: 0x78
    // 0xb2cbd8: EnterFrame
    //     0xb2cbd8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cbdc: mov             fp, SP
    // 0xb2cbe0: ldr             x0, [fp, #0x18]
    // 0xb2cbe4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2cbe4: ldur            w1, [x0, #0x17]
    // 0xb2cbe8: DecompressPointer r1
    //     0xb2cbe8: add             x1, x1, HEAP, lsl #32
    // 0xb2cbec: CheckStackOverflow
    //     0xb2cbec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cbf0: cmp             SP, x16
    //     0xb2cbf4: b.ls            #0xb2cc38
    // 0xb2cbf8: ldr             x2, [fp, #0x10]
    // 0xb2cbfc: r0 = computeMaxIntrinsicWidth()
    //     0xb2cbfc: bl              #0xb2cb04  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicWidth
    // 0xb2cc00: r0 = inline_Allocate_Double()
    //     0xb2cc00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2cc04: add             x0, x0, #0x10
    //     0xb2cc08: cmp             x1, x0
    //     0xb2cc0c: b.ls            #0xb2cc40
    //     0xb2cc10: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2cc14: sub             x0, x0, #0xf
    //     0xb2cc18: mov             x1, #0xe19c
    //     0xb2cc1c: movk            x1, #3, lsl #16
    //     0xb2cc20: stur            x1, [x0, #-1]
    // 0xb2cc24: dmb             ishst
    // 0xb2cc28: StoreField: r0->field_7 = d0
    //     0xb2cc28: stur            d0, [x0, #7]
    // 0xb2cc2c: LeaveFrame
    //     0xb2cc2c: mov             SP, fp
    //     0xb2cc30: ldp             fp, lr, [SP], #0x10
    // 0xb2cc34: ret
    //     0xb2cc34: ret             
    // 0xb2cc38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2cc38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2cc3c: b               #0xb2cbf8
    // 0xb2cc40: SaveReg d0
    //     0xb2cc40: str             q0, [SP, #-0x10]!
    // 0xb2cc44: r0 = AllocateDouble()
    //     0xb2cc44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2cc48: RestoreReg d0
    //     0xb2cc48: ldr             q0, [SP], #0x10
    // 0xb2cc4c: b               #0xb2cc28
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4a6c8, size: 0x2c
    // 0xb4a6c8: EnterFrame
    //     0xb4a6c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a6cc: mov             fp, SP
    // 0xb4a6d0: CheckStackOverflow
    //     0xb4a6d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a6d4: cmp             SP, x16
    //     0xb4a6d8: b.ls            #0xb4a6ec
    // 0xb4a6dc: r0 = _applyAspectRatio()
    //     0xb4a6dc: bl              #0xb4a6f4  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::_applyAspectRatio
    // 0xb4a6e0: LeaveFrame
    //     0xb4a6e0: mov             SP, fp
    //     0xb4a6e4: ldp             fp, lr, [SP], #0x10
    // 0xb4a6e8: ret
    //     0xb4a6e8: ret             
    // 0xb4a6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a6f0: b               #0xb4a6dc
  }
  _ _applyAspectRatio(/* No info */) {
    // ** addr: 0xb4a6f4, size: 0x14c
    // 0xb4a6f4: EnterFrame
    //     0xb4a6f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a6f8: mov             fp, SP
    // 0xb4a6fc: AllocStack(0x18)
    //     0xb4a6fc: sub             SP, SP, #0x18
    // 0xb4a700: SetupParameters(RenderAspectRatio this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0xb4a700: mov             x0, x1
    //     0xb4a704: mov             x1, x2
    //     0xb4a708: stur            x2, [fp, #-8]
    // 0xb4a70c: CheckStackOverflow
    //     0xb4a70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a710: cmp             SP, x16
    //     0xb4a714: b.ls            #0xb4a838
    // 0xb4a718: LoadField: d0 = r1->field_7
    //     0xb4a718: ldur            d0, [x1, #7]
    // 0xb4a71c: LoadField: d1 = r1->field_f
    //     0xb4a71c: ldur            d1, [x1, #0xf]
    // 0xb4a720: fcmp            d0, d1
    // 0xb4a724: b.lt            #0xb4a748
    // 0xb4a728: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb4a728: ldur            d2, [x1, #0x17]
    // 0xb4a72c: LoadField: d3 = r1->field_1f
    //     0xb4a72c: ldur            d3, [x1, #0x1f]
    // 0xb4a730: fcmp            d2, d3
    // 0xb4a734: b.lt            #0xb4a748
    // 0xb4a738: r0 = smallest()
    //     0xb4a738: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4a73c: LeaveFrame
    //     0xb4a73c: mov             SP, fp
    //     0xb4a740: ldp             fp, lr, [SP], #0x10
    // 0xb4a744: ret
    //     0xb4a744: ret             
    // 0xb4a748: mov             x2, v1.d[0]
    // 0xb4a74c: and             x2, x2, #0x7fffffffffffffff
    // 0xb4a750: r17 = 9218868437227405312
    //     0xb4a750: mov             x17, #0x7ff0000000000000
    // 0xb4a754: cmp             x2, x17
    // 0xb4a758: b.eq            #0xb4a774
    // 0xb4a75c: fcmp            d1, d1
    // 0xb4a760: b.vs            #0xb4a774
    // 0xb4a764: LoadField: d2 = r0->field_53
    //     0xb4a764: ldur            d2, [x0, #0x53]
    // 0xb4a768: fdiv            d3, d1, d2
    // 0xb4a76c: mov             v4.16b, v1.16b
    // 0xb4a770: b               #0xb4a78c
    // 0xb4a774: LoadField: d2 = r1->field_1f
    //     0xb4a774: ldur            d2, [x1, #0x1f]
    // 0xb4a778: LoadField: d3 = r0->field_53
    //     0xb4a778: ldur            d3, [x0, #0x53]
    // 0xb4a77c: fmul            d4, d2, d3
    // 0xb4a780: mov             v31.16b, v3.16b
    // 0xb4a784: mov             v3.16b, v2.16b
    // 0xb4a788: mov             v2.16b, v31.16b
    // 0xb4a78c: fcmp            d4, d1
    // 0xb4a790: b.le            #0xb4a7a8
    // 0xb4a794: fdiv            d3, d1, d2
    // 0xb4a798: mov             v31.16b, v3.16b
    // 0xb4a79c: mov             v3.16b, v1.16b
    // 0xb4a7a0: mov             v1.16b, v31.16b
    // 0xb4a7a4: b               #0xb4a7b0
    // 0xb4a7a8: mov             v1.16b, v3.16b
    // 0xb4a7ac: mov             v3.16b, v4.16b
    // 0xb4a7b0: LoadField: d4 = r1->field_1f
    //     0xb4a7b0: ldur            d4, [x1, #0x1f]
    // 0xb4a7b4: fcmp            d1, d4
    // 0xb4a7b8: b.le            #0xb4a7c8
    // 0xb4a7bc: fmul            d1, d4, d2
    // 0xb4a7c0: mov             v3.16b, v1.16b
    // 0xb4a7c4: mov             v1.16b, v4.16b
    // 0xb4a7c8: fcmp            d0, d3
    // 0xb4a7cc: b.le            #0xb4a7e4
    // 0xb4a7d0: fdiv            d1, d0, d2
    // 0xb4a7d4: mov             v31.16b, v1.16b
    // 0xb4a7d8: mov             v1.16b, v0.16b
    // 0xb4a7dc: mov             v0.16b, v31.16b
    // 0xb4a7e0: b               #0xb4a7ec
    // 0xb4a7e4: mov             v0.16b, v1.16b
    // 0xb4a7e8: mov             v1.16b, v3.16b
    // 0xb4a7ec: ArrayLoad: d3 = r1[0]  ; List_8
    //     0xb4a7ec: ldur            d3, [x1, #0x17]
    // 0xb4a7f0: fcmp            d3, d0
    // 0xb4a7f4: b.le            #0xb4a804
    // 0xb4a7f8: fmul            d0, d3, d2
    // 0xb4a7fc: mov             v1.16b, v0.16b
    // 0xb4a800: mov             v0.16b, v3.16b
    // 0xb4a804: stur            d1, [fp, #-0x10]
    // 0xb4a808: stur            d0, [fp, #-0x18]
    // 0xb4a80c: r0 = Size()
    //     0xb4a80c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4a810: ldur            d0, [fp, #-0x10]
    // 0xb4a814: StoreField: r0->field_7 = d0
    //     0xb4a814: stur            d0, [x0, #7]
    // 0xb4a818: ldur            d0, [fp, #-0x18]
    // 0xb4a81c: StoreField: r0->field_f = d0
    //     0xb4a81c: stur            d0, [x0, #0xf]
    // 0xb4a820: ldur            x1, [fp, #-8]
    // 0xb4a824: mov             x2, x0
    // 0xb4a828: r0 = constrain()
    //     0xb4a828: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4a82c: LeaveFrame
    //     0xb4a82c: mov             SP, fp
    //     0xb4a830: ldp             fp, lr, [SP], #0x10
    // 0xb4a834: ret
    //     0xb4a834: ret             
    // 0xb4a838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a83c: b               #0xb4a718
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb57f4c, size: 0x24
    // 0xb57f4c: EnterFrame
    //     0xb57f4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb57f50: mov             fp, SP
    // 0xb57f54: ldr             x2, [fp, #0x10]
    // 0xb57f58: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb57f58: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43f0] AnonymousClosure: (0xb2cbd8), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicWidth (0xb2cb04)
    //     0xb57f5c: ldr             x1, [x1, #0x3f0]
    // 0xb57f60: r0 = AllocateClosure()
    //     0xb57f60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57f64: LeaveFrame
    //     0xb57f64: mov             SP, fp
    //     0xb57f68: ldp             fp, lr, [SP], #0x10
    // 0xb57f6c: ret
    //     0xb57f6c: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e260, size: 0x24
    // 0xb5e260: EnterFrame
    //     0xb5e260: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e264: mov             fp, SP
    // 0xb5e268: ldr             x2, [fp, #0x10]
    // 0xb5e26c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e26c: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a628] AnonymousClosure: (0xb298ec), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicHeight (0xb29818)
    //     0xb5e270: ldr             x1, [x1, #0x628]
    // 0xb5e274: r0 = AllocateClosure()
    //     0xb5e274: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e278: LeaveFrame
    //     0xb5e278: mov             SP, fp
    //     0xb5e27c: ldp             fp, lr, [SP], #0x10
    // 0xb5e280: ret
    //     0xb5e280: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f738, size: 0xc0
    // 0xb5f738: EnterFrame
    //     0xb5f738: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f73c: mov             fp, SP
    // 0xb5f740: AllocStack(0x20)
    //     0xb5f740: sub             SP, SP, #0x20
    // 0xb5f744: SetupParameters(RenderAspectRatio this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5f744: mov             x5, x1
    //     0xb5f748: mov             x4, x2
    //     0xb5f74c: stur            x1, [fp, #-8]
    //     0xb5f750: stur            x2, [fp, #-0x10]
    //     0xb5f754: stur            x3, [fp, #-0x18]
    // 0xb5f758: CheckStackOverflow
    //     0xb5f758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f75c: cmp             SP, x16
    //     0xb5f760: b.ls            #0xb5f7f0
    // 0xb5f764: mov             x0, x4
    // 0xb5f768: r2 = Null
    //     0xb5f768: mov             x2, NULL
    // 0xb5f76c: r1 = Null
    //     0xb5f76c: mov             x1, NULL
    // 0xb5f770: r4 = 60
    //     0xb5f770: mov             x4, #0x3c
    // 0xb5f774: branchIfSmi(r0, 0xb5f780)
    //     0xb5f774: tbz             w0, #0, #0xb5f780
    // 0xb5f778: r4 = LoadClassIdInstr(r0)
    //     0xb5f778: ldur            x4, [x0, #-1]
    //     0xb5f77c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f780: sub             x4, x4, #0xb46
    // 0xb5f784: cmp             x4, #1
    // 0xb5f788: b.ls            #0xb5f79c
    // 0xb5f78c: r8 = BoxConstraints
    //     0xb5f78c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5f790: r3 = Null
    //     0xb5f790: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a630] Null
    //     0xb5f794: ldr             x3, [x3, #0x630]
    // 0xb5f798: r0 = BoxConstraints()
    //     0xb5f798: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5f79c: ldur            x1, [fp, #-8]
    // 0xb5f7a0: ldur            x2, [fp, #-0x10]
    // 0xb5f7a4: r0 = getDryLayout()
    //     0xb5f7a4: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb5f7a8: stur            x0, [fp, #-0x10]
    // 0xb5f7ac: LoadField: d0 = r0->field_7
    //     0xb5f7ac: ldur            d0, [x0, #7]
    // 0xb5f7b0: stur            d0, [fp, #-0x20]
    // 0xb5f7b4: r0 = BoxConstraints()
    //     0xb5f7b4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb5f7b8: ldur            d0, [fp, #-0x20]
    // 0xb5f7bc: StoreField: r0->field_7 = d0
    //     0xb5f7bc: stur            d0, [x0, #7]
    // 0xb5f7c0: StoreField: r0->field_f = d0
    //     0xb5f7c0: stur            d0, [x0, #0xf]
    // 0xb5f7c4: ldur            x1, [fp, #-0x10]
    // 0xb5f7c8: LoadField: d0 = r1->field_f
    //     0xb5f7c8: ldur            d0, [x1, #0xf]
    // 0xb5f7cc: ArrayStore: r0[0] = d0  ; List_8
    //     0xb5f7cc: stur            d0, [x0, #0x17]
    // 0xb5f7d0: StoreField: r0->field_1f = d0
    //     0xb5f7d0: stur            d0, [x0, #0x1f]
    // 0xb5f7d4: ldur            x1, [fp, #-8]
    // 0xb5f7d8: mov             x2, x0
    // 0xb5f7dc: ldur            x3, [fp, #-0x18]
    // 0xb5f7e0: r0 = computeDryBaseline()
    //     0xb5f7e0: bl              #0xb5fa98  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeDryBaseline
    // 0xb5f7e4: LeaveFrame
    //     0xb5f7e4: mov             SP, fp
    //     0xb5f7e8: ldp             fp, lr, [SP], #0x10
    // 0xb5f7ec: ret
    //     0xb5f7ec: ret             
    // 0xb5f7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f7f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f7f4: b               #0xb5f764
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb923c, size: 0x134
    // 0xbb923c: EnterFrame
    //     0xbb923c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb9240: mov             fp, SP
    // 0xbb9244: AllocStack(0x18)
    //     0xbb9244: sub             SP, SP, #0x18
    // 0xbb9248: SetupParameters(RenderAspectRatio this /* r1 => r3, fp-0x10 */)
    //     0xbb9248: mov             x3, x1
    //     0xbb924c: stur            x1, [fp, #-0x10]
    // 0xbb9250: CheckStackOverflow
    //     0xbb9250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9254: cmp             SP, x16
    //     0xbb9258: b.ls            #0xbb9368
    // 0xbb925c: LoadField: r4 = r3->field_27
    //     0xbb925c: ldur            w4, [x3, #0x27]
    // 0xbb9260: DecompressPointer r4
    //     0xbb9260: add             x4, x4, HEAP, lsl #32
    // 0xbb9264: stur            x4, [fp, #-8]
    // 0xbb9268: cmp             w4, NULL
    // 0xbb926c: b.eq            #0xbb934c
    // 0xbb9270: mov             x0, x4
    // 0xbb9274: r2 = Null
    //     0xbb9274: mov             x2, NULL
    // 0xbb9278: r1 = Null
    //     0xbb9278: mov             x1, NULL
    // 0xbb927c: r4 = LoadClassIdInstr(r0)
    //     0xbb927c: ldur            x4, [x0, #-1]
    //     0xbb9280: ubfx            x4, x4, #0xc, #0x14
    // 0xbb9284: sub             x4, x4, #0xb46
    // 0xbb9288: cmp             x4, #1
    // 0xbb928c: b.ls            #0xbb92a0
    // 0xbb9290: r8 = BoxConstraints
    //     0xbb9290: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb9294: r3 = Null
    //     0xbb9294: add             x3, PP, #0x90, lsl #12  ; [pp+0x90bd0] Null
    //     0xbb9298: ldr             x3, [x3, #0xbd0]
    // 0xbb929c: r0 = BoxConstraints()
    //     0xbb929c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb92a0: ldur            x1, [fp, #-0x10]
    // 0xbb92a4: ldur            x2, [fp, #-8]
    // 0xbb92a8: r0 = getDryLayout()
    //     0xbb92a8: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xbb92ac: ldur            x1, [fp, #-0x10]
    // 0xbb92b0: StoreField: r1->field_4b = r0
    //     0xbb92b0: stur            w0, [x1, #0x4b]
    //     0xbb92b4: ldurb           w16, [x1, #-1]
    //     0xbb92b8: ldurb           w17, [x0, #-1]
    //     0xbb92bc: and             x16, x17, x16, lsr #2
    //     0xbb92c0: tst             x16, HEAP, lsr #32
    //     0xbb92c4: b.eq            #0xbb92cc
    //     0xbb92c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb92cc: LoadField: r0 = r1->field_4f
    //     0xbb92cc: ldur            w0, [x1, #0x4f]
    // 0xbb92d0: DecompressPointer r0
    //     0xbb92d0: add             x0, x0, HEAP, lsl #32
    // 0xbb92d4: stur            x0, [fp, #-8]
    // 0xbb92d8: cmp             w0, NULL
    // 0xbb92dc: b.eq            #0xbb933c
    // 0xbb92e0: r0 = size()
    //     0xbb92e0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb92e4: stur            x0, [fp, #-0x10]
    // 0xbb92e8: LoadField: d0 = r0->field_7
    //     0xbb92e8: ldur            d0, [x0, #7]
    // 0xbb92ec: stur            d0, [fp, #-0x18]
    // 0xbb92f0: r0 = BoxConstraints()
    //     0xbb92f0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbb92f4: ldur            d0, [fp, #-0x18]
    // 0xbb92f8: StoreField: r0->field_7 = d0
    //     0xbb92f8: stur            d0, [x0, #7]
    // 0xbb92fc: StoreField: r0->field_f = d0
    //     0xbb92fc: stur            d0, [x0, #0xf]
    // 0xbb9300: ldur            x1, [fp, #-0x10]
    // 0xbb9304: LoadField: d0 = r1->field_f
    //     0xbb9304: ldur            d0, [x1, #0xf]
    // 0xbb9308: ArrayStore: r0[0] = d0  ; List_8
    //     0xbb9308: stur            d0, [x0, #0x17]
    // 0xbb930c: StoreField: r0->field_1f = d0
    //     0xbb930c: stur            d0, [x0, #0x1f]
    // 0xbb9310: ldur            x1, [fp, #-8]
    // 0xbb9314: r2 = LoadClassIdInstr(r1)
    //     0xbb9314: ldur            x2, [x1, #-1]
    //     0xbb9318: ubfx            x2, x2, #0xc, #0x14
    // 0xbb931c: mov             x16, x0
    // 0xbb9320: mov             x0, x2
    // 0xbb9324: mov             x2, x16
    // 0xbb9328: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbb9328: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbb932c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb932c: mov             x17, #0xe6b9
    //     0xbb9330: add             lr, x0, x17
    //     0xbb9334: ldr             lr, [x21, lr, lsl #3]
    //     0xbb9338: blr             lr
    // 0xbb933c: r0 = Null
    //     0xbb933c: mov             x0, NULL
    // 0xbb9340: LeaveFrame
    //     0xbb9340: mov             SP, fp
    //     0xbb9344: ldp             fp, lr, [SP], #0x10
    // 0xbb9348: ret
    //     0xbb9348: ret             
    // 0xbb934c: r0 = StateError()
    //     0xbb934c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb9350: mov             x1, x0
    // 0xbb9354: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9354: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9358: StoreField: r1->field_b = r0
    //     0xbb9358: stur            w0, [x1, #0xb]
    // 0xbb935c: mov             x0, x1
    // 0xbb9360: r0 = Throw()
    //     0xbb9360: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9364: brk             #0
    // 0xbb9368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb936c: b               #0xbb925c
  }
  set _ aspectRatio=(/* No info */) {
    // ** addr: 0xcf8620, size: 0x50
    // 0xcf8620: EnterFrame
    //     0xcf8620: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8624: mov             fp, SP
    // 0xcf8628: CheckStackOverflow
    //     0xcf8628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf862c: cmp             SP, x16
    //     0xcf8630: b.ls            #0xcf8668
    // 0xcf8634: LoadField: d1 = r1->field_53
    //     0xcf8634: ldur            d1, [x1, #0x53]
    // 0xcf8638: fcmp            d1, d0
    // 0xcf863c: b.ne            #0xcf8650
    // 0xcf8640: r0 = Null
    //     0xcf8640: mov             x0, NULL
    // 0xcf8644: LeaveFrame
    //     0xcf8644: mov             SP, fp
    //     0xcf8648: ldp             fp, lr, [SP], #0x10
    // 0xcf864c: ret
    //     0xcf864c: ret             
    // 0xcf8650: StoreField: r1->field_53 = d0
    //     0xcf8650: stur            d0, [x1, #0x53]
    // 0xcf8654: r0 = markNeedsLayout()
    //     0xcf8654: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf8658: r0 = Null
    //     0xcf8658: mov             x0, NULL
    // 0xcf865c: LeaveFrame
    //     0xcf865c: mov             SP, fp
    //     0xcf8660: ldp             fp, lr, [SP], #0x10
    // 0xcf8664: ret
    //     0xcf8664: ret             
    // 0xcf8668: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf8668: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf866c: b               #0xcf8634
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efa6c, size: 0x24
    // 0x10efa6c: EnterFrame
    //     0x10efa6c: stp             fp, lr, [SP, #-0x10]!
    //     0x10efa70: mov             fp, SP
    // 0x10efa74: ldr             x2, [fp, #0x10]
    // 0x10efa78: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efa78: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43e8] AnonymousClosure: (0xb22cdc), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicHeight (0xb22c08)
    //     0x10efa7c: ldr             x1, [x1, #0x3e8]
    // 0x10efa80: r0 = AllocateClosure()
    //     0x10efa80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efa84: LeaveFrame
    //     0x10efa84: mov             SP, fp
    //     0x10efa88: ldp             fp, lr, [SP], #0x10
    // 0x10efa8c: ret
    //     0x10efa8c: ret             
  }
  _ RenderAspectRatio(/* No info */) {
    // ** addr: 0x11d1d48, size: 0x70
    // 0x11d1d48: EnterFrame
    //     0x11d1d48: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1d4c: mov             fp, SP
    // 0x11d1d50: AllocStack(0x8)
    //     0x11d1d50: sub             SP, SP, #8
    // 0x11d1d54: SetupParameters(RenderAspectRatio this /* r1 => r1, fp-0x8 */)
    //     0x11d1d54: stur            x1, [fp, #-8]
    // 0x11d1d58: CheckStackOverflow
    //     0x11d1d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1d5c: cmp             SP, x16
    //     0x11d1d60: b.ls            #0x11d1db0
    // 0x11d1d64: StoreField: r1->field_53 = d0
    //     0x11d1d64: stur            d0, [x1, #0x53]
    // 0x11d1d68: r0 = _LayoutCacheStorage()
    //     0x11d1d68: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1d6c: ldur            x2, [fp, #-8]
    // 0x11d1d70: StoreField: r2->field_47 = r0
    //     0x11d1d70: stur            w0, [x2, #0x47]
    //     0x11d1d74: ldurb           w16, [x2, #-1]
    //     0x11d1d78: ldurb           w17, [x0, #-1]
    //     0x11d1d7c: and             x16, x17, x16, lsr #2
    //     0x11d1d80: tst             x16, HEAP, lsr #32
    //     0x11d1d84: b.eq            #0x11d1d8c
    //     0x11d1d88: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d1d8c: mov             x1, x2
    // 0x11d1d90: r0 = RenderObject()
    //     0x11d1d90: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1d94: ldur            x1, [fp, #-8]
    // 0x11d1d98: r2 = Null
    //     0x11d1d98: mov             x2, NULL
    // 0x11d1d9c: r0 = child=()
    //     0x11d1d9c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1da0: r0 = Null
    //     0x11d1da0: mov             x0, NULL
    // 0x11d1da4: LeaveFrame
    //     0x11d1da4: mov             SP, fp
    //     0x11d1da8: ldp             fp, lr, [SP], #0x10
    // 0x11d1dac: ret
    //     0x11d1dac: ret             
    // 0x11d1db0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d1db0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d1db4: b               #0x11d1d64
  }
}

// class id: 4946, size: 0x64, field offset: 0x54
class RenderLimitedBox extends RenderProxyBox {

  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4a464, size: 0x34
    // 0xb4a464: EnterFrame
    //     0xb4a464: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a468: mov             fp, SP
    // 0xb4a46c: CheckStackOverflow
    //     0xb4a46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a470: cmp             SP, x16
    //     0xb4a474: b.ls            #0xb4a490
    // 0xb4a478: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4a478: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4a47c: ldr             x3, [x3, #0x700]
    // 0xb4a480: r0 = _computeSize()
    //     0xb4a480: bl              #0xb4a498  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_computeSize
    // 0xb4a484: LeaveFrame
    //     0xb4a484: mov             SP, fp
    //     0xb4a488: ldp             fp, lr, [SP], #0x10
    // 0xb4a48c: ret
    //     0xb4a48c: ret             
    // 0xb4a490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a494: b               #0xb4a478
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0xb4a498, size: 0xa4
    // 0xb4a498: EnterFrame
    //     0xb4a498: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a49c: mov             fp, SP
    // 0xb4a4a0: AllocStack(0x30)
    //     0xb4a4a0: sub             SP, SP, #0x30
    // 0xb4a4a4: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb4a4a4: mov             x0, x3
    //     0xb4a4a8: stur            x3, [fp, #-0x18]
    //     0xb4a4ac: mov             x3, x2
    //     0xb4a4b0: stur            x2, [fp, #-0x10]
    // 0xb4a4b4: CheckStackOverflow
    //     0xb4a4b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a4b8: cmp             SP, x16
    //     0xb4a4bc: b.ls            #0xb4a534
    // 0xb4a4c0: LoadField: r4 = r1->field_4f
    //     0xb4a4c0: ldur            w4, [x1, #0x4f]
    // 0xb4a4c4: DecompressPointer r4
    //     0xb4a4c4: add             x4, x4, HEAP, lsl #32
    // 0xb4a4c8: stur            x4, [fp, #-8]
    // 0xb4a4cc: cmp             w4, NULL
    // 0xb4a4d0: b.eq            #0xb4a514
    // 0xb4a4d4: mov             x2, x3
    // 0xb4a4d8: r0 = _limitConstraints()
    //     0xb4a4d8: bl              #0xb4a53c  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_limitConstraints
    // 0xb4a4dc: ldur            x16, [fp, #-0x18]
    // 0xb4a4e0: ldur            lr, [fp, #-8]
    // 0xb4a4e4: stp             lr, x16, [SP, #8]
    // 0xb4a4e8: str             x0, [SP]
    // 0xb4a4ec: ldur            x0, [fp, #-0x18]
    // 0xb4a4f0: ClosureCall
    //     0xb4a4f0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb4a4f4: ldur            x2, [x0, #0x1f]
    //     0xb4a4f8: blr             x2
    // 0xb4a4fc: ldur            x1, [fp, #-0x10]
    // 0xb4a500: mov             x2, x0
    // 0xb4a504: r0 = constrain()
    //     0xb4a504: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4a508: LeaveFrame
    //     0xb4a508: mov             SP, fp
    //     0xb4a50c: ldp             fp, lr, [SP], #0x10
    // 0xb4a510: ret
    //     0xb4a510: ret             
    // 0xb4a514: ldur            x2, [fp, #-0x10]
    // 0xb4a518: r0 = _limitConstraints()
    //     0xb4a518: bl              #0xb4a53c  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_limitConstraints
    // 0xb4a51c: mov             x1, x0
    // 0xb4a520: r2 = Instance_Size
    //     0xb4a520: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb4a524: r0 = constrain()
    //     0xb4a524: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4a528: LeaveFrame
    //     0xb4a528: mov             SP, fp
    //     0xb4a52c: ldp             fp, lr, [SP], #0x10
    // 0xb4a530: ret
    //     0xb4a530: ret             
    // 0xb4a534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a538: b               #0xb4a4c0
  }
  _ _limitConstraints(/* No info */) {
    // ** addr: 0xb4a53c, size: 0x18c
    // 0xb4a53c: EnterFrame
    //     0xb4a53c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a540: mov             fp, SP
    // 0xb4a544: AllocStack(0x38)
    //     0xb4a544: sub             SP, SP, #0x38
    // 0xb4a548: d0 = inf
    //     0xb4a548: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4a54c: mov             x0, x2
    // 0xb4a550: stur            x2, [fp, #-0x10]
    // 0xb4a554: mov             x2, x1
    // 0xb4a558: stur            x1, [fp, #-8]
    // 0xb4a55c: CheckStackOverflow
    //     0xb4a55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a560: cmp             SP, x16
    //     0xb4a564: b.ls            #0xb4a67c
    // 0xb4a568: LoadField: d1 = r0->field_7
    //     0xb4a568: ldur            d1, [x0, #7]
    // 0xb4a56c: stur            d1, [fp, #-0x18]
    // 0xb4a570: LoadField: d2 = r0->field_f
    //     0xb4a570: ldur            d2, [x0, #0xf]
    // 0xb4a574: fcmp            d0, d2
    // 0xb4a578: b.le            #0xb4a588
    // 0xb4a57c: mov             v1.16b, v2.16b
    // 0xb4a580: mov             x1, x0
    // 0xb4a584: b               #0xb4a5d4
    // 0xb4a588: LoadField: d2 = r2->field_53
    //     0xb4a588: ldur            d2, [x2, #0x53]
    // 0xb4a58c: r1 = inline_Allocate_Double()
    //     0xb4a58c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xb4a590: add             x1, x1, #0x10
    //     0xb4a594: cmp             x3, x1
    //     0xb4a598: b.ls            #0xb4a684
    //     0xb4a59c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb4a5a0: sub             x1, x1, #0xf
    //     0xb4a5a4: mov             x3, #0xe19c
    //     0xb4a5a8: movk            x3, #3, lsl #16
    //     0xb4a5ac: stur            x3, [x1, #-1]
    // 0xb4a5b0: dmb             ishst
    // 0xb4a5b4: StoreField: r1->field_7 = d2
    //     0xb4a5b4: stur            d2, [x1, #7]
    // 0xb4a5b8: str             x1, [SP]
    // 0xb4a5bc: mov             x1, x0
    // 0xb4a5c0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb4a5c0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb4a5c4: r0 = constrainWidth()
    //     0xb4a5c4: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb4a5c8: mov             v1.16b, v0.16b
    // 0xb4a5cc: ldur            x1, [fp, #-0x10]
    // 0xb4a5d0: d0 = inf
    //     0xb4a5d0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4a5d4: stur            d1, [fp, #-0x28]
    // 0xb4a5d8: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb4a5d8: ldur            d2, [x1, #0x17]
    // 0xb4a5dc: stur            d2, [fp, #-0x20]
    // 0xb4a5e0: LoadField: d3 = r1->field_1f
    //     0xb4a5e0: ldur            d3, [x1, #0x1f]
    // 0xb4a5e4: fcmp            d0, d3
    // 0xb4a5e8: b.le            #0xb4a5f8
    // 0xb4a5ec: mov             v0.16b, v1.16b
    // 0xb4a5f0: mov             v1.16b, v2.16b
    // 0xb4a5f4: b               #0xb4a644
    // 0xb4a5f8: ldur            x0, [fp, #-8]
    // 0xb4a5fc: LoadField: d0 = r0->field_5b
    //     0xb4a5fc: ldur            d0, [x0, #0x5b]
    // 0xb4a600: r0 = inline_Allocate_Double()
    //     0xb4a600: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb4a604: add             x0, x0, #0x10
    //     0xb4a608: cmp             x2, x0
    //     0xb4a60c: b.ls            #0xb4a6a8
    //     0xb4a610: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4a614: sub             x0, x0, #0xf
    //     0xb4a618: mov             x2, #0xe19c
    //     0xb4a61c: movk            x2, #3, lsl #16
    //     0xb4a620: stur            x2, [x0, #-1]
    // 0xb4a624: dmb             ishst
    // 0xb4a628: StoreField: r0->field_7 = d0
    //     0xb4a628: stur            d0, [x0, #7]
    // 0xb4a62c: str             x0, [SP]
    // 0xb4a630: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb4a630: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb4a634: r0 = constrainHeight()
    //     0xb4a634: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb4a638: mov             v3.16b, v0.16b
    // 0xb4a63c: ldur            d0, [fp, #-0x28]
    // 0xb4a640: ldur            d1, [fp, #-0x20]
    // 0xb4a644: ldur            d2, [fp, #-0x18]
    // 0xb4a648: stur            d3, [fp, #-0x30]
    // 0xb4a64c: r0 = BoxConstraints()
    //     0xb4a64c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4a650: ldur            d0, [fp, #-0x18]
    // 0xb4a654: StoreField: r0->field_7 = d0
    //     0xb4a654: stur            d0, [x0, #7]
    // 0xb4a658: ldur            d0, [fp, #-0x28]
    // 0xb4a65c: StoreField: r0->field_f = d0
    //     0xb4a65c: stur            d0, [x0, #0xf]
    // 0xb4a660: ldur            d0, [fp, #-0x20]
    // 0xb4a664: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4a664: stur            d0, [x0, #0x17]
    // 0xb4a668: ldur            d0, [fp, #-0x30]
    // 0xb4a66c: StoreField: r0->field_1f = d0
    //     0xb4a66c: stur            d0, [x0, #0x1f]
    // 0xb4a670: LeaveFrame
    //     0xb4a670: mov             SP, fp
    //     0xb4a674: ldp             fp, lr, [SP], #0x10
    // 0xb4a678: ret
    //     0xb4a678: ret             
    // 0xb4a67c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb4a67c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb4a680: b               #0xb4a568
    // 0xb4a684: stp             q1, q2, [SP, #-0x20]!
    // 0xb4a688: SaveReg d0
    //     0xb4a688: str             q0, [SP, #-0x10]!
    // 0xb4a68c: stp             x0, x2, [SP, #-0x10]!
    // 0xb4a690: r0 = AllocateDouble()
    //     0xb4a690: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4a694: mov             x1, x0
    // 0xb4a698: ldp             x0, x2, [SP], #0x10
    // 0xb4a69c: RestoreReg d0
    //     0xb4a69c: ldr             q0, [SP], #0x10
    // 0xb4a6a0: ldp             q1, q2, [SP], #0x20
    // 0xb4a6a4: b               #0xb4a5b4
    // 0xb4a6a8: stp             q1, q2, [SP, #-0x20]!
    // 0xb4a6ac: SaveReg d0
    //     0xb4a6ac: str             q0, [SP, #-0x10]!
    // 0xb4a6b0: SaveReg r1
    //     0xb4a6b0: str             x1, [SP, #-8]!
    // 0xb4a6b4: r0 = AllocateDouble()
    //     0xb4a6b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4a6b8: RestoreReg r1
    //     0xb4a6b8: ldr             x1, [SP], #8
    // 0xb4a6bc: RestoreReg d0
    //     0xb4a6bc: ldr             q0, [SP], #0x10
    // 0xb4a6c0: ldp             q1, q2, [SP], #0x20
    // 0xb4a6c4: b               #0xb4a628
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb9170, size: 0xcc
    // 0xbb9170: EnterFrame
    //     0xbb9170: stp             fp, lr, [SP, #-0x10]!
    //     0xbb9174: mov             fp, SP
    // 0xbb9178: AllocStack(0x10)
    //     0xbb9178: sub             SP, SP, #0x10
    // 0xbb917c: SetupParameters(RenderLimitedBox this /* r1 => r3, fp-0x10 */)
    //     0xbb917c: mov             x3, x1
    //     0xbb9180: stur            x1, [fp, #-0x10]
    // 0xbb9184: CheckStackOverflow
    //     0xbb9184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9188: cmp             SP, x16
    //     0xbb918c: b.ls            #0xbb9234
    // 0xbb9190: LoadField: r4 = r3->field_27
    //     0xbb9190: ldur            w4, [x3, #0x27]
    // 0xbb9194: DecompressPointer r4
    //     0xbb9194: add             x4, x4, HEAP, lsl #32
    // 0xbb9198: stur            x4, [fp, #-8]
    // 0xbb919c: cmp             w4, NULL
    // 0xbb91a0: b.eq            #0xbb9218
    // 0xbb91a4: mov             x0, x4
    // 0xbb91a8: r2 = Null
    //     0xbb91a8: mov             x2, NULL
    // 0xbb91ac: r1 = Null
    //     0xbb91ac: mov             x1, NULL
    // 0xbb91b0: r4 = LoadClassIdInstr(r0)
    //     0xbb91b0: ldur            x4, [x0, #-1]
    //     0xbb91b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbb91b8: sub             x4, x4, #0xb46
    // 0xbb91bc: cmp             x4, #1
    // 0xbb91c0: b.ls            #0xbb91d4
    // 0xbb91c4: r8 = BoxConstraints
    //     0xbb91c4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb91c8: r3 = Null
    //     0xbb91c8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a5a8] Null
    //     0xbb91cc: ldr             x3, [x3, #0x5a8]
    // 0xbb91d0: r0 = BoxConstraints()
    //     0xbb91d0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb91d4: ldur            x1, [fp, #-0x10]
    // 0xbb91d8: ldur            x2, [fp, #-8]
    // 0xbb91dc: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbb91dc: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbb91e0: ldr             x3, [x3, #0x4f8]
    // 0xbb91e4: r0 = _computeSize()
    //     0xbb91e4: bl              #0xb4a498  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_computeSize
    // 0xbb91e8: ldur            x1, [fp, #-0x10]
    // 0xbb91ec: StoreField: r1->field_4b = r0
    //     0xbb91ec: stur            w0, [x1, #0x4b]
    //     0xbb91f0: ldurb           w16, [x1, #-1]
    //     0xbb91f4: ldurb           w17, [x0, #-1]
    //     0xbb91f8: and             x16, x17, x16, lsr #2
    //     0xbb91fc: tst             x16, HEAP, lsr #32
    //     0xbb9200: b.eq            #0xbb9208
    //     0xbb9204: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb9208: r0 = Null
    //     0xbb9208: mov             x0, NULL
    // 0xbb920c: LeaveFrame
    //     0xbb920c: mov             SP, fp
    //     0xbb9210: ldp             fp, lr, [SP], #0x10
    // 0xbb9214: ret
    //     0xbb9214: ret             
    // 0xbb9218: r0 = StateError()
    //     0xbb9218: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb921c: mov             x1, x0
    // 0xbb9220: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb9220: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb9224: StoreField: r1->field_b = r0
    //     0xbb9224: stur            w0, [x1, #0xb]
    // 0xbb9228: mov             x0, x1
    // 0xbb922c: r0 = Throw()
    //     0xbb922c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb9230: brk             #0
    // 0xbb9234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb9238: b               #0xbb9190
  }
  set _ maxHeight=(/* No info */) {
    // ** addr: 0xcf47d4, size: 0x50
    // 0xcf47d4: EnterFrame
    //     0xcf47d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf47d8: mov             fp, SP
    // 0xcf47dc: CheckStackOverflow
    //     0xcf47dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf47e0: cmp             SP, x16
    //     0xcf47e4: b.ls            #0xcf481c
    // 0xcf47e8: LoadField: d1 = r1->field_5b
    //     0xcf47e8: ldur            d1, [x1, #0x5b]
    // 0xcf47ec: fcmp            d1, d0
    // 0xcf47f0: b.ne            #0xcf4804
    // 0xcf47f4: r0 = Null
    //     0xcf47f4: mov             x0, NULL
    // 0xcf47f8: LeaveFrame
    //     0xcf47f8: mov             SP, fp
    //     0xcf47fc: ldp             fp, lr, [SP], #0x10
    // 0xcf4800: ret
    //     0xcf4800: ret             
    // 0xcf4804: StoreField: r1->field_5b = d0
    //     0xcf4804: stur            d0, [x1, #0x5b]
    // 0xcf4808: r0 = markNeedsLayout()
    //     0xcf4808: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf480c: r0 = Null
    //     0xcf480c: mov             x0, NULL
    // 0xcf4810: LeaveFrame
    //     0xcf4810: mov             SP, fp
    //     0xcf4814: ldp             fp, lr, [SP], #0x10
    // 0xcf4818: ret
    //     0xcf4818: ret             
    // 0xcf481c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf481c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf4820: b               #0xcf47e8
  }
  _ RenderLimitedBox(/* No info */) {
    // ** addr: 0x11d1a8c, size: 0x74
    // 0x11d1a8c: EnterFrame
    //     0x11d1a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1a90: mov             fp, SP
    // 0x11d1a94: AllocStack(0x8)
    //     0x11d1a94: sub             SP, SP, #8
    // 0x11d1a98: SetupParameters(RenderLimitedBox this /* r1 => r1, fp-0x8 */)
    //     0x11d1a98: stur            x1, [fp, #-8]
    // 0x11d1a9c: CheckStackOverflow
    //     0x11d1a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1aa0: cmp             SP, x16
    //     0x11d1aa4: b.ls            #0x11d1af8
    // 0x11d1aa8: StoreField: r1->field_53 = d1
    //     0x11d1aa8: stur            d1, [x1, #0x53]
    // 0x11d1aac: StoreField: r1->field_5b = d0
    //     0x11d1aac: stur            d0, [x1, #0x5b]
    // 0x11d1ab0: r0 = _LayoutCacheStorage()
    //     0x11d1ab0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1ab4: ldur            x2, [fp, #-8]
    // 0x11d1ab8: StoreField: r2->field_47 = r0
    //     0x11d1ab8: stur            w0, [x2, #0x47]
    //     0x11d1abc: ldurb           w16, [x2, #-1]
    //     0x11d1ac0: ldurb           w17, [x0, #-1]
    //     0x11d1ac4: and             x16, x17, x16, lsr #2
    //     0x11d1ac8: tst             x16, HEAP, lsr #32
    //     0x11d1acc: b.eq            #0x11d1ad4
    //     0x11d1ad0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d1ad4: mov             x1, x2
    // 0x11d1ad8: r0 = RenderObject()
    //     0x11d1ad8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1adc: ldur            x1, [fp, #-8]
    // 0x11d1ae0: r2 = Null
    //     0x11d1ae0: mov             x2, NULL
    // 0x11d1ae4: r0 = child=()
    //     0x11d1ae4: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1ae8: r0 = Null
    //     0x11d1ae8: mov             x0, NULL
    // 0x11d1aec: LeaveFrame
    //     0x11d1aec: mov             SP, fp
    //     0x11d1af0: ldp             fp, lr, [SP], #0x10
    // 0x11d1af4: ret
    //     0x11d1af4: ret             
    // 0x11d1af8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d1af8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d1afc: b               #0x11d1aa8
  }
}

// class id: 4947, size: 0x58, field offset: 0x54
abstract class RenderProxyBoxWithHitTestBehavior extends RenderProxyBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf82ec, size: 0xf0
    // 0xaf82ec: EnterFrame
    //     0xaf82ec: stp             fp, lr, [SP, #-0x10]!
    //     0xaf82f0: mov             fp, SP
    // 0xaf82f4: AllocStack(0x18)
    //     0xaf82f4: sub             SP, SP, #0x18
    // 0xaf82f8: SetupParameters(RenderProxyBoxWithHitTestBehavior this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xaf82f8: mov             x0, x2
    //     0xaf82fc: stur            x2, [fp, #-0x10]
    //     0xaf8300: mov             x2, x3
    //     0xaf8304: stur            x3, [fp, #-0x18]
    //     0xaf8308: mov             x3, x1
    //     0xaf830c: stur            x1, [fp, #-8]
    // 0xaf8310: CheckStackOverflow
    //     0xaf8310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf8314: cmp             SP, x16
    //     0xaf8318: b.ls            #0xaf83d4
    // 0xaf831c: mov             x1, x3
    // 0xaf8320: r0 = size()
    //     0xaf8320: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xaf8324: mov             x1, x0
    // 0xaf8328: ldur            x2, [fp, #-0x18]
    // 0xaf832c: r0 = contains()
    //     0xaf832c: bl              #0x81d498  ; [dart:ui] Size::contains
    // 0xaf8330: tbnz            w0, #4, #0xaf83c4
    // 0xaf8334: ldur            x1, [fp, #-8]
    // 0xaf8338: ldur            x2, [fp, #-0x10]
    // 0xaf833c: ldur            x3, [fp, #-0x18]
    // 0xaf8340: r0 = hitTestChildren()
    //     0xaf8340: bl              #0x10e9bac  ; [package:syncfusion_flutter_charts/src/charts/common/element_widget.dart] CustomRenderLayoutBuilder::hitTestChildren
    // 0xaf8344: tbnz            w0, #4, #0xaf8354
    // 0xaf8348: ldur            x0, [fp, #-8]
    // 0xaf834c: r2 = true
    //     0xaf834c: add             x2, NULL, #0x20  ; true
    // 0xaf8350: b               #0xaf8378
    // 0xaf8354: ldur            x0, [fp, #-8]
    // 0xaf8358: LoadField: r1 = r0->field_53
    //     0xaf8358: ldur            w1, [x0, #0x53]
    // 0xaf835c: DecompressPointer r1
    //     0xaf835c: add             x1, x1, HEAP, lsl #32
    // 0xaf8360: r16 = Instance_HitTestBehavior
    //     0xaf8360: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xaf8364: ldr             x16, [x16, #0x5c0]
    // 0xaf8368: cmp             w1, w16
    // 0xaf836c: r16 = true
    //     0xaf836c: add             x16, NULL, #0x20  ; true
    // 0xaf8370: r17 = false
    //     0xaf8370: add             x17, NULL, #0x30  ; false
    // 0xaf8374: csel            x2, x16, x17, eq
    // 0xaf8378: stur            x2, [fp, #-0x18]
    // 0xaf837c: tbz             w2, #4, #0xaf8398
    // 0xaf8380: LoadField: r1 = r0->field_53
    //     0xaf8380: ldur            w1, [x0, #0x53]
    // 0xaf8384: DecompressPointer r1
    //     0xaf8384: add             x1, x1, HEAP, lsl #32
    // 0xaf8388: r16 = Instance_HitTestBehavior
    //     0xaf8388: add             x16, PP, #0x15, lsl #12  ; [pp+0x15508] Obj!HitTestBehavior@12c43e1
    //     0xaf838c: ldr             x16, [x16, #0x508]
    // 0xaf8390: cmp             w1, w16
    // 0xaf8394: b.ne            #0xaf83bc
    // 0xaf8398: r1 = <RenderBox>
    //     0xaf8398: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xaf839c: ldr             x1, [x1, #0x5c8]
    // 0xaf83a0: r0 = BoxHitTestEntry()
    //     0xaf83a0: bl              #0xaf81ac  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x14)
    // 0xaf83a4: mov             x1, x0
    // 0xaf83a8: ldur            x0, [fp, #-8]
    // 0xaf83ac: StoreField: r1->field_b = r0
    //     0xaf83ac: stur            w0, [x1, #0xb]
    // 0xaf83b0: mov             x2, x1
    // 0xaf83b4: ldur            x1, [fp, #-0x10]
    // 0xaf83b8: r0 = add()
    //     0xaf83b8: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0xaf83bc: ldur            x0, [fp, #-0x18]
    // 0xaf83c0: b               #0xaf83c8
    // 0xaf83c4: r0 = false
    //     0xaf83c4: add             x0, NULL, #0x30  ; false
    // 0xaf83c8: LeaveFrame
    //     0xaf83c8: mov             SP, fp
    //     0xaf83cc: ldp             fp, lr, [SP], #0x10
    // 0xaf83d0: ret
    //     0xaf83d0: ret             
    // 0xaf83d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf83d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf83d8: b               #0xaf831c
  }
  _ hitTestSelf(/* No info */) {
    // ** addr: 0xb5d20c, size: 0x24
    // 0xb5d20c: LoadField: r2 = r1->field_53
    //     0xb5d20c: ldur            w2, [x1, #0x53]
    // 0xb5d210: DecompressPointer r2
    //     0xb5d210: add             x2, x2, HEAP, lsl #32
    // 0xb5d214: r16 = Instance_HitTestBehavior
    //     0xb5d214: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xb5d218: ldr             x16, [x16, #0x5c0]
    // 0xb5d21c: cmp             w2, w16
    // 0xb5d220: r16 = true
    //     0xb5d220: add             x16, NULL, #0x20  ; true
    // 0xb5d224: r17 = false
    //     0xb5d224: add             x17, NULL, #0x30  ; false
    // 0xb5d228: csel            x0, x16, x17, eq
    // 0xb5d22c: ret
    //     0xb5d22c: ret             
  }
  _ RenderProxyBoxWithHitTestBehavior(/* No info */) {
    // ** addr: 0x11d2340, size: 0xc0
    // 0x11d2340: EnterFrame
    //     0x11d2340: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2344: mov             fp, SP
    // 0x11d2348: AllocStack(0x8)
    //     0x11d2348: sub             SP, SP, #8
    // 0x11d234c: SetupParameters(RenderProxyBoxWithHitTestBehavior this /* r1 => r1, fp-0x8 */, {dynamic behavior = Instance_HitTestBehavior /* r0 */})
    //     0x11d234c: stur            x1, [fp, #-8]
    //     0x11d2350: ldur            w0, [x4, #0x13]
    //     0x11d2354: ldur            w2, [x4, #0x1f]
    //     0x11d2358: add             x2, x2, HEAP, lsl #32
    //     0x11d235c: add             x16, PP, #0x12, lsl #12  ; [pp+0x123c0] "behavior"
    //     0x11d2360: ldr             x16, [x16, #0x3c0]
    //     0x11d2364: cmp             w2, w16
    //     0x11d2368: b.ne            #0x11d2384
    //     0x11d236c: ldur            w2, [x4, #0x23]
    //     0x11d2370: add             x2, x2, HEAP, lsl #32
    //     0x11d2374: sub             w3, w0, w2
    //     0x11d2378: add             x0, fp, w3, sxtw #2
    //     0x11d237c: ldr             x0, [x0, #8]
    //     0x11d2380: b               #0x11d2388
    //     0x11d2384: ldr             x0, [PP, #0x5368]  ; [pp+0x5368] Obj!HitTestBehavior@12c43a1
    // 0x11d2388: CheckStackOverflow
    //     0x11d2388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d238c: cmp             SP, x16
    //     0x11d2390: b.ls            #0x11d23f8
    // 0x11d2394: StoreField: r1->field_53 = r0
    //     0x11d2394: stur            w0, [x1, #0x53]
    //     0x11d2398: ldurb           w16, [x1, #-1]
    //     0x11d239c: ldurb           w17, [x0, #-1]
    //     0x11d23a0: and             x16, x17, x16, lsr #2
    //     0x11d23a4: tst             x16, HEAP, lsr #32
    //     0x11d23a8: b.eq            #0x11d23b0
    //     0x11d23ac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d23b0: r0 = _LayoutCacheStorage()
    //     0x11d23b0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d23b4: ldur            x2, [fp, #-8]
    // 0x11d23b8: StoreField: r2->field_47 = r0
    //     0x11d23b8: stur            w0, [x2, #0x47]
    //     0x11d23bc: ldurb           w16, [x2, #-1]
    //     0x11d23c0: ldurb           w17, [x0, #-1]
    //     0x11d23c4: and             x16, x17, x16, lsr #2
    //     0x11d23c8: tst             x16, HEAP, lsr #32
    //     0x11d23cc: b.eq            #0x11d23d4
    //     0x11d23d0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d23d4: mov             x1, x2
    // 0x11d23d8: r0 = RenderObject()
    //     0x11d23d8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d23dc: ldur            x1, [fp, #-8]
    // 0x11d23e0: r2 = Null
    //     0x11d23e0: mov             x2, NULL
    // 0x11d23e4: r0 = child=()
    //     0x11d23e4: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d23e8: r0 = Null
    //     0x11d23e8: mov             x0, NULL
    // 0x11d23ec: LeaveFrame
    //     0x11d23ec: mov             SP, fp
    //     0x11d23f0: ldp             fp, lr, [SP], #0x10
    // 0x11d23f4: ret
    //     0x11d23f4: ret             
    // 0x11d23f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d23f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d23fc: b               #0x11d2394
  }
}

// class id: 4951, size: 0x74, field offset: 0x58
class RenderSemanticsGestureHandler extends RenderProxyBoxWithHitTestBehavior {

  set _ validActions=(/* No info */) {
    // ** addr: 0x86d3dc, size: 0x94
    // 0x86d3dc: EnterFrame
    //     0x86d3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x86d3e0: mov             fp, SP
    // 0x86d3e4: AllocStack(0x28)
    //     0x86d3e4: sub             SP, SP, #0x28
    // 0x86d3e8: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x86d3e8: mov             x0, x2
    //     0x86d3ec: stur            x1, [fp, #-8]
    //     0x86d3f0: stur            x2, [fp, #-0x10]
    // 0x86d3f4: CheckStackOverflow
    //     0x86d3f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86d3f8: cmp             SP, x16
    //     0x86d3fc: b.ls            #0x86d468
    // 0x86d400: LoadField: r2 = r1->field_57
    //     0x86d400: ldur            w2, [x1, #0x57]
    // 0x86d404: DecompressPointer r2
    //     0x86d404: add             x2, x2, HEAP, lsl #32
    // 0x86d408: r16 = <SemanticsAction>
    //     0x86d408: ldr             x16, [PP, #0x5540]  ; [pp+0x5540] TypeArguments: <SemanticsAction>
    // 0x86d40c: stp             x0, x16, [SP, #8]
    // 0x86d410: str             x2, [SP]
    // 0x86d414: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x86d414: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x86d418: r0 = setEquals()
    //     0x86d418: bl              #0x86d470  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0x86d41c: tbnz            w0, #4, #0x86d430
    // 0x86d420: r0 = Null
    //     0x86d420: mov             x0, NULL
    // 0x86d424: LeaveFrame
    //     0x86d424: mov             SP, fp
    //     0x86d428: ldp             fp, lr, [SP], #0x10
    // 0x86d42c: ret
    //     0x86d42c: ret             
    // 0x86d430: ldur            x1, [fp, #-8]
    // 0x86d434: ldur            x0, [fp, #-0x10]
    // 0x86d438: StoreField: r1->field_57 = r0
    //     0x86d438: stur            w0, [x1, #0x57]
    //     0x86d43c: ldurb           w16, [x1, #-1]
    //     0x86d440: ldurb           w17, [x0, #-1]
    //     0x86d444: and             x16, x17, x16, lsr #2
    //     0x86d448: tst             x16, HEAP, lsr #32
    //     0x86d44c: b.eq            #0x86d454
    //     0x86d450: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86d454: r0 = markNeedsSemanticsUpdate()
    //     0x86d454: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x86d458: r0 = Null
    //     0x86d458: mov             x0, NULL
    // 0x86d45c: LeaveFrame
    //     0x86d45c: mov             SP, fp
    //     0x86d460: ldp             fp, lr, [SP], #0x10
    // 0x86d464: ret
    //     0x86d464: ret             
    // 0x86d468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86d468: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86d46c: b               #0x86d400
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf5688, size: 0x1bc
    // 0xbf5688: EnterFrame
    //     0xbf5688: stp             fp, lr, [SP, #-0x10]!
    //     0xbf568c: mov             fp, SP
    // 0xbf5690: AllocStack(0x10)
    //     0xbf5690: sub             SP, SP, #0x10
    // 0xbf5694: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf5694: mov             x3, x1
    //     0xbf5698: mov             x0, x2
    //     0xbf569c: stur            x1, [fp, #-8]
    //     0xbf56a0: stur            x2, [fp, #-0x10]
    // 0xbf56a4: CheckStackOverflow
    //     0xbf56a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf56a8: cmp             SP, x16
    //     0xbf56ac: b.ls            #0xbf5834
    // 0xbf56b0: LoadField: r1 = r3->field_5b
    //     0xbf56b0: ldur            w1, [x3, #0x5b]
    // 0xbf56b4: DecompressPointer r1
    //     0xbf56b4: add             x1, x1, HEAP, lsl #32
    // 0xbf56b8: cmp             w1, NULL
    // 0xbf56bc: b.eq            #0xbf56f0
    // 0xbf56c0: mov             x1, x3
    // 0xbf56c4: r2 = Instance_SemanticsAction
    //     0xbf56c4: ldr             x2, [PP, #0x26b0]  ; [pp+0x26b0] Obj!SemanticsAction@12a0901
    // 0xbf56c8: r0 = _isValidAction()
    //     0xbf56c8: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf56cc: tbnz            w0, #4, #0xbf56f0
    // 0xbf56d0: ldur            x0, [fp, #-8]
    // 0xbf56d4: LoadField: r3 = r0->field_5b
    //     0xbf56d4: ldur            w3, [x0, #0x5b]
    // 0xbf56d8: DecompressPointer r3
    //     0xbf56d8: add             x3, x3, HEAP, lsl #32
    // 0xbf56dc: cmp             w3, NULL
    // 0xbf56e0: b.eq            #0xbf583c
    // 0xbf56e4: ldur            x1, [fp, #-0x10]
    // 0xbf56e8: r2 = Instance_SemanticsAction
    //     0xbf56e8: ldr             x2, [PP, #0x26b0]  ; [pp+0x26b0] Obj!SemanticsAction@12a0901
    // 0xbf56ec: r0 = _addArgumentlessAction()
    //     0xbf56ec: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf56f0: ldur            x0, [fp, #-8]
    // 0xbf56f4: LoadField: r1 = r0->field_5f
    //     0xbf56f4: ldur            w1, [x0, #0x5f]
    // 0xbf56f8: DecompressPointer r1
    //     0xbf56f8: add             x1, x1, HEAP, lsl #32
    // 0xbf56fc: cmp             w1, NULL
    // 0xbf5700: b.eq            #0xbf573c
    // 0xbf5704: mov             x1, x0
    // 0xbf5708: r2 = Instance_SemanticsAction
    //     0xbf5708: add             x2, PP, #0x85, lsl #12  ; [pp+0x85768] Obj!SemanticsAction@12a08e1
    //     0xbf570c: ldr             x2, [x2, #0x768]
    // 0xbf5710: r0 = _isValidAction()
    //     0xbf5710: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf5714: tbnz            w0, #4, #0xbf573c
    // 0xbf5718: ldur            x0, [fp, #-8]
    // 0xbf571c: LoadField: r3 = r0->field_5f
    //     0xbf571c: ldur            w3, [x0, #0x5f]
    // 0xbf5720: DecompressPointer r3
    //     0xbf5720: add             x3, x3, HEAP, lsl #32
    // 0xbf5724: cmp             w3, NULL
    // 0xbf5728: b.eq            #0xbf5840
    // 0xbf572c: ldur            x1, [fp, #-0x10]
    // 0xbf5730: r2 = Instance_SemanticsAction
    //     0xbf5730: add             x2, PP, #0x85, lsl #12  ; [pp+0x85768] Obj!SemanticsAction@12a08e1
    //     0xbf5734: ldr             x2, [x2, #0x768]
    // 0xbf5738: r0 = _addArgumentlessAction()
    //     0xbf5738: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf573c: ldur            x0, [fp, #-8]
    // 0xbf5740: LoadField: r1 = r0->field_63
    //     0xbf5740: ldur            w1, [x0, #0x63]
    // 0xbf5744: DecompressPointer r1
    //     0xbf5744: add             x1, x1, HEAP, lsl #32
    // 0xbf5748: cmp             w1, NULL
    // 0xbf574c: b.eq            #0xbf57b0
    // 0xbf5750: mov             x1, x0
    // 0xbf5754: r2 = Instance_SemanticsAction
    //     0xbf5754: add             x2, PP, #0x9a, lsl #12  ; [pp+0x9a738] Obj!SemanticsAction@12a08a1
    //     0xbf5758: ldr             x2, [x2, #0x738]
    // 0xbf575c: r0 = _isValidAction()
    //     0xbf575c: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf5760: tbnz            w0, #4, #0xbf5780
    // 0xbf5764: ldur            x2, [fp, #-8]
    // 0xbf5768: r1 = Function '_performSemanticScrollRight@37160605':.
    //     0xbf5768: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a740] AnonymousClosure: (0xbf5fdc), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollRight (0xbf6014)
    //     0xbf576c: ldr             x1, [x1, #0x740]
    // 0xbf5770: r0 = AllocateClosure()
    //     0xbf5770: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf5774: ldur            x1, [fp, #-0x10]
    // 0xbf5778: mov             x2, x0
    // 0xbf577c: r0 = onScrollRight=()
    //     0xbf577c: bl              #0xbf58f8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onScrollRight=
    // 0xbf5780: ldur            x1, [fp, #-8]
    // 0xbf5784: r2 = Instance_SemanticsAction
    //     0xbf5784: add             x2, PP, #0x9a, lsl #12  ; [pp+0x9a748] Obj!SemanticsAction@12a08c1
    //     0xbf5788: ldr             x2, [x2, #0x748]
    // 0xbf578c: r0 = _isValidAction()
    //     0xbf578c: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf5790: tbnz            w0, #4, #0xbf57b0
    // 0xbf5794: ldur            x2, [fp, #-8]
    // 0xbf5798: r1 = Function '_performSemanticScrollLeft@37160605':.
    //     0xbf5798: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a750] AnonymousClosure: (0xbf5e60), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollLeft (0xbf5e98)
    //     0xbf579c: ldr             x1, [x1, #0x750]
    // 0xbf57a0: r0 = AllocateClosure()
    //     0xbf57a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf57a4: ldur            x1, [fp, #-0x10]
    // 0xbf57a8: mov             x2, x0
    // 0xbf57ac: r0 = onScrollLeft=()
    //     0xbf57ac: bl              #0xbf58bc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onScrollLeft=
    // 0xbf57b0: ldur            x0, [fp, #-8]
    // 0xbf57b4: LoadField: r1 = r0->field_67
    //     0xbf57b4: ldur            w1, [x0, #0x67]
    // 0xbf57b8: DecompressPointer r1
    //     0xbf57b8: add             x1, x1, HEAP, lsl #32
    // 0xbf57bc: cmp             w1, NULL
    // 0xbf57c0: b.eq            #0xbf5824
    // 0xbf57c4: mov             x1, x0
    // 0xbf57c8: r2 = Instance_SemanticsAction
    //     0xbf57c8: add             x2, PP, #0x9a, lsl #12  ; [pp+0x9a758] Obj!SemanticsAction@12a0881
    //     0xbf57cc: ldr             x2, [x2, #0x758]
    // 0xbf57d0: r0 = _isValidAction()
    //     0xbf57d0: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf57d4: tbnz            w0, #4, #0xbf57f4
    // 0xbf57d8: ldur            x2, [fp, #-8]
    // 0xbf57dc: r1 = Function '_performSemanticScrollUp@37160605':.
    //     0xbf57dc: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a760] AnonymousClosure: (0xbf5ce4), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollUp (0xbf5d1c)
    //     0xbf57e0: ldr             x1, [x1, #0x760]
    // 0xbf57e4: r0 = AllocateClosure()
    //     0xbf57e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf57e8: ldur            x1, [fp, #-0x10]
    // 0xbf57ec: mov             x2, x0
    // 0xbf57f0: r0 = onScrollUp=()
    //     0xbf57f0: bl              #0xbf5880  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onScrollUp=
    // 0xbf57f4: ldur            x1, [fp, #-8]
    // 0xbf57f8: r2 = Instance_SemanticsAction
    //     0xbf57f8: add             x2, PP, #0x9a, lsl #12  ; [pp+0x9a768] Obj!SemanticsAction@12a0861
    //     0xbf57fc: ldr             x2, [x2, #0x768]
    // 0xbf5800: r0 = _isValidAction()
    //     0xbf5800: bl              #0xbf5934  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0xbf5804: tbnz            w0, #4, #0xbf5824
    // 0xbf5808: ldur            x2, [fp, #-8]
    // 0xbf580c: r1 = Function '_performSemanticScrollDown@37160605':.
    //     0xbf580c: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a770] AnonymousClosure: (0xbf597c), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollDown (0xbf59b4)
    //     0xbf5810: ldr             x1, [x1, #0x770]
    // 0xbf5814: r0 = AllocateClosure()
    //     0xbf5814: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf5818: ldur            x1, [fp, #-0x10]
    // 0xbf581c: mov             x2, x0
    // 0xbf5820: r0 = onScrollDown=()
    //     0xbf5820: bl              #0xbf5844  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onScrollDown=
    // 0xbf5824: r0 = Null
    //     0xbf5824: mov             x0, NULL
    // 0xbf5828: LeaveFrame
    //     0xbf5828: mov             SP, fp
    //     0xbf582c: ldp             fp, lr, [SP], #0x10
    // 0xbf5830: ret
    //     0xbf5830: ret             
    // 0xbf5834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5834: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5838: b               #0xbf56b0
    // 0xbf583c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf583c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf5840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf5840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _isValidAction(/* No info */) {
    // ** addr: 0xbf5934, size: 0x48
    // 0xbf5934: EnterFrame
    //     0xbf5934: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5938: mov             fp, SP
    // 0xbf593c: CheckStackOverflow
    //     0xbf593c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5940: cmp             SP, x16
    //     0xbf5944: b.ls            #0xbf5974
    // 0xbf5948: LoadField: r0 = r1->field_57
    //     0xbf5948: ldur            w0, [x1, #0x57]
    // 0xbf594c: DecompressPointer r0
    //     0xbf594c: add             x0, x0, HEAP, lsl #32
    // 0xbf5950: cmp             w0, NULL
    // 0xbf5954: b.ne            #0xbf5960
    // 0xbf5958: r0 = true
    //     0xbf5958: add             x0, NULL, #0x20  ; true
    // 0xbf595c: b               #0xbf5968
    // 0xbf5960: mov             x1, x0
    // 0xbf5964: r0 = contains()
    //     0xbf5964: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xbf5968: LeaveFrame
    //     0xbf5968: mov             SP, fp
    //     0xbf596c: ldp             fp, lr, [SP], #0x10
    // 0xbf5970: ret
    //     0xbf5970: ret             
    // 0xbf5974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5978: b               #0xbf5948
  }
  [closure] void _performSemanticScrollDown(dynamic) {
    // ** addr: 0xbf597c, size: 0x38
    // 0xbf597c: EnterFrame
    //     0xbf597c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5980: mov             fp, SP
    // 0xbf5984: ldr             x0, [fp, #0x10]
    // 0xbf5988: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5988: ldur            w1, [x0, #0x17]
    // 0xbf598c: DecompressPointer r1
    //     0xbf598c: add             x1, x1, HEAP, lsl #32
    // 0xbf5990: CheckStackOverflow
    //     0xbf5990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5994: cmp             SP, x16
    //     0xbf5998: b.ls            #0xbf59ac
    // 0xbf599c: r0 = _performSemanticScrollDown()
    //     0xbf599c: bl              #0xbf59b4  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollDown
    // 0xbf59a0: LeaveFrame
    //     0xbf59a0: mov             SP, fp
    //     0xbf59a4: ldp             fp, lr, [SP], #0x10
    // 0xbf59a8: ret
    //     0xbf59a8: ret             
    // 0xbf59ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf59ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf59b0: b               #0xbf599c
  }
  _ _performSemanticScrollDown(/* No info */) {
    // ** addr: 0xbf59b4, size: 0x144
    // 0xbf59b4: EnterFrame
    //     0xbf59b4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf59b8: mov             fp, SP
    // 0xbf59bc: AllocStack(0x38)
    //     0xbf59bc: sub             SP, SP, #0x38
    // 0xbf59c0: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r0, fp-0x8 */)
    //     0xbf59c0: mov             x0, x1
    //     0xbf59c4: stur            x1, [fp, #-8]
    // 0xbf59c8: CheckStackOverflow
    //     0xbf59c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf59cc: cmp             SP, x16
    //     0xbf59d0: b.ls            #0xbf5ad0
    // 0xbf59d4: LoadField: r1 = r0->field_67
    //     0xbf59d4: ldur            w1, [x0, #0x67]
    // 0xbf59d8: DecompressPointer r1
    //     0xbf59d8: add             x1, x1, HEAP, lsl #32
    // 0xbf59dc: cmp             w1, NULL
    // 0xbf59e0: b.eq            #0xbf5ac0
    // 0xbf59e4: mov             x1, x0
    // 0xbf59e8: r0 = size()
    //     0xbf59e8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf59ec: LoadField: d0 = r0->field_f
    //     0xbf59ec: ldur            d0, [x0, #0xf]
    // 0xbf59f0: d1 = 0.800000
    //     0xbf59f0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xbf59f4: ldr             d1, [x17, #0xa58]
    // 0xbf59f8: fmul            d2, d0, d1
    // 0xbf59fc: ldur            x1, [fp, #-8]
    // 0xbf5a00: stur            d2, [fp, #-0x28]
    // 0xbf5a04: LoadField: r0 = r1->field_67
    //     0xbf5a04: ldur            w0, [x1, #0x67]
    // 0xbf5a08: DecompressPointer r0
    //     0xbf5a08: add             x0, x0, HEAP, lsl #32
    // 0xbf5a0c: stur            x0, [fp, #-0x10]
    // 0xbf5a10: cmp             w0, NULL
    // 0xbf5a14: b.eq            #0xbf5ad8
    // 0xbf5a18: r0 = Offset()
    //     0xbf5a18: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbf5a1c: stur            x0, [fp, #-0x18]
    // 0xbf5a20: StoreField: r0->field_7 = rZR
    //     0xbf5a20: stur            xzr, [x0, #7]
    // 0xbf5a24: ldur            d0, [fp, #-0x28]
    // 0xbf5a28: StoreField: r0->field_f = d0
    //     0xbf5a28: stur            d0, [x0, #0xf]
    // 0xbf5a2c: ldur            x1, [fp, #-8]
    // 0xbf5a30: r0 = size()
    //     0xbf5a30: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf5a34: mov             x1, x0
    // 0xbf5a38: r0 = center()
    //     0xbf5a38: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xbf5a3c: ldur            x1, [fp, #-8]
    // 0xbf5a40: mov             x2, x0
    // 0xbf5a44: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbf5a44: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbf5a48: r0 = localToGlobal()
    //     0xbf5a48: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xbf5a4c: ldur            d0, [fp, #-0x28]
    // 0xbf5a50: stur            x0, [fp, #-0x20]
    // 0xbf5a54: r5 = inline_Allocate_Double()
    //     0xbf5a54: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xbf5a58: add             x5, x5, #0x10
    //     0xbf5a5c: cmp             x1, x5
    //     0xbf5a60: b.ls            #0xbf5adc
    //     0xbf5a64: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf5a68: sub             x5, x5, #0xf
    //     0xbf5a6c: mov             x1, #0xe19c
    //     0xbf5a70: movk            x1, #3, lsl #16
    //     0xbf5a74: stur            x1, [x5, #-1]
    // 0xbf5a78: dmb             ishst
    // 0xbf5a7c: StoreField: r5->field_7 = d0
    //     0xbf5a7c: stur            d0, [x5, #7]
    // 0xbf5a80: stur            x5, [fp, #-8]
    // 0xbf5a84: r0 = DragUpdateDetails()
    //     0xbf5a84: bl              #0xb9e494  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x20)
    // 0xbf5a88: mov             x1, x0
    // 0xbf5a8c: ldur            x2, [fp, #-0x18]
    // 0xbf5a90: ldur            x3, [fp, #-0x20]
    // 0xbf5a94: ldur            x5, [fp, #-8]
    // 0xbf5a98: stur            x0, [fp, #-8]
    // 0xbf5a9c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbf5a9c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbf5aa0: r0 = DragUpdateDetails()
    //     0xbf5aa0: bl              #0xbf5af8  ; [package:flutter/src/gestures/drag_details.dart] DragUpdateDetails::DragUpdateDetails
    // 0xbf5aa4: ldur            x16, [fp, #-0x10]
    // 0xbf5aa8: ldur            lr, [fp, #-8]
    // 0xbf5aac: stp             lr, x16, [SP]
    // 0xbf5ab0: ldur            x0, [fp, #-0x10]
    // 0xbf5ab4: ClosureCall
    //     0xbf5ab4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf5ab8: ldur            x2, [x0, #0x1f]
    //     0xbf5abc: blr             x2
    // 0xbf5ac0: r0 = Null
    //     0xbf5ac0: mov             x0, NULL
    // 0xbf5ac4: LeaveFrame
    //     0xbf5ac4: mov             SP, fp
    //     0xbf5ac8: ldp             fp, lr, [SP], #0x10
    // 0xbf5acc: ret
    //     0xbf5acc: ret             
    // 0xbf5ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5ad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5ad4: b               #0xbf59d4
    // 0xbf5ad8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf5ad8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf5adc: SaveReg d0
    //     0xbf5adc: str             q0, [SP, #-0x10]!
    // 0xbf5ae0: SaveReg r0
    //     0xbf5ae0: str             x0, [SP, #-8]!
    // 0xbf5ae4: r0 = AllocateDouble()
    //     0xbf5ae4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf5ae8: mov             x5, x0
    // 0xbf5aec: RestoreReg r0
    //     0xbf5aec: ldr             x0, [SP], #8
    // 0xbf5af0: RestoreReg d0
    //     0xbf5af0: ldr             q0, [SP], #0x10
    // 0xbf5af4: b               #0xbf5a7c
  }
  [closure] void _performSemanticScrollUp(dynamic) {
    // ** addr: 0xbf5ce4, size: 0x38
    // 0xbf5ce4: EnterFrame
    //     0xbf5ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5ce8: mov             fp, SP
    // 0xbf5cec: ldr             x0, [fp, #0x10]
    // 0xbf5cf0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5cf0: ldur            w1, [x0, #0x17]
    // 0xbf5cf4: DecompressPointer r1
    //     0xbf5cf4: add             x1, x1, HEAP, lsl #32
    // 0xbf5cf8: CheckStackOverflow
    //     0xbf5cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5cfc: cmp             SP, x16
    //     0xbf5d00: b.ls            #0xbf5d14
    // 0xbf5d04: r0 = _performSemanticScrollUp()
    //     0xbf5d04: bl              #0xbf5d1c  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollUp
    // 0xbf5d08: LeaveFrame
    //     0xbf5d08: mov             SP, fp
    //     0xbf5d0c: ldp             fp, lr, [SP], #0x10
    // 0xbf5d10: ret
    //     0xbf5d10: ret             
    // 0xbf5d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5d14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5d18: b               #0xbf5d04
  }
  _ _performSemanticScrollUp(/* No info */) {
    // ** addr: 0xbf5d1c, size: 0x144
    // 0xbf5d1c: EnterFrame
    //     0xbf5d1c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5d20: mov             fp, SP
    // 0xbf5d24: AllocStack(0x38)
    //     0xbf5d24: sub             SP, SP, #0x38
    // 0xbf5d28: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r0, fp-0x8 */)
    //     0xbf5d28: mov             x0, x1
    //     0xbf5d2c: stur            x1, [fp, #-8]
    // 0xbf5d30: CheckStackOverflow
    //     0xbf5d30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5d34: cmp             SP, x16
    //     0xbf5d38: b.ls            #0xbf5e38
    // 0xbf5d3c: LoadField: r1 = r0->field_67
    //     0xbf5d3c: ldur            w1, [x0, #0x67]
    // 0xbf5d40: DecompressPointer r1
    //     0xbf5d40: add             x1, x1, HEAP, lsl #32
    // 0xbf5d44: cmp             w1, NULL
    // 0xbf5d48: b.eq            #0xbf5e28
    // 0xbf5d4c: mov             x1, x0
    // 0xbf5d50: r0 = size()
    //     0xbf5d50: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf5d54: LoadField: d0 = r0->field_f
    //     0xbf5d54: ldur            d0, [x0, #0xf]
    // 0xbf5d58: d1 = -0.800000
    //     0xbf5d58: add             x17, PP, #0x9a, lsl #12  ; [pp+0x9a788] IMM: double(-0.8) from 0xbfe999999999999a
    //     0xbf5d5c: ldr             d1, [x17, #0x788]
    // 0xbf5d60: fmul            d2, d0, d1
    // 0xbf5d64: ldur            x1, [fp, #-8]
    // 0xbf5d68: stur            d2, [fp, #-0x28]
    // 0xbf5d6c: LoadField: r0 = r1->field_67
    //     0xbf5d6c: ldur            w0, [x1, #0x67]
    // 0xbf5d70: DecompressPointer r0
    //     0xbf5d70: add             x0, x0, HEAP, lsl #32
    // 0xbf5d74: stur            x0, [fp, #-0x10]
    // 0xbf5d78: cmp             w0, NULL
    // 0xbf5d7c: b.eq            #0xbf5e40
    // 0xbf5d80: r0 = Offset()
    //     0xbf5d80: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbf5d84: stur            x0, [fp, #-0x18]
    // 0xbf5d88: StoreField: r0->field_7 = rZR
    //     0xbf5d88: stur            xzr, [x0, #7]
    // 0xbf5d8c: ldur            d0, [fp, #-0x28]
    // 0xbf5d90: StoreField: r0->field_f = d0
    //     0xbf5d90: stur            d0, [x0, #0xf]
    // 0xbf5d94: ldur            x1, [fp, #-8]
    // 0xbf5d98: r0 = size()
    //     0xbf5d98: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf5d9c: mov             x1, x0
    // 0xbf5da0: r0 = center()
    //     0xbf5da0: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xbf5da4: ldur            x1, [fp, #-8]
    // 0xbf5da8: mov             x2, x0
    // 0xbf5dac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbf5dac: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbf5db0: r0 = localToGlobal()
    //     0xbf5db0: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xbf5db4: ldur            d0, [fp, #-0x28]
    // 0xbf5db8: stur            x0, [fp, #-0x20]
    // 0xbf5dbc: r5 = inline_Allocate_Double()
    //     0xbf5dbc: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xbf5dc0: add             x5, x5, #0x10
    //     0xbf5dc4: cmp             x1, x5
    //     0xbf5dc8: b.ls            #0xbf5e44
    //     0xbf5dcc: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf5dd0: sub             x5, x5, #0xf
    //     0xbf5dd4: mov             x1, #0xe19c
    //     0xbf5dd8: movk            x1, #3, lsl #16
    //     0xbf5ddc: stur            x1, [x5, #-1]
    // 0xbf5de0: dmb             ishst
    // 0xbf5de4: StoreField: r5->field_7 = d0
    //     0xbf5de4: stur            d0, [x5, #7]
    // 0xbf5de8: stur            x5, [fp, #-8]
    // 0xbf5dec: r0 = DragUpdateDetails()
    //     0xbf5dec: bl              #0xb9e494  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x20)
    // 0xbf5df0: mov             x1, x0
    // 0xbf5df4: ldur            x2, [fp, #-0x18]
    // 0xbf5df8: ldur            x3, [fp, #-0x20]
    // 0xbf5dfc: ldur            x5, [fp, #-8]
    // 0xbf5e00: stur            x0, [fp, #-8]
    // 0xbf5e04: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbf5e04: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbf5e08: r0 = DragUpdateDetails()
    //     0xbf5e08: bl              #0xbf5af8  ; [package:flutter/src/gestures/drag_details.dart] DragUpdateDetails::DragUpdateDetails
    // 0xbf5e0c: ldur            x16, [fp, #-0x10]
    // 0xbf5e10: ldur            lr, [fp, #-8]
    // 0xbf5e14: stp             lr, x16, [SP]
    // 0xbf5e18: ldur            x0, [fp, #-0x10]
    // 0xbf5e1c: ClosureCall
    //     0xbf5e1c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf5e20: ldur            x2, [x0, #0x1f]
    //     0xbf5e24: blr             x2
    // 0xbf5e28: r0 = Null
    //     0xbf5e28: mov             x0, NULL
    // 0xbf5e2c: LeaveFrame
    //     0xbf5e2c: mov             SP, fp
    //     0xbf5e30: ldp             fp, lr, [SP], #0x10
    // 0xbf5e34: ret
    //     0xbf5e34: ret             
    // 0xbf5e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5e3c: b               #0xbf5d3c
    // 0xbf5e40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf5e40: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf5e44: SaveReg d0
    //     0xbf5e44: str             q0, [SP, #-0x10]!
    // 0xbf5e48: SaveReg r0
    //     0xbf5e48: str             x0, [SP, #-8]!
    // 0xbf5e4c: r0 = AllocateDouble()
    //     0xbf5e4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf5e50: mov             x5, x0
    // 0xbf5e54: RestoreReg r0
    //     0xbf5e54: ldr             x0, [SP], #8
    // 0xbf5e58: RestoreReg d0
    //     0xbf5e58: ldr             q0, [SP], #0x10
    // 0xbf5e5c: b               #0xbf5de4
  }
  [closure] void _performSemanticScrollLeft(dynamic) {
    // ** addr: 0xbf5e60, size: 0x38
    // 0xbf5e60: EnterFrame
    //     0xbf5e60: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5e64: mov             fp, SP
    // 0xbf5e68: ldr             x0, [fp, #0x10]
    // 0xbf5e6c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5e6c: ldur            w1, [x0, #0x17]
    // 0xbf5e70: DecompressPointer r1
    //     0xbf5e70: add             x1, x1, HEAP, lsl #32
    // 0xbf5e74: CheckStackOverflow
    //     0xbf5e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5e78: cmp             SP, x16
    //     0xbf5e7c: b.ls            #0xbf5e90
    // 0xbf5e80: r0 = _performSemanticScrollLeft()
    //     0xbf5e80: bl              #0xbf5e98  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollLeft
    // 0xbf5e84: LeaveFrame
    //     0xbf5e84: mov             SP, fp
    //     0xbf5e88: ldp             fp, lr, [SP], #0x10
    // 0xbf5e8c: ret
    //     0xbf5e8c: ret             
    // 0xbf5e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5e90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5e94: b               #0xbf5e80
  }
  _ _performSemanticScrollLeft(/* No info */) {
    // ** addr: 0xbf5e98, size: 0x144
    // 0xbf5e98: EnterFrame
    //     0xbf5e98: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5e9c: mov             fp, SP
    // 0xbf5ea0: AllocStack(0x38)
    //     0xbf5ea0: sub             SP, SP, #0x38
    // 0xbf5ea4: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r0, fp-0x8 */)
    //     0xbf5ea4: mov             x0, x1
    //     0xbf5ea8: stur            x1, [fp, #-8]
    // 0xbf5eac: CheckStackOverflow
    //     0xbf5eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5eb0: cmp             SP, x16
    //     0xbf5eb4: b.ls            #0xbf5fb4
    // 0xbf5eb8: LoadField: r1 = r0->field_63
    //     0xbf5eb8: ldur            w1, [x0, #0x63]
    // 0xbf5ebc: DecompressPointer r1
    //     0xbf5ebc: add             x1, x1, HEAP, lsl #32
    // 0xbf5ec0: cmp             w1, NULL
    // 0xbf5ec4: b.eq            #0xbf5fa4
    // 0xbf5ec8: mov             x1, x0
    // 0xbf5ecc: r0 = size()
    //     0xbf5ecc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf5ed0: LoadField: d0 = r0->field_7
    //     0xbf5ed0: ldur            d0, [x0, #7]
    // 0xbf5ed4: d1 = -0.800000
    //     0xbf5ed4: add             x17, PP, #0x9a, lsl #12  ; [pp+0x9a788] IMM: double(-0.8) from 0xbfe999999999999a
    //     0xbf5ed8: ldr             d1, [x17, #0x788]
    // 0xbf5edc: fmul            d2, d0, d1
    // 0xbf5ee0: ldur            x1, [fp, #-8]
    // 0xbf5ee4: stur            d2, [fp, #-0x28]
    // 0xbf5ee8: LoadField: r0 = r1->field_63
    //     0xbf5ee8: ldur            w0, [x1, #0x63]
    // 0xbf5eec: DecompressPointer r0
    //     0xbf5eec: add             x0, x0, HEAP, lsl #32
    // 0xbf5ef0: stur            x0, [fp, #-0x10]
    // 0xbf5ef4: cmp             w0, NULL
    // 0xbf5ef8: b.eq            #0xbf5fbc
    // 0xbf5efc: r0 = Offset()
    //     0xbf5efc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbf5f00: ldur            d0, [fp, #-0x28]
    // 0xbf5f04: stur            x0, [fp, #-0x18]
    // 0xbf5f08: StoreField: r0->field_7 = d0
    //     0xbf5f08: stur            d0, [x0, #7]
    // 0xbf5f0c: StoreField: r0->field_f = rZR
    //     0xbf5f0c: stur            xzr, [x0, #0xf]
    // 0xbf5f10: ldur            x1, [fp, #-8]
    // 0xbf5f14: r0 = size()
    //     0xbf5f14: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf5f18: mov             x1, x0
    // 0xbf5f1c: r0 = center()
    //     0xbf5f1c: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xbf5f20: ldur            x1, [fp, #-8]
    // 0xbf5f24: mov             x2, x0
    // 0xbf5f28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbf5f28: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbf5f2c: r0 = localToGlobal()
    //     0xbf5f2c: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xbf5f30: ldur            d0, [fp, #-0x28]
    // 0xbf5f34: stur            x0, [fp, #-0x20]
    // 0xbf5f38: r5 = inline_Allocate_Double()
    //     0xbf5f38: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xbf5f3c: add             x5, x5, #0x10
    //     0xbf5f40: cmp             x1, x5
    //     0xbf5f44: b.ls            #0xbf5fc0
    //     0xbf5f48: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf5f4c: sub             x5, x5, #0xf
    //     0xbf5f50: mov             x1, #0xe19c
    //     0xbf5f54: movk            x1, #3, lsl #16
    //     0xbf5f58: stur            x1, [x5, #-1]
    // 0xbf5f5c: dmb             ishst
    // 0xbf5f60: StoreField: r5->field_7 = d0
    //     0xbf5f60: stur            d0, [x5, #7]
    // 0xbf5f64: stur            x5, [fp, #-8]
    // 0xbf5f68: r0 = DragUpdateDetails()
    //     0xbf5f68: bl              #0xb9e494  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x20)
    // 0xbf5f6c: mov             x1, x0
    // 0xbf5f70: ldur            x2, [fp, #-0x18]
    // 0xbf5f74: ldur            x3, [fp, #-0x20]
    // 0xbf5f78: ldur            x5, [fp, #-8]
    // 0xbf5f7c: stur            x0, [fp, #-8]
    // 0xbf5f80: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbf5f80: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbf5f84: r0 = DragUpdateDetails()
    //     0xbf5f84: bl              #0xbf5af8  ; [package:flutter/src/gestures/drag_details.dart] DragUpdateDetails::DragUpdateDetails
    // 0xbf5f88: ldur            x16, [fp, #-0x10]
    // 0xbf5f8c: ldur            lr, [fp, #-8]
    // 0xbf5f90: stp             lr, x16, [SP]
    // 0xbf5f94: ldur            x0, [fp, #-0x10]
    // 0xbf5f98: ClosureCall
    //     0xbf5f98: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf5f9c: ldur            x2, [x0, #0x1f]
    //     0xbf5fa0: blr             x2
    // 0xbf5fa4: r0 = Null
    //     0xbf5fa4: mov             x0, NULL
    // 0xbf5fa8: LeaveFrame
    //     0xbf5fa8: mov             SP, fp
    //     0xbf5fac: ldp             fp, lr, [SP], #0x10
    // 0xbf5fb0: ret
    //     0xbf5fb0: ret             
    // 0xbf5fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5fb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5fb8: b               #0xbf5eb8
    // 0xbf5fbc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf5fbc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf5fc0: SaveReg d0
    //     0xbf5fc0: str             q0, [SP, #-0x10]!
    // 0xbf5fc4: SaveReg r0
    //     0xbf5fc4: str             x0, [SP, #-8]!
    // 0xbf5fc8: r0 = AllocateDouble()
    //     0xbf5fc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf5fcc: mov             x5, x0
    // 0xbf5fd0: RestoreReg r0
    //     0xbf5fd0: ldr             x0, [SP], #8
    // 0xbf5fd4: RestoreReg d0
    //     0xbf5fd4: ldr             q0, [SP], #0x10
    // 0xbf5fd8: b               #0xbf5f60
  }
  [closure] void _performSemanticScrollRight(dynamic) {
    // ** addr: 0xbf5fdc, size: 0x38
    // 0xbf5fdc: EnterFrame
    //     0xbf5fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5fe0: mov             fp, SP
    // 0xbf5fe4: ldr             x0, [fp, #0x10]
    // 0xbf5fe8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5fe8: ldur            w1, [x0, #0x17]
    // 0xbf5fec: DecompressPointer r1
    //     0xbf5fec: add             x1, x1, HEAP, lsl #32
    // 0xbf5ff0: CheckStackOverflow
    //     0xbf5ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5ff4: cmp             SP, x16
    //     0xbf5ff8: b.ls            #0xbf600c
    // 0xbf5ffc: r0 = _performSemanticScrollRight()
    //     0xbf5ffc: bl              #0xbf6014  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollRight
    // 0xbf6000: LeaveFrame
    //     0xbf6000: mov             SP, fp
    //     0xbf6004: ldp             fp, lr, [SP], #0x10
    // 0xbf6008: ret
    //     0xbf6008: ret             
    // 0xbf600c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf600c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf6010: b               #0xbf5ffc
  }
  _ _performSemanticScrollRight(/* No info */) {
    // ** addr: 0xbf6014, size: 0x144
    // 0xbf6014: EnterFrame
    //     0xbf6014: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6018: mov             fp, SP
    // 0xbf601c: AllocStack(0x38)
    //     0xbf601c: sub             SP, SP, #0x38
    // 0xbf6020: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r0, fp-0x8 */)
    //     0xbf6020: mov             x0, x1
    //     0xbf6024: stur            x1, [fp, #-8]
    // 0xbf6028: CheckStackOverflow
    //     0xbf6028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf602c: cmp             SP, x16
    //     0xbf6030: b.ls            #0xbf6130
    // 0xbf6034: LoadField: r1 = r0->field_63
    //     0xbf6034: ldur            w1, [x0, #0x63]
    // 0xbf6038: DecompressPointer r1
    //     0xbf6038: add             x1, x1, HEAP, lsl #32
    // 0xbf603c: cmp             w1, NULL
    // 0xbf6040: b.eq            #0xbf6120
    // 0xbf6044: mov             x1, x0
    // 0xbf6048: r0 = size()
    //     0xbf6048: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf604c: LoadField: d0 = r0->field_7
    //     0xbf604c: ldur            d0, [x0, #7]
    // 0xbf6050: d1 = 0.800000
    //     0xbf6050: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xbf6054: ldr             d1, [x17, #0xa58]
    // 0xbf6058: fmul            d2, d0, d1
    // 0xbf605c: ldur            x1, [fp, #-8]
    // 0xbf6060: stur            d2, [fp, #-0x28]
    // 0xbf6064: LoadField: r0 = r1->field_63
    //     0xbf6064: ldur            w0, [x1, #0x63]
    // 0xbf6068: DecompressPointer r0
    //     0xbf6068: add             x0, x0, HEAP, lsl #32
    // 0xbf606c: stur            x0, [fp, #-0x10]
    // 0xbf6070: cmp             w0, NULL
    // 0xbf6074: b.eq            #0xbf6138
    // 0xbf6078: r0 = Offset()
    //     0xbf6078: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbf607c: ldur            d0, [fp, #-0x28]
    // 0xbf6080: stur            x0, [fp, #-0x18]
    // 0xbf6084: StoreField: r0->field_7 = d0
    //     0xbf6084: stur            d0, [x0, #7]
    // 0xbf6088: StoreField: r0->field_f = rZR
    //     0xbf6088: stur            xzr, [x0, #0xf]
    // 0xbf608c: ldur            x1, [fp, #-8]
    // 0xbf6090: r0 = size()
    //     0xbf6090: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf6094: mov             x1, x0
    // 0xbf6098: r0 = center()
    //     0xbf6098: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xbf609c: ldur            x1, [fp, #-8]
    // 0xbf60a0: mov             x2, x0
    // 0xbf60a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbf60a4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbf60a8: r0 = localToGlobal()
    //     0xbf60a8: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xbf60ac: ldur            d0, [fp, #-0x28]
    // 0xbf60b0: stur            x0, [fp, #-0x20]
    // 0xbf60b4: r5 = inline_Allocate_Double()
    //     0xbf60b4: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xbf60b8: add             x5, x5, #0x10
    //     0xbf60bc: cmp             x1, x5
    //     0xbf60c0: b.ls            #0xbf613c
    //     0xbf60c4: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf60c8: sub             x5, x5, #0xf
    //     0xbf60cc: mov             x1, #0xe19c
    //     0xbf60d0: movk            x1, #3, lsl #16
    //     0xbf60d4: stur            x1, [x5, #-1]
    // 0xbf60d8: dmb             ishst
    // 0xbf60dc: StoreField: r5->field_7 = d0
    //     0xbf60dc: stur            d0, [x5, #7]
    // 0xbf60e0: stur            x5, [fp, #-8]
    // 0xbf60e4: r0 = DragUpdateDetails()
    //     0xbf60e4: bl              #0xb9e494  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x20)
    // 0xbf60e8: mov             x1, x0
    // 0xbf60ec: ldur            x2, [fp, #-0x18]
    // 0xbf60f0: ldur            x3, [fp, #-0x20]
    // 0xbf60f4: ldur            x5, [fp, #-8]
    // 0xbf60f8: stur            x0, [fp, #-8]
    // 0xbf60fc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbf60fc: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbf6100: r0 = DragUpdateDetails()
    //     0xbf6100: bl              #0xbf5af8  ; [package:flutter/src/gestures/drag_details.dart] DragUpdateDetails::DragUpdateDetails
    // 0xbf6104: ldur            x16, [fp, #-0x10]
    // 0xbf6108: ldur            lr, [fp, #-8]
    // 0xbf610c: stp             lr, x16, [SP]
    // 0xbf6110: ldur            x0, [fp, #-0x10]
    // 0xbf6114: ClosureCall
    //     0xbf6114: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf6118: ldur            x2, [x0, #0x1f]
    //     0xbf611c: blr             x2
    // 0xbf6120: r0 = Null
    //     0xbf6120: mov             x0, NULL
    // 0xbf6124: LeaveFrame
    //     0xbf6124: mov             SP, fp
    //     0xbf6128: ldp             fp, lr, [SP], #0x10
    // 0xbf612c: ret
    //     0xbf612c: ret             
    // 0xbf6130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf6130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf6134: b               #0xbf6034
    // 0xbf6138: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf6138: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf613c: SaveReg d0
    //     0xbf613c: str             q0, [SP, #-0x10]!
    // 0xbf6140: SaveReg r0
    //     0xbf6140: str             x0, [SP, #-8]!
    // 0xbf6144: r0 = AllocateDouble()
    //     0xbf6144: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf6148: mov             x5, x0
    // 0xbf614c: RestoreReg r0
    //     0xbf614c: ldr             x0, [SP], #8
    // 0xbf6150: RestoreReg d0
    //     0xbf6150: ldr             q0, [SP], #0x10
    // 0xbf6154: b               #0xbf60dc
  }
  set _ onVerticalDragUpdate=(/* No info */) {
    // ** addr: 0xcfa568, size: 0xdc
    // 0xcfa568: EnterFrame
    //     0xcfa568: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa56c: mov             fp, SP
    // 0xcfa570: AllocStack(0x20)
    //     0xcfa570: sub             SP, SP, #0x20
    // 0xcfa574: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcfa574: stur            x1, [fp, #-8]
    //     0xcfa578: mov             x16, x2
    //     0xcfa57c: mov             x2, x1
    //     0xcfa580: mov             x1, x16
    //     0xcfa584: stur            x1, [fp, #-0x10]
    // 0xcfa588: CheckStackOverflow
    //     0xcfa588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfa58c: cmp             SP, x16
    //     0xcfa590: b.ls            #0xcfa63c
    // 0xcfa594: LoadField: r0 = r2->field_67
    //     0xcfa594: ldur            w0, [x2, #0x67]
    // 0xcfa598: DecompressPointer r0
    //     0xcfa598: add             x0, x0, HEAP, lsl #32
    // 0xcfa59c: r3 = LoadClassIdInstr(r0)
    //     0xcfa59c: ldur            x3, [x0, #-1]
    //     0xcfa5a0: ubfx            x3, x3, #0xc, #0x14
    // 0xcfa5a4: stp             x1, x0, [SP]
    // 0xcfa5a8: mov             x0, x3
    // 0xcfa5ac: mov             lr, x0
    // 0xcfa5b0: ldr             lr, [x21, lr, lsl #3]
    // 0xcfa5b4: blr             lr
    // 0xcfa5b8: tbnz            w0, #4, #0xcfa5cc
    // 0xcfa5bc: r0 = Null
    //     0xcfa5bc: mov             x0, NULL
    // 0xcfa5c0: LeaveFrame
    //     0xcfa5c0: mov             SP, fp
    //     0xcfa5c4: ldp             fp, lr, [SP], #0x10
    // 0xcfa5c8: ret
    //     0xcfa5c8: ret             
    // 0xcfa5cc: ldur            x2, [fp, #-8]
    // 0xcfa5d0: ldur            x1, [fp, #-0x10]
    // 0xcfa5d4: LoadField: r0 = r2->field_67
    //     0xcfa5d4: ldur            w0, [x2, #0x67]
    // 0xcfa5d8: DecompressPointer r0
    //     0xcfa5d8: add             x0, x0, HEAP, lsl #32
    // 0xcfa5dc: cmp             w0, NULL
    // 0xcfa5e0: r16 = true
    //     0xcfa5e0: add             x16, NULL, #0x20  ; true
    // 0xcfa5e4: r17 = false
    //     0xcfa5e4: add             x17, NULL, #0x30  ; false
    // 0xcfa5e8: csel            x3, x16, x17, ne
    // 0xcfa5ec: mov             x0, x1
    // 0xcfa5f0: StoreField: r2->field_67 = r0
    //     0xcfa5f0: stur            w0, [x2, #0x67]
    //     0xcfa5f4: ldurb           w16, [x2, #-1]
    //     0xcfa5f8: ldurb           w17, [x0, #-1]
    //     0xcfa5fc: and             x16, x17, x16, lsr #2
    //     0xcfa600: tst             x16, HEAP, lsr #32
    //     0xcfa604: b.eq            #0xcfa60c
    //     0xcfa608: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcfa60c: cmp             w1, NULL
    // 0xcfa610: r16 = true
    //     0xcfa610: add             x16, NULL, #0x20  ; true
    // 0xcfa614: r17 = false
    //     0xcfa614: add             x17, NULL, #0x30  ; false
    // 0xcfa618: csel            x0, x16, x17, ne
    // 0xcfa61c: cmp             w0, w3
    // 0xcfa620: b.eq            #0xcfa62c
    // 0xcfa624: mov             x1, x2
    // 0xcfa628: r0 = markNeedsSemanticsUpdate()
    //     0xcfa628: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcfa62c: r0 = Null
    //     0xcfa62c: mov             x0, NULL
    // 0xcfa630: LeaveFrame
    //     0xcfa630: mov             SP, fp
    //     0xcfa634: ldp             fp, lr, [SP], #0x10
    // 0xcfa638: ret
    //     0xcfa638: ret             
    // 0xcfa63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa640: b               #0xcfa594
  }
  set _ onHorizontalDragUpdate=(/* No info */) {
    // ** addr: 0xcfad8c, size: 0xdc
    // 0xcfad8c: EnterFrame
    //     0xcfad8c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfad90: mov             fp, SP
    // 0xcfad94: AllocStack(0x20)
    //     0xcfad94: sub             SP, SP, #0x20
    // 0xcfad98: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcfad98: stur            x1, [fp, #-8]
    //     0xcfad9c: mov             x16, x2
    //     0xcfada0: mov             x2, x1
    //     0xcfada4: mov             x1, x16
    //     0xcfada8: stur            x1, [fp, #-0x10]
    // 0xcfadac: CheckStackOverflow
    //     0xcfadac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfadb0: cmp             SP, x16
    //     0xcfadb4: b.ls            #0xcfae60
    // 0xcfadb8: LoadField: r0 = r2->field_63
    //     0xcfadb8: ldur            w0, [x2, #0x63]
    // 0xcfadbc: DecompressPointer r0
    //     0xcfadbc: add             x0, x0, HEAP, lsl #32
    // 0xcfadc0: r3 = LoadClassIdInstr(r0)
    //     0xcfadc0: ldur            x3, [x0, #-1]
    //     0xcfadc4: ubfx            x3, x3, #0xc, #0x14
    // 0xcfadc8: stp             x1, x0, [SP]
    // 0xcfadcc: mov             x0, x3
    // 0xcfadd0: mov             lr, x0
    // 0xcfadd4: ldr             lr, [x21, lr, lsl #3]
    // 0xcfadd8: blr             lr
    // 0xcfaddc: tbnz            w0, #4, #0xcfadf0
    // 0xcfade0: r0 = Null
    //     0xcfade0: mov             x0, NULL
    // 0xcfade4: LeaveFrame
    //     0xcfade4: mov             SP, fp
    //     0xcfade8: ldp             fp, lr, [SP], #0x10
    // 0xcfadec: ret
    //     0xcfadec: ret             
    // 0xcfadf0: ldur            x2, [fp, #-8]
    // 0xcfadf4: ldur            x1, [fp, #-0x10]
    // 0xcfadf8: LoadField: r0 = r2->field_63
    //     0xcfadf8: ldur            w0, [x2, #0x63]
    // 0xcfadfc: DecompressPointer r0
    //     0xcfadfc: add             x0, x0, HEAP, lsl #32
    // 0xcfae00: cmp             w0, NULL
    // 0xcfae04: r16 = true
    //     0xcfae04: add             x16, NULL, #0x20  ; true
    // 0xcfae08: r17 = false
    //     0xcfae08: add             x17, NULL, #0x30  ; false
    // 0xcfae0c: csel            x3, x16, x17, ne
    // 0xcfae10: mov             x0, x1
    // 0xcfae14: StoreField: r2->field_63 = r0
    //     0xcfae14: stur            w0, [x2, #0x63]
    //     0xcfae18: ldurb           w16, [x2, #-1]
    //     0xcfae1c: ldurb           w17, [x0, #-1]
    //     0xcfae20: and             x16, x17, x16, lsr #2
    //     0xcfae24: tst             x16, HEAP, lsr #32
    //     0xcfae28: b.eq            #0xcfae30
    //     0xcfae2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcfae30: cmp             w1, NULL
    // 0xcfae34: r16 = true
    //     0xcfae34: add             x16, NULL, #0x20  ; true
    // 0xcfae38: r17 = false
    //     0xcfae38: add             x17, NULL, #0x30  ; false
    // 0xcfae3c: csel            x0, x16, x17, ne
    // 0xcfae40: cmp             w0, w3
    // 0xcfae44: b.eq            #0xcfae50
    // 0xcfae48: mov             x1, x2
    // 0xcfae4c: r0 = markNeedsSemanticsUpdate()
    //     0xcfae4c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcfae50: r0 = Null
    //     0xcfae50: mov             x0, NULL
    // 0xcfae54: LeaveFrame
    //     0xcfae54: mov             SP, fp
    //     0xcfae58: ldp             fp, lr, [SP], #0x10
    // 0xcfae5c: ret
    //     0xcfae5c: ret             
    // 0xcfae60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfae60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfae64: b               #0xcfadb8
  }
  set _ onLongPress=(/* No info */) {
    // ** addr: 0xcfb0a0, size: 0xdc
    // 0xcfb0a0: EnterFrame
    //     0xcfb0a0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb0a4: mov             fp, SP
    // 0xcfb0a8: AllocStack(0x20)
    //     0xcfb0a8: sub             SP, SP, #0x20
    // 0xcfb0ac: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcfb0ac: stur            x1, [fp, #-8]
    //     0xcfb0b0: mov             x16, x2
    //     0xcfb0b4: mov             x2, x1
    //     0xcfb0b8: mov             x1, x16
    //     0xcfb0bc: stur            x1, [fp, #-0x10]
    // 0xcfb0c0: CheckStackOverflow
    //     0xcfb0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfb0c4: cmp             SP, x16
    //     0xcfb0c8: b.ls            #0xcfb174
    // 0xcfb0cc: LoadField: r0 = r2->field_5f
    //     0xcfb0cc: ldur            w0, [x2, #0x5f]
    // 0xcfb0d0: DecompressPointer r0
    //     0xcfb0d0: add             x0, x0, HEAP, lsl #32
    // 0xcfb0d4: r3 = LoadClassIdInstr(r0)
    //     0xcfb0d4: ldur            x3, [x0, #-1]
    //     0xcfb0d8: ubfx            x3, x3, #0xc, #0x14
    // 0xcfb0dc: stp             x1, x0, [SP]
    // 0xcfb0e0: mov             x0, x3
    // 0xcfb0e4: mov             lr, x0
    // 0xcfb0e8: ldr             lr, [x21, lr, lsl #3]
    // 0xcfb0ec: blr             lr
    // 0xcfb0f0: tbnz            w0, #4, #0xcfb104
    // 0xcfb0f4: r0 = Null
    //     0xcfb0f4: mov             x0, NULL
    // 0xcfb0f8: LeaveFrame
    //     0xcfb0f8: mov             SP, fp
    //     0xcfb0fc: ldp             fp, lr, [SP], #0x10
    // 0xcfb100: ret
    //     0xcfb100: ret             
    // 0xcfb104: ldur            x2, [fp, #-8]
    // 0xcfb108: ldur            x1, [fp, #-0x10]
    // 0xcfb10c: LoadField: r0 = r2->field_5f
    //     0xcfb10c: ldur            w0, [x2, #0x5f]
    // 0xcfb110: DecompressPointer r0
    //     0xcfb110: add             x0, x0, HEAP, lsl #32
    // 0xcfb114: cmp             w0, NULL
    // 0xcfb118: r16 = true
    //     0xcfb118: add             x16, NULL, #0x20  ; true
    // 0xcfb11c: r17 = false
    //     0xcfb11c: add             x17, NULL, #0x30  ; false
    // 0xcfb120: csel            x3, x16, x17, ne
    // 0xcfb124: mov             x0, x1
    // 0xcfb128: StoreField: r2->field_5f = r0
    //     0xcfb128: stur            w0, [x2, #0x5f]
    //     0xcfb12c: ldurb           w16, [x2, #-1]
    //     0xcfb130: ldurb           w17, [x0, #-1]
    //     0xcfb134: and             x16, x17, x16, lsr #2
    //     0xcfb138: tst             x16, HEAP, lsr #32
    //     0xcfb13c: b.eq            #0xcfb144
    //     0xcfb140: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcfb144: cmp             w1, NULL
    // 0xcfb148: r16 = true
    //     0xcfb148: add             x16, NULL, #0x20  ; true
    // 0xcfb14c: r17 = false
    //     0xcfb14c: add             x17, NULL, #0x30  ; false
    // 0xcfb150: csel            x0, x16, x17, ne
    // 0xcfb154: cmp             w0, w3
    // 0xcfb158: b.eq            #0xcfb164
    // 0xcfb15c: mov             x1, x2
    // 0xcfb160: r0 = markNeedsSemanticsUpdate()
    //     0xcfb160: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcfb164: r0 = Null
    //     0xcfb164: mov             x0, NULL
    // 0xcfb168: LeaveFrame
    //     0xcfb168: mov             SP, fp
    //     0xcfb16c: ldp             fp, lr, [SP], #0x10
    // 0xcfb170: ret
    //     0xcfb170: ret             
    // 0xcfb174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfb174: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfb178: b               #0xcfb0cc
  }
  set _ onTap=(/* No info */) {
    // ** addr: 0xcfbce4, size: 0xdc
    // 0xcfbce4: EnterFrame
    //     0xcfbce4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfbce8: mov             fp, SP
    // 0xcfbcec: AllocStack(0x20)
    //     0xcfbcec: sub             SP, SP, #0x20
    // 0xcfbcf0: SetupParameters(RenderSemanticsGestureHandler this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcfbcf0: stur            x1, [fp, #-8]
    //     0xcfbcf4: mov             x16, x2
    //     0xcfbcf8: mov             x2, x1
    //     0xcfbcfc: mov             x1, x16
    //     0xcfbd00: stur            x1, [fp, #-0x10]
    // 0xcfbd04: CheckStackOverflow
    //     0xcfbd04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfbd08: cmp             SP, x16
    //     0xcfbd0c: b.ls            #0xcfbdb8
    // 0xcfbd10: LoadField: r0 = r2->field_5b
    //     0xcfbd10: ldur            w0, [x2, #0x5b]
    // 0xcfbd14: DecompressPointer r0
    //     0xcfbd14: add             x0, x0, HEAP, lsl #32
    // 0xcfbd18: r3 = LoadClassIdInstr(r0)
    //     0xcfbd18: ldur            x3, [x0, #-1]
    //     0xcfbd1c: ubfx            x3, x3, #0xc, #0x14
    // 0xcfbd20: stp             x1, x0, [SP]
    // 0xcfbd24: mov             x0, x3
    // 0xcfbd28: mov             lr, x0
    // 0xcfbd2c: ldr             lr, [x21, lr, lsl #3]
    // 0xcfbd30: blr             lr
    // 0xcfbd34: tbnz            w0, #4, #0xcfbd48
    // 0xcfbd38: r0 = Null
    //     0xcfbd38: mov             x0, NULL
    // 0xcfbd3c: LeaveFrame
    //     0xcfbd3c: mov             SP, fp
    //     0xcfbd40: ldp             fp, lr, [SP], #0x10
    // 0xcfbd44: ret
    //     0xcfbd44: ret             
    // 0xcfbd48: ldur            x2, [fp, #-8]
    // 0xcfbd4c: ldur            x1, [fp, #-0x10]
    // 0xcfbd50: LoadField: r0 = r2->field_5b
    //     0xcfbd50: ldur            w0, [x2, #0x5b]
    // 0xcfbd54: DecompressPointer r0
    //     0xcfbd54: add             x0, x0, HEAP, lsl #32
    // 0xcfbd58: cmp             w0, NULL
    // 0xcfbd5c: r16 = true
    //     0xcfbd5c: add             x16, NULL, #0x20  ; true
    // 0xcfbd60: r17 = false
    //     0xcfbd60: add             x17, NULL, #0x30  ; false
    // 0xcfbd64: csel            x3, x16, x17, ne
    // 0xcfbd68: mov             x0, x1
    // 0xcfbd6c: StoreField: r2->field_5b = r0
    //     0xcfbd6c: stur            w0, [x2, #0x5b]
    //     0xcfbd70: ldurb           w16, [x2, #-1]
    //     0xcfbd74: ldurb           w17, [x0, #-1]
    //     0xcfbd78: and             x16, x17, x16, lsr #2
    //     0xcfbd7c: tst             x16, HEAP, lsr #32
    //     0xcfbd80: b.eq            #0xcfbd88
    //     0xcfbd84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcfbd88: cmp             w1, NULL
    // 0xcfbd8c: r16 = true
    //     0xcfbd8c: add             x16, NULL, #0x20  ; true
    // 0xcfbd90: r17 = false
    //     0xcfbd90: add             x17, NULL, #0x30  ; false
    // 0xcfbd94: csel            x0, x16, x17, ne
    // 0xcfbd98: cmp             w0, w3
    // 0xcfbd9c: b.eq            #0xcfbda8
    // 0xcfbda0: mov             x1, x2
    // 0xcfbda4: r0 = markNeedsSemanticsUpdate()
    //     0xcfbda4: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcfbda8: r0 = Null
    //     0xcfbda8: mov             x0, NULL
    // 0xcfbdac: LeaveFrame
    //     0xcfbdac: mov             SP, fp
    //     0xcfbdb0: ldp             fp, lr, [SP], #0x10
    // 0xcfbdb4: ret
    //     0xcfbdb4: ret             
    // 0xcfbdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfbdb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfbdbc: b               #0xcfbd10
  }
  _ RenderSemanticsGestureHandler(/* No info */) {
    // ** addr: 0x11d2e44, size: 0x50
    // 0x11d2e44: EnterFrame
    //     0x11d2e44: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2e48: mov             fp, SP
    // 0x11d2e4c: AllocStack(0x8)
    //     0x11d2e4c: sub             SP, SP, #8
    // 0x11d2e50: d0 = 0.800000
    //     0x11d2e50: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0x11d2e54: ldr             d0, [x17, #0xa58]
    // 0x11d2e58: CheckStackOverflow
    //     0x11d2e58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2e5c: cmp             SP, x16
    //     0x11d2e60: b.ls            #0x11d2e8c
    // 0x11d2e64: StoreField: r1->field_6b = d0
    //     0x11d2e64: stur            d0, [x1, #0x6b]
    // 0x11d2e68: r16 = Instance_HitTestBehavior
    //     0x11d2e68: ldr             x16, [PP, #0x5368]  ; [pp+0x5368] Obj!HitTestBehavior@12c43a1
    // 0x11d2e6c: str             x16, [SP]
    // 0x11d2e70: r4 = const [0, 0x2, 0x1, 0x1, behavior, 0x1, null]
    //     0x11d2e70: add             x4, PP, #0x12, lsl #12  ; [pp+0x123b8] List(7) [0, 0x2, 0x1, 0x1, "behavior", 0x1, Null]
    //     0x11d2e74: ldr             x4, [x4, #0x3b8]
    // 0x11d2e78: r0 = RenderProxyBoxWithHitTestBehavior()
    //     0x11d2e78: bl              #0x11d2340  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::RenderProxyBoxWithHitTestBehavior
    // 0x11d2e7c: r0 = Null
    //     0x11d2e7c: mov             x0, NULL
    // 0x11d2e80: LeaveFrame
    //     0x11d2e80: mov             SP, fp
    //     0x11d2e84: ldp             fp, lr, [SP], #0x10
    // 0x11d2e88: ret
    //     0x11d2e88: ret             
    // 0x11d2e8c: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d2e8c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d2e90: b               #0x11d2e64
  }
}

// class id: 4952, size: 0x5c, field offset: 0x58
class RenderMetaData extends RenderProxyBoxWithHitTestBehavior {
}

// class id: 4953, size: 0x70, field offset: 0x58
class RenderMouseRegion extends RenderProxyBoxWithHitTestBehavior
    implements MouseTrackerAnnotation {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf81b8, size: 0x3c
    // 0xaf81b8: EnterFrame
    //     0xaf81b8: stp             fp, lr, [SP, #-0x10]!
    //     0xaf81bc: mov             fp, SP
    // 0xaf81c0: CheckStackOverflow
    //     0xaf81c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf81c4: cmp             SP, x16
    //     0xaf81c8: b.ls            #0xaf81ec
    // 0xaf81cc: r0 = hitTest()
    //     0xaf81cc: bl              #0xaf82ec  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::hitTest
    // 0xaf81d0: tbnz            w0, #4, #0xaf81dc
    // 0xaf81d4: r0 = true
    //     0xaf81d4: add             x0, NULL, #0x20  ; true
    // 0xaf81d8: b               #0xaf81e0
    // 0xaf81dc: r0 = false
    //     0xaf81dc: add             x0, NULL, #0x30  ; false
    // 0xaf81e0: LeaveFrame
    //     0xaf81e0: mov             SP, fp
    //     0xaf81e4: ldp             fp, lr, [SP], #0x10
    // 0xaf81e8: ret
    //     0xaf81e8: ret             
    // 0xaf81ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf81ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf81f0: b               #0xaf81cc
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05c2c, size: 0x38
    // 0xc05c2c: EnterFrame
    //     0xc05c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc05c30: mov             fp, SP
    // 0xc05c34: r0 = false
    //     0xc05c34: add             x0, NULL, #0x30  ; false
    // 0xc05c38: CheckStackOverflow
    //     0xc05c38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05c3c: cmp             SP, x16
    //     0xc05c40: b.ls            #0xc05c5c
    // 0xc05c44: StoreField: r1->field_6b = r0
    //     0xc05c44: stur            w0, [x1, #0x6b]
    // 0xc05c48: r0 = detach()
    //     0xc05c48: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc05c4c: r0 = Null
    //     0xc05c4c: mov             x0, NULL
    // 0xc05c50: LeaveFrame
    //     0xc05c50: mov             SP, fp
    //     0xc05c54: ldp             fp, lr, [SP], #0x10
    // 0xc05c58: ret
    //     0xc05c58: ret             
    // 0xc05c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05c5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05c60: b               #0xc05c44
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0975c, size: 0x4c
    // 0xc0975c: EnterFrame
    //     0xc0975c: stp             fp, lr, [SP, #-0x10]!
    //     0xc09760: mov             fp, SP
    // 0xc09764: AllocStack(0x8)
    //     0xc09764: sub             SP, SP, #8
    // 0xc09768: SetupParameters(RenderMouseRegion this /* r1 => r0, fp-0x8 */)
    //     0xc09768: mov             x0, x1
    //     0xc0976c: stur            x1, [fp, #-8]
    // 0xc09770: CheckStackOverflow
    //     0xc09770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09774: cmp             SP, x16
    //     0xc09778: b.ls            #0xc097a0
    // 0xc0977c: mov             x1, x0
    // 0xc09780: r0 = attach()
    //     0xc09780: bl              #0xc09a60  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::attach
    // 0xc09784: ldur            x2, [fp, #-8]
    // 0xc09788: r1 = true
    //     0xc09788: add             x1, NULL, #0x20  ; true
    // 0xc0978c: StoreField: r2->field_6b = r1
    //     0xc0978c: stur            w1, [x2, #0x6b]
    // 0xc09790: r0 = Null
    //     0xc09790: mov             x0, NULL
    // 0xc09794: LeaveFrame
    //     0xc09794: mov             SP, fp
    //     0xc09798: ldp             fp, lr, [SP], #0x10
    // 0xc0979c: ret
    //     0xc0979c: ret             
    // 0xc097a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc097a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc097a4: b               #0xc0977c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcd0e2c, size: 0xf0
    // 0xcd0e2c: EnterFrame
    //     0xcd0e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0e30: mov             fp, SP
    // 0xcd0e34: AllocStack(0x20)
    //     0xcd0e34: sub             SP, SP, #0x20
    // 0xcd0e38: SetupParameters(RenderMouseRegion this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0 */)
    //     0xcd0e38: mov             x4, x1
    //     0xcd0e3c: mov             x0, x3
    //     0xcd0e40: mov             x3, x2
    //     0xcd0e44: stur            x1, [fp, #-8]
    //     0xcd0e48: stur            x2, [fp, #-0x10]
    // 0xcd0e4c: CheckStackOverflow
    //     0xcd0e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0e50: cmp             SP, x16
    //     0xcd0e54: b.ls            #0xcd0f14
    // 0xcd0e58: r2 = Null
    //     0xcd0e58: mov             x2, NULL
    // 0xcd0e5c: r1 = Null
    //     0xcd0e5c: mov             x1, NULL
    // 0xcd0e60: r4 = 60
    //     0xcd0e60: mov             x4, #0x3c
    // 0xcd0e64: branchIfSmi(r0, 0xcd0e70)
    //     0xcd0e64: tbz             w0, #0, #0xcd0e70
    // 0xcd0e68: r4 = LoadClassIdInstr(r0)
    //     0xcd0e68: ldur            x4, [x0, #-1]
    //     0xcd0e6c: ubfx            x4, x4, #0xc, #0x14
    // 0xcd0e70: sub             x4, x4, #0xc63
    // 0xcd0e74: cmp             x4, #2
    // 0xcd0e78: b.ls            #0xcd0e90
    // 0xcd0e7c: r8 = HitTestEntry<HitTestTarget>
    //     0xcd0e7c: add             x8, PP, #0xe, lsl #12  ; [pp+0xe2c0] Type: HitTestEntry<HitTestTarget>
    //     0xcd0e80: ldr             x8, [x8, #0x2c0]
    // 0xcd0e84: r3 = Null
    //     0xcd0e84: add             x3, PP, #0x90, lsl #12  ; [pp+0x90be0] Null
    //     0xcd0e88: ldr             x3, [x3, #0xbe0]
    // 0xcd0e8c: r0 = HitTestEntry<HitTestTarget>()
    //     0xcd0e8c: bl              #0x833728  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0xcd0e90: ldur            x0, [fp, #-0x10]
    // 0xcd0e94: r2 = Null
    //     0xcd0e94: mov             x2, NULL
    // 0xcd0e98: r1 = Null
    //     0xcd0e98: mov             x1, NULL
    // 0xcd0e9c: cmp             w0, NULL
    // 0xcd0ea0: b.eq            #0xcd0ec8
    // 0xcd0ea4: branchIfSmi(r0, 0xcd0ec8)
    //     0xcd0ea4: tbz             w0, #0, #0xcd0ec8
    // 0xcd0ea8: r3 = LoadClassIdInstr(r0)
    //     0xcd0ea8: ldur            x3, [x0, #-1]
    //     0xcd0eac: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0eb0: r17 = 4165
    //     0xcd0eb0: mov             x17, #0x1045
    // 0xcd0eb4: cmp             x3, x17
    // 0xcd0eb8: b.eq            #0xcd0ed0
    // 0xcd0ebc: r17 = 5294
    //     0xcd0ebc: mov             x17, #0x14ae
    // 0xcd0ec0: cmp             x3, x17
    // 0xcd0ec4: b.eq            #0xcd0ed0
    // 0xcd0ec8: r0 = false
    //     0xcd0ec8: add             x0, NULL, #0x30  ; false
    // 0xcd0ecc: b               #0xcd0ed4
    // 0xcd0ed0: r0 = true
    //     0xcd0ed0: add             x0, NULL, #0x20  ; true
    // 0xcd0ed4: tbnz            w0, #4, #0xcd0f04
    // 0xcd0ed8: ldur            x0, [fp, #-8]
    // 0xcd0edc: LoadField: r1 = r0->field_5f
    //     0xcd0edc: ldur            w1, [x0, #0x5f]
    // 0xcd0ee0: DecompressPointer r1
    //     0xcd0ee0: add             x1, x1, HEAP, lsl #32
    // 0xcd0ee4: cmp             w1, NULL
    // 0xcd0ee8: b.eq            #0xcd0f04
    // 0xcd0eec: ldur            x16, [fp, #-0x10]
    // 0xcd0ef0: stp             x16, x1, [SP]
    // 0xcd0ef4: mov             x0, x1
    // 0xcd0ef8: ClosureCall
    //     0xcd0ef8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0efc: ldur            x2, [x0, #0x1f]
    //     0xcd0f00: blr             x2
    // 0xcd0f04: r0 = Null
    //     0xcd0f04: mov             x0, NULL
    // 0xcd0f08: LeaveFrame
    //     0xcd0f08: mov             SP, fp
    //     0xcd0f0c: ldp             fp, lr, [SP], #0x10
    // 0xcd0f10: ret
    //     0xcd0f10: ret             
    // 0xcd0f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0f14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0f18: b               #0xcd0e58
  }
  set _ hitTestBehavior=(/* No info */) {
    // ** addr: 0xcf9668, size: 0x54
    // 0xcf9668: EnterFrame
    //     0xcf9668: stp             fp, lr, [SP, #-0x10]!
    //     0xcf966c: mov             fp, SP
    // 0xcf9670: CheckStackOverflow
    //     0xcf9670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9674: cmp             SP, x16
    //     0xcf9678: b.ls            #0xcf96b4
    // 0xcf967c: LoadField: r0 = r1->field_53
    //     0xcf967c: ldur            w0, [x1, #0x53]
    // 0xcf9680: DecompressPointer r0
    //     0xcf9680: add             x0, x0, HEAP, lsl #32
    // 0xcf9684: r16 = Instance_HitTestBehavior
    //     0xcf9684: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xcf9688: ldr             x16, [x16, #0x5c0]
    // 0xcf968c: cmp             w0, w16
    // 0xcf9690: b.eq            #0xcf96a4
    // 0xcf9694: r0 = Instance_HitTestBehavior
    //     0xcf9694: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xcf9698: ldr             x0, [x0, #0x5c0]
    // 0xcf969c: StoreField: r1->field_53 = r0
    //     0xcf969c: stur            w0, [x1, #0x53]
    // 0xcf96a0: r0 = markNeedsPaint()
    //     0xcf96a0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf96a4: r0 = Null
    //     0xcf96a4: mov             x0, NULL
    // 0xcf96a8: LeaveFrame
    //     0xcf96a8: mov             SP, fp
    //     0xcf96ac: ldp             fp, lr, [SP], #0x10
    // 0xcf96b0: ret
    //     0xcf96b0: ret             
    // 0xcf96b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf96b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf96b8: b               #0xcf967c
  }
  set _ cursor=(/* No info */) {
    // ** addr: 0xcf96bc, size: 0x94
    // 0xcf96bc: EnterFrame
    //     0xcf96bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf96c0: mov             fp, SP
    // 0xcf96c4: AllocStack(0x20)
    //     0xcf96c4: sub             SP, SP, #0x20
    // 0xcf96c8: SetupParameters(RenderMouseRegion this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf96c8: stur            x1, [fp, #-8]
    //     0xcf96cc: mov             x16, x2
    //     0xcf96d0: mov             x2, x1
    //     0xcf96d4: mov             x1, x16
    //     0xcf96d8: stur            x1, [fp, #-0x10]
    // 0xcf96dc: CheckStackOverflow
    //     0xcf96dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf96e0: cmp             SP, x16
    //     0xcf96e4: b.ls            #0xcf9748
    // 0xcf96e8: LoadField: r0 = r2->field_67
    //     0xcf96e8: ldur            w0, [x2, #0x67]
    // 0xcf96ec: DecompressPointer r0
    //     0xcf96ec: add             x0, x0, HEAP, lsl #32
    // 0xcf96f0: r3 = LoadClassIdInstr(r0)
    //     0xcf96f0: ldur            x3, [x0, #-1]
    //     0xcf96f4: ubfx            x3, x3, #0xc, #0x14
    // 0xcf96f8: stp             x1, x0, [SP]
    // 0xcf96fc: mov             x0, x3
    // 0xcf9700: mov             lr, x0
    // 0xcf9704: ldr             lr, [x21, lr, lsl #3]
    // 0xcf9708: blr             lr
    // 0xcf970c: tbz             w0, #4, #0xcf9738
    // 0xcf9710: ldur            x1, [fp, #-8]
    // 0xcf9714: ldur            x0, [fp, #-0x10]
    // 0xcf9718: StoreField: r1->field_67 = r0
    //     0xcf9718: stur            w0, [x1, #0x67]
    //     0xcf971c: ldurb           w16, [x1, #-1]
    //     0xcf9720: ldurb           w17, [x0, #-1]
    //     0xcf9724: and             x16, x17, x16, lsr #2
    //     0xcf9728: tst             x16, HEAP, lsr #32
    //     0xcf972c: b.eq            #0xcf9734
    //     0xcf9730: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf9734: r0 = markNeedsPaint()
    //     0xcf9734: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf9738: r0 = Null
    //     0xcf9738: mov             x0, NULL
    // 0xcf973c: LeaveFrame
    //     0xcf973c: mov             SP, fp
    //     0xcf9740: ldp             fp, lr, [SP], #0x10
    // 0xcf9744: ret
    //     0xcf9744: ret             
    // 0xcf9748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf974c: b               #0xcf96e8
  }
  get _ onEnter(/* No info */) {
    // ** addr: 0x10f4210, size: 0xc
    // 0x10f4210: LoadField: r0 = r1->field_5b
    //     0x10f4210: ldur            w0, [x1, #0x5b]
    // 0x10f4214: DecompressPointer r0
    //     0x10f4214: add             x0, x0, HEAP, lsl #32
    // 0x10f4218: ret
    //     0x10f4218: ret             
  }
  _ computeSizeForNoChild(/* No info */) {
    // ** addr: 0x11bcbd4, size: 0x68
    // 0x11bcbd4: EnterFrame
    //     0x11bcbd4: stp             fp, lr, [SP, #-0x10]!
    //     0x11bcbd8: mov             fp, SP
    // 0x11bcbdc: AllocStack(0x18)
    //     0x11bcbdc: sub             SP, SP, #0x18
    // 0x11bcbe0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x11bcbe0: mov             x0, x2
    //     0x11bcbe4: stur            x2, [fp, #-8]
    // 0x11bcbe8: CheckStackOverflow
    //     0x11bcbe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bcbec: cmp             SP, x16
    //     0x11bcbf0: b.ls            #0x11bcc34
    // 0x11bcbf4: mov             x1, x0
    // 0x11bcbf8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11bcbf8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11bcbfc: r0 = constrainWidth()
    //     0x11bcbfc: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x11bcc00: ldur            x1, [fp, #-8]
    // 0x11bcc04: stur            d0, [fp, #-0x10]
    // 0x11bcc08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11bcc08: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11bcc0c: r0 = constrainHeight()
    //     0x11bcc0c: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x11bcc10: stur            d0, [fp, #-0x18]
    // 0x11bcc14: r0 = Size()
    //     0x11bcc14: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x11bcc18: ldur            d0, [fp, #-0x10]
    // 0x11bcc1c: StoreField: r0->field_7 = d0
    //     0x11bcc1c: stur            d0, [x0, #7]
    // 0x11bcc20: ldur            d0, [fp, #-0x18]
    // 0x11bcc24: StoreField: r0->field_f = d0
    //     0x11bcc24: stur            d0, [x0, #0xf]
    // 0x11bcc28: LeaveFrame
    //     0x11bcc28: mov             SP, fp
    //     0x11bcc2c: ldp             fp, lr, [SP], #0x10
    // 0x11bcc30: ret
    //     0x11bcc30: ret             
    // 0x11bcc34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bcc34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bcc38: b               #0x11bcbf4
  }
  _ RenderMouseRegion(/* No info */) {
    // ** addr: 0x11d2470, size: 0x1e4
    // 0x11d2470: EnterFrame
    //     0x11d2470: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2474: mov             fp, SP
    // 0x11d2478: AllocStack(0x8)
    //     0x11d2478: sub             SP, SP, #8
    // 0x11d247c: SetupParameters(RenderMouseRegion this /* r1 => r2 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r1 */, {dynamic cursor = Instance__DeferringMouseCursor /* r6 */, dynamic hitTestBehavior = Instance_HitTestBehavior /* r7 */, dynamic onHover = Null /* r4 */})
    //     0x11d247c: mov             x0, x2
    //     0x11d2480: mov             x2, x1
    //     0x11d2484: mov             x1, x3
    //     0x11d2488: ldur            w3, [x4, #0x13]
    //     0x11d248c: ldur            w5, [x4, #0x1f]
    //     0x11d2490: add             x5, x5, HEAP, lsl #32
    //     0x11d2494: add             x16, PP, #0x85, lsl #12  ; [pp+0x85160] "cursor"
    //     0x11d2498: ldr             x16, [x16, #0x160]
    //     0x11d249c: cmp             w5, w16
    //     0x11d24a0: b.ne            #0x11d24c4
    //     0x11d24a4: ldur            w5, [x4, #0x23]
    //     0x11d24a8: add             x5, x5, HEAP, lsl #32
    //     0x11d24ac: sub             w6, w3, w5
    //     0x11d24b0: add             x5, fp, w6, sxtw #2
    //     0x11d24b4: ldr             x5, [x5, #8]
    //     0x11d24b8: mov             x6, x5
    //     0x11d24bc: mov             x5, #1
    //     0x11d24c0: b               #0x11d24cc
    //     0x11d24c4: ldr             x6, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    //     0x11d24c8: mov             x5, #0
    //     0x11d24cc: lsl             x7, x5, #1
    //     0x11d24d0: lsl             w8, w7, #1
    //     0x11d24d4: add             w9, w8, #8
    //     0x11d24d8: add             x16, x4, w9, sxtw #1
    //     0x11d24dc: ldur            w10, [x16, #0xf]
    //     0x11d24e0: add             x10, x10, HEAP, lsl #32
    //     0x11d24e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15158] "hitTestBehavior"
    //     0x11d24e8: ldr             x16, [x16, #0x158]
    //     0x11d24ec: cmp             w10, w16
    //     0x11d24f0: b.ne            #0x11d2524
    //     0x11d24f4: add             w5, w8, #0xa
    //     0x11d24f8: add             x16, x4, w5, sxtw #1
    //     0x11d24fc: ldur            w8, [x16, #0xf]
    //     0x11d2500: add             x8, x8, HEAP, lsl #32
    //     0x11d2504: sub             w5, w3, w8
    //     0x11d2508: add             x8, fp, w5, sxtw #2
    //     0x11d250c: ldr             x8, [x8, #8]
    //     0x11d2510: add             w5, w7, #2
    //     0x11d2514: sbfx            x7, x5, #1, #0x1f
    //     0x11d2518: mov             x5, x7
    //     0x11d251c: mov             x7, x8
    //     0x11d2520: b               #0x11d252c
    //     0x11d2524: add             x7, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0x11d2528: ldr             x7, [x7, #0x5c0]
    //     0x11d252c: lsl             x8, x5, #1
    //     0x11d2530: lsl             w5, w8, #1
    //     0x11d2534: add             w8, w5, #8
    //     0x11d2538: add             x16, x4, w8, sxtw #1
    //     0x11d253c: ldur            w9, [x16, #0xf]
    //     0x11d2540: add             x9, x9, HEAP, lsl #32
    //     0x11d2544: add             x16, PP, #0x85, lsl #12  ; [pp+0x85168] "onHover"
    //     0x11d2548: ldr             x16, [x16, #0x168]
    //     0x11d254c: cmp             w9, w16
    //     0x11d2550: b.ne            #0x11d2578
    //     0x11d2554: add             w8, w5, #0xa
    //     0x11d2558: add             x16, x4, w8, sxtw #1
    //     0x11d255c: ldur            w5, [x16, #0xf]
    //     0x11d2560: add             x5, x5, HEAP, lsl #32
    //     0x11d2564: sub             w4, w3, w5
    //     0x11d2568: add             x3, fp, w4, sxtw #2
    //     0x11d256c: ldr             x3, [x3, #8]
    //     0x11d2570: mov             x4, x3
    //     0x11d2574: b               #0x11d257c
    //     0x11d2578: mov             x4, NULL
    //     0x11d257c: add             x3, NULL, #0x20  ; true
    // 0x11d257c: r3 = true
    // 0x11d2580: CheckStackOverflow
    //     0x11d2580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2584: cmp             SP, x16
    //     0x11d2588: b.ls            #0x11d264c
    // 0x11d258c: StoreField: r2->field_5b = r0
    //     0x11d258c: stur            w0, [x2, #0x5b]
    //     0x11d2590: ldurb           w16, [x2, #-1]
    //     0x11d2594: ldurb           w17, [x0, #-1]
    //     0x11d2598: and             x16, x17, x16, lsr #2
    //     0x11d259c: tst             x16, HEAP, lsr #32
    //     0x11d25a0: b.eq            #0x11d25a8
    //     0x11d25a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d25a8: mov             x0, x4
    // 0x11d25ac: StoreField: r2->field_5f = r0
    //     0x11d25ac: stur            w0, [x2, #0x5f]
    //     0x11d25b0: ldurb           w16, [x2, #-1]
    //     0x11d25b4: ldurb           w17, [x0, #-1]
    //     0x11d25b8: and             x16, x17, x16, lsr #2
    //     0x11d25bc: tst             x16, HEAP, lsr #32
    //     0x11d25c0: b.eq            #0x11d25c8
    //     0x11d25c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d25c8: mov             x0, x1
    // 0x11d25cc: StoreField: r2->field_63 = r0
    //     0x11d25cc: stur            w0, [x2, #0x63]
    //     0x11d25d0: ldurb           w16, [x2, #-1]
    //     0x11d25d4: ldurb           w17, [x0, #-1]
    //     0x11d25d8: and             x16, x17, x16, lsr #2
    //     0x11d25dc: tst             x16, HEAP, lsr #32
    //     0x11d25e0: b.eq            #0x11d25e8
    //     0x11d25e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d25e8: mov             x0, x6
    // 0x11d25ec: StoreField: r2->field_67 = r0
    //     0x11d25ec: stur            w0, [x2, #0x67]
    //     0x11d25f0: ldurb           w16, [x2, #-1]
    //     0x11d25f4: ldurb           w17, [x0, #-1]
    //     0x11d25f8: and             x16, x17, x16, lsr #2
    //     0x11d25fc: tst             x16, HEAP, lsr #32
    //     0x11d2600: b.eq            #0x11d2608
    //     0x11d2604: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d2608: StoreField: r2->field_6b = r3
    //     0x11d2608: stur            w3, [x2, #0x6b]
    // 0x11d260c: StoreField: r2->field_57 = r3
    //     0x11d260c: stur            w3, [x2, #0x57]
    // 0x11d2610: cmp             w7, NULL
    // 0x11d2614: b.ne            #0x11d2624
    // 0x11d2618: r0 = Instance_HitTestBehavior
    //     0x11d2618: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0x11d261c: ldr             x0, [x0, #0x5c0]
    // 0x11d2620: b               #0x11d2628
    // 0x11d2624: mov             x0, x7
    // 0x11d2628: str             x0, [SP]
    // 0x11d262c: mov             x1, x2
    // 0x11d2630: r4 = const [0, 0x2, 0x1, 0x1, behavior, 0x1, null]
    //     0x11d2630: add             x4, PP, #0x12, lsl #12  ; [pp+0x123b8] List(7) [0, 0x2, 0x1, 0x1, "behavior", 0x1, Null]
    //     0x11d2634: ldr             x4, [x4, #0x3b8]
    // 0x11d2638: r0 = RenderProxyBoxWithHitTestBehavior()
    //     0x11d2638: bl              #0x11d2340  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::RenderProxyBoxWithHitTestBehavior
    // 0x11d263c: r0 = Null
    //     0x11d263c: mov             x0, NULL
    // 0x11d2640: LeaveFrame
    //     0x11d2640: mov             SP, fp
    //     0x11d2644: ldp             fp, lr, [SP], #0x10
    // 0x11d2648: ret
    //     0x11d2648: ret             
    // 0x11d264c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d264c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2650: b               #0x11d258c
  }
}

// class id: 4955, size: 0x7c, field offset: 0x58
class RenderPointerListener extends RenderProxyBoxWithHitTestBehavior {

  _ handleEvent(/* No info */) {
    // ** addr: 0xcd0854, size: 0x470
    // 0xcd0854: EnterFrame
    //     0xcd0854: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0858: mov             fp, SP
    // 0xcd085c: AllocStack(0x20)
    //     0xcd085c: sub             SP, SP, #0x20
    // 0xcd0860: SetupParameters(RenderPointerListener this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0 */)
    //     0xcd0860: mov             x4, x1
    //     0xcd0864: mov             x0, x3
    //     0xcd0868: mov             x3, x2
    //     0xcd086c: stur            x1, [fp, #-8]
    //     0xcd0870: stur            x2, [fp, #-0x10]
    // 0xcd0874: CheckStackOverflow
    //     0xcd0874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0878: cmp             SP, x16
    //     0xcd087c: b.ls            #0xcd0cbc
    // 0xcd0880: r2 = Null
    //     0xcd0880: mov             x2, NULL
    // 0xcd0884: r1 = Null
    //     0xcd0884: mov             x1, NULL
    // 0xcd0888: r4 = 60
    //     0xcd0888: mov             x4, #0x3c
    // 0xcd088c: branchIfSmi(r0, 0xcd0898)
    //     0xcd088c: tbz             w0, #0, #0xcd0898
    // 0xcd0890: r4 = LoadClassIdInstr(r0)
    //     0xcd0890: ldur            x4, [x0, #-1]
    //     0xcd0894: ubfx            x4, x4, #0xc, #0x14
    // 0xcd0898: sub             x4, x4, #0xc63
    // 0xcd089c: cmp             x4, #2
    // 0xcd08a0: b.ls            #0xcd08b8
    // 0xcd08a4: r8 = HitTestEntry<HitTestTarget>
    //     0xcd08a4: add             x8, PP, #0xe, lsl #12  ; [pp+0xe2c0] Type: HitTestEntry<HitTestTarget>
    //     0xcd08a8: ldr             x8, [x8, #0x2c0]
    // 0xcd08ac: r3 = Null
    //     0xcd08ac: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a658] Null
    //     0xcd08b0: ldr             x3, [x3, #0x658]
    // 0xcd08b4: r0 = HitTestEntry<HitTestTarget>()
    //     0xcd08b4: bl              #0x833728  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0xcd08b8: ldur            x0, [fp, #-0x10]
    // 0xcd08bc: r2 = Null
    //     0xcd08bc: mov             x2, NULL
    // 0xcd08c0: r1 = Null
    //     0xcd08c0: mov             x1, NULL
    // 0xcd08c4: cmp             w0, NULL
    // 0xcd08c8: b.eq            #0xcd08f0
    // 0xcd08cc: branchIfSmi(r0, 0xcd08f0)
    //     0xcd08cc: tbz             w0, #0, #0xcd08f0
    // 0xcd08d0: r3 = LoadClassIdInstr(r0)
    //     0xcd08d0: ldur            x3, [x0, #-1]
    //     0xcd08d4: ubfx            x3, x3, #0xc, #0x14
    // 0xcd08d8: r17 = 4159
    //     0xcd08d8: mov             x17, #0x103f
    // 0xcd08dc: cmp             x3, x17
    // 0xcd08e0: b.eq            #0xcd08f8
    // 0xcd08e4: r17 = 5288
    //     0xcd08e4: mov             x17, #0x14a8
    // 0xcd08e8: cmp             x3, x17
    // 0xcd08ec: b.eq            #0xcd08f8
    // 0xcd08f0: r0 = false
    //     0xcd08f0: add             x0, NULL, #0x30  ; false
    // 0xcd08f4: b               #0xcd08fc
    // 0xcd08f8: r0 = true
    //     0xcd08f8: add             x0, NULL, #0x20  ; true
    // 0xcd08fc: tbnz            w0, #4, #0xcd0934
    // 0xcd0900: ldur            x3, [fp, #-8]
    // 0xcd0904: LoadField: r0 = r3->field_57
    //     0xcd0904: ldur            w0, [x3, #0x57]
    // 0xcd0908: DecompressPointer r0
    //     0xcd0908: add             x0, x0, HEAP, lsl #32
    // 0xcd090c: cmp             w0, NULL
    // 0xcd0910: b.ne            #0xcd091c
    // 0xcd0914: r0 = Null
    //     0xcd0914: mov             x0, NULL
    // 0xcd0918: b               #0xcd0cb0
    // 0xcd091c: ldur            x16, [fp, #-0x10]
    // 0xcd0920: stp             x16, x0, [SP]
    // 0xcd0924: ClosureCall
    //     0xcd0924: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0928: ldur            x2, [x0, #0x1f]
    //     0xcd092c: blr             x2
    // 0xcd0930: b               #0xcd0cb0
    // 0xcd0934: ldur            x3, [fp, #-8]
    // 0xcd0938: ldur            x0, [fp, #-0x10]
    // 0xcd093c: r2 = Null
    //     0xcd093c: mov             x2, NULL
    // 0xcd0940: r1 = Null
    //     0xcd0940: mov             x1, NULL
    // 0xcd0944: cmp             w0, NULL
    // 0xcd0948: b.eq            #0xcd0970
    // 0xcd094c: branchIfSmi(r0, 0xcd0970)
    //     0xcd094c: tbz             w0, #0, #0xcd0970
    // 0xcd0950: r3 = LoadClassIdInstr(r0)
    //     0xcd0950: ldur            x3, [x0, #-1]
    //     0xcd0954: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0958: r17 = 4157
    //     0xcd0958: mov             x17, #0x103d
    // 0xcd095c: cmp             x3, x17
    // 0xcd0960: b.eq            #0xcd0978
    // 0xcd0964: r17 = 5286
    //     0xcd0964: mov             x17, #0x14a6
    // 0xcd0968: cmp             x3, x17
    // 0xcd096c: b.eq            #0xcd0978
    // 0xcd0970: r0 = false
    //     0xcd0970: add             x0, NULL, #0x30  ; false
    // 0xcd0974: b               #0xcd097c
    // 0xcd0978: r0 = true
    //     0xcd0978: add             x0, NULL, #0x20  ; true
    // 0xcd097c: tbnz            w0, #4, #0xcd09b4
    // 0xcd0980: ldur            x3, [fp, #-8]
    // 0xcd0984: LoadField: r0 = r3->field_5b
    //     0xcd0984: ldur            w0, [x3, #0x5b]
    // 0xcd0988: DecompressPointer r0
    //     0xcd0988: add             x0, x0, HEAP, lsl #32
    // 0xcd098c: cmp             w0, NULL
    // 0xcd0990: b.ne            #0xcd099c
    // 0xcd0994: r0 = Null
    //     0xcd0994: mov             x0, NULL
    // 0xcd0998: b               #0xcd0cb0
    // 0xcd099c: ldur            x16, [fp, #-0x10]
    // 0xcd09a0: stp             x16, x0, [SP]
    // 0xcd09a4: ClosureCall
    //     0xcd09a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd09a8: ldur            x2, [x0, #0x1f]
    //     0xcd09ac: blr             x2
    // 0xcd09b0: b               #0xcd0cb0
    // 0xcd09b4: ldur            x3, [fp, #-8]
    // 0xcd09b8: ldur            x0, [fp, #-0x10]
    // 0xcd09bc: r2 = Null
    //     0xcd09bc: mov             x2, NULL
    // 0xcd09c0: r1 = Null
    //     0xcd09c0: mov             x1, NULL
    // 0xcd09c4: cmp             w0, NULL
    // 0xcd09c8: b.eq            #0xcd09f0
    // 0xcd09cc: branchIfSmi(r0, 0xcd09f0)
    //     0xcd09cc: tbz             w0, #0, #0xcd09f0
    // 0xcd09d0: r3 = LoadClassIdInstr(r0)
    //     0xcd09d0: ldur            x3, [x0, #-1]
    //     0xcd09d4: ubfx            x3, x3, #0xc, #0x14
    // 0xcd09d8: r17 = 4155
    //     0xcd09d8: mov             x17, #0x103b
    // 0xcd09dc: cmp             x3, x17
    // 0xcd09e0: b.eq            #0xcd09f8
    // 0xcd09e4: r17 = 5284
    //     0xcd09e4: mov             x17, #0x14a4
    // 0xcd09e8: cmp             x3, x17
    // 0xcd09ec: b.eq            #0xcd09f8
    // 0xcd09f0: r0 = false
    //     0xcd09f0: add             x0, NULL, #0x30  ; false
    // 0xcd09f4: b               #0xcd09fc
    // 0xcd09f8: r0 = true
    //     0xcd09f8: add             x0, NULL, #0x20  ; true
    // 0xcd09fc: tbnz            w0, #4, #0xcd0a34
    // 0xcd0a00: ldur            x3, [fp, #-8]
    // 0xcd0a04: LoadField: r0 = r3->field_5f
    //     0xcd0a04: ldur            w0, [x3, #0x5f]
    // 0xcd0a08: DecompressPointer r0
    //     0xcd0a08: add             x0, x0, HEAP, lsl #32
    // 0xcd0a0c: cmp             w0, NULL
    // 0xcd0a10: b.ne            #0xcd0a1c
    // 0xcd0a14: r0 = Null
    //     0xcd0a14: mov             x0, NULL
    // 0xcd0a18: b               #0xcd0cb0
    // 0xcd0a1c: ldur            x16, [fp, #-0x10]
    // 0xcd0a20: stp             x16, x0, [SP]
    // 0xcd0a24: ClosureCall
    //     0xcd0a24: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0a28: ldur            x2, [x0, #0x1f]
    //     0xcd0a2c: blr             x2
    // 0xcd0a30: b               #0xcd0cb0
    // 0xcd0a34: ldur            x3, [fp, #-8]
    // 0xcd0a38: ldur            x0, [fp, #-0x10]
    // 0xcd0a3c: r2 = Null
    //     0xcd0a3c: mov             x2, NULL
    // 0xcd0a40: r1 = Null
    //     0xcd0a40: mov             x1, NULL
    // 0xcd0a44: cmp             w0, NULL
    // 0xcd0a48: b.eq            #0xcd0a70
    // 0xcd0a4c: branchIfSmi(r0, 0xcd0a70)
    //     0xcd0a4c: tbz             w0, #0, #0xcd0a70
    // 0xcd0a50: r3 = LoadClassIdInstr(r0)
    //     0xcd0a50: ldur            x3, [x0, #-1]
    //     0xcd0a54: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0a58: r17 = 4165
    //     0xcd0a58: mov             x17, #0x1045
    // 0xcd0a5c: cmp             x3, x17
    // 0xcd0a60: b.eq            #0xcd0a78
    // 0xcd0a64: r17 = 5294
    //     0xcd0a64: mov             x17, #0x14ae
    // 0xcd0a68: cmp             x3, x17
    // 0xcd0a6c: b.eq            #0xcd0a78
    // 0xcd0a70: r0 = false
    //     0xcd0a70: add             x0, NULL, #0x30  ; false
    // 0xcd0a74: b               #0xcd0a7c
    // 0xcd0a78: r0 = true
    //     0xcd0a78: add             x0, NULL, #0x20  ; true
    // 0xcd0a7c: tbnz            w0, #4, #0xcd0a88
    // 0xcd0a80: r0 = Null
    //     0xcd0a80: mov             x0, NULL
    // 0xcd0a84: b               #0xcd0cb0
    // 0xcd0a88: ldur            x0, [fp, #-0x10]
    // 0xcd0a8c: r2 = Null
    //     0xcd0a8c: mov             x2, NULL
    // 0xcd0a90: r1 = Null
    //     0xcd0a90: mov             x1, NULL
    // 0xcd0a94: cmp             w0, NULL
    // 0xcd0a98: b.eq            #0xcd0ac0
    // 0xcd0a9c: branchIfSmi(r0, 0xcd0ac0)
    //     0xcd0a9c: tbz             w0, #0, #0xcd0ac0
    // 0xcd0aa0: r3 = LoadClassIdInstr(r0)
    //     0xcd0aa0: ldur            x3, [x0, #-1]
    //     0xcd0aa4: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0aa8: r17 = 4139
    //     0xcd0aa8: mov             x17, #0x102b
    // 0xcd0aac: cmp             x3, x17
    // 0xcd0ab0: b.eq            #0xcd0ac8
    // 0xcd0ab4: r17 = 5276
    //     0xcd0ab4: mov             x17, #0x149c
    // 0xcd0ab8: cmp             x3, x17
    // 0xcd0abc: b.eq            #0xcd0ac8
    // 0xcd0ac0: r0 = false
    //     0xcd0ac0: add             x0, NULL, #0x30  ; false
    // 0xcd0ac4: b               #0xcd0acc
    // 0xcd0ac8: r0 = true
    //     0xcd0ac8: add             x0, NULL, #0x20  ; true
    // 0xcd0acc: tbnz            w0, #4, #0xcd0b04
    // 0xcd0ad0: ldur            x3, [fp, #-8]
    // 0xcd0ad4: LoadField: r0 = r3->field_67
    //     0xcd0ad4: ldur            w0, [x3, #0x67]
    // 0xcd0ad8: DecompressPointer r0
    //     0xcd0ad8: add             x0, x0, HEAP, lsl #32
    // 0xcd0adc: cmp             w0, NULL
    // 0xcd0ae0: b.ne            #0xcd0aec
    // 0xcd0ae4: r0 = Null
    //     0xcd0ae4: mov             x0, NULL
    // 0xcd0ae8: b               #0xcd0cb0
    // 0xcd0aec: ldur            x16, [fp, #-0x10]
    // 0xcd0af0: stp             x16, x0, [SP]
    // 0xcd0af4: ClosureCall
    //     0xcd0af4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0af8: ldur            x2, [x0, #0x1f]
    //     0xcd0afc: blr             x2
    // 0xcd0b00: b               #0xcd0cb0
    // 0xcd0b04: ldur            x3, [fp, #-8]
    // 0xcd0b08: ldur            x0, [fp, #-0x10]
    // 0xcd0b0c: r2 = Null
    //     0xcd0b0c: mov             x2, NULL
    // 0xcd0b10: r1 = Null
    //     0xcd0b10: mov             x1, NULL
    // 0xcd0b14: cmp             w0, NULL
    // 0xcd0b18: b.eq            #0xcd0b40
    // 0xcd0b1c: branchIfSmi(r0, 0xcd0b40)
    //     0xcd0b1c: tbz             w0, #0, #0xcd0b40
    // 0xcd0b20: r3 = LoadClassIdInstr(r0)
    //     0xcd0b20: ldur            x3, [x0, #-1]
    //     0xcd0b24: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0b28: r17 = 4145
    //     0xcd0b28: mov             x17, #0x1031
    // 0xcd0b2c: cmp             x3, x17
    // 0xcd0b30: b.eq            #0xcd0b48
    // 0xcd0b34: r17 = 5282
    //     0xcd0b34: mov             x17, #0x14a2
    // 0xcd0b38: cmp             x3, x17
    // 0xcd0b3c: b.eq            #0xcd0b48
    // 0xcd0b40: r0 = false
    //     0xcd0b40: add             x0, NULL, #0x30  ; false
    // 0xcd0b44: b               #0xcd0b4c
    // 0xcd0b48: r0 = true
    //     0xcd0b48: add             x0, NULL, #0x20  ; true
    // 0xcd0b4c: tbnz            w0, #4, #0xcd0b7c
    // 0xcd0b50: ldur            x3, [fp, #-8]
    // 0xcd0b54: LoadField: r0 = r3->field_6b
    //     0xcd0b54: ldur            w0, [x3, #0x6b]
    // 0xcd0b58: DecompressPointer r0
    //     0xcd0b58: add             x0, x0, HEAP, lsl #32
    // 0xcd0b5c: cmp             w0, NULL
    // 0xcd0b60: b.eq            #0xcd0b74
    // 0xcd0b64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcd0b64: ldur            w1, [x0, #0x17]
    // 0xcd0b68: DecompressPointer r1
    //     0xcd0b68: add             x1, x1, HEAP, lsl #32
    // 0xcd0b6c: ldur            x2, [fp, #-0x10]
    // 0xcd0b70: r0 = _handlePointerPanZoomStart()
    //     0xcd0b70: bl              #0xcd0d00  ; [package:flutter/src/widgets/gesture_detector.dart] RawGestureDetectorState::_handlePointerPanZoomStart
    // 0xcd0b74: r0 = Null
    //     0xcd0b74: mov             x0, NULL
    // 0xcd0b78: b               #0xcd0cb0
    // 0xcd0b7c: ldur            x3, [fp, #-8]
    // 0xcd0b80: ldur            x0, [fp, #-0x10]
    // 0xcd0b84: r2 = Null
    //     0xcd0b84: mov             x2, NULL
    // 0xcd0b88: r1 = Null
    //     0xcd0b88: mov             x1, NULL
    // 0xcd0b8c: cmp             w0, NULL
    // 0xcd0b90: b.eq            #0xcd0bb8
    // 0xcd0b94: branchIfSmi(r0, 0xcd0bb8)
    //     0xcd0b94: tbz             w0, #0, #0xcd0bb8
    // 0xcd0b98: r3 = LoadClassIdInstr(r0)
    //     0xcd0b98: ldur            x3, [x0, #-1]
    //     0xcd0b9c: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0ba0: r17 = 4143
    //     0xcd0ba0: mov             x17, #0x102f
    // 0xcd0ba4: cmp             x3, x17
    // 0xcd0ba8: b.eq            #0xcd0bc0
    // 0xcd0bac: r17 = 5280
    //     0xcd0bac: mov             x17, #0x14a0
    // 0xcd0bb0: cmp             x3, x17
    // 0xcd0bb4: b.eq            #0xcd0bc0
    // 0xcd0bb8: r0 = false
    //     0xcd0bb8: add             x0, NULL, #0x30  ; false
    // 0xcd0bbc: b               #0xcd0bc4
    // 0xcd0bc0: r0 = true
    //     0xcd0bc0: add             x0, NULL, #0x20  ; true
    // 0xcd0bc4: tbnz            w0, #4, #0xcd0bd0
    // 0xcd0bc8: r0 = Null
    //     0xcd0bc8: mov             x0, NULL
    // 0xcd0bcc: b               #0xcd0cb0
    // 0xcd0bd0: ldur            x0, [fp, #-0x10]
    // 0xcd0bd4: r2 = Null
    //     0xcd0bd4: mov             x2, NULL
    // 0xcd0bd8: r1 = Null
    //     0xcd0bd8: mov             x1, NULL
    // 0xcd0bdc: cmp             w0, NULL
    // 0xcd0be0: b.eq            #0xcd0c08
    // 0xcd0be4: branchIfSmi(r0, 0xcd0c08)
    //     0xcd0be4: tbz             w0, #0, #0xcd0c08
    // 0xcd0be8: r3 = LoadClassIdInstr(r0)
    //     0xcd0be8: ldur            x3, [x0, #-1]
    //     0xcd0bec: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0bf0: r17 = 4141
    //     0xcd0bf0: mov             x17, #0x102d
    // 0xcd0bf4: cmp             x3, x17
    // 0xcd0bf8: b.eq            #0xcd0c10
    // 0xcd0bfc: r17 = 5278
    //     0xcd0bfc: mov             x17, #0x149e
    // 0xcd0c00: cmp             x3, x17
    // 0xcd0c04: b.eq            #0xcd0c10
    // 0xcd0c08: r0 = false
    //     0xcd0c08: add             x0, NULL, #0x30  ; false
    // 0xcd0c0c: b               #0xcd0c14
    // 0xcd0c10: r0 = true
    //     0xcd0c10: add             x0, NULL, #0x20  ; true
    // 0xcd0c14: tbnz            w0, #4, #0xcd0c20
    // 0xcd0c18: r0 = Null
    //     0xcd0c18: mov             x0, NULL
    // 0xcd0c1c: b               #0xcd0cb0
    // 0xcd0c20: ldur            x0, [fp, #-0x10]
    // 0xcd0c24: r2 = Null
    //     0xcd0c24: mov             x2, NULL
    // 0xcd0c28: r1 = Null
    //     0xcd0c28: mov             x1, NULL
    // 0xcd0c2c: cmp             w0, NULL
    // 0xcd0c30: b.eq            #0xcd0c5c
    // 0xcd0c34: branchIfSmi(r0, 0xcd0c5c)
    //     0xcd0c34: tbz             w0, #0, #0xcd0c5c
    // 0xcd0c38: r3 = LoadClassIdInstr(r0)
    //     0xcd0c38: ldur            x3, [x0, #-1]
    //     0xcd0c3c: ubfx            x3, x3, #0xc, #0x14
    // 0xcd0c40: r17 = -4148
    //     0xcd0c40: mov             x17, #-0x1034
    // 0xcd0c44: add             x3, x3, x17
    // 0xcd0c48: cmp             x3, #5
    // 0xcd0c4c: b.ls            #0xcd0c64
    // 0xcd0c50: sub             x3, x3, #0x458
    // 0xcd0c54: cmp             x3, #4
    // 0xcd0c58: b.ls            #0xcd0c64
    // 0xcd0c5c: r0 = false
    //     0xcd0c5c: add             x0, NULL, #0x30  ; false
    // 0xcd0c60: b               #0xcd0c68
    // 0xcd0c64: r0 = true
    //     0xcd0c64: add             x0, NULL, #0x20  ; true
    // 0xcd0c68: tbnz            w0, #4, #0xcd0cac
    // 0xcd0c6c: ldur            x0, [fp, #-8]
    // 0xcd0c70: LoadField: r1 = r0->field_77
    //     0xcd0c70: ldur            w1, [x0, #0x77]
    // 0xcd0c74: DecompressPointer r1
    //     0xcd0c74: add             x1, x1, HEAP, lsl #32
    // 0xcd0c78: cmp             w1, NULL
    // 0xcd0c7c: b.ne            #0xcd0c88
    // 0xcd0c80: r1 = Null
    //     0xcd0c80: mov             x1, NULL
    // 0xcd0c84: b               #0xcd0ca4
    // 0xcd0c88: ldur            x16, [fp, #-0x10]
    // 0xcd0c8c: stp             x16, x1, [SP]
    // 0xcd0c90: mov             x0, x1
    // 0xcd0c94: ClosureCall
    //     0xcd0c94: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0c98: ldur            x2, [x0, #0x1f]
    //     0xcd0c9c: blr             x2
    // 0xcd0ca0: mov             x1, x0
    // 0xcd0ca4: mov             x0, x1
    // 0xcd0ca8: b               #0xcd0cb0
    // 0xcd0cac: r0 = Null
    //     0xcd0cac: mov             x0, NULL
    // 0xcd0cb0: LeaveFrame
    //     0xcd0cb0: mov             SP, fp
    //     0xcd0cb4: ldp             fp, lr, [SP], #0x10
    // 0xcd0cb8: ret
    //     0xcd0cb8: ret             
    // 0xcd0cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0cbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0cc0: b               #0xcd0880
  }
  _ RenderPointerListener(/* No info */) {
    // ** addr: 0x11d222c, size: 0x114
    // 0x11d222c: EnterFrame
    //     0x11d222c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2230: mov             fp, SP
    // 0x11d2234: AllocStack(0x8)
    //     0x11d2234: sub             SP, SP, #8
    // 0x11d2238: SetupParameters(RenderPointerListener this /* r1 => r5 */, dynamic _ /* r2 => r4 */, dynamic _ /* r5 => r0 */, dynamic _ /* r6 => r2 */, dynamic _ /* r7 => r1 */)
    //     0x11d2238: mov             x0, x5
    //     0x11d223c: mov             x5, x1
    //     0x11d2240: mov             x4, x2
    //     0x11d2244: mov             x2, x6
    //     0x11d2248: mov             x1, x7
    // 0x11d224c: CheckStackOverflow
    //     0x11d224c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2250: cmp             SP, x16
    //     0x11d2254: b.ls            #0x11d2338
    // 0x11d2258: StoreField: r5->field_57 = r0
    //     0x11d2258: stur            w0, [x5, #0x57]
    //     0x11d225c: ldurb           w16, [x5, #-1]
    //     0x11d2260: ldurb           w17, [x0, #-1]
    //     0x11d2264: and             x16, x17, x16, lsr #2
    //     0x11d2268: tst             x16, HEAP, lsr #32
    //     0x11d226c: b.eq            #0x11d2274
    //     0x11d2270: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d2274: mov             x0, x2
    // 0x11d2278: StoreField: r5->field_5b = r0
    //     0x11d2278: stur            w0, [x5, #0x5b]
    //     0x11d227c: ldurb           w16, [x5, #-1]
    //     0x11d2280: ldurb           w17, [x0, #-1]
    //     0x11d2284: and             x16, x17, x16, lsr #2
    //     0x11d2288: tst             x16, HEAP, lsr #32
    //     0x11d228c: b.eq            #0x11d2294
    //     0x11d2290: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d2294: ldr             x0, [fp, #0x10]
    // 0x11d2298: StoreField: r5->field_5f = r0
    //     0x11d2298: stur            w0, [x5, #0x5f]
    //     0x11d229c: ldurb           w16, [x5, #-1]
    //     0x11d22a0: ldurb           w17, [x0, #-1]
    //     0x11d22a4: and             x16, x17, x16, lsr #2
    //     0x11d22a8: tst             x16, HEAP, lsr #32
    //     0x11d22ac: b.eq            #0x11d22b4
    //     0x11d22b0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d22b4: mov             x0, x3
    // 0x11d22b8: StoreField: r5->field_67 = r0
    //     0x11d22b8: stur            w0, [x5, #0x67]
    //     0x11d22bc: ldurb           w16, [x5, #-1]
    //     0x11d22c0: ldurb           w17, [x0, #-1]
    //     0x11d22c4: and             x16, x17, x16, lsr #2
    //     0x11d22c8: tst             x16, HEAP, lsr #32
    //     0x11d22cc: b.eq            #0x11d22d4
    //     0x11d22d0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d22d4: mov             x0, x1
    // 0x11d22d8: StoreField: r5->field_6b = r0
    //     0x11d22d8: stur            w0, [x5, #0x6b]
    //     0x11d22dc: ldurb           w16, [x5, #-1]
    //     0x11d22e0: ldurb           w17, [x0, #-1]
    //     0x11d22e4: and             x16, x17, x16, lsr #2
    //     0x11d22e8: tst             x16, HEAP, lsr #32
    //     0x11d22ec: b.eq            #0x11d22f4
    //     0x11d22f0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d22f4: ldr             x0, [fp, #0x18]
    // 0x11d22f8: StoreField: r5->field_77 = r0
    //     0x11d22f8: stur            w0, [x5, #0x77]
    //     0x11d22fc: ldurb           w16, [x5, #-1]
    //     0x11d2300: ldurb           w17, [x0, #-1]
    //     0x11d2304: and             x16, x17, x16, lsr #2
    //     0x11d2308: tst             x16, HEAP, lsr #32
    //     0x11d230c: b.eq            #0x11d2314
    //     0x11d2310: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x11d2314: str             x4, [SP]
    // 0x11d2318: mov             x1, x5
    // 0x11d231c: r4 = const [0, 0x2, 0x1, 0x1, behavior, 0x1, null]
    //     0x11d231c: add             x4, PP, #0x12, lsl #12  ; [pp+0x123b8] List(7) [0, 0x2, 0x1, 0x1, "behavior", 0x1, Null]
    //     0x11d2320: ldr             x4, [x4, #0x3b8]
    // 0x11d2324: r0 = RenderProxyBoxWithHitTestBehavior()
    //     0x11d2324: bl              #0x11d2340  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::RenderProxyBoxWithHitTestBehavior
    // 0x11d2328: r0 = Null
    //     0x11d2328: mov             x0, NULL
    // 0x11d232c: LeaveFrame
    //     0x11d232c: mov             SP, fp
    //     0x11d2330: ldp             fp, lr, [SP], #0x10
    // 0x11d2334: ret
    //     0x11d2334: ret             
    // 0x11d2338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2338: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d233c: b               #0x11d2258
  }
}

// class id: 4960, size: 0x58, field offset: 0x54
class RenderConstrainedBox extends RenderProxyBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb15fe4, size: 0x24
    // 0xb15fe4: EnterFrame
    //     0xb15fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xb15fe8: mov             fp, SP
    // 0xb15fec: ldr             x2, [fp, #0x10]
    // 0xb15ff0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb15ff0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43e0] AnonymousClosure: (0xb16008), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicWidth (0xb16080)
    //     0xb15ff4: ldr             x1, [x1, #0x3e0]
    // 0xb15ff8: r0 = AllocateClosure()
    //     0xb15ff8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb15ffc: LeaveFrame
    //     0xb15ffc: mov             SP, fp
    //     0xb16000: ldp             fp, lr, [SP], #0x10
    // 0xb16004: ret
    //     0xb16004: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16008, size: 0x78
    // 0xb16008: EnterFrame
    //     0xb16008: stp             fp, lr, [SP, #-0x10]!
    //     0xb1600c: mov             fp, SP
    // 0xb16010: ldr             x0, [fp, #0x18]
    // 0xb16014: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16014: ldur            w1, [x0, #0x17]
    // 0xb16018: DecompressPointer r1
    //     0xb16018: add             x1, x1, HEAP, lsl #32
    // 0xb1601c: CheckStackOverflow
    //     0xb1601c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16020: cmp             SP, x16
    //     0xb16024: b.ls            #0xb16068
    // 0xb16028: ldr             x2, [fp, #0x10]
    // 0xb1602c: r0 = computeMinIntrinsicWidth()
    //     0xb1602c: bl              #0xb16080  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicWidth
    // 0xb16030: r0 = inline_Allocate_Double()
    //     0xb16030: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16034: add             x0, x0, #0x10
    //     0xb16038: cmp             x1, x0
    //     0xb1603c: b.ls            #0xb16070
    //     0xb16040: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16044: sub             x0, x0, #0xf
    //     0xb16048: mov             x1, #0xe19c
    //     0xb1604c: movk            x1, #3, lsl #16
    //     0xb16050: stur            x1, [x0, #-1]
    // 0xb16054: dmb             ishst
    // 0xb16058: StoreField: r0->field_7 = d0
    //     0xb16058: stur            d0, [x0, #7]
    // 0xb1605c: LeaveFrame
    //     0xb1605c: mov             SP, fp
    //     0xb16060: ldp             fp, lr, [SP], #0x10
    // 0xb16064: ret
    //     0xb16064: ret             
    // 0xb16068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1606c: b               #0xb16028
    // 0xb16070: SaveReg d0
    //     0xb16070: str             q0, [SP, #-0x10]!
    // 0xb16074: r0 = AllocateDouble()
    //     0xb16074: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16078: RestoreReg d0
    //     0xb16078: ldr             q0, [SP], #0x10
    // 0xb1607c: b               #0xb16058
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16080, size: 0xf4
    // 0xb16080: EnterFrame
    //     0xb16080: stp             fp, lr, [SP, #-0x10]!
    //     0xb16084: mov             fp, SP
    // 0xb16088: AllocStack(0x10)
    //     0xb16088: sub             SP, SP, #0x10
    // 0xb1608c: d0 = inf
    //     0xb1608c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb16090: mov             x0, x1
    // 0xb16094: stur            x1, [fp, #-8]
    // 0xb16098: CheckStackOverflow
    //     0xb16098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1609c: cmp             SP, x16
    //     0xb160a0: b.ls            #0xb16154
    // 0xb160a4: LoadField: r1 = r0->field_53
    //     0xb160a4: ldur            w1, [x0, #0x53]
    // 0xb160a8: DecompressPointer r1
    //     0xb160a8: add             x1, x1, HEAP, lsl #32
    // 0xb160ac: LoadField: d1 = r1->field_f
    //     0xb160ac: ldur            d1, [x1, #0xf]
    // 0xb160b0: fcmp            d0, d1
    // 0xb160b4: b.le            #0xb160d4
    // 0xb160b8: LoadField: d2 = r1->field_7
    //     0xb160b8: ldur            d2, [x1, #7]
    // 0xb160bc: fcmp            d2, d1
    // 0xb160c0: b.lt            #0xb160d4
    // 0xb160c4: mov             v0.16b, v2.16b
    // 0xb160c8: LeaveFrame
    //     0xb160c8: mov             SP, fp
    //     0xb160cc: ldp             fp, lr, [SP], #0x10
    // 0xb160d0: ret
    //     0xb160d0: ret             
    // 0xb160d4: mov             x1, x0
    // 0xb160d8: r0 = computeMinIntrinsicWidth()
    //     0xb160d8: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb160dc: ldur            x0, [fp, #-8]
    // 0xb160e0: LoadField: r1 = r0->field_53
    //     0xb160e0: ldur            w1, [x0, #0x53]
    // 0xb160e4: DecompressPointer r1
    //     0xb160e4: add             x1, x1, HEAP, lsl #32
    // 0xb160e8: LoadField: d1 = r1->field_7
    //     0xb160e8: ldur            d1, [x1, #7]
    // 0xb160ec: d2 = inf
    //     0xb160ec: ldr             d2, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb160f0: fcmp            d1, d2
    // 0xb160f4: r16 = true
    //     0xb160f4: add             x16, NULL, #0x20  ; true
    // 0xb160f8: r17 = false
    //     0xb160f8: add             x17, NULL, #0x30  ; false
    // 0xb160fc: csel            x0, x16, x17, ge
    // 0xb16100: tbz             w0, #4, #0xb16148
    // 0xb16104: r0 = inline_Allocate_Double()
    //     0xb16104: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb16108: add             x0, x0, #0x10
    //     0xb1610c: cmp             x2, x0
    //     0xb16110: b.ls            #0xb1615c
    //     0xb16114: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16118: sub             x0, x0, #0xf
    //     0xb1611c: mov             x2, #0xe19c
    //     0xb16120: movk            x2, #3, lsl #16
    //     0xb16124: stur            x2, [x0, #-1]
    // 0xb16128: dmb             ishst
    // 0xb1612c: StoreField: r0->field_7 = d0
    //     0xb1612c: stur            d0, [x0, #7]
    // 0xb16130: str             x0, [SP]
    // 0xb16134: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb16134: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb16138: r0 = constrainWidth()
    //     0xb16138: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb1613c: LeaveFrame
    //     0xb1613c: mov             SP, fp
    //     0xb16140: ldp             fp, lr, [SP], #0x10
    // 0xb16144: ret
    //     0xb16144: ret             
    // 0xb16148: LeaveFrame
    //     0xb16148: mov             SP, fp
    //     0xb1614c: ldp             fp, lr, [SP], #0x10
    // 0xb16150: ret
    //     0xb16150: ret             
    // 0xb16154: r0 = StackOverflowSharedWithFPURegs()
    //     0xb16154: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb16158: b               #0xb160a4
    // 0xb1615c: SaveReg d0
    //     0xb1615c: str             q0, [SP, #-0x10]!
    // 0xb16160: SaveReg r1
    //     0xb16160: str             x1, [SP, #-8]!
    // 0xb16164: r0 = AllocateDouble()
    //     0xb16164: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16168: RestoreReg r1
    //     0xb16168: ldr             x1, [SP], #8
    // 0xb1616c: RestoreReg d0
    //     0xb1616c: ldr             q0, [SP], #0x10
    // 0xb16170: b               #0xb1612c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb229b0, size: 0xf4
    // 0xb229b0: EnterFrame
    //     0xb229b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb229b4: mov             fp, SP
    // 0xb229b8: AllocStack(0x10)
    //     0xb229b8: sub             SP, SP, #0x10
    // 0xb229bc: d0 = inf
    //     0xb229bc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb229c0: mov             x0, x1
    // 0xb229c4: stur            x1, [fp, #-8]
    // 0xb229c8: CheckStackOverflow
    //     0xb229c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb229cc: cmp             SP, x16
    //     0xb229d0: b.ls            #0xb22a84
    // 0xb229d4: LoadField: r1 = r0->field_53
    //     0xb229d4: ldur            w1, [x0, #0x53]
    // 0xb229d8: DecompressPointer r1
    //     0xb229d8: add             x1, x1, HEAP, lsl #32
    // 0xb229dc: LoadField: d1 = r1->field_1f
    //     0xb229dc: ldur            d1, [x1, #0x1f]
    // 0xb229e0: fcmp            d0, d1
    // 0xb229e4: b.le            #0xb22a04
    // 0xb229e8: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb229e8: ldur            d2, [x1, #0x17]
    // 0xb229ec: fcmp            d2, d1
    // 0xb229f0: b.lt            #0xb22a04
    // 0xb229f4: mov             v0.16b, v2.16b
    // 0xb229f8: LeaveFrame
    //     0xb229f8: mov             SP, fp
    //     0xb229fc: ldp             fp, lr, [SP], #0x10
    // 0xb22a00: ret
    //     0xb22a00: ret             
    // 0xb22a04: mov             x1, x0
    // 0xb22a08: r0 = computeMinIntrinsicHeight()
    //     0xb22a08: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb22a0c: ldur            x0, [fp, #-8]
    // 0xb22a10: LoadField: r1 = r0->field_53
    //     0xb22a10: ldur            w1, [x0, #0x53]
    // 0xb22a14: DecompressPointer r1
    //     0xb22a14: add             x1, x1, HEAP, lsl #32
    // 0xb22a18: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb22a18: ldur            d1, [x1, #0x17]
    // 0xb22a1c: d2 = inf
    //     0xb22a1c: ldr             d2, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb22a20: fcmp            d1, d2
    // 0xb22a24: r16 = true
    //     0xb22a24: add             x16, NULL, #0x20  ; true
    // 0xb22a28: r17 = false
    //     0xb22a28: add             x17, NULL, #0x30  ; false
    // 0xb22a2c: csel            x0, x16, x17, ge
    // 0xb22a30: tbz             w0, #4, #0xb22a78
    // 0xb22a34: r0 = inline_Allocate_Double()
    //     0xb22a34: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb22a38: add             x0, x0, #0x10
    //     0xb22a3c: cmp             x2, x0
    //     0xb22a40: b.ls            #0xb22a8c
    //     0xb22a44: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22a48: sub             x0, x0, #0xf
    //     0xb22a4c: mov             x2, #0xe19c
    //     0xb22a50: movk            x2, #3, lsl #16
    //     0xb22a54: stur            x2, [x0, #-1]
    // 0xb22a58: dmb             ishst
    // 0xb22a5c: StoreField: r0->field_7 = d0
    //     0xb22a5c: stur            d0, [x0, #7]
    // 0xb22a60: str             x0, [SP]
    // 0xb22a64: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb22a64: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb22a68: r0 = constrainHeight()
    //     0xb22a68: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb22a6c: LeaveFrame
    //     0xb22a6c: mov             SP, fp
    //     0xb22a70: ldp             fp, lr, [SP], #0x10
    // 0xb22a74: ret
    //     0xb22a74: ret             
    // 0xb22a78: LeaveFrame
    //     0xb22a78: mov             SP, fp
    //     0xb22a7c: ldp             fp, lr, [SP], #0x10
    // 0xb22a80: ret
    //     0xb22a80: ret             
    // 0xb22a84: r0 = StackOverflowSharedWithFPURegs()
    //     0xb22a84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb22a88: b               #0xb229d4
    // 0xb22a8c: SaveReg d0
    //     0xb22a8c: str             q0, [SP, #-0x10]!
    // 0xb22a90: SaveReg r1
    //     0xb22a90: str             x1, [SP, #-8]!
    // 0xb22a94: r0 = AllocateDouble()
    //     0xb22a94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22a98: RestoreReg r1
    //     0xb22a98: ldr             x1, [SP], #8
    // 0xb22a9c: RestoreReg d0
    //     0xb22a9c: ldr             q0, [SP], #0x10
    // 0xb22aa0: b               #0xb22a5c
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb22aa4, size: 0x78
    // 0xb22aa4: EnterFrame
    //     0xb22aa4: stp             fp, lr, [SP, #-0x10]!
    //     0xb22aa8: mov             fp, SP
    // 0xb22aac: ldr             x0, [fp, #0x18]
    // 0xb22ab0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb22ab0: ldur            w1, [x0, #0x17]
    // 0xb22ab4: DecompressPointer r1
    //     0xb22ab4: add             x1, x1, HEAP, lsl #32
    // 0xb22ab8: CheckStackOverflow
    //     0xb22ab8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22abc: cmp             SP, x16
    //     0xb22ac0: b.ls            #0xb22b04
    // 0xb22ac4: ldr             x2, [fp, #0x10]
    // 0xb22ac8: r0 = computeMinIntrinsicHeight()
    //     0xb22ac8: bl              #0xb229b0  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicHeight
    // 0xb22acc: r0 = inline_Allocate_Double()
    //     0xb22acc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22ad0: add             x0, x0, #0x10
    //     0xb22ad4: cmp             x1, x0
    //     0xb22ad8: b.ls            #0xb22b0c
    //     0xb22adc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22ae0: sub             x0, x0, #0xf
    //     0xb22ae4: mov             x1, #0xe19c
    //     0xb22ae8: movk            x1, #3, lsl #16
    //     0xb22aec: stur            x1, [x0, #-1]
    // 0xb22af0: dmb             ishst
    // 0xb22af4: StoreField: r0->field_7 = d0
    //     0xb22af4: stur            d0, [x0, #7]
    // 0xb22af8: LeaveFrame
    //     0xb22af8: mov             SP, fp
    //     0xb22afc: ldp             fp, lr, [SP], #0x10
    // 0xb22b00: ret
    //     0xb22b00: ret             
    // 0xb22b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22b04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22b08: b               #0xb22ac4
    // 0xb22b0c: SaveReg d0
    //     0xb22b0c: str             q0, [SP, #-0x10]!
    // 0xb22b10: r0 = AllocateDouble()
    //     0xb22b10: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22b14: RestoreReg d0
    //     0xb22b14: ldr             q0, [SP], #0x10
    // 0xb22b18: b               #0xb22af4
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb295c0, size: 0xf4
    // 0xb295c0: EnterFrame
    //     0xb295c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb295c4: mov             fp, SP
    // 0xb295c8: AllocStack(0x10)
    //     0xb295c8: sub             SP, SP, #0x10
    // 0xb295cc: d0 = inf
    //     0xb295cc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb295d0: mov             x0, x1
    // 0xb295d4: stur            x1, [fp, #-8]
    // 0xb295d8: CheckStackOverflow
    //     0xb295d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb295dc: cmp             SP, x16
    //     0xb295e0: b.ls            #0xb29694
    // 0xb295e4: LoadField: r1 = r0->field_53
    //     0xb295e4: ldur            w1, [x0, #0x53]
    // 0xb295e8: DecompressPointer r1
    //     0xb295e8: add             x1, x1, HEAP, lsl #32
    // 0xb295ec: LoadField: d1 = r1->field_1f
    //     0xb295ec: ldur            d1, [x1, #0x1f]
    // 0xb295f0: fcmp            d0, d1
    // 0xb295f4: b.le            #0xb29614
    // 0xb295f8: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb295f8: ldur            d2, [x1, #0x17]
    // 0xb295fc: fcmp            d2, d1
    // 0xb29600: b.lt            #0xb29614
    // 0xb29604: mov             v0.16b, v2.16b
    // 0xb29608: LeaveFrame
    //     0xb29608: mov             SP, fp
    //     0xb2960c: ldp             fp, lr, [SP], #0x10
    // 0xb29610: ret
    //     0xb29610: ret             
    // 0xb29614: mov             x1, x0
    // 0xb29618: r0 = computeMaxIntrinsicHeight()
    //     0xb29618: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb2961c: ldur            x0, [fp, #-8]
    // 0xb29620: LoadField: r1 = r0->field_53
    //     0xb29620: ldur            w1, [x0, #0x53]
    // 0xb29624: DecompressPointer r1
    //     0xb29624: add             x1, x1, HEAP, lsl #32
    // 0xb29628: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb29628: ldur            d1, [x1, #0x17]
    // 0xb2962c: d2 = inf
    //     0xb2962c: ldr             d2, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb29630: fcmp            d1, d2
    // 0xb29634: r16 = true
    //     0xb29634: add             x16, NULL, #0x20  ; true
    // 0xb29638: r17 = false
    //     0xb29638: add             x17, NULL, #0x30  ; false
    // 0xb2963c: csel            x0, x16, x17, ge
    // 0xb29640: tbz             w0, #4, #0xb29688
    // 0xb29644: r0 = inline_Allocate_Double()
    //     0xb29644: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb29648: add             x0, x0, #0x10
    //     0xb2964c: cmp             x2, x0
    //     0xb29650: b.ls            #0xb2969c
    //     0xb29654: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29658: sub             x0, x0, #0xf
    //     0xb2965c: mov             x2, #0xe19c
    //     0xb29660: movk            x2, #3, lsl #16
    //     0xb29664: stur            x2, [x0, #-1]
    // 0xb29668: dmb             ishst
    // 0xb2966c: StoreField: r0->field_7 = d0
    //     0xb2966c: stur            d0, [x0, #7]
    // 0xb29670: str             x0, [SP]
    // 0xb29674: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb29674: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb29678: r0 = constrainHeight()
    //     0xb29678: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb2967c: LeaveFrame
    //     0xb2967c: mov             SP, fp
    //     0xb29680: ldp             fp, lr, [SP], #0x10
    // 0xb29684: ret
    //     0xb29684: ret             
    // 0xb29688: LeaveFrame
    //     0xb29688: mov             SP, fp
    //     0xb2968c: ldp             fp, lr, [SP], #0x10
    // 0xb29690: ret
    //     0xb29690: ret             
    // 0xb29694: r0 = StackOverflowSharedWithFPURegs()
    //     0xb29694: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb29698: b               #0xb295e4
    // 0xb2969c: SaveReg d0
    //     0xb2969c: str             q0, [SP, #-0x10]!
    // 0xb296a0: SaveReg r1
    //     0xb296a0: str             x1, [SP, #-8]!
    // 0xb296a4: r0 = AllocateDouble()
    //     0xb296a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb296a8: RestoreReg r1
    //     0xb296a8: ldr             x1, [SP], #8
    // 0xb296ac: RestoreReg d0
    //     0xb296ac: ldr             q0, [SP], #0x10
    // 0xb296b0: b               #0xb2966c
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb296b4, size: 0x78
    // 0xb296b4: EnterFrame
    //     0xb296b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb296b8: mov             fp, SP
    // 0xb296bc: ldr             x0, [fp, #0x18]
    // 0xb296c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb296c0: ldur            w1, [x0, #0x17]
    // 0xb296c4: DecompressPointer r1
    //     0xb296c4: add             x1, x1, HEAP, lsl #32
    // 0xb296c8: CheckStackOverflow
    //     0xb296c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb296cc: cmp             SP, x16
    //     0xb296d0: b.ls            #0xb29714
    // 0xb296d4: ldr             x2, [fp, #0x10]
    // 0xb296d8: r0 = computeMaxIntrinsicHeight()
    //     0xb296d8: bl              #0xb295c0  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicHeight
    // 0xb296dc: r0 = inline_Allocate_Double()
    //     0xb296dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb296e0: add             x0, x0, #0x10
    //     0xb296e4: cmp             x1, x0
    //     0xb296e8: b.ls            #0xb2971c
    //     0xb296ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xb296f0: sub             x0, x0, #0xf
    //     0xb296f4: mov             x1, #0xe19c
    //     0xb296f8: movk            x1, #3, lsl #16
    //     0xb296fc: stur            x1, [x0, #-1]
    // 0xb29700: dmb             ishst
    // 0xb29704: StoreField: r0->field_7 = d0
    //     0xb29704: stur            d0, [x0, #7]
    // 0xb29708: LeaveFrame
    //     0xb29708: mov             SP, fp
    //     0xb2970c: ldp             fp, lr, [SP], #0x10
    // 0xb29710: ret
    //     0xb29710: ret             
    // 0xb29714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29718: b               #0xb296d4
    // 0xb2971c: SaveReg d0
    //     0xb2971c: str             q0, [SP, #-0x10]!
    // 0xb29720: r0 = AllocateDouble()
    //     0xb29720: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29724: RestoreReg d0
    //     0xb29724: ldr             q0, [SP], #0x10
    // 0xb29728: b               #0xb29704
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2c8ac, size: 0xf4
    // 0xb2c8ac: EnterFrame
    //     0xb2c8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c8b0: mov             fp, SP
    // 0xb2c8b4: AllocStack(0x10)
    //     0xb2c8b4: sub             SP, SP, #0x10
    // 0xb2c8b8: d0 = inf
    //     0xb2c8b8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c8bc: mov             x0, x1
    // 0xb2c8c0: stur            x1, [fp, #-8]
    // 0xb2c8c4: CheckStackOverflow
    //     0xb2c8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c8c8: cmp             SP, x16
    //     0xb2c8cc: b.ls            #0xb2c980
    // 0xb2c8d0: LoadField: r1 = r0->field_53
    //     0xb2c8d0: ldur            w1, [x0, #0x53]
    // 0xb2c8d4: DecompressPointer r1
    //     0xb2c8d4: add             x1, x1, HEAP, lsl #32
    // 0xb2c8d8: LoadField: d1 = r1->field_f
    //     0xb2c8d8: ldur            d1, [x1, #0xf]
    // 0xb2c8dc: fcmp            d0, d1
    // 0xb2c8e0: b.le            #0xb2c900
    // 0xb2c8e4: LoadField: d2 = r1->field_7
    //     0xb2c8e4: ldur            d2, [x1, #7]
    // 0xb2c8e8: fcmp            d2, d1
    // 0xb2c8ec: b.lt            #0xb2c900
    // 0xb2c8f0: mov             v0.16b, v2.16b
    // 0xb2c8f4: LeaveFrame
    //     0xb2c8f4: mov             SP, fp
    //     0xb2c8f8: ldp             fp, lr, [SP], #0x10
    // 0xb2c8fc: ret
    //     0xb2c8fc: ret             
    // 0xb2c900: mov             x1, x0
    // 0xb2c904: r0 = computeMaxIntrinsicWidth()
    //     0xb2c904: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2c908: ldur            x0, [fp, #-8]
    // 0xb2c90c: LoadField: r1 = r0->field_53
    //     0xb2c90c: ldur            w1, [x0, #0x53]
    // 0xb2c910: DecompressPointer r1
    //     0xb2c910: add             x1, x1, HEAP, lsl #32
    // 0xb2c914: LoadField: d1 = r1->field_7
    //     0xb2c914: ldur            d1, [x1, #7]
    // 0xb2c918: d2 = inf
    //     0xb2c918: ldr             d2, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c91c: fcmp            d1, d2
    // 0xb2c920: r16 = true
    //     0xb2c920: add             x16, NULL, #0x20  ; true
    // 0xb2c924: r17 = false
    //     0xb2c924: add             x17, NULL, #0x30  ; false
    // 0xb2c928: csel            x0, x16, x17, ge
    // 0xb2c92c: tbz             w0, #4, #0xb2c974
    // 0xb2c930: r0 = inline_Allocate_Double()
    //     0xb2c930: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb2c934: add             x0, x0, #0x10
    //     0xb2c938: cmp             x2, x0
    //     0xb2c93c: b.ls            #0xb2c988
    //     0xb2c940: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2c944: sub             x0, x0, #0xf
    //     0xb2c948: mov             x2, #0xe19c
    //     0xb2c94c: movk            x2, #3, lsl #16
    //     0xb2c950: stur            x2, [x0, #-1]
    // 0xb2c954: dmb             ishst
    // 0xb2c958: StoreField: r0->field_7 = d0
    //     0xb2c958: stur            d0, [x0, #7]
    // 0xb2c95c: str             x0, [SP]
    // 0xb2c960: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb2c960: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb2c964: r0 = constrainWidth()
    //     0xb2c964: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb2c968: LeaveFrame
    //     0xb2c968: mov             SP, fp
    //     0xb2c96c: ldp             fp, lr, [SP], #0x10
    // 0xb2c970: ret
    //     0xb2c970: ret             
    // 0xb2c974: LeaveFrame
    //     0xb2c974: mov             SP, fp
    //     0xb2c978: ldp             fp, lr, [SP], #0x10
    // 0xb2c97c: ret
    //     0xb2c97c: ret             
    // 0xb2c980: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2c980: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2c984: b               #0xb2c8d0
    // 0xb2c988: SaveReg d0
    //     0xb2c988: str             q0, [SP, #-0x10]!
    // 0xb2c98c: SaveReg r1
    //     0xb2c98c: str             x1, [SP, #-8]!
    // 0xb2c990: r0 = AllocateDouble()
    //     0xb2c990: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2c994: RestoreReg r1
    //     0xb2c994: ldr             x1, [SP], #8
    // 0xb2c998: RestoreReg d0
    //     0xb2c998: ldr             q0, [SP], #0x10
    // 0xb2c99c: b               #0xb2c958
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2c9a0, size: 0x78
    // 0xb2c9a0: EnterFrame
    //     0xb2c9a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c9a4: mov             fp, SP
    // 0xb2c9a8: ldr             x0, [fp, #0x18]
    // 0xb2c9ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2c9ac: ldur            w1, [x0, #0x17]
    // 0xb2c9b0: DecompressPointer r1
    //     0xb2c9b0: add             x1, x1, HEAP, lsl #32
    // 0xb2c9b4: CheckStackOverflow
    //     0xb2c9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c9b8: cmp             SP, x16
    //     0xb2c9bc: b.ls            #0xb2ca00
    // 0xb2c9c0: ldr             x2, [fp, #0x10]
    // 0xb2c9c4: r0 = computeMaxIntrinsicWidth()
    //     0xb2c9c4: bl              #0xb2c8ac  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicWidth
    // 0xb2c9c8: r0 = inline_Allocate_Double()
    //     0xb2c9c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2c9cc: add             x0, x0, #0x10
    //     0xb2c9d0: cmp             x1, x0
    //     0xb2c9d4: b.ls            #0xb2ca08
    //     0xb2c9d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2c9dc: sub             x0, x0, #0xf
    //     0xb2c9e0: mov             x1, #0xe19c
    //     0xb2c9e4: movk            x1, #3, lsl #16
    //     0xb2c9e8: stur            x1, [x0, #-1]
    // 0xb2c9ec: dmb             ishst
    // 0xb2c9f0: StoreField: r0->field_7 = d0
    //     0xb2c9f0: stur            d0, [x0, #7]
    // 0xb2c9f4: LeaveFrame
    //     0xb2c9f4: mov             SP, fp
    //     0xb2c9f8: ldp             fp, lr, [SP], #0x10
    // 0xb2c9fc: ret
    //     0xb2c9fc: ret             
    // 0xb2ca00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ca00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ca04: b               #0xb2c9c0
    // 0xb2ca08: SaveReg d0
    //     0xb2ca08: str             q0, [SP, #-0x10]!
    // 0xb2ca0c: r0 = AllocateDouble()
    //     0xb2ca0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ca10: RestoreReg d0
    //     0xb2ca10: ldr             q0, [SP], #0x10
    // 0xb2ca14: b               #0xb2c9f0
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4a3c8, size: 0x9c
    // 0xb4a3c8: EnterFrame
    //     0xb4a3c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a3cc: mov             fp, SP
    // 0xb4a3d0: AllocStack(0x18)
    //     0xb4a3d0: sub             SP, SP, #0x18
    // 0xb4a3d4: SetupParameters(RenderConstrainedBox this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xb4a3d4: mov             x3, x1
    //     0xb4a3d8: mov             x0, x2
    //     0xb4a3dc: stur            x1, [fp, #-0x10]
    //     0xb4a3e0: stur            x2, [fp, #-0x18]
    // 0xb4a3e4: CheckStackOverflow
    //     0xb4a3e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4a3e8: cmp             SP, x16
    //     0xb4a3ec: b.ls            #0xb4a45c
    // 0xb4a3f0: LoadField: r4 = r3->field_4f
    //     0xb4a3f0: ldur            w4, [x3, #0x4f]
    // 0xb4a3f4: DecompressPointer r4
    //     0xb4a3f4: add             x4, x4, HEAP, lsl #32
    // 0xb4a3f8: stur            x4, [fp, #-8]
    // 0xb4a3fc: cmp             w4, NULL
    // 0xb4a400: b.ne            #0xb4a40c
    // 0xb4a404: r0 = Null
    //     0xb4a404: mov             x0, NULL
    // 0xb4a408: b               #0xb4a428
    // 0xb4a40c: LoadField: r1 = r3->field_53
    //     0xb4a40c: ldur            w1, [x3, #0x53]
    // 0xb4a410: DecompressPointer r1
    //     0xb4a410: add             x1, x1, HEAP, lsl #32
    // 0xb4a414: mov             x2, x0
    // 0xb4a418: r0 = enforce()
    //     0xb4a418: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb4a41c: ldur            x1, [fp, #-8]
    // 0xb4a420: mov             x2, x0
    // 0xb4a424: r0 = getDryLayout()
    //     0xb4a424: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4a428: cmp             w0, NULL
    // 0xb4a42c: b.ne            #0xb4a450
    // 0xb4a430: ldur            x0, [fp, #-0x10]
    // 0xb4a434: LoadField: r1 = r0->field_53
    //     0xb4a434: ldur            w1, [x0, #0x53]
    // 0xb4a438: DecompressPointer r1
    //     0xb4a438: add             x1, x1, HEAP, lsl #32
    // 0xb4a43c: ldur            x2, [fp, #-0x18]
    // 0xb4a440: r0 = enforce()
    //     0xb4a440: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb4a444: mov             x1, x0
    // 0xb4a448: r2 = Instance_Size
    //     0xb4a448: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb4a44c: r0 = constrain()
    //     0xb4a44c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4a450: LeaveFrame
    //     0xb4a450: mov             SP, fp
    //     0xb4a454: ldp             fp, lr, [SP], #0x10
    // 0xb4a458: ret
    //     0xb4a458: ret             
    // 0xb4a45c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4a45c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4a460: b               #0xb4a3f0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb57f04, size: 0x24
    // 0xb57f04: EnterFrame
    //     0xb57f04: stp             fp, lr, [SP, #-0x10]!
    //     0xb57f08: mov             fp, SP
    // 0xb57f0c: ldr             x2, [fp, #0x10]
    // 0xb57f10: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb57f10: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43d8] AnonymousClosure: (0xb2c9a0), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicWidth (0xb2c8ac)
    //     0xb57f14: ldr             x1, [x1, #0x3d8]
    // 0xb57f18: r0 = AllocateClosure()
    //     0xb57f18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57f1c: LeaveFrame
    //     0xb57f1c: mov             SP, fp
    //     0xb57f20: ldp             fp, lr, [SP], #0x10
    // 0xb57f24: ret
    //     0xb57f24: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e218, size: 0x24
    // 0xb5e218: EnterFrame
    //     0xb5e218: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e21c: mov             fp, SP
    // 0xb5e220: ldr             x2, [fp, #0x10]
    // 0xb5e224: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e224: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a610] AnonymousClosure: (0xb296b4), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicHeight (0xb295c0)
    //     0xb5e228: ldr             x1, [x1, #0x610]
    // 0xb5e22c: r0 = AllocateClosure()
    //     0xb5e22c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e230: LeaveFrame
    //     0xb5e230: mov             SP, fp
    //     0xb5e234: ldp             fp, lr, [SP], #0x10
    // 0xb5e238: ret
    //     0xb5e238: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5f680, size: 0xb8
    // 0xb5f680: EnterFrame
    //     0xb5f680: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f684: mov             fp, SP
    // 0xb5f688: AllocStack(0x20)
    //     0xb5f688: sub             SP, SP, #0x20
    // 0xb5f68c: SetupParameters(RenderConstrainedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5f68c: mov             x5, x1
    //     0xb5f690: mov             x4, x2
    //     0xb5f694: stur            x1, [fp, #-8]
    //     0xb5f698: stur            x2, [fp, #-0x10]
    //     0xb5f69c: stur            x3, [fp, #-0x18]
    // 0xb5f6a0: CheckStackOverflow
    //     0xb5f6a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f6a4: cmp             SP, x16
    //     0xb5f6a8: b.ls            #0xb5f730
    // 0xb5f6ac: mov             x0, x4
    // 0xb5f6b0: r2 = Null
    //     0xb5f6b0: mov             x2, NULL
    // 0xb5f6b4: r1 = Null
    //     0xb5f6b4: mov             x1, NULL
    // 0xb5f6b8: r4 = 60
    //     0xb5f6b8: mov             x4, #0x3c
    // 0xb5f6bc: branchIfSmi(r0, 0xb5f6c8)
    //     0xb5f6bc: tbz             w0, #0, #0xb5f6c8
    // 0xb5f6c0: r4 = LoadClassIdInstr(r0)
    //     0xb5f6c0: ldur            x4, [x0, #-1]
    //     0xb5f6c4: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f6c8: sub             x4, x4, #0xb46
    // 0xb5f6cc: cmp             x4, #1
    // 0xb5f6d0: b.ls            #0xb5f6e4
    // 0xb5f6d4: r8 = BoxConstraints
    //     0xb5f6d4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5f6d8: r3 = Null
    //     0xb5f6d8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a618] Null
    //     0xb5f6dc: ldr             x3, [x3, #0x618]
    // 0xb5f6e0: r0 = BoxConstraints()
    //     0xb5f6e0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5f6e4: ldur            x0, [fp, #-8]
    // 0xb5f6e8: LoadField: r3 = r0->field_4f
    //     0xb5f6e8: ldur            w3, [x0, #0x4f]
    // 0xb5f6ec: DecompressPointer r3
    //     0xb5f6ec: add             x3, x3, HEAP, lsl #32
    // 0xb5f6f0: stur            x3, [fp, #-0x20]
    // 0xb5f6f4: cmp             w3, NULL
    // 0xb5f6f8: b.ne            #0xb5f704
    // 0xb5f6fc: r0 = Null
    //     0xb5f6fc: mov             x0, NULL
    // 0xb5f700: b               #0xb5f724
    // 0xb5f704: LoadField: r1 = r0->field_53
    //     0xb5f704: ldur            w1, [x0, #0x53]
    // 0xb5f708: DecompressPointer r1
    //     0xb5f708: add             x1, x1, HEAP, lsl #32
    // 0xb5f70c: ldur            x2, [fp, #-0x10]
    // 0xb5f710: r0 = enforce()
    //     0xb5f710: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb5f714: ldur            x1, [fp, #-0x20]
    // 0xb5f718: mov             x2, x0
    // 0xb5f71c: ldur            x3, [fp, #-0x18]
    // 0xb5f720: r0 = getDryBaseline()
    //     0xb5f720: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb5f724: LeaveFrame
    //     0xb5f724: mov             SP, fp
    //     0xb5f728: ldp             fp, lr, [SP], #0x10
    // 0xb5f72c: ret
    //     0xb5f72c: ret             
    // 0xb5f730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f734: b               #0xb5f6ac
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb8b74, size: 0x178
    // 0xbb8b74: EnterFrame
    //     0xbb8b74: stp             fp, lr, [SP, #-0x10]!
    //     0xbb8b78: mov             fp, SP
    // 0xbb8b7c: AllocStack(0x20)
    //     0xbb8b7c: sub             SP, SP, #0x20
    // 0xbb8b80: SetupParameters(RenderConstrainedBox this /* r1 => r3, fp-0x10 */)
    //     0xbb8b80: mov             x3, x1
    //     0xbb8b84: stur            x1, [fp, #-0x10]
    // 0xbb8b88: CheckStackOverflow
    //     0xbb8b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb8b8c: cmp             SP, x16
    //     0xbb8b90: b.ls            #0xbb8ce0
    // 0xbb8b94: LoadField: r4 = r3->field_27
    //     0xbb8b94: ldur            w4, [x3, #0x27]
    // 0xbb8b98: DecompressPointer r4
    //     0xbb8b98: add             x4, x4, HEAP, lsl #32
    // 0xbb8b9c: stur            x4, [fp, #-8]
    // 0xbb8ba0: cmp             w4, NULL
    // 0xbb8ba4: b.eq            #0xbb8cc4
    // 0xbb8ba8: mov             x0, x4
    // 0xbb8bac: r2 = Null
    //     0xbb8bac: mov             x2, NULL
    // 0xbb8bb0: r1 = Null
    //     0xbb8bb0: mov             x1, NULL
    // 0xbb8bb4: r4 = LoadClassIdInstr(r0)
    //     0xbb8bb4: ldur            x4, [x0, #-1]
    //     0xbb8bb8: ubfx            x4, x4, #0xc, #0x14
    // 0xbb8bbc: sub             x4, x4, #0xb46
    // 0xbb8bc0: cmp             x4, #1
    // 0xbb8bc4: b.ls            #0xbb8bd8
    // 0xbb8bc8: r8 = BoxConstraints
    //     0xbb8bc8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb8bcc: r3 = Null
    //     0xbb8bcc: add             x3, PP, #0x15, lsl #12  ; [pp+0x155b0] Null
    //     0xbb8bd0: ldr             x3, [x3, #0x5b0]
    // 0xbb8bd4: r0 = BoxConstraints()
    //     0xbb8bd4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb8bd8: ldur            x0, [fp, #-0x10]
    // 0xbb8bdc: LoadField: r3 = r0->field_4f
    //     0xbb8bdc: ldur            w3, [x0, #0x4f]
    // 0xbb8be0: DecompressPointer r3
    //     0xbb8be0: add             x3, x3, HEAP, lsl #32
    // 0xbb8be4: stur            x3, [fp, #-0x18]
    // 0xbb8be8: cmp             w3, NULL
    // 0xbb8bec: b.eq            #0xbb8c74
    // 0xbb8bf0: LoadField: r1 = r0->field_53
    //     0xbb8bf0: ldur            w1, [x0, #0x53]
    // 0xbb8bf4: DecompressPointer r1
    //     0xbb8bf4: add             x1, x1, HEAP, lsl #32
    // 0xbb8bf8: ldur            x2, [fp, #-8]
    // 0xbb8bfc: r0 = enforce()
    //     0xbb8bfc: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xbb8c00: ldur            x1, [fp, #-0x18]
    // 0xbb8c04: r2 = LoadClassIdInstr(r1)
    //     0xbb8c04: ldur            x2, [x1, #-1]
    //     0xbb8c08: ubfx            x2, x2, #0xc, #0x14
    // 0xbb8c0c: r16 = true
    //     0xbb8c0c: add             x16, NULL, #0x20  ; true
    // 0xbb8c10: str             x16, [SP]
    // 0xbb8c14: mov             x16, x0
    // 0xbb8c18: mov             x0, x2
    // 0xbb8c1c: mov             x2, x16
    // 0xbb8c20: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbb8c20: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbb8c24: ldr             x4, [x4, #0xed0]
    // 0xbb8c28: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb8c28: mov             x17, #0xe6b9
    //     0xbb8c2c: add             lr, x0, x17
    //     0xbb8c30: ldr             lr, [x21, lr, lsl #3]
    //     0xbb8c34: blr             lr
    // 0xbb8c38: ldur            x0, [fp, #-0x10]
    // 0xbb8c3c: LoadField: r1 = r0->field_4f
    //     0xbb8c3c: ldur            w1, [x0, #0x4f]
    // 0xbb8c40: DecompressPointer r1
    //     0xbb8c40: add             x1, x1, HEAP, lsl #32
    // 0xbb8c44: cmp             w1, NULL
    // 0xbb8c48: b.eq            #0xbb8ce8
    // 0xbb8c4c: r0 = size()
    //     0xbb8c4c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8c50: ldur            x3, [fp, #-0x10]
    // 0xbb8c54: StoreField: r3->field_4b = r0
    //     0xbb8c54: stur            w0, [x3, #0x4b]
    //     0xbb8c58: ldurb           w16, [x3, #-1]
    //     0xbb8c5c: ldurb           w17, [x0, #-1]
    //     0xbb8c60: and             x16, x17, x16, lsr #2
    //     0xbb8c64: tst             x16, HEAP, lsr #32
    //     0xbb8c68: b.eq            #0xbb8c70
    //     0xbb8c6c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbb8c70: b               #0xbb8cb4
    // 0xbb8c74: mov             x3, x0
    // 0xbb8c78: LoadField: r1 = r3->field_53
    //     0xbb8c78: ldur            w1, [x3, #0x53]
    // 0xbb8c7c: DecompressPointer r1
    //     0xbb8c7c: add             x1, x1, HEAP, lsl #32
    // 0xbb8c80: ldur            x2, [fp, #-8]
    // 0xbb8c84: r0 = enforce()
    //     0xbb8c84: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xbb8c88: mov             x1, x0
    // 0xbb8c8c: r2 = Instance_Size
    //     0xbb8c8c: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xbb8c90: r0 = constrain()
    //     0xbb8c90: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbb8c94: ldur            x1, [fp, #-0x10]
    // 0xbb8c98: StoreField: r1->field_4b = r0
    //     0xbb8c98: stur            w0, [x1, #0x4b]
    //     0xbb8c9c: ldurb           w16, [x1, #-1]
    //     0xbb8ca0: ldurb           w17, [x0, #-1]
    //     0xbb8ca4: and             x16, x17, x16, lsr #2
    //     0xbb8ca8: tst             x16, HEAP, lsr #32
    //     0xbb8cac: b.eq            #0xbb8cb4
    //     0xbb8cb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb8cb4: r0 = Null
    //     0xbb8cb4: mov             x0, NULL
    // 0xbb8cb8: LeaveFrame
    //     0xbb8cb8: mov             SP, fp
    //     0xbb8cbc: ldp             fp, lr, [SP], #0x10
    // 0xbb8cc0: ret
    //     0xbb8cc0: ret             
    // 0xbb8cc4: r0 = StateError()
    //     0xbb8cc4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb8cc8: mov             x1, x0
    // 0xbb8ccc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb8ccc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb8cd0: StoreField: r1->field_b = r0
    //     0xbb8cd0: stur            w0, [x1, #0xb]
    // 0xbb8cd4: mov             x0, x1
    // 0xbb8cd8: r0 = Throw()
    //     0xbb8cd8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb8cdc: brk             #0
    // 0xbb8ce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb8ce0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb8ce4: b               #0xbb8b94
    // 0xbb8ce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb8ce8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ additionalConstraints=(/* No info */) {
    // ** addr: 0xcf7f84, size: 0x154
    // 0xcf7f84: EnterFrame
    //     0xcf7f84: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7f88: mov             fp, SP
    // 0xcf7f8c: AllocStack(0x28)
    //     0xcf7f8c: sub             SP, SP, #0x28
    // 0xcf7f90: SetupParameters(RenderConstrainedBox this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf7f90: mov             x0, x2
    //     0xcf7f94: stur            x1, [fp, #-0x10]
    //     0xcf7f98: stur            x2, [fp, #-0x18]
    // 0xcf7f9c: CheckStackOverflow
    //     0xcf7f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7fa0: cmp             SP, x16
    //     0xcf7fa4: b.ls            #0xcf80d0
    // 0xcf7fa8: LoadField: r2 = r1->field_53
    //     0xcf7fa8: ldur            w2, [x1, #0x53]
    // 0xcf7fac: DecompressPointer r2
    //     0xcf7fac: add             x2, x2, HEAP, lsl #32
    // 0xcf7fb0: stur            x2, [fp, #-8]
    // 0xcf7fb4: r3 = LoadClassIdInstr(r2)
    //     0xcf7fb4: ldur            x3, [x2, #-1]
    //     0xcf7fb8: ubfx            x3, x3, #0xc, #0x14
    // 0xcf7fbc: cmp             x3, #0xb46
    // 0xcf7fc0: b.ne            #0xcf802c
    // 0xcf7fc4: cmp             w2, w0
    // 0xcf7fc8: b.eq            #0xcf808c
    // 0xcf7fcc: stp             x2, x0, [SP]
    // 0xcf7fd0: r0 = _haveSameRuntimeType()
    //     0xcf7fd0: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcf7fd4: tbz             w0, #4, #0xcf7fe0
    // 0xcf7fd8: ldur            x0, [fp, #-0x18]
    // 0xcf7fdc: b               #0xcf809c
    // 0xcf7fe0: ldur            x0, [fp, #-0x18]
    // 0xcf7fe4: ldur            x1, [fp, #-8]
    // 0xcf7fe8: LoadField: d0 = r0->field_7
    //     0xcf7fe8: ldur            d0, [x0, #7]
    // 0xcf7fec: LoadField: d1 = r1->field_7
    //     0xcf7fec: ldur            d1, [x1, #7]
    // 0xcf7ff0: fcmp            d0, d1
    // 0xcf7ff4: b.ne            #0xcf809c
    // 0xcf7ff8: LoadField: d0 = r0->field_f
    //     0xcf7ff8: ldur            d0, [x0, #0xf]
    // 0xcf7ffc: LoadField: d1 = r1->field_f
    //     0xcf7ffc: ldur            d1, [x1, #0xf]
    // 0xcf8000: fcmp            d0, d1
    // 0xcf8004: b.ne            #0xcf809c
    // 0xcf8008: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcf8008: ldur            d0, [x0, #0x17]
    // 0xcf800c: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xcf800c: ldur            d1, [x1, #0x17]
    // 0xcf8010: fcmp            d0, d1
    // 0xcf8014: b.ne            #0xcf809c
    // 0xcf8018: LoadField: d0 = r0->field_1f
    //     0xcf8018: ldur            d0, [x0, #0x1f]
    // 0xcf801c: LoadField: d1 = r1->field_1f
    //     0xcf801c: ldur            d1, [x1, #0x1f]
    // 0xcf8020: fcmp            d0, d1
    // 0xcf8024: b.ne            #0xcf809c
    // 0xcf8028: b               #0xcf808c
    // 0xcf802c: mov             x1, x2
    // 0xcf8030: stp             x0, x1, [SP]
    // 0xcf8034: r0 = ==()
    //     0xcf8034: bl              #0x1299aec  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0xcf8038: tbz             w0, #4, #0xcf8044
    // 0xcf803c: ldur            x0, [fp, #-0x18]
    // 0xcf8040: b               #0xcf809c
    // 0xcf8044: ldur            x0, [fp, #-0x18]
    // 0xcf8048: r1 = LoadClassIdInstr(r0)
    //     0xcf8048: ldur            x1, [x0, #-1]
    //     0xcf804c: ubfx            x1, x1, #0xc, #0x14
    // 0xcf8050: cmp             x1, #0xb47
    // 0xcf8054: b.ne            #0xcf809c
    // 0xcf8058: ldur            x1, [fp, #-8]
    // 0xcf805c: LoadField: d0 = r0->field_37
    //     0xcf805c: ldur            d0, [x0, #0x37]
    // 0xcf8060: LoadField: d1 = r1->field_37
    //     0xcf8060: ldur            d1, [x1, #0x37]
    // 0xcf8064: fcmp            d0, d1
    // 0xcf8068: b.ne            #0xcf809c
    // 0xcf806c: LoadField: d0 = r0->field_27
    //     0xcf806c: ldur            d0, [x0, #0x27]
    // 0xcf8070: LoadField: d1 = r1->field_27
    //     0xcf8070: ldur            d1, [x1, #0x27]
    // 0xcf8074: fcmp            d0, d1
    // 0xcf8078: b.ne            #0xcf809c
    // 0xcf807c: LoadField: d0 = r0->field_2f
    //     0xcf807c: ldur            d0, [x0, #0x2f]
    // 0xcf8080: LoadField: d1 = r1->field_2f
    //     0xcf8080: ldur            d1, [x1, #0x2f]
    // 0xcf8084: fcmp            d0, d1
    // 0xcf8088: b.ne            #0xcf809c
    // 0xcf808c: r0 = Null
    //     0xcf808c: mov             x0, NULL
    // 0xcf8090: LeaveFrame
    //     0xcf8090: mov             SP, fp
    //     0xcf8094: ldp             fp, lr, [SP], #0x10
    // 0xcf8098: ret
    //     0xcf8098: ret             
    // 0xcf809c: ldur            x1, [fp, #-0x10]
    // 0xcf80a0: StoreField: r1->field_53 = r0
    //     0xcf80a0: stur            w0, [x1, #0x53]
    //     0xcf80a4: ldurb           w16, [x1, #-1]
    //     0xcf80a8: ldurb           w17, [x0, #-1]
    //     0xcf80ac: and             x16, x17, x16, lsr #2
    //     0xcf80b0: tst             x16, HEAP, lsr #32
    //     0xcf80b4: b.eq            #0xcf80bc
    //     0xcf80b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf80bc: r0 = markNeedsLayout()
    //     0xcf80bc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf80c0: r0 = Null
    //     0xcf80c0: mov             x0, NULL
    // 0xcf80c4: LeaveFrame
    //     0xcf80c4: mov             SP, fp
    //     0xcf80c8: ldp             fp, lr, [SP], #0x10
    // 0xcf80cc: ret
    //     0xcf80cc: ret             
    // 0xcf80d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf80d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf80d4: b               #0xcf7fa8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efa24, size: 0x24
    // 0x10efa24: EnterFrame
    //     0x10efa24: stp             fp, lr, [SP, #-0x10]!
    //     0x10efa28: mov             fp, SP
    // 0x10efa2c: ldr             x2, [fp, #0x10]
    // 0x10efa30: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efa30: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa43d0] AnonymousClosure: (0xb22aa4), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicHeight (0xb229b0)
    //     0x10efa34: ldr             x1, [x1, #0x3d0]
    // 0x10efa38: r0 = AllocateClosure()
    //     0x10efa38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efa3c: LeaveFrame
    //     0x10efa3c: mov             SP, fp
    //     0x10efa40: ldp             fp, lr, [SP], #0x10
    // 0x10efa44: ret
    //     0x10efa44: ret             
  }
}

// class id: 4966, size: 0x84, field offset: 0x84
class RenderSemanticsAnnotations extends _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin {

  _ RenderSemanticsAnnotations(/* No info */) {
    // ** addr: 0x11d1fac, size: 0x78
    // 0x11d1fac: EnterFrame
    //     0x11d1fac: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1fb0: mov             fp, SP
    // 0x11d1fb4: AllocStack(0x38)
    //     0x11d1fb4: sub             SP, SP, #0x38
    // 0x11d1fb8: SetupParameters(RenderSemanticsAnnotations this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x11d1fb8: mov             x0, x1
    //     0x11d1fbc: stur            x1, [fp, #-8]
    //     0x11d1fc0: stur            x2, [fp, #-0x10]
    //     0x11d1fc4: stur            x3, [fp, #-0x18]
    //     0x11d1fc8: stur            x5, [fp, #-0x20]
    //     0x11d1fcc: stur            x6, [fp, #-0x28]
    //     0x11d1fd0: stur            x7, [fp, #-0x30]
    // 0x11d1fd4: CheckStackOverflow
    //     0x11d1fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1fd8: cmp             SP, x16
    //     0x11d1fdc: b.ls            #0x11d201c
    // 0x11d1fe0: mov             x1, x0
    // 0x11d1fe4: r0 = _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin()
    //     0x11d1fe4: bl              #0x11d20e8  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::_MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin
    // 0x11d1fe8: ldr             x16, [fp, #0x10]
    // 0x11d1fec: str             x16, [SP]
    // 0x11d1ff0: ldur            x1, [fp, #-8]
    // 0x11d1ff4: ldur            x2, [fp, #-0x10]
    // 0x11d1ff8: ldur            x3, [fp, #-0x18]
    // 0x11d1ffc: ldur            x5, [fp, #-0x20]
    // 0x11d2000: ldur            x6, [fp, #-0x28]
    // 0x11d2004: ldur            x7, [fp, #-0x30]
    // 0x11d2008: r0 = initSemanticsAnnotations()
    //     0x11d2008: bl              #0x11d2024  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::initSemanticsAnnotations
    // 0x11d200c: r0 = Null
    //     0x11d200c: mov             x0, NULL
    // 0x11d2010: LeaveFrame
    //     0x11d2010: mov             SP, fp
    //     0x11d2014: ldp             fp, lr, [SP], #0x10
    // 0x11d2018: ret
    //     0x11d2018: ret             
    // 0x11d201c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d201c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2020: b               #0x11d1fe0
  }
}

// class id: 4968, size: 0x64, field offset: 0x64
class RenderAnimatedOpacity extends _MixinApplication441&RenderProxyBox&RenderAnimatedOpacityMixin {

  _ RenderAnimatedOpacity(/* No info */) {
    // ** addr: 0x11d3cb0, size: 0xa0
    // 0x11d3cb0: EnterFrame
    //     0x11d3cb0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d3cb4: mov             fp, SP
    // 0x11d3cb8: AllocStack(0x10)
    //     0x11d3cb8: sub             SP, SP, #0x10
    // 0x11d3cbc: SetupParameters(RenderAnimatedOpacity this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11d3cbc: stur            x1, [fp, #-8]
    //     0x11d3cc0: stur            x2, [fp, #-0x10]
    // 0x11d3cc4: CheckStackOverflow
    //     0x11d3cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d3cc8: cmp             SP, x16
    //     0x11d3ccc: b.ls            #0x11d3d48
    // 0x11d3cd0: r0 = _LayoutCacheStorage()
    //     0x11d3cd0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d3cd4: ldur            x2, [fp, #-8]
    // 0x11d3cd8: StoreField: r2->field_47 = r0
    //     0x11d3cd8: stur            w0, [x2, #0x47]
    //     0x11d3cdc: ldurb           w16, [x2, #-1]
    //     0x11d3ce0: ldurb           w17, [x0, #-1]
    //     0x11d3ce4: and             x16, x17, x16, lsr #2
    //     0x11d3ce8: tst             x16, HEAP, lsr #32
    //     0x11d3cec: b.eq            #0x11d3cf4
    //     0x11d3cf0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d3cf4: mov             x1, x2
    // 0x11d3cf8: r0 = RenderObject()
    //     0x11d3cf8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d3cfc: ldur            x1, [fp, #-8]
    // 0x11d3d00: r2 = Null
    //     0x11d3d00: mov             x2, NULL
    // 0x11d3d04: r0 = child=()
    //     0x11d3d04: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d3d08: ldur            x1, [fp, #-8]
    // 0x11d3d0c: ldur            x2, [fp, #-0x10]
    // 0x11d3d10: r0 = opacity=()
    //     0x11d3d10: bl              #0xcfd4d0  ; [dart:mixin_deduplication] _MixinApplication441&RenderProxyBox&RenderAnimatedOpacityMixin::opacity=
    // 0x11d3d14: ldur            x1, [fp, #-8]
    // 0x11d3d18: LoadField: r0 = r1->field_5f
    //     0x11d3d18: ldur            w0, [x1, #0x5f]
    // 0x11d3d1c: DecompressPointer r0
    //     0x11d3d1c: add             x0, x0, HEAP, lsl #32
    // 0x11d3d20: r16 = false
    //     0x11d3d20: add             x16, NULL, #0x30  ; false
    // 0x11d3d24: cmp             w0, w16
    // 0x11d3d28: b.eq            #0x11d3d38
    // 0x11d3d2c: r0 = false
    //     0x11d3d2c: add             x0, NULL, #0x30  ; false
    // 0x11d3d30: StoreField: r1->field_5f = r0
    //     0x11d3d30: stur            w0, [x1, #0x5f]
    // 0x11d3d34: r0 = markNeedsSemanticsUpdate()
    //     0x11d3d34: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x11d3d38: r0 = Null
    //     0x11d3d38: mov             x0, NULL
    // 0x11d3d3c: LeaveFrame
    //     0x11d3d3c: mov             SP, fp
    //     0x11d3d40: ldp             fp, lr, [SP], #0x10
    // 0x11d3d44: ret
    //     0x11d3d44: ret             
    // 0x11d3d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d3d48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d3d4c: b               #0x11d3cd0
  }
}

// class id: 8229, size: 0x14, field offset: 0x14
enum DecorationPosition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab098, size: 0x64
    // 0x11ab098: EnterFrame
    //     0x11ab098: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab09c: mov             fp, SP
    // 0x11ab0a0: AllocStack(0x10)
    //     0x11ab0a0: sub             SP, SP, #0x10
    // 0x11ab0a4: SetupParameters(DecorationPosition this /* r1 => r0, fp-0x8 */)
    //     0x11ab0a4: mov             x0, x1
    //     0x11ab0a8: stur            x1, [fp, #-8]
    // 0x11ab0ac: CheckStackOverflow
    //     0x11ab0ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab0b0: cmp             SP, x16
    //     0x11ab0b4: b.ls            #0x11ab0f4
    // 0x11ab0b8: r1 = Null
    //     0x11ab0b8: mov             x1, NULL
    // 0x11ab0bc: r2 = 4
    //     0x11ab0bc: mov             x2, #4
    // 0x11ab0c0: r0 = AllocateArray()
    //     0x11ab0c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab0c4: r16 = "DecorationPosition."
    //     0x11ab0c4: add             x16, PP, #0x90, lsl #12  ; [pp+0x90c88] "DecorationPosition."
    //     0x11ab0c8: ldr             x16, [x16, #0xc88]
    // 0x11ab0cc: StoreField: r0->field_f = r16
    //     0x11ab0cc: stur            w16, [x0, #0xf]
    // 0x11ab0d0: ldur            x1, [fp, #-8]
    // 0x11ab0d4: LoadField: r2 = r1->field_f
    //     0x11ab0d4: ldur            w2, [x1, #0xf]
    // 0x11ab0d8: DecompressPointer r2
    //     0x11ab0d8: add             x2, x2, HEAP, lsl #32
    // 0x11ab0dc: StoreField: r0->field_13 = r2
    //     0x11ab0dc: stur            w2, [x0, #0x13]
    // 0x11ab0e0: str             x0, [SP]
    // 0x11ab0e4: r0 = _interpolate()
    //     0x11ab0e4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab0e8: LeaveFrame
    //     0x11ab0e8: mov             SP, fp
    //     0x11ab0ec: ldp             fp, lr, [SP], #0x10
    // 0x11ab0f0: ret
    //     0x11ab0f0: ret             
    // 0x11ab0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab0f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab0f8: b               #0x11ab0b8
  }
}

// class id: 8230, size: 0x14, field offset: 0x14
enum HitTestBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab034, size: 0x64
    // 0x11ab034: EnterFrame
    //     0x11ab034: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab038: mov             fp, SP
    // 0x11ab03c: AllocStack(0x10)
    //     0x11ab03c: sub             SP, SP, #0x10
    // 0x11ab040: SetupParameters(HitTestBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11ab040: mov             x0, x1
    //     0x11ab044: stur            x1, [fp, #-8]
    // 0x11ab048: CheckStackOverflow
    //     0x11ab048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab04c: cmp             SP, x16
    //     0x11ab050: b.ls            #0x11ab090
    // 0x11ab054: r1 = Null
    //     0x11ab054: mov             x1, NULL
    // 0x11ab058: r2 = 4
    //     0x11ab058: mov             x2, #4
    // 0x11ab05c: r0 = AllocateArray()
    //     0x11ab05c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab060: r16 = "HitTestBehavior."
    //     0x11ab060: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fa0] "HitTestBehavior."
    //     0x11ab064: ldr             x16, [x16, #0xfa0]
    // 0x11ab068: StoreField: r0->field_f = r16
    //     0x11ab068: stur            w16, [x0, #0xf]
    // 0x11ab06c: ldur            x1, [fp, #-8]
    // 0x11ab070: LoadField: r2 = r1->field_f
    //     0x11ab070: ldur            w2, [x1, #0xf]
    // 0x11ab074: DecompressPointer r2
    //     0x11ab074: add             x2, x2, HEAP, lsl #32
    // 0x11ab078: StoreField: r0->field_13 = r2
    //     0x11ab078: stur            w2, [x0, #0x13]
    // 0x11ab07c: str             x0, [SP]
    // 0x11ab080: r0 = _interpolate()
    //     0x11ab080: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab084: LeaveFrame
    //     0x11ab084: mov             SP, fp
    //     0x11ab088: ldp             fp, lr, [SP], #0x10
    // 0x11ab08c: ret
    //     0x11ab08c: ret             
    // 0x11ab090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab094: b               #0x11ab054
  }
}
