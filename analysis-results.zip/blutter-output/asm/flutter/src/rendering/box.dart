// lib: , url: package:flutter/src/rendering/box.dart

// class id: 1049021, size: 0x8
class :: {

  static _ BaselineOffset.+(/* No info */) {
    // ** addr: 0xb5b044, size: 0x70
    // 0xb5b044: EnterFrame
    //     0xb5b044: stp             fp, lr, [SP, #-0x10]!
    //     0xb5b048: mov             fp, SP
    // 0xb5b04c: cmp             w1, NULL
    // 0xb5b050: b.ne            #0xb5b05c
    // 0xb5b054: r0 = Null
    //     0xb5b054: mov             x0, NULL
    // 0xb5b058: b               #0xb5b094
    // 0xb5b05c: LoadField: d1 = r1->field_7
    //     0xb5b05c: ldur            d1, [x1, #7]
    // 0xb5b060: fadd            d2, d1, d0
    // 0xb5b064: r1 = inline_Allocate_Double()
    //     0xb5b064: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb5b068: add             x1, x1, #0x10
    //     0xb5b06c: cmp             x2, x1
    //     0xb5b070: b.ls            #0xb5b0a0
    //     0xb5b074: str             x1, [THR, #0x60]  ; THR::top
    //     0xb5b078: sub             x1, x1, #0xf
    //     0xb5b07c: mov             x2, #0xe19c
    //     0xb5b080: movk            x2, #3, lsl #16
    //     0xb5b084: stur            x2, [x1, #-1]
    // 0xb5b088: dmb             ishst
    // 0xb5b08c: StoreField: r1->field_7 = d2
    //     0xb5b08c: stur            d2, [x1, #7]
    // 0xb5b090: mov             x0, x1
    // 0xb5b094: LeaveFrame
    //     0xb5b094: mov             SP, fp
    //     0xb5b098: ldp             fp, lr, [SP], #0x10
    // 0xb5b09c: ret
    //     0xb5b09c: ret             
    // 0xb5b0a0: SaveReg d2
    //     0xb5b0a0: str             q2, [SP, #-0x10]!
    // 0xb5b0a4: r0 = AllocateDouble()
    //     0xb5b0a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5b0a8: mov             x1, x0
    // 0xb5b0ac: RestoreReg d2
    //     0xb5b0ac: ldr             q2, [SP], #0x10
    // 0xb5b0b0: b               #0xb5b08c
  }
  static _ BaselineOffset.minOf(/* No info */) {
    // ** addr: 0xb66e28, size: 0xf4
    // 0xb66e28: EnterFrame
    //     0xb66e28: stp             fp, lr, [SP, #-0x10]!
    //     0xb66e2c: mov             fp, SP
    // 0xb66e30: cmp             w1, NULL
    // 0xb66e34: b.eq            #0xb66e98
    // 0xb66e38: cmp             w2, NULL
    // 0xb66e3c: b.eq            #0xb66e90
    // 0xb66e40: LoadField: d0 = r1->field_7
    //     0xb66e40: ldur            d0, [x1, #7]
    // 0xb66e44: LoadField: d1 = r2->field_7
    //     0xb66e44: ldur            d1, [x2, #7]
    // 0xb66e48: fcmp            d0, d1
    // 0xb66e4c: b.lt            #0xb66e58
    // 0xb66e50: LoadField: d0 = r2->field_7
    //     0xb66e50: ldur            d0, [x2, #7]
    // 0xb66e54: b               #0xb66e5c
    // 0xb66e58: LoadField: d0 = r1->field_7
    //     0xb66e58: ldur            d0, [x1, #7]
    // 0xb66e5c: r3 = inline_Allocate_Double()
    //     0xb66e5c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb66e60: add             x3, x3, #0x10
    //     0xb66e64: cmp             x4, x3
    //     0xb66e68: b.ls            #0xb66f08
    //     0xb66e6c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb66e70: sub             x3, x3, #0xf
    //     0xb66e74: mov             x4, #0xe19c
    //     0xb66e78: movk            x4, #3, lsl #16
    //     0xb66e7c: stur            x4, [x3, #-1]
    // 0xb66e80: dmb             ishst
    // 0xb66e84: StoreField: r3->field_7 = d0
    //     0xb66e84: stur            d0, [x3, #7]
    // 0xb66e88: mov             x0, x3
    // 0xb66e8c: b               #0xb66efc
    // 0xb66e90: r3 = true
    //     0xb66e90: add             x3, NULL, #0x20  ; true
    // 0xb66e94: b               #0xb66e9c
    // 0xb66e98: r3 = false
    //     0xb66e98: add             x3, NULL, #0x30  ; false
    // 0xb66e9c: cmp             w1, NULL
    // 0xb66ea0: b.eq            #0xb66ed4
    // 0xb66ea4: tbnz            w3, #4, #0xb66eb4
    // 0xb66ea8: r5 = Null
    //     0xb66ea8: mov             x5, NULL
    // 0xb66eac: r4 = Null
    //     0xb66eac: mov             x4, NULL
    // 0xb66eb0: b               #0xb66ebc
    // 0xb66eb4: mov             x5, x2
    // 0xb66eb8: mov             x4, x2
    // 0xb66ebc: cmp             w5, NULL
    // 0xb66ec0: b.ne            #0xb66ecc
    // 0xb66ec4: mov             x0, x1
    // 0xb66ec8: b               #0xb66efc
    // 0xb66ecc: r3 = true
    //     0xb66ecc: add             x3, NULL, #0x20  ; true
    // 0xb66ed0: b               #0xb66ed8
    // 0xb66ed4: r4 = Null
    //     0xb66ed4: mov             x4, NULL
    // 0xb66ed8: cmp             w1, NULL
    // 0xb66edc: b.ne            #0xb66ef8
    // 0xb66ee0: tbnz            w3, #4, #0xb66eec
    // 0xb66ee4: mov             x1, x4
    // 0xb66ee8: b               #0xb66ef0
    // 0xb66eec: mov             x1, x2
    // 0xb66ef0: mov             x0, x1
    // 0xb66ef4: b               #0xb66efc
    // 0xb66ef8: r0 = Null
    //     0xb66ef8: mov             x0, NULL
    // 0xb66efc: LeaveFrame
    //     0xb66efc: mov             SP, fp
    //     0xb66f00: ldp             fp, lr, [SP], #0x10
    // 0xb66f04: ret
    //     0xb66f04: ret             
    // 0xb66f08: SaveReg d0
    //     0xb66f08: str             q0, [SP, #-0x10]!
    // 0xb66f0c: r0 = AllocateDouble()
    //     0xb66f0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66f10: mov             x3, x0
    // 0xb66f14: RestoreReg d0
    //     0xb66f14: ldr             q0, [SP], #0x10
    // 0xb66f18: b               #0xb66e84
  }
}

// class id: 2880, size: 0x18, field offset: 0x8
class _LayoutCacheStorage extends Object {

  _ clear(/* No info */) {
    // ** addr: 0xbfb634, size: 0x1cc
    // 0xbfb634: EnterFrame
    //     0xbfb634: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb638: mov             fp, SP
    // 0xbfb63c: AllocStack(0x10)
    //     0xbfb63c: sub             SP, SP, #0x10
    // 0xbfb640: SetupParameters(_LayoutCacheStorage this /* r1 => r0, fp-0x10 */)
    //     0xbfb640: mov             x0, x1
    //     0xbfb644: stur            x1, [fp, #-0x10]
    // 0xbfb648: CheckStackOverflow
    //     0xbfb648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb64c: cmp             SP, x16
    //     0xbfb650: b.ls            #0xbfb7f8
    // 0xbfb654: LoadField: r1 = r0->field_b
    //     0xbfb654: ldur            w1, [x0, #0xb]
    // 0xbfb658: DecompressPointer r1
    //     0xbfb658: add             x1, x1, HEAP, lsl #32
    // 0xbfb65c: cmp             w1, NULL
    // 0xbfb660: b.ne            #0xbfb66c
    // 0xbfb664: r2 = Null
    //     0xbfb664: mov             x2, NULL
    // 0xbfb668: b               #0xbfb694
    // 0xbfb66c: LoadField: r2 = r1->field_13
    //     0xbfb66c: ldur            w2, [x1, #0x13]
    // 0xbfb670: r3 = LoadInt32Instr(r2)
    //     0xbfb670: sbfx            x3, x2, #1, #0x1f
    // 0xbfb674: asr             x2, x3, #1
    // 0xbfb678: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xbfb678: ldur            w3, [x1, #0x17]
    // 0xbfb67c: r4 = LoadInt32Instr(r3)
    //     0xbfb67c: sbfx            x4, x3, #1, #0x1f
    // 0xbfb680: sub             x3, x2, x4
    // 0xbfb684: cbnz            x3, #0xbfb690
    // 0xbfb688: r2 = false
    //     0xbfb688: add             x2, NULL, #0x30  ; false
    // 0xbfb68c: b               #0xbfb694
    // 0xbfb690: r2 = true
    //     0xbfb690: add             x2, NULL, #0x20  ; true
    // 0xbfb694: cmp             w2, NULL
    // 0xbfb698: b.eq            #0xbfb6a0
    // 0xbfb69c: tbz             w2, #4, #0xbfb738
    // 0xbfb6a0: LoadField: r2 = r0->field_7
    //     0xbfb6a0: ldur            w2, [x0, #7]
    // 0xbfb6a4: DecompressPointer r2
    //     0xbfb6a4: add             x2, x2, HEAP, lsl #32
    // 0xbfb6a8: cmp             w2, NULL
    // 0xbfb6ac: b.ne            #0xbfb6b8
    // 0xbfb6b0: r2 = Null
    //     0xbfb6b0: mov             x2, NULL
    // 0xbfb6b4: b               #0xbfb6e0
    // 0xbfb6b8: LoadField: r3 = r2->field_13
    //     0xbfb6b8: ldur            w3, [x2, #0x13]
    // 0xbfb6bc: r4 = LoadInt32Instr(r3)
    //     0xbfb6bc: sbfx            x4, x3, #1, #0x1f
    // 0xbfb6c0: asr             x3, x4, #1
    // 0xbfb6c4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfb6c4: ldur            w4, [x2, #0x17]
    // 0xbfb6c8: r2 = LoadInt32Instr(r4)
    //     0xbfb6c8: sbfx            x2, x4, #1, #0x1f
    // 0xbfb6cc: sub             x4, x3, x2
    // 0xbfb6d0: cbnz            x4, #0xbfb6dc
    // 0xbfb6d4: r2 = false
    //     0xbfb6d4: add             x2, NULL, #0x30  ; false
    // 0xbfb6d8: b               #0xbfb6e0
    // 0xbfb6dc: r2 = true
    //     0xbfb6dc: add             x2, NULL, #0x20  ; true
    // 0xbfb6e0: cmp             w2, NULL
    // 0xbfb6e4: b.eq            #0xbfb6ec
    // 0xbfb6e8: tbz             w2, #4, #0xbfb738
    // 0xbfb6ec: LoadField: r2 = r0->field_f
    //     0xbfb6ec: ldur            w2, [x0, #0xf]
    // 0xbfb6f0: DecompressPointer r2
    //     0xbfb6f0: add             x2, x2, HEAP, lsl #32
    // 0xbfb6f4: cmp             w2, NULL
    // 0xbfb6f8: b.ne            #0xbfb704
    // 0xbfb6fc: r2 = Null
    //     0xbfb6fc: mov             x2, NULL
    // 0xbfb700: b               #0xbfb72c
    // 0xbfb704: LoadField: r3 = r2->field_13
    //     0xbfb704: ldur            w3, [x2, #0x13]
    // 0xbfb708: r4 = LoadInt32Instr(r3)
    //     0xbfb708: sbfx            x4, x3, #1, #0x1f
    // 0xbfb70c: asr             x3, x4, #1
    // 0xbfb710: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfb710: ldur            w4, [x2, #0x17]
    // 0xbfb714: r2 = LoadInt32Instr(r4)
    //     0xbfb714: sbfx            x2, x4, #1, #0x1f
    // 0xbfb718: sub             x4, x3, x2
    // 0xbfb71c: cbnz            x4, #0xbfb728
    // 0xbfb720: r2 = false
    //     0xbfb720: add             x2, NULL, #0x30  ; false
    // 0xbfb724: b               #0xbfb72c
    // 0xbfb728: r2 = true
    //     0xbfb728: add             x2, NULL, #0x20  ; true
    // 0xbfb72c: cmp             w2, NULL
    // 0xbfb730: b.eq            #0xbfb740
    // 0xbfb734: tbnz            w2, #4, #0xbfb740
    // 0xbfb738: r2 = true
    //     0xbfb738: add             x2, NULL, #0x20  ; true
    // 0xbfb73c: b               #0xbfb78c
    // 0xbfb740: LoadField: r2 = r0->field_13
    //     0xbfb740: ldur            w2, [x0, #0x13]
    // 0xbfb744: DecompressPointer r2
    //     0xbfb744: add             x2, x2, HEAP, lsl #32
    // 0xbfb748: cmp             w2, NULL
    // 0xbfb74c: b.ne            #0xbfb758
    // 0xbfb750: r2 = Null
    //     0xbfb750: mov             x2, NULL
    // 0xbfb754: b               #0xbfb780
    // 0xbfb758: LoadField: r3 = r2->field_13
    //     0xbfb758: ldur            w3, [x2, #0x13]
    // 0xbfb75c: r4 = LoadInt32Instr(r3)
    //     0xbfb75c: sbfx            x4, x3, #1, #0x1f
    // 0xbfb760: asr             x3, x4, #1
    // 0xbfb764: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfb764: ldur            w4, [x2, #0x17]
    // 0xbfb768: r2 = LoadInt32Instr(r4)
    //     0xbfb768: sbfx            x2, x4, #1, #0x1f
    // 0xbfb76c: sub             x4, x3, x2
    // 0xbfb770: cbnz            x4, #0xbfb77c
    // 0xbfb774: r2 = false
    //     0xbfb774: add             x2, NULL, #0x30  ; false
    // 0xbfb778: b               #0xbfb780
    // 0xbfb77c: r2 = true
    //     0xbfb77c: add             x2, NULL, #0x20  ; true
    // 0xbfb780: cmp             w2, NULL
    // 0xbfb784: b.ne            #0xbfb78c
    // 0xbfb788: r2 = false
    //     0xbfb788: add             x2, NULL, #0x30  ; false
    // 0xbfb78c: stur            x2, [fp, #-8]
    // 0xbfb790: tbnz            w2, #4, #0xbfb7e8
    // 0xbfb794: cmp             w1, NULL
    // 0xbfb798: b.eq            #0xbfb7a4
    // 0xbfb79c: r0 = clear()
    //     0xbfb79c: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbfb7a0: ldur            x0, [fp, #-0x10]
    // 0xbfb7a4: LoadField: r1 = r0->field_7
    //     0xbfb7a4: ldur            w1, [x0, #7]
    // 0xbfb7a8: DecompressPointer r1
    //     0xbfb7a8: add             x1, x1, HEAP, lsl #32
    // 0xbfb7ac: cmp             w1, NULL
    // 0xbfb7b0: b.eq            #0xbfb7bc
    // 0xbfb7b4: r0 = clear()
    //     0xbfb7b4: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbfb7b8: ldur            x0, [fp, #-0x10]
    // 0xbfb7bc: LoadField: r1 = r0->field_f
    //     0xbfb7bc: ldur            w1, [x0, #0xf]
    // 0xbfb7c0: DecompressPointer r1
    //     0xbfb7c0: add             x1, x1, HEAP, lsl #32
    // 0xbfb7c4: cmp             w1, NULL
    // 0xbfb7c8: b.eq            #0xbfb7d4
    // 0xbfb7cc: r0 = clear()
    //     0xbfb7cc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbfb7d0: ldur            x0, [fp, #-0x10]
    // 0xbfb7d4: LoadField: r1 = r0->field_13
    //     0xbfb7d4: ldur            w1, [x0, #0x13]
    // 0xbfb7d8: DecompressPointer r1
    //     0xbfb7d8: add             x1, x1, HEAP, lsl #32
    // 0xbfb7dc: cmp             w1, NULL
    // 0xbfb7e0: b.eq            #0xbfb7e8
    // 0xbfb7e4: r0 = clear()
    //     0xbfb7e4: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbfb7e8: ldur            x0, [fp, #-8]
    // 0xbfb7ec: LeaveFrame
    //     0xbfb7ec: mov             SP, fp
    //     0xbfb7f0: ldp             fp, lr, [SP], #0x10
    // 0xbfb7f4: ret
    //     0xbfb7f4: ret             
    // 0xbfb7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb7f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb7fc: b               #0xbfb654
  }
}

// class id: 2881, size: 0x8, field offset: 0x8
//   const constructor, 
class _Baseline extends Object
    implements _CachedLayoutCalculation<X0, X1> {

  [closure] double? ifAbsent(dynamic) {
    // ** addr: 0x119f60c, size: 0x58
    // 0x119f60c: EnterFrame
    //     0x119f60c: stp             fp, lr, [SP, #-0x10]!
    //     0x119f610: mov             fp, SP
    // 0x119f614: AllocStack(0x10)
    //     0x119f614: sub             SP, SP, #0x10
    // 0x119f618: SetupParameters([dynamic _ /* r0 */])
    //     0x119f618: ldr             x0, [fp, #0x10]
    //     0x119f61c: ldur            w1, [x0, #0x17]
    //     0x119f620: add             x1, x1, HEAP, lsl #32
    // 0x119f624: CheckStackOverflow
    //     0x119f624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f628: cmp             SP, x16
    //     0x119f62c: b.ls            #0x119f65c
    // 0x119f630: LoadField: r0 = r1->field_13
    //     0x119f630: ldur            w0, [x1, #0x13]
    // 0x119f634: DecompressPointer r0
    //     0x119f634: add             x0, x0, HEAP, lsl #32
    // 0x119f638: LoadField: r2 = r1->field_f
    //     0x119f638: ldur            w2, [x1, #0xf]
    // 0x119f63c: DecompressPointer r2
    //     0x119f63c: add             x2, x2, HEAP, lsl #32
    // 0x119f640: stp             x2, x0, [SP]
    // 0x119f644: ClosureCall
    //     0x119f644: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x119f648: ldur            x2, [x0, #0x1f]
    //     0x119f64c: blr             x2
    // 0x119f650: LeaveFrame
    //     0x119f650: mov             SP, fp
    //     0x119f654: ldp             fp, lr, [SP], #0x10
    // 0x119f658: ret
    //     0x119f658: ret             
    // 0x119f65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f65c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f660: b               #0x119f630
  }
  _ memoize(/* No info */) {
    // ** addr: 0x123f314, size: 0x1a4
    // 0x123f314: EnterFrame
    //     0x123f314: stp             fp, lr, [SP, #-0x10]!
    //     0x123f318: mov             fp, SP
    // 0x123f31c: AllocStack(0x30)
    //     0x123f31c: sub             SP, SP, #0x30
    // 0x123f320: SetupParameters(_Baseline this /* r1 => r3, fp-0x18 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0x123f320: mov             x16, x3
    //     0x123f324: mov             x3, x1
    //     0x123f328: mov             x1, x16
    //     0x123f32c: mov             x0, x5
    //     0x123f330: stur            x2, [fp, #-8]
    //     0x123f334: stur            x1, [fp, #-0x10]
    //     0x123f338: stur            x5, [fp, #-0x18]
    // 0x123f33c: CheckStackOverflow
    //     0x123f33c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123f340: cmp             SP, x16
    //     0x123f344: b.ls            #0x123f4b0
    // 0x123f348: r1 = 2
    //     0x123f348: mov             x1, #2
    // 0x123f34c: r0 = AllocateContext()
    //     0x123f34c: bl              #0x13de838  ; AllocateContextStub
    // 0x123f350: mov             x4, x0
    // 0x123f354: ldur            x3, [fp, #-0x10]
    // 0x123f358: stur            x4, [fp, #-0x20]
    // 0x123f35c: StoreField: r4->field_f = r3
    //     0x123f35c: stur            w3, [x4, #0xf]
    // 0x123f360: ldur            x5, [fp, #-0x18]
    // 0x123f364: StoreField: r4->field_13 = r5
    //     0x123f364: stur            w5, [x4, #0x13]
    // 0x123f368: mov             x0, x3
    // 0x123f36c: r2 = Null
    //     0x123f36c: mov             x2, NULL
    // 0x123f370: r1 = Null
    //     0x123f370: mov             x1, NULL
    // 0x123f374: r8 = (BoxConstraints, TextBaseline)
    //     0x123f374: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a798] RecordType: (BoxConstraints, TextBaseline)
    //     0x123f378: ldr             x8, [x8, #0x798]
    // 0x123f37c: r3 = Null
    //     0x123f37c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a7a0] Null
    //     0x123f380: ldr             x3, [x3, #0x7a0]
    // 0x123f384: r0 = (BoxConstraints, TextBaseline)()
    //     0x123f384: bl              #0xb1978c  ; IsType_(BoxConstraints, TextBaseline)_Stub
    // 0x123f388: ldur            x0, [fp, #-0x18]
    // 0x123f38c: r2 = Null
    //     0x123f38c: mov             x2, NULL
    // 0x123f390: r1 = Null
    //     0x123f390: mov             x1, NULL
    // 0x123f394: r8 = (dynamic this, (BoxConstraints, TextBaseline)) => double?
    //     0x123f394: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a7b0] FunctionType: (dynamic this, (BoxConstraints, TextBaseline)) => double?
    //     0x123f398: ldr             x8, [x8, #0x7b0]
    // 0x123f39c: r3 = Null
    //     0x123f39c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a7b8] Null
    //     0x123f3a0: ldr             x3, [x3, #0x7b8]
    // 0x123f3a4: r0 = DefaultTypeTest()
    //     0x123f3a4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x123f3a8: ldur            x0, [fp, #-0x10]
    // 0x123f3ac: LoadField: r1 = r0->field_13
    //     0x123f3ac: ldur            w1, [x0, #0x13]
    // 0x123f3b0: DecompressPointer r1
    //     0x123f3b0: add             x1, x1, HEAP, lsl #32
    // 0x123f3b4: LoadField: r0 = r1->field_7
    //     0x123f3b4: ldur            x0, [x1, #7]
    // 0x123f3b8: cmp             x0, #0
    // 0x123f3bc: b.gt            #0x123f41c
    // 0x123f3c0: ldur            x0, [fp, #-8]
    // 0x123f3c4: LoadField: r1 = r0->field_f
    //     0x123f3c4: ldur            w1, [x0, #0xf]
    // 0x123f3c8: DecompressPointer r1
    //     0x123f3c8: add             x1, x1, HEAP, lsl #32
    // 0x123f3cc: cmp             w1, NULL
    // 0x123f3d0: b.ne            #0x123f414
    // 0x123f3d4: r16 = <BoxConstraints, double?>
    //     0x123f3d4: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a7c8] TypeArguments: <BoxConstraints, double?>
    //     0x123f3d8: ldr             x16, [x16, #0x7c8]
    // 0x123f3dc: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x123f3e0: stp             lr, x16, [SP]
    // 0x123f3e4: r0 = Map._fromLiteral()
    //     0x123f3e4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x123f3e8: mov             x2, x0
    // 0x123f3ec: ldur            x1, [fp, #-8]
    // 0x123f3f0: StoreField: r1->field_f = r0
    //     0x123f3f0: stur            w0, [x1, #0xf]
    //     0x123f3f4: ldurb           w16, [x1, #-1]
    //     0x123f3f8: ldurb           w17, [x0, #-1]
    //     0x123f3fc: and             x16, x17, x16, lsr #2
    //     0x123f400: tst             x16, HEAP, lsr #32
    //     0x123f404: b.eq            #0x123f40c
    //     0x123f408: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x123f40c: mov             x0, x2
    // 0x123f410: b               #0x123f46c
    // 0x123f414: mov             x0, x1
    // 0x123f418: b               #0x123f46c
    // 0x123f41c: ldur            x1, [fp, #-8]
    // 0x123f420: LoadField: r0 = r1->field_13
    //     0x123f420: ldur            w0, [x1, #0x13]
    // 0x123f424: DecompressPointer r0
    //     0x123f424: add             x0, x0, HEAP, lsl #32
    // 0x123f428: cmp             w0, NULL
    // 0x123f42c: b.ne            #0x123f46c
    // 0x123f430: r16 = <BoxConstraints, double?>
    //     0x123f430: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a7c8] TypeArguments: <BoxConstraints, double?>
    //     0x123f434: ldr             x16, [x16, #0x7c8]
    // 0x123f438: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x123f43c: stp             lr, x16, [SP]
    // 0x123f440: r0 = Map._fromLiteral()
    //     0x123f440: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x123f444: mov             x2, x0
    // 0x123f448: ldur            x1, [fp, #-8]
    // 0x123f44c: StoreField: r1->field_13 = r0
    //     0x123f44c: stur            w0, [x1, #0x13]
    //     0x123f450: ldurb           w16, [x1, #-1]
    //     0x123f454: ldurb           w17, [x0, #-1]
    //     0x123f458: and             x16, x17, x16, lsr #2
    //     0x123f45c: tst             x16, HEAP, lsr #32
    //     0x123f460: b.eq            #0x123f468
    //     0x123f464: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x123f468: mov             x0, x2
    // 0x123f46c: ldur            x2, [fp, #-0x20]
    // 0x123f470: stur            x0, [fp, #-0x10]
    // 0x123f474: LoadField: r1 = r2->field_f
    //     0x123f474: ldur            w1, [x2, #0xf]
    // 0x123f478: DecompressPointer r1
    //     0x123f478: add             x1, x1, HEAP, lsl #32
    // 0x123f47c: LoadField: r3 = r1->field_f
    //     0x123f47c: ldur            w3, [x1, #0xf]
    // 0x123f480: DecompressPointer r3
    //     0x123f480: add             x3, x3, HEAP, lsl #32
    // 0x123f484: stur            x3, [fp, #-8]
    // 0x123f488: r1 = Function 'ifAbsent':.
    //     0x123f488: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a7d0] AnonymousClosure: (0x119f60c), in [package:flutter/src/rendering/box.dart] _Baseline::memoize (0x123f314)
    //     0x123f48c: ldr             x1, [x1, #0x7d0]
    // 0x123f490: r0 = AllocateClosure()
    //     0x123f490: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x123f494: ldur            x1, [fp, #-0x10]
    // 0x123f498: ldur            x2, [fp, #-8]
    // 0x123f49c: mov             x3, x0
    // 0x123f4a0: r0 = putIfAbsent()
    //     0x123f4a0: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x123f4a4: LeaveFrame
    //     0x123f4a4: mov             SP, fp
    //     0x123f4a8: ldp             fp, lr, [SP], #0x10
    // 0x123f4ac: ret
    //     0x123f4ac: ret             
    // 0x123f4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123f4b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123f4b4: b               #0x123f348
  }
}

// class id: 2882, size: 0x8, field offset: 0x8
//   const constructor, 
class _DryLayout extends Object
    implements _CachedLayoutCalculation<X0, X1> {

  _ memoize(/* No info */) {
    // ** addr: 0x123f1c4, size: 0x100
    // 0x123f1c4: EnterFrame
    //     0x123f1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x123f1c8: mov             fp, SP
    // 0x123f1cc: AllocStack(0x30)
    //     0x123f1cc: sub             SP, SP, #0x30
    // 0x123f1d0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0x123f1d0: mov             x0, x5
    //     0x123f1d4: stur            x2, [fp, #-8]
    //     0x123f1d8: stur            x3, [fp, #-0x10]
    //     0x123f1dc: stur            x5, [fp, #-0x18]
    // 0x123f1e0: CheckStackOverflow
    //     0x123f1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123f1e4: cmp             SP, x16
    //     0x123f1e8: b.ls            #0x123f2bc
    // 0x123f1ec: r1 = 2
    //     0x123f1ec: mov             x1, #2
    // 0x123f1f0: r0 = AllocateContext()
    //     0x123f1f0: bl              #0x13de838  ; AllocateContextStub
    // 0x123f1f4: mov             x3, x0
    // 0x123f1f8: ldur            x0, [fp, #-0x10]
    // 0x123f1fc: stur            x3, [fp, #-0x20]
    // 0x123f200: StoreField: r3->field_f = r0
    //     0x123f200: stur            w0, [x3, #0xf]
    // 0x123f204: ldur            x0, [fp, #-0x18]
    // 0x123f208: StoreField: r3->field_13 = r0
    //     0x123f208: stur            w0, [x3, #0x13]
    // 0x123f20c: r2 = Null
    //     0x123f20c: mov             x2, NULL
    // 0x123f210: r1 = Null
    //     0x123f210: mov             x1, NULL
    // 0x123f214: r8 = (dynamic this, BoxConstraints) => Size
    //     0x123f214: add             x8, PP, #0x85, lsl #12  ; [pp+0x855a0] FunctionType: (dynamic this, BoxConstraints) => Size
    //     0x123f218: ldr             x8, [x8, #0x5a0]
    // 0x123f21c: r3 = Null
    //     0x123f21c: add             x3, PP, #0x85, lsl #12  ; [pp+0x855a8] Null
    //     0x123f220: ldr             x3, [x3, #0x5a8]
    // 0x123f224: r0 = DefaultTypeTest()
    //     0x123f224: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x123f228: ldur            x0, [fp, #-8]
    // 0x123f22c: LoadField: r1 = r0->field_b
    //     0x123f22c: ldur            w1, [x0, #0xb]
    // 0x123f230: DecompressPointer r1
    //     0x123f230: add             x1, x1, HEAP, lsl #32
    // 0x123f234: cmp             w1, NULL
    // 0x123f238: b.ne            #0x123f27c
    // 0x123f23c: r16 = <BoxConstraints, Size>
    //     0x123f23c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0x123f240: ldr             x16, [x16, #0x18]
    // 0x123f244: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x123f248: stp             lr, x16, [SP]
    // 0x123f24c: r0 = Map._fromLiteral()
    //     0x123f24c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x123f250: mov             x2, x0
    // 0x123f254: ldur            x1, [fp, #-8]
    // 0x123f258: StoreField: r1->field_b = r0
    //     0x123f258: stur            w0, [x1, #0xb]
    //     0x123f25c: ldurb           w16, [x1, #-1]
    //     0x123f260: ldurb           w17, [x0, #-1]
    //     0x123f264: and             x16, x17, x16, lsr #2
    //     0x123f268: tst             x16, HEAP, lsr #32
    //     0x123f26c: b.eq            #0x123f274
    //     0x123f270: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x123f274: mov             x0, x2
    // 0x123f278: b               #0x123f280
    // 0x123f27c: mov             x0, x1
    // 0x123f280: ldur            x2, [fp, #-0x20]
    // 0x123f284: stur            x0, [fp, #-0x10]
    // 0x123f288: LoadField: r3 = r2->field_f
    //     0x123f288: ldur            w3, [x2, #0xf]
    // 0x123f28c: DecompressPointer r3
    //     0x123f28c: add             x3, x3, HEAP, lsl #32
    // 0x123f290: stur            x3, [fp, #-8]
    // 0x123f294: r1 = Function '<anonymous closure>':.
    //     0x123f294: add             x1, PP, #0x85, lsl #12  ; [pp+0x855b8] AnonymousClosure: (0x123f2c4), in [package:flutter/src/rendering/box.dart] _DryLayout::memoize (0x123f1c4)
    //     0x123f298: ldr             x1, [x1, #0x5b8]
    // 0x123f29c: r0 = AllocateClosure()
    //     0x123f29c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x123f2a0: ldur            x1, [fp, #-0x10]
    // 0x123f2a4: ldur            x2, [fp, #-8]
    // 0x123f2a8: mov             x3, x0
    // 0x123f2ac: r0 = putIfAbsent()
    //     0x123f2ac: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x123f2b0: LeaveFrame
    //     0x123f2b0: mov             SP, fp
    //     0x123f2b4: ldp             fp, lr, [SP], #0x10
    // 0x123f2b8: ret
    //     0x123f2b8: ret             
    // 0x123f2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123f2bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123f2c0: b               #0x123f1ec
  }
  [closure] Size <anonymous closure>(dynamic) {
    // ** addr: 0x123f2c4, size: 0x50
    // 0x123f2c4: EnterFrame
    //     0x123f2c4: stp             fp, lr, [SP, #-0x10]!
    //     0x123f2c8: mov             fp, SP
    // 0x123f2cc: ldr             x0, [fp, #0x10]
    // 0x123f2d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x123f2d0: ldur            w1, [x0, #0x17]
    // 0x123f2d4: DecompressPointer r1
    //     0x123f2d4: add             x1, x1, HEAP, lsl #32
    // 0x123f2d8: CheckStackOverflow
    //     0x123f2d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123f2dc: cmp             SP, x16
    //     0x123f2e0: b.ls            #0x123f30c
    // 0x123f2e4: LoadField: r0 = r1->field_13
    //     0x123f2e4: ldur            w0, [x1, #0x13]
    // 0x123f2e8: DecompressPointer r0
    //     0x123f2e8: add             x0, x0, HEAP, lsl #32
    // 0x123f2ec: LoadField: r2 = r1->field_f
    //     0x123f2ec: ldur            w2, [x1, #0xf]
    // 0x123f2f0: DecompressPointer r2
    //     0x123f2f0: add             x2, x2, HEAP, lsl #32
    // 0x123f2f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x123f2f4: ldur            w1, [x0, #0x17]
    // 0x123f2f8: DecompressPointer r1
    //     0x123f2f8: add             x1, x1, HEAP, lsl #32
    // 0x123f2fc: r0 = _computeDryLayout()
    //     0x123f2fc: bl              #0xb204c4  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout
    // 0x123f300: LeaveFrame
    //     0x123f300: mov             SP, fp
    //     0x123f304: ldp             fp, lr, [SP], #0x10
    // 0x123f308: ret
    //     0x123f308: ret             
    // 0x123f30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123f30c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123f310: b               #0x123f2e4
  }
}

// class id: 2883, size: 0xc, field offset: 0x8
abstract class _CachedLayoutCalculation<X0, X1> extends Object {
}

// class id: 2886, size: 0x28, field offset: 0x8
//   const constructor, 
class BoxConstraints extends Constraints {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  _ constrain(/* No info */) {
    // ** addr: 0x898bc0, size: 0x104
    // 0x898bc0: EnterFrame
    //     0x898bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x898bc4: mov             fp, SP
    // 0x898bc8: AllocStack(0x28)
    //     0x898bc8: sub             SP, SP, #0x28
    // 0x898bcc: SetupParameters(BoxConstraints this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x898bcc: mov             x0, x1
    //     0x898bd0: stur            x1, [fp, #-8]
    //     0x898bd4: stur            x2, [fp, #-0x10]
    // 0x898bd8: CheckStackOverflow
    //     0x898bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898bdc: cmp             SP, x16
    //     0x898be0: b.ls            #0x898c90
    // 0x898be4: LoadField: d0 = r2->field_7
    //     0x898be4: ldur            d0, [x2, #7]
    // 0x898be8: r1 = inline_Allocate_Double()
    //     0x898be8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x898bec: add             x1, x1, #0x10
    //     0x898bf0: cmp             x3, x1
    //     0x898bf4: b.ls            #0x898c98
    //     0x898bf8: str             x1, [THR, #0x60]  ; THR::top
    //     0x898bfc: sub             x1, x1, #0xf
    //     0x898c00: mov             x3, #0xe19c
    //     0x898c04: movk            x3, #3, lsl #16
    //     0x898c08: stur            x3, [x1, #-1]
    // 0x898c0c: dmb             ishst
    // 0x898c10: StoreField: r1->field_7 = d0
    //     0x898c10: stur            d0, [x1, #7]
    // 0x898c14: str             x1, [SP]
    // 0x898c18: mov             x1, x0
    // 0x898c1c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x898c1c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x898c20: r0 = constrainWidth()
    //     0x898c20: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x898c24: ldur            x0, [fp, #-0x10]
    // 0x898c28: stur            d0, [fp, #-0x18]
    // 0x898c2c: LoadField: d1 = r0->field_f
    //     0x898c2c: ldur            d1, [x0, #0xf]
    // 0x898c30: r0 = inline_Allocate_Double()
    //     0x898c30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x898c34: add             x0, x0, #0x10
    //     0x898c38: cmp             x1, x0
    //     0x898c3c: b.ls            #0x898cb4
    //     0x898c40: str             x0, [THR, #0x60]  ; THR::top
    //     0x898c44: sub             x0, x0, #0xf
    //     0x898c48: mov             x1, #0xe19c
    //     0x898c4c: movk            x1, #3, lsl #16
    //     0x898c50: stur            x1, [x0, #-1]
    // 0x898c54: dmb             ishst
    // 0x898c58: StoreField: r0->field_7 = d1
    //     0x898c58: stur            d1, [x0, #7]
    // 0x898c5c: str             x0, [SP]
    // 0x898c60: ldur            x1, [fp, #-8]
    // 0x898c64: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x898c64: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x898c68: r0 = constrainHeight()
    //     0x898c68: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x898c6c: stur            d0, [fp, #-0x20]
    // 0x898c70: r0 = Size()
    //     0x898c70: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x898c74: ldur            d0, [fp, #-0x18]
    // 0x898c78: StoreField: r0->field_7 = d0
    //     0x898c78: stur            d0, [x0, #7]
    // 0x898c7c: ldur            d0, [fp, #-0x20]
    // 0x898c80: StoreField: r0->field_f = d0
    //     0x898c80: stur            d0, [x0, #0xf]
    // 0x898c84: LeaveFrame
    //     0x898c84: mov             SP, fp
    //     0x898c88: ldp             fp, lr, [SP], #0x10
    // 0x898c8c: ret
    //     0x898c8c: ret             
    // 0x898c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898c90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898c94: b               #0x898be4
    // 0x898c98: SaveReg d0
    //     0x898c98: str             q0, [SP, #-0x10]!
    // 0x898c9c: stp             x0, x2, [SP, #-0x10]!
    // 0x898ca0: r0 = AllocateDouble()
    //     0x898ca0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x898ca4: mov             x1, x0
    // 0x898ca8: ldp             x0, x2, [SP], #0x10
    // 0x898cac: RestoreReg d0
    //     0x898cac: ldr             q0, [SP], #0x10
    // 0x898cb0: b               #0x898c10
    // 0x898cb4: stp             q0, q1, [SP, #-0x20]!
    // 0x898cb8: r0 = AllocateDouble()
    //     0x898cb8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x898cbc: ldp             q0, q1, [SP], #0x20
    // 0x898cc0: b               #0x898c58
  }
  _ constrainHeight(/* No info */) {
    // ** addr: 0x898cc4, size: 0x74
    // 0x898cc4: EnterFrame
    //     0x898cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x898cc8: mov             fp, SP
    // 0x898ccc: LoadField: r0 = r4->field_13
    //     0x898ccc: ldur            w0, [x4, #0x13]
    // 0x898cd0: sub             x2, x0, #2
    // 0x898cd4: cmp             w2, #2
    // 0x898cd8: b.lt            #0x898cec
    // 0x898cdc: add             x0, fp, w2, sxtw #2
    // 0x898ce0: ldr             x0, [x0, #8]
    // 0x898ce4: LoadField: d1 = r0->field_7
    //     0x898ce4: ldur            d1, [x0, #7]
    // 0x898ce8: b               #0x898cf0
    // 0x898cec: d1 = inf
    //     0x898cec: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x898cf0: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x898cf0: ldur            d2, [x1, #0x17]
    // 0x898cf4: LoadField: d3 = r1->field_1f
    //     0x898cf4: ldur            d3, [x1, #0x1f]
    // 0x898cf8: fcmp            d2, d1
    // 0x898cfc: b.le            #0x898d08
    // 0x898d00: mov             v0.16b, v2.16b
    // 0x898d04: b               #0x898d2c
    // 0x898d08: fcmp            d1, d3
    // 0x898d0c: b.le            #0x898d18
    // 0x898d10: mov             v0.16b, v3.16b
    // 0x898d14: b               #0x898d2c
    // 0x898d18: fcmp            d1, d1
    // 0x898d1c: b.vc            #0x898d28
    // 0x898d20: mov             v0.16b, v3.16b
    // 0x898d24: b               #0x898d2c
    // 0x898d28: mov             v0.16b, v1.16b
    // 0x898d2c: LeaveFrame
    //     0x898d2c: mov             SP, fp
    //     0x898d30: ldp             fp, lr, [SP], #0x10
    // 0x898d34: ret
    //     0x898d34: ret             
  }
  _ constrainWidth(/* No info */) {
    // ** addr: 0x898d38, size: 0x74
    // 0x898d38: EnterFrame
    //     0x898d38: stp             fp, lr, [SP, #-0x10]!
    //     0x898d3c: mov             fp, SP
    // 0x898d40: LoadField: r0 = r4->field_13
    //     0x898d40: ldur            w0, [x4, #0x13]
    // 0x898d44: sub             x2, x0, #2
    // 0x898d48: cmp             w2, #2
    // 0x898d4c: b.lt            #0x898d60
    // 0x898d50: add             x0, fp, w2, sxtw #2
    // 0x898d54: ldr             x0, [x0, #8]
    // 0x898d58: LoadField: d1 = r0->field_7
    //     0x898d58: ldur            d1, [x0, #7]
    // 0x898d5c: b               #0x898d64
    // 0x898d60: d1 = inf
    //     0x898d60: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x898d64: LoadField: d2 = r1->field_7
    //     0x898d64: ldur            d2, [x1, #7]
    // 0x898d68: LoadField: d3 = r1->field_f
    //     0x898d68: ldur            d3, [x1, #0xf]
    // 0x898d6c: fcmp            d2, d1
    // 0x898d70: b.le            #0x898d7c
    // 0x898d74: mov             v0.16b, v2.16b
    // 0x898d78: b               #0x898da0
    // 0x898d7c: fcmp            d1, d3
    // 0x898d80: b.le            #0x898d8c
    // 0x898d84: mov             v0.16b, v3.16b
    // 0x898d88: b               #0x898da0
    // 0x898d8c: fcmp            d1, d1
    // 0x898d90: b.vc            #0x898d9c
    // 0x898d94: mov             v0.16b, v3.16b
    // 0x898d98: b               #0x898da0
    // 0x898d9c: mov             v0.16b, v1.16b
    // 0x898da0: LeaveFrame
    //     0x898da0: mov             SP, fp
    //     0x898da4: ldp             fp, lr, [SP], #0x10
    // 0x898da8: ret
    //     0x898da8: ret             
  }
  _ /(/* No info */) {
    // ** addr: 0x89d338, size: 0x6c
    // 0x89d338: EnterFrame
    //     0x89d338: stp             fp, lr, [SP, #-0x10]!
    //     0x89d33c: mov             fp, SP
    // 0x89d340: AllocStack(0x20)
    //     0x89d340: sub             SP, SP, #0x20
    // 0x89d344: LoadField: d1 = r1->field_7
    //     0x89d344: ldur            d1, [x1, #7]
    // 0x89d348: fdiv            d2, d1, d0
    // 0x89d34c: stur            d2, [fp, #-0x20]
    // 0x89d350: LoadField: d1 = r1->field_f
    //     0x89d350: ldur            d1, [x1, #0xf]
    // 0x89d354: fdiv            d3, d1, d0
    // 0x89d358: stur            d3, [fp, #-0x18]
    // 0x89d35c: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x89d35c: ldur            d1, [x1, #0x17]
    // 0x89d360: fdiv            d4, d1, d0
    // 0x89d364: stur            d4, [fp, #-0x10]
    // 0x89d368: LoadField: d1 = r1->field_1f
    //     0x89d368: ldur            d1, [x1, #0x1f]
    // 0x89d36c: fdiv            d5, d1, d0
    // 0x89d370: stur            d5, [fp, #-8]
    // 0x89d374: r0 = BoxConstraints()
    //     0x89d374: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x89d378: ldur            d0, [fp, #-0x20]
    // 0x89d37c: StoreField: r0->field_7 = d0
    //     0x89d37c: stur            d0, [x0, #7]
    // 0x89d380: ldur            d0, [fp, #-0x18]
    // 0x89d384: StoreField: r0->field_f = d0
    //     0x89d384: stur            d0, [x0, #0xf]
    // 0x89d388: ldur            d0, [fp, #-0x10]
    // 0x89d38c: ArrayStore: r0[0] = d0  ; List_8
    //     0x89d38c: stur            d0, [x0, #0x17]
    // 0x89d390: ldur            d0, [fp, #-8]
    // 0x89d394: StoreField: r0->field_1f = d0
    //     0x89d394: stur            d0, [x0, #0x1f]
    // 0x89d398: LeaveFrame
    //     0x89d398: mov             SP, fp
    //     0x89d39c: ldp             fp, lr, [SP], #0x10
    // 0x89d3a0: ret
    //     0x89d3a0: ret             
  }
  get _ biggest(/* No info */) {
    // ** addr: 0xb18a5c, size: 0x68
    // 0xb18a5c: EnterFrame
    //     0xb18a5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb18a60: mov             fp, SP
    // 0xb18a64: AllocStack(0x18)
    //     0xb18a64: sub             SP, SP, #0x18
    // 0xb18a68: SetupParameters(BoxConstraints this /* r1 => r0, fp-0x8 */)
    //     0xb18a68: mov             x0, x1
    //     0xb18a6c: stur            x1, [fp, #-8]
    // 0xb18a70: CheckStackOverflow
    //     0xb18a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb18a74: cmp             SP, x16
    //     0xb18a78: b.ls            #0xb18abc
    // 0xb18a7c: mov             x1, x0
    // 0xb18a80: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb18a80: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb18a84: r0 = constrainWidth()
    //     0xb18a84: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb18a88: ldur            x1, [fp, #-8]
    // 0xb18a8c: stur            d0, [fp, #-0x10]
    // 0xb18a90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb18a90: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb18a94: r0 = constrainHeight()
    //     0xb18a94: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb18a98: stur            d0, [fp, #-0x18]
    // 0xb18a9c: r0 = Size()
    //     0xb18a9c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18aa0: ldur            d0, [fp, #-0x10]
    // 0xb18aa4: StoreField: r0->field_7 = d0
    //     0xb18aa4: stur            d0, [x0, #7]
    // 0xb18aa8: ldur            d0, [fp, #-0x18]
    // 0xb18aac: StoreField: r0->field_f = d0
    //     0xb18aac: stur            d0, [x0, #0xf]
    // 0xb18ab0: LeaveFrame
    //     0xb18ab0: mov             SP, fp
    //     0xb18ab4: ldp             fp, lr, [SP], #0x10
    // 0xb18ab8: ret
    //     0xb18ab8: ret             
    // 0xb18abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb18abc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb18ac0: b               #0xb18a7c
  }
  get _ flipped(/* No info */) {
    // ** addr: 0xb18b2c, size: 0x5c
    // 0xb18b2c: EnterFrame
    //     0xb18b2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb18b30: mov             fp, SP
    // 0xb18b34: AllocStack(0x20)
    //     0xb18b34: sub             SP, SP, #0x20
    // 0xb18b38: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb18b38: ldur            d0, [x1, #0x17]
    // 0xb18b3c: stur            d0, [fp, #-0x20]
    // 0xb18b40: LoadField: d1 = r1->field_1f
    //     0xb18b40: ldur            d1, [x1, #0x1f]
    // 0xb18b44: stur            d1, [fp, #-0x18]
    // 0xb18b48: LoadField: d2 = r1->field_7
    //     0xb18b48: ldur            d2, [x1, #7]
    // 0xb18b4c: stur            d2, [fp, #-0x10]
    // 0xb18b50: LoadField: d3 = r1->field_f
    //     0xb18b50: ldur            d3, [x1, #0xf]
    // 0xb18b54: stur            d3, [fp, #-8]
    // 0xb18b58: r0 = BoxConstraints()
    //     0xb18b58: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb18b5c: ldur            d0, [fp, #-0x20]
    // 0xb18b60: StoreField: r0->field_7 = d0
    //     0xb18b60: stur            d0, [x0, #7]
    // 0xb18b64: ldur            d0, [fp, #-0x18]
    // 0xb18b68: StoreField: r0->field_f = d0
    //     0xb18b68: stur            d0, [x0, #0xf]
    // 0xb18b6c: ldur            d0, [fp, #-0x10]
    // 0xb18b70: ArrayStore: r0[0] = d0  ; List_8
    //     0xb18b70: stur            d0, [x0, #0x17]
    // 0xb18b74: ldur            d0, [fp, #-8]
    // 0xb18b78: StoreField: r0->field_1f = d0
    //     0xb18b78: stur            d0, [x0, #0x1f]
    // 0xb18b7c: LeaveFrame
    //     0xb18b7c: mov             SP, fp
    //     0xb18b80: ldp             fp, lr, [SP], #0x10
    // 0xb18b84: ret
    //     0xb18b84: ret             
  }
  _ constrainSizeAndAttemptToPreserveAspectRatio(/* No info */) {
    // ** addr: 0xb212f8, size: 0x1dc
    // 0xb212f8: EnterFrame
    //     0xb212f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb212fc: mov             fp, SP
    // 0xb21300: AllocStack(0x20)
    //     0xb21300: sub             SP, SP, #0x20
    // 0xb21304: SetupParameters(BoxConstraints this /* r1 => r0, fp-0x8 */)
    //     0xb21304: mov             x0, x1
    //     0xb21308: stur            x1, [fp, #-8]
    // 0xb2130c: CheckStackOverflow
    //     0xb2130c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21310: cmp             SP, x16
    //     0xb21314: b.ls            #0xb214a0
    // 0xb21318: LoadField: d0 = r0->field_7
    //     0xb21318: ldur            d0, [x0, #7]
    // 0xb2131c: LoadField: d1 = r0->field_f
    //     0xb2131c: ldur            d1, [x0, #0xf]
    // 0xb21320: fcmp            d0, d1
    // 0xb21324: b.lt            #0xb2134c
    // 0xb21328: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb21328: ldur            d2, [x0, #0x17]
    // 0xb2132c: LoadField: d3 = r0->field_1f
    //     0xb2132c: ldur            d3, [x0, #0x1f]
    // 0xb21330: fcmp            d2, d3
    // 0xb21334: b.lt            #0xb2134c
    // 0xb21338: mov             x1, x0
    // 0xb2133c: r0 = smallest()
    //     0xb2133c: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb21340: LeaveFrame
    //     0xb21340: mov             SP, fp
    //     0xb21344: ldp             fp, lr, [SP], #0x10
    // 0xb21348: ret
    //     0xb21348: ret             
    // 0xb2134c: d2 = 0.000000
    //     0xb2134c: eor             v2.16b, v2.16b, v2.16b
    // 0xb21350: LoadField: d3 = r2->field_7
    //     0xb21350: ldur            d3, [x2, #7]
    // 0xb21354: fcmp            d2, d3
    // 0xb21358: b.ge            #0xb21368
    // 0xb2135c: LoadField: d4 = r2->field_f
    //     0xb2135c: ldur            d4, [x2, #0xf]
    // 0xb21360: fcmp            d2, d4
    // 0xb21364: b.lt            #0xb2137c
    // 0xb21368: mov             x1, x0
    // 0xb2136c: r0 = constrain()
    //     0xb2136c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb21370: LeaveFrame
    //     0xb21370: mov             SP, fp
    //     0xb21374: ldp             fp, lr, [SP], #0x10
    // 0xb21378: ret
    //     0xb21378: ret             
    // 0xb2137c: fdiv            d2, d3, d4
    // 0xb21380: fcmp            d3, d1
    // 0xb21384: b.le            #0xb2139c
    // 0xb21388: fdiv            d3, d1, d2
    // 0xb2138c: mov             v31.16b, v3.16b
    // 0xb21390: mov             v3.16b, v1.16b
    // 0xb21394: mov             v1.16b, v31.16b
    // 0xb21398: b               #0xb213a0
    // 0xb2139c: mov             v1.16b, v4.16b
    // 0xb213a0: LoadField: d4 = r0->field_1f
    //     0xb213a0: ldur            d4, [x0, #0x1f]
    // 0xb213a4: fcmp            d1, d4
    // 0xb213a8: b.le            #0xb213b8
    // 0xb213ac: fmul            d1, d4, d2
    // 0xb213b0: mov             v3.16b, v1.16b
    // 0xb213b4: mov             v1.16b, v4.16b
    // 0xb213b8: fcmp            d0, d3
    // 0xb213bc: b.le            #0xb213d4
    // 0xb213c0: fdiv            d1, d0, d2
    // 0xb213c4: mov             v31.16b, v1.16b
    // 0xb213c8: mov             v1.16b, v0.16b
    // 0xb213cc: mov             v0.16b, v31.16b
    // 0xb213d0: b               #0xb213dc
    // 0xb213d4: mov             v0.16b, v1.16b
    // 0xb213d8: mov             v1.16b, v3.16b
    // 0xb213dc: ArrayLoad: d3 = r0[0]  ; List_8
    //     0xb213dc: ldur            d3, [x0, #0x17]
    // 0xb213e0: fcmp            d3, d0
    // 0xb213e4: b.le            #0xb213f4
    // 0xb213e8: fmul            d0, d3, d2
    // 0xb213ec: mov             v1.16b, v0.16b
    // 0xb213f0: mov             v0.16b, v3.16b
    // 0xb213f4: stur            d0, [fp, #-0x10]
    // 0xb213f8: r1 = inline_Allocate_Double()
    //     0xb213f8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb213fc: add             x1, x1, #0x10
    //     0xb21400: cmp             x2, x1
    //     0xb21404: b.ls            #0xb214a8
    //     0xb21408: str             x1, [THR, #0x60]  ; THR::top
    //     0xb2140c: sub             x1, x1, #0xf
    //     0xb21410: mov             x2, #0xe19c
    //     0xb21414: movk            x2, #3, lsl #16
    //     0xb21418: stur            x2, [x1, #-1]
    // 0xb2141c: dmb             ishst
    // 0xb21420: StoreField: r1->field_7 = d1
    //     0xb21420: stur            d1, [x1, #7]
    // 0xb21424: str             x1, [SP]
    // 0xb21428: mov             x1, x0
    // 0xb2142c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb2142c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb21430: r0 = constrainWidth()
    //     0xb21430: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb21434: mov             v1.16b, v0.16b
    // 0xb21438: ldur            d0, [fp, #-0x10]
    // 0xb2143c: stur            d1, [fp, #-0x18]
    // 0xb21440: r0 = inline_Allocate_Double()
    //     0xb21440: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb21444: add             x0, x0, #0x10
    //     0xb21448: cmp             x1, x0
    //     0xb2144c: b.ls            #0xb214c4
    //     0xb21450: str             x0, [THR, #0x60]  ; THR::top
    //     0xb21454: sub             x0, x0, #0xf
    //     0xb21458: mov             x1, #0xe19c
    //     0xb2145c: movk            x1, #3, lsl #16
    //     0xb21460: stur            x1, [x0, #-1]
    // 0xb21464: dmb             ishst
    // 0xb21468: StoreField: r0->field_7 = d0
    //     0xb21468: stur            d0, [x0, #7]
    // 0xb2146c: str             x0, [SP]
    // 0xb21470: ldur            x1, [fp, #-8]
    // 0xb21474: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb21474: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb21478: r0 = constrainHeight()
    //     0xb21478: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb2147c: stur            d0, [fp, #-0x10]
    // 0xb21480: r0 = Size()
    //     0xb21480: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb21484: ldur            d0, [fp, #-0x18]
    // 0xb21488: StoreField: r0->field_7 = d0
    //     0xb21488: stur            d0, [x0, #7]
    // 0xb2148c: ldur            d0, [fp, #-0x10]
    // 0xb21490: StoreField: r0->field_f = d0
    //     0xb21490: stur            d0, [x0, #0xf]
    // 0xb21494: LeaveFrame
    //     0xb21494: mov             SP, fp
    //     0xb21498: ldp             fp, lr, [SP], #0x10
    // 0xb2149c: ret
    //     0xb2149c: ret             
    // 0xb214a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb214a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb214a4: b               #0xb21318
    // 0xb214a8: stp             q0, q1, [SP, #-0x20]!
    // 0xb214ac: SaveReg r0
    //     0xb214ac: str             x0, [SP, #-8]!
    // 0xb214b0: r0 = AllocateDouble()
    //     0xb214b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb214b4: mov             x1, x0
    // 0xb214b8: RestoreReg r0
    //     0xb214b8: ldr             x0, [SP], #8
    // 0xb214bc: ldp             q0, q1, [SP], #0x20
    // 0xb214c0: b               #0xb21420
    // 0xb214c4: stp             q0, q1, [SP, #-0x20]!
    // 0xb214c8: r0 = AllocateDouble()
    //     0xb214c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb214cc: ldp             q0, q1, [SP], #0x20
    // 0xb214d0: b               #0xb21468
  }
  get _ smallest(/* No info */) {
    // ** addr: 0xb214d4, size: 0x78
    // 0xb214d4: EnterFrame
    //     0xb214d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb214d8: mov             fp, SP
    // 0xb214dc: AllocStack(0x20)
    //     0xb214dc: sub             SP, SP, #0x20
    // 0xb214e0: SetupParameters(BoxConstraints this /* r1 => r0, fp-0x8 */)
    //     0xb214e0: mov             x0, x1
    //     0xb214e4: stur            x1, [fp, #-8]
    // 0xb214e8: CheckStackOverflow
    //     0xb214e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb214ec: cmp             SP, x16
    //     0xb214f0: b.ls            #0xb21544
    // 0xb214f4: r16 = 0.000000
    //     0xb214f4: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb214f8: str             x16, [SP]
    // 0xb214fc: mov             x1, x0
    // 0xb21500: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb21500: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb21504: r0 = constrainWidth()
    //     0xb21504: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb21508: stur            d0, [fp, #-0x10]
    // 0xb2150c: r16 = 0.000000
    //     0xb2150c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb21510: str             x16, [SP]
    // 0xb21514: ldur            x1, [fp, #-8]
    // 0xb21518: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb21518: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb2151c: r0 = constrainHeight()
    //     0xb2151c: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb21520: stur            d0, [fp, #-0x18]
    // 0xb21524: r0 = Size()
    //     0xb21524: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb21528: ldur            d0, [fp, #-0x10]
    // 0xb2152c: StoreField: r0->field_7 = d0
    //     0xb2152c: stur            d0, [x0, #7]
    // 0xb21530: ldur            d0, [fp, #-0x18]
    // 0xb21534: StoreField: r0->field_f = d0
    //     0xb21534: stur            d0, [x0, #0xf]
    // 0xb21538: LeaveFrame
    //     0xb21538: mov             SP, fp
    //     0xb2153c: ldp             fp, lr, [SP], #0x10
    // 0xb21540: ret
    //     0xb21540: ret             
    // 0xb21544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21548: b               #0xb214f4
  }
  _ enforce(/* No info */) {
    // ** addr: 0xb2154c, size: 0x11c
    // 0xb2154c: EnterFrame
    //     0xb2154c: stp             fp, lr, [SP, #-0x10]!
    //     0xb21550: mov             fp, SP
    // 0xb21554: AllocStack(0x20)
    //     0xb21554: sub             SP, SP, #0x20
    // 0xb21558: LoadField: d0 = r1->field_7
    //     0xb21558: ldur            d0, [x1, #7]
    // 0xb2155c: LoadField: d1 = r2->field_7
    //     0xb2155c: ldur            d1, [x2, #7]
    // 0xb21560: LoadField: d2 = r2->field_f
    //     0xb21560: ldur            d2, [x2, #0xf]
    // 0xb21564: fcmp            d1, d0
    // 0xb21568: b.le            #0xb21574
    // 0xb2156c: mov             v0.16b, v1.16b
    // 0xb21570: b               #0xb21590
    // 0xb21574: fcmp            d0, d2
    // 0xb21578: b.le            #0xb21584
    // 0xb2157c: mov             v0.16b, v2.16b
    // 0xb21580: b               #0xb21590
    // 0xb21584: fcmp            d0, d0
    // 0xb21588: b.vc            #0xb21590
    // 0xb2158c: mov             v0.16b, v2.16b
    // 0xb21590: stur            d0, [fp, #-0x20]
    // 0xb21594: LoadField: d3 = r1->field_f
    //     0xb21594: ldur            d3, [x1, #0xf]
    // 0xb21598: fcmp            d1, d3
    // 0xb2159c: b.gt            #0xb215c4
    // 0xb215a0: fcmp            d3, d2
    // 0xb215a4: b.le            #0xb215b0
    // 0xb215a8: mov             v1.16b, v2.16b
    // 0xb215ac: b               #0xb215c4
    // 0xb215b0: fcmp            d3, d3
    // 0xb215b4: b.vc            #0xb215c0
    // 0xb215b8: mov             v1.16b, v2.16b
    // 0xb215bc: b               #0xb215c4
    // 0xb215c0: mov             v1.16b, v3.16b
    // 0xb215c4: stur            d1, [fp, #-0x18]
    // 0xb215c8: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb215c8: ldur            d2, [x1, #0x17]
    // 0xb215cc: ArrayLoad: d3 = r2[0]  ; List_8
    //     0xb215cc: ldur            d3, [x2, #0x17]
    // 0xb215d0: LoadField: d4 = r2->field_1f
    //     0xb215d0: ldur            d4, [x2, #0x1f]
    // 0xb215d4: fcmp            d3, d2
    // 0xb215d8: b.le            #0xb215e4
    // 0xb215dc: mov             v2.16b, v3.16b
    // 0xb215e0: b               #0xb21600
    // 0xb215e4: fcmp            d2, d4
    // 0xb215e8: b.le            #0xb215f4
    // 0xb215ec: mov             v2.16b, v4.16b
    // 0xb215f0: b               #0xb21600
    // 0xb215f4: fcmp            d2, d2
    // 0xb215f8: b.vc            #0xb21600
    // 0xb215fc: mov             v2.16b, v4.16b
    // 0xb21600: stur            d2, [fp, #-0x10]
    // 0xb21604: LoadField: d5 = r1->field_1f
    //     0xb21604: ldur            d5, [x1, #0x1f]
    // 0xb21608: fcmp            d3, d5
    // 0xb2160c: b.gt            #0xb21634
    // 0xb21610: fcmp            d5, d4
    // 0xb21614: b.le            #0xb21620
    // 0xb21618: mov             v3.16b, v4.16b
    // 0xb2161c: b               #0xb21634
    // 0xb21620: fcmp            d5, d5
    // 0xb21624: b.vc            #0xb21630
    // 0xb21628: mov             v3.16b, v4.16b
    // 0xb2162c: b               #0xb21634
    // 0xb21630: mov             v3.16b, v5.16b
    // 0xb21634: stur            d3, [fp, #-8]
    // 0xb21638: r0 = BoxConstraints()
    //     0xb21638: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2163c: ldur            d0, [fp, #-0x20]
    // 0xb21640: StoreField: r0->field_7 = d0
    //     0xb21640: stur            d0, [x0, #7]
    // 0xb21644: ldur            d0, [fp, #-0x18]
    // 0xb21648: StoreField: r0->field_f = d0
    //     0xb21648: stur            d0, [x0, #0xf]
    // 0xb2164c: ldur            d0, [fp, #-0x10]
    // 0xb21650: ArrayStore: r0[0] = d0  ; List_8
    //     0xb21650: stur            d0, [x0, #0x17]
    // 0xb21654: ldur            d0, [fp, #-8]
    // 0xb21658: StoreField: r0->field_1f = d0
    //     0xb21658: stur            d0, [x0, #0x1f]
    // 0xb2165c: LeaveFrame
    //     0xb2165c: mov             SP, fp
    //     0xb21660: ldp             fp, lr, [SP], #0x10
    // 0xb21664: ret
    //     0xb21664: ret             
  }
  _ tighten(/* No info */) {
    // ** addr: 0xb4aa24, size: 0x1e4
    // 0xb4aa24: EnterFrame
    //     0xb4aa24: stp             fp, lr, [SP, #-0x10]!
    //     0xb4aa28: mov             fp, SP
    // 0xb4aa2c: AllocStack(0x20)
    //     0xb4aa2c: sub             SP, SP, #0x20
    // 0xb4aa30: SetupParameters({dynamic height = Null /* r3 */, dynamic width = Null /* r0 */})
    //     0xb4aa30: ldur            w0, [x4, #0x13]
    //     0xb4aa34: ldur            w2, [x4, #0x1f]
    //     0xb4aa38: add             x2, x2, HEAP, lsl #32
    //     0xb4aa3c: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    //     0xb4aa40: cmp             w2, w16
    //     0xb4aa44: b.ne            #0xb4aa68
    //     0xb4aa48: ldur            w2, [x4, #0x23]
    //     0xb4aa4c: add             x2, x2, HEAP, lsl #32
    //     0xb4aa50: sub             w3, w0, w2
    //     0xb4aa54: add             x2, fp, w3, sxtw #2
    //     0xb4aa58: ldr             x2, [x2, #8]
    //     0xb4aa5c: mov             x3, x2
    //     0xb4aa60: mov             x2, #1
    //     0xb4aa64: b               #0xb4aa70
    //     0xb4aa68: mov             x3, NULL
    //     0xb4aa6c: mov             x2, #0
    //     0xb4aa70: lsl             x5, x2, #1
    //     0xb4aa74: lsl             w2, w5, #1
    //     0xb4aa78: add             w5, w2, #8
    //     0xb4aa7c: add             x16, x4, w5, sxtw #1
    //     0xb4aa80: ldur            w6, [x16, #0xf]
    //     0xb4aa84: add             x6, x6, HEAP, lsl #32
    //     0xb4aa88: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    //     0xb4aa8c: cmp             w6, w16
    //     0xb4aa90: b.ne            #0xb4aab4
    //     0xb4aa94: add             w5, w2, #0xa
    //     0xb4aa98: add             x16, x4, w5, sxtw #1
    //     0xb4aa9c: ldur            w2, [x16, #0xf]
    //     0xb4aaa0: add             x2, x2, HEAP, lsl #32
    //     0xb4aaa4: sub             w4, w0, w2
    //     0xb4aaa8: add             x0, fp, w4, sxtw #2
    //     0xb4aaac: ldr             x0, [x0, #8]
    //     0xb4aab0: b               #0xb4aab8
    //     0xb4aab4: mov             x0, NULL
    // 0xb4aab8: cmp             w0, NULL
    // 0xb4aabc: b.ne            #0xb4aacc
    // 0xb4aac0: LoadField: d0 = r1->field_7
    //     0xb4aac0: ldur            d0, [x1, #7]
    // 0xb4aac4: mov             v1.16b, v0.16b
    // 0xb4aac8: b               #0xb4aafc
    // 0xb4aacc: LoadField: d0 = r1->field_7
    //     0xb4aacc: ldur            d0, [x1, #7]
    // 0xb4aad0: LoadField: d1 = r1->field_f
    //     0xb4aad0: ldur            d1, [x1, #0xf]
    // 0xb4aad4: LoadField: d2 = r0->field_7
    //     0xb4aad4: ldur            d2, [x0, #7]
    // 0xb4aad8: fcmp            d0, d2
    // 0xb4aadc: b.le            #0xb4aae8
    // 0xb4aae0: mov             v1.16b, v0.16b
    // 0xb4aae4: b               #0xb4aafc
    // 0xb4aae8: fcmp            d2, d1
    // 0xb4aaec: b.gt            #0xb4aafc
    // 0xb4aaf0: fcmp            d2, d2
    // 0xb4aaf4: b.vs            #0xb4aafc
    // 0xb4aaf8: mov             v1.16b, v2.16b
    // 0xb4aafc: stur            d1, [fp, #-0x20]
    // 0xb4ab00: cmp             w0, NULL
    // 0xb4ab04: b.ne            #0xb4ab10
    // 0xb4ab08: LoadField: d0 = r1->field_f
    //     0xb4ab08: ldur            d0, [x1, #0xf]
    // 0xb4ab0c: b               #0xb4ab44
    // 0xb4ab10: LoadField: d2 = r1->field_f
    //     0xb4ab10: ldur            d2, [x1, #0xf]
    // 0xb4ab14: LoadField: d3 = r0->field_7
    //     0xb4ab14: ldur            d3, [x0, #7]
    // 0xb4ab18: fcmp            d0, d3
    // 0xb4ab1c: b.gt            #0xb4ab44
    // 0xb4ab20: fcmp            d3, d2
    // 0xb4ab24: b.le            #0xb4ab30
    // 0xb4ab28: mov             v0.16b, v2.16b
    // 0xb4ab2c: b               #0xb4ab44
    // 0xb4ab30: fcmp            d3, d3
    // 0xb4ab34: b.vc            #0xb4ab40
    // 0xb4ab38: mov             v0.16b, v2.16b
    // 0xb4ab3c: b               #0xb4ab44
    // 0xb4ab40: mov             v0.16b, v3.16b
    // 0xb4ab44: stur            d0, [fp, #-0x18]
    // 0xb4ab48: cmp             w3, NULL
    // 0xb4ab4c: b.ne            #0xb4ab5c
    // 0xb4ab50: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb4ab50: ldur            d2, [x1, #0x17]
    // 0xb4ab54: mov             v3.16b, v2.16b
    // 0xb4ab58: b               #0xb4ab8c
    // 0xb4ab5c: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb4ab5c: ldur            d2, [x1, #0x17]
    // 0xb4ab60: LoadField: d3 = r1->field_1f
    //     0xb4ab60: ldur            d3, [x1, #0x1f]
    // 0xb4ab64: LoadField: d4 = r3->field_7
    //     0xb4ab64: ldur            d4, [x3, #7]
    // 0xb4ab68: fcmp            d2, d4
    // 0xb4ab6c: b.le            #0xb4ab78
    // 0xb4ab70: mov             v3.16b, v2.16b
    // 0xb4ab74: b               #0xb4ab8c
    // 0xb4ab78: fcmp            d4, d3
    // 0xb4ab7c: b.gt            #0xb4ab8c
    // 0xb4ab80: fcmp            d4, d4
    // 0xb4ab84: b.vs            #0xb4ab8c
    // 0xb4ab88: mov             v3.16b, v4.16b
    // 0xb4ab8c: stur            d3, [fp, #-0x10]
    // 0xb4ab90: cmp             w3, NULL
    // 0xb4ab94: b.ne            #0xb4aba0
    // 0xb4ab98: LoadField: d2 = r1->field_1f
    //     0xb4ab98: ldur            d2, [x1, #0x1f]
    // 0xb4ab9c: b               #0xb4abd4
    // 0xb4aba0: LoadField: d4 = r1->field_1f
    //     0xb4aba0: ldur            d4, [x1, #0x1f]
    // 0xb4aba4: LoadField: d5 = r3->field_7
    //     0xb4aba4: ldur            d5, [x3, #7]
    // 0xb4aba8: fcmp            d2, d5
    // 0xb4abac: b.gt            #0xb4abd4
    // 0xb4abb0: fcmp            d5, d4
    // 0xb4abb4: b.le            #0xb4abc0
    // 0xb4abb8: mov             v2.16b, v4.16b
    // 0xb4abbc: b               #0xb4abd4
    // 0xb4abc0: fcmp            d5, d5
    // 0xb4abc4: b.vc            #0xb4abd0
    // 0xb4abc8: mov             v2.16b, v4.16b
    // 0xb4abcc: b               #0xb4abd4
    // 0xb4abd0: mov             v2.16b, v5.16b
    // 0xb4abd4: stur            d2, [fp, #-8]
    // 0xb4abd8: r0 = BoxConstraints()
    //     0xb4abd8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4abdc: ldur            d0, [fp, #-0x20]
    // 0xb4abe0: StoreField: r0->field_7 = d0
    //     0xb4abe0: stur            d0, [x0, #7]
    // 0xb4abe4: ldur            d0, [fp, #-0x18]
    // 0xb4abe8: StoreField: r0->field_f = d0
    //     0xb4abe8: stur            d0, [x0, #0xf]
    // 0xb4abec: ldur            d0, [fp, #-0x10]
    // 0xb4abf0: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4abf0: stur            d0, [x0, #0x17]
    // 0xb4abf4: ldur            d0, [fp, #-8]
    // 0xb4abf8: StoreField: r0->field_1f = d0
    //     0xb4abf8: stur            d0, [x0, #0x1f]
    // 0xb4abfc: LeaveFrame
    //     0xb4abfc: mov             SP, fp
    //     0xb4ac00: ldp             fp, lr, [SP], #0x10
    // 0xb4ac04: ret
    //     0xb4ac04: ret             
  }
  _ loosen(/* No info */) {
    // ** addr: 0xb4ae38, size: 0x44
    // 0xb4ae38: EnterFrame
    //     0xb4ae38: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ae3c: mov             fp, SP
    // 0xb4ae40: AllocStack(0x10)
    //     0xb4ae40: sub             SP, SP, #0x10
    // 0xb4ae44: LoadField: d0 = r1->field_f
    //     0xb4ae44: ldur            d0, [x1, #0xf]
    // 0xb4ae48: stur            d0, [fp, #-0x10]
    // 0xb4ae4c: LoadField: d1 = r1->field_1f
    //     0xb4ae4c: ldur            d1, [x1, #0x1f]
    // 0xb4ae50: stur            d1, [fp, #-8]
    // 0xb4ae54: r0 = BoxConstraints()
    //     0xb4ae54: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4ae58: StoreField: r0->field_7 = rZR
    //     0xb4ae58: stur            xzr, [x0, #7]
    // 0xb4ae5c: ldur            d0, [fp, #-0x10]
    // 0xb4ae60: StoreField: r0->field_f = d0
    //     0xb4ae60: stur            d0, [x0, #0xf]
    // 0xb4ae64: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb4ae64: stur            xzr, [x0, #0x17]
    // 0xb4ae68: ldur            d0, [fp, #-8]
    // 0xb4ae6c: StoreField: r0->field_1f = d0
    //     0xb4ae6c: stur            d0, [x0, #0x1f]
    // 0xb4ae70: LeaveFrame
    //     0xb4ae70: mov             SP, fp
    //     0xb4ae74: ldp             fp, lr, [SP], #0x10
    // 0xb4ae78: ret
    //     0xb4ae78: ret             
  }
  _ deflate(/* No info */) {
    // ** addr: 0xb4cd58, size: 0xc0
    // 0xb4cd58: EnterFrame
    //     0xb4cd58: stp             fp, lr, [SP, #-0x10]!
    //     0xb4cd5c: mov             fp, SP
    // 0xb4cd60: AllocStack(0x30)
    //     0xb4cd60: sub             SP, SP, #0x30
    // 0xb4cd64: SetupParameters(BoxConstraints this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4cd64: mov             x0, x2
    //     0xb4cd68: stur            x2, [fp, #-0x10]
    //     0xb4cd6c: mov             x2, x1
    //     0xb4cd70: stur            x1, [fp, #-8]
    // 0xb4cd74: CheckStackOverflow
    //     0xb4cd74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4cd78: cmp             SP, x16
    //     0xb4cd7c: b.ls            #0xb4ce10
    // 0xb4cd80: mov             x1, x0
    // 0xb4cd84: r0 = horizontal()
    //     0xb4cd84: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb4cd88: ldur            x1, [fp, #-0x10]
    // 0xb4cd8c: stur            d0, [fp, #-0x18]
    // 0xb4cd90: r0 = vertical()
    //     0xb4cd90: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb4cd94: ldur            x0, [fp, #-8]
    // 0xb4cd98: LoadField: d1 = r0->field_7
    //     0xb4cd98: ldur            d1, [x0, #7]
    // 0xb4cd9c: ldur            d2, [fp, #-0x18]
    // 0xb4cda0: fsub            d3, d1, d2
    // 0xb4cda4: d1 = 0.000000
    //     0xb4cda4: eor             v1.16b, v1.16b, v1.16b
    // 0xb4cda8: fmax            v4.2d, v1.2d, v3.2d
    // 0xb4cdac: stur            d4, [fp, #-0x30]
    // 0xb4cdb0: ArrayLoad: d3 = r0[0]  ; List_8
    //     0xb4cdb0: ldur            d3, [x0, #0x17]
    // 0xb4cdb4: fsub            d5, d3, d0
    // 0xb4cdb8: fmax            v3.2d, v1.2d, v5.2d
    // 0xb4cdbc: stur            d3, [fp, #-0x28]
    // 0xb4cdc0: LoadField: d1 = r0->field_f
    //     0xb4cdc0: ldur            d1, [x0, #0xf]
    // 0xb4cdc4: fsub            d5, d1, d2
    // 0xb4cdc8: fmax            v1.2d, v4.2d, v5.2d
    // 0xb4cdcc: stur            d1, [fp, #-0x20]
    // 0xb4cdd0: LoadField: d2 = r0->field_1f
    //     0xb4cdd0: ldur            d2, [x0, #0x1f]
    // 0xb4cdd4: fsub            d5, d2, d0
    // 0xb4cdd8: fmax            v0.2d, v3.2d, v5.2d
    // 0xb4cddc: stur            d0, [fp, #-0x18]
    // 0xb4cde0: r0 = BoxConstraints()
    //     0xb4cde0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4cde4: ldur            d0, [fp, #-0x30]
    // 0xb4cde8: StoreField: r0->field_7 = d0
    //     0xb4cde8: stur            d0, [x0, #7]
    // 0xb4cdec: ldur            d0, [fp, #-0x20]
    // 0xb4cdf0: StoreField: r0->field_f = d0
    //     0xb4cdf0: stur            d0, [x0, #0xf]
    // 0xb4cdf4: ldur            d0, [fp, #-0x28]
    // 0xb4cdf8: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4cdf8: stur            d0, [x0, #0x17]
    // 0xb4cdfc: ldur            d0, [fp, #-0x18]
    // 0xb4ce00: StoreField: r0->field_1f = d0
    //     0xb4ce00: stur            d0, [x0, #0x1f]
    // 0xb4ce04: LeaveFrame
    //     0xb4ce04: mov             SP, fp
    //     0xb4ce08: ldp             fp, lr, [SP], #0x10
    // 0xb4ce0c: ret
    //     0xb4ce0c: ret             
    // 0xb4ce10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4ce10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4ce14: b               #0xb4cd80
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xb4cfe8, size: 0x1dc
    // 0xb4cfe8: EnterFrame
    //     0xb4cfe8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4cfec: mov             fp, SP
    // 0xb4cff0: AllocStack(0x20)
    //     0xb4cff0: sub             SP, SP, #0x20
    // 0xb4cff4: SetupParameters({dynamic maxHeight = Null /* r3 */, dynamic maxWidth = Null /* r5 */, dynamic minHeight = Null /* r6 */, dynamic minWidth = Null /* r0 */})
    //     0xb4cff4: ldur            w0, [x4, #0x13]
    //     0xb4cff8: ldur            w2, [x4, #0x1f]
    //     0xb4cffc: add             x2, x2, HEAP, lsl #32
    //     0xb4d000: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c60] "maxHeight"
    //     0xb4d004: ldr             x16, [x16, #0xc60]
    //     0xb4d008: cmp             w2, w16
    //     0xb4d00c: b.ne            #0xb4d030
    //     0xb4d010: ldur            w2, [x4, #0x23]
    //     0xb4d014: add             x2, x2, HEAP, lsl #32
    //     0xb4d018: sub             w3, w0, w2
    //     0xb4d01c: add             x2, fp, w3, sxtw #2
    //     0xb4d020: ldr             x2, [x2, #8]
    //     0xb4d024: mov             x3, x2
    //     0xb4d028: mov             x2, #1
    //     0xb4d02c: b               #0xb4d038
    //     0xb4d030: mov             x3, NULL
    //     0xb4d034: mov             x2, #0
    //     0xb4d038: lsl             x5, x2, #1
    //     0xb4d03c: lsl             w6, w5, #1
    //     0xb4d040: add             w7, w6, #8
    //     0xb4d044: add             x16, x4, w7, sxtw #1
    //     0xb4d048: ldur            w8, [x16, #0xf]
    //     0xb4d04c: add             x8, x8, HEAP, lsl #32
    //     0xb4d050: ldr             x16, [PP, #0x4cb0]  ; [pp+0x4cb0] "maxWidth"
    //     0xb4d054: cmp             w8, w16
    //     0xb4d058: b.ne            #0xb4d08c
    //     0xb4d05c: add             w2, w6, #0xa
    //     0xb4d060: add             x16, x4, w2, sxtw #1
    //     0xb4d064: ldur            w6, [x16, #0xf]
    //     0xb4d068: add             x6, x6, HEAP, lsl #32
    //     0xb4d06c: sub             w2, w0, w6
    //     0xb4d070: add             x6, fp, w2, sxtw #2
    //     0xb4d074: ldr             x6, [x6, #8]
    //     0xb4d078: add             w2, w5, #2
    //     0xb4d07c: sbfx            x5, x2, #1, #0x1f
    //     0xb4d080: mov             x2, x5
    //     0xb4d084: mov             x5, x6
    //     0xb4d088: b               #0xb4d090
    //     0xb4d08c: mov             x5, NULL
    //     0xb4d090: lsl             x6, x2, #1
    //     0xb4d094: lsl             w7, w6, #1
    //     0xb4d098: add             w8, w7, #8
    //     0xb4d09c: add             x16, x4, w8, sxtw #1
    //     0xb4d0a0: ldur            w9, [x16, #0xf]
    //     0xb4d0a4: add             x9, x9, HEAP, lsl #32
    //     0xb4d0a8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c68] "minHeight"
    //     0xb4d0ac: ldr             x16, [x16, #0xc68]
    //     0xb4d0b0: cmp             w9, w16
    //     0xb4d0b4: b.ne            #0xb4d0e8
    //     0xb4d0b8: add             w2, w7, #0xa
    //     0xb4d0bc: add             x16, x4, w2, sxtw #1
    //     0xb4d0c0: ldur            w7, [x16, #0xf]
    //     0xb4d0c4: add             x7, x7, HEAP, lsl #32
    //     0xb4d0c8: sub             w2, w0, w7
    //     0xb4d0cc: add             x7, fp, w2, sxtw #2
    //     0xb4d0d0: ldr             x7, [x7, #8]
    //     0xb4d0d4: add             w2, w6, #2
    //     0xb4d0d8: sbfx            x6, x2, #1, #0x1f
    //     0xb4d0dc: mov             x2, x6
    //     0xb4d0e0: mov             x6, x7
    //     0xb4d0e4: b               #0xb4d0ec
    //     0xb4d0e8: mov             x6, NULL
    //     0xb4d0ec: lsl             x7, x2, #1
    //     0xb4d0f0: lsl             w2, w7, #1
    //     0xb4d0f4: add             w7, w2, #8
    //     0xb4d0f8: add             x16, x4, w7, sxtw #1
    //     0xb4d0fc: ldur            w8, [x16, #0xf]
    //     0xb4d100: add             x8, x8, HEAP, lsl #32
    //     0xb4d104: ldr             x16, [PP, #0x4cb8]  ; [pp+0x4cb8] "minWidth"
    //     0xb4d108: cmp             w8, w16
    //     0xb4d10c: b.ne            #0xb4d130
    //     0xb4d110: add             w7, w2, #0xa
    //     0xb4d114: add             x16, x4, w7, sxtw #1
    //     0xb4d118: ldur            w2, [x16, #0xf]
    //     0xb4d11c: add             x2, x2, HEAP, lsl #32
    //     0xb4d120: sub             w4, w0, w2
    //     0xb4d124: add             x0, fp, w4, sxtw #2
    //     0xb4d128: ldr             x0, [x0, #8]
    //     0xb4d12c: b               #0xb4d134
    //     0xb4d130: mov             x0, NULL
    // 0xb4d134: cmp             w0, NULL
    // 0xb4d138: b.ne            #0xb4d144
    // 0xb4d13c: LoadField: d0 = r1->field_7
    //     0xb4d13c: ldur            d0, [x1, #7]
    // 0xb4d140: b               #0xb4d148
    // 0xb4d144: LoadField: d0 = r0->field_7
    //     0xb4d144: ldur            d0, [x0, #7]
    // 0xb4d148: stur            d0, [fp, #-0x20]
    // 0xb4d14c: cmp             w5, NULL
    // 0xb4d150: b.ne            #0xb4d15c
    // 0xb4d154: LoadField: d1 = r1->field_f
    //     0xb4d154: ldur            d1, [x1, #0xf]
    // 0xb4d158: b               #0xb4d160
    // 0xb4d15c: LoadField: d1 = r5->field_7
    //     0xb4d15c: ldur            d1, [x5, #7]
    // 0xb4d160: stur            d1, [fp, #-0x18]
    // 0xb4d164: cmp             w6, NULL
    // 0xb4d168: b.ne            #0xb4d174
    // 0xb4d16c: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb4d16c: ldur            d2, [x1, #0x17]
    // 0xb4d170: b               #0xb4d178
    // 0xb4d174: LoadField: d2 = r6->field_7
    //     0xb4d174: ldur            d2, [x6, #7]
    // 0xb4d178: stur            d2, [fp, #-0x10]
    // 0xb4d17c: cmp             w3, NULL
    // 0xb4d180: b.ne            #0xb4d18c
    // 0xb4d184: LoadField: d3 = r1->field_1f
    //     0xb4d184: ldur            d3, [x1, #0x1f]
    // 0xb4d188: b               #0xb4d190
    // 0xb4d18c: LoadField: d3 = r3->field_7
    //     0xb4d18c: ldur            d3, [x3, #7]
    // 0xb4d190: stur            d3, [fp, #-8]
    // 0xb4d194: r0 = BoxConstraints()
    //     0xb4d194: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4d198: ldur            d0, [fp, #-0x20]
    // 0xb4d19c: StoreField: r0->field_7 = d0
    //     0xb4d19c: stur            d0, [x0, #7]
    // 0xb4d1a0: ldur            d0, [fp, #-0x18]
    // 0xb4d1a4: StoreField: r0->field_f = d0
    //     0xb4d1a4: stur            d0, [x0, #0xf]
    // 0xb4d1a8: ldur            d0, [fp, #-0x10]
    // 0xb4d1ac: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4d1ac: stur            d0, [x0, #0x17]
    // 0xb4d1b0: ldur            d0, [fp, #-8]
    // 0xb4d1b4: StoreField: r0->field_1f = d0
    //     0xb4d1b4: stur            d0, [x0, #0x1f]
    // 0xb4d1b8: LeaveFrame
    //     0xb4d1b8: mov             SP, fp
    //     0xb4d1bc: ldp             fp, lr, [SP], #0x10
    // 0xb4d1c0: ret
    //     0xb4d1c0: ret             
  }
  _ widthConstraints(/* No info */) {
    // ** addr: 0xb4e044, size: 0x48
    // 0xb4e044: EnterFrame
    //     0xb4e044: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e048: mov             fp, SP
    // 0xb4e04c: AllocStack(0x10)
    //     0xb4e04c: sub             SP, SP, #0x10
    // 0xb4e050: LoadField: d0 = r1->field_7
    //     0xb4e050: ldur            d0, [x1, #7]
    // 0xb4e054: stur            d0, [fp, #-0x10]
    // 0xb4e058: LoadField: d1 = r1->field_f
    //     0xb4e058: ldur            d1, [x1, #0xf]
    // 0xb4e05c: stur            d1, [fp, #-8]
    // 0xb4e060: r0 = BoxConstraints()
    //     0xb4e060: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4e064: ldur            d0, [fp, #-0x10]
    // 0xb4e068: StoreField: r0->field_7 = d0
    //     0xb4e068: stur            d0, [x0, #7]
    // 0xb4e06c: ldur            d0, [fp, #-8]
    // 0xb4e070: StoreField: r0->field_f = d0
    //     0xb4e070: stur            d0, [x0, #0xf]
    // 0xb4e074: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb4e074: stur            xzr, [x0, #0x17]
    // 0xb4e078: d0 = inf
    //     0xb4e078: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4e07c: StoreField: r0->field_1f = d0
    //     0xb4e07c: stur            d0, [x0, #0x1f]
    // 0xb4e080: LeaveFrame
    //     0xb4e080: mov             SP, fp
    //     0xb4e084: ldp             fp, lr, [SP], #0x10
    // 0xb4e088: ret
    //     0xb4e088: ret             
  }
  _ heightConstraints(/* No info */) {
    // ** addr: 0xb4e08c, size: 0x48
    // 0xb4e08c: EnterFrame
    //     0xb4e08c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e090: mov             fp, SP
    // 0xb4e094: AllocStack(0x10)
    //     0xb4e094: sub             SP, SP, #0x10
    // 0xb4e098: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb4e098: ldur            d0, [x1, #0x17]
    // 0xb4e09c: stur            d0, [fp, #-0x10]
    // 0xb4e0a0: LoadField: d1 = r1->field_1f
    //     0xb4e0a0: ldur            d1, [x1, #0x1f]
    // 0xb4e0a4: stur            d1, [fp, #-8]
    // 0xb4e0a8: r0 = BoxConstraints()
    //     0xb4e0a8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4e0ac: StoreField: r0->field_7 = rZR
    //     0xb4e0ac: stur            xzr, [x0, #7]
    // 0xb4e0b0: d0 = inf
    //     0xb4e0b0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4e0b4: StoreField: r0->field_f = d0
    //     0xb4e0b4: stur            d0, [x0, #0xf]
    // 0xb4e0b8: ldur            d0, [fp, #-0x10]
    // 0xb4e0bc: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4e0bc: stur            d0, [x0, #0x17]
    // 0xb4e0c0: ldur            d0, [fp, #-8]
    // 0xb4e0c4: StoreField: r0->field_1f = d0
    //     0xb4e0c4: stur            d0, [x0, #0x1f]
    // 0xb4e0c8: LeaveFrame
    //     0xb4e0c8: mov             SP, fp
    //     0xb4e0cc: ldp             fp, lr, [SP], #0x10
    // 0xb4e0d0: ret
    //     0xb4e0d0: ret             
  }
  _ constrainDimensions(/* No info */) {
    // ** addr: 0xbc8bf8, size: 0x100
    // 0xbc8bf8: EnterFrame
    //     0xbc8bf8: stp             fp, lr, [SP, #-0x10]!
    //     0xbc8bfc: mov             fp, SP
    // 0xbc8c00: AllocStack(0x20)
    //     0xbc8c00: sub             SP, SP, #0x20
    // 0xbc8c04: SetupParameters(BoxConstraints this /* r1 => r0, fp-0x8 */, dynamic _ /* d1 => d1, fp-0x10 */)
    //     0xbc8c04: mov             x0, x1
    //     0xbc8c08: stur            x1, [fp, #-8]
    //     0xbc8c0c: stur            d1, [fp, #-0x10]
    // 0xbc8c10: CheckStackOverflow
    //     0xbc8c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc8c14: cmp             SP, x16
    //     0xbc8c18: b.ls            #0xbc8cc4
    // 0xbc8c1c: r1 = inline_Allocate_Double()
    //     0xbc8c1c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbc8c20: add             x1, x1, #0x10
    //     0xbc8c24: cmp             x2, x1
    //     0xbc8c28: b.ls            #0xbc8ccc
    //     0xbc8c2c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbc8c30: sub             x1, x1, #0xf
    //     0xbc8c34: mov             x2, #0xe19c
    //     0xbc8c38: movk            x2, #3, lsl #16
    //     0xbc8c3c: stur            x2, [x1, #-1]
    // 0xbc8c40: dmb             ishst
    // 0xbc8c44: StoreField: r1->field_7 = d0
    //     0xbc8c44: stur            d0, [x1, #7]
    // 0xbc8c48: str             x1, [SP]
    // 0xbc8c4c: mov             x1, x0
    // 0xbc8c50: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbc8c50: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbc8c54: r0 = constrainWidth()
    //     0xbc8c54: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xbc8c58: mov             v1.16b, v0.16b
    // 0xbc8c5c: ldur            d0, [fp, #-0x10]
    // 0xbc8c60: stur            d1, [fp, #-0x18]
    // 0xbc8c64: r0 = inline_Allocate_Double()
    //     0xbc8c64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc8c68: add             x0, x0, #0x10
    //     0xbc8c6c: cmp             x1, x0
    //     0xbc8c70: b.ls            #0xbc8ce8
    //     0xbc8c74: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc8c78: sub             x0, x0, #0xf
    //     0xbc8c7c: mov             x1, #0xe19c
    //     0xbc8c80: movk            x1, #3, lsl #16
    //     0xbc8c84: stur            x1, [x0, #-1]
    // 0xbc8c88: dmb             ishst
    // 0xbc8c8c: StoreField: r0->field_7 = d0
    //     0xbc8c8c: stur            d0, [x0, #7]
    // 0xbc8c90: str             x0, [SP]
    // 0xbc8c94: ldur            x1, [fp, #-8]
    // 0xbc8c98: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbc8c98: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbc8c9c: r0 = constrainHeight()
    //     0xbc8c9c: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xbc8ca0: stur            d0, [fp, #-0x10]
    // 0xbc8ca4: r0 = Size()
    //     0xbc8ca4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc8ca8: ldur            d0, [fp, #-0x18]
    // 0xbc8cac: StoreField: r0->field_7 = d0
    //     0xbc8cac: stur            d0, [x0, #7]
    // 0xbc8cb0: ldur            d0, [fp, #-0x10]
    // 0xbc8cb4: StoreField: r0->field_f = d0
    //     0xbc8cb4: stur            d0, [x0, #0xf]
    // 0xbc8cb8: LeaveFrame
    //     0xbc8cb8: mov             SP, fp
    //     0xbc8cbc: ldp             fp, lr, [SP], #0x10
    // 0xbc8cc0: ret
    //     0xbc8cc0: ret             
    // 0xbc8cc4: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc8cc4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc8cc8: b               #0xbc8c1c
    // 0xbc8ccc: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8cd0: SaveReg r0
    //     0xbc8cd0: str             x0, [SP, #-8]!
    // 0xbc8cd4: r0 = AllocateDouble()
    //     0xbc8cd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8cd8: mov             x1, x0
    // 0xbc8cdc: RestoreReg r0
    //     0xbc8cdc: ldr             x0, [SP], #8
    // 0xbc8ce0: ldp             q0, q1, [SP], #0x20
    // 0xbc8ce4: b               #0xbc8c44
    // 0xbc8ce8: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8cec: r0 = AllocateDouble()
    //     0xbc8cec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8cf0: ldp             q0, q1, [SP], #0x20
    // 0xbc8cf4: b               #0xbc8c8c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1163c14, size: 0x5b8
    // 0x1163c14: EnterFrame
    //     0x1163c14: stp             fp, lr, [SP, #-0x10]!
    //     0x1163c18: mov             fp, SP
    // 0x1163c1c: AllocStack(0x30)
    //     0x1163c1c: sub             SP, SP, #0x30
    // 0x1163c20: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x1163c20: mov             x4, x1
    //     0x1163c24: mov             x0, x2
    //     0x1163c28: stur            x1, [fp, #-8]
    //     0x1163c2c: stur            x2, [fp, #-0x10]
    //     0x1163c30: stur            d0, [fp, #-0x18]
    // 0x1163c34: CheckStackOverflow
    //     0x1163c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1163c38: cmp             SP, x16
    //     0x1163c3c: b.ls            #0x1163ff8
    // 0x1163c40: cmp             w4, w0
    // 0x1163c44: b.ne            #0x1163c58
    // 0x1163c48: mov             x0, x4
    // 0x1163c4c: LeaveFrame
    //     0x1163c4c: mov             SP, fp
    //     0x1163c50: ldp             fp, lr, [SP], #0x10
    // 0x1163c54: ret
    //     0x1163c54: ret             
    // 0x1163c58: cmp             w4, NULL
    // 0x1163c5c: b.ne            #0x1163c7c
    // 0x1163c60: cmp             w0, NULL
    // 0x1163c64: b.eq            #0x1164000
    // 0x1163c68: mov             x1, x0
    // 0x1163c6c: r0 = *()
    //     0x1163c6c: bl              #0x11641cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::*
    // 0x1163c70: LeaveFrame
    //     0x1163c70: mov             SP, fp
    //     0x1163c74: ldp             fp, lr, [SP], #0x10
    // 0x1163c78: ret
    //     0x1163c78: ret             
    // 0x1163c7c: cmp             w0, NULL
    // 0x1163c80: b.ne            #0x1163ca4
    // 0x1163c84: d1 = 1.000000
    //     0x1163c84: fmov            d1, #1.00000000
    // 0x1163c88: fsub            d2, d1, d0
    // 0x1163c8c: mov             x1, x4
    // 0x1163c90: mov             v0.16b, v2.16b
    // 0x1163c94: r0 = *()
    //     0x1163c94: bl              #0x11641cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::*
    // 0x1163c98: LeaveFrame
    //     0x1163c98: mov             SP, fp
    //     0x1163c9c: ldp             fp, lr, [SP], #0x10
    // 0x1163ca0: ret
    //     0x1163ca0: ret             
    // 0x1163ca4: LoadField: d1 = r4->field_7
    //     0x1163ca4: ldur            d1, [x4, #7]
    // 0x1163ca8: mov             x1, v1.d[0]
    // 0x1163cac: and             x1, x1, #0x7fffffffffffffff
    // 0x1163cb0: r17 = 9218868437227405312
    //     0x1163cb0: mov             x17, #0x7ff0000000000000
    // 0x1163cb4: cmp             x1, x17
    // 0x1163cb8: b.eq            #0x1163d58
    // 0x1163cbc: fcmp            d1, d1
    // 0x1163cc0: b.vs            #0x1163d58
    // 0x1163cc4: LoadField: d2 = r0->field_7
    //     0x1163cc4: ldur            d2, [x0, #7]
    // 0x1163cc8: r3 = inline_Allocate_Double()
    //     0x1163cc8: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x1163ccc: add             x3, x3, #0x10
    //     0x1163cd0: cmp             x1, x3
    //     0x1163cd4: b.ls            #0x1164004
    //     0x1163cd8: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163cdc: sub             x3, x3, #0xf
    //     0x1163ce0: mov             x1, #0xe19c
    //     0x1163ce4: movk            x1, #3, lsl #16
    //     0x1163ce8: stur            x1, [x3, #-1]
    // 0x1163cec: dmb             ishst
    // 0x1163cf0: StoreField: r3->field_7 = d0
    //     0x1163cf0: stur            d0, [x3, #7]
    // 0x1163cf4: r1 = inline_Allocate_Double()
    //     0x1163cf4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1163cf8: add             x1, x1, #0x10
    //     0x1163cfc: cmp             x2, x1
    //     0x1163d00: b.ls            #0x1164028
    //     0x1163d04: str             x1, [THR, #0x60]  ; THR::top
    //     0x1163d08: sub             x1, x1, #0xf
    //     0x1163d0c: mov             x2, #0xe19c
    //     0x1163d10: movk            x2, #3, lsl #16
    //     0x1163d14: stur            x2, [x1, #-1]
    // 0x1163d18: dmb             ishst
    // 0x1163d1c: StoreField: r1->field_7 = d1
    //     0x1163d1c: stur            d1, [x1, #7]
    // 0x1163d20: r2 = inline_Allocate_Double()
    //     0x1163d20: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0x1163d24: add             x2, x2, #0x10
    //     0x1163d28: cmp             x5, x2
    //     0x1163d2c: b.ls            #0x1164054
    //     0x1163d30: str             x2, [THR, #0x60]  ; THR::top
    //     0x1163d34: sub             x2, x2, #0xf
    //     0x1163d38: mov             x5, #0xe19c
    //     0x1163d3c: movk            x5, #3, lsl #16
    //     0x1163d40: stur            x5, [x2, #-1]
    // 0x1163d44: dmb             ishst
    // 0x1163d48: StoreField: r2->field_7 = d2
    //     0x1163d48: stur            d2, [x2, #7]
    // 0x1163d4c: r0 = lerpDouble()
    //     0x1163d4c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1163d50: LoadField: d0 = r0->field_7
    //     0x1163d50: ldur            d0, [x0, #7]
    // 0x1163d54: b               #0x1163d5c
    // 0x1163d58: d0 = inf
    //     0x1163d58: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x1163d5c: ldur            x0, [fp, #-8]
    // 0x1163d60: stur            d0, [fp, #-0x20]
    // 0x1163d64: LoadField: d1 = r0->field_f
    //     0x1163d64: ldur            d1, [x0, #0xf]
    // 0x1163d68: mov             x1, v1.d[0]
    // 0x1163d6c: and             x1, x1, #0x7fffffffffffffff
    // 0x1163d70: r17 = 9218868437227405312
    //     0x1163d70: mov             x17, #0x7ff0000000000000
    // 0x1163d74: cmp             x1, x17
    // 0x1163d78: b.eq            #0x1163e20
    // 0x1163d7c: fcmp            d1, d1
    // 0x1163d80: b.vs            #0x1163e20
    // 0x1163d84: ldur            x4, [fp, #-0x10]
    // 0x1163d88: ldur            d2, [fp, #-0x18]
    // 0x1163d8c: LoadField: d3 = r4->field_f
    //     0x1163d8c: ldur            d3, [x4, #0xf]
    // 0x1163d90: r3 = inline_Allocate_Double()
    //     0x1163d90: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x1163d94: add             x3, x3, #0x10
    //     0x1163d98: cmp             x1, x3
    //     0x1163d9c: b.ls            #0x1164078
    //     0x1163da0: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163da4: sub             x3, x3, #0xf
    //     0x1163da8: mov             x1, #0xe19c
    //     0x1163dac: movk            x1, #3, lsl #16
    //     0x1163db0: stur            x1, [x3, #-1]
    // 0x1163db4: dmb             ishst
    // 0x1163db8: StoreField: r3->field_7 = d2
    //     0x1163db8: stur            d2, [x3, #7]
    // 0x1163dbc: r1 = inline_Allocate_Double()
    //     0x1163dbc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1163dc0: add             x1, x1, #0x10
    //     0x1163dc4: cmp             x2, x1
    //     0x1163dc8: b.ls            #0x116409c
    //     0x1163dcc: str             x1, [THR, #0x60]  ; THR::top
    //     0x1163dd0: sub             x1, x1, #0xf
    //     0x1163dd4: mov             x2, #0xe19c
    //     0x1163dd8: movk            x2, #3, lsl #16
    //     0x1163ddc: stur            x2, [x1, #-1]
    // 0x1163de0: dmb             ishst
    // 0x1163de4: StoreField: r1->field_7 = d1
    //     0x1163de4: stur            d1, [x1, #7]
    // 0x1163de8: r2 = inline_Allocate_Double()
    //     0x1163de8: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0x1163dec: add             x2, x2, #0x10
    //     0x1163df0: cmp             x5, x2
    //     0x1163df4: b.ls            #0x11640c8
    //     0x1163df8: str             x2, [THR, #0x60]  ; THR::top
    //     0x1163dfc: sub             x2, x2, #0xf
    //     0x1163e00: mov             x5, #0xe19c
    //     0x1163e04: movk            x5, #3, lsl #16
    //     0x1163e08: stur            x5, [x2, #-1]
    // 0x1163e0c: dmb             ishst
    // 0x1163e10: StoreField: r2->field_7 = d3
    //     0x1163e10: stur            d3, [x2, #7]
    // 0x1163e14: r0 = lerpDouble()
    //     0x1163e14: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1163e18: LoadField: d0 = r0->field_7
    //     0x1163e18: ldur            d0, [x0, #7]
    // 0x1163e1c: b               #0x1163e24
    // 0x1163e20: d0 = inf
    //     0x1163e20: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x1163e24: ldur            x0, [fp, #-8]
    // 0x1163e28: stur            d0, [fp, #-0x28]
    // 0x1163e2c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x1163e2c: ldur            d1, [x0, #0x17]
    // 0x1163e30: mov             x1, v1.d[0]
    // 0x1163e34: and             x1, x1, #0x7fffffffffffffff
    // 0x1163e38: r17 = 9218868437227405312
    //     0x1163e38: mov             x17, #0x7ff0000000000000
    // 0x1163e3c: cmp             x1, x17
    // 0x1163e40: b.eq            #0x1163ee8
    // 0x1163e44: fcmp            d1, d1
    // 0x1163e48: b.vs            #0x1163ee8
    // 0x1163e4c: ldur            x4, [fp, #-0x10]
    // 0x1163e50: ldur            d2, [fp, #-0x18]
    // 0x1163e54: ArrayLoad: d3 = r4[0]  ; List_8
    //     0x1163e54: ldur            d3, [x4, #0x17]
    // 0x1163e58: r3 = inline_Allocate_Double()
    //     0x1163e58: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x1163e5c: add             x3, x3, #0x10
    //     0x1163e60: cmp             x1, x3
    //     0x1163e64: b.ls            #0x11640f4
    //     0x1163e68: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163e6c: sub             x3, x3, #0xf
    //     0x1163e70: mov             x1, #0xe19c
    //     0x1163e74: movk            x1, #3, lsl #16
    //     0x1163e78: stur            x1, [x3, #-1]
    // 0x1163e7c: dmb             ishst
    // 0x1163e80: StoreField: r3->field_7 = d2
    //     0x1163e80: stur            d2, [x3, #7]
    // 0x1163e84: r1 = inline_Allocate_Double()
    //     0x1163e84: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1163e88: add             x1, x1, #0x10
    //     0x1163e8c: cmp             x2, x1
    //     0x1163e90: b.ls            #0x1164118
    //     0x1163e94: str             x1, [THR, #0x60]  ; THR::top
    //     0x1163e98: sub             x1, x1, #0xf
    //     0x1163e9c: mov             x2, #0xe19c
    //     0x1163ea0: movk            x2, #3, lsl #16
    //     0x1163ea4: stur            x2, [x1, #-1]
    // 0x1163ea8: dmb             ishst
    // 0x1163eac: StoreField: r1->field_7 = d1
    //     0x1163eac: stur            d1, [x1, #7]
    // 0x1163eb0: r2 = inline_Allocate_Double()
    //     0x1163eb0: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0x1163eb4: add             x2, x2, #0x10
    //     0x1163eb8: cmp             x5, x2
    //     0x1163ebc: b.ls            #0x1164144
    //     0x1163ec0: str             x2, [THR, #0x60]  ; THR::top
    //     0x1163ec4: sub             x2, x2, #0xf
    //     0x1163ec8: mov             x5, #0xe19c
    //     0x1163ecc: movk            x5, #3, lsl #16
    //     0x1163ed0: stur            x5, [x2, #-1]
    // 0x1163ed4: dmb             ishst
    // 0x1163ed8: StoreField: r2->field_7 = d3
    //     0x1163ed8: stur            d3, [x2, #7]
    // 0x1163edc: r0 = lerpDouble()
    //     0x1163edc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1163ee0: LoadField: d0 = r0->field_7
    //     0x1163ee0: ldur            d0, [x0, #7]
    // 0x1163ee4: b               #0x1163eec
    // 0x1163ee8: d0 = inf
    //     0x1163ee8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x1163eec: ldur            x0, [fp, #-8]
    // 0x1163ef0: stur            d0, [fp, #-0x30]
    // 0x1163ef4: LoadField: d1 = r0->field_1f
    //     0x1163ef4: ldur            d1, [x0, #0x1f]
    // 0x1163ef8: mov             x0, v1.d[0]
    // 0x1163efc: and             x0, x0, #0x7fffffffffffffff
    // 0x1163f00: r17 = 9218868437227405312
    //     0x1163f00: mov             x17, #0x7ff0000000000000
    // 0x1163f04: cmp             x0, x17
    // 0x1163f08: b.eq            #0x1163fb4
    // 0x1163f0c: fcmp            d1, d1
    // 0x1163f10: b.vs            #0x1163fb4
    // 0x1163f14: ldur            x0, [fp, #-0x10]
    // 0x1163f18: ldur            d2, [fp, #-0x18]
    // 0x1163f1c: LoadField: d3 = r0->field_1f
    //     0x1163f1c: ldur            d3, [x0, #0x1f]
    // 0x1163f20: r3 = inline_Allocate_Double()
    //     0x1163f20: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x1163f24: add             x3, x3, #0x10
    //     0x1163f28: cmp             x0, x3
    //     0x1163f2c: b.ls            #0x1164170
    //     0x1163f30: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163f34: sub             x3, x3, #0xf
    //     0x1163f38: mov             x0, #0xe19c
    //     0x1163f3c: movk            x0, #3, lsl #16
    //     0x1163f40: stur            x0, [x3, #-1]
    // 0x1163f44: dmb             ishst
    // 0x1163f48: StoreField: r3->field_7 = d2
    //     0x1163f48: stur            d2, [x3, #7]
    // 0x1163f4c: r1 = inline_Allocate_Double()
    //     0x1163f4c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x1163f50: add             x1, x1, #0x10
    //     0x1163f54: cmp             x0, x1
    //     0x1163f58: b.ls            #0x116418c
    //     0x1163f5c: str             x1, [THR, #0x60]  ; THR::top
    //     0x1163f60: sub             x1, x1, #0xf
    //     0x1163f64: mov             x0, #0xe19c
    //     0x1163f68: movk            x0, #3, lsl #16
    //     0x1163f6c: stur            x0, [x1, #-1]
    // 0x1163f70: dmb             ishst
    // 0x1163f74: StoreField: r1->field_7 = d1
    //     0x1163f74: stur            d1, [x1, #7]
    // 0x1163f78: r2 = inline_Allocate_Double()
    //     0x1163f78: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1163f7c: add             x2, x2, #0x10
    //     0x1163f80: cmp             x0, x2
    //     0x1163f84: b.ls            #0x11641b0
    //     0x1163f88: str             x2, [THR, #0x60]  ; THR::top
    //     0x1163f8c: sub             x2, x2, #0xf
    //     0x1163f90: mov             x0, #0xe19c
    //     0x1163f94: movk            x0, #3, lsl #16
    //     0x1163f98: stur            x0, [x2, #-1]
    // 0x1163f9c: dmb             ishst
    // 0x1163fa0: StoreField: r2->field_7 = d3
    //     0x1163fa0: stur            d3, [x2, #7]
    // 0x1163fa4: r0 = lerpDouble()
    //     0x1163fa4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1163fa8: LoadField: d0 = r0->field_7
    //     0x1163fa8: ldur            d0, [x0, #7]
    // 0x1163fac: mov             v3.16b, v0.16b
    // 0x1163fb0: b               #0x1163fb8
    // 0x1163fb4: d3 = inf
    //     0x1163fb4: ldr             d3, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x1163fb8: ldur            d2, [fp, #-0x20]
    // 0x1163fbc: ldur            d1, [fp, #-0x28]
    // 0x1163fc0: ldur            d0, [fp, #-0x30]
    // 0x1163fc4: stur            d3, [fp, #-0x18]
    // 0x1163fc8: r0 = BoxConstraints()
    //     0x1163fc8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x1163fcc: ldur            d0, [fp, #-0x20]
    // 0x1163fd0: StoreField: r0->field_7 = d0
    //     0x1163fd0: stur            d0, [x0, #7]
    // 0x1163fd4: ldur            d0, [fp, #-0x28]
    // 0x1163fd8: StoreField: r0->field_f = d0
    //     0x1163fd8: stur            d0, [x0, #0xf]
    // 0x1163fdc: ldur            d0, [fp, #-0x30]
    // 0x1163fe0: ArrayStore: r0[0] = d0  ; List_8
    //     0x1163fe0: stur            d0, [x0, #0x17]
    // 0x1163fe4: ldur            d0, [fp, #-0x18]
    // 0x1163fe8: StoreField: r0->field_1f = d0
    //     0x1163fe8: stur            d0, [x0, #0x1f]
    // 0x1163fec: LeaveFrame
    //     0x1163fec: mov             SP, fp
    //     0x1163ff0: ldp             fp, lr, [SP], #0x10
    // 0x1163ff4: ret
    //     0x1163ff4: ret             
    // 0x1163ff8: r0 = StackOverflowSharedWithFPURegs()
    //     0x1163ff8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1163ffc: b               #0x1163c40
    // 0x1164000: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1164000: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1164004: stp             q1, q2, [SP, #-0x20]!
    // 0x1164008: SaveReg d0
    //     0x1164008: str             q0, [SP, #-0x10]!
    // 0x116400c: stp             x0, x4, [SP, #-0x10]!
    // 0x1164010: r0 = AllocateDouble()
    //     0x1164010: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164014: mov             x3, x0
    // 0x1164018: ldp             x0, x4, [SP], #0x10
    // 0x116401c: RestoreReg d0
    //     0x116401c: ldr             q0, [SP], #0x10
    // 0x1164020: ldp             q1, q2, [SP], #0x20
    // 0x1164024: b               #0x1163cf0
    // 0x1164028: stp             q1, q2, [SP, #-0x20]!
    // 0x116402c: SaveReg d0
    //     0x116402c: str             q0, [SP, #-0x10]!
    // 0x1164030: stp             x3, x4, [SP, #-0x10]!
    // 0x1164034: SaveReg r0
    //     0x1164034: str             x0, [SP, #-8]!
    // 0x1164038: r0 = AllocateDouble()
    //     0x1164038: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116403c: mov             x1, x0
    // 0x1164040: RestoreReg r0
    //     0x1164040: ldr             x0, [SP], #8
    // 0x1164044: ldp             x3, x4, [SP], #0x10
    // 0x1164048: RestoreReg d0
    //     0x1164048: ldr             q0, [SP], #0x10
    // 0x116404c: ldp             q1, q2, [SP], #0x20
    // 0x1164050: b               #0x1163d1c
    // 0x1164054: stp             q0, q2, [SP, #-0x20]!
    // 0x1164058: stp             x3, x4, [SP, #-0x10]!
    // 0x116405c: stp             x0, x1, [SP, #-0x10]!
    // 0x1164060: r0 = AllocateDouble()
    //     0x1164060: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164064: mov             x2, x0
    // 0x1164068: ldp             x0, x1, [SP], #0x10
    // 0x116406c: ldp             x3, x4, [SP], #0x10
    // 0x1164070: ldp             q0, q2, [SP], #0x20
    // 0x1164074: b               #0x1163d48
    // 0x1164078: stp             q2, q3, [SP, #-0x20]!
    // 0x116407c: stp             q0, q1, [SP, #-0x20]!
    // 0x1164080: stp             x0, x4, [SP, #-0x10]!
    // 0x1164084: r0 = AllocateDouble()
    //     0x1164084: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164088: mov             x3, x0
    // 0x116408c: ldp             x0, x4, [SP], #0x10
    // 0x1164090: ldp             q0, q1, [SP], #0x20
    // 0x1164094: ldp             q2, q3, [SP], #0x20
    // 0x1164098: b               #0x1163db8
    // 0x116409c: stp             q2, q3, [SP, #-0x20]!
    // 0x11640a0: stp             q0, q1, [SP, #-0x20]!
    // 0x11640a4: stp             x3, x4, [SP, #-0x10]!
    // 0x11640a8: SaveReg r0
    //     0x11640a8: str             x0, [SP, #-8]!
    // 0x11640ac: r0 = AllocateDouble()
    //     0x11640ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11640b0: mov             x1, x0
    // 0x11640b4: RestoreReg r0
    //     0x11640b4: ldr             x0, [SP], #8
    // 0x11640b8: ldp             x3, x4, [SP], #0x10
    // 0x11640bc: ldp             q0, q1, [SP], #0x20
    // 0x11640c0: ldp             q2, q3, [SP], #0x20
    // 0x11640c4: b               #0x1163de4
    // 0x11640c8: stp             q2, q3, [SP, #-0x20]!
    // 0x11640cc: SaveReg d0
    //     0x11640cc: str             q0, [SP, #-0x10]!
    // 0x11640d0: stp             x3, x4, [SP, #-0x10]!
    // 0x11640d4: stp             x0, x1, [SP, #-0x10]!
    // 0x11640d8: r0 = AllocateDouble()
    //     0x11640d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11640dc: mov             x2, x0
    // 0x11640e0: ldp             x0, x1, [SP], #0x10
    // 0x11640e4: ldp             x3, x4, [SP], #0x10
    // 0x11640e8: RestoreReg d0
    //     0x11640e8: ldr             q0, [SP], #0x10
    // 0x11640ec: ldp             q2, q3, [SP], #0x20
    // 0x11640f0: b               #0x1163e10
    // 0x11640f4: stp             q2, q3, [SP, #-0x20]!
    // 0x11640f8: stp             q0, q1, [SP, #-0x20]!
    // 0x11640fc: stp             x0, x4, [SP, #-0x10]!
    // 0x1164100: r0 = AllocateDouble()
    //     0x1164100: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164104: mov             x3, x0
    // 0x1164108: ldp             x0, x4, [SP], #0x10
    // 0x116410c: ldp             q0, q1, [SP], #0x20
    // 0x1164110: ldp             q2, q3, [SP], #0x20
    // 0x1164114: b               #0x1163e80
    // 0x1164118: stp             q2, q3, [SP, #-0x20]!
    // 0x116411c: stp             q0, q1, [SP, #-0x20]!
    // 0x1164120: stp             x3, x4, [SP, #-0x10]!
    // 0x1164124: SaveReg r0
    //     0x1164124: str             x0, [SP, #-8]!
    // 0x1164128: r0 = AllocateDouble()
    //     0x1164128: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116412c: mov             x1, x0
    // 0x1164130: RestoreReg r0
    //     0x1164130: ldr             x0, [SP], #8
    // 0x1164134: ldp             x3, x4, [SP], #0x10
    // 0x1164138: ldp             q0, q1, [SP], #0x20
    // 0x116413c: ldp             q2, q3, [SP], #0x20
    // 0x1164140: b               #0x1163eac
    // 0x1164144: stp             q2, q3, [SP, #-0x20]!
    // 0x1164148: SaveReg d0
    //     0x1164148: str             q0, [SP, #-0x10]!
    // 0x116414c: stp             x3, x4, [SP, #-0x10]!
    // 0x1164150: stp             x0, x1, [SP, #-0x10]!
    // 0x1164154: r0 = AllocateDouble()
    //     0x1164154: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164158: mov             x2, x0
    // 0x116415c: ldp             x0, x1, [SP], #0x10
    // 0x1164160: ldp             x3, x4, [SP], #0x10
    // 0x1164164: RestoreReg d0
    //     0x1164164: ldr             q0, [SP], #0x10
    // 0x1164168: ldp             q2, q3, [SP], #0x20
    // 0x116416c: b               #0x1163ed8
    // 0x1164170: stp             q2, q3, [SP, #-0x20]!
    // 0x1164174: stp             q0, q1, [SP, #-0x20]!
    // 0x1164178: r0 = AllocateDouble()
    //     0x1164178: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116417c: mov             x3, x0
    // 0x1164180: ldp             q0, q1, [SP], #0x20
    // 0x1164184: ldp             q2, q3, [SP], #0x20
    // 0x1164188: b               #0x1163f48
    // 0x116418c: stp             q1, q3, [SP, #-0x20]!
    // 0x1164190: SaveReg d0
    //     0x1164190: str             q0, [SP, #-0x10]!
    // 0x1164194: SaveReg r3
    //     0x1164194: str             x3, [SP, #-8]!
    // 0x1164198: r0 = AllocateDouble()
    //     0x1164198: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116419c: mov             x1, x0
    // 0x11641a0: RestoreReg r3
    //     0x11641a0: ldr             x3, [SP], #8
    // 0x11641a4: RestoreReg d0
    //     0x11641a4: ldr             q0, [SP], #0x10
    // 0x11641a8: ldp             q1, q3, [SP], #0x20
    // 0x11641ac: b               #0x1163f74
    // 0x11641b0: stp             q0, q3, [SP, #-0x20]!
    // 0x11641b4: stp             x1, x3, [SP, #-0x10]!
    // 0x11641b8: r0 = AllocateDouble()
    //     0x11641b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11641bc: mov             x2, x0
    // 0x11641c0: ldp             x1, x3, [SP], #0x10
    // 0x11641c4: ldp             q0, q3, [SP], #0x20
    // 0x11641c8: b               #0x1163fa0
  }
  _ *(/* No info */) {
    // ** addr: 0x11641cc, size: 0x6c
    // 0x11641cc: EnterFrame
    //     0x11641cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11641d0: mov             fp, SP
    // 0x11641d4: AllocStack(0x20)
    //     0x11641d4: sub             SP, SP, #0x20
    // 0x11641d8: LoadField: d1 = r1->field_7
    //     0x11641d8: ldur            d1, [x1, #7]
    // 0x11641dc: fmul            d2, d1, d0
    // 0x11641e0: stur            d2, [fp, #-0x20]
    // 0x11641e4: LoadField: d1 = r1->field_f
    //     0x11641e4: ldur            d1, [x1, #0xf]
    // 0x11641e8: fmul            d3, d1, d0
    // 0x11641ec: stur            d3, [fp, #-0x18]
    // 0x11641f0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x11641f0: ldur            d1, [x1, #0x17]
    // 0x11641f4: fmul            d4, d1, d0
    // 0x11641f8: stur            d4, [fp, #-0x10]
    // 0x11641fc: LoadField: d1 = r1->field_1f
    //     0x11641fc: ldur            d1, [x1, #0x1f]
    // 0x1164200: fmul            d5, d1, d0
    // 0x1164204: stur            d5, [fp, #-8]
    // 0x1164208: r0 = BoxConstraints()
    //     0x1164208: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x116420c: ldur            d0, [fp, #-0x20]
    // 0x1164210: StoreField: r0->field_7 = d0
    //     0x1164210: stur            d0, [x0, #7]
    // 0x1164214: ldur            d0, [fp, #-0x18]
    // 0x1164218: StoreField: r0->field_f = d0
    //     0x1164218: stur            d0, [x0, #0xf]
    // 0x116421c: ldur            d0, [fp, #-0x10]
    // 0x1164220: ArrayStore: r0[0] = d0  ; List_8
    //     0x1164220: stur            d0, [x0, #0x17]
    // 0x1164224: ldur            d0, [fp, #-8]
    // 0x1164228: StoreField: r0->field_1f = d0
    //     0x1164228: stur            d0, [x0, #0x1f]
    // 0x116422c: LeaveFrame
    //     0x116422c: mov             SP, fp
    //     0x1164230: ldp             fp, lr, [SP], #0x10
    // 0x1164234: ret
    //     0x1164234: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299aec, size: 0xf8
    // 0x1299aec: EnterFrame
    //     0x1299aec: stp             fp, lr, [SP, #-0x10]!
    //     0x1299af0: mov             fp, SP
    // 0x1299af4: AllocStack(0x10)
    //     0x1299af4: sub             SP, SP, #0x10
    // 0x1299af8: CheckStackOverflow
    //     0x1299af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299afc: cmp             SP, x16
    //     0x1299b00: b.ls            #0x1299bdc
    // 0x1299b04: ldr             x0, [fp, #0x10]
    // 0x1299b08: cmp             w0, NULL
    // 0x1299b0c: b.ne            #0x1299b20
    // 0x1299b10: r0 = false
    //     0x1299b10: add             x0, NULL, #0x30  ; false
    // 0x1299b14: LeaveFrame
    //     0x1299b14: mov             SP, fp
    //     0x1299b18: ldp             fp, lr, [SP], #0x10
    // 0x1299b1c: ret
    //     0x1299b1c: ret             
    // 0x1299b20: ldr             x1, [fp, #0x18]
    // 0x1299b24: cmp             w1, w0
    // 0x1299b28: b.ne            #0x1299b3c
    // 0x1299b2c: r0 = true
    //     0x1299b2c: add             x0, NULL, #0x20  ; true
    // 0x1299b30: LeaveFrame
    //     0x1299b30: mov             SP, fp
    //     0x1299b34: ldp             fp, lr, [SP], #0x10
    // 0x1299b38: ret
    //     0x1299b38: ret             
    // 0x1299b3c: stp             x1, x0, [SP]
    // 0x1299b40: r0 = _haveSameRuntimeType()
    //     0x1299b40: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1299b44: tbz             w0, #4, #0x1299b58
    // 0x1299b48: r0 = false
    //     0x1299b48: add             x0, NULL, #0x30  ; false
    // 0x1299b4c: LeaveFrame
    //     0x1299b4c: mov             SP, fp
    //     0x1299b50: ldp             fp, lr, [SP], #0x10
    // 0x1299b54: ret
    //     0x1299b54: ret             
    // 0x1299b58: ldr             x1, [fp, #0x10]
    // 0x1299b5c: r2 = 60
    //     0x1299b5c: mov             x2, #0x3c
    // 0x1299b60: branchIfSmi(r1, 0x1299b6c)
    //     0x1299b60: tbz             w1, #0, #0x1299b6c
    // 0x1299b64: r2 = LoadClassIdInstr(r1)
    //     0x1299b64: ldur            x2, [x1, #-1]
    //     0x1299b68: ubfx            x2, x2, #0xc, #0x14
    // 0x1299b6c: sub             x16, x2, #0xb46
    // 0x1299b70: cmp             x16, #1
    // 0x1299b74: b.hi            #0x1299bcc
    // 0x1299b78: ldr             x2, [fp, #0x18]
    // 0x1299b7c: LoadField: d0 = r1->field_7
    //     0x1299b7c: ldur            d0, [x1, #7]
    // 0x1299b80: LoadField: d1 = r2->field_7
    //     0x1299b80: ldur            d1, [x2, #7]
    // 0x1299b84: fcmp            d0, d1
    // 0x1299b88: b.ne            #0x1299bcc
    // 0x1299b8c: LoadField: d0 = r1->field_f
    //     0x1299b8c: ldur            d0, [x1, #0xf]
    // 0x1299b90: LoadField: d1 = r2->field_f
    //     0x1299b90: ldur            d1, [x2, #0xf]
    // 0x1299b94: fcmp            d0, d1
    // 0x1299b98: b.ne            #0x1299bcc
    // 0x1299b9c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1299b9c: ldur            d0, [x1, #0x17]
    // 0x1299ba0: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x1299ba0: ldur            d1, [x2, #0x17]
    // 0x1299ba4: fcmp            d0, d1
    // 0x1299ba8: b.ne            #0x1299bcc
    // 0x1299bac: LoadField: d0 = r1->field_1f
    //     0x1299bac: ldur            d0, [x1, #0x1f]
    // 0x1299bb0: LoadField: d1 = r2->field_1f
    //     0x1299bb0: ldur            d1, [x2, #0x1f]
    // 0x1299bb4: fcmp            d0, d1
    // 0x1299bb8: r16 = true
    //     0x1299bb8: add             x16, NULL, #0x20  ; true
    // 0x1299bbc: r17 = false
    //     0x1299bbc: add             x17, NULL, #0x30  ; false
    // 0x1299bc0: csel            x1, x16, x17, eq
    // 0x1299bc4: mov             x0, x1
    // 0x1299bc8: b               #0x1299bd0
    // 0x1299bcc: r0 = false
    //     0x1299bcc: add             x0, NULL, #0x30  ; false
    // 0x1299bd0: LeaveFrame
    //     0x1299bd0: mov             SP, fp
    //     0x1299bd4: ldp             fp, lr, [SP], #0x10
    // 0x1299bd8: ret
    //     0x1299bd8: ret             
    // 0x1299bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299be0: b               #0x1299b04
  }
  get _ isTight(/* No info */) {
    // ** addr: 0x13081bc, size: 0x38
    // 0x13081bc: LoadField: d0 = r1->field_7
    //     0x13081bc: ldur            d0, [x1, #7]
    // 0x13081c0: LoadField: d1 = r1->field_f
    //     0x13081c0: ldur            d1, [x1, #0xf]
    // 0x13081c4: fcmp            d0, d1
    // 0x13081c8: b.lt            #0x13081ec
    // 0x13081cc: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x13081cc: ldur            d0, [x1, #0x17]
    // 0x13081d0: LoadField: d1 = r1->field_1f
    //     0x13081d0: ldur            d1, [x1, #0x1f]
    // 0x13081d4: fcmp            d0, d1
    // 0x13081d8: r16 = true
    //     0x13081d8: add             x16, NULL, #0x20  ; true
    // 0x13081dc: r17 = false
    //     0x13081dc: add             x17, NULL, #0x30  ; false
    // 0x13081e0: csel            x1, x16, x17, ge
    // 0x13081e4: mov             x0, x1
    // 0x13081e8: b               #0x13081f0
    // 0x13081ec: r0 = false
    //     0x13081ec: add             x0, NULL, #0x30  ; false
    // 0x13081f0: ret
    //     0x13081f0: ret             
  }
}

// class id: 3167, size: 0x14, field offset: 0x14
class BoxHitTestResult extends HitTestResult {

  _ addWithRawTransform(/* No info */) {
    // ** addr: 0xaf9790, size: 0xc0
    // 0xaf9790: EnterFrame
    //     0xaf9790: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9794: mov             fp, SP
    // 0xaf9798: AllocStack(0x38)
    //     0xaf9798: sub             SP, SP, #0x38
    // 0xaf979c: SetupParameters(BoxHitTestResult this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0xaf979c: mov             x0, x5
    //     0xaf97a0: stur            x5, [fp, #-0x18]
    //     0xaf97a4: mov             x5, x1
    //     0xaf97a8: mov             x4, x2
    //     0xaf97ac: stur            x1, [fp, #-8]
    //     0xaf97b0: stur            x2, [fp, #-0x10]
    // 0xaf97b4: CheckStackOverflow
    //     0xaf97b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf97b8: cmp             SP, x16
    //     0xaf97bc: b.ls            #0xaf9848
    // 0xaf97c0: cmp             w0, NULL
    // 0xaf97c4: b.eq            #0xaf97dc
    // 0xaf97c8: mov             x1, x0
    // 0xaf97cc: mov             x2, x3
    // 0xaf97d0: r0 = transformPoint()
    //     0xaf97d0: bl              #0x856f28  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0xaf97d4: mov             x3, x0
    // 0xaf97d8: ldur            x0, [fp, #-0x18]
    // 0xaf97dc: stur            x3, [fp, #-0x20]
    // 0xaf97e0: cmp             w0, NULL
    // 0xaf97e4: b.eq            #0xaf97f4
    // 0xaf97e8: ldur            x1, [fp, #-8]
    // 0xaf97ec: mov             x2, x0
    // 0xaf97f0: r0 = pushTransform()
    //     0xaf97f0: bl              #0xaf98ec  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushTransform
    // 0xaf97f4: ldur            x1, [fp, #-0x18]
    // 0xaf97f8: ldur            x16, [fp, #-0x10]
    // 0xaf97fc: ldur            lr, [fp, #-8]
    // 0xaf9800: stp             lr, x16, [SP, #8]
    // 0xaf9804: ldur            x16, [fp, #-0x20]
    // 0xaf9808: str             x16, [SP]
    // 0xaf980c: ldur            x0, [fp, #-0x10]
    // 0xaf9810: ClosureCall
    //     0xaf9810: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xaf9814: ldur            x2, [x0, #0x1f]
    //     0xaf9818: blr             x2
    // 0xaf981c: mov             x2, x0
    // 0xaf9820: ldur            x0, [fp, #-0x18]
    // 0xaf9824: stur            x2, [fp, #-0x10]
    // 0xaf9828: cmp             w0, NULL
    // 0xaf982c: b.eq            #0xaf9838
    // 0xaf9830: ldur            x1, [fp, #-8]
    // 0xaf9834: r0 = popTransform()
    //     0xaf9834: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0xaf9838: ldur            x0, [fp, #-0x10]
    // 0xaf983c: LeaveFrame
    //     0xaf983c: mov             SP, fp
    //     0xaf9840: ldp             fp, lr, [SP], #0x10
    // 0xaf9844: ret
    //     0xaf9844: ret             
    // 0xaf9848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf984c: b               #0xaf97c0
  }
  _ addWithPaintOffset(/* No info */) {
    // ** addr: 0xaf9d3c, size: 0xd0
    // 0xaf9d3c: EnterFrame
    //     0xaf9d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9d40: mov             fp, SP
    // 0xaf9d44: AllocStack(0x38)
    //     0xaf9d44: sub             SP, SP, #0x38
    // 0xaf9d48: SetupParameters(BoxHitTestResult this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xaf9d48: mov             x4, x1
    //     0xaf9d4c: mov             x0, x3
    //     0xaf9d50: stur            x3, [fp, #-0x18]
    //     0xaf9d54: mov             x3, x2
    //     0xaf9d58: stur            x1, [fp, #-8]
    //     0xaf9d5c: stur            x2, [fp, #-0x10]
    // 0xaf9d60: CheckStackOverflow
    //     0xaf9d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9d64: cmp             SP, x16
    //     0xaf9d68: b.ls            #0xaf9e04
    // 0xaf9d6c: cmp             w0, NULL
    // 0xaf9d70: b.ne            #0xaf9d7c
    // 0xaf9d74: mov             x2, x5
    // 0xaf9d78: b               #0xaf9d90
    // 0xaf9d7c: mov             x1, x5
    // 0xaf9d80: mov             x2, x0
    // 0xaf9d84: r0 = -()
    //     0xaf9d84: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xaf9d88: mov             x2, x0
    // 0xaf9d8c: ldur            x0, [fp, #-0x18]
    // 0xaf9d90: stur            x2, [fp, #-0x20]
    // 0xaf9d94: cmp             w0, NULL
    // 0xaf9d98: b.eq            #0xaf9db0
    // 0xaf9d9c: mov             x1, x0
    // 0xaf9da0: r0 = unary-()
    //     0xaf9da0: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0xaf9da4: ldur            x1, [fp, #-8]
    // 0xaf9da8: mov             x2, x0
    // 0xaf9dac: r0 = pushOffset()
    //     0xaf9dac: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0xaf9db0: ldur            x1, [fp, #-0x18]
    // 0xaf9db4: ldur            x16, [fp, #-0x10]
    // 0xaf9db8: ldur            lr, [fp, #-8]
    // 0xaf9dbc: stp             lr, x16, [SP, #8]
    // 0xaf9dc0: ldur            x16, [fp, #-0x20]
    // 0xaf9dc4: str             x16, [SP]
    // 0xaf9dc8: ldur            x0, [fp, #-0x10]
    // 0xaf9dcc: ClosureCall
    //     0xaf9dcc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xaf9dd0: ldur            x2, [x0, #0x1f]
    //     0xaf9dd4: blr             x2
    // 0xaf9dd8: mov             x2, x0
    // 0xaf9ddc: ldur            x0, [fp, #-0x18]
    // 0xaf9de0: stur            x2, [fp, #-0x10]
    // 0xaf9de4: cmp             w0, NULL
    // 0xaf9de8: b.eq            #0xaf9df4
    // 0xaf9dec: ldur            x1, [fp, #-8]
    // 0xaf9df0: r0 = popTransform()
    //     0xaf9df0: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0xaf9df4: ldur            x0, [fp, #-0x10]
    // 0xaf9df8: LeaveFrame
    //     0xaf9df8: mov             SP, fp
    //     0xaf9dfc: ldp             fp, lr, [SP], #0x10
    // 0xaf9e00: ret
    //     0xaf9e00: ret             
    // 0xaf9e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9e08: b               #0xaf9d6c
  }
  _ addWithPaintTransform(/* No info */) {
    // ** addr: 0x10e8cac, size: 0x88
    // 0x10e8cac: EnterFrame
    //     0x10e8cac: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8cb0: mov             fp, SP
    // 0x10e8cb4: AllocStack(0x18)
    //     0x10e8cb4: sub             SP, SP, #0x18
    // 0x10e8cb8: SetupParameters(BoxHitTestResult this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r1 */)
    //     0x10e8cb8: mov             x0, x1
    //     0x10e8cbc: stur            x1, [fp, #-8]
    //     0x10e8cc0: mov             x1, x5
    //     0x10e8cc4: stur            x2, [fp, #-0x10]
    //     0x10e8cc8: stur            x3, [fp, #-0x18]
    // 0x10e8ccc: CheckStackOverflow
    //     0x10e8ccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8cd0: cmp             SP, x16
    //     0x10e8cd4: b.ls            #0x10e8d2c
    // 0x10e8cd8: cmp             w1, NULL
    // 0x10e8cdc: b.eq            #0x10e8d0c
    // 0x10e8ce0: r0 = removePerspectiveTransform()
    //     0x10e8ce0: bl              #0x10e8d34  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x10e8ce4: mov             x1, x0
    // 0x10e8ce8: r0 = tryInvert()
    //     0x10e8ce8: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x10e8cec: cmp             w0, NULL
    // 0x10e8cf0: b.ne            #0x10e8d04
    // 0x10e8cf4: r0 = false
    //     0x10e8cf4: add             x0, NULL, #0x30  ; false
    // 0x10e8cf8: LeaveFrame
    //     0x10e8cf8: mov             SP, fp
    //     0x10e8cfc: ldp             fp, lr, [SP], #0x10
    // 0x10e8d00: ret
    //     0x10e8d00: ret             
    // 0x10e8d04: mov             x5, x0
    // 0x10e8d08: b               #0x10e8d10
    // 0x10e8d0c: mov             x5, x1
    // 0x10e8d10: ldur            x1, [fp, #-8]
    // 0x10e8d14: ldur            x2, [fp, #-0x10]
    // 0x10e8d18: ldur            x3, [fp, #-0x18]
    // 0x10e8d1c: r0 = addWithRawTransform()
    //     0x10e8d1c: bl              #0xaf9790  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0x10e8d20: LeaveFrame
    //     0x10e8d20: mov             SP, fp
    //     0x10e8d24: ldp             fp, lr, [SP], #0x10
    // 0x10e8d28: ret
    //     0x10e8d28: ret             
    // 0x10e8d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8d2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8d30: b               #0x10e8cd8
  }
  _ addWithOutOfBandPosition(/* No info */) {
    // ** addr: 0x10eb590, size: 0x13c
    // 0x10eb590: EnterFrame
    //     0x10eb590: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb594: mov             fp, SP
    // 0x10eb598: AllocStack(0x20)
    //     0x10eb598: sub             SP, SP, #0x20
    // 0x10eb59c: SetupParameters(BoxHitTestResult this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, {dynamic paintOffset = Null /* r5 */, dynamic paintTransform = Null /* r1 */})
    //     0x10eb59c: mov             x0, x2
    //     0x10eb5a0: stur            x2, [fp, #-0x10]
    //     0x10eb5a4: mov             x2, x1
    //     0x10eb5a8: stur            x1, [fp, #-8]
    //     0x10eb5ac: ldur            w1, [x4, #0x13]
    //     0x10eb5b0: ldur            w3, [x4, #0x1f]
    //     0x10eb5b4: add             x3, x3, HEAP, lsl #32
    //     0x10eb5b8: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4120] "paintOffset"
    //     0x10eb5bc: ldr             x16, [x16, #0x120]
    //     0x10eb5c0: cmp             w3, w16
    //     0x10eb5c4: b.ne            #0x10eb5e8
    //     0x10eb5c8: ldur            w3, [x4, #0x23]
    //     0x10eb5cc: add             x3, x3, HEAP, lsl #32
    //     0x10eb5d0: sub             w5, w1, w3
    //     0x10eb5d4: add             x3, fp, w5, sxtw #2
    //     0x10eb5d8: ldr             x3, [x3, #8]
    //     0x10eb5dc: mov             x5, x3
    //     0x10eb5e0: mov             x3, #1
    //     0x10eb5e4: b               #0x10eb5f0
    //     0x10eb5e8: mov             x5, NULL
    //     0x10eb5ec: mov             x3, #0
    //     0x10eb5f0: lsl             x6, x3, #1
    //     0x10eb5f4: lsl             w3, w6, #1
    //     0x10eb5f8: add             w6, w3, #8
    //     0x10eb5fc: add             x16, x4, w6, sxtw #1
    //     0x10eb600: ldur            w7, [x16, #0xf]
    //     0x10eb604: add             x7, x7, HEAP, lsl #32
    //     0x10eb608: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4128] "paintTransform"
    //     0x10eb60c: ldr             x16, [x16, #0x128]
    //     0x10eb610: cmp             w7, w16
    //     0x10eb614: b.ne            #0x10eb638
    //     0x10eb618: add             w6, w3, #0xa
    //     0x10eb61c: add             x16, x4, w6, sxtw #1
    //     0x10eb620: ldur            w3, [x16, #0xf]
    //     0x10eb624: add             x3, x3, HEAP, lsl #32
    //     0x10eb628: sub             w4, w1, w3
    //     0x10eb62c: add             x1, fp, w4, sxtw #2
    //     0x10eb630: ldr             x1, [x1, #8]
    //     0x10eb634: b               #0x10eb63c
    //     0x10eb638: mov             x1, NULL
    // 0x10eb63c: CheckStackOverflow
    //     0x10eb63c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb640: cmp             SP, x16
    //     0x10eb644: b.ls            #0x10eb6c0
    // 0x10eb648: cmp             w5, NULL
    // 0x10eb64c: b.eq            #0x10eb668
    // 0x10eb650: mov             x1, x5
    // 0x10eb654: r0 = unary-()
    //     0x10eb654: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x10eb658: ldur            x1, [fp, #-8]
    // 0x10eb65c: mov             x2, x0
    // 0x10eb660: r0 = pushOffset()
    //     0x10eb660: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x10eb664: b               #0x10eb688
    // 0x10eb668: r0 = removePerspectiveTransform()
    //     0x10eb668: bl              #0x10e8d34  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x10eb66c: mov             x1, x0
    // 0x10eb670: r0 = tryInvert()
    //     0x10eb670: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x10eb674: cmp             w0, NULL
    // 0x10eb678: b.eq            #0x10eb6c8
    // 0x10eb67c: ldur            x1, [fp, #-8]
    // 0x10eb680: mov             x2, x0
    // 0x10eb684: r0 = pushTransform()
    //     0x10eb684: bl              #0xaf98ec  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushTransform
    // 0x10eb688: ldur            x16, [fp, #-0x10]
    // 0x10eb68c: ldur            lr, [fp, #-8]
    // 0x10eb690: stp             lr, x16, [SP]
    // 0x10eb694: ldur            x0, [fp, #-0x10]
    // 0x10eb698: ClosureCall
    //     0x10eb698: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x10eb69c: ldur            x2, [x0, #0x1f]
    //     0x10eb6a0: blr             x2
    // 0x10eb6a4: ldur            x1, [fp, #-8]
    // 0x10eb6a8: stur            x0, [fp, #-8]
    // 0x10eb6ac: r0 = popTransform()
    //     0x10eb6ac: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x10eb6b0: ldur            x0, [fp, #-8]
    // 0x10eb6b4: LeaveFrame
    //     0x10eb6b4: mov             SP, fp
    //     0x10eb6b8: ldp             fp, lr, [SP], #0x10
    // 0x10eb6bc: ret
    //     0x10eb6bc: ret             
    // 0x10eb6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb6c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb6c4: b               #0x10eb648
    // 0x10eb6c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eb6c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3173, size: 0x14, field offset: 0x14
class BoxHitTestEntry extends HitTestEntry<dynamic> {
}

// class id: 4190, size: 0xc, field offset: 0x8
class BoxParentData extends ParentData {
}

// class id: 4193, size: 0x18, field offset: 0x18
abstract class ContainerBoxParentData<X0 bound RenderObject> extends _MixinApplication37&BoxParentData&ContainerParentDataMixin<X0 bound RenderObject> {
}

// class id: 4642, size: 0xc, field offset: 0x8
abstract class RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData> extends Object
    implements ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin> {
}

// class id: 4709, size: 0x50, field offset: 0x48
abstract class RenderBox extends RenderObject {

  _ localToGlobal(/* No info */) {
    // ** addr: 0x856eb0, size: 0x78
    // 0x856eb0: EnterFrame
    //     0x856eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x856eb4: mov             fp, SP
    // 0x856eb8: AllocStack(0x8)
    //     0x856eb8: sub             SP, SP, #8
    // 0x856ebc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, {dynamic ancestor = Null /* r2 */})
    //     0x856ebc: mov             x0, x2
    //     0x856ec0: stur            x2, [fp, #-8]
    //     0x856ec4: ldur            w2, [x4, #0x13]
    //     0x856ec8: ldur            w3, [x4, #0x1f]
    //     0x856ecc: add             x3, x3, HEAP, lsl #32
    //     0x856ed0: ldr             x16, [PP, #0x49b8]  ; [pp+0x49b8] "ancestor"
    //     0x856ed4: cmp             w3, w16
    //     0x856ed8: b.ne            #0x856ef4
    //     0x856edc: ldur            w3, [x4, #0x23]
    //     0x856ee0: add             x3, x3, HEAP, lsl #32
    //     0x856ee4: sub             w4, w2, w3
    //     0x856ee8: add             x2, fp, w4, sxtw #2
    //     0x856eec: ldr             x2, [x2, #8]
    //     0x856ef0: b               #0x856ef8
    //     0x856ef4: mov             x2, NULL
    // 0x856ef8: CheckStackOverflow
    //     0x856ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856efc: cmp             SP, x16
    //     0x856f00: b.ls            #0x856f20
    // 0x856f04: r0 = getTransformTo()
    //     0x856f04: bl              #0x857070  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x856f08: mov             x1, x0
    // 0x856f0c: ldur            x2, [fp, #-8]
    // 0x856f10: r0 = transformPoint()
    //     0x856f10: bl              #0x856f28  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0x856f14: LeaveFrame
    //     0x856f14: mov             SP, fp
    //     0x856f18: ldp             fp, lr, [SP], #0x10
    // 0x856f1c: ret
    //     0x856f1c: ret             
    // 0x856f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856f20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856f24: b               #0x856f04
  }
  get _ size(/* No info */) {
    // ** addr: 0x858808, size: 0xfc
    // 0x858808: EnterFrame
    //     0x858808: stp             fp, lr, [SP, #-0x10]!
    //     0x85880c: mov             fp, SP
    // 0x858810: AllocStack(0x18)
    //     0x858810: sub             SP, SP, #0x18
    // 0x858814: SetupParameters(RenderBox this /* r1 => r0, fp-0x8 */)
    //     0x858814: mov             x0, x1
    //     0x858818: stur            x1, [fp, #-8]
    // 0x85881c: CheckStackOverflow
    //     0x85881c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858820: cmp             SP, x16
    //     0x858824: b.ls            #0x8588fc
    // 0x858828: LoadField: r1 = r0->field_4b
    //     0x858828: ldur            w1, [x0, #0x4b]
    // 0x85882c: DecompressPointer r1
    //     0x85882c: add             x1, x1, HEAP, lsl #32
    // 0x858830: cmp             w1, NULL
    // 0x858834: b.eq            #0x858848
    // 0x858838: mov             x0, x1
    // 0x85883c: LeaveFrame
    //     0x85883c: mov             SP, fp
    //     0x858840: ldp             fp, lr, [SP], #0x10
    // 0x858844: ret
    //     0x858844: ret             
    // 0x858848: r1 = Null
    //     0x858848: mov             x1, NULL
    // 0x85884c: r2 = 8
    //     0x85884c: mov             x2, #8
    // 0x858850: r0 = AllocateArray()
    //     0x858850: bl              #0x13df928  ; AllocateArrayStub
    // 0x858854: stur            x0, [fp, #-0x10]
    // 0x858858: r16 = "RenderBox was not laid out: "
    //     0x858858: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0x85885c: StoreField: r0->field_f = r16
    //     0x85885c: stur            w16, [x0, #0xf]
    // 0x858860: ldur            x16, [fp, #-8]
    // 0x858864: str             x16, [SP]
    // 0x858868: r0 = runtimeType()
    //     0x858868: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x85886c: ldur            x1, [fp, #-0x10]
    // 0x858870: ArrayStore: r1[1] = r0  ; List_4
    //     0x858870: add             x25, x1, #0x13
    //     0x858874: str             w0, [x25]
    //     0x858878: tbz             w0, #0, #0x858894
    //     0x85887c: ldurb           w16, [x1, #-1]
    //     0x858880: ldurb           w17, [x0, #-1]
    //     0x858884: and             x16, x17, x16, lsr #2
    //     0x858888: tst             x16, HEAP, lsr #32
    //     0x85888c: b.eq            #0x858894
    //     0x858890: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x858894: ldur            x0, [fp, #-0x10]
    // 0x858898: r16 = "#"
    //     0x858898: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0x85889c: ArrayStore: r0[0] = r16  ; List_4
    //     0x85889c: stur            w16, [x0, #0x17]
    // 0x8588a0: ldur            x1, [fp, #-8]
    // 0x8588a4: r0 = shortHash()
    //     0x8588a4: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0x8588a8: ldur            x1, [fp, #-0x10]
    // 0x8588ac: ArrayStore: r1[3] = r0  ; List_4
    //     0x8588ac: add             x25, x1, #0x1b
    //     0x8588b0: str             w0, [x25]
    //     0x8588b4: tbz             w0, #0, #0x8588d0
    //     0x8588b8: ldurb           w16, [x1, #-1]
    //     0x8588bc: ldurb           w17, [x0, #-1]
    //     0x8588c0: and             x16, x17, x16, lsr #2
    //     0x8588c4: tst             x16, HEAP, lsr #32
    //     0x8588c8: b.eq            #0x8588d0
    //     0x8588cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8588d0: ldur            x16, [fp, #-0x10]
    // 0x8588d4: str             x16, [SP]
    // 0x8588d8: r0 = _interpolate()
    //     0x8588d8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8588dc: stur            x0, [fp, #-8]
    // 0x8588e0: r0 = StateError()
    //     0x8588e0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x8588e4: mov             x1, x0
    // 0x8588e8: ldur            x0, [fp, #-8]
    // 0x8588ec: StoreField: r1->field_b = r0
    //     0x8588ec: stur            w0, [x1, #0xb]
    // 0x8588f0: mov             x0, x1
    // 0x8588f4: r0 = Throw()
    //     0x8588f4: bl              #0x13ddb2c  ; ThrowStub
    // 0x8588f8: brk             #0
    // 0x8588fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8588fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858900: b               #0x858828
  }
  _ globalToLocal(/* No info */) {
    // ** addr: 0x867840, size: 0x270
    // 0x867840: EnterFrame
    //     0x867840: stp             fp, lr, [SP, #-0x10]!
    //     0x867844: mov             fp, SP
    // 0x867848: AllocStack(0x30)
    //     0x867848: sub             SP, SP, #0x30
    // 0x86784c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x86784c: mov             x0, x2
    //     0x867850: stur            x2, [fp, #-8]
    // 0x867854: CheckStackOverflow
    //     0x867854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x867858: cmp             SP, x16
    //     0x86785c: b.ls            #0x867a98
    // 0x867860: r2 = Null
    //     0x867860: mov             x2, NULL
    // 0x867864: r0 = getTransformTo()
    //     0x867864: bl              #0x857070  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x867868: mov             x1, x0
    // 0x86786c: stur            x0, [fp, #-0x10]
    // 0x867870: r0 = invert()
    //     0x867870: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x867874: mov             v1.16b, v0.16b
    // 0x867878: d0 = 0.000000
    //     0x867878: eor             v0.16b, v0.16b, v0.16b
    // 0x86787c: fcmp            d1, d0
    // 0x867880: b.ne            #0x867894
    // 0x867884: r0 = Instance_Offset
    //     0x867884: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x867888: LeaveFrame
    //     0x867888: mov             SP, fp
    //     0x86788c: ldp             fp, lr, [SP], #0x10
    // 0x867890: ret
    //     0x867890: ret             
    // 0x867894: ldur            x0, [fp, #-8]
    // 0x867898: r0 = Vector3()
    //     0x867898: bl              #0x8682fc  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x86789c: r4 = 6
    //     0x86789c: mov             x4, #6
    // 0x8678a0: stur            x0, [fp, #-0x18]
    // 0x8678a4: r0 = AllocateFloat64Array()
    //     0x8678a4: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x8678a8: ldur            x2, [fp, #-0x18]
    // 0x8678ac: StoreField: r2->field_7 = r0
    //     0x8678ac: stur            w0, [x2, #7]
    // 0x8678b0: StoreField: r0->field_27 = rZR
    //     0x8678b0: stur            xzr, [x0, #0x27]
    // 0x8678b4: StoreField: r0->field_1f = rZR
    //     0x8678b4: stur            xzr, [x0, #0x1f]
    // 0x8678b8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8678b8: stur            xzr, [x0, #0x17]
    // 0x8678bc: ldur            x1, [fp, #-0x10]
    // 0x8678c0: r0 = perspectiveTransform()
    //     0x8678c0: bl              #0x868130  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x8678c4: stur            x0, [fp, #-0x18]
    // 0x8678c8: r0 = Vector3()
    //     0x8678c8: bl              #0x8682fc  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x8678cc: r4 = 6
    //     0x8678cc: mov             x4, #6
    // 0x8678d0: stur            x0, [fp, #-0x20]
    // 0x8678d4: r0 = AllocateFloat64Array()
    //     0x8678d4: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x8678d8: ldur            x2, [fp, #-0x20]
    // 0x8678dc: StoreField: r2->field_7 = r0
    //     0x8678dc: stur            w0, [x2, #7]
    // 0x8678e0: d0 = 1.000000
    //     0x8678e0: fmov            d0, #1.00000000
    // 0x8678e4: StoreField: r0->field_27 = d0
    //     0x8678e4: stur            d0, [x0, #0x27]
    // 0x8678e8: StoreField: r0->field_1f = rZR
    //     0x8678e8: stur            xzr, [x0, #0x1f]
    // 0x8678ec: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8678ec: stur            xzr, [x0, #0x17]
    // 0x8678f0: ldur            x1, [fp, #-0x10]
    // 0x8678f4: r0 = perspectiveTransform()
    //     0x8678f4: bl              #0x868130  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x8678f8: mov             x1, x0
    // 0x8678fc: ldur            x2, [fp, #-0x18]
    // 0x867900: r0 = -()
    //     0x867900: bl              #0x868080  ; [package:vector_math/vector_math_64.dart] Vector3::-
    // 0x867904: mov             x1, x0
    // 0x867908: ldur            x0, [fp, #-8]
    // 0x86790c: stur            x1, [fp, #-0x18]
    // 0x867910: LoadField: d0 = r0->field_7
    //     0x867910: ldur            d0, [x0, #7]
    // 0x867914: stur            d0, [fp, #-0x30]
    // 0x867918: LoadField: d1 = r0->field_f
    //     0x867918: ldur            d1, [x0, #0xf]
    // 0x86791c: stur            d1, [fp, #-0x28]
    // 0x867920: r0 = Vector3()
    //     0x867920: bl              #0x8682fc  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x867924: r4 = 6
    //     0x867924: mov             x4, #6
    // 0x867928: stur            x0, [fp, #-8]
    // 0x86792c: r0 = AllocateFloat64Array()
    //     0x86792c: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x867930: ldur            x2, [fp, #-8]
    // 0x867934: StoreField: r2->field_7 = r0
    //     0x867934: stur            w0, [x2, #7]
    // 0x867938: StoreField: r0->field_27 = rZR
    //     0x867938: stur            xzr, [x0, #0x27]
    // 0x86793c: ldur            d0, [fp, #-0x28]
    // 0x867940: StoreField: r0->field_1f = d0
    //     0x867940: stur            d0, [x0, #0x1f]
    // 0x867944: ldur            d0, [fp, #-0x30]
    // 0x867948: ArrayStore: r0[0] = d0  ; List_8
    //     0x867948: stur            d0, [x0, #0x17]
    // 0x86794c: ldur            x1, [fp, #-0x10]
    // 0x867950: r0 = perspectiveTransform()
    //     0x867950: bl              #0x868130  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x867954: mov             x2, x0
    // 0x867958: stur            x2, [fp, #-8]
    // 0x86795c: LoadField: r3 = r2->field_7
    //     0x86795c: ldur            w3, [x2, #7]
    // 0x867960: DecompressPointer r3
    //     0x867960: add             x3, x3, HEAP, lsl #32
    // 0x867964: LoadField: r0 = r3->field_13
    //     0x867964: ldur            w0, [x3, #0x13]
    // 0x867968: r1 = LoadInt32Instr(r0)
    //     0x867968: sbfx            x1, x0, #1, #0x1f
    // 0x86796c: mov             x0, x1
    // 0x867970: r1 = 2
    //     0x867970: mov             x1, #2
    // 0x867974: cmp             x1, x0
    // 0x867978: b.hs            #0x867aa0
    // 0x86797c: LoadField: d0 = r3->field_27
    //     0x86797c: ldur            d0, [x3, #0x27]
    // 0x867980: LoadField: d1 = r3->field_1f
    //     0x867980: ldur            d1, [x3, #0x1f]
    // 0x867984: d2 = 0.000000
    //     0x867984: eor             v2.16b, v2.16b, v2.16b
    // 0x867988: fmul            d3, d1, d2
    // 0x86798c: fadd            d1, d0, d3
    // 0x867990: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x867990: ldur            d0, [x3, #0x17]
    // 0x867994: fmul            d3, d0, d2
    // 0x867998: fadd            d0, d1, d3
    // 0x86799c: ldur            x3, [fp, #-0x18]
    // 0x8679a0: LoadField: r4 = r3->field_7
    //     0x8679a0: ldur            w4, [x3, #7]
    // 0x8679a4: DecompressPointer r4
    //     0x8679a4: add             x4, x4, HEAP, lsl #32
    // 0x8679a8: LoadField: r0 = r4->field_13
    //     0x8679a8: ldur            w0, [x4, #0x13]
    // 0x8679ac: r1 = LoadInt32Instr(r0)
    //     0x8679ac: sbfx            x1, x0, #1, #0x1f
    // 0x8679b0: mov             x0, x1
    // 0x8679b4: r1 = 2
    //     0x8679b4: mov             x1, #2
    // 0x8679b8: cmp             x1, x0
    // 0x8679bc: b.hs            #0x867aa4
    // 0x8679c0: LoadField: d1 = r4->field_27
    //     0x8679c0: ldur            d1, [x4, #0x27]
    // 0x8679c4: LoadField: d3 = r4->field_1f
    //     0x8679c4: ldur            d3, [x4, #0x1f]
    // 0x8679c8: fmul            d4, d3, d2
    // 0x8679cc: fadd            d3, d1, d4
    // 0x8679d0: ArrayLoad: d1 = r4[0]  ; List_8
    //     0x8679d0: ldur            d1, [x4, #0x17]
    // 0x8679d4: fmul            d4, d1, d2
    // 0x8679d8: fadd            d1, d3, d4
    // 0x8679dc: fdiv            d2, d0, d1
    // 0x8679e0: mov             x1, x3
    // 0x8679e4: mov             v0.16b, v2.16b
    // 0x8679e8: r0 = scaled()
    //     0x8679e8: bl              #0x867ffc  ; [package:vector_math/vector_math_64.dart] Vector3::scaled
    // 0x8679ec: ldur            x1, [fp, #-8]
    // 0x8679f0: stur            x0, [fp, #-8]
    // 0x8679f4: r0 = clone()
    //     0x8679f4: bl              #0x867f50  ; [package:vector_math/vector_math_64.dart] Vector3::clone
    // 0x8679f8: mov             x1, x0
    // 0x8679fc: ldur            x0, [fp, #-8]
    // 0x867a00: LoadField: r2 = r0->field_7
    //     0x867a00: ldur            w2, [x0, #7]
    // 0x867a04: DecompressPointer r2
    //     0x867a04: add             x2, x2, HEAP, lsl #32
    // 0x867a08: LoadField: r3 = r1->field_7
    //     0x867a08: ldur            w3, [x1, #7]
    // 0x867a0c: DecompressPointer r3
    //     0x867a0c: add             x3, x3, HEAP, lsl #32
    // 0x867a10: LoadField: r0 = r3->field_13
    //     0x867a10: ldur            w0, [x3, #0x13]
    // 0x867a14: r1 = LoadInt32Instr(r0)
    //     0x867a14: sbfx            x1, x0, #1, #0x1f
    // 0x867a18: mov             x0, x1
    // 0x867a1c: r1 = 2
    //     0x867a1c: mov             x1, #2
    // 0x867a20: cmp             x1, x0
    // 0x867a24: b.hs            #0x867aa8
    // 0x867a28: LoadField: d0 = r3->field_27
    //     0x867a28: ldur            d0, [x3, #0x27]
    // 0x867a2c: LoadField: r0 = r2->field_13
    //     0x867a2c: ldur            w0, [x2, #0x13]
    // 0x867a30: r1 = LoadInt32Instr(r0)
    //     0x867a30: sbfx            x1, x0, #1, #0x1f
    // 0x867a34: mov             x0, x1
    // 0x867a38: r1 = 2
    //     0x867a38: mov             x1, #2
    // 0x867a3c: cmp             x1, x0
    // 0x867a40: b.hs            #0x867aac
    // 0x867a44: LoadField: d1 = r2->field_27
    //     0x867a44: ldur            d1, [x2, #0x27]
    // 0x867a48: fsub            d2, d0, d1
    // 0x867a4c: StoreField: r3->field_27 = d2
    //     0x867a4c: stur            d2, [x3, #0x27]
    // 0x867a50: LoadField: d0 = r3->field_1f
    //     0x867a50: ldur            d0, [x3, #0x1f]
    // 0x867a54: LoadField: d1 = r2->field_1f
    //     0x867a54: ldur            d1, [x2, #0x1f]
    // 0x867a58: fsub            d2, d0, d1
    // 0x867a5c: stur            d2, [fp, #-0x30]
    // 0x867a60: StoreField: r3->field_1f = d2
    //     0x867a60: stur            d2, [x3, #0x1f]
    // 0x867a64: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x867a64: ldur            d0, [x3, #0x17]
    // 0x867a68: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x867a68: ldur            d1, [x2, #0x17]
    // 0x867a6c: fsub            d3, d0, d1
    // 0x867a70: stur            d3, [fp, #-0x28]
    // 0x867a74: ArrayStore: r3[0] = d3  ; List_8
    //     0x867a74: stur            d3, [x3, #0x17]
    // 0x867a78: r0 = Offset()
    //     0x867a78: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x867a7c: ldur            d0, [fp, #-0x28]
    // 0x867a80: StoreField: r0->field_7 = d0
    //     0x867a80: stur            d0, [x0, #7]
    // 0x867a84: ldur            d0, [fp, #-0x30]
    // 0x867a88: StoreField: r0->field_f = d0
    //     0x867a88: stur            d0, [x0, #0xf]
    // 0x867a8c: LeaveFrame
    //     0x867a8c: mov             SP, fp
    //     0x867a90: ldp             fp, lr, [SP], #0x10
    // 0x867a94: ret
    //     0x867a94: ret             
    // 0x867a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x867a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x867a9c: b               #0x867860
    // 0x867aa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x867aa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x867aa4: r0 = RangeErrorSharedWithFPURegs()
    //     0x867aa4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x867aa8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x867aa8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x867aac: r0 = RangeErrorSharedWithFPURegs()
    //     0x867aac: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  _ hitTest(/* No info */) {
    // ** addr: 0xafb454, size: 0xf8
    // 0xafb454: EnterFrame
    //     0xafb454: stp             fp, lr, [SP, #-0x10]!
    //     0xafb458: mov             fp, SP
    // 0xafb45c: AllocStack(0x18)
    //     0xafb45c: sub             SP, SP, #0x18
    // 0xafb460: SetupParameters(RenderBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xafb460: mov             x4, x1
    //     0xafb464: mov             x0, x3
    //     0xafb468: stur            x3, [fp, #-0x18]
    //     0xafb46c: mov             x3, x2
    //     0xafb470: stur            x1, [fp, #-8]
    //     0xafb474: stur            x2, [fp, #-0x10]
    // 0xafb478: CheckStackOverflow
    //     0xafb478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xafb47c: cmp             SP, x16
    //     0xafb480: b.ls            #0xafb540
    // 0xafb484: LoadField: r1 = r4->field_4b
    //     0xafb484: ldur            w1, [x4, #0x4b]
    // 0xafb488: DecompressPointer r1
    //     0xafb488: add             x1, x1, HEAP, lsl #32
    // 0xafb48c: cmp             w1, NULL
    // 0xafb490: b.eq            #0xafb548
    // 0xafb494: mov             x2, x0
    // 0xafb498: r0 = contains()
    //     0xafb498: bl              #0x81d498  ; [dart:ui] Size::contains
    // 0xafb49c: tbnz            w0, #4, #0xafb530
    // 0xafb4a0: ldur            x4, [fp, #-8]
    // 0xafb4a4: r0 = LoadClassIdInstr(r4)
    //     0xafb4a4: ldur            x0, [x4, #-1]
    //     0xafb4a8: ubfx            x0, x0, #0xc, #0x14
    // 0xafb4ac: mov             x1, x4
    // 0xafb4b0: ldur            x2, [fp, #-0x10]
    // 0xafb4b4: ldur            x3, [fp, #-0x18]
    // 0xafb4b8: r0 = GDT[cid_x0 + 0xc77b]()
    //     0xafb4b8: mov             x17, #0xc77b
    //     0xafb4bc: add             lr, x0, x17
    //     0xafb4c0: ldr             lr, [x21, lr, lsl #3]
    //     0xafb4c4: blr             lr
    // 0xafb4c8: tbz             w0, #4, #0xafb4f8
    // 0xafb4cc: ldur            x3, [fp, #-8]
    // 0xafb4d0: r0 = LoadClassIdInstr(r3)
    //     0xafb4d0: ldur            x0, [x3, #-1]
    //     0xafb4d4: ubfx            x0, x0, #0xc, #0x14
    // 0xafb4d8: mov             x1, x3
    // 0xafb4dc: ldur            x2, [fp, #-0x18]
    // 0xafb4e0: r0 = GDT[cid_x0 + 0x121f7]()
    //     0xafb4e0: mov             x17, #0x21f7
    //     0xafb4e4: movk            x17, #1, lsl #16
    //     0xafb4e8: add             lr, x0, x17
    //     0xafb4ec: ldr             lr, [x21, lr, lsl #3]
    //     0xafb4f0: blr             lr
    // 0xafb4f4: tbnz            w0, #4, #0xafb530
    // 0xafb4f8: ldur            x0, [fp, #-8]
    // 0xafb4fc: r1 = <RenderBox>
    //     0xafb4fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xafb500: ldr             x1, [x1, #0x5c8]
    // 0xafb504: r0 = BoxHitTestEntry()
    //     0xafb504: bl              #0xaf81ac  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x14)
    // 0xafb508: mov             x1, x0
    // 0xafb50c: ldur            x0, [fp, #-8]
    // 0xafb510: StoreField: r1->field_b = r0
    //     0xafb510: stur            w0, [x1, #0xb]
    // 0xafb514: mov             x2, x1
    // 0xafb518: ldur            x1, [fp, #-0x10]
    // 0xafb51c: r0 = add()
    //     0xafb51c: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0xafb520: r0 = true
    //     0xafb520: add             x0, NULL, #0x20  ; true
    // 0xafb524: LeaveFrame
    //     0xafb524: mov             SP, fp
    //     0xafb528: ldp             fp, lr, [SP], #0x10
    // 0xafb52c: ret
    //     0xafb52c: ret             
    // 0xafb530: r0 = false
    //     0xafb530: add             x0, NULL, #0x30  ; false
    // 0xafb534: LeaveFrame
    //     0xafb534: mov             SP, fp
    //     0xafb538: ldp             fp, lr, [SP], #0x10
    // 0xafb53c: ret
    //     0xafb53c: ret             
    // 0xafb540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafb540: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafb544: b               #0xafb484
    // 0xafb548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xafb548: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1628c, size: 0xcc
    // 0xb1628c: EnterFrame
    //     0xb1628c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16290: mov             fp, SP
    // 0xb16294: AllocStack(0x38)
    //     0xb16294: sub             SP, SP, #0x38
    // 0xb16298: SetupParameters(RenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xb16298: stur            x1, [fp, #-8]
    //     0xb1629c: stur            d0, [fp, #-0x10]
    // 0xb162a0: CheckStackOverflow
    //     0xb162a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb162a4: cmp             SP, x16
    //     0xb162a8: b.ls            #0xb16334
    // 0xb162ac: r0 = LoadClassIdInstr(r1)
    //     0xb162ac: ldur            x0, [x1, #-1]
    //     0xb162b0: ubfx            x0, x0, #0xc, #0x14
    // 0xb162b4: str             x1, [SP]
    // 0xb162b8: r0 = GDT[cid_x0 + 0x12f2c]()
    //     0xb162b8: mov             x17, #0x2f2c
    //     0xb162bc: movk            x17, #1, lsl #16
    //     0xb162c0: add             lr, x0, x17
    //     0xb162c4: ldr             lr, [x21, lr, lsl #3]
    //     0xb162c8: blr             lr
    // 0xb162cc: ldur            d0, [fp, #-0x10]
    // 0xb162d0: r1 = inline_Allocate_Double()
    //     0xb162d0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb162d4: add             x1, x1, #0x10
    //     0xb162d8: cmp             x2, x1
    //     0xb162dc: b.ls            #0xb1633c
    //     0xb162e0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb162e4: sub             x1, x1, #0xf
    //     0xb162e8: mov             x2, #0xe19c
    //     0xb162ec: movk            x2, #3, lsl #16
    //     0xb162f0: stur            x2, [x1, #-1]
    // 0xb162f4: dmb             ishst
    // 0xb162f8: StoreField: r1->field_7 = d0
    //     0xb162f8: stur            d0, [x1, #7]
    // 0xb162fc: r16 = <double, double>
    //     0xb162fc: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb16300: ldr             x16, [x16, #0x228]
    // 0xb16304: ldur            lr, [fp, #-8]
    // 0xb16308: stp             lr, x16, [SP, #0x18]
    // 0xb1630c: r16 = Instance__IntrinsicDimension
    //     0xb1630c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98a78] Obj!_IntrinsicDimension@12c4681
    //     0xb16310: ldr             x16, [x16, #0xa78]
    // 0xb16314: stp             x1, x16, [SP, #8]
    // 0xb16318: str             x0, [SP]
    // 0xb1631c: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb1631c: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb16320: r0 = _computeIntrinsics()
    //     0xb16320: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb16324: LoadField: d0 = r0->field_7
    //     0xb16324: ldur            d0, [x0, #7]
    // 0xb16328: LeaveFrame
    //     0xb16328: mov             SP, fp
    //     0xb1632c: ldp             fp, lr, [SP], #0x10
    // 0xb16330: ret
    //     0xb16330: ret             
    // 0xb16334: r0 = StackOverflowSharedWithFPURegs()
    //     0xb16334: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb16338: b               #0xb162ac
    // 0xb1633c: SaveReg d0
    //     0xb1633c: str             q0, [SP, #-0x10]!
    // 0xb16340: SaveReg r0
    //     0xb16340: str             x0, [SP, #-8]!
    // 0xb16344: r0 = AllocateDouble()
    //     0xb16344: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16348: mov             x1, x0
    // 0xb1634c: RestoreReg r0
    //     0xb1634c: ldr             x0, [SP], #8
    // 0xb16350: RestoreReg d0
    //     0xb16350: ldr             q0, [SP], #0x10
    // 0xb16354: b               #0xb162f8
  }
  _ _computeIntrinsics(/* No info */) {
    // ** addr: 0xb16358, size: 0x80
    // 0xb16358: EnterFrame
    //     0xb16358: stp             fp, lr, [SP, #-0x10]!
    //     0xb1635c: mov             fp, SP
    // 0xb16360: AllocStack(0x28)
    //     0xb16360: sub             SP, SP, #0x28
    // 0xb16364: SetupParameters()
    //     0xb16364: ldur            w0, [x4, #0xf]
    //     0xb16368: cbnz            w0, #0xb16374
    //     0xb1636c: mov             x1, NULL
    //     0xb16370: b               #0xb16384
    //     0xb16374: ldur            w1, [x4, #0x17]
    //     0xb16378: add             x2, fp, w1, sxtw #2
    //     0xb1637c: ldr             x2, [x2, #0x10]
    //     0xb16380: mov             x1, x2
    // 0xb16384: CheckStackOverflow
    //     0xb16384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16388: cmp             SP, x16
    //     0xb1638c: b.ls            #0xb163d0
    // 0xb16390: cbnz            w0, #0xb1639c
    // 0xb16394: r0 = <Object, dynamic>
    //     0xb16394: ldr             x0, [PP, #0x5428]  ; [pp+0x5428] TypeArguments: <Object, dynamic>
    // 0xb16398: b               #0xb163a0
    // 0xb1639c: mov             x0, x1
    // 0xb163a0: ldr             x16, [fp, #0x28]
    // 0xb163a4: stp             x16, x0, [SP, #0x18]
    // 0xb163a8: ldr             x16, [fp, #0x20]
    // 0xb163ac: ldr             lr, [fp, #0x18]
    // 0xb163b0: stp             lr, x16, [SP, #8]
    // 0xb163b4: ldr             x16, [fp, #0x10]
    // 0xb163b8: str             x16, [SP]
    // 0xb163bc: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb163bc: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb163c0: r0 = _computeWithTimeline()
    //     0xb163c0: bl              #0xb163d8  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeWithTimeline
    // 0xb163c4: LeaveFrame
    //     0xb163c4: mov             SP, fp
    //     0xb163c8: ldp             fp, lr, [SP], #0x10
    // 0xb163cc: ret
    //     0xb163cc: ret             
    // 0xb163d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb163d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb163d4: b               #0xb16390
  }
  _ _computeWithTimeline(/* No info */) {
    // ** addr: 0xb163d8, size: 0x58
    // 0xb163d8: EnterFrame
    //     0xb163d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb163dc: mov             fp, SP
    // 0xb163e0: CheckStackOverflow
    //     0xb163e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb163e4: cmp             SP, x16
    //     0xb163e8: b.ls            #0xb16428
    // 0xb163ec: ldr             x0, [fp, #0x28]
    // 0xb163f0: LoadField: r2 = r0->field_47
    //     0xb163f0: ldur            w2, [x0, #0x47]
    // 0xb163f4: DecompressPointer r2
    //     0xb163f4: add             x2, x2, HEAP, lsl #32
    // 0xb163f8: ldr             x1, [fp, #0x20]
    // 0xb163fc: r0 = LoadClassIdInstr(r1)
    //     0xb163fc: ldur            x0, [x1, #-1]
    //     0xb16400: ubfx            x0, x0, #0xc, #0x14
    // 0xb16404: ldr             x3, [fp, #0x18]
    // 0xb16408: ldr             x5, [fp, #0x10]
    // 0xb1640c: r0 = GDT[cid_x0 + 0x18c3]()
    //     0xb1640c: mov             x17, #0x18c3
    //     0xb16410: add             lr, x0, x17
    //     0xb16414: ldr             lr, [x21, lr, lsl #3]
    //     0xb16418: blr             lr
    // 0xb1641c: LeaveFrame
    //     0xb1641c: mov             SP, fp
    //     0xb16420: ldp             fp, lr, [SP], #0x10
    // 0xb16424: ret
    //     0xb16424: ret             
    // 0xb16428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1642c: b               #0xb163ec
  }
  _ getMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16750, size: 0xcc
    // 0xb16750: EnterFrame
    //     0xb16750: stp             fp, lr, [SP, #-0x10]!
    //     0xb16754: mov             fp, SP
    // 0xb16758: AllocStack(0x38)
    //     0xb16758: sub             SP, SP, #0x38
    // 0xb1675c: SetupParameters(RenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xb1675c: stur            x1, [fp, #-8]
    //     0xb16760: stur            d0, [fp, #-0x10]
    // 0xb16764: CheckStackOverflow
    //     0xb16764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16768: cmp             SP, x16
    //     0xb1676c: b.ls            #0xb167f8
    // 0xb16770: r0 = LoadClassIdInstr(r1)
    //     0xb16770: ldur            x0, [x1, #-1]
    //     0xb16774: ubfx            x0, x0, #0xc, #0x14
    // 0xb16778: str             x1, [SP]
    // 0xb1677c: r0 = GDT[cid_x0 + 0x12498]()
    //     0xb1677c: mov             x17, #0x2498
    //     0xb16780: movk            x17, #1, lsl #16
    //     0xb16784: add             lr, x0, x17
    //     0xb16788: ldr             lr, [x21, lr, lsl #3]
    //     0xb1678c: blr             lr
    // 0xb16790: ldur            d0, [fp, #-0x10]
    // 0xb16794: r1 = inline_Allocate_Double()
    //     0xb16794: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb16798: add             x1, x1, #0x10
    //     0xb1679c: cmp             x2, x1
    //     0xb167a0: b.ls            #0xb16800
    //     0xb167a4: str             x1, [THR, #0x60]  ; THR::top
    //     0xb167a8: sub             x1, x1, #0xf
    //     0xb167ac: mov             x2, #0xe19c
    //     0xb167b0: movk            x2, #3, lsl #16
    //     0xb167b4: stur            x2, [x1, #-1]
    // 0xb167b8: dmb             ishst
    // 0xb167bc: StoreField: r1->field_7 = d0
    //     0xb167bc: stur            d0, [x1, #7]
    // 0xb167c0: r16 = <double, double>
    //     0xb167c0: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb167c4: ldr             x16, [x16, #0x228]
    // 0xb167c8: ldur            lr, [fp, #-8]
    // 0xb167cc: stp             lr, x16, [SP, #0x18]
    // 0xb167d0: r16 = Instance__IntrinsicDimension
    //     0xb167d0: add             x16, PP, #0x96, lsl #12  ; [pp+0x969d8] Obj!_IntrinsicDimension@12c46a1
    //     0xb167d4: ldr             x16, [x16, #0x9d8]
    // 0xb167d8: stp             x1, x16, [SP, #8]
    // 0xb167dc: str             x0, [SP]
    // 0xb167e0: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb167e0: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb167e4: r0 = _computeIntrinsics()
    //     0xb167e4: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb167e8: LoadField: d0 = r0->field_7
    //     0xb167e8: ldur            d0, [x0, #7]
    // 0xb167ec: LeaveFrame
    //     0xb167ec: mov             SP, fp
    //     0xb167f0: ldp             fp, lr, [SP], #0x10
    // 0xb167f4: ret
    //     0xb167f4: ret             
    // 0xb167f8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb167f8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb167fc: b               #0xb16770
    // 0xb16800: SaveReg d0
    //     0xb16800: str             q0, [SP, #-0x10]!
    // 0xb16804: SaveReg r0
    //     0xb16804: str             x0, [SP, #-8]!
    // 0xb16808: r0 = AllocateDouble()
    //     0xb16808: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1680c: mov             x1, x0
    // 0xb16810: RestoreReg r0
    //     0xb16810: ldr             x0, [SP], #8
    // 0xb16814: RestoreReg d0
    //     0xb16814: ldr             q0, [SP], #0x10
    // 0xb16818: b               #0xb167bc
  }
  _ getMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb16950, size: 0xcc
    // 0xb16950: EnterFrame
    //     0xb16950: stp             fp, lr, [SP, #-0x10]!
    //     0xb16954: mov             fp, SP
    // 0xb16958: AllocStack(0x38)
    //     0xb16958: sub             SP, SP, #0x38
    // 0xb1695c: SetupParameters(RenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xb1695c: stur            x1, [fp, #-8]
    //     0xb16960: stur            d0, [fp, #-0x10]
    // 0xb16964: CheckStackOverflow
    //     0xb16964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16968: cmp             SP, x16
    //     0xb1696c: b.ls            #0xb169f8
    // 0xb16970: r0 = LoadClassIdInstr(r1)
    //     0xb16970: ldur            x0, [x1, #-1]
    //     0xb16974: ubfx            x0, x0, #0xc, #0x14
    // 0xb16978: str             x1, [SP]
    // 0xb1697c: r0 = GDT[cid_x0 + 0x120ed]()
    //     0xb1697c: mov             x17, #0x20ed
    //     0xb16980: movk            x17, #1, lsl #16
    //     0xb16984: add             lr, x0, x17
    //     0xb16988: ldr             lr, [x21, lr, lsl #3]
    //     0xb1698c: blr             lr
    // 0xb16990: ldur            d0, [fp, #-0x10]
    // 0xb16994: r1 = inline_Allocate_Double()
    //     0xb16994: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb16998: add             x1, x1, #0x10
    //     0xb1699c: cmp             x2, x1
    //     0xb169a0: b.ls            #0xb16a00
    //     0xb169a4: str             x1, [THR, #0x60]  ; THR::top
    //     0xb169a8: sub             x1, x1, #0xf
    //     0xb169ac: mov             x2, #0xe19c
    //     0xb169b0: movk            x2, #3, lsl #16
    //     0xb169b4: stur            x2, [x1, #-1]
    // 0xb169b8: dmb             ishst
    // 0xb169bc: StoreField: r1->field_7 = d0
    //     0xb169bc: stur            d0, [x1, #7]
    // 0xb169c0: r16 = <double, double>
    //     0xb169c0: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb169c4: ldr             x16, [x16, #0x228]
    // 0xb169c8: ldur            lr, [fp, #-8]
    // 0xb169cc: stp             lr, x16, [SP, #0x18]
    // 0xb169d0: r16 = Instance__IntrinsicDimension
    //     0xb169d0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90bc8] Obj!_IntrinsicDimension@12c46c1
    //     0xb169d4: ldr             x16, [x16, #0xbc8]
    // 0xb169d8: stp             x1, x16, [SP, #8]
    // 0xb169dc: str             x0, [SP]
    // 0xb169e0: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb169e0: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb169e4: r0 = _computeIntrinsics()
    //     0xb169e4: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb169e8: LoadField: d0 = r0->field_7
    //     0xb169e8: ldur            d0, [x0, #7]
    // 0xb169ec: LeaveFrame
    //     0xb169ec: mov             SP, fp
    //     0xb169f0: ldp             fp, lr, [SP], #0x10
    // 0xb169f4: ret
    //     0xb169f4: ret             
    // 0xb169f8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb169f8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb169fc: b               #0xb16970
    // 0xb16a00: SaveReg d0
    //     0xb16a00: str             q0, [SP, #-0x10]!
    // 0xb16a04: SaveReg r0
    //     0xb16a04: str             x0, [SP, #-8]!
    // 0xb16a08: r0 = AllocateDouble()
    //     0xb16a08: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16a0c: mov             x1, x0
    // 0xb16a10: RestoreReg r0
    //     0xb16a10: ldr             x0, [SP], #8
    // 0xb16a14: RestoreReg d0
    //     0xb16a14: ldr             q0, [SP], #0x10
    // 0xb16a18: b               #0xb169bc
  }
  _ getMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb177d8, size: 0xc8
    // 0xb177d8: EnterFrame
    //     0xb177d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb177dc: mov             fp, SP
    // 0xb177e0: AllocStack(0x38)
    //     0xb177e0: sub             SP, SP, #0x38
    // 0xb177e4: SetupParameters(RenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xb177e4: stur            x1, [fp, #-8]
    //     0xb177e8: stur            d0, [fp, #-0x10]
    // 0xb177ec: CheckStackOverflow
    //     0xb177ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb177f0: cmp             SP, x16
    //     0xb177f4: b.ls            #0xb1787c
    // 0xb177f8: r0 = LoadClassIdInstr(r1)
    //     0xb177f8: ldur            x0, [x1, #-1]
    //     0xb177fc: ubfx            x0, x0, #0xc, #0x14
    // 0xb17800: str             x1, [SP]
    // 0xb17804: r0 = GDT[cid_x0 + 0xc5bb]()
    //     0xb17804: mov             x17, #0xc5bb
    //     0xb17808: add             lr, x0, x17
    //     0xb1780c: ldr             lr, [x21, lr, lsl #3]
    //     0xb17810: blr             lr
    // 0xb17814: ldur            d0, [fp, #-0x10]
    // 0xb17818: r1 = inline_Allocate_Double()
    //     0xb17818: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb1781c: add             x1, x1, #0x10
    //     0xb17820: cmp             x2, x1
    //     0xb17824: b.ls            #0xb17884
    //     0xb17828: str             x1, [THR, #0x60]  ; THR::top
    //     0xb1782c: sub             x1, x1, #0xf
    //     0xb17830: mov             x2, #0xe19c
    //     0xb17834: movk            x2, #3, lsl #16
    //     0xb17838: stur            x2, [x1, #-1]
    // 0xb1783c: dmb             ishst
    // 0xb17840: StoreField: r1->field_7 = d0
    //     0xb17840: stur            d0, [x1, #7]
    // 0xb17844: r16 = <double, double>
    //     0xb17844: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb17848: ldr             x16, [x16, #0x228]
    // 0xb1784c: ldur            lr, [fp, #-8]
    // 0xb17850: stp             lr, x16, [SP, #0x18]
    // 0xb17854: r16 = Instance__IntrinsicDimension
    //     0xb17854: add             x16, PP, #0x99, lsl #12  ; [pp+0x992f0] Obj!_IntrinsicDimension@12c46e1
    //     0xb17858: ldr             x16, [x16, #0x2f0]
    // 0xb1785c: stp             x1, x16, [SP, #8]
    // 0xb17860: str             x0, [SP]
    // 0xb17864: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb17864: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb17868: r0 = _computeIntrinsics()
    //     0xb17868: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb1786c: LoadField: d0 = r0->field_7
    //     0xb1786c: ldur            d0, [x0, #7]
    // 0xb17870: LeaveFrame
    //     0xb17870: mov             SP, fp
    //     0xb17874: ldp             fp, lr, [SP], #0x10
    // 0xb17878: ret
    //     0xb17878: ret             
    // 0xb1787c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb1787c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb17880: b               #0xb177f8
    // 0xb17884: SaveReg d0
    //     0xb17884: str             q0, [SP, #-0x10]!
    // 0xb17888: SaveReg r0
    //     0xb17888: str             x0, [SP, #-8]!
    // 0xb1788c: r0 = AllocateDouble()
    //     0xb1788c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17890: mov             x1, x0
    // 0xb17894: RestoreReg r0
    //     0xb17894: ldr             x0, [SP], #8
    // 0xb17898: RestoreReg d0
    //     0xb17898: ldr             q0, [SP], #0x10
    // 0xb1789c: b               #0xb17840
  }
  _ getDryBaseline(/* No info */) {
    // ** addr: 0xb19678, size: 0x78
    // 0xb19678: EnterFrame
    //     0xb19678: stp             fp, lr, [SP, #-0x10]!
    //     0xb1967c: mov             fp, SP
    // 0xb19680: AllocStack(0x38)
    //     0xb19680: sub             SP, SP, #0x38
    // 0xb19684: SetupParameters(RenderBox this /* r1 => r0, fp-0x8 */)
    //     0xb19684: mov             x0, x1
    //     0xb19688: stur            x1, [fp, #-8]
    // 0xb1968c: CheckStackOverflow
    //     0xb1968c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb19690: cmp             SP, x16
    //     0xb19694: b.ls            #0xb196e8
    // 0xb19698: r0 = AllocateRecord2()
    //     0xb19698: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb1969c: ldur            x2, [fp, #-8]
    // 0xb196a0: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb196a0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb196a4: ldr             x1, [x1, #0x868]
    // 0xb196a8: stur            x0, [fp, #-0x10]
    // 0xb196ac: r0 = AllocateClosure()
    //     0xb196ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb196b0: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb196b0: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb196b4: ldr             x16, [x16, #0x7f8]
    // 0xb196b8: ldur            lr, [fp, #-8]
    // 0xb196bc: stp             lr, x16, [SP, #0x18]
    // 0xb196c0: r16 = Instance__Baseline
    //     0xb196c0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb196c4: ldr             x16, [x16, #0x800]
    // 0xb196c8: ldur            lr, [fp, #-0x10]
    // 0xb196cc: stp             lr, x16, [SP, #8]
    // 0xb196d0: str             x0, [SP]
    // 0xb196d4: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb196d4: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb196d8: r0 = _computeIntrinsics()
    //     0xb196d8: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb196dc: LeaveFrame
    //     0xb196dc: mov             SP, fp
    //     0xb196e0: ldp             fp, lr, [SP], #0x10
    // 0xb196e4: ret
    //     0xb196e4: ret             
    // 0xb196e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb196e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb196ec: b               #0xb19698
  }
  [closure] double? _computeDryBaseline(dynamic, (BoxConstraints, TextBaseline)) {
    // ** addr: 0xb196f0, size: 0x3c
    // 0xb196f0: EnterFrame
    //     0xb196f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb196f4: mov             fp, SP
    // 0xb196f8: ldr             x0, [fp, #0x18]
    // 0xb196fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb196fc: ldur            w1, [x0, #0x17]
    // 0xb19700: DecompressPointer r1
    //     0xb19700: add             x1, x1, HEAP, lsl #32
    // 0xb19704: CheckStackOverflow
    //     0xb19704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb19708: cmp             SP, x16
    //     0xb1970c: b.ls            #0xb19724
    // 0xb19710: ldr             x2, [fp, #0x10]
    // 0xb19714: r0 = _computeDryBaseline()
    //     0xb19714: bl              #0xb1972c  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline
    // 0xb19718: LeaveFrame
    //     0xb19718: mov             SP, fp
    //     0xb1971c: ldp             fp, lr, [SP], #0x10
    // 0xb19720: ret
    //     0xb19720: ret             
    // 0xb19724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb19724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb19728: b               #0xb19710
  }
  _ _computeDryBaseline(/* No info */) {
    // ** addr: 0xb1972c, size: 0x60
    // 0xb1972c: EnterFrame
    //     0xb1972c: stp             fp, lr, [SP, #-0x10]!
    //     0xb19730: mov             fp, SP
    // 0xb19734: CheckStackOverflow
    //     0xb19734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb19738: cmp             SP, x16
    //     0xb1973c: b.ls            #0xb19784
    // 0xb19740: LoadField: r0 = r2->field_f
    //     0xb19740: ldur            w0, [x2, #0xf]
    // 0xb19744: DecompressPointer r0
    //     0xb19744: add             x0, x0, HEAP, lsl #32
    // 0xb19748: LoadField: r3 = r2->field_13
    //     0xb19748: ldur            w3, [x2, #0x13]
    // 0xb1974c: DecompressPointer r3
    //     0xb1974c: add             x3, x3, HEAP, lsl #32
    // 0xb19750: r2 = LoadClassIdInstr(r1)
    //     0xb19750: ldur            x2, [x1, #-1]
    //     0xb19754: ubfx            x2, x2, #0xc, #0x14
    // 0xb19758: mov             x16, x0
    // 0xb1975c: mov             x0, x2
    // 0xb19760: mov             x2, x16
    // 0xb19764: r0 = GDT[cid_x0 + 0x11fe3]()
    //     0xb19764: mov             x17, #0x1fe3
    //     0xb19768: movk            x17, #1, lsl #16
    //     0xb1976c: add             lr, x0, x17
    //     0xb19770: ldr             lr, [x21, lr, lsl #3]
    //     0xb19774: blr             lr
    // 0xb19778: LeaveFrame
    //     0xb19778: mov             SP, fp
    //     0xb1977c: ldp             fp, lr, [SP], #0x10
    // 0xb19780: ret
    //     0xb19780: ret             
    // 0xb19784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb19784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb19788: b               #0xb19740
  }
  _ getDryLayout(/* No info */) {
    // ** addr: 0xb20410, size: 0x78
    // 0xb20410: EnterFrame
    //     0xb20410: stp             fp, lr, [SP, #-0x10]!
    //     0xb20414: mov             fp, SP
    // 0xb20418: AllocStack(0x38)
    //     0xb20418: sub             SP, SP, #0x38
    // 0xb2041c: SetupParameters(RenderBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb2041c: mov             x3, x1
    //     0xb20420: mov             x0, x2
    //     0xb20424: stur            x1, [fp, #-8]
    //     0xb20428: stur            x2, [fp, #-0x10]
    // 0xb2042c: CheckStackOverflow
    //     0xb2042c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb20430: cmp             SP, x16
    //     0xb20434: b.ls            #0xb20480
    // 0xb20438: mov             x2, x3
    // 0xb2043c: r1 = Function '_computeDryLayout@29392247':.
    //     0xb2043c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb20440: ldr             x1, [x1, #0x10]
    // 0xb20444: r0 = AllocateClosure()
    //     0xb20444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20448: r16 = <BoxConstraints, Size>
    //     0xb20448: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb2044c: ldr             x16, [x16, #0x18]
    // 0xb20450: ldur            lr, [fp, #-8]
    // 0xb20454: stp             lr, x16, [SP, #0x18]
    // 0xb20458: r16 = Instance__DryLayout
    //     0xb20458: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb2045c: ldr             x16, [x16, #0x20]
    // 0xb20460: ldur            lr, [fp, #-0x10]
    // 0xb20464: stp             lr, x16, [SP, #8]
    // 0xb20468: str             x0, [SP]
    // 0xb2046c: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb2046c: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb20470: r0 = _computeIntrinsics()
    //     0xb20470: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb20474: LeaveFrame
    //     0xb20474: mov             SP, fp
    //     0xb20478: ldp             fp, lr, [SP], #0x10
    // 0xb2047c: ret
    //     0xb2047c: ret             
    // 0xb20480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb20480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20484: b               #0xb20438
  }
  [closure] Size _computeDryLayout(dynamic, BoxConstraints) {
    // ** addr: 0xb20488, size: 0x3c
    // 0xb20488: EnterFrame
    //     0xb20488: stp             fp, lr, [SP, #-0x10]!
    //     0xb2048c: mov             fp, SP
    // 0xb20490: ldr             x0, [fp, #0x18]
    // 0xb20494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb20494: ldur            w1, [x0, #0x17]
    // 0xb20498: DecompressPointer r1
    //     0xb20498: add             x1, x1, HEAP, lsl #32
    // 0xb2049c: CheckStackOverflow
    //     0xb2049c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb204a0: cmp             SP, x16
    //     0xb204a4: b.ls            #0xb204bc
    // 0xb204a8: ldr             x2, [fp, #0x10]
    // 0xb204ac: r0 = _computeDryLayout()
    //     0xb204ac: bl              #0xb204c4  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout
    // 0xb204b0: LeaveFrame
    //     0xb204b0: mov             SP, fp
    //     0xb204b4: ldp             fp, lr, [SP], #0x10
    // 0xb204b8: ret
    //     0xb204b8: ret             
    // 0xb204bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb204bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb204c0: b               #0xb204a8
  }
  _ _computeDryLayout(/* No info */) {
    // ** addr: 0xb204c4, size: 0x44
    // 0xb204c4: EnterFrame
    //     0xb204c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb204c8: mov             fp, SP
    // 0xb204cc: CheckStackOverflow
    //     0xb204cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb204d0: cmp             SP, x16
    //     0xb204d4: b.ls            #0xb20500
    // 0xb204d8: r0 = LoadClassIdInstr(r1)
    //     0xb204d8: ldur            x0, [x1, #-1]
    //     0xb204dc: ubfx            x0, x0, #0xc, #0x14
    // 0xb204e0: r0 = GDT[cid_x0 + 0x12603]()
    //     0xb204e0: mov             x17, #0x2603
    //     0xb204e4: movk            x17, #1, lsl #16
    //     0xb204e8: add             lr, x0, x17
    //     0xb204ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb204f0: blr             lr
    // 0xb204f4: LeaveFrame
    //     0xb204f4: mov             SP, fp
    //     0xb204f8: ldp             fp, lr, [SP], #0x10
    // 0xb204fc: ret
    //     0xb204fc: ret             
    // 0xb20500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb20500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20504: b               #0xb204d8
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb21cd4, size: 0x24
    // 0xb21cd4: EnterFrame
    //     0xb21cd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb21cd8: mov             fp, SP
    // 0xb21cdc: ldr             x2, [fp, #0x10]
    // 0xb21ce0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb21ce0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4440] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb21ce4: ldr             x1, [x1, #0x440]
    // 0xb21ce8: r0 = AllocateClosure()
    //     0xb21ce8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb21cec: LeaveFrame
    //     0xb21cec: mov             SP, fp
    //     0xb21cf0: ldp             fp, lr, [SP], #0x10
    // 0xb21cf4: ret
    //     0xb21cf4: ret             
  }
  _ getDistanceToBaseline(/* No info */) {
    // ** addr: 0xb53c94, size: 0xe0
    // 0xb53c94: EnterFrame
    //     0xb53c94: stp             fp, lr, [SP, #-0x10]!
    //     0xb53c98: mov             fp, SP
    // 0xb53c9c: AllocStack(0x10)
    //     0xb53c9c: sub             SP, SP, #0x10
    // 0xb53ca0: SetupParameters(RenderBox this /* r1 => r0, fp-0x10 */, {dynamic onlyReal = false /* r3, fp-0x8 */})
    //     0xb53ca0: mov             x0, x1
    //     0xb53ca4: stur            x1, [fp, #-0x10]
    //     0xb53ca8: ldur            w1, [x4, #0x13]
    //     0xb53cac: ldur            w3, [x4, #0x1f]
    //     0xb53cb0: add             x3, x3, HEAP, lsl #32
    //     0xb53cb4: add             x16, PP, #0x90, lsl #12  ; [pp+0x907d8] "onlyReal"
    //     0xb53cb8: ldr             x16, [x16, #0x7d8]
    //     0xb53cbc: cmp             w3, w16
    //     0xb53cc0: b.ne            #0xb53ce0
    //     0xb53cc4: ldur            w3, [x4, #0x23]
    //     0xb53cc8: add             x3, x3, HEAP, lsl #32
    //     0xb53ccc: sub             w4, w1, w3
    //     0xb53cd0: add             x1, fp, w4, sxtw #2
    //     0xb53cd4: ldr             x1, [x1, #8]
    //     0xb53cd8: mov             x3, x1
    //     0xb53cdc: b               #0xb53ce4
    //     0xb53ce0: add             x3, NULL, #0x30  ; false
    //     0xb53ce4: stur            x3, [fp, #-8]
    // 0xb53ce8: CheckStackOverflow
    //     0xb53ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb53cec: cmp             SP, x16
    //     0xb53cf0: b.ls            #0xb53d5c
    // 0xb53cf4: mov             x1, x0
    // 0xb53cf8: r0 = getDistanceToActualBaseline()
    //     0xb53cf8: bl              #0xb53d74  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0xb53cfc: cmp             w0, NULL
    // 0xb53d00: b.ne            #0xb53d50
    // 0xb53d04: ldur            x1, [fp, #-8]
    // 0xb53d08: tbz             w1, #4, #0xb53d50
    // 0xb53d0c: ldur            x1, [fp, #-0x10]
    // 0xb53d10: r0 = size()
    //     0xb53d10: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb53d14: LoadField: d0 = r0->field_f
    //     0xb53d14: ldur            d0, [x0, #0xf]
    // 0xb53d18: r0 = inline_Allocate_Double()
    //     0xb53d18: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb53d1c: add             x0, x0, #0x10
    //     0xb53d20: cmp             x1, x0
    //     0xb53d24: b.ls            #0xb53d64
    //     0xb53d28: str             x0, [THR, #0x60]  ; THR::top
    //     0xb53d2c: sub             x0, x0, #0xf
    //     0xb53d30: mov             x1, #0xe19c
    //     0xb53d34: movk            x1, #3, lsl #16
    //     0xb53d38: stur            x1, [x0, #-1]
    // 0xb53d3c: dmb             ishst
    // 0xb53d40: StoreField: r0->field_7 = d0
    //     0xb53d40: stur            d0, [x0, #7]
    // 0xb53d44: LeaveFrame
    //     0xb53d44: mov             SP, fp
    //     0xb53d48: ldp             fp, lr, [SP], #0x10
    // 0xb53d4c: ret
    //     0xb53d4c: ret             
    // 0xb53d50: LeaveFrame
    //     0xb53d50: mov             SP, fp
    //     0xb53d54: ldp             fp, lr, [SP], #0x10
    // 0xb53d58: ret
    //     0xb53d58: ret             
    // 0xb53d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb53d5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb53d60: b               #0xb53cf4
    // 0xb53d64: SaveReg d0
    //     0xb53d64: str             q0, [SP, #-0x10]!
    // 0xb53d68: r0 = AllocateDouble()
    //     0xb53d68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb53d6c: RestoreReg d0
    //     0xb53d6c: ldr             q0, [SP], #0x10
    // 0xb53d70: b               #0xb53d40
  }
  _ getDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb53d74, size: 0xfc
    // 0xb53d74: EnterFrame
    //     0xb53d74: stp             fp, lr, [SP, #-0x10]!
    //     0xb53d78: mov             fp, SP
    // 0xb53d7c: AllocStack(0x48)
    //     0xb53d7c: sub             SP, SP, #0x48
    // 0xb53d80: SetupParameters(RenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb53d80: mov             x3, x2
    //     0xb53d84: stur            x1, [fp, #-8]
    //     0xb53d88: stur            x2, [fp, #-0x10]
    // 0xb53d8c: CheckStackOverflow
    //     0xb53d8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb53d90: cmp             SP, x16
    //     0xb53d94: b.ls            #0xb53e68
    // 0xb53d98: r1 = 1
    //     0xb53d98: mov             x1, #1
    // 0xb53d9c: r0 = AllocateContext()
    //     0xb53d9c: bl              #0x13de838  ; AllocateContextStub
    // 0xb53da0: mov             x4, x0
    // 0xb53da4: ldur            x3, [fp, #-8]
    // 0xb53da8: stur            x4, [fp, #-0x20]
    // 0xb53dac: StoreField: r4->field_f = r3
    //     0xb53dac: stur            w3, [x4, #0xf]
    // 0xb53db0: LoadField: r5 = r3->field_27
    //     0xb53db0: ldur            w5, [x3, #0x27]
    // 0xb53db4: DecompressPointer r5
    //     0xb53db4: add             x5, x5, HEAP, lsl #32
    // 0xb53db8: stur            x5, [fp, #-0x18]
    // 0xb53dbc: cmp             w5, NULL
    // 0xb53dc0: b.eq            #0xb53e4c
    // 0xb53dc4: mov             x0, x5
    // 0xb53dc8: r2 = Null
    //     0xb53dc8: mov             x2, NULL
    // 0xb53dcc: r1 = Null
    //     0xb53dcc: mov             x1, NULL
    // 0xb53dd0: r4 = LoadClassIdInstr(r0)
    //     0xb53dd0: ldur            x4, [x0, #-1]
    //     0xb53dd4: ubfx            x4, x4, #0xc, #0x14
    // 0xb53dd8: sub             x4, x4, #0xb46
    // 0xb53ddc: cmp             x4, #1
    // 0xb53de0: b.ls            #0xb53df4
    // 0xb53de4: r8 = BoxConstraints
    //     0xb53de4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb53de8: r3 = Null
    //     0xb53de8: add             x3, PP, #0x90, lsl #12  ; [pp+0x907e0] Null
    //     0xb53dec: ldr             x3, [x3, #0x7e0]
    // 0xb53df0: r0 = BoxConstraints()
    //     0xb53df0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb53df4: ldur            x2, [fp, #-0x18]
    // 0xb53df8: ldur            x3, [fp, #-0x10]
    // 0xb53dfc: r0 = AllocateRecord2()
    //     0xb53dfc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb53e00: ldur            x2, [fp, #-0x20]
    // 0xb53e04: r1 = Function '<anonymous closure>':.
    //     0xb53e04: add             x1, PP, #0x90, lsl #12  ; [pp+0x907f0] AnonymousClosure: (0xb53e70), in [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline (0xb53d74)
    //     0xb53e08: ldr             x1, [x1, #0x7f0]
    // 0xb53e0c: stur            x0, [fp, #-0x10]
    // 0xb53e10: r0 = AllocateClosure()
    //     0xb53e10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb53e14: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb53e14: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb53e18: ldr             x16, [x16, #0x7f8]
    // 0xb53e1c: ldur            lr, [fp, #-8]
    // 0xb53e20: stp             lr, x16, [SP, #0x18]
    // 0xb53e24: r16 = Instance__Baseline
    //     0xb53e24: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb53e28: ldr             x16, [x16, #0x800]
    // 0xb53e2c: ldur            lr, [fp, #-0x10]
    // 0xb53e30: stp             lr, x16, [SP, #8]
    // 0xb53e34: str             x0, [SP]
    // 0xb53e38: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb53e38: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb53e3c: r0 = _computeIntrinsics()
    //     0xb53e3c: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb53e40: LeaveFrame
    //     0xb53e40: mov             SP, fp
    //     0xb53e44: ldp             fp, lr, [SP], #0x10
    // 0xb53e48: ret
    //     0xb53e48: ret             
    // 0xb53e4c: r0 = StateError()
    //     0xb53e4c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb53e50: mov             x1, x0
    // 0xb53e54: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xb53e54: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xb53e58: StoreField: r1->field_b = r0
    //     0xb53e58: stur            w0, [x1, #0xb]
    // 0xb53e5c: mov             x0, x1
    // 0xb53e60: r0 = Throw()
    //     0xb53e60: bl              #0x13ddb2c  ; ThrowStub
    // 0xb53e64: brk             #0
    // 0xb53e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb53e68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb53e6c: b               #0xb53d98
  }
  [closure] double? <anonymous closure>(dynamic, (BoxConstraints, TextBaseline)) {
    // ** addr: 0xb53e70, size: 0x70
    // 0xb53e70: EnterFrame
    //     0xb53e70: stp             fp, lr, [SP, #-0x10]!
    //     0xb53e74: mov             fp, SP
    // 0xb53e78: ldr             x0, [fp, #0x18]
    // 0xb53e7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb53e7c: ldur            w1, [x0, #0x17]
    // 0xb53e80: DecompressPointer r1
    //     0xb53e80: add             x1, x1, HEAP, lsl #32
    // 0xb53e84: CheckStackOverflow
    //     0xb53e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb53e88: cmp             SP, x16
    //     0xb53e8c: b.ls            #0xb53ed8
    // 0xb53e90: LoadField: r0 = r1->field_f
    //     0xb53e90: ldur            w0, [x1, #0xf]
    // 0xb53e94: DecompressPointer r0
    //     0xb53e94: add             x0, x0, HEAP, lsl #32
    // 0xb53e98: ldr             x1, [fp, #0x10]
    // 0xb53e9c: LoadField: r2 = r1->field_13
    //     0xb53e9c: ldur            w2, [x1, #0x13]
    // 0xb53ea0: DecompressPointer r2
    //     0xb53ea0: add             x2, x2, HEAP, lsl #32
    // 0xb53ea4: r1 = LoadClassIdInstr(r0)
    //     0xb53ea4: ldur            x1, [x0, #-1]
    //     0xb53ea8: ubfx            x1, x1, #0xc, #0x14
    // 0xb53eac: mov             x16, x0
    // 0xb53eb0: mov             x0, x1
    // 0xb53eb4: mov             x1, x16
    // 0xb53eb8: r0 = GDT[cid_x0 + 0x1231d]()
    //     0xb53eb8: mov             x17, #0x231d
    //     0xb53ebc: movk            x17, #1, lsl #16
    //     0xb53ec0: add             lr, x0, x17
    //     0xb53ec4: ldr             lr, [x21, lr, lsl #3]
    //     0xb53ec8: blr             lr
    // 0xb53ecc: LeaveFrame
    //     0xb53ecc: mov             SP, fp
    //     0xb53ed0: ldp             fp, lr, [SP], #0x10
    // 0xb53ed4: ret
    //     0xb53ed4: ret             
    // 0xb53ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb53ed8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb53edc: b               #0xb53e90
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58bc4, size: 0x24
    // 0xb58bc4: EnterFrame
    //     0xb58bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xb58bc8: mov             fp, SP
    // 0xb58bcc: ldr             x2, [fp, #0x10]
    // 0xb58bd0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58bd0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4438] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb58bd4: ldr             x1, [x1, #0x438]
    // 0xb58bd8: r0 = AllocateClosure()
    //     0xb58bd8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58bdc: LeaveFrame
    //     0xb58bdc: mov             SP, fp
    //     0xb58be0: ldp             fp, lr, [SP], #0x10
    // 0xb58be4: ret
    //     0xb58be4: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5ed04, size: 0x24
    // 0xb5ed04: EnterFrame
    //     0xb5ed04: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ed08: mov             fp, SP
    // 0xb5ed0c: ldr             x2, [fp, #0x10]
    // 0xb5ed10: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5ed10: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a7d8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb5ed14: ldr             x1, [x1, #0x7d8]
    // 0xb5ed18: r0 = AllocateClosure()
    //     0xb5ed18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5ed1c: LeaveFrame
    //     0xb5ed1c: mov             SP, fp
    //     0xb5ed20: ldp             fp, lr, [SP], #0x10
    // 0xb5ed24: ret
    //     0xb5ed24: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb67ac8, size: 0x58
    // 0xb67ac8: EnterFrame
    //     0xb67ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xb67acc: mov             fp, SP
    // 0xb67ad0: mov             x0, x2
    // 0xb67ad4: mov             x5, x1
    // 0xb67ad8: mov             x4, x2
    // 0xb67adc: r2 = Null
    //     0xb67adc: mov             x2, NULL
    // 0xb67ae0: r1 = Null
    //     0xb67ae0: mov             x1, NULL
    // 0xb67ae4: r4 = 60
    //     0xb67ae4: mov             x4, #0x3c
    // 0xb67ae8: branchIfSmi(r0, 0xb67af4)
    //     0xb67ae8: tbz             w0, #0, #0xb67af4
    // 0xb67aec: r4 = LoadClassIdInstr(r0)
    //     0xb67aec: ldur            x4, [x0, #-1]
    //     0xb67af0: ubfx            x4, x4, #0xc, #0x14
    // 0xb67af4: sub             x4, x4, #0xb46
    // 0xb67af8: cmp             x4, #1
    // 0xb67afc: b.ls            #0xb67b10
    // 0xb67b00: r8 = BoxConstraints
    //     0xb67b00: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb67b04: r3 = Null
    //     0xb67b04: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a7e0] Null
    //     0xb67b08: ldr             x3, [x3, #0x7e0]
    // 0xb67b0c: r0 = BoxConstraints()
    //     0xb67b0c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb67b10: r0 = Null
    //     0xb67b10: mov             x0, NULL
    // 0xb67b14: LeaveFrame
    //     0xb67b14: mov             SP, fp
    //     0xb67b18: ldp             fp, lr, [SP], #0x10
    // 0xb67b1c: ret
    //     0xb67b1c: ret             
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1f9c, size: 0xa0
    // 0xbf1f9c: EnterFrame
    //     0xbf1f9c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1fa0: mov             fp, SP
    // 0xbf1fa4: AllocStack(0x10)
    //     0xbf1fa4: sub             SP, SP, #0x10
    // 0xbf1fa8: SetupParameters(dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf1fa8: stur            x3, [fp, #-0x10]
    // 0xbf1fac: CheckStackOverflow
    //     0xbf1fac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1fb0: cmp             SP, x16
    //     0xbf1fb4: b.ls            #0xbf2030
    // 0xbf1fb8: LoadField: r4 = r2->field_7
    //     0xbf1fb8: ldur            w4, [x2, #7]
    // 0xbf1fbc: DecompressPointer r4
    //     0xbf1fbc: add             x4, x4, HEAP, lsl #32
    // 0xbf1fc0: stur            x4, [fp, #-8]
    // 0xbf1fc4: cmp             w4, NULL
    // 0xbf1fc8: b.eq            #0xbf2038
    // 0xbf1fcc: mov             x0, x4
    // 0xbf1fd0: r2 = Null
    //     0xbf1fd0: mov             x2, NULL
    // 0xbf1fd4: r1 = Null
    //     0xbf1fd4: mov             x1, NULL
    // 0xbf1fd8: r4 = LoadClassIdInstr(r0)
    //     0xbf1fd8: ldur            x4, [x0, #-1]
    //     0xbf1fdc: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1fe0: r17 = -4190
    //     0xbf1fe0: mov             x17, #-0x105e
    // 0xbf1fe4: add             x4, x4, x17
    // 0xbf1fe8: cmp             x4, #0x17
    // 0xbf1fec: b.ls            #0xbf2004
    // 0xbf1ff0: r8 = BoxParentData
    //     0xbf1ff0: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbf1ff4: ldr             x8, [x8, #0x5e8]
    // 0xbf1ff8: r3 = Null
    //     0xbf1ff8: add             x3, PP, #0x15, lsl #12  ; [pp+0x155f0] Null
    //     0xbf1ffc: ldr             x3, [x3, #0x5f0]
    // 0xbf2000: r0 = DefaultTypeTest()
    //     0xbf2000: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf2004: ldur            x0, [fp, #-8]
    // 0xbf2008: LoadField: r1 = r0->field_7
    //     0xbf2008: ldur            w1, [x0, #7]
    // 0xbf200c: DecompressPointer r1
    //     0xbf200c: add             x1, x1, HEAP, lsl #32
    // 0xbf2010: LoadField: d0 = r1->field_7
    //     0xbf2010: ldur            d0, [x1, #7]
    // 0xbf2014: LoadField: d1 = r1->field_f
    //     0xbf2014: ldur            d1, [x1, #0xf]
    // 0xbf2018: ldur            x1, [fp, #-0x10]
    // 0xbf201c: r0 = translateByDouble()
    //     0xbf201c: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf2020: r0 = Null
    //     0xbf2020: mov             x0, NULL
    // 0xbf2024: LeaveFrame
    //     0xbf2024: mov             SP, fp
    //     0xbf2028: ldp             fp, lr, [SP], #0x10
    // 0xbf202c: ret
    //     0xbf202c: ret             
    // 0xbf2030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2030: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2034: b               #0xbf1fb8
    // 0xbf2038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2038: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0xbfb4c8, size: 0x94
    // 0xbfb4c8: EnterFrame
    //     0xbfb4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb4cc: mov             fp, SP
    // 0xbfb4d0: AllocStack(0x8)
    //     0xbfb4d0: sub             SP, SP, #8
    // 0xbfb4d4: SetupParameters(RenderBox this /* r1 => r0, fp-0x8 */)
    //     0xbfb4d4: mov             x0, x1
    //     0xbfb4d8: stur            x1, [fp, #-8]
    // 0xbfb4dc: CheckStackOverflow
    //     0xbfb4dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb4e0: cmp             SP, x16
    //     0xbfb4e4: b.ls            #0xbfb554
    // 0xbfb4e8: LoadField: r1 = r0->field_47
    //     0xbfb4e8: ldur            w1, [x0, #0x47]
    // 0xbfb4ec: DecompressPointer r1
    //     0xbfb4ec: add             x1, x1, HEAP, lsl #32
    // 0xbfb4f0: r0 = clear()
    //     0xbfb4f0: bl              #0xbfb634  ; [package:flutter/src/rendering/box.dart] _LayoutCacheStorage::clear
    // 0xbfb4f4: tbnz            w0, #4, #0xbfb53c
    // 0xbfb4f8: ldur            x2, [fp, #-8]
    // 0xbfb4fc: r0 = LoadClassIdInstr(r2)
    //     0xbfb4fc: ldur            x0, [x2, #-1]
    //     0xbfb500: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb504: mov             x1, x2
    // 0xbfb508: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbfb508: mov             x17, #0xfc0
    //     0xbfb50c: movk            x17, #1, lsl #16
    //     0xbfb510: add             lr, x0, x17
    //     0xbfb514: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb518: blr             lr
    // 0xbfb51c: cmp             w0, NULL
    // 0xbfb520: b.eq            #0xbfb53c
    // 0xbfb524: ldur            x1, [fp, #-8]
    // 0xbfb528: r0 = markParentNeedsLayout()
    //     0xbfb528: bl              #0xbfb594  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0xbfb52c: r0 = Null
    //     0xbfb52c: mov             x0, NULL
    // 0xbfb530: LeaveFrame
    //     0xbfb530: mov             SP, fp
    //     0xbfb534: ldp             fp, lr, [SP], #0x10
    // 0xbfb538: ret
    //     0xbfb538: ret             
    // 0xbfb53c: ldur            x1, [fp, #-8]
    // 0xbfb540: r0 = markNeedsLayout()
    //     0xbfb540: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0xbfb544: r0 = Null
    //     0xbfb544: mov             x0, NULL
    // 0xbfb548: LeaveFrame
    //     0xbfb548: mov             SP, fp
    //     0xbfb54c: ldp             fp, lr, [SP], #0x10
    // 0xbfb550: ret
    //     0xbfb550: ret             
    // 0xbfb554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb554: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb558: b               #0xbfb4e8
  }
  [closure] void markNeedsLayout(dynamic) {
    // ** addr: 0xbfb55c, size: 0x38
    // 0xbfb55c: EnterFrame
    //     0xbfb55c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb560: mov             fp, SP
    // 0xbfb564: ldr             x0, [fp, #0x10]
    // 0xbfb568: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbfb568: ldur            w1, [x0, #0x17]
    // 0xbfb56c: DecompressPointer r1
    //     0xbfb56c: add             x1, x1, HEAP, lsl #32
    // 0xbfb570: CheckStackOverflow
    //     0xbfb570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb574: cmp             SP, x16
    //     0xbfb578: b.ls            #0xbfb58c
    // 0xbfb57c: r0 = markNeedsLayout()
    //     0xbfb57c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xbfb580: LeaveFrame
    //     0xbfb580: mov             SP, fp
    //     0xbfb584: ldp             fp, lr, [SP], #0x10
    // 0xbfb588: ret
    //     0xbfb588: ret             
    // 0xbfb58c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb58c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb590: b               #0xbfb57c
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0ec00, size: 0xb4
    // 0xc0ec00: EnterFrame
    //     0xc0ec00: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ec04: mov             fp, SP
    // 0xc0ec08: AllocStack(0x8)
    //     0xc0ec08: sub             SP, SP, #8
    // 0xc0ec0c: SetupParameters(RenderBox this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0ec0c: mov             x0, x2
    //     0xc0ec10: mov             x4, x1
    //     0xc0ec14: mov             x3, x2
    //     0xc0ec18: stur            x2, [fp, #-8]
    // 0xc0ec1c: r2 = Null
    //     0xc0ec1c: mov             x2, NULL
    // 0xc0ec20: r1 = Null
    //     0xc0ec20: mov             x1, NULL
    // 0xc0ec24: r4 = 60
    //     0xc0ec24: mov             x4, #0x3c
    // 0xc0ec28: branchIfSmi(r0, 0xc0ec34)
    //     0xc0ec28: tbz             w0, #0, #0xc0ec34
    // 0xc0ec2c: r4 = LoadClassIdInstr(r0)
    //     0xc0ec2c: ldur            x4, [x0, #-1]
    //     0xc0ec30: ubfx            x4, x4, #0xc, #0x14
    // 0xc0ec34: r17 = -4679
    //     0xc0ec34: mov             x17, #-0x1247
    // 0xc0ec38: add             x4, x4, x17
    // 0xc0ec3c: cmp             x4, #0x128
    // 0xc0ec40: b.ls            #0xc0ec54
    // 0xc0ec44: r8 = RenderObject
    //     0xc0ec44: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0ec48: r3 = Null
    //     0xc0ec48: add             x3, PP, #0x15, lsl #12  ; [pp+0x15610] Null
    //     0xc0ec4c: ldr             x3, [x3, #0x610]
    // 0xc0ec50: r0 = RenderObject()
    //     0xc0ec50: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0ec54: ldur            x0, [fp, #-8]
    // 0xc0ec58: LoadField: r1 = r0->field_7
    //     0xc0ec58: ldur            w1, [x0, #7]
    // 0xc0ec5c: DecompressPointer r1
    //     0xc0ec5c: add             x1, x1, HEAP, lsl #32
    // 0xc0ec60: r2 = LoadClassIdInstr(r1)
    //     0xc0ec60: ldur            x2, [x1, #-1]
    //     0xc0ec64: ubfx            x2, x2, #0xc, #0x14
    // 0xc0ec68: r17 = -4190
    //     0xc0ec68: mov             x17, #-0x105e
    // 0xc0ec6c: add             x16, x2, x17
    // 0xc0ec70: cmp             x16, #0x17
    // 0xc0ec74: b.ls            #0xc0eca4
    // 0xc0ec78: r0 = BoxParentData()
    //     0xc0ec78: bl              #0xc0ecb4  ; AllocateBoxParentDataStub -> BoxParentData (size=0xc)
    // 0xc0ec7c: r1 = Instance_Offset
    //     0xc0ec7c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0ec80: StoreField: r0->field_7 = r1
    //     0xc0ec80: stur            w1, [x0, #7]
    // 0xc0ec84: ldur            x1, [fp, #-8]
    // 0xc0ec88: StoreField: r1->field_7 = r0
    //     0xc0ec88: stur            w0, [x1, #7]
    //     0xc0ec8c: ldurb           w16, [x1, #-1]
    //     0xc0ec90: ldurb           w17, [x0, #-1]
    //     0xc0ec94: and             x16, x17, x16, lsr #2
    //     0xc0ec98: tst             x16, HEAP, lsr #32
    //     0xc0ec9c: b.eq            #0xc0eca4
    //     0xc0eca0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0eca4: r0 = Null
    //     0xc0eca4: mov             x0, NULL
    // 0xc0eca8: LeaveFrame
    //     0xc0eca8: mov             SP, fp
    //     0xc0ecac: ldp             fp, lr, [SP], #0x10
    // 0xc0ecb0: ret
    //     0xc0ecb0: ret             
  }
  get _ constraints(/* No info */) {
    // ** addr: 0xcce9b0, size: 0x78
    // 0xcce9b0: EnterFrame
    //     0xcce9b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcce9b4: mov             fp, SP
    // 0xcce9b8: AllocStack(0x8)
    //     0xcce9b8: sub             SP, SP, #8
    // 0xcce9bc: LoadField: r3 = r1->field_27
    //     0xcce9bc: ldur            w3, [x1, #0x27]
    // 0xcce9c0: DecompressPointer r3
    //     0xcce9c0: add             x3, x3, HEAP, lsl #32
    // 0xcce9c4: stur            x3, [fp, #-8]
    // 0xcce9c8: cmp             w3, NULL
    // 0xcce9cc: b.eq            #0xccea0c
    // 0xcce9d0: mov             x0, x3
    // 0xcce9d4: r2 = Null
    //     0xcce9d4: mov             x2, NULL
    // 0xcce9d8: r1 = Null
    //     0xcce9d8: mov             x1, NULL
    // 0xcce9dc: r4 = LoadClassIdInstr(r0)
    //     0xcce9dc: ldur            x4, [x0, #-1]
    //     0xcce9e0: ubfx            x4, x4, #0xc, #0x14
    // 0xcce9e4: sub             x4, x4, #0xb46
    // 0xcce9e8: cmp             x4, #1
    // 0xcce9ec: b.ls            #0xcce9fc
    // 0xcce9f0: r8 = BoxConstraints
    //     0xcce9f0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xcce9f4: r3 = Null
    //     0xcce9f4: ldr             x3, [PP, #0x4cf0]  ; [pp+0x4cf0] Null
    // 0xcce9f8: r0 = BoxConstraints()
    //     0xcce9f8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xcce9fc: ldur            x0, [fp, #-8]
    // 0xccea00: LeaveFrame
    //     0xccea00: mov             SP, fp
    //     0xccea04: ldp             fp, lr, [SP], #0x10
    // 0xccea08: ret
    //     0xccea08: ret             
    // 0xccea0c: r0 = StateError()
    //     0xccea0c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccea10: mov             x1, x0
    // 0xccea14: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccea14: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccea18: StoreField: r1->field_b = r0
    //     0xccea18: stur            w0, [x1, #0xb]
    // 0xccea1c: mov             x0, x1
    // 0xccea20: r0 = Throw()
    //     0xccea20: bl              #0x13ddb2c  ; ThrowStub
    // 0xccea24: brk             #0
  }
  _ performResize(/* No info */) {
    // ** addr: 0xccfb6c, size: 0xe0
    // 0xccfb6c: EnterFrame
    //     0xccfb6c: stp             fp, lr, [SP, #-0x10]!
    //     0xccfb70: mov             fp, SP
    // 0xccfb74: AllocStack(0x10)
    //     0xccfb74: sub             SP, SP, #0x10
    // 0xccfb78: SetupParameters(RenderBox this /* r1 => r3, fp-0x10 */)
    //     0xccfb78: mov             x3, x1
    //     0xccfb7c: stur            x1, [fp, #-0x10]
    // 0xccfb80: CheckStackOverflow
    //     0xccfb80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccfb84: cmp             SP, x16
    //     0xccfb88: b.ls            #0xccfc44
    // 0xccfb8c: LoadField: r4 = r3->field_27
    //     0xccfb8c: ldur            w4, [x3, #0x27]
    // 0xccfb90: DecompressPointer r4
    //     0xccfb90: add             x4, x4, HEAP, lsl #32
    // 0xccfb94: stur            x4, [fp, #-8]
    // 0xccfb98: cmp             w4, NULL
    // 0xccfb9c: b.eq            #0xccfc28
    // 0xccfba0: mov             x0, x4
    // 0xccfba4: r2 = Null
    //     0xccfba4: mov             x2, NULL
    // 0xccfba8: r1 = Null
    //     0xccfba8: mov             x1, NULL
    // 0xccfbac: r4 = LoadClassIdInstr(r0)
    //     0xccfbac: ldur            x4, [x0, #-1]
    //     0xccfbb0: ubfx            x4, x4, #0xc, #0x14
    // 0xccfbb4: sub             x4, x4, #0xb46
    // 0xccfbb8: cmp             x4, #1
    // 0xccfbbc: b.ls            #0xccfbd0
    // 0xccfbc0: r8 = BoxConstraints
    //     0xccfbc0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xccfbc4: r3 = Null
    //     0xccfbc4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15600] Null
    //     0xccfbc8: ldr             x3, [x3, #0x600]
    // 0xccfbcc: r0 = BoxConstraints()
    //     0xccfbcc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xccfbd0: ldur            x3, [fp, #-0x10]
    // 0xccfbd4: r0 = LoadClassIdInstr(r3)
    //     0xccfbd4: ldur            x0, [x3, #-1]
    //     0xccfbd8: ubfx            x0, x0, #0xc, #0x14
    // 0xccfbdc: mov             x1, x3
    // 0xccfbe0: ldur            x2, [fp, #-8]
    // 0xccfbe4: r0 = GDT[cid_x0 + 0x12603]()
    //     0xccfbe4: mov             x17, #0x2603
    //     0xccfbe8: movk            x17, #1, lsl #16
    //     0xccfbec: add             lr, x0, x17
    //     0xccfbf0: ldr             lr, [x21, lr, lsl #3]
    //     0xccfbf4: blr             lr
    // 0xccfbf8: ldur            x1, [fp, #-0x10]
    // 0xccfbfc: StoreField: r1->field_4b = r0
    //     0xccfbfc: stur            w0, [x1, #0x4b]
    //     0xccfc00: ldurb           w16, [x1, #-1]
    //     0xccfc04: ldurb           w17, [x0, #-1]
    //     0xccfc08: and             x16, x17, x16, lsr #2
    //     0xccfc0c: tst             x16, HEAP, lsr #32
    //     0xccfc10: b.eq            #0xccfc18
    //     0xccfc14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xccfc18: r0 = Null
    //     0xccfc18: mov             x0, NULL
    // 0xccfc1c: LeaveFrame
    //     0xccfc1c: mov             SP, fp
    //     0xccfc20: ldp             fp, lr, [SP], #0x10
    // 0xccfc24: ret
    //     0xccfc24: ret             
    // 0xccfc28: r0 = StateError()
    //     0xccfc28: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccfc2c: mov             x1, x0
    // 0xccfc30: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccfc30: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccfc34: StoreField: r1->field_b = r0
    //     0xccfc34: stur            w0, [x1, #0xb]
    // 0xccfc38: mov             x0, x1
    // 0xccfc3c: r0 = Throw()
    //     0xccfc3c: bl              #0x13ddb2c  ; ThrowStub
    // 0xccfc40: brk             #0
    // 0xccfc44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccfc44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccfc48: b               #0xccfb8c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcdd364, size: 0x58
    // 0xcdd364: EnterFrame
    //     0xcdd364: stp             fp, lr, [SP, #-0x10]!
    //     0xcdd368: mov             fp, SP
    // 0xcdd36c: mov             x0, x3
    // 0xcdd370: mov             x5, x1
    // 0xcdd374: mov             x4, x2
    // 0xcdd378: r2 = Null
    //     0xcdd378: mov             x2, NULL
    // 0xcdd37c: r1 = Null
    //     0xcdd37c: mov             x1, NULL
    // 0xcdd380: r4 = 60
    //     0xcdd380: mov             x4, #0x3c
    // 0xcdd384: branchIfSmi(r0, 0xcdd390)
    //     0xcdd384: tbz             w0, #0, #0xcdd390
    // 0xcdd388: r4 = LoadClassIdInstr(r0)
    //     0xcdd388: ldur            x4, [x0, #-1]
    //     0xcdd38c: ubfx            x4, x4, #0xc, #0x14
    // 0xcdd390: cmp             x4, #0xc65
    // 0xcdd394: b.eq            #0xcdd3ac
    // 0xcdd398: r8 = BoxHitTestEntry
    //     0xcdd398: add             x8, PP, #0x15, lsl #12  ; [pp+0x155d0] Type: BoxHitTestEntry
    //     0xcdd39c: ldr             x8, [x8, #0x5d0]
    // 0xcdd3a0: r3 = Null
    //     0xcdd3a0: add             x3, PP, #0x15, lsl #12  ; [pp+0x155d8] Null
    //     0xcdd3a4: ldr             x3, [x3, #0x5d8]
    // 0xcdd3a8: r0 = DefaultTypeTest()
    //     0xcdd3a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcdd3ac: r0 = Null
    //     0xcdd3ac: mov             x0, NULL
    // 0xcdd3b0: LeaveFrame
    //     0xcdd3b0: mov             SP, fp
    //     0xcdd3b4: ldp             fp, lr, [SP], #0x10
    // 0xcdd3b8: ret
    //     0xcdd3b8: ret             
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0348, size: 0x24
    // 0x10f0348: EnterFrame
    //     0x10f0348: stp             fp, lr, [SP, #-0x10]!
    //     0x10f034c: mov             fp, SP
    // 0x10f0350: ldr             x2, [fp, #0x10]
    // 0x10f0354: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0354: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4430] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0x10f0358: ldr             x1, [x1, #0x430]
    // 0x10f035c: r0 = AllocateClosure()
    //     0x10f035c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0360: LeaveFrame
    //     0x10f0360: mov             SP, fp
    //     0x10f0364: ldp             fp, lr, [SP], #0x10
    // 0x10f0368: ret
    //     0x10f0368: ret             
  }
}

// class id: 8239, size: 0x14, field offset: 0x14
enum _IntrinsicDimension extends _Enum
    implements _CachedLayoutCalculation<X0, X1> {

  _Mint field_8;
  _OneByteString field_10;

  _ memoize(/* No info */) {
    // ** addr: 0x119f504, size: 0x108
    // 0x119f504: EnterFrame
    //     0x119f504: stp             fp, lr, [SP, #-0x10]!
    //     0x119f508: mov             fp, SP
    // 0x119f50c: AllocStack(0x38)
    //     0x119f50c: sub             SP, SP, #0x38
    // 0x119f510: SetupParameters(_IntrinsicDimension this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0x119f510: mov             x0, x5
    //     0x119f514: stur            x1, [fp, #-8]
    //     0x119f518: stur            x2, [fp, #-0x10]
    //     0x119f51c: stur            x3, [fp, #-0x18]
    //     0x119f520: stur            x5, [fp, #-0x20]
    // 0x119f524: CheckStackOverflow
    //     0x119f524: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f528: cmp             SP, x16
    //     0x119f52c: b.ls            #0x119f604
    // 0x119f530: r1 = 2
    //     0x119f530: mov             x1, #2
    // 0x119f534: r0 = AllocateContext()
    //     0x119f534: bl              #0x13de838  ; AllocateContextStub
    // 0x119f538: mov             x3, x0
    // 0x119f53c: ldur            x0, [fp, #-0x18]
    // 0x119f540: stur            x3, [fp, #-0x28]
    // 0x119f544: StoreField: r3->field_f = r0
    //     0x119f544: stur            w0, [x3, #0xf]
    // 0x119f548: ldur            x0, [fp, #-0x20]
    // 0x119f54c: StoreField: r3->field_13 = r0
    //     0x119f54c: stur            w0, [x3, #0x13]
    // 0x119f550: r2 = Null
    //     0x119f550: mov             x2, NULL
    // 0x119f554: r1 = Null
    //     0x119f554: mov             x1, NULL
    // 0x119f558: r8 = (dynamic this, double) => double
    //     0x119f558: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a7f0] FunctionType: (dynamic this, double) => double
    //     0x119f55c: ldr             x8, [x8, #0x7f0]
    // 0x119f560: r3 = Null
    //     0x119f560: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a7f8] Null
    //     0x119f564: ldr             x3, [x3, #0x7f8]
    // 0x119f568: r0 = DefaultTypeTest()
    //     0x119f568: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x119f56c: ldur            x0, [fp, #-0x10]
    // 0x119f570: LoadField: r1 = r0->field_7
    //     0x119f570: ldur            w1, [x0, #7]
    // 0x119f574: DecompressPointer r1
    //     0x119f574: add             x1, x1, HEAP, lsl #32
    // 0x119f578: cmp             w1, NULL
    // 0x119f57c: b.ne            #0x119f5bc
    // 0x119f580: r16 = <(_IntrinsicDimension, double), double>
    //     0x119f580: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a808] TypeArguments: <(_IntrinsicDimension, double), double>
    //     0x119f584: ldr             x16, [x16, #0x808]
    // 0x119f588: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x119f58c: stp             lr, x16, [SP]
    // 0x119f590: r0 = Map._fromLiteral()
    //     0x119f590: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x119f594: mov             x2, x0
    // 0x119f598: ldur            x1, [fp, #-0x10]
    // 0x119f59c: StoreField: r1->field_7 = r0
    //     0x119f59c: stur            w0, [x1, #7]
    //     0x119f5a0: ldurb           w16, [x1, #-1]
    //     0x119f5a4: ldurb           w17, [x0, #-1]
    //     0x119f5a8: and             x16, x17, x16, lsr #2
    //     0x119f5ac: tst             x16, HEAP, lsr #32
    //     0x119f5b0: b.eq            #0x119f5b8
    //     0x119f5b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x119f5b8: mov             x1, x2
    // 0x119f5bc: ldur            x0, [fp, #-0x28]
    // 0x119f5c0: stur            x1, [fp, #-0x10]
    // 0x119f5c4: LoadField: r3 = r0->field_f
    //     0x119f5c4: ldur            w3, [x0, #0xf]
    // 0x119f5c8: DecompressPointer r3
    //     0x119f5c8: add             x3, x3, HEAP, lsl #32
    // 0x119f5cc: ldur            x2, [fp, #-8]
    // 0x119f5d0: r0 = AllocateRecord2()
    //     0x119f5d0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x119f5d4: ldur            x2, [fp, #-0x28]
    // 0x119f5d8: r1 = Function '<anonymous closure>':.
    //     0x119f5d8: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a810] AnonymousClosure: (0x119f60c), in [package:flutter/src/rendering/box.dart] _Baseline::memoize (0x123f314)
    //     0x119f5dc: ldr             x1, [x1, #0x810]
    // 0x119f5e0: stur            x0, [fp, #-8]
    // 0x119f5e4: r0 = AllocateClosure()
    //     0x119f5e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119f5e8: ldur            x1, [fp, #-0x10]
    // 0x119f5ec: ldur            x2, [fp, #-8]
    // 0x119f5f0: mov             x3, x0
    // 0x119f5f4: r0 = putIfAbsent()
    //     0x119f5f4: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x119f5f8: LeaveFrame
    //     0x119f5f8: mov             SP, fp
    //     0x119f5fc: ldp             fp, lr, [SP], #0x10
    // 0x119f600: ret
    //     0x119f600: ret             
    // 0x119f604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f608: b               #0x119f530
  }
  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaf08, size: 0x64
    // 0x11aaf08: EnterFrame
    //     0x11aaf08: stp             fp, lr, [SP, #-0x10]!
    //     0x11aaf0c: mov             fp, SP
    // 0x11aaf10: AllocStack(0x10)
    //     0x11aaf10: sub             SP, SP, #0x10
    // 0x11aaf14: SetupParameters(_IntrinsicDimension this /* r1 => r0, fp-0x8 */)
    //     0x11aaf14: mov             x0, x1
    //     0x11aaf18: stur            x1, [fp, #-8]
    // 0x11aaf1c: CheckStackOverflow
    //     0x11aaf1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaf20: cmp             SP, x16
    //     0x11aaf24: b.ls            #0x11aaf64
    // 0x11aaf28: r1 = Null
    //     0x11aaf28: mov             x1, NULL
    // 0x11aaf2c: r2 = 4
    //     0x11aaf2c: mov             x2, #4
    // 0x11aaf30: r0 = AllocateArray()
    //     0x11aaf30: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaf34: r16 = "_IntrinsicDimension."
    //     0x11aaf34: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a818] "_IntrinsicDimension."
    //     0x11aaf38: ldr             x16, [x16, #0x818]
    // 0x11aaf3c: StoreField: r0->field_f = r16
    //     0x11aaf3c: stur            w16, [x0, #0xf]
    // 0x11aaf40: ldur            x1, [fp, #-8]
    // 0x11aaf44: LoadField: r2 = r1->field_f
    //     0x11aaf44: ldur            w2, [x1, #0xf]
    // 0x11aaf48: DecompressPointer r2
    //     0x11aaf48: add             x2, x2, HEAP, lsl #32
    // 0x11aaf4c: StoreField: r0->field_13 = r2
    //     0x11aaf4c: stur            w2, [x0, #0x13]
    // 0x11aaf50: str             x0, [SP]
    // 0x11aaf54: r0 = _interpolate()
    //     0x11aaf54: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aaf58: LeaveFrame
    //     0x11aaf58: mov             SP, fp
    //     0x11aaf5c: ldp             fp, lr, [SP], #0x10
    // 0x11aaf60: ret
    //     0x11aaf60: ret             
    // 0x11aaf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aaf64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aaf68: b               #0x11aaf28
  }
}
