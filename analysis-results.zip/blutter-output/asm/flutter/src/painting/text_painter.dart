// lib: , url: package:flutter/src/painting/text_painter.dart

// class id: 1049010, size: 0x8
class :: {
}

// class id: 2900, size: 0x8, field offset: 0x8
//   const constructor, 
class _UnspecifiedTextScaler extends TextScaler {
}

// class id: 2901, size: 0x48, field offset: 0x8
class TextPainter extends Object {

  late _LineCaretMetrics _caretMetrics; // offset: 0x44

  get _ size(/* No info */) {
    // ** addr: 0x859c64, size: 0x64
    // 0x859c64: EnterFrame
    //     0x859c64: stp             fp, lr, [SP, #-0x10]!
    //     0x859c68: mov             fp, SP
    // 0x859c6c: AllocStack(0x10)
    //     0x859c6c: sub             SP, SP, #0x10
    // 0x859c70: CheckStackOverflow
    //     0x859c70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859c74: cmp             SP, x16
    //     0x859c78: b.ls            #0x859cbc
    // 0x859c7c: LoadField: r0 = r1->field_7
    //     0x859c7c: ldur            w0, [x1, #7]
    // 0x859c80: DecompressPointer r0
    //     0x859c80: add             x0, x0, HEAP, lsl #32
    // 0x859c84: cmp             w0, NULL
    // 0x859c88: b.eq            #0x859cc4
    // 0x859c8c: LoadField: d0 = r0->field_13
    //     0x859c8c: ldur            d0, [x0, #0x13]
    // 0x859c90: stur            d0, [fp, #-8]
    // 0x859c94: r0 = height()
    //     0x859c94: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x859c98: stur            d0, [fp, #-0x10]
    // 0x859c9c: r0 = Size()
    //     0x859c9c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x859ca0: ldur            d0, [fp, #-8]
    // 0x859ca4: StoreField: r0->field_7 = d0
    //     0x859ca4: stur            d0, [x0, #7]
    // 0x859ca8: ldur            d0, [fp, #-0x10]
    // 0x859cac: StoreField: r0->field_f = d0
    //     0x859cac: stur            d0, [x0, #0xf]
    // 0x859cb0: LeaveFrame
    //     0x859cb0: mov             SP, fp
    //     0x859cb4: ldp             fp, lr, [SP], #0x10
    // 0x859cb8: ret
    //     0x859cb8: ret             
    // 0x859cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859cbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859cc0: b               #0x859c7c
    // 0x859cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859cc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ height(/* No info */) {
    // ** addr: 0x859ce8, size: 0xa4
    // 0x859ce8: EnterFrame
    //     0x859ce8: stp             fp, lr, [SP, #-0x10]!
    //     0x859cec: mov             fp, SP
    // 0x859cf0: AllocStack(0x18)
    //     0x859cf0: sub             SP, SP, #0x18
    // 0x859cf4: CheckStackOverflow
    //     0x859cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859cf8: cmp             SP, x16
    //     0x859cfc: b.ls            #0x859d7c
    // 0x859d00: LoadField: r0 = r1->field_7
    //     0x859d00: ldur            w0, [x1, #7]
    // 0x859d04: DecompressPointer r0
    //     0x859d04: add             x0, x0, HEAP, lsl #32
    // 0x859d08: cmp             w0, NULL
    // 0x859d0c: b.eq            #0x859d84
    // 0x859d10: LoadField: r1 = r0->field_7
    //     0x859d10: ldur            w1, [x0, #7]
    // 0x859d14: DecompressPointer r1
    //     0x859d14: add             x1, x1, HEAP, lsl #32
    // 0x859d18: LoadField: r0 = r1->field_f
    //     0x859d18: ldur            w0, [x1, #0xf]
    // 0x859d1c: DecompressPointer r0
    //     0x859d1c: add             x0, x0, HEAP, lsl #32
    // 0x859d20: stur            x0, [fp, #-0x10]
    // 0x859d24: LoadField: r1 = r0->field_7
    //     0x859d24: ldur            w1, [x0, #7]
    // 0x859d28: DecompressPointer r1
    //     0x859d28: add             x1, x1, HEAP, lsl #32
    // 0x859d2c: cmp             w1, NULL
    // 0x859d30: b.eq            #0x859d88
    // 0x859d34: LoadField: r2 = r1->field_7
    //     0x859d34: ldur            x2, [x1, #7]
    // 0x859d38: ldr             x1, [x2]
    // 0x859d3c: cbz             x1, #0x859d6c
    // 0x859d40: mov             x2, x1
    // 0x859d44: stur            x2, [fp, #-8]
    // 0x859d48: r1 = <Never>
    //     0x859d48: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x859d4c: r0 = Pointer()
    //     0x859d4c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x859d50: mov             x1, x0
    // 0x859d54: ldur            x0, [fp, #-8]
    // 0x859d58: StoreField: r1->field_7 = r0
    //     0x859d58: stur            x0, [x1, #7]
    // 0x859d5c: r0 = _height$Getter$FfiNative()
    //     0x859d5c: bl              #0x859d8c  ; [dart:ui] _NativeParagraph::_height$Getter$FfiNative
    // 0x859d60: LeaveFrame
    //     0x859d60: mov             SP, fp
    //     0x859d64: ldp             fp, lr, [SP], #0x10
    // 0x859d68: ret
    //     0x859d68: ret             
    // 0x859d6c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x859d6c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x859d70: str             x16, [SP]
    // 0x859d74: r0 = _throwNew()
    //     0x859d74: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x859d78: brk             #0
    // 0x859d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859d80: b               #0x859d00
    // 0x859d84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859d84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859d88: r0 = NullErrorSharedWithoutFPURegs()
    //     0x859d88: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ preferredLineHeight(/* No info */) {
    // ** addr: 0x859e1c, size: 0x84
    // 0x859e1c: EnterFrame
    //     0x859e1c: stp             fp, lr, [SP, #-0x10]!
    //     0x859e20: mov             fp, SP
    // 0x859e24: AllocStack(0x18)
    //     0x859e24: sub             SP, SP, #0x18
    // 0x859e28: CheckStackOverflow
    //     0x859e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859e2c: cmp             SP, x16
    //     0x859e30: b.ls            #0x859e94
    // 0x859e34: r0 = _getOrCreateLayoutTemplate()
    //     0x859e34: bl              #0x859ea0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getOrCreateLayoutTemplate
    // 0x859e38: stur            x0, [fp, #-0x10]
    // 0x859e3c: LoadField: r1 = r0->field_7
    //     0x859e3c: ldur            w1, [x0, #7]
    // 0x859e40: DecompressPointer r1
    //     0x859e40: add             x1, x1, HEAP, lsl #32
    // 0x859e44: cmp             w1, NULL
    // 0x859e48: b.eq            #0x859e9c
    // 0x859e4c: LoadField: r2 = r1->field_7
    //     0x859e4c: ldur            x2, [x1, #7]
    // 0x859e50: ldr             x1, [x2]
    // 0x859e54: cbz             x1, #0x859e84
    // 0x859e58: mov             x2, x1
    // 0x859e5c: stur            x2, [fp, #-8]
    // 0x859e60: r1 = <Never>
    //     0x859e60: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x859e64: r0 = Pointer()
    //     0x859e64: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x859e68: mov             x1, x0
    // 0x859e6c: ldur            x0, [fp, #-8]
    // 0x859e70: StoreField: r1->field_7 = r0
    //     0x859e70: stur            x0, [x1, #7]
    // 0x859e74: r0 = _height$Getter$FfiNative()
    //     0x859e74: bl              #0x859d8c  ; [dart:ui] _NativeParagraph::_height$Getter$FfiNative
    // 0x859e78: LeaveFrame
    //     0x859e78: mov             SP, fp
    //     0x859e7c: ldp             fp, lr, [SP], #0x10
    // 0x859e80: ret
    //     0x859e80: ret             
    // 0x859e84: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x859e84: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x859e88: str             x16, [SP]
    // 0x859e8c: r0 = _throwNew()
    //     0x859e8c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x859e90: brk             #0
    // 0x859e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859e94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859e98: b               #0x859e34
    // 0x859e9c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x859e9c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _getOrCreateLayoutTemplate(/* No info */) {
    // ** addr: 0x859ea0, size: 0x7c
    // 0x859ea0: EnterFrame
    //     0x859ea0: stp             fp, lr, [SP, #-0x10]!
    //     0x859ea4: mov             fp, SP
    // 0x859ea8: AllocStack(0x8)
    //     0x859ea8: sub             SP, SP, #8
    // 0x859eac: SetupParameters(TextPainter this /* r1 => r0, fp-0x8 */)
    //     0x859eac: mov             x0, x1
    //     0x859eb0: stur            x1, [fp, #-8]
    // 0x859eb4: CheckStackOverflow
    //     0x859eb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859eb8: cmp             SP, x16
    //     0x859ebc: b.ls            #0x859f14
    // 0x859ec0: LoadField: r1 = r0->field_3f
    //     0x859ec0: ldur            w1, [x0, #0x3f]
    // 0x859ec4: DecompressPointer r1
    //     0x859ec4: add             x1, x1, HEAP, lsl #32
    // 0x859ec8: cmp             w1, NULL
    // 0x859ecc: b.ne            #0x859f04
    // 0x859ed0: mov             x1, x0
    // 0x859ed4: r0 = _createLayoutTemplate()
    //     0x859ed4: bl              #0x859f1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createLayoutTemplate
    // 0x859ed8: mov             x1, x0
    // 0x859edc: ldur            x2, [fp, #-8]
    // 0x859ee0: StoreField: r2->field_3f = r0
    //     0x859ee0: stur            w0, [x2, #0x3f]
    //     0x859ee4: ldurb           w16, [x2, #-1]
    //     0x859ee8: ldurb           w17, [x0, #-1]
    //     0x859eec: and             x16, x17, x16, lsr #2
    //     0x859ef0: tst             x16, HEAP, lsr #32
    //     0x859ef4: b.eq            #0x859efc
    //     0x859ef8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x859efc: mov             x0, x1
    // 0x859f00: b               #0x859f08
    // 0x859f04: mov             x0, x1
    // 0x859f08: LeaveFrame
    //     0x859f08: mov             SP, fp
    //     0x859f0c: ldp             fp, lr, [SP], #0x10
    // 0x859f10: ret
    //     0x859f10: ret             
    // 0x859f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859f14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859f18: b               #0x859ec0
  }
  _ _createLayoutTemplate(/* No info */) {
    // ** addr: 0x859f1c, size: 0x13c
    // 0x859f1c: EnterFrame
    //     0x859f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x859f20: mov             fp, SP
    // 0x859f24: AllocStack(0x28)
    //     0x859f24: sub             SP, SP, #0x28
    // 0x859f28: SetupParameters(TextPainter this /* r1 => r0, fp-0x8 */)
    //     0x859f28: mov             x0, x1
    //     0x859f2c: stur            x1, [fp, #-8]
    // 0x859f30: CheckStackOverflow
    //     0x859f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859f34: cmp             SP, x16
    //     0x859f38: b.ls            #0x85a04c
    // 0x859f3c: r16 = Instance_TextAlign
    //     0x859f3c: ldr             x16, [PP, #0x49e0]  ; [pp+0x49e0] Obj!TextAlign@12c74e1
    // 0x859f40: str             x16, [SP]
    // 0x859f44: mov             x1, x0
    // 0x859f48: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x859f48: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x859f4c: r0 = _createParagraphStyle()
    //     0x859f4c: bl              #0x85cd68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraphStyle
    // 0x859f50: stur            x0, [fp, #-0x10]
    // 0x859f54: r0 = _NativeParagraphBuilder()
    //     0x859f54: bl              #0x85cd5c  ; Allocate_NativeParagraphBuilderStub -> _NativeParagraphBuilder (size=0x1c)
    // 0x859f58: mov             x1, x0
    // 0x859f5c: ldur            x2, [fp, #-0x10]
    // 0x859f60: stur            x0, [fp, #-0x10]
    // 0x859f64: r0 = _NativeParagraphBuilder()
    //     0x859f64: bl              #0x85c8a0  ; [dart:ui] _NativeParagraphBuilder::_NativeParagraphBuilder
    // 0x859f68: ldur            x0, [fp, #-8]
    // 0x859f6c: LoadField: r1 = r0->field_f
    //     0x859f6c: ldur            w1, [x0, #0xf]
    // 0x859f70: DecompressPointer r1
    //     0x859f70: add             x1, x1, HEAP, lsl #32
    // 0x859f74: cmp             w1, NULL
    // 0x859f78: b.ne            #0x859f84
    // 0x859f7c: r2 = Null
    //     0x859f7c: mov             x2, NULL
    // 0x859f80: b               #0x859fb8
    // 0x859f84: LoadField: r2 = r1->field_7
    //     0x859f84: ldur            w2, [x1, #7]
    // 0x859f88: DecompressPointer r2
    //     0x859f88: add             x2, x2, HEAP, lsl #32
    // 0x859f8c: cmp             w2, NULL
    // 0x859f90: b.ne            #0x859f9c
    // 0x859f94: r0 = Null
    //     0x859f94: mov             x0, NULL
    // 0x859f98: b               #0x859fb4
    // 0x859f9c: LoadField: r1 = r0->field_1f
    //     0x859f9c: ldur            w1, [x0, #0x1f]
    // 0x859fa0: DecompressPointer r1
    //     0x859fa0: add             x1, x1, HEAP, lsl #32
    // 0x859fa4: mov             x16, x1
    // 0x859fa8: mov             x1, x2
    // 0x859fac: mov             x2, x16
    // 0x859fb0: r0 = getTextStyle()
    //     0x859fb0: bl              #0x85b480  ; [package:flutter/src/painting/text_style.dart] TextStyle::getTextStyle
    // 0x859fb4: mov             x2, x0
    // 0x859fb8: cmp             w2, NULL
    // 0x859fbc: b.eq            #0x859fc8
    // 0x859fc0: ldur            x1, [fp, #-0x10]
    // 0x859fc4: r0 = pushStyle()
    //     0x859fc4: bl              #0x85a5cc  ; [dart:ui] _NativeParagraphBuilder::pushStyle
    // 0x859fc8: ldur            x1, [fp, #-0x10]
    // 0x859fcc: r2 = " "
    //     0x859fcc: ldr             x2, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x859fd0: r0 = addText()
    //     0x859fd0: bl              #0x85a338  ; [dart:ui] _NativeParagraphBuilder::addText
    // 0x859fd4: ldur            x1, [fp, #-0x10]
    // 0x859fd8: r0 = build()
    //     0x859fd8: bl              #0x85a0e8  ; [dart:ui] _NativeParagraphBuilder::build
    // 0x859fdc: mov             x2, x0
    // 0x859fe0: r0 = Instance_ParagraphConstraints
    //     0x859fe0: ldr             x0, [PP, #0x49e8]  ; [pp+0x49e8] Obj!ParagraphConstraints@12a0461
    // 0x859fe4: stur            x2, [fp, #-8]
    // 0x859fe8: LoadField: d0 = r0->field_7
    //     0x859fe8: ldur            d0, [x0, #7]
    // 0x859fec: stur            d0, [fp, #-0x20]
    // 0x859ff0: LoadField: r0 = r2->field_7
    //     0x859ff0: ldur            w0, [x2, #7]
    // 0x859ff4: DecompressPointer r0
    //     0x859ff4: add             x0, x0, HEAP, lsl #32
    // 0x859ff8: cmp             w0, NULL
    // 0x859ffc: b.eq            #0x85a054
    // 0x85a000: LoadField: r1 = r0->field_7
    //     0x85a000: ldur            x1, [x0, #7]
    // 0x85a004: ldr             x0, [x1]
    // 0x85a008: cbz             x0, #0x85a03c
    // 0x85a00c: stur            x0, [fp, #-0x18]
    // 0x85a010: r1 = <Never>
    //     0x85a010: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85a014: r0 = Pointer()
    //     0x85a014: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85a018: mov             x1, x0
    // 0x85a01c: ldur            x0, [fp, #-0x18]
    // 0x85a020: StoreField: r1->field_7 = r0
    //     0x85a020: stur            x0, [x1, #7]
    // 0x85a024: ldur            d0, [fp, #-0x20]
    // 0x85a028: r0 = __layout$Method$FfiNative()
    //     0x85a028: bl              #0x85a058  ; [dart:ui] _NativeParagraph::__layout$Method$FfiNative
    // 0x85a02c: ldur            x0, [fp, #-8]
    // 0x85a030: LeaveFrame
    //     0x85a030: mov             SP, fp
    //     0x85a034: ldp             fp, lr, [SP], #0x10
    // 0x85a038: ret
    //     0x85a038: ret             
    // 0x85a03c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85a03c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85a040: str             x16, [SP]
    // 0x85a044: r0 = _throwNew()
    //     0x85a044: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85a048: brk             #0
    // 0x85a04c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85a04c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85a050: b               #0x859f3c
    // 0x85a054: r0 = NullErrorSharedWithFPURegs()
    //     0x85a054: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _createParagraphStyle(/* No info */) {
    // ** addr: 0x85cd68, size: 0xe0
    // 0x85cd68: EnterFrame
    //     0x85cd68: stp             fp, lr, [SP, #-0x10]!
    //     0x85cd6c: mov             fp, SP
    // 0x85cd70: AllocStack(0x10)
    //     0x85cd70: sub             SP, SP, #0x10
    // 0x85cd74: SetupParameters([dynamic _ = Null /* r0 */])
    //     0x85cd74: ldur            w0, [x4, #0x13]
    //     0x85cd78: sub             x2, x0, #2
    //     0x85cd7c: cmp             w2, #2
    //     0x85cd80: b.lt            #0x85cd90
    //     0x85cd84: add             x0, fp, w2, sxtw #2
    //     0x85cd88: ldr             x0, [x0, #8]
    //     0x85cd8c: b               #0x85cd94
    //     0x85cd90: mov             x0, NULL
    // 0x85cd94: CheckStackOverflow
    //     0x85cd94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85cd98: cmp             SP, x16
    //     0x85cd9c: b.ls            #0x85ce40
    // 0x85cda0: LoadField: r2 = r1->field_f
    //     0x85cda0: ldur            w2, [x1, #0xf]
    // 0x85cda4: DecompressPointer r2
    //     0x85cda4: add             x2, x2, HEAP, lsl #32
    // 0x85cda8: cmp             w2, NULL
    // 0x85cdac: b.ne            #0x85cdb8
    // 0x85cdb0: r2 = Null
    //     0x85cdb0: mov             x2, NULL
    // 0x85cdb4: b               #0x85cdc4
    // 0x85cdb8: LoadField: r3 = r2->field_7
    //     0x85cdb8: ldur            w3, [x2, #7]
    // 0x85cdbc: DecompressPointer r3
    //     0x85cdbc: add             x3, x3, HEAP, lsl #32
    // 0x85cdc0: mov             x2, x3
    // 0x85cdc4: cmp             w2, NULL
    // 0x85cdc8: b.ne            #0x85cdd0
    // 0x85cdcc: r2 = Instance_TextStyle
    //     0x85cdcc: ldr             x2, [PP, #0x4b38]  ; [pp+0x4b38] Obj!TextStyle@12ad3d1
    // 0x85cdd0: cmp             w0, NULL
    // 0x85cdd4: b.ne            #0x85cde8
    // 0x85cdd8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x85cdd8: ldur            w0, [x1, #0x17]
    // 0x85cddc: DecompressPointer r0
    //     0x85cddc: add             x0, x0, HEAP, lsl #32
    // 0x85cde0: mov             x7, x0
    // 0x85cde4: b               #0x85cdec
    // 0x85cde8: mov             x7, x0
    // 0x85cdec: LoadField: r0 = r1->field_1b
    //     0x85cdec: ldur            w0, [x1, #0x1b]
    // 0x85cdf0: DecompressPointer r0
    //     0x85cdf0: add             x0, x0, HEAP, lsl #32
    // 0x85cdf4: LoadField: r3 = r1->field_1f
    //     0x85cdf4: ldur            w3, [x1, #0x1f]
    // 0x85cdf8: DecompressPointer r3
    //     0x85cdf8: add             x3, x3, HEAP, lsl #32
    // 0x85cdfc: LoadField: r5 = r1->field_2b
    //     0x85cdfc: ldur            w5, [x1, #0x2b]
    // 0x85ce00: DecompressPointer r5
    //     0x85ce00: add             x5, x5, HEAP, lsl #32
    // 0x85ce04: LoadField: r4 = r1->field_23
    //     0x85ce04: ldur            w4, [x1, #0x23]
    // 0x85ce08: DecompressPointer r4
    //     0x85ce08: add             x4, x4, HEAP, lsl #32
    // 0x85ce0c: LoadField: r6 = r1->field_27
    //     0x85ce0c: ldur            w6, [x1, #0x27]
    // 0x85ce10: DecompressPointer r6
    //     0x85ce10: add             x6, x6, HEAP, lsl #32
    // 0x85ce14: LoadField: r8 = r1->field_2f
    //     0x85ce14: ldur            w8, [x1, #0x2f]
    // 0x85ce18: DecompressPointer r8
    //     0x85ce18: add             x8, x8, HEAP, lsl #32
    // 0x85ce1c: stp             x3, x0, [SP]
    // 0x85ce20: mov             x1, x2
    // 0x85ce24: mov             x2, x4
    // 0x85ce28: mov             x3, x6
    // 0x85ce2c: mov             x6, x8
    // 0x85ce30: r0 = getParagraphStyle()
    //     0x85ce30: bl              #0x85ce48  ; [package:flutter/src/painting/text_style.dart] TextStyle::getParagraphStyle
    // 0x85ce34: LeaveFrame
    //     0x85ce34: mov             SP, fp
    //     0x85ce38: ldp             fp, lr, [SP], #0x10
    // 0x85ce3c: ret
    //     0x85ce3c: ret             
    // 0x85ce40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85ce40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85ce44: b               #0x85cda0
  }
  _ getOffsetForCaret(/* No info */) {
    // ** addr: 0x85dc3c, size: 0x1e0
    // 0x85dc3c: EnterFrame
    //     0x85dc3c: stp             fp, lr, [SP, #-0x10]!
    //     0x85dc40: mov             fp, SP
    // 0x85dc44: AllocStack(0x30)
    //     0x85dc44: sub             SP, SP, #0x30
    // 0x85dc48: SetupParameters(TextPainter this /* r1 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x85dc48: mov             x0, x1
    //     0x85dc4c: stur            x1, [fp, #-0x10]
    //     0x85dc50: stur            x3, [fp, #-0x18]
    // 0x85dc54: CheckStackOverflow
    //     0x85dc54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85dc58: cmp             SP, x16
    //     0x85dc5c: b.ls            #0x85de0c
    // 0x85dc60: LoadField: r4 = r0->field_7
    //     0x85dc60: ldur            w4, [x0, #7]
    // 0x85dc64: DecompressPointer r4
    //     0x85dc64: add             x4, x4, HEAP, lsl #32
    // 0x85dc68: stur            x4, [fp, #-8]
    // 0x85dc6c: cmp             w4, NULL
    // 0x85dc70: b.eq            #0x85de14
    // 0x85dc74: mov             x1, x0
    // 0x85dc78: r0 = _computeCaretMetrics()
    //     0x85dc78: bl              #0x85e254  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0x85dc7c: cmp             w0, NULL
    // 0x85dc80: b.ne            #0x85dcec
    // 0x85dc84: ldur            x0, [fp, #-0x10]
    // 0x85dc88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85dc88: ldur            w1, [x0, #0x17]
    // 0x85dc8c: DecompressPointer r1
    //     0x85dc8c: add             x1, x1, HEAP, lsl #32
    // 0x85dc90: LoadField: r2 = r0->field_1b
    //     0x85dc90: ldur            w2, [x0, #0x1b]
    // 0x85dc94: DecompressPointer r2
    //     0x85dc94: add             x2, x2, HEAP, lsl #32
    // 0x85dc98: cmp             w2, NULL
    // 0x85dc9c: b.eq            #0x85de18
    // 0x85dca0: r0 = _computePaintOffsetFraction()
    //     0x85dca0: bl              #0x85e020  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computePaintOffsetFraction
    // 0x85dca4: mov             v1.16b, v0.16b
    // 0x85dca8: d0 = 0.000000
    //     0x85dca8: eor             v0.16b, v0.16b, v0.16b
    // 0x85dcac: fcmp            d1, d0
    // 0x85dcb0: b.ne            #0x85dcbc
    // 0x85dcb4: d0 = 0.000000
    //     0x85dcb4: eor             v0.16b, v0.16b, v0.16b
    // 0x85dcb8: b               #0x85dccc
    // 0x85dcbc: ldur            x1, [fp, #-8]
    // 0x85dcc0: LoadField: d0 = r1->field_13
    //     0x85dcc0: ldur            d0, [x1, #0x13]
    // 0x85dcc4: fmul            d2, d1, d0
    // 0x85dcc8: mov             v0.16b, v2.16b
    // 0x85dccc: stur            d0, [fp, #-0x20]
    // 0x85dcd0: r0 = Offset()
    //     0x85dcd0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85dcd4: ldur            d0, [fp, #-0x20]
    // 0x85dcd8: StoreField: r0->field_7 = d0
    //     0x85dcd8: stur            d0, [x0, #7]
    // 0x85dcdc: StoreField: r0->field_f = rZR
    //     0x85dcdc: stur            xzr, [x0, #0xf]
    // 0x85dce0: LeaveFrame
    //     0x85dce0: mov             SP, fp
    //     0x85dce4: ldp             fp, lr, [SP], #0x10
    // 0x85dce8: ret
    //     0x85dce8: ret             
    // 0x85dcec: ldur            x1, [fp, #-8]
    // 0x85dcf0: d0 = 0.000000
    //     0x85dcf0: eor             v0.16b, v0.16b, v0.16b
    // 0x85dcf4: LoadField: r2 = r0->field_b
    //     0x85dcf4: ldur            w2, [x0, #0xb]
    // 0x85dcf8: DecompressPointer r2
    //     0x85dcf8: add             x2, x2, HEAP, lsl #32
    // 0x85dcfc: r16 = Instance_TextDirection
    //     0x85dcfc: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0x85dd00: cmp             w2, w16
    // 0x85dd04: b.ne            #0x85dd18
    // 0x85dd08: LoadField: r2 = r0->field_7
    //     0x85dd08: ldur            w2, [x0, #7]
    // 0x85dd0c: DecompressPointer r2
    //     0x85dd0c: add             x2, x2, HEAP, lsl #32
    // 0x85dd10: mov             x0, x1
    // 0x85dd14: b               #0x85dd78
    // 0x85dd18: r16 = Instance_TextDirection
    //     0x85dd18: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0x85dd1c: cmp             w2, w16
    // 0x85dd20: b.ne            #0x85dd70
    // 0x85dd24: ldur            x2, [fp, #-0x18]
    // 0x85dd28: LoadField: r3 = r0->field_7
    //     0x85dd28: ldur            w3, [x0, #7]
    // 0x85dd2c: DecompressPointer r3
    //     0x85dd2c: add             x3, x3, HEAP, lsl #32
    // 0x85dd30: LoadField: d1 = r3->field_7
    //     0x85dd30: ldur            d1, [x3, #7]
    // 0x85dd34: ArrayLoad: d2 = r2[0]  ; List_8
    //     0x85dd34: ldur            d2, [x2, #0x17]
    // 0x85dd38: LoadField: d3 = r2->field_7
    //     0x85dd38: ldur            d3, [x2, #7]
    // 0x85dd3c: fsub            d4, d2, d3
    // 0x85dd40: fsub            d2, d1, d4
    // 0x85dd44: stur            d2, [fp, #-0x28]
    // 0x85dd48: LoadField: d1 = r3->field_f
    //     0x85dd48: ldur            d1, [x3, #0xf]
    // 0x85dd4c: stur            d1, [fp, #-0x20]
    // 0x85dd50: r0 = Offset()
    //     0x85dd50: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85dd54: ldur            d0, [fp, #-0x28]
    // 0x85dd58: StoreField: r0->field_7 = d0
    //     0x85dd58: stur            d0, [x0, #7]
    // 0x85dd5c: ldur            d0, [fp, #-0x20]
    // 0x85dd60: StoreField: r0->field_f = d0
    //     0x85dd60: stur            d0, [x0, #0xf]
    // 0x85dd64: mov             x2, x0
    // 0x85dd68: ldur            x0, [fp, #-8]
    // 0x85dd6c: b               #0x85dd78
    // 0x85dd70: ldur            x0, [fp, #-8]
    // 0x85dd74: r2 = Null
    //     0x85dd74: mov             x2, NULL
    // 0x85dd78: stur            x2, [fp, #-0x10]
    // 0x85dd7c: LoadField: d0 = r2->field_7
    //     0x85dd7c: ldur            d0, [x2, #7]
    // 0x85dd80: mov             x1, x0
    // 0x85dd84: stur            d0, [fp, #-0x20]
    // 0x85dd88: r0 = paintOffset()
    //     0x85dd88: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x85dd8c: LoadField: d0 = r0->field_7
    //     0x85dd8c: ldur            d0, [x0, #7]
    // 0x85dd90: ldur            d1, [fp, #-0x20]
    // 0x85dd94: fadd            d2, d1, d0
    // 0x85dd98: ldur            x1, [fp, #-8]
    // 0x85dd9c: LoadField: d0 = r1->field_13
    //     0x85dd9c: ldur            d0, [x1, #0x13]
    // 0x85dda0: d1 = 0.000000
    //     0x85dda0: eor             v1.16b, v1.16b, v1.16b
    // 0x85dda4: fcmp            d1, d2
    // 0x85dda8: b.le            #0x85ddb4
    // 0x85ddac: d0 = 0.000000
    //     0x85ddac: eor             v0.16b, v0.16b, v0.16b
    // 0x85ddb0: b               #0x85ddc8
    // 0x85ddb4: fcmp            d2, d0
    // 0x85ddb8: b.gt            #0x85ddc8
    // 0x85ddbc: fcmp            d2, d2
    // 0x85ddc0: b.vs            #0x85ddc8
    // 0x85ddc4: mov             v0.16b, v2.16b
    // 0x85ddc8: ldur            x0, [fp, #-0x10]
    // 0x85ddcc: stur            d0, [fp, #-0x28]
    // 0x85ddd0: LoadField: d1 = r0->field_f
    //     0x85ddd0: ldur            d1, [x0, #0xf]
    // 0x85ddd4: stur            d1, [fp, #-0x20]
    // 0x85ddd8: r0 = paintOffset()
    //     0x85ddd8: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x85dddc: LoadField: d0 = r0->field_f
    //     0x85dddc: ldur            d0, [x0, #0xf]
    // 0x85dde0: ldur            d1, [fp, #-0x20]
    // 0x85dde4: fadd            d2, d1, d0
    // 0x85dde8: stur            d2, [fp, #-0x30]
    // 0x85ddec: r0 = Offset()
    //     0x85ddec: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85ddf0: ldur            d0, [fp, #-0x28]
    // 0x85ddf4: StoreField: r0->field_7 = d0
    //     0x85ddf4: stur            d0, [x0, #7]
    // 0x85ddf8: ldur            d0, [fp, #-0x30]
    // 0x85ddfc: StoreField: r0->field_f = d0
    //     0x85ddfc: stur            d0, [x0, #0xf]
    // 0x85de00: LeaveFrame
    //     0x85de00: mov             SP, fp
    //     0x85de04: ldp             fp, lr, [SP], #0x10
    // 0x85de08: ret
    //     0x85de08: ret             
    // 0x85de0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85de0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85de10: b               #0x85dc60
    // 0x85de14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85de14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85de18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85de18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _computePaintOffsetFraction(/* No info */) {
    // ** addr: 0x85e020, size: 0x234
    // 0x85e020: r16 = Instance_TextAlign
    //     0x85e020: ldr             x16, [PP, #0x49e0]  ; [pp+0x49e0] Obj!TextAlign@12c74e1
    // 0x85e024: cmp             w1, w16
    // 0x85e028: b.ne            #0x85e034
    // 0x85e02c: r0 = 0.000000
    //     0x85e02c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x85e030: b               #0x85e24c
    // 0x85e034: r16 = Instance_TextAlign
    //     0x85e034: ldr             x16, [PP, #0x4c58]  ; [pp+0x4c58] Obj!TextAlign@12c7581
    // 0x85e038: cmp             w1, w16
    // 0x85e03c: b.ne            #0x85e048
    // 0x85e040: r0 = 1.000000
    //     0x85e040: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x85e044: b               #0x85e24c
    // 0x85e048: r16 = Instance_TextAlign
    //     0x85e048: ldr             x16, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0x85e04c: cmp             w1, w16
    // 0x85e050: b.ne            #0x85e05c
    // 0x85e054: r0 = 0.500000
    //     0x85e054: ldr             x0, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0x85e058: b               #0x85e24c
    // 0x85e05c: r16 = Instance_TextAlign
    //     0x85e05c: ldr             x16, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0x85e060: cmp             w1, w16
    // 0x85e064: r16 = true
    //     0x85e064: add             x16, NULL, #0x20  ; true
    // 0x85e068: r17 = false
    //     0x85e068: add             x17, NULL, #0x30  ; false
    // 0x85e06c: csel            x0, x16, x17, eq
    // 0x85e070: tbnz            w0, #4, #0x85e080
    // 0x85e074: r5 = Null
    //     0x85e074: mov             x5, NULL
    // 0x85e078: r4 = false
    //     0x85e078: add             x4, NULL, #0x30  ; false
    // 0x85e07c: b               #0x85e0a0
    // 0x85e080: r16 = Instance_TextAlign
    //     0x85e080: ldr             x16, [PP, #0x4c80]  ; [pp+0x4c80] Obj!TextAlign@12c7521
    // 0x85e084: cmp             w1, w16
    // 0x85e088: r16 = true
    //     0x85e088: add             x16, NULL, #0x20  ; true
    // 0x85e08c: r17 = false
    //     0x85e08c: add             x17, NULL, #0x30  ; false
    // 0x85e090: csel            x3, x16, x17, eq
    // 0x85e094: tbnz            w3, #4, #0x85e0e8
    // 0x85e098: mov             x5, x3
    // 0x85e09c: r4 = true
    //     0x85e09c: add             x4, NULL, #0x20  ; true
    // 0x85e0a0: r16 = Instance_TextDirection
    //     0x85e0a0: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0x85e0a4: cmp             w2, w16
    // 0x85e0a8: r16 = true
    //     0x85e0a8: add             x16, NULL, #0x20  ; true
    // 0x85e0ac: r17 = false
    //     0x85e0ac: add             x17, NULL, #0x30  ; false
    // 0x85e0b0: csel            x6, x16, x17, eq
    // 0x85e0b4: tbnz            w6, #4, #0x85e0c0
    // 0x85e0b8: r0 = 0.000000
    //     0x85e0b8: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x85e0bc: b               #0x85e24c
    // 0x85e0c0: mov             x8, x2
    // 0x85e0c4: mov             x16, x4
    // 0x85e0c8: mov             x4, x5
    // 0x85e0cc: mov             x5, x16
    // 0x85e0d0: mov             x16, x6
    // 0x85e0d4: mov             x6, x4
    // 0x85e0d8: mov             x4, x16
    // 0x85e0dc: r7 = true
    //     0x85e0dc: add             x7, NULL, #0x20  ; true
    // 0x85e0e0: r3 = true
    //     0x85e0e0: add             x3, NULL, #0x20  ; true
    // 0x85e0e4: b               #0x85e100
    // 0x85e0e8: mov             x6, x3
    // 0x85e0ec: r8 = Null
    //     0x85e0ec: mov             x8, NULL
    // 0x85e0f0: r7 = false
    //     0x85e0f0: add             x7, NULL, #0x30  ; false
    // 0x85e0f4: r5 = true
    //     0x85e0f4: add             x5, NULL, #0x20  ; true
    // 0x85e0f8: r4 = Null
    //     0x85e0f8: mov             x4, NULL
    // 0x85e0fc: r3 = false
    //     0x85e0fc: add             x3, NULL, #0x30  ; false
    // 0x85e100: tbz             w0, #4, #0x85e130
    // 0x85e104: tbnz            w5, #4, #0x85e110
    // 0x85e108: mov             x0, x6
    // 0x85e10c: b               #0x85e124
    // 0x85e110: r16 = Instance_TextAlign
    //     0x85e110: ldr             x16, [PP, #0x4c80]  ; [pp+0x4c80] Obj!TextAlign@12c7521
    // 0x85e114: cmp             w1, w16
    // 0x85e118: r16 = true
    //     0x85e118: add             x16, NULL, #0x20  ; true
    // 0x85e11c: r17 = false
    //     0x85e11c: add             x17, NULL, #0x30  ; false
    // 0x85e120: csel            x0, x16, x17, eq
    // 0x85e124: r16 = true
    //     0x85e124: add             x16, NULL, #0x20  ; true
    // 0x85e128: cmp             w0, w16
    // 0x85e12c: b.ne            #0x85e17c
    // 0x85e130: tbnz            w7, #4, #0x85e140
    // 0x85e134: mov             x5, x8
    // 0x85e138: mov             x0, x8
    // 0x85e13c: b               #0x85e148
    // 0x85e140: mov             x5, x2
    // 0x85e144: mov             x0, x2
    // 0x85e148: r16 = Instance_TextDirection
    //     0x85e148: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0x85e14c: cmp             w5, w16
    // 0x85e150: r16 = true
    //     0x85e150: add             x16, NULL, #0x20  ; true
    // 0x85e154: r17 = false
    //     0x85e154: add             x17, NULL, #0x30  ; false
    // 0x85e158: csel            x6, x16, x17, eq
    // 0x85e15c: tbnz            w6, #4, #0x85e168
    // 0x85e160: r0 = 1.000000
    //     0x85e160: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x85e164: b               #0x85e24c
    // 0x85e168: mov             x7, x6
    // 0x85e16c: mov             x5, x0
    // 0x85e170: r6 = true
    //     0x85e170: add             x6, NULL, #0x20  ; true
    // 0x85e174: r0 = true
    //     0x85e174: add             x0, NULL, #0x20  ; true
    // 0x85e178: b               #0x85e18c
    // 0x85e17c: mov             x5, x8
    // 0x85e180: mov             x0, x7
    // 0x85e184: r7 = Null
    //     0x85e184: mov             x7, NULL
    // 0x85e188: r6 = false
    //     0x85e188: add             x6, NULL, #0x30  ; false
    // 0x85e18c: r16 = Instance_TextAlign
    //     0x85e18c: ldr             x16, [PP, #0x4c88]  ; [pp+0x4c88] Obj!TextAlign@12c7501
    // 0x85e190: cmp             w1, w16
    // 0x85e194: r16 = true
    //     0x85e194: add             x16, NULL, #0x20  ; true
    // 0x85e198: r17 = false
    //     0x85e198: add             x17, NULL, #0x30  ; false
    // 0x85e19c: csel            x8, x16, x17, eq
    // 0x85e1a0: tbnz            w8, #4, #0x85e208
    // 0x85e1a4: tbnz            w3, #4, #0x85e1b4
    // 0x85e1a8: mov             x3, x5
    // 0x85e1ac: mov             x1, x0
    // 0x85e1b0: b               #0x85e1e8
    // 0x85e1b4: tbnz            w0, #4, #0x85e1c4
    // 0x85e1b8: mov             x3, x5
    // 0x85e1bc: mov             x1, x5
    // 0x85e1c0: b               #0x85e1cc
    // 0x85e1c4: mov             x3, x2
    // 0x85e1c8: mov             x1, x2
    // 0x85e1cc: r16 = Instance_TextDirection
    //     0x85e1cc: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0x85e1d0: cmp             w3, w16
    // 0x85e1d4: r16 = true
    //     0x85e1d4: add             x16, NULL, #0x20  ; true
    // 0x85e1d8: r17 = false
    //     0x85e1d8: add             x17, NULL, #0x30  ; false
    // 0x85e1dc: csel            x4, x16, x17, eq
    // 0x85e1e0: mov             x3, x1
    // 0x85e1e4: r1 = true
    //     0x85e1e4: add             x1, NULL, #0x20  ; true
    // 0x85e1e8: r16 = true
    //     0x85e1e8: add             x16, NULL, #0x20  ; true
    // 0x85e1ec: cmp             w4, w16
    // 0x85e1f0: b.ne            #0x85e1fc
    // 0x85e1f4: r0 = 1.000000
    //     0x85e1f4: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x85e1f8: b               #0x85e24c
    // 0x85e1fc: mov             x0, x1
    // 0x85e200: mov             x1, x3
    // 0x85e204: b               #0x85e20c
    // 0x85e208: mov             x1, x5
    // 0x85e20c: tbnz            w8, #4, #0x85e248
    // 0x85e210: tbnz            w6, #4, #0x85e224
    // 0x85e214: r16 = true
    //     0x85e214: add             x16, NULL, #0x20  ; true
    // 0x85e218: cmp             w7, w16
    // 0x85e21c: b.ne            #0x85e248
    // 0x85e220: b               #0x85e240
    // 0x85e224: tbnz            w0, #4, #0x85e230
    // 0x85e228: mov             x0, x1
    // 0x85e22c: b               #0x85e234
    // 0x85e230: mov             x0, x2
    // 0x85e234: r16 = Instance_TextDirection
    //     0x85e234: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0x85e238: cmp             w0, w16
    // 0x85e23c: b.ne            #0x85e248
    // 0x85e240: r0 = 0.000000
    //     0x85e240: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x85e244: b               #0x85e24c
    // 0x85e248: r0 = Null
    //     0x85e248: mov             x0, NULL
    // 0x85e24c: LoadField: d0 = r0->field_7
    //     0x85e24c: ldur            d0, [x0, #7]
    // 0x85e250: ret
    //     0x85e250: ret             
  }
  _ _computeCaretMetrics(/* No info */) {
    // ** addr: 0x85e254, size: 0x60c
    // 0x85e254: EnterFrame
    //     0x85e254: stp             fp, lr, [SP, #-0x10]!
    //     0x85e258: mov             fp, SP
    // 0x85e25c: AllocStack(0x70)
    //     0x85e25c: sub             SP, SP, #0x70
    // 0x85e260: SetupParameters(TextPainter this /* r1 => r0, fp-0x28 */, dynamic _ /* r2 => r2, fp-0x30 */)
    //     0x85e260: mov             x0, x1
    //     0x85e264: stur            x1, [fp, #-0x28]
    //     0x85e268: stur            x2, [fp, #-0x30]
    // 0x85e26c: CheckStackOverflow
    //     0x85e26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85e270: cmp             SP, x16
    //     0x85e274: b.ls            #0x85e838
    // 0x85e278: LoadField: r3 = r0->field_7
    //     0x85e278: ldur            w3, [x0, #7]
    // 0x85e27c: DecompressPointer r3
    //     0x85e27c: add             x3, x3, HEAP, lsl #32
    // 0x85e280: stur            x3, [fp, #-0x20]
    // 0x85e284: cmp             w3, NULL
    // 0x85e288: b.eq            #0x85e840
    // 0x85e28c: LoadField: r4 = r3->field_7
    //     0x85e28c: ldur            w4, [x3, #7]
    // 0x85e290: DecompressPointer r4
    //     0x85e290: add             x4, x4, HEAP, lsl #32
    // 0x85e294: stur            x4, [fp, #-0x18]
    // 0x85e298: LoadField: r5 = r4->field_f
    //     0x85e298: ldur            w5, [x4, #0xf]
    // 0x85e29c: DecompressPointer r5
    //     0x85e29c: add             x5, x5, HEAP, lsl #32
    // 0x85e2a0: stur            x5, [fp, #-0x10]
    // 0x85e2a4: LoadField: r1 = r5->field_7
    //     0x85e2a4: ldur            w1, [x5, #7]
    // 0x85e2a8: DecompressPointer r1
    //     0x85e2a8: add             x1, x1, HEAP, lsl #32
    // 0x85e2ac: cmp             w1, NULL
    // 0x85e2b0: b.eq            #0x85e844
    // 0x85e2b4: LoadField: r6 = r1->field_7
    //     0x85e2b4: ldur            x6, [x1, #7]
    // 0x85e2b8: ldr             x1, [x6]
    // 0x85e2bc: cbz             x1, #0x85e7f8
    // 0x85e2c0: mov             x6, x1
    // 0x85e2c4: stur            x6, [fp, #-8]
    // 0x85e2c8: r1 = <Never>
    //     0x85e2c8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85e2cc: r0 = Pointer()
    //     0x85e2cc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85e2d0: mov             x1, x0
    // 0x85e2d4: ldur            x0, [fp, #-8]
    // 0x85e2d8: StoreField: r1->field_7 = r0
    //     0x85e2d8: stur            x0, [x1, #7]
    // 0x85e2dc: r0 = _numberOfLines$Getter$FfiNative()
    //     0x85e2dc: bl              #0x85f494  ; [dart:ui] _NativeParagraph::_numberOfLines$Getter$FfiNative
    // 0x85e2e0: cmp             x0, #1
    // 0x85e2e4: b.ge            #0x85e2f8
    // 0x85e2e8: r0 = Null
    //     0x85e2e8: mov             x0, NULL
    // 0x85e2ec: LeaveFrame
    //     0x85e2ec: mov             SP, fp
    //     0x85e2f0: ldp             fp, lr, [SP], #0x10
    // 0x85e2f4: ret
    //     0x85e2f4: ret             
    // 0x85e2f8: ldur            x2, [fp, #-0x30]
    // 0x85e2fc: LoadField: r3 = r2->field_7
    //     0x85e2fc: ldur            x3, [x2, #7]
    // 0x85e300: stur            x3, [fp, #-8]
    // 0x85e304: r0 = BoxInt64Instr(r3)
    //     0x85e304: sbfiz           x0, x3, #1, #0x1f
    //     0x85e308: cmp             x3, x0, asr #1
    //     0x85e30c: b.eq            #0x85e318
    //     0x85e310: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85e314: stur            x3, [x0, #7]
    // 0x85e318: stur            x0, [fp, #-0x38]
    // 0x85e31c: cbnz            w0, #0x85e330
    // 0x85e320: r2 = 0
    //     0x85e320: mov             x2, #0
    // 0x85e324: r3 = true
    //     0x85e324: add             x3, NULL, #0x20  ; true
    // 0x85e328: r0 = AllocateRecord2()
    //     0x85e328: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x85e32c: b               #0x85e3c8
    // 0x85e330: LoadField: r1 = r2->field_f
    //     0x85e330: ldur            w1, [x2, #0xf]
    // 0x85e334: DecompressPointer r1
    //     0x85e334: add             x1, x1, HEAP, lsl #32
    // 0x85e338: r16 = Instance_TextAffinity
    //     0x85e338: ldr             x16, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x85e33c: cmp             w1, w16
    // 0x85e340: b.ne            #0x85e354
    // 0x85e344: mov             x2, x0
    // 0x85e348: r3 = true
    //     0x85e348: add             x3, NULL, #0x20  ; true
    // 0x85e34c: r0 = AllocateRecord2()
    //     0x85e34c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x85e350: b               #0x85e3c8
    // 0x85e354: r16 = Instance_TextAffinity
    //     0x85e354: ldr             x16, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x85e358: cmp             w1, w16
    // 0x85e35c: r16 = true
    //     0x85e35c: add             x16, NULL, #0x20  ; true
    // 0x85e360: r17 = false
    //     0x85e360: add             x17, NULL, #0x30  ; false
    // 0x85e364: csel            x4, x16, x17, eq
    // 0x85e368: stur            x4, [fp, #-0x10]
    // 0x85e36c: tbnz            w4, #4, #0x85e390
    // 0x85e370: sub             x2, x3, #1
    // 0x85e374: ldur            x1, [fp, #-0x28]
    // 0x85e378: r0 = _isNewlineAtOffset()
    //     0x85e378: bl              #0x85f22c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_isNewlineAtOffset
    // 0x85e37c: tbnz            w0, #4, #0x85e390
    // 0x85e380: ldur            x2, [fp, #-0x38]
    // 0x85e384: r3 = true
    //     0x85e384: add             x3, NULL, #0x20  ; true
    // 0x85e388: r0 = AllocateRecord2()
    //     0x85e388: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x85e38c: b               #0x85e3c8
    // 0x85e390: ldur            x0, [fp, #-0x10]
    // 0x85e394: tbnz            w0, #4, #0x85e3c4
    // 0x85e398: ldur            x0, [fp, #-8]
    // 0x85e39c: sub             x2, x0, #1
    // 0x85e3a0: r0 = BoxInt64Instr(r2)
    //     0x85e3a0: sbfiz           x0, x2, #1, #0x1f
    //     0x85e3a4: cmp             x2, x0, asr #1
    //     0x85e3a8: b.eq            #0x85e3b4
    //     0x85e3ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85e3b0: stur            x2, [x0, #7]
    // 0x85e3b4: mov             x2, x0
    // 0x85e3b8: r3 = false
    //     0x85e3b8: add             x3, NULL, #0x30  ; false
    // 0x85e3bc: r0 = AllocateRecord2()
    //     0x85e3bc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x85e3c0: b               #0x85e3c8
    // 0x85e3c4: r0 = Null
    //     0x85e3c4: mov             x0, NULL
    // 0x85e3c8: LoadField: r2 = r0->field_f
    //     0x85e3c8: ldur            w2, [x0, #0xf]
    // 0x85e3cc: DecompressPointer r2
    //     0x85e3cc: add             x2, x2, HEAP, lsl #32
    // 0x85e3d0: stur            x2, [fp, #-0x40]
    // 0x85e3d4: LoadField: r3 = r0->field_13
    //     0x85e3d4: ldur            w3, [x0, #0x13]
    // 0x85e3d8: DecompressPointer r3
    //     0x85e3d8: add             x3, x3, HEAP, lsl #32
    // 0x85e3dc: stur            x3, [fp, #-0x38]
    // 0x85e3e0: tbnz            w3, #4, #0x85e3f8
    // 0x85e3e4: r0 = LoadInt32Instr(r2)
    //     0x85e3e4: sbfx            x0, x2, #1, #0x1f
    //     0x85e3e8: tbz             w2, #0, #0x85e3f0
    //     0x85e3ec: ldur            x0, [x2, #7]
    // 0x85e3f0: mov             x5, x0
    // 0x85e3f4: b               #0x85e410
    // 0x85e3f8: r0 = LoadInt32Instr(r2)
    //     0x85e3f8: sbfx            x0, x2, #1, #0x1f
    //     0x85e3fc: tbz             w2, #0, #0x85e404
    //     0x85e400: ldur            x0, [x2, #7]
    // 0x85e404: neg             x1, x0
    // 0x85e408: sub             x0, x1, #1
    // 0x85e40c: mov             x5, x0
    // 0x85e410: ldur            x4, [fp, #-0x20]
    // 0x85e414: LoadField: r6 = r4->field_2b
    //     0x85e414: ldur            w6, [x4, #0x2b]
    // 0x85e418: DecompressPointer r6
    //     0x85e418: add             x6, x6, HEAP, lsl #32
    // 0x85e41c: r0 = BoxInt64Instr(r5)
    //     0x85e41c: sbfiz           x0, x5, #1, #0x1f
    //     0x85e420: cmp             x5, x0, asr #1
    //     0x85e424: b.eq            #0x85e430
    //     0x85e428: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85e42c: stur            x5, [x0, #7]
    // 0x85e430: stur            x0, [fp, #-0x30]
    // 0x85e434: cmp             w0, w6
    // 0x85e438: b.eq            #0x85e474
    // 0x85e43c: and             w16, w0, w6
    // 0x85e440: branchIfSmi(r16, 0x85e498)
    //     0x85e440: tbz             w16, #0, #0x85e498
    // 0x85e444: r16 = LoadClassIdInstr(r0)
    //     0x85e444: ldur            x16, [x0, #-1]
    //     0x85e448: ubfx            x16, x16, #0xc, #0x14
    // 0x85e44c: cmp             x16, #0x3d
    // 0x85e450: b.ne            #0x85e498
    // 0x85e454: r16 = LoadClassIdInstr(r6)
    //     0x85e454: ldur            x16, [x6, #-1]
    //     0x85e458: ubfx            x16, x16, #0xc, #0x14
    // 0x85e45c: cmp             x16, #0x3d
    // 0x85e460: b.ne            #0x85e498
    // 0x85e464: LoadField: r16 = r0->field_7
    //     0x85e464: ldur            x16, [x0, #7]
    // 0x85e468: LoadField: r17 = r6->field_7
    //     0x85e468: ldur            x17, [x6, #7]
    // 0x85e46c: cmp             x16, x17
    // 0x85e470: b.ne            #0x85e498
    // 0x85e474: ldur            x5, [fp, #-0x28]
    // 0x85e478: LoadField: r0 = r5->field_43
    //     0x85e478: ldur            w0, [x5, #0x43]
    // 0x85e47c: DecompressPointer r0
    //     0x85e47c: add             x0, x0, HEAP, lsl #32
    // 0x85e480: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85e484: cmp             w0, w16
    // 0x85e488: b.eq            #0x85e848
    // 0x85e48c: LeaveFrame
    //     0x85e48c: mov             SP, fp
    //     0x85e490: ldp             fp, lr, [SP], #0x10
    // 0x85e494: ret
    //     0x85e494: ret             
    // 0x85e498: ldur            x5, [fp, #-0x28]
    // 0x85e49c: ldur            x6, [fp, #-0x18]
    // 0x85e4a0: LoadField: r7 = r6->field_f
    //     0x85e4a0: ldur            w7, [x6, #0xf]
    // 0x85e4a4: DecompressPointer r7
    //     0x85e4a4: add             x7, x7, HEAP, lsl #32
    // 0x85e4a8: stur            x7, [fp, #-0x10]
    // 0x85e4ac: LoadField: r1 = r7->field_7
    //     0x85e4ac: ldur            w1, [x7, #7]
    // 0x85e4b0: DecompressPointer r1
    //     0x85e4b0: add             x1, x1, HEAP, lsl #32
    // 0x85e4b4: cmp             w1, NULL
    // 0x85e4b8: b.eq            #0x85e850
    // 0x85e4bc: LoadField: r8 = r1->field_7
    //     0x85e4bc: ldur            x8, [x1, #7]
    // 0x85e4c0: ldr             x1, [x8]
    // 0x85e4c4: cbz             x1, #0x85e808
    // 0x85e4c8: mov             x8, x1
    // 0x85e4cc: stur            x8, [fp, #-8]
    // 0x85e4d0: r1 = <Never>
    //     0x85e4d0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85e4d4: r0 = Pointer()
    //     0x85e4d4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85e4d8: mov             x1, x0
    // 0x85e4dc: ldur            x0, [fp, #-8]
    // 0x85e4e0: StoreField: r1->field_7 = r0
    //     0x85e4e0: stur            x0, [x1, #7]
    // 0x85e4e4: ldur            x0, [fp, #-0x40]
    // 0x85e4e8: r4 = LoadInt32Instr(r0)
    //     0x85e4e8: sbfx            x4, x0, #1, #0x1f
    //     0x85e4ec: tbz             w0, #0, #0x85e4f4
    //     0x85e4f0: ldur            x4, [x0, #7]
    // 0x85e4f4: mov             x2, x4
    // 0x85e4f8: stur            x4, [fp, #-8]
    // 0x85e4fc: r3 = Closure: (double, double, double, double, int, int, bool) => GlyphInfo from Function 'GlyphInfo._@38065589': static.
    //     0x85e4fc: ldr             x3, [PP, #0x4bc0]  ; [pp+0x4bc0] Closure: (double, double, double, double, int, int, bool) => GlyphInfo from Function 'GlyphInfo._@38065589': static. (0x7f2ada746a1c)
    // 0x85e500: r0 = __getGlyphInfoAt$Method$FfiNative()
    //     0x85e500: bl              #0x85f038  ; [dart:ui] _NativeParagraph::__getGlyphInfoAt$Method$FfiNative
    // 0x85e504: stur            x0, [fp, #-0x40]
    // 0x85e508: cmp             w0, NULL
    // 0x85e50c: b.ne            #0x85e5c8
    // 0x85e510: ldur            x1, [fp, #-0x28]
    // 0x85e514: r0 = _getOrCreateLayoutTemplate()
    //     0x85e514: bl              #0x859ea0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getOrCreateLayoutTemplate
    // 0x85e518: stur            x0, [fp, #-0x10]
    // 0x85e51c: LoadField: r1 = r0->field_7
    //     0x85e51c: ldur            w1, [x0, #7]
    // 0x85e520: DecompressPointer r1
    //     0x85e520: add             x1, x1, HEAP, lsl #32
    // 0x85e524: cmp             w1, NULL
    // 0x85e528: b.eq            #0x85e854
    // 0x85e52c: LoadField: r2 = r1->field_7
    //     0x85e52c: ldur            x2, [x1, #7]
    // 0x85e530: ldr             x1, [x2]
    // 0x85e534: cbz             x1, #0x85e818
    // 0x85e538: mov             x2, x1
    // 0x85e53c: stur            x2, [fp, #-0x48]
    // 0x85e540: r1 = <Never>
    //     0x85e540: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85e544: r0 = Pointer()
    //     0x85e544: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85e548: mov             x1, x0
    // 0x85e54c: ldur            x0, [fp, #-0x48]
    // 0x85e550: StoreField: r1->field_7 = r0
    //     0x85e550: stur            x0, [x1, #7]
    // 0x85e554: r2 = 0
    //     0x85e554: mov             x2, #0
    // 0x85e558: r3 = Closure: (bool, double, double, double, double, double, double, double, int) => LineMetrics from Function 'LineMetrics._@38065589': static.
    //     0x85e558: ldr             x3, [PP, #0x4bc8]  ; [pp+0x4bc8] Closure: (bool, double, double, double, double, double, double, double, int) => LineMetrics from Function 'LineMetrics._@38065589': static. (0x7f2ada746968)
    // 0x85e55c: r0 = __getLineMetricsAt$Method$FfiNative()
    //     0x85e55c: bl              #0x85ee44  ; [dart:ui] _NativeParagraph::__getLineMetricsAt$Method$FfiNative
    // 0x85e560: cmp             w0, NULL
    // 0x85e564: b.eq            #0x85e858
    // 0x85e568: LoadField: d0 = r0->field_3b
    //     0x85e568: ldur            d0, [x0, #0x3b]
    // 0x85e56c: ldur            x1, [fp, #-0x18]
    // 0x85e570: stur            d0, [fp, #-0x60]
    // 0x85e574: LoadField: r0 = r1->field_13
    //     0x85e574: ldur            w0, [x1, #0x13]
    // 0x85e578: DecompressPointer r0
    //     0x85e578: add             x0, x0, HEAP, lsl #32
    // 0x85e57c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85e580: cmp             w0, w16
    // 0x85e584: b.ne            #0x85e590
    // 0x85e588: r2 = _endOfTextCaretMetrics
    //     0x85e588: ldr             x2, [PP, #0x4bd0]  ; [pp+0x4bd0] Field <_TextLayout@49105366._endOfTextCaretMetrics@49105366>: late final (offset: 0x14)
    // 0x85e58c: r0 = InitLateFinalInstanceField()
    //     0x85e58c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x85e590: ldur            d0, [fp, #-0x60]
    // 0x85e594: stur            x0, [fp, #-0x10]
    // 0x85e598: fneg            d1, d0
    // 0x85e59c: stur            d1, [fp, #-0x68]
    // 0x85e5a0: r0 = Offset()
    //     0x85e5a0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85e5a4: StoreField: r0->field_7 = rZR
    //     0x85e5a4: stur            xzr, [x0, #7]
    // 0x85e5a8: ldur            d0, [fp, #-0x68]
    // 0x85e5ac: StoreField: r0->field_f = d0
    //     0x85e5ac: stur            d0, [x0, #0xf]
    // 0x85e5b0: ldur            x1, [fp, #-0x10]
    // 0x85e5b4: mov             x2, x0
    // 0x85e5b8: r0 = shift()
    //     0x85e5b8: bl              #0x85eda0  ; [package:flutter/src/painting/text_painter.dart] _LineCaretMetrics::shift
    // 0x85e5bc: LeaveFrame
    //     0x85e5bc: mov             SP, fp
    //     0x85e5c0: ldp             fp, lr, [SP], #0x10
    // 0x85e5c4: ret
    //     0x85e5c4: ret             
    // 0x85e5c8: LoadField: r1 = r0->field_b
    //     0x85e5c8: ldur            w1, [x0, #0xb]
    // 0x85e5cc: DecompressPointer r1
    //     0x85e5cc: add             x1, x1, HEAP, lsl #32
    // 0x85e5d0: LoadField: r2 = r1->field_7
    //     0x85e5d0: ldur            x2, [x1, #7]
    // 0x85e5d4: stur            x2, [fp, #-0x58]
    // 0x85e5d8: LoadField: r3 = r1->field_f
    //     0x85e5d8: ldur            x3, [x1, #0xf]
    // 0x85e5dc: stur            x3, [fp, #-0x50]
    // 0x85e5e0: cmp             x2, x3
    // 0x85e5e4: b.ne            #0x85e624
    // 0x85e5e8: ldur            x1, [fp, #-8]
    // 0x85e5ec: add             x0, x1, #1
    // 0x85e5f0: stur            x0, [fp, #-0x48]
    // 0x85e5f4: r0 = TextPosition()
    //     0x85e5f4: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x85e5f8: mov             x1, x0
    // 0x85e5fc: ldur            x0, [fp, #-0x48]
    // 0x85e600: StoreField: r1->field_7 = r0
    //     0x85e600: stur            x0, [x1, #7]
    // 0x85e604: r4 = Instance_TextAffinity
    //     0x85e604: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x85e608: StoreField: r1->field_f = r4
    //     0x85e608: stur            w4, [x1, #0xf]
    // 0x85e60c: mov             x2, x1
    // 0x85e610: ldur            x1, [fp, #-0x28]
    // 0x85e614: r0 = _computeCaretMetrics()
    //     0x85e614: bl              #0x85e254  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0x85e618: LeaveFrame
    //     0x85e618: mov             SP, fp
    //     0x85e61c: ldp             fp, lr, [SP], #0x10
    // 0x85e620: ret
    //     0x85e620: ret             
    // 0x85e624: ldur            x5, [fp, #-0x38]
    // 0x85e628: ldur            x1, [fp, #-8]
    // 0x85e62c: r4 = Instance_TextAffinity
    //     0x85e62c: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x85e630: tbnz            w5, #4, #0x85e668
    // 0x85e634: cmp             x2, x1
    // 0x85e638: b.eq            #0x85e668
    // 0x85e63c: r0 = TextPosition()
    //     0x85e63c: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x85e640: ldur            x3, [fp, #-0x50]
    // 0x85e644: StoreField: r0->field_7 = r3
    //     0x85e644: stur            x3, [x0, #7]
    // 0x85e648: r1 = Instance_TextAffinity
    //     0x85e648: ldr             x1, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x85e64c: StoreField: r0->field_f = r1
    //     0x85e64c: stur            w1, [x0, #0xf]
    // 0x85e650: ldur            x1, [fp, #-0x28]
    // 0x85e654: mov             x2, x0
    // 0x85e658: r0 = _computeCaretMetrics()
    //     0x85e658: bl              #0x85e254  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0x85e65c: LeaveFrame
    //     0x85e65c: mov             SP, fp
    //     0x85e660: ldp             fp, lr, [SP], #0x10
    // 0x85e664: ret
    //     0x85e664: ret             
    // 0x85e668: ldur            x1, [fp, #-0x18]
    // 0x85e66c: LoadField: r4 = r1->field_f
    //     0x85e66c: ldur            w4, [x1, #0xf]
    // 0x85e670: DecompressPointer r4
    //     0x85e670: add             x4, x4, HEAP, lsl #32
    // 0x85e674: stur            x4, [fp, #-0x10]
    // 0x85e678: LoadField: r1 = r4->field_7
    //     0x85e678: ldur            w1, [x4, #7]
    // 0x85e67c: DecompressPointer r1
    //     0x85e67c: add             x1, x1, HEAP, lsl #32
    // 0x85e680: cmp             w1, NULL
    // 0x85e684: b.eq            #0x85e85c
    // 0x85e688: LoadField: r6 = r1->field_7
    //     0x85e688: ldur            x6, [x1, #7]
    // 0x85e68c: ldr             x1, [x6]
    // 0x85e690: cbz             x1, #0x85e828
    // 0x85e694: mov             x6, x1
    // 0x85e698: stur            x6, [fp, #-8]
    // 0x85e69c: r1 = <Never>
    //     0x85e69c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85e6a0: r0 = Pointer()
    //     0x85e6a0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85e6a4: mov             x1, x0
    // 0x85e6a8: ldur            x0, [fp, #-8]
    // 0x85e6ac: StoreField: r1->field_7 = r0
    //     0x85e6ac: stur            x0, [x1, #7]
    // 0x85e6b0: ldur            x2, [fp, #-0x58]
    // 0x85e6b4: ldur            x3, [fp, #-0x50]
    // 0x85e6b8: r5 = 5
    //     0x85e6b8: mov             x5, #5
    // 0x85e6bc: r6 = 0
    //     0x85e6bc: mov             x6, #0
    // 0x85e6c0: r0 = __getBoxesForRange$Method$FfiNative()
    //     0x85e6c0: bl              #0x85eb58  ; [dart:ui] _NativeParagraph::__getBoxesForRange$Method$FfiNative
    // 0x85e6c4: ldur            x1, [fp, #-0x10]
    // 0x85e6c8: mov             x2, x0
    // 0x85e6cc: r0 = _decodeTextBoxes()
    //     0x85e6cc: bl              #0x85e86c  ; [dart:ui] _NativeParagraph::_decodeTextBoxes
    // 0x85e6d0: mov             x1, x0
    // 0x85e6d4: ldur            x0, [fp, #-0x40]
    // 0x85e6d8: LoadField: r2 = r0->field_f
    //     0x85e6d8: ldur            w2, [x0, #0xf]
    // 0x85e6dc: DecompressPointer r2
    //     0x85e6dc: add             x2, x2, HEAP, lsl #32
    // 0x85e6e0: LoadField: r0 = r2->field_7
    //     0x85e6e0: ldur            x0, [x2, #7]
    // 0x85e6e4: cmp             x0, #0
    // 0x85e6e8: b.gt            #0x85e6fc
    // 0x85e6ec: ldur            x0, [fp, #-0x38]
    // 0x85e6f0: eor             x2, x0, #0x10
    // 0x85e6f4: mov             x0, x2
    // 0x85e6f8: b               #0x85e700
    // 0x85e6fc: ldur            x0, [fp, #-0x38]
    // 0x85e700: stur            x0, [fp, #-0x10]
    // 0x85e704: tbnz            w0, #4, #0x85e714
    // 0x85e708: r0 = first()
    //     0x85e708: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0x85e70c: mov             x1, x0
    // 0x85e710: b               #0x85e71c
    // 0x85e714: r0 = last()
    //     0x85e714: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x85e718: mov             x1, x0
    // 0x85e71c: ldur            x0, [fp, #-0x10]
    // 0x85e720: stur            x1, [fp, #-0x18]
    // 0x85e724: tbnz            w0, #4, #0x85e730
    // 0x85e728: LoadField: d0 = r1->field_7
    //     0x85e728: ldur            d0, [x1, #7]
    // 0x85e72c: b               #0x85e734
    // 0x85e730: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x85e730: ldur            d0, [x1, #0x17]
    // 0x85e734: ldur            x2, [fp, #-0x28]
    // 0x85e738: ldur            x0, [fp, #-0x20]
    // 0x85e73c: stur            d0, [fp, #-0x68]
    // 0x85e740: LoadField: d1 = r1->field_f
    //     0x85e740: ldur            d1, [x1, #0xf]
    // 0x85e744: stur            d1, [fp, #-0x60]
    // 0x85e748: r0 = Offset()
    //     0x85e748: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85e74c: ldur            d0, [fp, #-0x68]
    // 0x85e750: stur            x0, [fp, #-0x38]
    // 0x85e754: StoreField: r0->field_7 = d0
    //     0x85e754: stur            d0, [x0, #7]
    // 0x85e758: ldur            d0, [fp, #-0x60]
    // 0x85e75c: StoreField: r0->field_f = d0
    //     0x85e75c: stur            d0, [x0, #0xf]
    // 0x85e760: ldur            x1, [fp, #-0x18]
    // 0x85e764: LoadField: r2 = r1->field_27
    //     0x85e764: ldur            w2, [x1, #0x27]
    // 0x85e768: DecompressPointer r2
    //     0x85e768: add             x2, x2, HEAP, lsl #32
    // 0x85e76c: stur            x2, [fp, #-0x10]
    // 0x85e770: LoadField: d1 = r1->field_1f
    //     0x85e770: ldur            d1, [x1, #0x1f]
    // 0x85e774: fsub            d2, d1, d0
    // 0x85e778: stur            d2, [fp, #-0x68]
    // 0x85e77c: r0 = _LineCaretMetrics()
    //     0x85e77c: bl              #0x85e860  ; Allocate_LineCaretMetricsStub -> _LineCaretMetrics (size=0x18)
    // 0x85e780: mov             x1, x0
    // 0x85e784: ldur            x0, [fp, #-0x38]
    // 0x85e788: StoreField: r1->field_7 = r0
    //     0x85e788: stur            w0, [x1, #7]
    // 0x85e78c: ldur            x0, [fp, #-0x10]
    // 0x85e790: StoreField: r1->field_b = r0
    //     0x85e790: stur            w0, [x1, #0xb]
    // 0x85e794: ldur            d0, [fp, #-0x68]
    // 0x85e798: StoreField: r1->field_f = d0
    //     0x85e798: stur            d0, [x1, #0xf]
    // 0x85e79c: ldur            x0, [fp, #-0x30]
    // 0x85e7a0: ldur            x2, [fp, #-0x20]
    // 0x85e7a4: StoreField: r2->field_2b = r0
    //     0x85e7a4: stur            w0, [x2, #0x2b]
    //     0x85e7a8: tbz             w0, #0, #0x85e7c4
    //     0x85e7ac: ldurb           w16, [x2, #-1]
    //     0x85e7b0: ldurb           w17, [x0, #-1]
    //     0x85e7b4: and             x16, x17, x16, lsr #2
    //     0x85e7b8: tst             x16, HEAP, lsr #32
    //     0x85e7bc: b.eq            #0x85e7c4
    //     0x85e7c0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x85e7c4: mov             x0, x1
    // 0x85e7c8: ldur            x2, [fp, #-0x28]
    // 0x85e7cc: StoreField: r2->field_43 = r0
    //     0x85e7cc: stur            w0, [x2, #0x43]
    //     0x85e7d0: ldurb           w16, [x2, #-1]
    //     0x85e7d4: ldurb           w17, [x0, #-1]
    //     0x85e7d8: and             x16, x17, x16, lsr #2
    //     0x85e7dc: tst             x16, HEAP, lsr #32
    //     0x85e7e0: b.eq            #0x85e7e8
    //     0x85e7e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x85e7e8: mov             x0, x1
    // 0x85e7ec: LeaveFrame
    //     0x85e7ec: mov             SP, fp
    //     0x85e7f0: ldp             fp, lr, [SP], #0x10
    // 0x85e7f4: ret
    //     0x85e7f4: ret             
    // 0x85e7f8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85e7f8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85e7fc: str             x16, [SP]
    // 0x85e800: r0 = _throwNew()
    //     0x85e800: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85e804: brk             #0
    // 0x85e808: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85e808: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85e80c: str             x16, [SP]
    // 0x85e810: r0 = _throwNew()
    //     0x85e810: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85e814: brk             #0
    // 0x85e818: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85e818: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85e81c: str             x16, [SP]
    // 0x85e820: r0 = _throwNew()
    //     0x85e820: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85e824: brk             #0
    // 0x85e828: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85e828: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85e82c: str             x16, [SP]
    // 0x85e830: r0 = _throwNew()
    //     0x85e830: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85e834: brk             #0
    // 0x85e838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85e838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85e83c: b               #0x85e278
    // 0x85e840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85e840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85e844: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85e844: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x85e848: r9 = _caretMetrics
    //     0x85e848: ldr             x9, [PP, #0x4bd8]  ; [pp+0x4bd8] Field <TextPainter._caretMetrics@49105366>: late (offset: 0x44)
    // 0x85e84c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85e84c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85e850: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85e850: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x85e854: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85e854: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x85e858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85e858: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85e85c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85e85c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _isNewlineAtOffset(/* No info */) {
    // ** addr: 0x85f22c, size: 0x108
    // 0x85f22c: EnterFrame
    //     0x85f22c: stp             fp, lr, [SP, #-0x10]!
    //     0x85f230: mov             fp, SP
    // 0x85f234: AllocStack(0x10)
    //     0x85f234: sub             SP, SP, #0x10
    // 0x85f238: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x85f238: mov             x0, x2
    //     0x85f23c: stur            x2, [fp, #-0x10]
    //     0x85f240: mov             x2, x1
    //     0x85f244: stur            x1, [fp, #-8]
    // 0x85f248: CheckStackOverflow
    //     0x85f248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f24c: cmp             SP, x16
    //     0x85f250: b.ls            #0x85f328
    // 0x85f254: tbnz            x0, #0x3f, #0x85f318
    // 0x85f258: mov             x1, x2
    // 0x85f25c: r0 = plainText()
    //     0x85f25c: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x85f260: LoadField: r1 = r0->field_7
    //     0x85f260: ldur            w1, [x0, #7]
    // 0x85f264: r0 = LoadInt32Instr(r1)
    //     0x85f264: sbfx            x0, x1, #1, #0x1f
    // 0x85f268: ldur            x2, [fp, #-0x10]
    // 0x85f26c: cmp             x2, x0
    // 0x85f270: b.ge            #0x85f318
    // 0x85f274: ldur            x1, [fp, #-8]
    // 0x85f278: r0 = plainText()
    //     0x85f278: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x85f27c: mov             x2, x0
    // 0x85f280: LoadField: r3 = r2->field_7
    //     0x85f280: ldur            w3, [x2, #7]
    // 0x85f284: r0 = LoadInt32Instr(r3)
    //     0x85f284: sbfx            x0, x3, #1, #0x1f
    // 0x85f288: ldur            x1, [fp, #-0x10]
    // 0x85f28c: cmp             x1, x0
    // 0x85f290: b.hs            #0x85f330
    // 0x85f294: r1 = LoadClassIdInstr(r2)
    //     0x85f294: ldur            x1, [x2, #-1]
    //     0x85f298: ubfx            x1, x1, #0xc, #0x14
    // 0x85f29c: lsl             x1, x1, #1
    // 0x85f2a0: cmp             w1, #0xbc
    // 0x85f2a4: b.ne            #0x85f2bc
    // 0x85f2a8: ldur            x1, [fp, #-0x10]
    // 0x85f2ac: ArrayLoad: r3 = r2[r1]  ; TypedUnsigned_1
    //     0x85f2ac: add             x16, x2, x1
    //     0x85f2b0: ldrb            w3, [x16, #0xf]
    // 0x85f2b4: mov             x1, x3
    // 0x85f2b8: b               #0x85f2cc
    // 0x85f2bc: ldur            x1, [fp, #-0x10]
    // 0x85f2c0: add             x16, x2, x1, lsl #1
    // 0x85f2c4: ldurh           w3, [x16, #0xf]
    // 0x85f2c8: mov             x1, x3
    // 0x85f2cc: cmp             x1, #0xa
    // 0x85f2d0: b.eq            #0x85f304
    // 0x85f2d4: cmp             x1, #0x85
    // 0x85f2d8: b.eq            #0x85f304
    // 0x85f2dc: cmp             x1, #0xb
    // 0x85f2e0: b.eq            #0x85f304
    // 0x85f2e4: cmp             x1, #0xc
    // 0x85f2e8: b.eq            #0x85f304
    // 0x85f2ec: r17 = 8232
    //     0x85f2ec: mov             x17, #0x2028
    // 0x85f2f0: cmp             x1, x17
    // 0x85f2f4: b.eq            #0x85f304
    // 0x85f2f8: r17 = 8233
    //     0x85f2f8: mov             x17, #0x2029
    // 0x85f2fc: cmp             x1, x17
    // 0x85f300: b.ne            #0x85f30c
    // 0x85f304: r1 = true
    //     0x85f304: add             x1, NULL, #0x20  ; true
    // 0x85f308: b               #0x85f310
    // 0x85f30c: r1 = false
    //     0x85f30c: add             x1, NULL, #0x30  ; false
    // 0x85f310: mov             x0, x1
    // 0x85f314: b               #0x85f31c
    // 0x85f318: r0 = false
    //     0x85f318: add             x0, NULL, #0x30  ; false
    // 0x85f31c: LeaveFrame
    //     0x85f31c: mov             SP, fp
    //     0x85f320: ldp             fp, lr, [SP], #0x10
    // 0x85f324: ret
    //     0x85f324: ret             
    // 0x85f328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f32c: b               #0x85f254
    // 0x85f330: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x85f330: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ plainText(/* No info */) {
    // ** addr: 0x85f334, size: 0xa0
    // 0x85f334: EnterFrame
    //     0x85f334: stp             fp, lr, [SP, #-0x10]!
    //     0x85f338: mov             fp, SP
    // 0x85f33c: AllocStack(0x8)
    //     0x85f33c: sub             SP, SP, #8
    // 0x85f340: SetupParameters(TextPainter this /* r1 => r0, fp-0x8 */)
    //     0x85f340: mov             x0, x1
    //     0x85f344: stur            x1, [fp, #-8]
    // 0x85f348: CheckStackOverflow
    //     0x85f348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f34c: cmp             SP, x16
    //     0x85f350: b.ls            #0x85f3cc
    // 0x85f354: LoadField: r1 = r0->field_13
    //     0x85f354: ldur            w1, [x0, #0x13]
    // 0x85f358: DecompressPointer r1
    //     0x85f358: add             x1, x1, HEAP, lsl #32
    // 0x85f35c: cmp             w1, NULL
    // 0x85f360: b.ne            #0x85f3ac
    // 0x85f364: LoadField: r1 = r0->field_f
    //     0x85f364: ldur            w1, [x0, #0xf]
    // 0x85f368: DecompressPointer r1
    //     0x85f368: add             x1, x1, HEAP, lsl #32
    // 0x85f36c: cmp             w1, NULL
    // 0x85f370: b.ne            #0x85f380
    // 0x85f374: mov             x2, x0
    // 0x85f378: r1 = Null
    //     0x85f378: mov             x1, NULL
    // 0x85f37c: b               #0x85f38c
    // 0x85f380: r0 = toPlainText()
    //     0x85f380: bl              #0x85f3d4  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0x85f384: mov             x1, x0
    // 0x85f388: ldur            x2, [fp, #-8]
    // 0x85f38c: mov             x0, x1
    // 0x85f390: StoreField: r2->field_13 = r0
    //     0x85f390: stur            w0, [x2, #0x13]
    //     0x85f394: ldurb           w16, [x2, #-1]
    //     0x85f398: ldurb           w17, [x0, #-1]
    //     0x85f39c: and             x16, x17, x16, lsr #2
    //     0x85f3a0: tst             x16, HEAP, lsr #32
    //     0x85f3a4: b.eq            #0x85f3ac
    //     0x85f3a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x85f3ac: cmp             w1, NULL
    // 0x85f3b0: b.ne            #0x85f3bc
    // 0x85f3b4: r0 = ""
    //     0x85f3b4: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x85f3b8: b               #0x85f3c0
    // 0x85f3bc: mov             x0, x1
    // 0x85f3c0: LeaveFrame
    //     0x85f3c0: mov             SP, fp
    //     0x85f3c4: ldp             fp, lr, [SP], #0x10
    // 0x85f3c8: ret
    //     0x85f3c8: ret             
    // 0x85f3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f3cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f3d0: b               #0x85f354
  }
  _ getBoxesForSelection(/* No info */) {
    // ** addr: 0x85fc0c, size: 0x258
    // 0x85fc0c: EnterFrame
    //     0x85fc0c: stp             fp, lr, [SP, #-0x10]!
    //     0x85fc10: mov             fp, SP
    // 0x85fc14: AllocStack(0x70)
    //     0x85fc14: sub             SP, SP, #0x70
    // 0x85fc18: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */, {dynamic boxHeightStyle = Instance_BoxHeightStyle /* r5, fp-0x18 */, dynamic boxWidthStyle = Instance_BoxWidthStyle /* r0, fp-0x10 */})
    //     0x85fc18: stur            x2, [fp, #-0x20]
    //     0x85fc1c: ldur            w0, [x4, #0x13]
    //     0x85fc20: ldur            w3, [x4, #0x1f]
    //     0x85fc24: add             x3, x3, HEAP, lsl #32
    //     0x85fc28: ldr             x16, [PP, #0x4d28]  ; [pp+0x4d28] "boxHeightStyle"
    //     0x85fc2c: cmp             w3, w16
    //     0x85fc30: b.ne            #0x85fc54
    //     0x85fc34: ldur            w3, [x4, #0x23]
    //     0x85fc38: add             x3, x3, HEAP, lsl #32
    //     0x85fc3c: sub             w5, w0, w3
    //     0x85fc40: add             x3, fp, w5, sxtw #2
    //     0x85fc44: ldr             x3, [x3, #8]
    //     0x85fc48: mov             x5, x3
    //     0x85fc4c: mov             x3, #1
    //     0x85fc50: b               #0x85fc5c
    //     0x85fc54: ldr             x5, [PP, #0x4d30]  ; [pp+0x4d30] Obj!BoxHeightStyle@12c7301
    //     0x85fc58: mov             x3, #0
    //     0x85fc5c: stur            x5, [fp, #-0x18]
    //     0x85fc60: lsl             x6, x3, #1
    //     0x85fc64: lsl             w3, w6, #1
    //     0x85fc68: add             w6, w3, #8
    //     0x85fc6c: add             x16, x4, w6, sxtw #1
    //     0x85fc70: ldur            w7, [x16, #0xf]
    //     0x85fc74: add             x7, x7, HEAP, lsl #32
    //     0x85fc78: ldr             x16, [PP, #0x4d38]  ; [pp+0x4d38] "boxWidthStyle"
    //     0x85fc7c: cmp             w7, w16
    //     0x85fc80: b.ne            #0x85fca4
    //     0x85fc84: add             w6, w3, #0xa
    //     0x85fc88: add             x16, x4, w6, sxtw #1
    //     0x85fc8c: ldur            w3, [x16, #0xf]
    //     0x85fc90: add             x3, x3, HEAP, lsl #32
    //     0x85fc94: sub             w4, w0, w3
    //     0x85fc98: add             x0, fp, w4, sxtw #2
    //     0x85fc9c: ldr             x0, [x0, #8]
    //     0x85fca0: b               #0x85fca8
    //     0x85fca4: ldr             x0, [PP, #0x4d40]  ; [pp+0x4d40] Obj!BoxWidthStyle@12c72c1
    //     0x85fca8: stur            x0, [fp, #-0x10]
    // 0x85fcac: CheckStackOverflow
    //     0x85fcac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85fcb0: cmp             SP, x16
    //     0x85fcb4: b.ls            #0x85fe54
    // 0x85fcb8: LoadField: r3 = r1->field_7
    //     0x85fcb8: ldur            w3, [x1, #7]
    // 0x85fcbc: DecompressPointer r3
    //     0x85fcbc: add             x3, x3, HEAP, lsl #32
    // 0x85fcc0: stur            x3, [fp, #-8]
    // 0x85fcc4: cmp             w3, NULL
    // 0x85fcc8: b.eq            #0x85fe5c
    // 0x85fccc: mov             x1, x3
    // 0x85fcd0: r0 = paintOffset()
    //     0x85fcd0: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x85fcd4: stur            x0, [fp, #-0x28]
    // 0x85fcd8: r1 = 1
    //     0x85fcd8: mov             x1, #1
    // 0x85fcdc: r0 = AllocateContext()
    //     0x85fcdc: bl              #0x13de838  ; AllocateContextStub
    // 0x85fce0: mov             x2, x0
    // 0x85fce4: ldur            x0, [fp, #-0x28]
    // 0x85fce8: stur            x2, [fp, #-0x58]
    // 0x85fcec: StoreField: r2->field_f = r0
    //     0x85fcec: stur            w0, [x2, #0xf]
    // 0x85fcf0: LoadField: d0 = r0->field_7
    //     0x85fcf0: ldur            d0, [x0, #7]
    // 0x85fcf4: mov             x1, v0.d[0]
    // 0x85fcf8: and             x1, x1, #0x7fffffffffffffff
    // 0x85fcfc: r17 = 9218868437227405312
    //     0x85fcfc: mov             x17, #0x7ff0000000000000
    // 0x85fd00: cmp             x1, x17
    // 0x85fd04: b.eq            #0x85fe2c
    // 0x85fd08: fcmp            d0, d0
    // 0x85fd0c: b.vs            #0x85fe2c
    // 0x85fd10: LoadField: d0 = r0->field_f
    //     0x85fd10: ldur            d0, [x0, #0xf]
    // 0x85fd14: mov             x1, v0.d[0]
    // 0x85fd18: and             x1, x1, #0x7fffffffffffffff
    // 0x85fd1c: r17 = 9218868437227405312
    //     0x85fd1c: mov             x17, #0x7ff0000000000000
    // 0x85fd20: cmp             x1, x17
    // 0x85fd24: b.eq            #0x85fe2c
    // 0x85fd28: fcmp            d0, d0
    // 0x85fd2c: b.vs            #0x85fe2c
    // 0x85fd30: ldur            x1, [fp, #-0x20]
    // 0x85fd34: ldur            x3, [fp, #-0x18]
    // 0x85fd38: ldur            x4, [fp, #-0x10]
    // 0x85fd3c: ldur            x5, [fp, #-8]
    // 0x85fd40: LoadField: r6 = r5->field_7
    //     0x85fd40: ldur            w6, [x5, #7]
    // 0x85fd44: DecompressPointer r6
    //     0x85fd44: add             x6, x6, HEAP, lsl #32
    // 0x85fd48: LoadField: r5 = r6->field_f
    //     0x85fd48: ldur            w5, [x6, #0xf]
    // 0x85fd4c: DecompressPointer r5
    //     0x85fd4c: add             x5, x5, HEAP, lsl #32
    // 0x85fd50: stur            x5, [fp, #-8]
    // 0x85fd54: LoadField: r6 = r1->field_7
    //     0x85fd54: ldur            x6, [x1, #7]
    // 0x85fd58: stur            x6, [fp, #-0x50]
    // 0x85fd5c: LoadField: r7 = r1->field_f
    //     0x85fd5c: ldur            x7, [x1, #0xf]
    // 0x85fd60: stur            x7, [fp, #-0x48]
    // 0x85fd64: LoadField: r8 = r3->field_7
    //     0x85fd64: ldur            x8, [x3, #7]
    // 0x85fd68: stur            x8, [fp, #-0x40]
    // 0x85fd6c: LoadField: r3 = r4->field_7
    //     0x85fd6c: ldur            x3, [x4, #7]
    // 0x85fd70: stur            x3, [fp, #-0x38]
    // 0x85fd74: LoadField: r1 = r5->field_7
    //     0x85fd74: ldur            w1, [x5, #7]
    // 0x85fd78: DecompressPointer r1
    //     0x85fd78: add             x1, x1, HEAP, lsl #32
    // 0x85fd7c: cmp             w1, NULL
    // 0x85fd80: b.eq            #0x85fe60
    // 0x85fd84: LoadField: r4 = r1->field_7
    //     0x85fd84: ldur            x4, [x1, #7]
    // 0x85fd88: ldr             x1, [x4]
    // 0x85fd8c: cbz             x1, #0x85fe44
    // 0x85fd90: mov             x4, x1
    // 0x85fd94: stur            x4, [fp, #-0x30]
    // 0x85fd98: r1 = <Never>
    //     0x85fd98: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85fd9c: r0 = Pointer()
    //     0x85fd9c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85fda0: mov             x1, x0
    // 0x85fda4: ldur            x0, [fp, #-0x30]
    // 0x85fda8: StoreField: r1->field_7 = r0
    //     0x85fda8: stur            x0, [x1, #7]
    // 0x85fdac: ldur            x2, [fp, #-0x50]
    // 0x85fdb0: ldur            x3, [fp, #-0x48]
    // 0x85fdb4: ldur            x5, [fp, #-0x40]
    // 0x85fdb8: ldur            x6, [fp, #-0x38]
    // 0x85fdbc: r0 = __getBoxesForRange$Method$FfiNative()
    //     0x85fdbc: bl              #0x85eb58  ; [dart:ui] _NativeParagraph::__getBoxesForRange$Method$FfiNative
    // 0x85fdc0: ldur            x1, [fp, #-8]
    // 0x85fdc4: mov             x2, x0
    // 0x85fdc8: r0 = _decodeTextBoxes()
    //     0x85fdc8: bl              #0x85e86c  ; [dart:ui] _NativeParagraph::_decodeTextBoxes
    // 0x85fdcc: stur            x0, [fp, #-8]
    // 0x85fdd0: ldur            x16, [fp, #-0x28]
    // 0x85fdd4: r30 = Instance_Offset
    //     0x85fdd4: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x85fdd8: stp             lr, x16, [SP]
    // 0x85fddc: r0 = ==()
    //     0x85fddc: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x85fde0: tbnz            w0, #4, #0x85fdec
    // 0x85fde4: ldur            x0, [fp, #-8]
    // 0x85fde8: b               #0x85fe20
    // 0x85fdec: ldur            x2, [fp, #-0x58]
    // 0x85fdf0: r1 = Function '<anonymous closure>':.
    //     0x85fdf0: ldr             x1, [PP, #0x4d48]  ; [pp+0x4d48] AnonymousClosure: (0x85fe64), in [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection (0x85fc0c)
    // 0x85fdf4: r0 = AllocateClosure()
    //     0x85fdf4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x85fdf8: r16 = <TextBox>
    //     0x85fdf8: ldr             x16, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0x85fdfc: ldur            lr, [fp, #-8]
    // 0x85fe00: stp             lr, x16, [SP, #8]
    // 0x85fe04: str             x0, [SP]
    // 0x85fe08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x85fe08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x85fe0c: r0 = map()
    //     0x85fe0c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x85fe10: LoadField: r1 = r0->field_7
    //     0x85fe10: ldur            w1, [x0, #7]
    // 0x85fe14: DecompressPointer r1
    //     0x85fe14: add             x1, x1, HEAP, lsl #32
    // 0x85fe18: mov             x2, x0
    // 0x85fe1c: r0 = _List.of()
    //     0x85fe1c: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0x85fe20: LeaveFrame
    //     0x85fe20: mov             SP, fp
    //     0x85fe24: ldp             fp, lr, [SP], #0x10
    // 0x85fe28: ret
    //     0x85fe28: ret             
    // 0x85fe2c: r1 = <TextBox>
    //     0x85fe2c: ldr             x1, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0x85fe30: r2 = 0
    //     0x85fe30: mov             x2, #0
    // 0x85fe34: r0 = _GrowableList()
    //     0x85fe34: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x85fe38: LeaveFrame
    //     0x85fe38: mov             SP, fp
    //     0x85fe3c: ldp             fp, lr, [SP], #0x10
    // 0x85fe40: ret
    //     0x85fe40: ret             
    // 0x85fe44: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85fe44: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85fe48: str             x16, [SP]
    // 0x85fe4c: r0 = _throwNew()
    //     0x85fe4c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85fe50: brk             #0
    // 0x85fe54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85fe54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85fe58: b               #0x85fcb8
    // 0x85fe5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85fe5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85fe60: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85fe60: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] TextBox <anonymous closure>(dynamic, TextBox) {
    // ** addr: 0x85fe64, size: 0x44
    // 0x85fe64: EnterFrame
    //     0x85fe64: stp             fp, lr, [SP, #-0x10]!
    //     0x85fe68: mov             fp, SP
    // 0x85fe6c: ldr             x0, [fp, #0x18]
    // 0x85fe70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85fe70: ldur            w1, [x0, #0x17]
    // 0x85fe74: DecompressPointer r1
    //     0x85fe74: add             x1, x1, HEAP, lsl #32
    // 0x85fe78: CheckStackOverflow
    //     0x85fe78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85fe7c: cmp             SP, x16
    //     0x85fe80: b.ls            #0x85fea0
    // 0x85fe84: LoadField: r2 = r1->field_f
    //     0x85fe84: ldur            w2, [x1, #0xf]
    // 0x85fe88: DecompressPointer r2
    //     0x85fe88: add             x2, x2, HEAP, lsl #32
    // 0x85fe8c: ldr             x1, [fp, #0x10]
    // 0x85fe90: r0 = _shiftTextBox()
    //     0x85fe90: bl              #0x85fea8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_shiftTextBox
    // 0x85fe94: LeaveFrame
    //     0x85fe94: mov             SP, fp
    //     0x85fe98: ldp             fp, lr, [SP], #0x10
    // 0x85fe9c: ret
    //     0x85fe9c: ret             
    // 0x85fea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85fea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85fea4: b               #0x85fe84
  }
  static _ _shiftTextBox(/* No info */) {
    // ** addr: 0x85fea8, size: 0x88
    // 0x85fea8: EnterFrame
    //     0x85fea8: stp             fp, lr, [SP, #-0x10]!
    //     0x85feac: mov             fp, SP
    // 0x85feb0: AllocStack(0x28)
    //     0x85feb0: sub             SP, SP, #0x28
    // 0x85feb4: LoadField: d0 = r1->field_7
    //     0x85feb4: ldur            d0, [x1, #7]
    // 0x85feb8: LoadField: d1 = r2->field_7
    //     0x85feb8: ldur            d1, [x2, #7]
    // 0x85febc: fadd            d2, d0, d1
    // 0x85fec0: stur            d2, [fp, #-0x28]
    // 0x85fec4: LoadField: d0 = r1->field_f
    //     0x85fec4: ldur            d0, [x1, #0xf]
    // 0x85fec8: LoadField: d3 = r2->field_f
    //     0x85fec8: ldur            d3, [x2, #0xf]
    // 0x85fecc: fadd            d4, d0, d3
    // 0x85fed0: stur            d4, [fp, #-0x20]
    // 0x85fed4: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x85fed4: ldur            d0, [x1, #0x17]
    // 0x85fed8: fadd            d5, d0, d1
    // 0x85fedc: stur            d5, [fp, #-0x18]
    // 0x85fee0: LoadField: d0 = r1->field_1f
    //     0x85fee0: ldur            d0, [x1, #0x1f]
    // 0x85fee4: fadd            d1, d0, d3
    // 0x85fee8: stur            d1, [fp, #-0x10]
    // 0x85feec: LoadField: r0 = r1->field_27
    //     0x85feec: ldur            w0, [x1, #0x27]
    // 0x85fef0: DecompressPointer r0
    //     0x85fef0: add             x0, x0, HEAP, lsl #32
    // 0x85fef4: stur            x0, [fp, #-8]
    // 0x85fef8: r0 = TextBox()
    //     0x85fef8: bl              #0x85eb2c  ; AllocateTextBoxStub -> TextBox (size=0x2c)
    // 0x85fefc: ldur            d0, [fp, #-0x28]
    // 0x85ff00: StoreField: r0->field_7 = d0
    //     0x85ff00: stur            d0, [x0, #7]
    // 0x85ff04: ldur            d0, [fp, #-0x20]
    // 0x85ff08: StoreField: r0->field_f = d0
    //     0x85ff08: stur            d0, [x0, #0xf]
    // 0x85ff0c: ldur            d0, [fp, #-0x18]
    // 0x85ff10: ArrayStore: r0[0] = d0  ; List_8
    //     0x85ff10: stur            d0, [x0, #0x17]
    // 0x85ff14: ldur            d0, [fp, #-0x10]
    // 0x85ff18: StoreField: r0->field_1f = d0
    //     0x85ff18: stur            d0, [x0, #0x1f]
    // 0x85ff1c: ldur            x1, [fp, #-8]
    // 0x85ff20: StoreField: r0->field_27 = r1
    //     0x85ff20: stur            w1, [x0, #0x27]
    // 0x85ff24: LeaveFrame
    //     0x85ff24: mov             SP, fp
    //     0x85ff28: ldp             fp, lr, [SP], #0x10
    // 0x85ff2c: ret
    //     0x85ff2c: ret             
  }
  _ layout(/* No info */) {
    // ** addr: 0x86018c, size: 0x550
    // 0x86018c: EnterFrame
    //     0x86018c: stp             fp, lr, [SP, #-0x10]!
    //     0x860190: mov             fp, SP
    // 0x860194: AllocStack(0x58)
    //     0x860194: sub             SP, SP, #0x58
    // 0x860198: SetupParameters(TextPainter this /* r1 => r0, fp-0x10 */, {_Double maxWidth = inf /* d2, fp-0x40 */, _Double minWidth = 0.000000 /* d3, fp-0x38 */})
    //     0x860198: mov             x0, x1
    //     0x86019c: stur            x1, [fp, #-0x10]
    //     0x8601a0: ldur            w1, [x4, #0x13]
    //     0x8601a4: ldur            w2, [x4, #0x1f]
    //     0x8601a8: add             x2, x2, HEAP, lsl #32
    //     0x8601ac: ldr             x16, [PP, #0x4cb0]  ; [pp+0x4cb0] "maxWidth"
    //     0x8601b0: cmp             w2, w16
    //     0x8601b4: b.ne            #0x8601dc
    //     0x8601b8: ldur            w2, [x4, #0x23]
    //     0x8601bc: add             x2, x2, HEAP, lsl #32
    //     0x8601c0: sub             w3, w1, w2
    //     0x8601c4: add             x2, fp, w3, sxtw #2
    //     0x8601c8: ldr             x2, [x2, #8]
    //     0x8601cc: ldur            d0, [x2, #7]
    //     0x8601d0: mov             v2.16b, v0.16b
    //     0x8601d4: mov             x2, #1
    //     0x8601d8: b               #0x8601e4
    //     0x8601dc: ldr             d2, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    //     0x8601e0: mov             x2, #0
    //     0x8601e4: stur            d2, [fp, #-0x40]
    //     0x8601e8: lsl             x3, x2, #1
    //     0x8601ec: lsl             w2, w3, #1
    //     0x8601f0: add             w3, w2, #8
    //     0x8601f4: add             x16, x4, w3, sxtw #1
    //     0x8601f8: ldur            w5, [x16, #0xf]
    //     0x8601fc: add             x5, x5, HEAP, lsl #32
    //     0x860200: ldr             x16, [PP, #0x4cb8]  ; [pp+0x4cb8] "minWidth"
    //     0x860204: cmp             w5, w16
    //     0x860208: b.ne            #0x860234
    //     0x86020c: add             w3, w2, #0xa
    //     0x860210: add             x16, x4, w3, sxtw #1
    //     0x860214: ldur            w2, [x16, #0xf]
    //     0x860218: add             x2, x2, HEAP, lsl #32
    //     0x86021c: sub             w3, w1, w2
    //     0x860220: add             x1, fp, w3, sxtw #2
    //     0x860224: ldr             x1, [x1, #8]
    //     0x860228: ldur            d0, [x1, #7]
    //     0x86022c: mov             v3.16b, v0.16b
    //     0x860230: b               #0x860238
    //     0x860234: eor             v3.16b, v3.16b, v3.16b
    //     0x860238: stur            d3, [fp, #-0x38]
    // 0x86023c: CheckStackOverflow
    //     0x86023c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860240: cmp             SP, x16
    //     0x860244: b.ls            #0x8606a4
    // 0x860248: LoadField: r2 = r0->field_7
    //     0x860248: ldur            w2, [x0, #7]
    // 0x86024c: DecompressPointer r2
    //     0x86024c: add             x2, x2, HEAP, lsl #32
    // 0x860250: stur            x2, [fp, #-8]
    // 0x860254: cmp             w2, NULL
    // 0x860258: b.eq            #0x860280
    // 0x86025c: mov             x1, x2
    // 0x860260: mov             v0.16b, v3.16b
    // 0x860264: mov             v1.16b, v2.16b
    // 0x860268: r0 = _resizeToFit()
    //     0x860268: bl              #0x8608e0  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::_resizeToFit
    // 0x86026c: tbnz            w0, #4, #0x860280
    // 0x860270: r0 = Null
    //     0x860270: mov             x0, NULL
    // 0x860274: LeaveFrame
    //     0x860274: mov             SP, fp
    //     0x860278: ldp             fp, lr, [SP], #0x10
    // 0x86027c: ret
    //     0x86027c: ret             
    // 0x860280: ldur            x0, [fp, #-0x10]
    // 0x860284: LoadField: r3 = r0->field_f
    //     0x860284: ldur            w3, [x0, #0xf]
    // 0x860288: DecompressPointer r3
    //     0x860288: add             x3, x3, HEAP, lsl #32
    // 0x86028c: stur            x3, [fp, #-0x20]
    // 0x860290: cmp             w3, NULL
    // 0x860294: b.eq            #0x86062c
    // 0x860298: LoadField: r4 = r0->field_1b
    //     0x860298: ldur            w4, [x0, #0x1b]
    // 0x86029c: DecompressPointer r4
    //     0x86029c: add             x4, x4, HEAP, lsl #32
    // 0x8602a0: stur            x4, [fp, #-0x18]
    // 0x8602a4: cmp             w4, NULL
    // 0x8602a8: b.eq            #0x860648
    // 0x8602ac: ldur            d0, [fp, #-0x40]
    // 0x8602b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8602b0: ldur            w1, [x0, #0x17]
    // 0x8602b4: DecompressPointer r1
    //     0x8602b4: add             x1, x1, HEAP, lsl #32
    // 0x8602b8: mov             x2, x4
    // 0x8602bc: r0 = _computePaintOffsetFraction()
    //     0x8602bc: bl              #0x85e020  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computePaintOffsetFraction
    // 0x8602c0: mov             v1.16b, v0.16b
    // 0x8602c4: ldur            d0, [fp, #-0x40]
    // 0x8602c8: stur            d1, [fp, #-0x48]
    // 0x8602cc: mov             x0, v0.d[0]
    // 0x8602d0: and             x0, x0, #0x7fffffffffffffff
    // 0x8602d4: r17 = 9218868437227405312
    //     0x8602d4: mov             x17, #0x7ff0000000000000
    // 0x8602d8: cmp             x0, x17
    // 0x8602dc: b.eq            #0x8602e8
    // 0x8602e0: fcmp            d0, d0
    // 0x8602e4: b.vc            #0x8602f4
    // 0x8602e8: d2 = 0.000000
    //     0x8602e8: eor             v2.16b, v2.16b, v2.16b
    // 0x8602ec: fcmp            d1, d2
    // 0x8602f0: b.ne            #0x860324
    // 0x8602f4: r0 = inline_Allocate_Double()
    //     0x8602f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8602f8: add             x0, x0, #0x10
    //     0x8602fc: cmp             x1, x0
    //     0x860300: b.ls            #0x8606ac
    //     0x860304: str             x0, [THR, #0x60]  ; THR::top
    //     0x860308: sub             x0, x0, #0xf
    //     0x86030c: mov             x1, #0xe19c
    //     0x860310: movk            x1, #3, lsl #16
    //     0x860314: stur            x1, [x0, #-1]
    // 0x860318: dmb             ishst
    // 0x86031c: StoreField: r0->field_7 = d0
    //     0x86031c: stur            d0, [x0, #7]
    // 0x860320: b               #0x8603b4
    // 0x860324: ldur            x0, [fp, #-8]
    // 0x860328: cmp             w0, NULL
    // 0x86032c: b.ne            #0x860338
    // 0x860330: r0 = Null
    //     0x860330: mov             x0, NULL
    // 0x860334: b               #0x8603b4
    // 0x860338: LoadField: r1 = r0->field_7
    //     0x860338: ldur            w1, [x0, #7]
    // 0x86033c: DecompressPointer r1
    //     0x86033c: add             x1, x1, HEAP, lsl #32
    // 0x860340: LoadField: r2 = r1->field_f
    //     0x860340: ldur            w2, [x1, #0xf]
    // 0x860344: DecompressPointer r2
    //     0x860344: add             x2, x2, HEAP, lsl #32
    // 0x860348: stur            x2, [fp, #-0x30]
    // 0x86034c: LoadField: r1 = r2->field_7
    //     0x86034c: ldur            w1, [x2, #7]
    // 0x860350: DecompressPointer r1
    //     0x860350: add             x1, x1, HEAP, lsl #32
    // 0x860354: cmp             w1, NULL
    // 0x860358: b.eq            #0x8606bc
    // 0x86035c: LoadField: r3 = r1->field_7
    //     0x86035c: ldur            x3, [x1, #7]
    // 0x860360: ldr             x1, [x3]
    // 0x860364: cbz             x1, #0x860664
    // 0x860368: mov             x3, x1
    // 0x86036c: stur            x3, [fp, #-0x28]
    // 0x860370: r1 = <Never>
    //     0x860370: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860374: r0 = Pointer()
    //     0x860374: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x860378: mov             x1, x0
    // 0x86037c: ldur            x0, [fp, #-0x28]
    // 0x860380: StoreField: r1->field_7 = r0
    //     0x860380: stur            x0, [x1, #7]
    // 0x860384: r0 = _maxIntrinsicWidth$Getter$FfiNative()
    //     0x860384: bl              #0x86085c  ; [dart:ui] _NativeParagraph::_maxIntrinsicWidth$Getter$FfiNative
    // 0x860388: r0 = inline_Allocate_Double()
    //     0x860388: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x86038c: add             x0, x0, #0x10
    //     0x860390: cmp             x1, x0
    //     0x860394: b.ls            #0x8606c0
    //     0x860398: str             x0, [THR, #0x60]  ; THR::top
    //     0x86039c: sub             x0, x0, #0xf
    //     0x8603a0: mov             x1, #0xe19c
    //     0x8603a4: movk            x1, #3, lsl #16
    //     0x8603a8: stur            x1, [x0, #-1]
    // 0x8603ac: dmb             ishst
    // 0x8603b0: StoreField: r0->field_7 = d0
    //     0x8603b0: stur            d0, [x0, #7]
    // 0x8603b4: stur            x0, [fp, #-0x30]
    // 0x8603b8: cmp             w0, NULL
    // 0x8603bc: b.ne            #0x8603c8
    // 0x8603c0: ldur            d0, [fp, #-0x40]
    // 0x8603c4: b               #0x8603cc
    // 0x8603c8: LoadField: d0 = r0->field_7
    //     0x8603c8: ldur            d0, [x0, #7]
    // 0x8603cc: ldur            x1, [fp, #-8]
    // 0x8603d0: stur            d0, [fp, #-0x50]
    // 0x8603d4: cmp             w1, NULL
    // 0x8603d8: b.ne            #0x8603e4
    // 0x8603dc: r1 = Null
    //     0x8603dc: mov             x1, NULL
    // 0x8603e0: b               #0x8603f4
    // 0x8603e4: LoadField: r2 = r1->field_7
    //     0x8603e4: ldur            w2, [x1, #7]
    // 0x8603e8: DecompressPointer r2
    //     0x8603e8: add             x2, x2, HEAP, lsl #32
    // 0x8603ec: LoadField: r1 = r2->field_f
    //     0x8603ec: ldur            w1, [x2, #0xf]
    // 0x8603f0: DecompressPointer r1
    //     0x8603f0: add             x1, x1, HEAP, lsl #32
    // 0x8603f4: cmp             w1, NULL
    // 0x8603f8: b.ne            #0x86040c
    // 0x8603fc: ldur            x1, [fp, #-0x10]
    // 0x860400: ldur            x2, [fp, #-0x20]
    // 0x860404: r0 = _createParagraph()
    //     0x860404: bl              #0x8607b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraph
    // 0x860408: b               #0x860410
    // 0x86040c: mov             x0, x1
    // 0x860410: stur            x0, [fp, #-8]
    // 0x860414: LoadField: r1 = r0->field_7
    //     0x860414: ldur            w1, [x0, #7]
    // 0x860418: DecompressPointer r1
    //     0x860418: add             x1, x1, HEAP, lsl #32
    // 0x86041c: cmp             w1, NULL
    // 0x860420: b.eq            #0x8606d0
    // 0x860424: LoadField: r2 = r1->field_7
    //     0x860424: ldur            x2, [x1, #7]
    // 0x860428: ldr             x1, [x2]
    // 0x86042c: cbz             x1, #0x860674
    // 0x860430: ldur            x3, [fp, #-0x10]
    // 0x860434: ldur            x2, [fp, #-0x30]
    // 0x860438: ldur            x4, [fp, #-0x18]
    // 0x86043c: mov             x5, x1
    // 0x860440: stur            x5, [fp, #-0x28]
    // 0x860444: r1 = <Never>
    //     0x860444: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860448: r0 = Pointer()
    //     0x860448: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x86044c: mov             x1, x0
    // 0x860450: ldur            x0, [fp, #-0x28]
    // 0x860454: StoreField: r1->field_7 = r0
    //     0x860454: stur            x0, [x1, #7]
    // 0x860458: ldur            d0, [fp, #-0x50]
    // 0x86045c: r0 = __layout$Method$FfiNative()
    //     0x86045c: bl              #0x85a058  ; [dart:ui] _NativeParagraph::__layout$Method$FfiNative
    // 0x860460: r0 = _TextLayout()
    //     0x860460: bl              #0x8607ac  ; Allocate_TextLayoutStub -> _TextLayout (size=0x18)
    // 0x860464: mov             x2, x0
    // 0x860468: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x86046c: stur            x2, [fp, #-0x20]
    // 0x860470: StoreField: r2->field_13 = r0
    //     0x860470: stur            w0, [x2, #0x13]
    // 0x860474: ldur            x0, [fp, #-8]
    // 0x860478: StoreField: r2->field_f = r0
    //     0x860478: stur            w0, [x2, #0xf]
    // 0x86047c: ldur            x1, [fp, #-0x18]
    // 0x860480: StoreField: r2->field_7 = r1
    //     0x860480: stur            w1, [x2, #7]
    // 0x860484: ldur            x3, [fp, #-0x10]
    // 0x860488: StoreField: r2->field_b = r3
    //     0x860488: stur            w3, [x2, #0xb]
    // 0x86048c: mov             x1, x2
    // 0x860490: ldur            d0, [fp, #-0x38]
    // 0x860494: ldur            d1, [fp, #-0x40]
    // 0x860498: r0 = _contentWidthFor()
    //     0x860498: bl              #0x8606e8  ; [package:flutter/src/painting/text_painter.dart] _TextLayout::_contentWidthFor
    // 0x86049c: ldur            x0, [fp, #-0x30]
    // 0x8604a0: stur            d0, [fp, #-0x40]
    // 0x8604a4: cmp             w0, NULL
    // 0x8604a8: b.ne            #0x8605c0
    // 0x8604ac: ldur            d1, [fp, #-0x38]
    // 0x8604b0: mov             x0, v1.d[0]
    // 0x8604b4: and             x0, x0, #0x7fffffffffffffff
    // 0x8604b8: r17 = 9218868437227405312
    //     0x8604b8: mov             x17, #0x7ff0000000000000
    // 0x8604bc: cmp             x0, x17
    // 0x8604c0: b.eq            #0x8605b0
    // 0x8604c4: fcmp            d1, d1
    // 0x8604c8: b.vs            #0x8605a0
    // 0x8604cc: ldur            x0, [fp, #-0x20]
    // 0x8604d0: LoadField: r2 = r0->field_f
    //     0x8604d0: ldur            w2, [x0, #0xf]
    // 0x8604d4: DecompressPointer r2
    //     0x8604d4: add             x2, x2, HEAP, lsl #32
    // 0x8604d8: stur            x2, [fp, #-0x18]
    // 0x8604dc: LoadField: r1 = r2->field_7
    //     0x8604dc: ldur            w1, [x2, #7]
    // 0x8604e0: DecompressPointer r1
    //     0x8604e0: add             x1, x1, HEAP, lsl #32
    // 0x8604e4: cmp             w1, NULL
    // 0x8604e8: b.eq            #0x8606d4
    // 0x8604ec: LoadField: r3 = r1->field_7
    //     0x8604ec: ldur            x3, [x1, #7]
    // 0x8604f0: ldr             x1, [x3]
    // 0x8604f4: cbz             x1, #0x860684
    // 0x8604f8: ldur            x3, [fp, #-8]
    // 0x8604fc: mov             x4, x1
    // 0x860500: stur            x4, [fp, #-0x28]
    // 0x860504: r1 = <Never>
    //     0x860504: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860508: r0 = Pointer()
    //     0x860508: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x86050c: mov             x1, x0
    // 0x860510: ldur            x0, [fp, #-0x28]
    // 0x860514: StoreField: r1->field_7 = r0
    //     0x860514: stur            x0, [x1, #7]
    // 0x860518: r0 = _maxIntrinsicWidth$Getter$FfiNative()
    //     0x860518: bl              #0x86085c  ; [dart:ui] _NativeParagraph::_maxIntrinsicWidth$Getter$FfiNative
    // 0x86051c: stur            d0, [fp, #-0x38]
    // 0x860520: ldur            x0, [fp, #-8]
    // 0x860524: LoadField: r1 = r0->field_7
    //     0x860524: ldur            w1, [x0, #7]
    // 0x860528: DecompressPointer r1
    //     0x860528: add             x1, x1, HEAP, lsl #32
    // 0x86052c: cmp             w1, NULL
    // 0x860530: b.eq            #0x8606d8
    // 0x860534: LoadField: r2 = r1->field_7
    //     0x860534: ldur            x2, [x1, #7]
    // 0x860538: ldr             x1, [x2]
    // 0x86053c: cbz             x1, #0x860694
    // 0x860540: ldur            d2, [fp, #-0x48]
    // 0x860544: ldur            x2, [fp, #-0x20]
    // 0x860548: ldur            d1, [fp, #-0x40]
    // 0x86054c: mov             x3, x1
    // 0x860550: stur            x3, [fp, #-0x28]
    // 0x860554: r1 = <Never>
    //     0x860554: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860558: r0 = Pointer()
    //     0x860558: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x86055c: mov             x1, x0
    // 0x860560: ldur            x0, [fp, #-0x28]
    // 0x860564: StoreField: r1->field_7 = r0
    //     0x860564: stur            x0, [x1, #7]
    // 0x860568: ldur            d0, [fp, #-0x38]
    // 0x86056c: r0 = __layout$Method$FfiNative()
    //     0x86056c: bl              #0x85a058  ; [dart:ui] _NativeParagraph::__layout$Method$FfiNative
    // 0x860570: r0 = _TextPainterLayoutCacheWithOffset()
    //     0x860570: bl              #0x8606dc  ; Allocate_TextPainterLayoutCacheWithOffsetStub -> _TextPainterLayoutCacheWithOffset (size=0x30)
    // 0x860574: mov             x1, x0
    // 0x860578: ldur            x0, [fp, #-0x20]
    // 0x86057c: StoreField: r1->field_7 = r0
    //     0x86057c: stur            w0, [x1, #7]
    // 0x860580: ldur            d0, [fp, #-0x48]
    // 0x860584: StoreField: r1->field_1b = d0
    //     0x860584: stur            d0, [x1, #0x1b]
    // 0x860588: ldur            d0, [fp, #-0x38]
    // 0x86058c: StoreField: r1->field_b = d0
    //     0x86058c: stur            d0, [x1, #0xb]
    // 0x860590: ldur            d1, [fp, #-0x40]
    // 0x860594: StoreField: r1->field_13 = d1
    //     0x860594: stur            d1, [x1, #0x13]
    // 0x860598: mov             x0, x1
    // 0x86059c: b               #0x8605fc
    // 0x8605a0: mov             v1.16b, v0.16b
    // 0x8605a4: ldur            d0, [fp, #-0x48]
    // 0x8605a8: ldur            x0, [fp, #-0x20]
    // 0x8605ac: b               #0x8605cc
    // 0x8605b0: mov             v1.16b, v0.16b
    // 0x8605b4: ldur            d0, [fp, #-0x48]
    // 0x8605b8: ldur            x0, [fp, #-0x20]
    // 0x8605bc: b               #0x8605cc
    // 0x8605c0: mov             v1.16b, v0.16b
    // 0x8605c4: ldur            d0, [fp, #-0x48]
    // 0x8605c8: ldur            x0, [fp, #-0x20]
    // 0x8605cc: ldur            d2, [fp, #-0x50]
    // 0x8605d0: r0 = _TextPainterLayoutCacheWithOffset()
    //     0x8605d0: bl              #0x8606dc  ; Allocate_TextPainterLayoutCacheWithOffsetStub -> _TextPainterLayoutCacheWithOffset (size=0x30)
    // 0x8605d4: mov             x1, x0
    // 0x8605d8: ldur            x0, [fp, #-0x20]
    // 0x8605dc: StoreField: r1->field_7 = r0
    //     0x8605dc: stur            w0, [x1, #7]
    // 0x8605e0: ldur            d0, [fp, #-0x48]
    // 0x8605e4: StoreField: r1->field_1b = d0
    //     0x8605e4: stur            d0, [x1, #0x1b]
    // 0x8605e8: ldur            d0, [fp, #-0x50]
    // 0x8605ec: StoreField: r1->field_b = d0
    //     0x8605ec: stur            d0, [x1, #0xb]
    // 0x8605f0: ldur            d0, [fp, #-0x40]
    // 0x8605f4: StoreField: r1->field_13 = d0
    //     0x8605f4: stur            d0, [x1, #0x13]
    // 0x8605f8: mov             x0, x1
    // 0x8605fc: ldur            x1, [fp, #-0x10]
    // 0x860600: StoreField: r1->field_7 = r0
    //     0x860600: stur            w0, [x1, #7]
    //     0x860604: ldurb           w16, [x1, #-1]
    //     0x860608: ldurb           w17, [x0, #-1]
    //     0x86060c: and             x16, x17, x16, lsr #2
    //     0x860610: tst             x16, HEAP, lsr #32
    //     0x860614: b.eq            #0x86061c
    //     0x860618: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86061c: r0 = Null
    //     0x86061c: mov             x0, NULL
    // 0x860620: LeaveFrame
    //     0x860620: mov             SP, fp
    //     0x860624: ldp             fp, lr, [SP], #0x10
    // 0x860628: ret
    //     0x860628: ret             
    // 0x86062c: r0 = StateError()
    //     0x86062c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x860630: mov             x1, x0
    // 0x860634: r0 = "TextPainter.text must be set to a non-null value before using the TextPainter."
    //     0x860634: ldr             x0, [PP, #0x4cc0]  ; [pp+0x4cc0] "TextPainter.text must be set to a non-null value before using the TextPainter."
    // 0x860638: StoreField: r1->field_b = r0
    //     0x860638: stur            w0, [x1, #0xb]
    // 0x86063c: mov             x0, x1
    // 0x860640: r0 = Throw()
    //     0x860640: bl              #0x13ddb2c  ; ThrowStub
    // 0x860644: brk             #0
    // 0x860648: r0 = StateError()
    //     0x860648: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x86064c: mov             x1, x0
    // 0x860650: r0 = "TextPainter.textDirection must be set to a non-null value before using the TextPainter."
    //     0x860650: ldr             x0, [PP, #0x4cc8]  ; [pp+0x4cc8] "TextPainter.textDirection must be set to a non-null value before using the TextPainter."
    // 0x860654: StoreField: r1->field_b = r0
    //     0x860654: stur            w0, [x1, #0xb]
    // 0x860658: mov             x0, x1
    // 0x86065c: r0 = Throw()
    //     0x86065c: bl              #0x13ddb2c  ; ThrowStub
    // 0x860660: brk             #0
    // 0x860664: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860664: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860668: str             x16, [SP]
    // 0x86066c: r0 = _throwNew()
    //     0x86066c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860670: brk             #0
    // 0x860674: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860674: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860678: str             x16, [SP]
    // 0x86067c: r0 = _throwNew()
    //     0x86067c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860680: brk             #0
    // 0x860684: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860684: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860688: str             x16, [SP]
    // 0x86068c: r0 = _throwNew()
    //     0x86068c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860690: brk             #0
    // 0x860694: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860694: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860698: str             x16, [SP]
    // 0x86069c: r0 = _throwNew()
    //     0x86069c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x8606a0: brk             #0
    // 0x8606a4: r0 = StackOverflowSharedWithFPURegs()
    //     0x8606a4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x8606a8: b               #0x860248
    // 0x8606ac: stp             q0, q1, [SP, #-0x20]!
    // 0x8606b0: r0 = AllocateDouble()
    //     0x8606b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8606b4: ldp             q0, q1, [SP], #0x20
    // 0x8606b8: b               #0x86031c
    // 0x8606bc: r0 = NullErrorSharedWithFPURegs()
    //     0x8606bc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x8606c0: SaveReg d0
    //     0x8606c0: str             q0, [SP, #-0x10]!
    // 0x8606c4: r0 = AllocateDouble()
    //     0x8606c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8606c8: RestoreReg d0
    //     0x8606c8: ldr             q0, [SP], #0x10
    // 0x8606cc: b               #0x8603b0
    // 0x8606d0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8606d0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x8606d4: r0 = NullErrorSharedWithFPURegs()
    //     0x8606d4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x8606d8: r0 = NullErrorSharedWithFPURegs()
    //     0x8606d8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _createParagraph(/* No info */) {
    // ** addr: 0x8607b8, size: 0xa4
    // 0x8607b8: EnterFrame
    //     0x8607b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8607bc: mov             fp, SP
    // 0x8607c0: AllocStack(0x18)
    //     0x8607c0: sub             SP, SP, #0x18
    // 0x8607c4: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8607c4: mov             x0, x2
    //     0x8607c8: stur            x2, [fp, #-0x10]
    //     0x8607cc: mov             x2, x1
    //     0x8607d0: stur            x1, [fp, #-8]
    // 0x8607d4: CheckStackOverflow
    //     0x8607d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8607d8: cmp             SP, x16
    //     0x8607dc: b.ls            #0x860854
    // 0x8607e0: mov             x1, x2
    // 0x8607e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8607e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8607e8: r0 = _createParagraphStyle()
    //     0x8607e8: bl              #0x85cd68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraphStyle
    // 0x8607ec: stur            x0, [fp, #-0x18]
    // 0x8607f0: r0 = _NativeParagraphBuilder()
    //     0x8607f0: bl              #0x85cd5c  ; Allocate_NativeParagraphBuilderStub -> _NativeParagraphBuilder (size=0x1c)
    // 0x8607f4: mov             x1, x0
    // 0x8607f8: ldur            x2, [fp, #-0x18]
    // 0x8607fc: stur            x0, [fp, #-0x18]
    // 0x860800: r0 = _NativeParagraphBuilder()
    //     0x860800: bl              #0x85c8a0  ; [dart:ui] _NativeParagraphBuilder::_NativeParagraphBuilder
    // 0x860804: ldur            x4, [fp, #-8]
    // 0x860808: LoadField: r5 = r4->field_1f
    //     0x860808: ldur            w5, [x4, #0x1f]
    // 0x86080c: DecompressPointer r5
    //     0x86080c: add             x5, x5, HEAP, lsl #32
    // 0x860810: LoadField: r3 = r4->field_3b
    //     0x860810: ldur            w3, [x4, #0x3b]
    // 0x860814: DecompressPointer r3
    //     0x860814: add             x3, x3, HEAP, lsl #32
    // 0x860818: ldur            x1, [fp, #-0x10]
    // 0x86081c: r0 = LoadClassIdInstr(r1)
    //     0x86081c: ldur            x0, [x1, #-1]
    //     0x860820: ubfx            x0, x0, #0xc, #0x14
    // 0x860824: ldur            x2, [fp, #-0x18]
    // 0x860828: r0 = GDT[cid_x0 + -0x8f]()
    //     0x860828: sub             lr, x0, #0x8f
    //     0x86082c: ldr             lr, [x21, lr, lsl #3]
    //     0x860830: blr             lr
    // 0x860834: ldur            x0, [fp, #-8]
    // 0x860838: r1 = false
    //     0x860838: add             x1, NULL, #0x30  ; false
    // 0x86083c: StoreField: r0->field_b = r1
    //     0x86083c: stur            w1, [x0, #0xb]
    // 0x860840: ldur            x1, [fp, #-0x18]
    // 0x860844: r0 = build()
    //     0x860844: bl              #0x85a0e8  ; [dart:ui] _NativeParagraphBuilder::build
    // 0x860848: LeaveFrame
    //     0x860848: mov             SP, fp
    //     0x86084c: ldp             fp, lr, [SP], #0x10
    // 0x860850: ret
    //     0x860850: ret             
    // 0x860854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860858: b               #0x8607e0
  }
  _ getFullHeightForCaret(/* No info */) {
    // ** addr: 0x86309c, size: 0x150
    // 0x86309c: EnterFrame
    //     0x86309c: stp             fp, lr, [SP, #-0x10]!
    //     0x8630a0: mov             fp, SP
    // 0x8630a4: AllocStack(0x20)
    //     0x8630a4: sub             SP, SP, #0x20
    // 0x8630a8: SetupParameters(TextPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8630a8: mov             x0, x1
    //     0x8630ac: stur            x1, [fp, #-8]
    //     0x8630b0: stur            x2, [fp, #-0x10]
    // 0x8630b4: CheckStackOverflow
    //     0x8630b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8630b8: cmp             SP, x16
    //     0x8630bc: b.ls            #0x8631d0
    // 0x8630c0: mov             x1, x0
    // 0x8630c4: r0 = _strutDisabled()
    //     0x8630c4: bl              #0x8631ec  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_strutDisabled
    // 0x8630c8: tbnz            w0, #4, #0x863130
    // 0x8630cc: ldur            x1, [fp, #-8]
    // 0x8630d0: ldur            x2, [fp, #-0x10]
    // 0x8630d4: r0 = _computeCaretMetrics()
    //     0x8630d4: bl              #0x85e254  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0x8630d8: cmp             w0, NULL
    // 0x8630dc: b.ne            #0x8630e8
    // 0x8630e0: r0 = Null
    //     0x8630e0: mov             x0, NULL
    // 0x8630e4: b               #0x863118
    // 0x8630e8: LoadField: d0 = r0->field_f
    //     0x8630e8: ldur            d0, [x0, #0xf]
    // 0x8630ec: r0 = inline_Allocate_Double()
    //     0x8630ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8630f0: add             x0, x0, #0x10
    //     0x8630f4: cmp             x1, x0
    //     0x8630f8: b.ls            #0x8631d8
    //     0x8630fc: str             x0, [THR, #0x60]  ; THR::top
    //     0x863100: sub             x0, x0, #0xf
    //     0x863104: mov             x1, #0xe19c
    //     0x863108: movk            x1, #3, lsl #16
    //     0x86310c: stur            x1, [x0, #-1]
    // 0x863110: dmb             ishst
    // 0x863114: StoreField: r0->field_7 = d0
    //     0x863114: stur            d0, [x0, #7]
    // 0x863118: cmp             w0, NULL
    // 0x86311c: b.eq            #0x863130
    // 0x863120: LoadField: d0 = r0->field_7
    //     0x863120: ldur            d0, [x0, #7]
    // 0x863124: LeaveFrame
    //     0x863124: mov             SP, fp
    //     0x863128: ldp             fp, lr, [SP], #0x10
    // 0x86312c: ret
    //     0x86312c: ret             
    // 0x863130: ldur            x1, [fp, #-8]
    // 0x863134: r0 = _getOrCreateLayoutTemplate()
    //     0x863134: bl              #0x859ea0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getOrCreateLayoutTemplate
    // 0x863138: stur            x0, [fp, #-8]
    // 0x86313c: LoadField: r1 = r0->field_7
    //     0x86313c: ldur            w1, [x0, #7]
    // 0x863140: DecompressPointer r1
    //     0x863140: add             x1, x1, HEAP, lsl #32
    // 0x863144: cmp             w1, NULL
    // 0x863148: b.eq            #0x8631e8
    // 0x86314c: LoadField: r2 = r1->field_7
    //     0x86314c: ldur            x2, [x1, #7]
    // 0x863150: ldr             x1, [x2]
    // 0x863154: cbz             x1, #0x8631c0
    // 0x863158: mov             x2, x1
    // 0x86315c: stur            x2, [fp, #-0x18]
    // 0x863160: r1 = <Never>
    //     0x863160: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x863164: r0 = Pointer()
    //     0x863164: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x863168: mov             x1, x0
    // 0x86316c: ldur            x0, [fp, #-0x18]
    // 0x863170: StoreField: r1->field_7 = r0
    //     0x863170: stur            x0, [x1, #7]
    // 0x863174: r2 = 0
    //     0x863174: mov             x2, #0
    // 0x863178: r3 = 1
    //     0x863178: mov             x3, #1
    // 0x86317c: r5 = 5
    //     0x86317c: mov             x5, #5
    // 0x863180: r6 = 0
    //     0x863180: mov             x6, #0
    // 0x863184: r0 = __getBoxesForRange$Method$FfiNative()
    //     0x863184: bl              #0x85eb58  ; [dart:ui] _NativeParagraph::__getBoxesForRange$Method$FfiNative
    // 0x863188: ldur            x1, [fp, #-8]
    // 0x86318c: mov             x2, x0
    // 0x863190: r0 = _decodeTextBoxes()
    //     0x863190: bl              #0x85e86c  ; [dart:ui] _NativeParagraph::_decodeTextBoxes
    // 0x863194: mov             x1, x0
    // 0x863198: r0 = single()
    //     0x863198: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0x86319c: mov             x1, x0
    // 0x8631a0: r0 = toRect()
    //     0x8631a0: bl              #0x861374  ; [dart:ui] TextBox::toRect
    // 0x8631a4: LoadField: d0 = r0->field_1f
    //     0x8631a4: ldur            d0, [x0, #0x1f]
    // 0x8631a8: LoadField: d1 = r0->field_f
    //     0x8631a8: ldur            d1, [x0, #0xf]
    // 0x8631ac: fsub            d2, d0, d1
    // 0x8631b0: mov             v0.16b, v2.16b
    // 0x8631b4: LeaveFrame
    //     0x8631b4: mov             SP, fp
    //     0x8631b8: ldp             fp, lr, [SP], #0x10
    // 0x8631bc: ret
    //     0x8631bc: ret             
    // 0x8631c0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x8631c0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x8631c4: str             x16, [SP]
    // 0x8631c8: r0 = _throwNew()
    //     0x8631c8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x8631cc: brk             #0
    // 0x8631d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8631d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8631d4: b               #0x8630c0
    // 0x8631d8: SaveReg d0
    //     0x8631d8: str             q0, [SP, #-0x10]!
    // 0x8631dc: r0 = AllocateDouble()
    //     0x8631dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8631e0: RestoreReg d0
    //     0x8631e0: ldr             q0, [SP], #0x10
    // 0x8631e4: b               #0x863114
    // 0x8631e8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8631e8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ _strutDisabled(/* No info */) {
    // ** addr: 0x8631ec, size: 0x80
    // 0x8631ec: EnterFrame
    //     0x8631ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8631f0: mov             fp, SP
    // 0x8631f4: AllocStack(0x18)
    //     0x8631f4: sub             SP, SP, #0x18
    // 0x8631f8: CheckStackOverflow
    //     0x8631f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8631fc: cmp             SP, x16
    //     0x863200: b.ls            #0x863264
    // 0x863204: LoadField: r0 = r1->field_2f
    //     0x863204: ldur            w0, [x1, #0x2f]
    // 0x863208: DecompressPointer r0
    //     0x863208: add             x0, x0, HEAP, lsl #32
    // 0x86320c: stur            x0, [fp, #-8]
    // 0x863210: cmp             w0, NULL
    // 0x863214: b.eq            #0x863228
    // 0x863218: r16 = Instance_StrutStyle
    //     0x863218: ldr             x16, [PP, #0x4c20]  ; [pp+0x4c20] Obj!StrutStyle@12b1ab1
    // 0x86321c: stp             x0, x16, [SP]
    // 0x863220: r0 = ==()
    //     0x863220: bl              #0x1278980  ; [package:flutter/src/painting/strut_style.dart] StrutStyle::==
    // 0x863224: tbnz            w0, #4, #0x863230
    // 0x863228: r0 = true
    //     0x863228: add             x0, NULL, #0x20  ; true
    // 0x86322c: b               #0x863258
    // 0x863230: ldur            x0, [fp, #-8]
    // 0x863234: LoadField: r1 = r0->field_13
    //     0x863234: ldur            w1, [x0, #0x13]
    // 0x863238: DecompressPointer r1
    //     0x863238: add             x1, x1, HEAP, lsl #32
    // 0x86323c: r0 = LoadClassIdInstr(r1)
    //     0x86323c: ldur            x0, [x1, #-1]
    //     0x863240: ubfx            x0, x0, #0xc, #0x14
    // 0x863244: r16 = 0.000000
    //     0x863244: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x863248: stp             x16, x1, [SP]
    // 0x86324c: mov             lr, x0
    // 0x863250: ldr             lr, [x21, lr, lsl #3]
    // 0x863254: blr             lr
    // 0x863258: LeaveFrame
    //     0x863258: mov             SP, fp
    //     0x86325c: ldp             fp, lr, [SP], #0x10
    // 0x863260: ret
    //     0x863260: ret             
    // 0x863264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863264: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863268: b               #0x863204
  }
  _ getPositionForOffset(/* No info */) {
    // ** addr: 0x86749c, size: 0x7c
    // 0x86749c: EnterFrame
    //     0x86749c: stp             fp, lr, [SP, #-0x10]!
    //     0x8674a0: mov             fp, SP
    // 0x8674a4: AllocStack(0x10)
    //     0x8674a4: sub             SP, SP, #0x10
    // 0x8674a8: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8674a8: mov             x0, x2
    //     0x8674ac: stur            x2, [fp, #-0x10]
    // 0x8674b0: CheckStackOverflow
    //     0x8674b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8674b4: cmp             SP, x16
    //     0x8674b8: b.ls            #0x86750c
    // 0x8674bc: LoadField: r2 = r1->field_7
    //     0x8674bc: ldur            w2, [x1, #7]
    // 0x8674c0: DecompressPointer r2
    //     0x8674c0: add             x2, x2, HEAP, lsl #32
    // 0x8674c4: cmp             w2, NULL
    // 0x8674c8: b.eq            #0x867514
    // 0x8674cc: LoadField: r1 = r2->field_7
    //     0x8674cc: ldur            w1, [x2, #7]
    // 0x8674d0: DecompressPointer r1
    //     0x8674d0: add             x1, x1, HEAP, lsl #32
    // 0x8674d4: LoadField: r3 = r1->field_f
    //     0x8674d4: ldur            w3, [x1, #0xf]
    // 0x8674d8: DecompressPointer r3
    //     0x8674d8: add             x3, x3, HEAP, lsl #32
    // 0x8674dc: mov             x1, x2
    // 0x8674e0: stur            x3, [fp, #-8]
    // 0x8674e4: r0 = paintOffset()
    //     0x8674e4: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x8674e8: ldur            x1, [fp, #-0x10]
    // 0x8674ec: mov             x2, x0
    // 0x8674f0: r0 = -()
    //     0x8674f0: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x8674f4: ldur            x1, [fp, #-8]
    // 0x8674f8: mov             x2, x0
    // 0x8674fc: r0 = getPositionForOffset()
    //     0x8674fc: bl              #0x867518  ; [dart:ui] _NativeParagraph::getPositionForOffset
    // 0x867500: LeaveFrame
    //     0x867500: mov             SP, fp
    //     0x867504: ldp             fp, lr, [SP], #0x10
    // 0x867508: ret
    //     0x867508: ret             
    // 0x86750c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86750c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x867510: b               #0x8674bc
    // 0x867514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867514: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getLineBoundary(/* No info */) {
    // ** addr: 0x870530, size: 0x54
    // 0x870530: EnterFrame
    //     0x870530: stp             fp, lr, [SP, #-0x10]!
    //     0x870534: mov             fp, SP
    // 0x870538: CheckStackOverflow
    //     0x870538: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87053c: cmp             SP, x16
    //     0x870540: b.ls            #0x870578
    // 0x870544: LoadField: r0 = r1->field_7
    //     0x870544: ldur            w0, [x1, #7]
    // 0x870548: DecompressPointer r0
    //     0x870548: add             x0, x0, HEAP, lsl #32
    // 0x87054c: cmp             w0, NULL
    // 0x870550: b.eq            #0x870580
    // 0x870554: LoadField: r1 = r0->field_7
    //     0x870554: ldur            w1, [x0, #7]
    // 0x870558: DecompressPointer r1
    //     0x870558: add             x1, x1, HEAP, lsl #32
    // 0x87055c: LoadField: r0 = r1->field_f
    //     0x87055c: ldur            w0, [x1, #0xf]
    // 0x870560: DecompressPointer r0
    //     0x870560: add             x0, x0, HEAP, lsl #32
    // 0x870564: mov             x1, x0
    // 0x870568: r0 = getLineBoundary()
    //     0x870568: bl              #0x870584  ; [dart:ui] _NativeParagraph::getLineBoundary
    // 0x87056c: LeaveFrame
    //     0x87056c: mov             SP, fp
    //     0x870570: ldp             fp, lr, [SP], #0x10
    // 0x870574: ret
    //     0x870574: ret             
    // 0x870578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870578: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87057c: b               #0x870544
    // 0x870580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870580: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ TextPainter(/* No info */) {
    // ** addr: 0xb135d4, size: 0x448
    // 0xb135d4: EnterFrame
    //     0xb135d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb135d8: mov             fp, SP
    // 0xb135dc: AllocStack(0x40)
    //     0xb135dc: sub             SP, SP, #0x40
    // 0xb135e0: SetupParameters(TextPainter this /* r1 => r1, fp-0x30 */, {dynamic ellipsis = Null /* r3, fp-0x28 */, dynamic locale = Null /* r5, fp-0x20 */, dynamic maxLines = Null /* r6, fp-0x18 */, dynamic strutStyle = Null /* r7, fp-0x10 */, dynamic text = Null /* r8 */, dynamic textAlign = Instance_TextAlign /* r9 */, dynamic textDirection = Null /* r10 */, dynamic textScaler = Instance__UnspecifiedTextScaler /* r4 */})
    //     0xb135e0: stur            x1, [fp, #-0x30]
    //     0xb135e4: ldur            w0, [x4, #0x13]
    //     0xb135e8: ldur            w2, [x4, #0x1f]
    //     0xb135ec: add             x2, x2, HEAP, lsl #32
    //     0xb135f0: ldr             x16, [PP, #0x4b50]  ; [pp+0x4b50] "ellipsis"
    //     0xb135f4: cmp             w2, w16
    //     0xb135f8: b.ne            #0xb1361c
    //     0xb135fc: ldur            w2, [x4, #0x23]
    //     0xb13600: add             x2, x2, HEAP, lsl #32
    //     0xb13604: sub             w3, w0, w2
    //     0xb13608: add             x2, fp, w3, sxtw #2
    //     0xb1360c: ldr             x2, [x2, #8]
    //     0xb13610: mov             x3, x2
    //     0xb13614: mov             x2, #1
    //     0xb13618: b               #0xb13624
    //     0xb1361c: mov             x3, NULL
    //     0xb13620: mov             x2, #0
    //     0xb13624: stur            x3, [fp, #-0x28]
    //     0xb13628: lsl             x5, x2, #1
    //     0xb1362c: lsl             w6, w5, #1
    //     0xb13630: add             w7, w6, #8
    //     0xb13634: add             x16, x4, w7, sxtw #1
    //     0xb13638: ldur            w8, [x16, #0xf]
    //     0xb1363c: add             x8, x8, HEAP, lsl #32
    //     0xb13640: ldr             x16, [PP, #0x4ae0]  ; [pp+0x4ae0] "locale"
    //     0xb13644: cmp             w8, w16
    //     0xb13648: b.ne            #0xb1367c
    //     0xb1364c: add             w2, w6, #0xa
    //     0xb13650: add             x16, x4, w2, sxtw #1
    //     0xb13654: ldur            w6, [x16, #0xf]
    //     0xb13658: add             x6, x6, HEAP, lsl #32
    //     0xb1365c: sub             w2, w0, w6
    //     0xb13660: add             x6, fp, w2, sxtw #2
    //     0xb13664: ldr             x6, [x6, #8]
    //     0xb13668: add             w2, w5, #2
    //     0xb1366c: sbfx            x5, x2, #1, #0x1f
    //     0xb13670: mov             x2, x5
    //     0xb13674: mov             x5, x6
    //     0xb13678: b               #0xb13680
    //     0xb1367c: mov             x5, NULL
    //     0xb13680: stur            x5, [fp, #-0x20]
    //     0xb13684: lsl             x6, x2, #1
    //     0xb13688: lsl             w7, w6, #1
    //     0xb1368c: add             w8, w7, #8
    //     0xb13690: add             x16, x4, w8, sxtw #1
    //     0xb13694: ldur            w9, [x16, #0xf]
    //     0xb13698: add             x9, x9, HEAP, lsl #32
    //     0xb1369c: ldr             x16, [PP, #0x4b68]  ; [pp+0x4b68] "maxLines"
    //     0xb136a0: cmp             w9, w16
    //     0xb136a4: b.ne            #0xb136d8
    //     0xb136a8: add             w2, w7, #0xa
    //     0xb136ac: add             x16, x4, w2, sxtw #1
    //     0xb136b0: ldur            w7, [x16, #0xf]
    //     0xb136b4: add             x7, x7, HEAP, lsl #32
    //     0xb136b8: sub             w2, w0, w7
    //     0xb136bc: add             x7, fp, w2, sxtw #2
    //     0xb136c0: ldr             x7, [x7, #8]
    //     0xb136c4: add             w2, w6, #2
    //     0xb136c8: sbfx            x6, x2, #1, #0x1f
    //     0xb136cc: mov             x2, x6
    //     0xb136d0: mov             x6, x7
    //     0xb136d4: b               #0xb136dc
    //     0xb136d8: mov             x6, NULL
    //     0xb136dc: stur            x6, [fp, #-0x18]
    //     0xb136e0: lsl             x7, x2, #1
    //     0xb136e4: lsl             w8, w7, #1
    //     0xb136e8: add             w9, w8, #8
    //     0xb136ec: add             x16, x4, w9, sxtw #1
    //     0xb136f0: ldur            w10, [x16, #0xf]
    //     0xb136f4: add             x10, x10, HEAP, lsl #32
    //     0xb136f8: ldr             x16, [PP, #0x4b70]  ; [pp+0x4b70] "strutStyle"
    //     0xb136fc: cmp             w10, w16
    //     0xb13700: b.ne            #0xb13734
    //     0xb13704: add             w2, w8, #0xa
    //     0xb13708: add             x16, x4, w2, sxtw #1
    //     0xb1370c: ldur            w8, [x16, #0xf]
    //     0xb13710: add             x8, x8, HEAP, lsl #32
    //     0xb13714: sub             w2, w0, w8
    //     0xb13718: add             x8, fp, w2, sxtw #2
    //     0xb1371c: ldr             x8, [x8, #8]
    //     0xb13720: add             w2, w7, #2
    //     0xb13724: sbfx            x7, x2, #1, #0x1f
    //     0xb13728: mov             x2, x7
    //     0xb1372c: mov             x7, x8
    //     0xb13730: b               #0xb13738
    //     0xb13734: mov             x7, NULL
    //     0xb13738: stur            x7, [fp, #-0x10]
    //     0xb1373c: lsl             x8, x2, #1
    //     0xb13740: lsl             w9, w8, #1
    //     0xb13744: add             w10, w9, #8
    //     0xb13748: add             x16, x4, w10, sxtw #1
    //     0xb1374c: ldur            w11, [x16, #0xf]
    //     0xb13750: add             x11, x11, HEAP, lsl #32
    //     0xb13754: ldr             x16, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    //     0xb13758: cmp             w11, w16
    //     0xb1375c: b.ne            #0xb13790
    //     0xb13760: add             w2, w9, #0xa
    //     0xb13764: add             x16, x4, w2, sxtw #1
    //     0xb13768: ldur            w9, [x16, #0xf]
    //     0xb1376c: add             x9, x9, HEAP, lsl #32
    //     0xb13770: sub             w2, w0, w9
    //     0xb13774: add             x9, fp, w2, sxtw #2
    //     0xb13778: ldr             x9, [x9, #8]
    //     0xb1377c: add             w2, w8, #2
    //     0xb13780: sbfx            x8, x2, #1, #0x1f
    //     0xb13784: mov             x2, x8
    //     0xb13788: mov             x8, x9
    //     0xb1378c: b               #0xb13794
    //     0xb13790: mov             x8, NULL
    //     0xb13794: lsl             x9, x2, #1
    //     0xb13798: lsl             w10, w9, #1
    //     0xb1379c: add             w11, w10, #8
    //     0xb137a0: add             x16, x4, w11, sxtw #1
    //     0xb137a4: ldur            w12, [x16, #0xf]
    //     0xb137a8: add             x12, x12, HEAP, lsl #32
    //     0xb137ac: ldr             x16, [PP, #0x4b78]  ; [pp+0x4b78] "textAlign"
    //     0xb137b0: cmp             w12, w16
    //     0xb137b4: b.ne            #0xb137e8
    //     0xb137b8: add             w2, w10, #0xa
    //     0xb137bc: add             x16, x4, w2, sxtw #1
    //     0xb137c0: ldur            w10, [x16, #0xf]
    //     0xb137c4: add             x10, x10, HEAP, lsl #32
    //     0xb137c8: sub             w2, w0, w10
    //     0xb137cc: add             x10, fp, w2, sxtw #2
    //     0xb137d0: ldr             x10, [x10, #8]
    //     0xb137d4: add             w2, w9, #2
    //     0xb137d8: sbfx            x9, x2, #1, #0x1f
    //     0xb137dc: mov             x2, x9
    //     0xb137e0: mov             x9, x10
    //     0xb137e4: b               #0xb137ec
    //     0xb137e8: ldr             x9, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    //     0xb137ec: lsl             x10, x2, #1
    //     0xb137f0: lsl             w11, w10, #1
    //     0xb137f4: add             w12, w11, #8
    //     0xb137f8: add             x16, x4, w12, sxtw #1
    //     0xb137fc: ldur            w13, [x16, #0xf]
    //     0xb13800: add             x13, x13, HEAP, lsl #32
    //     0xb13804: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xb13808: ldr             x16, [x16, #0x210]
    //     0xb1380c: cmp             w13, w16
    //     0xb13810: b.ne            #0xb13844
    //     0xb13814: add             w2, w11, #0xa
    //     0xb13818: add             x16, x4, w2, sxtw #1
    //     0xb1381c: ldur            w11, [x16, #0xf]
    //     0xb13820: add             x11, x11, HEAP, lsl #32
    //     0xb13824: sub             w2, w0, w11
    //     0xb13828: add             x11, fp, w2, sxtw #2
    //     0xb1382c: ldr             x11, [x11, #8]
    //     0xb13830: add             w2, w10, #2
    //     0xb13834: sbfx            x10, x2, #1, #0x1f
    //     0xb13838: mov             x2, x10
    //     0xb1383c: mov             x10, x11
    //     0xb13840: b               #0xb13848
    //     0xb13844: mov             x10, NULL
    //     0xb13848: lsl             x11, x2, #1
    //     0xb1384c: lsl             w2, w11, #1
    //     0xb13850: add             w11, w2, #8
    //     0xb13854: add             x16, x4, w11, sxtw #1
    //     0xb13858: ldur            w12, [x16, #0xf]
    //     0xb1385c: add             x12, x12, HEAP, lsl #32
    //     0xb13860: add             x16, PP, #0x12, lsl #12  ; [pp+0x12840] "textScaler"
    //     0xb13864: ldr             x16, [x16, #0x840]
    //     0xb13868: cmp             w12, w16
    //     0xb1386c: b.ne            #0xb13894
    //     0xb13870: add             w11, w2, #0xa
    //     0xb13874: add             x16, x4, w11, sxtw #1
    //     0xb13878: ldur            w2, [x16, #0xf]
    //     0xb1387c: add             x2, x2, HEAP, lsl #32
    //     0xb13880: sub             w4, w0, w2
    //     0xb13884: add             x0, fp, w4, sxtw #2
    //     0xb13888: ldr             x0, [x0, #8]
    //     0xb1388c: mov             x4, x0
    //     0xb13890: b               #0xb1389c
    //     0xb13894: add             x4, PP, #0x22, lsl #12  ; [pp+0x22028] Obj!_UnspecifiedTextScaler@129c671
    //     0xb13898: ldr             x4, [x4, #0x28]
    //     0xb1389c: add             x2, NULL, #0x20  ; true
    // 0xb1389c: r2 = true
    // 0xb138a0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xb138a4: stur            x4, [fp, #-8]
    // 0xb138a8: CheckStackOverflow
    //     0xb138a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb138ac: cmp             SP, x16
    //     0xb138b0: b.ls            #0xb13a14
    // 0xb138b4: StoreField: r1->field_b = r2
    //     0xb138b4: stur            w2, [x1, #0xb]
    // 0xb138b8: StoreField: r1->field_43 = r0
    //     0xb138b8: stur            w0, [x1, #0x43]
    // 0xb138bc: mov             x0, x8
    // 0xb138c0: StoreField: r1->field_f = r0
    //     0xb138c0: stur            w0, [x1, #0xf]
    //     0xb138c4: ldurb           w16, [x1, #-1]
    //     0xb138c8: ldurb           w17, [x0, #-1]
    //     0xb138cc: and             x16, x17, x16, lsr #2
    //     0xb138d0: tst             x16, HEAP, lsr #32
    //     0xb138d4: b.eq            #0xb138dc
    //     0xb138d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb138dc: mov             x0, x9
    // 0xb138e0: ArrayStore: r1[0] = r0  ; List_4
    //     0xb138e0: stur            w0, [x1, #0x17]
    //     0xb138e4: ldurb           w16, [x1, #-1]
    //     0xb138e8: ldurb           w17, [x0, #-1]
    //     0xb138ec: and             x16, x17, x16, lsr #2
    //     0xb138f0: tst             x16, HEAP, lsr #32
    //     0xb138f4: b.eq            #0xb138fc
    //     0xb138f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb138fc: mov             x0, x10
    // 0xb13900: StoreField: r1->field_1b = r0
    //     0xb13900: stur            w0, [x1, #0x1b]
    //     0xb13904: ldurb           w16, [x1, #-1]
    //     0xb13908: ldurb           w17, [x0, #-1]
    //     0xb1390c: and             x16, x17, x16, lsr #2
    //     0xb13910: tst             x16, HEAP, lsr #32
    //     0xb13914: b.eq            #0xb1391c
    //     0xb13918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1391c: r0 = LoadClassIdInstr(r4)
    //     0xb1391c: ldur            x0, [x4, #-1]
    //     0xb13920: ubfx            x0, x0, #0xc, #0x14
    // 0xb13924: r16 = Instance__UnspecifiedTextScaler
    //     0xb13924: add             x16, PP, #0x22, lsl #12  ; [pp+0x22028] Obj!_UnspecifiedTextScaler@129c671
    //     0xb13928: ldr             x16, [x16, #0x28]
    // 0xb1392c: stp             x16, x4, [SP]
    // 0xb13930: mov             lr, x0
    // 0xb13934: ldr             lr, [x21, lr, lsl #3]
    // 0xb13938: blr             lr
    // 0xb1393c: tbnz            w0, #4, #0xb13950
    // 0xb13940: r0 = _LinearTextScaler()
    //     0xb13940: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0xb13944: d0 = 1.000000
    //     0xb13944: fmov            d0, #1.00000000
    // 0xb13948: StoreField: r0->field_7 = d0
    //     0xb13948: stur            d0, [x0, #7]
    // 0xb1394c: b               #0xb13954
    // 0xb13950: ldur            x0, [fp, #-8]
    // 0xb13954: ldur            x1, [fp, #-0x30]
    // 0xb13958: r2 = Instance_TextWidthBasis
    //     0xb13958: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xb1395c: ldr             x2, [x2, #0x110]
    // 0xb13960: StoreField: r1->field_1f = r0
    //     0xb13960: stur            w0, [x1, #0x1f]
    //     0xb13964: ldurb           w16, [x1, #-1]
    //     0xb13968: ldurb           w17, [x0, #-1]
    //     0xb1396c: and             x16, x17, x16, lsr #2
    //     0xb13970: tst             x16, HEAP, lsr #32
    //     0xb13974: b.eq            #0xb1397c
    //     0xb13978: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1397c: ldur            x0, [fp, #-0x18]
    // 0xb13980: StoreField: r1->field_2b = r0
    //     0xb13980: stur            w0, [x1, #0x2b]
    //     0xb13984: tbz             w0, #0, #0xb139a0
    //     0xb13988: ldurb           w16, [x1, #-1]
    //     0xb1398c: ldurb           w17, [x0, #-1]
    //     0xb13990: and             x16, x17, x16, lsr #2
    //     0xb13994: tst             x16, HEAP, lsr #32
    //     0xb13998: b.eq            #0xb139a0
    //     0xb1399c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb139a0: ldur            x0, [fp, #-0x28]
    // 0xb139a4: StoreField: r1->field_23 = r0
    //     0xb139a4: stur            w0, [x1, #0x23]
    //     0xb139a8: ldurb           w16, [x1, #-1]
    //     0xb139ac: ldurb           w17, [x0, #-1]
    //     0xb139b0: and             x16, x17, x16, lsr #2
    //     0xb139b4: tst             x16, HEAP, lsr #32
    //     0xb139b8: b.eq            #0xb139c0
    //     0xb139bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb139c0: ldur            x0, [fp, #-0x20]
    // 0xb139c4: StoreField: r1->field_27 = r0
    //     0xb139c4: stur            w0, [x1, #0x27]
    //     0xb139c8: ldurb           w16, [x1, #-1]
    //     0xb139cc: ldurb           w17, [x0, #-1]
    //     0xb139d0: and             x16, x17, x16, lsr #2
    //     0xb139d4: tst             x16, HEAP, lsr #32
    //     0xb139d8: b.eq            #0xb139e0
    //     0xb139dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb139e0: ldur            x0, [fp, #-0x10]
    // 0xb139e4: StoreField: r1->field_2f = r0
    //     0xb139e4: stur            w0, [x1, #0x2f]
    //     0xb139e8: ldurb           w16, [x1, #-1]
    //     0xb139ec: ldurb           w17, [x0, #-1]
    //     0xb139f0: and             x16, x17, x16, lsr #2
    //     0xb139f4: tst             x16, HEAP, lsr #32
    //     0xb139f8: b.eq            #0xb13a00
    //     0xb139fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb13a00: StoreField: r1->field_33 = r2
    //     0xb13a00: stur            w2, [x1, #0x33]
    // 0xb13a04: r0 = Null
    //     0xb13a04: mov             x0, NULL
    // 0xb13a08: LeaveFrame
    //     0xb13a08: mov             SP, fp
    //     0xb13a0c: ldp             fp, lr, [SP], #0x10
    // 0xb13a10: ret
    //     0xb13a10: ret             
    // 0xb13a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb13a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb13a18: b               #0xb138b4
  }
  get _ minIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1c858, size: 0xa4
    // 0xb1c858: EnterFrame
    //     0xb1c858: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c85c: mov             fp, SP
    // 0xb1c860: AllocStack(0x18)
    //     0xb1c860: sub             SP, SP, #0x18
    // 0xb1c864: CheckStackOverflow
    //     0xb1c864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c868: cmp             SP, x16
    //     0xb1c86c: b.ls            #0xb1c8ec
    // 0xb1c870: LoadField: r0 = r1->field_7
    //     0xb1c870: ldur            w0, [x1, #7]
    // 0xb1c874: DecompressPointer r0
    //     0xb1c874: add             x0, x0, HEAP, lsl #32
    // 0xb1c878: cmp             w0, NULL
    // 0xb1c87c: b.eq            #0xb1c8f4
    // 0xb1c880: LoadField: r1 = r0->field_7
    //     0xb1c880: ldur            w1, [x0, #7]
    // 0xb1c884: DecompressPointer r1
    //     0xb1c884: add             x1, x1, HEAP, lsl #32
    // 0xb1c888: LoadField: r0 = r1->field_f
    //     0xb1c888: ldur            w0, [x1, #0xf]
    // 0xb1c88c: DecompressPointer r0
    //     0xb1c88c: add             x0, x0, HEAP, lsl #32
    // 0xb1c890: stur            x0, [fp, #-0x10]
    // 0xb1c894: LoadField: r1 = r0->field_7
    //     0xb1c894: ldur            w1, [x0, #7]
    // 0xb1c898: DecompressPointer r1
    //     0xb1c898: add             x1, x1, HEAP, lsl #32
    // 0xb1c89c: cmp             w1, NULL
    // 0xb1c8a0: b.eq            #0xb1c8f8
    // 0xb1c8a4: LoadField: r2 = r1->field_7
    //     0xb1c8a4: ldur            x2, [x1, #7]
    // 0xb1c8a8: ldr             x1, [x2]
    // 0xb1c8ac: cbz             x1, #0xb1c8dc
    // 0xb1c8b0: mov             x2, x1
    // 0xb1c8b4: stur            x2, [fp, #-8]
    // 0xb1c8b8: r1 = <Never>
    //     0xb1c8b8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb1c8bc: r0 = Pointer()
    //     0xb1c8bc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb1c8c0: mov             x1, x0
    // 0xb1c8c4: ldur            x0, [fp, #-8]
    // 0xb1c8c8: StoreField: r1->field_7 = r0
    //     0xb1c8c8: stur            x0, [x1, #7]
    // 0xb1c8cc: r0 = _minIntrinsicWidth$Getter$FfiNative()
    //     0xb1c8cc: bl              #0xb1c8fc  ; [dart:ui] _NativeParagraph::_minIntrinsicWidth$Getter$FfiNative
    // 0xb1c8d0: LeaveFrame
    //     0xb1c8d0: mov             SP, fp
    //     0xb1c8d4: ldp             fp, lr, [SP], #0x10
    // 0xb1c8d8: ret
    //     0xb1c8d8: ret             
    // 0xb1c8dc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb1c8dc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb1c8e0: str             x16, [SP]
    // 0xb1c8e4: r0 = _throwNew()
    //     0xb1c8e4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb1c8e8: brk             #0
    // 0xb1c8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c8f0: b               #0xb1c870
    // 0xb1c8f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1c8f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1c8f8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb1c8f8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ setPlaceholderDimensions(/* No info */) {
    // ** addr: 0xb1c98c, size: 0xa8
    // 0xb1c98c: EnterFrame
    //     0xb1c98c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c990: mov             fp, SP
    // 0xb1c994: AllocStack(0x28)
    //     0xb1c994: sub             SP, SP, #0x28
    // 0xb1c998: SetupParameters(TextPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb1c998: mov             x0, x2
    //     0xb1c99c: stur            x1, [fp, #-8]
    //     0xb1c9a0: stur            x2, [fp, #-0x10]
    // 0xb1c9a4: CheckStackOverflow
    //     0xb1c9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c9a8: cmp             SP, x16
    //     0xb1c9ac: b.ls            #0xb1ca2c
    // 0xb1c9b0: cmp             w0, NULL
    // 0xb1c9b4: b.eq            #0xb1c9e4
    // 0xb1c9b8: LoadField: r2 = r0->field_b
    //     0xb1c9b8: ldur            w2, [x0, #0xb]
    // 0xb1c9bc: cbz             w2, #0xb1c9e4
    // 0xb1c9c0: LoadField: r2 = r1->field_3b
    //     0xb1c9c0: ldur            w2, [x1, #0x3b]
    // 0xb1c9c4: DecompressPointer r2
    //     0xb1c9c4: add             x2, x2, HEAP, lsl #32
    // 0xb1c9c8: r16 = <PlaceholderDimensions>
    //     0xb1c9c8: add             x16, PP, #0x97, lsl #12  ; [pp+0x97960] TypeArguments: <PlaceholderDimensions>
    //     0xb1c9cc: ldr             x16, [x16, #0x960]
    // 0xb1c9d0: stp             x0, x16, [SP, #8]
    // 0xb1c9d4: str             x2, [SP]
    // 0xb1c9d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb1c9d8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb1c9dc: r0 = listEquals()
    //     0xb1c9dc: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xb1c9e0: tbnz            w0, #4, #0xb1c9f4
    // 0xb1c9e4: r0 = Null
    //     0xb1c9e4: mov             x0, NULL
    // 0xb1c9e8: LeaveFrame
    //     0xb1c9e8: mov             SP, fp
    //     0xb1c9ec: ldp             fp, lr, [SP], #0x10
    // 0xb1c9f0: ret
    //     0xb1c9f0: ret             
    // 0xb1c9f4: ldur            x1, [fp, #-8]
    // 0xb1c9f8: ldur            x0, [fp, #-0x10]
    // 0xb1c9fc: StoreField: r1->field_3b = r0
    //     0xb1c9fc: stur            w0, [x1, #0x3b]
    //     0xb1ca00: ldurb           w16, [x1, #-1]
    //     0xb1ca04: ldurb           w17, [x0, #-1]
    //     0xb1ca08: and             x16, x17, x16, lsr #2
    //     0xb1ca0c: tst             x16, HEAP, lsr #32
    //     0xb1ca10: b.eq            #0xb1ca18
    //     0xb1ca14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1ca18: r0 = markNeedsLayout()
    //     0xb1ca18: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1ca1c: r0 = Null
    //     0xb1ca1c: mov             x0, NULL
    // 0xb1ca20: LeaveFrame
    //     0xb1ca20: mov             SP, fp
    //     0xb1ca24: ldp             fp, lr, [SP], #0x10
    // 0xb1ca28: ret
    //     0xb1ca28: ret             
    // 0xb1ca2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ca2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ca30: b               #0xb1c9b0
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0xb1ca34, size: 0xb4
    // 0xb1ca34: EnterFrame
    //     0xb1ca34: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ca38: mov             fp, SP
    // 0xb1ca3c: AllocStack(0x20)
    //     0xb1ca3c: sub             SP, SP, #0x20
    // 0xb1ca40: SetupParameters(TextPainter this /* r1 => r0, fp-0x18 */)
    //     0xb1ca40: mov             x0, x1
    //     0xb1ca44: stur            x1, [fp, #-0x18]
    // 0xb1ca48: CheckStackOverflow
    //     0xb1ca48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1ca4c: cmp             SP, x16
    //     0xb1ca50: b.ls            #0xb1cadc
    // 0xb1ca54: LoadField: r1 = r0->field_7
    //     0xb1ca54: ldur            w1, [x0, #7]
    // 0xb1ca58: DecompressPointer r1
    //     0xb1ca58: add             x1, x1, HEAP, lsl #32
    // 0xb1ca5c: cmp             w1, NULL
    // 0xb1ca60: b.eq            #0xb1cab8
    // 0xb1ca64: LoadField: r2 = r1->field_7
    //     0xb1ca64: ldur            w2, [x1, #7]
    // 0xb1ca68: DecompressPointer r2
    //     0xb1ca68: add             x2, x2, HEAP, lsl #32
    // 0xb1ca6c: LoadField: r3 = r2->field_f
    //     0xb1ca6c: ldur            w3, [x2, #0xf]
    // 0xb1ca70: DecompressPointer r3
    //     0xb1ca70: add             x3, x3, HEAP, lsl #32
    // 0xb1ca74: stur            x3, [fp, #-0x10]
    // 0xb1ca78: LoadField: r1 = r3->field_7
    //     0xb1ca78: ldur            w1, [x3, #7]
    // 0xb1ca7c: DecompressPointer r1
    //     0xb1ca7c: add             x1, x1, HEAP, lsl #32
    // 0xb1ca80: cmp             w1, NULL
    // 0xb1ca84: b.eq            #0xb1cae4
    // 0xb1ca88: LoadField: r2 = r1->field_7
    //     0xb1ca88: ldur            x2, [x1, #7]
    // 0xb1ca8c: ldr             x1, [x2]
    // 0xb1ca90: cbz             x1, #0xb1cacc
    // 0xb1ca94: mov             x2, x1
    // 0xb1ca98: stur            x2, [fp, #-8]
    // 0xb1ca9c: r1 = <Never>
    //     0xb1ca9c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb1caa0: r0 = Pointer()
    //     0xb1caa0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb1caa4: mov             x1, x0
    // 0xb1caa8: ldur            x0, [fp, #-8]
    // 0xb1caac: StoreField: r1->field_7 = r0
    //     0xb1caac: stur            x0, [x1, #7]
    // 0xb1cab0: r0 = __dispose$Method$FfiNative()
    //     0xb1cab0: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xb1cab4: ldur            x0, [fp, #-0x18]
    // 0xb1cab8: StoreField: r0->field_7 = rNULL
    //     0xb1cab8: stur            NULL, [x0, #7]
    // 0xb1cabc: r0 = Null
    //     0xb1cabc: mov             x0, NULL
    // 0xb1cac0: LeaveFrame
    //     0xb1cac0: mov             SP, fp
    //     0xb1cac4: ldp             fp, lr, [SP], #0x10
    // 0xb1cac8: ret
    //     0xb1cac8: ret             
    // 0xb1cacc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb1cacc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb1cad0: str             x16, [SP]
    // 0xb1cad4: r0 = _throwNew()
    //     0xb1cad4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb1cad8: brk             #0
    // 0xb1cadc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cadc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cae0: b               #0xb1ca54
    // 0xb1cae4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb1cae4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0xb1cda8, size: 0xac
    // 0xb1cda8: EnterFrame
    //     0xb1cda8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cdac: mov             fp, SP
    // 0xb1cdb0: mov             x0, x2
    // 0xb1cdb4: CheckStackOverflow
    //     0xb1cdb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1cdb8: cmp             SP, x16
    //     0xb1cdbc: b.ls            #0xb1ce4c
    // 0xb1cdc0: LoadField: r2 = r1->field_2b
    //     0xb1cdc0: ldur            w2, [x1, #0x2b]
    // 0xb1cdc4: DecompressPointer r2
    //     0xb1cdc4: add             x2, x2, HEAP, lsl #32
    // 0xb1cdc8: cmp             w2, w0
    // 0xb1cdcc: b.eq            #0xb1ce08
    // 0xb1cdd0: and             w16, w2, w0
    // 0xb1cdd4: branchIfSmi(r16, 0xb1ce18)
    //     0xb1cdd4: tbz             w16, #0, #0xb1ce18
    // 0xb1cdd8: r16 = LoadClassIdInstr(r2)
    //     0xb1cdd8: ldur            x16, [x2, #-1]
    //     0xb1cddc: ubfx            x16, x16, #0xc, #0x14
    // 0xb1cde0: cmp             x16, #0x3d
    // 0xb1cde4: b.ne            #0xb1ce18
    // 0xb1cde8: r16 = LoadClassIdInstr(r0)
    //     0xb1cde8: ldur            x16, [x0, #-1]
    //     0xb1cdec: ubfx            x16, x16, #0xc, #0x14
    // 0xb1cdf0: cmp             x16, #0x3d
    // 0xb1cdf4: b.ne            #0xb1ce18
    // 0xb1cdf8: LoadField: r16 = r2->field_7
    //     0xb1cdf8: ldur            x16, [x2, #7]
    // 0xb1cdfc: LoadField: r17 = r0->field_7
    //     0xb1cdfc: ldur            x17, [x0, #7]
    // 0xb1ce00: cmp             x16, x17
    // 0xb1ce04: b.ne            #0xb1ce18
    // 0xb1ce08: r0 = Null
    //     0xb1ce08: mov             x0, NULL
    // 0xb1ce0c: LeaveFrame
    //     0xb1ce0c: mov             SP, fp
    //     0xb1ce10: ldp             fp, lr, [SP], #0x10
    // 0xb1ce14: ret
    //     0xb1ce14: ret             
    // 0xb1ce18: StoreField: r1->field_2b = r0
    //     0xb1ce18: stur            w0, [x1, #0x2b]
    //     0xb1ce1c: tbz             w0, #0, #0xb1ce38
    //     0xb1ce20: ldurb           w16, [x1, #-1]
    //     0xb1ce24: ldurb           w17, [x0, #-1]
    //     0xb1ce28: and             x16, x17, x16, lsr #2
    //     0xb1ce2c: tst             x16, HEAP, lsr #32
    //     0xb1ce30: b.eq            #0xb1ce38
    //     0xb1ce34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1ce38: r0 = markNeedsLayout()
    //     0xb1ce38: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1ce3c: r0 = Null
    //     0xb1ce3c: mov             x0, NULL
    // 0xb1ce40: LeaveFrame
    //     0xb1ce40: mov             SP, fp
    //     0xb1ce44: ldp             fp, lr, [SP], #0x10
    // 0xb1ce48: ret
    //     0xb1ce48: ret             
    // 0xb1ce4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ce4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ce50: b               #0xb1cdc0
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0xb1ce54, size: 0x70
    // 0xb1ce54: EnterFrame
    //     0xb1ce54: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ce58: mov             fp, SP
    // 0xb1ce5c: mov             x0, x2
    // 0xb1ce60: CheckStackOverflow
    //     0xb1ce60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1ce64: cmp             SP, x16
    //     0xb1ce68: b.ls            #0xb1cebc
    // 0xb1ce6c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb1ce6c: ldur            w2, [x1, #0x17]
    // 0xb1ce70: DecompressPointer r2
    //     0xb1ce70: add             x2, x2, HEAP, lsl #32
    // 0xb1ce74: cmp             w2, w0
    // 0xb1ce78: b.ne            #0xb1ce8c
    // 0xb1ce7c: r0 = Null
    //     0xb1ce7c: mov             x0, NULL
    // 0xb1ce80: LeaveFrame
    //     0xb1ce80: mov             SP, fp
    //     0xb1ce84: ldp             fp, lr, [SP], #0x10
    // 0xb1ce88: ret
    //     0xb1ce88: ret             
    // 0xb1ce8c: ArrayStore: r1[0] = r0  ; List_4
    //     0xb1ce8c: stur            w0, [x1, #0x17]
    //     0xb1ce90: ldurb           w16, [x1, #-1]
    //     0xb1ce94: ldurb           w17, [x0, #-1]
    //     0xb1ce98: and             x16, x17, x16, lsr #2
    //     0xb1ce9c: tst             x16, HEAP, lsr #32
    //     0xb1cea0: b.eq            #0xb1cea8
    //     0xb1cea4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1cea8: r0 = markNeedsLayout()
    //     0xb1cea8: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1ceac: r0 = Null
    //     0xb1ceac: mov             x0, NULL
    // 0xb1ceb0: LeaveFrame
    //     0xb1ceb0: mov             SP, fp
    //     0xb1ceb4: ldp             fp, lr, [SP], #0x10
    // 0xb1ceb8: ret
    //     0xb1ceb8: ret             
    // 0xb1cebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cec0: b               #0xb1ce6c
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0xb1cec4, size: 0xa4
    // 0xb1cec4: EnterFrame
    //     0xb1cec4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cec8: mov             fp, SP
    // 0xb1cecc: AllocStack(0x20)
    //     0xb1cecc: sub             SP, SP, #0x20
    // 0xb1ced0: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb1ced0: stur            x1, [fp, #-8]
    //     0xb1ced4: mov             x16, x2
    //     0xb1ced8: mov             x2, x1
    //     0xb1cedc: mov             x1, x16
    //     0xb1cee0: stur            x1, [fp, #-0x10]
    // 0xb1cee4: CheckStackOverflow
    //     0xb1cee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1cee8: cmp             SP, x16
    //     0xb1ceec: b.ls            #0xb1cf60
    // 0xb1cef0: LoadField: r0 = r2->field_2f
    //     0xb1cef0: ldur            w0, [x2, #0x2f]
    // 0xb1cef4: DecompressPointer r0
    //     0xb1cef4: add             x0, x0, HEAP, lsl #32
    // 0xb1cef8: r3 = LoadClassIdInstr(r0)
    //     0xb1cef8: ldur            x3, [x0, #-1]
    //     0xb1cefc: ubfx            x3, x3, #0xc, #0x14
    // 0xb1cf00: stp             x1, x0, [SP]
    // 0xb1cf04: mov             x0, x3
    // 0xb1cf08: mov             lr, x0
    // 0xb1cf0c: ldr             lr, [x21, lr, lsl #3]
    // 0xb1cf10: blr             lr
    // 0xb1cf14: tbnz            w0, #4, #0xb1cf28
    // 0xb1cf18: r0 = Null
    //     0xb1cf18: mov             x0, NULL
    // 0xb1cf1c: LeaveFrame
    //     0xb1cf1c: mov             SP, fp
    //     0xb1cf20: ldp             fp, lr, [SP], #0x10
    // 0xb1cf24: ret
    //     0xb1cf24: ret             
    // 0xb1cf28: ldur            x1, [fp, #-8]
    // 0xb1cf2c: ldur            x0, [fp, #-0x10]
    // 0xb1cf30: StoreField: r1->field_2f = r0
    //     0xb1cf30: stur            w0, [x1, #0x2f]
    //     0xb1cf34: ldurb           w16, [x1, #-1]
    //     0xb1cf38: ldurb           w17, [x0, #-1]
    //     0xb1cf3c: and             x16, x17, x16, lsr #2
    //     0xb1cf40: tst             x16, HEAP, lsr #32
    //     0xb1cf44: b.eq            #0xb1cf4c
    //     0xb1cf48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1cf4c: r0 = markNeedsLayout()
    //     0xb1cf4c: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1cf50: r0 = Null
    //     0xb1cf50: mov             x0, NULL
    // 0xb1cf54: LeaveFrame
    //     0xb1cf54: mov             SP, fp
    //     0xb1cf58: ldp             fp, lr, [SP], #0x10
    // 0xb1cf5c: ret
    //     0xb1cf5c: ret             
    // 0xb1cf60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cf60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cf64: b               #0xb1cef0
  }
  set _ locale=(/* No info */) {
    // ** addr: 0xb1cf68, size: 0xa4
    // 0xb1cf68: EnterFrame
    //     0xb1cf68: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cf6c: mov             fp, SP
    // 0xb1cf70: AllocStack(0x20)
    //     0xb1cf70: sub             SP, SP, #0x20
    // 0xb1cf74: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb1cf74: stur            x1, [fp, #-8]
    //     0xb1cf78: mov             x16, x2
    //     0xb1cf7c: mov             x2, x1
    //     0xb1cf80: mov             x1, x16
    //     0xb1cf84: stur            x1, [fp, #-0x10]
    // 0xb1cf88: CheckStackOverflow
    //     0xb1cf88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1cf8c: cmp             SP, x16
    //     0xb1cf90: b.ls            #0xb1d004
    // 0xb1cf94: LoadField: r0 = r2->field_27
    //     0xb1cf94: ldur            w0, [x2, #0x27]
    // 0xb1cf98: DecompressPointer r0
    //     0xb1cf98: add             x0, x0, HEAP, lsl #32
    // 0xb1cf9c: r3 = LoadClassIdInstr(r0)
    //     0xb1cf9c: ldur            x3, [x0, #-1]
    //     0xb1cfa0: ubfx            x3, x3, #0xc, #0x14
    // 0xb1cfa4: stp             x1, x0, [SP]
    // 0xb1cfa8: mov             x0, x3
    // 0xb1cfac: mov             lr, x0
    // 0xb1cfb0: ldr             lr, [x21, lr, lsl #3]
    // 0xb1cfb4: blr             lr
    // 0xb1cfb8: tbnz            w0, #4, #0xb1cfcc
    // 0xb1cfbc: r0 = Null
    //     0xb1cfbc: mov             x0, NULL
    // 0xb1cfc0: LeaveFrame
    //     0xb1cfc0: mov             SP, fp
    //     0xb1cfc4: ldp             fp, lr, [SP], #0x10
    // 0xb1cfc8: ret
    //     0xb1cfc8: ret             
    // 0xb1cfcc: ldur            x1, [fp, #-8]
    // 0xb1cfd0: ldur            x0, [fp, #-0x10]
    // 0xb1cfd4: StoreField: r1->field_27 = r0
    //     0xb1cfd4: stur            w0, [x1, #0x27]
    //     0xb1cfd8: ldurb           w16, [x1, #-1]
    //     0xb1cfdc: ldurb           w17, [x0, #-1]
    //     0xb1cfe0: and             x16, x17, x16, lsr #2
    //     0xb1cfe4: tst             x16, HEAP, lsr #32
    //     0xb1cfe8: b.eq            #0xb1cff0
    //     0xb1cfec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1cff0: r0 = markNeedsLayout()
    //     0xb1cff0: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1cff4: r0 = Null
    //     0xb1cff4: mov             x0, NULL
    // 0xb1cff8: LeaveFrame
    //     0xb1cff8: mov             SP, fp
    //     0xb1cffc: ldp             fp, lr, [SP], #0x10
    // 0xb1d000: ret
    //     0xb1d000: ret             
    // 0xb1d004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d004: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d008: b               #0xb1cf94
  }
  set _ ellipsis=(/* No info */) {
    // ** addr: 0xb1d00c, size: 0xa4
    // 0xb1d00c: EnterFrame
    //     0xb1d00c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d010: mov             fp, SP
    // 0xb1d014: AllocStack(0x20)
    //     0xb1d014: sub             SP, SP, #0x20
    // 0xb1d018: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb1d018: stur            x1, [fp, #-8]
    //     0xb1d01c: mov             x16, x2
    //     0xb1d020: mov             x2, x1
    //     0xb1d024: mov             x1, x16
    //     0xb1d028: stur            x1, [fp, #-0x10]
    // 0xb1d02c: CheckStackOverflow
    //     0xb1d02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d030: cmp             SP, x16
    //     0xb1d034: b.ls            #0xb1d0a8
    // 0xb1d038: LoadField: r0 = r2->field_23
    //     0xb1d038: ldur            w0, [x2, #0x23]
    // 0xb1d03c: DecompressPointer r0
    //     0xb1d03c: add             x0, x0, HEAP, lsl #32
    // 0xb1d040: r3 = LoadClassIdInstr(r0)
    //     0xb1d040: ldur            x3, [x0, #-1]
    //     0xb1d044: ubfx            x3, x3, #0xc, #0x14
    // 0xb1d048: stp             x1, x0, [SP]
    // 0xb1d04c: mov             x0, x3
    // 0xb1d050: mov             lr, x0
    // 0xb1d054: ldr             lr, [x21, lr, lsl #3]
    // 0xb1d058: blr             lr
    // 0xb1d05c: tbnz            w0, #4, #0xb1d070
    // 0xb1d060: r0 = Null
    //     0xb1d060: mov             x0, NULL
    // 0xb1d064: LeaveFrame
    //     0xb1d064: mov             SP, fp
    //     0xb1d068: ldp             fp, lr, [SP], #0x10
    // 0xb1d06c: ret
    //     0xb1d06c: ret             
    // 0xb1d070: ldur            x1, [fp, #-8]
    // 0xb1d074: ldur            x0, [fp, #-0x10]
    // 0xb1d078: StoreField: r1->field_23 = r0
    //     0xb1d078: stur            w0, [x1, #0x23]
    //     0xb1d07c: ldurb           w16, [x1, #-1]
    //     0xb1d080: ldurb           w17, [x0, #-1]
    //     0xb1d084: and             x16, x17, x16, lsr #2
    //     0xb1d088: tst             x16, HEAP, lsr #32
    //     0xb1d08c: b.eq            #0xb1d094
    //     0xb1d090: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1d094: r0 = markNeedsLayout()
    //     0xb1d094: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1d098: r0 = Null
    //     0xb1d098: mov             x0, NULL
    // 0xb1d09c: LeaveFrame
    //     0xb1d09c: mov             SP, fp
    //     0xb1d0a0: ldp             fp, lr, [SP], #0x10
    // 0xb1d0a4: ret
    //     0xb1d0a4: ret             
    // 0xb1d0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d0a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d0ac: b               #0xb1d038
  }
  set _ textScaler=(/* No info */) {
    // ** addr: 0xb1d0b0, size: 0x118
    // 0xb1d0b0: EnterFrame
    //     0xb1d0b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d0b4: mov             fp, SP
    // 0xb1d0b8: AllocStack(0x28)
    //     0xb1d0b8: sub             SP, SP, #0x28
    // 0xb1d0bc: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb1d0bc: stur            x1, [fp, #-8]
    //     0xb1d0c0: mov             x16, x2
    //     0xb1d0c4: mov             x2, x1
    //     0xb1d0c8: mov             x1, x16
    //     0xb1d0cc: stur            x1, [fp, #-0x10]
    // 0xb1d0d0: CheckStackOverflow
    //     0xb1d0d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d0d4: cmp             SP, x16
    //     0xb1d0d8: b.ls            #0xb1d1bc
    // 0xb1d0dc: LoadField: r0 = r2->field_1f
    //     0xb1d0dc: ldur            w0, [x2, #0x1f]
    // 0xb1d0e0: DecompressPointer r0
    //     0xb1d0e0: add             x0, x0, HEAP, lsl #32
    // 0xb1d0e4: r3 = LoadClassIdInstr(r1)
    //     0xb1d0e4: ldur            x3, [x1, #-1]
    //     0xb1d0e8: ubfx            x3, x3, #0xc, #0x14
    // 0xb1d0ec: stp             x0, x1, [SP]
    // 0xb1d0f0: mov             x0, x3
    // 0xb1d0f4: mov             lr, x0
    // 0xb1d0f8: ldr             lr, [x21, lr, lsl #3]
    // 0xb1d0fc: blr             lr
    // 0xb1d100: tbnz            w0, #4, #0xb1d114
    // 0xb1d104: r0 = Null
    //     0xb1d104: mov             x0, NULL
    // 0xb1d108: LeaveFrame
    //     0xb1d108: mov             SP, fp
    //     0xb1d10c: ldp             fp, lr, [SP], #0x10
    // 0xb1d110: ret
    //     0xb1d110: ret             
    // 0xb1d114: ldur            x2, [fp, #-8]
    // 0xb1d118: ldur            x0, [fp, #-0x10]
    // 0xb1d11c: StoreField: r2->field_1f = r0
    //     0xb1d11c: stur            w0, [x2, #0x1f]
    //     0xb1d120: ldurb           w16, [x2, #-1]
    //     0xb1d124: ldurb           w17, [x0, #-1]
    //     0xb1d128: and             x16, x17, x16, lsr #2
    //     0xb1d12c: tst             x16, HEAP, lsr #32
    //     0xb1d130: b.eq            #0xb1d138
    //     0xb1d134: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb1d138: mov             x1, x2
    // 0xb1d13c: r0 = markNeedsLayout()
    //     0xb1d13c: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1d140: ldur            x0, [fp, #-8]
    // 0xb1d144: LoadField: r2 = r0->field_3f
    //     0xb1d144: ldur            w2, [x0, #0x3f]
    // 0xb1d148: DecompressPointer r2
    //     0xb1d148: add             x2, x2, HEAP, lsl #32
    // 0xb1d14c: stur            x2, [fp, #-0x10]
    // 0xb1d150: cmp             w2, NULL
    // 0xb1d154: b.eq            #0xb1d198
    // 0xb1d158: LoadField: r1 = r2->field_7
    //     0xb1d158: ldur            w1, [x2, #7]
    // 0xb1d15c: DecompressPointer r1
    //     0xb1d15c: add             x1, x1, HEAP, lsl #32
    // 0xb1d160: cmp             w1, NULL
    // 0xb1d164: b.eq            #0xb1d1c4
    // 0xb1d168: LoadField: r3 = r1->field_7
    //     0xb1d168: ldur            x3, [x1, #7]
    // 0xb1d16c: ldr             x1, [x3]
    // 0xb1d170: cbz             x1, #0xb1d1ac
    // 0xb1d174: mov             x3, x1
    // 0xb1d178: stur            x3, [fp, #-0x18]
    // 0xb1d17c: r1 = <Never>
    //     0xb1d17c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb1d180: r0 = Pointer()
    //     0xb1d180: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb1d184: mov             x1, x0
    // 0xb1d188: ldur            x0, [fp, #-0x18]
    // 0xb1d18c: StoreField: r1->field_7 = r0
    //     0xb1d18c: stur            x0, [x1, #7]
    // 0xb1d190: r0 = __dispose$Method$FfiNative()
    //     0xb1d190: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xb1d194: ldur            x0, [fp, #-8]
    // 0xb1d198: StoreField: r0->field_3f = rNULL
    //     0xb1d198: stur            NULL, [x0, #0x3f]
    // 0xb1d19c: r0 = Null
    //     0xb1d19c: mov             x0, NULL
    // 0xb1d1a0: LeaveFrame
    //     0xb1d1a0: mov             SP, fp
    //     0xb1d1a4: ldp             fp, lr, [SP], #0x10
    // 0xb1d1a8: ret
    //     0xb1d1a8: ret             
    // 0xb1d1ac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb1d1ac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb1d1b0: str             x16, [SP]
    // 0xb1d1b4: r0 = _throwNew()
    //     0xb1d1b4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb1d1b8: brk             #0
    // 0xb1d1bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d1bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d1c0: b               #0xb1d0dc
    // 0xb1d1c4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb1d1c4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xb1d1c8, size: 0xf0
    // 0xb1d1c8: EnterFrame
    //     0xb1d1c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d1cc: mov             fp, SP
    // 0xb1d1d0: AllocStack(0x20)
    //     0xb1d1d0: sub             SP, SP, #0x20
    // 0xb1d1d4: SetupParameters(TextPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xb1d1d4: mov             x0, x2
    //     0xb1d1d8: mov             x2, x1
    //     0xb1d1dc: stur            x1, [fp, #-8]
    // 0xb1d1e0: CheckStackOverflow
    //     0xb1d1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d1e4: cmp             SP, x16
    //     0xb1d1e8: b.ls            #0xb1d2ac
    // 0xb1d1ec: LoadField: r1 = r2->field_1b
    //     0xb1d1ec: ldur            w1, [x2, #0x1b]
    // 0xb1d1f0: DecompressPointer r1
    //     0xb1d1f0: add             x1, x1, HEAP, lsl #32
    // 0xb1d1f4: cmp             w1, w0
    // 0xb1d1f8: b.ne            #0xb1d20c
    // 0xb1d1fc: r0 = Null
    //     0xb1d1fc: mov             x0, NULL
    // 0xb1d200: LeaveFrame
    //     0xb1d200: mov             SP, fp
    //     0xb1d204: ldp             fp, lr, [SP], #0x10
    // 0xb1d208: ret
    //     0xb1d208: ret             
    // 0xb1d20c: StoreField: r2->field_1b = r0
    //     0xb1d20c: stur            w0, [x2, #0x1b]
    //     0xb1d210: ldurb           w16, [x2, #-1]
    //     0xb1d214: ldurb           w17, [x0, #-1]
    //     0xb1d218: and             x16, x17, x16, lsr #2
    //     0xb1d21c: tst             x16, HEAP, lsr #32
    //     0xb1d220: b.eq            #0xb1d228
    //     0xb1d224: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb1d228: mov             x1, x2
    // 0xb1d22c: r0 = markNeedsLayout()
    //     0xb1d22c: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1d230: ldur            x0, [fp, #-8]
    // 0xb1d234: LoadField: r2 = r0->field_3f
    //     0xb1d234: ldur            w2, [x0, #0x3f]
    // 0xb1d238: DecompressPointer r2
    //     0xb1d238: add             x2, x2, HEAP, lsl #32
    // 0xb1d23c: stur            x2, [fp, #-0x18]
    // 0xb1d240: cmp             w2, NULL
    // 0xb1d244: b.eq            #0xb1d288
    // 0xb1d248: LoadField: r1 = r2->field_7
    //     0xb1d248: ldur            w1, [x2, #7]
    // 0xb1d24c: DecompressPointer r1
    //     0xb1d24c: add             x1, x1, HEAP, lsl #32
    // 0xb1d250: cmp             w1, NULL
    // 0xb1d254: b.eq            #0xb1d2b4
    // 0xb1d258: LoadField: r3 = r1->field_7
    //     0xb1d258: ldur            x3, [x1, #7]
    // 0xb1d25c: ldr             x1, [x3]
    // 0xb1d260: cbz             x1, #0xb1d29c
    // 0xb1d264: mov             x3, x1
    // 0xb1d268: stur            x3, [fp, #-0x10]
    // 0xb1d26c: r1 = <Never>
    //     0xb1d26c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb1d270: r0 = Pointer()
    //     0xb1d270: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb1d274: mov             x1, x0
    // 0xb1d278: ldur            x0, [fp, #-0x10]
    // 0xb1d27c: StoreField: r1->field_7 = r0
    //     0xb1d27c: stur            x0, [x1, #7]
    // 0xb1d280: r0 = __dispose$Method$FfiNative()
    //     0xb1d280: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xb1d284: ldur            x0, [fp, #-8]
    // 0xb1d288: StoreField: r0->field_3f = rNULL
    //     0xb1d288: stur            NULL, [x0, #0x3f]
    // 0xb1d28c: r0 = Null
    //     0xb1d28c: mov             x0, NULL
    // 0xb1d290: LeaveFrame
    //     0xb1d290: mov             SP, fp
    //     0xb1d294: ldp             fp, lr, [SP], #0x10
    // 0xb1d298: ret
    //     0xb1d298: ret             
    // 0xb1d29c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb1d29c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb1d2a0: str             x16, [SP]
    // 0xb1d2a4: r0 = _throwNew()
    //     0xb1d2a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb1d2a8: brk             #0
    // 0xb1d2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d2ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d2b0: b               #0xb1d1ec
    // 0xb1d2b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb1d2b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ text=(/* No info */) {
    // ** addr: 0xb1d2b8, size: 0x200
    // 0xb1d2b8: EnterFrame
    //     0xb1d2b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d2bc: mov             fp, SP
    // 0xb1d2c0: AllocStack(0x30)
    //     0xb1d2c0: sub             SP, SP, #0x30
    // 0xb1d2c4: SetupParameters(TextPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb1d2c4: stur            x1, [fp, #-8]
    //     0xb1d2c8: stur            x2, [fp, #-0x10]
    // 0xb1d2cc: CheckStackOverflow
    //     0xb1d2cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d2d0: cmp             SP, x16
    //     0xb1d2d4: b.ls            #0xb1d4ac
    // 0xb1d2d8: LoadField: r0 = r1->field_f
    //     0xb1d2d8: ldur            w0, [x1, #0xf]
    // 0xb1d2dc: DecompressPointer r0
    //     0xb1d2dc: add             x0, x0, HEAP, lsl #32
    // 0xb1d2e0: r3 = LoadClassIdInstr(r0)
    //     0xb1d2e0: ldur            x3, [x0, #-1]
    //     0xb1d2e4: ubfx            x3, x3, #0xc, #0x14
    // 0xb1d2e8: stp             x2, x0, [SP]
    // 0xb1d2ec: mov             x0, x3
    // 0xb1d2f0: mov             lr, x0
    // 0xb1d2f4: ldr             lr, [x21, lr, lsl #3]
    // 0xb1d2f8: blr             lr
    // 0xb1d2fc: tbnz            w0, #4, #0xb1d310
    // 0xb1d300: r0 = Null
    //     0xb1d300: mov             x0, NULL
    // 0xb1d304: LeaveFrame
    //     0xb1d304: mov             SP, fp
    //     0xb1d308: ldp             fp, lr, [SP], #0x10
    // 0xb1d30c: ret
    //     0xb1d30c: ret             
    // 0xb1d310: ldur            x1, [fp, #-8]
    // 0xb1d314: LoadField: r0 = r1->field_f
    //     0xb1d314: ldur            w0, [x1, #0xf]
    // 0xb1d318: DecompressPointer r0
    //     0xb1d318: add             x0, x0, HEAP, lsl #32
    // 0xb1d31c: cmp             w0, NULL
    // 0xb1d320: b.ne            #0xb1d32c
    // 0xb1d324: r0 = Null
    //     0xb1d324: mov             x0, NULL
    // 0xb1d328: b               #0xb1d338
    // 0xb1d32c: LoadField: r2 = r0->field_7
    //     0xb1d32c: ldur            w2, [x0, #7]
    // 0xb1d330: DecompressPointer r2
    //     0xb1d330: add             x2, x2, HEAP, lsl #32
    // 0xb1d334: mov             x0, x2
    // 0xb1d338: ldur            x2, [fp, #-0x10]
    // 0xb1d33c: cmp             w2, NULL
    // 0xb1d340: b.ne            #0xb1d34c
    // 0xb1d344: r3 = Null
    //     0xb1d344: mov             x3, NULL
    // 0xb1d348: b               #0xb1d354
    // 0xb1d34c: LoadField: r3 = r2->field_7
    //     0xb1d34c: ldur            w3, [x2, #7]
    // 0xb1d350: DecompressPointer r3
    //     0xb1d350: add             x3, x3, HEAP, lsl #32
    // 0xb1d354: r4 = LoadClassIdInstr(r0)
    //     0xb1d354: ldur            x4, [x0, #-1]
    //     0xb1d358: ubfx            x4, x4, #0xc, #0x14
    // 0xb1d35c: stp             x3, x0, [SP]
    // 0xb1d360: mov             x0, x4
    // 0xb1d364: mov             lr, x0
    // 0xb1d368: ldr             lr, [x21, lr, lsl #3]
    // 0xb1d36c: blr             lr
    // 0xb1d370: tbz             w0, #4, #0xb1d3dc
    // 0xb1d374: ldur            x0, [fp, #-8]
    // 0xb1d378: LoadField: r2 = r0->field_3f
    //     0xb1d378: ldur            w2, [x0, #0x3f]
    // 0xb1d37c: DecompressPointer r2
    //     0xb1d37c: add             x2, x2, HEAP, lsl #32
    // 0xb1d380: stur            x2, [fp, #-0x20]
    // 0xb1d384: cmp             w2, NULL
    // 0xb1d388: b.ne            #0xb1d394
    // 0xb1d38c: mov             x3, x0
    // 0xb1d390: b               #0xb1d3d4
    // 0xb1d394: LoadField: r1 = r2->field_7
    //     0xb1d394: ldur            w1, [x2, #7]
    // 0xb1d398: DecompressPointer r1
    //     0xb1d398: add             x1, x1, HEAP, lsl #32
    // 0xb1d39c: cmp             w1, NULL
    // 0xb1d3a0: b.eq            #0xb1d4b4
    // 0xb1d3a4: LoadField: r3 = r1->field_7
    //     0xb1d3a4: ldur            x3, [x1, #7]
    // 0xb1d3a8: ldr             x1, [x3]
    // 0xb1d3ac: cbz             x1, #0xb1d49c
    // 0xb1d3b0: mov             x3, x1
    // 0xb1d3b4: stur            x3, [fp, #-0x18]
    // 0xb1d3b8: r1 = <Never>
    //     0xb1d3b8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb1d3bc: r0 = Pointer()
    //     0xb1d3bc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb1d3c0: mov             x1, x0
    // 0xb1d3c4: ldur            x0, [fp, #-0x18]
    // 0xb1d3c8: StoreField: r1->field_7 = r0
    //     0xb1d3c8: stur            x0, [x1, #7]
    // 0xb1d3cc: r0 = __dispose$Method$FfiNative()
    //     0xb1d3cc: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xb1d3d0: ldur            x3, [fp, #-8]
    // 0xb1d3d4: StoreField: r3->field_3f = rNULL
    //     0xb1d3d4: stur            NULL, [x3, #0x3f]
    // 0xb1d3d8: b               #0xb1d3e0
    // 0xb1d3dc: ldur            x3, [fp, #-8]
    // 0xb1d3e0: ldur            x4, [fp, #-0x10]
    // 0xb1d3e4: cmp             w4, NULL
    // 0xb1d3e8: b.ne            #0xb1d3fc
    // 0xb1d3ec: mov             x1, x3
    // 0xb1d3f0: r2 = Instance_RenderComparison
    //     0xb1d3f0: add             x2, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0xb1d3f4: ldr             x2, [x2, #0x338]
    // 0xb1d3f8: b               #0xb1d444
    // 0xb1d3fc: LoadField: r1 = r3->field_f
    //     0xb1d3fc: ldur            w1, [x3, #0xf]
    // 0xb1d400: DecompressPointer r1
    //     0xb1d400: add             x1, x1, HEAP, lsl #32
    // 0xb1d404: cmp             w1, NULL
    // 0xb1d408: b.ne            #0xb1d414
    // 0xb1d40c: r0 = Null
    //     0xb1d40c: mov             x0, NULL
    // 0xb1d410: b               #0xb1d42c
    // 0xb1d414: r0 = LoadClassIdInstr(r1)
    //     0xb1d414: ldur            x0, [x1, #-1]
    //     0xb1d418: ubfx            x0, x0, #0xc, #0x14
    // 0xb1d41c: mov             x2, x4
    // 0xb1d420: r0 = GDT[cid_x0 + -0x6b3]()
    //     0xb1d420: sub             lr, x0, #0x6b3
    //     0xb1d424: ldr             lr, [x21, lr, lsl #3]
    //     0xb1d428: blr             lr
    // 0xb1d42c: cmp             w0, NULL
    // 0xb1d430: b.ne            #0xb1d43c
    // 0xb1d434: r0 = Instance_RenderComparison
    //     0xb1d434: add             x0, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0xb1d438: ldr             x0, [x0, #0x338]
    // 0xb1d43c: mov             x2, x0
    // 0xb1d440: ldur            x1, [fp, #-8]
    // 0xb1d444: ldur            x0, [fp, #-0x10]
    // 0xb1d448: StoreField: r1->field_f = r0
    //     0xb1d448: stur            w0, [x1, #0xf]
    //     0xb1d44c: ldurb           w16, [x1, #-1]
    //     0xb1d450: ldurb           w17, [x0, #-1]
    //     0xb1d454: and             x16, x17, x16, lsr #2
    //     0xb1d458: tst             x16, HEAP, lsr #32
    //     0xb1d45c: b.eq            #0xb1d464
    //     0xb1d460: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1d464: StoreField: r1->field_13 = rNULL
    //     0xb1d464: stur            NULL, [x1, #0x13]
    // 0xb1d468: LoadField: r0 = r2->field_7
    //     0xb1d468: ldur            x0, [x2, #7]
    // 0xb1d46c: cmp             x0, #3
    // 0xb1d470: b.lt            #0xb1d47c
    // 0xb1d474: r0 = markNeedsLayout()
    //     0xb1d474: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1d478: b               #0xb1d48c
    // 0xb1d47c: cmp             x0, #2
    // 0xb1d480: b.lt            #0xb1d48c
    // 0xb1d484: r0 = true
    //     0xb1d484: add             x0, NULL, #0x20  ; true
    // 0xb1d488: StoreField: r1->field_b = r0
    //     0xb1d488: stur            w0, [x1, #0xb]
    // 0xb1d48c: r0 = Null
    //     0xb1d48c: mov             x0, NULL
    // 0xb1d490: LeaveFrame
    //     0xb1d490: mov             SP, fp
    //     0xb1d494: ldp             fp, lr, [SP], #0x10
    // 0xb1d498: ret
    //     0xb1d498: ret             
    // 0xb1d49c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb1d49c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb1d4a0: str             x16, [SP]
    // 0xb1d4a4: r0 = _throwNew()
    //     0xb1d4a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb1d4a8: brk             #0
    // 0xb1d4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d4ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d4b0: b               #0xb1d2d8
    // 0xb1d4b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb1d4b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ maxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2e5b0, size: 0xa4
    // 0xb2e5b0: EnterFrame
    //     0xb2e5b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e5b4: mov             fp, SP
    // 0xb2e5b8: AllocStack(0x18)
    //     0xb2e5b8: sub             SP, SP, #0x18
    // 0xb2e5bc: CheckStackOverflow
    //     0xb2e5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e5c0: cmp             SP, x16
    //     0xb2e5c4: b.ls            #0xb2e644
    // 0xb2e5c8: LoadField: r0 = r1->field_7
    //     0xb2e5c8: ldur            w0, [x1, #7]
    // 0xb2e5cc: DecompressPointer r0
    //     0xb2e5cc: add             x0, x0, HEAP, lsl #32
    // 0xb2e5d0: cmp             w0, NULL
    // 0xb2e5d4: b.eq            #0xb2e64c
    // 0xb2e5d8: LoadField: r1 = r0->field_7
    //     0xb2e5d8: ldur            w1, [x0, #7]
    // 0xb2e5dc: DecompressPointer r1
    //     0xb2e5dc: add             x1, x1, HEAP, lsl #32
    // 0xb2e5e0: LoadField: r0 = r1->field_f
    //     0xb2e5e0: ldur            w0, [x1, #0xf]
    // 0xb2e5e4: DecompressPointer r0
    //     0xb2e5e4: add             x0, x0, HEAP, lsl #32
    // 0xb2e5e8: stur            x0, [fp, #-0x10]
    // 0xb2e5ec: LoadField: r1 = r0->field_7
    //     0xb2e5ec: ldur            w1, [x0, #7]
    // 0xb2e5f0: DecompressPointer r1
    //     0xb2e5f0: add             x1, x1, HEAP, lsl #32
    // 0xb2e5f4: cmp             w1, NULL
    // 0xb2e5f8: b.eq            #0xb2e650
    // 0xb2e5fc: LoadField: r2 = r1->field_7
    //     0xb2e5fc: ldur            x2, [x1, #7]
    // 0xb2e600: ldr             x1, [x2]
    // 0xb2e604: cbz             x1, #0xb2e634
    // 0xb2e608: mov             x2, x1
    // 0xb2e60c: stur            x2, [fp, #-8]
    // 0xb2e610: r1 = <Never>
    //     0xb2e610: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb2e614: r0 = Pointer()
    //     0xb2e614: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb2e618: mov             x1, x0
    // 0xb2e61c: ldur            x0, [fp, #-8]
    // 0xb2e620: StoreField: r1->field_7 = r0
    //     0xb2e620: stur            x0, [x1, #7]
    // 0xb2e624: r0 = _maxIntrinsicWidth$Getter$FfiNative()
    //     0xb2e624: bl              #0x86085c  ; [dart:ui] _NativeParagraph::_maxIntrinsicWidth$Getter$FfiNative
    // 0xb2e628: LeaveFrame
    //     0xb2e628: mov             SP, fp
    //     0xb2e62c: ldp             fp, lr, [SP], #0x10
    // 0xb2e630: ret
    //     0xb2e630: ret             
    // 0xb2e634: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb2e634: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb2e638: str             x16, [SP]
    // 0xb2e63c: r0 = _throwNew()
    //     0xb2e63c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb2e640: brk             #0
    // 0xb2e644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e648: b               #0xb2e5c8
    // 0xb2e64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2e64c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb2e650: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb2e650: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ computeLineMetrics(/* No info */) {
    // ** addr: 0xb3234c, size: 0x120
    // 0xb3234c: EnterFrame
    //     0xb3234c: stp             fp, lr, [SP, #-0x10]!
    //     0xb32350: mov             fp, SP
    // 0xb32354: AllocStack(0x30)
    //     0xb32354: sub             SP, SP, #0x30
    // 0xb32358: CheckStackOverflow
    //     0xb32358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3235c: cmp             SP, x16
    //     0xb32360: b.ls            #0xb32460
    // 0xb32364: LoadField: r0 = r1->field_7
    //     0xb32364: ldur            w0, [x1, #7]
    // 0xb32368: DecompressPointer r0
    //     0xb32368: add             x0, x0, HEAP, lsl #32
    // 0xb3236c: stur            x0, [fp, #-8]
    // 0xb32370: cmp             w0, NULL
    // 0xb32374: b.eq            #0xb32468
    // 0xb32378: mov             x1, x0
    // 0xb3237c: r0 = paintOffset()
    //     0xb3237c: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0xb32380: stur            x0, [fp, #-0x10]
    // 0xb32384: r1 = 1
    //     0xb32384: mov             x1, #1
    // 0xb32388: r0 = AllocateContext()
    //     0xb32388: bl              #0x13de838  ; AllocateContextStub
    // 0xb3238c: mov             x2, x0
    // 0xb32390: ldur            x0, [fp, #-0x10]
    // 0xb32394: stur            x2, [fp, #-0x18]
    // 0xb32398: StoreField: r2->field_f = r0
    //     0xb32398: stur            w0, [x2, #0xf]
    // 0xb3239c: LoadField: d0 = r0->field_7
    //     0xb3239c: ldur            d0, [x0, #7]
    // 0xb323a0: mov             x1, v0.d[0]
    // 0xb323a4: and             x1, x1, #0x7fffffffffffffff
    // 0xb323a8: r17 = 9218868437227405312
    //     0xb323a8: mov             x17, #0x7ff0000000000000
    // 0xb323ac: cmp             x1, x17
    // 0xb323b0: b.eq            #0xb3244c
    // 0xb323b4: fcmp            d0, d0
    // 0xb323b8: b.vs            #0xb3244c
    // 0xb323bc: LoadField: d0 = r0->field_f
    //     0xb323bc: ldur            d0, [x0, #0xf]
    // 0xb323c0: mov             x1, v0.d[0]
    // 0xb323c4: and             x1, x1, #0x7fffffffffffffff
    // 0xb323c8: r17 = 9218868437227405312
    //     0xb323c8: mov             x17, #0x7ff0000000000000
    // 0xb323cc: cmp             x1, x17
    // 0xb323d0: b.eq            #0xb3244c
    // 0xb323d4: fcmp            d0, d0
    // 0xb323d8: b.vs            #0xb3244c
    // 0xb323dc: ldur            x1, [fp, #-8]
    // 0xb323e0: r0 = lineMetrics()
    //     0xb323e0: bl              #0xb3246c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::lineMetrics
    // 0xb323e4: stur            x0, [fp, #-8]
    // 0xb323e8: ldur            x16, [fp, #-0x10]
    // 0xb323ec: r30 = Instance_Offset
    //     0xb323ec: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb323f0: stp             lr, x16, [SP]
    // 0xb323f4: r0 = ==()
    //     0xb323f4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb323f8: tbnz            w0, #4, #0xb32404
    // 0xb323fc: ldur            x0, [fp, #-8]
    // 0xb32400: b               #0xb32440
    // 0xb32404: ldur            x2, [fp, #-0x18]
    // 0xb32408: r1 = Function '<anonymous closure>':.
    //     0xb32408: add             x1, PP, #0x82, lsl #12  ; [pp+0x82890] AnonymousClosure: (0xb32a98), in [package:flutter/src/painting/text_painter.dart] TextPainter::computeLineMetrics (0xb3234c)
    //     0xb3240c: ldr             x1, [x1, #0x890]
    // 0xb32410: r0 = AllocateClosure()
    //     0xb32410: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb32414: r16 = <LineMetrics>
    //     0xb32414: add             x16, PP, #0x82, lsl #12  ; [pp+0x82898] TypeArguments: <LineMetrics>
    //     0xb32418: ldr             x16, [x16, #0x898]
    // 0xb3241c: ldur            lr, [fp, #-8]
    // 0xb32420: stp             lr, x16, [SP, #8]
    // 0xb32424: str             x0, [SP]
    // 0xb32428: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb32428: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb3242c: r0 = map()
    //     0xb3242c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xb32430: LoadField: r1 = r0->field_7
    //     0xb32430: ldur            w1, [x0, #7]
    // 0xb32434: DecompressPointer r1
    //     0xb32434: add             x1, x1, HEAP, lsl #32
    // 0xb32438: mov             x2, x0
    // 0xb3243c: r0 = _List.of()
    //     0xb3243c: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0xb32440: LeaveFrame
    //     0xb32440: mov             SP, fp
    //     0xb32444: ldp             fp, lr, [SP], #0x10
    // 0xb32448: ret
    //     0xb32448: ret             
    // 0xb3244c: r0 = const []
    //     0xb3244c: add             x0, PP, #0x82, lsl #12  ; [pp+0x828a0] List<LineMetrics>(0)
    //     0xb32450: ldr             x0, [x0, #0x8a0]
    // 0xb32454: LeaveFrame
    //     0xb32454: mov             SP, fp
    //     0xb32458: ldp             fp, lr, [SP], #0x10
    // 0xb3245c: ret
    //     0xb3245c: ret             
    // 0xb32460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32464: b               #0xb32364
    // 0xb32468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb32468: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] LineMetrics <anonymous closure>(dynamic, LineMetrics) {
    // ** addr: 0xb32a98, size: 0x44
    // 0xb32a98: EnterFrame
    //     0xb32a98: stp             fp, lr, [SP, #-0x10]!
    //     0xb32a9c: mov             fp, SP
    // 0xb32aa0: ldr             x0, [fp, #0x18]
    // 0xb32aa4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb32aa4: ldur            w1, [x0, #0x17]
    // 0xb32aa8: DecompressPointer r1
    //     0xb32aa8: add             x1, x1, HEAP, lsl #32
    // 0xb32aac: CheckStackOverflow
    //     0xb32aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb32ab0: cmp             SP, x16
    //     0xb32ab4: b.ls            #0xb32ad4
    // 0xb32ab8: LoadField: r2 = r1->field_f
    //     0xb32ab8: ldur            w2, [x1, #0xf]
    // 0xb32abc: DecompressPointer r2
    //     0xb32abc: add             x2, x2, HEAP, lsl #32
    // 0xb32ac0: ldr             x1, [fp, #0x10]
    // 0xb32ac4: r0 = _shiftLineMetrics()
    //     0xb32ac4: bl              #0xb32adc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_shiftLineMetrics
    // 0xb32ac8: LeaveFrame
    //     0xb32ac8: mov             SP, fp
    //     0xb32acc: ldp             fp, lr, [SP], #0x10
    // 0xb32ad0: ret
    //     0xb32ad0: ret             
    // 0xb32ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32ad8: b               #0xb32ab8
  }
  static _ _shiftLineMetrics(/* No info */) {
    // ** addr: 0xb32adc, size: 0xc0
    // 0xb32adc: EnterFrame
    //     0xb32adc: stp             fp, lr, [SP, #-0x10]!
    //     0xb32ae0: mov             fp, SP
    // 0xb32ae4: AllocStack(0x48)
    //     0xb32ae4: sub             SP, SP, #0x48
    // 0xb32ae8: LoadField: r0 = r1->field_7
    //     0xb32ae8: ldur            w0, [x1, #7]
    // 0xb32aec: DecompressPointer r0
    //     0xb32aec: add             x0, x0, HEAP, lsl #32
    // 0xb32af0: stur            x0, [fp, #-0x10]
    // 0xb32af4: LoadField: d0 = r1->field_b
    //     0xb32af4: ldur            d0, [x1, #0xb]
    // 0xb32af8: stur            d0, [fp, #-0x48]
    // 0xb32afc: LoadField: d1 = r1->field_13
    //     0xb32afc: ldur            d1, [x1, #0x13]
    // 0xb32b00: stur            d1, [fp, #-0x40]
    // 0xb32b04: LoadField: d2 = r1->field_1b
    //     0xb32b04: ldur            d2, [x1, #0x1b]
    // 0xb32b08: stur            d2, [fp, #-0x38]
    // 0xb32b0c: LoadField: d3 = r1->field_23
    //     0xb32b0c: ldur            d3, [x1, #0x23]
    // 0xb32b10: stur            d3, [fp, #-0x30]
    // 0xb32b14: LoadField: d4 = r1->field_2b
    //     0xb32b14: ldur            d4, [x1, #0x2b]
    // 0xb32b18: stur            d4, [fp, #-0x28]
    // 0xb32b1c: LoadField: d5 = r1->field_33
    //     0xb32b1c: ldur            d5, [x1, #0x33]
    // 0xb32b20: LoadField: d6 = r2->field_7
    //     0xb32b20: ldur            d6, [x2, #7]
    // 0xb32b24: fadd            d7, d5, d6
    // 0xb32b28: stur            d7, [fp, #-0x20]
    // 0xb32b2c: LoadField: d5 = r1->field_3b
    //     0xb32b2c: ldur            d5, [x1, #0x3b]
    // 0xb32b30: LoadField: d6 = r2->field_f
    //     0xb32b30: ldur            d6, [x2, #0xf]
    // 0xb32b34: fadd            d8, d5, d6
    // 0xb32b38: stur            d8, [fp, #-0x18]
    // 0xb32b3c: LoadField: r2 = r1->field_43
    //     0xb32b3c: ldur            x2, [x1, #0x43]
    // 0xb32b40: stur            x2, [fp, #-8]
    // 0xb32b44: r0 = LineMetrics()
    //     0xb32b44: bl              #0x85f9f0  ; AllocateLineMetricsStub -> LineMetrics (size=0x4c)
    // 0xb32b48: ldur            x1, [fp, #-0x10]
    // 0xb32b4c: StoreField: r0->field_7 = r1
    //     0xb32b4c: stur            w1, [x0, #7]
    // 0xb32b50: ldur            d0, [fp, #-0x48]
    // 0xb32b54: StoreField: r0->field_b = d0
    //     0xb32b54: stur            d0, [x0, #0xb]
    // 0xb32b58: ldur            d0, [fp, #-0x40]
    // 0xb32b5c: StoreField: r0->field_13 = d0
    //     0xb32b5c: stur            d0, [x0, #0x13]
    // 0xb32b60: ldur            d0, [fp, #-0x38]
    // 0xb32b64: StoreField: r0->field_1b = d0
    //     0xb32b64: stur            d0, [x0, #0x1b]
    // 0xb32b68: ldur            d0, [fp, #-0x30]
    // 0xb32b6c: StoreField: r0->field_23 = d0
    //     0xb32b6c: stur            d0, [x0, #0x23]
    // 0xb32b70: ldur            d0, [fp, #-0x28]
    // 0xb32b74: StoreField: r0->field_2b = d0
    //     0xb32b74: stur            d0, [x0, #0x2b]
    // 0xb32b78: ldur            d0, [fp, #-0x20]
    // 0xb32b7c: StoreField: r0->field_33 = d0
    //     0xb32b7c: stur            d0, [x0, #0x33]
    // 0xb32b80: ldur            d0, [fp, #-0x18]
    // 0xb32b84: StoreField: r0->field_3b = d0
    //     0xb32b84: stur            d0, [x0, #0x3b]
    // 0xb32b88: ldur            x1, [fp, #-8]
    // 0xb32b8c: StoreField: r0->field_43 = r1
    //     0xb32b8c: stur            x1, [x0, #0x43]
    // 0xb32b90: LeaveFrame
    //     0xb32b90: mov             SP, fp
    //     0xb32b94: ldp             fp, lr, [SP], #0x10
    // 0xb32b98: ret
    //     0xb32b98: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5b360, size: 0x110
    // 0xb5b360: EnterFrame
    //     0xb5b360: stp             fp, lr, [SP, #-0x10]!
    //     0xb5b364: mov             fp, SP
    // 0xb5b368: AllocStack(0x18)
    //     0xb5b368: sub             SP, SP, #0x18
    // 0xb5b36c: CheckStackOverflow
    //     0xb5b36c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5b370: cmp             SP, x16
    //     0xb5b374: b.ls            #0xb5b45c
    // 0xb5b378: LoadField: r0 = r1->field_7
    //     0xb5b378: ldur            w0, [x1, #7]
    // 0xb5b37c: DecompressPointer r0
    //     0xb5b37c: add             x0, x0, HEAP, lsl #32
    // 0xb5b380: cmp             w0, NULL
    // 0xb5b384: b.eq            #0xb5b464
    // 0xb5b388: LoadField: r1 = r0->field_7
    //     0xb5b388: ldur            w1, [x0, #7]
    // 0xb5b38c: DecompressPointer r1
    //     0xb5b38c: add             x1, x1, HEAP, lsl #32
    // 0xb5b390: LoadField: r0 = r2->field_7
    //     0xb5b390: ldur            x0, [x2, #7]
    // 0xb5b394: cmp             x0, #0
    // 0xb5b398: b.gt            #0xb5b3e8
    // 0xb5b39c: LoadField: r0 = r1->field_f
    //     0xb5b39c: ldur            w0, [x1, #0xf]
    // 0xb5b3a0: DecompressPointer r0
    //     0xb5b3a0: add             x0, x0, HEAP, lsl #32
    // 0xb5b3a4: stur            x0, [fp, #-0x10]
    // 0xb5b3a8: LoadField: r1 = r0->field_7
    //     0xb5b3a8: ldur            w1, [x0, #7]
    // 0xb5b3ac: DecompressPointer r1
    //     0xb5b3ac: add             x1, x1, HEAP, lsl #32
    // 0xb5b3b0: cmp             w1, NULL
    // 0xb5b3b4: b.eq            #0xb5b468
    // 0xb5b3b8: LoadField: r2 = r1->field_7
    //     0xb5b3b8: ldur            x2, [x1, #7]
    // 0xb5b3bc: ldr             x1, [x2]
    // 0xb5b3c0: cbz             x1, #0xb5b43c
    // 0xb5b3c4: mov             x2, x1
    // 0xb5b3c8: stur            x2, [fp, #-8]
    // 0xb5b3cc: r1 = <Never>
    //     0xb5b3cc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb5b3d0: r0 = Pointer()
    //     0xb5b3d0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb5b3d4: mov             x1, x0
    // 0xb5b3d8: ldur            x0, [fp, #-8]
    // 0xb5b3dc: StoreField: r1->field_7 = r0
    //     0xb5b3dc: stur            x0, [x1, #7]
    // 0xb5b3e0: r0 = _alphabeticBaseline$Getter$FfiNative()
    //     0xb5b3e0: bl              #0xb5b500  ; [dart:ui] _NativeParagraph::_alphabeticBaseline$Getter$FfiNative
    // 0xb5b3e4: b               #0xb5b430
    // 0xb5b3e8: LoadField: r0 = r1->field_f
    //     0xb5b3e8: ldur            w0, [x1, #0xf]
    // 0xb5b3ec: DecompressPointer r0
    //     0xb5b3ec: add             x0, x0, HEAP, lsl #32
    // 0xb5b3f0: stur            x0, [fp, #-0x10]
    // 0xb5b3f4: LoadField: r1 = r0->field_7
    //     0xb5b3f4: ldur            w1, [x0, #7]
    // 0xb5b3f8: DecompressPointer r1
    //     0xb5b3f8: add             x1, x1, HEAP, lsl #32
    // 0xb5b3fc: cmp             w1, NULL
    // 0xb5b400: b.eq            #0xb5b46c
    // 0xb5b404: LoadField: r2 = r1->field_7
    //     0xb5b404: ldur            x2, [x1, #7]
    // 0xb5b408: ldr             x1, [x2]
    // 0xb5b40c: cbz             x1, #0xb5b44c
    // 0xb5b410: mov             x2, x1
    // 0xb5b414: stur            x2, [fp, #-8]
    // 0xb5b418: r1 = <Never>
    //     0xb5b418: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb5b41c: r0 = Pointer()
    //     0xb5b41c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb5b420: mov             x1, x0
    // 0xb5b424: ldur            x0, [fp, #-8]
    // 0xb5b428: StoreField: r1->field_7 = r0
    //     0xb5b428: stur            x0, [x1, #7]
    // 0xb5b42c: r0 = _ideographicBaseline$Getter$FfiNative()
    //     0xb5b42c: bl              #0xb5b470  ; [dart:ui] _NativeParagraph::_ideographicBaseline$Getter$FfiNative
    // 0xb5b430: LeaveFrame
    //     0xb5b430: mov             SP, fp
    //     0xb5b434: ldp             fp, lr, [SP], #0x10
    // 0xb5b438: ret
    //     0xb5b438: ret             
    // 0xb5b43c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb5b43c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb5b440: str             x16, [SP]
    // 0xb5b444: r0 = _throwNew()
    //     0xb5b444: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb5b448: brk             #0
    // 0xb5b44c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb5b44c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb5b450: str             x16, [SP]
    // 0xb5b454: r0 = _throwNew()
    //     0xb5b454: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb5b458: brk             #0
    // 0xb5b45c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5b45c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5b460: b               #0xb5b378
    // 0xb5b464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5b464: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb5b468: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb5b468: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb5b46c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb5b46c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getWordBoundary(/* No info */) {
    // ** addr: 0xb984a8, size: 0x54
    // 0xb984a8: EnterFrame
    //     0xb984a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb984ac: mov             fp, SP
    // 0xb984b0: CheckStackOverflow
    //     0xb984b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb984b4: cmp             SP, x16
    //     0xb984b8: b.ls            #0xb984f0
    // 0xb984bc: LoadField: r0 = r1->field_7
    //     0xb984bc: ldur            w0, [x1, #7]
    // 0xb984c0: DecompressPointer r0
    //     0xb984c0: add             x0, x0, HEAP, lsl #32
    // 0xb984c4: cmp             w0, NULL
    // 0xb984c8: b.eq            #0xb984f8
    // 0xb984cc: LoadField: r1 = r0->field_7
    //     0xb984cc: ldur            w1, [x0, #7]
    // 0xb984d0: DecompressPointer r1
    //     0xb984d0: add             x1, x1, HEAP, lsl #32
    // 0xb984d4: LoadField: r0 = r1->field_f
    //     0xb984d4: ldur            w0, [x1, #0xf]
    // 0xb984d8: DecompressPointer r0
    //     0xb984d8: add             x0, x0, HEAP, lsl #32
    // 0xb984dc: mov             x1, x0
    // 0xb984e0: r0 = getWordBoundary()
    //     0xb984e0: bl              #0xb97efc  ; [dart:ui] _NativeParagraph::getWordBoundary
    // 0xb984e4: LeaveFrame
    //     0xb984e4: mov             SP, fp
    //     0xb984e8: ldp             fp, lr, [SP], #0x10
    // 0xb984ec: ret
    //     0xb984ec: ret             
    // 0xb984f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb984f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb984f4: b               #0xb984bc
    // 0xb984f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb984f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ inlinePlaceholderBoxes(/* No info */) {
    // ** addr: 0xbc401c, size: 0x134
    // 0xbc401c: EnterFrame
    //     0xbc401c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc4020: mov             fp, SP
    // 0xbc4024: AllocStack(0x30)
    //     0xbc4024: sub             SP, SP, #0x30
    // 0xbc4028: CheckStackOverflow
    //     0xbc4028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc402c: cmp             SP, x16
    //     0xbc4030: b.ls            #0xbc4148
    // 0xbc4034: LoadField: r0 = r1->field_7
    //     0xbc4034: ldur            w0, [x1, #7]
    // 0xbc4038: DecompressPointer r0
    //     0xbc4038: add             x0, x0, HEAP, lsl #32
    // 0xbc403c: stur            x0, [fp, #-8]
    // 0xbc4040: cmp             w0, NULL
    // 0xbc4044: b.ne            #0xbc4058
    // 0xbc4048: r0 = Null
    //     0xbc4048: mov             x0, NULL
    // 0xbc404c: LeaveFrame
    //     0xbc404c: mov             SP, fp
    //     0xbc4050: ldp             fp, lr, [SP], #0x10
    // 0xbc4054: ret
    //     0xbc4054: ret             
    // 0xbc4058: mov             x1, x0
    // 0xbc405c: r0 = paintOffset()
    //     0xbc405c: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0xbc4060: stur            x0, [fp, #-0x10]
    // 0xbc4064: r1 = 1
    //     0xbc4064: mov             x1, #1
    // 0xbc4068: r0 = AllocateContext()
    //     0xbc4068: bl              #0x13de838  ; AllocateContextStub
    // 0xbc406c: mov             x2, x0
    // 0xbc4070: ldur            x0, [fp, #-0x10]
    // 0xbc4074: stur            x2, [fp, #-0x18]
    // 0xbc4078: StoreField: r2->field_f = r0
    //     0xbc4078: stur            w0, [x2, #0xf]
    // 0xbc407c: LoadField: d0 = r0->field_7
    //     0xbc407c: ldur            d0, [x0, #7]
    // 0xbc4080: mov             x1, v0.d[0]
    // 0xbc4084: and             x1, x1, #0x7fffffffffffffff
    // 0xbc4088: r17 = 9218868437227405312
    //     0xbc4088: mov             x17, #0x7ff0000000000000
    // 0xbc408c: cmp             x1, x17
    // 0xbc4090: b.eq            #0xbc4130
    // 0xbc4094: fcmp            d0, d0
    // 0xbc4098: b.vs            #0xbc4130
    // 0xbc409c: LoadField: d0 = r0->field_f
    //     0xbc409c: ldur            d0, [x0, #0xf]
    // 0xbc40a0: mov             x1, v0.d[0]
    // 0xbc40a4: and             x1, x1, #0x7fffffffffffffff
    // 0xbc40a8: r17 = 9218868437227405312
    //     0xbc40a8: mov             x17, #0x7ff0000000000000
    // 0xbc40ac: cmp             x1, x17
    // 0xbc40b0: b.eq            #0xbc4130
    // 0xbc40b4: fcmp            d0, d0
    // 0xbc40b8: b.vs            #0xbc4130
    // 0xbc40bc: ldur            x1, [fp, #-8]
    // 0xbc40c0: r0 = inlinePlaceholderBoxes()
    //     0xbc40c0: bl              #0xbc4150  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::inlinePlaceholderBoxes
    // 0xbc40c4: stur            x0, [fp, #-8]
    // 0xbc40c8: ldur            x16, [fp, #-0x10]
    // 0xbc40cc: r30 = Instance_Offset
    //     0xbc40cc: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbc40d0: stp             lr, x16, [SP]
    // 0xbc40d4: r0 = ==()
    //     0xbc40d4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xbc40d8: tbnz            w0, #4, #0xbc40ec
    // 0xbc40dc: ldur            x0, [fp, #-8]
    // 0xbc40e0: LeaveFrame
    //     0xbc40e0: mov             SP, fp
    //     0xbc40e4: ldp             fp, lr, [SP], #0x10
    // 0xbc40e8: ret
    //     0xbc40e8: ret             
    // 0xbc40ec: ldur            x2, [fp, #-0x18]
    // 0xbc40f0: r1 = Function '<anonymous closure>':.
    //     0xbc40f0: add             x1, PP, #0x98, lsl #12  ; [pp+0x989a8] AnonymousClosure: (0x85fe64), in [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection (0x85fc0c)
    //     0xbc40f4: ldr             x1, [x1, #0x9a8]
    // 0xbc40f8: r0 = AllocateClosure()
    //     0xbc40f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc40fc: r16 = <TextBox>
    //     0xbc40fc: ldr             x16, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0xbc4100: ldur            lr, [fp, #-8]
    // 0xbc4104: stp             lr, x16, [SP, #8]
    // 0xbc4108: str             x0, [SP]
    // 0xbc410c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbc410c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbc4110: r0 = map()
    //     0xbc4110: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xbc4114: LoadField: r1 = r0->field_7
    //     0xbc4114: ldur            w1, [x0, #7]
    // 0xbc4118: DecompressPointer r1
    //     0xbc4118: add             x1, x1, HEAP, lsl #32
    // 0xbc411c: mov             x2, x0
    // 0xbc4120: r0 = _List.of()
    //     0xbc4120: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0xbc4124: LeaveFrame
    //     0xbc4124: mov             SP, fp
    //     0xbc4128: ldp             fp, lr, [SP], #0x10
    // 0xbc412c: ret
    //     0xbc412c: ret             
    // 0xbc4130: r1 = <TextBox>
    //     0xbc4130: ldr             x1, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0xbc4134: r2 = 0
    //     0xbc4134: mov             x2, #0
    // 0xbc4138: r0 = _GrowableList()
    //     0xbc4138: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbc413c: LeaveFrame
    //     0xbc413c: mov             SP, fp
    //     0xbc4140: ldp             fp, lr, [SP], #0x10
    // 0xbc4144: ret
    //     0xbc4144: ret             
    // 0xbc4148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc4148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc414c: b               #0xbc4034
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbcb780, size: 0x124
    // 0xbcb780: EnterFrame
    //     0xbcb780: stp             fp, lr, [SP, #-0x10]!
    //     0xbcb784: mov             fp, SP
    // 0xbcb788: AllocStack(0x20)
    //     0xbcb788: sub             SP, SP, #0x20
    // 0xbcb78c: SetupParameters(TextPainter this /* r1 => r0, fp-0x18 */)
    //     0xbcb78c: mov             x0, x1
    //     0xbcb790: stur            x1, [fp, #-0x18]
    // 0xbcb794: CheckStackOverflow
    //     0xbcb794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcb798: cmp             SP, x16
    //     0xbcb79c: b.ls            #0xbcb894
    // 0xbcb7a0: LoadField: r2 = r0->field_3f
    //     0xbcb7a0: ldur            w2, [x0, #0x3f]
    // 0xbcb7a4: DecompressPointer r2
    //     0xbcb7a4: add             x2, x2, HEAP, lsl #32
    // 0xbcb7a8: stur            x2, [fp, #-0x10]
    // 0xbcb7ac: cmp             w2, NULL
    // 0xbcb7b0: b.eq            #0xbcb7f4
    // 0xbcb7b4: LoadField: r1 = r2->field_7
    //     0xbcb7b4: ldur            w1, [x2, #7]
    // 0xbcb7b8: DecompressPointer r1
    //     0xbcb7b8: add             x1, x1, HEAP, lsl #32
    // 0xbcb7bc: cmp             w1, NULL
    // 0xbcb7c0: b.eq            #0xbcb89c
    // 0xbcb7c4: LoadField: r3 = r1->field_7
    //     0xbcb7c4: ldur            x3, [x1, #7]
    // 0xbcb7c8: ldr             x1, [x3]
    // 0xbcb7cc: cbz             x1, #0xbcb874
    // 0xbcb7d0: mov             x3, x1
    // 0xbcb7d4: stur            x3, [fp, #-8]
    // 0xbcb7d8: r1 = <Never>
    //     0xbcb7d8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbcb7dc: r0 = Pointer()
    //     0xbcb7dc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbcb7e0: mov             x1, x0
    // 0xbcb7e4: ldur            x0, [fp, #-8]
    // 0xbcb7e8: StoreField: r1->field_7 = r0
    //     0xbcb7e8: stur            x0, [x1, #7]
    // 0xbcb7ec: r0 = __dispose$Method$FfiNative()
    //     0xbcb7ec: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xbcb7f0: ldur            x0, [fp, #-0x18]
    // 0xbcb7f4: StoreField: r0->field_3f = rNULL
    //     0xbcb7f4: stur            NULL, [x0, #0x3f]
    // 0xbcb7f8: LoadField: r1 = r0->field_7
    //     0xbcb7f8: ldur            w1, [x0, #7]
    // 0xbcb7fc: DecompressPointer r1
    //     0xbcb7fc: add             x1, x1, HEAP, lsl #32
    // 0xbcb800: cmp             w1, NULL
    // 0xbcb804: b.eq            #0xbcb85c
    // 0xbcb808: LoadField: r2 = r1->field_7
    //     0xbcb808: ldur            w2, [x1, #7]
    // 0xbcb80c: DecompressPointer r2
    //     0xbcb80c: add             x2, x2, HEAP, lsl #32
    // 0xbcb810: LoadField: r3 = r2->field_f
    //     0xbcb810: ldur            w3, [x2, #0xf]
    // 0xbcb814: DecompressPointer r3
    //     0xbcb814: add             x3, x3, HEAP, lsl #32
    // 0xbcb818: stur            x3, [fp, #-0x10]
    // 0xbcb81c: LoadField: r1 = r3->field_7
    //     0xbcb81c: ldur            w1, [x3, #7]
    // 0xbcb820: DecompressPointer r1
    //     0xbcb820: add             x1, x1, HEAP, lsl #32
    // 0xbcb824: cmp             w1, NULL
    // 0xbcb828: b.eq            #0xbcb8a0
    // 0xbcb82c: LoadField: r2 = r1->field_7
    //     0xbcb82c: ldur            x2, [x1, #7]
    // 0xbcb830: ldr             x1, [x2]
    // 0xbcb834: cbz             x1, #0xbcb884
    // 0xbcb838: mov             x2, x1
    // 0xbcb83c: stur            x2, [fp, #-8]
    // 0xbcb840: r1 = <Never>
    //     0xbcb840: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbcb844: r0 = Pointer()
    //     0xbcb844: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbcb848: mov             x1, x0
    // 0xbcb84c: ldur            x0, [fp, #-8]
    // 0xbcb850: StoreField: r1->field_7 = r0
    //     0xbcb850: stur            x0, [x1, #7]
    // 0xbcb854: r0 = __dispose$Method$FfiNative()
    //     0xbcb854: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xbcb858: ldur            x0, [fp, #-0x18]
    // 0xbcb85c: StoreField: r0->field_7 = rNULL
    //     0xbcb85c: stur            NULL, [x0, #7]
    // 0xbcb860: StoreField: r0->field_f = rNULL
    //     0xbcb860: stur            NULL, [x0, #0xf]
    // 0xbcb864: r0 = Null
    //     0xbcb864: mov             x0, NULL
    // 0xbcb868: LeaveFrame
    //     0xbcb868: mov             SP, fp
    //     0xbcb86c: ldp             fp, lr, [SP], #0x10
    // 0xbcb870: ret
    //     0xbcb870: ret             
    // 0xbcb874: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbcb874: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbcb878: str             x16, [SP]
    // 0xbcb87c: r0 = _throwNew()
    //     0xbcb87c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbcb880: brk             #0
    // 0xbcb884: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbcb884: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbcb888: str             x16, [SP]
    // 0xbcb88c: r0 = _throwNew()
    //     0xbcb88c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbcb890: brk             #0
    // 0xbcb894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcb894: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcb898: b               #0xbcb7a0
    // 0xbcb89c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbcb89c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbcb8a0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbcb8a0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ didExceedMaxLines(/* No info */) {
    // ** addr: 0xbcc1a4, size: 0xa4
    // 0xbcc1a4: EnterFrame
    //     0xbcc1a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc1a8: mov             fp, SP
    // 0xbcc1ac: AllocStack(0x18)
    //     0xbcc1ac: sub             SP, SP, #0x18
    // 0xbcc1b0: CheckStackOverflow
    //     0xbcc1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcc1b4: cmp             SP, x16
    //     0xbcc1b8: b.ls            #0xbcc238
    // 0xbcc1bc: LoadField: r0 = r1->field_7
    //     0xbcc1bc: ldur            w0, [x1, #7]
    // 0xbcc1c0: DecompressPointer r0
    //     0xbcc1c0: add             x0, x0, HEAP, lsl #32
    // 0xbcc1c4: cmp             w0, NULL
    // 0xbcc1c8: b.eq            #0xbcc240
    // 0xbcc1cc: LoadField: r1 = r0->field_7
    //     0xbcc1cc: ldur            w1, [x0, #7]
    // 0xbcc1d0: DecompressPointer r1
    //     0xbcc1d0: add             x1, x1, HEAP, lsl #32
    // 0xbcc1d4: LoadField: r0 = r1->field_f
    //     0xbcc1d4: ldur            w0, [x1, #0xf]
    // 0xbcc1d8: DecompressPointer r0
    //     0xbcc1d8: add             x0, x0, HEAP, lsl #32
    // 0xbcc1dc: stur            x0, [fp, #-0x10]
    // 0xbcc1e0: LoadField: r1 = r0->field_7
    //     0xbcc1e0: ldur            w1, [x0, #7]
    // 0xbcc1e4: DecompressPointer r1
    //     0xbcc1e4: add             x1, x1, HEAP, lsl #32
    // 0xbcc1e8: cmp             w1, NULL
    // 0xbcc1ec: b.eq            #0xbcc244
    // 0xbcc1f0: LoadField: r2 = r1->field_7
    //     0xbcc1f0: ldur            x2, [x1, #7]
    // 0xbcc1f4: ldr             x1, [x2]
    // 0xbcc1f8: cbz             x1, #0xbcc228
    // 0xbcc1fc: mov             x2, x1
    // 0xbcc200: stur            x2, [fp, #-8]
    // 0xbcc204: r1 = <Never>
    //     0xbcc204: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbcc208: r0 = Pointer()
    //     0xbcc208: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbcc20c: mov             x1, x0
    // 0xbcc210: ldur            x0, [fp, #-8]
    // 0xbcc214: StoreField: r1->field_7 = r0
    //     0xbcc214: stur            x0, [x1, #7]
    // 0xbcc218: r0 = _didExceedMaxLines$Getter$FfiNative()
    //     0xbcc218: bl              #0xbcc248  ; [dart:ui] _NativeParagraph::_didExceedMaxLines$Getter$FfiNative
    // 0xbcc21c: LeaveFrame
    //     0xbcc21c: mov             SP, fp
    //     0xbcc220: ldp             fp, lr, [SP], #0x10
    // 0xbcc224: ret
    //     0xbcc224: ret             
    // 0xbcc228: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbcc228: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbcc22c: str             x16, [SP]
    // 0xbcc230: r0 = _throwNew()
    //     0xbcc230: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbcc234: brk             #0
    // 0xbcc238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcc238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcc23c: b               #0xbcc1bc
    // 0xbcc240: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcc240: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcc244: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbcc244: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getOffsetAfter(/* No info */) {
    // ** addr: 0xbf7e94, size: 0xb0
    // 0xbf7e94: EnterFrame
    //     0xbf7e94: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7e98: mov             fp, SP
    // 0xbf7e9c: AllocStack(0x8)
    //     0xbf7e9c: sub             SP, SP, #8
    // 0xbf7ea0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xbf7ea0: mov             x0, x2
    //     0xbf7ea4: stur            x2, [fp, #-8]
    // 0xbf7ea8: CheckStackOverflow
    //     0xbf7ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7eac: cmp             SP, x16
    //     0xbf7eb0: b.ls            #0xbf7f38
    // 0xbf7eb4: LoadField: r2 = r1->field_f
    //     0xbf7eb4: ldur            w2, [x1, #0xf]
    // 0xbf7eb8: DecompressPointer r2
    //     0xbf7eb8: add             x2, x2, HEAP, lsl #32
    // 0xbf7ebc: cmp             w2, NULL
    // 0xbf7ec0: b.eq            #0xbf7f40
    // 0xbf7ec4: mov             x1, x2
    // 0xbf7ec8: mov             x2, x0
    // 0xbf7ecc: r0 = codeUnitAt()
    //     0xbf7ecc: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0xbf7ed0: cmp             w0, NULL
    // 0xbf7ed4: b.ne            #0xbf7ee8
    // 0xbf7ed8: r0 = Null
    //     0xbf7ed8: mov             x0, NULL
    // 0xbf7edc: LeaveFrame
    //     0xbf7edc: mov             SP, fp
    //     0xbf7ee0: ldp             fp, lr, [SP], #0x10
    // 0xbf7ee4: ret
    //     0xbf7ee4: ret             
    // 0xbf7ee8: r2 = LoadInt32Instr(r0)
    //     0xbf7ee8: sbfx            x2, x0, #1, #0x1f
    // 0xbf7eec: and             w3, w2, #0xfc00
    // 0xbf7ef0: r17 = 55296
    //     0xbf7ef0: mov             x17, #0xd800
    // 0xbf7ef4: cmp             w3, w17
    // 0xbf7ef8: b.ne            #0xbf7f0c
    // 0xbf7efc: ldur            x2, [fp, #-8]
    // 0xbf7f00: add             x3, x2, #2
    // 0xbf7f04: mov             x2, x3
    // 0xbf7f08: b               #0xbf7f18
    // 0xbf7f0c: ldur            x2, [fp, #-8]
    // 0xbf7f10: add             x3, x2, #1
    // 0xbf7f14: mov             x2, x3
    // 0xbf7f18: r0 = BoxInt64Instr(r2)
    //     0xbf7f18: sbfiz           x0, x2, #1, #0x1f
    //     0xbf7f1c: cmp             x2, x0, asr #1
    //     0xbf7f20: b.eq            #0xbf7f2c
    //     0xbf7f24: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf7f28: stur            x2, [x0, #7]
    // 0xbf7f2c: LeaveFrame
    //     0xbf7f2c: mov             SP, fp
    //     0xbf7f30: ldp             fp, lr, [SP], #0x10
    // 0xbf7f34: ret
    //     0xbf7f34: ret             
    // 0xbf7f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7f38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7f3c: b               #0xbf7eb4
    // 0xbf7f40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7f40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getOffsetBefore(/* No info */) {
    // ** addr: 0xbf83a4, size: 0xb0
    // 0xbf83a4: EnterFrame
    //     0xbf83a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf83a8: mov             fp, SP
    // 0xbf83ac: AllocStack(0x10)
    //     0xbf83ac: sub             SP, SP, #0x10
    // 0xbf83b0: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf83b0: mov             x0, x2
    //     0xbf83b4: stur            x2, [fp, #-0x10]
    // 0xbf83b8: CheckStackOverflow
    //     0xbf83b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf83bc: cmp             SP, x16
    //     0xbf83c0: b.ls            #0xbf8448
    // 0xbf83c4: LoadField: r2 = r1->field_f
    //     0xbf83c4: ldur            w2, [x1, #0xf]
    // 0xbf83c8: DecompressPointer r2
    //     0xbf83c8: add             x2, x2, HEAP, lsl #32
    // 0xbf83cc: cmp             w2, NULL
    // 0xbf83d0: b.eq            #0xbf8450
    // 0xbf83d4: sub             x3, x0, #1
    // 0xbf83d8: mov             x1, x2
    // 0xbf83dc: mov             x2, x3
    // 0xbf83e0: stur            x3, [fp, #-8]
    // 0xbf83e4: r0 = codeUnitAt()
    //     0xbf83e4: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0xbf83e8: cmp             w0, NULL
    // 0xbf83ec: b.ne            #0xbf8400
    // 0xbf83f0: r0 = Null
    //     0xbf83f0: mov             x0, NULL
    // 0xbf83f4: LeaveFrame
    //     0xbf83f4: mov             SP, fp
    //     0xbf83f8: ldp             fp, lr, [SP], #0x10
    // 0xbf83fc: ret
    //     0xbf83fc: ret             
    // 0xbf8400: r2 = LoadInt32Instr(r0)
    //     0xbf8400: sbfx            x2, x0, #1, #0x1f
    // 0xbf8404: and             w3, w2, #0xfc00
    // 0xbf8408: r17 = 56320
    //     0xbf8408: mov             x17, #0xdc00
    // 0xbf840c: cmp             w3, w17
    // 0xbf8410: b.ne            #0xbf8424
    // 0xbf8414: ldur            x2, [fp, #-0x10]
    // 0xbf8418: sub             x3, x2, #2
    // 0xbf841c: mov             x2, x3
    // 0xbf8420: b               #0xbf8428
    // 0xbf8424: ldur            x2, [fp, #-8]
    // 0xbf8428: r0 = BoxInt64Instr(r2)
    //     0xbf8428: sbfiz           x0, x2, #1, #0x1f
    //     0xbf842c: cmp             x2, x0, asr #1
    //     0xbf8430: b.eq            #0xbf843c
    //     0xbf8434: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf8438: stur            x2, [x0, #7]
    // 0xbf843c: LeaveFrame
    //     0xbf843c: mov             SP, fp
    //     0xbf8440: ldp             fp, lr, [SP], #0x10
    // 0xbf8444: ret
    //     0xbf8444: ret             
    // 0xbf8448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf844c: b               #0xbf83c4
    // 0xbf8450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8450: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textScaleFactor=(/* No info */) {
    // ** addr: 0xc06b24, size: 0x50
    // 0xc06b24: EnterFrame
    //     0xc06b24: stp             fp, lr, [SP, #-0x10]!
    //     0xc06b28: mov             fp, SP
    // 0xc06b2c: AllocStack(0x10)
    //     0xc06b2c: sub             SP, SP, #0x10
    // 0xc06b30: SetupParameters(TextPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xc06b30: stur            x1, [fp, #-8]
    //     0xc06b34: stur            d0, [fp, #-0x10]
    // 0xc06b38: CheckStackOverflow
    //     0xc06b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06b3c: cmp             SP, x16
    //     0xc06b40: b.ls            #0xc06b6c
    // 0xc06b44: r0 = _LinearTextScaler()
    //     0xc06b44: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0xc06b48: ldur            d0, [fp, #-0x10]
    // 0xc06b4c: StoreField: r0->field_7 = d0
    //     0xc06b4c: stur            d0, [x0, #7]
    // 0xc06b50: ldur            x1, [fp, #-8]
    // 0xc06b54: mov             x2, x0
    // 0xc06b58: r0 = textScaler=()
    //     0xc06b58: bl              #0xb1d0b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaler=
    // 0xc06b5c: r0 = Null
    //     0xc06b5c: mov             x0, NULL
    // 0xc06b60: LeaveFrame
    //     0xc06b60: mov             SP, fp
    //     0xc06b64: ldp             fp, lr, [SP], #0x10
    // 0xc06b68: ret
    //     0xc06b68: ret             
    // 0xc06b6c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc06b6c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc06b70: b               #0xc06b44
  }
  _ paint(/* No info */) {
    // ** addr: 0xc22fac, size: 0x23c
    // 0xc22fac: EnterFrame
    //     0xc22fac: stp             fp, lr, [SP, #-0x10]!
    //     0xc22fb0: mov             fp, SP
    // 0xc22fb4: AllocStack(0x48)
    //     0xc22fb4: sub             SP, SP, #0x48
    // 0xc22fb8: SetupParameters(TextPainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0xc22fb8: mov             x0, x3
    //     0xc22fbc: stur            x3, [fp, #-0x20]
    //     0xc22fc0: mov             x3, x1
    //     0xc22fc4: stur            x1, [fp, #-0x10]
    //     0xc22fc8: stur            x2, [fp, #-0x18]
    // 0xc22fcc: CheckStackOverflow
    //     0xc22fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc22fd0: cmp             SP, x16
    //     0xc22fd4: b.ls            #0xc231d4
    // 0xc22fd8: LoadField: r4 = r3->field_7
    //     0xc22fd8: ldur            w4, [x3, #7]
    // 0xc22fdc: DecompressPointer r4
    //     0xc22fdc: add             x4, x4, HEAP, lsl #32
    // 0xc22fe0: stur            x4, [fp, #-8]
    // 0xc22fe4: cmp             w4, NULL
    // 0xc22fe8: b.eq            #0xc23194
    // 0xc22fec: mov             x1, x4
    // 0xc22ff0: r0 = paintOffset()
    //     0xc22ff0: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0xc22ff4: LoadField: d0 = r0->field_7
    //     0xc22ff4: ldur            d0, [x0, #7]
    // 0xc22ff8: mov             x0, v0.d[0]
    // 0xc22ffc: and             x0, x0, #0x7fffffffffffffff
    // 0xc23000: r17 = 9218868437227405312
    //     0xc23000: mov             x17, #0x7ff0000000000000
    // 0xc23004: cmp             x0, x17
    // 0xc23008: b.eq            #0xc23184
    // 0xc2300c: fcmp            d0, d0
    // 0xc23010: b.vs            #0xc23184
    // 0xc23014: ldur            x1, [fp, #-8]
    // 0xc23018: r0 = paintOffset()
    //     0xc23018: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0xc2301c: LoadField: d0 = r0->field_f
    //     0xc2301c: ldur            d0, [x0, #0xf]
    // 0xc23020: mov             x0, v0.d[0]
    // 0xc23024: and             x0, x0, #0x7fffffffffffffff
    // 0xc23028: r17 = 9218868437227405312
    //     0xc23028: mov             x17, #0x7ff0000000000000
    // 0xc2302c: cmp             x0, x17
    // 0xc23030: b.eq            #0xc23184
    // 0xc23034: fcmp            d0, d0
    // 0xc23038: b.vs            #0xc23184
    // 0xc2303c: ldur            x1, [fp, #-0x10]
    // 0xc23040: LoadField: r0 = r1->field_b
    //     0xc23040: ldur            w0, [x1, #0xb]
    // 0xc23044: DecompressPointer r0
    //     0xc23044: add             x0, x0, HEAP, lsl #32
    // 0xc23048: tbnz            w0, #4, #0xc2313c
    // 0xc2304c: ldur            x0, [fp, #-8]
    // 0xc23050: LoadField: r3 = r0->field_7
    //     0xc23050: ldur            w3, [x0, #7]
    // 0xc23054: DecompressPointer r3
    //     0xc23054: add             x3, x3, HEAP, lsl #32
    // 0xc23058: stur            x3, [fp, #-0x30]
    // 0xc2305c: LoadField: r4 = r3->field_f
    //     0xc2305c: ldur            w4, [x3, #0xf]
    // 0xc23060: DecompressPointer r4
    //     0xc23060: add             x4, x4, HEAP, lsl #32
    // 0xc23064: stur            x4, [fp, #-0x28]
    // 0xc23068: LoadField: r2 = r1->field_f
    //     0xc23068: ldur            w2, [x1, #0xf]
    // 0xc2306c: DecompressPointer r2
    //     0xc2306c: add             x2, x2, HEAP, lsl #32
    // 0xc23070: cmp             w2, NULL
    // 0xc23074: b.eq            #0xc231dc
    // 0xc23078: r0 = _createParagraph()
    //     0xc23078: bl              #0x8607b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraph
    // 0xc2307c: mov             x2, x0
    // 0xc23080: ldur            x0, [fp, #-8]
    // 0xc23084: stur            x2, [fp, #-0x10]
    // 0xc23088: LoadField: d0 = r0->field_b
    //     0xc23088: ldur            d0, [x0, #0xb]
    // 0xc2308c: stur            d0, [fp, #-0x40]
    // 0xc23090: LoadField: r1 = r2->field_7
    //     0xc23090: ldur            w1, [x2, #7]
    // 0xc23094: DecompressPointer r1
    //     0xc23094: add             x1, x1, HEAP, lsl #32
    // 0xc23098: cmp             w1, NULL
    // 0xc2309c: b.eq            #0xc231e0
    // 0xc230a0: LoadField: r3 = r1->field_7
    //     0xc230a0: ldur            x3, [x1, #7]
    // 0xc230a4: ldr             x1, [x3]
    // 0xc230a8: cbz             x1, #0xc231b4
    // 0xc230ac: ldur            x3, [fp, #-0x30]
    // 0xc230b0: ldur            x4, [fp, #-0x28]
    // 0xc230b4: mov             x5, x1
    // 0xc230b8: stur            x5, [fp, #-0x38]
    // 0xc230bc: r1 = <Never>
    //     0xc230bc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc230c0: r0 = Pointer()
    //     0xc230c0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc230c4: mov             x1, x0
    // 0xc230c8: ldur            x0, [fp, #-0x38]
    // 0xc230cc: StoreField: r1->field_7 = r0
    //     0xc230cc: stur            x0, [x1, #7]
    // 0xc230d0: ldur            d0, [fp, #-0x40]
    // 0xc230d4: r0 = __layout$Method$FfiNative()
    //     0xc230d4: bl              #0x85a058  ; [dart:ui] _NativeParagraph::__layout$Method$FfiNative
    // 0xc230d8: ldur            x0, [fp, #-0x10]
    // 0xc230dc: ldur            x1, [fp, #-0x30]
    // 0xc230e0: StoreField: r1->field_f = r0
    //     0xc230e0: stur            w0, [x1, #0xf]
    //     0xc230e4: ldurb           w16, [x1, #-1]
    //     0xc230e8: ldurb           w17, [x0, #-1]
    //     0xc230ec: and             x16, x17, x16, lsr #2
    //     0xc230f0: tst             x16, HEAP, lsr #32
    //     0xc230f4: b.eq            #0xc230fc
    //     0xc230f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc230fc: ldur            x0, [fp, #-0x28]
    // 0xc23100: LoadField: r1 = r0->field_7
    //     0xc23100: ldur            w1, [x0, #7]
    // 0xc23104: DecompressPointer r1
    //     0xc23104: add             x1, x1, HEAP, lsl #32
    // 0xc23108: cmp             w1, NULL
    // 0xc2310c: b.eq            #0xc231e4
    // 0xc23110: LoadField: r2 = r1->field_7
    //     0xc23110: ldur            x2, [x1, #7]
    // 0xc23114: ldr             x1, [x2]
    // 0xc23118: cbz             x1, #0xc231c4
    // 0xc2311c: mov             x2, x1
    // 0xc23120: stur            x2, [fp, #-0x38]
    // 0xc23124: r1 = <Never>
    //     0xc23124: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc23128: r0 = Pointer()
    //     0xc23128: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc2312c: mov             x1, x0
    // 0xc23130: ldur            x0, [fp, #-0x38]
    // 0xc23134: StoreField: r1->field_7 = r0
    //     0xc23134: stur            x0, [x1, #7]
    // 0xc23138: r0 = __dispose$Method$FfiNative()
    //     0xc23138: bl              #0xb1cae8  ; [dart:ui] _NativeParagraph::__dispose$Method$FfiNative
    // 0xc2313c: ldur            x1, [fp, #-8]
    // 0xc23140: LoadField: r0 = r1->field_7
    //     0xc23140: ldur            w0, [x1, #7]
    // 0xc23144: DecompressPointer r0
    //     0xc23144: add             x0, x0, HEAP, lsl #32
    // 0xc23148: LoadField: r2 = r0->field_f
    //     0xc23148: ldur            w2, [x0, #0xf]
    // 0xc2314c: DecompressPointer r2
    //     0xc2314c: add             x2, x2, HEAP, lsl #32
    // 0xc23150: stur            x2, [fp, #-0x10]
    // 0xc23154: r0 = paintOffset()
    //     0xc23154: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0xc23158: ldur            x1, [fp, #-0x20]
    // 0xc2315c: mov             x2, x0
    // 0xc23160: r0 = +()
    //     0xc23160: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc23164: ldur            x1, [fp, #-0x18]
    // 0xc23168: ldur            x2, [fp, #-0x10]
    // 0xc2316c: mov             x3, x0
    // 0xc23170: r0 = drawParagraph()
    //     0xc23170: bl              #0xc231e8  ; [dart:ui] _NativeCanvas::drawParagraph
    // 0xc23174: r0 = Null
    //     0xc23174: mov             x0, NULL
    // 0xc23178: LeaveFrame
    //     0xc23178: mov             SP, fp
    //     0xc2317c: ldp             fp, lr, [SP], #0x10
    // 0xc23180: ret
    //     0xc23180: ret             
    // 0xc23184: r0 = Null
    //     0xc23184: mov             x0, NULL
    // 0xc23188: LeaveFrame
    //     0xc23188: mov             SP, fp
    //     0xc2318c: ldp             fp, lr, [SP], #0x10
    // 0xc23190: ret
    //     0xc23190: ret             
    // 0xc23194: r0 = StateError()
    //     0xc23194: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc23198: mov             x1, x0
    // 0xc2319c: r0 = "TextPainter.paint called when text geometry was not yet calculated.\nPlease call layout() before paint() to position the text before painting it."
    //     0xc2319c: add             x0, PP, #0x97, lsl #12  ; [pp+0x97a50] "TextPainter.paint called when text geometry was not yet calculated.\nPlease call layout() before paint() to position the text before painting it."
    //     0xc231a0: ldr             x0, [x0, #0xa50]
    // 0xc231a4: StoreField: r1->field_b = r0
    //     0xc231a4: stur            w0, [x1, #0xb]
    // 0xc231a8: mov             x0, x1
    // 0xc231ac: r0 = Throw()
    //     0xc231ac: bl              #0x13ddb2c  ; ThrowStub
    // 0xc231b0: brk             #0
    // 0xc231b4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc231b4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc231b8: str             x16, [SP]
    // 0xc231bc: r0 = _throwNew()
    //     0xc231bc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc231c0: brk             #0
    // 0xc231c4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc231c4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc231c8: str             x16, [SP]
    // 0xc231cc: r0 = _throwNew()
    //     0xc231cc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc231d0: brk             #0
    // 0xc231d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc231d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc231d8: b               #0xc22fd8
    // 0xc231dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc231dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc231e0: r0 = NullErrorSharedWithFPURegs()
    //     0xc231e0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc231e4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc231e4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getClosestGlyphForOffset(/* No info */) {
    // ** addr: 0x10ea850, size: 0x118
    // 0x10ea850: EnterFrame
    //     0x10ea850: stp             fp, lr, [SP, #-0x10]!
    //     0x10ea854: mov             fp, SP
    // 0x10ea858: AllocStack(0x30)
    //     0x10ea858: sub             SP, SP, #0x30
    // 0x10ea85c: SetupParameters(dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x10ea85c: mov             x0, x2
    //     0x10ea860: stur            x2, [fp, #-0x18]
    // 0x10ea864: CheckStackOverflow
    //     0x10ea864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ea868: cmp             SP, x16
    //     0x10ea86c: b.ls            #0x10ea95c
    // 0x10ea870: LoadField: r2 = r1->field_7
    //     0x10ea870: ldur            w2, [x1, #7]
    // 0x10ea874: DecompressPointer r2
    //     0x10ea874: add             x2, x2, HEAP, lsl #32
    // 0x10ea878: stur            x2, [fp, #-0x10]
    // 0x10ea87c: cmp             w2, NULL
    // 0x10ea880: b.eq            #0x10ea964
    // 0x10ea884: LoadField: r1 = r2->field_7
    //     0x10ea884: ldur            w1, [x2, #7]
    // 0x10ea888: DecompressPointer r1
    //     0x10ea888: add             x1, x1, HEAP, lsl #32
    // 0x10ea88c: LoadField: r3 = r1->field_f
    //     0x10ea88c: ldur            w3, [x1, #0xf]
    // 0x10ea890: DecompressPointer r3
    //     0x10ea890: add             x3, x3, HEAP, lsl #32
    // 0x10ea894: mov             x1, x2
    // 0x10ea898: stur            x3, [fp, #-8]
    // 0x10ea89c: r0 = paintOffset()
    //     0x10ea89c: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x10ea8a0: ldur            x1, [fp, #-0x18]
    // 0x10ea8a4: mov             x2, x0
    // 0x10ea8a8: r0 = -()
    //     0x10ea8a8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x10ea8ac: ldur            x1, [fp, #-8]
    // 0x10ea8b0: mov             x2, x0
    // 0x10ea8b4: r0 = getClosestGlyphInfoForOffset()
    //     0x10ea8b4: bl              #0x10ea968  ; [dart:ui] _NativeParagraph::getClosestGlyphInfoForOffset
    // 0x10ea8b8: stur            x0, [fp, #-8]
    // 0x10ea8bc: cmp             w0, NULL
    // 0x10ea8c0: b.eq            #0x10ea8dc
    // 0x10ea8c4: ldur            x1, [fp, #-0x10]
    // 0x10ea8c8: r0 = paintOffset()
    //     0x10ea8c8: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x10ea8cc: r16 = Instance_Offset
    //     0x10ea8cc: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x10ea8d0: stp             x16, x0, [SP]
    // 0x10ea8d4: r0 = ==()
    //     0x10ea8d4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x10ea8d8: tbnz            w0, #4, #0x10ea8ec
    // 0x10ea8dc: ldur            x0, [fp, #-8]
    // 0x10ea8e0: LeaveFrame
    //     0x10ea8e0: mov             SP, fp
    //     0x10ea8e4: ldp             fp, lr, [SP], #0x10
    // 0x10ea8e8: ret
    //     0x10ea8e8: ret             
    // 0x10ea8ec: ldur            x0, [fp, #-8]
    // 0x10ea8f0: LoadField: r2 = r0->field_7
    //     0x10ea8f0: ldur            w2, [x0, #7]
    // 0x10ea8f4: DecompressPointer r2
    //     0x10ea8f4: add             x2, x2, HEAP, lsl #32
    // 0x10ea8f8: ldur            x1, [fp, #-0x10]
    // 0x10ea8fc: stur            x2, [fp, #-0x18]
    // 0x10ea900: r0 = paintOffset()
    //     0x10ea900: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x10ea904: ldur            x1, [fp, #-0x18]
    // 0x10ea908: mov             x2, x0
    // 0x10ea90c: r0 = shift()
    //     0x10ea90c: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x10ea910: mov             x1, x0
    // 0x10ea914: ldur            x0, [fp, #-8]
    // 0x10ea918: stur            x1, [fp, #-0x20]
    // 0x10ea91c: LoadField: r2 = r0->field_b
    //     0x10ea91c: ldur            w2, [x0, #0xb]
    // 0x10ea920: DecompressPointer r2
    //     0x10ea920: add             x2, x2, HEAP, lsl #32
    // 0x10ea924: stur            x2, [fp, #-0x18]
    // 0x10ea928: LoadField: r3 = r0->field_f
    //     0x10ea928: ldur            w3, [x0, #0xf]
    // 0x10ea92c: DecompressPointer r3
    //     0x10ea92c: add             x3, x3, HEAP, lsl #32
    // 0x10ea930: stur            x3, [fp, #-0x10]
    // 0x10ea934: r0 = GlyphInfo()
    //     0x10ea934: bl              #0x85fb88  ; AllocateGlyphInfoStub -> GlyphInfo (size=0x14)
    // 0x10ea938: ldur            x1, [fp, #-0x20]
    // 0x10ea93c: StoreField: r0->field_7 = r1
    //     0x10ea93c: stur            w1, [x0, #7]
    // 0x10ea940: ldur            x1, [fp, #-0x18]
    // 0x10ea944: StoreField: r0->field_b = r1
    //     0x10ea944: stur            w1, [x0, #0xb]
    // 0x10ea948: ldur            x1, [fp, #-0x10]
    // 0x10ea94c: StoreField: r0->field_f = r1
    //     0x10ea94c: stur            w1, [x0, #0xf]
    // 0x10ea950: LeaveFrame
    //     0x10ea950: mov             SP, fp
    //     0x10ea954: ldp             fp, lr, [SP], #0x10
    // 0x10ea958: ret
    //     0x10ea958: ret             
    // 0x10ea95c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ea95c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ea960: b               #0x10ea870
    // 0x10ea964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ea964: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ wordBoundaries(/* No info */) {
    // ** addr: 0x12a2114, size: 0x74
    // 0x12a2114: EnterFrame
    //     0x12a2114: stp             fp, lr, [SP, #-0x10]!
    //     0x12a2118: mov             fp, SP
    // 0x12a211c: AllocStack(0x10)
    //     0x12a211c: sub             SP, SP, #0x10
    // 0x12a2120: LoadField: r0 = r1->field_f
    //     0x12a2120: ldur            w0, [x1, #0xf]
    // 0x12a2124: DecompressPointer r0
    //     0x12a2124: add             x0, x0, HEAP, lsl #32
    // 0x12a2128: stur            x0, [fp, #-0x10]
    // 0x12a212c: cmp             w0, NULL
    // 0x12a2130: b.eq            #0x12a2180
    // 0x12a2134: LoadField: r2 = r1->field_7
    //     0x12a2134: ldur            w2, [x1, #7]
    // 0x12a2138: DecompressPointer r2
    //     0x12a2138: add             x2, x2, HEAP, lsl #32
    // 0x12a213c: cmp             w2, NULL
    // 0x12a2140: b.eq            #0x12a2184
    // 0x12a2144: LoadField: r1 = r2->field_7
    //     0x12a2144: ldur            w1, [x2, #7]
    // 0x12a2148: DecompressPointer r1
    //     0x12a2148: add             x1, x1, HEAP, lsl #32
    // 0x12a214c: LoadField: r2 = r1->field_f
    //     0x12a214c: ldur            w2, [x1, #0xf]
    // 0x12a2150: DecompressPointer r2
    //     0x12a2150: add             x2, x2, HEAP, lsl #32
    // 0x12a2154: stur            x2, [fp, #-8]
    // 0x12a2158: r0 = WordBoundary()
    //     0x12a2158: bl              #0x12a2188  ; AllocateWordBoundaryStub -> WordBoundary (size=0x14)
    // 0x12a215c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x12a2160: StoreField: r0->field_f = r1
    //     0x12a2160: stur            w1, [x0, #0xf]
    // 0x12a2164: ldur            x1, [fp, #-0x10]
    // 0x12a2168: StoreField: r0->field_7 = r1
    //     0x12a2168: stur            w1, [x0, #7]
    // 0x12a216c: ldur            x1, [fp, #-8]
    // 0x12a2170: StoreField: r0->field_b = r1
    //     0x12a2170: stur            w1, [x0, #0xb]
    // 0x12a2174: LeaveFrame
    //     0x12a2174: mov             SP, fp
    //     0x12a2178: ldp             fp, lr, [SP], #0x10
    // 0x12a217c: ret
    //     0x12a217c: ret             
    // 0x12a2180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a2180: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a2184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a2184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2902, size: 0x18, field offset: 0x8
//   const constructor, 
class _LineCaretMetrics extends Object {

  _ shift(/* No info */) {
    // ** addr: 0x85eda0, size: 0xa4
    // 0x85eda0: EnterFrame
    //     0x85eda0: stp             fp, lr, [SP, #-0x10]!
    //     0x85eda4: mov             fp, SP
    // 0x85eda8: AllocStack(0x30)
    //     0x85eda8: sub             SP, SP, #0x30
    // 0x85edac: SetupParameters(_LineCaretMetrics this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x85edac: mov             x0, x1
    //     0x85edb0: stur            x1, [fp, #-8]
    //     0x85edb4: mov             x1, x2
    //     0x85edb8: stur            x2, [fp, #-0x10]
    // 0x85edbc: CheckStackOverflow
    //     0x85edbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85edc0: cmp             SP, x16
    //     0x85edc4: b.ls            #0x85ee3c
    // 0x85edc8: r16 = Instance_Offset
    //     0x85edc8: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x85edcc: stp             x16, x1, [SP]
    // 0x85edd0: r0 = ==()
    //     0x85edd0: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x85edd4: tbnz            w0, #4, #0x85ede0
    // 0x85edd8: ldur            x0, [fp, #-8]
    // 0x85eddc: b               #0x85ee30
    // 0x85ede0: ldur            x0, [fp, #-8]
    // 0x85ede4: LoadField: r2 = r0->field_7
    //     0x85ede4: ldur            w2, [x0, #7]
    // 0x85ede8: DecompressPointer r2
    //     0x85ede8: add             x2, x2, HEAP, lsl #32
    // 0x85edec: ldur            x1, [fp, #-0x10]
    // 0x85edf0: r0 = +()
    //     0x85edf0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x85edf4: mov             x1, x0
    // 0x85edf8: ldur            x0, [fp, #-8]
    // 0x85edfc: stur            x1, [fp, #-0x18]
    // 0x85ee00: LoadField: r2 = r0->field_b
    //     0x85ee00: ldur            w2, [x0, #0xb]
    // 0x85ee04: DecompressPointer r2
    //     0x85ee04: add             x2, x2, HEAP, lsl #32
    // 0x85ee08: stur            x2, [fp, #-0x10]
    // 0x85ee0c: LoadField: d0 = r0->field_f
    //     0x85ee0c: ldur            d0, [x0, #0xf]
    // 0x85ee10: stur            d0, [fp, #-0x20]
    // 0x85ee14: r0 = _LineCaretMetrics()
    //     0x85ee14: bl              #0x85e860  ; Allocate_LineCaretMetricsStub -> _LineCaretMetrics (size=0x18)
    // 0x85ee18: ldur            x1, [fp, #-0x18]
    // 0x85ee1c: StoreField: r0->field_7 = r1
    //     0x85ee1c: stur            w1, [x0, #7]
    // 0x85ee20: ldur            x1, [fp, #-0x10]
    // 0x85ee24: StoreField: r0->field_b = r1
    //     0x85ee24: stur            w1, [x0, #0xb]
    // 0x85ee28: ldur            d0, [fp, #-0x20]
    // 0x85ee2c: StoreField: r0->field_f = d0
    //     0x85ee2c: stur            d0, [x0, #0xf]
    // 0x85ee30: LeaveFrame
    //     0x85ee30: mov             SP, fp
    //     0x85ee34: ldp             fp, lr, [SP], #0x10
    // 0x85ee38: ret
    //     0x85ee38: ret             
    // 0x85ee3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85ee3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85ee40: b               #0x85edc8
  }
}

// class id: 2903, size: 0x30, field offset: 0x8
class _TextPainterLayoutCacheWithOffset extends Object {

  get _ paintOffset(/* No info */) {
    // ** addr: 0x85de1c, size: 0x180
    // 0x85de1c: EnterFrame
    //     0x85de1c: stp             fp, lr, [SP, #-0x10]!
    //     0x85de20: mov             fp, SP
    // 0x85de24: AllocStack(0x38)
    //     0x85de24: sub             SP, SP, #0x38
    // 0x85de28: d0 = 0.000000
    //     0x85de28: eor             v0.16b, v0.16b, v0.16b
    // 0x85de2c: mov             x0, x1
    // 0x85de30: stur            x1, [fp, #-0x20]
    // 0x85de34: CheckStackOverflow
    //     0x85de34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85de38: cmp             SP, x16
    //     0x85de3c: b.ls            #0x85df8c
    // 0x85de40: LoadField: d1 = r0->field_1b
    //     0x85de40: ldur            d1, [x0, #0x1b]
    // 0x85de44: stur            d1, [fp, #-0x28]
    // 0x85de48: fcmp            d1, d0
    // 0x85de4c: b.ne            #0x85de60
    // 0x85de50: r0 = Instance_Offset
    //     0x85de50: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x85de54: LeaveFrame
    //     0x85de54: mov             SP, fp
    //     0x85de58: ldp             fp, lr, [SP], #0x10
    // 0x85de5c: ret
    //     0x85de5c: ret             
    // 0x85de60: LoadField: r2 = r0->field_7
    //     0x85de60: ldur            w2, [x0, #7]
    // 0x85de64: DecompressPointer r2
    //     0x85de64: add             x2, x2, HEAP, lsl #32
    // 0x85de68: stur            x2, [fp, #-0x18]
    // 0x85de6c: LoadField: r3 = r2->field_f
    //     0x85de6c: ldur            w3, [x2, #0xf]
    // 0x85de70: DecompressPointer r3
    //     0x85de70: add             x3, x3, HEAP, lsl #32
    // 0x85de74: stur            x3, [fp, #-0x10]
    // 0x85de78: LoadField: r1 = r3->field_7
    //     0x85de78: ldur            w1, [x3, #7]
    // 0x85de7c: DecompressPointer r1
    //     0x85de7c: add             x1, x1, HEAP, lsl #32
    // 0x85de80: cmp             w1, NULL
    // 0x85de84: b.eq            #0x85df94
    // 0x85de88: LoadField: r4 = r1->field_7
    //     0x85de88: ldur            x4, [x1, #7]
    // 0x85de8c: ldr             x1, [x4]
    // 0x85de90: cbz             x1, #0x85df6c
    // 0x85de94: mov             x4, x1
    // 0x85de98: stur            x4, [fp, #-8]
    // 0x85de9c: r1 = <Never>
    //     0x85de9c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85dea0: r0 = Pointer()
    //     0x85dea0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85dea4: mov             x1, x0
    // 0x85dea8: ldur            x0, [fp, #-8]
    // 0x85deac: StoreField: r1->field_7 = r0
    //     0x85deac: stur            x0, [x1, #7]
    // 0x85deb0: r0 = _width$Getter$FfiNative()
    //     0x85deb0: bl              #0x85df9c  ; [dart:ui] _NativeParagraph::_width$Getter$FfiNative
    // 0x85deb4: mov             x0, v0.d[0]
    // 0x85deb8: and             x0, x0, #0x7fffffffffffffff
    // 0x85debc: r17 = 9218868437227405312
    //     0x85debc: mov             x17, #0x7ff0000000000000
    // 0x85dec0: cmp             x0, x17
    // 0x85dec4: b.eq            #0x85df5c
    // 0x85dec8: fcmp            d0, d0
    // 0x85decc: b.vs            #0x85df5c
    // 0x85ded0: ldur            x0, [fp, #-0x20]
    // 0x85ded4: ldur            x1, [fp, #-0x18]
    // 0x85ded8: LoadField: d0 = r0->field_13
    //     0x85ded8: ldur            d0, [x0, #0x13]
    // 0x85dedc: stur            d0, [fp, #-0x30]
    // 0x85dee0: LoadField: r0 = r1->field_f
    //     0x85dee0: ldur            w0, [x1, #0xf]
    // 0x85dee4: DecompressPointer r0
    //     0x85dee4: add             x0, x0, HEAP, lsl #32
    // 0x85dee8: stur            x0, [fp, #-0x10]
    // 0x85deec: LoadField: r1 = r0->field_7
    //     0x85deec: ldur            w1, [x0, #7]
    // 0x85def0: DecompressPointer r1
    //     0x85def0: add             x1, x1, HEAP, lsl #32
    // 0x85def4: cmp             w1, NULL
    // 0x85def8: b.eq            #0x85df98
    // 0x85defc: LoadField: r2 = r1->field_7
    //     0x85defc: ldur            x2, [x1, #7]
    // 0x85df00: ldr             x1, [x2]
    // 0x85df04: cbz             x1, #0x85df7c
    // 0x85df08: ldur            d1, [fp, #-0x28]
    // 0x85df0c: mov             x2, x1
    // 0x85df10: stur            x2, [fp, #-8]
    // 0x85df14: r1 = <Never>
    //     0x85df14: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85df18: r0 = Pointer()
    //     0x85df18: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85df1c: mov             x1, x0
    // 0x85df20: ldur            x0, [fp, #-8]
    // 0x85df24: StoreField: r1->field_7 = r0
    //     0x85df24: stur            x0, [x1, #7]
    // 0x85df28: r0 = _width$Getter$FfiNative()
    //     0x85df28: bl              #0x85df9c  ; [dart:ui] _NativeParagraph::_width$Getter$FfiNative
    // 0x85df2c: ldur            d1, [fp, #-0x30]
    // 0x85df30: fsub            d2, d1, d0
    // 0x85df34: ldur            d0, [fp, #-0x28]
    // 0x85df38: fmul            d1, d0, d2
    // 0x85df3c: stur            d1, [fp, #-0x30]
    // 0x85df40: r0 = Offset()
    //     0x85df40: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85df44: ldur            d0, [fp, #-0x30]
    // 0x85df48: StoreField: r0->field_7 = d0
    //     0x85df48: stur            d0, [x0, #7]
    // 0x85df4c: StoreField: r0->field_f = rZR
    //     0x85df4c: stur            xzr, [x0, #0xf]
    // 0x85df50: LeaveFrame
    //     0x85df50: mov             SP, fp
    //     0x85df54: ldp             fp, lr, [SP], #0x10
    // 0x85df58: ret
    //     0x85df58: ret             
    // 0x85df5c: r0 = Instance_Offset
    //     0x85df5c: ldr             x0, [PP, #0x4c40]  ; [pp+0x4c40] Obj!Offset@12a7ab1
    // 0x85df60: LeaveFrame
    //     0x85df60: mov             SP, fp
    //     0x85df64: ldp             fp, lr, [SP], #0x10
    // 0x85df68: ret
    //     0x85df68: ret             
    // 0x85df6c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85df6c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85df70: str             x16, [SP]
    // 0x85df74: r0 = _throwNew()
    //     0x85df74: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85df78: brk             #0
    // 0x85df7c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85df7c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85df80: str             x16, [SP]
    // 0x85df84: r0 = _throwNew()
    //     0x85df84: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85df88: brk             #0
    // 0x85df8c: r0 = StackOverflowSharedWithFPURegs()
    //     0x85df8c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x85df90: b               #0x85de40
    // 0x85df94: r0 = NullErrorSharedWithFPURegs()
    //     0x85df94: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x85df98: r0 = NullErrorSharedWithFPURegs()
    //     0x85df98: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _resizeToFit(/* No info */) {
    // ** addr: 0x8608e0, size: 0x29c
    // 0x8608e0: EnterFrame
    //     0x8608e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8608e4: mov             fp, SP
    // 0x8608e8: AllocStack(0x40)
    //     0x8608e8: sub             SP, SP, #0x40
    // 0x8608ec: SetupParameters(_TextPainterLayoutCacheWithOffset this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */, dynamic _ /* d1 => d1, fp-0x30 */)
    //     0x8608ec: mov             x0, x1
    //     0x8608f0: stur            x1, [fp, #-8]
    //     0x8608f4: stur            d0, [fp, #-0x28]
    //     0x8608f8: stur            d1, [fp, #-0x30]
    // 0x8608fc: CheckStackOverflow
    //     0x8608fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860900: cmp             SP, x16
    //     0x860904: b.ls            #0x860b68
    // 0x860908: LoadField: d2 = r0->field_13
    //     0x860908: ldur            d2, [x0, #0x13]
    // 0x86090c: fcmp            d1, d2
    // 0x860910: b.ne            #0x860940
    // 0x860914: fcmp            d0, d2
    // 0x860918: b.ne            #0x860940
    // 0x86091c: LoadField: r1 = r0->field_7
    //     0x86091c: ldur            w1, [x0, #7]
    // 0x860920: DecompressPointer r1
    //     0x860920: add             x1, x1, HEAP, lsl #32
    // 0x860924: r0 = _contentWidthFor()
    //     0x860924: bl              #0x8606e8  ; [package:flutter/src/painting/text_painter.dart] _TextLayout::_contentWidthFor
    // 0x860928: ldur            x0, [fp, #-8]
    // 0x86092c: StoreField: r0->field_13 = d0
    //     0x86092c: stur            d0, [x0, #0x13]
    // 0x860930: r0 = true
    //     0x860930: add             x0, NULL, #0x20  ; true
    // 0x860934: LeaveFrame
    //     0x860934: mov             SP, fp
    //     0x860938: ldp             fp, lr, [SP], #0x10
    // 0x86093c: ret
    //     0x86093c: ret             
    // 0x860940: mov             x1, x0
    // 0x860944: r0 = paintOffset()
    //     0x860944: bl              #0x85de1c  ; [package:flutter/src/painting/text_painter.dart] _TextPainterLayoutCacheWithOffset::paintOffset
    // 0x860948: LoadField: d0 = r0->field_7
    //     0x860948: ldur            d0, [x0, #7]
    // 0x86094c: mov             x0, v0.d[0]
    // 0x860950: and             x0, x0, #0x7fffffffffffffff
    // 0x860954: r17 = 9218868437227405312
    //     0x860954: mov             x17, #0x7ff0000000000000
    // 0x860958: cmp             x0, x17
    // 0x86095c: b.eq            #0x860970
    // 0x860960: fcmp            d0, d0
    // 0x860964: b.vs            #0x860970
    // 0x860968: ldur            d0, [fp, #-0x28]
    // 0x86096c: b               #0x860a18
    // 0x860970: ldur            x0, [fp, #-8]
    // 0x860974: LoadField: r1 = r0->field_7
    //     0x860974: ldur            w1, [x0, #7]
    // 0x860978: DecompressPointer r1
    //     0x860978: add             x1, x1, HEAP, lsl #32
    // 0x86097c: LoadField: r2 = r1->field_f
    //     0x86097c: ldur            w2, [x1, #0xf]
    // 0x860980: DecompressPointer r2
    //     0x860980: add             x2, x2, HEAP, lsl #32
    // 0x860984: stur            x2, [fp, #-0x18]
    // 0x860988: LoadField: r1 = r2->field_7
    //     0x860988: ldur            w1, [x2, #7]
    // 0x86098c: DecompressPointer r1
    //     0x86098c: add             x1, x1, HEAP, lsl #32
    // 0x860990: cmp             w1, NULL
    // 0x860994: b.eq            #0x860b70
    // 0x860998: LoadField: r3 = r1->field_7
    //     0x860998: ldur            x3, [x1, #7]
    // 0x86099c: ldr             x1, [x3]
    // 0x8609a0: cbz             x1, #0x860b38
    // 0x8609a4: mov             x3, x1
    // 0x8609a8: stur            x3, [fp, #-0x10]
    // 0x8609ac: r1 = <Never>
    //     0x8609ac: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x8609b0: r0 = Pointer()
    //     0x8609b0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x8609b4: mov             x1, x0
    // 0x8609b8: ldur            x0, [fp, #-0x10]
    // 0x8609bc: StoreField: r1->field_7 = r0
    //     0x8609bc: stur            x0, [x1, #7]
    // 0x8609c0: r0 = _width$Getter$FfiNative()
    //     0x8609c0: bl              #0x85df9c  ; [dart:ui] _NativeParagraph::_width$Getter$FfiNative
    // 0x8609c4: mov             x0, v0.d[0]
    // 0x8609c8: and             x0, x0, #0x7fffffffffffffff
    // 0x8609cc: r17 = 9218868437227405312
    //     0x8609cc: mov             x17, #0x7ff0000000000000
    // 0x8609d0: cmp             x0, x17
    // 0x8609d4: b.eq            #0x8609e8
    // 0x8609d8: fcmp            d0, d0
    // 0x8609dc: b.vs            #0x8609e8
    // 0x8609e0: ldur            d0, [fp, #-0x28]
    // 0x8609e4: b               #0x860a18
    // 0x8609e8: ldur            d0, [fp, #-0x28]
    // 0x8609ec: mov             x0, v0.d[0]
    // 0x8609f0: and             x0, x0, #0x7fffffffffffffff
    // 0x8609f4: r17 = 9218868437227405312
    //     0x8609f4: mov             x17, #0x7ff0000000000000
    // 0x8609f8: cmp             x0, x17
    // 0x8609fc: b.eq            #0x860a18
    // 0x860a00: fcmp            d0, d0
    // 0x860a04: b.vs            #0x860a18
    // 0x860a08: r0 = false
    //     0x860a08: add             x0, NULL, #0x30  ; false
    // 0x860a0c: LeaveFrame
    //     0x860a0c: mov             SP, fp
    //     0x860a10: ldp             fp, lr, [SP], #0x10
    // 0x860a14: ret
    //     0x860a14: ret             
    // 0x860a18: ldur            x0, [fp, #-8]
    // 0x860a1c: LoadField: r2 = r0->field_7
    //     0x860a1c: ldur            w2, [x0, #7]
    // 0x860a20: DecompressPointer r2
    //     0x860a20: add             x2, x2, HEAP, lsl #32
    // 0x860a24: stur            x2, [fp, #-0x20]
    // 0x860a28: LoadField: r3 = r2->field_f
    //     0x860a28: ldur            w3, [x2, #0xf]
    // 0x860a2c: DecompressPointer r3
    //     0x860a2c: add             x3, x3, HEAP, lsl #32
    // 0x860a30: stur            x3, [fp, #-0x18]
    // 0x860a34: LoadField: r1 = r3->field_7
    //     0x860a34: ldur            w1, [x3, #7]
    // 0x860a38: DecompressPointer r1
    //     0x860a38: add             x1, x1, HEAP, lsl #32
    // 0x860a3c: cmp             w1, NULL
    // 0x860a40: b.eq            #0x860b74
    // 0x860a44: LoadField: r4 = r1->field_7
    //     0x860a44: ldur            x4, [x1, #7]
    // 0x860a48: ldr             x1, [x4]
    // 0x860a4c: cbz             x1, #0x860b48
    // 0x860a50: ldur            d1, [fp, #-0x30]
    // 0x860a54: mov             x4, x1
    // 0x860a58: stur            x4, [fp, #-0x10]
    // 0x860a5c: r1 = <Never>
    //     0x860a5c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860a60: r0 = Pointer()
    //     0x860a60: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x860a64: mov             x1, x0
    // 0x860a68: ldur            x0, [fp, #-0x10]
    // 0x860a6c: StoreField: r1->field_7 = r0
    //     0x860a6c: stur            x0, [x1, #7]
    // 0x860a70: r0 = _maxIntrinsicWidth$Getter$FfiNative()
    //     0x860a70: bl              #0x86085c  ; [dart:ui] _NativeParagraph::_maxIntrinsicWidth$Getter$FfiNative
    // 0x860a74: stur            d0, [fp, #-0x38]
    // 0x860a78: ldur            x0, [fp, #-8]
    // 0x860a7c: LoadField: d1 = r0->field_b
    //     0x860a7c: ldur            d1, [x0, #0xb]
    // 0x860a80: ldur            d2, [fp, #-0x30]
    // 0x860a84: fcmp            d2, d1
    // 0x860a88: b.eq            #0x860b00
    // 0x860a8c: ldur            x2, [fp, #-0x20]
    // 0x860a90: LoadField: r3 = r2->field_f
    //     0x860a90: ldur            w3, [x2, #0xf]
    // 0x860a94: DecompressPointer r3
    //     0x860a94: add             x3, x3, HEAP, lsl #32
    // 0x860a98: stur            x3, [fp, #-0x18]
    // 0x860a9c: LoadField: r1 = r3->field_7
    //     0x860a9c: ldur            w1, [x3, #7]
    // 0x860aa0: DecompressPointer r1
    //     0x860aa0: add             x1, x1, HEAP, lsl #32
    // 0x860aa4: cmp             w1, NULL
    // 0x860aa8: b.eq            #0x860b78
    // 0x860aac: LoadField: r4 = r1->field_7
    //     0x860aac: ldur            x4, [x1, #7]
    // 0x860ab0: ldr             x1, [x4]
    // 0x860ab4: cbz             x1, #0x860b58
    // 0x860ab8: mov             x4, x1
    // 0x860abc: stur            x4, [fp, #-0x10]
    // 0x860ac0: r1 = <Never>
    //     0x860ac0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x860ac4: r0 = Pointer()
    //     0x860ac4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x860ac8: mov             x1, x0
    // 0x860acc: ldur            x0, [fp, #-0x10]
    // 0x860ad0: StoreField: r1->field_7 = r0
    //     0x860ad0: stur            x0, [x1, #7]
    // 0x860ad4: r0 = _width$Getter$FfiNative()
    //     0x860ad4: bl              #0x85df9c  ; [dart:ui] _NativeParagraph::_width$Getter$FfiNative
    // 0x860ad8: ldur            d1, [fp, #-0x38]
    // 0x860adc: fsub            d2, d0, d1
    // 0x860ae0: d0 = -0.000000
    //     0x860ae0: ldr             d0, [PP, #0x4ce0]  ; [pp+0x4ce0] IMM: double(-1e-10) from 0xbddb7cdfd9d7bdbb
    // 0x860ae4: fcmp            d2, d0
    // 0x860ae8: b.le            #0x860b28
    // 0x860aec: ldur            d2, [fp, #-0x30]
    // 0x860af0: fsub            d3, d2, d1
    // 0x860af4: fcmp            d3, d0
    // 0x860af8: b.le            #0x860b28
    // 0x860afc: ldur            x0, [fp, #-8]
    // 0x860b00: ldur            x1, [fp, #-0x20]
    // 0x860b04: ldur            d0, [fp, #-0x28]
    // 0x860b08: mov             v1.16b, v2.16b
    // 0x860b0c: r0 = _contentWidthFor()
    //     0x860b0c: bl              #0x8606e8  ; [package:flutter/src/painting/text_painter.dart] _TextLayout::_contentWidthFor
    // 0x860b10: ldur            x0, [fp, #-8]
    // 0x860b14: StoreField: r0->field_13 = d0
    //     0x860b14: stur            d0, [x0, #0x13]
    // 0x860b18: r0 = true
    //     0x860b18: add             x0, NULL, #0x20  ; true
    // 0x860b1c: LeaveFrame
    //     0x860b1c: mov             SP, fp
    //     0x860b20: ldp             fp, lr, [SP], #0x10
    // 0x860b24: ret
    //     0x860b24: ret             
    // 0x860b28: r0 = false
    //     0x860b28: add             x0, NULL, #0x30  ; false
    // 0x860b2c: LeaveFrame
    //     0x860b2c: mov             SP, fp
    //     0x860b30: ldp             fp, lr, [SP], #0x10
    // 0x860b34: ret
    //     0x860b34: ret             
    // 0x860b38: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860b38: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860b3c: str             x16, [SP]
    // 0x860b40: r0 = _throwNew()
    //     0x860b40: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860b44: brk             #0
    // 0x860b48: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860b48: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860b4c: str             x16, [SP]
    // 0x860b50: r0 = _throwNew()
    //     0x860b50: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860b54: brk             #0
    // 0x860b58: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860b58: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860b5c: str             x16, [SP]
    // 0x860b60: r0 = _throwNew()
    //     0x860b60: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x860b64: brk             #0
    // 0x860b68: r0 = StackOverflowSharedWithFPURegs()
    //     0x860b68: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x860b6c: b               #0x860908
    // 0x860b70: r0 = NullErrorSharedWithoutFPURegs()
    //     0x860b70: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x860b74: r0 = NullErrorSharedWithFPURegs()
    //     0x860b74: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x860b78: r0 = NullErrorSharedWithFPURegs()
    //     0x860b78: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  get _ lineMetrics(/* No info */) {
    // ** addr: 0xb3246c, size: 0x8c
    // 0xb3246c: EnterFrame
    //     0xb3246c: stp             fp, lr, [SP, #-0x10]!
    //     0xb32470: mov             fp, SP
    // 0xb32474: AllocStack(0x8)
    //     0xb32474: sub             SP, SP, #8
    // 0xb32478: SetupParameters(_TextPainterLayoutCacheWithOffset this /* r1 => r0, fp-0x8 */)
    //     0xb32478: mov             x0, x1
    //     0xb3247c: stur            x1, [fp, #-8]
    // 0xb32480: CheckStackOverflow
    //     0xb32480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb32484: cmp             SP, x16
    //     0xb32488: b.ls            #0xb324f0
    // 0xb3248c: LoadField: r1 = r0->field_27
    //     0xb3248c: ldur            w1, [x0, #0x27]
    // 0xb32490: DecompressPointer r1
    //     0xb32490: add             x1, x1, HEAP, lsl #32
    // 0xb32494: cmp             w1, NULL
    // 0xb32498: b.ne            #0xb324e0
    // 0xb3249c: LoadField: r1 = r0->field_7
    //     0xb3249c: ldur            w1, [x0, #7]
    // 0xb324a0: DecompressPointer r1
    //     0xb324a0: add             x1, x1, HEAP, lsl #32
    // 0xb324a4: LoadField: r2 = r1->field_f
    //     0xb324a4: ldur            w2, [x1, #0xf]
    // 0xb324a8: DecompressPointer r2
    //     0xb324a8: add             x2, x2, HEAP, lsl #32
    // 0xb324ac: mov             x1, x2
    // 0xb324b0: r0 = computeLineMetrics()
    //     0xb324b0: bl              #0xb324f8  ; [dart:ui] _NativeParagraph::computeLineMetrics
    // 0xb324b4: mov             x1, x0
    // 0xb324b8: ldur            x2, [fp, #-8]
    // 0xb324bc: StoreField: r2->field_27 = r0
    //     0xb324bc: stur            w0, [x2, #0x27]
    //     0xb324c0: ldurb           w16, [x2, #-1]
    //     0xb324c4: ldurb           w17, [x0, #-1]
    //     0xb324c8: and             x16, x17, x16, lsr #2
    //     0xb324cc: tst             x16, HEAP, lsr #32
    //     0xb324d0: b.eq            #0xb324d8
    //     0xb324d4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb324d8: mov             x0, x1
    // 0xb324dc: b               #0xb324e4
    // 0xb324e0: mov             x0, x1
    // 0xb324e4: LeaveFrame
    //     0xb324e4: mov             SP, fp
    //     0xb324e8: ldp             fp, lr, [SP], #0x10
    // 0xb324ec: ret
    //     0xb324ec: ret             
    // 0xb324f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb324f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb324f4: b               #0xb3248c
  }
  get _ inlinePlaceholderBoxes(/* No info */) {
    // ** addr: 0xbc4150, size: 0x8c
    // 0xbc4150: EnterFrame
    //     0xbc4150: stp             fp, lr, [SP, #-0x10]!
    //     0xbc4154: mov             fp, SP
    // 0xbc4158: AllocStack(0x8)
    //     0xbc4158: sub             SP, SP, #8
    // 0xbc415c: SetupParameters(_TextPainterLayoutCacheWithOffset this /* r1 => r0, fp-0x8 */)
    //     0xbc415c: mov             x0, x1
    //     0xbc4160: stur            x1, [fp, #-8]
    // 0xbc4164: CheckStackOverflow
    //     0xbc4164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc4168: cmp             SP, x16
    //     0xbc416c: b.ls            #0xbc41d4
    // 0xbc4170: LoadField: r1 = r0->field_23
    //     0xbc4170: ldur            w1, [x0, #0x23]
    // 0xbc4174: DecompressPointer r1
    //     0xbc4174: add             x1, x1, HEAP, lsl #32
    // 0xbc4178: cmp             w1, NULL
    // 0xbc417c: b.ne            #0xbc41c4
    // 0xbc4180: LoadField: r1 = r0->field_7
    //     0xbc4180: ldur            w1, [x0, #7]
    // 0xbc4184: DecompressPointer r1
    //     0xbc4184: add             x1, x1, HEAP, lsl #32
    // 0xbc4188: LoadField: r2 = r1->field_f
    //     0xbc4188: ldur            w2, [x1, #0xf]
    // 0xbc418c: DecompressPointer r2
    //     0xbc418c: add             x2, x2, HEAP, lsl #32
    // 0xbc4190: mov             x1, x2
    // 0xbc4194: r0 = getBoxesForPlaceholders()
    //     0xbc4194: bl              #0xbc41dc  ; [dart:ui] _NativeParagraph::getBoxesForPlaceholders
    // 0xbc4198: mov             x1, x0
    // 0xbc419c: ldur            x2, [fp, #-8]
    // 0xbc41a0: StoreField: r2->field_23 = r0
    //     0xbc41a0: stur            w0, [x2, #0x23]
    //     0xbc41a4: ldurb           w16, [x2, #-1]
    //     0xbc41a8: ldurb           w17, [x0, #-1]
    //     0xbc41ac: and             x16, x17, x16, lsr #2
    //     0xbc41b0: tst             x16, HEAP, lsr #32
    //     0xbc41b4: b.eq            #0xbc41bc
    //     0xbc41b8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc41bc: mov             x0, x1
    // 0xbc41c0: b               #0xbc41c8
    // 0xbc41c4: mov             x0, x1
    // 0xbc41c8: LeaveFrame
    //     0xbc41c8: mov             SP, fp
    //     0xbc41cc: ldp             fp, lr, [SP], #0x10
    // 0xbc41d0: ret
    //     0xbc41d0: ret             
    // 0xbc41d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc41d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc41d8: b               #0xbc4170
  }
}

// class id: 2904, size: 0x18, field offset: 0x8
class _TextLayout extends Object {

  late final _LineCaretMetrics _endOfTextCaretMetrics; // offset: 0x14
  static late final RegExp _regExpSpaceSeparators; // offset: 0x614

  _LineCaretMetrics _endOfTextCaretMetrics(_TextLayout) {
    // ** addr: 0x85f54c, size: 0x30
    // 0x85f54c: EnterFrame
    //     0x85f54c: stp             fp, lr, [SP, #-0x10]!
    //     0x85f550: mov             fp, SP
    // 0x85f554: CheckStackOverflow
    //     0x85f554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f558: cmp             SP, x16
    //     0x85f55c: b.ls            #0x85f574
    // 0x85f560: ldr             x1, [fp, #0x10]
    // 0x85f564: r0 = _computeEndOfTextCaretAnchorOffset()
    //     0x85f564: bl              #0x85f57c  ; [package:flutter/src/painting/text_painter.dart] _TextLayout::_computeEndOfTextCaretAnchorOffset
    // 0x85f568: LeaveFrame
    //     0x85f568: mov             SP, fp
    //     0x85f56c: ldp             fp, lr, [SP], #0x10
    // 0x85f570: ret
    //     0x85f570: ret             
    // 0x85f574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f578: b               #0x85f560
  }
  _LineCaretMetrics _computeEndOfTextCaretAnchorOffset(_TextLayout) {
    // ** addr: 0x85f57c, size: 0x34c
    // 0x85f57c: EnterFrame
    //     0x85f57c: stp             fp, lr, [SP, #-0x10]!
    //     0x85f580: mov             fp, SP
    // 0x85f584: AllocStack(0x58)
    //     0x85f584: sub             SP, SP, #0x58
    // 0x85f588: SetupParameters(_TextLayout this /* r1 => r0, fp-0x8 */)
    //     0x85f588: mov             x0, x1
    //     0x85f58c: stur            x1, [fp, #-8]
    // 0x85f590: CheckStackOverflow
    //     0x85f590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f594: cmp             SP, x16
    //     0x85f598: b.ls            #0x85f8ac
    // 0x85f59c: LoadField: r1 = r0->field_b
    //     0x85f59c: ldur            w1, [x0, #0xb]
    // 0x85f5a0: DecompressPointer r1
    //     0x85f5a0: add             x1, x1, HEAP, lsl #32
    // 0x85f5a4: r0 = plainText()
    //     0x85f5a4: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x85f5a8: mov             x2, x0
    // 0x85f5ac: ldur            x0, [fp, #-8]
    // 0x85f5b0: stur            x2, [fp, #-0x20]
    // 0x85f5b4: LoadField: r3 = r0->field_f
    //     0x85f5b4: ldur            w3, [x0, #0xf]
    // 0x85f5b8: DecompressPointer r3
    //     0x85f5b8: add             x3, x3, HEAP, lsl #32
    // 0x85f5bc: stur            x3, [fp, #-0x18]
    // 0x85f5c0: LoadField: r1 = r3->field_7
    //     0x85f5c0: ldur            w1, [x3, #7]
    // 0x85f5c4: DecompressPointer r1
    //     0x85f5c4: add             x1, x1, HEAP, lsl #32
    // 0x85f5c8: cmp             w1, NULL
    // 0x85f5cc: b.eq            #0x85f8b4
    // 0x85f5d0: LoadField: r4 = r1->field_7
    //     0x85f5d0: ldur            x4, [x1, #7]
    // 0x85f5d4: ldr             x1, [x4]
    // 0x85f5d8: cbz             x1, #0x85f87c
    // 0x85f5dc: mov             x4, x1
    // 0x85f5e0: stur            x4, [fp, #-0x10]
    // 0x85f5e4: r1 = <Never>
    //     0x85f5e4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85f5e8: r0 = Pointer()
    //     0x85f5e8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85f5ec: mov             x1, x0
    // 0x85f5f0: ldur            x0, [fp, #-0x10]
    // 0x85f5f4: StoreField: r1->field_7 = r0
    //     0x85f5f4: stur            x0, [x1, #7]
    // 0x85f5f8: r0 = _numberOfLines$Getter$FfiNative()
    //     0x85f5f8: bl              #0x85f494  ; [dart:ui] _NativeParagraph::_numberOfLines$Getter$FfiNative
    // 0x85f5fc: sub             x2, x0, #1
    // 0x85f600: ldur            x0, [fp, #-8]
    // 0x85f604: stur            x2, [fp, #-0x28]
    // 0x85f608: LoadField: r3 = r0->field_f
    //     0x85f608: ldur            w3, [x0, #0xf]
    // 0x85f60c: DecompressPointer r3
    //     0x85f60c: add             x3, x3, HEAP, lsl #32
    // 0x85f610: stur            x3, [fp, #-0x18]
    // 0x85f614: LoadField: r1 = r3->field_7
    //     0x85f614: ldur            w1, [x3, #7]
    // 0x85f618: DecompressPointer r1
    //     0x85f618: add             x1, x1, HEAP, lsl #32
    // 0x85f61c: cmp             w1, NULL
    // 0x85f620: b.eq            #0x85f8b8
    // 0x85f624: LoadField: r4 = r1->field_7
    //     0x85f624: ldur            x4, [x1, #7]
    // 0x85f628: ldr             x1, [x4]
    // 0x85f62c: cbz             x1, #0x85f88c
    // 0x85f630: ldur            x4, [fp, #-0x20]
    // 0x85f634: mov             x5, x1
    // 0x85f638: stur            x5, [fp, #-0x10]
    // 0x85f63c: r1 = <Never>
    //     0x85f63c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85f640: r0 = Pointer()
    //     0x85f640: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85f644: mov             x1, x0
    // 0x85f648: ldur            x0, [fp, #-0x10]
    // 0x85f64c: StoreField: r1->field_7 = r0
    //     0x85f64c: stur            x0, [x1, #7]
    // 0x85f650: ldur            x2, [fp, #-0x28]
    // 0x85f654: r3 = Closure: (bool, double, double, double, double, double, double, double, int) => LineMetrics from Function 'LineMetrics._@38065589': static.
    //     0x85f654: ldr             x3, [PP, #0x4bc8]  ; [pp+0x4bc8] Closure: (bool, double, double, double, double, double, double, double, int) => LineMetrics from Function 'LineMetrics._@38065589': static. (0x7f2ada746968)
    // 0x85f658: r0 = __getLineMetricsAt$Method$FfiNative()
    //     0x85f658: bl              #0x85ee44  ; [dart:ui] _NativeParagraph::__getLineMetricsAt$Method$FfiNative
    // 0x85f65c: stur            x0, [fp, #-0x30]
    // 0x85f660: cmp             w0, NULL
    // 0x85f664: b.eq            #0x85f8bc
    // 0x85f668: ldur            x1, [fp, #-0x20]
    // 0x85f66c: LoadField: r2 = r1->field_7
    //     0x85f66c: ldur            w2, [x1, #7]
    // 0x85f670: r3 = LoadInt32Instr(r2)
    //     0x85f670: sbfx            x3, x2, #1, #0x1f
    // 0x85f674: sub             x2, x3, #1
    // 0x85f678: stur            x2, [fp, #-0x10]
    // 0x85f67c: lsl             x3, x2, #1
    // 0x85f680: stp             x3, x1, [SP]
    // 0x85f684: r0 = []()
    //     0x85f684: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0x85f688: mov             x2, x0
    // 0x85f68c: stur            x2, [fp, #-0x18]
    // 0x85f690: LoadField: r0 = r2->field_7
    //     0x85f690: ldur            w0, [x2, #7]
    // 0x85f694: r1 = LoadInt32Instr(r0)
    //     0x85f694: sbfx            x1, x0, #1, #0x1f
    // 0x85f698: mov             x0, x1
    // 0x85f69c: r1 = 0
    //     0x85f69c: mov             x1, #0
    // 0x85f6a0: cmp             x1, x0
    // 0x85f6a4: b.hs            #0x85f8c0
    // 0x85f6a8: r0 = LoadClassIdInstr(r2)
    //     0x85f6a8: ldur            x0, [x2, #-1]
    //     0x85f6ac: ubfx            x0, x0, #0xc, #0x14
    // 0x85f6b0: lsl             x0, x0, #1
    // 0x85f6b4: cmp             w0, #0xbc
    // 0x85f6b8: b.ne            #0x85f6c4
    // 0x85f6bc: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x85f6bc: ldrb            w0, [x2, #0xf]
    // 0x85f6c0: b               #0x85f6c8
    // 0x85f6c4: ldurh           w0, [x2, #0xf]
    // 0x85f6c8: cmp             x0, #9
    // 0x85f6cc: b.ne            #0x85f6d8
    // 0x85f6d0: r1 = true
    //     0x85f6d0: add             x1, NULL, #0x20  ; true
    // 0x85f6d4: b               #0x85f72c
    // 0x85f6d8: cmp             x0, #0xa0
    // 0x85f6dc: b.eq            #0x85f6f8
    // 0x85f6e0: r17 = 8199
    //     0x85f6e0: mov             x17, #0x2007
    // 0x85f6e4: cmp             x0, x17
    // 0x85f6e8: b.eq            #0x85f6f8
    // 0x85f6ec: r17 = 8239
    //     0x85f6ec: mov             x17, #0x202f
    // 0x85f6f0: cmp             x0, x17
    // 0x85f6f4: b.ne            #0x85f700
    // 0x85f6f8: r1 = false
    //     0x85f6f8: add             x1, NULL, #0x30  ; false
    // 0x85f6fc: b               #0x85f72c
    // 0x85f700: r0 = LoadStaticField(0x614)
    //     0x85f700: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x85f704: ldr             x0, [x0, #0xc28]
    // 0x85f708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85f70c: cmp             w0, w16
    // 0x85f710: b.ne            #0x85f71c
    // 0x85f714: r2 = _regExpSpaceSeparators
    //     0x85f714: ldr             x2, [PP, #0x4be0]  ; [pp+0x4be0] Field <_TextLayout@49105366._regExpSpaceSeparators@49105366>: static late final (offset: 0x614)
    // 0x85f718: r0 = InitLateFinalStaticField()
    //     0x85f718: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x85f71c: mov             x1, x0
    // 0x85f720: ldur            x2, [fp, #-0x18]
    // 0x85f724: r0 = hasMatch()
    //     0x85f724: bl              #0x85f8c8  ; [dart:core] _RegExp::hasMatch
    // 0x85f728: mov             x1, x0
    // 0x85f72c: ldur            x0, [fp, #-0x30]
    // 0x85f730: LoadField: d0 = r0->field_3b
    //     0x85f730: ldur            d0, [x0, #0x3b]
    // 0x85f734: stur            d0, [fp, #-0x38]
    // 0x85f738: tbnz            w1, #4, #0x85f7e4
    // 0x85f73c: ldur            x2, [fp, #-8]
    // 0x85f740: LoadField: r3 = r2->field_f
    //     0x85f740: ldur            w3, [x2, #0xf]
    // 0x85f744: DecompressPointer r3
    //     0x85f744: add             x3, x3, HEAP, lsl #32
    // 0x85f748: stur            x3, [fp, #-0x18]
    // 0x85f74c: LoadField: r1 = r3->field_7
    //     0x85f74c: ldur            w1, [x3, #7]
    // 0x85f750: DecompressPointer r1
    //     0x85f750: add             x1, x1, HEAP, lsl #32
    // 0x85f754: cmp             w1, NULL
    // 0x85f758: b.eq            #0x85f8c4
    // 0x85f75c: LoadField: r4 = r1->field_7
    //     0x85f75c: ldur            x4, [x1, #7]
    // 0x85f760: ldr             x1, [x4]
    // 0x85f764: cbz             x1, #0x85f89c
    // 0x85f768: mov             x4, x1
    // 0x85f76c: stur            x4, [fp, #-0x28]
    // 0x85f770: r1 = <Never>
    //     0x85f770: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x85f774: r0 = Pointer()
    //     0x85f774: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x85f778: mov             x1, x0
    // 0x85f77c: ldur            x0, [fp, #-0x28]
    // 0x85f780: StoreField: r1->field_7 = r0
    //     0x85f780: stur            x0, [x1, #7]
    // 0x85f784: ldur            x2, [fp, #-0x10]
    // 0x85f788: r3 = Closure: (double, double, double, double, int, int, bool) => GlyphInfo from Function 'GlyphInfo._@38065589': static.
    //     0x85f788: ldr             x3, [PP, #0x4bc0]  ; [pp+0x4bc0] Closure: (double, double, double, double, int, int, bool) => GlyphInfo from Function 'GlyphInfo._@38065589': static. (0x7f2ada746a1c)
    // 0x85f78c: r0 = __getGlyphInfoAt$Method$FfiNative()
    //     0x85f78c: bl              #0x85f038  ; [dart:ui] _NativeParagraph::__getGlyphInfoAt$Method$FfiNative
    // 0x85f790: cmp             w0, NULL
    // 0x85f794: b.eq            #0x85f7dc
    // 0x85f798: ldur            x1, [fp, #-8]
    // 0x85f79c: LoadField: r2 = r0->field_7
    //     0x85f79c: ldur            w2, [x0, #7]
    // 0x85f7a0: DecompressPointer r2
    //     0x85f7a0: add             x2, x2, HEAP, lsl #32
    // 0x85f7a4: LoadField: r0 = r1->field_7
    //     0x85f7a4: ldur            w0, [x1, #7]
    // 0x85f7a8: DecompressPointer r0
    //     0x85f7a8: add             x0, x0, HEAP, lsl #32
    // 0x85f7ac: LoadField: r1 = r0->field_7
    //     0x85f7ac: ldur            x1, [x0, #7]
    // 0x85f7b0: cmp             x1, #0
    // 0x85f7b4: b.gt            #0x85f7c0
    // 0x85f7b8: LoadField: d0 = r2->field_7
    //     0x85f7b8: ldur            d0, [x2, #7]
    // 0x85f7bc: b               #0x85f7c4
    // 0x85f7c0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x85f7c0: ldur            d0, [x2, #0x17]
    // 0x85f7c4: LoadField: d1 = r2->field_1f
    //     0x85f7c4: ldur            d1, [x2, #0x1f]
    // 0x85f7c8: LoadField: d2 = r2->field_f
    //     0x85f7c8: ldur            d2, [x2, #0xf]
    // 0x85f7cc: fsub            d3, d1, d2
    // 0x85f7d0: mov             v2.16b, v0.16b
    // 0x85f7d4: mov             v1.16b, v3.16b
    // 0x85f7d8: b               #0x85f824
    // 0x85f7dc: ldur            x1, [fp, #-8]
    // 0x85f7e0: b               #0x85f7e8
    // 0x85f7e4: ldur            x1, [fp, #-8]
    // 0x85f7e8: LoadField: r0 = r1->field_7
    //     0x85f7e8: ldur            w0, [x1, #7]
    // 0x85f7ec: DecompressPointer r0
    //     0x85f7ec: add             x0, x0, HEAP, lsl #32
    // 0x85f7f0: LoadField: r1 = r0->field_7
    //     0x85f7f0: ldur            x1, [x0, #7]
    // 0x85f7f4: cmp             x1, #0
    // 0x85f7f8: b.gt            #0x85f808
    // 0x85f7fc: ldur            x1, [fp, #-0x30]
    // 0x85f800: LoadField: d0 = r1->field_33
    //     0x85f800: ldur            d0, [x1, #0x33]
    // 0x85f804: b               #0x85f81c
    // 0x85f808: ldur            x1, [fp, #-0x30]
    // 0x85f80c: LoadField: d0 = r1->field_33
    //     0x85f80c: ldur            d0, [x1, #0x33]
    // 0x85f810: LoadField: d1 = r1->field_2b
    //     0x85f810: ldur            d1, [x1, #0x2b]
    // 0x85f814: fadd            d2, d0, d1
    // 0x85f818: mov             v0.16b, v2.16b
    // 0x85f81c: LoadField: d1 = r1->field_23
    //     0x85f81c: ldur            d1, [x1, #0x23]
    // 0x85f820: mov             v2.16b, v0.16b
    // 0x85f824: ldur            d0, [fp, #-0x38]
    // 0x85f828: stur            x0, [fp, #-8]
    // 0x85f82c: stur            d2, [fp, #-0x40]
    // 0x85f830: stur            d1, [fp, #-0x48]
    // 0x85f834: r0 = Offset()
    //     0x85f834: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85f838: ldur            d0, [fp, #-0x40]
    // 0x85f83c: stur            x0, [fp, #-0x18]
    // 0x85f840: StoreField: r0->field_7 = d0
    //     0x85f840: stur            d0, [x0, #7]
    // 0x85f844: ldur            d0, [fp, #-0x38]
    // 0x85f848: StoreField: r0->field_f = d0
    //     0x85f848: stur            d0, [x0, #0xf]
    // 0x85f84c: r0 = _LineCaretMetrics()
    //     0x85f84c: bl              #0x85e860  ; Allocate_LineCaretMetricsStub -> _LineCaretMetrics (size=0x18)
    // 0x85f850: mov             x1, x0
    // 0x85f854: ldur            x0, [fp, #-0x18]
    // 0x85f858: StoreField: r1->field_7 = r0
    //     0x85f858: stur            w0, [x1, #7]
    // 0x85f85c: ldur            x0, [fp, #-8]
    // 0x85f860: StoreField: r1->field_b = r0
    //     0x85f860: stur            w0, [x1, #0xb]
    // 0x85f864: ldur            d0, [fp, #-0x48]
    // 0x85f868: StoreField: r1->field_f = d0
    //     0x85f868: stur            d0, [x1, #0xf]
    // 0x85f86c: mov             x0, x1
    // 0x85f870: LeaveFrame
    //     0x85f870: mov             SP, fp
    //     0x85f874: ldp             fp, lr, [SP], #0x10
    // 0x85f878: ret
    //     0x85f878: ret             
    // 0x85f87c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85f87c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85f880: str             x16, [SP]
    // 0x85f884: r0 = _throwNew()
    //     0x85f884: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85f888: brk             #0
    // 0x85f88c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85f88c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85f890: str             x16, [SP]
    // 0x85f894: r0 = _throwNew()
    //     0x85f894: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85f898: brk             #0
    // 0x85f89c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x85f89c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x85f8a0: str             x16, [SP]
    // 0x85f8a4: r0 = _throwNew()
    //     0x85f8a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x85f8a8: brk             #0
    // 0x85f8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f8ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f8b0: b               #0x85f59c
    // 0x85f8b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85f8b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x85f8b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x85f8b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x85f8bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85f8bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85f8c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x85f8c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x85f8c4: r0 = NullErrorSharedWithFPURegs()
    //     0x85f8c4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  static RegExp _regExpSpaceSeparators() {
    // ** addr: 0x85f914, size: 0x54
    // 0x85f914: EnterFrame
    //     0x85f914: stp             fp, lr, [SP, #-0x10]!
    //     0x85f918: mov             fp, SP
    // 0x85f91c: AllocStack(0x30)
    //     0x85f91c: sub             SP, SP, #0x30
    // 0x85f920: CheckStackOverflow
    //     0x85f920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f924: cmp             SP, x16
    //     0x85f928: b.ls            #0x85f960
    // 0x85f92c: r16 = "\\p{Space_Separator}"
    //     0x85f92c: ldr             x16, [PP, #0x4be8]  ; [pp+0x4be8] "\\p{Space_Separator}"
    // 0x85f930: stp             x16, NULL, [SP, #0x20]
    // 0x85f934: r16 = false
    //     0x85f934: add             x16, NULL, #0x30  ; false
    // 0x85f938: r30 = true
    //     0x85f938: add             lr, NULL, #0x20  ; true
    // 0x85f93c: stp             lr, x16, [SP, #0x10]
    // 0x85f940: r16 = true
    //     0x85f940: add             x16, NULL, #0x20  ; true
    // 0x85f944: r30 = false
    //     0x85f944: add             lr, NULL, #0x30  ; false
    // 0x85f948: stp             lr, x16, [SP]
    // 0x85f94c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x85f94c: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x85f950: r0 = _RegExp()
    //     0x85f950: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x85f954: LeaveFrame
    //     0x85f954: mov             SP, fp
    //     0x85f958: ldp             fp, lr, [SP], #0x10
    // 0x85f95c: ret
    //     0x85f95c: ret             
    // 0x85f960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f960: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f964: b               #0x85f92c
  }
  _ _contentWidthFor(/* No info */) {
    // ** addr: 0x8606e8, size: 0xc4
    // 0x8606e8: EnterFrame
    //     0x8606e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8606ec: mov             fp, SP
    // 0x8606f0: AllocStack(0x28)
    //     0x8606f0: sub             SP, SP, #0x28
    // 0x8606f4: SetupParameters(dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */)
    //     0x8606f4: stur            d0, [fp, #-0x18]
    //     0x8606f8: stur            d1, [fp, #-0x20]
    // 0x8606fc: CheckStackOverflow
    //     0x8606fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860700: cmp             SP, x16
    //     0x860704: b.ls            #0x8607a0
    // 0x860708: LoadField: r0 = r1->field_f
    //     0x860708: ldur            w0, [x1, #0xf]
    // 0x86070c: DecompressPointer r0
    //     0x86070c: add             x0, x0, HEAP, lsl #32
    // 0x860710: stur            x0, [fp, #-0x10]
    // 0x860714: LoadField: r1 = r0->field_7
    //     0x860714: ldur            w1, [x0, #7]
    // 0x860718: DecompressPointer r1
    //     0x860718: add             x1, x1, HEAP, lsl #32
    // 0x86071c: cmp             w1, NULL
    // 0x860720: b.eq            #0x8607a8
    // 0x860724: LoadField: r2 = r1->field_7
    //     0x860724: ldur            x2, [x1, #7]
    // 0x860728: ldr             x1, [x2]
    // 0x86072c: cbz             x1, #0x860790
    // 0x860730: mov             x2, x1
    // 0x860734: stur            x2, [fp, #-8]
    // 0x860738: r1 = <Never>
    //     0x860738: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x86073c: r0 = Pointer()
    //     0x86073c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x860740: mov             x1, x0
    // 0x860744: ldur            x0, [fp, #-8]
    // 0x860748: StoreField: r1->field_7 = r0
    //     0x860748: stur            x0, [x1, #7]
    // 0x86074c: r0 = _maxIntrinsicWidth$Getter$FfiNative()
    //     0x86074c: bl              #0x86085c  ; [dart:ui] _NativeParagraph::_maxIntrinsicWidth$Getter$FfiNative
    // 0x860750: ldur            d1, [fp, #-0x18]
    // 0x860754: fcmp            d1, d0
    // 0x860758: b.le            #0x860764
    // 0x86075c: mov             v0.16b, v1.16b
    // 0x860760: b               #0x860784
    // 0x860764: ldur            d1, [fp, #-0x20]
    // 0x860768: fcmp            d0, d1
    // 0x86076c: b.le            #0x860778
    // 0x860770: mov             v0.16b, v1.16b
    // 0x860774: b               #0x860784
    // 0x860778: fcmp            d0, d0
    // 0x86077c: b.vc            #0x860784
    // 0x860780: mov             v0.16b, v1.16b
    // 0x860784: LeaveFrame
    //     0x860784: mov             SP, fp
    //     0x860788: ldp             fp, lr, [SP], #0x10
    // 0x86078c: ret
    //     0x86078c: ret             
    // 0x860790: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x860790: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x860794: str             x16, [SP]
    // 0x860798: r0 = _throwNew()
    //     0x860798: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x86079c: brk             #0
    // 0x8607a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x8607a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x8607a4: b               #0x860708
    // 0x8607a8: r0 = NullErrorSharedWithFPURegs()
    //     0x8607a8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 2911, size: 0x10, field offset: 0x8
//   const constructor, 
class _UntilTextBoundary extends TextBoundary {

  _ getTrailingTextBoundaryAt(/* No info */) {
    // ** addr: 0x1305ff0, size: 0xa4
    // 0x1305ff0: EnterFrame
    //     0x1305ff0: stp             fp, lr, [SP, #-0x10]!
    //     0x1305ff4: mov             fp, SP
    // 0x1305ff8: AllocStack(0x10)
    //     0x1305ff8: sub             SP, SP, #0x10
    // 0x1305ffc: r0 = 0
    //     0x1305ffc: mov             x0, #0
    // 0x1306000: mov             x3, x1
    // 0x1306004: stur            x1, [fp, #-8]
    // 0x1306008: CheckStackOverflow
    //     0x1306008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130600c: cmp             SP, x16
    //     0x1306010: b.ls            #0x130608c
    // 0x1306014: LoadField: r1 = r3->field_b
    //     0x1306014: ldur            w1, [x3, #0xb]
    // 0x1306018: DecompressPointer r1
    //     0x1306018: add             x1, x1, HEAP, lsl #32
    // 0x130601c: cmp             x2, x0
    // 0x1306020: csel            x4, x0, x2, lt
    // 0x1306024: mov             x2, x4
    // 0x1306028: r0 = getTrailingTextBoundaryAt()
    //     0x1306028: bl              #0x13064a0  ; [package:flutter/src/services/text_boundary.dart] TextBoundary::getTrailingTextBoundaryAt
    // 0x130602c: stur            x0, [fp, #-0x10]
    // 0x1306030: cmp             w0, NULL
    // 0x1306034: b.eq            #0x1306060
    // 0x1306038: ldur            x4, [fp, #-8]
    // 0x130603c: LoadField: r1 = r4->field_7
    //     0x130603c: ldur            w1, [x4, #7]
    // 0x1306040: DecompressPointer r1
    //     0x1306040: add             x1, x1, HEAP, lsl #32
    // 0x1306044: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1306044: ldur            w2, [x1, #0x17]
    // 0x1306048: DecompressPointer r2
    //     0x1306048: add             x2, x2, HEAP, lsl #32
    // 0x130604c: mov             x1, x2
    // 0x1306050: mov             x2, x0
    // 0x1306054: r3 = true
    //     0x1306054: add             x3, NULL, #0x20  ; true
    // 0x1306058: r0 = _skipSpacesAndPunctuations()
    //     0x1306058: bl              #0x13060d4  ; [package:flutter/src/painting/text_painter.dart] WordBoundary::_skipSpacesAndPunctuations
    // 0x130605c: tbnz            w0, #4, #0x1306068
    // 0x1306060: ldur            x0, [fp, #-0x10]
    // 0x1306064: b               #0x1306080
    // 0x1306068: ldur            x0, [fp, #-0x10]
    // 0x130606c: r2 = LoadInt32Instr(r0)
    //     0x130606c: sbfx            x2, x0, #1, #0x1f
    //     0x1306070: tbz             w0, #0, #0x1306078
    //     0x1306074: ldur            x2, [x0, #7]
    // 0x1306078: ldur            x1, [fp, #-8]
    // 0x130607c: r0 = getTrailingTextBoundaryAt()
    //     0x130607c: bl              #0x1305ff0  ; [package:flutter/src/painting/text_painter.dart] _UntilTextBoundary::getTrailingTextBoundaryAt
    // 0x1306080: LeaveFrame
    //     0x1306080: mov             SP, fp
    //     0x1306084: ldp             fp, lr, [SP], #0x10
    // 0x1306088: ret
    //     0x1306088: ret             
    // 0x130608c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130608c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306090: b               #0x1306014
  }
  _ getLeadingTextBoundaryAt(/* No info */) {
    // ** addr: 0x13068c0, size: 0xac
    // 0x13068c0: EnterFrame
    //     0x13068c0: stp             fp, lr, [SP, #-0x10]!
    //     0x13068c4: mov             fp, SP
    // 0x13068c8: AllocStack(0x10)
    //     0x13068c8: sub             SP, SP, #0x10
    // 0x13068cc: SetupParameters(_UntilTextBoundary this /* r1 => r0, fp-0x8 */)
    //     0x13068cc: mov             x0, x1
    //     0x13068d0: stur            x1, [fp, #-8]
    // 0x13068d4: CheckStackOverflow
    //     0x13068d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13068d8: cmp             SP, x16
    //     0x13068dc: b.ls            #0x1306964
    // 0x13068e0: tbz             x2, #0x3f, #0x13068f4
    // 0x13068e4: r0 = Null
    //     0x13068e4: mov             x0, NULL
    // 0x13068e8: LeaveFrame
    //     0x13068e8: mov             SP, fp
    //     0x13068ec: ldp             fp, lr, [SP], #0x10
    // 0x13068f0: ret
    //     0x13068f0: ret             
    // 0x13068f4: LoadField: r1 = r0->field_b
    //     0x13068f4: ldur            w1, [x0, #0xb]
    // 0x13068f8: DecompressPointer r1
    //     0x13068f8: add             x1, x1, HEAP, lsl #32
    // 0x13068fc: r0 = getLeadingTextBoundaryAt()
    //     0x13068fc: bl              #0x13069e8  ; [package:flutter/src/services/text_boundary.dart] TextBoundary::getLeadingTextBoundaryAt
    // 0x1306900: stur            x0, [fp, #-0x10]
    // 0x1306904: cmp             w0, NULL
    // 0x1306908: b.eq            #0x1306934
    // 0x130690c: ldur            x4, [fp, #-8]
    // 0x1306910: LoadField: r1 = r4->field_7
    //     0x1306910: ldur            w1, [x4, #7]
    // 0x1306914: DecompressPointer r1
    //     0x1306914: add             x1, x1, HEAP, lsl #32
    // 0x1306918: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1306918: ldur            w2, [x1, #0x17]
    // 0x130691c: DecompressPointer r2
    //     0x130691c: add             x2, x2, HEAP, lsl #32
    // 0x1306920: mov             x1, x2
    // 0x1306924: mov             x2, x0
    // 0x1306928: r3 = false
    //     0x1306928: add             x3, NULL, #0x30  ; false
    // 0x130692c: r0 = _skipSpacesAndPunctuations()
    //     0x130692c: bl              #0x13060d4  ; [package:flutter/src/painting/text_painter.dart] WordBoundary::_skipSpacesAndPunctuations
    // 0x1306930: tbnz            w0, #4, #0x130693c
    // 0x1306934: ldur            x0, [fp, #-0x10]
    // 0x1306938: b               #0x1306958
    // 0x130693c: ldur            x0, [fp, #-0x10]
    // 0x1306940: r1 = LoadInt32Instr(r0)
    //     0x1306940: sbfx            x1, x0, #1, #0x1f
    //     0x1306944: tbz             w0, #0, #0x130694c
    //     0x1306948: ldur            x1, [x0, #7]
    // 0x130694c: sub             x2, x1, #1
    // 0x1306950: ldur            x1, [fp, #-8]
    // 0x1306954: r0 = getLeadingTextBoundaryAt()
    //     0x1306954: bl              #0x13068c0  ; [package:flutter/src/painting/text_painter.dart] _UntilTextBoundary::getLeadingTextBoundaryAt
    // 0x1306958: LeaveFrame
    //     0x1306958: mov             SP, fp
    //     0x130695c: ldp             fp, lr, [SP], #0x10
    // 0x1306960: ret
    //     0x1306960: ret             
    // 0x1306964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306968: b               #0x13068e0
  }
}

// class id: 2912, size: 0x14, field offset: 0x8
class WordBoundary extends TextBoundary {

  late final TextBoundary moveByWordBoundary; // offset: 0x10
  static late final RegExp _regExpSpaceSeparatorOrPunctuation; // offset: 0x608

  TextBoundary moveByWordBoundary(WordBoundary) {
    // ** addr: 0x12a2194, size: 0x68
    // 0x12a2194: EnterFrame
    //     0x12a2194: stp             fp, lr, [SP, #-0x10]!
    //     0x12a2198: mov             fp, SP
    // 0x12a219c: AllocStack(0x10)
    //     0x12a219c: sub             SP, SP, #0x10
    // 0x12a21a0: CheckStackOverflow
    //     0x12a21a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a21a4: cmp             SP, x16
    //     0x12a21a8: b.ls            #0x12a21f4
    // 0x12a21ac: ldr             x1, [fp, #0x10]
    // 0x12a21b0: r0 = 60
    //     0x12a21b0: mov             x0, #0x3c
    // 0x12a21b4: branchIfSmi(r1, 0x12a21c0)
    //     0x12a21b4: tbz             w1, #0, #0x12a21c0
    // 0x12a21b8: r0 = LoadClassIdInstr(r1)
    //     0x12a21b8: ldur            x0, [x1, #-1]
    //     0x12a21bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12a21c0: str             x1, [SP]
    // 0x12a21c4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12a21c4: sub             lr, x0, #1, lsl #12
    //     0x12a21c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12a21cc: blr             lr
    // 0x12a21d0: stur            x0, [fp, #-8]
    // 0x12a21d4: r0 = _UntilTextBoundary()
    //     0x12a21d4: bl              #0x12a21fc  ; Allocate_UntilTextBoundaryStub -> _UntilTextBoundary (size=0x10)
    // 0x12a21d8: ldr             x1, [fp, #0x10]
    // 0x12a21dc: StoreField: r0->field_b = r1
    //     0x12a21dc: stur            w1, [x0, #0xb]
    // 0x12a21e0: ldur            x1, [fp, #-8]
    // 0x12a21e4: StoreField: r0->field_7 = r1
    //     0x12a21e4: stur            w1, [x0, #7]
    // 0x12a21e8: LeaveFrame
    //     0x12a21e8: mov             SP, fp
    //     0x12a21ec: ldp             fp, lr, [SP], #0x10
    // 0x12a21f0: ret
    //     0x12a21f0: ret             
    // 0x12a21f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a21f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a21f8: b               #0x12a21ac
  }
  [closure] bool _skipSpacesAndPunctuations(dynamic, int, bool) {
    // ** addr: 0x1306094, size: 0x40
    // 0x1306094: EnterFrame
    //     0x1306094: stp             fp, lr, [SP, #-0x10]!
    //     0x1306098: mov             fp, SP
    // 0x130609c: ldr             x0, [fp, #0x20]
    // 0x13060a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x13060a0: ldur            w1, [x0, #0x17]
    // 0x13060a4: DecompressPointer r1
    //     0x13060a4: add             x1, x1, HEAP, lsl #32
    // 0x13060a8: CheckStackOverflow
    //     0x13060a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13060ac: cmp             SP, x16
    //     0x13060b0: b.ls            #0x13060cc
    // 0x13060b4: ldr             x2, [fp, #0x18]
    // 0x13060b8: ldr             x3, [fp, #0x10]
    // 0x13060bc: r0 = _skipSpacesAndPunctuations()
    //     0x13060bc: bl              #0x13060d4  ; [package:flutter/src/painting/text_painter.dart] WordBoundary::_skipSpacesAndPunctuations
    // 0x13060c0: LeaveFrame
    //     0x13060c0: mov             SP, fp
    //     0x13060c4: ldp             fp, lr, [SP], #0x10
    // 0x13060c8: ret
    //     0x13060c8: ret             
    // 0x13060cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13060cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13060d0: b               #0x13060b4
  }
  _ _skipSpacesAndPunctuations(/* No info */) {
    // ** addr: 0x13060d4, size: 0x1a4
    // 0x13060d4: EnterFrame
    //     0x13060d4: stp             fp, lr, [SP, #-0x10]!
    //     0x13060d8: mov             fp, SP
    // 0x13060dc: AllocStack(0x28)
    //     0x13060dc: sub             SP, SP, #0x28
    // 0x13060e0: SetupParameters(WordBoundary this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x13060e0: mov             x4, x1
    //     0x13060e4: mov             x0, x2
    //     0x13060e8: stur            x1, [fp, #-8]
    //     0x13060ec: stur            x2, [fp, #-0x10]
    //     0x13060f0: stur            x3, [fp, #-0x18]
    // 0x13060f4: CheckStackOverflow
    //     0x13060f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13060f8: cmp             SP, x16
    //     0x13060fc: b.ls            #0x1306270
    // 0x1306100: tbnz            w3, #4, #0x1306118
    // 0x1306104: r1 = LoadInt32Instr(r0)
    //     0x1306104: sbfx            x1, x0, #1, #0x1f
    //     0x1306108: tbz             w0, #0, #0x1306110
    //     0x130610c: ldur            x1, [x0, #7]
    // 0x1306110: sub             x2, x1, #1
    // 0x1306114: b               #0x1306128
    // 0x1306118: r1 = LoadInt32Instr(r0)
    //     0x1306118: sbfx            x1, x0, #1, #0x1f
    //     0x130611c: tbz             w0, #0, #0x1306124
    //     0x1306120: ldur            x1, [x0, #7]
    // 0x1306124: mov             x2, x1
    // 0x1306128: mov             x1, x4
    // 0x130612c: r0 = _codePointAt()
    //     0x130612c: bl              #0x1306278  ; [package:flutter/src/painting/text_painter.dart] WordBoundary::_codePointAt
    // 0x1306130: mov             x3, x0
    // 0x1306134: ldur            x0, [fp, #-8]
    // 0x1306138: stur            x3, [fp, #-0x20]
    // 0x130613c: LoadField: r1 = r0->field_7
    //     0x130613c: ldur            w1, [x0, #7]
    // 0x1306140: DecompressPointer r1
    //     0x1306140: add             x1, x1, HEAP, lsl #32
    // 0x1306144: ldur            x0, [fp, #-0x18]
    // 0x1306148: tbnz            w0, #4, #0x1306160
    // 0x130614c: ldur            x0, [fp, #-0x10]
    // 0x1306150: r2 = LoadInt32Instr(r0)
    //     0x1306150: sbfx            x2, x0, #1, #0x1f
    //     0x1306154: tbz             w0, #0, #0x130615c
    //     0x1306158: ldur            x2, [x0, #7]
    // 0x130615c: b               #0x1306178
    // 0x1306160: ldur            x0, [fp, #-0x10]
    // 0x1306164: r2 = LoadInt32Instr(r0)
    //     0x1306164: sbfx            x2, x0, #1, #0x1f
    //     0x1306168: tbz             w0, #0, #0x1306170
    //     0x130616c: ldur            x2, [x0, #7]
    // 0x1306170: sub             x0, x2, #1
    // 0x1306174: mov             x2, x0
    // 0x1306178: r0 = codeUnitAt()
    //     0x1306178: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x130617c: mov             x1, x0
    // 0x1306180: ldur            x0, [fp, #-0x20]
    // 0x1306184: cmp             w0, NULL
    // 0x1306188: b.eq            #0x1306218
    // 0x130618c: cmp             w1, NULL
    // 0x1306190: b.eq            #0x1306218
    // 0x1306194: r2 = LoadInt32Instr(r0)
    //     0x1306194: sbfx            x2, x0, #1, #0x1f
    //     0x1306198: tbz             w0, #0, #0x13061a0
    //     0x130619c: ldur            x2, [x0, #7]
    // 0x13061a0: stur            x2, [fp, #-0x28]
    // 0x13061a4: cmp             x2, #0xa
    // 0x13061a8: b.eq            #0x1306218
    // 0x13061ac: cmp             x2, #0x85
    // 0x13061b0: b.eq            #0x1306218
    // 0x13061b4: cmp             x2, #0xb
    // 0x13061b8: b.eq            #0x1306218
    // 0x13061bc: cmp             x2, #0xc
    // 0x13061c0: b.eq            #0x1306218
    // 0x13061c4: r17 = 8232
    //     0x13061c4: mov             x17, #0x2028
    // 0x13061c8: cmp             x2, x17
    // 0x13061cc: b.eq            #0x1306218
    // 0x13061d0: r17 = 8233
    //     0x13061d0: mov             x17, #0x2029
    // 0x13061d4: cmp             x2, x17
    // 0x13061d8: b.eq            #0x1306218
    // 0x13061dc: r0 = LoadInt32Instr(r1)
    //     0x13061dc: sbfx            x0, x1, #1, #0x1f
    // 0x13061e0: cmp             x0, #0xa
    // 0x13061e4: b.eq            #0x1306218
    // 0x13061e8: cmp             x0, #0x85
    // 0x13061ec: b.eq            #0x1306218
    // 0x13061f0: cmp             x0, #0xb
    // 0x13061f4: b.eq            #0x1306218
    // 0x13061f8: cmp             x0, #0xc
    // 0x13061fc: b.eq            #0x1306218
    // 0x1306200: r17 = 8232
    //     0x1306200: mov             x17, #0x2028
    // 0x1306204: cmp             x0, x17
    // 0x1306208: b.eq            #0x1306218
    // 0x130620c: r17 = 8233
    //     0x130620c: mov             x17, #0x2029
    // 0x1306210: cmp             x0, x17
    // 0x1306214: b.ne            #0x1306220
    // 0x1306218: r0 = true
    //     0x1306218: add             x0, NULL, #0x20  ; true
    // 0x130621c: b               #0x1306264
    // 0x1306220: r0 = LoadStaticField(0x608)
    //     0x1306220: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1306224: ldr             x0, [x0, #0xc10]
    // 0x1306228: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x130622c: cmp             w0, w16
    // 0x1306230: b.ne            #0x1306240
    // 0x1306234: r2 = _regExpSpaceSeparatorOrPunctuation
    //     0x1306234: add             x2, PP, #0xcd, lsl #12  ; [pp+0xcd8c0] Field <WordBoundary._regExpSpaceSeparatorOrPunctuation@49105366>: static late final (offset: 0x608)
    //     0x1306238: ldr             x2, [x2, #0x8c0]
    // 0x130623c: r0 = InitLateFinalStaticField()
    //     0x130623c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x1306240: ldur            x2, [fp, #-0x28]
    // 0x1306244: r1 = Null
    //     0x1306244: mov             x1, NULL
    // 0x1306248: stur            x0, [fp, #-8]
    // 0x130624c: r0 = String.fromCharCode()
    //     0x130624c: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1306250: ldur            x1, [fp, #-8]
    // 0x1306254: mov             x2, x0
    // 0x1306258: r0 = hasMatch()
    //     0x1306258: bl              #0x85f8c8  ; [dart:core] _RegExp::hasMatch
    // 0x130625c: eor             x1, x0, #0x10
    // 0x1306260: mov             x0, x1
    // 0x1306264: LeaveFrame
    //     0x1306264: mov             SP, fp
    //     0x1306268: ldp             fp, lr, [SP], #0x10
    // 0x130626c: ret
    //     0x130626c: ret             
    // 0x1306270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306274: b               #0x1306100
  }
  _ _codePointAt(/* No info */) {
    // ** addr: 0x1306278, size: 0x128
    // 0x1306278: EnterFrame
    //     0x1306278: stp             fp, lr, [SP, #-0x10]!
    //     0x130627c: mov             fp, SP
    // 0x1306280: AllocStack(0x18)
    //     0x1306280: sub             SP, SP, #0x18
    // 0x1306284: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1306284: mov             x0, x2
    //     0x1306288: stur            x2, [fp, #-0x10]
    // 0x130628c: CheckStackOverflow
    //     0x130628c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306290: cmp             SP, x16
    //     0x1306294: b.ls            #0x1306390
    // 0x1306298: LoadField: r3 = r1->field_7
    //     0x1306298: ldur            w3, [x1, #7]
    // 0x130629c: DecompressPointer r3
    //     0x130629c: add             x3, x3, HEAP, lsl #32
    // 0x13062a0: mov             x1, x3
    // 0x13062a4: mov             x2, x0
    // 0x13062a8: stur            x3, [fp, #-8]
    // 0x13062ac: r0 = codeUnitAt()
    //     0x13062ac: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x13062b0: cmp             w0, NULL
    // 0x13062b4: b.ne            #0x13062c8
    // 0x13062b8: r0 = Null
    //     0x13062b8: mov             x0, NULL
    // 0x13062bc: LeaveFrame
    //     0x13062bc: mov             SP, fp
    //     0x13062c0: ldp             fp, lr, [SP], #0x10
    // 0x13062c4: ret
    //     0x13062c4: ret             
    // 0x13062c8: r3 = LoadInt32Instr(r0)
    //     0x13062c8: sbfx            x3, x0, #1, #0x1f
    // 0x13062cc: stur            x3, [fp, #-0x18]
    // 0x13062d0: mov             x0, x3
    // 0x13062d4: ubfx            x0, x0, #0, #0x20
    // 0x13062d8: and             w1, w0, #0xfc00
    // 0x13062dc: r17 = 55296
    //     0x13062dc: mov             x17, #0xd800
    // 0x13062e0: cmp             w1, w17
    // 0x13062e4: b.ne            #0x1306324
    // 0x13062e8: ldur            x0, [fp, #-0x10]
    // 0x13062ec: add             x2, x0, #1
    // 0x13062f0: ldur            x1, [fp, #-8]
    // 0x13062f4: r0 = codeUnitAt()
    //     0x13062f4: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x13062f8: cmp             w0, NULL
    // 0x13062fc: b.eq            #0x1306398
    // 0x1306300: ldur            x3, [fp, #-0x18]
    // 0x1306304: lsl             x1, x3, #0xa
    // 0x1306308: r2 = LoadInt32Instr(r0)
    //     0x1306308: sbfx            x2, x0, #1, #0x1f
    // 0x130630c: add             x0, x1, x2
    // 0x1306310: r17 = -56557569
    //     0x1306310: mov             x17, #-0x35f0001
    // 0x1306314: movk            x17, #0x2400
    // 0x1306318: add             x1, x0, x17
    // 0x130631c: mov             x2, x1
    // 0x1306320: b               #0x1306370
    // 0x1306324: ldur            x0, [fp, #-0x10]
    // 0x1306328: r17 = 56320
    //     0x1306328: mov             x17, #0xdc00
    // 0x130632c: cmp             w1, w17
    // 0x1306330: b.ne            #0x130636c
    // 0x1306334: sub             x2, x0, #1
    // 0x1306338: ldur            x1, [fp, #-8]
    // 0x130633c: r0 = codeUnitAt()
    //     0x130633c: bl              #0xb97dec  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x1306340: cmp             w0, NULL
    // 0x1306344: b.eq            #0x130639c
    // 0x1306348: r2 = LoadInt32Instr(r0)
    //     0x1306348: sbfx            x2, x0, #1, #0x1f
    // 0x130634c: lsl             x3, x2, #0xa
    // 0x1306350: ldur            x2, [fp, #-0x18]
    // 0x1306354: add             x4, x3, x2
    // 0x1306358: r17 = -56557569
    //     0x1306358: mov             x17, #-0x35f0001
    // 0x130635c: movk            x17, #0x2400
    // 0x1306360: add             x3, x4, x17
    // 0x1306364: mov             x2, x3
    // 0x1306368: b               #0x1306370
    // 0x130636c: mov             x2, x3
    // 0x1306370: r0 = BoxInt64Instr(r2)
    //     0x1306370: sbfiz           x0, x2, #1, #0x1f
    //     0x1306374: cmp             x2, x0, asr #1
    //     0x1306378: b.eq            #0x1306384
    //     0x130637c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1306380: stur            x2, [x0, #7]
    // 0x1306384: LeaveFrame
    //     0x1306384: mov             SP, fp
    //     0x1306388: ldp             fp, lr, [SP], #0x10
    // 0x130638c: ret
    //     0x130638c: ret             
    // 0x1306390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306394: b               #0x1306298
    // 0x1306398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1306398: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x130639c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x130639c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static RegExp _regExpSpaceSeparatorOrPunctuation() {
    // ** addr: 0x13063a0, size: 0x58
    // 0x13063a0: EnterFrame
    //     0x13063a0: stp             fp, lr, [SP, #-0x10]!
    //     0x13063a4: mov             fp, SP
    // 0x13063a8: AllocStack(0x30)
    //     0x13063a8: sub             SP, SP, #0x30
    // 0x13063ac: CheckStackOverflow
    //     0x13063ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13063b0: cmp             SP, x16
    //     0x13063b4: b.ls            #0x13063f0
    // 0x13063b8: r16 = "[\\p{Space_Separator}\\p{Punctuation}]"
    //     0x13063b8: add             x16, PP, #0xcd, lsl #12  ; [pp+0xcd8c8] "[\\p{Space_Separator}\\p{Punctuation}]"
    //     0x13063bc: ldr             x16, [x16, #0x8c8]
    // 0x13063c0: stp             x16, NULL, [SP, #0x20]
    // 0x13063c4: r16 = false
    //     0x13063c4: add             x16, NULL, #0x30  ; false
    // 0x13063c8: r30 = true
    //     0x13063c8: add             lr, NULL, #0x20  ; true
    // 0x13063cc: stp             lr, x16, [SP, #0x10]
    // 0x13063d0: r16 = true
    //     0x13063d0: add             x16, NULL, #0x20  ; true
    // 0x13063d4: r30 = false
    //     0x13063d4: add             lr, NULL, #0x30  ; false
    // 0x13063d8: stp             lr, x16, [SP]
    // 0x13063dc: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x13063dc: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x13063e0: r0 = _RegExp()
    //     0x13063e0: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x13063e4: LeaveFrame
    //     0x13063e4: mov             SP, fp
    //     0x13063e8: ldp             fp, lr, [SP], #0x10
    // 0x13063ec: ret
    //     0x13063ec: ret             
    // 0x13063f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13063f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13063f4: b               #0x13063b8
  }
  _ getTextBoundaryAt(/* No info */) {
    // ** addr: 0x1306e00, size: 0x6c
    // 0x1306e00: EnterFrame
    //     0x1306e00: stp             fp, lr, [SP, #-0x10]!
    //     0x1306e04: mov             fp, SP
    // 0x1306e08: AllocStack(0x10)
    //     0x1306e08: sub             SP, SP, #0x10
    // 0x1306e0c: r0 = 0
    //     0x1306e0c: mov             x0, #0
    // 0x1306e10: CheckStackOverflow
    //     0x1306e10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306e14: cmp             SP, x16
    //     0x1306e18: b.ls            #0x1306e64
    // 0x1306e1c: LoadField: r3 = r1->field_b
    //     0x1306e1c: ldur            w3, [x1, #0xb]
    // 0x1306e20: DecompressPointer r3
    //     0x1306e20: add             x3, x3, HEAP, lsl #32
    // 0x1306e24: stur            x3, [fp, #-0x10]
    // 0x1306e28: cmp             x2, x0
    // 0x1306e2c: csel            x1, x0, x2, lt
    // 0x1306e30: stur            x1, [fp, #-8]
    // 0x1306e34: r0 = TextPosition()
    //     0x1306e34: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x1306e38: mov             x1, x0
    // 0x1306e3c: ldur            x0, [fp, #-8]
    // 0x1306e40: StoreField: r1->field_7 = r0
    //     0x1306e40: stur            x0, [x1, #7]
    // 0x1306e44: r0 = Instance_TextAffinity
    //     0x1306e44: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x1306e48: StoreField: r1->field_f = r0
    //     0x1306e48: stur            w0, [x1, #0xf]
    // 0x1306e4c: mov             x2, x1
    // 0x1306e50: ldur            x1, [fp, #-0x10]
    // 0x1306e54: r0 = getWordBoundary()
    //     0x1306e54: bl              #0xb97efc  ; [dart:ui] _NativeParagraph::getWordBoundary
    // 0x1306e58: LeaveFrame
    //     0x1306e58: mov             SP, fp
    //     0x1306e5c: ldp             fp, lr, [SP], #0x10
    // 0x1306e60: ret
    //     0x1306e60: ret             
    // 0x1306e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306e64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306e68: b               #0x1306e1c
  }
  dynamic _skipSpacesAndPunctuations(dynamic) {
    // ** addr: 0x1306e6c, size: 0x24
    // 0x1306e6c: EnterFrame
    //     0x1306e6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1306e70: mov             fp, SP
    // 0x1306e74: ldr             x2, [fp, #0x10]
    // 0x1306e78: r1 = Function '_skipSpacesAndPunctuations@49105366':.
    //     0x1306e78: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd8d0] AnonymousClosure: (0x1306094), in [package:flutter/src/painting/text_painter.dart] WordBoundary::_skipSpacesAndPunctuations (0x13060d4)
    //     0x1306e7c: ldr             x1, [x1, #0x8d0]
    // 0x1306e80: r0 = AllocateClosure()
    //     0x1306e80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1306e84: LeaveFrame
    //     0x1306e84: mov             SP, fp
    //     0x1306e88: ldp             fp, lr, [SP], #0x10
    // 0x1306e8c: ret
    //     0x1306e8c: ret             
  }
}

// class id: 2913, size: 0x18, field offset: 0x8
//   const constructor, 
class PlaceholderDimensions extends Object {

  Size field_8;
  PlaceholderAlignment field_c;

  get _ hashCode(/* No info */) {
    // ** addr: 0x114c218, size: 0x74
    // 0x114c218: EnterFrame
    //     0x114c218: stp             fp, lr, [SP, #-0x10]!
    //     0x114c21c: mov             fp, SP
    // 0x114c220: AllocStack(0x10)
    //     0x114c220: sub             SP, SP, #0x10
    // 0x114c224: CheckStackOverflow
    //     0x114c224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c228: cmp             SP, x16
    //     0x114c22c: b.ls            #0x114c284
    // 0x114c230: ldr             x0, [fp, #0x10]
    // 0x114c234: LoadField: r1 = r0->field_7
    //     0x114c234: ldur            w1, [x0, #7]
    // 0x114c238: DecompressPointer r1
    //     0x114c238: add             x1, x1, HEAP, lsl #32
    // 0x114c23c: LoadField: r2 = r0->field_b
    //     0x114c23c: ldur            w2, [x0, #0xb]
    // 0x114c240: DecompressPointer r2
    //     0x114c240: add             x2, x2, HEAP, lsl #32
    // 0x114c244: LoadField: r3 = r0->field_13
    //     0x114c244: ldur            w3, [x0, #0x13]
    // 0x114c248: DecompressPointer r3
    //     0x114c248: add             x3, x3, HEAP, lsl #32
    // 0x114c24c: LoadField: r4 = r0->field_f
    //     0x114c24c: ldur            w4, [x0, #0xf]
    // 0x114c250: DecompressPointer r4
    //     0x114c250: add             x4, x4, HEAP, lsl #32
    // 0x114c254: stp             x4, x3, [SP]
    // 0x114c258: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x114c258: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x114c25c: r0 = hash()
    //     0x114c25c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c260: mov             x2, x0
    // 0x114c264: r0 = BoxInt64Instr(r2)
    //     0x114c264: sbfiz           x0, x2, #1, #0x1f
    //     0x114c268: cmp             x2, x0, asr #1
    //     0x114c26c: b.eq            #0x114c278
    //     0x114c270: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c274: stur            x2, [x0, #7]
    // 0x114c278: LeaveFrame
    //     0x114c278: mov             SP, fp
    //     0x114c27c: ldp             fp, lr, [SP], #0x10
    // 0x114c280: ret
    //     0x114c280: ret             
    // 0x114c284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c288: b               #0x114c230
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299750, size: 0x110
    // 0x1299750: EnterFrame
    //     0x1299750: stp             fp, lr, [SP, #-0x10]!
    //     0x1299754: mov             fp, SP
    // 0x1299758: AllocStack(0x10)
    //     0x1299758: sub             SP, SP, #0x10
    // 0x129975c: CheckStackOverflow
    //     0x129975c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299760: cmp             SP, x16
    //     0x1299764: b.ls            #0x1299858
    // 0x1299768: ldr             x0, [fp, #0x10]
    // 0x129976c: cmp             w0, NULL
    // 0x1299770: b.ne            #0x1299784
    // 0x1299774: r0 = false
    //     0x1299774: add             x0, NULL, #0x30  ; false
    // 0x1299778: LeaveFrame
    //     0x1299778: mov             SP, fp
    //     0x129977c: ldp             fp, lr, [SP], #0x10
    // 0x1299780: ret
    //     0x1299780: ret             
    // 0x1299784: ldr             x1, [fp, #0x18]
    // 0x1299788: cmp             w1, w0
    // 0x129978c: b.ne            #0x12997a0
    // 0x1299790: r0 = true
    //     0x1299790: add             x0, NULL, #0x20  ; true
    // 0x1299794: LeaveFrame
    //     0x1299794: mov             SP, fp
    //     0x1299798: ldp             fp, lr, [SP], #0x10
    // 0x129979c: ret
    //     0x129979c: ret             
    // 0x12997a0: r2 = 60
    //     0x12997a0: mov             x2, #0x3c
    // 0x12997a4: branchIfSmi(r0, 0x12997b0)
    //     0x12997a4: tbz             w0, #0, #0x12997b0
    // 0x12997a8: r2 = LoadClassIdInstr(r0)
    //     0x12997a8: ldur            x2, [x0, #-1]
    //     0x12997ac: ubfx            x2, x2, #0xc, #0x14
    // 0x12997b0: cmp             x2, #0xb61
    // 0x12997b4: b.ne            #0x1299848
    // 0x12997b8: LoadField: r2 = r0->field_7
    //     0x12997b8: ldur            w2, [x0, #7]
    // 0x12997bc: DecompressPointer r2
    //     0x12997bc: add             x2, x2, HEAP, lsl #32
    // 0x12997c0: LoadField: r3 = r1->field_7
    //     0x12997c0: ldur            w3, [x1, #7]
    // 0x12997c4: DecompressPointer r3
    //     0x12997c4: add             x3, x3, HEAP, lsl #32
    // 0x12997c8: LoadField: d0 = r3->field_7
    //     0x12997c8: ldur            d0, [x3, #7]
    // 0x12997cc: LoadField: d1 = r2->field_7
    //     0x12997cc: ldur            d1, [x2, #7]
    // 0x12997d0: fcmp            d0, d1
    // 0x12997d4: b.ne            #0x1299848
    // 0x12997d8: LoadField: d0 = r3->field_f
    //     0x12997d8: ldur            d0, [x3, #0xf]
    // 0x12997dc: LoadField: d1 = r2->field_f
    //     0x12997dc: ldur            d1, [x2, #0xf]
    // 0x12997e0: fcmp            d0, d1
    // 0x12997e4: b.ne            #0x1299848
    // 0x12997e8: LoadField: r2 = r0->field_b
    //     0x12997e8: ldur            w2, [x0, #0xb]
    // 0x12997ec: DecompressPointer r2
    //     0x12997ec: add             x2, x2, HEAP, lsl #32
    // 0x12997f0: LoadField: r3 = r1->field_b
    //     0x12997f0: ldur            w3, [x1, #0xb]
    // 0x12997f4: DecompressPointer r3
    //     0x12997f4: add             x3, x3, HEAP, lsl #32
    // 0x12997f8: cmp             w2, w3
    // 0x12997fc: b.ne            #0x1299848
    // 0x1299800: LoadField: r2 = r0->field_13
    //     0x1299800: ldur            w2, [x0, #0x13]
    // 0x1299804: DecompressPointer r2
    //     0x1299804: add             x2, x2, HEAP, lsl #32
    // 0x1299808: LoadField: r3 = r1->field_13
    //     0x1299808: ldur            w3, [x1, #0x13]
    // 0x129980c: DecompressPointer r3
    //     0x129980c: add             x3, x3, HEAP, lsl #32
    // 0x1299810: cmp             w2, w3
    // 0x1299814: b.ne            #0x1299848
    // 0x1299818: LoadField: r2 = r0->field_f
    //     0x1299818: ldur            w2, [x0, #0xf]
    // 0x129981c: DecompressPointer r2
    //     0x129981c: add             x2, x2, HEAP, lsl #32
    // 0x1299820: LoadField: r0 = r1->field_f
    //     0x1299820: ldur            w0, [x1, #0xf]
    // 0x1299824: DecompressPointer r0
    //     0x1299824: add             x0, x0, HEAP, lsl #32
    // 0x1299828: r1 = LoadClassIdInstr(r2)
    //     0x1299828: ldur            x1, [x2, #-1]
    //     0x129982c: ubfx            x1, x1, #0xc, #0x14
    // 0x1299830: stp             x0, x2, [SP]
    // 0x1299834: mov             x0, x1
    // 0x1299838: mov             lr, x0
    // 0x129983c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299840: blr             lr
    // 0x1299844: b               #0x129984c
    // 0x1299848: r0 = false
    //     0x1299848: add             x0, NULL, #0x30  ; false
    // 0x129984c: LeaveFrame
    //     0x129984c: mov             SP, fp
    //     0x1299850: ldp             fp, lr, [SP], #0x10
    // 0x1299854: ret
    //     0x1299854: ret             
    // 0x1299858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129985c: b               #0x1299768
  }
}

// class id: 8242, size: 0x14, field offset: 0x14
enum TextWidthBasis extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aae40, size: 0x64
    // 0x11aae40: EnterFrame
    //     0x11aae40: stp             fp, lr, [SP, #-0x10]!
    //     0x11aae44: mov             fp, SP
    // 0x11aae48: AllocStack(0x10)
    //     0x11aae48: sub             SP, SP, #0x10
    // 0x11aae4c: SetupParameters(TextWidthBasis this /* r1 => r0, fp-0x8 */)
    //     0x11aae4c: mov             x0, x1
    //     0x11aae50: stur            x1, [fp, #-8]
    // 0x11aae54: CheckStackOverflow
    //     0x11aae54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aae58: cmp             SP, x16
    //     0x11aae5c: b.ls            #0x11aae9c
    // 0x11aae60: r1 = Null
    //     0x11aae60: mov             x1, NULL
    // 0x11aae64: r2 = 4
    //     0x11aae64: mov             x2, #4
    // 0x11aae68: r0 = AllocateArray()
    //     0x11aae68: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aae6c: r16 = "TextWidthBasis."
    //     0x11aae6c: add             x16, PP, #0x85, lsl #12  ; [pp+0x851f8] "TextWidthBasis."
    //     0x11aae70: ldr             x16, [x16, #0x1f8]
    // 0x11aae74: StoreField: r0->field_f = r16
    //     0x11aae74: stur            w16, [x0, #0xf]
    // 0x11aae78: ldur            x1, [fp, #-8]
    // 0x11aae7c: LoadField: r2 = r1->field_f
    //     0x11aae7c: ldur            w2, [x1, #0xf]
    // 0x11aae80: DecompressPointer r2
    //     0x11aae80: add             x2, x2, HEAP, lsl #32
    // 0x11aae84: StoreField: r0->field_13 = r2
    //     0x11aae84: stur            w2, [x0, #0x13]
    // 0x11aae88: str             x0, [SP]
    // 0x11aae8c: r0 = _interpolate()
    //     0x11aae8c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aae90: LeaveFrame
    //     0x11aae90: mov             SP, fp
    //     0x11aae94: ldp             fp, lr, [SP], #0x10
    // 0x11aae98: ret
    //     0x11aae98: ret             
    // 0x11aae9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aae9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aaea0: b               #0x11aae60
  }
}

// class id: 8243, size: 0x14, field offset: 0x14
enum TextOverflow extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
