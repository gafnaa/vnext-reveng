// lib: , url: package:flutter/src/painting/box_border.dart

// class id: 1048983, size: 0x8
class :: {
}

// class id: 3011, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class BoxBorder extends ShapeBorder {

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbffd90, size: 0x1b8
    // 0xbffd90: EnterFrame
    //     0xbffd90: stp             fp, lr, [SP, #-0x10]!
    //     0xbffd94: mov             fp, SP
    // 0xbffd98: AllocStack(0x48)
    //     0xbffd98: sub             SP, SP, #0x48
    // 0xbffd9c: SetupParameters(BoxBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbffd9c: stur            x1, [fp, #-8]
    //     0xbffda0: stur            x2, [fp, #-0x10]
    // 0xbffda4: CheckStackOverflow
    //     0xbffda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbffda8: cmp             SP, x16
    //     0xbffdac: b.ls            #0xbfff3c
    // 0xbffdb0: r0 = _NativePath()
    //     0xbffdb0: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbffdb4: mov             x1, x0
    // 0xbffdb8: stur            x0, [fp, #-0x18]
    // 0xbffdbc: r0 = __constructor$Method$FfiNative()
    //     0xbffdbc: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbffdc0: ldur            x0, [fp, #-8]
    // 0xbffdc4: r1 = LoadClassIdInstr(r0)
    //     0xbffdc4: ldur            x1, [x0, #-1]
    //     0xbffdc8: ubfx            x1, x1, #0xc, #0x14
    // 0xbffdcc: cmp             x1, #0xbc4
    // 0xbffdd0: b.eq            #0xbfff20
    // 0xbffdd4: ldur            x1, [fp, #-0x18]
    // 0xbffdd8: d1 = 1.000000
    //     0xbffdd8: fmov            d1, #1.00000000
    // 0xbffddc: d0 = 2.000000
    //     0xbffddc: fmov            d0, #2.00000000
    // 0xbffde0: LoadField: r2 = r0->field_13
    //     0xbffde0: ldur            w2, [x0, #0x13]
    // 0xbffde4: DecompressPointer r2
    //     0xbffde4: add             x2, x2, HEAP, lsl #32
    // 0xbffde8: LoadField: d2 = r2->field_b
    //     0xbffde8: ldur            d2, [x2, #0xb]
    // 0xbffdec: ArrayLoad: d3 = r2[0]  ; List_8
    //     0xbffdec: ldur            d3, [x2, #0x17]
    // 0xbffdf0: fadd            d4, d3, d1
    // 0xbffdf4: fdiv            d3, d4, d0
    // 0xbffdf8: fsub            d4, d1, d3
    // 0xbffdfc: fmul            d3, d2, d4
    // 0xbffe00: stur            d3, [fp, #-0x40]
    // 0xbffe04: LoadField: r2 = r0->field_7
    //     0xbffe04: ldur            w2, [x0, #7]
    // 0xbffe08: DecompressPointer r2
    //     0xbffe08: add             x2, x2, HEAP, lsl #32
    // 0xbffe0c: LoadField: d2 = r2->field_b
    //     0xbffe0c: ldur            d2, [x2, #0xb]
    // 0xbffe10: ArrayLoad: d4 = r2[0]  ; List_8
    //     0xbffe10: ldur            d4, [x2, #0x17]
    // 0xbffe14: fadd            d5, d4, d1
    // 0xbffe18: fdiv            d4, d5, d0
    // 0xbffe1c: fsub            d5, d1, d4
    // 0xbffe20: fmul            d4, d2, d5
    // 0xbffe24: stur            d4, [fp, #-0x38]
    // 0xbffe28: LoadField: r2 = r0->field_b
    //     0xbffe28: ldur            w2, [x0, #0xb]
    // 0xbffe2c: DecompressPointer r2
    //     0xbffe2c: add             x2, x2, HEAP, lsl #32
    // 0xbffe30: LoadField: d2 = r2->field_b
    //     0xbffe30: ldur            d2, [x2, #0xb]
    // 0xbffe34: ArrayLoad: d5 = r2[0]  ; List_8
    //     0xbffe34: ldur            d5, [x2, #0x17]
    // 0xbffe38: fadd            d6, d5, d1
    // 0xbffe3c: fdiv            d5, d6, d0
    // 0xbffe40: fsub            d6, d1, d5
    // 0xbffe44: fmul            d5, d2, d6
    // 0xbffe48: stur            d5, [fp, #-0x30]
    // 0xbffe4c: LoadField: r2 = r0->field_f
    //     0xbffe4c: ldur            w2, [x0, #0xf]
    // 0xbffe50: DecompressPointer r2
    //     0xbffe50: add             x2, x2, HEAP, lsl #32
    // 0xbffe54: LoadField: d2 = r2->field_b
    //     0xbffe54: ldur            d2, [x2, #0xb]
    // 0xbffe58: ArrayLoad: d6 = r2[0]  ; List_8
    //     0xbffe58: ldur            d6, [x2, #0x17]
    // 0xbffe5c: fadd            d7, d6, d1
    // 0xbffe60: fdiv            d6, d7, d0
    // 0xbffe64: fsub            d0, d1, d6
    // 0xbffe68: fmul            d1, d2, d0
    // 0xbffe6c: stur            d1, [fp, #-0x28]
    // 0xbffe70: r0 = EdgeInsets()
    //     0xbffe70: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xbffe74: ldur            d0, [fp, #-0x40]
    // 0xbffe78: StoreField: r0->field_7 = d0
    //     0xbffe78: stur            d0, [x0, #7]
    // 0xbffe7c: ldur            d0, [fp, #-0x38]
    // 0xbffe80: StoreField: r0->field_f = d0
    //     0xbffe80: stur            d0, [x0, #0xf]
    // 0xbffe84: ldur            d0, [fp, #-0x30]
    // 0xbffe88: ArrayStore: r0[0] = d0  ; List_8
    //     0xbffe88: stur            d0, [x0, #0x17]
    // 0xbffe8c: ldur            d0, [fp, #-0x28]
    // 0xbffe90: StoreField: r0->field_1f = d0
    //     0xbffe90: stur            d0, [x0, #0x1f]
    // 0xbffe94: mov             x1, x0
    // 0xbffe98: ldur            x2, [fp, #-0x10]
    // 0xbffe9c: r0 = deflateRect()
    //     0xbffe9c: bl              #0xb7a1f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0xbffea0: LoadField: d0 = r0->field_7
    //     0xbffea0: ldur            d0, [x0, #7]
    // 0xbffea4: stur            d0, [fp, #-0x40]
    // 0xbffea8: LoadField: d1 = r0->field_f
    //     0xbffea8: ldur            d1, [x0, #0xf]
    // 0xbffeac: stur            d1, [fp, #-0x38]
    // 0xbffeb0: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xbffeb0: ldur            d2, [x0, #0x17]
    // 0xbffeb4: stur            d2, [fp, #-0x30]
    // 0xbffeb8: LoadField: d3 = r0->field_1f
    //     0xbffeb8: ldur            d3, [x0, #0x1f]
    // 0xbffebc: ldur            x0, [fp, #-0x18]
    // 0xbffec0: stur            d3, [fp, #-0x28]
    // 0xbffec4: LoadField: r1 = r0->field_7
    //     0xbffec4: ldur            w1, [x0, #7]
    // 0xbffec8: DecompressPointer r1
    //     0xbffec8: add             x1, x1, HEAP, lsl #32
    // 0xbffecc: cmp             w1, NULL
    // 0xbffed0: b.eq            #0xbfff44
    // 0xbffed4: LoadField: r2 = r1->field_7
    //     0xbffed4: ldur            x2, [x1, #7]
    // 0xbffed8: ldr             x1, [x2]
    // 0xbffedc: cbz             x1, #0xbfff2c
    // 0xbffee0: mov             x2, x1
    // 0xbffee4: stur            x2, [fp, #-0x20]
    // 0xbffee8: r1 = <Never>
    //     0xbffee8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbffeec: r0 = Pointer()
    //     0xbffeec: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbffef0: mov             x1, x0
    // 0xbffef4: ldur            x0, [fp, #-0x20]
    // 0xbffef8: StoreField: r1->field_7 = r0
    //     0xbffef8: stur            x0, [x1, #7]
    // 0xbffefc: ldur            d0, [fp, #-0x40]
    // 0xbfff00: ldur            d1, [fp, #-0x38]
    // 0xbfff04: ldur            d2, [fp, #-0x30]
    // 0xbfff08: ldur            d3, [fp, #-0x28]
    // 0xbfff0c: r0 = __addRect$Method$FfiNative()
    //     0xbfff0c: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0xbfff10: ldur            x0, [fp, #-0x18]
    // 0xbfff14: LeaveFrame
    //     0xbfff14: mov             SP, fp
    //     0xbfff18: ldp             fp, lr, [SP], #0x10
    // 0xbfff1c: ret
    //     0xbfff1c: ret             
    // 0xbfff20: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbfff20: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbfff24: r0 = Throw()
    //     0xbfff24: bl              #0x13ddb2c  ; ThrowStub
    // 0xbfff28: brk             #0
    // 0xbfff2c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfff2c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfff30: str             x16, [SP]
    // 0xbfff34: r0 = _throwNew()
    //     0xbfff34: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfff38: brk             #0
    // 0xbfff3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfff3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfff40: b               #0xbffdb0
    // 0xbfff44: r0 = NullErrorSharedWithFPURegs()
    //     0xbfff44: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1162fb0, size: 0x48
    // 0x1162fb0: EnterFrame
    //     0x1162fb0: stp             fp, lr, [SP, #-0x10]!
    //     0x1162fb4: mov             fp, SP
    // 0x1162fb8: mov             x0, x1
    // 0x1162fbc: CheckStackOverflow
    //     0x1162fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1162fc0: cmp             SP, x16
    //     0x1162fc4: b.ls            #0x1162ff0
    // 0x1162fc8: cmp             w0, w2
    // 0x1162fcc: b.ne            #0x1162fdc
    // 0x1162fd0: LeaveFrame
    //     0x1162fd0: mov             SP, fp
    //     0x1162fd4: ldp             fp, lr, [SP], #0x10
    // 0x1162fd8: ret
    //     0x1162fd8: ret             
    // 0x1162fdc: mov             x1, x0
    // 0x1162fe0: r0 = lerp()
    //     0x1162fe0: bl              #0x10ee6ec  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0x1162fe4: LeaveFrame
    //     0x1162fe4: mov             SP, fp
    //     0x1162fe8: ldp             fp, lr, [SP], #0x10
    // 0x1162fec: ret
    //     0x1162fec: ret             
    // 0x1162ff0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162ff0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1162ff4: b               #0x1162fc8
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ecad8, size: 0x40
    // 0x12ecad8: EnterFrame
    //     0x12ecad8: stp             fp, lr, [SP, #-0x10]!
    //     0x12ecadc: mov             fp, SP
    // 0x12ecae0: mov             x0, x1
    // 0x12ecae4: mov             x1, x2
    // 0x12ecae8: mov             x2, x3
    // 0x12ecaec: mov             x3, x5
    // 0x12ecaf0: CheckStackOverflow
    //     0x12ecaf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ecaf4: cmp             SP, x16
    //     0x12ecaf8: b.ls            #0x12ecb10
    // 0x12ecafc: r0 = drawRect()
    //     0x12ecafc: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ecb00: r0 = Null
    //     0x12ecb00: mov             x0, NULL
    // 0x12ecb04: LeaveFrame
    //     0x12ecb04: mov             SP, fp
    //     0x12ecb08: ldp             fp, lr, [SP], #0x10
    // 0x12ecb0c: ret
    //     0x12ecb0c: ret             
    // 0x12ecb10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ecb10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ecb14: b               #0x12ecafc
  }
  static _ paintNonUniformBorder(/* No info */) {
    // ** addr: 0x12ee15c, size: 0x41c
    // 0x12ee15c: EnterFrame
    //     0x12ee15c: stp             fp, lr, [SP, #-0x10]!
    //     0x12ee160: mov             fp, SP
    // 0x12ee164: AllocStack(0xb8)
    //     0x12ee164: sub             SP, SP, #0xb8
    // 0x12ee168: SetupParameters(dynamic _ /* r1 => r6, fp-0x20 */, dynamic _ /* r2 => r2, fp-0x38 */, dynamic _ /* r5 => r5, fp-0x28 */, dynamic _ /* r6 => r0, fp-0x30 */, {dynamic left = Instance_BorderSide /* r8, fp-0x18 */, dynamic right = Instance_BorderSide /* r9, fp-0x10 */, dynamic shape = Instance_BoxShape /* r10 */, dynamic top = Instance_BorderSide /* r4, fp-0x8 */})
    //     0x12ee168: mov             x0, x6
    //     0x12ee16c: stur            x6, [fp, #-0x30]
    //     0x12ee170: mov             x6, x1
    //     0x12ee174: stur            x1, [fp, #-0x20]
    //     0x12ee178: stur            x5, [fp, #-0x28]
    //     0x12ee17c: stur            x2, [fp, #-0x38]
    //     0x12ee180: ldur            w1, [x4, #0x13]
    //     0x12ee184: ldur            w7, [x4, #0x1f]
    //     0x12ee188: add             x7, x7, HEAP, lsl #32
    //     0x12ee18c: ldr             x16, [PP, #0x57c0]  ; [pp+0x57c0] "left"
    //     0x12ee190: cmp             w7, w16
    //     0x12ee194: b.ne            #0x12ee1b8
    //     0x12ee198: ldur            w7, [x4, #0x23]
    //     0x12ee19c: add             x7, x7, HEAP, lsl #32
    //     0x12ee1a0: sub             w8, w1, w7
    //     0x12ee1a4: add             x7, fp, w8, sxtw #2
    //     0x12ee1a8: ldr             x7, [x7, #8]
    //     0x12ee1ac: mov             x8, x7
    //     0x12ee1b0: mov             x7, #1
    //     0x12ee1b4: b               #0x12ee1c4
    //     0x12ee1b8: add             x8, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12ee1bc: ldr             x8, [x8, #0x310]
    //     0x12ee1c0: mov             x7, #0
    //     0x12ee1c4: stur            x8, [fp, #-0x18]
    //     0x12ee1c8: lsl             x9, x7, #1
    //     0x12ee1cc: lsl             w10, w9, #1
    //     0x12ee1d0: add             w11, w10, #8
    //     0x12ee1d4: add             x16, x4, w11, sxtw #1
    //     0x12ee1d8: ldur            w12, [x16, #0xf]
    //     0x12ee1dc: add             x12, x12, HEAP, lsl #32
    //     0x12ee1e0: ldr             x16, [PP, #0x57c8]  ; [pp+0x57c8] "right"
    //     0x12ee1e4: cmp             w12, w16
    //     0x12ee1e8: b.ne            #0x12ee21c
    //     0x12ee1ec: add             w7, w10, #0xa
    //     0x12ee1f0: add             x16, x4, w7, sxtw #1
    //     0x12ee1f4: ldur            w10, [x16, #0xf]
    //     0x12ee1f8: add             x10, x10, HEAP, lsl #32
    //     0x12ee1fc: sub             w7, w1, w10
    //     0x12ee200: add             x10, fp, w7, sxtw #2
    //     0x12ee204: ldr             x10, [x10, #8]
    //     0x12ee208: add             w7, w9, #2
    //     0x12ee20c: sbfx            x9, x7, #1, #0x1f
    //     0x12ee210: mov             x7, x9
    //     0x12ee214: mov             x9, x10
    //     0x12ee218: b               #0x12ee224
    //     0x12ee21c: add             x9, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12ee220: ldr             x9, [x9, #0x310]
    //     0x12ee224: stur            x9, [fp, #-0x10]
    //     0x12ee228: lsl             x10, x7, #1
    //     0x12ee22c: lsl             w11, w10, #1
    //     0x12ee230: add             w12, w11, #8
    //     0x12ee234: add             x16, x4, w12, sxtw #1
    //     0x12ee238: ldur            w13, [x16, #0xf]
    //     0x12ee23c: add             x13, x13, HEAP, lsl #32
    //     0x12ee240: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0x12ee244: ldr             x16, [x16, #0xa28]
    //     0x12ee248: cmp             w13, w16
    //     0x12ee24c: b.ne            #0x12ee280
    //     0x12ee250: add             w7, w11, #0xa
    //     0x12ee254: add             x16, x4, w7, sxtw #1
    //     0x12ee258: ldur            w11, [x16, #0xf]
    //     0x12ee25c: add             x11, x11, HEAP, lsl #32
    //     0x12ee260: sub             w7, w1, w11
    //     0x12ee264: add             x11, fp, w7, sxtw #2
    //     0x12ee268: ldr             x11, [x11, #8]
    //     0x12ee26c: add             w7, w10, #2
    //     0x12ee270: sbfx            x10, x7, #1, #0x1f
    //     0x12ee274: mov             x7, x10
    //     0x12ee278: mov             x10, x11
    //     0x12ee27c: b               #0x12ee288
    //     0x12ee280: add             x10, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0x12ee284: ldr             x10, [x10, #0x1f8]
    //     0x12ee288: lsl             x11, x7, #1
    //     0x12ee28c: lsl             w7, w11, #1
    //     0x12ee290: add             w11, w7, #8
    //     0x12ee294: add             x16, x4, w11, sxtw #1
    //     0x12ee298: ldur            w12, [x16, #0xf]
    //     0x12ee29c: add             x12, x12, HEAP, lsl #32
    //     0x12ee2a0: ldr             x16, [PP, #0x57d0]  ; [pp+0x57d0] "top"
    //     0x12ee2a4: cmp             w12, w16
    //     0x12ee2a8: b.ne            #0x12ee2d0
    //     0x12ee2ac: add             w11, w7, #0xa
    //     0x12ee2b0: add             x16, x4, w11, sxtw #1
    //     0x12ee2b4: ldur            w7, [x16, #0xf]
    //     0x12ee2b8: add             x7, x7, HEAP, lsl #32
    //     0x12ee2bc: sub             w4, w1, w7
    //     0x12ee2c0: add             x1, fp, w4, sxtw #2
    //     0x12ee2c4: ldr             x1, [x1, #8]
    //     0x12ee2c8: mov             x4, x1
    //     0x12ee2cc: b               #0x12ee2d8
    //     0x12ee2d0: add             x4, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12ee2d4: ldr             x4, [x4, #0x310]
    //     0x12ee2d8: stur            x4, [fp, #-8]
    // 0x12ee2dc: CheckStackOverflow
    //     0x12ee2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ee2e0: cmp             SP, x16
    //     0x12ee2e4: b.ls            #0x12ee570
    // 0x12ee2e8: LoadField: r1 = r10->field_7
    //     0x12ee2e8: ldur            x1, [x10, #7]
    // 0x12ee2ec: cmp             x1, #0
    // 0x12ee2f0: b.gt            #0x12ee318
    // 0x12ee2f4: cmp             w3, NULL
    // 0x12ee2f8: b.ne            #0x12ee308
    // 0x12ee2fc: r1 = Instance_BorderRadius
    //     0x12ee2fc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ee300: ldr             x1, [x1, #0x508]
    // 0x12ee304: b               #0x12ee30c
    // 0x12ee308: mov             x1, x3
    // 0x12ee30c: r0 = toRRect()
    //     0x12ee30c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ee310: mov             x4, x0
    // 0x12ee314: b               #0x12ee3a8
    // 0x12ee318: mov             x1, x2
    // 0x12ee31c: r0 = center()
    //     0x12ee31c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12ee320: ldur            x1, [fp, #-0x38]
    // 0x12ee324: stur            x0, [fp, #-0x40]
    // 0x12ee328: r0 = shortestSide()
    //     0x12ee328: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12ee32c: mov             v1.16b, v0.16b
    // 0x12ee330: d0 = 2.000000
    //     0x12ee330: fmov            d0, #2.00000000
    // 0x12ee334: fdiv            d2, d1, d0
    // 0x12ee338: fmul            d1, d2, d0
    // 0x12ee33c: stur            d1, [fp, #-0x50]
    // 0x12ee340: r0 = Rect()
    //     0x12ee340: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12ee344: mov             x1, x0
    // 0x12ee348: ldur            x2, [fp, #-0x40]
    // 0x12ee34c: ldur            d0, [fp, #-0x50]
    // 0x12ee350: ldur            d1, [fp, #-0x50]
    // 0x12ee354: stur            x0, [fp, #-0x40]
    // 0x12ee358: r0 = Rect.fromCenter()
    //     0x12ee358: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0x12ee35c: ldur            x0, [fp, #-0x38]
    // 0x12ee360: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12ee360: ldur            d0, [x0, #0x17]
    // 0x12ee364: LoadField: d1 = r0->field_7
    //     0x12ee364: ldur            d1, [x0, #7]
    // 0x12ee368: fsub            d2, d0, d1
    // 0x12ee36c: stur            d2, [fp, #-0x50]
    // 0x12ee370: r0 = Radius()
    //     0x12ee370: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee374: ldur            d0, [fp, #-0x50]
    // 0x12ee378: stur            x0, [fp, #-0x38]
    // 0x12ee37c: StoreField: r0->field_7 = d0
    //     0x12ee37c: stur            d0, [x0, #7]
    // 0x12ee380: StoreField: r0->field_f = d0
    //     0x12ee380: stur            d0, [x0, #0xf]
    // 0x12ee384: r1 = <RRect>
    //     0x12ee384: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12ee388: ldr             x1, [x1, #0x108]
    // 0x12ee38c: r0 = RRect()
    //     0x12ee38c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12ee390: mov             x1, x0
    // 0x12ee394: ldur            x2, [fp, #-0x40]
    // 0x12ee398: ldur            x3, [fp, #-0x38]
    // 0x12ee39c: stur            x0, [fp, #-0x38]
    // 0x12ee3a0: r0 = RRect.fromRectAndRadius()
    //     0x12ee3a0: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x12ee3a4: ldur            x4, [fp, #-0x38]
    // 0x12ee3a8: ldur            x0, [fp, #-0x28]
    // 0x12ee3ac: ldur            x1, [fp, #-0x18]
    // 0x12ee3b0: ldur            x2, [fp, #-0x10]
    // 0x12ee3b4: ldur            x3, [fp, #-8]
    // 0x12ee3b8: stur            x4, [fp, #-0x38]
    // 0x12ee3bc: r16 = 136
    //     0x12ee3bc: mov             x16, #0x88
    // 0x12ee3c0: stp             x16, NULL, [SP]
    // 0x12ee3c4: r0 = ByteData()
    //     0x12ee3c4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ee3c8: stur            x0, [fp, #-0x40]
    // 0x12ee3cc: r0 = Paint()
    //     0x12ee3cc: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ee3d0: mov             x3, x0
    // 0x12ee3d4: ldur            x0, [fp, #-0x40]
    // 0x12ee3d8: stur            x3, [fp, #-0x48]
    // 0x12ee3dc: StoreField: r3->field_7 = r0
    //     0x12ee3dc: stur            w0, [x3, #7]
    // 0x12ee3e0: mov             x1, x3
    // 0x12ee3e4: ldur            x2, [fp, #-0x30]
    // 0x12ee3e8: r0 = color=()
    //     0x12ee3e8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ee3ec: ldur            x0, [fp, #-0x18]
    // 0x12ee3f0: LoadField: d0 = r0->field_b
    //     0x12ee3f0: ldur            d0, [x0, #0xb]
    // 0x12ee3f4: stur            d0, [fp, #-0xa8]
    // 0x12ee3f8: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12ee3f8: ldur            d1, [x0, #0x17]
    // 0x12ee3fc: d2 = 1.000000
    //     0x12ee3fc: fmov            d2, #1.00000000
    // 0x12ee400: fadd            d3, d1, d2
    // 0x12ee404: stur            d3, [fp, #-0xa0]
    // 0x12ee408: d1 = 2.000000
    //     0x12ee408: fmov            d1, #2.00000000
    // 0x12ee40c: fdiv            d4, d3, d1
    // 0x12ee410: fsub            d5, d2, d4
    // 0x12ee414: fmul            d4, d0, d5
    // 0x12ee418: ldur            x0, [fp, #-8]
    // 0x12ee41c: stur            d4, [fp, #-0x98]
    // 0x12ee420: LoadField: d5 = r0->field_b
    //     0x12ee420: ldur            d5, [x0, #0xb]
    // 0x12ee424: stur            d5, [fp, #-0x90]
    // 0x12ee428: ArrayLoad: d6 = r0[0]  ; List_8
    //     0x12ee428: ldur            d6, [x0, #0x17]
    // 0x12ee42c: fadd            d7, d6, d2
    // 0x12ee430: stur            d7, [fp, #-0x88]
    // 0x12ee434: fdiv            d6, d7, d1
    // 0x12ee438: fsub            d8, d2, d6
    // 0x12ee43c: fmul            d6, d5, d8
    // 0x12ee440: ldur            x0, [fp, #-0x10]
    // 0x12ee444: stur            d6, [fp, #-0x80]
    // 0x12ee448: LoadField: d8 = r0->field_b
    //     0x12ee448: ldur            d8, [x0, #0xb]
    // 0x12ee44c: stur            d8, [fp, #-0x78]
    // 0x12ee450: ArrayLoad: d9 = r0[0]  ; List_8
    //     0x12ee450: ldur            d9, [x0, #0x17]
    // 0x12ee454: fadd            d10, d9, d2
    // 0x12ee458: stur            d10, [fp, #-0x70]
    // 0x12ee45c: fdiv            d9, d10, d1
    // 0x12ee460: fsub            d11, d2, d9
    // 0x12ee464: fmul            d9, d8, d11
    // 0x12ee468: ldur            x0, [fp, #-0x28]
    // 0x12ee46c: stur            d9, [fp, #-0x68]
    // 0x12ee470: LoadField: d11 = r0->field_b
    //     0x12ee470: ldur            d11, [x0, #0xb]
    // 0x12ee474: stur            d11, [fp, #-0x60]
    // 0x12ee478: ArrayLoad: d12 = r0[0]  ; List_8
    //     0x12ee478: ldur            d12, [x0, #0x17]
    // 0x12ee47c: fadd            d13, d12, d2
    // 0x12ee480: stur            d13, [fp, #-0x58]
    // 0x12ee484: fdiv            d12, d13, d1
    // 0x12ee488: fsub            d14, d2, d12
    // 0x12ee48c: fmul            d2, d11, d14
    // 0x12ee490: stur            d2, [fp, #-0x50]
    // 0x12ee494: r0 = EdgeInsets()
    //     0x12ee494: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12ee498: ldur            d0, [fp, #-0x98]
    // 0x12ee49c: StoreField: r0->field_7 = d0
    //     0x12ee49c: stur            d0, [x0, #7]
    // 0x12ee4a0: ldur            d0, [fp, #-0x80]
    // 0x12ee4a4: StoreField: r0->field_f = d0
    //     0x12ee4a4: stur            d0, [x0, #0xf]
    // 0x12ee4a8: ldur            d0, [fp, #-0x68]
    // 0x12ee4ac: ArrayStore: r0[0] = d0  ; List_8
    //     0x12ee4ac: stur            d0, [x0, #0x17]
    // 0x12ee4b0: ldur            d0, [fp, #-0x50]
    // 0x12ee4b4: StoreField: r0->field_1f = d0
    //     0x12ee4b4: stur            d0, [x0, #0x1f]
    // 0x12ee4b8: mov             x1, x0
    // 0x12ee4bc: ldur            x2, [fp, #-0x38]
    // 0x12ee4c0: r0 = deflateRRect()
    //     0x12ee4c0: bl              #0x12ee830  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRRect
    // 0x12ee4c4: ldur            d0, [fp, #-0xa8]
    // 0x12ee4c8: ldur            d1, [fp, #-0xa0]
    // 0x12ee4cc: stur            x0, [fp, #-8]
    // 0x12ee4d0: fmul            d2, d0, d1
    // 0x12ee4d4: d0 = 2.000000
    //     0x12ee4d4: fmov            d0, #2.00000000
    // 0x12ee4d8: fdiv            d1, d2, d0
    // 0x12ee4dc: ldur            d2, [fp, #-0x90]
    // 0x12ee4e0: ldur            d3, [fp, #-0x88]
    // 0x12ee4e4: stur            d1, [fp, #-0x98]
    // 0x12ee4e8: fmul            d4, d2, d3
    // 0x12ee4ec: fdiv            d2, d4, d0
    // 0x12ee4f0: ldur            d3, [fp, #-0x78]
    // 0x12ee4f4: ldur            d4, [fp, #-0x70]
    // 0x12ee4f8: stur            d2, [fp, #-0x80]
    // 0x12ee4fc: fmul            d5, d3, d4
    // 0x12ee500: fdiv            d3, d5, d0
    // 0x12ee504: ldur            d4, [fp, #-0x60]
    // 0x12ee508: ldur            d5, [fp, #-0x58]
    // 0x12ee50c: stur            d3, [fp, #-0x68]
    // 0x12ee510: fmul            d6, d4, d5
    // 0x12ee514: fdiv            d4, d6, d0
    // 0x12ee518: stur            d4, [fp, #-0x50]
    // 0x12ee51c: r0 = EdgeInsets()
    //     0x12ee51c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12ee520: ldur            d0, [fp, #-0x98]
    // 0x12ee524: StoreField: r0->field_7 = d0
    //     0x12ee524: stur            d0, [x0, #7]
    // 0x12ee528: ldur            d0, [fp, #-0x80]
    // 0x12ee52c: StoreField: r0->field_f = d0
    //     0x12ee52c: stur            d0, [x0, #0xf]
    // 0x12ee530: ldur            d0, [fp, #-0x68]
    // 0x12ee534: ArrayStore: r0[0] = d0  ; List_8
    //     0x12ee534: stur            d0, [x0, #0x17]
    // 0x12ee538: ldur            d0, [fp, #-0x50]
    // 0x12ee53c: StoreField: r0->field_1f = d0
    //     0x12ee53c: stur            d0, [x0, #0x1f]
    // 0x12ee540: mov             x1, x0
    // 0x12ee544: ldur            x2, [fp, #-0x38]
    // 0x12ee548: r0 = inflateRRect()
    //     0x12ee548: bl              #0x12ee578  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::inflateRRect
    // 0x12ee54c: ldur            x1, [fp, #-0x20]
    // 0x12ee550: mov             x2, x0
    // 0x12ee554: ldur            x3, [fp, #-8]
    // 0x12ee558: ldur            x5, [fp, #-0x48]
    // 0x12ee55c: r0 = drawDRRect()
    //     0x12ee55c: bl              #0x12ecee0  ; [dart:ui] _NativeCanvas::drawDRRect
    // 0x12ee560: r0 = Null
    //     0x12ee560: mov             x0, NULL
    // 0x12ee564: LeaveFrame
    //     0x12ee564: mov             SP, fp
    //     0x12ee568: ldp             fp, lr, [SP], #0x10
    // 0x12ee56c: ret
    //     0x12ee56c: ret             
    // 0x12ee570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ee570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ee574: b               #0x12ee2e8
  }
  static _ _paintUniformBorderWithCircle(/* No info */) {
    // ** addr: 0x12f0dec, size: 0x94
    // 0x12f0dec: EnterFrame
    //     0x12f0dec: stp             fp, lr, [SP, #-0x10]!
    //     0x12f0df0: mov             fp, SP
    // 0x12f0df4: AllocStack(0x20)
    //     0x12f0df4: sub             SP, SP, #0x20
    // 0x12f0df8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x12f0df8: mov             x0, x3
    //     0x12f0dfc: stur            x3, [fp, #-0x18]
    //     0x12f0e00: mov             x3, x1
    //     0x12f0e04: stur            x1, [fp, #-8]
    //     0x12f0e08: stur            x2, [fp, #-0x10]
    // 0x12f0e0c: CheckStackOverflow
    //     0x12f0e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f0e10: cmp             SP, x16
    //     0x12f0e14: b.ls            #0x12f0e78
    // 0x12f0e18: mov             x1, x2
    // 0x12f0e1c: r0 = shortestSide()
    //     0x12f0e1c: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12f0e20: ldur            x0, [fp, #-0x18]
    // 0x12f0e24: LoadField: d1 = r0->field_b
    //     0x12f0e24: ldur            d1, [x0, #0xb]
    // 0x12f0e28: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12f0e28: ldur            d2, [x0, #0x17]
    // 0x12f0e2c: fmul            d3, d1, d2
    // 0x12f0e30: fadd            d1, d0, d3
    // 0x12f0e34: d0 = 2.000000
    //     0x12f0e34: fmov            d0, #2.00000000
    // 0x12f0e38: fdiv            d2, d1, d0
    // 0x12f0e3c: ldur            x1, [fp, #-0x10]
    // 0x12f0e40: stur            d2, [fp, #-0x20]
    // 0x12f0e44: r0 = center()
    //     0x12f0e44: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12f0e48: ldur            x1, [fp, #-0x18]
    // 0x12f0e4c: stur            x0, [fp, #-0x10]
    // 0x12f0e50: r0 = toPaint()
    //     0x12f0e50: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12f0e54: ldur            x1, [fp, #-8]
    // 0x12f0e58: ldur            x2, [fp, #-0x10]
    // 0x12f0e5c: ldur            d0, [fp, #-0x20]
    // 0x12f0e60: mov             x3, x0
    // 0x12f0e64: r0 = drawCircle()
    //     0x12f0e64: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12f0e68: r0 = Null
    //     0x12f0e68: mov             x0, NULL
    // 0x12f0e6c: LeaveFrame
    //     0x12f0e6c: mov             SP, fp
    //     0x12f0e70: ldp             fp, lr, [SP], #0x10
    // 0x12f0e74: ret
    //     0x12f0e74: ret             
    // 0x12f0e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f0e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f0e7c: b               #0x12f0e18
  }
  static _ _paintUniformBorderWithRectangle(/* No info */) {
    // ** addr: 0x12f0e80, size: 0x80
    // 0x12f0e80: EnterFrame
    //     0x12f0e80: stp             fp, lr, [SP, #-0x10]!
    //     0x12f0e84: mov             fp, SP
    // 0x12f0e88: AllocStack(0x10)
    //     0x12f0e88: sub             SP, SP, #0x10
    // 0x12f0e8c: d0 = 2.000000
    //     0x12f0e8c: fmov            d0, #2.00000000
    // 0x12f0e90: stur            x1, [fp, #-8]
    // 0x12f0e94: mov             x16, x2
    // 0x12f0e98: mov             x2, x1
    // 0x12f0e9c: mov             x1, x16
    // 0x12f0ea0: mov             x0, x3
    // 0x12f0ea4: stur            x3, [fp, #-0x10]
    // 0x12f0ea8: CheckStackOverflow
    //     0x12f0ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f0eac: cmp             SP, x16
    //     0x12f0eb0: b.ls            #0x12f0ef8
    // 0x12f0eb4: LoadField: d1 = r0->field_b
    //     0x12f0eb4: ldur            d1, [x0, #0xb]
    // 0x12f0eb8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12f0eb8: ldur            d2, [x0, #0x17]
    // 0x12f0ebc: fmul            d3, d1, d2
    // 0x12f0ec0: fdiv            d1, d3, d0
    // 0x12f0ec4: mov             v0.16b, v1.16b
    // 0x12f0ec8: r0 = inflate()
    //     0x12f0ec8: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x12f0ecc: ldur            x1, [fp, #-0x10]
    // 0x12f0ed0: stur            x0, [fp, #-0x10]
    // 0x12f0ed4: r0 = toPaint()
    //     0x12f0ed4: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12f0ed8: ldur            x1, [fp, #-8]
    // 0x12f0edc: ldur            x2, [fp, #-0x10]
    // 0x12f0ee0: mov             x3, x0
    // 0x12f0ee4: r0 = drawRect()
    //     0x12f0ee4: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12f0ee8: r0 = Null
    //     0x12f0ee8: mov             x0, NULL
    // 0x12f0eec: LeaveFrame
    //     0x12f0eec: mov             SP, fp
    //     0x12f0ef0: ldp             fp, lr, [SP], #0x10
    // 0x12f0ef4: ret
    //     0x12f0ef4: ret             
    // 0x12f0ef8: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f0ef8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f0efc: b               #0x12f0eb4
  }
  static _ _paintUniformBorderWithRadius(/* No info */) {
    // ** addr: 0x12f0f00, size: 0x154
    // 0x12f0f00: EnterFrame
    //     0x12f0f00: stp             fp, lr, [SP, #-0x10]!
    //     0x12f0f04: mov             fp, SP
    // 0x12f0f08: AllocStack(0x50)
    //     0x12f0f08: sub             SP, SP, #0x50
    // 0x12f0f0c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r1, fp-0x20 */)
    //     0x12f0f0c: mov             x0, x1
    //     0x12f0f10: stur            x1, [fp, #-8]
    //     0x12f0f14: mov             x1, x5
    //     0x12f0f18: stur            x2, [fp, #-0x10]
    //     0x12f0f1c: stur            x3, [fp, #-0x18]
    //     0x12f0f20: stur            x5, [fp, #-0x20]
    // 0x12f0f24: CheckStackOverflow
    //     0x12f0f24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f0f28: cmp             SP, x16
    //     0x12f0f2c: b.ls            #0x12f104c
    // 0x12f0f30: r16 = 136
    //     0x12f0f30: mov             x16, #0x88
    // 0x12f0f34: stp             x16, NULL, [SP]
    // 0x12f0f38: r0 = ByteData()
    //     0x12f0f38: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f0f3c: stur            x0, [fp, #-0x28]
    // 0x12f0f40: r0 = Paint()
    //     0x12f0f40: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f0f44: mov             x3, x0
    // 0x12f0f48: ldur            x0, [fp, #-0x28]
    // 0x12f0f4c: stur            x3, [fp, #-0x30]
    // 0x12f0f50: StoreField: r3->field_7 = r0
    //     0x12f0f50: stur            w0, [x3, #7]
    // 0x12f0f54: ldur            x4, [fp, #-0x18]
    // 0x12f0f58: LoadField: r2 = r4->field_7
    //     0x12f0f58: ldur            w2, [x4, #7]
    // 0x12f0f5c: DecompressPointer r2
    //     0x12f0f5c: add             x2, x2, HEAP, lsl #32
    // 0x12f0f60: mov             x1, x3
    // 0x12f0f64: r0 = color=()
    //     0x12f0f64: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f0f68: ldur            x0, [fp, #-0x18]
    // 0x12f0f6c: LoadField: d0 = r0->field_b
    //     0x12f0f6c: ldur            d0, [x0, #0xb]
    // 0x12f0f70: stur            d0, [fp, #-0x38]
    // 0x12f0f74: d1 = 0.000000
    //     0x12f0f74: eor             v1.16b, v1.16b, v1.16b
    // 0x12f0f78: fcmp            d0, d1
    // 0x12f0f7c: b.ne            #0x12f0fc0
    // 0x12f0f80: ldur            x0, [fp, #-0x28]
    // 0x12f0f84: r1 = 1
    //     0x12f0f84: mov             x1, #1
    // 0x12f0f88: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12f0f88: ldur            w2, [x0, #0x17]
    // 0x12f0f8c: DecompressPointer r2
    //     0x12f0f8c: add             x2, x2, HEAP, lsl #32
    // 0x12f0f90: LoadField: r0 = r2->field_7
    //     0x12f0f90: ldur            x0, [x2, #7]
    // 0x12f0f94: str             w1, [x0, #0x1c]
    // 0x12f0f98: LoadField: r0 = r2->field_7
    //     0x12f0f98: ldur            x0, [x2, #7]
    // 0x12f0f9c: str             wzr, [x0, #0x20]
    // 0x12f0fa0: ldur            x1, [fp, #-0x20]
    // 0x12f0fa4: ldur            x2, [fp, #-0x10]
    // 0x12f0fa8: r0 = toRRect()
    //     0x12f0fa8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12f0fac: ldur            x1, [fp, #-8]
    // 0x12f0fb0: mov             x2, x0
    // 0x12f0fb4: ldur            x3, [fp, #-0x30]
    // 0x12f0fb8: r0 = drawRRect()
    //     0x12f0fb8: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12f0fbc: b               #0x12f103c
    // 0x12f0fc0: ldur            x1, [fp, #-0x20]
    // 0x12f0fc4: ldur            x2, [fp, #-0x10]
    // 0x12f0fc8: r0 = toRRect()
    //     0x12f0fc8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12f0fcc: mov             x2, x0
    // 0x12f0fd0: ldur            x0, [fp, #-0x18]
    // 0x12f0fd4: stur            x2, [fp, #-0x10]
    // 0x12f0fd8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f0fd8: ldur            d0, [x0, #0x17]
    // 0x12f0fdc: d1 = 1.000000
    //     0x12f0fdc: fmov            d1, #1.00000000
    // 0x12f0fe0: fadd            d2, d0, d1
    // 0x12f0fe4: stur            d2, [fp, #-0x40]
    // 0x12f0fe8: d3 = 2.000000
    //     0x12f0fe8: fmov            d3, #2.00000000
    // 0x12f0fec: fdiv            d0, d2, d3
    // 0x12f0ff0: fsub            d4, d1, d0
    // 0x12f0ff4: ldur            d1, [fp, #-0x38]
    // 0x12f0ff8: fmul            d0, d1, d4
    // 0x12f0ffc: mov             x1, x2
    // 0x12f1000: r0 = deflate()
    //     0x12f1000: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0x12f1004: ldur            d1, [fp, #-0x38]
    // 0x12f1008: ldur            d0, [fp, #-0x40]
    // 0x12f100c: stur            x0, [fp, #-0x18]
    // 0x12f1010: fmul            d2, d1, d0
    // 0x12f1014: d0 = 2.000000
    //     0x12f1014: fmov            d0, #2.00000000
    // 0x12f1018: fdiv            d1, d2, d0
    // 0x12f101c: ldur            x1, [fp, #-0x10]
    // 0x12f1020: mov             v0.16b, v1.16b
    // 0x12f1024: r0 = inflate()
    //     0x12f1024: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12f1028: ldur            x1, [fp, #-8]
    // 0x12f102c: mov             x2, x0
    // 0x12f1030: ldur            x3, [fp, #-0x18]
    // 0x12f1034: ldur            x5, [fp, #-0x30]
    // 0x12f1038: r0 = drawDRRect()
    //     0x12f1038: bl              #0x12ecee0  ; [dart:ui] _NativeCanvas::drawDRRect
    // 0x12f103c: r0 = Null
    //     0x12f103c: mov             x0, NULL
    // 0x12f1040: LeaveFrame
    //     0x12f1040: mov             SP, fp
    //     0x12f1044: ldp             fp, lr, [SP], #0x10
    // 0x12f1048: ret
    //     0x12f1048: ret             
    // 0x12f104c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f104c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1050: b               #0x12f0f30
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300d8c, size: 0xcc
    // 0x1300d8c: EnterFrame
    //     0x1300d8c: stp             fp, lr, [SP, #-0x10]!
    //     0x1300d90: mov             fp, SP
    // 0x1300d94: AllocStack(0x40)
    //     0x1300d94: sub             SP, SP, #0x40
    // 0x1300d98: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x1300d98: stur            x2, [fp, #-8]
    // 0x1300d9c: CheckStackOverflow
    //     0x1300d9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1300da0: cmp             SP, x16
    //     0x1300da4: b.ls            #0x1300e4c
    // 0x1300da8: r0 = _NativePath()
    //     0x1300da8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1300dac: mov             x1, x0
    // 0x1300db0: stur            x0, [fp, #-0x10]
    // 0x1300db4: r0 = __constructor$Method$FfiNative()
    //     0x1300db4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1300db8: ldur            x0, [fp, #-8]
    // 0x1300dbc: LoadField: d0 = r0->field_7
    //     0x1300dbc: ldur            d0, [x0, #7]
    // 0x1300dc0: stur            d0, [fp, #-0x38]
    // 0x1300dc4: LoadField: d1 = r0->field_f
    //     0x1300dc4: ldur            d1, [x0, #0xf]
    // 0x1300dc8: stur            d1, [fp, #-0x30]
    // 0x1300dcc: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x1300dcc: ldur            d2, [x0, #0x17]
    // 0x1300dd0: stur            d2, [fp, #-0x28]
    // 0x1300dd4: LoadField: d3 = r0->field_1f
    //     0x1300dd4: ldur            d3, [x0, #0x1f]
    // 0x1300dd8: ldur            x0, [fp, #-0x10]
    // 0x1300ddc: stur            d3, [fp, #-0x20]
    // 0x1300de0: LoadField: r1 = r0->field_7
    //     0x1300de0: ldur            w1, [x0, #7]
    // 0x1300de4: DecompressPointer r1
    //     0x1300de4: add             x1, x1, HEAP, lsl #32
    // 0x1300de8: cmp             w1, NULL
    // 0x1300dec: b.eq            #0x1300e54
    // 0x1300df0: LoadField: r2 = r1->field_7
    //     0x1300df0: ldur            x2, [x1, #7]
    // 0x1300df4: ldr             x1, [x2]
    // 0x1300df8: cbz             x1, #0x1300e3c
    // 0x1300dfc: mov             x2, x1
    // 0x1300e00: stur            x2, [fp, #-0x18]
    // 0x1300e04: r1 = <Never>
    //     0x1300e04: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300e08: r0 = Pointer()
    //     0x1300e08: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300e0c: mov             x1, x0
    // 0x1300e10: ldur            x0, [fp, #-0x18]
    // 0x1300e14: StoreField: r1->field_7 = r0
    //     0x1300e14: stur            x0, [x1, #7]
    // 0x1300e18: ldur            d0, [fp, #-0x38]
    // 0x1300e1c: ldur            d1, [fp, #-0x30]
    // 0x1300e20: ldur            d2, [fp, #-0x28]
    // 0x1300e24: ldur            d3, [fp, #-0x20]
    // 0x1300e28: r0 = __addRect$Method$FfiNative()
    //     0x1300e28: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0x1300e2c: ldur            x0, [fp, #-0x10]
    // 0x1300e30: LeaveFrame
    //     0x1300e30: mov             SP, fp
    //     0x1300e34: ldp             fp, lr, [SP], #0x10
    // 0x1300e38: ret
    //     0x1300e38: ret             
    // 0x1300e3c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300e3c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300e40: str             x16, [SP]
    // 0x1300e44: r0 = _throwNew()
    //     0x1300e44: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300e48: brk             #0
    // 0x1300e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300e50: b               #0x1300da8
    // 0x1300e54: r0 = NullErrorSharedWithFPURegs()
    //     0x1300e54: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 3013, size: 0x18, field offset: 0x8
//   const constructor, 
class Border extends BoxBorder {

  BorderSide field_8;
  BorderSide field_c;
  BorderSide field_10;
  BorderSide field_14;

  factory _ Border.all(/* No info */) {
    // ** addr: 0x8a7250, size: 0xf8
    // 0x8a7250: EnterFrame
    //     0x8a7250: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7254: mov             fp, SP
    // 0x8a7258: AllocStack(0x18)
    //     0x8a7258: sub             SP, SP, #0x18
    // 0x8a725c: SetupParameters({dynamic color = Instance_Color /* r2, fp-0x8 */, _Double width = 1.000000 /* d0, fp-0x18 */})
    //     0x8a725c: ldur            w0, [x4, #0x13]
    //     0x8a7260: ldur            w1, [x4, #0x1f]
    //     0x8a7264: add             x1, x1, HEAP, lsl #32
    //     0x8a7268: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0x8a726c: cmp             w1, w16
    //     0x8a7270: b.ne            #0x8a7294
    //     0x8a7274: ldur            w1, [x4, #0x23]
    //     0x8a7278: add             x1, x1, HEAP, lsl #32
    //     0x8a727c: sub             w2, w0, w1
    //     0x8a7280: add             x1, fp, w2, sxtw #2
    //     0x8a7284: ldr             x1, [x1, #8]
    //     0x8a7288: mov             x2, x1
    //     0x8a728c: mov             x1, #1
    //     0x8a7290: b               #0x8a72a0
    //     0x8a7294: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8a7298: ldr             x2, [x2, #0x948]
    //     0x8a729c: mov             x1, #0
    //     0x8a72a0: stur            x2, [fp, #-8]
    //     0x8a72a4: lsl             x3, x1, #1
    //     0x8a72a8: lsl             w1, w3, #1
    //     0x8a72ac: add             w3, w1, #8
    //     0x8a72b0: add             x16, x4, w3, sxtw #1
    //     0x8a72b4: ldur            w5, [x16, #0xf]
    //     0x8a72b8: add             x5, x5, HEAP, lsl #32
    //     0x8a72bc: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    //     0x8a72c0: cmp             w5, w16
    //     0x8a72c4: b.ne            #0x8a72ec
    //     0x8a72c8: add             w3, w1, #0xa
    //     0x8a72cc: add             x16, x4, w3, sxtw #1
    //     0x8a72d0: ldur            w1, [x16, #0xf]
    //     0x8a72d4: add             x1, x1, HEAP, lsl #32
    //     0x8a72d8: sub             w3, w0, w1
    //     0x8a72dc: add             x0, fp, w3, sxtw #2
    //     0x8a72e0: ldr             x0, [x0, #8]
    //     0x8a72e4: ldur            d0, [x0, #7]
    //     0x8a72e8: b               #0x8a72f0
    //     0x8a72ec: fmov            d0, #1.00000000
    //     0x8a72f0: stur            d0, [fp, #-0x18]
    // 0x8a72f4: r0 = BorderSide()
    //     0x8a72f4: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8a72f8: mov             x1, x0
    // 0x8a72fc: ldur            x0, [fp, #-8]
    // 0x8a7300: stur            x1, [fp, #-0x10]
    // 0x8a7304: StoreField: r1->field_7 = r0
    //     0x8a7304: stur            w0, [x1, #7]
    // 0x8a7308: ldur            d0, [fp, #-0x18]
    // 0x8a730c: StoreField: r1->field_b = d0
    //     0x8a730c: stur            d0, [x1, #0xb]
    // 0x8a7310: r0 = Instance_BorderStyle
    //     0x8a7310: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x8a7314: ldr             x0, [x0, #0xdc8]
    // 0x8a7318: StoreField: r1->field_13 = r0
    //     0x8a7318: stur            w0, [x1, #0x13]
    // 0x8a731c: d0 = -1.000000
    //     0x8a731c: fmov            d0, #-1.00000000
    // 0x8a7320: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a7320: stur            d0, [x1, #0x17]
    // 0x8a7324: r0 = Border()
    //     0x8a7324: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0x8a7328: ldur            x1, [fp, #-0x10]
    // 0x8a732c: StoreField: r0->field_7 = r1
    //     0x8a732c: stur            w1, [x0, #7]
    // 0x8a7330: StoreField: r0->field_b = r1
    //     0x8a7330: stur            w1, [x0, #0xb]
    // 0x8a7334: StoreField: r0->field_f = r1
    //     0x8a7334: stur            w1, [x0, #0xf]
    // 0x8a7338: StoreField: r0->field_13 = r1
    //     0x8a7338: stur            w1, [x0, #0x13]
    // 0x8a733c: LeaveFrame
    //     0x8a733c: mov             SP, fp
    //     0x8a7340: ldp             fp, lr, [SP], #0x10
    // 0x8a7344: ret
    //     0x8a7344: ret             
  }
  get _ isUniform(/* No info */) {
    // ** addr: 0xe37054, size: 0x108
    // 0xe37054: EnterFrame
    //     0xe37054: stp             fp, lr, [SP, #-0x10]!
    //     0xe37058: mov             fp, SP
    // 0xe3705c: AllocStack(0x8)
    //     0xe3705c: sub             SP, SP, #8
    // 0xe37060: SetupParameters(Border this /* r1 => r0, fp-0x8 */)
    //     0xe37060: mov             x0, x1
    //     0xe37064: stur            x1, [fp, #-8]
    // 0xe37068: CheckStackOverflow
    //     0xe37068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe3706c: cmp             SP, x16
    //     0xe37070: b.ls            #0xe37154
    // 0xe37074: mov             x1, x0
    // 0xe37078: r0 = _colorIsUniform()
    //     0xe37078: bl              #0xe3715c  ; [package:flutter/src/painting/box_border.dart] Border::_colorIsUniform
    // 0xe3707c: tbnz            w0, #4, #0xe37144
    // 0xe37080: ldur            x1, [fp, #-8]
    // 0xe37084: LoadField: r2 = r1->field_7
    //     0xe37084: ldur            w2, [x1, #7]
    // 0xe37088: DecompressPointer r2
    //     0xe37088: add             x2, x2, HEAP, lsl #32
    // 0xe3708c: LoadField: d0 = r2->field_b
    //     0xe3708c: ldur            d0, [x2, #0xb]
    // 0xe37090: LoadField: r3 = r1->field_13
    //     0xe37090: ldur            w3, [x1, #0x13]
    // 0xe37094: DecompressPointer r3
    //     0xe37094: add             x3, x3, HEAP, lsl #32
    // 0xe37098: LoadField: d1 = r3->field_b
    //     0xe37098: ldur            d1, [x3, #0xb]
    // 0xe3709c: fcmp            d1, d0
    // 0xe370a0: b.ne            #0xe37144
    // 0xe370a4: LoadField: r4 = r1->field_f
    //     0xe370a4: ldur            w4, [x1, #0xf]
    // 0xe370a8: DecompressPointer r4
    //     0xe370a8: add             x4, x4, HEAP, lsl #32
    // 0xe370ac: LoadField: d1 = r4->field_b
    //     0xe370ac: ldur            d1, [x4, #0xb]
    // 0xe370b0: fcmp            d1, d0
    // 0xe370b4: b.ne            #0xe37144
    // 0xe370b8: LoadField: r5 = r1->field_b
    //     0xe370b8: ldur            w5, [x1, #0xb]
    // 0xe370bc: DecompressPointer r5
    //     0xe370bc: add             x5, x5, HEAP, lsl #32
    // 0xe370c0: LoadField: d1 = r5->field_b
    //     0xe370c0: ldur            d1, [x5, #0xb]
    // 0xe370c4: fcmp            d1, d0
    // 0xe370c8: b.ne            #0xe37144
    // 0xe370cc: LoadField: r1 = r2->field_13
    //     0xe370cc: ldur            w1, [x2, #0x13]
    // 0xe370d0: DecompressPointer r1
    //     0xe370d0: add             x1, x1, HEAP, lsl #32
    // 0xe370d4: LoadField: r6 = r3->field_13
    //     0xe370d4: ldur            w6, [x3, #0x13]
    // 0xe370d8: DecompressPointer r6
    //     0xe370d8: add             x6, x6, HEAP, lsl #32
    // 0xe370dc: cmp             w6, w1
    // 0xe370e0: b.ne            #0xe37144
    // 0xe370e4: LoadField: r6 = r4->field_13
    //     0xe370e4: ldur            w6, [x4, #0x13]
    // 0xe370e8: DecompressPointer r6
    //     0xe370e8: add             x6, x6, HEAP, lsl #32
    // 0xe370ec: cmp             w6, w1
    // 0xe370f0: b.ne            #0xe37144
    // 0xe370f4: LoadField: r6 = r5->field_13
    //     0xe370f4: ldur            w6, [x5, #0x13]
    // 0xe370f8: DecompressPointer r6
    //     0xe370f8: add             x6, x6, HEAP, lsl #32
    // 0xe370fc: cmp             w6, w1
    // 0xe37100: b.ne            #0xe37144
    // 0xe37104: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xe37104: ldur            d0, [x2, #0x17]
    // 0xe37108: ArrayLoad: d1 = r3[0]  ; List_8
    //     0xe37108: ldur            d1, [x3, #0x17]
    // 0xe3710c: fcmp            d1, d0
    // 0xe37110: b.ne            #0xe37138
    // 0xe37114: ArrayLoad: d1 = r4[0]  ; List_8
    //     0xe37114: ldur            d1, [x4, #0x17]
    // 0xe37118: fcmp            d1, d0
    // 0xe3711c: b.ne            #0xe37138
    // 0xe37120: ArrayLoad: d1 = r5[0]  ; List_8
    //     0xe37120: ldur            d1, [x5, #0x17]
    // 0xe37124: fcmp            d1, d0
    // 0xe37128: r16 = true
    //     0xe37128: add             x16, NULL, #0x20  ; true
    // 0xe3712c: r17 = false
    //     0xe3712c: add             x17, NULL, #0x30  ; false
    // 0xe37130: csel            x1, x16, x17, eq
    // 0xe37134: b               #0xe3713c
    // 0xe37138: r1 = false
    //     0xe37138: add             x1, NULL, #0x30  ; false
    // 0xe3713c: mov             x0, x1
    // 0xe37140: b               #0xe37148
    // 0xe37144: r0 = false
    //     0xe37144: add             x0, NULL, #0x30  ; false
    // 0xe37148: LeaveFrame
    //     0xe37148: mov             SP, fp
    //     0xe3714c: ldp             fp, lr, [SP], #0x10
    // 0xe37150: ret
    //     0xe37150: ret             
    // 0xe37154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe37154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe37158: b               #0xe37074
  }
  get _ _colorIsUniform(/* No info */) {
    // ** addr: 0xe3715c, size: 0xe0
    // 0xe3715c: EnterFrame
    //     0xe3715c: stp             fp, lr, [SP, #-0x10]!
    //     0xe37160: mov             fp, SP
    // 0xe37164: AllocStack(0x20)
    //     0xe37164: sub             SP, SP, #0x20
    // 0xe37168: SetupParameters(Border this /* r1 => r1, fp-0x10 */)
    //     0xe37168: stur            x1, [fp, #-0x10]
    // 0xe3716c: CheckStackOverflow
    //     0xe3716c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe37170: cmp             SP, x16
    //     0xe37174: b.ls            #0xe37234
    // 0xe37178: LoadField: r0 = r1->field_7
    //     0xe37178: ldur            w0, [x1, #7]
    // 0xe3717c: DecompressPointer r0
    //     0xe3717c: add             x0, x0, HEAP, lsl #32
    // 0xe37180: LoadField: r2 = r0->field_7
    //     0xe37180: ldur            w2, [x0, #7]
    // 0xe37184: DecompressPointer r2
    //     0xe37184: add             x2, x2, HEAP, lsl #32
    // 0xe37188: stur            x2, [fp, #-8]
    // 0xe3718c: LoadField: r0 = r1->field_13
    //     0xe3718c: ldur            w0, [x1, #0x13]
    // 0xe37190: DecompressPointer r0
    //     0xe37190: add             x0, x0, HEAP, lsl #32
    // 0xe37194: LoadField: r3 = r0->field_7
    //     0xe37194: ldur            w3, [x0, #7]
    // 0xe37198: DecompressPointer r3
    //     0xe37198: add             x3, x3, HEAP, lsl #32
    // 0xe3719c: r0 = LoadClassIdInstr(r3)
    //     0xe3719c: ldur            x0, [x3, #-1]
    //     0xe371a0: ubfx            x0, x0, #0xc, #0x14
    // 0xe371a4: stp             x2, x3, [SP]
    // 0xe371a8: mov             lr, x0
    // 0xe371ac: ldr             lr, [x21, lr, lsl #3]
    // 0xe371b0: blr             lr
    // 0xe371b4: tbnz            w0, #4, #0xe37224
    // 0xe371b8: ldur            x1, [fp, #-0x10]
    // 0xe371bc: LoadField: r0 = r1->field_f
    //     0xe371bc: ldur            w0, [x1, #0xf]
    // 0xe371c0: DecompressPointer r0
    //     0xe371c0: add             x0, x0, HEAP, lsl #32
    // 0xe371c4: LoadField: r2 = r0->field_7
    //     0xe371c4: ldur            w2, [x0, #7]
    // 0xe371c8: DecompressPointer r2
    //     0xe371c8: add             x2, x2, HEAP, lsl #32
    // 0xe371cc: r0 = LoadClassIdInstr(r2)
    //     0xe371cc: ldur            x0, [x2, #-1]
    //     0xe371d0: ubfx            x0, x0, #0xc, #0x14
    // 0xe371d4: ldur            x16, [fp, #-8]
    // 0xe371d8: stp             x16, x2, [SP]
    // 0xe371dc: mov             lr, x0
    // 0xe371e0: ldr             lr, [x21, lr, lsl #3]
    // 0xe371e4: blr             lr
    // 0xe371e8: tbnz            w0, #4, #0xe37224
    // 0xe371ec: ldur            x0, [fp, #-0x10]
    // 0xe371f0: LoadField: r1 = r0->field_b
    //     0xe371f0: ldur            w1, [x0, #0xb]
    // 0xe371f4: DecompressPointer r1
    //     0xe371f4: add             x1, x1, HEAP, lsl #32
    // 0xe371f8: LoadField: r0 = r1->field_7
    //     0xe371f8: ldur            w0, [x1, #7]
    // 0xe371fc: DecompressPointer r0
    //     0xe371fc: add             x0, x0, HEAP, lsl #32
    // 0xe37200: r1 = LoadClassIdInstr(r0)
    //     0xe37200: ldur            x1, [x0, #-1]
    //     0xe37204: ubfx            x1, x1, #0xc, #0x14
    // 0xe37208: ldur            x16, [fp, #-8]
    // 0xe3720c: stp             x16, x0, [SP]
    // 0xe37210: mov             x0, x1
    // 0xe37214: mov             lr, x0
    // 0xe37218: ldr             lr, [x21, lr, lsl #3]
    // 0xe3721c: blr             lr
    // 0xe37220: b               #0xe37228
    // 0xe37224: r0 = false
    //     0xe37224: add             x0, NULL, #0x30  ; false
    // 0xe37228: LeaveFrame
    //     0xe37228: mov             SP, fp
    //     0xe3722c: ldp             fp, lr, [SP], #0x10
    // 0xe37230: ret
    //     0xe37230: ret             
    // 0xe37234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe37234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe37238: b               #0xe37178
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ee680, size: 0x6c
    // 0x10ee680: EnterFrame
    //     0x10ee680: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee684: mov             fp, SP
    // 0x10ee688: mov             x16, x2
    // 0x10ee68c: mov             x2, x1
    // 0x10ee690: mov             x1, x16
    // 0x10ee694: CheckStackOverflow
    //     0x10ee694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee698: cmp             SP, x16
    //     0x10ee69c: b.ls            #0x10ee6e4
    // 0x10ee6a0: r0 = LoadClassIdInstr(r1)
    //     0x10ee6a0: ldur            x0, [x1, #-1]
    //     0x10ee6a4: ubfx            x0, x0, #0xc, #0x14
    // 0x10ee6a8: cmp             x0, #0xbc5
    // 0x10ee6ac: b.ne            #0x10ee6c0
    // 0x10ee6b0: r0 = lerp()
    //     0x10ee6b0: bl              #0x10ee6ec  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0x10ee6b4: LeaveFrame
    //     0x10ee6b4: mov             SP, fp
    //     0x10ee6b8: ldp             fp, lr, [SP], #0x10
    // 0x10ee6bc: ret
    //     0x10ee6bc: ret             
    // 0x10ee6c0: cmp             w1, NULL
    // 0x10ee6c4: b.ne            #0x10ee6d4
    // 0x10ee6c8: mov             x1, x2
    // 0x10ee6cc: r0 = scale()
    //     0x10ee6cc: bl              #0x12fd09c  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x10ee6d0: b               #0x10ee6d8
    // 0x10ee6d4: r0 = Null
    //     0x10ee6d4: mov             x0, NULL
    // 0x10ee6d8: LeaveFrame
    //     0x10ee6d8: mov             SP, fp
    //     0x10ee6dc: ldp             fp, lr, [SP], #0x10
    // 0x10ee6e0: ret
    //     0x10ee6e0: ret             
    // 0x10ee6e4: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee6e4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee6e8: b               #0x10ee6a0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x10ee6ec, size: 0x168
    // 0x10ee6ec: EnterFrame
    //     0x10ee6ec: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee6f0: mov             fp, SP
    // 0x10ee6f4: AllocStack(0x30)
    //     0x10ee6f4: sub             SP, SP, #0x30
    // 0x10ee6f8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x10ee6f8: mov             x3, x1
    //     0x10ee6fc: mov             x0, x2
    //     0x10ee700: mov             v1.16b, v0.16b
    //     0x10ee704: stur            x1, [fp, #-8]
    //     0x10ee708: stur            x2, [fp, #-0x10]
    //     0x10ee70c: stur            d0, [fp, #-0x30]
    // 0x10ee710: CheckStackOverflow
    //     0x10ee710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee714: cmp             SP, x16
    //     0x10ee718: b.ls            #0x10ee848
    // 0x10ee71c: cmp             w3, w0
    // 0x10ee720: b.ne            #0x10ee734
    // 0x10ee724: mov             x0, x3
    // 0x10ee728: LeaveFrame
    //     0x10ee728: mov             SP, fp
    //     0x10ee72c: ldp             fp, lr, [SP], #0x10
    // 0x10ee730: ret
    //     0x10ee730: ret             
    // 0x10ee734: cmp             w3, NULL
    // 0x10ee738: b.ne            #0x10ee75c
    // 0x10ee73c: cmp             w0, NULL
    // 0x10ee740: b.eq            #0x10ee850
    // 0x10ee744: mov             x1, x0
    // 0x10ee748: mov             v0.16b, v1.16b
    // 0x10ee74c: r0 = scale()
    //     0x10ee74c: bl              #0x12fd09c  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x10ee750: LeaveFrame
    //     0x10ee750: mov             SP, fp
    //     0x10ee754: ldp             fp, lr, [SP], #0x10
    // 0x10ee758: ret
    //     0x10ee758: ret             
    // 0x10ee75c: cmp             w0, NULL
    // 0x10ee760: b.ne            #0x10ee784
    // 0x10ee764: d0 = 1.000000
    //     0x10ee764: fmov            d0, #1.00000000
    // 0x10ee768: fsub            d2, d0, d1
    // 0x10ee76c: mov             x1, x3
    // 0x10ee770: mov             v0.16b, v2.16b
    // 0x10ee774: r0 = scale()
    //     0x10ee774: bl              #0x12fd09c  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x10ee778: LeaveFrame
    //     0x10ee778: mov             SP, fp
    //     0x10ee77c: ldp             fp, lr, [SP], #0x10
    // 0x10ee780: ret
    //     0x10ee780: ret             
    // 0x10ee784: LoadField: r1 = r3->field_7
    //     0x10ee784: ldur            w1, [x3, #7]
    // 0x10ee788: DecompressPointer r1
    //     0x10ee788: add             x1, x1, HEAP, lsl #32
    // 0x10ee78c: LoadField: r2 = r0->field_7
    //     0x10ee78c: ldur            w2, [x0, #7]
    // 0x10ee790: DecompressPointer r2
    //     0x10ee790: add             x2, x2, HEAP, lsl #32
    // 0x10ee794: mov             v0.16b, v1.16b
    // 0x10ee798: r0 = lerp()
    //     0x10ee798: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee79c: mov             x3, x0
    // 0x10ee7a0: ldur            x0, [fp, #-8]
    // 0x10ee7a4: stur            x3, [fp, #-0x18]
    // 0x10ee7a8: LoadField: r1 = r0->field_b
    //     0x10ee7a8: ldur            w1, [x0, #0xb]
    // 0x10ee7ac: DecompressPointer r1
    //     0x10ee7ac: add             x1, x1, HEAP, lsl #32
    // 0x10ee7b0: ldur            x4, [fp, #-0x10]
    // 0x10ee7b4: LoadField: r2 = r4->field_b
    //     0x10ee7b4: ldur            w2, [x4, #0xb]
    // 0x10ee7b8: DecompressPointer r2
    //     0x10ee7b8: add             x2, x2, HEAP, lsl #32
    // 0x10ee7bc: ldur            d0, [fp, #-0x30]
    // 0x10ee7c0: r0 = lerp()
    //     0x10ee7c0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee7c4: mov             x3, x0
    // 0x10ee7c8: ldur            x0, [fp, #-8]
    // 0x10ee7cc: stur            x3, [fp, #-0x20]
    // 0x10ee7d0: LoadField: r1 = r0->field_f
    //     0x10ee7d0: ldur            w1, [x0, #0xf]
    // 0x10ee7d4: DecompressPointer r1
    //     0x10ee7d4: add             x1, x1, HEAP, lsl #32
    // 0x10ee7d8: ldur            x4, [fp, #-0x10]
    // 0x10ee7dc: LoadField: r2 = r4->field_f
    //     0x10ee7dc: ldur            w2, [x4, #0xf]
    // 0x10ee7e0: DecompressPointer r2
    //     0x10ee7e0: add             x2, x2, HEAP, lsl #32
    // 0x10ee7e4: ldur            d0, [fp, #-0x30]
    // 0x10ee7e8: r0 = lerp()
    //     0x10ee7e8: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee7ec: mov             x3, x0
    // 0x10ee7f0: ldur            x0, [fp, #-8]
    // 0x10ee7f4: stur            x3, [fp, #-0x28]
    // 0x10ee7f8: LoadField: r1 = r0->field_13
    //     0x10ee7f8: ldur            w1, [x0, #0x13]
    // 0x10ee7fc: DecompressPointer r1
    //     0x10ee7fc: add             x1, x1, HEAP, lsl #32
    // 0x10ee800: ldur            x0, [fp, #-0x10]
    // 0x10ee804: LoadField: r2 = r0->field_13
    //     0x10ee804: ldur            w2, [x0, #0x13]
    // 0x10ee808: DecompressPointer r2
    //     0x10ee808: add             x2, x2, HEAP, lsl #32
    // 0x10ee80c: ldur            d0, [fp, #-0x30]
    // 0x10ee810: r0 = lerp()
    //     0x10ee810: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee814: stur            x0, [fp, #-8]
    // 0x10ee818: r0 = Border()
    //     0x10ee818: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0x10ee81c: ldur            x1, [fp, #-0x18]
    // 0x10ee820: StoreField: r0->field_7 = r1
    //     0x10ee820: stur            w1, [x0, #7]
    // 0x10ee824: ldur            x1, [fp, #-0x20]
    // 0x10ee828: StoreField: r0->field_b = r1
    //     0x10ee828: stur            w1, [x0, #0xb]
    // 0x10ee82c: ldur            x1, [fp, #-0x28]
    // 0x10ee830: StoreField: r0->field_f = r1
    //     0x10ee830: stur            w1, [x0, #0xf]
    // 0x10ee834: ldur            x1, [fp, #-8]
    // 0x10ee838: StoreField: r0->field_13 = r1
    //     0x10ee838: stur            w1, [x0, #0x13]
    // 0x10ee83c: LeaveFrame
    //     0x10ee83c: mov             SP, fp
    //     0x10ee840: ldp             fp, lr, [SP], #0x10
    // 0x10ee844: ret
    //     0x10ee844: ret             
    // 0x10ee848: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee848: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee84c: b               #0x10ee71c
    // 0x10ee850: r0 = NullCastErrorSharedWithFPURegs()
    //     0x10ee850: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f179c, size: 0x4c
    // 0x10f179c: EnterFrame
    //     0x10f179c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f17a0: mov             fp, SP
    // 0x10f17a4: CheckStackOverflow
    //     0x10f17a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f17a8: cmp             SP, x16
    //     0x10f17ac: b.ls            #0x10f17e0
    // 0x10f17b0: r0 = LoadClassIdInstr(r2)
    //     0x10f17b0: ldur            x0, [x2, #-1]
    //     0x10f17b4: ubfx            x0, x0, #0xc, #0x14
    // 0x10f17b8: cmp             x0, #0xbc5
    // 0x10f17bc: b.ne            #0x10f17d0
    // 0x10f17c0: r0 = lerp()
    //     0x10f17c0: bl              #0x10ee6ec  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0x10f17c4: LeaveFrame
    //     0x10f17c4: mov             SP, fp
    //     0x10f17c8: ldp             fp, lr, [SP], #0x10
    // 0x10f17cc: ret
    //     0x10f17cc: ret             
    // 0x10f17d0: r0 = lerpTo()
    //     0x10f17d0: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f17d4: LeaveFrame
    //     0x10f17d4: mov             SP, fp
    //     0x10f17d8: ldp             fp, lr, [SP], #0x10
    // 0x10f17dc: ret
    //     0x10f17dc: ret             
    // 0x10f17e0: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f17e0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f17e4: b               #0x10f17b0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1296800, size: 0x150
    // 0x1296800: EnterFrame
    //     0x1296800: stp             fp, lr, [SP, #-0x10]!
    //     0x1296804: mov             fp, SP
    // 0x1296808: AllocStack(0x10)
    //     0x1296808: sub             SP, SP, #0x10
    // 0x129680c: CheckStackOverflow
    //     0x129680c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1296810: cmp             SP, x16
    //     0x1296814: b.ls            #0x1296948
    // 0x1296818: ldr             x0, [fp, #0x10]
    // 0x129681c: cmp             w0, NULL
    // 0x1296820: b.ne            #0x1296834
    // 0x1296824: r0 = false
    //     0x1296824: add             x0, NULL, #0x30  ; false
    // 0x1296828: LeaveFrame
    //     0x1296828: mov             SP, fp
    //     0x129682c: ldp             fp, lr, [SP], #0x10
    // 0x1296830: ret
    //     0x1296830: ret             
    // 0x1296834: ldr             x1, [fp, #0x18]
    // 0x1296838: cmp             w1, w0
    // 0x129683c: b.ne            #0x1296850
    // 0x1296840: r0 = true
    //     0x1296840: add             x0, NULL, #0x20  ; true
    // 0x1296844: LeaveFrame
    //     0x1296844: mov             SP, fp
    //     0x1296848: ldp             fp, lr, [SP], #0x10
    // 0x129684c: ret
    //     0x129684c: ret             
    // 0x1296850: str             x0, [SP]
    // 0x1296854: r0 = runtimeType()
    //     0x1296854: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1296858: r1 = LoadClassIdInstr(r0)
    //     0x1296858: ldur            x1, [x0, #-1]
    //     0x129685c: ubfx            x1, x1, #0xc, #0x14
    // 0x1296860: r16 = Border
    //     0x1296860: add             x16, PP, #0x80, lsl #12  ; [pp+0x808c8] Type: Border
    //     0x1296864: ldr             x16, [x16, #0x8c8]
    // 0x1296868: stp             x16, x0, [SP]
    // 0x129686c: mov             x0, x1
    // 0x1296870: mov             lr, x0
    // 0x1296874: ldr             lr, [x21, lr, lsl #3]
    // 0x1296878: blr             lr
    // 0x129687c: tbz             w0, #4, #0x1296890
    // 0x1296880: r0 = false
    //     0x1296880: add             x0, NULL, #0x30  ; false
    // 0x1296884: LeaveFrame
    //     0x1296884: mov             SP, fp
    //     0x1296888: ldp             fp, lr, [SP], #0x10
    // 0x129688c: ret
    //     0x129688c: ret             
    // 0x1296890: ldr             x0, [fp, #0x10]
    // 0x1296894: r1 = 60
    //     0x1296894: mov             x1, #0x3c
    // 0x1296898: branchIfSmi(r0, 0x12968a4)
    //     0x1296898: tbz             w0, #0, #0x12968a4
    // 0x129689c: r1 = LoadClassIdInstr(r0)
    //     0x129689c: ldur            x1, [x0, #-1]
    //     0x12968a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12968a4: cmp             x1, #0xbc5
    // 0x12968a8: b.ne            #0x1296938
    // 0x12968ac: ldr             x1, [fp, #0x18]
    // 0x12968b0: LoadField: r2 = r0->field_7
    //     0x12968b0: ldur            w2, [x0, #7]
    // 0x12968b4: DecompressPointer r2
    //     0x12968b4: add             x2, x2, HEAP, lsl #32
    // 0x12968b8: LoadField: r3 = r1->field_7
    //     0x12968b8: ldur            w3, [x1, #7]
    // 0x12968bc: DecompressPointer r3
    //     0x12968bc: add             x3, x3, HEAP, lsl #32
    // 0x12968c0: stp             x3, x2, [SP]
    // 0x12968c4: r0 = ==()
    //     0x12968c4: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x12968c8: tbnz            w0, #4, #0x1296938
    // 0x12968cc: ldr             x1, [fp, #0x18]
    // 0x12968d0: ldr             x0, [fp, #0x10]
    // 0x12968d4: LoadField: r2 = r0->field_b
    //     0x12968d4: ldur            w2, [x0, #0xb]
    // 0x12968d8: DecompressPointer r2
    //     0x12968d8: add             x2, x2, HEAP, lsl #32
    // 0x12968dc: LoadField: r3 = r1->field_b
    //     0x12968dc: ldur            w3, [x1, #0xb]
    // 0x12968e0: DecompressPointer r3
    //     0x12968e0: add             x3, x3, HEAP, lsl #32
    // 0x12968e4: stp             x3, x2, [SP]
    // 0x12968e8: r0 = ==()
    //     0x12968e8: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x12968ec: tbnz            w0, #4, #0x1296938
    // 0x12968f0: ldr             x1, [fp, #0x18]
    // 0x12968f4: ldr             x0, [fp, #0x10]
    // 0x12968f8: LoadField: r2 = r0->field_f
    //     0x12968f8: ldur            w2, [x0, #0xf]
    // 0x12968fc: DecompressPointer r2
    //     0x12968fc: add             x2, x2, HEAP, lsl #32
    // 0x1296900: LoadField: r3 = r1->field_f
    //     0x1296900: ldur            w3, [x1, #0xf]
    // 0x1296904: DecompressPointer r3
    //     0x1296904: add             x3, x3, HEAP, lsl #32
    // 0x1296908: stp             x3, x2, [SP]
    // 0x129690c: r0 = ==()
    //     0x129690c: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296910: tbnz            w0, #4, #0x1296938
    // 0x1296914: ldr             x1, [fp, #0x18]
    // 0x1296918: ldr             x0, [fp, #0x10]
    // 0x129691c: LoadField: r2 = r0->field_13
    //     0x129691c: ldur            w2, [x0, #0x13]
    // 0x1296920: DecompressPointer r2
    //     0x1296920: add             x2, x2, HEAP, lsl #32
    // 0x1296924: LoadField: r0 = r1->field_13
    //     0x1296924: ldur            w0, [x1, #0x13]
    // 0x1296928: DecompressPointer r0
    //     0x1296928: add             x0, x0, HEAP, lsl #32
    // 0x129692c: stp             x0, x2, [SP]
    // 0x1296930: r0 = ==()
    //     0x1296930: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296934: b               #0x129693c
    // 0x1296938: r0 = false
    //     0x1296938: add             x0, NULL, #0x30  ; false
    // 0x129693c: LeaveFrame
    //     0x129693c: mov             SP, fp
    //     0x1296940: ldp             fp, lr, [SP], #0x10
    // 0x1296944: ret
    //     0x1296944: ret             
    // 0x1296948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1296948: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129694c: b               #0x1296818
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ef9ec, size: 0x45c
    // 0x12ef9ec: EnterFrame
    //     0x12ef9ec: stp             fp, lr, [SP, #-0x10]!
    //     0x12ef9f0: mov             fp, SP
    // 0x12ef9f4: AllocStack(0x88)
    //     0x12ef9f4: sub             SP, SP, #0x88
    // 0x12ef9f8: SetupParameters(Border this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x28 */, dynamic _ /* r3 => r2, fp-0x30 */, {dynamic borderRadius = Null /* r6, fp-0x18 */, dynamic shape = Instance_BoxShape /* r7, fp-0x10 */, dynamic textDirection = Null /* r4, fp-0x8 */})
    //     0x12ef9f8: mov             x0, x2
    //     0x12ef9fc: stur            x2, [fp, #-0x28]
    //     0x12efa00: mov             x2, x3
    //     0x12efa04: stur            x3, [fp, #-0x30]
    //     0x12efa08: mov             x3, x1
    //     0x12efa0c: stur            x1, [fp, #-0x20]
    //     0x12efa10: ldur            w1, [x4, #0x13]
    //     0x12efa14: ldur            w5, [x4, #0x1f]
    //     0x12efa18: add             x5, x5, HEAP, lsl #32
    //     0x12efa1c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d00] "borderRadius"
    //     0x12efa20: ldr             x16, [x16, #0xd00]
    //     0x12efa24: cmp             w5, w16
    //     0x12efa28: b.ne            #0x12efa4c
    //     0x12efa2c: ldur            w5, [x4, #0x23]
    //     0x12efa30: add             x5, x5, HEAP, lsl #32
    //     0x12efa34: sub             w6, w1, w5
    //     0x12efa38: add             x5, fp, w6, sxtw #2
    //     0x12efa3c: ldr             x5, [x5, #8]
    //     0x12efa40: mov             x6, x5
    //     0x12efa44: mov             x5, #1
    //     0x12efa48: b               #0x12efa54
    //     0x12efa4c: mov             x6, NULL
    //     0x12efa50: mov             x5, #0
    //     0x12efa54: stur            x6, [fp, #-0x18]
    //     0x12efa58: lsl             x7, x5, #1
    //     0x12efa5c: lsl             w8, w7, #1
    //     0x12efa60: add             w9, w8, #8
    //     0x12efa64: add             x16, x4, w9, sxtw #1
    //     0x12efa68: ldur            w10, [x16, #0xf]
    //     0x12efa6c: add             x10, x10, HEAP, lsl #32
    //     0x12efa70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0x12efa74: ldr             x16, [x16, #0xa28]
    //     0x12efa78: cmp             w10, w16
    //     0x12efa7c: b.ne            #0x12efab0
    //     0x12efa80: add             w5, w8, #0xa
    //     0x12efa84: add             x16, x4, w5, sxtw #1
    //     0x12efa88: ldur            w8, [x16, #0xf]
    //     0x12efa8c: add             x8, x8, HEAP, lsl #32
    //     0x12efa90: sub             w5, w1, w8
    //     0x12efa94: add             x8, fp, w5, sxtw #2
    //     0x12efa98: ldr             x8, [x8, #8]
    //     0x12efa9c: add             w5, w7, #2
    //     0x12efaa0: sbfx            x7, x5, #1, #0x1f
    //     0x12efaa4: mov             x5, x7
    //     0x12efaa8: mov             x7, x8
    //     0x12efaac: b               #0x12efab8
    //     0x12efab0: add             x7, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0x12efab4: ldr             x7, [x7, #0x1f8]
    //     0x12efab8: stur            x7, [fp, #-0x10]
    //     0x12efabc: lsl             x8, x5, #1
    //     0x12efac0: lsl             w5, w8, #1
    //     0x12efac4: add             w8, w5, #8
    //     0x12efac8: add             x16, x4, w8, sxtw #1
    //     0x12efacc: ldur            w9, [x16, #0xf]
    //     0x12efad0: add             x9, x9, HEAP, lsl #32
    //     0x12efad4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12efad8: ldr             x16, [x16, #0x210]
    //     0x12efadc: cmp             w9, w16
    //     0x12efae0: b.ne            #0x12efb08
    //     0x12efae4: add             w8, w5, #0xa
    //     0x12efae8: add             x16, x4, w8, sxtw #1
    //     0x12efaec: ldur            w5, [x16, #0xf]
    //     0x12efaf0: add             x5, x5, HEAP, lsl #32
    //     0x12efaf4: sub             w4, w1, w5
    //     0x12efaf8: add             x1, fp, w4, sxtw #2
    //     0x12efafc: ldr             x1, [x1, #8]
    //     0x12efb00: mov             x4, x1
    //     0x12efb04: b               #0x12efb0c
    //     0x12efb08: mov             x4, NULL
    //     0x12efb0c: stur            x4, [fp, #-8]
    // 0x12efb10: CheckStackOverflow
    //     0x12efb10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12efb14: cmp             SP, x16
    //     0x12efb18: b.ls            #0x12efe40
    // 0x12efb1c: mov             x1, x3
    // 0x12efb20: r0 = isUniform()
    //     0x12efb20: bl              #0xe37054  ; [package:flutter/src/painting/box_border.dart] Border::isUniform
    // 0x12efb24: tbnz            w0, #4, #0x12efbe4
    // 0x12efb28: ldur            x0, [fp, #-0x20]
    // 0x12efb2c: LoadField: r3 = r0->field_7
    //     0x12efb2c: ldur            w3, [x0, #7]
    // 0x12efb30: DecompressPointer r3
    //     0x12efb30: add             x3, x3, HEAP, lsl #32
    // 0x12efb34: stur            x3, [fp, #-0x38]
    // 0x12efb38: LoadField: r0 = r3->field_13
    //     0x12efb38: ldur            w0, [x3, #0x13]
    // 0x12efb3c: DecompressPointer r0
    //     0x12efb3c: add             x0, x0, HEAP, lsl #32
    // 0x12efb40: LoadField: r1 = r0->field_7
    //     0x12efb40: ldur            x1, [x0, #7]
    // 0x12efb44: cmp             x1, #0
    // 0x12efb48: b.gt            #0x12efb5c
    // 0x12efb4c: r0 = Null
    //     0x12efb4c: mov             x0, NULL
    // 0x12efb50: LeaveFrame
    //     0x12efb50: mov             SP, fp
    //     0x12efb54: ldp             fp, lr, [SP], #0x10
    // 0x12efb58: ret
    //     0x12efb58: ret             
    // 0x12efb5c: ldur            x2, [fp, #-0x10]
    // 0x12efb60: LoadField: r0 = r2->field_7
    //     0x12efb60: ldur            x0, [x2, #7]
    // 0x12efb64: cmp             x0, #0
    // 0x12efb68: b.gt            #0x12efbc4
    // 0x12efb6c: ldur            x5, [fp, #-0x18]
    // 0x12efb70: cmp             w5, NULL
    // 0x12efb74: b.eq            #0x12efbb0
    // 0x12efb78: r16 = Instance_BorderRadius
    //     0x12efb78: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12efb7c: ldr             x16, [x16, #0x508]
    // 0x12efb80: stp             x16, x5, [SP]
    // 0x12efb84: r0 = ==()
    //     0x12efb84: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12efb88: tbz             w0, #4, #0x12efbb0
    // 0x12efb8c: ldur            x1, [fp, #-0x28]
    // 0x12efb90: ldur            x2, [fp, #-0x30]
    // 0x12efb94: ldur            x3, [fp, #-0x38]
    // 0x12efb98: ldur            x5, [fp, #-0x18]
    // 0x12efb9c: r0 = _paintUniformBorderWithRadius()
    //     0x12efb9c: bl              #0x12f0f00  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithRadius
    // 0x12efba0: r0 = Null
    //     0x12efba0: mov             x0, NULL
    // 0x12efba4: LeaveFrame
    //     0x12efba4: mov             SP, fp
    //     0x12efba8: ldp             fp, lr, [SP], #0x10
    // 0x12efbac: ret
    //     0x12efbac: ret             
    // 0x12efbb0: ldur            x1, [fp, #-0x28]
    // 0x12efbb4: ldur            x2, [fp, #-0x30]
    // 0x12efbb8: ldur            x3, [fp, #-0x38]
    // 0x12efbbc: r0 = _paintUniformBorderWithRectangle()
    //     0x12efbbc: bl              #0x12f0e80  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithRectangle
    // 0x12efbc0: b               #0x12efbd4
    // 0x12efbc4: ldur            x1, [fp, #-0x28]
    // 0x12efbc8: ldur            x2, [fp, #-0x30]
    // 0x12efbcc: ldur            x3, [fp, #-0x38]
    // 0x12efbd0: r0 = _paintUniformBorderWithCircle()
    //     0x12efbd0: bl              #0x12f0dec  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithCircle
    // 0x12efbd4: r0 = Null
    //     0x12efbd4: mov             x0, NULL
    // 0x12efbd8: LeaveFrame
    //     0x12efbd8: mov             SP, fp
    //     0x12efbdc: ldp             fp, lr, [SP], #0x10
    // 0x12efbe0: ret
    //     0x12efbe0: ret             
    // 0x12efbe4: ldur            x0, [fp, #-0x20]
    // 0x12efbe8: ldur            x2, [fp, #-0x10]
    // 0x12efbec: LoadField: r3 = r0->field_7
    //     0x12efbec: ldur            w3, [x0, #7]
    // 0x12efbf0: DecompressPointer r3
    //     0x12efbf0: add             x3, x3, HEAP, lsl #32
    // 0x12efbf4: stur            x3, [fp, #-0x50]
    // 0x12efbf8: LoadField: r4 = r3->field_13
    //     0x12efbf8: ldur            w4, [x3, #0x13]
    // 0x12efbfc: DecompressPointer r4
    //     0x12efbfc: add             x4, x4, HEAP, lsl #32
    // 0x12efc00: stur            x4, [fp, #-0x48]
    // 0x12efc04: LoadField: r5 = r0->field_13
    //     0x12efc04: ldur            w5, [x0, #0x13]
    // 0x12efc08: DecompressPointer r5
    //     0x12efc08: add             x5, x5, HEAP, lsl #32
    // 0x12efc0c: stur            x5, [fp, #-0x40]
    // 0x12efc10: LoadField: r6 = r5->field_13
    //     0x12efc10: ldur            w6, [x5, #0x13]
    // 0x12efc14: DecompressPointer r6
    //     0x12efc14: add             x6, x6, HEAP, lsl #32
    // 0x12efc18: stur            x6, [fp, #-0x38]
    // 0x12efc1c: cmp             w6, w4
    // 0x12efc20: b.ne            #0x12efc74
    // 0x12efc24: LoadField: r1 = r0->field_f
    //     0x12efc24: ldur            w1, [x0, #0xf]
    // 0x12efc28: DecompressPointer r1
    //     0x12efc28: add             x1, x1, HEAP, lsl #32
    // 0x12efc2c: LoadField: r7 = r1->field_13
    //     0x12efc2c: ldur            w7, [x1, #0x13]
    // 0x12efc30: DecompressPointer r7
    //     0x12efc30: add             x7, x7, HEAP, lsl #32
    // 0x12efc34: cmp             w7, w4
    // 0x12efc38: b.ne            #0x12efc74
    // 0x12efc3c: LoadField: r1 = r0->field_b
    //     0x12efc3c: ldur            w1, [x0, #0xb]
    // 0x12efc40: DecompressPointer r1
    //     0x12efc40: add             x1, x1, HEAP, lsl #32
    // 0x12efc44: LoadField: r7 = r1->field_13
    //     0x12efc44: ldur            w7, [x1, #0x13]
    // 0x12efc48: DecompressPointer r7
    //     0x12efc48: add             x7, x7, HEAP, lsl #32
    // 0x12efc4c: cmp             w7, w4
    // 0x12efc50: b.ne            #0x12efc74
    // 0x12efc54: r16 = Instance_BorderStyle
    //     0x12efc54: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12efc58: ldr             x16, [x16, #0x518]
    // 0x12efc5c: cmp             w4, w16
    // 0x12efc60: b.ne            #0x12efc74
    // 0x12efc64: r0 = Null
    //     0x12efc64: mov             x0, NULL
    // 0x12efc68: LeaveFrame
    //     0x12efc68: mov             SP, fp
    //     0x12efc6c: ldp             fp, lr, [SP], #0x10
    // 0x12efc70: ret
    //     0x12efc70: ret             
    // 0x12efc74: mov             x1, x0
    // 0x12efc78: r0 = _distinctVisibleColors()
    //     0x12efc78: bl              #0x12f0cb4  ; [package:flutter/src/painting/box_border.dart] Border::_distinctVisibleColors
    // 0x12efc7c: ldur            x1, [fp, #-0x20]
    // 0x12efc80: stur            x0, [fp, #-0x58]
    // 0x12efc84: r0 = _hasHairlineBorder()
    //     0x12efc84: bl              #0x12f0bd8  ; [package:flutter/src/painting/box_border.dart] Border::_hasHairlineBorder
    // 0x12efc88: ldur            x1, [fp, #-0x58]
    // 0x12efc8c: LoadField: r2 = r1->field_13
    //     0x12efc8c: ldur            w2, [x1, #0x13]
    // 0x12efc90: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x12efc90: ldur            w3, [x1, #0x17]
    // 0x12efc94: r4 = LoadInt32Instr(r2)
    //     0x12efc94: sbfx            x4, x2, #1, #0x1f
    // 0x12efc98: r2 = LoadInt32Instr(r3)
    //     0x12efc98: sbfx            x2, x3, #1, #0x1f
    // 0x12efc9c: sub             x3, x4, x2
    // 0x12efca0: cmp             x3, #1
    // 0x12efca4: b.ne            #0x12efe08
    // 0x12efca8: tbz             w0, #4, #0x12efe00
    // 0x12efcac: ldur            x0, [fp, #-0x10]
    // 0x12efcb0: r16 = Instance_BoxShape
    //     0x12efcb0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0x12efcb4: ldr             x16, [x16, #0xbf0]
    // 0x12efcb8: cmp             w0, w16
    // 0x12efcbc: b.eq            #0x12efce0
    // 0x12efcc0: ldur            x3, [fp, #-0x18]
    // 0x12efcc4: cmp             w3, NULL
    // 0x12efcc8: b.eq            #0x12efdf8
    // 0x12efccc: r16 = Instance_BorderRadius
    //     0x12efccc: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12efcd0: ldr             x16, [x16, #0x508]
    // 0x12efcd4: stp             x16, x3, [SP]
    // 0x12efcd8: r0 = ==()
    //     0x12efcd8: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12efcdc: tbz             w0, #4, #0x12efdf0
    // 0x12efce0: ldur            x0, [fp, #-0x48]
    // 0x12efce4: r16 = Instance_BorderStyle
    //     0x12efce4: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12efce8: ldr             x16, [x16, #0x518]
    // 0x12efcec: cmp             w0, w16
    // 0x12efcf0: b.ne            #0x12efd00
    // 0x12efcf4: r2 = Instance_BorderSide
    //     0x12efcf4: add             x2, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12efcf8: ldr             x2, [x2, #0x310]
    // 0x12efcfc: b               #0x12efd04
    // 0x12efd00: ldur            x2, [fp, #-0x50]
    // 0x12efd04: ldur            x0, [fp, #-0x20]
    // 0x12efd08: stur            x2, [fp, #-0x68]
    // 0x12efd0c: LoadField: r1 = r0->field_b
    //     0x12efd0c: ldur            w1, [x0, #0xb]
    // 0x12efd10: DecompressPointer r1
    //     0x12efd10: add             x1, x1, HEAP, lsl #32
    // 0x12efd14: LoadField: r3 = r1->field_13
    //     0x12efd14: ldur            w3, [x1, #0x13]
    // 0x12efd18: DecompressPointer r3
    //     0x12efd18: add             x3, x3, HEAP, lsl #32
    // 0x12efd1c: r16 = Instance_BorderStyle
    //     0x12efd1c: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12efd20: ldr             x16, [x16, #0x518]
    // 0x12efd24: cmp             w3, w16
    // 0x12efd28: b.ne            #0x12efd38
    // 0x12efd2c: r3 = Instance_BorderSide
    //     0x12efd2c: add             x3, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12efd30: ldr             x3, [x3, #0x310]
    // 0x12efd34: b               #0x12efd3c
    // 0x12efd38: mov             x3, x1
    // 0x12efd3c: stur            x3, [fp, #-0x60]
    // 0x12efd40: LoadField: r1 = r0->field_f
    //     0x12efd40: ldur            w1, [x0, #0xf]
    // 0x12efd44: DecompressPointer r1
    //     0x12efd44: add             x1, x1, HEAP, lsl #32
    // 0x12efd48: LoadField: r0 = r1->field_13
    //     0x12efd48: ldur            w0, [x1, #0x13]
    // 0x12efd4c: DecompressPointer r0
    //     0x12efd4c: add             x0, x0, HEAP, lsl #32
    // 0x12efd50: r16 = Instance_BorderStyle
    //     0x12efd50: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12efd54: ldr             x16, [x16, #0x518]
    // 0x12efd58: cmp             w0, w16
    // 0x12efd5c: b.ne            #0x12efd6c
    // 0x12efd60: r5 = Instance_BorderSide
    //     0x12efd60: add             x5, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12efd64: ldr             x5, [x5, #0x310]
    // 0x12efd68: b               #0x12efd70
    // 0x12efd6c: mov             x5, x1
    // 0x12efd70: ldur            x0, [fp, #-0x38]
    // 0x12efd74: stur            x5, [fp, #-0x48]
    // 0x12efd78: r16 = Instance_BorderStyle
    //     0x12efd78: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12efd7c: ldr             x16, [x16, #0x518]
    // 0x12efd80: cmp             w0, w16
    // 0x12efd84: b.ne            #0x12efd94
    // 0x12efd88: r0 = Instance_BorderSide
    //     0x12efd88: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x12efd8c: ldr             x0, [x0, #0x310]
    // 0x12efd90: b               #0x12efd98
    // 0x12efd94: ldur            x0, [fp, #-0x40]
    // 0x12efd98: ldur            x1, [fp, #-0x58]
    // 0x12efd9c: stur            x0, [fp, #-0x38]
    // 0x12efda0: r0 = first()
    //     0x12efda0: bl              #0xbb58dc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::first
    // 0x12efda4: ldur            x16, [fp, #-0x10]
    // 0x12efda8: ldur            lr, [fp, #-0x68]
    // 0x12efdac: stp             lr, x16, [SP, #0x10]
    // 0x12efdb0: ldur            x16, [fp, #-0x60]
    // 0x12efdb4: ldur            lr, [fp, #-0x38]
    // 0x12efdb8: stp             lr, x16, [SP]
    // 0x12efdbc: ldur            x1, [fp, #-0x28]
    // 0x12efdc0: ldur            x2, [fp, #-0x30]
    // 0x12efdc4: ldur            x3, [fp, #-0x18]
    // 0x12efdc8: ldur            x5, [fp, #-0x48]
    // 0x12efdcc: mov             x6, x0
    // 0x12efdd0: ldur            x7, [fp, #-8]
    // 0x12efdd4: r4 = const [0, 0xa, 0x4, 0x6, left, 0x9, right, 0x8, shape, 0x6, top, 0x7, null]
    //     0x12efdd4: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0d88] List(13) [0, 0xa, 0x4, 0x6, "left", 0x9, "right", 0x8, "shape", 0x6, "top", 0x7, Null]
    //     0x12efdd8: ldr             x4, [x4, #0xd88]
    // 0x12efddc: r0 = paintNonUniformBorder()
    //     0x12efddc: bl              #0x12ee15c  ; [package:flutter/src/painting/box_border.dart] BoxBorder::paintNonUniformBorder
    // 0x12efde0: r0 = Null
    //     0x12efde0: mov             x0, NULL
    // 0x12efde4: LeaveFrame
    //     0x12efde4: mov             SP, fp
    //     0x12efde8: ldp             fp, lr, [SP], #0x10
    // 0x12efdec: ret
    //     0x12efdec: ret             
    // 0x12efdf0: ldur            x0, [fp, #-0x20]
    // 0x12efdf4: b               #0x12efe0c
    // 0x12efdf8: ldur            x0, [fp, #-0x20]
    // 0x12efdfc: b               #0x12efe0c
    // 0x12efe00: ldur            x0, [fp, #-0x20]
    // 0x12efe04: b               #0x12efe0c
    // 0x12efe08: ldur            x0, [fp, #-0x20]
    // 0x12efe0c: LoadField: r6 = r0->field_b
    //     0x12efe0c: ldur            w6, [x0, #0xb]
    // 0x12efe10: DecompressPointer r6
    //     0x12efe10: add             x6, x6, HEAP, lsl #32
    // 0x12efe14: LoadField: r3 = r0->field_f
    //     0x12efe14: ldur            w3, [x0, #0xf]
    // 0x12efe18: DecompressPointer r3
    //     0x12efe18: add             x3, x3, HEAP, lsl #32
    // 0x12efe1c: ldur            x1, [fp, #-0x28]
    // 0x12efe20: ldur            x2, [fp, #-0x30]
    // 0x12efe24: ldur            x5, [fp, #-0x40]
    // 0x12efe28: ldur            x7, [fp, #-0x50]
    // 0x12efe2c: r0 = paintBorder()
    //     0x12efe2c: bl              #0x12efe48  ; [package:flutter/src/painting/borders.dart] ::paintBorder
    // 0x12efe30: r0 = Null
    //     0x12efe30: mov             x0, NULL
    // 0x12efe34: LeaveFrame
    //     0x12efe34: mov             SP, fp
    //     0x12efe38: ldp             fp, lr, [SP], #0x10
    // 0x12efe3c: ret
    //     0x12efe3c: ret             
    // 0x12efe40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12efe40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12efe44: b               #0x12efb1c
  }
  get _ _hasHairlineBorder(/* No info */) {
    // ** addr: 0x12f0bd8, size: 0xdc
    // 0x12f0bd8: LoadField: r2 = r1->field_7
    //     0x12f0bd8: ldur            w2, [x1, #7]
    // 0x12f0bdc: DecompressPointer r2
    //     0x12f0bdc: add             x2, x2, HEAP, lsl #32
    // 0x12f0be0: LoadField: r3 = r2->field_13
    //     0x12f0be0: ldur            w3, [x2, #0x13]
    // 0x12f0be4: DecompressPointer r3
    //     0x12f0be4: add             x3, x3, HEAP, lsl #32
    // 0x12f0be8: r16 = Instance_BorderStyle
    //     0x12f0be8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f0bec: ldr             x16, [x16, #0xdc8]
    // 0x12f0bf0: cmp             w3, w16
    // 0x12f0bf4: b.ne            #0x12f0c0c
    // 0x12f0bf8: d0 = 0.000000
    //     0x12f0bf8: eor             v0.16b, v0.16b, v0.16b
    // 0x12f0bfc: LoadField: d1 = r2->field_b
    //     0x12f0bfc: ldur            d1, [x2, #0xb]
    // 0x12f0c00: fcmp            d1, d0
    // 0x12f0c04: b.ne            #0x12f0c10
    // 0x12f0c08: b               #0x12f0c68
    // 0x12f0c0c: d0 = 0.000000
    //     0x12f0c0c: eor             v0.16b, v0.16b, v0.16b
    // 0x12f0c10: LoadField: r2 = r1->field_b
    //     0x12f0c10: ldur            w2, [x1, #0xb]
    // 0x12f0c14: DecompressPointer r2
    //     0x12f0c14: add             x2, x2, HEAP, lsl #32
    // 0x12f0c18: LoadField: r3 = r2->field_13
    //     0x12f0c18: ldur            w3, [x2, #0x13]
    // 0x12f0c1c: DecompressPointer r3
    //     0x12f0c1c: add             x3, x3, HEAP, lsl #32
    // 0x12f0c20: r16 = Instance_BorderStyle
    //     0x12f0c20: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f0c24: ldr             x16, [x16, #0xdc8]
    // 0x12f0c28: cmp             w3, w16
    // 0x12f0c2c: b.ne            #0x12f0c3c
    // 0x12f0c30: LoadField: d1 = r2->field_b
    //     0x12f0c30: ldur            d1, [x2, #0xb]
    // 0x12f0c34: fcmp            d1, d0
    // 0x12f0c38: b.eq            #0x12f0c68
    // 0x12f0c3c: LoadField: r2 = r1->field_f
    //     0x12f0c3c: ldur            w2, [x1, #0xf]
    // 0x12f0c40: DecompressPointer r2
    //     0x12f0c40: add             x2, x2, HEAP, lsl #32
    // 0x12f0c44: LoadField: r3 = r2->field_13
    //     0x12f0c44: ldur            w3, [x2, #0x13]
    // 0x12f0c48: DecompressPointer r3
    //     0x12f0c48: add             x3, x3, HEAP, lsl #32
    // 0x12f0c4c: r16 = Instance_BorderStyle
    //     0x12f0c4c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f0c50: ldr             x16, [x16, #0xdc8]
    // 0x12f0c54: cmp             w3, w16
    // 0x12f0c58: b.ne            #0x12f0c70
    // 0x12f0c5c: LoadField: d1 = r2->field_b
    //     0x12f0c5c: ldur            d1, [x2, #0xb]
    // 0x12f0c60: fcmp            d1, d0
    // 0x12f0c64: b.ne            #0x12f0c70
    // 0x12f0c68: r0 = true
    //     0x12f0c68: add             x0, NULL, #0x20  ; true
    // 0x12f0c6c: b               #0x12f0cb0
    // 0x12f0c70: LoadField: r2 = r1->field_13
    //     0x12f0c70: ldur            w2, [x1, #0x13]
    // 0x12f0c74: DecompressPointer r2
    //     0x12f0c74: add             x2, x2, HEAP, lsl #32
    // 0x12f0c78: LoadField: r1 = r2->field_13
    //     0x12f0c78: ldur            w1, [x2, #0x13]
    // 0x12f0c7c: DecompressPointer r1
    //     0x12f0c7c: add             x1, x1, HEAP, lsl #32
    // 0x12f0c80: r16 = Instance_BorderStyle
    //     0x12f0c80: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f0c84: ldr             x16, [x16, #0xdc8]
    // 0x12f0c88: cmp             w1, w16
    // 0x12f0c8c: b.ne            #0x12f0cac
    // 0x12f0c90: LoadField: d1 = r2->field_b
    //     0x12f0c90: ldur            d1, [x2, #0xb]
    // 0x12f0c94: fcmp            d1, d0
    // 0x12f0c98: r16 = true
    //     0x12f0c98: add             x16, NULL, #0x20  ; true
    // 0x12f0c9c: r17 = false
    //     0x12f0c9c: add             x17, NULL, #0x30  ; false
    // 0x12f0ca0: csel            x1, x16, x17, eq
    // 0x12f0ca4: mov             x0, x1
    // 0x12f0ca8: b               #0x12f0cb0
    // 0x12f0cac: r0 = false
    //     0x12f0cac: add             x0, NULL, #0x30  ; false
    // 0x12f0cb0: ret
    //     0x12f0cb0: ret             
  }
  _ _distinctVisibleColors(/* No info */) {
    // ** addr: 0x12f0cb4, size: 0x138
    // 0x12f0cb4: EnterFrame
    //     0x12f0cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f0cb8: mov             fp, SP
    // 0x12f0cbc: AllocStack(0x10)
    //     0x12f0cbc: sub             SP, SP, #0x10
    // 0x12f0cc0: SetupParameters(Border this /* r1 => r0, fp-0x8 */)
    //     0x12f0cc0: mov             x0, x1
    //     0x12f0cc4: stur            x1, [fp, #-8]
    // 0x12f0cc8: CheckStackOverflow
    //     0x12f0cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f0ccc: cmp             SP, x16
    //     0x12f0cd0: b.ls            #0x12f0de4
    // 0x12f0cd4: r1 = <Color>
    //     0x12f0cd4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12f0cd8: ldr             x1, [x1, #0xa90]
    // 0x12f0cdc: r0 = _Set()
    //     0x12f0cdc: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x12f0ce0: mov             x3, x0
    // 0x12f0ce4: r0 = _Uint32List
    //     0x12f0ce4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x12f0ce8: stur            x3, [fp, #-0x10]
    // 0x12f0cec: StoreField: r3->field_1b = r0
    //     0x12f0cec: stur            w0, [x3, #0x1b]
    // 0x12f0cf0: StoreField: r3->field_b = rZR
    //     0x12f0cf0: stur            wzr, [x3, #0xb]
    // 0x12f0cf4: r0 = const []
    //     0x12f0cf4: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x12f0cf8: StoreField: r3->field_f = r0
    //     0x12f0cf8: stur            w0, [x3, #0xf]
    // 0x12f0cfc: StoreField: r3->field_13 = rZR
    //     0x12f0cfc: stur            wzr, [x3, #0x13]
    // 0x12f0d00: ArrayStore: r3[0] = rZR  ; List_4
    //     0x12f0d00: stur            wzr, [x3, #0x17]
    // 0x12f0d04: ldur            x0, [fp, #-8]
    // 0x12f0d08: LoadField: r1 = r0->field_7
    //     0x12f0d08: ldur            w1, [x0, #7]
    // 0x12f0d0c: DecompressPointer r1
    //     0x12f0d0c: add             x1, x1, HEAP, lsl #32
    // 0x12f0d10: LoadField: r2 = r1->field_13
    //     0x12f0d10: ldur            w2, [x1, #0x13]
    // 0x12f0d14: DecompressPointer r2
    //     0x12f0d14: add             x2, x2, HEAP, lsl #32
    // 0x12f0d18: r16 = Instance_BorderStyle
    //     0x12f0d18: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12f0d1c: ldr             x16, [x16, #0x518]
    // 0x12f0d20: cmp             w2, w16
    // 0x12f0d24: b.eq            #0x12f0d38
    // 0x12f0d28: LoadField: r2 = r1->field_7
    //     0x12f0d28: ldur            w2, [x1, #7]
    // 0x12f0d2c: DecompressPointer r2
    //     0x12f0d2c: add             x2, x2, HEAP, lsl #32
    // 0x12f0d30: mov             x1, x3
    // 0x12f0d34: r0 = add()
    //     0x12f0d34: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x12f0d38: ldur            x0, [fp, #-8]
    // 0x12f0d3c: LoadField: r1 = r0->field_b
    //     0x12f0d3c: ldur            w1, [x0, #0xb]
    // 0x12f0d40: DecompressPointer r1
    //     0x12f0d40: add             x1, x1, HEAP, lsl #32
    // 0x12f0d44: LoadField: r2 = r1->field_13
    //     0x12f0d44: ldur            w2, [x1, #0x13]
    // 0x12f0d48: DecompressPointer r2
    //     0x12f0d48: add             x2, x2, HEAP, lsl #32
    // 0x12f0d4c: r16 = Instance_BorderStyle
    //     0x12f0d4c: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12f0d50: ldr             x16, [x16, #0x518]
    // 0x12f0d54: cmp             w2, w16
    // 0x12f0d58: b.eq            #0x12f0d6c
    // 0x12f0d5c: LoadField: r2 = r1->field_7
    //     0x12f0d5c: ldur            w2, [x1, #7]
    // 0x12f0d60: DecompressPointer r2
    //     0x12f0d60: add             x2, x2, HEAP, lsl #32
    // 0x12f0d64: ldur            x1, [fp, #-0x10]
    // 0x12f0d68: r0 = add()
    //     0x12f0d68: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x12f0d6c: ldur            x0, [fp, #-8]
    // 0x12f0d70: LoadField: r1 = r0->field_f
    //     0x12f0d70: ldur            w1, [x0, #0xf]
    // 0x12f0d74: DecompressPointer r1
    //     0x12f0d74: add             x1, x1, HEAP, lsl #32
    // 0x12f0d78: LoadField: r2 = r1->field_13
    //     0x12f0d78: ldur            w2, [x1, #0x13]
    // 0x12f0d7c: DecompressPointer r2
    //     0x12f0d7c: add             x2, x2, HEAP, lsl #32
    // 0x12f0d80: r16 = Instance_BorderStyle
    //     0x12f0d80: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12f0d84: ldr             x16, [x16, #0x518]
    // 0x12f0d88: cmp             w2, w16
    // 0x12f0d8c: b.eq            #0x12f0da0
    // 0x12f0d90: LoadField: r2 = r1->field_7
    //     0x12f0d90: ldur            w2, [x1, #7]
    // 0x12f0d94: DecompressPointer r2
    //     0x12f0d94: add             x2, x2, HEAP, lsl #32
    // 0x12f0d98: ldur            x1, [fp, #-0x10]
    // 0x12f0d9c: r0 = add()
    //     0x12f0d9c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x12f0da0: ldur            x0, [fp, #-8]
    // 0x12f0da4: LoadField: r1 = r0->field_13
    //     0x12f0da4: ldur            w1, [x0, #0x13]
    // 0x12f0da8: DecompressPointer r1
    //     0x12f0da8: add             x1, x1, HEAP, lsl #32
    // 0x12f0dac: LoadField: r0 = r1->field_13
    //     0x12f0dac: ldur            w0, [x1, #0x13]
    // 0x12f0db0: DecompressPointer r0
    //     0x12f0db0: add             x0, x0, HEAP, lsl #32
    // 0x12f0db4: r16 = Instance_BorderStyle
    //     0x12f0db4: add             x16, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12f0db8: ldr             x16, [x16, #0x518]
    // 0x12f0dbc: cmp             w0, w16
    // 0x12f0dc0: b.eq            #0x12f0dd4
    // 0x12f0dc4: LoadField: r2 = r1->field_7
    //     0x12f0dc4: ldur            w2, [x1, #7]
    // 0x12f0dc8: DecompressPointer r2
    //     0x12f0dc8: add             x2, x2, HEAP, lsl #32
    // 0x12f0dcc: ldur            x1, [fp, #-0x10]
    // 0x12f0dd0: r0 = add()
    //     0x12f0dd0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x12f0dd4: ldur            x0, [fp, #-0x10]
    // 0x12f0dd8: LeaveFrame
    //     0x12f0dd8: mov             SP, fp
    //     0x12f0ddc: ldp             fp, lr, [SP], #0x10
    // 0x12f0de0: ret
    //     0x12f0de0: ret             
    // 0x12f0de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f0de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f0de8: b               #0x12f0cd4
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0x12f56c4, size: 0xd4
    // 0x12f56c4: EnterFrame
    //     0x12f56c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f56c8: mov             fp, SP
    // 0x12f56cc: AllocStack(0x20)
    //     0x12f56cc: sub             SP, SP, #0x20
    // 0x12f56d0: d1 = 1.000000
    //     0x12f56d0: fmov            d1, #1.00000000
    // 0x12f56d4: d0 = 2.000000
    //     0x12f56d4: fmov            d0, #2.00000000
    // 0x12f56d8: LoadField: r0 = r1->field_13
    //     0x12f56d8: ldur            w0, [x1, #0x13]
    // 0x12f56dc: DecompressPointer r0
    //     0x12f56dc: add             x0, x0, HEAP, lsl #32
    // 0x12f56e0: LoadField: d2 = r0->field_b
    //     0x12f56e0: ldur            d2, [x0, #0xb]
    // 0x12f56e4: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x12f56e4: ldur            d3, [x0, #0x17]
    // 0x12f56e8: fadd            d4, d3, d1
    // 0x12f56ec: fdiv            d3, d4, d0
    // 0x12f56f0: fsub            d4, d1, d3
    // 0x12f56f4: fmul            d3, d2, d4
    // 0x12f56f8: stur            d3, [fp, #-0x20]
    // 0x12f56fc: LoadField: r0 = r1->field_7
    //     0x12f56fc: ldur            w0, [x1, #7]
    // 0x12f5700: DecompressPointer r0
    //     0x12f5700: add             x0, x0, HEAP, lsl #32
    // 0x12f5704: LoadField: d2 = r0->field_b
    //     0x12f5704: ldur            d2, [x0, #0xb]
    // 0x12f5708: ArrayLoad: d4 = r0[0]  ; List_8
    //     0x12f5708: ldur            d4, [x0, #0x17]
    // 0x12f570c: fadd            d5, d4, d1
    // 0x12f5710: fdiv            d4, d5, d0
    // 0x12f5714: fsub            d5, d1, d4
    // 0x12f5718: fmul            d4, d2, d5
    // 0x12f571c: stur            d4, [fp, #-0x18]
    // 0x12f5720: LoadField: r0 = r1->field_b
    //     0x12f5720: ldur            w0, [x1, #0xb]
    // 0x12f5724: DecompressPointer r0
    //     0x12f5724: add             x0, x0, HEAP, lsl #32
    // 0x12f5728: LoadField: d2 = r0->field_b
    //     0x12f5728: ldur            d2, [x0, #0xb]
    // 0x12f572c: ArrayLoad: d5 = r0[0]  ; List_8
    //     0x12f572c: ldur            d5, [x0, #0x17]
    // 0x12f5730: fadd            d6, d5, d1
    // 0x12f5734: fdiv            d5, d6, d0
    // 0x12f5738: fsub            d6, d1, d5
    // 0x12f573c: fmul            d5, d2, d6
    // 0x12f5740: stur            d5, [fp, #-0x10]
    // 0x12f5744: LoadField: r0 = r1->field_f
    //     0x12f5744: ldur            w0, [x1, #0xf]
    // 0x12f5748: DecompressPointer r0
    //     0x12f5748: add             x0, x0, HEAP, lsl #32
    // 0x12f574c: LoadField: d2 = r0->field_b
    //     0x12f574c: ldur            d2, [x0, #0xb]
    // 0x12f5750: ArrayLoad: d6 = r0[0]  ; List_8
    //     0x12f5750: ldur            d6, [x0, #0x17]
    // 0x12f5754: fadd            d7, d6, d1
    // 0x12f5758: fdiv            d6, d7, d0
    // 0x12f575c: fsub            d0, d1, d6
    // 0x12f5760: fmul            d1, d2, d0
    // 0x12f5764: stur            d1, [fp, #-8]
    // 0x12f5768: r0 = EdgeInsets()
    //     0x12f5768: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f576c: ldur            d0, [fp, #-0x20]
    // 0x12f5770: StoreField: r0->field_7 = d0
    //     0x12f5770: stur            d0, [x0, #7]
    // 0x12f5774: ldur            d0, [fp, #-0x18]
    // 0x12f5778: StoreField: r0->field_f = d0
    //     0x12f5778: stur            d0, [x0, #0xf]
    // 0x12f577c: ldur            d0, [fp, #-0x10]
    // 0x12f5780: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f5780: stur            d0, [x0, #0x17]
    // 0x12f5784: ldur            d0, [fp, #-8]
    // 0x12f5788: StoreField: r0->field_1f = d0
    //     0x12f5788: stur            d0, [x0, #0x1f]
    // 0x12f578c: LeaveFrame
    //     0x12f578c: mov             SP, fp
    //     0x12f5790: ldp             fp, lr, [SP], #0x10
    // 0x12f5794: ret
    //     0x12f5794: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fd09c, size: 0xc8
    // 0x12fd09c: EnterFrame
    //     0x12fd09c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd0a0: mov             fp, SP
    // 0x12fd0a4: AllocStack(0x28)
    //     0x12fd0a4: sub             SP, SP, #0x28
    // 0x12fd0a8: SetupParameters(Border this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x12fd0a8: mov             x0, x1
    //     0x12fd0ac: mov             v1.16b, v0.16b
    //     0x12fd0b0: stur            x1, [fp, #-8]
    //     0x12fd0b4: stur            d0, [fp, #-0x28]
    // 0x12fd0b8: CheckStackOverflow
    //     0x12fd0b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd0bc: cmp             SP, x16
    //     0x12fd0c0: b.ls            #0x12fd15c
    // 0x12fd0c4: LoadField: r1 = r0->field_7
    //     0x12fd0c4: ldur            w1, [x0, #7]
    // 0x12fd0c8: DecompressPointer r1
    //     0x12fd0c8: add             x1, x1, HEAP, lsl #32
    // 0x12fd0cc: mov             v0.16b, v1.16b
    // 0x12fd0d0: r0 = scale()
    //     0x12fd0d0: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fd0d4: mov             x2, x0
    // 0x12fd0d8: ldur            x0, [fp, #-8]
    // 0x12fd0dc: stur            x2, [fp, #-0x10]
    // 0x12fd0e0: LoadField: r1 = r0->field_b
    //     0x12fd0e0: ldur            w1, [x0, #0xb]
    // 0x12fd0e4: DecompressPointer r1
    //     0x12fd0e4: add             x1, x1, HEAP, lsl #32
    // 0x12fd0e8: ldur            d0, [fp, #-0x28]
    // 0x12fd0ec: r0 = scale()
    //     0x12fd0ec: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fd0f0: mov             x2, x0
    // 0x12fd0f4: ldur            x0, [fp, #-8]
    // 0x12fd0f8: stur            x2, [fp, #-0x18]
    // 0x12fd0fc: LoadField: r1 = r0->field_f
    //     0x12fd0fc: ldur            w1, [x0, #0xf]
    // 0x12fd100: DecompressPointer r1
    //     0x12fd100: add             x1, x1, HEAP, lsl #32
    // 0x12fd104: ldur            d0, [fp, #-0x28]
    // 0x12fd108: r0 = scale()
    //     0x12fd108: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fd10c: mov             x2, x0
    // 0x12fd110: ldur            x0, [fp, #-8]
    // 0x12fd114: stur            x2, [fp, #-0x20]
    // 0x12fd118: LoadField: r1 = r0->field_13
    //     0x12fd118: ldur            w1, [x0, #0x13]
    // 0x12fd11c: DecompressPointer r1
    //     0x12fd11c: add             x1, x1, HEAP, lsl #32
    // 0x12fd120: ldur            d0, [fp, #-0x28]
    // 0x12fd124: r0 = scale()
    //     0x12fd124: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fd128: stur            x0, [fp, #-8]
    // 0x12fd12c: r0 = Border()
    //     0x12fd12c: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0x12fd130: ldur            x1, [fp, #-0x10]
    // 0x12fd134: StoreField: r0->field_7 = r1
    //     0x12fd134: stur            w1, [x0, #7]
    // 0x12fd138: ldur            x1, [fp, #-0x18]
    // 0x12fd13c: StoreField: r0->field_b = r1
    //     0x12fd13c: stur            w1, [x0, #0xb]
    // 0x12fd140: ldur            x1, [fp, #-0x20]
    // 0x12fd144: StoreField: r0->field_f = r1
    //     0x12fd144: stur            w1, [x0, #0xf]
    // 0x12fd148: ldur            x1, [fp, #-8]
    // 0x12fd14c: StoreField: r0->field_13 = r1
    //     0x12fd14c: stur            w1, [x0, #0x13]
    // 0x12fd150: LeaveFrame
    //     0x12fd150: mov             SP, fp
    //     0x12fd154: ldp             fp, lr, [SP], #0x10
    // 0x12fd158: ret
    //     0x12fd158: ret             
    // 0x12fd15c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fd15c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fd160: b               #0x12fd0c4
  }
}

// class id: 8248, size: 0x14, field offset: 0x14
enum BoxShape extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aad78, size: 0x64
    // 0x11aad78: EnterFrame
    //     0x11aad78: stp             fp, lr, [SP, #-0x10]!
    //     0x11aad7c: mov             fp, SP
    // 0x11aad80: AllocStack(0x10)
    //     0x11aad80: sub             SP, SP, #0x10
    // 0x11aad84: SetupParameters(BoxShape this /* r1 => r0, fp-0x8 */)
    //     0x11aad84: mov             x0, x1
    //     0x11aad88: stur            x1, [fp, #-8]
    // 0x11aad8c: CheckStackOverflow
    //     0x11aad8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aad90: cmp             SP, x16
    //     0x11aad94: b.ls            #0x11aadd4
    // 0x11aad98: r1 = Null
    //     0x11aad98: mov             x1, NULL
    // 0x11aad9c: r2 = 4
    //     0x11aad9c: mov             x2, #4
    // 0x11aada0: r0 = AllocateArray()
    //     0x11aada0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aada4: r16 = "BoxShape."
    //     0x11aada4: add             x16, PP, #0x80, lsl #12  ; [pp+0x808c0] "BoxShape."
    //     0x11aada8: ldr             x16, [x16, #0x8c0]
    // 0x11aadac: StoreField: r0->field_f = r16
    //     0x11aadac: stur            w16, [x0, #0xf]
    // 0x11aadb0: ldur            x1, [fp, #-8]
    // 0x11aadb4: LoadField: r2 = r1->field_f
    //     0x11aadb4: ldur            w2, [x1, #0xf]
    // 0x11aadb8: DecompressPointer r2
    //     0x11aadb8: add             x2, x2, HEAP, lsl #32
    // 0x11aadbc: StoreField: r0->field_13 = r2
    //     0x11aadbc: stur            w2, [x0, #0x13]
    // 0x11aadc0: str             x0, [SP]
    // 0x11aadc4: r0 = _interpolate()
    //     0x11aadc4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aadc8: LeaveFrame
    //     0x11aadc8: mov             SP, fp
    //     0x11aadcc: ldp             fp, lr, [SP], #0x10
    // 0x11aadd0: ret
    //     0x11aadd0: ret             
    // 0x11aadd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aadd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aadd8: b               #0x11aad98
  }
}
