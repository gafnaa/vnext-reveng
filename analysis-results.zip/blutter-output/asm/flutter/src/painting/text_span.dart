// lib: , url: package:flutter/src/painting/text_span.dart

// class id: 1049012, size: 0x8
class :: {
}

// class id: 5788, size: 0x34, field offset: 0xc
//   const constructor, 
class TextSpan extends InlineSpan
    implements HitTestTarget, MouseTrackerAnnotation {

  _OneByteString field_c;
  _DeferringMouseCursor field_18;

  _ handleEvent(/* No info */) {
    // ** addr: 0xccf028, size: 0xb8
    // 0xccf028: EnterFrame
    //     0xccf028: stp             fp, lr, [SP, #-0x10]!
    //     0xccf02c: mov             fp, SP
    // 0xccf030: AllocStack(0x10)
    //     0xccf030: sub             SP, SP, #0x10
    // 0xccf034: SetupParameters(TextSpan this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */)
    //     0xccf034: mov             x5, x1
    //     0xccf038: mov             x4, x2
    //     0xccf03c: stur            x1, [fp, #-8]
    //     0xccf040: stur            x2, [fp, #-0x10]
    // 0xccf044: CheckStackOverflow
    //     0xccf044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf048: cmp             SP, x16
    //     0xccf04c: b.ls            #0xccf0d8
    // 0xccf050: mov             x0, x4
    // 0xccf054: r2 = Null
    //     0xccf054: mov             x2, NULL
    // 0xccf058: r1 = Null
    //     0xccf058: mov             x1, NULL
    // 0xccf05c: cmp             w0, NULL
    // 0xccf060: b.eq            #0xccf088
    // 0xccf064: branchIfSmi(r0, 0xccf088)
    //     0xccf064: tbz             w0, #0, #0xccf088
    // 0xccf068: r3 = LoadClassIdInstr(r0)
    //     0xccf068: ldur            x3, [x0, #-1]
    //     0xccf06c: ubfx            x3, x3, #0xc, #0x14
    // 0xccf070: r17 = 4159
    //     0xccf070: mov             x17, #0x103f
    // 0xccf074: cmp             x3, x17
    // 0xccf078: b.eq            #0xccf090
    // 0xccf07c: r17 = 5288
    //     0xccf07c: mov             x17, #0x14a8
    // 0xccf080: cmp             x3, x17
    // 0xccf084: b.eq            #0xccf090
    // 0xccf088: r0 = false
    //     0xccf088: add             x0, NULL, #0x30  ; false
    // 0xccf08c: b               #0xccf094
    // 0xccf090: r0 = true
    //     0xccf090: add             x0, NULL, #0x20  ; true
    // 0xccf094: tbnz            w0, #4, #0xccf0c8
    // 0xccf098: ldur            x0, [fp, #-8]
    // 0xccf09c: LoadField: r1 = r0->field_13
    //     0xccf09c: ldur            w1, [x0, #0x13]
    // 0xccf0a0: DecompressPointer r1
    //     0xccf0a0: add             x1, x1, HEAP, lsl #32
    // 0xccf0a4: cmp             w1, NULL
    // 0xccf0a8: b.eq            #0xccf0c8
    // 0xccf0ac: r0 = LoadClassIdInstr(r1)
    //     0xccf0ac: ldur            x0, [x1, #-1]
    //     0xccf0b0: ubfx            x0, x0, #0xc, #0x14
    // 0xccf0b4: ldur            x2, [fp, #-0x10]
    // 0xccf0b8: r0 = GDT[cid_x0 + 0xdfd4]()
    //     0xccf0b8: mov             x17, #0xdfd4
    //     0xccf0bc: add             lr, x0, x17
    //     0xccf0c0: ldr             lr, [x21, lr, lsl #3]
    //     0xccf0c4: blr             lr
    // 0xccf0c8: r0 = Null
    //     0xccf0c8: mov             x0, NULL
    // 0xccf0cc: LeaveFrame
    //     0xccf0cc: mov             SP, fp
    //     0xccf0d0: ldp             fp, lr, [SP], #0x10
    // 0xccf0d4: ret
    //     0xccf0d4: ret             
    // 0xccf0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf0d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf0dc: b               #0xccf050
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x112e0b8, size: 0x100
    // 0x112e0b8: EnterFrame
    //     0x112e0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x112e0bc: mov             fp, SP
    // 0x112e0c0: AllocStack(0x58)
    //     0x112e0c0: sub             SP, SP, #0x58
    // 0x112e0c4: CheckStackOverflow
    //     0x112e0c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e0c8: cmp             SP, x16
    //     0x112e0cc: b.ls            #0x112e1b0
    // 0x112e0d0: ldr             x1, [fp, #0x10]
    // 0x112e0d4: LoadField: r0 = r1->field_7
    //     0x112e0d4: ldur            w0, [x1, #7]
    // 0x112e0d8: DecompressPointer r0
    //     0x112e0d8: add             x0, x0, HEAP, lsl #32
    // 0x112e0dc: r2 = LoadClassIdInstr(r0)
    //     0x112e0dc: ldur            x2, [x0, #-1]
    //     0x112e0e0: ubfx            x2, x2, #0xc, #0x14
    // 0x112e0e4: str             x0, [SP]
    // 0x112e0e8: mov             x0, x2
    // 0x112e0ec: r0 = GDT[cid_x0 + 0x70de]()
    //     0x112e0ec: mov             x17, #0x70de
    //     0x112e0f0: add             lr, x0, x17
    //     0x112e0f4: ldr             lr, [x21, lr, lsl #3]
    //     0x112e0f8: blr             lr
    // 0x112e0fc: mov             x2, x0
    // 0x112e100: ldr             x0, [fp, #0x10]
    // 0x112e104: stur            x2, [fp, #-0x20]
    // 0x112e108: LoadField: r3 = r0->field_b
    //     0x112e108: ldur            w3, [x0, #0xb]
    // 0x112e10c: DecompressPointer r3
    //     0x112e10c: add             x3, x3, HEAP, lsl #32
    // 0x112e110: stur            x3, [fp, #-0x18]
    // 0x112e114: LoadField: r4 = r0->field_13
    //     0x112e114: ldur            w4, [x0, #0x13]
    // 0x112e118: DecompressPointer r4
    //     0x112e118: add             x4, x4, HEAP, lsl #32
    // 0x112e11c: stur            x4, [fp, #-0x10]
    // 0x112e120: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x112e120: ldur            w5, [x0, #0x17]
    // 0x112e124: DecompressPointer r5
    //     0x112e124: add             x5, x5, HEAP, lsl #32
    // 0x112e128: stur            x5, [fp, #-8]
    // 0x112e12c: LoadField: r1 = r0->field_f
    //     0x112e12c: ldur            w1, [x0, #0xf]
    // 0x112e130: DecompressPointer r1
    //     0x112e130: add             x1, x1, HEAP, lsl #32
    // 0x112e134: cmp             w1, NULL
    // 0x112e138: b.ne            #0x112e144
    // 0x112e13c: r0 = Null
    //     0x112e13c: mov             x0, NULL
    // 0x112e140: b               #0x112e160
    // 0x112e144: r0 = hashAll()
    //     0x112e144: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x112e148: mov             x2, x0
    // 0x112e14c: r0 = BoxInt64Instr(r2)
    //     0x112e14c: sbfiz           x0, x2, #1, #0x1f
    //     0x112e150: cmp             x2, x0, asr #1
    //     0x112e154: b.eq            #0x112e160
    //     0x112e158: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e15c: stur            x2, [x0, #7]
    // 0x112e160: ldur            x16, [fp, #-0x10]
    // 0x112e164: stp             NULL, x16, [SP, #0x28]
    // 0x112e168: stp             NULL, NULL, [SP, #0x18]
    // 0x112e16c: ldur            x16, [fp, #-8]
    // 0x112e170: stp             x16, NULL, [SP, #8]
    // 0x112e174: str             x0, [SP]
    // 0x112e178: ldur            x1, [fp, #-0x20]
    // 0x112e17c: ldur            x2, [fp, #-0x18]
    // 0x112e180: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x112e180: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x112e184: ldr             x4, [x4, #0x278]
    // 0x112e188: r0 = hash()
    //     0x112e188: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112e18c: mov             x2, x0
    // 0x112e190: r0 = BoxInt64Instr(r2)
    //     0x112e190: sbfiz           x0, x2, #1, #0x1f
    //     0x112e194: cmp             x2, x0, asr #1
    //     0x112e198: b.eq            #0x112e1a4
    //     0x112e19c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e1a0: stur            x2, [x0, #7]
    // 0x112e1a4: LeaveFrame
    //     0x112e1a4: mov             SP, fp
    //     0x112e1a8: ldp             fp, lr, [SP], #0x10
    // 0x112e1ac: ret
    //     0x112e1ac: ret             
    // 0x112e1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112e1b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e1b4: b               #0x112e0d0
  }
  _ getSpanForPositionVisitor(/* No info */) {
    // ** addr: 0x123a14c, size: 0xc0
    // 0x123a14c: EnterFrame
    //     0x123a14c: stp             fp, lr, [SP, #-0x10]!
    //     0x123a150: mov             fp, SP
    // 0x123a154: mov             x0, x1
    // 0x123a158: mov             x1, x3
    // 0x123a15c: CheckStackOverflow
    //     0x123a15c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123a160: cmp             SP, x16
    //     0x123a164: b.ls            #0x123a204
    // 0x123a168: LoadField: r3 = r0->field_b
    //     0x123a168: ldur            w3, [x0, #0xb]
    // 0x123a16c: DecompressPointer r3
    //     0x123a16c: add             x3, x3, HEAP, lsl #32
    // 0x123a170: cmp             w3, NULL
    // 0x123a174: b.eq            #0x123a180
    // 0x123a178: LoadField: r4 = r3->field_7
    //     0x123a178: ldur            w4, [x3, #7]
    // 0x123a17c: cbnz            w4, #0x123a190
    // 0x123a180: r0 = Null
    //     0x123a180: mov             x0, NULL
    // 0x123a184: LeaveFrame
    //     0x123a184: mov             SP, fp
    //     0x123a188: ldp             fp, lr, [SP], #0x10
    // 0x123a18c: ret
    //     0x123a18c: ret             
    // 0x123a190: LoadField: r3 = r2->field_f
    //     0x123a190: ldur            w3, [x2, #0xf]
    // 0x123a194: DecompressPointer r3
    //     0x123a194: add             x3, x3, HEAP, lsl #32
    // 0x123a198: LoadField: r5 = r2->field_7
    //     0x123a198: ldur            x5, [x2, #7]
    // 0x123a19c: LoadField: r2 = r1->field_7
    //     0x123a19c: ldur            x2, [x1, #7]
    // 0x123a1a0: r6 = LoadInt32Instr(r4)
    //     0x123a1a0: sbfx            x6, x4, #1, #0x1f
    // 0x123a1a4: add             x4, x2, x6
    // 0x123a1a8: cmp             x2, x5
    // 0x123a1ac: b.ne            #0x123a1bc
    // 0x123a1b0: r16 = Instance_TextAffinity
    //     0x123a1b0: ldr             x16, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x123a1b4: cmp             w3, w16
    // 0x123a1b8: b.eq            #0x123a1e0
    // 0x123a1bc: cmp             x2, x5
    // 0x123a1c0: b.ge            #0x123a1cc
    // 0x123a1c4: cmp             x5, x4
    // 0x123a1c8: b.lt            #0x123a1e0
    // 0x123a1cc: cmp             x4, x5
    // 0x123a1d0: b.ne            #0x123a1ec
    // 0x123a1d4: r16 = Instance_TextAffinity
    //     0x123a1d4: ldr             x16, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x123a1d8: cmp             w3, w16
    // 0x123a1dc: b.ne            #0x123a1ec
    // 0x123a1e0: LeaveFrame
    //     0x123a1e0: mov             SP, fp
    //     0x123a1e4: ldp             fp, lr, [SP], #0x10
    // 0x123a1e8: ret
    //     0x123a1e8: ret             
    // 0x123a1ec: mov             x2, x6
    // 0x123a1f0: r0 = increment()
    //     0x123a1f0: bl              #0xb98390  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x123a1f4: r0 = Null
    //     0x123a1f4: mov             x0, NULL
    // 0x123a1f8: LeaveFrame
    //     0x123a1f8: mov             SP, fp
    //     0x123a1fc: ldp             fp, lr, [SP], #0x10
    // 0x123a200: ret
    //     0x123a200: ret             
    // 0x123a204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123a204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123a208: b               #0x123a168
  }
  _ ==(/* No info */) {
    // ** addr: 0x125e728, size: 0x1c4
    // 0x125e728: EnterFrame
    //     0x125e728: stp             fp, lr, [SP, #-0x10]!
    //     0x125e72c: mov             fp, SP
    // 0x125e730: AllocStack(0x18)
    //     0x125e730: sub             SP, SP, #0x18
    // 0x125e734: CheckStackOverflow
    //     0x125e734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125e738: cmp             SP, x16
    //     0x125e73c: b.ls            #0x125e8e4
    // 0x125e740: ldr             x0, [fp, #0x10]
    // 0x125e744: cmp             w0, NULL
    // 0x125e748: b.ne            #0x125e75c
    // 0x125e74c: r0 = false
    //     0x125e74c: add             x0, NULL, #0x30  ; false
    // 0x125e750: LeaveFrame
    //     0x125e750: mov             SP, fp
    //     0x125e754: ldp             fp, lr, [SP], #0x10
    // 0x125e758: ret
    //     0x125e758: ret             
    // 0x125e75c: ldr             x1, [fp, #0x18]
    // 0x125e760: cmp             w1, w0
    // 0x125e764: b.ne            #0x125e778
    // 0x125e768: r0 = true
    //     0x125e768: add             x0, NULL, #0x20  ; true
    // 0x125e76c: LeaveFrame
    //     0x125e76c: mov             SP, fp
    //     0x125e770: ldp             fp, lr, [SP], #0x10
    // 0x125e774: ret
    //     0x125e774: ret             
    // 0x125e778: str             x0, [SP]
    // 0x125e77c: r0 = runtimeType()
    //     0x125e77c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x125e780: r1 = LoadClassIdInstr(r0)
    //     0x125e780: ldur            x1, [x0, #-1]
    //     0x125e784: ubfx            x1, x1, #0xc, #0x14
    // 0x125e788: r16 = TextSpan
    //     0x125e788: add             x16, PP, #0x85, lsl #12  ; [pp+0x851c0] Type: TextSpan
    //     0x125e78c: ldr             x16, [x16, #0x1c0]
    // 0x125e790: stp             x16, x0, [SP]
    // 0x125e794: mov             x0, x1
    // 0x125e798: mov             lr, x0
    // 0x125e79c: ldr             lr, [x21, lr, lsl #3]
    // 0x125e7a0: blr             lr
    // 0x125e7a4: tbz             w0, #4, #0x125e7b8
    // 0x125e7a8: r0 = false
    //     0x125e7a8: add             x0, NULL, #0x30  ; false
    // 0x125e7ac: LeaveFrame
    //     0x125e7ac: mov             SP, fp
    //     0x125e7b0: ldp             fp, lr, [SP], #0x10
    // 0x125e7b4: ret
    //     0x125e7b4: ret             
    // 0x125e7b8: ldr             x16, [fp, #0x18]
    // 0x125e7bc: ldr             lr, [fp, #0x10]
    // 0x125e7c0: stp             lr, x16, [SP]
    // 0x125e7c4: r0 = ==()
    //     0x125e7c4: bl              #0x125e62c  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::==
    // 0x125e7c8: tbz             w0, #4, #0x125e7dc
    // 0x125e7cc: r0 = false
    //     0x125e7cc: add             x0, NULL, #0x30  ; false
    // 0x125e7d0: LeaveFrame
    //     0x125e7d0: mov             SP, fp
    //     0x125e7d4: ldp             fp, lr, [SP], #0x10
    // 0x125e7d8: ret
    //     0x125e7d8: ret             
    // 0x125e7dc: ldr             x1, [fp, #0x10]
    // 0x125e7e0: r0 = 60
    //     0x125e7e0: mov             x0, #0x3c
    // 0x125e7e4: branchIfSmi(r1, 0x125e7f0)
    //     0x125e7e4: tbz             w1, #0, #0x125e7f0
    // 0x125e7e8: r0 = LoadClassIdInstr(r1)
    //     0x125e7e8: ldur            x0, [x1, #-1]
    //     0x125e7ec: ubfx            x0, x0, #0xc, #0x14
    // 0x125e7f0: r17 = 5788
    //     0x125e7f0: mov             x17, #0x169c
    // 0x125e7f4: cmp             x0, x17
    // 0x125e7f8: b.ne            #0x125e8d4
    // 0x125e7fc: ldr             x2, [fp, #0x18]
    // 0x125e800: LoadField: r0 = r1->field_b
    //     0x125e800: ldur            w0, [x1, #0xb]
    // 0x125e804: DecompressPointer r0
    //     0x125e804: add             x0, x0, HEAP, lsl #32
    // 0x125e808: LoadField: r3 = r2->field_b
    //     0x125e808: ldur            w3, [x2, #0xb]
    // 0x125e80c: DecompressPointer r3
    //     0x125e80c: add             x3, x3, HEAP, lsl #32
    // 0x125e810: r4 = LoadClassIdInstr(r0)
    //     0x125e810: ldur            x4, [x0, #-1]
    //     0x125e814: ubfx            x4, x4, #0xc, #0x14
    // 0x125e818: stp             x3, x0, [SP]
    // 0x125e81c: mov             x0, x4
    // 0x125e820: mov             lr, x0
    // 0x125e824: ldr             lr, [x21, lr, lsl #3]
    // 0x125e828: blr             lr
    // 0x125e82c: tbnz            w0, #4, #0x125e8d4
    // 0x125e830: ldr             x2, [fp, #0x18]
    // 0x125e834: ldr             x1, [fp, #0x10]
    // 0x125e838: LoadField: r0 = r1->field_13
    //     0x125e838: ldur            w0, [x1, #0x13]
    // 0x125e83c: DecompressPointer r0
    //     0x125e83c: add             x0, x0, HEAP, lsl #32
    // 0x125e840: LoadField: r3 = r2->field_13
    //     0x125e840: ldur            w3, [x2, #0x13]
    // 0x125e844: DecompressPointer r3
    //     0x125e844: add             x3, x3, HEAP, lsl #32
    // 0x125e848: r4 = LoadClassIdInstr(r0)
    //     0x125e848: ldur            x4, [x0, #-1]
    //     0x125e84c: ubfx            x4, x4, #0xc, #0x14
    // 0x125e850: stp             x3, x0, [SP]
    // 0x125e854: mov             x0, x4
    // 0x125e858: mov             lr, x0
    // 0x125e85c: ldr             lr, [x21, lr, lsl #3]
    // 0x125e860: blr             lr
    // 0x125e864: tbnz            w0, #4, #0x125e8d4
    // 0x125e868: ldr             x2, [fp, #0x18]
    // 0x125e86c: ldr             x1, [fp, #0x10]
    // 0x125e870: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x125e870: ldur            w0, [x2, #0x17]
    // 0x125e874: DecompressPointer r0
    //     0x125e874: add             x0, x0, HEAP, lsl #32
    // 0x125e878: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x125e878: ldur            w3, [x1, #0x17]
    // 0x125e87c: DecompressPointer r3
    //     0x125e87c: add             x3, x3, HEAP, lsl #32
    // 0x125e880: r4 = LoadClassIdInstr(r0)
    //     0x125e880: ldur            x4, [x0, #-1]
    //     0x125e884: ubfx            x4, x4, #0xc, #0x14
    // 0x125e888: stp             x3, x0, [SP]
    // 0x125e88c: mov             x0, x4
    // 0x125e890: mov             lr, x0
    // 0x125e894: ldr             lr, [x21, lr, lsl #3]
    // 0x125e898: blr             lr
    // 0x125e89c: tbnz            w0, #4, #0x125e8d4
    // 0x125e8a0: ldr             x1, [fp, #0x18]
    // 0x125e8a4: ldr             x0, [fp, #0x10]
    // 0x125e8a8: LoadField: r2 = r0->field_f
    //     0x125e8a8: ldur            w2, [x0, #0xf]
    // 0x125e8ac: DecompressPointer r2
    //     0x125e8ac: add             x2, x2, HEAP, lsl #32
    // 0x125e8b0: LoadField: r0 = r1->field_f
    //     0x125e8b0: ldur            w0, [x1, #0xf]
    // 0x125e8b4: DecompressPointer r0
    //     0x125e8b4: add             x0, x0, HEAP, lsl #32
    // 0x125e8b8: r16 = <InlineSpan>
    //     0x125e8b8: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aa80] TypeArguments: <InlineSpan>
    //     0x125e8bc: ldr             x16, [x16, #0xa80]
    // 0x125e8c0: stp             x2, x16, [SP, #8]
    // 0x125e8c4: str             x0, [SP]
    // 0x125e8c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x125e8c8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x125e8cc: r0 = listEquals()
    //     0x125e8cc: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x125e8d0: b               #0x125e8d8
    // 0x125e8d4: r0 = false
    //     0x125e8d4: add             x0, NULL, #0x30  ; false
    // 0x125e8d8: LeaveFrame
    //     0x125e8d8: mov             SP, fp
    //     0x125e8dc: ldp             fp, lr, [SP], #0x10
    // 0x125e8e0: ret
    //     0x125e8e0: ret             
    // 0x125e8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125e8e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125e8e8: b               #0x125e740
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x125eb34, size: 0x1a0
    // 0x125eb34: EnterFrame
    //     0x125eb34: stp             fp, lr, [SP, #-0x10]!
    //     0x125eb38: mov             fp, SP
    // 0x125eb3c: AllocStack(0x40)
    //     0x125eb3c: sub             SP, SP, #0x40
    // 0x125eb40: SetupParameters(TextSpan this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x125eb40: stur            x1, [fp, #-8]
    //     0x125eb44: mov             x16, x2
    //     0x125eb48: mov             x2, x1
    //     0x125eb4c: mov             x1, x16
    //     0x125eb50: stur            x1, [fp, #-0x10]
    // 0x125eb54: CheckStackOverflow
    //     0x125eb54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125eb58: cmp             SP, x16
    //     0x125eb5c: b.ls            #0x125ecc4
    // 0x125eb60: LoadField: r0 = r2->field_b
    //     0x125eb60: ldur            w0, [x2, #0xb]
    // 0x125eb64: DecompressPointer r0
    //     0x125eb64: add             x0, x0, HEAP, lsl #32
    // 0x125eb68: cmp             w0, NULL
    // 0x125eb6c: b.eq            #0x125eba0
    // 0x125eb70: stp             x2, x1, [SP]
    // 0x125eb74: mov             x0, x1
    // 0x125eb78: ClosureCall
    //     0x125eb78: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x125eb7c: ldur            x2, [x0, #0x1f]
    //     0x125eb80: blr             x2
    // 0x125eb84: r16 = true
    //     0x125eb84: add             x16, NULL, #0x20  ; true
    // 0x125eb88: cmp             w0, w16
    // 0x125eb8c: b.eq            #0x125eba0
    // 0x125eb90: r0 = false
    //     0x125eb90: add             x0, NULL, #0x30  ; false
    // 0x125eb94: LeaveFrame
    //     0x125eb94: mov             SP, fp
    //     0x125eb98: ldp             fp, lr, [SP], #0x10
    // 0x125eb9c: ret
    //     0x125eb9c: ret             
    // 0x125eba0: ldur            x0, [fp, #-8]
    // 0x125eba4: LoadField: r3 = r0->field_f
    //     0x125eba4: ldur            w3, [x0, #0xf]
    // 0x125eba8: DecompressPointer r3
    //     0x125eba8: add             x3, x3, HEAP, lsl #32
    // 0x125ebac: stur            x3, [fp, #-0x30]
    // 0x125ebb0: cmp             w3, NULL
    // 0x125ebb4: b.eq            #0x125ec94
    // 0x125ebb8: LoadField: r4 = r3->field_7
    //     0x125ebb8: ldur            w4, [x3, #7]
    // 0x125ebbc: DecompressPointer r4
    //     0x125ebbc: add             x4, x4, HEAP, lsl #32
    // 0x125ebc0: stur            x4, [fp, #-0x28]
    // 0x125ebc4: LoadField: r0 = r3->field_b
    //     0x125ebc4: ldur            w0, [x3, #0xb]
    // 0x125ebc8: r5 = LoadInt32Instr(r0)
    //     0x125ebc8: sbfx            x5, x0, #1, #0x1f
    // 0x125ebcc: stur            x5, [fp, #-0x20]
    // 0x125ebd0: r0 = 0
    //     0x125ebd0: mov             x0, #0
    // 0x125ebd4: CheckStackOverflow
    //     0x125ebd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125ebd8: cmp             SP, x16
    //     0x125ebdc: b.ls            #0x125eccc
    // 0x125ebe0: LoadField: r1 = r3->field_b
    //     0x125ebe0: ldur            w1, [x3, #0xb]
    // 0x125ebe4: r2 = LoadInt32Instr(r1)
    //     0x125ebe4: sbfx            x2, x1, #1, #0x1f
    // 0x125ebe8: cmp             x5, x2
    // 0x125ebec: b.ne            #0x125eca4
    // 0x125ebf0: cmp             x0, x2
    // 0x125ebf4: b.ge            #0x125ec94
    // 0x125ebf8: LoadField: r1 = r3->field_f
    //     0x125ebf8: ldur            w1, [x3, #0xf]
    // 0x125ebfc: DecompressPointer r1
    //     0x125ebfc: add             x1, x1, HEAP, lsl #32
    // 0x125ec00: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x125ec00: add             x16, x1, x0, lsl #2
    //     0x125ec04: ldur            w6, [x16, #0xf]
    // 0x125ec08: DecompressPointer r6
    //     0x125ec08: add             x6, x6, HEAP, lsl #32
    // 0x125ec0c: stur            x6, [fp, #-8]
    // 0x125ec10: add             x7, x0, #1
    // 0x125ec14: stur            x7, [fp, #-0x18]
    // 0x125ec18: cmp             w6, NULL
    // 0x125ec1c: b.ne            #0x125ec50
    // 0x125ec20: mov             x0, x6
    // 0x125ec24: mov             x2, x4
    // 0x125ec28: r1 = Null
    //     0x125ec28: mov             x1, NULL
    // 0x125ec2c: cmp             w2, NULL
    // 0x125ec30: b.eq            #0x125ec50
    // 0x125ec34: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x125ec34: ldur            w4, [x2, #0x17]
    // 0x125ec38: DecompressPointer r4
    //     0x125ec38: add             x4, x4, HEAP, lsl #32
    // 0x125ec3c: r8 = X0
    //     0x125ec3c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x125ec40: LoadField: r9 = r4->field_7
    //     0x125ec40: ldur            x9, [x4, #7]
    // 0x125ec44: r3 = Null
    //     0x125ec44: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a158] Null
    //     0x125ec48: ldr             x3, [x3, #0x158]
    // 0x125ec4c: blr             x9
    // 0x125ec50: ldur            x1, [fp, #-8]
    // 0x125ec54: r0 = LoadClassIdInstr(r1)
    //     0x125ec54: ldur            x0, [x1, #-1]
    //     0x125ec58: ubfx            x0, x0, #0xc, #0x14
    // 0x125ec5c: ldur            x2, [fp, #-0x10]
    // 0x125ec60: r0 = GDT[cid_x0 + -0x18]()
    //     0x125ec60: sub             lr, x0, #0x18
    //     0x125ec64: ldr             lr, [x21, lr, lsl #3]
    //     0x125ec68: blr             lr
    // 0x125ec6c: tbnz            w0, #4, #0x125ec84
    // 0x125ec70: ldur            x0, [fp, #-0x18]
    // 0x125ec74: ldur            x3, [fp, #-0x30]
    // 0x125ec78: ldur            x4, [fp, #-0x28]
    // 0x125ec7c: ldur            x5, [fp, #-0x20]
    // 0x125ec80: b               #0x125ebd4
    // 0x125ec84: r0 = false
    //     0x125ec84: add             x0, NULL, #0x30  ; false
    // 0x125ec88: LeaveFrame
    //     0x125ec88: mov             SP, fp
    //     0x125ec8c: ldp             fp, lr, [SP], #0x10
    // 0x125ec90: ret
    //     0x125ec90: ret             
    // 0x125ec94: r0 = true
    //     0x125ec94: add             x0, NULL, #0x20  ; true
    // 0x125ec98: LeaveFrame
    //     0x125ec98: mov             SP, fp
    //     0x125ec9c: ldp             fp, lr, [SP], #0x10
    // 0x125eca0: ret
    //     0x125eca0: ret             
    // 0x125eca4: mov             x0, x3
    // 0x125eca8: r0 = ConcurrentModificationError()
    //     0x125eca8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x125ecac: mov             x1, x0
    // 0x125ecb0: ldur            x0, [fp, #-0x30]
    // 0x125ecb4: StoreField: r1->field_b = r0
    //     0x125ecb4: stur            w0, [x1, #0xb]
    // 0x125ecb8: mov             x0, x1
    // 0x125ecbc: r0 = Throw()
    //     0x125ecbc: bl              #0x13ddb2c  ; ThrowStub
    // 0x125ecc0: brk             #0
    // 0x125ecc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125ecc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125ecc8: b               #0x125eb60
    // 0x125eccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125eccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125ecd0: b               #0x125ebe0
  }
  _ computeSemanticsInformation(/* No info */) {
    // ** addr: 0x125ee34, size: 0x3e4
    // 0x125ee34: EnterFrame
    //     0x125ee34: stp             fp, lr, [SP, #-0x10]!
    //     0x125ee38: mov             fp, SP
    // 0x125ee3c: AllocStack(0x50)
    //     0x125ee3c: sub             SP, SP, #0x50
    // 0x125ee40: SetupParameters(TextSpan this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x28 */, {dynamic inheritedSpellOut = false /* r4, fp-0x18 */})
    //     0x125ee40: mov             x3, x1
    //     0x125ee44: mov             x0, x2
    //     0x125ee48: stur            x1, [fp, #-0x20]
    //     0x125ee4c: stur            x2, [fp, #-0x28]
    //     0x125ee50: ldur            w1, [x4, #0x13]
    //     0x125ee54: ldur            w2, [x4, #0x1f]
    //     0x125ee58: add             x2, x2, HEAP, lsl #32
    //     0x125ee5c: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4198] "inheritedSpellOut"
    //     0x125ee60: ldr             x16, [x16, #0x198]
    //     0x125ee64: cmp             w2, w16
    //     0x125ee68: b.ne            #0x125ee88
    //     0x125ee6c: ldur            w2, [x4, #0x23]
    //     0x125ee70: add             x2, x2, HEAP, lsl #32
    //     0x125ee74: sub             w4, w1, w2
    //     0x125ee78: add             x1, fp, w4, sxtw #2
    //     0x125ee7c: ldr             x1, [x1, #8]
    //     0x125ee80: mov             x4, x1
    //     0x125ee84: b               #0x125ee8c
    //     0x125ee88: add             x4, NULL, #0x30  ; false
    //     0x125ee8c: stur            x4, [fp, #-0x18]
    // 0x125ee90: CheckStackOverflow
    //     0x125ee90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125ee94: cmp             SP, x16
    //     0x125ee98: b.ls            #0x125f208
    // 0x125ee9c: LoadField: r5 = r3->field_b
    //     0x125ee9c: ldur            w5, [x3, #0xb]
    // 0x125eea0: DecompressPointer r5
    //     0x125eea0: add             x5, x5, HEAP, lsl #32
    // 0x125eea4: stur            x5, [fp, #-0x10]
    // 0x125eea8: cmp             w5, NULL
    // 0x125eeac: b.eq            #0x125f0b4
    // 0x125eeb0: LoadField: r6 = r5->field_7
    //     0x125eeb0: ldur            w6, [x5, #7]
    // 0x125eeb4: stur            x6, [fp, #-8]
    // 0x125eeb8: r1 = <StringAttribute>
    //     0x125eeb8: ldr             x1, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0x125eebc: r2 = 0
    //     0x125eebc: mov             x2, #0
    // 0x125eec0: r0 = _GrowableList()
    //     0x125eec0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x125eec4: mov             x1, x0
    // 0x125eec8: ldur            x0, [fp, #-0x18]
    // 0x125eecc: stur            x1, [fp, #-0x38]
    // 0x125eed0: tbnz            w0, #4, #0x125efa4
    // 0x125eed4: ldur            x2, [fp, #-8]
    // 0x125eed8: r3 = LoadInt32Instr(r2)
    //     0x125eed8: sbfx            x3, x2, #1, #0x1f
    // 0x125eedc: stur            x3, [fp, #-0x30]
    // 0x125eee0: cmp             x3, #0
    // 0x125eee4: b.le            #0x125ef9c
    // 0x125eee8: r0 = TextRange()
    //     0x125eee8: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x125eeec: stur            x0, [fp, #-8]
    // 0x125eef0: StoreField: r0->field_7 = rZR
    //     0x125eef0: stur            xzr, [x0, #7]
    // 0x125eef4: ldur            x3, [fp, #-0x30]
    // 0x125eef8: StoreField: r0->field_f = r3
    //     0x125eef8: stur            x3, [x0, #0xf]
    // 0x125eefc: r0 = SpellOutStringAttribute()
    //     0x125eefc: bl              #0x125f3dc  ; AllocateSpellOutStringAttributeStub -> SpellOutStringAttribute (size=0x10)
    // 0x125ef00: mov             x4, x0
    // 0x125ef04: ldur            x0, [fp, #-8]
    // 0x125ef08: stur            x4, [fp, #-0x40]
    // 0x125ef0c: StoreField: r4->field_b = r0
    //     0x125ef0c: stur            w0, [x4, #0xb]
    // 0x125ef10: mov             x1, x4
    // 0x125ef14: ldur            x3, [fp, #-0x30]
    // 0x125ef18: r2 = 0
    //     0x125ef18: mov             x2, #0
    // 0x125ef1c: r0 = _initSpellOutStringAttribute()
    //     0x125ef1c: bl              #0x125f218  ; [dart:ui] SpellOutStringAttribute::_initSpellOutStringAttribute
    // 0x125ef20: ldur            x0, [fp, #-0x38]
    // 0x125ef24: LoadField: r1 = r0->field_b
    //     0x125ef24: ldur            w1, [x0, #0xb]
    // 0x125ef28: LoadField: r2 = r0->field_f
    //     0x125ef28: ldur            w2, [x0, #0xf]
    // 0x125ef2c: DecompressPointer r2
    //     0x125ef2c: add             x2, x2, HEAP, lsl #32
    // 0x125ef30: LoadField: r3 = r2->field_b
    //     0x125ef30: ldur            w3, [x2, #0xb]
    // 0x125ef34: r2 = LoadInt32Instr(r1)
    //     0x125ef34: sbfx            x2, x1, #1, #0x1f
    // 0x125ef38: stur            x2, [fp, #-0x30]
    // 0x125ef3c: r1 = LoadInt32Instr(r3)
    //     0x125ef3c: sbfx            x1, x3, #1, #0x1f
    // 0x125ef40: cmp             x2, x1
    // 0x125ef44: b.ne            #0x125ef50
    // 0x125ef48: mov             x1, x0
    // 0x125ef4c: r0 = _growToNextCapacity()
    //     0x125ef4c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125ef50: ldur            x2, [fp, #-0x38]
    // 0x125ef54: ldur            x3, [fp, #-0x30]
    // 0x125ef58: add             x0, x3, #1
    // 0x125ef5c: lsl             x1, x0, #1
    // 0x125ef60: StoreField: r2->field_b = r1
    //     0x125ef60: stur            w1, [x2, #0xb]
    // 0x125ef64: LoadField: r1 = r2->field_f
    //     0x125ef64: ldur            w1, [x2, #0xf]
    // 0x125ef68: DecompressPointer r1
    //     0x125ef68: add             x1, x1, HEAP, lsl #32
    // 0x125ef6c: ldur            x0, [fp, #-0x40]
    // 0x125ef70: ArrayStore: r1[r3] = r0  ; List_4
    //     0x125ef70: add             x25, x1, x3, lsl #2
    //     0x125ef74: add             x25, x25, #0xf
    //     0x125ef78: str             w0, [x25]
    //     0x125ef7c: tbz             w0, #0, #0x125ef98
    //     0x125ef80: ldurb           w16, [x1, #-1]
    //     0x125ef84: ldurb           w17, [x0, #-1]
    //     0x125ef88: and             x16, x17, x16, lsr #2
    //     0x125ef8c: tst             x16, HEAP, lsr #32
    //     0x125ef90: b.eq            #0x125ef98
    //     0x125ef94: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125ef98: b               #0x125efa8
    // 0x125ef9c: mov             x2, x1
    // 0x125efa0: b               #0x125efa8
    // 0x125efa4: mov             x2, x1
    // 0x125efa8: ldur            x0, [fp, #-0x20]
    // 0x125efac: ldur            x1, [fp, #-0x10]
    // 0x125efb0: LoadField: r3 = r0->field_13
    //     0x125efb0: ldur            w3, [x0, #0x13]
    // 0x125efb4: DecompressPointer r3
    //     0x125efb4: add             x3, x3, HEAP, lsl #32
    // 0x125efb8: stur            x3, [fp, #-8]
    // 0x125efbc: r0 = InlineSpanSemanticsInformation()
    //     0x125efbc: bl              #0xbfaed4  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x24)
    // 0x125efc0: mov             x3, x0
    // 0x125efc4: ldur            x0, [fp, #-0x10]
    // 0x125efc8: stur            x3, [fp, #-0x40]
    // 0x125efcc: StoreField: r3->field_7 = r0
    //     0x125efcc: stur            w0, [x3, #7]
    // 0x125efd0: r0 = false
    //     0x125efd0: add             x0, NULL, #0x30  ; false
    // 0x125efd4: ArrayStore: r3[0] = r0  ; List_4
    //     0x125efd4: stur            w0, [x3, #0x17]
    // 0x125efd8: ldur            x0, [fp, #-0x38]
    // 0x125efdc: StoreField: r3->field_1f = r0
    //     0x125efdc: stur            w0, [x3, #0x1f]
    // 0x125efe0: ldur            x0, [fp, #-8]
    // 0x125efe4: StoreField: r3->field_13 = r0
    //     0x125efe4: stur            w0, [x3, #0x13]
    // 0x125efe8: cmp             w0, NULL
    // 0x125efec: b.eq            #0x125eff8
    // 0x125eff0: r0 = true
    //     0x125eff0: add             x0, NULL, #0x20  ; true
    // 0x125eff4: b               #0x125effc
    // 0x125eff8: r0 = false
    //     0x125eff8: add             x0, NULL, #0x30  ; false
    // 0x125effc: ldur            x4, [fp, #-0x28]
    // 0x125f000: StoreField: r3->field_1b = r0
    //     0x125f000: stur            w0, [x3, #0x1b]
    // 0x125f004: LoadField: r2 = r4->field_7
    //     0x125f004: ldur            w2, [x4, #7]
    // 0x125f008: DecompressPointer r2
    //     0x125f008: add             x2, x2, HEAP, lsl #32
    // 0x125f00c: mov             x0, x3
    // 0x125f010: r1 = Null
    //     0x125f010: mov             x1, NULL
    // 0x125f014: cmp             w2, NULL
    // 0x125f018: b.eq            #0x125f038
    // 0x125f01c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x125f01c: ldur            w4, [x2, #0x17]
    // 0x125f020: DecompressPointer r4
    //     0x125f020: add             x4, x4, HEAP, lsl #32
    // 0x125f024: r8 = X0
    //     0x125f024: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x125f028: LoadField: r9 = r4->field_7
    //     0x125f028: ldur            x9, [x4, #7]
    // 0x125f02c: r3 = Null
    //     0x125f02c: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa41a0] Null
    //     0x125f030: ldr             x3, [x3, #0x1a0]
    // 0x125f034: blr             x9
    // 0x125f038: ldur            x0, [fp, #-0x28]
    // 0x125f03c: LoadField: r1 = r0->field_b
    //     0x125f03c: ldur            w1, [x0, #0xb]
    // 0x125f040: LoadField: r2 = r0->field_f
    //     0x125f040: ldur            w2, [x0, #0xf]
    // 0x125f044: DecompressPointer r2
    //     0x125f044: add             x2, x2, HEAP, lsl #32
    // 0x125f048: LoadField: r3 = r2->field_b
    //     0x125f048: ldur            w3, [x2, #0xb]
    // 0x125f04c: r2 = LoadInt32Instr(r1)
    //     0x125f04c: sbfx            x2, x1, #1, #0x1f
    // 0x125f050: stur            x2, [fp, #-0x30]
    // 0x125f054: r1 = LoadInt32Instr(r3)
    //     0x125f054: sbfx            x1, x3, #1, #0x1f
    // 0x125f058: cmp             x2, x1
    // 0x125f05c: b.ne            #0x125f068
    // 0x125f060: mov             x1, x0
    // 0x125f064: r0 = _growToNextCapacity()
    //     0x125f064: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125f068: ldur            x3, [fp, #-0x28]
    // 0x125f06c: ldur            x2, [fp, #-0x30]
    // 0x125f070: add             x0, x2, #1
    // 0x125f074: lsl             x1, x0, #1
    // 0x125f078: StoreField: r3->field_b = r1
    //     0x125f078: stur            w1, [x3, #0xb]
    // 0x125f07c: LoadField: r1 = r3->field_f
    //     0x125f07c: ldur            w1, [x3, #0xf]
    // 0x125f080: DecompressPointer r1
    //     0x125f080: add             x1, x1, HEAP, lsl #32
    // 0x125f084: ldur            x0, [fp, #-0x40]
    // 0x125f088: ArrayStore: r1[r2] = r0  ; List_4
    //     0x125f088: add             x25, x1, x2, lsl #2
    //     0x125f08c: add             x25, x25, #0xf
    //     0x125f090: str             w0, [x25]
    //     0x125f094: tbz             w0, #0, #0x125f0b0
    //     0x125f098: ldurb           w16, [x1, #-1]
    //     0x125f09c: ldurb           w17, [x0, #-1]
    //     0x125f0a0: and             x16, x17, x16, lsr #2
    //     0x125f0a4: tst             x16, HEAP, lsr #32
    //     0x125f0a8: b.eq            #0x125f0b0
    //     0x125f0ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125f0b0: b               #0x125f0b8
    // 0x125f0b4: mov             x3, x0
    // 0x125f0b8: ldur            x0, [fp, #-0x20]
    // 0x125f0bc: LoadField: r4 = r0->field_f
    //     0x125f0bc: ldur            w4, [x0, #0xf]
    // 0x125f0c0: DecompressPointer r4
    //     0x125f0c0: add             x4, x4, HEAP, lsl #32
    // 0x125f0c4: stur            x4, [fp, #-0x38]
    // 0x125f0c8: cmp             w4, NULL
    // 0x125f0cc: b.eq            #0x125f1d8
    // 0x125f0d0: LoadField: r5 = r4->field_7
    //     0x125f0d0: ldur            w5, [x4, #7]
    // 0x125f0d4: DecompressPointer r5
    //     0x125f0d4: add             x5, x5, HEAP, lsl #32
    // 0x125f0d8: stur            x5, [fp, #-0x10]
    // 0x125f0dc: LoadField: r0 = r4->field_b
    //     0x125f0dc: ldur            w0, [x4, #0xb]
    // 0x125f0e0: r6 = LoadInt32Instr(r0)
    //     0x125f0e0: sbfx            x6, x0, #1, #0x1f
    // 0x125f0e4: stur            x6, [fp, #-0x48]
    // 0x125f0e8: r0 = 0
    //     0x125f0e8: mov             x0, #0
    // 0x125f0ec: CheckStackOverflow
    //     0x125f0ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125f0f0: cmp             SP, x16
    //     0x125f0f4: b.ls            #0x125f210
    // 0x125f0f8: LoadField: r1 = r4->field_b
    //     0x125f0f8: ldur            w1, [x4, #0xb]
    // 0x125f0fc: r2 = LoadInt32Instr(r1)
    //     0x125f0fc: sbfx            x2, x1, #1, #0x1f
    // 0x125f100: cmp             x6, x2
    // 0x125f104: b.ne            #0x125f1e8
    // 0x125f108: cmp             x0, x2
    // 0x125f10c: b.ge            #0x125f1d8
    // 0x125f110: LoadField: r1 = r4->field_f
    //     0x125f110: ldur            w1, [x4, #0xf]
    // 0x125f114: DecompressPointer r1
    //     0x125f114: add             x1, x1, HEAP, lsl #32
    // 0x125f118: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x125f118: add             x16, x1, x0, lsl #2
    //     0x125f11c: ldur            w7, [x16, #0xf]
    // 0x125f120: DecompressPointer r7
    //     0x125f120: add             x7, x7, HEAP, lsl #32
    // 0x125f124: stur            x7, [fp, #-8]
    // 0x125f128: add             x8, x0, #1
    // 0x125f12c: stur            x8, [fp, #-0x30]
    // 0x125f130: cmp             w7, NULL
    // 0x125f134: b.ne            #0x125f168
    // 0x125f138: mov             x0, x7
    // 0x125f13c: mov             x2, x5
    // 0x125f140: r1 = Null
    //     0x125f140: mov             x1, NULL
    // 0x125f144: cmp             w2, NULL
    // 0x125f148: b.eq            #0x125f168
    // 0x125f14c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x125f14c: ldur            w4, [x2, #0x17]
    // 0x125f150: DecompressPointer r4
    //     0x125f150: add             x4, x4, HEAP, lsl #32
    // 0x125f154: r8 = X0
    //     0x125f154: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x125f158: LoadField: r9 = r4->field_7
    //     0x125f158: ldur            x9, [x4, #7]
    // 0x125f15c: r3 = Null
    //     0x125f15c: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa41b0] Null
    //     0x125f160: ldr             x3, [x3, #0x1b0]
    // 0x125f164: blr             x9
    // 0x125f168: ldur            x1, [fp, #-8]
    // 0x125f16c: r0 = 60
    //     0x125f16c: mov             x0, #0x3c
    // 0x125f170: branchIfSmi(r1, 0x125f17c)
    //     0x125f170: tbz             w1, #0, #0x125f17c
    // 0x125f174: r0 = LoadClassIdInstr(r1)
    //     0x125f174: ldur            x0, [x1, #-1]
    //     0x125f178: ubfx            x0, x0, #0xc, #0x14
    // 0x125f17c: r17 = 5788
    //     0x125f17c: mov             x17, #0x169c
    // 0x125f180: cmp             x0, x17
    // 0x125f184: b.ne            #0x125f1a4
    // 0x125f188: ldur            x16, [fp, #-0x18]
    // 0x125f18c: str             x16, [SP]
    // 0x125f190: ldur            x2, [fp, #-0x28]
    // 0x125f194: r4 = const [0, 0x3, 0x1, 0x2, inheritedSpellOut, 0x2, null]
    //     0x125f194: add             x4, PP, #0xa4, lsl #12  ; [pp+0xa41c0] List(7) [0, 0x3, 0x1, 0x2, "inheritedSpellOut", 0x2, Null]
    //     0x125f198: ldr             x4, [x4, #0x1c0]
    // 0x125f19c: r0 = computeSemanticsInformation()
    //     0x125f19c: bl              #0x125ee34  ; [package:flutter/src/painting/text_span.dart] TextSpan::computeSemanticsInformation
    // 0x125f1a0: b               #0x125f1c0
    // 0x125f1a4: r0 = LoadClassIdInstr(r1)
    //     0x125f1a4: ldur            x0, [x1, #-1]
    //     0x125f1a8: ubfx            x0, x0, #0xc, #0x14
    // 0x125f1ac: ldur            x2, [fp, #-0x28]
    // 0x125f1b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x125f1b0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x125f1b4: r0 = GDT[cid_x0 + -0x5c]()
    //     0x125f1b4: sub             lr, x0, #0x5c
    //     0x125f1b8: ldr             lr, [x21, lr, lsl #3]
    //     0x125f1bc: blr             lr
    // 0x125f1c0: ldur            x0, [fp, #-0x30]
    // 0x125f1c4: ldur            x3, [fp, #-0x28]
    // 0x125f1c8: ldur            x4, [fp, #-0x38]
    // 0x125f1cc: ldur            x5, [fp, #-0x10]
    // 0x125f1d0: ldur            x6, [fp, #-0x48]
    // 0x125f1d4: b               #0x125f0ec
    // 0x125f1d8: r0 = Null
    //     0x125f1d8: mov             x0, NULL
    // 0x125f1dc: LeaveFrame
    //     0x125f1dc: mov             SP, fp
    //     0x125f1e0: ldp             fp, lr, [SP], #0x10
    // 0x125f1e4: ret
    //     0x125f1e4: ret             
    // 0x125f1e8: mov             x0, x4
    // 0x125f1ec: r0 = ConcurrentModificationError()
    //     0x125f1ec: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x125f1f0: mov             x1, x0
    // 0x125f1f4: ldur            x0, [fp, #-0x38]
    // 0x125f1f8: StoreField: r1->field_b = r0
    //     0x125f1f8: stur            w0, [x1, #0xb]
    // 0x125f1fc: mov             x0, x1
    // 0x125f200: r0 = Throw()
    //     0x125f200: bl              #0x13ddb2c  ; ThrowStub
    // 0x125f204: brk             #0
    // 0x125f208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125f208: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125f20c: b               #0x125ee9c
    // 0x125f210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125f210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125f214: b               #0x125f0f8
  }
  _ computeToPlainText(/* No info */) {
    // ** addr: 0x12615d4, size: 0x118
    // 0x12615d4: EnterFrame
    //     0x12615d4: stp             fp, lr, [SP, #-0x10]!
    //     0x12615d8: mov             fp, SP
    // 0x12615dc: AllocStack(0x28)
    //     0x12615dc: sub             SP, SP, #0x28
    // 0x12615e0: SetupParameters(TextSpan this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12615e0: mov             x4, x1
    //     0x12615e4: mov             x0, x2
    //     0x12615e8: stur            x1, [fp, #-8]
    //     0x12615ec: stur            x2, [fp, #-0x10]
    // 0x12615f0: CheckStackOverflow
    //     0x12615f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12615f4: cmp             SP, x16
    //     0x12615f8: b.ls            #0x12616dc
    // 0x12615fc: LoadField: r2 = r4->field_b
    //     0x12615fc: ldur            w2, [x4, #0xb]
    // 0x1261600: DecompressPointer r2
    //     0x1261600: add             x2, x2, HEAP, lsl #32
    // 0x1261604: cmp             w2, NULL
    // 0x1261608: b.eq            #0x1261614
    // 0x126160c: mov             x1, x0
    // 0x1261610: r0 = write()
    //     0x1261610: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x1261614: ldur            x0, [fp, #-8]
    // 0x1261618: LoadField: r4 = r0->field_f
    //     0x1261618: ldur            w4, [x0, #0xf]
    // 0x126161c: DecompressPointer r4
    //     0x126161c: add             x4, x4, HEAP, lsl #32
    // 0x1261620: stur            x4, [fp, #-0x28]
    // 0x1261624: cmp             w4, NULL
    // 0x1261628: b.eq            #0x12616ac
    // 0x126162c: LoadField: r0 = r4->field_b
    //     0x126162c: ldur            w0, [x4, #0xb]
    // 0x1261630: r5 = LoadInt32Instr(r0)
    //     0x1261630: sbfx            x5, x0, #1, #0x1f
    // 0x1261634: stur            x5, [fp, #-0x20]
    // 0x1261638: r0 = 0
    //     0x1261638: mov             x0, #0
    // 0x126163c: CheckStackOverflow
    //     0x126163c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1261640: cmp             SP, x16
    //     0x1261644: b.ls            #0x12616e4
    // 0x1261648: LoadField: r1 = r4->field_b
    //     0x1261648: ldur            w1, [x4, #0xb]
    // 0x126164c: r2 = LoadInt32Instr(r1)
    //     0x126164c: sbfx            x2, x1, #1, #0x1f
    // 0x1261650: cmp             x5, x2
    // 0x1261654: b.ne            #0x12616bc
    // 0x1261658: cmp             x0, x2
    // 0x126165c: b.ge            #0x12616ac
    // 0x1261660: LoadField: r1 = r4->field_f
    //     0x1261660: ldur            w1, [x4, #0xf]
    // 0x1261664: DecompressPointer r1
    //     0x1261664: add             x1, x1, HEAP, lsl #32
    // 0x1261668: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0x1261668: add             x16, x1, x0, lsl #2
    //     0x126166c: ldur            w2, [x16, #0xf]
    // 0x1261670: DecompressPointer r2
    //     0x1261670: add             x2, x2, HEAP, lsl #32
    // 0x1261674: add             x6, x0, #1
    // 0x1261678: stur            x6, [fp, #-0x18]
    // 0x126167c: r0 = LoadClassIdInstr(r2)
    //     0x126167c: ldur            x0, [x2, #-1]
    //     0x1261680: ubfx            x0, x0, #0xc, #0x14
    // 0x1261684: mov             x1, x2
    // 0x1261688: ldur            x2, [fp, #-0x10]
    // 0x126168c: r3 = true
    //     0x126168c: add             x3, NULL, #0x20  ; true
    // 0x1261690: r0 = GDT[cid_x0 + -0x8a]()
    //     0x1261690: sub             lr, x0, #0x8a
    //     0x1261694: ldr             lr, [x21, lr, lsl #3]
    //     0x1261698: blr             lr
    // 0x126169c: ldur            x0, [fp, #-0x18]
    // 0x12616a0: ldur            x4, [fp, #-0x28]
    // 0x12616a4: ldur            x5, [fp, #-0x20]
    // 0x12616a8: b               #0x126163c
    // 0x12616ac: r0 = Null
    //     0x12616ac: mov             x0, NULL
    // 0x12616b0: LeaveFrame
    //     0x12616b0: mov             SP, fp
    //     0x12616b4: ldp             fp, lr, [SP], #0x10
    // 0x12616b8: ret
    //     0x12616b8: ret             
    // 0x12616bc: mov             x0, x4
    // 0x12616c0: r0 = ConcurrentModificationError()
    //     0x12616c0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x12616c4: mov             x1, x0
    // 0x12616c8: ldur            x0, [fp, #-0x28]
    // 0x12616cc: StoreField: r1->field_b = r0
    //     0x12616cc: stur            w0, [x1, #0xb]
    // 0x12616d0: mov             x0, x1
    // 0x12616d4: r0 = Throw()
    //     0x12616d4: bl              #0x13ddb2c  ; ThrowStub
    // 0x12616d8: brk             #0
    // 0x12616dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12616dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12616e0: b               #0x12615fc
    // 0x12616e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12616e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12616e8: b               #0x1261648
  }
  _ build(/* No info */) {
    // ** addr: 0x1261cd4, size: 0x31c
    // 0x1261cd4: EnterFrame
    //     0x1261cd4: stp             fp, lr, [SP, #-0x10]!
    //     0x1261cd8: mov             fp, SP
    // 0x1261cdc: AllocStack(0xc0)
    //     0x1261cdc: sub             SP, SP, #0xc0
    // 0x1261ce0: SetupParameters(TextSpan this /* r1 => r5, fp-0x68 */, dynamic _ /* r2 => r4, fp-0x70 */, dynamic _ /* r3 => r3, fp-0x78 */, dynamic _ /* r5 => r0, fp-0x80 */)
    //     0x1261ce0: mov             x0, x5
    //     0x1261ce4: stur            x5, [fp, #-0x80]
    //     0x1261ce8: mov             x5, x1
    //     0x1261cec: mov             x4, x2
    //     0x1261cf0: stur            x1, [fp, #-0x68]
    //     0x1261cf4: stur            x2, [fp, #-0x70]
    //     0x1261cf8: stur            x3, [fp, #-0x78]
    // 0x1261cfc: CheckStackOverflow
    //     0x1261cfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1261d00: cmp             SP, x16
    //     0x1261d04: b.ls            #0x1261fd8
    // 0x1261d08: LoadField: r1 = r5->field_7
    //     0x1261d08: ldur            w1, [x5, #7]
    // 0x1261d0c: DecompressPointer r1
    //     0x1261d0c: add             x1, x1, HEAP, lsl #32
    // 0x1261d10: cmp             w1, NULL
    // 0x1261d14: r16 = true
    //     0x1261d14: add             x16, NULL, #0x20  ; true
    // 0x1261d18: r17 = false
    //     0x1261d18: add             x17, NULL, #0x30  ; false
    // 0x1261d1c: csel            x6, x16, x17, ne
    // 0x1261d20: stur            x6, [fp, #-0x60]
    // 0x1261d24: tbnz            w6, #4, #0x1261d44
    // 0x1261d28: cmp             w1, NULL
    // 0x1261d2c: b.eq            #0x1261fe0
    // 0x1261d30: mov             x2, x0
    // 0x1261d34: r0 = getTextStyle()
    //     0x1261d34: bl              #0x85b480  ; [package:flutter/src/painting/text_style.dart] TextStyle::getTextStyle
    // 0x1261d38: ldur            x1, [fp, #-0x70]
    // 0x1261d3c: mov             x2, x0
    // 0x1261d40: r0 = pushStyle()
    //     0x1261d40: bl              #0x85a5cc  ; [dart:ui] _NativeParagraphBuilder::pushStyle
    // 0x1261d44: ldur            x0, [fp, #-0x68]
    // 0x1261d48: LoadField: r2 = r0->field_b
    //     0x1261d48: ldur            w2, [x0, #0xb]
    // 0x1261d4c: DecompressPointer r2
    //     0x1261d4c: add             x2, x2, HEAP, lsl #32
    // 0x1261d50: cmp             w2, NULL
    // 0x1261d54: b.eq            #0x1261e00
    // 0x1261d58: ldur            x1, [fp, #-0x70]
    // 0x1261d5c: r0 = addText()
    //     0x1261d5c: bl              #0x85a338  ; [dart:ui] _NativeParagraphBuilder::addText
    // 0x1261d60: b               #0x1261e00
    // 0x1261d64: sub             SP, fp, #0xc0
    // 0x1261d68: mov             x2, x0
    // 0x1261d6c: stur            x0, [fp, #-0x88]
    // 0x1261d70: mov             x0, x1
    // 0x1261d74: stur            x1, [fp, #-0x90]
    // 0x1261d78: r1 = 60
    //     0x1261d78: mov             x1, #0x3c
    // 0x1261d7c: branchIfSmi(r2, 0x1261d88)
    //     0x1261d7c: tbz             w2, #0, #0x1261d88
    // 0x1261d80: r1 = LoadClassIdInstr(r2)
    //     0x1261d80: ldur            x1, [x2, #-1]
    //     0x1261d84: ubfx            x1, x1, #0xc, #0x14
    // 0x1261d88: r17 = -7777
    //     0x1261d88: mov             x17, #-0x1e61
    // 0x1261d8c: add             x16, x1, x17
    // 0x1261d90: cmp             x16, #2
    // 0x1261d94: b.hi            #0x1261f90
    // 0x1261d98: r1 = <List<Object>>
    //     0x1261d98: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x1261d9c: r0 = ErrorDescription()
    //     0x1261d9c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1261da0: mov             x1, x0
    // 0x1261da4: r2 = "while building a TextSpan"
    //     0x1261da4: add             x2, PP, #0x85, lsl #12  ; [pp+0x851c8] "while building a TextSpan"
    //     0x1261da8: ldr             x2, [x2, #0x1c8]
    // 0x1261dac: r3 = Instance_DiagnosticLevel
    //     0x1261dac: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1261db0: stur            x0, [fp, #-0x98]
    // 0x1261db4: r0 = _ErrorDiagnostic()
    //     0x1261db4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1261db8: r0 = FlutterErrorDetails()
    //     0x1261db8: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x1261dbc: mov             x1, x0
    // 0x1261dc0: ldur            x0, [fp, #-0x88]
    // 0x1261dc4: StoreField: r1->field_7 = r0
    //     0x1261dc4: stur            w0, [x1, #7]
    // 0x1261dc8: ldur            x2, [fp, #-0x90]
    // 0x1261dcc: StoreField: r1->field_b = r2
    //     0x1261dcc: stur            w2, [x1, #0xb]
    // 0x1261dd0: r0 = "painting library"
    //     0x1261dd0: add             x0, PP, #0x85, lsl #12  ; [pp+0x851d0] "painting library"
    //     0x1261dd4: ldr             x0, [x0, #0x1d0]
    // 0x1261dd8: StoreField: r1->field_f = r0
    //     0x1261dd8: stur            w0, [x1, #0xf]
    // 0x1261ddc: ldur            x0, [fp, #-0x98]
    // 0x1261de0: StoreField: r1->field_13 = r0
    //     0x1261de0: stur            w0, [x1, #0x13]
    // 0x1261de4: r0 = true
    //     0x1261de4: add             x0, NULL, #0x20  ; true
    // 0x1261de8: StoreField: r1->field_1b = r0
    //     0x1261de8: stur            w0, [x1, #0x1b]
    // 0x1261dec: r0 = reportError()
    //     0x1261dec: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x1261df0: ldur            x1, [fp, #-0x70]
    // 0x1261df4: r2 = "�"
    //     0x1261df4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20580] "�"
    //     0x1261df8: ldr             x2, [x2, #0x580]
    // 0x1261dfc: r0 = addText()
    //     0x1261dfc: bl              #0x85a338  ; [dart:ui] _NativeParagraphBuilder::addText
    // 0x1261e00: ldur            x0, [fp, #-0x68]
    // 0x1261e04: LoadField: r2 = r0->field_f
    //     0x1261e04: ldur            w2, [x0, #0xf]
    // 0x1261e08: DecompressPointer r2
    //     0x1261e08: add             x2, x2, HEAP, lsl #32
    // 0x1261e0c: stur            x2, [fp, #-0x98]
    // 0x1261e10: cmp             w2, NULL
    // 0x1261e14: b.eq            #0x1261f38
    // 0x1261e18: LoadField: r0 = r2->field_7
    //     0x1261e18: ldur            w0, [x2, #7]
    // 0x1261e1c: DecompressPointer r0
    //     0x1261e1c: add             x0, x0, HEAP, lsl #32
    // 0x1261e20: mov             x1, x0
    // 0x1261e24: stur            x0, [fp, #-0x68]
    // 0x1261e28: r0 = ListIterator()
    //     0x1261e28: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x1261e2c: mov             x4, x0
    // 0x1261e30: ldur            x3, [fp, #-0x98]
    // 0x1261e34: stur            x4, [fp, #-0xb8]
    // 0x1261e38: StoreField: r4->field_b = r3
    //     0x1261e38: stur            w3, [x4, #0xb]
    // 0x1261e3c: LoadField: r0 = r3->field_b
    //     0x1261e3c: ldur            w0, [x3, #0xb]
    // 0x1261e40: r5 = LoadInt32Instr(r0)
    //     0x1261e40: sbfx            x5, x0, #1, #0x1f
    // 0x1261e44: stur            x5, [fp, #-0xb0]
    // 0x1261e48: StoreField: r4->field_f = r5
    //     0x1261e48: stur            x5, [x4, #0xf]
    // 0x1261e4c: ArrayStore: r4[0] = rZR  ; List_8
    //     0x1261e4c: stur            xzr, [x4, #0x17]
    // 0x1261e50: r1 = 0
    //     0x1261e50: mov             x1, #0
    // 0x1261e54: CheckStackOverflow
    //     0x1261e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1261e58: cmp             SP, x16
    //     0x1261e5c: b.ls            #0x1261fe4
    // 0x1261e60: LoadField: r0 = r3->field_b
    //     0x1261e60: ldur            w0, [x3, #0xb]
    // 0x1261e64: r2 = LoadInt32Instr(r0)
    //     0x1261e64: sbfx            x2, x0, #1, #0x1f
    // 0x1261e68: cmp             x5, x2
    // 0x1261e6c: b.ne            #0x1261fa8
    // 0x1261e70: cmp             x1, x2
    // 0x1261e74: b.ge            #0x1261f30
    // 0x1261e78: LoadField: r0 = r3->field_f
    //     0x1261e78: ldur            w0, [x3, #0xf]
    // 0x1261e7c: DecompressPointer r0
    //     0x1261e7c: add             x0, x0, HEAP, lsl #32
    // 0x1261e80: ArrayLoad: r6 = r0[r1]  ; Unknown_4
    //     0x1261e80: add             x16, x0, x1, lsl #2
    //     0x1261e84: ldur            w6, [x16, #0xf]
    // 0x1261e88: DecompressPointer r6
    //     0x1261e88: add             x6, x6, HEAP, lsl #32
    // 0x1261e8c: mov             x0, x6
    // 0x1261e90: stur            x6, [fp, #-0xa8]
    // 0x1261e94: StoreField: r4->field_1f = r0
    //     0x1261e94: stur            w0, [x4, #0x1f]
    //     0x1261e98: tbz             w0, #0, #0x1261eb4
    //     0x1261e9c: ldurb           w16, [x4, #-1]
    //     0x1261ea0: ldurb           w17, [x0, #-1]
    //     0x1261ea4: and             x16, x17, x16, lsr #2
    //     0x1261ea8: tst             x16, HEAP, lsr #32
    //     0x1261eac: b.eq            #0x1261eb4
    //     0x1261eb0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x1261eb4: add             x7, x1, #1
    // 0x1261eb8: stur            x7, [fp, #-0xa0]
    // 0x1261ebc: ArrayStore: r4[0] = r7  ; List_8
    //     0x1261ebc: stur            x7, [x4, #0x17]
    // 0x1261ec0: cmp             w6, NULL
    // 0x1261ec4: b.ne            #0x1261ef8
    // 0x1261ec8: mov             x0, x6
    // 0x1261ecc: ldur            x2, [fp, #-0x68]
    // 0x1261ed0: r1 = Null
    //     0x1261ed0: mov             x1, NULL
    // 0x1261ed4: cmp             w2, NULL
    // 0x1261ed8: b.eq            #0x1261ef8
    // 0x1261edc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1261edc: ldur            w4, [x2, #0x17]
    // 0x1261ee0: DecompressPointer r4
    //     0x1261ee0: add             x4, x4, HEAP, lsl #32
    // 0x1261ee4: r8 = X0
    //     0x1261ee4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1261ee8: LoadField: r9 = r4->field_7
    //     0x1261ee8: ldur            x9, [x4, #7]
    // 0x1261eec: r3 = Null
    //     0x1261eec: add             x3, PP, #0x85, lsl #12  ; [pp+0x851d8] Null
    //     0x1261ef0: ldr             x3, [x3, #0x1d8]
    // 0x1261ef4: blr             x9
    // 0x1261ef8: ldur            x1, [fp, #-0xa8]
    // 0x1261efc: r0 = LoadClassIdInstr(r1)
    //     0x1261efc: ldur            x0, [x1, #-1]
    //     0x1261f00: ubfx            x0, x0, #0xc, #0x14
    // 0x1261f04: ldur            x2, [fp, #-0x70]
    // 0x1261f08: ldur            x3, [fp, #-0x78]
    // 0x1261f0c: ldur            x5, [fp, #-0x80]
    // 0x1261f10: r0 = GDT[cid_x0 + -0x8f]()
    //     0x1261f10: sub             lr, x0, #0x8f
    //     0x1261f14: ldr             lr, [x21, lr, lsl #3]
    //     0x1261f18: blr             lr
    // 0x1261f1c: ldur            x1, [fp, #-0xa0]
    // 0x1261f20: ldur            x3, [fp, #-0x98]
    // 0x1261f24: ldur            x4, [fp, #-0xb8]
    // 0x1261f28: ldur            x5, [fp, #-0xb0]
    // 0x1261f2c: b               #0x1261e54
    // 0x1261f30: mov             x0, x4
    // 0x1261f34: StoreField: r0->field_1f = rNULL
    //     0x1261f34: stur            NULL, [x0, #0x1f]
    // 0x1261f38: ldur            x0, [fp, #-0x60]
    // 0x1261f3c: tbnz            w0, #4, #0x1261f80
    // 0x1261f40: ldur            x0, [fp, #-0x70]
    // 0x1261f44: LoadField: r1 = r0->field_7
    //     0x1261f44: ldur            w1, [x0, #7]
    // 0x1261f48: DecompressPointer r1
    //     0x1261f48: add             x1, x1, HEAP, lsl #32
    // 0x1261f4c: cmp             w1, NULL
    // 0x1261f50: b.eq            #0x1261fec
    // 0x1261f54: LoadField: r2 = r1->field_7
    //     0x1261f54: ldur            x2, [x1, #7]
    // 0x1261f58: ldr             x1, [x2]
    // 0x1261f5c: cbz             x1, #0x1261fc8
    // 0x1261f60: mov             x2, x1
    // 0x1261f64: stur            x2, [fp, #-0xa0]
    // 0x1261f68: r1 = <Never>
    //     0x1261f68: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1261f6c: r0 = Pointer()
    //     0x1261f6c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1261f70: mov             x1, x0
    // 0x1261f74: ldur            x0, [fp, #-0xa0]
    // 0x1261f78: StoreField: r1->field_7 = r0
    //     0x1261f78: stur            x0, [x1, #7]
    // 0x1261f7c: r0 = _pop$Method$FfiNative()
    //     0x1261f7c: bl              #0x12617f4  ; [dart:ui] _NativeParagraphBuilder::_pop$Method$FfiNative
    // 0x1261f80: r0 = Null
    //     0x1261f80: mov             x0, NULL
    // 0x1261f84: LeaveFrame
    //     0x1261f84: mov             SP, fp
    //     0x1261f88: ldp             fp, lr, [SP], #0x10
    // 0x1261f8c: ret
    //     0x1261f8c: ret             
    // 0x1261f90: mov             x16, x0
    // 0x1261f94: mov             x0, x2
    // 0x1261f98: mov             x2, x16
    // 0x1261f9c: mov             x1, x2
    // 0x1261fa0: r0 = ReThrow()
    //     0x1261fa0: bl              #0x13ddb00  ; ReThrowStub
    // 0x1261fa4: brk             #0
    // 0x1261fa8: mov             x0, x3
    // 0x1261fac: r0 = ConcurrentModificationError()
    //     0x1261fac: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x1261fb0: mov             x1, x0
    // 0x1261fb4: ldur            x0, [fp, #-0x98]
    // 0x1261fb8: StoreField: r1->field_b = r0
    //     0x1261fb8: stur            w0, [x1, #0xb]
    // 0x1261fbc: mov             x0, x1
    // 0x1261fc0: r0 = Throw()
    //     0x1261fc0: bl              #0x13ddb2c  ; ThrowStub
    // 0x1261fc4: brk             #0
    // 0x1261fc8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1261fc8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1261fcc: str             x16, [SP]
    // 0x1261fd0: r0 = _throwNew()
    //     0x1261fd0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1261fd4: brk             #0
    // 0x1261fd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1261fd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1261fdc: b               #0x1261d08
    // 0x1261fe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1261fe0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1261fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1261fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1261fe8: b               #0x1261e60
    // 0x1261fec: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1261fec: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ compareTo(/* No info */) {
    // ** addr: 0x128781c, size: 0x364
    // 0x128781c: EnterFrame
    //     0x128781c: stp             fp, lr, [SP, #-0x10]!
    //     0x1287820: mov             fp, SP
    // 0x1287824: AllocStack(0x48)
    //     0x1287824: sub             SP, SP, #0x48
    // 0x1287828: SetupParameters(TextSpan this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1287828: mov             x0, x2
    //     0x128782c: stur            x1, [fp, #-8]
    //     0x1287830: stur            x2, [fp, #-0x10]
    // 0x1287834: CheckStackOverflow
    //     0x1287834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1287838: cmp             SP, x16
    //     0x128783c: b.ls            #0x1287b64
    // 0x1287840: cmp             w1, w0
    // 0x1287844: b.ne            #0x128785c
    // 0x1287848: r0 = Instance_RenderComparison
    //     0x1287848: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a60] Obj!RenderComparison@12c4ae1
    //     0x128784c: ldr             x0, [x0, #0xa60]
    // 0x1287850: LeaveFrame
    //     0x1287850: mov             SP, fp
    //     0x1287854: ldp             fp, lr, [SP], #0x10
    // 0x1287858: ret
    //     0x1287858: ret             
    // 0x128785c: str             x0, [SP]
    // 0x1287860: r0 = runtimeType()
    //     0x1287860: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1287864: r1 = LoadClassIdInstr(r0)
    //     0x1287864: ldur            x1, [x0, #-1]
    //     0x1287868: ubfx            x1, x1, #0xc, #0x14
    // 0x128786c: r16 = TextSpan
    //     0x128786c: add             x16, PP, #0x85, lsl #12  ; [pp+0x851c0] Type: TextSpan
    //     0x1287870: ldr             x16, [x16, #0x1c0]
    // 0x1287874: stp             x16, x0, [SP]
    // 0x1287878: mov             x0, x1
    // 0x128787c: mov             lr, x0
    // 0x1287880: ldr             lr, [x21, lr, lsl #3]
    // 0x1287884: blr             lr
    // 0x1287888: tbz             w0, #4, #0x12878a0
    // 0x128788c: r0 = Instance_RenderComparison
    //     0x128788c: add             x0, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0x1287890: ldr             x0, [x0, #0x338]
    // 0x1287894: LeaveFrame
    //     0x1287894: mov             SP, fp
    //     0x1287898: ldp             fp, lr, [SP], #0x10
    // 0x128789c: ret
    //     0x128789c: ret             
    // 0x12878a0: ldur            x4, [fp, #-8]
    // 0x12878a4: ldur            x3, [fp, #-0x10]
    // 0x12878a8: mov             x0, x3
    // 0x12878ac: r2 = Null
    //     0x12878ac: mov             x2, NULL
    // 0x12878b0: r1 = Null
    //     0x12878b0: mov             x1, NULL
    // 0x12878b4: r4 = LoadClassIdInstr(r0)
    //     0x12878b4: ldur            x4, [x0, #-1]
    //     0x12878b8: ubfx            x4, x4, #0xc, #0x14
    // 0x12878bc: r17 = 5788
    //     0x12878bc: mov             x17, #0x169c
    // 0x12878c0: cmp             x4, x17
    // 0x12878c4: b.eq            #0x12878dc
    // 0x12878c8: r8 = TextSpan
    //     0x12878c8: add             x8, PP, #0x85, lsl #12  ; [pp+0x851c0] Type: TextSpan
    //     0x12878cc: ldr             x8, [x8, #0x1c0]
    // 0x12878d0: r3 = Null
    //     0x12878d0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a140] Null
    //     0x12878d4: ldr             x3, [x3, #0x140]
    // 0x12878d8: r0 = TextSpan()
    //     0x12878d8: bl              #0xb5788c  ; IsType_TextSpan_Stub
    // 0x12878dc: ldur            x1, [fp, #-0x10]
    // 0x12878e0: LoadField: r0 = r1->field_b
    //     0x12878e0: ldur            w0, [x1, #0xb]
    // 0x12878e4: DecompressPointer r0
    //     0x12878e4: add             x0, x0, HEAP, lsl #32
    // 0x12878e8: ldur            x2, [fp, #-8]
    // 0x12878ec: LoadField: r3 = r2->field_b
    //     0x12878ec: ldur            w3, [x2, #0xb]
    // 0x12878f0: DecompressPointer r3
    //     0x12878f0: add             x3, x3, HEAP, lsl #32
    // 0x12878f4: r4 = LoadClassIdInstr(r0)
    //     0x12878f4: ldur            x4, [x0, #-1]
    //     0x12878f8: ubfx            x4, x4, #0xc, #0x14
    // 0x12878fc: stp             x3, x0, [SP]
    // 0x1287900: mov             x0, x4
    // 0x1287904: mov             lr, x0
    // 0x1287908: ldr             lr, [x21, lr, lsl #3]
    // 0x128790c: blr             lr
    // 0x1287910: tbnz            w0, #4, #0x12879a8
    // 0x1287914: ldur            x0, [fp, #-8]
    // 0x1287918: LoadField: r1 = r0->field_f
    //     0x1287918: ldur            w1, [x0, #0xf]
    // 0x128791c: DecompressPointer r1
    //     0x128791c: add             x1, x1, HEAP, lsl #32
    // 0x1287920: stur            x1, [fp, #-0x30]
    // 0x1287924: cmp             w1, NULL
    // 0x1287928: b.ne            #0x1287934
    // 0x128792c: r3 = Null
    //     0x128792c: mov             x3, NULL
    // 0x1287930: b               #0x128793c
    // 0x1287934: LoadField: r2 = r1->field_b
    //     0x1287934: ldur            w2, [x1, #0xb]
    // 0x1287938: mov             x3, x2
    // 0x128793c: ldur            x2, [fp, #-0x10]
    // 0x1287940: LoadField: r4 = r2->field_f
    //     0x1287940: ldur            w4, [x2, #0xf]
    // 0x1287944: DecompressPointer r4
    //     0x1287944: add             x4, x4, HEAP, lsl #32
    // 0x1287948: stur            x4, [fp, #-0x28]
    // 0x128794c: cmp             w4, NULL
    // 0x1287950: b.ne            #0x128795c
    // 0x1287954: r5 = Null
    //     0x1287954: mov             x5, NULL
    // 0x1287958: b               #0x1287960
    // 0x128795c: LoadField: r5 = r4->field_b
    //     0x128795c: ldur            w5, [x4, #0xb]
    // 0x1287960: cmp             w3, w5
    // 0x1287964: b.ne            #0x12879a8
    // 0x1287968: LoadField: r3 = r0->field_7
    //     0x1287968: ldur            w3, [x0, #7]
    // 0x128796c: DecompressPointer r3
    //     0x128796c: add             x3, x3, HEAP, lsl #32
    // 0x1287970: stur            x3, [fp, #-0x20]
    // 0x1287974: cmp             w3, NULL
    // 0x1287978: r16 = true
    //     0x1287978: add             x16, NULL, #0x20  ; true
    // 0x128797c: r17 = false
    //     0x128797c: add             x17, NULL, #0x30  ; false
    // 0x1287980: csel            x5, x16, x17, eq
    // 0x1287984: LoadField: r6 = r2->field_7
    //     0x1287984: ldur            w6, [x2, #7]
    // 0x1287988: DecompressPointer r6
    //     0x1287988: add             x6, x6, HEAP, lsl #32
    // 0x128798c: stur            x6, [fp, #-0x18]
    // 0x1287990: cmp             w6, NULL
    // 0x1287994: r16 = true
    //     0x1287994: add             x16, NULL, #0x20  ; true
    // 0x1287998: r17 = false
    //     0x1287998: add             x17, NULL, #0x30  ; false
    // 0x128799c: csel            x7, x16, x17, eq
    // 0x12879a0: cmp             w5, w7
    // 0x12879a4: b.eq            #0x12879bc
    // 0x12879a8: r0 = Instance_RenderComparison
    //     0x12879a8: add             x0, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0x12879ac: ldr             x0, [x0, #0x338]
    // 0x12879b0: LeaveFrame
    //     0x12879b0: mov             SP, fp
    //     0x12879b4: ldp             fp, lr, [SP], #0x10
    // 0x12879b8: ret
    //     0x12879b8: ret             
    // 0x12879bc: LoadField: r5 = r0->field_13
    //     0x12879bc: ldur            w5, [x0, #0x13]
    // 0x12879c0: DecompressPointer r5
    //     0x12879c0: add             x5, x5, HEAP, lsl #32
    // 0x12879c4: LoadField: r0 = r2->field_13
    //     0x12879c4: ldur            w0, [x2, #0x13]
    // 0x12879c8: DecompressPointer r0
    //     0x12879c8: add             x0, x0, HEAP, lsl #32
    // 0x12879cc: r2 = LoadClassIdInstr(r5)
    //     0x12879cc: ldur            x2, [x5, #-1]
    //     0x12879d0: ubfx            x2, x2, #0xc, #0x14
    // 0x12879d4: stp             x0, x5, [SP]
    // 0x12879d8: mov             x0, x2
    // 0x12879dc: mov             lr, x0
    // 0x12879e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12879e4: blr             lr
    // 0x12879e8: tbnz            w0, #4, #0x12879f8
    // 0x12879ec: r0 = Instance_RenderComparison
    //     0x12879ec: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a60] Obj!RenderComparison@12c4ae1
    //     0x12879f0: ldr             x0, [x0, #0xa60]
    // 0x12879f4: b               #0x1287a00
    // 0x12879f8: r0 = Instance_RenderComparison
    //     0x12879f8: add             x0, PP, #0x9a, lsl #12  ; [pp+0x9a150] Obj!RenderComparison@12c4b01
    //     0x12879fc: ldr             x0, [x0, #0x150]
    // 0x1287a00: ldur            x1, [fp, #-0x20]
    // 0x1287a04: stur            x0, [fp, #-8]
    // 0x1287a08: cmp             w1, NULL
    // 0x1287a0c: b.eq            #0x1287a54
    // 0x1287a10: ldur            x2, [fp, #-0x18]
    // 0x1287a14: cmp             w2, NULL
    // 0x1287a18: b.eq            #0x1287b6c
    // 0x1287a1c: r0 = compareTo()
    //     0x1287a1c: bl              #0x1287370  ; [package:flutter/src/painting/text_style.dart] TextStyle::compareTo
    // 0x1287a20: LoadField: r1 = r0->field_7
    //     0x1287a20: ldur            x1, [x0, #7]
    // 0x1287a24: ldur            x2, [fp, #-8]
    // 0x1287a28: LoadField: r3 = r2->field_7
    //     0x1287a28: ldur            x3, [x2, #7]
    // 0x1287a2c: cmp             x1, x3
    // 0x1287a30: b.gt            #0x1287a38
    // 0x1287a34: mov             x0, x2
    // 0x1287a38: r16 = Instance_RenderComparison
    //     0x1287a38: add             x16, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0x1287a3c: ldr             x16, [x16, #0x338]
    // 0x1287a40: cmp             w0, w16
    // 0x1287a44: b.ne            #0x1287a5c
    // 0x1287a48: LeaveFrame
    //     0x1287a48: mov             SP, fp
    //     0x1287a4c: ldp             fp, lr, [SP], #0x10
    // 0x1287a50: ret
    //     0x1287a50: ret             
    // 0x1287a54: mov             x2, x0
    // 0x1287a58: mov             x0, x2
    // 0x1287a5c: ldur            x3, [fp, #-0x30]
    // 0x1287a60: cmp             w3, NULL
    // 0x1287a64: b.eq            #0x1287b58
    // 0x1287a68: mov             x6, x0
    // 0x1287a6c: r5 = 0
    //     0x1287a6c: mov             x5, #0
    // 0x1287a70: ldur            x4, [fp, #-0x28]
    // 0x1287a74: stur            x6, [fp, #-8]
    // 0x1287a78: stur            x5, [fp, #-0x38]
    // 0x1287a7c: CheckStackOverflow
    //     0x1287a7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1287a80: cmp             SP, x16
    //     0x1287a84: b.ls            #0x1287b70
    // 0x1287a88: LoadField: r0 = r3->field_b
    //     0x1287a88: ldur            w0, [x3, #0xb]
    // 0x1287a8c: r1 = LoadInt32Instr(r0)
    //     0x1287a8c: sbfx            x1, x0, #1, #0x1f
    // 0x1287a90: cmp             x5, x1
    // 0x1287a94: b.ge            #0x1287b50
    // 0x1287a98: LoadField: r0 = r3->field_f
    //     0x1287a98: ldur            w0, [x3, #0xf]
    // 0x1287a9c: DecompressPointer r0
    //     0x1287a9c: add             x0, x0, HEAP, lsl #32
    // 0x1287aa0: ArrayLoad: r2 = r0[r5]  ; Unknown_4
    //     0x1287aa0: add             x16, x0, x5, lsl #2
    //     0x1287aa4: ldur            w2, [x16, #0xf]
    // 0x1287aa8: DecompressPointer r2
    //     0x1287aa8: add             x2, x2, HEAP, lsl #32
    // 0x1287aac: cmp             w4, NULL
    // 0x1287ab0: b.eq            #0x1287b78
    // 0x1287ab4: LoadField: r0 = r4->field_b
    //     0x1287ab4: ldur            w0, [x4, #0xb]
    // 0x1287ab8: r1 = LoadInt32Instr(r0)
    //     0x1287ab8: sbfx            x1, x0, #1, #0x1f
    // 0x1287abc: mov             x0, x1
    // 0x1287ac0: mov             x1, x5
    // 0x1287ac4: cmp             x1, x0
    // 0x1287ac8: b.hs            #0x1287b7c
    // 0x1287acc: LoadField: r0 = r4->field_f
    //     0x1287acc: ldur            w0, [x4, #0xf]
    // 0x1287ad0: DecompressPointer r0
    //     0x1287ad0: add             x0, x0, HEAP, lsl #32
    // 0x1287ad4: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x1287ad4: add             x16, x0, x5, lsl #2
    //     0x1287ad8: ldur            w1, [x16, #0xf]
    // 0x1287adc: DecompressPointer r1
    //     0x1287adc: add             x1, x1, HEAP, lsl #32
    // 0x1287ae0: r0 = LoadClassIdInstr(r2)
    //     0x1287ae0: ldur            x0, [x2, #-1]
    //     0x1287ae4: ubfx            x0, x0, #0xc, #0x14
    // 0x1287ae8: mov             x16, x1
    // 0x1287aec: mov             x1, x2
    // 0x1287af0: mov             x2, x16
    // 0x1287af4: r0 = GDT[cid_x0 + -0x6b3]()
    //     0x1287af4: sub             lr, x0, #0x6b3
    //     0x1287af8: ldr             lr, [x21, lr, lsl #3]
    //     0x1287afc: blr             lr
    // 0x1287b00: LoadField: r1 = r0->field_7
    //     0x1287b00: ldur            x1, [x0, #7]
    // 0x1287b04: ldur            x2, [fp, #-8]
    // 0x1287b08: LoadField: r3 = r2->field_7
    //     0x1287b08: ldur            x3, [x2, #7]
    // 0x1287b0c: cmp             x1, x3
    // 0x1287b10: b.le            #0x1287b1c
    // 0x1287b14: mov             x6, x0
    // 0x1287b18: b               #0x1287b20
    // 0x1287b1c: mov             x6, x2
    // 0x1287b20: r16 = Instance_RenderComparison
    //     0x1287b20: add             x16, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0x1287b24: ldr             x16, [x16, #0x338]
    // 0x1287b28: cmp             w6, w16
    // 0x1287b2c: b.eq            #0x1287b40
    // 0x1287b30: ldur            x1, [fp, #-0x38]
    // 0x1287b34: add             x5, x1, #1
    // 0x1287b38: ldur            x3, [fp, #-0x30]
    // 0x1287b3c: b               #0x1287a70
    // 0x1287b40: mov             x0, x6
    // 0x1287b44: LeaveFrame
    //     0x1287b44: mov             SP, fp
    //     0x1287b48: ldp             fp, lr, [SP], #0x10
    // 0x1287b4c: ret
    //     0x1287b4c: ret             
    // 0x1287b50: mov             x2, x6
    // 0x1287b54: mov             x0, x2
    // 0x1287b58: LeaveFrame
    //     0x1287b58: mov             SP, fp
    //     0x1287b5c: ldp             fp, lr, [SP], #0x10
    // 0x1287b60: ret
    //     0x1287b60: ret             
    // 0x1287b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1287b64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1287b68: b               #0x1287840
    // 0x1287b6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1287b6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1287b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1287b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1287b74: b               #0x1287a88
    // 0x1287b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1287b78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1287b7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1287b7c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}
