// lib: , url: package:flutter/src/painting/shape_decoration.dart

// class id: 1049007, size: 0x8
class :: {
}

// class id: 3257, size: 0x38, field offset: 0xc
class _ShapeDecorationPainter extends BoxPainter {

  late Path _outerPath; // offset: 0x18
  late List<Rect> _shadowBounds; // offset: 0x28
  late List<Paint> _shadowPaints; // offset: 0x30
  late List<Path> _shadowPaths; // offset: 0x2c

  _ paint(/* No info */) {
    // ** addr: 0x12f81c4, size: 0x10c
    // 0x12f81c4: EnterFrame
    //     0x12f81c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f81c8: mov             fp, SP
    // 0x12f81cc: AllocStack(0x30)
    //     0x12f81cc: sub             SP, SP, #0x30
    // 0x12f81d0: SetupParameters(_ShapeDecorationPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0x12f81d0: mov             x4, x1
    //     0x12f81d4: mov             x0, x2
    //     0x12f81d8: stur            x1, [fp, #-8]
    //     0x12f81dc: mov             x1, x3
    //     0x12f81e0: mov             x3, x5
    //     0x12f81e4: stur            x2, [fp, #-0x10]
    //     0x12f81e8: stur            x5, [fp, #-0x18]
    // 0x12f81ec: CheckStackOverflow
    //     0x12f81ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f81f0: cmp             SP, x16
    //     0x12f81f4: b.ls            #0x12f82c4
    // 0x12f81f8: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x12f81f8: ldur            w2, [x3, #0x17]
    // 0x12f81fc: DecompressPointer r2
    //     0x12f81fc: add             x2, x2, HEAP, lsl #32
    // 0x12f8200: cmp             w2, NULL
    // 0x12f8204: b.eq            #0x12f82cc
    // 0x12f8208: r0 = &()
    //     0x12f8208: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12f820c: mov             x4, x0
    // 0x12f8210: ldur            x0, [fp, #-0x18]
    // 0x12f8214: stur            x4, [fp, #-0x28]
    // 0x12f8218: LoadField: r5 = r0->field_13
    //     0x12f8218: ldur            w5, [x0, #0x13]
    // 0x12f821c: DecompressPointer r5
    //     0x12f821c: add             x5, x5, HEAP, lsl #32
    // 0x12f8220: ldur            x1, [fp, #-8]
    // 0x12f8224: mov             x2, x4
    // 0x12f8228: mov             x3, x5
    // 0x12f822c: stur            x5, [fp, #-0x20]
    // 0x12f8230: r0 = _precache()
    //     0x12f8230: bl              #0x12f8a6c  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache
    // 0x12f8234: ldur            x1, [fp, #-8]
    // 0x12f8238: ldur            x2, [fp, #-0x10]
    // 0x12f823c: ldur            x3, [fp, #-0x20]
    // 0x12f8240: r0 = _paintShadows()
    //     0x12f8240: bl              #0x12f8714  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintShadows
    // 0x12f8244: ldur            x1, [fp, #-8]
    // 0x12f8248: ldur            x2, [fp, #-0x10]
    // 0x12f824c: ldur            x3, [fp, #-0x28]
    // 0x12f8250: ldur            x5, [fp, #-0x20]
    // 0x12f8254: r0 = _paintInterior()
    //     0x12f8254: bl              #0x12f83f0  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintInterior
    // 0x12f8258: ldur            x1, [fp, #-8]
    // 0x12f825c: ldur            x2, [fp, #-0x10]
    // 0x12f8260: ldur            x3, [fp, #-0x18]
    // 0x12f8264: r0 = _paintImage()
    //     0x12f8264: bl              #0x12f82d0  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintImage
    // 0x12f8268: ldur            x0, [fp, #-8]
    // 0x12f826c: LoadField: r1 = r0->field_b
    //     0x12f826c: ldur            w1, [x0, #0xb]
    // 0x12f8270: DecompressPointer r1
    //     0x12f8270: add             x1, x1, HEAP, lsl #32
    // 0x12f8274: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12f8274: ldur            w0, [x1, #0x17]
    // 0x12f8278: DecompressPointer r0
    //     0x12f8278: add             x0, x0, HEAP, lsl #32
    // 0x12f827c: r1 = LoadClassIdInstr(r0)
    //     0x12f827c: ldur            x1, [x0, #-1]
    //     0x12f8280: ubfx            x1, x1, #0xc, #0x14
    // 0x12f8284: ldur            x16, [fp, #-0x20]
    // 0x12f8288: str             x16, [SP]
    // 0x12f828c: mov             x16, x0
    // 0x12f8290: mov             x0, x1
    // 0x12f8294: mov             x1, x16
    // 0x12f8298: ldur            x2, [fp, #-0x10]
    // 0x12f829c: ldur            x3, [fp, #-0x28]
    // 0x12f82a0: r4 = const [0, 0x4, 0x1, 0x3, textDirection, 0x3, null]
    //     0x12f82a0: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0cb8] List(7) [0, 0x4, 0x1, 0x3, "textDirection", 0x3, Null]
    //     0x12f82a4: ldr             x4, [x4, #0xcb8]
    // 0x12f82a8: r0 = GDT[cid_x0 + -0xe4f]()
    //     0x12f82a8: sub             lr, x0, #0xe4f
    //     0x12f82ac: ldr             lr, [x21, lr, lsl #3]
    //     0x12f82b0: blr             lr
    // 0x12f82b4: r0 = Null
    //     0x12f82b4: mov             x0, NULL
    // 0x12f82b8: LeaveFrame
    //     0x12f82b8: mov             SP, fp
    //     0x12f82bc: ldp             fp, lr, [SP], #0x10
    // 0x12f82c0: ret
    //     0x12f82c0: ret             
    // 0x12f82c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f82c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f82c8: b               #0x12f81f8
    // 0x12f82cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f82cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintImage(/* No info */) {
    // ** addr: 0x12f82d0, size: 0x120
    // 0x12f82d0: EnterFrame
    //     0x12f82d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f82d4: mov             fp, SP
    // 0x12f82d8: AllocStack(0x18)
    //     0x12f82d8: sub             SP, SP, #0x18
    // 0x12f82dc: SetupParameters(_ShapeDecorationPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r6, fp-0x18 */)
    //     0x12f82dc: mov             x4, x1
    //     0x12f82e0: mov             x6, x3
    //     0x12f82e4: stur            x3, [fp, #-0x18]
    //     0x12f82e8: mov             x3, x2
    //     0x12f82ec: stur            x1, [fp, #-8]
    //     0x12f82f0: stur            x2, [fp, #-0x10]
    // 0x12f82f4: CheckStackOverflow
    //     0x12f82f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f82f8: cmp             SP, x16
    //     0x12f82fc: b.ls            #0x12f83e0
    // 0x12f8300: LoadField: r0 = r4->field_b
    //     0x12f8300: ldur            w0, [x4, #0xb]
    // 0x12f8304: DecompressPointer r0
    //     0x12f8304: add             x0, x0, HEAP, lsl #32
    // 0x12f8308: LoadField: r1 = r0->field_f
    //     0x12f8308: ldur            w1, [x0, #0xf]
    // 0x12f830c: DecompressPointer r1
    //     0x12f830c: add             x1, x1, HEAP, lsl #32
    // 0x12f8310: cmp             w1, NULL
    // 0x12f8314: b.ne            #0x12f8328
    // 0x12f8318: r0 = Null
    //     0x12f8318: mov             x0, NULL
    // 0x12f831c: LeaveFrame
    //     0x12f831c: mov             SP, fp
    //     0x12f8320: ldp             fp, lr, [SP], #0x10
    // 0x12f8324: ret
    //     0x12f8324: ret             
    // 0x12f8328: LoadField: r0 = r4->field_33
    //     0x12f8328: ldur            w0, [x4, #0x33]
    // 0x12f832c: DecompressPointer r0
    //     0x12f832c: add             x0, x0, HEAP, lsl #32
    // 0x12f8330: cmp             w0, NULL
    // 0x12f8334: b.ne            #0x12f8388
    // 0x12f8338: LoadField: r2 = r4->field_7
    //     0x12f8338: ldur            w2, [x4, #7]
    // 0x12f833c: DecompressPointer r2
    //     0x12f833c: add             x2, x2, HEAP, lsl #32
    // 0x12f8340: cmp             w2, NULL
    // 0x12f8344: b.eq            #0x12f83e8
    // 0x12f8348: r0 = LoadClassIdInstr(r1)
    //     0x12f8348: ldur            x0, [x1, #-1]
    //     0x12f834c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8350: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x12f8350: sub             lr, x0, #0xfb3
    //     0x12f8354: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8358: blr             lr
    // 0x12f835c: mov             x2, x0
    // 0x12f8360: ldur            x1, [fp, #-8]
    // 0x12f8364: StoreField: r1->field_33 = r0
    //     0x12f8364: stur            w0, [x1, #0x33]
    //     0x12f8368: ldurb           w16, [x1, #-1]
    //     0x12f836c: ldurb           w17, [x0, #-1]
    //     0x12f8370: and             x16, x17, x16, lsr #2
    //     0x12f8374: tst             x16, HEAP, lsr #32
    //     0x12f8378: b.eq            #0x12f8380
    //     0x12f837c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f8380: mov             x0, x2
    // 0x12f8384: b               #0x12f838c
    // 0x12f8388: mov             x1, x4
    // 0x12f838c: LoadField: r3 = r1->field_f
    //     0x12f838c: ldur            w3, [x1, #0xf]
    // 0x12f8390: DecompressPointer r3
    //     0x12f8390: add             x3, x3, HEAP, lsl #32
    // 0x12f8394: cmp             w3, NULL
    // 0x12f8398: b.eq            #0x12f83ec
    // 0x12f839c: LoadField: r5 = r1->field_1b
    //     0x12f839c: ldur            w5, [x1, #0x1b]
    // 0x12f83a0: DecompressPointer r5
    //     0x12f83a0: add             x5, x5, HEAP, lsl #32
    // 0x12f83a4: r1 = LoadClassIdInstr(r0)
    //     0x12f83a4: ldur            x1, [x0, #-1]
    //     0x12f83a8: ubfx            x1, x1, #0xc, #0x14
    // 0x12f83ac: mov             x16, x0
    // 0x12f83b0: mov             x0, x1
    // 0x12f83b4: mov             x1, x16
    // 0x12f83b8: ldur            x2, [fp, #-0x10]
    // 0x12f83bc: ldur            x6, [fp, #-0x18]
    // 0x12f83c0: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x12f83c0: ldr             x4, [PP, #0x1390]  ; [pp+0x1390] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x12f83c4: r0 = GDT[cid_x0 + -0xfba]()
    //     0x12f83c4: sub             lr, x0, #0xfba
    //     0x12f83c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f83cc: blr             lr
    // 0x12f83d0: r0 = Null
    //     0x12f83d0: mov             x0, NULL
    // 0x12f83d4: LeaveFrame
    //     0x12f83d4: mov             SP, fp
    //     0x12f83d8: ldp             fp, lr, [SP], #0x10
    // 0x12f83dc: ret
    //     0x12f83dc: ret             
    // 0x12f83e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f83e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f83e4: b               #0x12f8300
    // 0x12f83e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f83e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f83ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f83ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintInterior(/* No info */) {
    // ** addr: 0x12f83f0, size: 0x1f4
    // 0x12f83f0: EnterFrame
    //     0x12f83f0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f83f4: mov             fp, SP
    // 0x12f83f8: AllocStack(0x38)
    //     0x12f83f8: sub             SP, SP, #0x38
    // 0x12f83fc: SetupParameters(_ShapeDecorationPainter this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x28 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0x12f83fc: mov             x4, x1
    //     0x12f8400: stur            x2, [fp, #-0x18]
    //     0x12f8404: mov             x16, x3
    //     0x12f8408: mov             x3, x2
    //     0x12f840c: mov             x2, x16
    //     0x12f8410: stur            x1, [fp, #-0x10]
    //     0x12f8414: stur            x2, [fp, #-0x20]
    //     0x12f8418: stur            x5, [fp, #-0x28]
    // 0x12f841c: CheckStackOverflow
    //     0x12f841c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f8420: cmp             SP, x16
    //     0x12f8424: b.ls            #0x12f85c0
    // 0x12f8428: LoadField: r0 = r4->field_1f
    //     0x12f8428: ldur            w0, [x4, #0x1f]
    // 0x12f842c: DecompressPointer r0
    //     0x12f842c: add             x0, x0, HEAP, lsl #32
    // 0x12f8430: cmp             w0, NULL
    // 0x12f8434: b.eq            #0x12f85a0
    // 0x12f8438: LoadField: r0 = r4->field_b
    //     0x12f8438: ldur            w0, [x4, #0xb]
    // 0x12f843c: DecompressPointer r0
    //     0x12f843c: add             x0, x0, HEAP, lsl #32
    // 0x12f8440: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x12f8440: ldur            w6, [x0, #0x17]
    // 0x12f8444: DecompressPointer r6
    //     0x12f8444: add             x6, x6, HEAP, lsl #32
    // 0x12f8448: stur            x6, [fp, #-8]
    // 0x12f844c: r0 = LoadClassIdInstr(r6)
    //     0x12f844c: ldur            x0, [x6, #-1]
    //     0x12f8450: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8454: mov             x1, x6
    // 0x12f8458: r0 = GDT[cid_x0 + -0xf28]()
    //     0x12f8458: sub             lr, x0, #0xf28
    //     0x12f845c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8460: blr             lr
    // 0x12f8464: tbnz            w0, #4, #0x12f84d0
    // 0x12f8468: ldur            x0, [fp, #-0x10]
    // 0x12f846c: ldur            x3, [fp, #-8]
    // 0x12f8470: mov             x1, x0
    // 0x12f8474: ldur            x2, [fp, #-0x20]
    // 0x12f8478: r0 = _adjustedRectOnOutlinedBorder()
    //     0x12f8478: bl              #0x12f85e4  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_adjustedRectOnOutlinedBorder
    // 0x12f847c: mov             x1, x0
    // 0x12f8480: ldur            x0, [fp, #-0x10]
    // 0x12f8484: LoadField: r5 = r0->field_1f
    //     0x12f8484: ldur            w5, [x0, #0x1f]
    // 0x12f8488: DecompressPointer r5
    //     0x12f8488: add             x5, x5, HEAP, lsl #32
    // 0x12f848c: cmp             w5, NULL
    // 0x12f8490: b.eq            #0x12f85c8
    // 0x12f8494: ldur            x0, [fp, #-8]
    // 0x12f8498: r2 = LoadClassIdInstr(r0)
    //     0x12f8498: ldur            x2, [x0, #-1]
    //     0x12f849c: ubfx            x2, x2, #0xc, #0x14
    // 0x12f84a0: ldur            x16, [fp, #-0x28]
    // 0x12f84a4: str             x16, [SP]
    // 0x12f84a8: mov             x3, x1
    // 0x12f84ac: mov             x1, x0
    // 0x12f84b0: mov             x0, x2
    // 0x12f84b4: ldur            x2, [fp, #-0x18]
    // 0x12f84b8: r4 = const [0, 0x5, 0x1, 0x4, textDirection, 0x4, null]
    //     0x12f84b8: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0cc0] List(7) [0, 0x5, 0x1, 0x4, "textDirection", 0x4, Null]
    //     0x12f84bc: ldr             x4, [x4, #0xcc0]
    // 0x12f84c0: r0 = GDT[cid_x0 + -0xe3d]()
    //     0x12f84c0: sub             lr, x0, #0xe3d
    //     0x12f84c4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f84c8: blr             lr
    // 0x12f84cc: b               #0x12f85a0
    // 0x12f84d0: ldur            x0, [fp, #-0x10]
    // 0x12f84d4: ldur            x2, [fp, #-0x18]
    // 0x12f84d8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x12f84d8: ldur            w3, [x0, #0x17]
    // 0x12f84dc: DecompressPointer r3
    //     0x12f84dc: add             x3, x3, HEAP, lsl #32
    // 0x12f84e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f84e4: cmp             w3, w16
    // 0x12f84e8: b.eq            #0x12f85cc
    // 0x12f84ec: stur            x3, [fp, #-0x20]
    // 0x12f84f0: LoadField: r1 = r0->field_1f
    //     0x12f84f0: ldur            w1, [x0, #0x1f]
    // 0x12f84f4: DecompressPointer r1
    //     0x12f84f4: add             x1, x1, HEAP, lsl #32
    // 0x12f84f8: cmp             w1, NULL
    // 0x12f84fc: b.eq            #0x12f85d8
    // 0x12f8500: LoadField: r0 = r1->field_b
    //     0x12f8500: ldur            w0, [x1, #0xb]
    // 0x12f8504: DecompressPointer r0
    //     0x12f8504: add             x0, x0, HEAP, lsl #32
    // 0x12f8508: stur            x0, [fp, #-0x10]
    // 0x12f850c: LoadField: r5 = r1->field_7
    //     0x12f850c: ldur            w5, [x1, #7]
    // 0x12f8510: DecompressPointer r5
    //     0x12f8510: add             x5, x5, HEAP, lsl #32
    // 0x12f8514: stur            x5, [fp, #-8]
    // 0x12f8518: LoadField: r1 = r2->field_7
    //     0x12f8518: ldur            w1, [x2, #7]
    // 0x12f851c: DecompressPointer r1
    //     0x12f851c: add             x1, x1, HEAP, lsl #32
    // 0x12f8520: cmp             w1, NULL
    // 0x12f8524: b.eq            #0x12f85dc
    // 0x12f8528: LoadField: r4 = r1->field_7
    //     0x12f8528: ldur            x4, [x1, #7]
    // 0x12f852c: ldr             x1, [x4]
    // 0x12f8530: cbz             x1, #0x12f85b0
    // 0x12f8534: mov             x4, x1
    // 0x12f8538: stur            x4, [fp, #-0x30]
    // 0x12f853c: r1 = <Never>
    //     0x12f853c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f8540: r0 = Pointer()
    //     0x12f8540: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f8544: mov             x2, x0
    // 0x12f8548: ldur            x0, [fp, #-0x30]
    // 0x12f854c: stur            x2, [fp, #-0x28]
    // 0x12f8550: StoreField: r2->field_7 = r0
    //     0x12f8550: stur            x0, [x2, #7]
    // 0x12f8554: ldur            x0, [fp, #-0x20]
    // 0x12f8558: LoadField: r1 = r0->field_7
    //     0x12f8558: ldur            w1, [x0, #7]
    // 0x12f855c: DecompressPointer r1
    //     0x12f855c: add             x1, x1, HEAP, lsl #32
    // 0x12f8560: cmp             w1, NULL
    // 0x12f8564: b.eq            #0x12f85e0
    // 0x12f8568: LoadField: r3 = r1->field_7
    //     0x12f8568: ldur            x3, [x1, #7]
    // 0x12f856c: ldr             x1, [x3]
    // 0x12f8570: mov             x3, x1
    // 0x12f8574: stur            x3, [fp, #-0x30]
    // 0x12f8578: r1 = <Never>
    //     0x12f8578: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f857c: r0 = Pointer()
    //     0x12f857c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f8580: mov             x1, x0
    // 0x12f8584: ldur            x0, [fp, #-0x30]
    // 0x12f8588: StoreField: r1->field_7 = r0
    //     0x12f8588: stur            x0, [x1, #7]
    // 0x12f858c: mov             x2, x1
    // 0x12f8590: ldur            x1, [fp, #-0x28]
    // 0x12f8594: ldur            x3, [fp, #-0x10]
    // 0x12f8598: ldur            x5, [fp, #-8]
    // 0x12f859c: r0 = __drawPath$Method$FfiNative()
    //     0x12f859c: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f85a0: r0 = Null
    //     0x12f85a0: mov             x0, NULL
    // 0x12f85a4: LeaveFrame
    //     0x12f85a4: mov             SP, fp
    //     0x12f85a8: ldp             fp, lr, [SP], #0x10
    // 0x12f85ac: ret
    //     0x12f85ac: ret             
    // 0x12f85b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f85b0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f85b4: str             x16, [SP]
    // 0x12f85b8: r0 = _throwNew()
    //     0x12f85b8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f85bc: brk             #0
    // 0x12f85c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f85c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f85c4: b               #0x12f8428
    // 0x12f85c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f85c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f85cc: r9 = _outerPath
    //     0x12f85cc: add             x9, PP, #0xa0, lsl #12  ; [pp+0xa0cc8] Field <_ShapeDecorationPainter@804037234._outerPath@804037234>: late (offset: 0x18)
    //     0x12f85d0: ldr             x9, [x9, #0xcc8]
    // 0x12f85d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12f85d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12f85d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f85d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f85dc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f85dc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f85e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f85e0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustedRectOnOutlinedBorder(/* No info */) {
    // ** addr: 0x12f85e4, size: 0x130
    // 0x12f85e4: EnterFrame
    //     0x12f85e4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f85e8: mov             fp, SP
    // 0x12f85ec: AllocStack(0x18)
    //     0x12f85ec: sub             SP, SP, #0x18
    // 0x12f85f0: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12f85f0: mov             x3, x2
    //     0x12f85f4: stur            x2, [fp, #-0x10]
    // 0x12f85f8: CheckStackOverflow
    //     0x12f85f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f85fc: cmp             SP, x16
    //     0x12f8600: b.ls            #0x12f870c
    // 0x12f8604: LoadField: r0 = r1->field_b
    //     0x12f8604: ldur            w0, [x1, #0xb]
    // 0x12f8608: DecompressPointer r0
    //     0x12f8608: add             x0, x0, HEAP, lsl #32
    // 0x12f860c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x12f860c: ldur            w4, [x0, #0x17]
    // 0x12f8610: DecompressPointer r4
    //     0x12f8610: add             x4, x4, HEAP, lsl #32
    // 0x12f8614: stur            x4, [fp, #-8]
    // 0x12f8618: r1 = LoadClassIdInstr(r4)
    //     0x12f8618: ldur            x1, [x4, #-1]
    //     0x12f861c: ubfx            x1, x1, #0xc, #0x14
    // 0x12f8620: sub             x16, x1, #0xbcc
    // 0x12f8624: cmp             x16, #9
    // 0x12f8628: b.hi            #0x12f86fc
    // 0x12f862c: LoadField: r1 = r0->field_7
    //     0x12f862c: ldur            w1, [x0, #7]
    // 0x12f8630: DecompressPointer r1
    //     0x12f8630: add             x1, x1, HEAP, lsl #32
    // 0x12f8634: cmp             w1, NULL
    // 0x12f8638: b.eq            #0x12f86fc
    // 0x12f863c: mov             x0, x4
    // 0x12f8640: r2 = Null
    //     0x12f8640: mov             x2, NULL
    // 0x12f8644: r1 = Null
    //     0x12f8644: mov             x1, NULL
    // 0x12f8648: r4 = LoadClassIdInstr(r0)
    //     0x12f8648: ldur            x4, [x0, #-1]
    //     0x12f864c: ubfx            x4, x4, #0xc, #0x14
    // 0x12f8650: sub             x4, x4, #0xbcc
    // 0x12f8654: cmp             x4, #9
    // 0x12f8658: b.ls            #0x12f8670
    // 0x12f865c: r8 = OutlinedBorder
    //     0x12f865c: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0cd0] Type: OutlinedBorder
    //     0x12f8660: ldr             x8, [x8, #0xcd0]
    // 0x12f8664: r3 = Null
    //     0x12f8664: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0cd8] Null
    //     0x12f8668: ldr             x3, [x3, #0xcd8]
    // 0x12f866c: r0 = DefaultTypeTest()
    //     0x12f866c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12f8670: ldur            x0, [fp, #-8]
    // 0x12f8674: LoadField: r2 = r0->field_7
    //     0x12f8674: ldur            w2, [x0, #7]
    // 0x12f8678: DecompressPointer r2
    //     0x12f8678: add             x2, x2, HEAP, lsl #32
    // 0x12f867c: stur            x2, [fp, #-0x18]
    // 0x12f8680: LoadField: r1 = r2->field_7
    //     0x12f8680: ldur            w1, [x2, #7]
    // 0x12f8684: DecompressPointer r1
    //     0x12f8684: add             x1, x1, HEAP, lsl #32
    // 0x12f8688: r0 = LoadClassIdInstr(r1)
    //     0x12f8688: ldur            x0, [x1, #-1]
    //     0x12f868c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8690: r0 = GDT[cid_x0 + -0xfc0]()
    //     0x12f8690: sub             lr, x0, #0xfc0
    //     0x12f8694: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8698: blr             lr
    // 0x12f869c: cmp             x0, #0xff
    // 0x12f86a0: b.ne            #0x12f86fc
    // 0x12f86a4: ldur            x0, [fp, #-0x18]
    // 0x12f86a8: LoadField: r1 = r0->field_13
    //     0x12f86a8: ldur            w1, [x0, #0x13]
    // 0x12f86ac: DecompressPointer r1
    //     0x12f86ac: add             x1, x1, HEAP, lsl #32
    // 0x12f86b0: r16 = Instance_BorderStyle
    //     0x12f86b0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f86b4: ldr             x16, [x16, #0xdc8]
    // 0x12f86b8: cmp             w1, w16
    // 0x12f86bc: b.ne            #0x12f86fc
    // 0x12f86c0: d1 = 1.000000
    //     0x12f86c0: fmov            d1, #1.00000000
    // 0x12f86c4: d0 = 2.000000
    //     0x12f86c4: fmov            d0, #2.00000000
    // 0x12f86c8: LoadField: d2 = r0->field_b
    //     0x12f86c8: ldur            d2, [x0, #0xb]
    // 0x12f86cc: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x12f86cc: ldur            d3, [x0, #0x17]
    // 0x12f86d0: fadd            d4, d3, d1
    // 0x12f86d4: fdiv            d3, d4, d0
    // 0x12f86d8: fsub            d4, d1, d3
    // 0x12f86dc: fmul            d1, d2, d4
    // 0x12f86e0: fdiv            d2, d1, d0
    // 0x12f86e4: ldur            x1, [fp, #-0x10]
    // 0x12f86e8: mov             v0.16b, v2.16b
    // 0x12f86ec: r0 = deflate()
    //     0x12f86ec: bl              #0x882c84  ; [dart:ui] Rect::deflate
    // 0x12f86f0: LeaveFrame
    //     0x12f86f0: mov             SP, fp
    //     0x12f86f4: ldp             fp, lr, [SP], #0x10
    // 0x12f86f8: ret
    //     0x12f86f8: ret             
    // 0x12f86fc: ldur            x0, [fp, #-0x10]
    // 0x12f8700: LeaveFrame
    //     0x12f8700: mov             SP, fp
    //     0x12f8704: ldp             fp, lr, [SP], #0x10
    // 0x12f8708: ret
    //     0x12f8708: ret             
    // 0x12f870c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f870c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f8710: b               #0x12f8604
  }
  _ _paintShadows(/* No info */) {
    // ** addr: 0x12f8714, size: 0x358
    // 0x12f8714: EnterFrame
    //     0x12f8714: stp             fp, lr, [SP, #-0x10]!
    //     0x12f8718: mov             fp, SP
    // 0x12f871c: AllocStack(0x48)
    //     0x12f871c: sub             SP, SP, #0x48
    // 0x12f8720: SetupParameters(_ShapeDecorationPainter this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12f8720: mov             x4, x1
    //     0x12f8724: stur            x1, [fp, #-0x10]
    //     0x12f8728: stur            x2, [fp, #-0x18]
    //     0x12f872c: stur            x3, [fp, #-0x20]
    // 0x12f8730: CheckStackOverflow
    //     0x12f8730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f8734: cmp             SP, x16
    //     0x12f8738: b.ls            #0x12f8a04
    // 0x12f873c: LoadField: r0 = r4->field_23
    //     0x12f873c: ldur            w0, [x4, #0x23]
    // 0x12f8740: DecompressPointer r0
    //     0x12f8740: add             x0, x0, HEAP, lsl #32
    // 0x12f8744: cmp             w0, NULL
    // 0x12f8748: b.eq            #0x12f89e4
    // 0x12f874c: LoadField: r0 = r4->field_b
    //     0x12f874c: ldur            w0, [x4, #0xb]
    // 0x12f8750: DecompressPointer r0
    //     0x12f8750: add             x0, x0, HEAP, lsl #32
    // 0x12f8754: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x12f8754: ldur            w5, [x0, #0x17]
    // 0x12f8758: DecompressPointer r5
    //     0x12f8758: add             x5, x5, HEAP, lsl #32
    // 0x12f875c: stur            x5, [fp, #-8]
    // 0x12f8760: r0 = LoadClassIdInstr(r5)
    //     0x12f8760: ldur            x0, [x5, #-1]
    //     0x12f8764: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8768: mov             x1, x5
    // 0x12f876c: r0 = GDT[cid_x0 + -0xf28]()
    //     0x12f876c: sub             lr, x0, #0xf28
    //     0x12f8770: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8774: blr             lr
    // 0x12f8778: tbnz            w0, #4, #0x12f8874
    // 0x12f877c: r7 = 0
    //     0x12f877c: mov             x7, #0
    // 0x12f8780: ldur            x4, [fp, #-0x10]
    // 0x12f8784: ldur            x6, [fp, #-8]
    // 0x12f8788: stur            x7, [fp, #-0x28]
    // 0x12f878c: CheckStackOverflow
    //     0x12f878c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f8790: cmp             SP, x16
    //     0x12f8794: b.ls            #0x12f8a0c
    // 0x12f8798: LoadField: r0 = r4->field_23
    //     0x12f8798: ldur            w0, [x4, #0x23]
    // 0x12f879c: DecompressPointer r0
    //     0x12f879c: add             x0, x0, HEAP, lsl #32
    // 0x12f87a0: cmp             w0, NULL
    // 0x12f87a4: b.eq            #0x12f8a14
    // 0x12f87a8: r1 = LoadInt32Instr(r0)
    //     0x12f87a8: sbfx            x1, x0, #1, #0x1f
    //     0x12f87ac: tbz             w0, #0, #0x12f87b4
    //     0x12f87b0: ldur            x1, [x0, #7]
    // 0x12f87b4: cmp             x7, x1
    // 0x12f87b8: b.ge            #0x12f89e4
    // 0x12f87bc: LoadField: r2 = r4->field_27
    //     0x12f87bc: ldur            w2, [x4, #0x27]
    // 0x12f87c0: DecompressPointer r2
    //     0x12f87c0: add             x2, x2, HEAP, lsl #32
    // 0x12f87c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f87c8: cmp             w2, w16
    // 0x12f87cc: b.eq            #0x12f8a18
    // 0x12f87d0: LoadField: r0 = r2->field_b
    //     0x12f87d0: ldur            w0, [x2, #0xb]
    // 0x12f87d4: r1 = LoadInt32Instr(r0)
    //     0x12f87d4: sbfx            x1, x0, #1, #0x1f
    // 0x12f87d8: mov             x0, x1
    // 0x12f87dc: mov             x1, x7
    // 0x12f87e0: cmp             x1, x0
    // 0x12f87e4: b.hs            #0x12f8a24
    // 0x12f87e8: LoadField: r0 = r2->field_f
    //     0x12f87e8: ldur            w0, [x2, #0xf]
    // 0x12f87ec: DecompressPointer r0
    //     0x12f87ec: add             x0, x0, HEAP, lsl #32
    // 0x12f87f0: ArrayLoad: r3 = r0[r7]  ; Unknown_4
    //     0x12f87f0: add             x16, x0, x7, lsl #2
    //     0x12f87f4: ldur            w3, [x16, #0xf]
    // 0x12f87f8: DecompressPointer r3
    //     0x12f87f8: add             x3, x3, HEAP, lsl #32
    // 0x12f87fc: LoadField: r2 = r4->field_2f
    //     0x12f87fc: ldur            w2, [x4, #0x2f]
    // 0x12f8800: DecompressPointer r2
    //     0x12f8800: add             x2, x2, HEAP, lsl #32
    // 0x12f8804: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f8808: cmp             w2, w16
    // 0x12f880c: b.eq            #0x12f8a28
    // 0x12f8810: LoadField: r0 = r2->field_b
    //     0x12f8810: ldur            w0, [x2, #0xb]
    // 0x12f8814: r1 = LoadInt32Instr(r0)
    //     0x12f8814: sbfx            x1, x0, #1, #0x1f
    // 0x12f8818: mov             x0, x1
    // 0x12f881c: mov             x1, x7
    // 0x12f8820: cmp             x1, x0
    // 0x12f8824: b.hs            #0x12f8a34
    // 0x12f8828: LoadField: r0 = r2->field_f
    //     0x12f8828: ldur            w0, [x2, #0xf]
    // 0x12f882c: DecompressPointer r0
    //     0x12f882c: add             x0, x0, HEAP, lsl #32
    // 0x12f8830: ArrayLoad: r5 = r0[r7]  ; Unknown_4
    //     0x12f8830: add             x16, x0, x7, lsl #2
    //     0x12f8834: ldur            w5, [x16, #0xf]
    // 0x12f8838: DecompressPointer r5
    //     0x12f8838: add             x5, x5, HEAP, lsl #32
    // 0x12f883c: r0 = LoadClassIdInstr(r6)
    //     0x12f883c: ldur            x0, [x6, #-1]
    //     0x12f8840: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8844: ldur            x16, [fp, #-0x20]
    // 0x12f8848: str             x16, [SP]
    // 0x12f884c: mov             x1, x6
    // 0x12f8850: ldur            x2, [fp, #-0x18]
    // 0x12f8854: r4 = const [0, 0x5, 0x1, 0x4, textDirection, 0x4, null]
    //     0x12f8854: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0cc0] List(7) [0, 0x5, 0x1, 0x4, "textDirection", 0x4, Null]
    //     0x12f8858: ldr             x4, [x4, #0xcc0]
    // 0x12f885c: r0 = GDT[cid_x0 + -0xe3d]()
    //     0x12f885c: sub             lr, x0, #0xe3d
    //     0x12f8860: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8864: blr             lr
    // 0x12f8868: ldur            x0, [fp, #-0x28]
    // 0x12f886c: add             x7, x0, #1
    // 0x12f8870: b               #0x12f8780
    // 0x12f8874: r4 = 0
    //     0x12f8874: mov             x4, #0
    // 0x12f8878: ldur            x2, [fp, #-0x10]
    // 0x12f887c: ldur            x3, [fp, #-0x18]
    // 0x12f8880: stur            x4, [fp, #-0x38]
    // 0x12f8884: CheckStackOverflow
    //     0x12f8884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f8888: cmp             SP, x16
    //     0x12f888c: b.ls            #0x12f8a38
    // 0x12f8890: LoadField: r0 = r2->field_23
    //     0x12f8890: ldur            w0, [x2, #0x23]
    // 0x12f8894: DecompressPointer r0
    //     0x12f8894: add             x0, x0, HEAP, lsl #32
    // 0x12f8898: cmp             w0, NULL
    // 0x12f889c: b.eq            #0x12f8a40
    // 0x12f88a0: r1 = LoadInt32Instr(r0)
    //     0x12f88a0: sbfx            x1, x0, #1, #0x1f
    //     0x12f88a4: tbz             w0, #0, #0x12f88ac
    //     0x12f88a8: ldur            x1, [x0, #7]
    // 0x12f88ac: cmp             x4, x1
    // 0x12f88b0: b.ge            #0x12f89e4
    // 0x12f88b4: LoadField: r5 = r2->field_2b
    //     0x12f88b4: ldur            w5, [x2, #0x2b]
    // 0x12f88b8: DecompressPointer r5
    //     0x12f88b8: add             x5, x5, HEAP, lsl #32
    // 0x12f88bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f88c0: cmp             w5, w16
    // 0x12f88c4: b.eq            #0x12f8a44
    // 0x12f88c8: LoadField: r0 = r5->field_b
    //     0x12f88c8: ldur            w0, [x5, #0xb]
    // 0x12f88cc: r1 = LoadInt32Instr(r0)
    //     0x12f88cc: sbfx            x1, x0, #1, #0x1f
    // 0x12f88d0: mov             x0, x1
    // 0x12f88d4: mov             x1, x4
    // 0x12f88d8: cmp             x1, x0
    // 0x12f88dc: b.hs            #0x12f8a50
    // 0x12f88e0: LoadField: r0 = r5->field_f
    //     0x12f88e0: ldur            w0, [x5, #0xf]
    // 0x12f88e4: DecompressPointer r0
    //     0x12f88e4: add             x0, x0, HEAP, lsl #32
    // 0x12f88e8: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x12f88e8: add             x16, x0, x4, lsl #2
    //     0x12f88ec: ldur            w5, [x16, #0xf]
    // 0x12f88f0: DecompressPointer r5
    //     0x12f88f0: add             x5, x5, HEAP, lsl #32
    // 0x12f88f4: stur            x5, [fp, #-0x30]
    // 0x12f88f8: LoadField: r6 = r2->field_2f
    //     0x12f88f8: ldur            w6, [x2, #0x2f]
    // 0x12f88fc: DecompressPointer r6
    //     0x12f88fc: add             x6, x6, HEAP, lsl #32
    // 0x12f8900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f8904: cmp             w6, w16
    // 0x12f8908: b.eq            #0x12f8a54
    // 0x12f890c: LoadField: r0 = r6->field_b
    //     0x12f890c: ldur            w0, [x6, #0xb]
    // 0x12f8910: r1 = LoadInt32Instr(r0)
    //     0x12f8910: sbfx            x1, x0, #1, #0x1f
    // 0x12f8914: mov             x0, x1
    // 0x12f8918: mov             x1, x4
    // 0x12f891c: cmp             x1, x0
    // 0x12f8920: b.hs            #0x12f8a60
    // 0x12f8924: LoadField: r0 = r6->field_f
    //     0x12f8924: ldur            w0, [x6, #0xf]
    // 0x12f8928: DecompressPointer r0
    //     0x12f8928: add             x0, x0, HEAP, lsl #32
    // 0x12f892c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x12f892c: add             x16, x0, x4, lsl #2
    //     0x12f8930: ldur            w1, [x16, #0xf]
    // 0x12f8934: DecompressPointer r1
    //     0x12f8934: add             x1, x1, HEAP, lsl #32
    // 0x12f8938: LoadField: r0 = r1->field_b
    //     0x12f8938: ldur            w0, [x1, #0xb]
    // 0x12f893c: DecompressPointer r0
    //     0x12f893c: add             x0, x0, HEAP, lsl #32
    // 0x12f8940: stur            x0, [fp, #-0x20]
    // 0x12f8944: LoadField: r6 = r1->field_7
    //     0x12f8944: ldur            w6, [x1, #7]
    // 0x12f8948: DecompressPointer r6
    //     0x12f8948: add             x6, x6, HEAP, lsl #32
    // 0x12f894c: stur            x6, [fp, #-8]
    // 0x12f8950: LoadField: r1 = r3->field_7
    //     0x12f8950: ldur            w1, [x3, #7]
    // 0x12f8954: DecompressPointer r1
    //     0x12f8954: add             x1, x1, HEAP, lsl #32
    // 0x12f8958: cmp             w1, NULL
    // 0x12f895c: b.eq            #0x12f8a64
    // 0x12f8960: LoadField: r7 = r1->field_7
    //     0x12f8960: ldur            x7, [x1, #7]
    // 0x12f8964: ldr             x1, [x7]
    // 0x12f8968: cbz             x1, #0x12f89f4
    // 0x12f896c: mov             x7, x1
    // 0x12f8970: stur            x7, [fp, #-0x28]
    // 0x12f8974: r1 = <Never>
    //     0x12f8974: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f8978: r0 = Pointer()
    //     0x12f8978: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f897c: mov             x2, x0
    // 0x12f8980: ldur            x0, [fp, #-0x28]
    // 0x12f8984: stur            x2, [fp, #-0x40]
    // 0x12f8988: StoreField: r2->field_7 = r0
    //     0x12f8988: stur            x0, [x2, #7]
    // 0x12f898c: ldur            x0, [fp, #-0x30]
    // 0x12f8990: LoadField: r1 = r0->field_7
    //     0x12f8990: ldur            w1, [x0, #7]
    // 0x12f8994: DecompressPointer r1
    //     0x12f8994: add             x1, x1, HEAP, lsl #32
    // 0x12f8998: cmp             w1, NULL
    // 0x12f899c: b.eq            #0x12f8a68
    // 0x12f89a0: LoadField: r3 = r1->field_7
    //     0x12f89a0: ldur            x3, [x1, #7]
    // 0x12f89a4: ldr             x1, [x3]
    // 0x12f89a8: mov             x3, x1
    // 0x12f89ac: stur            x3, [fp, #-0x28]
    // 0x12f89b0: r1 = <Never>
    //     0x12f89b0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f89b4: r0 = Pointer()
    //     0x12f89b4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f89b8: mov             x1, x0
    // 0x12f89bc: ldur            x0, [fp, #-0x28]
    // 0x12f89c0: StoreField: r1->field_7 = r0
    //     0x12f89c0: stur            x0, [x1, #7]
    // 0x12f89c4: mov             x2, x1
    // 0x12f89c8: ldur            x1, [fp, #-0x40]
    // 0x12f89cc: ldur            x3, [fp, #-0x20]
    // 0x12f89d0: ldur            x5, [fp, #-8]
    // 0x12f89d4: r0 = __drawPath$Method$FfiNative()
    //     0x12f89d4: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f89d8: ldur            x0, [fp, #-0x38]
    // 0x12f89dc: add             x4, x0, #1
    // 0x12f89e0: b               #0x12f8878
    // 0x12f89e4: r0 = Null
    //     0x12f89e4: mov             x0, NULL
    // 0x12f89e8: LeaveFrame
    //     0x12f89e8: mov             SP, fp
    //     0x12f89ec: ldp             fp, lr, [SP], #0x10
    // 0x12f89f0: ret
    //     0x12f89f0: ret             
    // 0x12f89f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f89f4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f89f8: str             x16, [SP]
    // 0x12f89fc: r0 = _throwNew()
    //     0x12f89fc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f8a00: brk             #0
    // 0x12f8a04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f8a04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f8a08: b               #0x12f873c
    // 0x12f8a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f8a0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f8a10: b               #0x12f8798
    // 0x12f8a14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f8a14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f8a18: r9 = _shadowBounds
    //     0x12f8a18: add             x9, PP, #0xa0, lsl #12  ; [pp+0xa0ce8] Field <_ShapeDecorationPainter@804037234._shadowBounds@804037234>: late (offset: 0x28)
    //     0x12f8a1c: ldr             x9, [x9, #0xce8]
    // 0x12f8a20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12f8a20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12f8a24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f8a24: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12f8a28: r9 = _shadowPaints
    //     0x12f8a28: add             x9, PP, #0xa0, lsl #12  ; [pp+0xa0cf0] Field <_ShapeDecorationPainter@804037234._shadowPaints@804037234>: late (offset: 0x30)
    //     0x12f8a2c: ldr             x9, [x9, #0xcf0]
    // 0x12f8a30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12f8a30: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12f8a34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f8a34: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12f8a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f8a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f8a3c: b               #0x12f8890
    // 0x12f8a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f8a40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f8a44: r9 = _shadowPaths
    //     0x12f8a44: add             x9, PP, #0xa0, lsl #12  ; [pp+0xa0cf8] Field <_ShapeDecorationPainter@804037234._shadowPaths@804037234>: late (offset: 0x2c)
    //     0x12f8a48: ldr             x9, [x9, #0xcf8]
    // 0x12f8a4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12f8a4c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12f8a50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f8a50: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12f8a54: r9 = _shadowPaints
    //     0x12f8a54: add             x9, PP, #0xa0, lsl #12  ; [pp+0xa0cf0] Field <_ShapeDecorationPainter@804037234._shadowPaints@804037234>: late (offset: 0x30)
    //     0x12f8a58: ldr             x9, [x9, #0xcf0]
    // 0x12f8a5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12f8a5c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12f8a60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f8a60: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12f8a64: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f8a64: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f8a68: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f8a68: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _precache(/* No info */) {
    // ** addr: 0x12f8a6c, size: 0xa7c
    // 0x12f8a6c: EnterFrame
    //     0x12f8a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f8a70: mov             fp, SP
    // 0x12f8a74: AllocStack(0x78)
    //     0x12f8a74: sub             SP, SP, #0x78
    // 0x12f8a78: SetupParameters(_ShapeDecorationPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12f8a78: stur            x1, [fp, #-8]
    //     0x12f8a7c: stur            x2, [fp, #-0x10]
    //     0x12f8a80: stur            x3, [fp, #-0x18]
    // 0x12f8a84: CheckStackOverflow
    //     0x12f8a84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f8a88: cmp             SP, x16
    //     0x12f8a8c: b.ls            #0x12f94d4
    // 0x12f8a90: r1 = 3
    //     0x12f8a90: mov             x1, #3
    // 0x12f8a94: r0 = AllocateContext()
    //     0x12f8a94: bl              #0x13de838  ; AllocateContextStub
    // 0x12f8a98: mov             x1, x0
    // 0x12f8a9c: ldur            x0, [fp, #-8]
    // 0x12f8aa0: stur            x1, [fp, #-0x20]
    // 0x12f8aa4: StoreField: r1->field_f = r0
    //     0x12f8aa4: stur            w0, [x1, #0xf]
    // 0x12f8aa8: ldur            x2, [fp, #-0x10]
    // 0x12f8aac: StoreField: r1->field_13 = r2
    //     0x12f8aac: stur            w2, [x1, #0x13]
    // 0x12f8ab0: ldur            x3, [fp, #-0x18]
    // 0x12f8ab4: ArrayStore: r1[0] = r3  ; List_4
    //     0x12f8ab4: stur            w3, [x1, #0x17]
    // 0x12f8ab8: LoadField: r3 = r0->field_f
    //     0x12f8ab8: ldur            w3, [x0, #0xf]
    // 0x12f8abc: DecompressPointer r3
    //     0x12f8abc: add             x3, x3, HEAP, lsl #32
    // 0x12f8ac0: stp             x3, x2, [SP]
    // 0x12f8ac4: r0 = ==()
    //     0x12f8ac4: bl              #0x128bdfc  ; [dart:ui] Rect::==
    // 0x12f8ac8: tbnz            w0, #4, #0x12f8afc
    // 0x12f8acc: ldur            x0, [fp, #-8]
    // 0x12f8ad0: ldur            x2, [fp, #-0x20]
    // 0x12f8ad4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x12f8ad4: ldur            w1, [x2, #0x17]
    // 0x12f8ad8: DecompressPointer r1
    //     0x12f8ad8: add             x1, x1, HEAP, lsl #32
    // 0x12f8adc: LoadField: r3 = r0->field_13
    //     0x12f8adc: ldur            w3, [x0, #0x13]
    // 0x12f8ae0: DecompressPointer r3
    //     0x12f8ae0: add             x3, x3, HEAP, lsl #32
    // 0x12f8ae4: cmp             w1, w3
    // 0x12f8ae8: b.ne            #0x12f8b04
    // 0x12f8aec: r0 = Null
    //     0x12f8aec: mov             x0, NULL
    // 0x12f8af0: LeaveFrame
    //     0x12f8af0: mov             SP, fp
    //     0x12f8af4: ldp             fp, lr, [SP], #0x10
    // 0x12f8af8: ret
    //     0x12f8af8: ret             
    // 0x12f8afc: ldur            x0, [fp, #-8]
    // 0x12f8b00: ldur            x2, [fp, #-0x20]
    // 0x12f8b04: LoadField: r1 = r0->field_1f
    //     0x12f8b04: ldur            w1, [x0, #0x1f]
    // 0x12f8b08: DecompressPointer r1
    //     0x12f8b08: add             x1, x1, HEAP, lsl #32
    // 0x12f8b0c: cmp             w1, NULL
    // 0x12f8b10: b.ne            #0x12f8b94
    // 0x12f8b14: LoadField: r1 = r0->field_b
    //     0x12f8b14: ldur            w1, [x0, #0xb]
    // 0x12f8b18: DecompressPointer r1
    //     0x12f8b18: add             x1, x1, HEAP, lsl #32
    // 0x12f8b1c: LoadField: r3 = r1->field_7
    //     0x12f8b1c: ldur            w3, [x1, #7]
    // 0x12f8b20: DecompressPointer r3
    //     0x12f8b20: add             x3, x3, HEAP, lsl #32
    // 0x12f8b24: stur            x3, [fp, #-0x10]
    // 0x12f8b28: cmp             w3, NULL
    // 0x12f8b2c: b.ne            #0x12f8b40
    // 0x12f8b30: LoadField: r4 = r1->field_b
    //     0x12f8b30: ldur            w4, [x1, #0xb]
    // 0x12f8b34: DecompressPointer r4
    //     0x12f8b34: add             x4, x4, HEAP, lsl #32
    // 0x12f8b38: cmp             w4, NULL
    // 0x12f8b3c: b.eq            #0x12f8b94
    // 0x12f8b40: r16 = 136
    //     0x12f8b40: mov             x16, #0x88
    // 0x12f8b44: stp             x16, NULL, [SP]
    // 0x12f8b48: r0 = ByteData()
    //     0x12f8b48: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f8b4c: stur            x0, [fp, #-0x18]
    // 0x12f8b50: r0 = Paint()
    //     0x12f8b50: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f8b54: mov             x1, x0
    // 0x12f8b58: ldur            x0, [fp, #-0x18]
    // 0x12f8b5c: StoreField: r1->field_7 = r0
    //     0x12f8b5c: stur            w0, [x1, #7]
    // 0x12f8b60: mov             x0, x1
    // 0x12f8b64: ldur            x3, [fp, #-8]
    // 0x12f8b68: StoreField: r3->field_1f = r0
    //     0x12f8b68: stur            w0, [x3, #0x1f]
    //     0x12f8b6c: ldurb           w16, [x3, #-1]
    //     0x12f8b70: ldurb           w17, [x0, #-1]
    //     0x12f8b74: and             x16, x17, x16, lsr #2
    //     0x12f8b78: tst             x16, HEAP, lsr #32
    //     0x12f8b7c: b.eq            #0x12f8b84
    //     0x12f8b80: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12f8b84: ldur            x2, [fp, #-0x10]
    // 0x12f8b88: cmp             w2, NULL
    // 0x12f8b8c: b.eq            #0x12f8b94
    // 0x12f8b90: r0 = color=()
    //     0x12f8b90: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f8b94: ldur            x0, [fp, #-8]
    // 0x12f8b98: LoadField: r1 = r0->field_b
    //     0x12f8b98: ldur            w1, [x0, #0xb]
    // 0x12f8b9c: DecompressPointer r1
    //     0x12f8b9c: add             x1, x1, HEAP, lsl #32
    // 0x12f8ba0: stur            x1, [fp, #-0x30]
    // 0x12f8ba4: LoadField: r2 = r1->field_b
    //     0x12f8ba4: ldur            w2, [x1, #0xb]
    // 0x12f8ba8: DecompressPointer r2
    //     0x12f8ba8: add             x2, x2, HEAP, lsl #32
    // 0x12f8bac: stur            x2, [fp, #-0x28]
    // 0x12f8bb0: cmp             w2, NULL
    // 0x12f8bb4: b.eq            #0x12f8de8
    // 0x12f8bb8: ldur            x3, [fp, #-0x20]
    // 0x12f8bbc: LoadField: r4 = r0->field_1f
    //     0x12f8bbc: ldur            w4, [x0, #0x1f]
    // 0x12f8bc0: DecompressPointer r4
    //     0x12f8bc0: add             x4, x4, HEAP, lsl #32
    // 0x12f8bc4: stur            x4, [fp, #-0x18]
    // 0x12f8bc8: cmp             w4, NULL
    // 0x12f8bcc: b.eq            #0x12f94dc
    // 0x12f8bd0: LoadField: r5 = r3->field_13
    //     0x12f8bd0: ldur            w5, [x3, #0x13]
    // 0x12f8bd4: DecompressPointer r5
    //     0x12f8bd4: add             x5, x5, HEAP, lsl #32
    // 0x12f8bd8: stur            x5, [fp, #-0x10]
    // 0x12f8bdc: ArrayLoad: r6 = r3[0]  ; List_4
    //     0x12f8bdc: ldur            w6, [x3, #0x17]
    // 0x12f8be0: DecompressPointer r6
    //     0x12f8be0: add             x6, x6, HEAP, lsl #32
    // 0x12f8be4: r7 = LoadClassIdInstr(r2)
    //     0x12f8be4: ldur            x7, [x2, #-1]
    //     0x12f8be8: ubfx            x7, x7, #0xc, #0x14
    // 0x12f8bec: cmp             x7, #0xb73
    // 0x12f8bf0: b.ne            #0x12f8d88
    // 0x12f8bf4: LoadField: r7 = r2->field_13
    //     0x12f8bf4: ldur            w7, [x2, #0x13]
    // 0x12f8bf8: DecompressPointer r7
    //     0x12f8bf8: add             x7, x7, HEAP, lsl #32
    // 0x12f8bfc: r8 = LoadClassIdInstr(r7)
    //     0x12f8bfc: ldur            x8, [x7, #-1]
    //     0x12f8c00: ubfx            x8, x8, #0xc, #0x14
    // 0x12f8c04: sub             x16, x8, #0xb8e
    // 0x12f8c08: cmp             x16, #1
    // 0x12f8c0c: b.hi            #0x12f8c1c
    // 0x12f8c10: mov             x1, x7
    // 0x12f8c14: mov             x0, x2
    // 0x12f8c18: b               #0x12f8d0c
    // 0x12f8c1c: cmp             x8, #0xb8c
    // 0x12f8c20: b.ne            #0x12f8ca0
    // 0x12f8c24: cmp             w6, NULL
    // 0x12f8c28: b.eq            #0x12f94e0
    // 0x12f8c2c: LoadField: r8 = r6->field_7
    //     0x12f8c2c: ldur            x8, [x6, #7]
    // 0x12f8c30: cmp             x8, #0
    // 0x12f8c34: b.gt            #0x12f8c68
    // 0x12f8c38: LoadField: d0 = r7->field_7
    //     0x12f8c38: ldur            d0, [x7, #7]
    // 0x12f8c3c: LoadField: d1 = r7->field_f
    //     0x12f8c3c: ldur            d1, [x7, #0xf]
    // 0x12f8c40: fsub            d2, d0, d1
    // 0x12f8c44: stur            d2, [fp, #-0x60]
    // 0x12f8c48: ArrayLoad: d0 = r7[0]  ; List_8
    //     0x12f8c48: ldur            d0, [x7, #0x17]
    // 0x12f8c4c: stur            d0, [fp, #-0x58]
    // 0x12f8c50: r0 = Alignment()
    //     0x12f8c50: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f8c54: ldur            d0, [fp, #-0x60]
    // 0x12f8c58: StoreField: r0->field_7 = d0
    //     0x12f8c58: stur            d0, [x0, #7]
    // 0x12f8c5c: ldur            d0, [fp, #-0x58]
    // 0x12f8c60: StoreField: r0->field_f = d0
    //     0x12f8c60: stur            d0, [x0, #0xf]
    // 0x12f8c64: b               #0x12f8c94
    // 0x12f8c68: LoadField: d0 = r7->field_7
    //     0x12f8c68: ldur            d0, [x7, #7]
    // 0x12f8c6c: LoadField: d1 = r7->field_f
    //     0x12f8c6c: ldur            d1, [x7, #0xf]
    // 0x12f8c70: fadd            d2, d0, d1
    // 0x12f8c74: stur            d2, [fp, #-0x60]
    // 0x12f8c78: ArrayLoad: d0 = r7[0]  ; List_8
    //     0x12f8c78: ldur            d0, [x7, #0x17]
    // 0x12f8c7c: stur            d0, [fp, #-0x58]
    // 0x12f8c80: r0 = Alignment()
    //     0x12f8c80: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f8c84: ldur            d0, [fp, #-0x60]
    // 0x12f8c88: StoreField: r0->field_7 = d0
    //     0x12f8c88: stur            d0, [x0, #7]
    // 0x12f8c8c: ldur            d0, [fp, #-0x58]
    // 0x12f8c90: StoreField: r0->field_f = d0
    //     0x12f8c90: stur            d0, [x0, #0xf]
    // 0x12f8c94: mov             x1, x0
    // 0x12f8c98: ldur            x0, [fp, #-0x28]
    // 0x12f8c9c: b               #0x12f8d0c
    // 0x12f8ca0: cmp             w6, NULL
    // 0x12f8ca4: b.eq            #0x12f94e4
    // 0x12f8ca8: LoadField: r0 = r6->field_7
    //     0x12f8ca8: ldur            x0, [x6, #7]
    // 0x12f8cac: cmp             x0, #0
    // 0x12f8cb0: b.gt            #0x12f8ce0
    // 0x12f8cb4: LoadField: d0 = r7->field_7
    //     0x12f8cb4: ldur            d0, [x7, #7]
    // 0x12f8cb8: fneg            d1, d0
    // 0x12f8cbc: stur            d1, [fp, #-0x60]
    // 0x12f8cc0: LoadField: d0 = r7->field_f
    //     0x12f8cc0: ldur            d0, [x7, #0xf]
    // 0x12f8cc4: stur            d0, [fp, #-0x58]
    // 0x12f8cc8: r0 = Alignment()
    //     0x12f8cc8: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f8ccc: ldur            d0, [fp, #-0x60]
    // 0x12f8cd0: StoreField: r0->field_7 = d0
    //     0x12f8cd0: stur            d0, [x0, #7]
    // 0x12f8cd4: ldur            d0, [fp, #-0x58]
    // 0x12f8cd8: StoreField: r0->field_f = d0
    //     0x12f8cd8: stur            d0, [x0, #0xf]
    // 0x12f8cdc: b               #0x12f8d04
    // 0x12f8ce0: LoadField: d0 = r7->field_7
    //     0x12f8ce0: ldur            d0, [x7, #7]
    // 0x12f8ce4: stur            d0, [fp, #-0x60]
    // 0x12f8ce8: LoadField: d1 = r7->field_f
    //     0x12f8ce8: ldur            d1, [x7, #0xf]
    // 0x12f8cec: stur            d1, [fp, #-0x58]
    // 0x12f8cf0: r0 = Alignment()
    //     0x12f8cf0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f8cf4: ldur            d0, [fp, #-0x60]
    // 0x12f8cf8: StoreField: r0->field_7 = d0
    //     0x12f8cf8: stur            d0, [x0, #7]
    // 0x12f8cfc: ldur            d0, [fp, #-0x58]
    // 0x12f8d00: StoreField: r0->field_f = d0
    //     0x12f8d00: stur            d0, [x0, #0xf]
    // 0x12f8d04: mov             x1, x0
    // 0x12f8d08: ldur            x0, [fp, #-0x28]
    // 0x12f8d0c: ldur            x2, [fp, #-0x10]
    // 0x12f8d10: r0 = withinRect()
    //     0x12f8d10: bl              #0x12f7c84  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0x12f8d14: mov             x2, x0
    // 0x12f8d18: ldur            x0, [fp, #-0x28]
    // 0x12f8d1c: stur            x2, [fp, #-0x40]
    // 0x12f8d20: LoadField: r3 = r0->field_7
    //     0x12f8d20: ldur            w3, [x0, #7]
    // 0x12f8d24: DecompressPointer r3
    //     0x12f8d24: add             x3, x3, HEAP, lsl #32
    // 0x12f8d28: mov             x1, x0
    // 0x12f8d2c: stur            x3, [fp, #-0x38]
    // 0x12f8d30: r0 = _impliedStops()
    //     0x12f8d30: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x12f8d34: ldur            x1, [fp, #-0x28]
    // 0x12f8d38: stur            x0, [fp, #-0x48]
    // 0x12f8d3c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x12f8d3c: ldur            d0, [x1, #0x17]
    // 0x12f8d40: stur            d0, [fp, #-0x60]
    // 0x12f8d44: LoadField: d1 = r1->field_1f
    //     0x12f8d44: ldur            d1, [x1, #0x1f]
    // 0x12f8d48: ldur            x2, [fp, #-0x10]
    // 0x12f8d4c: stur            d1, [fp, #-0x58]
    // 0x12f8d50: r0 = _resolveTransform()
    //     0x12f8d50: bl              #0x12f7c18  ; [package:flutter/src/painting/gradient.dart] Gradient::_resolveTransform
    // 0x12f8d54: stur            x0, [fp, #-0x50]
    // 0x12f8d58: r0 = Gradient()
    //     0x12f8d58: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x12f8d5c: mov             x1, x0
    // 0x12f8d60: ldur            x2, [fp, #-0x40]
    // 0x12f8d64: ldur            x3, [fp, #-0x38]
    // 0x12f8d68: ldur            x5, [fp, #-0x48]
    // 0x12f8d6c: ldur            d0, [fp, #-0x60]
    // 0x12f8d70: ldur            d1, [fp, #-0x58]
    // 0x12f8d74: ldur            x6, [fp, #-0x50]
    // 0x12f8d78: stur            x0, [fp, #-0x38]
    // 0x12f8d7c: r0 = Gradient.sweep()
    //     0x12f8d7c: bl              #0x12f7908  ; [dart:ui] Gradient::Gradient.sweep
    // 0x12f8d80: ldur            x0, [fp, #-0x38]
    // 0x12f8d84: b               #0x12f8db0
    // 0x12f8d88: mov             x1, x2
    // 0x12f8d8c: r0 = LoadClassIdInstr(r1)
    //     0x12f8d8c: ldur            x0, [x1, #-1]
    //     0x12f8d90: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8d94: str             x6, [SP]
    // 0x12f8d98: ldur            x2, [fp, #-0x10]
    // 0x12f8d9c: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12f8d9c: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12f8da0: ldr             x4, [x4, #0x638]
    // 0x12f8da4: r0 = GDT[cid_x0 + -0xffe]()
    //     0x12f8da4: sub             lr, x0, #0xffe
    //     0x12f8da8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8dac: blr             lr
    // 0x12f8db0: ldur            x1, [fp, #-0x18]
    // 0x12f8db4: stur            x0, [fp, #-0x10]
    // 0x12f8db8: r0 = _ensureObjectsInitialized()
    //     0x12f8db8: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x12f8dbc: r1 = LoadClassIdInstr(r0)
    //     0x12f8dbc: ldur            x1, [x0, #-1]
    //     0x12f8dc0: ubfx            x1, x1, #0xc, #0x14
    // 0x12f8dc4: stp             xzr, x0, [SP, #8]
    // 0x12f8dc8: ldur            x16, [fp, #-0x10]
    // 0x12f8dcc: str             x16, [SP]
    // 0x12f8dd0: mov             x0, x1
    // 0x12f8dd4: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x12f8dd4: mov             x17, #0x8dc8
    //     0x12f8dd8: movk            x17, #1, lsl #16
    //     0x12f8ddc: add             lr, x0, x17
    //     0x12f8de0: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8de4: blr             lr
    // 0x12f8de8: ldur            x1, [fp, #-0x30]
    // 0x12f8dec: LoadField: r2 = r1->field_13
    //     0x12f8dec: ldur            w2, [x1, #0x13]
    // 0x12f8df0: DecompressPointer r2
    //     0x12f8df0: add             x2, x2, HEAP, lsl #32
    // 0x12f8df4: stur            x2, [fp, #-0x10]
    // 0x12f8df8: cmp             w2, NULL
    // 0x12f8dfc: b.eq            #0x12f933c
    // 0x12f8e00: ldur            x3, [fp, #-8]
    // 0x12f8e04: LoadField: r0 = r3->field_23
    //     0x12f8e04: ldur            w0, [x3, #0x23]
    // 0x12f8e08: DecompressPointer r0
    //     0x12f8e08: add             x0, x0, HEAP, lsl #32
    // 0x12f8e0c: cmp             w0, NULL
    // 0x12f8e10: b.ne            #0x12f8fe8
    // 0x12f8e14: r0 = LoadClassIdInstr(r2)
    //     0x12f8e14: ldur            x0, [x2, #-1]
    //     0x12f8e18: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8e1c: str             x2, [SP]
    // 0x12f8e20: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f8e20: mov             x17, #0xf078
    //     0x12f8e24: add             lr, x0, x17
    //     0x12f8e28: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8e2c: blr             lr
    // 0x12f8e30: ldur            x3, [fp, #-8]
    // 0x12f8e34: StoreField: r3->field_23 = r0
    //     0x12f8e34: stur            w0, [x3, #0x23]
    //     0x12f8e38: tbz             w0, #0, #0x12f8e54
    //     0x12f8e3c: ldurb           w16, [x3, #-1]
    //     0x12f8e40: ldurb           w17, [x0, #-1]
    //     0x12f8e44: and             x16, x17, x16, lsr #2
    //     0x12f8e48: tst             x16, HEAP, lsr #32
    //     0x12f8e4c: b.eq            #0x12f8e54
    //     0x12f8e50: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12f8e54: r1 = Function '<anonymous closure>':.
    //     0x12f8e54: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0d00] AnonymousClosure: (0x12f9608), in [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache (0x12f8a6c)
    //     0x12f8e58: ldr             x1, [x1, #0xd00]
    // 0x12f8e5c: r2 = Null
    //     0x12f8e5c: mov             x2, NULL
    // 0x12f8e60: r0 = AllocateClosure()
    //     0x12f8e60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12f8e64: ldur            x1, [fp, #-0x10]
    // 0x12f8e68: r2 = LoadClassIdInstr(r1)
    //     0x12f8e68: ldur            x2, [x1, #-1]
    //     0x12f8e6c: ubfx            x2, x2, #0xc, #0x14
    // 0x12f8e70: r16 = <Paint>
    //     0x12f8e70: add             x16, PP, #0x88, lsl #12  ; [pp+0x889d0] TypeArguments: <Paint>
    //     0x12f8e74: ldr             x16, [x16, #0x9d0]
    // 0x12f8e78: stp             x1, x16, [SP, #8]
    // 0x12f8e7c: str             x0, [SP]
    // 0x12f8e80: mov             x0, x2
    // 0x12f8e84: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12f8e84: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12f8e88: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x12f8e88: mov             x17, #0x2caa
    //     0x12f8e8c: movk            x17, #1, lsl #16
    //     0x12f8e90: add             lr, x0, x17
    //     0x12f8e94: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8e98: blr             lr
    // 0x12f8e9c: mov             x3, x0
    // 0x12f8ea0: stur            x3, [fp, #-0x18]
    // 0x12f8ea4: r0 = LoadClassIdInstr(r3)
    //     0x12f8ea4: ldur            x0, [x3, #-1]
    //     0x12f8ea8: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8eac: cmp             x0, #0x5c
    // 0x12f8eb0: b.ne            #0x12f8ec8
    // 0x12f8eb4: mov             x2, x3
    // 0x12f8eb8: r1 = <Paint>
    //     0x12f8eb8: add             x1, PP, #0x88, lsl #12  ; [pp+0x889d0] TypeArguments: <Paint>
    //     0x12f8ebc: ldr             x1, [x1, #0x9d0]
    // 0x12f8ec0: r0 = _GrowableList._ofGrowableList()
    //     0x12f8ec0: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x12f8ec4: b               #0x12f8fc4
    // 0x12f8ec8: sub             x16, x0, #0x5a
    // 0x12f8ecc: cmp             x16, #1
    // 0x12f8ed0: b.hi            #0x12f8ee8
    // 0x12f8ed4: mov             x2, x3
    // 0x12f8ed8: r1 = <Paint>
    //     0x12f8ed8: add             x1, PP, #0x88, lsl #12  ; [pp+0x889d0] TypeArguments: <Paint>
    //     0x12f8edc: ldr             x1, [x1, #0x9d0]
    // 0x12f8ee0: r0 = _GrowableList._ofArray()
    //     0x12f8ee0: bl              #0x7d7adc  ; [dart:core] _GrowableList::_GrowableList._ofArray
    // 0x12f8ee4: b               #0x12f8fc4
    // 0x12f8ee8: mov             x0, x3
    // 0x12f8eec: r2 = Null
    //     0x12f8eec: mov             x2, NULL
    // 0x12f8ef0: r1 = Null
    //     0x12f8ef0: mov             x1, NULL
    // 0x12f8ef4: cmp             w0, NULL
    // 0x12f8ef8: b.eq            #0x12f8f90
    // 0x12f8efc: branchIfSmi(r0, 0x12f8f90)
    //     0x12f8efc: tbz             w0, #0, #0x12f8f90
    // 0x12f8f00: r3 = LoadClassIdInstr(r0)
    //     0x12f8f00: ldur            x3, [x0, #-1]
    //     0x12f8f04: ubfx            x3, x3, #0xc, #0x14
    // 0x12f8f08: r17 = 7724
    //     0x12f8f08: mov             x17, #0x1e2c
    // 0x12f8f0c: cmp             x3, x17
    // 0x12f8f10: b.eq            #0x12f8f98
    // 0x12f8f14: r4 = LoadClassIdInstr(r0)
    //     0x12f8f14: ldur            x4, [x0, #-1]
    //     0x12f8f18: ubfx            x4, x4, #0xc, #0x14
    // 0x12f8f1c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12f8f20: ldr             x3, [x3, #0x18]
    // 0x12f8f24: ldr             x3, [x3, x4, lsl #3]
    // 0x12f8f28: LoadField: r3 = r3->field_2b
    //     0x12f8f28: ldur            w3, [x3, #0x2b]
    // 0x12f8f2c: DecompressPointer r3
    //     0x12f8f2c: add             x3, x3, HEAP, lsl #32
    // 0x12f8f30: cmp             w3, NULL
    // 0x12f8f34: b.eq            #0x12f8f90
    // 0x12f8f38: LoadField: r3 = r3->field_f
    //     0x12f8f38: ldur            w3, [x3, #0xf]
    // 0x12f8f3c: lsr             x3, x3, #3
    // 0x12f8f40: r17 = 7724
    //     0x12f8f40: mov             x17, #0x1e2c
    // 0x12f8f44: cmp             x3, x17
    // 0x12f8f48: b.eq            #0x12f8f98
    // 0x12f8f4c: r3 = SubtypeTestCache
    //     0x12f8f4c: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d08] SubtypeTestCache
    //     0x12f8f50: ldr             x3, [x3, #0xd08]
    // 0x12f8f54: r30 = Subtype1TestCacheStub
    //     0x12f8f54: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12f8f58: LoadField: r30 = r30->field_7
    //     0x12f8f58: ldur            lr, [lr, #7]
    // 0x12f8f5c: blr             lr
    // 0x12f8f60: cmp             w7, NULL
    // 0x12f8f64: b.eq            #0x12f8f70
    // 0x12f8f68: tbnz            w7, #4, #0x12f8f90
    // 0x12f8f6c: b               #0x12f8f98
    // 0x12f8f70: r8 = EfficientLengthIterable
    //     0x12f8f70: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0d10] Type: EfficientLengthIterable
    //     0x12f8f74: ldr             x8, [x8, #0xd10]
    // 0x12f8f78: r3 = SubtypeTestCache
    //     0x12f8f78: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d18] SubtypeTestCache
    //     0x12f8f7c: ldr             x3, [x3, #0xd18]
    // 0x12f8f80: r30 = InstanceOfStub
    //     0x12f8f80: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12f8f84: LoadField: r30 = r30->field_7
    //     0x12f8f84: ldur            lr, [lr, #7]
    // 0x12f8f88: blr             lr
    // 0x12f8f8c: b               #0x12f8f9c
    // 0x12f8f90: r0 = false
    //     0x12f8f90: add             x0, NULL, #0x30  ; false
    // 0x12f8f94: b               #0x12f8f9c
    // 0x12f8f98: r0 = true
    //     0x12f8f98: add             x0, NULL, #0x20  ; true
    // 0x12f8f9c: tbnz            w0, #4, #0x12f8fb4
    // 0x12f8fa0: ldur            x2, [fp, #-0x18]
    // 0x12f8fa4: r1 = <Paint>
    //     0x12f8fa4: add             x1, PP, #0x88, lsl #12  ; [pp+0x889d0] TypeArguments: <Paint>
    //     0x12f8fa8: ldr             x1, [x1, #0x9d0]
    // 0x12f8fac: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x12f8fac: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x12f8fb0: b               #0x12f8fc4
    // 0x12f8fb4: ldur            x2, [fp, #-0x18]
    // 0x12f8fb8: r1 = <Paint>
    //     0x12f8fb8: add             x1, PP, #0x88, lsl #12  ; [pp+0x889d0] TypeArguments: <Paint>
    //     0x12f8fbc: ldr             x1, [x1, #0x9d0]
    // 0x12f8fc0: r0 = _GrowableList._ofOther()
    //     0x12f8fc0: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x12f8fc4: ldur            x2, [fp, #-8]
    // 0x12f8fc8: StoreField: r2->field_2f = r0
    //     0x12f8fc8: stur            w0, [x2, #0x2f]
    //     0x12f8fcc: ldurb           w16, [x2, #-1]
    //     0x12f8fd0: ldurb           w17, [x0, #-1]
    //     0x12f8fd4: and             x16, x17, x16, lsr #2
    //     0x12f8fd8: tst             x16, HEAP, lsr #32
    //     0x12f8fdc: b.eq            #0x12f8fe4
    //     0x12f8fe0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12f8fe4: b               #0x12f8fec
    // 0x12f8fe8: mov             x2, x3
    // 0x12f8fec: ldur            x3, [fp, #-0x30]
    // 0x12f8ff0: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x12f8ff0: ldur            w1, [x3, #0x17]
    // 0x12f8ff4: DecompressPointer r1
    //     0x12f8ff4: add             x1, x1, HEAP, lsl #32
    // 0x12f8ff8: r0 = LoadClassIdInstr(r1)
    //     0x12f8ff8: ldur            x0, [x1, #-1]
    //     0x12f8ffc: ubfx            x0, x0, #0xc, #0x14
    // 0x12f9000: r0 = GDT[cid_x0 + -0xf28]()
    //     0x12f9000: sub             lr, x0, #0xf28
    //     0x12f9004: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9008: blr             lr
    // 0x12f900c: tbnz            w0, #4, #0x12f919c
    // 0x12f9010: ldur            x0, [fp, #-0x10]
    // 0x12f9014: ldur            x2, [fp, #-0x20]
    // 0x12f9018: r1 = Function '<anonymous closure>':.
    //     0x12f9018: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0d20] AnonymousClosure: (0x12f95a8), in [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache (0x12f8a6c)
    //     0x12f901c: ldr             x1, [x1, #0xd20]
    // 0x12f9020: r0 = AllocateClosure()
    //     0x12f9020: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12f9024: mov             x1, x0
    // 0x12f9028: ldur            x0, [fp, #-0x10]
    // 0x12f902c: r2 = LoadClassIdInstr(r0)
    //     0x12f902c: ldur            x2, [x0, #-1]
    //     0x12f9030: ubfx            x2, x2, #0xc, #0x14
    // 0x12f9034: r16 = <Rect>
    //     0x12f9034: ldr             x16, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12f9038: stp             x0, x16, [SP, #8]
    // 0x12f903c: str             x1, [SP]
    // 0x12f9040: mov             x0, x2
    // 0x12f9044: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12f9044: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12f9048: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x12f9048: mov             x17, #0x2caa
    //     0x12f904c: movk            x17, #1, lsl #16
    //     0x12f9050: add             lr, x0, x17
    //     0x12f9054: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9058: blr             lr
    // 0x12f905c: mov             x3, x0
    // 0x12f9060: stur            x3, [fp, #-0x18]
    // 0x12f9064: r0 = LoadClassIdInstr(r3)
    //     0x12f9064: ldur            x0, [x3, #-1]
    //     0x12f9068: ubfx            x0, x0, #0xc, #0x14
    // 0x12f906c: cmp             x0, #0x5c
    // 0x12f9070: b.ne            #0x12f9084
    // 0x12f9074: mov             x2, x3
    // 0x12f9078: r1 = <Rect>
    //     0x12f9078: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12f907c: r0 = _GrowableList._ofGrowableList()
    //     0x12f907c: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x12f9080: b               #0x12f9174
    // 0x12f9084: sub             x16, x0, #0x5a
    // 0x12f9088: cmp             x16, #1
    // 0x12f908c: b.hi            #0x12f90a0
    // 0x12f9090: mov             x2, x3
    // 0x12f9094: r1 = <Rect>
    //     0x12f9094: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12f9098: r0 = _GrowableList._ofArray()
    //     0x12f9098: bl              #0x7d7adc  ; [dart:core] _GrowableList::_GrowableList._ofArray
    // 0x12f909c: b               #0x12f9174
    // 0x12f90a0: mov             x0, x3
    // 0x12f90a4: r2 = Null
    //     0x12f90a4: mov             x2, NULL
    // 0x12f90a8: r1 = Null
    //     0x12f90a8: mov             x1, NULL
    // 0x12f90ac: cmp             w0, NULL
    // 0x12f90b0: b.eq            #0x12f9148
    // 0x12f90b4: branchIfSmi(r0, 0x12f9148)
    //     0x12f90b4: tbz             w0, #0, #0x12f9148
    // 0x12f90b8: r3 = LoadClassIdInstr(r0)
    //     0x12f90b8: ldur            x3, [x0, #-1]
    //     0x12f90bc: ubfx            x3, x3, #0xc, #0x14
    // 0x12f90c0: r17 = 7724
    //     0x12f90c0: mov             x17, #0x1e2c
    // 0x12f90c4: cmp             x3, x17
    // 0x12f90c8: b.eq            #0x12f9150
    // 0x12f90cc: r4 = LoadClassIdInstr(r0)
    //     0x12f90cc: ldur            x4, [x0, #-1]
    //     0x12f90d0: ubfx            x4, x4, #0xc, #0x14
    // 0x12f90d4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12f90d8: ldr             x3, [x3, #0x18]
    // 0x12f90dc: ldr             x3, [x3, x4, lsl #3]
    // 0x12f90e0: LoadField: r3 = r3->field_2b
    //     0x12f90e0: ldur            w3, [x3, #0x2b]
    // 0x12f90e4: DecompressPointer r3
    //     0x12f90e4: add             x3, x3, HEAP, lsl #32
    // 0x12f90e8: cmp             w3, NULL
    // 0x12f90ec: b.eq            #0x12f9148
    // 0x12f90f0: LoadField: r3 = r3->field_f
    //     0x12f90f0: ldur            w3, [x3, #0xf]
    // 0x12f90f4: lsr             x3, x3, #3
    // 0x12f90f8: r17 = 7724
    //     0x12f90f8: mov             x17, #0x1e2c
    // 0x12f90fc: cmp             x3, x17
    // 0x12f9100: b.eq            #0x12f9150
    // 0x12f9104: r3 = SubtypeTestCache
    //     0x12f9104: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d28] SubtypeTestCache
    //     0x12f9108: ldr             x3, [x3, #0xd28]
    // 0x12f910c: r30 = Subtype1TestCacheStub
    //     0x12f910c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12f9110: LoadField: r30 = r30->field_7
    //     0x12f9110: ldur            lr, [lr, #7]
    // 0x12f9114: blr             lr
    // 0x12f9118: cmp             w7, NULL
    // 0x12f911c: b.eq            #0x12f9128
    // 0x12f9120: tbnz            w7, #4, #0x12f9148
    // 0x12f9124: b               #0x12f9150
    // 0x12f9128: r8 = EfficientLengthIterable
    //     0x12f9128: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0d30] Type: EfficientLengthIterable
    //     0x12f912c: ldr             x8, [x8, #0xd30]
    // 0x12f9130: r3 = SubtypeTestCache
    //     0x12f9130: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d38] SubtypeTestCache
    //     0x12f9134: ldr             x3, [x3, #0xd38]
    // 0x12f9138: r30 = InstanceOfStub
    //     0x12f9138: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12f913c: LoadField: r30 = r30->field_7
    //     0x12f913c: ldur            lr, [lr, #7]
    // 0x12f9140: blr             lr
    // 0x12f9144: b               #0x12f9154
    // 0x12f9148: r0 = false
    //     0x12f9148: add             x0, NULL, #0x30  ; false
    // 0x12f914c: b               #0x12f9154
    // 0x12f9150: r0 = true
    //     0x12f9150: add             x0, NULL, #0x20  ; true
    // 0x12f9154: tbnz            w0, #4, #0x12f9168
    // 0x12f9158: ldur            x2, [fp, #-0x18]
    // 0x12f915c: r1 = <Rect>
    //     0x12f915c: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12f9160: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x12f9160: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x12f9164: b               #0x12f9174
    // 0x12f9168: ldur            x2, [fp, #-0x18]
    // 0x12f916c: r1 = <Rect>
    //     0x12f916c: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12f9170: r0 = _GrowableList._ofOther()
    //     0x12f9170: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x12f9174: ldur            x3, [fp, #-8]
    // 0x12f9178: StoreField: r3->field_27 = r0
    //     0x12f9178: stur            w0, [x3, #0x27]
    //     0x12f917c: ldurb           w16, [x3, #-1]
    //     0x12f9180: ldurb           w17, [x0, #-1]
    //     0x12f9184: and             x16, x17, x16, lsr #2
    //     0x12f9188: tst             x16, HEAP, lsr #32
    //     0x12f918c: b.eq            #0x12f9194
    //     0x12f9190: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12f9194: mov             x2, x3
    // 0x12f9198: b               #0x12f9340
    // 0x12f919c: ldur            x3, [fp, #-8]
    // 0x12f91a0: ldur            x0, [fp, #-0x10]
    // 0x12f91a4: ldur            x2, [fp, #-0x20]
    // 0x12f91a8: r1 = Function '<anonymous closure>':.
    //     0x12f91a8: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0d40] AnonymousClosure: (0x12f94e8), in [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache (0x12f8a6c)
    //     0x12f91ac: ldr             x1, [x1, #0xd40]
    // 0x12f91b0: r0 = AllocateClosure()
    //     0x12f91b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12f91b4: mov             x1, x0
    // 0x12f91b8: ldur            x0, [fp, #-0x10]
    // 0x12f91bc: r2 = LoadClassIdInstr(r0)
    //     0x12f91bc: ldur            x2, [x0, #-1]
    //     0x12f91c0: ubfx            x2, x2, #0xc, #0x14
    // 0x12f91c4: r16 = <Path>
    //     0x12f91c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x12f91c8: ldr             x16, [x16, #0xa60]
    // 0x12f91cc: stp             x0, x16, [SP, #8]
    // 0x12f91d0: str             x1, [SP]
    // 0x12f91d4: mov             x0, x2
    // 0x12f91d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12f91d8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12f91dc: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x12f91dc: mov             x17, #0x2caa
    //     0x12f91e0: movk            x17, #1, lsl #16
    //     0x12f91e4: add             lr, x0, x17
    //     0x12f91e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f91ec: blr             lr
    // 0x12f91f0: mov             x3, x0
    // 0x12f91f4: stur            x3, [fp, #-0x10]
    // 0x12f91f8: r0 = LoadClassIdInstr(r3)
    //     0x12f91f8: ldur            x0, [x3, #-1]
    //     0x12f91fc: ubfx            x0, x0, #0xc, #0x14
    // 0x12f9200: cmp             x0, #0x5c
    // 0x12f9204: b.ne            #0x12f921c
    // 0x12f9208: mov             x2, x3
    // 0x12f920c: r1 = <Path>
    //     0x12f920c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x12f9210: ldr             x1, [x1, #0xa60]
    // 0x12f9214: r0 = _GrowableList._ofGrowableList()
    //     0x12f9214: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x12f9218: b               #0x12f9318
    // 0x12f921c: sub             x16, x0, #0x5a
    // 0x12f9220: cmp             x16, #1
    // 0x12f9224: b.hi            #0x12f923c
    // 0x12f9228: mov             x2, x3
    // 0x12f922c: r1 = <Path>
    //     0x12f922c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x12f9230: ldr             x1, [x1, #0xa60]
    // 0x12f9234: r0 = _GrowableList._ofArray()
    //     0x12f9234: bl              #0x7d7adc  ; [dart:core] _GrowableList::_GrowableList._ofArray
    // 0x12f9238: b               #0x12f9318
    // 0x12f923c: mov             x0, x3
    // 0x12f9240: r2 = Null
    //     0x12f9240: mov             x2, NULL
    // 0x12f9244: r1 = Null
    //     0x12f9244: mov             x1, NULL
    // 0x12f9248: cmp             w0, NULL
    // 0x12f924c: b.eq            #0x12f92e4
    // 0x12f9250: branchIfSmi(r0, 0x12f92e4)
    //     0x12f9250: tbz             w0, #0, #0x12f92e4
    // 0x12f9254: r3 = LoadClassIdInstr(r0)
    //     0x12f9254: ldur            x3, [x0, #-1]
    //     0x12f9258: ubfx            x3, x3, #0xc, #0x14
    // 0x12f925c: r17 = 7724
    //     0x12f925c: mov             x17, #0x1e2c
    // 0x12f9260: cmp             x3, x17
    // 0x12f9264: b.eq            #0x12f92ec
    // 0x12f9268: r4 = LoadClassIdInstr(r0)
    //     0x12f9268: ldur            x4, [x0, #-1]
    //     0x12f926c: ubfx            x4, x4, #0xc, #0x14
    // 0x12f9270: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12f9274: ldr             x3, [x3, #0x18]
    // 0x12f9278: ldr             x3, [x3, x4, lsl #3]
    // 0x12f927c: LoadField: r3 = r3->field_2b
    //     0x12f927c: ldur            w3, [x3, #0x2b]
    // 0x12f9280: DecompressPointer r3
    //     0x12f9280: add             x3, x3, HEAP, lsl #32
    // 0x12f9284: cmp             w3, NULL
    // 0x12f9288: b.eq            #0x12f92e4
    // 0x12f928c: LoadField: r3 = r3->field_f
    //     0x12f928c: ldur            w3, [x3, #0xf]
    // 0x12f9290: lsr             x3, x3, #3
    // 0x12f9294: r17 = 7724
    //     0x12f9294: mov             x17, #0x1e2c
    // 0x12f9298: cmp             x3, x17
    // 0x12f929c: b.eq            #0x12f92ec
    // 0x12f92a0: r3 = SubtypeTestCache
    //     0x12f92a0: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d48] SubtypeTestCache
    //     0x12f92a4: ldr             x3, [x3, #0xd48]
    // 0x12f92a8: r30 = Subtype1TestCacheStub
    //     0x12f92a8: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12f92ac: LoadField: r30 = r30->field_7
    //     0x12f92ac: ldur            lr, [lr, #7]
    // 0x12f92b0: blr             lr
    // 0x12f92b4: cmp             w7, NULL
    // 0x12f92b8: b.eq            #0x12f92c4
    // 0x12f92bc: tbnz            w7, #4, #0x12f92e4
    // 0x12f92c0: b               #0x12f92ec
    // 0x12f92c4: r8 = EfficientLengthIterable
    //     0x12f92c4: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0d50] Type: EfficientLengthIterable
    //     0x12f92c8: ldr             x8, [x8, #0xd50]
    // 0x12f92cc: r3 = SubtypeTestCache
    //     0x12f92cc: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d58] SubtypeTestCache
    //     0x12f92d0: ldr             x3, [x3, #0xd58]
    // 0x12f92d4: r30 = InstanceOfStub
    //     0x12f92d4: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12f92d8: LoadField: r30 = r30->field_7
    //     0x12f92d8: ldur            lr, [lr, #7]
    // 0x12f92dc: blr             lr
    // 0x12f92e0: b               #0x12f92f0
    // 0x12f92e4: r0 = false
    //     0x12f92e4: add             x0, NULL, #0x30  ; false
    // 0x12f92e8: b               #0x12f92f0
    // 0x12f92ec: r0 = true
    //     0x12f92ec: add             x0, NULL, #0x20  ; true
    // 0x12f92f0: tbnz            w0, #4, #0x12f9308
    // 0x12f92f4: ldur            x2, [fp, #-0x10]
    // 0x12f92f8: r1 = <Path>
    //     0x12f92f8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x12f92fc: ldr             x1, [x1, #0xa60]
    // 0x12f9300: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x12f9300: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x12f9304: b               #0x12f9318
    // 0x12f9308: ldur            x2, [fp, #-0x10]
    // 0x12f930c: r1 = <Path>
    //     0x12f930c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x12f9310: ldr             x1, [x1, #0xa60]
    // 0x12f9314: r0 = _GrowableList._ofOther()
    //     0x12f9314: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x12f9318: ldur            x2, [fp, #-8]
    // 0x12f931c: StoreField: r2->field_2b = r0
    //     0x12f931c: stur            w0, [x2, #0x2b]
    //     0x12f9320: ldurb           w16, [x2, #-1]
    //     0x12f9324: ldurb           w17, [x0, #-1]
    //     0x12f9328: and             x16, x17, x16, lsr #2
    //     0x12f932c: tst             x16, HEAP, lsr #32
    //     0x12f9330: b.eq            #0x12f9338
    //     0x12f9334: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12f9338: b               #0x12f9340
    // 0x12f933c: ldur            x2, [fp, #-8]
    // 0x12f9340: ldur            x3, [fp, #-0x30]
    // 0x12f9344: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12f9344: ldur            w4, [x3, #0x17]
    // 0x12f9348: DecompressPointer r4
    //     0x12f9348: add             x4, x4, HEAP, lsl #32
    // 0x12f934c: stur            x4, [fp, #-0x10]
    // 0x12f9350: r0 = LoadClassIdInstr(r4)
    //     0x12f9350: ldur            x0, [x4, #-1]
    //     0x12f9354: ubfx            x0, x0, #0xc, #0x14
    // 0x12f9358: mov             x1, x4
    // 0x12f935c: r0 = GDT[cid_x0 + -0xf28]()
    //     0x12f935c: sub             lr, x0, #0xf28
    //     0x12f9360: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9364: blr             lr
    // 0x12f9368: tbz             w0, #4, #0x12f93f4
    // 0x12f936c: ldur            x3, [fp, #-8]
    // 0x12f9370: LoadField: r0 = r3->field_1f
    //     0x12f9370: ldur            w0, [x3, #0x1f]
    // 0x12f9374: DecompressPointer r0
    //     0x12f9374: add             x0, x0, HEAP, lsl #32
    // 0x12f9378: cmp             w0, NULL
    // 0x12f937c: b.ne            #0x12f9390
    // 0x12f9380: LoadField: r0 = r3->field_23
    //     0x12f9380: ldur            w0, [x3, #0x23]
    // 0x12f9384: DecompressPointer r0
    //     0x12f9384: add             x0, x0, HEAP, lsl #32
    // 0x12f9388: cmp             w0, NULL
    // 0x12f938c: b.eq            #0x12f93f8
    // 0x12f9390: ldur            x5, [fp, #-0x20]
    // 0x12f9394: ldur            x4, [fp, #-0x10]
    // 0x12f9398: LoadField: r2 = r5->field_13
    //     0x12f9398: ldur            w2, [x5, #0x13]
    // 0x12f939c: DecompressPointer r2
    //     0x12f939c: add             x2, x2, HEAP, lsl #32
    // 0x12f93a0: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x12f93a0: ldur            w0, [x5, #0x17]
    // 0x12f93a4: DecompressPointer r0
    //     0x12f93a4: add             x0, x0, HEAP, lsl #32
    // 0x12f93a8: r1 = LoadClassIdInstr(r4)
    //     0x12f93a8: ldur            x1, [x4, #-1]
    //     0x12f93ac: ubfx            x1, x1, #0xc, #0x14
    // 0x12f93b0: str             x0, [SP]
    // 0x12f93b4: mov             x0, x1
    // 0x12f93b8: mov             x1, x4
    // 0x12f93bc: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12f93bc: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12f93c0: ldr             x4, [x4, #0x638]
    // 0x12f93c4: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x12f93c4: sub             lr, x0, #0xfc1
    //     0x12f93c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f93cc: blr             lr
    // 0x12f93d0: ldur            x3, [fp, #-8]
    // 0x12f93d4: ArrayStore: r3[0] = r0  ; List_4
    //     0x12f93d4: stur            w0, [x3, #0x17]
    //     0x12f93d8: ldurb           w16, [x3, #-1]
    //     0x12f93dc: ldurb           w17, [x0, #-1]
    //     0x12f93e0: and             x16, x17, x16, lsr #2
    //     0x12f93e4: tst             x16, HEAP, lsr #32
    //     0x12f93e8: b.eq            #0x12f93f0
    //     0x12f93ec: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12f93f0: b               #0x12f93f8
    // 0x12f93f4: ldur            x3, [fp, #-8]
    // 0x12f93f8: ldur            x0, [fp, #-0x30]
    // 0x12f93fc: LoadField: r1 = r0->field_f
    //     0x12f93fc: ldur            w1, [x0, #0xf]
    // 0x12f9400: DecompressPointer r1
    //     0x12f9400: add             x1, x1, HEAP, lsl #32
    // 0x12f9404: cmp             w1, NULL
    // 0x12f9408: b.eq            #0x12f9474
    // 0x12f940c: ldur            x4, [fp, #-0x20]
    // 0x12f9410: ldur            x1, [fp, #-0x10]
    // 0x12f9414: LoadField: r2 = r4->field_13
    //     0x12f9414: ldur            w2, [x4, #0x13]
    // 0x12f9418: DecompressPointer r2
    //     0x12f9418: add             x2, x2, HEAP, lsl #32
    // 0x12f941c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12f941c: ldur            w0, [x4, #0x17]
    // 0x12f9420: DecompressPointer r0
    //     0x12f9420: add             x0, x0, HEAP, lsl #32
    // 0x12f9424: r5 = LoadClassIdInstr(r1)
    //     0x12f9424: ldur            x5, [x1, #-1]
    //     0x12f9428: ubfx            x5, x5, #0xc, #0x14
    // 0x12f942c: str             x0, [SP]
    // 0x12f9430: mov             x0, x5
    // 0x12f9434: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12f9434: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12f9438: ldr             x4, [x4, #0x638]
    // 0x12f943c: r0 = GDT[cid_x0 + 0x101d9]()
    //     0x12f943c: mov             x17, #0x1d9
    //     0x12f9440: movk            x17, #1, lsl #16
    //     0x12f9444: add             lr, x0, x17
    //     0x12f9448: ldr             lr, [x21, lr, lsl #3]
    //     0x12f944c: blr             lr
    // 0x12f9450: ldur            x1, [fp, #-8]
    // 0x12f9454: StoreField: r1->field_1b = r0
    //     0x12f9454: stur            w0, [x1, #0x1b]
    //     0x12f9458: ldurb           w16, [x1, #-1]
    //     0x12f945c: ldurb           w17, [x0, #-1]
    //     0x12f9460: and             x16, x17, x16, lsr #2
    //     0x12f9464: tst             x16, HEAP, lsr #32
    //     0x12f9468: b.eq            #0x12f9470
    //     0x12f946c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f9470: b               #0x12f9478
    // 0x12f9474: mov             x1, x3
    // 0x12f9478: ldur            x2, [fp, #-0x20]
    // 0x12f947c: LoadField: r0 = r2->field_13
    //     0x12f947c: ldur            w0, [x2, #0x13]
    // 0x12f9480: DecompressPointer r0
    //     0x12f9480: add             x0, x0, HEAP, lsl #32
    // 0x12f9484: StoreField: r1->field_f = r0
    //     0x12f9484: stur            w0, [x1, #0xf]
    //     0x12f9488: ldurb           w16, [x1, #-1]
    //     0x12f948c: ldurb           w17, [x0, #-1]
    //     0x12f9490: and             x16, x17, x16, lsr #2
    //     0x12f9494: tst             x16, HEAP, lsr #32
    //     0x12f9498: b.eq            #0x12f94a0
    //     0x12f949c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f94a0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x12f94a0: ldur            w0, [x2, #0x17]
    // 0x12f94a4: DecompressPointer r0
    //     0x12f94a4: add             x0, x0, HEAP, lsl #32
    // 0x12f94a8: StoreField: r1->field_13 = r0
    //     0x12f94a8: stur            w0, [x1, #0x13]
    //     0x12f94ac: ldurb           w16, [x1, #-1]
    //     0x12f94b0: ldurb           w17, [x0, #-1]
    //     0x12f94b4: and             x16, x17, x16, lsr #2
    //     0x12f94b8: tst             x16, HEAP, lsr #32
    //     0x12f94bc: b.eq            #0x12f94c4
    //     0x12f94c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f94c4: r0 = Null
    //     0x12f94c4: mov             x0, NULL
    // 0x12f94c8: LeaveFrame
    //     0x12f94c8: mov             SP, fp
    //     0x12f94cc: ldp             fp, lr, [SP], #0x10
    // 0x12f94d0: ret
    //     0x12f94d0: ret             
    // 0x12f94d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f94d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f94d8: b               #0x12f8a90
    // 0x12f94dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f94dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f94e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f94e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f94e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f94e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Path <anonymous closure>(dynamic, BoxShadow) {
    // ** addr: 0x12f94e8, size: 0xc0
    // 0x12f94e8: EnterFrame
    //     0x12f94e8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f94ec: mov             fp, SP
    // 0x12f94f0: AllocStack(0x18)
    //     0x12f94f0: sub             SP, SP, #0x18
    // 0x12f94f4: SetupParameters([dynamic _ /* r0 */])
    //     0x12f94f4: ldr             x0, [fp, #0x18]
    //     0x12f94f8: ldur            w3, [x0, #0x17]
    //     0x12f94fc: add             x3, x3, HEAP, lsl #32
    //     0x12f9500: stur            x3, [fp, #-0x10]
    // 0x12f9504: CheckStackOverflow
    //     0x12f9504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f9508: cmp             SP, x16
    //     0x12f950c: b.ls            #0x12f95a0
    // 0x12f9510: LoadField: r0 = r3->field_f
    //     0x12f9510: ldur            w0, [x3, #0xf]
    // 0x12f9514: DecompressPointer r0
    //     0x12f9514: add             x0, x0, HEAP, lsl #32
    // 0x12f9518: LoadField: r1 = r0->field_b
    //     0x12f9518: ldur            w1, [x0, #0xb]
    // 0x12f951c: DecompressPointer r1
    //     0x12f951c: add             x1, x1, HEAP, lsl #32
    // 0x12f9520: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12f9520: ldur            w0, [x1, #0x17]
    // 0x12f9524: DecompressPointer r0
    //     0x12f9524: add             x0, x0, HEAP, lsl #32
    // 0x12f9528: stur            x0, [fp, #-8]
    // 0x12f952c: LoadField: r1 = r3->field_13
    //     0x12f952c: ldur            w1, [x3, #0x13]
    // 0x12f9530: DecompressPointer r1
    //     0x12f9530: add             x1, x1, HEAP, lsl #32
    // 0x12f9534: ldr             x4, [fp, #0x10]
    // 0x12f9538: LoadField: r2 = r4->field_b
    //     0x12f9538: ldur            w2, [x4, #0xb]
    // 0x12f953c: DecompressPointer r2
    //     0x12f953c: add             x2, x2, HEAP, lsl #32
    // 0x12f9540: r0 = shift()
    //     0x12f9540: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x12f9544: mov             x1, x0
    // 0x12f9548: ldr             x0, [fp, #0x10]
    // 0x12f954c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f954c: ldur            d0, [x0, #0x17]
    // 0x12f9550: r0 = inflate()
    //     0x12f9550: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x12f9554: mov             x1, x0
    // 0x12f9558: ldur            x0, [fp, #-0x10]
    // 0x12f955c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12f955c: ldur            w2, [x0, #0x17]
    // 0x12f9560: DecompressPointer r2
    //     0x12f9560: add             x2, x2, HEAP, lsl #32
    // 0x12f9564: ldur            x0, [fp, #-8]
    // 0x12f9568: r3 = LoadClassIdInstr(r0)
    //     0x12f9568: ldur            x3, [x0, #-1]
    //     0x12f956c: ubfx            x3, x3, #0xc, #0x14
    // 0x12f9570: str             x2, [SP]
    // 0x12f9574: mov             x2, x1
    // 0x12f9578: mov             x1, x0
    // 0x12f957c: mov             x0, x3
    // 0x12f9580: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12f9580: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12f9584: ldr             x4, [x4, #0x638]
    // 0x12f9588: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x12f9588: sub             lr, x0, #0xfc1
    //     0x12f958c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9590: blr             lr
    // 0x12f9594: LeaveFrame
    //     0x12f9594: mov             SP, fp
    //     0x12f9598: ldp             fp, lr, [SP], #0x10
    // 0x12f959c: ret
    //     0x12f959c: ret             
    // 0x12f95a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f95a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f95a4: b               #0x12f9510
  }
  [closure] Rect <anonymous closure>(dynamic, BoxShadow) {
    // ** addr: 0x12f95a8, size: 0x60
    // 0x12f95a8: EnterFrame
    //     0x12f95a8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f95ac: mov             fp, SP
    // 0x12f95b0: ldr             x0, [fp, #0x18]
    // 0x12f95b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12f95b4: ldur            w1, [x0, #0x17]
    // 0x12f95b8: DecompressPointer r1
    //     0x12f95b8: add             x1, x1, HEAP, lsl #32
    // 0x12f95bc: CheckStackOverflow
    //     0x12f95bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f95c0: cmp             SP, x16
    //     0x12f95c4: b.ls            #0x12f9600
    // 0x12f95c8: LoadField: r0 = r1->field_13
    //     0x12f95c8: ldur            w0, [x1, #0x13]
    // 0x12f95cc: DecompressPointer r0
    //     0x12f95cc: add             x0, x0, HEAP, lsl #32
    // 0x12f95d0: ldr             x3, [fp, #0x10]
    // 0x12f95d4: LoadField: r2 = r3->field_b
    //     0x12f95d4: ldur            w2, [x3, #0xb]
    // 0x12f95d8: DecompressPointer r2
    //     0x12f95d8: add             x2, x2, HEAP, lsl #32
    // 0x12f95dc: mov             x1, x0
    // 0x12f95e0: r0 = shift()
    //     0x12f95e0: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x12f95e4: mov             x1, x0
    // 0x12f95e8: ldr             x0, [fp, #0x10]
    // 0x12f95ec: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f95ec: ldur            d0, [x0, #0x17]
    // 0x12f95f0: r0 = inflate()
    //     0x12f95f0: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x12f95f4: LeaveFrame
    //     0x12f95f4: mov             SP, fp
    //     0x12f95f8: ldp             fp, lr, [SP], #0x10
    // 0x12f95fc: ret
    //     0x12f95fc: ret             
    // 0x12f9600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f9600: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f9604: b               #0x12f95c8
  }
  [closure] Paint <anonymous closure>(dynamic, BoxShadow) {
    // ** addr: 0x12f9608, size: 0x30
    // 0x12f9608: EnterFrame
    //     0x12f9608: stp             fp, lr, [SP, #-0x10]!
    //     0x12f960c: mov             fp, SP
    // 0x12f9610: CheckStackOverflow
    //     0x12f9610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f9614: cmp             SP, x16
    //     0x12f9618: b.ls            #0x12f9630
    // 0x12f961c: ldr             x1, [fp, #0x10]
    // 0x12f9620: r0 = toPaint()
    //     0x12f9620: bl              #0xb6da24  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::toPaint
    // 0x12f9624: LeaveFrame
    //     0x12f9624: mov             SP, fp
    //     0x12f9628: ldp             fp, lr, [SP], #0x10
    // 0x12f962c: ret
    //     0x12f962c: ret             
    // 0x12f9630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f9630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f9634: b               #0x12f961c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x12f9694, size: 0x5c
    // 0x12f9694: EnterFrame
    //     0x12f9694: stp             fp, lr, [SP, #-0x10]!
    //     0x12f9698: mov             fp, SP
    // 0x12f969c: CheckStackOverflow
    //     0x12f969c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f96a0: cmp             SP, x16
    //     0x12f96a4: b.ls            #0x12f96e8
    // 0x12f96a8: LoadField: r0 = r1->field_33
    //     0x12f96a8: ldur            w0, [x1, #0x33]
    // 0x12f96ac: DecompressPointer r0
    //     0x12f96ac: add             x0, x0, HEAP, lsl #32
    // 0x12f96b0: cmp             w0, NULL
    // 0x12f96b4: b.eq            #0x12f96d8
    // 0x12f96b8: r1 = LoadClassIdInstr(r0)
    //     0x12f96b8: ldur            x1, [x0, #-1]
    //     0x12f96bc: ubfx            x1, x1, #0xc, #0x14
    // 0x12f96c0: mov             x16, x0
    // 0x12f96c4: mov             x0, x1
    // 0x12f96c8: mov             x1, x16
    // 0x12f96cc: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x12f96cc: sub             lr, x0, #0xfb9
    //     0x12f96d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12f96d4: blr             lr
    // 0x12f96d8: r0 = Null
    //     0x12f96d8: mov             x0, NULL
    // 0x12f96dc: LeaveFrame
    //     0x12f96dc: mov             SP, fp
    //     0x12f96e0: ldp             fp, lr, [SP], #0x10
    // 0x12f96e4: ret
    //     0x12f96e4: ret             
    // 0x12f96e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f96e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f96ec: b               #0x12f96a8
  }
}

// class id: 5237, size: 0x1c, field offset: 0x8
//   const constructor, 
class ShapeDecoration extends Decoration {

  _ImmutableList<BoxShadow> field_14;
  RoundedSuperellipseBorder field_18;

  get _ hashCode(/* No info */) {
    // ** addr: 0x112e508, size: 0xd0
    // 0x112e508: EnterFrame
    //     0x112e508: stp             fp, lr, [SP, #-0x10]!
    //     0x112e50c: mov             fp, SP
    // 0x112e510: AllocStack(0x38)
    //     0x112e510: sub             SP, SP, #0x38
    // 0x112e514: CheckStackOverflow
    //     0x112e514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e518: cmp             SP, x16
    //     0x112e51c: b.ls            #0x112e5d0
    // 0x112e520: ldr             x0, [fp, #0x10]
    // 0x112e524: LoadField: r2 = r0->field_7
    //     0x112e524: ldur            w2, [x0, #7]
    // 0x112e528: DecompressPointer r2
    //     0x112e528: add             x2, x2, HEAP, lsl #32
    // 0x112e52c: stur            x2, [fp, #-0x20]
    // 0x112e530: LoadField: r3 = r0->field_b
    //     0x112e530: ldur            w3, [x0, #0xb]
    // 0x112e534: DecompressPointer r3
    //     0x112e534: add             x3, x3, HEAP, lsl #32
    // 0x112e538: stur            x3, [fp, #-0x18]
    // 0x112e53c: LoadField: r4 = r0->field_f
    //     0x112e53c: ldur            w4, [x0, #0xf]
    // 0x112e540: DecompressPointer r4
    //     0x112e540: add             x4, x4, HEAP, lsl #32
    // 0x112e544: stur            x4, [fp, #-0x10]
    // 0x112e548: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x112e548: ldur            w5, [x0, #0x17]
    // 0x112e54c: DecompressPointer r5
    //     0x112e54c: add             x5, x5, HEAP, lsl #32
    // 0x112e550: stur            x5, [fp, #-8]
    // 0x112e554: LoadField: r1 = r0->field_13
    //     0x112e554: ldur            w1, [x0, #0x13]
    // 0x112e558: DecompressPointer r1
    //     0x112e558: add             x1, x1, HEAP, lsl #32
    // 0x112e55c: cmp             w1, NULL
    // 0x112e560: b.ne            #0x112e56c
    // 0x112e564: r0 = Null
    //     0x112e564: mov             x0, NULL
    // 0x112e568: b               #0x112e588
    // 0x112e56c: r0 = hashAll()
    //     0x112e56c: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x112e570: mov             x2, x0
    // 0x112e574: r0 = BoxInt64Instr(r2)
    //     0x112e574: sbfiz           x0, x2, #1, #0x1f
    //     0x112e578: cmp             x2, x0, asr #1
    //     0x112e57c: b.eq            #0x112e588
    //     0x112e580: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e584: stur            x2, [x0, #7]
    // 0x112e588: ldur            x16, [fp, #-0x10]
    // 0x112e58c: ldur            lr, [fp, #-8]
    // 0x112e590: stp             lr, x16, [SP, #8]
    // 0x112e594: str             x0, [SP]
    // 0x112e598: ldur            x1, [fp, #-0x20]
    // 0x112e59c: ldur            x2, [fp, #-0x18]
    // 0x112e5a0: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x112e5a0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x112e5a4: ldr             x4, [x4, #0xc80]
    // 0x112e5a8: r0 = hash()
    //     0x112e5a8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112e5ac: mov             x2, x0
    // 0x112e5b0: r0 = BoxInt64Instr(r2)
    //     0x112e5b0: sbfiz           x0, x2, #1, #0x1f
    //     0x112e5b4: cmp             x2, x0, asr #1
    //     0x112e5b8: b.eq            #0x112e5c4
    //     0x112e5bc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e5c0: stur            x2, [x0, #7]
    // 0x112e5c4: LeaveFrame
    //     0x112e5c4: mov             SP, fp
    //     0x112e5c8: ldp             fp, lr, [SP], #0x10
    // 0x112e5cc: ret
    //     0x112e5cc: ret             
    // 0x112e5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112e5d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e5d4: b               #0x112e520
  }
  factory _ ShapeDecoration.fromBoxDecoration(/* No info */) {
    // ** addr: 0x1163084, size: 0x160
    // 0x1163084: EnterFrame
    //     0x1163084: stp             fp, lr, [SP, #-0x10]!
    //     0x1163088: mov             fp, SP
    // 0x116308c: AllocStack(0x30)
    //     0x116308c: sub             SP, SP, #0x30
    // 0x1163090: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x1163090: stur            x2, [fp, #-0x18]
    // 0x1163094: LoadField: r0 = r2->field_23
    //     0x1163094: ldur            w0, [x2, #0x23]
    // 0x1163098: DecompressPointer r0
    //     0x1163098: add             x0, x0, HEAP, lsl #32
    // 0x116309c: LoadField: r1 = r0->field_7
    //     0x116309c: ldur            x1, [x0, #7]
    // 0x11630a0: cmp             x1, #0
    // 0x11630a4: b.gt            #0x1163134
    // 0x11630a8: LoadField: r0 = r2->field_13
    //     0x11630a8: ldur            w0, [x2, #0x13]
    // 0x11630ac: DecompressPointer r0
    //     0x11630ac: add             x0, x0, HEAP, lsl #32
    // 0x11630b0: stur            x0, [fp, #-0x10]
    // 0x11630b4: cmp             w0, NULL
    // 0x11630b8: b.eq            #0x1163114
    // 0x11630bc: LoadField: r1 = r2->field_f
    //     0x11630bc: ldur            w1, [x2, #0xf]
    // 0x11630c0: DecompressPointer r1
    //     0x11630c0: add             x1, x1, HEAP, lsl #32
    // 0x11630c4: cmp             w1, NULL
    // 0x11630c8: b.ne            #0x11630d4
    // 0x11630cc: r1 = Null
    //     0x11630cc: mov             x1, NULL
    // 0x11630d0: b               #0x11630e0
    // 0x11630d4: LoadField: r3 = r1->field_7
    //     0x11630d4: ldur            w3, [x1, #7]
    // 0x11630d8: DecompressPointer r3
    //     0x11630d8: add             x3, x3, HEAP, lsl #32
    // 0x11630dc: mov             x1, x3
    // 0x11630e0: cmp             w1, NULL
    // 0x11630e4: b.ne            #0x11630f0
    // 0x11630e8: r1 = Instance_BorderSide
    //     0x11630e8: add             x1, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x11630ec: ldr             x1, [x1, #0x310]
    // 0x11630f0: stur            x1, [fp, #-8]
    // 0x11630f4: r0 = RoundedRectangleBorder()
    //     0x11630f4: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x11630f8: mov             x1, x0
    // 0x11630fc: ldur            x0, [fp, #-0x10]
    // 0x1163100: StoreField: r1->field_b = r0
    //     0x1163100: stur            w0, [x1, #0xb]
    // 0x1163104: ldur            x0, [fp, #-8]
    // 0x1163108: StoreField: r1->field_7 = r0
    //     0x1163108: stur            w0, [x1, #7]
    // 0x116310c: ldur            x0, [fp, #-0x18]
    // 0x1163110: b               #0x1163178
    // 0x1163114: mov             x0, x2
    // 0x1163118: LoadField: r1 = r0->field_f
    //     0x1163118: ldur            w1, [x0, #0xf]
    // 0x116311c: DecompressPointer r1
    //     0x116311c: add             x1, x1, HEAP, lsl #32
    // 0x1163120: cmp             w1, NULL
    // 0x1163124: b.ne            #0x1163178
    // 0x1163128: r1 = Instance_Border
    //     0x1163128: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a08] Obj!Border@129eb81
    //     0x116312c: ldr             x1, [x1, #0xa08]
    // 0x1163130: b               #0x1163178
    // 0x1163134: mov             x0, x2
    // 0x1163138: LoadField: r1 = r0->field_f
    //     0x1163138: ldur            w1, [x0, #0xf]
    // 0x116313c: DecompressPointer r1
    //     0x116313c: add             x1, x1, HEAP, lsl #32
    // 0x1163140: cmp             w1, NULL
    // 0x1163144: b.eq            #0x1163168
    // 0x1163148: LoadField: r2 = r1->field_7
    //     0x1163148: ldur            w2, [x1, #7]
    // 0x116314c: DecompressPointer r2
    //     0x116314c: add             x2, x2, HEAP, lsl #32
    // 0x1163150: stur            x2, [fp, #-8]
    // 0x1163154: r0 = CircleBorder()
    //     0x1163154: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x1163158: StoreField: r0->field_b = rZR
    //     0x1163158: stur            xzr, [x0, #0xb]
    // 0x116315c: ldur            x1, [fp, #-8]
    // 0x1163160: StoreField: r0->field_7 = r1
    //     0x1163160: stur            w1, [x0, #7]
    // 0x1163164: b               #0x1163170
    // 0x1163168: r0 = Instance_CircleBorder
    //     0x1163168: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0x116316c: ldr             x0, [x0, #0x318]
    // 0x1163170: mov             x1, x0
    // 0x1163174: ldur            x0, [fp, #-0x18]
    // 0x1163178: stur            x1, [fp, #-0x30]
    // 0x116317c: LoadField: r2 = r0->field_7
    //     0x116317c: ldur            w2, [x0, #7]
    // 0x1163180: DecompressPointer r2
    //     0x1163180: add             x2, x2, HEAP, lsl #32
    // 0x1163184: stur            x2, [fp, #-0x28]
    // 0x1163188: LoadField: r3 = r0->field_b
    //     0x1163188: ldur            w3, [x0, #0xb]
    // 0x116318c: DecompressPointer r3
    //     0x116318c: add             x3, x3, HEAP, lsl #32
    // 0x1163190: stur            x3, [fp, #-0x20]
    // 0x1163194: LoadField: r4 = r0->field_1b
    //     0x1163194: ldur            w4, [x0, #0x1b]
    // 0x1163198: DecompressPointer r4
    //     0x1163198: add             x4, x4, HEAP, lsl #32
    // 0x116319c: stur            x4, [fp, #-0x10]
    // 0x11631a0: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11631a0: ldur            w5, [x0, #0x17]
    // 0x11631a4: DecompressPointer r5
    //     0x11631a4: add             x5, x5, HEAP, lsl #32
    // 0x11631a8: stur            x5, [fp, #-8]
    // 0x11631ac: r0 = ShapeDecoration()
    //     0x11631ac: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x11631b0: ldur            x1, [fp, #-0x28]
    // 0x11631b4: StoreField: r0->field_7 = r1
    //     0x11631b4: stur            w1, [x0, #7]
    // 0x11631b8: ldur            x1, [fp, #-0x20]
    // 0x11631bc: StoreField: r0->field_f = r1
    //     0x11631bc: stur            w1, [x0, #0xf]
    // 0x11631c0: ldur            x1, [fp, #-0x10]
    // 0x11631c4: StoreField: r0->field_b = r1
    //     0x11631c4: stur            w1, [x0, #0xb]
    // 0x11631c8: ldur            x1, [fp, #-8]
    // 0x11631cc: StoreField: r0->field_13 = r1
    //     0x11631cc: stur            w1, [x0, #0x13]
    // 0x11631d0: ldur            x1, [fp, #-0x30]
    // 0x11631d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x11631d4: stur            w1, [x0, #0x17]
    // 0x11631d8: LeaveFrame
    //     0x11631d8: mov             SP, fp
    //     0x11631dc: ldp             fp, lr, [SP], #0x10
    // 0x11631e0: ret
    //     0x11631e0: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116398c, size: 0x288
    // 0x116398c: EnterFrame
    //     0x116398c: stp             fp, lr, [SP, #-0x10]!
    //     0x1163990: mov             fp, SP
    // 0x1163994: AllocStack(0x38)
    //     0x1163994: sub             SP, SP, #0x38
    // 0x1163998: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0x1163998: mov             x4, x1
    //     0x116399c: mov             x0, x2
    //     0x11639a0: stur            x1, [fp, #-8]
    //     0x11639a4: stur            x2, [fp, #-0x10]
    //     0x11639a8: stur            d0, [fp, #-0x38]
    // 0x11639ac: CheckStackOverflow
    //     0x11639ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11639b0: cmp             SP, x16
    //     0x11639b4: b.ls            #0x1163be4
    // 0x11639b8: cmp             w4, w0
    // 0x11639bc: b.ne            #0x11639d0
    // 0x11639c0: mov             x0, x4
    // 0x11639c4: LeaveFrame
    //     0x11639c4: mov             SP, fp
    //     0x11639c8: ldp             fp, lr, [SP], #0x10
    // 0x11639cc: ret
    //     0x11639cc: ret             
    // 0x11639d0: cmp             w4, NULL
    // 0x11639d4: b.eq            #0x1163a14
    // 0x11639d8: cmp             w0, NULL
    // 0x11639dc: b.eq            #0x1163a14
    // 0x11639e0: d1 = 0.000000
    //     0x11639e0: eor             v1.16b, v1.16b, v1.16b
    // 0x11639e4: fcmp            d0, d1
    // 0x11639e8: b.ne            #0x11639fc
    // 0x11639ec: mov             x0, x4
    // 0x11639f0: LeaveFrame
    //     0x11639f0: mov             SP, fp
    //     0x11639f4: ldp             fp, lr, [SP], #0x10
    // 0x11639f8: ret
    //     0x11639f8: ret             
    // 0x11639fc: d1 = 1.000000
    //     0x11639fc: fmov            d1, #1.00000000
    // 0x1163a00: fcmp            d0, d1
    // 0x1163a04: b.ne            #0x1163a14
    // 0x1163a08: LeaveFrame
    //     0x1163a08: mov             SP, fp
    //     0x1163a0c: ldp             fp, lr, [SP], #0x10
    // 0x1163a10: ret
    //     0x1163a10: ret             
    // 0x1163a14: cmp             w4, NULL
    // 0x1163a18: b.ne            #0x1163a24
    // 0x1163a1c: r1 = Null
    //     0x1163a1c: mov             x1, NULL
    // 0x1163a20: b               #0x1163a2c
    // 0x1163a24: LoadField: r1 = r4->field_7
    //     0x1163a24: ldur            w1, [x4, #7]
    // 0x1163a28: DecompressPointer r1
    //     0x1163a28: add             x1, x1, HEAP, lsl #32
    // 0x1163a2c: cmp             w0, NULL
    // 0x1163a30: b.ne            #0x1163a3c
    // 0x1163a34: r2 = Null
    //     0x1163a34: mov             x2, NULL
    // 0x1163a38: b               #0x1163a44
    // 0x1163a3c: LoadField: r2 = r0->field_7
    //     0x1163a3c: ldur            w2, [x0, #7]
    // 0x1163a40: DecompressPointer r2
    //     0x1163a40: add             x2, x2, HEAP, lsl #32
    // 0x1163a44: r3 = inline_Allocate_Double()
    //     0x1163a44: ldp             x3, x5, [THR, #0x60]  ; THR::top
    //     0x1163a48: add             x3, x3, #0x10
    //     0x1163a4c: cmp             x5, x3
    //     0x1163a50: b.ls            #0x1163bec
    //     0x1163a54: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163a58: sub             x3, x3, #0xf
    //     0x1163a5c: mov             x5, #0xe19c
    //     0x1163a60: movk            x5, #3, lsl #16
    //     0x1163a64: stur            x5, [x3, #-1]
    // 0x1163a68: dmb             ishst
    // 0x1163a6c: StoreField: r3->field_7 = d0
    //     0x1163a6c: stur            d0, [x3, #7]
    // 0x1163a70: r0 = lerp()
    //     0x1163a70: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1163a74: mov             x3, x0
    // 0x1163a78: ldur            x0, [fp, #-8]
    // 0x1163a7c: stur            x3, [fp, #-0x18]
    // 0x1163a80: cmp             w0, NULL
    // 0x1163a84: b.ne            #0x1163a90
    // 0x1163a88: r1 = Null
    //     0x1163a88: mov             x1, NULL
    // 0x1163a8c: b               #0x1163a98
    // 0x1163a90: LoadField: r1 = r0->field_b
    //     0x1163a90: ldur            w1, [x0, #0xb]
    // 0x1163a94: DecompressPointer r1
    //     0x1163a94: add             x1, x1, HEAP, lsl #32
    // 0x1163a98: ldur            x4, [fp, #-0x10]
    // 0x1163a9c: cmp             w4, NULL
    // 0x1163aa0: b.ne            #0x1163aac
    // 0x1163aa4: r2 = Null
    //     0x1163aa4: mov             x2, NULL
    // 0x1163aa8: b               #0x1163ab4
    // 0x1163aac: LoadField: r2 = r4->field_b
    //     0x1163aac: ldur            w2, [x4, #0xb]
    // 0x1163ab0: DecompressPointer r2
    //     0x1163ab0: add             x2, x2, HEAP, lsl #32
    // 0x1163ab4: ldur            d0, [fp, #-0x38]
    // 0x1163ab8: r0 = lerp()
    //     0x1163ab8: bl              #0x115ffa0  ; [package:flutter/src/painting/gradient.dart] Gradient::lerp
    // 0x1163abc: mov             x3, x0
    // 0x1163ac0: ldur            x0, [fp, #-8]
    // 0x1163ac4: stur            x3, [fp, #-0x20]
    // 0x1163ac8: cmp             w0, NULL
    // 0x1163acc: b.ne            #0x1163ad8
    // 0x1163ad0: r1 = Null
    //     0x1163ad0: mov             x1, NULL
    // 0x1163ad4: b               #0x1163ae0
    // 0x1163ad8: LoadField: r1 = r0->field_f
    //     0x1163ad8: ldur            w1, [x0, #0xf]
    // 0x1163adc: DecompressPointer r1
    //     0x1163adc: add             x1, x1, HEAP, lsl #32
    // 0x1163ae0: ldur            x4, [fp, #-0x10]
    // 0x1163ae4: cmp             w4, NULL
    // 0x1163ae8: b.ne            #0x1163af4
    // 0x1163aec: r2 = Null
    //     0x1163aec: mov             x2, NULL
    // 0x1163af0: b               #0x1163afc
    // 0x1163af4: LoadField: r2 = r4->field_f
    //     0x1163af4: ldur            w2, [x4, #0xf]
    // 0x1163af8: DecompressPointer r2
    //     0x1163af8: add             x2, x2, HEAP, lsl #32
    // 0x1163afc: ldur            d0, [fp, #-0x38]
    // 0x1163b00: r0 = lerp()
    //     0x1163b00: bl              #0x1162ff8  ; [package:flutter/src/painting/decoration_image.dart] DecorationImage::lerp
    // 0x1163b04: mov             x3, x0
    // 0x1163b08: ldur            x0, [fp, #-8]
    // 0x1163b0c: stur            x3, [fp, #-0x28]
    // 0x1163b10: cmp             w0, NULL
    // 0x1163b14: b.ne            #0x1163b20
    // 0x1163b18: r1 = Null
    //     0x1163b18: mov             x1, NULL
    // 0x1163b1c: b               #0x1163b28
    // 0x1163b20: LoadField: r1 = r0->field_13
    //     0x1163b20: ldur            w1, [x0, #0x13]
    // 0x1163b24: DecompressPointer r1
    //     0x1163b24: add             x1, x1, HEAP, lsl #32
    // 0x1163b28: ldur            x4, [fp, #-0x10]
    // 0x1163b2c: cmp             w4, NULL
    // 0x1163b30: b.ne            #0x1163b3c
    // 0x1163b34: r2 = Null
    //     0x1163b34: mov             x2, NULL
    // 0x1163b38: b               #0x1163b44
    // 0x1163b3c: LoadField: r2 = r4->field_13
    //     0x1163b3c: ldur            w2, [x4, #0x13]
    // 0x1163b40: DecompressPointer r2
    //     0x1163b40: add             x2, x2, HEAP, lsl #32
    // 0x1163b44: ldur            d0, [fp, #-0x38]
    // 0x1163b48: r0 = lerpList()
    //     0x1163b48: bl              #0x116277c  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0x1163b4c: mov             x3, x0
    // 0x1163b50: ldur            x0, [fp, #-8]
    // 0x1163b54: stur            x3, [fp, #-0x30]
    // 0x1163b58: cmp             w0, NULL
    // 0x1163b5c: b.ne            #0x1163b68
    // 0x1163b60: r1 = Null
    //     0x1163b60: mov             x1, NULL
    // 0x1163b64: b               #0x1163b70
    // 0x1163b68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1163b68: ldur            w1, [x0, #0x17]
    // 0x1163b6c: DecompressPointer r1
    //     0x1163b6c: add             x1, x1, HEAP, lsl #32
    // 0x1163b70: ldur            x0, [fp, #-0x10]
    // 0x1163b74: cmp             w0, NULL
    // 0x1163b78: b.ne            #0x1163b84
    // 0x1163b7c: r2 = Null
    //     0x1163b7c: mov             x2, NULL
    // 0x1163b80: b               #0x1163b8c
    // 0x1163b84: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1163b84: ldur            w2, [x0, #0x17]
    // 0x1163b88: DecompressPointer r2
    //     0x1163b88: add             x2, x2, HEAP, lsl #32
    // 0x1163b8c: ldur            x5, [fp, #-0x18]
    // 0x1163b90: ldur            x4, [fp, #-0x20]
    // 0x1163b94: ldur            x0, [fp, #-0x28]
    // 0x1163b98: ldur            d0, [fp, #-0x38]
    // 0x1163b9c: r0 = lerp()
    //     0x1163b9c: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1163ba0: stur            x0, [fp, #-8]
    // 0x1163ba4: cmp             w0, NULL
    // 0x1163ba8: b.eq            #0x1163c10
    // 0x1163bac: r0 = ShapeDecoration()
    //     0x1163bac: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x1163bb0: ldur            x1, [fp, #-0x18]
    // 0x1163bb4: StoreField: r0->field_7 = r1
    //     0x1163bb4: stur            w1, [x0, #7]
    // 0x1163bb8: ldur            x1, [fp, #-0x28]
    // 0x1163bbc: StoreField: r0->field_f = r1
    //     0x1163bbc: stur            w1, [x0, #0xf]
    // 0x1163bc0: ldur            x1, [fp, #-0x20]
    // 0x1163bc4: StoreField: r0->field_b = r1
    //     0x1163bc4: stur            w1, [x0, #0xb]
    // 0x1163bc8: ldur            x1, [fp, #-0x30]
    // 0x1163bcc: StoreField: r0->field_13 = r1
    //     0x1163bcc: stur            w1, [x0, #0x13]
    // 0x1163bd0: ldur            x1, [fp, #-8]
    // 0x1163bd4: ArrayStore: r0[0] = r1  ; List_4
    //     0x1163bd4: stur            w1, [x0, #0x17]
    // 0x1163bd8: LeaveFrame
    //     0x1163bd8: mov             SP, fp
    //     0x1163bdc: ldp             fp, lr, [SP], #0x10
    // 0x1163be0: ret
    //     0x1163be0: ret             
    // 0x1163be4: r0 = StackOverflowSharedWithFPURegs()
    //     0x1163be4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1163be8: b               #0x11639b8
    // 0x1163bec: SaveReg d0
    //     0x1163bec: str             q0, [SP, #-0x10]!
    // 0x1163bf0: stp             x2, x4, [SP, #-0x10]!
    // 0x1163bf4: stp             x0, x1, [SP, #-0x10]!
    // 0x1163bf8: r0 = AllocateDouble()
    //     0x1163bf8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1163bfc: mov             x3, x0
    // 0x1163c00: ldp             x0, x1, [SP], #0x10
    // 0x1163c04: ldp             x2, x4, [SP], #0x10
    // 0x1163c08: RestoreReg d0
    //     0x1163c08: ldr             q0, [SP], #0x10
    // 0x1163c0c: b               #0x1163a6c
    // 0x1163c10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1163c10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getClipPath(/* No info */) {
    // ** addr: 0x1197464, size: 0x60
    // 0x1197464: EnterFrame
    //     0x1197464: stp             fp, lr, [SP, #-0x10]!
    //     0x1197468: mov             fp, SP
    // 0x119746c: AllocStack(0x8)
    //     0x119746c: sub             SP, SP, #8
    // 0x1197470: CheckStackOverflow
    //     0x1197470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1197474: cmp             SP, x16
    //     0x1197478: b.ls            #0x11974bc
    // 0x119747c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x119747c: ldur            w0, [x1, #0x17]
    // 0x1197480: DecompressPointer r0
    //     0x1197480: add             x0, x0, HEAP, lsl #32
    // 0x1197484: r1 = LoadClassIdInstr(r0)
    //     0x1197484: ldur            x1, [x0, #-1]
    //     0x1197488: ubfx            x1, x1, #0xc, #0x14
    // 0x119748c: str             x3, [SP]
    // 0x1197490: mov             x16, x0
    // 0x1197494: mov             x0, x1
    // 0x1197498: mov             x1, x16
    // 0x119749c: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x119749c: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x11974a0: ldr             x4, [x4, #0x638]
    // 0x11974a4: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x11974a4: sub             lr, x0, #0xfc1
    //     0x11974a8: ldr             lr, [x21, lr, lsl #3]
    //     0x11974ac: blr             lr
    // 0x11974b0: LeaveFrame
    //     0x11974b0: mov             SP, fp
    //     0x11974b4: ldp             fp, lr, [SP], #0x10
    // 0x11974b8: ret
    //     0x11974b8: ret             
    // 0x11974bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11974bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11974c0: b               #0x119747c
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x11a7e64, size: 0x8c
    // 0x11a7e64: EnterFrame
    //     0x11a7e64: stp             fp, lr, [SP, #-0x10]!
    //     0x11a7e68: mov             fp, SP
    // 0x11a7e6c: AllocStack(0x20)
    //     0x11a7e6c: sub             SP, SP, #0x20
    // 0x11a7e70: SetupParameters(dynamic _ /* r3 => r0, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x11a7e70: mov             x0, x3
    //     0x11a7e74: stur            x3, [fp, #-0x10]
    //     0x11a7e78: stur            x5, [fp, #-0x18]
    // 0x11a7e7c: CheckStackOverflow
    //     0x11a7e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a7e80: cmp             SP, x16
    //     0x11a7e84: b.ls            #0x11a7ee8
    // 0x11a7e88: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x11a7e88: ldur            w3, [x1, #0x17]
    // 0x11a7e8c: DecompressPointer r3
    //     0x11a7e8c: add             x3, x3, HEAP, lsl #32
    // 0x11a7e90: stur            x3, [fp, #-8]
    // 0x11a7e94: r1 = Instance_Offset
    //     0x11a7e94: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11a7e98: r0 = &()
    //     0x11a7e98: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x11a7e9c: ldur            x1, [fp, #-8]
    // 0x11a7ea0: r2 = LoadClassIdInstr(r1)
    //     0x11a7ea0: ldur            x2, [x1, #-1]
    //     0x11a7ea4: ubfx            x2, x2, #0xc, #0x14
    // 0x11a7ea8: ldur            x16, [fp, #-0x18]
    // 0x11a7eac: str             x16, [SP]
    // 0x11a7eb0: mov             x16, x0
    // 0x11a7eb4: mov             x0, x2
    // 0x11a7eb8: mov             x2, x16
    // 0x11a7ebc: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x11a7ebc: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x11a7ec0: ldr             x4, [x4, #0x638]
    // 0x11a7ec4: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x11a7ec4: sub             lr, x0, #0xfc1
    //     0x11a7ec8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a7ecc: blr             lr
    // 0x11a7ed0: mov             x1, x0
    // 0x11a7ed4: ldur            x2, [fp, #-0x10]
    // 0x11a7ed8: r0 = contains()
    //     0x11a7ed8: bl              #0xaf9104  ; [dart:ui] _NativePath::contains
    // 0x11a7edc: LeaveFrame
    //     0x11a7edc: mov             SP, fp
    //     0x11a7ee0: ldp             fp, lr, [SP], #0x10
    // 0x11a7ee4: ret
    //     0x11a7ee4: ret             
    // 0x11a7ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7ee8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7eec: b               #0x11a7e88
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0x1255018, size: 0x68
    // 0x1255018: EnterFrame
    //     0x1255018: stp             fp, lr, [SP, #-0x10]!
    //     0x125501c: mov             fp, SP
    // 0x1255020: AllocStack(0x10)
    //     0x1255020: sub             SP, SP, #0x10
    // 0x1255024: SetupParameters(ShapeDecoration this /* r1 => r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0x1255024: stur            x1, [fp, #-0x10]
    //     0x1255028: ldur            w0, [x4, #0x13]
    //     0x125502c: sub             x2, x0, #2
    //     0x1255030: cmp             w2, #2
    //     0x1255034: b.lt            #0x1255044
    //     0x1255038: add             x0, fp, w2, sxtw #2
    //     0x125503c: ldr             x0, [x0, #8]
    //     0x1255040: b               #0x1255048
    //     0x1255044: mov             x0, NULL
    //     0x1255048: stur            x0, [fp, #-8]
    // 0x125504c: r0 = _ShapeDecorationPainter()
    //     0x125504c: bl              #0xb7a684  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0x1255050: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x1255054: ArrayStore: r0[0] = r1  ; List_4
    //     0x1255054: stur            w1, [x0, #0x17]
    // 0x1255058: StoreField: r0->field_27 = r1
    //     0x1255058: stur            w1, [x0, #0x27]
    // 0x125505c: StoreField: r0->field_2b = r1
    //     0x125505c: stur            w1, [x0, #0x2b]
    // 0x1255060: StoreField: r0->field_2f = r1
    //     0x1255060: stur            w1, [x0, #0x2f]
    // 0x1255064: ldur            x1, [fp, #-0x10]
    // 0x1255068: StoreField: r0->field_b = r1
    //     0x1255068: stur            w1, [x0, #0xb]
    // 0x125506c: ldur            x1, [fp, #-8]
    // 0x1255070: StoreField: r0->field_7 = r1
    //     0x1255070: stur            w1, [x0, #7]
    // 0x1255074: LeaveFrame
    //     0x1255074: mov             SP, fp
    //     0x1255078: ldp             fp, lr, [SP], #0x10
    // 0x125507c: ret
    //     0x125507c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1262f6c, size: 0x1d8
    // 0x1262f6c: EnterFrame
    //     0x1262f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1262f70: mov             fp, SP
    // 0x1262f74: AllocStack(0x18)
    //     0x1262f74: sub             SP, SP, #0x18
    // 0x1262f78: CheckStackOverflow
    //     0x1262f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1262f7c: cmp             SP, x16
    //     0x1262f80: b.ls            #0x126313c
    // 0x1262f84: ldr             x0, [fp, #0x10]
    // 0x1262f88: cmp             w0, NULL
    // 0x1262f8c: b.ne            #0x1262fa0
    // 0x1262f90: r0 = false
    //     0x1262f90: add             x0, NULL, #0x30  ; false
    // 0x1262f94: LeaveFrame
    //     0x1262f94: mov             SP, fp
    //     0x1262f98: ldp             fp, lr, [SP], #0x10
    // 0x1262f9c: ret
    //     0x1262f9c: ret             
    // 0x1262fa0: ldr             x1, [fp, #0x18]
    // 0x1262fa4: cmp             w1, w0
    // 0x1262fa8: b.ne            #0x1262fbc
    // 0x1262fac: r0 = true
    //     0x1262fac: add             x0, NULL, #0x20  ; true
    // 0x1262fb0: LeaveFrame
    //     0x1262fb0: mov             SP, fp
    //     0x1262fb4: ldp             fp, lr, [SP], #0x10
    // 0x1262fb8: ret
    //     0x1262fb8: ret             
    // 0x1262fbc: str             x0, [SP]
    // 0x1262fc0: r0 = runtimeType()
    //     0x1262fc0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1262fc4: r1 = LoadClassIdInstr(r0)
    //     0x1262fc4: ldur            x1, [x0, #-1]
    //     0x1262fc8: ubfx            x1, x1, #0xc, #0x14
    // 0x1262fcc: r16 = ShapeDecoration
    //     0x1262fcc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80888] Type: ShapeDecoration
    //     0x1262fd0: ldr             x16, [x16, #0x888]
    // 0x1262fd4: stp             x16, x0, [SP]
    // 0x1262fd8: mov             x0, x1
    // 0x1262fdc: mov             lr, x0
    // 0x1262fe0: ldr             lr, [x21, lr, lsl #3]
    // 0x1262fe4: blr             lr
    // 0x1262fe8: tbz             w0, #4, #0x1262ffc
    // 0x1262fec: r0 = false
    //     0x1262fec: add             x0, NULL, #0x30  ; false
    // 0x1262ff0: LeaveFrame
    //     0x1262ff0: mov             SP, fp
    //     0x1262ff4: ldp             fp, lr, [SP], #0x10
    // 0x1262ff8: ret
    //     0x1262ff8: ret             
    // 0x1262ffc: ldr             x1, [fp, #0x10]
    // 0x1263000: r0 = 60
    //     0x1263000: mov             x0, #0x3c
    // 0x1263004: branchIfSmi(r1, 0x1263010)
    //     0x1263004: tbz             w1, #0, #0x1263010
    // 0x1263008: r0 = LoadClassIdInstr(r1)
    //     0x1263008: ldur            x0, [x1, #-1]
    //     0x126300c: ubfx            x0, x0, #0xc, #0x14
    // 0x1263010: r17 = 5237
    //     0x1263010: mov             x17, #0x1475
    // 0x1263014: cmp             x0, x17
    // 0x1263018: b.ne            #0x126312c
    // 0x126301c: ldr             x2, [fp, #0x18]
    // 0x1263020: LoadField: r0 = r1->field_7
    //     0x1263020: ldur            w0, [x1, #7]
    // 0x1263024: DecompressPointer r0
    //     0x1263024: add             x0, x0, HEAP, lsl #32
    // 0x1263028: LoadField: r3 = r2->field_7
    //     0x1263028: ldur            w3, [x2, #7]
    // 0x126302c: DecompressPointer r3
    //     0x126302c: add             x3, x3, HEAP, lsl #32
    // 0x1263030: r4 = LoadClassIdInstr(r0)
    //     0x1263030: ldur            x4, [x0, #-1]
    //     0x1263034: ubfx            x4, x4, #0xc, #0x14
    // 0x1263038: stp             x3, x0, [SP]
    // 0x126303c: mov             x0, x4
    // 0x1263040: mov             lr, x0
    // 0x1263044: ldr             lr, [x21, lr, lsl #3]
    // 0x1263048: blr             lr
    // 0x126304c: tbnz            w0, #4, #0x126312c
    // 0x1263050: ldr             x2, [fp, #0x18]
    // 0x1263054: ldr             x1, [fp, #0x10]
    // 0x1263058: LoadField: r0 = r1->field_b
    //     0x1263058: ldur            w0, [x1, #0xb]
    // 0x126305c: DecompressPointer r0
    //     0x126305c: add             x0, x0, HEAP, lsl #32
    // 0x1263060: LoadField: r3 = r2->field_b
    //     0x1263060: ldur            w3, [x2, #0xb]
    // 0x1263064: DecompressPointer r3
    //     0x1263064: add             x3, x3, HEAP, lsl #32
    // 0x1263068: r4 = LoadClassIdInstr(r0)
    //     0x1263068: ldur            x4, [x0, #-1]
    //     0x126306c: ubfx            x4, x4, #0xc, #0x14
    // 0x1263070: stp             x3, x0, [SP]
    // 0x1263074: mov             x0, x4
    // 0x1263078: mov             lr, x0
    // 0x126307c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263080: blr             lr
    // 0x1263084: tbnz            w0, #4, #0x126312c
    // 0x1263088: ldr             x2, [fp, #0x18]
    // 0x126308c: ldr             x1, [fp, #0x10]
    // 0x1263090: LoadField: r0 = r1->field_f
    //     0x1263090: ldur            w0, [x1, #0xf]
    // 0x1263094: DecompressPointer r0
    //     0x1263094: add             x0, x0, HEAP, lsl #32
    // 0x1263098: LoadField: r3 = r2->field_f
    //     0x1263098: ldur            w3, [x2, #0xf]
    // 0x126309c: DecompressPointer r3
    //     0x126309c: add             x3, x3, HEAP, lsl #32
    // 0x12630a0: r4 = LoadClassIdInstr(r0)
    //     0x12630a0: ldur            x4, [x0, #-1]
    //     0x12630a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12630a8: stp             x3, x0, [SP]
    // 0x12630ac: mov             x0, x4
    // 0x12630b0: mov             lr, x0
    // 0x12630b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12630b8: blr             lr
    // 0x12630bc: tbnz            w0, #4, #0x126312c
    // 0x12630c0: ldr             x1, [fp, #0x18]
    // 0x12630c4: ldr             x0, [fp, #0x10]
    // 0x12630c8: LoadField: r2 = r0->field_13
    //     0x12630c8: ldur            w2, [x0, #0x13]
    // 0x12630cc: DecompressPointer r2
    //     0x12630cc: add             x2, x2, HEAP, lsl #32
    // 0x12630d0: LoadField: r3 = r1->field_13
    //     0x12630d0: ldur            w3, [x1, #0x13]
    // 0x12630d4: DecompressPointer r3
    //     0x12630d4: add             x3, x3, HEAP, lsl #32
    // 0x12630d8: r16 = <BoxShadow>
    //     0x12630d8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16cf0] TypeArguments: <BoxShadow>
    //     0x12630dc: ldr             x16, [x16, #0xcf0]
    // 0x12630e0: stp             x2, x16, [SP, #8]
    // 0x12630e4: str             x3, [SP]
    // 0x12630e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12630e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12630ec: r0 = listEquals()
    //     0x12630ec: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12630f0: tbnz            w0, #4, #0x126312c
    // 0x12630f4: ldr             x1, [fp, #0x18]
    // 0x12630f8: ldr             x0, [fp, #0x10]
    // 0x12630fc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12630fc: ldur            w2, [x0, #0x17]
    // 0x1263100: DecompressPointer r2
    //     0x1263100: add             x2, x2, HEAP, lsl #32
    // 0x1263104: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1263104: ldur            w0, [x1, #0x17]
    // 0x1263108: DecompressPointer r0
    //     0x1263108: add             x0, x0, HEAP, lsl #32
    // 0x126310c: r1 = LoadClassIdInstr(r2)
    //     0x126310c: ldur            x1, [x2, #-1]
    //     0x1263110: ubfx            x1, x1, #0xc, #0x14
    // 0x1263114: stp             x0, x2, [SP]
    // 0x1263118: mov             x0, x1
    // 0x126311c: mov             lr, x0
    // 0x1263120: ldr             lr, [x21, lr, lsl #3]
    // 0x1263124: blr             lr
    // 0x1263128: b               #0x1263130
    // 0x126312c: r0 = false
    //     0x126312c: add             x0, NULL, #0x30  ; false
    // 0x1263130: LeaveFrame
    //     0x1263130: mov             SP, fp
    //     0x1263134: ldp             fp, lr, [SP], #0x10
    // 0x1263138: ret
    //     0x1263138: ret             
    // 0x126313c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126313c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1263140: b               #0x1262f84
  }
}
