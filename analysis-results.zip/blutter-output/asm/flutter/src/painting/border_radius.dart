// lib: , url: package:flutter/src/painting/border_radius.dart

// class id: 1048981, size: 0x8
class :: {
}

// class id: 2950, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class BorderRadiusGeometry extends Object {

  static _ lerp(/* No info */) {
    // ** addr: 0xbff804, size: 0x2d4
    // 0xbff804: EnterFrame
    //     0xbff804: stp             fp, lr, [SP, #-0x10]!
    //     0xbff808: mov             fp, SP
    // 0xbff80c: AllocStack(0x38)
    //     0xbff80c: sub             SP, SP, #0x38
    // 0xbff810: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0xbff810: mov             x0, x1
    //     0xbff814: stur            d0, [fp, #-0x38]
    // 0xbff818: CheckStackOverflow
    //     0xbff818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbff81c: cmp             SP, x16
    //     0xbff820: b.ls            #0xbffad0
    // 0xbff824: cmp             w0, w2
    // 0xbff828: b.ne            #0xbff838
    // 0xbff82c: LeaveFrame
    //     0xbff82c: mov             SP, fp
    //     0xbff830: ldp             fp, lr, [SP], #0x10
    // 0xbff834: ret
    //     0xbff834: ret             
    // 0xbff838: cmp             w0, NULL
    // 0xbff83c: b.ne            #0xbff848
    // 0xbff840: r0 = Instance_BorderRadius
    //     0xbff840: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xbff844: ldr             x0, [x0, #0x508]
    // 0xbff848: stur            x0, [fp, #-8]
    // 0xbff84c: cmp             w2, NULL
    // 0xbff850: b.ne            #0xbff860
    // 0xbff854: r1 = Instance_BorderRadius
    //     0xbff854: add             x1, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xbff858: ldr             x1, [x1, #0x508]
    // 0xbff85c: b               #0xbff864
    // 0xbff860: mov             x1, x2
    // 0xbff864: r2 = LoadClassIdInstr(r1)
    //     0xbff864: ldur            x2, [x1, #-1]
    //     0xbff868: ubfx            x2, x2, #0xc, #0x14
    // 0xbff86c: cmp             x2, #0xb88
    // 0xbff870: b.ne            #0xbff89c
    // 0xbff874: r2 = LoadClassIdInstr(r0)
    //     0xbff874: ldur            x2, [x0, #-1]
    //     0xbff878: ubfx            x2, x2, #0xc, #0x14
    // 0xbff87c: cmp             x2, #0xb88
    // 0xbff880: b.ne            #0xbff890
    // 0xbff884: mov             x2, x0
    // 0xbff888: r0 = -()
    //     0xbff888: bl              #0xb7792c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::-
    // 0xbff88c: b               #0xbff8e8
    // 0xbff890: ldur            x2, [fp, #-8]
    // 0xbff894: r0 = subtract()
    //     0xbff894: bl              #0x12f6024  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0xbff898: b               #0xbff8e8
    // 0xbff89c: cmp             x2, #0xb89
    // 0xbff8a0: b.ne            #0xbff8d0
    // 0xbff8a4: ldur            x0, [fp, #-8]
    // 0xbff8a8: r2 = LoadClassIdInstr(r0)
    //     0xbff8a8: ldur            x2, [x0, #-1]
    //     0xbff8ac: ubfx            x2, x2, #0xc, #0x14
    // 0xbff8b0: cmp             x2, #0xb89
    // 0xbff8b4: b.ne            #0xbff8c4
    // 0xbff8b8: mov             x2, x0
    // 0xbff8bc: r0 = -()
    //     0xbff8bc: bl              #0x8a4f68  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0xbff8c0: b               #0xbff8e8
    // 0xbff8c4: ldur            x2, [fp, #-8]
    // 0xbff8c8: r0 = subtract()
    //     0xbff8c8: bl              #0x12f6024  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0xbff8cc: b               #0xbff8e8
    // 0xbff8d0: r0 = LoadClassIdInstr(r1)
    //     0xbff8d0: ldur            x0, [x1, #-1]
    //     0xbff8d4: ubfx            x0, x0, #0xc, #0x14
    // 0xbff8d8: ldur            x2, [fp, #-8]
    // 0xbff8dc: r0 = GDT[cid_x0 + -0xec6]()
    //     0xbff8dc: sub             lr, x0, #0xec6
    //     0xbff8e0: ldr             lr, [x21, lr, lsl #3]
    //     0xbff8e4: blr             lr
    // 0xbff8e8: stur            x0, [fp, #-0x10]
    // 0xbff8ec: r1 = LoadClassIdInstr(r0)
    //     0xbff8ec: ldur            x1, [x0, #-1]
    //     0xbff8f0: ubfx            x1, x1, #0xc, #0x14
    // 0xbff8f4: cmp             x1, #0xb88
    // 0xbff8f8: b.ne            #0xbff994
    // 0xbff8fc: LoadField: r1 = r0->field_7
    //     0xbff8fc: ldur            w1, [x0, #7]
    // 0xbff900: DecompressPointer r1
    //     0xbff900: add             x1, x1, HEAP, lsl #32
    // 0xbff904: ldur            d0, [fp, #-0x38]
    // 0xbff908: r0 = *()
    //     0xbff908: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff90c: mov             x2, x0
    // 0xbff910: ldur            x0, [fp, #-0x10]
    // 0xbff914: stur            x2, [fp, #-0x18]
    // 0xbff918: LoadField: r1 = r0->field_b
    //     0xbff918: ldur            w1, [x0, #0xb]
    // 0xbff91c: DecompressPointer r1
    //     0xbff91c: add             x1, x1, HEAP, lsl #32
    // 0xbff920: ldur            d0, [fp, #-0x38]
    // 0xbff924: r0 = *()
    //     0xbff924: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff928: mov             x2, x0
    // 0xbff92c: ldur            x0, [fp, #-0x10]
    // 0xbff930: stur            x2, [fp, #-0x20]
    // 0xbff934: LoadField: r1 = r0->field_f
    //     0xbff934: ldur            w1, [x0, #0xf]
    // 0xbff938: DecompressPointer r1
    //     0xbff938: add             x1, x1, HEAP, lsl #32
    // 0xbff93c: ldur            d0, [fp, #-0x38]
    // 0xbff940: r0 = *()
    //     0xbff940: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff944: mov             x2, x0
    // 0xbff948: ldur            x0, [fp, #-0x10]
    // 0xbff94c: stur            x2, [fp, #-0x28]
    // 0xbff950: LoadField: r1 = r0->field_13
    //     0xbff950: ldur            w1, [x0, #0x13]
    // 0xbff954: DecompressPointer r1
    //     0xbff954: add             x1, x1, HEAP, lsl #32
    // 0xbff958: ldur            d0, [fp, #-0x38]
    // 0xbff95c: r0 = *()
    //     0xbff95c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff960: stur            x0, [fp, #-0x30]
    // 0xbff964: r0 = BorderRadiusDirectional()
    //     0xbff964: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0xbff968: mov             x1, x0
    // 0xbff96c: ldur            x0, [fp, #-0x18]
    // 0xbff970: StoreField: r1->field_7 = r0
    //     0xbff970: stur            w0, [x1, #7]
    // 0xbff974: ldur            x0, [fp, #-0x20]
    // 0xbff978: StoreField: r1->field_b = r0
    //     0xbff978: stur            w0, [x1, #0xb]
    // 0xbff97c: ldur            x0, [fp, #-0x28]
    // 0xbff980: StoreField: r1->field_f = r0
    //     0xbff980: stur            w0, [x1, #0xf]
    // 0xbff984: ldur            x0, [fp, #-0x30]
    // 0xbff988: StoreField: r1->field_13 = r0
    //     0xbff988: stur            w0, [x1, #0x13]
    // 0xbff98c: mov             x2, x1
    // 0xbff990: b               #0xbffa54
    // 0xbff994: cmp             x1, #0xb89
    // 0xbff998: b.ne            #0xbffa34
    // 0xbff99c: LoadField: r1 = r0->field_7
    //     0xbff99c: ldur            w1, [x0, #7]
    // 0xbff9a0: DecompressPointer r1
    //     0xbff9a0: add             x1, x1, HEAP, lsl #32
    // 0xbff9a4: ldur            d0, [fp, #-0x38]
    // 0xbff9a8: r0 = *()
    //     0xbff9a8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff9ac: mov             x2, x0
    // 0xbff9b0: ldur            x0, [fp, #-0x10]
    // 0xbff9b4: stur            x2, [fp, #-0x18]
    // 0xbff9b8: LoadField: r1 = r0->field_b
    //     0xbff9b8: ldur            w1, [x0, #0xb]
    // 0xbff9bc: DecompressPointer r1
    //     0xbff9bc: add             x1, x1, HEAP, lsl #32
    // 0xbff9c0: ldur            d0, [fp, #-0x38]
    // 0xbff9c4: r0 = *()
    //     0xbff9c4: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff9c8: mov             x2, x0
    // 0xbff9cc: ldur            x0, [fp, #-0x10]
    // 0xbff9d0: stur            x2, [fp, #-0x20]
    // 0xbff9d4: LoadField: r1 = r0->field_f
    //     0xbff9d4: ldur            w1, [x0, #0xf]
    // 0xbff9d8: DecompressPointer r1
    //     0xbff9d8: add             x1, x1, HEAP, lsl #32
    // 0xbff9dc: ldur            d0, [fp, #-0x38]
    // 0xbff9e0: r0 = *()
    //     0xbff9e0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbff9e4: ldur            x1, [fp, #-0x10]
    // 0xbff9e8: stur            x0, [fp, #-0x28]
    // 0xbff9ec: LoadField: r2 = r1->field_13
    //     0xbff9ec: ldur            w2, [x1, #0x13]
    // 0xbff9f0: DecompressPointer r2
    //     0xbff9f0: add             x2, x2, HEAP, lsl #32
    // 0xbff9f4: mov             x1, x2
    // 0xbff9f8: ldur            d0, [fp, #-0x38]
    // 0xbff9fc: r0 = *()
    //     0xbff9fc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0xbffa00: stur            x0, [fp, #-0x30]
    // 0xbffa04: r0 = BorderRadius()
    //     0xbffa04: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbffa08: mov             x1, x0
    // 0xbffa0c: ldur            x0, [fp, #-0x18]
    // 0xbffa10: StoreField: r1->field_7 = r0
    //     0xbffa10: stur            w0, [x1, #7]
    // 0xbffa14: ldur            x0, [fp, #-0x20]
    // 0xbffa18: StoreField: r1->field_b = r0
    //     0xbffa18: stur            w0, [x1, #0xb]
    // 0xbffa1c: ldur            x0, [fp, #-0x28]
    // 0xbffa20: StoreField: r1->field_f = r0
    //     0xbffa20: stur            w0, [x1, #0xf]
    // 0xbffa24: ldur            x0, [fp, #-0x30]
    // 0xbffa28: StoreField: r1->field_13 = r0
    //     0xbffa28: stur            w0, [x1, #0x13]
    // 0xbffa2c: mov             x2, x1
    // 0xbffa30: b               #0xbffa54
    // 0xbffa34: mov             x1, x0
    // 0xbffa38: r0 = LoadClassIdInstr(r1)
    //     0xbffa38: ldur            x0, [x1, #-1]
    //     0xbffa3c: ubfx            x0, x0, #0xc, #0x14
    // 0xbffa40: ldur            d0, [fp, #-0x38]
    // 0xbffa44: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xbffa44: sub             lr, x0, #0xfb8
    //     0xbffa48: ldr             lr, [x21, lr, lsl #3]
    //     0xbffa4c: blr             lr
    // 0xbffa50: mov             x2, x0
    // 0xbffa54: ldur            x1, [fp, #-8]
    // 0xbffa58: r0 = LoadClassIdInstr(r1)
    //     0xbffa58: ldur            x0, [x1, #-1]
    //     0xbffa5c: ubfx            x0, x0, #0xc, #0x14
    // 0xbffa60: cmp             x0, #0xb88
    // 0xbffa64: b.ne            #0xbffa88
    // 0xbffa68: r0 = LoadClassIdInstr(r2)
    //     0xbffa68: ldur            x0, [x2, #-1]
    //     0xbffa6c: ubfx            x0, x0, #0xc, #0x14
    // 0xbffa70: cmp             x0, #0xb88
    // 0xbffa74: b.ne            #0xbffa80
    // 0xbffa78: r0 = +()
    //     0xbffa78: bl              #0xb776e0  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::+
    // 0xbffa7c: b               #0xbffac4
    // 0xbffa80: r0 = add()
    //     0xbffa80: bl              #0x12f5a34  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0xbffa84: b               #0xbffac4
    // 0xbffa88: cmp             x0, #0xb89
    // 0xbffa8c: b.ne            #0xbffab0
    // 0xbffa90: r0 = LoadClassIdInstr(r2)
    //     0xbffa90: ldur            x0, [x2, #-1]
    //     0xbffa94: ubfx            x0, x0, #0xc, #0x14
    // 0xbffa98: cmp             x0, #0xb89
    // 0xbffa9c: b.ne            #0xbffaa8
    // 0xbffaa0: r0 = +()
    //     0xbffaa0: bl              #0x8a53c0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0xbffaa4: b               #0xbffac4
    // 0xbffaa8: r0 = add()
    //     0xbffaa8: bl              #0x12f5a34  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0xbffaac: b               #0xbffac4
    // 0xbffab0: r0 = LoadClassIdInstr(r1)
    //     0xbffab0: ldur            x0, [x1, #-1]
    //     0xbffab4: ubfx            x0, x0, #0xc, #0x14
    // 0xbffab8: r0 = GDT[cid_x0 + -0xec3]()
    //     0xbffab8: sub             lr, x0, #0xec3
    //     0xbffabc: ldr             lr, [x21, lr, lsl #3]
    //     0xbffac0: blr             lr
    // 0xbffac4: LeaveFrame
    //     0xbffac4: mov             SP, fp
    //     0xbffac8: ldp             fp, lr, [SP], #0x10
    // 0xbffacc: ret
    //     0xbffacc: ret             
    // 0xbffad0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbffad0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbffad4: b               #0xbff824
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114b8a8, size: 0x1f8
    // 0x114b8a8: EnterFrame
    //     0x114b8a8: stp             fp, lr, [SP, #-0x10]!
    //     0x114b8ac: mov             fp, SP
    // 0x114b8b0: AllocStack(0x30)
    //     0x114b8b0: sub             SP, SP, #0x30
    // 0x114b8b4: CheckStackOverflow
    //     0x114b8b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114b8b8: cmp             SP, x16
    //     0x114b8bc: b.ls            #0x114ba98
    // 0x114b8c0: ldr             x0, [fp, #0x10]
    // 0x114b8c4: r1 = LoadClassIdInstr(r0)
    //     0x114b8c4: ldur            x1, [x0, #-1]
    //     0x114b8c8: ubfx            x1, x1, #0xc, #0x14
    // 0x114b8cc: cmp             x1, #0xb87
    // 0x114b8d0: b.ne            #0x114b8e0
    // 0x114b8d4: LoadField: r2 = r0->field_7
    //     0x114b8d4: ldur            w2, [x0, #7]
    // 0x114b8d8: DecompressPointer r2
    //     0x114b8d8: add             x2, x2, HEAP, lsl #32
    // 0x114b8dc: b               #0x114b8fc
    // 0x114b8e0: cmp             x1, #0xb88
    // 0x114b8e4: b.ne            #0x114b8f4
    // 0x114b8e8: r2 = Instance_Radius
    //     0x114b8e8: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b8ec: ldr             x2, [x2, #0x1a0]
    // 0x114b8f0: b               #0x114b8fc
    // 0x114b8f4: LoadField: r2 = r0->field_7
    //     0x114b8f4: ldur            w2, [x0, #7]
    // 0x114b8f8: DecompressPointer r2
    //     0x114b8f8: add             x2, x2, HEAP, lsl #32
    // 0x114b8fc: cmp             x1, #0xb87
    // 0x114b900: b.ne            #0x114b910
    // 0x114b904: LoadField: r3 = r0->field_b
    //     0x114b904: ldur            w3, [x0, #0xb]
    // 0x114b908: DecompressPointer r3
    //     0x114b908: add             x3, x3, HEAP, lsl #32
    // 0x114b90c: b               #0x114b92c
    // 0x114b910: cmp             x1, #0xb88
    // 0x114b914: b.ne            #0x114b924
    // 0x114b918: r3 = Instance_Radius
    //     0x114b918: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b91c: ldr             x3, [x3, #0x1a0]
    // 0x114b920: b               #0x114b92c
    // 0x114b924: LoadField: r3 = r0->field_b
    //     0x114b924: ldur            w3, [x0, #0xb]
    // 0x114b928: DecompressPointer r3
    //     0x114b928: add             x3, x3, HEAP, lsl #32
    // 0x114b92c: cmp             x1, #0xb87
    // 0x114b930: b.ne            #0x114b940
    // 0x114b934: LoadField: r4 = r0->field_f
    //     0x114b934: ldur            w4, [x0, #0xf]
    // 0x114b938: DecompressPointer r4
    //     0x114b938: add             x4, x4, HEAP, lsl #32
    // 0x114b93c: b               #0x114b95c
    // 0x114b940: cmp             x1, #0xb88
    // 0x114b944: b.ne            #0x114b954
    // 0x114b948: r4 = Instance_Radius
    //     0x114b948: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b94c: ldr             x4, [x4, #0x1a0]
    // 0x114b950: b               #0x114b95c
    // 0x114b954: LoadField: r4 = r0->field_f
    //     0x114b954: ldur            w4, [x0, #0xf]
    // 0x114b958: DecompressPointer r4
    //     0x114b958: add             x4, x4, HEAP, lsl #32
    // 0x114b95c: cmp             x1, #0xb87
    // 0x114b960: b.ne            #0x114b970
    // 0x114b964: LoadField: r5 = r0->field_13
    //     0x114b964: ldur            w5, [x0, #0x13]
    // 0x114b968: DecompressPointer r5
    //     0x114b968: add             x5, x5, HEAP, lsl #32
    // 0x114b96c: b               #0x114b98c
    // 0x114b970: cmp             x1, #0xb88
    // 0x114b974: b.ne            #0x114b984
    // 0x114b978: r5 = Instance_Radius
    //     0x114b978: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b97c: ldr             x5, [x5, #0x1a0]
    // 0x114b980: b               #0x114b98c
    // 0x114b984: LoadField: r5 = r0->field_13
    //     0x114b984: ldur            w5, [x0, #0x13]
    // 0x114b988: DecompressPointer r5
    //     0x114b988: add             x5, x5, HEAP, lsl #32
    // 0x114b98c: cmp             x1, #0xb87
    // 0x114b990: b.ne            #0x114b9a0
    // 0x114b994: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x114b994: ldur            w6, [x0, #0x17]
    // 0x114b998: DecompressPointer r6
    //     0x114b998: add             x6, x6, HEAP, lsl #32
    // 0x114b99c: b               #0x114b9bc
    // 0x114b9a0: cmp             x1, #0xb88
    // 0x114b9a4: b.ne            #0x114b9b4
    // 0x114b9a8: LoadField: r6 = r0->field_7
    //     0x114b9a8: ldur            w6, [x0, #7]
    // 0x114b9ac: DecompressPointer r6
    //     0x114b9ac: add             x6, x6, HEAP, lsl #32
    // 0x114b9b0: b               #0x114b9bc
    // 0x114b9b4: r6 = Instance_Radius
    //     0x114b9b4: add             x6, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b9b8: ldr             x6, [x6, #0x1a0]
    // 0x114b9bc: cmp             x1, #0xb87
    // 0x114b9c0: b.ne            #0x114b9d0
    // 0x114b9c4: LoadField: r7 = r0->field_1b
    //     0x114b9c4: ldur            w7, [x0, #0x1b]
    // 0x114b9c8: DecompressPointer r7
    //     0x114b9c8: add             x7, x7, HEAP, lsl #32
    // 0x114b9cc: b               #0x114b9ec
    // 0x114b9d0: cmp             x1, #0xb88
    // 0x114b9d4: b.ne            #0x114b9e4
    // 0x114b9d8: LoadField: r7 = r0->field_b
    //     0x114b9d8: ldur            w7, [x0, #0xb]
    // 0x114b9dc: DecompressPointer r7
    //     0x114b9dc: add             x7, x7, HEAP, lsl #32
    // 0x114b9e0: b               #0x114b9ec
    // 0x114b9e4: r7 = Instance_Radius
    //     0x114b9e4: add             x7, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114b9e8: ldr             x7, [x7, #0x1a0]
    // 0x114b9ec: cmp             x1, #0xb87
    // 0x114b9f0: b.ne            #0x114ba00
    // 0x114b9f4: LoadField: r8 = r0->field_1f
    //     0x114b9f4: ldur            w8, [x0, #0x1f]
    // 0x114b9f8: DecompressPointer r8
    //     0x114b9f8: add             x8, x8, HEAP, lsl #32
    // 0x114b9fc: b               #0x114ba1c
    // 0x114ba00: cmp             x1, #0xb88
    // 0x114ba04: b.ne            #0x114ba14
    // 0x114ba08: LoadField: r8 = r0->field_f
    //     0x114ba08: ldur            w8, [x0, #0xf]
    // 0x114ba0c: DecompressPointer r8
    //     0x114ba0c: add             x8, x8, HEAP, lsl #32
    // 0x114ba10: b               #0x114ba1c
    // 0x114ba14: r8 = Instance_Radius
    //     0x114ba14: add             x8, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114ba18: ldr             x8, [x8, #0x1a0]
    // 0x114ba1c: cmp             x1, #0xb87
    // 0x114ba20: b.ne            #0x114ba34
    // 0x114ba24: LoadField: r1 = r0->field_23
    //     0x114ba24: ldur            w1, [x0, #0x23]
    // 0x114ba28: DecompressPointer r1
    //     0x114ba28: add             x1, x1, HEAP, lsl #32
    // 0x114ba2c: mov             x0, x1
    // 0x114ba30: b               #0x114ba54
    // 0x114ba34: cmp             x1, #0xb88
    // 0x114ba38: b.ne            #0x114ba4c
    // 0x114ba3c: LoadField: r1 = r0->field_13
    //     0x114ba3c: ldur            w1, [x0, #0x13]
    // 0x114ba40: DecompressPointer r1
    //     0x114ba40: add             x1, x1, HEAP, lsl #32
    // 0x114ba44: mov             x0, x1
    // 0x114ba48: b               #0x114ba54
    // 0x114ba4c: r0 = Instance_Radius
    //     0x114ba4c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x114ba50: ldr             x0, [x0, #0x1a0]
    // 0x114ba54: stp             x5, x4, [SP, #0x20]
    // 0x114ba58: stp             x7, x6, [SP, #0x10]
    // 0x114ba5c: stp             x0, x8, [SP]
    // 0x114ba60: mov             x1, x2
    // 0x114ba64: mov             x2, x3
    // 0x114ba68: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x114ba68: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x114ba6c: ldr             x4, [x4, #0x90]
    // 0x114ba70: r0 = hash()
    //     0x114ba70: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114ba74: mov             x2, x0
    // 0x114ba78: r0 = BoxInt64Instr(r2)
    //     0x114ba78: sbfiz           x0, x2, #1, #0x1f
    //     0x114ba7c: cmp             x2, x0, asr #1
    //     0x114ba80: b.eq            #0x114ba8c
    //     0x114ba84: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ba88: stur            x2, [x0, #7]
    // 0x114ba8c: LeaveFrame
    //     0x114ba8c: mov             SP, fp
    //     0x114ba90: ldp             fp, lr, [SP], #0x10
    // 0x114ba94: ret
    //     0x114ba94: ret             
    // 0x114ba98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ba98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ba9c: b               #0x114b8c0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1298058, size: 0x770
    // 0x1298058: EnterFrame
    //     0x1298058: stp             fp, lr, [SP, #-0x10]!
    //     0x129805c: mov             fp, SP
    // 0x1298060: AllocStack(0x30)
    //     0x1298060: sub             SP, SP, #0x30
    // 0x1298064: CheckStackOverflow
    //     0x1298064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1298068: cmp             SP, x16
    //     0x129806c: b.ls            #0x12987c0
    // 0x1298070: ldr             x0, [fp, #0x10]
    // 0x1298074: cmp             w0, NULL
    // 0x1298078: b.ne            #0x129808c
    // 0x129807c: r0 = false
    //     0x129807c: add             x0, NULL, #0x30  ; false
    // 0x1298080: LeaveFrame
    //     0x1298080: mov             SP, fp
    //     0x1298084: ldp             fp, lr, [SP], #0x10
    // 0x1298088: ret
    //     0x1298088: ret             
    // 0x129808c: ldr             x1, [fp, #0x18]
    // 0x1298090: cmp             w1, w0
    // 0x1298094: b.ne            #0x12980a8
    // 0x1298098: r0 = true
    //     0x1298098: add             x0, NULL, #0x20  ; true
    // 0x129809c: LeaveFrame
    //     0x129809c: mov             SP, fp
    //     0x12980a0: ldp             fp, lr, [SP], #0x10
    // 0x12980a4: ret
    //     0x12980a4: ret             
    // 0x12980a8: stp             x1, x0, [SP]
    // 0x12980ac: r0 = _haveSameRuntimeType()
    //     0x12980ac: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12980b0: tbz             w0, #4, #0x12980c4
    // 0x12980b4: r0 = false
    //     0x12980b4: add             x0, NULL, #0x30  ; false
    // 0x12980b8: LeaveFrame
    //     0x12980b8: mov             SP, fp
    //     0x12980bc: ldp             fp, lr, [SP], #0x10
    // 0x12980c0: ret
    //     0x12980c0: ret             
    // 0x12980c4: ldr             x0, [fp, #0x10]
    // 0x12980c8: r1 = 60
    //     0x12980c8: mov             x1, #0x3c
    // 0x12980cc: branchIfSmi(r0, 0x12980d8)
    //     0x12980cc: tbz             w0, #0, #0x12980d8
    // 0x12980d0: r1 = LoadClassIdInstr(r0)
    //     0x12980d0: ldur            x1, [x0, #-1]
    //     0x12980d4: ubfx            x1, x1, #0xc, #0x14
    // 0x12980d8: stur            x1, [fp, #-0x20]
    // 0x12980dc: sub             x16, x1, #0xb87
    // 0x12980e0: cmp             x16, #2
    // 0x12980e4: b.hi            #0x12987b0
    // 0x12980e8: cmp             x1, #0xb87
    // 0x12980ec: b.ne            #0x1298100
    // 0x12980f0: LoadField: r2 = r0->field_7
    //     0x12980f0: ldur            w2, [x0, #7]
    // 0x12980f4: DecompressPointer r2
    //     0x12980f4: add             x2, x2, HEAP, lsl #32
    // 0x12980f8: mov             x3, x2
    // 0x12980fc: b               #0x1298120
    // 0x1298100: cmp             x1, #0xb88
    // 0x1298104: b.ne            #0x1298114
    // 0x1298108: r3 = Instance_Radius
    //     0x1298108: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x129810c: ldr             x3, [x3, #0x1a0]
    // 0x1298110: b               #0x1298120
    // 0x1298114: LoadField: r2 = r0->field_7
    //     0x1298114: ldur            w2, [x0, #7]
    // 0x1298118: DecompressPointer r2
    //     0x1298118: add             x2, x2, HEAP, lsl #32
    // 0x129811c: mov             x3, x2
    // 0x1298120: ldr             x2, [fp, #0x18]
    // 0x1298124: stur            x3, [fp, #-0x18]
    // 0x1298128: r4 = LoadClassIdInstr(r2)
    //     0x1298128: ldur            x4, [x2, #-1]
    //     0x129812c: ubfx            x4, x4, #0xc, #0x14
    // 0x1298130: stur            x4, [fp, #-0x10]
    // 0x1298134: cmp             x4, #0xb87
    // 0x1298138: b.ne            #0x1298148
    // 0x129813c: LoadField: r5 = r2->field_7
    //     0x129813c: ldur            w5, [x2, #7]
    // 0x1298140: DecompressPointer r5
    //     0x1298140: add             x5, x5, HEAP, lsl #32
    // 0x1298144: b               #0x1298164
    // 0x1298148: cmp             x4, #0xb88
    // 0x129814c: b.ne            #0x129815c
    // 0x1298150: r5 = Instance_Radius
    //     0x1298150: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298154: ldr             x5, [x5, #0x1a0]
    // 0x1298158: b               #0x1298164
    // 0x129815c: LoadField: r5 = r2->field_7
    //     0x129815c: ldur            w5, [x2, #7]
    // 0x1298160: DecompressPointer r5
    //     0x1298160: add             x5, x5, HEAP, lsl #32
    // 0x1298164: stur            x5, [fp, #-8]
    // 0x1298168: cmp             w3, w5
    // 0x129816c: b.ne            #0x1298178
    // 0x1298170: mov             x0, x1
    // 0x1298174: b               #0x12981c0
    // 0x1298178: r16 = Radius
    //     0x1298178: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x129817c: ldr             x16, [x16, #0x960]
    // 0x1298180: r30 = Radius
    //     0x1298180: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298184: ldr             lr, [lr, #0x960]
    // 0x1298188: stp             lr, x16, [SP]
    // 0x129818c: r0 = ==()
    //     0x129818c: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1298190: tbnz            w0, #4, #0x12987b0
    // 0x1298194: ldur            x0, [fp, #-0x18]
    // 0x1298198: ldur            x1, [fp, #-8]
    // 0x129819c: LoadField: d0 = r1->field_7
    //     0x129819c: ldur            d0, [x1, #7]
    // 0x12981a0: LoadField: d1 = r0->field_7
    //     0x12981a0: ldur            d1, [x0, #7]
    // 0x12981a4: fcmp            d0, d1
    // 0x12981a8: b.ne            #0x12987b0
    // 0x12981ac: LoadField: d0 = r1->field_f
    //     0x12981ac: ldur            d0, [x1, #0xf]
    // 0x12981b0: LoadField: d1 = r0->field_f
    //     0x12981b0: ldur            d1, [x0, #0xf]
    // 0x12981b4: fcmp            d0, d1
    // 0x12981b8: b.ne            #0x12987b0
    // 0x12981bc: ldur            x0, [fp, #-0x20]
    // 0x12981c0: cmp             x0, #0xb87
    // 0x12981c4: b.ne            #0x12981dc
    // 0x12981c8: ldr             x1, [fp, #0x10]
    // 0x12981cc: LoadField: r2 = r1->field_b
    //     0x12981cc: ldur            w2, [x1, #0xb]
    // 0x12981d0: DecompressPointer r2
    //     0x12981d0: add             x2, x2, HEAP, lsl #32
    // 0x12981d4: mov             x3, x2
    // 0x12981d8: b               #0x1298200
    // 0x12981dc: ldr             x1, [fp, #0x10]
    // 0x12981e0: cmp             x0, #0xb88
    // 0x12981e4: b.ne            #0x12981f4
    // 0x12981e8: r3 = Instance_Radius
    //     0x12981e8: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12981ec: ldr             x3, [x3, #0x1a0]
    // 0x12981f0: b               #0x1298200
    // 0x12981f4: LoadField: r2 = r1->field_b
    //     0x12981f4: ldur            w2, [x1, #0xb]
    // 0x12981f8: DecompressPointer r2
    //     0x12981f8: add             x2, x2, HEAP, lsl #32
    // 0x12981fc: mov             x3, x2
    // 0x1298200: ldur            x2, [fp, #-0x10]
    // 0x1298204: stur            x3, [fp, #-0x18]
    // 0x1298208: cmp             x2, #0xb87
    // 0x129820c: b.ne            #0x1298220
    // 0x1298210: ldr             x4, [fp, #0x18]
    // 0x1298214: LoadField: r5 = r4->field_b
    //     0x1298214: ldur            w5, [x4, #0xb]
    // 0x1298218: DecompressPointer r5
    //     0x1298218: add             x5, x5, HEAP, lsl #32
    // 0x129821c: b               #0x1298240
    // 0x1298220: ldr             x4, [fp, #0x18]
    // 0x1298224: cmp             x2, #0xb88
    // 0x1298228: b.ne            #0x1298238
    // 0x129822c: r5 = Instance_Radius
    //     0x129822c: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298230: ldr             x5, [x5, #0x1a0]
    // 0x1298234: b               #0x1298240
    // 0x1298238: LoadField: r5 = r4->field_b
    //     0x1298238: ldur            w5, [x4, #0xb]
    // 0x129823c: DecompressPointer r5
    //     0x129823c: add             x5, x5, HEAP, lsl #32
    // 0x1298240: stur            x5, [fp, #-8]
    // 0x1298244: cmp             w3, w5
    // 0x1298248: b.eq            #0x1298294
    // 0x129824c: r16 = Radius
    //     0x129824c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298250: ldr             x16, [x16, #0x960]
    // 0x1298254: r30 = Radius
    //     0x1298254: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298258: ldr             lr, [lr, #0x960]
    // 0x129825c: stp             lr, x16, [SP]
    // 0x1298260: r0 = ==()
    //     0x1298260: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1298264: tbnz            w0, #4, #0x12987b0
    // 0x1298268: ldur            x0, [fp, #-0x18]
    // 0x129826c: ldur            x1, [fp, #-8]
    // 0x1298270: LoadField: d0 = r1->field_7
    //     0x1298270: ldur            d0, [x1, #7]
    // 0x1298274: LoadField: d1 = r0->field_7
    //     0x1298274: ldur            d1, [x0, #7]
    // 0x1298278: fcmp            d0, d1
    // 0x129827c: b.ne            #0x12987b0
    // 0x1298280: LoadField: d0 = r1->field_f
    //     0x1298280: ldur            d0, [x1, #0xf]
    // 0x1298284: LoadField: d1 = r0->field_f
    //     0x1298284: ldur            d1, [x0, #0xf]
    // 0x1298288: fcmp            d0, d1
    // 0x129828c: b.ne            #0x12987b0
    // 0x1298290: ldur            x0, [fp, #-0x20]
    // 0x1298294: cmp             x0, #0xb87
    // 0x1298298: b.ne            #0x12982b0
    // 0x129829c: ldr             x1, [fp, #0x10]
    // 0x12982a0: LoadField: r2 = r1->field_f
    //     0x12982a0: ldur            w2, [x1, #0xf]
    // 0x12982a4: DecompressPointer r2
    //     0x12982a4: add             x2, x2, HEAP, lsl #32
    // 0x12982a8: mov             x3, x2
    // 0x12982ac: b               #0x12982d4
    // 0x12982b0: ldr             x1, [fp, #0x10]
    // 0x12982b4: cmp             x0, #0xb88
    // 0x12982b8: b.ne            #0x12982c8
    // 0x12982bc: r3 = Instance_Radius
    //     0x12982bc: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12982c0: ldr             x3, [x3, #0x1a0]
    // 0x12982c4: b               #0x12982d4
    // 0x12982c8: LoadField: r2 = r1->field_f
    //     0x12982c8: ldur            w2, [x1, #0xf]
    // 0x12982cc: DecompressPointer r2
    //     0x12982cc: add             x2, x2, HEAP, lsl #32
    // 0x12982d0: mov             x3, x2
    // 0x12982d4: ldur            x2, [fp, #-0x10]
    // 0x12982d8: stur            x3, [fp, #-0x18]
    // 0x12982dc: cmp             x2, #0xb87
    // 0x12982e0: b.ne            #0x12982f4
    // 0x12982e4: ldr             x4, [fp, #0x18]
    // 0x12982e8: LoadField: r5 = r4->field_f
    //     0x12982e8: ldur            w5, [x4, #0xf]
    // 0x12982ec: DecompressPointer r5
    //     0x12982ec: add             x5, x5, HEAP, lsl #32
    // 0x12982f0: b               #0x1298314
    // 0x12982f4: ldr             x4, [fp, #0x18]
    // 0x12982f8: cmp             x2, #0xb88
    // 0x12982fc: b.ne            #0x129830c
    // 0x1298300: r5 = Instance_Radius
    //     0x1298300: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298304: ldr             x5, [x5, #0x1a0]
    // 0x1298308: b               #0x1298314
    // 0x129830c: LoadField: r5 = r4->field_f
    //     0x129830c: ldur            w5, [x4, #0xf]
    // 0x1298310: DecompressPointer r5
    //     0x1298310: add             x5, x5, HEAP, lsl #32
    // 0x1298314: stur            x5, [fp, #-8]
    // 0x1298318: cmp             w3, w5
    // 0x129831c: b.eq            #0x1298368
    // 0x1298320: r16 = Radius
    //     0x1298320: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298324: ldr             x16, [x16, #0x960]
    // 0x1298328: r30 = Radius
    //     0x1298328: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x129832c: ldr             lr, [lr, #0x960]
    // 0x1298330: stp             lr, x16, [SP]
    // 0x1298334: r0 = ==()
    //     0x1298334: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1298338: tbnz            w0, #4, #0x12987b0
    // 0x129833c: ldur            x0, [fp, #-0x18]
    // 0x1298340: ldur            x1, [fp, #-8]
    // 0x1298344: LoadField: d0 = r1->field_7
    //     0x1298344: ldur            d0, [x1, #7]
    // 0x1298348: LoadField: d1 = r0->field_7
    //     0x1298348: ldur            d1, [x0, #7]
    // 0x129834c: fcmp            d0, d1
    // 0x1298350: b.ne            #0x12987b0
    // 0x1298354: LoadField: d0 = r1->field_f
    //     0x1298354: ldur            d0, [x1, #0xf]
    // 0x1298358: LoadField: d1 = r0->field_f
    //     0x1298358: ldur            d1, [x0, #0xf]
    // 0x129835c: fcmp            d0, d1
    // 0x1298360: b.ne            #0x12987b0
    // 0x1298364: ldur            x0, [fp, #-0x20]
    // 0x1298368: cmp             x0, #0xb87
    // 0x129836c: b.ne            #0x1298384
    // 0x1298370: ldr             x1, [fp, #0x10]
    // 0x1298374: LoadField: r2 = r1->field_13
    //     0x1298374: ldur            w2, [x1, #0x13]
    // 0x1298378: DecompressPointer r2
    //     0x1298378: add             x2, x2, HEAP, lsl #32
    // 0x129837c: mov             x3, x2
    // 0x1298380: b               #0x12983a8
    // 0x1298384: ldr             x1, [fp, #0x10]
    // 0x1298388: cmp             x0, #0xb88
    // 0x129838c: b.ne            #0x129839c
    // 0x1298390: r3 = Instance_Radius
    //     0x1298390: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298394: ldr             x3, [x3, #0x1a0]
    // 0x1298398: b               #0x12983a8
    // 0x129839c: LoadField: r2 = r1->field_13
    //     0x129839c: ldur            w2, [x1, #0x13]
    // 0x12983a0: DecompressPointer r2
    //     0x12983a0: add             x2, x2, HEAP, lsl #32
    // 0x12983a4: mov             x3, x2
    // 0x12983a8: ldur            x2, [fp, #-0x10]
    // 0x12983ac: stur            x3, [fp, #-0x18]
    // 0x12983b0: cmp             x2, #0xb87
    // 0x12983b4: b.ne            #0x12983c8
    // 0x12983b8: ldr             x4, [fp, #0x18]
    // 0x12983bc: LoadField: r5 = r4->field_13
    //     0x12983bc: ldur            w5, [x4, #0x13]
    // 0x12983c0: DecompressPointer r5
    //     0x12983c0: add             x5, x5, HEAP, lsl #32
    // 0x12983c4: b               #0x12983e8
    // 0x12983c8: ldr             x4, [fp, #0x18]
    // 0x12983cc: cmp             x2, #0xb88
    // 0x12983d0: b.ne            #0x12983e0
    // 0x12983d4: r5 = Instance_Radius
    //     0x12983d4: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12983d8: ldr             x5, [x5, #0x1a0]
    // 0x12983dc: b               #0x12983e8
    // 0x12983e0: LoadField: r5 = r4->field_13
    //     0x12983e0: ldur            w5, [x4, #0x13]
    // 0x12983e4: DecompressPointer r5
    //     0x12983e4: add             x5, x5, HEAP, lsl #32
    // 0x12983e8: stur            x5, [fp, #-8]
    // 0x12983ec: cmp             w3, w5
    // 0x12983f0: b.eq            #0x129843c
    // 0x12983f4: r16 = Radius
    //     0x12983f4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12983f8: ldr             x16, [x16, #0x960]
    // 0x12983fc: r30 = Radius
    //     0x12983fc: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298400: ldr             lr, [lr, #0x960]
    // 0x1298404: stp             lr, x16, [SP]
    // 0x1298408: r0 = ==()
    //     0x1298408: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x129840c: tbnz            w0, #4, #0x12987b0
    // 0x1298410: ldur            x0, [fp, #-0x18]
    // 0x1298414: ldur            x1, [fp, #-8]
    // 0x1298418: LoadField: d0 = r1->field_7
    //     0x1298418: ldur            d0, [x1, #7]
    // 0x129841c: LoadField: d1 = r0->field_7
    //     0x129841c: ldur            d1, [x0, #7]
    // 0x1298420: fcmp            d0, d1
    // 0x1298424: b.ne            #0x12987b0
    // 0x1298428: LoadField: d0 = r1->field_f
    //     0x1298428: ldur            d0, [x1, #0xf]
    // 0x129842c: LoadField: d1 = r0->field_f
    //     0x129842c: ldur            d1, [x0, #0xf]
    // 0x1298430: fcmp            d0, d1
    // 0x1298434: b.ne            #0x12987b0
    // 0x1298438: ldur            x0, [fp, #-0x20]
    // 0x129843c: cmp             x0, #0xb87
    // 0x1298440: b.ne            #0x1298458
    // 0x1298444: ldr             x1, [fp, #0x10]
    // 0x1298448: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1298448: ldur            w2, [x1, #0x17]
    // 0x129844c: DecompressPointer r2
    //     0x129844c: add             x2, x2, HEAP, lsl #32
    // 0x1298450: mov             x3, x2
    // 0x1298454: b               #0x129847c
    // 0x1298458: ldr             x1, [fp, #0x10]
    // 0x129845c: cmp             x0, #0xb88
    // 0x1298460: b.ne            #0x1298474
    // 0x1298464: LoadField: r2 = r1->field_7
    //     0x1298464: ldur            w2, [x1, #7]
    // 0x1298468: DecompressPointer r2
    //     0x1298468: add             x2, x2, HEAP, lsl #32
    // 0x129846c: mov             x3, x2
    // 0x1298470: b               #0x129847c
    // 0x1298474: r3 = Instance_Radius
    //     0x1298474: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298478: ldr             x3, [x3, #0x1a0]
    // 0x129847c: ldur            x2, [fp, #-0x10]
    // 0x1298480: stur            x3, [fp, #-0x18]
    // 0x1298484: cmp             x2, #0xb87
    // 0x1298488: b.ne            #0x129849c
    // 0x129848c: ldr             x4, [fp, #0x18]
    // 0x1298490: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1298490: ldur            w5, [x4, #0x17]
    // 0x1298494: DecompressPointer r5
    //     0x1298494: add             x5, x5, HEAP, lsl #32
    // 0x1298498: b               #0x12984bc
    // 0x129849c: ldr             x4, [fp, #0x18]
    // 0x12984a0: cmp             x2, #0xb88
    // 0x12984a4: b.ne            #0x12984b4
    // 0x12984a8: LoadField: r5 = r4->field_7
    //     0x12984a8: ldur            w5, [x4, #7]
    // 0x12984ac: DecompressPointer r5
    //     0x12984ac: add             x5, x5, HEAP, lsl #32
    // 0x12984b0: b               #0x12984bc
    // 0x12984b4: r5 = Instance_Radius
    //     0x12984b4: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12984b8: ldr             x5, [x5, #0x1a0]
    // 0x12984bc: stur            x5, [fp, #-8]
    // 0x12984c0: cmp             w3, w5
    // 0x12984c4: b.eq            #0x1298510
    // 0x12984c8: r16 = Radius
    //     0x12984c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12984cc: ldr             x16, [x16, #0x960]
    // 0x12984d0: r30 = Radius
    //     0x12984d0: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12984d4: ldr             lr, [lr, #0x960]
    // 0x12984d8: stp             lr, x16, [SP]
    // 0x12984dc: r0 = ==()
    //     0x12984dc: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12984e0: tbnz            w0, #4, #0x12987b0
    // 0x12984e4: ldur            x0, [fp, #-0x18]
    // 0x12984e8: ldur            x1, [fp, #-8]
    // 0x12984ec: LoadField: d0 = r1->field_7
    //     0x12984ec: ldur            d0, [x1, #7]
    // 0x12984f0: LoadField: d1 = r0->field_7
    //     0x12984f0: ldur            d1, [x0, #7]
    // 0x12984f4: fcmp            d0, d1
    // 0x12984f8: b.ne            #0x12987b0
    // 0x12984fc: LoadField: d0 = r1->field_f
    //     0x12984fc: ldur            d0, [x1, #0xf]
    // 0x1298500: LoadField: d1 = r0->field_f
    //     0x1298500: ldur            d1, [x0, #0xf]
    // 0x1298504: fcmp            d0, d1
    // 0x1298508: b.ne            #0x12987b0
    // 0x129850c: ldur            x0, [fp, #-0x20]
    // 0x1298510: cmp             x0, #0xb87
    // 0x1298514: b.ne            #0x129852c
    // 0x1298518: ldr             x1, [fp, #0x10]
    // 0x129851c: LoadField: r2 = r1->field_1b
    //     0x129851c: ldur            w2, [x1, #0x1b]
    // 0x1298520: DecompressPointer r2
    //     0x1298520: add             x2, x2, HEAP, lsl #32
    // 0x1298524: mov             x3, x2
    // 0x1298528: b               #0x1298550
    // 0x129852c: ldr             x1, [fp, #0x10]
    // 0x1298530: cmp             x0, #0xb88
    // 0x1298534: b.ne            #0x1298548
    // 0x1298538: LoadField: r2 = r1->field_b
    //     0x1298538: ldur            w2, [x1, #0xb]
    // 0x129853c: DecompressPointer r2
    //     0x129853c: add             x2, x2, HEAP, lsl #32
    // 0x1298540: mov             x3, x2
    // 0x1298544: b               #0x1298550
    // 0x1298548: r3 = Instance_Radius
    //     0x1298548: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x129854c: ldr             x3, [x3, #0x1a0]
    // 0x1298550: ldur            x2, [fp, #-0x10]
    // 0x1298554: stur            x3, [fp, #-0x18]
    // 0x1298558: cmp             x2, #0xb87
    // 0x129855c: b.ne            #0x1298570
    // 0x1298560: ldr             x4, [fp, #0x18]
    // 0x1298564: LoadField: r5 = r4->field_1b
    //     0x1298564: ldur            w5, [x4, #0x1b]
    // 0x1298568: DecompressPointer r5
    //     0x1298568: add             x5, x5, HEAP, lsl #32
    // 0x129856c: b               #0x1298590
    // 0x1298570: ldr             x4, [fp, #0x18]
    // 0x1298574: cmp             x2, #0xb88
    // 0x1298578: b.ne            #0x1298588
    // 0x129857c: LoadField: r5 = r4->field_b
    //     0x129857c: ldur            w5, [x4, #0xb]
    // 0x1298580: DecompressPointer r5
    //     0x1298580: add             x5, x5, HEAP, lsl #32
    // 0x1298584: b               #0x1298590
    // 0x1298588: r5 = Instance_Radius
    //     0x1298588: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x129858c: ldr             x5, [x5, #0x1a0]
    // 0x1298590: stur            x5, [fp, #-8]
    // 0x1298594: cmp             w3, w5
    // 0x1298598: b.eq            #0x12985e4
    // 0x129859c: r16 = Radius
    //     0x129859c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12985a0: ldr             x16, [x16, #0x960]
    // 0x12985a4: r30 = Radius
    //     0x12985a4: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x12985a8: ldr             lr, [lr, #0x960]
    // 0x12985ac: stp             lr, x16, [SP]
    // 0x12985b0: r0 = ==()
    //     0x12985b0: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x12985b4: tbnz            w0, #4, #0x12987b0
    // 0x12985b8: ldur            x0, [fp, #-0x18]
    // 0x12985bc: ldur            x1, [fp, #-8]
    // 0x12985c0: LoadField: d0 = r1->field_7
    //     0x12985c0: ldur            d0, [x1, #7]
    // 0x12985c4: LoadField: d1 = r0->field_7
    //     0x12985c4: ldur            d1, [x0, #7]
    // 0x12985c8: fcmp            d0, d1
    // 0x12985cc: b.ne            #0x12987b0
    // 0x12985d0: LoadField: d0 = r1->field_f
    //     0x12985d0: ldur            d0, [x1, #0xf]
    // 0x12985d4: LoadField: d1 = r0->field_f
    //     0x12985d4: ldur            d1, [x0, #0xf]
    // 0x12985d8: fcmp            d0, d1
    // 0x12985dc: b.ne            #0x12987b0
    // 0x12985e0: ldur            x0, [fp, #-0x20]
    // 0x12985e4: cmp             x0, #0xb87
    // 0x12985e8: b.ne            #0x1298600
    // 0x12985ec: ldr             x1, [fp, #0x10]
    // 0x12985f0: LoadField: r2 = r1->field_1f
    //     0x12985f0: ldur            w2, [x1, #0x1f]
    // 0x12985f4: DecompressPointer r2
    //     0x12985f4: add             x2, x2, HEAP, lsl #32
    // 0x12985f8: mov             x3, x2
    // 0x12985fc: b               #0x1298624
    // 0x1298600: ldr             x1, [fp, #0x10]
    // 0x1298604: cmp             x0, #0xb88
    // 0x1298608: b.ne            #0x129861c
    // 0x129860c: LoadField: r2 = r1->field_f
    //     0x129860c: ldur            w2, [x1, #0xf]
    // 0x1298610: DecompressPointer r2
    //     0x1298610: add             x2, x2, HEAP, lsl #32
    // 0x1298614: mov             x3, x2
    // 0x1298618: b               #0x1298624
    // 0x129861c: r3 = Instance_Radius
    //     0x129861c: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298620: ldr             x3, [x3, #0x1a0]
    // 0x1298624: ldur            x2, [fp, #-0x10]
    // 0x1298628: stur            x3, [fp, #-0x18]
    // 0x129862c: cmp             x2, #0xb87
    // 0x1298630: b.ne            #0x1298644
    // 0x1298634: ldr             x4, [fp, #0x18]
    // 0x1298638: LoadField: r5 = r4->field_1f
    //     0x1298638: ldur            w5, [x4, #0x1f]
    // 0x129863c: DecompressPointer r5
    //     0x129863c: add             x5, x5, HEAP, lsl #32
    // 0x1298640: b               #0x1298664
    // 0x1298644: ldr             x4, [fp, #0x18]
    // 0x1298648: cmp             x2, #0xb88
    // 0x129864c: b.ne            #0x129865c
    // 0x1298650: LoadField: r5 = r4->field_f
    //     0x1298650: ldur            w5, [x4, #0xf]
    // 0x1298654: DecompressPointer r5
    //     0x1298654: add             x5, x5, HEAP, lsl #32
    // 0x1298658: b               #0x1298664
    // 0x129865c: r5 = Instance_Radius
    //     0x129865c: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298660: ldr             x5, [x5, #0x1a0]
    // 0x1298664: stur            x5, [fp, #-8]
    // 0x1298668: cmp             w3, w5
    // 0x129866c: b.eq            #0x12986b8
    // 0x1298670: r16 = Radius
    //     0x1298670: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298674: ldr             x16, [x16, #0x960]
    // 0x1298678: r30 = Radius
    //     0x1298678: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x129867c: ldr             lr, [lr, #0x960]
    // 0x1298680: stp             lr, x16, [SP]
    // 0x1298684: r0 = ==()
    //     0x1298684: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1298688: tbnz            w0, #4, #0x12987b0
    // 0x129868c: ldur            x0, [fp, #-0x18]
    // 0x1298690: ldur            x1, [fp, #-8]
    // 0x1298694: LoadField: d0 = r1->field_7
    //     0x1298694: ldur            d0, [x1, #7]
    // 0x1298698: LoadField: d1 = r0->field_7
    //     0x1298698: ldur            d1, [x0, #7]
    // 0x129869c: fcmp            d0, d1
    // 0x12986a0: b.ne            #0x12987b0
    // 0x12986a4: LoadField: d0 = r1->field_f
    //     0x12986a4: ldur            d0, [x1, #0xf]
    // 0x12986a8: LoadField: d1 = r0->field_f
    //     0x12986a8: ldur            d1, [x0, #0xf]
    // 0x12986ac: fcmp            d0, d1
    // 0x12986b0: b.ne            #0x12987b0
    // 0x12986b4: ldur            x0, [fp, #-0x20]
    // 0x12986b8: cmp             x0, #0xb87
    // 0x12986bc: b.ne            #0x12986d4
    // 0x12986c0: ldr             x1, [fp, #0x10]
    // 0x12986c4: LoadField: r0 = r1->field_23
    //     0x12986c4: ldur            w0, [x1, #0x23]
    // 0x12986c8: DecompressPointer r0
    //     0x12986c8: add             x0, x0, HEAP, lsl #32
    // 0x12986cc: mov             x1, x0
    // 0x12986d0: b               #0x12986f8
    // 0x12986d4: ldr             x1, [fp, #0x10]
    // 0x12986d8: cmp             x0, #0xb88
    // 0x12986dc: b.ne            #0x12986f0
    // 0x12986e0: LoadField: r0 = r1->field_13
    //     0x12986e0: ldur            w0, [x1, #0x13]
    // 0x12986e4: DecompressPointer r0
    //     0x12986e4: add             x0, x0, HEAP, lsl #32
    // 0x12986e8: mov             x1, x0
    // 0x12986ec: b               #0x12986f8
    // 0x12986f0: r1 = Instance_Radius
    //     0x12986f0: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12986f4: ldr             x1, [x1, #0x1a0]
    // 0x12986f8: ldur            x0, [fp, #-0x10]
    // 0x12986fc: stur            x1, [fp, #-0x18]
    // 0x1298700: cmp             x0, #0xb87
    // 0x1298704: b.ne            #0x1298718
    // 0x1298708: ldr             x2, [fp, #0x18]
    // 0x129870c: LoadField: r0 = r2->field_23
    //     0x129870c: ldur            w0, [x2, #0x23]
    // 0x1298710: DecompressPointer r0
    //     0x1298710: add             x0, x0, HEAP, lsl #32
    // 0x1298714: b               #0x1298738
    // 0x1298718: ldr             x2, [fp, #0x18]
    // 0x129871c: cmp             x0, #0xb88
    // 0x1298720: b.ne            #0x1298730
    // 0x1298724: LoadField: r0 = r2->field_13
    //     0x1298724: ldur            w0, [x2, #0x13]
    // 0x1298728: DecompressPointer r0
    //     0x1298728: add             x0, x0, HEAP, lsl #32
    // 0x129872c: b               #0x1298738
    // 0x1298730: r0 = Instance_Radius
    //     0x1298730: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x1298734: ldr             x0, [x0, #0x1a0]
    // 0x1298738: stur            x0, [fp, #-8]
    // 0x129873c: cmp             w1, w0
    // 0x1298740: b.ne            #0x129874c
    // 0x1298744: r1 = true
    //     0x1298744: add             x1, NULL, #0x20  ; true
    // 0x1298748: b               #0x12987a8
    // 0x129874c: r16 = Radius
    //     0x129874c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298750: ldr             x16, [x16, #0x960]
    // 0x1298754: r30 = Radius
    //     0x1298754: add             lr, PP, #0x26, lsl #12  ; [pp+0x26960] Type: Radius
    //     0x1298758: ldr             lr, [lr, #0x960]
    // 0x129875c: stp             lr, x16, [SP]
    // 0x1298760: r0 = ==()
    //     0x1298760: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1298764: tbz             w0, #4, #0x1298770
    // 0x1298768: r1 = false
    //     0x1298768: add             x1, NULL, #0x30  ; false
    // 0x129876c: b               #0x12987a8
    // 0x1298770: ldur            x1, [fp, #-0x18]
    // 0x1298774: ldur            x2, [fp, #-8]
    // 0x1298778: LoadField: d0 = r2->field_7
    //     0x1298778: ldur            d0, [x2, #7]
    // 0x129877c: LoadField: d1 = r1->field_7
    //     0x129877c: ldur            d1, [x1, #7]
    // 0x1298780: fcmp            d0, d1
    // 0x1298784: b.ne            #0x12987a4
    // 0x1298788: LoadField: d0 = r2->field_f
    //     0x1298788: ldur            d0, [x2, #0xf]
    // 0x129878c: LoadField: d1 = r1->field_f
    //     0x129878c: ldur            d1, [x1, #0xf]
    // 0x1298790: fcmp            d0, d1
    // 0x1298794: r16 = true
    //     0x1298794: add             x16, NULL, #0x20  ; true
    // 0x1298798: r17 = false
    //     0x1298798: add             x17, NULL, #0x30  ; false
    // 0x129879c: csel            x1, x16, x17, eq
    // 0x12987a0: b               #0x12987a8
    // 0x12987a4: r1 = false
    //     0x12987a4: add             x1, NULL, #0x30  ; false
    // 0x12987a8: mov             x0, x1
    // 0x12987ac: b               #0x12987b4
    // 0x12987b0: r0 = false
    //     0x12987b0: add             x0, NULL, #0x30  ; false
    // 0x12987b4: LeaveFrame
    //     0x12987b4: mov             SP, fp
    //     0x12987b8: ldp             fp, lr, [SP], #0x10
    // 0x12987bc: ret
    //     0x12987bc: ret             
    // 0x12987c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12987c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12987c4: b               #0x1298070
  }
  _ add(/* No info */) {
    // ** addr: 0x12f5a34, size: 0x4c4
    // 0x12f5a34: EnterFrame
    //     0x12f5a34: stp             fp, lr, [SP, #-0x10]!
    //     0x12f5a38: mov             fp, SP
    // 0x12f5a3c: AllocStack(0x58)
    //     0x12f5a3c: sub             SP, SP, #0x58
    // 0x12f5a40: SetupParameters(BorderRadiusGeometry this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x12f5a40: mov             x3, x1
    //     0x12f5a44: mov             x0, x2
    //     0x12f5a48: stur            x1, [fp, #-0x18]
    //     0x12f5a4c: stur            x2, [fp, #-0x20]
    // 0x12f5a50: CheckStackOverflow
    //     0x12f5a50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f5a54: cmp             SP, x16
    //     0x12f5a58: b.ls            #0x12f5ef0
    // 0x12f5a5c: r4 = LoadClassIdInstr(r3)
    //     0x12f5a5c: ldur            x4, [x3, #-1]
    //     0x12f5a60: ubfx            x4, x4, #0xc, #0x14
    // 0x12f5a64: stur            x4, [fp, #-0x10]
    // 0x12f5a68: cmp             x4, #0xb87
    // 0x12f5a6c: b.ne            #0x12f5a7c
    // 0x12f5a70: LoadField: r1 = r3->field_7
    //     0x12f5a70: ldur            w1, [x3, #7]
    // 0x12f5a74: DecompressPointer r1
    //     0x12f5a74: add             x1, x1, HEAP, lsl #32
    // 0x12f5a78: b               #0x12f5a98
    // 0x12f5a7c: cmp             x4, #0xb88
    // 0x12f5a80: b.ne            #0x12f5a90
    // 0x12f5a84: r1 = Instance_Radius
    //     0x12f5a84: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5a88: ldr             x1, [x1, #0x1a0]
    // 0x12f5a8c: b               #0x12f5a98
    // 0x12f5a90: LoadField: r1 = r3->field_7
    //     0x12f5a90: ldur            w1, [x3, #7]
    // 0x12f5a94: DecompressPointer r1
    //     0x12f5a94: add             x1, x1, HEAP, lsl #32
    // 0x12f5a98: r5 = LoadClassIdInstr(r0)
    //     0x12f5a98: ldur            x5, [x0, #-1]
    //     0x12f5a9c: ubfx            x5, x5, #0xc, #0x14
    // 0x12f5aa0: stur            x5, [fp, #-8]
    // 0x12f5aa4: cmp             x5, #0xb87
    // 0x12f5aa8: b.ne            #0x12f5ab8
    // 0x12f5aac: LoadField: r2 = r0->field_7
    //     0x12f5aac: ldur            w2, [x0, #7]
    // 0x12f5ab0: DecompressPointer r2
    //     0x12f5ab0: add             x2, x2, HEAP, lsl #32
    // 0x12f5ab4: b               #0x12f5ad4
    // 0x12f5ab8: cmp             x5, #0xb88
    // 0x12f5abc: b.ne            #0x12f5acc
    // 0x12f5ac0: r2 = Instance_Radius
    //     0x12f5ac0: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5ac4: ldr             x2, [x2, #0x1a0]
    // 0x12f5ac8: b               #0x12f5ad4
    // 0x12f5acc: LoadField: r2 = r0->field_7
    //     0x12f5acc: ldur            w2, [x0, #7]
    // 0x12f5ad0: DecompressPointer r2
    //     0x12f5ad0: add             x2, x2, HEAP, lsl #32
    // 0x12f5ad4: r0 = +()
    //     0x12f5ad4: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5ad8: mov             x3, x0
    // 0x12f5adc: ldur            x0, [fp, #-0x10]
    // 0x12f5ae0: stur            x3, [fp, #-0x28]
    // 0x12f5ae4: cmp             x0, #0xb87
    // 0x12f5ae8: b.ne            #0x12f5afc
    // 0x12f5aec: ldur            x4, [fp, #-0x18]
    // 0x12f5af0: LoadField: r1 = r4->field_b
    //     0x12f5af0: ldur            w1, [x4, #0xb]
    // 0x12f5af4: DecompressPointer r1
    //     0x12f5af4: add             x1, x1, HEAP, lsl #32
    // 0x12f5af8: b               #0x12f5b1c
    // 0x12f5afc: ldur            x4, [fp, #-0x18]
    // 0x12f5b00: cmp             x0, #0xb88
    // 0x12f5b04: b.ne            #0x12f5b14
    // 0x12f5b08: r1 = Instance_Radius
    //     0x12f5b08: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5b0c: ldr             x1, [x1, #0x1a0]
    // 0x12f5b10: b               #0x12f5b1c
    // 0x12f5b14: LoadField: r1 = r4->field_b
    //     0x12f5b14: ldur            w1, [x4, #0xb]
    // 0x12f5b18: DecompressPointer r1
    //     0x12f5b18: add             x1, x1, HEAP, lsl #32
    // 0x12f5b1c: ldur            x5, [fp, #-8]
    // 0x12f5b20: cmp             x5, #0xb87
    // 0x12f5b24: b.ne            #0x12f5b38
    // 0x12f5b28: ldur            x6, [fp, #-0x20]
    // 0x12f5b2c: LoadField: r2 = r6->field_b
    //     0x12f5b2c: ldur            w2, [x6, #0xb]
    // 0x12f5b30: DecompressPointer r2
    //     0x12f5b30: add             x2, x2, HEAP, lsl #32
    // 0x12f5b34: b               #0x12f5b58
    // 0x12f5b38: ldur            x6, [fp, #-0x20]
    // 0x12f5b3c: cmp             x5, #0xb88
    // 0x12f5b40: b.ne            #0x12f5b50
    // 0x12f5b44: r2 = Instance_Radius
    //     0x12f5b44: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5b48: ldr             x2, [x2, #0x1a0]
    // 0x12f5b4c: b               #0x12f5b58
    // 0x12f5b50: LoadField: r2 = r6->field_b
    //     0x12f5b50: ldur            w2, [x6, #0xb]
    // 0x12f5b54: DecompressPointer r2
    //     0x12f5b54: add             x2, x2, HEAP, lsl #32
    // 0x12f5b58: r0 = +()
    //     0x12f5b58: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5b5c: mov             x3, x0
    // 0x12f5b60: ldur            x0, [fp, #-0x10]
    // 0x12f5b64: stur            x3, [fp, #-0x30]
    // 0x12f5b68: cmp             x0, #0xb87
    // 0x12f5b6c: b.ne            #0x12f5b80
    // 0x12f5b70: ldur            x4, [fp, #-0x18]
    // 0x12f5b74: LoadField: r1 = r4->field_f
    //     0x12f5b74: ldur            w1, [x4, #0xf]
    // 0x12f5b78: DecompressPointer r1
    //     0x12f5b78: add             x1, x1, HEAP, lsl #32
    // 0x12f5b7c: b               #0x12f5ba0
    // 0x12f5b80: ldur            x4, [fp, #-0x18]
    // 0x12f5b84: cmp             x0, #0xb88
    // 0x12f5b88: b.ne            #0x12f5b98
    // 0x12f5b8c: r1 = Instance_Radius
    //     0x12f5b8c: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5b90: ldr             x1, [x1, #0x1a0]
    // 0x12f5b94: b               #0x12f5ba0
    // 0x12f5b98: LoadField: r1 = r4->field_f
    //     0x12f5b98: ldur            w1, [x4, #0xf]
    // 0x12f5b9c: DecompressPointer r1
    //     0x12f5b9c: add             x1, x1, HEAP, lsl #32
    // 0x12f5ba0: ldur            x5, [fp, #-8]
    // 0x12f5ba4: cmp             x5, #0xb87
    // 0x12f5ba8: b.ne            #0x12f5bbc
    // 0x12f5bac: ldur            x6, [fp, #-0x20]
    // 0x12f5bb0: LoadField: r2 = r6->field_f
    //     0x12f5bb0: ldur            w2, [x6, #0xf]
    // 0x12f5bb4: DecompressPointer r2
    //     0x12f5bb4: add             x2, x2, HEAP, lsl #32
    // 0x12f5bb8: b               #0x12f5bdc
    // 0x12f5bbc: ldur            x6, [fp, #-0x20]
    // 0x12f5bc0: cmp             x5, #0xb88
    // 0x12f5bc4: b.ne            #0x12f5bd4
    // 0x12f5bc8: r2 = Instance_Radius
    //     0x12f5bc8: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5bcc: ldr             x2, [x2, #0x1a0]
    // 0x12f5bd0: b               #0x12f5bdc
    // 0x12f5bd4: LoadField: r2 = r6->field_f
    //     0x12f5bd4: ldur            w2, [x6, #0xf]
    // 0x12f5bd8: DecompressPointer r2
    //     0x12f5bd8: add             x2, x2, HEAP, lsl #32
    // 0x12f5bdc: r0 = +()
    //     0x12f5bdc: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5be0: mov             x3, x0
    // 0x12f5be4: ldur            x0, [fp, #-0x10]
    // 0x12f5be8: stur            x3, [fp, #-0x38]
    // 0x12f5bec: cmp             x0, #0xb87
    // 0x12f5bf0: b.ne            #0x12f5c04
    // 0x12f5bf4: ldur            x4, [fp, #-0x18]
    // 0x12f5bf8: LoadField: r1 = r4->field_13
    //     0x12f5bf8: ldur            w1, [x4, #0x13]
    // 0x12f5bfc: DecompressPointer r1
    //     0x12f5bfc: add             x1, x1, HEAP, lsl #32
    // 0x12f5c00: b               #0x12f5c24
    // 0x12f5c04: ldur            x4, [fp, #-0x18]
    // 0x12f5c08: cmp             x0, #0xb88
    // 0x12f5c0c: b.ne            #0x12f5c1c
    // 0x12f5c10: r1 = Instance_Radius
    //     0x12f5c10: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5c14: ldr             x1, [x1, #0x1a0]
    // 0x12f5c18: b               #0x12f5c24
    // 0x12f5c1c: LoadField: r1 = r4->field_13
    //     0x12f5c1c: ldur            w1, [x4, #0x13]
    // 0x12f5c20: DecompressPointer r1
    //     0x12f5c20: add             x1, x1, HEAP, lsl #32
    // 0x12f5c24: ldur            x5, [fp, #-8]
    // 0x12f5c28: cmp             x5, #0xb87
    // 0x12f5c2c: b.ne            #0x12f5c40
    // 0x12f5c30: ldur            x6, [fp, #-0x20]
    // 0x12f5c34: LoadField: r2 = r6->field_13
    //     0x12f5c34: ldur            w2, [x6, #0x13]
    // 0x12f5c38: DecompressPointer r2
    //     0x12f5c38: add             x2, x2, HEAP, lsl #32
    // 0x12f5c3c: b               #0x12f5c60
    // 0x12f5c40: ldur            x6, [fp, #-0x20]
    // 0x12f5c44: cmp             x5, #0xb88
    // 0x12f5c48: b.ne            #0x12f5c58
    // 0x12f5c4c: r2 = Instance_Radius
    //     0x12f5c4c: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5c50: ldr             x2, [x2, #0x1a0]
    // 0x12f5c54: b               #0x12f5c60
    // 0x12f5c58: LoadField: r2 = r6->field_13
    //     0x12f5c58: ldur            w2, [x6, #0x13]
    // 0x12f5c5c: DecompressPointer r2
    //     0x12f5c5c: add             x2, x2, HEAP, lsl #32
    // 0x12f5c60: r0 = +()
    //     0x12f5c60: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5c64: mov             x3, x0
    // 0x12f5c68: ldur            x0, [fp, #-0x10]
    // 0x12f5c6c: stur            x3, [fp, #-0x40]
    // 0x12f5c70: cmp             x0, #0xb87
    // 0x12f5c74: b.ne            #0x12f5c88
    // 0x12f5c78: ldur            x4, [fp, #-0x18]
    // 0x12f5c7c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x12f5c7c: ldur            w1, [x4, #0x17]
    // 0x12f5c80: DecompressPointer r1
    //     0x12f5c80: add             x1, x1, HEAP, lsl #32
    // 0x12f5c84: b               #0x12f5ca8
    // 0x12f5c88: ldur            x4, [fp, #-0x18]
    // 0x12f5c8c: cmp             x0, #0xb88
    // 0x12f5c90: b.ne            #0x12f5ca0
    // 0x12f5c94: LoadField: r1 = r4->field_7
    //     0x12f5c94: ldur            w1, [x4, #7]
    // 0x12f5c98: DecompressPointer r1
    //     0x12f5c98: add             x1, x1, HEAP, lsl #32
    // 0x12f5c9c: b               #0x12f5ca8
    // 0x12f5ca0: r1 = Instance_Radius
    //     0x12f5ca0: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5ca4: ldr             x1, [x1, #0x1a0]
    // 0x12f5ca8: ldur            x5, [fp, #-8]
    // 0x12f5cac: cmp             x5, #0xb87
    // 0x12f5cb0: b.ne            #0x12f5cc4
    // 0x12f5cb4: ldur            x6, [fp, #-0x20]
    // 0x12f5cb8: ArrayLoad: r2 = r6[0]  ; List_4
    //     0x12f5cb8: ldur            w2, [x6, #0x17]
    // 0x12f5cbc: DecompressPointer r2
    //     0x12f5cbc: add             x2, x2, HEAP, lsl #32
    // 0x12f5cc0: b               #0x12f5ce4
    // 0x12f5cc4: ldur            x6, [fp, #-0x20]
    // 0x12f5cc8: cmp             x5, #0xb88
    // 0x12f5ccc: b.ne            #0x12f5cdc
    // 0x12f5cd0: LoadField: r2 = r6->field_7
    //     0x12f5cd0: ldur            w2, [x6, #7]
    // 0x12f5cd4: DecompressPointer r2
    //     0x12f5cd4: add             x2, x2, HEAP, lsl #32
    // 0x12f5cd8: b               #0x12f5ce4
    // 0x12f5cdc: r2 = Instance_Radius
    //     0x12f5cdc: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5ce0: ldr             x2, [x2, #0x1a0]
    // 0x12f5ce4: r0 = +()
    //     0x12f5ce4: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5ce8: mov             x3, x0
    // 0x12f5cec: ldur            x0, [fp, #-0x10]
    // 0x12f5cf0: stur            x3, [fp, #-0x48]
    // 0x12f5cf4: cmp             x0, #0xb87
    // 0x12f5cf8: b.ne            #0x12f5d0c
    // 0x12f5cfc: ldur            x4, [fp, #-0x18]
    // 0x12f5d00: LoadField: r1 = r4->field_1b
    //     0x12f5d00: ldur            w1, [x4, #0x1b]
    // 0x12f5d04: DecompressPointer r1
    //     0x12f5d04: add             x1, x1, HEAP, lsl #32
    // 0x12f5d08: b               #0x12f5d2c
    // 0x12f5d0c: ldur            x4, [fp, #-0x18]
    // 0x12f5d10: cmp             x0, #0xb88
    // 0x12f5d14: b.ne            #0x12f5d24
    // 0x12f5d18: LoadField: r1 = r4->field_b
    //     0x12f5d18: ldur            w1, [x4, #0xb]
    // 0x12f5d1c: DecompressPointer r1
    //     0x12f5d1c: add             x1, x1, HEAP, lsl #32
    // 0x12f5d20: b               #0x12f5d2c
    // 0x12f5d24: r1 = Instance_Radius
    //     0x12f5d24: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5d28: ldr             x1, [x1, #0x1a0]
    // 0x12f5d2c: ldur            x5, [fp, #-8]
    // 0x12f5d30: cmp             x5, #0xb87
    // 0x12f5d34: b.ne            #0x12f5d48
    // 0x12f5d38: ldur            x6, [fp, #-0x20]
    // 0x12f5d3c: LoadField: r2 = r6->field_1b
    //     0x12f5d3c: ldur            w2, [x6, #0x1b]
    // 0x12f5d40: DecompressPointer r2
    //     0x12f5d40: add             x2, x2, HEAP, lsl #32
    // 0x12f5d44: b               #0x12f5d68
    // 0x12f5d48: ldur            x6, [fp, #-0x20]
    // 0x12f5d4c: cmp             x5, #0xb88
    // 0x12f5d50: b.ne            #0x12f5d60
    // 0x12f5d54: LoadField: r2 = r6->field_b
    //     0x12f5d54: ldur            w2, [x6, #0xb]
    // 0x12f5d58: DecompressPointer r2
    //     0x12f5d58: add             x2, x2, HEAP, lsl #32
    // 0x12f5d5c: b               #0x12f5d68
    // 0x12f5d60: r2 = Instance_Radius
    //     0x12f5d60: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5d64: ldr             x2, [x2, #0x1a0]
    // 0x12f5d68: r0 = +()
    //     0x12f5d68: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5d6c: mov             x3, x0
    // 0x12f5d70: ldur            x0, [fp, #-0x10]
    // 0x12f5d74: stur            x3, [fp, #-0x50]
    // 0x12f5d78: cmp             x0, #0xb87
    // 0x12f5d7c: b.ne            #0x12f5d90
    // 0x12f5d80: ldur            x4, [fp, #-0x18]
    // 0x12f5d84: LoadField: r1 = r4->field_1f
    //     0x12f5d84: ldur            w1, [x4, #0x1f]
    // 0x12f5d88: DecompressPointer r1
    //     0x12f5d88: add             x1, x1, HEAP, lsl #32
    // 0x12f5d8c: b               #0x12f5db0
    // 0x12f5d90: ldur            x4, [fp, #-0x18]
    // 0x12f5d94: cmp             x0, #0xb88
    // 0x12f5d98: b.ne            #0x12f5da8
    // 0x12f5d9c: LoadField: r1 = r4->field_f
    //     0x12f5d9c: ldur            w1, [x4, #0xf]
    // 0x12f5da0: DecompressPointer r1
    //     0x12f5da0: add             x1, x1, HEAP, lsl #32
    // 0x12f5da4: b               #0x12f5db0
    // 0x12f5da8: r1 = Instance_Radius
    //     0x12f5da8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5dac: ldr             x1, [x1, #0x1a0]
    // 0x12f5db0: ldur            x5, [fp, #-8]
    // 0x12f5db4: cmp             x5, #0xb87
    // 0x12f5db8: b.ne            #0x12f5dcc
    // 0x12f5dbc: ldur            x6, [fp, #-0x20]
    // 0x12f5dc0: LoadField: r2 = r6->field_1f
    //     0x12f5dc0: ldur            w2, [x6, #0x1f]
    // 0x12f5dc4: DecompressPointer r2
    //     0x12f5dc4: add             x2, x2, HEAP, lsl #32
    // 0x12f5dc8: b               #0x12f5dec
    // 0x12f5dcc: ldur            x6, [fp, #-0x20]
    // 0x12f5dd0: cmp             x5, #0xb88
    // 0x12f5dd4: b.ne            #0x12f5de4
    // 0x12f5dd8: LoadField: r2 = r6->field_f
    //     0x12f5dd8: ldur            w2, [x6, #0xf]
    // 0x12f5ddc: DecompressPointer r2
    //     0x12f5ddc: add             x2, x2, HEAP, lsl #32
    // 0x12f5de0: b               #0x12f5dec
    // 0x12f5de4: r2 = Instance_Radius
    //     0x12f5de4: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5de8: ldr             x2, [x2, #0x1a0]
    // 0x12f5dec: r0 = +()
    //     0x12f5dec: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5df0: mov             x3, x0
    // 0x12f5df4: ldur            x0, [fp, #-0x10]
    // 0x12f5df8: stur            x3, [fp, #-0x58]
    // 0x12f5dfc: cmp             x0, #0xb87
    // 0x12f5e00: b.ne            #0x12f5e18
    // 0x12f5e04: ldur            x1, [fp, #-0x18]
    // 0x12f5e08: LoadField: r0 = r1->field_23
    //     0x12f5e08: ldur            w0, [x1, #0x23]
    // 0x12f5e0c: DecompressPointer r0
    //     0x12f5e0c: add             x0, x0, HEAP, lsl #32
    // 0x12f5e10: mov             x1, x0
    // 0x12f5e14: b               #0x12f5e3c
    // 0x12f5e18: ldur            x1, [fp, #-0x18]
    // 0x12f5e1c: cmp             x0, #0xb88
    // 0x12f5e20: b.ne            #0x12f5e34
    // 0x12f5e24: LoadField: r0 = r1->field_13
    //     0x12f5e24: ldur            w0, [x1, #0x13]
    // 0x12f5e28: DecompressPointer r0
    //     0x12f5e28: add             x0, x0, HEAP, lsl #32
    // 0x12f5e2c: mov             x1, x0
    // 0x12f5e30: b               #0x12f5e3c
    // 0x12f5e34: r1 = Instance_Radius
    //     0x12f5e34: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5e38: ldr             x1, [x1, #0x1a0]
    // 0x12f5e3c: ldur            x0, [fp, #-8]
    // 0x12f5e40: cmp             x0, #0xb87
    // 0x12f5e44: b.ne            #0x12f5e5c
    // 0x12f5e48: ldur            x2, [fp, #-0x20]
    // 0x12f5e4c: LoadField: r0 = r2->field_23
    //     0x12f5e4c: ldur            w0, [x2, #0x23]
    // 0x12f5e50: DecompressPointer r0
    //     0x12f5e50: add             x0, x0, HEAP, lsl #32
    // 0x12f5e54: mov             x2, x0
    // 0x12f5e58: b               #0x12f5e80
    // 0x12f5e5c: ldur            x2, [fp, #-0x20]
    // 0x12f5e60: cmp             x0, #0xb88
    // 0x12f5e64: b.ne            #0x12f5e78
    // 0x12f5e68: LoadField: r0 = r2->field_13
    //     0x12f5e68: ldur            w0, [x2, #0x13]
    // 0x12f5e6c: DecompressPointer r0
    //     0x12f5e6c: add             x0, x0, HEAP, lsl #32
    // 0x12f5e70: mov             x2, x0
    // 0x12f5e74: b               #0x12f5e80
    // 0x12f5e78: r2 = Instance_Radius
    //     0x12f5e78: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f5e7c: ldr             x2, [x2, #0x1a0]
    // 0x12f5e80: ldur            x8, [fp, #-0x28]
    // 0x12f5e84: ldur            x7, [fp, #-0x30]
    // 0x12f5e88: ldur            x6, [fp, #-0x38]
    // 0x12f5e8c: ldur            x5, [fp, #-0x40]
    // 0x12f5e90: ldur            x4, [fp, #-0x48]
    // 0x12f5e94: ldur            x0, [fp, #-0x50]
    // 0x12f5e98: r0 = +()
    //     0x12f5e98: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12f5e9c: stur            x0, [fp, #-0x18]
    // 0x12f5ea0: r0 = _MixedBorderRadius()
    //     0x12f5ea0: bl              #0x12f5ef8  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0x12f5ea4: ldur            x1, [fp, #-0x28]
    // 0x12f5ea8: StoreField: r0->field_7 = r1
    //     0x12f5ea8: stur            w1, [x0, #7]
    // 0x12f5eac: ldur            x1, [fp, #-0x30]
    // 0x12f5eb0: StoreField: r0->field_b = r1
    //     0x12f5eb0: stur            w1, [x0, #0xb]
    // 0x12f5eb4: ldur            x1, [fp, #-0x38]
    // 0x12f5eb8: StoreField: r0->field_f = r1
    //     0x12f5eb8: stur            w1, [x0, #0xf]
    // 0x12f5ebc: ldur            x1, [fp, #-0x40]
    // 0x12f5ec0: StoreField: r0->field_13 = r1
    //     0x12f5ec0: stur            w1, [x0, #0x13]
    // 0x12f5ec4: ldur            x1, [fp, #-0x48]
    // 0x12f5ec8: ArrayStore: r0[0] = r1  ; List_4
    //     0x12f5ec8: stur            w1, [x0, #0x17]
    // 0x12f5ecc: ldur            x1, [fp, #-0x50]
    // 0x12f5ed0: StoreField: r0->field_1b = r1
    //     0x12f5ed0: stur            w1, [x0, #0x1b]
    // 0x12f5ed4: ldur            x1, [fp, #-0x58]
    // 0x12f5ed8: StoreField: r0->field_1f = r1
    //     0x12f5ed8: stur            w1, [x0, #0x1f]
    // 0x12f5edc: ldur            x1, [fp, #-0x18]
    // 0x12f5ee0: StoreField: r0->field_23 = r1
    //     0x12f5ee0: stur            w1, [x0, #0x23]
    // 0x12f5ee4: LeaveFrame
    //     0x12f5ee4: mov             SP, fp
    //     0x12f5ee8: ldp             fp, lr, [SP], #0x10
    // 0x12f5eec: ret
    //     0x12f5eec: ret             
    // 0x12f5ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f5ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f5ef4: b               #0x12f5a5c
  }
  _ subtract(/* No info */) {
    // ** addr: 0x12f6024, size: 0x4c4
    // 0x12f6024: EnterFrame
    //     0x12f6024: stp             fp, lr, [SP, #-0x10]!
    //     0x12f6028: mov             fp, SP
    // 0x12f602c: AllocStack(0x58)
    //     0x12f602c: sub             SP, SP, #0x58
    // 0x12f6030: SetupParameters(BorderRadiusGeometry this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x12f6030: mov             x3, x1
    //     0x12f6034: mov             x0, x2
    //     0x12f6038: stur            x1, [fp, #-0x18]
    //     0x12f603c: stur            x2, [fp, #-0x20]
    // 0x12f6040: CheckStackOverflow
    //     0x12f6040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f6044: cmp             SP, x16
    //     0x12f6048: b.ls            #0x12f64e0
    // 0x12f604c: r4 = LoadClassIdInstr(r3)
    //     0x12f604c: ldur            x4, [x3, #-1]
    //     0x12f6050: ubfx            x4, x4, #0xc, #0x14
    // 0x12f6054: stur            x4, [fp, #-0x10]
    // 0x12f6058: cmp             x4, #0xb87
    // 0x12f605c: b.ne            #0x12f606c
    // 0x12f6060: LoadField: r1 = r3->field_7
    //     0x12f6060: ldur            w1, [x3, #7]
    // 0x12f6064: DecompressPointer r1
    //     0x12f6064: add             x1, x1, HEAP, lsl #32
    // 0x12f6068: b               #0x12f6088
    // 0x12f606c: cmp             x4, #0xb88
    // 0x12f6070: b.ne            #0x12f6080
    // 0x12f6074: r1 = Instance_Radius
    //     0x12f6074: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6078: ldr             x1, [x1, #0x1a0]
    // 0x12f607c: b               #0x12f6088
    // 0x12f6080: LoadField: r1 = r3->field_7
    //     0x12f6080: ldur            w1, [x3, #7]
    // 0x12f6084: DecompressPointer r1
    //     0x12f6084: add             x1, x1, HEAP, lsl #32
    // 0x12f6088: r5 = LoadClassIdInstr(r0)
    //     0x12f6088: ldur            x5, [x0, #-1]
    //     0x12f608c: ubfx            x5, x5, #0xc, #0x14
    // 0x12f6090: stur            x5, [fp, #-8]
    // 0x12f6094: cmp             x5, #0xb87
    // 0x12f6098: b.ne            #0x12f60a8
    // 0x12f609c: LoadField: r2 = r0->field_7
    //     0x12f609c: ldur            w2, [x0, #7]
    // 0x12f60a0: DecompressPointer r2
    //     0x12f60a0: add             x2, x2, HEAP, lsl #32
    // 0x12f60a4: b               #0x12f60c4
    // 0x12f60a8: cmp             x5, #0xb88
    // 0x12f60ac: b.ne            #0x12f60bc
    // 0x12f60b0: r2 = Instance_Radius
    //     0x12f60b0: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f60b4: ldr             x2, [x2, #0x1a0]
    // 0x12f60b8: b               #0x12f60c4
    // 0x12f60bc: LoadField: r2 = r0->field_7
    //     0x12f60bc: ldur            w2, [x0, #7]
    // 0x12f60c0: DecompressPointer r2
    //     0x12f60c0: add             x2, x2, HEAP, lsl #32
    // 0x12f60c4: r0 = -()
    //     0x12f60c4: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f60c8: mov             x3, x0
    // 0x12f60cc: ldur            x0, [fp, #-0x10]
    // 0x12f60d0: stur            x3, [fp, #-0x28]
    // 0x12f60d4: cmp             x0, #0xb87
    // 0x12f60d8: b.ne            #0x12f60ec
    // 0x12f60dc: ldur            x4, [fp, #-0x18]
    // 0x12f60e0: LoadField: r1 = r4->field_b
    //     0x12f60e0: ldur            w1, [x4, #0xb]
    // 0x12f60e4: DecompressPointer r1
    //     0x12f60e4: add             x1, x1, HEAP, lsl #32
    // 0x12f60e8: b               #0x12f610c
    // 0x12f60ec: ldur            x4, [fp, #-0x18]
    // 0x12f60f0: cmp             x0, #0xb88
    // 0x12f60f4: b.ne            #0x12f6104
    // 0x12f60f8: r1 = Instance_Radius
    //     0x12f60f8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f60fc: ldr             x1, [x1, #0x1a0]
    // 0x12f6100: b               #0x12f610c
    // 0x12f6104: LoadField: r1 = r4->field_b
    //     0x12f6104: ldur            w1, [x4, #0xb]
    // 0x12f6108: DecompressPointer r1
    //     0x12f6108: add             x1, x1, HEAP, lsl #32
    // 0x12f610c: ldur            x5, [fp, #-8]
    // 0x12f6110: cmp             x5, #0xb87
    // 0x12f6114: b.ne            #0x12f6128
    // 0x12f6118: ldur            x6, [fp, #-0x20]
    // 0x12f611c: LoadField: r2 = r6->field_b
    //     0x12f611c: ldur            w2, [x6, #0xb]
    // 0x12f6120: DecompressPointer r2
    //     0x12f6120: add             x2, x2, HEAP, lsl #32
    // 0x12f6124: b               #0x12f6148
    // 0x12f6128: ldur            x6, [fp, #-0x20]
    // 0x12f612c: cmp             x5, #0xb88
    // 0x12f6130: b.ne            #0x12f6140
    // 0x12f6134: r2 = Instance_Radius
    //     0x12f6134: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6138: ldr             x2, [x2, #0x1a0]
    // 0x12f613c: b               #0x12f6148
    // 0x12f6140: LoadField: r2 = r6->field_b
    //     0x12f6140: ldur            w2, [x6, #0xb]
    // 0x12f6144: DecompressPointer r2
    //     0x12f6144: add             x2, x2, HEAP, lsl #32
    // 0x12f6148: r0 = -()
    //     0x12f6148: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f614c: mov             x3, x0
    // 0x12f6150: ldur            x0, [fp, #-0x10]
    // 0x12f6154: stur            x3, [fp, #-0x30]
    // 0x12f6158: cmp             x0, #0xb87
    // 0x12f615c: b.ne            #0x12f6170
    // 0x12f6160: ldur            x4, [fp, #-0x18]
    // 0x12f6164: LoadField: r1 = r4->field_f
    //     0x12f6164: ldur            w1, [x4, #0xf]
    // 0x12f6168: DecompressPointer r1
    //     0x12f6168: add             x1, x1, HEAP, lsl #32
    // 0x12f616c: b               #0x12f6190
    // 0x12f6170: ldur            x4, [fp, #-0x18]
    // 0x12f6174: cmp             x0, #0xb88
    // 0x12f6178: b.ne            #0x12f6188
    // 0x12f617c: r1 = Instance_Radius
    //     0x12f617c: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6180: ldr             x1, [x1, #0x1a0]
    // 0x12f6184: b               #0x12f6190
    // 0x12f6188: LoadField: r1 = r4->field_f
    //     0x12f6188: ldur            w1, [x4, #0xf]
    // 0x12f618c: DecompressPointer r1
    //     0x12f618c: add             x1, x1, HEAP, lsl #32
    // 0x12f6190: ldur            x5, [fp, #-8]
    // 0x12f6194: cmp             x5, #0xb87
    // 0x12f6198: b.ne            #0x12f61ac
    // 0x12f619c: ldur            x6, [fp, #-0x20]
    // 0x12f61a0: LoadField: r2 = r6->field_f
    //     0x12f61a0: ldur            w2, [x6, #0xf]
    // 0x12f61a4: DecompressPointer r2
    //     0x12f61a4: add             x2, x2, HEAP, lsl #32
    // 0x12f61a8: b               #0x12f61cc
    // 0x12f61ac: ldur            x6, [fp, #-0x20]
    // 0x12f61b0: cmp             x5, #0xb88
    // 0x12f61b4: b.ne            #0x12f61c4
    // 0x12f61b8: r2 = Instance_Radius
    //     0x12f61b8: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f61bc: ldr             x2, [x2, #0x1a0]
    // 0x12f61c0: b               #0x12f61cc
    // 0x12f61c4: LoadField: r2 = r6->field_f
    //     0x12f61c4: ldur            w2, [x6, #0xf]
    // 0x12f61c8: DecompressPointer r2
    //     0x12f61c8: add             x2, x2, HEAP, lsl #32
    // 0x12f61cc: r0 = -()
    //     0x12f61cc: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f61d0: mov             x3, x0
    // 0x12f61d4: ldur            x0, [fp, #-0x10]
    // 0x12f61d8: stur            x3, [fp, #-0x38]
    // 0x12f61dc: cmp             x0, #0xb87
    // 0x12f61e0: b.ne            #0x12f61f4
    // 0x12f61e4: ldur            x4, [fp, #-0x18]
    // 0x12f61e8: LoadField: r1 = r4->field_13
    //     0x12f61e8: ldur            w1, [x4, #0x13]
    // 0x12f61ec: DecompressPointer r1
    //     0x12f61ec: add             x1, x1, HEAP, lsl #32
    // 0x12f61f0: b               #0x12f6214
    // 0x12f61f4: ldur            x4, [fp, #-0x18]
    // 0x12f61f8: cmp             x0, #0xb88
    // 0x12f61fc: b.ne            #0x12f620c
    // 0x12f6200: r1 = Instance_Radius
    //     0x12f6200: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6204: ldr             x1, [x1, #0x1a0]
    // 0x12f6208: b               #0x12f6214
    // 0x12f620c: LoadField: r1 = r4->field_13
    //     0x12f620c: ldur            w1, [x4, #0x13]
    // 0x12f6210: DecompressPointer r1
    //     0x12f6210: add             x1, x1, HEAP, lsl #32
    // 0x12f6214: ldur            x5, [fp, #-8]
    // 0x12f6218: cmp             x5, #0xb87
    // 0x12f621c: b.ne            #0x12f6230
    // 0x12f6220: ldur            x6, [fp, #-0x20]
    // 0x12f6224: LoadField: r2 = r6->field_13
    //     0x12f6224: ldur            w2, [x6, #0x13]
    // 0x12f6228: DecompressPointer r2
    //     0x12f6228: add             x2, x2, HEAP, lsl #32
    // 0x12f622c: b               #0x12f6250
    // 0x12f6230: ldur            x6, [fp, #-0x20]
    // 0x12f6234: cmp             x5, #0xb88
    // 0x12f6238: b.ne            #0x12f6248
    // 0x12f623c: r2 = Instance_Radius
    //     0x12f623c: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6240: ldr             x2, [x2, #0x1a0]
    // 0x12f6244: b               #0x12f6250
    // 0x12f6248: LoadField: r2 = r6->field_13
    //     0x12f6248: ldur            w2, [x6, #0x13]
    // 0x12f624c: DecompressPointer r2
    //     0x12f624c: add             x2, x2, HEAP, lsl #32
    // 0x12f6250: r0 = -()
    //     0x12f6250: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f6254: mov             x3, x0
    // 0x12f6258: ldur            x0, [fp, #-0x10]
    // 0x12f625c: stur            x3, [fp, #-0x40]
    // 0x12f6260: cmp             x0, #0xb87
    // 0x12f6264: b.ne            #0x12f6278
    // 0x12f6268: ldur            x4, [fp, #-0x18]
    // 0x12f626c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x12f626c: ldur            w1, [x4, #0x17]
    // 0x12f6270: DecompressPointer r1
    //     0x12f6270: add             x1, x1, HEAP, lsl #32
    // 0x12f6274: b               #0x12f6298
    // 0x12f6278: ldur            x4, [fp, #-0x18]
    // 0x12f627c: cmp             x0, #0xb88
    // 0x12f6280: b.ne            #0x12f6290
    // 0x12f6284: LoadField: r1 = r4->field_7
    //     0x12f6284: ldur            w1, [x4, #7]
    // 0x12f6288: DecompressPointer r1
    //     0x12f6288: add             x1, x1, HEAP, lsl #32
    // 0x12f628c: b               #0x12f6298
    // 0x12f6290: r1 = Instance_Radius
    //     0x12f6290: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6294: ldr             x1, [x1, #0x1a0]
    // 0x12f6298: ldur            x5, [fp, #-8]
    // 0x12f629c: cmp             x5, #0xb87
    // 0x12f62a0: b.ne            #0x12f62b4
    // 0x12f62a4: ldur            x6, [fp, #-0x20]
    // 0x12f62a8: ArrayLoad: r2 = r6[0]  ; List_4
    //     0x12f62a8: ldur            w2, [x6, #0x17]
    // 0x12f62ac: DecompressPointer r2
    //     0x12f62ac: add             x2, x2, HEAP, lsl #32
    // 0x12f62b0: b               #0x12f62d4
    // 0x12f62b4: ldur            x6, [fp, #-0x20]
    // 0x12f62b8: cmp             x5, #0xb88
    // 0x12f62bc: b.ne            #0x12f62cc
    // 0x12f62c0: LoadField: r2 = r6->field_7
    //     0x12f62c0: ldur            w2, [x6, #7]
    // 0x12f62c4: DecompressPointer r2
    //     0x12f62c4: add             x2, x2, HEAP, lsl #32
    // 0x12f62c8: b               #0x12f62d4
    // 0x12f62cc: r2 = Instance_Radius
    //     0x12f62cc: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f62d0: ldr             x2, [x2, #0x1a0]
    // 0x12f62d4: r0 = -()
    //     0x12f62d4: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f62d8: mov             x3, x0
    // 0x12f62dc: ldur            x0, [fp, #-0x10]
    // 0x12f62e0: stur            x3, [fp, #-0x48]
    // 0x12f62e4: cmp             x0, #0xb87
    // 0x12f62e8: b.ne            #0x12f62fc
    // 0x12f62ec: ldur            x4, [fp, #-0x18]
    // 0x12f62f0: LoadField: r1 = r4->field_1b
    //     0x12f62f0: ldur            w1, [x4, #0x1b]
    // 0x12f62f4: DecompressPointer r1
    //     0x12f62f4: add             x1, x1, HEAP, lsl #32
    // 0x12f62f8: b               #0x12f631c
    // 0x12f62fc: ldur            x4, [fp, #-0x18]
    // 0x12f6300: cmp             x0, #0xb88
    // 0x12f6304: b.ne            #0x12f6314
    // 0x12f6308: LoadField: r1 = r4->field_b
    //     0x12f6308: ldur            w1, [x4, #0xb]
    // 0x12f630c: DecompressPointer r1
    //     0x12f630c: add             x1, x1, HEAP, lsl #32
    // 0x12f6310: b               #0x12f631c
    // 0x12f6314: r1 = Instance_Radius
    //     0x12f6314: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6318: ldr             x1, [x1, #0x1a0]
    // 0x12f631c: ldur            x5, [fp, #-8]
    // 0x12f6320: cmp             x5, #0xb87
    // 0x12f6324: b.ne            #0x12f6338
    // 0x12f6328: ldur            x6, [fp, #-0x20]
    // 0x12f632c: LoadField: r2 = r6->field_1b
    //     0x12f632c: ldur            w2, [x6, #0x1b]
    // 0x12f6330: DecompressPointer r2
    //     0x12f6330: add             x2, x2, HEAP, lsl #32
    // 0x12f6334: b               #0x12f6358
    // 0x12f6338: ldur            x6, [fp, #-0x20]
    // 0x12f633c: cmp             x5, #0xb88
    // 0x12f6340: b.ne            #0x12f6350
    // 0x12f6344: LoadField: r2 = r6->field_b
    //     0x12f6344: ldur            w2, [x6, #0xb]
    // 0x12f6348: DecompressPointer r2
    //     0x12f6348: add             x2, x2, HEAP, lsl #32
    // 0x12f634c: b               #0x12f6358
    // 0x12f6350: r2 = Instance_Radius
    //     0x12f6350: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6354: ldr             x2, [x2, #0x1a0]
    // 0x12f6358: r0 = -()
    //     0x12f6358: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f635c: mov             x3, x0
    // 0x12f6360: ldur            x0, [fp, #-0x10]
    // 0x12f6364: stur            x3, [fp, #-0x50]
    // 0x12f6368: cmp             x0, #0xb87
    // 0x12f636c: b.ne            #0x12f6380
    // 0x12f6370: ldur            x4, [fp, #-0x18]
    // 0x12f6374: LoadField: r1 = r4->field_1f
    //     0x12f6374: ldur            w1, [x4, #0x1f]
    // 0x12f6378: DecompressPointer r1
    //     0x12f6378: add             x1, x1, HEAP, lsl #32
    // 0x12f637c: b               #0x12f63a0
    // 0x12f6380: ldur            x4, [fp, #-0x18]
    // 0x12f6384: cmp             x0, #0xb88
    // 0x12f6388: b.ne            #0x12f6398
    // 0x12f638c: LoadField: r1 = r4->field_f
    //     0x12f638c: ldur            w1, [x4, #0xf]
    // 0x12f6390: DecompressPointer r1
    //     0x12f6390: add             x1, x1, HEAP, lsl #32
    // 0x12f6394: b               #0x12f63a0
    // 0x12f6398: r1 = Instance_Radius
    //     0x12f6398: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f639c: ldr             x1, [x1, #0x1a0]
    // 0x12f63a0: ldur            x5, [fp, #-8]
    // 0x12f63a4: cmp             x5, #0xb87
    // 0x12f63a8: b.ne            #0x12f63bc
    // 0x12f63ac: ldur            x6, [fp, #-0x20]
    // 0x12f63b0: LoadField: r2 = r6->field_1f
    //     0x12f63b0: ldur            w2, [x6, #0x1f]
    // 0x12f63b4: DecompressPointer r2
    //     0x12f63b4: add             x2, x2, HEAP, lsl #32
    // 0x12f63b8: b               #0x12f63dc
    // 0x12f63bc: ldur            x6, [fp, #-0x20]
    // 0x12f63c0: cmp             x5, #0xb88
    // 0x12f63c4: b.ne            #0x12f63d4
    // 0x12f63c8: LoadField: r2 = r6->field_f
    //     0x12f63c8: ldur            w2, [x6, #0xf]
    // 0x12f63cc: DecompressPointer r2
    //     0x12f63cc: add             x2, x2, HEAP, lsl #32
    // 0x12f63d0: b               #0x12f63dc
    // 0x12f63d4: r2 = Instance_Radius
    //     0x12f63d4: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f63d8: ldr             x2, [x2, #0x1a0]
    // 0x12f63dc: r0 = -()
    //     0x12f63dc: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f63e0: mov             x3, x0
    // 0x12f63e4: ldur            x0, [fp, #-0x10]
    // 0x12f63e8: stur            x3, [fp, #-0x58]
    // 0x12f63ec: cmp             x0, #0xb87
    // 0x12f63f0: b.ne            #0x12f6408
    // 0x12f63f4: ldur            x1, [fp, #-0x18]
    // 0x12f63f8: LoadField: r0 = r1->field_23
    //     0x12f63f8: ldur            w0, [x1, #0x23]
    // 0x12f63fc: DecompressPointer r0
    //     0x12f63fc: add             x0, x0, HEAP, lsl #32
    // 0x12f6400: mov             x1, x0
    // 0x12f6404: b               #0x12f642c
    // 0x12f6408: ldur            x1, [fp, #-0x18]
    // 0x12f640c: cmp             x0, #0xb88
    // 0x12f6410: b.ne            #0x12f6424
    // 0x12f6414: LoadField: r0 = r1->field_13
    //     0x12f6414: ldur            w0, [x1, #0x13]
    // 0x12f6418: DecompressPointer r0
    //     0x12f6418: add             x0, x0, HEAP, lsl #32
    // 0x12f641c: mov             x1, x0
    // 0x12f6420: b               #0x12f642c
    // 0x12f6424: r1 = Instance_Radius
    //     0x12f6424: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f6428: ldr             x1, [x1, #0x1a0]
    // 0x12f642c: ldur            x0, [fp, #-8]
    // 0x12f6430: cmp             x0, #0xb87
    // 0x12f6434: b.ne            #0x12f644c
    // 0x12f6438: ldur            x2, [fp, #-0x20]
    // 0x12f643c: LoadField: r0 = r2->field_23
    //     0x12f643c: ldur            w0, [x2, #0x23]
    // 0x12f6440: DecompressPointer r0
    //     0x12f6440: add             x0, x0, HEAP, lsl #32
    // 0x12f6444: mov             x2, x0
    // 0x12f6448: b               #0x12f6470
    // 0x12f644c: ldur            x2, [fp, #-0x20]
    // 0x12f6450: cmp             x0, #0xb88
    // 0x12f6454: b.ne            #0x12f6468
    // 0x12f6458: LoadField: r0 = r2->field_13
    //     0x12f6458: ldur            w0, [x2, #0x13]
    // 0x12f645c: DecompressPointer r0
    //     0x12f645c: add             x0, x0, HEAP, lsl #32
    // 0x12f6460: mov             x2, x0
    // 0x12f6464: b               #0x12f6470
    // 0x12f6468: r2 = Instance_Radius
    //     0x12f6468: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12f646c: ldr             x2, [x2, #0x1a0]
    // 0x12f6470: ldur            x8, [fp, #-0x28]
    // 0x12f6474: ldur            x7, [fp, #-0x30]
    // 0x12f6478: ldur            x6, [fp, #-0x38]
    // 0x12f647c: ldur            x5, [fp, #-0x40]
    // 0x12f6480: ldur            x4, [fp, #-0x48]
    // 0x12f6484: ldur            x0, [fp, #-0x50]
    // 0x12f6488: r0 = -()
    //     0x12f6488: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12f648c: stur            x0, [fp, #-0x18]
    // 0x12f6490: r0 = _MixedBorderRadius()
    //     0x12f6490: bl              #0x12f5ef8  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0x12f6494: ldur            x1, [fp, #-0x28]
    // 0x12f6498: StoreField: r0->field_7 = r1
    //     0x12f6498: stur            w1, [x0, #7]
    // 0x12f649c: ldur            x1, [fp, #-0x30]
    // 0x12f64a0: StoreField: r0->field_b = r1
    //     0x12f64a0: stur            w1, [x0, #0xb]
    // 0x12f64a4: ldur            x1, [fp, #-0x38]
    // 0x12f64a8: StoreField: r0->field_f = r1
    //     0x12f64a8: stur            w1, [x0, #0xf]
    // 0x12f64ac: ldur            x1, [fp, #-0x40]
    // 0x12f64b0: StoreField: r0->field_13 = r1
    //     0x12f64b0: stur            w1, [x0, #0x13]
    // 0x12f64b4: ldur            x1, [fp, #-0x48]
    // 0x12f64b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x12f64b8: stur            w1, [x0, #0x17]
    // 0x12f64bc: ldur            x1, [fp, #-0x50]
    // 0x12f64c0: StoreField: r0->field_1b = r1
    //     0x12f64c0: stur            w1, [x0, #0x1b]
    // 0x12f64c4: ldur            x1, [fp, #-0x58]
    // 0x12f64c8: StoreField: r0->field_1f = r1
    //     0x12f64c8: stur            w1, [x0, #0x1f]
    // 0x12f64cc: ldur            x1, [fp, #-0x18]
    // 0x12f64d0: StoreField: r0->field_23 = r1
    //     0x12f64d0: stur            w1, [x0, #0x23]
    // 0x12f64d4: LeaveFrame
    //     0x12f64d4: mov             SP, fp
    //     0x12f64d8: ldp             fp, lr, [SP], #0x10
    // 0x12f64dc: ret
    //     0x12f64dc: ret             
    // 0x12f64e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f64e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f64e4: b               #0x12f604c
  }
}

// class id: 2951, size: 0x28, field offset: 0x8
//   const constructor, 
class _MixedBorderRadius extends BorderRadiusGeometry {

  BorderRadius resolve(_MixedBorderRadius, TextDirection?) {
    // ** addr: 0x12f5f1c, size: 0x88
    // 0x12f5f1c: EnterFrame
    //     0x12f5f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f5f20: mov             fp, SP
    // 0x12f5f24: CheckStackOverflow
    //     0x12f5f24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f5f28: cmp             SP, x16
    //     0x12f5f2c: b.ls            #0x12f5f84
    // 0x12f5f30: ldr             x0, [fp, #0x10]
    // 0x12f5f34: r2 = Null
    //     0x12f5f34: mov             x2, NULL
    // 0x12f5f38: r1 = Null
    //     0x12f5f38: mov             x1, NULL
    // 0x12f5f3c: r4 = 60
    //     0x12f5f3c: mov             x4, #0x3c
    // 0x12f5f40: branchIfSmi(r0, 0x12f5f4c)
    //     0x12f5f40: tbz             w0, #0, #0x12f5f4c
    // 0x12f5f44: r4 = LoadClassIdInstr(r0)
    //     0x12f5f44: ldur            x4, [x0, #-1]
    //     0x12f5f48: ubfx            x4, x4, #0xc, #0x14
    // 0x12f5f4c: r17 = 8353
    //     0x12f5f4c: mov             x17, #0x20a1
    // 0x12f5f50: cmp             x4, x17
    // 0x12f5f54: b.eq            #0x12f5f6c
    // 0x12f5f58: r8 = TextDirection?
    //     0x12f5f58: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0x12f5f5c: ldr             x8, [x8, #0x750]
    // 0x12f5f60: r3 = Null
    //     0x12f5f60: add             x3, PP, #0xac, lsl #12  ; [pp+0xacdc0] Null
    //     0x12f5f64: ldr             x3, [x3, #0xdc0]
    // 0x12f5f68: r0 = DefaultNullableTypeTest()
    //     0x12f5f68: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x12f5f6c: ldr             x1, [fp, #0x18]
    // 0x12f5f70: ldr             x2, [fp, #0x10]
    // 0x12f5f74: r0 = resolve()
    //     0x12f5f74: bl              #0x1304d64  ; [package:flutter/src/painting/border_radius.dart] _MixedBorderRadius::resolve
    // 0x12f5f78: LeaveFrame
    //     0x12f5f78: mov             SP, fp
    //     0x12f5f7c: ldp             fp, lr, [SP], #0x10
    // 0x12f5f80: ret
    //     0x12f5f80: ret             
    // 0x12f5f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f5f84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f5f88: b               #0x12f5f30
  }
  _ *(/* No info */) {
    // ** addr: 0x1301e44, size: 0x158
    // 0x1301e44: EnterFrame
    //     0x1301e44: stp             fp, lr, [SP, #-0x10]!
    //     0x1301e48: mov             fp, SP
    // 0x1301e4c: AllocStack(0x48)
    //     0x1301e4c: sub             SP, SP, #0x48
    // 0x1301e50: SetupParameters(_MixedBorderRadius this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x48 */)
    //     0x1301e50: mov             x0, x1
    //     0x1301e54: mov             v1.16b, v0.16b
    //     0x1301e58: stur            x1, [fp, #-8]
    //     0x1301e5c: stur            d0, [fp, #-0x48]
    // 0x1301e60: CheckStackOverflow
    //     0x1301e60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1301e64: cmp             SP, x16
    //     0x1301e68: b.ls            #0x1301f94
    // 0x1301e6c: LoadField: r1 = r0->field_7
    //     0x1301e6c: ldur            w1, [x0, #7]
    // 0x1301e70: DecompressPointer r1
    //     0x1301e70: add             x1, x1, HEAP, lsl #32
    // 0x1301e74: mov             v0.16b, v1.16b
    // 0x1301e78: r0 = *()
    //     0x1301e78: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301e7c: mov             x2, x0
    // 0x1301e80: ldur            x0, [fp, #-8]
    // 0x1301e84: stur            x2, [fp, #-0x10]
    // 0x1301e88: LoadField: r1 = r0->field_b
    //     0x1301e88: ldur            w1, [x0, #0xb]
    // 0x1301e8c: DecompressPointer r1
    //     0x1301e8c: add             x1, x1, HEAP, lsl #32
    // 0x1301e90: ldur            d0, [fp, #-0x48]
    // 0x1301e94: r0 = *()
    //     0x1301e94: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301e98: mov             x2, x0
    // 0x1301e9c: ldur            x0, [fp, #-8]
    // 0x1301ea0: stur            x2, [fp, #-0x18]
    // 0x1301ea4: LoadField: r1 = r0->field_f
    //     0x1301ea4: ldur            w1, [x0, #0xf]
    // 0x1301ea8: DecompressPointer r1
    //     0x1301ea8: add             x1, x1, HEAP, lsl #32
    // 0x1301eac: ldur            d0, [fp, #-0x48]
    // 0x1301eb0: r0 = *()
    //     0x1301eb0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301eb4: mov             x2, x0
    // 0x1301eb8: ldur            x0, [fp, #-8]
    // 0x1301ebc: stur            x2, [fp, #-0x20]
    // 0x1301ec0: LoadField: r1 = r0->field_13
    //     0x1301ec0: ldur            w1, [x0, #0x13]
    // 0x1301ec4: DecompressPointer r1
    //     0x1301ec4: add             x1, x1, HEAP, lsl #32
    // 0x1301ec8: ldur            d0, [fp, #-0x48]
    // 0x1301ecc: r0 = *()
    //     0x1301ecc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301ed0: mov             x2, x0
    // 0x1301ed4: ldur            x0, [fp, #-8]
    // 0x1301ed8: stur            x2, [fp, #-0x28]
    // 0x1301edc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1301edc: ldur            w1, [x0, #0x17]
    // 0x1301ee0: DecompressPointer r1
    //     0x1301ee0: add             x1, x1, HEAP, lsl #32
    // 0x1301ee4: ldur            d0, [fp, #-0x48]
    // 0x1301ee8: r0 = *()
    //     0x1301ee8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301eec: mov             x2, x0
    // 0x1301ef0: ldur            x0, [fp, #-8]
    // 0x1301ef4: stur            x2, [fp, #-0x30]
    // 0x1301ef8: LoadField: r1 = r0->field_1b
    //     0x1301ef8: ldur            w1, [x0, #0x1b]
    // 0x1301efc: DecompressPointer r1
    //     0x1301efc: add             x1, x1, HEAP, lsl #32
    // 0x1301f00: ldur            d0, [fp, #-0x48]
    // 0x1301f04: r0 = *()
    //     0x1301f04: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301f08: mov             x2, x0
    // 0x1301f0c: ldur            x0, [fp, #-8]
    // 0x1301f10: stur            x2, [fp, #-0x38]
    // 0x1301f14: LoadField: r1 = r0->field_1f
    //     0x1301f14: ldur            w1, [x0, #0x1f]
    // 0x1301f18: DecompressPointer r1
    //     0x1301f18: add             x1, x1, HEAP, lsl #32
    // 0x1301f1c: ldur            d0, [fp, #-0x48]
    // 0x1301f20: r0 = *()
    //     0x1301f20: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301f24: mov             x2, x0
    // 0x1301f28: ldur            x0, [fp, #-8]
    // 0x1301f2c: stur            x2, [fp, #-0x40]
    // 0x1301f30: LoadField: r1 = r0->field_23
    //     0x1301f30: ldur            w1, [x0, #0x23]
    // 0x1301f34: DecompressPointer r1
    //     0x1301f34: add             x1, x1, HEAP, lsl #32
    // 0x1301f38: ldur            d0, [fp, #-0x48]
    // 0x1301f3c: r0 = *()
    //     0x1301f3c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301f40: stur            x0, [fp, #-8]
    // 0x1301f44: r0 = _MixedBorderRadius()
    //     0x1301f44: bl              #0x12f5ef8  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0x1301f48: ldur            x1, [fp, #-0x10]
    // 0x1301f4c: StoreField: r0->field_7 = r1
    //     0x1301f4c: stur            w1, [x0, #7]
    // 0x1301f50: ldur            x1, [fp, #-0x18]
    // 0x1301f54: StoreField: r0->field_b = r1
    //     0x1301f54: stur            w1, [x0, #0xb]
    // 0x1301f58: ldur            x1, [fp, #-0x20]
    // 0x1301f5c: StoreField: r0->field_f = r1
    //     0x1301f5c: stur            w1, [x0, #0xf]
    // 0x1301f60: ldur            x1, [fp, #-0x28]
    // 0x1301f64: StoreField: r0->field_13 = r1
    //     0x1301f64: stur            w1, [x0, #0x13]
    // 0x1301f68: ldur            x1, [fp, #-0x30]
    // 0x1301f6c: ArrayStore: r0[0] = r1  ; List_4
    //     0x1301f6c: stur            w1, [x0, #0x17]
    // 0x1301f70: ldur            x1, [fp, #-0x38]
    // 0x1301f74: StoreField: r0->field_1b = r1
    //     0x1301f74: stur            w1, [x0, #0x1b]
    // 0x1301f78: ldur            x1, [fp, #-0x40]
    // 0x1301f7c: StoreField: r0->field_1f = r1
    //     0x1301f7c: stur            w1, [x0, #0x1f]
    // 0x1301f80: ldur            x1, [fp, #-8]
    // 0x1301f84: StoreField: r0->field_23 = r1
    //     0x1301f84: stur            w1, [x0, #0x23]
    // 0x1301f88: LeaveFrame
    //     0x1301f88: mov             SP, fp
    //     0x1301f8c: ldp             fp, lr, [SP], #0x10
    // 0x1301f90: ret
    //     0x1301f90: ret             
    // 0x1301f94: r0 = StackOverflowSharedWithFPURegs()
    //     0x1301f94: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1301f98: b               #0x1301e6c
  }
  BorderRadius resolve(_MixedBorderRadius, TextDirection?) {
    // ** addr: 0x1304d64, size: 0x198
    // 0x1304d64: EnterFrame
    //     0x1304d64: stp             fp, lr, [SP, #-0x10]!
    //     0x1304d68: mov             fp, SP
    // 0x1304d6c: AllocStack(0x28)
    //     0x1304d6c: sub             SP, SP, #0x28
    // 0x1304d70: SetupParameters(_MixedBorderRadius this /* r1 => r0, fp-0x8 */)
    //     0x1304d70: mov             x0, x1
    //     0x1304d74: stur            x1, [fp, #-8]
    // 0x1304d78: CheckStackOverflow
    //     0x1304d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304d7c: cmp             SP, x16
    //     0x1304d80: b.ls            #0x1304ef0
    // 0x1304d84: cmp             w2, NULL
    // 0x1304d88: b.eq            #0x1304ef8
    // 0x1304d8c: LoadField: r1 = r2->field_7
    //     0x1304d8c: ldur            x1, [x2, #7]
    // 0x1304d90: cmp             x1, #0
    // 0x1304d94: b.gt            #0x1304e48
    // 0x1304d98: LoadField: r1 = r0->field_7
    //     0x1304d98: ldur            w1, [x0, #7]
    // 0x1304d9c: DecompressPointer r1
    //     0x1304d9c: add             x1, x1, HEAP, lsl #32
    // 0x1304da0: LoadField: r2 = r0->field_1b
    //     0x1304da0: ldur            w2, [x0, #0x1b]
    // 0x1304da4: DecompressPointer r2
    //     0x1304da4: add             x2, x2, HEAP, lsl #32
    // 0x1304da8: r0 = +()
    //     0x1304da8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304dac: mov             x3, x0
    // 0x1304db0: ldur            x0, [fp, #-8]
    // 0x1304db4: stur            x3, [fp, #-0x10]
    // 0x1304db8: LoadField: r1 = r0->field_b
    //     0x1304db8: ldur            w1, [x0, #0xb]
    // 0x1304dbc: DecompressPointer r1
    //     0x1304dbc: add             x1, x1, HEAP, lsl #32
    // 0x1304dc0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1304dc0: ldur            w2, [x0, #0x17]
    // 0x1304dc4: DecompressPointer r2
    //     0x1304dc4: add             x2, x2, HEAP, lsl #32
    // 0x1304dc8: r0 = +()
    //     0x1304dc8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304dcc: mov             x3, x0
    // 0x1304dd0: ldur            x0, [fp, #-8]
    // 0x1304dd4: stur            x3, [fp, #-0x18]
    // 0x1304dd8: LoadField: r1 = r0->field_f
    //     0x1304dd8: ldur            w1, [x0, #0xf]
    // 0x1304ddc: DecompressPointer r1
    //     0x1304ddc: add             x1, x1, HEAP, lsl #32
    // 0x1304de0: LoadField: r2 = r0->field_23
    //     0x1304de0: ldur            w2, [x0, #0x23]
    // 0x1304de4: DecompressPointer r2
    //     0x1304de4: add             x2, x2, HEAP, lsl #32
    // 0x1304de8: r0 = +()
    //     0x1304de8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304dec: mov             x3, x0
    // 0x1304df0: ldur            x0, [fp, #-8]
    // 0x1304df4: stur            x3, [fp, #-0x20]
    // 0x1304df8: LoadField: r1 = r0->field_13
    //     0x1304df8: ldur            w1, [x0, #0x13]
    // 0x1304dfc: DecompressPointer r1
    //     0x1304dfc: add             x1, x1, HEAP, lsl #32
    // 0x1304e00: LoadField: r2 = r0->field_1f
    //     0x1304e00: ldur            w2, [x0, #0x1f]
    // 0x1304e04: DecompressPointer r2
    //     0x1304e04: add             x2, x2, HEAP, lsl #32
    // 0x1304e08: r0 = +()
    //     0x1304e08: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304e0c: stur            x0, [fp, #-0x28]
    // 0x1304e10: r0 = BorderRadius()
    //     0x1304e10: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1304e14: mov             x1, x0
    // 0x1304e18: ldur            x0, [fp, #-0x10]
    // 0x1304e1c: StoreField: r1->field_7 = r0
    //     0x1304e1c: stur            w0, [x1, #7]
    // 0x1304e20: ldur            x0, [fp, #-0x18]
    // 0x1304e24: StoreField: r1->field_b = r0
    //     0x1304e24: stur            w0, [x1, #0xb]
    // 0x1304e28: ldur            x0, [fp, #-0x20]
    // 0x1304e2c: StoreField: r1->field_f = r0
    //     0x1304e2c: stur            w0, [x1, #0xf]
    // 0x1304e30: ldur            x0, [fp, #-0x28]
    // 0x1304e34: StoreField: r1->field_13 = r0
    //     0x1304e34: stur            w0, [x1, #0x13]
    // 0x1304e38: mov             x0, x1
    // 0x1304e3c: LeaveFrame
    //     0x1304e3c: mov             SP, fp
    //     0x1304e40: ldp             fp, lr, [SP], #0x10
    // 0x1304e44: ret
    //     0x1304e44: ret             
    // 0x1304e48: LoadField: r1 = r0->field_7
    //     0x1304e48: ldur            w1, [x0, #7]
    // 0x1304e4c: DecompressPointer r1
    //     0x1304e4c: add             x1, x1, HEAP, lsl #32
    // 0x1304e50: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1304e50: ldur            w2, [x0, #0x17]
    // 0x1304e54: DecompressPointer r2
    //     0x1304e54: add             x2, x2, HEAP, lsl #32
    // 0x1304e58: r0 = +()
    //     0x1304e58: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304e5c: mov             x3, x0
    // 0x1304e60: ldur            x0, [fp, #-8]
    // 0x1304e64: stur            x3, [fp, #-0x10]
    // 0x1304e68: LoadField: r1 = r0->field_b
    //     0x1304e68: ldur            w1, [x0, #0xb]
    // 0x1304e6c: DecompressPointer r1
    //     0x1304e6c: add             x1, x1, HEAP, lsl #32
    // 0x1304e70: LoadField: r2 = r0->field_1b
    //     0x1304e70: ldur            w2, [x0, #0x1b]
    // 0x1304e74: DecompressPointer r2
    //     0x1304e74: add             x2, x2, HEAP, lsl #32
    // 0x1304e78: r0 = +()
    //     0x1304e78: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304e7c: mov             x3, x0
    // 0x1304e80: ldur            x0, [fp, #-8]
    // 0x1304e84: stur            x3, [fp, #-0x18]
    // 0x1304e88: LoadField: r1 = r0->field_f
    //     0x1304e88: ldur            w1, [x0, #0xf]
    // 0x1304e8c: DecompressPointer r1
    //     0x1304e8c: add             x1, x1, HEAP, lsl #32
    // 0x1304e90: LoadField: r2 = r0->field_1f
    //     0x1304e90: ldur            w2, [x0, #0x1f]
    // 0x1304e94: DecompressPointer r2
    //     0x1304e94: add             x2, x2, HEAP, lsl #32
    // 0x1304e98: r0 = +()
    //     0x1304e98: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304e9c: mov             x3, x0
    // 0x1304ea0: ldur            x0, [fp, #-8]
    // 0x1304ea4: stur            x3, [fp, #-0x20]
    // 0x1304ea8: LoadField: r1 = r0->field_13
    //     0x1304ea8: ldur            w1, [x0, #0x13]
    // 0x1304eac: DecompressPointer r1
    //     0x1304eac: add             x1, x1, HEAP, lsl #32
    // 0x1304eb0: LoadField: r2 = r0->field_23
    //     0x1304eb0: ldur            w2, [x0, #0x23]
    // 0x1304eb4: DecompressPointer r2
    //     0x1304eb4: add             x2, x2, HEAP, lsl #32
    // 0x1304eb8: r0 = +()
    //     0x1304eb8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x1304ebc: stur            x0, [fp, #-8]
    // 0x1304ec0: r0 = BorderRadius()
    //     0x1304ec0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1304ec4: ldur            x1, [fp, #-0x10]
    // 0x1304ec8: StoreField: r0->field_7 = r1
    //     0x1304ec8: stur            w1, [x0, #7]
    // 0x1304ecc: ldur            x1, [fp, #-0x18]
    // 0x1304ed0: StoreField: r0->field_b = r1
    //     0x1304ed0: stur            w1, [x0, #0xb]
    // 0x1304ed4: ldur            x1, [fp, #-0x20]
    // 0x1304ed8: StoreField: r0->field_f = r1
    //     0x1304ed8: stur            w1, [x0, #0xf]
    // 0x1304edc: ldur            x1, [fp, #-8]
    // 0x1304ee0: StoreField: r0->field_13 = r1
    //     0x1304ee0: stur            w1, [x0, #0x13]
    // 0x1304ee4: LeaveFrame
    //     0x1304ee4: mov             SP, fp
    //     0x1304ee8: ldp             fp, lr, [SP], #0x10
    // 0x1304eec: ret
    //     0x1304eec: ret             
    // 0x1304ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304ef4: b               #0x1304d84
    // 0x1304ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304ef8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2952, size: 0x18, field offset: 0x8
//   const constructor, 
class BorderRadiusDirectional extends BorderRadiusGeometry {

  Radius field_8;
  Radius field_c;
  Radius field_10;
  Radius field_14;

  BorderRadiusDirectional +(BorderRadiusDirectional, BorderRadiusDirectional) {
    // ** addr: 0xb77674, size: 0x84
    // 0xb77674: EnterFrame
    //     0xb77674: stp             fp, lr, [SP, #-0x10]!
    //     0xb77678: mov             fp, SP
    // 0xb7767c: CheckStackOverflow
    //     0xb7767c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb77680: cmp             SP, x16
    //     0xb77684: b.ls            #0xb776d8
    // 0xb77688: ldr             x0, [fp, #0x10]
    // 0xb7768c: r2 = Null
    //     0xb7768c: mov             x2, NULL
    // 0xb77690: r1 = Null
    //     0xb77690: mov             x1, NULL
    // 0xb77694: r4 = 60
    //     0xb77694: mov             x4, #0x3c
    // 0xb77698: branchIfSmi(r0, 0xb776a4)
    //     0xb77698: tbz             w0, #0, #0xb776a4
    // 0xb7769c: r4 = LoadClassIdInstr(r0)
    //     0xb7769c: ldur            x4, [x0, #-1]
    //     0xb776a0: ubfx            x4, x4, #0xc, #0x14
    // 0xb776a4: cmp             x4, #0xb88
    // 0xb776a8: b.eq            #0xb776c0
    // 0xb776ac: r8 = BorderRadiusDirectional
    //     0xb776ac: add             x8, PP, #0x82, lsl #12  ; [pp+0x82790] Type: BorderRadiusDirectional
    //     0xb776b0: ldr             x8, [x8, #0x790]
    // 0xb776b4: r3 = Null
    //     0xb776b4: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8ee68] Null
    //     0xb776b8: ldr             x3, [x3, #0xe68]
    // 0xb776bc: r0 = DefaultTypeTest()
    //     0xb776bc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb776c0: ldr             x1, [fp, #0x18]
    // 0xb776c4: ldr             x2, [fp, #0x10]
    // 0xb776c8: r0 = +()
    //     0xb776c8: bl              #0xb776e0  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::+
    // 0xb776cc: LeaveFrame
    //     0xb776cc: mov             SP, fp
    //     0xb776d0: ldp             fp, lr, [SP], #0x10
    // 0xb776d4: ret
    //     0xb776d4: ret             
    // 0xb776d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb776d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb776dc: b               #0xb77688
  }
  BorderRadiusDirectional +(BorderRadiusDirectional, BorderRadiusDirectional) {
    // ** addr: 0xb776e0, size: 0xe4
    // 0xb776e0: EnterFrame
    //     0xb776e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb776e4: mov             fp, SP
    // 0xb776e8: AllocStack(0x28)
    //     0xb776e8: sub             SP, SP, #0x28
    // 0xb776ec: SetupParameters(BorderRadiusDirectional this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb776ec: mov             x3, x1
    //     0xb776f0: mov             x0, x2
    //     0xb776f4: stur            x1, [fp, #-8]
    //     0xb776f8: stur            x2, [fp, #-0x10]
    // 0xb776fc: CheckStackOverflow
    //     0xb776fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb77700: cmp             SP, x16
    //     0xb77704: b.ls            #0xb777bc
    // 0xb77708: LoadField: r1 = r3->field_7
    //     0xb77708: ldur            w1, [x3, #7]
    // 0xb7770c: DecompressPointer r1
    //     0xb7770c: add             x1, x1, HEAP, lsl #32
    // 0xb77710: LoadField: r2 = r0->field_7
    //     0xb77710: ldur            w2, [x0, #7]
    // 0xb77714: DecompressPointer r2
    //     0xb77714: add             x2, x2, HEAP, lsl #32
    // 0xb77718: r0 = +()
    //     0xb77718: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0xb7771c: mov             x3, x0
    // 0xb77720: ldur            x0, [fp, #-8]
    // 0xb77724: stur            x3, [fp, #-0x18]
    // 0xb77728: LoadField: r1 = r0->field_b
    //     0xb77728: ldur            w1, [x0, #0xb]
    // 0xb7772c: DecompressPointer r1
    //     0xb7772c: add             x1, x1, HEAP, lsl #32
    // 0xb77730: ldur            x4, [fp, #-0x10]
    // 0xb77734: LoadField: r2 = r4->field_b
    //     0xb77734: ldur            w2, [x4, #0xb]
    // 0xb77738: DecompressPointer r2
    //     0xb77738: add             x2, x2, HEAP, lsl #32
    // 0xb7773c: r0 = +()
    //     0xb7773c: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0xb77740: mov             x3, x0
    // 0xb77744: ldur            x0, [fp, #-8]
    // 0xb77748: stur            x3, [fp, #-0x20]
    // 0xb7774c: LoadField: r1 = r0->field_f
    //     0xb7774c: ldur            w1, [x0, #0xf]
    // 0xb77750: DecompressPointer r1
    //     0xb77750: add             x1, x1, HEAP, lsl #32
    // 0xb77754: ldur            x4, [fp, #-0x10]
    // 0xb77758: LoadField: r2 = r4->field_f
    //     0xb77758: ldur            w2, [x4, #0xf]
    // 0xb7775c: DecompressPointer r2
    //     0xb7775c: add             x2, x2, HEAP, lsl #32
    // 0xb77760: r0 = +()
    //     0xb77760: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0xb77764: mov             x3, x0
    // 0xb77768: ldur            x0, [fp, #-8]
    // 0xb7776c: stur            x3, [fp, #-0x28]
    // 0xb77770: LoadField: r1 = r0->field_13
    //     0xb77770: ldur            w1, [x0, #0x13]
    // 0xb77774: DecompressPointer r1
    //     0xb77774: add             x1, x1, HEAP, lsl #32
    // 0xb77778: ldur            x0, [fp, #-0x10]
    // 0xb7777c: LoadField: r2 = r0->field_13
    //     0xb7777c: ldur            w2, [x0, #0x13]
    // 0xb77780: DecompressPointer r2
    //     0xb77780: add             x2, x2, HEAP, lsl #32
    // 0xb77784: r0 = +()
    //     0xb77784: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0xb77788: stur            x0, [fp, #-8]
    // 0xb7778c: r0 = BorderRadiusDirectional()
    //     0xb7778c: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0xb77790: ldur            x1, [fp, #-0x18]
    // 0xb77794: StoreField: r0->field_7 = r1
    //     0xb77794: stur            w1, [x0, #7]
    // 0xb77798: ldur            x1, [fp, #-0x20]
    // 0xb7779c: StoreField: r0->field_b = r1
    //     0xb7779c: stur            w1, [x0, #0xb]
    // 0xb777a0: ldur            x1, [fp, #-0x28]
    // 0xb777a4: StoreField: r0->field_f = r1
    //     0xb777a4: stur            w1, [x0, #0xf]
    // 0xb777a8: ldur            x1, [fp, #-8]
    // 0xb777ac: StoreField: r0->field_13 = r1
    //     0xb777ac: stur            w1, [x0, #0x13]
    // 0xb777b0: LeaveFrame
    //     0xb777b0: mov             SP, fp
    //     0xb777b4: ldp             fp, lr, [SP], #0x10
    // 0xb777b8: ret
    //     0xb777b8: ret             
    // 0xb777bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb777bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb777c0: b               #0xb77708
  }
  BorderRadius resolve(BorderRadiusDirectional, TextDirection?) {
    // ** addr: 0xb777e8, size: 0x88
    // 0xb777e8: EnterFrame
    //     0xb777e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb777ec: mov             fp, SP
    // 0xb777f0: CheckStackOverflow
    //     0xb777f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb777f4: cmp             SP, x16
    //     0xb777f8: b.ls            #0xb77850
    // 0xb777fc: ldr             x0, [fp, #0x10]
    // 0xb77800: r2 = Null
    //     0xb77800: mov             x2, NULL
    // 0xb77804: r1 = Null
    //     0xb77804: mov             x1, NULL
    // 0xb77808: r4 = 60
    //     0xb77808: mov             x4, #0x3c
    // 0xb7780c: branchIfSmi(r0, 0xb77818)
    //     0xb7780c: tbz             w0, #0, #0xb77818
    // 0xb77810: r4 = LoadClassIdInstr(r0)
    //     0xb77810: ldur            x4, [x0, #-1]
    //     0xb77814: ubfx            x4, x4, #0xc, #0x14
    // 0xb77818: r17 = 8353
    //     0xb77818: mov             x17, #0x20a1
    // 0xb7781c: cmp             x4, x17
    // 0xb77820: b.eq            #0xb77838
    // 0xb77824: r8 = TextDirection?
    //     0xb77824: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0xb77828: ldr             x8, [x8, #0x750]
    // 0xb7782c: r3 = Null
    //     0xb7782c: add             x3, PP, #0x82, lsl #12  ; [pp+0x82780] Null
    //     0xb77830: ldr             x3, [x3, #0x780]
    // 0xb77834: r0 = DefaultNullableTypeTest()
    //     0xb77834: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xb77838: ldr             x1, [fp, #0x18]
    // 0xb7783c: ldr             x2, [fp, #0x10]
    // 0xb77840: r0 = resolve()
    //     0xb77840: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0xb77844: LeaveFrame
    //     0xb77844: mov             SP, fp
    //     0xb77848: ldp             fp, lr, [SP], #0x10
    // 0xb7784c: ret
    //     0xb7784c: ret             
    // 0xb77850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb77850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb77854: b               #0xb777fc
  }
  BorderRadiusDirectional *(BorderRadiusDirectional, double) {
    // ** addr: 0xb77870, size: 0x50
    // 0xb77870: EnterFrame
    //     0xb77870: stp             fp, lr, [SP, #-0x10]!
    //     0xb77874: mov             fp, SP
    // 0xb77878: CheckStackOverflow
    //     0xb77878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7787c: cmp             SP, x16
    //     0xb77880: b.ls            #0xb778a0
    // 0xb77884: ldr             x0, [fp, #0x10]
    // 0xb77888: LoadField: d0 = r0->field_7
    //     0xb77888: ldur            d0, [x0, #7]
    // 0xb7788c: ldr             x1, [fp, #0x18]
    // 0xb77890: r0 = *()
    //     0xb77890: bl              #0x1301d7c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::*
    // 0xb77894: LeaveFrame
    //     0xb77894: mov             SP, fp
    //     0xb77898: ldp             fp, lr, [SP], #0x10
    // 0xb7789c: ret
    //     0xb7789c: ret             
    // 0xb778a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb778a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb778a4: b               #0xb77884
  }
  BorderRadiusDirectional -(BorderRadiusDirectional, BorderRadiusDirectional) {
    // ** addr: 0xb778c0, size: 0x84
    // 0xb778c0: EnterFrame
    //     0xb778c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb778c4: mov             fp, SP
    // 0xb778c8: CheckStackOverflow
    //     0xb778c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb778cc: cmp             SP, x16
    //     0xb778d0: b.ls            #0xb77924
    // 0xb778d4: ldr             x0, [fp, #0x10]
    // 0xb778d8: r2 = Null
    //     0xb778d8: mov             x2, NULL
    // 0xb778dc: r1 = Null
    //     0xb778dc: mov             x1, NULL
    // 0xb778e0: r4 = 60
    //     0xb778e0: mov             x4, #0x3c
    // 0xb778e4: branchIfSmi(r0, 0xb778f0)
    //     0xb778e4: tbz             w0, #0, #0xb778f0
    // 0xb778e8: r4 = LoadClassIdInstr(r0)
    //     0xb778e8: ldur            x4, [x0, #-1]
    //     0xb778ec: ubfx            x4, x4, #0xc, #0x14
    // 0xb778f0: cmp             x4, #0xb88
    // 0xb778f4: b.eq            #0xb7790c
    // 0xb778f8: r8 = BorderRadiusDirectional
    //     0xb778f8: add             x8, PP, #0x82, lsl #12  ; [pp+0x82790] Type: BorderRadiusDirectional
    //     0xb778fc: ldr             x8, [x8, #0x790]
    // 0xb77900: r3 = Null
    //     0xb77900: add             x3, PP, #0x82, lsl #12  ; [pp+0x82798] Null
    //     0xb77904: ldr             x3, [x3, #0x798]
    // 0xb77908: r0 = DefaultTypeTest()
    //     0xb77908: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb7790c: ldr             x1, [fp, #0x18]
    // 0xb77910: ldr             x2, [fp, #0x10]
    // 0xb77914: r0 = -()
    //     0xb77914: bl              #0xb7792c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::-
    // 0xb77918: LeaveFrame
    //     0xb77918: mov             SP, fp
    //     0xb7791c: ldp             fp, lr, [SP], #0x10
    // 0xb77920: ret
    //     0xb77920: ret             
    // 0xb77924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb77924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb77928: b               #0xb778d4
  }
  BorderRadiusDirectional -(BorderRadiusDirectional, BorderRadiusDirectional) {
    // ** addr: 0xb7792c, size: 0xe4
    // 0xb7792c: EnterFrame
    //     0xb7792c: stp             fp, lr, [SP, #-0x10]!
    //     0xb77930: mov             fp, SP
    // 0xb77934: AllocStack(0x28)
    //     0xb77934: sub             SP, SP, #0x28
    // 0xb77938: SetupParameters(BorderRadiusDirectional this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb77938: mov             x3, x1
    //     0xb7793c: mov             x0, x2
    //     0xb77940: stur            x1, [fp, #-8]
    //     0xb77944: stur            x2, [fp, #-0x10]
    // 0xb77948: CheckStackOverflow
    //     0xb77948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7794c: cmp             SP, x16
    //     0xb77950: b.ls            #0xb77a08
    // 0xb77954: LoadField: r1 = r3->field_7
    //     0xb77954: ldur            w1, [x3, #7]
    // 0xb77958: DecompressPointer r1
    //     0xb77958: add             x1, x1, HEAP, lsl #32
    // 0xb7795c: LoadField: r2 = r0->field_7
    //     0xb7795c: ldur            w2, [x0, #7]
    // 0xb77960: DecompressPointer r2
    //     0xb77960: add             x2, x2, HEAP, lsl #32
    // 0xb77964: r0 = -()
    //     0xb77964: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0xb77968: mov             x3, x0
    // 0xb7796c: ldur            x0, [fp, #-8]
    // 0xb77970: stur            x3, [fp, #-0x18]
    // 0xb77974: LoadField: r1 = r0->field_b
    //     0xb77974: ldur            w1, [x0, #0xb]
    // 0xb77978: DecompressPointer r1
    //     0xb77978: add             x1, x1, HEAP, lsl #32
    // 0xb7797c: ldur            x4, [fp, #-0x10]
    // 0xb77980: LoadField: r2 = r4->field_b
    //     0xb77980: ldur            w2, [x4, #0xb]
    // 0xb77984: DecompressPointer r2
    //     0xb77984: add             x2, x2, HEAP, lsl #32
    // 0xb77988: r0 = -()
    //     0xb77988: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0xb7798c: mov             x3, x0
    // 0xb77990: ldur            x0, [fp, #-8]
    // 0xb77994: stur            x3, [fp, #-0x20]
    // 0xb77998: LoadField: r1 = r0->field_f
    //     0xb77998: ldur            w1, [x0, #0xf]
    // 0xb7799c: DecompressPointer r1
    //     0xb7799c: add             x1, x1, HEAP, lsl #32
    // 0xb779a0: ldur            x4, [fp, #-0x10]
    // 0xb779a4: LoadField: r2 = r4->field_f
    //     0xb779a4: ldur            w2, [x4, #0xf]
    // 0xb779a8: DecompressPointer r2
    //     0xb779a8: add             x2, x2, HEAP, lsl #32
    // 0xb779ac: r0 = -()
    //     0xb779ac: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0xb779b0: mov             x3, x0
    // 0xb779b4: ldur            x0, [fp, #-8]
    // 0xb779b8: stur            x3, [fp, #-0x28]
    // 0xb779bc: LoadField: r1 = r0->field_13
    //     0xb779bc: ldur            w1, [x0, #0x13]
    // 0xb779c0: DecompressPointer r1
    //     0xb779c0: add             x1, x1, HEAP, lsl #32
    // 0xb779c4: ldur            x0, [fp, #-0x10]
    // 0xb779c8: LoadField: r2 = r0->field_13
    //     0xb779c8: ldur            w2, [x0, #0x13]
    // 0xb779cc: DecompressPointer r2
    //     0xb779cc: add             x2, x2, HEAP, lsl #32
    // 0xb779d0: r0 = -()
    //     0xb779d0: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0xb779d4: stur            x0, [fp, #-8]
    // 0xb779d8: r0 = BorderRadiusDirectional()
    //     0xb779d8: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0xb779dc: ldur            x1, [fp, #-0x18]
    // 0xb779e0: StoreField: r0->field_7 = r1
    //     0xb779e0: stur            w1, [x0, #7]
    // 0xb779e4: ldur            x1, [fp, #-0x20]
    // 0xb779e8: StoreField: r0->field_b = r1
    //     0xb779e8: stur            w1, [x0, #0xb]
    // 0xb779ec: ldur            x1, [fp, #-0x28]
    // 0xb779f0: StoreField: r0->field_f = r1
    //     0xb779f0: stur            w1, [x0, #0xf]
    // 0xb779f4: ldur            x1, [fp, #-8]
    // 0xb779f8: StoreField: r0->field_13 = r1
    //     0xb779f8: stur            w1, [x0, #0x13]
    // 0xb779fc: LeaveFrame
    //     0xb779fc: mov             SP, fp
    //     0xb77a00: ldp             fp, lr, [SP], #0x10
    // 0xb77a04: ret
    //     0xb77a04: ret             
    // 0xb77a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb77a08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb77a0c: b               #0xb77954
  }
  _ add(/* No info */) {
    // ** addr: 0x12f59e8, size: 0x4c
    // 0x12f59e8: EnterFrame
    //     0x12f59e8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f59ec: mov             fp, SP
    // 0x12f59f0: CheckStackOverflow
    //     0x12f59f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f59f4: cmp             SP, x16
    //     0x12f59f8: b.ls            #0x12f5a2c
    // 0x12f59fc: r0 = LoadClassIdInstr(r2)
    //     0x12f59fc: ldur            x0, [x2, #-1]
    //     0x12f5a00: ubfx            x0, x0, #0xc, #0x14
    // 0x12f5a04: cmp             x0, #0xb88
    // 0x12f5a08: b.ne            #0x12f5a1c
    // 0x12f5a0c: r0 = +()
    //     0x12f5a0c: bl              #0xb776e0  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::+
    // 0x12f5a10: LeaveFrame
    //     0x12f5a10: mov             SP, fp
    //     0x12f5a14: ldp             fp, lr, [SP], #0x10
    // 0x12f5a18: ret
    //     0x12f5a18: ret             
    // 0x12f5a1c: r0 = add()
    //     0x12f5a1c: bl              #0x12f5a34  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0x12f5a20: LeaveFrame
    //     0x12f5a20: mov             SP, fp
    //     0x12f5a24: ldp             fp, lr, [SP], #0x10
    // 0x12f5a28: ret
    //     0x12f5a28: ret             
    // 0x12f5a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f5a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f5a30: b               #0x12f59fc
  }
  _ subtract(/* No info */) {
    // ** addr: 0x12f5fd8, size: 0x4c
    // 0x12f5fd8: EnterFrame
    //     0x12f5fd8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f5fdc: mov             fp, SP
    // 0x12f5fe0: CheckStackOverflow
    //     0x12f5fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f5fe4: cmp             SP, x16
    //     0x12f5fe8: b.ls            #0x12f601c
    // 0x12f5fec: r0 = LoadClassIdInstr(r2)
    //     0x12f5fec: ldur            x0, [x2, #-1]
    //     0x12f5ff0: ubfx            x0, x0, #0xc, #0x14
    // 0x12f5ff4: cmp             x0, #0xb88
    // 0x12f5ff8: b.ne            #0x12f600c
    // 0x12f5ffc: r0 = -()
    //     0x12f5ffc: bl              #0xb7792c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::-
    // 0x12f6000: LeaveFrame
    //     0x12f6000: mov             SP, fp
    //     0x12f6004: ldp             fp, lr, [SP], #0x10
    // 0x12f6008: ret
    //     0x12f6008: ret             
    // 0x12f600c: r0 = subtract()
    //     0x12f600c: bl              #0x12f6024  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0x12f6010: LeaveFrame
    //     0x12f6010: mov             SP, fp
    //     0x12f6014: ldp             fp, lr, [SP], #0x10
    // 0x12f6018: ret
    //     0x12f6018: ret             
    // 0x12f601c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f601c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f6020: b               #0x12f5fec
  }
  BorderRadiusDirectional *(BorderRadiusDirectional, double) {
    // ** addr: 0x1301d7c, size: 0xc8
    // 0x1301d7c: EnterFrame
    //     0x1301d7c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301d80: mov             fp, SP
    // 0x1301d84: AllocStack(0x28)
    //     0x1301d84: sub             SP, SP, #0x28
    // 0x1301d88: SetupParameters(BorderRadiusDirectional this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x1301d88: mov             x0, x1
    //     0x1301d8c: mov             v1.16b, v0.16b
    //     0x1301d90: stur            x1, [fp, #-8]
    //     0x1301d94: stur            d0, [fp, #-0x28]
    // 0x1301d98: CheckStackOverflow
    //     0x1301d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1301d9c: cmp             SP, x16
    //     0x1301da0: b.ls            #0x1301e3c
    // 0x1301da4: LoadField: r1 = r0->field_7
    //     0x1301da4: ldur            w1, [x0, #7]
    // 0x1301da8: DecompressPointer r1
    //     0x1301da8: add             x1, x1, HEAP, lsl #32
    // 0x1301dac: mov             v0.16b, v1.16b
    // 0x1301db0: r0 = *()
    //     0x1301db0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301db4: mov             x2, x0
    // 0x1301db8: ldur            x0, [fp, #-8]
    // 0x1301dbc: stur            x2, [fp, #-0x10]
    // 0x1301dc0: LoadField: r1 = r0->field_b
    //     0x1301dc0: ldur            w1, [x0, #0xb]
    // 0x1301dc4: DecompressPointer r1
    //     0x1301dc4: add             x1, x1, HEAP, lsl #32
    // 0x1301dc8: ldur            d0, [fp, #-0x28]
    // 0x1301dcc: r0 = *()
    //     0x1301dcc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301dd0: mov             x2, x0
    // 0x1301dd4: ldur            x0, [fp, #-8]
    // 0x1301dd8: stur            x2, [fp, #-0x18]
    // 0x1301ddc: LoadField: r1 = r0->field_f
    //     0x1301ddc: ldur            w1, [x0, #0xf]
    // 0x1301de0: DecompressPointer r1
    //     0x1301de0: add             x1, x1, HEAP, lsl #32
    // 0x1301de4: ldur            d0, [fp, #-0x28]
    // 0x1301de8: r0 = *()
    //     0x1301de8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301dec: mov             x2, x0
    // 0x1301df0: ldur            x0, [fp, #-8]
    // 0x1301df4: stur            x2, [fp, #-0x20]
    // 0x1301df8: LoadField: r1 = r0->field_13
    //     0x1301df8: ldur            w1, [x0, #0x13]
    // 0x1301dfc: DecompressPointer r1
    //     0x1301dfc: add             x1, x1, HEAP, lsl #32
    // 0x1301e00: ldur            d0, [fp, #-0x28]
    // 0x1301e04: r0 = *()
    //     0x1301e04: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301e08: stur            x0, [fp, #-8]
    // 0x1301e0c: r0 = BorderRadiusDirectional()
    //     0x1301e0c: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0x1301e10: ldur            x1, [fp, #-0x10]
    // 0x1301e14: StoreField: r0->field_7 = r1
    //     0x1301e14: stur            w1, [x0, #7]
    // 0x1301e18: ldur            x1, [fp, #-0x18]
    // 0x1301e1c: StoreField: r0->field_b = r1
    //     0x1301e1c: stur            w1, [x0, #0xb]
    // 0x1301e20: ldur            x1, [fp, #-0x20]
    // 0x1301e24: StoreField: r0->field_f = r1
    //     0x1301e24: stur            w1, [x0, #0xf]
    // 0x1301e28: ldur            x1, [fp, #-8]
    // 0x1301e2c: StoreField: r0->field_13 = r1
    //     0x1301e2c: stur            w1, [x0, #0x13]
    // 0x1301e30: LeaveFrame
    //     0x1301e30: mov             SP, fp
    //     0x1301e34: ldp             fp, lr, [SP], #0x10
    // 0x1301e38: ret
    //     0x1301e38: ret             
    // 0x1301e3c: r0 = StackOverflowSharedWithFPURegs()
    //     0x1301e3c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1301e40: b               #0x1301da4
  }
  BorderRadius resolve(BorderRadiusDirectional, TextDirection?) {
    // ** addr: 0x1304c78, size: 0xec
    // 0x1304c78: EnterFrame
    //     0x1304c78: stp             fp, lr, [SP, #-0x10]!
    //     0x1304c7c: mov             fp, SP
    // 0x1304c80: AllocStack(0x20)
    //     0x1304c80: sub             SP, SP, #0x20
    // 0x1304c84: cmp             w2, NULL
    // 0x1304c88: b.eq            #0x1304d60
    // 0x1304c8c: LoadField: r0 = r2->field_7
    //     0x1304c8c: ldur            x0, [x2, #7]
    // 0x1304c90: cmp             x0, #0
    // 0x1304c94: b.gt            #0x1304d00
    // 0x1304c98: LoadField: r0 = r1->field_b
    //     0x1304c98: ldur            w0, [x1, #0xb]
    // 0x1304c9c: DecompressPointer r0
    //     0x1304c9c: add             x0, x0, HEAP, lsl #32
    // 0x1304ca0: stur            x0, [fp, #-0x20]
    // 0x1304ca4: LoadField: r2 = r1->field_7
    //     0x1304ca4: ldur            w2, [x1, #7]
    // 0x1304ca8: DecompressPointer r2
    //     0x1304ca8: add             x2, x2, HEAP, lsl #32
    // 0x1304cac: stur            x2, [fp, #-0x18]
    // 0x1304cb0: LoadField: r3 = r1->field_13
    //     0x1304cb0: ldur            w3, [x1, #0x13]
    // 0x1304cb4: DecompressPointer r3
    //     0x1304cb4: add             x3, x3, HEAP, lsl #32
    // 0x1304cb8: stur            x3, [fp, #-0x10]
    // 0x1304cbc: LoadField: r4 = r1->field_f
    //     0x1304cbc: ldur            w4, [x1, #0xf]
    // 0x1304cc0: DecompressPointer r4
    //     0x1304cc0: add             x4, x4, HEAP, lsl #32
    // 0x1304cc4: stur            x4, [fp, #-8]
    // 0x1304cc8: r0 = BorderRadius()
    //     0x1304cc8: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1304ccc: mov             x1, x0
    // 0x1304cd0: ldur            x0, [fp, #-0x20]
    // 0x1304cd4: StoreField: r1->field_7 = r0
    //     0x1304cd4: stur            w0, [x1, #7]
    // 0x1304cd8: ldur            x0, [fp, #-0x18]
    // 0x1304cdc: StoreField: r1->field_b = r0
    //     0x1304cdc: stur            w0, [x1, #0xb]
    // 0x1304ce0: ldur            x0, [fp, #-0x10]
    // 0x1304ce4: StoreField: r1->field_f = r0
    //     0x1304ce4: stur            w0, [x1, #0xf]
    // 0x1304ce8: ldur            x0, [fp, #-8]
    // 0x1304cec: StoreField: r1->field_13 = r0
    //     0x1304cec: stur            w0, [x1, #0x13]
    // 0x1304cf0: mov             x0, x1
    // 0x1304cf4: LeaveFrame
    //     0x1304cf4: mov             SP, fp
    //     0x1304cf8: ldp             fp, lr, [SP], #0x10
    // 0x1304cfc: ret
    //     0x1304cfc: ret             
    // 0x1304d00: LoadField: r0 = r1->field_7
    //     0x1304d00: ldur            w0, [x1, #7]
    // 0x1304d04: DecompressPointer r0
    //     0x1304d04: add             x0, x0, HEAP, lsl #32
    // 0x1304d08: stur            x0, [fp, #-0x20]
    // 0x1304d0c: LoadField: r2 = r1->field_b
    //     0x1304d0c: ldur            w2, [x1, #0xb]
    // 0x1304d10: DecompressPointer r2
    //     0x1304d10: add             x2, x2, HEAP, lsl #32
    // 0x1304d14: stur            x2, [fp, #-0x18]
    // 0x1304d18: LoadField: r3 = r1->field_f
    //     0x1304d18: ldur            w3, [x1, #0xf]
    // 0x1304d1c: DecompressPointer r3
    //     0x1304d1c: add             x3, x3, HEAP, lsl #32
    // 0x1304d20: stur            x3, [fp, #-0x10]
    // 0x1304d24: LoadField: r4 = r1->field_13
    //     0x1304d24: ldur            w4, [x1, #0x13]
    // 0x1304d28: DecompressPointer r4
    //     0x1304d28: add             x4, x4, HEAP, lsl #32
    // 0x1304d2c: stur            x4, [fp, #-8]
    // 0x1304d30: r0 = BorderRadius()
    //     0x1304d30: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1304d34: ldur            x1, [fp, #-0x20]
    // 0x1304d38: StoreField: r0->field_7 = r1
    //     0x1304d38: stur            w1, [x0, #7]
    // 0x1304d3c: ldur            x1, [fp, #-0x18]
    // 0x1304d40: StoreField: r0->field_b = r1
    //     0x1304d40: stur            w1, [x0, #0xb]
    // 0x1304d44: ldur            x1, [fp, #-0x10]
    // 0x1304d48: StoreField: r0->field_f = r1
    //     0x1304d48: stur            w1, [x0, #0xf]
    // 0x1304d4c: ldur            x1, [fp, #-8]
    // 0x1304d50: StoreField: r0->field_13 = r1
    //     0x1304d50: stur            w1, [x0, #0x13]
    // 0x1304d54: LeaveFrame
    //     0x1304d54: mov             SP, fp
    //     0x1304d58: ldp             fp, lr, [SP], #0x10
    // 0x1304d5c: ret
    //     0x1304d5c: ret             
    // 0x1304d60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304d60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2953, size: 0x18, field offset: 0x8
//   const constructor, 
class BorderRadius extends BorderRadiusGeometry {

  Radius field_8;
  Radius field_c;
  Radius field_10;
  Radius field_14;

  BorderRadius -(BorderRadius, BorderRadius) {
    // ** addr: 0x8a4efc, size: 0x84
    // 0x8a4efc: EnterFrame
    //     0x8a4efc: stp             fp, lr, [SP, #-0x10]!
    //     0x8a4f00: mov             fp, SP
    // 0x8a4f04: CheckStackOverflow
    //     0x8a4f04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a4f08: cmp             SP, x16
    //     0x8a4f0c: b.ls            #0x8a4f60
    // 0x8a4f10: ldr             x0, [fp, #0x10]
    // 0x8a4f14: r2 = Null
    //     0x8a4f14: mov             x2, NULL
    // 0x8a4f18: r1 = Null
    //     0x8a4f18: mov             x1, NULL
    // 0x8a4f1c: r4 = 60
    //     0x8a4f1c: mov             x4, #0x3c
    // 0x8a4f20: branchIfSmi(r0, 0x8a4f2c)
    //     0x8a4f20: tbz             w0, #0, #0x8a4f2c
    // 0x8a4f24: r4 = LoadClassIdInstr(r0)
    //     0x8a4f24: ldur            x4, [x0, #-1]
    //     0x8a4f28: ubfx            x4, x4, #0xc, #0x14
    // 0x8a4f2c: cmp             x4, #0xb89
    // 0x8a4f30: b.eq            #0x8a4f48
    // 0x8a4f34: r8 = BorderRadius
    //     0x8a4f34: add             x8, PP, #0x82, lsl #12  ; [pp+0x82768] Type: BorderRadius
    //     0x8a4f38: ldr             x8, [x8, #0x768]
    // 0x8a4f3c: r3 = Null
    //     0x8a4f3c: add             x3, PP, #0x82, lsl #12  ; [pp+0x82770] Null
    //     0x8a4f40: ldr             x3, [x3, #0x770]
    // 0x8a4f44: r0 = DefaultTypeTest()
    //     0x8a4f44: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8a4f48: ldr             x1, [fp, #0x18]
    // 0x8a4f4c: ldr             x2, [fp, #0x10]
    // 0x8a4f50: r0 = -()
    //     0x8a4f50: bl              #0x8a4f68  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0x8a4f54: LeaveFrame
    //     0x8a4f54: mov             SP, fp
    //     0x8a4f58: ldp             fp, lr, [SP], #0x10
    // 0x8a4f5c: ret
    //     0x8a4f5c: ret             
    // 0x8a4f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a4f60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a4f64: b               #0x8a4f10
  }
  BorderRadius -(BorderRadius, BorderRadius) {
    // ** addr: 0x8a4f68, size: 0xe4
    // 0x8a4f68: EnterFrame
    //     0x8a4f68: stp             fp, lr, [SP, #-0x10]!
    //     0x8a4f6c: mov             fp, SP
    // 0x8a4f70: AllocStack(0x28)
    //     0x8a4f70: sub             SP, SP, #0x28
    // 0x8a4f74: SetupParameters(BorderRadius this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8a4f74: mov             x3, x1
    //     0x8a4f78: mov             x0, x2
    //     0x8a4f7c: stur            x1, [fp, #-8]
    //     0x8a4f80: stur            x2, [fp, #-0x10]
    // 0x8a4f84: CheckStackOverflow
    //     0x8a4f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a4f88: cmp             SP, x16
    //     0x8a4f8c: b.ls            #0x8a5044
    // 0x8a4f90: LoadField: r1 = r3->field_7
    //     0x8a4f90: ldur            w1, [x3, #7]
    // 0x8a4f94: DecompressPointer r1
    //     0x8a4f94: add             x1, x1, HEAP, lsl #32
    // 0x8a4f98: LoadField: r2 = r0->field_7
    //     0x8a4f98: ldur            w2, [x0, #7]
    // 0x8a4f9c: DecompressPointer r2
    //     0x8a4f9c: add             x2, x2, HEAP, lsl #32
    // 0x8a4fa0: r0 = -()
    //     0x8a4fa0: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x8a4fa4: mov             x3, x0
    // 0x8a4fa8: ldur            x0, [fp, #-8]
    // 0x8a4fac: stur            x3, [fp, #-0x18]
    // 0x8a4fb0: LoadField: r1 = r0->field_b
    //     0x8a4fb0: ldur            w1, [x0, #0xb]
    // 0x8a4fb4: DecompressPointer r1
    //     0x8a4fb4: add             x1, x1, HEAP, lsl #32
    // 0x8a4fb8: ldur            x4, [fp, #-0x10]
    // 0x8a4fbc: LoadField: r2 = r4->field_b
    //     0x8a4fbc: ldur            w2, [x4, #0xb]
    // 0x8a4fc0: DecompressPointer r2
    //     0x8a4fc0: add             x2, x2, HEAP, lsl #32
    // 0x8a4fc4: r0 = -()
    //     0x8a4fc4: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x8a4fc8: mov             x3, x0
    // 0x8a4fcc: ldur            x0, [fp, #-8]
    // 0x8a4fd0: stur            x3, [fp, #-0x20]
    // 0x8a4fd4: LoadField: r1 = r0->field_f
    //     0x8a4fd4: ldur            w1, [x0, #0xf]
    // 0x8a4fd8: DecompressPointer r1
    //     0x8a4fd8: add             x1, x1, HEAP, lsl #32
    // 0x8a4fdc: ldur            x4, [fp, #-0x10]
    // 0x8a4fe0: LoadField: r2 = r4->field_f
    //     0x8a4fe0: ldur            w2, [x4, #0xf]
    // 0x8a4fe4: DecompressPointer r2
    //     0x8a4fe4: add             x2, x2, HEAP, lsl #32
    // 0x8a4fe8: r0 = -()
    //     0x8a4fe8: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x8a4fec: mov             x3, x0
    // 0x8a4ff0: ldur            x0, [fp, #-8]
    // 0x8a4ff4: stur            x3, [fp, #-0x28]
    // 0x8a4ff8: LoadField: r1 = r0->field_13
    //     0x8a4ff8: ldur            w1, [x0, #0x13]
    // 0x8a4ffc: DecompressPointer r1
    //     0x8a4ffc: add             x1, x1, HEAP, lsl #32
    // 0x8a5000: ldur            x0, [fp, #-0x10]
    // 0x8a5004: LoadField: r2 = r0->field_13
    //     0x8a5004: ldur            w2, [x0, #0x13]
    // 0x8a5008: DecompressPointer r2
    //     0x8a5008: add             x2, x2, HEAP, lsl #32
    // 0x8a500c: r0 = -()
    //     0x8a500c: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x8a5010: stur            x0, [fp, #-8]
    // 0x8a5014: r0 = BorderRadius()
    //     0x8a5014: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a5018: ldur            x1, [fp, #-0x18]
    // 0x8a501c: StoreField: r0->field_7 = r1
    //     0x8a501c: stur            w1, [x0, #7]
    // 0x8a5020: ldur            x1, [fp, #-0x20]
    // 0x8a5024: StoreField: r0->field_b = r1
    //     0x8a5024: stur            w1, [x0, #0xb]
    // 0x8a5028: ldur            x1, [fp, #-0x28]
    // 0x8a502c: StoreField: r0->field_f = r1
    //     0x8a502c: stur            w1, [x0, #0xf]
    // 0x8a5030: ldur            x1, [fp, #-8]
    // 0x8a5034: StoreField: r0->field_13 = r1
    //     0x8a5034: stur            w1, [x0, #0x13]
    // 0x8a5038: LeaveFrame
    //     0x8a5038: mov             SP, fp
    //     0x8a503c: ldp             fp, lr, [SP], #0x10
    // 0x8a5040: ret
    //     0x8a5040: ret             
    // 0x8a5044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a5048: b               #0x8a4f90
  }
  BorderRadius resolve(BorderRadius, TextDirection?) {
    // ** addr: 0x8a5298, size: 0x6c
    // 0x8a5298: EnterFrame
    //     0x8a5298: stp             fp, lr, [SP, #-0x10]!
    //     0x8a529c: mov             fp, SP
    // 0x8a52a0: ldr             x0, [fp, #0x10]
    // 0x8a52a4: r2 = Null
    //     0x8a52a4: mov             x2, NULL
    // 0x8a52a8: r1 = Null
    //     0x8a52a8: mov             x1, NULL
    // 0x8a52ac: r4 = 60
    //     0x8a52ac: mov             x4, #0x3c
    // 0x8a52b0: branchIfSmi(r0, 0x8a52bc)
    //     0x8a52b0: tbz             w0, #0, #0x8a52bc
    // 0x8a52b4: r4 = LoadClassIdInstr(r0)
    //     0x8a52b4: ldur            x4, [x0, #-1]
    //     0x8a52b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8a52bc: r17 = 8353
    //     0x8a52bc: mov             x17, #0x20a1
    // 0x8a52c0: cmp             x4, x17
    // 0x8a52c4: b.eq            #0x8a52dc
    // 0x8a52c8: r8 = TextDirection?
    //     0x8a52c8: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0x8a52cc: ldr             x8, [x8, #0x750]
    // 0x8a52d0: r3 = Null
    //     0x8a52d0: add             x3, PP, #0x82, lsl #12  ; [pp+0x82758] Null
    //     0x8a52d4: ldr             x3, [x3, #0x758]
    // 0x8a52d8: r0 = DefaultNullableTypeTest()
    //     0x8a52d8: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x8a52dc: ldr             x0, [fp, #0x18]
    // 0x8a52e0: LeaveFrame
    //     0x8a52e0: mov             SP, fp
    //     0x8a52e4: ldp             fp, lr, [SP], #0x10
    // 0x8a52e8: ret
    //     0x8a52e8: ret             
  }
  BorderRadius *(BorderRadius, double) {
    // ** addr: 0x8a5304, size: 0x50
    // 0x8a5304: EnterFrame
    //     0x8a5304: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5308: mov             fp, SP
    // 0x8a530c: CheckStackOverflow
    //     0x8a530c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5310: cmp             SP, x16
    //     0x8a5314: b.ls            #0x8a5334
    // 0x8a5318: ldr             x0, [fp, #0x10]
    // 0x8a531c: LoadField: d0 = r0->field_7
    //     0x8a531c: ldur            d0, [x0, #7]
    // 0x8a5320: ldr             x1, [fp, #0x18]
    // 0x8a5324: r0 = *()
    //     0x8a5324: bl              #0x1301cb4  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0x8a5328: LeaveFrame
    //     0x8a5328: mov             SP, fp
    //     0x8a532c: ldp             fp, lr, [SP], #0x10
    // 0x8a5330: ret
    //     0x8a5330: ret             
    // 0x8a5334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5334: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a5338: b               #0x8a5318
  }
  BorderRadius +(BorderRadius, BorderRadius) {
    // ** addr: 0x8a5354, size: 0x84
    // 0x8a5354: EnterFrame
    //     0x8a5354: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5358: mov             fp, SP
    // 0x8a535c: CheckStackOverflow
    //     0x8a535c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5360: cmp             SP, x16
    //     0x8a5364: b.ls            #0x8a53b8
    // 0x8a5368: ldr             x0, [fp, #0x10]
    // 0x8a536c: r2 = Null
    //     0x8a536c: mov             x2, NULL
    // 0x8a5370: r1 = Null
    //     0x8a5370: mov             x1, NULL
    // 0x8a5374: r4 = 60
    //     0x8a5374: mov             x4, #0x3c
    // 0x8a5378: branchIfSmi(r0, 0x8a5384)
    //     0x8a5378: tbz             w0, #0, #0x8a5384
    // 0x8a537c: r4 = LoadClassIdInstr(r0)
    //     0x8a537c: ldur            x4, [x0, #-1]
    //     0x8a5380: ubfx            x4, x4, #0xc, #0x14
    // 0x8a5384: cmp             x4, #0xb89
    // 0x8a5388: b.eq            #0x8a53a0
    // 0x8a538c: r8 = BorderRadius
    //     0x8a538c: add             x8, PP, #0x82, lsl #12  ; [pp+0x82768] Type: BorderRadius
    //     0x8a5390: ldr             x8, [x8, #0x768]
    // 0x8a5394: r3 = Null
    //     0x8a5394: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8ee58] Null
    //     0x8a5398: ldr             x3, [x3, #0xe58]
    // 0x8a539c: r0 = DefaultTypeTest()
    //     0x8a539c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8a53a0: ldr             x1, [fp, #0x18]
    // 0x8a53a4: ldr             x2, [fp, #0x10]
    // 0x8a53a8: r0 = +()
    //     0x8a53a8: bl              #0x8a53c0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0x8a53ac: LeaveFrame
    //     0x8a53ac: mov             SP, fp
    //     0x8a53b0: ldp             fp, lr, [SP], #0x10
    // 0x8a53b4: ret
    //     0x8a53b4: ret             
    // 0x8a53b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a53b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a53bc: b               #0x8a5368
  }
  BorderRadius +(BorderRadius, BorderRadius) {
    // ** addr: 0x8a53c0, size: 0xe4
    // 0x8a53c0: EnterFrame
    //     0x8a53c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a53c4: mov             fp, SP
    // 0x8a53c8: AllocStack(0x28)
    //     0x8a53c8: sub             SP, SP, #0x28
    // 0x8a53cc: SetupParameters(BorderRadius this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8a53cc: mov             x3, x1
    //     0x8a53d0: mov             x0, x2
    //     0x8a53d4: stur            x1, [fp, #-8]
    //     0x8a53d8: stur            x2, [fp, #-0x10]
    // 0x8a53dc: CheckStackOverflow
    //     0x8a53dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a53e0: cmp             SP, x16
    //     0x8a53e4: b.ls            #0x8a549c
    // 0x8a53e8: LoadField: r1 = r3->field_7
    //     0x8a53e8: ldur            w1, [x3, #7]
    // 0x8a53ec: DecompressPointer r1
    //     0x8a53ec: add             x1, x1, HEAP, lsl #32
    // 0x8a53f0: LoadField: r2 = r0->field_7
    //     0x8a53f0: ldur            w2, [x0, #7]
    // 0x8a53f4: DecompressPointer r2
    //     0x8a53f4: add             x2, x2, HEAP, lsl #32
    // 0x8a53f8: r0 = +()
    //     0x8a53f8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x8a53fc: mov             x3, x0
    // 0x8a5400: ldur            x0, [fp, #-8]
    // 0x8a5404: stur            x3, [fp, #-0x18]
    // 0x8a5408: LoadField: r1 = r0->field_b
    //     0x8a5408: ldur            w1, [x0, #0xb]
    // 0x8a540c: DecompressPointer r1
    //     0x8a540c: add             x1, x1, HEAP, lsl #32
    // 0x8a5410: ldur            x4, [fp, #-0x10]
    // 0x8a5414: LoadField: r2 = r4->field_b
    //     0x8a5414: ldur            w2, [x4, #0xb]
    // 0x8a5418: DecompressPointer r2
    //     0x8a5418: add             x2, x2, HEAP, lsl #32
    // 0x8a541c: r0 = +()
    //     0x8a541c: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x8a5420: mov             x3, x0
    // 0x8a5424: ldur            x0, [fp, #-8]
    // 0x8a5428: stur            x3, [fp, #-0x20]
    // 0x8a542c: LoadField: r1 = r0->field_f
    //     0x8a542c: ldur            w1, [x0, #0xf]
    // 0x8a5430: DecompressPointer r1
    //     0x8a5430: add             x1, x1, HEAP, lsl #32
    // 0x8a5434: ldur            x4, [fp, #-0x10]
    // 0x8a5438: LoadField: r2 = r4->field_f
    //     0x8a5438: ldur            w2, [x4, #0xf]
    // 0x8a543c: DecompressPointer r2
    //     0x8a543c: add             x2, x2, HEAP, lsl #32
    // 0x8a5440: r0 = +()
    //     0x8a5440: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x8a5444: mov             x3, x0
    // 0x8a5448: ldur            x0, [fp, #-8]
    // 0x8a544c: stur            x3, [fp, #-0x28]
    // 0x8a5450: LoadField: r1 = r0->field_13
    //     0x8a5450: ldur            w1, [x0, #0x13]
    // 0x8a5454: DecompressPointer r1
    //     0x8a5454: add             x1, x1, HEAP, lsl #32
    // 0x8a5458: ldur            x0, [fp, #-0x10]
    // 0x8a545c: LoadField: r2 = r0->field_13
    //     0x8a545c: ldur            w2, [x0, #0x13]
    // 0x8a5460: DecompressPointer r2
    //     0x8a5460: add             x2, x2, HEAP, lsl #32
    // 0x8a5464: r0 = +()
    //     0x8a5464: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x8a5468: stur            x0, [fp, #-8]
    // 0x8a546c: r0 = BorderRadius()
    //     0x8a546c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a5470: ldur            x1, [fp, #-0x18]
    // 0x8a5474: StoreField: r0->field_7 = r1
    //     0x8a5474: stur            w1, [x0, #7]
    // 0x8a5478: ldur            x1, [fp, #-0x20]
    // 0x8a547c: StoreField: r0->field_b = r1
    //     0x8a547c: stur            w1, [x0, #0xb]
    // 0x8a5480: ldur            x1, [fp, #-0x28]
    // 0x8a5484: StoreField: r0->field_f = r1
    //     0x8a5484: stur            w1, [x0, #0xf]
    // 0x8a5488: ldur            x1, [fp, #-8]
    // 0x8a548c: StoreField: r0->field_13 = r1
    //     0x8a548c: stur            w1, [x0, #0x13]
    // 0x8a5490: LeaveFrame
    //     0x8a5490: mov             SP, fp
    //     0x8a5494: ldp             fp, lr, [SP], #0x10
    // 0x8a5498: ret
    //     0x8a5498: ret             
    // 0x8a549c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a549c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a54a0: b               #0x8a53e8
  }
  _ toRRect(/* No info */) {
    // ** addr: 0xb77a10, size: 0x110
    // 0xb77a10: EnterFrame
    //     0xb77a10: stp             fp, lr, [SP, #-0x10]!
    //     0xb77a14: mov             fp, SP
    // 0xb77a18: AllocStack(0x30)
    //     0xb77a18: sub             SP, SP, #0x30
    // 0xb77a1c: SetupParameters(BorderRadius this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb77a1c: mov             x0, x1
    //     0xb77a20: stur            x1, [fp, #-8]
    //     0xb77a24: stur            x2, [fp, #-0x10]
    // 0xb77a28: CheckStackOverflow
    //     0xb77a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb77a2c: cmp             SP, x16
    //     0xb77a30: b.ls            #0xb77b18
    // 0xb77a34: LoadField: r1 = r0->field_7
    //     0xb77a34: ldur            w1, [x0, #7]
    // 0xb77a38: DecompressPointer r1
    //     0xb77a38: add             x1, x1, HEAP, lsl #32
    // 0xb77a3c: r16 = Instance_Radius
    //     0xb77a3c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xb77a40: ldr             x16, [x16, #0x1a0]
    // 0xb77a44: str             x16, [SP]
    // 0xb77a48: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xb77a48: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xb77a4c: ldr             x4, [x4, #0x678]
    // 0xb77a50: r0 = clamp()
    //     0xb77a50: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xb77a54: mov             x2, x0
    // 0xb77a58: ldur            x0, [fp, #-8]
    // 0xb77a5c: stur            x2, [fp, #-0x18]
    // 0xb77a60: LoadField: r1 = r0->field_b
    //     0xb77a60: ldur            w1, [x0, #0xb]
    // 0xb77a64: DecompressPointer r1
    //     0xb77a64: add             x1, x1, HEAP, lsl #32
    // 0xb77a68: r16 = Instance_Radius
    //     0xb77a68: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xb77a6c: ldr             x16, [x16, #0x1a0]
    // 0xb77a70: str             x16, [SP]
    // 0xb77a74: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xb77a74: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xb77a78: ldr             x4, [x4, #0x678]
    // 0xb77a7c: r0 = clamp()
    //     0xb77a7c: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xb77a80: mov             x2, x0
    // 0xb77a84: ldur            x0, [fp, #-8]
    // 0xb77a88: stur            x2, [fp, #-0x20]
    // 0xb77a8c: LoadField: r1 = r0->field_f
    //     0xb77a8c: ldur            w1, [x0, #0xf]
    // 0xb77a90: DecompressPointer r1
    //     0xb77a90: add             x1, x1, HEAP, lsl #32
    // 0xb77a94: r16 = Instance_Radius
    //     0xb77a94: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xb77a98: ldr             x16, [x16, #0x1a0]
    // 0xb77a9c: str             x16, [SP]
    // 0xb77aa0: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xb77aa0: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xb77aa4: ldr             x4, [x4, #0x678]
    // 0xb77aa8: r0 = clamp()
    //     0xb77aa8: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xb77aac: mov             x2, x0
    // 0xb77ab0: ldur            x0, [fp, #-8]
    // 0xb77ab4: stur            x2, [fp, #-0x28]
    // 0xb77ab8: LoadField: r1 = r0->field_13
    //     0xb77ab8: ldur            w1, [x0, #0x13]
    // 0xb77abc: DecompressPointer r1
    //     0xb77abc: add             x1, x1, HEAP, lsl #32
    // 0xb77ac0: r16 = Instance_Radius
    //     0xb77ac0: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xb77ac4: ldr             x16, [x16, #0x1a0]
    // 0xb77ac8: str             x16, [SP]
    // 0xb77acc: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xb77acc: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xb77ad0: ldr             x4, [x4, #0x678]
    // 0xb77ad4: r0 = clamp()
    //     0xb77ad4: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xb77ad8: r1 = <RRect>
    //     0xb77ad8: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb77adc: ldr             x1, [x1, #0x108]
    // 0xb77ae0: stur            x0, [fp, #-8]
    // 0xb77ae4: r0 = RRect()
    //     0xb77ae4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb77ae8: mov             x1, x0
    // 0xb77aec: ldur            x2, [fp, #-0x10]
    // 0xb77af0: ldur            x3, [fp, #-0x28]
    // 0xb77af4: ldur            x5, [fp, #-8]
    // 0xb77af8: ldur            x6, [fp, #-0x18]
    // 0xb77afc: ldur            x7, [fp, #-0x20]
    // 0xb77b00: stur            x0, [fp, #-8]
    // 0xb77b04: r0 = RSuperellipse.fromRectAndCorners()
    //     0xb77b04: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0xb77b08: ldur            x0, [fp, #-8]
    // 0xb77b0c: LeaveFrame
    //     0xb77b0c: mov             SP, fp
    //     0xb77b10: ldp             fp, lr, [SP], #0x10
    // 0xb77b14: ret
    //     0xb77b14: ret             
    // 0xb77b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb77b18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb77b1c: b               #0xb77a34
  }
  _ toRSuperellipse(/* No info */) {
    // ** addr: 0xbfdf88, size: 0x110
    // 0xbfdf88: EnterFrame
    //     0xbfdf88: stp             fp, lr, [SP, #-0x10]!
    //     0xbfdf8c: mov             fp, SP
    // 0xbfdf90: AllocStack(0x30)
    //     0xbfdf90: sub             SP, SP, #0x30
    // 0xbfdf94: SetupParameters(BorderRadius this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbfdf94: mov             x0, x1
    //     0xbfdf98: stur            x1, [fp, #-8]
    //     0xbfdf9c: stur            x2, [fp, #-0x10]
    // 0xbfdfa0: CheckStackOverflow
    //     0xbfdfa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfdfa4: cmp             SP, x16
    //     0xbfdfa8: b.ls            #0xbfe090
    // 0xbfdfac: LoadField: r1 = r0->field_7
    //     0xbfdfac: ldur            w1, [x0, #7]
    // 0xbfdfb0: DecompressPointer r1
    //     0xbfdfb0: add             x1, x1, HEAP, lsl #32
    // 0xbfdfb4: r16 = Instance_Radius
    //     0xbfdfb4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xbfdfb8: ldr             x16, [x16, #0x1a0]
    // 0xbfdfbc: str             x16, [SP]
    // 0xbfdfc0: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xbfdfc0: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xbfdfc4: ldr             x4, [x4, #0x678]
    // 0xbfdfc8: r0 = clamp()
    //     0xbfdfc8: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xbfdfcc: mov             x2, x0
    // 0xbfdfd0: ldur            x0, [fp, #-8]
    // 0xbfdfd4: stur            x2, [fp, #-0x18]
    // 0xbfdfd8: LoadField: r1 = r0->field_b
    //     0xbfdfd8: ldur            w1, [x0, #0xb]
    // 0xbfdfdc: DecompressPointer r1
    //     0xbfdfdc: add             x1, x1, HEAP, lsl #32
    // 0xbfdfe0: r16 = Instance_Radius
    //     0xbfdfe0: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xbfdfe4: ldr             x16, [x16, #0x1a0]
    // 0xbfdfe8: str             x16, [SP]
    // 0xbfdfec: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xbfdfec: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xbfdff0: ldr             x4, [x4, #0x678]
    // 0xbfdff4: r0 = clamp()
    //     0xbfdff4: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xbfdff8: mov             x2, x0
    // 0xbfdffc: ldur            x0, [fp, #-8]
    // 0xbfe000: stur            x2, [fp, #-0x20]
    // 0xbfe004: LoadField: r1 = r0->field_f
    //     0xbfe004: ldur            w1, [x0, #0xf]
    // 0xbfe008: DecompressPointer r1
    //     0xbfe008: add             x1, x1, HEAP, lsl #32
    // 0xbfe00c: r16 = Instance_Radius
    //     0xbfe00c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xbfe010: ldr             x16, [x16, #0x1a0]
    // 0xbfe014: str             x16, [SP]
    // 0xbfe018: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xbfe018: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xbfe01c: ldr             x4, [x4, #0x678]
    // 0xbfe020: r0 = clamp()
    //     0xbfe020: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xbfe024: mov             x2, x0
    // 0xbfe028: ldur            x0, [fp, #-8]
    // 0xbfe02c: stur            x2, [fp, #-0x28]
    // 0xbfe030: LoadField: r1 = r0->field_13
    //     0xbfe030: ldur            w1, [x0, #0x13]
    // 0xbfe034: DecompressPointer r1
    //     0xbfe034: add             x1, x1, HEAP, lsl #32
    // 0xbfe038: r16 = Instance_Radius
    //     0xbfe038: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xbfe03c: ldr             x16, [x16, #0x1a0]
    // 0xbfe040: str             x16, [SP]
    // 0xbfe044: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0xbfe044: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0xbfe048: ldr             x4, [x4, #0x678]
    // 0xbfe04c: r0 = clamp()
    //     0xbfe04c: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0xbfe050: r1 = <RSuperellipse>
    //     0xbfe050: add             x1, PP, #0x90, lsl #12  ; [pp+0x90c28] TypeArguments: <RSuperellipse>
    //     0xbfe054: ldr             x1, [x1, #0xc28]
    // 0xbfe058: stur            x0, [fp, #-8]
    // 0xbfe05c: r0 = RSuperellipse()
    //     0xbfe05c: bl              #0xb6dcd4  ; AllocateRSuperellipseStub -> RSuperellipse (size=0x6c)
    // 0xbfe060: mov             x1, x0
    // 0xbfe064: ldur            x2, [fp, #-0x10]
    // 0xbfe068: ldur            x3, [fp, #-0x28]
    // 0xbfe06c: ldur            x5, [fp, #-8]
    // 0xbfe070: ldur            x6, [fp, #-0x18]
    // 0xbfe074: ldur            x7, [fp, #-0x20]
    // 0xbfe078: stur            x0, [fp, #-8]
    // 0xbfe07c: r0 = RSuperellipse.fromRectAndCorners()
    //     0xbfe07c: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0xbfe080: ldur            x0, [fp, #-8]
    // 0xbfe084: LeaveFrame
    //     0xbfe084: mov             SP, fp
    //     0xbfe088: ldp             fp, lr, [SP], #0x10
    // 0xbfe08c: ret
    //     0xbfe08c: ret             
    // 0xbfe090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfe090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfe094: b               #0xbfdfac
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbfea10, size: 0x168
    // 0xbfea10: EnterFrame
    //     0xbfea10: stp             fp, lr, [SP, #-0x10]!
    //     0xbfea14: mov             fp, SP
    // 0xbfea18: AllocStack(0x30)
    //     0xbfea18: sub             SP, SP, #0x30
    // 0xbfea1c: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0xbfea1c: mov             x3, x1
    //     0xbfea20: mov             x0, x2
    //     0xbfea24: mov             v1.16b, v0.16b
    //     0xbfea28: stur            x1, [fp, #-8]
    //     0xbfea2c: stur            x2, [fp, #-0x10]
    //     0xbfea30: stur            d0, [fp, #-0x30]
    // 0xbfea34: CheckStackOverflow
    //     0xbfea34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfea38: cmp             SP, x16
    //     0xbfea3c: b.ls            #0xbfeb6c
    // 0xbfea40: cmp             w3, w0
    // 0xbfea44: b.ne            #0xbfea58
    // 0xbfea48: mov             x0, x3
    // 0xbfea4c: LeaveFrame
    //     0xbfea4c: mov             SP, fp
    //     0xbfea50: ldp             fp, lr, [SP], #0x10
    // 0xbfea54: ret
    //     0xbfea54: ret             
    // 0xbfea58: cmp             w3, NULL
    // 0xbfea5c: b.ne            #0xbfea80
    // 0xbfea60: cmp             w0, NULL
    // 0xbfea64: b.eq            #0xbfeb74
    // 0xbfea68: mov             x1, x0
    // 0xbfea6c: mov             v0.16b, v1.16b
    // 0xbfea70: r0 = *()
    //     0xbfea70: bl              #0x1301cb4  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0xbfea74: LeaveFrame
    //     0xbfea74: mov             SP, fp
    //     0xbfea78: ldp             fp, lr, [SP], #0x10
    // 0xbfea7c: ret
    //     0xbfea7c: ret             
    // 0xbfea80: cmp             w0, NULL
    // 0xbfea84: b.ne            #0xbfeaa8
    // 0xbfea88: d0 = 1.000000
    //     0xbfea88: fmov            d0, #1.00000000
    // 0xbfea8c: fsub            d2, d0, d1
    // 0xbfea90: mov             x1, x3
    // 0xbfea94: mov             v0.16b, v2.16b
    // 0xbfea98: r0 = *()
    //     0xbfea98: bl              #0x1301cb4  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0xbfea9c: LeaveFrame
    //     0xbfea9c: mov             SP, fp
    //     0xbfeaa0: ldp             fp, lr, [SP], #0x10
    // 0xbfeaa4: ret
    //     0xbfeaa4: ret             
    // 0xbfeaa8: LoadField: r1 = r3->field_7
    //     0xbfeaa8: ldur            w1, [x3, #7]
    // 0xbfeaac: DecompressPointer r1
    //     0xbfeaac: add             x1, x1, HEAP, lsl #32
    // 0xbfeab0: LoadField: r2 = r0->field_7
    //     0xbfeab0: ldur            w2, [x0, #7]
    // 0xbfeab4: DecompressPointer r2
    //     0xbfeab4: add             x2, x2, HEAP, lsl #32
    // 0xbfeab8: mov             v0.16b, v1.16b
    // 0xbfeabc: r0 = lerp()
    //     0xbfeabc: bl              #0xbfeb78  ; [dart:ui] Radius::lerp
    // 0xbfeac0: mov             x3, x0
    // 0xbfeac4: ldur            x0, [fp, #-8]
    // 0xbfeac8: stur            x3, [fp, #-0x18]
    // 0xbfeacc: LoadField: r1 = r0->field_b
    //     0xbfeacc: ldur            w1, [x0, #0xb]
    // 0xbfead0: DecompressPointer r1
    //     0xbfead0: add             x1, x1, HEAP, lsl #32
    // 0xbfead4: ldur            x4, [fp, #-0x10]
    // 0xbfead8: LoadField: r2 = r4->field_b
    //     0xbfead8: ldur            w2, [x4, #0xb]
    // 0xbfeadc: DecompressPointer r2
    //     0xbfeadc: add             x2, x2, HEAP, lsl #32
    // 0xbfeae0: ldur            d0, [fp, #-0x30]
    // 0xbfeae4: r0 = lerp()
    //     0xbfeae4: bl              #0xbfeb78  ; [dart:ui] Radius::lerp
    // 0xbfeae8: mov             x3, x0
    // 0xbfeaec: ldur            x0, [fp, #-8]
    // 0xbfeaf0: stur            x3, [fp, #-0x20]
    // 0xbfeaf4: LoadField: r1 = r0->field_f
    //     0xbfeaf4: ldur            w1, [x0, #0xf]
    // 0xbfeaf8: DecompressPointer r1
    //     0xbfeaf8: add             x1, x1, HEAP, lsl #32
    // 0xbfeafc: ldur            x4, [fp, #-0x10]
    // 0xbfeb00: LoadField: r2 = r4->field_f
    //     0xbfeb00: ldur            w2, [x4, #0xf]
    // 0xbfeb04: DecompressPointer r2
    //     0xbfeb04: add             x2, x2, HEAP, lsl #32
    // 0xbfeb08: ldur            d0, [fp, #-0x30]
    // 0xbfeb0c: r0 = lerp()
    //     0xbfeb0c: bl              #0xbfeb78  ; [dart:ui] Radius::lerp
    // 0xbfeb10: mov             x3, x0
    // 0xbfeb14: ldur            x0, [fp, #-8]
    // 0xbfeb18: stur            x3, [fp, #-0x28]
    // 0xbfeb1c: LoadField: r1 = r0->field_13
    //     0xbfeb1c: ldur            w1, [x0, #0x13]
    // 0xbfeb20: DecompressPointer r1
    //     0xbfeb20: add             x1, x1, HEAP, lsl #32
    // 0xbfeb24: ldur            x0, [fp, #-0x10]
    // 0xbfeb28: LoadField: r2 = r0->field_13
    //     0xbfeb28: ldur            w2, [x0, #0x13]
    // 0xbfeb2c: DecompressPointer r2
    //     0xbfeb2c: add             x2, x2, HEAP, lsl #32
    // 0xbfeb30: ldur            d0, [fp, #-0x30]
    // 0xbfeb34: r0 = lerp()
    //     0xbfeb34: bl              #0xbfeb78  ; [dart:ui] Radius::lerp
    // 0xbfeb38: stur            x0, [fp, #-8]
    // 0xbfeb3c: r0 = BorderRadius()
    //     0xbfeb3c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfeb40: ldur            x1, [fp, #-0x18]
    // 0xbfeb44: StoreField: r0->field_7 = r1
    //     0xbfeb44: stur            w1, [x0, #7]
    // 0xbfeb48: ldur            x1, [fp, #-0x20]
    // 0xbfeb4c: StoreField: r0->field_b = r1
    //     0xbfeb4c: stur            w1, [x0, #0xb]
    // 0xbfeb50: ldur            x1, [fp, #-0x28]
    // 0xbfeb54: StoreField: r0->field_f = r1
    //     0xbfeb54: stur            w1, [x0, #0xf]
    // 0xbfeb58: ldur            x1, [fp, #-8]
    // 0xbfeb5c: StoreField: r0->field_13 = r1
    //     0xbfeb5c: stur            w1, [x0, #0x13]
    // 0xbfeb60: LeaveFrame
    //     0xbfeb60: mov             SP, fp
    //     0xbfeb64: ldp             fp, lr, [SP], #0x10
    // 0xbfeb68: ret
    //     0xbfeb68: ret             
    // 0xbfeb6c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbfeb6c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbfeb70: b               #0xbfea40
    // 0xbfeb74: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbfeb74: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xfad144, size: 0x54
    // 0xfad144: EnterFrame
    //     0xfad144: stp             fp, lr, [SP, #-0x10]!
    //     0xfad148: mov             fp, SP
    // 0xfad14c: AllocStack(0x10)
    //     0xfad14c: sub             SP, SP, #0x10
    // 0xfad150: LoadField: r0 = r1->field_f
    //     0xfad150: ldur            w0, [x1, #0xf]
    // 0xfad154: DecompressPointer r0
    //     0xfad154: add             x0, x0, HEAP, lsl #32
    // 0xfad158: stur            x0, [fp, #-0x10]
    // 0xfad15c: LoadField: r2 = r1->field_13
    //     0xfad15c: ldur            w2, [x1, #0x13]
    // 0xfad160: DecompressPointer r2
    //     0xfad160: add             x2, x2, HEAP, lsl #32
    // 0xfad164: stur            x2, [fp, #-8]
    // 0xfad168: r0 = BorderRadius()
    //     0xfad168: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xfad16c: r1 = Instance_Radius
    //     0xfad16c: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xfad170: ldr             x1, [x1, #0x1a0]
    // 0xfad174: StoreField: r0->field_7 = r1
    //     0xfad174: stur            w1, [x0, #7]
    // 0xfad178: StoreField: r0->field_b = r1
    //     0xfad178: stur            w1, [x0, #0xb]
    // 0xfad17c: ldur            x1, [fp, #-0x10]
    // 0xfad180: StoreField: r0->field_f = r1
    //     0xfad180: stur            w1, [x0, #0xf]
    // 0xfad184: ldur            x1, [fp, #-8]
    // 0xfad188: StoreField: r0->field_13 = r1
    //     0xfad188: stur            w1, [x0, #0x13]
    // 0xfad18c: LeaveFrame
    //     0xfad18c: mov             SP, fp
    //     0xfad190: ldp             fp, lr, [SP], #0x10
    // 0xfad194: ret
    //     0xfad194: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0x12f599c, size: 0x4c
    // 0x12f599c: EnterFrame
    //     0x12f599c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f59a0: mov             fp, SP
    // 0x12f59a4: CheckStackOverflow
    //     0x12f59a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f59a8: cmp             SP, x16
    //     0x12f59ac: b.ls            #0x12f59e0
    // 0x12f59b0: r0 = LoadClassIdInstr(r2)
    //     0x12f59b0: ldur            x0, [x2, #-1]
    //     0x12f59b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12f59b8: cmp             x0, #0xb89
    // 0x12f59bc: b.ne            #0x12f59d0
    // 0x12f59c0: r0 = +()
    //     0x12f59c0: bl              #0x8a53c0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0x12f59c4: LeaveFrame
    //     0x12f59c4: mov             SP, fp
    //     0x12f59c8: ldp             fp, lr, [SP], #0x10
    // 0x12f59cc: ret
    //     0x12f59cc: ret             
    // 0x12f59d0: r0 = add()
    //     0x12f59d0: bl              #0x12f5a34  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0x12f59d4: LeaveFrame
    //     0x12f59d4: mov             SP, fp
    //     0x12f59d8: ldp             fp, lr, [SP], #0x10
    // 0x12f59dc: ret
    //     0x12f59dc: ret             
    // 0x12f59e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f59e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f59e4: b               #0x12f59b0
  }
  _ subtract(/* No info */) {
    // ** addr: 0x12f5f8c, size: 0x4c
    // 0x12f5f8c: EnterFrame
    //     0x12f5f8c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f5f90: mov             fp, SP
    // 0x12f5f94: CheckStackOverflow
    //     0x12f5f94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f5f98: cmp             SP, x16
    //     0x12f5f9c: b.ls            #0x12f5fd0
    // 0x12f5fa0: r0 = LoadClassIdInstr(r2)
    //     0x12f5fa0: ldur            x0, [x2, #-1]
    //     0x12f5fa4: ubfx            x0, x0, #0xc, #0x14
    // 0x12f5fa8: cmp             x0, #0xb89
    // 0x12f5fac: b.ne            #0x12f5fc0
    // 0x12f5fb0: r0 = -()
    //     0x12f5fb0: bl              #0x8a4f68  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0x12f5fb4: LeaveFrame
    //     0x12f5fb4: mov             SP, fp
    //     0x12f5fb8: ldp             fp, lr, [SP], #0x10
    // 0x12f5fbc: ret
    //     0x12f5fbc: ret             
    // 0x12f5fc0: r0 = subtract()
    //     0x12f5fc0: bl              #0x12f6024  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0x12f5fc4: LeaveFrame
    //     0x12f5fc4: mov             SP, fp
    //     0x12f5fc8: ldp             fp, lr, [SP], #0x10
    // 0x12f5fcc: ret
    //     0x12f5fcc: ret             
    // 0x12f5fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f5fd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f5fd4: b               #0x12f5fa0
  }
  BorderRadius *(BorderRadius, double) {
    // ** addr: 0x1301cb4, size: 0xc8
    // 0x1301cb4: EnterFrame
    //     0x1301cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x1301cb8: mov             fp, SP
    // 0x1301cbc: AllocStack(0x28)
    //     0x1301cbc: sub             SP, SP, #0x28
    // 0x1301cc0: SetupParameters(BorderRadius this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x1301cc0: mov             x0, x1
    //     0x1301cc4: mov             v1.16b, v0.16b
    //     0x1301cc8: stur            x1, [fp, #-8]
    //     0x1301ccc: stur            d0, [fp, #-0x28]
    // 0x1301cd0: CheckStackOverflow
    //     0x1301cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1301cd4: cmp             SP, x16
    //     0x1301cd8: b.ls            #0x1301d74
    // 0x1301cdc: LoadField: r1 = r0->field_7
    //     0x1301cdc: ldur            w1, [x0, #7]
    // 0x1301ce0: DecompressPointer r1
    //     0x1301ce0: add             x1, x1, HEAP, lsl #32
    // 0x1301ce4: mov             v0.16b, v1.16b
    // 0x1301ce8: r0 = *()
    //     0x1301ce8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301cec: mov             x2, x0
    // 0x1301cf0: ldur            x0, [fp, #-8]
    // 0x1301cf4: stur            x2, [fp, #-0x10]
    // 0x1301cf8: LoadField: r1 = r0->field_b
    //     0x1301cf8: ldur            w1, [x0, #0xb]
    // 0x1301cfc: DecompressPointer r1
    //     0x1301cfc: add             x1, x1, HEAP, lsl #32
    // 0x1301d00: ldur            d0, [fp, #-0x28]
    // 0x1301d04: r0 = *()
    //     0x1301d04: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301d08: mov             x2, x0
    // 0x1301d0c: ldur            x0, [fp, #-8]
    // 0x1301d10: stur            x2, [fp, #-0x18]
    // 0x1301d14: LoadField: r1 = r0->field_f
    //     0x1301d14: ldur            w1, [x0, #0xf]
    // 0x1301d18: DecompressPointer r1
    //     0x1301d18: add             x1, x1, HEAP, lsl #32
    // 0x1301d1c: ldur            d0, [fp, #-0x28]
    // 0x1301d20: r0 = *()
    //     0x1301d20: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301d24: mov             x2, x0
    // 0x1301d28: ldur            x0, [fp, #-8]
    // 0x1301d2c: stur            x2, [fp, #-0x20]
    // 0x1301d30: LoadField: r1 = r0->field_13
    //     0x1301d30: ldur            w1, [x0, #0x13]
    // 0x1301d34: DecompressPointer r1
    //     0x1301d34: add             x1, x1, HEAP, lsl #32
    // 0x1301d38: ldur            d0, [fp, #-0x28]
    // 0x1301d3c: r0 = *()
    //     0x1301d3c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x1301d40: stur            x0, [fp, #-8]
    // 0x1301d44: r0 = BorderRadius()
    //     0x1301d44: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1301d48: ldur            x1, [fp, #-0x10]
    // 0x1301d4c: StoreField: r0->field_7 = r1
    //     0x1301d4c: stur            w1, [x0, #7]
    // 0x1301d50: ldur            x1, [fp, #-0x18]
    // 0x1301d54: StoreField: r0->field_b = r1
    //     0x1301d54: stur            w1, [x0, #0xb]
    // 0x1301d58: ldur            x1, [fp, #-0x20]
    // 0x1301d5c: StoreField: r0->field_f = r1
    //     0x1301d5c: stur            w1, [x0, #0xf]
    // 0x1301d60: ldur            x1, [fp, #-8]
    // 0x1301d64: StoreField: r0->field_13 = r1
    //     0x1301d64: stur            w1, [x0, #0x13]
    // 0x1301d68: LeaveFrame
    //     0x1301d68: mov             SP, fp
    //     0x1301d6c: ldp             fp, lr, [SP], #0x10
    // 0x1301d70: ret
    //     0x1301d70: ret             
    // 0x1301d74: r0 = StackOverflowSharedWithFPURegs()
    //     0x1301d74: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1301d78: b               #0x1301cdc
  }
}
