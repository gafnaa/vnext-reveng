// lib: , url: package:flutter/src/painting/matrix_utils.dart

// class id: 1049002, size: 0x8
class :: {
}

// class id: 2917, size: 0x8, field offset: 0x8
abstract class MatrixUtils extends Object {

  static late final Float64List _minMax; // offset: 0xce4

  static _ transformPoint(/* No info */) {
    // ** addr: 0x856f28, size: 0x148
    // 0x856f28: EnterFrame
    //     0x856f28: stp             fp, lr, [SP, #-0x10]!
    //     0x856f2c: mov             fp, SP
    // 0x856f30: AllocStack(0x18)
    //     0x856f30: sub             SP, SP, #0x18
    // 0x856f34: d0 = 1.000000
    //     0x856f34: fmov            d0, #1.00000000
    // 0x856f38: LoadField: r3 = r1->field_7
    //     0x856f38: ldur            w3, [x1, #7]
    // 0x856f3c: DecompressPointer r3
    //     0x856f3c: add             x3, x3, HEAP, lsl #32
    // 0x856f40: LoadField: d1 = r2->field_7
    //     0x856f40: ldur            d1, [x2, #7]
    // 0x856f44: LoadField: d2 = r2->field_f
    //     0x856f44: ldur            d2, [x2, #0xf]
    // 0x856f48: LoadField: r0 = r3->field_13
    //     0x856f48: ldur            w0, [x3, #0x13]
    // 0x856f4c: r2 = LoadInt32Instr(r0)
    //     0x856f4c: sbfx            x2, x0, #1, #0x1f
    // 0x856f50: mov             x0, x2
    // 0x856f54: r1 = 0
    //     0x856f54: mov             x1, #0
    // 0x856f58: cmp             x1, x0
    // 0x856f5c: b.hs            #0x85705c
    // 0x856f60: ArrayLoad: d3 = r3[0]  ; List_8
    //     0x856f60: ldur            d3, [x3, #0x17]
    // 0x856f64: fmul            d4, d3, d1
    // 0x856f68: mov             x0, x2
    // 0x856f6c: r1 = 4
    //     0x856f6c: mov             x1, #4
    // 0x856f70: cmp             x1, x0
    // 0x856f74: b.hs            #0x857060
    // 0x856f78: LoadField: d3 = r3->field_37
    //     0x856f78: ldur            d3, [x3, #0x37]
    // 0x856f7c: fmul            d5, d3, d2
    // 0x856f80: fadd            d3, d4, d5
    // 0x856f84: mov             x0, x2
    // 0x856f88: r1 = 12
    //     0x856f88: mov             x1, #0xc
    // 0x856f8c: cmp             x1, x0
    // 0x856f90: b.hs            #0x857064
    // 0x856f94: LoadField: d4 = r3->field_77
    //     0x856f94: ldur            d4, [x3, #0x77]
    // 0x856f98: fadd            d5, d3, d4
    // 0x856f9c: stur            d5, [fp, #-0x10]
    // 0x856fa0: LoadField: d3 = r3->field_1f
    //     0x856fa0: ldur            d3, [x3, #0x1f]
    // 0x856fa4: fmul            d4, d3, d1
    // 0x856fa8: LoadField: d3 = r3->field_3f
    //     0x856fa8: ldur            d3, [x3, #0x3f]
    // 0x856fac: fmul            d6, d3, d2
    // 0x856fb0: fadd            d3, d4, d6
    // 0x856fb4: mov             x0, x2
    // 0x856fb8: r1 = 13
    //     0x856fb8: mov             x1, #0xd
    // 0x856fbc: cmp             x1, x0
    // 0x856fc0: b.hs            #0x857068
    // 0x856fc4: LoadField: d4 = r3->field_7f
    //     0x856fc4: ldur            d4, [x3, #0x7f]
    // 0x856fc8: fadd            d6, d3, d4
    // 0x856fcc: stur            d6, [fp, #-8]
    // 0x856fd0: LoadField: d3 = r3->field_2f
    //     0x856fd0: ldur            d3, [x3, #0x2f]
    // 0x856fd4: fmul            d4, d3, d1
    // 0x856fd8: LoadField: d1 = r3->field_4f
    //     0x856fd8: ldur            d1, [x3, #0x4f]
    // 0x856fdc: fmul            d3, d1, d2
    // 0x856fe0: fadd            d1, d4, d3
    // 0x856fe4: mov             x0, x2
    // 0x856fe8: r1 = 15
    //     0x856fe8: mov             x1, #0xf
    // 0x856fec: cmp             x1, x0
    // 0x856ff0: b.hs            #0x85706c
    // 0x856ff4: LoadField: d2 = r3->field_8f
    //     0x856ff4: ldur            d2, [x3, #0x8f]
    // 0x856ff8: fadd            d3, d1, d2
    // 0x856ffc: fcmp            d3, d0
    // 0x857000: b.ne            #0x857024
    // 0x857004: r0 = Offset()
    //     0x857004: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x857008: ldur            d0, [fp, #-0x10]
    // 0x85700c: StoreField: r0->field_7 = d0
    //     0x85700c: stur            d0, [x0, #7]
    // 0x857010: ldur            d1, [fp, #-8]
    // 0x857014: StoreField: r0->field_f = d1
    //     0x857014: stur            d1, [x0, #0xf]
    // 0x857018: LeaveFrame
    //     0x857018: mov             SP, fp
    //     0x85701c: ldp             fp, lr, [SP], #0x10
    // 0x857020: ret
    //     0x857020: ret             
    // 0x857024: mov             v0.16b, v5.16b
    // 0x857028: mov             v1.16b, v6.16b
    // 0x85702c: fdiv            d2, d0, d3
    // 0x857030: stur            d2, [fp, #-0x18]
    // 0x857034: fdiv            d0, d1, d3
    // 0x857038: stur            d0, [fp, #-0x10]
    // 0x85703c: r0 = Offset()
    //     0x85703c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x857040: ldur            d0, [fp, #-0x18]
    // 0x857044: StoreField: r0->field_7 = d0
    //     0x857044: stur            d0, [x0, #7]
    // 0x857048: ldur            d0, [fp, #-0x10]
    // 0x85704c: StoreField: r0->field_f = d0
    //     0x85704c: stur            d0, [x0, #0xf]
    // 0x857050: LeaveFrame
    //     0x857050: mov             SP, fp
    //     0x857054: ldp             fp, lr, [SP], #0x10
    // 0x857058: ret
    //     0x857058: ret             
    // 0x85705c: r0 = RangeErrorSharedWithFPURegs()
    //     0x85705c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x857060: r0 = RangeErrorSharedWithFPURegs()
    //     0x857060: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x857064: r0 = RangeErrorSharedWithFPURegs()
    //     0x857064: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x857068: r0 = RangeErrorSharedWithFPURegs()
    //     0x857068: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x85706c: r0 = RangeErrorSharedWithFPURegs()
    //     0x85706c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ transformRect(/* No info */) {
    // ** addr: 0x863e58, size: 0x3a0
    // 0x863e58: EnterFrame
    //     0x863e58: stp             fp, lr, [SP, #-0x10]!
    //     0x863e5c: mov             fp, SP
    // 0x863e60: AllocStack(0x20)
    //     0x863e60: sub             SP, SP, #0x20
    // 0x863e64: CheckStackOverflow
    //     0x863e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x863e68: cmp             SP, x16
    //     0x863e6c: b.ls            #0x8641d8
    // 0x863e70: LoadField: r3 = r1->field_7
    //     0x863e70: ldur            w3, [x1, #7]
    // 0x863e74: DecompressPointer r3
    //     0x863e74: add             x3, x3, HEAP, lsl #32
    // 0x863e78: LoadField: d0 = r2->field_7
    //     0x863e78: ldur            d0, [x2, #7]
    // 0x863e7c: LoadField: d1 = r2->field_f
    //     0x863e7c: ldur            d1, [x2, #0xf]
    // 0x863e80: ArrayLoad: d2 = r2[0]  ; List_8
    //     0x863e80: ldur            d2, [x2, #0x17]
    // 0x863e84: fsub            d3, d2, d0
    // 0x863e88: LoadField: d2 = r2->field_1f
    //     0x863e88: ldur            d2, [x2, #0x1f]
    // 0x863e8c: fsub            d4, d2, d1
    // 0x863e90: mov             x0, v3.d[0]
    // 0x863e94: and             x0, x0, #0x7fffffffffffffff
    // 0x863e98: r17 = 9218868437227405312
    //     0x863e98: mov             x17, #0x7ff0000000000000
    // 0x863e9c: cmp             x0, x17
    // 0x863ea0: b.eq            #0x8641c8
    // 0x863ea4: fcmp            d3, d3
    // 0x863ea8: b.vs            #0x8641c8
    // 0x863eac: mov             x0, v4.d[0]
    // 0x863eb0: and             x0, x0, #0x7fffffffffffffff
    // 0x863eb4: r17 = 9218868437227405312
    //     0x863eb4: mov             x17, #0x7ff0000000000000
    // 0x863eb8: cmp             x0, x17
    // 0x863ebc: b.eq            #0x8641c8
    // 0x863ec0: fcmp            d4, d4
    // 0x863ec4: b.vs            #0x8641c8
    // 0x863ec8: d2 = 0.000000
    //     0x863ec8: eor             v2.16b, v2.16b, v2.16b
    // 0x863ecc: LoadField: r0 = r3->field_13
    //     0x863ecc: ldur            w0, [x3, #0x13]
    // 0x863ed0: r2 = LoadInt32Instr(r0)
    //     0x863ed0: sbfx            x2, x0, #1, #0x1f
    // 0x863ed4: mov             x0, x2
    // 0x863ed8: r1 = 0
    //     0x863ed8: mov             x1, #0
    // 0x863edc: cmp             x1, x0
    // 0x863ee0: b.hs            #0x8641e0
    // 0x863ee4: ArrayLoad: d5 = r3[0]  ; List_8
    //     0x863ee4: ldur            d5, [x3, #0x17]
    // 0x863ee8: fmul            d6, d5, d3
    // 0x863eec: mov             x0, x2
    // 0x863ef0: r1 = 4
    //     0x863ef0: mov             x1, #4
    // 0x863ef4: cmp             x1, x0
    // 0x863ef8: b.hs            #0x8641e4
    // 0x863efc: LoadField: d7 = r3->field_37
    //     0x863efc: ldur            d7, [x3, #0x37]
    // 0x863f00: fmul            d8, d7, d4
    // 0x863f04: fmul            d9, d5, d0
    // 0x863f08: fmul            d5, d7, d1
    // 0x863f0c: fadd            d7, d9, d5
    // 0x863f10: mov             x0, x2
    // 0x863f14: r1 = 12
    //     0x863f14: mov             x1, #0xc
    // 0x863f18: cmp             x1, x0
    // 0x863f1c: b.hs            #0x8641e8
    // 0x863f20: LoadField: d5 = r3->field_77
    //     0x863f20: ldur            d5, [x3, #0x77]
    // 0x863f24: fadd            d9, d7, d5
    // 0x863f28: LoadField: d5 = r3->field_1f
    //     0x863f28: ldur            d5, [x3, #0x1f]
    // 0x863f2c: fmul            d7, d5, d3
    // 0x863f30: LoadField: d10 = r3->field_3f
    //     0x863f30: ldur            d10, [x3, #0x3f]
    // 0x863f34: fmul            d11, d10, d4
    // 0x863f38: fmul            d12, d5, d0
    // 0x863f3c: fmul            d5, d10, d1
    // 0x863f40: fadd            d10, d12, d5
    // 0x863f44: mov             x0, x2
    // 0x863f48: r1 = 13
    //     0x863f48: mov             x1, #0xd
    // 0x863f4c: cmp             x1, x0
    // 0x863f50: b.hs            #0x8641ec
    // 0x863f54: LoadField: d5 = r3->field_7f
    //     0x863f54: ldur            d5, [x3, #0x7f]
    // 0x863f58: fadd            d12, d10, d5
    // 0x863f5c: LoadField: d5 = r3->field_2f
    //     0x863f5c: ldur            d5, [x3, #0x2f]
    // 0x863f60: fcmp            d5, d2
    // 0x863f64: b.ne            #0x864054
    // 0x863f68: LoadField: d10 = r3->field_4f
    //     0x863f68: ldur            d10, [x3, #0x4f]
    // 0x863f6c: fcmp            d10, d2
    // 0x863f70: b.ne            #0x864054
    // 0x863f74: d10 = 1.000000
    //     0x863f74: fmov            d10, #1.00000000
    // 0x863f78: mov             x0, x2
    // 0x863f7c: r1 = 15
    //     0x863f7c: mov             x1, #0xf
    // 0x863f80: cmp             x1, x0
    // 0x863f84: b.hs            #0x8641f0
    // 0x863f88: LoadField: d13 = r3->field_8f
    //     0x863f88: ldur            d13, [x3, #0x8f]
    // 0x863f8c: fcmp            d13, d10
    // 0x863f90: b.ne            #0x864054
    // 0x863f94: fcmp            d2, d6
    // 0x863f98: b.le            #0x863fac
    // 0x863f9c: fadd            d0, d9, d6
    // 0x863fa0: mov             v1.16b, v0.16b
    // 0x863fa4: mov             v0.16b, v9.16b
    // 0x863fa8: b               #0x863fb4
    // 0x863fac: fadd            d0, d9, d6
    // 0x863fb0: mov             v1.16b, v9.16b
    // 0x863fb4: fcmp            d2, d8
    // 0x863fb8: b.le            #0x863fc8
    // 0x863fbc: fadd            d3, d1, d8
    // 0x863fc0: mov             v1.16b, v3.16b
    // 0x863fc4: b               #0x863fd0
    // 0x863fc8: fadd            d3, d0, d8
    // 0x863fcc: mov             v0.16b, v3.16b
    // 0x863fd0: stur            d1, [fp, #-0x18]
    // 0x863fd4: stur            d0, [fp, #-0x20]
    // 0x863fd8: fcmp            d2, d7
    // 0x863fdc: b.le            #0x863ff0
    // 0x863fe0: fadd            d3, d12, d7
    // 0x863fe4: mov             v4.16b, v3.16b
    // 0x863fe8: mov             v3.16b, v12.16b
    // 0x863fec: b               #0x863ff8
    // 0x863ff0: fadd            d3, d12, d7
    // 0x863ff4: mov             v4.16b, v12.16b
    // 0x863ff8: fcmp            d2, d11
    // 0x863ffc: b.le            #0x864014
    // 0x864000: fadd            d2, d4, d11
    // 0x864004: mov             v31.16b, v3.16b
    // 0x864008: mov             v3.16b, v2.16b
    // 0x86400c: mov             v2.16b, v31.16b
    // 0x864010: b               #0x86401c
    // 0x864014: fadd            d2, d3, d11
    // 0x864018: mov             v3.16b, v4.16b
    // 0x86401c: stur            d3, [fp, #-8]
    // 0x864020: stur            d2, [fp, #-0x10]
    // 0x864024: r0 = Rect()
    //     0x864024: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x864028: ldur            d0, [fp, #-0x18]
    // 0x86402c: StoreField: r0->field_7 = d0
    //     0x86402c: stur            d0, [x0, #7]
    // 0x864030: ldur            d0, [fp, #-8]
    // 0x864034: StoreField: r0->field_f = d0
    //     0x864034: stur            d0, [x0, #0xf]
    // 0x864038: ldur            d0, [fp, #-0x20]
    // 0x86403c: ArrayStore: r0[0] = d0  ; List_8
    //     0x86403c: stur            d0, [x0, #0x17]
    // 0x864040: ldur            d0, [fp, #-0x10]
    // 0x864044: StoreField: r0->field_1f = d0
    //     0x864044: stur            d0, [x0, #0x1f]
    // 0x864048: LeaveFrame
    //     0x864048: mov             SP, fp
    //     0x86404c: ldp             fp, lr, [SP], #0x10
    // 0x864050: ret
    //     0x864050: ret             
    // 0x864054: fmul            d2, d5, d3
    // 0x864058: LoadField: d3 = r3->field_4f
    //     0x864058: ldur            d3, [x3, #0x4f]
    // 0x86405c: fmul            d10, d3, d4
    // 0x864060: fmul            d4, d5, d0
    // 0x864064: fmul            d0, d3, d1
    // 0x864068: fadd            d1, d4, d0
    // 0x86406c: mov             x0, x2
    // 0x864070: r1 = 15
    //     0x864070: mov             x1, #0xf
    // 0x864074: cmp             x1, x0
    // 0x864078: b.hs            #0x8641f4
    // 0x86407c: LoadField: d0 = r3->field_8f
    //     0x86407c: ldur            d0, [x3, #0x8f]
    // 0x864080: fadd            d3, d1, d0
    // 0x864084: fdiv            d0, d9, d3
    // 0x864088: fdiv            d1, d12, d3
    // 0x86408c: fadd            d4, d9, d6
    // 0x864090: fadd            d5, d3, d2
    // 0x864094: fdiv            d2, d4, d5
    // 0x864098: fadd            d6, d12, d7
    // 0x86409c: fdiv            d7, d6, d5
    // 0x8640a0: fadd            d13, d9, d8
    // 0x8640a4: fadd            d9, d3, d10
    // 0x8640a8: fdiv            d3, d13, d9
    // 0x8640ac: fadd            d13, d12, d11
    // 0x8640b0: fdiv            d12, d13, d9
    // 0x8640b4: fadd            d9, d4, d8
    // 0x8640b8: fadd            d4, d5, d10
    // 0x8640bc: fdiv            d5, d9, d4
    // 0x8640c0: fadd            d8, d6, d11
    // 0x8640c4: fdiv            d6, d8, d4
    // 0x8640c8: fcmp            d2, d0
    // 0x8640cc: b.le            #0x8640d8
    // 0x8640d0: mov             v4.16b, v0.16b
    // 0x8640d4: b               #0x8640dc
    // 0x8640d8: mov             v4.16b, v2.16b
    // 0x8640dc: fcmp            d5, d3
    // 0x8640e0: b.le            #0x8640ec
    // 0x8640e4: mov             v8.16b, v3.16b
    // 0x8640e8: b               #0x8640f0
    // 0x8640ec: mov             v8.16b, v5.16b
    // 0x8640f0: fcmp            d8, d4
    // 0x8640f4: b.gt            #0x8640fc
    // 0x8640f8: mov             v4.16b, v8.16b
    // 0x8640fc: stur            d4, [fp, #-0x20]
    // 0x864100: fcmp            d7, d1
    // 0x864104: b.le            #0x864110
    // 0x864108: mov             v8.16b, v1.16b
    // 0x86410c: b               #0x864114
    // 0x864110: mov             v8.16b, v7.16b
    // 0x864114: fcmp            d6, d12
    // 0x864118: b.le            #0x864124
    // 0x86411c: mov             v9.16b, v12.16b
    // 0x864120: b               #0x864128
    // 0x864124: mov             v9.16b, v6.16b
    // 0x864128: fcmp            d9, d8
    // 0x86412c: b.gt            #0x864134
    // 0x864130: mov             v8.16b, v9.16b
    // 0x864134: stur            d8, [fp, #-0x18]
    // 0x864138: fcmp            d0, d2
    // 0x86413c: b.gt            #0x864144
    // 0x864140: mov             v0.16b, v2.16b
    // 0x864144: fcmp            d3, d5
    // 0x864148: b.le            #0x864154
    // 0x86414c: mov             v2.16b, v3.16b
    // 0x864150: b               #0x864158
    // 0x864154: mov             v2.16b, v5.16b
    // 0x864158: fcmp            d0, d2
    // 0x86415c: b.gt            #0x864164
    // 0x864160: mov             v0.16b, v2.16b
    // 0x864164: stur            d0, [fp, #-0x10]
    // 0x864168: fcmp            d1, d7
    // 0x86416c: b.gt            #0x864174
    // 0x864170: mov             v1.16b, v7.16b
    // 0x864174: fcmp            d12, d6
    // 0x864178: b.le            #0x864184
    // 0x86417c: mov             v2.16b, v12.16b
    // 0x864180: b               #0x864188
    // 0x864184: mov             v2.16b, v6.16b
    // 0x864188: fcmp            d1, d2
    // 0x86418c: b.gt            #0x864194
    // 0x864190: mov             v1.16b, v2.16b
    // 0x864194: stur            d1, [fp, #-8]
    // 0x864198: r0 = Rect()
    //     0x864198: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x86419c: ldur            d0, [fp, #-0x20]
    // 0x8641a0: StoreField: r0->field_7 = d0
    //     0x8641a0: stur            d0, [x0, #7]
    // 0x8641a4: ldur            d0, [fp, #-0x18]
    // 0x8641a8: StoreField: r0->field_f = d0
    //     0x8641a8: stur            d0, [x0, #0xf]
    // 0x8641ac: ldur            d0, [fp, #-0x10]
    // 0x8641b0: ArrayStore: r0[0] = d0  ; List_8
    //     0x8641b0: stur            d0, [x0, #0x17]
    // 0x8641b4: ldur            d0, [fp, #-8]
    // 0x8641b8: StoreField: r0->field_1f = d0
    //     0x8641b8: stur            d0, [x0, #0x1f]
    // 0x8641bc: LeaveFrame
    //     0x8641bc: mov             SP, fp
    //     0x8641c0: ldp             fp, lr, [SP], #0x10
    // 0x8641c4: ret
    //     0x8641c4: ret             
    // 0x8641c8: r0 = _safeTransformRect()
    //     0x8641c8: bl              #0x8641f8  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_safeTransformRect
    // 0x8641cc: LeaveFrame
    //     0x8641cc: mov             SP, fp
    //     0x8641d0: ldp             fp, lr, [SP], #0x10
    // 0x8641d4: ret
    //     0x8641d4: ret             
    // 0x8641d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8641d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8641dc: b               #0x863e70
    // 0x8641e0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641e0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8641e4: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641e4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8641e8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641e8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8641ec: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641ec: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8641f0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641f0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8641f4: r0 = RangeErrorSharedWithFPURegs()
    //     0x8641f4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ _safeTransformRect(/* No info */) {
    // ** addr: 0x8641f8, size: 0x208
    // 0x8641f8: EnterFrame
    //     0x8641f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8641fc: mov             fp, SP
    // 0x864200: AllocStack(0x38)
    //     0x864200: sub             SP, SP, #0x38
    // 0x864204: d0 = 0.000000
    //     0x864204: eor             v0.16b, v0.16b, v0.16b
    // 0x864208: mov             x4, x2
    // 0x86420c: stur            x2, [fp, #-0x18]
    // 0x864210: CheckStackOverflow
    //     0x864210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x864214: cmp             SP, x16
    //     0x864218: b.ls            #0x8643dc
    // 0x86421c: LoadField: r5 = r1->field_7
    //     0x86421c: ldur            w5, [x1, #7]
    // 0x864220: DecompressPointer r5
    //     0x864220: add             x5, x5, HEAP, lsl #32
    // 0x864224: stur            x5, [fp, #-0x10]
    // 0x864228: LoadField: r0 = r5->field_13
    //     0x864228: ldur            w0, [x5, #0x13]
    // 0x86422c: r2 = LoadInt32Instr(r0)
    //     0x86422c: sbfx            x2, x0, #1, #0x1f
    // 0x864230: mov             x0, x2
    // 0x864234: r1 = 3
    //     0x864234: mov             x1, #3
    // 0x864238: cmp             x1, x0
    // 0x86423c: b.hs            #0x8643e4
    // 0x864240: LoadField: d1 = r5->field_2f
    //     0x864240: ldur            d1, [x5, #0x2f]
    // 0x864244: fcmp            d1, d0
    // 0x864248: b.ne            #0x864294
    // 0x86424c: mov             x0, x2
    // 0x864250: r1 = 7
    //     0x864250: mov             x1, #7
    // 0x864254: cmp             x1, x0
    // 0x864258: b.hs            #0x8643e8
    // 0x86425c: LoadField: d1 = r5->field_4f
    //     0x86425c: ldur            d1, [x5, #0x4f]
    // 0x864260: fcmp            d1, d0
    // 0x864264: b.ne            #0x864294
    // 0x864268: d0 = 1.000000
    //     0x864268: fmov            d0, #1.00000000
    // 0x86426c: mov             x0, x2
    // 0x864270: r1 = 15
    //     0x864270: mov             x1, #0xf
    // 0x864274: cmp             x1, x0
    // 0x864278: b.hs            #0x8643ec
    // 0x86427c: LoadField: d1 = r5->field_8f
    //     0x86427c: ldur            d1, [x5, #0x8f]
    // 0x864280: fcmp            d1, d0
    // 0x864284: r16 = true
    //     0x864284: add             x16, NULL, #0x20  ; true
    // 0x864288: r17 = false
    //     0x864288: add             x17, NULL, #0x30  ; false
    // 0x86428c: csel            x0, x16, x17, eq
    // 0x864290: b               #0x864298
    // 0x864294: r0 = false
    //     0x864294: add             x0, NULL, #0x30  ; false
    // 0x864298: stur            x0, [fp, #-8]
    // 0x86429c: LoadField: d2 = r4->field_7
    //     0x86429c: ldur            d2, [x4, #7]
    // 0x8642a0: stur            d2, [fp, #-0x28]
    // 0x8642a4: LoadField: d3 = r4->field_f
    //     0x8642a4: ldur            d3, [x4, #0xf]
    // 0x8642a8: mov             x1, x5
    // 0x8642ac: mov             v0.16b, v2.16b
    // 0x8642b0: mov             v1.16b, v3.16b
    // 0x8642b4: mov             x3, x0
    // 0x8642b8: stur            d3, [fp, #-0x20]
    // 0x8642bc: r2 = true
    //     0x8642bc: add             x2, NULL, #0x20  ; true
    // 0x8642c0: r0 = _accumulate()
    //     0x8642c0: bl              #0x864400  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x8642c4: ldur            x0, [fp, #-0x18]
    // 0x8642c8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x8642c8: ldur            d2, [x0, #0x17]
    // 0x8642cc: ldur            x1, [fp, #-0x10]
    // 0x8642d0: mov             v0.16b, v2.16b
    // 0x8642d4: ldur            d1, [fp, #-0x20]
    // 0x8642d8: ldur            x3, [fp, #-8]
    // 0x8642dc: stur            d2, [fp, #-0x30]
    // 0x8642e0: r2 = false
    //     0x8642e0: add             x2, NULL, #0x30  ; false
    // 0x8642e4: r0 = _accumulate()
    //     0x8642e4: bl              #0x864400  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x8642e8: ldur            x0, [fp, #-0x18]
    // 0x8642ec: LoadField: d2 = r0->field_1f
    //     0x8642ec: ldur            d2, [x0, #0x1f]
    // 0x8642f0: ldur            x1, [fp, #-0x10]
    // 0x8642f4: ldur            d0, [fp, #-0x28]
    // 0x8642f8: mov             v1.16b, v2.16b
    // 0x8642fc: ldur            x3, [fp, #-8]
    // 0x864300: stur            d2, [fp, #-0x20]
    // 0x864304: r2 = false
    //     0x864304: add             x2, NULL, #0x30  ; false
    // 0x864308: r0 = _accumulate()
    //     0x864308: bl              #0x864400  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x86430c: ldur            x1, [fp, #-0x10]
    // 0x864310: ldur            d0, [fp, #-0x30]
    // 0x864314: ldur            d1, [fp, #-0x20]
    // 0x864318: ldur            x3, [fp, #-8]
    // 0x86431c: r2 = false
    //     0x86431c: add             x2, NULL, #0x30  ; false
    // 0x864320: r0 = _accumulate()
    //     0x864320: bl              #0x864400  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x864324: r0 = LoadStaticField(0xce4)
    //     0x864324: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x864328: ldr             x0, [x0, #0x19c8]
    // 0x86432c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x864330: cmp             w0, w16
    // 0x864334: b.ne            #0x864340
    // 0x864338: r2 = _minMax
    //     0x864338: ldr             x2, [PP, #0x2a38]  ; [pp+0x2a38] Field <MatrixUtils._minMax@801374251>: static late final (offset: 0xce4)
    // 0x86433c: r0 = InitLateFinalStaticField()
    //     0x86433c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x864340: mov             x2, x0
    // 0x864344: LoadField: r0 = r2->field_13
    //     0x864344: ldur            w0, [x2, #0x13]
    // 0x864348: r3 = LoadInt32Instr(r0)
    //     0x864348: sbfx            x3, x0, #1, #0x1f
    // 0x86434c: mov             x0, x3
    // 0x864350: r1 = 0
    //     0x864350: mov             x1, #0
    // 0x864354: cmp             x1, x0
    // 0x864358: b.hs            #0x8643f0
    // 0x86435c: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x86435c: ldur            d0, [x2, #0x17]
    // 0x864360: mov             x0, x3
    // 0x864364: stur            d0, [fp, #-0x38]
    // 0x864368: r1 = 1
    //     0x864368: mov             x1, #1
    // 0x86436c: cmp             x1, x0
    // 0x864370: b.hs            #0x8643f4
    // 0x864374: LoadField: d1 = r2->field_1f
    //     0x864374: ldur            d1, [x2, #0x1f]
    // 0x864378: mov             x0, x3
    // 0x86437c: stur            d1, [fp, #-0x30]
    // 0x864380: r1 = 2
    //     0x864380: mov             x1, #2
    // 0x864384: cmp             x1, x0
    // 0x864388: b.hs            #0x8643f8
    // 0x86438c: LoadField: d2 = r2->field_27
    //     0x86438c: ldur            d2, [x2, #0x27]
    // 0x864390: mov             x0, x3
    // 0x864394: stur            d2, [fp, #-0x28]
    // 0x864398: r1 = 3
    //     0x864398: mov             x1, #3
    // 0x86439c: cmp             x1, x0
    // 0x8643a0: b.hs            #0x8643fc
    // 0x8643a4: LoadField: d3 = r2->field_2f
    //     0x8643a4: ldur            d3, [x2, #0x2f]
    // 0x8643a8: stur            d3, [fp, #-0x20]
    // 0x8643ac: r0 = Rect()
    //     0x8643ac: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8643b0: ldur            d0, [fp, #-0x38]
    // 0x8643b4: StoreField: r0->field_7 = d0
    //     0x8643b4: stur            d0, [x0, #7]
    // 0x8643b8: ldur            d0, [fp, #-0x30]
    // 0x8643bc: StoreField: r0->field_f = d0
    //     0x8643bc: stur            d0, [x0, #0xf]
    // 0x8643c0: ldur            d0, [fp, #-0x28]
    // 0x8643c4: ArrayStore: r0[0] = d0  ; List_8
    //     0x8643c4: stur            d0, [x0, #0x17]
    // 0x8643c8: ldur            d0, [fp, #-0x20]
    // 0x8643cc: StoreField: r0->field_1f = d0
    //     0x8643cc: stur            d0, [x0, #0x1f]
    // 0x8643d0: LeaveFrame
    //     0x8643d0: mov             SP, fp
    //     0x8643d4: ldp             fp, lr, [SP], #0x10
    // 0x8643d8: ret
    //     0x8643d8: ret             
    // 0x8643dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x8643dc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x8643e0: b               #0x86421c
    // 0x8643e4: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643e4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8643e8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643e8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8643ec: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643ec: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8643f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8643f0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8643f4: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643f4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8643f8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643f8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8643fc: r0 = RangeErrorSharedWithFPURegs()
    //     0x8643fc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ _accumulate(/* No info */) {
    // ** addr: 0x864400, size: 0x284
    // 0x864400: EnterFrame
    //     0x864400: stp             fp, lr, [SP, #-0x10]!
    //     0x864404: mov             fp, SP
    // 0x864408: AllocStack(0x10)
    //     0x864408: sub             SP, SP, #0x10
    // 0x86440c: SetupParameters(dynamic _ /* r1 => r4 */)
    //     0x86440c: mov             x4, x1
    // 0x864410: CheckStackOverflow
    //     0x864410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x864414: cmp             SP, x16
    //     0x864418: b.ls            #0x864648
    // 0x86441c: tbnz            w3, #4, #0x864428
    // 0x864420: d2 = 1.000000
    //     0x864420: fmov            d2, #1.00000000
    // 0x864424: b               #0x864488
    // 0x864428: d2 = 1.000000
    //     0x864428: fmov            d2, #1.00000000
    // 0x86442c: LoadField: r0 = r4->field_13
    //     0x86442c: ldur            w0, [x4, #0x13]
    // 0x864430: r3 = LoadInt32Instr(r0)
    //     0x864430: sbfx            x3, x0, #1, #0x1f
    // 0x864434: mov             x0, x3
    // 0x864438: r1 = 3
    //     0x864438: mov             x1, #3
    // 0x86443c: cmp             x1, x0
    // 0x864440: b.hs            #0x864650
    // 0x864444: LoadField: d3 = r4->field_2f
    //     0x864444: ldur            d3, [x4, #0x2f]
    // 0x864448: fmul            d4, d3, d0
    // 0x86444c: mov             x0, x3
    // 0x864450: r1 = 7
    //     0x864450: mov             x1, #7
    // 0x864454: cmp             x1, x0
    // 0x864458: b.hs            #0x864654
    // 0x86445c: LoadField: d3 = r4->field_4f
    //     0x86445c: ldur            d3, [x4, #0x4f]
    // 0x864460: fmul            d5, d3, d1
    // 0x864464: fadd            d3, d4, d5
    // 0x864468: mov             x0, x3
    // 0x86446c: r1 = 15
    //     0x86446c: mov             x1, #0xf
    // 0x864470: cmp             x1, x0
    // 0x864474: b.hs            #0x864658
    // 0x864478: LoadField: d4 = r4->field_8f
    //     0x864478: ldur            d4, [x4, #0x8f]
    // 0x86447c: fadd            d5, d3, d4
    // 0x864480: fdiv            d3, d2, d5
    // 0x864484: mov             v2.16b, v3.16b
    // 0x864488: LoadField: r0 = r4->field_13
    //     0x864488: ldur            w0, [x4, #0x13]
    // 0x86448c: r3 = LoadInt32Instr(r0)
    //     0x86448c: sbfx            x3, x0, #1, #0x1f
    // 0x864490: mov             x0, x3
    // 0x864494: r1 = 0
    //     0x864494: mov             x1, #0
    // 0x864498: cmp             x1, x0
    // 0x86449c: b.hs            #0x86465c
    // 0x8644a0: ArrayLoad: d3 = r4[0]  ; List_8
    //     0x8644a0: ldur            d3, [x4, #0x17]
    // 0x8644a4: fmul            d4, d3, d0
    // 0x8644a8: mov             x0, x3
    // 0x8644ac: r1 = 4
    //     0x8644ac: mov             x1, #4
    // 0x8644b0: cmp             x1, x0
    // 0x8644b4: b.hs            #0x864660
    // 0x8644b8: LoadField: d3 = r4->field_37
    //     0x8644b8: ldur            d3, [x4, #0x37]
    // 0x8644bc: fmul            d5, d3, d1
    // 0x8644c0: fadd            d3, d4, d5
    // 0x8644c4: mov             x0, x3
    // 0x8644c8: r1 = 12
    //     0x8644c8: mov             x1, #0xc
    // 0x8644cc: cmp             x1, x0
    // 0x8644d0: b.hs            #0x864664
    // 0x8644d4: LoadField: d4 = r4->field_77
    //     0x8644d4: ldur            d4, [x4, #0x77]
    // 0x8644d8: fadd            d5, d3, d4
    // 0x8644dc: fmul            d3, d5, d2
    // 0x8644e0: stur            d3, [fp, #-0x10]
    // 0x8644e4: LoadField: d4 = r4->field_1f
    //     0x8644e4: ldur            d4, [x4, #0x1f]
    // 0x8644e8: fmul            d5, d4, d0
    // 0x8644ec: LoadField: d0 = r4->field_3f
    //     0x8644ec: ldur            d0, [x4, #0x3f]
    // 0x8644f0: fmul            d4, d0, d1
    // 0x8644f4: fadd            d0, d5, d4
    // 0x8644f8: mov             x0, x3
    // 0x8644fc: r1 = 13
    //     0x8644fc: mov             x1, #0xd
    // 0x864500: cmp             x1, x0
    // 0x864504: b.hs            #0x864668
    // 0x864508: LoadField: d1 = r4->field_7f
    //     0x864508: ldur            d1, [x4, #0x7f]
    // 0x86450c: fadd            d4, d0, d1
    // 0x864510: fmul            d0, d4, d2
    // 0x864514: stur            d0, [fp, #-8]
    // 0x864518: tbnz            w2, #4, #0x864580
    // 0x86451c: r0 = LoadStaticField(0xce4)
    //     0x86451c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x864520: ldr             x0, [x0, #0x19c8]
    // 0x864524: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x864528: cmp             w0, w16
    // 0x86452c: b.ne            #0x864538
    // 0x864530: r2 = _minMax
    //     0x864530: ldr             x2, [PP, #0x2a38]  ; [pp+0x2a38] Field <MatrixUtils._minMax@801374251>: static late final (offset: 0xce4)
    // 0x864534: r0 = InitLateFinalStaticField()
    //     0x864534: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x864538: mov             x2, x0
    // 0x86453c: LoadField: r0 = r2->field_13
    //     0x86453c: ldur            w0, [x2, #0x13]
    // 0x864540: r3 = LoadInt32Instr(r0)
    //     0x864540: sbfx            x3, x0, #1, #0x1f
    // 0x864544: mov             x0, x3
    // 0x864548: r1 = 2
    //     0x864548: mov             x1, #2
    // 0x86454c: cmp             x1, x0
    // 0x864550: b.hs            #0x86466c
    // 0x864554: ldur            d0, [fp, #-0x10]
    // 0x864558: StoreField: r2->field_27 = d0
    //     0x864558: stur            d0, [x2, #0x27]
    // 0x86455c: ArrayStore: r2[0] = d0  ; List_8
    //     0x86455c: stur            d0, [x2, #0x17]
    // 0x864560: mov             x0, x3
    // 0x864564: r1 = 3
    //     0x864564: mov             x1, #3
    // 0x864568: cmp             x1, x0
    // 0x86456c: b.hs            #0x864670
    // 0x864570: ldur            d1, [fp, #-8]
    // 0x864574: StoreField: r2->field_2f = d1
    //     0x864574: stur            d1, [x2, #0x2f]
    // 0x864578: StoreField: r2->field_1f = d1
    //     0x864578: stur            d1, [x2, #0x1f]
    // 0x86457c: b               #0x864638
    // 0x864580: mov             v1.16b, v0.16b
    // 0x864584: mov             v0.16b, v3.16b
    // 0x864588: r0 = LoadStaticField(0xce4)
    //     0x864588: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x86458c: ldr             x0, [x0, #0x19c8]
    // 0x864590: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x864594: cmp             w0, w16
    // 0x864598: b.ne            #0x8645a4
    // 0x86459c: r2 = _minMax
    //     0x86459c: ldr             x2, [PP, #0x2a38]  ; [pp+0x2a38] Field <MatrixUtils._minMax@801374251>: static late final (offset: 0xce4)
    // 0x8645a0: r0 = InitLateFinalStaticField()
    //     0x8645a0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8645a4: mov             x2, x0
    // 0x8645a8: LoadField: r3 = r2->field_13
    //     0x8645a8: ldur            w3, [x2, #0x13]
    // 0x8645ac: r4 = LoadInt32Instr(r3)
    //     0x8645ac: sbfx            x4, x3, #1, #0x1f
    // 0x8645b0: mov             x0, x4
    // 0x8645b4: r1 = 0
    //     0x8645b4: mov             x1, #0
    // 0x8645b8: cmp             x1, x0
    // 0x8645bc: b.hs            #0x864674
    // 0x8645c0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x8645c0: ldur            d0, [x2, #0x17]
    // 0x8645c4: ldur            d1, [fp, #-0x10]
    // 0x8645c8: fcmp            d0, d1
    // 0x8645cc: b.le            #0x8645d4
    // 0x8645d0: ArrayStore: r2[0] = d1  ; List_8
    //     0x8645d0: stur            d1, [x2, #0x17]
    // 0x8645d4: ldur            d0, [fp, #-8]
    // 0x8645d8: mov             x0, x4
    // 0x8645dc: r1 = 1
    //     0x8645dc: mov             x1, #1
    // 0x8645e0: cmp             x1, x0
    // 0x8645e4: b.hs            #0x864678
    // 0x8645e8: LoadField: d2 = r2->field_1f
    //     0x8645e8: ldur            d2, [x2, #0x1f]
    // 0x8645ec: fcmp            d2, d0
    // 0x8645f0: b.le            #0x8645f8
    // 0x8645f4: StoreField: r2->field_1f = d0
    //     0x8645f4: stur            d0, [x2, #0x1f]
    // 0x8645f8: mov             x0, x4
    // 0x8645fc: r1 = 2
    //     0x8645fc: mov             x1, #2
    // 0x864600: cmp             x1, x0
    // 0x864604: b.hs            #0x86467c
    // 0x864608: LoadField: d2 = r2->field_27
    //     0x864608: ldur            d2, [x2, #0x27]
    // 0x86460c: fcmp            d1, d2
    // 0x864610: b.le            #0x864618
    // 0x864614: StoreField: r2->field_27 = d1
    //     0x864614: stur            d1, [x2, #0x27]
    // 0x864618: mov             x0, x4
    // 0x86461c: r1 = 3
    //     0x86461c: mov             x1, #3
    // 0x864620: cmp             x1, x0
    // 0x864624: b.hs            #0x864680
    // 0x864628: LoadField: d1 = r2->field_2f
    //     0x864628: ldur            d1, [x2, #0x2f]
    // 0x86462c: fcmp            d0, d1
    // 0x864630: b.le            #0x864638
    // 0x864634: StoreField: r2->field_2f = d0
    //     0x864634: stur            d0, [x2, #0x2f]
    // 0x864638: r0 = Null
    //     0x864638: mov             x0, NULL
    // 0x86463c: LeaveFrame
    //     0x86463c: mov             SP, fp
    //     0x864640: ldp             fp, lr, [SP], #0x10
    // 0x864644: ret
    //     0x864644: ret             
    // 0x864648: r0 = StackOverflowSharedWithFPURegs()
    //     0x864648: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x86464c: b               #0x86441c
    // 0x864650: r0 = RangeErrorSharedWithFPURegs()
    //     0x864650: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864654: r0 = RangeErrorSharedWithFPURegs()
    //     0x864654: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864658: r0 = RangeErrorSharedWithFPURegs()
    //     0x864658: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x86465c: r0 = RangeErrorSharedWithFPURegs()
    //     0x86465c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864660: r0 = RangeErrorSharedWithFPURegs()
    //     0x864660: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864664: r0 = RangeErrorSharedWithFPURegs()
    //     0x864664: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864668: r0 = RangeErrorSharedWithFPURegs()
    //     0x864668: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x86466c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x86466c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x864670: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x864670: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x864674: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x864674: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x864678: r0 = RangeErrorSharedWithFPURegs()
    //     0x864678: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x86467c: r0 = RangeErrorSharedWithFPURegs()
    //     0x86467c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x864680: r0 = RangeErrorSharedWithFPURegs()
    //     0x864680: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static Float64List _minMax() {
    // ** addr: 0x864684, size: 0x1c
    // 0x864684: EnterFrame
    //     0x864684: stp             fp, lr, [SP, #-0x10]!
    //     0x864688: mov             fp, SP
    // 0x86468c: r4 = 8
    //     0x86468c: mov             x4, #8
    // 0x864690: r0 = AllocateFloat64Array()
    //     0x864690: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x864694: LeaveFrame
    //     0x864694: mov             SP, fp
    //     0x864698: ldp             fp, lr, [SP], #0x10
    // 0x86469c: ret
    //     0x86469c: ret             
  }
  static _ isIdentity(/* No info */) {
    // ** addr: 0x892998, size: 0x240
    // 0x892998: EnterFrame
    //     0x892998: stp             fp, lr, [SP, #-0x10]!
    //     0x89299c: mov             fp, SP
    // 0x8929a0: d0 = 1.000000
    //     0x8929a0: fmov            d0, #1.00000000
    // 0x8929a4: LoadField: r2 = r1->field_7
    //     0x8929a4: ldur            w2, [x1, #7]
    // 0x8929a8: DecompressPointer r2
    //     0x8929a8: add             x2, x2, HEAP, lsl #32
    // 0x8929ac: LoadField: r3 = r2->field_13
    //     0x8929ac: ldur            w3, [x2, #0x13]
    // 0x8929b0: r4 = LoadInt32Instr(r3)
    //     0x8929b0: sbfx            x4, x3, #1, #0x1f
    // 0x8929b4: mov             x0, x4
    // 0x8929b8: r1 = 0
    //     0x8929b8: mov             x1, #0
    // 0x8929bc: cmp             x1, x0
    // 0x8929c0: b.hs            #0x892b98
    // 0x8929c4: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x8929c4: ldur            d1, [x2, #0x17]
    // 0x8929c8: fcmp            d1, d0
    // 0x8929cc: b.ne            #0x892b88
    // 0x8929d0: d1 = 0.000000
    //     0x8929d0: eor             v1.16b, v1.16b, v1.16b
    // 0x8929d4: mov             x0, x4
    // 0x8929d8: r1 = 1
    //     0x8929d8: mov             x1, #1
    // 0x8929dc: cmp             x1, x0
    // 0x8929e0: b.hs            #0x892b9c
    // 0x8929e4: LoadField: d2 = r2->field_1f
    //     0x8929e4: ldur            d2, [x2, #0x1f]
    // 0x8929e8: fcmp            d2, d1
    // 0x8929ec: b.ne            #0x892b88
    // 0x8929f0: mov             x0, x4
    // 0x8929f4: r1 = 2
    //     0x8929f4: mov             x1, #2
    // 0x8929f8: cmp             x1, x0
    // 0x8929fc: b.hs            #0x892ba0
    // 0x892a00: LoadField: d2 = r2->field_27
    //     0x892a00: ldur            d2, [x2, #0x27]
    // 0x892a04: fcmp            d2, d1
    // 0x892a08: b.ne            #0x892b88
    // 0x892a0c: mov             x0, x4
    // 0x892a10: r1 = 3
    //     0x892a10: mov             x1, #3
    // 0x892a14: cmp             x1, x0
    // 0x892a18: b.hs            #0x892ba4
    // 0x892a1c: LoadField: d2 = r2->field_2f
    //     0x892a1c: ldur            d2, [x2, #0x2f]
    // 0x892a20: fcmp            d2, d1
    // 0x892a24: b.ne            #0x892b88
    // 0x892a28: mov             x0, x4
    // 0x892a2c: r1 = 4
    //     0x892a2c: mov             x1, #4
    // 0x892a30: cmp             x1, x0
    // 0x892a34: b.hs            #0x892ba8
    // 0x892a38: LoadField: d2 = r2->field_37
    //     0x892a38: ldur            d2, [x2, #0x37]
    // 0x892a3c: fcmp            d2, d1
    // 0x892a40: b.ne            #0x892b88
    // 0x892a44: mov             x0, x4
    // 0x892a48: r1 = 5
    //     0x892a48: mov             x1, #5
    // 0x892a4c: cmp             x1, x0
    // 0x892a50: b.hs            #0x892bac
    // 0x892a54: LoadField: d2 = r2->field_3f
    //     0x892a54: ldur            d2, [x2, #0x3f]
    // 0x892a58: fcmp            d2, d0
    // 0x892a5c: b.ne            #0x892b88
    // 0x892a60: mov             x0, x4
    // 0x892a64: r1 = 6
    //     0x892a64: mov             x1, #6
    // 0x892a68: cmp             x1, x0
    // 0x892a6c: b.hs            #0x892bb0
    // 0x892a70: LoadField: d2 = r2->field_47
    //     0x892a70: ldur            d2, [x2, #0x47]
    // 0x892a74: fcmp            d2, d1
    // 0x892a78: b.ne            #0x892b88
    // 0x892a7c: mov             x0, x4
    // 0x892a80: r1 = 7
    //     0x892a80: mov             x1, #7
    // 0x892a84: cmp             x1, x0
    // 0x892a88: b.hs            #0x892bb4
    // 0x892a8c: LoadField: d2 = r2->field_4f
    //     0x892a8c: ldur            d2, [x2, #0x4f]
    // 0x892a90: fcmp            d2, d1
    // 0x892a94: b.ne            #0x892b88
    // 0x892a98: mov             x0, x4
    // 0x892a9c: r1 = 8
    //     0x892a9c: mov             x1, #8
    // 0x892aa0: cmp             x1, x0
    // 0x892aa4: b.hs            #0x892bb8
    // 0x892aa8: LoadField: d2 = r2->field_57
    //     0x892aa8: ldur            d2, [x2, #0x57]
    // 0x892aac: fcmp            d2, d1
    // 0x892ab0: b.ne            #0x892b88
    // 0x892ab4: mov             x0, x4
    // 0x892ab8: r1 = 9
    //     0x892ab8: mov             x1, #9
    // 0x892abc: cmp             x1, x0
    // 0x892ac0: b.hs            #0x892bbc
    // 0x892ac4: LoadField: d2 = r2->field_5f
    //     0x892ac4: ldur            d2, [x2, #0x5f]
    // 0x892ac8: fcmp            d2, d1
    // 0x892acc: b.ne            #0x892b88
    // 0x892ad0: mov             x0, x4
    // 0x892ad4: r1 = 10
    //     0x892ad4: mov             x1, #0xa
    // 0x892ad8: cmp             x1, x0
    // 0x892adc: b.hs            #0x892bc0
    // 0x892ae0: LoadField: d2 = r2->field_67
    //     0x892ae0: ldur            d2, [x2, #0x67]
    // 0x892ae4: fcmp            d2, d0
    // 0x892ae8: b.ne            #0x892b88
    // 0x892aec: mov             x0, x4
    // 0x892af0: r1 = 11
    //     0x892af0: mov             x1, #0xb
    // 0x892af4: cmp             x1, x0
    // 0x892af8: b.hs            #0x892bc4
    // 0x892afc: LoadField: d2 = r2->field_6f
    //     0x892afc: ldur            d2, [x2, #0x6f]
    // 0x892b00: fcmp            d2, d1
    // 0x892b04: b.ne            #0x892b88
    // 0x892b08: mov             x0, x4
    // 0x892b0c: r1 = 12
    //     0x892b0c: mov             x1, #0xc
    // 0x892b10: cmp             x1, x0
    // 0x892b14: b.hs            #0x892bc8
    // 0x892b18: LoadField: d2 = r2->field_77
    //     0x892b18: ldur            d2, [x2, #0x77]
    // 0x892b1c: fcmp            d2, d1
    // 0x892b20: b.ne            #0x892b88
    // 0x892b24: mov             x0, x4
    // 0x892b28: r1 = 13
    //     0x892b28: mov             x1, #0xd
    // 0x892b2c: cmp             x1, x0
    // 0x892b30: b.hs            #0x892bcc
    // 0x892b34: LoadField: d2 = r2->field_7f
    //     0x892b34: ldur            d2, [x2, #0x7f]
    // 0x892b38: fcmp            d2, d1
    // 0x892b3c: b.ne            #0x892b88
    // 0x892b40: mov             x0, x4
    // 0x892b44: r1 = 14
    //     0x892b44: mov             x1, #0xe
    // 0x892b48: cmp             x1, x0
    // 0x892b4c: b.hs            #0x892bd0
    // 0x892b50: LoadField: d2 = r2->field_87
    //     0x892b50: ldur            d2, [x2, #0x87]
    // 0x892b54: fcmp            d2, d1
    // 0x892b58: b.ne            #0x892b88
    // 0x892b5c: mov             x0, x4
    // 0x892b60: r1 = 15
    //     0x892b60: mov             x1, #0xf
    // 0x892b64: cmp             x1, x0
    // 0x892b68: b.hs            #0x892bd4
    // 0x892b6c: LoadField: d1 = r2->field_8f
    //     0x892b6c: ldur            d1, [x2, #0x8f]
    // 0x892b70: fcmp            d1, d0
    // 0x892b74: r16 = true
    //     0x892b74: add             x16, NULL, #0x20  ; true
    // 0x892b78: r17 = false
    //     0x892b78: add             x17, NULL, #0x30  ; false
    // 0x892b7c: csel            x1, x16, x17, eq
    // 0x892b80: mov             x0, x1
    // 0x892b84: b               #0x892b8c
    // 0x892b88: r0 = false
    //     0x892b88: add             x0, NULL, #0x30  ; false
    // 0x892b8c: LeaveFrame
    //     0x892b8c: mov             SP, fp
    //     0x892b90: ldp             fp, lr, [SP], #0x10
    // 0x892b94: ret
    //     0x892b94: ret             
    // 0x892b98: r0 = RangeErrorSharedWithFPURegs()
    //     0x892b98: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892b9c: r0 = RangeErrorSharedWithFPURegs()
    //     0x892b9c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892ba0: r0 = RangeErrorSharedWithFPURegs()
    //     0x892ba0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892ba4: r0 = RangeErrorSharedWithFPURegs()
    //     0x892ba4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892ba8: r0 = RangeErrorSharedWithFPURegs()
    //     0x892ba8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bac: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bac: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bb0: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bb0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bb4: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bb4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bb8: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bb8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bbc: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bbc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bc0: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bc0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bc4: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bc4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bc8: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bc8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bcc: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bcc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bd0: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bd0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x892bd4: r0 = RangeErrorSharedWithFPURegs()
    //     0x892bd4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ matrixEquals(/* No info */) {
    // ** addr: 0x892cb0, size: 0x434
    // 0x892cb0: EnterFrame
    //     0x892cb0: stp             fp, lr, [SP, #-0x10]!
    //     0x892cb4: mov             fp, SP
    // 0x892cb8: CheckStackOverflow
    //     0x892cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x892cbc: cmp             SP, x16
    //     0x892cc0: b.ls            #0x893058
    // 0x892cc4: cmp             w1, w2
    // 0x892cc8: b.ne            #0x892cdc
    // 0x892ccc: r0 = true
    //     0x892ccc: add             x0, NULL, #0x20  ; true
    // 0x892cd0: LeaveFrame
    //     0x892cd0: mov             SP, fp
    //     0x892cd4: ldp             fp, lr, [SP], #0x10
    // 0x892cd8: ret
    //     0x892cd8: ret             
    // 0x892cdc: cmp             w1, NULL
    // 0x892ce0: b.ne            #0x892d00
    // 0x892ce4: cmp             w2, NULL
    // 0x892ce8: b.eq            #0x893060
    // 0x892cec: mov             x1, x2
    // 0x892cf0: r0 = isIdentity()
    //     0x892cf0: bl              #0x892998  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0x892cf4: LeaveFrame
    //     0x892cf4: mov             SP, fp
    //     0x892cf8: ldp             fp, lr, [SP], #0x10
    // 0x892cfc: ret
    //     0x892cfc: ret             
    // 0x892d00: cmp             w2, NULL
    // 0x892d04: b.ne            #0x892d18
    // 0x892d08: r0 = isIdentity()
    //     0x892d08: bl              #0x892998  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0x892d0c: LeaveFrame
    //     0x892d0c: mov             SP, fp
    //     0x892d10: ldp             fp, lr, [SP], #0x10
    // 0x892d14: ret
    //     0x892d14: ret             
    // 0x892d18: LoadField: r3 = r1->field_7
    //     0x892d18: ldur            w3, [x1, #7]
    // 0x892d1c: DecompressPointer r3
    //     0x892d1c: add             x3, x3, HEAP, lsl #32
    // 0x892d20: LoadField: r4 = r3->field_13
    //     0x892d20: ldur            w4, [x3, #0x13]
    // 0x892d24: r5 = LoadInt32Instr(r4)
    //     0x892d24: sbfx            x5, x4, #1, #0x1f
    // 0x892d28: mov             x0, x5
    // 0x892d2c: r1 = 0
    //     0x892d2c: mov             x1, #0
    // 0x892d30: cmp             x1, x0
    // 0x892d34: b.hs            #0x893064
    // 0x892d38: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x892d38: ldur            d0, [x3, #0x17]
    // 0x892d3c: LoadField: r4 = r2->field_7
    //     0x892d3c: ldur            w4, [x2, #7]
    // 0x892d40: DecompressPointer r4
    //     0x892d40: add             x4, x4, HEAP, lsl #32
    // 0x892d44: LoadField: r2 = r4->field_13
    //     0x892d44: ldur            w2, [x4, #0x13]
    // 0x892d48: r6 = LoadInt32Instr(r2)
    //     0x892d48: sbfx            x6, x2, #1, #0x1f
    // 0x892d4c: mov             x0, x6
    // 0x892d50: r1 = 0
    //     0x892d50: mov             x1, #0
    // 0x892d54: cmp             x1, x0
    // 0x892d58: b.hs            #0x893068
    // 0x892d5c: ArrayLoad: d1 = r4[0]  ; List_8
    //     0x892d5c: ldur            d1, [x4, #0x17]
    // 0x892d60: fcmp            d0, d1
    // 0x892d64: b.ne            #0x893048
    // 0x892d68: mov             x0, x5
    // 0x892d6c: r1 = 1
    //     0x892d6c: mov             x1, #1
    // 0x892d70: cmp             x1, x0
    // 0x892d74: b.hs            #0x89306c
    // 0x892d78: LoadField: d0 = r3->field_1f
    //     0x892d78: ldur            d0, [x3, #0x1f]
    // 0x892d7c: mov             x0, x6
    // 0x892d80: r1 = 1
    //     0x892d80: mov             x1, #1
    // 0x892d84: cmp             x1, x0
    // 0x892d88: b.hs            #0x893070
    // 0x892d8c: LoadField: d1 = r4->field_1f
    //     0x892d8c: ldur            d1, [x4, #0x1f]
    // 0x892d90: fcmp            d0, d1
    // 0x892d94: b.ne            #0x893048
    // 0x892d98: mov             x0, x5
    // 0x892d9c: r1 = 2
    //     0x892d9c: mov             x1, #2
    // 0x892da0: cmp             x1, x0
    // 0x892da4: b.hs            #0x893074
    // 0x892da8: LoadField: d0 = r3->field_27
    //     0x892da8: ldur            d0, [x3, #0x27]
    // 0x892dac: mov             x0, x6
    // 0x892db0: r1 = 2
    //     0x892db0: mov             x1, #2
    // 0x892db4: cmp             x1, x0
    // 0x892db8: b.hs            #0x893078
    // 0x892dbc: LoadField: d1 = r4->field_27
    //     0x892dbc: ldur            d1, [x4, #0x27]
    // 0x892dc0: fcmp            d0, d1
    // 0x892dc4: b.ne            #0x893048
    // 0x892dc8: mov             x0, x5
    // 0x892dcc: r1 = 3
    //     0x892dcc: mov             x1, #3
    // 0x892dd0: cmp             x1, x0
    // 0x892dd4: b.hs            #0x89307c
    // 0x892dd8: LoadField: d0 = r3->field_2f
    //     0x892dd8: ldur            d0, [x3, #0x2f]
    // 0x892ddc: mov             x0, x6
    // 0x892de0: r1 = 3
    //     0x892de0: mov             x1, #3
    // 0x892de4: cmp             x1, x0
    // 0x892de8: b.hs            #0x893080
    // 0x892dec: LoadField: d1 = r4->field_2f
    //     0x892dec: ldur            d1, [x4, #0x2f]
    // 0x892df0: fcmp            d0, d1
    // 0x892df4: b.ne            #0x893048
    // 0x892df8: mov             x0, x5
    // 0x892dfc: r1 = 4
    //     0x892dfc: mov             x1, #4
    // 0x892e00: cmp             x1, x0
    // 0x892e04: b.hs            #0x893084
    // 0x892e08: LoadField: d0 = r3->field_37
    //     0x892e08: ldur            d0, [x3, #0x37]
    // 0x892e0c: mov             x0, x6
    // 0x892e10: r1 = 4
    //     0x892e10: mov             x1, #4
    // 0x892e14: cmp             x1, x0
    // 0x892e18: b.hs            #0x893088
    // 0x892e1c: LoadField: d1 = r4->field_37
    //     0x892e1c: ldur            d1, [x4, #0x37]
    // 0x892e20: fcmp            d0, d1
    // 0x892e24: b.ne            #0x893048
    // 0x892e28: mov             x0, x5
    // 0x892e2c: r1 = 5
    //     0x892e2c: mov             x1, #5
    // 0x892e30: cmp             x1, x0
    // 0x892e34: b.hs            #0x89308c
    // 0x892e38: LoadField: d0 = r3->field_3f
    //     0x892e38: ldur            d0, [x3, #0x3f]
    // 0x892e3c: mov             x0, x6
    // 0x892e40: r1 = 5
    //     0x892e40: mov             x1, #5
    // 0x892e44: cmp             x1, x0
    // 0x892e48: b.hs            #0x893090
    // 0x892e4c: LoadField: d1 = r4->field_3f
    //     0x892e4c: ldur            d1, [x4, #0x3f]
    // 0x892e50: fcmp            d0, d1
    // 0x892e54: b.ne            #0x893048
    // 0x892e58: mov             x0, x5
    // 0x892e5c: r1 = 6
    //     0x892e5c: mov             x1, #6
    // 0x892e60: cmp             x1, x0
    // 0x892e64: b.hs            #0x893094
    // 0x892e68: LoadField: d0 = r3->field_47
    //     0x892e68: ldur            d0, [x3, #0x47]
    // 0x892e6c: mov             x0, x6
    // 0x892e70: r1 = 6
    //     0x892e70: mov             x1, #6
    // 0x892e74: cmp             x1, x0
    // 0x892e78: b.hs            #0x893098
    // 0x892e7c: LoadField: d1 = r4->field_47
    //     0x892e7c: ldur            d1, [x4, #0x47]
    // 0x892e80: fcmp            d0, d1
    // 0x892e84: b.ne            #0x893048
    // 0x892e88: mov             x0, x5
    // 0x892e8c: r1 = 7
    //     0x892e8c: mov             x1, #7
    // 0x892e90: cmp             x1, x0
    // 0x892e94: b.hs            #0x89309c
    // 0x892e98: LoadField: d0 = r3->field_4f
    //     0x892e98: ldur            d0, [x3, #0x4f]
    // 0x892e9c: mov             x0, x6
    // 0x892ea0: r1 = 7
    //     0x892ea0: mov             x1, #7
    // 0x892ea4: cmp             x1, x0
    // 0x892ea8: b.hs            #0x8930a0
    // 0x892eac: LoadField: d1 = r4->field_4f
    //     0x892eac: ldur            d1, [x4, #0x4f]
    // 0x892eb0: fcmp            d0, d1
    // 0x892eb4: b.ne            #0x893048
    // 0x892eb8: mov             x0, x5
    // 0x892ebc: r1 = 8
    //     0x892ebc: mov             x1, #8
    // 0x892ec0: cmp             x1, x0
    // 0x892ec4: b.hs            #0x8930a4
    // 0x892ec8: LoadField: d0 = r3->field_57
    //     0x892ec8: ldur            d0, [x3, #0x57]
    // 0x892ecc: mov             x0, x6
    // 0x892ed0: r1 = 8
    //     0x892ed0: mov             x1, #8
    // 0x892ed4: cmp             x1, x0
    // 0x892ed8: b.hs            #0x8930a8
    // 0x892edc: LoadField: d1 = r4->field_57
    //     0x892edc: ldur            d1, [x4, #0x57]
    // 0x892ee0: fcmp            d0, d1
    // 0x892ee4: b.ne            #0x893048
    // 0x892ee8: mov             x0, x5
    // 0x892eec: r1 = 9
    //     0x892eec: mov             x1, #9
    // 0x892ef0: cmp             x1, x0
    // 0x892ef4: b.hs            #0x8930ac
    // 0x892ef8: LoadField: d0 = r3->field_5f
    //     0x892ef8: ldur            d0, [x3, #0x5f]
    // 0x892efc: mov             x0, x6
    // 0x892f00: r1 = 9
    //     0x892f00: mov             x1, #9
    // 0x892f04: cmp             x1, x0
    // 0x892f08: b.hs            #0x8930b0
    // 0x892f0c: LoadField: d1 = r4->field_5f
    //     0x892f0c: ldur            d1, [x4, #0x5f]
    // 0x892f10: fcmp            d0, d1
    // 0x892f14: b.ne            #0x893048
    // 0x892f18: mov             x0, x5
    // 0x892f1c: r1 = 10
    //     0x892f1c: mov             x1, #0xa
    // 0x892f20: cmp             x1, x0
    // 0x892f24: b.hs            #0x8930b4
    // 0x892f28: LoadField: d0 = r3->field_67
    //     0x892f28: ldur            d0, [x3, #0x67]
    // 0x892f2c: mov             x0, x6
    // 0x892f30: r1 = 10
    //     0x892f30: mov             x1, #0xa
    // 0x892f34: cmp             x1, x0
    // 0x892f38: b.hs            #0x8930b8
    // 0x892f3c: LoadField: d1 = r4->field_67
    //     0x892f3c: ldur            d1, [x4, #0x67]
    // 0x892f40: fcmp            d0, d1
    // 0x892f44: b.ne            #0x893048
    // 0x892f48: mov             x0, x5
    // 0x892f4c: r1 = 11
    //     0x892f4c: mov             x1, #0xb
    // 0x892f50: cmp             x1, x0
    // 0x892f54: b.hs            #0x8930bc
    // 0x892f58: LoadField: d0 = r3->field_6f
    //     0x892f58: ldur            d0, [x3, #0x6f]
    // 0x892f5c: mov             x0, x6
    // 0x892f60: r1 = 11
    //     0x892f60: mov             x1, #0xb
    // 0x892f64: cmp             x1, x0
    // 0x892f68: b.hs            #0x8930c0
    // 0x892f6c: LoadField: d1 = r4->field_6f
    //     0x892f6c: ldur            d1, [x4, #0x6f]
    // 0x892f70: fcmp            d0, d1
    // 0x892f74: b.ne            #0x893048
    // 0x892f78: mov             x0, x5
    // 0x892f7c: r1 = 12
    //     0x892f7c: mov             x1, #0xc
    // 0x892f80: cmp             x1, x0
    // 0x892f84: b.hs            #0x8930c4
    // 0x892f88: LoadField: d0 = r3->field_77
    //     0x892f88: ldur            d0, [x3, #0x77]
    // 0x892f8c: mov             x0, x6
    // 0x892f90: r1 = 12
    //     0x892f90: mov             x1, #0xc
    // 0x892f94: cmp             x1, x0
    // 0x892f98: b.hs            #0x8930c8
    // 0x892f9c: LoadField: d1 = r4->field_77
    //     0x892f9c: ldur            d1, [x4, #0x77]
    // 0x892fa0: fcmp            d0, d1
    // 0x892fa4: b.ne            #0x893048
    // 0x892fa8: mov             x0, x5
    // 0x892fac: r1 = 13
    //     0x892fac: mov             x1, #0xd
    // 0x892fb0: cmp             x1, x0
    // 0x892fb4: b.hs            #0x8930cc
    // 0x892fb8: LoadField: d0 = r3->field_7f
    //     0x892fb8: ldur            d0, [x3, #0x7f]
    // 0x892fbc: mov             x0, x6
    // 0x892fc0: r1 = 13
    //     0x892fc0: mov             x1, #0xd
    // 0x892fc4: cmp             x1, x0
    // 0x892fc8: b.hs            #0x8930d0
    // 0x892fcc: LoadField: d1 = r4->field_7f
    //     0x892fcc: ldur            d1, [x4, #0x7f]
    // 0x892fd0: fcmp            d0, d1
    // 0x892fd4: b.ne            #0x893048
    // 0x892fd8: mov             x0, x5
    // 0x892fdc: r1 = 14
    //     0x892fdc: mov             x1, #0xe
    // 0x892fe0: cmp             x1, x0
    // 0x892fe4: b.hs            #0x8930d4
    // 0x892fe8: LoadField: d0 = r3->field_87
    //     0x892fe8: ldur            d0, [x3, #0x87]
    // 0x892fec: mov             x0, x6
    // 0x892ff0: r1 = 14
    //     0x892ff0: mov             x1, #0xe
    // 0x892ff4: cmp             x1, x0
    // 0x892ff8: b.hs            #0x8930d8
    // 0x892ffc: LoadField: d1 = r4->field_87
    //     0x892ffc: ldur            d1, [x4, #0x87]
    // 0x893000: fcmp            d0, d1
    // 0x893004: b.ne            #0x893048
    // 0x893008: mov             x0, x5
    // 0x89300c: r1 = 15
    //     0x89300c: mov             x1, #0xf
    // 0x893010: cmp             x1, x0
    // 0x893014: b.hs            #0x8930dc
    // 0x893018: LoadField: d0 = r3->field_8f
    //     0x893018: ldur            d0, [x3, #0x8f]
    // 0x89301c: mov             x0, x6
    // 0x893020: r1 = 15
    //     0x893020: mov             x1, #0xf
    // 0x893024: cmp             x1, x0
    // 0x893028: b.hs            #0x8930e0
    // 0x89302c: LoadField: d1 = r4->field_8f
    //     0x89302c: ldur            d1, [x4, #0x8f]
    // 0x893030: fcmp            d0, d1
    // 0x893034: r16 = true
    //     0x893034: add             x16, NULL, #0x20  ; true
    // 0x893038: r17 = false
    //     0x893038: add             x17, NULL, #0x30  ; false
    // 0x89303c: csel            x1, x16, x17, eq
    // 0x893040: mov             x0, x1
    // 0x893044: b               #0x89304c
    // 0x893048: r0 = false
    //     0x893048: add             x0, NULL, #0x30  ; false
    // 0x89304c: LeaveFrame
    //     0x89304c: mov             SP, fp
    //     0x893050: ldp             fp, lr, [SP], #0x10
    // 0x893054: ret
    //     0x893054: ret             
    // 0x893058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893058: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89305c: b               #0x892cc4
    // 0x893060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x893060: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x893064: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893064: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893068: r0 = RangeErrorSharedWithFPURegs()
    //     0x893068: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x89306c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89306c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893070: r0 = RangeErrorSharedWithFPURegs()
    //     0x893070: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893074: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893074: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893078: r0 = RangeErrorSharedWithFPURegs()
    //     0x893078: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x89307c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89307c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893080: r0 = RangeErrorSharedWithFPURegs()
    //     0x893080: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893084: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893084: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893088: r0 = RangeErrorSharedWithFPURegs()
    //     0x893088: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x89308c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89308c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893090: r0 = RangeErrorSharedWithFPURegs()
    //     0x893090: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893094: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893098: r0 = RangeErrorSharedWithFPURegs()
    //     0x893098: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x89309c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89309c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930a0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930a0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930a8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930a8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930b0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930b0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930b4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930b8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930b8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930bc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930c0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930c0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930c8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930c8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930cc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930d0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930d0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930d4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930d8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930d8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x8930dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8930dc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8930e0: r0 = RangeErrorSharedWithFPURegs()
    //     0x8930e0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ multiplyInPlace(/* No info */) {
    // ** addr: 0x8937c4, size: 0x3f4
    // 0x8937c4: EnterFrame
    //     0x8937c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8937c8: mov             fp, SP
    // 0x8937cc: AllocStack(0x20)
    //     0x8937cc: sub             SP, SP, #0x20
    // 0x8937d0: LoadField: r3 = r1->field_7
    //     0x8937d0: ldur            w3, [x1, #7]
    // 0x8937d4: DecompressPointer r3
    //     0x8937d4: add             x3, x3, HEAP, lsl #32
    // 0x8937d8: LoadField: r4 = r3->field_13
    //     0x8937d8: ldur            w4, [x3, #0x13]
    // 0x8937dc: r5 = LoadInt32Instr(r4)
    //     0x8937dc: sbfx            x5, x4, #1, #0x1f
    // 0x8937e0: mov             x0, x5
    // 0x8937e4: r1 = 0
    //     0x8937e4: mov             x1, #0
    // 0x8937e8: cmp             x1, x0
    // 0x8937ec: b.hs            #0x893b80
    // 0x8937f0: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x8937f0: ldur            d0, [x3, #0x17]
    // 0x8937f4: mov             x0, x5
    // 0x8937f8: r1 = 4
    //     0x8937f8: mov             x1, #4
    // 0x8937fc: cmp             x1, x0
    // 0x893800: b.hs            #0x893b84
    // 0x893804: LoadField: d1 = r3->field_37
    //     0x893804: ldur            d1, [x3, #0x37]
    // 0x893808: mov             x0, x5
    // 0x89380c: r1 = 8
    //     0x89380c: mov             x1, #8
    // 0x893810: cmp             x1, x0
    // 0x893814: b.hs            #0x893b88
    // 0x893818: LoadField: d2 = r3->field_57
    //     0x893818: ldur            d2, [x3, #0x57]
    // 0x89381c: mov             x0, x5
    // 0x893820: r1 = 12
    //     0x893820: mov             x1, #0xc
    // 0x893824: cmp             x1, x0
    // 0x893828: b.hs            #0x893b8c
    // 0x89382c: LoadField: d3 = r3->field_77
    //     0x89382c: ldur            d3, [x3, #0x77]
    // 0x893830: LoadField: d4 = r3->field_1f
    //     0x893830: ldur            d4, [x3, #0x1f]
    // 0x893834: LoadField: d5 = r3->field_3f
    //     0x893834: ldur            d5, [x3, #0x3f]
    // 0x893838: LoadField: d6 = r3->field_5f
    //     0x893838: ldur            d6, [x3, #0x5f]
    // 0x89383c: mov             x0, x5
    // 0x893840: r1 = 13
    //     0x893840: mov             x1, #0xd
    // 0x893844: cmp             x1, x0
    // 0x893848: b.hs            #0x893b90
    // 0x89384c: LoadField: d7 = r3->field_7f
    //     0x89384c: ldur            d7, [x3, #0x7f]
    // 0x893850: LoadField: d8 = r3->field_27
    //     0x893850: ldur            d8, [x3, #0x27]
    // 0x893854: LoadField: d9 = r3->field_47
    //     0x893854: ldur            d9, [x3, #0x47]
    // 0x893858: LoadField: d10 = r3->field_67
    //     0x893858: ldur            d10, [x3, #0x67]
    // 0x89385c: mov             x0, x5
    // 0x893860: r1 = 14
    //     0x893860: mov             x1, #0xe
    // 0x893864: cmp             x1, x0
    // 0x893868: b.hs            #0x893b94
    // 0x89386c: LoadField: d11 = r3->field_87
    //     0x89386c: ldur            d11, [x3, #0x87]
    // 0x893870: LoadField: d12 = r3->field_2f
    //     0x893870: ldur            d12, [x3, #0x2f]
    // 0x893874: stur            d12, [fp, #-0x20]
    // 0x893878: LoadField: d13 = r3->field_4f
    //     0x893878: ldur            d13, [x3, #0x4f]
    // 0x89387c: stur            d13, [fp, #-0x18]
    // 0x893880: LoadField: d14 = r3->field_6f
    //     0x893880: ldur            d14, [x3, #0x6f]
    // 0x893884: mov             x0, x5
    // 0x893888: stur            d14, [fp, #-0x10]
    // 0x89388c: r1 = 15
    //     0x89388c: mov             x1, #0xf
    // 0x893890: cmp             x1, x0
    // 0x893894: b.hs            #0x893b98
    // 0x893898: LoadField: d15 = r3->field_8f
    //     0x893898: ldur            d15, [x3, #0x8f]
    // 0x89389c: stur            d15, [fp, #-8]
    // 0x8938a0: LoadField: r3 = r2->field_7
    //     0x8938a0: ldur            w3, [x2, #7]
    // 0x8938a4: DecompressPointer r3
    //     0x8938a4: add             x3, x3, HEAP, lsl #32
    // 0x8938a8: LoadField: r2 = r3->field_13
    //     0x8938a8: ldur            w2, [x3, #0x13]
    // 0x8938ac: r4 = LoadInt32Instr(r2)
    //     0x8938ac: sbfx            x4, x2, #1, #0x1f
    // 0x8938b0: mov             x0, x4
    // 0x8938b4: r1 = 0
    //     0x8938b4: mov             x1, #0
    // 0x8938b8: cmp             x1, x0
    // 0x8938bc: b.hs            #0x893b9c
    // 0x8938c0: ArrayLoad: d16 = r3[0]  ; List_8
    //     0x8938c0: ldur            d16, [x3, #0x17]
    // 0x8938c4: mov             x0, x4
    // 0x8938c8: r1 = 4
    //     0x8938c8: mov             x1, #4
    // 0x8938cc: cmp             x1, x0
    // 0x8938d0: b.hs            #0x893ba0
    // 0x8938d4: LoadField: d17 = r3->field_37
    //     0x8938d4: ldur            d17, [x3, #0x37]
    // 0x8938d8: mov             x0, x4
    // 0x8938dc: r1 = 8
    //     0x8938dc: mov             x1, #8
    // 0x8938e0: cmp             x1, x0
    // 0x8938e4: b.hs            #0x893ba4
    // 0x8938e8: LoadField: d18 = r3->field_57
    //     0x8938e8: ldur            d18, [x3, #0x57]
    // 0x8938ec: mov             x0, x4
    // 0x8938f0: r1 = 12
    //     0x8938f0: mov             x1, #0xc
    // 0x8938f4: cmp             x1, x0
    // 0x8938f8: b.hs            #0x893ba8
    // 0x8938fc: LoadField: d19 = r3->field_77
    //     0x8938fc: ldur            d19, [x3, #0x77]
    // 0x893900: LoadField: d20 = r3->field_1f
    //     0x893900: ldur            d20, [x3, #0x1f]
    // 0x893904: LoadField: d21 = r3->field_3f
    //     0x893904: ldur            d21, [x3, #0x3f]
    // 0x893908: LoadField: d22 = r3->field_5f
    //     0x893908: ldur            d22, [x3, #0x5f]
    // 0x89390c: mov             x0, x4
    // 0x893910: r1 = 13
    //     0x893910: mov             x1, #0xd
    // 0x893914: cmp             x1, x0
    // 0x893918: b.hs            #0x893bac
    // 0x89391c: LoadField: d23 = r3->field_7f
    //     0x89391c: ldur            d23, [x3, #0x7f]
    // 0x893920: LoadField: d24 = r3->field_27
    //     0x893920: ldur            d24, [x3, #0x27]
    // 0x893924: LoadField: d25 = r3->field_47
    //     0x893924: ldur            d25, [x3, #0x47]
    // 0x893928: LoadField: d26 = r3->field_67
    //     0x893928: ldur            d26, [x3, #0x67]
    // 0x89392c: mov             x0, x4
    // 0x893930: r1 = 14
    //     0x893930: mov             x1, #0xe
    // 0x893934: cmp             x1, x0
    // 0x893938: b.hs            #0x893bb0
    // 0x89393c: LoadField: d27 = r3->field_87
    //     0x89393c: ldur            d27, [x3, #0x87]
    // 0x893940: LoadField: d28 = r3->field_2f
    //     0x893940: ldur            d28, [x3, #0x2f]
    // 0x893944: LoadField: d29 = r3->field_4f
    //     0x893944: ldur            d29, [x3, #0x4f]
    // 0x893948: LoadField: d30 = r3->field_6f
    //     0x893948: ldur            d30, [x3, #0x6f]
    // 0x89394c: mov             x0, x4
    // 0x893950: r1 = 15
    //     0x893950: mov             x1, #0xf
    // 0x893954: cmp             x1, x0
    // 0x893958: b.hs            #0x893bb4
    // 0x89395c: LoadField: d15 = r3->field_8f
    //     0x89395c: ldur            d15, [x3, #0x8f]
    // 0x893960: fmul            d14, d0, d16
    // 0x893964: fmul            d13, d1, d20
    // 0x893968: fadd            d12, d14, d13
    // 0x89396c: fmul            d13, d2, d24
    // 0x893970: fadd            d14, d12, d13
    // 0x893974: fmul            d12, d3, d28
    // 0x893978: fadd            d13, d14, d12
    // 0x89397c: ArrayStore: r3[0] = d13  ; List_8
    //     0x89397c: stur            d13, [x3, #0x17]
    // 0x893980: fmul            d12, d0, d17
    // 0x893984: fmul            d13, d1, d21
    // 0x893988: fadd            d14, d12, d13
    // 0x89398c: fmul            d12, d2, d25
    // 0x893990: fadd            d13, d14, d12
    // 0x893994: fmul            d12, d3, d29
    // 0x893998: fadd            d14, d13, d12
    // 0x89399c: StoreField: r3->field_37 = d14
    //     0x89399c: stur            d14, [x3, #0x37]
    // 0x8939a0: fmul            d12, d0, d18
    // 0x8939a4: fmul            d13, d1, d22
    // 0x8939a8: fadd            d14, d12, d13
    // 0x8939ac: fmul            d12, d2, d26
    // 0x8939b0: fadd            d13, d14, d12
    // 0x8939b4: fmul            d12, d3, d30
    // 0x8939b8: fadd            d14, d13, d12
    // 0x8939bc: StoreField: r3->field_57 = d14
    //     0x8939bc: stur            d14, [x3, #0x57]
    // 0x8939c0: fmul            d12, d0, d19
    // 0x8939c4: fmul            d0, d1, d23
    // 0x8939c8: fadd            d1, d12, d0
    // 0x8939cc: fmul            d0, d2, d27
    // 0x8939d0: fadd            d2, d1, d0
    // 0x8939d4: fmul            d0, d3, d15
    // 0x8939d8: fadd            d1, d2, d0
    // 0x8939dc: StoreField: r3->field_77 = d1
    //     0x8939dc: stur            d1, [x3, #0x77]
    // 0x8939e0: fmul            d0, d4, d16
    // 0x8939e4: fmul            d1, d5, d20
    // 0x8939e8: fadd            d2, d0, d1
    // 0x8939ec: fmul            d0, d6, d24
    // 0x8939f0: fadd            d1, d2, d0
    // 0x8939f4: fmul            d0, d7, d28
    // 0x8939f8: fadd            d2, d1, d0
    // 0x8939fc: StoreField: r3->field_1f = d2
    //     0x8939fc: stur            d2, [x3, #0x1f]
    // 0x893a00: fmul            d0, d4, d17
    // 0x893a04: fmul            d1, d5, d21
    // 0x893a08: fadd            d2, d0, d1
    // 0x893a0c: fmul            d0, d6, d25
    // 0x893a10: fadd            d1, d2, d0
    // 0x893a14: fmul            d0, d7, d29
    // 0x893a18: fadd            d2, d1, d0
    // 0x893a1c: StoreField: r3->field_3f = d2
    //     0x893a1c: stur            d2, [x3, #0x3f]
    // 0x893a20: fmul            d0, d4, d18
    // 0x893a24: fmul            d1, d5, d22
    // 0x893a28: fadd            d2, d0, d1
    // 0x893a2c: fmul            d0, d6, d26
    // 0x893a30: fadd            d1, d2, d0
    // 0x893a34: fmul            d0, d7, d30
    // 0x893a38: fadd            d2, d1, d0
    // 0x893a3c: StoreField: r3->field_5f = d2
    //     0x893a3c: stur            d2, [x3, #0x5f]
    // 0x893a40: fmul            d0, d4, d19
    // 0x893a44: fmul            d1, d5, d23
    // 0x893a48: fadd            d2, d0, d1
    // 0x893a4c: fmul            d0, d6, d27
    // 0x893a50: fadd            d1, d2, d0
    // 0x893a54: fmul            d0, d7, d15
    // 0x893a58: fadd            d2, d1, d0
    // 0x893a5c: StoreField: r3->field_7f = d2
    //     0x893a5c: stur            d2, [x3, #0x7f]
    // 0x893a60: fmul            d0, d8, d16
    // 0x893a64: fmul            d1, d9, d20
    // 0x893a68: fadd            d2, d0, d1
    // 0x893a6c: fmul            d0, d10, d24
    // 0x893a70: fadd            d1, d2, d0
    // 0x893a74: fmul            d0, d11, d28
    // 0x893a78: fadd            d2, d1, d0
    // 0x893a7c: StoreField: r3->field_27 = d2
    //     0x893a7c: stur            d2, [x3, #0x27]
    // 0x893a80: fmul            d0, d8, d17
    // 0x893a84: fmul            d1, d9, d21
    // 0x893a88: fadd            d2, d0, d1
    // 0x893a8c: fmul            d0, d10, d25
    // 0x893a90: fadd            d1, d2, d0
    // 0x893a94: fmul            d0, d11, d29
    // 0x893a98: fadd            d2, d1, d0
    // 0x893a9c: StoreField: r3->field_47 = d2
    //     0x893a9c: stur            d2, [x3, #0x47]
    // 0x893aa0: fmul            d0, d8, d18
    // 0x893aa4: fmul            d1, d9, d22
    // 0x893aa8: fadd            d2, d0, d1
    // 0x893aac: fmul            d0, d10, d26
    // 0x893ab0: fadd            d1, d2, d0
    // 0x893ab4: fmul            d0, d11, d30
    // 0x893ab8: fadd            d2, d1, d0
    // 0x893abc: StoreField: r3->field_67 = d2
    //     0x893abc: stur            d2, [x3, #0x67]
    // 0x893ac0: fmul            d0, d8, d19
    // 0x893ac4: fmul            d1, d9, d23
    // 0x893ac8: fadd            d2, d0, d1
    // 0x893acc: fmul            d0, d10, d27
    // 0x893ad0: fadd            d1, d2, d0
    // 0x893ad4: fmul            d0, d11, d15
    // 0x893ad8: fadd            d2, d1, d0
    // 0x893adc: StoreField: r3->field_87 = d2
    //     0x893adc: stur            d2, [x3, #0x87]
    // 0x893ae0: ldur            d0, [fp, #-0x20]
    // 0x893ae4: fmul            d1, d0, d16
    // 0x893ae8: ldur            d2, [fp, #-0x18]
    // 0x893aec: fmul            d3, d2, d20
    // 0x893af0: fadd            d4, d1, d3
    // 0x893af4: ldur            d1, [fp, #-0x10]
    // 0x893af8: fmul            d3, d1, d24
    // 0x893afc: fadd            d5, d4, d3
    // 0x893b00: ldur            d3, [fp, #-8]
    // 0x893b04: fmul            d4, d3, d28
    // 0x893b08: fadd            d6, d5, d4
    // 0x893b0c: StoreField: r3->field_2f = d6
    //     0x893b0c: stur            d6, [x3, #0x2f]
    // 0x893b10: fmul            d4, d0, d17
    // 0x893b14: fmul            d5, d2, d21
    // 0x893b18: fadd            d6, d4, d5
    // 0x893b1c: fmul            d4, d1, d25
    // 0x893b20: fadd            d5, d6, d4
    // 0x893b24: fmul            d4, d3, d29
    // 0x893b28: fadd            d6, d5, d4
    // 0x893b2c: StoreField: r3->field_4f = d6
    //     0x893b2c: stur            d6, [x3, #0x4f]
    // 0x893b30: fmul            d4, d0, d18
    // 0x893b34: fmul            d5, d2, d22
    // 0x893b38: fadd            d6, d4, d5
    // 0x893b3c: fmul            d4, d1, d26
    // 0x893b40: fadd            d5, d6, d4
    // 0x893b44: fmul            d4, d3, d30
    // 0x893b48: fadd            d6, d5, d4
    // 0x893b4c: StoreField: r3->field_6f = d6
    //     0x893b4c: stur            d6, [x3, #0x6f]
    // 0x893b50: fmul            d4, d0, d19
    // 0x893b54: fmul            d0, d2, d23
    // 0x893b58: fadd            d2, d4, d0
    // 0x893b5c: fmul            d0, d1, d27
    // 0x893b60: fadd            d1, d2, d0
    // 0x893b64: fmul            d0, d3, d15
    // 0x893b68: fadd            d2, d1, d0
    // 0x893b6c: StoreField: r3->field_8f = d2
    //     0x893b6c: stur            d2, [x3, #0x8f]
    // 0x893b70: r0 = Null
    //     0x893b70: mov             x0, NULL
    // 0x893b74: LeaveFrame
    //     0x893b74: mov             SP, fp
    //     0x893b78: ldp             fp, lr, [SP], #0x10
    // 0x893b7c: ret
    //     0x893b7c: ret             
    // 0x893b80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893b80: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x893b84: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b84: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b88: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b88: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b8c: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b8c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b90: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b90: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b94: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b94: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b98: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b98: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893b9c: r0 = RangeErrorSharedWithFPURegs()
    //     0x893b9c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893ba0: r0 = RangeErrorSharedWithFPURegs()
    //     0x893ba0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893ba4: r0 = RangeErrorSharedWithFPURegs()
    //     0x893ba4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893ba8: r0 = RangeErrorSharedWithFPURegs()
    //     0x893ba8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893bac: r0 = RangeErrorSharedWithFPURegs()
    //     0x893bac: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893bb0: r0 = RangeErrorSharedWithFPURegs()
    //     0x893bb0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x893bb4: r0 = RangeErrorSharedWithFPURegs()
    //     0x893bb4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ forceToPoint(/* No info */) {
    // ** addr: 0xaf99c4, size: 0x58
    // 0xaf99c4: EnterFrame
    //     0xaf99c4: stp             fp, lr, [SP, #-0x10]!
    //     0xaf99c8: mov             fp, SP
    // 0xaf99cc: AllocStack(0x10)
    //     0xaf99cc: sub             SP, SP, #0x10
    // 0xaf99d0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xaf99d0: stur            x1, [fp, #-8]
    // 0xaf99d4: r0 = Matrix4()
    //     0xaf99d4: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xaf99d8: r4 = 32
    //     0xaf99d8: mov             x4, #0x20
    // 0xaf99dc: stur            x0, [fp, #-0x10]
    // 0xaf99e0: r0 = AllocateFloat64Array()
    //     0xaf99e0: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xaf99e4: mov             x1, x0
    // 0xaf99e8: ldur            x0, [fp, #-0x10]
    // 0xaf99ec: StoreField: r0->field_7 = r1
    //     0xaf99ec: stur            w1, [x0, #7]
    // 0xaf99f0: d0 = 1.000000
    //     0xaf99f0: fmov            d0, #1.00000000
    // 0xaf99f4: StoreField: r1->field_67 = d0
    //     0xaf99f4: stur            d0, [x1, #0x67]
    // 0xaf99f8: ldur            x2, [fp, #-8]
    // 0xaf99fc: LoadField: d1 = r2->field_7
    //     0xaf99fc: ldur            d1, [x2, #7]
    // 0xaf9a00: StoreField: r1->field_77 = d1
    //     0xaf9a00: stur            d1, [x1, #0x77]
    // 0xaf9a04: LoadField: d1 = r2->field_f
    //     0xaf9a04: ldur            d1, [x2, #0xf]
    // 0xaf9a08: StoreField: r1->field_7f = d1
    //     0xaf9a08: stur            d1, [x1, #0x7f]
    // 0xaf9a0c: StoreField: r1->field_8f = d0
    //     0xaf9a0c: stur            d0, [x1, #0x8f]
    // 0xaf9a10: LeaveFrame
    //     0xaf9a10: mov             SP, fp
    //     0xaf9a14: ldp             fp, lr, [SP], #0x10
    // 0xaf9a18: ret
    //     0xaf9a18: ret             
  }
  static _ getAsTranslation(/* No info */) {
    // ** addr: 0xc155c4, size: 0x254
    // 0xc155c4: EnterFrame
    //     0xc155c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc155c8: mov             fp, SP
    // 0xc155cc: AllocStack(0x10)
    //     0xc155cc: sub             SP, SP, #0x10
    // 0xc155d0: LoadField: r2 = r1->field_7
    //     0xc155d0: ldur            w2, [x1, #7]
    // 0xc155d4: DecompressPointer r2
    //     0xc155d4: add             x2, x2, HEAP, lsl #32
    // 0xc155d8: LoadField: r0 = r2->field_13
    //     0xc155d8: ldur            w0, [x2, #0x13]
    // 0xc155dc: r3 = LoadInt32Instr(r0)
    //     0xc155dc: sbfx            x3, x0, #1, #0x1f
    // 0xc155e0: cmp             x3, #0x10
    // 0xc155e4: b.ne            #0xc157c8
    // 0xc155e8: d0 = 1.000000
    //     0xc155e8: fmov            d0, #1.00000000
    // 0xc155ec: mov             x0, x3
    // 0xc155f0: r1 = 0
    //     0xc155f0: mov             x1, #0
    // 0xc155f4: cmp             x1, x0
    // 0xc155f8: b.hs            #0xc157d8
    // 0xc155fc: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xc155fc: ldur            d1, [x2, #0x17]
    // 0xc15600: fcmp            d1, d0
    // 0xc15604: b.ne            #0xc157c8
    // 0xc15608: d1 = 0.000000
    //     0xc15608: eor             v1.16b, v1.16b, v1.16b
    // 0xc1560c: mov             x0, x3
    // 0xc15610: r1 = 1
    //     0xc15610: mov             x1, #1
    // 0xc15614: cmp             x1, x0
    // 0xc15618: b.hs            #0xc157dc
    // 0xc1561c: LoadField: d2 = r2->field_1f
    //     0xc1561c: ldur            d2, [x2, #0x1f]
    // 0xc15620: fcmp            d2, d1
    // 0xc15624: b.ne            #0xc157c8
    // 0xc15628: mov             x0, x3
    // 0xc1562c: r1 = 2
    //     0xc1562c: mov             x1, #2
    // 0xc15630: cmp             x1, x0
    // 0xc15634: b.hs            #0xc157e0
    // 0xc15638: LoadField: d2 = r2->field_27
    //     0xc15638: ldur            d2, [x2, #0x27]
    // 0xc1563c: fcmp            d2, d1
    // 0xc15640: b.ne            #0xc157c8
    // 0xc15644: mov             x0, x3
    // 0xc15648: r1 = 3
    //     0xc15648: mov             x1, #3
    // 0xc1564c: cmp             x1, x0
    // 0xc15650: b.hs            #0xc157e4
    // 0xc15654: LoadField: d2 = r2->field_2f
    //     0xc15654: ldur            d2, [x2, #0x2f]
    // 0xc15658: fcmp            d2, d1
    // 0xc1565c: b.ne            #0xc157c8
    // 0xc15660: mov             x0, x3
    // 0xc15664: r1 = 4
    //     0xc15664: mov             x1, #4
    // 0xc15668: cmp             x1, x0
    // 0xc1566c: b.hs            #0xc157e8
    // 0xc15670: LoadField: d2 = r2->field_37
    //     0xc15670: ldur            d2, [x2, #0x37]
    // 0xc15674: fcmp            d2, d1
    // 0xc15678: b.ne            #0xc157c8
    // 0xc1567c: mov             x0, x3
    // 0xc15680: r1 = 5
    //     0xc15680: mov             x1, #5
    // 0xc15684: cmp             x1, x0
    // 0xc15688: b.hs            #0xc157ec
    // 0xc1568c: LoadField: d2 = r2->field_3f
    //     0xc1568c: ldur            d2, [x2, #0x3f]
    // 0xc15690: fcmp            d2, d0
    // 0xc15694: b.ne            #0xc157c8
    // 0xc15698: mov             x0, x3
    // 0xc1569c: r1 = 6
    //     0xc1569c: mov             x1, #6
    // 0xc156a0: cmp             x1, x0
    // 0xc156a4: b.hs            #0xc157f0
    // 0xc156a8: LoadField: d2 = r2->field_47
    //     0xc156a8: ldur            d2, [x2, #0x47]
    // 0xc156ac: fcmp            d2, d1
    // 0xc156b0: b.ne            #0xc157c8
    // 0xc156b4: mov             x0, x3
    // 0xc156b8: r1 = 7
    //     0xc156b8: mov             x1, #7
    // 0xc156bc: cmp             x1, x0
    // 0xc156c0: b.hs            #0xc157f4
    // 0xc156c4: LoadField: d2 = r2->field_4f
    //     0xc156c4: ldur            d2, [x2, #0x4f]
    // 0xc156c8: fcmp            d2, d1
    // 0xc156cc: b.ne            #0xc157c8
    // 0xc156d0: mov             x0, x3
    // 0xc156d4: r1 = 8
    //     0xc156d4: mov             x1, #8
    // 0xc156d8: cmp             x1, x0
    // 0xc156dc: b.hs            #0xc157f8
    // 0xc156e0: LoadField: d2 = r2->field_57
    //     0xc156e0: ldur            d2, [x2, #0x57]
    // 0xc156e4: fcmp            d2, d1
    // 0xc156e8: b.ne            #0xc157c8
    // 0xc156ec: mov             x0, x3
    // 0xc156f0: r1 = 9
    //     0xc156f0: mov             x1, #9
    // 0xc156f4: cmp             x1, x0
    // 0xc156f8: b.hs            #0xc157fc
    // 0xc156fc: LoadField: d2 = r2->field_5f
    //     0xc156fc: ldur            d2, [x2, #0x5f]
    // 0xc15700: fcmp            d2, d1
    // 0xc15704: b.ne            #0xc157c8
    // 0xc15708: mov             x0, x3
    // 0xc1570c: r1 = 10
    //     0xc1570c: mov             x1, #0xa
    // 0xc15710: cmp             x1, x0
    // 0xc15714: b.hs            #0xc15800
    // 0xc15718: LoadField: d2 = r2->field_67
    //     0xc15718: ldur            d2, [x2, #0x67]
    // 0xc1571c: fcmp            d2, d0
    // 0xc15720: b.ne            #0xc157c8
    // 0xc15724: mov             x0, x3
    // 0xc15728: r1 = 11
    //     0xc15728: mov             x1, #0xb
    // 0xc1572c: cmp             x1, x0
    // 0xc15730: b.hs            #0xc15804
    // 0xc15734: LoadField: d2 = r2->field_6f
    //     0xc15734: ldur            d2, [x2, #0x6f]
    // 0xc15738: fcmp            d2, d1
    // 0xc1573c: b.ne            #0xc157c8
    // 0xc15740: mov             x0, x3
    // 0xc15744: r1 = 12
    //     0xc15744: mov             x1, #0xc
    // 0xc15748: cmp             x1, x0
    // 0xc1574c: b.hs            #0xc15808
    // 0xc15750: LoadField: d2 = r2->field_77
    //     0xc15750: ldur            d2, [x2, #0x77]
    // 0xc15754: mov             x0, x3
    // 0xc15758: stur            d2, [fp, #-0x10]
    // 0xc1575c: r1 = 13
    //     0xc1575c: mov             x1, #0xd
    // 0xc15760: cmp             x1, x0
    // 0xc15764: b.hs            #0xc1580c
    // 0xc15768: LoadField: d3 = r2->field_7f
    //     0xc15768: ldur            d3, [x2, #0x7f]
    // 0xc1576c: mov             x0, x3
    // 0xc15770: stur            d3, [fp, #-8]
    // 0xc15774: r1 = 14
    //     0xc15774: mov             x1, #0xe
    // 0xc15778: cmp             x1, x0
    // 0xc1577c: b.hs            #0xc15810
    // 0xc15780: LoadField: d4 = r2->field_87
    //     0xc15780: ldur            d4, [x2, #0x87]
    // 0xc15784: fcmp            d4, d1
    // 0xc15788: b.ne            #0xc157c8
    // 0xc1578c: mov             x0, x3
    // 0xc15790: r1 = 15
    //     0xc15790: mov             x1, #0xf
    // 0xc15794: cmp             x1, x0
    // 0xc15798: b.hs            #0xc15814
    // 0xc1579c: LoadField: d1 = r2->field_8f
    //     0xc1579c: ldur            d1, [x2, #0x8f]
    // 0xc157a0: fcmp            d1, d0
    // 0xc157a4: b.ne            #0xc157c8
    // 0xc157a8: r0 = Offset()
    //     0xc157a8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc157ac: ldur            d0, [fp, #-0x10]
    // 0xc157b0: StoreField: r0->field_7 = d0
    //     0xc157b0: stur            d0, [x0, #7]
    // 0xc157b4: ldur            d0, [fp, #-8]
    // 0xc157b8: StoreField: r0->field_f = d0
    //     0xc157b8: stur            d0, [x0, #0xf]
    // 0xc157bc: LeaveFrame
    //     0xc157bc: mov             SP, fp
    //     0xc157c0: ldp             fp, lr, [SP], #0x10
    // 0xc157c4: ret
    //     0xc157c4: ret             
    // 0xc157c8: r0 = Null
    //     0xc157c8: mov             x0, NULL
    // 0xc157cc: LeaveFrame
    //     0xc157cc: mov             SP, fp
    //     0xc157d0: ldp             fp, lr, [SP], #0x10
    // 0xc157d4: ret
    //     0xc157d4: ret             
    // 0xc157d8: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157d8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157dc: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157dc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157e0: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157e0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157e4: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157e4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157e8: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157e8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157ec: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157ec: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157f0: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157f0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157f4: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157f4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157f8: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157f8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc157fc: r0 = RangeErrorSharedWithFPURegs()
    //     0xc157fc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15800: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15800: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15804: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15804: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15808: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15808: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc1580c: r0 = RangeErrorSharedWithFPURegs()
    //     0xc1580c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15810: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15810: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15814: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15814: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ inverseTransformRect(/* No info */) {
    // ** addr: 0xc1ca54, size: 0x94
    // 0xc1ca54: EnterFrame
    //     0xc1ca54: stp             fp, lr, [SP, #-0x10]!
    //     0xc1ca58: mov             fp, SP
    // 0xc1ca5c: AllocStack(0x18)
    //     0xc1ca5c: sub             SP, SP, #0x18
    // 0xc1ca60: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1ca60: mov             x0, x2
    //     0xc1ca64: stur            x2, [fp, #-0x10]
    //     0xc1ca68: mov             x2, x1
    //     0xc1ca6c: stur            x1, [fp, #-8]
    // 0xc1ca70: CheckStackOverflow
    //     0xc1ca70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1ca74: cmp             SP, x16
    //     0xc1ca78: b.ls            #0xc1cae0
    // 0xc1ca7c: mov             x1, x2
    // 0xc1ca80: r0 = isIdentity()
    //     0xc1ca80: bl              #0x892998  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0xc1ca84: tbnz            w0, #4, #0xc1ca98
    // 0xc1ca88: ldur            x0, [fp, #-0x10]
    // 0xc1ca8c: LeaveFrame
    //     0xc1ca8c: mov             SP, fp
    //     0xc1ca90: ldp             fp, lr, [SP], #0x10
    // 0xc1ca94: ret
    //     0xc1ca94: ret             
    // 0xc1ca98: r0 = Matrix4()
    //     0xc1ca98: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc1ca9c: r4 = 32
    //     0xc1ca9c: mov             x4, #0x20
    // 0xc1caa0: stur            x0, [fp, #-0x18]
    // 0xc1caa4: r0 = AllocateFloat64Array()
    //     0xc1caa4: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xc1caa8: mov             x1, x0
    // 0xc1caac: ldur            x0, [fp, #-0x18]
    // 0xc1cab0: StoreField: r0->field_7 = r1
    //     0xc1cab0: stur            w1, [x0, #7]
    // 0xc1cab4: mov             x1, x0
    // 0xc1cab8: ldur            x2, [fp, #-8]
    // 0xc1cabc: r0 = setFrom()
    //     0xc1cabc: bl              #0x832b8c  ; [package:vector_math/vector_math_64.dart] Matrix4::setFrom
    // 0xc1cac0: ldur            x1, [fp, #-0x18]
    // 0xc1cac4: r0 = invert()
    //     0xc1cac4: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0xc1cac8: ldur            x1, [fp, #-0x18]
    // 0xc1cacc: ldur            x2, [fp, #-0x10]
    // 0xc1cad0: r0 = transformRect()
    //     0xc1cad0: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0xc1cad4: LeaveFrame
    //     0xc1cad4: mov             SP, fp
    //     0xc1cad8: ldp             fp, lr, [SP], #0x10
    // 0xc1cadc: ret
    //     0xc1cadc: ret             
    // 0xc1cae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1cae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1cae4: b               #0xc1ca7c
  }
}
