// lib: , url: package:flutter/src/painting/notched_shapes.dart

// class id: 1049003, size: 0x8
class :: {
}

// class id: 2915, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class NotchedShape extends Object {
}

// class id: 2916, size: 0x10, field offset: 0x8
//   const constructor, 
class AutomaticNotchedShape extends NotchedShape {

  RoundedRectangleBorder field_8;
}
