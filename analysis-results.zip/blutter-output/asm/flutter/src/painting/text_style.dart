// lib: , url: package:flutter/src/painting/text_style.dart

// class id: 1049013, size: 0x8
class :: {

  static _ lerpFontVariations(/* No info */) {
    // ** addr: 0xfb20ec, size: 0x640
    // 0xfb20ec: EnterFrame
    //     0xfb20ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfb20f0: mov             fp, SP
    // 0xfb20f4: AllocStack(0x58)
    //     0xfb20f4: sub             SP, SP, #0x58
    // 0xfb20f8: d1 = 0.000000
    //     0xfb20f8: eor             v1.16b, v1.16b, v1.16b
    // 0xfb20fc: mov             x3, x1
    // 0xfb2100: mov             x0, x2
    // 0xfb2104: stur            x1, [fp, #-8]
    // 0xfb2108: stur            x2, [fp, #-0x10]
    // 0xfb210c: stur            d0, [fp, #-0x48]
    // 0xfb2110: CheckStackOverflow
    //     0xfb2110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb2114: cmp             SP, x16
    //     0xfb2118: b.ls            #0xfb26ec
    // 0xfb211c: fcmp            d0, d1
    // 0xfb2120: b.ne            #0xfb2134
    // 0xfb2124: mov             x0, x3
    // 0xfb2128: LeaveFrame
    //     0xfb2128: mov             SP, fp
    //     0xfb212c: ldp             fp, lr, [SP], #0x10
    // 0xfb2130: ret
    //     0xfb2130: ret             
    // 0xfb2134: d1 = 1.000000
    //     0xfb2134: fmov            d1, #1.00000000
    // 0xfb2138: fcmp            d0, d1
    // 0xfb213c: b.ne            #0xfb214c
    // 0xfb2140: LeaveFrame
    //     0xfb2140: mov             SP, fp
    //     0xfb2144: ldp             fp, lr, [SP], #0x10
    // 0xfb2148: ret
    //     0xfb2148: ret             
    // 0xfb214c: cmp             w3, NULL
    // 0xfb2150: b.eq            #0xfb216c
    // 0xfb2154: LoadField: r1 = r3->field_b
    //     0xfb2154: ldur            w1, [x3, #0xb]
    // 0xfb2158: cbz             w1, #0xfb216c
    // 0xfb215c: cmp             w0, NULL
    // 0xfb2160: b.eq            #0xfb216c
    // 0xfb2164: LoadField: r1 = r0->field_b
    //     0xfb2164: ldur            w1, [x0, #0xb]
    // 0xfb2168: cbnz            w1, #0xfb2188
    // 0xfb216c: d1 = 0.500000
    //     0xfb216c: fmov            d1, #0.50000000
    // 0xfb2170: fcmp            d1, d0
    // 0xfb2174: b.le            #0xfb217c
    // 0xfb2178: mov             x0, x3
    // 0xfb217c: LeaveFrame
    //     0xfb217c: mov             SP, fp
    //     0xfb2180: ldp             fp, lr, [SP], #0x10
    // 0xfb2184: ret
    //     0xfb2184: ret             
    // 0xfb2188: r1 = <FontVariation>
    //     0xfb2188: add             x1, PP, #0xe, lsl #12  ; [pp+0xe260] TypeArguments: <FontVariation>
    //     0xfb218c: ldr             x1, [x1, #0x260]
    // 0xfb2190: r2 = 0
    //     0xfb2190: mov             x2, #0
    // 0xfb2194: r0 = _GrowableList()
    //     0xfb2194: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb2198: mov             x3, x0
    // 0xfb219c: ldur            x2, [fp, #-8]
    // 0xfb21a0: stur            x3, [fp, #-0x28]
    // 0xfb21a4: LoadField: r0 = r2->field_b
    //     0xfb21a4: ldur            w0, [x2, #0xb]
    // 0xfb21a8: ldur            x4, [fp, #-0x10]
    // 0xfb21ac: LoadField: r1 = r4->field_b
    //     0xfb21ac: ldur            w1, [x4, #0xb]
    // 0xfb21b0: r5 = LoadInt32Instr(r0)
    //     0xfb21b0: sbfx            x5, x0, #1, #0x1f
    // 0xfb21b4: r0 = LoadInt32Instr(r1)
    //     0xfb21b4: sbfx            x0, x1, #1, #0x1f
    // 0xfb21b8: cmp             x5, x0
    // 0xfb21bc: b.lt            #0xfb21c4
    // 0xfb21c0: mov             x5, x0
    // 0xfb21c4: stur            x5, [fp, #-0x20]
    // 0xfb21c8: r6 = 0
    //     0xfb21c8: mov             x6, #0
    // 0xfb21cc: stur            x6, [fp, #-0x18]
    // 0xfb21d0: CheckStackOverflow
    //     0xfb21d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb21d4: cmp             SP, x16
    //     0xfb21d8: b.ls            #0xfb26f4
    // 0xfb21dc: cmp             x6, x5
    // 0xfb21e0: b.ge            #0xfb237c
    // 0xfb21e4: LoadField: r0 = r2->field_b
    //     0xfb21e4: ldur            w0, [x2, #0xb]
    // 0xfb21e8: r1 = LoadInt32Instr(r0)
    //     0xfb21e8: sbfx            x1, x0, #1, #0x1f
    // 0xfb21ec: mov             x0, x1
    // 0xfb21f0: mov             x1, x6
    // 0xfb21f4: cmp             x1, x0
    // 0xfb21f8: b.hs            #0xfb26fc
    // 0xfb21fc: LoadField: r0 = r2->field_f
    //     0xfb21fc: ldur            w0, [x2, #0xf]
    // 0xfb2200: DecompressPointer r0
    //     0xfb2200: add             x0, x0, HEAP, lsl #32
    // 0xfb2204: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0xfb2204: add             x16, x0, x6, lsl #2
    //     0xfb2208: ldur            w1, [x16, #0xf]
    // 0xfb220c: DecompressPointer r1
    //     0xfb220c: add             x1, x1, HEAP, lsl #32
    // 0xfb2210: LoadField: r7 = r1->field_7
    //     0xfb2210: ldur            w7, [x1, #7]
    // 0xfb2214: DecompressPointer r7
    //     0xfb2214: add             x7, x7, HEAP, lsl #32
    // 0xfb2218: LoadField: r0 = r4->field_b
    //     0xfb2218: ldur            w0, [x4, #0xb]
    // 0xfb221c: r1 = LoadInt32Instr(r0)
    //     0xfb221c: sbfx            x1, x0, #1, #0x1f
    // 0xfb2220: mov             x0, x1
    // 0xfb2224: mov             x1, x6
    // 0xfb2228: cmp             x1, x0
    // 0xfb222c: b.hs            #0xfb2700
    // 0xfb2230: LoadField: r0 = r4->field_f
    //     0xfb2230: ldur            w0, [x4, #0xf]
    // 0xfb2234: DecompressPointer r0
    //     0xfb2234: add             x0, x0, HEAP, lsl #32
    // 0xfb2238: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0xfb2238: add             x16, x0, x6, lsl #2
    //     0xfb223c: ldur            w1, [x16, #0xf]
    // 0xfb2240: DecompressPointer r1
    //     0xfb2240: add             x1, x1, HEAP, lsl #32
    // 0xfb2244: LoadField: r0 = r1->field_7
    //     0xfb2244: ldur            w0, [x1, #7]
    // 0xfb2248: DecompressPointer r0
    //     0xfb2248: add             x0, x0, HEAP, lsl #32
    // 0xfb224c: stp             x0, x7, [SP]
    // 0xfb2250: r0 = ==()
    //     0xfb2250: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xfb2254: tbnz            w0, #4, #0xfb2370
    // 0xfb2258: ldur            x3, [fp, #-8]
    // 0xfb225c: ldur            x5, [fp, #-0x10]
    // 0xfb2260: ldur            x4, [fp, #-0x28]
    // 0xfb2264: ldur            x6, [fp, #-0x18]
    // 0xfb2268: LoadField: r0 = r3->field_b
    //     0xfb2268: ldur            w0, [x3, #0xb]
    // 0xfb226c: r1 = LoadInt32Instr(r0)
    //     0xfb226c: sbfx            x1, x0, #1, #0x1f
    // 0xfb2270: mov             x0, x1
    // 0xfb2274: mov             x1, x6
    // 0xfb2278: cmp             x1, x0
    // 0xfb227c: b.hs            #0xfb2704
    // 0xfb2280: LoadField: r0 = r3->field_f
    //     0xfb2280: ldur            w0, [x3, #0xf]
    // 0xfb2284: DecompressPointer r0
    //     0xfb2284: add             x0, x0, HEAP, lsl #32
    // 0xfb2288: ArrayLoad: r2 = r0[r6]  ; Unknown_4
    //     0xfb2288: add             x16, x0, x6, lsl #2
    //     0xfb228c: ldur            w2, [x16, #0xf]
    // 0xfb2290: DecompressPointer r2
    //     0xfb2290: add             x2, x2, HEAP, lsl #32
    // 0xfb2294: LoadField: r0 = r5->field_b
    //     0xfb2294: ldur            w0, [x5, #0xb]
    // 0xfb2298: r1 = LoadInt32Instr(r0)
    //     0xfb2298: sbfx            x1, x0, #1, #0x1f
    // 0xfb229c: mov             x0, x1
    // 0xfb22a0: mov             x1, x6
    // 0xfb22a4: cmp             x1, x0
    // 0xfb22a8: b.hs            #0xfb2708
    // 0xfb22ac: LoadField: r0 = r5->field_f
    //     0xfb22ac: ldur            w0, [x5, #0xf]
    // 0xfb22b0: DecompressPointer r0
    //     0xfb22b0: add             x0, x0, HEAP, lsl #32
    // 0xfb22b4: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0xfb22b4: add             x16, x0, x6, lsl #2
    //     0xfb22b8: ldur            w1, [x16, #0xf]
    // 0xfb22bc: DecompressPointer r1
    //     0xfb22bc: add             x1, x1, HEAP, lsl #32
    // 0xfb22c0: mov             x16, x1
    // 0xfb22c4: mov             x1, x2
    // 0xfb22c8: mov             x2, x16
    // 0xfb22cc: ldur            d0, [fp, #-0x48]
    // 0xfb22d0: r0 = lerp()
    //     0xfb22d0: bl              #0xfb272c  ; [dart:ui] FontVariation::lerp
    // 0xfb22d4: mov             x2, x0
    // 0xfb22d8: ldur            x0, [fp, #-0x28]
    // 0xfb22dc: stur            x2, [fp, #-0x38]
    // 0xfb22e0: LoadField: r1 = r0->field_b
    //     0xfb22e0: ldur            w1, [x0, #0xb]
    // 0xfb22e4: LoadField: r3 = r0->field_f
    //     0xfb22e4: ldur            w3, [x0, #0xf]
    // 0xfb22e8: DecompressPointer r3
    //     0xfb22e8: add             x3, x3, HEAP, lsl #32
    // 0xfb22ec: LoadField: r4 = r3->field_b
    //     0xfb22ec: ldur            w4, [x3, #0xb]
    // 0xfb22f0: r3 = LoadInt32Instr(r1)
    //     0xfb22f0: sbfx            x3, x1, #1, #0x1f
    // 0xfb22f4: stur            x3, [fp, #-0x30]
    // 0xfb22f8: r1 = LoadInt32Instr(r4)
    //     0xfb22f8: sbfx            x1, x4, #1, #0x1f
    // 0xfb22fc: cmp             x3, x1
    // 0xfb2300: b.ne            #0xfb230c
    // 0xfb2304: mov             x1, x0
    // 0xfb2308: r0 = _growToNextCapacity()
    //     0xfb2308: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb230c: ldur            x2, [fp, #-0x28]
    // 0xfb2310: ldur            x4, [fp, #-0x18]
    // 0xfb2314: ldur            x3, [fp, #-0x30]
    // 0xfb2318: add             x0, x3, #1
    // 0xfb231c: lsl             x1, x0, #1
    // 0xfb2320: StoreField: r2->field_b = r1
    //     0xfb2320: stur            w1, [x2, #0xb]
    // 0xfb2324: LoadField: r1 = r2->field_f
    //     0xfb2324: ldur            w1, [x2, #0xf]
    // 0xfb2328: DecompressPointer r1
    //     0xfb2328: add             x1, x1, HEAP, lsl #32
    // 0xfb232c: ldur            x0, [fp, #-0x38]
    // 0xfb2330: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb2330: add             x25, x1, x3, lsl #2
    //     0xfb2334: add             x25, x25, #0xf
    //     0xfb2338: str             w0, [x25]
    //     0xfb233c: tbz             w0, #0, #0xfb2358
    //     0xfb2340: ldurb           w16, [x1, #-1]
    //     0xfb2344: ldurb           w17, [x0, #-1]
    //     0xfb2348: and             x16, x17, x16, lsr #2
    //     0xfb234c: tst             x16, HEAP, lsr #32
    //     0xfb2350: b.eq            #0xfb2358
    //     0xfb2354: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb2358: add             x6, x4, #1
    // 0xfb235c: mov             x3, x2
    // 0xfb2360: ldur            x2, [fp, #-8]
    // 0xfb2364: ldur            x4, [fp, #-0x10]
    // 0xfb2368: ldur            x5, [fp, #-0x20]
    // 0xfb236c: b               #0xfb21cc
    // 0xfb2370: ldur            x2, [fp, #-0x28]
    // 0xfb2374: ldur            x4, [fp, #-0x18]
    // 0xfb2378: b               #0xfb2384
    // 0xfb237c: mov             x2, x3
    // 0xfb2380: mov             x4, x6
    // 0xfb2384: ldur            x0, [fp, #-8]
    // 0xfb2388: ldur            x3, [fp, #-0x10]
    // 0xfb238c: LoadField: r1 = r0->field_b
    //     0xfb238c: ldur            w1, [x0, #0xb]
    // 0xfb2390: LoadField: r5 = r3->field_b
    //     0xfb2390: ldur            w5, [x3, #0xb]
    // 0xfb2394: r6 = LoadInt32Instr(r1)
    //     0xfb2394: sbfx            x6, x1, #1, #0x1f
    // 0xfb2398: r1 = LoadInt32Instr(r5)
    //     0xfb2398: sbfx            x1, x5, #1, #0x1f
    // 0xfb239c: cmp             x6, x1
    // 0xfb23a0: b.le            #0xfb23a8
    // 0xfb23a4: mov             x1, x6
    // 0xfb23a8: cmp             x4, x1
    // 0xfb23ac: b.ge            #0xfb26dc
    // 0xfb23b0: r1 = <String>
    //     0xfb23b0: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xfb23b4: r0 = _HashSet()
    //     0xfb23b4: bl              #0x89f6f0  ; Allocate_HashSetStub -> _HashSet<X0> (size=0x20)
    // 0xfb23b8: stur            x0, [fp, #-0x38]
    // 0xfb23bc: StoreField: r0->field_f = rZR
    //     0xfb23bc: stur            xzr, [x0, #0xf]
    // 0xfb23c0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb23c0: stur            xzr, [x0, #0x17]
    // 0xfb23c4: r1 = <_HashSetEntry<String>?>
    //     0xfb23c4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b50] TypeArguments: <_HashSetEntry<String>?>
    //     0xfb23c8: ldr             x1, [x1, #0xb50]
    // 0xfb23cc: r2 = 16
    //     0xfb23cc: mov             x2, #0x10
    // 0xfb23d0: r0 = AllocateArray()
    //     0xfb23d0: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb23d4: mov             x1, x0
    // 0xfb23d8: ldur            x0, [fp, #-0x38]
    // 0xfb23dc: StoreField: r0->field_b = r1
    //     0xfb23dc: stur            w1, [x0, #0xb]
    // 0xfb23e0: r1 = <String, FontVariation>
    //     0xfb23e0: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b58] TypeArguments: <String, FontVariation>
    //     0xfb23e4: ldr             x1, [x1, #0xb58]
    // 0xfb23e8: r0 = _HashMap()
    //     0xfb23e8: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0xfb23ec: stur            x0, [fp, #-0x40]
    // 0xfb23f0: StoreField: r0->field_b = rZR
    //     0xfb23f0: stur            xzr, [x0, #0xb]
    // 0xfb23f4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb23f4: stur            xzr, [x0, #0x17]
    // 0xfb23f8: r1 = <_HashMapEntry?>
    //     0xfb23f8: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0xfb23fc: ldr             x1, [x1, #0x930]
    // 0xfb2400: r2 = 16
    //     0xfb2400: mov             x2, #0x10
    // 0xfb2404: r0 = AllocateArray()
    //     0xfb2404: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb2408: mov             x1, x0
    // 0xfb240c: ldur            x0, [fp, #-0x40]
    // 0xfb2410: StoreField: r0->field_13 = r1
    //     0xfb2410: stur            w1, [x0, #0x13]
    // 0xfb2414: ldur            x5, [fp, #-0x18]
    // 0xfb2418: ldur            x4, [fp, #-8]
    // 0xfb241c: stur            x5, [fp, #-0x20]
    // 0xfb2420: CheckStackOverflow
    //     0xfb2420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb2424: cmp             SP, x16
    //     0xfb2428: b.ls            #0xfb270c
    // 0xfb242c: LoadField: r1 = r4->field_b
    //     0xfb242c: ldur            w1, [x4, #0xb]
    // 0xfb2430: r2 = LoadInt32Instr(r1)
    //     0xfb2430: sbfx            x2, x1, #1, #0x1f
    // 0xfb2434: cmp             x5, x2
    // 0xfb2438: b.ge            #0xfb24b4
    // 0xfb243c: LoadField: r1 = r4->field_f
    //     0xfb243c: ldur            w1, [x4, #0xf]
    // 0xfb2440: DecompressPointer r1
    //     0xfb2440: add             x1, x1, HEAP, lsl #32
    // 0xfb2444: ArrayLoad: r3 = r1[r5]  ; Unknown_4
    //     0xfb2444: add             x16, x1, x5, lsl #2
    //     0xfb2448: ldur            w3, [x16, #0xf]
    // 0xfb244c: DecompressPointer r3
    //     0xfb244c: add             x3, x3, HEAP, lsl #32
    // 0xfb2450: LoadField: r2 = r3->field_7
    //     0xfb2450: ldur            w2, [x3, #7]
    // 0xfb2454: DecompressPointer r2
    //     0xfb2454: add             x2, x2, HEAP, lsl #32
    // 0xfb2458: mov             x1, x0
    // 0xfb245c: r0 = []=()
    //     0xfb245c: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0xfb2460: ldur            x3, [fp, #-8]
    // 0xfb2464: LoadField: r0 = r3->field_b
    //     0xfb2464: ldur            w0, [x3, #0xb]
    // 0xfb2468: r1 = LoadInt32Instr(r0)
    //     0xfb2468: sbfx            x1, x0, #1, #0x1f
    // 0xfb246c: mov             x0, x1
    // 0xfb2470: ldur            x1, [fp, #-0x20]
    // 0xfb2474: cmp             x1, x0
    // 0xfb2478: b.hs            #0xfb2714
    // 0xfb247c: LoadField: r0 = r3->field_f
    //     0xfb247c: ldur            w0, [x3, #0xf]
    // 0xfb2480: DecompressPointer r0
    //     0xfb2480: add             x0, x0, HEAP, lsl #32
    // 0xfb2484: ldur            x4, [fp, #-0x20]
    // 0xfb2488: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xfb2488: add             x16, x0, x4, lsl #2
    //     0xfb248c: ldur            w1, [x16, #0xf]
    // 0xfb2490: DecompressPointer r1
    //     0xfb2490: add             x1, x1, HEAP, lsl #32
    // 0xfb2494: LoadField: r2 = r1->field_7
    //     0xfb2494: ldur            w2, [x1, #7]
    // 0xfb2498: DecompressPointer r2
    //     0xfb2498: add             x2, x2, HEAP, lsl #32
    // 0xfb249c: ldur            x1, [fp, #-0x38]
    // 0xfb24a0: r0 = add()
    //     0xfb24a0: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0xfb24a4: ldur            x0, [fp, #-0x20]
    // 0xfb24a8: add             x5, x0, #1
    // 0xfb24ac: ldur            x0, [fp, #-0x40]
    // 0xfb24b0: b               #0xfb2418
    // 0xfb24b4: r1 = <String, FontVariation>
    //     0xfb24b4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b58] TypeArguments: <String, FontVariation>
    //     0xfb24b8: ldr             x1, [x1, #0xb58]
    // 0xfb24bc: r0 = _HashMap()
    //     0xfb24bc: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0xfb24c0: stur            x0, [fp, #-8]
    // 0xfb24c4: StoreField: r0->field_b = rZR
    //     0xfb24c4: stur            xzr, [x0, #0xb]
    // 0xfb24c8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb24c8: stur            xzr, [x0, #0x17]
    // 0xfb24cc: r1 = <_HashMapEntry?>
    //     0xfb24cc: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0xfb24d0: ldr             x1, [x1, #0x930]
    // 0xfb24d4: r2 = 16
    //     0xfb24d4: mov             x2, #0x10
    // 0xfb24d8: r0 = AllocateArray()
    //     0xfb24d8: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb24dc: mov             x1, x0
    // 0xfb24e0: ldur            x0, [fp, #-8]
    // 0xfb24e4: StoreField: r0->field_13 = r1
    //     0xfb24e4: stur            w1, [x0, #0x13]
    // 0xfb24e8: ldur            x5, [fp, #-0x18]
    // 0xfb24ec: ldur            x4, [fp, #-0x10]
    // 0xfb24f0: stur            x5, [fp, #-0x18]
    // 0xfb24f4: CheckStackOverflow
    //     0xfb24f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb24f8: cmp             SP, x16
    //     0xfb24fc: b.ls            #0xfb2718
    // 0xfb2500: LoadField: r1 = r4->field_b
    //     0xfb2500: ldur            w1, [x4, #0xb]
    // 0xfb2504: r2 = LoadInt32Instr(r1)
    //     0xfb2504: sbfx            x2, x1, #1, #0x1f
    // 0xfb2508: cmp             x5, x2
    // 0xfb250c: b.ge            #0xfb2588
    // 0xfb2510: LoadField: r1 = r4->field_f
    //     0xfb2510: ldur            w1, [x4, #0xf]
    // 0xfb2514: DecompressPointer r1
    //     0xfb2514: add             x1, x1, HEAP, lsl #32
    // 0xfb2518: ArrayLoad: r3 = r1[r5]  ; Unknown_4
    //     0xfb2518: add             x16, x1, x5, lsl #2
    //     0xfb251c: ldur            w3, [x16, #0xf]
    // 0xfb2520: DecompressPointer r3
    //     0xfb2520: add             x3, x3, HEAP, lsl #32
    // 0xfb2524: LoadField: r2 = r3->field_7
    //     0xfb2524: ldur            w2, [x3, #7]
    // 0xfb2528: DecompressPointer r2
    //     0xfb2528: add             x2, x2, HEAP, lsl #32
    // 0xfb252c: mov             x1, x0
    // 0xfb2530: r0 = []=()
    //     0xfb2530: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0xfb2534: ldur            x3, [fp, #-0x10]
    // 0xfb2538: LoadField: r0 = r3->field_b
    //     0xfb2538: ldur            w0, [x3, #0xb]
    // 0xfb253c: r1 = LoadInt32Instr(r0)
    //     0xfb253c: sbfx            x1, x0, #1, #0x1f
    // 0xfb2540: mov             x0, x1
    // 0xfb2544: ldur            x1, [fp, #-0x18]
    // 0xfb2548: cmp             x1, x0
    // 0xfb254c: b.hs            #0xfb2720
    // 0xfb2550: LoadField: r0 = r3->field_f
    //     0xfb2550: ldur            w0, [x3, #0xf]
    // 0xfb2554: DecompressPointer r0
    //     0xfb2554: add             x0, x0, HEAP, lsl #32
    // 0xfb2558: ldur            x4, [fp, #-0x18]
    // 0xfb255c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xfb255c: add             x16, x0, x4, lsl #2
    //     0xfb2560: ldur            w1, [x16, #0xf]
    // 0xfb2564: DecompressPointer r1
    //     0xfb2564: add             x1, x1, HEAP, lsl #32
    // 0xfb2568: LoadField: r2 = r1->field_7
    //     0xfb2568: ldur            w2, [x1, #7]
    // 0xfb256c: DecompressPointer r2
    //     0xfb256c: add             x2, x2, HEAP, lsl #32
    // 0xfb2570: ldur            x1, [fp, #-0x38]
    // 0xfb2574: r0 = add()
    //     0xfb2574: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0xfb2578: ldur            x0, [fp, #-0x18]
    // 0xfb257c: add             x5, x0, #1
    // 0xfb2580: ldur            x0, [fp, #-8]
    // 0xfb2584: b               #0xfb24ec
    // 0xfb2588: ldur            x0, [fp, #-0x38]
    // 0xfb258c: r1 = <String>
    //     0xfb258c: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xfb2590: r0 = _HashSetIterator()
    //     0xfb2590: bl              #0x90dac0  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0xfb2594: stur            x0, [fp, #-0x10]
    // 0xfb2598: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb2598: stur            xzr, [x0, #0x17]
    // 0xfb259c: ldur            x1, [fp, #-0x38]
    // 0xfb25a0: StoreField: r0->field_b = r1
    //     0xfb25a0: stur            w1, [x0, #0xb]
    // 0xfb25a4: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xfb25a4: ldur            x2, [x1, #0x17]
    // 0xfb25a8: StoreField: r0->field_f = r2
    //     0xfb25a8: stur            x2, [x0, #0xf]
    // 0xfb25ac: ldur            x2, [fp, #-0x28]
    // 0xfb25b0: CheckStackOverflow
    //     0xfb25b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb25b4: cmp             SP, x16
    //     0xfb25b8: b.ls            #0xfb2724
    // 0xfb25bc: mov             x1, x0
    // 0xfb25c0: r0 = moveNext()
    //     0xfb25c0: bl              #0x804abc  ; [dart:collection] _HashSetIterator::moveNext
    // 0xfb25c4: tbnz            w0, #4, #0xfb26d8
    // 0xfb25c8: ldur            x3, [fp, #-0x10]
    // 0xfb25cc: LoadField: r4 = r3->field_23
    //     0xfb25cc: ldur            w4, [x3, #0x23]
    // 0xfb25d0: DecompressPointer r4
    //     0xfb25d0: add             x4, x4, HEAP, lsl #32
    // 0xfb25d4: stur            x4, [fp, #-0x38]
    // 0xfb25d8: cmp             w4, NULL
    // 0xfb25dc: b.ne            #0xfb2618
    // 0xfb25e0: mov             x0, x4
    // 0xfb25e4: r2 = Null
    //     0xfb25e4: mov             x2, NULL
    // 0xfb25e8: r1 = Null
    //     0xfb25e8: mov             x1, NULL
    // 0xfb25ec: r4 = 60
    //     0xfb25ec: mov             x4, #0x3c
    // 0xfb25f0: branchIfSmi(r0, 0xfb25fc)
    //     0xfb25f0: tbz             w0, #0, #0xfb25fc
    // 0xfb25f4: r4 = LoadClassIdInstr(r0)
    //     0xfb25f4: ldur            x4, [x0, #-1]
    //     0xfb25f8: ubfx            x4, x4, #0xc, #0x14
    // 0xfb25fc: sub             x4, x4, #0x5e
    // 0xfb2600: cmp             x4, #1
    // 0xfb2604: b.ls            #0xfb2618
    // 0xfb2608: r8 = String
    //     0xfb2608: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xfb260c: r3 = Null
    //     0xfb260c: add             x3, PP, #0x95, lsl #12  ; [pp+0x95b60] Null
    //     0xfb2610: ldr             x3, [x3, #0xb60]
    // 0xfb2614: r0 = String()
    //     0xfb2614: bl              #0x13ee320  ; IsType_String_Stub
    // 0xfb2618: ldur            x1, [fp, #-0x40]
    // 0xfb261c: ldur            x2, [fp, #-0x38]
    // 0xfb2620: r0 = []()
    //     0xfb2620: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0xfb2624: ldur            x1, [fp, #-8]
    // 0xfb2628: ldur            x2, [fp, #-0x38]
    // 0xfb262c: stur            x0, [fp, #-0x38]
    // 0xfb2630: r0 = []()
    //     0xfb2630: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0xfb2634: ldur            x1, [fp, #-0x38]
    // 0xfb2638: mov             x2, x0
    // 0xfb263c: ldur            d0, [fp, #-0x48]
    // 0xfb2640: r0 = lerp()
    //     0xfb2640: bl              #0xfb272c  ; [dart:ui] FontVariation::lerp
    // 0xfb2644: stur            x0, [fp, #-0x38]
    // 0xfb2648: cmp             w0, NULL
    // 0xfb264c: b.eq            #0xfb26cc
    // 0xfb2650: ldur            x2, [fp, #-0x28]
    // 0xfb2654: LoadField: r1 = r2->field_b
    //     0xfb2654: ldur            w1, [x2, #0xb]
    // 0xfb2658: LoadField: r3 = r2->field_f
    //     0xfb2658: ldur            w3, [x2, #0xf]
    // 0xfb265c: DecompressPointer r3
    //     0xfb265c: add             x3, x3, HEAP, lsl #32
    // 0xfb2660: LoadField: r4 = r3->field_b
    //     0xfb2660: ldur            w4, [x3, #0xb]
    // 0xfb2664: r3 = LoadInt32Instr(r1)
    //     0xfb2664: sbfx            x3, x1, #1, #0x1f
    // 0xfb2668: stur            x3, [fp, #-0x18]
    // 0xfb266c: r1 = LoadInt32Instr(r4)
    //     0xfb266c: sbfx            x1, x4, #1, #0x1f
    // 0xfb2670: cmp             x3, x1
    // 0xfb2674: b.ne            #0xfb2680
    // 0xfb2678: mov             x1, x2
    // 0xfb267c: r0 = _growToNextCapacity()
    //     0xfb267c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb2680: ldur            x2, [fp, #-0x28]
    // 0xfb2684: ldur            x3, [fp, #-0x18]
    // 0xfb2688: add             x4, x3, #1
    // 0xfb268c: lsl             x5, x4, #1
    // 0xfb2690: StoreField: r2->field_b = r5
    //     0xfb2690: stur            w5, [x2, #0xb]
    // 0xfb2694: LoadField: r1 = r2->field_f
    //     0xfb2694: ldur            w1, [x2, #0xf]
    // 0xfb2698: DecompressPointer r1
    //     0xfb2698: add             x1, x1, HEAP, lsl #32
    // 0xfb269c: ldur            x0, [fp, #-0x38]
    // 0xfb26a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb26a0: add             x25, x1, x3, lsl #2
    //     0xfb26a4: add             x25, x25, #0xf
    //     0xfb26a8: str             w0, [x25]
    //     0xfb26ac: tbz             w0, #0, #0xfb26c8
    //     0xfb26b0: ldurb           w16, [x1, #-1]
    //     0xfb26b4: ldurb           w17, [x0, #-1]
    //     0xfb26b8: and             x16, x17, x16, lsr #2
    //     0xfb26bc: tst             x16, HEAP, lsr #32
    //     0xfb26c0: b.eq            #0xfb26c8
    //     0xfb26c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb26c8: b               #0xfb26d0
    // 0xfb26cc: ldur            x2, [fp, #-0x28]
    // 0xfb26d0: ldur            x0, [fp, #-0x10]
    // 0xfb26d4: b               #0xfb25b0
    // 0xfb26d8: ldur            x2, [fp, #-0x28]
    // 0xfb26dc: mov             x0, x2
    // 0xfb26e0: LeaveFrame
    //     0xfb26e0: mov             SP, fp
    //     0xfb26e4: ldp             fp, lr, [SP], #0x10
    // 0xfb26e8: ret
    //     0xfb26e8: ret             
    // 0xfb26ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xfb26ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xfb26f0: b               #0xfb211c
    // 0xfb26f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb26f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb26f8: b               #0xfb21dc
    // 0xfb26fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb26fc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb2700: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb2700: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb2704: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb2704: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb2708: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb2708: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb270c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb270c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb2710: b               #0xfb242c
    // 0xfb2714: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb2714: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb2718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb2718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb271c: b               #0xfb2500
    // 0xfb2720: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb2720: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb2724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb2724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb2728: b               #0xfb25bc
  }
}

// class id: 5040, size: 0x70, field offset: 0x8
//   const constructor, 
class TextStyle extends _MixinApplication3&Object&Diagnosticable {

  bool field_8;
  _Double field_20;
  FontWeight field_24;
  TextBaseline field_34;
  _OneByteString field_5c;
  _Double field_2c;
  Color field_c;
  _OneByteString field_14;
  TextDecoration field_4c;
  _Double field_38;
  TextLeadingDistribution field_3c;
  Color field_50;
  TextDecorationStyle field_54;

  _ getTextStyle(/* No info */) {
    // ** addr: 0x85b480, size: 0x2f4
    // 0x85b480: EnterFrame
    //     0x85b480: stp             fp, lr, [SP, #-0x10]!
    //     0x85b484: mov             fp, SP
    // 0x85b488: AllocStack(0x148)
    //     0x85b488: sub             SP, SP, #0x148
    // 0x85b48c: SetupParameters(TextStyle this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x85b48c: stur            x1, [fp, #-0x10]
    //     0x85b490: mov             x16, x2
    //     0x85b494: mov             x2, x1
    //     0x85b498: mov             x1, x16
    //     0x85b49c: stur            x1, [fp, #-0x18]
    // 0x85b4a0: CheckStackOverflow
    //     0x85b4a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85b4a4: cmp             SP, x16
    //     0x85b4a8: b.ls            #0x85b76c
    // 0x85b4ac: LoadField: r3 = r2->field_1f
    //     0x85b4ac: ldur            w3, [x2, #0x1f]
    // 0x85b4b0: DecompressPointer r3
    //     0x85b4b0: add             x3, x3, HEAP, lsl #32
    // 0x85b4b4: stur            x3, [fp, #-8]
    // 0x85b4b8: cmp             w3, NULL
    // 0x85b4bc: b.ne            #0x85b4cc
    // 0x85b4c0: mov             x0, x2
    // 0x85b4c4: r3 = Null
    //     0x85b4c4: mov             x3, NULL
    // 0x85b4c8: b               #0x85b520
    // 0x85b4cc: r0 = LoadClassIdInstr(r1)
    //     0x85b4cc: ldur            x0, [x1, #-1]
    //     0x85b4d0: ubfx            x0, x0, #0xc, #0x14
    // 0x85b4d4: r16 = Instance__LinearTextScaler
    //     0x85b4d4: ldr             x16, [PP, #0x4a58]  ; [pp+0x4a58] Obj!_LinearTextScaler@129c641
    // 0x85b4d8: stp             x16, x1, [SP]
    // 0x85b4dc: mov             lr, x0
    // 0x85b4e0: ldr             lr, [x21, lr, lsl #3]
    // 0x85b4e4: blr             lr
    // 0x85b4e8: tbnz            w0, #4, #0x85b4f8
    // 0x85b4ec: ldur            x3, [fp, #-8]
    // 0x85b4f0: ldur            x0, [fp, #-0x10]
    // 0x85b4f4: b               #0x85b520
    // 0x85b4f8: ldur            x1, [fp, #-0x18]
    // 0x85b4fc: ldur            x0, [fp, #-8]
    // 0x85b500: LoadField: d0 = r0->field_7
    //     0x85b500: ldur            d0, [x0, #7]
    // 0x85b504: r0 = LoadClassIdInstr(r1)
    //     0x85b504: ldur            x0, [x1, #-1]
    //     0x85b508: ubfx            x0, x0, #0xc, #0x14
    // 0x85b50c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x85b50c: sub             lr, x0, #1, lsl #12
    //     0x85b510: ldr             lr, [x21, lr, lsl #3]
    //     0x85b514: blr             lr
    // 0x85b518: mov             x3, x0
    // 0x85b51c: ldur            x0, [fp, #-0x10]
    // 0x85b520: stur            x3, [fp, #-0x60]
    // 0x85b524: LoadField: r2 = r0->field_b
    //     0x85b524: ldur            w2, [x0, #0xb]
    // 0x85b528: DecompressPointer r2
    //     0x85b528: add             x2, x2, HEAP, lsl #32
    // 0x85b52c: stur            x2, [fp, #-0x58]
    // 0x85b530: LoadField: r4 = r0->field_4b
    //     0x85b530: ldur            w4, [x0, #0x4b]
    // 0x85b534: DecompressPointer r4
    //     0x85b534: add             x4, x4, HEAP, lsl #32
    // 0x85b538: stur            x4, [fp, #-0x50]
    // 0x85b53c: LoadField: r5 = r0->field_4f
    //     0x85b53c: ldur            w5, [x0, #0x4f]
    // 0x85b540: DecompressPointer r5
    //     0x85b540: add             x5, x5, HEAP, lsl #32
    // 0x85b544: stur            x5, [fp, #-0x48]
    // 0x85b548: LoadField: r6 = r0->field_53
    //     0x85b548: ldur            w6, [x0, #0x53]
    // 0x85b54c: DecompressPointer r6
    //     0x85b54c: add             x6, x6, HEAP, lsl #32
    // 0x85b550: stur            x6, [fp, #-0x40]
    // 0x85b554: LoadField: r7 = r0->field_57
    //     0x85b554: ldur            w7, [x0, #0x57]
    // 0x85b558: DecompressPointer r7
    //     0x85b558: add             x7, x7, HEAP, lsl #32
    // 0x85b55c: stur            x7, [fp, #-0x38]
    // 0x85b560: LoadField: r8 = r0->field_23
    //     0x85b560: ldur            w8, [x0, #0x23]
    // 0x85b564: DecompressPointer r8
    //     0x85b564: add             x8, x8, HEAP, lsl #32
    // 0x85b568: stur            x8, [fp, #-0x30]
    // 0x85b56c: LoadField: r9 = r0->field_27
    //     0x85b56c: ldur            w9, [x0, #0x27]
    // 0x85b570: DecompressPointer r9
    //     0x85b570: add             x9, x9, HEAP, lsl #32
    // 0x85b574: stur            x9, [fp, #-0x28]
    // 0x85b578: LoadField: r10 = r0->field_33
    //     0x85b578: ldur            w10, [x0, #0x33]
    // 0x85b57c: DecompressPointer r10
    //     0x85b57c: add             x10, x10, HEAP, lsl #32
    // 0x85b580: stur            x10, [fp, #-0x20]
    // 0x85b584: LoadField: r11 = r0->field_3b
    //     0x85b584: ldur            w11, [x0, #0x3b]
    // 0x85b588: DecompressPointer r11
    //     0x85b588: add             x11, x11, HEAP, lsl #32
    // 0x85b58c: stur            x11, [fp, #-0x18]
    // 0x85b590: LoadField: r12 = r0->field_13
    //     0x85b590: ldur            w12, [x0, #0x13]
    // 0x85b594: DecompressPointer r12
    //     0x85b594: add             x12, x12, HEAP, lsl #32
    // 0x85b598: mov             x1, x0
    // 0x85b59c: stur            x12, [fp, #-8]
    // 0x85b5a0: r0 = fontFamilyFallback()
    //     0x85b5a0: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x85b5a4: mov             x4, x0
    // 0x85b5a8: ldur            x3, [fp, #-0x10]
    // 0x85b5ac: stur            x4, [fp, #-0x98]
    // 0x85b5b0: LoadField: r5 = r3->field_2b
    //     0x85b5b0: ldur            w5, [x3, #0x2b]
    // 0x85b5b4: DecompressPointer r5
    //     0x85b5b4: add             x5, x5, HEAP, lsl #32
    // 0x85b5b8: stur            x5, [fp, #-0x90]
    // 0x85b5bc: LoadField: r6 = r3->field_2f
    //     0x85b5bc: ldur            w6, [x3, #0x2f]
    // 0x85b5c0: DecompressPointer r6
    //     0x85b5c0: add             x6, x6, HEAP, lsl #32
    // 0x85b5c4: stur            x6, [fp, #-0x88]
    // 0x85b5c8: LoadField: r7 = r3->field_37
    //     0x85b5c8: ldur            w7, [x3, #0x37]
    // 0x85b5cc: DecompressPointer r7
    //     0x85b5cc: add             x7, x7, HEAP, lsl #32
    // 0x85b5d0: stur            x7, [fp, #-0x80]
    // 0x85b5d4: LoadField: r8 = r3->field_3f
    //     0x85b5d4: ldur            w8, [x3, #0x3f]
    // 0x85b5d8: DecompressPointer r8
    //     0x85b5d8: add             x8, x8, HEAP, lsl #32
    // 0x85b5dc: stur            x8, [fp, #-0x78]
    // 0x85b5e0: LoadField: r9 = r3->field_43
    //     0x85b5e0: ldur            w9, [x3, #0x43]
    // 0x85b5e4: DecompressPointer r9
    //     0x85b5e4: add             x9, x9, HEAP, lsl #32
    // 0x85b5e8: stur            x9, [fp, #-0x70]
    // 0x85b5ec: LoadField: r0 = r3->field_47
    //     0x85b5ec: ldur            w0, [x3, #0x47]
    // 0x85b5f0: DecompressPointer r0
    //     0x85b5f0: add             x0, x0, HEAP, lsl #32
    // 0x85b5f4: LoadField: r10 = r3->field_f
    //     0x85b5f4: ldur            w10, [x3, #0xf]
    // 0x85b5f8: DecompressPointer r10
    //     0x85b5f8: add             x10, x10, HEAP, lsl #32
    // 0x85b5fc: stur            x10, [fp, #-0x68]
    // 0x85b600: r1 = LoadClassIdInstr(r0)
    //     0x85b600: ldur            x1, [x0, #-1]
    //     0x85b604: ubfx            x1, x1, #0xc, #0x14
    // 0x85b608: cmp             x1, #0xecb
    // 0x85b60c: b.ne            #0x85b61c
    // 0x85b610: mov             x1, x0
    // 0x85b614: mov             x0, x3
    // 0x85b618: b               #0x85b6a4
    // 0x85b61c: mov             x0, x10
    // 0x85b620: r2 = Null
    //     0x85b620: mov             x2, NULL
    // 0x85b624: r1 = Null
    //     0x85b624: mov             x1, NULL
    // 0x85b628: cmp             w0, NULL
    // 0x85b62c: b.eq            #0x85b650
    // 0x85b630: branchIfSmi(r0, 0x85b650)
    //     0x85b630: tbz             w0, #0, #0x85b650
    // 0x85b634: r3 = LoadClassIdInstr(r0)
    //     0x85b634: ldur            x3, [x0, #-1]
    //     0x85b638: ubfx            x3, x3, #0xc, #0x14
    // 0x85b63c: sub             x3, x3, #0xecc
    // 0x85b640: cmp             x3, #5
    // 0x85b644: b.ls            #0x85b658
    // 0x85b648: cmp             x3, #0x5ad
    // 0x85b64c: b.eq            #0x85b658
    // 0x85b650: r0 = false
    //     0x85b650: add             x0, NULL, #0x30  ; false
    // 0x85b654: b               #0x85b65c
    // 0x85b658: r0 = true
    //     0x85b658: add             x0, NULL, #0x20  ; true
    // 0x85b65c: tbnz            w0, #4, #0x85b69c
    // 0x85b660: r16 = 136
    //     0x85b660: mov             x16, #0x88
    // 0x85b664: stp             x16, NULL, [SP]
    // 0x85b668: r0 = ByteData()
    //     0x85b668: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x85b66c: stur            x0, [fp, #-0xa0]
    // 0x85b670: r0 = Paint()
    //     0x85b670: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x85b674: mov             x3, x0
    // 0x85b678: ldur            x0, [fp, #-0xa0]
    // 0x85b67c: stur            x3, [fp, #-0xa8]
    // 0x85b680: StoreField: r3->field_7 = r0
    //     0x85b680: stur            w0, [x3, #7]
    // 0x85b684: mov             x1, x3
    // 0x85b688: ldur            x2, [fp, #-0x68]
    // 0x85b68c: r0 = color=()
    //     0x85b68c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x85b690: ldur            x1, [fp, #-0xa8]
    // 0x85b694: ldur            x0, [fp, #-0x10]
    // 0x85b698: b               #0x85b6a4
    // 0x85b69c: ldur            x0, [fp, #-0x10]
    // 0x85b6a0: r1 = Null
    //     0x85b6a0: mov             x1, NULL
    // 0x85b6a4: stur            x1, [fp, #-0xb0]
    // 0x85b6a8: LoadField: r2 = r0->field_5f
    //     0x85b6a8: ldur            w2, [x0, #0x5f]
    // 0x85b6ac: DecompressPointer r2
    //     0x85b6ac: add             x2, x2, HEAP, lsl #32
    // 0x85b6b0: stur            x2, [fp, #-0xa8]
    // 0x85b6b4: LoadField: r3 = r0->field_63
    //     0x85b6b4: ldur            w3, [x0, #0x63]
    // 0x85b6b8: DecompressPointer r3
    //     0x85b6b8: add             x3, x3, HEAP, lsl #32
    // 0x85b6bc: stur            x3, [fp, #-0xa0]
    // 0x85b6c0: LoadField: r4 = r0->field_67
    //     0x85b6c0: ldur            w4, [x0, #0x67]
    // 0x85b6c4: DecompressPointer r4
    //     0x85b6c4: add             x4, x4, HEAP, lsl #32
    // 0x85b6c8: stur            x4, [fp, #-0x68]
    // 0x85b6cc: r0 = TextStyle()
    //     0x85b6cc: bl              #0x85c488  ; AllocateTextStyleStub -> TextStyle (size=0x44)
    // 0x85b6d0: stur            x0, [fp, #-0x10]
    // 0x85b6d4: ldur            x16, [fp, #-0x58]
    // 0x85b6d8: ldur            lr, [fp, #-0x50]
    // 0x85b6dc: stp             lr, x16, [SP, #0x88]
    // 0x85b6e0: ldur            x16, [fp, #-0x48]
    // 0x85b6e4: ldur            lr, [fp, #-0x40]
    // 0x85b6e8: stp             lr, x16, [SP, #0x78]
    // 0x85b6ec: ldur            x16, [fp, #-0x38]
    // 0x85b6f0: ldur            lr, [fp, #-0x30]
    // 0x85b6f4: stp             lr, x16, [SP, #0x68]
    // 0x85b6f8: ldur            x16, [fp, #-0x28]
    // 0x85b6fc: ldur            lr, [fp, #-0x20]
    // 0x85b700: stp             lr, x16, [SP, #0x58]
    // 0x85b704: ldur            x16, [fp, #-0x18]
    // 0x85b708: ldur            lr, [fp, #-0x98]
    // 0x85b70c: stp             lr, x16, [SP, #0x48]
    // 0x85b710: ldur            x16, [fp, #-0x90]
    // 0x85b714: ldur            lr, [fp, #-0x88]
    // 0x85b718: stp             lr, x16, [SP, #0x38]
    // 0x85b71c: ldur            x16, [fp, #-0x80]
    // 0x85b720: ldur            lr, [fp, #-0x78]
    // 0x85b724: stp             lr, x16, [SP, #0x28]
    // 0x85b728: ldur            x16, [fp, #-0x70]
    // 0x85b72c: ldur            lr, [fp, #-0xb0]
    // 0x85b730: stp             lr, x16, [SP, #0x18]
    // 0x85b734: ldur            x16, [fp, #-0xa8]
    // 0x85b738: ldur            lr, [fp, #-0xa0]
    // 0x85b73c: stp             lr, x16, [SP, #8]
    // 0x85b740: ldur            x16, [fp, #-0x68]
    // 0x85b744: str             x16, [SP]
    // 0x85b748: mov             x1, x0
    // 0x85b74c: ldur            x2, [fp, #-8]
    // 0x85b750: ldur            x3, [fp, #-0x60]
    // 0x85b754: r4 = const [0, 0x16, 0x13, 0x3, background, 0x12, color, 0x3, decoration, 0x4, decorationColor, 0x5, decorationStyle, 0x6, decorationThickness, 0x7, fontFamilyFallback, 0xc, fontFeatures, 0x14, fontStyle, 0x9, fontVariations, 0x15, fontWeight, 0x8, foreground, 0x11, height, 0xf, leadingDistribution, 0xb, letterSpacing, 0xd, locale, 0x10, shadows, 0x13, textBaseline, 0xa, wordSpacing, 0xe, null]
    //     0x85b754: ldr             x4, [PP, #0x4a60]  ; [pp+0x4a60] List(43) [0, 0x16, 0x13, 0x3, "background", 0x12, "color", 0x3, "decoration", 0x4, "decorationColor", 0x5, "decorationStyle", 0x6, "decorationThickness", 0x7, "fontFamilyFallback", 0xc, "fontFeatures", 0x14, "fontStyle", 0x9, "fontVariations", 0x15, "fontWeight", 0x8, "foreground", 0x11, "height", 0xf, "leadingDistribution", 0xb, "letterSpacing", 0xd, "locale", 0x10, "shadows", 0x13, "textBaseline", 0xa, "wordSpacing", 0xe, Null]
    // 0x85b758: r0 = TextStyle()
    //     0x85b758: bl              #0x85b7fc  ; [dart:ui] TextStyle::TextStyle
    // 0x85b75c: ldur            x0, [fp, #-0x10]
    // 0x85b760: LeaveFrame
    //     0x85b760: mov             SP, fp
    //     0x85b764: ldp             fp, lr, [SP], #0x10
    // 0x85b768: ret
    //     0x85b768: ret             
    // 0x85b76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85b76c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85b770: b               #0x85b4ac
  }
  get _ fontFamilyFallback(/* No info */) {
    // ** addr: 0x85c694, size: 0x18c
    // 0x85c694: EnterFrame
    //     0x85c694: stp             fp, lr, [SP, #-0x10]!
    //     0x85c698: mov             fp, SP
    // 0x85c69c: AllocStack(0x28)
    //     0x85c69c: sub             SP, SP, #0x28
    // 0x85c6a0: SetupParameters(TextStyle this /* r1 => r1, fp-0x8 */)
    //     0x85c6a0: stur            x1, [fp, #-8]
    // 0x85c6a4: CheckStackOverflow
    //     0x85c6a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85c6a8: cmp             SP, x16
    //     0x85c6ac: b.ls            #0x85c818
    // 0x85c6b0: r1 = 1
    //     0x85c6b0: mov             x1, #1
    // 0x85c6b4: r0 = AllocateContext()
    //     0x85c6b4: bl              #0x13de838  ; AllocateContextStub
    // 0x85c6b8: mov             x1, x0
    // 0x85c6bc: ldur            x0, [fp, #-8]
    // 0x85c6c0: StoreField: r1->field_f = r0
    //     0x85c6c0: stur            w0, [x1, #0xf]
    // 0x85c6c4: LoadField: r2 = r0->field_1b
    //     0x85c6c4: ldur            w2, [x0, #0x1b]
    // 0x85c6c8: DecompressPointer r2
    //     0x85c6c8: add             x2, x2, HEAP, lsl #32
    // 0x85c6cc: cmp             w2, NULL
    // 0x85c6d0: b.ne            #0x85c6e4
    // 0x85c6d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85c6d4: ldur            w1, [x0, #0x17]
    // 0x85c6d8: DecompressPointer r1
    //     0x85c6d8: add             x1, x1, HEAP, lsl #32
    // 0x85c6dc: mov             x0, x1
    // 0x85c6e0: b               #0x85c80c
    // 0x85c6e4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x85c6e4: ldur            w3, [x0, #0x17]
    // 0x85c6e8: DecompressPointer r3
    //     0x85c6e8: add             x3, x3, HEAP, lsl #32
    // 0x85c6ec: stur            x3, [fp, #-0x10]
    // 0x85c6f0: cmp             w3, NULL
    // 0x85c6f4: b.ne            #0x85c700
    // 0x85c6f8: r1 = Null
    //     0x85c6f8: mov             x1, NULL
    // 0x85c6fc: b               #0x85c808
    // 0x85c700: mov             x2, x1
    // 0x85c704: r1 = Function '<anonymous closure>':.
    //     0x85c704: ldr             x1, [PP, #0x4b00]  ; [pp+0x4b00] AnonymousClosure: (0x85c820), in [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback (0x85c694)
    // 0x85c708: r0 = AllocateClosure()
    //     0x85c708: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x85c70c: r16 = <String>
    //     0x85c70c: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x85c710: ldur            lr, [fp, #-0x10]
    // 0x85c714: stp             lr, x16, [SP, #8]
    // 0x85c718: str             x0, [SP]
    // 0x85c71c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x85c71c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x85c720: r0 = map()
    //     0x85c720: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x85c724: mov             x3, x0
    // 0x85c728: stur            x3, [fp, #-0x10]
    // 0x85c72c: LoadField: r4 = r3->field_7
    //     0x85c72c: ldur            w4, [x3, #7]
    // 0x85c730: DecompressPointer r4
    //     0x85c730: add             x4, x4, HEAP, lsl #32
    // 0x85c734: mov             x0, x3
    // 0x85c738: stur            x4, [fp, #-8]
    // 0x85c73c: r2 = Null
    //     0x85c73c: mov             x2, NULL
    // 0x85c740: r1 = Null
    //     0x85c740: mov             x1, NULL
    // 0x85c744: cmp             w0, NULL
    // 0x85c748: b.eq            #0x85c7d4
    // 0x85c74c: branchIfSmi(r0, 0x85c7d4)
    //     0x85c74c: tbz             w0, #0, #0x85c7d4
    // 0x85c750: r3 = LoadClassIdInstr(r0)
    //     0x85c750: ldur            x3, [x0, #-1]
    //     0x85c754: ubfx            x3, x3, #0xc, #0x14
    // 0x85c758: r17 = 7724
    //     0x85c758: mov             x17, #0x1e2c
    // 0x85c75c: cmp             x3, x17
    // 0x85c760: b.eq            #0x85c7dc
    // 0x85c764: r4 = LoadClassIdInstr(r0)
    //     0x85c764: ldur            x4, [x0, #-1]
    //     0x85c768: ubfx            x4, x4, #0xc, #0x14
    // 0x85c76c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x85c770: ldr             x3, [x3, #0x18]
    // 0x85c774: ldr             x3, [x3, x4, lsl #3]
    // 0x85c778: LoadField: r3 = r3->field_2b
    //     0x85c778: ldur            w3, [x3, #0x2b]
    // 0x85c77c: DecompressPointer r3
    //     0x85c77c: add             x3, x3, HEAP, lsl #32
    // 0x85c780: cmp             w3, NULL
    // 0x85c784: b.eq            #0x85c7d4
    // 0x85c788: LoadField: r3 = r3->field_f
    //     0x85c788: ldur            w3, [x3, #0xf]
    // 0x85c78c: lsr             x3, x3, #3
    // 0x85c790: r17 = 7724
    //     0x85c790: mov             x17, #0x1e2c
    // 0x85c794: cmp             x3, x17
    // 0x85c798: b.eq            #0x85c7dc
    // 0x85c79c: r3 = SubtypeTestCache
    //     0x85c79c: ldr             x3, [PP, #0x4b08]  ; [pp+0x4b08] SubtypeTestCache
    // 0x85c7a0: r30 = Subtype1TestCacheStub
    //     0x85c7a0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x85c7a4: LoadField: r30 = r30->field_7
    //     0x85c7a4: ldur            lr, [lr, #7]
    // 0x85c7a8: blr             lr
    // 0x85c7ac: cmp             w7, NULL
    // 0x85c7b0: b.eq            #0x85c7bc
    // 0x85c7b4: tbnz            w7, #4, #0x85c7d4
    // 0x85c7b8: b               #0x85c7dc
    // 0x85c7bc: r8 = EfficientLengthIterable
    //     0x85c7bc: ldr             x8, [PP, #0x4b10]  ; [pp+0x4b10] Type: EfficientLengthIterable
    // 0x85c7c0: r3 = SubtypeTestCache
    //     0x85c7c0: ldr             x3, [PP, #0x4b18]  ; [pp+0x4b18] SubtypeTestCache
    // 0x85c7c4: r30 = InstanceOfStub
    //     0x85c7c4: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x85c7c8: LoadField: r30 = r30->field_7
    //     0x85c7c8: ldur            lr, [lr, #7]
    // 0x85c7cc: blr             lr
    // 0x85c7d0: b               #0x85c7e0
    // 0x85c7d4: r0 = false
    //     0x85c7d4: add             x0, NULL, #0x30  ; false
    // 0x85c7d8: b               #0x85c7e0
    // 0x85c7dc: r0 = true
    //     0x85c7dc: add             x0, NULL, #0x20  ; true
    // 0x85c7e0: tbnz            w0, #4, #0x85c7f8
    // 0x85c7e4: ldur            x1, [fp, #-8]
    // 0x85c7e8: ldur            x2, [fp, #-0x10]
    // 0x85c7ec: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x85c7ec: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x85c7f0: mov             x1, x0
    // 0x85c7f4: b               #0x85c808
    // 0x85c7f8: ldur            x1, [fp, #-8]
    // 0x85c7fc: ldur            x2, [fp, #-0x10]
    // 0x85c800: r0 = _GrowableList._ofOther()
    //     0x85c800: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x85c804: mov             x1, x0
    // 0x85c808: mov             x0, x1
    // 0x85c80c: LeaveFrame
    //     0x85c80c: mov             SP, fp
    //     0x85c810: ldp             fp, lr, [SP], #0x10
    // 0x85c814: ret
    //     0x85c814: ret             
    // 0x85c818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85c818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85c81c: b               #0x85c6b0
  }
  [closure] String <anonymous closure>(dynamic, String) {
    // ** addr: 0x85c820, size: 0x80
    // 0x85c820: EnterFrame
    //     0x85c820: stp             fp, lr, [SP, #-0x10]!
    //     0x85c824: mov             fp, SP
    // 0x85c828: AllocStack(0x10)
    //     0x85c828: sub             SP, SP, #0x10
    // 0x85c82c: SetupParameters([dynamic _ /* r0 */])
    //     0x85c82c: ldr             x0, [fp, #0x18]
    //     0x85c830: ldur            w3, [x0, #0x17]
    //     0x85c834: add             x3, x3, HEAP, lsl #32
    //     0x85c838: stur            x3, [fp, #-8]
    // 0x85c83c: CheckStackOverflow
    //     0x85c83c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85c840: cmp             SP, x16
    //     0x85c844: b.ls            #0x85c898
    // 0x85c848: r1 = Null
    //     0x85c848: mov             x1, NULL
    // 0x85c84c: r2 = 8
    //     0x85c84c: mov             x2, #8
    // 0x85c850: r0 = AllocateArray()
    //     0x85c850: bl              #0x13df928  ; AllocateArrayStub
    // 0x85c854: r16 = "packages/"
    //     0x85c854: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0x85c858: StoreField: r0->field_f = r16
    //     0x85c858: stur            w16, [x0, #0xf]
    // 0x85c85c: ldur            x1, [fp, #-8]
    // 0x85c860: LoadField: r2 = r1->field_f
    //     0x85c860: ldur            w2, [x1, #0xf]
    // 0x85c864: DecompressPointer r2
    //     0x85c864: add             x2, x2, HEAP, lsl #32
    // 0x85c868: LoadField: r1 = r2->field_1b
    //     0x85c868: ldur            w1, [x2, #0x1b]
    // 0x85c86c: DecompressPointer r1
    //     0x85c86c: add             x1, x1, HEAP, lsl #32
    // 0x85c870: StoreField: r0->field_13 = r1
    //     0x85c870: stur            w1, [x0, #0x13]
    // 0x85c874: r16 = "/"
    //     0x85c874: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x85c878: ArrayStore: r0[0] = r16  ; List_4
    //     0x85c878: stur            w16, [x0, #0x17]
    // 0x85c87c: ldr             x1, [fp, #0x10]
    // 0x85c880: StoreField: r0->field_1b = r1
    //     0x85c880: stur            w1, [x0, #0x1b]
    // 0x85c884: str             x0, [SP]
    // 0x85c888: r0 = _interpolate()
    //     0x85c888: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x85c88c: LeaveFrame
    //     0x85c88c: mov             SP, fp
    //     0x85c890: ldp             fp, lr, [SP], #0x10
    // 0x85c894: ret
    //     0x85c894: ret             
    // 0x85c898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85c898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85c89c: b               #0x85c848
  }
  _ getParagraphStyle(/* No info */) {
    // ** addr: 0x85ce48, size: 0x25c
    // 0x85ce48: EnterFrame
    //     0x85ce48: stp             fp, lr, [SP, #-0x10]!
    //     0x85ce4c: mov             fp, SP
    // 0x85ce50: AllocStack(0xf8)
    //     0x85ce50: sub             SP, SP, #0xf8
    // 0x85ce54: SetupParameters(TextStyle this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x85ce54: stur            x1, [fp, #-8]
    //     0x85ce58: stur            x2, [fp, #-0x10]
    //     0x85ce5c: stur            x3, [fp, #-0x18]
    //     0x85ce60: stur            x5, [fp, #-0x20]
    //     0x85ce64: stur            x6, [fp, #-0x28]
    //     0x85ce68: stur            x7, [fp, #-0x30]
    // 0x85ce6c: CheckStackOverflow
    //     0x85ce6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85ce70: cmp             SP, x16
    //     0x85ce74: b.ls            #0x85d09c
    // 0x85ce78: LoadField: r0 = r1->field_3b
    //     0x85ce78: ldur            w0, [x1, #0x3b]
    // 0x85ce7c: DecompressPointer r0
    //     0x85ce7c: add             x0, x0, HEAP, lsl #32
    // 0x85ce80: cmp             w0, NULL
    // 0x85ce84: b.ne            #0x85ce94
    // 0x85ce88: mov             x2, x1
    // 0x85ce8c: r3 = Null
    //     0x85ce8c: mov             x3, NULL
    // 0x85ce90: b               #0x85ceb8
    // 0x85ce94: r0 = TextHeightBehavior()
    //     0x85ce94: bl              #0x85dc30  ; AllocateTextHeightBehaviorStub -> TextHeightBehavior (size=0x14)
    // 0x85ce98: mov             x1, x0
    // 0x85ce9c: r0 = true
    //     0x85ce9c: add             x0, NULL, #0x20  ; true
    // 0x85cea0: StoreField: r1->field_7 = r0
    //     0x85cea0: stur            w0, [x1, #7]
    // 0x85cea4: StoreField: r1->field_b = r0
    //     0x85cea4: stur            w0, [x1, #0xb]
    // 0x85cea8: r0 = Instance_TextLeadingDistribution
    //     0x85cea8: ldr             x0, [PP, #0x4b40]  ; [pp+0x4b40] Obj!TextLeadingDistribution@12c73e1
    // 0x85ceac: StoreField: r1->field_f = r0
    //     0x85ceac: stur            w0, [x1, #0xf]
    // 0x85ceb0: mov             x3, x1
    // 0x85ceb4: ldur            x2, [fp, #-8]
    // 0x85ceb8: stur            x3, [fp, #-0x50]
    // 0x85cebc: LoadField: r4 = r2->field_23
    //     0x85cebc: ldur            w4, [x2, #0x23]
    // 0x85cec0: DecompressPointer r4
    //     0x85cec0: add             x4, x4, HEAP, lsl #32
    // 0x85cec4: stur            x4, [fp, #-0x48]
    // 0x85cec8: LoadField: r5 = r2->field_27
    //     0x85cec8: ldur            w5, [x2, #0x27]
    // 0x85cecc: DecompressPointer r5
    //     0x85cecc: add             x5, x5, HEAP, lsl #32
    // 0x85ced0: stur            x5, [fp, #-0x40]
    // 0x85ced4: LoadField: r6 = r2->field_13
    //     0x85ced4: ldur            w6, [x2, #0x13]
    // 0x85ced8: DecompressPointer r6
    //     0x85ced8: add             x6, x6, HEAP, lsl #32
    // 0x85cedc: stur            x6, [fp, #-0x38]
    // 0x85cee0: LoadField: r0 = r2->field_1f
    //     0x85cee0: ldur            w0, [x2, #0x1f]
    // 0x85cee4: DecompressPointer r0
    //     0x85cee4: add             x0, x0, HEAP, lsl #32
    // 0x85cee8: cmp             w0, NULL
    // 0x85ceec: b.ne            #0x85cef8
    // 0x85cef0: d0 = 14.000000
    //     0x85cef0: fmov            d0, #14.00000000
    // 0x85cef4: b               #0x85cefc
    // 0x85cef8: LoadField: d0 = r0->field_7
    //     0x85cef8: ldur            d0, [x0, #7]
    // 0x85cefc: ldur            x7, [fp, #-0x28]
    // 0x85cf00: ldr             x8, [fp, #0x10]
    // 0x85cf04: r0 = LoadClassIdInstr(r8)
    //     0x85cf04: ldur            x0, [x8, #-1]
    //     0x85cf08: ubfx            x0, x0, #0xc, #0x14
    // 0x85cf0c: mov             x1, x8
    // 0x85cf10: r0 = GDT[cid_x0 + -0x1000]()
    //     0x85cf10: sub             lr, x0, #1, lsl #12
    //     0x85cf14: ldr             lr, [x21, lr, lsl #3]
    //     0x85cf18: blr             lr
    // 0x85cf1c: mov             x2, x0
    // 0x85cf20: ldur            x0, [fp, #-8]
    // 0x85cf24: stur            x2, [fp, #-0x68]
    // 0x85cf28: LoadField: r3 = r0->field_37
    //     0x85cf28: ldur            w3, [x0, #0x37]
    // 0x85cf2c: DecompressPointer r3
    //     0x85cf2c: add             x3, x3, HEAP, lsl #32
    // 0x85cf30: ldur            x4, [fp, #-0x28]
    // 0x85cf34: stur            x3, [fp, #-0x60]
    // 0x85cf38: cmp             w4, NULL
    // 0x85cf3c: b.ne            #0x85cf48
    // 0x85cf40: r0 = Null
    //     0x85cf40: mov             x0, NULL
    // 0x85cf44: b               #0x85d02c
    // 0x85cf48: LoadField: r5 = r4->field_7
    //     0x85cf48: ldur            w5, [x4, #7]
    // 0x85cf4c: DecompressPointer r5
    //     0x85cf4c: add             x5, x5, HEAP, lsl #32
    // 0x85cf50: stur            x5, [fp, #-0x58]
    // 0x85cf54: LoadField: r6 = r4->field_b
    //     0x85cf54: ldur            w6, [x4, #0xb]
    // 0x85cf58: DecompressPointer r6
    //     0x85cf58: add             x6, x6, HEAP, lsl #32
    // 0x85cf5c: stur            x6, [fp, #-8]
    // 0x85cf60: LoadField: r0 = r4->field_13
    //     0x85cf60: ldur            w0, [x4, #0x13]
    // 0x85cf64: DecompressPointer r0
    //     0x85cf64: add             x0, x0, HEAP, lsl #32
    // 0x85cf68: cmp             w0, NULL
    // 0x85cf6c: b.ne            #0x85cf7c
    // 0x85cf70: mov             x0, x4
    // 0x85cf74: r5 = Null
    //     0x85cf74: mov             x5, NULL
    // 0x85cf78: b               #0x85cfa0
    // 0x85cf7c: ldr             x1, [fp, #0x10]
    // 0x85cf80: LoadField: d0 = r0->field_7
    //     0x85cf80: ldur            d0, [x0, #7]
    // 0x85cf84: r0 = LoadClassIdInstr(r1)
    //     0x85cf84: ldur            x0, [x1, #-1]
    //     0x85cf88: ubfx            x0, x0, #0xc, #0x14
    // 0x85cf8c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x85cf8c: sub             lr, x0, #1, lsl #12
    //     0x85cf90: ldr             lr, [x21, lr, lsl #3]
    //     0x85cf94: blr             lr
    // 0x85cf98: mov             x5, x0
    // 0x85cf9c: ldur            x0, [fp, #-0x28]
    // 0x85cfa0: stur            x5, [fp, #-0xa0]
    // 0x85cfa4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85cfa4: ldur            w1, [x0, #0x17]
    // 0x85cfa8: DecompressPointer r1
    //     0x85cfa8: add             x1, x1, HEAP, lsl #32
    // 0x85cfac: stur            x1, [fp, #-0x98]
    // 0x85cfb0: LoadField: r2 = r0->field_27
    //     0x85cfb0: ldur            w2, [x0, #0x27]
    // 0x85cfb4: DecompressPointer r2
    //     0x85cfb4: add             x2, x2, HEAP, lsl #32
    // 0x85cfb8: stur            x2, [fp, #-0x90]
    // 0x85cfbc: LoadField: r3 = r0->field_1b
    //     0x85cfbc: ldur            w3, [x0, #0x1b]
    // 0x85cfc0: DecompressPointer r3
    //     0x85cfc0: add             x3, x3, HEAP, lsl #32
    // 0x85cfc4: stur            x3, [fp, #-0x88]
    // 0x85cfc8: LoadField: r7 = r0->field_1f
    //     0x85cfc8: ldur            w7, [x0, #0x1f]
    // 0x85cfcc: DecompressPointer r7
    //     0x85cfcc: add             x7, x7, HEAP, lsl #32
    // 0x85cfd0: stur            x7, [fp, #-0x80]
    // 0x85cfd4: LoadField: r6 = r0->field_23
    //     0x85cfd4: ldur            w6, [x0, #0x23]
    // 0x85cfd8: DecompressPointer r6
    //     0x85cfd8: add             x6, x6, HEAP, lsl #32
    // 0x85cfdc: stur            x6, [fp, #-0x78]
    // 0x85cfe0: LoadField: r4 = r0->field_2b
    //     0x85cfe0: ldur            w4, [x0, #0x2b]
    // 0x85cfe4: DecompressPointer r4
    //     0x85cfe4: add             x4, x4, HEAP, lsl #32
    // 0x85cfe8: stur            x4, [fp, #-0x70]
    // 0x85cfec: r0 = StrutStyle()
    //     0x85cfec: bl              #0x85dc24  ; AllocateStrutStyleStub -> StrutStyle (size=0x18)
    // 0x85cff0: stur            x0, [fp, #-0x28]
    // 0x85cff4: ldur            x16, [fp, #-0x70]
    // 0x85cff8: ldur            lr, [fp, #-0x98]
    // 0x85cffc: stp             lr, x16, [SP, #0x10]
    // 0x85d000: ldur            x16, [fp, #-0x90]
    // 0x85d004: ldur            lr, [fp, #-0x88]
    // 0x85d008: stp             lr, x16, [SP]
    // 0x85d00c: mov             x1, x0
    // 0x85d010: ldur            x2, [fp, #-0x58]
    // 0x85d014: ldur            x3, [fp, #-8]
    // 0x85d018: ldur            x5, [fp, #-0xa0]
    // 0x85d01c: ldur            x6, [fp, #-0x78]
    // 0x85d020: ldur            x7, [fp, #-0x80]
    // 0x85d024: r0 = StrutStyle()
    //     0x85d024: bl              #0x85d800  ; [dart:ui] StrutStyle::StrutStyle
    // 0x85d028: ldur            x0, [fp, #-0x28]
    // 0x85d02c: stur            x0, [fp, #-8]
    // 0x85d030: r0 = ParagraphStyle()
    //     0x85d030: bl              #0x85d7f4  ; AllocateParagraphStyleStub -> ParagraphStyle (size=0x28)
    // 0x85d034: stur            x0, [fp, #-0x28]
    // 0x85d038: ldur            x16, [fp, #-0x30]
    // 0x85d03c: ldur            lr, [fp, #-0x48]
    // 0x85d040: stp             lr, x16, [SP, #0x48]
    // 0x85d044: ldur            x16, [fp, #-0x40]
    // 0x85d048: ldur            lr, [fp, #-0x38]
    // 0x85d04c: stp             lr, x16, [SP, #0x38]
    // 0x85d050: ldur            x16, [fp, #-0x68]
    // 0x85d054: ldur            lr, [fp, #-0x60]
    // 0x85d058: stp             lr, x16, [SP, #0x28]
    // 0x85d05c: ldur            x16, [fp, #-0x50]
    // 0x85d060: ldur            lr, [fp, #-8]
    // 0x85d064: stp             lr, x16, [SP, #0x18]
    // 0x85d068: ldur            x16, [fp, #-0x20]
    // 0x85d06c: ldur            lr, [fp, #-0x10]
    // 0x85d070: stp             lr, x16, [SP, #8]
    // 0x85d074: ldur            x16, [fp, #-0x18]
    // 0x85d078: str             x16, [SP]
    // 0x85d07c: mov             x1, x0
    // 0x85d080: ldr             x2, [fp, #0x18]
    // 0x85d084: r4 = const [0, 0xd, 0xb, 0x2, ellipsis, 0xb, fontFamily, 0x5, fontSize, 0x6, fontStyle, 0x4, fontWeight, 0x3, height, 0x7, locale, 0xc, maxLines, 0xa, strutStyle, 0x9, textAlign, 0x2, textHeightBehavior, 0x8, null]
    //     0x85d084: ldr             x4, [PP, #0x4b48]  ; [pp+0x4b48] List(27) [0, 0xd, 0xb, 0x2, "ellipsis", 0xb, "fontFamily", 0x5, "fontSize", 0x6, "fontStyle", 0x4, "fontWeight", 0x3, "height", 0x7, "locale", 0xc, "maxLines", 0xa, "strutStyle", 0x9, "textAlign", 0x2, "textHeightBehavior", 0x8, Null]
    // 0x85d088: r0 = ParagraphStyle()
    //     0x85d088: bl              #0x85d0a4  ; [dart:ui] ParagraphStyle::ParagraphStyle
    // 0x85d08c: ldur            x0, [fp, #-0x28]
    // 0x85d090: LeaveFrame
    //     0x85d090: mov             SP, fp
    //     0x85d094: ldp             fp, lr, [SP], #0x10
    // 0x85d098: ret
    //     0x85d098: ret             
    // 0x85d09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85d09c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85d0a0: b               #0x85ce78
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x8a5ba4, size: 0xd50
    // 0x8a5ba4: EnterFrame
    //     0x8a5ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5ba8: mov             fp, SP
    // 0x8a5bac: AllocStack(0xe8)
    //     0x8a5bac: sub             SP, SP, #0xe8
    // 0x8a5bb0: SetupParameters(TextStyle this /* r1 => r0, fp-0xd0 */, {dynamic background = Null /* r3 */, dynamic backgroundColor = Null /* r5 */, dynamic color = Null /* r6 */, dynamic decoration = Null /* fp-0x30 */, dynamic decorationColor = Null /* fp-0x28 */, dynamic decorationStyle = Null /* fp-0x20 */, dynamic decorationThickness = Null /* fp-0x18 */, dynamic fontFamily = Null /* fp-0x10 */, dynamic fontFamilyFallback = Null /* fp-0x8 */, dynamic fontFeatures = Null /* fp-0x40 */, dynamic fontSize = Null /* r14 */, dynamic fontStyle = Null /* r19 */, dynamic fontVariations = Null /* fp-0x38 */, dynamic fontWeight = Null /* r12 */, dynamic foreground = Null /* r11 */, dynamic height = Null /* r10 */, dynamic inherit = Null /* r9 */, dynamic leadingDistribution = Null /* r8 */, dynamic letterSpacing = Null /* r7 */, dynamic locale = Null /* r20 */, dynamic overflow = Null /* fp-0x48 */, dynamic package = Null /* fp-0x50 */, dynamic shadows = Null /* fp-0x58 */, dynamic textBaseline = Null /* r13 */, dynamic wordSpacing = Null /* r1 */})
    //     0x8a5bb0: mov             x0, x1
    //     0x8a5bb4: stur            x1, [fp, #-0xd0]
    //     0x8a5bb8: ldur            w1, [x4, #0x13]
    //     0x8a5bbc: ldur            w2, [x4, #0x1f]
    //     0x8a5bc0: add             x2, x2, HEAP, lsl #32
    //     0x8a5bc4: ldr             x16, [PP, #0x4a68]  ; [pp+0x4a68] "background"
    //     0x8a5bc8: cmp             w2, w16
    //     0x8a5bcc: b.ne            #0x8a5bf0
    //     0x8a5bd0: ldur            w2, [x4, #0x23]
    //     0x8a5bd4: add             x2, x2, HEAP, lsl #32
    //     0x8a5bd8: sub             w3, w1, w2
    //     0x8a5bdc: add             x2, fp, w3, sxtw #2
    //     0x8a5be0: ldr             x2, [x2, #8]
    //     0x8a5be4: mov             x3, x2
    //     0x8a5be8: mov             x2, #1
    //     0x8a5bec: b               #0x8a5bf8
    //     0x8a5bf0: mov             x3, NULL
    //     0x8a5bf4: mov             x2, #0
    //     0x8a5bf8: lsl             x5, x2, #1
    //     0x8a5bfc: lsl             w6, w5, #1
    //     0x8a5c00: add             w7, w6, #8
    //     0x8a5c04: add             x16, x4, w7, sxtw #1
    //     0x8a5c08: ldur            w8, [x16, #0xf]
    //     0x8a5c0c: add             x8, x8, HEAP, lsl #32
    //     0x8a5c10: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0x8a5c14: ldr             x16, [x16, #0x958]
    //     0x8a5c18: cmp             w8, w16
    //     0x8a5c1c: b.ne            #0x8a5c50
    //     0x8a5c20: add             w2, w6, #0xa
    //     0x8a5c24: add             x16, x4, w2, sxtw #1
    //     0x8a5c28: ldur            w6, [x16, #0xf]
    //     0x8a5c2c: add             x6, x6, HEAP, lsl #32
    //     0x8a5c30: sub             w2, w1, w6
    //     0x8a5c34: add             x6, fp, w2, sxtw #2
    //     0x8a5c38: ldr             x6, [x6, #8]
    //     0x8a5c3c: add             w2, w5, #2
    //     0x8a5c40: sbfx            x5, x2, #1, #0x1f
    //     0x8a5c44: mov             x2, x5
    //     0x8a5c48: mov             x5, x6
    //     0x8a5c4c: b               #0x8a5c54
    //     0x8a5c50: mov             x5, NULL
    //     0x8a5c54: lsl             x6, x2, #1
    //     0x8a5c58: lsl             w7, w6, #1
    //     0x8a5c5c: add             w8, w7, #8
    //     0x8a5c60: add             x16, x4, w8, sxtw #1
    //     0x8a5c64: ldur            w9, [x16, #0xf]
    //     0x8a5c68: add             x9, x9, HEAP, lsl #32
    //     0x8a5c6c: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0x8a5c70: cmp             w9, w16
    //     0x8a5c74: b.ne            #0x8a5ca8
    //     0x8a5c78: add             w2, w7, #0xa
    //     0x8a5c7c: add             x16, x4, w2, sxtw #1
    //     0x8a5c80: ldur            w7, [x16, #0xf]
    //     0x8a5c84: add             x7, x7, HEAP, lsl #32
    //     0x8a5c88: sub             w2, w1, w7
    //     0x8a5c8c: add             x7, fp, w2, sxtw #2
    //     0x8a5c90: ldr             x7, [x7, #8]
    //     0x8a5c94: add             w2, w6, #2
    //     0x8a5c98: sbfx            x6, x2, #1, #0x1f
    //     0x8a5c9c: mov             x2, x6
    //     0x8a5ca0: mov             x6, x7
    //     0x8a5ca4: b               #0x8a5cac
    //     0x8a5ca8: mov             x6, NULL
    //     0x8a5cac: lsl             x7, x2, #1
    //     0x8a5cb0: lsl             w8, w7, #1
    //     0x8a5cb4: add             w9, w8, #8
    //     0x8a5cb8: add             x16, x4, w9, sxtw #1
    //     0x8a5cbc: ldur            w10, [x16, #0xf]
    //     0x8a5cc0: add             x10, x10, HEAP, lsl #32
    //     0x8a5cc4: ldr             x16, [PP, #0x4a78]  ; [pp+0x4a78] "decoration"
    //     0x8a5cc8: cmp             w10, w16
    //     0x8a5ccc: b.ne            #0x8a5d00
    //     0x8a5cd0: add             w2, w8, #0xa
    //     0x8a5cd4: add             x16, x4, w2, sxtw #1
    //     0x8a5cd8: ldur            w8, [x16, #0xf]
    //     0x8a5cdc: add             x8, x8, HEAP, lsl #32
    //     0x8a5ce0: sub             w2, w1, w8
    //     0x8a5ce4: add             x8, fp, w2, sxtw #2
    //     0x8a5ce8: ldr             x8, [x8, #8]
    //     0x8a5cec: add             w2, w7, #2
    //     0x8a5cf0: sbfx            x7, x2, #1, #0x1f
    //     0x8a5cf4: mov             x2, x7
    //     0x8a5cf8: mov             x7, x8
    //     0x8a5cfc: b               #0x8a5d04
    //     0x8a5d00: mov             x7, NULL
    //     0x8a5d04: stur            x7, [fp, #-0x30]
    //     0x8a5d08: lsl             x8, x2, #1
    //     0x8a5d0c: lsl             w9, w8, #1
    //     0x8a5d10: add             w10, w9, #8
    //     0x8a5d14: add             x16, x4, w10, sxtw #1
    //     0x8a5d18: ldur            w11, [x16, #0xf]
    //     0x8a5d1c: add             x11, x11, HEAP, lsl #32
    //     0x8a5d20: ldr             x16, [PP, #0x4a80]  ; [pp+0x4a80] "decorationColor"
    //     0x8a5d24: cmp             w11, w16
    //     0x8a5d28: b.ne            #0x8a5d5c
    //     0x8a5d2c: add             w2, w9, #0xa
    //     0x8a5d30: add             x16, x4, w2, sxtw #1
    //     0x8a5d34: ldur            w9, [x16, #0xf]
    //     0x8a5d38: add             x9, x9, HEAP, lsl #32
    //     0x8a5d3c: sub             w2, w1, w9
    //     0x8a5d40: add             x9, fp, w2, sxtw #2
    //     0x8a5d44: ldr             x9, [x9, #8]
    //     0x8a5d48: add             w2, w8, #2
    //     0x8a5d4c: sbfx            x8, x2, #1, #0x1f
    //     0x8a5d50: mov             x2, x8
    //     0x8a5d54: mov             x8, x9
    //     0x8a5d58: b               #0x8a5d60
    //     0x8a5d5c: mov             x8, NULL
    //     0x8a5d60: stur            x8, [fp, #-0x28]
    //     0x8a5d64: lsl             x9, x2, #1
    //     0x8a5d68: lsl             w10, w9, #1
    //     0x8a5d6c: add             w11, w10, #8
    //     0x8a5d70: add             x16, x4, w11, sxtw #1
    //     0x8a5d74: ldur            w12, [x16, #0xf]
    //     0x8a5d78: add             x12, x12, HEAP, lsl #32
    //     0x8a5d7c: ldr             x16, [PP, #0x4a88]  ; [pp+0x4a88] "decorationStyle"
    //     0x8a5d80: cmp             w12, w16
    //     0x8a5d84: b.ne            #0x8a5db8
    //     0x8a5d88: add             w2, w10, #0xa
    //     0x8a5d8c: add             x16, x4, w2, sxtw #1
    //     0x8a5d90: ldur            w10, [x16, #0xf]
    //     0x8a5d94: add             x10, x10, HEAP, lsl #32
    //     0x8a5d98: sub             w2, w1, w10
    //     0x8a5d9c: add             x10, fp, w2, sxtw #2
    //     0x8a5da0: ldr             x10, [x10, #8]
    //     0x8a5da4: add             w2, w9, #2
    //     0x8a5da8: sbfx            x9, x2, #1, #0x1f
    //     0x8a5dac: mov             x2, x9
    //     0x8a5db0: mov             x9, x10
    //     0x8a5db4: b               #0x8a5dbc
    //     0x8a5db8: mov             x9, NULL
    //     0x8a5dbc: stur            x9, [fp, #-0x20]
    //     0x8a5dc0: lsl             x10, x2, #1
    //     0x8a5dc4: lsl             w11, w10, #1
    //     0x8a5dc8: add             w12, w11, #8
    //     0x8a5dcc: add             x16, x4, w12, sxtw #1
    //     0x8a5dd0: ldur            w13, [x16, #0xf]
    //     0x8a5dd4: add             x13, x13, HEAP, lsl #32
    //     0x8a5dd8: ldr             x16, [PP, #0x4a90]  ; [pp+0x4a90] "decorationThickness"
    //     0x8a5ddc: cmp             w13, w16
    //     0x8a5de0: b.ne            #0x8a5e14
    //     0x8a5de4: add             w2, w11, #0xa
    //     0x8a5de8: add             x16, x4, w2, sxtw #1
    //     0x8a5dec: ldur            w11, [x16, #0xf]
    //     0x8a5df0: add             x11, x11, HEAP, lsl #32
    //     0x8a5df4: sub             w2, w1, w11
    //     0x8a5df8: add             x11, fp, w2, sxtw #2
    //     0x8a5dfc: ldr             x11, [x11, #8]
    //     0x8a5e00: add             w2, w10, #2
    //     0x8a5e04: sbfx            x10, x2, #1, #0x1f
    //     0x8a5e08: mov             x2, x10
    //     0x8a5e0c: mov             x10, x11
    //     0x8a5e10: b               #0x8a5e18
    //     0x8a5e14: mov             x10, NULL
    //     0x8a5e18: stur            x10, [fp, #-0x18]
    //     0x8a5e1c: lsl             x11, x2, #1
    //     0x8a5e20: lsl             w12, w11, #1
    //     0x8a5e24: add             w13, w12, #8
    //     0x8a5e28: add             x16, x4, w13, sxtw #1
    //     0x8a5e2c: ldur            w14, [x16, #0xf]
    //     0x8a5e30: add             x14, x14, HEAP, lsl #32
    //     0x8a5e34: ldr             x16, [PP, #0x4b58]  ; [pp+0x4b58] "fontFamily"
    //     0x8a5e38: cmp             w14, w16
    //     0x8a5e3c: b.ne            #0x8a5e70
    //     0x8a5e40: add             w2, w12, #0xa
    //     0x8a5e44: add             x16, x4, w2, sxtw #1
    //     0x8a5e48: ldur            w12, [x16, #0xf]
    //     0x8a5e4c: add             x12, x12, HEAP, lsl #32
    //     0x8a5e50: sub             w2, w1, w12
    //     0x8a5e54: add             x12, fp, w2, sxtw #2
    //     0x8a5e58: ldr             x12, [x12, #8]
    //     0x8a5e5c: add             w2, w11, #2
    //     0x8a5e60: sbfx            x11, x2, #1, #0x1f
    //     0x8a5e64: mov             x2, x11
    //     0x8a5e68: mov             x11, x12
    //     0x8a5e6c: b               #0x8a5e74
    //     0x8a5e70: mov             x11, NULL
    //     0x8a5e74: stur            x11, [fp, #-0x10]
    //     0x8a5e78: lsl             x12, x2, #1
    //     0x8a5e7c: lsl             w13, w12, #1
    //     0x8a5e80: add             w14, w13, #8
    //     0x8a5e84: add             x16, x4, w14, sxtw #1
    //     0x8a5e88: ldur            w19, [x16, #0xf]
    //     0x8a5e8c: add             x19, x19, HEAP, lsl #32
    //     0x8a5e90: ldr             x16, [PP, #0x4a98]  ; [pp+0x4a98] "fontFamilyFallback"
    //     0x8a5e94: cmp             w19, w16
    //     0x8a5e98: b.ne            #0x8a5ecc
    //     0x8a5e9c: add             w2, w13, #0xa
    //     0x8a5ea0: add             x16, x4, w2, sxtw #1
    //     0x8a5ea4: ldur            w13, [x16, #0xf]
    //     0x8a5ea8: add             x13, x13, HEAP, lsl #32
    //     0x8a5eac: sub             w2, w1, w13
    //     0x8a5eb0: add             x13, fp, w2, sxtw #2
    //     0x8a5eb4: ldr             x13, [x13, #8]
    //     0x8a5eb8: add             w2, w12, #2
    //     0x8a5ebc: sbfx            x12, x2, #1, #0x1f
    //     0x8a5ec0: mov             x2, x12
    //     0x8a5ec4: mov             x12, x13
    //     0x8a5ec8: b               #0x8a5ed0
    //     0x8a5ecc: mov             x12, NULL
    //     0x8a5ed0: stur            x12, [fp, #-8]
    //     0x8a5ed4: lsl             x13, x2, #1
    //     0x8a5ed8: lsl             w14, w13, #1
    //     0x8a5edc: add             w19, w14, #8
    //     0x8a5ee0: add             x16, x4, w19, sxtw #1
    //     0x8a5ee4: ldur            w20, [x16, #0xf]
    //     0x8a5ee8: add             x20, x20, HEAP, lsl #32
    //     0x8a5eec: ldr             x16, [PP, #0x4aa0]  ; [pp+0x4aa0] "fontFeatures"
    //     0x8a5ef0: cmp             w20, w16
    //     0x8a5ef4: b.ne            #0x8a5f28
    //     0x8a5ef8: add             w2, w14, #0xa
    //     0x8a5efc: add             x16, x4, w2, sxtw #1
    //     0x8a5f00: ldur            w14, [x16, #0xf]
    //     0x8a5f04: add             x14, x14, HEAP, lsl #32
    //     0x8a5f08: sub             w2, w1, w14
    //     0x8a5f0c: add             x14, fp, w2, sxtw #2
    //     0x8a5f10: ldr             x14, [x14, #8]
    //     0x8a5f14: add             w2, w13, #2
    //     0x8a5f18: sbfx            x13, x2, #1, #0x1f
    //     0x8a5f1c: mov             x2, x13
    //     0x8a5f20: mov             x13, x14
    //     0x8a5f24: b               #0x8a5f2c
    //     0x8a5f28: mov             x13, NULL
    //     0x8a5f2c: stur            x13, [fp, #-0x40]
    //     0x8a5f30: lsl             x14, x2, #1
    //     0x8a5f34: lsl             w19, w14, #1
    //     0x8a5f38: add             w20, w19, #8
    //     0x8a5f3c: add             x16, x4, w20, sxtw #1
    //     0x8a5f40: ldur            w23, [x16, #0xf]
    //     0x8a5f44: add             x23, x23, HEAP, lsl #32
    //     0x8a5f48: ldr             x16, [PP, #0x4b60]  ; [pp+0x4b60] "fontSize"
    //     0x8a5f4c: cmp             w23, w16
    //     0x8a5f50: b.ne            #0x8a5f84
    //     0x8a5f54: add             w2, w19, #0xa
    //     0x8a5f58: add             x16, x4, w2, sxtw #1
    //     0x8a5f5c: ldur            w19, [x16, #0xf]
    //     0x8a5f60: add             x19, x19, HEAP, lsl #32
    //     0x8a5f64: sub             w2, w1, w19
    //     0x8a5f68: add             x19, fp, w2, sxtw #2
    //     0x8a5f6c: ldr             x19, [x19, #8]
    //     0x8a5f70: add             w2, w14, #2
    //     0x8a5f74: sbfx            x14, x2, #1, #0x1f
    //     0x8a5f78: mov             x2, x14
    //     0x8a5f7c: mov             x14, x19
    //     0x8a5f80: b               #0x8a5f88
    //     0x8a5f84: mov             x14, NULL
    //     0x8a5f88: lsl             x19, x2, #1
    //     0x8a5f8c: lsl             w20, w19, #1
    //     0x8a5f90: add             w23, w20, #8
    //     0x8a5f94: add             x16, x4, w23, sxtw #1
    //     0x8a5f98: ldur            w24, [x16, #0xf]
    //     0x8a5f9c: add             x24, x24, HEAP, lsl #32
    //     0x8a5fa0: ldr             x16, [PP, #0x4aa8]  ; [pp+0x4aa8] "fontStyle"
    //     0x8a5fa4: cmp             w24, w16
    //     0x8a5fa8: b.ne            #0x8a5fdc
    //     0x8a5fac: add             w2, w20, #0xa
    //     0x8a5fb0: add             x16, x4, w2, sxtw #1
    //     0x8a5fb4: ldur            w20, [x16, #0xf]
    //     0x8a5fb8: add             x20, x20, HEAP, lsl #32
    //     0x8a5fbc: sub             w2, w1, w20
    //     0x8a5fc0: add             x20, fp, w2, sxtw #2
    //     0x8a5fc4: ldr             x20, [x20, #8]
    //     0x8a5fc8: add             w2, w19, #2
    //     0x8a5fcc: sbfx            x19, x2, #1, #0x1f
    //     0x8a5fd0: mov             x2, x19
    //     0x8a5fd4: mov             x19, x20
    //     0x8a5fd8: b               #0x8a5fe0
    //     0x8a5fdc: mov             x19, NULL
    //     0x8a5fe0: lsl             x20, x2, #1
    //     0x8a5fe4: lsl             w23, w20, #1
    //     0x8a5fe8: add             w24, w23, #8
    //     0x8a5fec: add             x16, x4, w24, sxtw #1
    //     0x8a5ff0: ldur            w25, [x16, #0xf]
    //     0x8a5ff4: add             x25, x25, HEAP, lsl #32
    //     0x8a5ff8: ldr             x16, [PP, #0x4ab0]  ; [pp+0x4ab0] "fontVariations"
    //     0x8a5ffc: cmp             w25, w16
    //     0x8a6000: b.ne            #0x8a6034
    //     0x8a6004: add             w2, w23, #0xa
    //     0x8a6008: add             x16, x4, w2, sxtw #1
    //     0x8a600c: ldur            w23, [x16, #0xf]
    //     0x8a6010: add             x23, x23, HEAP, lsl #32
    //     0x8a6014: sub             w2, w1, w23
    //     0x8a6018: add             x23, fp, w2, sxtw #2
    //     0x8a601c: ldr             x23, [x23, #8]
    //     0x8a6020: add             w2, w20, #2
    //     0x8a6024: sbfx            x20, x2, #1, #0x1f
    //     0x8a6028: mov             x2, x20
    //     0x8a602c: mov             x20, x23
    //     0x8a6030: b               #0x8a6038
    //     0x8a6034: mov             x20, NULL
    //     0x8a6038: stur            x20, [fp, #-0x38]
    //     0x8a603c: lsl             x23, x2, #1
    //     0x8a6040: lsl             w24, w23, #1
    //     0x8a6044: add             w25, w24, #8
    //     0x8a6048: add             x16, x4, w25, sxtw #1
    //     0x8a604c: ldur            w12, [x16, #0xf]
    //     0x8a6050: add             x12, x12, HEAP, lsl #32
    //     0x8a6054: ldr             x16, [PP, #0x4ab8]  ; [pp+0x4ab8] "fontWeight"
    //     0x8a6058: cmp             w12, w16
    //     0x8a605c: b.ne            #0x8a608c
    //     0x8a6060: add             w2, w24, #0xa
    //     0x8a6064: add             x16, x4, w2, sxtw #1
    //     0x8a6068: ldur            w12, [x16, #0xf]
    //     0x8a606c: add             x12, x12, HEAP, lsl #32
    //     0x8a6070: sub             w2, w1, w12
    //     0x8a6074: add             x12, fp, w2, sxtw #2
    //     0x8a6078: ldr             x12, [x12, #8]
    //     0x8a607c: add             w2, w23, #2
    //     0x8a6080: sbfx            x23, x2, #1, #0x1f
    //     0x8a6084: mov             x2, x23
    //     0x8a6088: b               #0x8a6090
    //     0x8a608c: mov             x12, NULL
    //     0x8a6090: lsl             x23, x2, #1
    //     0x8a6094: lsl             w24, w23, #1
    //     0x8a6098: add             w25, w24, #8
    //     0x8a609c: add             x16, x4, w25, sxtw #1
    //     0x8a60a0: ldur            w11, [x16, #0xf]
    //     0x8a60a4: add             x11, x11, HEAP, lsl #32
    //     0x8a60a8: ldr             x16, [PP, #0x4ac0]  ; [pp+0x4ac0] "foreground"
    //     0x8a60ac: cmp             w11, w16
    //     0x8a60b0: b.ne            #0x8a60e0
    //     0x8a60b4: add             w2, w24, #0xa
    //     0x8a60b8: add             x16, x4, w2, sxtw #1
    //     0x8a60bc: ldur            w11, [x16, #0xf]
    //     0x8a60c0: add             x11, x11, HEAP, lsl #32
    //     0x8a60c4: sub             w2, w1, w11
    //     0x8a60c8: add             x11, fp, w2, sxtw #2
    //     0x8a60cc: ldr             x11, [x11, #8]
    //     0x8a60d0: add             w2, w23, #2
    //     0x8a60d4: sbfx            x23, x2, #1, #0x1f
    //     0x8a60d8: mov             x2, x23
    //     0x8a60dc: b               #0x8a60e4
    //     0x8a60e0: mov             x11, NULL
    //     0x8a60e4: lsl             x23, x2, #1
    //     0x8a60e8: lsl             w24, w23, #1
    //     0x8a60ec: add             w25, w24, #8
    //     0x8a60f0: add             x16, x4, w25, sxtw #1
    //     0x8a60f4: ldur            w10, [x16, #0xf]
    //     0x8a60f8: add             x10, x10, HEAP, lsl #32
    //     0x8a60fc: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    //     0x8a6100: cmp             w10, w16
    //     0x8a6104: b.ne            #0x8a6134
    //     0x8a6108: add             w2, w24, #0xa
    //     0x8a610c: add             x16, x4, w2, sxtw #1
    //     0x8a6110: ldur            w10, [x16, #0xf]
    //     0x8a6114: add             x10, x10, HEAP, lsl #32
    //     0x8a6118: sub             w2, w1, w10
    //     0x8a611c: add             x10, fp, w2, sxtw #2
    //     0x8a6120: ldr             x10, [x10, #8]
    //     0x8a6124: add             w2, w23, #2
    //     0x8a6128: sbfx            x23, x2, #1, #0x1f
    //     0x8a612c: mov             x2, x23
    //     0x8a6130: b               #0x8a6138
    //     0x8a6134: mov             x10, NULL
    //     0x8a6138: lsl             x23, x2, #1
    //     0x8a613c: lsl             w24, w23, #1
    //     0x8a6140: add             w25, w24, #8
    //     0x8a6144: add             x16, x4, w25, sxtw #1
    //     0x8a6148: ldur            w9, [x16, #0xf]
    //     0x8a614c: add             x9, x9, HEAP, lsl #32
    //     0x8a6150: add             x16, PP, #0x12, lsl #12  ; [pp+0x12960] "inherit"
    //     0x8a6154: ldr             x16, [x16, #0x960]
    //     0x8a6158: cmp             w9, w16
    //     0x8a615c: b.ne            #0x8a618c
    //     0x8a6160: add             w2, w24, #0xa
    //     0x8a6164: add             x16, x4, w2, sxtw #1
    //     0x8a6168: ldur            w9, [x16, #0xf]
    //     0x8a616c: add             x9, x9, HEAP, lsl #32
    //     0x8a6170: sub             w2, w1, w9
    //     0x8a6174: add             x9, fp, w2, sxtw #2
    //     0x8a6178: ldr             x9, [x9, #8]
    //     0x8a617c: add             w2, w23, #2
    //     0x8a6180: sbfx            x23, x2, #1, #0x1f
    //     0x8a6184: mov             x2, x23
    //     0x8a6188: b               #0x8a6190
    //     0x8a618c: mov             x9, NULL
    //     0x8a6190: lsl             x23, x2, #1
    //     0x8a6194: lsl             w24, w23, #1
    //     0x8a6198: add             w25, w24, #8
    //     0x8a619c: add             x16, x4, w25, sxtw #1
    //     0x8a61a0: ldur            w8, [x16, #0xf]
    //     0x8a61a4: add             x8, x8, HEAP, lsl #32
    //     0x8a61a8: ldr             x16, [PP, #0x4ad0]  ; [pp+0x4ad0] "leadingDistribution"
    //     0x8a61ac: cmp             w8, w16
    //     0x8a61b0: b.ne            #0x8a61e0
    //     0x8a61b4: add             w2, w24, #0xa
    //     0x8a61b8: add             x16, x4, w2, sxtw #1
    //     0x8a61bc: ldur            w8, [x16, #0xf]
    //     0x8a61c0: add             x8, x8, HEAP, lsl #32
    //     0x8a61c4: sub             w2, w1, w8
    //     0x8a61c8: add             x8, fp, w2, sxtw #2
    //     0x8a61cc: ldr             x8, [x8, #8]
    //     0x8a61d0: add             w2, w23, #2
    //     0x8a61d4: sbfx            x23, x2, #1, #0x1f
    //     0x8a61d8: mov             x2, x23
    //     0x8a61dc: b               #0x8a61e4
    //     0x8a61e0: mov             x8, NULL
    //     0x8a61e4: lsl             x23, x2, #1
    //     0x8a61e8: lsl             w24, w23, #1
    //     0x8a61ec: add             w25, w24, #8
    //     0x8a61f0: add             x16, x4, w25, sxtw #1
    //     0x8a61f4: ldur            w7, [x16, #0xf]
    //     0x8a61f8: add             x7, x7, HEAP, lsl #32
    //     0x8a61fc: ldr             x16, [PP, #0x4ad8]  ; [pp+0x4ad8] "letterSpacing"
    //     0x8a6200: cmp             w7, w16
    //     0x8a6204: b.ne            #0x8a6234
    //     0x8a6208: add             w2, w24, #0xa
    //     0x8a620c: add             x16, x4, w2, sxtw #1
    //     0x8a6210: ldur            w7, [x16, #0xf]
    //     0x8a6214: add             x7, x7, HEAP, lsl #32
    //     0x8a6218: sub             w2, w1, w7
    //     0x8a621c: add             x7, fp, w2, sxtw #2
    //     0x8a6220: ldr             x7, [x7, #8]
    //     0x8a6224: add             w2, w23, #2
    //     0x8a6228: sbfx            x23, x2, #1, #0x1f
    //     0x8a622c: mov             x2, x23
    //     0x8a6230: b               #0x8a6238
    //     0x8a6234: mov             x7, NULL
    //     0x8a6238: lsl             x23, x2, #1
    //     0x8a623c: lsl             w24, w23, #1
    //     0x8a6240: add             w25, w24, #8
    //     0x8a6244: add             x16, x4, w25, sxtw #1
    //     0x8a6248: ldur            w20, [x16, #0xf]
    //     0x8a624c: add             x20, x20, HEAP, lsl #32
    //     0x8a6250: ldr             x16, [PP, #0x4ae0]  ; [pp+0x4ae0] "locale"
    //     0x8a6254: cmp             w20, w16
    //     0x8a6258: b.ne            #0x8a6288
    //     0x8a625c: add             w2, w24, #0xa
    //     0x8a6260: add             x16, x4, w2, sxtw #1
    //     0x8a6264: ldur            w20, [x16, #0xf]
    //     0x8a6268: add             x20, x20, HEAP, lsl #32
    //     0x8a626c: sub             w2, w1, w20
    //     0x8a6270: add             x20, fp, w2, sxtw #2
    //     0x8a6274: ldr             x20, [x20, #8]
    //     0x8a6278: add             w2, w23, #2
    //     0x8a627c: sbfx            x23, x2, #1, #0x1f
    //     0x8a6280: mov             x2, x23
    //     0x8a6284: b               #0x8a628c
    //     0x8a6288: mov             x20, NULL
    //     0x8a628c: lsl             x23, x2, #1
    //     0x8a6290: lsl             w24, w23, #1
    //     0x8a6294: add             w25, w24, #8
    //     0x8a6298: add             x16, x4, w25, sxtw #1
    //     0x8a629c: ldur            w13, [x16, #0xf]
    //     0x8a62a0: add             x13, x13, HEAP, lsl #32
    //     0x8a62a4: ldr             x16, [PP, #0x6c28]  ; [pp+0x6c28] "overflow"
    //     0x8a62a8: cmp             w13, w16
    //     0x8a62ac: b.ne            #0x8a62dc
    //     0x8a62b0: add             w2, w24, #0xa
    //     0x8a62b4: add             x16, x4, w2, sxtw #1
    //     0x8a62b8: ldur            w13, [x16, #0xf]
    //     0x8a62bc: add             x13, x13, HEAP, lsl #32
    //     0x8a62c0: sub             w2, w1, w13
    //     0x8a62c4: add             x13, fp, w2, sxtw #2
    //     0x8a62c8: ldr             x13, [x13, #8]
    //     0x8a62cc: add             w2, w23, #2
    //     0x8a62d0: sbfx            x23, x2, #1, #0x1f
    //     0x8a62d4: mov             x2, x23
    //     0x8a62d8: b               #0x8a62e0
    //     0x8a62dc: mov             x13, NULL
    //     0x8a62e0: stur            x13, [fp, #-0x48]
    //     0x8a62e4: lsl             x23, x2, #1
    //     0x8a62e8: lsl             w24, w23, #1
    //     0x8a62ec: add             w25, w24, #8
    //     0x8a62f0: add             x16, x4, w25, sxtw #1
    //     0x8a62f4: ldur            w13, [x16, #0xf]
    //     0x8a62f8: add             x13, x13, HEAP, lsl #32
    //     0x8a62fc: ldr             x16, [PP, #0xfd8]  ; [pp+0xfd8] "package"
    //     0x8a6300: cmp             w13, w16
    //     0x8a6304: b.ne            #0x8a6334
    //     0x8a6308: add             w2, w24, #0xa
    //     0x8a630c: add             x16, x4, w2, sxtw #1
    //     0x8a6310: ldur            w13, [x16, #0xf]
    //     0x8a6314: add             x13, x13, HEAP, lsl #32
    //     0x8a6318: sub             w2, w1, w13
    //     0x8a631c: add             x13, fp, w2, sxtw #2
    //     0x8a6320: ldr             x13, [x13, #8]
    //     0x8a6324: add             w2, w23, #2
    //     0x8a6328: sbfx            x23, x2, #1, #0x1f
    //     0x8a632c: mov             x2, x23
    //     0x8a6330: b               #0x8a6338
    //     0x8a6334: mov             x13, NULL
    //     0x8a6338: stur            x13, [fp, #-0x50]
    //     0x8a633c: lsl             x23, x2, #1
    //     0x8a6340: lsl             w24, w23, #1
    //     0x8a6344: add             w25, w24, #8
    //     0x8a6348: add             x16, x4, w25, sxtw #1
    //     0x8a634c: ldur            w13, [x16, #0xf]
    //     0x8a6350: add             x13, x13, HEAP, lsl #32
    //     0x8a6354: ldr             x16, [PP, #0x4ae8]  ; [pp+0x4ae8] "shadows"
    //     0x8a6358: cmp             w13, w16
    //     0x8a635c: b.ne            #0x8a638c
    //     0x8a6360: add             w2, w24, #0xa
    //     0x8a6364: add             x16, x4, w2, sxtw #1
    //     0x8a6368: ldur            w13, [x16, #0xf]
    //     0x8a636c: add             x13, x13, HEAP, lsl #32
    //     0x8a6370: sub             w2, w1, w13
    //     0x8a6374: add             x13, fp, w2, sxtw #2
    //     0x8a6378: ldr             x13, [x13, #8]
    //     0x8a637c: add             w2, w23, #2
    //     0x8a6380: sbfx            x23, x2, #1, #0x1f
    //     0x8a6384: mov             x2, x23
    //     0x8a6388: b               #0x8a6390
    //     0x8a638c: mov             x13, NULL
    //     0x8a6390: stur            x13, [fp, #-0x58]
    //     0x8a6394: lsl             x23, x2, #1
    //     0x8a6398: lsl             w24, w23, #1
    //     0x8a639c: add             w25, w24, #8
    //     0x8a63a0: add             x16, x4, w25, sxtw #1
    //     0x8a63a4: ldur            w13, [x16, #0xf]
    //     0x8a63a8: add             x13, x13, HEAP, lsl #32
    //     0x8a63ac: ldr             x16, [PP, #0x4af0]  ; [pp+0x4af0] "textBaseline"
    //     0x8a63b0: cmp             w13, w16
    //     0x8a63b4: b.ne            #0x8a63e4
    //     0x8a63b8: add             w2, w24, #0xa
    //     0x8a63bc: add             x16, x4, w2, sxtw #1
    //     0x8a63c0: ldur            w13, [x16, #0xf]
    //     0x8a63c4: add             x13, x13, HEAP, lsl #32
    //     0x8a63c8: sub             w2, w1, w13
    //     0x8a63cc: add             x13, fp, w2, sxtw #2
    //     0x8a63d0: ldr             x13, [x13, #8]
    //     0x8a63d4: add             w2, w23, #2
    //     0x8a63d8: sbfx            x23, x2, #1, #0x1f
    //     0x8a63dc: mov             x2, x23
    //     0x8a63e0: b               #0x8a63e8
    //     0x8a63e4: mov             x13, NULL
    //     0x8a63e8: lsl             x23, x2, #1
    //     0x8a63ec: lsl             w2, w23, #1
    //     0x8a63f0: add             w23, w2, #8
    //     0x8a63f4: add             x16, x4, w23, sxtw #1
    //     0x8a63f8: ldur            w24, [x16, #0xf]
    //     0x8a63fc: add             x24, x24, HEAP, lsl #32
    //     0x8a6400: ldr             x16, [PP, #0x4af8]  ; [pp+0x4af8] "wordSpacing"
    //     0x8a6404: cmp             w24, w16
    //     0x8a6408: b.ne            #0x8a642c
    //     0x8a640c: add             w23, w2, #0xa
    //     0x8a6410: add             x16, x4, w23, sxtw #1
    //     0x8a6414: ldur            w2, [x16, #0xf]
    //     0x8a6418: add             x2, x2, HEAP, lsl #32
    //     0x8a641c: sub             w4, w1, w2
    //     0x8a6420: add             x1, fp, w4, sxtw #2
    //     0x8a6424: ldr             x1, [x1, #8]
    //     0x8a6428: b               #0x8a6430
    //     0x8a642c: mov             x1, NULL
    // 0x8a6430: CheckStackOverflow
    //     0x8a6430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6434: cmp             SP, x16
    //     0x8a6438: b.ls            #0x8a68ec
    // 0x8a643c: cmp             w9, NULL
    // 0x8a6440: b.ne            #0x8a6450
    // 0x8a6444: LoadField: r2 = r0->field_7
    //     0x8a6444: ldur            w2, [x0, #7]
    // 0x8a6448: DecompressPointer r2
    //     0x8a6448: add             x2, x2, HEAP, lsl #32
    // 0x8a644c: b               #0x8a6454
    // 0x8a6450: mov             x2, x9
    // 0x8a6454: stur            x2, [fp, #-0xc8]
    // 0x8a6458: LoadField: r4 = r0->field_43
    //     0x8a6458: ldur            w4, [x0, #0x43]
    // 0x8a645c: DecompressPointer r4
    //     0x8a645c: add             x4, x4, HEAP, lsl #32
    // 0x8a6460: cmp             w4, NULL
    // 0x8a6464: b.ne            #0x8a6484
    // 0x8a6468: cmp             w11, NULL
    // 0x8a646c: b.ne            #0x8a6484
    // 0x8a6470: cmp             w6, NULL
    // 0x8a6474: b.ne            #0x8a6488
    // 0x8a6478: LoadField: r6 = r0->field_b
    //     0x8a6478: ldur            w6, [x0, #0xb]
    // 0x8a647c: DecompressPointer r6
    //     0x8a647c: add             x6, x6, HEAP, lsl #32
    // 0x8a6480: b               #0x8a6488
    // 0x8a6484: r6 = Null
    //     0x8a6484: mov             x6, NULL
    // 0x8a6488: stur            x6, [fp, #-0xc0]
    // 0x8a648c: LoadField: r9 = r0->field_47
    //     0x8a648c: ldur            w9, [x0, #0x47]
    // 0x8a6490: DecompressPointer r9
    //     0x8a6490: add             x9, x9, HEAP, lsl #32
    // 0x8a6494: cmp             w9, NULL
    // 0x8a6498: b.ne            #0x8a64b8
    // 0x8a649c: cmp             w3, NULL
    // 0x8a64a0: b.ne            #0x8a64b8
    // 0x8a64a4: cmp             w5, NULL
    // 0x8a64a8: b.ne            #0x8a64bc
    // 0x8a64ac: LoadField: r5 = r0->field_f
    //     0x8a64ac: ldur            w5, [x0, #0xf]
    // 0x8a64b0: DecompressPointer r5
    //     0x8a64b0: add             x5, x5, HEAP, lsl #32
    // 0x8a64b4: b               #0x8a64bc
    // 0x8a64b8: r5 = Null
    //     0x8a64b8: mov             x5, NULL
    // 0x8a64bc: stur            x5, [fp, #-0xb8]
    // 0x8a64c0: cmp             w14, NULL
    // 0x8a64c4: b.ne            #0x8a64d0
    // 0x8a64c8: LoadField: r14 = r0->field_1f
    //     0x8a64c8: ldur            w14, [x0, #0x1f]
    // 0x8a64cc: DecompressPointer r14
    //     0x8a64cc: add             x14, x14, HEAP, lsl #32
    // 0x8a64d0: stur            x14, [fp, #-0xb0]
    // 0x8a64d4: cmp             w12, NULL
    // 0x8a64d8: b.ne            #0x8a64e4
    // 0x8a64dc: LoadField: r12 = r0->field_23
    //     0x8a64dc: ldur            w12, [x0, #0x23]
    // 0x8a64e0: DecompressPointer r12
    //     0x8a64e0: add             x12, x12, HEAP, lsl #32
    // 0x8a64e4: stur            x12, [fp, #-0xa8]
    // 0x8a64e8: cmp             w19, NULL
    // 0x8a64ec: b.ne            #0x8a64f8
    // 0x8a64f0: LoadField: r19 = r0->field_27
    //     0x8a64f0: ldur            w19, [x0, #0x27]
    // 0x8a64f4: DecompressPointer r19
    //     0x8a64f4: add             x19, x19, HEAP, lsl #32
    // 0x8a64f8: stur            x19, [fp, #-0xa0]
    // 0x8a64fc: cmp             w7, NULL
    // 0x8a6500: b.ne            #0x8a650c
    // 0x8a6504: LoadField: r7 = r0->field_2b
    //     0x8a6504: ldur            w7, [x0, #0x2b]
    // 0x8a6508: DecompressPointer r7
    //     0x8a6508: add             x7, x7, HEAP, lsl #32
    // 0x8a650c: stur            x7, [fp, #-0x98]
    // 0x8a6510: cmp             w1, NULL
    // 0x8a6514: b.ne            #0x8a6528
    // 0x8a6518: LoadField: r1 = r0->field_2f
    //     0x8a6518: ldur            w1, [x0, #0x2f]
    // 0x8a651c: DecompressPointer r1
    //     0x8a651c: add             x1, x1, HEAP, lsl #32
    // 0x8a6520: mov             x23, x1
    // 0x8a6524: b               #0x8a652c
    // 0x8a6528: mov             x23, x1
    // 0x8a652c: stur            x23, [fp, #-0x90]
    // 0x8a6530: cmp             w13, NULL
    // 0x8a6534: b.ne            #0x8a6544
    // 0x8a6538: LoadField: r1 = r0->field_33
    //     0x8a6538: ldur            w1, [x0, #0x33]
    // 0x8a653c: DecompressPointer r1
    //     0x8a653c: add             x1, x1, HEAP, lsl #32
    // 0x8a6540: mov             x13, x1
    // 0x8a6544: stur            x13, [fp, #-0x88]
    // 0x8a6548: cmp             w10, NULL
    // 0x8a654c: b.ne            #0x8a655c
    // 0x8a6550: LoadField: r1 = r0->field_37
    //     0x8a6550: ldur            w1, [x0, #0x37]
    // 0x8a6554: DecompressPointer r1
    //     0x8a6554: add             x1, x1, HEAP, lsl #32
    // 0x8a6558: mov             x10, x1
    // 0x8a655c: stur            x10, [fp, #-0x80]
    // 0x8a6560: cmp             w8, NULL
    // 0x8a6564: b.ne            #0x8a6574
    // 0x8a6568: LoadField: r1 = r0->field_3b
    //     0x8a6568: ldur            w1, [x0, #0x3b]
    // 0x8a656c: DecompressPointer r1
    //     0x8a656c: add             x1, x1, HEAP, lsl #32
    // 0x8a6570: mov             x8, x1
    // 0x8a6574: stur            x8, [fp, #-0x78]
    // 0x8a6578: cmp             w20, NULL
    // 0x8a657c: b.ne            #0x8a658c
    // 0x8a6580: LoadField: r1 = r0->field_3f
    //     0x8a6580: ldur            w1, [x0, #0x3f]
    // 0x8a6584: DecompressPointer r1
    //     0x8a6584: add             x1, x1, HEAP, lsl #32
    // 0x8a6588: mov             x20, x1
    // 0x8a658c: stur            x20, [fp, #-0x70]
    // 0x8a6590: cmp             w11, NULL
    // 0x8a6594: b.eq            #0x8a659c
    // 0x8a6598: mov             x4, x11
    // 0x8a659c: stur            x4, [fp, #-0x68]
    // 0x8a65a0: cmp             w3, NULL
    // 0x8a65a4: b.ne            #0x8a65ac
    // 0x8a65a8: mov             x3, x9
    // 0x8a65ac: ldur            x1, [fp, #-0x58]
    // 0x8a65b0: stur            x3, [fp, #-0x60]
    // 0x8a65b4: cmp             w1, NULL
    // 0x8a65b8: b.ne            #0x8a65cc
    // 0x8a65bc: LoadField: r1 = r0->field_5f
    //     0x8a65bc: ldur            w1, [x0, #0x5f]
    // 0x8a65c0: DecompressPointer r1
    //     0x8a65c0: add             x1, x1, HEAP, lsl #32
    // 0x8a65c4: mov             x9, x1
    // 0x8a65c8: b               #0x8a65d0
    // 0x8a65cc: mov             x9, x1
    // 0x8a65d0: ldur            x1, [fp, #-0x40]
    // 0x8a65d4: stur            x9, [fp, #-0x58]
    // 0x8a65d8: cmp             w1, NULL
    // 0x8a65dc: b.ne            #0x8a65f0
    // 0x8a65e0: LoadField: r1 = r0->field_63
    //     0x8a65e0: ldur            w1, [x0, #0x63]
    // 0x8a65e4: DecompressPointer r1
    //     0x8a65e4: add             x1, x1, HEAP, lsl #32
    // 0x8a65e8: mov             x11, x1
    // 0x8a65ec: b               #0x8a65f4
    // 0x8a65f0: mov             x11, x1
    // 0x8a65f4: ldur            x1, [fp, #-0x38]
    // 0x8a65f8: stur            x11, [fp, #-0x40]
    // 0x8a65fc: cmp             w1, NULL
    // 0x8a6600: b.ne            #0x8a6614
    // 0x8a6604: LoadField: r1 = r0->field_67
    //     0x8a6604: ldur            w1, [x0, #0x67]
    // 0x8a6608: DecompressPointer r1
    //     0x8a6608: add             x1, x1, HEAP, lsl #32
    // 0x8a660c: mov             x24, x1
    // 0x8a6610: b               #0x8a6618
    // 0x8a6614: mov             x24, x1
    // 0x8a6618: ldur            x1, [fp, #-0x30]
    // 0x8a661c: stur            x24, [fp, #-0x38]
    // 0x8a6620: cmp             w1, NULL
    // 0x8a6624: b.ne            #0x8a6638
    // 0x8a6628: LoadField: r1 = r0->field_4b
    //     0x8a6628: ldur            w1, [x0, #0x4b]
    // 0x8a662c: DecompressPointer r1
    //     0x8a662c: add             x1, x1, HEAP, lsl #32
    // 0x8a6630: mov             x25, x1
    // 0x8a6634: b               #0x8a663c
    // 0x8a6638: mov             x25, x1
    // 0x8a663c: ldur            x1, [fp, #-0x28]
    // 0x8a6640: stur            x25, [fp, #-0x30]
    // 0x8a6644: cmp             w1, NULL
    // 0x8a6648: b.ne            #0x8a665c
    // 0x8a664c: LoadField: r1 = r0->field_4f
    //     0x8a664c: ldur            w1, [x0, #0x4f]
    // 0x8a6650: DecompressPointer r1
    //     0x8a6650: add             x1, x1, HEAP, lsl #32
    // 0x8a6654: stur            x1, [fp, #-0x28]
    // 0x8a6658: b               #0x8a6660
    // 0x8a665c: stur            x1, [fp, #-0x28]
    // 0x8a6660: ldur            x1, [fp, #-0x20]
    // 0x8a6664: cmp             w1, NULL
    // 0x8a6668: b.ne            #0x8a667c
    // 0x8a666c: LoadField: r1 = r0->field_53
    //     0x8a666c: ldur            w1, [x0, #0x53]
    // 0x8a6670: DecompressPointer r1
    //     0x8a6670: add             x1, x1, HEAP, lsl #32
    // 0x8a6674: stur            x1, [fp, #-0x20]
    // 0x8a6678: b               #0x8a6680
    // 0x8a667c: stur            x1, [fp, #-0x20]
    // 0x8a6680: ldur            x1, [fp, #-0x18]
    // 0x8a6684: cmp             w1, NULL
    // 0x8a6688: b.ne            #0x8a669c
    // 0x8a668c: LoadField: r1 = r0->field_57
    //     0x8a668c: ldur            w1, [x0, #0x57]
    // 0x8a6690: DecompressPointer r1
    //     0x8a6690: add             x1, x1, HEAP, lsl #32
    // 0x8a6694: stur            x1, [fp, #-0x18]
    // 0x8a6698: b               #0x8a66a0
    // 0x8a669c: stur            x1, [fp, #-0x18]
    // 0x8a66a0: ldur            x1, [fp, #-0x10]
    // 0x8a66a4: cmp             w1, NULL
    // 0x8a66a8: b.ne            #0x8a66b8
    // 0x8a66ac: mov             x1, x0
    // 0x8a66b0: r0 = _fontFamily()
    //     0x8a66b0: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0x8a66b4: mov             x1, x0
    // 0x8a66b8: ldur            x0, [fp, #-8]
    // 0x8a66bc: stur            x1, [fp, #-0xe0]
    // 0x8a66c0: cmp             w0, NULL
    // 0x8a66c4: b.ne            #0x8a66dc
    // 0x8a66c8: ldur            x2, [fp, #-0xd0]
    // 0x8a66cc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a66cc: ldur            w0, [x2, #0x17]
    // 0x8a66d0: DecompressPointer r0
    //     0x8a66d0: add             x0, x0, HEAP, lsl #32
    // 0x8a66d4: mov             x3, x0
    // 0x8a66d8: b               #0x8a66e4
    // 0x8a66dc: ldur            x2, [fp, #-0xd0]
    // 0x8a66e0: mov             x3, x0
    // 0x8a66e4: ldur            x0, [fp, #-0x50]
    // 0x8a66e8: stur            x3, [fp, #-0xd8]
    // 0x8a66ec: cmp             w0, NULL
    // 0x8a66f0: b.ne            #0x8a6704
    // 0x8a66f4: LoadField: r0 = r2->field_1b
    //     0x8a66f4: ldur            w0, [x2, #0x1b]
    // 0x8a66f8: DecompressPointer r0
    //     0x8a66f8: add             x0, x0, HEAP, lsl #32
    // 0x8a66fc: mov             x4, x0
    // 0x8a6700: b               #0x8a6708
    // 0x8a6704: mov             x4, x0
    // 0x8a6708: ldur            x0, [fp, #-0x48]
    // 0x8a670c: stur            x4, [fp, #-0x10]
    // 0x8a6710: cmp             w0, NULL
    // 0x8a6714: b.ne            #0x8a6728
    // 0x8a6718: LoadField: r0 = r2->field_6b
    //     0x8a6718: ldur            w0, [x2, #0x6b]
    // 0x8a671c: DecompressPointer r0
    //     0x8a671c: add             x0, x0, HEAP, lsl #32
    // 0x8a6720: stur            x0, [fp, #-8]
    // 0x8a6724: b               #0x8a672c
    // 0x8a6728: stur            x0, [fp, #-8]
    // 0x8a672c: ldur            x0, [fp, #-0xc8]
    // 0x8a6730: ldur            x2, [fp, #-0xc0]
    // 0x8a6734: ldur            x5, [fp, #-0xb8]
    // 0x8a6738: ldur            x6, [fp, #-0xb0]
    // 0x8a673c: ldur            x7, [fp, #-0xa8]
    // 0x8a6740: ldur            x8, [fp, #-0xa0]
    // 0x8a6744: ldur            x9, [fp, #-0x98]
    // 0x8a6748: ldur            x10, [fp, #-0x90]
    // 0x8a674c: ldur            x11, [fp, #-0x88]
    // 0x8a6750: ldur            x12, [fp, #-0x80]
    // 0x8a6754: ldur            x13, [fp, #-0x78]
    // 0x8a6758: ldur            x14, [fp, #-0x70]
    // 0x8a675c: ldur            x19, [fp, #-0x68]
    // 0x8a6760: ldur            x20, [fp, #-0x60]
    // 0x8a6764: ldur            x23, [fp, #-0x58]
    // 0x8a6768: ldur            x24, [fp, #-0x40]
    // 0x8a676c: ldur            x25, [fp, #-0x38]
    // 0x8a6770: r0 = TextStyle()
    //     0x8a6770: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a6774: mov             x3, x0
    // 0x8a6778: ldur            x0, [fp, #-0xc8]
    // 0x8a677c: stur            x3, [fp, #-0x48]
    // 0x8a6780: StoreField: r3->field_7 = r0
    //     0x8a6780: stur            w0, [x3, #7]
    // 0x8a6784: ldur            x0, [fp, #-0xc0]
    // 0x8a6788: StoreField: r3->field_b = r0
    //     0x8a6788: stur            w0, [x3, #0xb]
    // 0x8a678c: ldur            x0, [fp, #-0xb8]
    // 0x8a6790: StoreField: r3->field_f = r0
    //     0x8a6790: stur            w0, [x3, #0xf]
    // 0x8a6794: ldur            x0, [fp, #-0xb0]
    // 0x8a6798: StoreField: r3->field_1f = r0
    //     0x8a6798: stur            w0, [x3, #0x1f]
    // 0x8a679c: ldur            x0, [fp, #-0xa8]
    // 0x8a67a0: StoreField: r3->field_23 = r0
    //     0x8a67a0: stur            w0, [x3, #0x23]
    // 0x8a67a4: ldur            x0, [fp, #-0xa0]
    // 0x8a67a8: StoreField: r3->field_27 = r0
    //     0x8a67a8: stur            w0, [x3, #0x27]
    // 0x8a67ac: ldur            x0, [fp, #-0x98]
    // 0x8a67b0: StoreField: r3->field_2b = r0
    //     0x8a67b0: stur            w0, [x3, #0x2b]
    // 0x8a67b4: ldur            x0, [fp, #-0x90]
    // 0x8a67b8: StoreField: r3->field_2f = r0
    //     0x8a67b8: stur            w0, [x3, #0x2f]
    // 0x8a67bc: ldur            x0, [fp, #-0x88]
    // 0x8a67c0: StoreField: r3->field_33 = r0
    //     0x8a67c0: stur            w0, [x3, #0x33]
    // 0x8a67c4: ldur            x0, [fp, #-0x80]
    // 0x8a67c8: StoreField: r3->field_37 = r0
    //     0x8a67c8: stur            w0, [x3, #0x37]
    // 0x8a67cc: ldur            x0, [fp, #-0x78]
    // 0x8a67d0: StoreField: r3->field_3b = r0
    //     0x8a67d0: stur            w0, [x3, #0x3b]
    // 0x8a67d4: ldur            x0, [fp, #-0x70]
    // 0x8a67d8: StoreField: r3->field_3f = r0
    //     0x8a67d8: stur            w0, [x3, #0x3f]
    // 0x8a67dc: ldur            x0, [fp, #-0x68]
    // 0x8a67e0: StoreField: r3->field_43 = r0
    //     0x8a67e0: stur            w0, [x3, #0x43]
    // 0x8a67e4: ldur            x0, [fp, #-0x60]
    // 0x8a67e8: StoreField: r3->field_47 = r0
    //     0x8a67e8: stur            w0, [x3, #0x47]
    // 0x8a67ec: ldur            x0, [fp, #-0x58]
    // 0x8a67f0: StoreField: r3->field_5f = r0
    //     0x8a67f0: stur            w0, [x3, #0x5f]
    // 0x8a67f4: ldur            x0, [fp, #-0x40]
    // 0x8a67f8: StoreField: r3->field_63 = r0
    //     0x8a67f8: stur            w0, [x3, #0x63]
    // 0x8a67fc: ldur            x0, [fp, #-0x38]
    // 0x8a6800: StoreField: r3->field_67 = r0
    //     0x8a6800: stur            w0, [x3, #0x67]
    // 0x8a6804: ldur            x0, [fp, #-0x30]
    // 0x8a6808: StoreField: r3->field_4b = r0
    //     0x8a6808: stur            w0, [x3, #0x4b]
    // 0x8a680c: ldur            x0, [fp, #-0x28]
    // 0x8a6810: StoreField: r3->field_4f = r0
    //     0x8a6810: stur            w0, [x3, #0x4f]
    // 0x8a6814: ldur            x0, [fp, #-0x20]
    // 0x8a6818: StoreField: r3->field_53 = r0
    //     0x8a6818: stur            w0, [x3, #0x53]
    // 0x8a681c: ldur            x0, [fp, #-0x18]
    // 0x8a6820: StoreField: r3->field_57 = r0
    //     0x8a6820: stur            w0, [x3, #0x57]
    // 0x8a6824: ldur            x0, [fp, #-8]
    // 0x8a6828: StoreField: r3->field_6b = r0
    //     0x8a6828: stur            w0, [x3, #0x6b]
    // 0x8a682c: ldur            x0, [fp, #-0x10]
    // 0x8a6830: cmp             w0, NULL
    // 0x8a6834: b.ne            #0x8a6844
    // 0x8a6838: ldur            x0, [fp, #-0xe0]
    // 0x8a683c: mov             x1, x3
    // 0x8a6840: b               #0x8a6880
    // 0x8a6844: ldur            x4, [fp, #-0xe0]
    // 0x8a6848: r1 = Null
    //     0x8a6848: mov             x1, NULL
    // 0x8a684c: r2 = 8
    //     0x8a684c: mov             x2, #8
    // 0x8a6850: r0 = AllocateArray()
    //     0x8a6850: bl              #0x13df928  ; AllocateArrayStub
    // 0x8a6854: r16 = "packages/"
    //     0x8a6854: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0x8a6858: StoreField: r0->field_f = r16
    //     0x8a6858: stur            w16, [x0, #0xf]
    // 0x8a685c: ldur            x1, [fp, #-0x10]
    // 0x8a6860: StoreField: r0->field_13 = r1
    //     0x8a6860: stur            w1, [x0, #0x13]
    // 0x8a6864: r16 = "/"
    //     0x8a6864: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x8a6868: ArrayStore: r0[0] = r16  ; List_4
    //     0x8a6868: stur            w16, [x0, #0x17]
    // 0x8a686c: ldur            x2, [fp, #-0xe0]
    // 0x8a6870: StoreField: r0->field_1b = r2
    //     0x8a6870: stur            w2, [x0, #0x1b]
    // 0x8a6874: str             x0, [SP]
    // 0x8a6878: r0 = _interpolate()
    //     0x8a6878: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8a687c: ldur            x1, [fp, #-0x48]
    // 0x8a6880: StoreField: r1->field_13 = r0
    //     0x8a6880: stur            w0, [x1, #0x13]
    //     0x8a6884: ldurb           w16, [x1, #-1]
    //     0x8a6888: ldurb           w17, [x0, #-1]
    //     0x8a688c: and             x16, x17, x16, lsr #2
    //     0x8a6890: tst             x16, HEAP, lsr #32
    //     0x8a6894: b.eq            #0x8a689c
    //     0x8a6898: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a689c: ldur            x0, [fp, #-0xd8]
    // 0x8a68a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a68a0: stur            w0, [x1, #0x17]
    //     0x8a68a4: ldurb           w16, [x1, #-1]
    //     0x8a68a8: ldurb           w17, [x0, #-1]
    //     0x8a68ac: and             x16, x17, x16, lsr #2
    //     0x8a68b0: tst             x16, HEAP, lsr #32
    //     0x8a68b4: b.eq            #0x8a68bc
    //     0x8a68b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a68bc: ldur            x0, [fp, #-0x10]
    // 0x8a68c0: StoreField: r1->field_1b = r0
    //     0x8a68c0: stur            w0, [x1, #0x1b]
    //     0x8a68c4: ldurb           w16, [x1, #-1]
    //     0x8a68c8: ldurb           w17, [x0, #-1]
    //     0x8a68cc: and             x16, x17, x16, lsr #2
    //     0x8a68d0: tst             x16, HEAP, lsr #32
    //     0x8a68d4: b.eq            #0x8a68dc
    //     0x8a68d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a68dc: mov             x0, x1
    // 0x8a68e0: LeaveFrame
    //     0x8a68e0: mov             SP, fp
    //     0x8a68e4: ldp             fp, lr, [SP], #0x10
    // 0x8a68e8: ret
    //     0x8a68e8: ret             
    // 0x8a68ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a68ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a68f0: b               #0x8a643c
  }
  get _ _fontFamily(/* No info */) {
    // ** addr: 0x8a6900, size: 0xc8
    // 0x8a6900: EnterFrame
    //     0x8a6900: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6904: mov             fp, SP
    // 0x8a6908: AllocStack(0x18)
    //     0x8a6908: sub             SP, SP, #0x18
    // 0x8a690c: SetupParameters(TextStyle this /* r1 => r0, fp-0x10 */)
    //     0x8a690c: mov             x0, x1
    //     0x8a6910: stur            x1, [fp, #-0x10]
    // 0x8a6914: CheckStackOverflow
    //     0x8a6914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6918: cmp             SP, x16
    //     0x8a691c: b.ls            #0x8a69c0
    // 0x8a6920: LoadField: r3 = r0->field_1b
    //     0x8a6920: ldur            w3, [x0, #0x1b]
    // 0x8a6924: DecompressPointer r3
    //     0x8a6924: add             x3, x3, HEAP, lsl #32
    // 0x8a6928: stur            x3, [fp, #-8]
    // 0x8a692c: cmp             w3, NULL
    // 0x8a6930: b.eq            #0x8a69a8
    // 0x8a6934: r1 = Null
    //     0x8a6934: mov             x1, NULL
    // 0x8a6938: r2 = 6
    //     0x8a6938: mov             x2, #6
    // 0x8a693c: r0 = AllocateArray()
    //     0x8a693c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8a6940: r16 = "packages/"
    //     0x8a6940: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0x8a6944: StoreField: r0->field_f = r16
    //     0x8a6944: stur            w16, [x0, #0xf]
    // 0x8a6948: ldur            x1, [fp, #-8]
    // 0x8a694c: StoreField: r0->field_13 = r1
    //     0x8a694c: stur            w1, [x0, #0x13]
    // 0x8a6950: r16 = "/"
    //     0x8a6950: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x8a6954: ArrayStore: r0[0] = r16  ; List_4
    //     0x8a6954: stur            w16, [x0, #0x17]
    // 0x8a6958: str             x0, [SP]
    // 0x8a695c: r0 = _interpolate()
    //     0x8a695c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8a6960: mov             x1, x0
    // 0x8a6964: ldur            x0, [fp, #-0x10]
    // 0x8a6968: LoadField: r2 = r0->field_13
    //     0x8a6968: ldur            w2, [x0, #0x13]
    // 0x8a696c: DecompressPointer r2
    //     0x8a696c: add             x2, x2, HEAP, lsl #32
    // 0x8a6970: cmp             w2, NULL
    // 0x8a6974: b.ne            #0x8a6980
    // 0x8a6978: r0 = Null
    //     0x8a6978: mov             x0, NULL
    // 0x8a697c: b               #0x8a699c
    // 0x8a6980: LoadField: r0 = r1->field_7
    //     0x8a6980: ldur            w0, [x1, #7]
    // 0x8a6984: r1 = LoadInt32Instr(r0)
    //     0x8a6984: sbfx            x1, x0, #1, #0x1f
    // 0x8a6988: mov             x16, x1
    // 0x8a698c: mov             x1, x2
    // 0x8a6990: mov             x2, x16
    // 0x8a6994: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a6994: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a6998: r0 = substring()
    //     0x8a6998: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x8a699c: LeaveFrame
    //     0x8a699c: mov             SP, fp
    //     0x8a69a0: ldp             fp, lr, [SP], #0x10
    // 0x8a69a4: ret
    //     0x8a69a4: ret             
    // 0x8a69a8: LoadField: r1 = r0->field_13
    //     0x8a69a8: ldur            w1, [x0, #0x13]
    // 0x8a69ac: DecompressPointer r1
    //     0x8a69ac: add             x1, x1, HEAP, lsl #32
    // 0x8a69b0: mov             x0, x1
    // 0x8a69b4: LeaveFrame
    //     0x8a69b4: mov             SP, fp
    //     0x8a69b8: ldp             fp, lr, [SP], #0x10
    // 0x8a69bc: ret
    //     0x8a69bc: ret             
    // 0x8a69c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a69c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a69c4: b               #0x8a6920
  }
  _ merge(/* No info */) {
    // ** addr: 0x8a98e8, size: 0x214
    // 0x8a98e8: EnterFrame
    //     0x8a98e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a98ec: mov             fp, SP
    // 0x8a98f0: AllocStack(0x170)
    //     0x8a98f0: sub             SP, SP, #0x170
    // 0x8a98f4: SetupParameters(TextStyle this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0xb0 */)
    //     0x8a98f4: mov             x0, x2
    //     0x8a98f8: stur            x2, [fp, #-0xb0]
    //     0x8a98fc: mov             x2, x1
    //     0x8a9900: stur            x1, [fp, #-8]
    // 0x8a9904: CheckStackOverflow
    //     0x8a9904: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9908: cmp             SP, x16
    //     0x8a990c: b.ls            #0x8a9af4
    // 0x8a9910: cmp             w0, NULL
    // 0x8a9914: b.ne            #0x8a9928
    // 0x8a9918: mov             x0, x2
    // 0x8a991c: LeaveFrame
    //     0x8a991c: mov             SP, fp
    //     0x8a9920: ldp             fp, lr, [SP], #0x10
    // 0x8a9924: ret
    //     0x8a9924: ret             
    // 0x8a9928: LoadField: r1 = r0->field_7
    //     0x8a9928: ldur            w1, [x0, #7]
    // 0x8a992c: DecompressPointer r1
    //     0x8a992c: add             x1, x1, HEAP, lsl #32
    // 0x8a9930: tbz             w1, #4, #0x8a9940
    // 0x8a9934: LeaveFrame
    //     0x8a9934: mov             SP, fp
    //     0x8a9938: ldp             fp, lr, [SP], #0x10
    // 0x8a993c: ret
    //     0x8a993c: ret             
    // 0x8a9940: LoadField: r3 = r0->field_b
    //     0x8a9940: ldur            w3, [x0, #0xb]
    // 0x8a9944: DecompressPointer r3
    //     0x8a9944: add             x3, x3, HEAP, lsl #32
    // 0x8a9948: stur            x3, [fp, #-0x10]
    // 0x8a994c: LoadField: r4 = r0->field_f
    //     0x8a994c: ldur            w4, [x0, #0xf]
    // 0x8a9950: DecompressPointer r4
    //     0x8a9950: add             x4, x4, HEAP, lsl #32
    // 0x8a9954: stur            x4, [fp, #-0xa8]
    // 0x8a9958: LoadField: r5 = r0->field_1f
    //     0x8a9958: ldur            w5, [x0, #0x1f]
    // 0x8a995c: DecompressPointer r5
    //     0x8a995c: add             x5, x5, HEAP, lsl #32
    // 0x8a9960: stur            x5, [fp, #-0xa0]
    // 0x8a9964: LoadField: r6 = r0->field_23
    //     0x8a9964: ldur            w6, [x0, #0x23]
    // 0x8a9968: DecompressPointer r6
    //     0x8a9968: add             x6, x6, HEAP, lsl #32
    // 0x8a996c: stur            x6, [fp, #-0x98]
    // 0x8a9970: LoadField: r7 = r0->field_27
    //     0x8a9970: ldur            w7, [x0, #0x27]
    // 0x8a9974: DecompressPointer r7
    //     0x8a9974: add             x7, x7, HEAP, lsl #32
    // 0x8a9978: stur            x7, [fp, #-0x90]
    // 0x8a997c: LoadField: r8 = r0->field_2b
    //     0x8a997c: ldur            w8, [x0, #0x2b]
    // 0x8a9980: DecompressPointer r8
    //     0x8a9980: add             x8, x8, HEAP, lsl #32
    // 0x8a9984: stur            x8, [fp, #-0x88]
    // 0x8a9988: LoadField: r9 = r0->field_2f
    //     0x8a9988: ldur            w9, [x0, #0x2f]
    // 0x8a998c: DecompressPointer r9
    //     0x8a998c: add             x9, x9, HEAP, lsl #32
    // 0x8a9990: stur            x9, [fp, #-0x80]
    // 0x8a9994: LoadField: r10 = r0->field_33
    //     0x8a9994: ldur            w10, [x0, #0x33]
    // 0x8a9998: DecompressPointer r10
    //     0x8a9998: add             x10, x10, HEAP, lsl #32
    // 0x8a999c: stur            x10, [fp, #-0x78]
    // 0x8a99a0: LoadField: r11 = r0->field_37
    //     0x8a99a0: ldur            w11, [x0, #0x37]
    // 0x8a99a4: DecompressPointer r11
    //     0x8a99a4: add             x11, x11, HEAP, lsl #32
    // 0x8a99a8: stur            x11, [fp, #-0x70]
    // 0x8a99ac: LoadField: r12 = r0->field_3b
    //     0x8a99ac: ldur            w12, [x0, #0x3b]
    // 0x8a99b0: DecompressPointer r12
    //     0x8a99b0: add             x12, x12, HEAP, lsl #32
    // 0x8a99b4: stur            x12, [fp, #-0x68]
    // 0x8a99b8: LoadField: r13 = r0->field_3f
    //     0x8a99b8: ldur            w13, [x0, #0x3f]
    // 0x8a99bc: DecompressPointer r13
    //     0x8a99bc: add             x13, x13, HEAP, lsl #32
    // 0x8a99c0: stur            x13, [fp, #-0x60]
    // 0x8a99c4: LoadField: r14 = r0->field_43
    //     0x8a99c4: ldur            w14, [x0, #0x43]
    // 0x8a99c8: DecompressPointer r14
    //     0x8a99c8: add             x14, x14, HEAP, lsl #32
    // 0x8a99cc: stur            x14, [fp, #-0x58]
    // 0x8a99d0: LoadField: r19 = r0->field_47
    //     0x8a99d0: ldur            w19, [x0, #0x47]
    // 0x8a99d4: DecompressPointer r19
    //     0x8a99d4: add             x19, x19, HEAP, lsl #32
    // 0x8a99d8: stur            x19, [fp, #-0x50]
    // 0x8a99dc: LoadField: r20 = r0->field_5f
    //     0x8a99dc: ldur            w20, [x0, #0x5f]
    // 0x8a99e0: DecompressPointer r20
    //     0x8a99e0: add             x20, x20, HEAP, lsl #32
    // 0x8a99e4: stur            x20, [fp, #-0x48]
    // 0x8a99e8: LoadField: r23 = r0->field_63
    //     0x8a99e8: ldur            w23, [x0, #0x63]
    // 0x8a99ec: DecompressPointer r23
    //     0x8a99ec: add             x23, x23, HEAP, lsl #32
    // 0x8a99f0: stur            x23, [fp, #-0x40]
    // 0x8a99f4: LoadField: r24 = r0->field_67
    //     0x8a99f4: ldur            w24, [x0, #0x67]
    // 0x8a99f8: DecompressPointer r24
    //     0x8a99f8: add             x24, x24, HEAP, lsl #32
    // 0x8a99fc: stur            x24, [fp, #-0x38]
    // 0x8a9a00: LoadField: r25 = r0->field_4b
    //     0x8a9a00: ldur            w25, [x0, #0x4b]
    // 0x8a9a04: DecompressPointer r25
    //     0x8a9a04: add             x25, x25, HEAP, lsl #32
    // 0x8a9a08: stur            x25, [fp, #-0x30]
    // 0x8a9a0c: LoadField: r1 = r0->field_4f
    //     0x8a9a0c: ldur            w1, [x0, #0x4f]
    // 0x8a9a10: DecompressPointer r1
    //     0x8a9a10: add             x1, x1, HEAP, lsl #32
    // 0x8a9a14: stur            x1, [fp, #-0x18]
    // 0x8a9a18: LoadField: r2 = r0->field_53
    //     0x8a9a18: ldur            w2, [x0, #0x53]
    // 0x8a9a1c: DecompressPointer r2
    //     0x8a9a1c: add             x2, x2, HEAP, lsl #32
    // 0x8a9a20: stur            x2, [fp, #-0x20]
    // 0x8a9a24: LoadField: r3 = r0->field_57
    //     0x8a9a24: ldur            w3, [x0, #0x57]
    // 0x8a9a28: DecompressPointer r3
    //     0x8a9a28: add             x3, x3, HEAP, lsl #32
    // 0x8a9a2c: mov             x1, x0
    // 0x8a9a30: stur            x3, [fp, #-0x28]
    // 0x8a9a34: r0 = _fontFamily()
    //     0x8a9a34: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0x8a9a38: mov             x1, x0
    // 0x8a9a3c: ldur            x0, [fp, #-0xb0]
    // 0x8a9a40: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8a9a40: ldur            w2, [x0, #0x17]
    // 0x8a9a44: DecompressPointer r2
    //     0x8a9a44: add             x2, x2, HEAP, lsl #32
    // 0x8a9a48: LoadField: r3 = r0->field_1b
    //     0x8a9a48: ldur            w3, [x0, #0x1b]
    // 0x8a9a4c: DecompressPointer r3
    //     0x8a9a4c: add             x3, x3, HEAP, lsl #32
    // 0x8a9a50: LoadField: r4 = r0->field_6b
    //     0x8a9a50: ldur            w4, [x0, #0x6b]
    // 0x8a9a54: DecompressPointer r4
    //     0x8a9a54: add             x4, x4, HEAP, lsl #32
    // 0x8a9a58: ldur            x16, [fp, #-0x10]
    // 0x8a9a5c: ldur            lr, [fp, #-0xa8]
    // 0x8a9a60: stp             lr, x16, [SP, #0xb0]
    // 0x8a9a64: ldur            x16, [fp, #-0xa0]
    // 0x8a9a68: ldur            lr, [fp, #-0x98]
    // 0x8a9a6c: stp             lr, x16, [SP, #0xa0]
    // 0x8a9a70: ldur            x16, [fp, #-0x90]
    // 0x8a9a74: ldur            lr, [fp, #-0x88]
    // 0x8a9a78: stp             lr, x16, [SP, #0x90]
    // 0x8a9a7c: ldur            x16, [fp, #-0x80]
    // 0x8a9a80: ldur            lr, [fp, #-0x78]
    // 0x8a9a84: stp             lr, x16, [SP, #0x80]
    // 0x8a9a88: ldur            x16, [fp, #-0x70]
    // 0x8a9a8c: ldur            lr, [fp, #-0x68]
    // 0x8a9a90: stp             lr, x16, [SP, #0x70]
    // 0x8a9a94: ldur            x16, [fp, #-0x60]
    // 0x8a9a98: ldur            lr, [fp, #-0x58]
    // 0x8a9a9c: stp             lr, x16, [SP, #0x60]
    // 0x8a9aa0: ldur            x16, [fp, #-0x50]
    // 0x8a9aa4: ldur            lr, [fp, #-0x48]
    // 0x8a9aa8: stp             lr, x16, [SP, #0x50]
    // 0x8a9aac: ldur            x16, [fp, #-0x40]
    // 0x8a9ab0: ldur            lr, [fp, #-0x38]
    // 0x8a9ab4: stp             lr, x16, [SP, #0x40]
    // 0x8a9ab8: ldur            x16, [fp, #-0x30]
    // 0x8a9abc: ldur            lr, [fp, #-0x18]
    // 0x8a9ac0: stp             lr, x16, [SP, #0x30]
    // 0x8a9ac4: ldur            x16, [fp, #-0x20]
    // 0x8a9ac8: ldur            lr, [fp, #-0x28]
    // 0x8a9acc: stp             lr, x16, [SP, #0x20]
    // 0x8a9ad0: stp             x2, x1, [SP, #0x10]
    // 0x8a9ad4: stp             x4, x3, [SP]
    // 0x8a9ad8: ldur            x1, [fp, #-8]
    // 0x8a9adc: r4 = const [0, 0x19, 0x18, 0x1, background, 0xd, backgroundColor, 0x2, color, 0x1, decoration, 0x11, decorationColor, 0x12, decorationStyle, 0x13, decorationThickness, 0x14, fontFamily, 0x15, fontFamilyFallback, 0x16, fontFeatures, 0xf, fontSize, 0x3, fontStyle, 0x5, fontVariations, 0x10, fontWeight, 0x4, foreground, 0xc, height, 0x9, leadingDistribution, 0xa, letterSpacing, 0x6, locale, 0xb, overflow, 0x18, package, 0x17, shadows, 0xe, textBaseline, 0x8, wordSpacing, 0x7, null]
    //     0x8a9adc: add             x4, PP, #0x12, lsl #12  ; [pp+0x12950] List(53) [0, 0x19, 0x18, 0x1, "background", 0xd, "backgroundColor", 0x2, "color", 0x1, "decoration", 0x11, "decorationColor", 0x12, "decorationStyle", 0x13, "decorationThickness", 0x14, "fontFamily", 0x15, "fontFamilyFallback", 0x16, "fontFeatures", 0xf, "fontSize", 0x3, "fontStyle", 0x5, "fontVariations", 0x10, "fontWeight", 0x4, "foreground", 0xc, "height", 0x9, "leadingDistribution", 0xa, "letterSpacing", 0x6, "locale", 0xb, "overflow", 0x18, "package", 0x17, "shadows", 0xe, "textBaseline", 0x8, "wordSpacing", 0x7, Null]
    //     0x8a9ae0: ldr             x4, [x4, #0x950]
    // 0x8a9ae4: r0 = copyWith()
    //     0x8a9ae4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x8a9ae8: LeaveFrame
    //     0x8a9ae8: mov             SP, fp
    //     0x8a9aec: ldp             fp, lr, [SP], #0x10
    // 0x8a9af0: ret
    //     0x8a9af0: ret             
    // 0x8a9af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9af4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9af8: b               #0x8a9910
  }
  _ apply(/* No info */) {
    // ** addr: 0x8acf20, size: 0x670
    // 0x8acf20: EnterFrame
    //     0x8acf20: stp             fp, lr, [SP, #-0x10]!
    //     0x8acf24: mov             fp, SP
    // 0x8acf28: AllocStack(0xe0)
    //     0x8acf28: sub             SP, SP, #0xe0
    // 0x8acf2c: SetupParameters(TextStyle this /* r1 => r0, fp-0x38 */, {dynamic decorationColor = Null /* r3, fp-0x30 */})
    //     0x8acf2c: mov             x0, x1
    //     0x8acf30: stur            x1, [fp, #-0x38]
    //     0x8acf34: ldur            w1, [x4, #0x13]
    //     0x8acf38: ldur            w3, [x4, #0x1f]
    //     0x8acf3c: add             x3, x3, HEAP, lsl #32
    //     0x8acf40: ldr             x16, [PP, #0x4a80]  ; [pp+0x4a80] "decorationColor"
    //     0x8acf44: cmp             w3, w16
    //     0x8acf48: b.ne            #0x8acf68
    //     0x8acf4c: ldur            w3, [x4, #0x23]
    //     0x8acf50: add             x3, x3, HEAP, lsl #32
    //     0x8acf54: sub             w4, w1, w3
    //     0x8acf58: add             x1, fp, w4, sxtw #2
    //     0x8acf5c: ldr             x1, [x1, #8]
    //     0x8acf60: mov             x3, x1
    //     0x8acf64: b               #0x8acf6c
    //     0x8acf68: mov             x3, NULL
    //     0x8acf6c: stur            x3, [fp, #-0x30]
    // 0x8acf70: CheckStackOverflow
    //     0x8acf70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8acf74: cmp             SP, x16
    //     0x8acf78: b.ls            #0x8ad4d0
    // 0x8acf7c: LoadField: r4 = r0->field_7
    //     0x8acf7c: ldur            w4, [x0, #7]
    // 0x8acf80: DecompressPointer r4
    //     0x8acf80: add             x4, x4, HEAP, lsl #32
    // 0x8acf84: stur            x4, [fp, #-0x28]
    // 0x8acf88: LoadField: r5 = r0->field_43
    //     0x8acf88: ldur            w5, [x0, #0x43]
    // 0x8acf8c: DecompressPointer r5
    //     0x8acf8c: add             x5, x5, HEAP, lsl #32
    // 0x8acf90: stur            x5, [fp, #-0x20]
    // 0x8acf94: cmp             w5, NULL
    // 0x8acf98: b.ne            #0x8acfbc
    // 0x8acf9c: cmp             w2, NULL
    // 0x8acfa0: b.ne            #0x8acfb0
    // 0x8acfa4: LoadField: r1 = r0->field_b
    //     0x8acfa4: ldur            w1, [x0, #0xb]
    // 0x8acfa8: DecompressPointer r1
    //     0x8acfa8: add             x1, x1, HEAP, lsl #32
    // 0x8acfac: b               #0x8acfb4
    // 0x8acfb0: mov             x1, x2
    // 0x8acfb4: mov             x2, x1
    // 0x8acfb8: b               #0x8acfc0
    // 0x8acfbc: r2 = Null
    //     0x8acfbc: mov             x2, NULL
    // 0x8acfc0: stur            x2, [fp, #-0x18]
    // 0x8acfc4: LoadField: r6 = r0->field_47
    //     0x8acfc4: ldur            w6, [x0, #0x47]
    // 0x8acfc8: DecompressPointer r6
    //     0x8acfc8: add             x6, x6, HEAP, lsl #32
    // 0x8acfcc: stur            x6, [fp, #-0x10]
    // 0x8acfd0: cmp             w6, NULL
    // 0x8acfd4: b.ne            #0x8acfe8
    // 0x8acfd8: LoadField: r1 = r0->field_f
    //     0x8acfd8: ldur            w1, [x0, #0xf]
    // 0x8acfdc: DecompressPointer r1
    //     0x8acfdc: add             x1, x1, HEAP, lsl #32
    // 0x8acfe0: mov             x7, x1
    // 0x8acfe4: b               #0x8acfec
    // 0x8acfe8: r7 = Null
    //     0x8acfe8: mov             x7, NULL
    // 0x8acfec: mov             x1, x0
    // 0x8acff0: stur            x7, [fp, #-8]
    // 0x8acff4: r0 = _fontFamily()
    //     0x8acff4: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0x8acff8: mov             x5, x0
    // 0x8acffc: ldur            x4, [fp, #-0x38]
    // 0x8ad000: stur            x5, [fp, #-0x50]
    // 0x8ad004: ArrayLoad: r6 = r4[0]  ; List_4
    //     0x8ad004: ldur            w6, [x4, #0x17]
    // 0x8ad008: DecompressPointer r6
    //     0x8ad008: add             x6, x6, HEAP, lsl #32
    // 0x8ad00c: stur            x6, [fp, #-0x48]
    // 0x8ad010: LoadField: r0 = r4->field_1f
    //     0x8ad010: ldur            w0, [x4, #0x1f]
    // 0x8ad014: DecompressPointer r0
    //     0x8ad014: add             x0, x0, HEAP, lsl #32
    // 0x8ad018: cmp             w0, NULL
    // 0x8ad01c: b.ne            #0x8ad02c
    // 0x8ad020: r7 = Null
    //     0x8ad020: mov             x7, NULL
    // 0x8ad024: d0 = 0.000000
    //     0x8ad024: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad028: b               #0x8ad068
    // 0x8ad02c: d0 = 0.000000
    //     0x8ad02c: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad030: LoadField: d1 = r0->field_7
    //     0x8ad030: ldur            d1, [x0, #7]
    // 0x8ad034: fadd            d2, d1, d0
    // 0x8ad038: r0 = inline_Allocate_Double()
    //     0x8ad038: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8ad03c: add             x0, x0, #0x10
    //     0x8ad040: cmp             x1, x0
    //     0x8ad044: b.ls            #0x8ad4d8
    //     0x8ad048: str             x0, [THR, #0x60]  ; THR::top
    //     0x8ad04c: sub             x0, x0, #0xf
    //     0x8ad050: mov             x1, #0xe19c
    //     0x8ad054: movk            x1, #3, lsl #16
    //     0x8ad058: stur            x1, [x0, #-1]
    // 0x8ad05c: dmb             ishst
    // 0x8ad060: StoreField: r0->field_7 = d2
    //     0x8ad060: stur            d2, [x0, #7]
    // 0x8ad064: mov             x7, x0
    // 0x8ad068: stur            x7, [fp, #-0x40]
    // 0x8ad06c: LoadField: r0 = r4->field_23
    //     0x8ad06c: ldur            w0, [x4, #0x23]
    // 0x8ad070: DecompressPointer r0
    //     0x8ad070: add             x0, x0, HEAP, lsl #32
    // 0x8ad074: cmp             w0, NULL
    // 0x8ad078: b.ne            #0x8ad088
    // 0x8ad07c: mov             x0, x4
    // 0x8ad080: r1 = Null
    //     0x8ad080: mov             x1, NULL
    // 0x8ad084: b               #0x8ad110
    // 0x8ad088: r1 = 100
    //     0x8ad088: mov             x1, #0x64
    // 0x8ad08c: LoadField: r2 = r0->field_7
    //     0x8ad08c: ldur            x2, [x0, #7]
    // 0x8ad090: sdiv            x0, x2, x1
    // 0x8ad094: sub             x1, x0, #1
    // 0x8ad098: tbz             x1, #0x3f, #0x8ad0a4
    // 0x8ad09c: r2 = 0
    //     0x8ad09c: mov             x2, #0
    // 0x8ad0a0: b               #0x8ad0b8
    // 0x8ad0a4: cmp             x1, #8
    // 0x8ad0a8: b.le            #0x8ad0b4
    // 0x8ad0ac: r2 = 8
    //     0x8ad0ac: mov             x2, #8
    // 0x8ad0b0: b               #0x8ad0b8
    // 0x8ad0b4: mov             x2, x1
    // 0x8ad0b8: r0 = BoxInt64Instr(r2)
    //     0x8ad0b8: sbfiz           x0, x2, #1, #0x1f
    //     0x8ad0bc: cmp             x2, x0, asr #1
    //     0x8ad0c0: b.eq            #0x8ad0cc
    //     0x8ad0c4: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x8ad0c8: stur            x2, [x0, #7]
    // 0x8ad0cc: mov             x1, x0
    // 0x8ad0d0: r2 = 0
    //     0x8ad0d0: mov             x2, #0
    // 0x8ad0d4: r3 = 16
    //     0x8ad0d4: mov             x3, #0x10
    // 0x8ad0d8: r0 = clamp()
    //     0x8ad0d8: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0x8ad0dc: r2 = LoadInt32Instr(r0)
    //     0x8ad0dc: sbfx            x2, x0, #1, #0x1f
    //     0x8ad0e0: tbz             w0, #0, #0x8ad0e8
    //     0x8ad0e4: ldur            x2, [x0, #7]
    // 0x8ad0e8: mov             x1, x2
    // 0x8ad0ec: r0 = 9
    //     0x8ad0ec: mov             x0, #9
    // 0x8ad0f0: cmp             x1, x0
    // 0x8ad0f4: b.hs            #0x8ad4f8
    // 0x8ad0f8: r0 = const [Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight']
    //     0x8ad0f8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ee0] List<FontWeight>(9)
    //     0x8ad0fc: ldr             x0, [x0, #0xee0]
    // 0x8ad100: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x8ad100: add             x16, x0, x2, lsl #2
    //     0x8ad104: ldur            w1, [x16, #0xf]
    // 0x8ad108: DecompressPointer r1
    //     0x8ad108: add             x1, x1, HEAP, lsl #32
    // 0x8ad10c: ldur            x0, [fp, #-0x38]
    // 0x8ad110: stur            x1, [fp, #-0x80]
    // 0x8ad114: LoadField: r2 = r0->field_27
    //     0x8ad114: ldur            w2, [x0, #0x27]
    // 0x8ad118: DecompressPointer r2
    //     0x8ad118: add             x2, x2, HEAP, lsl #32
    // 0x8ad11c: stur            x2, [fp, #-0x78]
    // 0x8ad120: LoadField: r3 = r0->field_2b
    //     0x8ad120: ldur            w3, [x0, #0x2b]
    // 0x8ad124: DecompressPointer r3
    //     0x8ad124: add             x3, x3, HEAP, lsl #32
    // 0x8ad128: cmp             w3, NULL
    // 0x8ad12c: b.ne            #0x8ad13c
    // 0x8ad130: r3 = Null
    //     0x8ad130: mov             x3, NULL
    // 0x8ad134: d0 = 0.000000
    //     0x8ad134: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad138: b               #0x8ad174
    // 0x8ad13c: d0 = 0.000000
    //     0x8ad13c: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad140: LoadField: d1 = r3->field_7
    //     0x8ad140: ldur            d1, [x3, #7]
    // 0x8ad144: fadd            d2, d1, d0
    // 0x8ad148: r3 = inline_Allocate_Double()
    //     0x8ad148: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x8ad14c: add             x3, x3, #0x10
    //     0x8ad150: cmp             x4, x3
    //     0x8ad154: b.ls            #0x8ad4fc
    //     0x8ad158: str             x3, [THR, #0x60]  ; THR::top
    //     0x8ad15c: sub             x3, x3, #0xf
    //     0x8ad160: mov             x4, #0xe19c
    //     0x8ad164: movk            x4, #3, lsl #16
    //     0x8ad168: stur            x4, [x3, #-1]
    // 0x8ad16c: dmb             ishst
    // 0x8ad170: StoreField: r3->field_7 = d2
    //     0x8ad170: stur            d2, [x3, #7]
    // 0x8ad174: stur            x3, [fp, #-0x70]
    // 0x8ad178: LoadField: r4 = r0->field_2f
    //     0x8ad178: ldur            w4, [x0, #0x2f]
    // 0x8ad17c: DecompressPointer r4
    //     0x8ad17c: add             x4, x4, HEAP, lsl #32
    // 0x8ad180: cmp             w4, NULL
    // 0x8ad184: b.ne            #0x8ad190
    // 0x8ad188: r4 = Null
    //     0x8ad188: mov             x4, NULL
    // 0x8ad18c: b               #0x8ad1c4
    // 0x8ad190: LoadField: d1 = r4->field_7
    //     0x8ad190: ldur            d1, [x4, #7]
    // 0x8ad194: fadd            d2, d1, d0
    // 0x8ad198: r4 = inline_Allocate_Double()
    //     0x8ad198: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x8ad19c: add             x4, x4, #0x10
    //     0x8ad1a0: cmp             x5, x4
    //     0x8ad1a4: b.ls            #0x8ad520
    //     0x8ad1a8: str             x4, [THR, #0x60]  ; THR::top
    //     0x8ad1ac: sub             x4, x4, #0xf
    //     0x8ad1b0: mov             x5, #0xe19c
    //     0x8ad1b4: movk            x5, #3, lsl #16
    //     0x8ad1b8: stur            x5, [x4, #-1]
    // 0x8ad1bc: dmb             ishst
    // 0x8ad1c0: StoreField: r4->field_7 = d2
    //     0x8ad1c0: stur            d2, [x4, #7]
    // 0x8ad1c4: stur            x4, [fp, #-0x68]
    // 0x8ad1c8: LoadField: r5 = r0->field_33
    //     0x8ad1c8: ldur            w5, [x0, #0x33]
    // 0x8ad1cc: DecompressPointer r5
    //     0x8ad1cc: add             x5, x5, HEAP, lsl #32
    // 0x8ad1d0: stur            x5, [fp, #-0x60]
    // 0x8ad1d4: LoadField: r6 = r0->field_37
    //     0x8ad1d4: ldur            w6, [x0, #0x37]
    // 0x8ad1d8: DecompressPointer r6
    //     0x8ad1d8: add             x6, x6, HEAP, lsl #32
    // 0x8ad1dc: stur            x6, [fp, #-0x58]
    // 0x8ad1e0: cmp             w6, NULL
    // 0x8ad1e4: b.eq            #0x8ad1f8
    // 0x8ad1e8: r16 = 0.000000
    //     0x8ad1e8: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x8ad1ec: stp             x16, x6, [SP]
    // 0x8ad1f0: r0 = ==()
    //     0x8ad1f0: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0x8ad1f4: tbnz            w0, #4, #0x8ad204
    // 0x8ad1f8: ldur            x2, [fp, #-0x58]
    // 0x8ad1fc: d0 = 0.000000
    //     0x8ad1fc: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad200: b               #0x8ad244
    // 0x8ad204: ldur            x0, [fp, #-0x58]
    // 0x8ad208: d0 = 0.000000
    //     0x8ad208: eor             v0.16b, v0.16b, v0.16b
    // 0x8ad20c: LoadField: d1 = r0->field_7
    //     0x8ad20c: ldur            d1, [x0, #7]
    // 0x8ad210: fadd            d2, d1, d0
    // 0x8ad214: r0 = inline_Allocate_Double()
    //     0x8ad214: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8ad218: add             x0, x0, #0x10
    //     0x8ad21c: cmp             x1, x0
    //     0x8ad220: b.ls            #0x8ad544
    //     0x8ad224: str             x0, [THR, #0x60]  ; THR::top
    //     0x8ad228: sub             x0, x0, #0xf
    //     0x8ad22c: mov             x1, #0xe19c
    //     0x8ad230: movk            x1, #3, lsl #16
    //     0x8ad234: stur            x1, [x0, #-1]
    // 0x8ad238: dmb             ishst
    // 0x8ad23c: StoreField: r0->field_7 = d2
    //     0x8ad23c: stur            d2, [x0, #7]
    // 0x8ad240: mov             x2, x0
    // 0x8ad244: ldur            x0, [fp, #-0x38]
    // 0x8ad248: ldur            x1, [fp, #-0x30]
    // 0x8ad24c: stur            x2, [fp, #-0x88]
    // 0x8ad250: LoadField: r3 = r0->field_3b
    //     0x8ad250: ldur            w3, [x0, #0x3b]
    // 0x8ad254: DecompressPointer r3
    //     0x8ad254: add             x3, x3, HEAP, lsl #32
    // 0x8ad258: stur            x3, [fp, #-0xd0]
    // 0x8ad25c: LoadField: r4 = r0->field_3f
    //     0x8ad25c: ldur            w4, [x0, #0x3f]
    // 0x8ad260: DecompressPointer r4
    //     0x8ad260: add             x4, x4, HEAP, lsl #32
    // 0x8ad264: stur            x4, [fp, #-0xc8]
    // 0x8ad268: LoadField: r5 = r0->field_5f
    //     0x8ad268: ldur            w5, [x0, #0x5f]
    // 0x8ad26c: DecompressPointer r5
    //     0x8ad26c: add             x5, x5, HEAP, lsl #32
    // 0x8ad270: stur            x5, [fp, #-0xc0]
    // 0x8ad274: LoadField: r6 = r0->field_63
    //     0x8ad274: ldur            w6, [x0, #0x63]
    // 0x8ad278: DecompressPointer r6
    //     0x8ad278: add             x6, x6, HEAP, lsl #32
    // 0x8ad27c: stur            x6, [fp, #-0xb8]
    // 0x8ad280: LoadField: r7 = r0->field_67
    //     0x8ad280: ldur            w7, [x0, #0x67]
    // 0x8ad284: DecompressPointer r7
    //     0x8ad284: add             x7, x7, HEAP, lsl #32
    // 0x8ad288: stur            x7, [fp, #-0xb0]
    // 0x8ad28c: LoadField: r8 = r0->field_4b
    //     0x8ad28c: ldur            w8, [x0, #0x4b]
    // 0x8ad290: DecompressPointer r8
    //     0x8ad290: add             x8, x8, HEAP, lsl #32
    // 0x8ad294: stur            x8, [fp, #-0xa8]
    // 0x8ad298: cmp             w1, NULL
    // 0x8ad29c: b.ne            #0x8ad2a8
    // 0x8ad2a0: LoadField: r1 = r0->field_4f
    //     0x8ad2a0: ldur            w1, [x0, #0x4f]
    // 0x8ad2a4: DecompressPointer r1
    //     0x8ad2a4: add             x1, x1, HEAP, lsl #32
    // 0x8ad2a8: stur            x1, [fp, #-0x58]
    // 0x8ad2ac: LoadField: r9 = r0->field_53
    //     0x8ad2ac: ldur            w9, [x0, #0x53]
    // 0x8ad2b0: DecompressPointer r9
    //     0x8ad2b0: add             x9, x9, HEAP, lsl #32
    // 0x8ad2b4: stur            x9, [fp, #-0xa0]
    // 0x8ad2b8: LoadField: r10 = r0->field_57
    //     0x8ad2b8: ldur            w10, [x0, #0x57]
    // 0x8ad2bc: DecompressPointer r10
    //     0x8ad2bc: add             x10, x10, HEAP, lsl #32
    // 0x8ad2c0: cmp             w10, NULL
    // 0x8ad2c4: b.ne            #0x8ad2d8
    // 0x8ad2c8: SaveReg r0
    //     0x8ad2c8: str             x0, [SP, #-8]!
    // 0x8ad2cc: stur            NULL, [fp, #-0x30]
    // 0x8ad2d0: RestoreReg r0
    //     0x8ad2d0: ldr             x0, [SP], #8
    // 0x8ad2d4: b               #0x8ad310
    // 0x8ad2d8: LoadField: d1 = r10->field_7
    //     0x8ad2d8: ldur            d1, [x10, #7]
    // 0x8ad2dc: fadd            d2, d1, d0
    // 0x8ad2e0: r10 = inline_Allocate_Double()
    //     0x8ad2e0: ldp             x10, x11, [THR, #0x60]  ; THR::top
    //     0x8ad2e4: add             x10, x10, #0x10
    //     0x8ad2e8: cmp             x11, x10
    //     0x8ad2ec: b.ls            #0x8ad554
    //     0x8ad2f0: str             x10, [THR, #0x60]  ; THR::top
    //     0x8ad2f4: sub             x10, x10, #0xf
    //     0x8ad2f8: mov             x11, #0xe19c
    //     0x8ad2fc: movk            x11, #3, lsl #16
    //     0x8ad300: stur            x11, [x10, #-1]
    // 0x8ad304: dmb             ishst
    // 0x8ad308: StoreField: r10->field_7 = d2
    //     0x8ad308: stur            d2, [x10, #7]
    // 0x8ad30c: stur            x10, [fp, #-0x30]
    // 0x8ad310: ldur            x20, [fp, #-0x28]
    // 0x8ad314: ldur            x23, [fp, #-0x20]
    // 0x8ad318: ldur            x24, [fp, #-0x18]
    // 0x8ad31c: ldur            x25, [fp, #-0x10]
    // 0x8ad320: ldur            x19, [fp, #-0x40]
    // 0x8ad324: ldur            x10, [fp, #-0x80]
    // 0x8ad328: ldur            x11, [fp, #-0x78]
    // 0x8ad32c: ldur            x12, [fp, #-0x70]
    // 0x8ad330: ldur            x13, [fp, #-0x68]
    // 0x8ad334: ldur            x14, [fp, #-0x60]
    // 0x8ad338: LoadField: r1 = r0->field_6b
    //     0x8ad338: ldur            w1, [x0, #0x6b]
    // 0x8ad33c: DecompressPointer r1
    //     0x8ad33c: add             x1, x1, HEAP, lsl #32
    // 0x8ad340: stur            x1, [fp, #-0x90]
    // 0x8ad344: LoadField: r2 = r0->field_1b
    //     0x8ad344: ldur            w2, [x0, #0x1b]
    // 0x8ad348: DecompressPointer r2
    //     0x8ad348: add             x2, x2, HEAP, lsl #32
    // 0x8ad34c: mov             x0, x2
    // 0x8ad350: stur            x2, [fp, #-0x98]
    // 0x8ad354: r0 = TextStyle()
    //     0x8ad354: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ad358: mov             x3, x0
    // 0x8ad35c: ldur            x0, [fp, #-0x28]
    // 0x8ad360: stur            x3, [fp, #-0x38]
    // 0x8ad364: StoreField: r3->field_7 = r0
    //     0x8ad364: stur            w0, [x3, #7]
    // 0x8ad368: ldur            x0, [fp, #-0x18]
    // 0x8ad36c: StoreField: r3->field_b = r0
    //     0x8ad36c: stur            w0, [x3, #0xb]
    // 0x8ad370: ldur            x0, [fp, #-8]
    // 0x8ad374: StoreField: r3->field_f = r0
    //     0x8ad374: stur            w0, [x3, #0xf]
    // 0x8ad378: ldur            x0, [fp, #-0x40]
    // 0x8ad37c: StoreField: r3->field_1f = r0
    //     0x8ad37c: stur            w0, [x3, #0x1f]
    // 0x8ad380: ldur            x0, [fp, #-0x80]
    // 0x8ad384: StoreField: r3->field_23 = r0
    //     0x8ad384: stur            w0, [x3, #0x23]
    // 0x8ad388: ldur            x0, [fp, #-0x78]
    // 0x8ad38c: StoreField: r3->field_27 = r0
    //     0x8ad38c: stur            w0, [x3, #0x27]
    // 0x8ad390: ldur            x0, [fp, #-0x70]
    // 0x8ad394: StoreField: r3->field_2b = r0
    //     0x8ad394: stur            w0, [x3, #0x2b]
    // 0x8ad398: ldur            x0, [fp, #-0x68]
    // 0x8ad39c: StoreField: r3->field_2f = r0
    //     0x8ad39c: stur            w0, [x3, #0x2f]
    // 0x8ad3a0: ldur            x0, [fp, #-0x60]
    // 0x8ad3a4: StoreField: r3->field_33 = r0
    //     0x8ad3a4: stur            w0, [x3, #0x33]
    // 0x8ad3a8: ldur            x0, [fp, #-0x88]
    // 0x8ad3ac: StoreField: r3->field_37 = r0
    //     0x8ad3ac: stur            w0, [x3, #0x37]
    // 0x8ad3b0: ldur            x0, [fp, #-0xd0]
    // 0x8ad3b4: StoreField: r3->field_3b = r0
    //     0x8ad3b4: stur            w0, [x3, #0x3b]
    // 0x8ad3b8: ldur            x0, [fp, #-0xc8]
    // 0x8ad3bc: StoreField: r3->field_3f = r0
    //     0x8ad3bc: stur            w0, [x3, #0x3f]
    // 0x8ad3c0: ldur            x0, [fp, #-0x20]
    // 0x8ad3c4: StoreField: r3->field_43 = r0
    //     0x8ad3c4: stur            w0, [x3, #0x43]
    // 0x8ad3c8: ldur            x0, [fp, #-0x10]
    // 0x8ad3cc: StoreField: r3->field_47 = r0
    //     0x8ad3cc: stur            w0, [x3, #0x47]
    // 0x8ad3d0: ldur            x0, [fp, #-0xc0]
    // 0x8ad3d4: StoreField: r3->field_5f = r0
    //     0x8ad3d4: stur            w0, [x3, #0x5f]
    // 0x8ad3d8: ldur            x0, [fp, #-0xb8]
    // 0x8ad3dc: StoreField: r3->field_63 = r0
    //     0x8ad3dc: stur            w0, [x3, #0x63]
    // 0x8ad3e0: ldur            x0, [fp, #-0xb0]
    // 0x8ad3e4: StoreField: r3->field_67 = r0
    //     0x8ad3e4: stur            w0, [x3, #0x67]
    // 0x8ad3e8: ldur            x0, [fp, #-0xa8]
    // 0x8ad3ec: StoreField: r3->field_4b = r0
    //     0x8ad3ec: stur            w0, [x3, #0x4b]
    // 0x8ad3f0: ldur            x0, [fp, #-0x58]
    // 0x8ad3f4: StoreField: r3->field_4f = r0
    //     0x8ad3f4: stur            w0, [x3, #0x4f]
    // 0x8ad3f8: ldur            x0, [fp, #-0xa0]
    // 0x8ad3fc: StoreField: r3->field_53 = r0
    //     0x8ad3fc: stur            w0, [x3, #0x53]
    // 0x8ad400: ldur            x0, [fp, #-0x30]
    // 0x8ad404: StoreField: r3->field_57 = r0
    //     0x8ad404: stur            w0, [x3, #0x57]
    // 0x8ad408: ldur            x0, [fp, #-0x90]
    // 0x8ad40c: StoreField: r3->field_6b = r0
    //     0x8ad40c: stur            w0, [x3, #0x6b]
    // 0x8ad410: ldur            x0, [fp, #-0x98]
    // 0x8ad414: cmp             w0, NULL
    // 0x8ad418: b.ne            #0x8ad428
    // 0x8ad41c: ldur            x0, [fp, #-0x50]
    // 0x8ad420: mov             x1, x3
    // 0x8ad424: b               #0x8ad464
    // 0x8ad428: ldur            x4, [fp, #-0x50]
    // 0x8ad42c: r1 = Null
    //     0x8ad42c: mov             x1, NULL
    // 0x8ad430: r2 = 8
    //     0x8ad430: mov             x2, #8
    // 0x8ad434: r0 = AllocateArray()
    //     0x8ad434: bl              #0x13df928  ; AllocateArrayStub
    // 0x8ad438: r16 = "packages/"
    //     0x8ad438: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0x8ad43c: StoreField: r0->field_f = r16
    //     0x8ad43c: stur            w16, [x0, #0xf]
    // 0x8ad440: ldur            x1, [fp, #-0x98]
    // 0x8ad444: StoreField: r0->field_13 = r1
    //     0x8ad444: stur            w1, [x0, #0x13]
    // 0x8ad448: r16 = "/"
    //     0x8ad448: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x8ad44c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ad44c: stur            w16, [x0, #0x17]
    // 0x8ad450: ldur            x2, [fp, #-0x50]
    // 0x8ad454: StoreField: r0->field_1b = r2
    //     0x8ad454: stur            w2, [x0, #0x1b]
    // 0x8ad458: str             x0, [SP]
    // 0x8ad45c: r0 = _interpolate()
    //     0x8ad45c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8ad460: ldur            x1, [fp, #-0x38]
    // 0x8ad464: StoreField: r1->field_13 = r0
    //     0x8ad464: stur            w0, [x1, #0x13]
    //     0x8ad468: ldurb           w16, [x1, #-1]
    //     0x8ad46c: ldurb           w17, [x0, #-1]
    //     0x8ad470: and             x16, x17, x16, lsr #2
    //     0x8ad474: tst             x16, HEAP, lsr #32
    //     0x8ad478: b.eq            #0x8ad480
    //     0x8ad47c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ad480: ldur            x0, [fp, #-0x48]
    // 0x8ad484: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ad484: stur            w0, [x1, #0x17]
    //     0x8ad488: ldurb           w16, [x1, #-1]
    //     0x8ad48c: ldurb           w17, [x0, #-1]
    //     0x8ad490: and             x16, x17, x16, lsr #2
    //     0x8ad494: tst             x16, HEAP, lsr #32
    //     0x8ad498: b.eq            #0x8ad4a0
    //     0x8ad49c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ad4a0: ldur            x0, [fp, #-0x98]
    // 0x8ad4a4: StoreField: r1->field_1b = r0
    //     0x8ad4a4: stur            w0, [x1, #0x1b]
    //     0x8ad4a8: ldurb           w16, [x1, #-1]
    //     0x8ad4ac: ldurb           w17, [x0, #-1]
    //     0x8ad4b0: and             x16, x17, x16, lsr #2
    //     0x8ad4b4: tst             x16, HEAP, lsr #32
    //     0x8ad4b8: b.eq            #0x8ad4c0
    //     0x8ad4bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8ad4c0: mov             x0, x1
    // 0x8ad4c4: LeaveFrame
    //     0x8ad4c4: mov             SP, fp
    //     0x8ad4c8: ldp             fp, lr, [SP], #0x10
    // 0x8ad4cc: ret
    //     0x8ad4cc: ret             
    // 0x8ad4d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ad4d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ad4d4: b               #0x8acf7c
    // 0x8ad4d8: stp             q0, q2, [SP, #-0x20]!
    // 0x8ad4dc: stp             x5, x6, [SP, #-0x10]!
    // 0x8ad4e0: SaveReg r4
    //     0x8ad4e0: str             x4, [SP, #-8]!
    // 0x8ad4e4: r0 = AllocateDouble()
    //     0x8ad4e4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8ad4e8: RestoreReg r4
    //     0x8ad4e8: ldr             x4, [SP], #8
    // 0x8ad4ec: ldp             x5, x6, [SP], #0x10
    // 0x8ad4f0: ldp             q0, q2, [SP], #0x20
    // 0x8ad4f4: b               #0x8ad060
    // 0x8ad4f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ad4f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ad4fc: stp             q0, q2, [SP, #-0x20]!
    // 0x8ad500: stp             x1, x2, [SP, #-0x10]!
    // 0x8ad504: SaveReg r0
    //     0x8ad504: str             x0, [SP, #-8]!
    // 0x8ad508: r0 = AllocateDouble()
    //     0x8ad508: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8ad50c: mov             x3, x0
    // 0x8ad510: RestoreReg r0
    //     0x8ad510: ldr             x0, [SP], #8
    // 0x8ad514: ldp             x1, x2, [SP], #0x10
    // 0x8ad518: ldp             q0, q2, [SP], #0x20
    // 0x8ad51c: b               #0x8ad170
    // 0x8ad520: stp             q0, q2, [SP, #-0x20]!
    // 0x8ad524: stp             x2, x3, [SP, #-0x10]!
    // 0x8ad528: stp             x0, x1, [SP, #-0x10]!
    // 0x8ad52c: r0 = AllocateDouble()
    //     0x8ad52c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8ad530: mov             x4, x0
    // 0x8ad534: ldp             x0, x1, [SP], #0x10
    // 0x8ad538: ldp             x2, x3, [SP], #0x10
    // 0x8ad53c: ldp             q0, q2, [SP], #0x20
    // 0x8ad540: b               #0x8ad1c0
    // 0x8ad544: stp             q0, q2, [SP, #-0x20]!
    // 0x8ad548: r0 = AllocateDouble()
    //     0x8ad548: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8ad54c: ldp             q0, q2, [SP], #0x20
    // 0x8ad550: b               #0x8ad23c
    // 0x8ad554: SaveReg d2
    //     0x8ad554: str             q2, [SP, #-0x10]!
    // 0x8ad558: stp             x8, x9, [SP, #-0x10]!
    // 0x8ad55c: stp             x6, x7, [SP, #-0x10]!
    // 0x8ad560: stp             x4, x5, [SP, #-0x10]!
    // 0x8ad564: stp             x2, x3, [SP, #-0x10]!
    // 0x8ad568: stp             x0, x1, [SP, #-0x10]!
    // 0x8ad56c: r0 = AllocateDouble()
    //     0x8ad56c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8ad570: mov             x10, x0
    // 0x8ad574: ldp             x0, x1, [SP], #0x10
    // 0x8ad578: ldp             x2, x3, [SP], #0x10
    // 0x8ad57c: ldp             x4, x5, [SP], #0x10
    // 0x8ad580: ldp             x6, x7, [SP], #0x10
    // 0x8ad584: ldp             x8, x9, [SP], #0x10
    // 0x8ad588: RestoreReg d2
    //     0x8ad588: ldr             q2, [SP], #0x10
    // 0x8ad58c: b               #0x8ad308
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xfb0d58, size: 0x135c
    // 0xfb0d58: EnterFrame
    //     0xfb0d58: stp             fp, lr, [SP, #-0x10]!
    //     0xfb0d5c: mov             fp, SP
    // 0xfb0d60: AllocStack(0x100)
    //     0xfb0d60: sub             SP, SP, #0x100
    // 0xfb0d64: SetupParameters(dynamic _ /* r1 => r5, fp-0xe8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xfb0d64: mov             x5, x1
    //     0xfb0d68: mov             x4, x2
    //     0xfb0d6c: mov             x0, x3
    //     0xfb0d70: stur            x2, [fp, #-0x10]
    //     0xfb0d74: stur            x3, [fp, #-0x18]
    //     0xfb0d78: stur            x1, [fp, #-0xe8]
    // 0xfb0d7c: CheckStackOverflow
    //     0xfb0d7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb0d80: cmp             SP, x16
    //     0xfb0d84: b.ls            #0xfb2098
    // 0xfb0d88: cmp             w5, w4
    // 0xfb0d8c: b.ne            #0xfb0da0
    // 0xfb0d90: mov             x0, x5
    // 0xfb0d94: LeaveFrame
    //     0xfb0d94: mov             SP, fp
    //     0xfb0d98: ldp             fp, lr, [SP], #0x10
    // 0xfb0d9c: ret
    //     0xfb0d9c: ret             
    // 0xfb0da0: cmp             w5, NULL
    // 0xfb0da4: b.ne            #0xfb12ac
    // 0xfb0da8: cmp             w4, NULL
    // 0xfb0dac: b.eq            #0xfb20a0
    // 0xfb0db0: LoadField: r5 = r4->field_7
    //     0xfb0db0: ldur            w5, [x4, #7]
    // 0xfb0db4: DecompressPointer r5
    //     0xfb0db4: add             x5, x5, HEAP, lsl #32
    // 0xfb0db8: stur            x5, [fp, #-8]
    // 0xfb0dbc: LoadField: r2 = r4->field_b
    //     0xfb0dbc: ldur            w2, [x4, #0xb]
    // 0xfb0dc0: DecompressPointer r2
    //     0xfb0dc0: add             x2, x2, HEAP, lsl #32
    // 0xfb0dc4: mov             x3, x0
    // 0xfb0dc8: r1 = Null
    //     0xfb0dc8: mov             x1, NULL
    // 0xfb0dcc: r0 = lerp()
    //     0xfb0dcc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb0dd0: mov             x4, x0
    // 0xfb0dd4: ldur            x0, [fp, #-0x10]
    // 0xfb0dd8: stur            x4, [fp, #-0x20]
    // 0xfb0ddc: LoadField: r2 = r0->field_f
    //     0xfb0ddc: ldur            w2, [x0, #0xf]
    // 0xfb0de0: DecompressPointer r2
    //     0xfb0de0: add             x2, x2, HEAP, lsl #32
    // 0xfb0de4: ldur            x3, [fp, #-0x18]
    // 0xfb0de8: r1 = Null
    //     0xfb0de8: mov             x1, NULL
    // 0xfb0dec: r0 = lerp()
    //     0xfb0dec: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb0df0: ldur            x3, [fp, #-0x18]
    // 0xfb0df4: stur            x0, [fp, #-0x30]
    // 0xfb0df8: LoadField: d1 = r3->field_7
    //     0xfb0df8: ldur            d1, [x3, #7]
    // 0xfb0dfc: stur            d1, [fp, #-0xf0]
    // 0xfb0e00: d2 = 0.500000
    //     0xfb0e00: fmov            d2, #0.50000000
    // 0xfb0e04: fcmp            d2, d1
    // 0xfb0e08: b.le            #0xfb0e18
    // 0xfb0e0c: ldur            x4, [fp, #-0x10]
    // 0xfb0e10: r5 = Null
    //     0xfb0e10: mov             x5, NULL
    // 0xfb0e14: b               #0xfb0e28
    // 0xfb0e18: ldur            x4, [fp, #-0x10]
    // 0xfb0e1c: LoadField: r1 = r4->field_1f
    //     0xfb0e1c: ldur            w1, [x4, #0x1f]
    // 0xfb0e20: DecompressPointer r1
    //     0xfb0e20: add             x1, x1, HEAP, lsl #32
    // 0xfb0e24: mov             x5, x1
    // 0xfb0e28: stur            x5, [fp, #-0x28]
    // 0xfb0e2c: LoadField: r2 = r4->field_23
    //     0xfb0e2c: ldur            w2, [x4, #0x23]
    // 0xfb0e30: DecompressPointer r2
    //     0xfb0e30: add             x2, x2, HEAP, lsl #32
    // 0xfb0e34: mov             v0.16b, v1.16b
    // 0xfb0e38: r1 = Null
    //     0xfb0e38: mov             x1, NULL
    // 0xfb0e3c: r0 = lerp()
    //     0xfb0e3c: bl              #0xfb2a34  ; [dart:ui] FontWeight::lerp
    // 0xfb0e40: ldur            d1, [fp, #-0xf0]
    // 0xfb0e44: d2 = 0.500000
    //     0xfb0e44: fmov            d2, #0.50000000
    // 0xfb0e48: stur            x0, [fp, #-0x90]
    // 0xfb0e4c: fcmp            d2, d1
    // 0xfb0e50: b.le            #0xfb0e60
    // 0xfb0e54: ldur            x3, [fp, #-0x10]
    // 0xfb0e58: r4 = Null
    //     0xfb0e58: mov             x4, NULL
    // 0xfb0e5c: b               #0xfb0e70
    // 0xfb0e60: ldur            x3, [fp, #-0x10]
    // 0xfb0e64: LoadField: r1 = r3->field_27
    //     0xfb0e64: ldur            w1, [x3, #0x27]
    // 0xfb0e68: DecompressPointer r1
    //     0xfb0e68: add             x1, x1, HEAP, lsl #32
    // 0xfb0e6c: mov             x4, x1
    // 0xfb0e70: stur            x4, [fp, #-0x88]
    // 0xfb0e74: fcmp            d2, d1
    // 0xfb0e78: b.le            #0xfb0e84
    // 0xfb0e7c: r5 = Null
    //     0xfb0e7c: mov             x5, NULL
    // 0xfb0e80: b               #0xfb0e90
    // 0xfb0e84: LoadField: r1 = r3->field_2b
    //     0xfb0e84: ldur            w1, [x3, #0x2b]
    // 0xfb0e88: DecompressPointer r1
    //     0xfb0e88: add             x1, x1, HEAP, lsl #32
    // 0xfb0e8c: mov             x5, x1
    // 0xfb0e90: stur            x5, [fp, #-0x80]
    // 0xfb0e94: fcmp            d2, d1
    // 0xfb0e98: b.le            #0xfb0ea4
    // 0xfb0e9c: r6 = Null
    //     0xfb0e9c: mov             x6, NULL
    // 0xfb0ea0: b               #0xfb0eb0
    // 0xfb0ea4: LoadField: r1 = r3->field_2f
    //     0xfb0ea4: ldur            w1, [x3, #0x2f]
    // 0xfb0ea8: DecompressPointer r1
    //     0xfb0ea8: add             x1, x1, HEAP, lsl #32
    // 0xfb0eac: mov             x6, x1
    // 0xfb0eb0: stur            x6, [fp, #-0x78]
    // 0xfb0eb4: fcmp            d2, d1
    // 0xfb0eb8: b.le            #0xfb0ec4
    // 0xfb0ebc: r7 = Null
    //     0xfb0ebc: mov             x7, NULL
    // 0xfb0ec0: b               #0xfb0ed0
    // 0xfb0ec4: LoadField: r1 = r3->field_33
    //     0xfb0ec4: ldur            w1, [x3, #0x33]
    // 0xfb0ec8: DecompressPointer r1
    //     0xfb0ec8: add             x1, x1, HEAP, lsl #32
    // 0xfb0ecc: mov             x7, x1
    // 0xfb0ed0: stur            x7, [fp, #-0x70]
    // 0xfb0ed4: fcmp            d2, d1
    // 0xfb0ed8: b.le            #0xfb0ee4
    // 0xfb0edc: r8 = Null
    //     0xfb0edc: mov             x8, NULL
    // 0xfb0ee0: b               #0xfb0ef0
    // 0xfb0ee4: LoadField: r1 = r3->field_37
    //     0xfb0ee4: ldur            w1, [x3, #0x37]
    // 0xfb0ee8: DecompressPointer r1
    //     0xfb0ee8: add             x1, x1, HEAP, lsl #32
    // 0xfb0eec: mov             x8, x1
    // 0xfb0ef0: stur            x8, [fp, #-0x68]
    // 0xfb0ef4: fcmp            d2, d1
    // 0xfb0ef8: b.le            #0xfb0f04
    // 0xfb0efc: r9 = Null
    //     0xfb0efc: mov             x9, NULL
    // 0xfb0f00: b               #0xfb0f10
    // 0xfb0f04: LoadField: r1 = r3->field_3b
    //     0xfb0f04: ldur            w1, [x3, #0x3b]
    // 0xfb0f08: DecompressPointer r1
    //     0xfb0f08: add             x1, x1, HEAP, lsl #32
    // 0xfb0f0c: mov             x9, x1
    // 0xfb0f10: stur            x9, [fp, #-0x60]
    // 0xfb0f14: fcmp            d2, d1
    // 0xfb0f18: b.le            #0xfb0f24
    // 0xfb0f1c: r10 = Null
    //     0xfb0f1c: mov             x10, NULL
    // 0xfb0f20: b               #0xfb0f30
    // 0xfb0f24: LoadField: r1 = r3->field_3f
    //     0xfb0f24: ldur            w1, [x3, #0x3f]
    // 0xfb0f28: DecompressPointer r1
    //     0xfb0f28: add             x1, x1, HEAP, lsl #32
    // 0xfb0f2c: mov             x10, x1
    // 0xfb0f30: stur            x10, [fp, #-0x58]
    // 0xfb0f34: fcmp            d2, d1
    // 0xfb0f38: b.le            #0xfb0f44
    // 0xfb0f3c: r11 = Null
    //     0xfb0f3c: mov             x11, NULL
    // 0xfb0f40: b               #0xfb0f50
    // 0xfb0f44: LoadField: r1 = r3->field_43
    //     0xfb0f44: ldur            w1, [x3, #0x43]
    // 0xfb0f48: DecompressPointer r1
    //     0xfb0f48: add             x1, x1, HEAP, lsl #32
    // 0xfb0f4c: mov             x11, x1
    // 0xfb0f50: stur            x11, [fp, #-0x50]
    // 0xfb0f54: fcmp            d2, d1
    // 0xfb0f58: b.le            #0xfb0f64
    // 0xfb0f5c: r12 = Null
    //     0xfb0f5c: mov             x12, NULL
    // 0xfb0f60: b               #0xfb0f70
    // 0xfb0f64: LoadField: r1 = r3->field_47
    //     0xfb0f64: ldur            w1, [x3, #0x47]
    // 0xfb0f68: DecompressPointer r1
    //     0xfb0f68: add             x1, x1, HEAP, lsl #32
    // 0xfb0f6c: mov             x12, x1
    // 0xfb0f70: stur            x12, [fp, #-0x48]
    // 0xfb0f74: fcmp            d2, d1
    // 0xfb0f78: b.le            #0xfb0f84
    // 0xfb0f7c: r13 = Null
    //     0xfb0f7c: mov             x13, NULL
    // 0xfb0f80: b               #0xfb0f90
    // 0xfb0f84: LoadField: r1 = r3->field_5f
    //     0xfb0f84: ldur            w1, [x3, #0x5f]
    // 0xfb0f88: DecompressPointer r1
    //     0xfb0f88: add             x1, x1, HEAP, lsl #32
    // 0xfb0f8c: mov             x13, x1
    // 0xfb0f90: stur            x13, [fp, #-0x40]
    // 0xfb0f94: fcmp            d2, d1
    // 0xfb0f98: b.le            #0xfb0fa4
    // 0xfb0f9c: r14 = Null
    //     0xfb0f9c: mov             x14, NULL
    // 0xfb0fa0: b               #0xfb0fb0
    // 0xfb0fa4: LoadField: r1 = r3->field_63
    //     0xfb0fa4: ldur            w1, [x3, #0x63]
    // 0xfb0fa8: DecompressPointer r1
    //     0xfb0fa8: add             x1, x1, HEAP, lsl #32
    // 0xfb0fac: mov             x14, x1
    // 0xfb0fb0: stur            x14, [fp, #-0x38]
    // 0xfb0fb4: LoadField: r2 = r3->field_67
    //     0xfb0fb4: ldur            w2, [x3, #0x67]
    // 0xfb0fb8: DecompressPointer r2
    //     0xfb0fb8: add             x2, x2, HEAP, lsl #32
    // 0xfb0fbc: mov             v0.16b, v1.16b
    // 0xfb0fc0: r1 = Null
    //     0xfb0fc0: mov             x1, NULL
    // 0xfb0fc4: r0 = lerpFontVariations()
    //     0xfb0fc4: bl              #0xfb20ec  ; [package:flutter/src/painting/text_style.dart] ::lerpFontVariations
    // 0xfb0fc8: ldur            d0, [fp, #-0xf0]
    // 0xfb0fcc: d1 = 0.500000
    //     0xfb0fcc: fmov            d1, #0.50000000
    // 0xfb0fd0: stur            x0, [fp, #-0xa0]
    // 0xfb0fd4: fcmp            d1, d0
    // 0xfb0fd8: b.le            #0xfb0fe8
    // 0xfb0fdc: ldur            x4, [fp, #-0x10]
    // 0xfb0fe0: r5 = Null
    //     0xfb0fe0: mov             x5, NULL
    // 0xfb0fe4: b               #0xfb0ff8
    // 0xfb0fe8: ldur            x4, [fp, #-0x10]
    // 0xfb0fec: LoadField: r1 = r4->field_4b
    //     0xfb0fec: ldur            w1, [x4, #0x4b]
    // 0xfb0ff0: DecompressPointer r1
    //     0xfb0ff0: add             x1, x1, HEAP, lsl #32
    // 0xfb0ff4: mov             x5, x1
    // 0xfb0ff8: stur            x5, [fp, #-0x98]
    // 0xfb0ffc: LoadField: r2 = r4->field_4f
    //     0xfb0ffc: ldur            w2, [x4, #0x4f]
    // 0xfb1000: DecompressPointer r2
    //     0xfb1000: add             x2, x2, HEAP, lsl #32
    // 0xfb1004: ldur            x3, [fp, #-0x18]
    // 0xfb1008: r1 = Null
    //     0xfb1008: mov             x1, NULL
    // 0xfb100c: r0 = lerp()
    //     0xfb100c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb1010: ldur            d0, [fp, #-0xf0]
    // 0xfb1014: d1 = 0.500000
    //     0xfb1014: fmov            d1, #0.50000000
    // 0xfb1018: stur            x0, [fp, #-0xb8]
    // 0xfb101c: fcmp            d1, d0
    // 0xfb1020: b.le            #0xfb1030
    // 0xfb1024: ldur            x2, [fp, #-0x10]
    // 0xfb1028: r3 = Null
    //     0xfb1028: mov             x3, NULL
    // 0xfb102c: b               #0xfb1040
    // 0xfb1030: ldur            x2, [fp, #-0x10]
    // 0xfb1034: LoadField: r1 = r2->field_53
    //     0xfb1034: ldur            w1, [x2, #0x53]
    // 0xfb1038: DecompressPointer r1
    //     0xfb1038: add             x1, x1, HEAP, lsl #32
    // 0xfb103c: mov             x3, x1
    // 0xfb1040: stur            x3, [fp, #-0xb0]
    // 0xfb1044: fcmp            d1, d0
    // 0xfb1048: b.le            #0xfb1054
    // 0xfb104c: r4 = Null
    //     0xfb104c: mov             x4, NULL
    // 0xfb1050: b               #0xfb1060
    // 0xfb1054: LoadField: r1 = r2->field_57
    //     0xfb1054: ldur            w1, [x2, #0x57]
    // 0xfb1058: DecompressPointer r1
    //     0xfb1058: add             x1, x1, HEAP, lsl #32
    // 0xfb105c: mov             x4, x1
    // 0xfb1060: stur            x4, [fp, #-0xa8]
    // 0xfb1064: fcmp            d1, d0
    // 0xfb1068: b.le            #0xfb1074
    // 0xfb106c: r0 = Null
    //     0xfb106c: mov             x0, NULL
    // 0xfb1070: b               #0xfb1084
    // 0xfb1074: mov             x1, x2
    // 0xfb1078: r0 = _fontFamily()
    //     0xfb1078: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0xfb107c: ldur            d0, [fp, #-0xf0]
    // 0xfb1080: d1 = 0.500000
    //     0xfb1080: fmov            d1, #0.50000000
    // 0xfb1084: stur            x0, [fp, #-0xd8]
    // 0xfb1088: fcmp            d1, d0
    // 0xfb108c: b.le            #0xfb109c
    // 0xfb1090: ldur            x4, [fp, #-0x10]
    // 0xfb1094: r1 = Null
    //     0xfb1094: mov             x1, NULL
    // 0xfb1098: b               #0xfb10a8
    // 0xfb109c: ldur            x4, [fp, #-0x10]
    // 0xfb10a0: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xfb10a0: ldur            w1, [x4, #0x17]
    // 0xfb10a4: DecompressPointer r1
    //     0xfb10a4: add             x1, x1, HEAP, lsl #32
    // 0xfb10a8: stur            x1, [fp, #-0xd0]
    // 0xfb10ac: fcmp            d1, d0
    // 0xfb10b0: b.le            #0xfb10bc
    // 0xfb10b4: r2 = Null
    //     0xfb10b4: mov             x2, NULL
    // 0xfb10b8: b               #0xfb10c4
    // 0xfb10bc: LoadField: r2 = r4->field_1b
    //     0xfb10bc: ldur            w2, [x4, #0x1b]
    // 0xfb10c0: DecompressPointer r2
    //     0xfb10c0: add             x2, x2, HEAP, lsl #32
    // 0xfb10c4: stur            x2, [fp, #-0xc8]
    // 0xfb10c8: fcmp            d1, d0
    // 0xfb10cc: b.le            #0xfb10e0
    // 0xfb10d0: SaveReg r0
    //     0xfb10d0: str             x0, [SP, #-8]!
    // 0xfb10d4: stur            NULL, [fp, #-0xc0]
    // 0xfb10d8: RestoreReg r0
    //     0xfb10d8: ldr             x0, [SP], #8
    // 0xfb10dc: b               #0xfb10ec
    // 0xfb10e0: LoadField: r3 = r4->field_6b
    //     0xfb10e0: ldur            w3, [x4, #0x6b]
    // 0xfb10e4: DecompressPointer r3
    //     0xfb10e4: add             x3, x3, HEAP, lsl #32
    // 0xfb10e8: stur            x3, [fp, #-0xc0]
    // 0xfb10ec: ldur            x8, [fp, #-0x90]
    // 0xfb10f0: ldur            x9, [fp, #-0x88]
    // 0xfb10f4: ldur            x10, [fp, #-0x80]
    // 0xfb10f8: ldur            x11, [fp, #-0x78]
    // 0xfb10fc: ldur            x12, [fp, #-0x70]
    // 0xfb1100: ldur            x13, [fp, #-0x68]
    // 0xfb1104: ldur            x14, [fp, #-0x60]
    // 0xfb1108: ldur            x19, [fp, #-0x58]
    // 0xfb110c: ldur            x20, [fp, #-0x50]
    // 0xfb1110: ldur            x23, [fp, #-0x48]
    // 0xfb1114: ldur            x24, [fp, #-0x40]
    // 0xfb1118: ldur            x25, [fp, #-0x38]
    // 0xfb111c: ldur            x6, [fp, #-0xa0]
    // 0xfb1120: ldur            x7, [fp, #-0x98]
    // 0xfb1124: ldur            x3, [fp, #-0xb8]
    // 0xfb1128: ldur            x4, [fp, #-0xb0]
    // 0xfb112c: ldur            x5, [fp, #-0xa8]
    // 0xfb1130: r0 = TextStyle()
    //     0xfb1130: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xfb1134: mov             x3, x0
    // 0xfb1138: ldur            x0, [fp, #-8]
    // 0xfb113c: stur            x3, [fp, #-0xe0]
    // 0xfb1140: StoreField: r3->field_7 = r0
    //     0xfb1140: stur            w0, [x3, #7]
    // 0xfb1144: ldur            x0, [fp, #-0x20]
    // 0xfb1148: StoreField: r3->field_b = r0
    //     0xfb1148: stur            w0, [x3, #0xb]
    // 0xfb114c: ldur            x0, [fp, #-0x30]
    // 0xfb1150: StoreField: r3->field_f = r0
    //     0xfb1150: stur            w0, [x3, #0xf]
    // 0xfb1154: ldur            x0, [fp, #-0x28]
    // 0xfb1158: StoreField: r3->field_1f = r0
    //     0xfb1158: stur            w0, [x3, #0x1f]
    // 0xfb115c: ldur            x0, [fp, #-0x90]
    // 0xfb1160: StoreField: r3->field_23 = r0
    //     0xfb1160: stur            w0, [x3, #0x23]
    // 0xfb1164: ldur            x0, [fp, #-0x88]
    // 0xfb1168: StoreField: r3->field_27 = r0
    //     0xfb1168: stur            w0, [x3, #0x27]
    // 0xfb116c: ldur            x0, [fp, #-0x80]
    // 0xfb1170: StoreField: r3->field_2b = r0
    //     0xfb1170: stur            w0, [x3, #0x2b]
    // 0xfb1174: ldur            x0, [fp, #-0x78]
    // 0xfb1178: StoreField: r3->field_2f = r0
    //     0xfb1178: stur            w0, [x3, #0x2f]
    // 0xfb117c: ldur            x0, [fp, #-0x70]
    // 0xfb1180: StoreField: r3->field_33 = r0
    //     0xfb1180: stur            w0, [x3, #0x33]
    // 0xfb1184: ldur            x0, [fp, #-0x68]
    // 0xfb1188: StoreField: r3->field_37 = r0
    //     0xfb1188: stur            w0, [x3, #0x37]
    // 0xfb118c: ldur            x0, [fp, #-0x60]
    // 0xfb1190: StoreField: r3->field_3b = r0
    //     0xfb1190: stur            w0, [x3, #0x3b]
    // 0xfb1194: ldur            x0, [fp, #-0x58]
    // 0xfb1198: StoreField: r3->field_3f = r0
    //     0xfb1198: stur            w0, [x3, #0x3f]
    // 0xfb119c: ldur            x0, [fp, #-0x50]
    // 0xfb11a0: StoreField: r3->field_43 = r0
    //     0xfb11a0: stur            w0, [x3, #0x43]
    // 0xfb11a4: ldur            x0, [fp, #-0x48]
    // 0xfb11a8: StoreField: r3->field_47 = r0
    //     0xfb11a8: stur            w0, [x3, #0x47]
    // 0xfb11ac: ldur            x0, [fp, #-0x40]
    // 0xfb11b0: StoreField: r3->field_5f = r0
    //     0xfb11b0: stur            w0, [x3, #0x5f]
    // 0xfb11b4: ldur            x0, [fp, #-0x38]
    // 0xfb11b8: StoreField: r3->field_63 = r0
    //     0xfb11b8: stur            w0, [x3, #0x63]
    // 0xfb11bc: ldur            x0, [fp, #-0xa0]
    // 0xfb11c0: StoreField: r3->field_67 = r0
    //     0xfb11c0: stur            w0, [x3, #0x67]
    // 0xfb11c4: ldur            x0, [fp, #-0x98]
    // 0xfb11c8: StoreField: r3->field_4b = r0
    //     0xfb11c8: stur            w0, [x3, #0x4b]
    // 0xfb11cc: ldur            x0, [fp, #-0xb8]
    // 0xfb11d0: StoreField: r3->field_4f = r0
    //     0xfb11d0: stur            w0, [x3, #0x4f]
    // 0xfb11d4: ldur            x0, [fp, #-0xb0]
    // 0xfb11d8: StoreField: r3->field_53 = r0
    //     0xfb11d8: stur            w0, [x3, #0x53]
    // 0xfb11dc: ldur            x0, [fp, #-0xa8]
    // 0xfb11e0: StoreField: r3->field_57 = r0
    //     0xfb11e0: stur            w0, [x3, #0x57]
    // 0xfb11e4: ldur            x0, [fp, #-0xc0]
    // 0xfb11e8: StoreField: r3->field_6b = r0
    //     0xfb11e8: stur            w0, [x3, #0x6b]
    // 0xfb11ec: ldur            x0, [fp, #-0xc8]
    // 0xfb11f0: cmp             w0, NULL
    // 0xfb11f4: b.ne            #0xfb1204
    // 0xfb11f8: ldur            x0, [fp, #-0xd8]
    // 0xfb11fc: mov             x1, x3
    // 0xfb1200: b               #0xfb1240
    // 0xfb1204: ldur            x4, [fp, #-0xd8]
    // 0xfb1208: r1 = Null
    //     0xfb1208: mov             x1, NULL
    // 0xfb120c: r2 = 8
    //     0xfb120c: mov             x2, #8
    // 0xfb1210: r0 = AllocateArray()
    //     0xfb1210: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb1214: r16 = "packages/"
    //     0xfb1214: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0xfb1218: StoreField: r0->field_f = r16
    //     0xfb1218: stur            w16, [x0, #0xf]
    // 0xfb121c: ldur            x1, [fp, #-0xc8]
    // 0xfb1220: StoreField: r0->field_13 = r1
    //     0xfb1220: stur            w1, [x0, #0x13]
    // 0xfb1224: r16 = "/"
    //     0xfb1224: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xfb1228: ArrayStore: r0[0] = r16  ; List_4
    //     0xfb1228: stur            w16, [x0, #0x17]
    // 0xfb122c: ldur            x2, [fp, #-0xd8]
    // 0xfb1230: StoreField: r0->field_1b = r2
    //     0xfb1230: stur            w2, [x0, #0x1b]
    // 0xfb1234: str             x0, [SP]
    // 0xfb1238: r0 = _interpolate()
    //     0xfb1238: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xfb123c: ldur            x1, [fp, #-0xe0]
    // 0xfb1240: StoreField: r1->field_13 = r0
    //     0xfb1240: stur            w0, [x1, #0x13]
    //     0xfb1244: ldurb           w16, [x1, #-1]
    //     0xfb1248: ldurb           w17, [x0, #-1]
    //     0xfb124c: and             x16, x17, x16, lsr #2
    //     0xfb1250: tst             x16, HEAP, lsr #32
    //     0xfb1254: b.eq            #0xfb125c
    //     0xfb1258: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb125c: ldur            x0, [fp, #-0xd0]
    // 0xfb1260: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb1260: stur            w0, [x1, #0x17]
    //     0xfb1264: ldurb           w16, [x1, #-1]
    //     0xfb1268: ldurb           w17, [x0, #-1]
    //     0xfb126c: and             x16, x17, x16, lsr #2
    //     0xfb1270: tst             x16, HEAP, lsr #32
    //     0xfb1274: b.eq            #0xfb127c
    //     0xfb1278: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb127c: ldur            x0, [fp, #-0xc8]
    // 0xfb1280: StoreField: r1->field_1b = r0
    //     0xfb1280: stur            w0, [x1, #0x1b]
    //     0xfb1284: ldurb           w16, [x1, #-1]
    //     0xfb1288: ldurb           w17, [x0, #-1]
    //     0xfb128c: and             x16, x17, x16, lsr #2
    //     0xfb1290: tst             x16, HEAP, lsr #32
    //     0xfb1294: b.eq            #0xfb129c
    //     0xfb1298: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb129c: mov             x0, x1
    // 0xfb12a0: LeaveFrame
    //     0xfb12a0: mov             SP, fp
    //     0xfb12a4: ldp             fp, lr, [SP], #0x10
    // 0xfb12a8: ret
    //     0xfb12a8: ret             
    // 0xfb12ac: d1 = 0.500000
    //     0xfb12ac: fmov            d1, #0.50000000
    // 0xfb12b0: cmp             w4, NULL
    // 0xfb12b4: b.ne            #0xfb17b8
    // 0xfb12b8: ldur            x0, [fp, #-0x18]
    // 0xfb12bc: LoadField: r4 = r5->field_7
    //     0xfb12bc: ldur            w4, [x5, #7]
    // 0xfb12c0: DecompressPointer r4
    //     0xfb12c0: add             x4, x4, HEAP, lsl #32
    // 0xfb12c4: stur            x4, [fp, #-8]
    // 0xfb12c8: LoadField: r1 = r5->field_b
    //     0xfb12c8: ldur            w1, [x5, #0xb]
    // 0xfb12cc: DecompressPointer r1
    //     0xfb12cc: add             x1, x1, HEAP, lsl #32
    // 0xfb12d0: mov             x3, x0
    // 0xfb12d4: r2 = Null
    //     0xfb12d4: mov             x2, NULL
    // 0xfb12d8: r0 = lerp()
    //     0xfb12d8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb12dc: mov             x4, x0
    // 0xfb12e0: ldur            x0, [fp, #-0xe8]
    // 0xfb12e4: stur            x4, [fp, #-0x20]
    // 0xfb12e8: LoadField: r2 = r0->field_f
    //     0xfb12e8: ldur            w2, [x0, #0xf]
    // 0xfb12ec: DecompressPointer r2
    //     0xfb12ec: add             x2, x2, HEAP, lsl #32
    // 0xfb12f0: ldur            x3, [fp, #-0x18]
    // 0xfb12f4: r1 = Null
    //     0xfb12f4: mov             x1, NULL
    // 0xfb12f8: r0 = lerp()
    //     0xfb12f8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb12fc: ldur            x3, [fp, #-0x18]
    // 0xfb1300: stur            x0, [fp, #-0x30]
    // 0xfb1304: LoadField: d1 = r3->field_7
    //     0xfb1304: ldur            d1, [x3, #7]
    // 0xfb1308: stur            d1, [fp, #-0xf0]
    // 0xfb130c: d2 = 0.500000
    //     0xfb130c: fmov            d2, #0.50000000
    // 0xfb1310: fcmp            d2, d1
    // 0xfb1314: b.le            #0xfb132c
    // 0xfb1318: ldur            x4, [fp, #-0xe8]
    // 0xfb131c: LoadField: r1 = r4->field_1f
    //     0xfb131c: ldur            w1, [x4, #0x1f]
    // 0xfb1320: DecompressPointer r1
    //     0xfb1320: add             x1, x1, HEAP, lsl #32
    // 0xfb1324: mov             x5, x1
    // 0xfb1328: b               #0xfb1334
    // 0xfb132c: ldur            x4, [fp, #-0xe8]
    // 0xfb1330: r5 = Null
    //     0xfb1330: mov             x5, NULL
    // 0xfb1334: stur            x5, [fp, #-0x28]
    // 0xfb1338: LoadField: r1 = r4->field_23
    //     0xfb1338: ldur            w1, [x4, #0x23]
    // 0xfb133c: DecompressPointer r1
    //     0xfb133c: add             x1, x1, HEAP, lsl #32
    // 0xfb1340: mov             v0.16b, v1.16b
    // 0xfb1344: r2 = Null
    //     0xfb1344: mov             x2, NULL
    // 0xfb1348: r0 = lerp()
    //     0xfb1348: bl              #0xfb2a34  ; [dart:ui] FontWeight::lerp
    // 0xfb134c: ldur            d1, [fp, #-0xf0]
    // 0xfb1350: d2 = 0.500000
    //     0xfb1350: fmov            d2, #0.50000000
    // 0xfb1354: stur            x0, [fp, #-0x90]
    // 0xfb1358: fcmp            d2, d1
    // 0xfb135c: b.le            #0xfb1374
    // 0xfb1360: ldur            x3, [fp, #-0xe8]
    // 0xfb1364: LoadField: r1 = r3->field_27
    //     0xfb1364: ldur            w1, [x3, #0x27]
    // 0xfb1368: DecompressPointer r1
    //     0xfb1368: add             x1, x1, HEAP, lsl #32
    // 0xfb136c: mov             x4, x1
    // 0xfb1370: b               #0xfb137c
    // 0xfb1374: ldur            x3, [fp, #-0xe8]
    // 0xfb1378: r4 = Null
    //     0xfb1378: mov             x4, NULL
    // 0xfb137c: stur            x4, [fp, #-0x88]
    // 0xfb1380: fcmp            d2, d1
    // 0xfb1384: b.le            #0xfb1398
    // 0xfb1388: LoadField: r1 = r3->field_2b
    //     0xfb1388: ldur            w1, [x3, #0x2b]
    // 0xfb138c: DecompressPointer r1
    //     0xfb138c: add             x1, x1, HEAP, lsl #32
    // 0xfb1390: mov             x5, x1
    // 0xfb1394: b               #0xfb139c
    // 0xfb1398: r5 = Null
    //     0xfb1398: mov             x5, NULL
    // 0xfb139c: stur            x5, [fp, #-0x80]
    // 0xfb13a0: fcmp            d2, d1
    // 0xfb13a4: b.le            #0xfb13b8
    // 0xfb13a8: LoadField: r1 = r3->field_2f
    //     0xfb13a8: ldur            w1, [x3, #0x2f]
    // 0xfb13ac: DecompressPointer r1
    //     0xfb13ac: add             x1, x1, HEAP, lsl #32
    // 0xfb13b0: mov             x6, x1
    // 0xfb13b4: b               #0xfb13bc
    // 0xfb13b8: r6 = Null
    //     0xfb13b8: mov             x6, NULL
    // 0xfb13bc: stur            x6, [fp, #-0x78]
    // 0xfb13c0: fcmp            d2, d1
    // 0xfb13c4: b.le            #0xfb13d8
    // 0xfb13c8: LoadField: r1 = r3->field_33
    //     0xfb13c8: ldur            w1, [x3, #0x33]
    // 0xfb13cc: DecompressPointer r1
    //     0xfb13cc: add             x1, x1, HEAP, lsl #32
    // 0xfb13d0: mov             x7, x1
    // 0xfb13d4: b               #0xfb13dc
    // 0xfb13d8: r7 = Null
    //     0xfb13d8: mov             x7, NULL
    // 0xfb13dc: stur            x7, [fp, #-0x70]
    // 0xfb13e0: fcmp            d2, d1
    // 0xfb13e4: b.le            #0xfb13f8
    // 0xfb13e8: LoadField: r1 = r3->field_37
    //     0xfb13e8: ldur            w1, [x3, #0x37]
    // 0xfb13ec: DecompressPointer r1
    //     0xfb13ec: add             x1, x1, HEAP, lsl #32
    // 0xfb13f0: mov             x8, x1
    // 0xfb13f4: b               #0xfb13fc
    // 0xfb13f8: r8 = Null
    //     0xfb13f8: mov             x8, NULL
    // 0xfb13fc: stur            x8, [fp, #-0x68]
    // 0xfb1400: fcmp            d2, d1
    // 0xfb1404: b.le            #0xfb1418
    // 0xfb1408: LoadField: r1 = r3->field_3b
    //     0xfb1408: ldur            w1, [x3, #0x3b]
    // 0xfb140c: DecompressPointer r1
    //     0xfb140c: add             x1, x1, HEAP, lsl #32
    // 0xfb1410: mov             x9, x1
    // 0xfb1414: b               #0xfb141c
    // 0xfb1418: r9 = Null
    //     0xfb1418: mov             x9, NULL
    // 0xfb141c: stur            x9, [fp, #-0x60]
    // 0xfb1420: fcmp            d2, d1
    // 0xfb1424: b.le            #0xfb1438
    // 0xfb1428: LoadField: r1 = r3->field_3f
    //     0xfb1428: ldur            w1, [x3, #0x3f]
    // 0xfb142c: DecompressPointer r1
    //     0xfb142c: add             x1, x1, HEAP, lsl #32
    // 0xfb1430: mov             x10, x1
    // 0xfb1434: b               #0xfb143c
    // 0xfb1438: r10 = Null
    //     0xfb1438: mov             x10, NULL
    // 0xfb143c: stur            x10, [fp, #-0x58]
    // 0xfb1440: fcmp            d2, d1
    // 0xfb1444: b.le            #0xfb1458
    // 0xfb1448: LoadField: r1 = r3->field_43
    //     0xfb1448: ldur            w1, [x3, #0x43]
    // 0xfb144c: DecompressPointer r1
    //     0xfb144c: add             x1, x1, HEAP, lsl #32
    // 0xfb1450: mov             x11, x1
    // 0xfb1454: b               #0xfb145c
    // 0xfb1458: r11 = Null
    //     0xfb1458: mov             x11, NULL
    // 0xfb145c: stur            x11, [fp, #-0x50]
    // 0xfb1460: fcmp            d2, d1
    // 0xfb1464: b.le            #0xfb1478
    // 0xfb1468: LoadField: r1 = r3->field_47
    //     0xfb1468: ldur            w1, [x3, #0x47]
    // 0xfb146c: DecompressPointer r1
    //     0xfb146c: add             x1, x1, HEAP, lsl #32
    // 0xfb1470: mov             x12, x1
    // 0xfb1474: b               #0xfb147c
    // 0xfb1478: r12 = Null
    //     0xfb1478: mov             x12, NULL
    // 0xfb147c: stur            x12, [fp, #-0x48]
    // 0xfb1480: fcmp            d2, d1
    // 0xfb1484: b.le            #0xfb1498
    // 0xfb1488: LoadField: r1 = r3->field_5f
    //     0xfb1488: ldur            w1, [x3, #0x5f]
    // 0xfb148c: DecompressPointer r1
    //     0xfb148c: add             x1, x1, HEAP, lsl #32
    // 0xfb1490: mov             x13, x1
    // 0xfb1494: b               #0xfb149c
    // 0xfb1498: r13 = Null
    //     0xfb1498: mov             x13, NULL
    // 0xfb149c: stur            x13, [fp, #-0x40]
    // 0xfb14a0: fcmp            d2, d1
    // 0xfb14a4: b.le            #0xfb14b8
    // 0xfb14a8: LoadField: r1 = r3->field_63
    //     0xfb14a8: ldur            w1, [x3, #0x63]
    // 0xfb14ac: DecompressPointer r1
    //     0xfb14ac: add             x1, x1, HEAP, lsl #32
    // 0xfb14b0: mov             x14, x1
    // 0xfb14b4: b               #0xfb14bc
    // 0xfb14b8: r14 = Null
    //     0xfb14b8: mov             x14, NULL
    // 0xfb14bc: stur            x14, [fp, #-0x38]
    // 0xfb14c0: LoadField: r1 = r3->field_67
    //     0xfb14c0: ldur            w1, [x3, #0x67]
    // 0xfb14c4: DecompressPointer r1
    //     0xfb14c4: add             x1, x1, HEAP, lsl #32
    // 0xfb14c8: mov             v0.16b, v1.16b
    // 0xfb14cc: r2 = Null
    //     0xfb14cc: mov             x2, NULL
    // 0xfb14d0: r0 = lerpFontVariations()
    //     0xfb14d0: bl              #0xfb20ec  ; [package:flutter/src/painting/text_style.dart] ::lerpFontVariations
    // 0xfb14d4: ldur            d0, [fp, #-0xf0]
    // 0xfb14d8: d1 = 0.500000
    //     0xfb14d8: fmov            d1, #0.50000000
    // 0xfb14dc: stur            x0, [fp, #-0xa0]
    // 0xfb14e0: fcmp            d1, d0
    // 0xfb14e4: b.le            #0xfb14fc
    // 0xfb14e8: ldur            x4, [fp, #-0xe8]
    // 0xfb14ec: LoadField: r1 = r4->field_4b
    //     0xfb14ec: ldur            w1, [x4, #0x4b]
    // 0xfb14f0: DecompressPointer r1
    //     0xfb14f0: add             x1, x1, HEAP, lsl #32
    // 0xfb14f4: mov             x5, x1
    // 0xfb14f8: b               #0xfb1504
    // 0xfb14fc: ldur            x4, [fp, #-0xe8]
    // 0xfb1500: r5 = Null
    //     0xfb1500: mov             x5, NULL
    // 0xfb1504: stur            x5, [fp, #-0x98]
    // 0xfb1508: LoadField: r1 = r4->field_4f
    //     0xfb1508: ldur            w1, [x4, #0x4f]
    // 0xfb150c: DecompressPointer r1
    //     0xfb150c: add             x1, x1, HEAP, lsl #32
    // 0xfb1510: ldur            x3, [fp, #-0x18]
    // 0xfb1514: r2 = Null
    //     0xfb1514: mov             x2, NULL
    // 0xfb1518: r0 = lerp()
    //     0xfb1518: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb151c: ldur            d0, [fp, #-0xf0]
    // 0xfb1520: d1 = 0.500000
    //     0xfb1520: fmov            d1, #0.50000000
    // 0xfb1524: stur            x0, [fp, #-0xb8]
    // 0xfb1528: fcmp            d1, d0
    // 0xfb152c: b.le            #0xfb1544
    // 0xfb1530: ldur            x2, [fp, #-0xe8]
    // 0xfb1534: LoadField: r1 = r2->field_53
    //     0xfb1534: ldur            w1, [x2, #0x53]
    // 0xfb1538: DecompressPointer r1
    //     0xfb1538: add             x1, x1, HEAP, lsl #32
    // 0xfb153c: mov             x3, x1
    // 0xfb1540: b               #0xfb154c
    // 0xfb1544: ldur            x2, [fp, #-0xe8]
    // 0xfb1548: r3 = Null
    //     0xfb1548: mov             x3, NULL
    // 0xfb154c: stur            x3, [fp, #-0xb0]
    // 0xfb1550: fcmp            d1, d0
    // 0xfb1554: b.le            #0xfb1568
    // 0xfb1558: LoadField: r1 = r2->field_57
    //     0xfb1558: ldur            w1, [x2, #0x57]
    // 0xfb155c: DecompressPointer r1
    //     0xfb155c: add             x1, x1, HEAP, lsl #32
    // 0xfb1560: mov             x4, x1
    // 0xfb1564: b               #0xfb156c
    // 0xfb1568: r4 = Null
    //     0xfb1568: mov             x4, NULL
    // 0xfb156c: stur            x4, [fp, #-0xa8]
    // 0xfb1570: fcmp            d1, d0
    // 0xfb1574: b.le            #0xfb1584
    // 0xfb1578: mov             x1, x2
    // 0xfb157c: r0 = _fontFamily()
    //     0xfb157c: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0xfb1580: b               #0xfb1588
    // 0xfb1584: r0 = Null
    //     0xfb1584: mov             x0, NULL
    // 0xfb1588: ldur            d0, [fp, #-0xf0]
    // 0xfb158c: d1 = 0.500000
    //     0xfb158c: fmov            d1, #0.50000000
    // 0xfb1590: stur            x0, [fp, #-0xd8]
    // 0xfb1594: fcmp            d1, d0
    // 0xfb1598: b.le            #0xfb15ac
    // 0xfb159c: ldur            x5, [fp, #-0xe8]
    // 0xfb15a0: ArrayLoad: r1 = r5[0]  ; List_4
    //     0xfb15a0: ldur            w1, [x5, #0x17]
    // 0xfb15a4: DecompressPointer r1
    //     0xfb15a4: add             x1, x1, HEAP, lsl #32
    // 0xfb15a8: b               #0xfb15b4
    // 0xfb15ac: ldur            x5, [fp, #-0xe8]
    // 0xfb15b0: r1 = Null
    //     0xfb15b0: mov             x1, NULL
    // 0xfb15b4: stur            x1, [fp, #-0xd0]
    // 0xfb15b8: fcmp            d1, d0
    // 0xfb15bc: b.le            #0xfb15cc
    // 0xfb15c0: LoadField: r2 = r5->field_1b
    //     0xfb15c0: ldur            w2, [x5, #0x1b]
    // 0xfb15c4: DecompressPointer r2
    //     0xfb15c4: add             x2, x2, HEAP, lsl #32
    // 0xfb15c8: b               #0xfb15d0
    // 0xfb15cc: r2 = Null
    //     0xfb15cc: mov             x2, NULL
    // 0xfb15d0: stur            x2, [fp, #-0xc8]
    // 0xfb15d4: fcmp            d1, d0
    // 0xfb15d8: b.le            #0xfb15ec
    // 0xfb15dc: LoadField: r3 = r5->field_6b
    //     0xfb15dc: ldur            w3, [x5, #0x6b]
    // 0xfb15e0: DecompressPointer r3
    //     0xfb15e0: add             x3, x3, HEAP, lsl #32
    // 0xfb15e4: stur            x3, [fp, #-0xc0]
    // 0xfb15e8: b               #0xfb15f8
    // 0xfb15ec: SaveReg r0
    //     0xfb15ec: str             x0, [SP, #-8]!
    // 0xfb15f0: stur            NULL, [fp, #-0xc0]
    // 0xfb15f4: RestoreReg r0
    //     0xfb15f4: ldr             x0, [SP], #8
    // 0xfb15f8: ldur            x8, [fp, #-0x90]
    // 0xfb15fc: ldur            x9, [fp, #-0x88]
    // 0xfb1600: ldur            x10, [fp, #-0x80]
    // 0xfb1604: ldur            x11, [fp, #-0x78]
    // 0xfb1608: ldur            x12, [fp, #-0x70]
    // 0xfb160c: ldur            x13, [fp, #-0x68]
    // 0xfb1610: ldur            x14, [fp, #-0x60]
    // 0xfb1614: ldur            x19, [fp, #-0x58]
    // 0xfb1618: ldur            x20, [fp, #-0x50]
    // 0xfb161c: ldur            x23, [fp, #-0x48]
    // 0xfb1620: ldur            x24, [fp, #-0x40]
    // 0xfb1624: ldur            x25, [fp, #-0x38]
    // 0xfb1628: ldur            x6, [fp, #-0xa0]
    // 0xfb162c: ldur            x7, [fp, #-0x98]
    // 0xfb1630: ldur            x3, [fp, #-0xb8]
    // 0xfb1634: ldur            x4, [fp, #-0xb0]
    // 0xfb1638: ldur            x5, [fp, #-0xa8]
    // 0xfb163c: r0 = TextStyle()
    //     0xfb163c: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xfb1640: mov             x3, x0
    // 0xfb1644: ldur            x0, [fp, #-8]
    // 0xfb1648: stur            x3, [fp, #-0xe0]
    // 0xfb164c: StoreField: r3->field_7 = r0
    //     0xfb164c: stur            w0, [x3, #7]
    // 0xfb1650: ldur            x0, [fp, #-0x20]
    // 0xfb1654: StoreField: r3->field_b = r0
    //     0xfb1654: stur            w0, [x3, #0xb]
    // 0xfb1658: ldur            x0, [fp, #-0x30]
    // 0xfb165c: StoreField: r3->field_f = r0
    //     0xfb165c: stur            w0, [x3, #0xf]
    // 0xfb1660: ldur            x0, [fp, #-0x28]
    // 0xfb1664: StoreField: r3->field_1f = r0
    //     0xfb1664: stur            w0, [x3, #0x1f]
    // 0xfb1668: ldur            x0, [fp, #-0x90]
    // 0xfb166c: StoreField: r3->field_23 = r0
    //     0xfb166c: stur            w0, [x3, #0x23]
    // 0xfb1670: ldur            x0, [fp, #-0x88]
    // 0xfb1674: StoreField: r3->field_27 = r0
    //     0xfb1674: stur            w0, [x3, #0x27]
    // 0xfb1678: ldur            x0, [fp, #-0x80]
    // 0xfb167c: StoreField: r3->field_2b = r0
    //     0xfb167c: stur            w0, [x3, #0x2b]
    // 0xfb1680: ldur            x0, [fp, #-0x78]
    // 0xfb1684: StoreField: r3->field_2f = r0
    //     0xfb1684: stur            w0, [x3, #0x2f]
    // 0xfb1688: ldur            x0, [fp, #-0x70]
    // 0xfb168c: StoreField: r3->field_33 = r0
    //     0xfb168c: stur            w0, [x3, #0x33]
    // 0xfb1690: ldur            x0, [fp, #-0x68]
    // 0xfb1694: StoreField: r3->field_37 = r0
    //     0xfb1694: stur            w0, [x3, #0x37]
    // 0xfb1698: ldur            x0, [fp, #-0x60]
    // 0xfb169c: StoreField: r3->field_3b = r0
    //     0xfb169c: stur            w0, [x3, #0x3b]
    // 0xfb16a0: ldur            x0, [fp, #-0x58]
    // 0xfb16a4: StoreField: r3->field_3f = r0
    //     0xfb16a4: stur            w0, [x3, #0x3f]
    // 0xfb16a8: ldur            x0, [fp, #-0x50]
    // 0xfb16ac: StoreField: r3->field_43 = r0
    //     0xfb16ac: stur            w0, [x3, #0x43]
    // 0xfb16b0: ldur            x0, [fp, #-0x48]
    // 0xfb16b4: StoreField: r3->field_47 = r0
    //     0xfb16b4: stur            w0, [x3, #0x47]
    // 0xfb16b8: ldur            x0, [fp, #-0x40]
    // 0xfb16bc: StoreField: r3->field_5f = r0
    //     0xfb16bc: stur            w0, [x3, #0x5f]
    // 0xfb16c0: ldur            x0, [fp, #-0x38]
    // 0xfb16c4: StoreField: r3->field_63 = r0
    //     0xfb16c4: stur            w0, [x3, #0x63]
    // 0xfb16c8: ldur            x0, [fp, #-0xa0]
    // 0xfb16cc: StoreField: r3->field_67 = r0
    //     0xfb16cc: stur            w0, [x3, #0x67]
    // 0xfb16d0: ldur            x0, [fp, #-0x98]
    // 0xfb16d4: StoreField: r3->field_4b = r0
    //     0xfb16d4: stur            w0, [x3, #0x4b]
    // 0xfb16d8: ldur            x0, [fp, #-0xb8]
    // 0xfb16dc: StoreField: r3->field_4f = r0
    //     0xfb16dc: stur            w0, [x3, #0x4f]
    // 0xfb16e0: ldur            x0, [fp, #-0xb0]
    // 0xfb16e4: StoreField: r3->field_53 = r0
    //     0xfb16e4: stur            w0, [x3, #0x53]
    // 0xfb16e8: ldur            x0, [fp, #-0xa8]
    // 0xfb16ec: StoreField: r3->field_57 = r0
    //     0xfb16ec: stur            w0, [x3, #0x57]
    // 0xfb16f0: ldur            x0, [fp, #-0xc0]
    // 0xfb16f4: StoreField: r3->field_6b = r0
    //     0xfb16f4: stur            w0, [x3, #0x6b]
    // 0xfb16f8: ldur            x0, [fp, #-0xc8]
    // 0xfb16fc: cmp             w0, NULL
    // 0xfb1700: b.ne            #0xfb1710
    // 0xfb1704: ldur            x0, [fp, #-0xd8]
    // 0xfb1708: mov             x1, x3
    // 0xfb170c: b               #0xfb174c
    // 0xfb1710: ldur            x4, [fp, #-0xd8]
    // 0xfb1714: r1 = Null
    //     0xfb1714: mov             x1, NULL
    // 0xfb1718: r2 = 8
    //     0xfb1718: mov             x2, #8
    // 0xfb171c: r0 = AllocateArray()
    //     0xfb171c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb1720: r16 = "packages/"
    //     0xfb1720: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0xfb1724: StoreField: r0->field_f = r16
    //     0xfb1724: stur            w16, [x0, #0xf]
    // 0xfb1728: ldur            x1, [fp, #-0xc8]
    // 0xfb172c: StoreField: r0->field_13 = r1
    //     0xfb172c: stur            w1, [x0, #0x13]
    // 0xfb1730: r16 = "/"
    //     0xfb1730: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xfb1734: ArrayStore: r0[0] = r16  ; List_4
    //     0xfb1734: stur            w16, [x0, #0x17]
    // 0xfb1738: ldur            x2, [fp, #-0xd8]
    // 0xfb173c: StoreField: r0->field_1b = r2
    //     0xfb173c: stur            w2, [x0, #0x1b]
    // 0xfb1740: str             x0, [SP]
    // 0xfb1744: r0 = _interpolate()
    //     0xfb1744: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xfb1748: ldur            x1, [fp, #-0xe0]
    // 0xfb174c: StoreField: r1->field_13 = r0
    //     0xfb174c: stur            w0, [x1, #0x13]
    //     0xfb1750: ldurb           w16, [x1, #-1]
    //     0xfb1754: ldurb           w17, [x0, #-1]
    //     0xfb1758: and             x16, x17, x16, lsr #2
    //     0xfb175c: tst             x16, HEAP, lsr #32
    //     0xfb1760: b.eq            #0xfb1768
    //     0xfb1764: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb1768: ldur            x0, [fp, #-0xd0]
    // 0xfb176c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb176c: stur            w0, [x1, #0x17]
    //     0xfb1770: ldurb           w16, [x1, #-1]
    //     0xfb1774: ldurb           w17, [x0, #-1]
    //     0xfb1778: and             x16, x17, x16, lsr #2
    //     0xfb177c: tst             x16, HEAP, lsr #32
    //     0xfb1780: b.eq            #0xfb1788
    //     0xfb1784: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb1788: ldur            x0, [fp, #-0xc8]
    // 0xfb178c: StoreField: r1->field_1b = r0
    //     0xfb178c: stur            w0, [x1, #0x1b]
    //     0xfb1790: ldurb           w16, [x1, #-1]
    //     0xfb1794: ldurb           w17, [x0, #-1]
    //     0xfb1798: and             x16, x17, x16, lsr #2
    //     0xfb179c: tst             x16, HEAP, lsr #32
    //     0xfb17a0: b.eq            #0xfb17a8
    //     0xfb17a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb17a8: mov             x0, x1
    // 0xfb17ac: LeaveFrame
    //     0xfb17ac: mov             SP, fp
    //     0xfb17b0: ldp             fp, lr, [SP], #0x10
    // 0xfb17b4: ret
    //     0xfb17b4: ret             
    // 0xfb17b8: ldur            x0, [fp, #-0x18]
    // 0xfb17bc: LoadField: d0 = r0->field_7
    //     0xfb17bc: ldur            d0, [x0, #7]
    // 0xfb17c0: stur            d0, [fp, #-0xf0]
    // 0xfb17c4: fcmp            d1, d0
    // 0xfb17c8: b.le            #0xfb17dc
    // 0xfb17cc: LoadField: r1 = r5->field_7
    //     0xfb17cc: ldur            w1, [x5, #7]
    // 0xfb17d0: DecompressPointer r1
    //     0xfb17d0: add             x1, x1, HEAP, lsl #32
    // 0xfb17d4: mov             x6, x1
    // 0xfb17d8: b               #0xfb17e8
    // 0xfb17dc: LoadField: r1 = r4->field_7
    //     0xfb17dc: ldur            w1, [x4, #7]
    // 0xfb17e0: DecompressPointer r1
    //     0xfb17e0: add             x1, x1, HEAP, lsl #32
    // 0xfb17e4: mov             x6, x1
    // 0xfb17e8: stur            x6, [fp, #-0x20]
    // 0xfb17ec: LoadField: r7 = r5->field_43
    //     0xfb17ec: ldur            w7, [x5, #0x43]
    // 0xfb17f0: DecompressPointer r7
    //     0xfb17f0: add             x7, x7, HEAP, lsl #32
    // 0xfb17f4: stur            x7, [fp, #-8]
    // 0xfb17f8: cmp             w7, NULL
    // 0xfb17fc: b.ne            #0xfb1830
    // 0xfb1800: LoadField: r1 = r4->field_43
    //     0xfb1800: ldur            w1, [x4, #0x43]
    // 0xfb1804: DecompressPointer r1
    //     0xfb1804: add             x1, x1, HEAP, lsl #32
    // 0xfb1808: cmp             w1, NULL
    // 0xfb180c: b.ne            #0xfb1830
    // 0xfb1810: LoadField: r1 = r5->field_b
    //     0xfb1810: ldur            w1, [x5, #0xb]
    // 0xfb1814: DecompressPointer r1
    //     0xfb1814: add             x1, x1, HEAP, lsl #32
    // 0xfb1818: LoadField: r2 = r4->field_b
    //     0xfb1818: ldur            w2, [x4, #0xb]
    // 0xfb181c: DecompressPointer r2
    //     0xfb181c: add             x2, x2, HEAP, lsl #32
    // 0xfb1820: mov             x3, x0
    // 0xfb1824: r0 = lerp()
    //     0xfb1824: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb1828: mov             x4, x0
    // 0xfb182c: b               #0xfb1834
    // 0xfb1830: r4 = Null
    //     0xfb1830: mov             x4, NULL
    // 0xfb1834: ldur            x0, [fp, #-0xe8]
    // 0xfb1838: stur            x4, [fp, #-0x30]
    // 0xfb183c: LoadField: r5 = r0->field_47
    //     0xfb183c: ldur            w5, [x0, #0x47]
    // 0xfb1840: DecompressPointer r5
    //     0xfb1840: add             x5, x5, HEAP, lsl #32
    // 0xfb1844: stur            x5, [fp, #-0x28]
    // 0xfb1848: cmp             w5, NULL
    // 0xfb184c: b.ne            #0xfb1884
    // 0xfb1850: ldur            x6, [fp, #-0x10]
    // 0xfb1854: LoadField: r1 = r6->field_47
    //     0xfb1854: ldur            w1, [x6, #0x47]
    // 0xfb1858: DecompressPointer r1
    //     0xfb1858: add             x1, x1, HEAP, lsl #32
    // 0xfb185c: cmp             w1, NULL
    // 0xfb1860: b.ne            #0xfb1884
    // 0xfb1864: LoadField: r1 = r0->field_f
    //     0xfb1864: ldur            w1, [x0, #0xf]
    // 0xfb1868: DecompressPointer r1
    //     0xfb1868: add             x1, x1, HEAP, lsl #32
    // 0xfb186c: LoadField: r2 = r6->field_f
    //     0xfb186c: ldur            w2, [x6, #0xf]
    // 0xfb1870: DecompressPointer r2
    //     0xfb1870: add             x2, x2, HEAP, lsl #32
    // 0xfb1874: ldur            x3, [fp, #-0x18]
    // 0xfb1878: r0 = lerp()
    //     0xfb1878: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb187c: mov             x4, x0
    // 0xfb1880: b               #0xfb1888
    // 0xfb1884: r4 = Null
    //     0xfb1884: mov             x4, NULL
    // 0xfb1888: ldur            x0, [fp, #-0xe8]
    // 0xfb188c: stur            x4, [fp, #-0x38]
    // 0xfb1890: LoadField: r1 = r0->field_1f
    //     0xfb1890: ldur            w1, [x0, #0x1f]
    // 0xfb1894: DecompressPointer r1
    //     0xfb1894: add             x1, x1, HEAP, lsl #32
    // 0xfb1898: cmp             w1, NULL
    // 0xfb189c: b.ne            #0xfb18b0
    // 0xfb18a0: ldur            x5, [fp, #-0x10]
    // 0xfb18a4: LoadField: r2 = r5->field_1f
    //     0xfb18a4: ldur            w2, [x5, #0x1f]
    // 0xfb18a8: DecompressPointer r2
    //     0xfb18a8: add             x2, x2, HEAP, lsl #32
    // 0xfb18ac: b               #0xfb18b8
    // 0xfb18b0: ldur            x5, [fp, #-0x10]
    // 0xfb18b4: mov             x2, x1
    // 0xfb18b8: LoadField: r3 = r5->field_1f
    //     0xfb18b8: ldur            w3, [x5, #0x1f]
    // 0xfb18bc: DecompressPointer r3
    //     0xfb18bc: add             x3, x3, HEAP, lsl #32
    // 0xfb18c0: cmp             w3, NULL
    // 0xfb18c4: b.eq            #0xfb18cc
    // 0xfb18c8: mov             x1, x3
    // 0xfb18cc: ldur            d0, [fp, #-0xf0]
    // 0xfb18d0: mov             x16, x1
    // 0xfb18d4: mov             x1, x2
    // 0xfb18d8: mov             x2, x16
    // 0xfb18dc: ldur            x3, [fp, #-0x18]
    // 0xfb18e0: r0 = lerpDouble()
    //     0xfb18e0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb18e4: mov             x3, x0
    // 0xfb18e8: ldur            x0, [fp, #-0xe8]
    // 0xfb18ec: stur            x3, [fp, #-0x40]
    // 0xfb18f0: LoadField: r1 = r0->field_23
    //     0xfb18f0: ldur            w1, [x0, #0x23]
    // 0xfb18f4: DecompressPointer r1
    //     0xfb18f4: add             x1, x1, HEAP, lsl #32
    // 0xfb18f8: ldur            x4, [fp, #-0x10]
    // 0xfb18fc: LoadField: r2 = r4->field_23
    //     0xfb18fc: ldur            w2, [x4, #0x23]
    // 0xfb1900: DecompressPointer r2
    //     0xfb1900: add             x2, x2, HEAP, lsl #32
    // 0xfb1904: ldur            d0, [fp, #-0xf0]
    // 0xfb1908: r0 = lerp()
    //     0xfb1908: bl              #0xfb2a34  ; [dart:ui] FontWeight::lerp
    // 0xfb190c: ldur            d1, [fp, #-0xf0]
    // 0xfb1910: d0 = 0.500000
    //     0xfb1910: fmov            d0, #0.50000000
    // 0xfb1914: stur            x0, [fp, #-0x50]
    // 0xfb1918: fcmp            d0, d1
    // 0xfb191c: b.le            #0xfb1938
    // 0xfb1920: ldur            x4, [fp, #-0xe8]
    // 0xfb1924: LoadField: r1 = r4->field_27
    //     0xfb1924: ldur            w1, [x4, #0x27]
    // 0xfb1928: DecompressPointer r1
    //     0xfb1928: add             x1, x1, HEAP, lsl #32
    // 0xfb192c: mov             x6, x1
    // 0xfb1930: ldur            x5, [fp, #-0x10]
    // 0xfb1934: b               #0xfb194c
    // 0xfb1938: ldur            x4, [fp, #-0xe8]
    // 0xfb193c: ldur            x5, [fp, #-0x10]
    // 0xfb1940: LoadField: r1 = r5->field_27
    //     0xfb1940: ldur            w1, [x5, #0x27]
    // 0xfb1944: DecompressPointer r1
    //     0xfb1944: add             x1, x1, HEAP, lsl #32
    // 0xfb1948: mov             x6, x1
    // 0xfb194c: stur            x6, [fp, #-0x48]
    // 0xfb1950: LoadField: r1 = r4->field_2b
    //     0xfb1950: ldur            w1, [x4, #0x2b]
    // 0xfb1954: DecompressPointer r1
    //     0xfb1954: add             x1, x1, HEAP, lsl #32
    // 0xfb1958: cmp             w1, NULL
    // 0xfb195c: b.ne            #0xfb196c
    // 0xfb1960: LoadField: r2 = r5->field_2b
    //     0xfb1960: ldur            w2, [x5, #0x2b]
    // 0xfb1964: DecompressPointer r2
    //     0xfb1964: add             x2, x2, HEAP, lsl #32
    // 0xfb1968: b               #0xfb1970
    // 0xfb196c: mov             x2, x1
    // 0xfb1970: LoadField: r3 = r5->field_2b
    //     0xfb1970: ldur            w3, [x5, #0x2b]
    // 0xfb1974: DecompressPointer r3
    //     0xfb1974: add             x3, x3, HEAP, lsl #32
    // 0xfb1978: cmp             w3, NULL
    // 0xfb197c: b.eq            #0xfb1984
    // 0xfb1980: mov             x1, x3
    // 0xfb1984: mov             x16, x1
    // 0xfb1988: mov             x1, x2
    // 0xfb198c: mov             x2, x16
    // 0xfb1990: ldur            x3, [fp, #-0x18]
    // 0xfb1994: r0 = lerpDouble()
    //     0xfb1994: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb1998: mov             x4, x0
    // 0xfb199c: ldur            x0, [fp, #-0xe8]
    // 0xfb19a0: stur            x4, [fp, #-0x58]
    // 0xfb19a4: LoadField: r1 = r0->field_2f
    //     0xfb19a4: ldur            w1, [x0, #0x2f]
    // 0xfb19a8: DecompressPointer r1
    //     0xfb19a8: add             x1, x1, HEAP, lsl #32
    // 0xfb19ac: cmp             w1, NULL
    // 0xfb19b0: b.ne            #0xfb19c4
    // 0xfb19b4: ldur            x5, [fp, #-0x10]
    // 0xfb19b8: LoadField: r2 = r5->field_2f
    //     0xfb19b8: ldur            w2, [x5, #0x2f]
    // 0xfb19bc: DecompressPointer r2
    //     0xfb19bc: add             x2, x2, HEAP, lsl #32
    // 0xfb19c0: b               #0xfb19cc
    // 0xfb19c4: ldur            x5, [fp, #-0x10]
    // 0xfb19c8: mov             x2, x1
    // 0xfb19cc: LoadField: r3 = r5->field_2f
    //     0xfb19cc: ldur            w3, [x5, #0x2f]
    // 0xfb19d0: DecompressPointer r3
    //     0xfb19d0: add             x3, x3, HEAP, lsl #32
    // 0xfb19d4: cmp             w3, NULL
    // 0xfb19d8: b.eq            #0xfb19e0
    // 0xfb19dc: mov             x1, x3
    // 0xfb19e0: ldur            d0, [fp, #-0xf0]
    // 0xfb19e4: mov             x16, x1
    // 0xfb19e8: mov             x1, x2
    // 0xfb19ec: mov             x2, x16
    // 0xfb19f0: ldur            x3, [fp, #-0x18]
    // 0xfb19f4: r0 = lerpDouble()
    //     0xfb19f4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb19f8: ldur            d1, [fp, #-0xf0]
    // 0xfb19fc: d0 = 0.500000
    //     0xfb19fc: fmov            d0, #0.50000000
    // 0xfb1a00: stur            x0, [fp, #-0x68]
    // 0xfb1a04: fcmp            d0, d1
    // 0xfb1a08: b.le            #0xfb1a24
    // 0xfb1a0c: ldur            x4, [fp, #-0xe8]
    // 0xfb1a10: LoadField: r1 = r4->field_33
    //     0xfb1a10: ldur            w1, [x4, #0x33]
    // 0xfb1a14: DecompressPointer r1
    //     0xfb1a14: add             x1, x1, HEAP, lsl #32
    // 0xfb1a18: mov             x6, x1
    // 0xfb1a1c: ldur            x5, [fp, #-0x10]
    // 0xfb1a20: b               #0xfb1a38
    // 0xfb1a24: ldur            x4, [fp, #-0xe8]
    // 0xfb1a28: ldur            x5, [fp, #-0x10]
    // 0xfb1a2c: LoadField: r1 = r5->field_33
    //     0xfb1a2c: ldur            w1, [x5, #0x33]
    // 0xfb1a30: DecompressPointer r1
    //     0xfb1a30: add             x1, x1, HEAP, lsl #32
    // 0xfb1a34: mov             x6, x1
    // 0xfb1a38: stur            x6, [fp, #-0x60]
    // 0xfb1a3c: LoadField: r1 = r4->field_37
    //     0xfb1a3c: ldur            w1, [x4, #0x37]
    // 0xfb1a40: DecompressPointer r1
    //     0xfb1a40: add             x1, x1, HEAP, lsl #32
    // 0xfb1a44: cmp             w1, NULL
    // 0xfb1a48: b.ne            #0xfb1a58
    // 0xfb1a4c: LoadField: r2 = r5->field_37
    //     0xfb1a4c: ldur            w2, [x5, #0x37]
    // 0xfb1a50: DecompressPointer r2
    //     0xfb1a50: add             x2, x2, HEAP, lsl #32
    // 0xfb1a54: b               #0xfb1a5c
    // 0xfb1a58: mov             x2, x1
    // 0xfb1a5c: LoadField: r3 = r5->field_37
    //     0xfb1a5c: ldur            w3, [x5, #0x37]
    // 0xfb1a60: DecompressPointer r3
    //     0xfb1a60: add             x3, x3, HEAP, lsl #32
    // 0xfb1a64: cmp             w3, NULL
    // 0xfb1a68: b.eq            #0xfb1a70
    // 0xfb1a6c: mov             x1, x3
    // 0xfb1a70: mov             x16, x1
    // 0xfb1a74: mov             x1, x2
    // 0xfb1a78: mov             x2, x16
    // 0xfb1a7c: ldur            x3, [fp, #-0x18]
    // 0xfb1a80: r0 = lerpDouble()
    //     0xfb1a80: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb1a84: ldur            d1, [fp, #-0xf0]
    // 0xfb1a88: d0 = 0.500000
    //     0xfb1a88: fmov            d0, #0.50000000
    // 0xfb1a8c: stur            x0, [fp, #-0x80]
    // 0xfb1a90: fcmp            d0, d1
    // 0xfb1a94: b.le            #0xfb1ab0
    // 0xfb1a98: ldur            x1, [fp, #-0xe8]
    // 0xfb1a9c: LoadField: r2 = r1->field_3b
    //     0xfb1a9c: ldur            w2, [x1, #0x3b]
    // 0xfb1aa0: DecompressPointer r2
    //     0xfb1aa0: add             x2, x2, HEAP, lsl #32
    // 0xfb1aa4: mov             x3, x2
    // 0xfb1aa8: ldur            x2, [fp, #-0x10]
    // 0xfb1aac: b               #0xfb1ac0
    // 0xfb1ab0: ldur            x1, [fp, #-0xe8]
    // 0xfb1ab4: ldur            x2, [fp, #-0x10]
    // 0xfb1ab8: LoadField: r3 = r2->field_3b
    //     0xfb1ab8: ldur            w3, [x2, #0x3b]
    // 0xfb1abc: DecompressPointer r3
    //     0xfb1abc: add             x3, x3, HEAP, lsl #32
    // 0xfb1ac0: stur            x3, [fp, #-0x78]
    // 0xfb1ac4: fcmp            d0, d1
    // 0xfb1ac8: b.le            #0xfb1adc
    // 0xfb1acc: LoadField: r4 = r1->field_3f
    //     0xfb1acc: ldur            w4, [x1, #0x3f]
    // 0xfb1ad0: DecompressPointer r4
    //     0xfb1ad0: add             x4, x4, HEAP, lsl #32
    // 0xfb1ad4: mov             x5, x4
    // 0xfb1ad8: b               #0xfb1ae8
    // 0xfb1adc: LoadField: r4 = r2->field_3f
    //     0xfb1adc: ldur            w4, [x2, #0x3f]
    // 0xfb1ae0: DecompressPointer r4
    //     0xfb1ae0: add             x4, x4, HEAP, lsl #32
    // 0xfb1ae4: mov             x5, x4
    // 0xfb1ae8: ldur            x4, [fp, #-8]
    // 0xfb1aec: stur            x5, [fp, #-0x70]
    // 0xfb1af0: cmp             w4, NULL
    // 0xfb1af4: b.ne            #0xfb1b08
    // 0xfb1af8: LoadField: r6 = r2->field_43
    //     0xfb1af8: ldur            w6, [x2, #0x43]
    // 0xfb1afc: DecompressPointer r6
    //     0xfb1afc: add             x6, x6, HEAP, lsl #32
    // 0xfb1b00: cmp             w6, NULL
    // 0xfb1b04: b.eq            #0xfb1bc8
    // 0xfb1b08: fcmp            d0, d1
    // 0xfb1b0c: b.le            #0xfb1b68
    // 0xfb1b10: cmp             w4, NULL
    // 0xfb1b14: b.ne            #0xfb1b60
    // 0xfb1b18: r16 = 136
    //     0xfb1b18: mov             x16, #0x88
    // 0xfb1b1c: stp             x16, NULL, [SP]
    // 0xfb1b20: r0 = ByteData()
    //     0xfb1b20: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xfb1b24: stur            x0, [fp, #-0x88]
    // 0xfb1b28: r0 = Paint()
    //     0xfb1b28: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xfb1b2c: mov             x3, x0
    // 0xfb1b30: ldur            x0, [fp, #-0x88]
    // 0xfb1b34: stur            x3, [fp, #-0x90]
    // 0xfb1b38: StoreField: r3->field_7 = r0
    //     0xfb1b38: stur            w0, [x3, #7]
    // 0xfb1b3c: ldur            x0, [fp, #-0xe8]
    // 0xfb1b40: LoadField: r2 = r0->field_b
    //     0xfb1b40: ldur            w2, [x0, #0xb]
    // 0xfb1b44: DecompressPointer r2
    //     0xfb1b44: add             x2, x2, HEAP, lsl #32
    // 0xfb1b48: cmp             w2, NULL
    // 0xfb1b4c: b.eq            #0xfb20a4
    // 0xfb1b50: mov             x1, x3
    // 0xfb1b54: r0 = color=()
    //     0xfb1b54: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xfb1b58: ldur            x0, [fp, #-0x90]
    // 0xfb1b5c: b               #0xfb1bc0
    // 0xfb1b60: mov             x0, x4
    // 0xfb1b64: b               #0xfb1bc0
    // 0xfb1b68: mov             x1, x2
    // 0xfb1b6c: LoadField: r0 = r1->field_43
    //     0xfb1b6c: ldur            w0, [x1, #0x43]
    // 0xfb1b70: DecompressPointer r0
    //     0xfb1b70: add             x0, x0, HEAP, lsl #32
    // 0xfb1b74: cmp             w0, NULL
    // 0xfb1b78: b.ne            #0xfb1bc0
    // 0xfb1b7c: r16 = 136
    //     0xfb1b7c: mov             x16, #0x88
    // 0xfb1b80: stp             x16, NULL, [SP]
    // 0xfb1b84: r0 = ByteData()
    //     0xfb1b84: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xfb1b88: stur            x0, [fp, #-8]
    // 0xfb1b8c: r0 = Paint()
    //     0xfb1b8c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xfb1b90: mov             x3, x0
    // 0xfb1b94: ldur            x0, [fp, #-8]
    // 0xfb1b98: stur            x3, [fp, #-0x88]
    // 0xfb1b9c: StoreField: r3->field_7 = r0
    //     0xfb1b9c: stur            w0, [x3, #7]
    // 0xfb1ba0: ldur            x0, [fp, #-0x10]
    // 0xfb1ba4: LoadField: r2 = r0->field_b
    //     0xfb1ba4: ldur            w2, [x0, #0xb]
    // 0xfb1ba8: DecompressPointer r2
    //     0xfb1ba8: add             x2, x2, HEAP, lsl #32
    // 0xfb1bac: cmp             w2, NULL
    // 0xfb1bb0: b.eq            #0xfb20a8
    // 0xfb1bb4: mov             x1, x3
    // 0xfb1bb8: r0 = color=()
    //     0xfb1bb8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xfb1bbc: ldur            x0, [fp, #-0x88]
    // 0xfb1bc0: mov             x1, x0
    // 0xfb1bc4: b               #0xfb1bcc
    // 0xfb1bc8: r1 = Null
    //     0xfb1bc8: mov             x1, NULL
    // 0xfb1bcc: ldur            x0, [fp, #-0x28]
    // 0xfb1bd0: stur            x1, [fp, #-8]
    // 0xfb1bd4: cmp             w0, NULL
    // 0xfb1bd8: b.eq            #0xfb1be4
    // 0xfb1bdc: ldur            x2, [fp, #-0x10]
    // 0xfb1be0: b               #0xfb1bf8
    // 0xfb1be4: ldur            x2, [fp, #-0x10]
    // 0xfb1be8: LoadField: r3 = r2->field_47
    //     0xfb1be8: ldur            w3, [x2, #0x47]
    // 0xfb1bec: DecompressPointer r3
    //     0xfb1bec: add             x3, x3, HEAP, lsl #32
    // 0xfb1bf0: cmp             w3, NULL
    // 0xfb1bf4: b.eq            #0xfb1cbc
    // 0xfb1bf8: ldur            d1, [fp, #-0xf0]
    // 0xfb1bfc: d0 = 0.500000
    //     0xfb1bfc: fmov            d0, #0.50000000
    // 0xfb1c00: fcmp            d0, d1
    // 0xfb1c04: b.le            #0xfb1c5c
    // 0xfb1c08: cmp             w0, NULL
    // 0xfb1c0c: b.ne            #0xfb1cb4
    // 0xfb1c10: ldur            x0, [fp, #-0xe8]
    // 0xfb1c14: r16 = 136
    //     0xfb1c14: mov             x16, #0x88
    // 0xfb1c18: stp             x16, NULL, [SP]
    // 0xfb1c1c: r0 = ByteData()
    //     0xfb1c1c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xfb1c20: stur            x0, [fp, #-0x88]
    // 0xfb1c24: r0 = Paint()
    //     0xfb1c24: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xfb1c28: mov             x3, x0
    // 0xfb1c2c: ldur            x0, [fp, #-0x88]
    // 0xfb1c30: stur            x3, [fp, #-0x90]
    // 0xfb1c34: StoreField: r3->field_7 = r0
    //     0xfb1c34: stur            w0, [x3, #7]
    // 0xfb1c38: ldur            x0, [fp, #-0xe8]
    // 0xfb1c3c: LoadField: r2 = r0->field_f
    //     0xfb1c3c: ldur            w2, [x0, #0xf]
    // 0xfb1c40: DecompressPointer r2
    //     0xfb1c40: add             x2, x2, HEAP, lsl #32
    // 0xfb1c44: cmp             w2, NULL
    // 0xfb1c48: b.eq            #0xfb20ac
    // 0xfb1c4c: mov             x1, x3
    // 0xfb1c50: r0 = color=()
    //     0xfb1c50: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xfb1c54: ldur            x0, [fp, #-0x90]
    // 0xfb1c58: b               #0xfb1cb4
    // 0xfb1c5c: mov             x1, x2
    // 0xfb1c60: LoadField: r0 = r1->field_47
    //     0xfb1c60: ldur            w0, [x1, #0x47]
    // 0xfb1c64: DecompressPointer r0
    //     0xfb1c64: add             x0, x0, HEAP, lsl #32
    // 0xfb1c68: cmp             w0, NULL
    // 0xfb1c6c: b.ne            #0xfb1cb4
    // 0xfb1c70: r16 = 136
    //     0xfb1c70: mov             x16, #0x88
    // 0xfb1c74: stp             x16, NULL, [SP]
    // 0xfb1c78: r0 = ByteData()
    //     0xfb1c78: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xfb1c7c: stur            x0, [fp, #-0x28]
    // 0xfb1c80: r0 = Paint()
    //     0xfb1c80: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xfb1c84: mov             x3, x0
    // 0xfb1c88: ldur            x0, [fp, #-0x28]
    // 0xfb1c8c: stur            x3, [fp, #-0x88]
    // 0xfb1c90: StoreField: r3->field_7 = r0
    //     0xfb1c90: stur            w0, [x3, #7]
    // 0xfb1c94: ldur            x0, [fp, #-0x10]
    // 0xfb1c98: LoadField: r2 = r0->field_f
    //     0xfb1c98: ldur            w2, [x0, #0xf]
    // 0xfb1c9c: DecompressPointer r2
    //     0xfb1c9c: add             x2, x2, HEAP, lsl #32
    // 0xfb1ca0: cmp             w2, NULL
    // 0xfb1ca4: b.eq            #0xfb20b0
    // 0xfb1ca8: mov             x1, x3
    // 0xfb1cac: r0 = color=()
    //     0xfb1cac: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xfb1cb0: ldur            x0, [fp, #-0x88]
    // 0xfb1cb4: mov             x4, x0
    // 0xfb1cb8: b               #0xfb1cc0
    // 0xfb1cbc: r4 = Null
    //     0xfb1cbc: mov             x4, NULL
    // 0xfb1cc0: ldur            x3, [fp, #-0xe8]
    // 0xfb1cc4: ldur            x0, [fp, #-0x10]
    // 0xfb1cc8: ldur            d1, [fp, #-0xf0]
    // 0xfb1ccc: stur            x4, [fp, #-0x28]
    // 0xfb1cd0: LoadField: r1 = r3->field_5f
    //     0xfb1cd0: ldur            w1, [x3, #0x5f]
    // 0xfb1cd4: DecompressPointer r1
    //     0xfb1cd4: add             x1, x1, HEAP, lsl #32
    // 0xfb1cd8: LoadField: r2 = r0->field_5f
    //     0xfb1cd8: ldur            w2, [x0, #0x5f]
    // 0xfb1cdc: DecompressPointer r2
    //     0xfb1cdc: add             x2, x2, HEAP, lsl #32
    // 0xfb1ce0: mov             v0.16b, v1.16b
    // 0xfb1ce4: r0 = lerpList()
    //     0xfb1ce4: bl              #0xfb0470  ; [dart:ui] Shadow::lerpList
    // 0xfb1ce8: ldur            d2, [fp, #-0xf0]
    // 0xfb1cec: d1 = 0.500000
    //     0xfb1cec: fmov            d1, #0.50000000
    // 0xfb1cf0: stur            x0, [fp, #-0x90]
    // 0xfb1cf4: fcmp            d1, d2
    // 0xfb1cf8: b.le            #0xfb1d14
    // 0xfb1cfc: ldur            x3, [fp, #-0xe8]
    // 0xfb1d00: LoadField: r1 = r3->field_63
    //     0xfb1d00: ldur            w1, [x3, #0x63]
    // 0xfb1d04: DecompressPointer r1
    //     0xfb1d04: add             x1, x1, HEAP, lsl #32
    // 0xfb1d08: mov             x5, x1
    // 0xfb1d0c: ldur            x4, [fp, #-0x10]
    // 0xfb1d10: b               #0xfb1d28
    // 0xfb1d14: ldur            x3, [fp, #-0xe8]
    // 0xfb1d18: ldur            x4, [fp, #-0x10]
    // 0xfb1d1c: LoadField: r1 = r4->field_63
    //     0xfb1d1c: ldur            w1, [x4, #0x63]
    // 0xfb1d20: DecompressPointer r1
    //     0xfb1d20: add             x1, x1, HEAP, lsl #32
    // 0xfb1d24: mov             x5, x1
    // 0xfb1d28: stur            x5, [fp, #-0x88]
    // 0xfb1d2c: LoadField: r1 = r3->field_67
    //     0xfb1d2c: ldur            w1, [x3, #0x67]
    // 0xfb1d30: DecompressPointer r1
    //     0xfb1d30: add             x1, x1, HEAP, lsl #32
    // 0xfb1d34: LoadField: r2 = r4->field_67
    //     0xfb1d34: ldur            w2, [x4, #0x67]
    // 0xfb1d38: DecompressPointer r2
    //     0xfb1d38: add             x2, x2, HEAP, lsl #32
    // 0xfb1d3c: mov             v0.16b, v2.16b
    // 0xfb1d40: r0 = lerpFontVariations()
    //     0xfb1d40: bl              #0xfb20ec  ; [package:flutter/src/painting/text_style.dart] ::lerpFontVariations
    // 0xfb1d44: ldur            d1, [fp, #-0xf0]
    // 0xfb1d48: d0 = 0.500000
    //     0xfb1d48: fmov            d0, #0.50000000
    // 0xfb1d4c: stur            x0, [fp, #-0xa0]
    // 0xfb1d50: fcmp            d0, d1
    // 0xfb1d54: b.le            #0xfb1d70
    // 0xfb1d58: ldur            x4, [fp, #-0xe8]
    // 0xfb1d5c: LoadField: r1 = r4->field_4b
    //     0xfb1d5c: ldur            w1, [x4, #0x4b]
    // 0xfb1d60: DecompressPointer r1
    //     0xfb1d60: add             x1, x1, HEAP, lsl #32
    // 0xfb1d64: mov             x6, x1
    // 0xfb1d68: ldur            x5, [fp, #-0x10]
    // 0xfb1d6c: b               #0xfb1d84
    // 0xfb1d70: ldur            x4, [fp, #-0xe8]
    // 0xfb1d74: ldur            x5, [fp, #-0x10]
    // 0xfb1d78: LoadField: r1 = r5->field_4b
    //     0xfb1d78: ldur            w1, [x5, #0x4b]
    // 0xfb1d7c: DecompressPointer r1
    //     0xfb1d7c: add             x1, x1, HEAP, lsl #32
    // 0xfb1d80: mov             x6, x1
    // 0xfb1d84: stur            x6, [fp, #-0x98]
    // 0xfb1d88: LoadField: r1 = r4->field_4f
    //     0xfb1d88: ldur            w1, [x4, #0x4f]
    // 0xfb1d8c: DecompressPointer r1
    //     0xfb1d8c: add             x1, x1, HEAP, lsl #32
    // 0xfb1d90: LoadField: r2 = r5->field_4f
    //     0xfb1d90: ldur            w2, [x5, #0x4f]
    // 0xfb1d94: DecompressPointer r2
    //     0xfb1d94: add             x2, x2, HEAP, lsl #32
    // 0xfb1d98: ldur            x3, [fp, #-0x18]
    // 0xfb1d9c: r0 = lerp()
    //     0xfb1d9c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xfb1da0: ldur            d1, [fp, #-0xf0]
    // 0xfb1da4: d0 = 0.500000
    //     0xfb1da4: fmov            d0, #0.50000000
    // 0xfb1da8: stur            x0, [fp, #-0xb0]
    // 0xfb1dac: fcmp            d0, d1
    // 0xfb1db0: b.le            #0xfb1dcc
    // 0xfb1db4: ldur            x4, [fp, #-0xe8]
    // 0xfb1db8: LoadField: r1 = r4->field_53
    //     0xfb1db8: ldur            w1, [x4, #0x53]
    // 0xfb1dbc: DecompressPointer r1
    //     0xfb1dbc: add             x1, x1, HEAP, lsl #32
    // 0xfb1dc0: mov             x6, x1
    // 0xfb1dc4: ldur            x5, [fp, #-0x10]
    // 0xfb1dc8: b               #0xfb1de0
    // 0xfb1dcc: ldur            x4, [fp, #-0xe8]
    // 0xfb1dd0: ldur            x5, [fp, #-0x10]
    // 0xfb1dd4: LoadField: r1 = r5->field_53
    //     0xfb1dd4: ldur            w1, [x5, #0x53]
    // 0xfb1dd8: DecompressPointer r1
    //     0xfb1dd8: add             x1, x1, HEAP, lsl #32
    // 0xfb1ddc: mov             x6, x1
    // 0xfb1de0: stur            x6, [fp, #-0xa8]
    // 0xfb1de4: LoadField: r1 = r4->field_57
    //     0xfb1de4: ldur            w1, [x4, #0x57]
    // 0xfb1de8: DecompressPointer r1
    //     0xfb1de8: add             x1, x1, HEAP, lsl #32
    // 0xfb1dec: cmp             w1, NULL
    // 0xfb1df0: b.ne            #0xfb1e00
    // 0xfb1df4: LoadField: r2 = r5->field_57
    //     0xfb1df4: ldur            w2, [x5, #0x57]
    // 0xfb1df8: DecompressPointer r2
    //     0xfb1df8: add             x2, x2, HEAP, lsl #32
    // 0xfb1dfc: b               #0xfb1e04
    // 0xfb1e00: mov             x2, x1
    // 0xfb1e04: LoadField: r3 = r5->field_57
    //     0xfb1e04: ldur            w3, [x5, #0x57]
    // 0xfb1e08: DecompressPointer r3
    //     0xfb1e08: add             x3, x3, HEAP, lsl #32
    // 0xfb1e0c: cmp             w3, NULL
    // 0xfb1e10: b.eq            #0xfb1e18
    // 0xfb1e14: mov             x1, x3
    // 0xfb1e18: mov             x16, x1
    // 0xfb1e1c: mov             x1, x2
    // 0xfb1e20: mov             x2, x16
    // 0xfb1e24: ldur            x3, [fp, #-0x18]
    // 0xfb1e28: r0 = lerpDouble()
    //     0xfb1e28: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb1e2c: ldur            d1, [fp, #-0xf0]
    // 0xfb1e30: d0 = 0.500000
    //     0xfb1e30: fmov            d0, #0.50000000
    // 0xfb1e34: stur            x0, [fp, #-0x18]
    // 0xfb1e38: fcmp            d0, d1
    // 0xfb1e3c: b.le            #0xfb1e4c
    // 0xfb1e40: ldur            x1, [fp, #-0xe8]
    // 0xfb1e44: r0 = _fontFamily()
    //     0xfb1e44: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0xfb1e48: b               #0xfb1e54
    // 0xfb1e4c: ldur            x1, [fp, #-0x10]
    // 0xfb1e50: r0 = _fontFamily()
    //     0xfb1e50: bl              #0x8a6900  ; [package:flutter/src/painting/text_style.dart] TextStyle::_fontFamily
    // 0xfb1e54: ldur            d1, [fp, #-0xf0]
    // 0xfb1e58: d0 = 0.500000
    //     0xfb1e58: fmov            d0, #0.50000000
    // 0xfb1e5c: stur            x0, [fp, #-0xc8]
    // 0xfb1e60: fcmp            d0, d1
    // 0xfb1e64: b.le            #0xfb1e80
    // 0xfb1e68: ldur            x1, [fp, #-0xe8]
    // 0xfb1e6c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xfb1e6c: ldur            w2, [x1, #0x17]
    // 0xfb1e70: DecompressPointer r2
    //     0xfb1e70: add             x2, x2, HEAP, lsl #32
    // 0xfb1e74: mov             x3, x2
    // 0xfb1e78: ldur            x2, [fp, #-0x10]
    // 0xfb1e7c: b               #0xfb1e90
    // 0xfb1e80: ldur            x1, [fp, #-0xe8]
    // 0xfb1e84: ldur            x2, [fp, #-0x10]
    // 0xfb1e88: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xfb1e88: ldur            w3, [x2, #0x17]
    // 0xfb1e8c: DecompressPointer r3
    //     0xfb1e8c: add             x3, x3, HEAP, lsl #32
    // 0xfb1e90: stur            x3, [fp, #-0xc0]
    // 0xfb1e94: fcmp            d0, d1
    // 0xfb1e98: b.le            #0xfb1ea8
    // 0xfb1e9c: LoadField: r4 = r1->field_1b
    //     0xfb1e9c: ldur            w4, [x1, #0x1b]
    // 0xfb1ea0: DecompressPointer r4
    //     0xfb1ea0: add             x4, x4, HEAP, lsl #32
    // 0xfb1ea4: b               #0xfb1eb0
    // 0xfb1ea8: LoadField: r4 = r2->field_1b
    //     0xfb1ea8: ldur            w4, [x2, #0x1b]
    // 0xfb1eac: DecompressPointer r4
    //     0xfb1eac: add             x4, x4, HEAP, lsl #32
    // 0xfb1eb0: stur            x4, [fp, #-0xb8]
    // 0xfb1eb4: fcmp            d0, d1
    // 0xfb1eb8: b.le            #0xfb1ecc
    // 0xfb1ebc: LoadField: r2 = r1->field_6b
    //     0xfb1ebc: ldur            w2, [x1, #0x6b]
    // 0xfb1ec0: DecompressPointer r2
    //     0xfb1ec0: add             x2, x2, HEAP, lsl #32
    // 0xfb1ec4: stur            x2, [fp, #-0x10]
    // 0xfb1ec8: b               #0xfb1ed8
    // 0xfb1ecc: LoadField: r1 = r2->field_6b
    //     0xfb1ecc: ldur            w1, [x2, #0x6b]
    // 0xfb1ed0: DecompressPointer r1
    //     0xfb1ed0: add             x1, x1, HEAP, lsl #32
    // 0xfb1ed4: stur            x1, [fp, #-0x10]
    // 0xfb1ed8: ldur            x24, [fp, #-0x50]
    // 0xfb1edc: ldur            x25, [fp, #-0x48]
    // 0xfb1ee0: ldur            x23, [fp, #-0x58]
    // 0xfb1ee4: ldur            x19, [fp, #-0x68]
    // 0xfb1ee8: ldur            x20, [fp, #-0x60]
    // 0xfb1eec: ldur            x12, [fp, #-0x80]
    // 0xfb1ef0: ldur            x13, [fp, #-0x78]
    // 0xfb1ef4: ldur            x14, [fp, #-0x70]
    // 0xfb1ef8: ldur            x11, [fp, #-8]
    // 0xfb1efc: ldur            x10, [fp, #-0x28]
    // 0xfb1f00: ldur            x8, [fp, #-0x90]
    // 0xfb1f04: ldur            x9, [fp, #-0x88]
    // 0xfb1f08: ldur            x6, [fp, #-0xa0]
    // 0xfb1f0c: ldur            x7, [fp, #-0x98]
    // 0xfb1f10: ldur            x2, [fp, #-0xb0]
    // 0xfb1f14: ldur            x5, [fp, #-0xa8]
    // 0xfb1f18: ldur            x1, [fp, #-0x18]
    // 0xfb1f1c: r0 = TextStyle()
    //     0xfb1f1c: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xfb1f20: mov             x3, x0
    // 0xfb1f24: ldur            x0, [fp, #-0x20]
    // 0xfb1f28: stur            x3, [fp, #-0xd0]
    // 0xfb1f2c: StoreField: r3->field_7 = r0
    //     0xfb1f2c: stur            w0, [x3, #7]
    // 0xfb1f30: ldur            x0, [fp, #-0x30]
    // 0xfb1f34: StoreField: r3->field_b = r0
    //     0xfb1f34: stur            w0, [x3, #0xb]
    // 0xfb1f38: ldur            x0, [fp, #-0x38]
    // 0xfb1f3c: StoreField: r3->field_f = r0
    //     0xfb1f3c: stur            w0, [x3, #0xf]
    // 0xfb1f40: ldur            x0, [fp, #-0x40]
    // 0xfb1f44: StoreField: r3->field_1f = r0
    //     0xfb1f44: stur            w0, [x3, #0x1f]
    // 0xfb1f48: ldur            x0, [fp, #-0x50]
    // 0xfb1f4c: StoreField: r3->field_23 = r0
    //     0xfb1f4c: stur            w0, [x3, #0x23]
    // 0xfb1f50: ldur            x0, [fp, #-0x48]
    // 0xfb1f54: StoreField: r3->field_27 = r0
    //     0xfb1f54: stur            w0, [x3, #0x27]
    // 0xfb1f58: ldur            x0, [fp, #-0x58]
    // 0xfb1f5c: StoreField: r3->field_2b = r0
    //     0xfb1f5c: stur            w0, [x3, #0x2b]
    // 0xfb1f60: ldur            x0, [fp, #-0x68]
    // 0xfb1f64: StoreField: r3->field_2f = r0
    //     0xfb1f64: stur            w0, [x3, #0x2f]
    // 0xfb1f68: ldur            x0, [fp, #-0x60]
    // 0xfb1f6c: StoreField: r3->field_33 = r0
    //     0xfb1f6c: stur            w0, [x3, #0x33]
    // 0xfb1f70: ldur            x0, [fp, #-0x80]
    // 0xfb1f74: StoreField: r3->field_37 = r0
    //     0xfb1f74: stur            w0, [x3, #0x37]
    // 0xfb1f78: ldur            x0, [fp, #-0x78]
    // 0xfb1f7c: StoreField: r3->field_3b = r0
    //     0xfb1f7c: stur            w0, [x3, #0x3b]
    // 0xfb1f80: ldur            x0, [fp, #-0x70]
    // 0xfb1f84: StoreField: r3->field_3f = r0
    //     0xfb1f84: stur            w0, [x3, #0x3f]
    // 0xfb1f88: ldur            x0, [fp, #-8]
    // 0xfb1f8c: StoreField: r3->field_43 = r0
    //     0xfb1f8c: stur            w0, [x3, #0x43]
    // 0xfb1f90: ldur            x0, [fp, #-0x28]
    // 0xfb1f94: StoreField: r3->field_47 = r0
    //     0xfb1f94: stur            w0, [x3, #0x47]
    // 0xfb1f98: ldur            x0, [fp, #-0x90]
    // 0xfb1f9c: StoreField: r3->field_5f = r0
    //     0xfb1f9c: stur            w0, [x3, #0x5f]
    // 0xfb1fa0: ldur            x0, [fp, #-0x88]
    // 0xfb1fa4: StoreField: r3->field_63 = r0
    //     0xfb1fa4: stur            w0, [x3, #0x63]
    // 0xfb1fa8: ldur            x0, [fp, #-0xa0]
    // 0xfb1fac: StoreField: r3->field_67 = r0
    //     0xfb1fac: stur            w0, [x3, #0x67]
    // 0xfb1fb0: ldur            x0, [fp, #-0x98]
    // 0xfb1fb4: StoreField: r3->field_4b = r0
    //     0xfb1fb4: stur            w0, [x3, #0x4b]
    // 0xfb1fb8: ldur            x0, [fp, #-0xb0]
    // 0xfb1fbc: StoreField: r3->field_4f = r0
    //     0xfb1fbc: stur            w0, [x3, #0x4f]
    // 0xfb1fc0: ldur            x0, [fp, #-0xa8]
    // 0xfb1fc4: StoreField: r3->field_53 = r0
    //     0xfb1fc4: stur            w0, [x3, #0x53]
    // 0xfb1fc8: ldur            x0, [fp, #-0x18]
    // 0xfb1fcc: StoreField: r3->field_57 = r0
    //     0xfb1fcc: stur            w0, [x3, #0x57]
    // 0xfb1fd0: ldur            x0, [fp, #-0x10]
    // 0xfb1fd4: StoreField: r3->field_6b = r0
    //     0xfb1fd4: stur            w0, [x3, #0x6b]
    // 0xfb1fd8: ldur            x0, [fp, #-0xb8]
    // 0xfb1fdc: cmp             w0, NULL
    // 0xfb1fe0: b.ne            #0xfb1ff0
    // 0xfb1fe4: ldur            x0, [fp, #-0xc8]
    // 0xfb1fe8: mov             x1, x3
    // 0xfb1fec: b               #0xfb202c
    // 0xfb1ff0: ldur            x4, [fp, #-0xc8]
    // 0xfb1ff4: r1 = Null
    //     0xfb1ff4: mov             x1, NULL
    // 0xfb1ff8: r2 = 8
    //     0xfb1ff8: mov             x2, #8
    // 0xfb1ffc: r0 = AllocateArray()
    //     0xfb1ffc: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb2000: r16 = "packages/"
    //     0xfb2000: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0xfb2004: StoreField: r0->field_f = r16
    //     0xfb2004: stur            w16, [x0, #0xf]
    // 0xfb2008: ldur            x1, [fp, #-0xb8]
    // 0xfb200c: StoreField: r0->field_13 = r1
    //     0xfb200c: stur            w1, [x0, #0x13]
    // 0xfb2010: r16 = "/"
    //     0xfb2010: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xfb2014: ArrayStore: r0[0] = r16  ; List_4
    //     0xfb2014: stur            w16, [x0, #0x17]
    // 0xfb2018: ldur            x2, [fp, #-0xc8]
    // 0xfb201c: StoreField: r0->field_1b = r2
    //     0xfb201c: stur            w2, [x0, #0x1b]
    // 0xfb2020: str             x0, [SP]
    // 0xfb2024: r0 = _interpolate()
    //     0xfb2024: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xfb2028: ldur            x1, [fp, #-0xd0]
    // 0xfb202c: StoreField: r1->field_13 = r0
    //     0xfb202c: stur            w0, [x1, #0x13]
    //     0xfb2030: ldurb           w16, [x1, #-1]
    //     0xfb2034: ldurb           w17, [x0, #-1]
    //     0xfb2038: and             x16, x17, x16, lsr #2
    //     0xfb203c: tst             x16, HEAP, lsr #32
    //     0xfb2040: b.eq            #0xfb2048
    //     0xfb2044: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb2048: ldur            x0, [fp, #-0xc0]
    // 0xfb204c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb204c: stur            w0, [x1, #0x17]
    //     0xfb2050: ldurb           w16, [x1, #-1]
    //     0xfb2054: ldurb           w17, [x0, #-1]
    //     0xfb2058: and             x16, x17, x16, lsr #2
    //     0xfb205c: tst             x16, HEAP, lsr #32
    //     0xfb2060: b.eq            #0xfb2068
    //     0xfb2064: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb2068: ldur            x0, [fp, #-0xb8]
    // 0xfb206c: StoreField: r1->field_1b = r0
    //     0xfb206c: stur            w0, [x1, #0x1b]
    //     0xfb2070: ldurb           w16, [x1, #-1]
    //     0xfb2074: ldurb           w17, [x0, #-1]
    //     0xfb2078: and             x16, x17, x16, lsr #2
    //     0xfb207c: tst             x16, HEAP, lsr #32
    //     0xfb2080: b.eq            #0xfb2088
    //     0xfb2084: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfb2088: mov             x0, x1
    // 0xfb208c: LeaveFrame
    //     0xfb208c: mov             SP, fp
    //     0xfb2090: ldp             fp, lr, [SP], #0x10
    // 0xfb2094: ret
    //     0xfb2094: ret             
    // 0xfb2098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb2098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb209c: b               #0xfb0d88
    // 0xfb20a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb20a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb20a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb20a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb20a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb20a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb20ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb20ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb20b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb20b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static TextStyle? lerp(dynamic, TextStyle?, TextStyle?, double) {
    // ** addr: 0xfb20b4, size: 0x38
    // 0xfb20b4: EnterFrame
    //     0xfb20b4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb20b8: mov             fp, SP
    // 0xfb20bc: CheckStackOverflow
    //     0xfb20bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb20c0: cmp             SP, x16
    //     0xfb20c4: b.ls            #0xfb20e4
    // 0xfb20c8: ldr             x1, [fp, #0x20]
    // 0xfb20cc: ldr             x2, [fp, #0x18]
    // 0xfb20d0: ldr             x3, [fp, #0x10]
    // 0xfb20d4: r0 = lerp()
    //     0xfb20d4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xfb20d8: LeaveFrame
    //     0xfb20d8: mov             SP, fp
    //     0xfb20dc: ldp             fp, lr, [SP], #0x10
    // 0xfb20e0: ret
    //     0xfb20e0: ret             
    // 0xfb20e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb20e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb20e8: b               #0xfb20c8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113b420, size: 0x2e8
    // 0x113b420: EnterFrame
    //     0x113b420: stp             fp, lr, [SP, #-0x10]!
    //     0x113b424: mov             fp, SP
    // 0x113b428: AllocStack(0x120)
    //     0x113b428: sub             SP, SP, #0x120
    // 0x113b42c: CheckStackOverflow
    //     0x113b42c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b430: cmp             SP, x16
    //     0x113b434: b.ls            #0x113b700
    // 0x113b438: ldr             x1, [fp, #0x10]
    // 0x113b43c: r0 = fontFamilyFallback()
    //     0x113b43c: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x113b440: mov             x1, x0
    // 0x113b444: ldr             x0, [fp, #0x10]
    // 0x113b448: LoadField: r2 = r0->field_53
    //     0x113b448: ldur            w2, [x0, #0x53]
    // 0x113b44c: DecompressPointer r2
    //     0x113b44c: add             x2, x2, HEAP, lsl #32
    // 0x113b450: stur            x2, [fp, #-0x18]
    // 0x113b454: LoadField: r3 = r0->field_57
    //     0x113b454: ldur            w3, [x0, #0x57]
    // 0x113b458: DecompressPointer r3
    //     0x113b458: add             x3, x3, HEAP, lsl #32
    // 0x113b45c: stur            x3, [fp, #-0x10]
    // 0x113b460: LoadField: r4 = r0->field_13
    //     0x113b460: ldur            w4, [x0, #0x13]
    // 0x113b464: DecompressPointer r4
    //     0x113b464: add             x4, x4, HEAP, lsl #32
    // 0x113b468: stur            x4, [fp, #-8]
    // 0x113b46c: cmp             w1, NULL
    // 0x113b470: b.ne            #0x113b47c
    // 0x113b474: r1 = Null
    //     0x113b474: mov             x1, NULL
    // 0x113b478: b               #0x113b4a0
    // 0x113b47c: r0 = hashAll()
    //     0x113b47c: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113b480: mov             x2, x0
    // 0x113b484: r0 = BoxInt64Instr(r2)
    //     0x113b484: sbfiz           x0, x2, #1, #0x1f
    //     0x113b488: cmp             x2, x0, asr #1
    //     0x113b48c: b.eq            #0x113b498
    //     0x113b490: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b494: stur            x2, [x0, #7]
    // 0x113b498: mov             x1, x0
    // 0x113b49c: ldr             x0, [fp, #0x10]
    // 0x113b4a0: LoadField: r2 = r0->field_1b
    //     0x113b4a0: ldur            w2, [x0, #0x1b]
    // 0x113b4a4: DecompressPointer r2
    //     0x113b4a4: add             x2, x2, HEAP, lsl #32
    // 0x113b4a8: LoadField: r3 = r0->field_6b
    //     0x113b4a8: ldur            w3, [x0, #0x6b]
    // 0x113b4ac: DecompressPointer r3
    //     0x113b4ac: add             x3, x3, HEAP, lsl #32
    // 0x113b4b0: ldur            x16, [fp, #-8]
    // 0x113b4b4: stp             x1, x16, [SP, #0x10]
    // 0x113b4b8: stp             x3, x2, [SP]
    // 0x113b4bc: ldur            x1, [fp, #-0x18]
    // 0x113b4c0: ldur            x2, [fp, #-0x10]
    // 0x113b4c4: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x113b4c4: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x113b4c8: ldr             x4, [x4, #0xd28]
    // 0x113b4cc: r0 = hash()
    //     0x113b4cc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b4d0: mov             x2, x0
    // 0x113b4d4: ldr             x0, [fp, #0x10]
    // 0x113b4d8: stur            x2, [fp, #-0x88]
    // 0x113b4dc: LoadField: r1 = r0->field_5f
    //     0x113b4dc: ldur            w1, [x0, #0x5f]
    // 0x113b4e0: DecompressPointer r1
    //     0x113b4e0: add             x1, x1, HEAP, lsl #32
    // 0x113b4e4: LoadField: r3 = r0->field_63
    //     0x113b4e4: ldur            w3, [x0, #0x63]
    // 0x113b4e8: DecompressPointer r3
    //     0x113b4e8: add             x3, x3, HEAP, lsl #32
    // 0x113b4ec: stur            x3, [fp, #-0x80]
    // 0x113b4f0: LoadField: r4 = r0->field_67
    //     0x113b4f0: ldur            w4, [x0, #0x67]
    // 0x113b4f4: DecompressPointer r4
    //     0x113b4f4: add             x4, x4, HEAP, lsl #32
    // 0x113b4f8: stur            x4, [fp, #-0x78]
    // 0x113b4fc: LoadField: r5 = r0->field_7
    //     0x113b4fc: ldur            w5, [x0, #7]
    // 0x113b500: DecompressPointer r5
    //     0x113b500: add             x5, x5, HEAP, lsl #32
    // 0x113b504: stur            x5, [fp, #-0x70]
    // 0x113b508: LoadField: r6 = r0->field_b
    //     0x113b508: ldur            w6, [x0, #0xb]
    // 0x113b50c: DecompressPointer r6
    //     0x113b50c: add             x6, x6, HEAP, lsl #32
    // 0x113b510: stur            x6, [fp, #-0x68]
    // 0x113b514: LoadField: r7 = r0->field_f
    //     0x113b514: ldur            w7, [x0, #0xf]
    // 0x113b518: DecompressPointer r7
    //     0x113b518: add             x7, x7, HEAP, lsl #32
    // 0x113b51c: stur            x7, [fp, #-0x60]
    // 0x113b520: LoadField: r8 = r0->field_1f
    //     0x113b520: ldur            w8, [x0, #0x1f]
    // 0x113b524: DecompressPointer r8
    //     0x113b524: add             x8, x8, HEAP, lsl #32
    // 0x113b528: stur            x8, [fp, #-0x58]
    // 0x113b52c: LoadField: r9 = r0->field_23
    //     0x113b52c: ldur            w9, [x0, #0x23]
    // 0x113b530: DecompressPointer r9
    //     0x113b530: add             x9, x9, HEAP, lsl #32
    // 0x113b534: stur            x9, [fp, #-0x50]
    // 0x113b538: LoadField: r10 = r0->field_27
    //     0x113b538: ldur            w10, [x0, #0x27]
    // 0x113b53c: DecompressPointer r10
    //     0x113b53c: add             x10, x10, HEAP, lsl #32
    // 0x113b540: stur            x10, [fp, #-0x48]
    // 0x113b544: LoadField: r11 = r0->field_2b
    //     0x113b544: ldur            w11, [x0, #0x2b]
    // 0x113b548: DecompressPointer r11
    //     0x113b548: add             x11, x11, HEAP, lsl #32
    // 0x113b54c: stur            x11, [fp, #-0x40]
    // 0x113b550: LoadField: r12 = r0->field_2f
    //     0x113b550: ldur            w12, [x0, #0x2f]
    // 0x113b554: DecompressPointer r12
    //     0x113b554: add             x12, x12, HEAP, lsl #32
    // 0x113b558: stur            x12, [fp, #-0x38]
    // 0x113b55c: LoadField: r13 = r0->field_33
    //     0x113b55c: ldur            w13, [x0, #0x33]
    // 0x113b560: DecompressPointer r13
    //     0x113b560: add             x13, x13, HEAP, lsl #32
    // 0x113b564: stur            x13, [fp, #-0x30]
    // 0x113b568: LoadField: r14 = r0->field_37
    //     0x113b568: ldur            w14, [x0, #0x37]
    // 0x113b56c: DecompressPointer r14
    //     0x113b56c: add             x14, x14, HEAP, lsl #32
    // 0x113b570: stur            x14, [fp, #-0x28]
    // 0x113b574: LoadField: r19 = r0->field_3b
    //     0x113b574: ldur            w19, [x0, #0x3b]
    // 0x113b578: DecompressPointer r19
    //     0x113b578: add             x19, x19, HEAP, lsl #32
    // 0x113b57c: stur            x19, [fp, #-0x20]
    // 0x113b580: LoadField: r20 = r0->field_3f
    //     0x113b580: ldur            w20, [x0, #0x3f]
    // 0x113b584: DecompressPointer r20
    //     0x113b584: add             x20, x20, HEAP, lsl #32
    // 0x113b588: stur            x20, [fp, #-0x18]
    // 0x113b58c: LoadField: r23 = r0->field_43
    //     0x113b58c: ldur            w23, [x0, #0x43]
    // 0x113b590: DecompressPointer r23
    //     0x113b590: add             x23, x23, HEAP, lsl #32
    // 0x113b594: stur            x23, [fp, #-0x10]
    // 0x113b598: LoadField: r24 = r0->field_47
    //     0x113b598: ldur            w24, [x0, #0x47]
    // 0x113b59c: DecompressPointer r24
    //     0x113b59c: add             x24, x24, HEAP, lsl #32
    // 0x113b5a0: stur            x24, [fp, #-8]
    // 0x113b5a4: cmp             w1, NULL
    // 0x113b5a8: b.ne            #0x113b5b8
    // 0x113b5ac: mov             x1, x3
    // 0x113b5b0: r0 = Null
    //     0x113b5b0: mov             x0, NULL
    // 0x113b5b4: b               #0x113b5d8
    // 0x113b5b8: r0 = hashAll()
    //     0x113b5b8: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113b5bc: mov             x2, x0
    // 0x113b5c0: r0 = BoxInt64Instr(r2)
    //     0x113b5c0: sbfiz           x0, x2, #1, #0x1f
    //     0x113b5c4: cmp             x2, x0, asr #1
    //     0x113b5c8: b.eq            #0x113b5d4
    //     0x113b5cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b5d0: stur            x2, [x0, #7]
    // 0x113b5d4: ldur            x1, [fp, #-0x80]
    // 0x113b5d8: stur            x0, [fp, #-0x90]
    // 0x113b5dc: cmp             w1, NULL
    // 0x113b5e0: b.ne            #0x113b5ec
    // 0x113b5e4: r0 = Null
    //     0x113b5e4: mov             x0, NULL
    // 0x113b5e8: b               #0x113b608
    // 0x113b5ec: r0 = hashAll()
    //     0x113b5ec: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113b5f0: mov             x2, x0
    // 0x113b5f4: r0 = BoxInt64Instr(r2)
    //     0x113b5f4: sbfiz           x0, x2, #1, #0x1f
    //     0x113b5f8: cmp             x2, x0, asr #1
    //     0x113b5fc: b.eq            #0x113b608
    //     0x113b600: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b604: stur            x2, [x0, #7]
    // 0x113b608: ldur            x1, [fp, #-0x78]
    // 0x113b60c: stur            x0, [fp, #-0x80]
    // 0x113b610: cmp             w1, NULL
    // 0x113b614: b.ne            #0x113b620
    // 0x113b618: r3 = Null
    //     0x113b618: mov             x3, NULL
    // 0x113b61c: b               #0x113b640
    // 0x113b620: r0 = hashAll()
    //     0x113b620: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113b624: mov             x2, x0
    // 0x113b628: r0 = BoxInt64Instr(r2)
    //     0x113b628: sbfiz           x0, x2, #1, #0x1f
    //     0x113b62c: cmp             x2, x0, asr #1
    //     0x113b630: b.eq            #0x113b63c
    //     0x113b634: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b638: stur            x2, [x0, #7]
    // 0x113b63c: mov             x3, x0
    // 0x113b640: ldr             x0, [fp, #0x10]
    // 0x113b644: ldur            x2, [fp, #-0x88]
    // 0x113b648: LoadField: r4 = r0->field_4b
    //     0x113b648: ldur            w4, [x0, #0x4b]
    // 0x113b64c: DecompressPointer r4
    //     0x113b64c: add             x4, x4, HEAP, lsl #32
    // 0x113b650: LoadField: r5 = r0->field_4f
    //     0x113b650: ldur            w5, [x0, #0x4f]
    // 0x113b654: DecompressPointer r5
    //     0x113b654: add             x5, x5, HEAP, lsl #32
    // 0x113b658: r0 = BoxInt64Instr(r2)
    //     0x113b658: sbfiz           x0, x2, #1, #0x1f
    //     0x113b65c: cmp             x2, x0, asr #1
    //     0x113b660: b.eq            #0x113b66c
    //     0x113b664: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b668: stur            x2, [x0, #7]
    // 0x113b66c: ldur            x16, [fp, #-0x60]
    // 0x113b670: ldur            lr, [fp, #-0x58]
    // 0x113b674: stp             lr, x16, [SP, #0x80]
    // 0x113b678: ldur            x16, [fp, #-0x50]
    // 0x113b67c: ldur            lr, [fp, #-0x48]
    // 0x113b680: stp             lr, x16, [SP, #0x70]
    // 0x113b684: ldur            x16, [fp, #-0x40]
    // 0x113b688: ldur            lr, [fp, #-0x38]
    // 0x113b68c: stp             lr, x16, [SP, #0x60]
    // 0x113b690: ldur            x16, [fp, #-0x30]
    // 0x113b694: ldur            lr, [fp, #-0x28]
    // 0x113b698: stp             lr, x16, [SP, #0x50]
    // 0x113b69c: ldur            x16, [fp, #-0x20]
    // 0x113b6a0: ldur            lr, [fp, #-0x18]
    // 0x113b6a4: stp             lr, x16, [SP, #0x40]
    // 0x113b6a8: ldur            x16, [fp, #-0x10]
    // 0x113b6ac: ldur            lr, [fp, #-8]
    // 0x113b6b0: stp             lr, x16, [SP, #0x30]
    // 0x113b6b4: ldur            x16, [fp, #-0x90]
    // 0x113b6b8: ldur            lr, [fp, #-0x80]
    // 0x113b6bc: stp             lr, x16, [SP, #0x20]
    // 0x113b6c0: stp             x4, x3, [SP, #0x10]
    // 0x113b6c4: stp             x0, x5, [SP]
    // 0x113b6c8: ldur            x1, [fp, #-0x70]
    // 0x113b6cc: ldur            x2, [fp, #-0x68]
    // 0x113b6d0: r4 = const [0, 0x14, 0x12, 0x14, null]
    //     0x113b6d0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf20] List(5) [0, 0x14, 0x12, 0x14, Null]
    //     0x113b6d4: ldr             x4, [x4, #0xf20]
    // 0x113b6d8: r0 = hash()
    //     0x113b6d8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b6dc: mov             x2, x0
    // 0x113b6e0: r0 = BoxInt64Instr(r2)
    //     0x113b6e0: sbfiz           x0, x2, #1, #0x1f
    //     0x113b6e4: cmp             x2, x0, asr #1
    //     0x113b6e8: b.eq            #0x113b6f4
    //     0x113b6ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b6f0: stur            x2, [x0, #7]
    // 0x113b6f4: LeaveFrame
    //     0x113b6f4: mov             SP, fp
    //     0x113b6f8: ldp             fp, lr, [SP], #0x10
    // 0x113b6fc: ret
    //     0x113b6fc: ret             
    // 0x113b700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b704: b               #0x113b438
  }
  _ ==(/* No info */) {
    // ** addr: 0x1278be0, size: 0x520
    // 0x1278be0: EnterFrame
    //     0x1278be0: stp             fp, lr, [SP, #-0x10]!
    //     0x1278be4: mov             fp, SP
    // 0x1278be8: AllocStack(0x20)
    //     0x1278be8: sub             SP, SP, #0x20
    // 0x1278bec: CheckStackOverflow
    //     0x1278bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1278bf0: cmp             SP, x16
    //     0x1278bf4: b.ls            #0x12790f8
    // 0x1278bf8: ldr             x1, [fp, #0x10]
    // 0x1278bfc: cmp             w1, NULL
    // 0x1278c00: b.ne            #0x1278c14
    // 0x1278c04: r0 = false
    //     0x1278c04: add             x0, NULL, #0x30  ; false
    // 0x1278c08: LeaveFrame
    //     0x1278c08: mov             SP, fp
    //     0x1278c0c: ldp             fp, lr, [SP], #0x10
    // 0x1278c10: ret
    //     0x1278c10: ret             
    // 0x1278c14: ldr             x0, [fp, #0x18]
    // 0x1278c18: cmp             w0, w1
    // 0x1278c1c: b.ne            #0x1278c30
    // 0x1278c20: r0 = true
    //     0x1278c20: add             x0, NULL, #0x20  ; true
    // 0x1278c24: LeaveFrame
    //     0x1278c24: mov             SP, fp
    //     0x1278c28: ldp             fp, lr, [SP], #0x10
    // 0x1278c2c: ret
    //     0x1278c2c: ret             
    // 0x1278c30: stp             x0, x1, [SP]
    // 0x1278c34: r0 = _haveSameRuntimeType()
    //     0x1278c34: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1278c38: tbz             w0, #4, #0x1278c4c
    // 0x1278c3c: r0 = false
    //     0x1278c3c: add             x0, NULL, #0x30  ; false
    // 0x1278c40: LeaveFrame
    //     0x1278c40: mov             SP, fp
    //     0x1278c44: ldp             fp, lr, [SP], #0x10
    // 0x1278c48: ret
    //     0x1278c48: ret             
    // 0x1278c4c: ldr             x1, [fp, #0x10]
    // 0x1278c50: r0 = 60
    //     0x1278c50: mov             x0, #0x3c
    // 0x1278c54: branchIfSmi(r1, 0x1278c60)
    //     0x1278c54: tbz             w1, #0, #0x1278c60
    // 0x1278c58: r0 = LoadClassIdInstr(r1)
    //     0x1278c58: ldur            x0, [x1, #-1]
    //     0x1278c5c: ubfx            x0, x0, #0xc, #0x14
    // 0x1278c60: r17 = -5040
    //     0x1278c60: mov             x17, #-0x13b0
    // 0x1278c64: add             x16, x0, x17
    // 0x1278c68: cmp             x16, #2
    // 0x1278c6c: b.hi            #0x12790e8
    // 0x1278c70: ldr             x2, [fp, #0x18]
    // 0x1278c74: LoadField: r0 = r1->field_7
    //     0x1278c74: ldur            w0, [x1, #7]
    // 0x1278c78: DecompressPointer r0
    //     0x1278c78: add             x0, x0, HEAP, lsl #32
    // 0x1278c7c: LoadField: r3 = r2->field_7
    //     0x1278c7c: ldur            w3, [x2, #7]
    // 0x1278c80: DecompressPointer r3
    //     0x1278c80: add             x3, x3, HEAP, lsl #32
    // 0x1278c84: cmp             w0, w3
    // 0x1278c88: b.ne            #0x12790e8
    // 0x1278c8c: LoadField: r0 = r1->field_b
    //     0x1278c8c: ldur            w0, [x1, #0xb]
    // 0x1278c90: DecompressPointer r0
    //     0x1278c90: add             x0, x0, HEAP, lsl #32
    // 0x1278c94: LoadField: r3 = r2->field_b
    //     0x1278c94: ldur            w3, [x2, #0xb]
    // 0x1278c98: DecompressPointer r3
    //     0x1278c98: add             x3, x3, HEAP, lsl #32
    // 0x1278c9c: r4 = LoadClassIdInstr(r0)
    //     0x1278c9c: ldur            x4, [x0, #-1]
    //     0x1278ca0: ubfx            x4, x4, #0xc, #0x14
    // 0x1278ca4: stp             x3, x0, [SP]
    // 0x1278ca8: mov             x0, x4
    // 0x1278cac: mov             lr, x0
    // 0x1278cb0: ldr             lr, [x21, lr, lsl #3]
    // 0x1278cb4: blr             lr
    // 0x1278cb8: tbnz            w0, #4, #0x12790e8
    // 0x1278cbc: ldr             x2, [fp, #0x18]
    // 0x1278cc0: ldr             x1, [fp, #0x10]
    // 0x1278cc4: LoadField: r0 = r1->field_f
    //     0x1278cc4: ldur            w0, [x1, #0xf]
    // 0x1278cc8: DecompressPointer r0
    //     0x1278cc8: add             x0, x0, HEAP, lsl #32
    // 0x1278ccc: LoadField: r3 = r2->field_f
    //     0x1278ccc: ldur            w3, [x2, #0xf]
    // 0x1278cd0: DecompressPointer r3
    //     0x1278cd0: add             x3, x3, HEAP, lsl #32
    // 0x1278cd4: r4 = LoadClassIdInstr(r0)
    //     0x1278cd4: ldur            x4, [x0, #-1]
    //     0x1278cd8: ubfx            x4, x4, #0xc, #0x14
    // 0x1278cdc: stp             x3, x0, [SP]
    // 0x1278ce0: mov             x0, x4
    // 0x1278ce4: mov             lr, x0
    // 0x1278ce8: ldr             lr, [x21, lr, lsl #3]
    // 0x1278cec: blr             lr
    // 0x1278cf0: tbnz            w0, #4, #0x12790e8
    // 0x1278cf4: ldr             x2, [fp, #0x18]
    // 0x1278cf8: ldr             x1, [fp, #0x10]
    // 0x1278cfc: LoadField: r0 = r1->field_1f
    //     0x1278cfc: ldur            w0, [x1, #0x1f]
    // 0x1278d00: DecompressPointer r0
    //     0x1278d00: add             x0, x0, HEAP, lsl #32
    // 0x1278d04: LoadField: r3 = r2->field_1f
    //     0x1278d04: ldur            w3, [x2, #0x1f]
    // 0x1278d08: DecompressPointer r3
    //     0x1278d08: add             x3, x3, HEAP, lsl #32
    // 0x1278d0c: r4 = LoadClassIdInstr(r0)
    //     0x1278d0c: ldur            x4, [x0, #-1]
    //     0x1278d10: ubfx            x4, x4, #0xc, #0x14
    // 0x1278d14: stp             x3, x0, [SP]
    // 0x1278d18: mov             x0, x4
    // 0x1278d1c: mov             lr, x0
    // 0x1278d20: ldr             lr, [x21, lr, lsl #3]
    // 0x1278d24: blr             lr
    // 0x1278d28: tbnz            w0, #4, #0x12790e8
    // 0x1278d2c: ldr             x2, [fp, #0x18]
    // 0x1278d30: ldr             x1, [fp, #0x10]
    // 0x1278d34: LoadField: r0 = r1->field_23
    //     0x1278d34: ldur            w0, [x1, #0x23]
    // 0x1278d38: DecompressPointer r0
    //     0x1278d38: add             x0, x0, HEAP, lsl #32
    // 0x1278d3c: LoadField: r3 = r2->field_23
    //     0x1278d3c: ldur            w3, [x2, #0x23]
    // 0x1278d40: DecompressPointer r3
    //     0x1278d40: add             x3, x3, HEAP, lsl #32
    // 0x1278d44: r4 = LoadClassIdInstr(r0)
    //     0x1278d44: ldur            x4, [x0, #-1]
    //     0x1278d48: ubfx            x4, x4, #0xc, #0x14
    // 0x1278d4c: stp             x3, x0, [SP]
    // 0x1278d50: mov             x0, x4
    // 0x1278d54: mov             lr, x0
    // 0x1278d58: ldr             lr, [x21, lr, lsl #3]
    // 0x1278d5c: blr             lr
    // 0x1278d60: tbnz            w0, #4, #0x12790e8
    // 0x1278d64: ldr             x2, [fp, #0x18]
    // 0x1278d68: ldr             x1, [fp, #0x10]
    // 0x1278d6c: LoadField: r0 = r1->field_27
    //     0x1278d6c: ldur            w0, [x1, #0x27]
    // 0x1278d70: DecompressPointer r0
    //     0x1278d70: add             x0, x0, HEAP, lsl #32
    // 0x1278d74: LoadField: r3 = r2->field_27
    //     0x1278d74: ldur            w3, [x2, #0x27]
    // 0x1278d78: DecompressPointer r3
    //     0x1278d78: add             x3, x3, HEAP, lsl #32
    // 0x1278d7c: cmp             w0, w3
    // 0x1278d80: b.ne            #0x12790e8
    // 0x1278d84: LoadField: r0 = r1->field_2b
    //     0x1278d84: ldur            w0, [x1, #0x2b]
    // 0x1278d88: DecompressPointer r0
    //     0x1278d88: add             x0, x0, HEAP, lsl #32
    // 0x1278d8c: LoadField: r3 = r2->field_2b
    //     0x1278d8c: ldur            w3, [x2, #0x2b]
    // 0x1278d90: DecompressPointer r3
    //     0x1278d90: add             x3, x3, HEAP, lsl #32
    // 0x1278d94: r4 = LoadClassIdInstr(r0)
    //     0x1278d94: ldur            x4, [x0, #-1]
    //     0x1278d98: ubfx            x4, x4, #0xc, #0x14
    // 0x1278d9c: stp             x3, x0, [SP]
    // 0x1278da0: mov             x0, x4
    // 0x1278da4: mov             lr, x0
    // 0x1278da8: ldr             lr, [x21, lr, lsl #3]
    // 0x1278dac: blr             lr
    // 0x1278db0: tbnz            w0, #4, #0x12790e8
    // 0x1278db4: ldr             x2, [fp, #0x18]
    // 0x1278db8: ldr             x1, [fp, #0x10]
    // 0x1278dbc: LoadField: r0 = r1->field_2f
    //     0x1278dbc: ldur            w0, [x1, #0x2f]
    // 0x1278dc0: DecompressPointer r0
    //     0x1278dc0: add             x0, x0, HEAP, lsl #32
    // 0x1278dc4: LoadField: r3 = r2->field_2f
    //     0x1278dc4: ldur            w3, [x2, #0x2f]
    // 0x1278dc8: DecompressPointer r3
    //     0x1278dc8: add             x3, x3, HEAP, lsl #32
    // 0x1278dcc: r4 = LoadClassIdInstr(r0)
    //     0x1278dcc: ldur            x4, [x0, #-1]
    //     0x1278dd0: ubfx            x4, x4, #0xc, #0x14
    // 0x1278dd4: stp             x3, x0, [SP]
    // 0x1278dd8: mov             x0, x4
    // 0x1278ddc: mov             lr, x0
    // 0x1278de0: ldr             lr, [x21, lr, lsl #3]
    // 0x1278de4: blr             lr
    // 0x1278de8: tbnz            w0, #4, #0x12790e8
    // 0x1278dec: ldr             x2, [fp, #0x18]
    // 0x1278df0: ldr             x1, [fp, #0x10]
    // 0x1278df4: LoadField: r0 = r1->field_33
    //     0x1278df4: ldur            w0, [x1, #0x33]
    // 0x1278df8: DecompressPointer r0
    //     0x1278df8: add             x0, x0, HEAP, lsl #32
    // 0x1278dfc: LoadField: r3 = r2->field_33
    //     0x1278dfc: ldur            w3, [x2, #0x33]
    // 0x1278e00: DecompressPointer r3
    //     0x1278e00: add             x3, x3, HEAP, lsl #32
    // 0x1278e04: cmp             w0, w3
    // 0x1278e08: b.ne            #0x12790e8
    // 0x1278e0c: LoadField: r0 = r1->field_37
    //     0x1278e0c: ldur            w0, [x1, #0x37]
    // 0x1278e10: DecompressPointer r0
    //     0x1278e10: add             x0, x0, HEAP, lsl #32
    // 0x1278e14: LoadField: r3 = r2->field_37
    //     0x1278e14: ldur            w3, [x2, #0x37]
    // 0x1278e18: DecompressPointer r3
    //     0x1278e18: add             x3, x3, HEAP, lsl #32
    // 0x1278e1c: r4 = LoadClassIdInstr(r0)
    //     0x1278e1c: ldur            x4, [x0, #-1]
    //     0x1278e20: ubfx            x4, x4, #0xc, #0x14
    // 0x1278e24: stp             x3, x0, [SP]
    // 0x1278e28: mov             x0, x4
    // 0x1278e2c: mov             lr, x0
    // 0x1278e30: ldr             lr, [x21, lr, lsl #3]
    // 0x1278e34: blr             lr
    // 0x1278e38: tbnz            w0, #4, #0x12790e8
    // 0x1278e3c: ldr             x2, [fp, #0x18]
    // 0x1278e40: ldr             x1, [fp, #0x10]
    // 0x1278e44: LoadField: r0 = r1->field_3b
    //     0x1278e44: ldur            w0, [x1, #0x3b]
    // 0x1278e48: DecompressPointer r0
    //     0x1278e48: add             x0, x0, HEAP, lsl #32
    // 0x1278e4c: LoadField: r3 = r2->field_3b
    //     0x1278e4c: ldur            w3, [x2, #0x3b]
    // 0x1278e50: DecompressPointer r3
    //     0x1278e50: add             x3, x3, HEAP, lsl #32
    // 0x1278e54: cmp             w0, w3
    // 0x1278e58: b.ne            #0x12790e8
    // 0x1278e5c: LoadField: r0 = r1->field_3f
    //     0x1278e5c: ldur            w0, [x1, #0x3f]
    // 0x1278e60: DecompressPointer r0
    //     0x1278e60: add             x0, x0, HEAP, lsl #32
    // 0x1278e64: LoadField: r3 = r2->field_3f
    //     0x1278e64: ldur            w3, [x2, #0x3f]
    // 0x1278e68: DecompressPointer r3
    //     0x1278e68: add             x3, x3, HEAP, lsl #32
    // 0x1278e6c: r4 = LoadClassIdInstr(r0)
    //     0x1278e6c: ldur            x4, [x0, #-1]
    //     0x1278e70: ubfx            x4, x4, #0xc, #0x14
    // 0x1278e74: stp             x3, x0, [SP]
    // 0x1278e78: mov             x0, x4
    // 0x1278e7c: mov             lr, x0
    // 0x1278e80: ldr             lr, [x21, lr, lsl #3]
    // 0x1278e84: blr             lr
    // 0x1278e88: tbnz            w0, #4, #0x12790e8
    // 0x1278e8c: ldr             x0, [fp, #0x18]
    // 0x1278e90: ldr             x1, [fp, #0x10]
    // 0x1278e94: LoadField: r2 = r1->field_43
    //     0x1278e94: ldur            w2, [x1, #0x43]
    // 0x1278e98: DecompressPointer r2
    //     0x1278e98: add             x2, x2, HEAP, lsl #32
    // 0x1278e9c: LoadField: r3 = r0->field_43
    //     0x1278e9c: ldur            w3, [x0, #0x43]
    // 0x1278ea0: DecompressPointer r3
    //     0x1278ea0: add             x3, x3, HEAP, lsl #32
    // 0x1278ea4: cmp             w2, w3
    // 0x1278ea8: b.ne            #0x12790e8
    // 0x1278eac: LoadField: r2 = r1->field_47
    //     0x1278eac: ldur            w2, [x1, #0x47]
    // 0x1278eb0: DecompressPointer r2
    //     0x1278eb0: add             x2, x2, HEAP, lsl #32
    // 0x1278eb4: LoadField: r3 = r0->field_47
    //     0x1278eb4: ldur            w3, [x0, #0x47]
    // 0x1278eb8: DecompressPointer r3
    //     0x1278eb8: add             x3, x3, HEAP, lsl #32
    // 0x1278ebc: cmp             w2, w3
    // 0x1278ec0: b.ne            #0x12790e8
    // 0x1278ec4: LoadField: r2 = r1->field_5f
    //     0x1278ec4: ldur            w2, [x1, #0x5f]
    // 0x1278ec8: DecompressPointer r2
    //     0x1278ec8: add             x2, x2, HEAP, lsl #32
    // 0x1278ecc: LoadField: r3 = r0->field_5f
    //     0x1278ecc: ldur            w3, [x0, #0x5f]
    // 0x1278ed0: DecompressPointer r3
    //     0x1278ed0: add             x3, x3, HEAP, lsl #32
    // 0x1278ed4: r16 = <Shadow>
    //     0x1278ed4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe250] TypeArguments: <Shadow>
    //     0x1278ed8: ldr             x16, [x16, #0x250]
    // 0x1278edc: stp             x2, x16, [SP, #8]
    // 0x1278ee0: str             x3, [SP]
    // 0x1278ee4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1278ee4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1278ee8: r0 = listEquals()
    //     0x1278ee8: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1278eec: tbnz            w0, #4, #0x12790e8
    // 0x1278ef0: ldr             x0, [fp, #0x18]
    // 0x1278ef4: ldr             x1, [fp, #0x10]
    // 0x1278ef8: LoadField: r2 = r1->field_63
    //     0x1278ef8: ldur            w2, [x1, #0x63]
    // 0x1278efc: DecompressPointer r2
    //     0x1278efc: add             x2, x2, HEAP, lsl #32
    // 0x1278f00: LoadField: r3 = r0->field_63
    //     0x1278f00: ldur            w3, [x0, #0x63]
    // 0x1278f04: DecompressPointer r3
    //     0x1278f04: add             x3, x3, HEAP, lsl #32
    // 0x1278f08: r16 = <FontFeature>
    //     0x1278f08: add             x16, PP, #0xe, lsl #12  ; [pp+0xe258] TypeArguments: <FontFeature>
    //     0x1278f0c: ldr             x16, [x16, #0x258]
    // 0x1278f10: stp             x2, x16, [SP, #8]
    // 0x1278f14: str             x3, [SP]
    // 0x1278f18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1278f18: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1278f1c: r0 = listEquals()
    //     0x1278f1c: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1278f20: tbnz            w0, #4, #0x12790e8
    // 0x1278f24: ldr             x0, [fp, #0x18]
    // 0x1278f28: ldr             x1, [fp, #0x10]
    // 0x1278f2c: LoadField: r2 = r1->field_67
    //     0x1278f2c: ldur            w2, [x1, #0x67]
    // 0x1278f30: DecompressPointer r2
    //     0x1278f30: add             x2, x2, HEAP, lsl #32
    // 0x1278f34: LoadField: r3 = r0->field_67
    //     0x1278f34: ldur            w3, [x0, #0x67]
    // 0x1278f38: DecompressPointer r3
    //     0x1278f38: add             x3, x3, HEAP, lsl #32
    // 0x1278f3c: r16 = <FontVariation>
    //     0x1278f3c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe260] TypeArguments: <FontVariation>
    //     0x1278f40: ldr             x16, [x16, #0x260]
    // 0x1278f44: stp             x2, x16, [SP, #8]
    // 0x1278f48: str             x3, [SP]
    // 0x1278f4c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1278f4c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1278f50: r0 = listEquals()
    //     0x1278f50: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1278f54: tbnz            w0, #4, #0x12790e8
    // 0x1278f58: ldr             x2, [fp, #0x18]
    // 0x1278f5c: ldr             x1, [fp, #0x10]
    // 0x1278f60: LoadField: r0 = r1->field_4b
    //     0x1278f60: ldur            w0, [x1, #0x4b]
    // 0x1278f64: DecompressPointer r0
    //     0x1278f64: add             x0, x0, HEAP, lsl #32
    // 0x1278f68: LoadField: r3 = r2->field_4b
    //     0x1278f68: ldur            w3, [x2, #0x4b]
    // 0x1278f6c: DecompressPointer r3
    //     0x1278f6c: add             x3, x3, HEAP, lsl #32
    // 0x1278f70: r4 = LoadClassIdInstr(r0)
    //     0x1278f70: ldur            x4, [x0, #-1]
    //     0x1278f74: ubfx            x4, x4, #0xc, #0x14
    // 0x1278f78: stp             x3, x0, [SP]
    // 0x1278f7c: mov             x0, x4
    // 0x1278f80: mov             lr, x0
    // 0x1278f84: ldr             lr, [x21, lr, lsl #3]
    // 0x1278f88: blr             lr
    // 0x1278f8c: tbnz            w0, #4, #0x12790e8
    // 0x1278f90: ldr             x2, [fp, #0x18]
    // 0x1278f94: ldr             x1, [fp, #0x10]
    // 0x1278f98: LoadField: r0 = r1->field_4f
    //     0x1278f98: ldur            w0, [x1, #0x4f]
    // 0x1278f9c: DecompressPointer r0
    //     0x1278f9c: add             x0, x0, HEAP, lsl #32
    // 0x1278fa0: LoadField: r3 = r2->field_4f
    //     0x1278fa0: ldur            w3, [x2, #0x4f]
    // 0x1278fa4: DecompressPointer r3
    //     0x1278fa4: add             x3, x3, HEAP, lsl #32
    // 0x1278fa8: r4 = LoadClassIdInstr(r0)
    //     0x1278fa8: ldur            x4, [x0, #-1]
    //     0x1278fac: ubfx            x4, x4, #0xc, #0x14
    // 0x1278fb0: stp             x3, x0, [SP]
    // 0x1278fb4: mov             x0, x4
    // 0x1278fb8: mov             lr, x0
    // 0x1278fbc: ldr             lr, [x21, lr, lsl #3]
    // 0x1278fc0: blr             lr
    // 0x1278fc4: tbnz            w0, #4, #0x12790e8
    // 0x1278fc8: ldr             x2, [fp, #0x18]
    // 0x1278fcc: ldr             x1, [fp, #0x10]
    // 0x1278fd0: LoadField: r0 = r1->field_53
    //     0x1278fd0: ldur            w0, [x1, #0x53]
    // 0x1278fd4: DecompressPointer r0
    //     0x1278fd4: add             x0, x0, HEAP, lsl #32
    // 0x1278fd8: LoadField: r3 = r2->field_53
    //     0x1278fd8: ldur            w3, [x2, #0x53]
    // 0x1278fdc: DecompressPointer r3
    //     0x1278fdc: add             x3, x3, HEAP, lsl #32
    // 0x1278fe0: cmp             w0, w3
    // 0x1278fe4: b.ne            #0x12790e8
    // 0x1278fe8: LoadField: r0 = r1->field_57
    //     0x1278fe8: ldur            w0, [x1, #0x57]
    // 0x1278fec: DecompressPointer r0
    //     0x1278fec: add             x0, x0, HEAP, lsl #32
    // 0x1278ff0: LoadField: r3 = r2->field_57
    //     0x1278ff0: ldur            w3, [x2, #0x57]
    // 0x1278ff4: DecompressPointer r3
    //     0x1278ff4: add             x3, x3, HEAP, lsl #32
    // 0x1278ff8: r4 = LoadClassIdInstr(r0)
    //     0x1278ff8: ldur            x4, [x0, #-1]
    //     0x1278ffc: ubfx            x4, x4, #0xc, #0x14
    // 0x1279000: stp             x3, x0, [SP]
    // 0x1279004: mov             x0, x4
    // 0x1279008: mov             lr, x0
    // 0x127900c: ldr             lr, [x21, lr, lsl #3]
    // 0x1279010: blr             lr
    // 0x1279014: tbnz            w0, #4, #0x12790e8
    // 0x1279018: ldr             x2, [fp, #0x18]
    // 0x127901c: ldr             x1, [fp, #0x10]
    // 0x1279020: LoadField: r0 = r1->field_13
    //     0x1279020: ldur            w0, [x1, #0x13]
    // 0x1279024: DecompressPointer r0
    //     0x1279024: add             x0, x0, HEAP, lsl #32
    // 0x1279028: LoadField: r3 = r2->field_13
    //     0x1279028: ldur            w3, [x2, #0x13]
    // 0x127902c: DecompressPointer r3
    //     0x127902c: add             x3, x3, HEAP, lsl #32
    // 0x1279030: r4 = LoadClassIdInstr(r0)
    //     0x1279030: ldur            x4, [x0, #-1]
    //     0x1279034: ubfx            x4, x4, #0xc, #0x14
    // 0x1279038: stp             x3, x0, [SP]
    // 0x127903c: mov             x0, x4
    // 0x1279040: mov             lr, x0
    // 0x1279044: ldr             lr, [x21, lr, lsl #3]
    // 0x1279048: blr             lr
    // 0x127904c: tbnz            w0, #4, #0x12790e8
    // 0x1279050: ldr             x1, [fp, #0x10]
    // 0x1279054: r0 = fontFamilyFallback()
    //     0x1279054: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x1279058: ldr             x1, [fp, #0x18]
    // 0x127905c: stur            x0, [fp, #-8]
    // 0x1279060: r0 = fontFamilyFallback()
    //     0x1279060: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x1279064: r16 = <String>
    //     0x1279064: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x1279068: ldur            lr, [fp, #-8]
    // 0x127906c: stp             lr, x16, [SP, #8]
    // 0x1279070: str             x0, [SP]
    // 0x1279074: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1279074: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1279078: r0 = listEquals()
    //     0x1279078: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x127907c: tbnz            w0, #4, #0x12790e8
    // 0x1279080: ldr             x2, [fp, #0x18]
    // 0x1279084: ldr             x1, [fp, #0x10]
    // 0x1279088: LoadField: r0 = r1->field_1b
    //     0x1279088: ldur            w0, [x1, #0x1b]
    // 0x127908c: DecompressPointer r0
    //     0x127908c: add             x0, x0, HEAP, lsl #32
    // 0x1279090: LoadField: r3 = r2->field_1b
    //     0x1279090: ldur            w3, [x2, #0x1b]
    // 0x1279094: DecompressPointer r3
    //     0x1279094: add             x3, x3, HEAP, lsl #32
    // 0x1279098: r4 = LoadClassIdInstr(r0)
    //     0x1279098: ldur            x4, [x0, #-1]
    //     0x127909c: ubfx            x4, x4, #0xc, #0x14
    // 0x12790a0: stp             x3, x0, [SP]
    // 0x12790a4: mov             x0, x4
    // 0x12790a8: mov             lr, x0
    // 0x12790ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12790b0: blr             lr
    // 0x12790b4: tbnz            w0, #4, #0x12790e8
    // 0x12790b8: ldr             x2, [fp, #0x18]
    // 0x12790bc: ldr             x1, [fp, #0x10]
    // 0x12790c0: LoadField: r3 = r1->field_6b
    //     0x12790c0: ldur            w3, [x1, #0x6b]
    // 0x12790c4: DecompressPointer r3
    //     0x12790c4: add             x3, x3, HEAP, lsl #32
    // 0x12790c8: LoadField: r1 = r2->field_6b
    //     0x12790c8: ldur            w1, [x2, #0x6b]
    // 0x12790cc: DecompressPointer r1
    //     0x12790cc: add             x1, x1, HEAP, lsl #32
    // 0x12790d0: cmp             w3, w1
    // 0x12790d4: r16 = true
    //     0x12790d4: add             x16, NULL, #0x20  ; true
    // 0x12790d8: r17 = false
    //     0x12790d8: add             x17, NULL, #0x30  ; false
    // 0x12790dc: csel            x2, x16, x17, eq
    // 0x12790e0: mov             x0, x2
    // 0x12790e4: b               #0x12790ec
    // 0x12790e8: r0 = false
    //     0x12790e8: add             x0, NULL, #0x30  ; false
    // 0x12790ec: LeaveFrame
    //     0x12790ec: mov             SP, fp
    //     0x12790f0: ldp             fp, lr, [SP], #0x10
    // 0x12790f4: ret
    //     0x12790f4: ret             
    // 0x12790f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12790f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12790fc: b               #0x1278bf8
  }
  _ compareTo(/* No info */) {
    // ** addr: 0x1287370, size: 0x4ac
    // 0x1287370: EnterFrame
    //     0x1287370: stp             fp, lr, [SP, #-0x10]!
    //     0x1287374: mov             fp, SP
    // 0x1287378: AllocStack(0x30)
    //     0x1287378: sub             SP, SP, #0x30
    // 0x128737c: SetupParameters(TextStyle this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x128737c: stur            x1, [fp, #-8]
    //     0x1287380: mov             x16, x2
    //     0x1287384: mov             x2, x1
    //     0x1287388: mov             x1, x16
    //     0x128738c: stur            x1, [fp, #-0x10]
    // 0x1287390: CheckStackOverflow
    //     0x1287390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1287394: cmp             SP, x16
    //     0x1287398: b.ls            #0x1287814
    // 0x128739c: cmp             w2, w1
    // 0x12873a0: b.ne            #0x12873b8
    // 0x12873a4: r0 = Instance_RenderComparison
    //     0x12873a4: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a60] Obj!RenderComparison@12c4ae1
    //     0x12873a8: ldr             x0, [x0, #0xa60]
    // 0x12873ac: LeaveFrame
    //     0x12873ac: mov             SP, fp
    //     0x12873b0: ldp             fp, lr, [SP], #0x10
    // 0x12873b4: ret
    //     0x12873b4: ret             
    // 0x12873b8: LoadField: r0 = r2->field_7
    //     0x12873b8: ldur            w0, [x2, #7]
    // 0x12873bc: DecompressPointer r0
    //     0x12873bc: add             x0, x0, HEAP, lsl #32
    // 0x12873c0: LoadField: r3 = r1->field_7
    //     0x12873c0: ldur            w3, [x1, #7]
    // 0x12873c4: DecompressPointer r3
    //     0x12873c4: add             x3, x3, HEAP, lsl #32
    // 0x12873c8: cmp             w0, w3
    // 0x12873cc: b.ne            #0x12876b4
    // 0x12873d0: LoadField: r0 = r2->field_13
    //     0x12873d0: ldur            w0, [x2, #0x13]
    // 0x12873d4: DecompressPointer r0
    //     0x12873d4: add             x0, x0, HEAP, lsl #32
    // 0x12873d8: LoadField: r3 = r1->field_13
    //     0x12873d8: ldur            w3, [x1, #0x13]
    // 0x12873dc: DecompressPointer r3
    //     0x12873dc: add             x3, x3, HEAP, lsl #32
    // 0x12873e0: r4 = LoadClassIdInstr(r0)
    //     0x12873e0: ldur            x4, [x0, #-1]
    //     0x12873e4: ubfx            x4, x4, #0xc, #0x14
    // 0x12873e8: stp             x3, x0, [SP]
    // 0x12873ec: mov             x0, x4
    // 0x12873f0: mov             lr, x0
    // 0x12873f4: ldr             lr, [x21, lr, lsl #3]
    // 0x12873f8: blr             lr
    // 0x12873fc: tbnz            w0, #4, #0x12876b4
    // 0x1287400: ldur            x2, [fp, #-8]
    // 0x1287404: ldur            x1, [fp, #-0x10]
    // 0x1287408: LoadField: r0 = r2->field_1f
    //     0x1287408: ldur            w0, [x2, #0x1f]
    // 0x128740c: DecompressPointer r0
    //     0x128740c: add             x0, x0, HEAP, lsl #32
    // 0x1287410: LoadField: r3 = r1->field_1f
    //     0x1287410: ldur            w3, [x1, #0x1f]
    // 0x1287414: DecompressPointer r3
    //     0x1287414: add             x3, x3, HEAP, lsl #32
    // 0x1287418: r4 = LoadClassIdInstr(r0)
    //     0x1287418: ldur            x4, [x0, #-1]
    //     0x128741c: ubfx            x4, x4, #0xc, #0x14
    // 0x1287420: stp             x3, x0, [SP]
    // 0x1287424: mov             x0, x4
    // 0x1287428: mov             lr, x0
    // 0x128742c: ldr             lr, [x21, lr, lsl #3]
    // 0x1287430: blr             lr
    // 0x1287434: tbnz            w0, #4, #0x12876b4
    // 0x1287438: ldur            x2, [fp, #-8]
    // 0x128743c: ldur            x1, [fp, #-0x10]
    // 0x1287440: LoadField: r0 = r2->field_23
    //     0x1287440: ldur            w0, [x2, #0x23]
    // 0x1287444: DecompressPointer r0
    //     0x1287444: add             x0, x0, HEAP, lsl #32
    // 0x1287448: LoadField: r3 = r1->field_23
    //     0x1287448: ldur            w3, [x1, #0x23]
    // 0x128744c: DecompressPointer r3
    //     0x128744c: add             x3, x3, HEAP, lsl #32
    // 0x1287450: r4 = LoadClassIdInstr(r0)
    //     0x1287450: ldur            x4, [x0, #-1]
    //     0x1287454: ubfx            x4, x4, #0xc, #0x14
    // 0x1287458: stp             x3, x0, [SP]
    // 0x128745c: mov             x0, x4
    // 0x1287460: mov             lr, x0
    // 0x1287464: ldr             lr, [x21, lr, lsl #3]
    // 0x1287468: blr             lr
    // 0x128746c: tbnz            w0, #4, #0x12876b4
    // 0x1287470: ldur            x2, [fp, #-8]
    // 0x1287474: ldur            x1, [fp, #-0x10]
    // 0x1287478: LoadField: r0 = r2->field_27
    //     0x1287478: ldur            w0, [x2, #0x27]
    // 0x128747c: DecompressPointer r0
    //     0x128747c: add             x0, x0, HEAP, lsl #32
    // 0x1287480: LoadField: r3 = r1->field_27
    //     0x1287480: ldur            w3, [x1, #0x27]
    // 0x1287484: DecompressPointer r3
    //     0x1287484: add             x3, x3, HEAP, lsl #32
    // 0x1287488: cmp             w0, w3
    // 0x128748c: b.ne            #0x12876b4
    // 0x1287490: LoadField: r0 = r2->field_2b
    //     0x1287490: ldur            w0, [x2, #0x2b]
    // 0x1287494: DecompressPointer r0
    //     0x1287494: add             x0, x0, HEAP, lsl #32
    // 0x1287498: LoadField: r3 = r1->field_2b
    //     0x1287498: ldur            w3, [x1, #0x2b]
    // 0x128749c: DecompressPointer r3
    //     0x128749c: add             x3, x3, HEAP, lsl #32
    // 0x12874a0: r4 = LoadClassIdInstr(r0)
    //     0x12874a0: ldur            x4, [x0, #-1]
    //     0x12874a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12874a8: stp             x3, x0, [SP]
    // 0x12874ac: mov             x0, x4
    // 0x12874b0: mov             lr, x0
    // 0x12874b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12874b8: blr             lr
    // 0x12874bc: tbnz            w0, #4, #0x12876b4
    // 0x12874c0: ldur            x2, [fp, #-8]
    // 0x12874c4: ldur            x1, [fp, #-0x10]
    // 0x12874c8: LoadField: r0 = r2->field_2f
    //     0x12874c8: ldur            w0, [x2, #0x2f]
    // 0x12874cc: DecompressPointer r0
    //     0x12874cc: add             x0, x0, HEAP, lsl #32
    // 0x12874d0: LoadField: r3 = r1->field_2f
    //     0x12874d0: ldur            w3, [x1, #0x2f]
    // 0x12874d4: DecompressPointer r3
    //     0x12874d4: add             x3, x3, HEAP, lsl #32
    // 0x12874d8: r4 = LoadClassIdInstr(r0)
    //     0x12874d8: ldur            x4, [x0, #-1]
    //     0x12874dc: ubfx            x4, x4, #0xc, #0x14
    // 0x12874e0: stp             x3, x0, [SP]
    // 0x12874e4: mov             x0, x4
    // 0x12874e8: mov             lr, x0
    // 0x12874ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12874f0: blr             lr
    // 0x12874f4: tbnz            w0, #4, #0x12876b4
    // 0x12874f8: ldur            x2, [fp, #-8]
    // 0x12874fc: ldur            x1, [fp, #-0x10]
    // 0x1287500: LoadField: r0 = r2->field_33
    //     0x1287500: ldur            w0, [x2, #0x33]
    // 0x1287504: DecompressPointer r0
    //     0x1287504: add             x0, x0, HEAP, lsl #32
    // 0x1287508: LoadField: r3 = r1->field_33
    //     0x1287508: ldur            w3, [x1, #0x33]
    // 0x128750c: DecompressPointer r3
    //     0x128750c: add             x3, x3, HEAP, lsl #32
    // 0x1287510: cmp             w0, w3
    // 0x1287514: b.ne            #0x12876b4
    // 0x1287518: LoadField: r0 = r2->field_37
    //     0x1287518: ldur            w0, [x2, #0x37]
    // 0x128751c: DecompressPointer r0
    //     0x128751c: add             x0, x0, HEAP, lsl #32
    // 0x1287520: LoadField: r3 = r1->field_37
    //     0x1287520: ldur            w3, [x1, #0x37]
    // 0x1287524: DecompressPointer r3
    //     0x1287524: add             x3, x3, HEAP, lsl #32
    // 0x1287528: r4 = LoadClassIdInstr(r0)
    //     0x1287528: ldur            x4, [x0, #-1]
    //     0x128752c: ubfx            x4, x4, #0xc, #0x14
    // 0x1287530: stp             x3, x0, [SP]
    // 0x1287534: mov             x0, x4
    // 0x1287538: mov             lr, x0
    // 0x128753c: ldr             lr, [x21, lr, lsl #3]
    // 0x1287540: blr             lr
    // 0x1287544: tbnz            w0, #4, #0x12876b4
    // 0x1287548: ldur            x2, [fp, #-8]
    // 0x128754c: ldur            x1, [fp, #-0x10]
    // 0x1287550: LoadField: r0 = r2->field_3b
    //     0x1287550: ldur            w0, [x2, #0x3b]
    // 0x1287554: DecompressPointer r0
    //     0x1287554: add             x0, x0, HEAP, lsl #32
    // 0x1287558: LoadField: r3 = r1->field_3b
    //     0x1287558: ldur            w3, [x1, #0x3b]
    // 0x128755c: DecompressPointer r3
    //     0x128755c: add             x3, x3, HEAP, lsl #32
    // 0x1287560: cmp             w0, w3
    // 0x1287564: b.ne            #0x12876b4
    // 0x1287568: LoadField: r0 = r2->field_3f
    //     0x1287568: ldur            w0, [x2, #0x3f]
    // 0x128756c: DecompressPointer r0
    //     0x128756c: add             x0, x0, HEAP, lsl #32
    // 0x1287570: LoadField: r3 = r1->field_3f
    //     0x1287570: ldur            w3, [x1, #0x3f]
    // 0x1287574: DecompressPointer r3
    //     0x1287574: add             x3, x3, HEAP, lsl #32
    // 0x1287578: r4 = LoadClassIdInstr(r0)
    //     0x1287578: ldur            x4, [x0, #-1]
    //     0x128757c: ubfx            x4, x4, #0xc, #0x14
    // 0x1287580: stp             x3, x0, [SP]
    // 0x1287584: mov             x0, x4
    // 0x1287588: mov             lr, x0
    // 0x128758c: ldr             lr, [x21, lr, lsl #3]
    // 0x1287590: blr             lr
    // 0x1287594: tbnz            w0, #4, #0x12876b4
    // 0x1287598: ldur            x0, [fp, #-8]
    // 0x128759c: ldur            x1, [fp, #-0x10]
    // 0x12875a0: LoadField: r2 = r0->field_43
    //     0x12875a0: ldur            w2, [x0, #0x43]
    // 0x12875a4: DecompressPointer r2
    //     0x12875a4: add             x2, x2, HEAP, lsl #32
    // 0x12875a8: LoadField: r3 = r1->field_43
    //     0x12875a8: ldur            w3, [x1, #0x43]
    // 0x12875ac: DecompressPointer r3
    //     0x12875ac: add             x3, x3, HEAP, lsl #32
    // 0x12875b0: cmp             w2, w3
    // 0x12875b4: b.ne            #0x12876b4
    // 0x12875b8: LoadField: r2 = r0->field_47
    //     0x12875b8: ldur            w2, [x0, #0x47]
    // 0x12875bc: DecompressPointer r2
    //     0x12875bc: add             x2, x2, HEAP, lsl #32
    // 0x12875c0: LoadField: r3 = r1->field_47
    //     0x12875c0: ldur            w3, [x1, #0x47]
    // 0x12875c4: DecompressPointer r3
    //     0x12875c4: add             x3, x3, HEAP, lsl #32
    // 0x12875c8: cmp             w2, w3
    // 0x12875cc: b.ne            #0x12876b4
    // 0x12875d0: LoadField: r2 = r0->field_5f
    //     0x12875d0: ldur            w2, [x0, #0x5f]
    // 0x12875d4: DecompressPointer r2
    //     0x12875d4: add             x2, x2, HEAP, lsl #32
    // 0x12875d8: LoadField: r3 = r1->field_5f
    //     0x12875d8: ldur            w3, [x1, #0x5f]
    // 0x12875dc: DecompressPointer r3
    //     0x12875dc: add             x3, x3, HEAP, lsl #32
    // 0x12875e0: r16 = <Shadow>
    //     0x12875e0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe250] TypeArguments: <Shadow>
    //     0x12875e4: ldr             x16, [x16, #0x250]
    // 0x12875e8: stp             x2, x16, [SP, #8]
    // 0x12875ec: str             x3, [SP]
    // 0x12875f0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12875f0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12875f4: r0 = listEquals()
    //     0x12875f4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12875f8: tbnz            w0, #4, #0x12876b4
    // 0x12875fc: ldur            x0, [fp, #-8]
    // 0x1287600: ldur            x1, [fp, #-0x10]
    // 0x1287604: LoadField: r2 = r0->field_63
    //     0x1287604: ldur            w2, [x0, #0x63]
    // 0x1287608: DecompressPointer r2
    //     0x1287608: add             x2, x2, HEAP, lsl #32
    // 0x128760c: LoadField: r3 = r1->field_63
    //     0x128760c: ldur            w3, [x1, #0x63]
    // 0x1287610: DecompressPointer r3
    //     0x1287610: add             x3, x3, HEAP, lsl #32
    // 0x1287614: r16 = <FontFeature>
    //     0x1287614: add             x16, PP, #0xe, lsl #12  ; [pp+0xe258] TypeArguments: <FontFeature>
    //     0x1287618: ldr             x16, [x16, #0x258]
    // 0x128761c: stp             x2, x16, [SP, #8]
    // 0x1287620: str             x3, [SP]
    // 0x1287624: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1287624: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1287628: r0 = listEquals()
    //     0x1287628: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x128762c: tbnz            w0, #4, #0x12876b4
    // 0x1287630: ldur            x0, [fp, #-8]
    // 0x1287634: ldur            x1, [fp, #-0x10]
    // 0x1287638: LoadField: r2 = r0->field_67
    //     0x1287638: ldur            w2, [x0, #0x67]
    // 0x128763c: DecompressPointer r2
    //     0x128763c: add             x2, x2, HEAP, lsl #32
    // 0x1287640: LoadField: r3 = r1->field_67
    //     0x1287640: ldur            w3, [x1, #0x67]
    // 0x1287644: DecompressPointer r3
    //     0x1287644: add             x3, x3, HEAP, lsl #32
    // 0x1287648: r16 = <FontVariation>
    //     0x1287648: add             x16, PP, #0xe, lsl #12  ; [pp+0xe260] TypeArguments: <FontVariation>
    //     0x128764c: ldr             x16, [x16, #0x260]
    // 0x1287650: stp             x2, x16, [SP, #8]
    // 0x1287654: str             x3, [SP]
    // 0x1287658: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1287658: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x128765c: r0 = listEquals()
    //     0x128765c: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1287660: tbnz            w0, #4, #0x12876b4
    // 0x1287664: ldur            x1, [fp, #-8]
    // 0x1287668: r0 = fontFamilyFallback()
    //     0x1287668: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x128766c: ldur            x1, [fp, #-0x10]
    // 0x1287670: stur            x0, [fp, #-0x18]
    // 0x1287674: r0 = fontFamilyFallback()
    //     0x1287674: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0x1287678: r16 = <String>
    //     0x1287678: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x128767c: ldur            lr, [fp, #-0x18]
    // 0x1287680: stp             lr, x16, [SP, #8]
    // 0x1287684: str             x0, [SP]
    // 0x1287688: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1287688: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x128768c: r0 = listEquals()
    //     0x128768c: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1287690: tbnz            w0, #4, #0x12876b4
    // 0x1287694: ldur            x2, [fp, #-8]
    // 0x1287698: ldur            x1, [fp, #-0x10]
    // 0x128769c: LoadField: r0 = r2->field_6b
    //     0x128769c: ldur            w0, [x2, #0x6b]
    // 0x12876a0: DecompressPointer r0
    //     0x12876a0: add             x0, x0, HEAP, lsl #32
    // 0x12876a4: LoadField: r3 = r1->field_6b
    //     0x12876a4: ldur            w3, [x1, #0x6b]
    // 0x12876a8: DecompressPointer r3
    //     0x12876a8: add             x3, x3, HEAP, lsl #32
    // 0x12876ac: cmp             w0, w3
    // 0x12876b0: b.eq            #0x12876c8
    // 0x12876b4: r0 = Instance_RenderComparison
    //     0x12876b4: add             x0, PP, #0x90, lsl #12  ; [pp+0x90338] Obj!RenderComparison@12c4aa1
    //     0x12876b8: ldr             x0, [x0, #0x338]
    // 0x12876bc: LeaveFrame
    //     0x12876bc: mov             SP, fp
    //     0x12876c0: ldp             fp, lr, [SP], #0x10
    // 0x12876c4: ret
    //     0x12876c4: ret             
    // 0x12876c8: LoadField: r0 = r2->field_b
    //     0x12876c8: ldur            w0, [x2, #0xb]
    // 0x12876cc: DecompressPointer r0
    //     0x12876cc: add             x0, x0, HEAP, lsl #32
    // 0x12876d0: LoadField: r3 = r1->field_b
    //     0x12876d0: ldur            w3, [x1, #0xb]
    // 0x12876d4: DecompressPointer r3
    //     0x12876d4: add             x3, x3, HEAP, lsl #32
    // 0x12876d8: r4 = LoadClassIdInstr(r0)
    //     0x12876d8: ldur            x4, [x0, #-1]
    //     0x12876dc: ubfx            x4, x4, #0xc, #0x14
    // 0x12876e0: stp             x3, x0, [SP]
    // 0x12876e4: mov             x0, x4
    // 0x12876e8: mov             lr, x0
    // 0x12876ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12876f0: blr             lr
    // 0x12876f4: tbnz            w0, #4, #0x12877ec
    // 0x12876f8: ldur            x2, [fp, #-8]
    // 0x12876fc: ldur            x1, [fp, #-0x10]
    // 0x1287700: LoadField: r0 = r2->field_f
    //     0x1287700: ldur            w0, [x2, #0xf]
    // 0x1287704: DecompressPointer r0
    //     0x1287704: add             x0, x0, HEAP, lsl #32
    // 0x1287708: LoadField: r3 = r1->field_f
    //     0x1287708: ldur            w3, [x1, #0xf]
    // 0x128770c: DecompressPointer r3
    //     0x128770c: add             x3, x3, HEAP, lsl #32
    // 0x1287710: r4 = LoadClassIdInstr(r0)
    //     0x1287710: ldur            x4, [x0, #-1]
    //     0x1287714: ubfx            x4, x4, #0xc, #0x14
    // 0x1287718: stp             x3, x0, [SP]
    // 0x128771c: mov             x0, x4
    // 0x1287720: mov             lr, x0
    // 0x1287724: ldr             lr, [x21, lr, lsl #3]
    // 0x1287728: blr             lr
    // 0x128772c: tbnz            w0, #4, #0x12877ec
    // 0x1287730: ldur            x2, [fp, #-8]
    // 0x1287734: ldur            x1, [fp, #-0x10]
    // 0x1287738: LoadField: r0 = r2->field_4b
    //     0x1287738: ldur            w0, [x2, #0x4b]
    // 0x128773c: DecompressPointer r0
    //     0x128773c: add             x0, x0, HEAP, lsl #32
    // 0x1287740: LoadField: r3 = r1->field_4b
    //     0x1287740: ldur            w3, [x1, #0x4b]
    // 0x1287744: DecompressPointer r3
    //     0x1287744: add             x3, x3, HEAP, lsl #32
    // 0x1287748: r4 = LoadClassIdInstr(r0)
    //     0x1287748: ldur            x4, [x0, #-1]
    //     0x128774c: ubfx            x4, x4, #0xc, #0x14
    // 0x1287750: stp             x3, x0, [SP]
    // 0x1287754: mov             x0, x4
    // 0x1287758: mov             lr, x0
    // 0x128775c: ldr             lr, [x21, lr, lsl #3]
    // 0x1287760: blr             lr
    // 0x1287764: tbnz            w0, #4, #0x12877ec
    // 0x1287768: ldur            x2, [fp, #-8]
    // 0x128776c: ldur            x1, [fp, #-0x10]
    // 0x1287770: LoadField: r0 = r2->field_4f
    //     0x1287770: ldur            w0, [x2, #0x4f]
    // 0x1287774: DecompressPointer r0
    //     0x1287774: add             x0, x0, HEAP, lsl #32
    // 0x1287778: LoadField: r3 = r1->field_4f
    //     0x1287778: ldur            w3, [x1, #0x4f]
    // 0x128777c: DecompressPointer r3
    //     0x128777c: add             x3, x3, HEAP, lsl #32
    // 0x1287780: r4 = LoadClassIdInstr(r0)
    //     0x1287780: ldur            x4, [x0, #-1]
    //     0x1287784: ubfx            x4, x4, #0xc, #0x14
    // 0x1287788: stp             x3, x0, [SP]
    // 0x128778c: mov             x0, x4
    // 0x1287790: mov             lr, x0
    // 0x1287794: ldr             lr, [x21, lr, lsl #3]
    // 0x1287798: blr             lr
    // 0x128779c: tbnz            w0, #4, #0x12877ec
    // 0x12877a0: ldur            x1, [fp, #-8]
    // 0x12877a4: ldur            x0, [fp, #-0x10]
    // 0x12877a8: LoadField: r2 = r1->field_53
    //     0x12877a8: ldur            w2, [x1, #0x53]
    // 0x12877ac: DecompressPointer r2
    //     0x12877ac: add             x2, x2, HEAP, lsl #32
    // 0x12877b0: LoadField: r3 = r0->field_53
    //     0x12877b0: ldur            w3, [x0, #0x53]
    // 0x12877b4: DecompressPointer r3
    //     0x12877b4: add             x3, x3, HEAP, lsl #32
    // 0x12877b8: cmp             w2, w3
    // 0x12877bc: b.ne            #0x12877ec
    // 0x12877c0: LoadField: r2 = r1->field_57
    //     0x12877c0: ldur            w2, [x1, #0x57]
    // 0x12877c4: DecompressPointer r2
    //     0x12877c4: add             x2, x2, HEAP, lsl #32
    // 0x12877c8: LoadField: r1 = r0->field_57
    //     0x12877c8: ldur            w1, [x0, #0x57]
    // 0x12877cc: DecompressPointer r1
    //     0x12877cc: add             x1, x1, HEAP, lsl #32
    // 0x12877d0: r0 = LoadClassIdInstr(r2)
    //     0x12877d0: ldur            x0, [x2, #-1]
    //     0x12877d4: ubfx            x0, x0, #0xc, #0x14
    // 0x12877d8: stp             x1, x2, [SP]
    // 0x12877dc: mov             lr, x0
    // 0x12877e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12877e4: blr             lr
    // 0x12877e8: tbz             w0, #4, #0x1287800
    // 0x12877ec: r0 = Instance_RenderComparison
    //     0x12877ec: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a80] Obj!RenderComparison@12c4ac1
    //     0x12877f0: ldr             x0, [x0, #0xa80]
    // 0x12877f4: LeaveFrame
    //     0x12877f4: mov             SP, fp
    //     0x12877f8: ldp             fp, lr, [SP], #0x10
    // 0x12877fc: ret
    //     0x12877fc: ret             
    // 0x1287800: r0 = Instance_RenderComparison
    //     0x1287800: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a60] Obj!RenderComparison@12c4ae1
    //     0x1287804: ldr             x0, [x0, #0xa60]
    // 0x1287808: LeaveFrame
    //     0x1287808: mov             SP, fp
    //     0x128780c: ldp             fp, lr, [SP], #0x10
    // 0x1287810: ret
    //     0x1287810: ret             
    // 0x1287814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1287814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1287818: b               #0x128739c
  }
}
