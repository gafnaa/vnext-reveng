// lib: , url: package:flutter/src/painting/circle_border.dart

// class id: 1048987, size: 0x8
class :: {
}

// class id: 3026, size: 0x14, field offset: 0xc
//   const constructor, 
class CircleBorder extends OutlinedBorder {

  BorderSide field_8;
  _Mint field_c;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfe098, size: 0x110
    // 0xbfe098: EnterFrame
    //     0xbfe098: stp             fp, lr, [SP, #-0x10]!
    //     0xbfe09c: mov             fp, SP
    // 0xbfe0a0: AllocStack(0x48)
    //     0xbfe0a0: sub             SP, SP, #0x48
    // 0xbfe0a4: SetupParameters(CircleBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbfe0a4: stur            x1, [fp, #-8]
    //     0xbfe0a8: stur            x2, [fp, #-0x10]
    // 0xbfe0ac: CheckStackOverflow
    //     0xbfe0ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfe0b0: cmp             SP, x16
    //     0xbfe0b4: b.ls            #0xbfe19c
    // 0xbfe0b8: r0 = _NativePath()
    //     0xbfe0b8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfe0bc: mov             x1, x0
    // 0xbfe0c0: stur            x0, [fp, #-0x18]
    // 0xbfe0c4: r0 = __constructor$Method$FfiNative()
    //     0xbfe0c4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfe0c8: ldur            x1, [fp, #-8]
    // 0xbfe0cc: ldur            x2, [fp, #-0x10]
    // 0xbfe0d0: r0 = _adjustRect()
    //     0xbfe0d0: bl              #0xbfe1a8  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0xbfe0d4: mov             x1, x0
    // 0xbfe0d8: ldur            x0, [fp, #-8]
    // 0xbfe0dc: LoadField: r2 = r0->field_7
    //     0xbfe0dc: ldur            w2, [x0, #7]
    // 0xbfe0e0: DecompressPointer r2
    //     0xbfe0e0: add             x2, x2, HEAP, lsl #32
    // 0xbfe0e4: LoadField: d0 = r2->field_b
    //     0xbfe0e4: ldur            d0, [x2, #0xb]
    // 0xbfe0e8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbfe0e8: ldur            d1, [x2, #0x17]
    // 0xbfe0ec: d2 = 1.000000
    //     0xbfe0ec: fmov            d2, #1.00000000
    // 0xbfe0f0: fadd            d3, d1, d2
    // 0xbfe0f4: d1 = 2.000000
    //     0xbfe0f4: fmov            d1, #2.00000000
    // 0xbfe0f8: fdiv            d4, d3, d1
    // 0xbfe0fc: fsub            d1, d2, d4
    // 0xbfe100: fmul            d2, d0, d1
    // 0xbfe104: mov             v0.16b, v2.16b
    // 0xbfe108: r0 = deflate()
    //     0xbfe108: bl              #0x882c84  ; [dart:ui] Rect::deflate
    // 0xbfe10c: LoadField: d0 = r0->field_7
    //     0xbfe10c: ldur            d0, [x0, #7]
    // 0xbfe110: stur            d0, [fp, #-0x40]
    // 0xbfe114: LoadField: d1 = r0->field_f
    //     0xbfe114: ldur            d1, [x0, #0xf]
    // 0xbfe118: stur            d1, [fp, #-0x38]
    // 0xbfe11c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xbfe11c: ldur            d2, [x0, #0x17]
    // 0xbfe120: stur            d2, [fp, #-0x30]
    // 0xbfe124: LoadField: d3 = r0->field_1f
    //     0xbfe124: ldur            d3, [x0, #0x1f]
    // 0xbfe128: ldur            x0, [fp, #-0x18]
    // 0xbfe12c: stur            d3, [fp, #-0x28]
    // 0xbfe130: LoadField: r1 = r0->field_7
    //     0xbfe130: ldur            w1, [x0, #7]
    // 0xbfe134: DecompressPointer r1
    //     0xbfe134: add             x1, x1, HEAP, lsl #32
    // 0xbfe138: cmp             w1, NULL
    // 0xbfe13c: b.eq            #0xbfe1a4
    // 0xbfe140: LoadField: r2 = r1->field_7
    //     0xbfe140: ldur            x2, [x1, #7]
    // 0xbfe144: ldr             x1, [x2]
    // 0xbfe148: cbz             x1, #0xbfe18c
    // 0xbfe14c: mov             x2, x1
    // 0xbfe150: stur            x2, [fp, #-0x20]
    // 0xbfe154: r1 = <Never>
    //     0xbfe154: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfe158: r0 = Pointer()
    //     0xbfe158: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfe15c: mov             x1, x0
    // 0xbfe160: ldur            x0, [fp, #-0x20]
    // 0xbfe164: StoreField: r1->field_7 = r0
    //     0xbfe164: stur            x0, [x1, #7]
    // 0xbfe168: ldur            d0, [fp, #-0x40]
    // 0xbfe16c: ldur            d1, [fp, #-0x38]
    // 0xbfe170: ldur            d2, [fp, #-0x30]
    // 0xbfe174: ldur            d3, [fp, #-0x28]
    // 0xbfe178: r0 = __addOval$Method$FfiNative()
    //     0xbfe178: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xbfe17c: ldur            x0, [fp, #-0x18]
    // 0xbfe180: LeaveFrame
    //     0xbfe180: mov             SP, fp
    //     0xbfe184: ldp             fp, lr, [SP], #0x10
    // 0xbfe188: ret
    //     0xbfe188: ret             
    // 0xbfe18c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfe18c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfe190: str             x16, [SP]
    // 0xbfe194: r0 = _throwNew()
    //     0xbfe194: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfe198: brk             #0
    // 0xbfe19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfe19c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfe1a0: b               #0xbfe0b8
    // 0xbfe1a4: r0 = NullErrorSharedWithFPURegs()
    //     0xbfe1a4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0xbfe1a8, size: 0x178
    // 0xbfe1a8: EnterFrame
    //     0xbfe1a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfe1ac: mov             fp, SP
    // 0xbfe1b0: AllocStack(0x38)
    //     0xbfe1b0: sub             SP, SP, #0x38
    // 0xbfe1b4: d0 = 0.000000
    //     0xbfe1b4: eor             v0.16b, v0.16b, v0.16b
    // 0xbfe1b8: mov             x0, x2
    // 0xbfe1bc: stur            x2, [fp, #-8]
    // 0xbfe1c0: CheckStackOverflow
    //     0xbfe1c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfe1c4: cmp             SP, x16
    //     0xbfe1c8: b.ls            #0xbfe318
    // 0xbfe1cc: LoadField: d1 = r1->field_b
    //     0xbfe1cc: ldur            d1, [x1, #0xb]
    // 0xbfe1d0: fcmp            d1, d0
    // 0xbfe1d4: b.eq            #0xbfe208
    // 0xbfe1d8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbfe1d8: ldur            d0, [x0, #0x17]
    // 0xbfe1dc: stur            d0, [fp, #-0x28]
    // 0xbfe1e0: LoadField: d2 = r0->field_7
    //     0xbfe1e0: ldur            d2, [x0, #7]
    // 0xbfe1e4: stur            d2, [fp, #-0x20]
    // 0xbfe1e8: fsub            d3, d0, d2
    // 0xbfe1ec: LoadField: d4 = r0->field_1f
    //     0xbfe1ec: ldur            d4, [x0, #0x1f]
    // 0xbfe1f0: stur            d4, [fp, #-0x38]
    // 0xbfe1f4: LoadField: d5 = r0->field_f
    //     0xbfe1f4: ldur            d5, [x0, #0xf]
    // 0xbfe1f8: stur            d5, [fp, #-0x30]
    // 0xbfe1fc: fsub            d6, d4, d5
    // 0xbfe200: fcmp            d3, d6
    // 0xbfe204: b.ne            #0xbfe258
    // 0xbfe208: mov             x1, x0
    // 0xbfe20c: r0 = center()
    //     0xbfe20c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xbfe210: ldur            x1, [fp, #-8]
    // 0xbfe214: stur            x0, [fp, #-8]
    // 0xbfe218: r0 = shortestSide()
    //     0xbfe218: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xbfe21c: d7 = 2.000000
    //     0xbfe21c: fmov            d7, #2.00000000
    // 0xbfe220: fdiv            d1, d0, d7
    // 0xbfe224: fmul            d0, d1, d7
    // 0xbfe228: stur            d0, [fp, #-0x10]
    // 0xbfe22c: r0 = Rect()
    //     0xbfe22c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbfe230: mov             x1, x0
    // 0xbfe234: ldur            x2, [fp, #-8]
    // 0xbfe238: ldur            d0, [fp, #-0x10]
    // 0xbfe23c: ldur            d1, [fp, #-0x10]
    // 0xbfe240: stur            x0, [fp, #-8]
    // 0xbfe244: r0 = Rect.fromCenter()
    //     0xbfe244: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xbfe248: ldur            x0, [fp, #-8]
    // 0xbfe24c: LeaveFrame
    //     0xbfe24c: mov             SP, fp
    //     0xbfe250: ldp             fp, lr, [SP], #0x10
    // 0xbfe254: ret
    //     0xbfe254: ret             
    // 0xbfe258: d7 = 2.000000
    //     0xbfe258: fmov            d7, #2.00000000
    // 0xbfe25c: fcmp            d6, d3
    // 0xbfe260: b.le            #0xbfe2b8
    // 0xbfe264: d8 = 1.000000
    //     0xbfe264: fmov            d8, #1.00000000
    // 0xbfe268: fsub            d9, d8, d1
    // 0xbfe26c: fsub            d1, d6, d3
    // 0xbfe270: fmul            d3, d9, d1
    // 0xbfe274: fdiv            d1, d3, d7
    // 0xbfe278: fadd            d3, d5, d1
    // 0xbfe27c: stur            d3, [fp, #-0x18]
    // 0xbfe280: fsub            d5, d4, d1
    // 0xbfe284: stur            d5, [fp, #-0x10]
    // 0xbfe288: r0 = Rect()
    //     0xbfe288: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbfe28c: ldur            d0, [fp, #-0x20]
    // 0xbfe290: StoreField: r0->field_7 = d0
    //     0xbfe290: stur            d0, [x0, #7]
    // 0xbfe294: ldur            d0, [fp, #-0x18]
    // 0xbfe298: StoreField: r0->field_f = d0
    //     0xbfe298: stur            d0, [x0, #0xf]
    // 0xbfe29c: ldur            d2, [fp, #-0x28]
    // 0xbfe2a0: ArrayStore: r0[0] = d2  ; List_8
    //     0xbfe2a0: stur            d2, [x0, #0x17]
    // 0xbfe2a4: ldur            d0, [fp, #-0x10]
    // 0xbfe2a8: StoreField: r0->field_1f = d0
    //     0xbfe2a8: stur            d0, [x0, #0x1f]
    // 0xbfe2ac: LeaveFrame
    //     0xbfe2ac: mov             SP, fp
    //     0xbfe2b0: ldp             fp, lr, [SP], #0x10
    // 0xbfe2b4: ret
    //     0xbfe2b4: ret             
    // 0xbfe2b8: mov             v31.16b, v2.16b
    // 0xbfe2bc: mov             v2.16b, v0.16b
    // 0xbfe2c0: mov             v0.16b, v31.16b
    // 0xbfe2c4: d8 = 1.000000
    //     0xbfe2c4: fmov            d8, #1.00000000
    // 0xbfe2c8: fsub            d9, d8, d1
    // 0xbfe2cc: fsub            d1, d3, d6
    // 0xbfe2d0: fmul            d3, d9, d1
    // 0xbfe2d4: fdiv            d1, d3, d7
    // 0xbfe2d8: fadd            d3, d0, d1
    // 0xbfe2dc: stur            d3, [fp, #-0x18]
    // 0xbfe2e0: fsub            d0, d2, d1
    // 0xbfe2e4: stur            d0, [fp, #-0x10]
    // 0xbfe2e8: r0 = Rect()
    //     0xbfe2e8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbfe2ec: ldur            d0, [fp, #-0x18]
    // 0xbfe2f0: StoreField: r0->field_7 = d0
    //     0xbfe2f0: stur            d0, [x0, #7]
    // 0xbfe2f4: ldur            d0, [fp, #-0x30]
    // 0xbfe2f8: StoreField: r0->field_f = d0
    //     0xbfe2f8: stur            d0, [x0, #0xf]
    // 0xbfe2fc: ldur            d0, [fp, #-0x10]
    // 0xbfe300: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfe300: stur            d0, [x0, #0x17]
    // 0xbfe304: ldur            d0, [fp, #-0x38]
    // 0xbfe308: StoreField: r0->field_1f = d0
    //     0xbfe308: stur            d0, [x0, #0x1f]
    // 0xbfe30c: LeaveFrame
    //     0xbfe30c: mov             SP, fp
    //     0xbfe310: ldp             fp, lr, [SP], #0x10
    // 0xbfe314: ret
    //     0xbfe314: ret             
    // 0xbfe318: r0 = StackOverflowSharedWithFPURegs()
    //     0xbfe318: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbfe31c: b               #0xbfe1cc
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ed498, size: 0x1f4
    // 0x10ed498: EnterFrame
    //     0x10ed498: stp             fp, lr, [SP, #-0x10]!
    //     0x10ed49c: mov             fp, SP
    // 0x10ed4a0: AllocStack(0x28)
    //     0x10ed4a0: sub             SP, SP, #0x28
    // 0x10ed4a4: SetupParameters(CircleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x10ed4a4: mov             x3, x1
    //     0x10ed4a8: mov             x0, x2
    //     0x10ed4ac: mov             v1.16b, v0.16b
    //     0x10ed4b0: stur            x1, [fp, #-8]
    //     0x10ed4b4: stur            x2, [fp, #-0x10]
    //     0x10ed4b8: stur            d0, [fp, #-0x20]
    // 0x10ed4bc: CheckStackOverflow
    //     0x10ed4bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ed4c0: cmp             SP, x16
    //     0x10ed4c4: b.ls            #0x10ed620
    // 0x10ed4c8: r1 = LoadClassIdInstr(r0)
    //     0x10ed4c8: ldur            x1, [x0, #-1]
    //     0x10ed4cc: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed4d0: cmp             x1, #0xbd2
    // 0x10ed4d4: b.ne            #0x10ed5f4
    // 0x10ed4d8: LoadField: r1 = r0->field_7
    //     0x10ed4d8: ldur            w1, [x0, #7]
    // 0x10ed4dc: DecompressPointer r1
    //     0x10ed4dc: add             x1, x1, HEAP, lsl #32
    // 0x10ed4e0: LoadField: r2 = r3->field_7
    //     0x10ed4e0: ldur            w2, [x3, #7]
    // 0x10ed4e4: DecompressPointer r2
    //     0x10ed4e4: add             x2, x2, HEAP, lsl #32
    // 0x10ed4e8: mov             v0.16b, v1.16b
    // 0x10ed4ec: r0 = lerp()
    //     0x10ed4ec: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed4f0: mov             x4, x0
    // 0x10ed4f4: ldur            x0, [fp, #-0x10]
    // 0x10ed4f8: stur            x4, [fp, #-0x18]
    // 0x10ed4fc: LoadField: d0 = r0->field_b
    //     0x10ed4fc: ldur            d0, [x0, #0xb]
    // 0x10ed500: ldur            x1, [fp, #-8]
    // 0x10ed504: LoadField: d1 = r1->field_b
    //     0x10ed504: ldur            d1, [x1, #0xb]
    // 0x10ed508: ldur            d2, [fp, #-0x20]
    // 0x10ed50c: r3 = inline_Allocate_Double()
    //     0x10ed50c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x10ed510: add             x3, x3, #0x10
    //     0x10ed514: cmp             x0, x3
    //     0x10ed518: b.ls            #0x10ed628
    //     0x10ed51c: str             x3, [THR, #0x60]  ; THR::top
    //     0x10ed520: sub             x3, x3, #0xf
    //     0x10ed524: mov             x0, #0xe19c
    //     0x10ed528: movk            x0, #3, lsl #16
    //     0x10ed52c: stur            x0, [x3, #-1]
    // 0x10ed530: dmb             ishst
    // 0x10ed534: StoreField: r3->field_7 = d2
    //     0x10ed534: stur            d2, [x3, #7]
    // 0x10ed538: r1 = inline_Allocate_Double()
    //     0x10ed538: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x10ed53c: add             x1, x1, #0x10
    //     0x10ed540: cmp             x0, x1
    //     0x10ed544: b.ls            #0x10ed64c
    //     0x10ed548: str             x1, [THR, #0x60]  ; THR::top
    //     0x10ed54c: sub             x1, x1, #0xf
    //     0x10ed550: mov             x0, #0xe19c
    //     0x10ed554: movk            x0, #3, lsl #16
    //     0x10ed558: stur            x0, [x1, #-1]
    // 0x10ed55c: dmb             ishst
    // 0x10ed560: StoreField: r1->field_7 = d0
    //     0x10ed560: stur            d0, [x1, #7]
    // 0x10ed564: r2 = inline_Allocate_Double()
    //     0x10ed564: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x10ed568: add             x2, x2, #0x10
    //     0x10ed56c: cmp             x0, x2
    //     0x10ed570: b.ls            #0x10ed668
    //     0x10ed574: str             x2, [THR, #0x60]  ; THR::top
    //     0x10ed578: sub             x2, x2, #0xf
    //     0x10ed57c: mov             x0, #0xe19c
    //     0x10ed580: movk            x0, #3, lsl #16
    //     0x10ed584: stur            x0, [x2, #-1]
    // 0x10ed588: dmb             ishst
    // 0x10ed58c: StoreField: r2->field_7 = d1
    //     0x10ed58c: stur            d1, [x2, #7]
    // 0x10ed590: r0 = lerpDouble()
    //     0x10ed590: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10ed594: LoadField: d0 = r0->field_7
    //     0x10ed594: ldur            d0, [x0, #7]
    // 0x10ed598: d1 = 0.000000
    //     0x10ed598: eor             v1.16b, v1.16b, v1.16b
    // 0x10ed59c: fcmp            d1, d0
    // 0x10ed5a0: b.le            #0x10ed5ac
    // 0x10ed5a4: d0 = 0.000000
    //     0x10ed5a4: eor             v0.16b, v0.16b, v0.16b
    // 0x10ed5a8: b               #0x10ed5cc
    // 0x10ed5ac: d1 = 1.000000
    //     0x10ed5ac: fmov            d1, #1.00000000
    // 0x10ed5b0: fcmp            d0, d1
    // 0x10ed5b4: b.le            #0x10ed5c0
    // 0x10ed5b8: d0 = 1.000000
    //     0x10ed5b8: fmov            d0, #1.00000000
    // 0x10ed5bc: b               #0x10ed5cc
    // 0x10ed5c0: fcmp            d0, d0
    // 0x10ed5c4: b.vc            #0x10ed5cc
    // 0x10ed5c8: d0 = 1.000000
    //     0x10ed5c8: fmov            d0, #1.00000000
    // 0x10ed5cc: ldur            x0, [fp, #-0x18]
    // 0x10ed5d0: stur            d0, [fp, #-0x28]
    // 0x10ed5d4: r0 = CircleBorder()
    //     0x10ed5d4: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x10ed5d8: ldur            d0, [fp, #-0x28]
    // 0x10ed5dc: StoreField: r0->field_b = d0
    //     0x10ed5dc: stur            d0, [x0, #0xb]
    // 0x10ed5e0: ldur            x1, [fp, #-0x18]
    // 0x10ed5e4: StoreField: r0->field_7 = r1
    //     0x10ed5e4: stur            w1, [x0, #7]
    // 0x10ed5e8: LeaveFrame
    //     0x10ed5e8: mov             SP, fp
    //     0x10ed5ec: ldp             fp, lr, [SP], #0x10
    // 0x10ed5f0: ret
    //     0x10ed5f0: ret             
    // 0x10ed5f4: mov             x1, x3
    // 0x10ed5f8: mov             v2.16b, v1.16b
    // 0x10ed5fc: cmp             w0, NULL
    // 0x10ed600: b.ne            #0x10ed610
    // 0x10ed604: mov             v0.16b, v2.16b
    // 0x10ed608: r0 = scale()
    //     0x10ed608: bl              #0x12fc868  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::scale
    // 0x10ed60c: b               #0x10ed614
    // 0x10ed610: r0 = Null
    //     0x10ed610: mov             x0, NULL
    // 0x10ed614: LeaveFrame
    //     0x10ed614: mov             SP, fp
    //     0x10ed618: ldp             fp, lr, [SP], #0x10
    // 0x10ed61c: ret
    //     0x10ed61c: ret             
    // 0x10ed620: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ed620: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ed624: b               #0x10ed4c8
    // 0x10ed628: stp             q1, q2, [SP, #-0x20]!
    // 0x10ed62c: SaveReg d0
    //     0x10ed62c: str             q0, [SP, #-0x10]!
    // 0x10ed630: SaveReg r4
    //     0x10ed630: str             x4, [SP, #-8]!
    // 0x10ed634: r0 = AllocateDouble()
    //     0x10ed634: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ed638: mov             x3, x0
    // 0x10ed63c: RestoreReg r4
    //     0x10ed63c: ldr             x4, [SP], #8
    // 0x10ed640: RestoreReg d0
    //     0x10ed640: ldr             q0, [SP], #0x10
    // 0x10ed644: ldp             q1, q2, [SP], #0x20
    // 0x10ed648: b               #0x10ed534
    // 0x10ed64c: stp             q0, q1, [SP, #-0x20]!
    // 0x10ed650: stp             x3, x4, [SP, #-0x10]!
    // 0x10ed654: r0 = AllocateDouble()
    //     0x10ed654: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ed658: mov             x1, x0
    // 0x10ed65c: ldp             x3, x4, [SP], #0x10
    // 0x10ed660: ldp             q0, q1, [SP], #0x20
    // 0x10ed664: b               #0x10ed560
    // 0x10ed668: SaveReg d1
    //     0x10ed668: str             q1, [SP, #-0x10]!
    // 0x10ed66c: stp             x3, x4, [SP, #-0x10]!
    // 0x10ed670: SaveReg r1
    //     0x10ed670: str             x1, [SP, #-8]!
    // 0x10ed674: r0 = AllocateDouble()
    //     0x10ed674: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ed678: mov             x2, x0
    // 0x10ed67c: RestoreReg r1
    //     0x10ed67c: ldr             x1, [SP], #8
    // 0x10ed680: ldp             x3, x4, [SP], #0x10
    // 0x10ed684: RestoreReg d1
    //     0x10ed684: ldr             q1, [SP], #0x10
    // 0x10ed688: b               #0x10ed58c
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f062c, size: 0x1e4
    // 0x10f062c: EnterFrame
    //     0x10f062c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0630: mov             fp, SP
    // 0x10f0634: AllocStack(0x28)
    //     0x10f0634: sub             SP, SP, #0x28
    // 0x10f0638: SetupParameters(CircleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x10f0638: mov             x3, x1
    //     0x10f063c: mov             x0, x2
    //     0x10f0640: mov             v1.16b, v0.16b
    //     0x10f0644: stur            x1, [fp, #-8]
    //     0x10f0648: stur            x2, [fp, #-0x10]
    //     0x10f064c: stur            d0, [fp, #-0x20]
    // 0x10f0650: CheckStackOverflow
    //     0x10f0650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f0654: cmp             SP, x16
    //     0x10f0658: b.ls            #0x10f07a4
    // 0x10f065c: r1 = LoadClassIdInstr(r0)
    //     0x10f065c: ldur            x1, [x0, #-1]
    //     0x10f0660: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0664: cmp             x1, #0xbd2
    // 0x10f0668: b.ne            #0x10f0784
    // 0x10f066c: LoadField: r1 = r3->field_7
    //     0x10f066c: ldur            w1, [x3, #7]
    // 0x10f0670: DecompressPointer r1
    //     0x10f0670: add             x1, x1, HEAP, lsl #32
    // 0x10f0674: LoadField: r2 = r0->field_7
    //     0x10f0674: ldur            w2, [x0, #7]
    // 0x10f0678: DecompressPointer r2
    //     0x10f0678: add             x2, x2, HEAP, lsl #32
    // 0x10f067c: mov             v0.16b, v1.16b
    // 0x10f0680: r0 = lerp()
    //     0x10f0680: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0684: ldur            x1, [fp, #-8]
    // 0x10f0688: stur            x0, [fp, #-0x18]
    // 0x10f068c: LoadField: d0 = r1->field_b
    //     0x10f068c: ldur            d0, [x1, #0xb]
    // 0x10f0690: ldur            x2, [fp, #-0x10]
    // 0x10f0694: LoadField: d1 = r2->field_b
    //     0x10f0694: ldur            d1, [x2, #0xb]
    // 0x10f0698: ldur            d2, [fp, #-0x20]
    // 0x10f069c: r3 = inline_Allocate_Double()
    //     0x10f069c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x10f06a0: add             x3, x3, #0x10
    //     0x10f06a4: cmp             x1, x3
    //     0x10f06a8: b.ls            #0x10f07ac
    //     0x10f06ac: str             x3, [THR, #0x60]  ; THR::top
    //     0x10f06b0: sub             x3, x3, #0xf
    //     0x10f06b4: mov             x1, #0xe19c
    //     0x10f06b8: movk            x1, #3, lsl #16
    //     0x10f06bc: stur            x1, [x3, #-1]
    // 0x10f06c0: dmb             ishst
    // 0x10f06c4: StoreField: r3->field_7 = d2
    //     0x10f06c4: stur            d2, [x3, #7]
    // 0x10f06c8: r1 = inline_Allocate_Double()
    //     0x10f06c8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10f06cc: add             x1, x1, #0x10
    //     0x10f06d0: cmp             x2, x1
    //     0x10f06d4: b.ls            #0x10f07d0
    //     0x10f06d8: str             x1, [THR, #0x60]  ; THR::top
    //     0x10f06dc: sub             x1, x1, #0xf
    //     0x10f06e0: mov             x2, #0xe19c
    //     0x10f06e4: movk            x2, #3, lsl #16
    //     0x10f06e8: stur            x2, [x1, #-1]
    // 0x10f06ec: dmb             ishst
    // 0x10f06f0: StoreField: r1->field_7 = d0
    //     0x10f06f0: stur            d0, [x1, #7]
    // 0x10f06f4: r2 = inline_Allocate_Double()
    //     0x10f06f4: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x10f06f8: add             x2, x2, #0x10
    //     0x10f06fc: cmp             x4, x2
    //     0x10f0700: b.ls            #0x10f07ec
    //     0x10f0704: str             x2, [THR, #0x60]  ; THR::top
    //     0x10f0708: sub             x2, x2, #0xf
    //     0x10f070c: mov             x4, #0xe19c
    //     0x10f0710: movk            x4, #3, lsl #16
    //     0x10f0714: stur            x4, [x2, #-1]
    // 0x10f0718: dmb             ishst
    // 0x10f071c: StoreField: r2->field_7 = d1
    //     0x10f071c: stur            d1, [x2, #7]
    // 0x10f0720: r0 = lerpDouble()
    //     0x10f0720: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10f0724: LoadField: d0 = r0->field_7
    //     0x10f0724: ldur            d0, [x0, #7]
    // 0x10f0728: d1 = 0.000000
    //     0x10f0728: eor             v1.16b, v1.16b, v1.16b
    // 0x10f072c: fcmp            d1, d0
    // 0x10f0730: b.le            #0x10f073c
    // 0x10f0734: d0 = 0.000000
    //     0x10f0734: eor             v0.16b, v0.16b, v0.16b
    // 0x10f0738: b               #0x10f075c
    // 0x10f073c: d1 = 1.000000
    //     0x10f073c: fmov            d1, #1.00000000
    // 0x10f0740: fcmp            d0, d1
    // 0x10f0744: b.le            #0x10f0750
    // 0x10f0748: d0 = 1.000000
    //     0x10f0748: fmov            d0, #1.00000000
    // 0x10f074c: b               #0x10f075c
    // 0x10f0750: fcmp            d0, d0
    // 0x10f0754: b.vc            #0x10f075c
    // 0x10f0758: d0 = 1.000000
    //     0x10f0758: fmov            d0, #1.00000000
    // 0x10f075c: ldur            x0, [fp, #-0x18]
    // 0x10f0760: stur            d0, [fp, #-0x28]
    // 0x10f0764: r0 = CircleBorder()
    //     0x10f0764: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x10f0768: ldur            d0, [fp, #-0x28]
    // 0x10f076c: StoreField: r0->field_b = d0
    //     0x10f076c: stur            d0, [x0, #0xb]
    // 0x10f0770: ldur            x1, [fp, #-0x18]
    // 0x10f0774: StoreField: r0->field_7 = r1
    //     0x10f0774: stur            w1, [x0, #7]
    // 0x10f0778: LeaveFrame
    //     0x10f0778: mov             SP, fp
    //     0x10f077c: ldp             fp, lr, [SP], #0x10
    // 0x10f0780: ret
    //     0x10f0780: ret             
    // 0x10f0784: mov             x1, x3
    // 0x10f0788: mov             x2, x0
    // 0x10f078c: mov             v2.16b, v1.16b
    // 0x10f0790: mov             v0.16b, v2.16b
    // 0x10f0794: r0 = lerpTo()
    //     0x10f0794: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f0798: LeaveFrame
    //     0x10f0798: mov             SP, fp
    //     0x10f079c: ldp             fp, lr, [SP], #0x10
    // 0x10f07a0: ret
    //     0x10f07a0: ret             
    // 0x10f07a4: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f07a4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f07a8: b               #0x10f065c
    // 0x10f07ac: stp             q1, q2, [SP, #-0x20]!
    // 0x10f07b0: SaveReg d0
    //     0x10f07b0: str             q0, [SP, #-0x10]!
    // 0x10f07b4: SaveReg r0
    //     0x10f07b4: str             x0, [SP, #-8]!
    // 0x10f07b8: r0 = AllocateDouble()
    //     0x10f07b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f07bc: mov             x3, x0
    // 0x10f07c0: RestoreReg r0
    //     0x10f07c0: ldr             x0, [SP], #8
    // 0x10f07c4: RestoreReg d0
    //     0x10f07c4: ldr             q0, [SP], #0x10
    // 0x10f07c8: ldp             q1, q2, [SP], #0x20
    // 0x10f07cc: b               #0x10f06c4
    // 0x10f07d0: stp             q0, q1, [SP, #-0x20]!
    // 0x10f07d4: stp             x0, x3, [SP, #-0x10]!
    // 0x10f07d8: r0 = AllocateDouble()
    //     0x10f07d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f07dc: mov             x1, x0
    // 0x10f07e0: ldp             x0, x3, [SP], #0x10
    // 0x10f07e4: ldp             q0, q1, [SP], #0x20
    // 0x10f07e8: b               #0x10f06f0
    // 0x10f07ec: SaveReg d1
    //     0x10f07ec: str             q1, [SP, #-0x10]!
    // 0x10f07f0: stp             x1, x3, [SP, #-0x10]!
    // 0x10f07f4: SaveReg r0
    //     0x10f07f4: str             x0, [SP, #-8]!
    // 0x10f07f8: r0 = AllocateDouble()
    //     0x10f07f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f07fc: mov             x2, x0
    // 0x10f0800: RestoreReg r0
    //     0x10f0800: ldr             x0, [SP], #8
    // 0x10f0804: ldp             x1, x3, [SP], #0x10
    // 0x10f0808: RestoreReg d1
    //     0x10f0808: ldr             q1, [SP], #0x10
    // 0x10f080c: b               #0x10f071c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12960bc, size: 0xf0
    // 0x12960bc: EnterFrame
    //     0x12960bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12960c0: mov             fp, SP
    // 0x12960c4: AllocStack(0x10)
    //     0x12960c4: sub             SP, SP, #0x10
    // 0x12960c8: CheckStackOverflow
    //     0x12960c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12960cc: cmp             SP, x16
    //     0x12960d0: b.ls            #0x12961a4
    // 0x12960d4: ldr             x0, [fp, #0x10]
    // 0x12960d8: cmp             w0, NULL
    // 0x12960dc: b.ne            #0x12960f0
    // 0x12960e0: r0 = false
    //     0x12960e0: add             x0, NULL, #0x30  ; false
    // 0x12960e4: LeaveFrame
    //     0x12960e4: mov             SP, fp
    //     0x12960e8: ldp             fp, lr, [SP], #0x10
    // 0x12960ec: ret
    //     0x12960ec: ret             
    // 0x12960f0: str             x0, [SP]
    // 0x12960f4: r0 = runtimeType()
    //     0x12960f4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12960f8: r1 = LoadClassIdInstr(r0)
    //     0x12960f8: ldur            x1, [x0, #-1]
    //     0x12960fc: ubfx            x1, x1, #0xc, #0x14
    // 0x1296100: r16 = CircleBorder
    //     0x1296100: add             x16, PP, #0x80, lsl #12  ; [pp+0x808b0] Type: CircleBorder
    //     0x1296104: ldr             x16, [x16, #0x8b0]
    // 0x1296108: stp             x16, x0, [SP]
    // 0x129610c: mov             x0, x1
    // 0x1296110: mov             lr, x0
    // 0x1296114: ldr             lr, [x21, lr, lsl #3]
    // 0x1296118: blr             lr
    // 0x129611c: tbz             w0, #4, #0x1296130
    // 0x1296120: r0 = false
    //     0x1296120: add             x0, NULL, #0x30  ; false
    // 0x1296124: LeaveFrame
    //     0x1296124: mov             SP, fp
    //     0x1296128: ldp             fp, lr, [SP], #0x10
    // 0x129612c: ret
    //     0x129612c: ret             
    // 0x1296130: ldr             x0, [fp, #0x10]
    // 0x1296134: r1 = 60
    //     0x1296134: mov             x1, #0x3c
    // 0x1296138: branchIfSmi(r0, 0x1296144)
    //     0x1296138: tbz             w0, #0, #0x1296144
    // 0x129613c: r1 = LoadClassIdInstr(r0)
    //     0x129613c: ldur            x1, [x0, #-1]
    //     0x1296140: ubfx            x1, x1, #0xc, #0x14
    // 0x1296144: cmp             x1, #0xbd2
    // 0x1296148: b.ne            #0x1296194
    // 0x129614c: ldr             x1, [fp, #0x18]
    // 0x1296150: LoadField: r2 = r0->field_7
    //     0x1296150: ldur            w2, [x0, #7]
    // 0x1296154: DecompressPointer r2
    //     0x1296154: add             x2, x2, HEAP, lsl #32
    // 0x1296158: LoadField: r3 = r1->field_7
    //     0x1296158: ldur            w3, [x1, #7]
    // 0x129615c: DecompressPointer r3
    //     0x129615c: add             x3, x3, HEAP, lsl #32
    // 0x1296160: stp             x3, x2, [SP]
    // 0x1296164: r0 = ==()
    //     0x1296164: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296168: tbnz            w0, #4, #0x1296194
    // 0x129616c: ldr             x2, [fp, #0x18]
    // 0x1296170: ldr             x1, [fp, #0x10]
    // 0x1296174: LoadField: d0 = r1->field_b
    //     0x1296174: ldur            d0, [x1, #0xb]
    // 0x1296178: LoadField: d1 = r2->field_b
    //     0x1296178: ldur            d1, [x2, #0xb]
    // 0x129617c: fcmp            d0, d1
    // 0x1296180: r16 = true
    //     0x1296180: add             x16, NULL, #0x20  ; true
    // 0x1296184: r17 = false
    //     0x1296184: add             x17, NULL, #0x30  ; false
    // 0x1296188: csel            x1, x16, x17, eq
    // 0x129618c: mov             x0, x1
    // 0x1296190: b               #0x1296198
    // 0x1296194: r0 = false
    //     0x1296194: add             x0, NULL, #0x30  ; false
    // 0x1296198: LeaveFrame
    //     0x1296198: mov             SP, fp
    //     0x129619c: ldp             fp, lr, [SP], #0x10
    // 0x12961a0: ret
    //     0x12961a0: ret             
    // 0x12961a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12961a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12961a8: b               #0x12960d4
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ec1ac, size: 0xa4
    // 0x12ec1ac: EnterFrame
    //     0x12ec1ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12ec1b0: mov             fp, SP
    // 0x12ec1b4: AllocStack(0x20)
    //     0x12ec1b4: sub             SP, SP, #0x20
    // 0x12ec1b8: d0 = 0.000000
    //     0x12ec1b8: eor             v0.16b, v0.16b, v0.16b
    // 0x12ec1bc: mov             x0, x3
    // 0x12ec1c0: stur            x3, [fp, #-0x10]
    // 0x12ec1c4: mov             x3, x5
    // 0x12ec1c8: stur            x2, [fp, #-8]
    // 0x12ec1cc: stur            x5, [fp, #-0x18]
    // 0x12ec1d0: CheckStackOverflow
    //     0x12ec1d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ec1d4: cmp             SP, x16
    //     0x12ec1d8: b.ls            #0x12ec248
    // 0x12ec1dc: LoadField: d1 = r1->field_b
    //     0x12ec1dc: ldur            d1, [x1, #0xb]
    // 0x12ec1e0: fcmp            d1, d0
    // 0x12ec1e4: b.ne            #0x12ec220
    // 0x12ec1e8: mov             x1, x0
    // 0x12ec1ec: r0 = center()
    //     0x12ec1ec: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12ec1f0: ldur            x1, [fp, #-0x10]
    // 0x12ec1f4: stur            x0, [fp, #-0x20]
    // 0x12ec1f8: r0 = shortestSide()
    //     0x12ec1f8: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12ec1fc: mov             v1.16b, v0.16b
    // 0x12ec200: d0 = 2.000000
    //     0x12ec200: fmov            d0, #2.00000000
    // 0x12ec204: fdiv            d2, d1, d0
    // 0x12ec208: ldur            x1, [fp, #-8]
    // 0x12ec20c: ldur            x2, [fp, #-0x20]
    // 0x12ec210: mov             v0.16b, v2.16b
    // 0x12ec214: ldur            x3, [fp, #-0x18]
    // 0x12ec218: r0 = drawCircle()
    //     0x12ec218: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12ec21c: b               #0x12ec238
    // 0x12ec220: ldur            x2, [fp, #-0x10]
    // 0x12ec224: r0 = _adjustRect()
    //     0x12ec224: bl              #0xbfe1a8  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0x12ec228: ldur            x1, [fp, #-8]
    // 0x12ec22c: mov             x2, x0
    // 0x12ec230: ldur            x3, [fp, #-0x18]
    // 0x12ec234: r0 = drawOval()
    //     0x12ec234: bl              #0x12ec250  ; [dart:ui] _NativeCanvas::drawOval
    // 0x12ec238: r0 = Null
    //     0x12ec238: mov             x0, NULL
    // 0x12ec23c: LeaveFrame
    //     0x12ec23c: mov             SP, fp
    //     0x12ec240: ldp             fp, lr, [SP], #0x10
    // 0x12ec244: ret
    //     0x12ec244: ret             
    // 0x12ec248: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ec248: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ec24c: b               #0x12ec1dc
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ed644, size: 0x110
    // 0x12ed644: EnterFrame
    //     0x12ed644: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed648: mov             fp, SP
    // 0x12ed64c: AllocStack(0x28)
    //     0x12ed64c: sub             SP, SP, #0x28
    // 0x12ed650: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x12ed650: mov             x0, x3
    //     0x12ed654: stur            x2, [fp, #-0x10]
    //     0x12ed658: stur            x3, [fp, #-0x18]
    // 0x12ed65c: CheckStackOverflow
    //     0x12ed65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed660: cmp             SP, x16
    //     0x12ed664: b.ls            #0x12ed74c
    // 0x12ed668: LoadField: r3 = r1->field_7
    //     0x12ed668: ldur            w3, [x1, #7]
    // 0x12ed66c: DecompressPointer r3
    //     0x12ed66c: add             x3, x3, HEAP, lsl #32
    // 0x12ed670: stur            x3, [fp, #-8]
    // 0x12ed674: LoadField: r4 = r3->field_13
    //     0x12ed674: ldur            w4, [x3, #0x13]
    // 0x12ed678: DecompressPointer r4
    //     0x12ed678: add             x4, x4, HEAP, lsl #32
    // 0x12ed67c: LoadField: r5 = r4->field_7
    //     0x12ed67c: ldur            x5, [x4, #7]
    // 0x12ed680: cmp             x5, #0
    // 0x12ed684: b.le            #0x12ed73c
    // 0x12ed688: d0 = 0.000000
    //     0x12ed688: eor             v0.16b, v0.16b, v0.16b
    // 0x12ed68c: LoadField: d1 = r1->field_b
    //     0x12ed68c: ldur            d1, [x1, #0xb]
    // 0x12ed690: fcmp            d1, d0
    // 0x12ed694: b.ne            #0x12ed6ec
    // 0x12ed698: mov             x1, x0
    // 0x12ed69c: r0 = center()
    //     0x12ed69c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12ed6a0: ldur            x1, [fp, #-0x18]
    // 0x12ed6a4: stur            x0, [fp, #-0x20]
    // 0x12ed6a8: r0 = shortestSide()
    //     0x12ed6a8: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12ed6ac: ldur            x0, [fp, #-8]
    // 0x12ed6b0: LoadField: d1 = r0->field_b
    //     0x12ed6b0: ldur            d1, [x0, #0xb]
    // 0x12ed6b4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12ed6b4: ldur            d2, [x0, #0x17]
    // 0x12ed6b8: fmul            d3, d1, d2
    // 0x12ed6bc: fadd            d1, d0, d3
    // 0x12ed6c0: d0 = 2.000000
    //     0x12ed6c0: fmov            d0, #2.00000000
    // 0x12ed6c4: fdiv            d2, d1, d0
    // 0x12ed6c8: mov             x1, x0
    // 0x12ed6cc: stur            d2, [fp, #-0x28]
    // 0x12ed6d0: r0 = toPaint()
    //     0x12ed6d0: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed6d4: ldur            x1, [fp, #-0x10]
    // 0x12ed6d8: ldur            x2, [fp, #-0x20]
    // 0x12ed6dc: ldur            d0, [fp, #-0x28]
    // 0x12ed6e0: mov             x3, x0
    // 0x12ed6e4: r0 = drawCircle()
    //     0x12ed6e4: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12ed6e8: b               #0x12ed73c
    // 0x12ed6ec: mov             x0, x3
    // 0x12ed6f0: d0 = 2.000000
    //     0x12ed6f0: fmov            d0, #2.00000000
    // 0x12ed6f4: ldur            x2, [fp, #-0x18]
    // 0x12ed6f8: r0 = _adjustRect()
    //     0x12ed6f8: bl              #0xbfe1a8  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0x12ed6fc: mov             x1, x0
    // 0x12ed700: ldur            x0, [fp, #-8]
    // 0x12ed704: LoadField: d0 = r0->field_b
    //     0x12ed704: ldur            d0, [x0, #0xb]
    // 0x12ed708: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12ed708: ldur            d1, [x0, #0x17]
    // 0x12ed70c: fmul            d2, d0, d1
    // 0x12ed710: d0 = 2.000000
    //     0x12ed710: fmov            d0, #2.00000000
    // 0x12ed714: fdiv            d1, d2, d0
    // 0x12ed718: mov             v0.16b, v1.16b
    // 0x12ed71c: r0 = inflate()
    //     0x12ed71c: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x12ed720: ldur            x1, [fp, #-8]
    // 0x12ed724: stur            x0, [fp, #-8]
    // 0x12ed728: r0 = toPaint()
    //     0x12ed728: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed72c: ldur            x1, [fp, #-0x10]
    // 0x12ed730: ldur            x2, [fp, #-8]
    // 0x12ed734: mov             x3, x0
    // 0x12ed738: r0 = drawOval()
    //     0x12ed738: bl              #0x12ec250  ; [dart:ui] _NativeCanvas::drawOval
    // 0x12ed73c: r0 = Null
    //     0x12ed73c: mov             x0, NULL
    // 0x12ed740: LeaveFrame
    //     0x12ed740: mov             SP, fp
    //     0x12ed744: ldp             fp, lr, [SP], #0x10
    // 0x12ed748: ret
    //     0x12ed748: ret             
    // 0x12ed74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ed74c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ed750: b               #0x12ed668
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fc868, size: 0x68
    // 0x12fc868: EnterFrame
    //     0x12fc868: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc86c: mov             fp, SP
    // 0x12fc870: AllocStack(0x18)
    //     0x12fc870: sub             SP, SP, #0x18
    // 0x12fc874: SetupParameters(CircleBorder this /* r1 => r0, fp-0x8 */)
    //     0x12fc874: mov             x0, x1
    //     0x12fc878: stur            x1, [fp, #-8]
    // 0x12fc87c: CheckStackOverflow
    //     0x12fc87c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc880: cmp             SP, x16
    //     0x12fc884: b.ls            #0x12fc8c8
    // 0x12fc888: LoadField: r1 = r0->field_7
    //     0x12fc888: ldur            w1, [x0, #7]
    // 0x12fc88c: DecompressPointer r1
    //     0x12fc88c: add             x1, x1, HEAP, lsl #32
    // 0x12fc890: r0 = scale()
    //     0x12fc890: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fc894: mov             x1, x0
    // 0x12fc898: ldur            x0, [fp, #-8]
    // 0x12fc89c: stur            x1, [fp, #-0x10]
    // 0x12fc8a0: LoadField: d0 = r0->field_b
    //     0x12fc8a0: ldur            d0, [x0, #0xb]
    // 0x12fc8a4: stur            d0, [fp, #-0x18]
    // 0x12fc8a8: r0 = CircleBorder()
    //     0x12fc8a8: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x12fc8ac: ldur            d0, [fp, #-0x18]
    // 0x12fc8b0: StoreField: r0->field_b = d0
    //     0x12fc8b0: stur            d0, [x0, #0xb]
    // 0x12fc8b4: ldur            x1, [fp, #-0x10]
    // 0x12fc8b8: StoreField: r0->field_7 = r1
    //     0x12fc8b8: stur            w1, [x0, #7]
    // 0x12fc8bc: LeaveFrame
    //     0x12fc8bc: mov             SP, fp
    //     0x12fc8c0: ldp             fp, lr, [SP], #0x10
    // 0x12fc8c4: ret
    //     0x12fc8c4: ret             
    // 0x12fc8c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fc8c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fc8cc: b               #0x12fc888
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300184, size: 0xd8
    // 0x1300184: EnterFrame
    //     0x1300184: stp             fp, lr, [SP, #-0x10]!
    //     0x1300188: mov             fp, SP
    // 0x130018c: AllocStack(0x48)
    //     0x130018c: sub             SP, SP, #0x48
    // 0x1300190: SetupParameters(CircleBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1300190: stur            x1, [fp, #-8]
    //     0x1300194: stur            x2, [fp, #-0x10]
    // 0x1300198: CheckStackOverflow
    //     0x1300198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130019c: cmp             SP, x16
    //     0x13001a0: b.ls            #0x1300250
    // 0x13001a4: r0 = _NativePath()
    //     0x13001a4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x13001a8: mov             x1, x0
    // 0x13001ac: stur            x0, [fp, #-0x18]
    // 0x13001b0: r0 = __constructor$Method$FfiNative()
    //     0x13001b0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x13001b4: ldur            x1, [fp, #-8]
    // 0x13001b8: ldur            x2, [fp, #-0x10]
    // 0x13001bc: r0 = _adjustRect()
    //     0x13001bc: bl              #0xbfe1a8  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0x13001c0: LoadField: d0 = r0->field_7
    //     0x13001c0: ldur            d0, [x0, #7]
    // 0x13001c4: stur            d0, [fp, #-0x40]
    // 0x13001c8: LoadField: d1 = r0->field_f
    //     0x13001c8: ldur            d1, [x0, #0xf]
    // 0x13001cc: stur            d1, [fp, #-0x38]
    // 0x13001d0: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x13001d0: ldur            d2, [x0, #0x17]
    // 0x13001d4: stur            d2, [fp, #-0x30]
    // 0x13001d8: LoadField: d3 = r0->field_1f
    //     0x13001d8: ldur            d3, [x0, #0x1f]
    // 0x13001dc: ldur            x0, [fp, #-0x18]
    // 0x13001e0: stur            d3, [fp, #-0x28]
    // 0x13001e4: LoadField: r1 = r0->field_7
    //     0x13001e4: ldur            w1, [x0, #7]
    // 0x13001e8: DecompressPointer r1
    //     0x13001e8: add             x1, x1, HEAP, lsl #32
    // 0x13001ec: cmp             w1, NULL
    // 0x13001f0: b.eq            #0x1300258
    // 0x13001f4: LoadField: r2 = r1->field_7
    //     0x13001f4: ldur            x2, [x1, #7]
    // 0x13001f8: ldr             x1, [x2]
    // 0x13001fc: cbz             x1, #0x1300240
    // 0x1300200: mov             x2, x1
    // 0x1300204: stur            x2, [fp, #-0x20]
    // 0x1300208: r1 = <Never>
    //     0x1300208: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x130020c: r0 = Pointer()
    //     0x130020c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300210: mov             x1, x0
    // 0x1300214: ldur            x0, [fp, #-0x20]
    // 0x1300218: StoreField: r1->field_7 = r0
    //     0x1300218: stur            x0, [x1, #7]
    // 0x130021c: ldur            d0, [fp, #-0x40]
    // 0x1300220: ldur            d1, [fp, #-0x38]
    // 0x1300224: ldur            d2, [fp, #-0x30]
    // 0x1300228: ldur            d3, [fp, #-0x28]
    // 0x130022c: r0 = __addOval$Method$FfiNative()
    //     0x130022c: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0x1300230: ldur            x0, [fp, #-0x18]
    // 0x1300234: LeaveFrame
    //     0x1300234: mov             SP, fp
    //     0x1300238: ldp             fp, lr, [SP], #0x10
    // 0x130023c: ret
    //     0x130023c: ret             
    // 0x1300240: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300240: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300244: str             x16, [SP]
    // 0x1300248: r0 = _throwNew()
    //     0x1300248: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x130024c: brk             #0
    // 0x1300250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300250: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300254: b               #0x13001a4
    // 0x1300258: r0 = NullErrorSharedWithFPURegs()
    //     0x1300258: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x130171c, size: 0x50
    // 0x130171c: EnterFrame
    //     0x130171c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301720: mov             fp, SP
    // 0x1301724: AllocStack(0x10)
    //     0x1301724: sub             SP, SP, #0x10
    // 0x1301728: cmp             w2, NULL
    // 0x130172c: b.ne            #0x130173c
    // 0x1301730: LoadField: r0 = r1->field_7
    //     0x1301730: ldur            w0, [x1, #7]
    // 0x1301734: DecompressPointer r0
    //     0x1301734: add             x0, x0, HEAP, lsl #32
    // 0x1301738: b               #0x1301740
    // 0x130173c: mov             x0, x2
    // 0x1301740: stur            x0, [fp, #-8]
    // 0x1301744: LoadField: d0 = r1->field_b
    //     0x1301744: ldur            d0, [x1, #0xb]
    // 0x1301748: stur            d0, [fp, #-0x10]
    // 0x130174c: r0 = CircleBorder()
    //     0x130174c: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x1301750: ldur            d0, [fp, #-0x10]
    // 0x1301754: StoreField: r0->field_b = d0
    //     0x1301754: stur            d0, [x0, #0xb]
    // 0x1301758: ldur            x1, [fp, #-8]
    // 0x130175c: StoreField: r0->field_7 = r1
    //     0x130175c: stur            w1, [x0, #7]
    // 0x1301760: LeaveFrame
    //     0x1301760: mov             SP, fp
    //     0x1301764: ldp             fp, lr, [SP], #0x10
    // 0x1301768: ret
    //     0x1301768: ret             
  }
}
