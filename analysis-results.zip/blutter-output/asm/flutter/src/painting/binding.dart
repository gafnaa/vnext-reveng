// lib: , url: package:flutter/src/painting/binding.dart

// class id: 1048980, size: 0x8
class :: {

  get _ imageCache(/* No info */) {
    // ** addr: 0xdba558, size: 0x44
    // 0xdba558: EnterFrame
    //     0xdba558: stp             fp, lr, [SP, #-0x10]!
    //     0xdba55c: mov             fp, SP
    // 0xdba560: r1 = LoadStaticField(0x780)
    //     0xdba560: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xdba564: ldr             x1, [x1, #0xf00]
    // 0xdba568: cmp             w1, NULL
    // 0xdba56c: b.eq            #0xdba590
    // 0xdba570: LoadField: r0 = r1->field_ab
    //     0xdba570: ldur            w0, [x1, #0xab]
    // 0xdba574: DecompressPointer r0
    //     0xdba574: add             x0, x0, HEAP, lsl #32
    // 0xdba578: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdba57c: cmp             w0, w16
    // 0xdba580: b.eq            #0xdba594
    // 0xdba584: LeaveFrame
    //     0xdba584: mov             SP, fp
    //     0xdba588: ldp             fp, lr, [SP], #0x10
    // 0xdba58c: ret
    //     0xdba58c: ret             
    // 0xdba590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdba590: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdba594: r9 = _imageCache
    //     0xdba594: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0xdba598: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdba598: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4302, size: 0xc, field offset: 0x8
class _SystemFontsNotifier extends Listenable {

  _ notifyListeners(/* No info */) {
    // ** addr: 0x87bcc4, size: 0xd8
    // 0x87bcc4: EnterFrame
    //     0x87bcc4: stp             fp, lr, [SP, #-0x10]!
    //     0x87bcc8: mov             fp, SP
    // 0x87bccc: AllocStack(0x20)
    //     0x87bccc: sub             SP, SP, #0x20
    // 0x87bcd0: CheckStackOverflow
    //     0x87bcd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87bcd4: cmp             SP, x16
    //     0x87bcd8: b.ls            #0x87bd8c
    // 0x87bcdc: LoadField: r0 = r1->field_7
    //     0x87bcdc: ldur            w0, [x1, #7]
    // 0x87bce0: DecompressPointer r0
    //     0x87bce0: add             x0, x0, HEAP, lsl #32
    // 0x87bce4: mov             x1, x0
    // 0x87bce8: r0 = iterator()
    //     0x87bce8: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x87bcec: stur            x0, [fp, #-0x10]
    // 0x87bcf0: LoadField: r2 = r0->field_7
    //     0x87bcf0: ldur            w2, [x0, #7]
    // 0x87bcf4: DecompressPointer r2
    //     0x87bcf4: add             x2, x2, HEAP, lsl #32
    // 0x87bcf8: stur            x2, [fp, #-8]
    // 0x87bcfc: CheckStackOverflow
    //     0x87bcfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87bd00: cmp             SP, x16
    //     0x87bd04: b.ls            #0x87bd94
    // 0x87bd08: mov             x1, x0
    // 0x87bd0c: r0 = moveNext()
    //     0x87bd0c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87bd10: tbnz            w0, #4, #0x87bd7c
    // 0x87bd14: ldur            x3, [fp, #-0x10]
    // 0x87bd18: LoadField: r4 = r3->field_33
    //     0x87bd18: ldur            w4, [x3, #0x33]
    // 0x87bd1c: DecompressPointer r4
    //     0x87bd1c: add             x4, x4, HEAP, lsl #32
    // 0x87bd20: stur            x4, [fp, #-0x18]
    // 0x87bd24: cmp             w4, NULL
    // 0x87bd28: b.ne            #0x87bd58
    // 0x87bd2c: mov             x0, x4
    // 0x87bd30: ldur            x2, [fp, #-8]
    // 0x87bd34: r1 = Null
    //     0x87bd34: mov             x1, NULL
    // 0x87bd38: cmp             w2, NULL
    // 0x87bd3c: b.eq            #0x87bd58
    // 0x87bd40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87bd40: ldur            w4, [x2, #0x17]
    // 0x87bd44: DecompressPointer r4
    //     0x87bd44: add             x4, x4, HEAP, lsl #32
    // 0x87bd48: r8 = X0
    //     0x87bd48: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87bd4c: LoadField: r9 = r4->field_7
    //     0x87bd4c: ldur            x9, [x4, #7]
    // 0x87bd50: r3 = Null
    //     0x87bd50: ldr             x3, [PP, #0x32c8]  ; [pp+0x32c8] Null
    // 0x87bd54: blr             x9
    // 0x87bd58: ldur            x16, [fp, #-0x18]
    // 0x87bd5c: str             x16, [SP]
    // 0x87bd60: ldur            x0, [fp, #-0x18]
    // 0x87bd64: ClosureCall
    //     0x87bd64: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x87bd68: ldur            x2, [x0, #0x1f]
    //     0x87bd6c: blr             x2
    // 0x87bd70: ldur            x0, [fp, #-0x10]
    // 0x87bd74: ldur            x2, [fp, #-8]
    // 0x87bd78: b               #0x87bcfc
    // 0x87bd7c: r0 = Null
    //     0x87bd7c: mov             x0, NULL
    // 0x87bd80: LeaveFrame
    //     0x87bd80: mov             SP, fp
    //     0x87bd84: ldp             fp, lr, [SP], #0x10
    // 0x87bd88: ret
    //     0x87bd88: ret             
    // 0x87bd8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87bd8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87bd90: b               #0x87bcdc
    // 0x87bd94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87bd94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87bd98: b               #0x87bd08
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xd01458, size: 0x3c
    // 0xd01458: EnterFrame
    //     0xd01458: stp             fp, lr, [SP, #-0x10]!
    //     0xd0145c: mov             fp, SP
    // 0xd01460: CheckStackOverflow
    //     0xd01460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01464: cmp             SP, x16
    //     0xd01468: b.ls            #0xd0148c
    // 0xd0146c: LoadField: r0 = r1->field_7
    //     0xd0146c: ldur            w0, [x1, #7]
    // 0xd01470: DecompressPointer r0
    //     0xd01470: add             x0, x0, HEAP, lsl #32
    // 0xd01474: mov             x1, x0
    // 0xd01478: r0 = remove()
    //     0xd01478: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xd0147c: r0 = Null
    //     0xd0147c: mov             x0, NULL
    // 0xd01480: LeaveFrame
    //     0xd01480: mov             SP, fp
    //     0xd01484: ldp             fp, lr, [SP], #0x10
    // 0xd01488: ret
    //     0xd01488: ret             
    // 0xd0148c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0148c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01490: b               #0xd0146c
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd04a08, size: 0x3c
    // 0xd04a08: EnterFrame
    //     0xd04a08: stp             fp, lr, [SP, #-0x10]!
    //     0xd04a0c: mov             fp, SP
    // 0xd04a10: CheckStackOverflow
    //     0xd04a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04a14: cmp             SP, x16
    //     0xd04a18: b.ls            #0xd04a3c
    // 0xd04a1c: LoadField: r0 = r1->field_7
    //     0xd04a1c: ldur            w0, [x1, #7]
    // 0xd04a20: DecompressPointer r0
    //     0xd04a20: add             x0, x0, HEAP, lsl #32
    // 0xd04a24: mov             x1, x0
    // 0xd04a28: r0 = add()
    //     0xd04a28: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd04a2c: r0 = Null
    //     0xd04a2c: mov             x0, NULL
    // 0xd04a30: LeaveFrame
    //     0xd04a30: mov             SP, fp
    //     0xd04a34: ldp             fp, lr, [SP], #0x10
    // 0xd04a38: ret
    //     0xd04a38: ret             
    // 0xd04a3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04a3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd04a40: b               #0xd04a1c
  }
}

// class id: 4573, size: 0x8, field offset: 0x8
abstract class PaintingBinding extends _MixinApplication194&BindingBase&ServicesBinding {

  get _ instance(/* No info */) {
    // ** addr: 0xc06878, size: 0x20
    // 0xc06878: r0 = LoadStaticField(0x780)
    //     0xc06878: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc0687c: ldr             x0, [x0, #0xf00]
    // 0xc06880: cmp             w0, NULL
    // 0xc06884: b.eq            #0xc0688c
    // 0xc06888: ret
    //     0xc06888: ret             
    // 0xc0688c: EnterFrame
    //     0xc0688c: stp             fp, lr, [SP, #-0x10]!
    //     0xc06890: mov             fp, SP
    // 0xc06894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc06894: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
