// lib: , url: package:flutter/src/painting/gradient.dart

// class id: 1048996, size: 0x8
class :: {

  static _ _interpolateColorsAndStops(/* No info */) {
    // ** addr: 0x1161a6c, size: 0x168
    // 0x1161a6c: EnterFrame
    //     0x1161a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1161a70: mov             fp, SP
    // 0x1161a74: AllocStack(0x48)
    //     0x1161a74: sub             SP, SP, #0x48
    // 0x1161a78: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1161a78: stur            x1, [fp, #-8]
    //     0x1161a7c: stur            x2, [fp, #-0x10]
    //     0x1161a80: stur            x3, [fp, #-0x18]
    //     0x1161a84: stur            x5, [fp, #-0x20]
    //     0x1161a88: stur            d0, [fp, #-0x30]
    // 0x1161a8c: CheckStackOverflow
    //     0x1161a8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1161a90: cmp             SP, x16
    //     0x1161a94: b.ls            #0x1161bb4
    // 0x1161a98: r1 = 5
    //     0x1161a98: mov             x1, #5
    // 0x1161a9c: r0 = AllocateContext()
    //     0x1161a9c: bl              #0x13de838  ; AllocateContextStub
    // 0x1161aa0: mov             x2, x0
    // 0x1161aa4: ldur            x0, [fp, #-8]
    // 0x1161aa8: stur            x2, [fp, #-0x28]
    // 0x1161aac: StoreField: r2->field_f = r0
    //     0x1161aac: stur            w0, [x2, #0xf]
    // 0x1161ab0: ldur            x0, [fp, #-0x10]
    // 0x1161ab4: StoreField: r2->field_13 = r0
    //     0x1161ab4: stur            w0, [x2, #0x13]
    // 0x1161ab8: ldur            x0, [fp, #-0x18]
    // 0x1161abc: ArrayStore: r2[0] = r0  ; List_4
    //     0x1161abc: stur            w0, [x2, #0x17]
    // 0x1161ac0: ldur            x0, [fp, #-0x20]
    // 0x1161ac4: StoreField: r2->field_1b = r0
    //     0x1161ac4: stur            w0, [x2, #0x1b]
    // 0x1161ac8: ldur            d0, [fp, #-0x30]
    // 0x1161acc: r0 = inline_Allocate_Double()
    //     0x1161acc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1161ad0: add             x0, x0, #0x10
    //     0x1161ad4: cmp             x1, x0
    //     0x1161ad8: b.ls            #0x1161bbc
    //     0x1161adc: str             x0, [THR, #0x60]  ; THR::top
    //     0x1161ae0: sub             x0, x0, #0xf
    //     0x1161ae4: mov             x1, #0xe19c
    //     0x1161ae8: movk            x1, #3, lsl #16
    //     0x1161aec: stur            x1, [x0, #-1]
    // 0x1161af0: dmb             ishst
    // 0x1161af4: StoreField: r0->field_7 = d0
    //     0x1161af4: stur            d0, [x0, #7]
    // 0x1161af8: StoreField: r2->field_1f = r0
    //     0x1161af8: stur            w0, [x2, #0x1f]
    // 0x1161afc: r1 = <double, _SplayTreeSetNode<double>, double>
    //     0x1161afc: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3970] TypeArguments: <double, _SplayTreeSetNode<double>, double>
    //     0x1161b00: ldr             x1, [x1, #0x970]
    // 0x1161b04: r0 = SplayTreeSet()
    //     0x1161b04: bl              #0xafd468  ; AllocateSplayTreeSetStub -> SplayTreeSet<C2X0> (size=0x30)
    // 0x1161b08: mov             x1, x0
    // 0x1161b0c: stur            x0, [fp, #-8]
    // 0x1161b10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1161b10: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1161b14: r0 = SplayTreeSet()
    //     0x1161b14: bl              #0x1161be0  ; [dart:collection] SplayTreeSet::SplayTreeSet
    // 0x1161b18: ldur            x0, [fp, #-0x28]
    // 0x1161b1c: LoadField: r2 = r0->field_13
    //     0x1161b1c: ldur            w2, [x0, #0x13]
    // 0x1161b20: DecompressPointer r2
    //     0x1161b20: add             x2, x2, HEAP, lsl #32
    // 0x1161b24: ldur            x1, [fp, #-8]
    // 0x1161b28: r0 = addAll()
    //     0x1161b28: bl              #0x116d828  ; [dart:collection] SplayTreeSet::addAll
    // 0x1161b2c: ldur            x0, [fp, #-0x28]
    // 0x1161b30: LoadField: r2 = r0->field_1b
    //     0x1161b30: ldur            w2, [x0, #0x1b]
    // 0x1161b34: DecompressPointer r2
    //     0x1161b34: add             x2, x2, HEAP, lsl #32
    // 0x1161b38: ldur            x1, [fp, #-8]
    // 0x1161b3c: r0 = addAll()
    //     0x1161b3c: bl              #0x116d828  ; [dart:collection] SplayTreeSet::addAll
    // 0x1161b40: ldur            x2, [fp, #-8]
    // 0x1161b44: r1 = <double, _SplayTreeSetNode<double>, double>
    //     0x1161b44: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3970] TypeArguments: <double, _SplayTreeSetNode<double>, double>
    //     0x1161b48: ldr             x1, [x1, #0x970]
    // 0x1161b4c: r0 = _List.of()
    //     0x1161b4c: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0x1161b50: ldur            x2, [fp, #-0x28]
    // 0x1161b54: r1 = Function '<anonymous closure>': static.
    //     0x1161b54: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3978] AnonymousClosure: static (0x1161ce8), in [package:flutter/src/painting/gradient.dart] ::_interpolateColorsAndStops (0x1161a6c)
    //     0x1161b58: ldr             x1, [x1, #0x978]
    // 0x1161b5c: stur            x0, [fp, #-8]
    // 0x1161b60: r0 = AllocateClosure()
    //     0x1161b60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1161b64: r16 = <Color>
    //     0x1161b64: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1161b68: ldr             x16, [x16, #0xa90]
    // 0x1161b6c: ldur            lr, [fp, #-8]
    // 0x1161b70: stp             lr, x16, [SP, #8]
    // 0x1161b74: str             x0, [SP]
    // 0x1161b78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1161b78: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1161b7c: r0 = map()
    //     0x1161b7c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1161b80: LoadField: r1 = r0->field_7
    //     0x1161b80: ldur            w1, [x0, #7]
    // 0x1161b84: DecompressPointer r1
    //     0x1161b84: add             x1, x1, HEAP, lsl #32
    // 0x1161b88: mov             x2, x0
    // 0x1161b8c: r0 = _List.of()
    //     0x1161b8c: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0x1161b90: stur            x0, [fp, #-0x10]
    // 0x1161b94: r0 = _ColorsAndStops()
    //     0x1161b94: bl              #0x1161bd4  ; Allocate_ColorsAndStopsStub -> _ColorsAndStops (size=0x10)
    // 0x1161b98: ldur            x1, [fp, #-0x10]
    // 0x1161b9c: StoreField: r0->field_7 = r1
    //     0x1161b9c: stur            w1, [x0, #7]
    // 0x1161ba0: ldur            x1, [fp, #-8]
    // 0x1161ba4: StoreField: r0->field_b = r1
    //     0x1161ba4: stur            w1, [x0, #0xb]
    // 0x1161ba8: LeaveFrame
    //     0x1161ba8: mov             SP, fp
    //     0x1161bac: ldp             fp, lr, [SP], #0x10
    // 0x1161bb0: ret
    //     0x1161bb0: ret             
    // 0x1161bb4: r0 = StackOverflowSharedWithFPURegs()
    //     0x1161bb4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1161bb8: b               #0x1161a98
    // 0x1161bbc: SaveReg d0
    //     0x1161bbc: str             q0, [SP, #-0x10]!
    // 0x1161bc0: SaveReg r2
    //     0x1161bc0: str             x2, [SP, #-8]!
    // 0x1161bc4: r0 = AllocateDouble()
    //     0x1161bc4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161bc8: RestoreReg r2
    //     0x1161bc8: ldr             x2, [SP], #8
    // 0x1161bcc: RestoreReg d0
    //     0x1161bcc: ldr             q0, [SP], #0x10
    // 0x1161bd0: b               #0x1161af4
  }
  [closure] static Color <anonymous closure>(dynamic, double) {
    // ** addr: 0x1161ce8, size: 0xa0
    // 0x1161ce8: EnterFrame
    //     0x1161ce8: stp             fp, lr, [SP, #-0x10]!
    //     0x1161cec: mov             fp, SP
    // 0x1161cf0: AllocStack(0x18)
    //     0x1161cf0: sub             SP, SP, #0x18
    // 0x1161cf4: SetupParameters([dynamic _ /* r0 */])
    //     0x1161cf4: ldr             x0, [fp, #0x18]
    //     0x1161cf8: ldur            w3, [x0, #0x17]
    //     0x1161cfc: add             x3, x3, HEAP, lsl #32
    //     0x1161d00: stur            x3, [fp, #-8]
    // 0x1161d04: CheckStackOverflow
    //     0x1161d04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1161d08: cmp             SP, x16
    //     0x1161d0c: b.ls            #0x1161d80
    // 0x1161d10: LoadField: r1 = r3->field_f
    //     0x1161d10: ldur            w1, [x3, #0xf]
    // 0x1161d14: DecompressPointer r1
    //     0x1161d14: add             x1, x1, HEAP, lsl #32
    // 0x1161d18: LoadField: r2 = r3->field_13
    //     0x1161d18: ldur            w2, [x3, #0x13]
    // 0x1161d1c: DecompressPointer r2
    //     0x1161d1c: add             x2, x2, HEAP, lsl #32
    // 0x1161d20: ldr             x0, [fp, #0x10]
    // 0x1161d24: LoadField: d1 = r0->field_7
    //     0x1161d24: ldur            d1, [x0, #7]
    // 0x1161d28: mov             v0.16b, v1.16b
    // 0x1161d2c: stur            d1, [fp, #-0x18]
    // 0x1161d30: r0 = _sample()
    //     0x1161d30: bl              #0x1161d88  ; [package:flutter/src/painting/gradient.dart] ::_sample
    // 0x1161d34: mov             x3, x0
    // 0x1161d38: ldur            x0, [fp, #-8]
    // 0x1161d3c: stur            x3, [fp, #-0x10]
    // 0x1161d40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1161d40: ldur            w1, [x0, #0x17]
    // 0x1161d44: DecompressPointer r1
    //     0x1161d44: add             x1, x1, HEAP, lsl #32
    // 0x1161d48: LoadField: r2 = r0->field_1b
    //     0x1161d48: ldur            w2, [x0, #0x1b]
    // 0x1161d4c: DecompressPointer r2
    //     0x1161d4c: add             x2, x2, HEAP, lsl #32
    // 0x1161d50: ldur            d0, [fp, #-0x18]
    // 0x1161d54: r0 = _sample()
    //     0x1161d54: bl              #0x1161d88  ; [package:flutter/src/painting/gradient.dart] ::_sample
    // 0x1161d58: mov             x1, x0
    // 0x1161d5c: ldur            x0, [fp, #-8]
    // 0x1161d60: LoadField: r3 = r0->field_1f
    //     0x1161d60: ldur            w3, [x0, #0x1f]
    // 0x1161d64: DecompressPointer r3
    //     0x1161d64: add             x3, x3, HEAP, lsl #32
    // 0x1161d68: mov             x2, x1
    // 0x1161d6c: ldur            x1, [fp, #-0x10]
    // 0x1161d70: r0 = lerp()
    //     0x1161d70: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1161d74: LeaveFrame
    //     0x1161d74: mov             SP, fp
    //     0x1161d78: ldp             fp, lr, [SP], #0x10
    // 0x1161d7c: ret
    //     0x1161d7c: ret             
    // 0x1161d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1161d80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1161d84: b               #0x1161d10
  }
  static _ _sample(/* No info */) {
    // ** addr: 0x1161d88, size: 0x34c
    // 0x1161d88: EnterFrame
    //     0x1161d88: stp             fp, lr, [SP, #-0x10]!
    //     0x1161d8c: mov             fp, SP
    // 0x1161d90: AllocStack(0x58)
    //     0x1161d90: sub             SP, SP, #0x58
    // 0x1161d94: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0x1161d94: mov             x0, x1
    //     0x1161d98: stur            x1, [fp, #-0x10]
    //     0x1161d9c: mov             x1, x2
    //     0x1161da0: stur            x2, [fp, #-0x18]
    //     0x1161da4: stur            d0, [fp, #-0x48]
    // 0x1161da8: CheckStackOverflow
    //     0x1161da8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1161dac: cmp             SP, x16
    //     0x1161db0: b.ls            #0x116209c
    // 0x1161db4: r2 = inline_Allocate_Double()
    //     0x1161db4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1161db8: add             x2, x2, #0x10
    //     0x1161dbc: cmp             x3, x2
    //     0x1161dc0: b.ls            #0x11620a4
    //     0x1161dc4: str             x2, [THR, #0x60]  ; THR::top
    //     0x1161dc8: sub             x2, x2, #0xf
    //     0x1161dcc: mov             x3, #0xe19c
    //     0x1161dd0: movk            x3, #3, lsl #16
    //     0x1161dd4: stur            x3, [x2, #-1]
    // 0x1161dd8: dmb             ishst
    // 0x1161ddc: StoreField: r2->field_7 = d0
    //     0x1161ddc: stur            d0, [x2, #7]
    // 0x1161de0: stur            x2, [fp, #-8]
    // 0x1161de4: r1 = 1
    //     0x1161de4: mov             x1, #1
    // 0x1161de8: r0 = AllocateContext()
    //     0x1161de8: bl              #0x13de838  ; AllocateContextStub
    // 0x1161dec: mov             x2, x0
    // 0x1161df0: ldur            x0, [fp, #-8]
    // 0x1161df4: stur            x2, [fp, #-0x20]
    // 0x1161df8: StoreField: r2->field_f = r0
    //     0x1161df8: stur            w0, [x2, #0xf]
    // 0x1161dfc: ldur            x3, [fp, #-0x18]
    // 0x1161e00: r0 = LoadClassIdInstr(r3)
    //     0x1161e00: ldur            x0, [x3, #-1]
    //     0x1161e04: ubfx            x0, x0, #0xc, #0x14
    // 0x1161e08: mov             x1, x3
    // 0x1161e0c: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x1161e0c: mov             x17, #0x27b5
    //     0x1161e10: movk            x17, #1, lsl #16
    //     0x1161e14: add             lr, x0, x17
    //     0x1161e18: ldr             lr, [x21, lr, lsl #3]
    //     0x1161e1c: blr             lr
    // 0x1161e20: LoadField: d0 = r0->field_7
    //     0x1161e20: ldur            d0, [x0, #7]
    // 0x1161e24: ldur            d1, [fp, #-0x48]
    // 0x1161e28: fcmp            d0, d1
    // 0x1161e2c: b.lt            #0x1161e60
    // 0x1161e30: ldur            x2, [fp, #-0x10]
    // 0x1161e34: r0 = LoadClassIdInstr(r2)
    //     0x1161e34: ldur            x0, [x2, #-1]
    //     0x1161e38: ubfx            x0, x0, #0xc, #0x14
    // 0x1161e3c: mov             x1, x2
    // 0x1161e40: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x1161e40: mov             x17, #0x27b5
    //     0x1161e44: movk            x17, #1, lsl #16
    //     0x1161e48: add             lr, x0, x17
    //     0x1161e4c: ldr             lr, [x21, lr, lsl #3]
    //     0x1161e50: blr             lr
    // 0x1161e54: LeaveFrame
    //     0x1161e54: mov             SP, fp
    //     0x1161e58: ldp             fp, lr, [SP], #0x10
    // 0x1161e5c: ret
    //     0x1161e5c: ret             
    // 0x1161e60: ldur            x2, [fp, #-0x10]
    // 0x1161e64: ldur            x4, [fp, #-0x18]
    // 0x1161e68: ldur            x3, [fp, #-0x20]
    // 0x1161e6c: LoadField: r5 = r3->field_f
    //     0x1161e6c: ldur            w5, [x3, #0xf]
    // 0x1161e70: DecompressPointer r5
    //     0x1161e70: add             x5, x5, HEAP, lsl #32
    // 0x1161e74: stur            x5, [fp, #-8]
    // 0x1161e78: r0 = LoadClassIdInstr(r4)
    //     0x1161e78: ldur            x0, [x4, #-1]
    //     0x1161e7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1161e80: mov             x1, x4
    // 0x1161e84: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x1161e84: mov             x17, #0x40c8
    //     0x1161e88: movk            x17, #1, lsl #16
    //     0x1161e8c: add             lr, x0, x17
    //     0x1161e90: ldr             lr, [x21, lr, lsl #3]
    //     0x1161e94: blr             lr
    // 0x1161e98: mov             x1, x0
    // 0x1161e9c: ldur            x0, [fp, #-8]
    // 0x1161ea0: LoadField: d0 = r0->field_7
    //     0x1161ea0: ldur            d0, [x0, #7]
    // 0x1161ea4: LoadField: d1 = r1->field_7
    //     0x1161ea4: ldur            d1, [x1, #7]
    // 0x1161ea8: fcmp            d0, d1
    // 0x1161eac: b.lt            #0x1161ee8
    // 0x1161eb0: ldur            x0, [fp, #-0x10]
    // 0x1161eb4: r1 = LoadClassIdInstr(r0)
    //     0x1161eb4: ldur            x1, [x0, #-1]
    //     0x1161eb8: ubfx            x1, x1, #0xc, #0x14
    // 0x1161ebc: mov             x16, x0
    // 0x1161ec0: mov             x0, x1
    // 0x1161ec4: mov             x1, x16
    // 0x1161ec8: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x1161ec8: mov             x17, #0x40c8
    //     0x1161ecc: movk            x17, #1, lsl #16
    //     0x1161ed0: add             lr, x0, x17
    //     0x1161ed4: ldr             lr, [x21, lr, lsl #3]
    //     0x1161ed8: blr             lr
    // 0x1161edc: LeaveFrame
    //     0x1161edc: mov             SP, fp
    //     0x1161ee0: ldp             fp, lr, [SP], #0x10
    // 0x1161ee4: ret
    //     0x1161ee4: ret             
    // 0x1161ee8: ldur            x0, [fp, #-0x10]
    // 0x1161eec: ldur            x4, [fp, #-0x18]
    // 0x1161ef0: ldur            x3, [fp, #-0x20]
    // 0x1161ef4: mov             x2, x3
    // 0x1161ef8: r1 = Function '<anonymous closure>': static.
    //     0x1161ef8: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3980] AnonymousClosure: static (0x11621d0), in [package:flutter/src/painting/gradient.dart] ::_sample (0x1161d88)
    //     0x1161efc: ldr             x1, [x1, #0x980]
    // 0x1161f00: r0 = AllocateClosure()
    //     0x1161f00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1161f04: ldur            x1, [fp, #-0x18]
    // 0x1161f08: mov             x2, x0
    // 0x1161f0c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1161f0c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1161f10: r0 = lastIndexWhere()
    //     0x1161f10: bl              #0x11620d4  ; [dart:collection] ListBase::lastIndexWhere
    // 0x1161f14: mov             x2, x0
    // 0x1161f18: stur            x2, [fp, #-0x28]
    // 0x1161f1c: r0 = BoxInt64Instr(r2)
    //     0x1161f1c: sbfiz           x0, x2, #1, #0x1f
    //     0x1161f20: cmp             x2, x0, asr #1
    //     0x1161f24: b.eq            #0x1161f30
    //     0x1161f28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1161f2c: stur            x2, [x0, #7]
    // 0x1161f30: mov             x3, x0
    // 0x1161f34: ldur            x1, [fp, #-0x10]
    // 0x1161f38: stur            x3, [fp, #-8]
    // 0x1161f3c: r0 = LoadClassIdInstr(r1)
    //     0x1161f3c: ldur            x0, [x1, #-1]
    //     0x1161f40: ubfx            x0, x0, #0xc, #0x14
    // 0x1161f44: stp             x3, x1, [SP]
    // 0x1161f48: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1161f48: sub             lr, x0, #0xdfd
    //     0x1161f4c: ldr             lr, [x21, lr, lsl #3]
    //     0x1161f50: blr             lr
    // 0x1161f54: mov             x2, x0
    // 0x1161f58: ldur            x0, [fp, #-0x28]
    // 0x1161f5c: stur            x2, [fp, #-0x38]
    // 0x1161f60: add             x3, x0, #1
    // 0x1161f64: r0 = BoxInt64Instr(r3)
    //     0x1161f64: sbfiz           x0, x3, #1, #0x1f
    //     0x1161f68: cmp             x3, x0, asr #1
    //     0x1161f6c: b.eq            #0x1161f78
    //     0x1161f70: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1161f74: stur            x3, [x0, #7]
    // 0x1161f78: mov             x1, x0
    // 0x1161f7c: ldur            x0, [fp, #-0x10]
    // 0x1161f80: stur            x1, [fp, #-0x30]
    // 0x1161f84: r3 = LoadClassIdInstr(r0)
    //     0x1161f84: ldur            x3, [x0, #-1]
    //     0x1161f88: ubfx            x3, x3, #0xc, #0x14
    // 0x1161f8c: stp             x1, x0, [SP]
    // 0x1161f90: mov             x0, x3
    // 0x1161f94: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1161f94: sub             lr, x0, #0xdfd
    //     0x1161f98: ldr             lr, [x21, lr, lsl #3]
    //     0x1161f9c: blr             lr
    // 0x1161fa0: mov             x1, x0
    // 0x1161fa4: ldur            x0, [fp, #-0x20]
    // 0x1161fa8: stur            x1, [fp, #-0x40]
    // 0x1161fac: LoadField: r2 = r0->field_f
    //     0x1161fac: ldur            w2, [x0, #0xf]
    // 0x1161fb0: DecompressPointer r2
    //     0x1161fb0: add             x2, x2, HEAP, lsl #32
    // 0x1161fb4: ldur            x3, [fp, #-0x18]
    // 0x1161fb8: stur            x2, [fp, #-0x10]
    // 0x1161fbc: r0 = LoadClassIdInstr(r3)
    //     0x1161fbc: ldur            x0, [x3, #-1]
    //     0x1161fc0: ubfx            x0, x0, #0xc, #0x14
    // 0x1161fc4: ldur            x16, [fp, #-8]
    // 0x1161fc8: stp             x16, x3, [SP]
    // 0x1161fcc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1161fcc: sub             lr, x0, #0xdfd
    //     0x1161fd0: ldr             lr, [x21, lr, lsl #3]
    //     0x1161fd4: blr             lr
    // 0x1161fd8: mov             x1, x0
    // 0x1161fdc: ldur            x0, [fp, #-0x10]
    // 0x1161fe0: LoadField: d0 = r0->field_7
    //     0x1161fe0: ldur            d0, [x0, #7]
    // 0x1161fe4: LoadField: d1 = r1->field_7
    //     0x1161fe4: ldur            d1, [x1, #7]
    // 0x1161fe8: fsub            d2, d0, d1
    // 0x1161fec: ldur            x1, [fp, #-0x18]
    // 0x1161ff0: stur            d2, [fp, #-0x48]
    // 0x1161ff4: r0 = LoadClassIdInstr(r1)
    //     0x1161ff4: ldur            x0, [x1, #-1]
    //     0x1161ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x1161ffc: ldur            x16, [fp, #-0x30]
    // 0x1162000: stp             x16, x1, [SP]
    // 0x1162004: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1162004: sub             lr, x0, #0xdfd
    //     0x1162008: ldr             lr, [x21, lr, lsl #3]
    //     0x116200c: blr             lr
    // 0x1162010: mov             x1, x0
    // 0x1162014: ldur            x0, [fp, #-0x18]
    // 0x1162018: stur            x1, [fp, #-0x10]
    // 0x116201c: r2 = LoadClassIdInstr(r0)
    //     0x116201c: ldur            x2, [x0, #-1]
    //     0x1162020: ubfx            x2, x2, #0xc, #0x14
    // 0x1162024: ldur            x16, [fp, #-8]
    // 0x1162028: stp             x16, x0, [SP]
    // 0x116202c: mov             x0, x2
    // 0x1162030: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1162030: sub             lr, x0, #0xdfd
    //     0x1162034: ldr             lr, [x21, lr, lsl #3]
    //     0x1162038: blr             lr
    // 0x116203c: mov             x1, x0
    // 0x1162040: ldur            x0, [fp, #-0x10]
    // 0x1162044: LoadField: d0 = r0->field_7
    //     0x1162044: ldur            d0, [x0, #7]
    // 0x1162048: LoadField: d1 = r1->field_7
    //     0x1162048: ldur            d1, [x1, #7]
    // 0x116204c: fsub            d2, d0, d1
    // 0x1162050: ldur            d0, [fp, #-0x48]
    // 0x1162054: fdiv            d1, d0, d2
    // 0x1162058: r3 = inline_Allocate_Double()
    //     0x1162058: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x116205c: add             x3, x3, #0x10
    //     0x1162060: cmp             x0, x3
    //     0x1162064: b.ls            #0x11620c0
    //     0x1162068: str             x3, [THR, #0x60]  ; THR::top
    //     0x116206c: sub             x3, x3, #0xf
    //     0x1162070: mov             x0, #0xe19c
    //     0x1162074: movk            x0, #3, lsl #16
    //     0x1162078: stur            x0, [x3, #-1]
    // 0x116207c: dmb             ishst
    // 0x1162080: StoreField: r3->field_7 = d1
    //     0x1162080: stur            d1, [x3, #7]
    // 0x1162084: ldur            x1, [fp, #-0x38]
    // 0x1162088: ldur            x2, [fp, #-0x40]
    // 0x116208c: r0 = lerp()
    //     0x116208c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1162090: LeaveFrame
    //     0x1162090: mov             SP, fp
    //     0x1162094: ldp             fp, lr, [SP], #0x10
    // 0x1162098: ret
    //     0x1162098: ret             
    // 0x116209c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116209c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11620a0: b               #0x1161db4
    // 0x11620a4: SaveReg d0
    //     0x11620a4: str             q0, [SP, #-0x10]!
    // 0x11620a8: stp             x0, x1, [SP, #-0x10]!
    // 0x11620ac: r0 = AllocateDouble()
    //     0x11620ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11620b0: mov             x2, x0
    // 0x11620b4: ldp             x0, x1, [SP], #0x10
    // 0x11620b8: RestoreReg d0
    //     0x11620b8: ldr             q0, [SP], #0x10
    // 0x11620bc: b               #0x1161ddc
    // 0x11620c0: SaveReg d1
    //     0x11620c0: str             q1, [SP, #-0x10]!
    // 0x11620c4: r0 = AllocateDouble()
    //     0x11620c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11620c8: mov             x3, x0
    // 0x11620cc: RestoreReg d1
    //     0x11620cc: ldr             q1, [SP], #0x10
    // 0x11620d0: b               #0x1162080
  }
  [closure] static bool <anonymous closure>(dynamic, double) {
    // ** addr: 0x11621d0, size: 0x34
    // 0x11621d0: ldr             x1, [SP, #8]
    // 0x11621d4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x11621d4: ldur            w2, [x1, #0x17]
    // 0x11621d8: DecompressPointer r2
    //     0x11621d8: add             x2, x2, HEAP, lsl #32
    // 0x11621dc: LoadField: r1 = r2->field_f
    //     0x11621dc: ldur            w1, [x2, #0xf]
    // 0x11621e0: DecompressPointer r1
    //     0x11621e0: add             x1, x1, HEAP, lsl #32
    // 0x11621e4: ldr             x2, [SP]
    // 0x11621e8: LoadField: d0 = r2->field_7
    //     0x11621e8: ldur            d0, [x2, #7]
    // 0x11621ec: LoadField: d1 = r1->field_7
    //     0x11621ec: ldur            d1, [x1, #7]
    // 0x11621f0: fcmp            d1, d0
    // 0x11621f4: r16 = true
    //     0x11621f4: add             x16, NULL, #0x20  ; true
    // 0x11621f8: r17 = false
    //     0x11621f8: add             x17, NULL, #0x30  ; false
    // 0x11621fc: csel            x0, x16, x17, ge
    // 0x1162200: ret
    //     0x1162200: ret             
  }
}

// class id: 2930, size: 0x14, field offset: 0x8
//   const constructor, 
abstract class Gradient extends Object {

  static _ lerp(/* No info */) {
    // ** addr: 0x115ffa0, size: 0xad4
    // 0x115ffa0: EnterFrame
    //     0x115ffa0: stp             fp, lr, [SP, #-0x10]!
    //     0x115ffa4: mov             fp, SP
    // 0x115ffa8: AllocStack(0x68)
    //     0x115ffa8: sub             SP, SP, #0x68
    // 0x115ffac: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0x115ffac: mov             x4, x1
    //     0x115ffb0: mov             x3, x2
    //     0x115ffb4: stur            x1, [fp, #-8]
    //     0x115ffb8: stur            x2, [fp, #-0x10]
    //     0x115ffbc: stur            d0, [fp, #-0x40]
    // 0x115ffc0: CheckStackOverflow
    //     0x115ffc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115ffc4: cmp             SP, x16
    //     0x115ffc8: b.ls            #0x11609f4
    // 0x115ffcc: cmp             w4, w3
    // 0x115ffd0: b.ne            #0x115ffe4
    // 0x115ffd4: mov             x0, x4
    // 0x115ffd8: LeaveFrame
    //     0x115ffd8: mov             SP, fp
    //     0x115ffdc: ldp             fp, lr, [SP], #0x10
    // 0x115ffe0: ret
    //     0x115ffe0: ret             
    // 0x115ffe4: cmp             w3, NULL
    // 0x115ffe8: b.eq            #0x11600a4
    // 0x115ffec: r0 = LoadClassIdInstr(r3)
    //     0x115ffec: ldur            x0, [x3, #-1]
    //     0x115fff0: ubfx            x0, x0, #0xc, #0x14
    // 0x115fff4: cmp             x0, #0xb73
    // 0x115fff8: b.ne            #0x1160050
    // 0x115fffc: mov             x0, x4
    // 0x1160000: r2 = Null
    //     0x1160000: mov             x2, NULL
    // 0x1160004: r1 = Null
    //     0x1160004: mov             x1, NULL
    // 0x1160008: cmp             w0, NULL
    // 0x116000c: b.eq            #0x116002c
    // 0x1160010: branchIfSmi(r0, 0x1160024)
    //     0x1160010: tbz             w0, #0, #0x1160024
    // 0x1160014: r3 = LoadClassIdInstr(r0)
    //     0x1160014: ldur            x3, [x0, #-1]
    //     0x1160018: ubfx            x3, x3, #0xc, #0x14
    // 0x116001c: cmp             x3, #0xb73
    // 0x1160020: b.eq            #0x116002c
    // 0x1160024: r0 = false
    //     0x1160024: add             x0, NULL, #0x30  ; false
    // 0x1160028: b               #0x1160030
    // 0x116002c: r0 = true
    //     0x116002c: add             x0, NULL, #0x20  ; true
    // 0x1160030: tbnz            w0, #4, #0x1160048
    // 0x1160034: ldur            x1, [fp, #-8]
    // 0x1160038: ldur            x2, [fp, #-0x10]
    // 0x116003c: ldur            d0, [fp, #-0x40]
    // 0x1160040: r0 = lerp()
    //     0x1160040: bl              #0x1162380  ; [package:flutter/src/painting/gradient.dart] SweepGradient::lerp
    // 0x1160044: b               #0x11600a8
    // 0x1160048: r0 = Null
    //     0x1160048: mov             x0, NULL
    // 0x116004c: b               #0x11600a8
    // 0x1160050: ldur            x0, [fp, #-8]
    // 0x1160054: r2 = Null
    //     0x1160054: mov             x2, NULL
    // 0x1160058: r1 = Null
    //     0x1160058: mov             x1, NULL
    // 0x116005c: cmp             w0, NULL
    // 0x1160060: b.eq            #0x1160080
    // 0x1160064: branchIfSmi(r0, 0x1160078)
    //     0x1160064: tbz             w0, #0, #0x1160078
    // 0x1160068: r3 = LoadClassIdInstr(r0)
    //     0x1160068: ldur            x3, [x0, #-1]
    //     0x116006c: ubfx            x3, x3, #0xc, #0x14
    // 0x1160070: cmp             x3, #0xb74
    // 0x1160074: b.eq            #0x1160080
    // 0x1160078: r0 = false
    //     0x1160078: add             x0, NULL, #0x30  ; false
    // 0x116007c: b               #0x1160084
    // 0x1160080: r0 = true
    //     0x1160080: add             x0, NULL, #0x20  ; true
    // 0x1160084: tbnz            w0, #4, #0x116009c
    // 0x1160088: ldur            x1, [fp, #-8]
    // 0x116008c: ldur            x2, [fp, #-0x10]
    // 0x1160090: ldur            d0, [fp, #-0x40]
    // 0x1160094: r0 = lerp()
    //     0x1160094: bl              #0x1160a80  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerp
    // 0x1160098: b               #0x11600a8
    // 0x116009c: r0 = Null
    //     0x116009c: mov             x0, NULL
    // 0x11600a0: b               #0x11600a8
    // 0x11600a4: r0 = Null
    //     0x11600a4: mov             x0, NULL
    // 0x11600a8: cmp             w0, NULL
    // 0x11600ac: b.ne            #0x1160170
    // 0x11600b0: ldur            x3, [fp, #-8]
    // 0x11600b4: cmp             w3, NULL
    // 0x11600b8: b.eq            #0x1160170
    // 0x11600bc: r0 = LoadClassIdInstr(r3)
    //     0x11600bc: ldur            x0, [x3, #-1]
    //     0x11600c0: ubfx            x0, x0, #0xc, #0x14
    // 0x11600c4: cmp             x0, #0xb73
    // 0x11600c8: b.ne            #0x1160120
    // 0x11600cc: ldur            x0, [fp, #-0x10]
    // 0x11600d0: r2 = Null
    //     0x11600d0: mov             x2, NULL
    // 0x11600d4: r1 = Null
    //     0x11600d4: mov             x1, NULL
    // 0x11600d8: cmp             w0, NULL
    // 0x11600dc: b.eq            #0x11600fc
    // 0x11600e0: branchIfSmi(r0, 0x11600f4)
    //     0x11600e0: tbz             w0, #0, #0x11600f4
    // 0x11600e4: r3 = LoadClassIdInstr(r0)
    //     0x11600e4: ldur            x3, [x0, #-1]
    //     0x11600e8: ubfx            x3, x3, #0xc, #0x14
    // 0x11600ec: cmp             x3, #0xb73
    // 0x11600f0: b.eq            #0x11600fc
    // 0x11600f4: r0 = false
    //     0x11600f4: add             x0, NULL, #0x30  ; false
    // 0x11600f8: b               #0x1160100
    // 0x11600fc: r0 = true
    //     0x11600fc: add             x0, NULL, #0x20  ; true
    // 0x1160100: tbnz            w0, #4, #0x1160118
    // 0x1160104: ldur            x1, [fp, #-8]
    // 0x1160108: ldur            x2, [fp, #-0x10]
    // 0x116010c: ldur            d0, [fp, #-0x40]
    // 0x1160110: r0 = lerp()
    //     0x1160110: bl              #0x1162380  ; [package:flutter/src/painting/gradient.dart] SweepGradient::lerp
    // 0x1160114: b               #0x1160170
    // 0x1160118: r0 = Null
    //     0x1160118: mov             x0, NULL
    // 0x116011c: b               #0x1160170
    // 0x1160120: ldur            x0, [fp, #-0x10]
    // 0x1160124: r2 = Null
    //     0x1160124: mov             x2, NULL
    // 0x1160128: r1 = Null
    //     0x1160128: mov             x1, NULL
    // 0x116012c: cmp             w0, NULL
    // 0x1160130: b.eq            #0x1160150
    // 0x1160134: branchIfSmi(r0, 0x1160148)
    //     0x1160134: tbz             w0, #0, #0x1160148
    // 0x1160138: r3 = LoadClassIdInstr(r0)
    //     0x1160138: ldur            x3, [x0, #-1]
    //     0x116013c: ubfx            x3, x3, #0xc, #0x14
    // 0x1160140: cmp             x3, #0xb74
    // 0x1160144: b.eq            #0x1160150
    // 0x1160148: r0 = false
    //     0x1160148: add             x0, NULL, #0x30  ; false
    // 0x116014c: b               #0x1160154
    // 0x1160150: r0 = true
    //     0x1160150: add             x0, NULL, #0x20  ; true
    // 0x1160154: tbnz            w0, #4, #0x116016c
    // 0x1160158: ldur            x1, [fp, #-8]
    // 0x116015c: ldur            x2, [fp, #-0x10]
    // 0x1160160: ldur            d0, [fp, #-0x40]
    // 0x1160164: r0 = lerp()
    //     0x1160164: bl              #0x1160a80  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerp
    // 0x1160168: b               #0x1160170
    // 0x116016c: r0 = Null
    //     0x116016c: mov             x0, NULL
    // 0x1160170: cmp             w0, NULL
    // 0x1160174: b.eq            #0x1160184
    // 0x1160178: LeaveFrame
    //     0x1160178: mov             SP, fp
    //     0x116017c: ldp             fp, lr, [SP], #0x10
    // 0x1160180: ret
    //     0x1160180: ret             
    // 0x1160184: ldur            d0, [fp, #-0x40]
    // 0x1160188: d1 = 0.500000
    //     0x1160188: fmov            d1, #0.50000000
    // 0x116018c: fcmp            d1, d0
    // 0x1160190: b.le            #0x11605c0
    // 0x1160194: ldur            x0, [fp, #-8]
    // 0x1160198: d2 = 2.000000
    //     0x1160198: fmov            d2, #2.00000000
    // 0x116019c: d1 = 1.000000
    //     0x116019c: fmov            d1, #1.00000000
    // 0x11601a0: cmp             w0, NULL
    // 0x11601a4: b.eq            #0x11609fc
    // 0x11601a8: fmul            d3, d0, d2
    // 0x11601ac: fsub            d0, d1, d3
    // 0x11601b0: r1 = LoadClassIdInstr(r0)
    //     0x11601b0: ldur            x1, [x0, #-1]
    //     0x11601b4: ubfx            x1, x1, #0xc, #0x14
    // 0x11601b8: cmp             x1, #0xb73
    // 0x11601bc: b.ne            #0x11603c4
    // 0x11601c0: r1 = inline_Allocate_Double()
    //     0x11601c0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11601c4: add             x1, x1, #0x10
    //     0x11601c8: cmp             x2, x1
    //     0x11601cc: b.ls            #0x1160a00
    //     0x11601d0: str             x1, [THR, #0x60]  ; THR::top
    //     0x11601d4: sub             x1, x1, #0xf
    //     0x11601d8: mov             x2, #0xe19c
    //     0x11601dc: movk            x2, #3, lsl #16
    //     0x11601e0: stur            x2, [x1, #-1]
    // 0x11601e4: dmb             ishst
    // 0x11601e8: StoreField: r1->field_7 = d0
    //     0x11601e8: stur            d0, [x1, #7]
    // 0x11601ec: stur            x1, [fp, #-0x18]
    // 0x11601f0: r1 = 1
    //     0x11601f0: mov             x1, #1
    // 0x11601f4: r0 = AllocateContext()
    //     0x11601f4: bl              #0x13de838  ; AllocateContextStub
    // 0x11601f8: mov             x1, x0
    // 0x11601fc: ldur            x0, [fp, #-0x18]
    // 0x1160200: StoreField: r1->field_f = r0
    //     0x1160200: stur            w0, [x1, #0xf]
    // 0x1160204: ldur            x0, [fp, #-8]
    // 0x1160208: LoadField: r3 = r0->field_13
    //     0x1160208: ldur            w3, [x0, #0x13]
    // 0x116020c: DecompressPointer r3
    //     0x116020c: add             x3, x3, HEAP, lsl #32
    // 0x1160210: stur            x3, [fp, #-0x20]
    // 0x1160214: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1160214: ldur            d0, [x0, #0x17]
    // 0x1160218: stur            d0, [fp, #-0x50]
    // 0x116021c: LoadField: d1 = r0->field_1f
    //     0x116021c: ldur            d1, [x0, #0x1f]
    // 0x1160220: stur            d1, [fp, #-0x48]
    // 0x1160224: LoadField: r4 = r0->field_7
    //     0x1160224: ldur            w4, [x0, #7]
    // 0x1160228: DecompressPointer r4
    //     0x1160228: add             x4, x4, HEAP, lsl #32
    // 0x116022c: mov             x2, x1
    // 0x1160230: stur            x4, [fp, #-0x18]
    // 0x1160234: r1 = Function '<anonymous closure>':.
    //     0x1160234: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3900] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1160238: ldr             x1, [x1, #0x900]
    // 0x116023c: r0 = AllocateClosure()
    //     0x116023c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1160240: r16 = <Color>
    //     0x1160240: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1160244: ldr             x16, [x16, #0xa90]
    // 0x1160248: ldur            lr, [fp, #-0x18]
    // 0x116024c: stp             lr, x16, [SP, #8]
    // 0x1160250: str             x0, [SP]
    // 0x1160254: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1160254: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1160258: r0 = map()
    //     0x1160258: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x116025c: mov             x3, x0
    // 0x1160260: stur            x3, [fp, #-0x28]
    // 0x1160264: LoadField: r4 = r3->field_7
    //     0x1160264: ldur            w4, [x3, #7]
    // 0x1160268: DecompressPointer r4
    //     0x1160268: add             x4, x4, HEAP, lsl #32
    // 0x116026c: mov             x0, x3
    // 0x1160270: stur            x4, [fp, #-0x18]
    // 0x1160274: r2 = Null
    //     0x1160274: mov             x2, NULL
    // 0x1160278: r1 = Null
    //     0x1160278: mov             x1, NULL
    // 0x116027c: cmp             w0, NULL
    // 0x1160280: b.eq            #0x1160318
    // 0x1160284: branchIfSmi(r0, 0x1160318)
    //     0x1160284: tbz             w0, #0, #0x1160318
    // 0x1160288: r3 = LoadClassIdInstr(r0)
    //     0x1160288: ldur            x3, [x0, #-1]
    //     0x116028c: ubfx            x3, x3, #0xc, #0x14
    // 0x1160290: r17 = 7724
    //     0x1160290: mov             x17, #0x1e2c
    // 0x1160294: cmp             x3, x17
    // 0x1160298: b.eq            #0x1160320
    // 0x116029c: r4 = LoadClassIdInstr(r0)
    //     0x116029c: ldur            x4, [x0, #-1]
    //     0x11602a0: ubfx            x4, x4, #0xc, #0x14
    // 0x11602a4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x11602a8: ldr             x3, [x3, #0x18]
    // 0x11602ac: ldr             x3, [x3, x4, lsl #3]
    // 0x11602b0: LoadField: r3 = r3->field_2b
    //     0x11602b0: ldur            w3, [x3, #0x2b]
    // 0x11602b4: DecompressPointer r3
    //     0x11602b4: add             x3, x3, HEAP, lsl #32
    // 0x11602b8: cmp             w3, NULL
    // 0x11602bc: b.eq            #0x1160318
    // 0x11602c0: LoadField: r3 = r3->field_f
    //     0x11602c0: ldur            w3, [x3, #0xf]
    // 0x11602c4: lsr             x3, x3, #3
    // 0x11602c8: r17 = 7724
    //     0x11602c8: mov             x17, #0x1e2c
    // 0x11602cc: cmp             x3, x17
    // 0x11602d0: b.eq            #0x1160320
    // 0x11602d4: r3 = SubtypeTestCache
    //     0x11602d4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3908] SubtypeTestCache
    //     0x11602d8: ldr             x3, [x3, #0x908]
    // 0x11602dc: r30 = Subtype1TestCacheStub
    //     0x11602dc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x11602e0: LoadField: r30 = r30->field_7
    //     0x11602e0: ldur            lr, [lr, #7]
    // 0x11602e4: blr             lr
    // 0x11602e8: cmp             w7, NULL
    // 0x11602ec: b.eq            #0x11602f8
    // 0x11602f0: tbnz            w7, #4, #0x1160318
    // 0x11602f4: b               #0x1160320
    // 0x11602f8: r8 = EfficientLengthIterable
    //     0x11602f8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3910] Type: EfficientLengthIterable
    //     0x11602fc: ldr             x8, [x8, #0x910]
    // 0x1160300: r3 = SubtypeTestCache
    //     0x1160300: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3918] SubtypeTestCache
    //     0x1160304: ldr             x3, [x3, #0x918]
    // 0x1160308: r30 = InstanceOfStub
    //     0x1160308: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x116030c: LoadField: r30 = r30->field_7
    //     0x116030c: ldur            lr, [lr, #7]
    // 0x1160310: blr             lr
    // 0x1160314: b               #0x1160324
    // 0x1160318: r0 = false
    //     0x1160318: add             x0, NULL, #0x30  ; false
    // 0x116031c: b               #0x1160324
    // 0x1160320: r0 = true
    //     0x1160320: add             x0, NULL, #0x20  ; true
    // 0x1160324: tbnz            w0, #4, #0x116033c
    // 0x1160328: ldur            x1, [fp, #-0x18]
    // 0x116032c: ldur            x2, [fp, #-0x28]
    // 0x1160330: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1160330: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1160334: mov             x2, x0
    // 0x1160338: b               #0x116034c
    // 0x116033c: ldur            x1, [fp, #-0x18]
    // 0x1160340: ldur            x2, [fp, #-0x28]
    // 0x1160344: r0 = _GrowableList._ofOther()
    //     0x1160344: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x1160348: mov             x2, x0
    // 0x116034c: ldur            x0, [fp, #-8]
    // 0x1160350: ldur            x1, [fp, #-0x20]
    // 0x1160354: ldur            d0, [fp, #-0x50]
    // 0x1160358: ldur            d1, [fp, #-0x48]
    // 0x116035c: stur            x2, [fp, #-0x30]
    // 0x1160360: LoadField: r3 = r0->field_b
    //     0x1160360: ldur            w3, [x0, #0xb]
    // 0x1160364: DecompressPointer r3
    //     0x1160364: add             x3, x3, HEAP, lsl #32
    // 0x1160368: stur            x3, [fp, #-0x28]
    // 0x116036c: LoadField: r4 = r0->field_f
    //     0x116036c: ldur            w4, [x0, #0xf]
    // 0x1160370: DecompressPointer r4
    //     0x1160370: add             x4, x4, HEAP, lsl #32
    // 0x1160374: stur            x4, [fp, #-0x18]
    // 0x1160378: r0 = SweepGradient()
    //     0x1160378: bl              #0x1160a74  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x116037c: mov             x1, x0
    // 0x1160380: ldur            x0, [fp, #-0x20]
    // 0x1160384: StoreField: r1->field_13 = r0
    //     0x1160384: stur            w0, [x1, #0x13]
    // 0x1160388: ldur            d0, [fp, #-0x50]
    // 0x116038c: ArrayStore: r1[0] = d0  ; List_8
    //     0x116038c: stur            d0, [x1, #0x17]
    // 0x1160390: ldur            d0, [fp, #-0x48]
    // 0x1160394: StoreField: r1->field_1f = d0
    //     0x1160394: stur            d0, [x1, #0x1f]
    // 0x1160398: r2 = Instance_TileMode
    //     0x1160398: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x116039c: ldr             x2, [x2, #0x900]
    // 0x11603a0: StoreField: r1->field_27 = r2
    //     0x11603a0: stur            w2, [x1, #0x27]
    // 0x11603a4: ldur            x0, [fp, #-0x30]
    // 0x11603a8: StoreField: r1->field_7 = r0
    //     0x11603a8: stur            w0, [x1, #7]
    // 0x11603ac: ldur            x0, [fp, #-0x28]
    // 0x11603b0: StoreField: r1->field_b = r0
    //     0x11603b0: stur            w0, [x1, #0xb]
    // 0x11603b4: ldur            x0, [fp, #-0x18]
    // 0x11603b8: StoreField: r1->field_f = r0
    //     0x11603b8: stur            w0, [x1, #0xf]
    // 0x11603bc: mov             x0, x1
    // 0x11603c0: b               #0x11609e8
    // 0x11603c4: r2 = Instance_TileMode
    //     0x11603c4: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x11603c8: ldr             x2, [x2, #0x900]
    // 0x11603cc: r1 = inline_Allocate_Double()
    //     0x11603cc: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x11603d0: add             x1, x1, #0x10
    //     0x11603d4: cmp             x3, x1
    //     0x11603d8: b.ls            #0x1160a1c
    //     0x11603dc: str             x1, [THR, #0x60]  ; THR::top
    //     0x11603e0: sub             x1, x1, #0xf
    //     0x11603e4: mov             x3, #0xe19c
    //     0x11603e8: movk            x3, #3, lsl #16
    //     0x11603ec: stur            x3, [x1, #-1]
    // 0x11603f0: dmb             ishst
    // 0x11603f4: StoreField: r1->field_7 = d0
    //     0x11603f4: stur            d0, [x1, #7]
    // 0x11603f8: stur            x1, [fp, #-0x18]
    // 0x11603fc: r1 = 1
    //     0x11603fc: mov             x1, #1
    // 0x1160400: r0 = AllocateContext()
    //     0x1160400: bl              #0x13de838  ; AllocateContextStub
    // 0x1160404: mov             x1, x0
    // 0x1160408: ldur            x0, [fp, #-0x18]
    // 0x116040c: StoreField: r1->field_f = r0
    //     0x116040c: stur            w0, [x1, #0xf]
    // 0x1160410: ldur            x0, [fp, #-8]
    // 0x1160414: LoadField: r3 = r0->field_13
    //     0x1160414: ldur            w3, [x0, #0x13]
    // 0x1160418: DecompressPointer r3
    //     0x1160418: add             x3, x3, HEAP, lsl #32
    // 0x116041c: stur            x3, [fp, #-0x28]
    // 0x1160420: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x1160420: ldur            w4, [x0, #0x17]
    // 0x1160424: DecompressPointer r4
    //     0x1160424: add             x4, x4, HEAP, lsl #32
    // 0x1160428: stur            x4, [fp, #-0x20]
    // 0x116042c: LoadField: r5 = r0->field_7
    //     0x116042c: ldur            w5, [x0, #7]
    // 0x1160430: DecompressPointer r5
    //     0x1160430: add             x5, x5, HEAP, lsl #32
    // 0x1160434: mov             x2, x1
    // 0x1160438: stur            x5, [fp, #-0x18]
    // 0x116043c: r1 = Function '<anonymous closure>':.
    //     0x116043c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3920] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1160440: ldr             x1, [x1, #0x920]
    // 0x1160444: r0 = AllocateClosure()
    //     0x1160444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1160448: r16 = <Color>
    //     0x1160448: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x116044c: ldr             x16, [x16, #0xa90]
    // 0x1160450: ldur            lr, [fp, #-0x18]
    // 0x1160454: stp             lr, x16, [SP, #8]
    // 0x1160458: str             x0, [SP]
    // 0x116045c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x116045c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1160460: r0 = map()
    //     0x1160460: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1160464: mov             x3, x0
    // 0x1160468: stur            x3, [fp, #-0x30]
    // 0x116046c: LoadField: r4 = r3->field_7
    //     0x116046c: ldur            w4, [x3, #7]
    // 0x1160470: DecompressPointer r4
    //     0x1160470: add             x4, x4, HEAP, lsl #32
    // 0x1160474: mov             x0, x3
    // 0x1160478: stur            x4, [fp, #-0x18]
    // 0x116047c: r2 = Null
    //     0x116047c: mov             x2, NULL
    // 0x1160480: r1 = Null
    //     0x1160480: mov             x1, NULL
    // 0x1160484: cmp             w0, NULL
    // 0x1160488: b.eq            #0x1160520
    // 0x116048c: branchIfSmi(r0, 0x1160520)
    //     0x116048c: tbz             w0, #0, #0x1160520
    // 0x1160490: r3 = LoadClassIdInstr(r0)
    //     0x1160490: ldur            x3, [x0, #-1]
    //     0x1160494: ubfx            x3, x3, #0xc, #0x14
    // 0x1160498: r17 = 7724
    //     0x1160498: mov             x17, #0x1e2c
    // 0x116049c: cmp             x3, x17
    // 0x11604a0: b.eq            #0x1160528
    // 0x11604a4: r4 = LoadClassIdInstr(r0)
    //     0x11604a4: ldur            x4, [x0, #-1]
    //     0x11604a8: ubfx            x4, x4, #0xc, #0x14
    // 0x11604ac: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x11604b0: ldr             x3, [x3, #0x18]
    // 0x11604b4: ldr             x3, [x3, x4, lsl #3]
    // 0x11604b8: LoadField: r3 = r3->field_2b
    //     0x11604b8: ldur            w3, [x3, #0x2b]
    // 0x11604bc: DecompressPointer r3
    //     0x11604bc: add             x3, x3, HEAP, lsl #32
    // 0x11604c0: cmp             w3, NULL
    // 0x11604c4: b.eq            #0x1160520
    // 0x11604c8: LoadField: r3 = r3->field_f
    //     0x11604c8: ldur            w3, [x3, #0xf]
    // 0x11604cc: lsr             x3, x3, #3
    // 0x11604d0: r17 = 7724
    //     0x11604d0: mov             x17, #0x1e2c
    // 0x11604d4: cmp             x3, x17
    // 0x11604d8: b.eq            #0x1160528
    // 0x11604dc: r3 = SubtypeTestCache
    //     0x11604dc: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3928] SubtypeTestCache
    //     0x11604e0: ldr             x3, [x3, #0x928]
    // 0x11604e4: r30 = Subtype1TestCacheStub
    //     0x11604e4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x11604e8: LoadField: r30 = r30->field_7
    //     0x11604e8: ldur            lr, [lr, #7]
    // 0x11604ec: blr             lr
    // 0x11604f0: cmp             w7, NULL
    // 0x11604f4: b.eq            #0x1160500
    // 0x11604f8: tbnz            w7, #4, #0x1160520
    // 0x11604fc: b               #0x1160528
    // 0x1160500: r8 = EfficientLengthIterable
    //     0x1160500: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3930] Type: EfficientLengthIterable
    //     0x1160504: ldr             x8, [x8, #0x930]
    // 0x1160508: r3 = SubtypeTestCache
    //     0x1160508: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3938] SubtypeTestCache
    //     0x116050c: ldr             x3, [x3, #0x938]
    // 0x1160510: r30 = InstanceOfStub
    //     0x1160510: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1160514: LoadField: r30 = r30->field_7
    //     0x1160514: ldur            lr, [lr, #7]
    // 0x1160518: blr             lr
    // 0x116051c: b               #0x116052c
    // 0x1160520: r0 = false
    //     0x1160520: add             x0, NULL, #0x30  ; false
    // 0x1160524: b               #0x116052c
    // 0x1160528: r0 = true
    //     0x1160528: add             x0, NULL, #0x20  ; true
    // 0x116052c: tbnz            w0, #4, #0x1160544
    // 0x1160530: ldur            x1, [fp, #-0x18]
    // 0x1160534: ldur            x2, [fp, #-0x30]
    // 0x1160538: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1160538: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x116053c: mov             x3, x0
    // 0x1160540: b               #0x1160554
    // 0x1160544: ldur            x1, [fp, #-0x18]
    // 0x1160548: ldur            x2, [fp, #-0x30]
    // 0x116054c: r0 = _GrowableList._ofOther()
    //     0x116054c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x1160550: mov             x3, x0
    // 0x1160554: ldur            x0, [fp, #-8]
    // 0x1160558: ldur            x1, [fp, #-0x28]
    // 0x116055c: ldur            x2, [fp, #-0x20]
    // 0x1160560: stur            x3, [fp, #-0x38]
    // 0x1160564: LoadField: r4 = r0->field_b
    //     0x1160564: ldur            w4, [x0, #0xb]
    // 0x1160568: DecompressPointer r4
    //     0x1160568: add             x4, x4, HEAP, lsl #32
    // 0x116056c: stur            x4, [fp, #-0x30]
    // 0x1160570: LoadField: r5 = r0->field_f
    //     0x1160570: ldur            w5, [x0, #0xf]
    // 0x1160574: DecompressPointer r5
    //     0x1160574: add             x5, x5, HEAP, lsl #32
    // 0x1160578: stur            x5, [fp, #-0x18]
    // 0x116057c: r0 = LinearGradient()
    //     0x116057c: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x1160580: mov             x1, x0
    // 0x1160584: ldur            x0, [fp, #-0x28]
    // 0x1160588: StoreField: r1->field_13 = r0
    //     0x1160588: stur            w0, [x1, #0x13]
    // 0x116058c: ldur            x0, [fp, #-0x20]
    // 0x1160590: ArrayStore: r1[0] = r0  ; List_4
    //     0x1160590: stur            w0, [x1, #0x17]
    // 0x1160594: r0 = Instance_TileMode
    //     0x1160594: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x1160598: ldr             x0, [x0, #0x900]
    // 0x116059c: StoreField: r1->field_1b = r0
    //     0x116059c: stur            w0, [x1, #0x1b]
    // 0x11605a0: ldur            x0, [fp, #-0x38]
    // 0x11605a4: StoreField: r1->field_7 = r0
    //     0x11605a4: stur            w0, [x1, #7]
    // 0x11605a8: ldur            x0, [fp, #-0x30]
    // 0x11605ac: StoreField: r1->field_b = r0
    //     0x11605ac: stur            w0, [x1, #0xb]
    // 0x11605b0: ldur            x0, [fp, #-0x18]
    // 0x11605b4: StoreField: r1->field_f = r0
    //     0x11605b4: stur            w0, [x1, #0xf]
    // 0x11605b8: mov             x0, x1
    // 0x11605bc: b               #0x11609e8
    // 0x11605c0: ldur            x1, [fp, #-0x10]
    // 0x11605c4: r0 = Instance_TileMode
    //     0x11605c4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x11605c8: ldr             x0, [x0, #0x900]
    // 0x11605cc: d2 = 2.000000
    //     0x11605cc: fmov            d2, #2.00000000
    // 0x11605d0: cmp             w1, NULL
    // 0x11605d4: b.eq            #0x1160a38
    // 0x11605d8: fsub            d3, d0, d1
    // 0x11605dc: fmul            d0, d3, d2
    // 0x11605e0: r2 = LoadClassIdInstr(r1)
    //     0x11605e0: ldur            x2, [x1, #-1]
    //     0x11605e4: ubfx            x2, x2, #0xc, #0x14
    // 0x11605e8: cmp             x2, #0xb73
    // 0x11605ec: b.ne            #0x11607f0
    // 0x11605f0: r2 = inline_Allocate_Double()
    //     0x11605f0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11605f4: add             x2, x2, #0x10
    //     0x11605f8: cmp             x3, x2
    //     0x11605fc: b.ls            #0x1160a3c
    //     0x1160600: str             x2, [THR, #0x60]  ; THR::top
    //     0x1160604: sub             x2, x2, #0xf
    //     0x1160608: mov             x3, #0xe19c
    //     0x116060c: movk            x3, #3, lsl #16
    //     0x1160610: stur            x3, [x2, #-1]
    // 0x1160614: dmb             ishst
    // 0x1160618: StoreField: r2->field_7 = d0
    //     0x1160618: stur            d0, [x2, #7]
    // 0x116061c: stur            x2, [fp, #-8]
    // 0x1160620: r1 = 1
    //     0x1160620: mov             x1, #1
    // 0x1160624: r0 = AllocateContext()
    //     0x1160624: bl              #0x13de838  ; AllocateContextStub
    // 0x1160628: mov             x1, x0
    // 0x116062c: ldur            x0, [fp, #-8]
    // 0x1160630: StoreField: r1->field_f = r0
    //     0x1160630: stur            w0, [x1, #0xf]
    // 0x1160634: ldur            x0, [fp, #-0x10]
    // 0x1160638: LoadField: r3 = r0->field_13
    //     0x1160638: ldur            w3, [x0, #0x13]
    // 0x116063c: DecompressPointer r3
    //     0x116063c: add             x3, x3, HEAP, lsl #32
    // 0x1160640: stur            x3, [fp, #-0x18]
    // 0x1160644: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1160644: ldur            d0, [x0, #0x17]
    // 0x1160648: stur            d0, [fp, #-0x48]
    // 0x116064c: LoadField: d1 = r0->field_1f
    //     0x116064c: ldur            d1, [x0, #0x1f]
    // 0x1160650: stur            d1, [fp, #-0x40]
    // 0x1160654: LoadField: r4 = r0->field_7
    //     0x1160654: ldur            w4, [x0, #7]
    // 0x1160658: DecompressPointer r4
    //     0x1160658: add             x4, x4, HEAP, lsl #32
    // 0x116065c: mov             x2, x1
    // 0x1160660: stur            x4, [fp, #-8]
    // 0x1160664: r1 = Function '<anonymous closure>':.
    //     0x1160664: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3900] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1160668: ldr             x1, [x1, #0x900]
    // 0x116066c: r0 = AllocateClosure()
    //     0x116066c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1160670: r16 = <Color>
    //     0x1160670: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1160674: ldr             x16, [x16, #0xa90]
    // 0x1160678: ldur            lr, [fp, #-8]
    // 0x116067c: stp             lr, x16, [SP, #8]
    // 0x1160680: str             x0, [SP]
    // 0x1160684: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1160684: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1160688: r0 = map()
    //     0x1160688: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x116068c: mov             x3, x0
    // 0x1160690: stur            x3, [fp, #-0x20]
    // 0x1160694: LoadField: r4 = r3->field_7
    //     0x1160694: ldur            w4, [x3, #7]
    // 0x1160698: DecompressPointer r4
    //     0x1160698: add             x4, x4, HEAP, lsl #32
    // 0x116069c: mov             x0, x3
    // 0x11606a0: stur            x4, [fp, #-8]
    // 0x11606a4: r2 = Null
    //     0x11606a4: mov             x2, NULL
    // 0x11606a8: r1 = Null
    //     0x11606a8: mov             x1, NULL
    // 0x11606ac: cmp             w0, NULL
    // 0x11606b0: b.eq            #0x1160748
    // 0x11606b4: branchIfSmi(r0, 0x1160748)
    //     0x11606b4: tbz             w0, #0, #0x1160748
    // 0x11606b8: r3 = LoadClassIdInstr(r0)
    //     0x11606b8: ldur            x3, [x0, #-1]
    //     0x11606bc: ubfx            x3, x3, #0xc, #0x14
    // 0x11606c0: r17 = 7724
    //     0x11606c0: mov             x17, #0x1e2c
    // 0x11606c4: cmp             x3, x17
    // 0x11606c8: b.eq            #0x1160750
    // 0x11606cc: r4 = LoadClassIdInstr(r0)
    //     0x11606cc: ldur            x4, [x0, #-1]
    //     0x11606d0: ubfx            x4, x4, #0xc, #0x14
    // 0x11606d4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x11606d8: ldr             x3, [x3, #0x18]
    // 0x11606dc: ldr             x3, [x3, x4, lsl #3]
    // 0x11606e0: LoadField: r3 = r3->field_2b
    //     0x11606e0: ldur            w3, [x3, #0x2b]
    // 0x11606e4: DecompressPointer r3
    //     0x11606e4: add             x3, x3, HEAP, lsl #32
    // 0x11606e8: cmp             w3, NULL
    // 0x11606ec: b.eq            #0x1160748
    // 0x11606f0: LoadField: r3 = r3->field_f
    //     0x11606f0: ldur            w3, [x3, #0xf]
    // 0x11606f4: lsr             x3, x3, #3
    // 0x11606f8: r17 = 7724
    //     0x11606f8: mov             x17, #0x1e2c
    // 0x11606fc: cmp             x3, x17
    // 0x1160700: b.eq            #0x1160750
    // 0x1160704: r3 = SubtypeTestCache
    //     0x1160704: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3940] SubtypeTestCache
    //     0x1160708: ldr             x3, [x3, #0x940]
    // 0x116070c: r30 = Subtype1TestCacheStub
    //     0x116070c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1160710: LoadField: r30 = r30->field_7
    //     0x1160710: ldur            lr, [lr, #7]
    // 0x1160714: blr             lr
    // 0x1160718: cmp             w7, NULL
    // 0x116071c: b.eq            #0x1160728
    // 0x1160720: tbnz            w7, #4, #0x1160748
    // 0x1160724: b               #0x1160750
    // 0x1160728: r8 = EfficientLengthIterable
    //     0x1160728: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3948] Type: EfficientLengthIterable
    //     0x116072c: ldr             x8, [x8, #0x948]
    // 0x1160730: r3 = SubtypeTestCache
    //     0x1160730: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3950] SubtypeTestCache
    //     0x1160734: ldr             x3, [x3, #0x950]
    // 0x1160738: r30 = InstanceOfStub
    //     0x1160738: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x116073c: LoadField: r30 = r30->field_7
    //     0x116073c: ldur            lr, [lr, #7]
    // 0x1160740: blr             lr
    // 0x1160744: b               #0x1160754
    // 0x1160748: r0 = false
    //     0x1160748: add             x0, NULL, #0x30  ; false
    // 0x116074c: b               #0x1160754
    // 0x1160750: r0 = true
    //     0x1160750: add             x0, NULL, #0x20  ; true
    // 0x1160754: tbnz            w0, #4, #0x116076c
    // 0x1160758: ldur            x1, [fp, #-8]
    // 0x116075c: ldur            x2, [fp, #-0x20]
    // 0x1160760: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1160760: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1160764: mov             x2, x0
    // 0x1160768: b               #0x116077c
    // 0x116076c: ldur            x1, [fp, #-8]
    // 0x1160770: ldur            x2, [fp, #-0x20]
    // 0x1160774: r0 = _GrowableList._ofOther()
    //     0x1160774: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x1160778: mov             x2, x0
    // 0x116077c: ldur            x0, [fp, #-0x10]
    // 0x1160780: ldur            x1, [fp, #-0x18]
    // 0x1160784: ldur            d0, [fp, #-0x48]
    // 0x1160788: ldur            d1, [fp, #-0x40]
    // 0x116078c: stur            x2, [fp, #-0x28]
    // 0x1160790: LoadField: r3 = r0->field_b
    //     0x1160790: ldur            w3, [x0, #0xb]
    // 0x1160794: DecompressPointer r3
    //     0x1160794: add             x3, x3, HEAP, lsl #32
    // 0x1160798: stur            x3, [fp, #-0x20]
    // 0x116079c: LoadField: r4 = r0->field_f
    //     0x116079c: ldur            w4, [x0, #0xf]
    // 0x11607a0: DecompressPointer r4
    //     0x11607a0: add             x4, x4, HEAP, lsl #32
    // 0x11607a4: stur            x4, [fp, #-8]
    // 0x11607a8: r0 = SweepGradient()
    //     0x11607a8: bl              #0x1160a74  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x11607ac: mov             x1, x0
    // 0x11607b0: ldur            x0, [fp, #-0x18]
    // 0x11607b4: StoreField: r1->field_13 = r0
    //     0x11607b4: stur            w0, [x1, #0x13]
    // 0x11607b8: ldur            d0, [fp, #-0x48]
    // 0x11607bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x11607bc: stur            d0, [x1, #0x17]
    // 0x11607c0: ldur            d0, [fp, #-0x40]
    // 0x11607c4: StoreField: r1->field_1f = d0
    //     0x11607c4: stur            d0, [x1, #0x1f]
    // 0x11607c8: r2 = Instance_TileMode
    //     0x11607c8: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x11607cc: ldr             x2, [x2, #0x900]
    // 0x11607d0: StoreField: r1->field_27 = r2
    //     0x11607d0: stur            w2, [x1, #0x27]
    // 0x11607d4: ldur            x0, [fp, #-0x28]
    // 0x11607d8: StoreField: r1->field_7 = r0
    //     0x11607d8: stur            w0, [x1, #7]
    // 0x11607dc: ldur            x0, [fp, #-0x20]
    // 0x11607e0: StoreField: r1->field_b = r0
    //     0x11607e0: stur            w0, [x1, #0xb]
    // 0x11607e4: ldur            x0, [fp, #-8]
    // 0x11607e8: StoreField: r1->field_f = r0
    //     0x11607e8: stur            w0, [x1, #0xf]
    // 0x11607ec: b               #0x11609e4
    // 0x11607f0: mov             x2, x0
    // 0x11607f4: mov             x0, x1
    // 0x11607f8: r1 = inline_Allocate_Double()
    //     0x11607f8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x11607fc: add             x1, x1, #0x10
    //     0x1160800: cmp             x3, x1
    //     0x1160804: b.ls            #0x1160a58
    //     0x1160808: str             x1, [THR, #0x60]  ; THR::top
    //     0x116080c: sub             x1, x1, #0xf
    //     0x1160810: mov             x3, #0xe19c
    //     0x1160814: movk            x3, #3, lsl #16
    //     0x1160818: stur            x3, [x1, #-1]
    // 0x116081c: dmb             ishst
    // 0x1160820: StoreField: r1->field_7 = d0
    //     0x1160820: stur            d0, [x1, #7]
    // 0x1160824: stur            x1, [fp, #-8]
    // 0x1160828: r1 = 1
    //     0x1160828: mov             x1, #1
    // 0x116082c: r0 = AllocateContext()
    //     0x116082c: bl              #0x13de838  ; AllocateContextStub
    // 0x1160830: mov             x1, x0
    // 0x1160834: ldur            x0, [fp, #-8]
    // 0x1160838: StoreField: r1->field_f = r0
    //     0x1160838: stur            w0, [x1, #0xf]
    // 0x116083c: ldur            x0, [fp, #-0x10]
    // 0x1160840: LoadField: r3 = r0->field_13
    //     0x1160840: ldur            w3, [x0, #0x13]
    // 0x1160844: DecompressPointer r3
    //     0x1160844: add             x3, x3, HEAP, lsl #32
    // 0x1160848: stur            x3, [fp, #-0x20]
    // 0x116084c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x116084c: ldur            w4, [x0, #0x17]
    // 0x1160850: DecompressPointer r4
    //     0x1160850: add             x4, x4, HEAP, lsl #32
    // 0x1160854: stur            x4, [fp, #-0x18]
    // 0x1160858: LoadField: r5 = r0->field_7
    //     0x1160858: ldur            w5, [x0, #7]
    // 0x116085c: DecompressPointer r5
    //     0x116085c: add             x5, x5, HEAP, lsl #32
    // 0x1160860: mov             x2, x1
    // 0x1160864: stur            x5, [fp, #-8]
    // 0x1160868: r1 = Function '<anonymous closure>':.
    //     0x1160868: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3920] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x116086c: ldr             x1, [x1, #0x920]
    // 0x1160870: r0 = AllocateClosure()
    //     0x1160870: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1160874: r16 = <Color>
    //     0x1160874: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1160878: ldr             x16, [x16, #0xa90]
    // 0x116087c: ldur            lr, [fp, #-8]
    // 0x1160880: stp             lr, x16, [SP, #8]
    // 0x1160884: str             x0, [SP]
    // 0x1160888: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1160888: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x116088c: r0 = map()
    //     0x116088c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1160890: mov             x3, x0
    // 0x1160894: stur            x3, [fp, #-0x28]
    // 0x1160898: LoadField: r4 = r3->field_7
    //     0x1160898: ldur            w4, [x3, #7]
    // 0x116089c: DecompressPointer r4
    //     0x116089c: add             x4, x4, HEAP, lsl #32
    // 0x11608a0: mov             x0, x3
    // 0x11608a4: stur            x4, [fp, #-8]
    // 0x11608a8: r2 = Null
    //     0x11608a8: mov             x2, NULL
    // 0x11608ac: r1 = Null
    //     0x11608ac: mov             x1, NULL
    // 0x11608b0: cmp             w0, NULL
    // 0x11608b4: b.eq            #0x116094c
    // 0x11608b8: branchIfSmi(r0, 0x116094c)
    //     0x11608b8: tbz             w0, #0, #0x116094c
    // 0x11608bc: r3 = LoadClassIdInstr(r0)
    //     0x11608bc: ldur            x3, [x0, #-1]
    //     0x11608c0: ubfx            x3, x3, #0xc, #0x14
    // 0x11608c4: r17 = 7724
    //     0x11608c4: mov             x17, #0x1e2c
    // 0x11608c8: cmp             x3, x17
    // 0x11608cc: b.eq            #0x1160954
    // 0x11608d0: r4 = LoadClassIdInstr(r0)
    //     0x11608d0: ldur            x4, [x0, #-1]
    //     0x11608d4: ubfx            x4, x4, #0xc, #0x14
    // 0x11608d8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x11608dc: ldr             x3, [x3, #0x18]
    // 0x11608e0: ldr             x3, [x3, x4, lsl #3]
    // 0x11608e4: LoadField: r3 = r3->field_2b
    //     0x11608e4: ldur            w3, [x3, #0x2b]
    // 0x11608e8: DecompressPointer r3
    //     0x11608e8: add             x3, x3, HEAP, lsl #32
    // 0x11608ec: cmp             w3, NULL
    // 0x11608f0: b.eq            #0x116094c
    // 0x11608f4: LoadField: r3 = r3->field_f
    //     0x11608f4: ldur            w3, [x3, #0xf]
    // 0x11608f8: lsr             x3, x3, #3
    // 0x11608fc: r17 = 7724
    //     0x11608fc: mov             x17, #0x1e2c
    // 0x1160900: cmp             x3, x17
    // 0x1160904: b.eq            #0x1160954
    // 0x1160908: r3 = SubtypeTestCache
    //     0x1160908: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3958] SubtypeTestCache
    //     0x116090c: ldr             x3, [x3, #0x958]
    // 0x1160910: r30 = Subtype1TestCacheStub
    //     0x1160910: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1160914: LoadField: r30 = r30->field_7
    //     0x1160914: ldur            lr, [lr, #7]
    // 0x1160918: blr             lr
    // 0x116091c: cmp             w7, NULL
    // 0x1160920: b.eq            #0x116092c
    // 0x1160924: tbnz            w7, #4, #0x116094c
    // 0x1160928: b               #0x1160954
    // 0x116092c: r8 = EfficientLengthIterable
    //     0x116092c: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3960] Type: EfficientLengthIterable
    //     0x1160930: ldr             x8, [x8, #0x960]
    // 0x1160934: r3 = SubtypeTestCache
    //     0x1160934: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3968] SubtypeTestCache
    //     0x1160938: ldr             x3, [x3, #0x968]
    // 0x116093c: r30 = InstanceOfStub
    //     0x116093c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1160940: LoadField: r30 = r30->field_7
    //     0x1160940: ldur            lr, [lr, #7]
    // 0x1160944: blr             lr
    // 0x1160948: b               #0x1160958
    // 0x116094c: r0 = false
    //     0x116094c: add             x0, NULL, #0x30  ; false
    // 0x1160950: b               #0x1160958
    // 0x1160954: r0 = true
    //     0x1160954: add             x0, NULL, #0x20  ; true
    // 0x1160958: tbnz            w0, #4, #0x1160970
    // 0x116095c: ldur            x1, [fp, #-8]
    // 0x1160960: ldur            x2, [fp, #-0x28]
    // 0x1160964: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1160964: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1160968: mov             x3, x0
    // 0x116096c: b               #0x1160980
    // 0x1160970: ldur            x1, [fp, #-8]
    // 0x1160974: ldur            x2, [fp, #-0x28]
    // 0x1160978: r0 = _GrowableList._ofOther()
    //     0x1160978: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x116097c: mov             x3, x0
    // 0x1160980: ldur            x0, [fp, #-0x10]
    // 0x1160984: ldur            x1, [fp, #-0x20]
    // 0x1160988: ldur            x2, [fp, #-0x18]
    // 0x116098c: stur            x3, [fp, #-0x30]
    // 0x1160990: LoadField: r4 = r0->field_b
    //     0x1160990: ldur            w4, [x0, #0xb]
    // 0x1160994: DecompressPointer r4
    //     0x1160994: add             x4, x4, HEAP, lsl #32
    // 0x1160998: stur            x4, [fp, #-0x28]
    // 0x116099c: LoadField: r5 = r0->field_f
    //     0x116099c: ldur            w5, [x0, #0xf]
    // 0x11609a0: DecompressPointer r5
    //     0x11609a0: add             x5, x5, HEAP, lsl #32
    // 0x11609a4: stur            x5, [fp, #-8]
    // 0x11609a8: r0 = LinearGradient()
    //     0x11609a8: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x11609ac: ldur            x1, [fp, #-0x20]
    // 0x11609b0: StoreField: r0->field_13 = r1
    //     0x11609b0: stur            w1, [x0, #0x13]
    // 0x11609b4: ldur            x1, [fp, #-0x18]
    // 0x11609b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x11609b8: stur            w1, [x0, #0x17]
    // 0x11609bc: r1 = Instance_TileMode
    //     0x11609bc: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x11609c0: ldr             x1, [x1, #0x900]
    // 0x11609c4: StoreField: r0->field_1b = r1
    //     0x11609c4: stur            w1, [x0, #0x1b]
    // 0x11609c8: ldur            x1, [fp, #-0x30]
    // 0x11609cc: StoreField: r0->field_7 = r1
    //     0x11609cc: stur            w1, [x0, #7]
    // 0x11609d0: ldur            x1, [fp, #-0x28]
    // 0x11609d4: StoreField: r0->field_b = r1
    //     0x11609d4: stur            w1, [x0, #0xb]
    // 0x11609d8: ldur            x1, [fp, #-8]
    // 0x11609dc: StoreField: r0->field_f = r1
    //     0x11609dc: stur            w1, [x0, #0xf]
    // 0x11609e0: mov             x1, x0
    // 0x11609e4: mov             x0, x1
    // 0x11609e8: LeaveFrame
    //     0x11609e8: mov             SP, fp
    //     0x11609ec: ldp             fp, lr, [SP], #0x10
    // 0x11609f0: ret
    //     0x11609f0: ret             
    // 0x11609f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11609f4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11609f8: b               #0x115ffcc
    // 0x11609fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11609fc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1160a00: SaveReg d0
    //     0x1160a00: str             q0, [SP, #-0x10]!
    // 0x1160a04: SaveReg r0
    //     0x1160a04: str             x0, [SP, #-8]!
    // 0x1160a08: r0 = AllocateDouble()
    //     0x1160a08: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1160a0c: mov             x1, x0
    // 0x1160a10: RestoreReg r0
    //     0x1160a10: ldr             x0, [SP], #8
    // 0x1160a14: RestoreReg d0
    //     0x1160a14: ldr             q0, [SP], #0x10
    // 0x1160a18: b               #0x11601e8
    // 0x1160a1c: SaveReg d0
    //     0x1160a1c: str             q0, [SP, #-0x10]!
    // 0x1160a20: stp             x0, x2, [SP, #-0x10]!
    // 0x1160a24: r0 = AllocateDouble()
    //     0x1160a24: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1160a28: mov             x1, x0
    // 0x1160a2c: ldp             x0, x2, [SP], #0x10
    // 0x1160a30: RestoreReg d0
    //     0x1160a30: ldr             q0, [SP], #0x10
    // 0x1160a34: b               #0x11603f4
    // 0x1160a38: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1160a38: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1160a3c: SaveReg d0
    //     0x1160a3c: str             q0, [SP, #-0x10]!
    // 0x1160a40: stp             x0, x1, [SP, #-0x10]!
    // 0x1160a44: r0 = AllocateDouble()
    //     0x1160a44: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1160a48: mov             x2, x0
    // 0x1160a4c: ldp             x0, x1, [SP], #0x10
    // 0x1160a50: RestoreReg d0
    //     0x1160a50: ldr             q0, [SP], #0x10
    // 0x1160a54: b               #0x1160618
    // 0x1160a58: SaveReg d0
    //     0x1160a58: str             q0, [SP, #-0x10]!
    // 0x1160a5c: stp             x0, x2, [SP, #-0x10]!
    // 0x1160a60: r0 = AllocateDouble()
    //     0x1160a60: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1160a64: mov             x1, x0
    // 0x1160a68: ldp             x0, x2, [SP], #0x10
    // 0x1160a6c: RestoreReg d0
    //     0x1160a6c: ldr             q0, [SP], #0x10
    // 0x1160a70: b               #0x1160820
  }
  _ _impliedStops(/* No info */) {
    // ** addr: 0x1162204, size: 0x17c
    // 0x1162204: EnterFrame
    //     0x1162204: stp             fp, lr, [SP, #-0x10]!
    //     0x1162208: mov             fp, SP
    // 0x116220c: AllocStack(0x18)
    //     0x116220c: sub             SP, SP, #0x18
    // 0x1162210: CheckStackOverflow
    //     0x1162210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1162214: cmp             SP, x16
    //     0x1162218: b.ls            #0x1162350
    // 0x116221c: LoadField: r0 = r1->field_b
    //     0x116221c: ldur            w0, [x1, #0xb]
    // 0x1162220: DecompressPointer r0
    //     0x1162220: add             x0, x0, HEAP, lsl #32
    // 0x1162224: cmp             w0, NULL
    // 0x1162228: b.eq            #0x1162238
    // 0x116222c: LeaveFrame
    //     0x116222c: mov             SP, fp
    //     0x1162230: ldp             fp, lr, [SP], #0x10
    // 0x1162234: ret
    //     0x1162234: ret             
    // 0x1162238: LoadField: r2 = r1->field_7
    //     0x1162238: ldur            w2, [x1, #7]
    // 0x116223c: DecompressPointer r2
    //     0x116223c: add             x2, x2, HEAP, lsl #32
    // 0x1162240: stur            x2, [fp, #-8]
    // 0x1162244: r0 = LoadClassIdInstr(r2)
    //     0x1162244: ldur            x0, [x2, #-1]
    //     0x1162248: ubfx            x0, x0, #0xc, #0x14
    // 0x116224c: str             x2, [SP]
    // 0x1162250: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1162250: mov             x17, #0xf078
    //     0x1162254: add             lr, x0, x17
    //     0x1162258: ldr             lr, [x21, lr, lsl #3]
    //     0x116225c: blr             lr
    // 0x1162260: r1 = LoadInt32Instr(r0)
    //     0x1162260: sbfx            x1, x0, #1, #0x1f
    // 0x1162264: sub             x0, x1, #1
    // 0x1162268: scvtf           d0, x0
    // 0x116226c: d1 = 1.000000
    //     0x116226c: fmov            d1, #1.00000000
    // 0x1162270: fdiv            d2, d1, d0
    // 0x1162274: ldur            x0, [fp, #-8]
    // 0x1162278: stur            d2, [fp, #-0x10]
    // 0x116227c: r1 = LoadClassIdInstr(r0)
    //     0x116227c: ldur            x1, [x0, #-1]
    //     0x1162280: ubfx            x1, x1, #0xc, #0x14
    // 0x1162284: str             x0, [SP]
    // 0x1162288: mov             x0, x1
    // 0x116228c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x116228c: mov             x17, #0xf078
    //     0x1162290: add             lr, x0, x17
    //     0x1162294: ldr             lr, [x21, lr, lsl #3]
    //     0x1162298: blr             lr
    // 0x116229c: mov             x2, x0
    // 0x11622a0: r1 = <double>
    //     0x11622a0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11622a4: stur            x0, [fp, #-8]
    // 0x11622a8: r0 = AllocateArray()
    //     0x11622a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11622ac: mov             x3, x0
    // 0x11622b0: ldur            x2, [fp, #-8]
    // 0x11622b4: r4 = LoadInt32Instr(r2)
    //     0x11622b4: sbfx            x4, x2, #1, #0x1f
    // 0x11622b8: ldur            d0, [fp, #-0x10]
    // 0x11622bc: r2 = 0
    //     0x11622bc: mov             x2, #0
    // 0x11622c0: CheckStackOverflow
    //     0x11622c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11622c4: cmp             SP, x16
    //     0x11622c8: b.ls            #0x1162358
    // 0x11622cc: cmp             x2, x4
    // 0x11622d0: b.ge            #0x1162340
    // 0x11622d4: scvtf           d1, x2
    // 0x11622d8: fmul            d2, d1, d0
    // 0x11622dc: r0 = inline_Allocate_Double()
    //     0x11622dc: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x11622e0: add             x0, x0, #0x10
    //     0x11622e4: cmp             x5, x0
    //     0x11622e8: b.ls            #0x1162360
    //     0x11622ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x11622f0: sub             x0, x0, #0xf
    //     0x11622f4: mov             x5, #0xe19c
    //     0x11622f8: movk            x5, #3, lsl #16
    //     0x11622fc: stur            x5, [x0, #-1]
    // 0x1162300: dmb             ishst
    // 0x1162304: StoreField: r0->field_7 = d2
    //     0x1162304: stur            d2, [x0, #7]
    // 0x1162308: mov             x1, x3
    // 0x116230c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x116230c: add             x25, x1, x2, lsl #2
    //     0x1162310: add             x25, x25, #0xf
    //     0x1162314: str             w0, [x25]
    //     0x1162318: tbz             w0, #0, #0x1162334
    //     0x116231c: ldurb           w16, [x1, #-1]
    //     0x1162320: ldurb           w17, [x0, #-1]
    //     0x1162324: and             x16, x17, x16, lsr #2
    //     0x1162328: tst             x16, HEAP, lsr #32
    //     0x116232c: b.eq            #0x1162334
    //     0x1162330: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1162334: add             x0, x2, #1
    // 0x1162338: mov             x2, x0
    // 0x116233c: b               #0x11622c0
    // 0x1162340: mov             x0, x3
    // 0x1162344: LeaveFrame
    //     0x1162344: mov             SP, fp
    //     0x1162348: ldp             fp, lr, [SP], #0x10
    // 0x116234c: ret
    //     0x116234c: ret             
    // 0x1162350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1162350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1162354: b               #0x116221c
    // 0x1162358: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162358: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116235c: b               #0x11622cc
    // 0x1162360: stp             q0, q2, [SP, #-0x20]!
    // 0x1162364: stp             x3, x4, [SP, #-0x10]!
    // 0x1162368: SaveReg r2
    //     0x1162368: str             x2, [SP, #-8]!
    // 0x116236c: r0 = AllocateDouble()
    //     0x116236c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162370: RestoreReg r2
    //     0x1162370: ldr             x2, [SP], #8
    // 0x1162374: ldp             x3, x4, [SP], #0x10
    // 0x1162378: ldp             q0, q2, [SP], #0x20
    // 0x116237c: b               #0x1162304
  }
  _ _resolveTransform(/* No info */) {
    // ** addr: 0x12f7c18, size: 0x6c
    // 0x12f7c18: EnterFrame
    //     0x12f7c18: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7c1c: mov             fp, SP
    // 0x12f7c20: CheckStackOverflow
    //     0x12f7c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f7c24: cmp             SP, x16
    //     0x12f7c28: b.ls            #0x12f7c7c
    // 0x12f7c2c: LoadField: r0 = r1->field_f
    //     0x12f7c2c: ldur            w0, [x1, #0xf]
    // 0x12f7c30: DecompressPointer r0
    //     0x12f7c30: add             x0, x0, HEAP, lsl #32
    // 0x12f7c34: cmp             w0, NULL
    // 0x12f7c38: b.ne            #0x12f7c44
    // 0x12f7c3c: r0 = Null
    //     0x12f7c3c: mov             x0, NULL
    // 0x12f7c40: b               #0x12f7c70
    // 0x12f7c44: r1 = LoadClassIdInstr(r0)
    //     0x12f7c44: ldur            x1, [x0, #-1]
    //     0x12f7c48: ubfx            x1, x1, #0xc, #0x14
    // 0x12f7c4c: mov             x16, x0
    // 0x12f7c50: mov             x0, x1
    // 0x12f7c54: mov             x1, x16
    // 0x12f7c58: r0 = GDT[cid_x0 + -0xfff]()
    //     0x12f7c58: sub             lr, x0, #0xfff
    //     0x12f7c5c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7c60: blr             lr
    // 0x12f7c64: LoadField: r1 = r0->field_7
    //     0x12f7c64: ldur            w1, [x0, #7]
    // 0x12f7c68: DecompressPointer r1
    //     0x12f7c68: add             x1, x1, HEAP, lsl #32
    // 0x12f7c6c: mov             x0, x1
    // 0x12f7c70: LeaveFrame
    //     0x12f7c70: mov             SP, fp
    //     0x12f7c74: ldp             fp, lr, [SP], #0x10
    // 0x12f7c78: ret
    //     0x12f7c78: ret             
    // 0x12f7c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f7c7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7c80: b               #0x12f7c2c
  }
}

// class id: 2931, size: 0x2c, field offset: 0x14
//   const constructor, 
class SweepGradient extends Gradient {

  _ImmutableList<Color> field_8;
  Alignment field_14;
  _Mint field_18;
  _Double field_20;
  TileMode field_28;

  get _ hashCode(/* No info */) {
    // ** addr: 0x114bf74, size: 0x1a4
    // 0x114bf74: EnterFrame
    //     0x114bf74: stp             fp, lr, [SP, #-0x10]!
    //     0x114bf78: mov             fp, SP
    // 0x114bf7c: AllocStack(0x50)
    //     0x114bf7c: sub             SP, SP, #0x50
    // 0x114bf80: CheckStackOverflow
    //     0x114bf80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114bf84: cmp             SP, x16
    //     0x114bf88: b.ls            #0x114c0d0
    // 0x114bf8c: ldr             x0, [fp, #0x10]
    // 0x114bf90: LoadField: r2 = r0->field_13
    //     0x114bf90: ldur            w2, [x0, #0x13]
    // 0x114bf94: DecompressPointer r2
    //     0x114bf94: add             x2, x2, HEAP, lsl #32
    // 0x114bf98: stur            x2, [fp, #-0x10]
    // 0x114bf9c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x114bf9c: ldur            d0, [x0, #0x17]
    // 0x114bfa0: stur            d0, [fp, #-0x28]
    // 0x114bfa4: LoadField: d1 = r0->field_1f
    //     0x114bfa4: ldur            d1, [x0, #0x1f]
    // 0x114bfa8: stur            d1, [fp, #-0x20]
    // 0x114bfac: LoadField: r3 = r0->field_f
    //     0x114bfac: ldur            w3, [x0, #0xf]
    // 0x114bfb0: DecompressPointer r3
    //     0x114bfb0: add             x3, x3, HEAP, lsl #32
    // 0x114bfb4: stur            x3, [fp, #-8]
    // 0x114bfb8: LoadField: r1 = r0->field_7
    //     0x114bfb8: ldur            w1, [x0, #7]
    // 0x114bfbc: DecompressPointer r1
    //     0x114bfbc: add             x1, x1, HEAP, lsl #32
    // 0x114bfc0: r0 = hashAll()
    //     0x114bfc0: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114bfc4: mov             x2, x0
    // 0x114bfc8: ldr             x0, [fp, #0x10]
    // 0x114bfcc: stur            x2, [fp, #-0x18]
    // 0x114bfd0: LoadField: r1 = r0->field_b
    //     0x114bfd0: ldur            w1, [x0, #0xb]
    // 0x114bfd4: DecompressPointer r1
    //     0x114bfd4: add             x1, x1, HEAP, lsl #32
    // 0x114bfd8: cmp             w1, NULL
    // 0x114bfdc: b.ne            #0x114bfe8
    // 0x114bfe0: r3 = Null
    //     0x114bfe0: mov             x3, NULL
    // 0x114bfe4: b               #0x114c00c
    // 0x114bfe8: r0 = hashAll()
    //     0x114bfe8: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114bfec: mov             x2, x0
    // 0x114bff0: r0 = BoxInt64Instr(r2)
    //     0x114bff0: sbfiz           x0, x2, #1, #0x1f
    //     0x114bff4: cmp             x2, x0, asr #1
    //     0x114bff8: b.eq            #0x114c004
    //     0x114bffc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c000: stur            x2, [x0, #7]
    // 0x114c004: mov             x3, x0
    // 0x114c008: ldur            x2, [fp, #-0x18]
    // 0x114c00c: ldur            d0, [fp, #-0x28]
    // 0x114c010: ldur            d1, [fp, #-0x20]
    // 0x114c014: r4 = inline_Allocate_Double()
    //     0x114c014: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0x114c018: add             x4, x4, #0x10
    //     0x114c01c: cmp             x0, x4
    //     0x114c020: b.ls            #0x114c0d8
    //     0x114c024: str             x4, [THR, #0x60]  ; THR::top
    //     0x114c028: sub             x4, x4, #0xf
    //     0x114c02c: mov             x0, #0xe19c
    //     0x114c030: movk            x0, #3, lsl #16
    //     0x114c034: stur            x0, [x4, #-1]
    // 0x114c038: dmb             ishst
    // 0x114c03c: StoreField: r4->field_7 = d0
    //     0x114c03c: stur            d0, [x4, #7]
    // 0x114c040: r5 = inline_Allocate_Double()
    //     0x114c040: ldp             x5, x0, [THR, #0x60]  ; THR::top
    //     0x114c044: add             x5, x5, #0x10
    //     0x114c048: cmp             x0, x5
    //     0x114c04c: b.ls            #0x114c0f4
    //     0x114c050: str             x5, [THR, #0x60]  ; THR::top
    //     0x114c054: sub             x5, x5, #0xf
    //     0x114c058: mov             x0, #0xe19c
    //     0x114c05c: movk            x0, #3, lsl #16
    //     0x114c060: stur            x0, [x5, #-1]
    // 0x114c064: dmb             ishst
    // 0x114c068: StoreField: r5->field_7 = d1
    //     0x114c068: stur            d1, [x5, #7]
    // 0x114c06c: r0 = BoxInt64Instr(r2)
    //     0x114c06c: sbfiz           x0, x2, #1, #0x1f
    //     0x114c070: cmp             x2, x0, asr #1
    //     0x114c074: b.eq            #0x114c080
    //     0x114c078: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c07c: stur            x2, [x0, #7]
    // 0x114c080: r16 = Instance_TileMode
    //     0x114c080: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x114c084: ldr             x16, [x16, #0x900]
    // 0x114c088: stp             x16, x5, [SP, #0x18]
    // 0x114c08c: ldur            x16, [fp, #-8]
    // 0x114c090: stp             x0, x16, [SP, #8]
    // 0x114c094: str             x3, [SP]
    // 0x114c098: ldur            x1, [fp, #-0x10]
    // 0x114c09c: mov             x2, x4
    // 0x114c0a0: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x114c0a0: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x114c0a4: ldr             x4, [x4, #0x8a0]
    // 0x114c0a8: r0 = hash()
    //     0x114c0a8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c0ac: mov             x2, x0
    // 0x114c0b0: r0 = BoxInt64Instr(r2)
    //     0x114c0b0: sbfiz           x0, x2, #1, #0x1f
    //     0x114c0b4: cmp             x2, x0, asr #1
    //     0x114c0b8: b.eq            #0x114c0c4
    //     0x114c0bc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c0c0: stur            x2, [x0, #7]
    // 0x114c0c4: LeaveFrame
    //     0x114c0c4: mov             SP, fp
    //     0x114c0c8: ldp             fp, lr, [SP], #0x10
    // 0x114c0cc: ret
    //     0x114c0cc: ret             
    // 0x114c0d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c0d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c0d4: b               #0x114bf8c
    // 0x114c0d8: stp             q0, q1, [SP, #-0x20]!
    // 0x114c0dc: stp             x2, x3, [SP, #-0x10]!
    // 0x114c0e0: r0 = AllocateDouble()
    //     0x114c0e0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c0e4: mov             x4, x0
    // 0x114c0e8: ldp             x2, x3, [SP], #0x10
    // 0x114c0ec: ldp             q0, q1, [SP], #0x20
    // 0x114c0f0: b               #0x114c03c
    // 0x114c0f4: SaveReg d1
    //     0x114c0f4: str             q1, [SP, #-0x10]!
    // 0x114c0f8: stp             x3, x4, [SP, #-0x10]!
    // 0x114c0fc: SaveReg r2
    //     0x114c0fc: str             x2, [SP, #-8]!
    // 0x114c100: r0 = AllocateDouble()
    //     0x114c100: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c104: mov             x5, x0
    // 0x114c108: RestoreReg r2
    //     0x114c108: ldr             x2, [SP], #8
    // 0x114c10c: ldp             x3, x4, [SP], #0x10
    // 0x114c110: RestoreReg d1
    //     0x114c110: ldr             q1, [SP], #0x10
    // 0x114c114: b               #0x114c068
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1162380, size: 0x3b4
    // 0x1162380: EnterFrame
    //     0x1162380: stp             fp, lr, [SP, #-0x10]!
    //     0x1162384: mov             fp, SP
    // 0x1162388: AllocStack(0x48)
    //     0x1162388: sub             SP, SP, #0x48
    // 0x116238c: SetupParameters(dynamic _ /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0x116238c: mov             x0, x2
    //     0x1162390: stur            x2, [fp, #-0x18]
    //     0x1162394: mov             x2, x1
    //     0x1162398: stur            x1, [fp, #-0x10]
    //     0x116239c: stur            d0, [fp, #-0x38]
    // 0x11623a0: CheckStackOverflow
    //     0x11623a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11623a4: cmp             SP, x16
    //     0x11623a8: b.ls            #0x1162658
    // 0x11623ac: cmp             w2, w0
    // 0x11623b0: b.ne            #0x11623c4
    // 0x11623b4: mov             x0, x2
    // 0x11623b8: LeaveFrame
    //     0x11623b8: mov             SP, fp
    //     0x11623bc: ldp             fp, lr, [SP], #0x10
    // 0x11623c0: ret
    //     0x11623c0: ret             
    // 0x11623c4: cmp             w2, NULL
    // 0x11623c8: b.ne            #0x11623e0
    // 0x11623cc: mov             x1, x0
    // 0x11623d0: r0 = scale()
    //     0x11623d0: bl              #0x1305db0  ; [package:flutter/src/painting/gradient.dart] SweepGradient::scale
    // 0x11623d4: LeaveFrame
    //     0x11623d4: mov             SP, fp
    //     0x11623d8: ldp             fp, lr, [SP], #0x10
    // 0x11623dc: ret
    //     0x11623dc: ret             
    // 0x11623e0: cmp             w0, NULL
    // 0x11623e4: b.ne            #0x1162408
    // 0x11623e8: d1 = 1.000000
    //     0x11623e8: fmov            d1, #1.00000000
    // 0x11623ec: fsub            d2, d1, d0
    // 0x11623f0: mov             x1, x2
    // 0x11623f4: mov             v0.16b, v2.16b
    // 0x11623f8: r0 = scale()
    //     0x11623f8: bl              #0x1305db0  ; [package:flutter/src/painting/gradient.dart] SweepGradient::scale
    // 0x11623fc: LeaveFrame
    //     0x11623fc: mov             SP, fp
    //     0x1162400: ldp             fp, lr, [SP], #0x10
    // 0x1162404: ret
    //     0x1162404: ret             
    // 0x1162408: LoadField: r3 = r2->field_7
    //     0x1162408: ldur            w3, [x2, #7]
    // 0x116240c: DecompressPointer r3
    //     0x116240c: add             x3, x3, HEAP, lsl #32
    // 0x1162410: mov             x1, x2
    // 0x1162414: stur            x3, [fp, #-8]
    // 0x1162418: r0 = _impliedStops()
    //     0x1162418: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x116241c: mov             x2, x0
    // 0x1162420: ldur            x0, [fp, #-0x18]
    // 0x1162424: stur            x2, [fp, #-0x28]
    // 0x1162428: LoadField: r3 = r0->field_7
    //     0x1162428: ldur            w3, [x0, #7]
    // 0x116242c: DecompressPointer r3
    //     0x116242c: add             x3, x3, HEAP, lsl #32
    // 0x1162430: mov             x1, x0
    // 0x1162434: stur            x3, [fp, #-0x20]
    // 0x1162438: r0 = _impliedStops()
    //     0x1162438: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x116243c: ldur            x1, [fp, #-8]
    // 0x1162440: ldur            x2, [fp, #-0x28]
    // 0x1162444: ldur            x3, [fp, #-0x20]
    // 0x1162448: mov             x5, x0
    // 0x116244c: ldur            d0, [fp, #-0x38]
    // 0x1162450: r0 = _interpolateColorsAndStops()
    //     0x1162450: bl              #0x1161a6c  ; [package:flutter/src/painting/gradient.dart] ::_interpolateColorsAndStops
    // 0x1162454: mov             x3, x0
    // 0x1162458: ldur            x0, [fp, #-0x10]
    // 0x116245c: stur            x3, [fp, #-8]
    // 0x1162460: LoadField: r1 = r0->field_13
    //     0x1162460: ldur            w1, [x0, #0x13]
    // 0x1162464: DecompressPointer r1
    //     0x1162464: add             x1, x1, HEAP, lsl #32
    // 0x1162468: ldur            x4, [fp, #-0x18]
    // 0x116246c: LoadField: r2 = r4->field_13
    //     0x116246c: ldur            w2, [x4, #0x13]
    // 0x1162470: DecompressPointer r2
    //     0x1162470: add             x2, x2, HEAP, lsl #32
    // 0x1162474: ldur            d0, [fp, #-0x38]
    // 0x1162478: r0 = lerp()
    //     0x1162478: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x116247c: mov             x4, x0
    // 0x1162480: ldur            x0, [fp, #-0x10]
    // 0x1162484: stur            x4, [fp, #-0x28]
    // 0x1162488: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1162488: ldur            d0, [x0, #0x17]
    // 0x116248c: ldur            x5, [fp, #-0x18]
    // 0x1162490: ArrayLoad: d1 = r5[0]  ; List_8
    //     0x1162490: ldur            d1, [x5, #0x17]
    // 0x1162494: ldur            d2, [fp, #-0x38]
    // 0x1162498: r6 = inline_Allocate_Double()
    //     0x1162498: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0x116249c: add             x6, x6, #0x10
    //     0x11624a0: cmp             x1, x6
    //     0x11624a4: b.ls            #0x1162660
    //     0x11624a8: str             x6, [THR, #0x60]  ; THR::top
    //     0x11624ac: sub             x6, x6, #0xf
    //     0x11624b0: mov             x1, #0xe19c
    //     0x11624b4: movk            x1, #3, lsl #16
    //     0x11624b8: stur            x1, [x6, #-1]
    // 0x11624bc: dmb             ishst
    // 0x11624c0: StoreField: r6->field_7 = d2
    //     0x11624c0: stur            d2, [x6, #7]
    // 0x11624c4: stur            x6, [fp, #-0x20]
    // 0x11624c8: r1 = inline_Allocate_Double()
    //     0x11624c8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11624cc: add             x1, x1, #0x10
    //     0x11624d0: cmp             x2, x1
    //     0x11624d4: b.ls            #0x116268c
    //     0x11624d8: str             x1, [THR, #0x60]  ; THR::top
    //     0x11624dc: sub             x1, x1, #0xf
    //     0x11624e0: mov             x2, #0xe19c
    //     0x11624e4: movk            x2, #3, lsl #16
    //     0x11624e8: stur            x2, [x1, #-1]
    // 0x11624ec: dmb             ishst
    // 0x11624f0: StoreField: r1->field_7 = d0
    //     0x11624f0: stur            d0, [x1, #7]
    // 0x11624f4: r2 = inline_Allocate_Double()
    //     0x11624f4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11624f8: add             x2, x2, #0x10
    //     0x11624fc: cmp             x3, x2
    //     0x1162500: b.ls            #0x11626b8
    //     0x1162504: str             x2, [THR, #0x60]  ; THR::top
    //     0x1162508: sub             x2, x2, #0xf
    //     0x116250c: mov             x3, #0xe19c
    //     0x1162510: movk            x3, #3, lsl #16
    //     0x1162514: stur            x3, [x2, #-1]
    // 0x1162518: dmb             ishst
    // 0x116251c: StoreField: r2->field_7 = d1
    //     0x116251c: stur            d1, [x2, #7]
    // 0x1162520: mov             x3, x6
    // 0x1162524: r0 = lerpDouble()
    //     0x1162524: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1162528: LoadField: d0 = r0->field_7
    //     0x1162528: ldur            d0, [x0, #7]
    // 0x116252c: d1 = 0.000000
    //     0x116252c: eor             v1.16b, v1.16b, v1.16b
    // 0x1162530: fmax            v2.2d, v1.2d, v0.2d
    // 0x1162534: ldur            x0, [fp, #-0x10]
    // 0x1162538: stur            d2, [fp, #-0x40]
    // 0x116253c: LoadField: d0 = r0->field_1f
    //     0x116253c: ldur            d0, [x0, #0x1f]
    // 0x1162540: ldur            x4, [fp, #-0x18]
    // 0x1162544: LoadField: d3 = r4->field_1f
    //     0x1162544: ldur            d3, [x4, #0x1f]
    // 0x1162548: r1 = inline_Allocate_Double()
    //     0x1162548: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x116254c: add             x1, x1, #0x10
    //     0x1162550: cmp             x2, x1
    //     0x1162554: b.ls            #0x11626e4
    //     0x1162558: str             x1, [THR, #0x60]  ; THR::top
    //     0x116255c: sub             x1, x1, #0xf
    //     0x1162560: mov             x2, #0xe19c
    //     0x1162564: movk            x2, #3, lsl #16
    //     0x1162568: stur            x2, [x1, #-1]
    // 0x116256c: dmb             ishst
    // 0x1162570: StoreField: r1->field_7 = d0
    //     0x1162570: stur            d0, [x1, #7]
    // 0x1162574: r2 = inline_Allocate_Double()
    //     0x1162574: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1162578: add             x2, x2, #0x10
    //     0x116257c: cmp             x3, x2
    //     0x1162580: b.ls            #0x1162708
    //     0x1162584: str             x2, [THR, #0x60]  ; THR::top
    //     0x1162588: sub             x2, x2, #0xf
    //     0x116258c: mov             x3, #0xe19c
    //     0x1162590: movk            x3, #3, lsl #16
    //     0x1162594: stur            x3, [x2, #-1]
    // 0x1162598: dmb             ishst
    // 0x116259c: StoreField: r2->field_7 = d3
    //     0x116259c: stur            d3, [x2, #7]
    // 0x11625a0: ldur            x3, [fp, #-0x20]
    // 0x11625a4: r0 = lerpDouble()
    //     0x11625a4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11625a8: LoadField: d0 = r0->field_7
    //     0x11625a8: ldur            d0, [x0, #7]
    // 0x11625ac: d1 = 0.000000
    //     0x11625ac: eor             v1.16b, v1.16b, v1.16b
    // 0x11625b0: fmax            v2.2d, v1.2d, v0.2d
    // 0x11625b4: ldur            x0, [fp, #-8]
    // 0x11625b8: stur            d2, [fp, #-0x48]
    // 0x11625bc: LoadField: r1 = r0->field_7
    //     0x11625bc: ldur            w1, [x0, #7]
    // 0x11625c0: DecompressPointer r1
    //     0x11625c0: add             x1, x1, HEAP, lsl #32
    // 0x11625c4: stur            x1, [fp, #-0x30]
    // 0x11625c8: LoadField: r2 = r0->field_b
    //     0x11625c8: ldur            w2, [x0, #0xb]
    // 0x11625cc: DecompressPointer r2
    //     0x11625cc: add             x2, x2, HEAP, lsl #32
    // 0x11625d0: ldur            d0, [fp, #-0x38]
    // 0x11625d4: stur            x2, [fp, #-0x20]
    // 0x11625d8: d1 = 0.500000
    //     0x11625d8: fmov            d1, #0.50000000
    // 0x11625dc: fcmp            d1, d0
    // 0x11625e0: b.le            #0x11625f4
    // 0x11625e4: ldur            x0, [fp, #-0x10]
    // 0x11625e8: LoadField: r3 = r0->field_f
    //     0x11625e8: ldur            w3, [x0, #0xf]
    // 0x11625ec: DecompressPointer r3
    //     0x11625ec: add             x3, x3, HEAP, lsl #32
    // 0x11625f0: b               #0x1162600
    // 0x11625f4: ldur            x0, [fp, #-0x18]
    // 0x11625f8: LoadField: r3 = r0->field_f
    //     0x11625f8: ldur            w3, [x0, #0xf]
    // 0x11625fc: DecompressPointer r3
    //     0x11625fc: add             x3, x3, HEAP, lsl #32
    // 0x1162600: ldur            x0, [fp, #-0x28]
    // 0x1162604: ldur            d0, [fp, #-0x40]
    // 0x1162608: stur            x3, [fp, #-8]
    // 0x116260c: r0 = SweepGradient()
    //     0x116260c: bl              #0x1160a74  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x1162610: ldur            x1, [fp, #-0x28]
    // 0x1162614: StoreField: r0->field_13 = r1
    //     0x1162614: stur            w1, [x0, #0x13]
    // 0x1162618: ldur            d0, [fp, #-0x40]
    // 0x116261c: ArrayStore: r0[0] = d0  ; List_8
    //     0x116261c: stur            d0, [x0, #0x17]
    // 0x1162620: ldur            d0, [fp, #-0x48]
    // 0x1162624: StoreField: r0->field_1f = d0
    //     0x1162624: stur            d0, [x0, #0x1f]
    // 0x1162628: r1 = Instance_TileMode
    //     0x1162628: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x116262c: ldr             x1, [x1, #0x900]
    // 0x1162630: StoreField: r0->field_27 = r1
    //     0x1162630: stur            w1, [x0, #0x27]
    // 0x1162634: ldur            x1, [fp, #-0x30]
    // 0x1162638: StoreField: r0->field_7 = r1
    //     0x1162638: stur            w1, [x0, #7]
    // 0x116263c: ldur            x1, [fp, #-0x20]
    // 0x1162640: StoreField: r0->field_b = r1
    //     0x1162640: stur            w1, [x0, #0xb]
    // 0x1162644: ldur            x1, [fp, #-8]
    // 0x1162648: StoreField: r0->field_f = r1
    //     0x1162648: stur            w1, [x0, #0xf]
    // 0x116264c: LeaveFrame
    //     0x116264c: mov             SP, fp
    //     0x1162650: ldp             fp, lr, [SP], #0x10
    // 0x1162654: ret
    //     0x1162654: ret             
    // 0x1162658: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162658: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116265c: b               #0x11623ac
    // 0x1162660: stp             q1, q2, [SP, #-0x20]!
    // 0x1162664: SaveReg d0
    //     0x1162664: str             q0, [SP, #-0x10]!
    // 0x1162668: stp             x4, x5, [SP, #-0x10]!
    // 0x116266c: SaveReg r0
    //     0x116266c: str             x0, [SP, #-8]!
    // 0x1162670: r0 = AllocateDouble()
    //     0x1162670: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162674: mov             x6, x0
    // 0x1162678: RestoreReg r0
    //     0x1162678: ldr             x0, [SP], #8
    // 0x116267c: ldp             x4, x5, [SP], #0x10
    // 0x1162680: RestoreReg d0
    //     0x1162680: ldr             q0, [SP], #0x10
    // 0x1162684: ldp             q1, q2, [SP], #0x20
    // 0x1162688: b               #0x11624c0
    // 0x116268c: stp             q1, q2, [SP, #-0x20]!
    // 0x1162690: SaveReg d0
    //     0x1162690: str             q0, [SP, #-0x10]!
    // 0x1162694: stp             x5, x6, [SP, #-0x10]!
    // 0x1162698: stp             x0, x4, [SP, #-0x10]!
    // 0x116269c: r0 = AllocateDouble()
    //     0x116269c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11626a0: mov             x1, x0
    // 0x11626a4: ldp             x0, x4, [SP], #0x10
    // 0x11626a8: ldp             x5, x6, [SP], #0x10
    // 0x11626ac: RestoreReg d0
    //     0x11626ac: ldr             q0, [SP], #0x10
    // 0x11626b0: ldp             q1, q2, [SP], #0x20
    // 0x11626b4: b               #0x11624f0
    // 0x11626b8: stp             q1, q2, [SP, #-0x20]!
    // 0x11626bc: stp             x5, x6, [SP, #-0x10]!
    // 0x11626c0: stp             x1, x4, [SP, #-0x10]!
    // 0x11626c4: SaveReg r0
    //     0x11626c4: str             x0, [SP, #-8]!
    // 0x11626c8: r0 = AllocateDouble()
    //     0x11626c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11626cc: mov             x2, x0
    // 0x11626d0: RestoreReg r0
    //     0x11626d0: ldr             x0, [SP], #8
    // 0x11626d4: ldp             x1, x4, [SP], #0x10
    // 0x11626d8: ldp             x5, x6, [SP], #0x10
    // 0x11626dc: ldp             q1, q2, [SP], #0x20
    // 0x11626e0: b               #0x116251c
    // 0x11626e4: stp             q2, q3, [SP, #-0x20]!
    // 0x11626e8: stp             q0, q1, [SP, #-0x20]!
    // 0x11626ec: stp             x0, x4, [SP, #-0x10]!
    // 0x11626f0: r0 = AllocateDouble()
    //     0x11626f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11626f4: mov             x1, x0
    // 0x11626f8: ldp             x0, x4, [SP], #0x10
    // 0x11626fc: ldp             q0, q1, [SP], #0x20
    // 0x1162700: ldp             q2, q3, [SP], #0x20
    // 0x1162704: b               #0x1162570
    // 0x1162708: stp             q2, q3, [SP, #-0x20]!
    // 0x116270c: SaveReg d1
    //     0x116270c: str             q1, [SP, #-0x10]!
    // 0x1162710: stp             x1, x4, [SP, #-0x10]!
    // 0x1162714: SaveReg r0
    //     0x1162714: str             x0, [SP, #-8]!
    // 0x1162718: r0 = AllocateDouble()
    //     0x1162718: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116271c: mov             x2, x0
    // 0x1162720: RestoreReg r0
    //     0x1162720: ldr             x0, [SP], #8
    // 0x1162724: ldp             x1, x4, [SP], #0x10
    // 0x1162728: RestoreReg d1
    //     0x1162728: ldr             q1, [SP], #0x10
    // 0x116272c: ldp             q2, q3, [SP], #0x20
    // 0x1162730: b               #0x116259c
  }
  [closure] Color <anonymous closure>(dynamic, Color) {
    // ** addr: 0x1162734, size: 0x48
    // 0x1162734: EnterFrame
    //     0x1162734: stp             fp, lr, [SP, #-0x10]!
    //     0x1162738: mov             fp, SP
    // 0x116273c: ldr             x0, [fp, #0x18]
    // 0x1162740: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1162740: ldur            w1, [x0, #0x17]
    // 0x1162744: DecompressPointer r1
    //     0x1162744: add             x1, x1, HEAP, lsl #32
    // 0x1162748: CheckStackOverflow
    //     0x1162748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116274c: cmp             SP, x16
    //     0x1162750: b.ls            #0x1162774
    // 0x1162754: LoadField: r3 = r1->field_f
    //     0x1162754: ldur            w3, [x1, #0xf]
    // 0x1162758: DecompressPointer r3
    //     0x1162758: add             x3, x3, HEAP, lsl #32
    // 0x116275c: ldr             x2, [fp, #0x10]
    // 0x1162760: r1 = Null
    //     0x1162760: mov             x1, NULL
    // 0x1162764: r0 = lerp()
    //     0x1162764: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1162768: LeaveFrame
    //     0x1162768: mov             SP, fp
    //     0x116276c: ldp             fp, lr, [SP], #0x10
    // 0x1162770: ret
    //     0x1162770: ret             
    // 0x1162774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1162774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1162778: b               #0x1162754
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299064, size: 0x1a0
    // 0x1299064: EnterFrame
    //     0x1299064: stp             fp, lr, [SP, #-0x10]!
    //     0x1299068: mov             fp, SP
    // 0x129906c: AllocStack(0x18)
    //     0x129906c: sub             SP, SP, #0x18
    // 0x1299070: CheckStackOverflow
    //     0x1299070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299074: cmp             SP, x16
    //     0x1299078: b.ls            #0x12991fc
    // 0x129907c: ldr             x0, [fp, #0x10]
    // 0x1299080: cmp             w0, NULL
    // 0x1299084: b.ne            #0x1299098
    // 0x1299088: r0 = false
    //     0x1299088: add             x0, NULL, #0x30  ; false
    // 0x129908c: LeaveFrame
    //     0x129908c: mov             SP, fp
    //     0x1299090: ldp             fp, lr, [SP], #0x10
    // 0x1299094: ret
    //     0x1299094: ret             
    // 0x1299098: ldr             x1, [fp, #0x18]
    // 0x129909c: cmp             w1, w0
    // 0x12990a0: b.ne            #0x12990b4
    // 0x12990a4: r0 = true
    //     0x12990a4: add             x0, NULL, #0x20  ; true
    // 0x12990a8: LeaveFrame
    //     0x12990a8: mov             SP, fp
    //     0x12990ac: ldp             fp, lr, [SP], #0x10
    // 0x12990b0: ret
    //     0x12990b0: ret             
    // 0x12990b4: str             x0, [SP]
    // 0x12990b8: r0 = runtimeType()
    //     0x12990b8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12990bc: r1 = LoadClassIdInstr(r0)
    //     0x12990bc: ldur            x1, [x0, #-1]
    //     0x12990c0: ubfx            x1, x1, #0xc, #0x14
    // 0x12990c4: r16 = SweepGradient
    //     0x12990c4: add             x16, PP, #0x95, lsl #12  ; [pp+0x95ac0] Type: SweepGradient
    //     0x12990c8: ldr             x16, [x16, #0xac0]
    // 0x12990cc: stp             x16, x0, [SP]
    // 0x12990d0: mov             x0, x1
    // 0x12990d4: mov             lr, x0
    // 0x12990d8: ldr             lr, [x21, lr, lsl #3]
    // 0x12990dc: blr             lr
    // 0x12990e0: tbz             w0, #4, #0x12990f4
    // 0x12990e4: r0 = false
    //     0x12990e4: add             x0, NULL, #0x30  ; false
    // 0x12990e8: LeaveFrame
    //     0x12990e8: mov             SP, fp
    //     0x12990ec: ldp             fp, lr, [SP], #0x10
    // 0x12990f0: ret
    //     0x12990f0: ret             
    // 0x12990f4: ldr             x0, [fp, #0x10]
    // 0x12990f8: r1 = 60
    //     0x12990f8: mov             x1, #0x3c
    // 0x12990fc: branchIfSmi(r0, 0x1299108)
    //     0x12990fc: tbz             w0, #0, #0x1299108
    // 0x1299100: r1 = LoadClassIdInstr(r0)
    //     0x1299100: ldur            x1, [x0, #-1]
    //     0x1299104: ubfx            x1, x1, #0xc, #0x14
    // 0x1299108: cmp             x1, #0xb73
    // 0x129910c: b.ne            #0x12991ec
    // 0x1299110: ldr             x1, [fp, #0x18]
    // 0x1299114: LoadField: r2 = r0->field_13
    //     0x1299114: ldur            w2, [x0, #0x13]
    // 0x1299118: DecompressPointer r2
    //     0x1299118: add             x2, x2, HEAP, lsl #32
    // 0x129911c: LoadField: r3 = r1->field_13
    //     0x129911c: ldur            w3, [x1, #0x13]
    // 0x1299120: DecompressPointer r3
    //     0x1299120: add             x3, x3, HEAP, lsl #32
    // 0x1299124: stp             x3, x2, [SP]
    // 0x1299128: r0 = ==()
    //     0x1299128: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x129912c: tbnz            w0, #4, #0x12991ec
    // 0x1299130: ldr             x2, [fp, #0x18]
    // 0x1299134: ldr             x1, [fp, #0x10]
    // 0x1299138: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1299138: ldur            d0, [x1, #0x17]
    // 0x129913c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x129913c: ldur            d1, [x2, #0x17]
    // 0x1299140: fcmp            d0, d1
    // 0x1299144: b.ne            #0x12991ec
    // 0x1299148: LoadField: d0 = r1->field_1f
    //     0x1299148: ldur            d0, [x1, #0x1f]
    // 0x129914c: LoadField: d1 = r2->field_1f
    //     0x129914c: ldur            d1, [x2, #0x1f]
    // 0x1299150: fcmp            d0, d1
    // 0x1299154: b.ne            #0x12991ec
    // 0x1299158: LoadField: r0 = r1->field_f
    //     0x1299158: ldur            w0, [x1, #0xf]
    // 0x129915c: DecompressPointer r0
    //     0x129915c: add             x0, x0, HEAP, lsl #32
    // 0x1299160: LoadField: r3 = r2->field_f
    //     0x1299160: ldur            w3, [x2, #0xf]
    // 0x1299164: DecompressPointer r3
    //     0x1299164: add             x3, x3, HEAP, lsl #32
    // 0x1299168: r4 = LoadClassIdInstr(r0)
    //     0x1299168: ldur            x4, [x0, #-1]
    //     0x129916c: ubfx            x4, x4, #0xc, #0x14
    // 0x1299170: stp             x3, x0, [SP]
    // 0x1299174: mov             x0, x4
    // 0x1299178: mov             lr, x0
    // 0x129917c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299180: blr             lr
    // 0x1299184: tbnz            w0, #4, #0x12991ec
    // 0x1299188: ldr             x1, [fp, #0x18]
    // 0x129918c: ldr             x0, [fp, #0x10]
    // 0x1299190: LoadField: r2 = r0->field_7
    //     0x1299190: ldur            w2, [x0, #7]
    // 0x1299194: DecompressPointer r2
    //     0x1299194: add             x2, x2, HEAP, lsl #32
    // 0x1299198: LoadField: r3 = r1->field_7
    //     0x1299198: ldur            w3, [x1, #7]
    // 0x129919c: DecompressPointer r3
    //     0x129919c: add             x3, x3, HEAP, lsl #32
    // 0x12991a0: r16 = <Color>
    //     0x12991a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12991a4: ldr             x16, [x16, #0xa90]
    // 0x12991a8: stp             x2, x16, [SP, #8]
    // 0x12991ac: str             x3, [SP]
    // 0x12991b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12991b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12991b4: r0 = listEquals()
    //     0x12991b4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12991b8: tbnz            w0, #4, #0x12991ec
    // 0x12991bc: ldr             x1, [fp, #0x18]
    // 0x12991c0: ldr             x0, [fp, #0x10]
    // 0x12991c4: LoadField: r2 = r0->field_b
    //     0x12991c4: ldur            w2, [x0, #0xb]
    // 0x12991c8: DecompressPointer r2
    //     0x12991c8: add             x2, x2, HEAP, lsl #32
    // 0x12991cc: LoadField: r0 = r1->field_b
    //     0x12991cc: ldur            w0, [x1, #0xb]
    // 0x12991d0: DecompressPointer r0
    //     0x12991d0: add             x0, x0, HEAP, lsl #32
    // 0x12991d4: r16 = <double>
    //     0x12991d4: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12991d8: stp             x2, x16, [SP, #8]
    // 0x12991dc: str             x0, [SP]
    // 0x12991e0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12991e0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12991e4: r0 = listEquals()
    //     0x12991e4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12991e8: b               #0x12991f0
    // 0x12991ec: r0 = false
    //     0x12991ec: add             x0, NULL, #0x30  ; false
    // 0x12991f0: LeaveFrame
    //     0x12991f0: mov             SP, fp
    //     0x12991f4: ldp             fp, lr, [SP], #0x10
    // 0x12991f8: ret
    //     0x12991f8: ret             
    // 0x12991fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12991fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299200: b               #0x129907c
  }
  _ createShader(/* No info */) {
    // ** addr: 0x130597c, size: 0x204
    // 0x130597c: EnterFrame
    //     0x130597c: stp             fp, lr, [SP, #-0x10]!
    //     0x1305980: mov             fp, SP
    // 0x1305984: AllocStack(0x38)
    //     0x1305984: sub             SP, SP, #0x38
    // 0x1305988: SetupParameters(SweepGradient this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, {dynamic textDirection = Null /* r0 */})
    //     0x1305988: stur            x1, [fp, #-8]
    //     0x130598c: stur            x2, [fp, #-0x10]
    //     0x1305990: ldur            w0, [x4, #0x13]
    //     0x1305994: ldur            w3, [x4, #0x1f]
    //     0x1305998: add             x3, x3, HEAP, lsl #32
    //     0x130599c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x13059a0: ldr             x16, [x16, #0x210]
    //     0x13059a4: cmp             w3, w16
    //     0x13059a8: b.ne            #0x13059c4
    //     0x13059ac: ldur            w3, [x4, #0x23]
    //     0x13059b0: add             x3, x3, HEAP, lsl #32
    //     0x13059b4: sub             w4, w0, w3
    //     0x13059b8: add             x0, fp, w4, sxtw #2
    //     0x13059bc: ldr             x0, [x0, #8]
    //     0x13059c0: b               #0x13059c8
    //     0x13059c4: mov             x0, NULL
    // 0x13059c8: CheckStackOverflow
    //     0x13059c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13059cc: cmp             SP, x16
    //     0x13059d0: b.ls            #0x1305b70
    // 0x13059d4: LoadField: r3 = r1->field_13
    //     0x13059d4: ldur            w3, [x1, #0x13]
    // 0x13059d8: DecompressPointer r3
    //     0x13059d8: add             x3, x3, HEAP, lsl #32
    // 0x13059dc: r4 = LoadClassIdInstr(r3)
    //     0x13059dc: ldur            x4, [x3, #-1]
    //     0x13059e0: ubfx            x4, x4, #0xc, #0x14
    // 0x13059e4: sub             x16, x4, #0xb8e
    // 0x13059e8: cmp             x16, #1
    // 0x13059ec: b.hi            #0x13059fc
    // 0x13059f0: mov             x0, x1
    // 0x13059f4: mov             x1, x3
    // 0x13059f8: b               #0x1305aec
    // 0x13059fc: cmp             x4, #0xb8c
    // 0x1305a00: b.ne            #0x1305a80
    // 0x1305a04: cmp             w0, NULL
    // 0x1305a08: b.eq            #0x1305b78
    // 0x1305a0c: LoadField: r4 = r0->field_7
    //     0x1305a0c: ldur            x4, [x0, #7]
    // 0x1305a10: cmp             x4, #0
    // 0x1305a14: b.gt            #0x1305a48
    // 0x1305a18: LoadField: d0 = r3->field_7
    //     0x1305a18: ldur            d0, [x3, #7]
    // 0x1305a1c: LoadField: d1 = r3->field_f
    //     0x1305a1c: ldur            d1, [x3, #0xf]
    // 0x1305a20: fsub            d2, d0, d1
    // 0x1305a24: stur            d2, [fp, #-0x38]
    // 0x1305a28: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x1305a28: ldur            d0, [x3, #0x17]
    // 0x1305a2c: stur            d0, [fp, #-0x30]
    // 0x1305a30: r0 = Alignment()
    //     0x1305a30: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305a34: ldur            d0, [fp, #-0x38]
    // 0x1305a38: StoreField: r0->field_7 = d0
    //     0x1305a38: stur            d0, [x0, #7]
    // 0x1305a3c: ldur            d0, [fp, #-0x30]
    // 0x1305a40: StoreField: r0->field_f = d0
    //     0x1305a40: stur            d0, [x0, #0xf]
    // 0x1305a44: b               #0x1305a74
    // 0x1305a48: LoadField: d0 = r3->field_7
    //     0x1305a48: ldur            d0, [x3, #7]
    // 0x1305a4c: LoadField: d1 = r3->field_f
    //     0x1305a4c: ldur            d1, [x3, #0xf]
    // 0x1305a50: fadd            d2, d0, d1
    // 0x1305a54: stur            d2, [fp, #-0x38]
    // 0x1305a58: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x1305a58: ldur            d0, [x3, #0x17]
    // 0x1305a5c: stur            d0, [fp, #-0x30]
    // 0x1305a60: r0 = Alignment()
    //     0x1305a60: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305a64: ldur            d0, [fp, #-0x38]
    // 0x1305a68: StoreField: r0->field_7 = d0
    //     0x1305a68: stur            d0, [x0, #7]
    // 0x1305a6c: ldur            d0, [fp, #-0x30]
    // 0x1305a70: StoreField: r0->field_f = d0
    //     0x1305a70: stur            d0, [x0, #0xf]
    // 0x1305a74: mov             x1, x0
    // 0x1305a78: ldur            x0, [fp, #-8]
    // 0x1305a7c: b               #0x1305aec
    // 0x1305a80: cmp             w0, NULL
    // 0x1305a84: b.eq            #0x1305b7c
    // 0x1305a88: LoadField: r1 = r0->field_7
    //     0x1305a88: ldur            x1, [x0, #7]
    // 0x1305a8c: cmp             x1, #0
    // 0x1305a90: b.gt            #0x1305ac0
    // 0x1305a94: LoadField: d0 = r3->field_7
    //     0x1305a94: ldur            d0, [x3, #7]
    // 0x1305a98: fneg            d1, d0
    // 0x1305a9c: stur            d1, [fp, #-0x38]
    // 0x1305aa0: LoadField: d0 = r3->field_f
    //     0x1305aa0: ldur            d0, [x3, #0xf]
    // 0x1305aa4: stur            d0, [fp, #-0x30]
    // 0x1305aa8: r0 = Alignment()
    //     0x1305aa8: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305aac: ldur            d0, [fp, #-0x38]
    // 0x1305ab0: StoreField: r0->field_7 = d0
    //     0x1305ab0: stur            d0, [x0, #7]
    // 0x1305ab4: ldur            d0, [fp, #-0x30]
    // 0x1305ab8: StoreField: r0->field_f = d0
    //     0x1305ab8: stur            d0, [x0, #0xf]
    // 0x1305abc: b               #0x1305ae4
    // 0x1305ac0: LoadField: d0 = r3->field_7
    //     0x1305ac0: ldur            d0, [x3, #7]
    // 0x1305ac4: stur            d0, [fp, #-0x38]
    // 0x1305ac8: LoadField: d1 = r3->field_f
    //     0x1305ac8: ldur            d1, [x3, #0xf]
    // 0x1305acc: stur            d1, [fp, #-0x30]
    // 0x1305ad0: r0 = Alignment()
    //     0x1305ad0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305ad4: ldur            d0, [fp, #-0x38]
    // 0x1305ad8: StoreField: r0->field_7 = d0
    //     0x1305ad8: stur            d0, [x0, #7]
    // 0x1305adc: ldur            d0, [fp, #-0x30]
    // 0x1305ae0: StoreField: r0->field_f = d0
    //     0x1305ae0: stur            d0, [x0, #0xf]
    // 0x1305ae4: mov             x1, x0
    // 0x1305ae8: ldur            x0, [fp, #-8]
    // 0x1305aec: ldur            x2, [fp, #-0x10]
    // 0x1305af0: r0 = withinRect()
    //     0x1305af0: bl              #0x12f7c84  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0x1305af4: mov             x2, x0
    // 0x1305af8: ldur            x0, [fp, #-8]
    // 0x1305afc: stur            x2, [fp, #-0x20]
    // 0x1305b00: LoadField: r3 = r0->field_7
    //     0x1305b00: ldur            w3, [x0, #7]
    // 0x1305b04: DecompressPointer r3
    //     0x1305b04: add             x3, x3, HEAP, lsl #32
    // 0x1305b08: mov             x1, x0
    // 0x1305b0c: stur            x3, [fp, #-0x18]
    // 0x1305b10: r0 = _impliedStops()
    //     0x1305b10: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x1305b14: ldur            x1, [fp, #-8]
    // 0x1305b18: stur            x0, [fp, #-0x28]
    // 0x1305b1c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1305b1c: ldur            d0, [x1, #0x17]
    // 0x1305b20: stur            d0, [fp, #-0x38]
    // 0x1305b24: LoadField: d1 = r1->field_1f
    //     0x1305b24: ldur            d1, [x1, #0x1f]
    // 0x1305b28: ldur            x2, [fp, #-0x10]
    // 0x1305b2c: stur            d1, [fp, #-0x30]
    // 0x1305b30: r0 = _resolveTransform()
    //     0x1305b30: bl              #0x12f7c18  ; [package:flutter/src/painting/gradient.dart] Gradient::_resolveTransform
    // 0x1305b34: stur            x0, [fp, #-8]
    // 0x1305b38: r0 = Gradient()
    //     0x1305b38: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x1305b3c: mov             x1, x0
    // 0x1305b40: ldur            x2, [fp, #-0x20]
    // 0x1305b44: ldur            x3, [fp, #-0x18]
    // 0x1305b48: ldur            x5, [fp, #-0x28]
    // 0x1305b4c: ldur            d0, [fp, #-0x38]
    // 0x1305b50: ldur            d1, [fp, #-0x30]
    // 0x1305b54: ldur            x6, [fp, #-8]
    // 0x1305b58: stur            x0, [fp, #-8]
    // 0x1305b5c: r0 = Gradient.sweep()
    //     0x1305b5c: bl              #0x12f7908  ; [dart:ui] Gradient::Gradient.sweep
    // 0x1305b60: ldur            x0, [fp, #-8]
    // 0x1305b64: LeaveFrame
    //     0x1305b64: mov             SP, fp
    //     0x1305b68: ldp             fp, lr, [SP], #0x10
    // 0x1305b6c: ret
    //     0x1305b6c: ret             
    // 0x1305b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1305b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1305b74: b               #0x13059d4
    // 0x1305b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1305b78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1305b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1305b7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0x1305db0, size: 0x240
    // 0x1305db0: EnterFrame
    //     0x1305db0: stp             fp, lr, [SP, #-0x10]!
    //     0x1305db4: mov             fp, SP
    // 0x1305db8: AllocStack(0x50)
    //     0x1305db8: sub             SP, SP, #0x50
    // 0x1305dbc: SetupParameters(SweepGradient this /* r1 => r1, fp-0x10 */)
    //     0x1305dbc: stur            x1, [fp, #-0x10]
    // 0x1305dc0: CheckStackOverflow
    //     0x1305dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1305dc4: cmp             SP, x16
    //     0x1305dc8: b.ls            #0x1305fd0
    // 0x1305dcc: r0 = inline_Allocate_Double()
    //     0x1305dcc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1305dd0: add             x0, x0, #0x10
    //     0x1305dd4: cmp             x2, x0
    //     0x1305dd8: b.ls            #0x1305fd8
    //     0x1305ddc: str             x0, [THR, #0x60]  ; THR::top
    //     0x1305de0: sub             x0, x0, #0xf
    //     0x1305de4: mov             x2, #0xe19c
    //     0x1305de8: movk            x2, #3, lsl #16
    //     0x1305dec: stur            x2, [x0, #-1]
    // 0x1305df0: dmb             ishst
    // 0x1305df4: StoreField: r0->field_7 = d0
    //     0x1305df4: stur            d0, [x0, #7]
    // 0x1305df8: stur            x0, [fp, #-8]
    // 0x1305dfc: r1 = 1
    //     0x1305dfc: mov             x1, #1
    // 0x1305e00: r0 = AllocateContext()
    //     0x1305e00: bl              #0x13de838  ; AllocateContextStub
    // 0x1305e04: mov             x1, x0
    // 0x1305e08: ldur            x0, [fp, #-8]
    // 0x1305e0c: StoreField: r1->field_f = r0
    //     0x1305e0c: stur            w0, [x1, #0xf]
    // 0x1305e10: ldur            x0, [fp, #-0x10]
    // 0x1305e14: LoadField: r3 = r0->field_13
    //     0x1305e14: ldur            w3, [x0, #0x13]
    // 0x1305e18: DecompressPointer r3
    //     0x1305e18: add             x3, x3, HEAP, lsl #32
    // 0x1305e1c: stur            x3, [fp, #-0x18]
    // 0x1305e20: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1305e20: ldur            d0, [x0, #0x17]
    // 0x1305e24: stur            d0, [fp, #-0x38]
    // 0x1305e28: LoadField: d1 = r0->field_1f
    //     0x1305e28: ldur            d1, [x0, #0x1f]
    // 0x1305e2c: stur            d1, [fp, #-0x30]
    // 0x1305e30: LoadField: r4 = r0->field_7
    //     0x1305e30: ldur            w4, [x0, #7]
    // 0x1305e34: DecompressPointer r4
    //     0x1305e34: add             x4, x4, HEAP, lsl #32
    // 0x1305e38: mov             x2, x1
    // 0x1305e3c: stur            x4, [fp, #-8]
    // 0x1305e40: r1 = Function '<anonymous closure>':.
    //     0x1305e40: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3900] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1305e44: ldr             x1, [x1, #0x900]
    // 0x1305e48: r0 = AllocateClosure()
    //     0x1305e48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1305e4c: r16 = <Color>
    //     0x1305e4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1305e50: ldr             x16, [x16, #0xa90]
    // 0x1305e54: ldur            lr, [fp, #-8]
    // 0x1305e58: stp             lr, x16, [SP, #8]
    // 0x1305e5c: str             x0, [SP]
    // 0x1305e60: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1305e60: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1305e64: r0 = map()
    //     0x1305e64: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1305e68: mov             x3, x0
    // 0x1305e6c: stur            x3, [fp, #-0x20]
    // 0x1305e70: LoadField: r4 = r3->field_7
    //     0x1305e70: ldur            w4, [x3, #7]
    // 0x1305e74: DecompressPointer r4
    //     0x1305e74: add             x4, x4, HEAP, lsl #32
    // 0x1305e78: mov             x0, x3
    // 0x1305e7c: stur            x4, [fp, #-8]
    // 0x1305e80: r2 = Null
    //     0x1305e80: mov             x2, NULL
    // 0x1305e84: r1 = Null
    //     0x1305e84: mov             x1, NULL
    // 0x1305e88: cmp             w0, NULL
    // 0x1305e8c: b.eq            #0x1305f24
    // 0x1305e90: branchIfSmi(r0, 0x1305f24)
    //     0x1305e90: tbz             w0, #0, #0x1305f24
    // 0x1305e94: r3 = LoadClassIdInstr(r0)
    //     0x1305e94: ldur            x3, [x0, #-1]
    //     0x1305e98: ubfx            x3, x3, #0xc, #0x14
    // 0x1305e9c: r17 = 7724
    //     0x1305e9c: mov             x17, #0x1e2c
    // 0x1305ea0: cmp             x3, x17
    // 0x1305ea4: b.eq            #0x1305f2c
    // 0x1305ea8: r4 = LoadClassIdInstr(r0)
    //     0x1305ea8: ldur            x4, [x0, #-1]
    //     0x1305eac: ubfx            x4, x4, #0xc, #0x14
    // 0x1305eb0: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1305eb4: ldr             x3, [x3, #0x18]
    // 0x1305eb8: ldr             x3, [x3, x4, lsl #3]
    // 0x1305ebc: LoadField: r3 = r3->field_2b
    //     0x1305ebc: ldur            w3, [x3, #0x2b]
    // 0x1305ec0: DecompressPointer r3
    //     0x1305ec0: add             x3, x3, HEAP, lsl #32
    // 0x1305ec4: cmp             w3, NULL
    // 0x1305ec8: b.eq            #0x1305f24
    // 0x1305ecc: LoadField: r3 = r3->field_f
    //     0x1305ecc: ldur            w3, [x3, #0xf]
    // 0x1305ed0: lsr             x3, x3, #3
    // 0x1305ed4: r17 = 7724
    //     0x1305ed4: mov             x17, #0x1e2c
    // 0x1305ed8: cmp             x3, x17
    // 0x1305edc: b.eq            #0x1305f2c
    // 0x1305ee0: r3 = SubtypeTestCache
    //     0x1305ee0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39b8] SubtypeTestCache
    //     0x1305ee4: ldr             x3, [x3, #0x9b8]
    // 0x1305ee8: r30 = Subtype1TestCacheStub
    //     0x1305ee8: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1305eec: LoadField: r30 = r30->field_7
    //     0x1305eec: ldur            lr, [lr, #7]
    // 0x1305ef0: blr             lr
    // 0x1305ef4: cmp             w7, NULL
    // 0x1305ef8: b.eq            #0x1305f04
    // 0x1305efc: tbnz            w7, #4, #0x1305f24
    // 0x1305f00: b               #0x1305f2c
    // 0x1305f04: r8 = EfficientLengthIterable
    //     0x1305f04: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa39c0] Type: EfficientLengthIterable
    //     0x1305f08: ldr             x8, [x8, #0x9c0]
    // 0x1305f0c: r3 = SubtypeTestCache
    //     0x1305f0c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39c8] SubtypeTestCache
    //     0x1305f10: ldr             x3, [x3, #0x9c8]
    // 0x1305f14: r30 = InstanceOfStub
    //     0x1305f14: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1305f18: LoadField: r30 = r30->field_7
    //     0x1305f18: ldur            lr, [lr, #7]
    // 0x1305f1c: blr             lr
    // 0x1305f20: b               #0x1305f30
    // 0x1305f24: r0 = false
    //     0x1305f24: add             x0, NULL, #0x30  ; false
    // 0x1305f28: b               #0x1305f30
    // 0x1305f2c: r0 = true
    //     0x1305f2c: add             x0, NULL, #0x20  ; true
    // 0x1305f30: tbnz            w0, #4, #0x1305f48
    // 0x1305f34: ldur            x1, [fp, #-8]
    // 0x1305f38: ldur            x2, [fp, #-0x20]
    // 0x1305f3c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1305f3c: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1305f40: mov             x2, x0
    // 0x1305f44: b               #0x1305f58
    // 0x1305f48: ldur            x1, [fp, #-8]
    // 0x1305f4c: ldur            x2, [fp, #-0x20]
    // 0x1305f50: r0 = _GrowableList._ofOther()
    //     0x1305f50: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x1305f54: mov             x2, x0
    // 0x1305f58: ldur            x0, [fp, #-0x10]
    // 0x1305f5c: ldur            x1, [fp, #-0x18]
    // 0x1305f60: ldur            d0, [fp, #-0x38]
    // 0x1305f64: ldur            d1, [fp, #-0x30]
    // 0x1305f68: stur            x2, [fp, #-0x28]
    // 0x1305f6c: LoadField: r3 = r0->field_b
    //     0x1305f6c: ldur            w3, [x0, #0xb]
    // 0x1305f70: DecompressPointer r3
    //     0x1305f70: add             x3, x3, HEAP, lsl #32
    // 0x1305f74: stur            x3, [fp, #-0x20]
    // 0x1305f78: LoadField: r4 = r0->field_f
    //     0x1305f78: ldur            w4, [x0, #0xf]
    // 0x1305f7c: DecompressPointer r4
    //     0x1305f7c: add             x4, x4, HEAP, lsl #32
    // 0x1305f80: stur            x4, [fp, #-8]
    // 0x1305f84: r0 = SweepGradient()
    //     0x1305f84: bl              #0x1160a74  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x1305f88: ldur            x1, [fp, #-0x18]
    // 0x1305f8c: StoreField: r0->field_13 = r1
    //     0x1305f8c: stur            w1, [x0, #0x13]
    // 0x1305f90: ldur            d0, [fp, #-0x38]
    // 0x1305f94: ArrayStore: r0[0] = d0  ; List_8
    //     0x1305f94: stur            d0, [x0, #0x17]
    // 0x1305f98: ldur            d0, [fp, #-0x30]
    // 0x1305f9c: StoreField: r0->field_1f = d0
    //     0x1305f9c: stur            d0, [x0, #0x1f]
    // 0x1305fa0: r1 = Instance_TileMode
    //     0x1305fa0: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x1305fa4: ldr             x1, [x1, #0x900]
    // 0x1305fa8: StoreField: r0->field_27 = r1
    //     0x1305fa8: stur            w1, [x0, #0x27]
    // 0x1305fac: ldur            x1, [fp, #-0x28]
    // 0x1305fb0: StoreField: r0->field_7 = r1
    //     0x1305fb0: stur            w1, [x0, #7]
    // 0x1305fb4: ldur            x1, [fp, #-0x20]
    // 0x1305fb8: StoreField: r0->field_b = r1
    //     0x1305fb8: stur            w1, [x0, #0xb]
    // 0x1305fbc: ldur            x1, [fp, #-8]
    // 0x1305fc0: StoreField: r0->field_f = r1
    //     0x1305fc0: stur            w1, [x0, #0xf]
    // 0x1305fc4: LeaveFrame
    //     0x1305fc4: mov             SP, fp
    //     0x1305fc8: ldp             fp, lr, [SP], #0x10
    // 0x1305fcc: ret
    //     0x1305fcc: ret             
    // 0x1305fd0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1305fd0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1305fd4: b               #0x1305dcc
    // 0x1305fd8: SaveReg d0
    //     0x1305fd8: str             q0, [SP, #-0x10]!
    // 0x1305fdc: SaveReg r1
    //     0x1305fdc: str             x1, [SP, #-8]!
    // 0x1305fe0: r0 = AllocateDouble()
    //     0x1305fe0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1305fe4: RestoreReg r1
    //     0x1305fe4: ldr             x1, [SP], #8
    // 0x1305fe8: RestoreReg d0
    //     0x1305fe8: ldr             q0, [SP], #0x10
    // 0x1305fec: b               #0x1305df4
  }
}

// class id: 2932, size: 0x20, field offset: 0x14
//   const constructor, 
class LinearGradient extends Gradient {

  _ImmutableList<Color> field_8;
  Alignment field_14;
  Alignment field_18;
  TileMode field_1c;

  get _ hashCode(/* No info */) {
    // ** addr: 0x114be78, size: 0xfc
    // 0x114be78: EnterFrame
    //     0x114be78: stp             fp, lr, [SP, #-0x10]!
    //     0x114be7c: mov             fp, SP
    // 0x114be80: AllocStack(0x40)
    //     0x114be80: sub             SP, SP, #0x40
    // 0x114be84: CheckStackOverflow
    //     0x114be84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114be88: cmp             SP, x16
    //     0x114be8c: b.ls            #0x114bf6c
    // 0x114be90: ldr             x0, [fp, #0x10]
    // 0x114be94: LoadField: r2 = r0->field_13
    //     0x114be94: ldur            w2, [x0, #0x13]
    // 0x114be98: DecompressPointer r2
    //     0x114be98: add             x2, x2, HEAP, lsl #32
    // 0x114be9c: stur            x2, [fp, #-0x18]
    // 0x114bea0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x114bea0: ldur            w3, [x0, #0x17]
    // 0x114bea4: DecompressPointer r3
    //     0x114bea4: add             x3, x3, HEAP, lsl #32
    // 0x114bea8: stur            x3, [fp, #-0x10]
    // 0x114beac: LoadField: r4 = r0->field_f
    //     0x114beac: ldur            w4, [x0, #0xf]
    // 0x114beb0: DecompressPointer r4
    //     0x114beb0: add             x4, x4, HEAP, lsl #32
    // 0x114beb4: stur            x4, [fp, #-8]
    // 0x114beb8: LoadField: r1 = r0->field_7
    //     0x114beb8: ldur            w1, [x0, #7]
    // 0x114bebc: DecompressPointer r1
    //     0x114bebc: add             x1, x1, HEAP, lsl #32
    // 0x114bec0: r0 = hashAll()
    //     0x114bec0: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114bec4: mov             x2, x0
    // 0x114bec8: ldr             x0, [fp, #0x10]
    // 0x114becc: stur            x2, [fp, #-0x20]
    // 0x114bed0: LoadField: r1 = r0->field_b
    //     0x114bed0: ldur            w1, [x0, #0xb]
    // 0x114bed4: DecompressPointer r1
    //     0x114bed4: add             x1, x1, HEAP, lsl #32
    // 0x114bed8: cmp             w1, NULL
    // 0x114bedc: b.ne            #0x114bee8
    // 0x114bee0: r3 = Null
    //     0x114bee0: mov             x3, NULL
    // 0x114bee4: b               #0x114bf0c
    // 0x114bee8: r0 = hashAll()
    //     0x114bee8: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114beec: mov             x2, x0
    // 0x114bef0: r0 = BoxInt64Instr(r2)
    //     0x114bef0: sbfiz           x0, x2, #1, #0x1f
    //     0x114bef4: cmp             x2, x0, asr #1
    //     0x114bef8: b.eq            #0x114bf04
    //     0x114befc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114bf00: stur            x2, [x0, #7]
    // 0x114bf04: mov             x3, x0
    // 0x114bf08: ldur            x2, [fp, #-0x20]
    // 0x114bf0c: r0 = BoxInt64Instr(r2)
    //     0x114bf0c: sbfiz           x0, x2, #1, #0x1f
    //     0x114bf10: cmp             x2, x0, asr #1
    //     0x114bf14: b.eq            #0x114bf20
    //     0x114bf18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114bf1c: stur            x2, [x0, #7]
    // 0x114bf20: r16 = Instance_TileMode
    //     0x114bf20: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x114bf24: ldr             x16, [x16, #0x900]
    // 0x114bf28: ldur            lr, [fp, #-8]
    // 0x114bf2c: stp             lr, x16, [SP, #0x10]
    // 0x114bf30: stp             x3, x0, [SP]
    // 0x114bf34: ldur            x1, [fp, #-0x18]
    // 0x114bf38: ldur            x2, [fp, #-0x10]
    // 0x114bf3c: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x114bf3c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x114bf40: ldr             x4, [x4, #0xd28]
    // 0x114bf44: r0 = hash()
    //     0x114bf44: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114bf48: mov             x2, x0
    // 0x114bf4c: r0 = BoxInt64Instr(r2)
    //     0x114bf4c: sbfiz           x0, x2, #1, #0x1f
    //     0x114bf50: cmp             x2, x0, asr #1
    //     0x114bf54: b.eq            #0x114bf60
    //     0x114bf58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114bf5c: stur            x2, [x0, #7]
    // 0x114bf60: LeaveFrame
    //     0x114bf60: mov             SP, fp
    //     0x114bf64: ldp             fp, lr, [SP], #0x10
    // 0x114bf68: ret
    //     0x114bf68: ret             
    // 0x114bf6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114bf6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114bf70: b               #0x114be90
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1160a80, size: 0x1c8
    // 0x1160a80: EnterFrame
    //     0x1160a80: stp             fp, lr, [SP, #-0x10]!
    //     0x1160a84: mov             fp, SP
    // 0x1160a88: AllocStack(0x40)
    //     0x1160a88: sub             SP, SP, #0x40
    // 0x1160a8c: SetupParameters(dynamic _ /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0x1160a8c: mov             x0, x2
    //     0x1160a90: stur            x2, [fp, #-0x18]
    //     0x1160a94: mov             x2, x1
    //     0x1160a98: stur            x1, [fp, #-0x10]
    //     0x1160a9c: stur            d0, [fp, #-0x40]
    // 0x1160aa0: CheckStackOverflow
    //     0x1160aa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1160aa4: cmp             SP, x16
    //     0x1160aa8: b.ls            #0x1160c40
    // 0x1160aac: cmp             w2, w0
    // 0x1160ab0: b.ne            #0x1160ac4
    // 0x1160ab4: mov             x0, x2
    // 0x1160ab8: LeaveFrame
    //     0x1160ab8: mov             SP, fp
    //     0x1160abc: ldp             fp, lr, [SP], #0x10
    // 0x1160ac0: ret
    //     0x1160ac0: ret             
    // 0x1160ac4: cmp             w2, NULL
    // 0x1160ac8: b.ne            #0x1160ae0
    // 0x1160acc: mov             x1, x0
    // 0x1160ad0: r0 = scale()
    //     0x1160ad0: bl              #0x1305b80  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0x1160ad4: LeaveFrame
    //     0x1160ad4: mov             SP, fp
    //     0x1160ad8: ldp             fp, lr, [SP], #0x10
    // 0x1160adc: ret
    //     0x1160adc: ret             
    // 0x1160ae0: cmp             w0, NULL
    // 0x1160ae4: b.ne            #0x1160b08
    // 0x1160ae8: d1 = 1.000000
    //     0x1160ae8: fmov            d1, #1.00000000
    // 0x1160aec: fsub            d2, d1, d0
    // 0x1160af0: mov             x1, x2
    // 0x1160af4: mov             v0.16b, v2.16b
    // 0x1160af8: r0 = scale()
    //     0x1160af8: bl              #0x1305b80  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0x1160afc: LeaveFrame
    //     0x1160afc: mov             SP, fp
    //     0x1160b00: ldp             fp, lr, [SP], #0x10
    // 0x1160b04: ret
    //     0x1160b04: ret             
    // 0x1160b08: LoadField: r3 = r2->field_7
    //     0x1160b08: ldur            w3, [x2, #7]
    // 0x1160b0c: DecompressPointer r3
    //     0x1160b0c: add             x3, x3, HEAP, lsl #32
    // 0x1160b10: mov             x1, x2
    // 0x1160b14: stur            x3, [fp, #-8]
    // 0x1160b18: r0 = _impliedStops()
    //     0x1160b18: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x1160b1c: mov             x2, x0
    // 0x1160b20: ldur            x0, [fp, #-0x18]
    // 0x1160b24: stur            x2, [fp, #-0x28]
    // 0x1160b28: LoadField: r3 = r0->field_7
    //     0x1160b28: ldur            w3, [x0, #7]
    // 0x1160b2c: DecompressPointer r3
    //     0x1160b2c: add             x3, x3, HEAP, lsl #32
    // 0x1160b30: mov             x1, x0
    // 0x1160b34: stur            x3, [fp, #-0x20]
    // 0x1160b38: r0 = _impliedStops()
    //     0x1160b38: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x1160b3c: ldur            x1, [fp, #-8]
    // 0x1160b40: ldur            x2, [fp, #-0x28]
    // 0x1160b44: ldur            x3, [fp, #-0x20]
    // 0x1160b48: mov             x5, x0
    // 0x1160b4c: ldur            d0, [fp, #-0x40]
    // 0x1160b50: r0 = _interpolateColorsAndStops()
    //     0x1160b50: bl              #0x1161a6c  ; [package:flutter/src/painting/gradient.dart] ::_interpolateColorsAndStops
    // 0x1160b54: mov             x3, x0
    // 0x1160b58: ldur            x0, [fp, #-0x10]
    // 0x1160b5c: stur            x3, [fp, #-8]
    // 0x1160b60: LoadField: r1 = r0->field_13
    //     0x1160b60: ldur            w1, [x0, #0x13]
    // 0x1160b64: DecompressPointer r1
    //     0x1160b64: add             x1, x1, HEAP, lsl #32
    // 0x1160b68: ldur            x4, [fp, #-0x18]
    // 0x1160b6c: LoadField: r2 = r4->field_13
    //     0x1160b6c: ldur            w2, [x4, #0x13]
    // 0x1160b70: DecompressPointer r2
    //     0x1160b70: add             x2, x2, HEAP, lsl #32
    // 0x1160b74: ldur            d0, [fp, #-0x40]
    // 0x1160b78: r0 = lerp()
    //     0x1160b78: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x1160b7c: mov             x3, x0
    // 0x1160b80: ldur            x0, [fp, #-0x10]
    // 0x1160b84: stur            x3, [fp, #-0x20]
    // 0x1160b88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1160b88: ldur            w1, [x0, #0x17]
    // 0x1160b8c: DecompressPointer r1
    //     0x1160b8c: add             x1, x1, HEAP, lsl #32
    // 0x1160b90: ldur            x4, [fp, #-0x18]
    // 0x1160b94: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x1160b94: ldur            w2, [x4, #0x17]
    // 0x1160b98: DecompressPointer r2
    //     0x1160b98: add             x2, x2, HEAP, lsl #32
    // 0x1160b9c: ldur            d0, [fp, #-0x40]
    // 0x1160ba0: r0 = lerp()
    //     0x1160ba0: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x1160ba4: mov             x1, x0
    // 0x1160ba8: ldur            x0, [fp, #-8]
    // 0x1160bac: stur            x1, [fp, #-0x38]
    // 0x1160bb0: LoadField: r2 = r0->field_7
    //     0x1160bb0: ldur            w2, [x0, #7]
    // 0x1160bb4: DecompressPointer r2
    //     0x1160bb4: add             x2, x2, HEAP, lsl #32
    // 0x1160bb8: stur            x2, [fp, #-0x30]
    // 0x1160bbc: LoadField: r3 = r0->field_b
    //     0x1160bbc: ldur            w3, [x0, #0xb]
    // 0x1160bc0: DecompressPointer r3
    //     0x1160bc0: add             x3, x3, HEAP, lsl #32
    // 0x1160bc4: ldur            d0, [fp, #-0x40]
    // 0x1160bc8: stur            x3, [fp, #-0x28]
    // 0x1160bcc: d1 = 0.500000
    //     0x1160bcc: fmov            d1, #0.50000000
    // 0x1160bd0: fcmp            d1, d0
    // 0x1160bd4: b.le            #0x1160be8
    // 0x1160bd8: ldur            x0, [fp, #-0x10]
    // 0x1160bdc: LoadField: r4 = r0->field_f
    //     0x1160bdc: ldur            w4, [x0, #0xf]
    // 0x1160be0: DecompressPointer r4
    //     0x1160be0: add             x4, x4, HEAP, lsl #32
    // 0x1160be4: b               #0x1160bf4
    // 0x1160be8: ldur            x0, [fp, #-0x18]
    // 0x1160bec: LoadField: r4 = r0->field_f
    //     0x1160bec: ldur            w4, [x0, #0xf]
    // 0x1160bf0: DecompressPointer r4
    //     0x1160bf0: add             x4, x4, HEAP, lsl #32
    // 0x1160bf4: ldur            x0, [fp, #-0x20]
    // 0x1160bf8: stur            x4, [fp, #-8]
    // 0x1160bfc: r0 = LinearGradient()
    //     0x1160bfc: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x1160c00: ldur            x1, [fp, #-0x20]
    // 0x1160c04: StoreField: r0->field_13 = r1
    //     0x1160c04: stur            w1, [x0, #0x13]
    // 0x1160c08: ldur            x1, [fp, #-0x38]
    // 0x1160c0c: ArrayStore: r0[0] = r1  ; List_4
    //     0x1160c0c: stur            w1, [x0, #0x17]
    // 0x1160c10: r1 = Instance_TileMode
    //     0x1160c10: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x1160c14: ldr             x1, [x1, #0x900]
    // 0x1160c18: StoreField: r0->field_1b = r1
    //     0x1160c18: stur            w1, [x0, #0x1b]
    // 0x1160c1c: ldur            x1, [fp, #-0x30]
    // 0x1160c20: StoreField: r0->field_7 = r1
    //     0x1160c20: stur            w1, [x0, #7]
    // 0x1160c24: ldur            x1, [fp, #-0x28]
    // 0x1160c28: StoreField: r0->field_b = r1
    //     0x1160c28: stur            w1, [x0, #0xb]
    // 0x1160c2c: ldur            x1, [fp, #-8]
    // 0x1160c30: StoreField: r0->field_f = r1
    //     0x1160c30: stur            w1, [x0, #0xf]
    // 0x1160c34: LeaveFrame
    //     0x1160c34: mov             SP, fp
    //     0x1160c38: ldp             fp, lr, [SP], #0x10
    // 0x1160c3c: ret
    //     0x1160c3c: ret             
    // 0x1160c40: r0 = StackOverflowSharedWithFPURegs()
    //     0x1160c40: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1160c44: b               #0x1160aac
  }
  _ ==(/* No info */) {
    // ** addr: 0x1298ec0, size: 0x1a4
    // 0x1298ec0: EnterFrame
    //     0x1298ec0: stp             fp, lr, [SP, #-0x10]!
    //     0x1298ec4: mov             fp, SP
    // 0x1298ec8: AllocStack(0x18)
    //     0x1298ec8: sub             SP, SP, #0x18
    // 0x1298ecc: CheckStackOverflow
    //     0x1298ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1298ed0: cmp             SP, x16
    //     0x1298ed4: b.ls            #0x129905c
    // 0x1298ed8: ldr             x0, [fp, #0x10]
    // 0x1298edc: cmp             w0, NULL
    // 0x1298ee0: b.ne            #0x1298ef4
    // 0x1298ee4: r0 = false
    //     0x1298ee4: add             x0, NULL, #0x30  ; false
    // 0x1298ee8: LeaveFrame
    //     0x1298ee8: mov             SP, fp
    //     0x1298eec: ldp             fp, lr, [SP], #0x10
    // 0x1298ef0: ret
    //     0x1298ef0: ret             
    // 0x1298ef4: ldr             x1, [fp, #0x18]
    // 0x1298ef8: cmp             w1, w0
    // 0x1298efc: b.ne            #0x1298f10
    // 0x1298f00: r0 = true
    //     0x1298f00: add             x0, NULL, #0x20  ; true
    // 0x1298f04: LeaveFrame
    //     0x1298f04: mov             SP, fp
    //     0x1298f08: ldp             fp, lr, [SP], #0x10
    // 0x1298f0c: ret
    //     0x1298f0c: ret             
    // 0x1298f10: str             x0, [SP]
    // 0x1298f14: r0 = runtimeType()
    //     0x1298f14: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1298f18: r1 = LoadClassIdInstr(r0)
    //     0x1298f18: ldur            x1, [x0, #-1]
    //     0x1298f1c: ubfx            x1, x1, #0xc, #0x14
    // 0x1298f20: r16 = LinearGradient
    //     0x1298f20: add             x16, PP, #0x80, lsl #12  ; [pp+0x80898] Type: LinearGradient
    //     0x1298f24: ldr             x16, [x16, #0x898]
    // 0x1298f28: stp             x16, x0, [SP]
    // 0x1298f2c: mov             x0, x1
    // 0x1298f30: mov             lr, x0
    // 0x1298f34: ldr             lr, [x21, lr, lsl #3]
    // 0x1298f38: blr             lr
    // 0x1298f3c: tbz             w0, #4, #0x1298f50
    // 0x1298f40: r0 = false
    //     0x1298f40: add             x0, NULL, #0x30  ; false
    // 0x1298f44: LeaveFrame
    //     0x1298f44: mov             SP, fp
    //     0x1298f48: ldp             fp, lr, [SP], #0x10
    // 0x1298f4c: ret
    //     0x1298f4c: ret             
    // 0x1298f50: ldr             x0, [fp, #0x10]
    // 0x1298f54: r1 = 60
    //     0x1298f54: mov             x1, #0x3c
    // 0x1298f58: branchIfSmi(r0, 0x1298f64)
    //     0x1298f58: tbz             w0, #0, #0x1298f64
    // 0x1298f5c: r1 = LoadClassIdInstr(r0)
    //     0x1298f5c: ldur            x1, [x0, #-1]
    //     0x1298f60: ubfx            x1, x1, #0xc, #0x14
    // 0x1298f64: cmp             x1, #0xb74
    // 0x1298f68: b.ne            #0x129904c
    // 0x1298f6c: ldr             x1, [fp, #0x18]
    // 0x1298f70: LoadField: r2 = r0->field_13
    //     0x1298f70: ldur            w2, [x0, #0x13]
    // 0x1298f74: DecompressPointer r2
    //     0x1298f74: add             x2, x2, HEAP, lsl #32
    // 0x1298f78: LoadField: r3 = r1->field_13
    //     0x1298f78: ldur            w3, [x1, #0x13]
    // 0x1298f7c: DecompressPointer r3
    //     0x1298f7c: add             x3, x3, HEAP, lsl #32
    // 0x1298f80: stp             x3, x2, [SP]
    // 0x1298f84: r0 = ==()
    //     0x1298f84: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x1298f88: tbnz            w0, #4, #0x129904c
    // 0x1298f8c: ldr             x1, [fp, #0x18]
    // 0x1298f90: ldr             x0, [fp, #0x10]
    // 0x1298f94: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1298f94: ldur            w2, [x0, #0x17]
    // 0x1298f98: DecompressPointer r2
    //     0x1298f98: add             x2, x2, HEAP, lsl #32
    // 0x1298f9c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1298f9c: ldur            w3, [x1, #0x17]
    // 0x1298fa0: DecompressPointer r3
    //     0x1298fa0: add             x3, x3, HEAP, lsl #32
    // 0x1298fa4: stp             x3, x2, [SP]
    // 0x1298fa8: r0 = ==()
    //     0x1298fa8: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x1298fac: tbnz            w0, #4, #0x129904c
    // 0x1298fb0: ldr             x2, [fp, #0x18]
    // 0x1298fb4: ldr             x1, [fp, #0x10]
    // 0x1298fb8: LoadField: r0 = r1->field_f
    //     0x1298fb8: ldur            w0, [x1, #0xf]
    // 0x1298fbc: DecompressPointer r0
    //     0x1298fbc: add             x0, x0, HEAP, lsl #32
    // 0x1298fc0: LoadField: r3 = r2->field_f
    //     0x1298fc0: ldur            w3, [x2, #0xf]
    // 0x1298fc4: DecompressPointer r3
    //     0x1298fc4: add             x3, x3, HEAP, lsl #32
    // 0x1298fc8: r4 = LoadClassIdInstr(r0)
    //     0x1298fc8: ldur            x4, [x0, #-1]
    //     0x1298fcc: ubfx            x4, x4, #0xc, #0x14
    // 0x1298fd0: stp             x3, x0, [SP]
    // 0x1298fd4: mov             x0, x4
    // 0x1298fd8: mov             lr, x0
    // 0x1298fdc: ldr             lr, [x21, lr, lsl #3]
    // 0x1298fe0: blr             lr
    // 0x1298fe4: tbnz            w0, #4, #0x129904c
    // 0x1298fe8: ldr             x1, [fp, #0x18]
    // 0x1298fec: ldr             x0, [fp, #0x10]
    // 0x1298ff0: LoadField: r2 = r0->field_7
    //     0x1298ff0: ldur            w2, [x0, #7]
    // 0x1298ff4: DecompressPointer r2
    //     0x1298ff4: add             x2, x2, HEAP, lsl #32
    // 0x1298ff8: LoadField: r3 = r1->field_7
    //     0x1298ff8: ldur            w3, [x1, #7]
    // 0x1298ffc: DecompressPointer r3
    //     0x1298ffc: add             x3, x3, HEAP, lsl #32
    // 0x1299000: r16 = <Color>
    //     0x1299000: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1299004: ldr             x16, [x16, #0xa90]
    // 0x1299008: stp             x2, x16, [SP, #8]
    // 0x129900c: str             x3, [SP]
    // 0x1299010: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1299010: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1299014: r0 = listEquals()
    //     0x1299014: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1299018: tbnz            w0, #4, #0x129904c
    // 0x129901c: ldr             x1, [fp, #0x18]
    // 0x1299020: ldr             x0, [fp, #0x10]
    // 0x1299024: LoadField: r2 = r0->field_b
    //     0x1299024: ldur            w2, [x0, #0xb]
    // 0x1299028: DecompressPointer r2
    //     0x1299028: add             x2, x2, HEAP, lsl #32
    // 0x129902c: LoadField: r0 = r1->field_b
    //     0x129902c: ldur            w0, [x1, #0xb]
    // 0x1299030: DecompressPointer r0
    //     0x1299030: add             x0, x0, HEAP, lsl #32
    // 0x1299034: r16 = <double>
    //     0x1299034: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1299038: stp             x2, x16, [SP, #8]
    // 0x129903c: str             x0, [SP]
    // 0x1299040: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1299040: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1299044: r0 = listEquals()
    //     0x1299044: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1299048: b               #0x1299050
    // 0x129904c: r0 = false
    //     0x129904c: add             x0, NULL, #0x30  ; false
    // 0x1299050: LeaveFrame
    //     0x1299050: mov             SP, fp
    //     0x1299054: ldp             fp, lr, [SP], #0x10
    // 0x1299058: ret
    //     0x1299058: ret             
    // 0x129905c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129905c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299060: b               #0x1298ed8
  }
  _ createShader(/* No info */) {
    // ** addr: 0x1305638, size: 0x344
    // 0x1305638: EnterFrame
    //     0x1305638: stp             fp, lr, [SP, #-0x10]!
    //     0x130563c: mov             fp, SP
    // 0x1305640: AllocStack(0x58)
    //     0x1305640: sub             SP, SP, #0x58
    // 0x1305644: SetupParameters(LinearGradient this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0x1305644: stur            x1, [fp, #-0x10]
    //     0x1305648: stur            x2, [fp, #-0x18]
    //     0x130564c: ldur            w0, [x4, #0x13]
    //     0x1305650: ldur            w3, [x4, #0x1f]
    //     0x1305654: add             x3, x3, HEAP, lsl #32
    //     0x1305658: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x130565c: ldr             x16, [x16, #0x210]
    //     0x1305660: cmp             w3, w16
    //     0x1305664: b.ne            #0x1305680
    //     0x1305668: ldur            w3, [x4, #0x23]
    //     0x130566c: add             x3, x3, HEAP, lsl #32
    //     0x1305670: sub             w4, w0, w3
    //     0x1305674: add             x0, fp, w4, sxtw #2
    //     0x1305678: ldr             x0, [x0, #8]
    //     0x130567c: b               #0x1305684
    //     0x1305680: mov             x0, NULL
    //     0x1305684: stur            x0, [fp, #-8]
    // 0x1305688: CheckStackOverflow
    //     0x1305688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130568c: cmp             SP, x16
    //     0x1305690: b.ls            #0x1305964
    // 0x1305694: LoadField: r3 = r1->field_13
    //     0x1305694: ldur            w3, [x1, #0x13]
    // 0x1305698: DecompressPointer r3
    //     0x1305698: add             x3, x3, HEAP, lsl #32
    // 0x130569c: r4 = LoadClassIdInstr(r3)
    //     0x130569c: ldur            x4, [x3, #-1]
    //     0x13056a0: ubfx            x4, x4, #0xc, #0x14
    // 0x13056a4: sub             x16, x4, #0xb8e
    // 0x13056a8: cmp             x16, #1
    // 0x13056ac: b.hi            #0x13056bc
    // 0x13056b0: mov             x0, x1
    // 0x13056b4: mov             x1, x3
    // 0x13056b8: b               #0x13057ac
    // 0x13056bc: cmp             x4, #0xb8c
    // 0x13056c0: b.ne            #0x1305740
    // 0x13056c4: cmp             w0, NULL
    // 0x13056c8: b.eq            #0x130596c
    // 0x13056cc: LoadField: r4 = r0->field_7
    //     0x13056cc: ldur            x4, [x0, #7]
    // 0x13056d0: cmp             x4, #0
    // 0x13056d4: b.gt            #0x1305708
    // 0x13056d8: LoadField: d0 = r3->field_7
    //     0x13056d8: ldur            d0, [x3, #7]
    // 0x13056dc: LoadField: d1 = r3->field_f
    //     0x13056dc: ldur            d1, [x3, #0xf]
    // 0x13056e0: fsub            d2, d0, d1
    // 0x13056e4: stur            d2, [fp, #-0x40]
    // 0x13056e8: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x13056e8: ldur            d0, [x3, #0x17]
    // 0x13056ec: stur            d0, [fp, #-0x38]
    // 0x13056f0: r0 = Alignment()
    //     0x13056f0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x13056f4: ldur            d0, [fp, #-0x40]
    // 0x13056f8: StoreField: r0->field_7 = d0
    //     0x13056f8: stur            d0, [x0, #7]
    // 0x13056fc: ldur            d0, [fp, #-0x38]
    // 0x1305700: StoreField: r0->field_f = d0
    //     0x1305700: stur            d0, [x0, #0xf]
    // 0x1305704: b               #0x1305734
    // 0x1305708: LoadField: d0 = r3->field_7
    //     0x1305708: ldur            d0, [x3, #7]
    // 0x130570c: LoadField: d1 = r3->field_f
    //     0x130570c: ldur            d1, [x3, #0xf]
    // 0x1305710: fadd            d2, d0, d1
    // 0x1305714: stur            d2, [fp, #-0x40]
    // 0x1305718: ArrayLoad: d0 = r3[0]  ; List_8
    //     0x1305718: ldur            d0, [x3, #0x17]
    // 0x130571c: stur            d0, [fp, #-0x38]
    // 0x1305720: r0 = Alignment()
    //     0x1305720: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305724: ldur            d0, [fp, #-0x40]
    // 0x1305728: StoreField: r0->field_7 = d0
    //     0x1305728: stur            d0, [x0, #7]
    // 0x130572c: ldur            d0, [fp, #-0x38]
    // 0x1305730: StoreField: r0->field_f = d0
    //     0x1305730: stur            d0, [x0, #0xf]
    // 0x1305734: mov             x1, x0
    // 0x1305738: ldur            x0, [fp, #-0x10]
    // 0x130573c: b               #0x13057ac
    // 0x1305740: cmp             w0, NULL
    // 0x1305744: b.eq            #0x1305970
    // 0x1305748: LoadField: r1 = r0->field_7
    //     0x1305748: ldur            x1, [x0, #7]
    // 0x130574c: cmp             x1, #0
    // 0x1305750: b.gt            #0x1305780
    // 0x1305754: LoadField: d0 = r3->field_7
    //     0x1305754: ldur            d0, [x3, #7]
    // 0x1305758: fneg            d1, d0
    // 0x130575c: stur            d1, [fp, #-0x40]
    // 0x1305760: LoadField: d0 = r3->field_f
    //     0x1305760: ldur            d0, [x3, #0xf]
    // 0x1305764: stur            d0, [fp, #-0x38]
    // 0x1305768: r0 = Alignment()
    //     0x1305768: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x130576c: ldur            d0, [fp, #-0x40]
    // 0x1305770: StoreField: r0->field_7 = d0
    //     0x1305770: stur            d0, [x0, #7]
    // 0x1305774: ldur            d0, [fp, #-0x38]
    // 0x1305778: StoreField: r0->field_f = d0
    //     0x1305778: stur            d0, [x0, #0xf]
    // 0x130577c: b               #0x13057a4
    // 0x1305780: LoadField: d0 = r3->field_7
    //     0x1305780: ldur            d0, [x3, #7]
    // 0x1305784: stur            d0, [fp, #-0x40]
    // 0x1305788: LoadField: d1 = r3->field_f
    //     0x1305788: ldur            d1, [x3, #0xf]
    // 0x130578c: stur            d1, [fp, #-0x38]
    // 0x1305790: r0 = Alignment()
    //     0x1305790: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305794: ldur            d0, [fp, #-0x40]
    // 0x1305798: StoreField: r0->field_7 = d0
    //     0x1305798: stur            d0, [x0, #7]
    // 0x130579c: ldur            d0, [fp, #-0x38]
    // 0x13057a0: StoreField: r0->field_f = d0
    //     0x13057a0: stur            d0, [x0, #0xf]
    // 0x13057a4: mov             x1, x0
    // 0x13057a8: ldur            x0, [fp, #-0x10]
    // 0x13057ac: ldur            x2, [fp, #-0x18]
    // 0x13057b0: r0 = withinRect()
    //     0x13057b0: bl              #0x12f7c84  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0x13057b4: ldur            x1, [fp, #-0x10]
    // 0x13057b8: stur            x0, [fp, #-0x20]
    // 0x13057bc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x13057bc: ldur            w2, [x1, #0x17]
    // 0x13057c0: DecompressPointer r2
    //     0x13057c0: add             x2, x2, HEAP, lsl #32
    // 0x13057c4: r3 = LoadClassIdInstr(r2)
    //     0x13057c4: ldur            x3, [x2, #-1]
    //     0x13057c8: ubfx            x3, x3, #0xc, #0x14
    // 0x13057cc: sub             x16, x3, #0xb8e
    // 0x13057d0: cmp             x16, #1
    // 0x13057d4: b.hi            #0x13057e4
    // 0x13057d8: mov             x0, x1
    // 0x13057dc: mov             x1, x2
    // 0x13057e0: b               #0x13058dc
    // 0x13057e4: cmp             x3, #0xb8c
    // 0x13057e8: b.ne            #0x130586c
    // 0x13057ec: ldur            x3, [fp, #-8]
    // 0x13057f0: cmp             w3, NULL
    // 0x13057f4: b.eq            #0x1305974
    // 0x13057f8: LoadField: r4 = r3->field_7
    //     0x13057f8: ldur            x4, [x3, #7]
    // 0x13057fc: cmp             x4, #0
    // 0x1305800: b.gt            #0x1305834
    // 0x1305804: LoadField: d0 = r2->field_7
    //     0x1305804: ldur            d0, [x2, #7]
    // 0x1305808: LoadField: d1 = r2->field_f
    //     0x1305808: ldur            d1, [x2, #0xf]
    // 0x130580c: fsub            d2, d0, d1
    // 0x1305810: stur            d2, [fp, #-0x40]
    // 0x1305814: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x1305814: ldur            d0, [x2, #0x17]
    // 0x1305818: stur            d0, [fp, #-0x38]
    // 0x130581c: r0 = Alignment()
    //     0x130581c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305820: ldur            d0, [fp, #-0x40]
    // 0x1305824: StoreField: r0->field_7 = d0
    //     0x1305824: stur            d0, [x0, #7]
    // 0x1305828: ldur            d0, [fp, #-0x38]
    // 0x130582c: StoreField: r0->field_f = d0
    //     0x130582c: stur            d0, [x0, #0xf]
    // 0x1305830: b               #0x1305860
    // 0x1305834: LoadField: d0 = r2->field_7
    //     0x1305834: ldur            d0, [x2, #7]
    // 0x1305838: LoadField: d1 = r2->field_f
    //     0x1305838: ldur            d1, [x2, #0xf]
    // 0x130583c: fadd            d2, d0, d1
    // 0x1305840: stur            d2, [fp, #-0x40]
    // 0x1305844: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x1305844: ldur            d0, [x2, #0x17]
    // 0x1305848: stur            d0, [fp, #-0x38]
    // 0x130584c: r0 = Alignment()
    //     0x130584c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1305850: ldur            d0, [fp, #-0x40]
    // 0x1305854: StoreField: r0->field_7 = d0
    //     0x1305854: stur            d0, [x0, #7]
    // 0x1305858: ldur            d0, [fp, #-0x38]
    // 0x130585c: StoreField: r0->field_f = d0
    //     0x130585c: stur            d0, [x0, #0xf]
    // 0x1305860: mov             x1, x0
    // 0x1305864: ldur            x0, [fp, #-0x10]
    // 0x1305868: b               #0x13058dc
    // 0x130586c: ldur            x3, [fp, #-8]
    // 0x1305870: cmp             w3, NULL
    // 0x1305874: b.eq            #0x1305978
    // 0x1305878: LoadField: r0 = r3->field_7
    //     0x1305878: ldur            x0, [x3, #7]
    // 0x130587c: cmp             x0, #0
    // 0x1305880: b.gt            #0x13058b0
    // 0x1305884: LoadField: d0 = r2->field_7
    //     0x1305884: ldur            d0, [x2, #7]
    // 0x1305888: fneg            d1, d0
    // 0x130588c: stur            d1, [fp, #-0x40]
    // 0x1305890: LoadField: d0 = r2->field_f
    //     0x1305890: ldur            d0, [x2, #0xf]
    // 0x1305894: stur            d0, [fp, #-0x38]
    // 0x1305898: r0 = Alignment()
    //     0x1305898: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x130589c: ldur            d0, [fp, #-0x40]
    // 0x13058a0: StoreField: r0->field_7 = d0
    //     0x13058a0: stur            d0, [x0, #7]
    // 0x13058a4: ldur            d0, [fp, #-0x38]
    // 0x13058a8: StoreField: r0->field_f = d0
    //     0x13058a8: stur            d0, [x0, #0xf]
    // 0x13058ac: b               #0x13058d4
    // 0x13058b0: LoadField: d0 = r2->field_7
    //     0x13058b0: ldur            d0, [x2, #7]
    // 0x13058b4: stur            d0, [fp, #-0x40]
    // 0x13058b8: LoadField: d1 = r2->field_f
    //     0x13058b8: ldur            d1, [x2, #0xf]
    // 0x13058bc: stur            d1, [fp, #-0x38]
    // 0x13058c0: r0 = Alignment()
    //     0x13058c0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x13058c4: ldur            d0, [fp, #-0x40]
    // 0x13058c8: StoreField: r0->field_7 = d0
    //     0x13058c8: stur            d0, [x0, #7]
    // 0x13058cc: ldur            d0, [fp, #-0x38]
    // 0x13058d0: StoreField: r0->field_f = d0
    //     0x13058d0: stur            d0, [x0, #0xf]
    // 0x13058d4: mov             x1, x0
    // 0x13058d8: ldur            x0, [fp, #-0x10]
    // 0x13058dc: ldur            x2, [fp, #-0x18]
    // 0x13058e0: r0 = withinRect()
    //     0x13058e0: bl              #0x12f7c84  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0x13058e4: mov             x2, x0
    // 0x13058e8: ldur            x0, [fp, #-0x10]
    // 0x13058ec: stur            x2, [fp, #-0x28]
    // 0x13058f0: LoadField: r5 = r0->field_7
    //     0x13058f0: ldur            w5, [x0, #7]
    // 0x13058f4: DecompressPointer r5
    //     0x13058f4: add             x5, x5, HEAP, lsl #32
    // 0x13058f8: mov             x1, x0
    // 0x13058fc: stur            x5, [fp, #-8]
    // 0x1305900: r0 = _impliedStops()
    //     0x1305900: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x1305904: ldur            x1, [fp, #-0x10]
    // 0x1305908: ldur            x2, [fp, #-0x18]
    // 0x130590c: stur            x0, [fp, #-0x10]
    // 0x1305910: r0 = _resolveTransform()
    //     0x1305910: bl              #0x12f7c18  ; [package:flutter/src/painting/gradient.dart] Gradient::_resolveTransform
    // 0x1305914: stur            x0, [fp, #-0x18]
    // 0x1305918: r0 = Gradient()
    //     0x1305918: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x130591c: stur            x0, [fp, #-0x30]
    // 0x1305920: ldur            x16, [fp, #-0x10]
    // 0x1305924: r30 = Instance_TileMode
    //     0x1305924: add             lr, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x1305928: ldr             lr, [lr, #0x900]
    // 0x130592c: stp             lr, x16, [SP, #8]
    // 0x1305930: ldur            x16, [fp, #-0x18]
    // 0x1305934: str             x16, [SP]
    // 0x1305938: mov             x1, x0
    // 0x130593c: ldur            x2, [fp, #-0x20]
    // 0x1305940: ldur            x3, [fp, #-0x28]
    // 0x1305944: ldur            x5, [fp, #-8]
    // 0x1305948: r4 = const [0, 0x7, 0x3, 0x7, null]
    //     0x1305948: add             x4, PP, #0x28, lsl #12  ; [pp+0x28808] List(5) [0, 0x7, 0x3, 0x7, Null]
    //     0x130594c: ldr             x4, [x4, #0x808]
    // 0x1305950: r0 = Gradient.linear()
    //     0x1305950: bl              #0xbcb8a4  ; [dart:ui] Gradient::Gradient.linear
    // 0x1305954: ldur            x0, [fp, #-0x30]
    // 0x1305958: LeaveFrame
    //     0x1305958: mov             SP, fp
    //     0x130595c: ldp             fp, lr, [SP], #0x10
    // 0x1305960: ret
    //     0x1305960: ret             
    // 0x1305964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1305964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1305968: b               #0x1305694
    // 0x130596c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x130596c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1305970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1305970: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1305974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1305974: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1305978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1305978: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0x1305b80, size: 0x230
    // 0x1305b80: EnterFrame
    //     0x1305b80: stp             fp, lr, [SP, #-0x10]!
    //     0x1305b84: mov             fp, SP
    // 0x1305b88: AllocStack(0x48)
    //     0x1305b88: sub             SP, SP, #0x48
    // 0x1305b8c: SetupParameters(LinearGradient this /* r1 => r1, fp-0x10 */)
    //     0x1305b8c: stur            x1, [fp, #-0x10]
    // 0x1305b90: CheckStackOverflow
    //     0x1305b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1305b94: cmp             SP, x16
    //     0x1305b98: b.ls            #0x1305d90
    // 0x1305b9c: r0 = inline_Allocate_Double()
    //     0x1305b9c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1305ba0: add             x0, x0, #0x10
    //     0x1305ba4: cmp             x2, x0
    //     0x1305ba8: b.ls            #0x1305d98
    //     0x1305bac: str             x0, [THR, #0x60]  ; THR::top
    //     0x1305bb0: sub             x0, x0, #0xf
    //     0x1305bb4: mov             x2, #0xe19c
    //     0x1305bb8: movk            x2, #3, lsl #16
    //     0x1305bbc: stur            x2, [x0, #-1]
    // 0x1305bc0: dmb             ishst
    // 0x1305bc4: StoreField: r0->field_7 = d0
    //     0x1305bc4: stur            d0, [x0, #7]
    // 0x1305bc8: stur            x0, [fp, #-8]
    // 0x1305bcc: r1 = 1
    //     0x1305bcc: mov             x1, #1
    // 0x1305bd0: r0 = AllocateContext()
    //     0x1305bd0: bl              #0x13de838  ; AllocateContextStub
    // 0x1305bd4: mov             x1, x0
    // 0x1305bd8: ldur            x0, [fp, #-8]
    // 0x1305bdc: StoreField: r1->field_f = r0
    //     0x1305bdc: stur            w0, [x1, #0xf]
    // 0x1305be0: ldur            x0, [fp, #-0x10]
    // 0x1305be4: LoadField: r3 = r0->field_13
    //     0x1305be4: ldur            w3, [x0, #0x13]
    // 0x1305be8: DecompressPointer r3
    //     0x1305be8: add             x3, x3, HEAP, lsl #32
    // 0x1305bec: stur            x3, [fp, #-0x20]
    // 0x1305bf0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x1305bf0: ldur            w4, [x0, #0x17]
    // 0x1305bf4: DecompressPointer r4
    //     0x1305bf4: add             x4, x4, HEAP, lsl #32
    // 0x1305bf8: stur            x4, [fp, #-0x18]
    // 0x1305bfc: LoadField: r5 = r0->field_7
    //     0x1305bfc: ldur            w5, [x0, #7]
    // 0x1305c00: DecompressPointer r5
    //     0x1305c00: add             x5, x5, HEAP, lsl #32
    // 0x1305c04: mov             x2, x1
    // 0x1305c08: stur            x5, [fp, #-8]
    // 0x1305c0c: r1 = Function '<anonymous closure>':.
    //     0x1305c0c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3920] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1305c10: ldr             x1, [x1, #0x920]
    // 0x1305c14: r0 = AllocateClosure()
    //     0x1305c14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1305c18: r16 = <Color>
    //     0x1305c18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1305c1c: ldr             x16, [x16, #0xa90]
    // 0x1305c20: ldur            lr, [fp, #-8]
    // 0x1305c24: stp             lr, x16, [SP, #8]
    // 0x1305c28: str             x0, [SP]
    // 0x1305c2c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1305c2c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1305c30: r0 = map()
    //     0x1305c30: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1305c34: mov             x3, x0
    // 0x1305c38: stur            x3, [fp, #-0x28]
    // 0x1305c3c: LoadField: r4 = r3->field_7
    //     0x1305c3c: ldur            w4, [x3, #7]
    // 0x1305c40: DecompressPointer r4
    //     0x1305c40: add             x4, x4, HEAP, lsl #32
    // 0x1305c44: mov             x0, x3
    // 0x1305c48: stur            x4, [fp, #-8]
    // 0x1305c4c: r2 = Null
    //     0x1305c4c: mov             x2, NULL
    // 0x1305c50: r1 = Null
    //     0x1305c50: mov             x1, NULL
    // 0x1305c54: cmp             w0, NULL
    // 0x1305c58: b.eq            #0x1305cf0
    // 0x1305c5c: branchIfSmi(r0, 0x1305cf0)
    //     0x1305c5c: tbz             w0, #0, #0x1305cf0
    // 0x1305c60: r3 = LoadClassIdInstr(r0)
    //     0x1305c60: ldur            x3, [x0, #-1]
    //     0x1305c64: ubfx            x3, x3, #0xc, #0x14
    // 0x1305c68: r17 = 7724
    //     0x1305c68: mov             x17, #0x1e2c
    // 0x1305c6c: cmp             x3, x17
    // 0x1305c70: b.eq            #0x1305cf8
    // 0x1305c74: r4 = LoadClassIdInstr(r0)
    //     0x1305c74: ldur            x4, [x0, #-1]
    //     0x1305c78: ubfx            x4, x4, #0xc, #0x14
    // 0x1305c7c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1305c80: ldr             x3, [x3, #0x18]
    // 0x1305c84: ldr             x3, [x3, x4, lsl #3]
    // 0x1305c88: LoadField: r3 = r3->field_2b
    //     0x1305c88: ldur            w3, [x3, #0x2b]
    // 0x1305c8c: DecompressPointer r3
    //     0x1305c8c: add             x3, x3, HEAP, lsl #32
    // 0x1305c90: cmp             w3, NULL
    // 0x1305c94: b.eq            #0x1305cf0
    // 0x1305c98: LoadField: r3 = r3->field_f
    //     0x1305c98: ldur            w3, [x3, #0xf]
    // 0x1305c9c: lsr             x3, x3, #3
    // 0x1305ca0: r17 = 7724
    //     0x1305ca0: mov             x17, #0x1e2c
    // 0x1305ca4: cmp             x3, x17
    // 0x1305ca8: b.eq            #0x1305cf8
    // 0x1305cac: r3 = SubtypeTestCache
    //     0x1305cac: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39a0] SubtypeTestCache
    //     0x1305cb0: ldr             x3, [x3, #0x9a0]
    // 0x1305cb4: r30 = Subtype1TestCacheStub
    //     0x1305cb4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1305cb8: LoadField: r30 = r30->field_7
    //     0x1305cb8: ldur            lr, [lr, #7]
    // 0x1305cbc: blr             lr
    // 0x1305cc0: cmp             w7, NULL
    // 0x1305cc4: b.eq            #0x1305cd0
    // 0x1305cc8: tbnz            w7, #4, #0x1305cf0
    // 0x1305ccc: b               #0x1305cf8
    // 0x1305cd0: r8 = EfficientLengthIterable
    //     0x1305cd0: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa39a8] Type: EfficientLengthIterable
    //     0x1305cd4: ldr             x8, [x8, #0x9a8]
    // 0x1305cd8: r3 = SubtypeTestCache
    //     0x1305cd8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39b0] SubtypeTestCache
    //     0x1305cdc: ldr             x3, [x3, #0x9b0]
    // 0x1305ce0: r30 = InstanceOfStub
    //     0x1305ce0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1305ce4: LoadField: r30 = r30->field_7
    //     0x1305ce4: ldur            lr, [lr, #7]
    // 0x1305ce8: blr             lr
    // 0x1305cec: b               #0x1305cfc
    // 0x1305cf0: r0 = false
    //     0x1305cf0: add             x0, NULL, #0x30  ; false
    // 0x1305cf4: b               #0x1305cfc
    // 0x1305cf8: r0 = true
    //     0x1305cf8: add             x0, NULL, #0x20  ; true
    // 0x1305cfc: tbnz            w0, #4, #0x1305d14
    // 0x1305d00: ldur            x1, [fp, #-8]
    // 0x1305d04: ldur            x2, [fp, #-0x28]
    // 0x1305d08: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1305d08: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1305d0c: mov             x3, x0
    // 0x1305d10: b               #0x1305d24
    // 0x1305d14: ldur            x1, [fp, #-8]
    // 0x1305d18: ldur            x2, [fp, #-0x28]
    // 0x1305d1c: r0 = _GrowableList._ofOther()
    //     0x1305d1c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x1305d20: mov             x3, x0
    // 0x1305d24: ldur            x0, [fp, #-0x10]
    // 0x1305d28: ldur            x1, [fp, #-0x20]
    // 0x1305d2c: ldur            x2, [fp, #-0x18]
    // 0x1305d30: stur            x3, [fp, #-0x30]
    // 0x1305d34: LoadField: r4 = r0->field_b
    //     0x1305d34: ldur            w4, [x0, #0xb]
    // 0x1305d38: DecompressPointer r4
    //     0x1305d38: add             x4, x4, HEAP, lsl #32
    // 0x1305d3c: stur            x4, [fp, #-0x28]
    // 0x1305d40: LoadField: r5 = r0->field_f
    //     0x1305d40: ldur            w5, [x0, #0xf]
    // 0x1305d44: DecompressPointer r5
    //     0x1305d44: add             x5, x5, HEAP, lsl #32
    // 0x1305d48: stur            x5, [fp, #-8]
    // 0x1305d4c: r0 = LinearGradient()
    //     0x1305d4c: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x1305d50: ldur            x1, [fp, #-0x20]
    // 0x1305d54: StoreField: r0->field_13 = r1
    //     0x1305d54: stur            w1, [x0, #0x13]
    // 0x1305d58: ldur            x1, [fp, #-0x18]
    // 0x1305d5c: ArrayStore: r0[0] = r1  ; List_4
    //     0x1305d5c: stur            w1, [x0, #0x17]
    // 0x1305d60: r1 = Instance_TileMode
    //     0x1305d60: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x1305d64: ldr             x1, [x1, #0x900]
    // 0x1305d68: StoreField: r0->field_1b = r1
    //     0x1305d68: stur            w1, [x0, #0x1b]
    // 0x1305d6c: ldur            x1, [fp, #-0x30]
    // 0x1305d70: StoreField: r0->field_7 = r1
    //     0x1305d70: stur            w1, [x0, #7]
    // 0x1305d74: ldur            x1, [fp, #-0x28]
    // 0x1305d78: StoreField: r0->field_b = r1
    //     0x1305d78: stur            w1, [x0, #0xb]
    // 0x1305d7c: ldur            x1, [fp, #-8]
    // 0x1305d80: StoreField: r0->field_f = r1
    //     0x1305d80: stur            w1, [x0, #0xf]
    // 0x1305d84: LeaveFrame
    //     0x1305d84: mov             SP, fp
    //     0x1305d88: ldp             fp, lr, [SP], #0x10
    // 0x1305d8c: ret
    //     0x1305d8c: ret             
    // 0x1305d90: r0 = StackOverflowSharedWithFPURegs()
    //     0x1305d90: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1305d94: b               #0x1305b9c
    // 0x1305d98: SaveReg d0
    //     0x1305d98: str             q0, [SP, #-0x10]!
    // 0x1305d9c: SaveReg r1
    //     0x1305d9c: str             x1, [SP, #-8]!
    // 0x1305da0: r0 = AllocateDouble()
    //     0x1305da0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1305da4: RestoreReg r1
    //     0x1305da4: ldr             x1, [SP], #8
    // 0x1305da8: RestoreReg d0
    //     0x1305da8: ldr             q0, [SP], #0x10
    // 0x1305dac: b               #0x1305bc4
  }
}

// class id: 2933, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class GradientTransform extends Object {
}

// class id: 2936, size: 0x10, field offset: 0x8
class _ColorsAndStops extends Object {
}
