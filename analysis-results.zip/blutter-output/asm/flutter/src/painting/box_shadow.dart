// lib: , url: package:flutter/src/painting/box_shadow.dart

// class id: 1048986, size: 0x8
class :: {
}

// class id: 3761, size: 0x24, field offset: 0x18
//   const constructor, 
class BoxShadow extends Shadow {

  Color field_8;
  Offset field_c;
  _Double field_10;
  _Mint field_18;
  BlurStyle field_20;

  _ toPaint(/* No info */) {
    // ** addr: 0xb6da24, size: 0xa0
    // 0xb6da24: EnterFrame
    //     0xb6da24: stp             fp, lr, [SP, #-0x10]!
    //     0xb6da28: mov             fp, SP
    // 0xb6da2c: AllocStack(0x28)
    //     0xb6da2c: sub             SP, SP, #0x28
    // 0xb6da30: SetupParameters(BoxShadow this /* r1 => r1, fp-0x8 */)
    //     0xb6da30: stur            x1, [fp, #-8]
    // 0xb6da34: CheckStackOverflow
    //     0xb6da34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6da38: cmp             SP, x16
    //     0xb6da3c: b.ls            #0xb6dabc
    // 0xb6da40: r16 = 136
    //     0xb6da40: mov             x16, #0x88
    // 0xb6da44: stp             x16, NULL, [SP]
    // 0xb6da48: r0 = ByteData()
    //     0xb6da48: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6da4c: stur            x0, [fp, #-0x10]
    // 0xb6da50: r0 = Paint()
    //     0xb6da50: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6da54: mov             x3, x0
    // 0xb6da58: ldur            x0, [fp, #-0x10]
    // 0xb6da5c: stur            x3, [fp, #-0x18]
    // 0xb6da60: StoreField: r3->field_7 = r0
    //     0xb6da60: stur            w0, [x3, #7]
    // 0xb6da64: ldur            x4, [fp, #-8]
    // 0xb6da68: LoadField: r2 = r4->field_7
    //     0xb6da68: ldur            w2, [x4, #7]
    // 0xb6da6c: DecompressPointer r2
    //     0xb6da6c: add             x2, x2, HEAP, lsl #32
    // 0xb6da70: mov             x1, x3
    // 0xb6da74: r0 = color=()
    //     0xb6da74: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6da78: ldur            x1, [fp, #-8]
    // 0xb6da7c: r0 = blurSigma()
    //     0xb6da7c: bl              #0xb6dac4  ; [dart:ui] Shadow::blurSigma
    // 0xb6da80: ldur            x1, [fp, #-0x10]
    // 0xb6da84: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb6da84: ldur            w2, [x1, #0x17]
    // 0xb6da88: DecompressPointer r2
    //     0xb6da88: add             x2, x2, HEAP, lsl #32
    // 0xb6da8c: LoadField: r1 = r2->field_7
    //     0xb6da8c: ldur            x1, [x2, #7]
    // 0xb6da90: r3 = 1
    //     0xb6da90: mov             x3, #1
    // 0xb6da94: str             w3, [x1, #0x34]
    // 0xb6da98: LoadField: r1 = r2->field_7
    //     0xb6da98: ldur            x1, [x2, #7]
    // 0xb6da9c: str             wzr, [x1, #0x38]
    // 0xb6daa0: fcvt            s1, d0
    // 0xb6daa4: LoadField: r1 = r2->field_7
    //     0xb6daa4: ldur            x1, [x2, #7]
    // 0xb6daa8: str             s1, [x1, #0x3c]
    // 0xb6daac: ldur            x0, [fp, #-0x18]
    // 0xb6dab0: LeaveFrame
    //     0xb6dab0: mov             SP, fp
    //     0xb6dab4: ldp             fp, lr, [SP], #0x10
    // 0xb6dab8: ret
    //     0xb6dab8: ret             
    // 0xb6dabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6dabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6dac0: b               #0xb6da40
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114812c, size: 0x110
    // 0x114812c: EnterFrame
    //     0x114812c: stp             fp, lr, [SP, #-0x10]!
    //     0x1148130: mov             fp, SP
    // 0x1148134: AllocStack(0x18)
    //     0x1148134: sub             SP, SP, #0x18
    // 0x1148138: CheckStackOverflow
    //     0x1148138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114813c: cmp             SP, x16
    //     0x1148140: b.ls            #0x11481f8
    // 0x1148144: ldr             x0, [fp, #0x10]
    // 0x1148148: LoadField: r1 = r0->field_7
    //     0x1148148: ldur            w1, [x0, #7]
    // 0x114814c: DecompressPointer r1
    //     0x114814c: add             x1, x1, HEAP, lsl #32
    // 0x1148150: LoadField: r2 = r0->field_b
    //     0x1148150: ldur            w2, [x0, #0xb]
    // 0x1148154: DecompressPointer r2
    //     0x1148154: add             x2, x2, HEAP, lsl #32
    // 0x1148158: LoadField: d0 = r0->field_f
    //     0x1148158: ldur            d0, [x0, #0xf]
    // 0x114815c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x114815c: ldur            d1, [x0, #0x17]
    // 0x1148160: r0 = inline_Allocate_Double()
    //     0x1148160: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x1148164: add             x0, x0, #0x10
    //     0x1148168: cmp             x3, x0
    //     0x114816c: b.ls            #0x1148200
    //     0x1148170: str             x0, [THR, #0x60]  ; THR::top
    //     0x1148174: sub             x0, x0, #0xf
    //     0x1148178: mov             x3, #0xe19c
    //     0x114817c: movk            x3, #3, lsl #16
    //     0x1148180: stur            x3, [x0, #-1]
    // 0x1148184: dmb             ishst
    // 0x1148188: StoreField: r0->field_7 = d0
    //     0x1148188: stur            d0, [x0, #7]
    // 0x114818c: r3 = inline_Allocate_Double()
    //     0x114818c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x1148190: add             x3, x3, #0x10
    //     0x1148194: cmp             x4, x3
    //     0x1148198: b.ls            #0x1148218
    //     0x114819c: str             x3, [THR, #0x60]  ; THR::top
    //     0x11481a0: sub             x3, x3, #0xf
    //     0x11481a4: mov             x4, #0xe19c
    //     0x11481a8: movk            x4, #3, lsl #16
    //     0x11481ac: stur            x4, [x3, #-1]
    // 0x11481b0: dmb             ishst
    // 0x11481b4: StoreField: r3->field_7 = d1
    //     0x11481b4: stur            d1, [x3, #7]
    // 0x11481b8: stp             x3, x0, [SP, #8]
    // 0x11481bc: r16 = Instance_BlurStyle
    //     0x11481bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0x11481c0: ldr             x16, [x16, #0xce0]
    // 0x11481c4: str             x16, [SP]
    // 0x11481c8: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x11481c8: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x11481cc: ldr             x4, [x4, #0xc80]
    // 0x11481d0: r0 = hash()
    //     0x11481d0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11481d4: mov             x2, x0
    // 0x11481d8: r0 = BoxInt64Instr(r2)
    //     0x11481d8: sbfiz           x0, x2, #1, #0x1f
    //     0x11481dc: cmp             x2, x0, asr #1
    //     0x11481e0: b.eq            #0x11481ec
    //     0x11481e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11481e8: stur            x2, [x0, #7]
    // 0x11481ec: LeaveFrame
    //     0x11481ec: mov             SP, fp
    //     0x11481f0: ldp             fp, lr, [SP], #0x10
    // 0x11481f4: ret
    //     0x11481f4: ret             
    // 0x11481f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11481f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11481fc: b               #0x1148144
    // 0x1148200: stp             q0, q1, [SP, #-0x20]!
    // 0x1148204: stp             x1, x2, [SP, #-0x10]!
    // 0x1148208: r0 = AllocateDouble()
    //     0x1148208: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114820c: ldp             x1, x2, [SP], #0x10
    // 0x1148210: ldp             q0, q1, [SP], #0x20
    // 0x1148214: b               #0x1148188
    // 0x1148218: SaveReg d1
    //     0x1148218: str             q1, [SP, #-0x10]!
    // 0x114821c: stp             x1, x2, [SP, #-0x10]!
    // 0x1148220: SaveReg r0
    //     0x1148220: str             x0, [SP, #-8]!
    // 0x1148224: r0 = AllocateDouble()
    //     0x1148224: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1148228: mov             x3, x0
    // 0x114822c: RestoreReg r0
    //     0x114822c: ldr             x0, [SP], #8
    // 0x1148230: ldp             x1, x2, [SP], #0x10
    // 0x1148234: RestoreReg d1
    //     0x1148234: ldr             q1, [SP], #0x10
    // 0x1148238: b               #0x11481b4
  }
  static _ lerpList(/* No info */) {
    // ** addr: 0x116277c, size: 0x5a0
    // 0x116277c: EnterFrame
    //     0x116277c: stp             fp, lr, [SP, #-0x10]!
    //     0x1162780: mov             fp, SP
    // 0x1162784: AllocStack(0x78)
    //     0x1162784: sub             SP, SP, #0x78
    // 0x1162788: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x50 */)
    //     0x1162788: mov             x0, x2
    //     0x116278c: stur            x2, [fp, #-8]
    //     0x1162790: stur            d0, [fp, #-0x50]
    // 0x1162794: CheckStackOverflow
    //     0x1162794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1162798: cmp             SP, x16
    //     0x116279c: b.ls            #0x1162cfc
    // 0x11627a0: cmp             w1, w0
    // 0x11627a4: b.ne            #0x11627b8
    // 0x11627a8: mov             x0, x1
    // 0x11627ac: LeaveFrame
    //     0x11627ac: mov             SP, fp
    //     0x11627b0: ldp             fp, lr, [SP], #0x10
    // 0x11627b4: ret
    //     0x11627b4: ret             
    // 0x11627b8: cmp             w1, NULL
    // 0x11627bc: b.ne            #0x11627d8
    // 0x11627c0: r1 = <BoxShadow>
    //     0x11627c0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16cf0] TypeArguments: <BoxShadow>
    //     0x11627c4: ldr             x1, [x1, #0xcf0]
    // 0x11627c8: r2 = 0
    //     0x11627c8: mov             x2, #0
    // 0x11627cc: r0 = _GrowableList()
    //     0x11627cc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x11627d0: mov             x3, x0
    // 0x11627d4: b               #0x11627dc
    // 0x11627d8: mov             x3, x1
    // 0x11627dc: ldur            x0, [fp, #-8]
    // 0x11627e0: stur            x3, [fp, #-0x10]
    // 0x11627e4: cmp             w0, NULL
    // 0x11627e8: b.ne            #0x1162804
    // 0x11627ec: r1 = <BoxShadow>
    //     0x11627ec: add             x1, PP, #0x16, lsl #12  ; [pp+0x16cf0] TypeArguments: <BoxShadow>
    //     0x11627f0: ldr             x1, [x1, #0xcf0]
    // 0x11627f4: r2 = 0
    //     0x11627f4: mov             x2, #0
    // 0x11627f8: r0 = _GrowableList()
    //     0x11627f8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x11627fc: mov             x2, x0
    // 0x1162800: b               #0x1162808
    // 0x1162804: mov             x2, x0
    // 0x1162808: ldur            x1, [fp, #-0x10]
    // 0x116280c: stur            x2, [fp, #-8]
    // 0x1162810: r0 = LoadClassIdInstr(r1)
    //     0x1162810: ldur            x0, [x1, #-1]
    //     0x1162814: ubfx            x0, x0, #0xc, #0x14
    // 0x1162818: str             x1, [SP]
    // 0x116281c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x116281c: mov             x17, #0xf078
    //     0x1162820: add             lr, x0, x17
    //     0x1162824: ldr             lr, [x21, lr, lsl #3]
    //     0x1162828: blr             lr
    // 0x116282c: mov             x2, x0
    // 0x1162830: ldur            x1, [fp, #-8]
    // 0x1162834: stur            x2, [fp, #-0x18]
    // 0x1162838: r0 = LoadClassIdInstr(r1)
    //     0x1162838: ldur            x0, [x1, #-1]
    //     0x116283c: ubfx            x0, x0, #0xc, #0x14
    // 0x1162840: str             x1, [SP]
    // 0x1162844: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1162844: mov             x17, #0xf078
    //     0x1162848: add             lr, x0, x17
    //     0x116284c: ldr             lr, [x21, lr, lsl #3]
    //     0x1162850: blr             lr
    // 0x1162854: mov             x1, x0
    // 0x1162858: ldur            x0, [fp, #-0x18]
    // 0x116285c: r2 = LoadInt32Instr(r0)
    //     0x116285c: sbfx            x2, x0, #1, #0x1f
    //     0x1162860: tbz             w0, #0, #0x1162868
    //     0x1162864: ldur            x2, [x0, #7]
    // 0x1162868: r0 = LoadInt32Instr(r1)
    //     0x1162868: sbfx            x0, x1, #1, #0x1f
    //     0x116286c: tbz             w1, #0, #0x1162874
    //     0x1162870: ldur            x0, [x1, #7]
    // 0x1162874: cmp             x2, x0
    // 0x1162878: csel            x3, x0, x2, gt
    // 0x116287c: stur            x3, [fp, #-0x20]
    // 0x1162880: r1 = <BoxShadow>
    //     0x1162880: add             x1, PP, #0x16, lsl #12  ; [pp+0x16cf0] TypeArguments: <BoxShadow>
    //     0x1162884: ldr             x1, [x1, #0xcf0]
    // 0x1162888: r2 = 0
    //     0x1162888: mov             x2, #0
    // 0x116288c: r0 = _GrowableList()
    //     0x116288c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x1162890: mov             x2, x0
    // 0x1162894: stur            x2, [fp, #-0x30]
    // 0x1162898: r6 = 0
    //     0x1162898: mov             x6, #0
    // 0x116289c: ldur            x5, [fp, #-0x10]
    // 0x11628a0: ldur            x4, [fp, #-8]
    // 0x11628a4: ldur            x3, [fp, #-0x20]
    // 0x11628a8: stur            x6, [fp, #-0x28]
    // 0x11628ac: CheckStackOverflow
    //     0x11628ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11628b0: cmp             SP, x16
    //     0x11628b4: b.ls            #0x1162d04
    // 0x11628b8: cmp             x6, x3
    // 0x11628bc: b.ge            #0x11629b8
    // 0x11628c0: r0 = BoxInt64Instr(r6)
    //     0x11628c0: sbfiz           x0, x6, #1, #0x1f
    //     0x11628c4: cmp             x6, x0, asr #1
    //     0x11628c8: b.eq            #0x11628d4
    //     0x11628cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11628d0: stur            x6, [x0, #7]
    // 0x11628d4: mov             x1, x0
    // 0x11628d8: stur            x1, [fp, #-0x18]
    // 0x11628dc: r0 = LoadClassIdInstr(r5)
    //     0x11628dc: ldur            x0, [x5, #-1]
    //     0x11628e0: ubfx            x0, x0, #0xc, #0x14
    // 0x11628e4: stp             x1, x5, [SP]
    // 0x11628e8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x11628e8: sub             lr, x0, #0xdfd
    //     0x11628ec: ldr             lr, [x21, lr, lsl #3]
    //     0x11628f0: blr             lr
    // 0x11628f4: mov             x2, x0
    // 0x11628f8: ldur            x1, [fp, #-8]
    // 0x11628fc: stur            x2, [fp, #-0x38]
    // 0x1162900: r0 = LoadClassIdInstr(r1)
    //     0x1162900: ldur            x0, [x1, #-1]
    //     0x1162904: ubfx            x0, x0, #0xc, #0x14
    // 0x1162908: ldur            x16, [fp, #-0x18]
    // 0x116290c: stp             x16, x1, [SP]
    // 0x1162910: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1162910: sub             lr, x0, #0xdfd
    //     0x1162914: ldr             lr, [x21, lr, lsl #3]
    //     0x1162918: blr             lr
    // 0x116291c: ldur            x1, [fp, #-0x38]
    // 0x1162920: mov             x2, x0
    // 0x1162924: ldur            d0, [fp, #-0x50]
    // 0x1162928: r0 = lerp()
    //     0x1162928: bl              #0x1162d1c  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerp
    // 0x116292c: mov             x2, x0
    // 0x1162930: ldur            x0, [fp, #-0x30]
    // 0x1162934: stur            x2, [fp, #-0x18]
    // 0x1162938: LoadField: r1 = r0->field_b
    //     0x1162938: ldur            w1, [x0, #0xb]
    // 0x116293c: LoadField: r3 = r0->field_f
    //     0x116293c: ldur            w3, [x0, #0xf]
    // 0x1162940: DecompressPointer r3
    //     0x1162940: add             x3, x3, HEAP, lsl #32
    // 0x1162944: LoadField: r4 = r3->field_b
    //     0x1162944: ldur            w4, [x3, #0xb]
    // 0x1162948: r3 = LoadInt32Instr(r1)
    //     0x1162948: sbfx            x3, x1, #1, #0x1f
    // 0x116294c: stur            x3, [fp, #-0x40]
    // 0x1162950: r1 = LoadInt32Instr(r4)
    //     0x1162950: sbfx            x1, x4, #1, #0x1f
    // 0x1162954: cmp             x3, x1
    // 0x1162958: b.ne            #0x1162964
    // 0x116295c: mov             x1, x0
    // 0x1162960: r0 = _growToNextCapacity()
    //     0x1162960: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1162964: ldur            x2, [fp, #-0x30]
    // 0x1162968: ldur            x4, [fp, #-0x28]
    // 0x116296c: ldur            x3, [fp, #-0x40]
    // 0x1162970: add             x0, x3, #1
    // 0x1162974: lsl             x1, x0, #1
    // 0x1162978: StoreField: r2->field_b = r1
    //     0x1162978: stur            w1, [x2, #0xb]
    // 0x116297c: LoadField: r1 = r2->field_f
    //     0x116297c: ldur            w1, [x2, #0xf]
    // 0x1162980: DecompressPointer r1
    //     0x1162980: add             x1, x1, HEAP, lsl #32
    // 0x1162984: ldur            x0, [fp, #-0x18]
    // 0x1162988: ArrayStore: r1[r3] = r0  ; List_4
    //     0x1162988: add             x25, x1, x3, lsl #2
    //     0x116298c: add             x25, x25, #0xf
    //     0x1162990: str             w0, [x25]
    //     0x1162994: tbz             w0, #0, #0x11629b0
    //     0x1162998: ldurb           w16, [x1, #-1]
    //     0x116299c: ldurb           w17, [x0, #-1]
    //     0x11629a0: and             x16, x17, x16, lsr #2
    //     0x11629a4: tst             x16, HEAP, lsr #32
    //     0x11629a8: b.eq            #0x11629b0
    //     0x11629ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11629b0: add             x6, x4, #1
    // 0x11629b4: b               #0x116289c
    // 0x11629b8: ldur            d0, [fp, #-0x50]
    // 0x11629bc: d1 = 1.000000
    //     0x11629bc: fmov            d1, #1.00000000
    // 0x11629c0: fsub            d2, d1, d0
    // 0x11629c4: stur            d2, [fp, #-0x58]
    // 0x11629c8: ldur            x3, [fp, #-0x20]
    // 0x11629cc: ldur            x1, [fp, #-0x10]
    // 0x11629d0: stur            x3, [fp, #-0x28]
    // 0x11629d4: CheckStackOverflow
    //     0x11629d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11629d8: cmp             SP, x16
    //     0x11629dc: b.ls            #0x1162d0c
    // 0x11629e0: r0 = LoadClassIdInstr(r1)
    //     0x11629e0: ldur            x0, [x1, #-1]
    //     0x11629e4: ubfx            x0, x0, #0xc, #0x14
    // 0x11629e8: str             x1, [SP]
    // 0x11629ec: r0 = GDT[cid_x0 + 0xf078]()
    //     0x11629ec: mov             x17, #0xf078
    //     0x11629f0: add             lr, x0, x17
    //     0x11629f4: ldr             lr, [x21, lr, lsl #3]
    //     0x11629f8: blr             lr
    // 0x11629fc: r1 = LoadInt32Instr(r0)
    //     0x11629fc: sbfx            x1, x0, #1, #0x1f
    //     0x1162a00: tbz             w0, #0, #0x1162a08
    //     0x1162a04: ldur            x1, [x0, #7]
    // 0x1162a08: ldur            x2, [fp, #-0x28]
    // 0x1162a0c: cmp             x2, x1
    // 0x1162a10: b.ge            #0x1162b58
    // 0x1162a14: ldur            x4, [fp, #-0x10]
    // 0x1162a18: ldur            x3, [fp, #-0x30]
    // 0x1162a1c: ldur            d0, [fp, #-0x58]
    // 0x1162a20: r0 = BoxInt64Instr(r2)
    //     0x1162a20: sbfiz           x0, x2, #1, #0x1f
    //     0x1162a24: cmp             x2, x0, asr #1
    //     0x1162a28: b.eq            #0x1162a34
    //     0x1162a2c: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x1162a30: stur            x2, [x0, #7]
    // 0x1162a34: r1 = LoadClassIdInstr(r4)
    //     0x1162a34: ldur            x1, [x4, #-1]
    //     0x1162a38: ubfx            x1, x1, #0xc, #0x14
    // 0x1162a3c: stp             x0, x4, [SP]
    // 0x1162a40: mov             x0, x1
    // 0x1162a44: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1162a44: sub             lr, x0, #0xdfd
    //     0x1162a48: ldr             lr, [x21, lr, lsl #3]
    //     0x1162a4c: blr             lr
    // 0x1162a50: stur            x0, [fp, #-0x38]
    // 0x1162a54: LoadField: r2 = r0->field_7
    //     0x1162a54: ldur            w2, [x0, #7]
    // 0x1162a58: DecompressPointer r2
    //     0x1162a58: add             x2, x2, HEAP, lsl #32
    // 0x1162a5c: stur            x2, [fp, #-0x18]
    // 0x1162a60: LoadField: r1 = r0->field_b
    //     0x1162a60: ldur            w1, [x0, #0xb]
    // 0x1162a64: DecompressPointer r1
    //     0x1162a64: add             x1, x1, HEAP, lsl #32
    // 0x1162a68: ldur            d0, [fp, #-0x58]
    // 0x1162a6c: r0 = *()
    //     0x1162a6c: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0x1162a70: mov             x1, x0
    // 0x1162a74: ldur            x0, [fp, #-0x38]
    // 0x1162a78: stur            x1, [fp, #-0x48]
    // 0x1162a7c: LoadField: d0 = r0->field_f
    //     0x1162a7c: ldur            d0, [x0, #0xf]
    // 0x1162a80: ldur            d1, [fp, #-0x58]
    // 0x1162a84: fmul            d2, d0, d1
    // 0x1162a88: stur            d2, [fp, #-0x68]
    // 0x1162a8c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1162a8c: ldur            d0, [x0, #0x17]
    // 0x1162a90: fmul            d3, d0, d1
    // 0x1162a94: stur            d3, [fp, #-0x60]
    // 0x1162a98: r0 = BoxShadow()
    //     0x1162a98: bl              #0x919648  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x1162a9c: ldur            d0, [fp, #-0x60]
    // 0x1162aa0: stur            x0, [fp, #-0x38]
    // 0x1162aa4: ArrayStore: r0[0] = d0  ; List_8
    //     0x1162aa4: stur            d0, [x0, #0x17]
    // 0x1162aa8: r2 = Instance_BlurStyle
    //     0x1162aa8: add             x2, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0x1162aac: ldr             x2, [x2, #0xce0]
    // 0x1162ab0: StoreField: r0->field_1f = r2
    //     0x1162ab0: stur            w2, [x0, #0x1f]
    // 0x1162ab4: ldur            x1, [fp, #-0x18]
    // 0x1162ab8: StoreField: r0->field_7 = r1
    //     0x1162ab8: stur            w1, [x0, #7]
    // 0x1162abc: ldur            x1, [fp, #-0x48]
    // 0x1162ac0: StoreField: r0->field_b = r1
    //     0x1162ac0: stur            w1, [x0, #0xb]
    // 0x1162ac4: ldur            d0, [fp, #-0x68]
    // 0x1162ac8: StoreField: r0->field_f = d0
    //     0x1162ac8: stur            d0, [x0, #0xf]
    // 0x1162acc: ldur            x3, [fp, #-0x30]
    // 0x1162ad0: LoadField: r1 = r3->field_b
    //     0x1162ad0: ldur            w1, [x3, #0xb]
    // 0x1162ad4: LoadField: r4 = r3->field_f
    //     0x1162ad4: ldur            w4, [x3, #0xf]
    // 0x1162ad8: DecompressPointer r4
    //     0x1162ad8: add             x4, x4, HEAP, lsl #32
    // 0x1162adc: LoadField: r5 = r4->field_b
    //     0x1162adc: ldur            w5, [x4, #0xb]
    // 0x1162ae0: r4 = LoadInt32Instr(r1)
    //     0x1162ae0: sbfx            x4, x1, #1, #0x1f
    // 0x1162ae4: stur            x4, [fp, #-0x40]
    // 0x1162ae8: r1 = LoadInt32Instr(r5)
    //     0x1162ae8: sbfx            x1, x5, #1, #0x1f
    // 0x1162aec: cmp             x4, x1
    // 0x1162af0: b.ne            #0x1162afc
    // 0x1162af4: mov             x1, x3
    // 0x1162af8: r0 = _growToNextCapacity()
    //     0x1162af8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1162afc: ldur            x2, [fp, #-0x30]
    // 0x1162b00: ldur            x4, [fp, #-0x28]
    // 0x1162b04: ldur            x3, [fp, #-0x40]
    // 0x1162b08: add             x0, x3, #1
    // 0x1162b0c: lsl             x1, x0, #1
    // 0x1162b10: StoreField: r2->field_b = r1
    //     0x1162b10: stur            w1, [x2, #0xb]
    // 0x1162b14: LoadField: r1 = r2->field_f
    //     0x1162b14: ldur            w1, [x2, #0xf]
    // 0x1162b18: DecompressPointer r1
    //     0x1162b18: add             x1, x1, HEAP, lsl #32
    // 0x1162b1c: ldur            x0, [fp, #-0x38]
    // 0x1162b20: ArrayStore: r1[r3] = r0  ; List_4
    //     0x1162b20: add             x25, x1, x3, lsl #2
    //     0x1162b24: add             x25, x25, #0xf
    //     0x1162b28: str             w0, [x25]
    //     0x1162b2c: tbz             w0, #0, #0x1162b48
    //     0x1162b30: ldurb           w16, [x1, #-1]
    //     0x1162b34: ldurb           w17, [x0, #-1]
    //     0x1162b38: and             x16, x17, x16, lsr #2
    //     0x1162b3c: tst             x16, HEAP, lsr #32
    //     0x1162b40: b.eq            #0x1162b48
    //     0x1162b44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1162b48: add             x3, x4, #1
    // 0x1162b4c: ldur            d0, [fp, #-0x50]
    // 0x1162b50: ldur            d2, [fp, #-0x58]
    // 0x1162b54: b               #0x11629cc
    // 0x1162b58: ldur            x2, [fp, #-0x30]
    // 0x1162b5c: ldur            x3, [fp, #-0x20]
    // 0x1162b60: ldur            d0, [fp, #-0x50]
    // 0x1162b64: ldur            x1, [fp, #-8]
    // 0x1162b68: stur            x3, [fp, #-0x20]
    // 0x1162b6c: CheckStackOverflow
    //     0x1162b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1162b70: cmp             SP, x16
    //     0x1162b74: b.ls            #0x1162d14
    // 0x1162b78: r0 = LoadClassIdInstr(r1)
    //     0x1162b78: ldur            x0, [x1, #-1]
    //     0x1162b7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1162b80: str             x1, [SP]
    // 0x1162b84: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1162b84: mov             x17, #0xf078
    //     0x1162b88: add             lr, x0, x17
    //     0x1162b8c: ldr             lr, [x21, lr, lsl #3]
    //     0x1162b90: blr             lr
    // 0x1162b94: r1 = LoadInt32Instr(r0)
    //     0x1162b94: sbfx            x1, x0, #1, #0x1f
    //     0x1162b98: tbz             w0, #0, #0x1162ba0
    //     0x1162b9c: ldur            x1, [x0, #7]
    // 0x1162ba0: ldur            x2, [fp, #-0x20]
    // 0x1162ba4: cmp             x2, x1
    // 0x1162ba8: b.ge            #0x1162ce8
    // 0x1162bac: ldur            d0, [fp, #-0x50]
    // 0x1162bb0: ldur            x4, [fp, #-8]
    // 0x1162bb4: ldur            x3, [fp, #-0x30]
    // 0x1162bb8: r0 = BoxInt64Instr(r2)
    //     0x1162bb8: sbfiz           x0, x2, #1, #0x1f
    //     0x1162bbc: cmp             x2, x0, asr #1
    //     0x1162bc0: b.eq            #0x1162bcc
    //     0x1162bc4: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x1162bc8: stur            x2, [x0, #7]
    // 0x1162bcc: r1 = LoadClassIdInstr(r4)
    //     0x1162bcc: ldur            x1, [x4, #-1]
    //     0x1162bd0: ubfx            x1, x1, #0xc, #0x14
    // 0x1162bd4: stp             x0, x4, [SP]
    // 0x1162bd8: mov             x0, x1
    // 0x1162bdc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1162bdc: sub             lr, x0, #0xdfd
    //     0x1162be0: ldr             lr, [x21, lr, lsl #3]
    //     0x1162be4: blr             lr
    // 0x1162be8: stur            x0, [fp, #-0x18]
    // 0x1162bec: LoadField: r2 = r0->field_7
    //     0x1162bec: ldur            w2, [x0, #7]
    // 0x1162bf0: DecompressPointer r2
    //     0x1162bf0: add             x2, x2, HEAP, lsl #32
    // 0x1162bf4: stur            x2, [fp, #-0x10]
    // 0x1162bf8: LoadField: r1 = r0->field_b
    //     0x1162bf8: ldur            w1, [x0, #0xb]
    // 0x1162bfc: DecompressPointer r1
    //     0x1162bfc: add             x1, x1, HEAP, lsl #32
    // 0x1162c00: ldur            d0, [fp, #-0x50]
    // 0x1162c04: r0 = *()
    //     0x1162c04: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0x1162c08: mov             x1, x0
    // 0x1162c0c: ldur            x0, [fp, #-0x18]
    // 0x1162c10: stur            x1, [fp, #-0x38]
    // 0x1162c14: LoadField: d0 = r0->field_f
    //     0x1162c14: ldur            d0, [x0, #0xf]
    // 0x1162c18: ldur            d1, [fp, #-0x50]
    // 0x1162c1c: fmul            d2, d0, d1
    // 0x1162c20: stur            d2, [fp, #-0x60]
    // 0x1162c24: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1162c24: ldur            d0, [x0, #0x17]
    // 0x1162c28: fmul            d3, d0, d1
    // 0x1162c2c: stur            d3, [fp, #-0x58]
    // 0x1162c30: r0 = BoxShadow()
    //     0x1162c30: bl              #0x919648  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x1162c34: ldur            d0, [fp, #-0x58]
    // 0x1162c38: stur            x0, [fp, #-0x18]
    // 0x1162c3c: ArrayStore: r0[0] = d0  ; List_8
    //     0x1162c3c: stur            d0, [x0, #0x17]
    // 0x1162c40: r2 = Instance_BlurStyle
    //     0x1162c40: add             x2, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0x1162c44: ldr             x2, [x2, #0xce0]
    // 0x1162c48: StoreField: r0->field_1f = r2
    //     0x1162c48: stur            w2, [x0, #0x1f]
    // 0x1162c4c: ldur            x1, [fp, #-0x10]
    // 0x1162c50: StoreField: r0->field_7 = r1
    //     0x1162c50: stur            w1, [x0, #7]
    // 0x1162c54: ldur            x1, [fp, #-0x38]
    // 0x1162c58: StoreField: r0->field_b = r1
    //     0x1162c58: stur            w1, [x0, #0xb]
    // 0x1162c5c: ldur            d0, [fp, #-0x60]
    // 0x1162c60: StoreField: r0->field_f = d0
    //     0x1162c60: stur            d0, [x0, #0xf]
    // 0x1162c64: ldur            x3, [fp, #-0x30]
    // 0x1162c68: LoadField: r1 = r3->field_b
    //     0x1162c68: ldur            w1, [x3, #0xb]
    // 0x1162c6c: LoadField: r4 = r3->field_f
    //     0x1162c6c: ldur            w4, [x3, #0xf]
    // 0x1162c70: DecompressPointer r4
    //     0x1162c70: add             x4, x4, HEAP, lsl #32
    // 0x1162c74: LoadField: r5 = r4->field_b
    //     0x1162c74: ldur            w5, [x4, #0xb]
    // 0x1162c78: r4 = LoadInt32Instr(r1)
    //     0x1162c78: sbfx            x4, x1, #1, #0x1f
    // 0x1162c7c: stur            x4, [fp, #-0x28]
    // 0x1162c80: r1 = LoadInt32Instr(r5)
    //     0x1162c80: sbfx            x1, x5, #1, #0x1f
    // 0x1162c84: cmp             x4, x1
    // 0x1162c88: b.ne            #0x1162c94
    // 0x1162c8c: mov             x1, x3
    // 0x1162c90: r0 = _growToNextCapacity()
    //     0x1162c90: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1162c94: ldur            x2, [fp, #-0x30]
    // 0x1162c98: ldur            x4, [fp, #-0x20]
    // 0x1162c9c: ldur            x3, [fp, #-0x28]
    // 0x1162ca0: add             x5, x3, #1
    // 0x1162ca4: lsl             x6, x5, #1
    // 0x1162ca8: StoreField: r2->field_b = r6
    //     0x1162ca8: stur            w6, [x2, #0xb]
    // 0x1162cac: LoadField: r1 = r2->field_f
    //     0x1162cac: ldur            w1, [x2, #0xf]
    // 0x1162cb0: DecompressPointer r1
    //     0x1162cb0: add             x1, x1, HEAP, lsl #32
    // 0x1162cb4: ldur            x0, [fp, #-0x18]
    // 0x1162cb8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x1162cb8: add             x25, x1, x3, lsl #2
    //     0x1162cbc: add             x25, x25, #0xf
    //     0x1162cc0: str             w0, [x25]
    //     0x1162cc4: tbz             w0, #0, #0x1162ce0
    //     0x1162cc8: ldurb           w16, [x1, #-1]
    //     0x1162ccc: ldurb           w17, [x0, #-1]
    //     0x1162cd0: and             x16, x17, x16, lsr #2
    //     0x1162cd4: tst             x16, HEAP, lsr #32
    //     0x1162cd8: b.eq            #0x1162ce0
    //     0x1162cdc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1162ce0: add             x3, x4, #1
    // 0x1162ce4: b               #0x1162b60
    // 0x1162ce8: ldur            x2, [fp, #-0x30]
    // 0x1162cec: mov             x0, x2
    // 0x1162cf0: LeaveFrame
    //     0x1162cf0: mov             SP, fp
    //     0x1162cf4: ldp             fp, lr, [SP], #0x10
    // 0x1162cf8: ret
    //     0x1162cf8: ret             
    // 0x1162cfc: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162cfc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1162d00: b               #0x11627a0
    // 0x1162d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1162d04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1162d08: b               #0x11628b8
    // 0x1162d0c: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162d0c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1162d10: b               #0x11629e0
    // 0x1162d14: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162d14: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1162d18: b               #0x1162b78
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1162d1c, size: 0x294
    // 0x1162d1c: EnterFrame
    //     0x1162d1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1162d20: mov             fp, SP
    // 0x1162d24: AllocStack(0x38)
    //     0x1162d24: sub             SP, SP, #0x38
    // 0x1162d28: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x1162d28: mov             x4, x1
    //     0x1162d2c: mov             x0, x2
    //     0x1162d30: stur            x1, [fp, #-0x10]
    //     0x1162d34: stur            x2, [fp, #-0x18]
    // 0x1162d38: CheckStackOverflow
    //     0x1162d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1162d3c: cmp             SP, x16
    //     0x1162d40: b.ls            #0x1162f04
    // 0x1162d44: cmp             w4, w0
    // 0x1162d48: b.ne            #0x1162d5c
    // 0x1162d4c: mov             x0, x4
    // 0x1162d50: LeaveFrame
    //     0x1162d50: mov             SP, fp
    //     0x1162d54: ldp             fp, lr, [SP], #0x10
    // 0x1162d58: ret
    //     0x1162d58: ret             
    // 0x1162d5c: LoadField: r1 = r4->field_7
    //     0x1162d5c: ldur            w1, [x4, #7]
    // 0x1162d60: DecompressPointer r1
    //     0x1162d60: add             x1, x1, HEAP, lsl #32
    // 0x1162d64: LoadField: r2 = r0->field_7
    //     0x1162d64: ldur            w2, [x0, #7]
    // 0x1162d68: DecompressPointer r2
    //     0x1162d68: add             x2, x2, HEAP, lsl #32
    // 0x1162d6c: r5 = inline_Allocate_Double()
    //     0x1162d6c: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1162d70: add             x5, x5, #0x10
    //     0x1162d74: cmp             x3, x5
    //     0x1162d78: b.ls            #0x1162f0c
    //     0x1162d7c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1162d80: sub             x5, x5, #0xf
    //     0x1162d84: mov             x3, #0xe19c
    //     0x1162d88: movk            x3, #3, lsl #16
    //     0x1162d8c: stur            x3, [x5, #-1]
    // 0x1162d90: dmb             ishst
    // 0x1162d94: StoreField: r5->field_7 = d0
    //     0x1162d94: stur            d0, [x5, #7]
    // 0x1162d98: mov             x3, x5
    // 0x1162d9c: stur            x5, [fp, #-8]
    // 0x1162da0: r0 = lerp()
    //     0x1162da0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1162da4: mov             x4, x0
    // 0x1162da8: ldur            x0, [fp, #-0x10]
    // 0x1162dac: stur            x4, [fp, #-0x20]
    // 0x1162db0: LoadField: r1 = r0->field_b
    //     0x1162db0: ldur            w1, [x0, #0xb]
    // 0x1162db4: DecompressPointer r1
    //     0x1162db4: add             x1, x1, HEAP, lsl #32
    // 0x1162db8: ldur            x5, [fp, #-0x18]
    // 0x1162dbc: LoadField: r2 = r5->field_b
    //     0x1162dbc: ldur            w2, [x5, #0xb]
    // 0x1162dc0: DecompressPointer r2
    //     0x1162dc0: add             x2, x2, HEAP, lsl #32
    // 0x1162dc4: ldur            x3, [fp, #-8]
    // 0x1162dc8: r0 = lerp()
    //     0x1162dc8: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0x1162dcc: mov             x4, x0
    // 0x1162dd0: ldur            x0, [fp, #-0x10]
    // 0x1162dd4: stur            x4, [fp, #-0x28]
    // 0x1162dd8: LoadField: d0 = r0->field_f
    //     0x1162dd8: ldur            d0, [x0, #0xf]
    // 0x1162ddc: ldur            x5, [fp, #-0x18]
    // 0x1162de0: LoadField: d1 = r5->field_f
    //     0x1162de0: ldur            d1, [x5, #0xf]
    // 0x1162de4: r1 = inline_Allocate_Double()
    //     0x1162de4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1162de8: add             x1, x1, #0x10
    //     0x1162dec: cmp             x2, x1
    //     0x1162df0: b.ls            #0x1162f30
    //     0x1162df4: str             x1, [THR, #0x60]  ; THR::top
    //     0x1162df8: sub             x1, x1, #0xf
    //     0x1162dfc: mov             x2, #0xe19c
    //     0x1162e00: movk            x2, #3, lsl #16
    //     0x1162e04: stur            x2, [x1, #-1]
    // 0x1162e08: dmb             ishst
    // 0x1162e0c: StoreField: r1->field_7 = d0
    //     0x1162e0c: stur            d0, [x1, #7]
    // 0x1162e10: r2 = inline_Allocate_Double()
    //     0x1162e10: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1162e14: add             x2, x2, #0x10
    //     0x1162e18: cmp             x3, x2
    //     0x1162e1c: b.ls            #0x1162f54
    //     0x1162e20: str             x2, [THR, #0x60]  ; THR::top
    //     0x1162e24: sub             x2, x2, #0xf
    //     0x1162e28: mov             x3, #0xe19c
    //     0x1162e2c: movk            x3, #3, lsl #16
    //     0x1162e30: stur            x3, [x2, #-1]
    // 0x1162e34: dmb             ishst
    // 0x1162e38: StoreField: r2->field_7 = d1
    //     0x1162e38: stur            d1, [x2, #7]
    // 0x1162e3c: ldur            x3, [fp, #-8]
    // 0x1162e40: r0 = lerpDouble()
    //     0x1162e40: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1162e44: mov             x4, x0
    // 0x1162e48: ldur            x0, [fp, #-0x10]
    // 0x1162e4c: stur            x4, [fp, #-0x30]
    // 0x1162e50: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1162e50: ldur            d0, [x0, #0x17]
    // 0x1162e54: ldur            x0, [fp, #-0x18]
    // 0x1162e58: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x1162e58: ldur            d1, [x0, #0x17]
    // 0x1162e5c: r1 = inline_Allocate_Double()
    //     0x1162e5c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x1162e60: add             x1, x1, #0x10
    //     0x1162e64: cmp             x0, x1
    //     0x1162e68: b.ls            #0x1162f78
    //     0x1162e6c: str             x1, [THR, #0x60]  ; THR::top
    //     0x1162e70: sub             x1, x1, #0xf
    //     0x1162e74: mov             x0, #0xe19c
    //     0x1162e78: movk            x0, #3, lsl #16
    //     0x1162e7c: stur            x0, [x1, #-1]
    // 0x1162e80: dmb             ishst
    // 0x1162e84: StoreField: r1->field_7 = d0
    //     0x1162e84: stur            d0, [x1, #7]
    // 0x1162e88: r2 = inline_Allocate_Double()
    //     0x1162e88: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1162e8c: add             x2, x2, #0x10
    //     0x1162e90: cmp             x0, x2
    //     0x1162e94: b.ls            #0x1162f94
    //     0x1162e98: str             x2, [THR, #0x60]  ; THR::top
    //     0x1162e9c: sub             x2, x2, #0xf
    //     0x1162ea0: mov             x0, #0xe19c
    //     0x1162ea4: movk            x0, #3, lsl #16
    //     0x1162ea8: stur            x0, [x2, #-1]
    // 0x1162eac: dmb             ishst
    // 0x1162eb0: StoreField: r2->field_7 = d1
    //     0x1162eb0: stur            d1, [x2, #7]
    // 0x1162eb4: ldur            x3, [fp, #-8]
    // 0x1162eb8: r0 = lerpDouble()
    //     0x1162eb8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1162ebc: LoadField: d0 = r0->field_7
    //     0x1162ebc: ldur            d0, [x0, #7]
    // 0x1162ec0: stur            d0, [fp, #-0x38]
    // 0x1162ec4: r0 = BoxShadow()
    //     0x1162ec4: bl              #0x919648  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x1162ec8: ldur            d0, [fp, #-0x38]
    // 0x1162ecc: ArrayStore: r0[0] = d0  ; List_8
    //     0x1162ecc: stur            d0, [x0, #0x17]
    // 0x1162ed0: r1 = Instance_BlurStyle
    //     0x1162ed0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0x1162ed4: ldr             x1, [x1, #0xce0]
    // 0x1162ed8: StoreField: r0->field_1f = r1
    //     0x1162ed8: stur            w1, [x0, #0x1f]
    // 0x1162edc: ldur            x1, [fp, #-0x20]
    // 0x1162ee0: StoreField: r0->field_7 = r1
    //     0x1162ee0: stur            w1, [x0, #7]
    // 0x1162ee4: ldur            x1, [fp, #-0x28]
    // 0x1162ee8: StoreField: r0->field_b = r1
    //     0x1162ee8: stur            w1, [x0, #0xb]
    // 0x1162eec: ldur            x1, [fp, #-0x30]
    // 0x1162ef0: LoadField: d0 = r1->field_7
    //     0x1162ef0: ldur            d0, [x1, #7]
    // 0x1162ef4: StoreField: r0->field_f = d0
    //     0x1162ef4: stur            d0, [x0, #0xf]
    // 0x1162ef8: LeaveFrame
    //     0x1162ef8: mov             SP, fp
    //     0x1162efc: ldp             fp, lr, [SP], #0x10
    // 0x1162f00: ret
    //     0x1162f00: ret             
    // 0x1162f04: r0 = StackOverflowSharedWithFPURegs()
    //     0x1162f04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1162f08: b               #0x1162d44
    // 0x1162f0c: SaveReg d0
    //     0x1162f0c: str             q0, [SP, #-0x10]!
    // 0x1162f10: stp             x2, x4, [SP, #-0x10]!
    // 0x1162f14: stp             x0, x1, [SP, #-0x10]!
    // 0x1162f18: r0 = AllocateDouble()
    //     0x1162f18: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162f1c: mov             x5, x0
    // 0x1162f20: ldp             x0, x1, [SP], #0x10
    // 0x1162f24: ldp             x2, x4, [SP], #0x10
    // 0x1162f28: RestoreReg d0
    //     0x1162f28: ldr             q0, [SP], #0x10
    // 0x1162f2c: b               #0x1162d94
    // 0x1162f30: stp             q0, q1, [SP, #-0x20]!
    // 0x1162f34: stp             x4, x5, [SP, #-0x10]!
    // 0x1162f38: SaveReg r0
    //     0x1162f38: str             x0, [SP, #-8]!
    // 0x1162f3c: r0 = AllocateDouble()
    //     0x1162f3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162f40: mov             x1, x0
    // 0x1162f44: RestoreReg r0
    //     0x1162f44: ldr             x0, [SP], #8
    // 0x1162f48: ldp             x4, x5, [SP], #0x10
    // 0x1162f4c: ldp             q0, q1, [SP], #0x20
    // 0x1162f50: b               #0x1162e0c
    // 0x1162f54: SaveReg d1
    //     0x1162f54: str             q1, [SP, #-0x10]!
    // 0x1162f58: stp             x4, x5, [SP, #-0x10]!
    // 0x1162f5c: stp             x0, x1, [SP, #-0x10]!
    // 0x1162f60: r0 = AllocateDouble()
    //     0x1162f60: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162f64: mov             x2, x0
    // 0x1162f68: ldp             x0, x1, [SP], #0x10
    // 0x1162f6c: ldp             x4, x5, [SP], #0x10
    // 0x1162f70: RestoreReg d1
    //     0x1162f70: ldr             q1, [SP], #0x10
    // 0x1162f74: b               #0x1162e38
    // 0x1162f78: stp             q0, q1, [SP, #-0x20]!
    // 0x1162f7c: SaveReg r4
    //     0x1162f7c: str             x4, [SP, #-8]!
    // 0x1162f80: r0 = AllocateDouble()
    //     0x1162f80: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162f84: mov             x1, x0
    // 0x1162f88: RestoreReg r4
    //     0x1162f88: ldr             x4, [SP], #8
    // 0x1162f8c: ldp             q0, q1, [SP], #0x20
    // 0x1162f90: b               #0x1162e84
    // 0x1162f94: SaveReg d1
    //     0x1162f94: str             q1, [SP, #-0x10]!
    // 0x1162f98: stp             x1, x4, [SP, #-0x10]!
    // 0x1162f9c: r0 = AllocateDouble()
    //     0x1162f9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1162fa0: mov             x2, x0
    // 0x1162fa4: ldp             x1, x4, [SP], #0x10
    // 0x1162fa8: RestoreReg d1
    //     0x1162fa8: ldr             q1, [SP], #0x10
    // 0x1162fac: b               #0x1162eb0
  }
  _ ==(/* No info */) {
    // ** addr: 0x128df9c, size: 0x14c
    // 0x128df9c: EnterFrame
    //     0x128df9c: stp             fp, lr, [SP, #-0x10]!
    //     0x128dfa0: mov             fp, SP
    // 0x128dfa4: AllocStack(0x10)
    //     0x128dfa4: sub             SP, SP, #0x10
    // 0x128dfa8: CheckStackOverflow
    //     0x128dfa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x128dfac: cmp             SP, x16
    //     0x128dfb0: b.ls            #0x128e0e0
    // 0x128dfb4: ldr             x0, [fp, #0x10]
    // 0x128dfb8: cmp             w0, NULL
    // 0x128dfbc: b.ne            #0x128dfd0
    // 0x128dfc0: r0 = false
    //     0x128dfc0: add             x0, NULL, #0x30  ; false
    // 0x128dfc4: LeaveFrame
    //     0x128dfc4: mov             SP, fp
    //     0x128dfc8: ldp             fp, lr, [SP], #0x10
    // 0x128dfcc: ret
    //     0x128dfcc: ret             
    // 0x128dfd0: ldr             x1, [fp, #0x18]
    // 0x128dfd4: cmp             w1, w0
    // 0x128dfd8: b.ne            #0x128dfec
    // 0x128dfdc: r0 = true
    //     0x128dfdc: add             x0, NULL, #0x20  ; true
    // 0x128dfe0: LeaveFrame
    //     0x128dfe0: mov             SP, fp
    //     0x128dfe4: ldp             fp, lr, [SP], #0x10
    // 0x128dfe8: ret
    //     0x128dfe8: ret             
    // 0x128dfec: str             x0, [SP]
    // 0x128dff0: r0 = runtimeType()
    //     0x128dff0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x128dff4: r1 = LoadClassIdInstr(r0)
    //     0x128dff4: ldur            x1, [x0, #-1]
    //     0x128dff8: ubfx            x1, x1, #0xc, #0x14
    // 0x128dffc: r16 = BoxShadow
    //     0x128dffc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84940] Type: BoxShadow
    //     0x128e000: ldr             x16, [x16, #0x940]
    // 0x128e004: stp             x16, x0, [SP]
    // 0x128e008: mov             x0, x1
    // 0x128e00c: mov             lr, x0
    // 0x128e010: ldr             lr, [x21, lr, lsl #3]
    // 0x128e014: blr             lr
    // 0x128e018: tbz             w0, #4, #0x128e02c
    // 0x128e01c: r0 = false
    //     0x128e01c: add             x0, NULL, #0x30  ; false
    // 0x128e020: LeaveFrame
    //     0x128e020: mov             SP, fp
    //     0x128e024: ldp             fp, lr, [SP], #0x10
    // 0x128e028: ret
    //     0x128e028: ret             
    // 0x128e02c: ldr             x1, [fp, #0x10]
    // 0x128e030: r0 = 60
    //     0x128e030: mov             x0, #0x3c
    // 0x128e034: branchIfSmi(r1, 0x128e040)
    //     0x128e034: tbz             w1, #0, #0x128e040
    // 0x128e038: r0 = LoadClassIdInstr(r1)
    //     0x128e038: ldur            x0, [x1, #-1]
    //     0x128e03c: ubfx            x0, x0, #0xc, #0x14
    // 0x128e040: cmp             x0, #0xeb1
    // 0x128e044: b.ne            #0x128e0d0
    // 0x128e048: ldr             x2, [fp, #0x18]
    // 0x128e04c: LoadField: r0 = r1->field_7
    //     0x128e04c: ldur            w0, [x1, #7]
    // 0x128e050: DecompressPointer r0
    //     0x128e050: add             x0, x0, HEAP, lsl #32
    // 0x128e054: LoadField: r3 = r2->field_7
    //     0x128e054: ldur            w3, [x2, #7]
    // 0x128e058: DecompressPointer r3
    //     0x128e058: add             x3, x3, HEAP, lsl #32
    // 0x128e05c: r4 = LoadClassIdInstr(r0)
    //     0x128e05c: ldur            x4, [x0, #-1]
    //     0x128e060: ubfx            x4, x4, #0xc, #0x14
    // 0x128e064: stp             x3, x0, [SP]
    // 0x128e068: mov             x0, x4
    // 0x128e06c: mov             lr, x0
    // 0x128e070: ldr             lr, [x21, lr, lsl #3]
    // 0x128e074: blr             lr
    // 0x128e078: tbnz            w0, #4, #0x128e0d0
    // 0x128e07c: ldr             x1, [fp, #0x18]
    // 0x128e080: ldr             x0, [fp, #0x10]
    // 0x128e084: LoadField: r2 = r0->field_b
    //     0x128e084: ldur            w2, [x0, #0xb]
    // 0x128e088: DecompressPointer r2
    //     0x128e088: add             x2, x2, HEAP, lsl #32
    // 0x128e08c: LoadField: r3 = r1->field_b
    //     0x128e08c: ldur            w3, [x1, #0xb]
    // 0x128e090: DecompressPointer r3
    //     0x128e090: add             x3, x3, HEAP, lsl #32
    // 0x128e094: stp             x3, x2, [SP]
    // 0x128e098: r0 = ==()
    //     0x128e098: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x128e09c: tbnz            w0, #4, #0x128e0d0
    // 0x128e0a0: ldr             x2, [fp, #0x18]
    // 0x128e0a4: ldr             x1, [fp, #0x10]
    // 0x128e0a8: LoadField: d0 = r1->field_f
    //     0x128e0a8: ldur            d0, [x1, #0xf]
    // 0x128e0ac: LoadField: d1 = r2->field_f
    //     0x128e0ac: ldur            d1, [x2, #0xf]
    // 0x128e0b0: fcmp            d0, d1
    // 0x128e0b4: b.ne            #0x128e0d0
    // 0x128e0b8: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x128e0b8: ldur            d0, [x1, #0x17]
    // 0x128e0bc: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x128e0bc: ldur            d1, [x2, #0x17]
    // 0x128e0c0: fcmp            d0, d1
    // 0x128e0c4: b.ne            #0x128e0d0
    // 0x128e0c8: r0 = true
    //     0x128e0c8: add             x0, NULL, #0x20  ; true
    // 0x128e0cc: b               #0x128e0d4
    // 0x128e0d0: r0 = false
    //     0x128e0d0: add             x0, NULL, #0x30  ; false
    // 0x128e0d4: LeaveFrame
    //     0x128e0d4: mov             SP, fp
    //     0x128e0d8: ldp             fp, lr, [SP], #0x10
    // 0x128e0dc: ret
    //     0x128e0dc: ret             
    // 0x128e0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x128e0e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x128e0e4: b               #0x128dfb4
  }
  _ scale(/* No info */) {
    // ** addr: 0x12dc264, size: 0xb0
    // 0x12dc264: EnterFrame
    //     0x12dc264: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc268: mov             fp, SP
    // 0x12dc26c: AllocStack(0x30)
    //     0x12dc26c: sub             SP, SP, #0x30
    // 0x12dc270: SetupParameters(BoxShadow this /* r1 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x12dc270: mov             x0, x1
    //     0x12dc274: mov             v1.16b, v0.16b
    //     0x12dc278: stur            x1, [fp, #-0x10]
    //     0x12dc27c: stur            d0, [fp, #-0x20]
    // 0x12dc280: CheckStackOverflow
    //     0x12dc280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dc284: cmp             SP, x16
    //     0x12dc288: b.ls            #0x12dc30c
    // 0x12dc28c: LoadField: r2 = r0->field_7
    //     0x12dc28c: ldur            w2, [x0, #7]
    // 0x12dc290: DecompressPointer r2
    //     0x12dc290: add             x2, x2, HEAP, lsl #32
    // 0x12dc294: stur            x2, [fp, #-8]
    // 0x12dc298: LoadField: r1 = r0->field_b
    //     0x12dc298: ldur            w1, [x0, #0xb]
    // 0x12dc29c: DecompressPointer r1
    //     0x12dc29c: add             x1, x1, HEAP, lsl #32
    // 0x12dc2a0: mov             v0.16b, v1.16b
    // 0x12dc2a4: r0 = *()
    //     0x12dc2a4: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0x12dc2a8: mov             x1, x0
    // 0x12dc2ac: ldur            x0, [fp, #-0x10]
    // 0x12dc2b0: stur            x1, [fp, #-0x18]
    // 0x12dc2b4: LoadField: d0 = r0->field_f
    //     0x12dc2b4: ldur            d0, [x0, #0xf]
    // 0x12dc2b8: ldur            d1, [fp, #-0x20]
    // 0x12dc2bc: fmul            d2, d0, d1
    // 0x12dc2c0: stur            d2, [fp, #-0x30]
    // 0x12dc2c4: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12dc2c4: ldur            d0, [x0, #0x17]
    // 0x12dc2c8: fmul            d3, d0, d1
    // 0x12dc2cc: stur            d3, [fp, #-0x28]
    // 0x12dc2d0: r0 = BoxShadow()
    //     0x12dc2d0: bl              #0x919648  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x12dc2d4: ldur            d0, [fp, #-0x28]
    // 0x12dc2d8: ArrayStore: r0[0] = d0  ; List_8
    //     0x12dc2d8: stur            d0, [x0, #0x17]
    // 0x12dc2dc: r1 = Instance_BlurStyle
    //     0x12dc2dc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0x12dc2e0: ldr             x1, [x1, #0xce0]
    // 0x12dc2e4: StoreField: r0->field_1f = r1
    //     0x12dc2e4: stur            w1, [x0, #0x1f]
    // 0x12dc2e8: ldur            x1, [fp, #-8]
    // 0x12dc2ec: StoreField: r0->field_7 = r1
    //     0x12dc2ec: stur            w1, [x0, #7]
    // 0x12dc2f0: ldur            x1, [fp, #-0x18]
    // 0x12dc2f4: StoreField: r0->field_b = r1
    //     0x12dc2f4: stur            w1, [x0, #0xb]
    // 0x12dc2f8: ldur            d0, [fp, #-0x30]
    // 0x12dc2fc: StoreField: r0->field_f = d0
    //     0x12dc2fc: stur            d0, [x0, #0xf]
    // 0x12dc300: LeaveFrame
    //     0x12dc300: mov             SP, fp
    //     0x12dc304: ldp             fp, lr, [SP], #0x10
    // 0x12dc308: ret
    //     0x12dc308: ret             
    // 0x12dc30c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12dc30c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12dc310: b               #0x12dc28c
  }
}
