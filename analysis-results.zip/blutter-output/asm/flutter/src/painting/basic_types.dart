// lib: , url: package:flutter/src/painting/basic_types.dart

// class id: 1048979, size: 0x8
class :: {
}

// class id: 8250, size: 0x14, field offset: 0x14
enum AxisDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aacb0, size: 0x64
    // 0x11aacb0: EnterFrame
    //     0x11aacb0: stp             fp, lr, [SP, #-0x10]!
    //     0x11aacb4: mov             fp, SP
    // 0x11aacb8: AllocStack(0x10)
    //     0x11aacb8: sub             SP, SP, #0x10
    // 0x11aacbc: SetupParameters(AxisDirection this /* r1 => r0, fp-0x8 */)
    //     0x11aacbc: mov             x0, x1
    //     0x11aacc0: stur            x1, [fp, #-8]
    // 0x11aacc4: CheckStackOverflow
    //     0x11aacc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aacc8: cmp             SP, x16
    //     0x11aaccc: b.ls            #0x11aad0c
    // 0x11aacd0: r1 = Null
    //     0x11aacd0: mov             x1, NULL
    // 0x11aacd4: r2 = 4
    //     0x11aacd4: mov             x2, #4
    // 0x11aacd8: r0 = AllocateArray()
    //     0x11aacd8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aacdc: r16 = "AxisDirection."
    //     0x11aacdc: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ec0] "AxisDirection."
    //     0x11aace0: ldr             x16, [x16, #0xec0]
    // 0x11aace4: StoreField: r0->field_f = r16
    //     0x11aace4: stur            w16, [x0, #0xf]
    // 0x11aace8: ldur            x1, [fp, #-8]
    // 0x11aacec: LoadField: r2 = r1->field_f
    //     0x11aacec: ldur            w2, [x1, #0xf]
    // 0x11aacf0: DecompressPointer r2
    //     0x11aacf0: add             x2, x2, HEAP, lsl #32
    // 0x11aacf4: StoreField: r0->field_13 = r2
    //     0x11aacf4: stur            w2, [x0, #0x13]
    // 0x11aacf8: str             x0, [SP]
    // 0x11aacfc: r0 = _interpolate()
    //     0x11aacfc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aad00: LeaveFrame
    //     0x11aad00: mov             SP, fp
    //     0x11aad04: ldp             fp, lr, [SP], #0x10
    // 0x11aad08: ret
    //     0x11aad08: ret             
    // 0x11aad0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aad0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aad10: b               #0x11aacd0
  }
}

// class id: 8251, size: 0x14, field offset: 0x14
enum VerticalDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 8252, size: 0x14, field offset: 0x14
enum Axis extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 8253, size: 0x14, field offset: 0x14
enum RenderComparison extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aac4c, size: 0x64
    // 0x11aac4c: EnterFrame
    //     0x11aac4c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aac50: mov             fp, SP
    // 0x11aac54: AllocStack(0x10)
    //     0x11aac54: sub             SP, SP, #0x10
    // 0x11aac58: SetupParameters(RenderComparison this /* r1 => r0, fp-0x8 */)
    //     0x11aac58: mov             x0, x1
    //     0x11aac5c: stur            x1, [fp, #-8]
    // 0x11aac60: CheckStackOverflow
    //     0x11aac60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aac64: cmp             SP, x16
    //     0x11aac68: b.ls            #0x11aaca8
    // 0x11aac6c: r1 = Null
    //     0x11aac6c: mov             x1, NULL
    // 0x11aac70: r2 = 4
    //     0x11aac70: mov             x2, #4
    // 0x11aac74: r0 = AllocateArray()
    //     0x11aac74: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aac78: r16 = "RenderComparison."
    //     0x11aac78: add             x16, PP, #0x99, lsl #12  ; [pp+0x99f40] "RenderComparison."
    //     0x11aac7c: ldr             x16, [x16, #0xf40]
    // 0x11aac80: StoreField: r0->field_f = r16
    //     0x11aac80: stur            w16, [x0, #0xf]
    // 0x11aac84: ldur            x1, [fp, #-8]
    // 0x11aac88: LoadField: r2 = r1->field_f
    //     0x11aac88: ldur            w2, [x1, #0xf]
    // 0x11aac8c: DecompressPointer r2
    //     0x11aac8c: add             x2, x2, HEAP, lsl #32
    // 0x11aac90: StoreField: r0->field_13 = r2
    //     0x11aac90: stur            w2, [x0, #0x13]
    // 0x11aac94: str             x0, [SP]
    // 0x11aac98: r0 = _interpolate()
    //     0x11aac98: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aac9c: LeaveFrame
    //     0x11aac9c: mov             SP, fp
    //     0x11aaca0: ldp             fp, lr, [SP], #0x10
    // 0x11aaca4: ret
    //     0x11aaca4: ret             
    // 0x11aaca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aaca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aacac: b               #0x11aac6c
  }
}
