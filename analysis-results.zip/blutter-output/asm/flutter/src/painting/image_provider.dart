// lib: , url: package:flutter/src/painting/image_provider.dart

// class id: 1048998, size: 0x8
class :: {
}

// class id: 2921, size: 0xc, field offset: 0x8
class NetworkImageLoadException extends Object
    implements Exception {

  _ NetworkImageLoadException(/* No info */) {
    // ** addr: 0x1191dfc, size: 0xb4
    // 0x1191dfc: EnterFrame
    //     0x1191dfc: stp             fp, lr, [SP, #-0x10]!
    //     0x1191e00: mov             fp, SP
    // 0x1191e04: AllocStack(0x20)
    //     0x1191e04: sub             SP, SP, #0x20
    // 0x1191e08: SetupParameters(NetworkImageLoadException this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x1191e08: mov             x4, x1
    //     0x1191e0c: mov             x0, x2
    //     0x1191e10: stur            x1, [fp, #-8]
    //     0x1191e14: stur            x2, [fp, #-0x10]
    //     0x1191e18: stur            x3, [fp, #-0x18]
    // 0x1191e1c: CheckStackOverflow
    //     0x1191e1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191e20: cmp             SP, x16
    //     0x1191e24: b.ls            #0x1191ea8
    // 0x1191e28: r1 = Null
    //     0x1191e28: mov             x1, NULL
    // 0x1191e2c: r2 = 8
    //     0x1191e2c: mov             x2, #8
    // 0x1191e30: r0 = AllocateArray()
    //     0x1191e30: bl              #0x13df928  ; AllocateArrayStub
    // 0x1191e34: mov             x2, x0
    // 0x1191e38: r16 = "HTTP request failed, statusCode: "
    //     0x1191e38: add             x16, PP, #0x94, lsl #12  ; [pp+0x94d90] "HTTP request failed, statusCode: "
    //     0x1191e3c: ldr             x16, [x16, #0xd90]
    // 0x1191e40: StoreField: r2->field_f = r16
    //     0x1191e40: stur            w16, [x2, #0xf]
    // 0x1191e44: ldur            x3, [fp, #-0x10]
    // 0x1191e48: r0 = BoxInt64Instr(r3)
    //     0x1191e48: sbfiz           x0, x3, #1, #0x1f
    //     0x1191e4c: cmp             x3, x0, asr #1
    //     0x1191e50: b.eq            #0x1191e5c
    //     0x1191e54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1191e58: stur            x3, [x0, #7]
    // 0x1191e5c: StoreField: r2->field_13 = r0
    //     0x1191e5c: stur            w0, [x2, #0x13]
    // 0x1191e60: r16 = ", "
    //     0x1191e60: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0x1191e64: ArrayStore: r2[0] = r16  ; List_4
    //     0x1191e64: stur            w16, [x2, #0x17]
    // 0x1191e68: ldur            x0, [fp, #-0x18]
    // 0x1191e6c: StoreField: r2->field_1b = r0
    //     0x1191e6c: stur            w0, [x2, #0x1b]
    // 0x1191e70: str             x2, [SP]
    // 0x1191e74: r0 = _interpolate()
    //     0x1191e74: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1191e78: ldur            x1, [fp, #-8]
    // 0x1191e7c: StoreField: r1->field_7 = r0
    //     0x1191e7c: stur            w0, [x1, #7]
    //     0x1191e80: ldurb           w16, [x1, #-1]
    //     0x1191e84: ldurb           w17, [x0, #-1]
    //     0x1191e88: and             x16, x17, x16, lsr #2
    //     0x1191e8c: tst             x16, HEAP, lsr #32
    //     0x1191e90: b.eq            #0x1191e98
    //     0x1191e94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1191e98: r0 = Null
    //     0x1191e98: mov             x0, NULL
    // 0x1191e9c: LeaveFrame
    //     0x1191e9c: mov             SP, fp
    //     0x1191ea0: ldp             fp, lr, [SP], #0x10
    // 0x1191ea4: ret
    //     0x1191ea4: ret             
    // 0x1191ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191eac: b               #0x1191e28
  }
}

// class id: 2923, size: 0x18, field offset: 0x8
//   const constructor, 
class AssetBundleImageKey extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x12993b0, size: 0x11c
    // 0x12993b0: EnterFrame
    //     0x12993b0: stp             fp, lr, [SP, #-0x10]!
    //     0x12993b4: mov             fp, SP
    // 0x12993b8: AllocStack(0x10)
    //     0x12993b8: sub             SP, SP, #0x10
    // 0x12993bc: CheckStackOverflow
    //     0x12993bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12993c0: cmp             SP, x16
    //     0x12993c4: b.ls            #0x12994c4
    // 0x12993c8: ldr             x0, [fp, #0x10]
    // 0x12993cc: cmp             w0, NULL
    // 0x12993d0: b.ne            #0x12993e4
    // 0x12993d4: r0 = false
    //     0x12993d4: add             x0, NULL, #0x30  ; false
    // 0x12993d8: LeaveFrame
    //     0x12993d8: mov             SP, fp
    //     0x12993dc: ldp             fp, lr, [SP], #0x10
    // 0x12993e0: ret
    //     0x12993e0: ret             
    // 0x12993e4: str             x0, [SP]
    // 0x12993e8: r0 = runtimeType()
    //     0x12993e8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12993ec: r1 = LoadClassIdInstr(r0)
    //     0x12993ec: ldur            x1, [x0, #-1]
    //     0x12993f0: ubfx            x1, x1, #0xc, #0x14
    // 0x12993f4: r16 = AssetBundleImageKey
    //     0x12993f4: add             x16, PP, #0x97, lsl #12  ; [pp+0x977b0] Type: AssetBundleImageKey
    //     0x12993f8: ldr             x16, [x16, #0x7b0]
    // 0x12993fc: stp             x16, x0, [SP]
    // 0x1299400: mov             x0, x1
    // 0x1299404: mov             lr, x0
    // 0x1299408: ldr             lr, [x21, lr, lsl #3]
    // 0x129940c: blr             lr
    // 0x1299410: tbz             w0, #4, #0x1299424
    // 0x1299414: r0 = false
    //     0x1299414: add             x0, NULL, #0x30  ; false
    // 0x1299418: LeaveFrame
    //     0x1299418: mov             SP, fp
    //     0x129941c: ldp             fp, lr, [SP], #0x10
    // 0x1299420: ret
    //     0x1299420: ret             
    // 0x1299424: ldr             x1, [fp, #0x10]
    // 0x1299428: r0 = 60
    //     0x1299428: mov             x0, #0x3c
    // 0x129942c: branchIfSmi(r1, 0x1299438)
    //     0x129942c: tbz             w1, #0, #0x1299438
    // 0x1299430: r0 = LoadClassIdInstr(r1)
    //     0x1299430: ldur            x0, [x1, #-1]
    //     0x1299434: ubfx            x0, x0, #0xc, #0x14
    // 0x1299438: cmp             x0, #0xb6b
    // 0x129943c: b.ne            #0x12994b4
    // 0x1299440: ldr             x2, [fp, #0x18]
    // 0x1299444: LoadField: r0 = r1->field_7
    //     0x1299444: ldur            w0, [x1, #7]
    // 0x1299448: DecompressPointer r0
    //     0x1299448: add             x0, x0, HEAP, lsl #32
    // 0x129944c: LoadField: r3 = r2->field_7
    //     0x129944c: ldur            w3, [x2, #7]
    // 0x1299450: DecompressPointer r3
    //     0x1299450: add             x3, x3, HEAP, lsl #32
    // 0x1299454: cmp             w0, w3
    // 0x1299458: b.ne            #0x12994b4
    // 0x129945c: LoadField: r0 = r1->field_b
    //     0x129945c: ldur            w0, [x1, #0xb]
    // 0x1299460: DecompressPointer r0
    //     0x1299460: add             x0, x0, HEAP, lsl #32
    // 0x1299464: LoadField: r3 = r2->field_b
    //     0x1299464: ldur            w3, [x2, #0xb]
    // 0x1299468: DecompressPointer r3
    //     0x1299468: add             x3, x3, HEAP, lsl #32
    // 0x129946c: r4 = LoadClassIdInstr(r0)
    //     0x129946c: ldur            x4, [x0, #-1]
    //     0x1299470: ubfx            x4, x4, #0xc, #0x14
    // 0x1299474: stp             x3, x0, [SP]
    // 0x1299478: mov             x0, x4
    // 0x129947c: mov             lr, x0
    // 0x1299480: ldr             lr, [x21, lr, lsl #3]
    // 0x1299484: blr             lr
    // 0x1299488: tbnz            w0, #4, #0x12994b4
    // 0x129948c: ldr             x2, [fp, #0x18]
    // 0x1299490: ldr             x1, [fp, #0x10]
    // 0x1299494: LoadField: d0 = r1->field_f
    //     0x1299494: ldur            d0, [x1, #0xf]
    // 0x1299498: LoadField: d1 = r2->field_f
    //     0x1299498: ldur            d1, [x2, #0xf]
    // 0x129949c: fcmp            d0, d1
    // 0x12994a0: r16 = true
    //     0x12994a0: add             x16, NULL, #0x20  ; true
    // 0x12994a4: r17 = false
    //     0x12994a4: add             x17, NULL, #0x30  ; false
    // 0x12994a8: csel            x1, x16, x17, eq
    // 0x12994ac: mov             x0, x1
    // 0x12994b0: b               #0x12994b8
    // 0x12994b4: r0 = false
    //     0x12994b4: add             x0, NULL, #0x30  ; false
    // 0x12994b8: LeaveFrame
    //     0x12994b8: mov             SP, fp
    //     0x12994bc: ldp             fp, lr, [SP], #0x10
    // 0x12994c0: ret
    //     0x12994c0: ret             
    // 0x12994c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12994c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12994c8: b               #0x12993c8
  }
}

// class id: 2924, size: 0x20, field offset: 0x8
//   const constructor, 
class ImageConfiguration extends Object {

  _ copyWith(/* No info */) {
    // ** addr: 0xb6d728, size: 0x8c
    // 0xb6d728: EnterFrame
    //     0xb6d728: stp             fp, lr, [SP, #-0x10]!
    //     0xb6d72c: mov             fp, SP
    // 0xb6d730: AllocStack(0x30)
    //     0xb6d730: sub             SP, SP, #0x30
    // 0xb6d734: SetupParameters(dynamic _ /* r2 => r2, fp-0x30 */)
    //     0xb6d734: stur            x2, [fp, #-0x30]
    // 0xb6d738: LoadField: r0 = r1->field_7
    //     0xb6d738: ldur            w0, [x1, #7]
    // 0xb6d73c: DecompressPointer r0
    //     0xb6d73c: add             x0, x0, HEAP, lsl #32
    // 0xb6d740: stur            x0, [fp, #-0x28]
    // 0xb6d744: LoadField: r3 = r1->field_b
    //     0xb6d744: ldur            w3, [x1, #0xb]
    // 0xb6d748: DecompressPointer r3
    //     0xb6d748: add             x3, x3, HEAP, lsl #32
    // 0xb6d74c: stur            x3, [fp, #-0x20]
    // 0xb6d750: LoadField: r4 = r1->field_f
    //     0xb6d750: ldur            w4, [x1, #0xf]
    // 0xb6d754: DecompressPointer r4
    //     0xb6d754: add             x4, x4, HEAP, lsl #32
    // 0xb6d758: stur            x4, [fp, #-0x18]
    // 0xb6d75c: LoadField: r5 = r1->field_13
    //     0xb6d75c: ldur            w5, [x1, #0x13]
    // 0xb6d760: DecompressPointer r5
    //     0xb6d760: add             x5, x5, HEAP, lsl #32
    // 0xb6d764: stur            x5, [fp, #-0x10]
    // 0xb6d768: LoadField: r6 = r1->field_1b
    //     0xb6d768: ldur            w6, [x1, #0x1b]
    // 0xb6d76c: DecompressPointer r6
    //     0xb6d76c: add             x6, x6, HEAP, lsl #32
    // 0xb6d770: stur            x6, [fp, #-8]
    // 0xb6d774: r0 = ImageConfiguration()
    //     0xb6d774: bl              #0xb6d7b4  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xb6d778: ldur            x1, [fp, #-0x28]
    // 0xb6d77c: StoreField: r0->field_7 = r1
    //     0xb6d77c: stur            w1, [x0, #7]
    // 0xb6d780: ldur            x1, [fp, #-0x20]
    // 0xb6d784: StoreField: r0->field_b = r1
    //     0xb6d784: stur            w1, [x0, #0xb]
    // 0xb6d788: ldur            x1, [fp, #-0x18]
    // 0xb6d78c: StoreField: r0->field_f = r1
    //     0xb6d78c: stur            w1, [x0, #0xf]
    // 0xb6d790: ldur            x1, [fp, #-0x10]
    // 0xb6d794: StoreField: r0->field_13 = r1
    //     0xb6d794: stur            w1, [x0, #0x13]
    // 0xb6d798: ldur            x1, [fp, #-0x30]
    // 0xb6d79c: ArrayStore: r0[0] = r1  ; List_4
    //     0xb6d79c: stur            w1, [x0, #0x17]
    // 0xb6d7a0: ldur            x1, [fp, #-8]
    // 0xb6d7a4: StoreField: r0->field_1b = r1
    //     0xb6d7a4: stur            w1, [x0, #0x1b]
    // 0xb6d7a8: LeaveFrame
    //     0xb6d7a8: mov             SP, fp
    //     0xb6d7ac: ldp             fp, lr, [SP], #0x10
    // 0xb6d7b0: ret
    //     0xb6d7b0: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114c118, size: 0x84
    // 0x114c118: EnterFrame
    //     0x114c118: stp             fp, lr, [SP, #-0x10]!
    //     0x114c11c: mov             fp, SP
    // 0x114c120: AllocStack(0x18)
    //     0x114c120: sub             SP, SP, #0x18
    // 0x114c124: CheckStackOverflow
    //     0x114c124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c128: cmp             SP, x16
    //     0x114c12c: b.ls            #0x114c194
    // 0x114c130: ldr             x0, [fp, #0x10]
    // 0x114c134: LoadField: r1 = r0->field_7
    //     0x114c134: ldur            w1, [x0, #7]
    // 0x114c138: DecompressPointer r1
    //     0x114c138: add             x1, x1, HEAP, lsl #32
    // 0x114c13c: LoadField: r2 = r0->field_b
    //     0x114c13c: ldur            w2, [x0, #0xb]
    // 0x114c140: DecompressPointer r2
    //     0x114c140: add             x2, x2, HEAP, lsl #32
    // 0x114c144: LoadField: r3 = r0->field_f
    //     0x114c144: ldur            w3, [x0, #0xf]
    // 0x114c148: DecompressPointer r3
    //     0x114c148: add             x3, x3, HEAP, lsl #32
    // 0x114c14c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x114c14c: ldur            w4, [x0, #0x17]
    // 0x114c150: DecompressPointer r4
    //     0x114c150: add             x4, x4, HEAP, lsl #32
    // 0x114c154: LoadField: r5 = r0->field_1b
    //     0x114c154: ldur            w5, [x0, #0x1b]
    // 0x114c158: DecompressPointer r5
    //     0x114c158: add             x5, x5, HEAP, lsl #32
    // 0x114c15c: stp             x4, x3, [SP, #8]
    // 0x114c160: str             x5, [SP]
    // 0x114c164: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x114c164: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x114c168: ldr             x4, [x4, #0xc80]
    // 0x114c16c: r0 = hash()
    //     0x114c16c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c170: mov             x2, x0
    // 0x114c174: r0 = BoxInt64Instr(r2)
    //     0x114c174: sbfiz           x0, x2, #1, #0x1f
    //     0x114c178: cmp             x2, x0, asr #1
    //     0x114c17c: b.eq            #0x114c188
    //     0x114c180: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c184: stur            x2, [x0, #7]
    // 0x114c188: LeaveFrame
    //     0x114c188: mov             SP, fp
    //     0x114c18c: ldp             fp, lr, [SP], #0x10
    // 0x114c190: ret
    //     0x114c190: ret             
    // 0x114c194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c198: b               #0x114c130
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299204, size: 0x1ac
    // 0x1299204: EnterFrame
    //     0x1299204: stp             fp, lr, [SP, #-0x10]!
    //     0x1299208: mov             fp, SP
    // 0x129920c: AllocStack(0x10)
    //     0x129920c: sub             SP, SP, #0x10
    // 0x1299210: CheckStackOverflow
    //     0x1299210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299214: cmp             SP, x16
    //     0x1299218: b.ls            #0x12993a8
    // 0x129921c: ldr             x0, [fp, #0x10]
    // 0x1299220: cmp             w0, NULL
    // 0x1299224: b.ne            #0x1299238
    // 0x1299228: r0 = false
    //     0x1299228: add             x0, NULL, #0x30  ; false
    // 0x129922c: LeaveFrame
    //     0x129922c: mov             SP, fp
    //     0x1299230: ldp             fp, lr, [SP], #0x10
    // 0x1299234: ret
    //     0x1299234: ret             
    // 0x1299238: str             x0, [SP]
    // 0x129923c: r0 = runtimeType()
    //     0x129923c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1299240: r1 = LoadClassIdInstr(r0)
    //     0x1299240: ldur            x1, [x0, #-1]
    //     0x1299244: ubfx            x1, x1, #0xc, #0x14
    // 0x1299248: r16 = ImageConfiguration
    //     0x1299248: add             x16, PP, #0x81, lsl #12  ; [pp+0x81300] Type: ImageConfiguration
    //     0x129924c: ldr             x16, [x16, #0x300]
    // 0x1299250: stp             x16, x0, [SP]
    // 0x1299254: mov             x0, x1
    // 0x1299258: mov             lr, x0
    // 0x129925c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299260: blr             lr
    // 0x1299264: tbz             w0, #4, #0x1299278
    // 0x1299268: r0 = false
    //     0x1299268: add             x0, NULL, #0x30  ; false
    // 0x129926c: LeaveFrame
    //     0x129926c: mov             SP, fp
    //     0x1299270: ldp             fp, lr, [SP], #0x10
    // 0x1299274: ret
    //     0x1299274: ret             
    // 0x1299278: ldr             x1, [fp, #0x10]
    // 0x129927c: r0 = 60
    //     0x129927c: mov             x0, #0x3c
    // 0x1299280: branchIfSmi(r1, 0x129928c)
    //     0x1299280: tbz             w1, #0, #0x129928c
    // 0x1299284: r0 = LoadClassIdInstr(r1)
    //     0x1299284: ldur            x0, [x1, #-1]
    //     0x1299288: ubfx            x0, x0, #0xc, #0x14
    // 0x129928c: cmp             x0, #0xb6c
    // 0x1299290: b.ne            #0x1299398
    // 0x1299294: ldr             x2, [fp, #0x18]
    // 0x1299298: LoadField: r0 = r1->field_7
    //     0x1299298: ldur            w0, [x1, #7]
    // 0x129929c: DecompressPointer r0
    //     0x129929c: add             x0, x0, HEAP, lsl #32
    // 0x12992a0: LoadField: r3 = r2->field_7
    //     0x12992a0: ldur            w3, [x2, #7]
    // 0x12992a4: DecompressPointer r3
    //     0x12992a4: add             x3, x3, HEAP, lsl #32
    // 0x12992a8: cmp             w0, w3
    // 0x12992ac: b.ne            #0x1299398
    // 0x12992b0: LoadField: r0 = r1->field_b
    //     0x12992b0: ldur            w0, [x1, #0xb]
    // 0x12992b4: DecompressPointer r0
    //     0x12992b4: add             x0, x0, HEAP, lsl #32
    // 0x12992b8: LoadField: r3 = r2->field_b
    //     0x12992b8: ldur            w3, [x2, #0xb]
    // 0x12992bc: DecompressPointer r3
    //     0x12992bc: add             x3, x3, HEAP, lsl #32
    // 0x12992c0: r4 = LoadClassIdInstr(r0)
    //     0x12992c0: ldur            x4, [x0, #-1]
    //     0x12992c4: ubfx            x4, x4, #0xc, #0x14
    // 0x12992c8: stp             x3, x0, [SP]
    // 0x12992cc: mov             x0, x4
    // 0x12992d0: mov             lr, x0
    // 0x12992d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12992d8: blr             lr
    // 0x12992dc: tbnz            w0, #4, #0x1299398
    // 0x12992e0: ldr             x2, [fp, #0x18]
    // 0x12992e4: ldr             x1, [fp, #0x10]
    // 0x12992e8: LoadField: r0 = r1->field_f
    //     0x12992e8: ldur            w0, [x1, #0xf]
    // 0x12992ec: DecompressPointer r0
    //     0x12992ec: add             x0, x0, HEAP, lsl #32
    // 0x12992f0: LoadField: r3 = r2->field_f
    //     0x12992f0: ldur            w3, [x2, #0xf]
    // 0x12992f4: DecompressPointer r3
    //     0x12992f4: add             x3, x3, HEAP, lsl #32
    // 0x12992f8: r4 = LoadClassIdInstr(r0)
    //     0x12992f8: ldur            x4, [x0, #-1]
    //     0x12992fc: ubfx            x4, x4, #0xc, #0x14
    // 0x1299300: stp             x3, x0, [SP]
    // 0x1299304: mov             x0, x4
    // 0x1299308: mov             lr, x0
    // 0x129930c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299310: blr             lr
    // 0x1299314: tbnz            w0, #4, #0x1299398
    // 0x1299318: ldr             x2, [fp, #0x18]
    // 0x129931c: ldr             x1, [fp, #0x10]
    // 0x1299320: LoadField: r0 = r1->field_13
    //     0x1299320: ldur            w0, [x1, #0x13]
    // 0x1299324: DecompressPointer r0
    //     0x1299324: add             x0, x0, HEAP, lsl #32
    // 0x1299328: LoadField: r3 = r2->field_13
    //     0x1299328: ldur            w3, [x2, #0x13]
    // 0x129932c: DecompressPointer r3
    //     0x129932c: add             x3, x3, HEAP, lsl #32
    // 0x1299330: cmp             w0, w3
    // 0x1299334: b.ne            #0x1299398
    // 0x1299338: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1299338: ldur            w0, [x1, #0x17]
    // 0x129933c: DecompressPointer r0
    //     0x129933c: add             x0, x0, HEAP, lsl #32
    // 0x1299340: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1299340: ldur            w3, [x2, #0x17]
    // 0x1299344: DecompressPointer r3
    //     0x1299344: add             x3, x3, HEAP, lsl #32
    // 0x1299348: r4 = LoadClassIdInstr(r0)
    //     0x1299348: ldur            x4, [x0, #-1]
    //     0x129934c: ubfx            x4, x4, #0xc, #0x14
    // 0x1299350: stp             x3, x0, [SP]
    // 0x1299354: mov             x0, x4
    // 0x1299358: mov             lr, x0
    // 0x129935c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299360: blr             lr
    // 0x1299364: tbnz            w0, #4, #0x1299398
    // 0x1299368: ldr             x2, [fp, #0x18]
    // 0x129936c: ldr             x1, [fp, #0x10]
    // 0x1299370: LoadField: r3 = r1->field_1b
    //     0x1299370: ldur            w3, [x1, #0x1b]
    // 0x1299374: DecompressPointer r3
    //     0x1299374: add             x3, x3, HEAP, lsl #32
    // 0x1299378: LoadField: r1 = r2->field_1b
    //     0x1299378: ldur            w1, [x2, #0x1b]
    // 0x129937c: DecompressPointer r1
    //     0x129937c: add             x1, x1, HEAP, lsl #32
    // 0x1299380: cmp             w3, w1
    // 0x1299384: r16 = true
    //     0x1299384: add             x16, NULL, #0x20  ; true
    // 0x1299388: r17 = false
    //     0x1299388: add             x17, NULL, #0x30  ; false
    // 0x129938c: csel            x2, x16, x17, eq
    // 0x1299390: mov             x0, x2
    // 0x1299394: b               #0x129939c
    // 0x1299398: r0 = false
    //     0x1299398: add             x0, NULL, #0x30  ; false
    // 0x129939c: LeaveFrame
    //     0x129939c: mov             SP, fp
    //     0x12993a0: ldp             fp, lr, [SP], #0x10
    // 0x12993a4: ret
    //     0x12993a4: ret             
    // 0x12993a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12993a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12993ac: b               #0x129921c
  }
}

// class id: 3593, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ImageProvider<X0> extends Object {

  ImageStream resolve(ImageProvider<X0>, ImageConfiguration) {
    // ** addr: 0x919d60, size: 0x84
    // 0x919d60: EnterFrame
    //     0x919d60: stp             fp, lr, [SP, #-0x10]!
    //     0x919d64: mov             fp, SP
    // 0x919d68: CheckStackOverflow
    //     0x919d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919d6c: cmp             SP, x16
    //     0x919d70: b.ls            #0x919dc4
    // 0x919d74: ldr             x0, [fp, #0x10]
    // 0x919d78: r2 = Null
    //     0x919d78: mov             x2, NULL
    // 0x919d7c: r1 = Null
    //     0x919d7c: mov             x1, NULL
    // 0x919d80: r4 = 60
    //     0x919d80: mov             x4, #0x3c
    // 0x919d84: branchIfSmi(r0, 0x919d90)
    //     0x919d84: tbz             w0, #0, #0x919d90
    // 0x919d88: r4 = LoadClassIdInstr(r0)
    //     0x919d88: ldur            x4, [x0, #-1]
    //     0x919d8c: ubfx            x4, x4, #0xc, #0x14
    // 0x919d90: cmp             x4, #0xb6c
    // 0x919d94: b.eq            #0x919dac
    // 0x919d98: r8 = ImageConfiguration
    //     0x919d98: add             x8, PP, #0x81, lsl #12  ; [pp+0x81300] Type: ImageConfiguration
    //     0x919d9c: ldr             x8, [x8, #0x300]
    // 0x919da0: r3 = Null
    //     0x919da0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81308] Null
    //     0x919da4: ldr             x3, [x3, #0x308]
    // 0x919da8: r0 = DefaultTypeTest()
    //     0x919da8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x919dac: ldr             x1, [fp, #0x18]
    // 0x919db0: ldr             x2, [fp, #0x10]
    // 0x919db4: r0 = resolve()
    //     0x919db4: bl              #0x919dcc  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve
    // 0x919db8: LeaveFrame
    //     0x919db8: mov             SP, fp
    //     0x919dbc: ldp             fp, lr, [SP], #0x10
    // 0x919dc0: ret
    //     0x919dc0: ret             
    // 0x919dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x919dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x919dc8: b               #0x919d74
  }
  ImageStream resolve(ImageProvider<X0>, ImageConfiguration) {
    // ** addr: 0x919dcc, size: 0xd0
    // 0x919dcc: EnterFrame
    //     0x919dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x919dd0: mov             fp, SP
    // 0x919dd4: AllocStack(0x28)
    //     0x919dd4: sub             SP, SP, #0x28
    // 0x919dd8: SetupParameters(ImageProvider<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x919dd8: stur            x1, [fp, #-8]
    //     0x919ddc: stur            x2, [fp, #-0x10]
    // 0x919de0: CheckStackOverflow
    //     0x919de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919de4: cmp             SP, x16
    //     0x919de8: b.ls            #0x919e94
    // 0x919dec: r1 = 2
    //     0x919dec: mov             x1, #2
    // 0x919df0: r0 = AllocateContext()
    //     0x919df0: bl              #0x13de838  ; AllocateContextStub
    // 0x919df4: mov             x2, x0
    // 0x919df8: ldur            x0, [fp, #-8]
    // 0x919dfc: stur            x2, [fp, #-0x18]
    // 0x919e00: StoreField: r2->field_f = r0
    //     0x919e00: stur            w0, [x2, #0xf]
    // 0x919e04: mov             x1, x0
    // 0x919e08: r0 = createStream()
    //     0x919e08: bl              #0x91a174  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::createStream
    // 0x919e0c: mov             x5, x0
    // 0x919e10: ldur            x4, [fp, #-0x18]
    // 0x919e14: stur            x5, [fp, #-0x28]
    // 0x919e18: StoreField: r4->field_13 = r0
    //     0x919e18: stur            w0, [x4, #0x13]
    //     0x919e1c: ldurb           w16, [x4, #-1]
    //     0x919e20: ldurb           w17, [x0, #-1]
    //     0x919e24: and             x16, x17, x16, lsr #2
    //     0x919e28: tst             x16, HEAP, lsr #32
    //     0x919e2c: b.eq            #0x919e34
    //     0x919e30: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x919e34: ldur            x0, [fp, #-8]
    // 0x919e38: LoadField: r6 = r0->field_7
    //     0x919e38: ldur            w6, [x0, #7]
    // 0x919e3c: DecompressPointer r6
    //     0x919e3c: add             x6, x6, HEAP, lsl #32
    // 0x919e40: mov             x2, x4
    // 0x919e44: mov             x3, x6
    // 0x919e48: stur            x6, [fp, #-0x20]
    // 0x919e4c: r1 = Function '<anonymous closure>':.
    //     0x919e4c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81318] AnonymousClosure: (0x91ab34), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve (0x919dcc)
    //     0x919e50: ldr             x1, [x1, #0x318]
    // 0x919e54: r0 = AllocateClosureTA()
    //     0x919e54: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x919e58: ldur            x2, [fp, #-0x18]
    // 0x919e5c: ldur            x3, [fp, #-0x20]
    // 0x919e60: r1 = Function '<anonymous closure>':.
    //     0x919e60: add             x1, PP, #0x81, lsl #12  ; [pp+0x81320] AnonymousClosure: (0x91a198), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve (0x919dcc)
    //     0x919e64: ldr             x1, [x1, #0x320]
    // 0x919e68: stur            x0, [fp, #-0x18]
    // 0x919e6c: r0 = AllocateClosureTA()
    //     0x919e6c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x919e70: ldur            x1, [fp, #-8]
    // 0x919e74: ldur            x2, [fp, #-0x10]
    // 0x919e78: ldur            x3, [fp, #-0x18]
    // 0x919e7c: mov             x5, x0
    // 0x919e80: r0 = _createErrorHandlerAndKey()
    //     0x919e80: bl              #0x919e9c  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey
    // 0x919e84: ldur            x0, [fp, #-0x28]
    // 0x919e88: LeaveFrame
    //     0x919e88: mov             SP, fp
    //     0x919e8c: ldp             fp, lr, [SP], #0x10
    // 0x919e90: ret
    //     0x919e90: ret             
    // 0x919e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x919e94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x919e98: b               #0x919dec
  }
  _ _createErrorHandlerAndKey(/* No info */) {
    // ** addr: 0x919e9c, size: 0x15c
    // 0x919e9c: EnterFrame
    //     0x919e9c: stp             fp, lr, [SP, #-0x10]!
    //     0x919ea0: mov             fp, SP
    // 0x919ea4: AllocStack(0x90)
    //     0x919ea4: sub             SP, SP, #0x90
    // 0x919ea8: SetupParameters(ImageProvider<X0> this /* r1 => r1, fp-0x58 */, dynamic _ /* r2 => r2, fp-0x60 */, dynamic _ /* r3 => r3, fp-0x68 */, dynamic _ /* r5 => r5, fp-0x70 */)
    //     0x919ea8: stur            x1, [fp, #-0x58]
    //     0x919eac: stur            x2, [fp, #-0x60]
    //     0x919eb0: stur            x3, [fp, #-0x68]
    //     0x919eb4: stur            x5, [fp, #-0x70]
    // 0x919eb8: CheckStackOverflow
    //     0x919eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919ebc: cmp             SP, x16
    //     0x919ec0: b.ls            #0x919ff0
    // 0x919ec4: r1 = 6
    //     0x919ec4: mov             x1, #6
    // 0x919ec8: r0 = AllocateContext()
    //     0x919ec8: bl              #0x13de838  ; AllocateContextStub
    // 0x919ecc: mov             x3, x0
    // 0x919ed0: ldur            x0, [fp, #-0x58]
    // 0x919ed4: stur            x3, [fp, #-0x78]
    // 0x919ed8: StoreField: r3->field_f = r0
    //     0x919ed8: stur            w0, [x3, #0xf]
    // 0x919edc: ldur            x1, [fp, #-0x68]
    // 0x919ee0: StoreField: r3->field_13 = r1
    //     0x919ee0: stur            w1, [x3, #0x13]
    // 0x919ee4: ldur            x1, [fp, #-0x70]
    // 0x919ee8: ArrayStore: r3[0] = r1  ; List_4
    //     0x919ee8: stur            w1, [x3, #0x17]
    // 0x919eec: r1 = false
    //     0x919eec: add             x1, NULL, #0x30  ; false
    // 0x919ef0: StoreField: r3->field_1f = r1
    //     0x919ef0: stur            w1, [x3, #0x1f]
    // 0x919ef4: mov             x2, x3
    // 0x919ef8: r1 = Function 'handleError':.
    //     0x919ef8: add             x1, PP, #0x81, lsl #12  ; [pp+0x81470] AnonymousClosure: (0x91a0b8), in [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey (0x919e9c)
    //     0x919efc: ldr             x1, [x1, #0x470]
    // 0x919f00: r0 = AllocateClosure()
    //     0x919f00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x919f04: mov             x4, x0
    // 0x919f08: ldur            x3, [fp, #-0x78]
    // 0x919f0c: stur            x4, [fp, #-0x68]
    // 0x919f10: StoreField: r3->field_23 = r4
    //     0x919f10: stur            w4, [x3, #0x23]
    // 0x919f14: ldur            x5, [fp, #-0x58]
    // 0x919f18: r0 = LoadClassIdInstr(r5)
    //     0x919f18: ldur            x0, [x5, #-1]
    //     0x919f1c: ubfx            x0, x0, #0xc, #0x14
    // 0x919f20: mov             x1, x5
    // 0x919f24: ldur            x2, [fp, #-0x60]
    // 0x919f28: r0 = GDT[cid_x0 + 0x5671]()
    //     0x919f28: mov             x17, #0x5671
    //     0x919f2c: add             lr, x0, x17
    //     0x919f30: ldr             lr, [x21, lr, lsl #3]
    //     0x919f34: blr             lr
    // 0x919f38: stur            x0, [fp, #-0x60]
    // 0x919f3c: ldur            x1, [fp, #-0x58]
    // 0x919f40: LoadField: r3 = r1->field_7
    //     0x919f40: ldur            w3, [x1, #7]
    // 0x919f44: DecompressPointer r3
    //     0x919f44: add             x3, x3, HEAP, lsl #32
    // 0x919f48: ldur            x2, [fp, #-0x78]
    // 0x919f4c: r1 = Function '<anonymous closure>':.
    //     0x919f4c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81478] AnonymousClosure: (0x919ff8), in [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey (0x919e9c)
    //     0x919f50: ldr             x1, [x1, #0x478]
    // 0x919f54: r0 = AllocateClosureTA()
    //     0x919f54: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x919f58: mov             x1, x0
    // 0x919f5c: ldur            x0, [fp, #-0x60]
    // 0x919f60: r2 = LoadClassIdInstr(r0)
    //     0x919f60: ldur            x2, [x0, #-1]
    //     0x919f64: ubfx            x2, x2, #0xc, #0x14
    // 0x919f68: r16 = <void?>
    //     0x919f68: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x919f6c: stp             x0, x16, [SP, #8]
    // 0x919f70: str             x1, [SP]
    // 0x919f74: mov             x0, x2
    // 0x919f78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x919f78: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x919f7c: r0 = GDT[cid_x0 + -0xfef]()
    //     0x919f7c: sub             lr, x0, #0xfef
    //     0x919f80: ldr             lr, [x21, lr, lsl #3]
    //     0x919f84: blr             lr
    // 0x919f88: r1 = LoadClassIdInstr(r0)
    //     0x919f88: ldur            x1, [x0, #-1]
    //     0x919f8c: ubfx            x1, x1, #0xc, #0x14
    // 0x919f90: mov             x16, x0
    // 0x919f94: mov             x0, x1
    // 0x919f98: mov             x1, x16
    // 0x919f9c: ldur            x2, [fp, #-0x68]
    // 0x919fa0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x919fa0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x919fa4: r0 = GDT[cid_x0 + -0xf47]()
    //     0x919fa4: sub             lr, x0, #0xf47
    //     0x919fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x919fac: blr             lr
    // 0x919fb0: r0 = Null
    //     0x919fb0: mov             x0, NULL
    // 0x919fb4: LeaveFrame
    //     0x919fb4: mov             SP, fp
    //     0x919fb8: ldp             fp, lr, [SP], #0x10
    // 0x919fbc: ret
    //     0x919fbc: ret             
    // 0x919fc0: sub             SP, fp, #0x90
    // 0x919fc4: ldur            x16, [fp, #-0x68]
    // 0x919fc8: stp             x0, x16, [SP, #8]
    // 0x919fcc: str             x1, [SP]
    // 0x919fd0: ldur            x0, [fp, #-0x68]
    // 0x919fd4: ClosureCall
    //     0x919fd4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x919fd8: ldur            x2, [x0, #0x1f]
    //     0x919fdc: blr             x2
    // 0x919fe0: r0 = Null
    //     0x919fe0: mov             x0, NULL
    // 0x919fe4: LeaveFrame
    //     0x919fe4: mov             SP, fp
    //     0x919fe8: ldp             fp, lr, [SP], #0x10
    // 0x919fec: ret
    //     0x919fec: ret             
    // 0x919ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x919ff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x919ff4: b               #0x919ec4
  }
  [closure] Null <anonymous closure>(dynamic, X0) {
    // ** addr: 0x919ff8, size: 0xc0
    // 0x919ff8: EnterFrame
    //     0x919ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x919ffc: mov             fp, SP
    // 0x91a000: AllocStack(0x70)
    //     0x91a000: sub             SP, SP, #0x70
    // 0x91a004: SetupParameters([dynamic _ /* r0 */])
    //     0x91a004: ldr             x0, [fp, #0x18]
    //     0x91a008: ldur            w1, [x0, #0x17]
    //     0x91a00c: add             x1, x1, HEAP, lsl #32
    //     0x91a010: stur            x1, [fp, #-0x58]
    // 0x91a014: CheckStackOverflow
    //     0x91a014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a018: cmp             SP, x16
    //     0x91a01c: b.ls            #0x91a0b0
    // 0x91a020: ldr             x0, [fp, #0x10]
    // 0x91a024: StoreField: r1->field_1b = r0
    //     0x91a024: stur            w0, [x1, #0x1b]
    //     0x91a028: tbz             w0, #0, #0x91a044
    //     0x91a02c: ldurb           w16, [x1, #-1]
    //     0x91a030: ldurb           w17, [x0, #-1]
    //     0x91a034: and             x16, x17, x16, lsr #2
    //     0x91a038: tst             x16, HEAP, lsr #32
    //     0x91a03c: b.eq            #0x91a044
    //     0x91a040: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91a044: LoadField: r2 = r1->field_13
    //     0x91a044: ldur            w2, [x1, #0x13]
    // 0x91a048: DecompressPointer r2
    //     0x91a048: add             x2, x2, HEAP, lsl #32
    // 0x91a04c: stur            x2, [fp, #-0x50]
    // 0x91a050: LoadField: r0 = r1->field_23
    //     0x91a050: ldur            w0, [x1, #0x23]
    // 0x91a054: DecompressPointer r0
    //     0x91a054: add             x0, x0, HEAP, lsl #32
    // 0x91a058: ldr             x16, [fp, #0x10]
    // 0x91a05c: stp             x16, x2, [SP, #8]
    // 0x91a060: str             x0, [SP]
    // 0x91a064: mov             x0, x2
    // 0x91a068: ClosureCall
    //     0x91a068: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x91a06c: ldur            x2, [x0, #0x1f]
    //     0x91a070: blr             x2
    // 0x91a074: b               #0x91a0a0
    // 0x91a078: sub             SP, fp, #0x70
    // 0x91a07c: ldur            x2, [fp, #-0x58]
    // 0x91a080: LoadField: r3 = r2->field_23
    //     0x91a080: ldur            w3, [x2, #0x23]
    // 0x91a084: DecompressPointer r3
    //     0x91a084: add             x3, x3, HEAP, lsl #32
    // 0x91a088: stp             x0, x3, [SP, #8]
    // 0x91a08c: str             x1, [SP]
    // 0x91a090: mov             x0, x3
    // 0x91a094: ClosureCall
    //     0x91a094: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x91a098: ldur            x2, [x0, #0x1f]
    //     0x91a09c: blr             x2
    // 0x91a0a0: r0 = Null
    //     0x91a0a0: mov             x0, NULL
    // 0x91a0a4: LeaveFrame
    //     0x91a0a4: mov             SP, fp
    //     0x91a0a8: ldp             fp, lr, [SP], #0x10
    // 0x91a0ac: ret
    //     0x91a0ac: ret             
    // 0x91a0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a0b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a0b4: b               #0x91a020
  }
  [closure] Future<void> handleError(dynamic, Object, StackTrace?) async {
    // ** addr: 0x91a0b8, size: 0xbc
    // 0x91a0b8: EnterFrame
    //     0x91a0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x91a0bc: mov             fp, SP
    // 0x91a0c0: AllocStack(0x40)
    //     0x91a0c0: sub             SP, SP, #0x40
    // 0x91a0c4: SetupParameters(ImageProvider<X0> this /* r1 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x91a0c4: stur            NULL, [fp, #-8]
    //     0x91a0c8: mov             x0, #0
    //     0x91a0cc: add             x1, fp, w0, sxtw #2
    //     0x91a0d0: ldr             x1, [x1, #0x20]
    //     0x91a0d4: add             x2, fp, w0, sxtw #2
    //     0x91a0d8: ldr             x2, [x2, #0x18]
    //     0x91a0dc: stur            x2, [fp, #-0x20]
    //     0x91a0e0: add             x3, fp, w0, sxtw #2
    //     0x91a0e4: ldr             x3, [x3, #0x10]
    //     0x91a0e8: stur            x3, [fp, #-0x18]
    //     0x91a0ec: ldur            w4, [x1, #0x17]
    //     0x91a0f0: add             x4, x4, HEAP, lsl #32
    //     0x91a0f4: stur            x4, [fp, #-0x10]
    // 0x91a0f8: CheckStackOverflow
    //     0x91a0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a0fc: cmp             SP, x16
    //     0x91a100: b.ls            #0x91a16c
    // 0x91a104: InitAsync() -> Future<void?>
    //     0x91a104: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x91a108: bl              #0x7f5e44  ; InitAsyncStub
    // 0x91a10c: ldur            x1, [fp, #-0x10]
    // 0x91a110: LoadField: r0 = r1->field_1f
    //     0x91a110: ldur            w0, [x1, #0x1f]
    // 0x91a114: DecompressPointer r0
    //     0x91a114: add             x0, x0, HEAP, lsl #32
    // 0x91a118: tbnz            w0, #4, #0x91a124
    // 0x91a11c: r0 = Null
    //     0x91a11c: mov             x0, NULL
    // 0x91a120: r0 = ReturnAsyncNotFuture()
    //     0x91a120: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x91a124: r0 = true
    //     0x91a124: add             x0, NULL, #0x20  ; true
    // 0x91a128: StoreField: r1->field_1f = r0
    //     0x91a128: stur            w0, [x1, #0x1f]
    // 0x91a12c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x91a12c: ldur            w0, [x1, #0x17]
    // 0x91a130: DecompressPointer r0
    //     0x91a130: add             x0, x0, HEAP, lsl #32
    // 0x91a134: LoadField: r2 = r1->field_1b
    //     0x91a134: ldur            w2, [x1, #0x1b]
    // 0x91a138: DecompressPointer r2
    //     0x91a138: add             x2, x2, HEAP, lsl #32
    // 0x91a13c: stp             x2, x0, [SP, #0x10]
    // 0x91a140: ldur            x16, [fp, #-0x20]
    // 0x91a144: ldur            lr, [fp, #-0x18]
    // 0x91a148: stp             lr, x16, [SP]
    // 0x91a14c: ClosureCall
    //     0x91a14c: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x91a150: ldur            x2, [x0, #0x1f]
    //     0x91a154: blr             x2
    // 0x91a158: mov             x1, x0
    // 0x91a15c: stur            x1, [fp, #-0x18]
    // 0x91a160: r0 = Await()
    //     0x91a160: bl              #0x7f5c00  ; AwaitStub
    // 0x91a164: r0 = Null
    //     0x91a164: mov             x0, NULL
    // 0x91a168: r0 = ReturnAsyncNotFuture()
    //     0x91a168: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x91a16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a170: b               #0x91a104
  }
  _ createStream(/* No info */) {
    // ** addr: 0x91a174, size: 0x18
    // 0x91a174: EnterFrame
    //     0x91a174: stp             fp, lr, [SP, #-0x10]!
    //     0x91a178: mov             fp, SP
    // 0x91a17c: r0 = ImageStream()
    //     0x91a17c: bl              #0x91a18c  ; AllocateImageStreamStub -> ImageStream (size=0x10)
    // 0x91a180: LeaveFrame
    //     0x91a180: mov             SP, fp
    //     0x91a184: ldp             fp, lr, [SP], #0x10
    // 0x91a188: ret
    //     0x91a188: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic, X0?, Object, StackTrace?) async {
    // ** addr: 0x91a198, size: 0x108
    // 0x91a198: EnterFrame
    //     0x91a198: stp             fp, lr, [SP, #-0x10]!
    //     0x91a19c: mov             fp, SP
    // 0x91a1a0: AllocStack(0x38)
    //     0x91a1a0: sub             SP, SP, #0x38
    // 0x91a1a4: SetupParameters(ImageProvider<X0> this /* r1 */, dynamic _ /* r3, fp-0x20 */, dynamic _ /* r5, fp-0x18 */)
    //     0x91a1a4: stur            NULL, [fp, #-8]
    //     0x91a1a8: mov             x0, #0
    //     0x91a1ac: add             x1, fp, w0, sxtw #2
    //     0x91a1b0: ldr             x1, [x1, #0x28]
    //     0x91a1b4: add             x3, fp, w0, sxtw #2
    //     0x91a1b8: ldr             x3, [x3, #0x18]
    //     0x91a1bc: stur            x3, [fp, #-0x20]
    //     0x91a1c0: add             x5, fp, w0, sxtw #2
    //     0x91a1c4: ldr             x5, [x5, #0x10]
    //     0x91a1c8: stur            x5, [fp, #-0x18]
    //     0x91a1cc: ldur            w2, [x1, #0x17]
    //     0x91a1d0: add             x2, x2, HEAP, lsl #32
    //     0x91a1d4: stur            x2, [fp, #-0x10]
    // 0x91a1d8: CheckStackOverflow
    //     0x91a1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a1dc: cmp             SP, x16
    //     0x91a1e0: b.ls            #0x91a294
    // 0x91a1e4: InitAsync() -> Future<void?>
    //     0x91a1e4: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x91a1e8: bl              #0x7f5e44  ; InitAsyncStub
    // 0x91a1ec: r0 = Null
    //     0x91a1ec: mov             x0, NULL
    // 0x91a1f0: r0 = Await()
    //     0x91a1f0: bl              #0x7f5c00  ; AwaitStub
    // 0x91a1f4: ldur            x0, [fp, #-0x10]
    // 0x91a1f8: LoadField: r1 = r0->field_13
    //     0x91a1f8: ldur            w1, [x0, #0x13]
    // 0x91a1fc: DecompressPointer r1
    //     0x91a1fc: add             x1, x1, HEAP, lsl #32
    // 0x91a200: stur            x1, [fp, #-0x28]
    // 0x91a204: LoadField: r0 = r1->field_7
    //     0x91a204: ldur            w0, [x1, #7]
    // 0x91a208: DecompressPointer r0
    //     0x91a208: add             x0, x0, HEAP, lsl #32
    // 0x91a20c: cmp             w0, NULL
    // 0x91a210: b.ne            #0x91a230
    // 0x91a214: r0 = _ErrorImageCompleter()
    //     0x91a214: bl              #0x91ab28  ; Allocate_ErrorImageCompleterStub -> _ErrorImageCompleter (size=0x30)
    // 0x91a218: mov             x1, x0
    // 0x91a21c: stur            x0, [fp, #-0x10]
    // 0x91a220: r0 = ImageStreamCompleter()
    //     0x91a220: bl              #0x91aa54  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0x91a224: ldur            x1, [fp, #-0x28]
    // 0x91a228: ldur            x2, [fp, #-0x10]
    // 0x91a22c: r0 = setCompleter()
    //     0x91a22c: bl              #0x91a7dc  ; [package:flutter/src/painting/image_stream.dart] ImageStream::setCompleter
    // 0x91a230: ldur            x0, [fp, #-0x28]
    // 0x91a234: LoadField: r2 = r0->field_7
    //     0x91a234: ldur            w2, [x0, #7]
    // 0x91a238: DecompressPointer r2
    //     0x91a238: add             x2, x2, HEAP, lsl #32
    // 0x91a23c: stur            x2, [fp, #-0x10]
    // 0x91a240: cmp             w2, NULL
    // 0x91a244: b.eq            #0x91a29c
    // 0x91a248: r1 = <List<Object>>
    //     0x91a248: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x91a24c: r0 = ErrorDescription()
    //     0x91a24c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x91a250: mov             x1, x0
    // 0x91a254: r2 = "while resolving an image"
    //     0x91a254: add             x2, PP, #0x81, lsl #12  ; [pp+0x81328] "while resolving an image"
    //     0x91a258: ldr             x2, [x2, #0x328]
    // 0x91a25c: r3 = Instance_DiagnosticLevel
    //     0x91a25c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x91a260: stur            x0, [fp, #-0x28]
    // 0x91a264: r0 = _ErrorDiagnostic()
    //     0x91a264: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x91a268: r16 = true
    //     0x91a268: add             x16, NULL, #0x20  ; true
    // 0x91a26c: stp             NULL, x16, [SP]
    // 0x91a270: ldur            x1, [fp, #-0x10]
    // 0x91a274: ldur            x2, [fp, #-0x28]
    // 0x91a278: ldur            x3, [fp, #-0x20]
    // 0x91a27c: ldur            x5, [fp, #-0x18]
    // 0x91a280: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x5, silent, 0x4, null]
    //     0x91a280: add             x4, PP, #0x81, lsl #12  ; [pp+0x81330] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x5, "silent", 0x4, Null]
    //     0x91a284: ldr             x4, [x4, #0x330]
    // 0x91a288: r0 = reportError()
    //     0x91a288: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0x91a28c: r0 = Null
    //     0x91a28c: mov             x0, NULL
    // 0x91a290: r0 = ReturnAsyncNotFuture()
    //     0x91a290: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x91a294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a298: b               #0x91a1e4
    // 0x91a29c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a29c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, X0, (dynamic, Object, StackTrace?) => void) {
    // ** addr: 0x91ab34, size: 0x74
    // 0x91ab34: EnterFrame
    //     0x91ab34: stp             fp, lr, [SP, #-0x10]!
    //     0x91ab38: mov             fp, SP
    // 0x91ab3c: ldr             x0, [fp, #0x20]
    // 0x91ab40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91ab40: ldur            w1, [x0, #0x17]
    // 0x91ab44: DecompressPointer r1
    //     0x91ab44: add             x1, x1, HEAP, lsl #32
    // 0x91ab48: CheckStackOverflow
    //     0x91ab48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91ab4c: cmp             SP, x16
    //     0x91ab50: b.ls            #0x91aba0
    // 0x91ab54: LoadField: r0 = r1->field_f
    //     0x91ab54: ldur            w0, [x1, #0xf]
    // 0x91ab58: DecompressPointer r0
    //     0x91ab58: add             x0, x0, HEAP, lsl #32
    // 0x91ab5c: LoadField: r2 = r1->field_13
    //     0x91ab5c: ldur            w2, [x1, #0x13]
    // 0x91ab60: DecompressPointer r2
    //     0x91ab60: add             x2, x2, HEAP, lsl #32
    // 0x91ab64: r1 = LoadClassIdInstr(r0)
    //     0x91ab64: ldur            x1, [x0, #-1]
    //     0x91ab68: ubfx            x1, x1, #0xc, #0x14
    // 0x91ab6c: mov             x16, x0
    // 0x91ab70: mov             x0, x1
    // 0x91ab74: mov             x1, x16
    // 0x91ab78: ldr             x3, [fp, #0x18]
    // 0x91ab7c: ldr             x5, [fp, #0x10]
    // 0x91ab80: r0 = GDT[cid_x0 + 0x4669]()
    //     0x91ab80: mov             x17, #0x4669
    //     0x91ab84: add             lr, x0, x17
    //     0x91ab88: ldr             lr, [x21, lr, lsl #3]
    //     0x91ab8c: blr             lr
    // 0x91ab90: r0 = Null
    //     0x91ab90: mov             x0, NULL
    // 0x91ab94: LeaveFrame
    //     0x91ab94: mov             SP, fp
    //     0x91ab98: ldp             fp, lr, [SP], #0x10
    // 0x91ab9c: ret
    //     0x91ab9c: ret             
    // 0x91aba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91aba0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91aba4: b               #0x91ab54
  }
  _ resolveStreamForKey(/* No info */) {
    // ** addr: 0x116dacc, size: 0x1b4
    // 0x116dacc: EnterFrame
    //     0x116dacc: stp             fp, lr, [SP, #-0x10]!
    //     0x116dad0: mov             fp, SP
    // 0x116dad4: AllocStack(0x30)
    //     0x116dad4: sub             SP, SP, #0x30
    // 0x116dad8: SetupParameters(ImageProvider<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x116dad8: mov             x0, x3
    //     0x116dadc: stur            x1, [fp, #-8]
    //     0x116dae0: stur            x2, [fp, #-0x10]
    //     0x116dae4: stur            x3, [fp, #-0x18]
    //     0x116dae8: stur            x5, [fp, #-0x20]
    // 0x116daec: CheckStackOverflow
    //     0x116daec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116daf0: cmp             SP, x16
    //     0x116daf4: b.ls            #0x116dc64
    // 0x116daf8: r1 = 3
    //     0x116daf8: mov             x1, #3
    // 0x116dafc: r0 = AllocateContext()
    //     0x116dafc: bl              #0x13de838  ; AllocateContextStub
    // 0x116db00: mov             x3, x0
    // 0x116db04: ldur            x0, [fp, #-8]
    // 0x116db08: stur            x3, [fp, #-0x28]
    // 0x116db0c: StoreField: r3->field_f = r0
    //     0x116db0c: stur            w0, [x3, #0xf]
    // 0x116db10: ldur            x4, [fp, #-0x10]
    // 0x116db14: StoreField: r3->field_13 = r4
    //     0x116db14: stur            w4, [x3, #0x13]
    // 0x116db18: ldur            x5, [fp, #-0x18]
    // 0x116db1c: ArrayStore: r3[0] = r5  ; List_4
    //     0x116db1c: stur            w5, [x3, #0x17]
    // 0x116db20: LoadField: r2 = r0->field_7
    //     0x116db20: ldur            w2, [x0, #7]
    // 0x116db24: DecompressPointer r2
    //     0x116db24: add             x2, x2, HEAP, lsl #32
    // 0x116db28: mov             x0, x5
    // 0x116db2c: r1 = Null
    //     0x116db2c: mov             x1, NULL
    // 0x116db30: cmp             w2, NULL
    // 0x116db34: b.eq            #0x116db58
    // 0x116db38: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x116db38: ldur            w4, [x2, #0x17]
    // 0x116db3c: DecompressPointer r4
    //     0x116db3c: add             x4, x4, HEAP, lsl #32
    // 0x116db40: r8 = X0
    //     0x116db40: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d238] TypeParameter: X0
    //     0x116db44: ldr             x8, [x8, #0x238]
    // 0x116db48: LoadField: r9 = r4->field_7
    //     0x116db48: ldur            x9, [x4, #7]
    // 0x116db4c: r3 = Null
    //     0x116db4c: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d240] Null
    //     0x116db50: ldr             x3, [x3, #0x240]
    // 0x116db54: blr             x9
    // 0x116db58: ldur            x0, [fp, #-0x10]
    // 0x116db5c: LoadField: r1 = r0->field_7
    //     0x116db5c: ldur            w1, [x0, #7]
    // 0x116db60: DecompressPointer r1
    //     0x116db60: add             x1, x1, HEAP, lsl #32
    // 0x116db64: cmp             w1, NULL
    // 0x116db68: b.eq            #0x116dbd4
    // 0x116db6c: r0 = LoadStaticField(0x780)
    //     0x116db6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x116db70: ldr             x0, [x0, #0xf00]
    // 0x116db74: cmp             w0, NULL
    // 0x116db78: b.eq            #0x116dc6c
    // 0x116db7c: LoadField: r3 = r0->field_ab
    //     0x116db7c: ldur            w3, [x0, #0xab]
    // 0x116db80: DecompressPointer r3
    //     0x116db80: add             x3, x3, HEAP, lsl #32
    // 0x116db84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x116db88: cmp             w3, w16
    // 0x116db8c: b.eq            #0x116dc70
    // 0x116db90: ldur            x2, [fp, #-0x28]
    // 0x116db94: stur            x3, [fp, #-8]
    // 0x116db98: r1 = Function '<anonymous closure>':.
    //     0x116db98: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d250] AnonymousClosure: (0x116dd90), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolveStreamForKey (0x116dacc)
    //     0x116db9c: ldr             x1, [x1, #0x250]
    // 0x116dba0: r0 = AllocateClosure()
    //     0x116dba0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116dba4: ldur            x16, [fp, #-0x20]
    // 0x116dba8: str             x16, [SP]
    // 0x116dbac: ldur            x1, [fp, #-8]
    // 0x116dbb0: ldur            x2, [fp, #-0x18]
    // 0x116dbb4: mov             x3, x0
    // 0x116dbb8: r4 = const [0, 0x4, 0x1, 0x3, onError, 0x3, null]
    //     0x116dbb8: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d258] List(7) [0, 0x4, 0x1, 0x3, "onError", 0x3, Null]
    //     0x116dbbc: ldr             x4, [x4, #0x258]
    // 0x116dbc0: r0 = putIfAbsent()
    //     0x116dbc0: bl              #0xf2f9e8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent
    // 0x116dbc4: r0 = Null
    //     0x116dbc4: mov             x0, NULL
    // 0x116dbc8: LeaveFrame
    //     0x116dbc8: mov             SP, fp
    //     0x116dbcc: ldp             fp, lr, [SP], #0x10
    // 0x116dbd0: ret
    //     0x116dbd0: ret             
    // 0x116dbd4: ldur            x2, [fp, #-0x28]
    // 0x116dbd8: r0 = instance()
    //     0x116dbd8: bl              #0xc06878  ; [package:flutter/src/painting/binding.dart] PaintingBinding::instance
    // 0x116dbdc: LoadField: r3 = r0->field_ab
    //     0x116dbdc: ldur            w3, [x0, #0xab]
    // 0x116dbe0: DecompressPointer r3
    //     0x116dbe0: add             x3, x3, HEAP, lsl #32
    // 0x116dbe4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x116dbe8: cmp             w3, w16
    // 0x116dbec: b.eq            #0x116dc78
    // 0x116dbf0: ldur            x0, [fp, #-0x28]
    // 0x116dbf4: stur            x3, [fp, #-0x10]
    // 0x116dbf8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x116dbf8: ldur            w4, [x0, #0x17]
    // 0x116dbfc: DecompressPointer r4
    //     0x116dbfc: add             x4, x4, HEAP, lsl #32
    // 0x116dc00: mov             x2, x0
    // 0x116dc04: stur            x4, [fp, #-8]
    // 0x116dc08: r1 = Function '<anonymous closure>':.
    //     0x116dc08: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d260] AnonymousClosure: (0x116dc80), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolveStreamForKey (0x116dacc)
    //     0x116dc0c: ldr             x1, [x1, #0x260]
    // 0x116dc10: r0 = AllocateClosure()
    //     0x116dc10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116dc14: ldur            x16, [fp, #-0x20]
    // 0x116dc18: str             x16, [SP]
    // 0x116dc1c: ldur            x1, [fp, #-0x10]
    // 0x116dc20: ldur            x2, [fp, #-8]
    // 0x116dc24: mov             x3, x0
    // 0x116dc28: r4 = const [0, 0x4, 0x1, 0x3, onError, 0x3, null]
    //     0x116dc28: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d258] List(7) [0, 0x4, 0x1, 0x3, "onError", 0x3, Null]
    //     0x116dc2c: ldr             x4, [x4, #0x258]
    // 0x116dc30: r0 = putIfAbsent()
    //     0x116dc30: bl              #0xf2f9e8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent
    // 0x116dc34: cmp             w0, NULL
    // 0x116dc38: b.eq            #0x116dc54
    // 0x116dc3c: ldur            x1, [fp, #-0x28]
    // 0x116dc40: LoadField: r2 = r1->field_13
    //     0x116dc40: ldur            w2, [x1, #0x13]
    // 0x116dc44: DecompressPointer r2
    //     0x116dc44: add             x2, x2, HEAP, lsl #32
    // 0x116dc48: mov             x1, x2
    // 0x116dc4c: mov             x2, x0
    // 0x116dc50: r0 = setCompleter()
    //     0x116dc50: bl              #0x91a7dc  ; [package:flutter/src/painting/image_stream.dart] ImageStream::setCompleter
    // 0x116dc54: r0 = Null
    //     0x116dc54: mov             x0, NULL
    // 0x116dc58: LeaveFrame
    //     0x116dc58: mov             SP, fp
    //     0x116dc5c: ldp             fp, lr, [SP], #0x10
    // 0x116dc60: ret
    //     0x116dc60: ret             
    // 0x116dc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116dc64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116dc68: b               #0x116daf8
    // 0x116dc6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116dc6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x116dc70: r9 = _imageCache
    //     0x116dc70: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x116dc74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x116dc74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x116dc78: r9 = _imageCache
    //     0x116dc78: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x116dc7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x116dc7c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] ImageStreamCompleter <anonymous closure>(dynamic) {
    // ** addr: 0x116dc80, size: 0x98
    // 0x116dc80: EnterFrame
    //     0x116dc80: stp             fp, lr, [SP, #-0x10]!
    //     0x116dc84: mov             fp, SP
    // 0x116dc88: AllocStack(0x10)
    //     0x116dc88: sub             SP, SP, #0x10
    // 0x116dc8c: SetupParameters([dynamic _ /* r0 */])
    //     0x116dc8c: ldr             x0, [fp, #0x10]
    //     0x116dc90: ldur            w1, [x0, #0x17]
    //     0x116dc94: add             x1, x1, HEAP, lsl #32
    // 0x116dc98: CheckStackOverflow
    //     0x116dc98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116dc9c: cmp             SP, x16
    //     0x116dca0: b.ls            #0x116dd0c
    // 0x116dca4: LoadField: r0 = r1->field_f
    //     0x116dca4: ldur            w0, [x1, #0xf]
    // 0x116dca8: DecompressPointer r0
    //     0x116dca8: add             x0, x0, HEAP, lsl #32
    // 0x116dcac: stur            x0, [fp, #-0x10]
    // 0x116dcb0: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x116dcb0: ldur            w3, [x1, #0x17]
    // 0x116dcb4: DecompressPointer r3
    //     0x116dcb4: add             x3, x3, HEAP, lsl #32
    // 0x116dcb8: stur            x3, [fp, #-8]
    // 0x116dcbc: r2 = LoadStaticField(0x780)
    //     0x116dcbc: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x116dcc0: ldr             x2, [x2, #0xf00]
    // 0x116dcc4: cmp             w2, NULL
    // 0x116dcc8: b.eq            #0x116dd14
    // 0x116dccc: r1 = Function 'instantiateImageCodecWithSize':.
    //     0x116dccc: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d268] AnonymousClosure: (0x116dd18), of [dart:mixin_deduplication] _MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding
    //     0x116dcd0: ldr             x1, [x1, #0x268]
    // 0x116dcd4: r0 = AllocateClosure()
    //     0x116dcd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116dcd8: ldur            x1, [fp, #-0x10]
    // 0x116dcdc: r2 = LoadClassIdInstr(r1)
    //     0x116dcdc: ldur            x2, [x1, #-1]
    //     0x116dce0: ubfx            x2, x2, #0xc, #0x14
    // 0x116dce4: mov             x3, x0
    // 0x116dce8: mov             x0, x2
    // 0x116dcec: ldur            x2, [fp, #-8]
    // 0x116dcf0: r0 = GDT[cid_x0 + 0x332d]()
    //     0x116dcf0: mov             x17, #0x332d
    //     0x116dcf4: add             lr, x0, x17
    //     0x116dcf8: ldr             lr, [x21, lr, lsl #3]
    //     0x116dcfc: blr             lr
    // 0x116dd00: LeaveFrame
    //     0x116dd00: mov             SP, fp
    //     0x116dd04: ldp             fp, lr, [SP], #0x10
    // 0x116dd08: ret
    //     0x116dd08: ret             
    // 0x116dd0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116dd0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116dd10: b               #0x116dca4
    // 0x116dd14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116dd14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ImageStreamCompleter <anonymous closure>(dynamic) {
    // ** addr: 0x116dd90, size: 0x34
    // 0x116dd90: ldr             x1, [SP]
    // 0x116dd94: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x116dd94: ldur            w2, [x1, #0x17]
    // 0x116dd98: DecompressPointer r2
    //     0x116dd98: add             x2, x2, HEAP, lsl #32
    // 0x116dd9c: LoadField: r1 = r2->field_13
    //     0x116dd9c: ldur            w1, [x2, #0x13]
    // 0x116dda0: DecompressPointer r1
    //     0x116dda0: add             x1, x1, HEAP, lsl #32
    // 0x116dda4: LoadField: r0 = r1->field_7
    //     0x116dda4: ldur            w0, [x1, #7]
    // 0x116dda8: DecompressPointer r0
    //     0x116dda8: add             x0, x0, HEAP, lsl #32
    // 0x116ddac: cmp             w0, NULL
    // 0x116ddb0: b.eq            #0x116ddb8
    // 0x116ddb4: ret
    //     0x116ddb4: ret             
    // 0x116ddb8: EnterFrame
    //     0x116ddb8: stp             fp, lr, [SP, #-0x10]!
    //     0x116ddbc: mov             fp, SP
    // 0x116ddc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116ddc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3595, size: 0x18, field offset: 0xc
//   const constructor, 
class MemoryImage extends ImageProvider<dynamic> {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1149478, size: 0x7c
    // 0x1149478: EnterFrame
    //     0x1149478: stp             fp, lr, [SP, #-0x10]!
    //     0x114947c: mov             fp, SP
    // 0x1149480: AllocStack(0x8)
    //     0x1149480: sub             SP, SP, #8
    // 0x1149484: CheckStackOverflow
    //     0x1149484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149488: cmp             SP, x16
    //     0x114948c: b.ls            #0x11494ec
    // 0x1149490: ldr             x0, [fp, #0x10]
    // 0x1149494: LoadField: r1 = r0->field_b
    //     0x1149494: ldur            w1, [x0, #0xb]
    // 0x1149498: DecompressPointer r1
    //     0x1149498: add             x1, x1, HEAP, lsl #32
    // 0x114949c: r0 = LoadClassIdInstr(r1)
    //     0x114949c: ldur            x0, [x1, #-1]
    //     0x11494a0: ubfx            x0, x0, #0xc, #0x14
    // 0x11494a4: str             x1, [SP]
    // 0x11494a8: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11494a8: mov             x17, #0x70de
    //     0x11494ac: add             lr, x0, x17
    //     0x11494b0: ldr             lr, [x21, lr, lsl #3]
    //     0x11494b4: blr             lr
    // 0x11494b8: mov             x1, x0
    // 0x11494bc: r2 = 1.000000
    //     0x11494bc: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x11494c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11494c0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11494c4: r0 = hash()
    //     0x11494c4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11494c8: mov             x2, x0
    // 0x11494cc: r0 = BoxInt64Instr(r2)
    //     0x11494cc: sbfiz           x0, x2, #1, #0x1f
    //     0x11494d0: cmp             x2, x0, asr #1
    //     0x11494d4: b.eq            #0x11494e0
    //     0x11494d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11494dc: stur            x2, [x0, #7]
    // 0x11494e0: LeaveFrame
    //     0x11494e0: mov             SP, fp
    //     0x11494e4: ldp             fp, lr, [SP], #0x10
    // 0x11494e8: ret
    //     0x11494e8: ret             
    // 0x11494ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11494ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11494f0: b               #0x1149490
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0x115befc, size: 0x34
    // 0x115befc: EnterFrame
    //     0x115befc: stp             fp, lr, [SP, #-0x10]!
    //     0x115bf00: mov             fp, SP
    // 0x115bf04: AllocStack(0x8)
    //     0x115bf04: sub             SP, SP, #8
    // 0x115bf08: SetupParameters(MemoryImage this /* r1 => r0, fp-0x8 */)
    //     0x115bf08: mov             x0, x1
    //     0x115bf0c: stur            x1, [fp, #-8]
    // 0x115bf10: r1 = <MemoryImage>
    //     0x115bf10: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b2d0] TypeArguments: <MemoryImage>
    //     0x115bf14: ldr             x1, [x1, #0x2d0]
    // 0x115bf18: r0 = SynchronousFuture()
    //     0x115bf18: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x115bf1c: ldur            x1, [fp, #-8]
    // 0x115bf20: StoreField: r0->field_b = r1
    //     0x115bf20: stur            w1, [x0, #0xb]
    // 0x115bf24: LeaveFrame
    //     0x115bf24: mov             SP, fp
    //     0x115bf28: ldp             fp, lr, [SP], #0x10
    // 0x115bf2c: ret
    //     0x115bf2c: ret             
  }
  _ loadImage(/* No info */) {
    // ** addr: 0x1192ec4, size: 0xd4
    // 0x1192ec4: EnterFrame
    //     0x1192ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x1192ec8: mov             fp, SP
    // 0x1192ecc: AllocStack(0x20)
    //     0x1192ecc: sub             SP, SP, #0x20
    // 0x1192ed0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2 */)
    //     0x1192ed0: mov             x0, x2
    //     0x1192ed4: stur            x2, [fp, #-8]
    //     0x1192ed8: mov             x2, x3
    // 0x1192edc: CheckStackOverflow
    //     0x1192edc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192ee0: cmp             SP, x16
    //     0x1192ee4: b.ls            #0x1192f90
    // 0x1192ee8: r0 = _loadAsync()
    //     0x1192ee8: bl              #0x1192f98  ; [package:flutter/src/painting/image_provider.dart] MemoryImage::_loadAsync
    // 0x1192eec: r1 = Null
    //     0x1192eec: mov             x1, NULL
    // 0x1192ef0: r2 = 6
    //     0x1192ef0: mov             x2, #6
    // 0x1192ef4: stur            x0, [fp, #-0x10]
    // 0x1192ef8: r0 = AllocateArray()
    //     0x1192ef8: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192efc: stur            x0, [fp, #-0x18]
    // 0x1192f00: r16 = "MemoryImage("
    //     0x1192f00: add             x16, PP, #0x97, lsl #12  ; [pp+0x977b8] "MemoryImage("
    //     0x1192f04: ldr             x16, [x16, #0x7b8]
    // 0x1192f08: StoreField: r0->field_f = r16
    //     0x1192f08: stur            w16, [x0, #0xf]
    // 0x1192f0c: ldur            x1, [fp, #-8]
    // 0x1192f10: LoadField: r2 = r1->field_b
    //     0x1192f10: ldur            w2, [x1, #0xb]
    // 0x1192f14: DecompressPointer r2
    //     0x1192f14: add             x2, x2, HEAP, lsl #32
    // 0x1192f18: mov             x1, x2
    // 0x1192f1c: r0 = describeIdentity()
    //     0x1192f1c: bl              #0x1115914  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0x1192f20: ldur            x1, [fp, #-0x18]
    // 0x1192f24: ArrayStore: r1[1] = r0  ; List_4
    //     0x1192f24: add             x25, x1, #0x13
    //     0x1192f28: str             w0, [x25]
    //     0x1192f2c: tbz             w0, #0, #0x1192f48
    //     0x1192f30: ldurb           w16, [x1, #-1]
    //     0x1192f34: ldurb           w17, [x0, #-1]
    //     0x1192f38: and             x16, x17, x16, lsr #2
    //     0x1192f3c: tst             x16, HEAP, lsr #32
    //     0x1192f40: b.eq            #0x1192f48
    //     0x1192f44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1192f48: ldur            x0, [fp, #-0x18]
    // 0x1192f4c: r16 = ")"
    //     0x1192f4c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1192f50: ArrayStore: r0[0] = r16  ; List_4
    //     0x1192f50: stur            w16, [x0, #0x17]
    // 0x1192f54: str             x0, [SP]
    // 0x1192f58: r0 = _interpolate()
    //     0x1192f58: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1192f5c: stur            x0, [fp, #-8]
    // 0x1192f60: r0 = MultiFrameImageStreamCompleter()
    //     0x1192f60: bl              #0x1191a44  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0x1192f64: mov             x1, x0
    // 0x1192f68: ldur            x2, [fp, #-0x10]
    // 0x1192f6c: ldur            x3, [fp, #-8]
    // 0x1192f70: d0 = 1.000000
    //     0x1192f70: fmov            d0, #1.00000000
    // 0x1192f74: stur            x0, [fp, #-8]
    // 0x1192f78: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x1192f78: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x1192f7c: r0 = MultiFrameImageStreamCompleter()
    //     0x1192f7c: bl              #0x11864e8  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0x1192f80: ldur            x0, [fp, #-8]
    // 0x1192f84: LeaveFrame
    //     0x1192f84: mov             SP, fp
    //     0x1192f88: ldp             fp, lr, [SP], #0x10
    // 0x1192f8c: ret
    //     0x1192f8c: ret             
    // 0x1192f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192f90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192f94: b               #0x1192ee8
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0x1192f98, size: 0x64
    // 0x1192f98: EnterFrame
    //     0x1192f98: stp             fp, lr, [SP, #-0x10]!
    //     0x1192f9c: mov             fp, SP
    // 0x1192fa0: AllocStack(0x18)
    //     0x1192fa0: sub             SP, SP, #0x18
    // 0x1192fa4: SetupParameters(MemoryImage this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x1192fa4: stur            NULL, [fp, #-8]
    //     0x1192fa8: stur            x1, [fp, #-0x10]
    //     0x1192fac: stur            x2, [fp, #-0x18]
    // 0x1192fb0: CheckStackOverflow
    //     0x1192fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192fb4: cmp             SP, x16
    //     0x1192fb8: b.ls            #0x1192ff4
    // 0x1192fbc: InitAsync() -> Future<Codec>
    //     0x1192fbc: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1192fc0: ldr             x0, [x0, #0x278]
    //     0x1192fc4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1192fc8: ldur            x0, [fp, #-0x10]
    // 0x1192fcc: LoadField: r1 = r0->field_b
    //     0x1192fcc: ldur            w1, [x0, #0xb]
    // 0x1192fd0: DecompressPointer r1
    //     0x1192fd0: add             x1, x1, HEAP, lsl #32
    // 0x1192fd4: r0 = fromUint8List()
    //     0x1192fd4: bl              #0xce7b70  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0x1192fd8: mov             x1, x0
    // 0x1192fdc: stur            x1, [fp, #-0x10]
    // 0x1192fe0: r0 = Await()
    //     0x1192fe0: bl              #0x7f5c00  ; AwaitStub
    // 0x1192fe4: mov             x1, x0
    // 0x1192fe8: r2 = Null
    //     0x1192fe8: mov             x2, NULL
    // 0x1192fec: r0 = instantiateImageCodecWithSize()
    //     0x1192fec: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x1192ff0: r0 = ReturnAsync()
    //     0x1192ff0: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x1192ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192ff4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192ff8: b               #0x1192fbc
  }
  _ ==(/* No info */) {
    // ** addr: 0x1292570, size: 0xe0
    // 0x1292570: EnterFrame
    //     0x1292570: stp             fp, lr, [SP, #-0x10]!
    //     0x1292574: mov             fp, SP
    // 0x1292578: AllocStack(0x10)
    //     0x1292578: sub             SP, SP, #0x10
    // 0x129257c: CheckStackOverflow
    //     0x129257c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292580: cmp             SP, x16
    //     0x1292584: b.ls            #0x1292648
    // 0x1292588: ldr             x0, [fp, #0x10]
    // 0x129258c: cmp             w0, NULL
    // 0x1292590: b.ne            #0x12925a4
    // 0x1292594: r0 = false
    //     0x1292594: add             x0, NULL, #0x30  ; false
    // 0x1292598: LeaveFrame
    //     0x1292598: mov             SP, fp
    //     0x129259c: ldp             fp, lr, [SP], #0x10
    // 0x12925a0: ret
    //     0x12925a0: ret             
    // 0x12925a4: str             x0, [SP]
    // 0x12925a8: r0 = runtimeType()
    //     0x12925a8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12925ac: r1 = LoadClassIdInstr(r0)
    //     0x12925ac: ldur            x1, [x0, #-1]
    //     0x12925b0: ubfx            x1, x1, #0xc, #0x14
    // 0x12925b4: r16 = MemoryImage
    //     0x12925b4: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d230] Type: MemoryImage
    //     0x12925b8: ldr             x16, [x16, #0x230]
    // 0x12925bc: stp             x16, x0, [SP]
    // 0x12925c0: mov             x0, x1
    // 0x12925c4: mov             lr, x0
    // 0x12925c8: ldr             lr, [x21, lr, lsl #3]
    // 0x12925cc: blr             lr
    // 0x12925d0: tbz             w0, #4, #0x12925e4
    // 0x12925d4: r0 = false
    //     0x12925d4: add             x0, NULL, #0x30  ; false
    // 0x12925d8: LeaveFrame
    //     0x12925d8: mov             SP, fp
    //     0x12925dc: ldp             fp, lr, [SP], #0x10
    // 0x12925e0: ret
    //     0x12925e0: ret             
    // 0x12925e4: ldr             x1, [fp, #0x10]
    // 0x12925e8: r2 = 60
    //     0x12925e8: mov             x2, #0x3c
    // 0x12925ec: branchIfSmi(r1, 0x12925f8)
    //     0x12925ec: tbz             w1, #0, #0x12925f8
    // 0x12925f0: r2 = LoadClassIdInstr(r1)
    //     0x12925f0: ldur            x2, [x1, #-1]
    //     0x12925f4: ubfx            x2, x2, #0xc, #0x14
    // 0x12925f8: cmp             x2, #0xe0b
    // 0x12925fc: b.ne            #0x1292638
    // 0x1292600: ldr             x2, [fp, #0x18]
    // 0x1292604: LoadField: r3 = r1->field_b
    //     0x1292604: ldur            w3, [x1, #0xb]
    // 0x1292608: DecompressPointer r3
    //     0x1292608: add             x3, x3, HEAP, lsl #32
    // 0x129260c: LoadField: r1 = r2->field_b
    //     0x129260c: ldur            w1, [x2, #0xb]
    // 0x1292610: DecompressPointer r1
    //     0x1292610: add             x1, x1, HEAP, lsl #32
    // 0x1292614: cmp             w3, w1
    // 0x1292618: b.ne            #0x1292638
    // 0x129261c: d0 = 1.000000
    //     0x129261c: fmov            d0, #1.00000000
    // 0x1292620: fcmp            d0, d0
    // 0x1292624: r16 = true
    //     0x1292624: add             x16, NULL, #0x20  ; true
    // 0x1292628: r17 = false
    //     0x1292628: add             x17, NULL, #0x30  ; false
    // 0x129262c: csel            x1, x16, x17, eq
    // 0x1292630: mov             x0, x1
    // 0x1292634: b               #0x129263c
    // 0x1292638: r0 = false
    //     0x1292638: add             x0, NULL, #0x30  ; false
    // 0x129263c: LeaveFrame
    //     0x129263c: mov             SP, fp
    //     0x1292640: ldp             fp, lr, [SP], #0x10
    // 0x1292644: ret
    //     0x1292644: ret             
    // 0x1292648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129264c: b               #0x1292588
  }
}

// class id: 3596, size: 0x18, field offset: 0xc
//   const constructor, 
class FileImage extends ImageProvider<dynamic> {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1149414, size: 0x64
    // 0x1149414: EnterFrame
    //     0x1149414: stp             fp, lr, [SP, #-0x10]!
    //     0x1149418: mov             fp, SP
    // 0x114941c: CheckStackOverflow
    //     0x114941c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149420: cmp             SP, x16
    //     0x1149424: b.ls            #0x1149470
    // 0x1149428: ldr             x0, [fp, #0x10]
    // 0x114942c: LoadField: r1 = r0->field_b
    //     0x114942c: ldur            w1, [x0, #0xb]
    // 0x1149430: DecompressPointer r1
    //     0x1149430: add             x1, x1, HEAP, lsl #32
    // 0x1149434: LoadField: r0 = r1->field_7
    //     0x1149434: ldur            w0, [x1, #7]
    // 0x1149438: DecompressPointer r0
    //     0x1149438: add             x0, x0, HEAP, lsl #32
    // 0x114943c: mov             x1, x0
    // 0x1149440: r2 = 1.000000
    //     0x1149440: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1149444: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1149444: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1149448: r0 = hash()
    //     0x1149448: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114944c: mov             x2, x0
    // 0x1149450: r0 = BoxInt64Instr(r2)
    //     0x1149450: sbfiz           x0, x2, #1, #0x1f
    //     0x1149454: cmp             x2, x0, asr #1
    //     0x1149458: b.eq            #0x1149464
    //     0x114945c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149460: stur            x2, [x0, #7]
    // 0x1149464: LeaveFrame
    //     0x1149464: mov             SP, fp
    //     0x1149468: ldp             fp, lr, [SP], #0x10
    // 0x114946c: ret
    //     0x114946c: ret             
    // 0x1149470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149474: b               #0x1149428
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0x115bec8, size: 0x34
    // 0x115bec8: EnterFrame
    //     0x115bec8: stp             fp, lr, [SP, #-0x10]!
    //     0x115becc: mov             fp, SP
    // 0x115bed0: AllocStack(0x8)
    //     0x115bed0: sub             SP, SP, #8
    // 0x115bed4: SetupParameters(FileImage this /* r1 => r0, fp-0x8 */)
    //     0x115bed4: mov             x0, x1
    //     0x115bed8: stur            x1, [fp, #-8]
    // 0x115bedc: r1 = <FileImage>
    //     0x115bedc: add             x1, PP, #0x89, lsl #12  ; [pp+0x89ec8] TypeArguments: <FileImage>
    //     0x115bee0: ldr             x1, [x1, #0xec8]
    // 0x115bee4: r0 = SynchronousFuture()
    //     0x115bee4: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x115bee8: ldur            x1, [fp, #-8]
    // 0x115beec: StoreField: r0->field_b = r1
    //     0x115beec: stur            w1, [x0, #0xb]
    // 0x115bef0: LeaveFrame
    //     0x115bef0: mov             SP, fp
    //     0x115bef4: ldp             fp, lr, [SP], #0x10
    // 0x115bef8: ret
    //     0x115bef8: ret             
  }
  _ loadImage(/* No info */) {
    // ** addr: 0x119283c, size: 0xbc
    // 0x119283c: EnterFrame
    //     0x119283c: stp             fp, lr, [SP, #-0x10]!
    //     0x1192840: mov             fp, SP
    // 0x1192844: AllocStack(0x28)
    //     0x1192844: sub             SP, SP, #0x28
    // 0x1192848: SetupParameters(FileImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x1192848: stur            x1, [fp, #-8]
    //     0x119284c: stur            x2, [fp, #-0x10]
    //     0x1192850: stur            x3, [fp, #-0x18]
    // 0x1192854: CheckStackOverflow
    //     0x1192854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192858: cmp             SP, x16
    //     0x119285c: b.ls            #0x11928f0
    // 0x1192860: r1 = 1
    //     0x1192860: mov             x1, #1
    // 0x1192864: r0 = AllocateContext()
    //     0x1192864: bl              #0x13de838  ; AllocateContextStub
    // 0x1192868: ldur            x1, [fp, #-8]
    // 0x119286c: stur            x0, [fp, #-0x20]
    // 0x1192870: StoreField: r0->field_f = r1
    //     0x1192870: stur            w1, [x0, #0xf]
    // 0x1192874: ldur            x2, [fp, #-0x10]
    // 0x1192878: ldur            x3, [fp, #-0x18]
    // 0x119287c: r0 = _loadAsync()
    //     0x119287c: bl              #0x11928f8  ; [package:flutter/src/painting/image_provider.dart] FileImage::_loadAsync
    // 0x1192880: mov             x3, x0
    // 0x1192884: ldur            x0, [fp, #-0x10]
    // 0x1192888: stur            x3, [fp, #-0x18]
    // 0x119288c: LoadField: r1 = r0->field_b
    //     0x119288c: ldur            w1, [x0, #0xb]
    // 0x1192890: DecompressPointer r1
    //     0x1192890: add             x1, x1, HEAP, lsl #32
    // 0x1192894: LoadField: r0 = r1->field_7
    //     0x1192894: ldur            w0, [x1, #7]
    // 0x1192898: DecompressPointer r0
    //     0x1192898: add             x0, x0, HEAP, lsl #32
    // 0x119289c: ldur            x2, [fp, #-0x20]
    // 0x11928a0: stur            x0, [fp, #-8]
    // 0x11928a4: r1 = Function '<anonymous closure>':.
    //     0x11928a4: add             x1, PP, #0x97, lsl #12  ; [pp+0x977c8] AnonymousClosure: (0x1192df4), in [package:flutter/src/painting/image_provider.dart] FileImage::loadImage (0x119283c)
    //     0x11928a8: ldr             x1, [x1, #0x7c8]
    // 0x11928ac: r0 = AllocateClosure()
    //     0x11928ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11928b0: stur            x0, [fp, #-0x10]
    // 0x11928b4: r0 = MultiFrameImageStreamCompleter()
    //     0x11928b4: bl              #0x1191a44  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0x11928b8: stur            x0, [fp, #-0x20]
    // 0x11928bc: ldur            x16, [fp, #-0x10]
    // 0x11928c0: str             x16, [SP]
    // 0x11928c4: mov             x1, x0
    // 0x11928c8: ldur            x2, [fp, #-0x18]
    // 0x11928cc: ldur            x3, [fp, #-8]
    // 0x11928d0: d0 = 1.000000
    //     0x11928d0: fmov            d0, #1.00000000
    // 0x11928d4: r4 = const [0, 0x5, 0x1, 0x4, informationCollector, 0x4, null]
    //     0x11928d4: add             x4, PP, #0x97, lsl #12  ; [pp+0x977d0] List(7) [0, 0x5, 0x1, 0x4, "informationCollector", 0x4, Null]
    //     0x11928d8: ldr             x4, [x4, #0x7d0]
    // 0x11928dc: r0 = MultiFrameImageStreamCompleter()
    //     0x11928dc: bl              #0x11864e8  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0x11928e0: ldur            x0, [fp, #-0x20]
    // 0x11928e4: LeaveFrame
    //     0x11928e4: mov             SP, fp
    //     0x11928e8: ldp             fp, lr, [SP], #0x10
    // 0x11928ec: ret
    //     0x11928ec: ret             
    // 0x11928f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11928f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11928f4: b               #0x1192860
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0x11928f8, size: 0x174
    // 0x11928f8: EnterFrame
    //     0x11928f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11928fc: mov             fp, SP
    // 0x1192900: AllocStack(0x40)
    //     0x1192900: sub             SP, SP, #0x40
    // 0x1192904: SetupParameters(FileImage this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x1192904: stur            NULL, [fp, #-8]
    //     0x1192908: stur            x1, [fp, #-0x10]
    //     0x119290c: stur            x2, [fp, #-0x18]
    //     0x1192910: stur            x3, [fp, #-0x20]
    // 0x1192914: CheckStackOverflow
    //     0x1192914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192918: cmp             SP, x16
    //     0x119291c: b.ls            #0x1192a58
    // 0x1192920: InitAsync() -> Future<Codec>
    //     0x1192920: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1192924: ldr             x0, [x0, #0x278]
    //     0x1192928: bl              #0x7f5e44  ; InitAsyncStub
    // 0x119292c: ldur            x0, [fp, #-0x10]
    // 0x1192930: LoadField: r2 = r0->field_b
    //     0x1192930: ldur            w2, [x0, #0xb]
    // 0x1192934: DecompressPointer r2
    //     0x1192934: add             x2, x2, HEAP, lsl #32
    // 0x1192938: mov             x1, x2
    // 0x119293c: stur            x2, [fp, #-0x28]
    // 0x1192940: r0 = length()
    //     0x1192940: bl              #0x123a20c  ; [dart:io] _File::length
    // 0x1192944: mov             x1, x0
    // 0x1192948: stur            x1, [fp, #-0x30]
    // 0x119294c: r0 = Await()
    //     0x119294c: bl              #0x7f5c00  ; AwaitStub
    // 0x1192950: cbz             w0, #0x11929d8
    // 0x1192954: r16 = _File
    //     0x1192954: add             x16, PP, #0x97, lsl #12  ; [pp+0x977e0] Type: _File
    //     0x1192958: ldr             x16, [x16, #0x7e0]
    // 0x119295c: r30 = File
    //     0x119295c: add             lr, PP, #0x97, lsl #12  ; [pp+0x977e8] Type: File
    //     0x1192960: ldr             lr, [lr, #0x7e8]
    // 0x1192964: stp             lr, x16, [SP]
    // 0x1192968: r0 = ==()
    //     0x1192968: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x119296c: tbnz            w0, #4, #0x119299c
    // 0x1192970: ldur            x0, [fp, #-0x28]
    // 0x1192974: LoadField: r1 = r0->field_7
    //     0x1192974: ldur            w1, [x0, #7]
    // 0x1192978: DecompressPointer r1
    //     0x1192978: add             x1, x1, HEAP, lsl #32
    // 0x119297c: r0 = fromFilePath()
    //     0x119297c: bl              #0x1192a6c  ; [dart:ui] ImmutableBuffer::fromFilePath
    // 0x1192980: mov             x1, x0
    // 0x1192984: stur            x1, [fp, #-0x10]
    // 0x1192988: r0 = Await()
    //     0x1192988: bl              #0x7f5c00  ; AwaitStub
    // 0x119298c: mov             x1, x0
    // 0x1192990: r2 = Null
    //     0x1192990: mov             x2, NULL
    // 0x1192994: r0 = instantiateImageCodecWithSize()
    //     0x1192994: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x1192998: b               #0x11929d4
    // 0x119299c: ldur            x0, [fp, #-0x28]
    // 0x11929a0: mov             x1, x0
    // 0x11929a4: r0 = readAsBytes()
    //     0x11929a4: bl              #0x124c570  ; [dart:io] _File::readAsBytes
    // 0x11929a8: mov             x1, x0
    // 0x11929ac: stur            x1, [fp, #-0x10]
    // 0x11929b0: r0 = Await()
    //     0x11929b0: bl              #0x7f5c00  ; AwaitStub
    // 0x11929b4: mov             x1, x0
    // 0x11929b8: r0 = fromUint8List()
    //     0x11929b8: bl              #0xce7b70  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0x11929bc: mov             x1, x0
    // 0x11929c0: stur            x1, [fp, #-0x10]
    // 0x11929c4: r0 = Await()
    //     0x11929c4: bl              #0x7f5c00  ; AwaitStub
    // 0x11929c8: mov             x1, x0
    // 0x11929cc: r2 = Null
    //     0x11929cc: mov             x2, NULL
    // 0x11929d0: r0 = instantiateImageCodecWithSize()
    //     0x11929d0: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x11929d4: r0 = ReturnAsync()
    //     0x11929d4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x11929d8: ldur            x0, [fp, #-0x28]
    // 0x11929dc: r1 = LoadStaticField(0x780)
    //     0x11929dc: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x11929e0: ldr             x1, [x1, #0xf00]
    // 0x11929e4: cmp             w1, NULL
    // 0x11929e8: b.eq            #0x1192a60
    // 0x11929ec: LoadField: r2 = r1->field_ab
    //     0x11929ec: ldur            w2, [x1, #0xab]
    // 0x11929f0: DecompressPointer r2
    //     0x11929f0: add             x2, x2, HEAP, lsl #32
    // 0x11929f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11929f8: cmp             w2, w16
    // 0x11929fc: b.eq            #0x1192a64
    // 0x1192a00: mov             x1, x2
    // 0x1192a04: ldur            x2, [fp, #-0x18]
    // 0x1192a08: r0 = evict()
    //     0x1192a08: bl              #0x118b5f8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0x1192a0c: r1 = Null
    //     0x1192a0c: mov             x1, NULL
    // 0x1192a10: r2 = 4
    //     0x1192a10: mov             x2, #4
    // 0x1192a14: r0 = AllocateArray()
    //     0x1192a14: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192a18: mov             x1, x0
    // 0x1192a1c: ldur            x0, [fp, #-0x28]
    // 0x1192a20: StoreField: r1->field_f = r0
    //     0x1192a20: stur            w0, [x1, #0xf]
    // 0x1192a24: r16 = " is empty and cannot be loaded as an image."
    //     0x1192a24: add             x16, PP, #0x97, lsl #12  ; [pp+0x977f0] " is empty and cannot be loaded as an image."
    //     0x1192a28: ldr             x16, [x16, #0x7f0]
    // 0x1192a2c: StoreField: r1->field_13 = r16
    //     0x1192a2c: stur            w16, [x1, #0x13]
    // 0x1192a30: str             x1, [SP]
    // 0x1192a34: r0 = _interpolate()
    //     0x1192a34: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1192a38: stur            x0, [fp, #-0x10]
    // 0x1192a3c: r0 = StateError()
    //     0x1192a3c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1192a40: mov             x1, x0
    // 0x1192a44: ldur            x0, [fp, #-0x10]
    // 0x1192a48: StoreField: r1->field_b = r0
    //     0x1192a48: stur            w0, [x1, #0xb]
    // 0x1192a4c: mov             x0, x1
    // 0x1192a50: r0 = Throw()
    //     0x1192a50: bl              #0x13ddb2c  ; ThrowStub
    // 0x1192a54: brk             #0
    // 0x1192a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192a58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192a5c: b               #0x1192920
    // 0x1192a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1192a60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1192a64: r9 = _imageCache
    //     0x1192a64: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x1192a68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1192a68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x1192df4, size: 0xd0
    // 0x1192df4: EnterFrame
    //     0x1192df4: stp             fp, lr, [SP, #-0x10]!
    //     0x1192df8: mov             fp, SP
    // 0x1192dfc: AllocStack(0x18)
    //     0x1192dfc: sub             SP, SP, #0x18
    // 0x1192e00: SetupParameters([dynamic _ /* r0 */])
    //     0x1192e00: ldr             x0, [fp, #0x10]
    //     0x1192e04: ldur            w3, [x0, #0x17]
    //     0x1192e08: add             x3, x3, HEAP, lsl #32
    //     0x1192e0c: stur            x3, [fp, #-8]
    // 0x1192e10: CheckStackOverflow
    //     0x1192e10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192e14: cmp             SP, x16
    //     0x1192e18: b.ls            #0x1192ebc
    // 0x1192e1c: r1 = Null
    //     0x1192e1c: mov             x1, NULL
    // 0x1192e20: r2 = 4
    //     0x1192e20: mov             x2, #4
    // 0x1192e24: r0 = AllocateArray()
    //     0x1192e24: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192e28: r16 = "Path: "
    //     0x1192e28: add             x16, PP, #0x97, lsl #12  ; [pp+0x977d8] "Path: "
    //     0x1192e2c: ldr             x16, [x16, #0x7d8]
    // 0x1192e30: StoreField: r0->field_f = r16
    //     0x1192e30: stur            w16, [x0, #0xf]
    // 0x1192e34: ldur            x1, [fp, #-8]
    // 0x1192e38: LoadField: r2 = r1->field_f
    //     0x1192e38: ldur            w2, [x1, #0xf]
    // 0x1192e3c: DecompressPointer r2
    //     0x1192e3c: add             x2, x2, HEAP, lsl #32
    // 0x1192e40: LoadField: r1 = r2->field_b
    //     0x1192e40: ldur            w1, [x2, #0xb]
    // 0x1192e44: DecompressPointer r1
    //     0x1192e44: add             x1, x1, HEAP, lsl #32
    // 0x1192e48: LoadField: r2 = r1->field_7
    //     0x1192e48: ldur            w2, [x1, #7]
    // 0x1192e4c: DecompressPointer r2
    //     0x1192e4c: add             x2, x2, HEAP, lsl #32
    // 0x1192e50: StoreField: r0->field_13 = r2
    //     0x1192e50: stur            w2, [x0, #0x13]
    // 0x1192e54: str             x0, [SP]
    // 0x1192e58: r0 = _interpolate()
    //     0x1192e58: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1192e5c: r1 = <List<Object>>
    //     0x1192e5c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x1192e60: stur            x0, [fp, #-8]
    // 0x1192e64: r0 = ErrorDescription()
    //     0x1192e64: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1192e68: mov             x1, x0
    // 0x1192e6c: ldur            x2, [fp, #-8]
    // 0x1192e70: r3 = Instance_DiagnosticLevel
    //     0x1192e70: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1192e74: stur            x0, [fp, #-8]
    // 0x1192e78: r0 = _ErrorDiagnostic()
    //     0x1192e78: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1192e7c: r1 = Null
    //     0x1192e7c: mov             x1, NULL
    // 0x1192e80: r2 = 2
    //     0x1192e80: mov             x2, #2
    // 0x1192e84: r0 = AllocateArray()
    //     0x1192e84: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192e88: mov             x2, x0
    // 0x1192e8c: ldur            x0, [fp, #-8]
    // 0x1192e90: stur            x2, [fp, #-0x10]
    // 0x1192e94: StoreField: r2->field_f = r0
    //     0x1192e94: stur            w0, [x2, #0xf]
    // 0x1192e98: r1 = <DiagnosticsNode>
    //     0x1192e98: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x1192e9c: r0 = AllocateGrowableArray()
    //     0x1192e9c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1192ea0: ldur            x1, [fp, #-0x10]
    // 0x1192ea4: StoreField: r0->field_f = r1
    //     0x1192ea4: stur            w1, [x0, #0xf]
    // 0x1192ea8: r1 = 2
    //     0x1192ea8: mov             x1, #2
    // 0x1192eac: StoreField: r0->field_b = r1
    //     0x1192eac: stur            w1, [x0, #0xb]
    // 0x1192eb0: LeaveFrame
    //     0x1192eb0: mov             SP, fp
    //     0x1192eb4: ldp             fp, lr, [SP], #0x10
    // 0x1192eb8: ret
    //     0x1192eb8: ret             
    // 0x1192ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192ec0: b               #0x1192e1c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1292468, size: 0x108
    // 0x1292468: EnterFrame
    //     0x1292468: stp             fp, lr, [SP, #-0x10]!
    //     0x129246c: mov             fp, SP
    // 0x1292470: AllocStack(0x10)
    //     0x1292470: sub             SP, SP, #0x10
    // 0x1292474: CheckStackOverflow
    //     0x1292474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292478: cmp             SP, x16
    //     0x129247c: b.ls            #0x1292568
    // 0x1292480: ldr             x0, [fp, #0x10]
    // 0x1292484: cmp             w0, NULL
    // 0x1292488: b.ne            #0x129249c
    // 0x129248c: r0 = false
    //     0x129248c: add             x0, NULL, #0x30  ; false
    // 0x1292490: LeaveFrame
    //     0x1292490: mov             SP, fp
    //     0x1292494: ldp             fp, lr, [SP], #0x10
    // 0x1292498: ret
    //     0x1292498: ret             
    // 0x129249c: str             x0, [SP]
    // 0x12924a0: r0 = runtimeType()
    //     0x12924a0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12924a4: r1 = LoadClassIdInstr(r0)
    //     0x12924a4: ldur            x1, [x0, #-1]
    //     0x12924a8: ubfx            x1, x1, #0xc, #0x14
    // 0x12924ac: r16 = FileImage
    //     0x12924ac: add             x16, PP, #0x97, lsl #12  ; [pp+0x977c0] Type: FileImage
    //     0x12924b0: ldr             x16, [x16, #0x7c0]
    // 0x12924b4: stp             x16, x0, [SP]
    // 0x12924b8: mov             x0, x1
    // 0x12924bc: mov             lr, x0
    // 0x12924c0: ldr             lr, [x21, lr, lsl #3]
    // 0x12924c4: blr             lr
    // 0x12924c8: tbz             w0, #4, #0x12924dc
    // 0x12924cc: r0 = false
    //     0x12924cc: add             x0, NULL, #0x30  ; false
    // 0x12924d0: LeaveFrame
    //     0x12924d0: mov             SP, fp
    //     0x12924d4: ldp             fp, lr, [SP], #0x10
    // 0x12924d8: ret
    //     0x12924d8: ret             
    // 0x12924dc: ldr             x0, [fp, #0x10]
    // 0x12924e0: r1 = 60
    //     0x12924e0: mov             x1, #0x3c
    // 0x12924e4: branchIfSmi(r0, 0x12924f0)
    //     0x12924e4: tbz             w0, #0, #0x12924f0
    // 0x12924e8: r1 = LoadClassIdInstr(r0)
    //     0x12924e8: ldur            x1, [x0, #-1]
    //     0x12924ec: ubfx            x1, x1, #0xc, #0x14
    // 0x12924f0: cmp             x1, #0xe0c
    // 0x12924f4: b.ne            #0x1292558
    // 0x12924f8: ldr             x1, [fp, #0x18]
    // 0x12924fc: LoadField: r2 = r0->field_b
    //     0x12924fc: ldur            w2, [x0, #0xb]
    // 0x1292500: DecompressPointer r2
    //     0x1292500: add             x2, x2, HEAP, lsl #32
    // 0x1292504: LoadField: r0 = r2->field_7
    //     0x1292504: ldur            w0, [x2, #7]
    // 0x1292508: DecompressPointer r0
    //     0x1292508: add             x0, x0, HEAP, lsl #32
    // 0x129250c: LoadField: r2 = r1->field_b
    //     0x129250c: ldur            w2, [x1, #0xb]
    // 0x1292510: DecompressPointer r2
    //     0x1292510: add             x2, x2, HEAP, lsl #32
    // 0x1292514: LoadField: r1 = r2->field_7
    //     0x1292514: ldur            w1, [x2, #7]
    // 0x1292518: DecompressPointer r1
    //     0x1292518: add             x1, x1, HEAP, lsl #32
    // 0x129251c: r2 = LoadClassIdInstr(r0)
    //     0x129251c: ldur            x2, [x0, #-1]
    //     0x1292520: ubfx            x2, x2, #0xc, #0x14
    // 0x1292524: stp             x1, x0, [SP]
    // 0x1292528: mov             x0, x2
    // 0x129252c: mov             lr, x0
    // 0x1292530: ldr             lr, [x21, lr, lsl #3]
    // 0x1292534: blr             lr
    // 0x1292538: tbnz            w0, #4, #0x1292558
    // 0x129253c: d0 = 1.000000
    //     0x129253c: fmov            d0, #1.00000000
    // 0x1292540: fcmp            d0, d0
    // 0x1292544: r16 = true
    //     0x1292544: add             x16, NULL, #0x20  ; true
    // 0x1292548: r17 = false
    //     0x1292548: add             x17, NULL, #0x30  ; false
    // 0x129254c: csel            x1, x16, x17, eq
    // 0x1292550: mov             x0, x1
    // 0x1292554: b               #0x129255c
    // 0x1292558: r0 = false
    //     0x1292558: add             x0, NULL, #0x30  ; false
    // 0x129255c: LeaveFrame
    //     0x129255c: mov             SP, fp
    //     0x1292560: ldp             fp, lr, [SP], #0x10
    // 0x1292564: ret
    //     0x1292564: ret             
    // 0x1292568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129256c: b               #0x1292480
  }
}

// class id: 3598, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class AssetBundleImageProvider extends ImageProvider<dynamic> {

  _ loadImage(/* No info */) {
    // ** addr: 0x1192184, size: 0x88
    // 0x1192184: EnterFrame
    //     0x1192184: stp             fp, lr, [SP, #-0x10]!
    //     0x1192188: mov             fp, SP
    // 0x119218c: AllocStack(0x28)
    //     0x119218c: sub             SP, SP, #0x28
    // 0x1192190: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x1192190: mov             x0, x2
    //     0x1192194: stur            x2, [fp, #-8]
    // 0x1192198: CheckStackOverflow
    //     0x1192198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119219c: cmp             SP, x16
    //     0x11921a0: b.ls            #0x1192204
    // 0x11921a4: mov             x2, x0
    // 0x11921a8: r0 = _loadAsync()
    //     0x11921a8: bl              #0x119220c  ; [package:flutter/src/painting/image_provider.dart] AssetBundleImageProvider::_loadAsync
    // 0x11921ac: mov             x1, x0
    // 0x11921b0: ldur            x0, [fp, #-8]
    // 0x11921b4: stur            x1, [fp, #-0x18]
    // 0x11921b8: LoadField: d0 = r0->field_f
    //     0x11921b8: ldur            d0, [x0, #0xf]
    // 0x11921bc: stur            d0, [fp, #-0x20]
    // 0x11921c0: LoadField: r3 = r0->field_b
    //     0x11921c0: ldur            w3, [x0, #0xb]
    // 0x11921c4: DecompressPointer r3
    //     0x11921c4: add             x3, x3, HEAP, lsl #32
    // 0x11921c8: stur            x3, [fp, #-0x10]
    // 0x11921cc: r0 = MultiFrameImageStreamCompleter()
    //     0x11921cc: bl              #0x1191a44  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0x11921d0: stur            x0, [fp, #-8]
    // 0x11921d4: str             NULL, [SP]
    // 0x11921d8: mov             x1, x0
    // 0x11921dc: ldur            x2, [fp, #-0x18]
    // 0x11921e0: ldur            x3, [fp, #-0x10]
    // 0x11921e4: ldur            d0, [fp, #-0x20]
    // 0x11921e8: r4 = const [0, 0x5, 0x1, 0x4, informationCollector, 0x4, null]
    //     0x11921e8: add             x4, PP, #0x97, lsl #12  ; [pp+0x977d0] List(7) [0, 0x5, 0x1, 0x4, "informationCollector", 0x4, Null]
    //     0x11921ec: ldr             x4, [x4, #0x7d0]
    // 0x11921f0: r0 = MultiFrameImageStreamCompleter()
    //     0x11921f0: bl              #0x11864e8  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0x11921f4: ldur            x0, [fp, #-8]
    // 0x11921f8: LeaveFrame
    //     0x11921f8: mov             SP, fp
    //     0x11921fc: ldp             fp, lr, [SP], #0x10
    // 0x1192200: ret
    //     0x1192200: ret             
    // 0x1192204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192208: b               #0x11921a4
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0x119220c, size: 0xfc
    // 0x119220c: EnterFrame
    //     0x119220c: stp             fp, lr, [SP, #-0x10]!
    //     0x1192210: mov             fp, SP
    // 0x1192214: AllocStack(0x78)
    //     0x1192214: sub             SP, SP, #0x78
    // 0x1192218: SetupParameters(AssetBundleImageProvider this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */, dynamic _ /* r3 => r3, fp-0x78 */)
    //     0x1192218: stur            NULL, [fp, #-8]
    //     0x119221c: stur            x1, [fp, #-0x68]
    //     0x1192220: stur            x2, [fp, #-0x70]
    //     0x1192224: stur            x3, [fp, #-0x78]
    // 0x1192228: CheckStackOverflow
    //     0x1192228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119222c: cmp             SP, x16
    //     0x1192230: b.ls            #0x11922f4
    // 0x1192234: InitAsync() -> Future<Codec>
    //     0x1192234: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1192238: ldr             x0, [x0, #0x278]
    //     0x119223c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1192240: ldur            x0, [fp, #-0x70]
    // 0x1192244: LoadField: r1 = r0->field_7
    //     0x1192244: ldur            w1, [x0, #7]
    // 0x1192248: DecompressPointer r1
    //     0x1192248: add             x1, x1, HEAP, lsl #32
    // 0x119224c: LoadField: r2 = r0->field_b
    //     0x119224c: ldur            w2, [x0, #0xb]
    // 0x1192250: DecompressPointer r2
    //     0x1192250: add             x2, x2, HEAP, lsl #32
    // 0x1192254: r0 = loadBuffer()
    //     0x1192254: bl              #0x1192308  ; [package:flutter/src/services/asset_bundle.dart] PlatformAssetBundle::loadBuffer
    // 0x1192258: mov             x1, x0
    // 0x119225c: stur            x1, [fp, #-0x68]
    // 0x1192260: r0 = Await()
    //     0x1192260: bl              #0x7f5c00  ; AwaitStub
    // 0x1192264: mov             x1, x0
    // 0x1192268: r2 = Null
    //     0x1192268: mov             x2, NULL
    // 0x119226c: r0 = instantiateImageCodecWithSize()
    //     0x119226c: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x1192270: r0 = ReturnAsync()
    //     0x1192270: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x1192274: sub             SP, fp, #0x78
    // 0x1192278: mov             x3, x0
    // 0x119227c: stur            x0, [fp, #-0x68]
    // 0x1192280: mov             x0, x1
    // 0x1192284: stur            x1, [fp, #-0x78]
    // 0x1192288: r1 = 60
    //     0x1192288: mov             x1, #0x3c
    // 0x119228c: branchIfSmi(r3, 0x1192298)
    //     0x119228c: tbz             w3, #0, #0x1192298
    // 0x1192290: r1 = LoadClassIdInstr(r3)
    //     0x1192290: ldur            x1, [x3, #-1]
    //     0x1192294: ubfx            x1, x1, #0xc, #0x14
    // 0x1192298: r17 = 7754
    //     0x1192298: mov             x17, #0x1e4a
    // 0x119229c: cmp             x1, x17
    // 0x11922a0: b.ne            #0x11922e4
    // 0x11922a4: r1 = LoadStaticField(0x780)
    //     0x11922a4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x11922a8: ldr             x1, [x1, #0xf00]
    // 0x11922ac: cmp             w1, NULL
    // 0x11922b0: b.eq            #0x11922fc
    // 0x11922b4: LoadField: r2 = r1->field_ab
    //     0x11922b4: ldur            w2, [x1, #0xab]
    // 0x11922b8: DecompressPointer r2
    //     0x11922b8: add             x2, x2, HEAP, lsl #32
    // 0x11922bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11922c0: cmp             w2, w16
    // 0x11922c4: b.eq            #0x1192300
    // 0x11922c8: mov             x1, x2
    // 0x11922cc: ldur            x2, [fp, #-0x70]
    // 0x11922d0: r0 = evict()
    //     0x11922d0: bl              #0x118b5f8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0x11922d4: ldur            x0, [fp, #-0x68]
    // 0x11922d8: ldur            x1, [fp, #-0x78]
    // 0x11922dc: r0 = ReThrow()
    //     0x11922dc: bl              #0x13ddb00  ; ReThrowStub
    // 0x11922e0: brk             #0
    // 0x11922e4: ldur            x0, [fp, #-0x68]
    // 0x11922e8: ldur            x1, [fp, #-0x78]
    // 0x11922ec: r0 = ReThrow()
    //     0x11922ec: bl              #0x13ddb00  ; ReThrowStub
    // 0x11922f0: brk             #0
    // 0x11922f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11922f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11922f8: b               #0x1192234
    // 0x11922fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11922fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1192300: r9 = _imageCache
    //     0x1192300: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x1192304: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1192304: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3602, size: 0xc, field offset: 0xc
abstract class NetworkImage extends ImageProvider<dynamic> {
}

// class id: 5246, size: 0x30, field offset: 0x30
class _ErrorImageCompleter extends ImageStreamCompleter {
}
