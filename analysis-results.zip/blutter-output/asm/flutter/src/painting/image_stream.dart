// lib: , url: package:flutter/src/painting/image_stream.dart

// class id: 1049000, size: 0x8
class :: {
}

// class id: 2920, size: 0x14, field offset: 0x8
//   const constructor, 
class ImageStreamListener extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x12994cc, size: 0x134
    // 0x12994cc: EnterFrame
    //     0x12994cc: stp             fp, lr, [SP, #-0x10]!
    //     0x12994d0: mov             fp, SP
    // 0x12994d4: AllocStack(0x10)
    //     0x12994d4: sub             SP, SP, #0x10
    // 0x12994d8: CheckStackOverflow
    //     0x12994d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12994dc: cmp             SP, x16
    //     0x12994e0: b.ls            #0x12995f8
    // 0x12994e4: ldr             x0, [fp, #0x10]
    // 0x12994e8: cmp             w0, NULL
    // 0x12994ec: b.ne            #0x1299500
    // 0x12994f0: r0 = false
    //     0x12994f0: add             x0, NULL, #0x30  ; false
    // 0x12994f4: LeaveFrame
    //     0x12994f4: mov             SP, fp
    //     0x12994f8: ldp             fp, lr, [SP], #0x10
    // 0x12994fc: ret
    //     0x12994fc: ret             
    // 0x1299500: str             x0, [SP]
    // 0x1299504: r0 = runtimeType()
    //     0x1299504: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1299508: r1 = LoadClassIdInstr(r0)
    //     0x1299508: ldur            x1, [x0, #-1]
    //     0x129950c: ubfx            x1, x1, #0xc, #0x14
    // 0x1299510: r16 = ImageStreamListener
    //     0x1299510: ldr             x16, [PP, #0x34d8]  ; [pp+0x34d8] Type: ImageStreamListener
    // 0x1299514: stp             x16, x0, [SP]
    // 0x1299518: mov             x0, x1
    // 0x129951c: mov             lr, x0
    // 0x1299520: ldr             lr, [x21, lr, lsl #3]
    // 0x1299524: blr             lr
    // 0x1299528: tbz             w0, #4, #0x129953c
    // 0x129952c: r0 = false
    //     0x129952c: add             x0, NULL, #0x30  ; false
    // 0x1299530: LeaveFrame
    //     0x1299530: mov             SP, fp
    //     0x1299534: ldp             fp, lr, [SP], #0x10
    // 0x1299538: ret
    //     0x1299538: ret             
    // 0x129953c: ldr             x0, [fp, #0x10]
    // 0x1299540: r1 = 60
    //     0x1299540: mov             x1, #0x3c
    // 0x1299544: branchIfSmi(r0, 0x1299550)
    //     0x1299544: tbz             w0, #0, #0x1299550
    // 0x1299548: r1 = LoadClassIdInstr(r0)
    //     0x1299548: ldur            x1, [x0, #-1]
    //     0x129954c: ubfx            x1, x1, #0xc, #0x14
    // 0x1299550: cmp             x1, #0xb68
    // 0x1299554: b.ne            #0x12995e8
    // 0x1299558: ldr             x1, [fp, #0x18]
    // 0x129955c: LoadField: r2 = r0->field_7
    //     0x129955c: ldur            w2, [x0, #7]
    // 0x1299560: DecompressPointer r2
    //     0x1299560: add             x2, x2, HEAP, lsl #32
    // 0x1299564: LoadField: r3 = r1->field_7
    //     0x1299564: ldur            w3, [x1, #7]
    // 0x1299568: DecompressPointer r3
    //     0x1299568: add             x3, x3, HEAP, lsl #32
    // 0x129956c: stp             x3, x2, [SP]
    // 0x1299570: r0 = ==()
    //     0x1299570: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0x1299574: tbnz            w0, #4, #0x12995e8
    // 0x1299578: ldr             x2, [fp, #0x18]
    // 0x129957c: ldr             x1, [fp, #0x10]
    // 0x1299580: LoadField: r0 = r1->field_b
    //     0x1299580: ldur            w0, [x1, #0xb]
    // 0x1299584: DecompressPointer r0
    //     0x1299584: add             x0, x0, HEAP, lsl #32
    // 0x1299588: LoadField: r3 = r2->field_b
    //     0x1299588: ldur            w3, [x2, #0xb]
    // 0x129958c: DecompressPointer r3
    //     0x129958c: add             x3, x3, HEAP, lsl #32
    // 0x1299590: r4 = LoadClassIdInstr(r0)
    //     0x1299590: ldur            x4, [x0, #-1]
    //     0x1299594: ubfx            x4, x4, #0xc, #0x14
    // 0x1299598: stp             x3, x0, [SP]
    // 0x129959c: mov             x0, x4
    // 0x12995a0: mov             lr, x0
    // 0x12995a4: ldr             lr, [x21, lr, lsl #3]
    // 0x12995a8: blr             lr
    // 0x12995ac: tbnz            w0, #4, #0x12995e8
    // 0x12995b0: ldr             x1, [fp, #0x18]
    // 0x12995b4: ldr             x0, [fp, #0x10]
    // 0x12995b8: LoadField: r2 = r0->field_f
    //     0x12995b8: ldur            w2, [x0, #0xf]
    // 0x12995bc: DecompressPointer r2
    //     0x12995bc: add             x2, x2, HEAP, lsl #32
    // 0x12995c0: LoadField: r0 = r1->field_f
    //     0x12995c0: ldur            w0, [x1, #0xf]
    // 0x12995c4: DecompressPointer r0
    //     0x12995c4: add             x0, x0, HEAP, lsl #32
    // 0x12995c8: r1 = LoadClassIdInstr(r2)
    //     0x12995c8: ldur            x1, [x2, #-1]
    //     0x12995cc: ubfx            x1, x1, #0xc, #0x14
    // 0x12995d0: stp             x0, x2, [SP]
    // 0x12995d4: mov             x0, x1
    // 0x12995d8: mov             lr, x0
    // 0x12995dc: ldr             lr, [x21, lr, lsl #3]
    // 0x12995e0: blr             lr
    // 0x12995e4: b               #0x12995ec
    // 0x12995e8: r0 = false
    //     0x12995e8: add             x0, NULL, #0x30  ; false
    // 0x12995ec: LeaveFrame
    //     0x12995ec: mov             SP, fp
    //     0x12995f0: ldp             fp, lr, [SP], #0x10
    // 0x12995f4: ret
    //     0x12995f4: ret             
    // 0x12995f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12995f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12995fc: b               #0x12994e4
  }
}

// class id: 2960, size: 0x18, field offset: 0x8
class ImageInfo extends Object {

  _ clone(/* No info */) {
    // ** addr: 0xd08a74, size: 0x7c
    // 0xd08a74: EnterFrame
    //     0xd08a74: stp             fp, lr, [SP, #-0x10]!
    //     0xd08a78: mov             fp, SP
    // 0xd08a7c: AllocStack(0x20)
    //     0xd08a7c: sub             SP, SP, #0x20
    // 0xd08a80: SetupParameters(ImageInfo this /* r1 => r0, fp-0x8 */)
    //     0xd08a80: mov             x0, x1
    //     0xd08a84: stur            x1, [fp, #-8]
    // 0xd08a88: CheckStackOverflow
    //     0xd08a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08a8c: cmp             SP, x16
    //     0xd08a90: b.ls            #0xd08ae8
    // 0xd08a94: LoadField: r1 = r0->field_7
    //     0xd08a94: ldur            w1, [x0, #7]
    // 0xd08a98: DecompressPointer r1
    //     0xd08a98: add             x1, x1, HEAP, lsl #32
    // 0xd08a9c: r0 = clone()
    //     0xd08a9c: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0xd08aa0: mov             x1, x0
    // 0xd08aa4: ldur            x0, [fp, #-8]
    // 0xd08aa8: stur            x1, [fp, #-0x18]
    // 0xd08aac: LoadField: d0 = r0->field_b
    //     0xd08aac: ldur            d0, [x0, #0xb]
    // 0xd08ab0: stur            d0, [fp, #-0x20]
    // 0xd08ab4: LoadField: r2 = r0->field_13
    //     0xd08ab4: ldur            w2, [x0, #0x13]
    // 0xd08ab8: DecompressPointer r2
    //     0xd08ab8: add             x2, x2, HEAP, lsl #32
    // 0xd08abc: stur            x2, [fp, #-0x10]
    // 0xd08ac0: r0 = ImageInfo()
    //     0xd08ac0: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd08ac4: ldur            x1, [fp, #-0x18]
    // 0xd08ac8: StoreField: r0->field_7 = r1
    //     0xd08ac8: stur            w1, [x0, #7]
    // 0xd08acc: ldur            d0, [fp, #-0x20]
    // 0xd08ad0: StoreField: r0->field_b = d0
    //     0xd08ad0: stur            d0, [x0, #0xb]
    // 0xd08ad4: ldur            x1, [fp, #-0x10]
    // 0xd08ad8: StoreField: r0->field_13 = r1
    //     0xd08ad8: stur            w1, [x0, #0x13]
    // 0xd08adc: LeaveFrame
    //     0xd08adc: mov             SP, fp
    //     0xd08ae0: ldp             fp, lr, [SP], #0x10
    // 0xd08ae4: ret
    //     0xd08ae4: ret             
    // 0xd08ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08aec: b               #0xd08a94
  }
  _ dispose(/* No info */) {
    // ** addr: 0xd08b2c, size: 0x3c
    // 0xd08b2c: EnterFrame
    //     0xd08b2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd08b30: mov             fp, SP
    // 0xd08b34: CheckStackOverflow
    //     0xd08b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08b38: cmp             SP, x16
    //     0xd08b3c: b.ls            #0xd08b60
    // 0xd08b40: LoadField: r0 = r1->field_7
    //     0xd08b40: ldur            w0, [x1, #7]
    // 0xd08b44: DecompressPointer r0
    //     0xd08b44: add             x0, x0, HEAP, lsl #32
    // 0xd08b48: mov             x1, x0
    // 0xd08b4c: r0 = dispose()
    //     0xd08b4c: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xd08b50: r0 = Null
    //     0xd08b50: mov             x0, NULL
    // 0xd08b54: LeaveFrame
    //     0xd08b54: mov             SP, fp
    //     0xd08b58: ldp             fp, lr, [SP], #0x10
    // 0xd08b5c: ret
    //     0xd08b5c: ret             
    // 0xd08b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08b60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08b64: b               #0xd08b40
  }
  _ ==(/* No info */) {
    // ** addr: 0x1297df8, size: 0x104
    // 0x1297df8: EnterFrame
    //     0x1297df8: stp             fp, lr, [SP, #-0x10]!
    //     0x1297dfc: mov             fp, SP
    // 0x1297e00: AllocStack(0x10)
    //     0x1297e00: sub             SP, SP, #0x10
    // 0x1297e04: CheckStackOverflow
    //     0x1297e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1297e08: cmp             SP, x16
    //     0x1297e0c: b.ls            #0x1297ef4
    // 0x1297e10: ldr             x0, [fp, #0x10]
    // 0x1297e14: cmp             w0, NULL
    // 0x1297e18: b.ne            #0x1297e2c
    // 0x1297e1c: r0 = false
    //     0x1297e1c: add             x0, NULL, #0x30  ; false
    // 0x1297e20: LeaveFrame
    //     0x1297e20: mov             SP, fp
    //     0x1297e24: ldp             fp, lr, [SP], #0x10
    // 0x1297e28: ret
    //     0x1297e28: ret             
    // 0x1297e2c: str             x0, [SP]
    // 0x1297e30: r0 = runtimeType()
    //     0x1297e30: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1297e34: r1 = LoadClassIdInstr(r0)
    //     0x1297e34: ldur            x1, [x0, #-1]
    //     0x1297e38: ubfx            x1, x1, #0xc, #0x14
    // 0x1297e3c: r16 = ImageInfo
    //     0x1297e3c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c450] Type: ImageInfo
    //     0x1297e40: ldr             x16, [x16, #0x450]
    // 0x1297e44: stp             x16, x0, [SP]
    // 0x1297e48: mov             x0, x1
    // 0x1297e4c: mov             lr, x0
    // 0x1297e50: ldr             lr, [x21, lr, lsl #3]
    // 0x1297e54: blr             lr
    // 0x1297e58: tbz             w0, #4, #0x1297e6c
    // 0x1297e5c: r0 = false
    //     0x1297e5c: add             x0, NULL, #0x30  ; false
    // 0x1297e60: LeaveFrame
    //     0x1297e60: mov             SP, fp
    //     0x1297e64: ldp             fp, lr, [SP], #0x10
    // 0x1297e68: ret
    //     0x1297e68: ret             
    // 0x1297e6c: ldr             x0, [fp, #0x10]
    // 0x1297e70: r1 = 60
    //     0x1297e70: mov             x1, #0x3c
    // 0x1297e74: branchIfSmi(r0, 0x1297e80)
    //     0x1297e74: tbz             w0, #0, #0x1297e80
    // 0x1297e78: r1 = LoadClassIdInstr(r0)
    //     0x1297e78: ldur            x1, [x0, #-1]
    //     0x1297e7c: ubfx            x1, x1, #0xc, #0x14
    // 0x1297e80: cmp             x1, #0xb90
    // 0x1297e84: b.ne            #0x1297ee4
    // 0x1297e88: ldr             x1, [fp, #0x18]
    // 0x1297e8c: LoadField: r2 = r0->field_7
    //     0x1297e8c: ldur            w2, [x0, #7]
    // 0x1297e90: DecompressPointer r2
    //     0x1297e90: add             x2, x2, HEAP, lsl #32
    // 0x1297e94: LoadField: r3 = r1->field_7
    //     0x1297e94: ldur            w3, [x1, #7]
    // 0x1297e98: DecompressPointer r3
    //     0x1297e98: add             x3, x3, HEAP, lsl #32
    // 0x1297e9c: cmp             w2, w3
    // 0x1297ea0: b.ne            #0x1297ee4
    // 0x1297ea4: LoadField: d0 = r0->field_b
    //     0x1297ea4: ldur            d0, [x0, #0xb]
    // 0x1297ea8: LoadField: d1 = r1->field_b
    //     0x1297ea8: ldur            d1, [x1, #0xb]
    // 0x1297eac: fcmp            d0, d1
    // 0x1297eb0: b.ne            #0x1297ee4
    // 0x1297eb4: LoadField: r2 = r0->field_13
    //     0x1297eb4: ldur            w2, [x0, #0x13]
    // 0x1297eb8: DecompressPointer r2
    //     0x1297eb8: add             x2, x2, HEAP, lsl #32
    // 0x1297ebc: LoadField: r0 = r1->field_13
    //     0x1297ebc: ldur            w0, [x1, #0x13]
    // 0x1297ec0: DecompressPointer r0
    //     0x1297ec0: add             x0, x0, HEAP, lsl #32
    // 0x1297ec4: r1 = LoadClassIdInstr(r2)
    //     0x1297ec4: ldur            x1, [x2, #-1]
    //     0x1297ec8: ubfx            x1, x1, #0xc, #0x14
    // 0x1297ecc: stp             x0, x2, [SP]
    // 0x1297ed0: mov             x0, x1
    // 0x1297ed4: mov             lr, x0
    // 0x1297ed8: ldr             lr, [x21, lr, lsl #3]
    // 0x1297edc: blr             lr
    // 0x1297ee0: b               #0x1297ee8
    // 0x1297ee4: r0 = false
    //     0x1297ee4: add             x0, NULL, #0x30  ; false
    // 0x1297ee8: LeaveFrame
    //     0x1297ee8: mov             SP, fp
    //     0x1297eec: ldp             fp, lr, [SP], #0x10
    // 0x1297ef0: ret
    //     0x1297ef0: ret             
    // 0x1297ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1297ef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1297ef8: b               #0x1297e10
  }
  _ isCloneOf(/* No info */) {
    // ** addr: 0x1303aa8, size: 0x94
    // 0x1303aa8: EnterFrame
    //     0x1303aa8: stp             fp, lr, [SP, #-0x10]!
    //     0x1303aac: mov             fp, SP
    // 0x1303ab0: AllocStack(0x10)
    //     0x1303ab0: sub             SP, SP, #0x10
    // 0x1303ab4: CheckStackOverflow
    //     0x1303ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303ab8: cmp             SP, x16
    //     0x1303abc: b.ls            #0x1303b34
    // 0x1303ac0: LoadField: r0 = r2->field_7
    //     0x1303ac0: ldur            w0, [x2, #7]
    // 0x1303ac4: DecompressPointer r0
    //     0x1303ac4: add             x0, x0, HEAP, lsl #32
    // 0x1303ac8: LoadField: r3 = r1->field_7
    //     0x1303ac8: ldur            w3, [x1, #7]
    // 0x1303acc: DecompressPointer r3
    //     0x1303acc: add             x3, x3, HEAP, lsl #32
    // 0x1303ad0: LoadField: r4 = r3->field_7
    //     0x1303ad0: ldur            w4, [x3, #7]
    // 0x1303ad4: DecompressPointer r4
    //     0x1303ad4: add             x4, x4, HEAP, lsl #32
    // 0x1303ad8: LoadField: r3 = r0->field_7
    //     0x1303ad8: ldur            w3, [x0, #7]
    // 0x1303adc: DecompressPointer r3
    //     0x1303adc: add             x3, x3, HEAP, lsl #32
    // 0x1303ae0: cmp             w4, w3
    // 0x1303ae4: b.ne            #0x1303b24
    // 0x1303ae8: LoadField: d0 = r1->field_b
    //     0x1303ae8: ldur            d0, [x1, #0xb]
    // 0x1303aec: fcmp            d0, d0
    // 0x1303af0: b.ne            #0x1303b24
    // 0x1303af4: LoadField: r0 = r2->field_13
    //     0x1303af4: ldur            w0, [x2, #0x13]
    // 0x1303af8: DecompressPointer r0
    //     0x1303af8: add             x0, x0, HEAP, lsl #32
    // 0x1303afc: LoadField: r2 = r1->field_13
    //     0x1303afc: ldur            w2, [x1, #0x13]
    // 0x1303b00: DecompressPointer r2
    //     0x1303b00: add             x2, x2, HEAP, lsl #32
    // 0x1303b04: r1 = LoadClassIdInstr(r0)
    //     0x1303b04: ldur            x1, [x0, #-1]
    //     0x1303b08: ubfx            x1, x1, #0xc, #0x14
    // 0x1303b0c: stp             x2, x0, [SP]
    // 0x1303b10: mov             x0, x1
    // 0x1303b14: mov             lr, x0
    // 0x1303b18: ldr             lr, [x21, lr, lsl #3]
    // 0x1303b1c: blr             lr
    // 0x1303b20: b               #0x1303b28
    // 0x1303b24: r0 = false
    //     0x1303b24: add             x0, NULL, #0x30  ; false
    // 0x1303b28: LeaveFrame
    //     0x1303b28: mov             SP, fp
    //     0x1303b2c: ldp             fp, lr, [SP], #0x10
    // 0x1303b30: ret
    //     0x1303b30: ret             
    // 0x1303b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1303b34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1303b38: b               #0x1303ac0
  }
}

// class id: 3591, size: 0xc, field offset: 0x8
class ImageStreamCompleterHandle extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x12e6e64, size: 0x74
    // 0x12e6e64: EnterFrame
    //     0x12e6e64: stp             fp, lr, [SP, #-0x10]!
    //     0x12e6e68: mov             fp, SP
    // 0x12e6e6c: AllocStack(0x8)
    //     0x12e6e6c: sub             SP, SP, #8
    // 0x12e6e70: SetupParameters(ImageStreamCompleterHandle this /* r1 => r2, fp-0x8 */)
    //     0x12e6e70: mov             x2, x1
    //     0x12e6e74: stur            x1, [fp, #-8]
    // 0x12e6e78: CheckStackOverflow
    //     0x12e6e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6e7c: cmp             SP, x16
    //     0x12e6e80: b.ls            #0x12e6ecc
    // 0x12e6e84: LoadField: r1 = r2->field_7
    //     0x12e6e84: ldur            w1, [x2, #7]
    // 0x12e6e88: DecompressPointer r1
    //     0x12e6e88: add             x1, x1, HEAP, lsl #32
    // 0x12e6e8c: cmp             w1, NULL
    // 0x12e6e90: b.eq            #0x12e6ed4
    // 0x12e6e94: LoadField: r0 = r1->field_1f
    //     0x12e6e94: ldur            x0, [x1, #0x1f]
    // 0x12e6e98: sub             x3, x0, #1
    // 0x12e6e9c: StoreField: r1->field_1f = r3
    //     0x12e6e9c: stur            x3, [x1, #0x1f]
    // 0x12e6ea0: r0 = LoadClassIdInstr(r1)
    //     0x12e6ea0: ldur            x0, [x1, #-1]
    //     0x12e6ea4: ubfx            x0, x0, #0xc, #0x14
    // 0x12e6ea8: r0 = GDT[cid_x0 + 0xe80]()
    //     0x12e6ea8: add             lr, x0, #0xe80
    //     0x12e6eac: ldr             lr, [x21, lr, lsl #3]
    //     0x12e6eb0: blr             lr
    // 0x12e6eb4: ldur            x1, [fp, #-8]
    // 0x12e6eb8: StoreField: r1->field_7 = rNULL
    //     0x12e6eb8: stur            NULL, [x1, #7]
    // 0x12e6ebc: r0 = Null
    //     0x12e6ebc: mov             x0, NULL
    // 0x12e6ec0: LeaveFrame
    //     0x12e6ec0: mov             SP, fp
    //     0x12e6ec4: ldp             fp, lr, [SP], #0x10
    // 0x12e6ec8: ret
    //     0x12e6ec8: ret             
    // 0x12e6ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6ecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e6ed0: b               #0x12e6e84
    // 0x12e6ed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12e6ed4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5044, size: 0x10, field offset: 0x8
class ImageStream extends _MixinApplication3&Object&Diagnosticable {

  _ setCompleter(/* No info */) {
    // ** addr: 0x91a7dc, size: 0x1c4
    // 0x91a7dc: EnterFrame
    //     0x91a7dc: stp             fp, lr, [SP, #-0x10]!
    //     0x91a7e0: mov             fp, SP
    // 0x91a7e4: AllocStack(0x38)
    //     0x91a7e4: sub             SP, SP, #0x38
    // 0x91a7e8: SetupParameters(ImageStream this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x91a7e8: mov             x3, x1
    //     0x91a7ec: stur            x1, [fp, #-0x10]
    //     0x91a7f0: mov             x1, x2
    // 0x91a7f4: CheckStackOverflow
    //     0x91a7f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a7f8: cmp             SP, x16
    //     0x91a7fc: b.ls            #0x91a988
    // 0x91a800: mov             x0, x1
    // 0x91a804: StoreField: r3->field_7 = r0
    //     0x91a804: stur            w0, [x3, #7]
    //     0x91a808: ldurb           w16, [x3, #-1]
    //     0x91a80c: ldurb           w17, [x0, #-1]
    //     0x91a810: and             x16, x17, x16, lsr #2
    //     0x91a814: tst             x16, HEAP, lsr #32
    //     0x91a818: b.eq            #0x91a820
    //     0x91a81c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x91a820: LoadField: r0 = r3->field_b
    //     0x91a820: ldur            w0, [x3, #0xb]
    // 0x91a824: DecompressPointer r0
    //     0x91a824: add             x0, x0, HEAP, lsl #32
    // 0x91a828: stur            x0, [fp, #-8]
    // 0x91a82c: cmp             w0, NULL
    // 0x91a830: b.eq            #0x91a95c
    // 0x91a834: r2 = true
    //     0x91a834: add             x2, NULL, #0x20  ; true
    // 0x91a838: StoreField: r3->field_b = rNULL
    //     0x91a838: stur            NULL, [x3, #0xb]
    // 0x91a83c: StoreField: r1->field_1b = r2
    //     0x91a83c: stur            w2, [x1, #0x1b]
    // 0x91a840: r2 = LoadClassIdInstr(r1)
    //     0x91a840: ldur            x2, [x1, #-1]
    //     0x91a844: ubfx            x2, x2, #0xc, #0x14
    // 0x91a848: r17 = -5245
    //     0x91a848: mov             x17, #-0x147d
    // 0x91a84c: add             x16, x2, x17
    // 0x91a850: cmp             x16, #1
    // 0x91a854: b.hi            #0x91a870
    // 0x91a858: mov             x2, x1
    // 0x91a85c: r1 = Function 'addListener':.
    //     0x91a85c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81380] AnonymousClosure: (0x91aa18), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener (0x124a354)
    //     0x91a860: ldr             x1, [x1, #0x380]
    // 0x91a864: r0 = AllocateClosure()
    //     0x91a864: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91a868: mov             x3, x0
    // 0x91a86c: b               #0x91a8a8
    // 0x91a870: r17 = 5244
    //     0x91a870: mov             x17, #0x147c
    // 0x91a874: cmp             x2, x17
    // 0x91a878: b.ne            #0x91a894
    // 0x91a87c: mov             x2, x1
    // 0x91a880: r1 = Function 'addListener':.
    //     0x91a880: add             x1, PP, #0x81, lsl #12  ; [pp+0x81388] AnonymousClosure: (0x91a9dc), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::addListener (0x124a604)
    //     0x91a884: ldr             x1, [x1, #0x388]
    // 0x91a888: r0 = AllocateClosure()
    //     0x91a888: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91a88c: mov             x3, x0
    // 0x91a890: b               #0x91a8a8
    // 0x91a894: mov             x2, x1
    // 0x91a898: r1 = Function 'addListener':.
    //     0x91a898: add             x1, PP, #0x81, lsl #12  ; [pp+0x81390] AnonymousClosure: (0x91a9a0), in [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::addListener (0x124a2dc)
    //     0x91a89c: ldr             x1, [x1, #0x390]
    // 0x91a8a0: r0 = AllocateClosure()
    //     0x91a8a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91a8a4: mov             x3, x0
    // 0x91a8a8: ldur            x2, [fp, #-8]
    // 0x91a8ac: stur            x3, [fp, #-0x28]
    // 0x91a8b0: LoadField: r4 = r2->field_b
    //     0x91a8b0: ldur            w4, [x2, #0xb]
    // 0x91a8b4: stur            x4, [fp, #-0x20]
    // 0x91a8b8: r0 = LoadInt32Instr(r4)
    //     0x91a8b8: sbfx            x0, x4, #1, #0x1f
    // 0x91a8bc: r5 = 0
    //     0x91a8bc: mov             x5, #0
    // 0x91a8c0: stur            x5, [fp, #-0x18]
    // 0x91a8c4: CheckStackOverflow
    //     0x91a8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a8c8: cmp             SP, x16
    //     0x91a8cc: b.ls            #0x91a990
    // 0x91a8d0: cmp             x5, x0
    // 0x91a8d4: b.ge            #0x91a940
    // 0x91a8d8: mov             x1, x5
    // 0x91a8dc: cmp             x1, x0
    // 0x91a8e0: b.hs            #0x91a998
    // 0x91a8e4: LoadField: r0 = r2->field_f
    //     0x91a8e4: ldur            w0, [x2, #0xf]
    // 0x91a8e8: DecompressPointer r0
    //     0x91a8e8: add             x0, x0, HEAP, lsl #32
    // 0x91a8ec: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x91a8ec: add             x16, x0, x5, lsl #2
    //     0x91a8f0: ldur            w1, [x16, #0xf]
    // 0x91a8f4: DecompressPointer r1
    //     0x91a8f4: add             x1, x1, HEAP, lsl #32
    // 0x91a8f8: stp             x1, x3, [SP]
    // 0x91a8fc: mov             x0, x3
    // 0x91a900: ClosureCall
    //     0x91a900: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x91a904: ldur            x2, [x0, #0x1f]
    //     0x91a908: blr             x2
    // 0x91a90c: ldur            x1, [fp, #-8]
    // 0x91a910: LoadField: r0 = r1->field_b
    //     0x91a910: ldur            w0, [x1, #0xb]
    // 0x91a914: ldur            x2, [fp, #-0x20]
    // 0x91a918: cmp             w0, w2
    // 0x91a91c: b.ne            #0x91a96c
    // 0x91a920: ldur            x3, [fp, #-0x18]
    // 0x91a924: add             x5, x3, #1
    // 0x91a928: r3 = LoadInt32Instr(r0)
    //     0x91a928: sbfx            x3, x0, #1, #0x1f
    // 0x91a92c: mov             x0, x3
    // 0x91a930: mov             x4, x2
    // 0x91a934: mov             x2, x1
    // 0x91a938: ldur            x3, [fp, #-0x28]
    // 0x91a93c: b               #0x91a8c0
    // 0x91a940: ldur            x0, [fp, #-0x10]
    // 0x91a944: r1 = false
    //     0x91a944: add             x1, NULL, #0x30  ; false
    // 0x91a948: LoadField: r2 = r0->field_7
    //     0x91a948: ldur            w2, [x0, #7]
    // 0x91a94c: DecompressPointer r2
    //     0x91a94c: add             x2, x2, HEAP, lsl #32
    // 0x91a950: cmp             w2, NULL
    // 0x91a954: b.eq            #0x91a99c
    // 0x91a958: StoreField: r2->field_1b = r1
    //     0x91a958: stur            w1, [x2, #0x1b]
    // 0x91a95c: r0 = Null
    //     0x91a95c: mov             x0, NULL
    // 0x91a960: LeaveFrame
    //     0x91a960: mov             SP, fp
    //     0x91a964: ldp             fp, lr, [SP], #0x10
    // 0x91a968: ret
    //     0x91a968: ret             
    // 0x91a96c: r0 = ConcurrentModificationError()
    //     0x91a96c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x91a970: mov             x1, x0
    // 0x91a974: ldur            x0, [fp, #-8]
    // 0x91a978: StoreField: r1->field_b = r0
    //     0x91a978: stur            w0, [x1, #0xb]
    // 0x91a97c: mov             x0, x1
    // 0x91a980: r0 = Throw()
    //     0x91a980: bl              #0x13ddb2c  ; ThrowStub
    // 0x91a984: brk             #0
    // 0x91a988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a98c: b               #0x91a800
    // 0x91a990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a994: b               #0x91a8d0
    // 0x91a998: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91a998: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x91a99c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a99c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd07ce0, size: 0x1fc
    // 0xd07ce0: EnterFrame
    //     0xd07ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xd07ce4: mov             fp, SP
    // 0xd07ce8: AllocStack(0x20)
    //     0xd07ce8: sub             SP, SP, #0x20
    // 0xd07cec: SetupParameters(ImageStream this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd07cec: mov             x0, x1
    //     0xd07cf0: stur            x2, [fp, #-0x10]
    //     0xd07cf4: stur            x1, [fp, #-0x18]
    // 0xd07cf8: CheckStackOverflow
    //     0xd07cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd07cfc: cmp             SP, x16
    //     0xd07d00: b.ls            #0xd07ed4
    // 0xd07d04: LoadField: r3 = r0->field_7
    //     0xd07d04: ldur            w3, [x0, #7]
    // 0xd07d08: DecompressPointer r3
    //     0xd07d08: add             x3, x3, HEAP, lsl #32
    // 0xd07d0c: stur            x3, [fp, #-8]
    // 0xd07d10: cmp             w3, NULL
    // 0xd07d14: b.eq            #0xd07dfc
    // 0xd07d18: r0 = LoadClassIdInstr(r3)
    //     0xd07d18: ldur            x0, [x3, #-1]
    //     0xd07d1c: ubfx            x0, x0, #0xc, #0x14
    // 0xd07d20: r17 = 5244
    //     0xd07d20: mov             x17, #0x147c
    // 0xd07d24: cmp             x0, x17
    // 0xd07d28: b.ne            #0xd07d80
    // 0xd07d2c: LoadField: r0 = r3->field_7
    //     0xd07d2c: ldur            w0, [x3, #7]
    // 0xd07d30: DecompressPointer r0
    //     0xd07d30: add             x0, x0, HEAP, lsl #32
    // 0xd07d34: LoadField: r1 = r0->field_b
    //     0xd07d34: ldur            w1, [x0, #0xb]
    // 0xd07d38: cbnz            w1, #0xd07d70
    // 0xd07d3c: LoadField: r1 = r3->field_33
    //     0xd07d3c: ldur            w1, [x3, #0x33]
    // 0xd07d40: DecompressPointer r1
    //     0xd07d40: add             x1, x1, HEAP, lsl #32
    // 0xd07d44: cmp             w1, NULL
    // 0xd07d48: b.eq            #0xd07d70
    // 0xd07d4c: LoadField: r0 = r3->field_f
    //     0xd07d4c: ldur            w0, [x3, #0xf]
    // 0xd07d50: DecompressPointer r0
    //     0xd07d50: add             x0, x0, HEAP, lsl #32
    // 0xd07d54: cmp             w0, NULL
    // 0xd07d58: b.eq            #0xd07d68
    // 0xd07d5c: r0 = frameCount()
    //     0xd07d5c: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd07d60: cmp             x0, #1
    // 0xd07d64: b.le            #0xd07d70
    // 0xd07d68: ldur            x1, [fp, #-8]
    // 0xd07d6c: r0 = _decodeNextFrameAndSchedule()
    //     0xd07d6c: bl              #0xd08bb4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xd07d70: ldur            x1, [fp, #-8]
    // 0xd07d74: ldur            x2, [fp, #-0x10]
    // 0xd07d78: r0 = addListener()
    //     0xd07d78: bl              #0x124a354  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0xd07d7c: b               #0xd07dec
    // 0xd07d80: r17 = 5247
    //     0xd07d80: mov             x17, #0x147f
    // 0xd07d84: cmp             x0, x17
    // 0xd07d88: b.ne            #0xd07dd0
    // 0xd07d8c: ldur            x0, [fp, #-8]
    // 0xd07d90: r1 = true
    //     0xd07d90: add             x1, NULL, #0x20  ; true
    // 0xd07d94: StoreField: r0->field_63 = r1
    //     0xd07d94: stur            w1, [x0, #0x63]
    // 0xd07d98: LoadField: r1 = r0->field_7
    //     0xd07d98: ldur            w1, [x0, #7]
    // 0xd07d9c: DecompressPointer r1
    //     0xd07d9c: add             x1, x1, HEAP, lsl #32
    // 0xd07da0: LoadField: r2 = r1->field_b
    //     0xd07da0: ldur            w2, [x1, #0xb]
    // 0xd07da4: cbnz            w2, #0xd07dc0
    // 0xd07da8: LoadField: r1 = r0->field_2f
    //     0xd07da8: ldur            w1, [x0, #0x2f]
    // 0xd07dac: DecompressPointer r1
    //     0xd07dac: add             x1, x1, HEAP, lsl #32
    // 0xd07db0: cmp             w1, NULL
    // 0xd07db4: b.eq            #0xd07dc0
    // 0xd07db8: mov             x1, x0
    // 0xd07dbc: r0 = _decodeNextFrameAndSchedule()
    //     0xd07dbc: bl              #0xd07edc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xd07dc0: ldur            x1, [fp, #-8]
    // 0xd07dc4: ldur            x2, [fp, #-0x10]
    // 0xd07dc8: r0 = addListener()
    //     0xd07dc8: bl              #0x124a354  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0xd07dcc: b               #0xd07dec
    // 0xd07dd0: ldur            x1, [fp, #-8]
    // 0xd07dd4: r0 = LoadClassIdInstr(r1)
    //     0xd07dd4: ldur            x0, [x1, #-1]
    //     0xd07dd8: ubfx            x0, x0, #0xc, #0x14
    // 0xd07ddc: ldur            x2, [fp, #-0x10]
    // 0xd07de0: r0 = GDT[cid_x0 + 0xe1d]()
    //     0xd07de0: add             lr, x0, #0xe1d
    //     0xd07de4: ldr             lr, [x21, lr, lsl #3]
    //     0xd07de8: blr             lr
    // 0xd07dec: r0 = Null
    //     0xd07dec: mov             x0, NULL
    // 0xd07df0: LeaveFrame
    //     0xd07df0: mov             SP, fp
    //     0xd07df4: ldp             fp, lr, [SP], #0x10
    // 0xd07df8: ret
    //     0xd07df8: ret             
    // 0xd07dfc: LoadField: r1 = r0->field_b
    //     0xd07dfc: ldur            w1, [x0, #0xb]
    // 0xd07e00: DecompressPointer r1
    //     0xd07e00: add             x1, x1, HEAP, lsl #32
    // 0xd07e04: cmp             w1, NULL
    // 0xd07e08: b.ne            #0xd07e48
    // 0xd07e0c: r1 = <ImageStreamListener>
    //     0xd07e0c: add             x1, PP, #0x81, lsl #12  ; [pp+0x813e0] TypeArguments: <ImageStreamListener>
    //     0xd07e10: ldr             x1, [x1, #0x3e0]
    // 0xd07e14: r2 = 0
    //     0xd07e14: mov             x2, #0
    // 0xd07e18: r0 = _GrowableList()
    //     0xd07e18: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd07e1c: mov             x2, x0
    // 0xd07e20: ldur            x1, [fp, #-0x18]
    // 0xd07e24: StoreField: r1->field_b = r0
    //     0xd07e24: stur            w0, [x1, #0xb]
    //     0xd07e28: ldurb           w16, [x1, #-1]
    //     0xd07e2c: ldurb           w17, [x0, #-1]
    //     0xd07e30: and             x16, x17, x16, lsr #2
    //     0xd07e34: tst             x16, HEAP, lsr #32
    //     0xd07e38: b.eq            #0xd07e40
    //     0xd07e3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd07e40: mov             x0, x2
    // 0xd07e44: b               #0xd07e4c
    // 0xd07e48: mov             x0, x1
    // 0xd07e4c: stur            x0, [fp, #-8]
    // 0xd07e50: LoadField: r1 = r0->field_b
    //     0xd07e50: ldur            w1, [x0, #0xb]
    // 0xd07e54: LoadField: r2 = r0->field_f
    //     0xd07e54: ldur            w2, [x0, #0xf]
    // 0xd07e58: DecompressPointer r2
    //     0xd07e58: add             x2, x2, HEAP, lsl #32
    // 0xd07e5c: LoadField: r3 = r2->field_b
    //     0xd07e5c: ldur            w3, [x2, #0xb]
    // 0xd07e60: r2 = LoadInt32Instr(r1)
    //     0xd07e60: sbfx            x2, x1, #1, #0x1f
    // 0xd07e64: stur            x2, [fp, #-0x20]
    // 0xd07e68: r1 = LoadInt32Instr(r3)
    //     0xd07e68: sbfx            x1, x3, #1, #0x1f
    // 0xd07e6c: cmp             x2, x1
    // 0xd07e70: b.ne            #0xd07e7c
    // 0xd07e74: mov             x1, x0
    // 0xd07e78: r0 = _growToNextCapacity()
    //     0xd07e78: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd07e7c: ldur            x3, [fp, #-0x20]
    // 0xd07e80: ldur            x2, [fp, #-8]
    // 0xd07e84: add             x4, x3, #1
    // 0xd07e88: lsl             x5, x4, #1
    // 0xd07e8c: StoreField: r2->field_b = r5
    //     0xd07e8c: stur            w5, [x2, #0xb]
    // 0xd07e90: LoadField: r1 = r2->field_f
    //     0xd07e90: ldur            w1, [x2, #0xf]
    // 0xd07e94: DecompressPointer r1
    //     0xd07e94: add             x1, x1, HEAP, lsl #32
    // 0xd07e98: ldur            x0, [fp, #-0x10]
    // 0xd07e9c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd07e9c: add             x25, x1, x3, lsl #2
    //     0xd07ea0: add             x25, x25, #0xf
    //     0xd07ea4: str             w0, [x25]
    //     0xd07ea8: tbz             w0, #0, #0xd07ec4
    //     0xd07eac: ldurb           w16, [x1, #-1]
    //     0xd07eb0: ldurb           w17, [x0, #-1]
    //     0xd07eb4: and             x16, x17, x16, lsr #2
    //     0xd07eb8: tst             x16, HEAP, lsr #32
    //     0xd07ebc: b.eq            #0xd07ec4
    //     0xd07ec0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd07ec4: r0 = Null
    //     0xd07ec4: mov             x0, NULL
    // 0xd07ec8: LeaveFrame
    //     0xd07ec8: mov             SP, fp
    //     0xd07ecc: ldp             fp, lr, [SP], #0x10
    // 0xd07ed0: ret
    //     0xd07ed0: ret             
    // 0xd07ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd07ed4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd07ed8: b               #0xd07d04
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xd09490, size: 0x1ac
    // 0xd09490: EnterFrame
    //     0xd09490: stp             fp, lr, [SP, #-0x10]!
    //     0xd09494: mov             fp, SP
    // 0xd09498: AllocStack(0x30)
    //     0xd09498: sub             SP, SP, #0x30
    // 0xd0949c: SetupParameters(ImageStream this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xd0949c: stur            x1, [fp, #-0x18]
    //     0xd094a0: stur            x2, [fp, #-0x20]
    // 0xd094a4: CheckStackOverflow
    //     0xd094a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd094a8: cmp             SP, x16
    //     0xd094ac: b.ls            #0xd09624
    // 0xd094b0: LoadField: r0 = r1->field_7
    //     0xd094b0: ldur            w0, [x1, #7]
    // 0xd094b4: DecompressPointer r0
    //     0xd094b4: add             x0, x0, HEAP, lsl #32
    // 0xd094b8: stur            x0, [fp, #-8]
    // 0xd094bc: cmp             w0, NULL
    // 0xd094c0: b.eq            #0xd09590
    // 0xd094c4: r1 = LoadClassIdInstr(r0)
    //     0xd094c4: ldur            x1, [x0, #-1]
    //     0xd094c8: ubfx            x1, x1, #0xc, #0x14
    // 0xd094cc: r17 = 5244
    //     0xd094cc: mov             x17, #0x147c
    // 0xd094d0: cmp             x1, x17
    // 0xd094d4: b.ne            #0xd09514
    // 0xd094d8: mov             x1, x0
    // 0xd094dc: r0 = removeListener()
    //     0xd094dc: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0xd094e0: ldur            x0, [fp, #-8]
    // 0xd094e4: LoadField: r1 = r0->field_7
    //     0xd094e4: ldur            w1, [x0, #7]
    // 0xd094e8: DecompressPointer r1
    //     0xd094e8: add             x1, x1, HEAP, lsl #32
    // 0xd094ec: LoadField: r2 = r1->field_b
    //     0xd094ec: ldur            w2, [x1, #0xb]
    // 0xd094f0: cbnz            w2, #0xd09580
    // 0xd094f4: LoadField: r1 = r0->field_57
    //     0xd094f4: ldur            w1, [x0, #0x57]
    // 0xd094f8: DecompressPointer r1
    //     0xd094f8: add             x1, x1, HEAP, lsl #32
    // 0xd094fc: cmp             w1, NULL
    // 0xd09500: b.eq            #0xd0950c
    // 0xd09504: r0 = cancel()
    //     0xd09504: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xd09508: ldur            x0, [fp, #-8]
    // 0xd0950c: StoreField: r0->field_57 = rNULL
    //     0xd0950c: stur            NULL, [x0, #0x57]
    // 0xd09510: b               #0xd09580
    // 0xd09514: r17 = 5247
    //     0xd09514: mov             x17, #0x147f
    // 0xd09518: cmp             x1, x17
    // 0xd0951c: b.ne            #0xd09568
    // 0xd09520: mov             x1, x0
    // 0xd09524: r0 = removeListener()
    //     0xd09524: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0xd09528: ldur            x0, [fp, #-8]
    // 0xd0952c: LoadField: r1 = r0->field_7
    //     0xd0952c: ldur            w1, [x0, #7]
    // 0xd09530: DecompressPointer r1
    //     0xd09530: add             x1, x1, HEAP, lsl #32
    // 0xd09534: LoadField: r2 = r1->field_b
    //     0xd09534: ldur            w2, [x1, #0xb]
    // 0xd09538: cbnz            w2, #0xd09580
    // 0xd0953c: LoadField: r1 = r0->field_57
    //     0xd0953c: ldur            w1, [x0, #0x57]
    // 0xd09540: DecompressPointer r1
    //     0xd09540: add             x1, x1, HEAP, lsl #32
    // 0xd09544: cmp             w1, NULL
    // 0xd09548: b.ne            #0xd09554
    // 0xd0954c: mov             x1, x0
    // 0xd09550: b               #0xd0955c
    // 0xd09554: r0 = cancel()
    //     0xd09554: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xd09558: ldur            x1, [fp, #-8]
    // 0xd0955c: StoreField: r1->field_57 = rNULL
    //     0xd0955c: stur            NULL, [x1, #0x57]
    // 0xd09560: r0 = __maybeDispose()
    //     0xd09560: bl              #0x87c6d8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::__maybeDispose
    // 0xd09564: b               #0xd09580
    // 0xd09568: mov             x1, x0
    // 0xd0956c: r0 = LoadClassIdInstr(r1)
    //     0xd0956c: ldur            x0, [x1, #-1]
    //     0xd09570: ubfx            x0, x0, #0xc, #0x14
    // 0xd09574: r0 = GDT[cid_x0 + 0x949]()
    //     0xd09574: add             lr, x0, #0x949
    //     0xd09578: ldr             lr, [x21, lr, lsl #3]
    //     0xd0957c: blr             lr
    // 0xd09580: r0 = Null
    //     0xd09580: mov             x0, NULL
    // 0xd09584: LeaveFrame
    //     0xd09584: mov             SP, fp
    //     0xd09588: ldp             fp, lr, [SP], #0x10
    // 0xd0958c: ret
    //     0xd0958c: ret             
    // 0xd09590: r0 = 0
    //     0xd09590: mov             x0, #0
    // 0xd09594: stur            x0, [fp, #-0x10]
    // 0xd09598: CheckStackOverflow
    //     0xd09598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0959c: cmp             SP, x16
    //     0xd095a0: b.ls            #0xd0962c
    // 0xd095a4: LoadField: r3 = r1->field_b
    //     0xd095a4: ldur            w3, [x1, #0xb]
    // 0xd095a8: DecompressPointer r3
    //     0xd095a8: add             x3, x3, HEAP, lsl #32
    // 0xd095ac: cmp             w3, NULL
    // 0xd095b0: b.eq            #0xd09634
    // 0xd095b4: LoadField: r4 = r3->field_b
    //     0xd095b4: ldur            w4, [x3, #0xb]
    // 0xd095b8: r5 = LoadInt32Instr(r4)
    //     0xd095b8: sbfx            x5, x4, #1, #0x1f
    // 0xd095bc: cmp             x0, x5
    // 0xd095c0: b.ge            #0xd09614
    // 0xd095c4: LoadField: r4 = r3->field_f
    //     0xd095c4: ldur            w4, [x3, #0xf]
    // 0xd095c8: DecompressPointer r4
    //     0xd095c8: add             x4, x4, HEAP, lsl #32
    // 0xd095cc: ArrayLoad: r3 = r4[r0]  ; Unknown_4
    //     0xd095cc: add             x16, x4, x0, lsl #2
    //     0xd095d0: ldur            w3, [x16, #0xf]
    // 0xd095d4: DecompressPointer r3
    //     0xd095d4: add             x3, x3, HEAP, lsl #32
    // 0xd095d8: stp             x2, x3, [SP]
    // 0xd095dc: r0 = ==()
    //     0xd095dc: bl              #0x12994cc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamListener::==
    // 0xd095e0: tbz             w0, #4, #0xd095f8
    // 0xd095e4: ldur            x2, [fp, #-0x10]
    // 0xd095e8: add             x0, x2, #1
    // 0xd095ec: ldur            x1, [fp, #-0x18]
    // 0xd095f0: ldur            x2, [fp, #-0x20]
    // 0xd095f4: b               #0xd09594
    // 0xd095f8: ldur            x0, [fp, #-0x18]
    // 0xd095fc: ldur            x2, [fp, #-0x10]
    // 0xd09600: LoadField: r1 = r0->field_b
    //     0xd09600: ldur            w1, [x0, #0xb]
    // 0xd09604: DecompressPointer r1
    //     0xd09604: add             x1, x1, HEAP, lsl #32
    // 0xd09608: cmp             w1, NULL
    // 0xd0960c: b.eq            #0xd09638
    // 0xd09610: r0 = removeAt()
    //     0xd09610: bl              #0x9fac48  ; [dart:core] _GrowableList::removeAt
    // 0xd09614: r0 = Null
    //     0xd09614: mov             x0, NULL
    // 0xd09618: LeaveFrame
    //     0xd09618: mov             SP, fp
    //     0xd0961c: ldp             fp, lr, [SP], #0x10
    // 0xd09620: ret
    //     0xd09620: ret             
    // 0xd09624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd09624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd09628: b               #0xd094b0
    // 0xd0962c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0962c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd09630: b               #0xd095a4
    // 0xd09634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09634: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd09638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09638: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5045, size: 0x14, field offset: 0x8
//   const constructor, 
class ImageChunkEvent extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5243, size: 0x30, field offset: 0x8
abstract class ImageStreamCompleter extends _MixinApplication3&Object&Diagnosticable {

  _ reportError(/* No info */) {
    // ** addr: 0x91a2a0, size: 0x51c
    // 0x91a2a0: EnterFrame
    //     0x91a2a0: stp             fp, lr, [SP, #-0x10]!
    //     0x91a2a4: mov             fp, SP
    // 0x91a2a8: AllocStack(0x128)
    //     0x91a2a8: sub             SP, SP, #0x128
    // 0x91a2ac: SetupParameters(ImageStreamCompleter this /* r1 => r1, fp-0xc8 */, dynamic _ /* r2 => r2, fp-0xd0 */, dynamic _ /* r3 => r3, fp-0xd8 */, dynamic _ /* r5 => r5, fp-0xe0 */, {dynamic informationCollector = Null /* r7, fp-0xc0 */, dynamic silent = false /* r0, fp-0xb8 */})
    //     0x91a2ac: stur            x1, [fp, #-0xc8]
    //     0x91a2b0: stur            x2, [fp, #-0xd0]
    //     0x91a2b4: stur            x3, [fp, #-0xd8]
    //     0x91a2b8: stur            x5, [fp, #-0xe0]
    //     0x91a2bc: ldur            w0, [x4, #0x13]
    //     0x91a2c0: ldur            w6, [x4, #0x1f]
    //     0x91a2c4: add             x6, x6, HEAP, lsl #32
    //     0x91a2c8: ldr             x16, [PP, #0x22d8]  ; [pp+0x22d8] "informationCollector"
    //     0x91a2cc: cmp             w6, w16
    //     0x91a2d0: b.ne            #0x91a2f4
    //     0x91a2d4: ldur            w6, [x4, #0x23]
    //     0x91a2d8: add             x6, x6, HEAP, lsl #32
    //     0x91a2dc: sub             w7, w0, w6
    //     0x91a2e0: add             x6, fp, w7, sxtw #2
    //     0x91a2e4: ldr             x6, [x6, #8]
    //     0x91a2e8: mov             x7, x6
    //     0x91a2ec: mov             x6, #1
    //     0x91a2f0: b               #0x91a2fc
    //     0x91a2f4: mov             x7, NULL
    //     0x91a2f8: mov             x6, #0
    //     0x91a2fc: stur            x7, [fp, #-0xc0]
    //     0x91a300: lsl             x8, x6, #1
    //     0x91a304: lsl             w6, w8, #1
    //     0x91a308: add             w8, w6, #8
    //     0x91a30c: add             x16, x4, w8, sxtw #1
    //     0x91a310: ldur            w9, [x16, #0xf]
    //     0x91a314: add             x9, x9, HEAP, lsl #32
    //     0x91a318: add             x16, PP, #8, lsl #12  ; [pp+0x8348] "silent"
    //     0x91a31c: ldr             x16, [x16, #0x348]
    //     0x91a320: cmp             w9, w16
    //     0x91a324: b.ne            #0x91a348
    //     0x91a328: add             w8, w6, #0xa
    //     0x91a32c: add             x16, x4, w8, sxtw #1
    //     0x91a330: ldur            w6, [x16, #0xf]
    //     0x91a334: add             x6, x6, HEAP, lsl #32
    //     0x91a338: sub             w4, w0, w6
    //     0x91a33c: add             x0, fp, w4, sxtw #2
    //     0x91a340: ldr             x0, [x0, #8]
    //     0x91a344: b               #0x91a34c
    //     0x91a348: add             x0, NULL, #0x30  ; false
    //     0x91a34c: stur            x0, [fp, #-0xb8]
    // 0x91a350: CheckStackOverflow
    //     0x91a350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a354: cmp             SP, x16
    //     0x91a358: b.ls            #0x91a7a8
    // 0x91a35c: r0 = FlutterErrorDetails()
    //     0x91a35c: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x91a360: ldur            x3, [fp, #-0xd8]
    // 0x91a364: StoreField: r0->field_7 = r3
    //     0x91a364: stur            w3, [x0, #7]
    // 0x91a368: ldur            x4, [fp, #-0xe0]
    // 0x91a36c: StoreField: r0->field_b = r4
    //     0x91a36c: stur            w4, [x0, #0xb]
    // 0x91a370: r5 = "image resource service"
    //     0x91a370: ldr             x5, [PP, #0x7da8]  ; [pp+0x7da8] "image resource service"
    // 0x91a374: StoreField: r0->field_f = r5
    //     0x91a374: stur            w5, [x0, #0xf]
    // 0x91a378: ldur            x1, [fp, #-0xd0]
    // 0x91a37c: StoreField: r0->field_13 = r1
    //     0x91a37c: stur            w1, [x0, #0x13]
    // 0x91a380: ldur            x1, [fp, #-0xc0]
    // 0x91a384: ArrayStore: r0[0] = r1  ; List_4
    //     0x91a384: stur            w1, [x0, #0x17]
    // 0x91a388: ldur            x1, [fp, #-0xb8]
    // 0x91a38c: StoreField: r0->field_1b = r1
    //     0x91a38c: stur            w1, [x0, #0x1b]
    // 0x91a390: ldur            x6, [fp, #-0xc8]
    // 0x91a394: StoreField: r6->field_13 = r0
    //     0x91a394: stur            w0, [x6, #0x13]
    //     0x91a398: ldurb           w16, [x6, #-1]
    //     0x91a39c: ldurb           w17, [x0, #-1]
    //     0x91a3a0: and             x16, x17, x16, lsr #2
    //     0x91a3a4: tst             x16, HEAP, lsr #32
    //     0x91a3a8: b.eq            #0x91a3b0
    //     0x91a3ac: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x91a3b0: LoadField: r0 = r6->field_7
    //     0x91a3b0: ldur            w0, [x6, #7]
    // 0x91a3b4: DecompressPointer r0
    //     0x91a3b4: add             x0, x0, HEAP, lsl #32
    // 0x91a3b8: stur            x0, [fp, #-0xb8]
    // 0x91a3bc: r1 = Function '<anonymous closure>':.
    //     0x91a3bc: add             x1, PP, #0x81, lsl #12  ; [pp+0x81338] Function: [package:flutter/src/widgets/icon_data.dart] IconData::fontFamily (0x12dc910)
    //     0x91a3c0: ldr             x1, [x1, #0x338]
    // 0x91a3c4: r2 = Null
    //     0x91a3c4: mov             x2, NULL
    // 0x91a3c8: r0 = AllocateClosure()
    //     0x91a3c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x91a3cc: r16 = <((dynamic this, Object, StackTrace?) => void?)?>
    //     0x91a3cc: add             x16, PP, #0x81, lsl #12  ; [pp+0x81340] TypeArguments: <((dynamic this, Object, StackTrace?) => void?)?>
    //     0x91a3d0: ldr             x16, [x16, #0x340]
    // 0x91a3d4: ldur            lr, [fp, #-0xb8]
    // 0x91a3d8: stp             lr, x16, [SP, #8]
    // 0x91a3dc: str             x0, [SP]
    // 0x91a3e0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x91a3e0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x91a3e4: r0 = map()
    //     0x91a3e4: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x91a3e8: r16 = <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a3e8: add             x16, PP, #0x81, lsl #12  ; [pp+0x81348] TypeArguments: <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a3ec: ldr             x16, [x16, #0x348]
    // 0x91a3f0: stp             x0, x16, [SP]
    // 0x91a3f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x91a3f4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x91a3f8: r0 = whereType()
    //     0x91a3f8: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x91a3fc: mov             x3, x0
    // 0x91a400: r2 = Null
    //     0x91a400: mov             x2, NULL
    // 0x91a404: r1 = Null
    //     0x91a404: mov             x1, NULL
    // 0x91a408: stur            x3, [fp, #-0xb8]
    // 0x91a40c: cmp             w0, NULL
    // 0x91a410: b.eq            #0x91a4a8
    // 0x91a414: branchIfSmi(r0, 0x91a4a8)
    //     0x91a414: tbz             w0, #0, #0x91a4a8
    // 0x91a418: r3 = LoadClassIdInstr(r0)
    //     0x91a418: ldur            x3, [x0, #-1]
    //     0x91a41c: ubfx            x3, x3, #0xc, #0x14
    // 0x91a420: r17 = 7724
    //     0x91a420: mov             x17, #0x1e2c
    // 0x91a424: cmp             x3, x17
    // 0x91a428: b.eq            #0x91a4b0
    // 0x91a42c: r4 = LoadClassIdInstr(r0)
    //     0x91a42c: ldur            x4, [x0, #-1]
    //     0x91a430: ubfx            x4, x4, #0xc, #0x14
    // 0x91a434: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x91a438: ldr             x3, [x3, #0x18]
    // 0x91a43c: ldr             x3, [x3, x4, lsl #3]
    // 0x91a440: LoadField: r3 = r3->field_2b
    //     0x91a440: ldur            w3, [x3, #0x2b]
    // 0x91a444: DecompressPointer r3
    //     0x91a444: add             x3, x3, HEAP, lsl #32
    // 0x91a448: cmp             w3, NULL
    // 0x91a44c: b.eq            #0x91a4a8
    // 0x91a450: LoadField: r3 = r3->field_f
    //     0x91a450: ldur            w3, [x3, #0xf]
    // 0x91a454: lsr             x3, x3, #3
    // 0x91a458: r17 = 7724
    //     0x91a458: mov             x17, #0x1e2c
    // 0x91a45c: cmp             x3, x17
    // 0x91a460: b.eq            #0x91a4b0
    // 0x91a464: r3 = SubtypeTestCache
    //     0x91a464: add             x3, PP, #0x81, lsl #12  ; [pp+0x81350] SubtypeTestCache
    //     0x91a468: ldr             x3, [x3, #0x350]
    // 0x91a46c: r30 = Subtype1TestCacheStub
    //     0x91a46c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x91a470: LoadField: r30 = r30->field_7
    //     0x91a470: ldur            lr, [lr, #7]
    // 0x91a474: blr             lr
    // 0x91a478: cmp             w7, NULL
    // 0x91a47c: b.eq            #0x91a488
    // 0x91a480: tbnz            w7, #4, #0x91a4a8
    // 0x91a484: b               #0x91a4b0
    // 0x91a488: r8 = EfficientLengthIterable
    //     0x91a488: add             x8, PP, #0x81, lsl #12  ; [pp+0x81358] Type: EfficientLengthIterable
    //     0x91a48c: ldr             x8, [x8, #0x358]
    // 0x91a490: r3 = SubtypeTestCache
    //     0x91a490: add             x3, PP, #0x81, lsl #12  ; [pp+0x81360] SubtypeTestCache
    //     0x91a494: ldr             x3, [x3, #0x360]
    // 0x91a498: r30 = InstanceOfStub
    //     0x91a498: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x91a49c: LoadField: r30 = r30->field_7
    //     0x91a49c: ldur            lr, [lr, #7]
    // 0x91a4a0: blr             lr
    // 0x91a4a4: b               #0x91a4b4
    // 0x91a4a8: r0 = false
    //     0x91a4a8: add             x0, NULL, #0x30  ; false
    // 0x91a4ac: b               #0x91a4b4
    // 0x91a4b0: r0 = true
    //     0x91a4b0: add             x0, NULL, #0x20  ; true
    // 0x91a4b4: tbnz            w0, #4, #0x91a4d0
    // 0x91a4b8: ldur            x2, [fp, #-0xb8]
    // 0x91a4bc: r1 = <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a4bc: add             x1, PP, #0x81, lsl #12  ; [pp+0x81348] TypeArguments: <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a4c0: ldr             x1, [x1, #0x348]
    // 0x91a4c4: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x91a4c4: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x91a4c8: mov             x3, x0
    // 0x91a4cc: b               #0x91a4e4
    // 0x91a4d0: ldur            x2, [fp, #-0xb8]
    // 0x91a4d4: r1 = <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a4d4: add             x1, PP, #0x81, lsl #12  ; [pp+0x81348] TypeArguments: <(dynamic this, Object, StackTrace?) => void?>
    //     0x91a4d8: ldr             x1, [x1, #0x348]
    // 0x91a4dc: r0 = _GrowableList._ofOther()
    //     0x91a4dc: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x91a4e0: mov             x3, x0
    // 0x91a4e4: ldur            x0, [fp, #-0xc8]
    // 0x91a4e8: stur            x3, [fp, #-0xc0]
    // 0x91a4ec: LoadField: r4 = r0->field_b
    //     0x91a4ec: ldur            w4, [x0, #0xb]
    // 0x91a4f0: DecompressPointer r4
    //     0x91a4f0: add             x4, x4, HEAP, lsl #32
    // 0x91a4f4: mov             x1, x3
    // 0x91a4f8: mov             x2, x4
    // 0x91a4fc: stur            x4, [fp, #-0xb8]
    // 0x91a500: r0 = addAll()
    //     0x91a500: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x91a504: ldur            x1, [fp, #-0xb8]
    // 0x91a508: r0 = clear()
    //     0x91a508: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x91a50c: ldur            x0, [fp, #-0xc0]
    // 0x91a510: LoadField: r2 = r0->field_7
    //     0x91a510: ldur            w2, [x0, #7]
    // 0x91a514: DecompressPointer r2
    //     0x91a514: add             x2, x2, HEAP, lsl #32
    // 0x91a518: mov             x1, x2
    // 0x91a51c: stur            x2, [fp, #-0xb8]
    // 0x91a520: r0 = ListIterator()
    //     0x91a520: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x91a524: ldur            x1, [fp, #-0xc0]
    // 0x91a528: stur            x0, [fp, #-0x100]
    // 0x91a52c: StoreField: r0->field_b = r1
    //     0x91a52c: stur            w1, [x0, #0xb]
    // 0x91a530: LoadField: r2 = r1->field_b
    //     0x91a530: ldur            w2, [x1, #0xb]
    // 0x91a534: r3 = LoadInt32Instr(r2)
    //     0x91a534: sbfx            x3, x2, #1, #0x1f
    // 0x91a538: stur            x3, [fp, #-0xf8]
    // 0x91a53c: StoreField: r0->field_f = r3
    //     0x91a53c: stur            x3, [x0, #0xf]
    // 0x91a540: ArrayStore: r0[0] = rZR  ; List_8
    //     0x91a540: stur            xzr, [x0, #0x17]
    // 0x91a544: r5 = false
    //     0x91a544: add             x5, NULL, #0x30  ; false
    // 0x91a548: r4 = Null
    //     0x91a548: mov             x4, NULL
    // 0x91a54c: r2 = Null
    //     0x91a54c: mov             x2, NULL
    // 0x91a550: stur            x5, [fp, #-0xd0]
    // 0x91a554: stur            x4, [fp, #-0xe8]
    // 0x91a558: stur            x2, [fp, #-0xf0]
    // 0x91a55c: CheckStackOverflow
    //     0x91a55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a560: cmp             SP, x16
    //     0x91a564: b.ls            #0x91a7b0
    // 0x91a568: str             x1, [SP]
    // 0x91a56c: r0 = length()
    //     0x91a56c: bl              #0xd05214  ; [dart:core] _Array::length
    // 0x91a570: r1 = LoadInt32Instr(r0)
    //     0x91a570: sbfx            x1, x0, #1, #0x1f
    //     0x91a574: tbz             w0, #0, #0x91a57c
    //     0x91a578: ldur            x1, [x0, #7]
    // 0x91a57c: ldur            x0, [fp, #-0xf8]
    // 0x91a580: cmp             x0, x1
    // 0x91a584: b.ne            #0x91a788
    // 0x91a588: ldur            x3, [fp, #-0x100]
    // 0x91a58c: ArrayLoad: r2 = r3[0]  ; List_8
    //     0x91a58c: ldur            x2, [x3, #0x17]
    // 0x91a590: cmp             x2, x1
    // 0x91a594: b.ge            #0x91a748
    // 0x91a598: ldur            x1, [fp, #-0xc0]
    // 0x91a59c: r0 = elementAt()
    //     0x91a59c: bl              #0xb94a50  ; [dart:core] _GrowableList::elementAt
    // 0x91a5a0: mov             x4, x0
    // 0x91a5a4: ldur            x3, [fp, #-0x100]
    // 0x91a5a8: r17 = -264
    //     0x91a5a8: mov             x17, #-0x108
    // 0x91a5ac: str             x4, [fp, x17]
    // 0x91a5b0: StoreField: r3->field_1f = r0
    //     0x91a5b0: stur            w0, [x3, #0x1f]
    //     0x91a5b4: tbz             w0, #0, #0x91a5d0
    //     0x91a5b8: ldurb           w16, [x3, #-1]
    //     0x91a5bc: ldurb           w17, [x0, #-1]
    //     0x91a5c0: and             x16, x17, x16, lsr #2
    //     0x91a5c4: tst             x16, HEAP, lsr #32
    //     0x91a5c8: b.eq            #0x91a5d0
    //     0x91a5cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x91a5d0: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x91a5d0: ldur            x0, [x3, #0x17]
    // 0x91a5d4: add             x1, x0, #1
    // 0x91a5d8: ArrayStore: r3[0] = r1  ; List_8
    //     0x91a5d8: stur            x1, [x3, #0x17]
    // 0x91a5dc: cmp             w4, NULL
    // 0x91a5e0: b.ne            #0x91a614
    // 0x91a5e4: mov             x0, x4
    // 0x91a5e8: ldur            x2, [fp, #-0xb8]
    // 0x91a5ec: r1 = Null
    //     0x91a5ec: mov             x1, NULL
    // 0x91a5f0: cmp             w2, NULL
    // 0x91a5f4: b.eq            #0x91a614
    // 0x91a5f8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x91a5f8: ldur            w4, [x2, #0x17]
    // 0x91a5fc: DecompressPointer r4
    //     0x91a5fc: add             x4, x4, HEAP, lsl #32
    // 0x91a600: r8 = X0
    //     0x91a600: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x91a604: LoadField: r9 = r4->field_7
    //     0x91a604: ldur            x9, [x4, #7]
    // 0x91a608: r3 = Null
    //     0x91a608: add             x3, PP, #0x81, lsl #12  ; [pp+0x81368] Null
    //     0x91a60c: ldr             x3, [x3, #0x368]
    // 0x91a610: blr             x9
    // 0x91a614: r17 = -264
    //     0x91a614: mov             x17, #-0x108
    // 0x91a618: ldr             x16, [fp, x17]
    // 0x91a61c: ldur            lr, [fp, #-0xd8]
    // 0x91a620: stp             lr, x16, [SP, #8]
    // 0x91a624: ldur            x16, [fp, #-0xe0]
    // 0x91a628: str             x16, [SP]
    // 0x91a62c: r17 = -264
    //     0x91a62c: mov             x17, #-0x108
    // 0x91a630: ldr             x0, [fp, x17]
    // 0x91a634: ClosureCall
    //     0x91a634: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x91a638: ldur            x2, [x0, #0x1f]
    //     0x91a63c: blr             x2
    // 0x91a640: ldur            x4, [fp, #-0xe8]
    // 0x91a644: ldur            x2, [fp, #-0xf0]
    // 0x91a648: r5 = true
    //     0x91a648: add             x5, NULL, #0x20  ; true
    // 0x91a64c: b               #0x91a738
    // 0x91a650: sub             SP, fp, #0x128
    // 0x91a654: mov             x2, x0
    // 0x91a658: stur            x0, [fp, #-0xe8]
    // 0x91a65c: stur            x1, [fp, #-0xf0]
    // 0x91a660: r0 = 60
    //     0x91a660: mov             x0, #0x3c
    // 0x91a664: branchIfSmi(r2, 0x91a670)
    //     0x91a664: tbz             w2, #0, #0x91a670
    // 0x91a668: r0 = LoadClassIdInstr(r2)
    //     0x91a668: ldur            x0, [x2, #-1]
    //     0x91a66c: ubfx            x0, x0, #0xc, #0x14
    // 0x91a670: ldur            x16, [fp, #-0xd8]
    // 0x91a674: stp             x16, x2, [SP]
    // 0x91a678: mov             lr, x0
    // 0x91a67c: ldr             lr, [x21, lr, lsl #3]
    // 0x91a680: blr             lr
    // 0x91a684: tbz             w0, #4, #0x91a72c
    // 0x91a688: ldur            x2, [fp, #-0xe8]
    // 0x91a68c: ldur            x0, [fp, #-0xf0]
    // 0x91a690: r1 = <List<Object>>
    //     0x91a690: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x91a694: r0 = ErrorDescription()
    //     0x91a694: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x91a698: mov             x1, x0
    // 0x91a69c: r2 = "when reporting an error to an image listener"
    //     0x91a69c: add             x2, PP, #0x81, lsl #12  ; [pp+0x81378] "when reporting an error to an image listener"
    //     0x91a6a0: ldr             x2, [x2, #0x378]
    // 0x91a6a4: r3 = Instance_DiagnosticLevel
    //     0x91a6a4: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x91a6a8: r17 = -264
    //     0x91a6a8: mov             x17, #-0x108
    // 0x91a6ac: str             x0, [fp, x17]
    // 0x91a6b0: r0 = _ErrorDiagnostic()
    //     0x91a6b0: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x91a6b4: r0 = FlutterErrorDetails()
    //     0x91a6b4: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x91a6b8: mov             x1, x0
    // 0x91a6bc: ldur            x0, [fp, #-0xe8]
    // 0x91a6c0: r17 = -272
    //     0x91a6c0: mov             x17, #-0x110
    // 0x91a6c4: str             x1, [fp, x17]
    // 0x91a6c8: StoreField: r1->field_7 = r0
    //     0x91a6c8: stur            w0, [x1, #7]
    // 0x91a6cc: ldur            x2, [fp, #-0xf0]
    // 0x91a6d0: StoreField: r1->field_b = r2
    //     0x91a6d0: stur            w2, [x1, #0xb]
    // 0x91a6d4: r3 = "image resource service"
    //     0x91a6d4: ldr             x3, [PP, #0x7da8]  ; [pp+0x7da8] "image resource service"
    // 0x91a6d8: StoreField: r1->field_f = r3
    //     0x91a6d8: stur            w3, [x1, #0xf]
    // 0x91a6dc: r17 = -264
    //     0x91a6dc: mov             x17, #-0x108
    // 0x91a6e0: ldr             x4, [fp, x17]
    // 0x91a6e4: StoreField: r1->field_13 = r4
    //     0x91a6e4: stur            w4, [x1, #0x13]
    // 0x91a6e8: r4 = false
    //     0x91a6e8: add             x4, NULL, #0x30  ; false
    // 0x91a6ec: StoreField: r1->field_1b = r4
    //     0x91a6ec: stur            w4, [x1, #0x1b]
    // 0x91a6f0: r0 = LoadStaticField(0x46c)
    //     0x91a6f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91a6f4: ldr             x0, [x0, #0x8d8]
    // 0x91a6f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a6fc: cmp             w0, w16
    // 0x91a700: b.ne            #0x91a70c
    // 0x91a704: r2 = onError
    //     0x91a704: ldr             x2, [PP, #0x878]  ; [pp+0x878] Field <FlutterError.onError>: static late (offset: 0x46c)
    // 0x91a708: r0 = InitLateStaticField()
    //     0x91a708: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x91a70c: cmp             w0, NULL
    // 0x91a710: b.eq            #0x91a72c
    // 0x91a714: r17 = -272
    //     0x91a714: mov             x17, #-0x110
    // 0x91a718: ldr             x16, [fp, x17]
    // 0x91a71c: stp             x16, x0, [SP]
    // 0x91a720: ClosureCall
    //     0x91a720: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x91a724: ldur            x2, [x0, #0x1f]
    //     0x91a728: blr             x2
    // 0x91a72c: ldur            x5, [fp, #-0xd0]
    // 0x91a730: ldur            x4, [fp, #-0xe8]
    // 0x91a734: ldur            x2, [fp, #-0xf0]
    // 0x91a738: ldur            x0, [fp, #-0x100]
    // 0x91a73c: ldur            x1, [fp, #-0xc0]
    // 0x91a740: ldur            x3, [fp, #-0xf8]
    // 0x91a744: b               #0x91a550
    // 0x91a748: ldur            x1, [fp, #-0xd0]
    // 0x91a74c: mov             x0, x3
    // 0x91a750: StoreField: r0->field_1f = rNULL
    //     0x91a750: stur            NULL, [x0, #0x1f]
    // 0x91a754: r16 = true
    //     0x91a754: add             x16, NULL, #0x20  ; true
    // 0x91a758: cmp             w1, w16
    // 0x91a75c: b.eq            #0x91a778
    // 0x91a760: ldur            x0, [fp, #-0xc8]
    // 0x91a764: LoadField: r1 = r0->field_13
    //     0x91a764: ldur            w1, [x0, #0x13]
    // 0x91a768: DecompressPointer r1
    //     0x91a768: add             x1, x1, HEAP, lsl #32
    // 0x91a76c: cmp             w1, NULL
    // 0x91a770: b.eq            #0x91a7b8
    // 0x91a774: r0 = reportError()
    //     0x91a774: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x91a778: r0 = Null
    //     0x91a778: mov             x0, NULL
    // 0x91a77c: LeaveFrame
    //     0x91a77c: mov             SP, fp
    //     0x91a780: ldp             fp, lr, [SP], #0x10
    // 0x91a784: ret
    //     0x91a784: ret             
    // 0x91a788: ldur            x0, [fp, #-0xc0]
    // 0x91a78c: r0 = ConcurrentModificationError()
    //     0x91a78c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x91a790: mov             x1, x0
    // 0x91a794: ldur            x0, [fp, #-0xc0]
    // 0x91a798: StoreField: r1->field_b = r0
    //     0x91a798: stur            w0, [x1, #0xb]
    // 0x91a79c: mov             x0, x1
    // 0x91a7a0: r0 = Throw()
    //     0x91a7a0: bl              #0x13ddb2c  ; ThrowStub
    // 0x91a7a4: brk             #0
    // 0x91a7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a7a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a7ac: b               #0x91a35c
    // 0x91a7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a7b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a7b4: b               #0x91a568
    // 0x91a7b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a7b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void addListener(dynamic, ImageStreamListener) {
    // ** addr: 0x91aa18, size: 0x3c
    // 0x91aa18: EnterFrame
    //     0x91aa18: stp             fp, lr, [SP, #-0x10]!
    //     0x91aa1c: mov             fp, SP
    // 0x91aa20: ldr             x0, [fp, #0x18]
    // 0x91aa24: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91aa24: ldur            w1, [x0, #0x17]
    // 0x91aa28: DecompressPointer r1
    //     0x91aa28: add             x1, x1, HEAP, lsl #32
    // 0x91aa2c: CheckStackOverflow
    //     0x91aa2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91aa30: cmp             SP, x16
    //     0x91aa34: b.ls            #0x91aa4c
    // 0x91aa38: ldr             x2, [fp, #0x10]
    // 0x91aa3c: r0 = addListener()
    //     0x91aa3c: bl              #0x124a354  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0x91aa40: LeaveFrame
    //     0x91aa40: mov             SP, fp
    //     0x91aa44: ldp             fp, lr, [SP], #0x10
    // 0x91aa48: ret
    //     0x91aa48: ret             
    // 0x91aa4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91aa4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91aa50: b               #0x91aa38
  }
  _ ImageStreamCompleter(/* No info */) {
    // ** addr: 0x91aa54, size: 0xd4
    // 0x91aa54: EnterFrame
    //     0x91aa54: stp             fp, lr, [SP, #-0x10]!
    //     0x91aa58: mov             fp, SP
    // 0x91aa5c: AllocStack(0x8)
    //     0x91aa5c: sub             SP, SP, #8
    // 0x91aa60: r0 = false
    //     0x91aa60: add             x0, NULL, #0x30  ; false
    // 0x91aa64: mov             x3, x1
    // 0x91aa68: stur            x1, [fp, #-8]
    // 0x91aa6c: CheckStackOverflow
    //     0x91aa6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91aa70: cmp             SP, x16
    //     0x91aa74: b.ls            #0x91ab20
    // 0x91aa78: StoreField: r3->field_1b = r0
    //     0x91aa78: stur            w0, [x3, #0x1b]
    // 0x91aa7c: StoreField: r3->field_1f = rZR
    //     0x91aa7c: stur            xzr, [x3, #0x1f]
    // 0x91aa80: StoreField: r3->field_27 = r0
    //     0x91aa80: stur            w0, [x3, #0x27]
    // 0x91aa84: r1 = <ImageStreamListener>
    //     0x91aa84: add             x1, PP, #0x81, lsl #12  ; [pp+0x813e0] TypeArguments: <ImageStreamListener>
    //     0x91aa88: ldr             x1, [x1, #0x3e0]
    // 0x91aa8c: r2 = 0
    //     0x91aa8c: mov             x2, #0
    // 0x91aa90: r0 = _GrowableList()
    //     0x91aa90: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x91aa94: ldur            x3, [fp, #-8]
    // 0x91aa98: StoreField: r3->field_7 = r0
    //     0x91aa98: stur            w0, [x3, #7]
    //     0x91aa9c: ldurb           w16, [x3, #-1]
    //     0x91aaa0: ldurb           w17, [x0, #-1]
    //     0x91aaa4: and             x16, x17, x16, lsr #2
    //     0x91aaa8: tst             x16, HEAP, lsr #32
    //     0x91aaac: b.eq            #0x91aab4
    //     0x91aab0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x91aab4: r1 = <(dynamic this, Object, StackTrace?) => void?>
    //     0x91aab4: add             x1, PP, #0x81, lsl #12  ; [pp+0x81348] TypeArguments: <(dynamic this, Object, StackTrace?) => void?>
    //     0x91aab8: ldr             x1, [x1, #0x348]
    // 0x91aabc: r2 = 0
    //     0x91aabc: mov             x2, #0
    // 0x91aac0: r0 = _GrowableList()
    //     0x91aac0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x91aac4: ldur            x3, [fp, #-8]
    // 0x91aac8: StoreField: r3->field_b = r0
    //     0x91aac8: stur            w0, [x3, #0xb]
    //     0x91aacc: ldurb           w16, [x3, #-1]
    //     0x91aad0: ldurb           w17, [x0, #-1]
    //     0x91aad4: and             x16, x17, x16, lsr #2
    //     0x91aad8: tst             x16, HEAP, lsr #32
    //     0x91aadc: b.eq            #0x91aae4
    //     0x91aae0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x91aae4: r1 = <(dynamic this) => void?>
    //     0x91aae4: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0x91aae8: r2 = 0
    //     0x91aae8: mov             x2, #0
    // 0x91aaec: r0 = _GrowableList()
    //     0x91aaec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x91aaf0: ldur            x1, [fp, #-8]
    // 0x91aaf4: StoreField: r1->field_2b = r0
    //     0x91aaf4: stur            w0, [x1, #0x2b]
    //     0x91aaf8: ldurb           w16, [x1, #-1]
    //     0x91aafc: ldurb           w17, [x0, #-1]
    //     0x91ab00: and             x16, x17, x16, lsr #2
    //     0x91ab04: tst             x16, HEAP, lsr #32
    //     0x91ab08: b.eq            #0x91ab10
    //     0x91ab0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x91ab10: r0 = Null
    //     0x91ab10: mov             x0, NULL
    // 0x91ab14: LeaveFrame
    //     0x91ab14: mov             SP, fp
    //     0x91ab18: ldp             fp, lr, [SP], #0x10
    // 0x91ab1c: ret
    //     0x91ab1c: ret             
    // 0x91ab20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ab20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ab24: b               #0x91aa78
  }
  _ setImage(/* No info */) {
    // ** addr: 0xd08768, size: 0x30c
    // 0xd08768: EnterFrame
    //     0xd08768: stp             fp, lr, [SP, #-0x10]!
    //     0xd0876c: mov             fp, SP
    // 0xd08770: AllocStack(0xf8)
    //     0xd08770: sub             SP, SP, #0xf8
    // 0xd08774: SetupParameters(ImageStreamCompleter this /* r1 => r2, fp-0x78 */, dynamic _ /* r2 => r0, fp-0x80 */)
    //     0xd08774: mov             x0, x2
    //     0xd08778: stur            x2, [fp, #-0x80]
    //     0xd0877c: mov             x2, x1
    //     0xd08780: stur            x1, [fp, #-0x78]
    // 0xd08784: CheckStackOverflow
    //     0xd08784: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08788: cmp             SP, x16
    //     0xd0878c: b.ls            #0xd08a60
    // 0xd08790: mov             x1, x2
    // 0xd08794: r0 = _checkDisposed()
    //     0xd08794: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xd08798: ldur            x0, [fp, #-0x78]
    // 0xd0879c: LoadField: r1 = r0->field_f
    //     0xd0879c: ldur            w1, [x0, #0xf]
    // 0xd087a0: DecompressPointer r1
    //     0xd087a0: add             x1, x1, HEAP, lsl #32
    // 0xd087a4: cmp             w1, NULL
    // 0xd087a8: b.ne            #0xd087b4
    // 0xd087ac: mov             x2, x0
    // 0xd087b0: b               #0xd087bc
    // 0xd087b4: r0 = dispose()
    //     0xd087b4: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xd087b8: ldur            x2, [fp, #-0x78]
    // 0xd087bc: ldur            x0, [fp, #-0x80]
    // 0xd087c0: StoreField: r2->field_f = r0
    //     0xd087c0: stur            w0, [x2, #0xf]
    //     0xd087c4: ldurb           w16, [x2, #-1]
    //     0xd087c8: ldurb           w17, [x0, #-1]
    //     0xd087cc: and             x16, x17, x16, lsr #2
    //     0xd087d0: tst             x16, HEAP, lsr #32
    //     0xd087d4: b.eq            #0xd087dc
    //     0xd087d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd087dc: LoadField: r1 = r2->field_b
    //     0xd087dc: ldur            w1, [x2, #0xb]
    // 0xd087e0: DecompressPointer r1
    //     0xd087e0: add             x1, x1, HEAP, lsl #32
    // 0xd087e4: r0 = clear()
    //     0xd087e4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xd087e8: ldur            x0, [fp, #-0x78]
    // 0xd087ec: LoadField: r2 = r0->field_7
    //     0xd087ec: ldur            w2, [x0, #7]
    // 0xd087f0: DecompressPointer r2
    //     0xd087f0: add             x2, x2, HEAP, lsl #32
    // 0xd087f4: LoadField: r1 = r2->field_b
    //     0xd087f4: ldur            w1, [x2, #0xb]
    // 0xd087f8: cbnz            w1, #0xd0880c
    // 0xd087fc: r0 = Null
    //     0xd087fc: mov             x0, NULL
    // 0xd08800: LeaveFrame
    //     0xd08800: mov             SP, fp
    //     0xd08804: ldp             fp, lr, [SP], #0x10
    // 0xd08808: ret
    //     0xd08808: ret             
    // 0xd0880c: ldur            x3, [fp, #-0x80]
    // 0xd08810: r1 = <ImageStreamListener>
    //     0xd08810: add             x1, PP, #0x81, lsl #12  ; [pp+0x813e0] TypeArguments: <ImageStreamListener>
    //     0xd08814: ldr             x1, [x1, #0x3e0]
    // 0xd08818: r0 = _GrowableList._ofGrowableList()
    //     0xd08818: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xd0881c: stur            x0, [fp, #-0x90]
    // 0xd08820: LoadField: r2 = r0->field_7
    //     0xd08820: ldur            w2, [x0, #7]
    // 0xd08824: DecompressPointer r2
    //     0xd08824: add             x2, x2, HEAP, lsl #32
    // 0xd08828: mov             x1, x2
    // 0xd0882c: stur            x2, [fp, #-0x88]
    // 0xd08830: r0 = ListIterator()
    //     0xd08830: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0xd08834: mov             x4, x0
    // 0xd08838: ldur            x3, [fp, #-0x90]
    // 0xd0883c: stur            x4, [fp, #-0xc8]
    // 0xd08840: StoreField: r4->field_b = r3
    //     0xd08840: stur            w3, [x4, #0xb]
    // 0xd08844: LoadField: r0 = r3->field_b
    //     0xd08844: ldur            w0, [x3, #0xb]
    // 0xd08848: r5 = LoadInt32Instr(r0)
    //     0xd08848: sbfx            x5, x0, #1, #0x1f
    // 0xd0884c: stur            x5, [fp, #-0xc0]
    // 0xd08850: StoreField: r4->field_f = r5
    //     0xd08850: stur            x5, [x4, #0xf]
    // 0xd08854: ArrayStore: r4[0] = rZR  ; List_8
    //     0xd08854: stur            xzr, [x4, #0x17]
    // 0xd08858: ldur            x6, [fp, #-0x80]
    // 0xd0885c: LoadField: r7 = r6->field_7
    //     0xd0885c: ldur            w7, [x6, #7]
    // 0xd08860: DecompressPointer r7
    //     0xd08860: add             x7, x7, HEAP, lsl #32
    // 0xd08864: stur            x7, [fp, #-0xb8]
    // 0xd08868: LoadField: d0 = r6->field_b
    //     0xd08868: ldur            d0, [x6, #0xb]
    // 0xd0886c: stur            d0, [fp, #-0xe0]
    // 0xd08870: LoadField: r8 = r6->field_13
    //     0xd08870: ldur            w8, [x6, #0x13]
    // 0xd08874: DecompressPointer r8
    //     0xd08874: add             x8, x8, HEAP, lsl #32
    // 0xd08878: stur            x8, [fp, #-0xb0]
    // 0xd0887c: r10 = Null
    //     0xd0887c: mov             x10, NULL
    // 0xd08880: r9 = Null
    //     0xd08880: mov             x9, NULL
    // 0xd08884: stur            x10, [fp, #-0xa0]
    // 0xd08888: stur            x9, [fp, #-0xa8]
    // 0xd0888c: CheckStackOverflow
    //     0xd0888c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08890: cmp             SP, x16
    //     0xd08894: b.ls            #0xd08a68
    // 0xd08898: LoadField: r0 = r3->field_b
    //     0xd08898: ldur            w0, [x3, #0xb]
    // 0xd0889c: r1 = LoadInt32Instr(r0)
    //     0xd0889c: sbfx            x1, x0, #1, #0x1f
    // 0xd088a0: cmp             x5, x1
    // 0xd088a4: b.ne            #0xd08a40
    // 0xd088a8: ArrayLoad: r2 = r4[0]  ; List_8
    //     0xd088a8: ldur            x2, [x4, #0x17]
    // 0xd088ac: cmp             x2, x1
    // 0xd088b0: b.ge            #0xd08a28
    // 0xd088b4: mov             x0, x1
    // 0xd088b8: mov             x1, x2
    // 0xd088bc: cmp             x1, x0
    // 0xd088c0: b.hs            #0xd08a70
    // 0xd088c4: LoadField: r0 = r3->field_f
    //     0xd088c4: ldur            w0, [x3, #0xf]
    // 0xd088c8: DecompressPointer r0
    //     0xd088c8: add             x0, x0, HEAP, lsl #32
    // 0xd088cc: ArrayLoad: r11 = r0[r2]  ; Unknown_4
    //     0xd088cc: add             x16, x0, x2, lsl #2
    //     0xd088d0: ldur            w11, [x16, #0xf]
    // 0xd088d4: DecompressPointer r11
    //     0xd088d4: add             x11, x11, HEAP, lsl #32
    // 0xd088d8: mov             x0, x11
    // 0xd088dc: stur            x11, [fp, #-0x98]
    // 0xd088e0: StoreField: r4->field_1f = r0
    //     0xd088e0: stur            w0, [x4, #0x1f]
    //     0xd088e4: tbz             w0, #0, #0xd08900
    //     0xd088e8: ldurb           w16, [x4, #-1]
    //     0xd088ec: ldurb           w17, [x0, #-1]
    //     0xd088f0: and             x16, x17, x16, lsr #2
    //     0xd088f4: tst             x16, HEAP, lsr #32
    //     0xd088f8: b.eq            #0xd08900
    //     0xd088fc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd08900: add             x0, x2, #1
    // 0xd08904: ArrayStore: r4[0] = r0  ; List_8
    //     0xd08904: stur            x0, [x4, #0x17]
    // 0xd08908: cmp             w11, NULL
    // 0xd0890c: b.ne            #0xd08940
    // 0xd08910: mov             x0, x11
    // 0xd08914: ldur            x2, [fp, #-0x88]
    // 0xd08918: r1 = Null
    //     0xd08918: mov             x1, NULL
    // 0xd0891c: cmp             w2, NULL
    // 0xd08920: b.eq            #0xd08940
    // 0xd08924: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd08924: ldur            w4, [x2, #0x17]
    // 0xd08928: DecompressPointer r4
    //     0xd08928: add             x4, x4, HEAP, lsl #32
    // 0xd0892c: r8 = X0
    //     0xd0892c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd08930: LoadField: r9 = r4->field_7
    //     0xd08930: ldur            x9, [x4, #7]
    // 0xd08934: r3 = Null
    //     0xd08934: add             x3, PP, #0x81, lsl #12  ; [pp+0x813e8] Null
    //     0xd08938: ldr             x3, [x3, #0x3e8]
    // 0xd0893c: blr             x9
    // 0xd08940: ldur            d0, [fp, #-0xe0]
    // 0xd08944: ldur            x0, [fp, #-0xb0]
    // 0xd08948: ldur            x2, [fp, #-0x98]
    // 0xd0894c: ldur            x1, [fp, #-0xb8]
    // 0xd08950: r0 = clone()
    //     0xd08950: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0xd08954: stur            x0, [fp, #-0xd0]
    // 0xd08958: r0 = ImageInfo()
    //     0xd08958: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd0895c: mov             x1, x0
    // 0xd08960: ldur            x0, [fp, #-0xd0]
    // 0xd08964: stur            x1, [fp, #-0xd8]
    // 0xd08968: StoreField: r1->field_7 = r0
    //     0xd08968: stur            w0, [x1, #7]
    // 0xd0896c: ldur            d0, [fp, #-0xe0]
    // 0xd08970: StoreField: r1->field_b = d0
    //     0xd08970: stur            d0, [x1, #0xb]
    // 0xd08974: ldur            x2, [fp, #-0xb0]
    // 0xd08978: StoreField: r1->field_13 = r2
    //     0xd08978: stur            w2, [x1, #0x13]
    // 0xd0897c: ldur            x3, [fp, #-0x98]
    // 0xd08980: LoadField: r4 = r3->field_7
    //     0xd08980: ldur            w4, [x3, #7]
    // 0xd08984: DecompressPointer r4
    //     0xd08984: add             x4, x4, HEAP, lsl #32
    // 0xd08988: stur            x4, [fp, #-0xd0]
    // 0xd0898c: stp             x1, x4, [SP, #8]
    // 0xd08990: r16 = false
    //     0xd08990: add             x16, NULL, #0x30  ; false
    // 0xd08994: str             x16, [SP]
    // 0xd08998: mov             x0, x4
    // 0xd0899c: ClosureCall
    //     0xd0899c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xd089a0: ldur            x2, [x0, #0x1f]
    //     0xd089a4: blr             x2
    // 0xd089a8: ldur            x10, [fp, #-0xa0]
    // 0xd089ac: ldur            x9, [fp, #-0xa8]
    // 0xd089b0: b               #0xd08a08
    // 0xd089b4: sub             SP, fp, #0xf8
    // 0xd089b8: mov             x3, x0
    // 0xd089bc: mov             x5, x1
    // 0xd089c0: stur            x0, [fp, #-0x98]
    // 0xd089c4: stur            x1, [fp, #-0xa0]
    // 0xd089c8: r1 = <List<Object>>
    //     0xd089c8: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xd089cc: r0 = ErrorDescription()
    //     0xd089cc: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xd089d0: mov             x1, x0
    // 0xd089d4: r2 = "by an image listener"
    //     0xd089d4: add             x2, PP, #0x81, lsl #12  ; [pp+0x813f8] "by an image listener"
    //     0xd089d8: ldr             x2, [x2, #0x3f8]
    // 0xd089dc: r3 = Instance_DiagnosticLevel
    //     0xd089dc: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xd089e0: stur            x0, [fp, #-0xa8]
    // 0xd089e4: r0 = _ErrorDiagnostic()
    //     0xd089e4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xd089e8: ldur            x1, [fp, #-0x78]
    // 0xd089ec: ldur            x2, [fp, #-0xa8]
    // 0xd089f0: ldur            x3, [fp, #-0x98]
    // 0xd089f4: ldur            x5, [fp, #-0xa0]
    // 0xd089f8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xd089f8: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xd089fc: r0 = reportError()
    //     0xd089fc: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xd08a00: ldur            x10, [fp, #-0xa0]
    // 0xd08a04: ldur            x9, [fp, #-0x98]
    // 0xd08a08: ldur            x6, [fp, #-0x80]
    // 0xd08a0c: ldur            x7, [fp, #-0xb8]
    // 0xd08a10: ldur            d0, [fp, #-0xe0]
    // 0xd08a14: ldur            x8, [fp, #-0xb0]
    // 0xd08a18: ldur            x4, [fp, #-0xc8]
    // 0xd08a1c: ldur            x3, [fp, #-0x90]
    // 0xd08a20: ldur            x5, [fp, #-0xc0]
    // 0xd08a24: b               #0xd08884
    // 0xd08a28: mov             x0, x4
    // 0xd08a2c: StoreField: r0->field_1f = rNULL
    //     0xd08a2c: stur            NULL, [x0, #0x1f]
    // 0xd08a30: r0 = Null
    //     0xd08a30: mov             x0, NULL
    // 0xd08a34: LeaveFrame
    //     0xd08a34: mov             SP, fp
    //     0xd08a38: ldp             fp, lr, [SP], #0x10
    // 0xd08a3c: ret
    //     0xd08a3c: ret             
    // 0xd08a40: mov             x0, x3
    // 0xd08a44: r0 = ConcurrentModificationError()
    //     0xd08a44: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd08a48: mov             x1, x0
    // 0xd08a4c: ldur            x0, [fp, #-0x90]
    // 0xd08a50: StoreField: r1->field_b = r0
    //     0xd08a50: stur            w0, [x1, #0xb]
    // 0xd08a54: mov             x0, x1
    // 0xd08a58: r0 = Throw()
    //     0xd08a58: bl              #0x13ddb2c  ; ThrowStub
    // 0xd08a5c: brk             #0
    // 0xd08a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08a60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08a64: b               #0xd08790
    // 0xd08a68: r0 = StackOverflowSharedWithFPURegs()
    //     0xd08a68: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd08a6c: b               #0xd08898
    // 0xd08a70: r0 = RangeErrorSharedWithFPURegs()
    //     0xd08a70: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  [closure] void setImage(dynamic, ImageInfo) {
    // ** addr: 0xd08af0, size: 0x3c
    // 0xd08af0: EnterFrame
    //     0xd08af0: stp             fp, lr, [SP, #-0x10]!
    //     0xd08af4: mov             fp, SP
    // 0xd08af8: ldr             x0, [fp, #0x18]
    // 0xd08afc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd08afc: ldur            w1, [x0, #0x17]
    // 0xd08b00: DecompressPointer r1
    //     0xd08b00: add             x1, x1, HEAP, lsl #32
    // 0xd08b04: CheckStackOverflow
    //     0xd08b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08b08: cmp             SP, x16
    //     0xd08b0c: b.ls            #0xd08b24
    // 0xd08b10: ldr             x2, [fp, #0x10]
    // 0xd08b14: r0 = setImage()
    //     0xd08b14: bl              #0xd08768  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::setImage
    // 0xd08b18: LeaveFrame
    //     0xd08b18: mov             SP, fp
    //     0xd08b1c: ldp             fp, lr, [SP], #0x10
    // 0xd08b20: ret
    //     0xd08b20: ret             
    // 0xd08b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08b28: b               #0xd08b10
  }
  _ _checkDisposed(/* No info */) {
    // ** addr: 0xd08b68, size: 0x40
    // 0xd08b68: EnterFrame
    //     0xd08b68: stp             fp, lr, [SP, #-0x10]!
    //     0xd08b6c: mov             fp, SP
    // 0xd08b70: LoadField: r0 = r1->field_27
    //     0xd08b70: ldur            w0, [x1, #0x27]
    // 0xd08b74: DecompressPointer r0
    //     0xd08b74: add             x0, x0, HEAP, lsl #32
    // 0xd08b78: tbz             w0, #4, #0xd08b8c
    // 0xd08b7c: r0 = Null
    //     0xd08b7c: mov             x0, NULL
    // 0xd08b80: LeaveFrame
    //     0xd08b80: mov             SP, fp
    //     0xd08b84: ldp             fp, lr, [SP], #0x10
    // 0xd08b88: ret
    //     0xd08b88: ret             
    // 0xd08b8c: r0 = StateError()
    //     0xd08b8c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xd08b90: mov             x1, x0
    // 0xd08b94: r0 = "Stream has been disposed.\nAn ImageStream is considered disposed once at least one listener has been added and subsequently all listeners have been removed and no handles are outstanding from the keepAlive method.\nTo resolve this error, maintain at least one listener on the stream, or create an ImageStreamCompleterHandle from the keepAlive method, or create a new stream for the image."
    //     0xd08b94: ldr             x0, [PP, #0x3500]  ; [pp+0x3500] "Stream has been disposed.\nAn ImageStream is considered disposed once at least one listener has been added and subsequently all listeners have been removed and no handles are outstanding from the keepAlive method.\nTo resolve this error, maintain at least one listener on the stream, or create an ImageStreamCompleterHandle from the keepAlive method, or create a new stream for the image."
    // 0xd08b98: StoreField: r1->field_b = r0
    //     0xd08b98: stur            w0, [x1, #0xb]
    // 0xd08b9c: mov             x0, x1
    // 0xd08ba0: r0 = Throw()
    //     0xd08ba0: bl              #0x13ddb2c  ; ThrowStub
    // 0xd08ba4: brk             #0
  }
  _ addEphemeralErrorListener(/* No info */) {
    // ** addr: 0xd09acc, size: 0x20c
    // 0xd09acc: EnterFrame
    //     0xd09acc: stp             fp, lr, [SP, #-0x10]!
    //     0xd09ad0: mov             fp, SP
    // 0xd09ad4: AllocStack(0x90)
    //     0xd09ad4: sub             SP, SP, #0x90
    // 0xd09ad8: SetupParameters(ImageStreamCompleter this /* r1 => r2, fp-0x50 */, dynamic _ /* r2 => r0, fp-0x58 */)
    //     0xd09ad8: mov             x0, x2
    //     0xd09adc: stur            x2, [fp, #-0x58]
    //     0xd09ae0: mov             x2, x1
    //     0xd09ae4: stur            x1, [fp, #-0x50]
    // 0xd09ae8: CheckStackOverflow
    //     0xd09ae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd09aec: cmp             SP, x16
    //     0xd09af0: b.ls            #0xd09ccc
    // 0xd09af4: mov             x1, x2
    // 0xd09af8: r0 = _checkDisposed()
    //     0xd09af8: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xd09afc: ldur            x1, [fp, #-0x50]
    // 0xd09b00: LoadField: r0 = r1->field_13
    //     0xd09b00: ldur            w0, [x1, #0x13]
    // 0xd09b04: DecompressPointer r0
    //     0xd09b04: add             x0, x0, HEAP, lsl #32
    // 0xd09b08: cmp             w0, NULL
    // 0xd09b0c: b.eq            #0xd09bf0
    // 0xd09b10: LoadField: r2 = r0->field_7
    //     0xd09b10: ldur            w2, [x0, #7]
    // 0xd09b14: DecompressPointer r2
    //     0xd09b14: add             x2, x2, HEAP, lsl #32
    // 0xd09b18: LoadField: r3 = r0->field_b
    //     0xd09b18: ldur            w3, [x0, #0xb]
    // 0xd09b1c: DecompressPointer r3
    //     0xd09b1c: add             x3, x3, HEAP, lsl #32
    // 0xd09b20: ldur            x16, [fp, #-0x58]
    // 0xd09b24: stp             x2, x16, [SP, #8]
    // 0xd09b28: str             x3, [SP]
    // 0xd09b2c: ldur            x0, [fp, #-0x58]
    // 0xd09b30: ClosureCall
    //     0xd09b30: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xd09b34: ldur            x2, [x0, #0x1f]
    //     0xd09b38: blr             x2
    // 0xd09b3c: b               #0xd09cbc
    // 0xd09b40: sub             SP, fp, #0x90
    // 0xd09b44: ldur            x2, [fp, #-0x50]
    // 0xd09b48: mov             x3, x0
    // 0xd09b4c: stur            x0, [fp, #-0x60]
    // 0xd09b50: stur            x1, [fp, #-0x68]
    // 0xd09b54: LoadField: r0 = r2->field_13
    //     0xd09b54: ldur            w0, [x2, #0x13]
    // 0xd09b58: DecompressPointer r0
    //     0xd09b58: add             x0, x0, HEAP, lsl #32
    // 0xd09b5c: cmp             w0, NULL
    // 0xd09b60: b.eq            #0xd09cd4
    // 0xd09b64: LoadField: r2 = r0->field_7
    //     0xd09b64: ldur            w2, [x0, #7]
    // 0xd09b68: DecompressPointer r2
    //     0xd09b68: add             x2, x2, HEAP, lsl #32
    // 0xd09b6c: r0 = 60
    //     0xd09b6c: mov             x0, #0x3c
    // 0xd09b70: branchIfSmi(r3, 0xd09b7c)
    //     0xd09b70: tbz             w3, #0, #0xd09b7c
    // 0xd09b74: r0 = LoadClassIdInstr(r3)
    //     0xd09b74: ldur            x0, [x3, #-1]
    //     0xd09b78: ubfx            x0, x0, #0xc, #0x14
    // 0xd09b7c: stp             x2, x3, [SP]
    // 0xd09b80: mov             lr, x0
    // 0xd09b84: ldr             lr, [x21, lr, lsl #3]
    // 0xd09b88: blr             lr
    // 0xd09b8c: tbz             w0, #4, #0xd09cbc
    // 0xd09b90: ldur            x2, [fp, #-0x60]
    // 0xd09b94: ldur            x0, [fp, #-0x68]
    // 0xd09b98: r1 = <List<Object>>
    //     0xd09b98: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xd09b9c: r0 = ErrorDescription()
    //     0xd09b9c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xd09ba0: mov             x1, x0
    // 0xd09ba4: r2 = "by a synchronously-called image error listener"
    //     0xd09ba4: add             x2, PP, #0x81, lsl #12  ; [pp+0x813a0] "by a synchronously-called image error listener"
    //     0xd09ba8: ldr             x2, [x2, #0x3a0]
    // 0xd09bac: r3 = Instance_DiagnosticLevel
    //     0xd09bac: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xd09bb0: stur            x0, [fp, #-0x70]
    // 0xd09bb4: r0 = _ErrorDiagnostic()
    //     0xd09bb4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xd09bb8: r0 = FlutterErrorDetails()
    //     0xd09bb8: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0xd09bbc: mov             x1, x0
    // 0xd09bc0: ldur            x0, [fp, #-0x60]
    // 0xd09bc4: StoreField: r1->field_7 = r0
    //     0xd09bc4: stur            w0, [x1, #7]
    // 0xd09bc8: ldur            x0, [fp, #-0x68]
    // 0xd09bcc: StoreField: r1->field_b = r0
    //     0xd09bcc: stur            w0, [x1, #0xb]
    // 0xd09bd0: r0 = "image resource service"
    //     0xd09bd0: ldr             x0, [PP, #0x7da8]  ; [pp+0x7da8] "image resource service"
    // 0xd09bd4: StoreField: r1->field_f = r0
    //     0xd09bd4: stur            w0, [x1, #0xf]
    // 0xd09bd8: ldur            x0, [fp, #-0x70]
    // 0xd09bdc: StoreField: r1->field_13 = r0
    //     0xd09bdc: stur            w0, [x1, #0x13]
    // 0xd09be0: r0 = false
    //     0xd09be0: add             x0, NULL, #0x30  ; false
    // 0xd09be4: StoreField: r1->field_1b = r0
    //     0xd09be4: stur            w0, [x1, #0x1b]
    // 0xd09be8: r0 = reportError()
    //     0xd09be8: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xd09bec: b               #0xd09cbc
    // 0xd09bf0: mov             x2, x1
    // 0xd09bf4: LoadField: r0 = r2->field_f
    //     0xd09bf4: ldur            w0, [x2, #0xf]
    // 0xd09bf8: DecompressPointer r0
    //     0xd09bf8: add             x0, x0, HEAP, lsl #32
    // 0xd09bfc: cmp             w0, NULL
    // 0xd09c00: b.ne            #0xd09cbc
    // 0xd09c04: LoadField: r3 = r2->field_b
    //     0xd09c04: ldur            w3, [x2, #0xb]
    // 0xd09c08: DecompressPointer r3
    //     0xd09c08: add             x3, x3, HEAP, lsl #32
    // 0xd09c0c: stur            x3, [fp, #-0x60]
    // 0xd09c10: LoadField: r2 = r3->field_7
    //     0xd09c10: ldur            w2, [x3, #7]
    // 0xd09c14: DecompressPointer r2
    //     0xd09c14: add             x2, x2, HEAP, lsl #32
    // 0xd09c18: ldur            x0, [fp, #-0x58]
    // 0xd09c1c: r1 = Null
    //     0xd09c1c: mov             x1, NULL
    // 0xd09c20: cmp             w2, NULL
    // 0xd09c24: b.eq            #0xd09c44
    // 0xd09c28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd09c28: ldur            w4, [x2, #0x17]
    // 0xd09c2c: DecompressPointer r4
    //     0xd09c2c: add             x4, x4, HEAP, lsl #32
    // 0xd09c30: r8 = X0
    //     0xd09c30: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd09c34: LoadField: r9 = r4->field_7
    //     0xd09c34: ldur            x9, [x4, #7]
    // 0xd09c38: r3 = Null
    //     0xd09c38: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f160] Null
    //     0xd09c3c: ldr             x3, [x3, #0x160]
    // 0xd09c40: blr             x9
    // 0xd09c44: ldur            x0, [fp, #-0x60]
    // 0xd09c48: LoadField: r1 = r0->field_b
    //     0xd09c48: ldur            w1, [x0, #0xb]
    // 0xd09c4c: LoadField: r2 = r0->field_f
    //     0xd09c4c: ldur            w2, [x0, #0xf]
    // 0xd09c50: DecompressPointer r2
    //     0xd09c50: add             x2, x2, HEAP, lsl #32
    // 0xd09c54: LoadField: r3 = r2->field_b
    //     0xd09c54: ldur            w3, [x2, #0xb]
    // 0xd09c58: r2 = LoadInt32Instr(r1)
    //     0xd09c58: sbfx            x2, x1, #1, #0x1f
    // 0xd09c5c: stur            x2, [fp, #-0x78]
    // 0xd09c60: r1 = LoadInt32Instr(r3)
    //     0xd09c60: sbfx            x1, x3, #1, #0x1f
    // 0xd09c64: cmp             x2, x1
    // 0xd09c68: b.ne            #0xd09c74
    // 0xd09c6c: mov             x1, x0
    // 0xd09c70: r0 = _growToNextCapacity()
    //     0xd09c70: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd09c74: ldur            x2, [fp, #-0x60]
    // 0xd09c78: ldur            x3, [fp, #-0x78]
    // 0xd09c7c: add             x4, x3, #1
    // 0xd09c80: lsl             x5, x4, #1
    // 0xd09c84: StoreField: r2->field_b = r5
    //     0xd09c84: stur            w5, [x2, #0xb]
    // 0xd09c88: LoadField: r1 = r2->field_f
    //     0xd09c88: ldur            w1, [x2, #0xf]
    // 0xd09c8c: DecompressPointer r1
    //     0xd09c8c: add             x1, x1, HEAP, lsl #32
    // 0xd09c90: ldur            x0, [fp, #-0x58]
    // 0xd09c94: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd09c94: add             x25, x1, x3, lsl #2
    //     0xd09c98: add             x25, x25, #0xf
    //     0xd09c9c: str             w0, [x25]
    //     0xd09ca0: tbz             w0, #0, #0xd09cbc
    //     0xd09ca4: ldurb           w16, [x1, #-1]
    //     0xd09ca8: ldurb           w17, [x0, #-1]
    //     0xd09cac: and             x16, x17, x16, lsr #2
    //     0xd09cb0: tst             x16, HEAP, lsr #32
    //     0xd09cb4: b.eq            #0xd09cbc
    //     0xd09cb8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd09cbc: r0 = Null
    //     0xd09cbc: mov             x0, NULL
    // 0xd09cc0: LeaveFrame
    //     0xd09cc0: mov             SP, fp
    //     0xd09cc4: ldp             fp, lr, [SP], #0x10
    // 0xd09cc8: ret
    //     0xd09cc8: ret             
    // 0xd09ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd09ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd09cd0: b               #0xd09af4
    // 0xd09cd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09cd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ removeOnLastListenerRemovedCallback(/* No info */) {
    // ** addr: 0xec0a48, size: 0x58
    // 0xec0a48: EnterFrame
    //     0xec0a48: stp             fp, lr, [SP, #-0x10]!
    //     0xec0a4c: mov             fp, SP
    // 0xec0a50: AllocStack(0x10)
    //     0xec0a50: sub             SP, SP, #0x10
    // 0xec0a54: SetupParameters(ImageStreamCompleter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xec0a54: mov             x0, x1
    //     0xec0a58: stur            x1, [fp, #-8]
    //     0xec0a5c: stur            x2, [fp, #-0x10]
    // 0xec0a60: CheckStackOverflow
    //     0xec0a60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xec0a64: cmp             SP, x16
    //     0xec0a68: b.ls            #0xec0a98
    // 0xec0a6c: mov             x1, x0
    // 0xec0a70: r0 = _checkDisposed()
    //     0xec0a70: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xec0a74: ldur            x0, [fp, #-8]
    // 0xec0a78: LoadField: r1 = r0->field_2b
    //     0xec0a78: ldur            w1, [x0, #0x2b]
    // 0xec0a7c: DecompressPointer r1
    //     0xec0a7c: add             x1, x1, HEAP, lsl #32
    // 0xec0a80: ldur            x2, [fp, #-0x10]
    // 0xec0a84: r0 = remove()
    //     0xec0a84: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xec0a88: r0 = Null
    //     0xec0a88: mov             x0, NULL
    // 0xec0a8c: LeaveFrame
    //     0xec0a8c: mov             SP, fp
    //     0xec0a90: ldp             fp, lr, [SP], #0x10
    // 0xec0a94: ret
    //     0xec0a94: ret             
    // 0xec0a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xec0a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xec0a9c: b               #0xec0a6c
  }
  _ addOnLastListenerRemovedCallback(/* No info */) {
    // ** addr: 0xf3041c, size: 0x104
    // 0xf3041c: EnterFrame
    //     0xf3041c: stp             fp, lr, [SP, #-0x10]!
    //     0xf30420: mov             fp, SP
    // 0xf30424: AllocStack(0x20)
    //     0xf30424: sub             SP, SP, #0x20
    // 0xf30428: SetupParameters(ImageStreamCompleter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf30428: mov             x0, x2
    //     0xf3042c: stur            x2, [fp, #-0x10]
    //     0xf30430: mov             x2, x1
    //     0xf30434: stur            x1, [fp, #-8]
    // 0xf30438: CheckStackOverflow
    //     0xf30438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3043c: cmp             SP, x16
    //     0xf30440: b.ls            #0xf30518
    // 0xf30444: mov             x1, x2
    // 0xf30448: r0 = _checkDisposed()
    //     0xf30448: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xf3044c: ldur            x0, [fp, #-8]
    // 0xf30450: LoadField: r3 = r0->field_2b
    //     0xf30450: ldur            w3, [x0, #0x2b]
    // 0xf30454: DecompressPointer r3
    //     0xf30454: add             x3, x3, HEAP, lsl #32
    // 0xf30458: stur            x3, [fp, #-0x18]
    // 0xf3045c: LoadField: r2 = r3->field_7
    //     0xf3045c: ldur            w2, [x3, #7]
    // 0xf30460: DecompressPointer r2
    //     0xf30460: add             x2, x2, HEAP, lsl #32
    // 0xf30464: ldur            x0, [fp, #-0x10]
    // 0xf30468: r1 = Null
    //     0xf30468: mov             x1, NULL
    // 0xf3046c: cmp             w2, NULL
    // 0xf30470: b.eq            #0xf30490
    // 0xf30474: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf30474: ldur            w4, [x2, #0x17]
    // 0xf30478: DecompressPointer r4
    //     0xf30478: add             x4, x4, HEAP, lsl #32
    // 0xf3047c: r8 = X0
    //     0xf3047c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf30480: LoadField: r9 = r4->field_7
    //     0xf30480: ldur            x9, [x4, #7]
    // 0xf30484: r3 = Null
    //     0xf30484: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d378] Null
    //     0xf30488: ldr             x3, [x3, #0x378]
    // 0xf3048c: blr             x9
    // 0xf30490: ldur            x0, [fp, #-0x18]
    // 0xf30494: LoadField: r1 = r0->field_b
    //     0xf30494: ldur            w1, [x0, #0xb]
    // 0xf30498: LoadField: r2 = r0->field_f
    //     0xf30498: ldur            w2, [x0, #0xf]
    // 0xf3049c: DecompressPointer r2
    //     0xf3049c: add             x2, x2, HEAP, lsl #32
    // 0xf304a0: LoadField: r3 = r2->field_b
    //     0xf304a0: ldur            w3, [x2, #0xb]
    // 0xf304a4: r2 = LoadInt32Instr(r1)
    //     0xf304a4: sbfx            x2, x1, #1, #0x1f
    // 0xf304a8: stur            x2, [fp, #-0x20]
    // 0xf304ac: r1 = LoadInt32Instr(r3)
    //     0xf304ac: sbfx            x1, x3, #1, #0x1f
    // 0xf304b0: cmp             x2, x1
    // 0xf304b4: b.ne            #0xf304c0
    // 0xf304b8: mov             x1, x0
    // 0xf304bc: r0 = _growToNextCapacity()
    //     0xf304bc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf304c0: ldur            x2, [fp, #-0x18]
    // 0xf304c4: ldur            x3, [fp, #-0x20]
    // 0xf304c8: add             x4, x3, #1
    // 0xf304cc: lsl             x5, x4, #1
    // 0xf304d0: StoreField: r2->field_b = r5
    //     0xf304d0: stur            w5, [x2, #0xb]
    // 0xf304d4: LoadField: r1 = r2->field_f
    //     0xf304d4: ldur            w1, [x2, #0xf]
    // 0xf304d8: DecompressPointer r1
    //     0xf304d8: add             x1, x1, HEAP, lsl #32
    // 0xf304dc: ldur            x0, [fp, #-0x10]
    // 0xf304e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf304e0: add             x25, x1, x3, lsl #2
    //     0xf304e4: add             x25, x25, #0xf
    //     0xf304e8: str             w0, [x25]
    //     0xf304ec: tbz             w0, #0, #0xf30508
    //     0xf304f0: ldurb           w16, [x1, #-1]
    //     0xf304f4: ldurb           w17, [x0, #-1]
    //     0xf304f8: and             x16, x17, x16, lsr #2
    //     0xf304fc: tst             x16, HEAP, lsr #32
    //     0xf30500: b.eq            #0xf30508
    //     0xf30504: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf30508: r0 = Null
    //     0xf30508: mov             x0, NULL
    // 0xf3050c: LeaveFrame
    //     0xf3050c: mov             SP, fp
    //     0xf30510: ldp             fp, lr, [SP], #0x10
    // 0xf30514: ret
    //     0xf30514: ret             
    // 0xf30518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3051c: b               #0xf30444
  }
  [closure] void reportImageChunkEvent(dynamic, ImageChunkEvent) {
    // ** addr: 0x11868a4, size: 0x3c
    // 0x11868a4: EnterFrame
    //     0x11868a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11868a8: mov             fp, SP
    // 0x11868ac: ldr             x0, [fp, #0x18]
    // 0x11868b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11868b0: ldur            w1, [x0, #0x17]
    // 0x11868b4: DecompressPointer r1
    //     0x11868b4: add             x1, x1, HEAP, lsl #32
    // 0x11868b8: CheckStackOverflow
    //     0x11868b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11868bc: cmp             SP, x16
    //     0x11868c0: b.ls            #0x11868d8
    // 0x11868c4: ldr             x2, [fp, #0x10]
    // 0x11868c8: r0 = reportImageChunkEvent()
    //     0x11868c8: bl              #0x11868e0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportImageChunkEvent
    // 0x11868cc: LeaveFrame
    //     0x11868cc: mov             SP, fp
    //     0x11868d0: ldp             fp, lr, [SP], #0x10
    // 0x11868d4: ret
    //     0x11868d4: ret             
    // 0x11868d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11868d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11868dc: b               #0x11868c4
  }
  _ reportImageChunkEvent(/* No info */) {
    // ** addr: 0x11868e0, size: 0x1a0
    // 0x11868e0: EnterFrame
    //     0x11868e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11868e4: mov             fp, SP
    // 0x11868e8: AllocStack(0x48)
    //     0x11868e8: sub             SP, SP, #0x48
    // 0x11868ec: SetupParameters(ImageStreamCompleter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11868ec: mov             x0, x1
    //     0x11868f0: stur            x1, [fp, #-8]
    //     0x11868f4: stur            x2, [fp, #-0x10]
    // 0x11868f8: CheckStackOverflow
    //     0x11868f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11868fc: cmp             SP, x16
    //     0x1186900: b.ls            #0x1186a70
    // 0x1186904: mov             x1, x0
    // 0x1186908: r0 = _checkDisposed()
    //     0x1186908: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0x118690c: ldur            x0, [fp, #-8]
    // 0x1186910: LoadField: r3 = r0->field_7
    //     0x1186910: ldur            w3, [x0, #7]
    // 0x1186914: DecompressPointer r3
    //     0x1186914: add             x3, x3, HEAP, lsl #32
    // 0x1186918: stur            x3, [fp, #-0x18]
    // 0x118691c: LoadField: r0 = r3->field_b
    //     0x118691c: ldur            w0, [x3, #0xb]
    // 0x1186920: cbz             w0, #0x1186a40
    // 0x1186924: r1 = Function '<anonymous closure>':.
    //     0x1186924: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d28] Function: [dart:ui] Paint::_objects (0x11006d0)
    //     0x1186928: ldr             x1, [x1, #0xd28]
    // 0x118692c: r2 = Null
    //     0x118692c: mov             x2, NULL
    // 0x1186930: r0 = AllocateClosure()
    //     0x1186930: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186934: r16 = <((dynamic this, ImageChunkEvent) => void?)?>
    //     0x1186934: add             x16, PP, #0x94, lsl #12  ; [pp+0x94d30] TypeArguments: <((dynamic this, ImageChunkEvent) => void?)?>
    //     0x1186938: ldr             x16, [x16, #0xd30]
    // 0x118693c: ldur            lr, [fp, #-0x18]
    // 0x1186940: stp             lr, x16, [SP, #8]
    // 0x1186944: str             x0, [SP]
    // 0x1186948: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1186948: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x118694c: r0 = map()
    //     0x118694c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1186950: r16 = <(dynamic this, ImageChunkEvent) => void?>
    //     0x1186950: add             x16, PP, #0x94, lsl #12  ; [pp+0x94d38] TypeArguments: <(dynamic this, ImageChunkEvent) => void?>
    //     0x1186954: ldr             x16, [x16, #0xd38]
    // 0x1186958: stp             x0, x16, [SP]
    // 0x118695c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x118695c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1186960: r0 = whereType()
    //     0x1186960: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x1186964: mov             x1, x0
    // 0x1186968: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1186968: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x118696c: r0 = toList()
    //     0x118696c: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x1186970: mov             x3, x0
    // 0x1186974: stur            x3, [fp, #-0x30]
    // 0x1186978: LoadField: r4 = r3->field_7
    //     0x1186978: ldur            w4, [x3, #7]
    // 0x118697c: DecompressPointer r4
    //     0x118697c: add             x4, x4, HEAP, lsl #32
    // 0x1186980: stur            x4, [fp, #-0x18]
    // 0x1186984: LoadField: r0 = r3->field_b
    //     0x1186984: ldur            w0, [x3, #0xb]
    // 0x1186988: r5 = LoadInt32Instr(r0)
    //     0x1186988: sbfx            x5, x0, #1, #0x1f
    // 0x118698c: stur            x5, [fp, #-0x28]
    // 0x1186990: r0 = 0
    //     0x1186990: mov             x0, #0
    // 0x1186994: CheckStackOverflow
    //     0x1186994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186998: cmp             SP, x16
    //     0x118699c: b.ls            #0x1186a78
    // 0x11869a0: LoadField: r1 = r3->field_b
    //     0x11869a0: ldur            w1, [x3, #0xb]
    // 0x11869a4: r2 = LoadInt32Instr(r1)
    //     0x11869a4: sbfx            x2, x1, #1, #0x1f
    // 0x11869a8: cmp             x5, x2
    // 0x11869ac: b.ne            #0x1186a50
    // 0x11869b0: cmp             x0, x2
    // 0x11869b4: b.ge            #0x1186a40
    // 0x11869b8: LoadField: r1 = r3->field_f
    //     0x11869b8: ldur            w1, [x3, #0xf]
    // 0x11869bc: DecompressPointer r1
    //     0x11869bc: add             x1, x1, HEAP, lsl #32
    // 0x11869c0: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x11869c0: add             x16, x1, x0, lsl #2
    //     0x11869c4: ldur            w6, [x16, #0xf]
    // 0x11869c8: DecompressPointer r6
    //     0x11869c8: add             x6, x6, HEAP, lsl #32
    // 0x11869cc: stur            x6, [fp, #-8]
    // 0x11869d0: add             x7, x0, #1
    // 0x11869d4: stur            x7, [fp, #-0x20]
    // 0x11869d8: cmp             w6, NULL
    // 0x11869dc: b.ne            #0x1186a10
    // 0x11869e0: mov             x0, x6
    // 0x11869e4: mov             x2, x4
    // 0x11869e8: r1 = Null
    //     0x11869e8: mov             x1, NULL
    // 0x11869ec: cmp             w2, NULL
    // 0x11869f0: b.eq            #0x1186a10
    // 0x11869f4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x11869f4: ldur            w4, [x2, #0x17]
    // 0x11869f8: DecompressPointer r4
    //     0x11869f8: add             x4, x4, HEAP, lsl #32
    // 0x11869fc: r8 = X0
    //     0x11869fc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1186a00: LoadField: r9 = r4->field_7
    //     0x1186a00: ldur            x9, [x4, #7]
    // 0x1186a04: r3 = Null
    //     0x1186a04: add             x3, PP, #0x94, lsl #12  ; [pp+0x94d40] Null
    //     0x1186a08: ldr             x3, [x3, #0xd40]
    // 0x1186a0c: blr             x9
    // 0x1186a10: ldur            x16, [fp, #-8]
    // 0x1186a14: ldur            lr, [fp, #-0x10]
    // 0x1186a18: stp             lr, x16, [SP]
    // 0x1186a1c: ldur            x0, [fp, #-8]
    // 0x1186a20: ClosureCall
    //     0x1186a20: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1186a24: ldur            x2, [x0, #0x1f]
    //     0x1186a28: blr             x2
    // 0x1186a2c: ldur            x0, [fp, #-0x20]
    // 0x1186a30: ldur            x3, [fp, #-0x30]
    // 0x1186a34: ldur            x4, [fp, #-0x18]
    // 0x1186a38: ldur            x5, [fp, #-0x28]
    // 0x1186a3c: b               #0x1186994
    // 0x1186a40: r0 = Null
    //     0x1186a40: mov             x0, NULL
    // 0x1186a44: LeaveFrame
    //     0x1186a44: mov             SP, fp
    //     0x1186a48: ldp             fp, lr, [SP], #0x10
    // 0x1186a4c: ret
    //     0x1186a4c: ret             
    // 0x1186a50: mov             x0, x3
    // 0x1186a54: r0 = ConcurrentModificationError()
    //     0x1186a54: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x1186a58: mov             x1, x0
    // 0x1186a5c: ldur            x0, [fp, #-0x30]
    // 0x1186a60: StoreField: r1->field_b = r0
    //     0x1186a60: stur            w0, [x1, #0xb]
    // 0x1186a64: mov             x0, x1
    // 0x1186a68: r0 = Throw()
    //     0x1186a68: bl              #0x13ddb2c  ; ThrowStub
    // 0x1186a6c: brk             #0
    // 0x1186a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186a70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186a74: b               #0x1186904
    // 0x1186a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186a78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186a7c: b               #0x11869a0
  }
  _ _maybeDispose(/* No info */) {
    // ** addr: 0x1248efc, size: 0xa8
    // 0x1248efc: EnterFrame
    //     0x1248efc: stp             fp, lr, [SP, #-0x10]!
    //     0x1248f00: mov             fp, SP
    // 0x1248f04: AllocStack(0x8)
    //     0x1248f04: sub             SP, SP, #8
    // 0x1248f08: SetupParameters(ImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0x1248f08: mov             x0, x1
    //     0x1248f0c: stur            x1, [fp, #-8]
    // 0x1248f10: CheckStackOverflow
    //     0x1248f10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1248f14: cmp             SP, x16
    //     0x1248f18: b.ls            #0x1248f9c
    // 0x1248f1c: LoadField: r1 = r0->field_27
    //     0x1248f1c: ldur            w1, [x0, #0x27]
    // 0x1248f20: DecompressPointer r1
    //     0x1248f20: add             x1, x1, HEAP, lsl #32
    // 0x1248f24: tbz             w1, #4, #0x1248f40
    // 0x1248f28: LoadField: r1 = r0->field_7
    //     0x1248f28: ldur            w1, [x0, #7]
    // 0x1248f2c: DecompressPointer r1
    //     0x1248f2c: add             x1, x1, HEAP, lsl #32
    // 0x1248f30: LoadField: r2 = r1->field_b
    //     0x1248f30: ldur            w2, [x1, #0xb]
    // 0x1248f34: cbnz            w2, #0x1248f40
    // 0x1248f38: LoadField: r1 = r0->field_1f
    //     0x1248f38: ldur            x1, [x0, #0x1f]
    // 0x1248f3c: cbz             x1, #0x1248f50
    // 0x1248f40: r0 = Null
    //     0x1248f40: mov             x0, NULL
    // 0x1248f44: LeaveFrame
    //     0x1248f44: mov             SP, fp
    //     0x1248f48: ldp             fp, lr, [SP], #0x10
    // 0x1248f4c: ret
    //     0x1248f4c: ret             
    // 0x1248f50: LoadField: r1 = r0->field_b
    //     0x1248f50: ldur            w1, [x0, #0xb]
    // 0x1248f54: DecompressPointer r1
    //     0x1248f54: add             x1, x1, HEAP, lsl #32
    // 0x1248f58: r0 = clear()
    //     0x1248f58: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x1248f5c: ldur            x0, [fp, #-8]
    // 0x1248f60: LoadField: r1 = r0->field_f
    //     0x1248f60: ldur            w1, [x0, #0xf]
    // 0x1248f64: DecompressPointer r1
    //     0x1248f64: add             x1, x1, HEAP, lsl #32
    // 0x1248f68: cmp             w1, NULL
    // 0x1248f6c: b.ne            #0x1248f78
    // 0x1248f70: mov             x1, x0
    // 0x1248f74: b               #0x1248f80
    // 0x1248f78: r0 = dispose()
    //     0x1248f78: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0x1248f7c: ldur            x1, [fp, #-8]
    // 0x1248f80: r2 = true
    //     0x1248f80: add             x2, NULL, #0x20  ; true
    // 0x1248f84: StoreField: r1->field_f = rNULL
    //     0x1248f84: stur            NULL, [x1, #0xf]
    // 0x1248f88: StoreField: r1->field_27 = r2
    //     0x1248f88: stur            w2, [x1, #0x27]
    // 0x1248f8c: r0 = Null
    //     0x1248f8c: mov             x0, NULL
    // 0x1248f90: LeaveFrame
    //     0x1248f90: mov             SP, fp
    //     0x1248f94: ldp             fp, lr, [SP], #0x10
    // 0x1248f98: ret
    //     0x1248f98: ret             
    // 0x1248f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1248f9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1248fa0: b               #0x1248f1c
  }
  _ keepAlive(/* No info */) {
    // ** addr: 0x12490c8, size: 0x54
    // 0x12490c8: EnterFrame
    //     0x12490c8: stp             fp, lr, [SP, #-0x10]!
    //     0x12490cc: mov             fp, SP
    // 0x12490d0: AllocStack(0x8)
    //     0x12490d0: sub             SP, SP, #8
    // 0x12490d4: SetupParameters(ImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0x12490d4: mov             x0, x1
    //     0x12490d8: stur            x1, [fp, #-8]
    // 0x12490dc: CheckStackOverflow
    //     0x12490dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12490e0: cmp             SP, x16
    //     0x12490e4: b.ls            #0x1249114
    // 0x12490e8: mov             x1, x0
    // 0x12490ec: r0 = _checkDisposed()
    //     0x12490ec: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0x12490f0: r0 = ImageStreamCompleterHandle()
    //     0x12490f0: bl              #0xd09ce4  ; AllocateImageStreamCompleterHandleStub -> ImageStreamCompleterHandle (size=0xc)
    // 0x12490f4: ldur            x1, [fp, #-8]
    // 0x12490f8: StoreField: r0->field_7 = r1
    //     0x12490f8: stur            w1, [x0, #7]
    // 0x12490fc: LoadField: r2 = r1->field_1f
    //     0x12490fc: ldur            x2, [x1, #0x1f]
    // 0x1249100: add             x3, x2, #1
    // 0x1249104: StoreField: r1->field_1f = r3
    //     0x1249104: stur            x3, [x1, #0x1f]
    // 0x1249108: LeaveFrame
    //     0x1249108: mov             SP, fp
    //     0x124910c: ldp             fp, lr, [SP], #0x10
    // 0x1249110: ret
    //     0x1249110: ret             
    // 0x1249114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249118: b               #0x12490e8
  }
  _ addListener(/* No info */) {
    // ** addr: 0x124a354, size: 0x2b0
    // 0x124a354: EnterFrame
    //     0x124a354: stp             fp, lr, [SP, #-0x10]!
    //     0x124a358: mov             fp, SP
    // 0x124a35c: AllocStack(0xa0)
    //     0x124a35c: sub             SP, SP, #0xa0
    // 0x124a360: SetupParameters(ImageStreamCompleter this /* r1 => r2, fp-0x60 */, dynamic _ /* r2 => r0, fp-0x68 */)
    //     0x124a360: mov             x0, x2
    //     0x124a364: stur            x2, [fp, #-0x68]
    //     0x124a368: mov             x2, x1
    //     0x124a36c: stur            x1, [fp, #-0x60]
    // 0x124a370: CheckStackOverflow
    //     0x124a370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a374: cmp             SP, x16
    //     0x124a378: b.ls            #0x124a5f8
    // 0x124a37c: mov             x1, x2
    // 0x124a380: r0 = _checkDisposed()
    //     0x124a380: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0x124a384: ldur            x0, [fp, #-0x60]
    // 0x124a388: LoadField: r2 = r0->field_7
    //     0x124a388: ldur            w2, [x0, #7]
    // 0x124a38c: DecompressPointer r2
    //     0x124a38c: add             x2, x2, HEAP, lsl #32
    // 0x124a390: stur            x2, [fp, #-0x78]
    // 0x124a394: LoadField: r1 = r2->field_b
    //     0x124a394: ldur            w1, [x2, #0xb]
    // 0x124a398: LoadField: r3 = r2->field_f
    //     0x124a398: ldur            w3, [x2, #0xf]
    // 0x124a39c: DecompressPointer r3
    //     0x124a39c: add             x3, x3, HEAP, lsl #32
    // 0x124a3a0: LoadField: r4 = r3->field_b
    //     0x124a3a0: ldur            w4, [x3, #0xb]
    // 0x124a3a4: r3 = LoadInt32Instr(r1)
    //     0x124a3a4: sbfx            x3, x1, #1, #0x1f
    // 0x124a3a8: stur            x3, [fp, #-0x70]
    // 0x124a3ac: r1 = LoadInt32Instr(r4)
    //     0x124a3ac: sbfx            x1, x4, #1, #0x1f
    // 0x124a3b0: cmp             x3, x1
    // 0x124a3b4: b.ne            #0x124a3c0
    // 0x124a3b8: mov             x1, x2
    // 0x124a3bc: r0 = _growToNextCapacity()
    //     0x124a3bc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x124a3c0: ldur            x2, [fp, #-0x60]
    // 0x124a3c4: ldur            x0, [fp, #-0x78]
    // 0x124a3c8: ldur            x3, [fp, #-0x70]
    // 0x124a3cc: add             x1, x3, #1
    // 0x124a3d0: lsl             x4, x1, #1
    // 0x124a3d4: StoreField: r0->field_b = r4
    //     0x124a3d4: stur            w4, [x0, #0xb]
    // 0x124a3d8: LoadField: r1 = r0->field_f
    //     0x124a3d8: ldur            w1, [x0, #0xf]
    // 0x124a3dc: DecompressPointer r1
    //     0x124a3dc: add             x1, x1, HEAP, lsl #32
    // 0x124a3e0: ldur            x0, [fp, #-0x68]
    // 0x124a3e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x124a3e4: add             x25, x1, x3, lsl #2
    //     0x124a3e8: add             x25, x25, #0xf
    //     0x124a3ec: str             w0, [x25]
    //     0x124a3f0: tbz             w0, #0, #0x124a40c
    //     0x124a3f4: ldurb           w16, [x1, #-1]
    //     0x124a3f8: ldurb           w17, [x0, #-1]
    //     0x124a3fc: and             x16, x17, x16, lsr #2
    //     0x124a400: tst             x16, HEAP, lsr #32
    //     0x124a404: b.eq            #0x124a40c
    //     0x124a408: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x124a40c: LoadField: r1 = r2->field_f
    //     0x124a40c: ldur            w1, [x2, #0xf]
    // 0x124a410: DecompressPointer r1
    //     0x124a410: add             x1, x1, HEAP, lsl #32
    // 0x124a414: cmp             w1, NULL
    // 0x124a418: b.eq            #0x124a4d4
    // 0x124a41c: ldur            x0, [fp, #-0x68]
    // 0x124a420: r0 = clone()
    //     0x124a420: bl              #0xd08a74  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::clone
    // 0x124a424: mov             x2, x0
    // 0x124a428: ldur            x1, [fp, #-0x60]
    // 0x124a42c: stur            x2, [fp, #-0x88]
    // 0x124a430: LoadField: r0 = r1->field_1b
    //     0x124a430: ldur            w0, [x1, #0x1b]
    // 0x124a434: DecompressPointer r0
    //     0x124a434: add             x0, x0, HEAP, lsl #32
    // 0x124a438: eor             x3, x0, #0x10
    // 0x124a43c: ldur            x4, [fp, #-0x68]
    // 0x124a440: stur            x3, [fp, #-0x80]
    // 0x124a444: LoadField: r5 = r4->field_7
    //     0x124a444: ldur            w5, [x4, #7]
    // 0x124a448: DecompressPointer r5
    //     0x124a448: add             x5, x5, HEAP, lsl #32
    // 0x124a44c: stur            x5, [fp, #-0x78]
    // 0x124a450: stp             x2, x5, [SP, #8]
    // 0x124a454: str             x3, [SP]
    // 0x124a458: mov             x0, x5
    // 0x124a45c: ClosureCall
    //     0x124a45c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x124a460: ldur            x2, [x0, #0x1f]
    //     0x124a464: blr             x2
    // 0x124a468: r1 = Null
    //     0x124a468: mov             x1, NULL
    // 0x124a46c: r0 = Null
    //     0x124a46c: mov             x0, NULL
    // 0x124a470: b               #0x124a4c8
    // 0x124a474: sub             SP, fp, #0xa0
    // 0x124a478: mov             x3, x0
    // 0x124a47c: mov             x5, x1
    // 0x124a480: stur            x0, [fp, #-0x78]
    // 0x124a484: stur            x1, [fp, #-0x80]
    // 0x124a488: r1 = <List<Object>>
    //     0x124a488: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x124a48c: r0 = ErrorDescription()
    //     0x124a48c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x124a490: mov             x1, x0
    // 0x124a494: r2 = "by a synchronously-called image listener"
    //     0x124a494: add             x2, PP, #0x81, lsl #12  ; [pp+0x81398] "by a synchronously-called image listener"
    //     0x124a498: ldr             x2, [x2, #0x398]
    // 0x124a49c: r3 = Instance_DiagnosticLevel
    //     0x124a49c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x124a4a0: stur            x0, [fp, #-0x88]
    // 0x124a4a4: r0 = _ErrorDiagnostic()
    //     0x124a4a4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x124a4a8: ldur            x1, [fp, #-0x60]
    // 0x124a4ac: ldur            x2, [fp, #-0x88]
    // 0x124a4b0: ldur            x3, [fp, #-0x78]
    // 0x124a4b4: ldur            x5, [fp, #-0x80]
    // 0x124a4b8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x124a4b8: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x124a4bc: r0 = reportError()
    //     0x124a4bc: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0x124a4c0: ldur            x1, [fp, #-0x80]
    // 0x124a4c4: ldur            x0, [fp, #-0x78]
    // 0x124a4c8: mov             x3, x1
    // 0x124a4cc: mov             x2, x0
    // 0x124a4d0: b               #0x124a4dc
    // 0x124a4d4: r3 = Null
    //     0x124a4d4: mov             x3, NULL
    // 0x124a4d8: r2 = Null
    //     0x124a4d8: mov             x2, NULL
    // 0x124a4dc: ldur            x1, [fp, #-0x60]
    // 0x124a4e0: stur            x3, [fp, #-0x80]
    // 0x124a4e4: stur            x2, [fp, #-0x88]
    // 0x124a4e8: LoadField: r0 = r1->field_13
    //     0x124a4e8: ldur            w0, [x1, #0x13]
    // 0x124a4ec: DecompressPointer r0
    //     0x124a4ec: add             x0, x0, HEAP, lsl #32
    // 0x124a4f0: cmp             w0, NULL
    // 0x124a4f4: b.eq            #0x124a5e8
    // 0x124a4f8: ldur            x4, [fp, #-0x68]
    // 0x124a4fc: LoadField: r5 = r4->field_f
    //     0x124a4fc: ldur            w5, [x4, #0xf]
    // 0x124a500: DecompressPointer r5
    //     0x124a500: add             x5, x5, HEAP, lsl #32
    // 0x124a504: stur            x5, [fp, #-0x78]
    // 0x124a508: cmp             w5, NULL
    // 0x124a50c: b.eq            #0x124a5e8
    // 0x124a510: LoadField: r6 = r0->field_7
    //     0x124a510: ldur            w6, [x0, #7]
    // 0x124a514: DecompressPointer r6
    //     0x124a514: add             x6, x6, HEAP, lsl #32
    // 0x124a518: LoadField: r7 = r0->field_b
    //     0x124a518: ldur            w7, [x0, #0xb]
    // 0x124a51c: DecompressPointer r7
    //     0x124a51c: add             x7, x7, HEAP, lsl #32
    // 0x124a520: stp             x6, x5, [SP, #8]
    // 0x124a524: str             x7, [SP]
    // 0x124a528: mov             x0, x5
    // 0x124a52c: ClosureCall
    //     0x124a52c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x124a530: ldur            x2, [x0, #0x1f]
    //     0x124a534: blr             x2
    // 0x124a538: b               #0x124a5e8
    // 0x124a53c: sub             SP, fp, #0xa0
    // 0x124a540: ldur            x2, [fp, #-0x60]
    // 0x124a544: mov             x3, x0
    // 0x124a548: stur            x0, [fp, #-0x68]
    // 0x124a54c: stur            x1, [fp, #-0x78]
    // 0x124a550: LoadField: r0 = r2->field_13
    //     0x124a550: ldur            w0, [x2, #0x13]
    // 0x124a554: DecompressPointer r0
    //     0x124a554: add             x0, x0, HEAP, lsl #32
    // 0x124a558: cmp             w0, NULL
    // 0x124a55c: b.eq            #0x124a600
    // 0x124a560: LoadField: r2 = r0->field_7
    //     0x124a560: ldur            w2, [x0, #7]
    // 0x124a564: DecompressPointer r2
    //     0x124a564: add             x2, x2, HEAP, lsl #32
    // 0x124a568: r0 = 60
    //     0x124a568: mov             x0, #0x3c
    // 0x124a56c: branchIfSmi(r3, 0x124a578)
    //     0x124a56c: tbz             w3, #0, #0x124a578
    // 0x124a570: r0 = LoadClassIdInstr(r3)
    //     0x124a570: ldur            x0, [x3, #-1]
    //     0x124a574: ubfx            x0, x0, #0xc, #0x14
    // 0x124a578: stp             x2, x3, [SP]
    // 0x124a57c: mov             lr, x0
    // 0x124a580: ldr             lr, [x21, lr, lsl #3]
    // 0x124a584: blr             lr
    // 0x124a588: tbz             w0, #4, #0x124a5e8
    // 0x124a58c: ldur            x2, [fp, #-0x68]
    // 0x124a590: ldur            x0, [fp, #-0x78]
    // 0x124a594: r1 = <List<Object>>
    //     0x124a594: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x124a598: r0 = ErrorDescription()
    //     0x124a598: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x124a59c: mov             x1, x0
    // 0x124a5a0: r2 = "by a synchronously-called image error listener"
    //     0x124a5a0: add             x2, PP, #0x81, lsl #12  ; [pp+0x813a0] "by a synchronously-called image error listener"
    //     0x124a5a4: ldr             x2, [x2, #0x3a0]
    // 0x124a5a8: r3 = Instance_DiagnosticLevel
    //     0x124a5a8: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x124a5ac: stur            x0, [fp, #-0x60]
    // 0x124a5b0: r0 = _ErrorDiagnostic()
    //     0x124a5b0: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x124a5b4: r0 = FlutterErrorDetails()
    //     0x124a5b4: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x124a5b8: mov             x1, x0
    // 0x124a5bc: ldur            x0, [fp, #-0x68]
    // 0x124a5c0: StoreField: r1->field_7 = r0
    //     0x124a5c0: stur            w0, [x1, #7]
    // 0x124a5c4: ldur            x0, [fp, #-0x78]
    // 0x124a5c8: StoreField: r1->field_b = r0
    //     0x124a5c8: stur            w0, [x1, #0xb]
    // 0x124a5cc: r0 = "image resource service"
    //     0x124a5cc: ldr             x0, [PP, #0x7da8]  ; [pp+0x7da8] "image resource service"
    // 0x124a5d0: StoreField: r1->field_f = r0
    //     0x124a5d0: stur            w0, [x1, #0xf]
    // 0x124a5d4: ldur            x0, [fp, #-0x60]
    // 0x124a5d8: StoreField: r1->field_13 = r0
    //     0x124a5d8: stur            w0, [x1, #0x13]
    // 0x124a5dc: r0 = false
    //     0x124a5dc: add             x0, NULL, #0x30  ; false
    // 0x124a5e0: StoreField: r1->field_1b = r0
    //     0x124a5e0: stur            w0, [x1, #0x1b]
    // 0x124a5e4: r0 = reportError()
    //     0x124a5e4: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x124a5e8: r0 = Null
    //     0x124a5e8: mov             x0, NULL
    // 0x124a5ec: LeaveFrame
    //     0x124a5ec: mov             SP, fp
    //     0x124a5f0: ldp             fp, lr, [SP], #0x10
    // 0x124a5f4: ret
    //     0x124a5f4: ret             
    // 0x124a5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a5f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a5fc: b               #0x124a37c
    // 0x124a600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124a600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x12539dc, size: 0x204
    // 0x12539dc: EnterFrame
    //     0x12539dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12539e0: mov             fp, SP
    // 0x12539e4: AllocStack(0x48)
    //     0x12539e4: sub             SP, SP, #0x48
    // 0x12539e8: SetupParameters(ImageStreamCompleter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12539e8: mov             x0, x1
    //     0x12539ec: stur            x1, [fp, #-8]
    //     0x12539f0: stur            x2, [fp, #-0x10]
    // 0x12539f4: CheckStackOverflow
    //     0x12539f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12539f8: cmp             SP, x16
    //     0x12539fc: b.ls            #0x1253bc8
    // 0x1253a00: mov             x1, x0
    // 0x1253a04: r0 = _checkDisposed()
    //     0x1253a04: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0x1253a08: ldur            x1, [fp, #-8]
    // 0x1253a0c: LoadField: r0 = r1->field_7
    //     0x1253a0c: ldur            w0, [x1, #7]
    // 0x1253a10: DecompressPointer r0
    //     0x1253a10: add             x0, x0, HEAP, lsl #32
    // 0x1253a14: stur            x0, [fp, #-0x20]
    // 0x1253a18: r2 = 0
    //     0x1253a18: mov             x2, #0
    // 0x1253a1c: stur            x2, [fp, #-0x18]
    // 0x1253a20: CheckStackOverflow
    //     0x1253a20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1253a24: cmp             SP, x16
    //     0x1253a28: b.ls            #0x1253bd0
    // 0x1253a2c: LoadField: r3 = r0->field_b
    //     0x1253a2c: ldur            w3, [x0, #0xb]
    // 0x1253a30: r4 = LoadInt32Instr(r3)
    //     0x1253a30: sbfx            x4, x3, #1, #0x1f
    // 0x1253a34: cmp             x2, x4
    // 0x1253a38: b.ge            #0x1253a84
    // 0x1253a3c: LoadField: r3 = r0->field_f
    //     0x1253a3c: ldur            w3, [x0, #0xf]
    // 0x1253a40: DecompressPointer r3
    //     0x1253a40: add             x3, x3, HEAP, lsl #32
    // 0x1253a44: ArrayLoad: r4 = r3[r2]  ; Unknown_4
    //     0x1253a44: add             x16, x3, x2, lsl #2
    //     0x1253a48: ldur            w4, [x16, #0xf]
    // 0x1253a4c: DecompressPointer r4
    //     0x1253a4c: add             x4, x4, HEAP, lsl #32
    // 0x1253a50: ldur            x16, [fp, #-0x10]
    // 0x1253a54: stp             x16, x4, [SP]
    // 0x1253a58: r0 = ==()
    //     0x1253a58: bl              #0x12994cc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamListener::==
    // 0x1253a5c: tbz             w0, #4, #0x1253a78
    // 0x1253a60: ldur            x2, [fp, #-0x18]
    // 0x1253a64: add             x0, x2, #1
    // 0x1253a68: mov             x2, x0
    // 0x1253a6c: ldur            x1, [fp, #-8]
    // 0x1253a70: ldur            x0, [fp, #-0x20]
    // 0x1253a74: b               #0x1253a1c
    // 0x1253a78: ldur            x2, [fp, #-0x18]
    // 0x1253a7c: ldur            x1, [fp, #-0x20]
    // 0x1253a80: r0 = removeAt()
    //     0x1253a80: bl              #0x9fac48  ; [dart:core] _GrowableList::removeAt
    // 0x1253a84: ldur            x0, [fp, #-0x20]
    // 0x1253a88: LoadField: r1 = r0->field_b
    //     0x1253a88: ldur            w1, [x0, #0xb]
    // 0x1253a8c: cbnz            w1, #0x1253b98
    // 0x1253a90: ldur            x0, [fp, #-8]
    // 0x1253a94: LoadField: r2 = r0->field_2b
    //     0x1253a94: ldur            w2, [x0, #0x2b]
    // 0x1253a98: DecompressPointer r2
    //     0x1253a98: add             x2, x2, HEAP, lsl #32
    // 0x1253a9c: mov             x1, x2
    // 0x1253aa0: stur            x2, [fp, #-0x10]
    // 0x1253aa4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1253aa4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1253aa8: r0 = toList()
    //     0x1253aa8: bl              #0xbb6108  ; [dart:core] _GrowableList::toList
    // 0x1253aac: mov             x3, x0
    // 0x1253ab0: stur            x3, [fp, #-0x38]
    // 0x1253ab4: LoadField: r4 = r3->field_7
    //     0x1253ab4: ldur            w4, [x3, #7]
    // 0x1253ab8: DecompressPointer r4
    //     0x1253ab8: add             x4, x4, HEAP, lsl #32
    // 0x1253abc: stur            x4, [fp, #-0x30]
    // 0x1253ac0: LoadField: r0 = r3->field_b
    //     0x1253ac0: ldur            w0, [x3, #0xb]
    // 0x1253ac4: r5 = LoadInt32Instr(r0)
    //     0x1253ac4: sbfx            x5, x0, #1, #0x1f
    // 0x1253ac8: stur            x5, [fp, #-0x28]
    // 0x1253acc: r0 = 0
    //     0x1253acc: mov             x0, #0
    // 0x1253ad0: CheckStackOverflow
    //     0x1253ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1253ad4: cmp             SP, x16
    //     0x1253ad8: b.ls            #0x1253bd8
    // 0x1253adc: LoadField: r1 = r3->field_b
    //     0x1253adc: ldur            w1, [x3, #0xb]
    // 0x1253ae0: r2 = LoadInt32Instr(r1)
    //     0x1253ae0: sbfx            x2, x1, #1, #0x1f
    // 0x1253ae4: cmp             x5, x2
    // 0x1253ae8: b.ne            #0x1253ba8
    // 0x1253aec: cmp             x0, x2
    // 0x1253af0: b.ge            #0x1253b74
    // 0x1253af4: LoadField: r1 = r3->field_f
    //     0x1253af4: ldur            w1, [x3, #0xf]
    // 0x1253af8: DecompressPointer r1
    //     0x1253af8: add             x1, x1, HEAP, lsl #32
    // 0x1253afc: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x1253afc: add             x16, x1, x0, lsl #2
    //     0x1253b00: ldur            w6, [x16, #0xf]
    // 0x1253b04: DecompressPointer r6
    //     0x1253b04: add             x6, x6, HEAP, lsl #32
    // 0x1253b08: stur            x6, [fp, #-0x20]
    // 0x1253b0c: add             x7, x0, #1
    // 0x1253b10: stur            x7, [fp, #-0x18]
    // 0x1253b14: cmp             w6, NULL
    // 0x1253b18: b.ne            #0x1253b48
    // 0x1253b1c: mov             x0, x6
    // 0x1253b20: mov             x2, x4
    // 0x1253b24: r1 = Null
    //     0x1253b24: mov             x1, NULL
    // 0x1253b28: cmp             w2, NULL
    // 0x1253b2c: b.eq            #0x1253b48
    // 0x1253b30: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1253b30: ldur            w4, [x2, #0x17]
    // 0x1253b34: DecompressPointer r4
    //     0x1253b34: add             x4, x4, HEAP, lsl #32
    // 0x1253b38: r8 = X0
    //     0x1253b38: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1253b3c: LoadField: r9 = r4->field_7
    //     0x1253b3c: ldur            x9, [x4, #7]
    // 0x1253b40: r3 = Null
    //     0x1253b40: ldr             x3, [PP, #0x34c8]  ; [pp+0x34c8] Null
    // 0x1253b44: blr             x9
    // 0x1253b48: ldur            x16, [fp, #-0x20]
    // 0x1253b4c: str             x16, [SP]
    // 0x1253b50: ldur            x0, [fp, #-0x20]
    // 0x1253b54: ClosureCall
    //     0x1253b54: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x1253b58: ldur            x2, [x0, #0x1f]
    //     0x1253b5c: blr             x2
    // 0x1253b60: ldur            x0, [fp, #-0x18]
    // 0x1253b64: ldur            x3, [fp, #-0x38]
    // 0x1253b68: ldur            x4, [fp, #-0x30]
    // 0x1253b6c: ldur            x5, [fp, #-0x28]
    // 0x1253b70: b               #0x1253ad0
    // 0x1253b74: ldur            x0, [fp, #-8]
    // 0x1253b78: ldur            x1, [fp, #-0x10]
    // 0x1253b7c: r0 = clear()
    //     0x1253b7c: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x1253b80: ldur            x1, [fp, #-8]
    // 0x1253b84: r0 = LoadClassIdInstr(r1)
    //     0x1253b84: ldur            x0, [x1, #-1]
    //     0x1253b88: ubfx            x0, x0, #0xc, #0x14
    // 0x1253b8c: r0 = GDT[cid_x0 + 0xe80]()
    //     0x1253b8c: add             lr, x0, #0xe80
    //     0x1253b90: ldr             lr, [x21, lr, lsl #3]
    //     0x1253b94: blr             lr
    // 0x1253b98: r0 = Null
    //     0x1253b98: mov             x0, NULL
    // 0x1253b9c: LeaveFrame
    //     0x1253b9c: mov             SP, fp
    //     0x1253ba0: ldp             fp, lr, [SP], #0x10
    // 0x1253ba4: ret
    //     0x1253ba4: ret             
    // 0x1253ba8: mov             x0, x3
    // 0x1253bac: r0 = ConcurrentModificationError()
    //     0x1253bac: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x1253bb0: mov             x1, x0
    // 0x1253bb4: ldur            x0, [fp, #-0x38]
    // 0x1253bb8: StoreField: r1->field_b = r0
    //     0x1253bb8: stur            w0, [x1, #0xb]
    // 0x1253bbc: mov             x0, x1
    // 0x1253bc0: r0 = Throw()
    //     0x1253bc0: bl              #0x13ddb2c  ; ThrowStub
    // 0x1253bc4: brk             #0
    // 0x1253bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1253bc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1253bcc: b               #0x1253a00
    // 0x1253bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1253bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1253bd4: b               #0x1253a2c
    // 0x1253bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1253bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1253bdc: b               #0x1253adc
  }
}

// class id: 5244, size: 0x60, field offset: 0x30
class MultiFrameImageStreamCompleter extends ImageStreamCompleter {

  late Duration _shownTimestamp; // offset: 0x48

  [closure] void addListener(dynamic, ImageStreamListener) {
    // ** addr: 0x91a9dc, size: 0x3c
    // 0x91a9dc: EnterFrame
    //     0x91a9dc: stp             fp, lr, [SP, #-0x10]!
    //     0x91a9e0: mov             fp, SP
    // 0x91a9e4: ldr             x0, [fp, #0x18]
    // 0x91a9e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91a9e8: ldur            w1, [x0, #0x17]
    // 0x91a9ec: DecompressPointer r1
    //     0x91a9ec: add             x1, x1, HEAP, lsl #32
    // 0x91a9f0: CheckStackOverflow
    //     0x91a9f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a9f4: cmp             SP, x16
    //     0x91a9f8: b.ls            #0x91aa10
    // 0x91a9fc: ldr             x2, [fp, #0x10]
    // 0x91aa00: r0 = addListener()
    //     0x91aa00: bl              #0x124a604  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::addListener
    // 0x91aa04: LeaveFrame
    //     0x91aa04: mov             SP, fp
    //     0x91aa08: ldp             fp, lr, [SP], #0x10
    // 0x91aa0c: ret
    //     0x91aa0c: ret             
    // 0x91aa10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91aa10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91aa14: b               #0x91a9fc
  }
  _ _emitFrame(/* No info */) {
    // ** addr: 0xd08718, size: 0x50
    // 0xd08718: EnterFrame
    //     0xd08718: stp             fp, lr, [SP, #-0x10]!
    //     0xd0871c: mov             fp, SP
    // 0xd08720: AllocStack(0x8)
    //     0xd08720: sub             SP, SP, #8
    // 0xd08724: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0xd08724: mov             x0, x1
    //     0xd08728: stur            x1, [fp, #-8]
    // 0xd0872c: CheckStackOverflow
    //     0xd0872c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08730: cmp             SP, x16
    //     0xd08734: b.ls            #0xd08760
    // 0xd08738: mov             x1, x0
    // 0xd0873c: r0 = setImage()
    //     0xd0873c: bl              #0xd08768  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::setImage
    // 0xd08740: ldur            x1, [fp, #-8]
    // 0xd08744: LoadField: r2 = r1->field_4f
    //     0xd08744: ldur            x2, [x1, #0x4f]
    // 0xd08748: add             x3, x2, #1
    // 0xd0874c: StoreField: r1->field_4f = r3
    //     0xd0874c: stur            x3, [x1, #0x4f]
    // 0xd08750: r0 = Null
    //     0xd08750: mov             x0, NULL
    // 0xd08754: LeaveFrame
    //     0xd08754: mov             SP, fp
    //     0xd08758: ldp             fp, lr, [SP], #0x10
    // 0xd0875c: ret
    //     0xd0875c: ret             
    // 0xd08760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08764: b               #0xd08738
  }
  _ _decodeNextFrameAndSchedule(/* No info */) async {
    // ** addr: 0xd08bb4, size: 0x278
    // 0xd08bb4: EnterFrame
    //     0xd08bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd08bb8: mov             fp, SP
    // 0xd08bbc: AllocStack(0xb0)
    //     0xd08bbc: sub             SP, SP, #0xb0
    // 0xd08bc0: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r1, fp-0x78 */)
    //     0xd08bc0: stur            NULL, [fp, #-8]
    //     0xd08bc4: stur            x1, [fp, #-0x78]
    // 0xd08bc8: CheckStackOverflow
    //     0xd08bc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08bcc: cmp             SP, x16
    //     0xd08bd0: b.ls            #0xd08e14
    // 0xd08bd4: InitAsync() -> Future<void?>
    //     0xd08bd4: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd08bd8: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd08bdc: ldur            x0, [fp, #-0x78]
    // 0xd08be0: LoadField: r1 = r0->field_43
    //     0xd08be0: ldur            w1, [x0, #0x43]
    // 0xd08be4: DecompressPointer r1
    //     0xd08be4: add             x1, x1, HEAP, lsl #32
    // 0xd08be8: cmp             w1, NULL
    // 0xd08bec: b.eq            #0xd08c04
    // 0xd08bf0: LoadField: r2 = r1->field_b
    //     0xd08bf0: ldur            w2, [x1, #0xb]
    // 0xd08bf4: DecompressPointer r2
    //     0xd08bf4: add             x2, x2, HEAP, lsl #32
    // 0xd08bf8: mov             x1, x2
    // 0xd08bfc: r0 = dispose()
    //     0xd08bfc: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xd08c00: ldur            x0, [fp, #-0x78]
    // 0xd08c04: StoreField: r0->field_43 = rNULL
    //     0xd08c04: stur            NULL, [x0, #0x43]
    // 0xd08c08: LoadField: r1 = r0->field_33
    //     0xd08c08: ldur            w1, [x0, #0x33]
    // 0xd08c0c: DecompressPointer r1
    //     0xd08c0c: add             x1, x1, HEAP, lsl #32
    // 0xd08c10: cmp             w1, NULL
    // 0xd08c14: b.eq            #0xd08e1c
    // 0xd08c18: r0 = getNextFrame()
    //     0xd08c18: bl              #0xce94b4  ; [dart:ui] _NativeCodec::getNextFrame
    // 0xd08c1c: mov             x1, x0
    // 0xd08c20: stur            x1, [fp, #-0x80]
    // 0xd08c24: r0 = Await()
    //     0xd08c24: bl              #0x7f5c00  ; AwaitStub
    // 0xd08c28: ldur            x2, [fp, #-0x78]
    // 0xd08c2c: StoreField: r2->field_43 = r0
    //     0xd08c2c: stur            w0, [x2, #0x43]
    //     0xd08c30: ldurb           w16, [x2, #-1]
    //     0xd08c34: ldurb           w17, [x0, #-1]
    //     0xd08c38: and             x16, x17, x16, lsr #2
    //     0xd08c3c: tst             x16, HEAP, lsr #32
    //     0xd08c40: b.eq            #0xd08c48
    //     0xd08c44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd08c48: LoadField: r1 = r2->field_33
    //     0xd08c48: ldur            w1, [x2, #0x33]
    // 0xd08c4c: DecompressPointer r1
    //     0xd08c4c: add             x1, x1, HEAP, lsl #32
    // 0xd08c50: cmp             w1, NULL
    // 0xd08c54: b.ne            #0xd08c60
    // 0xd08c58: r0 = Null
    //     0xd08c58: mov             x0, NULL
    // 0xd08c5c: r0 = ReturnAsyncNotFuture()
    //     0xd08c5c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08c60: r0 = frameCount()
    //     0xd08c60: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd08c64: cmp             x0, #1
    // 0xd08c68: b.ne            #0xd08d84
    // 0xd08c6c: ldur            x0, [fp, #-0x78]
    // 0xd08c70: LoadField: r1 = r0->field_7
    //     0xd08c70: ldur            w1, [x0, #7]
    // 0xd08c74: DecompressPointer r1
    //     0xd08c74: add             x1, x1, HEAP, lsl #32
    // 0xd08c78: LoadField: r2 = r1->field_b
    //     0xd08c78: ldur            w2, [x1, #0xb]
    // 0xd08c7c: cbnz            w2, #0xd08c88
    // 0xd08c80: r0 = Null
    //     0xd08c80: mov             x0, NULL
    // 0xd08c84: r0 = ReturnAsyncNotFuture()
    //     0xd08c84: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08c88: LoadField: r1 = r0->field_43
    //     0xd08c88: ldur            w1, [x0, #0x43]
    // 0xd08c8c: DecompressPointer r1
    //     0xd08c8c: add             x1, x1, HEAP, lsl #32
    // 0xd08c90: cmp             w1, NULL
    // 0xd08c94: b.eq            #0xd08e20
    // 0xd08c98: LoadField: r2 = r1->field_b
    //     0xd08c98: ldur            w2, [x1, #0xb]
    // 0xd08c9c: DecompressPointer r2
    //     0xd08c9c: add             x2, x2, HEAP, lsl #32
    // 0xd08ca0: mov             x1, x2
    // 0xd08ca4: r0 = clone()
    //     0xd08ca4: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0xd08ca8: ldur            x1, [fp, #-0x78]
    // 0xd08cac: stur            x0, [fp, #-0x88]
    // 0xd08cb0: LoadField: d0 = r1->field_37
    //     0xd08cb0: ldur            d0, [x1, #0x37]
    // 0xd08cb4: stur            d0, [fp, #-0xa0]
    // 0xd08cb8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd08cb8: ldur            w2, [x1, #0x17]
    // 0xd08cbc: DecompressPointer r2
    //     0xd08cbc: add             x2, x2, HEAP, lsl #32
    // 0xd08cc0: stur            x2, [fp, #-0x80]
    // 0xd08cc4: r0 = ImageInfo()
    //     0xd08cc4: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd08cc8: mov             x1, x0
    // 0xd08ccc: ldur            x0, [fp, #-0x88]
    // 0xd08cd0: StoreField: r1->field_7 = r0
    //     0xd08cd0: stur            w0, [x1, #7]
    // 0xd08cd4: ldur            d0, [fp, #-0xa0]
    // 0xd08cd8: StoreField: r1->field_b = d0
    //     0xd08cd8: stur            d0, [x1, #0xb]
    // 0xd08cdc: ldur            x0, [fp, #-0x80]
    // 0xd08ce0: StoreField: r1->field_13 = r0
    //     0xd08ce0: stur            w0, [x1, #0x13]
    // 0xd08ce4: mov             x2, x1
    // 0xd08ce8: ldur            x1, [fp, #-0x78]
    // 0xd08cec: r0 = _emitFrame()
    //     0xd08cec: bl              #0xd08718  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xd08cf0: ldur            x0, [fp, #-0x78]
    // 0xd08cf4: LoadField: r1 = r0->field_43
    //     0xd08cf4: ldur            w1, [x0, #0x43]
    // 0xd08cf8: DecompressPointer r1
    //     0xd08cf8: add             x1, x1, HEAP, lsl #32
    // 0xd08cfc: cmp             w1, NULL
    // 0xd08d00: b.eq            #0xd08e24
    // 0xd08d04: LoadField: r2 = r1->field_b
    //     0xd08d04: ldur            w2, [x1, #0xb]
    // 0xd08d08: DecompressPointer r2
    //     0xd08d08: add             x2, x2, HEAP, lsl #32
    // 0xd08d0c: mov             x1, x2
    // 0xd08d10: r0 = dispose()
    //     0xd08d10: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xd08d14: ldur            x0, [fp, #-0x78]
    // 0xd08d18: StoreField: r0->field_43 = rNULL
    //     0xd08d18: stur            NULL, [x0, #0x43]
    // 0xd08d1c: LoadField: r2 = r0->field_33
    //     0xd08d1c: ldur            w2, [x0, #0x33]
    // 0xd08d20: DecompressPointer r2
    //     0xd08d20: add             x2, x2, HEAP, lsl #32
    // 0xd08d24: stur            x2, [fp, #-0x80]
    // 0xd08d28: cmp             w2, NULL
    // 0xd08d2c: b.ne            #0xd08d38
    // 0xd08d30: mov             x2, x0
    // 0xd08d34: b               #0xd08d78
    // 0xd08d38: LoadField: r1 = r2->field_7
    //     0xd08d38: ldur            w1, [x2, #7]
    // 0xd08d3c: DecompressPointer r1
    //     0xd08d3c: add             x1, x1, HEAP, lsl #32
    // 0xd08d40: cmp             w1, NULL
    // 0xd08d44: b.eq            #0xd08e28
    // 0xd08d48: LoadField: r3 = r1->field_7
    //     0xd08d48: ldur            x3, [x1, #7]
    // 0xd08d4c: ldr             x1, [x3]
    // 0xd08d50: cbz             x1, #0xd08e04
    // 0xd08d54: mov             x3, x1
    // 0xd08d58: stur            x3, [fp, #-0x90]
    // 0xd08d5c: r1 = <Never>
    //     0xd08d5c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xd08d60: r0 = Pointer()
    //     0xd08d60: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xd08d64: mov             x1, x0
    // 0xd08d68: ldur            x0, [fp, #-0x90]
    // 0xd08d6c: StoreField: r1->field_7 = r0
    //     0xd08d6c: stur            x0, [x1, #7]
    // 0xd08d70: r0 = _dispose$Method$FfiNative()
    //     0xd08d70: bl              #0xce93f0  ; [dart:ui] _NativeCodec::_dispose$Method$FfiNative
    // 0xd08d74: ldur            x2, [fp, #-0x78]
    // 0xd08d78: StoreField: r2->field_33 = rNULL
    //     0xd08d78: stur            NULL, [x2, #0x33]
    // 0xd08d7c: r0 = Null
    //     0xd08d7c: mov             x0, NULL
    // 0xd08d80: r0 = ReturnAsyncNotFuture()
    //     0xd08d80: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08d84: ldur            x2, [fp, #-0x78]
    // 0xd08d88: mov             x1, x2
    // 0xd08d8c: r0 = _scheduleAppFrame()
    //     0xd08d8c: bl              #0xd08e2c  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_scheduleAppFrame
    // 0xd08d90: r0 = Null
    //     0xd08d90: mov             x0, NULL
    // 0xd08d94: r0 = ReturnAsyncNotFuture()
    //     0xd08d94: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08d98: sub             SP, fp, #0xb0
    // 0xd08d9c: ldur            x2, [fp, #-0x78]
    // 0xd08da0: mov             x3, x0
    // 0xd08da4: mov             x5, x1
    // 0xd08da8: stur            x0, [fp, #-0x80]
    // 0xd08dac: stur            x1, [fp, #-0x88]
    // 0xd08db0: r1 = <List<Object>>
    //     0xd08db0: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xd08db4: r0 = ErrorDescription()
    //     0xd08db4: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xd08db8: mov             x1, x0
    // 0xd08dbc: r2 = "resolving an image frame"
    //     0xd08dbc: add             x2, PP, #0x81, lsl #12  ; [pp+0x813b0] "resolving an image frame"
    //     0xd08dc0: ldr             x2, [x2, #0x3b0]
    // 0xd08dc4: r3 = Instance_DiagnosticLevel
    //     0xd08dc4: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xd08dc8: stur            x0, [fp, #-0x98]
    // 0xd08dcc: r0 = _ErrorDiagnostic()
    //     0xd08dcc: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xd08dd0: ldur            x1, [fp, #-0x78]
    // 0xd08dd4: LoadField: r0 = r1->field_3f
    //     0xd08dd4: ldur            w0, [x1, #0x3f]
    // 0xd08dd8: DecompressPointer r0
    //     0xd08dd8: add             x0, x0, HEAP, lsl #32
    // 0xd08ddc: r16 = true
    //     0xd08ddc: add             x16, NULL, #0x20  ; true
    // 0xd08de0: stp             x16, x0, [SP]
    // 0xd08de4: ldur            x2, [fp, #-0x98]
    // 0xd08de8: ldur            x3, [fp, #-0x80]
    // 0xd08dec: ldur            x5, [fp, #-0x88]
    // 0xd08df0: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xd08df0: add             x4, PP, #0x81, lsl #12  ; [pp+0x813b8] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xd08df4: ldr             x4, [x4, #0x3b8]
    // 0xd08df8: r0 = reportError()
    //     0xd08df8: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xd08dfc: r0 = Null
    //     0xd08dfc: mov             x0, NULL
    // 0xd08e00: r0 = ReturnAsyncNotFuture()
    //     0xd08e00: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08e04: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xd08e04: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xd08e08: str             x16, [SP]
    // 0xd08e0c: r0 = _throwNew()
    //     0xd08e0c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xd08e10: brk             #0
    // 0xd08e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08e14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08e18: b               #0xd08bd4
    // 0xd08e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08e1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08e20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08e20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08e24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08e28: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd08e28: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _scheduleAppFrame(/* No info */) {
    // ** addr: 0xd08e2c, size: 0x8c
    // 0xd08e2c: EnterFrame
    //     0xd08e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd08e30: mov             fp, SP
    // 0xd08e34: AllocStack(0x8)
    //     0xd08e34: sub             SP, SP, #8
    // 0xd08e38: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r2 */)
    //     0xd08e38: mov             x2, x1
    // 0xd08e3c: CheckStackOverflow
    //     0xd08e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08e40: cmp             SP, x16
    //     0xd08e44: b.ls            #0xd08eac
    // 0xd08e48: LoadField: r0 = r2->field_5b
    //     0xd08e48: ldur            w0, [x2, #0x5b]
    // 0xd08e4c: DecompressPointer r0
    //     0xd08e4c: add             x0, x0, HEAP, lsl #32
    // 0xd08e50: tbnz            w0, #4, #0xd08e64
    // 0xd08e54: r0 = Null
    //     0xd08e54: mov             x0, NULL
    // 0xd08e58: LeaveFrame
    //     0xd08e58: mov             SP, fp
    //     0xd08e5c: ldp             fp, lr, [SP], #0x10
    // 0xd08e60: ret
    //     0xd08e60: ret             
    // 0xd08e64: r0 = true
    //     0xd08e64: add             x0, NULL, #0x20  ; true
    // 0xd08e68: StoreField: r2->field_5b = r0
    //     0xd08e68: stur            w0, [x2, #0x5b]
    // 0xd08e6c: r0 = LoadStaticField(0x5e4)
    //     0xd08e6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd08e70: ldr             x0, [x0, #0xbc8]
    // 0xd08e74: stur            x0, [fp, #-8]
    // 0xd08e78: cmp             w0, NULL
    // 0xd08e7c: b.eq            #0xd08eb4
    // 0xd08e80: r1 = Function '_handleAppFrame@800483930':.
    //     0xd08e80: add             x1, PP, #0x81, lsl #12  ; [pp+0x81448] AnonymousClosure: (0xd08eb8), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame (0xd08ef4)
    //     0xd08e84: ldr             x1, [x1, #0x448]
    // 0xd08e88: r0 = AllocateClosure()
    //     0xd08e88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd08e8c: ldur            x1, [fp, #-8]
    // 0xd08e90: mov             x2, x0
    // 0xd08e94: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd08e94: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd08e98: r0 = scheduleFrameCallback()
    //     0xd08e98: bl              #0x8669b0  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::scheduleFrameCallback
    // 0xd08e9c: r0 = Null
    //     0xd08e9c: mov             x0, NULL
    // 0xd08ea0: LeaveFrame
    //     0xd08ea0: mov             SP, fp
    //     0xd08ea4: ldp             fp, lr, [SP], #0x10
    // 0xd08ea8: ret
    //     0xd08ea8: ret             
    // 0xd08eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08eb0: b               #0xd08e48
    // 0xd08eb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08eb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleAppFrame(dynamic, Duration) {
    // ** addr: 0xd08eb8, size: 0x3c
    // 0xd08eb8: EnterFrame
    //     0xd08eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xd08ebc: mov             fp, SP
    // 0xd08ec0: ldr             x0, [fp, #0x18]
    // 0xd08ec4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd08ec4: ldur            w1, [x0, #0x17]
    // 0xd08ec8: DecompressPointer r1
    //     0xd08ec8: add             x1, x1, HEAP, lsl #32
    // 0xd08ecc: CheckStackOverflow
    //     0xd08ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08ed0: cmp             SP, x16
    //     0xd08ed4: b.ls            #0xd08eec
    // 0xd08ed8: ldr             x2, [fp, #0x10]
    // 0xd08edc: r0 = _handleAppFrame()
    //     0xd08edc: bl              #0xd08ef4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame
    // 0xd08ee0: LeaveFrame
    //     0xd08ee0: mov             SP, fp
    //     0xd08ee4: ldp             fp, lr, [SP], #0x10
    // 0xd08ee8: ret
    //     0xd08ee8: ret             
    // 0xd08eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08eec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08ef0: b               #0xd08ed8
  }
  _ _handleAppFrame(/* No info */) {
    // ** addr: 0xd08ef4, size: 0x374
    // 0xd08ef4: EnterFrame
    //     0xd08ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xd08ef8: mov             fp, SP
    // 0xd08efc: AllocStack(0x48)
    //     0xd08efc: sub             SP, SP, #0x48
    // 0xd08f00: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd08f00: stur            x1, [fp, #-8]
    //     0xd08f04: stur            x2, [fp, #-0x10]
    // 0xd08f08: CheckStackOverflow
    //     0xd08f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08f0c: cmp             SP, x16
    //     0xd08f10: b.ls            #0xd09220
    // 0xd08f14: r1 = 1
    //     0xd08f14: mov             x1, #1
    // 0xd08f18: r0 = AllocateContext()
    //     0xd08f18: bl              #0x13de838  ; AllocateContextStub
    // 0xd08f1c: mov             x3, x0
    // 0xd08f20: ldur            x0, [fp, #-8]
    // 0xd08f24: stur            x3, [fp, #-0x18]
    // 0xd08f28: StoreField: r3->field_f = r0
    //     0xd08f28: stur            w0, [x3, #0xf]
    // 0xd08f2c: r1 = false
    //     0xd08f2c: add             x1, NULL, #0x30  ; false
    // 0xd08f30: StoreField: r0->field_5b = r1
    //     0xd08f30: stur            w1, [x0, #0x5b]
    // 0xd08f34: LoadField: r1 = r0->field_7
    //     0xd08f34: ldur            w1, [x0, #7]
    // 0xd08f38: DecompressPointer r1
    //     0xd08f38: add             x1, x1, HEAP, lsl #32
    // 0xd08f3c: LoadField: r2 = r1->field_b
    //     0xd08f3c: ldur            w2, [x1, #0xb]
    // 0xd08f40: cbnz            w2, #0xd08f54
    // 0xd08f44: r0 = Null
    //     0xd08f44: mov             x0, NULL
    // 0xd08f48: LeaveFrame
    //     0xd08f48: mov             SP, fp
    //     0xd08f4c: ldp             fp, lr, [SP], #0x10
    // 0xd08f50: ret
    //     0xd08f50: ret             
    // 0xd08f54: LoadField: r1 = r0->field_4b
    //     0xd08f54: ldur            w1, [x0, #0x4b]
    // 0xd08f58: DecompressPointer r1
    //     0xd08f58: add             x1, x1, HEAP, lsl #32
    // 0xd08f5c: cmp             w1, NULL
    // 0xd08f60: b.eq            #0xd08f78
    // 0xd08f64: mov             x1, x0
    // 0xd08f68: ldur            x2, [fp, #-0x10]
    // 0xd08f6c: r0 = _hasFrameDurationPassed()
    //     0xd08f6c: bl              #0xd09268  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_hasFrameDurationPassed
    // 0xd08f70: tbnz            w0, #4, #0xd09160
    // 0xd08f74: ldur            x0, [fp, #-8]
    // 0xd08f78: LoadField: r1 = r0->field_43
    //     0xd08f78: ldur            w1, [x0, #0x43]
    // 0xd08f7c: DecompressPointer r1
    //     0xd08f7c: add             x1, x1, HEAP, lsl #32
    // 0xd08f80: cmp             w1, NULL
    // 0xd08f84: b.eq            #0xd09228
    // 0xd08f88: LoadField: r2 = r1->field_b
    //     0xd08f88: ldur            w2, [x1, #0xb]
    // 0xd08f8c: DecompressPointer r2
    //     0xd08f8c: add             x2, x2, HEAP, lsl #32
    // 0xd08f90: mov             x1, x2
    // 0xd08f94: r0 = clone()
    //     0xd08f94: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0xd08f98: ldur            x1, [fp, #-8]
    // 0xd08f9c: stur            x0, [fp, #-0x28]
    // 0xd08fa0: LoadField: d0 = r1->field_37
    //     0xd08fa0: ldur            d0, [x1, #0x37]
    // 0xd08fa4: stur            d0, [fp, #-0x40]
    // 0xd08fa8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd08fa8: ldur            w2, [x1, #0x17]
    // 0xd08fac: DecompressPointer r2
    //     0xd08fac: add             x2, x2, HEAP, lsl #32
    // 0xd08fb0: stur            x2, [fp, #-0x20]
    // 0xd08fb4: r0 = ImageInfo()
    //     0xd08fb4: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd08fb8: mov             x1, x0
    // 0xd08fbc: ldur            x0, [fp, #-0x28]
    // 0xd08fc0: StoreField: r1->field_7 = r0
    //     0xd08fc0: stur            w0, [x1, #7]
    // 0xd08fc4: ldur            d0, [fp, #-0x40]
    // 0xd08fc8: StoreField: r1->field_b = d0
    //     0xd08fc8: stur            d0, [x1, #0xb]
    // 0xd08fcc: ldur            x0, [fp, #-0x20]
    // 0xd08fd0: StoreField: r1->field_13 = r0
    //     0xd08fd0: stur            w0, [x1, #0x13]
    // 0xd08fd4: mov             x2, x1
    // 0xd08fd8: ldur            x1, [fp, #-8]
    // 0xd08fdc: r0 = _emitFrame()
    //     0xd08fdc: bl              #0xd08718  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xd08fe0: ldur            x0, [fp, #-0x10]
    // 0xd08fe4: ldur            x2, [fp, #-8]
    // 0xd08fe8: StoreField: r2->field_47 = r0
    //     0xd08fe8: stur            w0, [x2, #0x47]
    //     0xd08fec: ldurb           w16, [x2, #-1]
    //     0xd08ff0: ldurb           w17, [x0, #-1]
    //     0xd08ff4: and             x16, x17, x16, lsr #2
    //     0xd08ff8: tst             x16, HEAP, lsr #32
    //     0xd08ffc: b.eq            #0xd09004
    //     0xd09000: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd09004: LoadField: r1 = r2->field_43
    //     0xd09004: ldur            w1, [x2, #0x43]
    // 0xd09008: DecompressPointer r1
    //     0xd09008: add             x1, x1, HEAP, lsl #32
    // 0xd0900c: cmp             w1, NULL
    // 0xd09010: b.eq            #0xd0922c
    // 0xd09014: LoadField: r0 = r1->field_7
    //     0xd09014: ldur            w0, [x1, #7]
    // 0xd09018: DecompressPointer r0
    //     0xd09018: add             x0, x0, HEAP, lsl #32
    // 0xd0901c: StoreField: r2->field_4b = r0
    //     0xd0901c: stur            w0, [x2, #0x4b]
    //     0xd09020: ldurb           w16, [x2, #-1]
    //     0xd09024: ldurb           w17, [x0, #-1]
    //     0xd09028: and             x16, x17, x16, lsr #2
    //     0xd0902c: tst             x16, HEAP, lsr #32
    //     0xd09030: b.eq            #0xd09038
    //     0xd09034: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd09038: LoadField: r0 = r1->field_b
    //     0xd09038: ldur            w0, [x1, #0xb]
    // 0xd0903c: DecompressPointer r0
    //     0xd0903c: add             x0, x0, HEAP, lsl #32
    // 0xd09040: mov             x1, x0
    // 0xd09044: r0 = dispose()
    //     0xd09044: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xd09048: ldur            x0, [fp, #-8]
    // 0xd0904c: StoreField: r0->field_43 = rNULL
    //     0xd0904c: stur            NULL, [x0, #0x43]
    // 0xd09050: LoadField: r1 = r0->field_33
    //     0xd09050: ldur            w1, [x0, #0x33]
    // 0xd09054: DecompressPointer r1
    //     0xd09054: add             x1, x1, HEAP, lsl #32
    // 0xd09058: cmp             w1, NULL
    // 0xd0905c: b.ne            #0xd09070
    // 0xd09060: r0 = Null
    //     0xd09060: mov             x0, NULL
    // 0xd09064: LeaveFrame
    //     0xd09064: mov             SP, fp
    //     0xd09068: ldp             fp, lr, [SP], #0x10
    // 0xd0906c: ret
    //     0xd0906c: ret             
    // 0xd09070: LoadField: r2 = r0->field_4f
    //     0xd09070: ldur            x2, [x0, #0x4f]
    // 0xd09074: stur            x2, [fp, #-0x30]
    // 0xd09078: r0 = frameCount()
    //     0xd09078: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd0907c: mov             x1, x0
    // 0xd09080: ldur            x0, [fp, #-0x30]
    // 0xd09084: cbz             x1, #0xd09230
    // 0xd09088: sdiv            x2, x0, x1
    // 0xd0908c: ldur            x0, [fp, #-8]
    // 0xd09090: stur            x2, [fp, #-0x38]
    // 0xd09094: LoadField: r1 = r0->field_33
    //     0xd09094: ldur            w1, [x0, #0x33]
    // 0xd09098: DecompressPointer r1
    //     0xd09098: add             x1, x1, HEAP, lsl #32
    // 0xd0909c: cmp             w1, NULL
    // 0xd090a0: b.eq            #0xd09248
    // 0xd090a4: r0 = repetitionCount()
    //     0xd090a4: bl              #0xd08480  ; [dart:ui] _NativeCodec::repetitionCount
    // 0xd090a8: cmn             x0, #1
    // 0xd090ac: b.eq            #0xd090dc
    // 0xd090b0: ldur            x2, [fp, #-8]
    // 0xd090b4: ldur            x0, [fp, #-0x38]
    // 0xd090b8: LoadField: r1 = r2->field_33
    //     0xd090b8: ldur            w1, [x2, #0x33]
    // 0xd090bc: DecompressPointer r1
    //     0xd090bc: add             x1, x1, HEAP, lsl #32
    // 0xd090c0: cmp             w1, NULL
    // 0xd090c4: b.eq            #0xd0924c
    // 0xd090c8: r0 = repetitionCount()
    //     0xd090c8: bl              #0xd08480  ; [dart:ui] _NativeCodec::repetitionCount
    // 0xd090cc: mov             x1, x0
    // 0xd090d0: ldur            x0, [fp, #-0x38]
    // 0xd090d4: cmp             x0, x1
    // 0xd090d8: b.gt            #0xd090f4
    // 0xd090dc: ldur            x1, [fp, #-8]
    // 0xd090e0: r0 = _decodeNextFrameAndSchedule()
    //     0xd090e0: bl              #0xd08bb4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xd090e4: r0 = Null
    //     0xd090e4: mov             x0, NULL
    // 0xd090e8: LeaveFrame
    //     0xd090e8: mov             SP, fp
    //     0xd090ec: ldp             fp, lr, [SP], #0x10
    // 0xd090f0: ret
    //     0xd090f0: ret             
    // 0xd090f4: ldur            x0, [fp, #-8]
    // 0xd090f8: LoadField: r2 = r0->field_33
    //     0xd090f8: ldur            w2, [x0, #0x33]
    // 0xd090fc: DecompressPointer r2
    //     0xd090fc: add             x2, x2, HEAP, lsl #32
    // 0xd09100: stur            x2, [fp, #-0x20]
    // 0xd09104: cmp             w2, NULL
    // 0xd09108: b.eq            #0xd09250
    // 0xd0910c: LoadField: r1 = r2->field_7
    //     0xd0910c: ldur            w1, [x2, #7]
    // 0xd09110: DecompressPointer r1
    //     0xd09110: add             x1, x1, HEAP, lsl #32
    // 0xd09114: cmp             w1, NULL
    // 0xd09118: b.eq            #0xd09254
    // 0xd0911c: LoadField: r3 = r1->field_7
    //     0xd0911c: ldur            x3, [x1, #7]
    // 0xd09120: ldr             x1, [x3]
    // 0xd09124: cbz             x1, #0xd09210
    // 0xd09128: mov             x3, x1
    // 0xd0912c: stur            x3, [fp, #-0x30]
    // 0xd09130: r1 = <Never>
    //     0xd09130: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xd09134: r0 = Pointer()
    //     0xd09134: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xd09138: mov             x1, x0
    // 0xd0913c: ldur            x0, [fp, #-0x30]
    // 0xd09140: StoreField: r1->field_7 = r0
    //     0xd09140: stur            x0, [x1, #7]
    // 0xd09144: r0 = _dispose$Method$FfiNative()
    //     0xd09144: bl              #0xce93f0  ; [dart:ui] _NativeCodec::_dispose$Method$FfiNative
    // 0xd09148: ldur            x0, [fp, #-8]
    // 0xd0914c: StoreField: r0->field_33 = rNULL
    //     0xd0914c: stur            NULL, [x0, #0x33]
    // 0xd09150: r0 = Null
    //     0xd09150: mov             x0, NULL
    // 0xd09154: LeaveFrame
    //     0xd09154: mov             SP, fp
    //     0xd09158: ldp             fp, lr, [SP], #0x10
    // 0xd0915c: ret
    //     0xd0915c: ret             
    // 0xd09160: ldur            x0, [fp, #-8]
    // 0xd09164: ldur            x1, [fp, #-0x10]
    // 0xd09168: LoadField: r2 = r0->field_4b
    //     0xd09168: ldur            w2, [x0, #0x4b]
    // 0xd0916c: DecompressPointer r2
    //     0xd0916c: add             x2, x2, HEAP, lsl #32
    // 0xd09170: cmp             w2, NULL
    // 0xd09174: b.eq            #0xd09258
    // 0xd09178: LoadField: r3 = r0->field_47
    //     0xd09178: ldur            w3, [x0, #0x47]
    // 0xd0917c: DecompressPointer r3
    //     0xd0917c: add             x3, x3, HEAP, lsl #32
    // 0xd09180: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd09184: cmp             w3, w16
    // 0xd09188: b.eq            #0xd0925c
    // 0xd0918c: LoadField: r4 = r1->field_7
    //     0xd0918c: ldur            x4, [x1, #7]
    // 0xd09190: LoadField: r1 = r3->field_7
    //     0xd09190: ldur            x1, [x3, #7]
    // 0xd09194: sub             x3, x4, x1
    // 0xd09198: LoadField: r1 = r2->field_7
    //     0xd09198: ldur            x1, [x2, #7]
    // 0xd0919c: sub             x2, x1, x3
    // 0xd091a0: stur            x2, [fp, #-0x30]
    // 0xd091a4: r0 = Duration()
    //     0xd091a4: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xd091a8: mov             x1, x0
    // 0xd091ac: ldur            x0, [fp, #-0x30]
    // 0xd091b0: StoreField: r1->field_7 = r0
    //     0xd091b0: stur            x0, [x1, #7]
    // 0xd091b4: r2 = 1.000000
    //     0xd091b4: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd091b8: r0 = *()
    //     0xd091b8: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0xd091bc: ldur            x2, [fp, #-0x18]
    // 0xd091c0: r1 = Function '<anonymous closure>':.
    //     0xd091c0: add             x1, PP, #0x81, lsl #12  ; [pp+0x81450] AnonymousClosure: (0xd092d0), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame (0xd08ef4)
    //     0xd091c4: ldr             x1, [x1, #0x450]
    // 0xd091c8: stur            x0, [fp, #-0x10]
    // 0xd091cc: r0 = AllocateClosure()
    //     0xd091cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd091d0: ldur            x2, [fp, #-0x10]
    // 0xd091d4: mov             x3, x0
    // 0xd091d8: r1 = Null
    //     0xd091d8: mov             x1, NULL
    // 0xd091dc: r0 = Timer()
    //     0xd091dc: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xd091e0: ldur            x1, [fp, #-8]
    // 0xd091e4: StoreField: r1->field_57 = r0
    //     0xd091e4: stur            w0, [x1, #0x57]
    //     0xd091e8: ldurb           w16, [x1, #-1]
    //     0xd091ec: ldurb           w17, [x0, #-1]
    //     0xd091f0: and             x16, x17, x16, lsr #2
    //     0xd091f4: tst             x16, HEAP, lsr #32
    //     0xd091f8: b.eq            #0xd09200
    //     0xd091fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd09200: r0 = Null
    //     0xd09200: mov             x0, NULL
    // 0xd09204: LeaveFrame
    //     0xd09204: mov             SP, fp
    //     0xd09208: ldp             fp, lr, [SP], #0x10
    // 0xd0920c: ret
    //     0xd0920c: ret             
    // 0xd09210: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xd09210: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xd09214: str             x16, [SP]
    // 0xd09218: r0 = _throwNew()
    //     0xd09218: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xd0921c: brk             #0
    // 0xd09220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd09220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd09224: b               #0xd08f14
    // 0xd09228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09228: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0922c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0922c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd09230: stp             x0, x1, [SP, #-0x10]!
    // 0xd09234: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xd09238: r4 = 0
    //     0xd09238: mov             x4, #0
    // 0xd0923c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xd09240: blr             lr
    // 0xd09244: brk             #0
    // 0xd09248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09248: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0924c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0924c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd09250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09250: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd09254: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd09254: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd09258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd09258: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0925c: r9 = _shownTimestamp
    //     0xd0925c: add             x9, PP, #0x81, lsl #12  ; [pp+0x81458] Field <MultiFrameImageStreamCompleter._shownTimestamp@800483930>: late (offset: 0x48)
    //     0xd09260: ldr             x9, [x9, #0x458]
    // 0xd09264: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd09264: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _hasFrameDurationPassed(/* No info */) {
    // ** addr: 0xd09268, size: 0x68
    // 0xd09268: EnterFrame
    //     0xd09268: stp             fp, lr, [SP, #-0x10]!
    //     0xd0926c: mov             fp, SP
    // 0xd09270: LoadField: r3 = r1->field_47
    //     0xd09270: ldur            w3, [x1, #0x47]
    // 0xd09274: DecompressPointer r3
    //     0xd09274: add             x3, x3, HEAP, lsl #32
    // 0xd09278: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0927c: cmp             w3, w16
    // 0xd09280: b.eq            #0xd092c0
    // 0xd09284: LoadField: r4 = r2->field_7
    //     0xd09284: ldur            x4, [x2, #7]
    // 0xd09288: LoadField: r2 = r3->field_7
    //     0xd09288: ldur            x2, [x3, #7]
    // 0xd0928c: sub             x3, x4, x2
    // 0xd09290: LoadField: r2 = r1->field_4b
    //     0xd09290: ldur            w2, [x1, #0x4b]
    // 0xd09294: DecompressPointer r2
    //     0xd09294: add             x2, x2, HEAP, lsl #32
    // 0xd09298: cmp             w2, NULL
    // 0xd0929c: b.eq            #0xd092cc
    // 0xd092a0: LoadField: r1 = r2->field_7
    //     0xd092a0: ldur            x1, [x2, #7]
    // 0xd092a4: cmp             x3, x1
    // 0xd092a8: r16 = true
    //     0xd092a8: add             x16, NULL, #0x20  ; true
    // 0xd092ac: r17 = false
    //     0xd092ac: add             x17, NULL, #0x30  ; false
    // 0xd092b0: csel            x0, x16, x17, ge
    // 0xd092b4: LeaveFrame
    //     0xd092b4: mov             SP, fp
    //     0xd092b8: ldp             fp, lr, [SP], #0x10
    // 0xd092bc: ret
    //     0xd092bc: ret             
    // 0xd092c0: r9 = _shownTimestamp
    //     0xd092c0: add             x9, PP, #0x81, lsl #12  ; [pp+0x81458] Field <MultiFrameImageStreamCompleter._shownTimestamp@800483930>: late (offset: 0x48)
    //     0xd092c4: ldr             x9, [x9, #0x458]
    // 0xd092c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd092c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd092cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd092cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd092d0, size: 0x48
    // 0xd092d0: EnterFrame
    //     0xd092d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd092d4: mov             fp, SP
    // 0xd092d8: ldr             x0, [fp, #0x10]
    // 0xd092dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd092dc: ldur            w1, [x0, #0x17]
    // 0xd092e0: DecompressPointer r1
    //     0xd092e0: add             x1, x1, HEAP, lsl #32
    // 0xd092e4: CheckStackOverflow
    //     0xd092e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd092e8: cmp             SP, x16
    //     0xd092ec: b.ls            #0xd09310
    // 0xd092f0: LoadField: r0 = r1->field_f
    //     0xd092f0: ldur            w0, [x1, #0xf]
    // 0xd092f4: DecompressPointer r0
    //     0xd092f4: add             x0, x0, HEAP, lsl #32
    // 0xd092f8: mov             x1, x0
    // 0xd092fc: r0 = _scheduleAppFrame()
    //     0xd092fc: bl              #0xd08e2c  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_scheduleAppFrame
    // 0xd09300: r0 = Null
    //     0xd09300: mov             x0, NULL
    // 0xd09304: LeaveFrame
    //     0xd09304: mov             SP, fp
    //     0xd09308: ldp             fp, lr, [SP], #0x10
    // 0xd0930c: ret
    //     0xd0930c: ret             
    // 0xd09310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd09310: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd09314: b               #0xd092f0
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x1186450, size: 0x98
    // 0x1186450: EnterFrame
    //     0x1186450: stp             fp, lr, [SP, #-0x10]!
    //     0x1186454: mov             fp, SP
    // 0x1186458: AllocStack(0x20)
    //     0x1186458: sub             SP, SP, #0x20
    // 0x118645c: SetupParameters([dynamic _ /* r0 */])
    //     0x118645c: ldr             x0, [fp, #0x20]
    //     0x1186460: ldur            w2, [x0, #0x17]
    //     0x1186464: add             x2, x2, HEAP, lsl #32
    //     0x1186468: stur            x2, [fp, #-8]
    // 0x118646c: CheckStackOverflow
    //     0x118646c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186470: cmp             SP, x16
    //     0x1186474: b.ls            #0x11864e0
    // 0x1186478: r1 = <List<Object>>
    //     0x1186478: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x118647c: r0 = ErrorDescription()
    //     0x118647c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1186480: mov             x1, x0
    // 0x1186484: r2 = "loading an image"
    //     0x1186484: add             x2, PP, #0x94, lsl #12  ; [pp+0x94d20] "loading an image"
    //     0x1186488: ldr             x2, [x2, #0xd20]
    // 0x118648c: r3 = Instance_DiagnosticLevel
    //     0x118648c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1186490: stur            x0, [fp, #-0x10]
    // 0x1186494: r0 = _ErrorDiagnostic()
    //     0x1186494: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1186498: ldur            x0, [fp, #-8]
    // 0x118649c: LoadField: r1 = r0->field_13
    //     0x118649c: ldur            w1, [x0, #0x13]
    // 0x11864a0: DecompressPointer r1
    //     0x11864a0: add             x1, x1, HEAP, lsl #32
    // 0x11864a4: LoadField: r2 = r0->field_f
    //     0x11864a4: ldur            w2, [x0, #0xf]
    // 0x11864a8: DecompressPointer r2
    //     0x11864a8: add             x2, x2, HEAP, lsl #32
    // 0x11864ac: r16 = true
    //     0x11864ac: add             x16, NULL, #0x20  ; true
    // 0x11864b0: stp             x16, x1, [SP]
    // 0x11864b4: mov             x1, x2
    // 0x11864b8: ldur            x2, [fp, #-0x10]
    // 0x11864bc: ldr             x3, [fp, #0x18]
    // 0x11864c0: ldr             x5, [fp, #0x10]
    // 0x11864c4: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0x11864c4: add             x4, PP, #0x81, lsl #12  ; [pp+0x813b8] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0x11864c8: ldr             x4, [x4, #0x3b8]
    // 0x11864cc: r0 = reportError()
    //     0x11864cc: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0x11864d0: r0 = Null
    //     0x11864d0: mov             x0, NULL
    // 0x11864d4: LeaveFrame
    //     0x11864d4: mov             SP, fp
    //     0x11864d8: ldp             fp, lr, [SP], #0x10
    // 0x11864dc: ret
    //     0x11864dc: ret             
    // 0x11864e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11864e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11864e4: b               #0x1186478
  }
  _ MultiFrameImageStreamCompleter(/* No info */) {
    // ** addr: 0x11864e8, size: 0x208
    // 0x11864e8: EnterFrame
    //     0x11864e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11864ec: mov             fp, SP
    // 0x11864f0: AllocStack(0x58)
    //     0x11864f0: sub             SP, SP, #0x58
    // 0x11864f4: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r0, fp-0x28 */, dynamic _ /* d0 => d0, fp-0x38 */, {dynamic chunkEvents = Null /* r6, fp-0x10 */, dynamic informationCollector = Null /* r3, fp-0x8 */})
    //     0x11864f4: mov             x0, x3
    //     0x11864f8: stur            x1, [fp, #-0x18]
    //     0x11864fc: stur            x2, [fp, #-0x20]
    //     0x1186500: stur            x3, [fp, #-0x28]
    //     0x1186504: stur            d0, [fp, #-0x38]
    //     0x1186508: ldur            w3, [x4, #0x13]
    //     0x118650c: ldur            w5, [x4, #0x1f]
    //     0x1186510: add             x5, x5, HEAP, lsl #32
    //     0x1186514: add             x16, PP, #0x94, lsl #12  ; [pp+0x94cf8] "chunkEvents"
    //     0x1186518: ldr             x16, [x16, #0xcf8]
    //     0x118651c: cmp             w5, w16
    //     0x1186520: b.ne            #0x1186544
    //     0x1186524: ldur            w5, [x4, #0x23]
    //     0x1186528: add             x5, x5, HEAP, lsl #32
    //     0x118652c: sub             w6, w3, w5
    //     0x1186530: add             x5, fp, w6, sxtw #2
    //     0x1186534: ldr             x5, [x5, #8]
    //     0x1186538: mov             x6, x5
    //     0x118653c: mov             x5, #1
    //     0x1186540: b               #0x118654c
    //     0x1186544: mov             x6, NULL
    //     0x1186548: mov             x5, #0
    //     0x118654c: stur            x6, [fp, #-0x10]
    //     0x1186550: lsl             x7, x5, #1
    //     0x1186554: lsl             w5, w7, #1
    //     0x1186558: add             w7, w5, #8
    //     0x118655c: add             x16, x4, w7, sxtw #1
    //     0x1186560: ldur            w8, [x16, #0xf]
    //     0x1186564: add             x8, x8, HEAP, lsl #32
    //     0x1186568: ldr             x16, [PP, #0x22d8]  ; [pp+0x22d8] "informationCollector"
    //     0x118656c: cmp             w8, w16
    //     0x1186570: b.ne            #0x1186594
    //     0x1186574: add             w7, w5, #0xa
    //     0x1186578: add             x16, x4, w7, sxtw #1
    //     0x118657c: ldur            w5, [x16, #0xf]
    //     0x1186580: add             x5, x5, HEAP, lsl #32
    //     0x1186584: sub             w4, w3, w5
    //     0x1186588: add             x3, fp, w4, sxtw #2
    //     0x118658c: ldr             x3, [x3, #8]
    //     0x1186590: b               #0x1186598
    //     0x1186594: mov             x3, NULL
    //     0x1186598: stur            x3, [fp, #-8]
    // 0x118659c: CheckStackOverflow
    //     0x118659c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11865a0: cmp             SP, x16
    //     0x11865a4: b.ls            #0x11866e8
    // 0x11865a8: r1 = 2
    //     0x11865a8: mov             x1, #2
    // 0x11865ac: r0 = AllocateContext()
    //     0x11865ac: bl              #0x13de838  ; AllocateContextStub
    // 0x11865b0: mov             x3, x0
    // 0x11865b4: ldur            x2, [fp, #-0x18]
    // 0x11865b8: stur            x3, [fp, #-0x30]
    // 0x11865bc: StoreField: r3->field_f = r2
    //     0x11865bc: stur            w2, [x3, #0xf]
    // 0x11865c0: ldur            x0, [fp, #-8]
    // 0x11865c4: StoreField: r3->field_13 = r0
    //     0x11865c4: stur            w0, [x3, #0x13]
    // 0x11865c8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x11865cc: StoreField: r2->field_47 = r1
    //     0x11865cc: stur            w1, [x2, #0x47]
    // 0x11865d0: StoreField: r2->field_4f = rZR
    //     0x11865d0: stur            xzr, [x2, #0x4f]
    // 0x11865d4: r1 = false
    //     0x11865d4: add             x1, NULL, #0x30  ; false
    // 0x11865d8: StoreField: r2->field_5b = r1
    //     0x11865d8: stur            w1, [x2, #0x5b]
    // 0x11865dc: StoreField: r2->field_3f = r0
    //     0x11865dc: stur            w0, [x2, #0x3f]
    //     0x11865e0: ldurb           w16, [x2, #-1]
    //     0x11865e4: ldurb           w17, [x0, #-1]
    //     0x11865e8: and             x16, x17, x16, lsr #2
    //     0x11865ec: tst             x16, HEAP, lsr #32
    //     0x11865f0: b.eq            #0x11865f8
    //     0x11865f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11865f8: ldur            d0, [fp, #-0x38]
    // 0x11865fc: StoreField: r2->field_37 = d0
    //     0x11865fc: stur            d0, [x2, #0x37]
    // 0x1186600: mov             x1, x2
    // 0x1186604: r0 = ImageStreamCompleter()
    //     0x1186604: bl              #0x91aa54  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0x1186608: ldur            x0, [fp, #-0x28]
    // 0x118660c: ldur            x3, [fp, #-0x18]
    // 0x1186610: ArrayStore: r3[0] = r0  ; List_4
    //     0x1186610: stur            w0, [x3, #0x17]
    //     0x1186614: ldurb           w16, [x3, #-1]
    //     0x1186618: ldurb           w17, [x0, #-1]
    //     0x118661c: and             x16, x17, x16, lsr #2
    //     0x1186620: tst             x16, HEAP, lsr #32
    //     0x1186624: b.eq            #0x118662c
    //     0x1186628: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x118662c: mov             x2, x3
    // 0x1186630: r1 = Function '_handleCodecReady@800483930':.
    //     0x1186630: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d00] AnonymousClosure: (0x1186788), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleCodecReady (0x11867c4)
    //     0x1186634: ldr             x1, [x1, #0xd00]
    // 0x1186638: r0 = AllocateClosure()
    //     0x1186638: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x118663c: ldur            x2, [fp, #-0x30]
    // 0x1186640: r1 = Function '<anonymous closure>':.
    //     0x1186640: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d08] AnonymousClosure: (0x11866f0), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0x11864e8)
    //     0x1186644: ldr             x1, [x1, #0xd08]
    // 0x1186648: stur            x0, [fp, #-8]
    // 0x118664c: r0 = AllocateClosure()
    //     0x118664c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186650: r16 = <void?>
    //     0x1186650: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x1186654: ldur            lr, [fp, #-0x20]
    // 0x1186658: stp             lr, x16, [SP, #0x10]
    // 0x118665c: ldur            x16, [fp, #-8]
    // 0x1186660: stp             x0, x16, [SP]
    // 0x1186664: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x1186664: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x1186668: r0 = then()
    //     0x1186668: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x118666c: ldur            x0, [fp, #-0x10]
    // 0x1186670: cmp             w0, NULL
    // 0x1186674: b.eq            #0x11866d8
    // 0x1186678: ldur            x3, [fp, #-0x18]
    // 0x118667c: mov             x2, x3
    // 0x1186680: r1 = Function 'reportImageChunkEvent':.
    //     0x1186680: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d10] AnonymousClosure: (0x11868a4), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportImageChunkEvent (0x11868e0)
    //     0x1186684: ldr             x1, [x1, #0xd10]
    // 0x1186688: r0 = AllocateClosure()
    //     0x1186688: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x118668c: ldur            x2, [fp, #-0x30]
    // 0x1186690: r1 = Function '<anonymous closure>':.
    //     0x1186690: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d18] AnonymousClosure: (0x1186450), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0x11864e8)
    //     0x1186694: ldr             x1, [x1, #0xd18]
    // 0x1186698: stur            x0, [fp, #-8]
    // 0x118669c: r0 = AllocateClosure()
    //     0x118669c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11866a0: str             x0, [SP]
    // 0x11866a4: ldur            x1, [fp, #-0x10]
    // 0x11866a8: ldur            x2, [fp, #-8]
    // 0x11866ac: r4 = const [0, 0x3, 0x1, 0x2, onError, 0x2, null]
    //     0x11866ac: add             x4, PP, #0x83, lsl #12  ; [pp+0x83680] List(7) [0, 0x3, 0x1, 0x2, "onError", 0x2, Null]
    //     0x11866b0: ldr             x4, [x4, #0x680]
    // 0x11866b4: r0 = listen()
    //     0x11866b4: bl              #0x123a37c  ; [dart:async] _StreamImpl::listen
    // 0x11866b8: ldur            x1, [fp, #-0x18]
    // 0x11866bc: StoreField: r1->field_2f = r0
    //     0x11866bc: stur            w0, [x1, #0x2f]
    //     0x11866c0: ldurb           w16, [x1, #-1]
    //     0x11866c4: ldurb           w17, [x0, #-1]
    //     0x11866c8: and             x16, x17, x16, lsr #2
    //     0x11866cc: tst             x16, HEAP, lsr #32
    //     0x11866d0: b.eq            #0x11866d8
    //     0x11866d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11866d8: r0 = Null
    //     0x11866d8: mov             x0, NULL
    // 0x11866dc: LeaveFrame
    //     0x11866dc: mov             SP, fp
    //     0x11866e0: ldp             fp, lr, [SP], #0x10
    // 0x11866e4: ret
    //     0x11866e4: ret             
    // 0x11866e8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11866e8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11866ec: b               #0x11865a8
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x11866f0, size: 0x98
    // 0x11866f0: EnterFrame
    //     0x11866f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11866f4: mov             fp, SP
    // 0x11866f8: AllocStack(0x20)
    //     0x11866f8: sub             SP, SP, #0x20
    // 0x11866fc: SetupParameters([dynamic _ /* r0 */])
    //     0x11866fc: ldr             x0, [fp, #0x20]
    //     0x1186700: ldur            w2, [x0, #0x17]
    //     0x1186704: add             x2, x2, HEAP, lsl #32
    //     0x1186708: stur            x2, [fp, #-8]
    // 0x118670c: CheckStackOverflow
    //     0x118670c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186710: cmp             SP, x16
    //     0x1186714: b.ls            #0x1186780
    // 0x1186718: r1 = <List<Object>>
    //     0x1186718: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x118671c: r0 = ErrorDescription()
    //     0x118671c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1186720: mov             x1, x0
    // 0x1186724: r2 = "resolving an image codec"
    //     0x1186724: add             x2, PP, #0x94, lsl #12  ; [pp+0x94d50] "resolving an image codec"
    //     0x1186728: ldr             x2, [x2, #0xd50]
    // 0x118672c: r3 = Instance_DiagnosticLevel
    //     0x118672c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1186730: stur            x0, [fp, #-0x10]
    // 0x1186734: r0 = _ErrorDiagnostic()
    //     0x1186734: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1186738: ldur            x0, [fp, #-8]
    // 0x118673c: LoadField: r1 = r0->field_13
    //     0x118673c: ldur            w1, [x0, #0x13]
    // 0x1186740: DecompressPointer r1
    //     0x1186740: add             x1, x1, HEAP, lsl #32
    // 0x1186744: LoadField: r2 = r0->field_f
    //     0x1186744: ldur            w2, [x0, #0xf]
    // 0x1186748: DecompressPointer r2
    //     0x1186748: add             x2, x2, HEAP, lsl #32
    // 0x118674c: r16 = true
    //     0x118674c: add             x16, NULL, #0x20  ; true
    // 0x1186750: stp             x16, x1, [SP]
    // 0x1186754: mov             x1, x2
    // 0x1186758: ldur            x2, [fp, #-0x10]
    // 0x118675c: ldr             x3, [fp, #0x18]
    // 0x1186760: ldr             x5, [fp, #0x10]
    // 0x1186764: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0x1186764: add             x4, PP, #0x81, lsl #12  ; [pp+0x813b8] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0x1186768: ldr             x4, [x4, #0x3b8]
    // 0x118676c: r0 = reportError()
    //     0x118676c: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0x1186770: r0 = Null
    //     0x1186770: mov             x0, NULL
    // 0x1186774: LeaveFrame
    //     0x1186774: mov             SP, fp
    //     0x1186778: ldp             fp, lr, [SP], #0x10
    // 0x118677c: ret
    //     0x118677c: ret             
    // 0x1186780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186784: b               #0x1186718
  }
  [closure] void _handleCodecReady(dynamic, Codec) {
    // ** addr: 0x1186788, size: 0x3c
    // 0x1186788: EnterFrame
    //     0x1186788: stp             fp, lr, [SP, #-0x10]!
    //     0x118678c: mov             fp, SP
    // 0x1186790: ldr             x0, [fp, #0x18]
    // 0x1186794: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1186794: ldur            w1, [x0, #0x17]
    // 0x1186798: DecompressPointer r1
    //     0x1186798: add             x1, x1, HEAP, lsl #32
    // 0x118679c: CheckStackOverflow
    //     0x118679c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11867a0: cmp             SP, x16
    //     0x11867a4: b.ls            #0x11867bc
    // 0x11867a8: ldr             x2, [fp, #0x10]
    // 0x11867ac: r0 = _handleCodecReady()
    //     0x11867ac: bl              #0x11867c4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleCodecReady
    // 0x11867b0: LeaveFrame
    //     0x11867b0: mov             SP, fp
    //     0x11867b4: ldp             fp, lr, [SP], #0x10
    // 0x11867b8: ret
    //     0x11867b8: ret             
    // 0x11867bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11867bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11867c0: b               #0x11867a8
  }
  _ _handleCodecReady(/* No info */) {
    // ** addr: 0x11867c4, size: 0x60
    // 0x11867c4: EnterFrame
    //     0x11867c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11867c8: mov             fp, SP
    // 0x11867cc: mov             x0, x2
    // 0x11867d0: CheckStackOverflow
    //     0x11867d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11867d4: cmp             SP, x16
    //     0x11867d8: b.ls            #0x118681c
    // 0x11867dc: StoreField: r1->field_33 = r0
    //     0x11867dc: stur            w0, [x1, #0x33]
    //     0x11867e0: ldurb           w16, [x1, #-1]
    //     0x11867e4: ldurb           w17, [x0, #-1]
    //     0x11867e8: and             x16, x17, x16, lsr #2
    //     0x11867ec: tst             x16, HEAP, lsr #32
    //     0x11867f0: b.eq            #0x11867f8
    //     0x11867f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11867f8: LoadField: r0 = r1->field_7
    //     0x11867f8: ldur            w0, [x1, #7]
    // 0x11867fc: DecompressPointer r0
    //     0x11867fc: add             x0, x0, HEAP, lsl #32
    // 0x1186800: LoadField: r2 = r0->field_b
    //     0x1186800: ldur            w2, [x0, #0xb]
    // 0x1186804: cbz             w2, #0x118680c
    // 0x1186808: r0 = _decodeNextFrameAndSchedule()
    //     0x1186808: bl              #0xd08bb4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0x118680c: r0 = Null
    //     0x118680c: mov             x0, NULL
    // 0x1186810: LeaveFrame
    //     0x1186810: mov             SP, fp
    //     0x1186814: ldp             fp, lr, [SP], #0x10
    // 0x1186818: ret
    //     0x1186818: ret             
    // 0x118681c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118681c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186820: b               #0x11867dc
  }
  _ _maybeDispose(/* No info */) {
    // ** addr: 0x1248fa4, size: 0x124
    // 0x1248fa4: EnterFrame
    //     0x1248fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x1248fa8: mov             fp, SP
    // 0x1248fac: AllocStack(0x20)
    //     0x1248fac: sub             SP, SP, #0x20
    // 0x1248fb0: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0x1248fb0: mov             x0, x1
    //     0x1248fb4: stur            x1, [fp, #-8]
    // 0x1248fb8: CheckStackOverflow
    //     0x1248fb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1248fbc: cmp             SP, x16
    //     0x1248fc0: b.ls            #0x12490bc
    // 0x1248fc4: mov             x1, x0
    // 0x1248fc8: r0 = _maybeDispose()
    //     0x1248fc8: bl              #0x1248efc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_maybeDispose
    // 0x1248fcc: ldur            x3, [fp, #-8]
    // 0x1248fd0: LoadField: r0 = r3->field_27
    //     0x1248fd0: ldur            w0, [x3, #0x27]
    // 0x1248fd4: DecompressPointer r0
    //     0x1248fd4: add             x0, x0, HEAP, lsl #32
    // 0x1248fd8: tbnz            w0, #4, #0x124909c
    // 0x1248fdc: LoadField: r1 = r3->field_2f
    //     0x1248fdc: ldur            w1, [x3, #0x2f]
    // 0x1248fe0: DecompressPointer r1
    //     0x1248fe0: add             x1, x1, HEAP, lsl #32
    // 0x1248fe4: cmp             w1, NULL
    // 0x1248fe8: b.ne            #0x1248ff4
    // 0x1248fec: mov             x2, x3
    // 0x1248ff0: b               #0x1249010
    // 0x1248ff4: r0 = LoadClassIdInstr(r1)
    //     0x1248ff4: ldur            x0, [x1, #-1]
    //     0x1248ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x1248ffc: r2 = Null
    //     0x1248ffc: mov             x2, NULL
    // 0x1249000: r0 = GDT[cid_x0 + 0x665]()
    //     0x1249000: add             lr, x0, #0x665
    //     0x1249004: ldr             lr, [x21, lr, lsl #3]
    //     0x1249008: blr             lr
    // 0x124900c: ldur            x2, [fp, #-8]
    // 0x1249010: LoadField: r1 = r2->field_2f
    //     0x1249010: ldur            w1, [x2, #0x2f]
    // 0x1249014: DecompressPointer r1
    //     0x1249014: add             x1, x1, HEAP, lsl #32
    // 0x1249018: cmp             w1, NULL
    // 0x124901c: b.ne            #0x1249028
    // 0x1249020: mov             x0, x2
    // 0x1249024: b               #0x1249040
    // 0x1249028: r0 = LoadClassIdInstr(r1)
    //     0x1249028: ldur            x0, [x1, #-1]
    //     0x124902c: ubfx            x0, x0, #0xc, #0x14
    // 0x1249030: r0 = GDT[cid_x0 + 0x549]()
    //     0x1249030: add             lr, x0, #0x549
    //     0x1249034: ldr             lr, [x21, lr, lsl #3]
    //     0x1249038: blr             lr
    // 0x124903c: ldur            x0, [fp, #-8]
    // 0x1249040: StoreField: r0->field_2f = rNULL
    //     0x1249040: stur            NULL, [x0, #0x2f]
    // 0x1249044: LoadField: r2 = r0->field_33
    //     0x1249044: ldur            w2, [x0, #0x33]
    // 0x1249048: DecompressPointer r2
    //     0x1249048: add             x2, x2, HEAP, lsl #32
    // 0x124904c: stur            x2, [fp, #-0x18]
    // 0x1249050: cmp             w2, NULL
    // 0x1249054: b.eq            #0x1249098
    // 0x1249058: LoadField: r1 = r2->field_7
    //     0x1249058: ldur            w1, [x2, #7]
    // 0x124905c: DecompressPointer r1
    //     0x124905c: add             x1, x1, HEAP, lsl #32
    // 0x1249060: cmp             w1, NULL
    // 0x1249064: b.eq            #0x12490c4
    // 0x1249068: LoadField: r3 = r1->field_7
    //     0x1249068: ldur            x3, [x1, #7]
    // 0x124906c: ldr             x1, [x3]
    // 0x1249070: cbz             x1, #0x12490ac
    // 0x1249074: mov             x3, x1
    // 0x1249078: stur            x3, [fp, #-0x10]
    // 0x124907c: r1 = <Never>
    //     0x124907c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1249080: r0 = Pointer()
    //     0x1249080: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1249084: mov             x1, x0
    // 0x1249088: ldur            x0, [fp, #-0x10]
    // 0x124908c: StoreField: r1->field_7 = r0
    //     0x124908c: stur            x0, [x1, #7]
    // 0x1249090: r0 = _dispose$Method$FfiNative()
    //     0x1249090: bl              #0xce93f0  ; [dart:ui] _NativeCodec::_dispose$Method$FfiNative
    // 0x1249094: ldur            x0, [fp, #-8]
    // 0x1249098: StoreField: r0->field_33 = rNULL
    //     0x1249098: stur            NULL, [x0, #0x33]
    // 0x124909c: r0 = Null
    //     0x124909c: mov             x0, NULL
    // 0x12490a0: LeaveFrame
    //     0x12490a0: mov             SP, fp
    //     0x12490a4: ldp             fp, lr, [SP], #0x10
    // 0x12490a8: ret
    //     0x12490a8: ret             
    // 0x12490ac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12490ac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12490b0: str             x16, [SP]
    // 0x12490b4: r0 = _throwNew()
    //     0x12490b4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12490b8: brk             #0
    // 0x12490bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12490bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12490c0: b               #0x1248fc4
    // 0x12490c4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12490c4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addListener(/* No info */) {
    // ** addr: 0x124a604, size: 0x8c
    // 0x124a604: EnterFrame
    //     0x124a604: stp             fp, lr, [SP, #-0x10]!
    //     0x124a608: mov             fp, SP
    // 0x124a60c: AllocStack(0x10)
    //     0x124a60c: sub             SP, SP, #0x10
    // 0x124a610: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x124a610: mov             x0, x1
    //     0x124a614: stur            x1, [fp, #-8]
    //     0x124a618: stur            x2, [fp, #-0x10]
    // 0x124a61c: CheckStackOverflow
    //     0x124a61c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a620: cmp             SP, x16
    //     0x124a624: b.ls            #0x124a688
    // 0x124a628: LoadField: r1 = r0->field_7
    //     0x124a628: ldur            w1, [x0, #7]
    // 0x124a62c: DecompressPointer r1
    //     0x124a62c: add             x1, x1, HEAP, lsl #32
    // 0x124a630: LoadField: r3 = r1->field_b
    //     0x124a630: ldur            w3, [x1, #0xb]
    // 0x124a634: cbnz            w3, #0x124a66c
    // 0x124a638: LoadField: r1 = r0->field_33
    //     0x124a638: ldur            w1, [x0, #0x33]
    // 0x124a63c: DecompressPointer r1
    //     0x124a63c: add             x1, x1, HEAP, lsl #32
    // 0x124a640: cmp             w1, NULL
    // 0x124a644: b.eq            #0x124a66c
    // 0x124a648: LoadField: r3 = r0->field_f
    //     0x124a648: ldur            w3, [x0, #0xf]
    // 0x124a64c: DecompressPointer r3
    //     0x124a64c: add             x3, x3, HEAP, lsl #32
    // 0x124a650: cmp             w3, NULL
    // 0x124a654: b.eq            #0x124a664
    // 0x124a658: r0 = frameCount()
    //     0x124a658: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0x124a65c: cmp             x0, #1
    // 0x124a660: b.le            #0x124a66c
    // 0x124a664: ldur            x1, [fp, #-8]
    // 0x124a668: r0 = _decodeNextFrameAndSchedule()
    //     0x124a668: bl              #0xd08bb4  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0x124a66c: ldur            x1, [fp, #-8]
    // 0x124a670: ldur            x2, [fp, #-0x10]
    // 0x124a674: r0 = addListener()
    //     0x124a674: bl              #0x124a354  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0x124a678: r0 = Null
    //     0x124a678: mov             x0, NULL
    // 0x124a67c: LeaveFrame
    //     0x124a67c: mov             SP, fp
    //     0x124a680: ldp             fp, lr, [SP], #0x10
    // 0x124a684: ret
    //     0x124a684: ret             
    // 0x124a688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a688: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a68c: b               #0x124a628
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x1253be0, size: 0x78
    // 0x1253be0: EnterFrame
    //     0x1253be0: stp             fp, lr, [SP, #-0x10]!
    //     0x1253be4: mov             fp, SP
    // 0x1253be8: AllocStack(0x8)
    //     0x1253be8: sub             SP, SP, #8
    // 0x1253bec: SetupParameters(MultiFrameImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0x1253bec: mov             x0, x1
    //     0x1253bf0: stur            x1, [fp, #-8]
    // 0x1253bf4: CheckStackOverflow
    //     0x1253bf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1253bf8: cmp             SP, x16
    //     0x1253bfc: b.ls            #0x1253c50
    // 0x1253c00: mov             x1, x0
    // 0x1253c04: r0 = removeListener()
    //     0x1253c04: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x1253c08: ldur            x0, [fp, #-8]
    // 0x1253c0c: LoadField: r1 = r0->field_7
    //     0x1253c0c: ldur            w1, [x0, #7]
    // 0x1253c10: DecompressPointer r1
    //     0x1253c10: add             x1, x1, HEAP, lsl #32
    // 0x1253c14: LoadField: r2 = r1->field_b
    //     0x1253c14: ldur            w2, [x1, #0xb]
    // 0x1253c18: cbnz            w2, #0x1253c40
    // 0x1253c1c: LoadField: r1 = r0->field_57
    //     0x1253c1c: ldur            w1, [x0, #0x57]
    // 0x1253c20: DecompressPointer r1
    //     0x1253c20: add             x1, x1, HEAP, lsl #32
    // 0x1253c24: cmp             w1, NULL
    // 0x1253c28: b.ne            #0x1253c34
    // 0x1253c2c: mov             x1, x0
    // 0x1253c30: b               #0x1253c3c
    // 0x1253c34: r0 = cancel()
    //     0x1253c34: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x1253c38: ldur            x1, [fp, #-8]
    // 0x1253c3c: StoreField: r1->field_57 = rNULL
    //     0x1253c3c: stur            NULL, [x1, #0x57]
    // 0x1253c40: r0 = Null
    //     0x1253c40: mov             x0, NULL
    // 0x1253c44: LeaveFrame
    //     0x1253c44: mov             SP, fp
    //     0x1253c48: ldp             fp, lr, [SP], #0x10
    // 0x1253c4c: ret
    //     0x1253c4c: ret             
    // 0x1253c50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1253c50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1253c54: b               #0x1253c00
  }
}

// class id: 5245, size: 0x30, field offset: 0x30
class OneFrameImageStreamCompleter extends ImageStreamCompleter {

  _ OneFrameImageStreamCompleter(/* No info */) {
    // ** addr: 0xf30bc8, size: 0x98
    // 0xf30bc8: EnterFrame
    //     0xf30bc8: stp             fp, lr, [SP, #-0x10]!
    //     0xf30bcc: mov             fp, SP
    // 0xf30bd0: AllocStack(0x38)
    //     0xf30bd0: sub             SP, SP, #0x38
    // 0xf30bd4: SetupParameters(OneFrameImageStreamCompleter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf30bd4: stur            x1, [fp, #-8]
    //     0xf30bd8: stur            x2, [fp, #-0x10]
    // 0xf30bdc: CheckStackOverflow
    //     0xf30bdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30be0: cmp             SP, x16
    //     0xf30be4: b.ls            #0xf30c58
    // 0xf30be8: r1 = 1
    //     0xf30be8: mov             x1, #1
    // 0xf30bec: r0 = AllocateContext()
    //     0xf30bec: bl              #0x13de838  ; AllocateContextStub
    // 0xf30bf0: mov             x2, x0
    // 0xf30bf4: ldur            x0, [fp, #-8]
    // 0xf30bf8: stur            x2, [fp, #-0x18]
    // 0xf30bfc: StoreField: r2->field_f = r0
    //     0xf30bfc: stur            w0, [x2, #0xf]
    // 0xf30c00: mov             x1, x0
    // 0xf30c04: r0 = ImageStreamCompleter()
    //     0xf30c04: bl              #0x91aa54  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0xf30c08: ldur            x2, [fp, #-8]
    // 0xf30c0c: r1 = Function 'setImage':.
    //     0xf30c0c: add             x1, PP, #0x93, lsl #12  ; [pp+0x93890] AnonymousClosure: (0xd08af0), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::setImage (0xd08768)
    //     0xf30c10: ldr             x1, [x1, #0x890]
    // 0xf30c14: r0 = AllocateClosure()
    //     0xf30c14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf30c18: ldur            x2, [fp, #-0x18]
    // 0xf30c1c: r1 = Function '<anonymous closure>':.
    //     0xf30c1c: add             x1, PP, #0x93, lsl #12  ; [pp+0x93898] AnonymousClosure: (0xf30c60), in [package:flutter/src/painting/image_stream.dart] OneFrameImageStreamCompleter::OneFrameImageStreamCompleter (0xf30bc8)
    //     0xf30c20: ldr             x1, [x1, #0x898]
    // 0xf30c24: stur            x0, [fp, #-8]
    // 0xf30c28: r0 = AllocateClosure()
    //     0xf30c28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf30c2c: r16 = <void?>
    //     0xf30c2c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf30c30: ldur            lr, [fp, #-0x10]
    // 0xf30c34: stp             lr, x16, [SP, #0x10]
    // 0xf30c38: ldur            x16, [fp, #-8]
    // 0xf30c3c: stp             x0, x16, [SP]
    // 0xf30c40: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xf30c40: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xf30c44: r0 = then()
    //     0xf30c44: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xf30c48: r0 = Null
    //     0xf30c48: mov             x0, NULL
    // 0xf30c4c: LeaveFrame
    //     0xf30c4c: mov             SP, fp
    //     0xf30c50: ldp             fp, lr, [SP], #0x10
    // 0xf30c54: ret
    //     0xf30c54: ret             
    // 0xf30c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30c58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30c5c: b               #0xf30be8
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xf30c60, size: 0x8c
    // 0xf30c60: EnterFrame
    //     0xf30c60: stp             fp, lr, [SP, #-0x10]!
    //     0xf30c64: mov             fp, SP
    // 0xf30c68: AllocStack(0x20)
    //     0xf30c68: sub             SP, SP, #0x20
    // 0xf30c6c: SetupParameters([dynamic _ /* r0 */])
    //     0xf30c6c: ldr             x0, [fp, #0x20]
    //     0xf30c70: ldur            w2, [x0, #0x17]
    //     0xf30c74: add             x2, x2, HEAP, lsl #32
    //     0xf30c78: stur            x2, [fp, #-8]
    // 0xf30c7c: CheckStackOverflow
    //     0xf30c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30c80: cmp             SP, x16
    //     0xf30c84: b.ls            #0xf30ce4
    // 0xf30c88: r1 = <List<Object>>
    //     0xf30c88: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xf30c8c: r0 = ErrorDescription()
    //     0xf30c8c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xf30c90: mov             x1, x0
    // 0xf30c94: r2 = "resolving a single-frame image stream"
    //     0xf30c94: add             x2, PP, #0x93, lsl #12  ; [pp+0x938a0] "resolving a single-frame image stream"
    //     0xf30c98: ldr             x2, [x2, #0x8a0]
    // 0xf30c9c: r3 = Instance_DiagnosticLevel
    //     0xf30c9c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xf30ca0: stur            x0, [fp, #-0x10]
    // 0xf30ca4: r0 = _ErrorDiagnostic()
    //     0xf30ca4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xf30ca8: ldur            x0, [fp, #-8]
    // 0xf30cac: LoadField: r1 = r0->field_f
    //     0xf30cac: ldur            w1, [x0, #0xf]
    // 0xf30cb0: DecompressPointer r1
    //     0xf30cb0: add             x1, x1, HEAP, lsl #32
    // 0xf30cb4: r16 = true
    //     0xf30cb4: add             x16, NULL, #0x20  ; true
    // 0xf30cb8: stp             x16, NULL, [SP]
    // 0xf30cbc: ldur            x2, [fp, #-0x10]
    // 0xf30cc0: ldr             x3, [fp, #0x18]
    // 0xf30cc4: ldr             x5, [fp, #0x10]
    // 0xf30cc8: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xf30cc8: add             x4, PP, #0x81, lsl #12  ; [pp+0x813b8] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xf30ccc: ldr             x4, [x4, #0x3b8]
    // 0xf30cd0: r0 = reportError()
    //     0xf30cd0: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xf30cd4: r0 = Null
    //     0xf30cd4: mov             x0, NULL
    // 0xf30cd8: LeaveFrame
    //     0xf30cd8: mov             SP, fp
    //     0xf30cdc: ldp             fp, lr, [SP], #0x10
    // 0xf30ce0: ret
    //     0xf30ce0: ret             
    // 0xf30ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30ce4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30ce8: b               #0xf30c88
  }
}
