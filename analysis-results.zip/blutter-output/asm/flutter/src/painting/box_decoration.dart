// lib: , url: package:flutter/src/painting/box_decoration.dart

// class id: 1048984, size: 0x8
class :: {
}

// class id: 3258, size: 0x1c, field offset: 0xc
class _BoxDecorationPainter extends BoxPainter {

  _ paint(/* No info */) {
    // ** addr: 0x12f6bf4, size: 0x23c
    // 0x12f6bf4: EnterFrame
    //     0x12f6bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f6bf8: mov             fp, SP
    // 0x12f6bfc: AllocStack(0x60)
    //     0x12f6bfc: sub             SP, SP, #0x60
    // 0x12f6c00: SetupParameters(_BoxDecorationPainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x12f6c00: stur            x1, [fp, #-8]
    //     0x12f6c04: mov             x16, x3
    //     0x12f6c08: mov             x3, x1
    //     0x12f6c0c: mov             x1, x16
    //     0x12f6c10: mov             x0, x2
    //     0x12f6c14: stur            x2, [fp, #-0x10]
    //     0x12f6c18: stur            x5, [fp, #-0x18]
    // 0x12f6c1c: CheckStackOverflow
    //     0x12f6c1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f6c20: cmp             SP, x16
    //     0x12f6c24: b.ls            #0x12f6e20
    // 0x12f6c28: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x12f6c28: ldur            w2, [x5, #0x17]
    // 0x12f6c2c: DecompressPointer r2
    //     0x12f6c2c: add             x2, x2, HEAP, lsl #32
    // 0x12f6c30: cmp             w2, NULL
    // 0x12f6c34: b.eq            #0x12f6e28
    // 0x12f6c38: r0 = &()
    //     0x12f6c38: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12f6c3c: mov             x4, x0
    // 0x12f6c40: ldur            x0, [fp, #-0x18]
    // 0x12f6c44: stur            x4, [fp, #-0x28]
    // 0x12f6c48: LoadField: r6 = r0->field_13
    //     0x12f6c48: ldur            w6, [x0, #0x13]
    // 0x12f6c4c: DecompressPointer r6
    //     0x12f6c4c: add             x6, x6, HEAP, lsl #32
    // 0x12f6c50: ldur            x1, [fp, #-8]
    // 0x12f6c54: ldur            x2, [fp, #-0x10]
    // 0x12f6c58: mov             x3, x4
    // 0x12f6c5c: mov             x5, x6
    // 0x12f6c60: stur            x6, [fp, #-0x20]
    // 0x12f6c64: r0 = _paintShadows()
    //     0x12f6c64: bl              #0x12f7f68  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintShadows
    // 0x12f6c68: ldur            x1, [fp, #-8]
    // 0x12f6c6c: ldur            x2, [fp, #-0x10]
    // 0x12f6c70: ldur            x3, [fp, #-0x28]
    // 0x12f6c74: ldur            x5, [fp, #-0x20]
    // 0x12f6c78: r0 = _paintBackgroundColor()
    //     0x12f6c78: bl              #0x12f72ac  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBackgroundColor
    // 0x12f6c7c: ldur            x1, [fp, #-8]
    // 0x12f6c80: ldur            x2, [fp, #-0x10]
    // 0x12f6c84: ldur            x3, [fp, #-0x28]
    // 0x12f6c88: ldur            x5, [fp, #-0x18]
    // 0x12f6c8c: r0 = _paintBackgroundImage()
    //     0x12f6c8c: bl              #0x12f6e30  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBackgroundImage
    // 0x12f6c90: ldur            x0, [fp, #-8]
    // 0x12f6c94: LoadField: r1 = r0->field_b
    //     0x12f6c94: ldur            w1, [x0, #0xb]
    // 0x12f6c98: DecompressPointer r1
    //     0x12f6c98: add             x1, x1, HEAP, lsl #32
    // 0x12f6c9c: LoadField: r0 = r1->field_f
    //     0x12f6c9c: ldur            w0, [x1, #0xf]
    // 0x12f6ca0: DecompressPointer r0
    //     0x12f6ca0: add             x0, x0, HEAP, lsl #32
    // 0x12f6ca4: stur            x0, [fp, #-0x48]
    // 0x12f6ca8: cmp             w0, NULL
    // 0x12f6cac: b.eq            #0x12f6e10
    // 0x12f6cb0: LoadField: r2 = r1->field_23
    //     0x12f6cb0: ldur            w2, [x1, #0x23]
    // 0x12f6cb4: DecompressPointer r2
    //     0x12f6cb4: add             x2, x2, HEAP, lsl #32
    // 0x12f6cb8: stur            x2, [fp, #-0x40]
    // 0x12f6cbc: LoadField: r3 = r1->field_13
    //     0x12f6cbc: ldur            w3, [x1, #0x13]
    // 0x12f6cc0: DecompressPointer r3
    //     0x12f6cc0: add             x3, x3, HEAP, lsl #32
    // 0x12f6cc4: cmp             w3, NULL
    // 0x12f6cc8: b.ne            #0x12f6cd4
    // 0x12f6ccc: r0 = Null
    //     0x12f6ccc: mov             x0, NULL
    // 0x12f6cd0: b               #0x12f6de8
    // 0x12f6cd4: r1 = LoadClassIdInstr(r3)
    //     0x12f6cd4: ldur            x1, [x3, #-1]
    //     0x12f6cd8: ubfx            x1, x1, #0xc, #0x14
    // 0x12f6cdc: cmp             x1, #0xb88
    // 0x12f6ce0: b.ne            #0x12f6dbc
    // 0x12f6ce4: ldur            x1, [fp, #-0x20]
    // 0x12f6ce8: cmp             w1, NULL
    // 0x12f6cec: b.eq            #0x12f6e2c
    // 0x12f6cf0: LoadField: r4 = r1->field_7
    //     0x12f6cf0: ldur            x4, [x1, #7]
    // 0x12f6cf4: cmp             x4, #0
    // 0x12f6cf8: b.gt            #0x12f6d5c
    // 0x12f6cfc: LoadField: r4 = r3->field_b
    //     0x12f6cfc: ldur            w4, [x3, #0xb]
    // 0x12f6d00: DecompressPointer r4
    //     0x12f6d00: add             x4, x4, HEAP, lsl #32
    // 0x12f6d04: stur            x4, [fp, #-0x38]
    // 0x12f6d08: LoadField: r5 = r3->field_7
    //     0x12f6d08: ldur            w5, [x3, #7]
    // 0x12f6d0c: DecompressPointer r5
    //     0x12f6d0c: add             x5, x5, HEAP, lsl #32
    // 0x12f6d10: stur            x5, [fp, #-0x30]
    // 0x12f6d14: LoadField: r6 = r3->field_13
    //     0x12f6d14: ldur            w6, [x3, #0x13]
    // 0x12f6d18: DecompressPointer r6
    //     0x12f6d18: add             x6, x6, HEAP, lsl #32
    // 0x12f6d1c: stur            x6, [fp, #-0x18]
    // 0x12f6d20: LoadField: r7 = r3->field_f
    //     0x12f6d20: ldur            w7, [x3, #0xf]
    // 0x12f6d24: DecompressPointer r7
    //     0x12f6d24: add             x7, x7, HEAP, lsl #32
    // 0x12f6d28: stur            x7, [fp, #-8]
    // 0x12f6d2c: r0 = BorderRadius()
    //     0x12f6d2c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f6d30: mov             x1, x0
    // 0x12f6d34: ldur            x0, [fp, #-0x38]
    // 0x12f6d38: StoreField: r1->field_7 = r0
    //     0x12f6d38: stur            w0, [x1, #7]
    // 0x12f6d3c: ldur            x0, [fp, #-0x30]
    // 0x12f6d40: StoreField: r1->field_b = r0
    //     0x12f6d40: stur            w0, [x1, #0xb]
    // 0x12f6d44: ldur            x0, [fp, #-0x18]
    // 0x12f6d48: StoreField: r1->field_f = r0
    //     0x12f6d48: stur            w0, [x1, #0xf]
    // 0x12f6d4c: ldur            x0, [fp, #-8]
    // 0x12f6d50: StoreField: r1->field_13 = r0
    //     0x12f6d50: stur            w0, [x1, #0x13]
    // 0x12f6d54: mov             x0, x1
    // 0x12f6d58: b               #0x12f6de8
    // 0x12f6d5c: LoadField: r0 = r3->field_7
    //     0x12f6d5c: ldur            w0, [x3, #7]
    // 0x12f6d60: DecompressPointer r0
    //     0x12f6d60: add             x0, x0, HEAP, lsl #32
    // 0x12f6d64: stur            x0, [fp, #-0x38]
    // 0x12f6d68: LoadField: r1 = r3->field_b
    //     0x12f6d68: ldur            w1, [x3, #0xb]
    // 0x12f6d6c: DecompressPointer r1
    //     0x12f6d6c: add             x1, x1, HEAP, lsl #32
    // 0x12f6d70: stur            x1, [fp, #-0x30]
    // 0x12f6d74: LoadField: r2 = r3->field_f
    //     0x12f6d74: ldur            w2, [x3, #0xf]
    // 0x12f6d78: DecompressPointer r2
    //     0x12f6d78: add             x2, x2, HEAP, lsl #32
    // 0x12f6d7c: stur            x2, [fp, #-0x18]
    // 0x12f6d80: LoadField: r4 = r3->field_13
    //     0x12f6d80: ldur            w4, [x3, #0x13]
    // 0x12f6d84: DecompressPointer r4
    //     0x12f6d84: add             x4, x4, HEAP, lsl #32
    // 0x12f6d88: stur            x4, [fp, #-8]
    // 0x12f6d8c: r0 = BorderRadius()
    //     0x12f6d8c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f6d90: mov             x1, x0
    // 0x12f6d94: ldur            x0, [fp, #-0x38]
    // 0x12f6d98: StoreField: r1->field_7 = r0
    //     0x12f6d98: stur            w0, [x1, #7]
    // 0x12f6d9c: ldur            x0, [fp, #-0x30]
    // 0x12f6da0: StoreField: r1->field_b = r0
    //     0x12f6da0: stur            w0, [x1, #0xb]
    // 0x12f6da4: ldur            x0, [fp, #-0x18]
    // 0x12f6da8: StoreField: r1->field_f = r0
    //     0x12f6da8: stur            w0, [x1, #0xf]
    // 0x12f6dac: ldur            x0, [fp, #-8]
    // 0x12f6db0: StoreField: r1->field_13 = r0
    //     0x12f6db0: stur            w0, [x1, #0x13]
    // 0x12f6db4: mov             x0, x1
    // 0x12f6db8: b               #0x12f6de8
    // 0x12f6dbc: cmp             x1, #0xb89
    // 0x12f6dc0: b.ne            #0x12f6dcc
    // 0x12f6dc4: mov             x0, x3
    // 0x12f6dc8: b               #0x12f6de8
    // 0x12f6dcc: r0 = LoadClassIdInstr(r3)
    //     0x12f6dcc: ldur            x0, [x3, #-1]
    //     0x12f6dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x12f6dd4: mov             x1, x3
    // 0x12f6dd8: ldur            x2, [fp, #-0x20]
    // 0x12f6ddc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f6ddc: sub             lr, x0, #1, lsl #12
    //     0x12f6de0: ldr             lr, [x21, lr, lsl #3]
    //     0x12f6de4: blr             lr
    // 0x12f6de8: ldur            x16, [fp, #-0x40]
    // 0x12f6dec: stp             x0, x16, [SP, #8]
    // 0x12f6df0: ldur            x16, [fp, #-0x20]
    // 0x12f6df4: str             x16, [SP]
    // 0x12f6df8: ldur            x1, [fp, #-0x48]
    // 0x12f6dfc: ldur            x2, [fp, #-0x10]
    // 0x12f6e00: ldur            x3, [fp, #-0x28]
    // 0x12f6e04: r4 = const [0, 0x6, 0x3, 0x3, borderRadius, 0x4, shape, 0x3, textDirection, 0x5, null]
    //     0x12f6e04: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0d80] List(11) [0, 0x6, 0x3, 0x3, "borderRadius", 0x4, "shape", 0x3, "textDirection", 0x5, Null]
    //     0x12f6e08: ldr             x4, [x4, #0xd80]
    // 0x12f6e0c: r0 = paint()
    //     0x12f6e0c: bl              #0x12ef9ec  ; [package:flutter/src/painting/box_border.dart] Border::paint
    // 0x12f6e10: r0 = Null
    //     0x12f6e10: mov             x0, NULL
    // 0x12f6e14: LeaveFrame
    //     0x12f6e14: mov             SP, fp
    //     0x12f6e18: ldp             fp, lr, [SP], #0x10
    // 0x12f6e1c: ret
    //     0x12f6e1c: ret             
    // 0x12f6e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f6e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f6e24: b               #0x12f6c28
    // 0x12f6e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f6e28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f6e2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f6e2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintBackgroundImage(/* No info */) {
    // ** addr: 0x12f6e30, size: 0x47c
    // 0x12f6e30: EnterFrame
    //     0x12f6e30: stp             fp, lr, [SP, #-0x10]!
    //     0x12f6e34: mov             fp, SP
    // 0x12f6e38: AllocStack(0x80)
    //     0x12f6e38: sub             SP, SP, #0x80
    // 0x12f6e3c: SetupParameters(_BoxDecorationPainter this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r6, fp-0x28 */)
    //     0x12f6e3c: mov             x6, x5
    //     0x12f6e40: stur            x5, [fp, #-0x28]
    //     0x12f6e44: mov             x5, x1
    //     0x12f6e48: mov             x4, x2
    //     0x12f6e4c: stur            x1, [fp, #-0x10]
    //     0x12f6e50: stur            x2, [fp, #-0x18]
    //     0x12f6e54: stur            x3, [fp, #-0x20]
    // 0x12f6e58: CheckStackOverflow
    //     0x12f6e58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f6e5c: cmp             SP, x16
    //     0x12f6e60: b.ls            #0x12f7290
    // 0x12f6e64: LoadField: r7 = r5->field_b
    //     0x12f6e64: ldur            w7, [x5, #0xb]
    // 0x12f6e68: DecompressPointer r7
    //     0x12f6e68: add             x7, x7, HEAP, lsl #32
    // 0x12f6e6c: stur            x7, [fp, #-8]
    // 0x12f6e70: LoadField: r1 = r7->field_b
    //     0x12f6e70: ldur            w1, [x7, #0xb]
    // 0x12f6e74: DecompressPointer r1
    //     0x12f6e74: add             x1, x1, HEAP, lsl #32
    // 0x12f6e78: cmp             w1, NULL
    // 0x12f6e7c: b.ne            #0x12f6e90
    // 0x12f6e80: r0 = Null
    //     0x12f6e80: mov             x0, NULL
    // 0x12f6e84: LeaveFrame
    //     0x12f6e84: mov             SP, fp
    //     0x12f6e88: ldp             fp, lr, [SP], #0x10
    // 0x12f6e8c: ret
    //     0x12f6e8c: ret             
    // 0x12f6e90: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x12f6e90: ldur            w0, [x5, #0x17]
    // 0x12f6e94: DecompressPointer r0
    //     0x12f6e94: add             x0, x0, HEAP, lsl #32
    // 0x12f6e98: cmp             w0, NULL
    // 0x12f6e9c: b.ne            #0x12f6ee8
    // 0x12f6ea0: LoadField: r2 = r5->field_7
    //     0x12f6ea0: ldur            w2, [x5, #7]
    // 0x12f6ea4: DecompressPointer r2
    //     0x12f6ea4: add             x2, x2, HEAP, lsl #32
    // 0x12f6ea8: cmp             w2, NULL
    // 0x12f6eac: b.eq            #0x12f7298
    // 0x12f6eb0: r0 = LoadClassIdInstr(r1)
    //     0x12f6eb0: ldur            x0, [x1, #-1]
    //     0x12f6eb4: ubfx            x0, x0, #0xc, #0x14
    // 0x12f6eb8: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x12f6eb8: sub             lr, x0, #0xfb3
    //     0x12f6ebc: ldr             lr, [x21, lr, lsl #3]
    //     0x12f6ec0: blr             lr
    // 0x12f6ec4: ldur            x1, [fp, #-0x10]
    // 0x12f6ec8: ArrayStore: r1[0] = r0  ; List_4
    //     0x12f6ec8: stur            w0, [x1, #0x17]
    //     0x12f6ecc: ldurb           w16, [x1, #-1]
    //     0x12f6ed0: ldurb           w17, [x0, #-1]
    //     0x12f6ed4: and             x16, x17, x16, lsr #2
    //     0x12f6ed8: tst             x16, HEAP, lsr #32
    //     0x12f6edc: b.eq            #0x12f6ee4
    //     0x12f6ee0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f6ee4: b               #0x12f6eec
    // 0x12f6ee8: mov             x1, x5
    // 0x12f6eec: ldur            x0, [fp, #-8]
    // 0x12f6ef0: LoadField: r2 = r0->field_23
    //     0x12f6ef0: ldur            w2, [x0, #0x23]
    // 0x12f6ef4: DecompressPointer r2
    //     0x12f6ef4: add             x2, x2, HEAP, lsl #32
    // 0x12f6ef8: LoadField: r3 = r2->field_7
    //     0x12f6ef8: ldur            x3, [x2, #7]
    // 0x12f6efc: cmp             x3, #0
    // 0x12f6f00: b.gt            #0x12f715c
    // 0x12f6f04: LoadField: r2 = r0->field_13
    //     0x12f6f04: ldur            w2, [x0, #0x13]
    // 0x12f6f08: DecompressPointer r2
    //     0x12f6f08: add             x2, x2, HEAP, lsl #32
    // 0x12f6f0c: stur            x2, [fp, #-0x30]
    // 0x12f6f10: cmp             w2, NULL
    // 0x12f6f14: b.eq            #0x12f7150
    // 0x12f6f18: ldur            x6, [fp, #-0x28]
    // 0x12f6f1c: r0 = _NativePath()
    //     0x12f6f1c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12f6f20: mov             x1, x0
    // 0x12f6f24: stur            x0, [fp, #-8]
    // 0x12f6f28: r0 = __constructor$Method$FfiNative()
    //     0x12f6f28: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12f6f2c: ldur            x6, [fp, #-0x28]
    // 0x12f6f30: LoadField: r2 = r6->field_13
    //     0x12f6f30: ldur            w2, [x6, #0x13]
    // 0x12f6f34: DecompressPointer r2
    //     0x12f6f34: add             x2, x2, HEAP, lsl #32
    // 0x12f6f38: ldur            x0, [fp, #-0x30]
    // 0x12f6f3c: r1 = LoadClassIdInstr(r0)
    //     0x12f6f3c: ldur            x1, [x0, #-1]
    //     0x12f6f40: ubfx            x1, x1, #0xc, #0x14
    // 0x12f6f44: cmp             x1, #0xb88
    // 0x12f6f48: b.ne            #0x12f7018
    // 0x12f6f4c: cmp             w2, NULL
    // 0x12f6f50: b.eq            #0x12f729c
    // 0x12f6f54: LoadField: r1 = r2->field_7
    //     0x12f6f54: ldur            x1, [x2, #7]
    // 0x12f6f58: cmp             x1, #0
    // 0x12f6f5c: b.gt            #0x12f6fbc
    // 0x12f6f60: LoadField: r1 = r0->field_b
    //     0x12f6f60: ldur            w1, [x0, #0xb]
    // 0x12f6f64: DecompressPointer r1
    //     0x12f6f64: add             x1, x1, HEAP, lsl #32
    // 0x12f6f68: stur            x1, [fp, #-0x50]
    // 0x12f6f6c: LoadField: r2 = r0->field_7
    //     0x12f6f6c: ldur            w2, [x0, #7]
    // 0x12f6f70: DecompressPointer r2
    //     0x12f6f70: add             x2, x2, HEAP, lsl #32
    // 0x12f6f74: stur            x2, [fp, #-0x48]
    // 0x12f6f78: LoadField: r3 = r0->field_13
    //     0x12f6f78: ldur            w3, [x0, #0x13]
    // 0x12f6f7c: DecompressPointer r3
    //     0x12f6f7c: add             x3, x3, HEAP, lsl #32
    // 0x12f6f80: stur            x3, [fp, #-0x40]
    // 0x12f6f84: LoadField: r4 = r0->field_f
    //     0x12f6f84: ldur            w4, [x0, #0xf]
    // 0x12f6f88: DecompressPointer r4
    //     0x12f6f88: add             x4, x4, HEAP, lsl #32
    // 0x12f6f8c: stur            x4, [fp, #-0x38]
    // 0x12f6f90: r0 = BorderRadius()
    //     0x12f6f90: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f6f94: mov             x1, x0
    // 0x12f6f98: ldur            x0, [fp, #-0x50]
    // 0x12f6f9c: StoreField: r1->field_7 = r0
    //     0x12f6f9c: stur            w0, [x1, #7]
    // 0x12f6fa0: ldur            x0, [fp, #-0x48]
    // 0x12f6fa4: StoreField: r1->field_b = r0
    //     0x12f6fa4: stur            w0, [x1, #0xb]
    // 0x12f6fa8: ldur            x0, [fp, #-0x40]
    // 0x12f6fac: StoreField: r1->field_f = r0
    //     0x12f6fac: stur            w0, [x1, #0xf]
    // 0x12f6fb0: ldur            x0, [fp, #-0x38]
    // 0x12f6fb4: StoreField: r1->field_13 = r0
    //     0x12f6fb4: stur            w0, [x1, #0x13]
    // 0x12f6fb8: b               #0x12f704c
    // 0x12f6fbc: LoadField: r1 = r0->field_7
    //     0x12f6fbc: ldur            w1, [x0, #7]
    // 0x12f6fc0: DecompressPointer r1
    //     0x12f6fc0: add             x1, x1, HEAP, lsl #32
    // 0x12f6fc4: stur            x1, [fp, #-0x50]
    // 0x12f6fc8: LoadField: r2 = r0->field_b
    //     0x12f6fc8: ldur            w2, [x0, #0xb]
    // 0x12f6fcc: DecompressPointer r2
    //     0x12f6fcc: add             x2, x2, HEAP, lsl #32
    // 0x12f6fd0: stur            x2, [fp, #-0x48]
    // 0x12f6fd4: LoadField: r3 = r0->field_f
    //     0x12f6fd4: ldur            w3, [x0, #0xf]
    // 0x12f6fd8: DecompressPointer r3
    //     0x12f6fd8: add             x3, x3, HEAP, lsl #32
    // 0x12f6fdc: stur            x3, [fp, #-0x40]
    // 0x12f6fe0: LoadField: r4 = r0->field_13
    //     0x12f6fe0: ldur            w4, [x0, #0x13]
    // 0x12f6fe4: DecompressPointer r4
    //     0x12f6fe4: add             x4, x4, HEAP, lsl #32
    // 0x12f6fe8: stur            x4, [fp, #-0x38]
    // 0x12f6fec: r0 = BorderRadius()
    //     0x12f6fec: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f6ff0: mov             x1, x0
    // 0x12f6ff4: ldur            x0, [fp, #-0x50]
    // 0x12f6ff8: StoreField: r1->field_7 = r0
    //     0x12f6ff8: stur            w0, [x1, #7]
    // 0x12f6ffc: ldur            x0, [fp, #-0x48]
    // 0x12f7000: StoreField: r1->field_b = r0
    //     0x12f7000: stur            w0, [x1, #0xb]
    // 0x12f7004: ldur            x0, [fp, #-0x40]
    // 0x12f7008: StoreField: r1->field_f = r0
    //     0x12f7008: stur            w0, [x1, #0xf]
    // 0x12f700c: ldur            x0, [fp, #-0x38]
    // 0x12f7010: StoreField: r1->field_13 = r0
    //     0x12f7010: stur            w0, [x1, #0x13]
    // 0x12f7014: b               #0x12f704c
    // 0x12f7018: cmp             x1, #0xb89
    // 0x12f701c: b.ne            #0x12f7028
    // 0x12f7020: mov             x1, x0
    // 0x12f7024: b               #0x12f704c
    // 0x12f7028: r1 = LoadClassIdInstr(r0)
    //     0x12f7028: ldur            x1, [x0, #-1]
    //     0x12f702c: ubfx            x1, x1, #0xc, #0x14
    // 0x12f7030: mov             x16, x0
    // 0x12f7034: mov             x0, x1
    // 0x12f7038: mov             x1, x16
    // 0x12f703c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f703c: sub             lr, x0, #1, lsl #12
    //     0x12f7040: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7044: blr             lr
    // 0x12f7048: mov             x1, x0
    // 0x12f704c: ldur            x0, [fp, #-8]
    // 0x12f7050: ldur            x2, [fp, #-0x20]
    // 0x12f7054: r0 = toRRect()
    //     0x12f7054: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12f7058: stur            x0, [fp, #-0x30]
    // 0x12f705c: LoadField: d0 = r0->field_b
    //     0x12f705c: ldur            d0, [x0, #0xb]
    // 0x12f7060: fcvt            s1, d0
    // 0x12f7064: stur            d1, [fp, #-0x60]
    // 0x12f7068: r4 = 24
    //     0x12f7068: mov             x4, #0x18
    // 0x12f706c: r0 = AllocateFloat32Array()
    //     0x12f706c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12f7070: ldur            d0, [fp, #-0x60]
    // 0x12f7074: stur            x0, [fp, #-0x38]
    // 0x12f7078: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f7078: stur            s0, [x0, #0x17]
    // 0x12f707c: ldur            x1, [fp, #-0x30]
    // 0x12f7080: LoadField: d0 = r1->field_13
    //     0x12f7080: ldur            d0, [x1, #0x13]
    // 0x12f7084: fcvt            s1, d0
    // 0x12f7088: StoreField: r0->field_1b = d1
    //     0x12f7088: stur            s1, [x0, #0x1b]
    // 0x12f708c: LoadField: d0 = r1->field_1b
    //     0x12f708c: ldur            d0, [x1, #0x1b]
    // 0x12f7090: fcvt            s1, d0
    // 0x12f7094: StoreField: r0->field_1f = d1
    //     0x12f7094: stur            s1, [x0, #0x1f]
    // 0x12f7098: LoadField: d0 = r1->field_23
    //     0x12f7098: ldur            d0, [x1, #0x23]
    // 0x12f709c: fcvt            s1, d0
    // 0x12f70a0: StoreField: r0->field_23 = d1
    //     0x12f70a0: stur            s1, [x0, #0x23]
    // 0x12f70a4: LoadField: d0 = r1->field_2b
    //     0x12f70a4: ldur            d0, [x1, #0x2b]
    // 0x12f70a8: fcvt            s1, d0
    // 0x12f70ac: StoreField: r0->field_27 = d1
    //     0x12f70ac: stur            s1, [x0, #0x27]
    // 0x12f70b0: LoadField: d0 = r1->field_33
    //     0x12f70b0: ldur            d0, [x1, #0x33]
    // 0x12f70b4: fcvt            s1, d0
    // 0x12f70b8: StoreField: r0->field_2b = d1
    //     0x12f70b8: stur            s1, [x0, #0x2b]
    // 0x12f70bc: LoadField: d0 = r1->field_3b
    //     0x12f70bc: ldur            d0, [x1, #0x3b]
    // 0x12f70c0: fcvt            s1, d0
    // 0x12f70c4: StoreField: r0->field_2f = d1
    //     0x12f70c4: stur            s1, [x0, #0x2f]
    // 0x12f70c8: LoadField: d0 = r1->field_43
    //     0x12f70c8: ldur            d0, [x1, #0x43]
    // 0x12f70cc: fcvt            s1, d0
    // 0x12f70d0: StoreField: r0->field_33 = d1
    //     0x12f70d0: stur            s1, [x0, #0x33]
    // 0x12f70d4: LoadField: d0 = r1->field_4b
    //     0x12f70d4: ldur            d0, [x1, #0x4b]
    // 0x12f70d8: fcvt            s1, d0
    // 0x12f70dc: StoreField: r0->field_37 = d1
    //     0x12f70dc: stur            s1, [x0, #0x37]
    // 0x12f70e0: LoadField: d0 = r1->field_53
    //     0x12f70e0: ldur            d0, [x1, #0x53]
    // 0x12f70e4: fcvt            s1, d0
    // 0x12f70e8: StoreField: r0->field_3b = d1
    //     0x12f70e8: stur            s1, [x0, #0x3b]
    // 0x12f70ec: LoadField: d0 = r1->field_5b
    //     0x12f70ec: ldur            d0, [x1, #0x5b]
    // 0x12f70f0: fcvt            s1, d0
    // 0x12f70f4: StoreField: r0->field_3f = d1
    //     0x12f70f4: stur            s1, [x0, #0x3f]
    // 0x12f70f8: LoadField: d0 = r1->field_63
    //     0x12f70f8: ldur            d0, [x1, #0x63]
    // 0x12f70fc: fcvt            s1, d0
    // 0x12f7100: StoreField: r0->field_43 = d1
    //     0x12f7100: stur            s1, [x0, #0x43]
    // 0x12f7104: ldur            x2, [fp, #-8]
    // 0x12f7108: LoadField: r1 = r2->field_7
    //     0x12f7108: ldur            w1, [x2, #7]
    // 0x12f710c: DecompressPointer r1
    //     0x12f710c: add             x1, x1, HEAP, lsl #32
    // 0x12f7110: cmp             w1, NULL
    // 0x12f7114: b.eq            #0x12f72a0
    // 0x12f7118: LoadField: r3 = r1->field_7
    //     0x12f7118: ldur            x3, [x1, #7]
    // 0x12f711c: ldr             x1, [x3]
    // 0x12f7120: cbz             x1, #0x12f7270
    // 0x12f7124: mov             x3, x1
    // 0x12f7128: stur            x3, [fp, #-0x58]
    // 0x12f712c: r1 = <Never>
    //     0x12f712c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f7130: r0 = Pointer()
    //     0x12f7130: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f7134: mov             x1, x0
    // 0x12f7138: ldur            x0, [fp, #-0x58]
    // 0x12f713c: StoreField: r1->field_7 = r0
    //     0x12f713c: stur            x0, [x1, #7]
    // 0x12f7140: ldur            x2, [fp, #-0x38]
    // 0x12f7144: r0 = __addRRect$Method$FfiNative()
    //     0x12f7144: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x12f7148: ldur            x0, [fp, #-8]
    // 0x12f714c: b               #0x12f7154
    // 0x12f7150: r0 = Null
    //     0x12f7150: mov             x0, NULL
    // 0x12f7154: mov             x5, x0
    // 0x12f7158: b               #0x12f7228
    // 0x12f715c: ldur            x1, [fp, #-0x20]
    // 0x12f7160: r0 = center()
    //     0x12f7160: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12f7164: ldur            x1, [fp, #-0x20]
    // 0x12f7168: stur            x0, [fp, #-8]
    // 0x12f716c: r0 = shortestSide()
    //     0x12f716c: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12f7170: mov             v1.16b, v0.16b
    // 0x12f7174: d0 = 2.000000
    //     0x12f7174: fmov            d0, #2.00000000
    // 0x12f7178: fdiv            d2, d1, d0
    // 0x12f717c: fmul            d1, d2, d0
    // 0x12f7180: stur            d1, [fp, #-0x60]
    // 0x12f7184: r0 = Rect()
    //     0x12f7184: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12f7188: mov             x1, x0
    // 0x12f718c: ldur            x2, [fp, #-8]
    // 0x12f7190: ldur            d0, [fp, #-0x60]
    // 0x12f7194: ldur            d1, [fp, #-0x60]
    // 0x12f7198: stur            x0, [fp, #-8]
    // 0x12f719c: r0 = Rect.fromCenter()
    //     0x12f719c: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0x12f71a0: r0 = _NativePath()
    //     0x12f71a0: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12f71a4: mov             x1, x0
    // 0x12f71a8: stur            x0, [fp, #-0x30]
    // 0x12f71ac: r0 = __constructor$Method$FfiNative()
    //     0x12f71ac: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12f71b0: ldur            x0, [fp, #-8]
    // 0x12f71b4: LoadField: d0 = r0->field_7
    //     0x12f71b4: ldur            d0, [x0, #7]
    // 0x12f71b8: stur            d0, [fp, #-0x78]
    // 0x12f71bc: LoadField: d1 = r0->field_f
    //     0x12f71bc: ldur            d1, [x0, #0xf]
    // 0x12f71c0: stur            d1, [fp, #-0x70]
    // 0x12f71c4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12f71c4: ldur            d2, [x0, #0x17]
    // 0x12f71c8: stur            d2, [fp, #-0x68]
    // 0x12f71cc: LoadField: d3 = r0->field_1f
    //     0x12f71cc: ldur            d3, [x0, #0x1f]
    // 0x12f71d0: ldur            x0, [fp, #-0x30]
    // 0x12f71d4: stur            d3, [fp, #-0x60]
    // 0x12f71d8: LoadField: r1 = r0->field_7
    //     0x12f71d8: ldur            w1, [x0, #7]
    // 0x12f71dc: DecompressPointer r1
    //     0x12f71dc: add             x1, x1, HEAP, lsl #32
    // 0x12f71e0: cmp             w1, NULL
    // 0x12f71e4: b.eq            #0x12f72a4
    // 0x12f71e8: LoadField: r2 = r1->field_7
    //     0x12f71e8: ldur            x2, [x1, #7]
    // 0x12f71ec: ldr             x1, [x2]
    // 0x12f71f0: cbz             x1, #0x12f7280
    // 0x12f71f4: mov             x2, x1
    // 0x12f71f8: stur            x2, [fp, #-0x58]
    // 0x12f71fc: r1 = <Never>
    //     0x12f71fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f7200: r0 = Pointer()
    //     0x12f7200: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f7204: mov             x1, x0
    // 0x12f7208: ldur            x0, [fp, #-0x58]
    // 0x12f720c: StoreField: r1->field_7 = r0
    //     0x12f720c: stur            x0, [x1, #7]
    // 0x12f7210: ldur            d0, [fp, #-0x78]
    // 0x12f7214: ldur            d1, [fp, #-0x70]
    // 0x12f7218: ldur            d2, [fp, #-0x68]
    // 0x12f721c: ldur            d3, [fp, #-0x60]
    // 0x12f7220: r0 = __addOval$Method$FfiNative()
    //     0x12f7220: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0x12f7224: ldur            x5, [fp, #-0x30]
    // 0x12f7228: ldur            x0, [fp, #-0x10]
    // 0x12f722c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12f722c: ldur            w1, [x0, #0x17]
    // 0x12f7230: DecompressPointer r1
    //     0x12f7230: add             x1, x1, HEAP, lsl #32
    // 0x12f7234: cmp             w1, NULL
    // 0x12f7238: b.eq            #0x12f72a8
    // 0x12f723c: r0 = LoadClassIdInstr(r1)
    //     0x12f723c: ldur            x0, [x1, #-1]
    //     0x12f7240: ubfx            x0, x0, #0xc, #0x14
    // 0x12f7244: ldur            x2, [fp, #-0x18]
    // 0x12f7248: ldur            x3, [fp, #-0x20]
    // 0x12f724c: ldur            x6, [fp, #-0x28]
    // 0x12f7250: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x12f7250: ldr             x4, [PP, #0x1390]  ; [pp+0x1390] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x12f7254: r0 = GDT[cid_x0 + -0xfba]()
    //     0x12f7254: sub             lr, x0, #0xfba
    //     0x12f7258: ldr             lr, [x21, lr, lsl #3]
    //     0x12f725c: blr             lr
    // 0x12f7260: r0 = Null
    //     0x12f7260: mov             x0, NULL
    // 0x12f7264: LeaveFrame
    //     0x12f7264: mov             SP, fp
    //     0x12f7268: ldp             fp, lr, [SP], #0x10
    // 0x12f726c: ret
    //     0x12f726c: ret             
    // 0x12f7270: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f7270: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f7274: str             x16, [SP]
    // 0x12f7278: r0 = _throwNew()
    //     0x12f7278: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f727c: brk             #0
    // 0x12f7280: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f7280: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f7284: str             x16, [SP]
    // 0x12f7288: r0 = _throwNew()
    //     0x12f7288: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f728c: brk             #0
    // 0x12f7290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f7290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7294: b               #0x12f6e64
    // 0x12f7298: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f7298: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f729c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f729c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f72a0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f72a0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f72a4: r0 = NullErrorSharedWithFPURegs()
    //     0x12f72a4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f72a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f72a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintBackgroundColor(/* No info */) {
    // ** addr: 0x12f72ac, size: 0xb0
    // 0x12f72ac: EnterFrame
    //     0x12f72ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12f72b0: mov             fp, SP
    // 0x12f72b4: AllocStack(0x20)
    //     0x12f72b4: sub             SP, SP, #0x20
    // 0x12f72b8: SetupParameters(_BoxDecorationPainter this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */)
    //     0x12f72b8: mov             x0, x3
    //     0x12f72bc: stur            x3, [fp, #-0x18]
    //     0x12f72c0: mov             x3, x5
    //     0x12f72c4: stur            x5, [fp, #-0x20]
    //     0x12f72c8: mov             x5, x1
    //     0x12f72cc: mov             x4, x2
    //     0x12f72d0: stur            x1, [fp, #-8]
    //     0x12f72d4: stur            x2, [fp, #-0x10]
    // 0x12f72d8: CheckStackOverflow
    //     0x12f72d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f72dc: cmp             SP, x16
    //     0x12f72e0: b.ls            #0x12f7354
    // 0x12f72e4: LoadField: r1 = r5->field_b
    //     0x12f72e4: ldur            w1, [x5, #0xb]
    // 0x12f72e8: DecompressPointer r1
    //     0x12f72e8: add             x1, x1, HEAP, lsl #32
    // 0x12f72ec: LoadField: r2 = r1->field_7
    //     0x12f72ec: ldur            w2, [x1, #7]
    // 0x12f72f0: DecompressPointer r2
    //     0x12f72f0: add             x2, x2, HEAP, lsl #32
    // 0x12f72f4: cmp             w2, NULL
    // 0x12f72f8: b.ne            #0x12f730c
    // 0x12f72fc: LoadField: r2 = r1->field_1b
    //     0x12f72fc: ldur            w2, [x1, #0x1b]
    // 0x12f7300: DecompressPointer r2
    //     0x12f7300: add             x2, x2, HEAP, lsl #32
    // 0x12f7304: cmp             w2, NULL
    // 0x12f7308: b.eq            #0x12f7344
    // 0x12f730c: mov             x1, x5
    // 0x12f7310: mov             x2, x0
    // 0x12f7314: r0 = _adjustedRectOnOutlinedBorder()
    //     0x12f7314: bl              #0x12f7cfc  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_adjustedRectOnOutlinedBorder
    // 0x12f7318: ldur            x1, [fp, #-8]
    // 0x12f731c: ldur            x2, [fp, #-0x18]
    // 0x12f7320: ldur            x3, [fp, #-0x20]
    // 0x12f7324: stur            x0, [fp, #-0x18]
    // 0x12f7328: r0 = _getBackgroundPaint()
    //     0x12f7328: bl              #0x12f7588  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_getBackgroundPaint
    // 0x12f732c: ldur            x1, [fp, #-8]
    // 0x12f7330: ldur            x2, [fp, #-0x10]
    // 0x12f7334: ldur            x3, [fp, #-0x18]
    // 0x12f7338: mov             x5, x0
    // 0x12f733c: ldur            x6, [fp, #-0x20]
    // 0x12f7340: r0 = _paintBox()
    //     0x12f7340: bl              #0x12f735c  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBox
    // 0x12f7344: r0 = Null
    //     0x12f7344: mov             x0, NULL
    // 0x12f7348: LeaveFrame
    //     0x12f7348: mov             SP, fp
    //     0x12f734c: ldp             fp, lr, [SP], #0x10
    // 0x12f7350: ret
    //     0x12f7350: ret             
    // 0x12f7354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f7354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7358: b               #0x12f72e4
  }
  _ _paintBox(/* No info */) {
    // ** addr: 0x12f735c, size: 0x22c
    // 0x12f735c: EnterFrame
    //     0x12f735c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7360: mov             fp, SP
    // 0x12f7364: AllocStack(0x58)
    //     0x12f7364: sub             SP, SP, #0x58
    // 0x12f7368: SetupParameters(_BoxDecorationPainter this /* r1 => r0 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */)
    //     0x12f7368: mov             x0, x1
    //     0x12f736c: mov             x4, x2
    //     0x12f7370: mov             x1, x3
    //     0x12f7374: stur            x3, [fp, #-0x18]
    //     0x12f7378: mov             x3, x5
    //     0x12f737c: stur            x2, [fp, #-0x10]
    //     0x12f7380: mov             x2, x6
    //     0x12f7384: stur            x5, [fp, #-0x20]
    //     0x12f7388: stur            x6, [fp, #-0x28]
    // 0x12f738c: CheckStackOverflow
    //     0x12f738c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f7390: cmp             SP, x16
    //     0x12f7394: b.ls            #0x12f757c
    // 0x12f7398: LoadField: r5 = r0->field_b
    //     0x12f7398: ldur            w5, [x0, #0xb]
    // 0x12f739c: DecompressPointer r5
    //     0x12f739c: add             x5, x5, HEAP, lsl #32
    // 0x12f73a0: LoadField: r0 = r5->field_23
    //     0x12f73a0: ldur            w0, [x5, #0x23]
    // 0x12f73a4: DecompressPointer r0
    //     0x12f73a4: add             x0, x0, HEAP, lsl #32
    // 0x12f73a8: LoadField: r6 = r0->field_7
    //     0x12f73a8: ldur            x6, [x0, #7]
    // 0x12f73ac: cmp             x6, #0
    // 0x12f73b0: b.gt            #0x12f7538
    // 0x12f73b4: LoadField: r6 = r5->field_13
    //     0x12f73b4: ldur            w6, [x5, #0x13]
    // 0x12f73b8: DecompressPointer r6
    //     0x12f73b8: add             x6, x6, HEAP, lsl #32
    // 0x12f73bc: stur            x6, [fp, #-8]
    // 0x12f73c0: cmp             w6, NULL
    // 0x12f73c4: b.eq            #0x12f73ec
    // 0x12f73c8: r0 = LoadClassIdInstr(r6)
    //     0x12f73c8: ldur            x0, [x6, #-1]
    //     0x12f73cc: ubfx            x0, x0, #0xc, #0x14
    // 0x12f73d0: r16 = Instance_BorderRadius
    //     0x12f73d0: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12f73d4: ldr             x16, [x16, #0x508]
    // 0x12f73d8: stp             x16, x6, [SP]
    // 0x12f73dc: mov             lr, x0
    // 0x12f73e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12f73e4: blr             lr
    // 0x12f73e8: tbnz            w0, #4, #0x12f7400
    // 0x12f73ec: ldur            x1, [fp, #-0x10]
    // 0x12f73f0: ldur            x2, [fp, #-0x18]
    // 0x12f73f4: ldur            x3, [fp, #-0x20]
    // 0x12f73f8: r0 = drawRect()
    //     0x12f73f8: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12f73fc: b               #0x12f756c
    // 0x12f7400: ldur            x0, [fp, #-8]
    // 0x12f7404: r1 = LoadClassIdInstr(r0)
    //     0x12f7404: ldur            x1, [x0, #-1]
    //     0x12f7408: ubfx            x1, x1, #0xc, #0x14
    // 0x12f740c: cmp             x1, #0xb88
    // 0x12f7410: b.ne            #0x12f74e4
    // 0x12f7414: ldur            x2, [fp, #-0x28]
    // 0x12f7418: cmp             w2, NULL
    // 0x12f741c: b.eq            #0x12f7584
    // 0x12f7420: LoadField: r1 = r2->field_7
    //     0x12f7420: ldur            x1, [x2, #7]
    // 0x12f7424: cmp             x1, #0
    // 0x12f7428: b.gt            #0x12f7488
    // 0x12f742c: LoadField: r1 = r0->field_b
    //     0x12f742c: ldur            w1, [x0, #0xb]
    // 0x12f7430: DecompressPointer r1
    //     0x12f7430: add             x1, x1, HEAP, lsl #32
    // 0x12f7434: stur            x1, [fp, #-0x48]
    // 0x12f7438: LoadField: r2 = r0->field_7
    //     0x12f7438: ldur            w2, [x0, #7]
    // 0x12f743c: DecompressPointer r2
    //     0x12f743c: add             x2, x2, HEAP, lsl #32
    // 0x12f7440: stur            x2, [fp, #-0x40]
    // 0x12f7444: LoadField: r3 = r0->field_13
    //     0x12f7444: ldur            w3, [x0, #0x13]
    // 0x12f7448: DecompressPointer r3
    //     0x12f7448: add             x3, x3, HEAP, lsl #32
    // 0x12f744c: stur            x3, [fp, #-0x38]
    // 0x12f7450: LoadField: r4 = r0->field_f
    //     0x12f7450: ldur            w4, [x0, #0xf]
    // 0x12f7454: DecompressPointer r4
    //     0x12f7454: add             x4, x4, HEAP, lsl #32
    // 0x12f7458: stur            x4, [fp, #-0x30]
    // 0x12f745c: r0 = BorderRadius()
    //     0x12f745c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f7460: mov             x1, x0
    // 0x12f7464: ldur            x0, [fp, #-0x48]
    // 0x12f7468: StoreField: r1->field_7 = r0
    //     0x12f7468: stur            w0, [x1, #7]
    // 0x12f746c: ldur            x0, [fp, #-0x40]
    // 0x12f7470: StoreField: r1->field_b = r0
    //     0x12f7470: stur            w0, [x1, #0xb]
    // 0x12f7474: ldur            x0, [fp, #-0x38]
    // 0x12f7478: StoreField: r1->field_f = r0
    //     0x12f7478: stur            w0, [x1, #0xf]
    // 0x12f747c: ldur            x0, [fp, #-0x30]
    // 0x12f7480: StoreField: r1->field_13 = r0
    //     0x12f7480: stur            w0, [x1, #0x13]
    // 0x12f7484: b               #0x12f751c
    // 0x12f7488: LoadField: r1 = r0->field_7
    //     0x12f7488: ldur            w1, [x0, #7]
    // 0x12f748c: DecompressPointer r1
    //     0x12f748c: add             x1, x1, HEAP, lsl #32
    // 0x12f7490: stur            x1, [fp, #-0x48]
    // 0x12f7494: LoadField: r2 = r0->field_b
    //     0x12f7494: ldur            w2, [x0, #0xb]
    // 0x12f7498: DecompressPointer r2
    //     0x12f7498: add             x2, x2, HEAP, lsl #32
    // 0x12f749c: stur            x2, [fp, #-0x40]
    // 0x12f74a0: LoadField: r3 = r0->field_f
    //     0x12f74a0: ldur            w3, [x0, #0xf]
    // 0x12f74a4: DecompressPointer r3
    //     0x12f74a4: add             x3, x3, HEAP, lsl #32
    // 0x12f74a8: stur            x3, [fp, #-0x38]
    // 0x12f74ac: LoadField: r4 = r0->field_13
    //     0x12f74ac: ldur            w4, [x0, #0x13]
    // 0x12f74b0: DecompressPointer r4
    //     0x12f74b0: add             x4, x4, HEAP, lsl #32
    // 0x12f74b4: stur            x4, [fp, #-0x30]
    // 0x12f74b8: r0 = BorderRadius()
    //     0x12f74b8: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12f74bc: mov             x1, x0
    // 0x12f74c0: ldur            x0, [fp, #-0x48]
    // 0x12f74c4: StoreField: r1->field_7 = r0
    //     0x12f74c4: stur            w0, [x1, #7]
    // 0x12f74c8: ldur            x0, [fp, #-0x40]
    // 0x12f74cc: StoreField: r1->field_b = r0
    //     0x12f74cc: stur            w0, [x1, #0xb]
    // 0x12f74d0: ldur            x0, [fp, #-0x38]
    // 0x12f74d4: StoreField: r1->field_f = r0
    //     0x12f74d4: stur            w0, [x1, #0xf]
    // 0x12f74d8: ldur            x0, [fp, #-0x30]
    // 0x12f74dc: StoreField: r1->field_13 = r0
    //     0x12f74dc: stur            w0, [x1, #0x13]
    // 0x12f74e0: b               #0x12f751c
    // 0x12f74e4: ldur            x2, [fp, #-0x28]
    // 0x12f74e8: cmp             x1, #0xb89
    // 0x12f74ec: b.ne            #0x12f74f8
    // 0x12f74f0: mov             x1, x0
    // 0x12f74f4: b               #0x12f751c
    // 0x12f74f8: r1 = LoadClassIdInstr(r0)
    //     0x12f74f8: ldur            x1, [x0, #-1]
    //     0x12f74fc: ubfx            x1, x1, #0xc, #0x14
    // 0x12f7500: mov             x16, x0
    // 0x12f7504: mov             x0, x1
    // 0x12f7508: mov             x1, x16
    // 0x12f750c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f750c: sub             lr, x0, #1, lsl #12
    //     0x12f7510: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7514: blr             lr
    // 0x12f7518: mov             x1, x0
    // 0x12f751c: ldur            x2, [fp, #-0x18]
    // 0x12f7520: r0 = toRRect()
    //     0x12f7520: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12f7524: ldur            x1, [fp, #-0x10]
    // 0x12f7528: mov             x2, x0
    // 0x12f752c: ldur            x3, [fp, #-0x20]
    // 0x12f7530: r0 = drawRRect()
    //     0x12f7530: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12f7534: b               #0x12f756c
    // 0x12f7538: ldur            x1, [fp, #-0x18]
    // 0x12f753c: r0 = center()
    //     0x12f753c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12f7540: ldur            x1, [fp, #-0x18]
    // 0x12f7544: stur            x0, [fp, #-8]
    // 0x12f7548: r0 = shortestSide()
    //     0x12f7548: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12f754c: mov             v1.16b, v0.16b
    // 0x12f7550: d0 = 2.000000
    //     0x12f7550: fmov            d0, #2.00000000
    // 0x12f7554: fdiv            d2, d1, d0
    // 0x12f7558: ldur            x1, [fp, #-0x10]
    // 0x12f755c: ldur            x2, [fp, #-8]
    // 0x12f7560: mov             v0.16b, v2.16b
    // 0x12f7564: ldur            x3, [fp, #-0x20]
    // 0x12f7568: r0 = drawCircle()
    //     0x12f7568: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12f756c: r0 = Null
    //     0x12f756c: mov             x0, NULL
    // 0x12f7570: LeaveFrame
    //     0x12f7570: mov             SP, fp
    //     0x12f7574: ldp             fp, lr, [SP], #0x10
    // 0x12f7578: ret
    //     0x12f7578: ret             
    // 0x12f757c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f757c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7580: b               #0x12f7398
    // 0x12f7584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f7584: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getBackgroundPaint(/* No info */) {
    // ** addr: 0x12f7588, size: 0x380
    // 0x12f7588: EnterFrame
    //     0x12f7588: stp             fp, lr, [SP, #-0x10]!
    //     0x12f758c: mov             fp, SP
    // 0x12f7590: AllocStack(0x70)
    //     0x12f7590: sub             SP, SP, #0x70
    // 0x12f7594: SetupParameters(_BoxDecorationPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12f7594: stur            x1, [fp, #-8]
    //     0x12f7598: stur            x2, [fp, #-0x10]
    //     0x12f759c: stur            x3, [fp, #-0x18]
    // 0x12f75a0: CheckStackOverflow
    //     0x12f75a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f75a4: cmp             SP, x16
    //     0x12f75a8: b.ls            #0x12f78f4
    // 0x12f75ac: LoadField: r0 = r1->field_f
    //     0x12f75ac: ldur            w0, [x1, #0xf]
    // 0x12f75b0: DecompressPointer r0
    //     0x12f75b0: add             x0, x0, HEAP, lsl #32
    // 0x12f75b4: cmp             w0, NULL
    // 0x12f75b8: b.ne            #0x12f75c4
    // 0x12f75bc: mov             x0, x1
    // 0x12f75c0: b               #0x12f7608
    // 0x12f75c4: LoadField: r0 = r1->field_b
    //     0x12f75c4: ldur            w0, [x1, #0xb]
    // 0x12f75c8: DecompressPointer r0
    //     0x12f75c8: add             x0, x0, HEAP, lsl #32
    // 0x12f75cc: LoadField: r4 = r0->field_1b
    //     0x12f75cc: ldur            w4, [x0, #0x1b]
    // 0x12f75d0: DecompressPointer r4
    //     0x12f75d0: add             x4, x4, HEAP, lsl #32
    // 0x12f75d4: cmp             w4, NULL
    // 0x12f75d8: b.eq            #0x12f78d8
    // 0x12f75dc: LoadField: r0 = r1->field_13
    //     0x12f75dc: ldur            w0, [x1, #0x13]
    // 0x12f75e0: DecompressPointer r0
    //     0x12f75e0: add             x0, x0, HEAP, lsl #32
    // 0x12f75e4: r4 = LoadClassIdInstr(r0)
    //     0x12f75e4: ldur            x4, [x0, #-1]
    //     0x12f75e8: ubfx            x4, x4, #0xc, #0x14
    // 0x12f75ec: stp             x2, x0, [SP]
    // 0x12f75f0: mov             x0, x4
    // 0x12f75f4: mov             lr, x0
    // 0x12f75f8: ldr             lr, [x21, lr, lsl #3]
    // 0x12f75fc: blr             lr
    // 0x12f7600: tbz             w0, #4, #0x12f78d4
    // 0x12f7604: ldur            x0, [fp, #-8]
    // 0x12f7608: r16 = 136
    //     0x12f7608: mov             x16, #0x88
    // 0x12f760c: stp             x16, NULL, [SP]
    // 0x12f7610: r0 = ByteData()
    //     0x12f7610: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f7614: stur            x0, [fp, #-0x20]
    // 0x12f7618: r0 = Paint()
    //     0x12f7618: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f761c: mov             x3, x0
    // 0x12f7620: ldur            x0, [fp, #-0x20]
    // 0x12f7624: stur            x3, [fp, #-0x28]
    // 0x12f7628: StoreField: r3->field_7 = r0
    //     0x12f7628: stur            w0, [x3, #7]
    // 0x12f762c: ldur            x0, [fp, #-8]
    // 0x12f7630: LoadField: r4 = r0->field_b
    //     0x12f7630: ldur            w4, [x0, #0xb]
    // 0x12f7634: DecompressPointer r4
    //     0x12f7634: add             x4, x4, HEAP, lsl #32
    // 0x12f7638: stur            x4, [fp, #-0x20]
    // 0x12f763c: LoadField: r2 = r4->field_7
    //     0x12f763c: ldur            w2, [x4, #7]
    // 0x12f7640: DecompressPointer r2
    //     0x12f7640: add             x2, x2, HEAP, lsl #32
    // 0x12f7644: cmp             w2, NULL
    // 0x12f7648: b.eq            #0x12f7654
    // 0x12f764c: mov             x1, x3
    // 0x12f7650: r0 = color=()
    //     0x12f7650: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f7654: ldur            x0, [fp, #-0x20]
    // 0x12f7658: LoadField: r1 = r0->field_1b
    //     0x12f7658: ldur            w1, [x0, #0x1b]
    // 0x12f765c: DecompressPointer r1
    //     0x12f765c: add             x1, x1, HEAP, lsl #32
    // 0x12f7660: stur            x1, [fp, #-0x30]
    // 0x12f7664: cmp             w1, NULL
    // 0x12f7668: b.eq            #0x12f78ac
    // 0x12f766c: r0 = LoadClassIdInstr(r1)
    //     0x12f766c: ldur            x0, [x1, #-1]
    //     0x12f7670: ubfx            x0, x0, #0xc, #0x14
    // 0x12f7674: cmp             x0, #0xb73
    // 0x12f7678: b.ne            #0x12f781c
    // 0x12f767c: LoadField: r0 = r1->field_13
    //     0x12f767c: ldur            w0, [x1, #0x13]
    // 0x12f7680: DecompressPointer r0
    //     0x12f7680: add             x0, x0, HEAP, lsl #32
    // 0x12f7684: r2 = LoadClassIdInstr(r0)
    //     0x12f7684: ldur            x2, [x0, #-1]
    //     0x12f7688: ubfx            x2, x2, #0xc, #0x14
    // 0x12f768c: sub             x16, x2, #0xb8e
    // 0x12f7690: cmp             x16, #1
    // 0x12f7694: b.hi            #0x12f76a8
    // 0x12f7698: mov             x16, x1
    // 0x12f769c: mov             x1, x0
    // 0x12f76a0: mov             x0, x16
    // 0x12f76a4: b               #0x12f77a0
    // 0x12f76a8: cmp             x2, #0xb8c
    // 0x12f76ac: b.ne            #0x12f7730
    // 0x12f76b0: ldur            x2, [fp, #-0x18]
    // 0x12f76b4: cmp             w2, NULL
    // 0x12f76b8: b.eq            #0x12f78fc
    // 0x12f76bc: LoadField: r3 = r2->field_7
    //     0x12f76bc: ldur            x3, [x2, #7]
    // 0x12f76c0: cmp             x3, #0
    // 0x12f76c4: b.gt            #0x12f76f8
    // 0x12f76c8: LoadField: d0 = r0->field_7
    //     0x12f76c8: ldur            d0, [x0, #7]
    // 0x12f76cc: LoadField: d1 = r0->field_f
    //     0x12f76cc: ldur            d1, [x0, #0xf]
    // 0x12f76d0: fsub            d2, d0, d1
    // 0x12f76d4: stur            d2, [fp, #-0x58]
    // 0x12f76d8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f76d8: ldur            d0, [x0, #0x17]
    // 0x12f76dc: stur            d0, [fp, #-0x50]
    // 0x12f76e0: r0 = Alignment()
    //     0x12f76e0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f76e4: ldur            d0, [fp, #-0x58]
    // 0x12f76e8: StoreField: r0->field_7 = d0
    //     0x12f76e8: stur            d0, [x0, #7]
    // 0x12f76ec: ldur            d0, [fp, #-0x50]
    // 0x12f76f0: StoreField: r0->field_f = d0
    //     0x12f76f0: stur            d0, [x0, #0xf]
    // 0x12f76f4: b               #0x12f7724
    // 0x12f76f8: LoadField: d0 = r0->field_7
    //     0x12f76f8: ldur            d0, [x0, #7]
    // 0x12f76fc: LoadField: d1 = r0->field_f
    //     0x12f76fc: ldur            d1, [x0, #0xf]
    // 0x12f7700: fadd            d2, d0, d1
    // 0x12f7704: stur            d2, [fp, #-0x58]
    // 0x12f7708: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f7708: ldur            d0, [x0, #0x17]
    // 0x12f770c: stur            d0, [fp, #-0x50]
    // 0x12f7710: r0 = Alignment()
    //     0x12f7710: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f7714: ldur            d0, [fp, #-0x58]
    // 0x12f7718: StoreField: r0->field_7 = d0
    //     0x12f7718: stur            d0, [x0, #7]
    // 0x12f771c: ldur            d0, [fp, #-0x50]
    // 0x12f7720: StoreField: r0->field_f = d0
    //     0x12f7720: stur            d0, [x0, #0xf]
    // 0x12f7724: mov             x1, x0
    // 0x12f7728: ldur            x0, [fp, #-0x30]
    // 0x12f772c: b               #0x12f77a0
    // 0x12f7730: ldur            x2, [fp, #-0x18]
    // 0x12f7734: cmp             w2, NULL
    // 0x12f7738: b.eq            #0x12f7900
    // 0x12f773c: LoadField: r1 = r2->field_7
    //     0x12f773c: ldur            x1, [x2, #7]
    // 0x12f7740: cmp             x1, #0
    // 0x12f7744: b.gt            #0x12f7774
    // 0x12f7748: LoadField: d0 = r0->field_7
    //     0x12f7748: ldur            d0, [x0, #7]
    // 0x12f774c: fneg            d1, d0
    // 0x12f7750: stur            d1, [fp, #-0x58]
    // 0x12f7754: LoadField: d0 = r0->field_f
    //     0x12f7754: ldur            d0, [x0, #0xf]
    // 0x12f7758: stur            d0, [fp, #-0x50]
    // 0x12f775c: r0 = Alignment()
    //     0x12f775c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f7760: ldur            d0, [fp, #-0x58]
    // 0x12f7764: StoreField: r0->field_7 = d0
    //     0x12f7764: stur            d0, [x0, #7]
    // 0x12f7768: ldur            d0, [fp, #-0x50]
    // 0x12f776c: StoreField: r0->field_f = d0
    //     0x12f776c: stur            d0, [x0, #0xf]
    // 0x12f7770: b               #0x12f7798
    // 0x12f7774: LoadField: d0 = r0->field_7
    //     0x12f7774: ldur            d0, [x0, #7]
    // 0x12f7778: stur            d0, [fp, #-0x58]
    // 0x12f777c: LoadField: d1 = r0->field_f
    //     0x12f777c: ldur            d1, [x0, #0xf]
    // 0x12f7780: stur            d1, [fp, #-0x50]
    // 0x12f7784: r0 = Alignment()
    //     0x12f7784: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12f7788: ldur            d0, [fp, #-0x58]
    // 0x12f778c: StoreField: r0->field_7 = d0
    //     0x12f778c: stur            d0, [x0, #7]
    // 0x12f7790: ldur            d0, [fp, #-0x50]
    // 0x12f7794: StoreField: r0->field_f = d0
    //     0x12f7794: stur            d0, [x0, #0xf]
    // 0x12f7798: mov             x1, x0
    // 0x12f779c: ldur            x0, [fp, #-0x30]
    // 0x12f77a0: ldur            x2, [fp, #-0x10]
    // 0x12f77a4: r0 = withinRect()
    //     0x12f77a4: bl              #0x12f7c84  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0x12f77a8: mov             x2, x0
    // 0x12f77ac: ldur            x0, [fp, #-0x30]
    // 0x12f77b0: stur            x2, [fp, #-0x38]
    // 0x12f77b4: LoadField: r3 = r0->field_7
    //     0x12f77b4: ldur            w3, [x0, #7]
    // 0x12f77b8: DecompressPointer r3
    //     0x12f77b8: add             x3, x3, HEAP, lsl #32
    // 0x12f77bc: mov             x1, x0
    // 0x12f77c0: stur            x3, [fp, #-0x20]
    // 0x12f77c4: r0 = _impliedStops()
    //     0x12f77c4: bl              #0x1162204  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0x12f77c8: ldur            x1, [fp, #-0x30]
    // 0x12f77cc: stur            x0, [fp, #-0x40]
    // 0x12f77d0: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x12f77d0: ldur            d0, [x1, #0x17]
    // 0x12f77d4: stur            d0, [fp, #-0x58]
    // 0x12f77d8: LoadField: d1 = r1->field_1f
    //     0x12f77d8: ldur            d1, [x1, #0x1f]
    // 0x12f77dc: ldur            x2, [fp, #-0x10]
    // 0x12f77e0: stur            d1, [fp, #-0x50]
    // 0x12f77e4: r0 = _resolveTransform()
    //     0x12f77e4: bl              #0x12f7c18  ; [package:flutter/src/painting/gradient.dart] Gradient::_resolveTransform
    // 0x12f77e8: stur            x0, [fp, #-0x48]
    // 0x12f77ec: r0 = Gradient()
    //     0x12f77ec: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x12f77f0: mov             x1, x0
    // 0x12f77f4: ldur            x2, [fp, #-0x38]
    // 0x12f77f8: ldur            x3, [fp, #-0x20]
    // 0x12f77fc: ldur            x5, [fp, #-0x40]
    // 0x12f7800: ldur            d0, [fp, #-0x58]
    // 0x12f7804: ldur            d1, [fp, #-0x50]
    // 0x12f7808: ldur            x6, [fp, #-0x48]
    // 0x12f780c: stur            x0, [fp, #-0x20]
    // 0x12f7810: r0 = Gradient.sweep()
    //     0x12f7810: bl              #0x12f7908  ; [dart:ui] Gradient::Gradient.sweep
    // 0x12f7814: ldur            x2, [fp, #-0x20]
    // 0x12f7818: b               #0x12f7848
    // 0x12f781c: ldur            x2, [fp, #-0x18]
    // 0x12f7820: r0 = LoadClassIdInstr(r1)
    //     0x12f7820: ldur            x0, [x1, #-1]
    //     0x12f7824: ubfx            x0, x0, #0xc, #0x14
    // 0x12f7828: str             x2, [SP]
    // 0x12f782c: ldur            x2, [fp, #-0x10]
    // 0x12f7830: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12f7830: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12f7834: ldr             x4, [x4, #0x638]
    // 0x12f7838: r0 = GDT[cid_x0 + -0xffe]()
    //     0x12f7838: sub             lr, x0, #0xffe
    //     0x12f783c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7840: blr             lr
    // 0x12f7844: mov             x2, x0
    // 0x12f7848: ldur            x0, [fp, #-8]
    // 0x12f784c: ldur            x1, [fp, #-0x28]
    // 0x12f7850: stur            x2, [fp, #-0x18]
    // 0x12f7854: r0 = _ensureObjectsInitialized()
    //     0x12f7854: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x12f7858: r1 = LoadClassIdInstr(r0)
    //     0x12f7858: ldur            x1, [x0, #-1]
    //     0x12f785c: ubfx            x1, x1, #0xc, #0x14
    // 0x12f7860: stp             xzr, x0, [SP, #8]
    // 0x12f7864: ldur            x16, [fp, #-0x18]
    // 0x12f7868: str             x16, [SP]
    // 0x12f786c: mov             x0, x1
    // 0x12f7870: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x12f7870: mov             x17, #0x8dc8
    //     0x12f7874: movk            x17, #1, lsl #16
    //     0x12f7878: add             lr, x0, x17
    //     0x12f787c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7880: blr             lr
    // 0x12f7884: ldur            x0, [fp, #-0x10]
    // 0x12f7888: ldur            x1, [fp, #-8]
    // 0x12f788c: StoreField: r1->field_13 = r0
    //     0x12f788c: stur            w0, [x1, #0x13]
    //     0x12f7890: ldurb           w16, [x1, #-1]
    //     0x12f7894: ldurb           w17, [x0, #-1]
    //     0x12f7898: and             x16, x17, x16, lsr #2
    //     0x12f789c: tst             x16, HEAP, lsr #32
    //     0x12f78a0: b.eq            #0x12f78a8
    //     0x12f78a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f78a8: b               #0x12f78b0
    // 0x12f78ac: ldur            x1, [fp, #-8]
    // 0x12f78b0: ldur            x0, [fp, #-0x28]
    // 0x12f78b4: StoreField: r1->field_f = r0
    //     0x12f78b4: stur            w0, [x1, #0xf]
    //     0x12f78b8: ldurb           w16, [x1, #-1]
    //     0x12f78bc: ldurb           w17, [x0, #-1]
    //     0x12f78c0: and             x16, x17, x16, lsr #2
    //     0x12f78c4: tst             x16, HEAP, lsr #32
    //     0x12f78c8: b.eq            #0x12f78d0
    //     0x12f78cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f78d0: b               #0x12f78d8
    // 0x12f78d4: ldur            x1, [fp, #-8]
    // 0x12f78d8: LoadField: r0 = r1->field_f
    //     0x12f78d8: ldur            w0, [x1, #0xf]
    // 0x12f78dc: DecompressPointer r0
    //     0x12f78dc: add             x0, x0, HEAP, lsl #32
    // 0x12f78e0: cmp             w0, NULL
    // 0x12f78e4: b.eq            #0x12f7904
    // 0x12f78e8: LeaveFrame
    //     0x12f78e8: mov             SP, fp
    //     0x12f78ec: ldp             fp, lr, [SP], #0x10
    // 0x12f78f0: ret
    //     0x12f78f0: ret             
    // 0x12f78f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f78f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f78f8: b               #0x12f75ac
    // 0x12f78fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f78fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f7900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f7900: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f7904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f7904: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _adjustedRectOnOutlinedBorder(/* No info */) {
    // ** addr: 0x12f7cfc, size: 0x15c
    // 0x12f7cfc: EnterFrame
    //     0x12f7cfc: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7d00: mov             fp, SP
    // 0x12f7d04: AllocStack(0x38)
    //     0x12f7d04: sub             SP, SP, #0x38
    // 0x12f7d08: SetupParameters(_BoxDecorationPainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x12f7d08: mov             x3, x1
    //     0x12f7d0c: mov             x0, x2
    //     0x12f7d10: stur            x1, [fp, #-0x10]
    //     0x12f7d14: stur            x2, [fp, #-0x18]
    // 0x12f7d18: CheckStackOverflow
    //     0x12f7d18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f7d1c: cmp             SP, x16
    //     0x12f7d20: b.ls            #0x12f7e50
    // 0x12f7d24: LoadField: r1 = r3->field_b
    //     0x12f7d24: ldur            w1, [x3, #0xb]
    // 0x12f7d28: DecompressPointer r1
    //     0x12f7d28: add             x1, x1, HEAP, lsl #32
    // 0x12f7d2c: LoadField: r4 = r1->field_f
    //     0x12f7d2c: ldur            w4, [x1, #0xf]
    // 0x12f7d30: DecompressPointer r4
    //     0x12f7d30: add             x4, x4, HEAP, lsl #32
    // 0x12f7d34: stur            x4, [fp, #-8]
    // 0x12f7d38: cmp             w4, NULL
    // 0x12f7d3c: b.ne            #0x12f7d4c
    // 0x12f7d40: LeaveFrame
    //     0x12f7d40: mov             SP, fp
    //     0x12f7d44: ldp             fp, lr, [SP], #0x10
    // 0x12f7d48: ret
    //     0x12f7d48: ret             
    // 0x12f7d4c: LoadField: r2 = r4->field_13
    //     0x12f7d4c: ldur            w2, [x4, #0x13]
    // 0x12f7d50: DecompressPointer r2
    //     0x12f7d50: add             x2, x2, HEAP, lsl #32
    // 0x12f7d54: mov             x1, x3
    // 0x12f7d58: r0 = _calculateAdjustedSide()
    //     0x12f7d58: bl              #0x12f7ec8  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_calculateAdjustedSide
    // 0x12f7d5c: ldur            x0, [fp, #-8]
    // 0x12f7d60: stur            d0, [fp, #-0x20]
    // 0x12f7d64: LoadField: r2 = r0->field_7
    //     0x12f7d64: ldur            w2, [x0, #7]
    // 0x12f7d68: DecompressPointer r2
    //     0x12f7d68: add             x2, x2, HEAP, lsl #32
    // 0x12f7d6c: ldur            x1, [fp, #-0x10]
    // 0x12f7d70: r0 = _calculateAdjustedSide()
    //     0x12f7d70: bl              #0x12f7ec8  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_calculateAdjustedSide
    // 0x12f7d74: ldur            x0, [fp, #-8]
    // 0x12f7d78: stur            d0, [fp, #-0x28]
    // 0x12f7d7c: LoadField: r2 = r0->field_b
    //     0x12f7d7c: ldur            w2, [x0, #0xb]
    // 0x12f7d80: DecompressPointer r2
    //     0x12f7d80: add             x2, x2, HEAP, lsl #32
    // 0x12f7d84: ldur            x1, [fp, #-0x10]
    // 0x12f7d88: r0 = _calculateAdjustedSide()
    //     0x12f7d88: bl              #0x12f7ec8  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_calculateAdjustedSide
    // 0x12f7d8c: ldur            x0, [fp, #-8]
    // 0x12f7d90: stur            d0, [fp, #-0x30]
    // 0x12f7d94: LoadField: r2 = r0->field_f
    //     0x12f7d94: ldur            w2, [x0, #0xf]
    // 0x12f7d98: DecompressPointer r2
    //     0x12f7d98: add             x2, x2, HEAP, lsl #32
    // 0x12f7d9c: ldur            x1, [fp, #-0x10]
    // 0x12f7da0: r0 = _calculateAdjustedSide()
    //     0x12f7da0: bl              #0x12f7ec8  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_calculateAdjustedSide
    // 0x12f7da4: stur            d0, [fp, #-0x38]
    // 0x12f7da8: r0 = EdgeInsets()
    //     0x12f7da8: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f7dac: ldur            d0, [fp, #-0x20]
    // 0x12f7db0: StoreField: r0->field_7 = d0
    //     0x12f7db0: stur            d0, [x0, #7]
    // 0x12f7db4: ldur            d0, [fp, #-0x28]
    // 0x12f7db8: StoreField: r0->field_f = d0
    //     0x12f7db8: stur            d0, [x0, #0xf]
    // 0x12f7dbc: ldur            d0, [fp, #-0x30]
    // 0x12f7dc0: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f7dc0: stur            d0, [x0, #0x17]
    // 0x12f7dc4: ldur            d0, [fp, #-0x38]
    // 0x12f7dc8: StoreField: r0->field_1f = d0
    //     0x12f7dc8: stur            d0, [x0, #0x1f]
    // 0x12f7dcc: mov             x1, x0
    // 0x12f7dd0: d0 = 2.000000
    //     0x12f7dd0: fmov            d0, #2.00000000
    // 0x12f7dd4: r0 = /()
    //     0x12f7dd4: bl              #0x12f7e58  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::/
    // 0x12f7dd8: mov             x1, x0
    // 0x12f7ddc: ldur            x0, [fp, #-0x18]
    // 0x12f7de0: LoadField: d0 = r0->field_7
    //     0x12f7de0: ldur            d0, [x0, #7]
    // 0x12f7de4: LoadField: d1 = r1->field_7
    //     0x12f7de4: ldur            d1, [x1, #7]
    // 0x12f7de8: fadd            d2, d0, d1
    // 0x12f7dec: stur            d2, [fp, #-0x38]
    // 0x12f7df0: LoadField: d0 = r0->field_f
    //     0x12f7df0: ldur            d0, [x0, #0xf]
    // 0x12f7df4: LoadField: d1 = r1->field_f
    //     0x12f7df4: ldur            d1, [x1, #0xf]
    // 0x12f7df8: fadd            d3, d0, d1
    // 0x12f7dfc: stur            d3, [fp, #-0x30]
    // 0x12f7e00: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f7e00: ldur            d0, [x0, #0x17]
    // 0x12f7e04: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x12f7e04: ldur            d1, [x1, #0x17]
    // 0x12f7e08: fsub            d4, d0, d1
    // 0x12f7e0c: stur            d4, [fp, #-0x28]
    // 0x12f7e10: LoadField: d0 = r0->field_1f
    //     0x12f7e10: ldur            d0, [x0, #0x1f]
    // 0x12f7e14: LoadField: d1 = r1->field_1f
    //     0x12f7e14: ldur            d1, [x1, #0x1f]
    // 0x12f7e18: fsub            d5, d0, d1
    // 0x12f7e1c: stur            d5, [fp, #-0x20]
    // 0x12f7e20: r0 = Rect()
    //     0x12f7e20: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12f7e24: ldur            d0, [fp, #-0x38]
    // 0x12f7e28: StoreField: r0->field_7 = d0
    //     0x12f7e28: stur            d0, [x0, #7]
    // 0x12f7e2c: ldur            d0, [fp, #-0x30]
    // 0x12f7e30: StoreField: r0->field_f = d0
    //     0x12f7e30: stur            d0, [x0, #0xf]
    // 0x12f7e34: ldur            d0, [fp, #-0x28]
    // 0x12f7e38: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f7e38: stur            d0, [x0, #0x17]
    // 0x12f7e3c: ldur            d0, [fp, #-0x20]
    // 0x12f7e40: StoreField: r0->field_1f = d0
    //     0x12f7e40: stur            d0, [x0, #0x1f]
    // 0x12f7e44: LeaveFrame
    //     0x12f7e44: mov             SP, fp
    //     0x12f7e48: ldp             fp, lr, [SP], #0x10
    // 0x12f7e4c: ret
    //     0x12f7e4c: ret             
    // 0x12f7e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f7e50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7e54: b               #0x12f7d24
  }
  _ _calculateAdjustedSide(/* No info */) {
    // ** addr: 0x12f7ec8, size: 0xa0
    // 0x12f7ec8: EnterFrame
    //     0x12f7ec8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7ecc: mov             fp, SP
    // 0x12f7ed0: AllocStack(0x8)
    //     0x12f7ed0: sub             SP, SP, #8
    // 0x12f7ed4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x12f7ed4: stur            x2, [fp, #-8]
    // 0x12f7ed8: CheckStackOverflow
    //     0x12f7ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f7edc: cmp             SP, x16
    //     0x12f7ee0: b.ls            #0x12f7f60
    // 0x12f7ee4: LoadField: r1 = r2->field_7
    //     0x12f7ee4: ldur            w1, [x2, #7]
    // 0x12f7ee8: DecompressPointer r1
    //     0x12f7ee8: add             x1, x1, HEAP, lsl #32
    // 0x12f7eec: r0 = LoadClassIdInstr(r1)
    //     0x12f7eec: ldur            x0, [x1, #-1]
    //     0x12f7ef0: ubfx            x0, x0, #0xc, #0x14
    // 0x12f7ef4: r0 = GDT[cid_x0 + -0xfc0]()
    //     0x12f7ef4: sub             lr, x0, #0xfc0
    //     0x12f7ef8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7efc: blr             lr
    // 0x12f7f00: cmp             x0, #0xff
    // 0x12f7f04: b.ne            #0x12f7f50
    // 0x12f7f08: ldur            x0, [fp, #-8]
    // 0x12f7f0c: LoadField: r1 = r0->field_13
    //     0x12f7f0c: ldur            w1, [x0, #0x13]
    // 0x12f7f10: DecompressPointer r1
    //     0x12f7f10: add             x1, x1, HEAP, lsl #32
    // 0x12f7f14: r16 = Instance_BorderStyle
    //     0x12f7f14: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12f7f18: ldr             x16, [x16, #0xdc8]
    // 0x12f7f1c: cmp             w1, w16
    // 0x12f7f20: b.ne            #0x12f7f50
    // 0x12f7f24: d2 = 1.000000
    //     0x12f7f24: fmov            d2, #1.00000000
    // 0x12f7f28: d1 = 2.000000
    //     0x12f7f28: fmov            d1, #2.00000000
    // 0x12f7f2c: LoadField: d3 = r0->field_b
    //     0x12f7f2c: ldur            d3, [x0, #0xb]
    // 0x12f7f30: ArrayLoad: d4 = r0[0]  ; List_8
    //     0x12f7f30: ldur            d4, [x0, #0x17]
    // 0x12f7f34: fadd            d5, d4, d2
    // 0x12f7f38: fdiv            d4, d5, d1
    // 0x12f7f3c: fsub            d1, d2, d4
    // 0x12f7f40: fmul            d0, d3, d1
    // 0x12f7f44: LeaveFrame
    //     0x12f7f44: mov             SP, fp
    //     0x12f7f48: ldp             fp, lr, [SP], #0x10
    // 0x12f7f4c: ret
    //     0x12f7f4c: ret             
    // 0x12f7f50: d0 = 0.000000
    //     0x12f7f50: eor             v0.16b, v0.16b, v0.16b
    // 0x12f7f54: LeaveFrame
    //     0x12f7f54: mov             SP, fp
    //     0x12f7f58: ldp             fp, lr, [SP], #0x10
    // 0x12f7f5c: ret
    //     0x12f7f5c: ret             
    // 0x12f7f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f7f60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f7f64: b               #0x12f7ee4
  }
  _ _paintShadows(/* No info */) {
    // ** addr: 0x12f7f68, size: 0x25c
    // 0x12f7f68: EnterFrame
    //     0x12f7f68: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7f6c: mov             fp, SP
    // 0x12f7f70: AllocStack(0x88)
    //     0x12f7f70: sub             SP, SP, #0x88
    // 0x12f7f74: SetupParameters(_BoxDecorationPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r6, fp-0x20 */)
    //     0x12f7f74: mov             x4, x1
    //     0x12f7f78: mov             x6, x5
    //     0x12f7f7c: stur            x1, [fp, #-8]
    //     0x12f7f80: stur            x2, [fp, #-0x10]
    //     0x12f7f84: stur            x3, [fp, #-0x18]
    //     0x12f7f88: stur            x5, [fp, #-0x20]
    // 0x12f7f8c: CheckStackOverflow
    //     0x12f7f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f7f90: cmp             SP, x16
    //     0x12f7f94: b.ls            #0x12f81b4
    // 0x12f7f98: LoadField: r0 = r4->field_b
    //     0x12f7f98: ldur            w0, [x4, #0xb]
    // 0x12f7f9c: DecompressPointer r0
    //     0x12f7f9c: add             x0, x0, HEAP, lsl #32
    // 0x12f7fa0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12f7fa0: ldur            w1, [x0, #0x17]
    // 0x12f7fa4: DecompressPointer r1
    //     0x12f7fa4: add             x1, x1, HEAP, lsl #32
    // 0x12f7fa8: cmp             w1, NULL
    // 0x12f7fac: b.ne            #0x12f7fc0
    // 0x12f7fb0: r0 = Null
    //     0x12f7fb0: mov             x0, NULL
    // 0x12f7fb4: LeaveFrame
    //     0x12f7fb4: mov             SP, fp
    //     0x12f7fb8: ldp             fp, lr, [SP], #0x10
    // 0x12f7fbc: ret
    //     0x12f7fbc: ret             
    // 0x12f7fc0: r0 = LoadClassIdInstr(r1)
    //     0x12f7fc0: ldur            x0, [x1, #-1]
    //     0x12f7fc4: ubfx            x0, x0, #0xc, #0x14
    // 0x12f7fc8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12f7fc8: mov             x17, #0x2641
    //     0x12f7fcc: movk            x17, #1, lsl #16
    //     0x12f7fd0: add             lr, x0, x17
    //     0x12f7fd4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f7fd8: blr             lr
    // 0x12f7fdc: mov             x2, x0
    // 0x12f7fe0: ldur            x0, [fp, #-0x18]
    // 0x12f7fe4: stur            x2, [fp, #-0x28]
    // 0x12f7fe8: LoadField: d0 = r0->field_7
    //     0x12f7fe8: ldur            d0, [x0, #7]
    // 0x12f7fec: stur            d0, [fp, #-0x58]
    // 0x12f7ff0: LoadField: d1 = r0->field_f
    //     0x12f7ff0: ldur            d1, [x0, #0xf]
    // 0x12f7ff4: stur            d1, [fp, #-0x50]
    // 0x12f7ff8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12f7ff8: ldur            d2, [x0, #0x17]
    // 0x12f7ffc: stur            d2, [fp, #-0x48]
    // 0x12f8000: LoadField: d3 = r0->field_1f
    //     0x12f8000: ldur            d3, [x0, #0x1f]
    // 0x12f8004: stur            d3, [fp, #-0x40]
    // 0x12f8008: CheckStackOverflow
    //     0x12f8008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f800c: cmp             SP, x16
    //     0x12f8010: b.ls            #0x12f81bc
    // 0x12f8014: r0 = LoadClassIdInstr(r2)
    //     0x12f8014: ldur            x0, [x2, #-1]
    //     0x12f8018: ubfx            x0, x0, #0xc, #0x14
    // 0x12f801c: mov             x1, x2
    // 0x12f8020: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12f8020: mov             x17, #0x845b
    //     0x12f8024: movk            x17, #1, lsl #16
    //     0x12f8028: add             lr, x0, x17
    //     0x12f802c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8030: blr             lr
    // 0x12f8034: tbnz            w0, #4, #0x12f81a4
    // 0x12f8038: ldur            x2, [fp, #-0x28]
    // 0x12f803c: r0 = LoadClassIdInstr(r2)
    //     0x12f803c: ldur            x0, [x2, #-1]
    //     0x12f8040: ubfx            x0, x0, #0xc, #0x14
    // 0x12f8044: mov             x1, x2
    // 0x12f8048: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12f8048: mov             x17, #0x7d4c
    //     0x12f804c: movk            x17, #1, lsl #16
    //     0x12f8050: add             lr, x0, x17
    //     0x12f8054: ldr             lr, [x21, lr, lsl #3]
    //     0x12f8058: blr             lr
    // 0x12f805c: stur            x0, [fp, #-0x18]
    // 0x12f8060: r16 = 136
    //     0x12f8060: mov             x16, #0x88
    // 0x12f8064: stp             x16, NULL, [SP]
    // 0x12f8068: r0 = ByteData()
    //     0x12f8068: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f806c: stur            x0, [fp, #-0x30]
    // 0x12f8070: r0 = Paint()
    //     0x12f8070: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f8074: mov             x3, x0
    // 0x12f8078: ldur            x0, [fp, #-0x30]
    // 0x12f807c: stur            x3, [fp, #-0x38]
    // 0x12f8080: StoreField: r3->field_7 = r0
    //     0x12f8080: stur            w0, [x3, #7]
    // 0x12f8084: ldur            x4, [fp, #-0x18]
    // 0x12f8088: LoadField: r2 = r4->field_7
    //     0x12f8088: ldur            w2, [x4, #7]
    // 0x12f808c: DecompressPointer r2
    //     0x12f808c: add             x2, x2, HEAP, lsl #32
    // 0x12f8090: mov             x1, x3
    // 0x12f8094: r0 = color=()
    //     0x12f8094: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f8098: ldur            x0, [fp, #-0x18]
    // 0x12f809c: LoadField: d0 = r0->field_f
    //     0x12f809c: ldur            d0, [x0, #0xf]
    // 0x12f80a0: d1 = 0.000000
    //     0x12f80a0: eor             v1.16b, v1.16b, v1.16b
    // 0x12f80a4: fcmp            d0, d1
    // 0x12f80a8: b.le            #0x12f80c4
    // 0x12f80ac: d3 = 0.577350
    //     0x12f80ac: ldr             d3, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0x12f80b0: d2 = 0.500000
    //     0x12f80b0: fmov            d2, #0.50000000
    // 0x12f80b4: fmul            d4, d0, d3
    // 0x12f80b8: fadd            d0, d4, d2
    // 0x12f80bc: mov             v7.16b, v0.16b
    // 0x12f80c0: b               #0x12f80d0
    // 0x12f80c4: d3 = 0.577350
    //     0x12f80c4: ldr             d3, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0x12f80c8: d2 = 0.500000
    //     0x12f80c8: fmov            d2, #0.50000000
    // 0x12f80cc: d7 = 0.000000
    //     0x12f80cc: eor             v7.16b, v7.16b, v7.16b
    // 0x12f80d0: ldur            d0, [fp, #-0x58]
    // 0x12f80d4: ldur            d4, [fp, #-0x50]
    // 0x12f80d8: ldur            d5, [fp, #-0x48]
    // 0x12f80dc: ldur            d6, [fp, #-0x40]
    // 0x12f80e0: ldur            x1, [fp, #-0x30]
    // 0x12f80e4: r2 = 1
    //     0x12f80e4: mov             x2, #1
    // 0x12f80e8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x12f80e8: ldur            w3, [x1, #0x17]
    // 0x12f80ec: DecompressPointer r3
    //     0x12f80ec: add             x3, x3, HEAP, lsl #32
    // 0x12f80f0: LoadField: r1 = r3->field_7
    //     0x12f80f0: ldur            x1, [x3, #7]
    // 0x12f80f4: str             w2, [x1, #0x34]
    // 0x12f80f8: LoadField: r1 = r3->field_7
    //     0x12f80f8: ldur            x1, [x3, #7]
    // 0x12f80fc: str             wzr, [x1, #0x38]
    // 0x12f8100: fcvt            s8, d7
    // 0x12f8104: LoadField: r1 = r3->field_7
    //     0x12f8104: ldur            x1, [x3, #7]
    // 0x12f8108: str             s8, [x1, #0x3c]
    // 0x12f810c: LoadField: r1 = r0->field_b
    //     0x12f810c: ldur            w1, [x0, #0xb]
    // 0x12f8110: DecompressPointer r1
    //     0x12f8110: add             x1, x1, HEAP, lsl #32
    // 0x12f8114: LoadField: d7 = r1->field_7
    //     0x12f8114: ldur            d7, [x1, #7]
    // 0x12f8118: fadd            d8, d0, d7
    // 0x12f811c: LoadField: d9 = r1->field_f
    //     0x12f811c: ldur            d9, [x1, #0xf]
    // 0x12f8120: fadd            d10, d4, d9
    // 0x12f8124: fadd            d11, d5, d7
    // 0x12f8128: fadd            d7, d6, d9
    // 0x12f812c: ArrayLoad: d9 = r0[0]  ; List_8
    //     0x12f812c: ldur            d9, [x0, #0x17]
    // 0x12f8130: fsub            d12, d8, d9
    // 0x12f8134: stur            d12, [fp, #-0x78]
    // 0x12f8138: fsub            d8, d10, d9
    // 0x12f813c: stur            d8, [fp, #-0x70]
    // 0x12f8140: fadd            d10, d11, d9
    // 0x12f8144: stur            d10, [fp, #-0x68]
    // 0x12f8148: fadd            d11, d7, d9
    // 0x12f814c: stur            d11, [fp, #-0x60]
    // 0x12f8150: r0 = Rect()
    //     0x12f8150: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12f8154: ldur            d0, [fp, #-0x78]
    // 0x12f8158: StoreField: r0->field_7 = d0
    //     0x12f8158: stur            d0, [x0, #7]
    // 0x12f815c: ldur            d0, [fp, #-0x70]
    // 0x12f8160: StoreField: r0->field_f = d0
    //     0x12f8160: stur            d0, [x0, #0xf]
    // 0x12f8164: ldur            d0, [fp, #-0x68]
    // 0x12f8168: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f8168: stur            d0, [x0, #0x17]
    // 0x12f816c: ldur            d0, [fp, #-0x60]
    // 0x12f8170: StoreField: r0->field_1f = d0
    //     0x12f8170: stur            d0, [x0, #0x1f]
    // 0x12f8174: ldur            x1, [fp, #-8]
    // 0x12f8178: ldur            x2, [fp, #-0x10]
    // 0x12f817c: mov             x3, x0
    // 0x12f8180: ldur            x5, [fp, #-0x38]
    // 0x12f8184: ldur            x6, [fp, #-0x20]
    // 0x12f8188: r0 = _paintBox()
    //     0x12f8188: bl              #0x12f735c  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBox
    // 0x12f818c: ldur            x2, [fp, #-0x28]
    // 0x12f8190: ldur            d0, [fp, #-0x58]
    // 0x12f8194: ldur            d1, [fp, #-0x50]
    // 0x12f8198: ldur            d2, [fp, #-0x48]
    // 0x12f819c: ldur            d3, [fp, #-0x40]
    // 0x12f81a0: b               #0x12f8008
    // 0x12f81a4: r0 = Null
    //     0x12f81a4: mov             x0, NULL
    // 0x12f81a8: LeaveFrame
    //     0x12f81a8: mov             SP, fp
    //     0x12f81ac: ldp             fp, lr, [SP], #0x10
    // 0x12f81b0: ret
    //     0x12f81b0: ret             
    // 0x12f81b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f81b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f81b8: b               #0x12f7f98
    // 0x12f81bc: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f81bc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f81c0: b               #0x12f8014
  }
  _ dispose(/* No info */) {
    // ** addr: 0x12f9638, size: 0x5c
    // 0x12f9638: EnterFrame
    //     0x12f9638: stp             fp, lr, [SP, #-0x10]!
    //     0x12f963c: mov             fp, SP
    // 0x12f9640: CheckStackOverflow
    //     0x12f9640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f9644: cmp             SP, x16
    //     0x12f9648: b.ls            #0x12f968c
    // 0x12f964c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12f964c: ldur            w0, [x1, #0x17]
    // 0x12f9650: DecompressPointer r0
    //     0x12f9650: add             x0, x0, HEAP, lsl #32
    // 0x12f9654: cmp             w0, NULL
    // 0x12f9658: b.eq            #0x12f967c
    // 0x12f965c: r1 = LoadClassIdInstr(r0)
    //     0x12f965c: ldur            x1, [x0, #-1]
    //     0x12f9660: ubfx            x1, x1, #0xc, #0x14
    // 0x12f9664: mov             x16, x0
    // 0x12f9668: mov             x0, x1
    // 0x12f966c: mov             x1, x16
    // 0x12f9670: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x12f9670: sub             lr, x0, #0xfb9
    //     0x12f9674: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9678: blr             lr
    // 0x12f967c: r0 = Null
    //     0x12f967c: mov             x0, NULL
    // 0x12f9680: LeaveFrame
    //     0x12f9680: mov             SP, fp
    //     0x12f9684: ldp             fp, lr, [SP], #0x10
    // 0x12f9688: ret
    //     0x12f9688: ret             
    // 0x12f968c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f968c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f9690: b               #0x12f964c
  }
}

// class id: 5238, size: 0x28, field offset: 0x8
//   const constructor, 
class BoxDecoration extends Decoration {

  DecorationImage field_c;
  BoxShape field_24;
  Color field_8;
  SweepGradient field_1c;
  Border field_10;
  BorderRadius field_14;

  _ copyWith(/* No info */) {
    // ** addr: 0xe3723c, size: 0x218
    // 0xe3723c: EnterFrame
    //     0xe3723c: stp             fp, lr, [SP, #-0x10]!
    //     0xe37240: mov             fp, SP
    // 0xe37244: AllocStack(0x38)
    //     0xe37244: sub             SP, SP, #0x38
    // 0xe37248: SetupParameters({dynamic border = Null /* r3 */, dynamic borderRadius = Null /* r5 */, dynamic color = Null /* r6 */, dynamic image = Null /* r0 */})
    //     0xe37248: ldur            w0, [x4, #0x13]
    //     0xe3724c: ldur            w2, [x4, #0x1f]
    //     0xe37250: add             x2, x2, HEAP, lsl #32
    //     0xe37254: add             x16, PP, #0x19, lsl #12  ; [pp+0x19ee8] "border"
    //     0xe37258: ldr             x16, [x16, #0xee8]
    //     0xe3725c: cmp             w2, w16
    //     0xe37260: b.ne            #0xe37284
    //     0xe37264: ldur            w2, [x4, #0x23]
    //     0xe37268: add             x2, x2, HEAP, lsl #32
    //     0xe3726c: sub             w3, w0, w2
    //     0xe37270: add             x2, fp, w3, sxtw #2
    //     0xe37274: ldr             x2, [x2, #8]
    //     0xe37278: mov             x3, x2
    //     0xe3727c: mov             x2, #1
    //     0xe37280: b               #0xe3728c
    //     0xe37284: mov             x3, NULL
    //     0xe37288: mov             x2, #0
    //     0xe3728c: lsl             x5, x2, #1
    //     0xe37290: lsl             w6, w5, #1
    //     0xe37294: add             w7, w6, #8
    //     0xe37298: add             x16, x4, w7, sxtw #1
    //     0xe3729c: ldur            w8, [x16, #0xf]
    //     0xe372a0: add             x8, x8, HEAP, lsl #32
    //     0xe372a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d00] "borderRadius"
    //     0xe372a8: ldr             x16, [x16, #0xd00]
    //     0xe372ac: cmp             w8, w16
    //     0xe372b0: b.ne            #0xe372e4
    //     0xe372b4: add             w2, w6, #0xa
    //     0xe372b8: add             x16, x4, w2, sxtw #1
    //     0xe372bc: ldur            w6, [x16, #0xf]
    //     0xe372c0: add             x6, x6, HEAP, lsl #32
    //     0xe372c4: sub             w2, w0, w6
    //     0xe372c8: add             x6, fp, w2, sxtw #2
    //     0xe372cc: ldr             x6, [x6, #8]
    //     0xe372d0: add             w2, w5, #2
    //     0xe372d4: sbfx            x5, x2, #1, #0x1f
    //     0xe372d8: mov             x2, x5
    //     0xe372dc: mov             x5, x6
    //     0xe372e0: b               #0xe372e8
    //     0xe372e4: mov             x5, NULL
    //     0xe372e8: lsl             x6, x2, #1
    //     0xe372ec: lsl             w7, w6, #1
    //     0xe372f0: add             w8, w7, #8
    //     0xe372f4: add             x16, x4, w8, sxtw #1
    //     0xe372f8: ldur            w9, [x16, #0xf]
    //     0xe372fc: add             x9, x9, HEAP, lsl #32
    //     0xe37300: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0xe37304: cmp             w9, w16
    //     0xe37308: b.ne            #0xe3733c
    //     0xe3730c: add             w2, w7, #0xa
    //     0xe37310: add             x16, x4, w2, sxtw #1
    //     0xe37314: ldur            w7, [x16, #0xf]
    //     0xe37318: add             x7, x7, HEAP, lsl #32
    //     0xe3731c: sub             w2, w0, w7
    //     0xe37320: add             x7, fp, w2, sxtw #2
    //     0xe37324: ldr             x7, [x7, #8]
    //     0xe37328: add             w2, w6, #2
    //     0xe3732c: sbfx            x6, x2, #1, #0x1f
    //     0xe37330: mov             x2, x6
    //     0xe37334: mov             x6, x7
    //     0xe37338: b               #0xe37340
    //     0xe3733c: mov             x6, NULL
    //     0xe37340: lsl             x7, x2, #1
    //     0xe37344: lsl             w2, w7, #1
    //     0xe37348: add             w7, w2, #8
    //     0xe3734c: add             x16, x4, w7, sxtw #1
    //     0xe37350: ldur            w8, [x16, #0xf]
    //     0xe37354: add             x8, x8, HEAP, lsl #32
    //     0xe37358: ldr             x16, [PP, #0x6530]  ; [pp+0x6530] "image"
    //     0xe3735c: cmp             w8, w16
    //     0xe37360: b.ne            #0xe37384
    //     0xe37364: add             w7, w2, #0xa
    //     0xe37368: add             x16, x4, w7, sxtw #1
    //     0xe3736c: ldur            w2, [x16, #0xf]
    //     0xe37370: add             x2, x2, HEAP, lsl #32
    //     0xe37374: sub             w4, w0, w2
    //     0xe37378: add             x0, fp, w4, sxtw #2
    //     0xe3737c: ldr             x0, [x0, #8]
    //     0xe37380: b               #0xe37388
    //     0xe37384: mov             x0, NULL
    // 0xe37388: cmp             w6, NULL
    // 0xe3738c: b.ne            #0xe3739c
    // 0xe37390: LoadField: r2 = r1->field_7
    //     0xe37390: ldur            w2, [x1, #7]
    // 0xe37394: DecompressPointer r2
    //     0xe37394: add             x2, x2, HEAP, lsl #32
    // 0xe37398: b               #0xe373a0
    // 0xe3739c: mov             x2, x6
    // 0xe373a0: stur            x2, [fp, #-0x38]
    // 0xe373a4: cmp             w0, NULL
    // 0xe373a8: b.ne            #0xe373b4
    // 0xe373ac: LoadField: r0 = r1->field_b
    //     0xe373ac: ldur            w0, [x1, #0xb]
    // 0xe373b0: DecompressPointer r0
    //     0xe373b0: add             x0, x0, HEAP, lsl #32
    // 0xe373b4: stur            x0, [fp, #-0x30]
    // 0xe373b8: cmp             w3, NULL
    // 0xe373bc: b.ne            #0xe373c8
    // 0xe373c0: LoadField: r3 = r1->field_f
    //     0xe373c0: ldur            w3, [x1, #0xf]
    // 0xe373c4: DecompressPointer r3
    //     0xe373c4: add             x3, x3, HEAP, lsl #32
    // 0xe373c8: stur            x3, [fp, #-0x28]
    // 0xe373cc: cmp             w5, NULL
    // 0xe373d0: b.ne            #0xe373e0
    // 0xe373d4: LoadField: r4 = r1->field_13
    //     0xe373d4: ldur            w4, [x1, #0x13]
    // 0xe373d8: DecompressPointer r4
    //     0xe373d8: add             x4, x4, HEAP, lsl #32
    // 0xe373dc: b               #0xe373e4
    // 0xe373e0: mov             x4, x5
    // 0xe373e4: stur            x4, [fp, #-0x20]
    // 0xe373e8: ArrayLoad: r5 = r1[0]  ; List_4
    //     0xe373e8: ldur            w5, [x1, #0x17]
    // 0xe373ec: DecompressPointer r5
    //     0xe373ec: add             x5, x5, HEAP, lsl #32
    // 0xe373f0: stur            x5, [fp, #-0x18]
    // 0xe373f4: LoadField: r6 = r1->field_1b
    //     0xe373f4: ldur            w6, [x1, #0x1b]
    // 0xe373f8: DecompressPointer r6
    //     0xe373f8: add             x6, x6, HEAP, lsl #32
    // 0xe373fc: stur            x6, [fp, #-0x10]
    // 0xe37400: LoadField: r7 = r1->field_23
    //     0xe37400: ldur            w7, [x1, #0x23]
    // 0xe37404: DecompressPointer r7
    //     0xe37404: add             x7, x7, HEAP, lsl #32
    // 0xe37408: stur            x7, [fp, #-8]
    // 0xe3740c: r0 = BoxDecoration()
    //     0xe3740c: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xe37410: ldur            x1, [fp, #-0x38]
    // 0xe37414: StoreField: r0->field_7 = r1
    //     0xe37414: stur            w1, [x0, #7]
    // 0xe37418: ldur            x1, [fp, #-0x30]
    // 0xe3741c: StoreField: r0->field_b = r1
    //     0xe3741c: stur            w1, [x0, #0xb]
    // 0xe37420: ldur            x1, [fp, #-0x28]
    // 0xe37424: StoreField: r0->field_f = r1
    //     0xe37424: stur            w1, [x0, #0xf]
    // 0xe37428: ldur            x1, [fp, #-0x20]
    // 0xe3742c: StoreField: r0->field_13 = r1
    //     0xe3742c: stur            w1, [x0, #0x13]
    // 0xe37430: ldur            x1, [fp, #-0x18]
    // 0xe37434: ArrayStore: r0[0] = r1  ; List_4
    //     0xe37434: stur            w1, [x0, #0x17]
    // 0xe37438: ldur            x1, [fp, #-0x10]
    // 0xe3743c: StoreField: r0->field_1b = r1
    //     0xe3743c: stur            w1, [x0, #0x1b]
    // 0xe37440: ldur            x1, [fp, #-8]
    // 0xe37444: StoreField: r0->field_23 = r1
    //     0xe37444: stur            w1, [x0, #0x23]
    // 0xe37448: LeaveFrame
    //     0xe37448: mov             SP, fp
    //     0xe3744c: ldp             fp, lr, [SP], #0x10
    // 0xe37450: ret
    //     0xe37450: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x112e41c, size: 0xec
    // 0x112e41c: EnterFrame
    //     0x112e41c: stp             fp, lr, [SP, #-0x10]!
    //     0x112e420: mov             fp, SP
    // 0x112e424: AllocStack(0x50)
    //     0x112e424: sub             SP, SP, #0x50
    // 0x112e428: CheckStackOverflow
    //     0x112e428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e42c: cmp             SP, x16
    //     0x112e430: b.ls            #0x112e500
    // 0x112e434: ldr             x0, [fp, #0x10]
    // 0x112e438: LoadField: r2 = r0->field_7
    //     0x112e438: ldur            w2, [x0, #7]
    // 0x112e43c: DecompressPointer r2
    //     0x112e43c: add             x2, x2, HEAP, lsl #32
    // 0x112e440: stur            x2, [fp, #-0x20]
    // 0x112e444: LoadField: r3 = r0->field_b
    //     0x112e444: ldur            w3, [x0, #0xb]
    // 0x112e448: DecompressPointer r3
    //     0x112e448: add             x3, x3, HEAP, lsl #32
    // 0x112e44c: stur            x3, [fp, #-0x18]
    // 0x112e450: LoadField: r4 = r0->field_f
    //     0x112e450: ldur            w4, [x0, #0xf]
    // 0x112e454: DecompressPointer r4
    //     0x112e454: add             x4, x4, HEAP, lsl #32
    // 0x112e458: stur            x4, [fp, #-0x10]
    // 0x112e45c: LoadField: r5 = r0->field_13
    //     0x112e45c: ldur            w5, [x0, #0x13]
    // 0x112e460: DecompressPointer r5
    //     0x112e460: add             x5, x5, HEAP, lsl #32
    // 0x112e464: stur            x5, [fp, #-8]
    // 0x112e468: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x112e468: ldur            w1, [x0, #0x17]
    // 0x112e46c: DecompressPointer r1
    //     0x112e46c: add             x1, x1, HEAP, lsl #32
    // 0x112e470: cmp             w1, NULL
    // 0x112e474: b.ne            #0x112e480
    // 0x112e478: r1 = Null
    //     0x112e478: mov             x1, NULL
    // 0x112e47c: b               #0x112e4a4
    // 0x112e480: r0 = hashAll()
    //     0x112e480: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x112e484: mov             x2, x0
    // 0x112e488: r0 = BoxInt64Instr(r2)
    //     0x112e488: sbfiz           x0, x2, #1, #0x1f
    //     0x112e48c: cmp             x2, x0, asr #1
    //     0x112e490: b.eq            #0x112e49c
    //     0x112e494: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e498: stur            x2, [x0, #7]
    // 0x112e49c: mov             x1, x0
    // 0x112e4a0: ldr             x0, [fp, #0x10]
    // 0x112e4a4: LoadField: r2 = r0->field_1b
    //     0x112e4a4: ldur            w2, [x0, #0x1b]
    // 0x112e4a8: DecompressPointer r2
    //     0x112e4a8: add             x2, x2, HEAP, lsl #32
    // 0x112e4ac: LoadField: r3 = r0->field_23
    //     0x112e4ac: ldur            w3, [x0, #0x23]
    // 0x112e4b0: DecompressPointer r3
    //     0x112e4b0: add             x3, x3, HEAP, lsl #32
    // 0x112e4b4: ldur            x16, [fp, #-0x10]
    // 0x112e4b8: ldur            lr, [fp, #-8]
    // 0x112e4bc: stp             lr, x16, [SP, #0x20]
    // 0x112e4c0: stp             x2, x1, [SP, #0x10]
    // 0x112e4c4: stp             x3, NULL, [SP]
    // 0x112e4c8: ldur            x1, [fp, #-0x20]
    // 0x112e4cc: ldur            x2, [fp, #-0x18]
    // 0x112e4d0: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x112e4d0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x112e4d4: ldr             x4, [x4, #0x90]
    // 0x112e4d8: r0 = hash()
    //     0x112e4d8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112e4dc: mov             x2, x0
    // 0x112e4e0: r0 = BoxInt64Instr(r2)
    //     0x112e4e0: sbfiz           x0, x2, #1, #0x1f
    //     0x112e4e4: cmp             x2, x0, asr #1
    //     0x112e4e8: b.eq            #0x112e4f4
    //     0x112e4ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e4f0: stur            x2, [x0, #7]
    // 0x112e4f4: LeaveFrame
    //     0x112e4f4: mov             SP, fp
    //     0x112e4f8: ldp             fp, lr, [SP], #0x10
    // 0x112e4fc: ret
    //     0x112e4fc: ret             
    // 0x112e500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112e500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e504: b               #0x112e434
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x115fd5c, size: 0x244
    // 0x115fd5c: EnterFrame
    //     0x115fd5c: stp             fp, lr, [SP, #-0x10]!
    //     0x115fd60: mov             fp, SP
    // 0x115fd64: AllocStack(0x48)
    //     0x115fd64: sub             SP, SP, #0x48
    // 0x115fd68: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0x115fd68: mov             x4, x1
    //     0x115fd6c: mov             x0, x2
    //     0x115fd70: stur            x1, [fp, #-8]
    //     0x115fd74: stur            x2, [fp, #-0x10]
    //     0x115fd78: stur            d0, [fp, #-0x48]
    // 0x115fd7c: CheckStackOverflow
    //     0x115fd7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115fd80: cmp             SP, x16
    //     0x115fd84: b.ls            #0x115ff74
    // 0x115fd88: cmp             w4, w0
    // 0x115fd8c: b.ne            #0x115fda0
    // 0x115fd90: mov             x0, x4
    // 0x115fd94: LeaveFrame
    //     0x115fd94: mov             SP, fp
    //     0x115fd98: ldp             fp, lr, [SP], #0x10
    // 0x115fd9c: ret
    //     0x115fd9c: ret             
    // 0x115fda0: d1 = 0.000000
    //     0x115fda0: eor             v1.16b, v1.16b, v1.16b
    // 0x115fda4: fcmp            d0, d1
    // 0x115fda8: b.ne            #0x115fdbc
    // 0x115fdac: mov             x0, x4
    // 0x115fdb0: LeaveFrame
    //     0x115fdb0: mov             SP, fp
    //     0x115fdb4: ldp             fp, lr, [SP], #0x10
    // 0x115fdb8: ret
    //     0x115fdb8: ret             
    // 0x115fdbc: d1 = 1.000000
    //     0x115fdbc: fmov            d1, #1.00000000
    // 0x115fdc0: fcmp            d0, d1
    // 0x115fdc4: b.ne            #0x115fdd4
    // 0x115fdc8: LeaveFrame
    //     0x115fdc8: mov             SP, fp
    //     0x115fdcc: ldp             fp, lr, [SP], #0x10
    // 0x115fdd0: ret
    //     0x115fdd0: ret             
    // 0x115fdd4: LoadField: r1 = r4->field_7
    //     0x115fdd4: ldur            w1, [x4, #7]
    // 0x115fdd8: DecompressPointer r1
    //     0x115fdd8: add             x1, x1, HEAP, lsl #32
    // 0x115fddc: LoadField: r2 = r0->field_7
    //     0x115fddc: ldur            w2, [x0, #7]
    // 0x115fde0: DecompressPointer r2
    //     0x115fde0: add             x2, x2, HEAP, lsl #32
    // 0x115fde4: r3 = inline_Allocate_Double()
    //     0x115fde4: ldp             x3, x5, [THR, #0x60]  ; THR::top
    //     0x115fde8: add             x3, x3, #0x10
    //     0x115fdec: cmp             x5, x3
    //     0x115fdf0: b.ls            #0x115ff7c
    //     0x115fdf4: str             x3, [THR, #0x60]  ; THR::top
    //     0x115fdf8: sub             x3, x3, #0xf
    //     0x115fdfc: mov             x5, #0xe19c
    //     0x115fe00: movk            x5, #3, lsl #16
    //     0x115fe04: stur            x5, [x3, #-1]
    // 0x115fe08: dmb             ishst
    // 0x115fe0c: StoreField: r3->field_7 = d0
    //     0x115fe0c: stur            d0, [x3, #7]
    // 0x115fe10: r0 = lerp()
    //     0x115fe10: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115fe14: mov             x3, x0
    // 0x115fe18: ldur            x0, [fp, #-8]
    // 0x115fe1c: stur            x3, [fp, #-0x18]
    // 0x115fe20: LoadField: r1 = r0->field_b
    //     0x115fe20: ldur            w1, [x0, #0xb]
    // 0x115fe24: DecompressPointer r1
    //     0x115fe24: add             x1, x1, HEAP, lsl #32
    // 0x115fe28: ldur            x4, [fp, #-0x10]
    // 0x115fe2c: LoadField: r2 = r4->field_b
    //     0x115fe2c: ldur            w2, [x4, #0xb]
    // 0x115fe30: DecompressPointer r2
    //     0x115fe30: add             x2, x2, HEAP, lsl #32
    // 0x115fe34: ldur            d0, [fp, #-0x48]
    // 0x115fe38: r0 = lerp()
    //     0x115fe38: bl              #0x1162ff8  ; [package:flutter/src/painting/decoration_image.dart] DecorationImage::lerp
    // 0x115fe3c: mov             x3, x0
    // 0x115fe40: ldur            x0, [fp, #-8]
    // 0x115fe44: stur            x3, [fp, #-0x20]
    // 0x115fe48: LoadField: r1 = r0->field_f
    //     0x115fe48: ldur            w1, [x0, #0xf]
    // 0x115fe4c: DecompressPointer r1
    //     0x115fe4c: add             x1, x1, HEAP, lsl #32
    // 0x115fe50: ldur            x4, [fp, #-0x10]
    // 0x115fe54: LoadField: r2 = r4->field_f
    //     0x115fe54: ldur            w2, [x4, #0xf]
    // 0x115fe58: DecompressPointer r2
    //     0x115fe58: add             x2, x2, HEAP, lsl #32
    // 0x115fe5c: ldur            d0, [fp, #-0x48]
    // 0x115fe60: r0 = lerp()
    //     0x115fe60: bl              #0x1162fb0  ; [package:flutter/src/painting/box_border.dart] BoxBorder::lerp
    // 0x115fe64: mov             x3, x0
    // 0x115fe68: ldur            x0, [fp, #-8]
    // 0x115fe6c: stur            x3, [fp, #-0x28]
    // 0x115fe70: LoadField: r1 = r0->field_13
    //     0x115fe70: ldur            w1, [x0, #0x13]
    // 0x115fe74: DecompressPointer r1
    //     0x115fe74: add             x1, x1, HEAP, lsl #32
    // 0x115fe78: ldur            x4, [fp, #-0x10]
    // 0x115fe7c: LoadField: r2 = r4->field_13
    //     0x115fe7c: ldur            w2, [x4, #0x13]
    // 0x115fe80: DecompressPointer r2
    //     0x115fe80: add             x2, x2, HEAP, lsl #32
    // 0x115fe84: ldur            d0, [fp, #-0x48]
    // 0x115fe88: r0 = lerp()
    //     0x115fe88: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x115fe8c: mov             x3, x0
    // 0x115fe90: ldur            x0, [fp, #-8]
    // 0x115fe94: stur            x3, [fp, #-0x30]
    // 0x115fe98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115fe98: ldur            w1, [x0, #0x17]
    // 0x115fe9c: DecompressPointer r1
    //     0x115fe9c: add             x1, x1, HEAP, lsl #32
    // 0x115fea0: ldur            x4, [fp, #-0x10]
    // 0x115fea4: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x115fea4: ldur            w2, [x4, #0x17]
    // 0x115fea8: DecompressPointer r2
    //     0x115fea8: add             x2, x2, HEAP, lsl #32
    // 0x115feac: ldur            d0, [fp, #-0x48]
    // 0x115feb0: r0 = lerpList()
    //     0x115feb0: bl              #0x116277c  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0x115feb4: mov             x3, x0
    // 0x115feb8: ldur            x0, [fp, #-8]
    // 0x115febc: stur            x3, [fp, #-0x38]
    // 0x115fec0: LoadField: r1 = r0->field_1b
    //     0x115fec0: ldur            w1, [x0, #0x1b]
    // 0x115fec4: DecompressPointer r1
    //     0x115fec4: add             x1, x1, HEAP, lsl #32
    // 0x115fec8: ldur            x4, [fp, #-0x10]
    // 0x115fecc: LoadField: r2 = r4->field_1b
    //     0x115fecc: ldur            w2, [x4, #0x1b]
    // 0x115fed0: DecompressPointer r2
    //     0x115fed0: add             x2, x2, HEAP, lsl #32
    // 0x115fed4: ldur            d0, [fp, #-0x48]
    // 0x115fed8: r0 = lerp()
    //     0x115fed8: bl              #0x115ffa0  ; [package:flutter/src/painting/gradient.dart] Gradient::lerp
    // 0x115fedc: ldur            d0, [fp, #-0x48]
    // 0x115fee0: d1 = 0.500000
    //     0x115fee0: fmov            d1, #0.50000000
    // 0x115fee4: stur            x0, [fp, #-0x40]
    // 0x115fee8: fcmp            d1, d0
    // 0x115feec: b.le            #0x115ff04
    // 0x115fef0: ldur            x1, [fp, #-8]
    // 0x115fef4: LoadField: r2 = r1->field_23
    //     0x115fef4: ldur            w2, [x1, #0x23]
    // 0x115fef8: DecompressPointer r2
    //     0x115fef8: add             x2, x2, HEAP, lsl #32
    // 0x115fefc: mov             x6, x2
    // 0x115ff00: b               #0x115ff14
    // 0x115ff04: ldur            x1, [fp, #-0x10]
    // 0x115ff08: LoadField: r2 = r1->field_23
    //     0x115ff08: ldur            w2, [x1, #0x23]
    // 0x115ff0c: DecompressPointer r2
    //     0x115ff0c: add             x2, x2, HEAP, lsl #32
    // 0x115ff10: mov             x6, x2
    // 0x115ff14: ldur            x5, [fp, #-0x18]
    // 0x115ff18: ldur            x4, [fp, #-0x20]
    // 0x115ff1c: ldur            x3, [fp, #-0x28]
    // 0x115ff20: ldur            x2, [fp, #-0x30]
    // 0x115ff24: ldur            x1, [fp, #-0x38]
    // 0x115ff28: stur            x6, [fp, #-8]
    // 0x115ff2c: r0 = BoxDecoration()
    //     0x115ff2c: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x115ff30: ldur            x1, [fp, #-0x18]
    // 0x115ff34: StoreField: r0->field_7 = r1
    //     0x115ff34: stur            w1, [x0, #7]
    // 0x115ff38: ldur            x1, [fp, #-0x20]
    // 0x115ff3c: StoreField: r0->field_b = r1
    //     0x115ff3c: stur            w1, [x0, #0xb]
    // 0x115ff40: ldur            x1, [fp, #-0x28]
    // 0x115ff44: StoreField: r0->field_f = r1
    //     0x115ff44: stur            w1, [x0, #0xf]
    // 0x115ff48: ldur            x1, [fp, #-0x30]
    // 0x115ff4c: StoreField: r0->field_13 = r1
    //     0x115ff4c: stur            w1, [x0, #0x13]
    // 0x115ff50: ldur            x1, [fp, #-0x38]
    // 0x115ff54: ArrayStore: r0[0] = r1  ; List_4
    //     0x115ff54: stur            w1, [x0, #0x17]
    // 0x115ff58: ldur            x1, [fp, #-0x40]
    // 0x115ff5c: StoreField: r0->field_1b = r1
    //     0x115ff5c: stur            w1, [x0, #0x1b]
    // 0x115ff60: ldur            x1, [fp, #-8]
    // 0x115ff64: StoreField: r0->field_23 = r1
    //     0x115ff64: stur            w1, [x0, #0x23]
    // 0x115ff68: LeaveFrame
    //     0x115ff68: mov             SP, fp
    //     0x115ff6c: ldp             fp, lr, [SP], #0x10
    // 0x115ff70: ret
    //     0x115ff70: ret             
    // 0x115ff74: r0 = StackOverflowSharedWithFPURegs()
    //     0x115ff74: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115ff78: b               #0x115fd88
    // 0x115ff7c: SaveReg d0
    //     0x115ff7c: str             q0, [SP, #-0x10]!
    // 0x115ff80: stp             x2, x4, [SP, #-0x10]!
    // 0x115ff84: stp             x0, x1, [SP, #-0x10]!
    // 0x115ff88: r0 = AllocateDouble()
    //     0x115ff88: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ff8c: mov             x3, x0
    // 0x115ff90: ldp             x0, x1, [SP], #0x10
    // 0x115ff94: ldp             x2, x4, [SP], #0x10
    // 0x115ff98: RestoreReg d0
    //     0x115ff98: ldr             q0, [SP], #0x10
    // 0x115ff9c: b               #0x115fe0c
  }
  _ scale(/* No info */) {
    // ** addr: 0x11637d0, size: 0x1bc
    // 0x11637d0: EnterFrame
    //     0x11637d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11637d4: mov             fp, SP
    // 0x11637d8: AllocStack(0x48)
    //     0x11637d8: sub             SP, SP, #0x48
    // 0x11637dc: SetupParameters(BoxDecoration this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0x11637dc: mov             x0, x1
    //     0x11637e0: stur            x1, [fp, #-8]
    //     0x11637e4: stur            d0, [fp, #-0x48]
    // 0x11637e8: CheckStackOverflow
    //     0x11637e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11637ec: cmp             SP, x16
    //     0x11637f0: b.ls            #0x1163968
    // 0x11637f4: LoadField: r2 = r0->field_7
    //     0x11637f4: ldur            w2, [x0, #7]
    // 0x11637f8: DecompressPointer r2
    //     0x11637f8: add             x2, x2, HEAP, lsl #32
    // 0x11637fc: r3 = inline_Allocate_Double()
    //     0x11637fc: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x1163800: add             x3, x3, #0x10
    //     0x1163804: cmp             x1, x3
    //     0x1163808: b.ls            #0x1163970
    //     0x116380c: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163810: sub             x3, x3, #0xf
    //     0x1163814: mov             x1, #0xe19c
    //     0x1163818: movk            x1, #3, lsl #16
    //     0x116381c: stur            x1, [x3, #-1]
    // 0x1163820: dmb             ishst
    // 0x1163824: StoreField: r3->field_7 = d0
    //     0x1163824: stur            d0, [x3, #7]
    // 0x1163828: r1 = Null
    //     0x1163828: mov             x1, NULL
    // 0x116382c: r0 = lerp()
    //     0x116382c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1163830: mov             x3, x0
    // 0x1163834: ldur            x0, [fp, #-8]
    // 0x1163838: stur            x3, [fp, #-0x10]
    // 0x116383c: LoadField: r2 = r0->field_b
    //     0x116383c: ldur            w2, [x0, #0xb]
    // 0x1163840: DecompressPointer r2
    //     0x1163840: add             x2, x2, HEAP, lsl #32
    // 0x1163844: ldur            d0, [fp, #-0x48]
    // 0x1163848: r1 = Null
    //     0x1163848: mov             x1, NULL
    // 0x116384c: r0 = lerp()
    //     0x116384c: bl              #0x1162ff8  ; [package:flutter/src/painting/decoration_image.dart] DecorationImage::lerp
    // 0x1163850: mov             x3, x0
    // 0x1163854: ldur            x0, [fp, #-8]
    // 0x1163858: stur            x3, [fp, #-0x18]
    // 0x116385c: LoadField: r2 = r0->field_f
    //     0x116385c: ldur            w2, [x0, #0xf]
    // 0x1163860: DecompressPointer r2
    //     0x1163860: add             x2, x2, HEAP, lsl #32
    // 0x1163864: ldur            d0, [fp, #-0x48]
    // 0x1163868: r1 = Null
    //     0x1163868: mov             x1, NULL
    // 0x116386c: r0 = lerp()
    //     0x116386c: bl              #0x1162fb0  ; [package:flutter/src/painting/box_border.dart] BoxBorder::lerp
    // 0x1163870: mov             x3, x0
    // 0x1163874: ldur            x0, [fp, #-8]
    // 0x1163878: stur            x3, [fp, #-0x20]
    // 0x116387c: LoadField: r2 = r0->field_13
    //     0x116387c: ldur            w2, [x0, #0x13]
    // 0x1163880: DecompressPointer r2
    //     0x1163880: add             x2, x2, HEAP, lsl #32
    // 0x1163884: ldur            d0, [fp, #-0x48]
    // 0x1163888: r1 = Null
    //     0x1163888: mov             x1, NULL
    // 0x116388c: r0 = lerp()
    //     0x116388c: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x1163890: mov             x3, x0
    // 0x1163894: ldur            x0, [fp, #-8]
    // 0x1163898: stur            x3, [fp, #-0x28]
    // 0x116389c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x116389c: ldur            w2, [x0, #0x17]
    // 0x11638a0: DecompressPointer r2
    //     0x11638a0: add             x2, x2, HEAP, lsl #32
    // 0x11638a4: ldur            d0, [fp, #-0x48]
    // 0x11638a8: r1 = Null
    //     0x11638a8: mov             x1, NULL
    // 0x11638ac: r0 = lerpList()
    //     0x11638ac: bl              #0x116277c  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0x11638b0: mov             x3, x0
    // 0x11638b4: ldur            x2, [fp, #-8]
    // 0x11638b8: stur            x3, [fp, #-0x30]
    // 0x11638bc: LoadField: r1 = r2->field_1b
    //     0x11638bc: ldur            w1, [x2, #0x1b]
    // 0x11638c0: DecompressPointer r1
    //     0x11638c0: add             x1, x1, HEAP, lsl #32
    // 0x11638c4: cmp             w1, NULL
    // 0x11638c8: b.ne            #0x11638dc
    // 0x11638cc: mov             x0, x2
    // 0x11638d0: mov             x1, x3
    // 0x11638d4: r6 = Null
    //     0x11638d4: mov             x6, NULL
    // 0x11638d8: b               #0x1163900
    // 0x11638dc: r0 = LoadClassIdInstr(r1)
    //     0x11638dc: ldur            x0, [x1, #-1]
    //     0x11638e0: ubfx            x0, x0, #0xc, #0x14
    // 0x11638e4: ldur            d0, [fp, #-0x48]
    // 0x11638e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11638e8: sub             lr, x0, #1, lsl #12
    //     0x11638ec: ldr             lr, [x21, lr, lsl #3]
    //     0x11638f0: blr             lr
    // 0x11638f4: mov             x6, x0
    // 0x11638f8: ldur            x0, [fp, #-8]
    // 0x11638fc: ldur            x1, [fp, #-0x30]
    // 0x1163900: ldur            x5, [fp, #-0x10]
    // 0x1163904: ldur            x4, [fp, #-0x18]
    // 0x1163908: ldur            x3, [fp, #-0x20]
    // 0x116390c: ldur            x2, [fp, #-0x28]
    // 0x1163910: stur            x6, [fp, #-0x40]
    // 0x1163914: LoadField: r7 = r0->field_23
    //     0x1163914: ldur            w7, [x0, #0x23]
    // 0x1163918: DecompressPointer r7
    //     0x1163918: add             x7, x7, HEAP, lsl #32
    // 0x116391c: stur            x7, [fp, #-0x38]
    // 0x1163920: r0 = BoxDecoration()
    //     0x1163920: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x1163924: ldur            x1, [fp, #-0x10]
    // 0x1163928: StoreField: r0->field_7 = r1
    //     0x1163928: stur            w1, [x0, #7]
    // 0x116392c: ldur            x1, [fp, #-0x18]
    // 0x1163930: StoreField: r0->field_b = r1
    //     0x1163930: stur            w1, [x0, #0xb]
    // 0x1163934: ldur            x1, [fp, #-0x20]
    // 0x1163938: StoreField: r0->field_f = r1
    //     0x1163938: stur            w1, [x0, #0xf]
    // 0x116393c: ldur            x1, [fp, #-0x28]
    // 0x1163940: StoreField: r0->field_13 = r1
    //     0x1163940: stur            w1, [x0, #0x13]
    // 0x1163944: ldur            x1, [fp, #-0x30]
    // 0x1163948: ArrayStore: r0[0] = r1  ; List_4
    //     0x1163948: stur            w1, [x0, #0x17]
    // 0x116394c: ldur            x1, [fp, #-0x40]
    // 0x1163950: StoreField: r0->field_1b = r1
    //     0x1163950: stur            w1, [x0, #0x1b]
    // 0x1163954: ldur            x1, [fp, #-0x38]
    // 0x1163958: StoreField: r0->field_23 = r1
    //     0x1163958: stur            w1, [x0, #0x23]
    // 0x116395c: LeaveFrame
    //     0x116395c: mov             SP, fp
    //     0x1163960: ldp             fp, lr, [SP], #0x10
    // 0x1163964: ret
    //     0x1163964: ret             
    // 0x1163968: r0 = StackOverflowSharedWithFPURegs()
    //     0x1163968: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116396c: b               #0x11637f4
    // 0x1163970: SaveReg d0
    //     0x1163970: str             q0, [SP, #-0x10]!
    // 0x1163974: stp             x0, x2, [SP, #-0x10]!
    // 0x1163978: r0 = AllocateDouble()
    //     0x1163978: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116397c: mov             x3, x0
    // 0x1163980: ldp             x0, x2, [SP], #0x10
    // 0x1163984: RestoreReg d0
    //     0x1163984: ldr             q0, [SP], #0x10
    // 0x1163988: b               #0x1163824
  }
  _ getClipPath(/* No info */) {
    // ** addr: 0x1197030, size: 0x434
    // 0x1197030: EnterFrame
    //     0x1197030: stp             fp, lr, [SP, #-0x10]!
    //     0x1197034: mov             fp, SP
    // 0x1197038: AllocStack(0x70)
    //     0x1197038: sub             SP, SP, #0x70
    // 0x119703c: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0x119703c: mov             x0, x2
    //     0x1197040: stur            x2, [fp, #-0x10]
    //     0x1197044: mov             x2, x3
    //     0x1197048: stur            x3, [fp, #-0x18]
    // 0x119704c: CheckStackOverflow
    //     0x119704c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1197050: cmp             SP, x16
    //     0x1197054: b.ls            #0x1197450
    // 0x1197058: LoadField: r3 = r1->field_23
    //     0x1197058: ldur            w3, [x1, #0x23]
    // 0x119705c: DecompressPointer r3
    //     0x119705c: add             x3, x3, HEAP, lsl #32
    // 0x1197060: LoadField: r4 = r3->field_7
    //     0x1197060: ldur            x4, [x3, #7]
    // 0x1197064: cmp             x4, #0
    // 0x1197068: b.gt            #0x1197348
    // 0x119706c: LoadField: r3 = r1->field_13
    //     0x119706c: ldur            w3, [x1, #0x13]
    // 0x1197070: DecompressPointer r3
    //     0x1197070: add             x3, x3, HEAP, lsl #32
    // 0x1197074: stur            x3, [fp, #-8]
    // 0x1197078: cmp             w3, NULL
    // 0x119707c: b.eq            #0x11972b0
    // 0x1197080: r0 = _NativePath()
    //     0x1197080: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1197084: mov             x1, x0
    // 0x1197088: stur            x0, [fp, #-0x20]
    // 0x119708c: r0 = __constructor$Method$FfiNative()
    //     0x119708c: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1197090: ldur            x0, [fp, #-8]
    // 0x1197094: r1 = LoadClassIdInstr(r0)
    //     0x1197094: ldur            x1, [x0, #-1]
    //     0x1197098: ubfx            x1, x1, #0xc, #0x14
    // 0x119709c: cmp             x1, #0xb88
    // 0x11970a0: b.ne            #0x119716c
    // 0x11970a4: ldur            x2, [fp, #-0x18]
    // 0x11970a8: LoadField: r1 = r2->field_7
    //     0x11970a8: ldur            x1, [x2, #7]
    // 0x11970ac: cmp             x1, #0
    // 0x11970b0: b.gt            #0x1197110
    // 0x11970b4: LoadField: r1 = r0->field_b
    //     0x11970b4: ldur            w1, [x0, #0xb]
    // 0x11970b8: DecompressPointer r1
    //     0x11970b8: add             x1, x1, HEAP, lsl #32
    // 0x11970bc: stur            x1, [fp, #-0x40]
    // 0x11970c0: LoadField: r2 = r0->field_7
    //     0x11970c0: ldur            w2, [x0, #7]
    // 0x11970c4: DecompressPointer r2
    //     0x11970c4: add             x2, x2, HEAP, lsl #32
    // 0x11970c8: stur            x2, [fp, #-0x38]
    // 0x11970cc: LoadField: r3 = r0->field_13
    //     0x11970cc: ldur            w3, [x0, #0x13]
    // 0x11970d0: DecompressPointer r3
    //     0x11970d0: add             x3, x3, HEAP, lsl #32
    // 0x11970d4: stur            x3, [fp, #-0x30]
    // 0x11970d8: LoadField: r4 = r0->field_f
    //     0x11970d8: ldur            w4, [x0, #0xf]
    // 0x11970dc: DecompressPointer r4
    //     0x11970dc: add             x4, x4, HEAP, lsl #32
    // 0x11970e0: stur            x4, [fp, #-0x28]
    // 0x11970e4: r0 = BorderRadius()
    //     0x11970e4: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x11970e8: mov             x1, x0
    // 0x11970ec: ldur            x0, [fp, #-0x40]
    // 0x11970f0: StoreField: r1->field_7 = r0
    //     0x11970f0: stur            w0, [x1, #7]
    // 0x11970f4: ldur            x0, [fp, #-0x38]
    // 0x11970f8: StoreField: r1->field_b = r0
    //     0x11970f8: stur            w0, [x1, #0xb]
    // 0x11970fc: ldur            x0, [fp, #-0x30]
    // 0x1197100: StoreField: r1->field_f = r0
    //     0x1197100: stur            w0, [x1, #0xf]
    // 0x1197104: ldur            x0, [fp, #-0x28]
    // 0x1197108: StoreField: r1->field_13 = r0
    //     0x1197108: stur            w0, [x1, #0x13]
    // 0x119710c: b               #0x11971a4
    // 0x1197110: LoadField: r1 = r0->field_7
    //     0x1197110: ldur            w1, [x0, #7]
    // 0x1197114: DecompressPointer r1
    //     0x1197114: add             x1, x1, HEAP, lsl #32
    // 0x1197118: stur            x1, [fp, #-0x40]
    // 0x119711c: LoadField: r2 = r0->field_b
    //     0x119711c: ldur            w2, [x0, #0xb]
    // 0x1197120: DecompressPointer r2
    //     0x1197120: add             x2, x2, HEAP, lsl #32
    // 0x1197124: stur            x2, [fp, #-0x38]
    // 0x1197128: LoadField: r3 = r0->field_f
    //     0x1197128: ldur            w3, [x0, #0xf]
    // 0x119712c: DecompressPointer r3
    //     0x119712c: add             x3, x3, HEAP, lsl #32
    // 0x1197130: stur            x3, [fp, #-0x30]
    // 0x1197134: LoadField: r4 = r0->field_13
    //     0x1197134: ldur            w4, [x0, #0x13]
    // 0x1197138: DecompressPointer r4
    //     0x1197138: add             x4, x4, HEAP, lsl #32
    // 0x119713c: stur            x4, [fp, #-0x28]
    // 0x1197140: r0 = BorderRadius()
    //     0x1197140: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1197144: mov             x1, x0
    // 0x1197148: ldur            x0, [fp, #-0x40]
    // 0x119714c: StoreField: r1->field_7 = r0
    //     0x119714c: stur            w0, [x1, #7]
    // 0x1197150: ldur            x0, [fp, #-0x38]
    // 0x1197154: StoreField: r1->field_b = r0
    //     0x1197154: stur            w0, [x1, #0xb]
    // 0x1197158: ldur            x0, [fp, #-0x30]
    // 0x119715c: StoreField: r1->field_f = r0
    //     0x119715c: stur            w0, [x1, #0xf]
    // 0x1197160: ldur            x0, [fp, #-0x28]
    // 0x1197164: StoreField: r1->field_13 = r0
    //     0x1197164: stur            w0, [x1, #0x13]
    // 0x1197168: b               #0x11971a4
    // 0x119716c: ldur            x2, [fp, #-0x18]
    // 0x1197170: cmp             x1, #0xb89
    // 0x1197174: b.ne            #0x1197180
    // 0x1197178: mov             x1, x0
    // 0x119717c: b               #0x11971a4
    // 0x1197180: r1 = LoadClassIdInstr(r0)
    //     0x1197180: ldur            x1, [x0, #-1]
    //     0x1197184: ubfx            x1, x1, #0xc, #0x14
    // 0x1197188: mov             x16, x0
    // 0x119718c: mov             x0, x1
    // 0x1197190: mov             x1, x16
    // 0x1197194: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1197194: sub             lr, x0, #1, lsl #12
    //     0x1197198: ldr             lr, [x21, lr, lsl #3]
    //     0x119719c: blr             lr
    // 0x11971a0: mov             x1, x0
    // 0x11971a4: ldur            x0, [fp, #-0x20]
    // 0x11971a8: ldur            x2, [fp, #-0x10]
    // 0x11971ac: r0 = toRRect()
    //     0x11971ac: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x11971b0: stur            x0, [fp, #-8]
    // 0x11971b4: LoadField: d0 = r0->field_b
    //     0x11971b4: ldur            d0, [x0, #0xb]
    // 0x11971b8: fcvt            s1, d0
    // 0x11971bc: stur            d1, [fp, #-0x50]
    // 0x11971c0: r4 = 24
    //     0x11971c0: mov             x4, #0x18
    // 0x11971c4: r0 = AllocateFloat32Array()
    //     0x11971c4: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x11971c8: ldur            d0, [fp, #-0x50]
    // 0x11971cc: stur            x0, [fp, #-0x18]
    // 0x11971d0: ArrayStore: r0[0] = d0  ; List_8
    //     0x11971d0: stur            s0, [x0, #0x17]
    // 0x11971d4: ldur            x1, [fp, #-8]
    // 0x11971d8: LoadField: d0 = r1->field_13
    //     0x11971d8: ldur            d0, [x1, #0x13]
    // 0x11971dc: fcvt            s1, d0
    // 0x11971e0: StoreField: r0->field_1b = d1
    //     0x11971e0: stur            s1, [x0, #0x1b]
    // 0x11971e4: LoadField: d0 = r1->field_1b
    //     0x11971e4: ldur            d0, [x1, #0x1b]
    // 0x11971e8: fcvt            s1, d0
    // 0x11971ec: StoreField: r0->field_1f = d1
    //     0x11971ec: stur            s1, [x0, #0x1f]
    // 0x11971f0: LoadField: d0 = r1->field_23
    //     0x11971f0: ldur            d0, [x1, #0x23]
    // 0x11971f4: fcvt            s1, d0
    // 0x11971f8: StoreField: r0->field_23 = d1
    //     0x11971f8: stur            s1, [x0, #0x23]
    // 0x11971fc: LoadField: d0 = r1->field_2b
    //     0x11971fc: ldur            d0, [x1, #0x2b]
    // 0x1197200: fcvt            s1, d0
    // 0x1197204: StoreField: r0->field_27 = d1
    //     0x1197204: stur            s1, [x0, #0x27]
    // 0x1197208: LoadField: d0 = r1->field_33
    //     0x1197208: ldur            d0, [x1, #0x33]
    // 0x119720c: fcvt            s1, d0
    // 0x1197210: StoreField: r0->field_2b = d1
    //     0x1197210: stur            s1, [x0, #0x2b]
    // 0x1197214: LoadField: d0 = r1->field_3b
    //     0x1197214: ldur            d0, [x1, #0x3b]
    // 0x1197218: fcvt            s1, d0
    // 0x119721c: StoreField: r0->field_2f = d1
    //     0x119721c: stur            s1, [x0, #0x2f]
    // 0x1197220: LoadField: d0 = r1->field_43
    //     0x1197220: ldur            d0, [x1, #0x43]
    // 0x1197224: fcvt            s1, d0
    // 0x1197228: StoreField: r0->field_33 = d1
    //     0x1197228: stur            s1, [x0, #0x33]
    // 0x119722c: LoadField: d0 = r1->field_4b
    //     0x119722c: ldur            d0, [x1, #0x4b]
    // 0x1197230: fcvt            s1, d0
    // 0x1197234: StoreField: r0->field_37 = d1
    //     0x1197234: stur            s1, [x0, #0x37]
    // 0x1197238: LoadField: d0 = r1->field_53
    //     0x1197238: ldur            d0, [x1, #0x53]
    // 0x119723c: fcvt            s1, d0
    // 0x1197240: StoreField: r0->field_3b = d1
    //     0x1197240: stur            s1, [x0, #0x3b]
    // 0x1197244: LoadField: d0 = r1->field_5b
    //     0x1197244: ldur            d0, [x1, #0x5b]
    // 0x1197248: fcvt            s1, d0
    // 0x119724c: StoreField: r0->field_3f = d1
    //     0x119724c: stur            s1, [x0, #0x3f]
    // 0x1197250: LoadField: d0 = r1->field_63
    //     0x1197250: ldur            d0, [x1, #0x63]
    // 0x1197254: fcvt            s1, d0
    // 0x1197258: StoreField: r0->field_43 = d1
    //     0x1197258: stur            s1, [x0, #0x43]
    // 0x119725c: ldur            x2, [fp, #-0x20]
    // 0x1197260: LoadField: r1 = r2->field_7
    //     0x1197260: ldur            w1, [x2, #7]
    // 0x1197264: DecompressPointer r1
    //     0x1197264: add             x1, x1, HEAP, lsl #32
    // 0x1197268: cmp             w1, NULL
    // 0x119726c: b.eq            #0x1197458
    // 0x1197270: LoadField: r3 = r1->field_7
    //     0x1197270: ldur            x3, [x1, #7]
    // 0x1197274: ldr             x1, [x3]
    // 0x1197278: cbz             x1, #0x1197420
    // 0x119727c: mov             x3, x1
    // 0x1197280: stur            x3, [fp, #-0x48]
    // 0x1197284: r1 = <Never>
    //     0x1197284: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1197288: r0 = Pointer()
    //     0x1197288: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x119728c: mov             x1, x0
    // 0x1197290: ldur            x0, [fp, #-0x48]
    // 0x1197294: StoreField: r1->field_7 = r0
    //     0x1197294: stur            x0, [x1, #7]
    // 0x1197298: ldur            x2, [fp, #-0x18]
    // 0x119729c: r0 = __addRRect$Method$FfiNative()
    //     0x119729c: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x11972a0: ldur            x0, [fp, #-0x20]
    // 0x11972a4: LeaveFrame
    //     0x11972a4: mov             SP, fp
    //     0x11972a8: ldp             fp, lr, [SP], #0x10
    // 0x11972ac: ret
    //     0x11972ac: ret             
    // 0x11972b0: mov             x1, x0
    // 0x11972b4: r0 = _NativePath()
    //     0x11972b4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x11972b8: mov             x1, x0
    // 0x11972bc: stur            x0, [fp, #-8]
    // 0x11972c0: r0 = __constructor$Method$FfiNative()
    //     0x11972c0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x11972c4: ldur            x0, [fp, #-0x10]
    // 0x11972c8: LoadField: d0 = r0->field_7
    //     0x11972c8: ldur            d0, [x0, #7]
    // 0x11972cc: stur            d0, [fp, #-0x68]
    // 0x11972d0: LoadField: d1 = r0->field_f
    //     0x11972d0: ldur            d1, [x0, #0xf]
    // 0x11972d4: stur            d1, [fp, #-0x60]
    // 0x11972d8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x11972d8: ldur            d2, [x0, #0x17]
    // 0x11972dc: stur            d2, [fp, #-0x58]
    // 0x11972e0: LoadField: d3 = r0->field_1f
    //     0x11972e0: ldur            d3, [x0, #0x1f]
    // 0x11972e4: ldur            x0, [fp, #-8]
    // 0x11972e8: stur            d3, [fp, #-0x50]
    // 0x11972ec: LoadField: r1 = r0->field_7
    //     0x11972ec: ldur            w1, [x0, #7]
    // 0x11972f0: DecompressPointer r1
    //     0x11972f0: add             x1, x1, HEAP, lsl #32
    // 0x11972f4: cmp             w1, NULL
    // 0x11972f8: b.eq            #0x119745c
    // 0x11972fc: LoadField: r2 = r1->field_7
    //     0x11972fc: ldur            x2, [x1, #7]
    // 0x1197300: ldr             x1, [x2]
    // 0x1197304: cbz             x1, #0x1197430
    // 0x1197308: mov             x2, x1
    // 0x119730c: stur            x2, [fp, #-0x48]
    // 0x1197310: r1 = <Never>
    //     0x1197310: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1197314: r0 = Pointer()
    //     0x1197314: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1197318: mov             x1, x0
    // 0x119731c: ldur            x0, [fp, #-0x48]
    // 0x1197320: StoreField: r1->field_7 = r0
    //     0x1197320: stur            x0, [x1, #7]
    // 0x1197324: ldur            d0, [fp, #-0x68]
    // 0x1197328: ldur            d1, [fp, #-0x60]
    // 0x119732c: ldur            d2, [fp, #-0x58]
    // 0x1197330: ldur            d3, [fp, #-0x50]
    // 0x1197334: r0 = __addRect$Method$FfiNative()
    //     0x1197334: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0x1197338: ldur            x0, [fp, #-8]
    // 0x119733c: LeaveFrame
    //     0x119733c: mov             SP, fp
    //     0x1197340: ldp             fp, lr, [SP], #0x10
    // 0x1197344: ret
    //     0x1197344: ret             
    // 0x1197348: mov             x1, x0
    // 0x119734c: r0 = center()
    //     0x119734c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x1197350: ldur            x1, [fp, #-0x10]
    // 0x1197354: stur            x0, [fp, #-8]
    // 0x1197358: r0 = shortestSide()
    //     0x1197358: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x119735c: mov             v1.16b, v0.16b
    // 0x1197360: d0 = 2.000000
    //     0x1197360: fmov            d0, #2.00000000
    // 0x1197364: fdiv            d2, d1, d0
    // 0x1197368: fmul            d1, d2, d0
    // 0x119736c: stur            d1, [fp, #-0x50]
    // 0x1197370: r0 = Rect()
    //     0x1197370: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x1197374: mov             x1, x0
    // 0x1197378: ldur            x2, [fp, #-8]
    // 0x119737c: ldur            d0, [fp, #-0x50]
    // 0x1197380: ldur            d1, [fp, #-0x50]
    // 0x1197384: stur            x0, [fp, #-8]
    // 0x1197388: r0 = Rect.fromCenter()
    //     0x1197388: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0x119738c: r0 = _NativePath()
    //     0x119738c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1197390: mov             x1, x0
    // 0x1197394: stur            x0, [fp, #-0x10]
    // 0x1197398: r0 = __constructor$Method$FfiNative()
    //     0x1197398: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x119739c: ldur            x0, [fp, #-8]
    // 0x11973a0: LoadField: d0 = r0->field_7
    //     0x11973a0: ldur            d0, [x0, #7]
    // 0x11973a4: stur            d0, [fp, #-0x68]
    // 0x11973a8: LoadField: d1 = r0->field_f
    //     0x11973a8: ldur            d1, [x0, #0xf]
    // 0x11973ac: stur            d1, [fp, #-0x60]
    // 0x11973b0: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x11973b0: ldur            d2, [x0, #0x17]
    // 0x11973b4: stur            d2, [fp, #-0x58]
    // 0x11973b8: LoadField: d3 = r0->field_1f
    //     0x11973b8: ldur            d3, [x0, #0x1f]
    // 0x11973bc: ldur            x0, [fp, #-0x10]
    // 0x11973c0: stur            d3, [fp, #-0x50]
    // 0x11973c4: LoadField: r1 = r0->field_7
    //     0x11973c4: ldur            w1, [x0, #7]
    // 0x11973c8: DecompressPointer r1
    //     0x11973c8: add             x1, x1, HEAP, lsl #32
    // 0x11973cc: cmp             w1, NULL
    // 0x11973d0: b.eq            #0x1197460
    // 0x11973d4: LoadField: r2 = r1->field_7
    //     0x11973d4: ldur            x2, [x1, #7]
    // 0x11973d8: ldr             x1, [x2]
    // 0x11973dc: cbz             x1, #0x1197440
    // 0x11973e0: mov             x2, x1
    // 0x11973e4: stur            x2, [fp, #-0x48]
    // 0x11973e8: r1 = <Never>
    //     0x11973e8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x11973ec: r0 = Pointer()
    //     0x11973ec: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x11973f0: mov             x1, x0
    // 0x11973f4: ldur            x0, [fp, #-0x48]
    // 0x11973f8: StoreField: r1->field_7 = r0
    //     0x11973f8: stur            x0, [x1, #7]
    // 0x11973fc: ldur            d0, [fp, #-0x68]
    // 0x1197400: ldur            d1, [fp, #-0x60]
    // 0x1197404: ldur            d2, [fp, #-0x58]
    // 0x1197408: ldur            d3, [fp, #-0x50]
    // 0x119740c: r0 = __addOval$Method$FfiNative()
    //     0x119740c: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0x1197410: ldur            x0, [fp, #-0x10]
    // 0x1197414: LeaveFrame
    //     0x1197414: mov             SP, fp
    //     0x1197418: ldp             fp, lr, [SP], #0x10
    // 0x119741c: ret
    //     0x119741c: ret             
    // 0x1197420: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1197420: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1197424: str             x16, [SP]
    // 0x1197428: r0 = _throwNew()
    //     0x1197428: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x119742c: brk             #0
    // 0x1197430: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1197430: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1197434: str             x16, [SP]
    // 0x1197438: r0 = _throwNew()
    //     0x1197438: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x119743c: brk             #0
    // 0x1197440: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1197440: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1197444: str             x16, [SP]
    // 0x1197448: r0 = _throwNew()
    //     0x1197448: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x119744c: brk             #0
    // 0x1197450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1197450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1197454: b               #0x1197058
    // 0x1197458: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1197458: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x119745c: r0 = NullErrorSharedWithFPURegs()
    //     0x119745c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x1197460: r0 = NullErrorSharedWithFPURegs()
    //     0x1197460: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x11a7c50, size: 0x214
    // 0x11a7c50: EnterFrame
    //     0x11a7c50: stp             fp, lr, [SP, #-0x10]!
    //     0x11a7c54: mov             fp, SP
    // 0x11a7c58: AllocStack(0x30)
    //     0x11a7c58: sub             SP, SP, #0x30
    // 0x11a7c5c: SetupParameters(BoxDecoration this /* r1 => r3 */, dynamic _ /* r2 => r1, fp-0x28 */, dynamic _ /* r3 => r0, fp-0x30 */, dynamic _ /* r5 => r2 */)
    //     0x11a7c5c: mov             x0, x3
    //     0x11a7c60: stur            x3, [fp, #-0x30]
    //     0x11a7c64: mov             x3, x1
    //     0x11a7c68: mov             x1, x2
    //     0x11a7c6c: stur            x2, [fp, #-0x28]
    //     0x11a7c70: mov             x2, x5
    // 0x11a7c74: CheckStackOverflow
    //     0x11a7c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a7c78: cmp             SP, x16
    //     0x11a7c7c: b.ls            #0x11a7e58
    // 0x11a7c80: LoadField: r4 = r3->field_23
    //     0x11a7c80: ldur            w4, [x3, #0x23]
    // 0x11a7c84: DecompressPointer r4
    //     0x11a7c84: add             x4, x4, HEAP, lsl #32
    // 0x11a7c88: LoadField: r5 = r4->field_7
    //     0x11a7c88: ldur            x5, [x4, #7]
    // 0x11a7c8c: cmp             x5, #0
    // 0x11a7c90: b.gt            #0x11a7df4
    // 0x11a7c94: LoadField: r4 = r3->field_13
    //     0x11a7c94: ldur            w4, [x3, #0x13]
    // 0x11a7c98: DecompressPointer r4
    //     0x11a7c98: add             x4, x4, HEAP, lsl #32
    // 0x11a7c9c: cmp             w4, NULL
    // 0x11a7ca0: b.eq            #0x11a7de4
    // 0x11a7ca4: r3 = LoadClassIdInstr(r4)
    //     0x11a7ca4: ldur            x3, [x4, #-1]
    //     0x11a7ca8: ubfx            x3, x3, #0xc, #0x14
    // 0x11a7cac: cmp             x3, #0xb88
    // 0x11a7cb0: b.ne            #0x11a7d88
    // 0x11a7cb4: cmp             w2, NULL
    // 0x11a7cb8: b.eq            #0x11a7e60
    // 0x11a7cbc: LoadField: r3 = r2->field_7
    //     0x11a7cbc: ldur            x3, [x2, #7]
    // 0x11a7cc0: cmp             x3, #0
    // 0x11a7cc4: b.gt            #0x11a7d28
    // 0x11a7cc8: LoadField: r2 = r4->field_b
    //     0x11a7cc8: ldur            w2, [x4, #0xb]
    // 0x11a7ccc: DecompressPointer r2
    //     0x11a7ccc: add             x2, x2, HEAP, lsl #32
    // 0x11a7cd0: stur            x2, [fp, #-0x20]
    // 0x11a7cd4: LoadField: r3 = r4->field_7
    //     0x11a7cd4: ldur            w3, [x4, #7]
    // 0x11a7cd8: DecompressPointer r3
    //     0x11a7cd8: add             x3, x3, HEAP, lsl #32
    // 0x11a7cdc: stur            x3, [fp, #-0x18]
    // 0x11a7ce0: LoadField: r5 = r4->field_13
    //     0x11a7ce0: ldur            w5, [x4, #0x13]
    // 0x11a7ce4: DecompressPointer r5
    //     0x11a7ce4: add             x5, x5, HEAP, lsl #32
    // 0x11a7ce8: stur            x5, [fp, #-0x10]
    // 0x11a7cec: LoadField: r6 = r4->field_f
    //     0x11a7cec: ldur            w6, [x4, #0xf]
    // 0x11a7cf0: DecompressPointer r6
    //     0x11a7cf0: add             x6, x6, HEAP, lsl #32
    // 0x11a7cf4: stur            x6, [fp, #-8]
    // 0x11a7cf8: r0 = BorderRadius()
    //     0x11a7cf8: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x11a7cfc: mov             x1, x0
    // 0x11a7d00: ldur            x0, [fp, #-0x20]
    // 0x11a7d04: StoreField: r1->field_7 = r0
    //     0x11a7d04: stur            w0, [x1, #7]
    // 0x11a7d08: ldur            x0, [fp, #-0x18]
    // 0x11a7d0c: StoreField: r1->field_b = r0
    //     0x11a7d0c: stur            w0, [x1, #0xb]
    // 0x11a7d10: ldur            x0, [fp, #-0x10]
    // 0x11a7d14: StoreField: r1->field_f = r0
    //     0x11a7d14: stur            w0, [x1, #0xf]
    // 0x11a7d18: ldur            x0, [fp, #-8]
    // 0x11a7d1c: StoreField: r1->field_13 = r0
    //     0x11a7d1c: stur            w0, [x1, #0x13]
    // 0x11a7d20: mov             x0, x1
    // 0x11a7d24: b               #0x11a7db0
    // 0x11a7d28: LoadField: r0 = r4->field_7
    //     0x11a7d28: ldur            w0, [x4, #7]
    // 0x11a7d2c: DecompressPointer r0
    //     0x11a7d2c: add             x0, x0, HEAP, lsl #32
    // 0x11a7d30: stur            x0, [fp, #-0x20]
    // 0x11a7d34: LoadField: r1 = r4->field_b
    //     0x11a7d34: ldur            w1, [x4, #0xb]
    // 0x11a7d38: DecompressPointer r1
    //     0x11a7d38: add             x1, x1, HEAP, lsl #32
    // 0x11a7d3c: stur            x1, [fp, #-0x18]
    // 0x11a7d40: LoadField: r2 = r4->field_f
    //     0x11a7d40: ldur            w2, [x4, #0xf]
    // 0x11a7d44: DecompressPointer r2
    //     0x11a7d44: add             x2, x2, HEAP, lsl #32
    // 0x11a7d48: stur            x2, [fp, #-0x10]
    // 0x11a7d4c: LoadField: r3 = r4->field_13
    //     0x11a7d4c: ldur            w3, [x4, #0x13]
    // 0x11a7d50: DecompressPointer r3
    //     0x11a7d50: add             x3, x3, HEAP, lsl #32
    // 0x11a7d54: stur            x3, [fp, #-8]
    // 0x11a7d58: r0 = BorderRadius()
    //     0x11a7d58: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x11a7d5c: mov             x1, x0
    // 0x11a7d60: ldur            x0, [fp, #-0x20]
    // 0x11a7d64: StoreField: r1->field_7 = r0
    //     0x11a7d64: stur            w0, [x1, #7]
    // 0x11a7d68: ldur            x0, [fp, #-0x18]
    // 0x11a7d6c: StoreField: r1->field_b = r0
    //     0x11a7d6c: stur            w0, [x1, #0xb]
    // 0x11a7d70: ldur            x0, [fp, #-0x10]
    // 0x11a7d74: StoreField: r1->field_f = r0
    //     0x11a7d74: stur            w0, [x1, #0xf]
    // 0x11a7d78: ldur            x0, [fp, #-8]
    // 0x11a7d7c: StoreField: r1->field_13 = r0
    //     0x11a7d7c: stur            w0, [x1, #0x13]
    // 0x11a7d80: mov             x0, x1
    // 0x11a7d84: b               #0x11a7db0
    // 0x11a7d88: cmp             x3, #0xb89
    // 0x11a7d8c: b.ne            #0x11a7d98
    // 0x11a7d90: mov             x0, x4
    // 0x11a7d94: b               #0x11a7db0
    // 0x11a7d98: r0 = LoadClassIdInstr(r4)
    //     0x11a7d98: ldur            x0, [x4, #-1]
    //     0x11a7d9c: ubfx            x0, x0, #0xc, #0x14
    // 0x11a7da0: mov             x1, x4
    // 0x11a7da4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11a7da4: sub             lr, x0, #1, lsl #12
    //     0x11a7da8: ldr             lr, [x21, lr, lsl #3]
    //     0x11a7dac: blr             lr
    // 0x11a7db0: ldur            x2, [fp, #-0x28]
    // 0x11a7db4: stur            x0, [fp, #-8]
    // 0x11a7db8: r1 = Instance_Offset
    //     0x11a7db8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11a7dbc: r0 = &()
    //     0x11a7dbc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x11a7dc0: ldur            x1, [fp, #-8]
    // 0x11a7dc4: mov             x2, x0
    // 0x11a7dc8: r0 = toRRect()
    //     0x11a7dc8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x11a7dcc: mov             x1, x0
    // 0x11a7dd0: ldur            x2, [fp, #-0x30]
    // 0x11a7dd4: r0 = contains()
    //     0x11a7dd4: bl              #0xaf8c9c  ; [dart:ui] RRect::contains
    // 0x11a7dd8: LeaveFrame
    //     0x11a7dd8: mov             SP, fp
    //     0x11a7ddc: ldp             fp, lr, [SP], #0x10
    // 0x11a7de0: ret
    //     0x11a7de0: ret             
    // 0x11a7de4: r0 = true
    //     0x11a7de4: add             x0, NULL, #0x20  ; true
    // 0x11a7de8: LeaveFrame
    //     0x11a7de8: mov             SP, fp
    //     0x11a7dec: ldp             fp, lr, [SP], #0x10
    // 0x11a7df0: ret
    //     0x11a7df0: ret             
    // 0x11a7df4: mov             x0, x1
    // 0x11a7df8: mov             x1, x0
    // 0x11a7dfc: r0 = center()
    //     0x11a7dfc: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0x11a7e00: ldur            x1, [fp, #-0x30]
    // 0x11a7e04: mov             x2, x0
    // 0x11a7e08: r0 = -()
    //     0x11a7e08: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x11a7e0c: LoadField: d0 = r0->field_7
    //     0x11a7e0c: ldur            d0, [x0, #7]
    // 0x11a7e10: fmul            d1, d0, d0
    // 0x11a7e14: LoadField: d0 = r0->field_f
    //     0x11a7e14: ldur            d0, [x0, #0xf]
    // 0x11a7e18: fmul            d2, d0, d0
    // 0x11a7e1c: fadd            d0, d1, d2
    // 0x11a7e20: fsqrt           d1, d0
    // 0x11a7e24: ldur            x1, [fp, #-0x28]
    // 0x11a7e28: LoadField: d0 = r1->field_7
    //     0x11a7e28: ldur            d0, [x1, #7]
    // 0x11a7e2c: LoadField: d2 = r1->field_f
    //     0x11a7e2c: ldur            d2, [x1, #0xf]
    // 0x11a7e30: fmin            v3.2d, v0.2d, v2.2d
    // 0x11a7e34: d0 = 2.000000
    //     0x11a7e34: fmov            d0, #2.00000000
    // 0x11a7e38: fdiv            d2, d3, d0
    // 0x11a7e3c: fcmp            d2, d1
    // 0x11a7e40: r16 = true
    //     0x11a7e40: add             x16, NULL, #0x20  ; true
    // 0x11a7e44: r17 = false
    //     0x11a7e44: add             x17, NULL, #0x30  ; false
    // 0x11a7e48: csel            x0, x16, x17, ge
    // 0x11a7e4c: LeaveFrame
    //     0x11a7e4c: mov             SP, fp
    //     0x11a7e50: ldp             fp, lr, [SP], #0x10
    // 0x11a7e54: ret
    //     0x11a7e54: ret             
    // 0x11a7e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7e5c: b               #0x11a7c80
    // 0x11a7e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a7e60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0x1254fc4, size: 0x54
    // 0x1254fc4: EnterFrame
    //     0x1254fc4: stp             fp, lr, [SP, #-0x10]!
    //     0x1254fc8: mov             fp, SP
    // 0x1254fcc: AllocStack(0x10)
    //     0x1254fcc: sub             SP, SP, #0x10
    // 0x1254fd0: SetupParameters(BoxDecoration this /* r1 => r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0x1254fd0: stur            x1, [fp, #-0x10]
    //     0x1254fd4: ldur            w0, [x4, #0x13]
    //     0x1254fd8: sub             x2, x0, #2
    //     0x1254fdc: cmp             w2, #2
    //     0x1254fe0: b.lt            #0x1254ff0
    //     0x1254fe4: add             x0, fp, w2, sxtw #2
    //     0x1254fe8: ldr             x0, [x0, #8]
    //     0x1254fec: b               #0x1254ff4
    //     0x1254ff0: mov             x0, NULL
    //     0x1254ff4: stur            x0, [fp, #-8]
    // 0x1254ff8: r0 = _BoxDecorationPainter()
    //     0x1254ff8: bl              #0xb7a678  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0x1254ffc: ldur            x1, [fp, #-0x10]
    // 0x1255000: StoreField: r0->field_b = r1
    //     0x1255000: stur            w1, [x0, #0xb]
    // 0x1255004: ldur            x1, [fp, #-8]
    // 0x1255008: StoreField: r0->field_7 = r1
    //     0x1255008: stur            w1, [x0, #7]
    // 0x125500c: LeaveFrame
    //     0x125500c: mov             SP, fp
    //     0x1255010: ldp             fp, lr, [SP], #0x10
    // 0x1255014: ret
    //     0x1255014: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1262d2c, size: 0x240
    // 0x1262d2c: EnterFrame
    //     0x1262d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1262d30: mov             fp, SP
    // 0x1262d34: AllocStack(0x18)
    //     0x1262d34: sub             SP, SP, #0x18
    // 0x1262d38: CheckStackOverflow
    //     0x1262d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1262d3c: cmp             SP, x16
    //     0x1262d40: b.ls            #0x1262f64
    // 0x1262d44: ldr             x0, [fp, #0x10]
    // 0x1262d48: cmp             w0, NULL
    // 0x1262d4c: b.ne            #0x1262d60
    // 0x1262d50: r0 = false
    //     0x1262d50: add             x0, NULL, #0x30  ; false
    // 0x1262d54: LeaveFrame
    //     0x1262d54: mov             SP, fp
    //     0x1262d58: ldp             fp, lr, [SP], #0x10
    // 0x1262d5c: ret
    //     0x1262d5c: ret             
    // 0x1262d60: ldr             x1, [fp, #0x18]
    // 0x1262d64: cmp             w1, w0
    // 0x1262d68: b.ne            #0x1262d7c
    // 0x1262d6c: r0 = true
    //     0x1262d6c: add             x0, NULL, #0x20  ; true
    // 0x1262d70: LeaveFrame
    //     0x1262d70: mov             SP, fp
    //     0x1262d74: ldp             fp, lr, [SP], #0x10
    // 0x1262d78: ret
    //     0x1262d78: ret             
    // 0x1262d7c: str             x0, [SP]
    // 0x1262d80: r0 = runtimeType()
    //     0x1262d80: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1262d84: r1 = LoadClassIdInstr(r0)
    //     0x1262d84: ldur            x1, [x0, #-1]
    //     0x1262d88: ubfx            x1, x1, #0xc, #0x14
    // 0x1262d8c: r16 = BoxDecoration
    //     0x1262d8c: add             x16, PP, #0x80, lsl #12  ; [pp+0x808b8] Type: BoxDecoration
    //     0x1262d90: ldr             x16, [x16, #0x8b8]
    // 0x1262d94: stp             x16, x0, [SP]
    // 0x1262d98: mov             x0, x1
    // 0x1262d9c: mov             lr, x0
    // 0x1262da0: ldr             lr, [x21, lr, lsl #3]
    // 0x1262da4: blr             lr
    // 0x1262da8: tbz             w0, #4, #0x1262dbc
    // 0x1262dac: r0 = false
    //     0x1262dac: add             x0, NULL, #0x30  ; false
    // 0x1262db0: LeaveFrame
    //     0x1262db0: mov             SP, fp
    //     0x1262db4: ldp             fp, lr, [SP], #0x10
    // 0x1262db8: ret
    //     0x1262db8: ret             
    // 0x1262dbc: ldr             x1, [fp, #0x10]
    // 0x1262dc0: r0 = 60
    //     0x1262dc0: mov             x0, #0x3c
    // 0x1262dc4: branchIfSmi(r1, 0x1262dd0)
    //     0x1262dc4: tbz             w1, #0, #0x1262dd0
    // 0x1262dc8: r0 = LoadClassIdInstr(r1)
    //     0x1262dc8: ldur            x0, [x1, #-1]
    //     0x1262dcc: ubfx            x0, x0, #0xc, #0x14
    // 0x1262dd0: r17 = 5238
    //     0x1262dd0: mov             x17, #0x1476
    // 0x1262dd4: cmp             x0, x17
    // 0x1262dd8: b.ne            #0x1262f54
    // 0x1262ddc: ldr             x2, [fp, #0x18]
    // 0x1262de0: LoadField: r0 = r1->field_7
    //     0x1262de0: ldur            w0, [x1, #7]
    // 0x1262de4: DecompressPointer r0
    //     0x1262de4: add             x0, x0, HEAP, lsl #32
    // 0x1262de8: LoadField: r3 = r2->field_7
    //     0x1262de8: ldur            w3, [x2, #7]
    // 0x1262dec: DecompressPointer r3
    //     0x1262dec: add             x3, x3, HEAP, lsl #32
    // 0x1262df0: r4 = LoadClassIdInstr(r0)
    //     0x1262df0: ldur            x4, [x0, #-1]
    //     0x1262df4: ubfx            x4, x4, #0xc, #0x14
    // 0x1262df8: stp             x3, x0, [SP]
    // 0x1262dfc: mov             x0, x4
    // 0x1262e00: mov             lr, x0
    // 0x1262e04: ldr             lr, [x21, lr, lsl #3]
    // 0x1262e08: blr             lr
    // 0x1262e0c: tbnz            w0, #4, #0x1262f54
    // 0x1262e10: ldr             x2, [fp, #0x18]
    // 0x1262e14: ldr             x1, [fp, #0x10]
    // 0x1262e18: LoadField: r0 = r1->field_b
    //     0x1262e18: ldur            w0, [x1, #0xb]
    // 0x1262e1c: DecompressPointer r0
    //     0x1262e1c: add             x0, x0, HEAP, lsl #32
    // 0x1262e20: LoadField: r3 = r2->field_b
    //     0x1262e20: ldur            w3, [x2, #0xb]
    // 0x1262e24: DecompressPointer r3
    //     0x1262e24: add             x3, x3, HEAP, lsl #32
    // 0x1262e28: r4 = LoadClassIdInstr(r0)
    //     0x1262e28: ldur            x4, [x0, #-1]
    //     0x1262e2c: ubfx            x4, x4, #0xc, #0x14
    // 0x1262e30: stp             x3, x0, [SP]
    // 0x1262e34: mov             x0, x4
    // 0x1262e38: mov             lr, x0
    // 0x1262e3c: ldr             lr, [x21, lr, lsl #3]
    // 0x1262e40: blr             lr
    // 0x1262e44: tbnz            w0, #4, #0x1262f54
    // 0x1262e48: ldr             x2, [fp, #0x18]
    // 0x1262e4c: ldr             x1, [fp, #0x10]
    // 0x1262e50: LoadField: r0 = r1->field_f
    //     0x1262e50: ldur            w0, [x1, #0xf]
    // 0x1262e54: DecompressPointer r0
    //     0x1262e54: add             x0, x0, HEAP, lsl #32
    // 0x1262e58: LoadField: r3 = r2->field_f
    //     0x1262e58: ldur            w3, [x2, #0xf]
    // 0x1262e5c: DecompressPointer r3
    //     0x1262e5c: add             x3, x3, HEAP, lsl #32
    // 0x1262e60: r4 = LoadClassIdInstr(r0)
    //     0x1262e60: ldur            x4, [x0, #-1]
    //     0x1262e64: ubfx            x4, x4, #0xc, #0x14
    // 0x1262e68: stp             x3, x0, [SP]
    // 0x1262e6c: mov             x0, x4
    // 0x1262e70: mov             lr, x0
    // 0x1262e74: ldr             lr, [x21, lr, lsl #3]
    // 0x1262e78: blr             lr
    // 0x1262e7c: tbnz            w0, #4, #0x1262f54
    // 0x1262e80: ldr             x2, [fp, #0x18]
    // 0x1262e84: ldr             x1, [fp, #0x10]
    // 0x1262e88: LoadField: r0 = r1->field_13
    //     0x1262e88: ldur            w0, [x1, #0x13]
    // 0x1262e8c: DecompressPointer r0
    //     0x1262e8c: add             x0, x0, HEAP, lsl #32
    // 0x1262e90: LoadField: r3 = r2->field_13
    //     0x1262e90: ldur            w3, [x2, #0x13]
    // 0x1262e94: DecompressPointer r3
    //     0x1262e94: add             x3, x3, HEAP, lsl #32
    // 0x1262e98: r4 = LoadClassIdInstr(r0)
    //     0x1262e98: ldur            x4, [x0, #-1]
    //     0x1262e9c: ubfx            x4, x4, #0xc, #0x14
    // 0x1262ea0: stp             x3, x0, [SP]
    // 0x1262ea4: mov             x0, x4
    // 0x1262ea8: mov             lr, x0
    // 0x1262eac: ldr             lr, [x21, lr, lsl #3]
    // 0x1262eb0: blr             lr
    // 0x1262eb4: tbnz            w0, #4, #0x1262f54
    // 0x1262eb8: ldr             x1, [fp, #0x18]
    // 0x1262ebc: ldr             x0, [fp, #0x10]
    // 0x1262ec0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1262ec0: ldur            w2, [x0, #0x17]
    // 0x1262ec4: DecompressPointer r2
    //     0x1262ec4: add             x2, x2, HEAP, lsl #32
    // 0x1262ec8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1262ec8: ldur            w3, [x1, #0x17]
    // 0x1262ecc: DecompressPointer r3
    //     0x1262ecc: add             x3, x3, HEAP, lsl #32
    // 0x1262ed0: r16 = <BoxShadow>
    //     0x1262ed0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16cf0] TypeArguments: <BoxShadow>
    //     0x1262ed4: ldr             x16, [x16, #0xcf0]
    // 0x1262ed8: stp             x2, x16, [SP, #8]
    // 0x1262edc: str             x3, [SP]
    // 0x1262ee0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1262ee0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1262ee4: r0 = listEquals()
    //     0x1262ee4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1262ee8: tbnz            w0, #4, #0x1262f54
    // 0x1262eec: ldr             x2, [fp, #0x18]
    // 0x1262ef0: ldr             x1, [fp, #0x10]
    // 0x1262ef4: LoadField: r0 = r1->field_1b
    //     0x1262ef4: ldur            w0, [x1, #0x1b]
    // 0x1262ef8: DecompressPointer r0
    //     0x1262ef8: add             x0, x0, HEAP, lsl #32
    // 0x1262efc: LoadField: r3 = r2->field_1b
    //     0x1262efc: ldur            w3, [x2, #0x1b]
    // 0x1262f00: DecompressPointer r3
    //     0x1262f00: add             x3, x3, HEAP, lsl #32
    // 0x1262f04: r4 = LoadClassIdInstr(r0)
    //     0x1262f04: ldur            x4, [x0, #-1]
    //     0x1262f08: ubfx            x4, x4, #0xc, #0x14
    // 0x1262f0c: stp             x3, x0, [SP]
    // 0x1262f10: mov             x0, x4
    // 0x1262f14: mov             lr, x0
    // 0x1262f18: ldr             lr, [x21, lr, lsl #3]
    // 0x1262f1c: blr             lr
    // 0x1262f20: tbnz            w0, #4, #0x1262f54
    // 0x1262f24: ldr             x2, [fp, #0x18]
    // 0x1262f28: ldr             x1, [fp, #0x10]
    // 0x1262f2c: LoadField: r3 = r1->field_23
    //     0x1262f2c: ldur            w3, [x1, #0x23]
    // 0x1262f30: DecompressPointer r3
    //     0x1262f30: add             x3, x3, HEAP, lsl #32
    // 0x1262f34: LoadField: r1 = r2->field_23
    //     0x1262f34: ldur            w1, [x2, #0x23]
    // 0x1262f38: DecompressPointer r1
    //     0x1262f38: add             x1, x1, HEAP, lsl #32
    // 0x1262f3c: cmp             w3, w1
    // 0x1262f40: r16 = true
    //     0x1262f40: add             x16, NULL, #0x20  ; true
    // 0x1262f44: r17 = false
    //     0x1262f44: add             x17, NULL, #0x30  ; false
    // 0x1262f48: csel            x2, x16, x17, eq
    // 0x1262f4c: mov             x0, x2
    // 0x1262f50: b               #0x1262f58
    // 0x1262f54: r0 = false
    //     0x1262f54: add             x0, NULL, #0x30  ; false
    // 0x1262f58: LeaveFrame
    //     0x1262f58: mov             SP, fp
    //     0x1262f5c: ldp             fp, lr, [SP], #0x10
    // 0x1262f60: ret
    //     0x1262f60: ret             
    // 0x1262f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1262f64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1262f68: b               #0x1262d44
  }
}
