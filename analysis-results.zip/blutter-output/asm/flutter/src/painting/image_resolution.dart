// lib: , url: package:flutter/src/painting/image_resolution.dart

// class id: 1048999, size: 0x8
class :: {
}

// class id: 3599, size: 0x18, field offset: 0xc
//   const constructor, 
class AssetImage extends AssetBundleImageProvider {

  _OneByteString field_c;

  get _ hashCode(/* No info */) {
    // ** addr: 0x1149328, size: 0x58
    // 0x1149328: EnterFrame
    //     0x1149328: stp             fp, lr, [SP, #-0x10]!
    //     0x114932c: mov             fp, SP
    // 0x1149330: CheckStackOverflow
    //     0x1149330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149334: cmp             SP, x16
    //     0x1149338: b.ls            #0x1149378
    // 0x114933c: ldr             x1, [fp, #0x10]
    // 0x1149340: r0 = keyName()
    //     0x1149340: bl              #0x1149380  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::keyName
    // 0x1149344: mov             x1, x0
    // 0x1149348: r2 = Null
    //     0x1149348: mov             x2, NULL
    // 0x114934c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x114934c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1149350: r0 = hash()
    //     0x1149350: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1149354: mov             x2, x0
    // 0x1149358: r0 = BoxInt64Instr(r2)
    //     0x1149358: sbfiz           x0, x2, #1, #0x1f
    //     0x114935c: cmp             x2, x0, asr #1
    //     0x1149360: b.eq            #0x114936c
    //     0x1149364: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149368: stur            x2, [x0, #7]
    // 0x114936c: LeaveFrame
    //     0x114936c: mov             SP, fp
    //     0x1149370: ldp             fp, lr, [SP], #0x10
    // 0x1149374: ret
    //     0x1149374: ret             
    // 0x1149378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114937c: b               #0x114933c
  }
  get _ keyName(/* No info */) {
    // ** addr: 0x1149380, size: 0x94
    // 0x1149380: EnterFrame
    //     0x1149380: stp             fp, lr, [SP, #-0x10]!
    //     0x1149384: mov             fp, SP
    // 0x1149388: AllocStack(0x18)
    //     0x1149388: sub             SP, SP, #0x18
    // 0x114938c: SetupParameters(AssetImage this /* r1 => r0, fp-0x10 */)
    //     0x114938c: mov             x0, x1
    //     0x1149390: stur            x1, [fp, #-0x10]
    // 0x1149394: CheckStackOverflow
    //     0x1149394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1149398: cmp             SP, x16
    //     0x114939c: b.ls            #0x114940c
    // 0x11493a0: LoadField: r3 = r0->field_13
    //     0x11493a0: ldur            w3, [x0, #0x13]
    // 0x11493a4: DecompressPointer r3
    //     0x11493a4: add             x3, x3, HEAP, lsl #32
    // 0x11493a8: stur            x3, [fp, #-8]
    // 0x11493ac: cmp             w3, NULL
    // 0x11493b0: b.ne            #0x11493c4
    // 0x11493b4: LoadField: r1 = r0->field_b
    //     0x11493b4: ldur            w1, [x0, #0xb]
    // 0x11493b8: DecompressPointer r1
    //     0x11493b8: add             x1, x1, HEAP, lsl #32
    // 0x11493bc: mov             x0, x1
    // 0x11493c0: b               #0x1149400
    // 0x11493c4: r1 = Null
    //     0x11493c4: mov             x1, NULL
    // 0x11493c8: r2 = 8
    //     0x11493c8: mov             x2, #8
    // 0x11493cc: r0 = AllocateArray()
    //     0x11493cc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11493d0: r16 = "packages/"
    //     0x11493d0: ldr             x16, [PP, #0x4b20]  ; [pp+0x4b20] "packages/"
    // 0x11493d4: StoreField: r0->field_f = r16
    //     0x11493d4: stur            w16, [x0, #0xf]
    // 0x11493d8: ldur            x1, [fp, #-8]
    // 0x11493dc: StoreField: r0->field_13 = r1
    //     0x11493dc: stur            w1, [x0, #0x13]
    // 0x11493e0: r16 = "/"
    //     0x11493e0: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x11493e4: ArrayStore: r0[0] = r16  ; List_4
    //     0x11493e4: stur            w16, [x0, #0x17]
    // 0x11493e8: ldur            x1, [fp, #-0x10]
    // 0x11493ec: LoadField: r2 = r1->field_b
    //     0x11493ec: ldur            w2, [x1, #0xb]
    // 0x11493f0: DecompressPointer r2
    //     0x11493f0: add             x2, x2, HEAP, lsl #32
    // 0x11493f4: StoreField: r0->field_1b = r2
    //     0x11493f4: stur            w2, [x0, #0x1b]
    // 0x11493f8: str             x0, [SP]
    // 0x11493fc: r0 = _interpolate()
    //     0x11493fc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1149400: LeaveFrame
    //     0x1149400: mov             SP, fp
    //     0x1149404: ldp             fp, lr, [SP], #0x10
    // 0x1149408: ret
    //     0x1149408: ret             
    // 0x114940c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114940c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149410: b               #0x11493a0
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0x115a904, size: 0x1ac
    // 0x115a904: EnterFrame
    //     0x115a904: stp             fp, lr, [SP, #-0x10]!
    //     0x115a908: mov             fp, SP
    // 0x115a90c: AllocStack(0x30)
    //     0x115a90c: sub             SP, SP, #0x30
    // 0x115a910: SetupParameters(AssetImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x115a910: stur            x1, [fp, #-8]
    //     0x115a914: stur            x2, [fp, #-0x10]
    // 0x115a918: CheckStackOverflow
    //     0x115a918: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115a91c: cmp             SP, x16
    //     0x115a920: b.ls            #0x115aaa8
    // 0x115a924: r1 = 5
    //     0x115a924: mov             x1, #5
    // 0x115a928: r0 = AllocateContext()
    //     0x115a928: bl              #0x13de838  ; AllocateContextStub
    // 0x115a92c: mov             x1, x0
    // 0x115a930: ldur            x0, [fp, #-8]
    // 0x115a934: stur            x1, [fp, #-0x18]
    // 0x115a938: StoreField: r1->field_f = r0
    //     0x115a938: stur            w0, [x1, #0xf]
    // 0x115a93c: ldur            x0, [fp, #-0x10]
    // 0x115a940: StoreField: r1->field_13 = r0
    //     0x115a940: stur            w0, [x1, #0x13]
    // 0x115a944: LoadField: r2 = r0->field_7
    //     0x115a944: ldur            w2, [x0, #7]
    // 0x115a948: DecompressPointer r2
    //     0x115a948: add             x2, x2, HEAP, lsl #32
    // 0x115a94c: cmp             w2, NULL
    // 0x115a950: b.ne            #0x115a978
    // 0x115a954: r0 = LoadStaticField(0x824)
    //     0x115a954: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x115a958: ldr             x0, [x0, #0x1048]
    // 0x115a95c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115a960: cmp             w0, w16
    // 0x115a964: b.ne            #0x115a970
    // 0x115a968: r2 = rootBundle
    //     0x115a968: ldr             x2, [PP, #0x3508]  ; [pp+0x3508] Field <::.rootBundle>: static late final (offset: 0x824)
    // 0x115a96c: r0 = InitLateFinalStaticField()
    //     0x115a96c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x115a970: mov             x1, x0
    // 0x115a974: b               #0x115a97c
    // 0x115a978: mov             x1, x2
    // 0x115a97c: ldur            x2, [fp, #-0x18]
    // 0x115a980: ArrayStore: r2[0] = r1  ; List_4
    //     0x115a980: stur            w1, [x2, #0x17]
    // 0x115a984: StoreField: r2->field_1b = rNULL
    //     0x115a984: stur            NULL, [x2, #0x1b]
    // 0x115a988: StoreField: r2->field_1f = rNULL
    //     0x115a988: stur            NULL, [x2, #0x1f]
    // 0x115a98c: r0 = loadFromAssetBundle()
    //     0x115a98c: bl              #0xeb3b28  ; [package:flutter/src/services/asset_manifest.dart] AssetManifest::loadFromAssetBundle
    // 0x115a990: ldur            x2, [fp, #-0x18]
    // 0x115a994: r1 = Function '<anonymous closure>':.
    //     0x115a994: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c458] AnonymousClosure: (0x115b12c), in [package:flutter/src/painting/image_resolution.dart] AssetImage::obtainKey (0x115a904)
    //     0x115a998: ldr             x1, [x1, #0x458]
    // 0x115a99c: stur            x0, [fp, #-8]
    // 0x115a9a0: r0 = AllocateClosure()
    //     0x115a9a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x115a9a4: mov             x1, x0
    // 0x115a9a8: ldur            x0, [fp, #-8]
    // 0x115a9ac: r2 = LoadClassIdInstr(r0)
    //     0x115a9ac: ldur            x2, [x0, #-1]
    //     0x115a9b0: ubfx            x2, x2, #0xc, #0x14
    // 0x115a9b4: r16 = <Null?>
    //     0x115a9b4: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x115a9b8: stp             x0, x16, [SP, #8]
    // 0x115a9bc: str             x1, [SP]
    // 0x115a9c0: mov             x0, x2
    // 0x115a9c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x115a9c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x115a9c8: r0 = GDT[cid_x0 + -0xfef]()
    //     0x115a9c8: sub             lr, x0, #0xfef
    //     0x115a9cc: ldr             lr, [x21, lr, lsl #3]
    //     0x115a9d0: blr             lr
    // 0x115a9d4: ldur            x2, [fp, #-0x18]
    // 0x115a9d8: r1 = Function '<anonymous closure>':.
    //     0x115a9d8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c460] AnonymousClosure: (0x115b0c4), in [package:flutter/src/painting/image_resolution.dart] AssetImage::obtainKey (0x115a904)
    //     0x115a9dc: ldr             x1, [x1, #0x460]
    // 0x115a9e0: stur            x0, [fp, #-8]
    // 0x115a9e4: r0 = AllocateClosure()
    //     0x115a9e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x115a9e8: r16 = <Null?, Object>
    //     0x115a9e8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c468] TypeArguments: <Null?, Object>
    //     0x115a9ec: ldr             x16, [x16, #0x468]
    // 0x115a9f0: ldur            lr, [fp, #-8]
    // 0x115a9f4: stp             lr, x16, [SP, #8]
    // 0x115a9f8: str             x0, [SP]
    // 0x115a9fc: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x115a9fc: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x115aa00: r0 = FutureExtensions.onError()
    //     0x115aa00: bl              #0x115aab0  ; [dart:async] ::FutureExtensions.onError
    // 0x115aa04: ldur            x0, [fp, #-0x18]
    // 0x115aa08: LoadField: r1 = r0->field_1f
    //     0x115aa08: ldur            w1, [x0, #0x1f]
    // 0x115aa0c: DecompressPointer r1
    //     0x115aa0c: add             x1, x1, HEAP, lsl #32
    // 0x115aa10: cmp             w1, NULL
    // 0x115aa14: b.eq            #0x115aa28
    // 0x115aa18: mov             x0, x1
    // 0x115aa1c: LeaveFrame
    //     0x115aa1c: mov             SP, fp
    //     0x115aa20: ldp             fp, lr, [SP], #0x10
    // 0x115aa24: ret
    //     0x115aa24: ret             
    // 0x115aa28: r1 = <AssetBundleImageKey>
    //     0x115aa28: add             x1, PP, #0x16, lsl #12  ; [pp+0x16fc8] TypeArguments: <AssetBundleImageKey>
    //     0x115aa2c: ldr             x1, [x1, #0xfc8]
    // 0x115aa30: r0 = _Future()
    //     0x115aa30: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x115aa34: stur            x0, [fp, #-8]
    // 0x115aa38: StoreField: r0->field_b = rZR
    //     0x115aa38: stur            xzr, [x0, #0xb]
    // 0x115aa3c: r0 = LoadStaticField(0x364)
    //     0x115aa3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x115aa40: ldr             x0, [x0, #0x6c8]
    // 0x115aa44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115aa48: cmp             w0, w16
    // 0x115aa4c: b.ne            #0x115aa58
    // 0x115aa50: r2 = _current
    //     0x115aa50: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x115aa54: r0 = InitLateStaticField()
    //     0x115aa54: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x115aa58: mov             x1, x0
    // 0x115aa5c: ldur            x0, [fp, #-8]
    // 0x115aa60: StoreField: r0->field_13 = r1
    //     0x115aa60: stur            w1, [x0, #0x13]
    // 0x115aa64: r1 = <AssetBundleImageKey>
    //     0x115aa64: add             x1, PP, #0x16, lsl #12  ; [pp+0x16fc8] TypeArguments: <AssetBundleImageKey>
    //     0x115aa68: ldr             x1, [x1, #0xfc8]
    // 0x115aa6c: r0 = _AsyncCompleter()
    //     0x115aa6c: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x115aa70: ldur            x1, [fp, #-8]
    // 0x115aa74: StoreField: r0->field_b = r1
    //     0x115aa74: stur            w1, [x0, #0xb]
    // 0x115aa78: ldur            x2, [fp, #-0x18]
    // 0x115aa7c: StoreField: r2->field_1b = r0
    //     0x115aa7c: stur            w0, [x2, #0x1b]
    //     0x115aa80: ldurb           w16, [x2, #-1]
    //     0x115aa84: ldurb           w17, [x0, #-1]
    //     0x115aa88: and             x16, x17, x16, lsr #2
    //     0x115aa8c: tst             x16, HEAP, lsr #32
    //     0x115aa90: b.eq            #0x115aa98
    //     0x115aa94: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x115aa98: mov             x0, x1
    // 0x115aa9c: LeaveFrame
    //     0x115aa9c: mov             SP, fp
    //     0x115aaa0: ldp             fp, lr, [SP], #0x10
    // 0x115aaa4: ret
    //     0x115aaa4: ret             
    // 0x115aaa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115aaa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115aaac: b               #0x115a924
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x115b0c4, size: 0x68
    // 0x115b0c4: EnterFrame
    //     0x115b0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x115b0c8: mov             fp, SP
    // 0x115b0cc: AllocStack(0x8)
    //     0x115b0cc: sub             SP, SP, #8
    // 0x115b0d0: SetupParameters([dynamic _ /* r0 */])
    //     0x115b0d0: ldr             x0, [fp, #0x20]
    //     0x115b0d4: ldur            w1, [x0, #0x17]
    //     0x115b0d8: add             x1, x1, HEAP, lsl #32
    // 0x115b0dc: CheckStackOverflow
    //     0x115b0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115b0e0: cmp             SP, x16
    //     0x115b0e4: b.ls            #0x115b120
    // 0x115b0e8: LoadField: r0 = r1->field_1b
    //     0x115b0e8: ldur            w0, [x1, #0x1b]
    // 0x115b0ec: DecompressPointer r0
    //     0x115b0ec: add             x0, x0, HEAP, lsl #32
    // 0x115b0f0: cmp             w0, NULL
    // 0x115b0f4: b.eq            #0x115b128
    // 0x115b0f8: ldr             x16, [fp, #0x10]
    // 0x115b0fc: str             x16, [SP]
    // 0x115b100: mov             x1, x0
    // 0x115b104: ldr             x2, [fp, #0x18]
    // 0x115b108: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x115b108: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x115b10c: r0 = completeError()
    //     0x115b10c: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x115b110: r0 = Null
    //     0x115b110: mov             x0, NULL
    // 0x115b114: LeaveFrame
    //     0x115b114: mov             SP, fp
    //     0x115b118: ldp             fp, lr, [SP], #0x10
    // 0x115b11c: ret
    //     0x115b11c: ret             
    // 0x115b120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115b120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115b124: b               #0x115b0e8
    // 0x115b128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, AssetManifest) {
    // ** addr: 0x115b12c, size: 0x150
    // 0x115b12c: EnterFrame
    //     0x115b12c: stp             fp, lr, [SP, #-0x10]!
    //     0x115b130: mov             fp, SP
    // 0x115b134: AllocStack(0x30)
    //     0x115b134: sub             SP, SP, #0x30
    // 0x115b138: SetupParameters([dynamic _ /* r0 */])
    //     0x115b138: ldr             x0, [fp, #0x18]
    //     0x115b13c: ldur            w2, [x0, #0x17]
    //     0x115b140: add             x2, x2, HEAP, lsl #32
    //     0x115b144: stur            x2, [fp, #-8]
    // 0x115b148: CheckStackOverflow
    //     0x115b148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115b14c: cmp             SP, x16
    //     0x115b150: b.ls            #0x115b274
    // 0x115b154: LoadField: r1 = r2->field_f
    //     0x115b154: ldur            w1, [x2, #0xf]
    // 0x115b158: DecompressPointer r1
    //     0x115b158: add             x1, x1, HEAP, lsl #32
    // 0x115b15c: r0 = keyName()
    //     0x115b15c: bl              #0x1149380  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::keyName
    // 0x115b160: ldr             x1, [fp, #0x10]
    // 0x115b164: mov             x2, x0
    // 0x115b168: r0 = getAssetVariants()
    //     0x115b168: bl              #0x115bac0  ; [package:flutter/src/services/asset_manifest.dart] _AssetManifestBin::getAssetVariants
    // 0x115b16c: mov             x2, x0
    // 0x115b170: ldur            x0, [fp, #-8]
    // 0x115b174: stur            x2, [fp, #-0x18]
    // 0x115b178: LoadField: r3 = r0->field_f
    //     0x115b178: ldur            w3, [x0, #0xf]
    // 0x115b17c: DecompressPointer r3
    //     0x115b17c: add             x3, x3, HEAP, lsl #32
    // 0x115b180: mov             x1, x3
    // 0x115b184: stur            x3, [fp, #-0x10]
    // 0x115b188: r0 = keyName()
    //     0x115b188: bl              #0x1149380  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::keyName
    // 0x115b18c: mov             x1, x0
    // 0x115b190: ldur            x0, [fp, #-8]
    // 0x115b194: LoadField: r3 = r0->field_13
    //     0x115b194: ldur            w3, [x0, #0x13]
    // 0x115b198: DecompressPointer r3
    //     0x115b198: add             x3, x3, HEAP, lsl #32
    // 0x115b19c: mov             x2, x1
    // 0x115b1a0: ldur            x1, [fp, #-0x10]
    // 0x115b1a4: ldur            x5, [fp, #-0x18]
    // 0x115b1a8: r0 = _chooseVariant()
    //     0x115b1a8: bl              #0x115b288  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_chooseVariant
    // 0x115b1ac: LoadField: r1 = r0->field_b
    //     0x115b1ac: ldur            w1, [x0, #0xb]
    // 0x115b1b0: DecompressPointer r1
    //     0x115b1b0: add             x1, x1, HEAP, lsl #32
    // 0x115b1b4: stur            x1, [fp, #-0x18]
    // 0x115b1b8: LoadField: r2 = r0->field_7
    //     0x115b1b8: ldur            w2, [x0, #7]
    // 0x115b1bc: DecompressPointer r2
    //     0x115b1bc: add             x2, x2, HEAP, lsl #32
    // 0x115b1c0: cmp             w2, NULL
    // 0x115b1c4: b.ne            #0x115b1d0
    // 0x115b1c8: d0 = 1.000000
    //     0x115b1c8: fmov            d0, #1.00000000
    // 0x115b1cc: b               #0x115b1d4
    // 0x115b1d0: LoadField: d0 = r2->field_7
    //     0x115b1d0: ldur            d0, [x2, #7]
    // 0x115b1d4: ldur            x0, [fp, #-8]
    // 0x115b1d8: stur            d0, [fp, #-0x28]
    // 0x115b1dc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x115b1dc: ldur            w2, [x0, #0x17]
    // 0x115b1e0: DecompressPointer r2
    //     0x115b1e0: add             x2, x2, HEAP, lsl #32
    // 0x115b1e4: stur            x2, [fp, #-0x10]
    // 0x115b1e8: r0 = AssetBundleImageKey()
    //     0x115b1e8: bl              #0x115b27c  ; AllocateAssetBundleImageKeyStub -> AssetBundleImageKey (size=0x18)
    // 0x115b1ec: mov             x2, x0
    // 0x115b1f0: ldur            x0, [fp, #-0x10]
    // 0x115b1f4: stur            x2, [fp, #-0x20]
    // 0x115b1f8: StoreField: r2->field_7 = r0
    //     0x115b1f8: stur            w0, [x2, #7]
    // 0x115b1fc: ldur            x0, [fp, #-0x18]
    // 0x115b200: StoreField: r2->field_b = r0
    //     0x115b200: stur            w0, [x2, #0xb]
    // 0x115b204: ldur            d0, [fp, #-0x28]
    // 0x115b208: StoreField: r2->field_f = d0
    //     0x115b208: stur            d0, [x2, #0xf]
    // 0x115b20c: ldur            x0, [fp, #-8]
    // 0x115b210: LoadField: r1 = r0->field_1b
    //     0x115b210: ldur            w1, [x0, #0x1b]
    // 0x115b214: DecompressPointer r1
    //     0x115b214: add             x1, x1, HEAP, lsl #32
    // 0x115b218: cmp             w1, NULL
    // 0x115b21c: b.eq            #0x115b230
    // 0x115b220: str             x2, [SP]
    // 0x115b224: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x115b224: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x115b228: r0 = complete()
    //     0x115b228: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x115b22c: b               #0x115b264
    // 0x115b230: r1 = <AssetBundleImageKey>
    //     0x115b230: add             x1, PP, #0x16, lsl #12  ; [pp+0x16fc8] TypeArguments: <AssetBundleImageKey>
    //     0x115b234: ldr             x1, [x1, #0xfc8]
    // 0x115b238: r0 = SynchronousFuture()
    //     0x115b238: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x115b23c: ldur            x1, [fp, #-0x20]
    // 0x115b240: StoreField: r0->field_b = r1
    //     0x115b240: stur            w1, [x0, #0xb]
    // 0x115b244: ldur            x1, [fp, #-8]
    // 0x115b248: StoreField: r1->field_1f = r0
    //     0x115b248: stur            w0, [x1, #0x1f]
    //     0x115b24c: ldurb           w16, [x1, #-1]
    //     0x115b250: ldurb           w17, [x0, #-1]
    //     0x115b254: and             x16, x17, x16, lsr #2
    //     0x115b258: tst             x16, HEAP, lsr #32
    //     0x115b25c: b.eq            #0x115b264
    //     0x115b260: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x115b264: r0 = Null
    //     0x115b264: mov             x0, NULL
    // 0x115b268: LeaveFrame
    //     0x115b268: mov             SP, fp
    //     0x115b26c: ldp             fp, lr, [SP], #0x10
    // 0x115b270: ret
    //     0x115b270: ret             
    // 0x115b274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115b274: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115b278: b               #0x115b154
  }
  _ _chooseVariant(/* No info */) {
    // ** addr: 0x115b288, size: 0x2b8
    // 0x115b288: EnterFrame
    //     0x115b288: stp             fp, lr, [SP, #-0x10]!
    //     0x115b28c: mov             fp, SP
    // 0x115b290: AllocStack(0x40)
    //     0x115b290: sub             SP, SP, #0x40
    // 0x115b294: SetupParameters(AssetImage this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */)
    //     0x115b294: mov             x4, x2
    //     0x115b298: stur            x2, [fp, #-0x10]
    //     0x115b29c: mov             x2, x5
    //     0x115b2a0: stur            x5, [fp, #-0x20]
    //     0x115b2a4: mov             x5, x1
    //     0x115b2a8: stur            x1, [fp, #-8]
    //     0x115b2ac: stur            x3, [fp, #-0x18]
    // 0x115b2b0: CheckStackOverflow
    //     0x115b2b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115b2b4: cmp             SP, x16
    //     0x115b2b8: b.ls            #0x115b510
    // 0x115b2bc: cmp             w2, NULL
    // 0x115b2c0: b.ne            #0x115b2cc
    // 0x115b2c4: mov             x0, x4
    // 0x115b2c8: b               #0x115b314
    // 0x115b2cc: r0 = LoadClassIdInstr(r2)
    //     0x115b2cc: ldur            x0, [x2, #-1]
    //     0x115b2d0: ubfx            x0, x0, #0xc, #0x14
    // 0x115b2d4: mov             x1, x2
    // 0x115b2d8: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x115b2d8: mov             x17, #0x2b36
    //     0x115b2dc: movk            x17, #1, lsl #16
    //     0x115b2e0: add             lr, x0, x17
    //     0x115b2e4: ldr             lr, [x21, lr, lsl #3]
    //     0x115b2e8: blr             lr
    // 0x115b2ec: tbnz            w0, #4, #0x115b2f8
    // 0x115b2f0: ldur            x0, [fp, #-0x10]
    // 0x115b2f4: b               #0x115b314
    // 0x115b2f8: ldur            x0, [fp, #-0x18]
    // 0x115b2fc: LoadField: r2 = r0->field_b
    //     0x115b2fc: ldur            w2, [x0, #0xb]
    // 0x115b300: DecompressPointer r2
    //     0x115b300: add             x2, x2, HEAP, lsl #32
    // 0x115b304: stur            x2, [fp, #-0x28]
    // 0x115b308: cmp             w2, NULL
    // 0x115b30c: b.ne            #0x115b334
    // 0x115b310: ldur            x0, [fp, #-0x10]
    // 0x115b314: r0 = AssetMetadata()
    //     0x115b314: bl              #0x115b9f0  ; AllocateAssetMetadataStub -> AssetMetadata (size=0x10)
    // 0x115b318: mov             x1, x0
    // 0x115b31c: ldur            x0, [fp, #-0x10]
    // 0x115b320: StoreField: r1->field_b = r0
    //     0x115b320: stur            w0, [x1, #0xb]
    // 0x115b324: mov             x0, x1
    // 0x115b328: LeaveFrame
    //     0x115b328: mov             SP, fp
    //     0x115b32c: ldp             fp, lr, [SP], #0x10
    // 0x115b330: ret
    //     0x115b330: ret             
    // 0x115b334: ldur            x0, [fp, #-0x20]
    // 0x115b338: r1 = <double, _SplayTreeMapNode<double, AssetMetadata>, double, AssetMetadata>
    //     0x115b338: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c470] TypeArguments: <double, _SplayTreeMapNode<double, AssetMetadata>, double, AssetMetadata>
    //     0x115b33c: ldr             x1, [x1, #0x470]
    // 0x115b340: r0 = SplayTreeMap()
    //     0x115b340: bl              #0xbb3158  ; AllocateSplayTreeMapStub -> SplayTreeMap<C2X0, C2X1> (size=0x30)
    // 0x115b344: mov             x1, x0
    // 0x115b348: stur            x0, [fp, #-0x10]
    // 0x115b34c: r0 = SplayTreeMap()
    //     0x115b34c: bl              #0xbb2fac  ; [dart:collection] SplayTreeMap::SplayTreeMap
    // 0x115b350: ldur            x1, [fp, #-0x20]
    // 0x115b354: r0 = LoadClassIdInstr(r1)
    //     0x115b354: ldur            x0, [x1, #-1]
    //     0x115b358: ubfx            x0, x0, #0xc, #0x14
    // 0x115b35c: r0 = GDT[cid_x0 + 0x12641]()
    //     0x115b35c: mov             x17, #0x2641
    //     0x115b360: movk            x17, #1, lsl #16
    //     0x115b364: add             lr, x0, x17
    //     0x115b368: ldr             lr, [x21, lr, lsl #3]
    //     0x115b36c: blr             lr
    // 0x115b370: mov             x2, x0
    // 0x115b374: stur            x2, [fp, #-0x18]
    // 0x115b378: ldur            x3, [fp, #-0x10]
    // 0x115b37c: CheckStackOverflow
    //     0x115b37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115b380: cmp             SP, x16
    //     0x115b384: b.ls            #0x115b518
    // 0x115b388: r0 = LoadClassIdInstr(r2)
    //     0x115b388: ldur            x0, [x2, #-1]
    //     0x115b38c: ubfx            x0, x0, #0xc, #0x14
    // 0x115b390: mov             x1, x2
    // 0x115b394: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x115b394: mov             x17, #0x845b
    //     0x115b398: movk            x17, #1, lsl #16
    //     0x115b39c: add             lr, x0, x17
    //     0x115b3a0: ldr             lr, [x21, lr, lsl #3]
    //     0x115b3a4: blr             lr
    // 0x115b3a8: tbnz            w0, #4, #0x115b4f0
    // 0x115b3ac: ldur            x2, [fp, #-0x18]
    // 0x115b3b0: r0 = LoadClassIdInstr(r2)
    //     0x115b3b0: ldur            x0, [x2, #-1]
    //     0x115b3b4: ubfx            x0, x0, #0xc, #0x14
    // 0x115b3b8: mov             x1, x2
    // 0x115b3bc: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x115b3bc: mov             x17, #0x7d4c
    //     0x115b3c0: movk            x17, #1, lsl #16
    //     0x115b3c4: add             lr, x0, x17
    //     0x115b3c8: ldr             lr, [x21, lr, lsl #3]
    //     0x115b3cc: blr             lr
    // 0x115b3d0: stur            x0, [fp, #-0x30]
    // 0x115b3d4: LoadField: r1 = r0->field_7
    //     0x115b3d4: ldur            w1, [x0, #7]
    // 0x115b3d8: DecompressPointer r1
    //     0x115b3d8: add             x1, x1, HEAP, lsl #32
    // 0x115b3dc: cmp             w1, NULL
    // 0x115b3e0: b.ne            #0x115b3ec
    // 0x115b3e4: d0 = 1.000000
    //     0x115b3e4: fmov            d0, #1.00000000
    // 0x115b3e8: b               #0x115b3f0
    // 0x115b3ec: LoadField: d0 = r1->field_7
    //     0x115b3ec: ldur            d0, [x1, #7]
    // 0x115b3f0: r3 = inline_Allocate_Double()
    //     0x115b3f0: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x115b3f4: add             x3, x3, #0x10
    //     0x115b3f8: cmp             x1, x3
    //     0x115b3fc: b.ls            #0x115b520
    //     0x115b400: str             x3, [THR, #0x60]  ; THR::top
    //     0x115b404: sub             x3, x3, #0xf
    //     0x115b408: mov             x1, #0xe19c
    //     0x115b40c: movk            x1, #3, lsl #16
    //     0x115b410: stur            x1, [x3, #-1]
    // 0x115b414: dmb             ishst
    // 0x115b418: StoreField: r3->field_7 = d0
    //     0x115b418: stur            d0, [x3, #7]
    // 0x115b41c: ldur            x1, [fp, #-0x10]
    // 0x115b420: mov             x2, x3
    // 0x115b424: stur            x3, [fp, #-0x20]
    // 0x115b428: r0 = _splay()
    //     0x115b428: bl              #0x803590  ; [dart:collection] _SplayTree::_splay
    // 0x115b42c: stur            x0, [fp, #-0x40]
    // 0x115b430: cbnz            x0, #0x115b4b0
    // 0x115b434: ldur            x3, [fp, #-0x10]
    // 0x115b438: LoadField: r4 = r3->field_23
    //     0x115b438: ldur            w4, [x3, #0x23]
    // 0x115b43c: DecompressPointer r4
    //     0x115b43c: add             x4, x4, HEAP, lsl #32
    // 0x115b440: stur            x4, [fp, #-0x38]
    // 0x115b444: cmp             w4, NULL
    // 0x115b448: b.eq            #0x115b53c
    // 0x115b44c: LoadField: r2 = r4->field_7
    //     0x115b44c: ldur            w2, [x4, #7]
    // 0x115b450: DecompressPointer r2
    //     0x115b450: add             x2, x2, HEAP, lsl #32
    // 0x115b454: ldur            x0, [fp, #-0x30]
    // 0x115b458: r1 = Null
    //     0x115b458: mov             x1, NULL
    // 0x115b45c: cmp             w2, NULL
    // 0x115b460: b.eq            #0x115b484
    // 0x115b464: LoadField: r4 = r2->field_23
    //     0x115b464: ldur            w4, [x2, #0x23]
    // 0x115b468: DecompressPointer r4
    //     0x115b468: add             x4, x4, HEAP, lsl #32
    // 0x115b46c: r8 = C2X1
    //     0x115b46c: add             x8, PP, #0xe, lsl #12  ; [pp+0xe800] TypeParameter: C2X1
    //     0x115b470: ldr             x8, [x8, #0x800]
    // 0x115b474: LoadField: r9 = r4->field_7
    //     0x115b474: ldur            x9, [x4, #7]
    // 0x115b478: r3 = Null
    //     0x115b478: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c478] Null
    //     0x115b47c: ldr             x3, [x3, #0x478]
    // 0x115b480: blr             x9
    // 0x115b484: ldur            x0, [fp, #-0x30]
    // 0x115b488: ldur            x1, [fp, #-0x38]
    // 0x115b48c: ArrayStore: r1[0] = r0  ; List_4
    //     0x115b48c: stur            w0, [x1, #0x17]
    //     0x115b490: tbz             w0, #0, #0x115b4ac
    //     0x115b494: ldurb           w16, [x1, #-1]
    //     0x115b498: ldurb           w17, [x0, #-1]
    //     0x115b49c: and             x16, x17, x16, lsr #2
    //     0x115b4a0: tst             x16, HEAP, lsr #32
    //     0x115b4a4: b.eq            #0x115b4ac
    //     0x115b4a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x115b4ac: b               #0x115b4e8
    // 0x115b4b0: ldur            x2, [fp, #-0x30]
    // 0x115b4b4: ldur            x3, [fp, #-0x20]
    // 0x115b4b8: r1 = <double, _SplayTreeMapNode<double, AssetMetadata>, double, AssetMetadata>
    //     0x115b4b8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c470] TypeArguments: <double, _SplayTreeMapNode<double, AssetMetadata>, double, AssetMetadata>
    //     0x115b4bc: ldr             x1, [x1, #0x470]
    // 0x115b4c0: r0 = _SplayTreeMapNode()
    //     0x115b4c0: bl              #0xa0a59c  ; Allocate_SplayTreeMapNodeStub -> _SplayTreeMapNode<C2X0, C2X1> (size=0x1c)
    // 0x115b4c4: mov             x1, x0
    // 0x115b4c8: ldur            x0, [fp, #-0x30]
    // 0x115b4cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x115b4cc: stur            w0, [x1, #0x17]
    // 0x115b4d0: ldur            x0, [fp, #-0x20]
    // 0x115b4d4: StoreField: r1->field_b = r0
    //     0x115b4d4: stur            w0, [x1, #0xb]
    // 0x115b4d8: mov             x2, x1
    // 0x115b4dc: ldur            x1, [fp, #-0x10]
    // 0x115b4e0: ldur            x3, [fp, #-0x40]
    // 0x115b4e4: r0 = _addNewRoot()
    //     0x115b4e4: bl              #0xa0a234  ; [dart:collection] _SplayTree::_addNewRoot
    // 0x115b4e8: ldur            x2, [fp, #-0x18]
    // 0x115b4ec: b               #0x115b378
    // 0x115b4f0: ldur            x0, [fp, #-0x28]
    // 0x115b4f4: LoadField: d0 = r0->field_7
    //     0x115b4f4: ldur            d0, [x0, #7]
    // 0x115b4f8: ldur            x1, [fp, #-8]
    // 0x115b4fc: ldur            x2, [fp, #-0x10]
    // 0x115b500: r0 = _findBestVariant()
    //     0x115b500: bl              #0x115b540  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_findBestVariant
    // 0x115b504: LeaveFrame
    //     0x115b504: mov             SP, fp
    //     0x115b508: ldp             fp, lr, [SP], #0x10
    // 0x115b50c: ret
    //     0x115b50c: ret             
    // 0x115b510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115b510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115b514: b               #0x115b2bc
    // 0x115b518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115b518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115b51c: b               #0x115b388
    // 0x115b520: SaveReg d0
    //     0x115b520: str             q0, [SP, #-0x10]!
    // 0x115b524: SaveReg r0
    //     0x115b524: str             x0, [SP, #-8]!
    // 0x115b528: r0 = AllocateDouble()
    //     0x115b528: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115b52c: mov             x3, x0
    // 0x115b530: RestoreReg r0
    //     0x115b530: ldr             x0, [SP], #8
    // 0x115b534: RestoreReg d0
    //     0x115b534: ldr             q0, [SP], #0x10
    // 0x115b538: b               #0x115b418
    // 0x115b53c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b53c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _findBestVariant(/* No info */) {
    // ** addr: 0x115b540, size: 0x1fc
    // 0x115b540: EnterFrame
    //     0x115b540: stp             fp, lr, [SP, #-0x10]!
    //     0x115b544: mov             fp, SP
    // 0x115b548: AllocStack(0x18)
    //     0x115b548: sub             SP, SP, #0x18
    // 0x115b54c: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x115b54c: mov             x0, x2
    //     0x115b550: stur            x2, [fp, #-0x10]
    //     0x115b554: stur            d0, [fp, #-0x18]
    // 0x115b558: CheckStackOverflow
    //     0x115b558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115b55c: cmp             SP, x16
    //     0x115b560: b.ls            #0x115b704
    // 0x115b564: r3 = inline_Allocate_Double()
    //     0x115b564: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x115b568: add             x3, x3, #0x10
    //     0x115b56c: cmp             x1, x3
    //     0x115b570: b.ls            #0x115b70c
    //     0x115b574: str             x3, [THR, #0x60]  ; THR::top
    //     0x115b578: sub             x3, x3, #0xf
    //     0x115b57c: mov             x1, #0xe19c
    //     0x115b580: movk            x1, #3, lsl #16
    //     0x115b584: stur            x1, [x3, #-1]
    // 0x115b588: dmb             ishst
    // 0x115b58c: StoreField: r3->field_7 = d0
    //     0x115b58c: stur            d0, [x3, #7]
    // 0x115b590: mov             x1, x0
    // 0x115b594: mov             x2, x3
    // 0x115b598: stur            x3, [fp, #-8]
    // 0x115b59c: r0 = containsKey()
    //     0x115b59c: bl              #0x125a240  ; [dart:collection] SplayTreeMap::containsKey
    // 0x115b5a0: tbnz            w0, #4, #0x115b5e0
    // 0x115b5a4: ldur            x1, [fp, #-0x10]
    // 0x115b5a8: ldur            x2, [fp, #-8]
    // 0x115b5ac: r0 = _untypedLookup()
    //     0x115b5ac: bl              #0x8d39d0  ; [dart:collection] _SplayTree::_untypedLookup
    // 0x115b5b0: cmp             w0, NULL
    // 0x115b5b4: b.ne            #0x115b5c0
    // 0x115b5b8: r0 = Null
    //     0x115b5b8: mov             x0, NULL
    // 0x115b5bc: b               #0x115b5cc
    // 0x115b5c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115b5c0: ldur            w1, [x0, #0x17]
    // 0x115b5c4: DecompressPointer r1
    //     0x115b5c4: add             x1, x1, HEAP, lsl #32
    // 0x115b5c8: mov             x0, x1
    // 0x115b5cc: cmp             w0, NULL
    // 0x115b5d0: b.eq            #0x115b728
    // 0x115b5d4: LeaveFrame
    //     0x115b5d4: mov             SP, fp
    //     0x115b5d8: ldp             fp, lr, [SP], #0x10
    // 0x115b5dc: ret
    //     0x115b5dc: ret             
    // 0x115b5e0: ldur            x1, [fp, #-0x10]
    // 0x115b5e4: ldur            d0, [fp, #-0x18]
    // 0x115b5e8: r0 = lastKeyBefore()
    //     0x115b5e8: bl              #0x115b898  ; [dart:collection] SplayTreeMap::lastKeyBefore
    // 0x115b5ec: ldur            x1, [fp, #-0x10]
    // 0x115b5f0: ldur            d0, [fp, #-0x18]
    // 0x115b5f4: stur            x0, [fp, #-8]
    // 0x115b5f8: r0 = firstKeyAfter()
    //     0x115b5f8: bl              #0x115b73c  ; [dart:collection] SplayTreeMap::firstKeyAfter
    // 0x115b5fc: ldur            x2, [fp, #-8]
    // 0x115b600: cmp             w2, NULL
    // 0x115b604: b.ne            #0x115b644
    // 0x115b608: ldur            x1, [fp, #-0x10]
    // 0x115b60c: mov             x2, x0
    // 0x115b610: r0 = _untypedLookup()
    //     0x115b610: bl              #0x8d39d0  ; [dart:collection] _SplayTree::_untypedLookup
    // 0x115b614: cmp             w0, NULL
    // 0x115b618: b.ne            #0x115b624
    // 0x115b61c: r0 = Null
    //     0x115b61c: mov             x0, NULL
    // 0x115b620: b               #0x115b630
    // 0x115b624: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115b624: ldur            w1, [x0, #0x17]
    // 0x115b628: DecompressPointer r1
    //     0x115b628: add             x1, x1, HEAP, lsl #32
    // 0x115b62c: mov             x0, x1
    // 0x115b630: cmp             w0, NULL
    // 0x115b634: b.eq            #0x115b72c
    // 0x115b638: LeaveFrame
    //     0x115b638: mov             SP, fp
    //     0x115b63c: ldp             fp, lr, [SP], #0x10
    // 0x115b640: ret
    //     0x115b640: ret             
    // 0x115b644: cmp             w0, NULL
    // 0x115b648: b.ne            #0x115b684
    // 0x115b64c: ldur            x1, [fp, #-0x10]
    // 0x115b650: r0 = _untypedLookup()
    //     0x115b650: bl              #0x8d39d0  ; [dart:collection] _SplayTree::_untypedLookup
    // 0x115b654: cmp             w0, NULL
    // 0x115b658: b.ne            #0x115b664
    // 0x115b65c: r0 = Null
    //     0x115b65c: mov             x0, NULL
    // 0x115b660: b               #0x115b670
    // 0x115b664: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115b664: ldur            w1, [x0, #0x17]
    // 0x115b668: DecompressPointer r1
    //     0x115b668: add             x1, x1, HEAP, lsl #32
    // 0x115b66c: mov             x0, x1
    // 0x115b670: cmp             w0, NULL
    // 0x115b674: b.eq            #0x115b730
    // 0x115b678: LeaveFrame
    //     0x115b678: mov             SP, fp
    //     0x115b67c: ldp             fp, lr, [SP], #0x10
    // 0x115b680: ret
    //     0x115b680: ret             
    // 0x115b684: ldur            d0, [fp, #-0x18]
    // 0x115b688: d1 = 2.000000
    //     0x115b688: fmov            d1, #2.00000000
    // 0x115b68c: fcmp            d1, d0
    // 0x115b690: b.gt            #0x115b6ac
    // 0x115b694: LoadField: d2 = r2->field_7
    //     0x115b694: ldur            d2, [x2, #7]
    // 0x115b698: LoadField: d3 = r0->field_7
    //     0x115b698: ldur            d3, [x0, #7]
    // 0x115b69c: fadd            d4, d2, d3
    // 0x115b6a0: fdiv            d2, d4, d1
    // 0x115b6a4: fcmp            d0, d2
    // 0x115b6a8: b.le            #0x115b6e8
    // 0x115b6ac: ldur            x1, [fp, #-0x10]
    // 0x115b6b0: mov             x2, x0
    // 0x115b6b4: r0 = _untypedLookup()
    //     0x115b6b4: bl              #0x8d39d0  ; [dart:collection] _SplayTree::_untypedLookup
    // 0x115b6b8: cmp             w0, NULL
    // 0x115b6bc: b.ne            #0x115b6c8
    // 0x115b6c0: r0 = Null
    //     0x115b6c0: mov             x0, NULL
    // 0x115b6c4: b               #0x115b6d4
    // 0x115b6c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115b6c8: ldur            w1, [x0, #0x17]
    // 0x115b6cc: DecompressPointer r1
    //     0x115b6cc: add             x1, x1, HEAP, lsl #32
    // 0x115b6d0: mov             x0, x1
    // 0x115b6d4: cmp             w0, NULL
    // 0x115b6d8: b.eq            #0x115b734
    // 0x115b6dc: LeaveFrame
    //     0x115b6dc: mov             SP, fp
    //     0x115b6e0: ldp             fp, lr, [SP], #0x10
    // 0x115b6e4: ret
    //     0x115b6e4: ret             
    // 0x115b6e8: ldur            x1, [fp, #-0x10]
    // 0x115b6ec: r0 = []()
    //     0x115b6ec: bl              #0x12895c0  ; [dart:collection] SplayTreeMap::[]
    // 0x115b6f0: cmp             w0, NULL
    // 0x115b6f4: b.eq            #0x115b738
    // 0x115b6f8: LeaveFrame
    //     0x115b6f8: mov             SP, fp
    //     0x115b6fc: ldp             fp, lr, [SP], #0x10
    // 0x115b700: ret
    //     0x115b700: ret             
    // 0x115b704: r0 = StackOverflowSharedWithFPURegs()
    //     0x115b704: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115b708: b               #0x115b564
    // 0x115b70c: SaveReg d0
    //     0x115b70c: str             q0, [SP, #-0x10]!
    // 0x115b710: SaveReg r0
    //     0x115b710: str             x0, [SP, #-8]!
    // 0x115b714: r0 = AllocateDouble()
    //     0x115b714: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115b718: mov             x3, x0
    // 0x115b71c: RestoreReg r0
    //     0x115b71c: ldr             x0, [SP], #8
    // 0x115b720: RestoreReg d0
    //     0x115b720: ldr             q0, [SP], #0x10
    // 0x115b724: b               #0x115b58c
    // 0x115b728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115b72c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b72c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115b730: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b730: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115b734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115b738: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115b738: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0x1292380, size: 0xe8
    // 0x1292380: EnterFrame
    //     0x1292380: stp             fp, lr, [SP, #-0x10]!
    //     0x1292384: mov             fp, SP
    // 0x1292388: AllocStack(0x18)
    //     0x1292388: sub             SP, SP, #0x18
    // 0x129238c: CheckStackOverflow
    //     0x129238c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1292390: cmp             SP, x16
    //     0x1292394: b.ls            #0x1292460
    // 0x1292398: ldr             x1, [fp, #0x10]
    // 0x129239c: cmp             w1, NULL
    // 0x12923a0: b.ne            #0x12923b4
    // 0x12923a4: r0 = false
    //     0x12923a4: add             x0, NULL, #0x30  ; false
    // 0x12923a8: LeaveFrame
    //     0x12923a8: mov             SP, fp
    //     0x12923ac: ldp             fp, lr, [SP], #0x10
    // 0x12923b0: ret
    //     0x12923b0: ret             
    // 0x12923b4: str             x1, [SP]
    // 0x12923b8: r0 = runtimeType()
    //     0x12923b8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12923bc: r1 = LoadClassIdInstr(r0)
    //     0x12923bc: ldur            x1, [x0, #-1]
    //     0x12923c0: ubfx            x1, x1, #0xc, #0x14
    // 0x12923c4: r16 = AssetImage
    //     0x12923c4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80890] Type: AssetImage
    //     0x12923c8: ldr             x16, [x16, #0x890]
    // 0x12923cc: stp             x16, x0, [SP]
    // 0x12923d0: mov             x0, x1
    // 0x12923d4: mov             lr, x0
    // 0x12923d8: ldr             lr, [x21, lr, lsl #3]
    // 0x12923dc: blr             lr
    // 0x12923e0: tbz             w0, #4, #0x12923f4
    // 0x12923e4: r0 = false
    //     0x12923e4: add             x0, NULL, #0x30  ; false
    // 0x12923e8: LeaveFrame
    //     0x12923e8: mov             SP, fp
    //     0x12923ec: ldp             fp, lr, [SP], #0x10
    // 0x12923f0: ret
    //     0x12923f0: ret             
    // 0x12923f4: ldr             x1, [fp, #0x10]
    // 0x12923f8: r0 = 60
    //     0x12923f8: mov             x0, #0x3c
    // 0x12923fc: branchIfSmi(r1, 0x1292408)
    //     0x12923fc: tbz             w1, #0, #0x1292408
    // 0x1292400: r0 = LoadClassIdInstr(r1)
    //     0x1292400: ldur            x0, [x1, #-1]
    //     0x1292404: ubfx            x0, x0, #0xc, #0x14
    // 0x1292408: cmp             x0, #0xe0f
    // 0x129240c: b.ne            #0x1292450
    // 0x1292410: r0 = keyName()
    //     0x1292410: bl              #0x1149380  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::keyName
    // 0x1292414: ldr             x1, [fp, #0x18]
    // 0x1292418: stur            x0, [fp, #-8]
    // 0x129241c: r0 = keyName()
    //     0x129241c: bl              #0x1149380  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::keyName
    // 0x1292420: mov             x1, x0
    // 0x1292424: ldur            x0, [fp, #-8]
    // 0x1292428: r2 = LoadClassIdInstr(r0)
    //     0x1292428: ldur            x2, [x0, #-1]
    //     0x129242c: ubfx            x2, x2, #0xc, #0x14
    // 0x1292430: stp             x1, x0, [SP]
    // 0x1292434: mov             x0, x2
    // 0x1292438: mov             lr, x0
    // 0x129243c: ldr             lr, [x21, lr, lsl #3]
    // 0x1292440: blr             lr
    // 0x1292444: tbnz            w0, #4, #0x1292450
    // 0x1292448: r0 = true
    //     0x1292448: add             x0, NULL, #0x20  ; true
    // 0x129244c: b               #0x1292454
    // 0x1292450: r0 = false
    //     0x1292450: add             x0, NULL, #0x30  ; false
    // 0x1292454: LeaveFrame
    //     0x1292454: mov             SP, fp
    //     0x1292458: ldp             fp, lr, [SP], #0x10
    // 0x129245c: ret
    //     0x129245c: ret             
    // 0x1292460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1292464: b               #0x1292398
  }
}
