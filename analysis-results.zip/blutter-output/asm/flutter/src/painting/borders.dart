// lib: , url: package:flutter/src/painting/borders.dart

// class id: 1048982, size: 0x8
class :: {

  static _ paintBorder(/* No info */) {
    // ** addr: 0x12efe48, size: 0xd90
    // 0x12efe48: EnterFrame
    //     0x12efe48: stp             fp, lr, [SP, #-0x10]!
    //     0x12efe4c: mov             fp, SP
    // 0x12efe50: AllocStack(0x98)
    //     0x12efe50: sub             SP, SP, #0x98
    // 0x12efe54: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x12efe54: stur            x1, [fp, #-8]
    //     0x12efe58: stur            x2, [fp, #-0x10]
    //     0x12efe5c: stur            x3, [fp, #-0x18]
    //     0x12efe60: stur            x5, [fp, #-0x20]
    //     0x12efe64: stur            x6, [fp, #-0x28]
    //     0x12efe68: stur            x7, [fp, #-0x30]
    // 0x12efe6c: CheckStackOverflow
    //     0x12efe6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12efe70: cmp             SP, x16
    //     0x12efe74: b.ls            #0x12f0b60
    // 0x12efe78: r16 = 136
    //     0x12efe78: mov             x16, #0x88
    // 0x12efe7c: stp             x16, NULL, [SP]
    // 0x12efe80: r0 = ByteData()
    //     0x12efe80: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12efe84: stur            x0, [fp, #-0x38]
    // 0x12efe88: r0 = Paint()
    //     0x12efe88: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12efe8c: ldur            x5, [fp, #-0x38]
    // 0x12efe90: stur            x0, [fp, #-0x48]
    // 0x12efe94: StoreField: r0->field_7 = r5
    //     0x12efe94: stur            w5, [x0, #7]
    // 0x12efe98: ArrayLoad: r1 = r5[0]  ; List_4
    //     0x12efe98: ldur            w1, [x5, #0x17]
    // 0x12efe9c: DecompressPointer r1
    //     0x12efe9c: add             x1, x1, HEAP, lsl #32
    // 0x12efea0: stur            x1, [fp, #-0x40]
    // 0x12efea4: LoadField: r2 = r1->field_7
    //     0x12efea4: ldur            x2, [x1, #7]
    // 0x12efea8: str             wzr, [x2, #0x20]
    // 0x12efeac: r0 = _NativePath()
    //     0x12efeac: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12efeb0: mov             x1, x0
    // 0x12efeb4: stur            x0, [fp, #-0x50]
    // 0x12efeb8: r0 = __constructor$Method$FfiNative()
    //     0x12efeb8: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12efebc: ldur            x0, [fp, #-0x30]
    // 0x12efec0: LoadField: r1 = r0->field_13
    //     0x12efec0: ldur            w1, [x0, #0x13]
    // 0x12efec4: DecompressPointer r1
    //     0x12efec4: add             x1, x1, HEAP, lsl #32
    // 0x12efec8: LoadField: r2 = r1->field_7
    //     0x12efec8: ldur            x2, [x1, #7]
    // 0x12efecc: cmp             x2, #0
    // 0x12efed0: b.le            #0x12f0184
    // 0x12efed4: ldur            x3, [fp, #-0x50]
    // 0x12efed8: LoadField: r2 = r0->field_7
    //     0x12efed8: ldur            w2, [x0, #7]
    // 0x12efedc: DecompressPointer r2
    //     0x12efedc: add             x2, x2, HEAP, lsl #32
    // 0x12efee0: ldur            x1, [fp, #-0x48]
    // 0x12efee4: r0 = color=()
    //     0x12efee4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12efee8: ldur            x0, [fp, #-0x50]
    // 0x12efeec: LoadField: r1 = r0->field_7
    //     0x12efeec: ldur            w1, [x0, #7]
    // 0x12efef0: DecompressPointer r1
    //     0x12efef0: add             x1, x1, HEAP, lsl #32
    // 0x12efef4: cmp             w1, NULL
    // 0x12efef8: b.eq            #0x12f0b68
    // 0x12efefc: LoadField: r2 = r1->field_7
    //     0x12efefc: ldur            x2, [x1, #7]
    // 0x12eff00: ldr             x1, [x2]
    // 0x12eff04: cbz             x1, #0x12f09e0
    // 0x12eff08: ldur            x2, [fp, #-0x10]
    // 0x12eff0c: mov             x3, x1
    // 0x12eff10: stur            x3, [fp, #-0x58]
    // 0x12eff14: r1 = <Never>
    //     0x12eff14: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eff18: r0 = Pointer()
    //     0x12eff18: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eff1c: mov             x1, x0
    // 0x12eff20: ldur            x0, [fp, #-0x58]
    // 0x12eff24: StoreField: r1->field_7 = r0
    //     0x12eff24: stur            x0, [x1, #7]
    // 0x12eff28: r0 = _reset$Method$FfiNative()
    //     0x12eff28: bl              #0xc33450  ; [dart:ui] _NativePath::_reset$Method$FfiNative
    // 0x12eff2c: ldur            x0, [fp, #-0x10]
    // 0x12eff30: LoadField: d0 = r0->field_7
    //     0x12eff30: ldur            d0, [x0, #7]
    // 0x12eff34: stur            d0, [fp, #-0x78]
    // 0x12eff38: LoadField: d1 = r0->field_f
    //     0x12eff38: ldur            d1, [x0, #0xf]
    // 0x12eff3c: ldur            x2, [fp, #-0x50]
    // 0x12eff40: stur            d1, [fp, #-0x70]
    // 0x12eff44: LoadField: r1 = r2->field_7
    //     0x12eff44: ldur            w1, [x2, #7]
    // 0x12eff48: DecompressPointer r1
    //     0x12eff48: add             x1, x1, HEAP, lsl #32
    // 0x12eff4c: cmp             w1, NULL
    // 0x12eff50: b.eq            #0x12f0b6c
    // 0x12eff54: LoadField: r3 = r1->field_7
    //     0x12eff54: ldur            x3, [x1, #7]
    // 0x12eff58: ldr             x1, [x3]
    // 0x12eff5c: cbz             x1, #0x12f09f0
    // 0x12eff60: mov             x3, x1
    // 0x12eff64: stur            x3, [fp, #-0x58]
    // 0x12eff68: r1 = <Never>
    //     0x12eff68: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eff6c: r0 = Pointer()
    //     0x12eff6c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eff70: mov             x1, x0
    // 0x12eff74: ldur            x0, [fp, #-0x58]
    // 0x12eff78: StoreField: r1->field_7 = r0
    //     0x12eff78: stur            x0, [x1, #7]
    // 0x12eff7c: ldur            d0, [fp, #-0x78]
    // 0x12eff80: ldur            d1, [fp, #-0x70]
    // 0x12eff84: r0 = _moveTo$Method$FfiNative()
    //     0x12eff84: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12eff88: ldur            x0, [fp, #-0x10]
    // 0x12eff8c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12eff8c: ldur            d0, [x0, #0x17]
    // 0x12eff90: ldur            x2, [fp, #-0x50]
    // 0x12eff94: stur            d0, [fp, #-0x80]
    // 0x12eff98: LoadField: r1 = r2->field_7
    //     0x12eff98: ldur            w1, [x2, #7]
    // 0x12eff9c: DecompressPointer r1
    //     0x12eff9c: add             x1, x1, HEAP, lsl #32
    // 0x12effa0: cmp             w1, NULL
    // 0x12effa4: b.eq            #0x12f0b70
    // 0x12effa8: LoadField: r3 = r1->field_7
    //     0x12effa8: ldur            x3, [x1, #7]
    // 0x12effac: ldr             x1, [x3]
    // 0x12effb0: cbz             x1, #0x12f0a00
    // 0x12effb4: ldur            x3, [fp, #-0x30]
    // 0x12effb8: mov             x4, x1
    // 0x12effbc: stur            x4, [fp, #-0x58]
    // 0x12effc0: r1 = <Never>
    //     0x12effc0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12effc4: r0 = Pointer()
    //     0x12effc4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12effc8: mov             x1, x0
    // 0x12effcc: ldur            x0, [fp, #-0x58]
    // 0x12effd0: StoreField: r1->field_7 = r0
    //     0x12effd0: stur            x0, [x1, #7]
    // 0x12effd4: ldur            d0, [fp, #-0x80]
    // 0x12effd8: ldur            d1, [fp, #-0x70]
    // 0x12effdc: r0 = _lineTo$Method$FfiNative()
    //     0x12effdc: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12effe0: ldur            x0, [fp, #-0x30]
    // 0x12effe4: LoadField: d0 = r0->field_b
    //     0x12effe4: ldur            d0, [x0, #0xb]
    // 0x12effe8: d1 = 0.000000
    //     0x12effe8: eor             v1.16b, v1.16b, v1.16b
    // 0x12effec: fcmp            d0, d1
    // 0x12efff0: b.ne            #0x12f0008
    // 0x12efff4: ldur            x2, [fp, #-0x40]
    // 0x12efff8: r3 = 1
    //     0x12efff8: mov             x3, #1
    // 0x12efffc: LoadField: r1 = r2->field_7
    //     0x12efffc: ldur            x1, [x2, #7]
    // 0x12f0000: str             w3, [x1, #0x1c]
    // 0x12f0004: b               #0x12f00e4
    // 0x12f0008: ldur            x5, [fp, #-0x28]
    // 0x12f000c: ldur            x4, [fp, #-0x50]
    // 0x12f0010: ldur            d3, [fp, #-0x70]
    // 0x12f0014: ldur            d2, [fp, #-0x80]
    // 0x12f0018: ldur            x2, [fp, #-0x40]
    // 0x12f001c: r3 = 1
    //     0x12f001c: mov             x3, #1
    // 0x12f0020: LoadField: r1 = r2->field_7
    //     0x12f0020: ldur            x1, [x2, #7]
    // 0x12f0024: str             wzr, [x1, #0x1c]
    // 0x12f0028: LoadField: d4 = r5->field_b
    //     0x12f0028: ldur            d4, [x5, #0xb]
    // 0x12f002c: fsub            d5, d2, d4
    // 0x12f0030: stur            d5, [fp, #-0x88]
    // 0x12f0034: fadd            d2, d3, d0
    // 0x12f0038: stur            d2, [fp, #-0x80]
    // 0x12f003c: LoadField: r1 = r4->field_7
    //     0x12f003c: ldur            w1, [x4, #7]
    // 0x12f0040: DecompressPointer r1
    //     0x12f0040: add             x1, x1, HEAP, lsl #32
    // 0x12f0044: cmp             w1, NULL
    // 0x12f0048: b.eq            #0x12f0b74
    // 0x12f004c: LoadField: r6 = r1->field_7
    //     0x12f004c: ldur            x6, [x1, #7]
    // 0x12f0050: ldr             x1, [x6]
    // 0x12f0054: cbz             x1, #0x12f0a10
    // 0x12f0058: ldur            x6, [fp, #-0x20]
    // 0x12f005c: ldur            d0, [fp, #-0x78]
    // 0x12f0060: mov             x7, x1
    // 0x12f0064: stur            x7, [fp, #-0x58]
    // 0x12f0068: r1 = <Never>
    //     0x12f0068: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f006c: r0 = Pointer()
    //     0x12f006c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0070: mov             x1, x0
    // 0x12f0074: ldur            x0, [fp, #-0x58]
    // 0x12f0078: StoreField: r1->field_7 = r0
    //     0x12f0078: stur            x0, [x1, #7]
    // 0x12f007c: ldur            d0, [fp, #-0x88]
    // 0x12f0080: ldur            d1, [fp, #-0x80]
    // 0x12f0084: r0 = _lineTo$Method$FfiNative()
    //     0x12f0084: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0088: ldur            x0, [fp, #-0x20]
    // 0x12f008c: LoadField: d0 = r0->field_b
    //     0x12f008c: ldur            d0, [x0, #0xb]
    // 0x12f0090: ldur            d1, [fp, #-0x78]
    // 0x12f0094: fadd            d2, d1, d0
    // 0x12f0098: ldur            x2, [fp, #-0x50]
    // 0x12f009c: stur            d2, [fp, #-0x70]
    // 0x12f00a0: LoadField: r1 = r2->field_7
    //     0x12f00a0: ldur            w1, [x2, #7]
    // 0x12f00a4: DecompressPointer r1
    //     0x12f00a4: add             x1, x1, HEAP, lsl #32
    // 0x12f00a8: cmp             w1, NULL
    // 0x12f00ac: b.eq            #0x12f0b78
    // 0x12f00b0: LoadField: r3 = r1->field_7
    //     0x12f00b0: ldur            x3, [x1, #7]
    // 0x12f00b4: ldr             x1, [x3]
    // 0x12f00b8: cbz             x1, #0x12f0a20
    // 0x12f00bc: mov             x3, x1
    // 0x12f00c0: stur            x3, [fp, #-0x58]
    // 0x12f00c4: r1 = <Never>
    //     0x12f00c4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f00c8: r0 = Pointer()
    //     0x12f00c8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f00cc: mov             x1, x0
    // 0x12f00d0: ldur            x0, [fp, #-0x58]
    // 0x12f00d4: StoreField: r1->field_7 = r0
    //     0x12f00d4: stur            x0, [x1, #7]
    // 0x12f00d8: ldur            d0, [fp, #-0x70]
    // 0x12f00dc: ldur            d1, [fp, #-0x80]
    // 0x12f00e0: r0 = _lineTo$Method$FfiNative()
    //     0x12f00e0: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f00e4: ldur            x2, [fp, #-8]
    // 0x12f00e8: ldur            x0, [fp, #-0x48]
    // 0x12f00ec: LoadField: r3 = r0->field_b
    //     0x12f00ec: ldur            w3, [x0, #0xb]
    // 0x12f00f0: DecompressPointer r3
    //     0x12f00f0: add             x3, x3, HEAP, lsl #32
    // 0x12f00f4: stur            x3, [fp, #-0x60]
    // 0x12f00f8: LoadField: r1 = r2->field_7
    //     0x12f00f8: ldur            w1, [x2, #7]
    // 0x12f00fc: DecompressPointer r1
    //     0x12f00fc: add             x1, x1, HEAP, lsl #32
    // 0x12f0100: cmp             w1, NULL
    // 0x12f0104: b.eq            #0x12f0b7c
    // 0x12f0108: LoadField: r4 = r1->field_7
    //     0x12f0108: ldur            x4, [x1, #7]
    // 0x12f010c: ldr             x1, [x4]
    // 0x12f0110: cbz             x1, #0x12f0a30
    // 0x12f0114: ldur            x4, [fp, #-0x50]
    // 0x12f0118: mov             x5, x1
    // 0x12f011c: stur            x5, [fp, #-0x58]
    // 0x12f0120: r1 = <Never>
    //     0x12f0120: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0124: r0 = Pointer()
    //     0x12f0124: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0128: mov             x2, x0
    // 0x12f012c: ldur            x0, [fp, #-0x58]
    // 0x12f0130: stur            x2, [fp, #-0x68]
    // 0x12f0134: StoreField: r2->field_7 = r0
    //     0x12f0134: stur            x0, [x2, #7]
    // 0x12f0138: ldur            x0, [fp, #-0x50]
    // 0x12f013c: LoadField: r1 = r0->field_7
    //     0x12f013c: ldur            w1, [x0, #7]
    // 0x12f0140: DecompressPointer r1
    //     0x12f0140: add             x1, x1, HEAP, lsl #32
    // 0x12f0144: cmp             w1, NULL
    // 0x12f0148: b.eq            #0x12f0b80
    // 0x12f014c: LoadField: r3 = r1->field_7
    //     0x12f014c: ldur            x3, [x1, #7]
    // 0x12f0150: ldr             x1, [x3]
    // 0x12f0154: mov             x3, x1
    // 0x12f0158: stur            x3, [fp, #-0x58]
    // 0x12f015c: r1 = <Never>
    //     0x12f015c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0160: r0 = Pointer()
    //     0x12f0160: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0164: mov             x1, x0
    // 0x12f0168: ldur            x0, [fp, #-0x58]
    // 0x12f016c: StoreField: r1->field_7 = r0
    //     0x12f016c: stur            x0, [x1, #7]
    // 0x12f0170: mov             x2, x1
    // 0x12f0174: ldur            x1, [fp, #-0x68]
    // 0x12f0178: ldur            x3, [fp, #-0x60]
    // 0x12f017c: ldur            x5, [fp, #-0x38]
    // 0x12f0180: r0 = __drawPath$Method$FfiNative()
    //     0x12f0180: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f0184: ldur            x0, [fp, #-0x28]
    // 0x12f0188: LoadField: r1 = r0->field_13
    //     0x12f0188: ldur            w1, [x0, #0x13]
    // 0x12f018c: DecompressPointer r1
    //     0x12f018c: add             x1, x1, HEAP, lsl #32
    // 0x12f0190: LoadField: r2 = r1->field_7
    //     0x12f0190: ldur            x2, [x1, #7]
    // 0x12f0194: cmp             x2, #0
    // 0x12f0198: b.le            #0x12f044c
    // 0x12f019c: ldur            x3, [fp, #-0x50]
    // 0x12f01a0: LoadField: r2 = r0->field_7
    //     0x12f01a0: ldur            w2, [x0, #7]
    // 0x12f01a4: DecompressPointer r2
    //     0x12f01a4: add             x2, x2, HEAP, lsl #32
    // 0x12f01a8: ldur            x1, [fp, #-0x48]
    // 0x12f01ac: r0 = color=()
    //     0x12f01ac: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f01b0: ldur            x0, [fp, #-0x50]
    // 0x12f01b4: LoadField: r1 = r0->field_7
    //     0x12f01b4: ldur            w1, [x0, #7]
    // 0x12f01b8: DecompressPointer r1
    //     0x12f01b8: add             x1, x1, HEAP, lsl #32
    // 0x12f01bc: cmp             w1, NULL
    // 0x12f01c0: b.eq            #0x12f0b84
    // 0x12f01c4: LoadField: r2 = r1->field_7
    //     0x12f01c4: ldur            x2, [x1, #7]
    // 0x12f01c8: ldr             x1, [x2]
    // 0x12f01cc: cbz             x1, #0x12f0a40
    // 0x12f01d0: ldur            x2, [fp, #-0x10]
    // 0x12f01d4: mov             x3, x1
    // 0x12f01d8: stur            x3, [fp, #-0x58]
    // 0x12f01dc: r1 = <Never>
    //     0x12f01dc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f01e0: r0 = Pointer()
    //     0x12f01e0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f01e4: mov             x1, x0
    // 0x12f01e8: ldur            x0, [fp, #-0x58]
    // 0x12f01ec: StoreField: r1->field_7 = r0
    //     0x12f01ec: stur            x0, [x1, #7]
    // 0x12f01f0: r0 = _reset$Method$FfiNative()
    //     0x12f01f0: bl              #0xc33450  ; [dart:ui] _NativePath::_reset$Method$FfiNative
    // 0x12f01f4: ldur            x0, [fp, #-0x10]
    // 0x12f01f8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f01f8: ldur            d0, [x0, #0x17]
    // 0x12f01fc: stur            d0, [fp, #-0x78]
    // 0x12f0200: LoadField: d1 = r0->field_f
    //     0x12f0200: ldur            d1, [x0, #0xf]
    // 0x12f0204: ldur            x2, [fp, #-0x50]
    // 0x12f0208: stur            d1, [fp, #-0x70]
    // 0x12f020c: LoadField: r1 = r2->field_7
    //     0x12f020c: ldur            w1, [x2, #7]
    // 0x12f0210: DecompressPointer r1
    //     0x12f0210: add             x1, x1, HEAP, lsl #32
    // 0x12f0214: cmp             w1, NULL
    // 0x12f0218: b.eq            #0x12f0b88
    // 0x12f021c: LoadField: r3 = r1->field_7
    //     0x12f021c: ldur            x3, [x1, #7]
    // 0x12f0220: ldr             x1, [x3]
    // 0x12f0224: cbz             x1, #0x12f0a50
    // 0x12f0228: mov             x3, x1
    // 0x12f022c: stur            x3, [fp, #-0x58]
    // 0x12f0230: r1 = <Never>
    //     0x12f0230: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0234: r0 = Pointer()
    //     0x12f0234: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0238: mov             x1, x0
    // 0x12f023c: ldur            x0, [fp, #-0x58]
    // 0x12f0240: StoreField: r1->field_7 = r0
    //     0x12f0240: stur            x0, [x1, #7]
    // 0x12f0244: ldur            d0, [fp, #-0x78]
    // 0x12f0248: ldur            d1, [fp, #-0x70]
    // 0x12f024c: r0 = _moveTo$Method$FfiNative()
    //     0x12f024c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12f0250: ldur            x0, [fp, #-0x10]
    // 0x12f0254: LoadField: d1 = r0->field_1f
    //     0x12f0254: ldur            d1, [x0, #0x1f]
    // 0x12f0258: ldur            x2, [fp, #-0x50]
    // 0x12f025c: stur            d1, [fp, #-0x80]
    // 0x12f0260: LoadField: r1 = r2->field_7
    //     0x12f0260: ldur            w1, [x2, #7]
    // 0x12f0264: DecompressPointer r1
    //     0x12f0264: add             x1, x1, HEAP, lsl #32
    // 0x12f0268: cmp             w1, NULL
    // 0x12f026c: b.eq            #0x12f0b8c
    // 0x12f0270: LoadField: r3 = r1->field_7
    //     0x12f0270: ldur            x3, [x1, #7]
    // 0x12f0274: ldr             x1, [x3]
    // 0x12f0278: cbz             x1, #0x12f0a60
    // 0x12f027c: ldur            x3, [fp, #-0x28]
    // 0x12f0280: mov             x4, x1
    // 0x12f0284: stur            x4, [fp, #-0x58]
    // 0x12f0288: r1 = <Never>
    //     0x12f0288: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f028c: r0 = Pointer()
    //     0x12f028c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0290: mov             x1, x0
    // 0x12f0294: ldur            x0, [fp, #-0x58]
    // 0x12f0298: StoreField: r1->field_7 = r0
    //     0x12f0298: stur            x0, [x1, #7]
    // 0x12f029c: ldur            d0, [fp, #-0x78]
    // 0x12f02a0: ldur            d1, [fp, #-0x80]
    // 0x12f02a4: r0 = _lineTo$Method$FfiNative()
    //     0x12f02a4: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f02a8: ldur            x0, [fp, #-0x28]
    // 0x12f02ac: LoadField: d0 = r0->field_b
    //     0x12f02ac: ldur            d0, [x0, #0xb]
    // 0x12f02b0: d1 = 0.000000
    //     0x12f02b0: eor             v1.16b, v1.16b, v1.16b
    // 0x12f02b4: fcmp            d0, d1
    // 0x12f02b8: b.ne            #0x12f02d0
    // 0x12f02bc: ldur            x2, [fp, #-0x40]
    // 0x12f02c0: r3 = 1
    //     0x12f02c0: mov             x3, #1
    // 0x12f02c4: LoadField: r1 = r2->field_7
    //     0x12f02c4: ldur            x1, [x2, #7]
    // 0x12f02c8: str             w3, [x1, #0x1c]
    // 0x12f02cc: b               #0x12f03ac
    // 0x12f02d0: ldur            x5, [fp, #-0x18]
    // 0x12f02d4: ldur            x4, [fp, #-0x50]
    // 0x12f02d8: ldur            d3, [fp, #-0x78]
    // 0x12f02dc: ldur            d2, [fp, #-0x80]
    // 0x12f02e0: ldur            x2, [fp, #-0x40]
    // 0x12f02e4: r3 = 1
    //     0x12f02e4: mov             x3, #1
    // 0x12f02e8: LoadField: r1 = r2->field_7
    //     0x12f02e8: ldur            x1, [x2, #7]
    // 0x12f02ec: str             wzr, [x1, #0x1c]
    // 0x12f02f0: fsub            d4, d3, d0
    // 0x12f02f4: stur            d4, [fp, #-0x88]
    // 0x12f02f8: LoadField: d0 = r5->field_b
    //     0x12f02f8: ldur            d0, [x5, #0xb]
    // 0x12f02fc: fsub            d3, d2, d0
    // 0x12f0300: stur            d3, [fp, #-0x78]
    // 0x12f0304: LoadField: r1 = r4->field_7
    //     0x12f0304: ldur            w1, [x4, #7]
    // 0x12f0308: DecompressPointer r1
    //     0x12f0308: add             x1, x1, HEAP, lsl #32
    // 0x12f030c: cmp             w1, NULL
    // 0x12f0310: b.eq            #0x12f0b90
    // 0x12f0314: LoadField: r6 = r1->field_7
    //     0x12f0314: ldur            x6, [x1, #7]
    // 0x12f0318: ldr             x1, [x6]
    // 0x12f031c: cbz             x1, #0x12f0a70
    // 0x12f0320: ldur            x6, [fp, #-0x30]
    // 0x12f0324: ldur            d0, [fp, #-0x70]
    // 0x12f0328: mov             x7, x1
    // 0x12f032c: stur            x7, [fp, #-0x58]
    // 0x12f0330: r1 = <Never>
    //     0x12f0330: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0334: r0 = Pointer()
    //     0x12f0334: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0338: mov             x1, x0
    // 0x12f033c: ldur            x0, [fp, #-0x58]
    // 0x12f0340: StoreField: r1->field_7 = r0
    //     0x12f0340: stur            x0, [x1, #7]
    // 0x12f0344: ldur            d0, [fp, #-0x88]
    // 0x12f0348: ldur            d1, [fp, #-0x78]
    // 0x12f034c: r0 = _lineTo$Method$FfiNative()
    //     0x12f034c: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0350: ldur            x0, [fp, #-0x30]
    // 0x12f0354: LoadField: d0 = r0->field_b
    //     0x12f0354: ldur            d0, [x0, #0xb]
    // 0x12f0358: ldur            d1, [fp, #-0x70]
    // 0x12f035c: fadd            d2, d1, d0
    // 0x12f0360: ldur            x2, [fp, #-0x50]
    // 0x12f0364: stur            d2, [fp, #-0x78]
    // 0x12f0368: LoadField: r1 = r2->field_7
    //     0x12f0368: ldur            w1, [x2, #7]
    // 0x12f036c: DecompressPointer r1
    //     0x12f036c: add             x1, x1, HEAP, lsl #32
    // 0x12f0370: cmp             w1, NULL
    // 0x12f0374: b.eq            #0x12f0b94
    // 0x12f0378: LoadField: r3 = r1->field_7
    //     0x12f0378: ldur            x3, [x1, #7]
    // 0x12f037c: ldr             x1, [x3]
    // 0x12f0380: cbz             x1, #0x12f0a80
    // 0x12f0384: mov             x3, x1
    // 0x12f0388: stur            x3, [fp, #-0x58]
    // 0x12f038c: r1 = <Never>
    //     0x12f038c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0390: r0 = Pointer()
    //     0x12f0390: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0394: mov             x1, x0
    // 0x12f0398: ldur            x0, [fp, #-0x58]
    // 0x12f039c: StoreField: r1->field_7 = r0
    //     0x12f039c: stur            x0, [x1, #7]
    // 0x12f03a0: ldur            d0, [fp, #-0x88]
    // 0x12f03a4: ldur            d1, [fp, #-0x78]
    // 0x12f03a8: r0 = _lineTo$Method$FfiNative()
    //     0x12f03a8: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f03ac: ldur            x2, [fp, #-8]
    // 0x12f03b0: ldur            x0, [fp, #-0x48]
    // 0x12f03b4: LoadField: r3 = r0->field_b
    //     0x12f03b4: ldur            w3, [x0, #0xb]
    // 0x12f03b8: DecompressPointer r3
    //     0x12f03b8: add             x3, x3, HEAP, lsl #32
    // 0x12f03bc: stur            x3, [fp, #-0x60]
    // 0x12f03c0: LoadField: r1 = r2->field_7
    //     0x12f03c0: ldur            w1, [x2, #7]
    // 0x12f03c4: DecompressPointer r1
    //     0x12f03c4: add             x1, x1, HEAP, lsl #32
    // 0x12f03c8: cmp             w1, NULL
    // 0x12f03cc: b.eq            #0x12f0b98
    // 0x12f03d0: LoadField: r4 = r1->field_7
    //     0x12f03d0: ldur            x4, [x1, #7]
    // 0x12f03d4: ldr             x1, [x4]
    // 0x12f03d8: cbz             x1, #0x12f0a90
    // 0x12f03dc: ldur            x4, [fp, #-0x50]
    // 0x12f03e0: mov             x5, x1
    // 0x12f03e4: stur            x5, [fp, #-0x58]
    // 0x12f03e8: r1 = <Never>
    //     0x12f03e8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f03ec: r0 = Pointer()
    //     0x12f03ec: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f03f0: mov             x2, x0
    // 0x12f03f4: ldur            x0, [fp, #-0x58]
    // 0x12f03f8: stur            x2, [fp, #-0x68]
    // 0x12f03fc: StoreField: r2->field_7 = r0
    //     0x12f03fc: stur            x0, [x2, #7]
    // 0x12f0400: ldur            x0, [fp, #-0x50]
    // 0x12f0404: LoadField: r1 = r0->field_7
    //     0x12f0404: ldur            w1, [x0, #7]
    // 0x12f0408: DecompressPointer r1
    //     0x12f0408: add             x1, x1, HEAP, lsl #32
    // 0x12f040c: cmp             w1, NULL
    // 0x12f0410: b.eq            #0x12f0b9c
    // 0x12f0414: LoadField: r3 = r1->field_7
    //     0x12f0414: ldur            x3, [x1, #7]
    // 0x12f0418: ldr             x1, [x3]
    // 0x12f041c: mov             x3, x1
    // 0x12f0420: stur            x3, [fp, #-0x58]
    // 0x12f0424: r1 = <Never>
    //     0x12f0424: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0428: r0 = Pointer()
    //     0x12f0428: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f042c: mov             x1, x0
    // 0x12f0430: ldur            x0, [fp, #-0x58]
    // 0x12f0434: StoreField: r1->field_7 = r0
    //     0x12f0434: stur            x0, [x1, #7]
    // 0x12f0438: mov             x2, x1
    // 0x12f043c: ldur            x1, [fp, #-0x68]
    // 0x12f0440: ldur            x3, [fp, #-0x60]
    // 0x12f0444: ldur            x5, [fp, #-0x38]
    // 0x12f0448: r0 = __drawPath$Method$FfiNative()
    //     0x12f0448: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f044c: ldur            x0, [fp, #-0x18]
    // 0x12f0450: LoadField: r1 = r0->field_13
    //     0x12f0450: ldur            w1, [x0, #0x13]
    // 0x12f0454: DecompressPointer r1
    //     0x12f0454: add             x1, x1, HEAP, lsl #32
    // 0x12f0458: LoadField: r2 = r1->field_7
    //     0x12f0458: ldur            x2, [x1, #7]
    // 0x12f045c: cmp             x2, #0
    // 0x12f0460: b.le            #0x12f0714
    // 0x12f0464: ldur            x3, [fp, #-0x50]
    // 0x12f0468: LoadField: r2 = r0->field_7
    //     0x12f0468: ldur            w2, [x0, #7]
    // 0x12f046c: DecompressPointer r2
    //     0x12f046c: add             x2, x2, HEAP, lsl #32
    // 0x12f0470: ldur            x1, [fp, #-0x48]
    // 0x12f0474: r0 = color=()
    //     0x12f0474: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f0478: ldur            x0, [fp, #-0x50]
    // 0x12f047c: LoadField: r1 = r0->field_7
    //     0x12f047c: ldur            w1, [x0, #7]
    // 0x12f0480: DecompressPointer r1
    //     0x12f0480: add             x1, x1, HEAP, lsl #32
    // 0x12f0484: cmp             w1, NULL
    // 0x12f0488: b.eq            #0x12f0ba0
    // 0x12f048c: LoadField: r2 = r1->field_7
    //     0x12f048c: ldur            x2, [x1, #7]
    // 0x12f0490: ldr             x1, [x2]
    // 0x12f0494: cbz             x1, #0x12f0aa0
    // 0x12f0498: ldur            x2, [fp, #-0x10]
    // 0x12f049c: mov             x3, x1
    // 0x12f04a0: stur            x3, [fp, #-0x58]
    // 0x12f04a4: r1 = <Never>
    //     0x12f04a4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f04a8: r0 = Pointer()
    //     0x12f04a8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f04ac: mov             x1, x0
    // 0x12f04b0: ldur            x0, [fp, #-0x58]
    // 0x12f04b4: StoreField: r1->field_7 = r0
    //     0x12f04b4: stur            x0, [x1, #7]
    // 0x12f04b8: r0 = _reset$Method$FfiNative()
    //     0x12f04b8: bl              #0xc33450  ; [dart:ui] _NativePath::_reset$Method$FfiNative
    // 0x12f04bc: ldur            x0, [fp, #-0x10]
    // 0x12f04c0: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12f04c0: ldur            d0, [x0, #0x17]
    // 0x12f04c4: stur            d0, [fp, #-0x78]
    // 0x12f04c8: LoadField: d1 = r0->field_1f
    //     0x12f04c8: ldur            d1, [x0, #0x1f]
    // 0x12f04cc: ldur            x2, [fp, #-0x50]
    // 0x12f04d0: stur            d1, [fp, #-0x70]
    // 0x12f04d4: LoadField: r1 = r2->field_7
    //     0x12f04d4: ldur            w1, [x2, #7]
    // 0x12f04d8: DecompressPointer r1
    //     0x12f04d8: add             x1, x1, HEAP, lsl #32
    // 0x12f04dc: cmp             w1, NULL
    // 0x12f04e0: b.eq            #0x12f0ba4
    // 0x12f04e4: LoadField: r3 = r1->field_7
    //     0x12f04e4: ldur            x3, [x1, #7]
    // 0x12f04e8: ldr             x1, [x3]
    // 0x12f04ec: cbz             x1, #0x12f0ab0
    // 0x12f04f0: mov             x3, x1
    // 0x12f04f4: stur            x3, [fp, #-0x58]
    // 0x12f04f8: r1 = <Never>
    //     0x12f04f8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f04fc: r0 = Pointer()
    //     0x12f04fc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0500: mov             x1, x0
    // 0x12f0504: ldur            x0, [fp, #-0x58]
    // 0x12f0508: StoreField: r1->field_7 = r0
    //     0x12f0508: stur            x0, [x1, #7]
    // 0x12f050c: ldur            d0, [fp, #-0x78]
    // 0x12f0510: ldur            d1, [fp, #-0x70]
    // 0x12f0514: r0 = _moveTo$Method$FfiNative()
    //     0x12f0514: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12f0518: ldur            x0, [fp, #-0x10]
    // 0x12f051c: LoadField: d0 = r0->field_7
    //     0x12f051c: ldur            d0, [x0, #7]
    // 0x12f0520: ldur            x2, [fp, #-0x50]
    // 0x12f0524: stur            d0, [fp, #-0x80]
    // 0x12f0528: LoadField: r1 = r2->field_7
    //     0x12f0528: ldur            w1, [x2, #7]
    // 0x12f052c: DecompressPointer r1
    //     0x12f052c: add             x1, x1, HEAP, lsl #32
    // 0x12f0530: cmp             w1, NULL
    // 0x12f0534: b.eq            #0x12f0ba8
    // 0x12f0538: LoadField: r3 = r1->field_7
    //     0x12f0538: ldur            x3, [x1, #7]
    // 0x12f053c: ldr             x1, [x3]
    // 0x12f0540: cbz             x1, #0x12f0ac0
    // 0x12f0544: ldur            x3, [fp, #-0x18]
    // 0x12f0548: mov             x4, x1
    // 0x12f054c: stur            x4, [fp, #-0x58]
    // 0x12f0550: r1 = <Never>
    //     0x12f0550: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0554: r0 = Pointer()
    //     0x12f0554: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0558: mov             x1, x0
    // 0x12f055c: ldur            x0, [fp, #-0x58]
    // 0x12f0560: StoreField: r1->field_7 = r0
    //     0x12f0560: stur            x0, [x1, #7]
    // 0x12f0564: ldur            d0, [fp, #-0x80]
    // 0x12f0568: ldur            d1, [fp, #-0x70]
    // 0x12f056c: r0 = _lineTo$Method$FfiNative()
    //     0x12f056c: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0570: ldur            x0, [fp, #-0x18]
    // 0x12f0574: LoadField: d0 = r0->field_b
    //     0x12f0574: ldur            d0, [x0, #0xb]
    // 0x12f0578: d1 = 0.000000
    //     0x12f0578: eor             v1.16b, v1.16b, v1.16b
    // 0x12f057c: fcmp            d0, d1
    // 0x12f0580: b.ne            #0x12f0598
    // 0x12f0584: ldur            x2, [fp, #-0x40]
    // 0x12f0588: r3 = 1
    //     0x12f0588: mov             x3, #1
    // 0x12f058c: LoadField: r1 = r2->field_7
    //     0x12f058c: ldur            x1, [x2, #7]
    // 0x12f0590: str             w3, [x1, #0x1c]
    // 0x12f0594: b               #0x12f0674
    // 0x12f0598: ldur            x5, [fp, #-0x20]
    // 0x12f059c: ldur            x4, [fp, #-0x50]
    // 0x12f05a0: ldur            d3, [fp, #-0x70]
    // 0x12f05a4: ldur            d2, [fp, #-0x80]
    // 0x12f05a8: ldur            x2, [fp, #-0x40]
    // 0x12f05ac: r3 = 1
    //     0x12f05ac: mov             x3, #1
    // 0x12f05b0: LoadField: r1 = r2->field_7
    //     0x12f05b0: ldur            x1, [x2, #7]
    // 0x12f05b4: str             wzr, [x1, #0x1c]
    // 0x12f05b8: LoadField: d4 = r5->field_b
    //     0x12f05b8: ldur            d4, [x5, #0xb]
    // 0x12f05bc: fadd            d5, d2, d4
    // 0x12f05c0: stur            d5, [fp, #-0x88]
    // 0x12f05c4: fsub            d2, d3, d0
    // 0x12f05c8: stur            d2, [fp, #-0x80]
    // 0x12f05cc: LoadField: r1 = r4->field_7
    //     0x12f05cc: ldur            w1, [x4, #7]
    // 0x12f05d0: DecompressPointer r1
    //     0x12f05d0: add             x1, x1, HEAP, lsl #32
    // 0x12f05d4: cmp             w1, NULL
    // 0x12f05d8: b.eq            #0x12f0bac
    // 0x12f05dc: LoadField: r6 = r1->field_7
    //     0x12f05dc: ldur            x6, [x1, #7]
    // 0x12f05e0: ldr             x1, [x6]
    // 0x12f05e4: cbz             x1, #0x12f0ad0
    // 0x12f05e8: ldur            x6, [fp, #-0x28]
    // 0x12f05ec: ldur            d0, [fp, #-0x78]
    // 0x12f05f0: mov             x7, x1
    // 0x12f05f4: stur            x7, [fp, #-0x58]
    // 0x12f05f8: r1 = <Never>
    //     0x12f05f8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f05fc: r0 = Pointer()
    //     0x12f05fc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0600: mov             x1, x0
    // 0x12f0604: ldur            x0, [fp, #-0x58]
    // 0x12f0608: StoreField: r1->field_7 = r0
    //     0x12f0608: stur            x0, [x1, #7]
    // 0x12f060c: ldur            d0, [fp, #-0x88]
    // 0x12f0610: ldur            d1, [fp, #-0x80]
    // 0x12f0614: r0 = _lineTo$Method$FfiNative()
    //     0x12f0614: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0618: ldur            x0, [fp, #-0x28]
    // 0x12f061c: LoadField: d0 = r0->field_b
    //     0x12f061c: ldur            d0, [x0, #0xb]
    // 0x12f0620: ldur            d1, [fp, #-0x78]
    // 0x12f0624: fsub            d2, d1, d0
    // 0x12f0628: ldur            x0, [fp, #-0x50]
    // 0x12f062c: stur            d2, [fp, #-0x70]
    // 0x12f0630: LoadField: r1 = r0->field_7
    //     0x12f0630: ldur            w1, [x0, #7]
    // 0x12f0634: DecompressPointer r1
    //     0x12f0634: add             x1, x1, HEAP, lsl #32
    // 0x12f0638: cmp             w1, NULL
    // 0x12f063c: b.eq            #0x12f0bb0
    // 0x12f0640: LoadField: r2 = r1->field_7
    //     0x12f0640: ldur            x2, [x1, #7]
    // 0x12f0644: ldr             x1, [x2]
    // 0x12f0648: cbz             x1, #0x12f0ae0
    // 0x12f064c: mov             x2, x1
    // 0x12f0650: stur            x2, [fp, #-0x58]
    // 0x12f0654: r1 = <Never>
    //     0x12f0654: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0658: r0 = Pointer()
    //     0x12f0658: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f065c: mov             x1, x0
    // 0x12f0660: ldur            x0, [fp, #-0x58]
    // 0x12f0664: StoreField: r1->field_7 = r0
    //     0x12f0664: stur            x0, [x1, #7]
    // 0x12f0668: ldur            d0, [fp, #-0x70]
    // 0x12f066c: ldur            d1, [fp, #-0x80]
    // 0x12f0670: r0 = _lineTo$Method$FfiNative()
    //     0x12f0670: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0674: ldur            x2, [fp, #-8]
    // 0x12f0678: ldur            x0, [fp, #-0x48]
    // 0x12f067c: LoadField: r3 = r0->field_b
    //     0x12f067c: ldur            w3, [x0, #0xb]
    // 0x12f0680: DecompressPointer r3
    //     0x12f0680: add             x3, x3, HEAP, lsl #32
    // 0x12f0684: stur            x3, [fp, #-0x28]
    // 0x12f0688: LoadField: r1 = r2->field_7
    //     0x12f0688: ldur            w1, [x2, #7]
    // 0x12f068c: DecompressPointer r1
    //     0x12f068c: add             x1, x1, HEAP, lsl #32
    // 0x12f0690: cmp             w1, NULL
    // 0x12f0694: b.eq            #0x12f0bb4
    // 0x12f0698: LoadField: r4 = r1->field_7
    //     0x12f0698: ldur            x4, [x1, #7]
    // 0x12f069c: ldr             x1, [x4]
    // 0x12f06a0: cbz             x1, #0x12f0af0
    // 0x12f06a4: ldur            x4, [fp, #-0x50]
    // 0x12f06a8: mov             x5, x1
    // 0x12f06ac: stur            x5, [fp, #-0x58]
    // 0x12f06b0: r1 = <Never>
    //     0x12f06b0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f06b4: r0 = Pointer()
    //     0x12f06b4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f06b8: mov             x2, x0
    // 0x12f06bc: ldur            x0, [fp, #-0x58]
    // 0x12f06c0: stur            x2, [fp, #-0x60]
    // 0x12f06c4: StoreField: r2->field_7 = r0
    //     0x12f06c4: stur            x0, [x2, #7]
    // 0x12f06c8: ldur            x0, [fp, #-0x50]
    // 0x12f06cc: LoadField: r1 = r0->field_7
    //     0x12f06cc: ldur            w1, [x0, #7]
    // 0x12f06d0: DecompressPointer r1
    //     0x12f06d0: add             x1, x1, HEAP, lsl #32
    // 0x12f06d4: cmp             w1, NULL
    // 0x12f06d8: b.eq            #0x12f0bb8
    // 0x12f06dc: LoadField: r3 = r1->field_7
    //     0x12f06dc: ldur            x3, [x1, #7]
    // 0x12f06e0: ldr             x1, [x3]
    // 0x12f06e4: mov             x3, x1
    // 0x12f06e8: stur            x3, [fp, #-0x58]
    // 0x12f06ec: r1 = <Never>
    //     0x12f06ec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f06f0: r0 = Pointer()
    //     0x12f06f0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f06f4: mov             x1, x0
    // 0x12f06f8: ldur            x0, [fp, #-0x58]
    // 0x12f06fc: StoreField: r1->field_7 = r0
    //     0x12f06fc: stur            x0, [x1, #7]
    // 0x12f0700: mov             x2, x1
    // 0x12f0704: ldur            x1, [fp, #-0x60]
    // 0x12f0708: ldur            x3, [fp, #-0x28]
    // 0x12f070c: ldur            x5, [fp, #-0x38]
    // 0x12f0710: r0 = __drawPath$Method$FfiNative()
    //     0x12f0710: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f0714: ldur            x0, [fp, #-0x20]
    // 0x12f0718: LoadField: r1 = r0->field_13
    //     0x12f0718: ldur            w1, [x0, #0x13]
    // 0x12f071c: DecompressPointer r1
    //     0x12f071c: add             x1, x1, HEAP, lsl #32
    // 0x12f0720: LoadField: r2 = r1->field_7
    //     0x12f0720: ldur            x2, [x1, #7]
    // 0x12f0724: cmp             x2, #0
    // 0x12f0728: b.le            #0x12f09d0
    // 0x12f072c: ldur            x3, [fp, #-0x50]
    // 0x12f0730: LoadField: r2 = r0->field_7
    //     0x12f0730: ldur            w2, [x0, #7]
    // 0x12f0734: DecompressPointer r2
    //     0x12f0734: add             x2, x2, HEAP, lsl #32
    // 0x12f0738: ldur            x1, [fp, #-0x48]
    // 0x12f073c: r0 = color=()
    //     0x12f073c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f0740: ldur            x0, [fp, #-0x50]
    // 0x12f0744: LoadField: r1 = r0->field_7
    //     0x12f0744: ldur            w1, [x0, #7]
    // 0x12f0748: DecompressPointer r1
    //     0x12f0748: add             x1, x1, HEAP, lsl #32
    // 0x12f074c: cmp             w1, NULL
    // 0x12f0750: b.eq            #0x12f0bbc
    // 0x12f0754: LoadField: r2 = r1->field_7
    //     0x12f0754: ldur            x2, [x1, #7]
    // 0x12f0758: ldr             x1, [x2]
    // 0x12f075c: cbz             x1, #0x12f0b00
    // 0x12f0760: ldur            x2, [fp, #-0x10]
    // 0x12f0764: mov             x3, x1
    // 0x12f0768: stur            x3, [fp, #-0x58]
    // 0x12f076c: r1 = <Never>
    //     0x12f076c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0770: r0 = Pointer()
    //     0x12f0770: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0774: mov             x1, x0
    // 0x12f0778: ldur            x0, [fp, #-0x58]
    // 0x12f077c: StoreField: r1->field_7 = r0
    //     0x12f077c: stur            x0, [x1, #7]
    // 0x12f0780: r0 = _reset$Method$FfiNative()
    //     0x12f0780: bl              #0xc33450  ; [dart:ui] _NativePath::_reset$Method$FfiNative
    // 0x12f0784: ldur            x0, [fp, #-0x10]
    // 0x12f0788: LoadField: d0 = r0->field_7
    //     0x12f0788: ldur            d0, [x0, #7]
    // 0x12f078c: stur            d0, [fp, #-0x78]
    // 0x12f0790: LoadField: d1 = r0->field_1f
    //     0x12f0790: ldur            d1, [x0, #0x1f]
    // 0x12f0794: ldur            x2, [fp, #-0x50]
    // 0x12f0798: stur            d1, [fp, #-0x70]
    // 0x12f079c: LoadField: r1 = r2->field_7
    //     0x12f079c: ldur            w1, [x2, #7]
    // 0x12f07a0: DecompressPointer r1
    //     0x12f07a0: add             x1, x1, HEAP, lsl #32
    // 0x12f07a4: cmp             w1, NULL
    // 0x12f07a8: b.eq            #0x12f0bc0
    // 0x12f07ac: LoadField: r3 = r1->field_7
    //     0x12f07ac: ldur            x3, [x1, #7]
    // 0x12f07b0: ldr             x1, [x3]
    // 0x12f07b4: cbz             x1, #0x12f0b10
    // 0x12f07b8: mov             x3, x1
    // 0x12f07bc: stur            x3, [fp, #-0x58]
    // 0x12f07c0: r1 = <Never>
    //     0x12f07c0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f07c4: r0 = Pointer()
    //     0x12f07c4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f07c8: mov             x1, x0
    // 0x12f07cc: ldur            x0, [fp, #-0x58]
    // 0x12f07d0: StoreField: r1->field_7 = r0
    //     0x12f07d0: stur            x0, [x1, #7]
    // 0x12f07d4: ldur            d0, [fp, #-0x78]
    // 0x12f07d8: ldur            d1, [fp, #-0x70]
    // 0x12f07dc: r0 = _moveTo$Method$FfiNative()
    //     0x12f07dc: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12f07e0: ldur            x0, [fp, #-0x10]
    // 0x12f07e4: LoadField: d1 = r0->field_f
    //     0x12f07e4: ldur            d1, [x0, #0xf]
    // 0x12f07e8: ldur            x0, [fp, #-0x50]
    // 0x12f07ec: stur            d1, [fp, #-0x80]
    // 0x12f07f0: LoadField: r1 = r0->field_7
    //     0x12f07f0: ldur            w1, [x0, #7]
    // 0x12f07f4: DecompressPointer r1
    //     0x12f07f4: add             x1, x1, HEAP, lsl #32
    // 0x12f07f8: cmp             w1, NULL
    // 0x12f07fc: b.eq            #0x12f0bc4
    // 0x12f0800: LoadField: r2 = r1->field_7
    //     0x12f0800: ldur            x2, [x1, #7]
    // 0x12f0804: ldr             x1, [x2]
    // 0x12f0808: cbz             x1, #0x12f0b20
    // 0x12f080c: ldur            x2, [fp, #-0x20]
    // 0x12f0810: mov             x3, x1
    // 0x12f0814: stur            x3, [fp, #-0x58]
    // 0x12f0818: r1 = <Never>
    //     0x12f0818: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f081c: r0 = Pointer()
    //     0x12f081c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0820: mov             x1, x0
    // 0x12f0824: ldur            x0, [fp, #-0x58]
    // 0x12f0828: StoreField: r1->field_7 = r0
    //     0x12f0828: stur            x0, [x1, #7]
    // 0x12f082c: ldur            d0, [fp, #-0x78]
    // 0x12f0830: ldur            d1, [fp, #-0x80]
    // 0x12f0834: r0 = _lineTo$Method$FfiNative()
    //     0x12f0834: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0838: ldur            x0, [fp, #-0x20]
    // 0x12f083c: LoadField: d0 = r0->field_b
    //     0x12f083c: ldur            d0, [x0, #0xb]
    // 0x12f0840: d1 = 0.000000
    //     0x12f0840: eor             v1.16b, v1.16b, v1.16b
    // 0x12f0844: fcmp            d0, d1
    // 0x12f0848: b.ne            #0x12f0860
    // 0x12f084c: ldur            x0, [fp, #-0x40]
    // 0x12f0850: r1 = 1
    //     0x12f0850: mov             x1, #1
    // 0x12f0854: LoadField: r2 = r0->field_7
    //     0x12f0854: ldur            x2, [x0, #7]
    // 0x12f0858: str             w1, [x2, #0x1c]
    // 0x12f085c: b               #0x12f0934
    // 0x12f0860: ldur            x1, [fp, #-0x30]
    // 0x12f0864: ldur            x2, [fp, #-0x50]
    // 0x12f0868: ldur            d2, [fp, #-0x78]
    // 0x12f086c: ldur            d1, [fp, #-0x80]
    // 0x12f0870: ldur            x0, [fp, #-0x40]
    // 0x12f0874: LoadField: r3 = r0->field_7
    //     0x12f0874: ldur            x3, [x0, #7]
    // 0x12f0878: str             wzr, [x3, #0x1c]
    // 0x12f087c: fadd            d3, d2, d0
    // 0x12f0880: stur            d3, [fp, #-0x88]
    // 0x12f0884: LoadField: d0 = r1->field_b
    //     0x12f0884: ldur            d0, [x1, #0xb]
    // 0x12f0888: fadd            d2, d1, d0
    // 0x12f088c: stur            d2, [fp, #-0x78]
    // 0x12f0890: LoadField: r0 = r2->field_7
    //     0x12f0890: ldur            w0, [x2, #7]
    // 0x12f0894: DecompressPointer r0
    //     0x12f0894: add             x0, x0, HEAP, lsl #32
    // 0x12f0898: cmp             w0, NULL
    // 0x12f089c: b.eq            #0x12f0bc8
    // 0x12f08a0: LoadField: r1 = r0->field_7
    //     0x12f08a0: ldur            x1, [x0, #7]
    // 0x12f08a4: ldr             x0, [x1]
    // 0x12f08a8: cbz             x0, #0x12f0b30
    // 0x12f08ac: ldur            x3, [fp, #-0x18]
    // 0x12f08b0: ldur            d0, [fp, #-0x70]
    // 0x12f08b4: stur            x0, [fp, #-0x58]
    // 0x12f08b8: r1 = <Never>
    //     0x12f08b8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f08bc: r0 = Pointer()
    //     0x12f08bc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f08c0: mov             x1, x0
    // 0x12f08c4: ldur            x0, [fp, #-0x58]
    // 0x12f08c8: StoreField: r1->field_7 = r0
    //     0x12f08c8: stur            x0, [x1, #7]
    // 0x12f08cc: ldur            d0, [fp, #-0x88]
    // 0x12f08d0: ldur            d1, [fp, #-0x78]
    // 0x12f08d4: r0 = _lineTo$Method$FfiNative()
    //     0x12f08d4: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f08d8: ldur            x0, [fp, #-0x18]
    // 0x12f08dc: LoadField: d0 = r0->field_b
    //     0x12f08dc: ldur            d0, [x0, #0xb]
    // 0x12f08e0: ldur            d1, [fp, #-0x70]
    // 0x12f08e4: fsub            d2, d1, d0
    // 0x12f08e8: ldur            x0, [fp, #-0x50]
    // 0x12f08ec: stur            d2, [fp, #-0x78]
    // 0x12f08f0: LoadField: r1 = r0->field_7
    //     0x12f08f0: ldur            w1, [x0, #7]
    // 0x12f08f4: DecompressPointer r1
    //     0x12f08f4: add             x1, x1, HEAP, lsl #32
    // 0x12f08f8: cmp             w1, NULL
    // 0x12f08fc: b.eq            #0x12f0bcc
    // 0x12f0900: LoadField: r2 = r1->field_7
    //     0x12f0900: ldur            x2, [x1, #7]
    // 0x12f0904: ldr             x1, [x2]
    // 0x12f0908: cbz             x1, #0x12f0b40
    // 0x12f090c: mov             x2, x1
    // 0x12f0910: stur            x2, [fp, #-0x58]
    // 0x12f0914: r1 = <Never>
    //     0x12f0914: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0918: r0 = Pointer()
    //     0x12f0918: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f091c: mov             x1, x0
    // 0x12f0920: ldur            x0, [fp, #-0x58]
    // 0x12f0924: StoreField: r1->field_7 = r0
    //     0x12f0924: stur            x0, [x1, #7]
    // 0x12f0928: ldur            d0, [fp, #-0x88]
    // 0x12f092c: ldur            d1, [fp, #-0x78]
    // 0x12f0930: r0 = _lineTo$Method$FfiNative()
    //     0x12f0930: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12f0934: ldur            x2, [fp, #-8]
    // 0x12f0938: ldur            x0, [fp, #-0x48]
    // 0x12f093c: LoadField: r3 = r0->field_b
    //     0x12f093c: ldur            w3, [x0, #0xb]
    // 0x12f0940: DecompressPointer r3
    //     0x12f0940: add             x3, x3, HEAP, lsl #32
    // 0x12f0944: stur            x3, [fp, #-0x10]
    // 0x12f0948: LoadField: r0 = r2->field_7
    //     0x12f0948: ldur            w0, [x2, #7]
    // 0x12f094c: DecompressPointer r0
    //     0x12f094c: add             x0, x0, HEAP, lsl #32
    // 0x12f0950: cmp             w0, NULL
    // 0x12f0954: b.eq            #0x12f0bd0
    // 0x12f0958: LoadField: r1 = r0->field_7
    //     0x12f0958: ldur            x1, [x0, #7]
    // 0x12f095c: ldr             x0, [x1]
    // 0x12f0960: cbz             x0, #0x12f0b50
    // 0x12f0964: ldur            x4, [fp, #-0x50]
    // 0x12f0968: stur            x0, [fp, #-0x58]
    // 0x12f096c: r1 = <Never>
    //     0x12f096c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f0970: r0 = Pointer()
    //     0x12f0970: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f0974: mov             x2, x0
    // 0x12f0978: ldur            x0, [fp, #-0x58]
    // 0x12f097c: stur            x2, [fp, #-0x18]
    // 0x12f0980: StoreField: r2->field_7 = r0
    //     0x12f0980: stur            x0, [x2, #7]
    // 0x12f0984: ldur            x0, [fp, #-0x50]
    // 0x12f0988: LoadField: r1 = r0->field_7
    //     0x12f0988: ldur            w1, [x0, #7]
    // 0x12f098c: DecompressPointer r1
    //     0x12f098c: add             x1, x1, HEAP, lsl #32
    // 0x12f0990: cmp             w1, NULL
    // 0x12f0994: b.eq            #0x12f0bd4
    // 0x12f0998: LoadField: r3 = r1->field_7
    //     0x12f0998: ldur            x3, [x1, #7]
    // 0x12f099c: ldr             x1, [x3]
    // 0x12f09a0: mov             x3, x1
    // 0x12f09a4: stur            x3, [fp, #-0x58]
    // 0x12f09a8: r1 = <Never>
    //     0x12f09a8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f09ac: r0 = Pointer()
    //     0x12f09ac: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f09b0: mov             x1, x0
    // 0x12f09b4: ldur            x0, [fp, #-0x58]
    // 0x12f09b8: StoreField: r1->field_7 = r0
    //     0x12f09b8: stur            x0, [x1, #7]
    // 0x12f09bc: mov             x2, x1
    // 0x12f09c0: ldur            x1, [fp, #-0x18]
    // 0x12f09c4: ldur            x3, [fp, #-0x10]
    // 0x12f09c8: ldur            x5, [fp, #-0x38]
    // 0x12f09cc: r0 = __drawPath$Method$FfiNative()
    //     0x12f09cc: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12f09d0: r0 = Null
    //     0x12f09d0: mov             x0, NULL
    // 0x12f09d4: LeaveFrame
    //     0x12f09d4: mov             SP, fp
    //     0x12f09d8: ldp             fp, lr, [SP], #0x10
    // 0x12f09dc: ret
    //     0x12f09dc: ret             
    // 0x12f09e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f09e0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f09e4: str             x16, [SP]
    // 0x12f09e8: r0 = _throwNew()
    //     0x12f09e8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f09ec: brk             #0
    // 0x12f09f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f09f0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f09f4: str             x16, [SP]
    // 0x12f09f8: r0 = _throwNew()
    //     0x12f09f8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f09fc: brk             #0
    // 0x12f0a00: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a00: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a04: str             x16, [SP]
    // 0x12f0a08: r0 = _throwNew()
    //     0x12f0a08: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a0c: brk             #0
    // 0x12f0a10: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a10: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a14: str             x16, [SP]
    // 0x12f0a18: r0 = _throwNew()
    //     0x12f0a18: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a1c: brk             #0
    // 0x12f0a20: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a20: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a24: str             x16, [SP]
    // 0x12f0a28: r0 = _throwNew()
    //     0x12f0a28: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a2c: brk             #0
    // 0x12f0a30: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a30: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a34: str             x16, [SP]
    // 0x12f0a38: r0 = _throwNew()
    //     0x12f0a38: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a3c: brk             #0
    // 0x12f0a40: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a40: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a44: str             x16, [SP]
    // 0x12f0a48: r0 = _throwNew()
    //     0x12f0a48: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a4c: brk             #0
    // 0x12f0a50: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a50: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a54: str             x16, [SP]
    // 0x12f0a58: r0 = _throwNew()
    //     0x12f0a58: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a5c: brk             #0
    // 0x12f0a60: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a60: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a64: str             x16, [SP]
    // 0x12f0a68: r0 = _throwNew()
    //     0x12f0a68: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a6c: brk             #0
    // 0x12f0a70: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a70: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a74: str             x16, [SP]
    // 0x12f0a78: r0 = _throwNew()
    //     0x12f0a78: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a7c: brk             #0
    // 0x12f0a80: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a80: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a84: str             x16, [SP]
    // 0x12f0a88: r0 = _throwNew()
    //     0x12f0a88: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a8c: brk             #0
    // 0x12f0a90: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0a90: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0a94: str             x16, [SP]
    // 0x12f0a98: r0 = _throwNew()
    //     0x12f0a98: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0a9c: brk             #0
    // 0x12f0aa0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0aa0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0aa4: str             x16, [SP]
    // 0x12f0aa8: r0 = _throwNew()
    //     0x12f0aa8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0aac: brk             #0
    // 0x12f0ab0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0ab0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0ab4: str             x16, [SP]
    // 0x12f0ab8: r0 = _throwNew()
    //     0x12f0ab8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0abc: brk             #0
    // 0x12f0ac0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0ac0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0ac4: str             x16, [SP]
    // 0x12f0ac8: r0 = _throwNew()
    //     0x12f0ac8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0acc: brk             #0
    // 0x12f0ad0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0ad0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0ad4: str             x16, [SP]
    // 0x12f0ad8: r0 = _throwNew()
    //     0x12f0ad8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0adc: brk             #0
    // 0x12f0ae0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0ae0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0ae4: str             x16, [SP]
    // 0x12f0ae8: r0 = _throwNew()
    //     0x12f0ae8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0aec: brk             #0
    // 0x12f0af0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0af0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0af4: str             x16, [SP]
    // 0x12f0af8: r0 = _throwNew()
    //     0x12f0af8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0afc: brk             #0
    // 0x12f0b00: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b00: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b04: str             x16, [SP]
    // 0x12f0b08: r0 = _throwNew()
    //     0x12f0b08: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b0c: brk             #0
    // 0x12f0b10: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b10: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b14: str             x16, [SP]
    // 0x12f0b18: r0 = _throwNew()
    //     0x12f0b18: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b1c: brk             #0
    // 0x12f0b20: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b20: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b24: str             x16, [SP]
    // 0x12f0b28: r0 = _throwNew()
    //     0x12f0b28: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b2c: brk             #0
    // 0x12f0b30: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b30: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b34: str             x16, [SP]
    // 0x12f0b38: r0 = _throwNew()
    //     0x12f0b38: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b3c: brk             #0
    // 0x12f0b40: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b40: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b44: str             x16, [SP]
    // 0x12f0b48: r0 = _throwNew()
    //     0x12f0b48: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b4c: brk             #0
    // 0x12f0b50: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f0b50: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f0b54: str             x16, [SP]
    // 0x12f0b58: r0 = _throwNew()
    //     0x12f0b58: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f0b5c: brk             #0
    // 0x12f0b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f0b60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f0b64: b               #0x12efe78
    // 0x12f0b68: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b68: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0b6c: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b6c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b70: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b70: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b74: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b74: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b78: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b78: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b7c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b7c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0b80: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b80: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0b84: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b84: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0b88: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b88: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b8c: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b8c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b90: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b90: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b94: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0b94: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0b98: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b98: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0b9c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0b9c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0ba0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0ba0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0ba4: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0ba4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0ba8: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0ba8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bac: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bac: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bb0: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bb0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bb4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0bb4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0bb8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0bb8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0bbc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0bbc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0bc0: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bc0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bc4: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bc4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bc8: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bc8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bcc: r0 = NullErrorSharedWithFPURegs()
    //     0x12f0bcc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12f0bd0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0bd0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12f0bd4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f0bd4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3010, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ShapeBorder extends Object {

  ShapeBorder +(ShapeBorder, ShapeBorder) {
    // ** addr: 0x8a7360, size: 0x68
    // 0x8a7360: EnterFrame
    //     0x8a7360: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7364: mov             fp, SP
    // 0x8a7368: ldr             x0, [fp, #0x10]
    // 0x8a736c: r2 = Null
    //     0x8a736c: mov             x2, NULL
    // 0x8a7370: r1 = Null
    //     0x8a7370: mov             x1, NULL
    // 0x8a7374: r4 = 60
    //     0x8a7374: mov             x4, #0x3c
    // 0x8a7378: branchIfSmi(r0, 0x8a7384)
    //     0x8a7378: tbz             w0, #0, #0x8a7384
    // 0x8a737c: r4 = LoadClassIdInstr(r0)
    //     0x8a737c: ldur            x4, [x0, #-1]
    //     0x8a7380: ubfx            x4, x4, #0xc, #0x14
    // 0x8a7384: sub             x4, x4, #0xbc4
    // 0x8a7388: cmp             x4, #0x11
    // 0x8a738c: b.ls            #0x8a73a4
    // 0x8a7390: r8 = ShapeBorder
    //     0x8a7390: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8ee78] Type: ShapeBorder
    //     0x8a7394: ldr             x8, [x8, #0xe78]
    // 0x8a7398: r3 = Null
    //     0x8a7398: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8ee80] Null
    //     0x8a739c: ldr             x3, [x3, #0xe80]
    // 0x8a73a0: r0 = DefaultTypeTest()
    //     0x8a73a0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8a73a4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x8a73a4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x8a73a8: r0 = Throw()
    //     0x8a73a8: bl              #0x13ddb2c  ; ThrowStub
    // 0x8a73ac: brk             #0
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ee854, size: 0x54
    // 0x10ee854: EnterFrame
    //     0x10ee854: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee858: mov             fp, SP
    // 0x10ee85c: CheckStackOverflow
    //     0x10ee85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee860: cmp             SP, x16
    //     0x10ee864: b.ls            #0x10ee8a0
    // 0x10ee868: cmp             w2, NULL
    // 0x10ee86c: b.ne            #0x10ee890
    // 0x10ee870: r0 = LoadClassIdInstr(r1)
    //     0x10ee870: ldur            x0, [x1, #-1]
    //     0x10ee874: ubfx            x0, x0, #0xc, #0x14
    // 0x10ee878: r0 = GDT[cid_x0 + -0xf5f]()
    //     0x10ee878: sub             lr, x0, #0xf5f
    //     0x10ee87c: ldr             lr, [x21, lr, lsl #3]
    //     0x10ee880: blr             lr
    // 0x10ee884: LeaveFrame
    //     0x10ee884: mov             SP, fp
    //     0x10ee888: ldp             fp, lr, [SP], #0x10
    // 0x10ee88c: ret
    //     0x10ee88c: ret             
    // 0x10ee890: r0 = Null
    //     0x10ee890: mov             x0, NULL
    // 0x10ee894: LeaveFrame
    //     0x10ee894: mov             SP, fp
    //     0x10ee898: ldp             fp, lr, [SP], #0x10
    // 0x10ee89c: ret
    //     0x10ee89c: ret             
    // 0x10ee8a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee8a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee8a4: b               #0x10ee868
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f17e8, size: 0x60
    // 0x10f17e8: EnterFrame
    //     0x10f17e8: stp             fp, lr, [SP, #-0x10]!
    //     0x10f17ec: mov             fp, SP
    // 0x10f17f0: CheckStackOverflow
    //     0x10f17f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f17f4: cmp             SP, x16
    //     0x10f17f8: b.ls            #0x10f1840
    // 0x10f17fc: cmp             w2, NULL
    // 0x10f1800: b.ne            #0x10f1830
    // 0x10f1804: d1 = 1.000000
    //     0x10f1804: fmov            d1, #1.00000000
    // 0x10f1808: fsub            d2, d1, d0
    // 0x10f180c: r0 = LoadClassIdInstr(r1)
    //     0x10f180c: ldur            x0, [x1, #-1]
    //     0x10f1810: ubfx            x0, x0, #0xc, #0x14
    // 0x10f1814: mov             v0.16b, v2.16b
    // 0x10f1818: r0 = GDT[cid_x0 + -0xf5f]()
    //     0x10f1818: sub             lr, x0, #0xf5f
    //     0x10f181c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f1820: blr             lr
    // 0x10f1824: LeaveFrame
    //     0x10f1824: mov             SP, fp
    //     0x10f1828: ldp             fp, lr, [SP], #0x10
    // 0x10f182c: ret
    //     0x10f182c: ret             
    // 0x10f1830: r0 = Null
    //     0x10f1830: mov             x0, NULL
    // 0x10f1834: LeaveFrame
    //     0x10f1834: mov             SP, fp
    //     0x10f1838: ldp             fp, lr, [SP], #0x10
    // 0x10f183c: ret
    //     0x10f183c: ret             
    // 0x10f1840: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f1840: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f1844: b               #0x10f17fc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x115deb4, size: 0x10c
    // 0x115deb4: EnterFrame
    //     0x115deb4: stp             fp, lr, [SP, #-0x10]!
    //     0x115deb8: mov             fp, SP
    // 0x115debc: AllocStack(0x18)
    //     0x115debc: sub             SP, SP, #0x18
    // 0x115dec0: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x18 */)
    //     0x115dec0: mov             x4, x1
    //     0x115dec4: mov             x3, x2
    //     0x115dec8: mov             v1.16b, v0.16b
    //     0x115decc: stur            x1, [fp, #-8]
    //     0x115ded0: stur            x2, [fp, #-0x10]
    //     0x115ded4: stur            d0, [fp, #-0x18]
    // 0x115ded8: CheckStackOverflow
    //     0x115ded8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115dedc: cmp             SP, x16
    //     0x115dee0: b.ls            #0x115dfb8
    // 0x115dee4: cmp             w4, w3
    // 0x115dee8: b.ne            #0x115defc
    // 0x115deec: mov             x0, x4
    // 0x115def0: LeaveFrame
    //     0x115def0: mov             SP, fp
    //     0x115def4: ldp             fp, lr, [SP], #0x10
    // 0x115def8: ret
    //     0x115def8: ret             
    // 0x115defc: cmp             w3, NULL
    // 0x115df00: b.ne            #0x115df0c
    // 0x115df04: r0 = Null
    //     0x115df04: mov             x0, NULL
    // 0x115df08: b               #0x115df30
    // 0x115df0c: r0 = LoadClassIdInstr(r3)
    //     0x115df0c: ldur            x0, [x3, #-1]
    //     0x115df10: ubfx            x0, x0, #0xc, #0x14
    // 0x115df14: mov             x1, x3
    // 0x115df18: mov             x2, x4
    // 0x115df1c: mov             v0.16b, v1.16b
    // 0x115df20: r0 = GDT[cid_x0 + 0xce0a]()
    //     0x115df20: mov             x17, #0xce0a
    //     0x115df24: add             lr, x0, x17
    //     0x115df28: ldr             lr, [x21, lr, lsl #3]
    //     0x115df2c: blr             lr
    // 0x115df30: cmp             w0, NULL
    // 0x115df34: b.ne            #0x115df78
    // 0x115df38: ldur            x3, [fp, #-8]
    // 0x115df3c: cmp             w3, NULL
    // 0x115df40: b.ne            #0x115df4c
    // 0x115df44: r1 = Null
    //     0x115df44: mov             x1, NULL
    // 0x115df48: b               #0x115df7c
    // 0x115df4c: r0 = LoadClassIdInstr(r3)
    //     0x115df4c: ldur            x0, [x3, #-1]
    //     0x115df50: ubfx            x0, x0, #0xc, #0x14
    // 0x115df54: mov             x1, x3
    // 0x115df58: ldur            x2, [fp, #-0x10]
    // 0x115df5c: ldur            d0, [fp, #-0x18]
    // 0x115df60: r0 = GDT[cid_x0 + 0xcc4a]()
    //     0x115df60: mov             x17, #0xcc4a
    //     0x115df64: add             lr, x0, x17
    //     0x115df68: ldr             lr, [x21, lr, lsl #3]
    //     0x115df6c: blr             lr
    // 0x115df70: mov             x1, x0
    // 0x115df74: b               #0x115df7c
    // 0x115df78: mov             x1, x0
    // 0x115df7c: cmp             w1, NULL
    // 0x115df80: b.ne            #0x115dfa8
    // 0x115df84: ldur            d0, [fp, #-0x18]
    // 0x115df88: d1 = 0.500000
    //     0x115df88: fmov            d1, #0.50000000
    // 0x115df8c: fcmp            d1, d0
    // 0x115df90: b.le            #0x115df9c
    // 0x115df94: ldur            x2, [fp, #-8]
    // 0x115df98: b               #0x115dfa0
    // 0x115df9c: ldur            x2, [fp, #-0x10]
    // 0x115dfa0: mov             x0, x2
    // 0x115dfa4: b               #0x115dfac
    // 0x115dfa8: mov             x0, x1
    // 0x115dfac: LeaveFrame
    //     0x115dfac: mov             SP, fp
    //     0x115dfb0: ldp             fp, lr, [SP], #0x10
    // 0x115dfb4: ret
    //     0x115dfb4: ret             
    // 0x115dfb8: r0 = StackOverflowSharedWithFPURegs()
    //     0x115dfb8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115dfbc: b               #0x115dee4
  }
}

// class id: 3019, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class OutlinedBorder extends ShapeBorder {

  [closure] static OutlinedBorder? lerp(dynamic, OutlinedBorder?, OutlinedBorder?, double) {
    // ** addr: 0x1165118, size: 0x38
    // 0x1165118: EnterFrame
    //     0x1165118: stp             fp, lr, [SP, #-0x10]!
    //     0x116511c: mov             fp, SP
    // 0x1165120: CheckStackOverflow
    //     0x1165120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165124: cmp             SP, x16
    //     0x1165128: b.ls            #0x1165148
    // 0x116512c: ldr             x1, [fp, #0x20]
    // 0x1165130: ldr             x2, [fp, #0x18]
    // 0x1165134: ldr             x3, [fp, #0x10]
    // 0x1165138: r0 = lerp()
    //     0x1165138: bl              #0x1165150  ; [package:flutter/src/painting/borders.dart] OutlinedBorder::lerp
    // 0x116513c: LeaveFrame
    //     0x116513c: mov             SP, fp
    //     0x1165140: ldp             fp, lr, [SP], #0x10
    // 0x1165144: ret
    //     0x1165144: ret             
    // 0x1165148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1165148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116514c: b               #0x116512c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165150, size: 0x110
    // 0x1165150: EnterFrame
    //     0x1165150: stp             fp, lr, [SP, #-0x10]!
    //     0x1165154: mov             fp, SP
    // 0x1165158: AllocStack(0x18)
    //     0x1165158: sub             SP, SP, #0x18
    // 0x116515c: SetupParameters(dynamic _ /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x116515c: mov             x5, x1
    //     0x1165160: mov             x4, x2
    //     0x1165164: stur            x1, [fp, #-8]
    //     0x1165168: stur            x2, [fp, #-0x10]
    //     0x116516c: stur            x3, [fp, #-0x18]
    // 0x1165170: CheckStackOverflow
    //     0x1165170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165174: cmp             SP, x16
    //     0x1165178: b.ls            #0x1165258
    // 0x116517c: cmp             w5, w4
    // 0x1165180: b.ne            #0x1165194
    // 0x1165184: mov             x0, x5
    // 0x1165188: LeaveFrame
    //     0x1165188: mov             SP, fp
    //     0x116518c: ldp             fp, lr, [SP], #0x10
    // 0x1165190: ret
    //     0x1165190: ret             
    // 0x1165194: cmp             w4, NULL
    // 0x1165198: b.ne            #0x11651a4
    // 0x116519c: r0 = Null
    //     0x116519c: mov             x0, NULL
    // 0x11651a0: b               #0x11651c8
    // 0x11651a4: LoadField: d0 = r3->field_7
    //     0x11651a4: ldur            d0, [x3, #7]
    // 0x11651a8: r0 = LoadClassIdInstr(r4)
    //     0x11651a8: ldur            x0, [x4, #-1]
    //     0x11651ac: ubfx            x0, x0, #0xc, #0x14
    // 0x11651b0: mov             x1, x4
    // 0x11651b4: mov             x2, x5
    // 0x11651b8: r0 = GDT[cid_x0 + 0xce0a]()
    //     0x11651b8: mov             x17, #0xce0a
    //     0x11651bc: add             lr, x0, x17
    //     0x11651c0: ldr             lr, [x21, lr, lsl #3]
    //     0x11651c4: blr             lr
    // 0x11651c8: cmp             w0, NULL
    // 0x11651cc: b.ne            #0x1165214
    // 0x11651d0: ldur            x3, [fp, #-8]
    // 0x11651d4: cmp             w3, NULL
    // 0x11651d8: b.ne            #0x11651e4
    // 0x11651dc: r1 = Null
    //     0x11651dc: mov             x1, NULL
    // 0x11651e0: b               #0x1165218
    // 0x11651e4: ldur            x4, [fp, #-0x18]
    // 0x11651e8: LoadField: d0 = r4->field_7
    //     0x11651e8: ldur            d0, [x4, #7]
    // 0x11651ec: r0 = LoadClassIdInstr(r3)
    //     0x11651ec: ldur            x0, [x3, #-1]
    //     0x11651f0: ubfx            x0, x0, #0xc, #0x14
    // 0x11651f4: mov             x1, x3
    // 0x11651f8: ldur            x2, [fp, #-0x10]
    // 0x11651fc: r0 = GDT[cid_x0 + 0xcc4a]()
    //     0x11651fc: mov             x17, #0xcc4a
    //     0x1165200: add             lr, x0, x17
    //     0x1165204: ldr             lr, [x21, lr, lsl #3]
    //     0x1165208: blr             lr
    // 0x116520c: mov             x1, x0
    // 0x1165210: b               #0x1165218
    // 0x1165214: mov             x1, x0
    // 0x1165218: cmp             w1, NULL
    // 0x116521c: b.ne            #0x1165248
    // 0x1165220: ldur            x2, [fp, #-0x18]
    // 0x1165224: d0 = 0.500000
    //     0x1165224: fmov            d0, #0.50000000
    // 0x1165228: LoadField: d1 = r2->field_7
    //     0x1165228: ldur            d1, [x2, #7]
    // 0x116522c: fcmp            d0, d1
    // 0x1165230: b.le            #0x116523c
    // 0x1165234: ldur            x2, [fp, #-8]
    // 0x1165238: b               #0x1165240
    // 0x116523c: ldur            x2, [fp, #-0x10]
    // 0x1165240: mov             x0, x2
    // 0x1165244: b               #0x116524c
    // 0x1165248: mov             x0, x1
    // 0x116524c: LeaveFrame
    //     0x116524c: mov             SP, fp
    //     0x1165250: ldp             fp, lr, [SP], #0x10
    // 0x1165254: ret
    //     0x1165254: ret             
    // 0x1165258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1165258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116525c: b               #0x116517c
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0x12f55bc, size: 0x64
    // 0x12f55bc: EnterFrame
    //     0x12f55bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12f55c0: mov             fp, SP
    // 0x12f55c4: AllocStack(0x8)
    //     0x12f55c4: sub             SP, SP, #8
    // 0x12f55c8: d2 = 1.000000
    //     0x12f55c8: fmov            d2, #1.00000000
    // 0x12f55cc: d1 = 2.000000
    //     0x12f55cc: fmov            d1, #2.00000000
    // 0x12f55d0: d0 = 0.000000
    //     0x12f55d0: eor             v0.16b, v0.16b, v0.16b
    // 0x12f55d4: LoadField: r0 = r1->field_7
    //     0x12f55d4: ldur            w0, [x1, #7]
    // 0x12f55d8: DecompressPointer r0
    //     0x12f55d8: add             x0, x0, HEAP, lsl #32
    // 0x12f55dc: LoadField: d3 = r0->field_b
    //     0x12f55dc: ldur            d3, [x0, #0xb]
    // 0x12f55e0: ArrayLoad: d4 = r0[0]  ; List_8
    //     0x12f55e0: ldur            d4, [x0, #0x17]
    // 0x12f55e4: fadd            d5, d4, d2
    // 0x12f55e8: fdiv            d4, d5, d1
    // 0x12f55ec: fsub            d1, d2, d4
    // 0x12f55f0: fmul            d2, d3, d1
    // 0x12f55f4: fmax            v1.2d, v2.2d, v0.2d
    // 0x12f55f8: stur            d1, [fp, #-8]
    // 0x12f55fc: r0 = EdgeInsets()
    //     0x12f55fc: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f5600: ldur            d0, [fp, #-8]
    // 0x12f5604: StoreField: r0->field_7 = d0
    //     0x12f5604: stur            d0, [x0, #7]
    // 0x12f5608: StoreField: r0->field_f = d0
    //     0x12f5608: stur            d0, [x0, #0xf]
    // 0x12f560c: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f560c: stur            d0, [x0, #0x17]
    // 0x12f5610: StoreField: r0->field_1f = d0
    //     0x12f5610: stur            d0, [x0, #0x1f]
    // 0x12f5614: LeaveFrame
    //     0x12f5614: mov             SP, fp
    //     0x12f5618: ldp             fp, lr, [SP], #0x10
    // 0x12f561c: ret
    //     0x12f561c: ret             
  }
}

// class id: 5046, size: 0x20, field offset: 0x8
//   const constructor, 
class BorderSide extends _MixinApplication3&Object&Diagnosticable {

  Color field_8;
  _Double field_c;
  BorderStyle field_14;
  _Double field_18;

  static _ lerp(/* No info */) {
    // ** addr: 0xa07be0, size: 0x440
    // 0xa07be0: EnterFrame
    //     0xa07be0: stp             fp, lr, [SP, #-0x10]!
    //     0xa07be4: mov             fp, SP
    // 0xa07be8: AllocStack(0x48)
    //     0xa07be8: sub             SP, SP, #0x48
    // 0xa07bec: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xa07bec: mov             x4, x1
    //     0xa07bf0: mov             x0, x2
    //     0xa07bf4: stur            x1, [fp, #-0x10]
    //     0xa07bf8: stur            x2, [fp, #-0x18]
    // 0xa07bfc: CheckStackOverflow
    //     0xa07bfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa07c00: cmp             SP, x16
    //     0xa07c04: b.ls            #0xa07f6c
    // 0xa07c08: cmp             w4, w0
    // 0xa07c0c: b.ne            #0xa07c20
    // 0xa07c10: mov             x0, x4
    // 0xa07c14: LeaveFrame
    //     0xa07c14: mov             SP, fp
    //     0xa07c18: ldp             fp, lr, [SP], #0x10
    // 0xa07c1c: ret
    //     0xa07c1c: ret             
    // 0xa07c20: d1 = 0.000000
    //     0xa07c20: eor             v1.16b, v1.16b, v1.16b
    // 0xa07c24: fcmp            d0, d1
    // 0xa07c28: b.ne            #0xa07c3c
    // 0xa07c2c: mov             x0, x4
    // 0xa07c30: LeaveFrame
    //     0xa07c30: mov             SP, fp
    //     0xa07c34: ldp             fp, lr, [SP], #0x10
    // 0xa07c38: ret
    //     0xa07c38: ret             
    // 0xa07c3c: d2 = 1.000000
    //     0xa07c3c: fmov            d2, #1.00000000
    // 0xa07c40: fcmp            d0, d2
    // 0xa07c44: b.ne            #0xa07c54
    // 0xa07c48: LeaveFrame
    //     0xa07c48: mov             SP, fp
    //     0xa07c4c: ldp             fp, lr, [SP], #0x10
    // 0xa07c50: ret
    //     0xa07c50: ret             
    // 0xa07c54: LoadField: d2 = r4->field_b
    //     0xa07c54: ldur            d2, [x4, #0xb]
    // 0xa07c58: LoadField: d3 = r0->field_b
    //     0xa07c58: ldur            d3, [x0, #0xb]
    // 0xa07c5c: r5 = inline_Allocate_Double()
    //     0xa07c5c: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xa07c60: add             x5, x5, #0x10
    //     0xa07c64: cmp             x1, x5
    //     0xa07c68: b.ls            #0xa07f74
    //     0xa07c6c: str             x5, [THR, #0x60]  ; THR::top
    //     0xa07c70: sub             x5, x5, #0xf
    //     0xa07c74: mov             x1, #0xe19c
    //     0xa07c78: movk            x1, #3, lsl #16
    //     0xa07c7c: stur            x1, [x5, #-1]
    // 0xa07c80: dmb             ishst
    // 0xa07c84: StoreField: r5->field_7 = d0
    //     0xa07c84: stur            d0, [x5, #7]
    // 0xa07c88: stur            x5, [fp, #-8]
    // 0xa07c8c: r1 = inline_Allocate_Double()
    //     0xa07c8c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa07c90: add             x1, x1, #0x10
    //     0xa07c94: cmp             x2, x1
    //     0xa07c98: b.ls            #0xa07f98
    //     0xa07c9c: str             x1, [THR, #0x60]  ; THR::top
    //     0xa07ca0: sub             x1, x1, #0xf
    //     0xa07ca4: mov             x2, #0xe19c
    //     0xa07ca8: movk            x2, #3, lsl #16
    //     0xa07cac: stur            x2, [x1, #-1]
    // 0xa07cb0: dmb             ishst
    // 0xa07cb4: StoreField: r1->field_7 = d2
    //     0xa07cb4: stur            d2, [x1, #7]
    // 0xa07cb8: r2 = inline_Allocate_Double()
    //     0xa07cb8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa07cbc: add             x2, x2, #0x10
    //     0xa07cc0: cmp             x3, x2
    //     0xa07cc4: b.ls            #0xa07fc4
    //     0xa07cc8: str             x2, [THR, #0x60]  ; THR::top
    //     0xa07ccc: sub             x2, x2, #0xf
    //     0xa07cd0: mov             x3, #0xe19c
    //     0xa07cd4: movk            x3, #3, lsl #16
    //     0xa07cd8: stur            x3, [x2, #-1]
    // 0xa07cdc: dmb             ishst
    // 0xa07ce0: StoreField: r2->field_7 = d3
    //     0xa07ce0: stur            d3, [x2, #7]
    // 0xa07ce4: mov             x3, x5
    // 0xa07ce8: r0 = lerpDouble()
    //     0xa07ce8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xa07cec: LoadField: d0 = r0->field_7
    //     0xa07cec: ldur            d0, [x0, #7]
    // 0xa07cf0: stur            d0, [fp, #-0x40]
    // 0xa07cf4: d1 = 0.000000
    //     0xa07cf4: eor             v1.16b, v1.16b, v1.16b
    // 0xa07cf8: fcmp            d1, d0
    // 0xa07cfc: b.le            #0xa07d14
    // 0xa07d00: r0 = Instance_BorderSide
    //     0xa07d00: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xa07d04: ldr             x0, [x0, #0x310]
    // 0xa07d08: LeaveFrame
    //     0xa07d08: mov             SP, fp
    //     0xa07d0c: ldp             fp, lr, [SP], #0x10
    // 0xa07d10: ret
    //     0xa07d10: ret             
    // 0xa07d14: ldur            x4, [fp, #-0x10]
    // 0xa07d18: ldur            x3, [fp, #-0x18]
    // 0xa07d1c: LoadField: r0 = r4->field_13
    //     0xa07d1c: ldur            w0, [x4, #0x13]
    // 0xa07d20: DecompressPointer r0
    //     0xa07d20: add             x0, x0, HEAP, lsl #32
    // 0xa07d24: stur            x0, [fp, #-0x20]
    // 0xa07d28: LoadField: r5 = r3->field_13
    //     0xa07d28: ldur            w5, [x3, #0x13]
    // 0xa07d2c: DecompressPointer r5
    //     0xa07d2c: add             x5, x5, HEAP, lsl #32
    // 0xa07d30: stur            x5, [fp, #-0x30]
    // 0xa07d34: cmp             w0, w5
    // 0xa07d38: b.ne            #0xa07da4
    // 0xa07d3c: ArrayLoad: d1 = r4[0]  ; List_8
    //     0xa07d3c: ldur            d1, [x4, #0x17]
    // 0xa07d40: stur            d1, [fp, #-0x38]
    // 0xa07d44: ArrayLoad: d2 = r3[0]  ; List_8
    //     0xa07d44: ldur            d2, [x3, #0x17]
    // 0xa07d48: fcmp            d1, d2
    // 0xa07d4c: b.ne            #0xa07da4
    // 0xa07d50: LoadField: r1 = r4->field_7
    //     0xa07d50: ldur            w1, [x4, #7]
    // 0xa07d54: DecompressPointer r1
    //     0xa07d54: add             x1, x1, HEAP, lsl #32
    // 0xa07d58: LoadField: r2 = r3->field_7
    //     0xa07d58: ldur            w2, [x3, #7]
    // 0xa07d5c: DecompressPointer r2
    //     0xa07d5c: add             x2, x2, HEAP, lsl #32
    // 0xa07d60: ldur            x3, [fp, #-8]
    // 0xa07d64: r0 = lerp()
    //     0xa07d64: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xa07d68: stur            x0, [fp, #-0x28]
    // 0xa07d6c: r0 = BorderSide()
    //     0xa07d6c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa07d70: mov             x1, x0
    // 0xa07d74: ldur            x0, [fp, #-0x28]
    // 0xa07d78: StoreField: r1->field_7 = r0
    //     0xa07d78: stur            w0, [x1, #7]
    // 0xa07d7c: ldur            d0, [fp, #-0x40]
    // 0xa07d80: StoreField: r1->field_b = d0
    //     0xa07d80: stur            d0, [x1, #0xb]
    // 0xa07d84: ldur            x0, [fp, #-0x20]
    // 0xa07d88: StoreField: r1->field_13 = r0
    //     0xa07d88: stur            w0, [x1, #0x13]
    // 0xa07d8c: ldur            d0, [fp, #-0x38]
    // 0xa07d90: ArrayStore: r1[0] = d0  ; List_8
    //     0xa07d90: stur            d0, [x1, #0x17]
    // 0xa07d94: mov             x0, x1
    // 0xa07d98: LeaveFrame
    //     0xa07d98: mov             SP, fp
    //     0xa07d9c: ldp             fp, lr, [SP], #0x10
    // 0xa07da0: ret
    //     0xa07da0: ret             
    // 0xa07da4: LoadField: r1 = r0->field_7
    //     0xa07da4: ldur            x1, [x0, #7]
    // 0xa07da8: cmp             x1, #0
    // 0xa07dac: b.gt            #0xa07ddc
    // 0xa07db0: LoadField: r1 = r4->field_7
    //     0xa07db0: ldur            w1, [x4, #7]
    // 0xa07db4: DecompressPointer r1
    //     0xa07db4: add             x1, x1, HEAP, lsl #32
    // 0xa07db8: r0 = LoadClassIdInstr(r1)
    //     0xa07db8: ldur            x0, [x1, #-1]
    //     0xa07dbc: ubfx            x0, x0, #0xc, #0x14
    // 0xa07dc0: r2 = 0
    //     0xa07dc0: mov             x2, #0
    // 0xa07dc4: r0 = GDT[cid_x0 + -0xff4]()
    //     0xa07dc4: sub             lr, x0, #0xff4
    //     0xa07dc8: ldr             lr, [x21, lr, lsl #3]
    //     0xa07dcc: blr             lr
    // 0xa07dd0: mov             x4, x0
    // 0xa07dd4: ldur            x3, [fp, #-0x10]
    // 0xa07dd8: b               #0xa07dec
    // 0xa07ddc: mov             x3, x4
    // 0xa07de0: LoadField: r0 = r3->field_7
    //     0xa07de0: ldur            w0, [x3, #7]
    // 0xa07de4: DecompressPointer r0
    //     0xa07de4: add             x0, x0, HEAP, lsl #32
    // 0xa07de8: mov             x4, x0
    // 0xa07dec: ldur            x0, [fp, #-0x30]
    // 0xa07df0: stur            x4, [fp, #-0x20]
    // 0xa07df4: LoadField: r1 = r0->field_7
    //     0xa07df4: ldur            x1, [x0, #7]
    // 0xa07df8: cmp             x1, #0
    // 0xa07dfc: b.gt            #0xa07e30
    // 0xa07e00: ldur            x5, [fp, #-0x18]
    // 0xa07e04: LoadField: r1 = r5->field_7
    //     0xa07e04: ldur            w1, [x5, #7]
    // 0xa07e08: DecompressPointer r1
    //     0xa07e08: add             x1, x1, HEAP, lsl #32
    // 0xa07e0c: r0 = LoadClassIdInstr(r1)
    //     0xa07e0c: ldur            x0, [x1, #-1]
    //     0xa07e10: ubfx            x0, x0, #0xc, #0x14
    // 0xa07e14: r2 = 0
    //     0xa07e14: mov             x2, #0
    // 0xa07e18: r0 = GDT[cid_x0 + -0xff4]()
    //     0xa07e18: sub             lr, x0, #0xff4
    //     0xa07e1c: ldr             lr, [x21, lr, lsl #3]
    //     0xa07e20: blr             lr
    // 0xa07e24: mov             x2, x0
    // 0xa07e28: ldur            x0, [fp, #-0x18]
    // 0xa07e2c: b               #0xa07e40
    // 0xa07e30: ldur            x0, [fp, #-0x18]
    // 0xa07e34: LoadField: r1 = r0->field_7
    //     0xa07e34: ldur            w1, [x0, #7]
    // 0xa07e38: DecompressPointer r1
    //     0xa07e38: add             x1, x1, HEAP, lsl #32
    // 0xa07e3c: mov             x2, x1
    // 0xa07e40: ldur            x1, [fp, #-0x10]
    // 0xa07e44: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xa07e44: ldur            d0, [x1, #0x17]
    // 0xa07e48: stur            d0, [fp, #-0x48]
    // 0xa07e4c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xa07e4c: ldur            d1, [x0, #0x17]
    // 0xa07e50: stur            d1, [fp, #-0x38]
    // 0xa07e54: fcmp            d0, d1
    // 0xa07e58: b.eq            #0xa07f1c
    // 0xa07e5c: ldur            d2, [fp, #-0x40]
    // 0xa07e60: ldur            x1, [fp, #-0x20]
    // 0xa07e64: ldur            x3, [fp, #-8]
    // 0xa07e68: r0 = lerp()
    //     0xa07e68: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xa07e6c: ldur            d0, [fp, #-0x48]
    // 0xa07e70: stur            x0, [fp, #-0x10]
    // 0xa07e74: r1 = inline_Allocate_Double()
    //     0xa07e74: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa07e78: add             x1, x1, #0x10
    //     0xa07e7c: cmp             x2, x1
    //     0xa07e80: b.ls            #0xa07fe8
    //     0xa07e84: str             x1, [THR, #0x60]  ; THR::top
    //     0xa07e88: sub             x1, x1, #0xf
    //     0xa07e8c: mov             x2, #0xe19c
    //     0xa07e90: movk            x2, #3, lsl #16
    //     0xa07e94: stur            x2, [x1, #-1]
    // 0xa07e98: dmb             ishst
    // 0xa07e9c: StoreField: r1->field_7 = d0
    //     0xa07e9c: stur            d0, [x1, #7]
    // 0xa07ea0: ldur            d0, [fp, #-0x38]
    // 0xa07ea4: r2 = inline_Allocate_Double()
    //     0xa07ea4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa07ea8: add             x2, x2, #0x10
    //     0xa07eac: cmp             x3, x2
    //     0xa07eb0: b.ls            #0xa08004
    //     0xa07eb4: str             x2, [THR, #0x60]  ; THR::top
    //     0xa07eb8: sub             x2, x2, #0xf
    //     0xa07ebc: mov             x3, #0xe19c
    //     0xa07ec0: movk            x3, #3, lsl #16
    //     0xa07ec4: stur            x3, [x2, #-1]
    // 0xa07ec8: dmb             ishst
    // 0xa07ecc: StoreField: r2->field_7 = d0
    //     0xa07ecc: stur            d0, [x2, #7]
    // 0xa07ed0: ldur            x3, [fp, #-8]
    // 0xa07ed4: r0 = lerpDouble()
    //     0xa07ed4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xa07ed8: stur            x0, [fp, #-0x18]
    // 0xa07edc: r0 = BorderSide()
    //     0xa07edc: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa07ee0: mov             x1, x0
    // 0xa07ee4: ldur            x0, [fp, #-0x10]
    // 0xa07ee8: StoreField: r1->field_7 = r0
    //     0xa07ee8: stur            w0, [x1, #7]
    // 0xa07eec: ldur            d1, [fp, #-0x40]
    // 0xa07ef0: StoreField: r1->field_b = d1
    //     0xa07ef0: stur            d1, [x1, #0xb]
    // 0xa07ef4: r0 = Instance_BorderStyle
    //     0xa07ef4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xa07ef8: ldr             x0, [x0, #0xdc8]
    // 0xa07efc: StoreField: r1->field_13 = r0
    //     0xa07efc: stur            w0, [x1, #0x13]
    // 0xa07f00: ldur            x0, [fp, #-0x18]
    // 0xa07f04: LoadField: d0 = r0->field_7
    //     0xa07f04: ldur            d0, [x0, #7]
    // 0xa07f08: ArrayStore: r1[0] = d0  ; List_8
    //     0xa07f08: stur            d0, [x1, #0x17]
    // 0xa07f0c: mov             x0, x1
    // 0xa07f10: LeaveFrame
    //     0xa07f10: mov             SP, fp
    //     0xa07f14: ldp             fp, lr, [SP], #0x10
    // 0xa07f18: ret
    //     0xa07f18: ret             
    // 0xa07f1c: ldur            d1, [fp, #-0x40]
    // 0xa07f20: r0 = Instance_BorderStyle
    //     0xa07f20: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xa07f24: ldr             x0, [x0, #0xdc8]
    // 0xa07f28: ldur            x1, [fp, #-0x20]
    // 0xa07f2c: ldur            x3, [fp, #-8]
    // 0xa07f30: r0 = lerp()
    //     0xa07f30: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xa07f34: stur            x0, [fp, #-8]
    // 0xa07f38: r0 = BorderSide()
    //     0xa07f38: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa07f3c: ldur            x1, [fp, #-8]
    // 0xa07f40: StoreField: r0->field_7 = r1
    //     0xa07f40: stur            w1, [x0, #7]
    // 0xa07f44: ldur            d0, [fp, #-0x40]
    // 0xa07f48: StoreField: r0->field_b = d0
    //     0xa07f48: stur            d0, [x0, #0xb]
    // 0xa07f4c: r1 = Instance_BorderStyle
    //     0xa07f4c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xa07f50: ldr             x1, [x1, #0xdc8]
    // 0xa07f54: StoreField: r0->field_13 = r1
    //     0xa07f54: stur            w1, [x0, #0x13]
    // 0xa07f58: ldur            d0, [fp, #-0x48]
    // 0xa07f5c: ArrayStore: r0[0] = d0  ; List_8
    //     0xa07f5c: stur            d0, [x0, #0x17]
    // 0xa07f60: LeaveFrame
    //     0xa07f60: mov             SP, fp
    //     0xa07f64: ldp             fp, lr, [SP], #0x10
    // 0xa07f68: ret
    //     0xa07f68: ret             
    // 0xa07f6c: r0 = StackOverflowSharedWithFPURegs()
    //     0xa07f6c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xa07f70: b               #0xa07c08
    // 0xa07f74: stp             q2, q3, [SP, #-0x20]!
    // 0xa07f78: stp             q0, q1, [SP, #-0x20]!
    // 0xa07f7c: stp             x0, x4, [SP, #-0x10]!
    // 0xa07f80: r0 = AllocateDouble()
    //     0xa07f80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xa07f84: mov             x5, x0
    // 0xa07f88: ldp             x0, x4, [SP], #0x10
    // 0xa07f8c: ldp             q0, q1, [SP], #0x20
    // 0xa07f90: ldp             q2, q3, [SP], #0x20
    // 0xa07f94: b               #0xa07c84
    // 0xa07f98: stp             q2, q3, [SP, #-0x20]!
    // 0xa07f9c: SaveReg d1
    //     0xa07f9c: str             q1, [SP, #-0x10]!
    // 0xa07fa0: stp             x4, x5, [SP, #-0x10]!
    // 0xa07fa4: SaveReg r0
    //     0xa07fa4: str             x0, [SP, #-8]!
    // 0xa07fa8: r0 = AllocateDouble()
    //     0xa07fa8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xa07fac: mov             x1, x0
    // 0xa07fb0: RestoreReg r0
    //     0xa07fb0: ldr             x0, [SP], #8
    // 0xa07fb4: ldp             x4, x5, [SP], #0x10
    // 0xa07fb8: RestoreReg d1
    //     0xa07fb8: ldr             q1, [SP], #0x10
    // 0xa07fbc: ldp             q2, q3, [SP], #0x20
    // 0xa07fc0: b               #0xa07cb4
    // 0xa07fc4: stp             q1, q3, [SP, #-0x20]!
    // 0xa07fc8: stp             x4, x5, [SP, #-0x10]!
    // 0xa07fcc: stp             x0, x1, [SP, #-0x10]!
    // 0xa07fd0: r0 = AllocateDouble()
    //     0xa07fd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xa07fd4: mov             x2, x0
    // 0xa07fd8: ldp             x0, x1, [SP], #0x10
    // 0xa07fdc: ldp             x4, x5, [SP], #0x10
    // 0xa07fe0: ldp             q1, q3, [SP], #0x20
    // 0xa07fe4: b               #0xa07ce0
    // 0xa07fe8: SaveReg d0
    //     0xa07fe8: str             q0, [SP, #-0x10]!
    // 0xa07fec: SaveReg r0
    //     0xa07fec: str             x0, [SP, #-8]!
    // 0xa07ff0: r0 = AllocateDouble()
    //     0xa07ff0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xa07ff4: mov             x1, x0
    // 0xa07ff8: RestoreReg r0
    //     0xa07ff8: ldr             x0, [SP], #8
    // 0xa07ffc: RestoreReg d0
    //     0xa07ffc: ldr             q0, [SP], #0x10
    // 0xa08000: b               #0xa07e9c
    // 0xa08004: SaveReg d0
    //     0xa08004: str             q0, [SP, #-0x10]!
    // 0xa08008: stp             x0, x1, [SP, #-0x10]!
    // 0xa0800c: r0 = AllocateDouble()
    //     0xa0800c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xa08010: mov             x2, x0
    // 0xa08014: ldp             x0, x1, [SP], #0x10
    // 0xa08018: RestoreReg d0
    //     0xa08018: ldr             q0, [SP], #0x10
    // 0xa0801c: b               #0xa07ecc
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xdf1d5c, size: 0x1e4
    // 0xdf1d5c: EnterFrame
    //     0xdf1d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf1d60: mov             fp, SP
    // 0xdf1d64: AllocStack(0x20)
    //     0xdf1d64: sub             SP, SP, #0x20
    // 0xdf1d68: SetupParameters({dynamic color = Null /* r3 */, dynamic strokeAlign = Null /* r5 */, dynamic style = Null /* r6 */, dynamic width = Null /* r0 */})
    //     0xdf1d68: ldur            w0, [x4, #0x13]
    //     0xdf1d6c: ldur            w2, [x4, #0x1f]
    //     0xdf1d70: add             x2, x2, HEAP, lsl #32
    //     0xdf1d74: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0xdf1d78: cmp             w2, w16
    //     0xdf1d7c: b.ne            #0xdf1da0
    //     0xdf1d80: ldur            w2, [x4, #0x23]
    //     0xdf1d84: add             x2, x2, HEAP, lsl #32
    //     0xdf1d88: sub             w3, w0, w2
    //     0xdf1d8c: add             x2, fp, w3, sxtw #2
    //     0xdf1d90: ldr             x2, [x2, #8]
    //     0xdf1d94: mov             x3, x2
    //     0xdf1d98: mov             x2, #1
    //     0xdf1d9c: b               #0xdf1da8
    //     0xdf1da0: mov             x3, NULL
    //     0xdf1da4: mov             x2, #0
    //     0xdf1da8: lsl             x5, x2, #1
    //     0xdf1dac: lsl             w6, w5, #1
    //     0xdf1db0: add             w7, w6, #8
    //     0xdf1db4: add             x16, x4, w7, sxtw #1
    //     0xdf1db8: ldur            w8, [x16, #0xf]
    //     0xdf1dbc: add             x8, x8, HEAP, lsl #32
    //     0xdf1dc0: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0288] "strokeAlign"
    //     0xdf1dc4: ldr             x16, [x16, #0x288]
    //     0xdf1dc8: cmp             w8, w16
    //     0xdf1dcc: b.ne            #0xdf1e00
    //     0xdf1dd0: add             w2, w6, #0xa
    //     0xdf1dd4: add             x16, x4, w2, sxtw #1
    //     0xdf1dd8: ldur            w6, [x16, #0xf]
    //     0xdf1ddc: add             x6, x6, HEAP, lsl #32
    //     0xdf1de0: sub             w2, w0, w6
    //     0xdf1de4: add             x6, fp, w2, sxtw #2
    //     0xdf1de8: ldr             x6, [x6, #8]
    //     0xdf1dec: add             w2, w5, #2
    //     0xdf1df0: sbfx            x5, x2, #1, #0x1f
    //     0xdf1df4: mov             x2, x5
    //     0xdf1df8: mov             x5, x6
    //     0xdf1dfc: b               #0xdf1e04
    //     0xdf1e00: mov             x5, NULL
    //     0xdf1e04: lsl             x6, x2, #1
    //     0xdf1e08: lsl             w7, w6, #1
    //     0xdf1e0c: add             w8, w7, #8
    //     0xdf1e10: add             x16, x4, w8, sxtw #1
    //     0xdf1e14: ldur            w9, [x16, #0xf]
    //     0xdf1e18: add             x9, x9, HEAP, lsl #32
    //     0xdf1e1c: add             x16, PP, #8, lsl #12  ; [pp+0x8400] "style"
    //     0xdf1e20: ldr             x16, [x16, #0x400]
    //     0xdf1e24: cmp             w9, w16
    //     0xdf1e28: b.ne            #0xdf1e5c
    //     0xdf1e2c: add             w2, w7, #0xa
    //     0xdf1e30: add             x16, x4, w2, sxtw #1
    //     0xdf1e34: ldur            w7, [x16, #0xf]
    //     0xdf1e38: add             x7, x7, HEAP, lsl #32
    //     0xdf1e3c: sub             w2, w0, w7
    //     0xdf1e40: add             x7, fp, w2, sxtw #2
    //     0xdf1e44: ldr             x7, [x7, #8]
    //     0xdf1e48: add             w2, w6, #2
    //     0xdf1e4c: sbfx            x6, x2, #1, #0x1f
    //     0xdf1e50: mov             x2, x6
    //     0xdf1e54: mov             x6, x7
    //     0xdf1e58: b               #0xdf1e60
    //     0xdf1e5c: mov             x6, NULL
    //     0xdf1e60: lsl             x7, x2, #1
    //     0xdf1e64: lsl             w2, w7, #1
    //     0xdf1e68: add             w7, w2, #8
    //     0xdf1e6c: add             x16, x4, w7, sxtw #1
    //     0xdf1e70: ldur            w8, [x16, #0xf]
    //     0xdf1e74: add             x8, x8, HEAP, lsl #32
    //     0xdf1e78: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    //     0xdf1e7c: cmp             w8, w16
    //     0xdf1e80: b.ne            #0xdf1ea4
    //     0xdf1e84: add             w7, w2, #0xa
    //     0xdf1e88: add             x16, x4, w7, sxtw #1
    //     0xdf1e8c: ldur            w2, [x16, #0xf]
    //     0xdf1e90: add             x2, x2, HEAP, lsl #32
    //     0xdf1e94: sub             w4, w0, w2
    //     0xdf1e98: add             x0, fp, w4, sxtw #2
    //     0xdf1e9c: ldr             x0, [x0, #8]
    //     0xdf1ea0: b               #0xdf1ea8
    //     0xdf1ea4: mov             x0, NULL
    // 0xdf1ea8: cmp             w3, NULL
    // 0xdf1eac: b.ne            #0xdf1ebc
    // 0xdf1eb0: LoadField: r2 = r1->field_7
    //     0xdf1eb0: ldur            w2, [x1, #7]
    // 0xdf1eb4: DecompressPointer r2
    //     0xdf1eb4: add             x2, x2, HEAP, lsl #32
    // 0xdf1eb8: b               #0xdf1ec0
    // 0xdf1ebc: mov             x2, x3
    // 0xdf1ec0: stur            x2, [fp, #-0x10]
    // 0xdf1ec4: cmp             w0, NULL
    // 0xdf1ec8: b.ne            #0xdf1ed4
    // 0xdf1ecc: LoadField: d0 = r1->field_b
    //     0xdf1ecc: ldur            d0, [x1, #0xb]
    // 0xdf1ed0: b               #0xdf1ed8
    // 0xdf1ed4: LoadField: d0 = r0->field_7
    //     0xdf1ed4: ldur            d0, [x0, #7]
    // 0xdf1ed8: stur            d0, [fp, #-0x20]
    // 0xdf1edc: cmp             w6, NULL
    // 0xdf1ee0: b.ne            #0xdf1ef0
    // 0xdf1ee4: LoadField: r0 = r1->field_13
    //     0xdf1ee4: ldur            w0, [x1, #0x13]
    // 0xdf1ee8: DecompressPointer r0
    //     0xdf1ee8: add             x0, x0, HEAP, lsl #32
    // 0xdf1eec: b               #0xdf1ef4
    // 0xdf1ef0: mov             x0, x6
    // 0xdf1ef4: stur            x0, [fp, #-8]
    // 0xdf1ef8: cmp             w5, NULL
    // 0xdf1efc: b.ne            #0xdf1f08
    // 0xdf1f00: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xdf1f00: ldur            d1, [x1, #0x17]
    // 0xdf1f04: b               #0xdf1f0c
    // 0xdf1f08: LoadField: d1 = r5->field_7
    //     0xdf1f08: ldur            d1, [x5, #7]
    // 0xdf1f0c: stur            d1, [fp, #-0x18]
    // 0xdf1f10: r0 = BorderSide()
    //     0xdf1f10: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdf1f14: ldur            x1, [fp, #-0x10]
    // 0xdf1f18: StoreField: r0->field_7 = r1
    //     0xdf1f18: stur            w1, [x0, #7]
    // 0xdf1f1c: ldur            d0, [fp, #-0x20]
    // 0xdf1f20: StoreField: r0->field_b = d0
    //     0xdf1f20: stur            d0, [x0, #0xb]
    // 0xdf1f24: ldur            x1, [fp, #-8]
    // 0xdf1f28: StoreField: r0->field_13 = r1
    //     0xdf1f28: stur            w1, [x0, #0x13]
    // 0xdf1f2c: ldur            d0, [fp, #-0x18]
    // 0xdf1f30: ArrayStore: r0[0] = d0  ; List_8
    //     0xdf1f30: stur            d0, [x0, #0x17]
    // 0xdf1f34: LeaveFrame
    //     0xdf1f34: mov             SP, fp
    //     0xdf1f38: ldp             fp, lr, [SP], #0x10
    // 0xdf1f3c: ret
    //     0xdf1f3c: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113b284, size: 0x104
    // 0x113b284: EnterFrame
    //     0x113b284: stp             fp, lr, [SP, #-0x10]!
    //     0x113b288: mov             fp, SP
    // 0x113b28c: AllocStack(0x10)
    //     0x113b28c: sub             SP, SP, #0x10
    // 0x113b290: CheckStackOverflow
    //     0x113b290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b294: cmp             SP, x16
    //     0x113b298: b.ls            #0x113b344
    // 0x113b29c: ldr             x0, [fp, #0x10]
    // 0x113b2a0: LoadField: r1 = r0->field_7
    //     0x113b2a0: ldur            w1, [x0, #7]
    // 0x113b2a4: DecompressPointer r1
    //     0x113b2a4: add             x1, x1, HEAP, lsl #32
    // 0x113b2a8: LoadField: d0 = r0->field_b
    //     0x113b2a8: ldur            d0, [x0, #0xb]
    // 0x113b2ac: LoadField: r2 = r0->field_13
    //     0x113b2ac: ldur            w2, [x0, #0x13]
    // 0x113b2b0: DecompressPointer r2
    //     0x113b2b0: add             x2, x2, HEAP, lsl #32
    // 0x113b2b4: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x113b2b4: ldur            d1, [x0, #0x17]
    // 0x113b2b8: r0 = inline_Allocate_Double()
    //     0x113b2b8: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x113b2bc: add             x0, x0, #0x10
    //     0x113b2c0: cmp             x3, x0
    //     0x113b2c4: b.ls            #0x113b34c
    //     0x113b2c8: str             x0, [THR, #0x60]  ; THR::top
    //     0x113b2cc: sub             x0, x0, #0xf
    //     0x113b2d0: mov             x3, #0xe19c
    //     0x113b2d4: movk            x3, #3, lsl #16
    //     0x113b2d8: stur            x3, [x0, #-1]
    // 0x113b2dc: dmb             ishst
    // 0x113b2e0: StoreField: r0->field_7 = d0
    //     0x113b2e0: stur            d0, [x0, #7]
    // 0x113b2e4: r3 = inline_Allocate_Double()
    //     0x113b2e4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x113b2e8: add             x3, x3, #0x10
    //     0x113b2ec: cmp             x4, x3
    //     0x113b2f0: b.ls            #0x113b364
    //     0x113b2f4: str             x3, [THR, #0x60]  ; THR::top
    //     0x113b2f8: sub             x3, x3, #0xf
    //     0x113b2fc: mov             x4, #0xe19c
    //     0x113b300: movk            x4, #3, lsl #16
    //     0x113b304: stur            x4, [x3, #-1]
    // 0x113b308: dmb             ishst
    // 0x113b30c: StoreField: r3->field_7 = d1
    //     0x113b30c: stur            d1, [x3, #7]
    // 0x113b310: stp             x3, x2, [SP]
    // 0x113b314: mov             x2, x0
    // 0x113b318: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x113b318: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x113b31c: r0 = hash()
    //     0x113b31c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b320: mov             x2, x0
    // 0x113b324: r0 = BoxInt64Instr(r2)
    //     0x113b324: sbfiz           x0, x2, #1, #0x1f
    //     0x113b328: cmp             x2, x0, asr #1
    //     0x113b32c: b.eq            #0x113b338
    //     0x113b330: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b334: stur            x2, [x0, #7]
    // 0x113b338: LeaveFrame
    //     0x113b338: mov             SP, fp
    //     0x113b33c: ldp             fp, lr, [SP], #0x10
    // 0x113b340: ret
    //     0x113b340: ret             
    // 0x113b344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b344: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b348: b               #0x113b29c
    // 0x113b34c: stp             q0, q1, [SP, #-0x20]!
    // 0x113b350: stp             x1, x2, [SP, #-0x10]!
    // 0x113b354: r0 = AllocateDouble()
    //     0x113b354: bl              #0x13df878  ; AllocateDoubleStub
    // 0x113b358: ldp             x1, x2, [SP], #0x10
    // 0x113b35c: ldp             q0, q1, [SP], #0x20
    // 0x113b360: b               #0x113b2e0
    // 0x113b364: SaveReg d1
    //     0x113b364: str             q1, [SP, #-0x10]!
    // 0x113b368: stp             x1, x2, [SP, #-0x10]!
    // 0x113b36c: SaveReg r0
    //     0x113b36c: str             x0, [SP, #-8]!
    // 0x113b370: r0 = AllocateDouble()
    //     0x113b370: bl              #0x13df878  ; AllocateDoubleStub
    // 0x113b374: mov             x3, x0
    // 0x113b378: RestoreReg r0
    //     0x113b378: ldr             x0, [SP], #8
    // 0x113b37c: ldp             x1, x2, [SP], #0x10
    // 0x113b380: RestoreReg d1
    //     0x113b380: ldr             q1, [SP], #0x10
    // 0x113b384: b               #0x113b30c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1278854, size: 0x12c
    // 0x1278854: EnterFrame
    //     0x1278854: stp             fp, lr, [SP, #-0x10]!
    //     0x1278858: mov             fp, SP
    // 0x127885c: AllocStack(0x10)
    //     0x127885c: sub             SP, SP, #0x10
    // 0x1278860: CheckStackOverflow
    //     0x1278860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1278864: cmp             SP, x16
    //     0x1278868: b.ls            #0x1278978
    // 0x127886c: ldr             x0, [fp, #0x10]
    // 0x1278870: cmp             w0, NULL
    // 0x1278874: b.ne            #0x1278888
    // 0x1278878: r0 = false
    //     0x1278878: add             x0, NULL, #0x30  ; false
    // 0x127887c: LeaveFrame
    //     0x127887c: mov             SP, fp
    //     0x1278880: ldp             fp, lr, [SP], #0x10
    // 0x1278884: ret
    //     0x1278884: ret             
    // 0x1278888: ldr             x1, [fp, #0x18]
    // 0x127888c: cmp             w1, w0
    // 0x1278890: b.ne            #0x12788a4
    // 0x1278894: r0 = true
    //     0x1278894: add             x0, NULL, #0x20  ; true
    // 0x1278898: LeaveFrame
    //     0x1278898: mov             SP, fp
    //     0x127889c: ldp             fp, lr, [SP], #0x10
    // 0x12788a0: ret
    //     0x12788a0: ret             
    // 0x12788a4: stp             x1, x0, [SP]
    // 0x12788a8: r0 = _haveSameRuntimeType()
    //     0x12788a8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12788ac: tbz             w0, #4, #0x12788c0
    // 0x12788b0: r0 = false
    //     0x12788b0: add             x0, NULL, #0x30  ; false
    // 0x12788b4: LeaveFrame
    //     0x12788b4: mov             SP, fp
    //     0x12788b8: ldp             fp, lr, [SP], #0x10
    // 0x12788bc: ret
    //     0x12788bc: ret             
    // 0x12788c0: ldr             x1, [fp, #0x10]
    // 0x12788c4: r0 = 60
    //     0x12788c4: mov             x0, #0x3c
    // 0x12788c8: branchIfSmi(r1, 0x12788d4)
    //     0x12788c8: tbz             w1, #0, #0x12788d4
    // 0x12788cc: r0 = LoadClassIdInstr(r1)
    //     0x12788cc: ldur            x0, [x1, #-1]
    //     0x12788d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12788d4: r17 = -5046
    //     0x12788d4: mov             x17, #-0x13b6
    // 0x12788d8: add             x16, x0, x17
    // 0x12788dc: cmp             x16, #2
    // 0x12788e0: b.hi            #0x1278968
    // 0x12788e4: ldr             x2, [fp, #0x18]
    // 0x12788e8: LoadField: r0 = r1->field_7
    //     0x12788e8: ldur            w0, [x1, #7]
    // 0x12788ec: DecompressPointer r0
    //     0x12788ec: add             x0, x0, HEAP, lsl #32
    // 0x12788f0: LoadField: r3 = r2->field_7
    //     0x12788f0: ldur            w3, [x2, #7]
    // 0x12788f4: DecompressPointer r3
    //     0x12788f4: add             x3, x3, HEAP, lsl #32
    // 0x12788f8: r4 = LoadClassIdInstr(r0)
    //     0x12788f8: ldur            x4, [x0, #-1]
    //     0x12788fc: ubfx            x4, x4, #0xc, #0x14
    // 0x1278900: stp             x3, x0, [SP]
    // 0x1278904: mov             x0, x4
    // 0x1278908: mov             lr, x0
    // 0x127890c: ldr             lr, [x21, lr, lsl #3]
    // 0x1278910: blr             lr
    // 0x1278914: tbnz            w0, #4, #0x1278968
    // 0x1278918: ldr             x2, [fp, #0x18]
    // 0x127891c: ldr             x1, [fp, #0x10]
    // 0x1278920: LoadField: d0 = r1->field_b
    //     0x1278920: ldur            d0, [x1, #0xb]
    // 0x1278924: LoadField: d1 = r2->field_b
    //     0x1278924: ldur            d1, [x2, #0xb]
    // 0x1278928: fcmp            d0, d1
    // 0x127892c: b.ne            #0x1278968
    // 0x1278930: LoadField: r3 = r1->field_13
    //     0x1278930: ldur            w3, [x1, #0x13]
    // 0x1278934: DecompressPointer r3
    //     0x1278934: add             x3, x3, HEAP, lsl #32
    // 0x1278938: LoadField: r4 = r2->field_13
    //     0x1278938: ldur            w4, [x2, #0x13]
    // 0x127893c: DecompressPointer r4
    //     0x127893c: add             x4, x4, HEAP, lsl #32
    // 0x1278940: cmp             w3, w4
    // 0x1278944: b.ne            #0x1278968
    // 0x1278948: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1278948: ldur            d0, [x1, #0x17]
    // 0x127894c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x127894c: ldur            d1, [x2, #0x17]
    // 0x1278950: fcmp            d0, d1
    // 0x1278954: r16 = true
    //     0x1278954: add             x16, NULL, #0x20  ; true
    // 0x1278958: r17 = false
    //     0x1278958: add             x17, NULL, #0x30  ; false
    // 0x127895c: csel            x1, x16, x17, eq
    // 0x1278960: mov             x0, x1
    // 0x1278964: b               #0x127896c
    // 0x1278968: r0 = false
    //     0x1278968: add             x0, NULL, #0x30  ; false
    // 0x127896c: LeaveFrame
    //     0x127896c: mov             SP, fp
    //     0x1278970: ldp             fp, lr, [SP], #0x10
    // 0x1278974: ret
    //     0x1278974: ret             
    // 0x1278978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1278978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127897c: b               #0x127886c
  }
  _ toPaint(/* No info */) {
    // ** addr: 0x12ed2c0, size: 0x114
    // 0x12ed2c0: EnterFrame
    //     0x12ed2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed2c4: mov             fp, SP
    // 0x12ed2c8: AllocStack(0x28)
    //     0x12ed2c8: sub             SP, SP, #0x28
    // 0x12ed2cc: SetupParameters(BorderSide this /* r1 => r1, fp-0x18 */)
    //     0x12ed2cc: stur            x1, [fp, #-0x18]
    // 0x12ed2d0: CheckStackOverflow
    //     0x12ed2d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed2d4: cmp             SP, x16
    //     0x12ed2d8: b.ls            #0x12ed3cc
    // 0x12ed2dc: LoadField: r0 = r1->field_13
    //     0x12ed2dc: ldur            w0, [x1, #0x13]
    // 0x12ed2e0: DecompressPointer r0
    //     0x12ed2e0: add             x0, x0, HEAP, lsl #32
    // 0x12ed2e4: LoadField: r2 = r0->field_7
    //     0x12ed2e4: ldur            x2, [x0, #7]
    // 0x12ed2e8: cmp             x2, #0
    // 0x12ed2ec: b.gt            #0x12ed354
    // 0x12ed2f0: r16 = 136
    //     0x12ed2f0: mov             x16, #0x88
    // 0x12ed2f4: stp             x16, NULL, [SP]
    // 0x12ed2f8: r0 = ByteData()
    //     0x12ed2f8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ed2fc: stur            x0, [fp, #-8]
    // 0x12ed300: r0 = Paint()
    //     0x12ed300: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ed304: mov             x3, x0
    // 0x12ed308: ldur            x0, [fp, #-8]
    // 0x12ed30c: stur            x3, [fp, #-0x10]
    // 0x12ed310: StoreField: r3->field_7 = r0
    //     0x12ed310: stur            w0, [x3, #7]
    // 0x12ed314: mov             x1, x3
    // 0x12ed318: r2 = Instance_Color
    //     0x12ed318: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12ed31c: ldr             x2, [x2, #0x810]
    // 0x12ed320: r0 = color=()
    //     0x12ed320: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ed324: ldur            x0, [fp, #-8]
    // 0x12ed328: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12ed328: ldur            w1, [x0, #0x17]
    // 0x12ed32c: DecompressPointer r1
    //     0x12ed32c: add             x1, x1, HEAP, lsl #32
    // 0x12ed330: LoadField: r0 = r1->field_7
    //     0x12ed330: ldur            x0, [x1, #7]
    // 0x12ed334: str             wzr, [x0, #0x20]
    // 0x12ed338: LoadField: r0 = r1->field_7
    //     0x12ed338: ldur            x0, [x1, #7]
    // 0x12ed33c: r2 = 1
    //     0x12ed33c: mov             x2, #1
    // 0x12ed340: str             w2, [x0, #0x1c]
    // 0x12ed344: ldur            x0, [fp, #-0x10]
    // 0x12ed348: LeaveFrame
    //     0x12ed348: mov             SP, fp
    //     0x12ed34c: ldp             fp, lr, [SP], #0x10
    // 0x12ed350: ret
    //     0x12ed350: ret             
    // 0x12ed354: r2 = 1
    //     0x12ed354: mov             x2, #1
    // 0x12ed358: r16 = 136
    //     0x12ed358: mov             x16, #0x88
    // 0x12ed35c: stp             x16, NULL, [SP]
    // 0x12ed360: r0 = ByteData()
    //     0x12ed360: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ed364: stur            x0, [fp, #-8]
    // 0x12ed368: r0 = Paint()
    //     0x12ed368: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ed36c: mov             x3, x0
    // 0x12ed370: ldur            x0, [fp, #-8]
    // 0x12ed374: stur            x3, [fp, #-0x10]
    // 0x12ed378: StoreField: r3->field_7 = r0
    //     0x12ed378: stur            w0, [x3, #7]
    // 0x12ed37c: ldur            x4, [fp, #-0x18]
    // 0x12ed380: LoadField: r2 = r4->field_7
    //     0x12ed380: ldur            w2, [x4, #7]
    // 0x12ed384: DecompressPointer r2
    //     0x12ed384: add             x2, x2, HEAP, lsl #32
    // 0x12ed388: mov             x1, x3
    // 0x12ed38c: r0 = color=()
    //     0x12ed38c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ed390: ldur            x1, [fp, #-0x18]
    // 0x12ed394: LoadField: d0 = r1->field_b
    //     0x12ed394: ldur            d0, [x1, #0xb]
    // 0x12ed398: ldur            x1, [fp, #-8]
    // 0x12ed39c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x12ed39c: ldur            w2, [x1, #0x17]
    // 0x12ed3a0: DecompressPointer r2
    //     0x12ed3a0: add             x2, x2, HEAP, lsl #32
    // 0x12ed3a4: fcvt            s1, d0
    // 0x12ed3a8: LoadField: r1 = r2->field_7
    //     0x12ed3a8: ldur            x1, [x2, #7]
    // 0x12ed3ac: str             s1, [x1, #0x20]
    // 0x12ed3b0: LoadField: r1 = r2->field_7
    //     0x12ed3b0: ldur            x1, [x2, #7]
    // 0x12ed3b4: r2 = 1
    //     0x12ed3b4: mov             x2, #1
    // 0x12ed3b8: str             w2, [x1, #0x1c]
    // 0x12ed3bc: ldur            x0, [fp, #-0x10]
    // 0x12ed3c0: LeaveFrame
    //     0x12ed3c0: mov             SP, fp
    //     0x12ed3c4: ldp             fp, lr, [SP], #0x10
    // 0x12ed3c8: ret
    //     0x12ed3c8: ret             
    // 0x12ed3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ed3cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ed3d0: b               #0x12ed2dc
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fc608, size: 0x80
    // 0x12fc608: EnterFrame
    //     0x12fc608: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc60c: mov             fp, SP
    // 0x12fc610: AllocStack(0x18)
    //     0x12fc610: sub             SP, SP, #0x18
    // 0x12fc614: d1 = 0.000000
    //     0x12fc614: eor             v1.16b, v1.16b, v1.16b
    // 0x12fc618: LoadField: r0 = r1->field_7
    //     0x12fc618: ldur            w0, [x1, #7]
    // 0x12fc61c: DecompressPointer r0
    //     0x12fc61c: add             x0, x0, HEAP, lsl #32
    // 0x12fc620: stur            x0, [fp, #-0x10]
    // 0x12fc624: LoadField: d2 = r1->field_b
    //     0x12fc624: ldur            d2, [x1, #0xb]
    // 0x12fc628: fmul            d3, d2, d0
    // 0x12fc62c: fmax            v2.2d, v1.2d, v3.2d
    // 0x12fc630: stur            d2, [fp, #-0x18]
    // 0x12fc634: fcmp            d1, d0
    // 0x12fc638: b.lt            #0x12fc648
    // 0x12fc63c: r1 = Instance_BorderStyle
    //     0x12fc63c: add             x1, PP, #0x89, lsl #12  ; [pp+0x89518] Obj!BorderStyle@12c4981
    //     0x12fc640: ldr             x1, [x1, #0x518]
    // 0x12fc644: b               #0x12fc654
    // 0x12fc648: LoadField: r2 = r1->field_13
    //     0x12fc648: ldur            w2, [x1, #0x13]
    // 0x12fc64c: DecompressPointer r2
    //     0x12fc64c: add             x2, x2, HEAP, lsl #32
    // 0x12fc650: mov             x1, x2
    // 0x12fc654: stur            x1, [fp, #-8]
    // 0x12fc658: r0 = BorderSide()
    //     0x12fc658: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x12fc65c: ldur            x1, [fp, #-0x10]
    // 0x12fc660: StoreField: r0->field_7 = r1
    //     0x12fc660: stur            w1, [x0, #7]
    // 0x12fc664: ldur            d0, [fp, #-0x18]
    // 0x12fc668: StoreField: r0->field_b = d0
    //     0x12fc668: stur            d0, [x0, #0xb]
    // 0x12fc66c: ldur            x1, [fp, #-8]
    // 0x12fc670: StoreField: r0->field_13 = r1
    //     0x12fc670: stur            w1, [x0, #0x13]
    // 0x12fc674: d0 = -1.000000
    //     0x12fc674: fmov            d0, #-1.00000000
    // 0x12fc678: ArrayStore: r0[0] = d0  ; List_8
    //     0x12fc678: stur            d0, [x0, #0x17]
    // 0x12fc67c: LeaveFrame
    //     0x12fc67c: mov             SP, fp
    //     0x12fc680: ldp             fp, lr, [SP], #0x10
    // 0x12fc684: ret
    //     0x12fc684: ret             
  }
}

// class id: 8249, size: 0x14, field offset: 0x14
enum BorderStyle extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aad14, size: 0x64
    // 0x11aad14: EnterFrame
    //     0x11aad14: stp             fp, lr, [SP, #-0x10]!
    //     0x11aad18: mov             fp, SP
    // 0x11aad1c: AllocStack(0x10)
    //     0x11aad1c: sub             SP, SP, #0x10
    // 0x11aad20: SetupParameters(BorderStyle this /* r1 => r0, fp-0x8 */)
    //     0x11aad20: mov             x0, x1
    //     0x11aad24: stur            x1, [fp, #-8]
    // 0x11aad28: CheckStackOverflow
    //     0x11aad28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aad2c: cmp             SP, x16
    //     0x11aad30: b.ls            #0x11aad70
    // 0x11aad34: r1 = Null
    //     0x11aad34: mov             x1, NULL
    // 0x11aad38: r2 = 4
    //     0x11aad38: mov             x2, #4
    // 0x11aad3c: r0 = AllocateArray()
    //     0x11aad3c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aad40: r16 = "BorderStyle."
    //     0x11aad40: add             x16, PP, #0x26, lsl #12  ; [pp+0x26968] "BorderStyle."
    //     0x11aad44: ldr             x16, [x16, #0x968]
    // 0x11aad48: StoreField: r0->field_f = r16
    //     0x11aad48: stur            w16, [x0, #0xf]
    // 0x11aad4c: ldur            x1, [fp, #-8]
    // 0x11aad50: LoadField: r2 = r1->field_f
    //     0x11aad50: ldur            w2, [x1, #0xf]
    // 0x11aad54: DecompressPointer r2
    //     0x11aad54: add             x2, x2, HEAP, lsl #32
    // 0x11aad58: StoreField: r0->field_13 = r2
    //     0x11aad58: stur            w2, [x0, #0x13]
    // 0x11aad5c: str             x0, [SP]
    // 0x11aad60: r0 = _interpolate()
    //     0x11aad60: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aad64: LeaveFrame
    //     0x11aad64: mov             SP, fp
    //     0x11aad68: ldp             fp, lr, [SP], #0x10
    // 0x11aad6c: ret
    //     0x11aad6c: ret             
    // 0x11aad70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aad70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aad74: b               #0x11aad34
  }
}
