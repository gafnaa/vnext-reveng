// lib: , url: package:flutter/src/painting/alignment.dart

// class id: 1048978, size: 0x8
class :: {
}

// class id: 2954, size: 0x10, field offset: 0x8
//   const constructor, 
class TextAlignVertical extends Object {

  _Mint field_8;
}

// class id: 2955, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class AlignmentGeometry extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114b700, size: 0x1a8
    // 0x114b700: EnterFrame
    //     0x114b700: stp             fp, lr, [SP, #-0x10]!
    //     0x114b704: mov             fp, SP
    // 0x114b708: AllocStack(0x8)
    //     0x114b708: sub             SP, SP, #8
    // 0x114b70c: CheckStackOverflow
    //     0x114b70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114b710: cmp             SP, x16
    //     0x114b714: b.ls            #0x114b850
    // 0x114b718: ldr             x0, [fp, #0x10]
    // 0x114b71c: r1 = LoadClassIdInstr(r0)
    //     0x114b71c: ldur            x1, [x0, #-1]
    //     0x114b720: ubfx            x1, x1, #0xc, #0x14
    // 0x114b724: sub             x16, x1, #0xb8e
    // 0x114b728: cmp             x16, #1
    // 0x114b72c: b.hi            #0x114b738
    // 0x114b730: LoadField: d0 = r0->field_7
    //     0x114b730: ldur            d0, [x0, #7]
    // 0x114b734: b               #0x114b74c
    // 0x114b738: cmp             x1, #0xb8c
    // 0x114b73c: b.ne            #0x114b748
    // 0x114b740: LoadField: d0 = r0->field_7
    //     0x114b740: ldur            d0, [x0, #7]
    // 0x114b744: b               #0x114b74c
    // 0x114b748: d0 = 0.000000
    //     0x114b748: eor             v0.16b, v0.16b, v0.16b
    // 0x114b74c: sub             x16, x1, #0xb8e
    // 0x114b750: cmp             x16, #1
    // 0x114b754: b.hi            #0x114b760
    // 0x114b758: d1 = 0.000000
    //     0x114b758: eor             v1.16b, v1.16b, v1.16b
    // 0x114b75c: b               #0x114b774
    // 0x114b760: cmp             x1, #0xb8c
    // 0x114b764: b.ne            #0x114b770
    // 0x114b768: LoadField: d1 = r0->field_f
    //     0x114b768: ldur            d1, [x0, #0xf]
    // 0x114b76c: b               #0x114b774
    // 0x114b770: LoadField: d1 = r0->field_7
    //     0x114b770: ldur            d1, [x0, #7]
    // 0x114b774: sub             x16, x1, #0xb8e
    // 0x114b778: cmp             x16, #1
    // 0x114b77c: b.hi            #0x114b788
    // 0x114b780: LoadField: d2 = r0->field_f
    //     0x114b780: ldur            d2, [x0, #0xf]
    // 0x114b784: b               #0x114b79c
    // 0x114b788: cmp             x1, #0xb8c
    // 0x114b78c: b.ne            #0x114b798
    // 0x114b790: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x114b790: ldur            d2, [x0, #0x17]
    // 0x114b794: b               #0x114b79c
    // 0x114b798: LoadField: d2 = r0->field_f
    //     0x114b798: ldur            d2, [x0, #0xf]
    // 0x114b79c: r1 = inline_Allocate_Double()
    //     0x114b79c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x114b7a0: add             x1, x1, #0x10
    //     0x114b7a4: cmp             x0, x1
    //     0x114b7a8: b.ls            #0x114b858
    //     0x114b7ac: str             x1, [THR, #0x60]  ; THR::top
    //     0x114b7b0: sub             x1, x1, #0xf
    //     0x114b7b4: mov             x0, #0xe19c
    //     0x114b7b8: movk            x0, #3, lsl #16
    //     0x114b7bc: stur            x0, [x1, #-1]
    // 0x114b7c0: dmb             ishst
    // 0x114b7c4: StoreField: r1->field_7 = d0
    //     0x114b7c4: stur            d0, [x1, #7]
    // 0x114b7c8: r2 = inline_Allocate_Double()
    //     0x114b7c8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x114b7cc: add             x2, x2, #0x10
    //     0x114b7d0: cmp             x0, x2
    //     0x114b7d4: b.ls            #0x114b874
    //     0x114b7d8: str             x2, [THR, #0x60]  ; THR::top
    //     0x114b7dc: sub             x2, x2, #0xf
    //     0x114b7e0: mov             x0, #0xe19c
    //     0x114b7e4: movk            x0, #3, lsl #16
    //     0x114b7e8: stur            x0, [x2, #-1]
    // 0x114b7ec: dmb             ishst
    // 0x114b7f0: StoreField: r2->field_7 = d1
    //     0x114b7f0: stur            d1, [x2, #7]
    // 0x114b7f4: r0 = inline_Allocate_Double()
    //     0x114b7f4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114b7f8: add             x0, x0, #0x10
    //     0x114b7fc: cmp             x3, x0
    //     0x114b800: b.ls            #0x114b890
    //     0x114b804: str             x0, [THR, #0x60]  ; THR::top
    //     0x114b808: sub             x0, x0, #0xf
    //     0x114b80c: mov             x3, #0xe19c
    //     0x114b810: movk            x3, #3, lsl #16
    //     0x114b814: stur            x3, [x0, #-1]
    // 0x114b818: dmb             ishst
    // 0x114b81c: StoreField: r0->field_7 = d2
    //     0x114b81c: stur            d2, [x0, #7]
    // 0x114b820: str             x0, [SP]
    // 0x114b824: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114b824: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114b828: r0 = hash()
    //     0x114b828: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114b82c: mov             x2, x0
    // 0x114b830: r0 = BoxInt64Instr(r2)
    //     0x114b830: sbfiz           x0, x2, #1, #0x1f
    //     0x114b834: cmp             x2, x0, asr #1
    //     0x114b838: b.eq            #0x114b844
    //     0x114b83c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114b840: stur            x2, [x0, #7]
    // 0x114b844: LeaveFrame
    //     0x114b844: mov             SP, fp
    //     0x114b848: ldp             fp, lr, [SP], #0x10
    // 0x114b84c: ret
    //     0x114b84c: ret             
    // 0x114b850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114b850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114b854: b               #0x114b718
    // 0x114b858: stp             q1, q2, [SP, #-0x20]!
    // 0x114b85c: SaveReg d0
    //     0x114b85c: str             q0, [SP, #-0x10]!
    // 0x114b860: r0 = AllocateDouble()
    //     0x114b860: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114b864: mov             x1, x0
    // 0x114b868: RestoreReg d0
    //     0x114b868: ldr             q0, [SP], #0x10
    // 0x114b86c: ldp             q1, q2, [SP], #0x20
    // 0x114b870: b               #0x114b7c4
    // 0x114b874: stp             q1, q2, [SP, #-0x20]!
    // 0x114b878: SaveReg r1
    //     0x114b878: str             x1, [SP, #-8]!
    // 0x114b87c: r0 = AllocateDouble()
    //     0x114b87c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114b880: mov             x2, x0
    // 0x114b884: RestoreReg r1
    //     0x114b884: ldr             x1, [SP], #8
    // 0x114b888: ldp             q1, q2, [SP], #0x20
    // 0x114b88c: b               #0x114b7f0
    // 0x114b890: SaveReg d2
    //     0x114b890: str             q2, [SP, #-0x10]!
    // 0x114b894: stp             x1, x2, [SP, #-0x10]!
    // 0x114b898: r0 = AllocateDouble()
    //     0x114b898: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114b89c: ldp             x1, x2, [SP], #0x10
    // 0x114b8a0: RestoreReg d2
    //     0x114b8a0: ldr             q2, [SP], #0x10
    // 0x114b8a4: b               #0x114b81c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1160c48, size: 0x71c
    // 0x1160c48: EnterFrame
    //     0x1160c48: stp             fp, lr, [SP, #-0x10]!
    //     0x1160c4c: mov             fp, SP
    // 0x1160c50: AllocStack(0x50)
    //     0x1160c50: sub             SP, SP, #0x50
    // 0x1160c54: SetupParameters(dynamic _ /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x28 */)
    //     0x1160c54: mov             x4, x1
    //     0x1160c58: mov             x0, x2
    //     0x1160c5c: stur            x1, [fp, #-0x20]
    //     0x1160c60: stur            x2, [fp, #-0x28]
    // 0x1160c64: CheckStackOverflow
    //     0x1160c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1160c68: cmp             SP, x16
    //     0x1160c6c: b.ls            #0x116123c
    // 0x1160c70: cmp             w4, w0
    // 0x1160c74: b.ne            #0x1160c88
    // 0x1160c78: mov             x0, x4
    // 0x1160c7c: LeaveFrame
    //     0x1160c7c: mov             SP, fp
    //     0x1160c80: ldp             fp, lr, [SP], #0x10
    // 0x1160c84: ret
    //     0x1160c84: ret             
    // 0x1160c88: cmp             w4, NULL
    // 0x1160c8c: b.ne            #0x1160dbc
    // 0x1160c90: cmp             w0, NULL
    // 0x1160c94: b.eq            #0x1161244
    // 0x1160c98: r1 = LoadClassIdInstr(r0)
    //     0x1160c98: ldur            x1, [x0, #-1]
    //     0x1160c9c: ubfx            x1, x1, #0xc, #0x14
    // 0x1160ca0: cmp             x1, #0xb8c
    // 0x1160ca4: b.ne            #0x1160cec
    // 0x1160ca8: LoadField: d1 = r0->field_7
    //     0x1160ca8: ldur            d1, [x0, #7]
    // 0x1160cac: fmul            d2, d1, d0
    // 0x1160cb0: stur            d2, [fp, #-0x50]
    // 0x1160cb4: LoadField: d1 = r0->field_f
    //     0x1160cb4: ldur            d1, [x0, #0xf]
    // 0x1160cb8: fmul            d3, d1, d0
    // 0x1160cbc: stur            d3, [fp, #-0x48]
    // 0x1160cc0: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x1160cc0: ldur            d1, [x0, #0x17]
    // 0x1160cc4: fmul            d4, d1, d0
    // 0x1160cc8: stur            d4, [fp, #-0x40]
    // 0x1160ccc: r0 = _MixedAlignment()
    //     0x1160ccc: bl              #0x1161a60  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0x1160cd0: ldur            d0, [fp, #-0x50]
    // 0x1160cd4: StoreField: r0->field_7 = d0
    //     0x1160cd4: stur            d0, [x0, #7]
    // 0x1160cd8: ldur            d0, [fp, #-0x48]
    // 0x1160cdc: StoreField: r0->field_f = d0
    //     0x1160cdc: stur            d0, [x0, #0xf]
    // 0x1160ce0: ldur            d0, [fp, #-0x40]
    // 0x1160ce4: ArrayStore: r0[0] = d0  ; List_8
    //     0x1160ce4: stur            d0, [x0, #0x17]
    // 0x1160ce8: b               #0x1160db0
    // 0x1160cec: cmp             x1, #0xb8d
    // 0x1160cf0: b.ne            #0x1160d24
    // 0x1160cf4: LoadField: d1 = r0->field_7
    //     0x1160cf4: ldur            d1, [x0, #7]
    // 0x1160cf8: fmul            d2, d1, d0
    // 0x1160cfc: stur            d2, [fp, #-0x48]
    // 0x1160d00: LoadField: d1 = r0->field_f
    //     0x1160d00: ldur            d1, [x0, #0xf]
    // 0x1160d04: fmul            d3, d1, d0
    // 0x1160d08: stur            d3, [fp, #-0x40]
    // 0x1160d0c: r0 = AlignmentDirectional()
    //     0x1160d0c: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x1160d10: ldur            d0, [fp, #-0x48]
    // 0x1160d14: StoreField: r0->field_7 = d0
    //     0x1160d14: stur            d0, [x0, #7]
    // 0x1160d18: ldur            d0, [fp, #-0x40]
    // 0x1160d1c: StoreField: r0->field_f = d0
    //     0x1160d1c: stur            d0, [x0, #0xf]
    // 0x1160d20: b               #0x1160db0
    // 0x1160d24: cmp             x1, #0xb8e
    // 0x1160d28: b.ne            #0x1160d5c
    // 0x1160d2c: LoadField: d1 = r0->field_7
    //     0x1160d2c: ldur            d1, [x0, #7]
    // 0x1160d30: fmul            d2, d1, d0
    // 0x1160d34: stur            d2, [fp, #-0x48]
    // 0x1160d38: LoadField: d1 = r0->field_f
    //     0x1160d38: ldur            d1, [x0, #0xf]
    // 0x1160d3c: fmul            d3, d1, d0
    // 0x1160d40: stur            d3, [fp, #-0x40]
    // 0x1160d44: r0 = Alignment()
    //     0x1160d44: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1160d48: ldur            d0, [fp, #-0x48]
    // 0x1160d4c: StoreField: r0->field_7 = d0
    //     0x1160d4c: stur            d0, [x0, #7]
    // 0x1160d50: ldur            d0, [fp, #-0x40]
    // 0x1160d54: StoreField: r0->field_f = d0
    //     0x1160d54: stur            d0, [x0, #0xf]
    // 0x1160d58: b               #0x1160db0
    // 0x1160d5c: d2 = 1.000000
    //     0x1160d5c: fmov            d2, #1.00000000
    // 0x1160d60: d1 = 2.000000
    //     0x1160d60: fmov            d1, #2.00000000
    // 0x1160d64: LoadField: d3 = r0->field_7
    //     0x1160d64: ldur            d3, [x0, #7]
    // 0x1160d68: fadd            d4, d3, d2
    // 0x1160d6c: fdiv            d3, d4, d1
    // 0x1160d70: fmul            d4, d3, d0
    // 0x1160d74: LoadField: d3 = r0->field_f
    //     0x1160d74: ldur            d3, [x0, #0xf]
    // 0x1160d78: fadd            d5, d3, d2
    // 0x1160d7c: fdiv            d3, d5, d1
    // 0x1160d80: fmul            d5, d3, d0
    // 0x1160d84: fmul            d0, d4, d1
    // 0x1160d88: fsub            d3, d0, d2
    // 0x1160d8c: stur            d3, [fp, #-0x48]
    // 0x1160d90: fmul            d0, d5, d1
    // 0x1160d94: fsub            d1, d0, d2
    // 0x1160d98: stur            d1, [fp, #-0x40]
    // 0x1160d9c: r0 = FractionalOffset()
    //     0x1160d9c: bl              #0xddc0fc  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0x1160da0: ldur            d0, [fp, #-0x48]
    // 0x1160da4: StoreField: r0->field_7 = d0
    //     0x1160da4: stur            d0, [x0, #7]
    // 0x1160da8: ldur            d0, [fp, #-0x40]
    // 0x1160dac: StoreField: r0->field_f = d0
    //     0x1160dac: stur            d0, [x0, #0xf]
    // 0x1160db0: LeaveFrame
    //     0x1160db0: mov             SP, fp
    //     0x1160db4: ldp             fp, lr, [SP], #0x10
    // 0x1160db8: ret
    //     0x1160db8: ret             
    // 0x1160dbc: d2 = 1.000000
    //     0x1160dbc: fmov            d2, #1.00000000
    // 0x1160dc0: d1 = 2.000000
    //     0x1160dc0: fmov            d1, #2.00000000
    // 0x1160dc4: cmp             w0, NULL
    // 0x1160dc8: b.ne            #0x1160eec
    // 0x1160dcc: fsub            d3, d2, d0
    // 0x1160dd0: r0 = LoadClassIdInstr(r4)
    //     0x1160dd0: ldur            x0, [x4, #-1]
    //     0x1160dd4: ubfx            x0, x0, #0xc, #0x14
    // 0x1160dd8: cmp             x0, #0xb8c
    // 0x1160ddc: b.ne            #0x1160e24
    // 0x1160de0: LoadField: d0 = r4->field_7
    //     0x1160de0: ldur            d0, [x4, #7]
    // 0x1160de4: fmul            d1, d0, d3
    // 0x1160de8: stur            d1, [fp, #-0x50]
    // 0x1160dec: LoadField: d0 = r4->field_f
    //     0x1160dec: ldur            d0, [x4, #0xf]
    // 0x1160df0: fmul            d2, d0, d3
    // 0x1160df4: stur            d2, [fp, #-0x48]
    // 0x1160df8: ArrayLoad: d0 = r4[0]  ; List_8
    //     0x1160df8: ldur            d0, [x4, #0x17]
    // 0x1160dfc: fmul            d4, d0, d3
    // 0x1160e00: stur            d4, [fp, #-0x40]
    // 0x1160e04: r0 = _MixedAlignment()
    //     0x1160e04: bl              #0x1161a60  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0x1160e08: ldur            d0, [fp, #-0x50]
    // 0x1160e0c: StoreField: r0->field_7 = d0
    //     0x1160e0c: stur            d0, [x0, #7]
    // 0x1160e10: ldur            d0, [fp, #-0x48]
    // 0x1160e14: StoreField: r0->field_f = d0
    //     0x1160e14: stur            d0, [x0, #0xf]
    // 0x1160e18: ldur            d0, [fp, #-0x40]
    // 0x1160e1c: ArrayStore: r0[0] = d0  ; List_8
    //     0x1160e1c: stur            d0, [x0, #0x17]
    // 0x1160e20: b               #0x1160ee0
    // 0x1160e24: cmp             x0, #0xb8d
    // 0x1160e28: b.ne            #0x1160e5c
    // 0x1160e2c: LoadField: d0 = r4->field_7
    //     0x1160e2c: ldur            d0, [x4, #7]
    // 0x1160e30: fmul            d1, d0, d3
    // 0x1160e34: stur            d1, [fp, #-0x48]
    // 0x1160e38: LoadField: d0 = r4->field_f
    //     0x1160e38: ldur            d0, [x4, #0xf]
    // 0x1160e3c: fmul            d2, d0, d3
    // 0x1160e40: stur            d2, [fp, #-0x40]
    // 0x1160e44: r0 = AlignmentDirectional()
    //     0x1160e44: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x1160e48: ldur            d0, [fp, #-0x48]
    // 0x1160e4c: StoreField: r0->field_7 = d0
    //     0x1160e4c: stur            d0, [x0, #7]
    // 0x1160e50: ldur            d0, [fp, #-0x40]
    // 0x1160e54: StoreField: r0->field_f = d0
    //     0x1160e54: stur            d0, [x0, #0xf]
    // 0x1160e58: b               #0x1160ee0
    // 0x1160e5c: cmp             x0, #0xb8e
    // 0x1160e60: b.ne            #0x1160e94
    // 0x1160e64: LoadField: d0 = r4->field_7
    //     0x1160e64: ldur            d0, [x4, #7]
    // 0x1160e68: fmul            d1, d0, d3
    // 0x1160e6c: stur            d1, [fp, #-0x48]
    // 0x1160e70: LoadField: d0 = r4->field_f
    //     0x1160e70: ldur            d0, [x4, #0xf]
    // 0x1160e74: fmul            d2, d0, d3
    // 0x1160e78: stur            d2, [fp, #-0x40]
    // 0x1160e7c: r0 = Alignment()
    //     0x1160e7c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1160e80: ldur            d0, [fp, #-0x48]
    // 0x1160e84: StoreField: r0->field_7 = d0
    //     0x1160e84: stur            d0, [x0, #7]
    // 0x1160e88: ldur            d0, [fp, #-0x40]
    // 0x1160e8c: StoreField: r0->field_f = d0
    //     0x1160e8c: stur            d0, [x0, #0xf]
    // 0x1160e90: b               #0x1160ee0
    // 0x1160e94: LoadField: d0 = r4->field_7
    //     0x1160e94: ldur            d0, [x4, #7]
    // 0x1160e98: fadd            d4, d0, d2
    // 0x1160e9c: fdiv            d0, d4, d1
    // 0x1160ea0: fmul            d4, d0, d3
    // 0x1160ea4: LoadField: d0 = r4->field_f
    //     0x1160ea4: ldur            d0, [x4, #0xf]
    // 0x1160ea8: fadd            d5, d0, d2
    // 0x1160eac: fdiv            d0, d5, d1
    // 0x1160eb0: fmul            d5, d0, d3
    // 0x1160eb4: fmul            d0, d4, d1
    // 0x1160eb8: fsub            d3, d0, d2
    // 0x1160ebc: stur            d3, [fp, #-0x48]
    // 0x1160ec0: fmul            d0, d5, d1
    // 0x1160ec4: fsub            d1, d0, d2
    // 0x1160ec8: stur            d1, [fp, #-0x40]
    // 0x1160ecc: r0 = FractionalOffset()
    //     0x1160ecc: bl              #0xddc0fc  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0x1160ed0: ldur            d0, [fp, #-0x48]
    // 0x1160ed4: StoreField: r0->field_7 = d0
    //     0x1160ed4: stur            d0, [x0, #7]
    // 0x1160ed8: ldur            d0, [fp, #-0x40]
    // 0x1160edc: StoreField: r0->field_f = d0
    //     0x1160edc: stur            d0, [x0, #0xf]
    // 0x1160ee0: LeaveFrame
    //     0x1160ee0: mov             SP, fp
    //     0x1160ee4: ldp             fp, lr, [SP], #0x10
    // 0x1160ee8: ret
    //     0x1160ee8: ret             
    // 0x1160eec: r5 = LoadClassIdInstr(r4)
    //     0x1160eec: ldur            x5, [x4, #-1]
    //     0x1160ef0: ubfx            x5, x5, #0xc, #0x14
    // 0x1160ef4: stur            x5, [fp, #-0x18]
    // 0x1160ef8: sub             x16, x5, #0xb8e
    // 0x1160efc: cmp             x16, #1
    // 0x1160f00: b.hi            #0x1160f30
    // 0x1160f04: r1 = LoadClassIdInstr(r0)
    //     0x1160f04: ldur            x1, [x0, #-1]
    //     0x1160f08: ubfx            x1, x1, #0xc, #0x14
    // 0x1160f0c: sub             x16, x1, #0xb8e
    // 0x1160f10: cmp             x16, #1
    // 0x1160f14: b.hi            #0x1160f30
    // 0x1160f18: mov             x1, x4
    // 0x1160f1c: mov             x2, x0
    // 0x1160f20: r0 = lerp()
    //     0x1160f20: bl              #0x1161598  ; [package:flutter/src/painting/alignment.dart] Alignment::lerp
    // 0x1160f24: LeaveFrame
    //     0x1160f24: mov             SP, fp
    //     0x1160f28: ldp             fp, lr, [SP], #0x10
    // 0x1160f2c: ret
    //     0x1160f2c: ret             
    // 0x1160f30: cmp             x5, #0xb8d
    // 0x1160f34: b.ne            #0x1160f60
    // 0x1160f38: r1 = LoadClassIdInstr(r0)
    //     0x1160f38: ldur            x1, [x0, #-1]
    //     0x1160f3c: ubfx            x1, x1, #0xc, #0x14
    // 0x1160f40: cmp             x1, #0xb8d
    // 0x1160f44: b.ne            #0x1160f60
    // 0x1160f48: mov             x1, x4
    // 0x1160f4c: mov             x2, x0
    // 0x1160f50: r0 = lerp()
    //     0x1160f50: bl              #0x1161364  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::lerp
    // 0x1160f54: LeaveFrame
    //     0x1160f54: mov             SP, fp
    //     0x1160f58: ldp             fp, lr, [SP], #0x10
    // 0x1160f5c: ret
    //     0x1160f5c: ret             
    // 0x1160f60: sub             x16, x5, #0xb8e
    // 0x1160f64: cmp             x16, #1
    // 0x1160f68: b.hi            #0x1160f74
    // 0x1160f6c: LoadField: d1 = r4->field_7
    //     0x1160f6c: ldur            d1, [x4, #7]
    // 0x1160f70: b               #0x1160f88
    // 0x1160f74: cmp             x5, #0xb8c
    // 0x1160f78: b.ne            #0x1160f84
    // 0x1160f7c: LoadField: d1 = r4->field_7
    //     0x1160f7c: ldur            d1, [x4, #7]
    // 0x1160f80: b               #0x1160f88
    // 0x1160f84: d1 = 0.000000
    //     0x1160f84: eor             v1.16b, v1.16b, v1.16b
    // 0x1160f88: r6 = LoadClassIdInstr(r0)
    //     0x1160f88: ldur            x6, [x0, #-1]
    //     0x1160f8c: ubfx            x6, x6, #0xc, #0x14
    // 0x1160f90: stur            x6, [fp, #-0x10]
    // 0x1160f94: sub             x16, x6, #0xb8e
    // 0x1160f98: cmp             x16, #1
    // 0x1160f9c: b.hi            #0x1160fa8
    // 0x1160fa0: LoadField: d2 = r0->field_7
    //     0x1160fa0: ldur            d2, [x0, #7]
    // 0x1160fa4: b               #0x1160fbc
    // 0x1160fa8: cmp             x6, #0xb8c
    // 0x1160fac: b.ne            #0x1160fb8
    // 0x1160fb0: LoadField: d2 = r0->field_7
    //     0x1160fb0: ldur            d2, [x0, #7]
    // 0x1160fb4: b               #0x1160fbc
    // 0x1160fb8: d2 = 0.000000
    //     0x1160fb8: eor             v2.16b, v2.16b, v2.16b
    // 0x1160fbc: r7 = inline_Allocate_Double()
    //     0x1160fbc: ldp             x7, x1, [THR, #0x60]  ; THR::top
    //     0x1160fc0: add             x7, x7, #0x10
    //     0x1160fc4: cmp             x1, x7
    //     0x1160fc8: b.ls            #0x1161248
    //     0x1160fcc: str             x7, [THR, #0x60]  ; THR::top
    //     0x1160fd0: sub             x7, x7, #0xf
    //     0x1160fd4: mov             x1, #0xe19c
    //     0x1160fd8: movk            x1, #3, lsl #16
    //     0x1160fdc: stur            x1, [x7, #-1]
    // 0x1160fe0: dmb             ishst
    // 0x1160fe4: StoreField: r7->field_7 = d0
    //     0x1160fe4: stur            d0, [x7, #7]
    // 0x1160fe8: stur            x7, [fp, #-8]
    // 0x1160fec: r1 = inline_Allocate_Double()
    //     0x1160fec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1160ff0: add             x1, x1, #0x10
    //     0x1160ff4: cmp             x2, x1
    //     0x1160ff8: b.ls            #0x1161274
    //     0x1160ffc: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161000: sub             x1, x1, #0xf
    //     0x1161004: mov             x2, #0xe19c
    //     0x1161008: movk            x2, #3, lsl #16
    //     0x116100c: stur            x2, [x1, #-1]
    // 0x1161010: dmb             ishst
    // 0x1161014: StoreField: r1->field_7 = d1
    //     0x1161014: stur            d1, [x1, #7]
    // 0x1161018: r2 = inline_Allocate_Double()
    //     0x1161018: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x116101c: add             x2, x2, #0x10
    //     0x1161020: cmp             x3, x2
    //     0x1161024: b.ls            #0x11612a0
    //     0x1161028: str             x2, [THR, #0x60]  ; THR::top
    //     0x116102c: sub             x2, x2, #0xf
    //     0x1161030: mov             x3, #0xe19c
    //     0x1161034: movk            x3, #3, lsl #16
    //     0x1161038: stur            x3, [x2, #-1]
    // 0x116103c: dmb             ishst
    // 0x1161040: StoreField: r2->field_7 = d2
    //     0x1161040: stur            d2, [x2, #7]
    // 0x1161044: mov             x3, x7
    // 0x1161048: r0 = lerpDouble()
    //     0x1161048: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116104c: mov             x4, x0
    // 0x1161050: ldur            x0, [fp, #-0x18]
    // 0x1161054: stur            x4, [fp, #-0x30]
    // 0x1161058: sub             x16, x0, #0xb8e
    // 0x116105c: cmp             x16, #1
    // 0x1161060: b.hi            #0x1161070
    // 0x1161064: ldur            x5, [fp, #-0x20]
    // 0x1161068: d0 = 0.000000
    //     0x1161068: eor             v0.16b, v0.16b, v0.16b
    // 0x116106c: b               #0x116108c
    // 0x1161070: cmp             x0, #0xb8c
    // 0x1161074: b.ne            #0x1161084
    // 0x1161078: ldur            x5, [fp, #-0x20]
    // 0x116107c: LoadField: d0 = r5->field_f
    //     0x116107c: ldur            d0, [x5, #0xf]
    // 0x1161080: b               #0x116108c
    // 0x1161084: ldur            x5, [fp, #-0x20]
    // 0x1161088: LoadField: d0 = r5->field_7
    //     0x1161088: ldur            d0, [x5, #7]
    // 0x116108c: ldur            x6, [fp, #-0x10]
    // 0x1161090: sub             x16, x6, #0xb8e
    // 0x1161094: cmp             x16, #1
    // 0x1161098: b.hi            #0x11610a8
    // 0x116109c: ldur            x7, [fp, #-0x28]
    // 0x11610a0: d1 = 0.000000
    //     0x11610a0: eor             v1.16b, v1.16b, v1.16b
    // 0x11610a4: b               #0x11610c4
    // 0x11610a8: cmp             x6, #0xb8c
    // 0x11610ac: b.ne            #0x11610bc
    // 0x11610b0: ldur            x7, [fp, #-0x28]
    // 0x11610b4: LoadField: d1 = r7->field_f
    //     0x11610b4: ldur            d1, [x7, #0xf]
    // 0x11610b8: b               #0x11610c4
    // 0x11610bc: ldur            x7, [fp, #-0x28]
    // 0x11610c0: LoadField: d1 = r7->field_7
    //     0x11610c0: ldur            d1, [x7, #7]
    // 0x11610c4: r1 = inline_Allocate_Double()
    //     0x11610c4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11610c8: add             x1, x1, #0x10
    //     0x11610cc: cmp             x2, x1
    //     0x11610d0: b.ls            #0x11612cc
    //     0x11610d4: str             x1, [THR, #0x60]  ; THR::top
    //     0x11610d8: sub             x1, x1, #0xf
    //     0x11610dc: mov             x2, #0xe19c
    //     0x11610e0: movk            x2, #3, lsl #16
    //     0x11610e4: stur            x2, [x1, #-1]
    // 0x11610e8: dmb             ishst
    // 0x11610ec: StoreField: r1->field_7 = d0
    //     0x11610ec: stur            d0, [x1, #7]
    // 0x11610f0: r2 = inline_Allocate_Double()
    //     0x11610f0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11610f4: add             x2, x2, #0x10
    //     0x11610f8: cmp             x3, x2
    //     0x11610fc: b.ls            #0x11612f8
    //     0x1161100: str             x2, [THR, #0x60]  ; THR::top
    //     0x1161104: sub             x2, x2, #0xf
    //     0x1161108: mov             x3, #0xe19c
    //     0x116110c: movk            x3, #3, lsl #16
    //     0x1161110: stur            x3, [x2, #-1]
    // 0x1161114: dmb             ishst
    // 0x1161118: StoreField: r2->field_7 = d1
    //     0x1161118: stur            d1, [x2, #7]
    // 0x116111c: ldur            x3, [fp, #-8]
    // 0x1161120: r0 = lerpDouble()
    //     0x1161120: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1161124: mov             x4, x0
    // 0x1161128: ldur            x0, [fp, #-0x18]
    // 0x116112c: stur            x4, [fp, #-0x38]
    // 0x1161130: sub             x16, x0, #0xb8e
    // 0x1161134: cmp             x16, #1
    // 0x1161138: b.hi            #0x1161148
    // 0x116113c: ldur            x1, [fp, #-0x20]
    // 0x1161140: LoadField: d0 = r1->field_f
    //     0x1161140: ldur            d0, [x1, #0xf]
    // 0x1161144: b               #0x1161160
    // 0x1161148: ldur            x1, [fp, #-0x20]
    // 0x116114c: cmp             x0, #0xb8c
    // 0x1161150: b.ne            #0x116115c
    // 0x1161154: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1161154: ldur            d0, [x1, #0x17]
    // 0x1161158: b               #0x1161160
    // 0x116115c: LoadField: d0 = r1->field_f
    //     0x116115c: ldur            d0, [x1, #0xf]
    // 0x1161160: ldur            x0, [fp, #-0x10]
    // 0x1161164: sub             x16, x0, #0xb8e
    // 0x1161168: cmp             x16, #1
    // 0x116116c: b.hi            #0x116117c
    // 0x1161170: ldur            x1, [fp, #-0x28]
    // 0x1161174: LoadField: d1 = r1->field_f
    //     0x1161174: ldur            d1, [x1, #0xf]
    // 0x1161178: b               #0x1161194
    // 0x116117c: ldur            x1, [fp, #-0x28]
    // 0x1161180: cmp             x0, #0xb8c
    // 0x1161184: b.ne            #0x1161190
    // 0x1161188: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x1161188: ldur            d1, [x1, #0x17]
    // 0x116118c: b               #0x1161194
    // 0x1161190: LoadField: d1 = r1->field_f
    //     0x1161190: ldur            d1, [x1, #0xf]
    // 0x1161194: ldur            x0, [fp, #-0x30]
    // 0x1161198: r1 = inline_Allocate_Double()
    //     0x1161198: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x116119c: add             x1, x1, #0x10
    //     0x11611a0: cmp             x2, x1
    //     0x11611a4: b.ls            #0x1161324
    //     0x11611a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x11611ac: sub             x1, x1, #0xf
    //     0x11611b0: mov             x2, #0xe19c
    //     0x11611b4: movk            x2, #3, lsl #16
    //     0x11611b8: stur            x2, [x1, #-1]
    // 0x11611bc: dmb             ishst
    // 0x11611c0: StoreField: r1->field_7 = d0
    //     0x11611c0: stur            d0, [x1, #7]
    // 0x11611c4: r2 = inline_Allocate_Double()
    //     0x11611c4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11611c8: add             x2, x2, #0x10
    //     0x11611cc: cmp             x3, x2
    //     0x11611d0: b.ls            #0x1161340
    //     0x11611d4: str             x2, [THR, #0x60]  ; THR::top
    //     0x11611d8: sub             x2, x2, #0xf
    //     0x11611dc: mov             x3, #0xe19c
    //     0x11611e0: movk            x3, #3, lsl #16
    //     0x11611e4: stur            x3, [x2, #-1]
    // 0x11611e8: dmb             ishst
    // 0x11611ec: StoreField: r2->field_7 = d1
    //     0x11611ec: stur            d1, [x2, #7]
    // 0x11611f0: ldur            x3, [fp, #-8]
    // 0x11611f4: r0 = lerpDouble()
    //     0x11611f4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11611f8: mov             x1, x0
    // 0x11611fc: ldur            x0, [fp, #-0x30]
    // 0x1161200: stur            x1, [fp, #-8]
    // 0x1161204: LoadField: d0 = r0->field_7
    //     0x1161204: ldur            d0, [x0, #7]
    // 0x1161208: stur            d0, [fp, #-0x40]
    // 0x116120c: r0 = _MixedAlignment()
    //     0x116120c: bl              #0x1161a60  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0x1161210: ldur            d0, [fp, #-0x40]
    // 0x1161214: StoreField: r0->field_7 = d0
    //     0x1161214: stur            d0, [x0, #7]
    // 0x1161218: ldur            x1, [fp, #-0x38]
    // 0x116121c: LoadField: d0 = r1->field_7
    //     0x116121c: ldur            d0, [x1, #7]
    // 0x1161220: StoreField: r0->field_f = d0
    //     0x1161220: stur            d0, [x0, #0xf]
    // 0x1161224: ldur            x1, [fp, #-8]
    // 0x1161228: LoadField: d0 = r1->field_7
    //     0x1161228: ldur            d0, [x1, #7]
    // 0x116122c: ArrayStore: r0[0] = d0  ; List_8
    //     0x116122c: stur            d0, [x0, #0x17]
    // 0x1161230: LeaveFrame
    //     0x1161230: mov             SP, fp
    //     0x1161234: ldp             fp, lr, [SP], #0x10
    // 0x1161238: ret
    //     0x1161238: ret             
    // 0x116123c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116123c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1161240: b               #0x1160c70
    // 0x1161244: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1161244: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1161248: stp             q1, q2, [SP, #-0x20]!
    // 0x116124c: SaveReg d0
    //     0x116124c: str             q0, [SP, #-0x10]!
    // 0x1161250: stp             x5, x6, [SP, #-0x10]!
    // 0x1161254: stp             x0, x4, [SP, #-0x10]!
    // 0x1161258: r0 = AllocateDouble()
    //     0x1161258: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116125c: mov             x7, x0
    // 0x1161260: ldp             x0, x4, [SP], #0x10
    // 0x1161264: ldp             x5, x6, [SP], #0x10
    // 0x1161268: RestoreReg d0
    //     0x1161268: ldr             q0, [SP], #0x10
    // 0x116126c: ldp             q1, q2, [SP], #0x20
    // 0x1161270: b               #0x1160fe4
    // 0x1161274: stp             q1, q2, [SP, #-0x20]!
    // 0x1161278: stp             x6, x7, [SP, #-0x10]!
    // 0x116127c: stp             x4, x5, [SP, #-0x10]!
    // 0x1161280: SaveReg r0
    //     0x1161280: str             x0, [SP, #-8]!
    // 0x1161284: r0 = AllocateDouble()
    //     0x1161284: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161288: mov             x1, x0
    // 0x116128c: RestoreReg r0
    //     0x116128c: ldr             x0, [SP], #8
    // 0x1161290: ldp             x4, x5, [SP], #0x10
    // 0x1161294: ldp             x6, x7, [SP], #0x10
    // 0x1161298: ldp             q1, q2, [SP], #0x20
    // 0x116129c: b               #0x1161014
    // 0x11612a0: SaveReg d2
    //     0x11612a0: str             q2, [SP, #-0x10]!
    // 0x11612a4: stp             x6, x7, [SP, #-0x10]!
    // 0x11612a8: stp             x4, x5, [SP, #-0x10]!
    // 0x11612ac: stp             x0, x1, [SP, #-0x10]!
    // 0x11612b0: r0 = AllocateDouble()
    //     0x11612b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11612b4: mov             x2, x0
    // 0x11612b8: ldp             x0, x1, [SP], #0x10
    // 0x11612bc: ldp             x4, x5, [SP], #0x10
    // 0x11612c0: ldp             x6, x7, [SP], #0x10
    // 0x11612c4: RestoreReg d2
    //     0x11612c4: ldr             q2, [SP], #0x10
    // 0x11612c8: b               #0x1161040
    // 0x11612cc: stp             q0, q1, [SP, #-0x20]!
    // 0x11612d0: stp             x6, x7, [SP, #-0x10]!
    // 0x11612d4: stp             x4, x5, [SP, #-0x10]!
    // 0x11612d8: SaveReg r0
    //     0x11612d8: str             x0, [SP, #-8]!
    // 0x11612dc: r0 = AllocateDouble()
    //     0x11612dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11612e0: mov             x1, x0
    // 0x11612e4: RestoreReg r0
    //     0x11612e4: ldr             x0, [SP], #8
    // 0x11612e8: ldp             x4, x5, [SP], #0x10
    // 0x11612ec: ldp             x6, x7, [SP], #0x10
    // 0x11612f0: ldp             q0, q1, [SP], #0x20
    // 0x11612f4: b               #0x11610ec
    // 0x11612f8: SaveReg d1
    //     0x11612f8: str             q1, [SP, #-0x10]!
    // 0x11612fc: stp             x6, x7, [SP, #-0x10]!
    // 0x1161300: stp             x4, x5, [SP, #-0x10]!
    // 0x1161304: stp             x0, x1, [SP, #-0x10]!
    // 0x1161308: r0 = AllocateDouble()
    //     0x1161308: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116130c: mov             x2, x0
    // 0x1161310: ldp             x0, x1, [SP], #0x10
    // 0x1161314: ldp             x4, x5, [SP], #0x10
    // 0x1161318: ldp             x6, x7, [SP], #0x10
    // 0x116131c: RestoreReg d1
    //     0x116131c: ldr             q1, [SP], #0x10
    // 0x1161320: b               #0x1161118
    // 0x1161324: stp             q0, q1, [SP, #-0x20]!
    // 0x1161328: stp             x0, x4, [SP, #-0x10]!
    // 0x116132c: r0 = AllocateDouble()
    //     0x116132c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161330: mov             x1, x0
    // 0x1161334: ldp             x0, x4, [SP], #0x10
    // 0x1161338: ldp             q0, q1, [SP], #0x20
    // 0x116133c: b               #0x11611c0
    // 0x1161340: SaveReg d1
    //     0x1161340: str             q1, [SP, #-0x10]!
    // 0x1161344: stp             x1, x4, [SP, #-0x10]!
    // 0x1161348: SaveReg r0
    //     0x1161348: str             x0, [SP, #-8]!
    // 0x116134c: r0 = AllocateDouble()
    //     0x116134c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161350: mov             x2, x0
    // 0x1161354: RestoreReg r0
    //     0x1161354: ldr             x0, [SP], #8
    // 0x1161358: ldp             x1, x4, [SP], #0x10
    // 0x116135c: RestoreReg d1
    //     0x116135c: ldr             q1, [SP], #0x10
    // 0x1161360: b               #0x11611ec
  }
  _ ==(/* No info */) {
    // ** addr: 0x1297efc, size: 0x15c
    // 0x1297efc: ldr             x1, [SP]
    // 0x1297f00: cmp             w1, NULL
    // 0x1297f04: b.ne            #0x1297f10
    // 0x1297f08: r0 = false
    //     0x1297f08: add             x0, NULL, #0x30  ; false
    // 0x1297f0c: ret
    //     0x1297f0c: ret             
    // 0x1297f10: r2 = 60
    //     0x1297f10: mov             x2, #0x3c
    // 0x1297f14: branchIfSmi(r1, 0x1297f20)
    //     0x1297f14: tbz             w1, #0, #0x1297f20
    // 0x1297f18: r2 = LoadClassIdInstr(r1)
    //     0x1297f18: ldur            x2, [x1, #-1]
    //     0x1297f1c: ubfx            x2, x2, #0xc, #0x14
    // 0x1297f20: sub             x16, x2, #0xb8c
    // 0x1297f24: cmp             x16, #3
    // 0x1297f28: b.hi            #0x1298050
    // 0x1297f2c: sub             x16, x2, #0xb8e
    // 0x1297f30: cmp             x16, #1
    // 0x1297f34: b.hi            #0x1297f40
    // 0x1297f38: LoadField: d0 = r1->field_7
    //     0x1297f38: ldur            d0, [x1, #7]
    // 0x1297f3c: b               #0x1297f54
    // 0x1297f40: cmp             x2, #0xb8c
    // 0x1297f44: b.ne            #0x1297f50
    // 0x1297f48: LoadField: d0 = r1->field_7
    //     0x1297f48: ldur            d0, [x1, #7]
    // 0x1297f4c: b               #0x1297f54
    // 0x1297f50: d0 = 0.000000
    //     0x1297f50: eor             v0.16b, v0.16b, v0.16b
    // 0x1297f54: ldr             x3, [SP, #8]
    // 0x1297f58: r4 = LoadClassIdInstr(r3)
    //     0x1297f58: ldur            x4, [x3, #-1]
    //     0x1297f5c: ubfx            x4, x4, #0xc, #0x14
    // 0x1297f60: sub             x16, x4, #0xb8e
    // 0x1297f64: cmp             x16, #1
    // 0x1297f68: b.hi            #0x1297f74
    // 0x1297f6c: LoadField: d1 = r3->field_7
    //     0x1297f6c: ldur            d1, [x3, #7]
    // 0x1297f70: b               #0x1297f88
    // 0x1297f74: cmp             x4, #0xb8c
    // 0x1297f78: b.ne            #0x1297f84
    // 0x1297f7c: LoadField: d1 = r3->field_7
    //     0x1297f7c: ldur            d1, [x3, #7]
    // 0x1297f80: b               #0x1297f88
    // 0x1297f84: d1 = 0.000000
    //     0x1297f84: eor             v1.16b, v1.16b, v1.16b
    // 0x1297f88: fcmp            d0, d1
    // 0x1297f8c: b.ne            #0x1298050
    // 0x1297f90: sub             x16, x2, #0xb8e
    // 0x1297f94: cmp             x16, #1
    // 0x1297f98: b.hi            #0x1297fa4
    // 0x1297f9c: d0 = 0.000000
    //     0x1297f9c: eor             v0.16b, v0.16b, v0.16b
    // 0x1297fa0: b               #0x1297fb8
    // 0x1297fa4: cmp             x2, #0xb8c
    // 0x1297fa8: b.ne            #0x1297fb4
    // 0x1297fac: LoadField: d0 = r1->field_f
    //     0x1297fac: ldur            d0, [x1, #0xf]
    // 0x1297fb0: b               #0x1297fb8
    // 0x1297fb4: LoadField: d0 = r1->field_7
    //     0x1297fb4: ldur            d0, [x1, #7]
    // 0x1297fb8: sub             x16, x4, #0xb8e
    // 0x1297fbc: cmp             x16, #1
    // 0x1297fc0: b.hi            #0x1297fcc
    // 0x1297fc4: d1 = 0.000000
    //     0x1297fc4: eor             v1.16b, v1.16b, v1.16b
    // 0x1297fc8: b               #0x1297fe0
    // 0x1297fcc: cmp             x4, #0xb8c
    // 0x1297fd0: b.ne            #0x1297fdc
    // 0x1297fd4: LoadField: d1 = r3->field_f
    //     0x1297fd4: ldur            d1, [x3, #0xf]
    // 0x1297fd8: b               #0x1297fe0
    // 0x1297fdc: LoadField: d1 = r3->field_7
    //     0x1297fdc: ldur            d1, [x3, #7]
    // 0x1297fe0: fcmp            d0, d1
    // 0x1297fe4: b.ne            #0x1298050
    // 0x1297fe8: sub             x16, x2, #0xb8e
    // 0x1297fec: cmp             x16, #1
    // 0x1297ff0: b.hi            #0x1297ffc
    // 0x1297ff4: LoadField: d0 = r1->field_f
    //     0x1297ff4: ldur            d0, [x1, #0xf]
    // 0x1297ff8: b               #0x1298010
    // 0x1297ffc: cmp             x2, #0xb8c
    // 0x1298000: b.ne            #0x129800c
    // 0x1298004: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1298004: ldur            d0, [x1, #0x17]
    // 0x1298008: b               #0x1298010
    // 0x129800c: LoadField: d0 = r1->field_f
    //     0x129800c: ldur            d0, [x1, #0xf]
    // 0x1298010: sub             x16, x4, #0xb8e
    // 0x1298014: cmp             x16, #1
    // 0x1298018: b.hi            #0x1298024
    // 0x129801c: LoadField: d1 = r3->field_f
    //     0x129801c: ldur            d1, [x3, #0xf]
    // 0x1298020: b               #0x1298038
    // 0x1298024: cmp             x4, #0xb8c
    // 0x1298028: b.ne            #0x1298034
    // 0x129802c: ArrayLoad: d1 = r3[0]  ; List_8
    //     0x129802c: ldur            d1, [x3, #0x17]
    // 0x1298030: b               #0x1298038
    // 0x1298034: LoadField: d1 = r3->field_f
    //     0x1298034: ldur            d1, [x3, #0xf]
    // 0x1298038: fcmp            d0, d1
    // 0x129803c: r16 = true
    //     0x129803c: add             x16, NULL, #0x20  ; true
    // 0x1298040: r17 = false
    //     0x1298040: add             x17, NULL, #0x30  ; false
    // 0x1298044: csel            x1, x16, x17, eq
    // 0x1298048: mov             x0, x1
    // 0x129804c: b               #0x1298054
    // 0x1298050: r0 = false
    //     0x1298050: add             x0, NULL, #0x30  ; false
    // 0x1298054: ret
    //     0x1298054: ret             
  }
}

// class id: 2956, size: 0x20, field offset: 0x8
//   const constructor, 
class _MixedAlignment extends AlignmentGeometry {

  Alignment resolve(_MixedAlignment, TextDirection?) {
    // ** addr: 0xb5ff10, size: 0x88
    // 0xb5ff10: EnterFrame
    //     0xb5ff10: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ff14: mov             fp, SP
    // 0xb5ff18: CheckStackOverflow
    //     0xb5ff18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5ff1c: cmp             SP, x16
    //     0xb5ff20: b.ls            #0xb5ff78
    // 0xb5ff24: ldr             x0, [fp, #0x10]
    // 0xb5ff28: r2 = Null
    //     0xb5ff28: mov             x2, NULL
    // 0xb5ff2c: r1 = Null
    //     0xb5ff2c: mov             x1, NULL
    // 0xb5ff30: r4 = 60
    //     0xb5ff30: mov             x4, #0x3c
    // 0xb5ff34: branchIfSmi(r0, 0xb5ff40)
    //     0xb5ff34: tbz             w0, #0, #0xb5ff40
    // 0xb5ff38: r4 = LoadClassIdInstr(r0)
    //     0xb5ff38: ldur            x4, [x0, #-1]
    //     0xb5ff3c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5ff40: r17 = 8353
    //     0xb5ff40: mov             x17, #0x20a1
    // 0xb5ff44: cmp             x4, x17
    // 0xb5ff48: b.eq            #0xb5ff60
    // 0xb5ff4c: r8 = TextDirection?
    //     0xb5ff4c: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0xb5ff50: ldr             x8, [x8, #0x750]
    // 0xb5ff54: r3 = Null
    //     0xb5ff54: add             x3, PP, #0xad, lsl #12  ; [pp+0xad0e8] Null
    //     0xb5ff58: ldr             x3, [x3, #0xe8]
    // 0xb5ff5c: r0 = DefaultNullableTypeTest()
    //     0xb5ff5c: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xb5ff60: ldr             x1, [fp, #0x18]
    // 0xb5ff64: ldr             x2, [fp, #0x10]
    // 0xb5ff68: r0 = resolve()
    //     0xb5ff68: bl              #0x1301c28  ; [package:flutter/src/painting/alignment.dart] _MixedAlignment::resolve
    // 0xb5ff6c: LeaveFrame
    //     0xb5ff6c: mov             SP, fp
    //     0xb5ff70: ldp             fp, lr, [SP], #0x10
    // 0xb5ff74: ret
    //     0xb5ff74: ret             
    // 0xb5ff78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5ff78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5ff7c: b               #0xb5ff24
  }
  Alignment resolve(_MixedAlignment, TextDirection?) {
    // ** addr: 0x1301c28, size: 0x8c
    // 0x1301c28: EnterFrame
    //     0x1301c28: stp             fp, lr, [SP, #-0x10]!
    //     0x1301c2c: mov             fp, SP
    // 0x1301c30: AllocStack(0x10)
    //     0x1301c30: sub             SP, SP, #0x10
    // 0x1301c34: cmp             w2, NULL
    // 0x1301c38: b.eq            #0x1301cb0
    // 0x1301c3c: LoadField: r0 = r2->field_7
    //     0x1301c3c: ldur            x0, [x2, #7]
    // 0x1301c40: cmp             x0, #0
    // 0x1301c44: b.gt            #0x1301c78
    // 0x1301c48: LoadField: d0 = r1->field_7
    //     0x1301c48: ldur            d0, [x1, #7]
    // 0x1301c4c: LoadField: d1 = r1->field_f
    //     0x1301c4c: ldur            d1, [x1, #0xf]
    // 0x1301c50: fsub            d2, d0, d1
    // 0x1301c54: stur            d2, [fp, #-0x10]
    // 0x1301c58: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1301c58: ldur            d0, [x1, #0x17]
    // 0x1301c5c: stur            d0, [fp, #-8]
    // 0x1301c60: r0 = Alignment()
    //     0x1301c60: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1301c64: ldur            d0, [fp, #-0x10]
    // 0x1301c68: StoreField: r0->field_7 = d0
    //     0x1301c68: stur            d0, [x0, #7]
    // 0x1301c6c: ldur            d0, [fp, #-8]
    // 0x1301c70: StoreField: r0->field_f = d0
    //     0x1301c70: stur            d0, [x0, #0xf]
    // 0x1301c74: b               #0x1301ca4
    // 0x1301c78: LoadField: d0 = r1->field_7
    //     0x1301c78: ldur            d0, [x1, #7]
    // 0x1301c7c: LoadField: d1 = r1->field_f
    //     0x1301c7c: ldur            d1, [x1, #0xf]
    // 0x1301c80: fadd            d2, d0, d1
    // 0x1301c84: stur            d2, [fp, #-0x10]
    // 0x1301c88: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1301c88: ldur            d0, [x1, #0x17]
    // 0x1301c8c: stur            d0, [fp, #-8]
    // 0x1301c90: r0 = Alignment()
    //     0x1301c90: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1301c94: ldur            d0, [fp, #-0x10]
    // 0x1301c98: StoreField: r0->field_7 = d0
    //     0x1301c98: stur            d0, [x0, #7]
    // 0x1301c9c: ldur            d0, [fp, #-8]
    // 0x1301ca0: StoreField: r0->field_f = d0
    //     0x1301ca0: stur            d0, [x0, #0xf]
    // 0x1301ca4: LeaveFrame
    //     0x1301ca4: mov             SP, fp
    //     0x1301ca8: ldp             fp, lr, [SP], #0x10
    // 0x1301cac: ret
    //     0x1301cac: ret             
    // 0x1301cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1301cb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2957, size: 0x18, field offset: 0x8
//   const constructor, 
class AlignmentDirectional extends AlignmentGeometry {

  _Double field_8;
  _Double field_10;

  AlignmentDirectional *(AlignmentDirectional, double) {
    // ** addr: 0xb5f3bc, size: 0x50
    // 0xb5f3bc: EnterFrame
    //     0xb5f3bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f3c0: mov             fp, SP
    // 0xb5f3c4: CheckStackOverflow
    //     0xb5f3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f3c8: cmp             SP, x16
    //     0xb5f3cc: b.ls            #0xb5f3ec
    // 0xb5f3d0: ldr             x0, [fp, #0x10]
    // 0xb5f3d4: LoadField: d0 = r0->field_7
    //     0xb5f3d4: ldur            d0, [x0, #7]
    // 0xb5f3d8: ldr             x1, [fp, #0x18]
    // 0xb5f3dc: r0 = *()
    //     0xb5f3dc: bl              #0x12ffb6c  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::*
    // 0xb5f3e0: LeaveFrame
    //     0xb5f3e0: mov             SP, fp
    //     0xb5f3e4: ldp             fp, lr, [SP], #0x10
    // 0xb5f3e8: ret
    //     0xb5f3e8: ret             
    // 0xb5f3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f3ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f3f0: b               #0xb5f3d0
  }
  Alignment resolve(AlignmentDirectional, TextDirection?) {
    // ** addr: 0xb5f40c, size: 0x88
    // 0xb5f40c: EnterFrame
    //     0xb5f40c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f410: mov             fp, SP
    // 0xb5f414: CheckStackOverflow
    //     0xb5f414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f418: cmp             SP, x16
    //     0xb5f41c: b.ls            #0xb5f474
    // 0xb5f420: ldr             x0, [fp, #0x10]
    // 0xb5f424: r2 = Null
    //     0xb5f424: mov             x2, NULL
    // 0xb5f428: r1 = Null
    //     0xb5f428: mov             x1, NULL
    // 0xb5f42c: r4 = 60
    //     0xb5f42c: mov             x4, #0x3c
    // 0xb5f430: branchIfSmi(r0, 0xb5f43c)
    //     0xb5f430: tbz             w0, #0, #0xb5f43c
    // 0xb5f434: r4 = LoadClassIdInstr(r0)
    //     0xb5f434: ldur            x4, [x0, #-1]
    //     0xb5f438: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f43c: r17 = 8353
    //     0xb5f43c: mov             x17, #0x20a1
    // 0xb5f440: cmp             x4, x17
    // 0xb5f444: b.eq            #0xb5f45c
    // 0xb5f448: r8 = TextDirection?
    //     0xb5f448: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0xb5f44c: ldr             x8, [x8, #0x750]
    // 0xb5f450: r3 = Null
    //     0xb5f450: add             x3, PP, #0x82, lsl #12  ; [pp+0x827d8] Null
    //     0xb5f454: ldr             x3, [x3, #0x7d8]
    // 0xb5f458: r0 = DefaultNullableTypeTest()
    //     0xb5f458: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xb5f45c: ldr             x1, [fp, #0x18]
    // 0xb5f460: ldr             x2, [fp, #0x10]
    // 0xb5f464: r0 = resolve()
    //     0xb5f464: bl              #0x1301ba8  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::resolve
    // 0xb5f468: LeaveFrame
    //     0xb5f468: mov             SP, fp
    //     0xb5f46c: ldp             fp, lr, [SP], #0x10
    // 0xb5f470: ret
    //     0xb5f470: ret             
    // 0xb5f474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f474: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f478: b               #0xb5f420
  }
  AlignmentDirectional -(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0xb5f494, size: 0x84
    // 0xb5f494: EnterFrame
    //     0xb5f494: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f498: mov             fp, SP
    // 0xb5f49c: CheckStackOverflow
    //     0xb5f49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f4a0: cmp             SP, x16
    //     0xb5f4a4: b.ls            #0xb5f4f8
    // 0xb5f4a8: ldr             x0, [fp, #0x10]
    // 0xb5f4ac: r2 = Null
    //     0xb5f4ac: mov             x2, NULL
    // 0xb5f4b0: r1 = Null
    //     0xb5f4b0: mov             x1, NULL
    // 0xb5f4b4: r4 = 60
    //     0xb5f4b4: mov             x4, #0x3c
    // 0xb5f4b8: branchIfSmi(r0, 0xb5f4c4)
    //     0xb5f4b8: tbz             w0, #0, #0xb5f4c4
    // 0xb5f4bc: r4 = LoadClassIdInstr(r0)
    //     0xb5f4bc: ldur            x4, [x0, #-1]
    //     0xb5f4c0: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f4c4: cmp             x4, #0xb8d
    // 0xb5f4c8: b.eq            #0xb5f4e0
    // 0xb5f4cc: r8 = AlignmentDirectional
    //     0xb5f4cc: add             x8, PP, #0x82, lsl #12  ; [pp+0x827e8] Type: AlignmentDirectional
    //     0xb5f4d0: ldr             x8, [x8, #0x7e8]
    // 0xb5f4d4: r3 = Null
    //     0xb5f4d4: add             x3, PP, #0x82, lsl #12  ; [pp+0x827f0] Null
    //     0xb5f4d8: ldr             x3, [x3, #0x7f0]
    // 0xb5f4dc: r0 = DefaultTypeTest()
    //     0xb5f4dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5f4e0: ldr             x1, [fp, #0x18]
    // 0xb5f4e4: ldr             x2, [fp, #0x10]
    // 0xb5f4e8: r0 = -()
    //     0xb5f4e8: bl              #0xb5f500  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::-
    // 0xb5f4ec: LeaveFrame
    //     0xb5f4ec: mov             SP, fp
    //     0xb5f4f0: ldp             fp, lr, [SP], #0x10
    // 0xb5f4f4: ret
    //     0xb5f4f4: ret             
    // 0xb5f4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f4f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f4fc: b               #0xb5f4a8
  }
  AlignmentDirectional -(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0xb5f500, size: 0x4c
    // 0xb5f500: EnterFrame
    //     0xb5f500: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f504: mov             fp, SP
    // 0xb5f508: AllocStack(0x10)
    //     0xb5f508: sub             SP, SP, #0x10
    // 0xb5f50c: LoadField: d0 = r1->field_7
    //     0xb5f50c: ldur            d0, [x1, #7]
    // 0xb5f510: LoadField: d1 = r2->field_7
    //     0xb5f510: ldur            d1, [x2, #7]
    // 0xb5f514: fsub            d2, d0, d1
    // 0xb5f518: stur            d2, [fp, #-0x10]
    // 0xb5f51c: LoadField: d0 = r1->field_f
    //     0xb5f51c: ldur            d0, [x1, #0xf]
    // 0xb5f520: LoadField: d1 = r2->field_f
    //     0xb5f520: ldur            d1, [x2, #0xf]
    // 0xb5f524: fsub            d3, d0, d1
    // 0xb5f528: stur            d3, [fp, #-8]
    // 0xb5f52c: r0 = AlignmentDirectional()
    //     0xb5f52c: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xb5f530: ldur            d0, [fp, #-0x10]
    // 0xb5f534: StoreField: r0->field_7 = d0
    //     0xb5f534: stur            d0, [x0, #7]
    // 0xb5f538: ldur            d0, [fp, #-8]
    // 0xb5f53c: StoreField: r0->field_f = d0
    //     0xb5f53c: stur            d0, [x0, #0xf]
    // 0xb5f540: LeaveFrame
    //     0xb5f540: mov             SP, fp
    //     0xb5f544: ldp             fp, lr, [SP], #0x10
    // 0xb5f548: ret
    //     0xb5f548: ret             
  }
  AlignmentDirectional +(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0xb5f570, size: 0x84
    // 0xb5f570: EnterFrame
    //     0xb5f570: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f574: mov             fp, SP
    // 0xb5f578: CheckStackOverflow
    //     0xb5f578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5f57c: cmp             SP, x16
    //     0xb5f580: b.ls            #0xb5f5d4
    // 0xb5f584: ldr             x0, [fp, #0x10]
    // 0xb5f588: r2 = Null
    //     0xb5f588: mov             x2, NULL
    // 0xb5f58c: r1 = Null
    //     0xb5f58c: mov             x1, NULL
    // 0xb5f590: r4 = 60
    //     0xb5f590: mov             x4, #0x3c
    // 0xb5f594: branchIfSmi(r0, 0xb5f5a0)
    //     0xb5f594: tbz             w0, #0, #0xb5f5a0
    // 0xb5f598: r4 = LoadClassIdInstr(r0)
    //     0xb5f598: ldur            x4, [x0, #-1]
    //     0xb5f59c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5f5a0: cmp             x4, #0xb8d
    // 0xb5f5a4: b.eq            #0xb5f5bc
    // 0xb5f5a8: r8 = AlignmentDirectional
    //     0xb5f5a8: add             x8, PP, #0x82, lsl #12  ; [pp+0x827e8] Type: AlignmentDirectional
    //     0xb5f5ac: ldr             x8, [x8, #0x7e8]
    // 0xb5f5b0: r3 = Null
    //     0xb5f5b0: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8ef38] Null
    //     0xb5f5b4: ldr             x3, [x3, #0xf38]
    // 0xb5f5b8: r0 = DefaultTypeTest()
    //     0xb5f5b8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5f5bc: ldr             x1, [fp, #0x18]
    // 0xb5f5c0: ldr             x2, [fp, #0x10]
    // 0xb5f5c4: r0 = +()
    //     0xb5f5c4: bl              #0xb5f5dc  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::+
    // 0xb5f5c8: LeaveFrame
    //     0xb5f5c8: mov             SP, fp
    //     0xb5f5cc: ldp             fp, lr, [SP], #0x10
    // 0xb5f5d0: ret
    //     0xb5f5d0: ret             
    // 0xb5f5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5f5d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5f5d8: b               #0xb5f584
  }
  AlignmentDirectional +(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0xb5f5dc, size: 0x4c
    // 0xb5f5dc: EnterFrame
    //     0xb5f5dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f5e0: mov             fp, SP
    // 0xb5f5e4: AllocStack(0x10)
    //     0xb5f5e4: sub             SP, SP, #0x10
    // 0xb5f5e8: LoadField: d0 = r1->field_7
    //     0xb5f5e8: ldur            d0, [x1, #7]
    // 0xb5f5ec: LoadField: d1 = r2->field_7
    //     0xb5f5ec: ldur            d1, [x2, #7]
    // 0xb5f5f0: fadd            d2, d0, d1
    // 0xb5f5f4: stur            d2, [fp, #-0x10]
    // 0xb5f5f8: LoadField: d0 = r1->field_f
    //     0xb5f5f8: ldur            d0, [x1, #0xf]
    // 0xb5f5fc: LoadField: d1 = r2->field_f
    //     0xb5f5fc: ldur            d1, [x2, #0xf]
    // 0xb5f600: fadd            d3, d0, d1
    // 0xb5f604: stur            d3, [fp, #-8]
    // 0xb5f608: r0 = AlignmentDirectional()
    //     0xb5f608: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xb5f60c: ldur            d0, [fp, #-0x10]
    // 0xb5f610: StoreField: r0->field_7 = d0
    //     0xb5f610: stur            d0, [x0, #7]
    // 0xb5f614: ldur            d0, [fp, #-8]
    // 0xb5f618: StoreField: r0->field_f = d0
    //     0xb5f618: stur            d0, [x0, #0xf]
    // 0xb5f61c: LeaveFrame
    //     0xb5f61c: mov             SP, fp
    //     0xb5f620: ldp             fp, lr, [SP], #0x10
    // 0xb5f624: ret
    //     0xb5f624: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1161364, size: 0x234
    // 0x1161364: EnterFrame
    //     0x1161364: stp             fp, lr, [SP, #-0x10]!
    //     0x1161368: mov             fp, SP
    // 0x116136c: AllocStack(0x28)
    //     0x116136c: sub             SP, SP, #0x28
    // 0x1161370: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x1161370: mov             x4, x1
    //     0x1161374: mov             x0, x2
    //     0x1161378: stur            x1, [fp, #-0x10]
    //     0x116137c: stur            x2, [fp, #-0x18]
    // 0x1161380: CheckStackOverflow
    //     0x1161380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1161384: cmp             SP, x16
    //     0x1161388: b.ls            #0x11614ec
    // 0x116138c: cmp             w4, w0
    // 0x1161390: b.ne            #0x11613a4
    // 0x1161394: mov             x0, x4
    // 0x1161398: LeaveFrame
    //     0x1161398: mov             SP, fp
    //     0x116139c: ldp             fp, lr, [SP], #0x10
    // 0x11613a0: ret
    //     0x11613a0: ret             
    // 0x11613a4: LoadField: d1 = r4->field_7
    //     0x11613a4: ldur            d1, [x4, #7]
    // 0x11613a8: LoadField: d2 = r0->field_7
    //     0x11613a8: ldur            d2, [x0, #7]
    // 0x11613ac: r5 = inline_Allocate_Double()
    //     0x11613ac: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11613b0: add             x5, x5, #0x10
    //     0x11613b4: cmp             x1, x5
    //     0x11613b8: b.ls            #0x11614f4
    //     0x11613bc: str             x5, [THR, #0x60]  ; THR::top
    //     0x11613c0: sub             x5, x5, #0xf
    //     0x11613c4: mov             x1, #0xe19c
    //     0x11613c8: movk            x1, #3, lsl #16
    //     0x11613cc: stur            x1, [x5, #-1]
    // 0x11613d0: dmb             ishst
    // 0x11613d4: StoreField: r5->field_7 = d0
    //     0x11613d4: stur            d0, [x5, #7]
    // 0x11613d8: stur            x5, [fp, #-8]
    // 0x11613dc: r1 = inline_Allocate_Double()
    //     0x11613dc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11613e0: add             x1, x1, #0x10
    //     0x11613e4: cmp             x2, x1
    //     0x11613e8: b.ls            #0x1161518
    //     0x11613ec: str             x1, [THR, #0x60]  ; THR::top
    //     0x11613f0: sub             x1, x1, #0xf
    //     0x11613f4: mov             x2, #0xe19c
    //     0x11613f8: movk            x2, #3, lsl #16
    //     0x11613fc: stur            x2, [x1, #-1]
    // 0x1161400: dmb             ishst
    // 0x1161404: StoreField: r1->field_7 = d1
    //     0x1161404: stur            d1, [x1, #7]
    // 0x1161408: r2 = inline_Allocate_Double()
    //     0x1161408: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x116140c: add             x2, x2, #0x10
    //     0x1161410: cmp             x3, x2
    //     0x1161414: b.ls            #0x116153c
    //     0x1161418: str             x2, [THR, #0x60]  ; THR::top
    //     0x116141c: sub             x2, x2, #0xf
    //     0x1161420: mov             x3, #0xe19c
    //     0x1161424: movk            x3, #3, lsl #16
    //     0x1161428: stur            x3, [x2, #-1]
    // 0x116142c: dmb             ishst
    // 0x1161430: StoreField: r2->field_7 = d2
    //     0x1161430: stur            d2, [x2, #7]
    // 0x1161434: mov             x3, x5
    // 0x1161438: r0 = lerpDouble()
    //     0x1161438: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116143c: mov             x4, x0
    // 0x1161440: ldur            x0, [fp, #-0x10]
    // 0x1161444: stur            x4, [fp, #-0x20]
    // 0x1161448: LoadField: d0 = r0->field_f
    //     0x1161448: ldur            d0, [x0, #0xf]
    // 0x116144c: ldur            x0, [fp, #-0x18]
    // 0x1161450: LoadField: d1 = r0->field_f
    //     0x1161450: ldur            d1, [x0, #0xf]
    // 0x1161454: r1 = inline_Allocate_Double()
    //     0x1161454: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x1161458: add             x1, x1, #0x10
    //     0x116145c: cmp             x0, x1
    //     0x1161460: b.ls            #0x1161560
    //     0x1161464: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161468: sub             x1, x1, #0xf
    //     0x116146c: mov             x0, #0xe19c
    //     0x1161470: movk            x0, #3, lsl #16
    //     0x1161474: stur            x0, [x1, #-1]
    // 0x1161478: dmb             ishst
    // 0x116147c: StoreField: r1->field_7 = d0
    //     0x116147c: stur            d0, [x1, #7]
    // 0x1161480: r2 = inline_Allocate_Double()
    //     0x1161480: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1161484: add             x2, x2, #0x10
    //     0x1161488: cmp             x0, x2
    //     0x116148c: b.ls            #0x116157c
    //     0x1161490: str             x2, [THR, #0x60]  ; THR::top
    //     0x1161494: sub             x2, x2, #0xf
    //     0x1161498: mov             x0, #0xe19c
    //     0x116149c: movk            x0, #3, lsl #16
    //     0x11614a0: stur            x0, [x2, #-1]
    // 0x11614a4: dmb             ishst
    // 0x11614a8: StoreField: r2->field_7 = d1
    //     0x11614a8: stur            d1, [x2, #7]
    // 0x11614ac: ldur            x3, [fp, #-8]
    // 0x11614b0: r0 = lerpDouble()
    //     0x11614b0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11614b4: mov             x1, x0
    // 0x11614b8: ldur            x0, [fp, #-0x20]
    // 0x11614bc: stur            x1, [fp, #-8]
    // 0x11614c0: LoadField: d0 = r0->field_7
    //     0x11614c0: ldur            d0, [x0, #7]
    // 0x11614c4: stur            d0, [fp, #-0x28]
    // 0x11614c8: r0 = AlignmentDirectional()
    //     0x11614c8: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x11614cc: ldur            d0, [fp, #-0x28]
    // 0x11614d0: StoreField: r0->field_7 = d0
    //     0x11614d0: stur            d0, [x0, #7]
    // 0x11614d4: ldur            x1, [fp, #-8]
    // 0x11614d8: LoadField: d0 = r1->field_7
    //     0x11614d8: ldur            d0, [x1, #7]
    // 0x11614dc: StoreField: r0->field_f = d0
    //     0x11614dc: stur            d0, [x0, #0xf]
    // 0x11614e0: LeaveFrame
    //     0x11614e0: mov             SP, fp
    //     0x11614e4: ldp             fp, lr, [SP], #0x10
    // 0x11614e8: ret
    //     0x11614e8: ret             
    // 0x11614ec: r0 = StackOverflowSharedWithFPURegs()
    //     0x11614ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11614f0: b               #0x116138c
    // 0x11614f4: stp             q1, q2, [SP, #-0x20]!
    // 0x11614f8: SaveReg d0
    //     0x11614f8: str             q0, [SP, #-0x10]!
    // 0x11614fc: stp             x0, x4, [SP, #-0x10]!
    // 0x1161500: r0 = AllocateDouble()
    //     0x1161500: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161504: mov             x5, x0
    // 0x1161508: ldp             x0, x4, [SP], #0x10
    // 0x116150c: RestoreReg d0
    //     0x116150c: ldr             q0, [SP], #0x10
    // 0x1161510: ldp             q1, q2, [SP], #0x20
    // 0x1161514: b               #0x11613d4
    // 0x1161518: stp             q1, q2, [SP, #-0x20]!
    // 0x116151c: stp             x4, x5, [SP, #-0x10]!
    // 0x1161520: SaveReg r0
    //     0x1161520: str             x0, [SP, #-8]!
    // 0x1161524: r0 = AllocateDouble()
    //     0x1161524: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161528: mov             x1, x0
    // 0x116152c: RestoreReg r0
    //     0x116152c: ldr             x0, [SP], #8
    // 0x1161530: ldp             x4, x5, [SP], #0x10
    // 0x1161534: ldp             q1, q2, [SP], #0x20
    // 0x1161538: b               #0x1161404
    // 0x116153c: SaveReg d2
    //     0x116153c: str             q2, [SP, #-0x10]!
    // 0x1161540: stp             x4, x5, [SP, #-0x10]!
    // 0x1161544: stp             x0, x1, [SP, #-0x10]!
    // 0x1161548: r0 = AllocateDouble()
    //     0x1161548: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116154c: mov             x2, x0
    // 0x1161550: ldp             x0, x1, [SP], #0x10
    // 0x1161554: ldp             x4, x5, [SP], #0x10
    // 0x1161558: RestoreReg d2
    //     0x1161558: ldr             q2, [SP], #0x10
    // 0x116155c: b               #0x1161430
    // 0x1161560: stp             q0, q1, [SP, #-0x20]!
    // 0x1161564: SaveReg r4
    //     0x1161564: str             x4, [SP, #-8]!
    // 0x1161568: r0 = AllocateDouble()
    //     0x1161568: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116156c: mov             x1, x0
    // 0x1161570: RestoreReg r4
    //     0x1161570: ldr             x4, [SP], #8
    // 0x1161574: ldp             q0, q1, [SP], #0x20
    // 0x1161578: b               #0x116147c
    // 0x116157c: SaveReg d1
    //     0x116157c: str             q1, [SP, #-0x10]!
    // 0x1161580: stp             x1, x4, [SP, #-0x10]!
    // 0x1161584: r0 = AllocateDouble()
    //     0x1161584: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161588: mov             x2, x0
    // 0x116158c: ldp             x1, x4, [SP], #0x10
    // 0x1161590: RestoreReg d1
    //     0x1161590: ldr             q1, [SP], #0x10
    // 0x1161594: b               #0x11614a8
  }
  AlignmentDirectional *(AlignmentDirectional, double) {
    // ** addr: 0x12ffb6c, size: 0x44
    // 0x12ffb6c: EnterFrame
    //     0x12ffb6c: stp             fp, lr, [SP, #-0x10]!
    //     0x12ffb70: mov             fp, SP
    // 0x12ffb74: AllocStack(0x10)
    //     0x12ffb74: sub             SP, SP, #0x10
    // 0x12ffb78: LoadField: d1 = r1->field_7
    //     0x12ffb78: ldur            d1, [x1, #7]
    // 0x12ffb7c: fmul            d2, d1, d0
    // 0x12ffb80: stur            d2, [fp, #-0x10]
    // 0x12ffb84: LoadField: d1 = r1->field_f
    //     0x12ffb84: ldur            d1, [x1, #0xf]
    // 0x12ffb88: fmul            d3, d1, d0
    // 0x12ffb8c: stur            d3, [fp, #-8]
    // 0x12ffb90: r0 = AlignmentDirectional()
    //     0x12ffb90: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x12ffb94: ldur            d0, [fp, #-0x10]
    // 0x12ffb98: StoreField: r0->field_7 = d0
    //     0x12ffb98: stur            d0, [x0, #7]
    // 0x12ffb9c: ldur            d0, [fp, #-8]
    // 0x12ffba0: StoreField: r0->field_f = d0
    //     0x12ffba0: stur            d0, [x0, #0xf]
    // 0x12ffba4: LeaveFrame
    //     0x12ffba4: mov             SP, fp
    //     0x12ffba8: ldp             fp, lr, [SP], #0x10
    // 0x12ffbac: ret
    //     0x12ffbac: ret             
  }
  Alignment resolve(AlignmentDirectional, TextDirection?) {
    // ** addr: 0x1301ba8, size: 0x80
    // 0x1301ba8: EnterFrame
    //     0x1301ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x1301bac: mov             fp, SP
    // 0x1301bb0: AllocStack(0x10)
    //     0x1301bb0: sub             SP, SP, #0x10
    // 0x1301bb4: cmp             w2, NULL
    // 0x1301bb8: b.eq            #0x1301c24
    // 0x1301bbc: LoadField: r0 = r2->field_7
    //     0x1301bbc: ldur            x0, [x2, #7]
    // 0x1301bc0: cmp             x0, #0
    // 0x1301bc4: b.gt            #0x1301bf4
    // 0x1301bc8: LoadField: d0 = r1->field_7
    //     0x1301bc8: ldur            d0, [x1, #7]
    // 0x1301bcc: fneg            d1, d0
    // 0x1301bd0: stur            d1, [fp, #-0x10]
    // 0x1301bd4: LoadField: d0 = r1->field_f
    //     0x1301bd4: ldur            d0, [x1, #0xf]
    // 0x1301bd8: stur            d0, [fp, #-8]
    // 0x1301bdc: r0 = Alignment()
    //     0x1301bdc: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1301be0: ldur            d0, [fp, #-0x10]
    // 0x1301be4: StoreField: r0->field_7 = d0
    //     0x1301be4: stur            d0, [x0, #7]
    // 0x1301be8: ldur            d0, [fp, #-8]
    // 0x1301bec: StoreField: r0->field_f = d0
    //     0x1301bec: stur            d0, [x0, #0xf]
    // 0x1301bf0: b               #0x1301c18
    // 0x1301bf4: LoadField: d0 = r1->field_7
    //     0x1301bf4: ldur            d0, [x1, #7]
    // 0x1301bf8: stur            d0, [fp, #-0x10]
    // 0x1301bfc: LoadField: d1 = r1->field_f
    //     0x1301bfc: ldur            d1, [x1, #0xf]
    // 0x1301c00: stur            d1, [fp, #-8]
    // 0x1301c04: r0 = Alignment()
    //     0x1301c04: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x1301c08: ldur            d0, [fp, #-0x10]
    // 0x1301c0c: StoreField: r0->field_7 = d0
    //     0x1301c0c: stur            d0, [x0, #7]
    // 0x1301c10: ldur            d0, [fp, #-8]
    // 0x1301c14: StoreField: r0->field_f = d0
    //     0x1301c14: stur            d0, [x0, #0xf]
    // 0x1301c18: LeaveFrame
    //     0x1301c18: mov             SP, fp
    //     0x1301c1c: ldp             fp, lr, [SP], #0x10
    // 0x1301c20: ret
    //     0x1301c20: ret             
    // 0x1301c24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1301c24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2958, size: 0x18, field offset: 0x8
//   const constructor, 
class Alignment extends AlignmentGeometry {

  _Double field_8;
  _Double field_10;

  Alignment +(Alignment, Alignment) {
    // ** addr: 0x82f460, size: 0x88
    // 0x82f460: EnterFrame
    //     0x82f460: stp             fp, lr, [SP, #-0x10]!
    //     0x82f464: mov             fp, SP
    // 0x82f468: CheckStackOverflow
    //     0x82f468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f46c: cmp             SP, x16
    //     0x82f470: b.ls            #0x82f4c8
    // 0x82f474: ldr             x0, [fp, #0x10]
    // 0x82f478: r2 = Null
    //     0x82f478: mov             x2, NULL
    // 0x82f47c: r1 = Null
    //     0x82f47c: mov             x1, NULL
    // 0x82f480: r4 = 60
    //     0x82f480: mov             x4, #0x3c
    // 0x82f484: branchIfSmi(r0, 0x82f490)
    //     0x82f484: tbz             w0, #0, #0x82f490
    // 0x82f488: r4 = LoadClassIdInstr(r0)
    //     0x82f488: ldur            x4, [x0, #-1]
    //     0x82f48c: ubfx            x4, x4, #0xc, #0x14
    // 0x82f490: sub             x4, x4, #0xb8e
    // 0x82f494: cmp             x4, #1
    // 0x82f498: b.ls            #0x82f4b0
    // 0x82f49c: r8 = Alignment
    //     0x82f49c: add             x8, PP, #0x82, lsl #12  ; [pp+0x827c0] Type: Alignment
    //     0x82f4a0: ldr             x8, [x8, #0x7c0]
    // 0x82f4a4: r3 = Null
    //     0x82f4a4: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8ef28] Null
    //     0x82f4a8: ldr             x3, [x3, #0xf28]
    // 0x82f4ac: r0 = Alignment()
    //     0x82f4ac: bl              #0x82f6b8  ; IsType_Alignment_Stub
    // 0x82f4b0: ldr             x1, [fp, #0x18]
    // 0x82f4b4: ldr             x2, [fp, #0x10]
    // 0x82f4b8: r0 = +()
    //     0x82f4b8: bl              #0x82f4d0  ; [package:flutter/src/painting/alignment.dart] Alignment::+
    // 0x82f4bc: LeaveFrame
    //     0x82f4bc: mov             SP, fp
    //     0x82f4c0: ldp             fp, lr, [SP], #0x10
    // 0x82f4c4: ret
    //     0x82f4c4: ret             
    // 0x82f4c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f4c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f4cc: b               #0x82f474
  }
  Alignment +(Alignment, Alignment) {
    // ** addr: 0x82f4d0, size: 0x4c
    // 0x82f4d0: EnterFrame
    //     0x82f4d0: stp             fp, lr, [SP, #-0x10]!
    //     0x82f4d4: mov             fp, SP
    // 0x82f4d8: AllocStack(0x10)
    //     0x82f4d8: sub             SP, SP, #0x10
    // 0x82f4dc: LoadField: d0 = r1->field_7
    //     0x82f4dc: ldur            d0, [x1, #7]
    // 0x82f4e0: LoadField: d1 = r2->field_7
    //     0x82f4e0: ldur            d1, [x2, #7]
    // 0x82f4e4: fadd            d2, d0, d1
    // 0x82f4e8: stur            d2, [fp, #-0x10]
    // 0x82f4ec: LoadField: d0 = r1->field_f
    //     0x82f4ec: ldur            d0, [x1, #0xf]
    // 0x82f4f0: LoadField: d1 = r2->field_f
    //     0x82f4f0: ldur            d1, [x2, #0xf]
    // 0x82f4f4: fadd            d3, d0, d1
    // 0x82f4f8: stur            d3, [fp, #-8]
    // 0x82f4fc: r0 = Alignment()
    //     0x82f4fc: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x82f500: ldur            d0, [fp, #-0x10]
    // 0x82f504: StoreField: r0->field_7 = d0
    //     0x82f504: stur            d0, [x0, #7]
    // 0x82f508: ldur            d0, [fp, #-8]
    // 0x82f50c: StoreField: r0->field_f = d0
    //     0x82f50c: stur            d0, [x0, #0xf]
    // 0x82f510: LeaveFrame
    //     0x82f510: mov             SP, fp
    //     0x82f514: ldp             fp, lr, [SP], #0x10
    // 0x82f518: ret
    //     0x82f518: ret             
  }
  Alignment resolve(Alignment, TextDirection?) {
    // ** addr: 0x82f540, size: 0x6c
    // 0x82f540: EnterFrame
    //     0x82f540: stp             fp, lr, [SP, #-0x10]!
    //     0x82f544: mov             fp, SP
    // 0x82f548: ldr             x0, [fp, #0x10]
    // 0x82f54c: r2 = Null
    //     0x82f54c: mov             x2, NULL
    // 0x82f550: r1 = Null
    //     0x82f550: mov             x1, NULL
    // 0x82f554: r4 = 60
    //     0x82f554: mov             x4, #0x3c
    // 0x82f558: branchIfSmi(r0, 0x82f564)
    //     0x82f558: tbz             w0, #0, #0x82f564
    // 0x82f55c: r4 = LoadClassIdInstr(r0)
    //     0x82f55c: ldur            x4, [x0, #-1]
    //     0x82f560: ubfx            x4, x4, #0xc, #0x14
    // 0x82f564: r17 = 8353
    //     0x82f564: mov             x17, #0x20a1
    // 0x82f568: cmp             x4, x17
    // 0x82f56c: b.eq            #0x82f584
    // 0x82f570: r8 = TextDirection?
    //     0x82f570: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0x82f574: ldr             x8, [x8, #0x750]
    // 0x82f578: r3 = Null
    //     0x82f578: add             x3, PP, #0x82, lsl #12  ; [pp+0x827b0] Null
    //     0x82f57c: ldr             x3, [x3, #0x7b0]
    // 0x82f580: r0 = DefaultNullableTypeTest()
    //     0x82f580: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x82f584: ldr             x0, [fp, #0x18]
    // 0x82f588: LeaveFrame
    //     0x82f588: mov             SP, fp
    //     0x82f58c: ldp             fp, lr, [SP], #0x10
    // 0x82f590: ret
    //     0x82f590: ret             
  }
  Alignment *(Alignment, double) {
    // ** addr: 0x82f5ac, size: 0x50
    // 0x82f5ac: EnterFrame
    //     0x82f5ac: stp             fp, lr, [SP, #-0x10]!
    //     0x82f5b0: mov             fp, SP
    // 0x82f5b4: CheckStackOverflow
    //     0x82f5b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f5b8: cmp             SP, x16
    //     0x82f5bc: b.ls            #0x82f5dc
    // 0x82f5c0: ldr             x0, [fp, #0x10]
    // 0x82f5c4: LoadField: d0 = r0->field_7
    //     0x82f5c4: ldur            d0, [x0, #7]
    // 0x82f5c8: ldr             x1, [fp, #0x18]
    // 0x82f5cc: r0 = *()
    //     0x82f5cc: bl              #0x12ffb28  ; [package:flutter/src/painting/alignment.dart] Alignment::*
    // 0x82f5d0: LeaveFrame
    //     0x82f5d0: mov             SP, fp
    //     0x82f5d4: ldp             fp, lr, [SP], #0x10
    // 0x82f5d8: ret
    //     0x82f5d8: ret             
    // 0x82f5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f5dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f5e0: b               #0x82f5c0
  }
  Alignment -(Alignment, Alignment) {
    // ** addr: 0x82f5fc, size: 0x88
    // 0x82f5fc: EnterFrame
    //     0x82f5fc: stp             fp, lr, [SP, #-0x10]!
    //     0x82f600: mov             fp, SP
    // 0x82f604: CheckStackOverflow
    //     0x82f604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f608: cmp             SP, x16
    //     0x82f60c: b.ls            #0x82f664
    // 0x82f610: ldr             x0, [fp, #0x10]
    // 0x82f614: r2 = Null
    //     0x82f614: mov             x2, NULL
    // 0x82f618: r1 = Null
    //     0x82f618: mov             x1, NULL
    // 0x82f61c: r4 = 60
    //     0x82f61c: mov             x4, #0x3c
    // 0x82f620: branchIfSmi(r0, 0x82f62c)
    //     0x82f620: tbz             w0, #0, #0x82f62c
    // 0x82f624: r4 = LoadClassIdInstr(r0)
    //     0x82f624: ldur            x4, [x0, #-1]
    //     0x82f628: ubfx            x4, x4, #0xc, #0x14
    // 0x82f62c: sub             x4, x4, #0xb8e
    // 0x82f630: cmp             x4, #1
    // 0x82f634: b.ls            #0x82f64c
    // 0x82f638: r8 = Alignment
    //     0x82f638: add             x8, PP, #0x82, lsl #12  ; [pp+0x827c0] Type: Alignment
    //     0x82f63c: ldr             x8, [x8, #0x7c0]
    // 0x82f640: r3 = Null
    //     0x82f640: add             x3, PP, #0x82, lsl #12  ; [pp+0x827c8] Null
    //     0x82f644: ldr             x3, [x3, #0x7c8]
    // 0x82f648: r0 = Alignment()
    //     0x82f648: bl              #0x82f6b8  ; IsType_Alignment_Stub
    // 0x82f64c: ldr             x1, [fp, #0x18]
    // 0x82f650: ldr             x2, [fp, #0x10]
    // 0x82f654: r0 = -()
    //     0x82f654: bl              #0x82f66c  ; [package:flutter/src/painting/alignment.dart] Alignment::-
    // 0x82f658: LeaveFrame
    //     0x82f658: mov             SP, fp
    //     0x82f65c: ldp             fp, lr, [SP], #0x10
    // 0x82f660: ret
    //     0x82f660: ret             
    // 0x82f664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f668: b               #0x82f610
  }
  Alignment -(Alignment, Alignment) {
    // ** addr: 0x82f66c, size: 0x4c
    // 0x82f66c: EnterFrame
    //     0x82f66c: stp             fp, lr, [SP, #-0x10]!
    //     0x82f670: mov             fp, SP
    // 0x82f674: AllocStack(0x10)
    //     0x82f674: sub             SP, SP, #0x10
    // 0x82f678: LoadField: d0 = r1->field_7
    //     0x82f678: ldur            d0, [x1, #7]
    // 0x82f67c: LoadField: d1 = r2->field_7
    //     0x82f67c: ldur            d1, [x2, #7]
    // 0x82f680: fsub            d2, d0, d1
    // 0x82f684: stur            d2, [fp, #-0x10]
    // 0x82f688: LoadField: d0 = r1->field_f
    //     0x82f688: ldur            d0, [x1, #0xf]
    // 0x82f68c: LoadField: d1 = r2->field_f
    //     0x82f68c: ldur            d1, [x2, #0xf]
    // 0x82f690: fsub            d3, d0, d1
    // 0x82f694: stur            d3, [fp, #-8]
    // 0x82f698: r0 = Alignment()
    //     0x82f698: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x82f69c: ldur            d0, [fp, #-0x10]
    // 0x82f6a0: StoreField: r0->field_7 = d0
    //     0x82f6a0: stur            d0, [x0, #7]
    // 0x82f6a4: ldur            d0, [fp, #-8]
    // 0x82f6a8: StoreField: r0->field_f = d0
    //     0x82f6a8: stur            d0, [x0, #0xf]
    // 0x82f6ac: LeaveFrame
    //     0x82f6ac: mov             SP, fp
    //     0x82f6b0: ldp             fp, lr, [SP], #0x10
    // 0x82f6b4: ret
    //     0x82f6b4: ret             
  }
  _ alongOffset(/* No info */) {
    // ** addr: 0xb5f054, size: 0x60
    // 0xb5f054: EnterFrame
    //     0xb5f054: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f058: mov             fp, SP
    // 0xb5f05c: AllocStack(0x10)
    //     0xb5f05c: sub             SP, SP, #0x10
    // 0xb5f060: d0 = 2.000000
    //     0xb5f060: fmov            d0, #2.00000000
    // 0xb5f064: LoadField: d1 = r2->field_7
    //     0xb5f064: ldur            d1, [x2, #7]
    // 0xb5f068: fdiv            d2, d1, d0
    // 0xb5f06c: LoadField: d1 = r2->field_f
    //     0xb5f06c: ldur            d1, [x2, #0xf]
    // 0xb5f070: fdiv            d3, d1, d0
    // 0xb5f074: LoadField: d0 = r1->field_7
    //     0xb5f074: ldur            d0, [x1, #7]
    // 0xb5f078: fmul            d1, d0, d2
    // 0xb5f07c: fadd            d0, d2, d1
    // 0xb5f080: stur            d0, [fp, #-0x10]
    // 0xb5f084: LoadField: d1 = r1->field_f
    //     0xb5f084: ldur            d1, [x1, #0xf]
    // 0xb5f088: fmul            d2, d1, d3
    // 0xb5f08c: fadd            d1, d3, d2
    // 0xb5f090: stur            d1, [fp, #-8]
    // 0xb5f094: r0 = Offset()
    //     0xb5f094: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb5f098: ldur            d0, [fp, #-0x10]
    // 0xb5f09c: StoreField: r0->field_7 = d0
    //     0xb5f09c: stur            d0, [x0, #7]
    // 0xb5f0a0: ldur            d0, [fp, #-8]
    // 0xb5f0a4: StoreField: r0->field_f = d0
    //     0xb5f0a4: stur            d0, [x0, #0xf]
    // 0xb5f0a8: LeaveFrame
    //     0xb5f0a8: mov             SP, fp
    //     0xb5f0ac: ldp             fp, lr, [SP], #0x10
    // 0xb5f0b0: ret
    //     0xb5f0b0: ret             
  }
  _ inscribe(/* No info */) {
    // ** addr: 0xb7da30, size: 0xa8
    // 0xb7da30: EnterFrame
    //     0xb7da30: stp             fp, lr, [SP, #-0x10]!
    //     0xb7da34: mov             fp, SP
    // 0xb7da38: AllocStack(0x20)
    //     0xb7da38: sub             SP, SP, #0x20
    // 0xb7da3c: d0 = 2.000000
    //     0xb7da3c: fmov            d0, #2.00000000
    // 0xb7da40: ArrayLoad: d1 = r3[0]  ; List_8
    //     0xb7da40: ldur            d1, [x3, #0x17]
    // 0xb7da44: LoadField: d2 = r3->field_7
    //     0xb7da44: ldur            d2, [x3, #7]
    // 0xb7da48: fsub            d3, d1, d2
    // 0xb7da4c: LoadField: d1 = r2->field_7
    //     0xb7da4c: ldur            d1, [x2, #7]
    // 0xb7da50: fsub            d4, d3, d1
    // 0xb7da54: fdiv            d3, d4, d0
    // 0xb7da58: LoadField: d4 = r3->field_1f
    //     0xb7da58: ldur            d4, [x3, #0x1f]
    // 0xb7da5c: LoadField: d5 = r3->field_f
    //     0xb7da5c: ldur            d5, [x3, #0xf]
    // 0xb7da60: fsub            d6, d4, d5
    // 0xb7da64: LoadField: d4 = r2->field_f
    //     0xb7da64: ldur            d4, [x2, #0xf]
    // 0xb7da68: fsub            d7, d6, d4
    // 0xb7da6c: fdiv            d6, d7, d0
    // 0xb7da70: fadd            d0, d2, d3
    // 0xb7da74: LoadField: d2 = r1->field_7
    //     0xb7da74: ldur            d2, [x1, #7]
    // 0xb7da78: fmul            d7, d2, d3
    // 0xb7da7c: fadd            d2, d0, d7
    // 0xb7da80: stur            d2, [fp, #-0x20]
    // 0xb7da84: fadd            d0, d5, d6
    // 0xb7da88: LoadField: d3 = r1->field_f
    //     0xb7da88: ldur            d3, [x1, #0xf]
    // 0xb7da8c: fmul            d5, d3, d6
    // 0xb7da90: fadd            d3, d0, d5
    // 0xb7da94: stur            d3, [fp, #-0x18]
    // 0xb7da98: fadd            d0, d2, d1
    // 0xb7da9c: stur            d0, [fp, #-0x10]
    // 0xb7daa0: fadd            d1, d3, d4
    // 0xb7daa4: stur            d1, [fp, #-8]
    // 0xb7daa8: r0 = Rect()
    //     0xb7daa8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7daac: ldur            d0, [fp, #-0x20]
    // 0xb7dab0: StoreField: r0->field_7 = d0
    //     0xb7dab0: stur            d0, [x0, #7]
    // 0xb7dab4: ldur            d0, [fp, #-0x18]
    // 0xb7dab8: StoreField: r0->field_f = d0
    //     0xb7dab8: stur            d0, [x0, #0xf]
    // 0xb7dabc: ldur            d0, [fp, #-0x10]
    // 0xb7dac0: ArrayStore: r0[0] = d0  ; List_8
    //     0xb7dac0: stur            d0, [x0, #0x17]
    // 0xb7dac4: ldur            d0, [fp, #-8]
    // 0xb7dac8: StoreField: r0->field_1f = d0
    //     0xb7dac8: stur            d0, [x0, #0x1f]
    // 0xb7dacc: LeaveFrame
    //     0xb7dacc: mov             SP, fp
    //     0xb7dad0: ldp             fp, lr, [SP], #0x10
    // 0xb7dad4: ret
    //     0xb7dad4: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1161598, size: 0x4c8
    // 0x1161598: EnterFrame
    //     0x1161598: stp             fp, lr, [SP, #-0x10]!
    //     0x116159c: mov             fp, SP
    // 0x11615a0: AllocStack(0x28)
    //     0x11615a0: sub             SP, SP, #0x28
    // 0x11615a4: SetupParameters(dynamic _ /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x11615a4: mov             x4, x1
    //     0x11615a8: mov             x0, x2
    //     0x11615ac: stur            x2, [fp, #-0x10]
    //     0x11615b0: stur            x1, [fp, #-0x20]
    // 0x11615b4: CheckStackOverflow
    //     0x11615b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11615b8: cmp             SP, x16
    //     0x11615bc: b.ls            #0x116190c
    // 0x11615c0: cmp             w4, w0
    // 0x11615c4: b.ne            #0x11615d8
    // 0x11615c8: mov             x0, x4
    // 0x11615cc: LeaveFrame
    //     0x11615cc: mov             SP, fp
    //     0x11615d0: ldp             fp, lr, [SP], #0x10
    // 0x11615d4: ret
    //     0x11615d4: ret             
    // 0x11615d8: cmp             w4, NULL
    // 0x11615dc: b.ne            #0x11616d4
    // 0x11615e0: cmp             w0, NULL
    // 0x11615e4: b.eq            #0x1161914
    // 0x11615e8: LoadField: d1 = r0->field_7
    //     0x11615e8: ldur            d1, [x0, #7]
    // 0x11615ec: r4 = inline_Allocate_Double()
    //     0x11615ec: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0x11615f0: add             x4, x4, #0x10
    //     0x11615f4: cmp             x1, x4
    //     0x11615f8: b.ls            #0x1161918
    //     0x11615fc: str             x4, [THR, #0x60]  ; THR::top
    //     0x1161600: sub             x4, x4, #0xf
    //     0x1161604: mov             x1, #0xe19c
    //     0x1161608: movk            x1, #3, lsl #16
    //     0x116160c: stur            x1, [x4, #-1]
    // 0x1161610: dmb             ishst
    // 0x1161614: StoreField: r4->field_7 = d0
    //     0x1161614: stur            d0, [x4, #7]
    // 0x1161618: stur            x4, [fp, #-8]
    // 0x116161c: r2 = inline_Allocate_Double()
    //     0x116161c: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x1161620: add             x2, x2, #0x10
    //     0x1161624: cmp             x1, x2
    //     0x1161628: b.ls            #0x1161934
    //     0x116162c: str             x2, [THR, #0x60]  ; THR::top
    //     0x1161630: sub             x2, x2, #0xf
    //     0x1161634: mov             x1, #0xe19c
    //     0x1161638: movk            x1, #3, lsl #16
    //     0x116163c: stur            x1, [x2, #-1]
    // 0x1161640: dmb             ishst
    // 0x1161644: StoreField: r2->field_7 = d1
    //     0x1161644: stur            d1, [x2, #7]
    // 0x1161648: mov             x3, x4
    // 0x116164c: r1 = 0.000000
    //     0x116164c: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1161650: r0 = lerpDouble()
    //     0x1161650: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1161654: mov             x4, x0
    // 0x1161658: ldur            x0, [fp, #-0x10]
    // 0x116165c: stur            x4, [fp, #-0x18]
    // 0x1161660: LoadField: d0 = r0->field_f
    //     0x1161660: ldur            d0, [x0, #0xf]
    // 0x1161664: r2 = inline_Allocate_Double()
    //     0x1161664: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1161668: add             x2, x2, #0x10
    //     0x116166c: cmp             x0, x2
    //     0x1161670: b.ls            #0x1161950
    //     0x1161674: str             x2, [THR, #0x60]  ; THR::top
    //     0x1161678: sub             x2, x2, #0xf
    //     0x116167c: mov             x0, #0xe19c
    //     0x1161680: movk            x0, #3, lsl #16
    //     0x1161684: stur            x0, [x2, #-1]
    // 0x1161688: dmb             ishst
    // 0x116168c: StoreField: r2->field_7 = d0
    //     0x116168c: stur            d0, [x2, #7]
    // 0x1161690: ldur            x3, [fp, #-8]
    // 0x1161694: r1 = 0.000000
    //     0x1161694: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1161698: r0 = lerpDouble()
    //     0x1161698: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116169c: mov             x1, x0
    // 0x11616a0: ldur            x0, [fp, #-0x18]
    // 0x11616a4: stur            x1, [fp, #-8]
    // 0x11616a8: LoadField: d0 = r0->field_7
    //     0x11616a8: ldur            d0, [x0, #7]
    // 0x11616ac: stur            d0, [fp, #-0x28]
    // 0x11616b0: r0 = Alignment()
    //     0x11616b0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x11616b4: ldur            d0, [fp, #-0x28]
    // 0x11616b8: StoreField: r0->field_7 = d0
    //     0x11616b8: stur            d0, [x0, #7]
    // 0x11616bc: ldur            x1, [fp, #-8]
    // 0x11616c0: LoadField: d0 = r1->field_7
    //     0x11616c0: ldur            d0, [x1, #7]
    // 0x11616c4: StoreField: r0->field_f = d0
    //     0x11616c4: stur            d0, [x0, #0xf]
    // 0x11616c8: LeaveFrame
    //     0x11616c8: mov             SP, fp
    //     0x11616cc: ldp             fp, lr, [SP], #0x10
    // 0x11616d0: ret
    //     0x11616d0: ret             
    // 0x11616d4: cmp             w0, NULL
    // 0x11616d8: b.ne            #0x11617c4
    // 0x11616dc: LoadField: d1 = r4->field_7
    //     0x11616dc: ldur            d1, [x4, #7]
    // 0x11616e0: r0 = inline_Allocate_Double()
    //     0x11616e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x11616e4: add             x0, x0, #0x10
    //     0x11616e8: cmp             x1, x0
    //     0x11616ec: b.ls            #0x116196c
    //     0x11616f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x11616f4: sub             x0, x0, #0xf
    //     0x11616f8: mov             x1, #0xe19c
    //     0x11616fc: movk            x1, #3, lsl #16
    //     0x1161700: stur            x1, [x0, #-1]
    // 0x1161704: dmb             ishst
    // 0x1161708: StoreField: r0->field_7 = d0
    //     0x1161708: stur            d0, [x0, #7]
    // 0x116170c: stur            x0, [fp, #-8]
    // 0x1161710: r1 = inline_Allocate_Double()
    //     0x1161710: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1161714: add             x1, x1, #0x10
    //     0x1161718: cmp             x2, x1
    //     0x116171c: b.ls            #0x1161984
    //     0x1161720: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161724: sub             x1, x1, #0xf
    //     0x1161728: mov             x2, #0xe19c
    //     0x116172c: movk            x2, #3, lsl #16
    //     0x1161730: stur            x2, [x1, #-1]
    // 0x1161734: dmb             ishst
    // 0x1161738: StoreField: r1->field_7 = d1
    //     0x1161738: stur            d1, [x1, #7]
    // 0x116173c: mov             x3, x0
    // 0x1161740: r2 = 0.000000
    //     0x1161740: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1161744: r0 = lerpDouble()
    //     0x1161744: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1161748: ldur            x4, [fp, #-0x20]
    // 0x116174c: stur            x0, [fp, #-0x18]
    // 0x1161750: LoadField: d0 = r4->field_f
    //     0x1161750: ldur            d0, [x4, #0xf]
    // 0x1161754: r1 = inline_Allocate_Double()
    //     0x1161754: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1161758: add             x1, x1, #0x10
    //     0x116175c: cmp             x2, x1
    //     0x1161760: b.ls            #0x11619a0
    //     0x1161764: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161768: sub             x1, x1, #0xf
    //     0x116176c: mov             x2, #0xe19c
    //     0x1161770: movk            x2, #3, lsl #16
    //     0x1161774: stur            x2, [x1, #-1]
    // 0x1161778: dmb             ishst
    // 0x116177c: StoreField: r1->field_7 = d0
    //     0x116177c: stur            d0, [x1, #7]
    // 0x1161780: ldur            x3, [fp, #-8]
    // 0x1161784: r2 = 0.000000
    //     0x1161784: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1161788: r0 = lerpDouble()
    //     0x1161788: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116178c: mov             x1, x0
    // 0x1161790: ldur            x0, [fp, #-0x18]
    // 0x1161794: stur            x1, [fp, #-8]
    // 0x1161798: LoadField: d0 = r0->field_7
    //     0x1161798: ldur            d0, [x0, #7]
    // 0x116179c: stur            d0, [fp, #-0x28]
    // 0x11617a0: r0 = Alignment()
    //     0x11617a0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x11617a4: ldur            d0, [fp, #-0x28]
    // 0x11617a8: StoreField: r0->field_7 = d0
    //     0x11617a8: stur            d0, [x0, #7]
    // 0x11617ac: ldur            x1, [fp, #-8]
    // 0x11617b0: LoadField: d0 = r1->field_7
    //     0x11617b0: ldur            d0, [x1, #7]
    // 0x11617b4: StoreField: r0->field_f = d0
    //     0x11617b4: stur            d0, [x0, #0xf]
    // 0x11617b8: LeaveFrame
    //     0x11617b8: mov             SP, fp
    //     0x11617bc: ldp             fp, lr, [SP], #0x10
    // 0x11617c0: ret
    //     0x11617c0: ret             
    // 0x11617c4: LoadField: d1 = r4->field_7
    //     0x11617c4: ldur            d1, [x4, #7]
    // 0x11617c8: LoadField: d2 = r0->field_7
    //     0x11617c8: ldur            d2, [x0, #7]
    // 0x11617cc: r5 = inline_Allocate_Double()
    //     0x11617cc: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11617d0: add             x5, x5, #0x10
    //     0x11617d4: cmp             x1, x5
    //     0x11617d8: b.ls            #0x11619bc
    //     0x11617dc: str             x5, [THR, #0x60]  ; THR::top
    //     0x11617e0: sub             x5, x5, #0xf
    //     0x11617e4: mov             x1, #0xe19c
    //     0x11617e8: movk            x1, #3, lsl #16
    //     0x11617ec: stur            x1, [x5, #-1]
    // 0x11617f0: dmb             ishst
    // 0x11617f4: StoreField: r5->field_7 = d0
    //     0x11617f4: stur            d0, [x5, #7]
    // 0x11617f8: stur            x5, [fp, #-8]
    // 0x11617fc: r1 = inline_Allocate_Double()
    //     0x11617fc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1161800: add             x1, x1, #0x10
    //     0x1161804: cmp             x2, x1
    //     0x1161808: b.ls            #0x11619e0
    //     0x116180c: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161810: sub             x1, x1, #0xf
    //     0x1161814: mov             x2, #0xe19c
    //     0x1161818: movk            x2, #3, lsl #16
    //     0x116181c: stur            x2, [x1, #-1]
    // 0x1161820: dmb             ishst
    // 0x1161824: StoreField: r1->field_7 = d1
    //     0x1161824: stur            d1, [x1, #7]
    // 0x1161828: r2 = inline_Allocate_Double()
    //     0x1161828: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x116182c: add             x2, x2, #0x10
    //     0x1161830: cmp             x3, x2
    //     0x1161834: b.ls            #0x1161a04
    //     0x1161838: str             x2, [THR, #0x60]  ; THR::top
    //     0x116183c: sub             x2, x2, #0xf
    //     0x1161840: mov             x3, #0xe19c
    //     0x1161844: movk            x3, #3, lsl #16
    //     0x1161848: stur            x3, [x2, #-1]
    // 0x116184c: dmb             ishst
    // 0x1161850: StoreField: r2->field_7 = d2
    //     0x1161850: stur            d2, [x2, #7]
    // 0x1161854: mov             x3, x5
    // 0x1161858: r0 = lerpDouble()
    //     0x1161858: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116185c: mov             x4, x0
    // 0x1161860: ldur            x0, [fp, #-0x20]
    // 0x1161864: stur            x4, [fp, #-0x18]
    // 0x1161868: LoadField: d0 = r0->field_f
    //     0x1161868: ldur            d0, [x0, #0xf]
    // 0x116186c: ldur            x0, [fp, #-0x10]
    // 0x1161870: LoadField: d1 = r0->field_f
    //     0x1161870: ldur            d1, [x0, #0xf]
    // 0x1161874: r1 = inline_Allocate_Double()
    //     0x1161874: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x1161878: add             x1, x1, #0x10
    //     0x116187c: cmp             x0, x1
    //     0x1161880: b.ls            #0x1161a28
    //     0x1161884: str             x1, [THR, #0x60]  ; THR::top
    //     0x1161888: sub             x1, x1, #0xf
    //     0x116188c: mov             x0, #0xe19c
    //     0x1161890: movk            x0, #3, lsl #16
    //     0x1161894: stur            x0, [x1, #-1]
    // 0x1161898: dmb             ishst
    // 0x116189c: StoreField: r1->field_7 = d0
    //     0x116189c: stur            d0, [x1, #7]
    // 0x11618a0: r2 = inline_Allocate_Double()
    //     0x11618a0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11618a4: add             x2, x2, #0x10
    //     0x11618a8: cmp             x0, x2
    //     0x11618ac: b.ls            #0x1161a44
    //     0x11618b0: str             x2, [THR, #0x60]  ; THR::top
    //     0x11618b4: sub             x2, x2, #0xf
    //     0x11618b8: mov             x0, #0xe19c
    //     0x11618bc: movk            x0, #3, lsl #16
    //     0x11618c0: stur            x0, [x2, #-1]
    // 0x11618c4: dmb             ishst
    // 0x11618c8: StoreField: r2->field_7 = d1
    //     0x11618c8: stur            d1, [x2, #7]
    // 0x11618cc: ldur            x3, [fp, #-8]
    // 0x11618d0: r0 = lerpDouble()
    //     0x11618d0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11618d4: mov             x1, x0
    // 0x11618d8: ldur            x0, [fp, #-0x18]
    // 0x11618dc: stur            x1, [fp, #-8]
    // 0x11618e0: LoadField: d0 = r0->field_7
    //     0x11618e0: ldur            d0, [x0, #7]
    // 0x11618e4: stur            d0, [fp, #-0x28]
    // 0x11618e8: r0 = Alignment()
    //     0x11618e8: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x11618ec: ldur            d0, [fp, #-0x28]
    // 0x11618f0: StoreField: r0->field_7 = d0
    //     0x11618f0: stur            d0, [x0, #7]
    // 0x11618f4: ldur            x1, [fp, #-8]
    // 0x11618f8: LoadField: d0 = r1->field_7
    //     0x11618f8: ldur            d0, [x1, #7]
    // 0x11618fc: StoreField: r0->field_f = d0
    //     0x11618fc: stur            d0, [x0, #0xf]
    // 0x1161900: LeaveFrame
    //     0x1161900: mov             SP, fp
    //     0x1161904: ldp             fp, lr, [SP], #0x10
    // 0x1161908: ret
    //     0x1161908: ret             
    // 0x116190c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116190c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1161910: b               #0x11615c0
    // 0x1161914: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1161914: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1161918: stp             q0, q1, [SP, #-0x20]!
    // 0x116191c: SaveReg r0
    //     0x116191c: str             x0, [SP, #-8]!
    // 0x1161920: r0 = AllocateDouble()
    //     0x1161920: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161924: mov             x4, x0
    // 0x1161928: RestoreReg r0
    //     0x1161928: ldr             x0, [SP], #8
    // 0x116192c: ldp             q0, q1, [SP], #0x20
    // 0x1161930: b               #0x1161614
    // 0x1161934: SaveReg d1
    //     0x1161934: str             q1, [SP, #-0x10]!
    // 0x1161938: stp             x0, x4, [SP, #-0x10]!
    // 0x116193c: r0 = AllocateDouble()
    //     0x116193c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161940: mov             x2, x0
    // 0x1161944: ldp             x0, x4, [SP], #0x10
    // 0x1161948: RestoreReg d1
    //     0x1161948: ldr             q1, [SP], #0x10
    // 0x116194c: b               #0x1161644
    // 0x1161950: SaveReg d0
    //     0x1161950: str             q0, [SP, #-0x10]!
    // 0x1161954: SaveReg r4
    //     0x1161954: str             x4, [SP, #-8]!
    // 0x1161958: r0 = AllocateDouble()
    //     0x1161958: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116195c: mov             x2, x0
    // 0x1161960: RestoreReg r4
    //     0x1161960: ldr             x4, [SP], #8
    // 0x1161964: RestoreReg d0
    //     0x1161964: ldr             q0, [SP], #0x10
    // 0x1161968: b               #0x116168c
    // 0x116196c: stp             q0, q1, [SP, #-0x20]!
    // 0x1161970: SaveReg r4
    //     0x1161970: str             x4, [SP, #-8]!
    // 0x1161974: r0 = AllocateDouble()
    //     0x1161974: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161978: RestoreReg r4
    //     0x1161978: ldr             x4, [SP], #8
    // 0x116197c: ldp             q0, q1, [SP], #0x20
    // 0x1161980: b               #0x1161708
    // 0x1161984: SaveReg d1
    //     0x1161984: str             q1, [SP, #-0x10]!
    // 0x1161988: stp             x0, x4, [SP, #-0x10]!
    // 0x116198c: r0 = AllocateDouble()
    //     0x116198c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161990: mov             x1, x0
    // 0x1161994: ldp             x0, x4, [SP], #0x10
    // 0x1161998: RestoreReg d1
    //     0x1161998: ldr             q1, [SP], #0x10
    // 0x116199c: b               #0x1161738
    // 0x11619a0: SaveReg d0
    //     0x11619a0: str             q0, [SP, #-0x10]!
    // 0x11619a4: SaveReg r0
    //     0x11619a4: str             x0, [SP, #-8]!
    // 0x11619a8: r0 = AllocateDouble()
    //     0x11619a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11619ac: mov             x1, x0
    // 0x11619b0: RestoreReg r0
    //     0x11619b0: ldr             x0, [SP], #8
    // 0x11619b4: RestoreReg d0
    //     0x11619b4: ldr             q0, [SP], #0x10
    // 0x11619b8: b               #0x116177c
    // 0x11619bc: stp             q1, q2, [SP, #-0x20]!
    // 0x11619c0: SaveReg d0
    //     0x11619c0: str             q0, [SP, #-0x10]!
    // 0x11619c4: stp             x0, x4, [SP, #-0x10]!
    // 0x11619c8: r0 = AllocateDouble()
    //     0x11619c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11619cc: mov             x5, x0
    // 0x11619d0: ldp             x0, x4, [SP], #0x10
    // 0x11619d4: RestoreReg d0
    //     0x11619d4: ldr             q0, [SP], #0x10
    // 0x11619d8: ldp             q1, q2, [SP], #0x20
    // 0x11619dc: b               #0x11617f4
    // 0x11619e0: stp             q1, q2, [SP, #-0x20]!
    // 0x11619e4: stp             x4, x5, [SP, #-0x10]!
    // 0x11619e8: SaveReg r0
    //     0x11619e8: str             x0, [SP, #-8]!
    // 0x11619ec: r0 = AllocateDouble()
    //     0x11619ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11619f0: mov             x1, x0
    // 0x11619f4: RestoreReg r0
    //     0x11619f4: ldr             x0, [SP], #8
    // 0x11619f8: ldp             x4, x5, [SP], #0x10
    // 0x11619fc: ldp             q1, q2, [SP], #0x20
    // 0x1161a00: b               #0x1161824
    // 0x1161a04: SaveReg d2
    //     0x1161a04: str             q2, [SP, #-0x10]!
    // 0x1161a08: stp             x4, x5, [SP, #-0x10]!
    // 0x1161a0c: stp             x0, x1, [SP, #-0x10]!
    // 0x1161a10: r0 = AllocateDouble()
    //     0x1161a10: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161a14: mov             x2, x0
    // 0x1161a18: ldp             x0, x1, [SP], #0x10
    // 0x1161a1c: ldp             x4, x5, [SP], #0x10
    // 0x1161a20: RestoreReg d2
    //     0x1161a20: ldr             q2, [SP], #0x10
    // 0x1161a24: b               #0x1161850
    // 0x1161a28: stp             q0, q1, [SP, #-0x20]!
    // 0x1161a2c: SaveReg r4
    //     0x1161a2c: str             x4, [SP, #-8]!
    // 0x1161a30: r0 = AllocateDouble()
    //     0x1161a30: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161a34: mov             x1, x0
    // 0x1161a38: RestoreReg r4
    //     0x1161a38: ldr             x4, [SP], #8
    // 0x1161a3c: ldp             q0, q1, [SP], #0x20
    // 0x1161a40: b               #0x116189c
    // 0x1161a44: SaveReg d1
    //     0x1161a44: str             q1, [SP, #-0x10]!
    // 0x1161a48: stp             x1, x4, [SP, #-0x10]!
    // 0x1161a4c: r0 = AllocateDouble()
    //     0x1161a4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1161a50: mov             x2, x0
    // 0x1161a54: ldp             x1, x4, [SP], #0x10
    // 0x1161a58: RestoreReg d1
    //     0x1161a58: ldr             q1, [SP], #0x10
    // 0x1161a5c: b               #0x11618c8
  }
  _ withinRect(/* No info */) {
    // ** addr: 0x12f7c84, size: 0x78
    // 0x12f7c84: EnterFrame
    //     0x12f7c84: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7c88: mov             fp, SP
    // 0x12f7c8c: AllocStack(0x10)
    //     0x12f7c8c: sub             SP, SP, #0x10
    // 0x12f7c90: d0 = 2.000000
    //     0x12f7c90: fmov            d0, #2.00000000
    // 0x12f7c94: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x12f7c94: ldur            d1, [x2, #0x17]
    // 0x12f7c98: LoadField: d2 = r2->field_7
    //     0x12f7c98: ldur            d2, [x2, #7]
    // 0x12f7c9c: fsub            d3, d1, d2
    // 0x12f7ca0: fdiv            d1, d3, d0
    // 0x12f7ca4: LoadField: d3 = r2->field_1f
    //     0x12f7ca4: ldur            d3, [x2, #0x1f]
    // 0x12f7ca8: LoadField: d4 = r2->field_f
    //     0x12f7ca8: ldur            d4, [x2, #0xf]
    // 0x12f7cac: fsub            d5, d3, d4
    // 0x12f7cb0: fdiv            d3, d5, d0
    // 0x12f7cb4: fadd            d0, d2, d1
    // 0x12f7cb8: LoadField: d2 = r1->field_7
    //     0x12f7cb8: ldur            d2, [x1, #7]
    // 0x12f7cbc: fmul            d5, d2, d1
    // 0x12f7cc0: fadd            d1, d0, d5
    // 0x12f7cc4: stur            d1, [fp, #-0x10]
    // 0x12f7cc8: fadd            d0, d4, d3
    // 0x12f7ccc: LoadField: d2 = r1->field_f
    //     0x12f7ccc: ldur            d2, [x1, #0xf]
    // 0x12f7cd0: fmul            d4, d2, d3
    // 0x12f7cd4: fadd            d2, d0, d4
    // 0x12f7cd8: stur            d2, [fp, #-8]
    // 0x12f7cdc: r0 = Offset()
    //     0x12f7cdc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f7ce0: ldur            d0, [fp, #-0x10]
    // 0x12f7ce4: StoreField: r0->field_7 = d0
    //     0x12f7ce4: stur            d0, [x0, #7]
    // 0x12f7ce8: ldur            d0, [fp, #-8]
    // 0x12f7cec: StoreField: r0->field_f = d0
    //     0x12f7cec: stur            d0, [x0, #0xf]
    // 0x12f7cf0: LeaveFrame
    //     0x12f7cf0: mov             SP, fp
    //     0x12f7cf4: ldp             fp, lr, [SP], #0x10
    // 0x12f7cf8: ret
    //     0x12f7cf8: ret             
  }
  Alignment *(Alignment, double) {
    // ** addr: 0x12ffb28, size: 0x44
    // 0x12ffb28: EnterFrame
    //     0x12ffb28: stp             fp, lr, [SP, #-0x10]!
    //     0x12ffb2c: mov             fp, SP
    // 0x12ffb30: AllocStack(0x10)
    //     0x12ffb30: sub             SP, SP, #0x10
    // 0x12ffb34: LoadField: d1 = r1->field_7
    //     0x12ffb34: ldur            d1, [x1, #7]
    // 0x12ffb38: fmul            d2, d1, d0
    // 0x12ffb3c: stur            d2, [fp, #-0x10]
    // 0x12ffb40: LoadField: d1 = r1->field_f
    //     0x12ffb40: ldur            d1, [x1, #0xf]
    // 0x12ffb44: fmul            d3, d1, d0
    // 0x12ffb48: stur            d3, [fp, #-8]
    // 0x12ffb4c: r0 = Alignment()
    //     0x12ffb4c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x12ffb50: ldur            d0, [fp, #-0x10]
    // 0x12ffb54: StoreField: r0->field_7 = d0
    //     0x12ffb54: stur            d0, [x0, #7]
    // 0x12ffb58: ldur            d0, [fp, #-8]
    // 0x12ffb5c: StoreField: r0->field_f = d0
    //     0x12ffb5c: stur            d0, [x0, #0xf]
    // 0x12ffb60: LeaveFrame
    //     0x12ffb60: mov             SP, fp
    //     0x12ffb64: ldp             fp, lr, [SP], #0x10
    // 0x12ffb68: ret
    //     0x12ffb68: ret             
  }
}
