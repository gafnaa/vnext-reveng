// lib: , url: package:flutter/src/painting/placeholder_span.dart

// class id: 1049004, size: 0x8
class :: {
}

// class id: 5789, size: 0x14, field offset: 0xc
//   const constructor, 
abstract class PlaceholderSpan extends InlineSpan {

  _ computeSemanticsInformation(/* No info */) {
    // ** addr: 0x125ed68, size: 0xcc
    // 0x125ed68: EnterFrame
    //     0x125ed68: stp             fp, lr, [SP, #-0x10]!
    //     0x125ed6c: mov             fp, SP
    // 0x125ed70: AllocStack(0x10)
    //     0x125ed70: sub             SP, SP, #0x10
    // 0x125ed74: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x125ed74: mov             x3, x2
    //     0x125ed78: stur            x2, [fp, #-8]
    // 0x125ed7c: CheckStackOverflow
    //     0x125ed7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125ed80: cmp             SP, x16
    //     0x125ed84: b.ls            #0x125ee2c
    // 0x125ed88: LoadField: r2 = r3->field_7
    //     0x125ed88: ldur            w2, [x3, #7]
    // 0x125ed8c: DecompressPointer r2
    //     0x125ed8c: add             x2, x2, HEAP, lsl #32
    // 0x125ed90: r0 = Instance_InlineSpanSemanticsInformation
    //     0x125ed90: add             x0, PP, #0x98, lsl #12  ; [pp+0x98908] Obj!InlineSpanSemanticsInformation@129c6b1
    //     0x125ed94: ldr             x0, [x0, #0x908]
    // 0x125ed98: r1 = Null
    //     0x125ed98: mov             x1, NULL
    // 0x125ed9c: cmp             w2, NULL
    // 0x125eda0: b.eq            #0x125edc0
    // 0x125eda4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x125eda4: ldur            w4, [x2, #0x17]
    // 0x125eda8: DecompressPointer r4
    //     0x125eda8: add             x4, x4, HEAP, lsl #32
    // 0x125edac: r8 = X0
    //     0x125edac: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x125edb0: LoadField: r9 = r4->field_7
    //     0x125edb0: ldur            x9, [x4, #7]
    // 0x125edb4: r3 = Null
    //     0x125edb4: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0d70] Null
    //     0x125edb8: ldr             x3, [x3, #0xd70]
    // 0x125edbc: blr             x9
    // 0x125edc0: ldur            x0, [fp, #-8]
    // 0x125edc4: LoadField: r1 = r0->field_b
    //     0x125edc4: ldur            w1, [x0, #0xb]
    // 0x125edc8: LoadField: r2 = r0->field_f
    //     0x125edc8: ldur            w2, [x0, #0xf]
    // 0x125edcc: DecompressPointer r2
    //     0x125edcc: add             x2, x2, HEAP, lsl #32
    // 0x125edd0: LoadField: r3 = r2->field_b
    //     0x125edd0: ldur            w3, [x2, #0xb]
    // 0x125edd4: r2 = LoadInt32Instr(r1)
    //     0x125edd4: sbfx            x2, x1, #1, #0x1f
    // 0x125edd8: stur            x2, [fp, #-0x10]
    // 0x125eddc: r1 = LoadInt32Instr(r3)
    //     0x125eddc: sbfx            x1, x3, #1, #0x1f
    // 0x125ede0: cmp             x2, x1
    // 0x125ede4: b.ne            #0x125edf0
    // 0x125ede8: mov             x1, x0
    // 0x125edec: r0 = _growToNextCapacity()
    //     0x125edec: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125edf0: ldur            x1, [fp, #-8]
    // 0x125edf4: ldur            x2, [fp, #-0x10]
    // 0x125edf8: add             x3, x2, #1
    // 0x125edfc: lsl             x4, x3, #1
    // 0x125ee00: StoreField: r1->field_b = r4
    //     0x125ee00: stur            w4, [x1, #0xb]
    // 0x125ee04: LoadField: r3 = r1->field_f
    //     0x125ee04: ldur            w3, [x1, #0xf]
    // 0x125ee08: DecompressPointer r3
    //     0x125ee08: add             x3, x3, HEAP, lsl #32
    // 0x125ee0c: add             x1, x3, x2, lsl #2
    // 0x125ee10: r16 = Instance_InlineSpanSemanticsInformation
    //     0x125ee10: add             x16, PP, #0x98, lsl #12  ; [pp+0x98908] Obj!InlineSpanSemanticsInformation@129c6b1
    //     0x125ee14: ldr             x16, [x16, #0x908]
    // 0x125ee18: StoreField: r1->field_f = r16
    //     0x125ee18: stur            w16, [x1, #0xf]
    // 0x125ee1c: r0 = Null
    //     0x125ee1c: mov             x0, NULL
    // 0x125ee20: LeaveFrame
    //     0x125ee20: mov             SP, fp
    //     0x125ee24: ldp             fp, lr, [SP], #0x10
    // 0x125ee28: ret
    //     0x125ee28: ret             
    // 0x125ee2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125ee2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125ee30: b               #0x125ed88
  }
  _ computeToPlainText(/* No info */) {
    // ** addr: 0x1261598, size: 0x3c
    // 0x1261598: EnterFrame
    //     0x1261598: stp             fp, lr, [SP, #-0x10]!
    //     0x126159c: mov             fp, SP
    // 0x12615a0: mov             x0, x1
    // 0x12615a4: mov             x1, x2
    // 0x12615a8: CheckStackOverflow
    //     0x12615a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12615ac: cmp             SP, x16
    //     0x12615b0: b.ls            #0x12615cc
    // 0x12615b4: r2 = 65532
    //     0x12615b4: mov             x2, #0xfffc
    // 0x12615b8: r0 = writeCharCode()
    //     0x12615b8: bl              #0x7e69f0  ; [dart:core] StringBuffer::writeCharCode
    // 0x12615bc: r0 = Null
    //     0x12615bc: mov             x0, NULL
    // 0x12615c0: LeaveFrame
    //     0x12615c0: mov             SP, fp
    //     0x12615c4: ldp             fp, lr, [SP], #0x10
    // 0x12615c8: ret
    //     0x12615c8: ret             
    // 0x12615cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12615cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12615d0: b               #0x12615b4
  }
}
