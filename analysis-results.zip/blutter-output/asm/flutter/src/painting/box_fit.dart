// lib: , url: package:flutter/src/painting/box_fit.dart

// class id: 1048985, size: 0x8
class :: {

  static _ applyBoxFit(/* No info */) {
    // ** addr: 0xb8aba4, size: 0x314
    // 0xb8aba4: EnterFrame
    //     0xb8aba4: stp             fp, lr, [SP, #-0x10]!
    //     0xb8aba8: mov             fp, SP
    // 0xb8abac: AllocStack(0x40)
    //     0xb8abac: sub             SP, SP, #0x40
    // 0xb8abb0: d0 = 0.000000
    //     0xb8abb0: eor             v0.16b, v0.16b, v0.16b
    // 0xb8abb4: stur            x2, [fp, #-8]
    // 0xb8abb8: stur            x3, [fp, #-0x10]
    // 0xb8abbc: LoadField: d1 = r2->field_f
    //     0xb8abbc: ldur            d1, [x2, #0xf]
    // 0xb8abc0: stur            d1, [fp, #-0x38]
    // 0xb8abc4: fcmp            d0, d1
    // 0xb8abc8: b.ge            #0xb8abfc
    // 0xb8abcc: LoadField: d2 = r2->field_7
    //     0xb8abcc: ldur            d2, [x2, #7]
    // 0xb8abd0: stur            d2, [fp, #-0x30]
    // 0xb8abd4: fcmp            d0, d2
    // 0xb8abd8: b.ge            #0xb8abfc
    // 0xb8abdc: LoadField: d3 = r3->field_f
    //     0xb8abdc: ldur            d3, [x3, #0xf]
    // 0xb8abe0: stur            d3, [fp, #-0x20]
    // 0xb8abe4: fcmp            d0, d3
    // 0xb8abe8: b.ge            #0xb8abfc
    // 0xb8abec: LoadField: d4 = r3->field_7
    //     0xb8abec: ldur            d4, [x3, #7]
    // 0xb8abf0: stur            d4, [fp, #-0x28]
    // 0xb8abf4: fcmp            d0, d4
    // 0xb8abf8: b.lt            #0xb8ac10
    // 0xb8abfc: r0 = Instance_FittedSizes
    //     0xb8abfc: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1390] Obj!FittedSizes@129e2a1
    //     0xb8ac00: ldr             x0, [x0, #0x390]
    // 0xb8ac04: LeaveFrame
    //     0xb8ac04: mov             SP, fp
    //     0xb8ac08: ldp             fp, lr, [SP], #0x10
    // 0xb8ac0c: ret
    //     0xb8ac0c: ret             
    // 0xb8ac10: LoadField: r0 = r1->field_7
    //     0xb8ac10: ldur            x0, [x1, #7]
    // 0xb8ac14: cmp             x0, #3
    // 0xb8ac18: b.gt            #0xb8ad74
    // 0xb8ac1c: cmp             x0, #1
    // 0xb8ac20: b.gt            #0xb8ac94
    // 0xb8ac24: cmp             x0, #0
    // 0xb8ac28: b.gt            #0xb8ac38
    // 0xb8ac2c: mov             x1, x2
    // 0xb8ac30: mov             x0, x3
    // 0xb8ac34: b               #0xb8ae90
    // 0xb8ac38: fdiv            d0, d4, d3
    // 0xb8ac3c: fdiv            d5, d2, d1
    // 0xb8ac40: fcmp            d0, d5
    // 0xb8ac44: b.le            #0xb8ac6c
    // 0xb8ac48: fmul            d0, d2, d3
    // 0xb8ac4c: fdiv            d2, d0, d1
    // 0xb8ac50: stur            d2, [fp, #-0x18]
    // 0xb8ac54: r0 = Size()
    //     0xb8ac54: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ac58: ldur            d0, [fp, #-0x18]
    // 0xb8ac5c: StoreField: r0->field_7 = d0
    //     0xb8ac5c: stur            d0, [x0, #7]
    // 0xb8ac60: ldur            d0, [fp, #-0x20]
    // 0xb8ac64: StoreField: r0->field_f = d0
    //     0xb8ac64: stur            d0, [x0, #0xf]
    // 0xb8ac68: b               #0xb8ac8c
    // 0xb8ac6c: fmul            d0, d1, d4
    // 0xb8ac70: fdiv            d1, d0, d2
    // 0xb8ac74: stur            d1, [fp, #-0x18]
    // 0xb8ac78: r0 = Size()
    //     0xb8ac78: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ac7c: ldur            d3, [fp, #-0x28]
    // 0xb8ac80: StoreField: r0->field_7 = d3
    //     0xb8ac80: stur            d3, [x0, #7]
    // 0xb8ac84: ldur            d0, [fp, #-0x18]
    // 0xb8ac88: StoreField: r0->field_f = d0
    //     0xb8ac88: stur            d0, [x0, #0xf]
    // 0xb8ac8c: ldur            x1, [fp, #-8]
    // 0xb8ac90: b               #0xb8ae90
    // 0xb8ac94: mov             v0.16b, v3.16b
    // 0xb8ac98: mov             v3.16b, v4.16b
    // 0xb8ac9c: cmp             x0, #2
    // 0xb8aca0: b.gt            #0xb8ad04
    // 0xb8aca4: fdiv            d4, d3, d0
    // 0xb8aca8: fdiv            d5, d2, d1
    // 0xb8acac: fcmp            d4, d5
    // 0xb8acb0: b.le            #0xb8acd8
    // 0xb8acb4: fmul            d1, d2, d0
    // 0xb8acb8: fdiv            d0, d1, d3
    // 0xb8acbc: stur            d0, [fp, #-0x18]
    // 0xb8acc0: r0 = Size()
    //     0xb8acc0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8acc4: ldur            d1, [fp, #-0x30]
    // 0xb8acc8: StoreField: r0->field_7 = d1
    //     0xb8acc8: stur            d1, [x0, #7]
    // 0xb8accc: ldur            d0, [fp, #-0x18]
    // 0xb8acd0: StoreField: r0->field_f = d0
    //     0xb8acd0: stur            d0, [x0, #0xf]
    // 0xb8acd4: b               #0xb8acf8
    // 0xb8acd8: fmul            d2, d1, d3
    // 0xb8acdc: fdiv            d3, d2, d0
    // 0xb8ace0: stur            d3, [fp, #-0x18]
    // 0xb8ace4: r0 = Size()
    //     0xb8ace4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ace8: ldur            d0, [fp, #-0x18]
    // 0xb8acec: StoreField: r0->field_7 = d0
    //     0xb8acec: stur            d0, [x0, #7]
    // 0xb8acf0: ldur            d2, [fp, #-0x38]
    // 0xb8acf4: StoreField: r0->field_f = d2
    //     0xb8acf4: stur            d2, [x0, #0xf]
    // 0xb8acf8: mov             x1, x0
    // 0xb8acfc: ldur            x0, [fp, #-0x10]
    // 0xb8ad00: b               #0xb8ae90
    // 0xb8ad04: mov             v31.16b, v1.16b
    // 0xb8ad08: mov             v1.16b, v2.16b
    // 0xb8ad0c: mov             v2.16b, v31.16b
    // 0xb8ad10: fdiv            d4, d3, d0
    // 0xb8ad14: fdiv            d5, d1, d2
    // 0xb8ad18: fcmp            d4, d5
    // 0xb8ad1c: b.le            #0xb8ad4c
    // 0xb8ad20: fmul            d2, d1, d0
    // 0xb8ad24: fdiv            d0, d2, d3
    // 0xb8ad28: stur            d0, [fp, #-0x18]
    // 0xb8ad2c: r0 = Size()
    //     0xb8ad2c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ad30: ldur            d1, [fp, #-0x30]
    // 0xb8ad34: StoreField: r0->field_7 = d1
    //     0xb8ad34: stur            d1, [x0, #7]
    // 0xb8ad38: ldur            d0, [fp, #-0x18]
    // 0xb8ad3c: StoreField: r0->field_f = d0
    //     0xb8ad3c: stur            d0, [x0, #0xf]
    // 0xb8ad40: mov             x1, x0
    // 0xb8ad44: ldur            x0, [fp, #-0x10]
    // 0xb8ad48: b               #0xb8ae90
    // 0xb8ad4c: fmul            d0, d2, d3
    // 0xb8ad50: fdiv            d2, d0, d1
    // 0xb8ad54: stur            d2, [fp, #-0x18]
    // 0xb8ad58: r0 = Size()
    //     0xb8ad58: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ad5c: ldur            d3, [fp, #-0x28]
    // 0xb8ad60: StoreField: r0->field_7 = d3
    //     0xb8ad60: stur            d3, [x0, #7]
    // 0xb8ad64: ldur            d0, [fp, #-0x18]
    // 0xb8ad68: StoreField: r0->field_f = d0
    //     0xb8ad68: stur            d0, [x0, #0xf]
    // 0xb8ad6c: ldur            x1, [fp, #-8]
    // 0xb8ad70: b               #0xb8ae90
    // 0xb8ad74: mov             v0.16b, v3.16b
    // 0xb8ad78: mov             v3.16b, v4.16b
    // 0xb8ad7c: mov             v31.16b, v1.16b
    // 0xb8ad80: mov             v1.16b, v2.16b
    // 0xb8ad84: mov             v2.16b, v31.16b
    // 0xb8ad88: cmp             x0, #5
    // 0xb8ad8c: b.gt            #0xb8ae28
    // 0xb8ad90: cmp             x0, #4
    // 0xb8ad94: b.gt            #0xb8adfc
    // 0xb8ad98: fdiv            d4, d3, d0
    // 0xb8ad9c: fdiv            d5, d1, d2
    // 0xb8ada0: fcmp            d4, d5
    // 0xb8ada4: b.le            #0xb8add0
    // 0xb8ada8: fmul            d3, d1, d0
    // 0xb8adac: fdiv            d1, d3, d2
    // 0xb8adb0: stur            d1, [fp, #-0x18]
    // 0xb8adb4: r0 = Size()
    //     0xb8adb4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8adb8: ldur            d0, [fp, #-0x18]
    // 0xb8adbc: StoreField: r0->field_7 = d0
    //     0xb8adbc: stur            d0, [x0, #7]
    // 0xb8adc0: ldur            d0, [fp, #-0x20]
    // 0xb8adc4: StoreField: r0->field_f = d0
    //     0xb8adc4: stur            d0, [x0, #0xf]
    // 0xb8adc8: ldur            x1, [fp, #-8]
    // 0xb8adcc: b               #0xb8ae90
    // 0xb8add0: fmul            d1, d2, d3
    // 0xb8add4: fdiv            d3, d1, d0
    // 0xb8add8: stur            d3, [fp, #-0x18]
    // 0xb8addc: r0 = Size()
    //     0xb8addc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ade0: ldur            d0, [fp, #-0x18]
    // 0xb8ade4: StoreField: r0->field_7 = d0
    //     0xb8ade4: stur            d0, [x0, #7]
    // 0xb8ade8: ldur            d2, [fp, #-0x38]
    // 0xb8adec: StoreField: r0->field_f = d2
    //     0xb8adec: stur            d2, [x0, #0xf]
    // 0xb8adf0: mov             x1, x0
    // 0xb8adf4: ldur            x0, [fp, #-0x10]
    // 0xb8adf8: b               #0xb8ae90
    // 0xb8adfc: fmin            v4.2d, v1.2d, v3.2d
    // 0xb8ae00: stur            d4, [fp, #-0x40]
    // 0xb8ae04: fmin            v1.2d, v2.2d, v0.2d
    // 0xb8ae08: stur            d1, [fp, #-0x18]
    // 0xb8ae0c: r0 = Size()
    //     0xb8ae0c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ae10: ldur            d0, [fp, #-0x40]
    // 0xb8ae14: StoreField: r0->field_7 = d0
    //     0xb8ae14: stur            d0, [x0, #7]
    // 0xb8ae18: ldur            d0, [fp, #-0x18]
    // 0xb8ae1c: StoreField: r0->field_f = d0
    //     0xb8ae1c: stur            d0, [x0, #0xf]
    // 0xb8ae20: mov             x1, x0
    // 0xb8ae24: b               #0xb8ae90
    // 0xb8ae28: fdiv            d4, d1, d2
    // 0xb8ae2c: stur            d4, [fp, #-0x40]
    // 0xb8ae30: fcmp            d2, d0
    // 0xb8ae34: b.le            #0xb8ae5c
    // 0xb8ae38: fmul            d1, d0, d4
    // 0xb8ae3c: stur            d1, [fp, #-0x18]
    // 0xb8ae40: r0 = Size()
    //     0xb8ae40: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ae44: ldur            d0, [fp, #-0x18]
    // 0xb8ae48: StoreField: r0->field_7 = d0
    //     0xb8ae48: stur            d0, [x0, #7]
    // 0xb8ae4c: ldur            d1, [fp, #-0x20]
    // 0xb8ae50: StoreField: r0->field_f = d1
    //     0xb8ae50: stur            d1, [x0, #0xf]
    // 0xb8ae54: mov             v1.16b, v0.16b
    // 0xb8ae58: b               #0xb8ae60
    // 0xb8ae5c: ldur            x0, [fp, #-8]
    // 0xb8ae60: ldur            d0, [fp, #-0x28]
    // 0xb8ae64: fcmp            d1, d0
    // 0xb8ae68: b.le            #0xb8ae8c
    // 0xb8ae6c: ldur            d1, [fp, #-0x40]
    // 0xb8ae70: fdiv            d2, d0, d1
    // 0xb8ae74: stur            d2, [fp, #-0x18]
    // 0xb8ae78: r0 = Size()
    //     0xb8ae78: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb8ae7c: ldur            d0, [fp, #-0x28]
    // 0xb8ae80: StoreField: r0->field_7 = d0
    //     0xb8ae80: stur            d0, [x0, #7]
    // 0xb8ae84: ldur            d0, [fp, #-0x18]
    // 0xb8ae88: StoreField: r0->field_f = d0
    //     0xb8ae88: stur            d0, [x0, #0xf]
    // 0xb8ae8c: ldur            x1, [fp, #-8]
    // 0xb8ae90: stur            x1, [fp, #-8]
    // 0xb8ae94: stur            x0, [fp, #-0x10]
    // 0xb8ae98: r0 = FittedSizes()
    //     0xb8ae98: bl              #0xb8aeb8  ; AllocateFittedSizesStub -> FittedSizes (size=0x10)
    // 0xb8ae9c: ldur            x1, [fp, #-8]
    // 0xb8aea0: StoreField: r0->field_7 = r1
    //     0xb8aea0: stur            w1, [x0, #7]
    // 0xb8aea4: ldur            x1, [fp, #-0x10]
    // 0xb8aea8: StoreField: r0->field_b = r1
    //     0xb8aea8: stur            w1, [x0, #0xb]
    // 0xb8aeac: LeaveFrame
    //     0xb8aeac: mov             SP, fp
    //     0xb8aeb0: ldp             fp, lr, [SP], #0x10
    // 0xb8aeb4: ret
    //     0xb8aeb4: ret             
  }
}

// class id: 2949, size: 0x10, field offset: 0x8
//   const constructor, 
class FittedSizes extends Object {

  Size field_8;
  Size field_c;
}

// class id: 8247, size: 0x14, field offset: 0x14
enum BoxFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
