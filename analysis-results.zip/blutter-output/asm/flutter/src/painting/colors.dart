// lib: , url: package:flutter/src/painting/colors.dart

// class id: 1048989, size: 0x8
class :: {

  static _ _colorFromHue(/* No info */) {
    // ** addr: 0xd433c0, size: 0x710
    // 0xd433c0: EnterFrame
    //     0xd433c0: stp             fp, lr, [SP, #-0x10]!
    //     0xd433c4: mov             fp, SP
    // 0xd433c8: AllocStack(0x28)
    //     0xd433c8: sub             SP, SP, #0x28
    // 0xd433cc: d5 = 60.000000
    //     0xd433cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13358] IMM: double(60) from 0x404e000000000000
    //     0xd433d0: ldr             d5, [x17, #0x358]
    // 0xd433d4: stur            d0, [fp, #-0x20]
    // 0xd433d8: stur            d4, [fp, #-0x28]
    // 0xd433dc: fcmp            d5, d1
    // 0xd433e0: b.le            #0xd43448
    // 0xd433e4: r2 = inline_Allocate_Double()
    //     0xd433e4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd433e8: add             x2, x2, #0x10
    //     0xd433ec: cmp             x0, x2
    //     0xd433f0: b.ls            #0xd438e4
    //     0xd433f4: str             x2, [THR, #0x60]  ; THR::top
    //     0xd433f8: sub             x2, x2, #0xf
    //     0xd433fc: mov             x0, #0xe19c
    //     0xd43400: movk            x0, #3, lsl #16
    //     0xd43404: stur            x0, [x2, #-1]
    // 0xd43408: dmb             ishst
    // 0xd4340c: StoreField: r2->field_7 = d2
    //     0xd4340c: stur            d2, [x2, #7]
    // 0xd43410: r3 = inline_Allocate_Double()
    //     0xd43410: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xd43414: add             x3, x3, #0x10
    //     0xd43418: cmp             x0, x3
    //     0xd4341c: b.ls            #0xd43900
    //     0xd43420: str             x3, [THR, #0x60]  ; THR::top
    //     0xd43424: sub             x3, x3, #0xf
    //     0xd43428: mov             x0, #0xe19c
    //     0xd4342c: movk            x0, #3, lsl #16
    //     0xd43430: stur            x0, [x3, #-1]
    // 0xd43434: dmb             ishst
    // 0xd43438: StoreField: r3->field_7 = d3
    //     0xd43438: stur            d3, [x3, #7]
    // 0xd4343c: r4 = 0.000000
    //     0xd4343c: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd43440: r0 = AllocateRecord3()
    //     0xd43440: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd43444: b               #0xd43678
    // 0xd43448: d0 = 120.000000
    //     0xd43448: add             x17, PP, #0x26, lsl #12  ; [pp+0x26190] IMM: double(120) from 0x405e000000000000
    //     0xd4344c: ldr             d0, [x17, #0x190]
    // 0xd43450: fcmp            d0, d1
    // 0xd43454: b.le            #0xd434bc
    // 0xd43458: r3 = inline_Allocate_Double()
    //     0xd43458: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xd4345c: add             x3, x3, #0x10
    //     0xd43460: cmp             x0, x3
    //     0xd43464: b.ls            #0xd43924
    //     0xd43468: str             x3, [THR, #0x60]  ; THR::top
    //     0xd4346c: sub             x3, x3, #0xf
    //     0xd43470: mov             x0, #0xe19c
    //     0xd43474: movk            x0, #3, lsl #16
    //     0xd43478: stur            x0, [x3, #-1]
    // 0xd4347c: dmb             ishst
    // 0xd43480: StoreField: r3->field_7 = d2
    //     0xd43480: stur            d2, [x3, #7]
    // 0xd43484: r2 = inline_Allocate_Double()
    //     0xd43484: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd43488: add             x2, x2, #0x10
    //     0xd4348c: cmp             x0, x2
    //     0xd43490: b.ls            #0xd43938
    //     0xd43494: str             x2, [THR, #0x60]  ; THR::top
    //     0xd43498: sub             x2, x2, #0xf
    //     0xd4349c: mov             x0, #0xe19c
    //     0xd434a0: movk            x0, #3, lsl #16
    //     0xd434a4: stur            x0, [x2, #-1]
    // 0xd434a8: dmb             ishst
    // 0xd434ac: StoreField: r2->field_7 = d3
    //     0xd434ac: stur            d3, [x2, #7]
    // 0xd434b0: r4 = 0.000000
    //     0xd434b0: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd434b4: r0 = AllocateRecord3()
    //     0xd434b4: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd434b8: b               #0xd43678
    // 0xd434bc: d0 = 180.000000
    //     0xd434bc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13170] IMM: double(180) from 0x4066800000000000
    //     0xd434c0: ldr             d0, [x17, #0x170]
    // 0xd434c4: fcmp            d0, d1
    // 0xd434c8: b.le            #0xd43530
    // 0xd434cc: r3 = inline_Allocate_Double()
    //     0xd434cc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xd434d0: add             x3, x3, #0x10
    //     0xd434d4: cmp             x0, x3
    //     0xd434d8: b.ls            #0xd43954
    //     0xd434dc: str             x3, [THR, #0x60]  ; THR::top
    //     0xd434e0: sub             x3, x3, #0xf
    //     0xd434e4: mov             x0, #0xe19c
    //     0xd434e8: movk            x0, #3, lsl #16
    //     0xd434ec: stur            x0, [x3, #-1]
    // 0xd434f0: dmb             ishst
    // 0xd434f4: StoreField: r3->field_7 = d2
    //     0xd434f4: stur            d2, [x3, #7]
    // 0xd434f8: r4 = inline_Allocate_Double()
    //     0xd434f8: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd434fc: add             x4, x4, #0x10
    //     0xd43500: cmp             x0, x4
    //     0xd43504: b.ls            #0xd43968
    //     0xd43508: str             x4, [THR, #0x60]  ; THR::top
    //     0xd4350c: sub             x4, x4, #0xf
    //     0xd43510: mov             x0, #0xe19c
    //     0xd43514: movk            x0, #3, lsl #16
    //     0xd43518: stur            x0, [x4, #-1]
    // 0xd4351c: dmb             ishst
    // 0xd43520: StoreField: r4->field_7 = d3
    //     0xd43520: stur            d3, [x4, #7]
    // 0xd43524: r2 = 0.000000
    //     0xd43524: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd43528: r0 = AllocateRecord3()
    //     0xd43528: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd4352c: b               #0xd43678
    // 0xd43530: d0 = 240.000000
    //     0xd43530: add             x17, PP, #0x26, lsl #12  ; [pp+0x26198] IMM: double(240) from 0x406e000000000000
    //     0xd43534: ldr             d0, [x17, #0x198]
    // 0xd43538: fcmp            d0, d1
    // 0xd4353c: b.le            #0xd435a4
    // 0xd43540: r4 = inline_Allocate_Double()
    //     0xd43540: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd43544: add             x4, x4, #0x10
    //     0xd43548: cmp             x0, x4
    //     0xd4354c: b.ls            #0xd43984
    //     0xd43550: str             x4, [THR, #0x60]  ; THR::top
    //     0xd43554: sub             x4, x4, #0xf
    //     0xd43558: mov             x0, #0xe19c
    //     0xd4355c: movk            x0, #3, lsl #16
    //     0xd43560: stur            x0, [x4, #-1]
    // 0xd43564: dmb             ishst
    // 0xd43568: StoreField: r4->field_7 = d2
    //     0xd43568: stur            d2, [x4, #7]
    // 0xd4356c: r3 = inline_Allocate_Double()
    //     0xd4356c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xd43570: add             x3, x3, #0x10
    //     0xd43574: cmp             x0, x3
    //     0xd43578: b.ls            #0xd43998
    //     0xd4357c: str             x3, [THR, #0x60]  ; THR::top
    //     0xd43580: sub             x3, x3, #0xf
    //     0xd43584: mov             x0, #0xe19c
    //     0xd43588: movk            x0, #3, lsl #16
    //     0xd4358c: stur            x0, [x3, #-1]
    // 0xd43590: dmb             ishst
    // 0xd43594: StoreField: r3->field_7 = d3
    //     0xd43594: stur            d3, [x3, #7]
    // 0xd43598: r2 = 0.000000
    //     0xd43598: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd4359c: r0 = AllocateRecord3()
    //     0xd4359c: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd435a0: b               #0xd43678
    // 0xd435a4: d0 = 300.000000
    //     0xd435a4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261a0] IMM: double(300) from 0x4072c00000000000
    //     0xd435a8: ldr             d0, [x17, #0x1a0]
    // 0xd435ac: fcmp            d0, d1
    // 0xd435b0: b.le            #0xd43618
    // 0xd435b4: r4 = inline_Allocate_Double()
    //     0xd435b4: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd435b8: add             x4, x4, #0x10
    //     0xd435bc: cmp             x0, x4
    //     0xd435c0: b.ls            #0xd439b4
    //     0xd435c4: str             x4, [THR, #0x60]  ; THR::top
    //     0xd435c8: sub             x4, x4, #0xf
    //     0xd435cc: mov             x0, #0xe19c
    //     0xd435d0: movk            x0, #3, lsl #16
    //     0xd435d4: stur            x0, [x4, #-1]
    // 0xd435d8: dmb             ishst
    // 0xd435dc: StoreField: r4->field_7 = d2
    //     0xd435dc: stur            d2, [x4, #7]
    // 0xd435e0: r2 = inline_Allocate_Double()
    //     0xd435e0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd435e4: add             x2, x2, #0x10
    //     0xd435e8: cmp             x0, x2
    //     0xd435ec: b.ls            #0xd439c8
    //     0xd435f0: str             x2, [THR, #0x60]  ; THR::top
    //     0xd435f4: sub             x2, x2, #0xf
    //     0xd435f8: mov             x0, #0xe19c
    //     0xd435fc: movk            x0, #3, lsl #16
    //     0xd43600: stur            x0, [x2, #-1]
    // 0xd43604: dmb             ishst
    // 0xd43608: StoreField: r2->field_7 = d3
    //     0xd43608: stur            d3, [x2, #7]
    // 0xd4360c: r3 = 0.000000
    //     0xd4360c: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd43610: r0 = AllocateRecord3()
    //     0xd43610: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd43614: b               #0xd43678
    // 0xd43618: r2 = inline_Allocate_Double()
    //     0xd43618: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd4361c: add             x2, x2, #0x10
    //     0xd43620: cmp             x0, x2
    //     0xd43624: b.ls            #0xd439e4
    //     0xd43628: str             x2, [THR, #0x60]  ; THR::top
    //     0xd4362c: sub             x2, x2, #0xf
    //     0xd43630: mov             x0, #0xe19c
    //     0xd43634: movk            x0, #3, lsl #16
    //     0xd43638: stur            x0, [x2, #-1]
    // 0xd4363c: dmb             ishst
    // 0xd43640: StoreField: r2->field_7 = d2
    //     0xd43640: stur            d2, [x2, #7]
    // 0xd43644: r4 = inline_Allocate_Double()
    //     0xd43644: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd43648: add             x4, x4, #0x10
    //     0xd4364c: cmp             x0, x4
    //     0xd43650: b.ls            #0xd439f8
    //     0xd43654: str             x4, [THR, #0x60]  ; THR::top
    //     0xd43658: sub             x4, x4, #0xf
    //     0xd4365c: mov             x0, #0xe19c
    //     0xd43660: movk            x0, #3, lsl #16
    //     0xd43664: stur            x0, [x4, #-1]
    // 0xd43668: dmb             ishst
    // 0xd4366c: StoreField: r4->field_7 = d3
    //     0xd4366c: stur            d3, [x4, #7]
    // 0xd43670: r3 = 0.000000
    //     0xd43670: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd43674: r0 = AllocateRecord3()
    //     0xd43674: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xd43678: ldur            d0, [fp, #-0x20]
    // 0xd4367c: ldur            d1, [fp, #-0x28]
    // 0xd43680: d2 = 255.000000
    //     0xd43680: ldr             d2, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43684: LoadField: r19 = r0->field_f
    //     0xd43684: ldur            w19, [x0, #0xf]
    // 0xd43688: DecompressPointer r19
    //     0xd43688: add             x19, x19, HEAP, lsl #32
    // 0xd4368c: LoadField: r20 = r0->field_13
    //     0xd4368c: ldur            w20, [x0, #0x13]
    // 0xd43690: DecompressPointer r20
    //     0xd43690: add             x20, x20, HEAP, lsl #32
    // 0xd43694: ArrayLoad: r23 = r0[0]  ; List_4
    //     0xd43694: ldur            w23, [x0, #0x17]
    // 0xd43698: DecompressPointer r23
    //     0xd43698: add             x23, x23, HEAP, lsl #32
    // 0xd4369c: fmul            d3, d0, d2
    // 0xd436a0: mov             v0.16b, v3.16b
    // 0xd436a4: stp             fp, lr, [SP, #-0x10]!
    // 0xd436a8: mov             fp, SP
    // 0xd436ac: CallRuntime_LibcRound(double) -> double
    //     0xd436ac: and             SP, SP, #0xfffffffffffffff0
    //     0xd436b0: mov             sp, SP
    //     0xd436b4: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd436b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd436bc: blr             x16
    //     0xd436c0: mov             x16, #8
    //     0xd436c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd436c8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd436cc: sub             sp, x16, #1, lsl #12
    //     0xd436d0: mov             SP, fp
    //     0xd436d4: ldp             fp, lr, [SP], #0x10
    // 0xd436d8: fcmp            d0, d0
    // 0xd436dc: b.vs            #0xd43a14
    // 0xd436e0: fcvtzs          x24, d0
    // 0xd436e4: asr             x16, x24, #0x1e
    // 0xd436e8: cmp             x16, x24, asr #63
    // 0xd436ec: b.ne            #0xd43a14
    // 0xd436f0: lsl             x24, x24, #1
    // 0xd436f4: LoadField: d0 = r19->field_7
    //     0xd436f4: ldur            d0, [x19, #7]
    // 0xd436f8: ldur            d1, [fp, #-0x28]
    // 0xd436fc: fadd            d2, d0, d1
    // 0xd43700: d3 = 255.000000
    //     0xd43700: ldr             d3, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43704: fmul            d0, d2, d3
    // 0xd43708: stp             fp, lr, [SP, #-0x10]!
    // 0xd4370c: mov             fp, SP
    // 0xd43710: CallRuntime_LibcRound(double) -> double
    //     0xd43710: and             SP, SP, #0xfffffffffffffff0
    //     0xd43714: mov             sp, SP
    //     0xd43718: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd4371c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43720: blr             x16
    //     0xd43724: mov             x16, #8
    //     0xd43728: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd4372c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd43730: sub             sp, x16, #1, lsl #12
    //     0xd43734: mov             SP, fp
    //     0xd43738: ldp             fp, lr, [SP], #0x10
    // 0xd4373c: fcmp            d0, d0
    // 0xd43740: b.vs            #0xd43a44
    // 0xd43744: fcvtzs          x19, d0
    // 0xd43748: asr             x16, x19, #0x1e
    // 0xd4374c: cmp             x16, x19, asr #63
    // 0xd43750: b.ne            #0xd43a44
    // 0xd43754: lsl             x19, x19, #1
    // 0xd43758: stur            x19, [fp, #-0x18]
    // 0xd4375c: LoadField: d0 = r20->field_7
    //     0xd4375c: ldur            d0, [x20, #7]
    // 0xd43760: ldur            d1, [fp, #-0x28]
    // 0xd43764: fadd            d2, d0, d1
    // 0xd43768: d3 = 255.000000
    //     0xd43768: ldr             d3, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd4376c: fmul            d0, d2, d3
    // 0xd43770: stp             fp, lr, [SP, #-0x10]!
    // 0xd43774: mov             fp, SP
    // 0xd43778: CallRuntime_LibcRound(double) -> double
    //     0xd43778: and             SP, SP, #0xfffffffffffffff0
    //     0xd4377c: mov             sp, SP
    //     0xd43780: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd43784: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43788: blr             x16
    //     0xd4378c: mov             x16, #8
    //     0xd43790: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43794: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd43798: sub             sp, x16, #1, lsl #12
    //     0xd4379c: mov             SP, fp
    //     0xd437a0: ldp             fp, lr, [SP], #0x10
    // 0xd437a4: fcmp            d0, d0
    // 0xd437a8: b.vs            #0xd43a74
    // 0xd437ac: fcvtzs          x20, d0
    // 0xd437b0: asr             x16, x20, #0x1e
    // 0xd437b4: cmp             x16, x20, asr #63
    // 0xd437b8: b.ne            #0xd43a74
    // 0xd437bc: lsl             x20, x20, #1
    // 0xd437c0: stur            x20, [fp, #-0x10]
    // 0xd437c4: LoadField: d0 = r23->field_7
    //     0xd437c4: ldur            d0, [x23, #7]
    // 0xd437c8: ldur            d1, [fp, #-0x28]
    // 0xd437cc: fadd            d2, d0, d1
    // 0xd437d0: d1 = 255.000000
    //     0xd437d0: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd437d4: fmul            d0, d2, d1
    // 0xd437d8: stp             fp, lr, [SP, #-0x10]!
    // 0xd437dc: mov             fp, SP
    // 0xd437e0: CallRuntime_LibcRound(double) -> double
    //     0xd437e0: and             SP, SP, #0xfffffffffffffff0
    //     0xd437e4: mov             sp, SP
    //     0xd437e8: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd437ec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd437f0: blr             x16
    //     0xd437f4: mov             x16, #8
    //     0xd437f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd437fc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd43800: sub             sp, x16, #1, lsl #12
    //     0xd43804: mov             SP, fp
    //     0xd43808: ldp             fp, lr, [SP], #0x10
    // 0xd4380c: fcmp            d0, d0
    // 0xd43810: b.vs            #0xd43aa4
    // 0xd43814: fcvtzs          x0, d0
    // 0xd43818: asr             x16, x0, #0x1e
    // 0xd4381c: cmp             x16, x0, asr #63
    // 0xd43820: b.ne            #0xd43aa4
    // 0xd43824: lsl             x0, x0, #1
    // 0xd43828: stur            x0, [fp, #-8]
    // 0xd4382c: r1 = LoadInt32Instr(r24)
    //     0xd4382c: sbfx            x1, x24, #1, #0x1f
    //     0xd43830: tbz             w24, #0, #0xd43838
    //     0xd43834: ldur            x1, [x24, #7]
    // 0xd43838: and             w2, w1, #0xff
    // 0xd4383c: ubfx            x2, x2, #0, #0x20
    // 0xd43840: scvtf           d0, x2
    // 0xd43844: d1 = 255.000000
    //     0xd43844: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43848: fdiv            d2, d0, d1
    // 0xd4384c: stur            d2, [fp, #-0x20]
    // 0xd43850: r0 = Color()
    //     0xd43850: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0xd43854: r1 = Instance_ColorSpace
    //     0xd43854: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0xd43858: ldr             x1, [x1, #0x298]
    // 0xd4385c: StoreField: r0->field_27 = r1
    //     0xd4385c: stur            w1, [x0, #0x27]
    // 0xd43860: ldur            d0, [fp, #-0x20]
    // 0xd43864: StoreField: r0->field_7 = d0
    //     0xd43864: stur            d0, [x0, #7]
    // 0xd43868: ldur            x1, [fp, #-0x18]
    // 0xd4386c: r2 = LoadInt32Instr(r1)
    //     0xd4386c: sbfx            x2, x1, #1, #0x1f
    //     0xd43870: tbz             w1, #0, #0xd43878
    //     0xd43874: ldur            x2, [x1, #7]
    // 0xd43878: and             w1, w2, #0xff
    // 0xd4387c: ubfx            x1, x1, #0, #0x20
    // 0xd43880: scvtf           d0, x1
    // 0xd43884: d1 = 255.000000
    //     0xd43884: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43888: fdiv            d2, d0, d1
    // 0xd4388c: StoreField: r0->field_f = d2
    //     0xd4388c: stur            d2, [x0, #0xf]
    // 0xd43890: ldur            x1, [fp, #-0x10]
    // 0xd43894: r2 = LoadInt32Instr(r1)
    //     0xd43894: sbfx            x2, x1, #1, #0x1f
    //     0xd43898: tbz             w1, #0, #0xd438a0
    //     0xd4389c: ldur            x2, [x1, #7]
    // 0xd438a0: and             w1, w2, #0xff
    // 0xd438a4: ubfx            x1, x1, #0, #0x20
    // 0xd438a8: scvtf           d0, x1
    // 0xd438ac: fdiv            d2, d0, d1
    // 0xd438b0: ArrayStore: r0[0] = d2  ; List_8
    //     0xd438b0: stur            d2, [x0, #0x17]
    // 0xd438b4: ldur            x1, [fp, #-8]
    // 0xd438b8: r2 = LoadInt32Instr(r1)
    //     0xd438b8: sbfx            x2, x1, #1, #0x1f
    //     0xd438bc: tbz             w1, #0, #0xd438c4
    //     0xd438c0: ldur            x2, [x1, #7]
    // 0xd438c4: and             w1, w2, #0xff
    // 0xd438c8: ubfx            x1, x1, #0, #0x20
    // 0xd438cc: scvtf           d0, x1
    // 0xd438d0: fdiv            d2, d0, d1
    // 0xd438d4: StoreField: r0->field_1f = d2
    //     0xd438d4: stur            d2, [x0, #0x1f]
    // 0xd438d8: LeaveFrame
    //     0xd438d8: mov             SP, fp
    //     0xd438dc: ldp             fp, lr, [SP], #0x10
    // 0xd438e0: ret
    //     0xd438e0: ret             
    // 0xd438e4: stp             q3, q4, [SP, #-0x20]!
    // 0xd438e8: stp             q0, q2, [SP, #-0x20]!
    // 0xd438ec: r0 = AllocateDouble()
    //     0xd438ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd438f0: mov             x2, x0
    // 0xd438f4: ldp             q0, q2, [SP], #0x20
    // 0xd438f8: ldp             q3, q4, [SP], #0x20
    // 0xd438fc: b               #0xd4340c
    // 0xd43900: stp             q3, q4, [SP, #-0x20]!
    // 0xd43904: SaveReg d0
    //     0xd43904: str             q0, [SP, #-0x10]!
    // 0xd43908: SaveReg r2
    //     0xd43908: str             x2, [SP, #-8]!
    // 0xd4390c: r0 = AllocateDouble()
    //     0xd4390c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43910: mov             x3, x0
    // 0xd43914: RestoreReg r2
    //     0xd43914: ldr             x2, [SP], #8
    // 0xd43918: RestoreReg d0
    //     0xd43918: ldr             q0, [SP], #0x10
    // 0xd4391c: ldp             q3, q4, [SP], #0x20
    // 0xd43920: b               #0xd43438
    // 0xd43924: stp             q2, q3, [SP, #-0x20]!
    // 0xd43928: r0 = AllocateDouble()
    //     0xd43928: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4392c: mov             x3, x0
    // 0xd43930: ldp             q2, q3, [SP], #0x20
    // 0xd43934: b               #0xd43480
    // 0xd43938: SaveReg d3
    //     0xd43938: str             q3, [SP, #-0x10]!
    // 0xd4393c: SaveReg r3
    //     0xd4393c: str             x3, [SP, #-8]!
    // 0xd43940: r0 = AllocateDouble()
    //     0xd43940: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43944: mov             x2, x0
    // 0xd43948: RestoreReg r3
    //     0xd43948: ldr             x3, [SP], #8
    // 0xd4394c: RestoreReg d3
    //     0xd4394c: ldr             q3, [SP], #0x10
    // 0xd43950: b               #0xd434ac
    // 0xd43954: stp             q2, q3, [SP, #-0x20]!
    // 0xd43958: r0 = AllocateDouble()
    //     0xd43958: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4395c: mov             x3, x0
    // 0xd43960: ldp             q2, q3, [SP], #0x20
    // 0xd43964: b               #0xd434f4
    // 0xd43968: SaveReg d3
    //     0xd43968: str             q3, [SP, #-0x10]!
    // 0xd4396c: SaveReg r3
    //     0xd4396c: str             x3, [SP, #-8]!
    // 0xd43970: r0 = AllocateDouble()
    //     0xd43970: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43974: mov             x4, x0
    // 0xd43978: RestoreReg r3
    //     0xd43978: ldr             x3, [SP], #8
    // 0xd4397c: RestoreReg d3
    //     0xd4397c: ldr             q3, [SP], #0x10
    // 0xd43980: b               #0xd43520
    // 0xd43984: stp             q2, q3, [SP, #-0x20]!
    // 0xd43988: r0 = AllocateDouble()
    //     0xd43988: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4398c: mov             x4, x0
    // 0xd43990: ldp             q2, q3, [SP], #0x20
    // 0xd43994: b               #0xd43568
    // 0xd43998: SaveReg d3
    //     0xd43998: str             q3, [SP, #-0x10]!
    // 0xd4399c: SaveReg r4
    //     0xd4399c: str             x4, [SP, #-8]!
    // 0xd439a0: r0 = AllocateDouble()
    //     0xd439a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd439a4: mov             x3, x0
    // 0xd439a8: RestoreReg r4
    //     0xd439a8: ldr             x4, [SP], #8
    // 0xd439ac: RestoreReg d3
    //     0xd439ac: ldr             q3, [SP], #0x10
    // 0xd439b0: b               #0xd43594
    // 0xd439b4: stp             q2, q3, [SP, #-0x20]!
    // 0xd439b8: r0 = AllocateDouble()
    //     0xd439b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd439bc: mov             x4, x0
    // 0xd439c0: ldp             q2, q3, [SP], #0x20
    // 0xd439c4: b               #0xd435dc
    // 0xd439c8: SaveReg d3
    //     0xd439c8: str             q3, [SP, #-0x10]!
    // 0xd439cc: SaveReg r4
    //     0xd439cc: str             x4, [SP, #-8]!
    // 0xd439d0: r0 = AllocateDouble()
    //     0xd439d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd439d4: mov             x2, x0
    // 0xd439d8: RestoreReg r4
    //     0xd439d8: ldr             x4, [SP], #8
    // 0xd439dc: RestoreReg d3
    //     0xd439dc: ldr             q3, [SP], #0x10
    // 0xd439e0: b               #0xd43608
    // 0xd439e4: stp             q2, q3, [SP, #-0x20]!
    // 0xd439e8: r0 = AllocateDouble()
    //     0xd439e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd439ec: mov             x2, x0
    // 0xd439f0: ldp             q2, q3, [SP], #0x20
    // 0xd439f4: b               #0xd43640
    // 0xd439f8: SaveReg d3
    //     0xd439f8: str             q3, [SP, #-0x10]!
    // 0xd439fc: SaveReg r2
    //     0xd439fc: str             x2, [SP, #-8]!
    // 0xd43a00: r0 = AllocateDouble()
    //     0xd43a00: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43a04: mov             x4, x0
    // 0xd43a08: RestoreReg r2
    //     0xd43a08: ldr             x2, [SP], #8
    // 0xd43a0c: RestoreReg d3
    //     0xd43a0c: ldr             q3, [SP], #0x10
    // 0xd43a10: b               #0xd4366c
    // 0xd43a14: SaveReg d0
    //     0xd43a14: str             q0, [SP, #-0x10]!
    // 0xd43a18: stp             x20, x23, [SP, #-0x10]!
    // 0xd43a1c: SaveReg r19
    //     0xd43a1c: str             x19, [SP, #-8]!
    // 0xd43a20: r0 = 76
    //     0xd43a20: mov             x0, #0x4c
    // 0xd43a24: r30 = DoubleToIntegerStub
    //     0xd43a24: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd43a28: LoadField: r30 = r30->field_7
    //     0xd43a28: ldur            lr, [lr, #7]
    // 0xd43a2c: blr             lr
    // 0xd43a30: mov             x24, x0
    // 0xd43a34: RestoreReg r19
    //     0xd43a34: ldr             x19, [SP], #8
    // 0xd43a38: ldp             x20, x23, [SP], #0x10
    // 0xd43a3c: RestoreReg d0
    //     0xd43a3c: ldr             q0, [SP], #0x10
    // 0xd43a40: b               #0xd436f4
    // 0xd43a44: SaveReg d0
    //     0xd43a44: str             q0, [SP, #-0x10]!
    // 0xd43a48: stp             x23, x24, [SP, #-0x10]!
    // 0xd43a4c: SaveReg r20
    //     0xd43a4c: str             x20, [SP, #-8]!
    // 0xd43a50: r0 = 76
    //     0xd43a50: mov             x0, #0x4c
    // 0xd43a54: r30 = DoubleToIntegerStub
    //     0xd43a54: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd43a58: LoadField: r30 = r30->field_7
    //     0xd43a58: ldur            lr, [lr, #7]
    // 0xd43a5c: blr             lr
    // 0xd43a60: mov             x19, x0
    // 0xd43a64: RestoreReg r20
    //     0xd43a64: ldr             x20, [SP], #8
    // 0xd43a68: ldp             x23, x24, [SP], #0x10
    // 0xd43a6c: RestoreReg d0
    //     0xd43a6c: ldr             q0, [SP], #0x10
    // 0xd43a70: b               #0xd43758
    // 0xd43a74: SaveReg d0
    //     0xd43a74: str             q0, [SP, #-0x10]!
    // 0xd43a78: stp             x23, x24, [SP, #-0x10]!
    // 0xd43a7c: SaveReg r19
    //     0xd43a7c: str             x19, [SP, #-8]!
    // 0xd43a80: r0 = 76
    //     0xd43a80: mov             x0, #0x4c
    // 0xd43a84: r30 = DoubleToIntegerStub
    //     0xd43a84: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd43a88: LoadField: r30 = r30->field_7
    //     0xd43a88: ldur            lr, [lr, #7]
    // 0xd43a8c: blr             lr
    // 0xd43a90: mov             x20, x0
    // 0xd43a94: RestoreReg r19
    //     0xd43a94: ldr             x19, [SP], #8
    // 0xd43a98: ldp             x23, x24, [SP], #0x10
    // 0xd43a9c: RestoreReg d0
    //     0xd43a9c: ldr             q0, [SP], #0x10
    // 0xd43aa0: b               #0xd437c0
    // 0xd43aa4: SaveReg d0
    //     0xd43aa4: str             q0, [SP, #-0x10]!
    // 0xd43aa8: stp             x20, x24, [SP, #-0x10]!
    // 0xd43aac: SaveReg r19
    //     0xd43aac: str             x19, [SP, #-8]!
    // 0xd43ab0: r0 = 76
    //     0xd43ab0: mov             x0, #0x4c
    // 0xd43ab4: r30 = DoubleToIntegerStub
    //     0xd43ab4: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd43ab8: LoadField: r30 = r30->field_7
    //     0xd43ab8: ldur            lr, [lr, #7]
    // 0xd43abc: blr             lr
    // 0xd43ac0: RestoreReg r19
    //     0xd43ac0: ldr             x19, [SP], #8
    // 0xd43ac4: ldp             x20, x24, [SP], #0x10
    // 0xd43ac8: RestoreReg d0
    //     0xd43ac8: ldr             q0, [SP], #0x10
    // 0xd43acc: b               #0xd43828
  }
  static _ _getHue(/* No info */) {
    // ** addr: 0xd43d88, size: 0x1dc
    // 0xd43d88: EnterFrame
    //     0xd43d88: stp             fp, lr, [SP, #-0x10]!
    //     0xd43d8c: mov             fp, SP
    // 0xd43d90: AllocStack(0x18)
    //     0xd43d90: sub             SP, SP, #0x18
    // 0xd43d94: d5 = 0.000000
    //     0xd43d94: eor             v5.16b, v5.16b, v5.16b
    // 0xd43d98: CheckStackOverflow
    //     0xd43d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd43d9c: cmp             SP, x16
    //     0xd43da0: b.ls            #0xd43f2c
    // 0xd43da4: fcmp            d3, d5
    // 0xd43da8: b.ne            #0xd43db4
    // 0xd43dac: r0 = 0.000000
    //     0xd43dac: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd43db0: b               #0xd43ef0
    // 0xd43db4: fcmp            d3, d0
    // 0xd43db8: b.ne            #0xd43e4c
    // 0xd43dbc: fsub            d0, d1, d2
    // 0xd43dc0: fdiv            d1, d0, d4
    // 0xd43dc4: stur            d1, [fp, #-8]
    // 0xd43dc8: r16 = 12
    //     0xd43dc8: mov             x16, #0xc
    // 0xd43dcc: stp             x16, NULL, [SP]
    // 0xd43dd0: r0 = _Double.fromInteger()
    //     0xd43dd0: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xd43dd4: LoadField: d1 = r0->field_7
    //     0xd43dd4: ldur            d1, [x0, #7]
    // 0xd43dd8: ldur            d0, [fp, #-8]
    // 0xd43ddc: stp             fp, lr, [SP, #-0x10]!
    // 0xd43de0: mov             fp, SP
    // 0xd43de4: CallRuntime_DartModulo(double, double) -> double
    //     0xd43de4: and             SP, SP, #0xfffffffffffffff0
    //     0xd43de8: mov             sp, SP
    //     0xd43dec: ldr             x16, [THR, #0x748]  ; THR::DartModulo
    //     0xd43df0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43df4: blr             x16
    //     0xd43df8: mov             x16, #8
    //     0xd43dfc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43e00: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd43e04: sub             sp, x16, #1, lsl #12
    //     0xd43e08: mov             SP, fp
    //     0xd43e0c: ldp             fp, lr, [SP], #0x10
    // 0xd43e10: d5 = 60.000000
    //     0xd43e10: add             x17, PP, #0x13, lsl #12  ; [pp+0x13358] IMM: double(60) from 0x404e000000000000
    //     0xd43e14: ldr             d5, [x17, #0x358]
    // 0xd43e18: fmul            d1, d0, d5
    // 0xd43e1c: r0 = inline_Allocate_Double()
    //     0xd43e1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd43e20: add             x0, x0, #0x10
    //     0xd43e24: cmp             x1, x0
    //     0xd43e28: b.ls            #0xd43f34
    //     0xd43e2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd43e30: sub             x0, x0, #0xf
    //     0xd43e34: mov             x1, #0xe19c
    //     0xd43e38: movk            x1, #3, lsl #16
    //     0xd43e3c: stur            x1, [x0, #-1]
    // 0xd43e40: dmb             ishst
    // 0xd43e44: StoreField: r0->field_7 = d1
    //     0xd43e44: stur            d1, [x0, #7]
    // 0xd43e48: b               #0xd43ef0
    // 0xd43e4c: d5 = 60.000000
    //     0xd43e4c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13358] IMM: double(60) from 0x404e000000000000
    //     0xd43e50: ldr             d5, [x17, #0x358]
    // 0xd43e54: fcmp            d3, d1
    // 0xd43e58: b.ne            #0xd43ea0
    // 0xd43e5c: d1 = 2.000000
    //     0xd43e5c: fmov            d1, #2.00000000
    // 0xd43e60: fsub            d3, d2, d0
    // 0xd43e64: fdiv            d0, d3, d4
    // 0xd43e68: fadd            d2, d0, d1
    // 0xd43e6c: fmul            d0, d2, d5
    // 0xd43e70: r0 = inline_Allocate_Double()
    //     0xd43e70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd43e74: add             x0, x0, #0x10
    //     0xd43e78: cmp             x1, x0
    //     0xd43e7c: b.ls            #0xd43f44
    //     0xd43e80: str             x0, [THR, #0x60]  ; THR::top
    //     0xd43e84: sub             x0, x0, #0xf
    //     0xd43e88: mov             x1, #0xe19c
    //     0xd43e8c: movk            x1, #3, lsl #16
    //     0xd43e90: stur            x1, [x0, #-1]
    // 0xd43e94: dmb             ishst
    // 0xd43e98: StoreField: r0->field_7 = d0
    //     0xd43e98: stur            d0, [x0, #7]
    // 0xd43e9c: b               #0xd43ef0
    // 0xd43ea0: fcmp            d3, d2
    // 0xd43ea4: b.ne            #0xd43eec
    // 0xd43ea8: d2 = 4.000000
    //     0xd43ea8: fmov            d2, #4.00000000
    // 0xd43eac: fsub            d3, d0, d1
    // 0xd43eb0: fdiv            d0, d3, d4
    // 0xd43eb4: fadd            d1, d0, d2
    // 0xd43eb8: fmul            d0, d1, d5
    // 0xd43ebc: r0 = inline_Allocate_Double()
    //     0xd43ebc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd43ec0: add             x0, x0, #0x10
    //     0xd43ec4: cmp             x1, x0
    //     0xd43ec8: b.ls            #0xd43f54
    //     0xd43ecc: str             x0, [THR, #0x60]  ; THR::top
    //     0xd43ed0: sub             x0, x0, #0xf
    //     0xd43ed4: mov             x1, #0xe19c
    //     0xd43ed8: movk            x1, #3, lsl #16
    //     0xd43edc: stur            x1, [x0, #-1]
    // 0xd43ee0: dmb             ishst
    // 0xd43ee4: StoreField: r0->field_7 = d0
    //     0xd43ee4: stur            d0, [x0, #7]
    // 0xd43ee8: b               #0xd43ef0
    // 0xd43eec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd43ef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd43ef4: cmp             w0, w16
    // 0xd43ef8: b.eq            #0xd43f18
    // 0xd43efc: LoadField: d0 = r0->field_7
    //     0xd43efc: ldur            d0, [x0, #7]
    // 0xd43f00: fcmp            d0, d0
    // 0xd43f04: b.vc            #0xd43f0c
    // 0xd43f08: d0 = 0.000000
    //     0xd43f08: eor             v0.16b, v0.16b, v0.16b
    // 0xd43f0c: LeaveFrame
    //     0xd43f0c: mov             SP, fp
    //     0xd43f10: ldp             fp, lr, [SP], #0x10
    // 0xd43f14: ret
    //     0xd43f14: ret             
    // 0xd43f18: r16 = "hue"
    //     0xd43f18: add             x16, PP, #0x26, lsl #12  ; [pp+0x261b0] "hue"
    //     0xd43f1c: ldr             x16, [x16, #0x1b0]
    // 0xd43f20: str             x16, [SP]
    // 0xd43f24: r0 = _throwLocalNotInitialized()
    //     0xd43f24: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xd43f28: brk             #0
    // 0xd43f2c: r0 = StackOverflowSharedWithFPURegs()
    //     0xd43f2c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd43f30: b               #0xd43da4
    // 0xd43f34: SaveReg d1
    //     0xd43f34: str             q1, [SP, #-0x10]!
    // 0xd43f38: r0 = AllocateDouble()
    //     0xd43f38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43f3c: RestoreReg d1
    //     0xd43f3c: ldr             q1, [SP], #0x10
    // 0xd43f40: b               #0xd43e44
    // 0xd43f44: SaveReg d0
    //     0xd43f44: str             q0, [SP, #-0x10]!
    // 0xd43f48: r0 = AllocateDouble()
    //     0xd43f48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43f4c: RestoreReg d0
    //     0xd43f4c: ldr             q0, [SP], #0x10
    // 0xd43f50: b               #0xd43e98
    // 0xd43f54: SaveReg d0
    //     0xd43f54: str             q0, [SP, #-0x10]!
    // 0xd43f58: r0 = AllocateDouble()
    //     0xd43f58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd43f5c: RestoreReg d0
    //     0xd43f5c: ldr             q0, [SP], #0x10
    // 0xd43f60: b               #0xd43ee4
  }
}

// class id: 2946, size: 0x28, field offset: 0x8
//   const constructor, 
class HSLColor extends Object {

  _ toColor(/* No info */) {
    // ** addr: 0xd43270, size: 0x150
    // 0xd43270: EnterFrame
    //     0xd43270: stp             fp, lr, [SP, #-0x10]!
    //     0xd43274: mov             fp, SP
    // 0xd43278: AllocStack(0x18)
    //     0xd43278: sub             SP, SP, #0x18
    // 0xd4327c: d4 = 2.000000
    //     0xd4327c: fmov            d4, #2.00000000
    // 0xd43280: d3 = 1.000000
    //     0xd43280: fmov            d3, #1.00000000
    // 0xd43284: d2 = 0.000000
    //     0xd43284: eor             v2.16b, v2.16b, v2.16b
    // 0xd43288: mov             x19, x1
    // 0xd4328c: CheckStackOverflow
    //     0xd4328c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd43290: cmp             SP, x16
    //     0xd43294: b.ls            #0xd433b8
    // 0xd43298: LoadField: d5 = r19->field_1f
    //     0xd43298: ldur            d5, [x19, #0x1f]
    // 0xd4329c: stur            d5, [fp, #-0x18]
    // 0xd432a0: fmul            d0, d5, d4
    // 0xd432a4: fsub            d1, d0, d3
    // 0xd432a8: fcmp            d1, d2
    // 0xd432ac: b.ne            #0xd432b8
    // 0xd432b0: d1 = 0.000000
    //     0xd432b0: eor             v1.16b, v1.16b, v1.16b
    // 0xd432b4: b               #0xd432d0
    // 0xd432b8: fcmp            d2, d1
    // 0xd432bc: b.le            #0xd432c8
    // 0xd432c0: fneg            d0, d1
    // 0xd432c4: b               #0xd432cc
    // 0xd432c8: mov             v0.16b, v1.16b
    // 0xd432cc: mov             v1.16b, v0.16b
    // 0xd432d0: d0 = 60.000000
    //     0xd432d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13358] IMM: double(60) from 0x404e000000000000
    //     0xd432d4: ldr             d0, [x17, #0x358]
    // 0xd432d8: fsub            d6, d3, d1
    // 0xd432dc: ArrayLoad: d1 = r19[0]  ; List_8
    //     0xd432dc: ldur            d1, [x19, #0x17]
    // 0xd432e0: fmul            d7, d6, d1
    // 0xd432e4: stur            d7, [fp, #-0x10]
    // 0xd432e8: LoadField: d6 = r19->field_f
    //     0xd432e8: ldur            d6, [x19, #0xf]
    // 0xd432ec: stur            d6, [fp, #-8]
    // 0xd432f0: fdiv            d1, d6, d0
    // 0xd432f4: mov             v0.16b, v1.16b
    // 0xd432f8: mov             v1.16b, v4.16b
    // 0xd432fc: stp             fp, lr, [SP, #-0x10]!
    // 0xd43300: mov             fp, SP
    // 0xd43304: CallRuntime_DartModulo(double, double) -> double
    //     0xd43304: and             SP, SP, #0xfffffffffffffff0
    //     0xd43308: mov             sp, SP
    //     0xd4330c: ldr             x16, [THR, #0x748]  ; THR::DartModulo
    //     0xd43310: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43314: blr             x16
    //     0xd43318: mov             x16, #8
    //     0xd4331c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd43320: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd43324: sub             sp, x16, #1, lsl #12
    //     0xd43328: mov             SP, fp
    //     0xd4332c: ldp             fp, lr, [SP], #0x10
    // 0xd43330: mov             v1.16b, v0.16b
    // 0xd43334: d0 = 1.000000
    //     0xd43334: fmov            d0, #1.00000000
    // 0xd43338: fsub            d2, d1, d0
    // 0xd4333c: d1 = 0.000000
    //     0xd4333c: eor             v1.16b, v1.16b, v1.16b
    // 0xd43340: fcmp            d2, d1
    // 0xd43344: b.ne            #0xd43350
    // 0xd43348: d4 = 0.000000
    //     0xd43348: eor             v4.16b, v4.16b, v4.16b
    // 0xd4334c: b               #0xd43368
    // 0xd43350: fcmp            d1, d2
    // 0xd43354: b.le            #0xd43360
    // 0xd43358: fneg            d1, d2
    // 0xd4335c: b               #0xd43364
    // 0xd43360: mov             v1.16b, v2.16b
    // 0xd43364: mov             v4.16b, v1.16b
    // 0xd43368: ldur            d2, [fp, #-0x18]
    // 0xd4336c: ldur            d3, [fp, #-0x10]
    // 0xd43370: d1 = 2.000000
    //     0xd43370: fmov            d1, #2.00000000
    // 0xd43374: fsub            d5, d0, d4
    // 0xd43378: fmul            d0, d3, d5
    // 0xd4337c: fdiv            d4, d3, d1
    // 0xd43380: fsub            d1, d2, d4
    // 0xd43384: LoadField: d2 = r19->field_7
    //     0xd43384: ldur            d2, [x19, #7]
    // 0xd43388: mov             v31.16b, v3.16b
    // 0xd4338c: mov             v3.16b, v2.16b
    // 0xd43390: mov             v2.16b, v31.16b
    // 0xd43394: mov             v31.16b, v0.16b
    // 0xd43398: mov             v0.16b, v3.16b
    // 0xd4339c: mov             v3.16b, v31.16b
    // 0xd433a0: mov             v4.16b, v1.16b
    // 0xd433a4: ldur            d1, [fp, #-8]
    // 0xd433a8: r0 = _colorFromHue()
    //     0xd433a8: bl              #0xd433c0  ; [package:flutter/src/painting/colors.dart] ::_colorFromHue
    // 0xd433ac: LeaveFrame
    //     0xd433ac: mov             SP, fp
    //     0xd433b0: ldp             fp, lr, [SP], #0x10
    // 0xd433b4: ret
    //     0xd433b4: ret             
    // 0xd433b8: r0 = StackOverflowSharedWithFPURegs()
    //     0xd433b8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd433bc: b               #0xd43298
  }
  _ withSaturation(/* No info */) {
    // ** addr: 0xd43ad0, size: 0x58
    // 0xd43ad0: EnterFrame
    //     0xd43ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xd43ad4: mov             fp, SP
    // 0xd43ad8: AllocStack(0x18)
    //     0xd43ad8: sub             SP, SP, #0x18
    // 0xd43adc: LoadField: d0 = r1->field_7
    //     0xd43adc: ldur            d0, [x1, #7]
    // 0xd43ae0: stur            d0, [fp, #-0x18]
    // 0xd43ae4: LoadField: d1 = r1->field_f
    //     0xd43ae4: ldur            d1, [x1, #0xf]
    // 0xd43ae8: stur            d1, [fp, #-0x10]
    // 0xd43aec: LoadField: d2 = r1->field_1f
    //     0xd43aec: ldur            d2, [x1, #0x1f]
    // 0xd43af0: stur            d2, [fp, #-8]
    // 0xd43af4: r0 = HSLColor()
    //     0xd43af4: bl              #0xd43b28  ; AllocateHSLColorStub -> HSLColor (size=0x28)
    // 0xd43af8: ldur            d0, [fp, #-0x18]
    // 0xd43afc: StoreField: r0->field_7 = d0
    //     0xd43afc: stur            d0, [x0, #7]
    // 0xd43b00: ldur            d0, [fp, #-0x10]
    // 0xd43b04: StoreField: r0->field_f = d0
    //     0xd43b04: stur            d0, [x0, #0xf]
    // 0xd43b08: d0 = 0.835000
    //     0xd43b08: add             x17, PP, #0x26, lsl #12  ; [pp+0x261a8] IMM: double(0.835) from 0x3feab851eb851eb8
    //     0xd43b0c: ldr             d0, [x17, #0x1a8]
    // 0xd43b10: ArrayStore: r0[0] = d0  ; List_8
    //     0xd43b10: stur            d0, [x0, #0x17]
    // 0xd43b14: ldur            d0, [fp, #-8]
    // 0xd43b18: StoreField: r0->field_1f = d0
    //     0xd43b18: stur            d0, [x0, #0x1f]
    // 0xd43b1c: LeaveFrame
    //     0xd43b1c: mov             SP, fp
    //     0xd43b20: ldp             fp, lr, [SP], #0x10
    // 0xd43b24: ret
    //     0xd43b24: ret             
  }
  _ withLightness(/* No info */) {
    // ** addr: 0xd43b34, size: 0x58
    // 0xd43b34: EnterFrame
    //     0xd43b34: stp             fp, lr, [SP, #-0x10]!
    //     0xd43b38: mov             fp, SP
    // 0xd43b3c: AllocStack(0x18)
    //     0xd43b3c: sub             SP, SP, #0x18
    // 0xd43b40: LoadField: d0 = r1->field_7
    //     0xd43b40: ldur            d0, [x1, #7]
    // 0xd43b44: stur            d0, [fp, #-0x18]
    // 0xd43b48: LoadField: d1 = r1->field_f
    //     0xd43b48: ldur            d1, [x1, #0xf]
    // 0xd43b4c: stur            d1, [fp, #-0x10]
    // 0xd43b50: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xd43b50: ldur            d2, [x1, #0x17]
    // 0xd43b54: stur            d2, [fp, #-8]
    // 0xd43b58: r0 = HSLColor()
    //     0xd43b58: bl              #0xd43b28  ; AllocateHSLColorStub -> HSLColor (size=0x28)
    // 0xd43b5c: ldur            d0, [fp, #-0x18]
    // 0xd43b60: StoreField: r0->field_7 = d0
    //     0xd43b60: stur            d0, [x0, #7]
    // 0xd43b64: ldur            d0, [fp, #-0x10]
    // 0xd43b68: StoreField: r0->field_f = d0
    //     0xd43b68: stur            d0, [x0, #0xf]
    // 0xd43b6c: ldur            d0, [fp, #-8]
    // 0xd43b70: ArrayStore: r0[0] = d0  ; List_8
    //     0xd43b70: stur            d0, [x0, #0x17]
    // 0xd43b74: d0 = 0.690000
    //     0xd43b74: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e8] IMM: double(0.69) from 0x3fe6147ae147ae14
    //     0xd43b78: ldr             d0, [x17, #0x1e8]
    // 0xd43b7c: StoreField: r0->field_1f = d0
    //     0xd43b7c: stur            d0, [x0, #0x1f]
    // 0xd43b80: LeaveFrame
    //     0xd43b80: mov             SP, fp
    //     0xd43b84: ldp             fp, lr, [SP], #0x10
    // 0xd43b88: ret
    //     0xd43b88: ret             
  }
  factory _ HSLColor.fromColor(/* No info */) {
    // ** addr: 0xd43b8c, size: 0x1fc
    // 0xd43b8c: EnterFrame
    //     0xd43b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xd43b90: mov             fp, SP
    // 0xd43b94: AllocStack(0x40)
    //     0xd43b94: sub             SP, SP, #0x40
    // 0xd43b98: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd43b98: stur            x2, [fp, #-8]
    // 0xd43b9c: CheckStackOverflow
    //     0xd43b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd43ba0: cmp             SP, x16
    //     0xd43ba4: b.ls            #0xd43d80
    // 0xd43ba8: r0 = LoadClassIdInstr(r2)
    //     0xd43ba8: ldur            x0, [x2, #-1]
    //     0xd43bac: ubfx            x0, x0, #0xc, #0x14
    // 0xd43bb0: mov             x1, x2
    // 0xd43bb4: r0 = GDT[cid_x0 + 0x30c2]()
    //     0xd43bb4: mov             x17, #0x30c2
    //     0xd43bb8: add             lr, x0, x17
    //     0xd43bbc: ldr             lr, [x21, lr, lsl #3]
    //     0xd43bc0: blr             lr
    // 0xd43bc4: scvtf           d0, x0
    // 0xd43bc8: d1 = 255.000000
    //     0xd43bc8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43bcc: fdiv            d2, d0, d1
    // 0xd43bd0: ldur            x2, [fp, #-8]
    // 0xd43bd4: stur            d2, [fp, #-0x10]
    // 0xd43bd8: r0 = LoadClassIdInstr(r2)
    //     0xd43bd8: ldur            x0, [x2, #-1]
    //     0xd43bdc: ubfx            x0, x0, #0xc, #0x14
    // 0xd43be0: mov             x1, x2
    // 0xd43be4: r0 = GDT[cid_x0 + 0x343f]()
    //     0xd43be4: mov             x17, #0x343f
    //     0xd43be8: add             lr, x0, x17
    //     0xd43bec: ldr             lr, [x21, lr, lsl #3]
    //     0xd43bf0: blr             lr
    // 0xd43bf4: scvtf           d0, x0
    // 0xd43bf8: d1 = 255.000000
    //     0xd43bf8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43bfc: fdiv            d2, d0, d1
    // 0xd43c00: ldur            x2, [fp, #-8]
    // 0xd43c04: stur            d2, [fp, #-0x18]
    // 0xd43c08: r0 = LoadClassIdInstr(r2)
    //     0xd43c08: ldur            x0, [x2, #-1]
    //     0xd43c0c: ubfx            x0, x0, #0xc, #0x14
    // 0xd43c10: mov             x1, x2
    // 0xd43c14: r0 = GDT[cid_x0 + 0x362a]()
    //     0xd43c14: mov             x17, #0x362a
    //     0xd43c18: add             lr, x0, x17
    //     0xd43c1c: ldr             lr, [x21, lr, lsl #3]
    //     0xd43c20: blr             lr
    // 0xd43c24: scvtf           d0, x0
    // 0xd43c28: d1 = 255.000000
    //     0xd43c28: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43c2c: fdiv            d2, d0, d1
    // 0xd43c30: ldur            d0, [fp, #-0x18]
    // 0xd43c34: stur            d2, [fp, #-0x38]
    // 0xd43c38: fmax            v3.2d, v0.2d, v2.2d
    // 0xd43c3c: ldur            d4, [fp, #-0x10]
    // 0xd43c40: fmax            v5.2d, v4.2d, v3.2d
    // 0xd43c44: stur            d5, [fp, #-0x30]
    // 0xd43c48: fmin            v3.2d, v0.2d, v2.2d
    // 0xd43c4c: fmin            v6.2d, v4.2d, v3.2d
    // 0xd43c50: stur            d6, [fp, #-0x28]
    // 0xd43c54: fsub            d3, d5, d6
    // 0xd43c58: ldur            x1, [fp, #-8]
    // 0xd43c5c: stur            d3, [fp, #-0x20]
    // 0xd43c60: r0 = LoadClassIdInstr(r1)
    //     0xd43c60: ldur            x0, [x1, #-1]
    //     0xd43c64: ubfx            x0, x0, #0xc, #0x14
    // 0xd43c68: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd43c68: sub             lr, x0, #0xfc0
    //     0xd43c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xd43c70: blr             lr
    // 0xd43c74: scvtf           d0, x0
    // 0xd43c78: d1 = 255.000000
    //     0xd43c78: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0xd43c7c: fdiv            d5, d0, d1
    // 0xd43c80: ldur            d0, [fp, #-0x10]
    // 0xd43c84: ldur            d1, [fp, #-0x18]
    // 0xd43c88: ldur            d2, [fp, #-0x38]
    // 0xd43c8c: ldur            d3, [fp, #-0x30]
    // 0xd43c90: ldur            d4, [fp, #-0x20]
    // 0xd43c94: stur            d5, [fp, #-0x40]
    // 0xd43c98: r0 = _getHue()
    //     0xd43c98: bl              #0xd43d88  ; [package:flutter/src/painting/colors.dart] ::_getHue
    // 0xd43c9c: mov             v2.16b, v0.16b
    // 0xd43ca0: ldur            d0, [fp, #-0x30]
    // 0xd43ca4: ldur            d1, [fp, #-0x28]
    // 0xd43ca8: stur            d2, [fp, #-0x38]
    // 0xd43cac: fadd            d3, d0, d1
    // 0xd43cb0: d4 = 2.000000
    //     0xd43cb0: fmov            d4, #2.00000000
    // 0xd43cb4: fdiv            d5, d3, d4
    // 0xd43cb8: stur            d5, [fp, #-0x18]
    // 0xd43cbc: fcmp            d1, d0
    // 0xd43cc0: b.ne            #0xd43ccc
    // 0xd43cc4: d1 = 0.000000
    //     0xd43cc4: eor             v1.16b, v1.16b, v1.16b
    // 0xd43cc8: b               #0xd43d48
    // 0xd43ccc: d1 = 0.000000
    //     0xd43ccc: eor             v1.16b, v1.16b, v1.16b
    // 0xd43cd0: d0 = 1.000000
    //     0xd43cd0: fmov            d0, #1.00000000
    // 0xd43cd4: fmul            d3, d5, d4
    // 0xd43cd8: fsub            d4, d3, d0
    // 0xd43cdc: fcmp            d4, d1
    // 0xd43ce0: b.ne            #0xd43cec
    // 0xd43ce4: d4 = 0.000000
    //     0xd43ce4: eor             v4.16b, v4.16b, v4.16b
    // 0xd43ce8: b               #0xd43d04
    // 0xd43cec: fcmp            d1, d4
    // 0xd43cf0: b.le            #0xd43cfc
    // 0xd43cf4: fneg            d3, d4
    // 0xd43cf8: b               #0xd43d00
    // 0xd43cfc: mov             v3.16b, v4.16b
    // 0xd43d00: mov             v4.16b, v3.16b
    // 0xd43d04: ldur            d3, [fp, #-0x20]
    // 0xd43d08: fsub            d6, d0, d4
    // 0xd43d0c: fdiv            d4, d3, d6
    // 0xd43d10: fcmp            d1, d4
    // 0xd43d14: b.le            #0xd43d20
    // 0xd43d18: d0 = 0.000000
    //     0xd43d18: eor             v0.16b, v0.16b, v0.16b
    // 0xd43d1c: b               #0xd43d44
    // 0xd43d20: fcmp            d4, d0
    // 0xd43d24: b.le            #0xd43d30
    // 0xd43d28: d0 = 1.000000
    //     0xd43d28: fmov            d0, #1.00000000
    // 0xd43d2c: b               #0xd43d44
    // 0xd43d30: fcmp            d4, d4
    // 0xd43d34: b.vc            #0xd43d40
    // 0xd43d38: d0 = 1.000000
    //     0xd43d38: fmov            d0, #1.00000000
    // 0xd43d3c: b               #0xd43d44
    // 0xd43d40: mov             v0.16b, v4.16b
    // 0xd43d44: mov             v1.16b, v0.16b
    // 0xd43d48: ldur            d0, [fp, #-0x40]
    // 0xd43d4c: stur            d1, [fp, #-0x10]
    // 0xd43d50: r0 = HSLColor()
    //     0xd43d50: bl              #0xd43b28  ; AllocateHSLColorStub -> HSLColor (size=0x28)
    // 0xd43d54: ldur            d0, [fp, #-0x40]
    // 0xd43d58: StoreField: r0->field_7 = d0
    //     0xd43d58: stur            d0, [x0, #7]
    // 0xd43d5c: ldur            d0, [fp, #-0x38]
    // 0xd43d60: StoreField: r0->field_f = d0
    //     0xd43d60: stur            d0, [x0, #0xf]
    // 0xd43d64: ldur            d0, [fp, #-0x10]
    // 0xd43d68: ArrayStore: r0[0] = d0  ; List_8
    //     0xd43d68: stur            d0, [x0, #0x17]
    // 0xd43d6c: ldur            d0, [fp, #-0x18]
    // 0xd43d70: StoreField: r0->field_1f = d0
    //     0xd43d70: stur            d0, [x0, #0x1f]
    // 0xd43d74: LeaveFrame
    //     0xd43d74: mov             SP, fp
    //     0xd43d78: ldp             fp, lr, [SP], #0x10
    // 0xd43d7c: ret
    //     0xd43d7c: ret             
    // 0xd43d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd43d80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd43d84: b               #0xd43ba8
  }
  _ ==(/* No info */) {
    // ** addr: 0x12987c8, size: 0x98
    // 0x12987c8: ldr             x1, [SP]
    // 0x12987cc: cmp             w1, NULL
    // 0x12987d0: b.ne            #0x12987dc
    // 0x12987d4: r0 = false
    //     0x12987d4: add             x0, NULL, #0x30  ; false
    // 0x12987d8: ret
    //     0x12987d8: ret             
    // 0x12987dc: ldr             x2, [SP, #8]
    // 0x12987e0: cmp             w2, w1
    // 0x12987e4: b.ne            #0x12987f0
    // 0x12987e8: r0 = true
    //     0x12987e8: add             x0, NULL, #0x20  ; true
    // 0x12987ec: ret
    //     0x12987ec: ret             
    // 0x12987f0: r3 = 60
    //     0x12987f0: mov             x3, #0x3c
    // 0x12987f4: branchIfSmi(r1, 0x1298800)
    //     0x12987f4: tbz             w1, #0, #0x1298800
    // 0x12987f8: r3 = LoadClassIdInstr(r1)
    //     0x12987f8: ldur            x3, [x1, #-1]
    //     0x12987fc: ubfx            x3, x3, #0xc, #0x14
    // 0x1298800: cmp             x3, #0xb82
    // 0x1298804: b.ne            #0x1298858
    // 0x1298808: LoadField: d0 = r1->field_7
    //     0x1298808: ldur            d0, [x1, #7]
    // 0x129880c: LoadField: d1 = r2->field_7
    //     0x129880c: ldur            d1, [x2, #7]
    // 0x1298810: fcmp            d0, d1
    // 0x1298814: b.ne            #0x1298858
    // 0x1298818: LoadField: d0 = r1->field_f
    //     0x1298818: ldur            d0, [x1, #0xf]
    // 0x129881c: LoadField: d1 = r2->field_f
    //     0x129881c: ldur            d1, [x2, #0xf]
    // 0x1298820: fcmp            d0, d1
    // 0x1298824: b.ne            #0x1298858
    // 0x1298828: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1298828: ldur            d0, [x1, #0x17]
    // 0x129882c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x129882c: ldur            d1, [x2, #0x17]
    // 0x1298830: fcmp            d0, d1
    // 0x1298834: b.ne            #0x1298858
    // 0x1298838: LoadField: d0 = r1->field_1f
    //     0x1298838: ldur            d0, [x1, #0x1f]
    // 0x129883c: LoadField: d1 = r2->field_1f
    //     0x129883c: ldur            d1, [x2, #0x1f]
    // 0x1298840: fcmp            d0, d1
    // 0x1298844: r16 = true
    //     0x1298844: add             x16, NULL, #0x20  ; true
    // 0x1298848: r17 = false
    //     0x1298848: add             x17, NULL, #0x30  ; false
    // 0x129884c: csel            x1, x16, x17, eq
    // 0x1298850: mov             x0, x1
    // 0x1298854: b               #0x129885c
    // 0x1298858: r0 = false
    //     0x1298858: add             x0, NULL, #0x30  ; false
    // 0x129885c: ret
    //     0x129885c: ret             
  }
}

// class id: 3791, size: 0x34, field offset: 0x2c
//   const constructor, 
abstract class ColorSwatch<X0> extends Color {

  Color? [](ColorSwatch<X0>, X0) {
    // ** addr: 0x8abce8, size: 0x94
    // 0x8abce8: EnterFrame
    //     0x8abce8: stp             fp, lr, [SP, #-0x10]!
    //     0x8abcec: mov             fp, SP
    // 0x8abcf0: AllocStack(0x10)
    //     0x8abcf0: sub             SP, SP, #0x10
    // 0x8abcf4: SetupParameters(ColorSwatch<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8abcf4: mov             x4, x1
    //     0x8abcf8: mov             x3, x2
    //     0x8abcfc: stur            x1, [fp, #-8]
    //     0x8abd00: stur            x2, [fp, #-0x10]
    // 0x8abd04: CheckStackOverflow
    //     0x8abd04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abd08: cmp             SP, x16
    //     0x8abd0c: b.ls            #0x8abd74
    // 0x8abd10: LoadField: r2 = r4->field_2b
    //     0x8abd10: ldur            w2, [x4, #0x2b]
    // 0x8abd14: DecompressPointer r2
    //     0x8abd14: add             x2, x2, HEAP, lsl #32
    // 0x8abd18: mov             x0, x3
    // 0x8abd1c: r1 = Null
    //     0x8abd1c: mov             x1, NULL
    // 0x8abd20: cmp             w2, NULL
    // 0x8abd24: b.eq            #0x8abd44
    // 0x8abd28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8abd28: ldur            w4, [x2, #0x17]
    // 0x8abd2c: DecompressPointer r4
    //     0x8abd2c: add             x4, x4, HEAP, lsl #32
    // 0x8abd30: r8 = X0
    //     0x8abd30: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8abd34: LoadField: r9 = r4->field_7
    //     0x8abd34: ldur            x9, [x4, #7]
    // 0x8abd38: r3 = Null
    //     0x8abd38: add             x3, PP, #0x26, lsl #12  ; [pp+0x26070] Null
    //     0x8abd3c: ldr             x3, [x3, #0x70]
    // 0x8abd40: blr             x9
    // 0x8abd44: ldur            x0, [fp, #-8]
    // 0x8abd48: LoadField: r1 = r0->field_2f
    //     0x8abd48: ldur            w1, [x0, #0x2f]
    // 0x8abd4c: DecompressPointer r1
    //     0x8abd4c: add             x1, x1, HEAP, lsl #32
    // 0x8abd50: r0 = LoadClassIdInstr(r1)
    //     0x8abd50: ldur            x0, [x1, #-1]
    //     0x8abd54: ubfx            x0, x0, #0xc, #0x14
    // 0x8abd58: ldur            x2, [fp, #-0x10]
    // 0x8abd5c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8abd5c: sub             lr, x0, #0xd48
    //     0x8abd60: ldr             lr, [x21, lr, lsl #3]
    //     0x8abd64: blr             lr
    // 0x8abd68: LeaveFrame
    //     0x8abd68: mov             SP, fp
    //     0x8abd6c: ldp             fp, lr, [SP], #0x10
    // 0x8abd70: ret
    //     0x8abd70: ret             
    // 0x8abd74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abd74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abd78: b               #0x8abd10
  }
  Color? [](ColorSwatch<X0>, X0) {
    // ** addr: 0x8abd94, size: 0x4c
    // 0x8abd94: EnterFrame
    //     0x8abd94: stp             fp, lr, [SP, #-0x10]!
    //     0x8abd98: mov             fp, SP
    // 0x8abd9c: CheckStackOverflow
    //     0x8abd9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abda0: cmp             SP, x16
    //     0x8abda4: b.ls            #0x8abdc0
    // 0x8abda8: ldr             x1, [fp, #0x18]
    // 0x8abdac: ldr             x2, [fp, #0x10]
    // 0x8abdb0: r0 = []()
    //     0x8abdb0: bl              #0x8abce8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::[]
    // 0x8abdb4: LeaveFrame
    //     0x8abdb4: mov             SP, fp
    //     0x8abdb8: ldp             fp, lr, [SP], #0x10
    // 0x8abdbc: ret
    //     0x8abdbc: ret             
    // 0x8abdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abdc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abdc4: b               #0x8abda8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1147e54, size: 0x94
    // 0x1147e54: EnterFrame
    //     0x1147e54: stp             fp, lr, [SP, #-0x10]!
    //     0x1147e58: mov             fp, SP
    // 0x1147e5c: AllocStack(0x10)
    //     0x1147e5c: sub             SP, SP, #0x10
    // 0x1147e60: CheckStackOverflow
    //     0x1147e60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1147e64: cmp             SP, x16
    //     0x1147e68: b.ls            #0x1147ee0
    // 0x1147e6c: ldr             x16, [fp, #0x10]
    // 0x1147e70: str             x16, [SP]
    // 0x1147e74: r0 = runtimeType()
    //     0x1147e74: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1147e78: ldr             x1, [fp, #0x10]
    // 0x1147e7c: stur            x0, [fp, #-8]
    // 0x1147e80: r0 = toARGB32()
    //     0x1147e80: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0x1147e84: mov             x2, x0
    // 0x1147e88: ldr             x0, [fp, #0x10]
    // 0x1147e8c: LoadField: r3 = r0->field_2f
    //     0x1147e8c: ldur            w3, [x0, #0x2f]
    // 0x1147e90: DecompressPointer r3
    //     0x1147e90: add             x3, x3, HEAP, lsl #32
    // 0x1147e94: r0 = BoxInt64Instr(r2)
    //     0x1147e94: sbfiz           x0, x2, #1, #0x1f
    //     0x1147e98: cmp             x2, x0, asr #1
    //     0x1147e9c: b.eq            #0x1147ea8
    //     0x1147ea0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1147ea4: stur            x2, [x0, #7]
    // 0x1147ea8: str             x3, [SP]
    // 0x1147eac: ldur            x1, [fp, #-8]
    // 0x1147eb0: mov             x2, x0
    // 0x1147eb4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1147eb4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x1147eb8: r0 = hash()
    //     0x1147eb8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1147ebc: mov             x2, x0
    // 0x1147ec0: r0 = BoxInt64Instr(r2)
    //     0x1147ec0: sbfiz           x0, x2, #1, #0x1f
    //     0x1147ec4: cmp             x2, x0, asr #1
    //     0x1147ec8: b.eq            #0x1147ed4
    //     0x1147ecc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1147ed0: stur            x2, [x0, #7]
    // 0x1147ed4: LeaveFrame
    //     0x1147ed4: mov             SP, fp
    //     0x1147ed8: ldp             fp, lr, [SP], #0x10
    // 0x1147edc: ret
    //     0x1147edc: ret             
    // 0x1147ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147ee0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147ee4: b               #0x1147e6c
  }
  _ ==(/* No info */) {
    // ** addr: 0x128c158, size: 0x168
    // 0x128c158: EnterFrame
    //     0x128c158: stp             fp, lr, [SP, #-0x10]!
    //     0x128c15c: mov             fp, SP
    // 0x128c160: AllocStack(0x20)
    //     0x128c160: sub             SP, SP, #0x20
    // 0x128c164: CheckStackOverflow
    //     0x128c164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x128c168: cmp             SP, x16
    //     0x128c16c: b.ls            #0x128c2b8
    // 0x128c170: ldr             x0, [fp, #0x10]
    // 0x128c174: cmp             w0, NULL
    // 0x128c178: b.ne            #0x128c18c
    // 0x128c17c: r0 = false
    //     0x128c17c: add             x0, NULL, #0x30  ; false
    // 0x128c180: LeaveFrame
    //     0x128c180: mov             SP, fp
    //     0x128c184: ldp             fp, lr, [SP], #0x10
    // 0x128c188: ret
    //     0x128c188: ret             
    // 0x128c18c: ldr             x1, [fp, #0x18]
    // 0x128c190: cmp             w1, w0
    // 0x128c194: b.ne            #0x128c1a8
    // 0x128c198: r0 = true
    //     0x128c198: add             x0, NULL, #0x20  ; true
    // 0x128c19c: LeaveFrame
    //     0x128c19c: mov             SP, fp
    //     0x128c1a0: ldp             fp, lr, [SP], #0x10
    // 0x128c1a4: ret
    //     0x128c1a4: ret             
    // 0x128c1a8: stp             x1, x0, [SP]
    // 0x128c1ac: r0 = _haveSameRuntimeType()
    //     0x128c1ac: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x128c1b0: tbz             w0, #4, #0x128c1c4
    // 0x128c1b4: r0 = false
    //     0x128c1b4: add             x0, NULL, #0x30  ; false
    // 0x128c1b8: LeaveFrame
    //     0x128c1b8: mov             SP, fp
    //     0x128c1bc: ldp             fp, lr, [SP], #0x10
    // 0x128c1c0: ret
    //     0x128c1c0: ret             
    // 0x128c1c4: ldr             x16, [fp, #0x18]
    // 0x128c1c8: ldr             lr, [fp, #0x10]
    // 0x128c1cc: stp             lr, x16, [SP]
    // 0x128c1d0: r0 = ==()
    //     0x128c1d0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x128c1d4: tbnz            w0, #4, #0x128c2a8
    // 0x128c1d8: ldr             x3, [fp, #0x18]
    // 0x128c1dc: LoadField: r4 = r3->field_2b
    //     0x128c1dc: ldur            w4, [x3, #0x2b]
    // 0x128c1e0: DecompressPointer r4
    //     0x128c1e0: add             x4, x4, HEAP, lsl #32
    // 0x128c1e4: ldr             x0, [fp, #0x10]
    // 0x128c1e8: mov             x2, x4
    // 0x128c1ec: stur            x4, [fp, #-8]
    // 0x128c1f0: r1 = Null
    //     0x128c1f0: mov             x1, NULL
    // 0x128c1f4: cmp             w0, NULL
    // 0x128c1f8: b.eq            #0x128c244
    // 0x128c1fc: branchIfSmi(r0, 0x128c244)
    //     0x128c1fc: tbz             w0, #0, #0x128c244
    // 0x128c200: r3 = SubtypeTestCache
    //     0x128c200: add             x3, PP, #0x26, lsl #12  ; [pp+0x26050] SubtypeTestCache
    //     0x128c204: ldr             x3, [x3, #0x50]
    // 0x128c208: r30 = Subtype3TestCacheStub
    //     0x128c208: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x128c20c: LoadField: r30 = r30->field_7
    //     0x128c20c: ldur            lr, [lr, #7]
    // 0x128c210: blr             lr
    // 0x128c214: cmp             w7, NULL
    // 0x128c218: b.eq            #0x128c224
    // 0x128c21c: tbnz            w7, #4, #0x128c244
    // 0x128c220: b               #0x128c24c
    // 0x128c224: r8 = ColorSwatch<X0>
    //     0x128c224: add             x8, PP, #0x26, lsl #12  ; [pp+0x26058] Type: ColorSwatch<X0>
    //     0x128c228: ldr             x8, [x8, #0x58]
    // 0x128c22c: r3 = SubtypeTestCache
    //     0x128c22c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26060] SubtypeTestCache
    //     0x128c230: ldr             x3, [x3, #0x60]
    // 0x128c234: r30 = InstanceOfStub
    //     0x128c234: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x128c238: LoadField: r30 = r30->field_7
    //     0x128c238: ldur            lr, [lr, #7]
    // 0x128c23c: blr             lr
    // 0x128c240: b               #0x128c250
    // 0x128c244: r0 = false
    //     0x128c244: add             x0, NULL, #0x30  ; false
    // 0x128c248: b               #0x128c250
    // 0x128c24c: r0 = true
    //     0x128c24c: add             x0, NULL, #0x20  ; true
    // 0x128c250: tbnz            w0, #4, #0x128c2a8
    // 0x128c254: ldr             x0, [fp, #0x18]
    // 0x128c258: ldr             x4, [fp, #0x10]
    // 0x128c25c: ldur            x2, [fp, #-8]
    // 0x128c260: r1 = Null
    //     0x128c260: mov             x1, NULL
    // 0x128c264: r3 = <X0, Color>
    //     0x128c264: add             x3, PP, #0x26, lsl #12  ; [pp+0x26068] TypeArguments: <X0, Color>
    //     0x128c268: ldr             x3, [x3, #0x68]
    // 0x128c26c: r30 = InstantiateTypeArgumentsStub
    //     0x128c26c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x128c270: LoadField: r30 = r30->field_7
    //     0x128c270: ldur            lr, [lr, #7]
    // 0x128c274: blr             lr
    // 0x128c278: mov             x1, x0
    // 0x128c27c: ldr             x0, [fp, #0x10]
    // 0x128c280: LoadField: r2 = r0->field_2f
    //     0x128c280: ldur            w2, [x0, #0x2f]
    // 0x128c284: DecompressPointer r2
    //     0x128c284: add             x2, x2, HEAP, lsl #32
    // 0x128c288: ldr             x0, [fp, #0x18]
    // 0x128c28c: LoadField: r3 = r0->field_2f
    //     0x128c28c: ldur            w3, [x0, #0x2f]
    // 0x128c290: DecompressPointer r3
    //     0x128c290: add             x3, x3, HEAP, lsl #32
    // 0x128c294: stp             x2, x1, [SP, #8]
    // 0x128c298: str             x3, [SP]
    // 0x128c29c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x128c29c: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x128c2a0: r0 = mapEquals()
    //     0x128c2a0: bl              #0xc015b8  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0x128c2a4: b               #0x128c2ac
    // 0x128c2a8: r0 = false
    //     0x128c2a8: add             x0, NULL, #0x30  ; false
    // 0x128c2ac: LeaveFrame
    //     0x128c2ac: mov             SP, fp
    //     0x128c2b0: ldp             fp, lr, [SP], #0x10
    // 0x128c2b4: ret
    //     0x128c2b4: ret             
    // 0x128c2b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x128c2b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x128c2bc: b               #0x128c170
  }
}
