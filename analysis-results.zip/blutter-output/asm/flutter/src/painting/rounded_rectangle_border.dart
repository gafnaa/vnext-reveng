// lib: , url: package:flutter/src/painting/rounded_rectangle_border.dart

// class id: 1049005, size: 0x8
class :: {
}

// class id: 3023, size: 0x24, field offset: 0xc
//   const constructor, 
abstract class _ShapeToCircleBorder<X0 bound _RRectLikeBorder> extends OutlinedBorder {

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfe38c, size: 0x38c
    // 0xbfe38c: EnterFrame
    //     0xbfe38c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfe390: mov             fp, SP
    // 0xbfe394: AllocStack(0x40)
    //     0xbfe394: sub             SP, SP, #0x40
    // 0xbfe398: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, {dynamic textDirection = Null /* r4, fp-0x8 */})
    //     0xbfe398: mov             x3, x1
    //     0xbfe39c: mov             x0, x2
    //     0xbfe3a0: stur            x1, [fp, #-0x10]
    //     0xbfe3a4: stur            x2, [fp, #-0x18]
    //     0xbfe3a8: ldur            w1, [x4, #0x13]
    //     0xbfe3ac: ldur            w2, [x4, #0x1f]
    //     0xbfe3b0: add             x2, x2, HEAP, lsl #32
    //     0xbfe3b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xbfe3b8: ldr             x16, [x16, #0x210]
    //     0xbfe3bc: cmp             w2, w16
    //     0xbfe3c0: b.ne            #0xbfe3e0
    //     0xbfe3c4: ldur            w2, [x4, #0x23]
    //     0xbfe3c8: add             x2, x2, HEAP, lsl #32
    //     0xbfe3cc: sub             w4, w1, w2
    //     0xbfe3d0: add             x1, fp, w4, sxtw #2
    //     0xbfe3d4: ldr             x1, [x1, #8]
    //     0xbfe3d8: mov             x4, x1
    //     0xbfe3dc: b               #0xbfe3e4
    //     0xbfe3e0: mov             x4, NULL
    //     0xbfe3e4: stur            x4, [fp, #-8]
    // 0xbfe3e8: CheckStackOverflow
    //     0xbfe3e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfe3ec: cmp             SP, x16
    //     0xbfe3f0: b.ls            #0xbfe6c4
    // 0xbfe3f4: mov             x1, x3
    // 0xbfe3f8: mov             x2, x0
    // 0xbfe3fc: r0 = _adjustRect()
    //     0xbfe3fc: bl              #0xbfec34  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustRect
    // 0xbfe400: ldur            x1, [fp, #-0x10]
    // 0xbfe404: ldur            x2, [fp, #-0x18]
    // 0xbfe408: ldur            x3, [fp, #-8]
    // 0xbfe40c: stur            x0, [fp, #-8]
    // 0xbfe410: r0 = _adjustBorderRadius()
    //     0xbfe410: bl              #0xbfe718  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustBorderRadius
    // 0xbfe414: mov             x4, x0
    // 0xbfe418: ldur            x0, [fp, #-0x10]
    // 0xbfe41c: stur            x4, [fp, #-0x18]
    // 0xbfe420: LoadField: r1 = r0->field_7
    //     0xbfe420: ldur            w1, [x0, #7]
    // 0xbfe424: DecompressPointer r1
    //     0xbfe424: add             x1, x1, HEAP, lsl #32
    // 0xbfe428: LoadField: d0 = r1->field_b
    //     0xbfe428: ldur            d0, [x1, #0xb]
    // 0xbfe42c: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xbfe42c: ldur            d1, [x1, #0x17]
    // 0xbfe430: r1 = inline_Allocate_Double()
    //     0xbfe430: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbfe434: add             x1, x1, #0x10
    //     0xbfe438: cmp             x2, x1
    //     0xbfe43c: b.ls            #0xbfe6cc
    //     0xbfe440: str             x1, [THR, #0x60]  ; THR::top
    //     0xbfe444: sub             x1, x1, #0xf
    //     0xbfe448: mov             x2, #0xe19c
    //     0xbfe44c: movk            x2, #3, lsl #16
    //     0xbfe450: stur            x2, [x1, #-1]
    // 0xbfe454: dmb             ishst
    // 0xbfe458: StoreField: r1->field_7 = d0
    //     0xbfe458: stur            d0, [x1, #7]
    // 0xbfe45c: r3 = inline_Allocate_Double()
    //     0xbfe45c: ldp             x3, x2, [THR, #0x60]  ; THR::top
    //     0xbfe460: add             x3, x3, #0x10
    //     0xbfe464: cmp             x2, x3
    //     0xbfe468: b.ls            #0xbfe6e8
    //     0xbfe46c: str             x3, [THR, #0x60]  ; THR::top
    //     0xbfe470: sub             x3, x3, #0xf
    //     0xbfe474: mov             x2, #0xe19c
    //     0xbfe478: movk            x2, #3, lsl #16
    //     0xbfe47c: stur            x2, [x3, #-1]
    // 0xbfe480: dmb             ishst
    // 0xbfe484: StoreField: r3->field_7 = d1
    //     0xbfe484: stur            d1, [x3, #7]
    // 0xbfe488: r2 = 0
    //     0xbfe488: mov             x2, #0
    // 0xbfe48c: r0 = lerpDouble()
    //     0xbfe48c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xbfe490: LoadField: d0 = r0->field_7
    //     0xbfe490: ldur            d0, [x0, #7]
    // 0xbfe494: fneg            d1, d0
    // 0xbfe498: ldur            x0, [fp, #-0x10]
    // 0xbfe49c: stur            d1, [fp, #-0x38]
    // 0xbfe4a0: r1 = LoadClassIdInstr(r0)
    //     0xbfe4a0: ldur            x1, [x0, #-1]
    //     0xbfe4a4: ubfx            x1, x1, #0xc, #0x14
    // 0xbfe4a8: cmp             x1, #0xbd0
    // 0xbfe4ac: b.ne            #0xbfe578
    // 0xbfe4b0: ldur            x1, [fp, #-0x18]
    // 0xbfe4b4: ldur            x2, [fp, #-8]
    // 0xbfe4b8: r0 = toRSuperellipse()
    //     0xbfe4b8: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0xbfe4bc: mov             x1, x0
    // 0xbfe4c0: ldur            d0, [fp, #-0x38]
    // 0xbfe4c4: r0 = inflate()
    //     0xbfe4c4: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0xbfe4c8: stur            x0, [fp, #-0x10]
    // 0xbfe4cc: r0 = _NativePath()
    //     0xbfe4cc: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfe4d0: mov             x1, x0
    // 0xbfe4d4: stur            x0, [fp, #-0x20]
    // 0xbfe4d8: r0 = __constructor$Method$FfiNative()
    //     0xbfe4d8: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfe4dc: ldur            x1, [fp, #-0x10]
    // 0xbfe4e0: r0 = _native()
    //     0xbfe4e0: bl              #0xaf867c  ; [dart:ui] RSuperellipse::_native
    // 0xbfe4e4: mov             x2, x0
    // 0xbfe4e8: ldur            x0, [fp, #-0x20]
    // 0xbfe4ec: stur            x2, [fp, #-0x10]
    // 0xbfe4f0: LoadField: r1 = r0->field_7
    //     0xbfe4f0: ldur            w1, [x0, #7]
    // 0xbfe4f4: DecompressPointer r1
    //     0xbfe4f4: add             x1, x1, HEAP, lsl #32
    // 0xbfe4f8: cmp             w1, NULL
    // 0xbfe4fc: b.eq            #0xbfe70c
    // 0xbfe500: LoadField: r3 = r1->field_7
    //     0xbfe500: ldur            x3, [x1, #7]
    // 0xbfe504: ldr             x1, [x3]
    // 0xbfe508: cbz             x1, #0xbfe6a4
    // 0xbfe50c: mov             x3, x1
    // 0xbfe510: stur            x3, [fp, #-0x28]
    // 0xbfe514: r1 = <Never>
    //     0xbfe514: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfe518: r0 = Pointer()
    //     0xbfe518: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfe51c: mov             x2, x0
    // 0xbfe520: ldur            x0, [fp, #-0x28]
    // 0xbfe524: stur            x2, [fp, #-0x30]
    // 0xbfe528: StoreField: r2->field_7 = r0
    //     0xbfe528: stur            x0, [x2, #7]
    // 0xbfe52c: ldur            x0, [fp, #-0x10]
    // 0xbfe530: LoadField: r1 = r0->field_7
    //     0xbfe530: ldur            w1, [x0, #7]
    // 0xbfe534: DecompressPointer r1
    //     0xbfe534: add             x1, x1, HEAP, lsl #32
    // 0xbfe538: cmp             w1, NULL
    // 0xbfe53c: b.eq            #0xbfe710
    // 0xbfe540: LoadField: r3 = r1->field_7
    //     0xbfe540: ldur            x3, [x1, #7]
    // 0xbfe544: ldr             x1, [x3]
    // 0xbfe548: mov             x3, x1
    // 0xbfe54c: stur            x3, [fp, #-0x28]
    // 0xbfe550: r1 = <Never>
    //     0xbfe550: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfe554: r0 = Pointer()
    //     0xbfe554: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfe558: mov             x1, x0
    // 0xbfe55c: ldur            x0, [fp, #-0x28]
    // 0xbfe560: StoreField: r1->field_7 = r0
    //     0xbfe560: stur            x0, [x1, #7]
    // 0xbfe564: mov             x2, x1
    // 0xbfe568: ldur            x1, [fp, #-0x30]
    // 0xbfe56c: r0 = __addRSuperellipse$Method$FfiNative()
    //     0xbfe56c: bl              #0xbfdeb4  ; [dart:ui] _NativePath::__addRSuperellipse$Method$FfiNative
    // 0xbfe570: ldur            x0, [fp, #-0x20]
    // 0xbfe574: b               #0xbfe698
    // 0xbfe578: ldur            x1, [fp, #-0x18]
    // 0xbfe57c: ldur            x2, [fp, #-8]
    // 0xbfe580: r0 = toRRect()
    //     0xbfe580: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbfe584: mov             x1, x0
    // 0xbfe588: ldur            d0, [fp, #-0x38]
    // 0xbfe58c: r0 = inflate()
    //     0xbfe58c: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0xbfe590: stur            x0, [fp, #-8]
    // 0xbfe594: r0 = _NativePath()
    //     0xbfe594: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfe598: mov             x1, x0
    // 0xbfe59c: stur            x0, [fp, #-0x10]
    // 0xbfe5a0: r0 = __constructor$Method$FfiNative()
    //     0xbfe5a0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfe5a4: ldur            x0, [fp, #-8]
    // 0xbfe5a8: LoadField: d0 = r0->field_b
    //     0xbfe5a8: ldur            d0, [x0, #0xb]
    // 0xbfe5ac: fcvt            s1, d0
    // 0xbfe5b0: stur            d1, [fp, #-0x38]
    // 0xbfe5b4: r4 = 24
    //     0xbfe5b4: mov             x4, #0x18
    // 0xbfe5b8: r0 = AllocateFloat32Array()
    //     0xbfe5b8: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbfe5bc: ldur            d0, [fp, #-0x38]
    // 0xbfe5c0: stur            x0, [fp, #-0x18]
    // 0xbfe5c4: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfe5c4: stur            s0, [x0, #0x17]
    // 0xbfe5c8: ldur            x1, [fp, #-8]
    // 0xbfe5cc: LoadField: d0 = r1->field_13
    //     0xbfe5cc: ldur            d0, [x1, #0x13]
    // 0xbfe5d0: fcvt            s1, d0
    // 0xbfe5d4: StoreField: r0->field_1b = d1
    //     0xbfe5d4: stur            s1, [x0, #0x1b]
    // 0xbfe5d8: LoadField: d0 = r1->field_1b
    //     0xbfe5d8: ldur            d0, [x1, #0x1b]
    // 0xbfe5dc: fcvt            s1, d0
    // 0xbfe5e0: StoreField: r0->field_1f = d1
    //     0xbfe5e0: stur            s1, [x0, #0x1f]
    // 0xbfe5e4: LoadField: d0 = r1->field_23
    //     0xbfe5e4: ldur            d0, [x1, #0x23]
    // 0xbfe5e8: fcvt            s1, d0
    // 0xbfe5ec: StoreField: r0->field_23 = d1
    //     0xbfe5ec: stur            s1, [x0, #0x23]
    // 0xbfe5f0: LoadField: d0 = r1->field_2b
    //     0xbfe5f0: ldur            d0, [x1, #0x2b]
    // 0xbfe5f4: fcvt            s1, d0
    // 0xbfe5f8: StoreField: r0->field_27 = d1
    //     0xbfe5f8: stur            s1, [x0, #0x27]
    // 0xbfe5fc: LoadField: d0 = r1->field_33
    //     0xbfe5fc: ldur            d0, [x1, #0x33]
    // 0xbfe600: fcvt            s1, d0
    // 0xbfe604: StoreField: r0->field_2b = d1
    //     0xbfe604: stur            s1, [x0, #0x2b]
    // 0xbfe608: LoadField: d0 = r1->field_3b
    //     0xbfe608: ldur            d0, [x1, #0x3b]
    // 0xbfe60c: fcvt            s1, d0
    // 0xbfe610: StoreField: r0->field_2f = d1
    //     0xbfe610: stur            s1, [x0, #0x2f]
    // 0xbfe614: LoadField: d0 = r1->field_43
    //     0xbfe614: ldur            d0, [x1, #0x43]
    // 0xbfe618: fcvt            s1, d0
    // 0xbfe61c: StoreField: r0->field_33 = d1
    //     0xbfe61c: stur            s1, [x0, #0x33]
    // 0xbfe620: LoadField: d0 = r1->field_4b
    //     0xbfe620: ldur            d0, [x1, #0x4b]
    // 0xbfe624: fcvt            s1, d0
    // 0xbfe628: StoreField: r0->field_37 = d1
    //     0xbfe628: stur            s1, [x0, #0x37]
    // 0xbfe62c: LoadField: d0 = r1->field_53
    //     0xbfe62c: ldur            d0, [x1, #0x53]
    // 0xbfe630: fcvt            s1, d0
    // 0xbfe634: StoreField: r0->field_3b = d1
    //     0xbfe634: stur            s1, [x0, #0x3b]
    // 0xbfe638: LoadField: d0 = r1->field_5b
    //     0xbfe638: ldur            d0, [x1, #0x5b]
    // 0xbfe63c: fcvt            s1, d0
    // 0xbfe640: StoreField: r0->field_3f = d1
    //     0xbfe640: stur            s1, [x0, #0x3f]
    // 0xbfe644: LoadField: d0 = r1->field_63
    //     0xbfe644: ldur            d0, [x1, #0x63]
    // 0xbfe648: fcvt            s1, d0
    // 0xbfe64c: StoreField: r0->field_43 = d1
    //     0xbfe64c: stur            s1, [x0, #0x43]
    // 0xbfe650: ldur            x2, [fp, #-0x10]
    // 0xbfe654: LoadField: r1 = r2->field_7
    //     0xbfe654: ldur            w1, [x2, #7]
    // 0xbfe658: DecompressPointer r1
    //     0xbfe658: add             x1, x1, HEAP, lsl #32
    // 0xbfe65c: cmp             w1, NULL
    // 0xbfe660: b.eq            #0xbfe714
    // 0xbfe664: LoadField: r3 = r1->field_7
    //     0xbfe664: ldur            x3, [x1, #7]
    // 0xbfe668: ldr             x1, [x3]
    // 0xbfe66c: cbz             x1, #0xbfe6b4
    // 0xbfe670: mov             x3, x1
    // 0xbfe674: stur            x3, [fp, #-0x28]
    // 0xbfe678: r1 = <Never>
    //     0xbfe678: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfe67c: r0 = Pointer()
    //     0xbfe67c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfe680: mov             x1, x0
    // 0xbfe684: ldur            x0, [fp, #-0x28]
    // 0xbfe688: StoreField: r1->field_7 = r0
    //     0xbfe688: stur            x0, [x1, #7]
    // 0xbfe68c: ldur            x2, [fp, #-0x18]
    // 0xbfe690: r0 = __addRRect$Method$FfiNative()
    //     0xbfe690: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbfe694: ldur            x0, [fp, #-0x10]
    // 0xbfe698: LeaveFrame
    //     0xbfe698: mov             SP, fp
    //     0xbfe69c: ldp             fp, lr, [SP], #0x10
    // 0xbfe6a0: ret
    //     0xbfe6a0: ret             
    // 0xbfe6a4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfe6a4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfe6a8: str             x16, [SP]
    // 0xbfe6ac: r0 = _throwNew()
    //     0xbfe6ac: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfe6b0: brk             #0
    // 0xbfe6b4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfe6b4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfe6b8: str             x16, [SP]
    // 0xbfe6bc: r0 = _throwNew()
    //     0xbfe6bc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfe6c0: brk             #0
    // 0xbfe6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfe6c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfe6c8: b               #0xbfe3f4
    // 0xbfe6cc: stp             q0, q1, [SP, #-0x20]!
    // 0xbfe6d0: stp             x0, x4, [SP, #-0x10]!
    // 0xbfe6d4: r0 = AllocateDouble()
    //     0xbfe6d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbfe6d8: mov             x1, x0
    // 0xbfe6dc: ldp             x0, x4, [SP], #0x10
    // 0xbfe6e0: ldp             q0, q1, [SP], #0x20
    // 0xbfe6e4: b               #0xbfe458
    // 0xbfe6e8: SaveReg d1
    //     0xbfe6e8: str             q1, [SP, #-0x10]!
    // 0xbfe6ec: stp             x1, x4, [SP, #-0x10]!
    // 0xbfe6f0: SaveReg r0
    //     0xbfe6f0: str             x0, [SP, #-8]!
    // 0xbfe6f4: r0 = AllocateDouble()
    //     0xbfe6f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbfe6f8: mov             x3, x0
    // 0xbfe6fc: RestoreReg r0
    //     0xbfe6fc: ldr             x0, [SP], #8
    // 0xbfe700: ldp             x1, x4, [SP], #0x10
    // 0xbfe704: RestoreReg d1
    //     0xbfe704: ldr             q1, [SP], #0x10
    // 0xbfe708: b               #0xbfe484
    // 0xbfe70c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfe70c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbfe710: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfe710: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbfe714: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfe714: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0xbfe718, size: 0x2f8
    // 0xbfe718: EnterFrame
    //     0xbfe718: stp             fp, lr, [SP, #-0x10]!
    //     0xbfe71c: mov             fp, SP
    // 0xbfe720: AllocStack(0x48)
    //     0xbfe720: sub             SP, SP, #0x48
    // 0xbfe724: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r0, fp-0x28 */, dynamic _ /* r2 => r1, fp-0x30 */, dynamic _ /* r3 => r2 */)
    //     0xbfe724: mov             x0, x1
    //     0xbfe728: stur            x1, [fp, #-0x28]
    //     0xbfe72c: mov             x1, x2
    //     0xbfe730: stur            x2, [fp, #-0x30]
    //     0xbfe734: mov             x2, x3
    // 0xbfe738: CheckStackOverflow
    //     0xbfe738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfe73c: cmp             SP, x16
    //     0xbfe740: b.ls            #0xbfea04
    // 0xbfe744: LoadField: r3 = r0->field_f
    //     0xbfe744: ldur            w3, [x0, #0xf]
    // 0xbfe748: DecompressPointer r3
    //     0xbfe748: add             x3, x3, HEAP, lsl #32
    // 0xbfe74c: r4 = LoadClassIdInstr(r3)
    //     0xbfe74c: ldur            x4, [x3, #-1]
    //     0xbfe750: ubfx            x4, x4, #0xc, #0x14
    // 0xbfe754: cmp             x4, #0xb88
    // 0xbfe758: b.ne            #0xbfe828
    // 0xbfe75c: cmp             w2, NULL
    // 0xbfe760: b.eq            #0xbfea0c
    // 0xbfe764: LoadField: r4 = r2->field_7
    //     0xbfe764: ldur            x4, [x2, #7]
    // 0xbfe768: cmp             x4, #0
    // 0xbfe76c: b.gt            #0xbfe7cc
    // 0xbfe770: LoadField: r2 = r3->field_b
    //     0xbfe770: ldur            w2, [x3, #0xb]
    // 0xbfe774: DecompressPointer r2
    //     0xbfe774: add             x2, x2, HEAP, lsl #32
    // 0xbfe778: stur            x2, [fp, #-0x20]
    // 0xbfe77c: LoadField: r4 = r3->field_7
    //     0xbfe77c: ldur            w4, [x3, #7]
    // 0xbfe780: DecompressPointer r4
    //     0xbfe780: add             x4, x4, HEAP, lsl #32
    // 0xbfe784: stur            x4, [fp, #-0x18]
    // 0xbfe788: LoadField: r5 = r3->field_13
    //     0xbfe788: ldur            w5, [x3, #0x13]
    // 0xbfe78c: DecompressPointer r5
    //     0xbfe78c: add             x5, x5, HEAP, lsl #32
    // 0xbfe790: stur            x5, [fp, #-0x10]
    // 0xbfe794: LoadField: r6 = r3->field_f
    //     0xbfe794: ldur            w6, [x3, #0xf]
    // 0xbfe798: DecompressPointer r6
    //     0xbfe798: add             x6, x6, HEAP, lsl #32
    // 0xbfe79c: stur            x6, [fp, #-8]
    // 0xbfe7a0: r0 = BorderRadius()
    //     0xbfe7a0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfe7a4: mov             x1, x0
    // 0xbfe7a8: ldur            x0, [fp, #-0x20]
    // 0xbfe7ac: StoreField: r1->field_7 = r0
    //     0xbfe7ac: stur            w0, [x1, #7]
    // 0xbfe7b0: ldur            x0, [fp, #-0x18]
    // 0xbfe7b4: StoreField: r1->field_b = r0
    //     0xbfe7b4: stur            w0, [x1, #0xb]
    // 0xbfe7b8: ldur            x0, [fp, #-0x10]
    // 0xbfe7bc: StoreField: r1->field_f = r0
    //     0xbfe7bc: stur            w0, [x1, #0xf]
    // 0xbfe7c0: ldur            x0, [fp, #-8]
    // 0xbfe7c4: StoreField: r1->field_13 = r0
    //     0xbfe7c4: stur            w0, [x1, #0x13]
    // 0xbfe7c8: b               #0xbfe854
    // 0xbfe7cc: LoadField: r0 = r3->field_7
    //     0xbfe7cc: ldur            w0, [x3, #7]
    // 0xbfe7d0: DecompressPointer r0
    //     0xbfe7d0: add             x0, x0, HEAP, lsl #32
    // 0xbfe7d4: stur            x0, [fp, #-0x20]
    // 0xbfe7d8: LoadField: r1 = r3->field_b
    //     0xbfe7d8: ldur            w1, [x3, #0xb]
    // 0xbfe7dc: DecompressPointer r1
    //     0xbfe7dc: add             x1, x1, HEAP, lsl #32
    // 0xbfe7e0: stur            x1, [fp, #-0x18]
    // 0xbfe7e4: LoadField: r2 = r3->field_f
    //     0xbfe7e4: ldur            w2, [x3, #0xf]
    // 0xbfe7e8: DecompressPointer r2
    //     0xbfe7e8: add             x2, x2, HEAP, lsl #32
    // 0xbfe7ec: stur            x2, [fp, #-0x10]
    // 0xbfe7f0: LoadField: r4 = r3->field_13
    //     0xbfe7f0: ldur            w4, [x3, #0x13]
    // 0xbfe7f4: DecompressPointer r4
    //     0xbfe7f4: add             x4, x4, HEAP, lsl #32
    // 0xbfe7f8: stur            x4, [fp, #-8]
    // 0xbfe7fc: r0 = BorderRadius()
    //     0xbfe7fc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfe800: mov             x1, x0
    // 0xbfe804: ldur            x0, [fp, #-0x20]
    // 0xbfe808: StoreField: r1->field_7 = r0
    //     0xbfe808: stur            w0, [x1, #7]
    // 0xbfe80c: ldur            x0, [fp, #-0x18]
    // 0xbfe810: StoreField: r1->field_b = r0
    //     0xbfe810: stur            w0, [x1, #0xb]
    // 0xbfe814: ldur            x0, [fp, #-0x10]
    // 0xbfe818: StoreField: r1->field_f = r0
    //     0xbfe818: stur            w0, [x1, #0xf]
    // 0xbfe81c: ldur            x0, [fp, #-8]
    // 0xbfe820: StoreField: r1->field_13 = r0
    //     0xbfe820: stur            w0, [x1, #0x13]
    // 0xbfe824: b               #0xbfe854
    // 0xbfe828: cmp             x4, #0xb89
    // 0xbfe82c: b.ne            #0xbfe838
    // 0xbfe830: mov             x1, x3
    // 0xbfe834: b               #0xbfe854
    // 0xbfe838: r0 = LoadClassIdInstr(r3)
    //     0xbfe838: ldur            x0, [x3, #-1]
    //     0xbfe83c: ubfx            x0, x0, #0xc, #0x14
    // 0xbfe840: mov             x1, x3
    // 0xbfe844: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbfe844: sub             lr, x0, #1, lsl #12
    //     0xbfe848: ldr             lr, [x21, lr, lsl #3]
    //     0xbfe84c: blr             lr
    // 0xbfe850: mov             x1, x0
    // 0xbfe854: ldur            x0, [fp, #-0x28]
    // 0xbfe858: d0 = 0.000000
    //     0xbfe858: eor             v0.16b, v0.16b, v0.16b
    // 0xbfe85c: stur            x1, [fp, #-8]
    // 0xbfe860: LoadField: d1 = r0->field_13
    //     0xbfe860: ldur            d1, [x0, #0x13]
    // 0xbfe864: stur            d1, [fp, #-0x48]
    // 0xbfe868: fcmp            d1, d0
    // 0xbfe86c: b.ne            #0xbfe880
    // 0xbfe870: mov             x0, x1
    // 0xbfe874: LeaveFrame
    //     0xbfe874: mov             SP, fp
    //     0xbfe878: ldp             fp, lr, [SP], #0x10
    // 0xbfe87c: ret
    //     0xbfe87c: ret             
    // 0xbfe880: LoadField: d2 = r0->field_1b
    //     0xbfe880: ldur            d2, [x0, #0x1b]
    // 0xbfe884: fcmp            d2, d0
    // 0xbfe888: b.eq            #0xbfe998
    // 0xbfe88c: ldur            x0, [fp, #-0x30]
    // 0xbfe890: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbfe890: ldur            d0, [x0, #0x17]
    // 0xbfe894: LoadField: d3 = r0->field_7
    //     0xbfe894: ldur            d3, [x0, #7]
    // 0xbfe898: fsub            d4, d0, d3
    // 0xbfe89c: LoadField: d0 = r0->field_1f
    //     0xbfe89c: ldur            d0, [x0, #0x1f]
    // 0xbfe8a0: LoadField: d3 = r0->field_f
    //     0xbfe8a0: ldur            d3, [x0, #0xf]
    // 0xbfe8a4: fsub            d5, d0, d3
    // 0xbfe8a8: fcmp            d5, d4
    // 0xbfe8ac: b.le            #0xbfe924
    // 0xbfe8b0: d3 = 2.000000
    //     0xbfe8b0: fmov            d3, #2.00000000
    // 0xbfe8b4: d0 = 0.500000
    //     0xbfe8b4: fmov            d0, #0.50000000
    // 0xbfe8b8: fdiv            d6, d4, d3
    // 0xbfe8bc: stur            d6, [fp, #-0x40]
    // 0xbfe8c0: fdiv            d4, d2, d3
    // 0xbfe8c4: fadd            d2, d4, d0
    // 0xbfe8c8: fmul            d0, d2, d5
    // 0xbfe8cc: fdiv            d2, d0, d3
    // 0xbfe8d0: stur            d2, [fp, #-0x38]
    // 0xbfe8d4: r0 = Radius()
    //     0xbfe8d4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbfe8d8: ldur            d0, [fp, #-0x40]
    // 0xbfe8dc: stur            x0, [fp, #-0x10]
    // 0xbfe8e0: StoreField: r0->field_7 = d0
    //     0xbfe8e0: stur            d0, [x0, #7]
    // 0xbfe8e4: ldur            d0, [fp, #-0x38]
    // 0xbfe8e8: StoreField: r0->field_f = d0
    //     0xbfe8e8: stur            d0, [x0, #0xf]
    // 0xbfe8ec: r0 = BorderRadius()
    //     0xbfe8ec: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfe8f0: mov             x1, x0
    // 0xbfe8f4: ldur            x0, [fp, #-0x10]
    // 0xbfe8f8: StoreField: r1->field_7 = r0
    //     0xbfe8f8: stur            w0, [x1, #7]
    // 0xbfe8fc: StoreField: r1->field_b = r0
    //     0xbfe8fc: stur            w0, [x1, #0xb]
    // 0xbfe900: StoreField: r1->field_f = r0
    //     0xbfe900: stur            w0, [x1, #0xf]
    // 0xbfe904: StoreField: r1->field_13 = r0
    //     0xbfe904: stur            w0, [x1, #0x13]
    // 0xbfe908: mov             x2, x1
    // 0xbfe90c: ldur            x1, [fp, #-8]
    // 0xbfe910: ldur            d0, [fp, #-0x48]
    // 0xbfe914: r0 = lerp()
    //     0xbfe914: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbfe918: LeaveFrame
    //     0xbfe918: mov             SP, fp
    //     0xbfe91c: ldp             fp, lr, [SP], #0x10
    // 0xbfe920: ret
    //     0xbfe920: ret             
    // 0xbfe924: d3 = 2.000000
    //     0xbfe924: fmov            d3, #2.00000000
    // 0xbfe928: d0 = 0.500000
    //     0xbfe928: fmov            d0, #0.50000000
    // 0xbfe92c: fdiv            d1, d2, d3
    // 0xbfe930: fadd            d2, d1, d0
    // 0xbfe934: fmul            d0, d2, d4
    // 0xbfe938: fdiv            d1, d0, d3
    // 0xbfe93c: stur            d1, [fp, #-0x40]
    // 0xbfe940: fdiv            d0, d5, d3
    // 0xbfe944: stur            d0, [fp, #-0x38]
    // 0xbfe948: r0 = Radius()
    //     0xbfe948: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbfe94c: ldur            d0, [fp, #-0x40]
    // 0xbfe950: stur            x0, [fp, #-0x10]
    // 0xbfe954: StoreField: r0->field_7 = d0
    //     0xbfe954: stur            d0, [x0, #7]
    // 0xbfe958: ldur            d0, [fp, #-0x38]
    // 0xbfe95c: StoreField: r0->field_f = d0
    //     0xbfe95c: stur            d0, [x0, #0xf]
    // 0xbfe960: r0 = BorderRadius()
    //     0xbfe960: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfe964: mov             x1, x0
    // 0xbfe968: ldur            x0, [fp, #-0x10]
    // 0xbfe96c: StoreField: r1->field_7 = r0
    //     0xbfe96c: stur            w0, [x1, #7]
    // 0xbfe970: StoreField: r1->field_b = r0
    //     0xbfe970: stur            w0, [x1, #0xb]
    // 0xbfe974: StoreField: r1->field_f = r0
    //     0xbfe974: stur            w0, [x1, #0xf]
    // 0xbfe978: StoreField: r1->field_13 = r0
    //     0xbfe978: stur            w0, [x1, #0x13]
    // 0xbfe97c: mov             x2, x1
    // 0xbfe980: ldur            x1, [fp, #-8]
    // 0xbfe984: ldur            d0, [fp, #-0x48]
    // 0xbfe988: r0 = lerp()
    //     0xbfe988: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbfe98c: LeaveFrame
    //     0xbfe98c: mov             SP, fp
    //     0xbfe990: ldp             fp, lr, [SP], #0x10
    // 0xbfe994: ret
    //     0xbfe994: ret             
    // 0xbfe998: ldur            x0, [fp, #-0x30]
    // 0xbfe99c: d3 = 2.000000
    //     0xbfe99c: fmov            d3, #2.00000000
    // 0xbfe9a0: mov             x1, x0
    // 0xbfe9a4: r0 = shortestSide()
    //     0xbfe9a4: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xbfe9a8: mov             v1.16b, v0.16b
    // 0xbfe9ac: d0 = 2.000000
    //     0xbfe9ac: fmov            d0, #2.00000000
    // 0xbfe9b0: fdiv            d2, d1, d0
    // 0xbfe9b4: stur            d2, [fp, #-0x38]
    // 0xbfe9b8: r0 = Radius()
    //     0xbfe9b8: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbfe9bc: ldur            d0, [fp, #-0x38]
    // 0xbfe9c0: stur            x0, [fp, #-0x10]
    // 0xbfe9c4: StoreField: r0->field_7 = d0
    //     0xbfe9c4: stur            d0, [x0, #7]
    // 0xbfe9c8: StoreField: r0->field_f = d0
    //     0xbfe9c8: stur            d0, [x0, #0xf]
    // 0xbfe9cc: r0 = BorderRadius()
    //     0xbfe9cc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfe9d0: mov             x1, x0
    // 0xbfe9d4: ldur            x0, [fp, #-0x10]
    // 0xbfe9d8: StoreField: r1->field_7 = r0
    //     0xbfe9d8: stur            w0, [x1, #7]
    // 0xbfe9dc: StoreField: r1->field_b = r0
    //     0xbfe9dc: stur            w0, [x1, #0xb]
    // 0xbfe9e0: StoreField: r1->field_f = r0
    //     0xbfe9e0: stur            w0, [x1, #0xf]
    // 0xbfe9e4: StoreField: r1->field_13 = r0
    //     0xbfe9e4: stur            w0, [x1, #0x13]
    // 0xbfe9e8: mov             x2, x1
    // 0xbfe9ec: ldur            x1, [fp, #-8]
    // 0xbfe9f0: ldur            d0, [fp, #-0x48]
    // 0xbfe9f4: r0 = lerp()
    //     0xbfe9f4: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbfe9f8: LeaveFrame
    //     0xbfe9f8: mov             SP, fp
    //     0xbfe9fc: ldp             fp, lr, [SP], #0x10
    // 0xbfea00: ret
    //     0xbfea00: ret             
    // 0xbfea04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfea04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfea08: b               #0xbfe744
    // 0xbfea0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfea0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0xbfec34, size: 0x130
    // 0xbfec34: EnterFrame
    //     0xbfec34: stp             fp, lr, [SP, #-0x10]!
    //     0xbfec38: mov             fp, SP
    // 0xbfec3c: AllocStack(0x30)
    //     0xbfec3c: sub             SP, SP, #0x30
    // 0xbfec40: d0 = 0.000000
    //     0xbfec40: eor             v0.16b, v0.16b, v0.16b
    // 0xbfec44: mov             x0, x2
    // 0xbfec48: LoadField: d1 = r1->field_13
    //     0xbfec48: ldur            d1, [x1, #0x13]
    // 0xbfec4c: fcmp            d1, d0
    // 0xbfec50: b.eq            #0xbfec84
    // 0xbfec54: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbfec54: ldur            d0, [x0, #0x17]
    // 0xbfec58: stur            d0, [fp, #-0x20]
    // 0xbfec5c: LoadField: d2 = r0->field_7
    //     0xbfec5c: ldur            d2, [x0, #7]
    // 0xbfec60: stur            d2, [fp, #-0x18]
    // 0xbfec64: fsub            d3, d0, d2
    // 0xbfec68: LoadField: d4 = r0->field_1f
    //     0xbfec68: ldur            d4, [x0, #0x1f]
    // 0xbfec6c: stur            d4, [fp, #-0x30]
    // 0xbfec70: LoadField: d5 = r0->field_f
    //     0xbfec70: ldur            d5, [x0, #0xf]
    // 0xbfec74: stur            d5, [fp, #-0x28]
    // 0xbfec78: fsub            d6, d4, d5
    // 0xbfec7c: fcmp            d3, d6
    // 0xbfec80: b.ne            #0xbfec90
    // 0xbfec84: LeaveFrame
    //     0xbfec84: mov             SP, fp
    //     0xbfec88: ldp             fp, lr, [SP], #0x10
    // 0xbfec8c: ret
    //     0xbfec8c: ret             
    // 0xbfec90: fcmp            d6, d3
    // 0xbfec94: b.le            #0xbfecf8
    // 0xbfec98: d8 = 2.000000
    //     0xbfec98: fmov            d8, #2.00000000
    // 0xbfec9c: d7 = 1.000000
    //     0xbfec9c: fmov            d7, #1.00000000
    // 0xbfeca0: fsub            d9, d6, d3
    // 0xbfeca4: fdiv            d3, d9, d8
    // 0xbfeca8: fmul            d6, d1, d3
    // 0xbfecac: LoadField: d1 = r1->field_1b
    //     0xbfecac: ldur            d1, [x1, #0x1b]
    // 0xbfecb0: fsub            d3, d7, d1
    // 0xbfecb4: fmul            d1, d6, d3
    // 0xbfecb8: fadd            d3, d5, d1
    // 0xbfecbc: stur            d3, [fp, #-0x10]
    // 0xbfecc0: fsub            d5, d4, d1
    // 0xbfecc4: stur            d5, [fp, #-8]
    // 0xbfecc8: r0 = Rect()
    //     0xbfecc8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbfeccc: ldur            d0, [fp, #-0x18]
    // 0xbfecd0: StoreField: r0->field_7 = d0
    //     0xbfecd0: stur            d0, [x0, #7]
    // 0xbfecd4: ldur            d0, [fp, #-0x10]
    // 0xbfecd8: StoreField: r0->field_f = d0
    //     0xbfecd8: stur            d0, [x0, #0xf]
    // 0xbfecdc: ldur            d2, [fp, #-0x20]
    // 0xbfece0: ArrayStore: r0[0] = d2  ; List_8
    //     0xbfece0: stur            d2, [x0, #0x17]
    // 0xbfece4: ldur            d0, [fp, #-8]
    // 0xbfece8: StoreField: r0->field_1f = d0
    //     0xbfece8: stur            d0, [x0, #0x1f]
    // 0xbfecec: LeaveFrame
    //     0xbfecec: mov             SP, fp
    //     0xbfecf0: ldp             fp, lr, [SP], #0x10
    // 0xbfecf4: ret
    //     0xbfecf4: ret             
    // 0xbfecf8: mov             v31.16b, v2.16b
    // 0xbfecfc: mov             v2.16b, v0.16b
    // 0xbfed00: mov             v0.16b, v31.16b
    // 0xbfed04: d8 = 2.000000
    //     0xbfed04: fmov            d8, #2.00000000
    // 0xbfed08: d7 = 1.000000
    //     0xbfed08: fmov            d7, #1.00000000
    // 0xbfed0c: fsub            d9, d3, d6
    // 0xbfed10: fdiv            d3, d9, d8
    // 0xbfed14: fmul            d6, d1, d3
    // 0xbfed18: LoadField: d1 = r1->field_1b
    //     0xbfed18: ldur            d1, [x1, #0x1b]
    // 0xbfed1c: fsub            d3, d7, d1
    // 0xbfed20: fmul            d1, d6, d3
    // 0xbfed24: fadd            d3, d0, d1
    // 0xbfed28: stur            d3, [fp, #-0x10]
    // 0xbfed2c: fsub            d0, d2, d1
    // 0xbfed30: stur            d0, [fp, #-8]
    // 0xbfed34: r0 = Rect()
    //     0xbfed34: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbfed38: ldur            d0, [fp, #-0x10]
    // 0xbfed3c: StoreField: r0->field_7 = d0
    //     0xbfed3c: stur            d0, [x0, #7]
    // 0xbfed40: ldur            d0, [fp, #-0x28]
    // 0xbfed44: StoreField: r0->field_f = d0
    //     0xbfed44: stur            d0, [x0, #0xf]
    // 0xbfed48: ldur            d0, [fp, #-8]
    // 0xbfed4c: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfed4c: stur            d0, [x0, #0x17]
    // 0xbfed50: ldur            d0, [fp, #-0x30]
    // 0xbfed54: StoreField: r0->field_1f = d0
    //     0xbfed54: stur            d0, [x0, #0x1f]
    // 0xbfed58: LeaveFrame
    //     0xbfed58: mov             SP, fp
    //     0xbfed5c: ldp             fp, lr, [SP], #0x10
    // 0xbfed60: ret
    //     0xbfed60: ret             
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ed68c, size: 0x5c0
    // 0x10ed68c: EnterFrame
    //     0x10ed68c: stp             fp, lr, [SP, #-0x10]!
    //     0x10ed690: mov             fp, SP
    // 0x10ed694: AllocStack(0x40)
    //     0x10ed694: sub             SP, SP, #0x40
    // 0x10ed698: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x10ed698: mov             x4, x1
    //     0x10ed69c: mov             x3, x2
    //     0x10ed6a0: stur            x1, [fp, #-0x10]
    //     0x10ed6a4: stur            x2, [fp, #-0x18]
    //     0x10ed6a8: stur            d0, [fp, #-0x30]
    // 0x10ed6ac: CheckStackOverflow
    //     0x10ed6ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ed6b0: cmp             SP, x16
    //     0x10ed6b4: b.ls            #0x10edbd8
    // 0x10ed6b8: LoadField: r5 = r4->field_b
    //     0x10ed6b8: ldur            w5, [x4, #0xb]
    // 0x10ed6bc: DecompressPointer r5
    //     0x10ed6bc: add             x5, x5, HEAP, lsl #32
    // 0x10ed6c0: mov             x0, x3
    // 0x10ed6c4: mov             x2, x5
    // 0x10ed6c8: stur            x5, [fp, #-8]
    // 0x10ed6cc: r1 = Null
    //     0x10ed6cc: mov             x1, NULL
    // 0x10ed6d0: cmp             w2, NULL
    // 0x10ed6d4: b.eq            #0x10ed76c
    // 0x10ed6d8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x10ed6d8: ldur            w3, [x2, #0x17]
    // 0x10ed6dc: DecompressPointer r3
    //     0x10ed6dc: add             x3, x3, HEAP, lsl #32
    // 0x10ed6e0: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x10ed6e4: cmp             w3, w16
    // 0x10ed6e8: b.eq            #0x10ed76c
    // 0x10ed6ec: r16 = Object?
    //     0x10ed6ec: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x10ed6f0: cmp             w3, w16
    // 0x10ed6f4: b.eq            #0x10ed76c
    // 0x10ed6f8: r16 = void?
    //     0x10ed6f8: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x10ed6fc: cmp             w3, w16
    // 0x10ed700: b.eq            #0x10ed76c
    // 0x10ed704: tbnz            w0, #0, #0x10ed720
    // 0x10ed708: r16 = int
    //     0x10ed708: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x10ed70c: cmp             w3, w16
    // 0x10ed710: b.eq            #0x10ed76c
    // 0x10ed714: r16 = num
    //     0x10ed714: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x10ed718: cmp             w3, w16
    // 0x10ed71c: b.eq            #0x10ed76c
    // 0x10ed720: r3 = SubtypeTestCache
    //     0x10ed720: add             x3, PP, #0xac, lsl #12  ; [pp+0xace28] SubtypeTestCache
    //     0x10ed724: ldr             x3, [x3, #0xe28]
    // 0x10ed728: r30 = Subtype4TestCacheStub
    //     0x10ed728: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0x10ed72c: LoadField: r30 = r30->field_7
    //     0x10ed72c: ldur            lr, [lr, #7]
    // 0x10ed730: blr             lr
    // 0x10ed734: cmp             w7, NULL
    // 0x10ed738: b.eq            #0x10ed744
    // 0x10ed73c: tbnz            w7, #4, #0x10ed764
    // 0x10ed740: b               #0x10ed76c
    // 0x10ed744: r8 = X0 bound _RRectLikeBorder
    //     0x10ed744: add             x8, PP, #0xac, lsl #12  ; [pp+0xace30] TypeParameter: X0 bound _RRectLikeBorder
    //     0x10ed748: ldr             x8, [x8, #0xe30]
    // 0x10ed74c: r3 = SubtypeTestCache
    //     0x10ed74c: add             x3, PP, #0xac, lsl #12  ; [pp+0xace38] SubtypeTestCache
    //     0x10ed750: ldr             x3, [x3, #0xe38]
    // 0x10ed754: r30 = InstanceOfStub
    //     0x10ed754: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x10ed758: LoadField: r30 = r30->field_7
    //     0x10ed758: ldur            lr, [lr, #7]
    // 0x10ed75c: blr             lr
    // 0x10ed760: b               #0x10ed770
    // 0x10ed764: r0 = false
    //     0x10ed764: add             x0, NULL, #0x30  ; false
    // 0x10ed768: b               #0x10ed770
    // 0x10ed76c: r0 = true
    //     0x10ed76c: add             x0, NULL, #0x20  ; true
    // 0x10ed770: tbnz            w0, #4, #0x10ed894
    // 0x10ed774: ldur            x3, [fp, #-0x10]
    // 0x10ed778: ldur            x0, [fp, #-0x18]
    // 0x10ed77c: ldur            d1, [fp, #-0x30]
    // 0x10ed780: LoadField: r1 = r0->field_7
    //     0x10ed780: ldur            w1, [x0, #7]
    // 0x10ed784: DecompressPointer r1
    //     0x10ed784: add             x1, x1, HEAP, lsl #32
    // 0x10ed788: LoadField: r2 = r3->field_7
    //     0x10ed788: ldur            w2, [x3, #7]
    // 0x10ed78c: DecompressPointer r2
    //     0x10ed78c: add             x2, x2, HEAP, lsl #32
    // 0x10ed790: mov             v0.16b, v1.16b
    // 0x10ed794: r0 = lerp()
    //     0x10ed794: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed798: mov             x2, x0
    // 0x10ed79c: ldur            x0, [fp, #-0x18]
    // 0x10ed7a0: stur            x2, [fp, #-0x20]
    // 0x10ed7a4: r1 = LoadClassIdInstr(r0)
    //     0x10ed7a4: ldur            x1, [x0, #-1]
    //     0x10ed7a8: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed7ac: mov             x16, x0
    // 0x10ed7b0: mov             x0, x1
    // 0x10ed7b4: mov             x1, x16
    // 0x10ed7b8: r0 = GDT[cid_x0 + -0xfdb]()
    //     0x10ed7b8: sub             lr, x0, #0xfdb
    //     0x10ed7bc: ldr             lr, [x21, lr, lsl #3]
    //     0x10ed7c0: blr             lr
    // 0x10ed7c4: mov             x1, x0
    // 0x10ed7c8: ldur            x0, [fp, #-0x10]
    // 0x10ed7cc: LoadField: r2 = r0->field_f
    //     0x10ed7cc: ldur            w2, [x0, #0xf]
    // 0x10ed7d0: DecompressPointer r2
    //     0x10ed7d0: add             x2, x2, HEAP, lsl #32
    // 0x10ed7d4: ldur            d0, [fp, #-0x30]
    // 0x10ed7d8: r0 = lerp()
    //     0x10ed7d8: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10ed7dc: ldur            x3, [fp, #-0x10]
    // 0x10ed7e0: stur            x0, [fp, #-0x28]
    // 0x10ed7e4: LoadField: d0 = r3->field_13
    //     0x10ed7e4: ldur            d0, [x3, #0x13]
    // 0x10ed7e8: ldur            d1, [fp, #-0x30]
    // 0x10ed7ec: fmul            d2, d0, d1
    // 0x10ed7f0: stur            d2, [fp, #-0x40]
    // 0x10ed7f4: LoadField: d0 = r3->field_1b
    //     0x10ed7f4: ldur            d0, [x3, #0x1b]
    // 0x10ed7f8: stur            d0, [fp, #-0x38]
    // 0x10ed7fc: r1 = LoadClassIdInstr(r3)
    //     0x10ed7fc: ldur            x1, [x3, #-1]
    //     0x10ed800: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed804: cmp             x1, #0xbd0
    // 0x10ed808: b.ne            #0x10ed848
    // 0x10ed80c: ldur            x2, [fp, #-0x20]
    // 0x10ed810: r1 = <RoundedSuperellipseBorder>
    //     0x10ed810: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10ed814: ldr             x1, [x1, #0xda8]
    // 0x10ed818: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10ed818: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10ed81c: mov             x1, x0
    // 0x10ed820: ldur            x0, [fp, #-0x28]
    // 0x10ed824: StoreField: r1->field_f = r0
    //     0x10ed824: stur            w0, [x1, #0xf]
    // 0x10ed828: ldur            d0, [fp, #-0x40]
    // 0x10ed82c: StoreField: r1->field_13 = d0
    //     0x10ed82c: stur            d0, [x1, #0x13]
    // 0x10ed830: ldur            d1, [fp, #-0x38]
    // 0x10ed834: StoreField: r1->field_1b = d1
    //     0x10ed834: stur            d1, [x1, #0x1b]
    // 0x10ed838: ldur            x2, [fp, #-0x20]
    // 0x10ed83c: StoreField: r1->field_7 = r2
    //     0x10ed83c: stur            w2, [x1, #7]
    // 0x10ed840: mov             x0, x1
    // 0x10ed844: b               #0x10ed888
    // 0x10ed848: ldur            x2, [fp, #-0x20]
    // 0x10ed84c: mov             v1.16b, v0.16b
    // 0x10ed850: mov             v0.16b, v2.16b
    // 0x10ed854: r1 = <RoundedRectangleBorder>
    //     0x10ed854: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10ed858: ldr             x1, [x1, #0xd90]
    // 0x10ed85c: r0 = _RoundedRectangleToCircleBorder()
    //     0x10ed85c: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10ed860: mov             x1, x0
    // 0x10ed864: ldur            x0, [fp, #-0x28]
    // 0x10ed868: StoreField: r1->field_f = r0
    //     0x10ed868: stur            w0, [x1, #0xf]
    // 0x10ed86c: ldur            d0, [fp, #-0x40]
    // 0x10ed870: StoreField: r1->field_13 = d0
    //     0x10ed870: stur            d0, [x1, #0x13]
    // 0x10ed874: ldur            d0, [fp, #-0x38]
    // 0x10ed878: StoreField: r1->field_1b = d0
    //     0x10ed878: stur            d0, [x1, #0x1b]
    // 0x10ed87c: ldur            x0, [fp, #-0x20]
    // 0x10ed880: StoreField: r1->field_7 = r0
    //     0x10ed880: stur            w0, [x1, #7]
    // 0x10ed884: mov             x0, x1
    // 0x10ed888: LeaveFrame
    //     0x10ed888: mov             SP, fp
    //     0x10ed88c: ldp             fp, lr, [SP], #0x10
    // 0x10ed890: ret
    //     0x10ed890: ret             
    // 0x10ed894: ldur            x3, [fp, #-0x10]
    // 0x10ed898: ldur            x0, [fp, #-0x18]
    // 0x10ed89c: ldur            d1, [fp, #-0x30]
    // 0x10ed8a0: r1 = LoadClassIdInstr(r0)
    //     0x10ed8a0: ldur            x1, [x0, #-1]
    //     0x10ed8a4: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed8a8: cmp             x1, #0xbd2
    // 0x10ed8ac: b.ne            #0x10ed9a4
    // 0x10ed8b0: LoadField: r1 = r0->field_7
    //     0x10ed8b0: ldur            w1, [x0, #7]
    // 0x10ed8b4: DecompressPointer r1
    //     0x10ed8b4: add             x1, x1, HEAP, lsl #32
    // 0x10ed8b8: LoadField: r2 = r3->field_7
    //     0x10ed8b8: ldur            w2, [x3, #7]
    // 0x10ed8bc: DecompressPointer r2
    //     0x10ed8bc: add             x2, x2, HEAP, lsl #32
    // 0x10ed8c0: mov             v0.16b, v1.16b
    // 0x10ed8c4: r0 = lerp()
    //     0x10ed8c4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed8c8: ldur            x3, [fp, #-0x10]
    // 0x10ed8cc: stur            x0, [fp, #-0x28]
    // 0x10ed8d0: LoadField: r2 = r3->field_f
    //     0x10ed8d0: ldur            w2, [x3, #0xf]
    // 0x10ed8d4: DecompressPointer r2
    //     0x10ed8d4: add             x2, x2, HEAP, lsl #32
    // 0x10ed8d8: stur            x2, [fp, #-0x20]
    // 0x10ed8dc: LoadField: d0 = r3->field_13
    //     0x10ed8dc: ldur            d0, [x3, #0x13]
    // 0x10ed8e0: d1 = 1.000000
    //     0x10ed8e0: fmov            d1, #1.00000000
    // 0x10ed8e4: fsub            d2, d1, d0
    // 0x10ed8e8: ldur            d3, [fp, #-0x30]
    // 0x10ed8ec: fsub            d4, d1, d3
    // 0x10ed8f0: fmul            d1, d2, d4
    // 0x10ed8f4: fadd            d2, d0, d1
    // 0x10ed8f8: ldur            x4, [fp, #-0x18]
    // 0x10ed8fc: stur            d2, [fp, #-0x40]
    // 0x10ed900: LoadField: d0 = r4->field_b
    //     0x10ed900: ldur            d0, [x4, #0xb]
    // 0x10ed904: stur            d0, [fp, #-0x38]
    // 0x10ed908: r1 = LoadClassIdInstr(r3)
    //     0x10ed908: ldur            x1, [x3, #-1]
    //     0x10ed90c: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed910: cmp             x1, #0xbd0
    // 0x10ed914: b.ne            #0x10ed950
    // 0x10ed918: r1 = <RoundedSuperellipseBorder>
    //     0x10ed918: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10ed91c: ldr             x1, [x1, #0xda8]
    // 0x10ed920: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10ed920: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10ed924: mov             x1, x0
    // 0x10ed928: ldur            x0, [fp, #-0x20]
    // 0x10ed92c: StoreField: r1->field_f = r0
    //     0x10ed92c: stur            w0, [x1, #0xf]
    // 0x10ed930: ldur            d0, [fp, #-0x40]
    // 0x10ed934: StoreField: r1->field_13 = d0
    //     0x10ed934: stur            d0, [x1, #0x13]
    // 0x10ed938: ldur            d1, [fp, #-0x38]
    // 0x10ed93c: StoreField: r1->field_1b = d1
    //     0x10ed93c: stur            d1, [x1, #0x1b]
    // 0x10ed940: ldur            x2, [fp, #-0x28]
    // 0x10ed944: StoreField: r1->field_7 = r2
    //     0x10ed944: stur            w2, [x1, #7]
    // 0x10ed948: mov             x0, x1
    // 0x10ed94c: b               #0x10ed998
    // 0x10ed950: mov             x16, x2
    // 0x10ed954: mov             x2, x0
    // 0x10ed958: mov             x0, x16
    // 0x10ed95c: mov             v1.16b, v0.16b
    // 0x10ed960: mov             v0.16b, v2.16b
    // 0x10ed964: r1 = <RoundedRectangleBorder>
    //     0x10ed964: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10ed968: ldr             x1, [x1, #0xd90]
    // 0x10ed96c: r0 = _RoundedRectangleToCircleBorder()
    //     0x10ed96c: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10ed970: mov             x1, x0
    // 0x10ed974: ldur            x0, [fp, #-0x20]
    // 0x10ed978: StoreField: r1->field_f = r0
    //     0x10ed978: stur            w0, [x1, #0xf]
    // 0x10ed97c: ldur            d0, [fp, #-0x40]
    // 0x10ed980: StoreField: r1->field_13 = d0
    //     0x10ed980: stur            d0, [x1, #0x13]
    // 0x10ed984: ldur            d0, [fp, #-0x38]
    // 0x10ed988: StoreField: r1->field_1b = d0
    //     0x10ed988: stur            d0, [x1, #0x1b]
    // 0x10ed98c: ldur            x0, [fp, #-0x28]
    // 0x10ed990: StoreField: r1->field_7 = r0
    //     0x10ed990: stur            w0, [x1, #7]
    // 0x10ed994: mov             x0, x1
    // 0x10ed998: LeaveFrame
    //     0x10ed998: mov             SP, fp
    //     0x10ed99c: ldp             fp, lr, [SP], #0x10
    // 0x10ed9a0: ret
    //     0x10ed9a0: ret             
    // 0x10ed9a4: mov             x4, x0
    // 0x10ed9a8: mov             v3.16b, v1.16b
    // 0x10ed9ac: mov             x0, x4
    // 0x10ed9b0: ldur            x2, [fp, #-8]
    // 0x10ed9b4: r1 = Null
    //     0x10ed9b4: mov             x1, NULL
    // 0x10ed9b8: cmp             w0, NULL
    // 0x10ed9bc: b.eq            #0x10eda08
    // 0x10ed9c0: branchIfSmi(r0, 0x10eda08)
    //     0x10ed9c0: tbz             w0, #0, #0x10eda08
    // 0x10ed9c4: r3 = SubtypeTestCache
    //     0x10ed9c4: add             x3, PP, #0xac, lsl #12  ; [pp+0xace40] SubtypeTestCache
    //     0x10ed9c8: ldr             x3, [x3, #0xe40]
    // 0x10ed9cc: r30 = Subtype3TestCacheStub
    //     0x10ed9cc: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x10ed9d0: LoadField: r30 = r30->field_7
    //     0x10ed9d0: ldur            lr, [lr, #7]
    // 0x10ed9d4: blr             lr
    // 0x10ed9d8: cmp             w7, NULL
    // 0x10ed9dc: b.eq            #0x10ed9e8
    // 0x10ed9e0: tbnz            w7, #4, #0x10eda08
    // 0x10ed9e4: b               #0x10eda10
    // 0x10ed9e8: r8 = _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x10ed9e8: add             x8, PP, #0xac, lsl #12  ; [pp+0xace48] Type: _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x10ed9ec: ldr             x8, [x8, #0xe48]
    // 0x10ed9f0: r3 = SubtypeTestCache
    //     0x10ed9f0: add             x3, PP, #0xac, lsl #12  ; [pp+0xace50] SubtypeTestCache
    //     0x10ed9f4: ldr             x3, [x3, #0xe50]
    // 0x10ed9f8: r30 = InstanceOfStub
    //     0x10ed9f8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x10ed9fc: LoadField: r30 = r30->field_7
    //     0x10ed9fc: ldur            lr, [lr, #7]
    // 0x10eda00: blr             lr
    // 0x10eda04: b               #0x10eda14
    // 0x10eda08: r0 = false
    //     0x10eda08: add             x0, NULL, #0x30  ; false
    // 0x10eda0c: b               #0x10eda14
    // 0x10eda10: r0 = true
    //     0x10eda10: add             x0, NULL, #0x20  ; true
    // 0x10eda14: tbnz            w0, #4, #0x10edbb8
    // 0x10eda18: ldur            x0, [fp, #-0x10]
    // 0x10eda1c: ldur            x3, [fp, #-0x18]
    // 0x10eda20: ldur            d1, [fp, #-0x30]
    // 0x10eda24: LoadField: r1 = r3->field_7
    //     0x10eda24: ldur            w1, [x3, #7]
    // 0x10eda28: DecompressPointer r1
    //     0x10eda28: add             x1, x1, HEAP, lsl #32
    // 0x10eda2c: LoadField: r2 = r0->field_7
    //     0x10eda2c: ldur            w2, [x0, #7]
    // 0x10eda30: DecompressPointer r2
    //     0x10eda30: add             x2, x2, HEAP, lsl #32
    // 0x10eda34: mov             v0.16b, v1.16b
    // 0x10eda38: r0 = lerp()
    //     0x10eda38: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10eda3c: mov             x3, x0
    // 0x10eda40: ldur            x0, [fp, #-0x18]
    // 0x10eda44: stur            x3, [fp, #-8]
    // 0x10eda48: LoadField: r1 = r0->field_f
    //     0x10eda48: ldur            w1, [x0, #0xf]
    // 0x10eda4c: DecompressPointer r1
    //     0x10eda4c: add             x1, x1, HEAP, lsl #32
    // 0x10eda50: ldur            x4, [fp, #-0x10]
    // 0x10eda54: LoadField: r2 = r4->field_f
    //     0x10eda54: ldur            w2, [x4, #0xf]
    // 0x10eda58: DecompressPointer r2
    //     0x10eda58: add             x2, x2, HEAP, lsl #32
    // 0x10eda5c: ldur            d0, [fp, #-0x30]
    // 0x10eda60: r0 = lerp()
    //     0x10eda60: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10eda64: ldur            x2, [fp, #-0x18]
    // 0x10eda68: stur            x0, [fp, #-0x20]
    // 0x10eda6c: LoadField: d0 = r2->field_13
    //     0x10eda6c: ldur            d0, [x2, #0x13]
    // 0x10eda70: ldur            x4, [fp, #-0x10]
    // 0x10eda74: LoadField: d1 = r4->field_13
    //     0x10eda74: ldur            d1, [x4, #0x13]
    // 0x10eda78: ldur            d2, [fp, #-0x30]
    // 0x10eda7c: r3 = inline_Allocate_Double()
    //     0x10eda7c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x10eda80: add             x3, x3, #0x10
    //     0x10eda84: cmp             x1, x3
    //     0x10eda88: b.ls            #0x10edbe0
    //     0x10eda8c: str             x3, [THR, #0x60]  ; THR::top
    //     0x10eda90: sub             x3, x3, #0xf
    //     0x10eda94: mov             x1, #0xe19c
    //     0x10eda98: movk            x1, #3, lsl #16
    //     0x10eda9c: stur            x1, [x3, #-1]
    // 0x10edaa0: dmb             ishst
    // 0x10edaa4: StoreField: r3->field_7 = d2
    //     0x10edaa4: stur            d2, [x3, #7]
    // 0x10edaa8: r1 = inline_Allocate_Double()
    //     0x10edaa8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10edaac: add             x1, x1, #0x10
    //     0x10edab0: cmp             x2, x1
    //     0x10edab4: b.ls            #0x10edc04
    //     0x10edab8: str             x1, [THR, #0x60]  ; THR::top
    //     0x10edabc: sub             x1, x1, #0xf
    //     0x10edac0: mov             x2, #0xe19c
    //     0x10edac4: movk            x2, #3, lsl #16
    //     0x10edac8: stur            x2, [x1, #-1]
    // 0x10edacc: dmb             ishst
    // 0x10edad0: StoreField: r1->field_7 = d0
    //     0x10edad0: stur            d0, [x1, #7]
    // 0x10edad4: r2 = inline_Allocate_Double()
    //     0x10edad4: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0x10edad8: add             x2, x2, #0x10
    //     0x10edadc: cmp             x5, x2
    //     0x10edae0: b.ls            #0x10edc28
    //     0x10edae4: str             x2, [THR, #0x60]  ; THR::top
    //     0x10edae8: sub             x2, x2, #0xf
    //     0x10edaec: mov             x5, #0xe19c
    //     0x10edaf0: movk            x5, #3, lsl #16
    //     0x10edaf4: stur            x5, [x2, #-1]
    // 0x10edaf8: dmb             ishst
    // 0x10edafc: StoreField: r2->field_7 = d1
    //     0x10edafc: stur            d1, [x2, #7]
    // 0x10edb00: r0 = lerpDouble()
    //     0x10edb00: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10edb04: ldur            x1, [fp, #-0x10]
    // 0x10edb08: stur            x0, [fp, #-0x28]
    // 0x10edb0c: LoadField: d0 = r1->field_1b
    //     0x10edb0c: ldur            d0, [x1, #0x1b]
    // 0x10edb10: stur            d0, [fp, #-0x38]
    // 0x10edb14: r2 = LoadClassIdInstr(r1)
    //     0x10edb14: ldur            x2, [x1, #-1]
    //     0x10edb18: ubfx            x2, x2, #0xc, #0x14
    // 0x10edb1c: cmp             x2, #0xbd0
    // 0x10edb20: b.ne            #0x10edb68
    // 0x10edb24: ldur            x3, [fp, #-8]
    // 0x10edb28: ldur            x2, [fp, #-0x20]
    // 0x10edb2c: r1 = <RoundedSuperellipseBorder>
    //     0x10edb2c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10edb30: ldr             x1, [x1, #0xda8]
    // 0x10edb34: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10edb34: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10edb38: mov             x1, x0
    // 0x10edb3c: ldur            x0, [fp, #-0x20]
    // 0x10edb40: StoreField: r1->field_f = r0
    //     0x10edb40: stur            w0, [x1, #0xf]
    // 0x10edb44: ldur            x2, [fp, #-0x28]
    // 0x10edb48: LoadField: d0 = r2->field_7
    //     0x10edb48: ldur            d0, [x2, #7]
    // 0x10edb4c: StoreField: r1->field_13 = d0
    //     0x10edb4c: stur            d0, [x1, #0x13]
    // 0x10edb50: ldur            d0, [fp, #-0x38]
    // 0x10edb54: StoreField: r1->field_1b = d0
    //     0x10edb54: stur            d0, [x1, #0x1b]
    // 0x10edb58: ldur            x3, [fp, #-8]
    // 0x10edb5c: StoreField: r1->field_7 = r3
    //     0x10edb5c: stur            w3, [x1, #7]
    // 0x10edb60: mov             x0, x1
    // 0x10edb64: b               #0x10edbac
    // 0x10edb68: ldur            x3, [fp, #-8]
    // 0x10edb6c: mov             x2, x0
    // 0x10edb70: ldur            x0, [fp, #-0x20]
    // 0x10edb74: r1 = <RoundedRectangleBorder>
    //     0x10edb74: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10edb78: ldr             x1, [x1, #0xd90]
    // 0x10edb7c: r0 = _RoundedRectangleToCircleBorder()
    //     0x10edb7c: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10edb80: mov             x1, x0
    // 0x10edb84: ldur            x0, [fp, #-0x20]
    // 0x10edb88: StoreField: r1->field_f = r0
    //     0x10edb88: stur            w0, [x1, #0xf]
    // 0x10edb8c: ldur            x0, [fp, #-0x28]
    // 0x10edb90: LoadField: d0 = r0->field_7
    //     0x10edb90: ldur            d0, [x0, #7]
    // 0x10edb94: StoreField: r1->field_13 = d0
    //     0x10edb94: stur            d0, [x1, #0x13]
    // 0x10edb98: ldur            d0, [fp, #-0x38]
    // 0x10edb9c: StoreField: r1->field_1b = d0
    //     0x10edb9c: stur            d0, [x1, #0x1b]
    // 0x10edba0: ldur            x0, [fp, #-8]
    // 0x10edba4: StoreField: r1->field_7 = r0
    //     0x10edba4: stur            w0, [x1, #7]
    // 0x10edba8: mov             x0, x1
    // 0x10edbac: LeaveFrame
    //     0x10edbac: mov             SP, fp
    //     0x10edbb0: ldp             fp, lr, [SP], #0x10
    // 0x10edbb4: ret
    //     0x10edbb4: ret             
    // 0x10edbb8: ldur            x1, [fp, #-0x10]
    // 0x10edbbc: ldur            x2, [fp, #-0x18]
    // 0x10edbc0: ldur            d2, [fp, #-0x30]
    // 0x10edbc4: mov             v0.16b, v2.16b
    // 0x10edbc8: r0 = lerpFrom()
    //     0x10edbc8: bl              #0x10ee854  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpFrom
    // 0x10edbcc: LeaveFrame
    //     0x10edbcc: mov             SP, fp
    //     0x10edbd0: ldp             fp, lr, [SP], #0x10
    // 0x10edbd4: ret
    //     0x10edbd4: ret             
    // 0x10edbd8: r0 = StackOverflowSharedWithFPURegs()
    //     0x10edbd8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10edbdc: b               #0x10ed6b8
    // 0x10edbe0: stp             q1, q2, [SP, #-0x20]!
    // 0x10edbe4: SaveReg d0
    //     0x10edbe4: str             q0, [SP, #-0x10]!
    // 0x10edbe8: stp             x0, x4, [SP, #-0x10]!
    // 0x10edbec: r0 = AllocateDouble()
    //     0x10edbec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10edbf0: mov             x3, x0
    // 0x10edbf4: ldp             x0, x4, [SP], #0x10
    // 0x10edbf8: RestoreReg d0
    //     0x10edbf8: ldr             q0, [SP], #0x10
    // 0x10edbfc: ldp             q1, q2, [SP], #0x20
    // 0x10edc00: b               #0x10edaa4
    // 0x10edc04: stp             q0, q1, [SP, #-0x20]!
    // 0x10edc08: stp             x3, x4, [SP, #-0x10]!
    // 0x10edc0c: SaveReg r0
    //     0x10edc0c: str             x0, [SP, #-8]!
    // 0x10edc10: r0 = AllocateDouble()
    //     0x10edc10: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10edc14: mov             x1, x0
    // 0x10edc18: RestoreReg r0
    //     0x10edc18: ldr             x0, [SP], #8
    // 0x10edc1c: ldp             x3, x4, [SP], #0x10
    // 0x10edc20: ldp             q0, q1, [SP], #0x20
    // 0x10edc24: b               #0x10edad0
    // 0x10edc28: SaveReg d1
    //     0x10edc28: str             q1, [SP, #-0x10]!
    // 0x10edc2c: stp             x3, x4, [SP, #-0x10]!
    // 0x10edc30: stp             x0, x1, [SP, #-0x10]!
    // 0x10edc34: r0 = AllocateDouble()
    //     0x10edc34: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10edc38: mov             x2, x0
    // 0x10edc3c: ldp             x0, x1, [SP], #0x10
    // 0x10edc40: ldp             x3, x4, [SP], #0x10
    // 0x10edc44: RestoreReg d1
    //     0x10edc44: ldr             q1, [SP], #0x10
    // 0x10edc48: b               #0x10edafc
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f0810, size: 0x5d8
    // 0x10f0810: EnterFrame
    //     0x10f0810: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0814: mov             fp, SP
    // 0x10f0818: AllocStack(0x40)
    //     0x10f0818: sub             SP, SP, #0x40
    // 0x10f081c: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x10f081c: mov             x4, x1
    //     0x10f0820: mov             x3, x2
    //     0x10f0824: stur            x1, [fp, #-0x10]
    //     0x10f0828: stur            x2, [fp, #-0x18]
    //     0x10f082c: stur            d0, [fp, #-0x30]
    // 0x10f0830: CheckStackOverflow
    //     0x10f0830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f0834: cmp             SP, x16
    //     0x10f0838: b.ls            #0x10f0d74
    // 0x10f083c: LoadField: r5 = r4->field_b
    //     0x10f083c: ldur            w5, [x4, #0xb]
    // 0x10f0840: DecompressPointer r5
    //     0x10f0840: add             x5, x5, HEAP, lsl #32
    // 0x10f0844: mov             x0, x3
    // 0x10f0848: mov             x2, x5
    // 0x10f084c: stur            x5, [fp, #-8]
    // 0x10f0850: r1 = Null
    //     0x10f0850: mov             x1, NULL
    // 0x10f0854: cmp             w2, NULL
    // 0x10f0858: b.eq            #0x10f08f0
    // 0x10f085c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x10f085c: ldur            w3, [x2, #0x17]
    // 0x10f0860: DecompressPointer r3
    //     0x10f0860: add             x3, x3, HEAP, lsl #32
    // 0x10f0864: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x10f0868: cmp             w3, w16
    // 0x10f086c: b.eq            #0x10f08f0
    // 0x10f0870: r16 = Object?
    //     0x10f0870: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x10f0874: cmp             w3, w16
    // 0x10f0878: b.eq            #0x10f08f0
    // 0x10f087c: r16 = void?
    //     0x10f087c: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x10f0880: cmp             w3, w16
    // 0x10f0884: b.eq            #0x10f08f0
    // 0x10f0888: tbnz            w0, #0, #0x10f08a4
    // 0x10f088c: r16 = int
    //     0x10f088c: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x10f0890: cmp             w3, w16
    // 0x10f0894: b.eq            #0x10f08f0
    // 0x10f0898: r16 = num
    //     0x10f0898: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x10f089c: cmp             w3, w16
    // 0x10f08a0: b.eq            #0x10f08f0
    // 0x10f08a4: r3 = SubtypeTestCache
    //     0x10f08a4: add             x3, PP, #0xac, lsl #12  ; [pp+0xacdf8] SubtypeTestCache
    //     0x10f08a8: ldr             x3, [x3, #0xdf8]
    // 0x10f08ac: r30 = Subtype4TestCacheStub
    //     0x10f08ac: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0x10f08b0: LoadField: r30 = r30->field_7
    //     0x10f08b0: ldur            lr, [lr, #7]
    // 0x10f08b4: blr             lr
    // 0x10f08b8: cmp             w7, NULL
    // 0x10f08bc: b.eq            #0x10f08c8
    // 0x10f08c0: tbnz            w7, #4, #0x10f08e8
    // 0x10f08c4: b               #0x10f08f0
    // 0x10f08c8: r8 = X0 bound _RRectLikeBorder
    //     0x10f08c8: add             x8, PP, #0xac, lsl #12  ; [pp+0xace00] TypeParameter: X0 bound _RRectLikeBorder
    //     0x10f08cc: ldr             x8, [x8, #0xe00]
    // 0x10f08d0: r3 = SubtypeTestCache
    //     0x10f08d0: add             x3, PP, #0xac, lsl #12  ; [pp+0xace08] SubtypeTestCache
    //     0x10f08d4: ldr             x3, [x3, #0xe08]
    // 0x10f08d8: r30 = InstanceOfStub
    //     0x10f08d8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x10f08dc: LoadField: r30 = r30->field_7
    //     0x10f08dc: ldur            lr, [lr, #7]
    // 0x10f08e0: blr             lr
    // 0x10f08e4: b               #0x10f08f4
    // 0x10f08e8: r0 = false
    //     0x10f08e8: add             x0, NULL, #0x30  ; false
    // 0x10f08ec: b               #0x10f08f4
    // 0x10f08f0: r0 = true
    //     0x10f08f0: add             x0, NULL, #0x20  ; true
    // 0x10f08f4: tbnz            w0, #4, #0x10f0a2c
    // 0x10f08f8: ldur            x3, [fp, #-0x10]
    // 0x10f08fc: ldur            x0, [fp, #-0x18]
    // 0x10f0900: ldur            d1, [fp, #-0x30]
    // 0x10f0904: LoadField: r1 = r3->field_7
    //     0x10f0904: ldur            w1, [x3, #7]
    // 0x10f0908: DecompressPointer r1
    //     0x10f0908: add             x1, x1, HEAP, lsl #32
    // 0x10f090c: LoadField: r2 = r0->field_7
    //     0x10f090c: ldur            w2, [x0, #7]
    // 0x10f0910: DecompressPointer r2
    //     0x10f0910: add             x2, x2, HEAP, lsl #32
    // 0x10f0914: mov             v0.16b, v1.16b
    // 0x10f0918: r0 = lerp()
    //     0x10f0918: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f091c: mov             x3, x0
    // 0x10f0920: ldur            x2, [fp, #-0x10]
    // 0x10f0924: stur            x3, [fp, #-0x28]
    // 0x10f0928: LoadField: r4 = r2->field_f
    //     0x10f0928: ldur            w4, [x2, #0xf]
    // 0x10f092c: DecompressPointer r4
    //     0x10f092c: add             x4, x4, HEAP, lsl #32
    // 0x10f0930: ldur            x0, [fp, #-0x18]
    // 0x10f0934: stur            x4, [fp, #-0x20]
    // 0x10f0938: r1 = LoadClassIdInstr(r0)
    //     0x10f0938: ldur            x1, [x0, #-1]
    //     0x10f093c: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0940: mov             x16, x0
    // 0x10f0944: mov             x0, x1
    // 0x10f0948: mov             x1, x16
    // 0x10f094c: r0 = GDT[cid_x0 + -0xfdb]()
    //     0x10f094c: sub             lr, x0, #0xfdb
    //     0x10f0950: ldr             lr, [x21, lr, lsl #3]
    //     0x10f0954: blr             lr
    // 0x10f0958: ldur            x1, [fp, #-0x20]
    // 0x10f095c: mov             x2, x0
    // 0x10f0960: ldur            d0, [fp, #-0x30]
    // 0x10f0964: r0 = lerp()
    //     0x10f0964: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10f0968: ldur            x3, [fp, #-0x10]
    // 0x10f096c: stur            x0, [fp, #-0x20]
    // 0x10f0970: LoadField: d0 = r3->field_13
    //     0x10f0970: ldur            d0, [x3, #0x13]
    // 0x10f0974: ldur            d1, [fp, #-0x30]
    // 0x10f0978: d2 = 1.000000
    //     0x10f0978: fmov            d2, #1.00000000
    // 0x10f097c: fsub            d3, d2, d1
    // 0x10f0980: fmul            d1, d0, d3
    // 0x10f0984: stur            d1, [fp, #-0x40]
    // 0x10f0988: LoadField: d0 = r3->field_1b
    //     0x10f0988: ldur            d0, [x3, #0x1b]
    // 0x10f098c: stur            d0, [fp, #-0x38]
    // 0x10f0990: r1 = LoadClassIdInstr(r3)
    //     0x10f0990: ldur            x1, [x3, #-1]
    //     0x10f0994: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0998: cmp             x1, #0xbd0
    // 0x10f099c: b.ne            #0x10f09dc
    // 0x10f09a0: ldur            x2, [fp, #-0x28]
    // 0x10f09a4: r1 = <RoundedSuperellipseBorder>
    //     0x10f09a4: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10f09a8: ldr             x1, [x1, #0xda8]
    // 0x10f09ac: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10f09ac: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10f09b0: mov             x1, x0
    // 0x10f09b4: ldur            x0, [fp, #-0x20]
    // 0x10f09b8: StoreField: r1->field_f = r0
    //     0x10f09b8: stur            w0, [x1, #0xf]
    // 0x10f09bc: ldur            d0, [fp, #-0x40]
    // 0x10f09c0: StoreField: r1->field_13 = d0
    //     0x10f09c0: stur            d0, [x1, #0x13]
    // 0x10f09c4: ldur            d1, [fp, #-0x38]
    // 0x10f09c8: StoreField: r1->field_1b = d1
    //     0x10f09c8: stur            d1, [x1, #0x1b]
    // 0x10f09cc: ldur            x2, [fp, #-0x28]
    // 0x10f09d0: StoreField: r1->field_7 = r2
    //     0x10f09d0: stur            w2, [x1, #7]
    // 0x10f09d4: mov             x0, x1
    // 0x10f09d8: b               #0x10f0a20
    // 0x10f09dc: ldur            x2, [fp, #-0x28]
    // 0x10f09e0: mov             v31.16b, v0.16b
    // 0x10f09e4: mov             v0.16b, v1.16b
    // 0x10f09e8: mov             v1.16b, v31.16b
    // 0x10f09ec: r1 = <RoundedRectangleBorder>
    //     0x10f09ec: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10f09f0: ldr             x1, [x1, #0xd90]
    // 0x10f09f4: r0 = _RoundedRectangleToCircleBorder()
    //     0x10f09f4: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10f09f8: mov             x1, x0
    // 0x10f09fc: ldur            x0, [fp, #-0x20]
    // 0x10f0a00: StoreField: r1->field_f = r0
    //     0x10f0a00: stur            w0, [x1, #0xf]
    // 0x10f0a04: ldur            d0, [fp, #-0x40]
    // 0x10f0a08: StoreField: r1->field_13 = d0
    //     0x10f0a08: stur            d0, [x1, #0x13]
    // 0x10f0a0c: ldur            d0, [fp, #-0x38]
    // 0x10f0a10: StoreField: r1->field_1b = d0
    //     0x10f0a10: stur            d0, [x1, #0x1b]
    // 0x10f0a14: ldur            x0, [fp, #-0x28]
    // 0x10f0a18: StoreField: r1->field_7 = r0
    //     0x10f0a18: stur            w0, [x1, #7]
    // 0x10f0a1c: mov             x0, x1
    // 0x10f0a20: LeaveFrame
    //     0x10f0a20: mov             SP, fp
    //     0x10f0a24: ldp             fp, lr, [SP], #0x10
    // 0x10f0a28: ret
    //     0x10f0a28: ret             
    // 0x10f0a2c: ldur            x3, [fp, #-0x10]
    // 0x10f0a30: ldur            x0, [fp, #-0x18]
    // 0x10f0a34: ldur            d1, [fp, #-0x30]
    // 0x10f0a38: d2 = 1.000000
    //     0x10f0a38: fmov            d2, #1.00000000
    // 0x10f0a3c: r1 = LoadClassIdInstr(r0)
    //     0x10f0a3c: ldur            x1, [x0, #-1]
    //     0x10f0a40: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0a44: cmp             x1, #0xbd2
    // 0x10f0a48: b.ne            #0x10f0b40
    // 0x10f0a4c: LoadField: r1 = r3->field_7
    //     0x10f0a4c: ldur            w1, [x3, #7]
    // 0x10f0a50: DecompressPointer r1
    //     0x10f0a50: add             x1, x1, HEAP, lsl #32
    // 0x10f0a54: LoadField: r2 = r0->field_7
    //     0x10f0a54: ldur            w2, [x0, #7]
    // 0x10f0a58: DecompressPointer r2
    //     0x10f0a58: add             x2, x2, HEAP, lsl #32
    // 0x10f0a5c: mov             v0.16b, v1.16b
    // 0x10f0a60: r0 = lerp()
    //     0x10f0a60: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0a64: ldur            x3, [fp, #-0x10]
    // 0x10f0a68: stur            x0, [fp, #-0x28]
    // 0x10f0a6c: LoadField: r2 = r3->field_f
    //     0x10f0a6c: ldur            w2, [x3, #0xf]
    // 0x10f0a70: DecompressPointer r2
    //     0x10f0a70: add             x2, x2, HEAP, lsl #32
    // 0x10f0a74: stur            x2, [fp, #-0x20]
    // 0x10f0a78: LoadField: d0 = r3->field_13
    //     0x10f0a78: ldur            d0, [x3, #0x13]
    // 0x10f0a7c: d1 = 1.000000
    //     0x10f0a7c: fmov            d1, #1.00000000
    // 0x10f0a80: fsub            d2, d1, d0
    // 0x10f0a84: ldur            d1, [fp, #-0x30]
    // 0x10f0a88: fmul            d3, d2, d1
    // 0x10f0a8c: fadd            d1, d0, d3
    // 0x10f0a90: ldur            x4, [fp, #-0x18]
    // 0x10f0a94: stur            d1, [fp, #-0x40]
    // 0x10f0a98: LoadField: d0 = r4->field_b
    //     0x10f0a98: ldur            d0, [x4, #0xb]
    // 0x10f0a9c: stur            d0, [fp, #-0x38]
    // 0x10f0aa0: r1 = LoadClassIdInstr(r3)
    //     0x10f0aa0: ldur            x1, [x3, #-1]
    //     0x10f0aa4: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0aa8: cmp             x1, #0xbd0
    // 0x10f0aac: b.ne            #0x10f0ae8
    // 0x10f0ab0: r1 = <RoundedSuperellipseBorder>
    //     0x10f0ab0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10f0ab4: ldr             x1, [x1, #0xda8]
    // 0x10f0ab8: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10f0ab8: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10f0abc: mov             x1, x0
    // 0x10f0ac0: ldur            x0, [fp, #-0x20]
    // 0x10f0ac4: StoreField: r1->field_f = r0
    //     0x10f0ac4: stur            w0, [x1, #0xf]
    // 0x10f0ac8: ldur            d0, [fp, #-0x40]
    // 0x10f0acc: StoreField: r1->field_13 = d0
    //     0x10f0acc: stur            d0, [x1, #0x13]
    // 0x10f0ad0: ldur            d1, [fp, #-0x38]
    // 0x10f0ad4: StoreField: r1->field_1b = d1
    //     0x10f0ad4: stur            d1, [x1, #0x1b]
    // 0x10f0ad8: ldur            x2, [fp, #-0x28]
    // 0x10f0adc: StoreField: r1->field_7 = r2
    //     0x10f0adc: stur            w2, [x1, #7]
    // 0x10f0ae0: mov             x0, x1
    // 0x10f0ae4: b               #0x10f0b34
    // 0x10f0ae8: mov             x16, x2
    // 0x10f0aec: mov             x2, x0
    // 0x10f0af0: mov             x0, x16
    // 0x10f0af4: mov             v31.16b, v0.16b
    // 0x10f0af8: mov             v0.16b, v1.16b
    // 0x10f0afc: mov             v1.16b, v31.16b
    // 0x10f0b00: r1 = <RoundedRectangleBorder>
    //     0x10f0b00: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10f0b04: ldr             x1, [x1, #0xd90]
    // 0x10f0b08: r0 = _RoundedRectangleToCircleBorder()
    //     0x10f0b08: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10f0b0c: mov             x1, x0
    // 0x10f0b10: ldur            x0, [fp, #-0x20]
    // 0x10f0b14: StoreField: r1->field_f = r0
    //     0x10f0b14: stur            w0, [x1, #0xf]
    // 0x10f0b18: ldur            d0, [fp, #-0x40]
    // 0x10f0b1c: StoreField: r1->field_13 = d0
    //     0x10f0b1c: stur            d0, [x1, #0x13]
    // 0x10f0b20: ldur            d0, [fp, #-0x38]
    // 0x10f0b24: StoreField: r1->field_1b = d0
    //     0x10f0b24: stur            d0, [x1, #0x1b]
    // 0x10f0b28: ldur            x0, [fp, #-0x28]
    // 0x10f0b2c: StoreField: r1->field_7 = r0
    //     0x10f0b2c: stur            w0, [x1, #7]
    // 0x10f0b30: mov             x0, x1
    // 0x10f0b34: LeaveFrame
    //     0x10f0b34: mov             SP, fp
    //     0x10f0b38: ldp             fp, lr, [SP], #0x10
    // 0x10f0b3c: ret
    //     0x10f0b3c: ret             
    // 0x10f0b40: mov             x4, x0
    // 0x10f0b44: mov             x0, x4
    // 0x10f0b48: ldur            x2, [fp, #-8]
    // 0x10f0b4c: r1 = Null
    //     0x10f0b4c: mov             x1, NULL
    // 0x10f0b50: cmp             w0, NULL
    // 0x10f0b54: b.eq            #0x10f0ba0
    // 0x10f0b58: branchIfSmi(r0, 0x10f0ba0)
    //     0x10f0b58: tbz             w0, #0, #0x10f0ba0
    // 0x10f0b5c: r3 = SubtypeTestCache
    //     0x10f0b5c: add             x3, PP, #0xac, lsl #12  ; [pp+0xace10] SubtypeTestCache
    //     0x10f0b60: ldr             x3, [x3, #0xe10]
    // 0x10f0b64: r30 = Subtype3TestCacheStub
    //     0x10f0b64: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x10f0b68: LoadField: r30 = r30->field_7
    //     0x10f0b68: ldur            lr, [lr, #7]
    // 0x10f0b6c: blr             lr
    // 0x10f0b70: cmp             w7, NULL
    // 0x10f0b74: b.eq            #0x10f0b80
    // 0x10f0b78: tbnz            w7, #4, #0x10f0ba0
    // 0x10f0b7c: b               #0x10f0ba8
    // 0x10f0b80: r8 = _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x10f0b80: add             x8, PP, #0xac, lsl #12  ; [pp+0xace18] Type: _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x10f0b84: ldr             x8, [x8, #0xe18]
    // 0x10f0b88: r3 = SubtypeTestCache
    //     0x10f0b88: add             x3, PP, #0xac, lsl #12  ; [pp+0xace20] SubtypeTestCache
    //     0x10f0b8c: ldr             x3, [x3, #0xe20]
    // 0x10f0b90: r30 = InstanceOfStub
    //     0x10f0b90: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x10f0b94: LoadField: r30 = r30->field_7
    //     0x10f0b94: ldur            lr, [lr, #7]
    // 0x10f0b98: blr             lr
    // 0x10f0b9c: b               #0x10f0bac
    // 0x10f0ba0: r0 = false
    //     0x10f0ba0: add             x0, NULL, #0x30  ; false
    // 0x10f0ba4: b               #0x10f0bac
    // 0x10f0ba8: r0 = true
    //     0x10f0ba8: add             x0, NULL, #0x20  ; true
    // 0x10f0bac: tbnz            w0, #4, #0x10f0d54
    // 0x10f0bb0: ldur            x0, [fp, #-0x10]
    // 0x10f0bb4: ldur            x3, [fp, #-0x18]
    // 0x10f0bb8: ldur            d1, [fp, #-0x30]
    // 0x10f0bbc: LoadField: r1 = r0->field_7
    //     0x10f0bbc: ldur            w1, [x0, #7]
    // 0x10f0bc0: DecompressPointer r1
    //     0x10f0bc0: add             x1, x1, HEAP, lsl #32
    // 0x10f0bc4: LoadField: r2 = r3->field_7
    //     0x10f0bc4: ldur            w2, [x3, #7]
    // 0x10f0bc8: DecompressPointer r2
    //     0x10f0bc8: add             x2, x2, HEAP, lsl #32
    // 0x10f0bcc: mov             v0.16b, v1.16b
    // 0x10f0bd0: r0 = lerp()
    //     0x10f0bd0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0bd4: mov             x3, x0
    // 0x10f0bd8: ldur            x0, [fp, #-0x10]
    // 0x10f0bdc: stur            x3, [fp, #-8]
    // 0x10f0be0: LoadField: r1 = r0->field_f
    //     0x10f0be0: ldur            w1, [x0, #0xf]
    // 0x10f0be4: DecompressPointer r1
    //     0x10f0be4: add             x1, x1, HEAP, lsl #32
    // 0x10f0be8: ldur            x4, [fp, #-0x18]
    // 0x10f0bec: LoadField: r2 = r4->field_f
    //     0x10f0bec: ldur            w2, [x4, #0xf]
    // 0x10f0bf0: DecompressPointer r2
    //     0x10f0bf0: add             x2, x2, HEAP, lsl #32
    // 0x10f0bf4: ldur            d0, [fp, #-0x30]
    // 0x10f0bf8: r0 = lerp()
    //     0x10f0bf8: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10f0bfc: mov             x4, x0
    // 0x10f0c00: ldur            x0, [fp, #-0x10]
    // 0x10f0c04: stur            x4, [fp, #-0x20]
    // 0x10f0c08: LoadField: d0 = r0->field_13
    //     0x10f0c08: ldur            d0, [x0, #0x13]
    // 0x10f0c0c: ldur            x2, [fp, #-0x18]
    // 0x10f0c10: LoadField: d1 = r2->field_13
    //     0x10f0c10: ldur            d1, [x2, #0x13]
    // 0x10f0c14: ldur            d2, [fp, #-0x30]
    // 0x10f0c18: r3 = inline_Allocate_Double()
    //     0x10f0c18: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x10f0c1c: add             x3, x3, #0x10
    //     0x10f0c20: cmp             x1, x3
    //     0x10f0c24: b.ls            #0x10f0d7c
    //     0x10f0c28: str             x3, [THR, #0x60]  ; THR::top
    //     0x10f0c2c: sub             x3, x3, #0xf
    //     0x10f0c30: mov             x1, #0xe19c
    //     0x10f0c34: movk            x1, #3, lsl #16
    //     0x10f0c38: stur            x1, [x3, #-1]
    // 0x10f0c3c: dmb             ishst
    // 0x10f0c40: StoreField: r3->field_7 = d2
    //     0x10f0c40: stur            d2, [x3, #7]
    // 0x10f0c44: r1 = inline_Allocate_Double()
    //     0x10f0c44: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10f0c48: add             x1, x1, #0x10
    //     0x10f0c4c: cmp             x2, x1
    //     0x10f0c50: b.ls            #0x10f0da0
    //     0x10f0c54: str             x1, [THR, #0x60]  ; THR::top
    //     0x10f0c58: sub             x1, x1, #0xf
    //     0x10f0c5c: mov             x2, #0xe19c
    //     0x10f0c60: movk            x2, #3, lsl #16
    //     0x10f0c64: stur            x2, [x1, #-1]
    // 0x10f0c68: dmb             ishst
    // 0x10f0c6c: StoreField: r1->field_7 = d0
    //     0x10f0c6c: stur            d0, [x1, #7]
    // 0x10f0c70: r2 = inline_Allocate_Double()
    //     0x10f0c70: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0x10f0c74: add             x2, x2, #0x10
    //     0x10f0c78: cmp             x5, x2
    //     0x10f0c7c: b.ls            #0x10f0dc4
    //     0x10f0c80: str             x2, [THR, #0x60]  ; THR::top
    //     0x10f0c84: sub             x2, x2, #0xf
    //     0x10f0c88: mov             x5, #0xe19c
    //     0x10f0c8c: movk            x5, #3, lsl #16
    //     0x10f0c90: stur            x5, [x2, #-1]
    // 0x10f0c94: dmb             ishst
    // 0x10f0c98: StoreField: r2->field_7 = d1
    //     0x10f0c98: stur            d1, [x2, #7]
    // 0x10f0c9c: r0 = lerpDouble()
    //     0x10f0c9c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10f0ca0: ldur            x1, [fp, #-0x10]
    // 0x10f0ca4: stur            x0, [fp, #-0x28]
    // 0x10f0ca8: LoadField: d0 = r1->field_1b
    //     0x10f0ca8: ldur            d0, [x1, #0x1b]
    // 0x10f0cac: stur            d0, [fp, #-0x38]
    // 0x10f0cb0: r2 = LoadClassIdInstr(r1)
    //     0x10f0cb0: ldur            x2, [x1, #-1]
    //     0x10f0cb4: ubfx            x2, x2, #0xc, #0x14
    // 0x10f0cb8: cmp             x2, #0xbd0
    // 0x10f0cbc: b.ne            #0x10f0d04
    // 0x10f0cc0: ldur            x3, [fp, #-8]
    // 0x10f0cc4: ldur            x2, [fp, #-0x20]
    // 0x10f0cc8: r1 = <RoundedSuperellipseBorder>
    //     0x10f0cc8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10f0ccc: ldr             x1, [x1, #0xda8]
    // 0x10f0cd0: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10f0cd0: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10f0cd4: mov             x1, x0
    // 0x10f0cd8: ldur            x0, [fp, #-0x20]
    // 0x10f0cdc: StoreField: r1->field_f = r0
    //     0x10f0cdc: stur            w0, [x1, #0xf]
    // 0x10f0ce0: ldur            x2, [fp, #-0x28]
    // 0x10f0ce4: LoadField: d0 = r2->field_7
    //     0x10f0ce4: ldur            d0, [x2, #7]
    // 0x10f0ce8: StoreField: r1->field_13 = d0
    //     0x10f0ce8: stur            d0, [x1, #0x13]
    // 0x10f0cec: ldur            d0, [fp, #-0x38]
    // 0x10f0cf0: StoreField: r1->field_1b = d0
    //     0x10f0cf0: stur            d0, [x1, #0x1b]
    // 0x10f0cf4: ldur            x3, [fp, #-8]
    // 0x10f0cf8: StoreField: r1->field_7 = r3
    //     0x10f0cf8: stur            w3, [x1, #7]
    // 0x10f0cfc: mov             x0, x1
    // 0x10f0d00: b               #0x10f0d48
    // 0x10f0d04: ldur            x3, [fp, #-8]
    // 0x10f0d08: mov             x2, x0
    // 0x10f0d0c: ldur            x0, [fp, #-0x20]
    // 0x10f0d10: r1 = <RoundedRectangleBorder>
    //     0x10f0d10: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10f0d14: ldr             x1, [x1, #0xd90]
    // 0x10f0d18: r0 = _RoundedRectangleToCircleBorder()
    //     0x10f0d18: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10f0d1c: mov             x1, x0
    // 0x10f0d20: ldur            x0, [fp, #-0x20]
    // 0x10f0d24: StoreField: r1->field_f = r0
    //     0x10f0d24: stur            w0, [x1, #0xf]
    // 0x10f0d28: ldur            x0, [fp, #-0x28]
    // 0x10f0d2c: LoadField: d0 = r0->field_7
    //     0x10f0d2c: ldur            d0, [x0, #7]
    // 0x10f0d30: StoreField: r1->field_13 = d0
    //     0x10f0d30: stur            d0, [x1, #0x13]
    // 0x10f0d34: ldur            d0, [fp, #-0x38]
    // 0x10f0d38: StoreField: r1->field_1b = d0
    //     0x10f0d38: stur            d0, [x1, #0x1b]
    // 0x10f0d3c: ldur            x0, [fp, #-8]
    // 0x10f0d40: StoreField: r1->field_7 = r0
    //     0x10f0d40: stur            w0, [x1, #7]
    // 0x10f0d44: mov             x0, x1
    // 0x10f0d48: LeaveFrame
    //     0x10f0d48: mov             SP, fp
    //     0x10f0d4c: ldp             fp, lr, [SP], #0x10
    // 0x10f0d50: ret
    //     0x10f0d50: ret             
    // 0x10f0d54: ldur            x1, [fp, #-0x10]
    // 0x10f0d58: ldur            x2, [fp, #-0x18]
    // 0x10f0d5c: ldur            d2, [fp, #-0x30]
    // 0x10f0d60: mov             v0.16b, v2.16b
    // 0x10f0d64: r0 = lerpTo()
    //     0x10f0d64: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f0d68: LeaveFrame
    //     0x10f0d68: mov             SP, fp
    //     0x10f0d6c: ldp             fp, lr, [SP], #0x10
    // 0x10f0d70: ret
    //     0x10f0d70: ret             
    // 0x10f0d74: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f0d74: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f0d78: b               #0x10f083c
    // 0x10f0d7c: stp             q1, q2, [SP, #-0x20]!
    // 0x10f0d80: SaveReg d0
    //     0x10f0d80: str             q0, [SP, #-0x10]!
    // 0x10f0d84: stp             x0, x4, [SP, #-0x10]!
    // 0x10f0d88: r0 = AllocateDouble()
    //     0x10f0d88: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f0d8c: mov             x3, x0
    // 0x10f0d90: ldp             x0, x4, [SP], #0x10
    // 0x10f0d94: RestoreReg d0
    //     0x10f0d94: ldr             q0, [SP], #0x10
    // 0x10f0d98: ldp             q1, q2, [SP], #0x20
    // 0x10f0d9c: b               #0x10f0c40
    // 0x10f0da0: stp             q0, q1, [SP, #-0x20]!
    // 0x10f0da4: stp             x3, x4, [SP, #-0x10]!
    // 0x10f0da8: SaveReg r0
    //     0x10f0da8: str             x0, [SP, #-8]!
    // 0x10f0dac: r0 = AllocateDouble()
    //     0x10f0dac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f0db0: mov             x1, x0
    // 0x10f0db4: RestoreReg r0
    //     0x10f0db4: ldr             x0, [SP], #8
    // 0x10f0db8: ldp             x3, x4, [SP], #0x10
    // 0x10f0dbc: ldp             q0, q1, [SP], #0x20
    // 0x10f0dc0: b               #0x10f0c6c
    // 0x10f0dc4: SaveReg d1
    //     0x10f0dc4: str             q1, [SP, #-0x10]!
    // 0x10f0dc8: stp             x3, x4, [SP, #-0x10]!
    // 0x10f0dcc: stp             x0, x1, [SP, #-0x10]!
    // 0x10f0dd0: r0 = AllocateDouble()
    //     0x10f0dd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f0dd4: mov             x2, x0
    // 0x10f0dd8: ldp             x0, x1, [SP], #0x10
    // 0x10f0ddc: ldp             x3, x4, [SP], #0x10
    // 0x10f0de0: RestoreReg d1
    //     0x10f0de0: ldr             q1, [SP], #0x10
    // 0x10f0de4: b               #0x10f0c98
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114ac68, size: 0xac
    // 0x114ac68: EnterFrame
    //     0x114ac68: stp             fp, lr, [SP, #-0x10]!
    //     0x114ac6c: mov             fp, SP
    // 0x114ac70: AllocStack(0x8)
    //     0x114ac70: sub             SP, SP, #8
    // 0x114ac74: CheckStackOverflow
    //     0x114ac74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ac78: cmp             SP, x16
    //     0x114ac7c: b.ls            #0x114acf4
    // 0x114ac80: ldr             x0, [fp, #0x10]
    // 0x114ac84: LoadField: r1 = r0->field_7
    //     0x114ac84: ldur            w1, [x0, #7]
    // 0x114ac88: DecompressPointer r1
    //     0x114ac88: add             x1, x1, HEAP, lsl #32
    // 0x114ac8c: LoadField: r2 = r0->field_f
    //     0x114ac8c: ldur            w2, [x0, #0xf]
    // 0x114ac90: DecompressPointer r2
    //     0x114ac90: add             x2, x2, HEAP, lsl #32
    // 0x114ac94: LoadField: d0 = r0->field_13
    //     0x114ac94: ldur            d0, [x0, #0x13]
    // 0x114ac98: r0 = inline_Allocate_Double()
    //     0x114ac98: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114ac9c: add             x0, x0, #0x10
    //     0x114aca0: cmp             x3, x0
    //     0x114aca4: b.ls            #0x114acfc
    //     0x114aca8: str             x0, [THR, #0x60]  ; THR::top
    //     0x114acac: sub             x0, x0, #0xf
    //     0x114acb0: mov             x3, #0xe19c
    //     0x114acb4: movk            x3, #3, lsl #16
    //     0x114acb8: stur            x3, [x0, #-1]
    // 0x114acbc: dmb             ishst
    // 0x114acc0: StoreField: r0->field_7 = d0
    //     0x114acc0: stur            d0, [x0, #7]
    // 0x114acc4: str             x0, [SP]
    // 0x114acc8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114acc8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114accc: r0 = hash()
    //     0x114accc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114acd0: mov             x2, x0
    // 0x114acd4: r0 = BoxInt64Instr(r2)
    //     0x114acd4: sbfiz           x0, x2, #1, #0x1f
    //     0x114acd8: cmp             x2, x0, asr #1
    //     0x114acdc: b.eq            #0x114ace8
    //     0x114ace0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ace4: stur            x2, [x0, #7]
    // 0x114ace8: LeaveFrame
    //     0x114ace8: mov             SP, fp
    //     0x114acec: ldp             fp, lr, [SP], #0x10
    // 0x114acf0: ret
    //     0x114acf0: ret             
    // 0x114acf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114acf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114acf8: b               #0x114ac80
    // 0x114acfc: SaveReg d0
    //     0x114acfc: str             q0, [SP, #-0x10]!
    // 0x114ad00: stp             x1, x2, [SP, #-0x10]!
    // 0x114ad04: r0 = AllocateDouble()
    //     0x114ad04: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114ad08: ldp             x1, x2, [SP], #0x10
    // 0x114ad0c: RestoreReg d0
    //     0x114ad0c: ldr             q0, [SP], #0x10
    // 0x114ad10: b               #0x114acc0
  }
  _ ==(/* No info */) {
    // ** addr: 0x12961ac, size: 0x150
    // 0x12961ac: EnterFrame
    //     0x12961ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12961b0: mov             fp, SP
    // 0x12961b4: AllocStack(0x10)
    //     0x12961b4: sub             SP, SP, #0x10
    // 0x12961b8: CheckStackOverflow
    //     0x12961b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12961bc: cmp             SP, x16
    //     0x12961c0: b.ls            #0x12962f4
    // 0x12961c4: ldr             x0, [fp, #0x10]
    // 0x12961c8: cmp             w0, NULL
    // 0x12961cc: b.ne            #0x12961e0
    // 0x12961d0: r0 = false
    //     0x12961d0: add             x0, NULL, #0x30  ; false
    // 0x12961d4: LeaveFrame
    //     0x12961d4: mov             SP, fp
    //     0x12961d8: ldp             fp, lr, [SP], #0x10
    // 0x12961dc: ret
    //     0x12961dc: ret             
    // 0x12961e0: ldr             x16, [fp, #0x18]
    // 0x12961e4: stp             x16, x0, [SP]
    // 0x12961e8: r0 = _haveSameRuntimeType()
    //     0x12961e8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12961ec: tbz             w0, #4, #0x1296200
    // 0x12961f0: r0 = false
    //     0x12961f0: add             x0, NULL, #0x30  ; false
    // 0x12961f4: LeaveFrame
    //     0x12961f4: mov             SP, fp
    //     0x12961f8: ldp             fp, lr, [SP], #0x10
    // 0x12961fc: ret
    //     0x12961fc: ret             
    // 0x1296200: ldr             x3, [fp, #0x18]
    // 0x1296204: LoadField: r2 = r3->field_b
    //     0x1296204: ldur            w2, [x3, #0xb]
    // 0x1296208: DecompressPointer r2
    //     0x1296208: add             x2, x2, HEAP, lsl #32
    // 0x129620c: ldr             x0, [fp, #0x10]
    // 0x1296210: r1 = Null
    //     0x1296210: mov             x1, NULL
    // 0x1296214: cmp             w0, NULL
    // 0x1296218: b.eq            #0x1296264
    // 0x129621c: branchIfSmi(r0, 0x1296264)
    //     0x129621c: tbz             w0, #0, #0x1296264
    // 0x1296220: r3 = SubtypeTestCache
    //     0x1296220: add             x3, PP, #0xac, lsl #12  ; [pp+0xacdd0] SubtypeTestCache
    //     0x1296224: ldr             x3, [x3, #0xdd0]
    // 0x1296228: r30 = Subtype3TestCacheStub
    //     0x1296228: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x129622c: LoadField: r30 = r30->field_7
    //     0x129622c: ldur            lr, [lr, #7]
    // 0x1296230: blr             lr
    // 0x1296234: cmp             w7, NULL
    // 0x1296238: b.eq            #0x1296244
    // 0x129623c: tbnz            w7, #4, #0x1296264
    // 0x1296240: b               #0x129626c
    // 0x1296244: r8 = _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x1296244: add             x8, PP, #0xac, lsl #12  ; [pp+0xacdd8] Type: _ShapeToCircleBorder<X0 bound _RRectLikeBorder>
    //     0x1296248: ldr             x8, [x8, #0xdd8]
    // 0x129624c: r3 = SubtypeTestCache
    //     0x129624c: add             x3, PP, #0xac, lsl #12  ; [pp+0xacde0] SubtypeTestCache
    //     0x1296250: ldr             x3, [x3, #0xde0]
    // 0x1296254: r30 = InstanceOfStub
    //     0x1296254: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1296258: LoadField: r30 = r30->field_7
    //     0x1296258: ldur            lr, [lr, #7]
    // 0x129625c: blr             lr
    // 0x1296260: b               #0x1296270
    // 0x1296264: r0 = false
    //     0x1296264: add             x0, NULL, #0x30  ; false
    // 0x1296268: b               #0x1296270
    // 0x129626c: r0 = true
    //     0x129626c: add             x0, NULL, #0x20  ; true
    // 0x1296270: tbnz            w0, #4, #0x12962e4
    // 0x1296274: ldr             x0, [fp, #0x18]
    // 0x1296278: ldr             x1, [fp, #0x10]
    // 0x129627c: LoadField: r2 = r1->field_7
    //     0x129627c: ldur            w2, [x1, #7]
    // 0x1296280: DecompressPointer r2
    //     0x1296280: add             x2, x2, HEAP, lsl #32
    // 0x1296284: LoadField: r3 = r0->field_7
    //     0x1296284: ldur            w3, [x0, #7]
    // 0x1296288: DecompressPointer r3
    //     0x1296288: add             x3, x3, HEAP, lsl #32
    // 0x129628c: stp             x3, x2, [SP]
    // 0x1296290: r0 = ==()
    //     0x1296290: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296294: tbnz            w0, #4, #0x12962e4
    // 0x1296298: ldr             x0, [fp, #0x18]
    // 0x129629c: ldr             x1, [fp, #0x10]
    // 0x12962a0: LoadField: r2 = r1->field_f
    //     0x12962a0: ldur            w2, [x1, #0xf]
    // 0x12962a4: DecompressPointer r2
    //     0x12962a4: add             x2, x2, HEAP, lsl #32
    // 0x12962a8: LoadField: r3 = r0->field_f
    //     0x12962a8: ldur            w3, [x0, #0xf]
    // 0x12962ac: DecompressPointer r3
    //     0x12962ac: add             x3, x3, HEAP, lsl #32
    // 0x12962b0: stp             x3, x2, [SP]
    // 0x12962b4: r0 = ==()
    //     0x12962b4: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12962b8: tbnz            w0, #4, #0x12962e4
    // 0x12962bc: ldr             x1, [fp, #0x18]
    // 0x12962c0: ldr             x2, [fp, #0x10]
    // 0x12962c4: LoadField: d0 = r2->field_13
    //     0x12962c4: ldur            d0, [x2, #0x13]
    // 0x12962c8: LoadField: d1 = r1->field_13
    //     0x12962c8: ldur            d1, [x1, #0x13]
    // 0x12962cc: fcmp            d0, d1
    // 0x12962d0: r16 = true
    //     0x12962d0: add             x16, NULL, #0x20  ; true
    // 0x12962d4: r17 = false
    //     0x12962d4: add             x17, NULL, #0x30  ; false
    // 0x12962d8: csel            x1, x16, x17, eq
    // 0x12962dc: mov             x0, x1
    // 0x12962e0: b               #0x12962e8
    // 0x12962e4: r0 = false
    //     0x12962e4: add             x0, NULL, #0x30  ; false
    // 0x12962e8: LeaveFrame
    //     0x12962e8: mov             SP, fp
    //     0x12962ec: ldp             fp, lr, [SP], #0x10
    // 0x12962f0: ret
    //     0x12962f0: ret             
    // 0x12962f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12962f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12962f8: b               #0x12961c4
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ec5c0, size: 0x134
    // 0x12ec5c0: EnterFrame
    //     0x12ec5c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ec5c4: mov             fp, SP
    // 0x12ec5c8: AllocStack(0x38)
    //     0x12ec5c8: sub             SP, SP, #0x38
    // 0x12ec5cc: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r7, fp-0x8 */, dynamic _ /* r2 => r6, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, {dynamic textDirection = Null /* r3 */})
    //     0x12ec5cc: mov             x7, x1
    //     0x12ec5d0: mov             x6, x2
    //     0x12ec5d4: mov             x0, x5
    //     0x12ec5d8: stur            x5, [fp, #-0x20]
    //     0x12ec5dc: mov             x5, x3
    //     0x12ec5e0: stur            x1, [fp, #-8]
    //     0x12ec5e4: stur            x2, [fp, #-0x10]
    //     0x12ec5e8: stur            x3, [fp, #-0x18]
    //     0x12ec5ec: ldur            w1, [x4, #0x13]
    //     0x12ec5f0: ldur            w2, [x4, #0x1f]
    //     0x12ec5f4: add             x2, x2, HEAP, lsl #32
    //     0x12ec5f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ec5fc: ldr             x16, [x16, #0x210]
    //     0x12ec600: cmp             w2, w16
    //     0x12ec604: b.ne            #0x12ec624
    //     0x12ec608: ldur            w2, [x4, #0x23]
    //     0x12ec60c: add             x2, x2, HEAP, lsl #32
    //     0x12ec610: sub             w3, w1, w2
    //     0x12ec614: add             x1, fp, w3, sxtw #2
    //     0x12ec618: ldr             x1, [x1, #8]
    //     0x12ec61c: mov             x3, x1
    //     0x12ec620: b               #0x12ec628
    //     0x12ec624: mov             x3, NULL
    // 0x12ec628: CheckStackOverflow
    //     0x12ec628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ec62c: cmp             SP, x16
    //     0x12ec630: b.ls            #0x12ec6ec
    // 0x12ec634: mov             x1, x7
    // 0x12ec638: mov             x2, x5
    // 0x12ec63c: r0 = _adjustBorderRadius()
    //     0x12ec63c: bl              #0xbfe718  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustBorderRadius
    // 0x12ec640: stur            x0, [fp, #-0x28]
    // 0x12ec644: r16 = Instance_BorderRadius
    //     0x12ec644: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ec648: ldr             x16, [x16, #0x508]
    // 0x12ec64c: stp             x16, x0, [SP]
    // 0x12ec650: r0 = ==()
    //     0x12ec650: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ec654: tbnz            w0, #4, #0x12ec678
    // 0x12ec658: ldur            x1, [fp, #-8]
    // 0x12ec65c: ldur            x2, [fp, #-0x18]
    // 0x12ec660: r0 = _adjustRect()
    //     0x12ec660: bl              #0xbfec34  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustRect
    // 0x12ec664: ldur            x1, [fp, #-0x10]
    // 0x12ec668: mov             x2, x0
    // 0x12ec66c: ldur            x3, [fp, #-0x20]
    // 0x12ec670: r0 = drawRect()
    //     0x12ec670: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ec674: b               #0x12ec6dc
    // 0x12ec678: ldur            x0, [fp, #-8]
    // 0x12ec67c: mov             x1, x0
    // 0x12ec680: ldur            x2, [fp, #-0x18]
    // 0x12ec684: r0 = _adjustRect()
    //     0x12ec684: bl              #0xbfec34  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustRect
    // 0x12ec688: mov             x1, x0
    // 0x12ec68c: ldur            x0, [fp, #-8]
    // 0x12ec690: r2 = LoadClassIdInstr(r0)
    //     0x12ec690: ldur            x2, [x0, #-1]
    //     0x12ec694: ubfx            x2, x2, #0xc, #0x14
    // 0x12ec698: cmp             x2, #0xbd0
    // 0x12ec69c: b.ne            #0x12ec6c0
    // 0x12ec6a0: mov             x2, x1
    // 0x12ec6a4: ldur            x1, [fp, #-0x28]
    // 0x12ec6a8: r0 = toRSuperellipse()
    //     0x12ec6a8: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x12ec6ac: ldur            x1, [fp, #-0x10]
    // 0x12ec6b0: mov             x2, x0
    // 0x12ec6b4: ldur            x3, [fp, #-0x20]
    // 0x12ec6b8: r0 = drawRSuperellipse()
    //     0x12ec6b8: bl              #0x12ebed0  ; [dart:ui] _NativeCanvas::drawRSuperellipse
    // 0x12ec6bc: b               #0x12ec6dc
    // 0x12ec6c0: mov             x2, x1
    // 0x12ec6c4: ldur            x1, [fp, #-0x28]
    // 0x12ec6c8: r0 = toRRect()
    //     0x12ec6c8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ec6cc: ldur            x1, [fp, #-0x10]
    // 0x12ec6d0: mov             x2, x0
    // 0x12ec6d4: ldur            x3, [fp, #-0x20]
    // 0x12ec6d8: r0 = drawRRect()
    //     0x12ec6d8: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ec6dc: r0 = Null
    //     0x12ec6dc: mov             x0, NULL
    // 0x12ec6e0: LeaveFrame
    //     0x12ec6e0: mov             SP, fp
    //     0x12ec6e4: ldp             fp, lr, [SP], #0x10
    // 0x12ec6e8: ret
    //     0x12ec6e8: ret             
    // 0x12ec6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ec6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ec6f0: b               #0x12ec634
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ed754, size: 0x160
    // 0x12ed754: EnterFrame
    //     0x12ed754: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed758: mov             fp, SP
    // 0x12ed75c: AllocStack(0x38)
    //     0x12ed75c: sub             SP, SP, #0x38
    // 0x12ed760: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */, dynamic _ /* r3 => r0, fp-0x28 */, {dynamic textDirection = Null /* r4, fp-0x10 */})
    //     0x12ed760: mov             x5, x1
    //     0x12ed764: mov             x0, x3
    //     0x12ed768: stur            x3, [fp, #-0x28]
    //     0x12ed76c: mov             x3, x2
    //     0x12ed770: stur            x1, [fp, #-0x18]
    //     0x12ed774: stur            x2, [fp, #-0x20]
    //     0x12ed778: ldur            w1, [x4, #0x13]
    //     0x12ed77c: ldur            w2, [x4, #0x1f]
    //     0x12ed780: add             x2, x2, HEAP, lsl #32
    //     0x12ed784: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ed788: ldr             x16, [x16, #0x210]
    //     0x12ed78c: cmp             w2, w16
    //     0x12ed790: b.ne            #0x12ed7b0
    //     0x12ed794: ldur            w2, [x4, #0x23]
    //     0x12ed798: add             x2, x2, HEAP, lsl #32
    //     0x12ed79c: sub             w4, w1, w2
    //     0x12ed7a0: add             x1, fp, w4, sxtw #2
    //     0x12ed7a4: ldr             x1, [x1, #8]
    //     0x12ed7a8: mov             x4, x1
    //     0x12ed7ac: b               #0x12ed7b4
    //     0x12ed7b0: mov             x4, NULL
    //     0x12ed7b4: stur            x4, [fp, #-0x10]
    // 0x12ed7b8: CheckStackOverflow
    //     0x12ed7b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed7bc: cmp             SP, x16
    //     0x12ed7c0: b.ls            #0x12ed8ac
    // 0x12ed7c4: LoadField: r6 = r5->field_7
    //     0x12ed7c4: ldur            w6, [x5, #7]
    // 0x12ed7c8: DecompressPointer r6
    //     0x12ed7c8: add             x6, x6, HEAP, lsl #32
    // 0x12ed7cc: stur            x6, [fp, #-8]
    // 0x12ed7d0: LoadField: r1 = r6->field_13
    //     0x12ed7d0: ldur            w1, [x6, #0x13]
    // 0x12ed7d4: DecompressPointer r1
    //     0x12ed7d4: add             x1, x1, HEAP, lsl #32
    // 0x12ed7d8: LoadField: r2 = r1->field_7
    //     0x12ed7d8: ldur            x2, [x1, #7]
    // 0x12ed7dc: cmp             x2, #0
    // 0x12ed7e0: b.le            #0x12ed89c
    // 0x12ed7e4: mov             x1, x5
    // 0x12ed7e8: mov             x2, x0
    // 0x12ed7ec: r0 = _adjustRect()
    //     0x12ed7ec: bl              #0xbfec34  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustRect
    // 0x12ed7f0: ldur            x1, [fp, #-0x18]
    // 0x12ed7f4: ldur            x2, [fp, #-0x28]
    // 0x12ed7f8: ldur            x3, [fp, #-0x10]
    // 0x12ed7fc: stur            x0, [fp, #-0x10]
    // 0x12ed800: r0 = _adjustBorderRadius()
    //     0x12ed800: bl              #0xbfe718  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustBorderRadius
    // 0x12ed804: ldur            x1, [fp, #-8]
    // 0x12ed808: stur            x0, [fp, #-0x28]
    // 0x12ed80c: r0 = toPaint()
    //     0x12ed80c: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed810: mov             x3, x0
    // 0x12ed814: ldur            x0, [fp, #-8]
    // 0x12ed818: stur            x3, [fp, #-0x30]
    // 0x12ed81c: LoadField: d0 = r0->field_b
    //     0x12ed81c: ldur            d0, [x0, #0xb]
    // 0x12ed820: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12ed820: ldur            d1, [x0, #0x17]
    // 0x12ed824: fmul            d2, d0, d1
    // 0x12ed828: d0 = 2.000000
    //     0x12ed828: fmov            d0, #2.00000000
    // 0x12ed82c: fdiv            d1, d2, d0
    // 0x12ed830: ldur            x0, [fp, #-0x18]
    // 0x12ed834: stur            d1, [fp, #-0x38]
    // 0x12ed838: r1 = LoadClassIdInstr(r0)
    //     0x12ed838: ldur            x1, [x0, #-1]
    //     0x12ed83c: ubfx            x1, x1, #0xc, #0x14
    // 0x12ed840: cmp             x1, #0xbd0
    // 0x12ed844: b.ne            #0x12ed874
    // 0x12ed848: ldur            x1, [fp, #-0x28]
    // 0x12ed84c: ldur            x2, [fp, #-0x10]
    // 0x12ed850: r0 = toRSuperellipse()
    //     0x12ed850: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x12ed854: mov             x1, x0
    // 0x12ed858: ldur            d0, [fp, #-0x38]
    // 0x12ed85c: r0 = inflate()
    //     0x12ed85c: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12ed860: ldur            x1, [fp, #-0x20]
    // 0x12ed864: mov             x2, x0
    // 0x12ed868: ldur            x3, [fp, #-0x30]
    // 0x12ed86c: r0 = drawRSuperellipse()
    //     0x12ed86c: bl              #0x12ebed0  ; [dart:ui] _NativeCanvas::drawRSuperellipse
    // 0x12ed870: b               #0x12ed89c
    // 0x12ed874: ldur            x1, [fp, #-0x28]
    // 0x12ed878: ldur            x2, [fp, #-0x10]
    // 0x12ed87c: r0 = toRRect()
    //     0x12ed87c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ed880: mov             x1, x0
    // 0x12ed884: ldur            d0, [fp, #-0x38]
    // 0x12ed888: r0 = inflate()
    //     0x12ed888: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12ed88c: ldur            x1, [fp, #-0x20]
    // 0x12ed890: mov             x2, x0
    // 0x12ed894: ldur            x3, [fp, #-0x30]
    // 0x12ed898: r0 = drawRRect()
    //     0x12ed898: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ed89c: r0 = Null
    //     0x12ed89c: mov             x0, NULL
    // 0x12ed8a0: LeaveFrame
    //     0x12ed8a0: mov             SP, fp
    //     0x12ed8a4: ldp             fp, lr, [SP], #0x10
    // 0x12ed8a8: ret
    //     0x12ed8a8: ret             
    // 0x12ed8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ed8ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ed8b0: b               #0x12ed7c4
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fc8d0, size: 0x26c
    // 0x12fc8d0: EnterFrame
    //     0x12fc8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc8d4: mov             fp, SP
    // 0x12fc8d8: AllocStack(0x48)
    //     0x12fc8d8: sub             SP, SP, #0x48
    // 0x12fc8dc: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x40 */)
    //     0x12fc8dc: mov             x0, x1
    //     0x12fc8e0: mov             v1.16b, v0.16b
    //     0x12fc8e4: stur            x1, [fp, #-8]
    //     0x12fc8e8: stur            d0, [fp, #-0x40]
    // 0x12fc8ec: CheckStackOverflow
    //     0x12fc8ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc8f0: cmp             SP, x16
    //     0x12fc8f4: b.ls            #0x12fcb34
    // 0x12fc8f8: LoadField: r1 = r0->field_7
    //     0x12fc8f8: ldur            w1, [x0, #7]
    // 0x12fc8fc: DecompressPointer r1
    //     0x12fc8fc: add             x1, x1, HEAP, lsl #32
    // 0x12fc900: mov             v0.16b, v1.16b
    // 0x12fc904: r0 = scale()
    //     0x12fc904: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fc908: mov             x2, x0
    // 0x12fc90c: ldur            x0, [fp, #-8]
    // 0x12fc910: stur            x2, [fp, #-0x18]
    // 0x12fc914: LoadField: r3 = r0->field_f
    //     0x12fc914: ldur            w3, [x0, #0xf]
    // 0x12fc918: DecompressPointer r3
    //     0x12fc918: add             x3, x3, HEAP, lsl #32
    // 0x12fc91c: stur            x3, [fp, #-0x10]
    // 0x12fc920: r1 = LoadClassIdInstr(r3)
    //     0x12fc920: ldur            x1, [x3, #-1]
    //     0x12fc924: ubfx            x1, x1, #0xc, #0x14
    // 0x12fc928: cmp             x1, #0xb88
    // 0x12fc92c: b.ne            #0x12fc9c8
    // 0x12fc930: LoadField: r1 = r3->field_7
    //     0x12fc930: ldur            w1, [x3, #7]
    // 0x12fc934: DecompressPointer r1
    //     0x12fc934: add             x1, x1, HEAP, lsl #32
    // 0x12fc938: ldur            d0, [fp, #-0x40]
    // 0x12fc93c: r0 = *()
    //     0x12fc93c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc940: mov             x2, x0
    // 0x12fc944: ldur            x0, [fp, #-0x10]
    // 0x12fc948: stur            x2, [fp, #-0x20]
    // 0x12fc94c: LoadField: r1 = r0->field_b
    //     0x12fc94c: ldur            w1, [x0, #0xb]
    // 0x12fc950: DecompressPointer r1
    //     0x12fc950: add             x1, x1, HEAP, lsl #32
    // 0x12fc954: ldur            d0, [fp, #-0x40]
    // 0x12fc958: r0 = *()
    //     0x12fc958: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc95c: mov             x2, x0
    // 0x12fc960: ldur            x0, [fp, #-0x10]
    // 0x12fc964: stur            x2, [fp, #-0x28]
    // 0x12fc968: LoadField: r1 = r0->field_f
    //     0x12fc968: ldur            w1, [x0, #0xf]
    // 0x12fc96c: DecompressPointer r1
    //     0x12fc96c: add             x1, x1, HEAP, lsl #32
    // 0x12fc970: ldur            d0, [fp, #-0x40]
    // 0x12fc974: r0 = *()
    //     0x12fc974: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc978: mov             x2, x0
    // 0x12fc97c: ldur            x0, [fp, #-0x10]
    // 0x12fc980: stur            x2, [fp, #-0x30]
    // 0x12fc984: LoadField: r1 = r0->field_13
    //     0x12fc984: ldur            w1, [x0, #0x13]
    // 0x12fc988: DecompressPointer r1
    //     0x12fc988: add             x1, x1, HEAP, lsl #32
    // 0x12fc98c: ldur            d0, [fp, #-0x40]
    // 0x12fc990: r0 = *()
    //     0x12fc990: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc994: stur            x0, [fp, #-0x38]
    // 0x12fc998: r0 = BorderRadiusDirectional()
    //     0x12fc998: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0x12fc99c: mov             x1, x0
    // 0x12fc9a0: ldur            x0, [fp, #-0x20]
    // 0x12fc9a4: StoreField: r1->field_7 = r0
    //     0x12fc9a4: stur            w0, [x1, #7]
    // 0x12fc9a8: ldur            x0, [fp, #-0x28]
    // 0x12fc9ac: StoreField: r1->field_b = r0
    //     0x12fc9ac: stur            w0, [x1, #0xb]
    // 0x12fc9b0: ldur            x0, [fp, #-0x30]
    // 0x12fc9b4: StoreField: r1->field_f = r0
    //     0x12fc9b4: stur            w0, [x1, #0xf]
    // 0x12fc9b8: ldur            x0, [fp, #-0x38]
    // 0x12fc9bc: StoreField: r1->field_13 = r0
    //     0x12fc9bc: stur            w0, [x1, #0x13]
    // 0x12fc9c0: mov             x2, x1
    // 0x12fc9c4: b               #0x12fca8c
    // 0x12fc9c8: mov             x0, x3
    // 0x12fc9cc: cmp             x1, #0xb89
    // 0x12fc9d0: b.ne            #0x12fca6c
    // 0x12fc9d4: LoadField: r1 = r0->field_7
    //     0x12fc9d4: ldur            w1, [x0, #7]
    // 0x12fc9d8: DecompressPointer r1
    //     0x12fc9d8: add             x1, x1, HEAP, lsl #32
    // 0x12fc9dc: ldur            d0, [fp, #-0x40]
    // 0x12fc9e0: r0 = *()
    //     0x12fc9e0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc9e4: mov             x2, x0
    // 0x12fc9e8: ldur            x0, [fp, #-0x10]
    // 0x12fc9ec: stur            x2, [fp, #-0x20]
    // 0x12fc9f0: LoadField: r1 = r0->field_b
    //     0x12fc9f0: ldur            w1, [x0, #0xb]
    // 0x12fc9f4: DecompressPointer r1
    //     0x12fc9f4: add             x1, x1, HEAP, lsl #32
    // 0x12fc9f8: ldur            d0, [fp, #-0x40]
    // 0x12fc9fc: r0 = *()
    //     0x12fc9fc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fca00: mov             x2, x0
    // 0x12fca04: ldur            x0, [fp, #-0x10]
    // 0x12fca08: stur            x2, [fp, #-0x28]
    // 0x12fca0c: LoadField: r1 = r0->field_f
    //     0x12fca0c: ldur            w1, [x0, #0xf]
    // 0x12fca10: DecompressPointer r1
    //     0x12fca10: add             x1, x1, HEAP, lsl #32
    // 0x12fca14: ldur            d0, [fp, #-0x40]
    // 0x12fca18: r0 = *()
    //     0x12fca18: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fca1c: ldur            x1, [fp, #-0x10]
    // 0x12fca20: stur            x0, [fp, #-0x30]
    // 0x12fca24: LoadField: r2 = r1->field_13
    //     0x12fca24: ldur            w2, [x1, #0x13]
    // 0x12fca28: DecompressPointer r2
    //     0x12fca28: add             x2, x2, HEAP, lsl #32
    // 0x12fca2c: mov             x1, x2
    // 0x12fca30: ldur            d0, [fp, #-0x40]
    // 0x12fca34: r0 = *()
    //     0x12fca34: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fca38: stur            x0, [fp, #-0x38]
    // 0x12fca3c: r0 = BorderRadius()
    //     0x12fca3c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12fca40: mov             x1, x0
    // 0x12fca44: ldur            x0, [fp, #-0x20]
    // 0x12fca48: StoreField: r1->field_7 = r0
    //     0x12fca48: stur            w0, [x1, #7]
    // 0x12fca4c: ldur            x0, [fp, #-0x28]
    // 0x12fca50: StoreField: r1->field_b = r0
    //     0x12fca50: stur            w0, [x1, #0xb]
    // 0x12fca54: ldur            x0, [fp, #-0x30]
    // 0x12fca58: StoreField: r1->field_f = r0
    //     0x12fca58: stur            w0, [x1, #0xf]
    // 0x12fca5c: ldur            x0, [fp, #-0x38]
    // 0x12fca60: StoreField: r1->field_13 = r0
    //     0x12fca60: stur            w0, [x1, #0x13]
    // 0x12fca64: mov             x2, x1
    // 0x12fca68: b               #0x12fca8c
    // 0x12fca6c: mov             x1, x0
    // 0x12fca70: r0 = LoadClassIdInstr(r1)
    //     0x12fca70: ldur            x0, [x1, #-1]
    //     0x12fca74: ubfx            x0, x0, #0xc, #0x14
    // 0x12fca78: ldur            d0, [fp, #-0x40]
    // 0x12fca7c: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x12fca7c: sub             lr, x0, #0xfb8
    //     0x12fca80: ldr             lr, [x21, lr, lsl #3]
    //     0x12fca84: blr             lr
    // 0x12fca88: mov             x2, x0
    // 0x12fca8c: ldur            x0, [fp, #-8]
    // 0x12fca90: stur            x2, [fp, #-0x10]
    // 0x12fca94: LoadField: d0 = r0->field_1b
    //     0x12fca94: ldur            d0, [x0, #0x1b]
    // 0x12fca98: stur            d0, [fp, #-0x48]
    // 0x12fca9c: r1 = LoadClassIdInstr(r0)
    //     0x12fca9c: ldur            x1, [x0, #-1]
    //     0x12fcaa0: ubfx            x1, x1, #0xc, #0x14
    // 0x12fcaa4: cmp             x1, #0xbd0
    // 0x12fcaa8: b.ne            #0x12fcaec
    // 0x12fcaac: ldur            d1, [fp, #-0x40]
    // 0x12fcab0: ldur            x0, [fp, #-0x18]
    // 0x12fcab4: r1 = <RoundedSuperellipseBorder>
    //     0x12fcab4: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x12fcab8: ldr             x1, [x1, #0xda8]
    // 0x12fcabc: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x12fcabc: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x12fcac0: mov             x1, x0
    // 0x12fcac4: ldur            x0, [fp, #-0x10]
    // 0x12fcac8: StoreField: r1->field_f = r0
    //     0x12fcac8: stur            w0, [x1, #0xf]
    // 0x12fcacc: ldur            d0, [fp, #-0x40]
    // 0x12fcad0: StoreField: r1->field_13 = d0
    //     0x12fcad0: stur            d0, [x1, #0x13]
    // 0x12fcad4: ldur            d1, [fp, #-0x48]
    // 0x12fcad8: StoreField: r1->field_1b = d1
    //     0x12fcad8: stur            d1, [x1, #0x1b]
    // 0x12fcadc: ldur            x2, [fp, #-0x18]
    // 0x12fcae0: StoreField: r1->field_7 = r2
    //     0x12fcae0: stur            w2, [x1, #7]
    // 0x12fcae4: mov             x0, x1
    // 0x12fcae8: b               #0x12fcb28
    // 0x12fcaec: mov             v1.16b, v0.16b
    // 0x12fcaf0: ldur            d0, [fp, #-0x40]
    // 0x12fcaf4: mov             x0, x2
    // 0x12fcaf8: ldur            x2, [fp, #-0x18]
    // 0x12fcafc: r1 = <RoundedRectangleBorder>
    //     0x12fcafc: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x12fcb00: ldr             x1, [x1, #0xd90]
    // 0x12fcb04: r0 = _RoundedRectangleToCircleBorder()
    //     0x12fcb04: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x12fcb08: ldur            x1, [fp, #-0x10]
    // 0x12fcb0c: StoreField: r0->field_f = r1
    //     0x12fcb0c: stur            w1, [x0, #0xf]
    // 0x12fcb10: ldur            d0, [fp, #-0x40]
    // 0x12fcb14: StoreField: r0->field_13 = d0
    //     0x12fcb14: stur            d0, [x0, #0x13]
    // 0x12fcb18: ldur            d0, [fp, #-0x48]
    // 0x12fcb1c: StoreField: r0->field_1b = d0
    //     0x12fcb1c: stur            d0, [x0, #0x1b]
    // 0x12fcb20: ldur            x1, [fp, #-0x18]
    // 0x12fcb24: StoreField: r0->field_7 = r1
    //     0x12fcb24: stur            w1, [x0, #7]
    // 0x12fcb28: LeaveFrame
    //     0x12fcb28: mov             SP, fp
    //     0x12fcb2c: ldp             fp, lr, [SP], #0x10
    // 0x12fcb30: ret
    //     0x12fcb30: ret             
    // 0x12fcb34: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fcb34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fcb38: b               #0x12fc8f8
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x130025c, size: 0x2a8
    // 0x130025c: EnterFrame
    //     0x130025c: stp             fp, lr, [SP, #-0x10]!
    //     0x1300260: mov             fp, SP
    // 0x1300264: AllocStack(0x38)
    //     0x1300264: sub             SP, SP, #0x38
    // 0x1300268: SetupParameters(_ShapeToCircleBorder<X0 bound _RRectLikeBorder> this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, {dynamic textDirection = Null /* r4, fp-0x8 */})
    //     0x1300268: mov             x3, x1
    //     0x130026c: mov             x0, x2
    //     0x1300270: stur            x1, [fp, #-0x10]
    //     0x1300274: stur            x2, [fp, #-0x18]
    //     0x1300278: ldur            w1, [x4, #0x13]
    //     0x130027c: ldur            w2, [x4, #0x1f]
    //     0x1300280: add             x2, x2, HEAP, lsl #32
    //     0x1300284: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x1300288: ldr             x16, [x16, #0x210]
    //     0x130028c: cmp             w2, w16
    //     0x1300290: b.ne            #0x13002b0
    //     0x1300294: ldur            w2, [x4, #0x23]
    //     0x1300298: add             x2, x2, HEAP, lsl #32
    //     0x130029c: sub             w4, w1, w2
    //     0x13002a0: add             x1, fp, w4, sxtw #2
    //     0x13002a4: ldr             x1, [x1, #8]
    //     0x13002a8: mov             x4, x1
    //     0x13002ac: b               #0x13002b4
    //     0x13002b0: mov             x4, NULL
    //     0x13002b4: stur            x4, [fp, #-8]
    // 0x13002b8: CheckStackOverflow
    //     0x13002b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13002bc: cmp             SP, x16
    //     0x13002c0: b.ls            #0x13004f0
    // 0x13002c4: mov             x1, x3
    // 0x13002c8: mov             x2, x0
    // 0x13002cc: r0 = _adjustRect()
    //     0x13002cc: bl              #0xbfec34  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustRect
    // 0x13002d0: ldur            x1, [fp, #-0x10]
    // 0x13002d4: ldur            x2, [fp, #-0x18]
    // 0x13002d8: ldur            x3, [fp, #-8]
    // 0x13002dc: stur            x0, [fp, #-8]
    // 0x13002e0: r0 = _adjustBorderRadius()
    //     0x13002e0: bl              #0xbfe718  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _ShapeToCircleBorder::_adjustBorderRadius
    // 0x13002e4: mov             x1, x0
    // 0x13002e8: ldur            x0, [fp, #-0x10]
    // 0x13002ec: r2 = LoadClassIdInstr(r0)
    //     0x13002ec: ldur            x2, [x0, #-1]
    //     0x13002f0: ubfx            x2, x2, #0xc, #0x14
    // 0x13002f4: cmp             x2, #0xbd0
    // 0x13002f8: b.ne            #0x13003b4
    // 0x13002fc: ldur            x2, [fp, #-8]
    // 0x1300300: r0 = toRSuperellipse()
    //     0x1300300: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x1300304: stur            x0, [fp, #-0x10]
    // 0x1300308: r0 = _NativePath()
    //     0x1300308: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x130030c: mov             x1, x0
    // 0x1300310: stur            x0, [fp, #-0x18]
    // 0x1300314: r0 = __constructor$Method$FfiNative()
    //     0x1300314: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1300318: ldur            x1, [fp, #-0x10]
    // 0x130031c: r0 = _native()
    //     0x130031c: bl              #0xaf867c  ; [dart:ui] RSuperellipse::_native
    // 0x1300320: mov             x2, x0
    // 0x1300324: ldur            x0, [fp, #-0x18]
    // 0x1300328: stur            x2, [fp, #-0x10]
    // 0x130032c: LoadField: r1 = r0->field_7
    //     0x130032c: ldur            w1, [x0, #7]
    // 0x1300330: DecompressPointer r1
    //     0x1300330: add             x1, x1, HEAP, lsl #32
    // 0x1300334: cmp             w1, NULL
    // 0x1300338: b.eq            #0x13004f8
    // 0x130033c: LoadField: r3 = r1->field_7
    //     0x130033c: ldur            x3, [x1, #7]
    // 0x1300340: ldr             x1, [x3]
    // 0x1300344: cbz             x1, #0x13004d0
    // 0x1300348: mov             x3, x1
    // 0x130034c: stur            x3, [fp, #-0x20]
    // 0x1300350: r1 = <Never>
    //     0x1300350: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300354: r0 = Pointer()
    //     0x1300354: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300358: mov             x2, x0
    // 0x130035c: ldur            x0, [fp, #-0x20]
    // 0x1300360: stur            x2, [fp, #-0x28]
    // 0x1300364: StoreField: r2->field_7 = r0
    //     0x1300364: stur            x0, [x2, #7]
    // 0x1300368: ldur            x0, [fp, #-0x10]
    // 0x130036c: LoadField: r1 = r0->field_7
    //     0x130036c: ldur            w1, [x0, #7]
    // 0x1300370: DecompressPointer r1
    //     0x1300370: add             x1, x1, HEAP, lsl #32
    // 0x1300374: cmp             w1, NULL
    // 0x1300378: b.eq            #0x13004fc
    // 0x130037c: LoadField: r3 = r1->field_7
    //     0x130037c: ldur            x3, [x1, #7]
    // 0x1300380: ldr             x1, [x3]
    // 0x1300384: mov             x3, x1
    // 0x1300388: stur            x3, [fp, #-0x20]
    // 0x130038c: r1 = <Never>
    //     0x130038c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300390: r0 = Pointer()
    //     0x1300390: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300394: mov             x1, x0
    // 0x1300398: ldur            x0, [fp, #-0x20]
    // 0x130039c: StoreField: r1->field_7 = r0
    //     0x130039c: stur            x0, [x1, #7]
    // 0x13003a0: mov             x2, x1
    // 0x13003a4: ldur            x1, [fp, #-0x28]
    // 0x13003a8: r0 = __addRSuperellipse$Method$FfiNative()
    //     0x13003a8: bl              #0xbfdeb4  ; [dart:ui] _NativePath::__addRSuperellipse$Method$FfiNative
    // 0x13003ac: ldur            x0, [fp, #-0x18]
    // 0x13003b0: b               #0x13004c4
    // 0x13003b4: ldur            x2, [fp, #-8]
    // 0x13003b8: r0 = toRRect()
    //     0x13003b8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x13003bc: stur            x0, [fp, #-8]
    // 0x13003c0: r0 = _NativePath()
    //     0x13003c0: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x13003c4: mov             x1, x0
    // 0x13003c8: stur            x0, [fp, #-0x10]
    // 0x13003cc: r0 = __constructor$Method$FfiNative()
    //     0x13003cc: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x13003d0: ldur            x0, [fp, #-8]
    // 0x13003d4: LoadField: d0 = r0->field_b
    //     0x13003d4: ldur            d0, [x0, #0xb]
    // 0x13003d8: fcvt            s1, d0
    // 0x13003dc: stur            d1, [fp, #-0x30]
    // 0x13003e0: r4 = 24
    //     0x13003e0: mov             x4, #0x18
    // 0x13003e4: r0 = AllocateFloat32Array()
    //     0x13003e4: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x13003e8: ldur            d0, [fp, #-0x30]
    // 0x13003ec: stur            x0, [fp, #-0x18]
    // 0x13003f0: ArrayStore: r0[0] = d0  ; List_8
    //     0x13003f0: stur            s0, [x0, #0x17]
    // 0x13003f4: ldur            x1, [fp, #-8]
    // 0x13003f8: LoadField: d0 = r1->field_13
    //     0x13003f8: ldur            d0, [x1, #0x13]
    // 0x13003fc: fcvt            s1, d0
    // 0x1300400: StoreField: r0->field_1b = d1
    //     0x1300400: stur            s1, [x0, #0x1b]
    // 0x1300404: LoadField: d0 = r1->field_1b
    //     0x1300404: ldur            d0, [x1, #0x1b]
    // 0x1300408: fcvt            s1, d0
    // 0x130040c: StoreField: r0->field_1f = d1
    //     0x130040c: stur            s1, [x0, #0x1f]
    // 0x1300410: LoadField: d0 = r1->field_23
    //     0x1300410: ldur            d0, [x1, #0x23]
    // 0x1300414: fcvt            s1, d0
    // 0x1300418: StoreField: r0->field_23 = d1
    //     0x1300418: stur            s1, [x0, #0x23]
    // 0x130041c: LoadField: d0 = r1->field_2b
    //     0x130041c: ldur            d0, [x1, #0x2b]
    // 0x1300420: fcvt            s1, d0
    // 0x1300424: StoreField: r0->field_27 = d1
    //     0x1300424: stur            s1, [x0, #0x27]
    // 0x1300428: LoadField: d0 = r1->field_33
    //     0x1300428: ldur            d0, [x1, #0x33]
    // 0x130042c: fcvt            s1, d0
    // 0x1300430: StoreField: r0->field_2b = d1
    //     0x1300430: stur            s1, [x0, #0x2b]
    // 0x1300434: LoadField: d0 = r1->field_3b
    //     0x1300434: ldur            d0, [x1, #0x3b]
    // 0x1300438: fcvt            s1, d0
    // 0x130043c: StoreField: r0->field_2f = d1
    //     0x130043c: stur            s1, [x0, #0x2f]
    // 0x1300440: LoadField: d0 = r1->field_43
    //     0x1300440: ldur            d0, [x1, #0x43]
    // 0x1300444: fcvt            s1, d0
    // 0x1300448: StoreField: r0->field_33 = d1
    //     0x1300448: stur            s1, [x0, #0x33]
    // 0x130044c: LoadField: d0 = r1->field_4b
    //     0x130044c: ldur            d0, [x1, #0x4b]
    // 0x1300450: fcvt            s1, d0
    // 0x1300454: StoreField: r0->field_37 = d1
    //     0x1300454: stur            s1, [x0, #0x37]
    // 0x1300458: LoadField: d0 = r1->field_53
    //     0x1300458: ldur            d0, [x1, #0x53]
    // 0x130045c: fcvt            s1, d0
    // 0x1300460: StoreField: r0->field_3b = d1
    //     0x1300460: stur            s1, [x0, #0x3b]
    // 0x1300464: LoadField: d0 = r1->field_5b
    //     0x1300464: ldur            d0, [x1, #0x5b]
    // 0x1300468: fcvt            s1, d0
    // 0x130046c: StoreField: r0->field_3f = d1
    //     0x130046c: stur            s1, [x0, #0x3f]
    // 0x1300470: LoadField: d0 = r1->field_63
    //     0x1300470: ldur            d0, [x1, #0x63]
    // 0x1300474: fcvt            s1, d0
    // 0x1300478: StoreField: r0->field_43 = d1
    //     0x1300478: stur            s1, [x0, #0x43]
    // 0x130047c: ldur            x2, [fp, #-0x10]
    // 0x1300480: LoadField: r1 = r2->field_7
    //     0x1300480: ldur            w1, [x2, #7]
    // 0x1300484: DecompressPointer r1
    //     0x1300484: add             x1, x1, HEAP, lsl #32
    // 0x1300488: cmp             w1, NULL
    // 0x130048c: b.eq            #0x1300500
    // 0x1300490: LoadField: r3 = r1->field_7
    //     0x1300490: ldur            x3, [x1, #7]
    // 0x1300494: ldr             x1, [x3]
    // 0x1300498: cbz             x1, #0x13004e0
    // 0x130049c: mov             x3, x1
    // 0x13004a0: stur            x3, [fp, #-0x20]
    // 0x13004a4: r1 = <Never>
    //     0x13004a4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x13004a8: r0 = Pointer()
    //     0x13004a8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x13004ac: mov             x1, x0
    // 0x13004b0: ldur            x0, [fp, #-0x20]
    // 0x13004b4: StoreField: r1->field_7 = r0
    //     0x13004b4: stur            x0, [x1, #7]
    // 0x13004b8: ldur            x2, [fp, #-0x18]
    // 0x13004bc: r0 = __addRRect$Method$FfiNative()
    //     0x13004bc: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x13004c0: ldur            x0, [fp, #-0x10]
    // 0x13004c4: LeaveFrame
    //     0x13004c4: mov             SP, fp
    //     0x13004c8: ldp             fp, lr, [SP], #0x10
    // 0x13004cc: ret
    //     0x13004cc: ret             
    // 0x13004d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x13004d0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x13004d4: str             x16, [SP]
    // 0x13004d8: r0 = _throwNew()
    //     0x13004d8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x13004dc: brk             #0
    // 0x13004e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x13004e0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x13004e4: str             x16, [SP]
    // 0x13004e8: r0 = _throwNew()
    //     0x13004e8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x13004ec: brk             #0
    // 0x13004f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13004f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13004f4: b               #0x13002c4
    // 0x13004f8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x13004f8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x13004fc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x13004fc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1300500: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300500: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3024, size: 0x24, field offset: 0x24
//   const constructor, 
class _RoundedSuperellipseToCircleBorder extends _ShapeToCircleBorder<dynamic> {

  _ copyWith(/* No info */) {
    // ** addr: 0x13018fc, size: 0x190
    // 0x13018fc: EnterFrame
    //     0x13018fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1301900: mov             fp, SP
    // 0x1301904: AllocStack(0x20)
    //     0x1301904: sub             SP, SP, #0x20
    // 0x1301908: SetupParameters({dynamic borderRadius = Null /* r5 */, dynamic circularity = Null /* r6 */, dynamic eccentricity = Null /* r0 */})
    //     0x1301908: ldur            w0, [x4, #0x13]
    //     0x130190c: ldur            w3, [x4, #0x1f]
    //     0x1301910: add             x3, x3, HEAP, lsl #32
    //     0x1301914: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d00] "borderRadius"
    //     0x1301918: ldr             x16, [x16, #0xd00]
    //     0x130191c: cmp             w3, w16
    //     0x1301920: b.ne            #0x1301944
    //     0x1301924: ldur            w3, [x4, #0x23]
    //     0x1301928: add             x3, x3, HEAP, lsl #32
    //     0x130192c: sub             w5, w0, w3
    //     0x1301930: add             x3, fp, w5, sxtw #2
    //     0x1301934: ldr             x3, [x3, #8]
    //     0x1301938: mov             x5, x3
    //     0x130193c: mov             x3, #1
    //     0x1301940: b               #0x130194c
    //     0x1301944: mov             x5, NULL
    //     0x1301948: mov             x3, #0
    //     0x130194c: lsl             x6, x3, #1
    //     0x1301950: lsl             w7, w6, #1
    //     0x1301954: add             w8, w7, #8
    //     0x1301958: add             x16, x4, w8, sxtw #1
    //     0x130195c: ldur            w9, [x16, #0xf]
    //     0x1301960: add             x9, x9, HEAP, lsl #32
    //     0x1301964: add             x16, PP, #0xaa, lsl #12  ; [pp+0xaafd8] "circularity"
    //     0x1301968: ldr             x16, [x16, #0xfd8]
    //     0x130196c: cmp             w9, w16
    //     0x1301970: b.ne            #0x13019a4
    //     0x1301974: add             w3, w7, #0xa
    //     0x1301978: add             x16, x4, w3, sxtw #1
    //     0x130197c: ldur            w7, [x16, #0xf]
    //     0x1301980: add             x7, x7, HEAP, lsl #32
    //     0x1301984: sub             w3, w0, w7
    //     0x1301988: add             x7, fp, w3, sxtw #2
    //     0x130198c: ldr             x7, [x7, #8]
    //     0x1301990: add             w3, w6, #2
    //     0x1301994: sbfx            x6, x3, #1, #0x1f
    //     0x1301998: mov             x3, x6
    //     0x130199c: mov             x6, x7
    //     0x13019a0: b               #0x13019a8
    //     0x13019a4: mov             x6, NULL
    //     0x13019a8: lsl             x7, x3, #1
    //     0x13019ac: lsl             w3, w7, #1
    //     0x13019b0: add             w7, w3, #8
    //     0x13019b4: add             x16, x4, w7, sxtw #1
    //     0x13019b8: ldur            w8, [x16, #0xf]
    //     0x13019bc: add             x8, x8, HEAP, lsl #32
    //     0x13019c0: add             x16, PP, #0xac, lsl #12  ; [pp+0xace58] "eccentricity"
    //     0x13019c4: ldr             x16, [x16, #0xe58]
    //     0x13019c8: cmp             w8, w16
    //     0x13019cc: b.ne            #0x13019f0
    //     0x13019d0: add             w7, w3, #0xa
    //     0x13019d4: add             x16, x4, w7, sxtw #1
    //     0x13019d8: ldur            w3, [x16, #0xf]
    //     0x13019dc: add             x3, x3, HEAP, lsl #32
    //     0x13019e0: sub             w4, w0, w3
    //     0x13019e4: add             x0, fp, w4, sxtw #2
    //     0x13019e8: ldr             x0, [x0, #8]
    //     0x13019ec: b               #0x13019f4
    //     0x13019f0: mov             x0, NULL
    // 0x13019f4: cmp             w2, NULL
    // 0x13019f8: b.ne            #0x1301a04
    // 0x13019fc: LoadField: r2 = r1->field_7
    //     0x13019fc: ldur            w2, [x1, #7]
    // 0x1301a00: DecompressPointer r2
    //     0x1301a00: add             x2, x2, HEAP, lsl #32
    // 0x1301a04: stur            x2, [fp, #-0x10]
    // 0x1301a08: cmp             w5, NULL
    // 0x1301a0c: b.ne            #0x1301a1c
    // 0x1301a10: LoadField: r3 = r1->field_f
    //     0x1301a10: ldur            w3, [x1, #0xf]
    // 0x1301a14: DecompressPointer r3
    //     0x1301a14: add             x3, x3, HEAP, lsl #32
    // 0x1301a18: b               #0x1301a20
    // 0x1301a1c: mov             x3, x5
    // 0x1301a20: stur            x3, [fp, #-8]
    // 0x1301a24: cmp             w6, NULL
    // 0x1301a28: b.ne            #0x1301a34
    // 0x1301a2c: LoadField: d0 = r1->field_13
    //     0x1301a2c: ldur            d0, [x1, #0x13]
    // 0x1301a30: b               #0x1301a38
    // 0x1301a34: LoadField: d0 = r6->field_7
    //     0x1301a34: ldur            d0, [x6, #7]
    // 0x1301a38: stur            d0, [fp, #-0x20]
    // 0x1301a3c: cmp             w0, NULL
    // 0x1301a40: b.ne            #0x1301a4c
    // 0x1301a44: LoadField: d1 = r1->field_1b
    //     0x1301a44: ldur            d1, [x1, #0x1b]
    // 0x1301a48: b               #0x1301a50
    // 0x1301a4c: LoadField: d1 = r0->field_7
    //     0x1301a4c: ldur            d1, [x0, #7]
    // 0x1301a50: stur            d1, [fp, #-0x18]
    // 0x1301a54: r1 = <RoundedSuperellipseBorder>
    //     0x1301a54: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x1301a58: ldr             x1, [x1, #0xda8]
    // 0x1301a5c: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x1301a5c: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x1301a60: ldur            x1, [fp, #-8]
    // 0x1301a64: StoreField: r0->field_f = r1
    //     0x1301a64: stur            w1, [x0, #0xf]
    // 0x1301a68: ldur            d0, [fp, #-0x20]
    // 0x1301a6c: StoreField: r0->field_13 = d0
    //     0x1301a6c: stur            d0, [x0, #0x13]
    // 0x1301a70: ldur            d0, [fp, #-0x18]
    // 0x1301a74: StoreField: r0->field_1b = d0
    //     0x1301a74: stur            d0, [x0, #0x1b]
    // 0x1301a78: ldur            x1, [fp, #-0x10]
    // 0x1301a7c: StoreField: r0->field_7 = r1
    //     0x1301a7c: stur            w1, [x0, #7]
    // 0x1301a80: LeaveFrame
    //     0x1301a80: mov             SP, fp
    //     0x1301a84: ldp             fp, lr, [SP], #0x10
    // 0x1301a88: ret
    //     0x1301a88: ret             
  }
}

// class id: 3025, size: 0x24, field offset: 0x24
//   const constructor, 
class _RoundedRectangleToCircleBorder extends _ShapeToCircleBorder<dynamic> {

  _ copyWith(/* No info */) {
    // ** addr: 0x130176c, size: 0x190
    // 0x130176c: EnterFrame
    //     0x130176c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301770: mov             fp, SP
    // 0x1301774: AllocStack(0x20)
    //     0x1301774: sub             SP, SP, #0x20
    // 0x1301778: SetupParameters({dynamic borderRadius = Null /* r5 */, dynamic circularity = Null /* r6 */, dynamic eccentricity = Null /* r0 */})
    //     0x1301778: ldur            w0, [x4, #0x13]
    //     0x130177c: ldur            w3, [x4, #0x1f]
    //     0x1301780: add             x3, x3, HEAP, lsl #32
    //     0x1301784: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d00] "borderRadius"
    //     0x1301788: ldr             x16, [x16, #0xd00]
    //     0x130178c: cmp             w3, w16
    //     0x1301790: b.ne            #0x13017b4
    //     0x1301794: ldur            w3, [x4, #0x23]
    //     0x1301798: add             x3, x3, HEAP, lsl #32
    //     0x130179c: sub             w5, w0, w3
    //     0x13017a0: add             x3, fp, w5, sxtw #2
    //     0x13017a4: ldr             x3, [x3, #8]
    //     0x13017a8: mov             x5, x3
    //     0x13017ac: mov             x3, #1
    //     0x13017b0: b               #0x13017bc
    //     0x13017b4: mov             x5, NULL
    //     0x13017b8: mov             x3, #0
    //     0x13017bc: lsl             x6, x3, #1
    //     0x13017c0: lsl             w7, w6, #1
    //     0x13017c4: add             w8, w7, #8
    //     0x13017c8: add             x16, x4, w8, sxtw #1
    //     0x13017cc: ldur            w9, [x16, #0xf]
    //     0x13017d0: add             x9, x9, HEAP, lsl #32
    //     0x13017d4: add             x16, PP, #0xaa, lsl #12  ; [pp+0xaafd8] "circularity"
    //     0x13017d8: ldr             x16, [x16, #0xfd8]
    //     0x13017dc: cmp             w9, w16
    //     0x13017e0: b.ne            #0x1301814
    //     0x13017e4: add             w3, w7, #0xa
    //     0x13017e8: add             x16, x4, w3, sxtw #1
    //     0x13017ec: ldur            w7, [x16, #0xf]
    //     0x13017f0: add             x7, x7, HEAP, lsl #32
    //     0x13017f4: sub             w3, w0, w7
    //     0x13017f8: add             x7, fp, w3, sxtw #2
    //     0x13017fc: ldr             x7, [x7, #8]
    //     0x1301800: add             w3, w6, #2
    //     0x1301804: sbfx            x6, x3, #1, #0x1f
    //     0x1301808: mov             x3, x6
    //     0x130180c: mov             x6, x7
    //     0x1301810: b               #0x1301818
    //     0x1301814: mov             x6, NULL
    //     0x1301818: lsl             x7, x3, #1
    //     0x130181c: lsl             w3, w7, #1
    //     0x1301820: add             w7, w3, #8
    //     0x1301824: add             x16, x4, w7, sxtw #1
    //     0x1301828: ldur            w8, [x16, #0xf]
    //     0x130182c: add             x8, x8, HEAP, lsl #32
    //     0x1301830: add             x16, PP, #0xac, lsl #12  ; [pp+0xace58] "eccentricity"
    //     0x1301834: ldr             x16, [x16, #0xe58]
    //     0x1301838: cmp             w8, w16
    //     0x130183c: b.ne            #0x1301860
    //     0x1301840: add             w7, w3, #0xa
    //     0x1301844: add             x16, x4, w7, sxtw #1
    //     0x1301848: ldur            w3, [x16, #0xf]
    //     0x130184c: add             x3, x3, HEAP, lsl #32
    //     0x1301850: sub             w4, w0, w3
    //     0x1301854: add             x0, fp, w4, sxtw #2
    //     0x1301858: ldr             x0, [x0, #8]
    //     0x130185c: b               #0x1301864
    //     0x1301860: mov             x0, NULL
    // 0x1301864: cmp             w2, NULL
    // 0x1301868: b.ne            #0x1301874
    // 0x130186c: LoadField: r2 = r1->field_7
    //     0x130186c: ldur            w2, [x1, #7]
    // 0x1301870: DecompressPointer r2
    //     0x1301870: add             x2, x2, HEAP, lsl #32
    // 0x1301874: stur            x2, [fp, #-0x10]
    // 0x1301878: cmp             w5, NULL
    // 0x130187c: b.ne            #0x130188c
    // 0x1301880: LoadField: r3 = r1->field_f
    //     0x1301880: ldur            w3, [x1, #0xf]
    // 0x1301884: DecompressPointer r3
    //     0x1301884: add             x3, x3, HEAP, lsl #32
    // 0x1301888: b               #0x1301890
    // 0x130188c: mov             x3, x5
    // 0x1301890: stur            x3, [fp, #-8]
    // 0x1301894: cmp             w6, NULL
    // 0x1301898: b.ne            #0x13018a4
    // 0x130189c: LoadField: d0 = r1->field_13
    //     0x130189c: ldur            d0, [x1, #0x13]
    // 0x13018a0: b               #0x13018a8
    // 0x13018a4: LoadField: d0 = r6->field_7
    //     0x13018a4: ldur            d0, [x6, #7]
    // 0x13018a8: stur            d0, [fp, #-0x20]
    // 0x13018ac: cmp             w0, NULL
    // 0x13018b0: b.ne            #0x13018bc
    // 0x13018b4: LoadField: d1 = r1->field_1b
    //     0x13018b4: ldur            d1, [x1, #0x1b]
    // 0x13018b8: b               #0x13018c0
    // 0x13018bc: LoadField: d1 = r0->field_7
    //     0x13018bc: ldur            d1, [x0, #7]
    // 0x13018c0: stur            d1, [fp, #-0x18]
    // 0x13018c4: r1 = <RoundedRectangleBorder>
    //     0x13018c4: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x13018c8: ldr             x1, [x1, #0xd90]
    // 0x13018cc: r0 = _RoundedRectangleToCircleBorder()
    //     0x13018cc: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x13018d0: ldur            x1, [fp, #-8]
    // 0x13018d4: StoreField: r0->field_f = r1
    //     0x13018d4: stur            w1, [x0, #0xf]
    // 0x13018d8: ldur            d0, [fp, #-0x20]
    // 0x13018dc: StoreField: r0->field_13 = d0
    //     0x13018dc: stur            d0, [x0, #0x13]
    // 0x13018e0: ldur            d0, [fp, #-0x18]
    // 0x13018e4: StoreField: r0->field_1b = d0
    //     0x13018e4: stur            d0, [x0, #0x1b]
    // 0x13018e8: ldur            x1, [fp, #-0x10]
    // 0x13018ec: StoreField: r0->field_7 = r1
    //     0x13018ec: stur            w1, [x0, #7]
    // 0x13018f0: LeaveFrame
    //     0x13018f0: mov             SP, fp
    //     0x13018f4: ldp             fp, lr, [SP], #0x10
    // 0x13018f8: ret
    //     0x13018f8: ret             
  }
}

// class id: 3028, size: 0x10, field offset: 0xc
//   const constructor, 
class RoundedSuperellipseBorder extends _MixinApplication305&OutlinedBorder&_RRectLikeBorder {

  BorderSide field_8;
  BorderRadius field_c;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfdb18, size: 0x39c
    // 0xbfdb18: EnterFrame
    //     0xbfdb18: stp             fp, lr, [SP, #-0x10]!
    //     0xbfdb1c: mov             fp, SP
    // 0xbfdb20: AllocStack(0x78)
    //     0xbfdb20: sub             SP, SP, #0x78
    // 0xbfdb24: SetupParameters(RoundedSuperellipseBorder this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x20 */, {dynamic textDirection = Null /* r2, fp-0x10 */})
    //     0xbfdb24: mov             x0, x1
    //     0xbfdb28: stur            x1, [fp, #-0x18]
    //     0xbfdb2c: mov             x1, x2
    //     0xbfdb30: stur            x2, [fp, #-0x20]
    //     0xbfdb34: ldur            w2, [x4, #0x13]
    //     0xbfdb38: ldur            w3, [x4, #0x1f]
    //     0xbfdb3c: add             x3, x3, HEAP, lsl #32
    //     0xbfdb40: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xbfdb44: ldr             x16, [x16, #0x210]
    //     0xbfdb48: cmp             w3, w16
    //     0xbfdb4c: b.ne            #0xbfdb68
    //     0xbfdb50: ldur            w3, [x4, #0x23]
    //     0xbfdb54: add             x3, x3, HEAP, lsl #32
    //     0xbfdb58: sub             w4, w2, w3
    //     0xbfdb5c: add             x2, fp, w4, sxtw #2
    //     0xbfdb60: ldr             x2, [x2, #8]
    //     0xbfdb64: b               #0xbfdb6c
    //     0xbfdb68: mov             x2, NULL
    //     0xbfdb6c: stur            x2, [fp, #-0x10]
    // 0xbfdb70: CheckStackOverflow
    //     0xbfdb70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfdb74: cmp             SP, x16
    //     0xbfdb78: b.ls            #0xbfde9c
    // 0xbfdb7c: LoadField: r3 = r0->field_b
    //     0xbfdb7c: ldur            w3, [x0, #0xb]
    // 0xbfdb80: DecompressPointer r3
    //     0xbfdb80: add             x3, x3, HEAP, lsl #32
    // 0xbfdb84: stur            x3, [fp, #-8]
    // 0xbfdb88: r16 = Instance_BorderRadius
    //     0xbfdb88: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xbfdb8c: ldr             x16, [x16, #0x508]
    // 0xbfdb90: stp             x16, x3, [SP]
    // 0xbfdb94: r0 = ==()
    //     0xbfdb94: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xbfdb98: tbnz            w0, #4, #0xbfdc68
    // 0xbfdb9c: ldur            x0, [fp, #-0x18]
    // 0xbfdba0: r0 = _NativePath()
    //     0xbfdba0: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfdba4: mov             x1, x0
    // 0xbfdba8: stur            x0, [fp, #-0x28]
    // 0xbfdbac: r0 = __constructor$Method$FfiNative()
    //     0xbfdbac: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfdbb0: ldur            x0, [fp, #-0x18]
    // 0xbfdbb4: LoadField: r1 = r0->field_7
    //     0xbfdbb4: ldur            w1, [x0, #7]
    // 0xbfdbb8: DecompressPointer r1
    //     0xbfdbb8: add             x1, x1, HEAP, lsl #32
    // 0xbfdbbc: LoadField: d0 = r1->field_b
    //     0xbfdbbc: ldur            d0, [x1, #0xb]
    // 0xbfdbc0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xbfdbc0: ldur            d1, [x1, #0x17]
    // 0xbfdbc4: d2 = 1.000000
    //     0xbfdbc4: fmov            d2, #1.00000000
    // 0xbfdbc8: fadd            d3, d1, d2
    // 0xbfdbcc: d1 = 2.000000
    //     0xbfdbcc: fmov            d1, #2.00000000
    // 0xbfdbd0: fdiv            d4, d3, d1
    // 0xbfdbd4: fsub            d1, d2, d4
    // 0xbfdbd8: fmul            d2, d0, d1
    // 0xbfdbdc: ldur            x1, [fp, #-0x20]
    // 0xbfdbe0: mov             v0.16b, v2.16b
    // 0xbfdbe4: r0 = deflate()
    //     0xbfdbe4: bl              #0x882c84  ; [dart:ui] Rect::deflate
    // 0xbfdbe8: LoadField: d0 = r0->field_7
    //     0xbfdbe8: ldur            d0, [x0, #7]
    // 0xbfdbec: stur            d0, [fp, #-0x68]
    // 0xbfdbf0: LoadField: d1 = r0->field_f
    //     0xbfdbf0: ldur            d1, [x0, #0xf]
    // 0xbfdbf4: stur            d1, [fp, #-0x60]
    // 0xbfdbf8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xbfdbf8: ldur            d2, [x0, #0x17]
    // 0xbfdbfc: stur            d2, [fp, #-0x58]
    // 0xbfdc00: LoadField: d3 = r0->field_1f
    //     0xbfdc00: ldur            d3, [x0, #0x1f]
    // 0xbfdc04: ldur            x0, [fp, #-0x28]
    // 0xbfdc08: stur            d3, [fp, #-0x50]
    // 0xbfdc0c: LoadField: r1 = r0->field_7
    //     0xbfdc0c: ldur            w1, [x0, #7]
    // 0xbfdc10: DecompressPointer r1
    //     0xbfdc10: add             x1, x1, HEAP, lsl #32
    // 0xbfdc14: cmp             w1, NULL
    // 0xbfdc18: b.eq            #0xbfdea4
    // 0xbfdc1c: LoadField: r2 = r1->field_7
    //     0xbfdc1c: ldur            x2, [x1, #7]
    // 0xbfdc20: ldr             x1, [x2]
    // 0xbfdc24: cbz             x1, #0xbfde7c
    // 0xbfdc28: mov             x2, x1
    // 0xbfdc2c: stur            x2, [fp, #-0x30]
    // 0xbfdc30: r1 = <Never>
    //     0xbfdc30: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfdc34: r0 = Pointer()
    //     0xbfdc34: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfdc38: mov             x1, x0
    // 0xbfdc3c: ldur            x0, [fp, #-0x30]
    // 0xbfdc40: StoreField: r1->field_7 = r0
    //     0xbfdc40: stur            x0, [x1, #7]
    // 0xbfdc44: ldur            d0, [fp, #-0x68]
    // 0xbfdc48: ldur            d1, [fp, #-0x60]
    // 0xbfdc4c: ldur            d2, [fp, #-0x58]
    // 0xbfdc50: ldur            d3, [fp, #-0x50]
    // 0xbfdc54: r0 = __addRect$Method$FfiNative()
    //     0xbfdc54: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0xbfdc58: ldur            x0, [fp, #-0x28]
    // 0xbfdc5c: LeaveFrame
    //     0xbfdc5c: mov             SP, fp
    //     0xbfdc60: ldp             fp, lr, [SP], #0x10
    // 0xbfdc64: ret
    //     0xbfdc64: ret             
    // 0xbfdc68: ldur            x0, [fp, #-0x18]
    // 0xbfdc6c: ldur            x1, [fp, #-8]
    // 0xbfdc70: d2 = 1.000000
    //     0xbfdc70: fmov            d2, #1.00000000
    // 0xbfdc74: d1 = 2.000000
    //     0xbfdc74: fmov            d1, #2.00000000
    // 0xbfdc78: r2 = LoadClassIdInstr(r1)
    //     0xbfdc78: ldur            x2, [x1, #-1]
    //     0xbfdc7c: ubfx            x2, x2, #0xc, #0x14
    // 0xbfdc80: cmp             x2, #0xb88
    // 0xbfdc84: b.ne            #0xbfdd58
    // 0xbfdc88: ldur            x3, [fp, #-0x10]
    // 0xbfdc8c: cmp             w3, NULL
    // 0xbfdc90: b.eq            #0xbfdea8
    // 0xbfdc94: LoadField: r2 = r3->field_7
    //     0xbfdc94: ldur            x2, [x3, #7]
    // 0xbfdc98: cmp             x2, #0
    // 0xbfdc9c: b.gt            #0xbfdcfc
    // 0xbfdca0: LoadField: r2 = r1->field_b
    //     0xbfdca0: ldur            w2, [x1, #0xb]
    // 0xbfdca4: DecompressPointer r2
    //     0xbfdca4: add             x2, x2, HEAP, lsl #32
    // 0xbfdca8: stur            x2, [fp, #-0x48]
    // 0xbfdcac: LoadField: r3 = r1->field_7
    //     0xbfdcac: ldur            w3, [x1, #7]
    // 0xbfdcb0: DecompressPointer r3
    //     0xbfdcb0: add             x3, x3, HEAP, lsl #32
    // 0xbfdcb4: stur            x3, [fp, #-0x40]
    // 0xbfdcb8: LoadField: r4 = r1->field_13
    //     0xbfdcb8: ldur            w4, [x1, #0x13]
    // 0xbfdcbc: DecompressPointer r4
    //     0xbfdcbc: add             x4, x4, HEAP, lsl #32
    // 0xbfdcc0: stur            x4, [fp, #-0x38]
    // 0xbfdcc4: LoadField: r5 = r1->field_f
    //     0xbfdcc4: ldur            w5, [x1, #0xf]
    // 0xbfdcc8: DecompressPointer r5
    //     0xbfdcc8: add             x5, x5, HEAP, lsl #32
    // 0xbfdccc: stur            x5, [fp, #-0x28]
    // 0xbfdcd0: r0 = BorderRadius()
    //     0xbfdcd0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfdcd4: mov             x1, x0
    // 0xbfdcd8: ldur            x0, [fp, #-0x48]
    // 0xbfdcdc: StoreField: r1->field_7 = r0
    //     0xbfdcdc: stur            w0, [x1, #7]
    // 0xbfdce0: ldur            x0, [fp, #-0x40]
    // 0xbfdce4: StoreField: r1->field_b = r0
    //     0xbfdce4: stur            w0, [x1, #0xb]
    // 0xbfdce8: ldur            x0, [fp, #-0x38]
    // 0xbfdcec: StoreField: r1->field_f = r0
    //     0xbfdcec: stur            w0, [x1, #0xf]
    // 0xbfdcf0: ldur            x0, [fp, #-0x28]
    // 0xbfdcf4: StoreField: r1->field_13 = r0
    //     0xbfdcf4: stur            w0, [x1, #0x13]
    // 0xbfdcf8: b               #0xbfdd80
    // 0xbfdcfc: LoadField: r0 = r1->field_7
    //     0xbfdcfc: ldur            w0, [x1, #7]
    // 0xbfdd00: DecompressPointer r0
    //     0xbfdd00: add             x0, x0, HEAP, lsl #32
    // 0xbfdd04: stur            x0, [fp, #-0x48]
    // 0xbfdd08: LoadField: r2 = r1->field_b
    //     0xbfdd08: ldur            w2, [x1, #0xb]
    // 0xbfdd0c: DecompressPointer r2
    //     0xbfdd0c: add             x2, x2, HEAP, lsl #32
    // 0xbfdd10: stur            x2, [fp, #-0x40]
    // 0xbfdd14: LoadField: r3 = r1->field_f
    //     0xbfdd14: ldur            w3, [x1, #0xf]
    // 0xbfdd18: DecompressPointer r3
    //     0xbfdd18: add             x3, x3, HEAP, lsl #32
    // 0xbfdd1c: stur            x3, [fp, #-0x38]
    // 0xbfdd20: LoadField: r4 = r1->field_13
    //     0xbfdd20: ldur            w4, [x1, #0x13]
    // 0xbfdd24: DecompressPointer r4
    //     0xbfdd24: add             x4, x4, HEAP, lsl #32
    // 0xbfdd28: stur            x4, [fp, #-0x28]
    // 0xbfdd2c: r0 = BorderRadius()
    //     0xbfdd2c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfdd30: mov             x1, x0
    // 0xbfdd34: ldur            x0, [fp, #-0x48]
    // 0xbfdd38: StoreField: r1->field_7 = r0
    //     0xbfdd38: stur            w0, [x1, #7]
    // 0xbfdd3c: ldur            x0, [fp, #-0x40]
    // 0xbfdd40: StoreField: r1->field_b = r0
    //     0xbfdd40: stur            w0, [x1, #0xb]
    // 0xbfdd44: ldur            x0, [fp, #-0x38]
    // 0xbfdd48: StoreField: r1->field_f = r0
    //     0xbfdd48: stur            w0, [x1, #0xf]
    // 0xbfdd4c: ldur            x0, [fp, #-0x28]
    // 0xbfdd50: StoreField: r1->field_13 = r0
    //     0xbfdd50: stur            w0, [x1, #0x13]
    // 0xbfdd54: b               #0xbfdd80
    // 0xbfdd58: ldur            x3, [fp, #-0x10]
    // 0xbfdd5c: cmp             x2, #0xb89
    // 0xbfdd60: b.eq            #0xbfdd80
    // 0xbfdd64: r0 = LoadClassIdInstr(r1)
    //     0xbfdd64: ldur            x0, [x1, #-1]
    //     0xbfdd68: ubfx            x0, x0, #0xc, #0x14
    // 0xbfdd6c: mov             x2, x3
    // 0xbfdd70: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbfdd70: sub             lr, x0, #1, lsl #12
    //     0xbfdd74: ldr             lr, [x21, lr, lsl #3]
    //     0xbfdd78: blr             lr
    // 0xbfdd7c: mov             x1, x0
    // 0xbfdd80: ldur            x0, [fp, #-0x18]
    // 0xbfdd84: ldur            x2, [fp, #-0x20]
    // 0xbfdd88: r0 = toRSuperellipse()
    //     0xbfdd88: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0xbfdd8c: mov             x1, x0
    // 0xbfdd90: ldur            x0, [fp, #-0x18]
    // 0xbfdd94: LoadField: r2 = r0->field_7
    //     0xbfdd94: ldur            w2, [x0, #7]
    // 0xbfdd98: DecompressPointer r2
    //     0xbfdd98: add             x2, x2, HEAP, lsl #32
    // 0xbfdd9c: LoadField: d0 = r2->field_b
    //     0xbfdd9c: ldur            d0, [x2, #0xb]
    // 0xbfdda0: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbfdda0: ldur            d1, [x2, #0x17]
    // 0xbfdda4: d2 = 1.000000
    //     0xbfdda4: fmov            d2, #1.00000000
    // 0xbfdda8: fadd            d3, d1, d2
    // 0xbfddac: d1 = 2.000000
    //     0xbfddac: fmov            d1, #2.00000000
    // 0xbfddb0: fdiv            d4, d3, d1
    // 0xbfddb4: fsub            d1, d2, d4
    // 0xbfddb8: fmul            d2, d0, d1
    // 0xbfddbc: mov             v0.16b, v2.16b
    // 0xbfddc0: r0 = deflate()
    //     0xbfddc0: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbfddc4: stur            x0, [fp, #-8]
    // 0xbfddc8: r0 = _NativePath()
    //     0xbfddc8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfddcc: mov             x1, x0
    // 0xbfddd0: stur            x0, [fp, #-0x10]
    // 0xbfddd4: r0 = __constructor$Method$FfiNative()
    //     0xbfddd4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfddd8: ldur            x1, [fp, #-8]
    // 0xbfdddc: r0 = _native()
    //     0xbfdddc: bl              #0xaf867c  ; [dart:ui] RSuperellipse::_native
    // 0xbfdde0: mov             x2, x0
    // 0xbfdde4: ldur            x0, [fp, #-0x10]
    // 0xbfdde8: stur            x2, [fp, #-8]
    // 0xbfddec: LoadField: r1 = r0->field_7
    //     0xbfddec: ldur            w1, [x0, #7]
    // 0xbfddf0: DecompressPointer r1
    //     0xbfddf0: add             x1, x1, HEAP, lsl #32
    // 0xbfddf4: cmp             w1, NULL
    // 0xbfddf8: b.eq            #0xbfdeac
    // 0xbfddfc: LoadField: r3 = r1->field_7
    //     0xbfddfc: ldur            x3, [x1, #7]
    // 0xbfde00: ldr             x1, [x3]
    // 0xbfde04: cbz             x1, #0xbfde8c
    // 0xbfde08: mov             x3, x1
    // 0xbfde0c: stur            x3, [fp, #-0x30]
    // 0xbfde10: r1 = <Never>
    //     0xbfde10: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfde14: r0 = Pointer()
    //     0xbfde14: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfde18: mov             x2, x0
    // 0xbfde1c: ldur            x0, [fp, #-0x30]
    // 0xbfde20: stur            x2, [fp, #-0x18]
    // 0xbfde24: StoreField: r2->field_7 = r0
    //     0xbfde24: stur            x0, [x2, #7]
    // 0xbfde28: ldur            x0, [fp, #-8]
    // 0xbfde2c: LoadField: r1 = r0->field_7
    //     0xbfde2c: ldur            w1, [x0, #7]
    // 0xbfde30: DecompressPointer r1
    //     0xbfde30: add             x1, x1, HEAP, lsl #32
    // 0xbfde34: cmp             w1, NULL
    // 0xbfde38: b.eq            #0xbfdeb0
    // 0xbfde3c: LoadField: r3 = r1->field_7
    //     0xbfde3c: ldur            x3, [x1, #7]
    // 0xbfde40: ldr             x1, [x3]
    // 0xbfde44: mov             x3, x1
    // 0xbfde48: stur            x3, [fp, #-0x30]
    // 0xbfde4c: r1 = <Never>
    //     0xbfde4c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfde50: r0 = Pointer()
    //     0xbfde50: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfde54: mov             x1, x0
    // 0xbfde58: ldur            x0, [fp, #-0x30]
    // 0xbfde5c: StoreField: r1->field_7 = r0
    //     0xbfde5c: stur            x0, [x1, #7]
    // 0xbfde60: mov             x2, x1
    // 0xbfde64: ldur            x1, [fp, #-0x18]
    // 0xbfde68: r0 = __addRSuperellipse$Method$FfiNative()
    //     0xbfde68: bl              #0xbfdeb4  ; [dart:ui] _NativePath::__addRSuperellipse$Method$FfiNative
    // 0xbfde6c: ldur            x0, [fp, #-0x10]
    // 0xbfde70: LeaveFrame
    //     0xbfde70: mov             SP, fp
    //     0xbfde74: ldp             fp, lr, [SP], #0x10
    // 0xbfde78: ret
    //     0xbfde78: ret             
    // 0xbfde7c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfde7c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfde80: str             x16, [SP]
    // 0xbfde84: r0 = _throwNew()
    //     0xbfde84: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfde88: brk             #0
    // 0xbfde8c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfde8c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfde90: str             x16, [SP]
    // 0xbfde94: r0 = _throwNew()
    //     0xbfde94: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfde98: brk             #0
    // 0xbfde9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfde9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfdea0: b               #0xbfdb7c
    // 0xbfdea4: r0 = NullErrorSharedWithFPURegs()
    //     0xbfdea4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xbfdea8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbfdea8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbfdeac: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfdeac: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbfdeb0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfdeb0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ed314, size: 0x178
    // 0x10ed314: EnterFrame
    //     0x10ed314: stp             fp, lr, [SP, #-0x10]!
    //     0x10ed318: mov             fp, SP
    // 0x10ed31c: AllocStack(0x38)
    //     0x10ed31c: sub             SP, SP, #0x38
    // 0x10ed320: SetupParameters(RoundedSuperellipseBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10ed320: mov             x3, x1
    //     0x10ed324: mov             x0, x2
    //     0x10ed328: mov             v1.16b, v0.16b
    //     0x10ed32c: stur            x1, [fp, #-8]
    //     0x10ed330: stur            x2, [fp, #-0x10]
    //     0x10ed334: stur            d0, [fp, #-0x28]
    // 0x10ed338: CheckStackOverflow
    //     0x10ed338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ed33c: cmp             SP, x16
    //     0x10ed340: b.ls            #0x10ed484
    // 0x10ed344: r1 = LoadClassIdInstr(r0)
    //     0x10ed344: ldur            x1, [x0, #-1]
    //     0x10ed348: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed34c: cmp             x1, #0xbd4
    // 0x10ed350: b.ne            #0x10ed3c0
    // 0x10ed354: LoadField: r1 = r0->field_7
    //     0x10ed354: ldur            w1, [x0, #7]
    // 0x10ed358: DecompressPointer r1
    //     0x10ed358: add             x1, x1, HEAP, lsl #32
    // 0x10ed35c: LoadField: r2 = r3->field_7
    //     0x10ed35c: ldur            w2, [x3, #7]
    // 0x10ed360: DecompressPointer r2
    //     0x10ed360: add             x2, x2, HEAP, lsl #32
    // 0x10ed364: mov             v0.16b, v1.16b
    // 0x10ed368: r0 = lerp()
    //     0x10ed368: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed36c: mov             x3, x0
    // 0x10ed370: ldur            x0, [fp, #-0x10]
    // 0x10ed374: stur            x3, [fp, #-0x18]
    // 0x10ed378: LoadField: r1 = r0->field_b
    //     0x10ed378: ldur            w1, [x0, #0xb]
    // 0x10ed37c: DecompressPointer r1
    //     0x10ed37c: add             x1, x1, HEAP, lsl #32
    // 0x10ed380: ldur            x4, [fp, #-8]
    // 0x10ed384: LoadField: r2 = r4->field_b
    //     0x10ed384: ldur            w2, [x4, #0xb]
    // 0x10ed388: DecompressPointer r2
    //     0x10ed388: add             x2, x2, HEAP, lsl #32
    // 0x10ed38c: ldur            d0, [fp, #-0x28]
    // 0x10ed390: r0 = lerp()
    //     0x10ed390: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10ed394: stur            x0, [fp, #-0x20]
    // 0x10ed398: r0 = RoundedSuperellipseBorder()
    //     0x10ed398: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0x10ed39c: mov             x1, x0
    // 0x10ed3a0: ldur            x0, [fp, #-0x20]
    // 0x10ed3a4: StoreField: r1->field_b = r0
    //     0x10ed3a4: stur            w0, [x1, #0xb]
    // 0x10ed3a8: ldur            x0, [fp, #-0x18]
    // 0x10ed3ac: StoreField: r1->field_7 = r0
    //     0x10ed3ac: stur            w0, [x1, #7]
    // 0x10ed3b0: mov             x0, x1
    // 0x10ed3b4: LeaveFrame
    //     0x10ed3b4: mov             SP, fp
    //     0x10ed3b8: ldp             fp, lr, [SP], #0x10
    // 0x10ed3bc: ret
    //     0x10ed3bc: ret             
    // 0x10ed3c0: mov             x4, x3
    // 0x10ed3c4: cmp             x1, #0xbd2
    // 0x10ed3c8: b.ne            #0x10ed458
    // 0x10ed3cc: ldur            d1, [fp, #-0x28]
    // 0x10ed3d0: LoadField: r1 = r0->field_7
    //     0x10ed3d0: ldur            w1, [x0, #7]
    // 0x10ed3d4: DecompressPointer r1
    //     0x10ed3d4: add             x1, x1, HEAP, lsl #32
    // 0x10ed3d8: LoadField: r2 = r4->field_7
    //     0x10ed3d8: ldur            w2, [x4, #7]
    // 0x10ed3dc: DecompressPointer r2
    //     0x10ed3dc: add             x2, x2, HEAP, lsl #32
    // 0x10ed3e0: mov             v0.16b, v1.16b
    // 0x10ed3e4: r0 = lerp()
    //     0x10ed3e4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed3e8: ldur            x1, [fp, #-8]
    // 0x10ed3ec: stur            x0, [fp, #-0x20]
    // 0x10ed3f0: LoadField: r2 = r1->field_b
    //     0x10ed3f0: ldur            w2, [x1, #0xb]
    // 0x10ed3f4: DecompressPointer r2
    //     0x10ed3f4: add             x2, x2, HEAP, lsl #32
    // 0x10ed3f8: ldur            d0, [fp, #-0x28]
    // 0x10ed3fc: stur            x2, [fp, #-0x18]
    // 0x10ed400: d1 = 1.000000
    //     0x10ed400: fmov            d1, #1.00000000
    // 0x10ed404: fsub            d2, d1, d0
    // 0x10ed408: ldur            x3, [fp, #-0x10]
    // 0x10ed40c: stur            d2, [fp, #-0x38]
    // 0x10ed410: LoadField: d0 = r3->field_b
    //     0x10ed410: ldur            d0, [x3, #0xb]
    // 0x10ed414: stur            d0, [fp, #-0x30]
    // 0x10ed418: r1 = <RoundedSuperellipseBorder>
    //     0x10ed418: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10ed41c: ldr             x1, [x1, #0xda8]
    // 0x10ed420: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10ed420: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10ed424: mov             x1, x0
    // 0x10ed428: ldur            x0, [fp, #-0x18]
    // 0x10ed42c: StoreField: r1->field_f = r0
    //     0x10ed42c: stur            w0, [x1, #0xf]
    // 0x10ed430: ldur            d0, [fp, #-0x38]
    // 0x10ed434: StoreField: r1->field_13 = d0
    //     0x10ed434: stur            d0, [x1, #0x13]
    // 0x10ed438: ldur            d0, [fp, #-0x30]
    // 0x10ed43c: StoreField: r1->field_1b = d0
    //     0x10ed43c: stur            d0, [x1, #0x1b]
    // 0x10ed440: ldur            x0, [fp, #-0x20]
    // 0x10ed444: StoreField: r1->field_7 = r0
    //     0x10ed444: stur            w0, [x1, #7]
    // 0x10ed448: mov             x0, x1
    // 0x10ed44c: LeaveFrame
    //     0x10ed44c: mov             SP, fp
    //     0x10ed450: ldp             fp, lr, [SP], #0x10
    // 0x10ed454: ret
    //     0x10ed454: ret             
    // 0x10ed458: mov             x1, x4
    // 0x10ed45c: mov             x3, x0
    // 0x10ed460: ldur            d0, [fp, #-0x28]
    // 0x10ed464: cmp             w3, NULL
    // 0x10ed468: b.ne            #0x10ed474
    // 0x10ed46c: r0 = scale()
    //     0x10ed46c: bl              #0x12fc688  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedSuperellipseBorder::scale
    // 0x10ed470: b               #0x10ed478
    // 0x10ed474: r0 = Null
    //     0x10ed474: mov             x0, NULL
    // 0x10ed478: LeaveFrame
    //     0x10ed478: mov             SP, fp
    //     0x10ed47c: ldp             fp, lr, [SP], #0x10
    // 0x10ed480: ret
    //     0x10ed480: ret             
    // 0x10ed484: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ed484: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ed488: b               #0x10ed344
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f04cc, size: 0x160
    // 0x10f04cc: EnterFrame
    //     0x10f04cc: stp             fp, lr, [SP, #-0x10]!
    //     0x10f04d0: mov             fp, SP
    // 0x10f04d4: AllocStack(0x30)
    //     0x10f04d4: sub             SP, SP, #0x30
    // 0x10f04d8: SetupParameters(RoundedSuperellipseBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10f04d8: mov             x3, x1
    //     0x10f04dc: mov             x0, x2
    //     0x10f04e0: mov             v1.16b, v0.16b
    //     0x10f04e4: stur            x1, [fp, #-8]
    //     0x10f04e8: stur            x2, [fp, #-0x10]
    //     0x10f04ec: stur            d0, [fp, #-0x28]
    // 0x10f04f0: CheckStackOverflow
    //     0x10f04f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f04f4: cmp             SP, x16
    //     0x10f04f8: b.ls            #0x10f0624
    // 0x10f04fc: r1 = LoadClassIdInstr(r0)
    //     0x10f04fc: ldur            x1, [x0, #-1]
    //     0x10f0500: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0504: cmp             x1, #0xbd4
    // 0x10f0508: b.ne            #0x10f0578
    // 0x10f050c: LoadField: r1 = r3->field_7
    //     0x10f050c: ldur            w1, [x3, #7]
    // 0x10f0510: DecompressPointer r1
    //     0x10f0510: add             x1, x1, HEAP, lsl #32
    // 0x10f0514: LoadField: r2 = r0->field_7
    //     0x10f0514: ldur            w2, [x0, #7]
    // 0x10f0518: DecompressPointer r2
    //     0x10f0518: add             x2, x2, HEAP, lsl #32
    // 0x10f051c: mov             v0.16b, v1.16b
    // 0x10f0520: r0 = lerp()
    //     0x10f0520: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0524: mov             x3, x0
    // 0x10f0528: ldur            x0, [fp, #-8]
    // 0x10f052c: stur            x3, [fp, #-0x18]
    // 0x10f0530: LoadField: r1 = r0->field_b
    //     0x10f0530: ldur            w1, [x0, #0xb]
    // 0x10f0534: DecompressPointer r1
    //     0x10f0534: add             x1, x1, HEAP, lsl #32
    // 0x10f0538: ldur            x4, [fp, #-0x10]
    // 0x10f053c: LoadField: r2 = r4->field_b
    //     0x10f053c: ldur            w2, [x4, #0xb]
    // 0x10f0540: DecompressPointer r2
    //     0x10f0540: add             x2, x2, HEAP, lsl #32
    // 0x10f0544: ldur            d0, [fp, #-0x28]
    // 0x10f0548: r0 = lerp()
    //     0x10f0548: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10f054c: stur            x0, [fp, #-0x20]
    // 0x10f0550: r0 = RoundedSuperellipseBorder()
    //     0x10f0550: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0x10f0554: mov             x1, x0
    // 0x10f0558: ldur            x0, [fp, #-0x20]
    // 0x10f055c: StoreField: r1->field_b = r0
    //     0x10f055c: stur            w0, [x1, #0xb]
    // 0x10f0560: ldur            x0, [fp, #-0x18]
    // 0x10f0564: StoreField: r1->field_7 = r0
    //     0x10f0564: stur            w0, [x1, #7]
    // 0x10f0568: mov             x0, x1
    // 0x10f056c: LeaveFrame
    //     0x10f056c: mov             SP, fp
    //     0x10f0570: ldp             fp, lr, [SP], #0x10
    // 0x10f0574: ret
    //     0x10f0574: ret             
    // 0x10f0578: mov             x4, x0
    // 0x10f057c: mov             x0, x3
    // 0x10f0580: cmp             x1, #0xbd2
    // 0x10f0584: b.ne            #0x10f0604
    // 0x10f0588: ldur            d1, [fp, #-0x28]
    // 0x10f058c: LoadField: r1 = r0->field_7
    //     0x10f058c: ldur            w1, [x0, #7]
    // 0x10f0590: DecompressPointer r1
    //     0x10f0590: add             x1, x1, HEAP, lsl #32
    // 0x10f0594: LoadField: r2 = r4->field_7
    //     0x10f0594: ldur            w2, [x4, #7]
    // 0x10f0598: DecompressPointer r2
    //     0x10f0598: add             x2, x2, HEAP, lsl #32
    // 0x10f059c: mov             v0.16b, v1.16b
    // 0x10f05a0: r0 = lerp()
    //     0x10f05a0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f05a4: ldur            x1, [fp, #-8]
    // 0x10f05a8: stur            x0, [fp, #-0x20]
    // 0x10f05ac: LoadField: r2 = r1->field_b
    //     0x10f05ac: ldur            w2, [x1, #0xb]
    // 0x10f05b0: DecompressPointer r2
    //     0x10f05b0: add             x2, x2, HEAP, lsl #32
    // 0x10f05b4: ldur            x3, [fp, #-0x10]
    // 0x10f05b8: stur            x2, [fp, #-0x18]
    // 0x10f05bc: LoadField: d0 = r3->field_b
    //     0x10f05bc: ldur            d0, [x3, #0xb]
    // 0x10f05c0: stur            d0, [fp, #-0x30]
    // 0x10f05c4: r1 = <RoundedSuperellipseBorder>
    //     0x10f05c4: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2da8] TypeArguments: <RoundedSuperellipseBorder>
    //     0x10f05c8: ldr             x1, [x1, #0xda8]
    // 0x10f05cc: r0 = _RoundedSuperellipseToCircleBorder()
    //     0x10f05cc: bl              #0x10ed48c  ; Allocate_RoundedSuperellipseToCircleBorderStub -> _RoundedSuperellipseToCircleBorder (size=0x24)
    // 0x10f05d0: mov             x1, x0
    // 0x10f05d4: ldur            x0, [fp, #-0x18]
    // 0x10f05d8: StoreField: r1->field_f = r0
    //     0x10f05d8: stur            w0, [x1, #0xf]
    // 0x10f05dc: ldur            d0, [fp, #-0x28]
    // 0x10f05e0: StoreField: r1->field_13 = d0
    //     0x10f05e0: stur            d0, [x1, #0x13]
    // 0x10f05e4: ldur            d0, [fp, #-0x30]
    // 0x10f05e8: StoreField: r1->field_1b = d0
    //     0x10f05e8: stur            d0, [x1, #0x1b]
    // 0x10f05ec: ldur            x0, [fp, #-0x20]
    // 0x10f05f0: StoreField: r1->field_7 = r0
    //     0x10f05f0: stur            w0, [x1, #7]
    // 0x10f05f4: mov             x0, x1
    // 0x10f05f8: LeaveFrame
    //     0x10f05f8: mov             SP, fp
    //     0x10f05fc: ldp             fp, lr, [SP], #0x10
    // 0x10f0600: ret
    //     0x10f0600: ret             
    // 0x10f0604: mov             x1, x0
    // 0x10f0608: mov             x3, x4
    // 0x10f060c: ldur            d0, [fp, #-0x28]
    // 0x10f0610: mov             x2, x3
    // 0x10f0614: r0 = lerpTo()
    //     0x10f0614: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f0618: LeaveFrame
    //     0x10f0618: mov             SP, fp
    //     0x10f061c: ldp             fp, lr, [SP], #0x10
    // 0x10f0620: ret
    //     0x10f0620: ret             
    // 0x10f0624: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f0624: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f0628: b               #0x10f04fc
  }
  _ ==(/* No info */) {
    // ** addr: 0x1295fd0, size: 0xec
    // 0x1295fd0: EnterFrame
    //     0x1295fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1295fd4: mov             fp, SP
    // 0x1295fd8: AllocStack(0x10)
    //     0x1295fd8: sub             SP, SP, #0x10
    // 0x1295fdc: CheckStackOverflow
    //     0x1295fdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1295fe0: cmp             SP, x16
    //     0x1295fe4: b.ls            #0x12960b4
    // 0x1295fe8: ldr             x0, [fp, #0x10]
    // 0x1295fec: cmp             w0, NULL
    // 0x1295ff0: b.ne            #0x1296004
    // 0x1295ff4: r0 = false
    //     0x1295ff4: add             x0, NULL, #0x30  ; false
    // 0x1295ff8: LeaveFrame
    //     0x1295ff8: mov             SP, fp
    //     0x1295ffc: ldp             fp, lr, [SP], #0x10
    // 0x1296000: ret
    //     0x1296000: ret             
    // 0x1296004: str             x0, [SP]
    // 0x1296008: r0 = runtimeType()
    //     0x1296008: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129600c: r1 = LoadClassIdInstr(r0)
    //     0x129600c: ldur            x1, [x0, #-1]
    //     0x1296010: ubfx            x1, x1, #0xc, #0x14
    // 0x1296014: r16 = RoundedSuperellipseBorder
    //     0x1296014: add             x16, PP, #0x98, lsl #12  ; [pp+0x98808] Type: RoundedSuperellipseBorder
    //     0x1296018: ldr             x16, [x16, #0x808]
    // 0x129601c: stp             x16, x0, [SP]
    // 0x1296020: mov             x0, x1
    // 0x1296024: mov             lr, x0
    // 0x1296028: ldr             lr, [x21, lr, lsl #3]
    // 0x129602c: blr             lr
    // 0x1296030: tbz             w0, #4, #0x1296044
    // 0x1296034: r0 = false
    //     0x1296034: add             x0, NULL, #0x30  ; false
    // 0x1296038: LeaveFrame
    //     0x1296038: mov             SP, fp
    //     0x129603c: ldp             fp, lr, [SP], #0x10
    // 0x1296040: ret
    //     0x1296040: ret             
    // 0x1296044: ldr             x0, [fp, #0x10]
    // 0x1296048: r1 = 60
    //     0x1296048: mov             x1, #0x3c
    // 0x129604c: branchIfSmi(r0, 0x1296058)
    //     0x129604c: tbz             w0, #0, #0x1296058
    // 0x1296050: r1 = LoadClassIdInstr(r0)
    //     0x1296050: ldur            x1, [x0, #-1]
    //     0x1296054: ubfx            x1, x1, #0xc, #0x14
    // 0x1296058: cmp             x1, #0xbd4
    // 0x129605c: b.ne            #0x12960a4
    // 0x1296060: ldr             x1, [fp, #0x18]
    // 0x1296064: LoadField: r2 = r0->field_7
    //     0x1296064: ldur            w2, [x0, #7]
    // 0x1296068: DecompressPointer r2
    //     0x1296068: add             x2, x2, HEAP, lsl #32
    // 0x129606c: LoadField: r3 = r1->field_7
    //     0x129606c: ldur            w3, [x1, #7]
    // 0x1296070: DecompressPointer r3
    //     0x1296070: add             x3, x3, HEAP, lsl #32
    // 0x1296074: stp             x3, x2, [SP]
    // 0x1296078: r0 = ==()
    //     0x1296078: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x129607c: tbnz            w0, #4, #0x12960a4
    // 0x1296080: ldr             x1, [fp, #0x18]
    // 0x1296084: ldr             x0, [fp, #0x10]
    // 0x1296088: LoadField: r2 = r0->field_b
    //     0x1296088: ldur            w2, [x0, #0xb]
    // 0x129608c: DecompressPointer r2
    //     0x129608c: add             x2, x2, HEAP, lsl #32
    // 0x1296090: LoadField: r0 = r1->field_b
    //     0x1296090: ldur            w0, [x1, #0xb]
    // 0x1296094: DecompressPointer r0
    //     0x1296094: add             x0, x0, HEAP, lsl #32
    // 0x1296098: stp             x0, x2, [SP]
    // 0x129609c: r0 = ==()
    //     0x129609c: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12960a0: b               #0x12960a8
    // 0x12960a4: r0 = false
    //     0x12960a4: add             x0, NULL, #0x30  ; false
    // 0x12960a8: LeaveFrame
    //     0x12960a8: mov             SP, fp
    //     0x12960ac: ldp             fp, lr, [SP], #0x10
    // 0x12960b0: ret
    //     0x12960b0: ret             
    // 0x12960b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12960b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12960b8: b               #0x1295fe8
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ebcd8, size: 0x1f8
    // 0x12ebcd8: EnterFrame
    //     0x12ebcd8: stp             fp, lr, [SP, #-0x10]!
    //     0x12ebcdc: mov             fp, SP
    // 0x12ebce0: AllocStack(0x58)
    //     0x12ebce0: sub             SP, SP, #0x58
    // 0x12ebce4: SetupParameters(RoundedSuperellipseBorder this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */, {dynamic textDirection = Null /* r4, fp-0x10 */})
    //     0x12ebce4: mov             x0, x1
    //     0x12ebce8: mov             x1, x2
    //     0x12ebcec: stur            x2, [fp, #-0x18]
    //     0x12ebcf0: mov             x2, x3
    //     0x12ebcf4: stur            x3, [fp, #-0x20]
    //     0x12ebcf8: mov             x3, x5
    //     0x12ebcfc: stur            x5, [fp, #-0x28]
    //     0x12ebd00: ldur            w5, [x4, #0x13]
    //     0x12ebd04: ldur            w6, [x4, #0x1f]
    //     0x12ebd08: add             x6, x6, HEAP, lsl #32
    //     0x12ebd0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ebd10: ldr             x16, [x16, #0x210]
    //     0x12ebd14: cmp             w6, w16
    //     0x12ebd18: b.ne            #0x12ebd38
    //     0x12ebd1c: ldur            w6, [x4, #0x23]
    //     0x12ebd20: add             x6, x6, HEAP, lsl #32
    //     0x12ebd24: sub             w4, w5, w6
    //     0x12ebd28: add             x5, fp, w4, sxtw #2
    //     0x12ebd2c: ldr             x5, [x5, #8]
    //     0x12ebd30: mov             x4, x5
    //     0x12ebd34: b               #0x12ebd3c
    //     0x12ebd38: mov             x4, NULL
    //     0x12ebd3c: stur            x4, [fp, #-0x10]
    // 0x12ebd40: CheckStackOverflow
    //     0x12ebd40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ebd44: cmp             SP, x16
    //     0x12ebd48: b.ls            #0x12ebec4
    // 0x12ebd4c: LoadField: r5 = r0->field_b
    //     0x12ebd4c: ldur            w5, [x0, #0xb]
    // 0x12ebd50: DecompressPointer r5
    //     0x12ebd50: add             x5, x5, HEAP, lsl #32
    // 0x12ebd54: stur            x5, [fp, #-8]
    // 0x12ebd58: r16 = Instance_BorderRadius
    //     0x12ebd58: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ebd5c: ldr             x16, [x16, #0x508]
    // 0x12ebd60: stp             x16, x5, [SP]
    // 0x12ebd64: r0 = ==()
    //     0x12ebd64: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ebd68: tbnz            w0, #4, #0x12ebd80
    // 0x12ebd6c: ldur            x1, [fp, #-0x18]
    // 0x12ebd70: ldur            x2, [fp, #-0x20]
    // 0x12ebd74: ldur            x3, [fp, #-0x28]
    // 0x12ebd78: r0 = drawRect()
    //     0x12ebd78: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ebd7c: b               #0x12ebeb4
    // 0x12ebd80: ldur            x0, [fp, #-8]
    // 0x12ebd84: r1 = LoadClassIdInstr(r0)
    //     0x12ebd84: ldur            x1, [x0, #-1]
    //     0x12ebd88: ubfx            x1, x1, #0xc, #0x14
    // 0x12ebd8c: cmp             x1, #0xb88
    // 0x12ebd90: b.ne            #0x12ebe64
    // 0x12ebd94: ldur            x2, [fp, #-0x10]
    // 0x12ebd98: cmp             w2, NULL
    // 0x12ebd9c: b.eq            #0x12ebecc
    // 0x12ebda0: LoadField: r1 = r2->field_7
    //     0x12ebda0: ldur            x1, [x2, #7]
    // 0x12ebda4: cmp             x1, #0
    // 0x12ebda8: b.gt            #0x12ebe08
    // 0x12ebdac: LoadField: r1 = r0->field_b
    //     0x12ebdac: ldur            w1, [x0, #0xb]
    // 0x12ebdb0: DecompressPointer r1
    //     0x12ebdb0: add             x1, x1, HEAP, lsl #32
    // 0x12ebdb4: stur            x1, [fp, #-0x48]
    // 0x12ebdb8: LoadField: r2 = r0->field_7
    //     0x12ebdb8: ldur            w2, [x0, #7]
    // 0x12ebdbc: DecompressPointer r2
    //     0x12ebdbc: add             x2, x2, HEAP, lsl #32
    // 0x12ebdc0: stur            x2, [fp, #-0x40]
    // 0x12ebdc4: LoadField: r3 = r0->field_13
    //     0x12ebdc4: ldur            w3, [x0, #0x13]
    // 0x12ebdc8: DecompressPointer r3
    //     0x12ebdc8: add             x3, x3, HEAP, lsl #32
    // 0x12ebdcc: stur            x3, [fp, #-0x38]
    // 0x12ebdd0: LoadField: r4 = r0->field_f
    //     0x12ebdd0: ldur            w4, [x0, #0xf]
    // 0x12ebdd4: DecompressPointer r4
    //     0x12ebdd4: add             x4, x4, HEAP, lsl #32
    // 0x12ebdd8: stur            x4, [fp, #-0x30]
    // 0x12ebddc: r0 = BorderRadius()
    //     0x12ebddc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ebde0: mov             x1, x0
    // 0x12ebde4: ldur            x0, [fp, #-0x48]
    // 0x12ebde8: StoreField: r1->field_7 = r0
    //     0x12ebde8: stur            w0, [x1, #7]
    // 0x12ebdec: ldur            x0, [fp, #-0x40]
    // 0x12ebdf0: StoreField: r1->field_b = r0
    //     0x12ebdf0: stur            w0, [x1, #0xb]
    // 0x12ebdf4: ldur            x0, [fp, #-0x38]
    // 0x12ebdf8: StoreField: r1->field_f = r0
    //     0x12ebdf8: stur            w0, [x1, #0xf]
    // 0x12ebdfc: ldur            x0, [fp, #-0x30]
    // 0x12ebe00: StoreField: r1->field_13 = r0
    //     0x12ebe00: stur            w0, [x1, #0x13]
    // 0x12ebe04: b               #0x12ebe9c
    // 0x12ebe08: LoadField: r1 = r0->field_7
    //     0x12ebe08: ldur            w1, [x0, #7]
    // 0x12ebe0c: DecompressPointer r1
    //     0x12ebe0c: add             x1, x1, HEAP, lsl #32
    // 0x12ebe10: stur            x1, [fp, #-0x48]
    // 0x12ebe14: LoadField: r2 = r0->field_b
    //     0x12ebe14: ldur            w2, [x0, #0xb]
    // 0x12ebe18: DecompressPointer r2
    //     0x12ebe18: add             x2, x2, HEAP, lsl #32
    // 0x12ebe1c: stur            x2, [fp, #-0x40]
    // 0x12ebe20: LoadField: r3 = r0->field_f
    //     0x12ebe20: ldur            w3, [x0, #0xf]
    // 0x12ebe24: DecompressPointer r3
    //     0x12ebe24: add             x3, x3, HEAP, lsl #32
    // 0x12ebe28: stur            x3, [fp, #-0x38]
    // 0x12ebe2c: LoadField: r4 = r0->field_13
    //     0x12ebe2c: ldur            w4, [x0, #0x13]
    // 0x12ebe30: DecompressPointer r4
    //     0x12ebe30: add             x4, x4, HEAP, lsl #32
    // 0x12ebe34: stur            x4, [fp, #-0x30]
    // 0x12ebe38: r0 = BorderRadius()
    //     0x12ebe38: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ebe3c: mov             x1, x0
    // 0x12ebe40: ldur            x0, [fp, #-0x48]
    // 0x12ebe44: StoreField: r1->field_7 = r0
    //     0x12ebe44: stur            w0, [x1, #7]
    // 0x12ebe48: ldur            x0, [fp, #-0x40]
    // 0x12ebe4c: StoreField: r1->field_b = r0
    //     0x12ebe4c: stur            w0, [x1, #0xb]
    // 0x12ebe50: ldur            x0, [fp, #-0x38]
    // 0x12ebe54: StoreField: r1->field_f = r0
    //     0x12ebe54: stur            w0, [x1, #0xf]
    // 0x12ebe58: ldur            x0, [fp, #-0x30]
    // 0x12ebe5c: StoreField: r1->field_13 = r0
    //     0x12ebe5c: stur            w0, [x1, #0x13]
    // 0x12ebe60: b               #0x12ebe9c
    // 0x12ebe64: ldur            x2, [fp, #-0x10]
    // 0x12ebe68: cmp             x1, #0xb89
    // 0x12ebe6c: b.ne            #0x12ebe78
    // 0x12ebe70: mov             x1, x0
    // 0x12ebe74: b               #0x12ebe9c
    // 0x12ebe78: r1 = LoadClassIdInstr(r0)
    //     0x12ebe78: ldur            x1, [x0, #-1]
    //     0x12ebe7c: ubfx            x1, x1, #0xc, #0x14
    // 0x12ebe80: mov             x16, x0
    // 0x12ebe84: mov             x0, x1
    // 0x12ebe88: mov             x1, x16
    // 0x12ebe8c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ebe8c: sub             lr, x0, #1, lsl #12
    //     0x12ebe90: ldr             lr, [x21, lr, lsl #3]
    //     0x12ebe94: blr             lr
    // 0x12ebe98: mov             x1, x0
    // 0x12ebe9c: ldur            x2, [fp, #-0x20]
    // 0x12ebea0: r0 = toRSuperellipse()
    //     0x12ebea0: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x12ebea4: ldur            x1, [fp, #-0x18]
    // 0x12ebea8: mov             x2, x0
    // 0x12ebeac: ldur            x3, [fp, #-0x28]
    // 0x12ebeb0: r0 = drawRSuperellipse()
    //     0x12ebeb0: bl              #0x12ebed0  ; [dart:ui] _NativeCanvas::drawRSuperellipse
    // 0x12ebeb4: r0 = Null
    //     0x12ebeb4: mov             x0, NULL
    // 0x12ebeb8: LeaveFrame
    //     0x12ebeb8: mov             SP, fp
    //     0x12ebebc: ldp             fp, lr, [SP], #0x10
    // 0x12ebec0: ret
    //     0x12ebec0: ret             
    // 0x12ebec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ebec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ebec8: b               #0x12ebd4c
    // 0x12ebecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ebecc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ed3d4, size: 0x270
    // 0x12ed3d4: EnterFrame
    //     0x12ed3d4: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed3d8: mov             fp, SP
    // 0x12ed3dc: AllocStack(0x60)
    //     0x12ed3dc: sub             SP, SP, #0x60
    // 0x12ed3e0: SetupParameters(RoundedSuperellipseBorder this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* r3 => r1, fp-0x28 */, {dynamic textDirection = Null /* r3, fp-0x18 */})
    //     0x12ed3e0: mov             x0, x2
    //     0x12ed3e4: stur            x2, [fp, #-0x20]
    //     0x12ed3e8: mov             x2, x1
    //     0x12ed3ec: mov             x1, x3
    //     0x12ed3f0: stur            x3, [fp, #-0x28]
    //     0x12ed3f4: ldur            w3, [x4, #0x13]
    //     0x12ed3f8: ldur            w5, [x4, #0x1f]
    //     0x12ed3fc: add             x5, x5, HEAP, lsl #32
    //     0x12ed400: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ed404: ldr             x16, [x16, #0x210]
    //     0x12ed408: cmp             w5, w16
    //     0x12ed40c: b.ne            #0x12ed428
    //     0x12ed410: ldur            w5, [x4, #0x23]
    //     0x12ed414: add             x5, x5, HEAP, lsl #32
    //     0x12ed418: sub             w4, w3, w5
    //     0x12ed41c: add             x3, fp, w4, sxtw #2
    //     0x12ed420: ldr             x3, [x3, #8]
    //     0x12ed424: b               #0x12ed42c
    //     0x12ed428: mov             x3, NULL
    //     0x12ed42c: stur            x3, [fp, #-0x18]
    // 0x12ed430: CheckStackOverflow
    //     0x12ed430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed434: cmp             SP, x16
    //     0x12ed438: b.ls            #0x12ed638
    // 0x12ed43c: LoadField: r4 = r2->field_7
    //     0x12ed43c: ldur            w4, [x2, #7]
    // 0x12ed440: DecompressPointer r4
    //     0x12ed440: add             x4, x4, HEAP, lsl #32
    // 0x12ed444: stur            x4, [fp, #-0x10]
    // 0x12ed448: LoadField: r5 = r4->field_13
    //     0x12ed448: ldur            w5, [x4, #0x13]
    // 0x12ed44c: DecompressPointer r5
    //     0x12ed44c: add             x5, x5, HEAP, lsl #32
    // 0x12ed450: LoadField: r6 = r5->field_7
    //     0x12ed450: ldur            x6, [x5, #7]
    // 0x12ed454: cmp             x6, #0
    // 0x12ed458: b.le            #0x12ed628
    // 0x12ed45c: d1 = 1.000000
    //     0x12ed45c: fmov            d1, #1.00000000
    // 0x12ed460: d0 = 2.000000
    //     0x12ed460: fmov            d0, #2.00000000
    // 0x12ed464: LoadField: d2 = r4->field_b
    //     0x12ed464: ldur            d2, [x4, #0xb]
    // 0x12ed468: ArrayLoad: d3 = r4[0]  ; List_8
    //     0x12ed468: ldur            d3, [x4, #0x17]
    // 0x12ed46c: fadd            d4, d3, d1
    // 0x12ed470: fmul            d3, d2, d4
    // 0x12ed474: fdiv            d5, d3, d0
    // 0x12ed478: fdiv            d3, d4, d0
    // 0x12ed47c: fsub            d4, d1, d3
    // 0x12ed480: fmul            d1, d2, d4
    // 0x12ed484: fsub            d2, d5, d1
    // 0x12ed488: fdiv            d1, d2, d0
    // 0x12ed48c: stur            d1, [fp, #-0x50]
    // 0x12ed490: LoadField: r5 = r2->field_b
    //     0x12ed490: ldur            w5, [x2, #0xb]
    // 0x12ed494: DecompressPointer r5
    //     0x12ed494: add             x5, x5, HEAP, lsl #32
    // 0x12ed498: stur            x5, [fp, #-8]
    // 0x12ed49c: r16 = Instance_BorderRadius
    //     0x12ed49c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ed4a0: ldr             x16, [x16, #0x508]
    // 0x12ed4a4: stp             x16, x5, [SP]
    // 0x12ed4a8: r0 = ==()
    //     0x12ed4a8: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ed4ac: tbnz            w0, #4, #0x12ed4dc
    // 0x12ed4b0: ldur            x1, [fp, #-0x28]
    // 0x12ed4b4: ldur            d0, [fp, #-0x50]
    // 0x12ed4b8: r0 = inflate()
    //     0x12ed4b8: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x12ed4bc: ldur            x1, [fp, #-0x10]
    // 0x12ed4c0: stur            x0, [fp, #-0x30]
    // 0x12ed4c4: r0 = toPaint()
    //     0x12ed4c4: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed4c8: ldur            x1, [fp, #-0x20]
    // 0x12ed4cc: ldur            x2, [fp, #-0x30]
    // 0x12ed4d0: mov             x3, x0
    // 0x12ed4d4: r0 = drawRect()
    //     0x12ed4d4: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ed4d8: b               #0x12ed628
    // 0x12ed4dc: ldur            x0, [fp, #-8]
    // 0x12ed4e0: r1 = LoadClassIdInstr(r0)
    //     0x12ed4e0: ldur            x1, [x0, #-1]
    //     0x12ed4e4: ubfx            x1, x1, #0xc, #0x14
    // 0x12ed4e8: cmp             x1, #0xb88
    // 0x12ed4ec: b.ne            #0x12ed5c0
    // 0x12ed4f0: ldur            x2, [fp, #-0x18]
    // 0x12ed4f4: cmp             w2, NULL
    // 0x12ed4f8: b.eq            #0x12ed640
    // 0x12ed4fc: LoadField: r1 = r2->field_7
    //     0x12ed4fc: ldur            x1, [x2, #7]
    // 0x12ed500: cmp             x1, #0
    // 0x12ed504: b.gt            #0x12ed564
    // 0x12ed508: LoadField: r1 = r0->field_b
    //     0x12ed508: ldur            w1, [x0, #0xb]
    // 0x12ed50c: DecompressPointer r1
    //     0x12ed50c: add             x1, x1, HEAP, lsl #32
    // 0x12ed510: stur            x1, [fp, #-0x48]
    // 0x12ed514: LoadField: r2 = r0->field_7
    //     0x12ed514: ldur            w2, [x0, #7]
    // 0x12ed518: DecompressPointer r2
    //     0x12ed518: add             x2, x2, HEAP, lsl #32
    // 0x12ed51c: stur            x2, [fp, #-0x40]
    // 0x12ed520: LoadField: r3 = r0->field_13
    //     0x12ed520: ldur            w3, [x0, #0x13]
    // 0x12ed524: DecompressPointer r3
    //     0x12ed524: add             x3, x3, HEAP, lsl #32
    // 0x12ed528: stur            x3, [fp, #-0x38]
    // 0x12ed52c: LoadField: r4 = r0->field_f
    //     0x12ed52c: ldur            w4, [x0, #0xf]
    // 0x12ed530: DecompressPointer r4
    //     0x12ed530: add             x4, x4, HEAP, lsl #32
    // 0x12ed534: stur            x4, [fp, #-0x30]
    // 0x12ed538: r0 = BorderRadius()
    //     0x12ed538: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ed53c: mov             x1, x0
    // 0x12ed540: ldur            x0, [fp, #-0x48]
    // 0x12ed544: StoreField: r1->field_7 = r0
    //     0x12ed544: stur            w0, [x1, #7]
    // 0x12ed548: ldur            x0, [fp, #-0x40]
    // 0x12ed54c: StoreField: r1->field_b = r0
    //     0x12ed54c: stur            w0, [x1, #0xb]
    // 0x12ed550: ldur            x0, [fp, #-0x38]
    // 0x12ed554: StoreField: r1->field_f = r0
    //     0x12ed554: stur            w0, [x1, #0xf]
    // 0x12ed558: ldur            x0, [fp, #-0x30]
    // 0x12ed55c: StoreField: r1->field_13 = r0
    //     0x12ed55c: stur            w0, [x1, #0x13]
    // 0x12ed560: b               #0x12ed5f8
    // 0x12ed564: LoadField: r1 = r0->field_7
    //     0x12ed564: ldur            w1, [x0, #7]
    // 0x12ed568: DecompressPointer r1
    //     0x12ed568: add             x1, x1, HEAP, lsl #32
    // 0x12ed56c: stur            x1, [fp, #-0x48]
    // 0x12ed570: LoadField: r2 = r0->field_b
    //     0x12ed570: ldur            w2, [x0, #0xb]
    // 0x12ed574: DecompressPointer r2
    //     0x12ed574: add             x2, x2, HEAP, lsl #32
    // 0x12ed578: stur            x2, [fp, #-0x40]
    // 0x12ed57c: LoadField: r3 = r0->field_f
    //     0x12ed57c: ldur            w3, [x0, #0xf]
    // 0x12ed580: DecompressPointer r3
    //     0x12ed580: add             x3, x3, HEAP, lsl #32
    // 0x12ed584: stur            x3, [fp, #-0x38]
    // 0x12ed588: LoadField: r4 = r0->field_13
    //     0x12ed588: ldur            w4, [x0, #0x13]
    // 0x12ed58c: DecompressPointer r4
    //     0x12ed58c: add             x4, x4, HEAP, lsl #32
    // 0x12ed590: stur            x4, [fp, #-0x30]
    // 0x12ed594: r0 = BorderRadius()
    //     0x12ed594: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ed598: mov             x1, x0
    // 0x12ed59c: ldur            x0, [fp, #-0x48]
    // 0x12ed5a0: StoreField: r1->field_7 = r0
    //     0x12ed5a0: stur            w0, [x1, #7]
    // 0x12ed5a4: ldur            x0, [fp, #-0x40]
    // 0x12ed5a8: StoreField: r1->field_b = r0
    //     0x12ed5a8: stur            w0, [x1, #0xb]
    // 0x12ed5ac: ldur            x0, [fp, #-0x38]
    // 0x12ed5b0: StoreField: r1->field_f = r0
    //     0x12ed5b0: stur            w0, [x1, #0xf]
    // 0x12ed5b4: ldur            x0, [fp, #-0x30]
    // 0x12ed5b8: StoreField: r1->field_13 = r0
    //     0x12ed5b8: stur            w0, [x1, #0x13]
    // 0x12ed5bc: b               #0x12ed5f8
    // 0x12ed5c0: ldur            x2, [fp, #-0x18]
    // 0x12ed5c4: cmp             x1, #0xb89
    // 0x12ed5c8: b.ne            #0x12ed5d4
    // 0x12ed5cc: mov             x1, x0
    // 0x12ed5d0: b               #0x12ed5f8
    // 0x12ed5d4: r1 = LoadClassIdInstr(r0)
    //     0x12ed5d4: ldur            x1, [x0, #-1]
    //     0x12ed5d8: ubfx            x1, x1, #0xc, #0x14
    // 0x12ed5dc: mov             x16, x0
    // 0x12ed5e0: mov             x0, x1
    // 0x12ed5e4: mov             x1, x16
    // 0x12ed5e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ed5e8: sub             lr, x0, #1, lsl #12
    //     0x12ed5ec: ldr             lr, [x21, lr, lsl #3]
    //     0x12ed5f0: blr             lr
    // 0x12ed5f4: mov             x1, x0
    // 0x12ed5f8: ldur            x2, [fp, #-0x28]
    // 0x12ed5fc: r0 = toRSuperellipse()
    //     0x12ed5fc: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x12ed600: mov             x1, x0
    // 0x12ed604: ldur            d0, [fp, #-0x50]
    // 0x12ed608: r0 = inflate()
    //     0x12ed608: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12ed60c: ldur            x1, [fp, #-0x10]
    // 0x12ed610: stur            x0, [fp, #-8]
    // 0x12ed614: r0 = toPaint()
    //     0x12ed614: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed618: ldur            x1, [fp, #-0x20]
    // 0x12ed61c: ldur            x2, [fp, #-8]
    // 0x12ed620: mov             x3, x0
    // 0x12ed624: r0 = drawRSuperellipse()
    //     0x12ed624: bl              #0x12ebed0  ; [dart:ui] _NativeCanvas::drawRSuperellipse
    // 0x12ed628: r0 = Null
    //     0x12ed628: mov             x0, NULL
    // 0x12ed62c: LeaveFrame
    //     0x12ed62c: mov             SP, fp
    //     0x12ed630: ldp             fp, lr, [SP], #0x10
    // 0x12ed634: ret
    //     0x12ed634: ret             
    // 0x12ed638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ed638: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ed63c: b               #0x12ed43c
    // 0x12ed640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ed640: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fc688, size: 0x1e0
    // 0x12fc688: EnterFrame
    //     0x12fc688: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc68c: mov             fp, SP
    // 0x12fc690: AllocStack(0x38)
    //     0x12fc690: sub             SP, SP, #0x38
    // 0x12fc694: SetupParameters(RoundedSuperellipseBorder this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x38 */)
    //     0x12fc694: mov             x0, x1
    //     0x12fc698: mov             v1.16b, v0.16b
    //     0x12fc69c: stur            x1, [fp, #-8]
    //     0x12fc6a0: stur            d0, [fp, #-0x38]
    // 0x12fc6a4: CheckStackOverflow
    //     0x12fc6a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc6a8: cmp             SP, x16
    //     0x12fc6ac: b.ls            #0x12fc860
    // 0x12fc6b0: LoadField: r1 = r0->field_7
    //     0x12fc6b0: ldur            w1, [x0, #7]
    // 0x12fc6b4: DecompressPointer r1
    //     0x12fc6b4: add             x1, x1, HEAP, lsl #32
    // 0x12fc6b8: mov             v0.16b, v1.16b
    // 0x12fc6bc: r0 = scale()
    //     0x12fc6bc: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fc6c0: mov             x2, x0
    // 0x12fc6c4: ldur            x0, [fp, #-8]
    // 0x12fc6c8: stur            x2, [fp, #-0x18]
    // 0x12fc6cc: LoadField: r3 = r0->field_b
    //     0x12fc6cc: ldur            w3, [x0, #0xb]
    // 0x12fc6d0: DecompressPointer r3
    //     0x12fc6d0: add             x3, x3, HEAP, lsl #32
    // 0x12fc6d4: stur            x3, [fp, #-0x10]
    // 0x12fc6d8: r0 = LoadClassIdInstr(r3)
    //     0x12fc6d8: ldur            x0, [x3, #-1]
    //     0x12fc6dc: ubfx            x0, x0, #0xc, #0x14
    // 0x12fc6e0: cmp             x0, #0xb88
    // 0x12fc6e4: b.ne            #0x12fc778
    // 0x12fc6e8: LoadField: r1 = r3->field_7
    //     0x12fc6e8: ldur            w1, [x3, #7]
    // 0x12fc6ec: DecompressPointer r1
    //     0x12fc6ec: add             x1, x1, HEAP, lsl #32
    // 0x12fc6f0: ldur            d0, [fp, #-0x38]
    // 0x12fc6f4: r0 = *()
    //     0x12fc6f4: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc6f8: mov             x2, x0
    // 0x12fc6fc: ldur            x0, [fp, #-0x10]
    // 0x12fc700: stur            x2, [fp, #-8]
    // 0x12fc704: LoadField: r1 = r0->field_b
    //     0x12fc704: ldur            w1, [x0, #0xb]
    // 0x12fc708: DecompressPointer r1
    //     0x12fc708: add             x1, x1, HEAP, lsl #32
    // 0x12fc70c: ldur            d0, [fp, #-0x38]
    // 0x12fc710: r0 = *()
    //     0x12fc710: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc714: mov             x2, x0
    // 0x12fc718: ldur            x0, [fp, #-0x10]
    // 0x12fc71c: stur            x2, [fp, #-0x20]
    // 0x12fc720: LoadField: r1 = r0->field_f
    //     0x12fc720: ldur            w1, [x0, #0xf]
    // 0x12fc724: DecompressPointer r1
    //     0x12fc724: add             x1, x1, HEAP, lsl #32
    // 0x12fc728: ldur            d0, [fp, #-0x38]
    // 0x12fc72c: r0 = *()
    //     0x12fc72c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc730: ldur            x2, [fp, #-0x10]
    // 0x12fc734: stur            x0, [fp, #-0x28]
    // 0x12fc738: LoadField: r1 = r2->field_13
    //     0x12fc738: ldur            w1, [x2, #0x13]
    // 0x12fc73c: DecompressPointer r1
    //     0x12fc73c: add             x1, x1, HEAP, lsl #32
    // 0x12fc740: ldur            d0, [fp, #-0x38]
    // 0x12fc744: r0 = *()
    //     0x12fc744: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc748: stur            x0, [fp, #-0x30]
    // 0x12fc74c: r0 = BorderRadiusDirectional()
    //     0x12fc74c: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0x12fc750: mov             x1, x0
    // 0x12fc754: ldur            x0, [fp, #-8]
    // 0x12fc758: StoreField: r1->field_7 = r0
    //     0x12fc758: stur            w0, [x1, #7]
    // 0x12fc75c: ldur            x0, [fp, #-0x20]
    // 0x12fc760: StoreField: r1->field_b = r0
    //     0x12fc760: stur            w0, [x1, #0xb]
    // 0x12fc764: ldur            x0, [fp, #-0x28]
    // 0x12fc768: StoreField: r1->field_f = r0
    //     0x12fc768: stur            w0, [x1, #0xf]
    // 0x12fc76c: ldur            x0, [fp, #-0x30]
    // 0x12fc770: StoreField: r1->field_13 = r0
    //     0x12fc770: stur            w0, [x1, #0x13]
    // 0x12fc774: b               #0x12fc838
    // 0x12fc778: mov             x2, x3
    // 0x12fc77c: cmp             x0, #0xb89
    // 0x12fc780: b.ne            #0x12fc818
    // 0x12fc784: LoadField: r1 = r2->field_7
    //     0x12fc784: ldur            w1, [x2, #7]
    // 0x12fc788: DecompressPointer r1
    //     0x12fc788: add             x1, x1, HEAP, lsl #32
    // 0x12fc78c: ldur            d0, [fp, #-0x38]
    // 0x12fc790: r0 = *()
    //     0x12fc790: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc794: mov             x2, x0
    // 0x12fc798: ldur            x0, [fp, #-0x10]
    // 0x12fc79c: stur            x2, [fp, #-8]
    // 0x12fc7a0: LoadField: r1 = r0->field_b
    //     0x12fc7a0: ldur            w1, [x0, #0xb]
    // 0x12fc7a4: DecompressPointer r1
    //     0x12fc7a4: add             x1, x1, HEAP, lsl #32
    // 0x12fc7a8: ldur            d0, [fp, #-0x38]
    // 0x12fc7ac: r0 = *()
    //     0x12fc7ac: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc7b0: mov             x2, x0
    // 0x12fc7b4: ldur            x0, [fp, #-0x10]
    // 0x12fc7b8: stur            x2, [fp, #-0x20]
    // 0x12fc7bc: LoadField: r1 = r0->field_f
    //     0x12fc7bc: ldur            w1, [x0, #0xf]
    // 0x12fc7c0: DecompressPointer r1
    //     0x12fc7c0: add             x1, x1, HEAP, lsl #32
    // 0x12fc7c4: ldur            d0, [fp, #-0x38]
    // 0x12fc7c8: r0 = *()
    //     0x12fc7c8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc7cc: ldur            x1, [fp, #-0x10]
    // 0x12fc7d0: stur            x0, [fp, #-0x28]
    // 0x12fc7d4: LoadField: r2 = r1->field_13
    //     0x12fc7d4: ldur            w2, [x1, #0x13]
    // 0x12fc7d8: DecompressPointer r2
    //     0x12fc7d8: add             x2, x2, HEAP, lsl #32
    // 0x12fc7dc: mov             x1, x2
    // 0x12fc7e0: ldur            d0, [fp, #-0x38]
    // 0x12fc7e4: r0 = *()
    //     0x12fc7e4: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc7e8: stur            x0, [fp, #-0x30]
    // 0x12fc7ec: r0 = BorderRadius()
    //     0x12fc7ec: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12fc7f0: mov             x1, x0
    // 0x12fc7f4: ldur            x0, [fp, #-8]
    // 0x12fc7f8: StoreField: r1->field_7 = r0
    //     0x12fc7f8: stur            w0, [x1, #7]
    // 0x12fc7fc: ldur            x0, [fp, #-0x20]
    // 0x12fc800: StoreField: r1->field_b = r0
    //     0x12fc800: stur            w0, [x1, #0xb]
    // 0x12fc804: ldur            x0, [fp, #-0x28]
    // 0x12fc808: StoreField: r1->field_f = r0
    //     0x12fc808: stur            w0, [x1, #0xf]
    // 0x12fc80c: ldur            x0, [fp, #-0x30]
    // 0x12fc810: StoreField: r1->field_13 = r0
    //     0x12fc810: stur            w0, [x1, #0x13]
    // 0x12fc814: b               #0x12fc838
    // 0x12fc818: mov             x1, x2
    // 0x12fc81c: r0 = LoadClassIdInstr(r1)
    //     0x12fc81c: ldur            x0, [x1, #-1]
    //     0x12fc820: ubfx            x0, x0, #0xc, #0x14
    // 0x12fc824: ldur            d0, [fp, #-0x38]
    // 0x12fc828: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x12fc828: sub             lr, x0, #0xfb8
    //     0x12fc82c: ldr             lr, [x21, lr, lsl #3]
    //     0x12fc830: blr             lr
    // 0x12fc834: mov             x1, x0
    // 0x12fc838: ldur            x0, [fp, #-0x18]
    // 0x12fc83c: stur            x1, [fp, #-8]
    // 0x12fc840: r0 = RoundedSuperellipseBorder()
    //     0x12fc840: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0x12fc844: ldur            x1, [fp, #-8]
    // 0x12fc848: StoreField: r0->field_b = r1
    //     0x12fc848: stur            w1, [x0, #0xb]
    // 0x12fc84c: ldur            x1, [fp, #-0x18]
    // 0x12fc850: StoreField: r0->field_7 = r1
    //     0x12fc850: stur            w1, [x0, #7]
    // 0x12fc854: LeaveFrame
    //     0x12fc854: mov             SP, fp
    //     0x12fc858: ldp             fp, lr, [SP], #0x10
    // 0x12fc85c: ret
    //     0x12fc85c: ret             
    // 0x12fc860: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fc860: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fc864: b               #0x12fc6b0
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x12ffe58, size: 0x32c
    // 0x12ffe58: EnterFrame
    //     0x12ffe58: stp             fp, lr, [SP, #-0x10]!
    //     0x12ffe5c: mov             fp, SP
    // 0x12ffe60: AllocStack(0x78)
    //     0x12ffe60: sub             SP, SP, #0x78
    // 0x12ffe64: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */, {dynamic textDirection = Null /* r0, fp-0x10 */})
    //     0x12ffe64: stur            x2, [fp, #-0x18]
    //     0x12ffe68: ldur            w0, [x4, #0x13]
    //     0x12ffe6c: ldur            w3, [x4, #0x1f]
    //     0x12ffe70: add             x3, x3, HEAP, lsl #32
    //     0x12ffe74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ffe78: ldr             x16, [x16, #0x210]
    //     0x12ffe7c: cmp             w3, w16
    //     0x12ffe80: b.ne            #0x12ffe9c
    //     0x12ffe84: ldur            w3, [x4, #0x23]
    //     0x12ffe88: add             x3, x3, HEAP, lsl #32
    //     0x12ffe8c: sub             w4, w0, w3
    //     0x12ffe90: add             x0, fp, w4, sxtw #2
    //     0x12ffe94: ldr             x0, [x0, #8]
    //     0x12ffe98: b               #0x12ffea0
    //     0x12ffe9c: mov             x0, NULL
    //     0x12ffea0: stur            x0, [fp, #-0x10]
    // 0x12ffea4: CheckStackOverflow
    //     0x12ffea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ffea8: cmp             SP, x16
    //     0x12ffeac: b.ls            #0x130016c
    // 0x12ffeb0: LoadField: r3 = r1->field_b
    //     0x12ffeb0: ldur            w3, [x1, #0xb]
    // 0x12ffeb4: DecompressPointer r3
    //     0x12ffeb4: add             x3, x3, HEAP, lsl #32
    // 0x12ffeb8: stur            x3, [fp, #-8]
    // 0x12ffebc: r16 = Instance_BorderRadius
    //     0x12ffebc: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ffec0: ldr             x16, [x16, #0x508]
    // 0x12ffec4: stp             x16, x3, [SP]
    // 0x12ffec8: r0 = ==()
    //     0x12ffec8: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ffecc: tbnz            w0, #4, #0x12fff68
    // 0x12ffed0: ldur            x2, [fp, #-0x18]
    // 0x12ffed4: r0 = _NativePath()
    //     0x12ffed4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12ffed8: mov             x1, x0
    // 0x12ffedc: stur            x0, [fp, #-0x20]
    // 0x12ffee0: r0 = __constructor$Method$FfiNative()
    //     0x12ffee0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12ffee4: ldur            x2, [fp, #-0x18]
    // 0x12ffee8: LoadField: d0 = r2->field_7
    //     0x12ffee8: ldur            d0, [x2, #7]
    // 0x12ffeec: stur            d0, [fp, #-0x68]
    // 0x12ffef0: LoadField: d1 = r2->field_f
    //     0x12ffef0: ldur            d1, [x2, #0xf]
    // 0x12ffef4: stur            d1, [fp, #-0x60]
    // 0x12ffef8: ArrayLoad: d2 = r2[0]  ; List_8
    //     0x12ffef8: ldur            d2, [x2, #0x17]
    // 0x12ffefc: stur            d2, [fp, #-0x58]
    // 0x12fff00: LoadField: d3 = r2->field_1f
    //     0x12fff00: ldur            d3, [x2, #0x1f]
    // 0x12fff04: ldur            x0, [fp, #-0x20]
    // 0x12fff08: stur            d3, [fp, #-0x50]
    // 0x12fff0c: LoadField: r1 = r0->field_7
    //     0x12fff0c: ldur            w1, [x0, #7]
    // 0x12fff10: DecompressPointer r1
    //     0x12fff10: add             x1, x1, HEAP, lsl #32
    // 0x12fff14: cmp             w1, NULL
    // 0x12fff18: b.eq            #0x1300174
    // 0x12fff1c: LoadField: r2 = r1->field_7
    //     0x12fff1c: ldur            x2, [x1, #7]
    // 0x12fff20: ldr             x1, [x2]
    // 0x12fff24: cbz             x1, #0x130014c
    // 0x12fff28: mov             x2, x1
    // 0x12fff2c: stur            x2, [fp, #-0x28]
    // 0x12fff30: r1 = <Never>
    //     0x12fff30: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12fff34: r0 = Pointer()
    //     0x12fff34: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12fff38: mov             x1, x0
    // 0x12fff3c: ldur            x0, [fp, #-0x28]
    // 0x12fff40: StoreField: r1->field_7 = r0
    //     0x12fff40: stur            x0, [x1, #7]
    // 0x12fff44: ldur            d0, [fp, #-0x68]
    // 0x12fff48: ldur            d1, [fp, #-0x60]
    // 0x12fff4c: ldur            d2, [fp, #-0x58]
    // 0x12fff50: ldur            d3, [fp, #-0x50]
    // 0x12fff54: r0 = __addRect$Method$FfiNative()
    //     0x12fff54: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0x12fff58: ldur            x0, [fp, #-0x20]
    // 0x12fff5c: LeaveFrame
    //     0x12fff5c: mov             SP, fp
    //     0x12fff60: ldp             fp, lr, [SP], #0x10
    // 0x12fff64: ret
    //     0x12fff64: ret             
    // 0x12fff68: ldur            x2, [fp, #-0x18]
    // 0x12fff6c: ldur            x0, [fp, #-8]
    // 0x12fff70: r0 = _NativePath()
    //     0x12fff70: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12fff74: mov             x1, x0
    // 0x12fff78: stur            x0, [fp, #-0x20]
    // 0x12fff7c: r0 = __constructor$Method$FfiNative()
    //     0x12fff7c: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12fff80: ldur            x0, [fp, #-8]
    // 0x12fff84: r1 = LoadClassIdInstr(r0)
    //     0x12fff84: ldur            x1, [x0, #-1]
    //     0x12fff88: ubfx            x1, x1, #0xc, #0x14
    // 0x12fff8c: cmp             x1, #0xb88
    // 0x12fff90: b.ne            #0x1300064
    // 0x12fff94: ldur            x2, [fp, #-0x10]
    // 0x12fff98: cmp             w2, NULL
    // 0x12fff9c: b.eq            #0x1300178
    // 0x12fffa0: LoadField: r1 = r2->field_7
    //     0x12fffa0: ldur            x1, [x2, #7]
    // 0x12fffa4: cmp             x1, #0
    // 0x12fffa8: b.gt            #0x1300008
    // 0x12fffac: LoadField: r1 = r0->field_b
    //     0x12fffac: ldur            w1, [x0, #0xb]
    // 0x12fffb0: DecompressPointer r1
    //     0x12fffb0: add             x1, x1, HEAP, lsl #32
    // 0x12fffb4: stur            x1, [fp, #-0x48]
    // 0x12fffb8: LoadField: r2 = r0->field_7
    //     0x12fffb8: ldur            w2, [x0, #7]
    // 0x12fffbc: DecompressPointer r2
    //     0x12fffbc: add             x2, x2, HEAP, lsl #32
    // 0x12fffc0: stur            x2, [fp, #-0x40]
    // 0x12fffc4: LoadField: r3 = r0->field_13
    //     0x12fffc4: ldur            w3, [x0, #0x13]
    // 0x12fffc8: DecompressPointer r3
    //     0x12fffc8: add             x3, x3, HEAP, lsl #32
    // 0x12fffcc: stur            x3, [fp, #-0x38]
    // 0x12fffd0: LoadField: r4 = r0->field_f
    //     0x12fffd0: ldur            w4, [x0, #0xf]
    // 0x12fffd4: DecompressPointer r4
    //     0x12fffd4: add             x4, x4, HEAP, lsl #32
    // 0x12fffd8: stur            x4, [fp, #-0x30]
    // 0x12fffdc: r0 = BorderRadius()
    //     0x12fffdc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12fffe0: mov             x1, x0
    // 0x12fffe4: ldur            x0, [fp, #-0x48]
    // 0x12fffe8: StoreField: r1->field_7 = r0
    //     0x12fffe8: stur            w0, [x1, #7]
    // 0x12fffec: ldur            x0, [fp, #-0x40]
    // 0x12ffff0: StoreField: r1->field_b = r0
    //     0x12ffff0: stur            w0, [x1, #0xb]
    // 0x12ffff4: ldur            x0, [fp, #-0x38]
    // 0x12ffff8: StoreField: r1->field_f = r0
    //     0x12ffff8: stur            w0, [x1, #0xf]
    // 0x12ffffc: ldur            x0, [fp, #-0x30]
    // 0x1300000: StoreField: r1->field_13 = r0
    //     0x1300000: stur            w0, [x1, #0x13]
    // 0x1300004: b               #0x130009c
    // 0x1300008: LoadField: r1 = r0->field_7
    //     0x1300008: ldur            w1, [x0, #7]
    // 0x130000c: DecompressPointer r1
    //     0x130000c: add             x1, x1, HEAP, lsl #32
    // 0x1300010: stur            x1, [fp, #-0x48]
    // 0x1300014: LoadField: r2 = r0->field_b
    //     0x1300014: ldur            w2, [x0, #0xb]
    // 0x1300018: DecompressPointer r2
    //     0x1300018: add             x2, x2, HEAP, lsl #32
    // 0x130001c: stur            x2, [fp, #-0x40]
    // 0x1300020: LoadField: r3 = r0->field_f
    //     0x1300020: ldur            w3, [x0, #0xf]
    // 0x1300024: DecompressPointer r3
    //     0x1300024: add             x3, x3, HEAP, lsl #32
    // 0x1300028: stur            x3, [fp, #-0x38]
    // 0x130002c: LoadField: r4 = r0->field_13
    //     0x130002c: ldur            w4, [x0, #0x13]
    // 0x1300030: DecompressPointer r4
    //     0x1300030: add             x4, x4, HEAP, lsl #32
    // 0x1300034: stur            x4, [fp, #-0x30]
    // 0x1300038: r0 = BorderRadius()
    //     0x1300038: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x130003c: mov             x1, x0
    // 0x1300040: ldur            x0, [fp, #-0x48]
    // 0x1300044: StoreField: r1->field_7 = r0
    //     0x1300044: stur            w0, [x1, #7]
    // 0x1300048: ldur            x0, [fp, #-0x40]
    // 0x130004c: StoreField: r1->field_b = r0
    //     0x130004c: stur            w0, [x1, #0xb]
    // 0x1300050: ldur            x0, [fp, #-0x38]
    // 0x1300054: StoreField: r1->field_f = r0
    //     0x1300054: stur            w0, [x1, #0xf]
    // 0x1300058: ldur            x0, [fp, #-0x30]
    // 0x130005c: StoreField: r1->field_13 = r0
    //     0x130005c: stur            w0, [x1, #0x13]
    // 0x1300060: b               #0x130009c
    // 0x1300064: ldur            x2, [fp, #-0x10]
    // 0x1300068: cmp             x1, #0xb89
    // 0x130006c: b.ne            #0x1300078
    // 0x1300070: mov             x1, x0
    // 0x1300074: b               #0x130009c
    // 0x1300078: r1 = LoadClassIdInstr(r0)
    //     0x1300078: ldur            x1, [x0, #-1]
    //     0x130007c: ubfx            x1, x1, #0xc, #0x14
    // 0x1300080: mov             x16, x0
    // 0x1300084: mov             x0, x1
    // 0x1300088: mov             x1, x16
    // 0x130008c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x130008c: sub             lr, x0, #1, lsl #12
    //     0x1300090: ldr             lr, [x21, lr, lsl #3]
    //     0x1300094: blr             lr
    // 0x1300098: mov             x1, x0
    // 0x130009c: ldur            x0, [fp, #-0x20]
    // 0x13000a0: ldur            x2, [fp, #-0x18]
    // 0x13000a4: r0 = toRSuperellipse()
    //     0x13000a4: bl              #0xbfdf88  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRSuperellipse
    // 0x13000a8: mov             x1, x0
    // 0x13000ac: r0 = _native()
    //     0x13000ac: bl              #0xaf867c  ; [dart:ui] RSuperellipse::_native
    // 0x13000b0: mov             x2, x0
    // 0x13000b4: ldur            x0, [fp, #-0x20]
    // 0x13000b8: stur            x2, [fp, #-8]
    // 0x13000bc: LoadField: r1 = r0->field_7
    //     0x13000bc: ldur            w1, [x0, #7]
    // 0x13000c0: DecompressPointer r1
    //     0x13000c0: add             x1, x1, HEAP, lsl #32
    // 0x13000c4: cmp             w1, NULL
    // 0x13000c8: b.eq            #0x130017c
    // 0x13000cc: LoadField: r3 = r1->field_7
    //     0x13000cc: ldur            x3, [x1, #7]
    // 0x13000d0: ldr             x1, [x3]
    // 0x13000d4: cbz             x1, #0x130015c
    // 0x13000d8: mov             x3, x1
    // 0x13000dc: stur            x3, [fp, #-0x28]
    // 0x13000e0: r1 = <Never>
    //     0x13000e0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x13000e4: r0 = Pointer()
    //     0x13000e4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x13000e8: mov             x2, x0
    // 0x13000ec: ldur            x0, [fp, #-0x28]
    // 0x13000f0: stur            x2, [fp, #-0x10]
    // 0x13000f4: StoreField: r2->field_7 = r0
    //     0x13000f4: stur            x0, [x2, #7]
    // 0x13000f8: ldur            x0, [fp, #-8]
    // 0x13000fc: LoadField: r1 = r0->field_7
    //     0x13000fc: ldur            w1, [x0, #7]
    // 0x1300100: DecompressPointer r1
    //     0x1300100: add             x1, x1, HEAP, lsl #32
    // 0x1300104: cmp             w1, NULL
    // 0x1300108: b.eq            #0x1300180
    // 0x130010c: LoadField: r3 = r1->field_7
    //     0x130010c: ldur            x3, [x1, #7]
    // 0x1300110: ldr             x1, [x3]
    // 0x1300114: mov             x3, x1
    // 0x1300118: stur            x3, [fp, #-0x28]
    // 0x130011c: r1 = <Never>
    //     0x130011c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300120: r0 = Pointer()
    //     0x1300120: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300124: mov             x1, x0
    // 0x1300128: ldur            x0, [fp, #-0x28]
    // 0x130012c: StoreField: r1->field_7 = r0
    //     0x130012c: stur            x0, [x1, #7]
    // 0x1300130: mov             x2, x1
    // 0x1300134: ldur            x1, [fp, #-0x10]
    // 0x1300138: r0 = __addRSuperellipse$Method$FfiNative()
    //     0x1300138: bl              #0xbfdeb4  ; [dart:ui] _NativePath::__addRSuperellipse$Method$FfiNative
    // 0x130013c: ldur            x0, [fp, #-0x20]
    // 0x1300140: LeaveFrame
    //     0x1300140: mov             SP, fp
    //     0x1300144: ldp             fp, lr, [SP], #0x10
    // 0x1300148: ret
    //     0x1300148: ret             
    // 0x130014c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x130014c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300150: str             x16, [SP]
    // 0x1300154: r0 = _throwNew()
    //     0x1300154: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300158: brk             #0
    // 0x130015c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x130015c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300160: str             x16, [SP]
    // 0x1300164: r0 = _throwNew()
    //     0x1300164: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300168: brk             #0
    // 0x130016c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130016c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300170: b               #0x12ffeb0
    // 0x1300174: r0 = NullErrorSharedWithFPURegs()
    //     0x1300174: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x1300178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1300178: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x130017c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x130017c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1300180: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300180: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x13016c8, size: 0x54
    // 0x13016c8: EnterFrame
    //     0x13016c8: stp             fp, lr, [SP, #-0x10]!
    //     0x13016cc: mov             fp, SP
    // 0x13016d0: AllocStack(0x10)
    //     0x13016d0: sub             SP, SP, #0x10
    // 0x13016d4: cmp             w2, NULL
    // 0x13016d8: b.ne            #0x13016e8
    // 0x13016dc: LoadField: r0 = r1->field_7
    //     0x13016dc: ldur            w0, [x1, #7]
    // 0x13016e0: DecompressPointer r0
    //     0x13016e0: add             x0, x0, HEAP, lsl #32
    // 0x13016e4: b               #0x13016ec
    // 0x13016e8: mov             x0, x2
    // 0x13016ec: stur            x0, [fp, #-0x10]
    // 0x13016f0: LoadField: r2 = r1->field_b
    //     0x13016f0: ldur            w2, [x1, #0xb]
    // 0x13016f4: DecompressPointer r2
    //     0x13016f4: add             x2, x2, HEAP, lsl #32
    // 0x13016f8: stur            x2, [fp, #-8]
    // 0x13016fc: r0 = RoundedSuperellipseBorder()
    //     0x13016fc: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0x1301700: ldur            x1, [fp, #-8]
    // 0x1301704: StoreField: r0->field_b = r1
    //     0x1301704: stur            w1, [x0, #0xb]
    // 0x1301708: ldur            x1, [fp, #-0x10]
    // 0x130170c: StoreField: r0->field_7 = r1
    //     0x130170c: stur            w1, [x0, #7]
    // 0x1301710: LeaveFrame
    //     0x1301710: mov             SP, fp
    //     0x1301714: ldp             fp, lr, [SP], #0x10
    // 0x1301718: ret
    //     0x1301718: ret             
  }
}

// class id: 3029, size: 0x10, field offset: 0xc
//   const constructor, 
class RoundedRectangleBorder extends _MixinApplication305&OutlinedBorder&_RRectLikeBorder {

  BorderSide field_8;
  BorderRadius field_c;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfd648, size: 0x2e8
    // 0xbfd648: EnterFrame
    //     0xbfd648: stp             fp, lr, [SP, #-0x10]!
    //     0xbfd64c: mov             fp, SP
    // 0xbfd650: AllocStack(0x48)
    //     0xbfd650: sub             SP, SP, #0x48
    // 0xbfd654: SetupParameters(RoundedRectangleBorder this /* r1 => r1, fp-0x28 */, dynamic _ /* r2 => r2, fp-0x30 */, {dynamic textDirection = Null /* r0 */})
    //     0xbfd654: stur            x1, [fp, #-0x28]
    //     0xbfd658: stur            x2, [fp, #-0x30]
    //     0xbfd65c: ldur            w0, [x4, #0x13]
    //     0xbfd660: ldur            w3, [x4, #0x1f]
    //     0xbfd664: add             x3, x3, HEAP, lsl #32
    //     0xbfd668: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xbfd66c: ldr             x16, [x16, #0x210]
    //     0xbfd670: cmp             w3, w16
    //     0xbfd674: b.ne            #0xbfd690
    //     0xbfd678: ldur            w3, [x4, #0x23]
    //     0xbfd67c: add             x3, x3, HEAP, lsl #32
    //     0xbfd680: sub             w4, w0, w3
    //     0xbfd684: add             x0, fp, w4, sxtw #2
    //     0xbfd688: ldr             x0, [x0, #8]
    //     0xbfd68c: b               #0xbfd694
    //     0xbfd690: mov             x0, NULL
    // 0xbfd694: CheckStackOverflow
    //     0xbfd694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfd698: cmp             SP, x16
    //     0xbfd69c: b.ls            #0xbfd920
    // 0xbfd6a0: LoadField: r3 = r1->field_b
    //     0xbfd6a0: ldur            w3, [x1, #0xb]
    // 0xbfd6a4: DecompressPointer r3
    //     0xbfd6a4: add             x3, x3, HEAP, lsl #32
    // 0xbfd6a8: r4 = LoadClassIdInstr(r3)
    //     0xbfd6a8: ldur            x4, [x3, #-1]
    //     0xbfd6ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbfd6b0: cmp             x4, #0xb88
    // 0xbfd6b4: b.ne            #0xbfd784
    // 0xbfd6b8: cmp             w0, NULL
    // 0xbfd6bc: b.eq            #0xbfd928
    // 0xbfd6c0: LoadField: r4 = r0->field_7
    //     0xbfd6c0: ldur            x4, [x0, #7]
    // 0xbfd6c4: cmp             x4, #0
    // 0xbfd6c8: b.gt            #0xbfd728
    // 0xbfd6cc: LoadField: r0 = r3->field_b
    //     0xbfd6cc: ldur            w0, [x3, #0xb]
    // 0xbfd6d0: DecompressPointer r0
    //     0xbfd6d0: add             x0, x0, HEAP, lsl #32
    // 0xbfd6d4: stur            x0, [fp, #-0x20]
    // 0xbfd6d8: LoadField: r4 = r3->field_7
    //     0xbfd6d8: ldur            w4, [x3, #7]
    // 0xbfd6dc: DecompressPointer r4
    //     0xbfd6dc: add             x4, x4, HEAP, lsl #32
    // 0xbfd6e0: stur            x4, [fp, #-0x18]
    // 0xbfd6e4: LoadField: r5 = r3->field_13
    //     0xbfd6e4: ldur            w5, [x3, #0x13]
    // 0xbfd6e8: DecompressPointer r5
    //     0xbfd6e8: add             x5, x5, HEAP, lsl #32
    // 0xbfd6ec: stur            x5, [fp, #-0x10]
    // 0xbfd6f0: LoadField: r6 = r3->field_f
    //     0xbfd6f0: ldur            w6, [x3, #0xf]
    // 0xbfd6f4: DecompressPointer r6
    //     0xbfd6f4: add             x6, x6, HEAP, lsl #32
    // 0xbfd6f8: stur            x6, [fp, #-8]
    // 0xbfd6fc: r0 = BorderRadius()
    //     0xbfd6fc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfd700: mov             x1, x0
    // 0xbfd704: ldur            x0, [fp, #-0x20]
    // 0xbfd708: StoreField: r1->field_7 = r0
    //     0xbfd708: stur            w0, [x1, #7]
    // 0xbfd70c: ldur            x0, [fp, #-0x18]
    // 0xbfd710: StoreField: r1->field_b = r0
    //     0xbfd710: stur            w0, [x1, #0xb]
    // 0xbfd714: ldur            x0, [fp, #-0x10]
    // 0xbfd718: StoreField: r1->field_f = r0
    //     0xbfd718: stur            w0, [x1, #0xf]
    // 0xbfd71c: ldur            x0, [fp, #-8]
    // 0xbfd720: StoreField: r1->field_13 = r0
    //     0xbfd720: stur            w0, [x1, #0x13]
    // 0xbfd724: b               #0xbfd7b8
    // 0xbfd728: LoadField: r0 = r3->field_7
    //     0xbfd728: ldur            w0, [x3, #7]
    // 0xbfd72c: DecompressPointer r0
    //     0xbfd72c: add             x0, x0, HEAP, lsl #32
    // 0xbfd730: stur            x0, [fp, #-0x20]
    // 0xbfd734: LoadField: r1 = r3->field_b
    //     0xbfd734: ldur            w1, [x3, #0xb]
    // 0xbfd738: DecompressPointer r1
    //     0xbfd738: add             x1, x1, HEAP, lsl #32
    // 0xbfd73c: stur            x1, [fp, #-0x18]
    // 0xbfd740: LoadField: r2 = r3->field_f
    //     0xbfd740: ldur            w2, [x3, #0xf]
    // 0xbfd744: DecompressPointer r2
    //     0xbfd744: add             x2, x2, HEAP, lsl #32
    // 0xbfd748: stur            x2, [fp, #-0x10]
    // 0xbfd74c: LoadField: r4 = r3->field_13
    //     0xbfd74c: ldur            w4, [x3, #0x13]
    // 0xbfd750: DecompressPointer r4
    //     0xbfd750: add             x4, x4, HEAP, lsl #32
    // 0xbfd754: stur            x4, [fp, #-8]
    // 0xbfd758: r0 = BorderRadius()
    //     0xbfd758: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbfd75c: mov             x1, x0
    // 0xbfd760: ldur            x0, [fp, #-0x20]
    // 0xbfd764: StoreField: r1->field_7 = r0
    //     0xbfd764: stur            w0, [x1, #7]
    // 0xbfd768: ldur            x0, [fp, #-0x18]
    // 0xbfd76c: StoreField: r1->field_b = r0
    //     0xbfd76c: stur            w0, [x1, #0xb]
    // 0xbfd770: ldur            x0, [fp, #-0x10]
    // 0xbfd774: StoreField: r1->field_f = r0
    //     0xbfd774: stur            w0, [x1, #0xf]
    // 0xbfd778: ldur            x0, [fp, #-8]
    // 0xbfd77c: StoreField: r1->field_13 = r0
    //     0xbfd77c: stur            w0, [x1, #0x13]
    // 0xbfd780: b               #0xbfd7b8
    // 0xbfd784: cmp             x4, #0xb89
    // 0xbfd788: b.ne            #0xbfd794
    // 0xbfd78c: mov             x1, x3
    // 0xbfd790: b               #0xbfd7b8
    // 0xbfd794: r1 = LoadClassIdInstr(r3)
    //     0xbfd794: ldur            x1, [x3, #-1]
    //     0xbfd798: ubfx            x1, x1, #0xc, #0x14
    // 0xbfd79c: mov             x2, x0
    // 0xbfd7a0: mov             x0, x1
    // 0xbfd7a4: mov             x1, x3
    // 0xbfd7a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbfd7a8: sub             lr, x0, #1, lsl #12
    //     0xbfd7ac: ldr             lr, [x21, lr, lsl #3]
    //     0xbfd7b0: blr             lr
    // 0xbfd7b4: mov             x1, x0
    // 0xbfd7b8: ldur            x0, [fp, #-0x28]
    // 0xbfd7bc: ldur            x2, [fp, #-0x30]
    // 0xbfd7c0: r0 = toRRect()
    //     0xbfd7c0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbfd7c4: mov             x1, x0
    // 0xbfd7c8: ldur            x0, [fp, #-0x28]
    // 0xbfd7cc: LoadField: r2 = r0->field_7
    //     0xbfd7cc: ldur            w2, [x0, #7]
    // 0xbfd7d0: DecompressPointer r2
    //     0xbfd7d0: add             x2, x2, HEAP, lsl #32
    // 0xbfd7d4: LoadField: d0 = r2->field_b
    //     0xbfd7d4: ldur            d0, [x2, #0xb]
    // 0xbfd7d8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbfd7d8: ldur            d1, [x2, #0x17]
    // 0xbfd7dc: d2 = 1.000000
    //     0xbfd7dc: fmov            d2, #1.00000000
    // 0xbfd7e0: fadd            d3, d1, d2
    // 0xbfd7e4: d1 = 2.000000
    //     0xbfd7e4: fmov            d1, #2.00000000
    // 0xbfd7e8: fdiv            d4, d3, d1
    // 0xbfd7ec: fsub            d1, d2, d4
    // 0xbfd7f0: fmul            d2, d0, d1
    // 0xbfd7f4: mov             v0.16b, v2.16b
    // 0xbfd7f8: r0 = deflate()
    //     0xbfd7f8: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbfd7fc: stur            x0, [fp, #-8]
    // 0xbfd800: r0 = _NativePath()
    //     0xbfd800: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfd804: mov             x1, x0
    // 0xbfd808: stur            x0, [fp, #-0x10]
    // 0xbfd80c: r0 = __constructor$Method$FfiNative()
    //     0xbfd80c: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfd810: ldur            x0, [fp, #-8]
    // 0xbfd814: LoadField: d0 = r0->field_b
    //     0xbfd814: ldur            d0, [x0, #0xb]
    // 0xbfd818: fcvt            s1, d0
    // 0xbfd81c: stur            d1, [fp, #-0x40]
    // 0xbfd820: r4 = 24
    //     0xbfd820: mov             x4, #0x18
    // 0xbfd824: r0 = AllocateFloat32Array()
    //     0xbfd824: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbfd828: ldur            d0, [fp, #-0x40]
    // 0xbfd82c: stur            x0, [fp, #-0x18]
    // 0xbfd830: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfd830: stur            s0, [x0, #0x17]
    // 0xbfd834: ldur            x1, [fp, #-8]
    // 0xbfd838: LoadField: d0 = r1->field_13
    //     0xbfd838: ldur            d0, [x1, #0x13]
    // 0xbfd83c: fcvt            s1, d0
    // 0xbfd840: StoreField: r0->field_1b = d1
    //     0xbfd840: stur            s1, [x0, #0x1b]
    // 0xbfd844: LoadField: d0 = r1->field_1b
    //     0xbfd844: ldur            d0, [x1, #0x1b]
    // 0xbfd848: fcvt            s1, d0
    // 0xbfd84c: StoreField: r0->field_1f = d1
    //     0xbfd84c: stur            s1, [x0, #0x1f]
    // 0xbfd850: LoadField: d0 = r1->field_23
    //     0xbfd850: ldur            d0, [x1, #0x23]
    // 0xbfd854: fcvt            s1, d0
    // 0xbfd858: StoreField: r0->field_23 = d1
    //     0xbfd858: stur            s1, [x0, #0x23]
    // 0xbfd85c: LoadField: d0 = r1->field_2b
    //     0xbfd85c: ldur            d0, [x1, #0x2b]
    // 0xbfd860: fcvt            s1, d0
    // 0xbfd864: StoreField: r0->field_27 = d1
    //     0xbfd864: stur            s1, [x0, #0x27]
    // 0xbfd868: LoadField: d0 = r1->field_33
    //     0xbfd868: ldur            d0, [x1, #0x33]
    // 0xbfd86c: fcvt            s1, d0
    // 0xbfd870: StoreField: r0->field_2b = d1
    //     0xbfd870: stur            s1, [x0, #0x2b]
    // 0xbfd874: LoadField: d0 = r1->field_3b
    //     0xbfd874: ldur            d0, [x1, #0x3b]
    // 0xbfd878: fcvt            s1, d0
    // 0xbfd87c: StoreField: r0->field_2f = d1
    //     0xbfd87c: stur            s1, [x0, #0x2f]
    // 0xbfd880: LoadField: d0 = r1->field_43
    //     0xbfd880: ldur            d0, [x1, #0x43]
    // 0xbfd884: fcvt            s1, d0
    // 0xbfd888: StoreField: r0->field_33 = d1
    //     0xbfd888: stur            s1, [x0, #0x33]
    // 0xbfd88c: LoadField: d0 = r1->field_4b
    //     0xbfd88c: ldur            d0, [x1, #0x4b]
    // 0xbfd890: fcvt            s1, d0
    // 0xbfd894: StoreField: r0->field_37 = d1
    //     0xbfd894: stur            s1, [x0, #0x37]
    // 0xbfd898: LoadField: d0 = r1->field_53
    //     0xbfd898: ldur            d0, [x1, #0x53]
    // 0xbfd89c: fcvt            s1, d0
    // 0xbfd8a0: StoreField: r0->field_3b = d1
    //     0xbfd8a0: stur            s1, [x0, #0x3b]
    // 0xbfd8a4: LoadField: d0 = r1->field_5b
    //     0xbfd8a4: ldur            d0, [x1, #0x5b]
    // 0xbfd8a8: fcvt            s1, d0
    // 0xbfd8ac: StoreField: r0->field_3f = d1
    //     0xbfd8ac: stur            s1, [x0, #0x3f]
    // 0xbfd8b0: LoadField: d0 = r1->field_63
    //     0xbfd8b0: ldur            d0, [x1, #0x63]
    // 0xbfd8b4: fcvt            s1, d0
    // 0xbfd8b8: StoreField: r0->field_43 = d1
    //     0xbfd8b8: stur            s1, [x0, #0x43]
    // 0xbfd8bc: ldur            x2, [fp, #-0x10]
    // 0xbfd8c0: LoadField: r1 = r2->field_7
    //     0xbfd8c0: ldur            w1, [x2, #7]
    // 0xbfd8c4: DecompressPointer r1
    //     0xbfd8c4: add             x1, x1, HEAP, lsl #32
    // 0xbfd8c8: cmp             w1, NULL
    // 0xbfd8cc: b.eq            #0xbfd92c
    // 0xbfd8d0: LoadField: r3 = r1->field_7
    //     0xbfd8d0: ldur            x3, [x1, #7]
    // 0xbfd8d4: ldr             x1, [x3]
    // 0xbfd8d8: cbz             x1, #0xbfd910
    // 0xbfd8dc: mov             x3, x1
    // 0xbfd8e0: stur            x3, [fp, #-0x38]
    // 0xbfd8e4: r1 = <Never>
    //     0xbfd8e4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfd8e8: r0 = Pointer()
    //     0xbfd8e8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfd8ec: mov             x1, x0
    // 0xbfd8f0: ldur            x0, [fp, #-0x38]
    // 0xbfd8f4: StoreField: r1->field_7 = r0
    //     0xbfd8f4: stur            x0, [x1, #7]
    // 0xbfd8f8: ldur            x2, [fp, #-0x18]
    // 0xbfd8fc: r0 = __addRRect$Method$FfiNative()
    //     0xbfd8fc: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbfd900: ldur            x0, [fp, #-0x10]
    // 0xbfd904: LeaveFrame
    //     0xbfd904: mov             SP, fp
    //     0xbfd908: ldp             fp, lr, [SP], #0x10
    // 0xbfd90c: ret
    //     0xbfd90c: ret             
    // 0xbfd910: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfd910: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfd914: str             x16, [SP]
    // 0xbfd918: r0 = _throwNew()
    //     0xbfd918: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfd91c: brk             #0
    // 0xbfd920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfd920: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfd924: b               #0xbfd6a0
    // 0xbfd928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfd928: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfd92c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfd92c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static RoundedRectangleBorder RoundedRectangleBorder(dynamic, {BorderSide side, BorderRadiusGeometry borderRadius}) {
    // ** addr: 0xde2f8c, size: 0xcc
    // 0xde2f8c: EnterFrame
    //     0xde2f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xde2f90: mov             fp, SP
    // 0xde2f94: AllocStack(0x10)
    //     0xde2f94: sub             SP, SP, #0x10
    // 0xde2f98: SetupParameters({dynamic borderRadius = Instance_BorderRadius /* r2, fp-0x10 */, dynamic side = Instance_BorderSide /* r0, fp-0x8 */})
    //     0xde2f98: ldur            w0, [x4, #0x13]
    //     0xde2f9c: ldur            w1, [x4, #0x1f]
    //     0xde2fa0: add             x1, x1, HEAP, lsl #32
    //     0xde2fa4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d00] "borderRadius"
    //     0xde2fa8: ldr             x16, [x16, #0xd00]
    //     0xde2fac: cmp             w1, w16
    //     0xde2fb0: b.ne            #0xde2fd4
    //     0xde2fb4: ldur            w1, [x4, #0x23]
    //     0xde2fb8: add             x1, x1, HEAP, lsl #32
    //     0xde2fbc: sub             w2, w0, w1
    //     0xde2fc0: add             x1, fp, w2, sxtw #2
    //     0xde2fc4: ldr             x1, [x1, #8]
    //     0xde2fc8: mov             x2, x1
    //     0xde2fcc: mov             x1, #1
    //     0xde2fd0: b               #0xde2fe0
    //     0xde2fd4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xde2fd8: ldr             x2, [x2, #0x508]
    //     0xde2fdc: mov             x1, #0
    //     0xde2fe0: stur            x2, [fp, #-0x10]
    //     0xde2fe4: lsl             x3, x1, #1
    //     0xde2fe8: lsl             w1, w3, #1
    //     0xde2fec: add             w3, w1, #8
    //     0xde2ff0: add             x16, x4, w3, sxtw #1
    //     0xde2ff4: ldur            w5, [x16, #0xf]
    //     0xde2ff8: add             x5, x5, HEAP, lsl #32
    //     0xde2ffc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c88] "side"
    //     0xde3000: ldr             x16, [x16, #0xc88]
    //     0xde3004: cmp             w5, w16
    //     0xde3008: b.ne            #0xde302c
    //     0xde300c: add             w3, w1, #0xa
    //     0xde3010: add             x16, x4, w3, sxtw #1
    //     0xde3014: ldur            w1, [x16, #0xf]
    //     0xde3018: add             x1, x1, HEAP, lsl #32
    //     0xde301c: sub             w3, w0, w1
    //     0xde3020: add             x0, fp, w3, sxtw #2
    //     0xde3024: ldr             x0, [x0, #8]
    //     0xde3028: b               #0xde3034
    //     0xde302c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xde3030: ldr             x0, [x0, #0x310]
    //     0xde3034: stur            x0, [fp, #-8]
    // 0xde3038: r0 = RoundedRectangleBorder()
    //     0xde3038: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xde303c: ldur            x1, [fp, #-0x10]
    // 0xde3040: StoreField: r0->field_b = r1
    //     0xde3040: stur            w1, [x0, #0xb]
    // 0xde3044: ldur            x1, [fp, #-8]
    // 0xde3048: StoreField: r0->field_7 = r1
    //     0xde3048: stur            w1, [x0, #7]
    // 0xde304c: LeaveFrame
    //     0xde304c: mov             SP, fp
    //     0xde3050: ldp             fp, lr, [SP], #0x10
    // 0xde3054: ret
    //     0xde3054: ret             
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ed190, size: 0x178
    // 0x10ed190: EnterFrame
    //     0x10ed190: stp             fp, lr, [SP, #-0x10]!
    //     0x10ed194: mov             fp, SP
    // 0x10ed198: AllocStack(0x38)
    //     0x10ed198: sub             SP, SP, #0x38
    // 0x10ed19c: SetupParameters(RoundedRectangleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10ed19c: mov             x3, x1
    //     0x10ed1a0: mov             x0, x2
    //     0x10ed1a4: mov             v1.16b, v0.16b
    //     0x10ed1a8: stur            x1, [fp, #-8]
    //     0x10ed1ac: stur            x2, [fp, #-0x10]
    //     0x10ed1b0: stur            d0, [fp, #-0x28]
    // 0x10ed1b4: CheckStackOverflow
    //     0x10ed1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ed1b8: cmp             SP, x16
    //     0x10ed1bc: b.ls            #0x10ed300
    // 0x10ed1c0: r1 = LoadClassIdInstr(r0)
    //     0x10ed1c0: ldur            x1, [x0, #-1]
    //     0x10ed1c4: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed1c8: cmp             x1, #0xbd5
    // 0x10ed1cc: b.ne            #0x10ed23c
    // 0x10ed1d0: LoadField: r1 = r0->field_7
    //     0x10ed1d0: ldur            w1, [x0, #7]
    // 0x10ed1d4: DecompressPointer r1
    //     0x10ed1d4: add             x1, x1, HEAP, lsl #32
    // 0x10ed1d8: LoadField: r2 = r3->field_7
    //     0x10ed1d8: ldur            w2, [x3, #7]
    // 0x10ed1dc: DecompressPointer r2
    //     0x10ed1dc: add             x2, x2, HEAP, lsl #32
    // 0x10ed1e0: mov             v0.16b, v1.16b
    // 0x10ed1e4: r0 = lerp()
    //     0x10ed1e4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed1e8: mov             x3, x0
    // 0x10ed1ec: ldur            x0, [fp, #-0x10]
    // 0x10ed1f0: stur            x3, [fp, #-0x18]
    // 0x10ed1f4: LoadField: r1 = r0->field_b
    //     0x10ed1f4: ldur            w1, [x0, #0xb]
    // 0x10ed1f8: DecompressPointer r1
    //     0x10ed1f8: add             x1, x1, HEAP, lsl #32
    // 0x10ed1fc: ldur            x4, [fp, #-8]
    // 0x10ed200: LoadField: r2 = r4->field_b
    //     0x10ed200: ldur            w2, [x4, #0xb]
    // 0x10ed204: DecompressPointer r2
    //     0x10ed204: add             x2, x2, HEAP, lsl #32
    // 0x10ed208: ldur            d0, [fp, #-0x28]
    // 0x10ed20c: r0 = lerp()
    //     0x10ed20c: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10ed210: stur            x0, [fp, #-0x20]
    // 0x10ed214: r0 = RoundedRectangleBorder()
    //     0x10ed214: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x10ed218: mov             x1, x0
    // 0x10ed21c: ldur            x0, [fp, #-0x20]
    // 0x10ed220: StoreField: r1->field_b = r0
    //     0x10ed220: stur            w0, [x1, #0xb]
    // 0x10ed224: ldur            x0, [fp, #-0x18]
    // 0x10ed228: StoreField: r1->field_7 = r0
    //     0x10ed228: stur            w0, [x1, #7]
    // 0x10ed22c: mov             x0, x1
    // 0x10ed230: LeaveFrame
    //     0x10ed230: mov             SP, fp
    //     0x10ed234: ldp             fp, lr, [SP], #0x10
    // 0x10ed238: ret
    //     0x10ed238: ret             
    // 0x10ed23c: mov             x4, x3
    // 0x10ed240: cmp             x1, #0xbd2
    // 0x10ed244: b.ne            #0x10ed2d4
    // 0x10ed248: ldur            d1, [fp, #-0x28]
    // 0x10ed24c: LoadField: r1 = r0->field_7
    //     0x10ed24c: ldur            w1, [x0, #7]
    // 0x10ed250: DecompressPointer r1
    //     0x10ed250: add             x1, x1, HEAP, lsl #32
    // 0x10ed254: LoadField: r2 = r4->field_7
    //     0x10ed254: ldur            w2, [x4, #7]
    // 0x10ed258: DecompressPointer r2
    //     0x10ed258: add             x2, x2, HEAP, lsl #32
    // 0x10ed25c: mov             v0.16b, v1.16b
    // 0x10ed260: r0 = lerp()
    //     0x10ed260: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ed264: ldur            x1, [fp, #-8]
    // 0x10ed268: stur            x0, [fp, #-0x20]
    // 0x10ed26c: LoadField: r2 = r1->field_b
    //     0x10ed26c: ldur            w2, [x1, #0xb]
    // 0x10ed270: DecompressPointer r2
    //     0x10ed270: add             x2, x2, HEAP, lsl #32
    // 0x10ed274: ldur            d0, [fp, #-0x28]
    // 0x10ed278: stur            x2, [fp, #-0x18]
    // 0x10ed27c: d1 = 1.000000
    //     0x10ed27c: fmov            d1, #1.00000000
    // 0x10ed280: fsub            d2, d1, d0
    // 0x10ed284: ldur            x3, [fp, #-0x10]
    // 0x10ed288: stur            d2, [fp, #-0x38]
    // 0x10ed28c: LoadField: d0 = r3->field_b
    //     0x10ed28c: ldur            d0, [x3, #0xb]
    // 0x10ed290: stur            d0, [fp, #-0x30]
    // 0x10ed294: r1 = <RoundedRectangleBorder>
    //     0x10ed294: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10ed298: ldr             x1, [x1, #0xd90]
    // 0x10ed29c: r0 = _RoundedRectangleToCircleBorder()
    //     0x10ed29c: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10ed2a0: mov             x1, x0
    // 0x10ed2a4: ldur            x0, [fp, #-0x18]
    // 0x10ed2a8: StoreField: r1->field_f = r0
    //     0x10ed2a8: stur            w0, [x1, #0xf]
    // 0x10ed2ac: ldur            d0, [fp, #-0x38]
    // 0x10ed2b0: StoreField: r1->field_13 = d0
    //     0x10ed2b0: stur            d0, [x1, #0x13]
    // 0x10ed2b4: ldur            d0, [fp, #-0x30]
    // 0x10ed2b8: StoreField: r1->field_1b = d0
    //     0x10ed2b8: stur            d0, [x1, #0x1b]
    // 0x10ed2bc: ldur            x0, [fp, #-0x20]
    // 0x10ed2c0: StoreField: r1->field_7 = r0
    //     0x10ed2c0: stur            w0, [x1, #7]
    // 0x10ed2c4: mov             x0, x1
    // 0x10ed2c8: LeaveFrame
    //     0x10ed2c8: mov             SP, fp
    //     0x10ed2cc: ldp             fp, lr, [SP], #0x10
    // 0x10ed2d0: ret
    //     0x10ed2d0: ret             
    // 0x10ed2d4: mov             x1, x4
    // 0x10ed2d8: mov             x3, x0
    // 0x10ed2dc: ldur            d0, [fp, #-0x28]
    // 0x10ed2e0: cmp             w3, NULL
    // 0x10ed2e4: b.ne            #0x10ed2f0
    // 0x10ed2e8: r0 = scale()
    //     0x10ed2e8: bl              #0x12fc428  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::scale
    // 0x10ed2ec: b               #0x10ed2f4
    // 0x10ed2f0: r0 = Null
    //     0x10ed2f0: mov             x0, NULL
    // 0x10ed2f4: LeaveFrame
    //     0x10ed2f4: mov             SP, fp
    //     0x10ed2f8: ldp             fp, lr, [SP], #0x10
    // 0x10ed2fc: ret
    //     0x10ed2fc: ret             
    // 0x10ed300: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ed300: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ed304: b               #0x10ed1c0
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f036c, size: 0x160
    // 0x10f036c: EnterFrame
    //     0x10f036c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0370: mov             fp, SP
    // 0x10f0374: AllocStack(0x30)
    //     0x10f0374: sub             SP, SP, #0x30
    // 0x10f0378: SetupParameters(RoundedRectangleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x10f0378: mov             x3, x1
    //     0x10f037c: mov             x0, x2
    //     0x10f0380: mov             v1.16b, v0.16b
    //     0x10f0384: stur            x1, [fp, #-8]
    //     0x10f0388: stur            x2, [fp, #-0x10]
    //     0x10f038c: stur            d0, [fp, #-0x28]
    // 0x10f0390: CheckStackOverflow
    //     0x10f0390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f0394: cmp             SP, x16
    //     0x10f0398: b.ls            #0x10f04c4
    // 0x10f039c: r1 = LoadClassIdInstr(r0)
    //     0x10f039c: ldur            x1, [x0, #-1]
    //     0x10f03a0: ubfx            x1, x1, #0xc, #0x14
    // 0x10f03a4: cmp             x1, #0xbd5
    // 0x10f03a8: b.ne            #0x10f0418
    // 0x10f03ac: LoadField: r1 = r3->field_7
    //     0x10f03ac: ldur            w1, [x3, #7]
    // 0x10f03b0: DecompressPointer r1
    //     0x10f03b0: add             x1, x1, HEAP, lsl #32
    // 0x10f03b4: LoadField: r2 = r0->field_7
    //     0x10f03b4: ldur            w2, [x0, #7]
    // 0x10f03b8: DecompressPointer r2
    //     0x10f03b8: add             x2, x2, HEAP, lsl #32
    // 0x10f03bc: mov             v0.16b, v1.16b
    // 0x10f03c0: r0 = lerp()
    //     0x10f03c0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f03c4: mov             x3, x0
    // 0x10f03c8: ldur            x0, [fp, #-8]
    // 0x10f03cc: stur            x3, [fp, #-0x18]
    // 0x10f03d0: LoadField: r1 = r0->field_b
    //     0x10f03d0: ldur            w1, [x0, #0xb]
    // 0x10f03d4: DecompressPointer r1
    //     0x10f03d4: add             x1, x1, HEAP, lsl #32
    // 0x10f03d8: ldur            x4, [fp, #-0x10]
    // 0x10f03dc: LoadField: r2 = r4->field_b
    //     0x10f03dc: ldur            w2, [x4, #0xb]
    // 0x10f03e0: DecompressPointer r2
    //     0x10f03e0: add             x2, x2, HEAP, lsl #32
    // 0x10f03e4: ldur            d0, [fp, #-0x28]
    // 0x10f03e8: r0 = lerp()
    //     0x10f03e8: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10f03ec: stur            x0, [fp, #-0x20]
    // 0x10f03f0: r0 = RoundedRectangleBorder()
    //     0x10f03f0: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x10f03f4: mov             x1, x0
    // 0x10f03f8: ldur            x0, [fp, #-0x20]
    // 0x10f03fc: StoreField: r1->field_b = r0
    //     0x10f03fc: stur            w0, [x1, #0xb]
    // 0x10f0400: ldur            x0, [fp, #-0x18]
    // 0x10f0404: StoreField: r1->field_7 = r0
    //     0x10f0404: stur            w0, [x1, #7]
    // 0x10f0408: mov             x0, x1
    // 0x10f040c: LeaveFrame
    //     0x10f040c: mov             SP, fp
    //     0x10f0410: ldp             fp, lr, [SP], #0x10
    // 0x10f0414: ret
    //     0x10f0414: ret             
    // 0x10f0418: mov             x4, x0
    // 0x10f041c: mov             x0, x3
    // 0x10f0420: cmp             x1, #0xbd2
    // 0x10f0424: b.ne            #0x10f04a4
    // 0x10f0428: ldur            d1, [fp, #-0x28]
    // 0x10f042c: LoadField: r1 = r0->field_7
    //     0x10f042c: ldur            w1, [x0, #7]
    // 0x10f0430: DecompressPointer r1
    //     0x10f0430: add             x1, x1, HEAP, lsl #32
    // 0x10f0434: LoadField: r2 = r4->field_7
    //     0x10f0434: ldur            w2, [x4, #7]
    // 0x10f0438: DecompressPointer r2
    //     0x10f0438: add             x2, x2, HEAP, lsl #32
    // 0x10f043c: mov             v0.16b, v1.16b
    // 0x10f0440: r0 = lerp()
    //     0x10f0440: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0444: ldur            x1, [fp, #-8]
    // 0x10f0448: stur            x0, [fp, #-0x20]
    // 0x10f044c: LoadField: r2 = r1->field_b
    //     0x10f044c: ldur            w2, [x1, #0xb]
    // 0x10f0450: DecompressPointer r2
    //     0x10f0450: add             x2, x2, HEAP, lsl #32
    // 0x10f0454: ldur            x3, [fp, #-0x10]
    // 0x10f0458: stur            x2, [fp, #-0x18]
    // 0x10f045c: LoadField: d0 = r3->field_b
    //     0x10f045c: ldur            d0, [x3, #0xb]
    // 0x10f0460: stur            d0, [fp, #-0x30]
    // 0x10f0464: r1 = <RoundedRectangleBorder>
    //     0x10f0464: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2d90] TypeArguments: <RoundedRectangleBorder>
    //     0x10f0468: ldr             x1, [x1, #0xd90]
    // 0x10f046c: r0 = _RoundedRectangleToCircleBorder()
    //     0x10f046c: bl              #0x10ed308  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x24)
    // 0x10f0470: mov             x1, x0
    // 0x10f0474: ldur            x0, [fp, #-0x18]
    // 0x10f0478: StoreField: r1->field_f = r0
    //     0x10f0478: stur            w0, [x1, #0xf]
    // 0x10f047c: ldur            d0, [fp, #-0x28]
    // 0x10f0480: StoreField: r1->field_13 = d0
    //     0x10f0480: stur            d0, [x1, #0x13]
    // 0x10f0484: ldur            d0, [fp, #-0x30]
    // 0x10f0488: StoreField: r1->field_1b = d0
    //     0x10f0488: stur            d0, [x1, #0x1b]
    // 0x10f048c: ldur            x0, [fp, #-0x20]
    // 0x10f0490: StoreField: r1->field_7 = r0
    //     0x10f0490: stur            w0, [x1, #7]
    // 0x10f0494: mov             x0, x1
    // 0x10f0498: LeaveFrame
    //     0x10f0498: mov             SP, fp
    //     0x10f049c: ldp             fp, lr, [SP], #0x10
    // 0x10f04a0: ret
    //     0x10f04a0: ret             
    // 0x10f04a4: mov             x1, x0
    // 0x10f04a8: mov             x3, x4
    // 0x10f04ac: ldur            d0, [fp, #-0x28]
    // 0x10f04b0: mov             x2, x3
    // 0x10f04b4: r0 = lerpTo()
    //     0x10f04b4: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f04b8: LeaveFrame
    //     0x10f04b8: mov             SP, fp
    //     0x10f04bc: ldp             fp, lr, [SP], #0x10
    // 0x10f04c0: ret
    //     0x10f04c0: ret             
    // 0x10f04c4: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f04c4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f04c8: b               #0x10f039c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1295ee4, size: 0xec
    // 0x1295ee4: EnterFrame
    //     0x1295ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x1295ee8: mov             fp, SP
    // 0x1295eec: AllocStack(0x10)
    //     0x1295eec: sub             SP, SP, #0x10
    // 0x1295ef0: CheckStackOverflow
    //     0x1295ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1295ef4: cmp             SP, x16
    //     0x1295ef8: b.ls            #0x1295fc8
    // 0x1295efc: ldr             x0, [fp, #0x10]
    // 0x1295f00: cmp             w0, NULL
    // 0x1295f04: b.ne            #0x1295f18
    // 0x1295f08: r0 = false
    //     0x1295f08: add             x0, NULL, #0x30  ; false
    // 0x1295f0c: LeaveFrame
    //     0x1295f0c: mov             SP, fp
    //     0x1295f10: ldp             fp, lr, [SP], #0x10
    // 0x1295f14: ret
    //     0x1295f14: ret             
    // 0x1295f18: str             x0, [SP]
    // 0x1295f1c: r0 = runtimeType()
    //     0x1295f1c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1295f20: r1 = LoadClassIdInstr(r0)
    //     0x1295f20: ldur            x1, [x0, #-1]
    //     0x1295f24: ubfx            x1, x1, #0xc, #0x14
    // 0x1295f28: r16 = RoundedRectangleBorder
    //     0x1295f28: add             x16, PP, #0x26, lsl #12  ; [pp+0x26530] Type: RoundedRectangleBorder
    //     0x1295f2c: ldr             x16, [x16, #0x530]
    // 0x1295f30: stp             x16, x0, [SP]
    // 0x1295f34: mov             x0, x1
    // 0x1295f38: mov             lr, x0
    // 0x1295f3c: ldr             lr, [x21, lr, lsl #3]
    // 0x1295f40: blr             lr
    // 0x1295f44: tbz             w0, #4, #0x1295f58
    // 0x1295f48: r0 = false
    //     0x1295f48: add             x0, NULL, #0x30  ; false
    // 0x1295f4c: LeaveFrame
    //     0x1295f4c: mov             SP, fp
    //     0x1295f50: ldp             fp, lr, [SP], #0x10
    // 0x1295f54: ret
    //     0x1295f54: ret             
    // 0x1295f58: ldr             x0, [fp, #0x10]
    // 0x1295f5c: r1 = 60
    //     0x1295f5c: mov             x1, #0x3c
    // 0x1295f60: branchIfSmi(r0, 0x1295f6c)
    //     0x1295f60: tbz             w0, #0, #0x1295f6c
    // 0x1295f64: r1 = LoadClassIdInstr(r0)
    //     0x1295f64: ldur            x1, [x0, #-1]
    //     0x1295f68: ubfx            x1, x1, #0xc, #0x14
    // 0x1295f6c: cmp             x1, #0xbd5
    // 0x1295f70: b.ne            #0x1295fb8
    // 0x1295f74: ldr             x1, [fp, #0x18]
    // 0x1295f78: LoadField: r2 = r0->field_7
    //     0x1295f78: ldur            w2, [x0, #7]
    // 0x1295f7c: DecompressPointer r2
    //     0x1295f7c: add             x2, x2, HEAP, lsl #32
    // 0x1295f80: LoadField: r3 = r1->field_7
    //     0x1295f80: ldur            w3, [x1, #7]
    // 0x1295f84: DecompressPointer r3
    //     0x1295f84: add             x3, x3, HEAP, lsl #32
    // 0x1295f88: stp             x3, x2, [SP]
    // 0x1295f8c: r0 = ==()
    //     0x1295f8c: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1295f90: tbnz            w0, #4, #0x1295fb8
    // 0x1295f94: ldr             x1, [fp, #0x18]
    // 0x1295f98: ldr             x0, [fp, #0x10]
    // 0x1295f9c: LoadField: r2 = r0->field_b
    //     0x1295f9c: ldur            w2, [x0, #0xb]
    // 0x1295fa0: DecompressPointer r2
    //     0x1295fa0: add             x2, x2, HEAP, lsl #32
    // 0x1295fa4: LoadField: r0 = r1->field_b
    //     0x1295fa4: ldur            w0, [x1, #0xb]
    // 0x1295fa8: DecompressPointer r0
    //     0x1295fa8: add             x0, x0, HEAP, lsl #32
    // 0x1295fac: stp             x0, x2, [SP]
    // 0x1295fb0: r0 = ==()
    //     0x1295fb0: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x1295fb4: b               #0x1295fbc
    // 0x1295fb8: r0 = false
    //     0x1295fb8: add             x0, NULL, #0x30  ; false
    // 0x1295fbc: LeaveFrame
    //     0x1295fbc: mov             SP, fp
    //     0x1295fc0: ldp             fp, lr, [SP], #0x10
    // 0x1295fc4: ret
    //     0x1295fc4: ret             
    // 0x1295fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1295fc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1295fcc: b               #0x1295efc
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ebae0, size: 0x1f8
    // 0x12ebae0: EnterFrame
    //     0x12ebae0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ebae4: mov             fp, SP
    // 0x12ebae8: AllocStack(0x58)
    //     0x12ebae8: sub             SP, SP, #0x58
    // 0x12ebaec: SetupParameters(RoundedRectangleBorder this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */, {dynamic textDirection = Null /* r4, fp-0x10 */})
    //     0x12ebaec: mov             x0, x1
    //     0x12ebaf0: mov             x1, x2
    //     0x12ebaf4: stur            x2, [fp, #-0x18]
    //     0x12ebaf8: mov             x2, x3
    //     0x12ebafc: stur            x3, [fp, #-0x20]
    //     0x12ebb00: mov             x3, x5
    //     0x12ebb04: stur            x5, [fp, #-0x28]
    //     0x12ebb08: ldur            w5, [x4, #0x13]
    //     0x12ebb0c: ldur            w6, [x4, #0x1f]
    //     0x12ebb10: add             x6, x6, HEAP, lsl #32
    //     0x12ebb14: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ebb18: ldr             x16, [x16, #0x210]
    //     0x12ebb1c: cmp             w6, w16
    //     0x12ebb20: b.ne            #0x12ebb40
    //     0x12ebb24: ldur            w6, [x4, #0x23]
    //     0x12ebb28: add             x6, x6, HEAP, lsl #32
    //     0x12ebb2c: sub             w4, w5, w6
    //     0x12ebb30: add             x5, fp, w4, sxtw #2
    //     0x12ebb34: ldr             x5, [x5, #8]
    //     0x12ebb38: mov             x4, x5
    //     0x12ebb3c: b               #0x12ebb44
    //     0x12ebb40: mov             x4, NULL
    //     0x12ebb44: stur            x4, [fp, #-0x10]
    // 0x12ebb48: CheckStackOverflow
    //     0x12ebb48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ebb4c: cmp             SP, x16
    //     0x12ebb50: b.ls            #0x12ebccc
    // 0x12ebb54: LoadField: r5 = r0->field_b
    //     0x12ebb54: ldur            w5, [x0, #0xb]
    // 0x12ebb58: DecompressPointer r5
    //     0x12ebb58: add             x5, x5, HEAP, lsl #32
    // 0x12ebb5c: stur            x5, [fp, #-8]
    // 0x12ebb60: r16 = Instance_BorderRadius
    //     0x12ebb60: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ebb64: ldr             x16, [x16, #0x508]
    // 0x12ebb68: stp             x16, x5, [SP]
    // 0x12ebb6c: r0 = ==()
    //     0x12ebb6c: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ebb70: tbnz            w0, #4, #0x12ebb88
    // 0x12ebb74: ldur            x1, [fp, #-0x18]
    // 0x12ebb78: ldur            x2, [fp, #-0x20]
    // 0x12ebb7c: ldur            x3, [fp, #-0x28]
    // 0x12ebb80: r0 = drawRect()
    //     0x12ebb80: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ebb84: b               #0x12ebcbc
    // 0x12ebb88: ldur            x0, [fp, #-8]
    // 0x12ebb8c: r1 = LoadClassIdInstr(r0)
    //     0x12ebb8c: ldur            x1, [x0, #-1]
    //     0x12ebb90: ubfx            x1, x1, #0xc, #0x14
    // 0x12ebb94: cmp             x1, #0xb88
    // 0x12ebb98: b.ne            #0x12ebc6c
    // 0x12ebb9c: ldur            x2, [fp, #-0x10]
    // 0x12ebba0: cmp             w2, NULL
    // 0x12ebba4: b.eq            #0x12ebcd4
    // 0x12ebba8: LoadField: r1 = r2->field_7
    //     0x12ebba8: ldur            x1, [x2, #7]
    // 0x12ebbac: cmp             x1, #0
    // 0x12ebbb0: b.gt            #0x12ebc10
    // 0x12ebbb4: LoadField: r1 = r0->field_b
    //     0x12ebbb4: ldur            w1, [x0, #0xb]
    // 0x12ebbb8: DecompressPointer r1
    //     0x12ebbb8: add             x1, x1, HEAP, lsl #32
    // 0x12ebbbc: stur            x1, [fp, #-0x48]
    // 0x12ebbc0: LoadField: r2 = r0->field_7
    //     0x12ebbc0: ldur            w2, [x0, #7]
    // 0x12ebbc4: DecompressPointer r2
    //     0x12ebbc4: add             x2, x2, HEAP, lsl #32
    // 0x12ebbc8: stur            x2, [fp, #-0x40]
    // 0x12ebbcc: LoadField: r3 = r0->field_13
    //     0x12ebbcc: ldur            w3, [x0, #0x13]
    // 0x12ebbd0: DecompressPointer r3
    //     0x12ebbd0: add             x3, x3, HEAP, lsl #32
    // 0x12ebbd4: stur            x3, [fp, #-0x38]
    // 0x12ebbd8: LoadField: r4 = r0->field_f
    //     0x12ebbd8: ldur            w4, [x0, #0xf]
    // 0x12ebbdc: DecompressPointer r4
    //     0x12ebbdc: add             x4, x4, HEAP, lsl #32
    // 0x12ebbe0: stur            x4, [fp, #-0x30]
    // 0x12ebbe4: r0 = BorderRadius()
    //     0x12ebbe4: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ebbe8: mov             x1, x0
    // 0x12ebbec: ldur            x0, [fp, #-0x48]
    // 0x12ebbf0: StoreField: r1->field_7 = r0
    //     0x12ebbf0: stur            w0, [x1, #7]
    // 0x12ebbf4: ldur            x0, [fp, #-0x40]
    // 0x12ebbf8: StoreField: r1->field_b = r0
    //     0x12ebbf8: stur            w0, [x1, #0xb]
    // 0x12ebbfc: ldur            x0, [fp, #-0x38]
    // 0x12ebc00: StoreField: r1->field_f = r0
    //     0x12ebc00: stur            w0, [x1, #0xf]
    // 0x12ebc04: ldur            x0, [fp, #-0x30]
    // 0x12ebc08: StoreField: r1->field_13 = r0
    //     0x12ebc08: stur            w0, [x1, #0x13]
    // 0x12ebc0c: b               #0x12ebca4
    // 0x12ebc10: LoadField: r1 = r0->field_7
    //     0x12ebc10: ldur            w1, [x0, #7]
    // 0x12ebc14: DecompressPointer r1
    //     0x12ebc14: add             x1, x1, HEAP, lsl #32
    // 0x12ebc18: stur            x1, [fp, #-0x48]
    // 0x12ebc1c: LoadField: r2 = r0->field_b
    //     0x12ebc1c: ldur            w2, [x0, #0xb]
    // 0x12ebc20: DecompressPointer r2
    //     0x12ebc20: add             x2, x2, HEAP, lsl #32
    // 0x12ebc24: stur            x2, [fp, #-0x40]
    // 0x12ebc28: LoadField: r3 = r0->field_f
    //     0x12ebc28: ldur            w3, [x0, #0xf]
    // 0x12ebc2c: DecompressPointer r3
    //     0x12ebc2c: add             x3, x3, HEAP, lsl #32
    // 0x12ebc30: stur            x3, [fp, #-0x38]
    // 0x12ebc34: LoadField: r4 = r0->field_13
    //     0x12ebc34: ldur            w4, [x0, #0x13]
    // 0x12ebc38: DecompressPointer r4
    //     0x12ebc38: add             x4, x4, HEAP, lsl #32
    // 0x12ebc3c: stur            x4, [fp, #-0x30]
    // 0x12ebc40: r0 = BorderRadius()
    //     0x12ebc40: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ebc44: mov             x1, x0
    // 0x12ebc48: ldur            x0, [fp, #-0x48]
    // 0x12ebc4c: StoreField: r1->field_7 = r0
    //     0x12ebc4c: stur            w0, [x1, #7]
    // 0x12ebc50: ldur            x0, [fp, #-0x40]
    // 0x12ebc54: StoreField: r1->field_b = r0
    //     0x12ebc54: stur            w0, [x1, #0xb]
    // 0x12ebc58: ldur            x0, [fp, #-0x38]
    // 0x12ebc5c: StoreField: r1->field_f = r0
    //     0x12ebc5c: stur            w0, [x1, #0xf]
    // 0x12ebc60: ldur            x0, [fp, #-0x30]
    // 0x12ebc64: StoreField: r1->field_13 = r0
    //     0x12ebc64: stur            w0, [x1, #0x13]
    // 0x12ebc68: b               #0x12ebca4
    // 0x12ebc6c: ldur            x2, [fp, #-0x10]
    // 0x12ebc70: cmp             x1, #0xb89
    // 0x12ebc74: b.ne            #0x12ebc80
    // 0x12ebc78: mov             x1, x0
    // 0x12ebc7c: b               #0x12ebca4
    // 0x12ebc80: r1 = LoadClassIdInstr(r0)
    //     0x12ebc80: ldur            x1, [x0, #-1]
    //     0x12ebc84: ubfx            x1, x1, #0xc, #0x14
    // 0x12ebc88: mov             x16, x0
    // 0x12ebc8c: mov             x0, x1
    // 0x12ebc90: mov             x1, x16
    // 0x12ebc94: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ebc94: sub             lr, x0, #1, lsl #12
    //     0x12ebc98: ldr             lr, [x21, lr, lsl #3]
    //     0x12ebc9c: blr             lr
    // 0x12ebca0: mov             x1, x0
    // 0x12ebca4: ldur            x2, [fp, #-0x20]
    // 0x12ebca8: r0 = toRRect()
    //     0x12ebca8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ebcac: ldur            x1, [fp, #-0x18]
    // 0x12ebcb0: mov             x2, x0
    // 0x12ebcb4: ldur            x3, [fp, #-0x28]
    // 0x12ebcb8: r0 = drawRRect()
    //     0x12ebcb8: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ebcbc: r0 = Null
    //     0x12ebcbc: mov             x0, NULL
    // 0x12ebcc0: LeaveFrame
    //     0x12ebcc0: mov             SP, fp
    //     0x12ebcc4: ldp             fp, lr, [SP], #0x10
    // 0x12ebcc8: ret
    //     0x12ebcc8: ret             
    // 0x12ebccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ebccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ebcd0: b               #0x12ebb54
    // 0x12ebcd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ebcd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ecb18, size: 0x3c8
    // 0x12ecb18: EnterFrame
    //     0x12ecb18: stp             fp, lr, [SP, #-0x10]!
    //     0x12ecb1c: mov             fp, SP
    // 0x12ecb20: AllocStack(0x68)
    //     0x12ecb20: sub             SP, SP, #0x68
    // 0x12ecb24: SetupParameters(RoundedRectangleBorder this /* r1 => r0, fp-0x48 */, dynamic _ /* r2 => r1, fp-0x30 */, dynamic _ /* r3 => r2, fp-0x38 */, {dynamic textDirection = Null /* r3, fp-0x40 */})
    //     0x12ecb24: mov             x0, x1
    //     0x12ecb28: stur            x1, [fp, #-0x48]
    //     0x12ecb2c: mov             x1, x2
    //     0x12ecb30: stur            x2, [fp, #-0x30]
    //     0x12ecb34: mov             x2, x3
    //     0x12ecb38: stur            x3, [fp, #-0x38]
    //     0x12ecb3c: ldur            w3, [x4, #0x13]
    //     0x12ecb40: ldur            w5, [x4, #0x1f]
    //     0x12ecb44: add             x5, x5, HEAP, lsl #32
    //     0x12ecb48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ecb4c: ldr             x16, [x16, #0x210]
    //     0x12ecb50: cmp             w5, w16
    //     0x12ecb54: b.ne            #0x12ecb70
    //     0x12ecb58: ldur            w5, [x4, #0x23]
    //     0x12ecb5c: add             x5, x5, HEAP, lsl #32
    //     0x12ecb60: sub             w4, w3, w5
    //     0x12ecb64: add             x3, fp, w4, sxtw #2
    //     0x12ecb68: ldr             x3, [x3, #8]
    //     0x12ecb6c: b               #0x12ecb74
    //     0x12ecb70: mov             x3, NULL
    //     0x12ecb74: stur            x3, [fp, #-0x40]
    // 0x12ecb78: CheckStackOverflow
    //     0x12ecb78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ecb7c: cmp             SP, x16
    //     0x12ecb80: b.ls            #0x12eced0
    // 0x12ecb84: LoadField: r4 = r0->field_7
    //     0x12ecb84: ldur            w4, [x0, #7]
    // 0x12ecb88: DecompressPointer r4
    //     0x12ecb88: add             x4, x4, HEAP, lsl #32
    // 0x12ecb8c: stur            x4, [fp, #-0x28]
    // 0x12ecb90: LoadField: r5 = r4->field_13
    //     0x12ecb90: ldur            w5, [x4, #0x13]
    // 0x12ecb94: DecompressPointer r5
    //     0x12ecb94: add             x5, x5, HEAP, lsl #32
    // 0x12ecb98: LoadField: r6 = r5->field_7
    //     0x12ecb98: ldur            x6, [x5, #7]
    // 0x12ecb9c: cmp             x6, #0
    // 0x12ecba0: b.le            #0x12ecec0
    // 0x12ecba4: d0 = 0.000000
    //     0x12ecba4: eor             v0.16b, v0.16b, v0.16b
    // 0x12ecba8: LoadField: d1 = r4->field_b
    //     0x12ecba8: ldur            d1, [x4, #0xb]
    // 0x12ecbac: stur            d1, [fp, #-0x50]
    // 0x12ecbb0: fcmp            d1, d0
    // 0x12ecbb4: b.ne            #0x12eccf4
    // 0x12ecbb8: LoadField: r5 = r0->field_b
    //     0x12ecbb8: ldur            w5, [x0, #0xb]
    // 0x12ecbbc: DecompressPointer r5
    //     0x12ecbbc: add             x5, x5, HEAP, lsl #32
    // 0x12ecbc0: r0 = LoadClassIdInstr(r5)
    //     0x12ecbc0: ldur            x0, [x5, #-1]
    //     0x12ecbc4: ubfx            x0, x0, #0xc, #0x14
    // 0x12ecbc8: cmp             x0, #0xb88
    // 0x12ecbcc: b.ne            #0x12ecc9c
    // 0x12ecbd0: cmp             w3, NULL
    // 0x12ecbd4: b.eq            #0x12eced8
    // 0x12ecbd8: LoadField: r0 = r3->field_7
    //     0x12ecbd8: ldur            x0, [x3, #7]
    // 0x12ecbdc: cmp             x0, #0
    // 0x12ecbe0: b.gt            #0x12ecc40
    // 0x12ecbe4: LoadField: r0 = r5->field_b
    //     0x12ecbe4: ldur            w0, [x5, #0xb]
    // 0x12ecbe8: DecompressPointer r0
    //     0x12ecbe8: add             x0, x0, HEAP, lsl #32
    // 0x12ecbec: stur            x0, [fp, #-0x20]
    // 0x12ecbf0: LoadField: r3 = r5->field_7
    //     0x12ecbf0: ldur            w3, [x5, #7]
    // 0x12ecbf4: DecompressPointer r3
    //     0x12ecbf4: add             x3, x3, HEAP, lsl #32
    // 0x12ecbf8: stur            x3, [fp, #-0x18]
    // 0x12ecbfc: LoadField: r6 = r5->field_13
    //     0x12ecbfc: ldur            w6, [x5, #0x13]
    // 0x12ecc00: DecompressPointer r6
    //     0x12ecc00: add             x6, x6, HEAP, lsl #32
    // 0x12ecc04: stur            x6, [fp, #-0x10]
    // 0x12ecc08: LoadField: r7 = r5->field_f
    //     0x12ecc08: ldur            w7, [x5, #0xf]
    // 0x12ecc0c: DecompressPointer r7
    //     0x12ecc0c: add             x7, x7, HEAP, lsl #32
    // 0x12ecc10: stur            x7, [fp, #-8]
    // 0x12ecc14: r0 = BorderRadius()
    //     0x12ecc14: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ecc18: mov             x1, x0
    // 0x12ecc1c: ldur            x0, [fp, #-0x20]
    // 0x12ecc20: StoreField: r1->field_7 = r0
    //     0x12ecc20: stur            w0, [x1, #7]
    // 0x12ecc24: ldur            x0, [fp, #-0x18]
    // 0x12ecc28: StoreField: r1->field_b = r0
    //     0x12ecc28: stur            w0, [x1, #0xb]
    // 0x12ecc2c: ldur            x0, [fp, #-0x10]
    // 0x12ecc30: StoreField: r1->field_f = r0
    //     0x12ecc30: stur            w0, [x1, #0xf]
    // 0x12ecc34: ldur            x0, [fp, #-8]
    // 0x12ecc38: StoreField: r1->field_13 = r0
    //     0x12ecc38: stur            w0, [x1, #0x13]
    // 0x12ecc3c: b               #0x12ecccc
    // 0x12ecc40: LoadField: r0 = r5->field_7
    //     0x12ecc40: ldur            w0, [x5, #7]
    // 0x12ecc44: DecompressPointer r0
    //     0x12ecc44: add             x0, x0, HEAP, lsl #32
    // 0x12ecc48: stur            x0, [fp, #-0x20]
    // 0x12ecc4c: LoadField: r1 = r5->field_b
    //     0x12ecc4c: ldur            w1, [x5, #0xb]
    // 0x12ecc50: DecompressPointer r1
    //     0x12ecc50: add             x1, x1, HEAP, lsl #32
    // 0x12ecc54: stur            x1, [fp, #-0x18]
    // 0x12ecc58: LoadField: r2 = r5->field_f
    //     0x12ecc58: ldur            w2, [x5, #0xf]
    // 0x12ecc5c: DecompressPointer r2
    //     0x12ecc5c: add             x2, x2, HEAP, lsl #32
    // 0x12ecc60: stur            x2, [fp, #-0x10]
    // 0x12ecc64: LoadField: r3 = r5->field_13
    //     0x12ecc64: ldur            w3, [x5, #0x13]
    // 0x12ecc68: DecompressPointer r3
    //     0x12ecc68: add             x3, x3, HEAP, lsl #32
    // 0x12ecc6c: stur            x3, [fp, #-8]
    // 0x12ecc70: r0 = BorderRadius()
    //     0x12ecc70: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ecc74: mov             x1, x0
    // 0x12ecc78: ldur            x0, [fp, #-0x20]
    // 0x12ecc7c: StoreField: r1->field_7 = r0
    //     0x12ecc7c: stur            w0, [x1, #7]
    // 0x12ecc80: ldur            x0, [fp, #-0x18]
    // 0x12ecc84: StoreField: r1->field_b = r0
    //     0x12ecc84: stur            w0, [x1, #0xb]
    // 0x12ecc88: ldur            x0, [fp, #-0x10]
    // 0x12ecc8c: StoreField: r1->field_f = r0
    //     0x12ecc8c: stur            w0, [x1, #0xf]
    // 0x12ecc90: ldur            x0, [fp, #-8]
    // 0x12ecc94: StoreField: r1->field_13 = r0
    //     0x12ecc94: stur            w0, [x1, #0x13]
    // 0x12ecc98: b               #0x12ecccc
    // 0x12ecc9c: cmp             x0, #0xb89
    // 0x12ecca0: b.ne            #0x12eccac
    // 0x12ecca4: mov             x1, x5
    // 0x12ecca8: b               #0x12ecccc
    // 0x12eccac: r0 = LoadClassIdInstr(r5)
    //     0x12eccac: ldur            x0, [x5, #-1]
    //     0x12eccb0: ubfx            x0, x0, #0xc, #0x14
    // 0x12eccb4: mov             x1, x5
    // 0x12eccb8: mov             x2, x3
    // 0x12eccbc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12eccbc: sub             lr, x0, #1, lsl #12
    //     0x12eccc0: ldr             lr, [x21, lr, lsl #3]
    //     0x12eccc4: blr             lr
    // 0x12eccc8: mov             x1, x0
    // 0x12ecccc: ldur            x2, [fp, #-0x38]
    // 0x12eccd0: r0 = toRRect()
    //     0x12eccd0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12eccd4: ldur            x1, [fp, #-0x28]
    // 0x12eccd8: stur            x0, [fp, #-8]
    // 0x12eccdc: r0 = toPaint()
    //     0x12eccdc: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ecce0: ldur            x1, [fp, #-0x30]
    // 0x12ecce4: ldur            x2, [fp, #-8]
    // 0x12ecce8: mov             x3, x0
    // 0x12eccec: r0 = drawRRect()
    //     0x12eccec: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12eccf0: b               #0x12ecec0
    // 0x12eccf4: mov             x1, x4
    // 0x12eccf8: r16 = 136
    //     0x12eccf8: mov             x16, #0x88
    // 0x12eccfc: stp             x16, NULL, [SP]
    // 0x12ecd00: r0 = ByteData()
    //     0x12ecd00: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12ecd04: stur            x0, [fp, #-8]
    // 0x12ecd08: r0 = Paint()
    //     0x12ecd08: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12ecd0c: mov             x3, x0
    // 0x12ecd10: ldur            x0, [fp, #-8]
    // 0x12ecd14: stur            x3, [fp, #-0x10]
    // 0x12ecd18: StoreField: r3->field_7 = r0
    //     0x12ecd18: stur            w0, [x3, #7]
    // 0x12ecd1c: ldur            x0, [fp, #-0x28]
    // 0x12ecd20: LoadField: r2 = r0->field_7
    //     0x12ecd20: ldur            w2, [x0, #7]
    // 0x12ecd24: DecompressPointer r2
    //     0x12ecd24: add             x2, x2, HEAP, lsl #32
    // 0x12ecd28: mov             x1, x3
    // 0x12ecd2c: r0 = color=()
    //     0x12ecd2c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12ecd30: ldur            x0, [fp, #-0x48]
    // 0x12ecd34: LoadField: r1 = r0->field_b
    //     0x12ecd34: ldur            w1, [x0, #0xb]
    // 0x12ecd38: DecompressPointer r1
    //     0x12ecd38: add             x1, x1, HEAP, lsl #32
    // 0x12ecd3c: r0 = LoadClassIdInstr(r1)
    //     0x12ecd3c: ldur            x0, [x1, #-1]
    //     0x12ecd40: ubfx            x0, x0, #0xc, #0x14
    // 0x12ecd44: cmp             x0, #0xb88
    // 0x12ecd48: b.ne            #0x12ece1c
    // 0x12ecd4c: ldur            x2, [fp, #-0x40]
    // 0x12ecd50: cmp             w2, NULL
    // 0x12ecd54: b.eq            #0x12ecedc
    // 0x12ecd58: LoadField: r0 = r2->field_7
    //     0x12ecd58: ldur            x0, [x2, #7]
    // 0x12ecd5c: cmp             x0, #0
    // 0x12ecd60: b.gt            #0x12ecdc0
    // 0x12ecd64: LoadField: r0 = r1->field_b
    //     0x12ecd64: ldur            w0, [x1, #0xb]
    // 0x12ecd68: DecompressPointer r0
    //     0x12ecd68: add             x0, x0, HEAP, lsl #32
    // 0x12ecd6c: stur            x0, [fp, #-0x48]
    // 0x12ecd70: LoadField: r2 = r1->field_7
    //     0x12ecd70: ldur            w2, [x1, #7]
    // 0x12ecd74: DecompressPointer r2
    //     0x12ecd74: add             x2, x2, HEAP, lsl #32
    // 0x12ecd78: stur            x2, [fp, #-0x20]
    // 0x12ecd7c: LoadField: r3 = r1->field_13
    //     0x12ecd7c: ldur            w3, [x1, #0x13]
    // 0x12ecd80: DecompressPointer r3
    //     0x12ecd80: add             x3, x3, HEAP, lsl #32
    // 0x12ecd84: stur            x3, [fp, #-0x18]
    // 0x12ecd88: LoadField: r4 = r1->field_f
    //     0x12ecd88: ldur            w4, [x1, #0xf]
    // 0x12ecd8c: DecompressPointer r4
    //     0x12ecd8c: add             x4, x4, HEAP, lsl #32
    // 0x12ecd90: stur            x4, [fp, #-8]
    // 0x12ecd94: r0 = BorderRadius()
    //     0x12ecd94: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ecd98: mov             x1, x0
    // 0x12ecd9c: ldur            x0, [fp, #-0x48]
    // 0x12ecda0: StoreField: r1->field_7 = r0
    //     0x12ecda0: stur            w0, [x1, #7]
    // 0x12ecda4: ldur            x0, [fp, #-0x20]
    // 0x12ecda8: StoreField: r1->field_b = r0
    //     0x12ecda8: stur            w0, [x1, #0xb]
    // 0x12ecdac: ldur            x0, [fp, #-0x18]
    // 0x12ecdb0: StoreField: r1->field_f = r0
    //     0x12ecdb0: stur            w0, [x1, #0xf]
    // 0x12ecdb4: ldur            x0, [fp, #-8]
    // 0x12ecdb8: StoreField: r1->field_13 = r0
    //     0x12ecdb8: stur            w0, [x1, #0x13]
    // 0x12ecdbc: b               #0x12ece40
    // 0x12ecdc0: LoadField: r0 = r1->field_7
    //     0x12ecdc0: ldur            w0, [x1, #7]
    // 0x12ecdc4: DecompressPointer r0
    //     0x12ecdc4: add             x0, x0, HEAP, lsl #32
    // 0x12ecdc8: stur            x0, [fp, #-0x48]
    // 0x12ecdcc: LoadField: r2 = r1->field_b
    //     0x12ecdcc: ldur            w2, [x1, #0xb]
    // 0x12ecdd0: DecompressPointer r2
    //     0x12ecdd0: add             x2, x2, HEAP, lsl #32
    // 0x12ecdd4: stur            x2, [fp, #-0x20]
    // 0x12ecdd8: LoadField: r3 = r1->field_f
    //     0x12ecdd8: ldur            w3, [x1, #0xf]
    // 0x12ecddc: DecompressPointer r3
    //     0x12ecddc: add             x3, x3, HEAP, lsl #32
    // 0x12ecde0: stur            x3, [fp, #-0x18]
    // 0x12ecde4: LoadField: r4 = r1->field_13
    //     0x12ecde4: ldur            w4, [x1, #0x13]
    // 0x12ecde8: DecompressPointer r4
    //     0x12ecde8: add             x4, x4, HEAP, lsl #32
    // 0x12ecdec: stur            x4, [fp, #-8]
    // 0x12ecdf0: r0 = BorderRadius()
    //     0x12ecdf0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ecdf4: mov             x1, x0
    // 0x12ecdf8: ldur            x0, [fp, #-0x48]
    // 0x12ecdfc: StoreField: r1->field_7 = r0
    //     0x12ecdfc: stur            w0, [x1, #7]
    // 0x12ece00: ldur            x0, [fp, #-0x20]
    // 0x12ece04: StoreField: r1->field_b = r0
    //     0x12ece04: stur            w0, [x1, #0xb]
    // 0x12ece08: ldur            x0, [fp, #-0x18]
    // 0x12ece0c: StoreField: r1->field_f = r0
    //     0x12ece0c: stur            w0, [x1, #0xf]
    // 0x12ece10: ldur            x0, [fp, #-8]
    // 0x12ece14: StoreField: r1->field_13 = r0
    //     0x12ece14: stur            w0, [x1, #0x13]
    // 0x12ece18: b               #0x12ece40
    // 0x12ece1c: ldur            x2, [fp, #-0x40]
    // 0x12ece20: cmp             x0, #0xb89
    // 0x12ece24: b.eq            #0x12ece40
    // 0x12ece28: r0 = LoadClassIdInstr(r1)
    //     0x12ece28: ldur            x0, [x1, #-1]
    //     0x12ece2c: ubfx            x0, x0, #0xc, #0x14
    // 0x12ece30: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ece30: sub             lr, x0, #1, lsl #12
    //     0x12ece34: ldr             lr, [x21, lr, lsl #3]
    //     0x12ece38: blr             lr
    // 0x12ece3c: mov             x1, x0
    // 0x12ece40: ldur            x0, [fp, #-0x28]
    // 0x12ece44: ldur            d0, [fp, #-0x50]
    // 0x12ece48: ldur            x2, [fp, #-0x38]
    // 0x12ece4c: r0 = toRRect()
    //     0x12ece4c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ece50: mov             x2, x0
    // 0x12ece54: ldur            x0, [fp, #-0x28]
    // 0x12ece58: stur            x2, [fp, #-8]
    // 0x12ece5c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x12ece5c: ldur            d0, [x0, #0x17]
    // 0x12ece60: d1 = 1.000000
    //     0x12ece60: fmov            d1, #1.00000000
    // 0x12ece64: fadd            d2, d0, d1
    // 0x12ece68: stur            d2, [fp, #-0x58]
    // 0x12ece6c: d3 = 2.000000
    //     0x12ece6c: fmov            d3, #2.00000000
    // 0x12ece70: fdiv            d0, d2, d3
    // 0x12ece74: fsub            d4, d1, d0
    // 0x12ece78: ldur            d1, [fp, #-0x50]
    // 0x12ece7c: fmul            d0, d1, d4
    // 0x12ece80: mov             x1, x2
    // 0x12ece84: r0 = deflate()
    //     0x12ece84: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0x12ece88: ldur            d1, [fp, #-0x50]
    // 0x12ece8c: ldur            d0, [fp, #-0x58]
    // 0x12ece90: stur            x0, [fp, #-0x18]
    // 0x12ece94: fmul            d2, d1, d0
    // 0x12ece98: d0 = 2.000000
    //     0x12ece98: fmov            d0, #2.00000000
    // 0x12ece9c: fdiv            d1, d2, d0
    // 0x12ecea0: ldur            x1, [fp, #-8]
    // 0x12ecea4: mov             v0.16b, v1.16b
    // 0x12ecea8: r0 = inflate()
    //     0x12ecea8: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12eceac: ldur            x1, [fp, #-0x30]
    // 0x12eceb0: mov             x2, x0
    // 0x12eceb4: ldur            x3, [fp, #-0x18]
    // 0x12eceb8: ldur            x5, [fp, #-0x10]
    // 0x12ecebc: r0 = drawDRRect()
    //     0x12ecebc: bl              #0x12ecee0  ; [dart:ui] _NativeCanvas::drawDRRect
    // 0x12ecec0: r0 = Null
    //     0x12ecec0: mov             x0, NULL
    // 0x12ecec4: LeaveFrame
    //     0x12ecec4: mov             SP, fp
    //     0x12ecec8: ldp             fp, lr, [SP], #0x10
    // 0x12ececc: ret
    //     0x12ececc: ret             
    // 0x12eced0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eced0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eced4: b               #0x12ecb84
    // 0x12eced8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eced8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12ecedc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ecedc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fc428, size: 0x1e0
    // 0x12fc428: EnterFrame
    //     0x12fc428: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc42c: mov             fp, SP
    // 0x12fc430: AllocStack(0x38)
    //     0x12fc430: sub             SP, SP, #0x38
    // 0x12fc434: SetupParameters(RoundedRectangleBorder this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x38 */)
    //     0x12fc434: mov             x0, x1
    //     0x12fc438: mov             v1.16b, v0.16b
    //     0x12fc43c: stur            x1, [fp, #-8]
    //     0x12fc440: stur            d0, [fp, #-0x38]
    // 0x12fc444: CheckStackOverflow
    //     0x12fc444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc448: cmp             SP, x16
    //     0x12fc44c: b.ls            #0x12fc600
    // 0x12fc450: LoadField: r1 = r0->field_7
    //     0x12fc450: ldur            w1, [x0, #7]
    // 0x12fc454: DecompressPointer r1
    //     0x12fc454: add             x1, x1, HEAP, lsl #32
    // 0x12fc458: mov             v0.16b, v1.16b
    // 0x12fc45c: r0 = scale()
    //     0x12fc45c: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fc460: mov             x2, x0
    // 0x12fc464: ldur            x0, [fp, #-8]
    // 0x12fc468: stur            x2, [fp, #-0x18]
    // 0x12fc46c: LoadField: r3 = r0->field_b
    //     0x12fc46c: ldur            w3, [x0, #0xb]
    // 0x12fc470: DecompressPointer r3
    //     0x12fc470: add             x3, x3, HEAP, lsl #32
    // 0x12fc474: stur            x3, [fp, #-0x10]
    // 0x12fc478: r0 = LoadClassIdInstr(r3)
    //     0x12fc478: ldur            x0, [x3, #-1]
    //     0x12fc47c: ubfx            x0, x0, #0xc, #0x14
    // 0x12fc480: cmp             x0, #0xb88
    // 0x12fc484: b.ne            #0x12fc518
    // 0x12fc488: LoadField: r1 = r3->field_7
    //     0x12fc488: ldur            w1, [x3, #7]
    // 0x12fc48c: DecompressPointer r1
    //     0x12fc48c: add             x1, x1, HEAP, lsl #32
    // 0x12fc490: ldur            d0, [fp, #-0x38]
    // 0x12fc494: r0 = *()
    //     0x12fc494: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc498: mov             x2, x0
    // 0x12fc49c: ldur            x0, [fp, #-0x10]
    // 0x12fc4a0: stur            x2, [fp, #-8]
    // 0x12fc4a4: LoadField: r1 = r0->field_b
    //     0x12fc4a4: ldur            w1, [x0, #0xb]
    // 0x12fc4a8: DecompressPointer r1
    //     0x12fc4a8: add             x1, x1, HEAP, lsl #32
    // 0x12fc4ac: ldur            d0, [fp, #-0x38]
    // 0x12fc4b0: r0 = *()
    //     0x12fc4b0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc4b4: mov             x2, x0
    // 0x12fc4b8: ldur            x0, [fp, #-0x10]
    // 0x12fc4bc: stur            x2, [fp, #-0x20]
    // 0x12fc4c0: LoadField: r1 = r0->field_f
    //     0x12fc4c0: ldur            w1, [x0, #0xf]
    // 0x12fc4c4: DecompressPointer r1
    //     0x12fc4c4: add             x1, x1, HEAP, lsl #32
    // 0x12fc4c8: ldur            d0, [fp, #-0x38]
    // 0x12fc4cc: r0 = *()
    //     0x12fc4cc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc4d0: ldur            x2, [fp, #-0x10]
    // 0x12fc4d4: stur            x0, [fp, #-0x28]
    // 0x12fc4d8: LoadField: r1 = r2->field_13
    //     0x12fc4d8: ldur            w1, [x2, #0x13]
    // 0x12fc4dc: DecompressPointer r1
    //     0x12fc4dc: add             x1, x1, HEAP, lsl #32
    // 0x12fc4e0: ldur            d0, [fp, #-0x38]
    // 0x12fc4e4: r0 = *()
    //     0x12fc4e4: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc4e8: stur            x0, [fp, #-0x30]
    // 0x12fc4ec: r0 = BorderRadiusDirectional()
    //     0x12fc4ec: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0x12fc4f0: mov             x1, x0
    // 0x12fc4f4: ldur            x0, [fp, #-8]
    // 0x12fc4f8: StoreField: r1->field_7 = r0
    //     0x12fc4f8: stur            w0, [x1, #7]
    // 0x12fc4fc: ldur            x0, [fp, #-0x20]
    // 0x12fc500: StoreField: r1->field_b = r0
    //     0x12fc500: stur            w0, [x1, #0xb]
    // 0x12fc504: ldur            x0, [fp, #-0x28]
    // 0x12fc508: StoreField: r1->field_f = r0
    //     0x12fc508: stur            w0, [x1, #0xf]
    // 0x12fc50c: ldur            x0, [fp, #-0x30]
    // 0x12fc510: StoreField: r1->field_13 = r0
    //     0x12fc510: stur            w0, [x1, #0x13]
    // 0x12fc514: b               #0x12fc5d8
    // 0x12fc518: mov             x2, x3
    // 0x12fc51c: cmp             x0, #0xb89
    // 0x12fc520: b.ne            #0x12fc5b8
    // 0x12fc524: LoadField: r1 = r2->field_7
    //     0x12fc524: ldur            w1, [x2, #7]
    // 0x12fc528: DecompressPointer r1
    //     0x12fc528: add             x1, x1, HEAP, lsl #32
    // 0x12fc52c: ldur            d0, [fp, #-0x38]
    // 0x12fc530: r0 = *()
    //     0x12fc530: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc534: mov             x2, x0
    // 0x12fc538: ldur            x0, [fp, #-0x10]
    // 0x12fc53c: stur            x2, [fp, #-8]
    // 0x12fc540: LoadField: r1 = r0->field_b
    //     0x12fc540: ldur            w1, [x0, #0xb]
    // 0x12fc544: DecompressPointer r1
    //     0x12fc544: add             x1, x1, HEAP, lsl #32
    // 0x12fc548: ldur            d0, [fp, #-0x38]
    // 0x12fc54c: r0 = *()
    //     0x12fc54c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc550: mov             x2, x0
    // 0x12fc554: ldur            x0, [fp, #-0x10]
    // 0x12fc558: stur            x2, [fp, #-0x20]
    // 0x12fc55c: LoadField: r1 = r0->field_f
    //     0x12fc55c: ldur            w1, [x0, #0xf]
    // 0x12fc560: DecompressPointer r1
    //     0x12fc560: add             x1, x1, HEAP, lsl #32
    // 0x12fc564: ldur            d0, [fp, #-0x38]
    // 0x12fc568: r0 = *()
    //     0x12fc568: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc56c: ldur            x1, [fp, #-0x10]
    // 0x12fc570: stur            x0, [fp, #-0x28]
    // 0x12fc574: LoadField: r2 = r1->field_13
    //     0x12fc574: ldur            w2, [x1, #0x13]
    // 0x12fc578: DecompressPointer r2
    //     0x12fc578: add             x2, x2, HEAP, lsl #32
    // 0x12fc57c: mov             x1, x2
    // 0x12fc580: ldur            d0, [fp, #-0x38]
    // 0x12fc584: r0 = *()
    //     0x12fc584: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fc588: stur            x0, [fp, #-0x30]
    // 0x12fc58c: r0 = BorderRadius()
    //     0x12fc58c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12fc590: mov             x1, x0
    // 0x12fc594: ldur            x0, [fp, #-8]
    // 0x12fc598: StoreField: r1->field_7 = r0
    //     0x12fc598: stur            w0, [x1, #7]
    // 0x12fc59c: ldur            x0, [fp, #-0x20]
    // 0x12fc5a0: StoreField: r1->field_b = r0
    //     0x12fc5a0: stur            w0, [x1, #0xb]
    // 0x12fc5a4: ldur            x0, [fp, #-0x28]
    // 0x12fc5a8: StoreField: r1->field_f = r0
    //     0x12fc5a8: stur            w0, [x1, #0xf]
    // 0x12fc5ac: ldur            x0, [fp, #-0x30]
    // 0x12fc5b0: StoreField: r1->field_13 = r0
    //     0x12fc5b0: stur            w0, [x1, #0x13]
    // 0x12fc5b4: b               #0x12fc5d8
    // 0x12fc5b8: mov             x1, x2
    // 0x12fc5bc: r0 = LoadClassIdInstr(r1)
    //     0x12fc5bc: ldur            x0, [x1, #-1]
    //     0x12fc5c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12fc5c4: ldur            d0, [fp, #-0x38]
    // 0x12fc5c8: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x12fc5c8: sub             lr, x0, #0xfb8
    //     0x12fc5cc: ldr             lr, [x21, lr, lsl #3]
    //     0x12fc5d0: blr             lr
    // 0x12fc5d4: mov             x1, x0
    // 0x12fc5d8: ldur            x0, [fp, #-0x18]
    // 0x12fc5dc: stur            x1, [fp, #-8]
    // 0x12fc5e0: r0 = RoundedRectangleBorder()
    //     0x12fc5e0: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x12fc5e4: ldur            x1, [fp, #-8]
    // 0x12fc5e8: StoreField: r0->field_b = r1
    //     0x12fc5e8: stur            w1, [x0, #0xb]
    // 0x12fc5ec: ldur            x1, [fp, #-0x18]
    // 0x12fc5f0: StoreField: r0->field_7 = r1
    //     0x12fc5f0: stur            w1, [x0, #7]
    // 0x12fc5f4: LeaveFrame
    //     0x12fc5f4: mov             SP, fp
    //     0x12fc5f8: ldp             fp, lr, [SP], #0x10
    // 0x12fc5fc: ret
    //     0x12fc5fc: ret             
    // 0x12fc600: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fc600: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fc604: b               #0x12fc450
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x12ffbb0, size: 0x2a8
    // 0x12ffbb0: EnterFrame
    //     0x12ffbb0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ffbb4: mov             fp, SP
    // 0x12ffbb8: AllocStack(0x50)
    //     0x12ffbb8: sub             SP, SP, #0x50
    // 0x12ffbbc: SetupParameters(RoundedRectangleBorder this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0x12ffbbc: stur            x1, [fp, #-0x10]
    //     0x12ffbc0: stur            x2, [fp, #-0x18]
    //     0x12ffbc4: ldur            w0, [x4, #0x13]
    //     0x12ffbc8: ldur            w3, [x4, #0x1f]
    //     0x12ffbcc: add             x3, x3, HEAP, lsl #32
    //     0x12ffbd0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ffbd4: ldr             x16, [x16, #0x210]
    //     0x12ffbd8: cmp             w3, w16
    //     0x12ffbdc: b.ne            #0x12ffbf8
    //     0x12ffbe0: ldur            w3, [x4, #0x23]
    //     0x12ffbe4: add             x3, x3, HEAP, lsl #32
    //     0x12ffbe8: sub             w4, w0, w3
    //     0x12ffbec: add             x0, fp, w4, sxtw #2
    //     0x12ffbf0: ldr             x0, [x0, #8]
    //     0x12ffbf4: b               #0x12ffbfc
    //     0x12ffbf8: mov             x0, NULL
    //     0x12ffbfc: stur            x0, [fp, #-8]
    // 0x12ffc00: CheckStackOverflow
    //     0x12ffc00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ffc04: cmp             SP, x16
    //     0x12ffc08: b.ls            #0x12ffe48
    // 0x12ffc0c: r0 = _NativePath()
    //     0x12ffc0c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12ffc10: mov             x1, x0
    // 0x12ffc14: stur            x0, [fp, #-0x20]
    // 0x12ffc18: r0 = __constructor$Method$FfiNative()
    //     0x12ffc18: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12ffc1c: ldur            x0, [fp, #-0x10]
    // 0x12ffc20: LoadField: r1 = r0->field_b
    //     0x12ffc20: ldur            w1, [x0, #0xb]
    // 0x12ffc24: DecompressPointer r1
    //     0x12ffc24: add             x1, x1, HEAP, lsl #32
    // 0x12ffc28: r0 = LoadClassIdInstr(r1)
    //     0x12ffc28: ldur            x0, [x1, #-1]
    //     0x12ffc2c: ubfx            x0, x0, #0xc, #0x14
    // 0x12ffc30: cmp             x0, #0xb88
    // 0x12ffc34: b.ne            #0x12ffd08
    // 0x12ffc38: ldur            x2, [fp, #-8]
    // 0x12ffc3c: cmp             w2, NULL
    // 0x12ffc40: b.eq            #0x12ffe50
    // 0x12ffc44: LoadField: r0 = r2->field_7
    //     0x12ffc44: ldur            x0, [x2, #7]
    // 0x12ffc48: cmp             x0, #0
    // 0x12ffc4c: b.gt            #0x12ffcac
    // 0x12ffc50: LoadField: r0 = r1->field_b
    //     0x12ffc50: ldur            w0, [x1, #0xb]
    // 0x12ffc54: DecompressPointer r0
    //     0x12ffc54: add             x0, x0, HEAP, lsl #32
    // 0x12ffc58: stur            x0, [fp, #-0x38]
    // 0x12ffc5c: LoadField: r2 = r1->field_7
    //     0x12ffc5c: ldur            w2, [x1, #7]
    // 0x12ffc60: DecompressPointer r2
    //     0x12ffc60: add             x2, x2, HEAP, lsl #32
    // 0x12ffc64: stur            x2, [fp, #-0x30]
    // 0x12ffc68: LoadField: r3 = r1->field_13
    //     0x12ffc68: ldur            w3, [x1, #0x13]
    // 0x12ffc6c: DecompressPointer r3
    //     0x12ffc6c: add             x3, x3, HEAP, lsl #32
    // 0x12ffc70: stur            x3, [fp, #-0x28]
    // 0x12ffc74: LoadField: r4 = r1->field_f
    //     0x12ffc74: ldur            w4, [x1, #0xf]
    // 0x12ffc78: DecompressPointer r4
    //     0x12ffc78: add             x4, x4, HEAP, lsl #32
    // 0x12ffc7c: stur            x4, [fp, #-0x10]
    // 0x12ffc80: r0 = BorderRadius()
    //     0x12ffc80: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ffc84: mov             x1, x0
    // 0x12ffc88: ldur            x0, [fp, #-0x38]
    // 0x12ffc8c: StoreField: r1->field_7 = r0
    //     0x12ffc8c: stur            w0, [x1, #7]
    // 0x12ffc90: ldur            x0, [fp, #-0x30]
    // 0x12ffc94: StoreField: r1->field_b = r0
    //     0x12ffc94: stur            w0, [x1, #0xb]
    // 0x12ffc98: ldur            x0, [fp, #-0x28]
    // 0x12ffc9c: StoreField: r1->field_f = r0
    //     0x12ffc9c: stur            w0, [x1, #0xf]
    // 0x12ffca0: ldur            x0, [fp, #-0x10]
    // 0x12ffca4: StoreField: r1->field_13 = r0
    //     0x12ffca4: stur            w0, [x1, #0x13]
    // 0x12ffca8: b               #0x12ffd2c
    // 0x12ffcac: LoadField: r0 = r1->field_7
    //     0x12ffcac: ldur            w0, [x1, #7]
    // 0x12ffcb0: DecompressPointer r0
    //     0x12ffcb0: add             x0, x0, HEAP, lsl #32
    // 0x12ffcb4: stur            x0, [fp, #-0x38]
    // 0x12ffcb8: LoadField: r2 = r1->field_b
    //     0x12ffcb8: ldur            w2, [x1, #0xb]
    // 0x12ffcbc: DecompressPointer r2
    //     0x12ffcbc: add             x2, x2, HEAP, lsl #32
    // 0x12ffcc0: stur            x2, [fp, #-0x30]
    // 0x12ffcc4: LoadField: r3 = r1->field_f
    //     0x12ffcc4: ldur            w3, [x1, #0xf]
    // 0x12ffcc8: DecompressPointer r3
    //     0x12ffcc8: add             x3, x3, HEAP, lsl #32
    // 0x12ffccc: stur            x3, [fp, #-0x28]
    // 0x12ffcd0: LoadField: r4 = r1->field_13
    //     0x12ffcd0: ldur            w4, [x1, #0x13]
    // 0x12ffcd4: DecompressPointer r4
    //     0x12ffcd4: add             x4, x4, HEAP, lsl #32
    // 0x12ffcd8: stur            x4, [fp, #-0x10]
    // 0x12ffcdc: r0 = BorderRadius()
    //     0x12ffcdc: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ffce0: mov             x1, x0
    // 0x12ffce4: ldur            x0, [fp, #-0x38]
    // 0x12ffce8: StoreField: r1->field_7 = r0
    //     0x12ffce8: stur            w0, [x1, #7]
    // 0x12ffcec: ldur            x0, [fp, #-0x30]
    // 0x12ffcf0: StoreField: r1->field_b = r0
    //     0x12ffcf0: stur            w0, [x1, #0xb]
    // 0x12ffcf4: ldur            x0, [fp, #-0x28]
    // 0x12ffcf8: StoreField: r1->field_f = r0
    //     0x12ffcf8: stur            w0, [x1, #0xf]
    // 0x12ffcfc: ldur            x0, [fp, #-0x10]
    // 0x12ffd00: StoreField: r1->field_13 = r0
    //     0x12ffd00: stur            w0, [x1, #0x13]
    // 0x12ffd04: b               #0x12ffd2c
    // 0x12ffd08: ldur            x2, [fp, #-8]
    // 0x12ffd0c: cmp             x0, #0xb89
    // 0x12ffd10: b.eq            #0x12ffd2c
    // 0x12ffd14: r0 = LoadClassIdInstr(r1)
    //     0x12ffd14: ldur            x0, [x1, #-1]
    //     0x12ffd18: ubfx            x0, x0, #0xc, #0x14
    // 0x12ffd1c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ffd1c: sub             lr, x0, #1, lsl #12
    //     0x12ffd20: ldr             lr, [x21, lr, lsl #3]
    //     0x12ffd24: blr             lr
    // 0x12ffd28: mov             x1, x0
    // 0x12ffd2c: ldur            x0, [fp, #-0x20]
    // 0x12ffd30: ldur            x2, [fp, #-0x18]
    // 0x12ffd34: r0 = toRRect()
    //     0x12ffd34: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ffd38: stur            x0, [fp, #-8]
    // 0x12ffd3c: LoadField: d0 = r0->field_b
    //     0x12ffd3c: ldur            d0, [x0, #0xb]
    // 0x12ffd40: fcvt            s1, d0
    // 0x12ffd44: stur            d1, [fp, #-0x48]
    // 0x12ffd48: r4 = 24
    //     0x12ffd48: mov             x4, #0x18
    // 0x12ffd4c: r0 = AllocateFloat32Array()
    //     0x12ffd4c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12ffd50: ldur            d0, [fp, #-0x48]
    // 0x12ffd54: stur            x0, [fp, #-0x10]
    // 0x12ffd58: ArrayStore: r0[0] = d0  ; List_8
    //     0x12ffd58: stur            s0, [x0, #0x17]
    // 0x12ffd5c: ldur            x1, [fp, #-8]
    // 0x12ffd60: LoadField: d0 = r1->field_13
    //     0x12ffd60: ldur            d0, [x1, #0x13]
    // 0x12ffd64: fcvt            s1, d0
    // 0x12ffd68: StoreField: r0->field_1b = d1
    //     0x12ffd68: stur            s1, [x0, #0x1b]
    // 0x12ffd6c: LoadField: d0 = r1->field_1b
    //     0x12ffd6c: ldur            d0, [x1, #0x1b]
    // 0x12ffd70: fcvt            s1, d0
    // 0x12ffd74: StoreField: r0->field_1f = d1
    //     0x12ffd74: stur            s1, [x0, #0x1f]
    // 0x12ffd78: LoadField: d0 = r1->field_23
    //     0x12ffd78: ldur            d0, [x1, #0x23]
    // 0x12ffd7c: fcvt            s1, d0
    // 0x12ffd80: StoreField: r0->field_23 = d1
    //     0x12ffd80: stur            s1, [x0, #0x23]
    // 0x12ffd84: LoadField: d0 = r1->field_2b
    //     0x12ffd84: ldur            d0, [x1, #0x2b]
    // 0x12ffd88: fcvt            s1, d0
    // 0x12ffd8c: StoreField: r0->field_27 = d1
    //     0x12ffd8c: stur            s1, [x0, #0x27]
    // 0x12ffd90: LoadField: d0 = r1->field_33
    //     0x12ffd90: ldur            d0, [x1, #0x33]
    // 0x12ffd94: fcvt            s1, d0
    // 0x12ffd98: StoreField: r0->field_2b = d1
    //     0x12ffd98: stur            s1, [x0, #0x2b]
    // 0x12ffd9c: LoadField: d0 = r1->field_3b
    //     0x12ffd9c: ldur            d0, [x1, #0x3b]
    // 0x12ffda0: fcvt            s1, d0
    // 0x12ffda4: StoreField: r0->field_2f = d1
    //     0x12ffda4: stur            s1, [x0, #0x2f]
    // 0x12ffda8: LoadField: d0 = r1->field_43
    //     0x12ffda8: ldur            d0, [x1, #0x43]
    // 0x12ffdac: fcvt            s1, d0
    // 0x12ffdb0: StoreField: r0->field_33 = d1
    //     0x12ffdb0: stur            s1, [x0, #0x33]
    // 0x12ffdb4: LoadField: d0 = r1->field_4b
    //     0x12ffdb4: ldur            d0, [x1, #0x4b]
    // 0x12ffdb8: fcvt            s1, d0
    // 0x12ffdbc: StoreField: r0->field_37 = d1
    //     0x12ffdbc: stur            s1, [x0, #0x37]
    // 0x12ffdc0: LoadField: d0 = r1->field_53
    //     0x12ffdc0: ldur            d0, [x1, #0x53]
    // 0x12ffdc4: fcvt            s1, d0
    // 0x12ffdc8: StoreField: r0->field_3b = d1
    //     0x12ffdc8: stur            s1, [x0, #0x3b]
    // 0x12ffdcc: LoadField: d0 = r1->field_5b
    //     0x12ffdcc: ldur            d0, [x1, #0x5b]
    // 0x12ffdd0: fcvt            s1, d0
    // 0x12ffdd4: StoreField: r0->field_3f = d1
    //     0x12ffdd4: stur            s1, [x0, #0x3f]
    // 0x12ffdd8: LoadField: d0 = r1->field_63
    //     0x12ffdd8: ldur            d0, [x1, #0x63]
    // 0x12ffddc: fcvt            s1, d0
    // 0x12ffde0: StoreField: r0->field_43 = d1
    //     0x12ffde0: stur            s1, [x0, #0x43]
    // 0x12ffde4: ldur            x2, [fp, #-0x20]
    // 0x12ffde8: LoadField: r1 = r2->field_7
    //     0x12ffde8: ldur            w1, [x2, #7]
    // 0x12ffdec: DecompressPointer r1
    //     0x12ffdec: add             x1, x1, HEAP, lsl #32
    // 0x12ffdf0: cmp             w1, NULL
    // 0x12ffdf4: b.eq            #0x12ffe54
    // 0x12ffdf8: LoadField: r3 = r1->field_7
    //     0x12ffdf8: ldur            x3, [x1, #7]
    // 0x12ffdfc: ldr             x1, [x3]
    // 0x12ffe00: cbz             x1, #0x12ffe38
    // 0x12ffe04: mov             x3, x1
    // 0x12ffe08: stur            x3, [fp, #-0x40]
    // 0x12ffe0c: r1 = <Never>
    //     0x12ffe0c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12ffe10: r0 = Pointer()
    //     0x12ffe10: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12ffe14: mov             x1, x0
    // 0x12ffe18: ldur            x0, [fp, #-0x40]
    // 0x12ffe1c: StoreField: r1->field_7 = r0
    //     0x12ffe1c: stur            x0, [x1, #7]
    // 0x12ffe20: ldur            x2, [fp, #-0x10]
    // 0x12ffe24: r0 = __addRRect$Method$FfiNative()
    //     0x12ffe24: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x12ffe28: ldur            x0, [fp, #-0x20]
    // 0x12ffe2c: LeaveFrame
    //     0x12ffe2c: mov             SP, fp
    //     0x12ffe30: ldp             fp, lr, [SP], #0x10
    // 0x12ffe34: ret
    //     0x12ffe34: ret             
    // 0x12ffe38: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12ffe38: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12ffe3c: str             x16, [SP]
    // 0x12ffe40: r0 = _throwNew()
    //     0x12ffe40: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12ffe44: brk             #0
    // 0x12ffe48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ffe48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ffe4c: b               #0x12ffc0c
    // 0x12ffe50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12ffe50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12ffe54: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12ffe54: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1301674, size: 0x54
    // 0x1301674: EnterFrame
    //     0x1301674: stp             fp, lr, [SP, #-0x10]!
    //     0x1301678: mov             fp, SP
    // 0x130167c: AllocStack(0x10)
    //     0x130167c: sub             SP, SP, #0x10
    // 0x1301680: cmp             w2, NULL
    // 0x1301684: b.ne            #0x1301694
    // 0x1301688: LoadField: r0 = r1->field_7
    //     0x1301688: ldur            w0, [x1, #7]
    // 0x130168c: DecompressPointer r0
    //     0x130168c: add             x0, x0, HEAP, lsl #32
    // 0x1301690: b               #0x1301698
    // 0x1301694: mov             x0, x2
    // 0x1301698: stur            x0, [fp, #-0x10]
    // 0x130169c: LoadField: r2 = r1->field_b
    //     0x130169c: ldur            w2, [x1, #0xb]
    // 0x13016a0: DecompressPointer r2
    //     0x13016a0: add             x2, x2, HEAP, lsl #32
    // 0x13016a4: stur            x2, [fp, #-8]
    // 0x13016a8: r0 = RoundedRectangleBorder()
    //     0x13016a8: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x13016ac: ldur            x1, [fp, #-8]
    // 0x13016b0: StoreField: r0->field_b = r1
    //     0x13016b0: stur            w1, [x0, #0xb]
    // 0x13016b4: ldur            x1, [fp, #-0x10]
    // 0x13016b8: StoreField: r0->field_7 = r1
    //     0x13016b8: stur            w1, [x0, #7]
    // 0x13016bc: LeaveFrame
    //     0x13016bc: mov             SP, fp
    //     0x13016c0: ldp             fp, lr, [SP], #0x10
    // 0x13016c4: ret
    //     0x13016c4: ret             
  }
}

// class id: 3030, size: 0xc, field offset: 0xc
abstract class _RRectLikeBorder extends OutlinedBorder {
}
