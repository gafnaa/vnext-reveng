// lib: , url: package:flutter/src/painting/edge_insets.dart

// class id: 1048993, size: 0x8
class :: {
}

// class id: 2937, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class EdgeInsetsGeometry extends Object {

  get _ horizontal(/* No info */) {
    // ** addr: 0xb17264, size: 0xa8
    // 0xb17264: r0 = LoadClassIdInstr(r1)
    //     0xb17264: ldur            x0, [x1, #-1]
    //     0xb17268: ubfx            x0, x0, #0xc, #0x14
    // 0xb1726c: cmp             x0, #0xb7a
    // 0xb17270: b.ne            #0xb1727c
    // 0xb17274: LoadField: d1 = r1->field_7
    //     0xb17274: ldur            d1, [x1, #7]
    // 0xb17278: b               #0xb17290
    // 0xb1727c: cmp             x0, #0xb7b
    // 0xb17280: b.ne            #0xb1728c
    // 0xb17284: d1 = 0.000000
    //     0xb17284: eor             v1.16b, v1.16b, v1.16b
    // 0xb17288: b               #0xb17290
    // 0xb1728c: LoadField: d1 = r1->field_7
    //     0xb1728c: ldur            d1, [x1, #7]
    // 0xb17290: cmp             x0, #0xb7a
    // 0xb17294: b.ne            #0xb172a0
    // 0xb17298: LoadField: d2 = r1->field_f
    //     0xb17298: ldur            d2, [x1, #0xf]
    // 0xb1729c: b               #0xb172b4
    // 0xb172a0: cmp             x0, #0xb7b
    // 0xb172a4: b.ne            #0xb172b0
    // 0xb172a8: d2 = 0.000000
    //     0xb172a8: eor             v2.16b, v2.16b, v2.16b
    // 0xb172ac: b               #0xb172b4
    // 0xb172b0: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb172b0: ldur            d2, [x1, #0x17]
    // 0xb172b4: fadd            d3, d1, d2
    // 0xb172b8: cmp             x0, #0xb7a
    // 0xb172bc: b.ne            #0xb172c8
    // 0xb172c0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb172c0: ldur            d1, [x1, #0x17]
    // 0xb172c4: b               #0xb172dc
    // 0xb172c8: cmp             x0, #0xb7b
    // 0xb172cc: b.ne            #0xb172d8
    // 0xb172d0: LoadField: d1 = r1->field_7
    //     0xb172d0: ldur            d1, [x1, #7]
    // 0xb172d4: b               #0xb172dc
    // 0xb172d8: d1 = 0.000000
    //     0xb172d8: eor             v1.16b, v1.16b, v1.16b
    // 0xb172dc: fadd            d2, d3, d1
    // 0xb172e0: cmp             x0, #0xb7a
    // 0xb172e4: b.ne            #0xb172f0
    // 0xb172e8: LoadField: d1 = r1->field_1f
    //     0xb172e8: ldur            d1, [x1, #0x1f]
    // 0xb172ec: b               #0xb17304
    // 0xb172f0: cmp             x0, #0xb7b
    // 0xb172f4: b.ne            #0xb17300
    // 0xb172f8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb172f8: ldur            d1, [x1, #0x17]
    // 0xb172fc: b               #0xb17304
    // 0xb17300: d1 = 0.000000
    //     0xb17300: eor             v1.16b, v1.16b, v1.16b
    // 0xb17304: fadd            d0, d2, d1
    // 0xb17308: ret
    //     0xb17308: ret             
  }
  get _ vertical(/* No info */) {
    // ** addr: 0xb1730c, size: 0x58
    // 0xb1730c: r0 = LoadClassIdInstr(r1)
    //     0xb1730c: ldur            x0, [x1, #-1]
    //     0xb17310: ubfx            x0, x0, #0xc, #0x14
    // 0xb17314: cmp             x0, #0xb7a
    // 0xb17318: b.ne            #0xb17324
    // 0xb1731c: LoadField: d1 = r1->field_27
    //     0xb1731c: ldur            d1, [x1, #0x27]
    // 0xb17320: b               #0xb17338
    // 0xb17324: cmp             x0, #0xb7b
    // 0xb17328: b.ne            #0xb17334
    // 0xb1732c: LoadField: d1 = r1->field_f
    //     0xb1732c: ldur            d1, [x1, #0xf]
    // 0xb17330: b               #0xb17338
    // 0xb17334: LoadField: d1 = r1->field_f
    //     0xb17334: ldur            d1, [x1, #0xf]
    // 0xb17338: cmp             x0, #0xb7a
    // 0xb1733c: b.ne            #0xb17348
    // 0xb17340: LoadField: d2 = r1->field_2f
    //     0xb17340: ldur            d2, [x1, #0x2f]
    // 0xb17344: b               #0xb1735c
    // 0xb17348: cmp             x0, #0xb7b
    // 0xb1734c: b.ne            #0xb17358
    // 0xb17350: LoadField: d2 = r1->field_1f
    //     0xb17350: ldur            d2, [x1, #0x1f]
    // 0xb17354: b               #0xb1735c
    // 0xb17358: LoadField: d2 = r1->field_1f
    //     0xb17358: ldur            d2, [x1, #0x1f]
    // 0xb1735c: fadd            d0, d1, d2
    // 0xb17360: ret
    //     0xb17360: ret             
  }
  get _ collapsedSize(/* No info */) {
    // ** addr: 0xb7a270, size: 0x60
    // 0xb7a270: EnterFrame
    //     0xb7a270: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a274: mov             fp, SP
    // 0xb7a278: AllocStack(0x18)
    //     0xb7a278: sub             SP, SP, #0x18
    // 0xb7a27c: SetupParameters(EdgeInsetsGeometry this /* r1 => r0, fp-0x8 */)
    //     0xb7a27c: mov             x0, x1
    //     0xb7a280: stur            x1, [fp, #-8]
    // 0xb7a284: CheckStackOverflow
    //     0xb7a284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a288: cmp             SP, x16
    //     0xb7a28c: b.ls            #0xb7a2c8
    // 0xb7a290: mov             x1, x0
    // 0xb7a294: r0 = horizontal()
    //     0xb7a294: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb7a298: ldur            x1, [fp, #-8]
    // 0xb7a29c: stur            d0, [fp, #-0x10]
    // 0xb7a2a0: r0 = vertical()
    //     0xb7a2a0: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb7a2a4: stur            d0, [fp, #-0x18]
    // 0xb7a2a8: r0 = Size()
    //     0xb7a2a8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb7a2ac: ldur            d0, [fp, #-0x10]
    // 0xb7a2b0: StoreField: r0->field_7 = d0
    //     0xb7a2b0: stur            d0, [x0, #7]
    // 0xb7a2b4: ldur            d0, [fp, #-0x18]
    // 0xb7a2b8: StoreField: r0->field_f = d0
    //     0xb7a2b8: stur            d0, [x0, #0xf]
    // 0xb7a2bc: LeaveFrame
    //     0xb7a2bc: mov             SP, fp
    //     0xb7a2c0: ldp             fp, lr, [SP], #0x10
    // 0xb7a2c4: ret
    //     0xb7a2c4: ret             
    // 0xb7a2c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a2c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a2cc: b               #0xb7a290
  }
  _ along(/* No info */) {
    // ** addr: 0xbeb014, size: 0x40
    // 0xbeb014: EnterFrame
    //     0xbeb014: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb018: mov             fp, SP
    // 0xbeb01c: CheckStackOverflow
    //     0xbeb01c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb020: cmp             SP, x16
    //     0xbeb024: b.ls            #0xbeb04c
    // 0xbeb028: LoadField: r0 = r2->field_7
    //     0xbeb028: ldur            x0, [x2, #7]
    // 0xbeb02c: cmp             x0, #0
    // 0xbeb030: b.gt            #0xbeb03c
    // 0xbeb034: r0 = horizontal()
    //     0xbeb034: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xbeb038: b               #0xbeb040
    // 0xbeb03c: r0 = vertical()
    //     0xbeb03c: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xbeb040: LeaveFrame
    //     0xbeb040: mov             SP, fp
    //     0xbeb044: ldp             fp, lr, [SP], #0x10
    // 0xbeb048: ret
    //     0xbeb048: ret             
    // 0xbeb04c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb04c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb050: b               #0xbeb028
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1140de0, size: 0xabc
    // 0x1140de0: EnterFrame
    //     0x1140de0: stp             fp, lr, [SP, #-0x10]!
    //     0x1140de4: mov             fp, SP
    // 0x1140de8: AllocStack(0x80)
    //     0x1140de8: sub             SP, SP, #0x80
    // 0x1140dec: SetupParameters(dynamic _ /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r4, fp-0x20 */, dynamic _ /* r3 => r0, fp-0x28 */)
    //     0x1140dec: mov             x5, x1
    //     0x1140df0: mov             x4, x2
    //     0x1140df4: mov             x0, x3
    //     0x1140df8: stur            x1, [fp, #-0x18]
    //     0x1140dfc: stur            x2, [fp, #-0x20]
    //     0x1140e00: stur            x3, [fp, #-0x28]
    // 0x1140e04: CheckStackOverflow
    //     0x1140e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1140e08: cmp             SP, x16
    //     0x1140e0c: b.ls            #0x1141680
    // 0x1140e10: cmp             w5, w4
    // 0x1140e14: b.ne            #0x1140e28
    // 0x1140e18: mov             x0, x5
    // 0x1140e1c: LeaveFrame
    //     0x1140e1c: mov             SP, fp
    //     0x1140e20: ldp             fp, lr, [SP], #0x10
    // 0x1140e24: ret
    //     0x1140e24: ret             
    // 0x1140e28: cmp             w5, NULL
    // 0x1140e2c: b.ne            #0x1140f94
    // 0x1140e30: cmp             w4, NULL
    // 0x1140e34: b.eq            #0x1141688
    // 0x1140e38: r1 = LoadClassIdInstr(r4)
    //     0x1140e38: ldur            x1, [x4, #-1]
    //     0x1140e3c: ubfx            x1, x1, #0xc, #0x14
    // 0x1140e40: cmp             x1, #0xb7a
    // 0x1140e44: b.ne            #0x1140ecc
    // 0x1140e48: LoadField: d0 = r4->field_7
    //     0x1140e48: ldur            d0, [x4, #7]
    // 0x1140e4c: LoadField: d1 = r0->field_7
    //     0x1140e4c: ldur            d1, [x0, #7]
    // 0x1140e50: fmul            d2, d0, d1
    // 0x1140e54: stur            d2, [fp, #-0x80]
    // 0x1140e58: LoadField: d0 = r4->field_f
    //     0x1140e58: ldur            d0, [x4, #0xf]
    // 0x1140e5c: fmul            d3, d0, d1
    // 0x1140e60: stur            d3, [fp, #-0x78]
    // 0x1140e64: ArrayLoad: d0 = r4[0]  ; List_8
    //     0x1140e64: ldur            d0, [x4, #0x17]
    // 0x1140e68: fmul            d4, d0, d1
    // 0x1140e6c: stur            d4, [fp, #-0x70]
    // 0x1140e70: LoadField: d0 = r4->field_1f
    //     0x1140e70: ldur            d0, [x4, #0x1f]
    // 0x1140e74: fmul            d5, d0, d1
    // 0x1140e78: stur            d5, [fp, #-0x68]
    // 0x1140e7c: LoadField: d0 = r4->field_27
    //     0x1140e7c: ldur            d0, [x4, #0x27]
    // 0x1140e80: fmul            d6, d0, d1
    // 0x1140e84: stur            d6, [fp, #-0x60]
    // 0x1140e88: LoadField: d0 = r4->field_2f
    //     0x1140e88: ldur            d0, [x4, #0x2f]
    // 0x1140e8c: fmul            d7, d0, d1
    // 0x1140e90: stur            d7, [fp, #-0x58]
    // 0x1140e94: r0 = _MixedEdgeInsets()
    //     0x1140e94: bl              #0x1141d28  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x1140e98: ldur            d0, [fp, #-0x80]
    // 0x1140e9c: StoreField: r0->field_7 = d0
    //     0x1140e9c: stur            d0, [x0, #7]
    // 0x1140ea0: ldur            d0, [fp, #-0x78]
    // 0x1140ea4: StoreField: r0->field_f = d0
    //     0x1140ea4: stur            d0, [x0, #0xf]
    // 0x1140ea8: ldur            d0, [fp, #-0x70]
    // 0x1140eac: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140eac: stur            d0, [x0, #0x17]
    // 0x1140eb0: ldur            d0, [fp, #-0x68]
    // 0x1140eb4: StoreField: r0->field_1f = d0
    //     0x1140eb4: stur            d0, [x0, #0x1f]
    // 0x1140eb8: ldur            d0, [fp, #-0x60]
    // 0x1140ebc: StoreField: r0->field_27 = d0
    //     0x1140ebc: stur            d0, [x0, #0x27]
    // 0x1140ec0: ldur            d0, [fp, #-0x58]
    // 0x1140ec4: StoreField: r0->field_2f = d0
    //     0x1140ec4: stur            d0, [x0, #0x2f]
    // 0x1140ec8: b               #0x1140f88
    // 0x1140ecc: cmp             x1, #0xb7b
    // 0x1140ed0: b.ne            #0x1140f30
    // 0x1140ed4: LoadField: d0 = r4->field_7
    //     0x1140ed4: ldur            d0, [x4, #7]
    // 0x1140ed8: LoadField: d1 = r0->field_7
    //     0x1140ed8: ldur            d1, [x0, #7]
    // 0x1140edc: fmul            d2, d0, d1
    // 0x1140ee0: stur            d2, [fp, #-0x70]
    // 0x1140ee4: LoadField: d0 = r4->field_f
    //     0x1140ee4: ldur            d0, [x4, #0xf]
    // 0x1140ee8: fmul            d3, d0, d1
    // 0x1140eec: stur            d3, [fp, #-0x68]
    // 0x1140ef0: ArrayLoad: d0 = r4[0]  ; List_8
    //     0x1140ef0: ldur            d0, [x4, #0x17]
    // 0x1140ef4: fmul            d4, d0, d1
    // 0x1140ef8: stur            d4, [fp, #-0x60]
    // 0x1140efc: LoadField: d0 = r4->field_1f
    //     0x1140efc: ldur            d0, [x4, #0x1f]
    // 0x1140f00: fmul            d5, d0, d1
    // 0x1140f04: stur            d5, [fp, #-0x58]
    // 0x1140f08: r0 = EdgeInsetsDirectional()
    //     0x1140f08: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x1140f0c: ldur            d0, [fp, #-0x70]
    // 0x1140f10: StoreField: r0->field_7 = d0
    //     0x1140f10: stur            d0, [x0, #7]
    // 0x1140f14: ldur            d0, [fp, #-0x68]
    // 0x1140f18: StoreField: r0->field_f = d0
    //     0x1140f18: stur            d0, [x0, #0xf]
    // 0x1140f1c: ldur            d0, [fp, #-0x60]
    // 0x1140f20: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140f20: stur            d0, [x0, #0x17]
    // 0x1140f24: ldur            d0, [fp, #-0x58]
    // 0x1140f28: StoreField: r0->field_1f = d0
    //     0x1140f28: stur            d0, [x0, #0x1f]
    // 0x1140f2c: b               #0x1140f88
    // 0x1140f30: LoadField: d0 = r4->field_7
    //     0x1140f30: ldur            d0, [x4, #7]
    // 0x1140f34: LoadField: d1 = r0->field_7
    //     0x1140f34: ldur            d1, [x0, #7]
    // 0x1140f38: fmul            d2, d0, d1
    // 0x1140f3c: stur            d2, [fp, #-0x70]
    // 0x1140f40: LoadField: d0 = r4->field_f
    //     0x1140f40: ldur            d0, [x4, #0xf]
    // 0x1140f44: fmul            d3, d0, d1
    // 0x1140f48: stur            d3, [fp, #-0x68]
    // 0x1140f4c: ArrayLoad: d0 = r4[0]  ; List_8
    //     0x1140f4c: ldur            d0, [x4, #0x17]
    // 0x1140f50: fmul            d4, d0, d1
    // 0x1140f54: stur            d4, [fp, #-0x60]
    // 0x1140f58: LoadField: d0 = r4->field_1f
    //     0x1140f58: ldur            d0, [x4, #0x1f]
    // 0x1140f5c: fmul            d5, d0, d1
    // 0x1140f60: stur            d5, [fp, #-0x58]
    // 0x1140f64: r0 = EdgeInsets()
    //     0x1140f64: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1140f68: ldur            d0, [fp, #-0x70]
    // 0x1140f6c: StoreField: r0->field_7 = d0
    //     0x1140f6c: stur            d0, [x0, #7]
    // 0x1140f70: ldur            d0, [fp, #-0x68]
    // 0x1140f74: StoreField: r0->field_f = d0
    //     0x1140f74: stur            d0, [x0, #0xf]
    // 0x1140f78: ldur            d0, [fp, #-0x60]
    // 0x1140f7c: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140f7c: stur            d0, [x0, #0x17]
    // 0x1140f80: ldur            d0, [fp, #-0x58]
    // 0x1140f84: StoreField: r0->field_1f = d0
    //     0x1140f84: stur            d0, [x0, #0x1f]
    // 0x1140f88: LeaveFrame
    //     0x1140f88: mov             SP, fp
    //     0x1140f8c: ldp             fp, lr, [SP], #0x10
    // 0x1140f90: ret
    //     0x1140f90: ret             
    // 0x1140f94: cmp             w4, NULL
    // 0x1140f98: b.ne            #0x11410f8
    // 0x1140f9c: d0 = 1.000000
    //     0x1140f9c: fmov            d0, #1.00000000
    // 0x1140fa0: LoadField: d1 = r0->field_7
    //     0x1140fa0: ldur            d1, [x0, #7]
    // 0x1140fa4: fsub            d2, d0, d1
    // 0x1140fa8: r0 = LoadClassIdInstr(r5)
    //     0x1140fa8: ldur            x0, [x5, #-1]
    //     0x1140fac: ubfx            x0, x0, #0xc, #0x14
    // 0x1140fb0: cmp             x0, #0xb7a
    // 0x1140fb4: b.ne            #0x1141038
    // 0x1140fb8: LoadField: d0 = r5->field_7
    //     0x1140fb8: ldur            d0, [x5, #7]
    // 0x1140fbc: fmul            d1, d0, d2
    // 0x1140fc0: stur            d1, [fp, #-0x80]
    // 0x1140fc4: LoadField: d0 = r5->field_f
    //     0x1140fc4: ldur            d0, [x5, #0xf]
    // 0x1140fc8: fmul            d3, d0, d2
    // 0x1140fcc: stur            d3, [fp, #-0x78]
    // 0x1140fd0: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x1140fd0: ldur            d0, [x5, #0x17]
    // 0x1140fd4: fmul            d4, d0, d2
    // 0x1140fd8: stur            d4, [fp, #-0x70]
    // 0x1140fdc: LoadField: d0 = r5->field_1f
    //     0x1140fdc: ldur            d0, [x5, #0x1f]
    // 0x1140fe0: fmul            d5, d0, d2
    // 0x1140fe4: stur            d5, [fp, #-0x68]
    // 0x1140fe8: LoadField: d0 = r5->field_27
    //     0x1140fe8: ldur            d0, [x5, #0x27]
    // 0x1140fec: fmul            d6, d0, d2
    // 0x1140ff0: stur            d6, [fp, #-0x60]
    // 0x1140ff4: LoadField: d0 = r5->field_2f
    //     0x1140ff4: ldur            d0, [x5, #0x2f]
    // 0x1140ff8: fmul            d7, d0, d2
    // 0x1140ffc: stur            d7, [fp, #-0x58]
    // 0x1141000: r0 = _MixedEdgeInsets()
    //     0x1141000: bl              #0x1141d28  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x1141004: ldur            d0, [fp, #-0x80]
    // 0x1141008: StoreField: r0->field_7 = d0
    //     0x1141008: stur            d0, [x0, #7]
    // 0x114100c: ldur            d0, [fp, #-0x78]
    // 0x1141010: StoreField: r0->field_f = d0
    //     0x1141010: stur            d0, [x0, #0xf]
    // 0x1141014: ldur            d0, [fp, #-0x70]
    // 0x1141018: ArrayStore: r0[0] = d0  ; List_8
    //     0x1141018: stur            d0, [x0, #0x17]
    // 0x114101c: ldur            d0, [fp, #-0x68]
    // 0x1141020: StoreField: r0->field_1f = d0
    //     0x1141020: stur            d0, [x0, #0x1f]
    // 0x1141024: ldur            d0, [fp, #-0x60]
    // 0x1141028: StoreField: r0->field_27 = d0
    //     0x1141028: stur            d0, [x0, #0x27]
    // 0x114102c: ldur            d0, [fp, #-0x58]
    // 0x1141030: StoreField: r0->field_2f = d0
    //     0x1141030: stur            d0, [x0, #0x2f]
    // 0x1141034: b               #0x11410ec
    // 0x1141038: cmp             x0, #0xb7b
    // 0x114103c: b.ne            #0x1141098
    // 0x1141040: LoadField: d0 = r5->field_7
    //     0x1141040: ldur            d0, [x5, #7]
    // 0x1141044: fmul            d1, d0, d2
    // 0x1141048: stur            d1, [fp, #-0x70]
    // 0x114104c: LoadField: d0 = r5->field_f
    //     0x114104c: ldur            d0, [x5, #0xf]
    // 0x1141050: fmul            d3, d0, d2
    // 0x1141054: stur            d3, [fp, #-0x68]
    // 0x1141058: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x1141058: ldur            d0, [x5, #0x17]
    // 0x114105c: fmul            d4, d0, d2
    // 0x1141060: stur            d4, [fp, #-0x60]
    // 0x1141064: LoadField: d0 = r5->field_1f
    //     0x1141064: ldur            d0, [x5, #0x1f]
    // 0x1141068: fmul            d5, d0, d2
    // 0x114106c: stur            d5, [fp, #-0x58]
    // 0x1141070: r0 = EdgeInsetsDirectional()
    //     0x1141070: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x1141074: ldur            d0, [fp, #-0x70]
    // 0x1141078: StoreField: r0->field_7 = d0
    //     0x1141078: stur            d0, [x0, #7]
    // 0x114107c: ldur            d0, [fp, #-0x68]
    // 0x1141080: StoreField: r0->field_f = d0
    //     0x1141080: stur            d0, [x0, #0xf]
    // 0x1141084: ldur            d0, [fp, #-0x60]
    // 0x1141088: ArrayStore: r0[0] = d0  ; List_8
    //     0x1141088: stur            d0, [x0, #0x17]
    // 0x114108c: ldur            d0, [fp, #-0x58]
    // 0x1141090: StoreField: r0->field_1f = d0
    //     0x1141090: stur            d0, [x0, #0x1f]
    // 0x1141094: b               #0x11410ec
    // 0x1141098: LoadField: d0 = r5->field_7
    //     0x1141098: ldur            d0, [x5, #7]
    // 0x114109c: fmul            d1, d0, d2
    // 0x11410a0: stur            d1, [fp, #-0x70]
    // 0x11410a4: LoadField: d0 = r5->field_f
    //     0x11410a4: ldur            d0, [x5, #0xf]
    // 0x11410a8: fmul            d3, d0, d2
    // 0x11410ac: stur            d3, [fp, #-0x68]
    // 0x11410b0: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x11410b0: ldur            d0, [x5, #0x17]
    // 0x11410b4: fmul            d4, d0, d2
    // 0x11410b8: stur            d4, [fp, #-0x60]
    // 0x11410bc: LoadField: d0 = r5->field_1f
    //     0x11410bc: ldur            d0, [x5, #0x1f]
    // 0x11410c0: fmul            d5, d0, d2
    // 0x11410c4: stur            d5, [fp, #-0x58]
    // 0x11410c8: r0 = EdgeInsets()
    //     0x11410c8: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x11410cc: ldur            d0, [fp, #-0x70]
    // 0x11410d0: StoreField: r0->field_7 = d0
    //     0x11410d0: stur            d0, [x0, #7]
    // 0x11410d4: ldur            d0, [fp, #-0x68]
    // 0x11410d8: StoreField: r0->field_f = d0
    //     0x11410d8: stur            d0, [x0, #0xf]
    // 0x11410dc: ldur            d0, [fp, #-0x60]
    // 0x11410e0: ArrayStore: r0[0] = d0  ; List_8
    //     0x11410e0: stur            d0, [x0, #0x17]
    // 0x11410e4: ldur            d0, [fp, #-0x58]
    // 0x11410e8: StoreField: r0->field_1f = d0
    //     0x11410e8: stur            d0, [x0, #0x1f]
    // 0x11410ec: LeaveFrame
    //     0x11410ec: mov             SP, fp
    //     0x11410f0: ldp             fp, lr, [SP], #0x10
    // 0x11410f4: ret
    //     0x11410f4: ret             
    // 0x11410f8: r6 = LoadClassIdInstr(r5)
    //     0x11410f8: ldur            x6, [x5, #-1]
    //     0x11410fc: ubfx            x6, x6, #0xc, #0x14
    // 0x1141100: stur            x6, [fp, #-0x10]
    // 0x1141104: cmp             x6, #0xb7c
    // 0x1141108: b.ne            #0x1141138
    // 0x114110c: r1 = LoadClassIdInstr(r4)
    //     0x114110c: ldur            x1, [x4, #-1]
    //     0x1141110: ubfx            x1, x1, #0xc, #0x14
    // 0x1141114: cmp             x1, #0xb7c
    // 0x1141118: b.ne            #0x1141138
    // 0x114111c: LoadField: d0 = r0->field_7
    //     0x114111c: ldur            d0, [x0, #7]
    // 0x1141120: mov             x1, x5
    // 0x1141124: mov             x2, x4
    // 0x1141128: r0 = lerp()
    //     0x1141128: bl              #0x868640  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0x114112c: LeaveFrame
    //     0x114112c: mov             SP, fp
    //     0x1141130: ldp             fp, lr, [SP], #0x10
    // 0x1141134: ret
    //     0x1141134: ret             
    // 0x1141138: cmp             x6, #0xb7b
    // 0x114113c: b.ne            #0x114116c
    // 0x1141140: r1 = LoadClassIdInstr(r4)
    //     0x1141140: ldur            x1, [x4, #-1]
    //     0x1141144: ubfx            x1, x1, #0xc, #0x14
    // 0x1141148: cmp             x1, #0xb7b
    // 0x114114c: b.ne            #0x114116c
    // 0x1141150: LoadField: d0 = r0->field_7
    //     0x1141150: ldur            d0, [x0, #7]
    // 0x1141154: mov             x1, x5
    // 0x1141158: mov             x2, x4
    // 0x114115c: r0 = lerp()
    //     0x114115c: bl              #0x114195c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::lerp
    // 0x1141160: LeaveFrame
    //     0x1141160: mov             SP, fp
    //     0x1141164: ldp             fp, lr, [SP], #0x10
    // 0x1141168: ret
    //     0x1141168: ret             
    // 0x114116c: cmp             x6, #0xb7a
    // 0x1141170: b.ne            #0x114117c
    // 0x1141174: LoadField: d0 = r5->field_7
    //     0x1141174: ldur            d0, [x5, #7]
    // 0x1141178: b               #0x1141190
    // 0x114117c: cmp             x6, #0xb7b
    // 0x1141180: b.ne            #0x114118c
    // 0x1141184: d0 = 0.000000
    //     0x1141184: eor             v0.16b, v0.16b, v0.16b
    // 0x1141188: b               #0x1141190
    // 0x114118c: LoadField: d0 = r5->field_7
    //     0x114118c: ldur            d0, [x5, #7]
    // 0x1141190: r7 = LoadClassIdInstr(r4)
    //     0x1141190: ldur            x7, [x4, #-1]
    //     0x1141194: ubfx            x7, x7, #0xc, #0x14
    // 0x1141198: stur            x7, [fp, #-8]
    // 0x114119c: cmp             x7, #0xb7a
    // 0x11411a0: b.ne            #0x11411ac
    // 0x11411a4: LoadField: d1 = r4->field_7
    //     0x11411a4: ldur            d1, [x4, #7]
    // 0x11411a8: b               #0x11411c0
    // 0x11411ac: cmp             x7, #0xb7b
    // 0x11411b0: b.ne            #0x11411bc
    // 0x11411b4: d1 = 0.000000
    //     0x11411b4: eor             v1.16b, v1.16b, v1.16b
    // 0x11411b8: b               #0x11411c0
    // 0x11411bc: LoadField: d1 = r4->field_7
    //     0x11411bc: ldur            d1, [x4, #7]
    // 0x11411c0: r1 = inline_Allocate_Double()
    //     0x11411c0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11411c4: add             x1, x1, #0x10
    //     0x11411c8: cmp             x2, x1
    //     0x11411cc: b.ls            #0x114168c
    //     0x11411d0: str             x1, [THR, #0x60]  ; THR::top
    //     0x11411d4: sub             x1, x1, #0xf
    //     0x11411d8: mov             x2, #0xe19c
    //     0x11411dc: movk            x2, #3, lsl #16
    //     0x11411e0: stur            x2, [x1, #-1]
    // 0x11411e4: dmb             ishst
    // 0x11411e8: StoreField: r1->field_7 = d0
    //     0x11411e8: stur            d0, [x1, #7]
    // 0x11411ec: r2 = inline_Allocate_Double()
    //     0x11411ec: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11411f0: add             x2, x2, #0x10
    //     0x11411f4: cmp             x3, x2
    //     0x11411f8: b.ls            #0x11416b8
    //     0x11411fc: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141200: sub             x2, x2, #0xf
    //     0x1141204: mov             x3, #0xe19c
    //     0x1141208: movk            x3, #3, lsl #16
    //     0x114120c: stur            x3, [x2, #-1]
    // 0x1141210: dmb             ishst
    // 0x1141214: StoreField: r2->field_7 = d1
    //     0x1141214: stur            d1, [x2, #7]
    // 0x1141218: mov             x3, x0
    // 0x114121c: r0 = lerpDouble()
    //     0x114121c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141220: mov             x4, x0
    // 0x1141224: ldur            x0, [fp, #-0x10]
    // 0x1141228: stur            x4, [fp, #-0x30]
    // 0x114122c: cmp             x0, #0xb7a
    // 0x1141230: b.ne            #0x1141240
    // 0x1141234: ldur            x5, [fp, #-0x18]
    // 0x1141238: LoadField: d0 = r5->field_f
    //     0x1141238: ldur            d0, [x5, #0xf]
    // 0x114123c: b               #0x1141258
    // 0x1141240: ldur            x5, [fp, #-0x18]
    // 0x1141244: cmp             x0, #0xb7b
    // 0x1141248: b.ne            #0x1141254
    // 0x114124c: d0 = 0.000000
    //     0x114124c: eor             v0.16b, v0.16b, v0.16b
    // 0x1141250: b               #0x1141258
    // 0x1141254: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x1141254: ldur            d0, [x5, #0x17]
    // 0x1141258: ldur            x6, [fp, #-8]
    // 0x114125c: cmp             x6, #0xb7a
    // 0x1141260: b.ne            #0x1141270
    // 0x1141264: ldur            x7, [fp, #-0x20]
    // 0x1141268: LoadField: d1 = r7->field_f
    //     0x1141268: ldur            d1, [x7, #0xf]
    // 0x114126c: b               #0x1141288
    // 0x1141270: ldur            x7, [fp, #-0x20]
    // 0x1141274: cmp             x6, #0xb7b
    // 0x1141278: b.ne            #0x1141284
    // 0x114127c: d1 = 0.000000
    //     0x114127c: eor             v1.16b, v1.16b, v1.16b
    // 0x1141280: b               #0x1141288
    // 0x1141284: ArrayLoad: d1 = r7[0]  ; List_8
    //     0x1141284: ldur            d1, [x7, #0x17]
    // 0x1141288: r1 = inline_Allocate_Double()
    //     0x1141288: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x114128c: add             x1, x1, #0x10
    //     0x1141290: cmp             x2, x1
    //     0x1141294: b.ls            #0x11416e4
    //     0x1141298: str             x1, [THR, #0x60]  ; THR::top
    //     0x114129c: sub             x1, x1, #0xf
    //     0x11412a0: mov             x2, #0xe19c
    //     0x11412a4: movk            x2, #3, lsl #16
    //     0x11412a8: stur            x2, [x1, #-1]
    // 0x11412ac: dmb             ishst
    // 0x11412b0: StoreField: r1->field_7 = d0
    //     0x11412b0: stur            d0, [x1, #7]
    // 0x11412b4: r2 = inline_Allocate_Double()
    //     0x11412b4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11412b8: add             x2, x2, #0x10
    //     0x11412bc: cmp             x3, x2
    //     0x11412c0: b.ls            #0x1141710
    //     0x11412c4: str             x2, [THR, #0x60]  ; THR::top
    //     0x11412c8: sub             x2, x2, #0xf
    //     0x11412cc: mov             x3, #0xe19c
    //     0x11412d0: movk            x3, #3, lsl #16
    //     0x11412d4: stur            x3, [x2, #-1]
    // 0x11412d8: dmb             ishst
    // 0x11412dc: StoreField: r2->field_7 = d1
    //     0x11412dc: stur            d1, [x2, #7]
    // 0x11412e0: ldur            x3, [fp, #-0x28]
    // 0x11412e4: r0 = lerpDouble()
    //     0x11412e4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11412e8: mov             x4, x0
    // 0x11412ec: ldur            x0, [fp, #-0x10]
    // 0x11412f0: stur            x4, [fp, #-0x38]
    // 0x11412f4: cmp             x0, #0xb7a
    // 0x11412f8: b.ne            #0x1141308
    // 0x11412fc: ldur            x5, [fp, #-0x18]
    // 0x1141300: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x1141300: ldur            d0, [x5, #0x17]
    // 0x1141304: b               #0x1141320
    // 0x1141308: ldur            x5, [fp, #-0x18]
    // 0x114130c: cmp             x0, #0xb7b
    // 0x1141310: b.ne            #0x114131c
    // 0x1141314: LoadField: d0 = r5->field_7
    //     0x1141314: ldur            d0, [x5, #7]
    // 0x1141318: b               #0x1141320
    // 0x114131c: d0 = 0.000000
    //     0x114131c: eor             v0.16b, v0.16b, v0.16b
    // 0x1141320: ldur            x6, [fp, #-8]
    // 0x1141324: cmp             x6, #0xb7a
    // 0x1141328: b.ne            #0x1141338
    // 0x114132c: ldur            x7, [fp, #-0x20]
    // 0x1141330: ArrayLoad: d1 = r7[0]  ; List_8
    //     0x1141330: ldur            d1, [x7, #0x17]
    // 0x1141334: b               #0x1141350
    // 0x1141338: ldur            x7, [fp, #-0x20]
    // 0x114133c: cmp             x6, #0xb7b
    // 0x1141340: b.ne            #0x114134c
    // 0x1141344: LoadField: d1 = r7->field_7
    //     0x1141344: ldur            d1, [x7, #7]
    // 0x1141348: b               #0x1141350
    // 0x114134c: d1 = 0.000000
    //     0x114134c: eor             v1.16b, v1.16b, v1.16b
    // 0x1141350: r1 = inline_Allocate_Double()
    //     0x1141350: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1141354: add             x1, x1, #0x10
    //     0x1141358: cmp             x2, x1
    //     0x114135c: b.ls            #0x114173c
    //     0x1141360: str             x1, [THR, #0x60]  ; THR::top
    //     0x1141364: sub             x1, x1, #0xf
    //     0x1141368: mov             x2, #0xe19c
    //     0x114136c: movk            x2, #3, lsl #16
    //     0x1141370: stur            x2, [x1, #-1]
    // 0x1141374: dmb             ishst
    // 0x1141378: StoreField: r1->field_7 = d0
    //     0x1141378: stur            d0, [x1, #7]
    // 0x114137c: r2 = inline_Allocate_Double()
    //     0x114137c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141380: add             x2, x2, #0x10
    //     0x1141384: cmp             x3, x2
    //     0x1141388: b.ls            #0x1141768
    //     0x114138c: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141390: sub             x2, x2, #0xf
    //     0x1141394: mov             x3, #0xe19c
    //     0x1141398: movk            x3, #3, lsl #16
    //     0x114139c: stur            x3, [x2, #-1]
    // 0x11413a0: dmb             ishst
    // 0x11413a4: StoreField: r2->field_7 = d1
    //     0x11413a4: stur            d1, [x2, #7]
    // 0x11413a8: ldur            x3, [fp, #-0x28]
    // 0x11413ac: r0 = lerpDouble()
    //     0x11413ac: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11413b0: mov             x4, x0
    // 0x11413b4: ldur            x0, [fp, #-0x10]
    // 0x11413b8: stur            x4, [fp, #-0x40]
    // 0x11413bc: cmp             x0, #0xb7a
    // 0x11413c0: b.ne            #0x11413d0
    // 0x11413c4: ldur            x5, [fp, #-0x18]
    // 0x11413c8: LoadField: d0 = r5->field_1f
    //     0x11413c8: ldur            d0, [x5, #0x1f]
    // 0x11413cc: b               #0x11413e8
    // 0x11413d0: ldur            x5, [fp, #-0x18]
    // 0x11413d4: cmp             x0, #0xb7b
    // 0x11413d8: b.ne            #0x11413e4
    // 0x11413dc: ArrayLoad: d0 = r5[0]  ; List_8
    //     0x11413dc: ldur            d0, [x5, #0x17]
    // 0x11413e0: b               #0x11413e8
    // 0x11413e4: d0 = 0.000000
    //     0x11413e4: eor             v0.16b, v0.16b, v0.16b
    // 0x11413e8: ldur            x6, [fp, #-8]
    // 0x11413ec: cmp             x6, #0xb7a
    // 0x11413f0: b.ne            #0x1141400
    // 0x11413f4: ldur            x7, [fp, #-0x20]
    // 0x11413f8: LoadField: d1 = r7->field_1f
    //     0x11413f8: ldur            d1, [x7, #0x1f]
    // 0x11413fc: b               #0x1141418
    // 0x1141400: ldur            x7, [fp, #-0x20]
    // 0x1141404: cmp             x6, #0xb7b
    // 0x1141408: b.ne            #0x1141414
    // 0x114140c: ArrayLoad: d1 = r7[0]  ; List_8
    //     0x114140c: ldur            d1, [x7, #0x17]
    // 0x1141410: b               #0x1141418
    // 0x1141414: d1 = 0.000000
    //     0x1141414: eor             v1.16b, v1.16b, v1.16b
    // 0x1141418: r1 = inline_Allocate_Double()
    //     0x1141418: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x114141c: add             x1, x1, #0x10
    //     0x1141420: cmp             x2, x1
    //     0x1141424: b.ls            #0x1141794
    //     0x1141428: str             x1, [THR, #0x60]  ; THR::top
    //     0x114142c: sub             x1, x1, #0xf
    //     0x1141430: mov             x2, #0xe19c
    //     0x1141434: movk            x2, #3, lsl #16
    //     0x1141438: stur            x2, [x1, #-1]
    // 0x114143c: dmb             ishst
    // 0x1141440: StoreField: r1->field_7 = d0
    //     0x1141440: stur            d0, [x1, #7]
    // 0x1141444: r2 = inline_Allocate_Double()
    //     0x1141444: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141448: add             x2, x2, #0x10
    //     0x114144c: cmp             x3, x2
    //     0x1141450: b.ls            #0x11417c0
    //     0x1141454: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141458: sub             x2, x2, #0xf
    //     0x114145c: mov             x3, #0xe19c
    //     0x1141460: movk            x3, #3, lsl #16
    //     0x1141464: stur            x3, [x2, #-1]
    // 0x1141468: dmb             ishst
    // 0x114146c: StoreField: r2->field_7 = d1
    //     0x114146c: stur            d1, [x2, #7]
    // 0x1141470: ldur            x3, [fp, #-0x28]
    // 0x1141474: r0 = lerpDouble()
    //     0x1141474: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141478: mov             x4, x0
    // 0x114147c: ldur            x0, [fp, #-0x10]
    // 0x1141480: stur            x4, [fp, #-0x48]
    // 0x1141484: cmp             x0, #0xb7a
    // 0x1141488: b.ne            #0x1141498
    // 0x114148c: ldur            x5, [fp, #-0x18]
    // 0x1141490: LoadField: d0 = r5->field_27
    //     0x1141490: ldur            d0, [x5, #0x27]
    // 0x1141494: b               #0x11414b0
    // 0x1141498: ldur            x5, [fp, #-0x18]
    // 0x114149c: cmp             x0, #0xb7b
    // 0x11414a0: b.ne            #0x11414ac
    // 0x11414a4: LoadField: d0 = r5->field_f
    //     0x11414a4: ldur            d0, [x5, #0xf]
    // 0x11414a8: b               #0x11414b0
    // 0x11414ac: LoadField: d0 = r5->field_f
    //     0x11414ac: ldur            d0, [x5, #0xf]
    // 0x11414b0: ldur            x6, [fp, #-8]
    // 0x11414b4: cmp             x6, #0xb7a
    // 0x11414b8: b.ne            #0x11414c8
    // 0x11414bc: ldur            x7, [fp, #-0x20]
    // 0x11414c0: LoadField: d1 = r7->field_27
    //     0x11414c0: ldur            d1, [x7, #0x27]
    // 0x11414c4: b               #0x11414e0
    // 0x11414c8: ldur            x7, [fp, #-0x20]
    // 0x11414cc: cmp             x6, #0xb7b
    // 0x11414d0: b.ne            #0x11414dc
    // 0x11414d4: LoadField: d1 = r7->field_f
    //     0x11414d4: ldur            d1, [x7, #0xf]
    // 0x11414d8: b               #0x11414e0
    // 0x11414dc: LoadField: d1 = r7->field_f
    //     0x11414dc: ldur            d1, [x7, #0xf]
    // 0x11414e0: r1 = inline_Allocate_Double()
    //     0x11414e0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11414e4: add             x1, x1, #0x10
    //     0x11414e8: cmp             x2, x1
    //     0x11414ec: b.ls            #0x11417ec
    //     0x11414f0: str             x1, [THR, #0x60]  ; THR::top
    //     0x11414f4: sub             x1, x1, #0xf
    //     0x11414f8: mov             x2, #0xe19c
    //     0x11414fc: movk            x2, #3, lsl #16
    //     0x1141500: stur            x2, [x1, #-1]
    // 0x1141504: dmb             ishst
    // 0x1141508: StoreField: r1->field_7 = d0
    //     0x1141508: stur            d0, [x1, #7]
    // 0x114150c: r2 = inline_Allocate_Double()
    //     0x114150c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141510: add             x2, x2, #0x10
    //     0x1141514: cmp             x3, x2
    //     0x1141518: b.ls            #0x1141818
    //     0x114151c: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141520: sub             x2, x2, #0xf
    //     0x1141524: mov             x3, #0xe19c
    //     0x1141528: movk            x3, #3, lsl #16
    //     0x114152c: stur            x3, [x2, #-1]
    // 0x1141530: dmb             ishst
    // 0x1141534: StoreField: r2->field_7 = d1
    //     0x1141534: stur            d1, [x2, #7]
    // 0x1141538: ldur            x3, [fp, #-0x28]
    // 0x114153c: r0 = lerpDouble()
    //     0x114153c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141540: mov             x4, x0
    // 0x1141544: ldur            x0, [fp, #-0x10]
    // 0x1141548: stur            x4, [fp, #-0x50]
    // 0x114154c: cmp             x0, #0xb7a
    // 0x1141550: b.ne            #0x1141560
    // 0x1141554: ldur            x1, [fp, #-0x18]
    // 0x1141558: LoadField: d0 = r1->field_2f
    //     0x1141558: ldur            d0, [x1, #0x2f]
    // 0x114155c: b               #0x1141578
    // 0x1141560: ldur            x1, [fp, #-0x18]
    // 0x1141564: cmp             x0, #0xb7b
    // 0x1141568: b.ne            #0x1141574
    // 0x114156c: LoadField: d0 = r1->field_1f
    //     0x114156c: ldur            d0, [x1, #0x1f]
    // 0x1141570: b               #0x1141578
    // 0x1141574: LoadField: d0 = r1->field_1f
    //     0x1141574: ldur            d0, [x1, #0x1f]
    // 0x1141578: ldur            x0, [fp, #-8]
    // 0x114157c: cmp             x0, #0xb7a
    // 0x1141580: b.ne            #0x1141590
    // 0x1141584: ldur            x1, [fp, #-0x20]
    // 0x1141588: LoadField: d1 = r1->field_2f
    //     0x1141588: ldur            d1, [x1, #0x2f]
    // 0x114158c: b               #0x11415a8
    // 0x1141590: ldur            x1, [fp, #-0x20]
    // 0x1141594: cmp             x0, #0xb7b
    // 0x1141598: b.ne            #0x11415a4
    // 0x114159c: LoadField: d1 = r1->field_1f
    //     0x114159c: ldur            d1, [x1, #0x1f]
    // 0x11415a0: b               #0x11415a8
    // 0x11415a4: LoadField: d1 = r1->field_1f
    //     0x11415a4: ldur            d1, [x1, #0x1f]
    // 0x11415a8: ldur            x7, [fp, #-0x30]
    // 0x11415ac: ldur            x6, [fp, #-0x38]
    // 0x11415b0: ldur            x5, [fp, #-0x40]
    // 0x11415b4: ldur            x0, [fp, #-0x48]
    // 0x11415b8: r1 = inline_Allocate_Double()
    //     0x11415b8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11415bc: add             x1, x1, #0x10
    //     0x11415c0: cmp             x2, x1
    //     0x11415c4: b.ls            #0x1141844
    //     0x11415c8: str             x1, [THR, #0x60]  ; THR::top
    //     0x11415cc: sub             x1, x1, #0xf
    //     0x11415d0: mov             x2, #0xe19c
    //     0x11415d4: movk            x2, #3, lsl #16
    //     0x11415d8: stur            x2, [x1, #-1]
    // 0x11415dc: dmb             ishst
    // 0x11415e0: StoreField: r1->field_7 = d0
    //     0x11415e0: stur            d0, [x1, #7]
    // 0x11415e4: r2 = inline_Allocate_Double()
    //     0x11415e4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x11415e8: add             x2, x2, #0x10
    //     0x11415ec: cmp             x3, x2
    //     0x11415f0: b.ls            #0x1141870
    //     0x11415f4: str             x2, [THR, #0x60]  ; THR::top
    //     0x11415f8: sub             x2, x2, #0xf
    //     0x11415fc: mov             x3, #0xe19c
    //     0x1141600: movk            x3, #3, lsl #16
    //     0x1141604: stur            x3, [x2, #-1]
    // 0x1141608: dmb             ishst
    // 0x114160c: StoreField: r2->field_7 = d1
    //     0x114160c: stur            d1, [x2, #7]
    // 0x1141610: ldur            x3, [fp, #-0x28]
    // 0x1141614: r0 = lerpDouble()
    //     0x1141614: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141618: mov             x1, x0
    // 0x114161c: ldur            x0, [fp, #-0x30]
    // 0x1141620: stur            x1, [fp, #-0x18]
    // 0x1141624: LoadField: d0 = r0->field_7
    //     0x1141624: ldur            d0, [x0, #7]
    // 0x1141628: stur            d0, [fp, #-0x58]
    // 0x114162c: r0 = _MixedEdgeInsets()
    //     0x114162c: bl              #0x1141d28  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x1141630: ldur            d0, [fp, #-0x58]
    // 0x1141634: StoreField: r0->field_7 = d0
    //     0x1141634: stur            d0, [x0, #7]
    // 0x1141638: ldur            x1, [fp, #-0x38]
    // 0x114163c: LoadField: d0 = r1->field_7
    //     0x114163c: ldur            d0, [x1, #7]
    // 0x1141640: StoreField: r0->field_f = d0
    //     0x1141640: stur            d0, [x0, #0xf]
    // 0x1141644: ldur            x1, [fp, #-0x40]
    // 0x1141648: LoadField: d0 = r1->field_7
    //     0x1141648: ldur            d0, [x1, #7]
    // 0x114164c: ArrayStore: r0[0] = d0  ; List_8
    //     0x114164c: stur            d0, [x0, #0x17]
    // 0x1141650: ldur            x1, [fp, #-0x48]
    // 0x1141654: LoadField: d0 = r1->field_7
    //     0x1141654: ldur            d0, [x1, #7]
    // 0x1141658: StoreField: r0->field_1f = d0
    //     0x1141658: stur            d0, [x0, #0x1f]
    // 0x114165c: ldur            x1, [fp, #-0x50]
    // 0x1141660: LoadField: d0 = r1->field_7
    //     0x1141660: ldur            d0, [x1, #7]
    // 0x1141664: StoreField: r0->field_27 = d0
    //     0x1141664: stur            d0, [x0, #0x27]
    // 0x1141668: ldur            x1, [fp, #-0x18]
    // 0x114166c: LoadField: d0 = r1->field_7
    //     0x114166c: ldur            d0, [x1, #7]
    // 0x1141670: StoreField: r0->field_2f = d0
    //     0x1141670: stur            d0, [x0, #0x2f]
    // 0x1141674: LeaveFrame
    //     0x1141674: mov             SP, fp
    //     0x1141678: ldp             fp, lr, [SP], #0x10
    // 0x114167c: ret
    //     0x114167c: ret             
    // 0x1141680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1141680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141684: b               #0x1140e10
    // 0x1141688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1141688: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x114168c: stp             q0, q1, [SP, #-0x20]!
    // 0x1141690: stp             x6, x7, [SP, #-0x10]!
    // 0x1141694: stp             x4, x5, [SP, #-0x10]!
    // 0x1141698: SaveReg r0
    //     0x1141698: str             x0, [SP, #-8]!
    // 0x114169c: r0 = AllocateDouble()
    //     0x114169c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11416a0: mov             x1, x0
    // 0x11416a4: RestoreReg r0
    //     0x11416a4: ldr             x0, [SP], #8
    // 0x11416a8: ldp             x4, x5, [SP], #0x10
    // 0x11416ac: ldp             x6, x7, [SP], #0x10
    // 0x11416b0: ldp             q0, q1, [SP], #0x20
    // 0x11416b4: b               #0x11411e8
    // 0x11416b8: SaveReg d1
    //     0x11416b8: str             q1, [SP, #-0x10]!
    // 0x11416bc: stp             x6, x7, [SP, #-0x10]!
    // 0x11416c0: stp             x4, x5, [SP, #-0x10]!
    // 0x11416c4: stp             x0, x1, [SP, #-0x10]!
    // 0x11416c8: r0 = AllocateDouble()
    //     0x11416c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11416cc: mov             x2, x0
    // 0x11416d0: ldp             x0, x1, [SP], #0x10
    // 0x11416d4: ldp             x4, x5, [SP], #0x10
    // 0x11416d8: ldp             x6, x7, [SP], #0x10
    // 0x11416dc: RestoreReg d1
    //     0x11416dc: ldr             q1, [SP], #0x10
    // 0x11416e0: b               #0x1141214
    // 0x11416e4: stp             q0, q1, [SP, #-0x20]!
    // 0x11416e8: stp             x6, x7, [SP, #-0x10]!
    // 0x11416ec: stp             x4, x5, [SP, #-0x10]!
    // 0x11416f0: SaveReg r0
    //     0x11416f0: str             x0, [SP, #-8]!
    // 0x11416f4: r0 = AllocateDouble()
    //     0x11416f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11416f8: mov             x1, x0
    // 0x11416fc: RestoreReg r0
    //     0x11416fc: ldr             x0, [SP], #8
    // 0x1141700: ldp             x4, x5, [SP], #0x10
    // 0x1141704: ldp             x6, x7, [SP], #0x10
    // 0x1141708: ldp             q0, q1, [SP], #0x20
    // 0x114170c: b               #0x11412b0
    // 0x1141710: SaveReg d1
    //     0x1141710: str             q1, [SP, #-0x10]!
    // 0x1141714: stp             x6, x7, [SP, #-0x10]!
    // 0x1141718: stp             x4, x5, [SP, #-0x10]!
    // 0x114171c: stp             x0, x1, [SP, #-0x10]!
    // 0x1141720: r0 = AllocateDouble()
    //     0x1141720: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141724: mov             x2, x0
    // 0x1141728: ldp             x0, x1, [SP], #0x10
    // 0x114172c: ldp             x4, x5, [SP], #0x10
    // 0x1141730: ldp             x6, x7, [SP], #0x10
    // 0x1141734: RestoreReg d1
    //     0x1141734: ldr             q1, [SP], #0x10
    // 0x1141738: b               #0x11412dc
    // 0x114173c: stp             q0, q1, [SP, #-0x20]!
    // 0x1141740: stp             x6, x7, [SP, #-0x10]!
    // 0x1141744: stp             x4, x5, [SP, #-0x10]!
    // 0x1141748: SaveReg r0
    //     0x1141748: str             x0, [SP, #-8]!
    // 0x114174c: r0 = AllocateDouble()
    //     0x114174c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141750: mov             x1, x0
    // 0x1141754: RestoreReg r0
    //     0x1141754: ldr             x0, [SP], #8
    // 0x1141758: ldp             x4, x5, [SP], #0x10
    // 0x114175c: ldp             x6, x7, [SP], #0x10
    // 0x1141760: ldp             q0, q1, [SP], #0x20
    // 0x1141764: b               #0x1141378
    // 0x1141768: SaveReg d1
    //     0x1141768: str             q1, [SP, #-0x10]!
    // 0x114176c: stp             x6, x7, [SP, #-0x10]!
    // 0x1141770: stp             x4, x5, [SP, #-0x10]!
    // 0x1141774: stp             x0, x1, [SP, #-0x10]!
    // 0x1141778: r0 = AllocateDouble()
    //     0x1141778: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114177c: mov             x2, x0
    // 0x1141780: ldp             x0, x1, [SP], #0x10
    // 0x1141784: ldp             x4, x5, [SP], #0x10
    // 0x1141788: ldp             x6, x7, [SP], #0x10
    // 0x114178c: RestoreReg d1
    //     0x114178c: ldr             q1, [SP], #0x10
    // 0x1141790: b               #0x11413a4
    // 0x1141794: stp             q0, q1, [SP, #-0x20]!
    // 0x1141798: stp             x6, x7, [SP, #-0x10]!
    // 0x114179c: stp             x4, x5, [SP, #-0x10]!
    // 0x11417a0: SaveReg r0
    //     0x11417a0: str             x0, [SP, #-8]!
    // 0x11417a4: r0 = AllocateDouble()
    //     0x11417a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11417a8: mov             x1, x0
    // 0x11417ac: RestoreReg r0
    //     0x11417ac: ldr             x0, [SP], #8
    // 0x11417b0: ldp             x4, x5, [SP], #0x10
    // 0x11417b4: ldp             x6, x7, [SP], #0x10
    // 0x11417b8: ldp             q0, q1, [SP], #0x20
    // 0x11417bc: b               #0x1141440
    // 0x11417c0: SaveReg d1
    //     0x11417c0: str             q1, [SP, #-0x10]!
    // 0x11417c4: stp             x6, x7, [SP, #-0x10]!
    // 0x11417c8: stp             x4, x5, [SP, #-0x10]!
    // 0x11417cc: stp             x0, x1, [SP, #-0x10]!
    // 0x11417d0: r0 = AllocateDouble()
    //     0x11417d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11417d4: mov             x2, x0
    // 0x11417d8: ldp             x0, x1, [SP], #0x10
    // 0x11417dc: ldp             x4, x5, [SP], #0x10
    // 0x11417e0: ldp             x6, x7, [SP], #0x10
    // 0x11417e4: RestoreReg d1
    //     0x11417e4: ldr             q1, [SP], #0x10
    // 0x11417e8: b               #0x114146c
    // 0x11417ec: stp             q0, q1, [SP, #-0x20]!
    // 0x11417f0: stp             x6, x7, [SP, #-0x10]!
    // 0x11417f4: stp             x4, x5, [SP, #-0x10]!
    // 0x11417f8: SaveReg r0
    //     0x11417f8: str             x0, [SP, #-8]!
    // 0x11417fc: r0 = AllocateDouble()
    //     0x11417fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141800: mov             x1, x0
    // 0x1141804: RestoreReg r0
    //     0x1141804: ldr             x0, [SP], #8
    // 0x1141808: ldp             x4, x5, [SP], #0x10
    // 0x114180c: ldp             x6, x7, [SP], #0x10
    // 0x1141810: ldp             q0, q1, [SP], #0x20
    // 0x1141814: b               #0x1141508
    // 0x1141818: SaveReg d1
    //     0x1141818: str             q1, [SP, #-0x10]!
    // 0x114181c: stp             x6, x7, [SP, #-0x10]!
    // 0x1141820: stp             x4, x5, [SP, #-0x10]!
    // 0x1141824: stp             x0, x1, [SP, #-0x10]!
    // 0x1141828: r0 = AllocateDouble()
    //     0x1141828: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114182c: mov             x2, x0
    // 0x1141830: ldp             x0, x1, [SP], #0x10
    // 0x1141834: ldp             x4, x5, [SP], #0x10
    // 0x1141838: ldp             x6, x7, [SP], #0x10
    // 0x114183c: RestoreReg d1
    //     0x114183c: ldr             q1, [SP], #0x10
    // 0x1141840: b               #0x1141534
    // 0x1141844: stp             q0, q1, [SP, #-0x20]!
    // 0x1141848: stp             x6, x7, [SP, #-0x10]!
    // 0x114184c: stp             x4, x5, [SP, #-0x10]!
    // 0x1141850: SaveReg r0
    //     0x1141850: str             x0, [SP, #-8]!
    // 0x1141854: r0 = AllocateDouble()
    //     0x1141854: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141858: mov             x1, x0
    // 0x114185c: RestoreReg r0
    //     0x114185c: ldr             x0, [SP], #8
    // 0x1141860: ldp             x4, x5, [SP], #0x10
    // 0x1141864: ldp             x6, x7, [SP], #0x10
    // 0x1141868: ldp             q0, q1, [SP], #0x20
    // 0x114186c: b               #0x11415e0
    // 0x1141870: SaveReg d1
    //     0x1141870: str             q1, [SP, #-0x10]!
    // 0x1141874: stp             x6, x7, [SP, #-0x10]!
    // 0x1141878: stp             x4, x5, [SP, #-0x10]!
    // 0x114187c: stp             x0, x1, [SP, #-0x10]!
    // 0x1141880: r0 = AllocateDouble()
    //     0x1141880: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141884: mov             x2, x0
    // 0x1141888: ldp             x0, x1, [SP], #0x10
    // 0x114188c: ldp             x4, x5, [SP], #0x10
    // 0x1141890: ldp             x6, x7, [SP], #0x10
    // 0x1141894: RestoreReg d1
    //     0x1141894: ldr             q1, [SP], #0x10
    // 0x1141898: b               #0x114160c
  }
  [closure] static EdgeInsetsGeometry? lerp(dynamic, EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) {
    // ** addr: 0x1141924, size: 0x38
    // 0x1141924: EnterFrame
    //     0x1141924: stp             fp, lr, [SP, #-0x10]!
    //     0x1141928: mov             fp, SP
    // 0x114192c: CheckStackOverflow
    //     0x114192c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1141930: cmp             SP, x16
    //     0x1141934: b.ls            #0x1141954
    // 0x1141938: ldr             x1, [fp, #0x20]
    // 0x114193c: ldr             x2, [fp, #0x18]
    // 0x1141940: ldr             x3, [fp, #0x10]
    // 0x1141944: r0 = lerp()
    //     0x1141944: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1141948: LeaveFrame
    //     0x1141948: mov             SP, fp
    //     0x114194c: ldp             fp, lr, [SP], #0x10
    // 0x1141950: ret
    //     0x1141950: ret             
    // 0x1141954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1141954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141958: b               #0x1141938
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114bb48, size: 0x330
    // 0x114bb48: EnterFrame
    //     0x114bb48: stp             fp, lr, [SP, #-0x10]!
    //     0x114bb4c: mov             fp, SP
    // 0x114bb50: AllocStack(0x20)
    //     0x114bb50: sub             SP, SP, #0x20
    // 0x114bb54: CheckStackOverflow
    //     0x114bb54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114bb58: cmp             SP, x16
    //     0x114bb5c: b.ls            #0x114bd84
    // 0x114bb60: ldr             x0, [fp, #0x10]
    // 0x114bb64: r1 = LoadClassIdInstr(r0)
    //     0x114bb64: ldur            x1, [x0, #-1]
    //     0x114bb68: ubfx            x1, x1, #0xc, #0x14
    // 0x114bb6c: cmp             x1, #0xb7a
    // 0x114bb70: b.ne            #0x114bb7c
    // 0x114bb74: LoadField: d0 = r0->field_7
    //     0x114bb74: ldur            d0, [x0, #7]
    // 0x114bb78: b               #0x114bb90
    // 0x114bb7c: cmp             x1, #0xb7b
    // 0x114bb80: b.ne            #0x114bb8c
    // 0x114bb84: d0 = 0.000000
    //     0x114bb84: eor             v0.16b, v0.16b, v0.16b
    // 0x114bb88: b               #0x114bb90
    // 0x114bb8c: LoadField: d0 = r0->field_7
    //     0x114bb8c: ldur            d0, [x0, #7]
    // 0x114bb90: cmp             x1, #0xb7a
    // 0x114bb94: b.ne            #0x114bba0
    // 0x114bb98: LoadField: d1 = r0->field_f
    //     0x114bb98: ldur            d1, [x0, #0xf]
    // 0x114bb9c: b               #0x114bbb4
    // 0x114bba0: cmp             x1, #0xb7b
    // 0x114bba4: b.ne            #0x114bbb0
    // 0x114bba8: d1 = 0.000000
    //     0x114bba8: eor             v1.16b, v1.16b, v1.16b
    // 0x114bbac: b               #0x114bbb4
    // 0x114bbb0: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x114bbb0: ldur            d1, [x0, #0x17]
    // 0x114bbb4: cmp             x1, #0xb7a
    // 0x114bbb8: b.ne            #0x114bbc4
    // 0x114bbbc: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x114bbbc: ldur            d2, [x0, #0x17]
    // 0x114bbc0: b               #0x114bbd8
    // 0x114bbc4: cmp             x1, #0xb7b
    // 0x114bbc8: b.ne            #0x114bbd4
    // 0x114bbcc: LoadField: d2 = r0->field_7
    //     0x114bbcc: ldur            d2, [x0, #7]
    // 0x114bbd0: b               #0x114bbd8
    // 0x114bbd4: d2 = 0.000000
    //     0x114bbd4: eor             v2.16b, v2.16b, v2.16b
    // 0x114bbd8: cmp             x1, #0xb7a
    // 0x114bbdc: b.ne            #0x114bbe8
    // 0x114bbe0: LoadField: d3 = r0->field_1f
    //     0x114bbe0: ldur            d3, [x0, #0x1f]
    // 0x114bbe4: b               #0x114bbfc
    // 0x114bbe8: cmp             x1, #0xb7b
    // 0x114bbec: b.ne            #0x114bbf8
    // 0x114bbf0: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x114bbf0: ldur            d3, [x0, #0x17]
    // 0x114bbf4: b               #0x114bbfc
    // 0x114bbf8: d3 = 0.000000
    //     0x114bbf8: eor             v3.16b, v3.16b, v3.16b
    // 0x114bbfc: cmp             x1, #0xb7a
    // 0x114bc00: b.ne            #0x114bc0c
    // 0x114bc04: LoadField: d4 = r0->field_27
    //     0x114bc04: ldur            d4, [x0, #0x27]
    // 0x114bc08: b               #0x114bc20
    // 0x114bc0c: cmp             x1, #0xb7b
    // 0x114bc10: b.ne            #0x114bc1c
    // 0x114bc14: LoadField: d4 = r0->field_f
    //     0x114bc14: ldur            d4, [x0, #0xf]
    // 0x114bc18: b               #0x114bc20
    // 0x114bc1c: LoadField: d4 = r0->field_f
    //     0x114bc1c: ldur            d4, [x0, #0xf]
    // 0x114bc20: cmp             x1, #0xb7a
    // 0x114bc24: b.ne            #0x114bc30
    // 0x114bc28: LoadField: d5 = r0->field_2f
    //     0x114bc28: ldur            d5, [x0, #0x2f]
    // 0x114bc2c: b               #0x114bc44
    // 0x114bc30: cmp             x1, #0xb7b
    // 0x114bc34: b.ne            #0x114bc40
    // 0x114bc38: LoadField: d5 = r0->field_1f
    //     0x114bc38: ldur            d5, [x0, #0x1f]
    // 0x114bc3c: b               #0x114bc44
    // 0x114bc40: LoadField: d5 = r0->field_1f
    //     0x114bc40: ldur            d5, [x0, #0x1f]
    // 0x114bc44: r1 = inline_Allocate_Double()
    //     0x114bc44: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x114bc48: add             x1, x1, #0x10
    //     0x114bc4c: cmp             x0, x1
    //     0x114bc50: b.ls            #0x114bd8c
    //     0x114bc54: str             x1, [THR, #0x60]  ; THR::top
    //     0x114bc58: sub             x1, x1, #0xf
    //     0x114bc5c: mov             x0, #0xe19c
    //     0x114bc60: movk            x0, #3, lsl #16
    //     0x114bc64: stur            x0, [x1, #-1]
    // 0x114bc68: dmb             ishst
    // 0x114bc6c: StoreField: r1->field_7 = d0
    //     0x114bc6c: stur            d0, [x1, #7]
    // 0x114bc70: r2 = inline_Allocate_Double()
    //     0x114bc70: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x114bc74: add             x2, x2, #0x10
    //     0x114bc78: cmp             x0, x2
    //     0x114bc7c: b.ls            #0x114bdb0
    //     0x114bc80: str             x2, [THR, #0x60]  ; THR::top
    //     0x114bc84: sub             x2, x2, #0xf
    //     0x114bc88: mov             x0, #0xe19c
    //     0x114bc8c: movk            x0, #3, lsl #16
    //     0x114bc90: stur            x0, [x2, #-1]
    // 0x114bc94: dmb             ishst
    // 0x114bc98: StoreField: r2->field_7 = d1
    //     0x114bc98: stur            d1, [x2, #7]
    // 0x114bc9c: r0 = inline_Allocate_Double()
    //     0x114bc9c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114bca0: add             x0, x0, #0x10
    //     0x114bca4: cmp             x3, x0
    //     0x114bca8: b.ls            #0x114bddc
    //     0x114bcac: str             x0, [THR, #0x60]  ; THR::top
    //     0x114bcb0: sub             x0, x0, #0xf
    //     0x114bcb4: mov             x3, #0xe19c
    //     0x114bcb8: movk            x3, #3, lsl #16
    //     0x114bcbc: stur            x3, [x0, #-1]
    // 0x114bcc0: dmb             ishst
    // 0x114bcc4: StoreField: r0->field_7 = d2
    //     0x114bcc4: stur            d2, [x0, #7]
    // 0x114bcc8: r3 = inline_Allocate_Double()
    //     0x114bcc8: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x114bccc: add             x3, x3, #0x10
    //     0x114bcd0: cmp             x4, x3
    //     0x114bcd4: b.ls            #0x114bdfc
    //     0x114bcd8: str             x3, [THR, #0x60]  ; THR::top
    //     0x114bcdc: sub             x3, x3, #0xf
    //     0x114bce0: mov             x4, #0xe19c
    //     0x114bce4: movk            x4, #3, lsl #16
    //     0x114bce8: stur            x4, [x3, #-1]
    // 0x114bcec: dmb             ishst
    // 0x114bcf0: StoreField: r3->field_7 = d3
    //     0x114bcf0: stur            d3, [x3, #7]
    // 0x114bcf4: r4 = inline_Allocate_Double()
    //     0x114bcf4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x114bcf8: add             x4, x4, #0x10
    //     0x114bcfc: cmp             x5, x4
    //     0x114bd00: b.ls            #0x114be28
    //     0x114bd04: str             x4, [THR, #0x60]  ; THR::top
    //     0x114bd08: sub             x4, x4, #0xf
    //     0x114bd0c: mov             x5, #0xe19c
    //     0x114bd10: movk            x5, #3, lsl #16
    //     0x114bd14: stur            x5, [x4, #-1]
    // 0x114bd18: dmb             ishst
    // 0x114bd1c: StoreField: r4->field_7 = d4
    //     0x114bd1c: stur            d4, [x4, #7]
    // 0x114bd20: r5 = inline_Allocate_Double()
    //     0x114bd20: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x114bd24: add             x5, x5, #0x10
    //     0x114bd28: cmp             x6, x5
    //     0x114bd2c: b.ls            #0x114be4c
    //     0x114bd30: str             x5, [THR, #0x60]  ; THR::top
    //     0x114bd34: sub             x5, x5, #0xf
    //     0x114bd38: mov             x6, #0xe19c
    //     0x114bd3c: movk            x6, #3, lsl #16
    //     0x114bd40: stur            x6, [x5, #-1]
    // 0x114bd44: dmb             ishst
    // 0x114bd48: StoreField: r5->field_7 = d5
    //     0x114bd48: stur            d5, [x5, #7]
    // 0x114bd4c: stp             x3, x0, [SP, #0x10]
    // 0x114bd50: stp             x5, x4, [SP]
    // 0x114bd54: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x114bd54: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x114bd58: ldr             x4, [x4, #0xd28]
    // 0x114bd5c: r0 = hash()
    //     0x114bd5c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114bd60: mov             x2, x0
    // 0x114bd64: r0 = BoxInt64Instr(r2)
    //     0x114bd64: sbfiz           x0, x2, #1, #0x1f
    //     0x114bd68: cmp             x2, x0, asr #1
    //     0x114bd6c: b.eq            #0x114bd78
    //     0x114bd70: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114bd74: stur            x2, [x0, #7]
    // 0x114bd78: LeaveFrame
    //     0x114bd78: mov             SP, fp
    //     0x114bd7c: ldp             fp, lr, [SP], #0x10
    // 0x114bd80: ret
    //     0x114bd80: ret             
    // 0x114bd84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114bd84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114bd88: b               #0x114bb60
    // 0x114bd8c: stp             q4, q5, [SP, #-0x20]!
    // 0x114bd90: stp             q2, q3, [SP, #-0x20]!
    // 0x114bd94: stp             q0, q1, [SP, #-0x20]!
    // 0x114bd98: r0 = AllocateDouble()
    //     0x114bd98: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114bd9c: mov             x1, x0
    // 0x114bda0: ldp             q0, q1, [SP], #0x20
    // 0x114bda4: ldp             q2, q3, [SP], #0x20
    // 0x114bda8: ldp             q4, q5, [SP], #0x20
    // 0x114bdac: b               #0x114bc6c
    // 0x114bdb0: stp             q4, q5, [SP, #-0x20]!
    // 0x114bdb4: stp             q2, q3, [SP, #-0x20]!
    // 0x114bdb8: SaveReg d1
    //     0x114bdb8: str             q1, [SP, #-0x10]!
    // 0x114bdbc: SaveReg r1
    //     0x114bdbc: str             x1, [SP, #-8]!
    // 0x114bdc0: r0 = AllocateDouble()
    //     0x114bdc0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114bdc4: mov             x2, x0
    // 0x114bdc8: RestoreReg r1
    //     0x114bdc8: ldr             x1, [SP], #8
    // 0x114bdcc: RestoreReg d1
    //     0x114bdcc: ldr             q1, [SP], #0x10
    // 0x114bdd0: ldp             q2, q3, [SP], #0x20
    // 0x114bdd4: ldp             q4, q5, [SP], #0x20
    // 0x114bdd8: b               #0x114bc98
    // 0x114bddc: stp             q4, q5, [SP, #-0x20]!
    // 0x114bde0: stp             q2, q3, [SP, #-0x20]!
    // 0x114bde4: stp             x1, x2, [SP, #-0x10]!
    // 0x114bde8: r0 = AllocateDouble()
    //     0x114bde8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114bdec: ldp             x1, x2, [SP], #0x10
    // 0x114bdf0: ldp             q2, q3, [SP], #0x20
    // 0x114bdf4: ldp             q4, q5, [SP], #0x20
    // 0x114bdf8: b               #0x114bcc4
    // 0x114bdfc: stp             q4, q5, [SP, #-0x20]!
    // 0x114be00: SaveReg d3
    //     0x114be00: str             q3, [SP, #-0x10]!
    // 0x114be04: stp             x1, x2, [SP, #-0x10]!
    // 0x114be08: SaveReg r0
    //     0x114be08: str             x0, [SP, #-8]!
    // 0x114be0c: r0 = AllocateDouble()
    //     0x114be0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114be10: mov             x3, x0
    // 0x114be14: RestoreReg r0
    //     0x114be14: ldr             x0, [SP], #8
    // 0x114be18: ldp             x1, x2, [SP], #0x10
    // 0x114be1c: RestoreReg d3
    //     0x114be1c: ldr             q3, [SP], #0x10
    // 0x114be20: ldp             q4, q5, [SP], #0x20
    // 0x114be24: b               #0x114bcf0
    // 0x114be28: stp             q4, q5, [SP, #-0x20]!
    // 0x114be2c: stp             x2, x3, [SP, #-0x10]!
    // 0x114be30: stp             x0, x1, [SP, #-0x10]!
    // 0x114be34: r0 = AllocateDouble()
    //     0x114be34: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114be38: mov             x4, x0
    // 0x114be3c: ldp             x0, x1, [SP], #0x10
    // 0x114be40: ldp             x2, x3, [SP], #0x10
    // 0x114be44: ldp             q4, q5, [SP], #0x20
    // 0x114be48: b               #0x114bd1c
    // 0x114be4c: SaveReg d5
    //     0x114be4c: str             q5, [SP, #-0x10]!
    // 0x114be50: stp             x3, x4, [SP, #-0x10]!
    // 0x114be54: stp             x1, x2, [SP, #-0x10]!
    // 0x114be58: SaveReg r0
    //     0x114be58: str             x0, [SP, #-8]!
    // 0x114be5c: r0 = AllocateDouble()
    //     0x114be5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114be60: mov             x5, x0
    // 0x114be64: RestoreReg r0
    //     0x114be64: ldr             x0, [SP], #8
    // 0x114be68: ldp             x1, x2, [SP], #0x10
    // 0x114be6c: ldp             x3, x4, [SP], #0x10
    // 0x114be70: RestoreReg d5
    //     0x114be70: ldr             q5, [SP], #0x10
    // 0x114be74: b               #0x114bd48
  }
  _ ==(/* No info */) {
    // ** addr: 0x1298c8c, size: 0x234
    // 0x1298c8c: ldr             x1, [SP]
    // 0x1298c90: cmp             w1, NULL
    // 0x1298c94: b.ne            #0x1298ca0
    // 0x1298c98: r0 = false
    //     0x1298c98: add             x0, NULL, #0x30  ; false
    // 0x1298c9c: ret
    //     0x1298c9c: ret             
    // 0x1298ca0: r2 = 60
    //     0x1298ca0: mov             x2, #0x3c
    // 0x1298ca4: branchIfSmi(r1, 0x1298cb0)
    //     0x1298ca4: tbz             w1, #0, #0x1298cb0
    // 0x1298ca8: r2 = LoadClassIdInstr(r1)
    //     0x1298ca8: ldur            x2, [x1, #-1]
    //     0x1298cac: ubfx            x2, x2, #0xc, #0x14
    // 0x1298cb0: sub             x16, x2, #0xb7a
    // 0x1298cb4: cmp             x16, #2
    // 0x1298cb8: b.hi            #0x1298eb8
    // 0x1298cbc: cmp             x2, #0xb7a
    // 0x1298cc0: b.ne            #0x1298ccc
    // 0x1298cc4: LoadField: d0 = r1->field_7
    //     0x1298cc4: ldur            d0, [x1, #7]
    // 0x1298cc8: b               #0x1298ce0
    // 0x1298ccc: cmp             x2, #0xb7b
    // 0x1298cd0: b.ne            #0x1298cdc
    // 0x1298cd4: d0 = 0.000000
    //     0x1298cd4: eor             v0.16b, v0.16b, v0.16b
    // 0x1298cd8: b               #0x1298ce0
    // 0x1298cdc: LoadField: d0 = r1->field_7
    //     0x1298cdc: ldur            d0, [x1, #7]
    // 0x1298ce0: ldr             x3, [SP, #8]
    // 0x1298ce4: r4 = LoadClassIdInstr(r3)
    //     0x1298ce4: ldur            x4, [x3, #-1]
    //     0x1298ce8: ubfx            x4, x4, #0xc, #0x14
    // 0x1298cec: cmp             x4, #0xb7a
    // 0x1298cf0: b.ne            #0x1298cfc
    // 0x1298cf4: LoadField: d1 = r3->field_7
    //     0x1298cf4: ldur            d1, [x3, #7]
    // 0x1298cf8: b               #0x1298d10
    // 0x1298cfc: cmp             x4, #0xb7b
    // 0x1298d00: b.ne            #0x1298d0c
    // 0x1298d04: d1 = 0.000000
    //     0x1298d04: eor             v1.16b, v1.16b, v1.16b
    // 0x1298d08: b               #0x1298d10
    // 0x1298d0c: LoadField: d1 = r3->field_7
    //     0x1298d0c: ldur            d1, [x3, #7]
    // 0x1298d10: fcmp            d0, d1
    // 0x1298d14: b.ne            #0x1298eb8
    // 0x1298d18: cmp             x2, #0xb7a
    // 0x1298d1c: b.ne            #0x1298d28
    // 0x1298d20: LoadField: d0 = r1->field_f
    //     0x1298d20: ldur            d0, [x1, #0xf]
    // 0x1298d24: b               #0x1298d3c
    // 0x1298d28: cmp             x2, #0xb7b
    // 0x1298d2c: b.ne            #0x1298d38
    // 0x1298d30: d0 = 0.000000
    //     0x1298d30: eor             v0.16b, v0.16b, v0.16b
    // 0x1298d34: b               #0x1298d3c
    // 0x1298d38: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1298d38: ldur            d0, [x1, #0x17]
    // 0x1298d3c: cmp             x4, #0xb7a
    // 0x1298d40: b.ne            #0x1298d4c
    // 0x1298d44: LoadField: d1 = r3->field_f
    //     0x1298d44: ldur            d1, [x3, #0xf]
    // 0x1298d48: b               #0x1298d60
    // 0x1298d4c: cmp             x4, #0xb7b
    // 0x1298d50: b.ne            #0x1298d5c
    // 0x1298d54: d1 = 0.000000
    //     0x1298d54: eor             v1.16b, v1.16b, v1.16b
    // 0x1298d58: b               #0x1298d60
    // 0x1298d5c: ArrayLoad: d1 = r3[0]  ; List_8
    //     0x1298d5c: ldur            d1, [x3, #0x17]
    // 0x1298d60: fcmp            d0, d1
    // 0x1298d64: b.ne            #0x1298eb8
    // 0x1298d68: cmp             x2, #0xb7a
    // 0x1298d6c: b.ne            #0x1298d78
    // 0x1298d70: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1298d70: ldur            d0, [x1, #0x17]
    // 0x1298d74: b               #0x1298d8c
    // 0x1298d78: cmp             x2, #0xb7b
    // 0x1298d7c: b.ne            #0x1298d88
    // 0x1298d80: LoadField: d0 = r1->field_7
    //     0x1298d80: ldur            d0, [x1, #7]
    // 0x1298d84: b               #0x1298d8c
    // 0x1298d88: d0 = 0.000000
    //     0x1298d88: eor             v0.16b, v0.16b, v0.16b
    // 0x1298d8c: cmp             x4, #0xb7a
    // 0x1298d90: b.ne            #0x1298d9c
    // 0x1298d94: ArrayLoad: d1 = r3[0]  ; List_8
    //     0x1298d94: ldur            d1, [x3, #0x17]
    // 0x1298d98: b               #0x1298db0
    // 0x1298d9c: cmp             x4, #0xb7b
    // 0x1298da0: b.ne            #0x1298dac
    // 0x1298da4: LoadField: d1 = r3->field_7
    //     0x1298da4: ldur            d1, [x3, #7]
    // 0x1298da8: b               #0x1298db0
    // 0x1298dac: d1 = 0.000000
    //     0x1298dac: eor             v1.16b, v1.16b, v1.16b
    // 0x1298db0: fcmp            d0, d1
    // 0x1298db4: b.ne            #0x1298eb8
    // 0x1298db8: cmp             x2, #0xb7a
    // 0x1298dbc: b.ne            #0x1298dc8
    // 0x1298dc0: LoadField: d0 = r1->field_1f
    //     0x1298dc0: ldur            d0, [x1, #0x1f]
    // 0x1298dc4: b               #0x1298ddc
    // 0x1298dc8: cmp             x2, #0xb7b
    // 0x1298dcc: b.ne            #0x1298dd8
    // 0x1298dd0: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1298dd0: ldur            d0, [x1, #0x17]
    // 0x1298dd4: b               #0x1298ddc
    // 0x1298dd8: d0 = 0.000000
    //     0x1298dd8: eor             v0.16b, v0.16b, v0.16b
    // 0x1298ddc: cmp             x4, #0xb7a
    // 0x1298de0: b.ne            #0x1298dec
    // 0x1298de4: LoadField: d1 = r3->field_1f
    //     0x1298de4: ldur            d1, [x3, #0x1f]
    // 0x1298de8: b               #0x1298e00
    // 0x1298dec: cmp             x4, #0xb7b
    // 0x1298df0: b.ne            #0x1298dfc
    // 0x1298df4: ArrayLoad: d1 = r3[0]  ; List_8
    //     0x1298df4: ldur            d1, [x3, #0x17]
    // 0x1298df8: b               #0x1298e00
    // 0x1298dfc: d1 = 0.000000
    //     0x1298dfc: eor             v1.16b, v1.16b, v1.16b
    // 0x1298e00: fcmp            d0, d1
    // 0x1298e04: b.ne            #0x1298eb8
    // 0x1298e08: cmp             x2, #0xb7a
    // 0x1298e0c: b.ne            #0x1298e18
    // 0x1298e10: LoadField: d0 = r1->field_27
    //     0x1298e10: ldur            d0, [x1, #0x27]
    // 0x1298e14: b               #0x1298e2c
    // 0x1298e18: cmp             x2, #0xb7b
    // 0x1298e1c: b.ne            #0x1298e28
    // 0x1298e20: LoadField: d0 = r1->field_f
    //     0x1298e20: ldur            d0, [x1, #0xf]
    // 0x1298e24: b               #0x1298e2c
    // 0x1298e28: LoadField: d0 = r1->field_f
    //     0x1298e28: ldur            d0, [x1, #0xf]
    // 0x1298e2c: cmp             x4, #0xb7a
    // 0x1298e30: b.ne            #0x1298e3c
    // 0x1298e34: LoadField: d1 = r3->field_27
    //     0x1298e34: ldur            d1, [x3, #0x27]
    // 0x1298e38: b               #0x1298e50
    // 0x1298e3c: cmp             x4, #0xb7b
    // 0x1298e40: b.ne            #0x1298e4c
    // 0x1298e44: LoadField: d1 = r3->field_f
    //     0x1298e44: ldur            d1, [x3, #0xf]
    // 0x1298e48: b               #0x1298e50
    // 0x1298e4c: LoadField: d1 = r3->field_f
    //     0x1298e4c: ldur            d1, [x3, #0xf]
    // 0x1298e50: fcmp            d0, d1
    // 0x1298e54: b.ne            #0x1298eb8
    // 0x1298e58: cmp             x2, #0xb7a
    // 0x1298e5c: b.ne            #0x1298e68
    // 0x1298e60: LoadField: d0 = r1->field_2f
    //     0x1298e60: ldur            d0, [x1, #0x2f]
    // 0x1298e64: b               #0x1298e7c
    // 0x1298e68: cmp             x2, #0xb7b
    // 0x1298e6c: b.ne            #0x1298e78
    // 0x1298e70: LoadField: d0 = r1->field_1f
    //     0x1298e70: ldur            d0, [x1, #0x1f]
    // 0x1298e74: b               #0x1298e7c
    // 0x1298e78: LoadField: d0 = r1->field_1f
    //     0x1298e78: ldur            d0, [x1, #0x1f]
    // 0x1298e7c: cmp             x4, #0xb7a
    // 0x1298e80: b.ne            #0x1298e8c
    // 0x1298e84: LoadField: d1 = r3->field_2f
    //     0x1298e84: ldur            d1, [x3, #0x2f]
    // 0x1298e88: b               #0x1298ea0
    // 0x1298e8c: cmp             x4, #0xb7b
    // 0x1298e90: b.ne            #0x1298e9c
    // 0x1298e94: LoadField: d1 = r3->field_1f
    //     0x1298e94: ldur            d1, [x3, #0x1f]
    // 0x1298e98: b               #0x1298ea0
    // 0x1298e9c: LoadField: d1 = r3->field_1f
    //     0x1298e9c: ldur            d1, [x3, #0x1f]
    // 0x1298ea0: fcmp            d0, d1
    // 0x1298ea4: r16 = true
    //     0x1298ea4: add             x16, NULL, #0x20  ; true
    // 0x1298ea8: r17 = false
    //     0x1298ea8: add             x17, NULL, #0x30  ; false
    // 0x1298eac: csel            x1, x16, x17, eq
    // 0x1298eb0: mov             x0, x1
    // 0x1298eb4: b               #0x1298ebc
    // 0x1298eb8: r0 = false
    //     0x1298eb8: add             x0, NULL, #0x30  ; false
    // 0x1298ebc: ret
    //     0x1298ebc: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0x130112c, size: 0x294
    // 0x130112c: EnterFrame
    //     0x130112c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301130: mov             fp, SP
    // 0x1301134: AllocStack(0x30)
    //     0x1301134: sub             SP, SP, #0x30
    // 0x1301138: r0 = LoadClassIdInstr(r1)
    //     0x1301138: ldur            x0, [x1, #-1]
    //     0x130113c: ubfx            x0, x0, #0xc, #0x14
    // 0x1301140: cmp             x0, #0xb7a
    // 0x1301144: b.ne            #0x1301150
    // 0x1301148: LoadField: d0 = r1->field_7
    //     0x1301148: ldur            d0, [x1, #7]
    // 0x130114c: b               #0x1301164
    // 0x1301150: cmp             x0, #0xb7b
    // 0x1301154: b.ne            #0x1301160
    // 0x1301158: d0 = 0.000000
    //     0x1301158: eor             v0.16b, v0.16b, v0.16b
    // 0x130115c: b               #0x1301164
    // 0x1301160: LoadField: d0 = r1->field_7
    //     0x1301160: ldur            d0, [x1, #7]
    // 0x1301164: r3 = Instance_EdgeInsets
    //     0x1301164: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1301168: r2 = Instance__MixedEdgeInsets
    //     0x1301168: add             x2, PP, #0x9a, lsl #12  ; [pp+0x9a790] Obj!_MixedEdgeInsets@129c7d1
    //     0x130116c: ldr             x2, [x2, #0x790]
    // 0x1301170: LoadField: d1 = r3->field_7
    //     0x1301170: ldur            d1, [x3, #7]
    // 0x1301174: LoadField: d2 = r2->field_7
    //     0x1301174: ldur            d2, [x2, #7]
    // 0x1301178: fcmp            d1, d0
    // 0x130117c: b.le            #0x1301188
    // 0x1301180: mov             v0.16b, v1.16b
    // 0x1301184: b               #0x13011a4
    // 0x1301188: fcmp            d0, d2
    // 0x130118c: b.le            #0x1301198
    // 0x1301190: mov             v0.16b, v2.16b
    // 0x1301194: b               #0x13011a4
    // 0x1301198: fcmp            d0, d0
    // 0x130119c: b.vc            #0x13011a4
    // 0x13011a0: mov             v0.16b, v2.16b
    // 0x13011a4: stur            d0, [fp, #-0x30]
    // 0x13011a8: cmp             x0, #0xb7a
    // 0x13011ac: b.ne            #0x13011b8
    // 0x13011b0: LoadField: d1 = r1->field_f
    //     0x13011b0: ldur            d1, [x1, #0xf]
    // 0x13011b4: b               #0x13011cc
    // 0x13011b8: cmp             x0, #0xb7b
    // 0x13011bc: b.ne            #0x13011c8
    // 0x13011c0: d1 = 0.000000
    //     0x13011c0: eor             v1.16b, v1.16b, v1.16b
    // 0x13011c4: b               #0x13011cc
    // 0x13011c8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x13011c8: ldur            d1, [x1, #0x17]
    // 0x13011cc: ArrayLoad: d2 = r3[0]  ; List_8
    //     0x13011cc: ldur            d2, [x3, #0x17]
    // 0x13011d0: LoadField: d3 = r2->field_f
    //     0x13011d0: ldur            d3, [x2, #0xf]
    // 0x13011d4: fcmp            d2, d1
    // 0x13011d8: b.le            #0x13011e4
    // 0x13011dc: mov             v1.16b, v2.16b
    // 0x13011e0: b               #0x1301200
    // 0x13011e4: fcmp            d1, d3
    // 0x13011e8: b.le            #0x13011f4
    // 0x13011ec: mov             v1.16b, v3.16b
    // 0x13011f0: b               #0x1301200
    // 0x13011f4: fcmp            d1, d1
    // 0x13011f8: b.vc            #0x1301200
    // 0x13011fc: mov             v1.16b, v3.16b
    // 0x1301200: stur            d1, [fp, #-0x28]
    // 0x1301204: cmp             x0, #0xb7a
    // 0x1301208: b.ne            #0x1301218
    // 0x130120c: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x130120c: ldur            d2, [x1, #0x17]
    // 0x1301210: mov             v3.16b, v2.16b
    // 0x1301214: b               #0x1301230
    // 0x1301218: cmp             x0, #0xb7b
    // 0x130121c: b.ne            #0x130122c
    // 0x1301220: LoadField: d2 = r1->field_7
    //     0x1301220: ldur            d2, [x1, #7]
    // 0x1301224: mov             v3.16b, v2.16b
    // 0x1301228: b               #0x1301230
    // 0x130122c: d3 = 0.000000
    //     0x130122c: eor             v3.16b, v3.16b, v3.16b
    // 0x1301230: d2 = 0.000000
    //     0x1301230: eor             v2.16b, v2.16b, v2.16b
    // 0x1301234: ArrayLoad: d4 = r2[0]  ; List_8
    //     0x1301234: ldur            d4, [x2, #0x17]
    // 0x1301238: fcmp            d2, d3
    // 0x130123c: b.le            #0x1301248
    // 0x1301240: d3 = 0.000000
    //     0x1301240: eor             v3.16b, v3.16b, v3.16b
    // 0x1301244: b               #0x1301264
    // 0x1301248: fcmp            d3, d4
    // 0x130124c: b.le            #0x1301258
    // 0x1301250: mov             v3.16b, v4.16b
    // 0x1301254: b               #0x1301264
    // 0x1301258: fcmp            d3, d3
    // 0x130125c: b.vc            #0x1301264
    // 0x1301260: mov             v3.16b, v4.16b
    // 0x1301264: stur            d3, [fp, #-0x20]
    // 0x1301268: cmp             x0, #0xb7a
    // 0x130126c: b.ne            #0x1301278
    // 0x1301270: LoadField: d4 = r1->field_1f
    //     0x1301270: ldur            d4, [x1, #0x1f]
    // 0x1301274: b               #0x130128c
    // 0x1301278: cmp             x0, #0xb7b
    // 0x130127c: b.ne            #0x1301288
    // 0x1301280: ArrayLoad: d4 = r1[0]  ; List_8
    //     0x1301280: ldur            d4, [x1, #0x17]
    // 0x1301284: b               #0x130128c
    // 0x1301288: d4 = 0.000000
    //     0x1301288: eor             v4.16b, v4.16b, v4.16b
    // 0x130128c: LoadField: d5 = r2->field_1f
    //     0x130128c: ldur            d5, [x2, #0x1f]
    // 0x1301290: fcmp            d2, d4
    // 0x1301294: b.le            #0x13012a0
    // 0x1301298: d2 = 0.000000
    //     0x1301298: eor             v2.16b, v2.16b, v2.16b
    // 0x130129c: b               #0x13012c4
    // 0x13012a0: fcmp            d4, d5
    // 0x13012a4: b.le            #0x13012b0
    // 0x13012a8: mov             v2.16b, v5.16b
    // 0x13012ac: b               #0x13012c4
    // 0x13012b0: fcmp            d4, d4
    // 0x13012b4: b.vc            #0x13012c0
    // 0x13012b8: mov             v2.16b, v5.16b
    // 0x13012bc: b               #0x13012c4
    // 0x13012c0: mov             v2.16b, v4.16b
    // 0x13012c4: stur            d2, [fp, #-0x18]
    // 0x13012c8: cmp             x0, #0xb7a
    // 0x13012cc: b.ne            #0x13012d8
    // 0x13012d0: LoadField: d4 = r1->field_27
    //     0x13012d0: ldur            d4, [x1, #0x27]
    // 0x13012d4: b               #0x13012ec
    // 0x13012d8: cmp             x0, #0xb7b
    // 0x13012dc: b.ne            #0x13012e8
    // 0x13012e0: LoadField: d4 = r1->field_f
    //     0x13012e0: ldur            d4, [x1, #0xf]
    // 0x13012e4: b               #0x13012ec
    // 0x13012e8: LoadField: d4 = r1->field_f
    //     0x13012e8: ldur            d4, [x1, #0xf]
    // 0x13012ec: LoadField: d5 = r3->field_f
    //     0x13012ec: ldur            d5, [x3, #0xf]
    // 0x13012f0: LoadField: d6 = r2->field_27
    //     0x13012f0: ldur            d6, [x2, #0x27]
    // 0x13012f4: fcmp            d5, d4
    // 0x13012f8: b.le            #0x1301304
    // 0x13012fc: mov             v4.16b, v5.16b
    // 0x1301300: b               #0x1301320
    // 0x1301304: fcmp            d4, d6
    // 0x1301308: b.le            #0x1301314
    // 0x130130c: mov             v4.16b, v6.16b
    // 0x1301310: b               #0x1301320
    // 0x1301314: fcmp            d4, d4
    // 0x1301318: b.vc            #0x1301320
    // 0x130131c: mov             v4.16b, v6.16b
    // 0x1301320: stur            d4, [fp, #-0x10]
    // 0x1301324: cmp             x0, #0xb7a
    // 0x1301328: b.ne            #0x1301334
    // 0x130132c: LoadField: d5 = r1->field_2f
    //     0x130132c: ldur            d5, [x1, #0x2f]
    // 0x1301330: b               #0x1301348
    // 0x1301334: cmp             x0, #0xb7b
    // 0x1301338: b.ne            #0x1301344
    // 0x130133c: LoadField: d5 = r1->field_1f
    //     0x130133c: ldur            d5, [x1, #0x1f]
    // 0x1301340: b               #0x1301348
    // 0x1301344: LoadField: d5 = r1->field_1f
    //     0x1301344: ldur            d5, [x1, #0x1f]
    // 0x1301348: LoadField: d6 = r3->field_1f
    //     0x1301348: ldur            d6, [x3, #0x1f]
    // 0x130134c: LoadField: d7 = r2->field_2f
    //     0x130134c: ldur            d7, [x2, #0x2f]
    // 0x1301350: fcmp            d6, d5
    // 0x1301354: b.le            #0x1301360
    // 0x1301358: mov             v5.16b, v6.16b
    // 0x130135c: b               #0x130137c
    // 0x1301360: fcmp            d5, d7
    // 0x1301364: b.le            #0x1301370
    // 0x1301368: mov             v5.16b, v7.16b
    // 0x130136c: b               #0x130137c
    // 0x1301370: fcmp            d5, d5
    // 0x1301374: b.vc            #0x130137c
    // 0x1301378: mov             v5.16b, v7.16b
    // 0x130137c: stur            d5, [fp, #-8]
    // 0x1301380: r0 = _MixedEdgeInsets()
    //     0x1301380: bl              #0x1141d28  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x1301384: ldur            d0, [fp, #-0x30]
    // 0x1301388: StoreField: r0->field_7 = d0
    //     0x1301388: stur            d0, [x0, #7]
    // 0x130138c: ldur            d0, [fp, #-0x28]
    // 0x1301390: StoreField: r0->field_f = d0
    //     0x1301390: stur            d0, [x0, #0xf]
    // 0x1301394: ldur            d0, [fp, #-0x20]
    // 0x1301398: ArrayStore: r0[0] = d0  ; List_8
    //     0x1301398: stur            d0, [x0, #0x17]
    // 0x130139c: ldur            d0, [fp, #-0x18]
    // 0x13013a0: StoreField: r0->field_1f = d0
    //     0x13013a0: stur            d0, [x0, #0x1f]
    // 0x13013a4: ldur            d0, [fp, #-0x10]
    // 0x13013a8: StoreField: r0->field_27 = d0
    //     0x13013a8: stur            d0, [x0, #0x27]
    // 0x13013ac: ldur            d0, [fp, #-8]
    // 0x13013b0: StoreField: r0->field_2f = d0
    //     0x13013b0: stur            d0, [x0, #0x2f]
    // 0x13013b4: LeaveFrame
    //     0x13013b4: mov             SP, fp
    //     0x13013b8: ldp             fp, lr, [SP], #0x10
    // 0x13013bc: ret
    //     0x13013bc: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0x1301438, size: 0x23c
    // 0x1301438: EnterFrame
    //     0x1301438: stp             fp, lr, [SP, #-0x10]!
    //     0x130143c: mov             fp, SP
    // 0x1301440: AllocStack(0x30)
    //     0x1301440: sub             SP, SP, #0x30
    // 0x1301444: r0 = LoadClassIdInstr(r1)
    //     0x1301444: ldur            x0, [x1, #-1]
    //     0x1301448: ubfx            x0, x0, #0xc, #0x14
    // 0x130144c: cmp             x0, #0xb7a
    // 0x1301450: b.ne            #0x130145c
    // 0x1301454: LoadField: d0 = r1->field_7
    //     0x1301454: ldur            d0, [x1, #7]
    // 0x1301458: b               #0x1301470
    // 0x130145c: cmp             x0, #0xb7b
    // 0x1301460: b.ne            #0x130146c
    // 0x1301464: d0 = 0.000000
    //     0x1301464: eor             v0.16b, v0.16b, v0.16b
    // 0x1301468: b               #0x1301470
    // 0x130146c: LoadField: d0 = r1->field_7
    //     0x130146c: ldur            d0, [x1, #7]
    // 0x1301470: r3 = LoadClassIdInstr(r2)
    //     0x1301470: ldur            x3, [x2, #-1]
    //     0x1301474: ubfx            x3, x3, #0xc, #0x14
    // 0x1301478: cmp             x3, #0xb7a
    // 0x130147c: b.ne            #0x1301488
    // 0x1301480: LoadField: d1 = r2->field_7
    //     0x1301480: ldur            d1, [x2, #7]
    // 0x1301484: b               #0x130149c
    // 0x1301488: cmp             x3, #0xb7b
    // 0x130148c: b.ne            #0x1301498
    // 0x1301490: d1 = 0.000000
    //     0x1301490: eor             v1.16b, v1.16b, v1.16b
    // 0x1301494: b               #0x130149c
    // 0x1301498: LoadField: d1 = r2->field_7
    //     0x1301498: ldur            d1, [x2, #7]
    // 0x130149c: fadd            d2, d0, d1
    // 0x13014a0: stur            d2, [fp, #-0x30]
    // 0x13014a4: cmp             x0, #0xb7a
    // 0x13014a8: b.ne            #0x13014b4
    // 0x13014ac: LoadField: d0 = r1->field_f
    //     0x13014ac: ldur            d0, [x1, #0xf]
    // 0x13014b0: b               #0x13014c8
    // 0x13014b4: cmp             x0, #0xb7b
    // 0x13014b8: b.ne            #0x13014c4
    // 0x13014bc: d0 = 0.000000
    //     0x13014bc: eor             v0.16b, v0.16b, v0.16b
    // 0x13014c0: b               #0x13014c8
    // 0x13014c4: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x13014c4: ldur            d0, [x1, #0x17]
    // 0x13014c8: cmp             x3, #0xb7a
    // 0x13014cc: b.ne            #0x13014d8
    // 0x13014d0: LoadField: d1 = r2->field_f
    //     0x13014d0: ldur            d1, [x2, #0xf]
    // 0x13014d4: b               #0x13014ec
    // 0x13014d8: cmp             x3, #0xb7b
    // 0x13014dc: b.ne            #0x13014e8
    // 0x13014e0: d1 = 0.000000
    //     0x13014e0: eor             v1.16b, v1.16b, v1.16b
    // 0x13014e4: b               #0x13014ec
    // 0x13014e8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x13014e8: ldur            d1, [x2, #0x17]
    // 0x13014ec: fadd            d3, d0, d1
    // 0x13014f0: stur            d3, [fp, #-0x28]
    // 0x13014f4: cmp             x0, #0xb7a
    // 0x13014f8: b.ne            #0x1301504
    // 0x13014fc: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x13014fc: ldur            d0, [x1, #0x17]
    // 0x1301500: b               #0x1301518
    // 0x1301504: cmp             x0, #0xb7b
    // 0x1301508: b.ne            #0x1301514
    // 0x130150c: LoadField: d0 = r1->field_7
    //     0x130150c: ldur            d0, [x1, #7]
    // 0x1301510: b               #0x1301518
    // 0x1301514: d0 = 0.000000
    //     0x1301514: eor             v0.16b, v0.16b, v0.16b
    // 0x1301518: cmp             x3, #0xb7a
    // 0x130151c: b.ne            #0x1301528
    // 0x1301520: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x1301520: ldur            d1, [x2, #0x17]
    // 0x1301524: b               #0x130153c
    // 0x1301528: cmp             x3, #0xb7b
    // 0x130152c: b.ne            #0x1301538
    // 0x1301530: LoadField: d1 = r2->field_7
    //     0x1301530: ldur            d1, [x2, #7]
    // 0x1301534: b               #0x130153c
    // 0x1301538: d1 = 0.000000
    //     0x1301538: eor             v1.16b, v1.16b, v1.16b
    // 0x130153c: fadd            d4, d0, d1
    // 0x1301540: stur            d4, [fp, #-0x20]
    // 0x1301544: cmp             x0, #0xb7a
    // 0x1301548: b.ne            #0x1301554
    // 0x130154c: LoadField: d0 = r1->field_1f
    //     0x130154c: ldur            d0, [x1, #0x1f]
    // 0x1301550: b               #0x1301568
    // 0x1301554: cmp             x0, #0xb7b
    // 0x1301558: b.ne            #0x1301564
    // 0x130155c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x130155c: ldur            d0, [x1, #0x17]
    // 0x1301560: b               #0x1301568
    // 0x1301564: d0 = 0.000000
    //     0x1301564: eor             v0.16b, v0.16b, v0.16b
    // 0x1301568: cmp             x3, #0xb7a
    // 0x130156c: b.ne            #0x1301578
    // 0x1301570: LoadField: d1 = r2->field_1f
    //     0x1301570: ldur            d1, [x2, #0x1f]
    // 0x1301574: b               #0x130158c
    // 0x1301578: cmp             x3, #0xb7b
    // 0x130157c: b.ne            #0x1301588
    // 0x1301580: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x1301580: ldur            d1, [x2, #0x17]
    // 0x1301584: b               #0x130158c
    // 0x1301588: d1 = 0.000000
    //     0x1301588: eor             v1.16b, v1.16b, v1.16b
    // 0x130158c: fadd            d5, d0, d1
    // 0x1301590: stur            d5, [fp, #-0x18]
    // 0x1301594: cmp             x0, #0xb7a
    // 0x1301598: b.ne            #0x13015a4
    // 0x130159c: LoadField: d0 = r1->field_27
    //     0x130159c: ldur            d0, [x1, #0x27]
    // 0x13015a0: b               #0x13015b8
    // 0x13015a4: cmp             x0, #0xb7b
    // 0x13015a8: b.ne            #0x13015b4
    // 0x13015ac: LoadField: d0 = r1->field_f
    //     0x13015ac: ldur            d0, [x1, #0xf]
    // 0x13015b0: b               #0x13015b8
    // 0x13015b4: LoadField: d0 = r1->field_f
    //     0x13015b4: ldur            d0, [x1, #0xf]
    // 0x13015b8: cmp             x3, #0xb7a
    // 0x13015bc: b.ne            #0x13015c8
    // 0x13015c0: LoadField: d1 = r2->field_27
    //     0x13015c0: ldur            d1, [x2, #0x27]
    // 0x13015c4: b               #0x13015dc
    // 0x13015c8: cmp             x3, #0xb7b
    // 0x13015cc: b.ne            #0x13015d8
    // 0x13015d0: LoadField: d1 = r2->field_f
    //     0x13015d0: ldur            d1, [x2, #0xf]
    // 0x13015d4: b               #0x13015dc
    // 0x13015d8: LoadField: d1 = r2->field_f
    //     0x13015d8: ldur            d1, [x2, #0xf]
    // 0x13015dc: fadd            d6, d0, d1
    // 0x13015e0: stur            d6, [fp, #-0x10]
    // 0x13015e4: cmp             x0, #0xb7a
    // 0x13015e8: b.ne            #0x13015f4
    // 0x13015ec: LoadField: d0 = r1->field_2f
    //     0x13015ec: ldur            d0, [x1, #0x2f]
    // 0x13015f0: b               #0x1301608
    // 0x13015f4: cmp             x0, #0xb7b
    // 0x13015f8: b.ne            #0x1301604
    // 0x13015fc: LoadField: d0 = r1->field_1f
    //     0x13015fc: ldur            d0, [x1, #0x1f]
    // 0x1301600: b               #0x1301608
    // 0x1301604: LoadField: d0 = r1->field_1f
    //     0x1301604: ldur            d0, [x1, #0x1f]
    // 0x1301608: cmp             x3, #0xb7a
    // 0x130160c: b.ne            #0x1301618
    // 0x1301610: LoadField: d1 = r2->field_2f
    //     0x1301610: ldur            d1, [x2, #0x2f]
    // 0x1301614: b               #0x130162c
    // 0x1301618: cmp             x3, #0xb7b
    // 0x130161c: b.ne            #0x1301628
    // 0x1301620: LoadField: d1 = r2->field_1f
    //     0x1301620: ldur            d1, [x2, #0x1f]
    // 0x1301624: b               #0x130162c
    // 0x1301628: LoadField: d1 = r2->field_1f
    //     0x1301628: ldur            d1, [x2, #0x1f]
    // 0x130162c: fadd            d7, d0, d1
    // 0x1301630: stur            d7, [fp, #-8]
    // 0x1301634: r0 = _MixedEdgeInsets()
    //     0x1301634: bl              #0x1141d28  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x1301638: ldur            d0, [fp, #-0x30]
    // 0x130163c: StoreField: r0->field_7 = d0
    //     0x130163c: stur            d0, [x0, #7]
    // 0x1301640: ldur            d0, [fp, #-0x28]
    // 0x1301644: StoreField: r0->field_f = d0
    //     0x1301644: stur            d0, [x0, #0xf]
    // 0x1301648: ldur            d0, [fp, #-0x20]
    // 0x130164c: ArrayStore: r0[0] = d0  ; List_8
    //     0x130164c: stur            d0, [x0, #0x17]
    // 0x1301650: ldur            d0, [fp, #-0x18]
    // 0x1301654: StoreField: r0->field_1f = d0
    //     0x1301654: stur            d0, [x0, #0x1f]
    // 0x1301658: ldur            d0, [fp, #-0x10]
    // 0x130165c: StoreField: r0->field_27 = d0
    //     0x130165c: stur            d0, [x0, #0x27]
    // 0x1301660: ldur            d0, [fp, #-8]
    // 0x1301664: StoreField: r0->field_2f = d0
    //     0x1301664: stur            d0, [x0, #0x2f]
    // 0x1301668: LeaveFrame
    //     0x1301668: mov             SP, fp
    //     0x130166c: ldp             fp, lr, [SP], #0x10
    // 0x1301670: ret
    //     0x1301670: ret             
  }
}

// class id: 2938, size: 0x38, field offset: 0x8
//   const constructor, 
class _MixedEdgeInsets extends EdgeInsetsGeometry {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;
  _Double field_28;
  _Double field_30;

  EdgeInsets resolve(_MixedEdgeInsets, TextDirection?) {
    // ** addr: 0x11418b4, size: 0x88
    // 0x11418b4: EnterFrame
    //     0x11418b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11418b8: mov             fp, SP
    // 0x11418bc: CheckStackOverflow
    //     0x11418bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11418c0: cmp             SP, x16
    //     0x11418c4: b.ls            #0x114191c
    // 0x11418c8: ldr             x0, [fp, #0x10]
    // 0x11418cc: r2 = Null
    //     0x11418cc: mov             x2, NULL
    // 0x11418d0: r1 = Null
    //     0x11418d0: mov             x1, NULL
    // 0x11418d4: r4 = 60
    //     0x11418d4: mov             x4, #0x3c
    // 0x11418d8: branchIfSmi(r0, 0x11418e4)
    //     0x11418d8: tbz             w0, #0, #0x11418e4
    // 0x11418dc: r4 = LoadClassIdInstr(r0)
    //     0x11418dc: ldur            x4, [x0, #-1]
    //     0x11418e0: ubfx            x4, x4, #0xc, #0x14
    // 0x11418e4: r17 = 8353
    //     0x11418e4: mov             x17, #0x20a1
    // 0x11418e8: cmp             x4, x17
    // 0x11418ec: b.eq            #0x1141904
    // 0x11418f0: r8 = TextDirection?
    //     0x11418f0: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0x11418f4: ldr             x8, [x8, #0x750]
    // 0x11418f8: r3 = Null
    //     0x11418f8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90ca0] Null
    //     0x11418fc: ldr             x3, [x3, #0xca0]
    // 0x1141900: r0 = DefaultNullableTypeTest()
    //     0x1141900: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1141904: ldr             x1, [fp, #0x18]
    // 0x1141908: ldr             x2, [fp, #0x10]
    // 0x114190c: r0 = resolve()
    //     0x114190c: bl              #0x1304b9c  ; [package:flutter/src/painting/edge_insets.dart] _MixedEdgeInsets::resolve
    // 0x1141910: LeaveFrame
    //     0x1141910: mov             SP, fp
    //     0x1141914: ldp             fp, lr, [SP], #0x10
    // 0x1141918: ret
    //     0x1141918: ret             
    // 0x114191c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114191c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141920: b               #0x11418c8
  }
  EdgeInsets resolve(_MixedEdgeInsets, TextDirection?) {
    // ** addr: 0x1304b9c, size: 0xdc
    // 0x1304b9c: EnterFrame
    //     0x1304b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x1304ba0: mov             fp, SP
    // 0x1304ba4: AllocStack(0x20)
    //     0x1304ba4: sub             SP, SP, #0x20
    // 0x1304ba8: cmp             w2, NULL
    // 0x1304bac: b.eq            #0x1304c74
    // 0x1304bb0: LoadField: r0 = r2->field_7
    //     0x1304bb0: ldur            x0, [x2, #7]
    // 0x1304bb4: cmp             x0, #0
    // 0x1304bb8: b.gt            #0x1304c14
    // 0x1304bbc: LoadField: d0 = r1->field_1f
    //     0x1304bbc: ldur            d0, [x1, #0x1f]
    // 0x1304bc0: LoadField: d1 = r1->field_7
    //     0x1304bc0: ldur            d1, [x1, #7]
    // 0x1304bc4: fadd            d2, d0, d1
    // 0x1304bc8: stur            d2, [fp, #-0x20]
    // 0x1304bcc: LoadField: d0 = r1->field_27
    //     0x1304bcc: ldur            d0, [x1, #0x27]
    // 0x1304bd0: stur            d0, [fp, #-0x18]
    // 0x1304bd4: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x1304bd4: ldur            d1, [x1, #0x17]
    // 0x1304bd8: LoadField: d3 = r1->field_f
    //     0x1304bd8: ldur            d3, [x1, #0xf]
    // 0x1304bdc: fadd            d4, d1, d3
    // 0x1304be0: stur            d4, [fp, #-0x10]
    // 0x1304be4: LoadField: d1 = r1->field_2f
    //     0x1304be4: ldur            d1, [x1, #0x2f]
    // 0x1304be8: stur            d1, [fp, #-8]
    // 0x1304bec: r0 = EdgeInsets()
    //     0x1304bec: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1304bf0: ldur            d0, [fp, #-0x20]
    // 0x1304bf4: StoreField: r0->field_7 = d0
    //     0x1304bf4: stur            d0, [x0, #7]
    // 0x1304bf8: ldur            d0, [fp, #-0x18]
    // 0x1304bfc: StoreField: r0->field_f = d0
    //     0x1304bfc: stur            d0, [x0, #0xf]
    // 0x1304c00: ldur            d0, [fp, #-0x10]
    // 0x1304c04: ArrayStore: r0[0] = d0  ; List_8
    //     0x1304c04: stur            d0, [x0, #0x17]
    // 0x1304c08: ldur            d0, [fp, #-8]
    // 0x1304c0c: StoreField: r0->field_1f = d0
    //     0x1304c0c: stur            d0, [x0, #0x1f]
    // 0x1304c10: b               #0x1304c68
    // 0x1304c14: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1304c14: ldur            d0, [x1, #0x17]
    // 0x1304c18: LoadField: d1 = r1->field_7
    //     0x1304c18: ldur            d1, [x1, #7]
    // 0x1304c1c: fadd            d2, d0, d1
    // 0x1304c20: stur            d2, [fp, #-0x20]
    // 0x1304c24: LoadField: d0 = r1->field_27
    //     0x1304c24: ldur            d0, [x1, #0x27]
    // 0x1304c28: stur            d0, [fp, #-0x18]
    // 0x1304c2c: LoadField: d1 = r1->field_1f
    //     0x1304c2c: ldur            d1, [x1, #0x1f]
    // 0x1304c30: LoadField: d3 = r1->field_f
    //     0x1304c30: ldur            d3, [x1, #0xf]
    // 0x1304c34: fadd            d4, d1, d3
    // 0x1304c38: stur            d4, [fp, #-0x10]
    // 0x1304c3c: LoadField: d1 = r1->field_2f
    //     0x1304c3c: ldur            d1, [x1, #0x2f]
    // 0x1304c40: stur            d1, [fp, #-8]
    // 0x1304c44: r0 = EdgeInsets()
    //     0x1304c44: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1304c48: ldur            d0, [fp, #-0x20]
    // 0x1304c4c: StoreField: r0->field_7 = d0
    //     0x1304c4c: stur            d0, [x0, #7]
    // 0x1304c50: ldur            d0, [fp, #-0x18]
    // 0x1304c54: StoreField: r0->field_f = d0
    //     0x1304c54: stur            d0, [x0, #0xf]
    // 0x1304c58: ldur            d0, [fp, #-0x10]
    // 0x1304c5c: ArrayStore: r0[0] = d0  ; List_8
    //     0x1304c5c: stur            d0, [x0, #0x17]
    // 0x1304c60: ldur            d0, [fp, #-8]
    // 0x1304c64: StoreField: r0->field_1f = d0
    //     0x1304c64: stur            d0, [x0, #0x1f]
    // 0x1304c68: LeaveFrame
    //     0x1304c68: mov             SP, fp
    //     0x1304c6c: ldp             fp, lr, [SP], #0x10
    // 0x1304c70: ret
    //     0x1304c70: ret             
    // 0x1304c74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304c74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2939, size: 0x28, field offset: 0x8
//   const constructor, 
class EdgeInsetsDirectional extends EdgeInsetsGeometry {

  _Double field_8;
  _Mint field_10;
  _Double field_18;
  _Mint field_20;

  EdgeInsetsDirectional +(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0xb50084, size: 0x84
    // 0xb50084: EnterFrame
    //     0xb50084: stp             fp, lr, [SP, #-0x10]!
    //     0xb50088: mov             fp, SP
    // 0xb5008c: CheckStackOverflow
    //     0xb5008c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50090: cmp             SP, x16
    //     0xb50094: b.ls            #0xb500e8
    // 0xb50098: ldr             x0, [fp, #0x10]
    // 0xb5009c: r2 = Null
    //     0xb5009c: mov             x2, NULL
    // 0xb500a0: r1 = Null
    //     0xb500a0: mov             x1, NULL
    // 0xb500a4: r4 = 60
    //     0xb500a4: mov             x4, #0x3c
    // 0xb500a8: branchIfSmi(r0, 0xb500b4)
    //     0xb500a8: tbz             w0, #0, #0xb500b4
    // 0xb500ac: r4 = LoadClassIdInstr(r0)
    //     0xb500ac: ldur            x4, [x0, #-1]
    //     0xb500b0: ubfx            x4, x4, #0xc, #0x14
    // 0xb500b4: cmp             x4, #0xb7b
    // 0xb500b8: b.eq            #0xb500d0
    // 0xb500bc: r8 = EdgeInsetsDirectional
    //     0xb500bc: add             x8, PP, #0x85, lsl #12  ; [pp+0x85588] Type: EdgeInsetsDirectional
    //     0xb500c0: ldr             x8, [x8, #0x588]
    // 0xb500c4: r3 = Null
    //     0xb500c4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90cb0] Null
    //     0xb500c8: ldr             x3, [x3, #0xcb0]
    // 0xb500cc: r0 = DefaultTypeTest()
    //     0xb500cc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb500d0: ldr             x1, [fp, #0x18]
    // 0xb500d4: ldr             x2, [fp, #0x10]
    // 0xb500d8: r0 = +()
    //     0xb500d8: bl              #0xb500f0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::+
    // 0xb500dc: LeaveFrame
    //     0xb500dc: mov             SP, fp
    //     0xb500e0: ldp             fp, lr, [SP], #0x10
    // 0xb500e4: ret
    //     0xb500e4: ret             
    // 0xb500e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb500e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb500ec: b               #0xb50098
  }
  EdgeInsetsDirectional +(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0xb500f0, size: 0x7c
    // 0xb500f0: EnterFrame
    //     0xb500f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb500f4: mov             fp, SP
    // 0xb500f8: AllocStack(0x20)
    //     0xb500f8: sub             SP, SP, #0x20
    // 0xb500fc: LoadField: d0 = r1->field_7
    //     0xb500fc: ldur            d0, [x1, #7]
    // 0xb50100: LoadField: d1 = r2->field_7
    //     0xb50100: ldur            d1, [x2, #7]
    // 0xb50104: fadd            d2, d0, d1
    // 0xb50108: stur            d2, [fp, #-0x20]
    // 0xb5010c: LoadField: d0 = r1->field_f
    //     0xb5010c: ldur            d0, [x1, #0xf]
    // 0xb50110: LoadField: d1 = r2->field_f
    //     0xb50110: ldur            d1, [x2, #0xf]
    // 0xb50114: fadd            d3, d0, d1
    // 0xb50118: stur            d3, [fp, #-0x18]
    // 0xb5011c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb5011c: ldur            d0, [x1, #0x17]
    // 0xb50120: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xb50120: ldur            d1, [x2, #0x17]
    // 0xb50124: fadd            d4, d0, d1
    // 0xb50128: stur            d4, [fp, #-0x10]
    // 0xb5012c: LoadField: d0 = r1->field_1f
    //     0xb5012c: ldur            d0, [x1, #0x1f]
    // 0xb50130: LoadField: d1 = r2->field_1f
    //     0xb50130: ldur            d1, [x2, #0x1f]
    // 0xb50134: fadd            d5, d0, d1
    // 0xb50138: stur            d5, [fp, #-8]
    // 0xb5013c: r0 = EdgeInsetsDirectional()
    //     0xb5013c: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xb50140: ldur            d0, [fp, #-0x20]
    // 0xb50144: StoreField: r0->field_7 = d0
    //     0xb50144: stur            d0, [x0, #7]
    // 0xb50148: ldur            d0, [fp, #-0x18]
    // 0xb5014c: StoreField: r0->field_f = d0
    //     0xb5014c: stur            d0, [x0, #0xf]
    // 0xb50150: ldur            d0, [fp, #-0x10]
    // 0xb50154: ArrayStore: r0[0] = d0  ; List_8
    //     0xb50154: stur            d0, [x0, #0x17]
    // 0xb50158: ldur            d0, [fp, #-8]
    // 0xb5015c: StoreField: r0->field_1f = d0
    //     0xb5015c: stur            d0, [x0, #0x1f]
    // 0xb50160: LeaveFrame
    //     0xb50160: mov             SP, fp
    //     0xb50164: ldp             fp, lr, [SP], #0x10
    // 0xb50168: ret
    //     0xb50168: ret             
  }
  EdgeInsets resolve(EdgeInsetsDirectional, TextDirection?) {
    // ** addr: 0xb50184, size: 0x88
    // 0xb50184: EnterFrame
    //     0xb50184: stp             fp, lr, [SP, #-0x10]!
    //     0xb50188: mov             fp, SP
    // 0xb5018c: CheckStackOverflow
    //     0xb5018c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50190: cmp             SP, x16
    //     0xb50194: b.ls            #0xb501ec
    // 0xb50198: ldr             x0, [fp, #0x10]
    // 0xb5019c: r2 = Null
    //     0xb5019c: mov             x2, NULL
    // 0xb501a0: r1 = Null
    //     0xb501a0: mov             x1, NULL
    // 0xb501a4: r4 = 60
    //     0xb501a4: mov             x4, #0x3c
    // 0xb501a8: branchIfSmi(r0, 0xb501b4)
    //     0xb501a8: tbz             w0, #0, #0xb501b4
    // 0xb501ac: r4 = LoadClassIdInstr(r0)
    //     0xb501ac: ldur            x4, [x0, #-1]
    //     0xb501b0: ubfx            x4, x4, #0xc, #0x14
    // 0xb501b4: r17 = 8353
    //     0xb501b4: mov             x17, #0x20a1
    // 0xb501b8: cmp             x4, x17
    // 0xb501bc: b.eq            #0xb501d4
    // 0xb501c0: r8 = TextDirection?
    //     0xb501c0: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0xb501c4: ldr             x8, [x8, #0x750]
    // 0xb501c8: r3 = Null
    //     0xb501c8: add             x3, PP, #0x85, lsl #12  ; [pp+0x85578] Null
    //     0xb501cc: ldr             x3, [x3, #0x578]
    // 0xb501d0: r0 = DefaultNullableTypeTest()
    //     0xb501d0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xb501d4: ldr             x1, [fp, #0x18]
    // 0xb501d8: ldr             x2, [fp, #0x10]
    // 0xb501dc: r0 = resolve()
    //     0xb501dc: bl              #0x1304ae0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::resolve
    // 0xb501e0: LeaveFrame
    //     0xb501e0: mov             SP, fp
    //     0xb501e4: ldp             fp, lr, [SP], #0x10
    // 0xb501e8: ret
    //     0xb501e8: ret             
    // 0xb501ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb501ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb501f0: b               #0xb50198
  }
  EdgeInsetsDirectional -(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0xb5020c, size: 0x84
    // 0xb5020c: EnterFrame
    //     0xb5020c: stp             fp, lr, [SP, #-0x10]!
    //     0xb50210: mov             fp, SP
    // 0xb50214: CheckStackOverflow
    //     0xb50214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50218: cmp             SP, x16
    //     0xb5021c: b.ls            #0xb50270
    // 0xb50220: ldr             x0, [fp, #0x10]
    // 0xb50224: r2 = Null
    //     0xb50224: mov             x2, NULL
    // 0xb50228: r1 = Null
    //     0xb50228: mov             x1, NULL
    // 0xb5022c: r4 = 60
    //     0xb5022c: mov             x4, #0x3c
    // 0xb50230: branchIfSmi(r0, 0xb5023c)
    //     0xb50230: tbz             w0, #0, #0xb5023c
    // 0xb50234: r4 = LoadClassIdInstr(r0)
    //     0xb50234: ldur            x4, [x0, #-1]
    //     0xb50238: ubfx            x4, x4, #0xc, #0x14
    // 0xb5023c: cmp             x4, #0xb7b
    // 0xb50240: b.eq            #0xb50258
    // 0xb50244: r8 = EdgeInsetsDirectional
    //     0xb50244: add             x8, PP, #0x85, lsl #12  ; [pp+0x85588] Type: EdgeInsetsDirectional
    //     0xb50248: ldr             x8, [x8, #0x588]
    // 0xb5024c: r3 = Null
    //     0xb5024c: add             x3, PP, #0x85, lsl #12  ; [pp+0x85590] Null
    //     0xb50250: ldr             x3, [x3, #0x590]
    // 0xb50254: r0 = DefaultTypeTest()
    //     0xb50254: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb50258: ldr             x1, [fp, #0x18]
    // 0xb5025c: ldr             x2, [fp, #0x10]
    // 0xb50260: r0 = -()
    //     0xb50260: bl              #0xb50278  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::-
    // 0xb50264: LeaveFrame
    //     0xb50264: mov             SP, fp
    //     0xb50268: ldp             fp, lr, [SP], #0x10
    // 0xb5026c: ret
    //     0xb5026c: ret             
    // 0xb50270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb50270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb50274: b               #0xb50220
  }
  EdgeInsetsDirectional -(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0xb50278, size: 0x7c
    // 0xb50278: EnterFrame
    //     0xb50278: stp             fp, lr, [SP, #-0x10]!
    //     0xb5027c: mov             fp, SP
    // 0xb50280: AllocStack(0x20)
    //     0xb50280: sub             SP, SP, #0x20
    // 0xb50284: LoadField: d0 = r1->field_7
    //     0xb50284: ldur            d0, [x1, #7]
    // 0xb50288: LoadField: d1 = r2->field_7
    //     0xb50288: ldur            d1, [x2, #7]
    // 0xb5028c: fsub            d2, d0, d1
    // 0xb50290: stur            d2, [fp, #-0x20]
    // 0xb50294: LoadField: d0 = r1->field_f
    //     0xb50294: ldur            d0, [x1, #0xf]
    // 0xb50298: LoadField: d1 = r2->field_f
    //     0xb50298: ldur            d1, [x2, #0xf]
    // 0xb5029c: fsub            d3, d0, d1
    // 0xb502a0: stur            d3, [fp, #-0x18]
    // 0xb502a4: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb502a4: ldur            d0, [x1, #0x17]
    // 0xb502a8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xb502a8: ldur            d1, [x2, #0x17]
    // 0xb502ac: fsub            d4, d0, d1
    // 0xb502b0: stur            d4, [fp, #-0x10]
    // 0xb502b4: LoadField: d0 = r1->field_1f
    //     0xb502b4: ldur            d0, [x1, #0x1f]
    // 0xb502b8: LoadField: d1 = r2->field_1f
    //     0xb502b8: ldur            d1, [x2, #0x1f]
    // 0xb502bc: fsub            d5, d0, d1
    // 0xb502c0: stur            d5, [fp, #-8]
    // 0xb502c4: r0 = EdgeInsetsDirectional()
    //     0xb502c4: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xb502c8: ldur            d0, [fp, #-0x20]
    // 0xb502cc: StoreField: r0->field_7 = d0
    //     0xb502cc: stur            d0, [x0, #7]
    // 0xb502d0: ldur            d0, [fp, #-0x18]
    // 0xb502d4: StoreField: r0->field_f = d0
    //     0xb502d4: stur            d0, [x0, #0xf]
    // 0xb502d8: ldur            d0, [fp, #-0x10]
    // 0xb502dc: ArrayStore: r0[0] = d0  ; List_8
    //     0xb502dc: stur            d0, [x0, #0x17]
    // 0xb502e0: ldur            d0, [fp, #-8]
    // 0xb502e4: StoreField: r0->field_1f = d0
    //     0xb502e4: stur            d0, [x0, #0x1f]
    // 0xb502e8: LeaveFrame
    //     0xb502e8: mov             SP, fp
    //     0xb502ec: ldp             fp, lr, [SP], #0x10
    // 0xb502f0: ret
    //     0xb502f0: ret             
  }
  EdgeInsetsDirectional *(EdgeInsetsDirectional, double) {
    // ** addr: 0xb5030c, size: 0x50
    // 0xb5030c: EnterFrame
    //     0xb5030c: stp             fp, lr, [SP, #-0x10]!
    //     0xb50310: mov             fp, SP
    // 0xb50314: CheckStackOverflow
    //     0xb50314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50318: cmp             SP, x16
    //     0xb5031c: b.ls            #0xb5033c
    // 0xb50320: ldr             x0, [fp, #0x10]
    // 0xb50324: LoadField: d0 = r0->field_7
    //     0xb50324: ldur            d0, [x0, #7]
    // 0xb50328: ldr             x1, [fp, #0x18]
    // 0xb5032c: r0 = *()
    //     0xb5032c: bl              #0x1300ec4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::*
    // 0xb50330: LeaveFrame
    //     0xb50330: mov             SP, fp
    //     0xb50334: ldp             fp, lr, [SP], #0x10
    // 0xb50338: ret
    //     0xb50338: ret             
    // 0xb5033c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5033c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb50340: b               #0xb50320
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x114195c, size: 0x3cc
    // 0x114195c: EnterFrame
    //     0x114195c: stp             fp, lr, [SP, #-0x10]!
    //     0x1141960: mov             fp, SP
    // 0x1141964: AllocStack(0x38)
    //     0x1141964: sub             SP, SP, #0x38
    // 0x1141968: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x1141968: mov             x4, x1
    //     0x114196c: mov             x0, x2
    //     0x1141970: stur            x1, [fp, #-0x10]
    //     0x1141974: stur            x2, [fp, #-0x18]
    // 0x1141978: CheckStackOverflow
    //     0x1141978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114197c: cmp             SP, x16
    //     0x1141980: b.ls            #0x1141bec
    // 0x1141984: cmp             w4, w0
    // 0x1141988: b.ne            #0x114199c
    // 0x114198c: mov             x0, x4
    // 0x1141990: LeaveFrame
    //     0x1141990: mov             SP, fp
    //     0x1141994: ldp             fp, lr, [SP], #0x10
    // 0x1141998: ret
    //     0x1141998: ret             
    // 0x114199c: LoadField: d1 = r4->field_7
    //     0x114199c: ldur            d1, [x4, #7]
    // 0x11419a0: LoadField: d2 = r0->field_7
    //     0x11419a0: ldur            d2, [x0, #7]
    // 0x11419a4: r5 = inline_Allocate_Double()
    //     0x11419a4: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11419a8: add             x5, x5, #0x10
    //     0x11419ac: cmp             x1, x5
    //     0x11419b0: b.ls            #0x1141bf4
    //     0x11419b4: str             x5, [THR, #0x60]  ; THR::top
    //     0x11419b8: sub             x5, x5, #0xf
    //     0x11419bc: mov             x1, #0xe19c
    //     0x11419c0: movk            x1, #3, lsl #16
    //     0x11419c4: stur            x1, [x5, #-1]
    // 0x11419c8: dmb             ishst
    // 0x11419cc: StoreField: r5->field_7 = d0
    //     0x11419cc: stur            d0, [x5, #7]
    // 0x11419d0: stur            x5, [fp, #-8]
    // 0x11419d4: r1 = inline_Allocate_Double()
    //     0x11419d4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x11419d8: add             x1, x1, #0x10
    //     0x11419dc: cmp             x2, x1
    //     0x11419e0: b.ls            #0x1141c18
    //     0x11419e4: str             x1, [THR, #0x60]  ; THR::top
    //     0x11419e8: sub             x1, x1, #0xf
    //     0x11419ec: mov             x2, #0xe19c
    //     0x11419f0: movk            x2, #3, lsl #16
    //     0x11419f4: stur            x2, [x1, #-1]
    // 0x11419f8: dmb             ishst
    // 0x11419fc: StoreField: r1->field_7 = d1
    //     0x11419fc: stur            d1, [x1, #7]
    // 0x1141a00: r2 = inline_Allocate_Double()
    //     0x1141a00: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141a04: add             x2, x2, #0x10
    //     0x1141a08: cmp             x3, x2
    //     0x1141a0c: b.ls            #0x1141c3c
    //     0x1141a10: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141a14: sub             x2, x2, #0xf
    //     0x1141a18: mov             x3, #0xe19c
    //     0x1141a1c: movk            x3, #3, lsl #16
    //     0x1141a20: stur            x3, [x2, #-1]
    // 0x1141a24: dmb             ishst
    // 0x1141a28: StoreField: r2->field_7 = d2
    //     0x1141a28: stur            d2, [x2, #7]
    // 0x1141a2c: mov             x3, x5
    // 0x1141a30: r0 = lerpDouble()
    //     0x1141a30: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141a34: mov             x4, x0
    // 0x1141a38: ldur            x0, [fp, #-0x10]
    // 0x1141a3c: stur            x4, [fp, #-0x20]
    // 0x1141a40: LoadField: d0 = r0->field_f
    //     0x1141a40: ldur            d0, [x0, #0xf]
    // 0x1141a44: ldur            x5, [fp, #-0x18]
    // 0x1141a48: LoadField: d1 = r5->field_f
    //     0x1141a48: ldur            d1, [x5, #0xf]
    // 0x1141a4c: r1 = inline_Allocate_Double()
    //     0x1141a4c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1141a50: add             x1, x1, #0x10
    //     0x1141a54: cmp             x2, x1
    //     0x1141a58: b.ls            #0x1141c60
    //     0x1141a5c: str             x1, [THR, #0x60]  ; THR::top
    //     0x1141a60: sub             x1, x1, #0xf
    //     0x1141a64: mov             x2, #0xe19c
    //     0x1141a68: movk            x2, #3, lsl #16
    //     0x1141a6c: stur            x2, [x1, #-1]
    // 0x1141a70: dmb             ishst
    // 0x1141a74: StoreField: r1->field_7 = d0
    //     0x1141a74: stur            d0, [x1, #7]
    // 0x1141a78: r2 = inline_Allocate_Double()
    //     0x1141a78: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141a7c: add             x2, x2, #0x10
    //     0x1141a80: cmp             x3, x2
    //     0x1141a84: b.ls            #0x1141c84
    //     0x1141a88: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141a8c: sub             x2, x2, #0xf
    //     0x1141a90: mov             x3, #0xe19c
    //     0x1141a94: movk            x3, #3, lsl #16
    //     0x1141a98: stur            x3, [x2, #-1]
    // 0x1141a9c: dmb             ishst
    // 0x1141aa0: StoreField: r2->field_7 = d1
    //     0x1141aa0: stur            d1, [x2, #7]
    // 0x1141aa4: ldur            x3, [fp, #-8]
    // 0x1141aa8: r0 = lerpDouble()
    //     0x1141aa8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141aac: mov             x4, x0
    // 0x1141ab0: ldur            x0, [fp, #-0x10]
    // 0x1141ab4: stur            x4, [fp, #-0x28]
    // 0x1141ab8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x1141ab8: ldur            d0, [x0, #0x17]
    // 0x1141abc: ldur            x5, [fp, #-0x18]
    // 0x1141ac0: ArrayLoad: d1 = r5[0]  ; List_8
    //     0x1141ac0: ldur            d1, [x5, #0x17]
    // 0x1141ac4: r1 = inline_Allocate_Double()
    //     0x1141ac4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1141ac8: add             x1, x1, #0x10
    //     0x1141acc: cmp             x2, x1
    //     0x1141ad0: b.ls            #0x1141ca8
    //     0x1141ad4: str             x1, [THR, #0x60]  ; THR::top
    //     0x1141ad8: sub             x1, x1, #0xf
    //     0x1141adc: mov             x2, #0xe19c
    //     0x1141ae0: movk            x2, #3, lsl #16
    //     0x1141ae4: stur            x2, [x1, #-1]
    // 0x1141ae8: dmb             ishst
    // 0x1141aec: StoreField: r1->field_7 = d0
    //     0x1141aec: stur            d0, [x1, #7]
    // 0x1141af0: r2 = inline_Allocate_Double()
    //     0x1141af0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1141af4: add             x2, x2, #0x10
    //     0x1141af8: cmp             x3, x2
    //     0x1141afc: b.ls            #0x1141ccc
    //     0x1141b00: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141b04: sub             x2, x2, #0xf
    //     0x1141b08: mov             x3, #0xe19c
    //     0x1141b0c: movk            x3, #3, lsl #16
    //     0x1141b10: stur            x3, [x2, #-1]
    // 0x1141b14: dmb             ishst
    // 0x1141b18: StoreField: r2->field_7 = d1
    //     0x1141b18: stur            d1, [x2, #7]
    // 0x1141b1c: ldur            x3, [fp, #-8]
    // 0x1141b20: r0 = lerpDouble()
    //     0x1141b20: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141b24: mov             x4, x0
    // 0x1141b28: ldur            x0, [fp, #-0x10]
    // 0x1141b2c: stur            x4, [fp, #-0x30]
    // 0x1141b30: LoadField: d0 = r0->field_1f
    //     0x1141b30: ldur            d0, [x0, #0x1f]
    // 0x1141b34: ldur            x0, [fp, #-0x18]
    // 0x1141b38: LoadField: d1 = r0->field_1f
    //     0x1141b38: ldur            d1, [x0, #0x1f]
    // 0x1141b3c: r1 = inline_Allocate_Double()
    //     0x1141b3c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x1141b40: add             x1, x1, #0x10
    //     0x1141b44: cmp             x0, x1
    //     0x1141b48: b.ls            #0x1141cf0
    //     0x1141b4c: str             x1, [THR, #0x60]  ; THR::top
    //     0x1141b50: sub             x1, x1, #0xf
    //     0x1141b54: mov             x0, #0xe19c
    //     0x1141b58: movk            x0, #3, lsl #16
    //     0x1141b5c: stur            x0, [x1, #-1]
    // 0x1141b60: dmb             ishst
    // 0x1141b64: StoreField: r1->field_7 = d0
    //     0x1141b64: stur            d0, [x1, #7]
    // 0x1141b68: r2 = inline_Allocate_Double()
    //     0x1141b68: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1141b6c: add             x2, x2, #0x10
    //     0x1141b70: cmp             x0, x2
    //     0x1141b74: b.ls            #0x1141d0c
    //     0x1141b78: str             x2, [THR, #0x60]  ; THR::top
    //     0x1141b7c: sub             x2, x2, #0xf
    //     0x1141b80: mov             x0, #0xe19c
    //     0x1141b84: movk            x0, #3, lsl #16
    //     0x1141b88: stur            x0, [x2, #-1]
    // 0x1141b8c: dmb             ishst
    // 0x1141b90: StoreField: r2->field_7 = d1
    //     0x1141b90: stur            d1, [x2, #7]
    // 0x1141b94: ldur            x3, [fp, #-8]
    // 0x1141b98: r0 = lerpDouble()
    //     0x1141b98: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1141b9c: mov             x1, x0
    // 0x1141ba0: ldur            x0, [fp, #-0x20]
    // 0x1141ba4: stur            x1, [fp, #-8]
    // 0x1141ba8: LoadField: d0 = r0->field_7
    //     0x1141ba8: ldur            d0, [x0, #7]
    // 0x1141bac: stur            d0, [fp, #-0x38]
    // 0x1141bb0: r0 = EdgeInsetsDirectional()
    //     0x1141bb0: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x1141bb4: ldur            d0, [fp, #-0x38]
    // 0x1141bb8: StoreField: r0->field_7 = d0
    //     0x1141bb8: stur            d0, [x0, #7]
    // 0x1141bbc: ldur            x1, [fp, #-0x28]
    // 0x1141bc0: LoadField: d0 = r1->field_7
    //     0x1141bc0: ldur            d0, [x1, #7]
    // 0x1141bc4: StoreField: r0->field_f = d0
    //     0x1141bc4: stur            d0, [x0, #0xf]
    // 0x1141bc8: ldur            x1, [fp, #-0x30]
    // 0x1141bcc: LoadField: d0 = r1->field_7
    //     0x1141bcc: ldur            d0, [x1, #7]
    // 0x1141bd0: ArrayStore: r0[0] = d0  ; List_8
    //     0x1141bd0: stur            d0, [x0, #0x17]
    // 0x1141bd4: ldur            x1, [fp, #-8]
    // 0x1141bd8: LoadField: d0 = r1->field_7
    //     0x1141bd8: ldur            d0, [x1, #7]
    // 0x1141bdc: StoreField: r0->field_1f = d0
    //     0x1141bdc: stur            d0, [x0, #0x1f]
    // 0x1141be0: LeaveFrame
    //     0x1141be0: mov             SP, fp
    //     0x1141be4: ldp             fp, lr, [SP], #0x10
    // 0x1141be8: ret
    //     0x1141be8: ret             
    // 0x1141bec: r0 = StackOverflowSharedWithFPURegs()
    //     0x1141bec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1141bf0: b               #0x1141984
    // 0x1141bf4: stp             q1, q2, [SP, #-0x20]!
    // 0x1141bf8: SaveReg d0
    //     0x1141bf8: str             q0, [SP, #-0x10]!
    // 0x1141bfc: stp             x0, x4, [SP, #-0x10]!
    // 0x1141c00: r0 = AllocateDouble()
    //     0x1141c00: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141c04: mov             x5, x0
    // 0x1141c08: ldp             x0, x4, [SP], #0x10
    // 0x1141c0c: RestoreReg d0
    //     0x1141c0c: ldr             q0, [SP], #0x10
    // 0x1141c10: ldp             q1, q2, [SP], #0x20
    // 0x1141c14: b               #0x11419cc
    // 0x1141c18: stp             q1, q2, [SP, #-0x20]!
    // 0x1141c1c: stp             x4, x5, [SP, #-0x10]!
    // 0x1141c20: SaveReg r0
    //     0x1141c20: str             x0, [SP, #-8]!
    // 0x1141c24: r0 = AllocateDouble()
    //     0x1141c24: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141c28: mov             x1, x0
    // 0x1141c2c: RestoreReg r0
    //     0x1141c2c: ldr             x0, [SP], #8
    // 0x1141c30: ldp             x4, x5, [SP], #0x10
    // 0x1141c34: ldp             q1, q2, [SP], #0x20
    // 0x1141c38: b               #0x11419fc
    // 0x1141c3c: SaveReg d2
    //     0x1141c3c: str             q2, [SP, #-0x10]!
    // 0x1141c40: stp             x4, x5, [SP, #-0x10]!
    // 0x1141c44: stp             x0, x1, [SP, #-0x10]!
    // 0x1141c48: r0 = AllocateDouble()
    //     0x1141c48: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141c4c: mov             x2, x0
    // 0x1141c50: ldp             x0, x1, [SP], #0x10
    // 0x1141c54: ldp             x4, x5, [SP], #0x10
    // 0x1141c58: RestoreReg d2
    //     0x1141c58: ldr             q2, [SP], #0x10
    // 0x1141c5c: b               #0x1141a28
    // 0x1141c60: stp             q0, q1, [SP, #-0x20]!
    // 0x1141c64: stp             x4, x5, [SP, #-0x10]!
    // 0x1141c68: SaveReg r0
    //     0x1141c68: str             x0, [SP, #-8]!
    // 0x1141c6c: r0 = AllocateDouble()
    //     0x1141c6c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141c70: mov             x1, x0
    // 0x1141c74: RestoreReg r0
    //     0x1141c74: ldr             x0, [SP], #8
    // 0x1141c78: ldp             x4, x5, [SP], #0x10
    // 0x1141c7c: ldp             q0, q1, [SP], #0x20
    // 0x1141c80: b               #0x1141a74
    // 0x1141c84: SaveReg d1
    //     0x1141c84: str             q1, [SP, #-0x10]!
    // 0x1141c88: stp             x4, x5, [SP, #-0x10]!
    // 0x1141c8c: stp             x0, x1, [SP, #-0x10]!
    // 0x1141c90: r0 = AllocateDouble()
    //     0x1141c90: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141c94: mov             x2, x0
    // 0x1141c98: ldp             x0, x1, [SP], #0x10
    // 0x1141c9c: ldp             x4, x5, [SP], #0x10
    // 0x1141ca0: RestoreReg d1
    //     0x1141ca0: ldr             q1, [SP], #0x10
    // 0x1141ca4: b               #0x1141aa0
    // 0x1141ca8: stp             q0, q1, [SP, #-0x20]!
    // 0x1141cac: stp             x4, x5, [SP, #-0x10]!
    // 0x1141cb0: SaveReg r0
    //     0x1141cb0: str             x0, [SP, #-8]!
    // 0x1141cb4: r0 = AllocateDouble()
    //     0x1141cb4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141cb8: mov             x1, x0
    // 0x1141cbc: RestoreReg r0
    //     0x1141cbc: ldr             x0, [SP], #8
    // 0x1141cc0: ldp             x4, x5, [SP], #0x10
    // 0x1141cc4: ldp             q0, q1, [SP], #0x20
    // 0x1141cc8: b               #0x1141aec
    // 0x1141ccc: SaveReg d1
    //     0x1141ccc: str             q1, [SP, #-0x10]!
    // 0x1141cd0: stp             x4, x5, [SP, #-0x10]!
    // 0x1141cd4: stp             x0, x1, [SP, #-0x10]!
    // 0x1141cd8: r0 = AllocateDouble()
    //     0x1141cd8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141cdc: mov             x2, x0
    // 0x1141ce0: ldp             x0, x1, [SP], #0x10
    // 0x1141ce4: ldp             x4, x5, [SP], #0x10
    // 0x1141ce8: RestoreReg d1
    //     0x1141ce8: ldr             q1, [SP], #0x10
    // 0x1141cec: b               #0x1141b18
    // 0x1141cf0: stp             q0, q1, [SP, #-0x20]!
    // 0x1141cf4: SaveReg r4
    //     0x1141cf4: str             x4, [SP, #-8]!
    // 0x1141cf8: r0 = AllocateDouble()
    //     0x1141cf8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141cfc: mov             x1, x0
    // 0x1141d00: RestoreReg r4
    //     0x1141d00: ldr             x4, [SP], #8
    // 0x1141d04: ldp             q0, q1, [SP], #0x20
    // 0x1141d08: b               #0x1141b64
    // 0x1141d0c: SaveReg d1
    //     0x1141d0c: str             q1, [SP, #-0x10]!
    // 0x1141d10: stp             x1, x4, [SP, #-0x10]!
    // 0x1141d14: r0 = AllocateDouble()
    //     0x1141d14: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1141d18: mov             x2, x0
    // 0x1141d1c: ldp             x1, x4, [SP], #0x10
    // 0x1141d20: RestoreReg d1
    //     0x1141d20: ldr             q1, [SP], #0x10
    // 0x1141d24: b               #0x1141b90
  }
  EdgeInsetsDirectional *(EdgeInsetsDirectional, double) {
    // ** addr: 0x1300ec4, size: 0x6c
    // 0x1300ec4: EnterFrame
    //     0x1300ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x1300ec8: mov             fp, SP
    // 0x1300ecc: AllocStack(0x20)
    //     0x1300ecc: sub             SP, SP, #0x20
    // 0x1300ed0: LoadField: d1 = r1->field_7
    //     0x1300ed0: ldur            d1, [x1, #7]
    // 0x1300ed4: fmul            d2, d1, d0
    // 0x1300ed8: stur            d2, [fp, #-0x20]
    // 0x1300edc: LoadField: d1 = r1->field_f
    //     0x1300edc: ldur            d1, [x1, #0xf]
    // 0x1300ee0: fmul            d3, d1, d0
    // 0x1300ee4: stur            d3, [fp, #-0x18]
    // 0x1300ee8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x1300ee8: ldur            d1, [x1, #0x17]
    // 0x1300eec: fmul            d4, d1, d0
    // 0x1300ef0: stur            d4, [fp, #-0x10]
    // 0x1300ef4: LoadField: d1 = r1->field_1f
    //     0x1300ef4: ldur            d1, [x1, #0x1f]
    // 0x1300ef8: fmul            d5, d1, d0
    // 0x1300efc: stur            d5, [fp, #-8]
    // 0x1300f00: r0 = EdgeInsetsDirectional()
    //     0x1300f00: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x1300f04: ldur            d0, [fp, #-0x20]
    // 0x1300f08: StoreField: r0->field_7 = d0
    //     0x1300f08: stur            d0, [x0, #7]
    // 0x1300f0c: ldur            d0, [fp, #-0x18]
    // 0x1300f10: StoreField: r0->field_f = d0
    //     0x1300f10: stur            d0, [x0, #0xf]
    // 0x1300f14: ldur            d0, [fp, #-0x10]
    // 0x1300f18: ArrayStore: r0[0] = d0  ; List_8
    //     0x1300f18: stur            d0, [x0, #0x17]
    // 0x1300f1c: ldur            d0, [fp, #-8]
    // 0x1300f20: StoreField: r0->field_1f = d0
    //     0x1300f20: stur            d0, [x0, #0x1f]
    // 0x1300f24: LeaveFrame
    //     0x1300f24: mov             SP, fp
    //     0x1300f28: ldp             fp, lr, [SP], #0x10
    // 0x1300f2c: ret
    //     0x1300f2c: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0x130140c, size: 0x2c
    // 0x130140c: EnterFrame
    //     0x130140c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301410: mov             fp, SP
    // 0x1301414: CheckStackOverflow
    //     0x1301414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1301418: cmp             SP, x16
    //     0x130141c: b.ls            #0x1301430
    // 0x1301420: r0 = add()
    //     0x1301420: bl              #0x1301438  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0x1301424: LeaveFrame
    //     0x1301424: mov             SP, fp
    //     0x1301428: ldp             fp, lr, [SP], #0x10
    // 0x130142c: ret
    //     0x130142c: ret             
    // 0x1301430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1301430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1301434: b               #0x1301420
  }
  EdgeInsets resolve(EdgeInsetsDirectional, TextDirection?) {
    // ** addr: 0x1304ae0, size: 0xbc
    // 0x1304ae0: EnterFrame
    //     0x1304ae0: stp             fp, lr, [SP, #-0x10]!
    //     0x1304ae4: mov             fp, SP
    // 0x1304ae8: AllocStack(0x20)
    //     0x1304ae8: sub             SP, SP, #0x20
    // 0x1304aec: cmp             w2, NULL
    // 0x1304af0: b.eq            #0x1304b98
    // 0x1304af4: LoadField: r0 = r2->field_7
    //     0x1304af4: ldur            x0, [x2, #7]
    // 0x1304af8: cmp             x0, #0
    // 0x1304afc: b.gt            #0x1304b48
    // 0x1304b00: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x1304b00: ldur            d0, [x1, #0x17]
    // 0x1304b04: stur            d0, [fp, #-0x20]
    // 0x1304b08: LoadField: d1 = r1->field_f
    //     0x1304b08: ldur            d1, [x1, #0xf]
    // 0x1304b0c: stur            d1, [fp, #-0x18]
    // 0x1304b10: LoadField: d2 = r1->field_7
    //     0x1304b10: ldur            d2, [x1, #7]
    // 0x1304b14: stur            d2, [fp, #-0x10]
    // 0x1304b18: LoadField: d3 = r1->field_1f
    //     0x1304b18: ldur            d3, [x1, #0x1f]
    // 0x1304b1c: stur            d3, [fp, #-8]
    // 0x1304b20: r0 = EdgeInsets()
    //     0x1304b20: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1304b24: ldur            d0, [fp, #-0x20]
    // 0x1304b28: StoreField: r0->field_7 = d0
    //     0x1304b28: stur            d0, [x0, #7]
    // 0x1304b2c: ldur            d0, [fp, #-0x18]
    // 0x1304b30: StoreField: r0->field_f = d0
    //     0x1304b30: stur            d0, [x0, #0xf]
    // 0x1304b34: ldur            d0, [fp, #-0x10]
    // 0x1304b38: ArrayStore: r0[0] = d0  ; List_8
    //     0x1304b38: stur            d0, [x0, #0x17]
    // 0x1304b3c: ldur            d0, [fp, #-8]
    // 0x1304b40: StoreField: r0->field_1f = d0
    //     0x1304b40: stur            d0, [x0, #0x1f]
    // 0x1304b44: b               #0x1304b8c
    // 0x1304b48: LoadField: d0 = r1->field_7
    //     0x1304b48: ldur            d0, [x1, #7]
    // 0x1304b4c: stur            d0, [fp, #-0x20]
    // 0x1304b50: LoadField: d1 = r1->field_f
    //     0x1304b50: ldur            d1, [x1, #0xf]
    // 0x1304b54: stur            d1, [fp, #-0x18]
    // 0x1304b58: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x1304b58: ldur            d2, [x1, #0x17]
    // 0x1304b5c: stur            d2, [fp, #-0x10]
    // 0x1304b60: LoadField: d3 = r1->field_1f
    //     0x1304b60: ldur            d3, [x1, #0x1f]
    // 0x1304b64: stur            d3, [fp, #-8]
    // 0x1304b68: r0 = EdgeInsets()
    //     0x1304b68: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1304b6c: ldur            d0, [fp, #-0x20]
    // 0x1304b70: StoreField: r0->field_7 = d0
    //     0x1304b70: stur            d0, [x0, #7]
    // 0x1304b74: ldur            d0, [fp, #-0x18]
    // 0x1304b78: StoreField: r0->field_f = d0
    //     0x1304b78: stur            d0, [x0, #0xf]
    // 0x1304b7c: ldur            d0, [fp, #-0x10]
    // 0x1304b80: ArrayStore: r0[0] = d0  ; List_8
    //     0x1304b80: stur            d0, [x0, #0x17]
    // 0x1304b84: ldur            d0, [fp, #-8]
    // 0x1304b88: StoreField: r0->field_1f = d0
    //     0x1304b88: stur            d0, [x0, #0x1f]
    // 0x1304b8c: LeaveFrame
    //     0x1304b8c: mov             SP, fp
    //     0x1304b90: ldp             fp, lr, [SP], #0x10
    // 0x1304b94: ret
    //     0x1304b94: ret             
    // 0x1304b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304b98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2940, size: 0x28, field offset: 0x8
//   const constructor, 
class EdgeInsets extends EdgeInsetsGeometry {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  get _ topLeft(/* No info */) {
    // ** addr: 0x85842c, size: 0x3c
    // 0x85842c: EnterFrame
    //     0x85842c: stp             fp, lr, [SP, #-0x10]!
    //     0x858430: mov             fp, SP
    // 0x858434: AllocStack(0x10)
    //     0x858434: sub             SP, SP, #0x10
    // 0x858438: LoadField: d0 = r1->field_7
    //     0x858438: ldur            d0, [x1, #7]
    // 0x85843c: stur            d0, [fp, #-0x10]
    // 0x858440: LoadField: d1 = r1->field_f
    //     0x858440: ldur            d1, [x1, #0xf]
    // 0x858444: stur            d1, [fp, #-8]
    // 0x858448: r0 = Offset()
    //     0x858448: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85844c: ldur            d0, [fp, #-0x10]
    // 0x858450: StoreField: r0->field_7 = d0
    //     0x858450: stur            d0, [x0, #7]
    // 0x858454: ldur            d0, [fp, #-8]
    // 0x858458: StoreField: r0->field_f = d0
    //     0x858458: stur            d0, [x0, #0xf]
    // 0x85845c: LeaveFrame
    //     0x85845c: mov             SP, fp
    //     0x858460: ldp             fp, lr, [SP], #0x10
    // 0x858464: ret
    //     0x858464: ret             
  }
  EdgeInsets +(EdgeInsets, EdgeInsets) {
    // ** addr: 0x858480, size: 0x84
    // 0x858480: EnterFrame
    //     0x858480: stp             fp, lr, [SP, #-0x10]!
    //     0x858484: mov             fp, SP
    // 0x858488: CheckStackOverflow
    //     0x858488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85848c: cmp             SP, x16
    //     0x858490: b.ls            #0x8584e4
    // 0x858494: ldr             x0, [fp, #0x10]
    // 0x858498: r2 = Null
    //     0x858498: mov             x2, NULL
    // 0x85849c: r1 = Null
    //     0x85849c: mov             x1, NULL
    // 0x8584a0: r4 = 60
    //     0x8584a0: mov             x4, #0x3c
    // 0x8584a4: branchIfSmi(r0, 0x8584b0)
    //     0x8584a4: tbz             w0, #0, #0x8584b0
    // 0x8584a8: r4 = LoadClassIdInstr(r0)
    //     0x8584a8: ldur            x4, [x0, #-1]
    //     0x8584ac: ubfx            x4, x4, #0xc, #0x14
    // 0x8584b0: cmp             x4, #0xb7c
    // 0x8584b4: b.eq            #0x8584cc
    // 0x8584b8: r8 = EdgeInsets
    //     0x8584b8: add             x8, PP, #0x85, lsl #12  ; [pp+0x85560] Type: EdgeInsets
    //     0x8584bc: ldr             x8, [x8, #0x560]
    // 0x8584c0: r3 = Null
    //     0x8584c0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90c90] Null
    //     0x8584c4: ldr             x3, [x3, #0xc90]
    // 0x8584c8: r0 = EdgeInsets()
    //     0x8584c8: bl              #0x858730  ; IsType_EdgeInsets_Stub
    // 0x8584cc: ldr             x1, [fp, #0x18]
    // 0x8584d0: ldr             x2, [fp, #0x10]
    // 0x8584d4: r0 = +()
    //     0x8584d4: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x8584d8: LeaveFrame
    //     0x8584d8: mov             SP, fp
    //     0x8584dc: ldp             fp, lr, [SP], #0x10
    // 0x8584e0: ret
    //     0x8584e0: ret             
    // 0x8584e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8584e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8584e8: b               #0x858494
  }
  EdgeInsets +(EdgeInsets, EdgeInsets) {
    // ** addr: 0x8584ec, size: 0x7c
    // 0x8584ec: EnterFrame
    //     0x8584ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8584f0: mov             fp, SP
    // 0x8584f4: AllocStack(0x20)
    //     0x8584f4: sub             SP, SP, #0x20
    // 0x8584f8: LoadField: d0 = r1->field_7
    //     0x8584f8: ldur            d0, [x1, #7]
    // 0x8584fc: LoadField: d1 = r2->field_7
    //     0x8584fc: ldur            d1, [x2, #7]
    // 0x858500: fadd            d2, d0, d1
    // 0x858504: stur            d2, [fp, #-0x20]
    // 0x858508: LoadField: d0 = r1->field_f
    //     0x858508: ldur            d0, [x1, #0xf]
    // 0x85850c: LoadField: d1 = r2->field_f
    //     0x85850c: ldur            d1, [x2, #0xf]
    // 0x858510: fadd            d3, d0, d1
    // 0x858514: stur            d3, [fp, #-0x18]
    // 0x858518: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x858518: ldur            d0, [x1, #0x17]
    // 0x85851c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x85851c: ldur            d1, [x2, #0x17]
    // 0x858520: fadd            d4, d0, d1
    // 0x858524: stur            d4, [fp, #-0x10]
    // 0x858528: LoadField: d0 = r1->field_1f
    //     0x858528: ldur            d0, [x1, #0x1f]
    // 0x85852c: LoadField: d1 = r2->field_1f
    //     0x85852c: ldur            d1, [x2, #0x1f]
    // 0x858530: fadd            d5, d0, d1
    // 0x858534: stur            d5, [fp, #-8]
    // 0x858538: r0 = EdgeInsets()
    //     0x858538: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x85853c: ldur            d0, [fp, #-0x20]
    // 0x858540: StoreField: r0->field_7 = d0
    //     0x858540: stur            d0, [x0, #7]
    // 0x858544: ldur            d0, [fp, #-0x18]
    // 0x858548: StoreField: r0->field_f = d0
    //     0x858548: stur            d0, [x0, #0xf]
    // 0x85854c: ldur            d0, [fp, #-0x10]
    // 0x858550: ArrayStore: r0[0] = d0  ; List_8
    //     0x858550: stur            d0, [x0, #0x17]
    // 0x858554: ldur            d0, [fp, #-8]
    // 0x858558: StoreField: r0->field_1f = d0
    //     0x858558: stur            d0, [x0, #0x1f]
    // 0x85855c: LeaveFrame
    //     0x85855c: mov             SP, fp
    //     0x858560: ldp             fp, lr, [SP], #0x10
    // 0x858564: ret
    //     0x858564: ret             
  }
  EdgeInsets resolve(EdgeInsets, TextDirection?) {
    // ** addr: 0x85858c, size: 0x6c
    // 0x85858c: EnterFrame
    //     0x85858c: stp             fp, lr, [SP, #-0x10]!
    //     0x858590: mov             fp, SP
    // 0x858594: ldr             x0, [fp, #0x10]
    // 0x858598: r2 = Null
    //     0x858598: mov             x2, NULL
    // 0x85859c: r1 = Null
    //     0x85859c: mov             x1, NULL
    // 0x8585a0: r4 = 60
    //     0x8585a0: mov             x4, #0x3c
    // 0x8585a4: branchIfSmi(r0, 0x8585b0)
    //     0x8585a4: tbz             w0, #0, #0x8585b0
    // 0x8585a8: r4 = LoadClassIdInstr(r0)
    //     0x8585a8: ldur            x4, [x0, #-1]
    //     0x8585ac: ubfx            x4, x4, #0xc, #0x14
    // 0x8585b0: r17 = 8353
    //     0x8585b0: mov             x17, #0x20a1
    // 0x8585b4: cmp             x4, x17
    // 0x8585b8: b.eq            #0x8585d0
    // 0x8585bc: r8 = TextDirection?
    //     0x8585bc: add             x8, PP, #0x82, lsl #12  ; [pp+0x82750] Type: TextDirection?
    //     0x8585c0: ldr             x8, [x8, #0x750]
    // 0x8585c4: r3 = Null
    //     0x8585c4: add             x3, PP, #0x85, lsl #12  ; [pp+0x85550] Null
    //     0x8585c8: ldr             x3, [x3, #0x550]
    // 0x8585cc: r0 = DefaultNullableTypeTest()
    //     0x8585cc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x8585d0: ldr             x0, [fp, #0x18]
    // 0x8585d4: LeaveFrame
    //     0x8585d4: mov             SP, fp
    //     0x8585d8: ldp             fp, lr, [SP], #0x10
    // 0x8585dc: ret
    //     0x8585dc: ret             
  }
  EdgeInsets -(EdgeInsets, EdgeInsets) {
    // ** addr: 0x8585f8, size: 0x84
    // 0x8585f8: EnterFrame
    //     0x8585f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8585fc: mov             fp, SP
    // 0x858600: CheckStackOverflow
    //     0x858600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858604: cmp             SP, x16
    //     0x858608: b.ls            #0x85865c
    // 0x85860c: ldr             x0, [fp, #0x10]
    // 0x858610: r2 = Null
    //     0x858610: mov             x2, NULL
    // 0x858614: r1 = Null
    //     0x858614: mov             x1, NULL
    // 0x858618: r4 = 60
    //     0x858618: mov             x4, #0x3c
    // 0x85861c: branchIfSmi(r0, 0x858628)
    //     0x85861c: tbz             w0, #0, #0x858628
    // 0x858620: r4 = LoadClassIdInstr(r0)
    //     0x858620: ldur            x4, [x0, #-1]
    //     0x858624: ubfx            x4, x4, #0xc, #0x14
    // 0x858628: cmp             x4, #0xb7c
    // 0x85862c: b.eq            #0x858644
    // 0x858630: r8 = EdgeInsets
    //     0x858630: add             x8, PP, #0x85, lsl #12  ; [pp+0x85560] Type: EdgeInsets
    //     0x858634: ldr             x8, [x8, #0x560]
    // 0x858638: r3 = Null
    //     0x858638: add             x3, PP, #0x85, lsl #12  ; [pp+0x85568] Null
    //     0x85863c: ldr             x3, [x3, #0x568]
    // 0x858640: r0 = EdgeInsets()
    //     0x858640: bl              #0x858730  ; IsType_EdgeInsets_Stub
    // 0x858644: ldr             x1, [fp, #0x18]
    // 0x858648: ldr             x2, [fp, #0x10]
    // 0x85864c: r0 = -()
    //     0x85864c: bl              #0x858664  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::-
    // 0x858650: LeaveFrame
    //     0x858650: mov             SP, fp
    //     0x858654: ldp             fp, lr, [SP], #0x10
    // 0x858658: ret
    //     0x858658: ret             
    // 0x85865c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85865c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858660: b               #0x85860c
  }
  EdgeInsets -(EdgeInsets, EdgeInsets) {
    // ** addr: 0x858664, size: 0x7c
    // 0x858664: EnterFrame
    //     0x858664: stp             fp, lr, [SP, #-0x10]!
    //     0x858668: mov             fp, SP
    // 0x85866c: AllocStack(0x20)
    //     0x85866c: sub             SP, SP, #0x20
    // 0x858670: LoadField: d0 = r1->field_7
    //     0x858670: ldur            d0, [x1, #7]
    // 0x858674: LoadField: d1 = r2->field_7
    //     0x858674: ldur            d1, [x2, #7]
    // 0x858678: fsub            d2, d0, d1
    // 0x85867c: stur            d2, [fp, #-0x20]
    // 0x858680: LoadField: d0 = r1->field_f
    //     0x858680: ldur            d0, [x1, #0xf]
    // 0x858684: LoadField: d1 = r2->field_f
    //     0x858684: ldur            d1, [x2, #0xf]
    // 0x858688: fsub            d3, d0, d1
    // 0x85868c: stur            d3, [fp, #-0x18]
    // 0x858690: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x858690: ldur            d0, [x1, #0x17]
    // 0x858694: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x858694: ldur            d1, [x2, #0x17]
    // 0x858698: fsub            d4, d0, d1
    // 0x85869c: stur            d4, [fp, #-0x10]
    // 0x8586a0: LoadField: d0 = r1->field_1f
    //     0x8586a0: ldur            d0, [x1, #0x1f]
    // 0x8586a4: LoadField: d1 = r2->field_1f
    //     0x8586a4: ldur            d1, [x2, #0x1f]
    // 0x8586a8: fsub            d5, d0, d1
    // 0x8586ac: stur            d5, [fp, #-8]
    // 0x8586b0: r0 = EdgeInsets()
    //     0x8586b0: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8586b4: ldur            d0, [fp, #-0x20]
    // 0x8586b8: StoreField: r0->field_7 = d0
    //     0x8586b8: stur            d0, [x0, #7]
    // 0x8586bc: ldur            d0, [fp, #-0x18]
    // 0x8586c0: StoreField: r0->field_f = d0
    //     0x8586c0: stur            d0, [x0, #0xf]
    // 0x8586c4: ldur            d0, [fp, #-0x10]
    // 0x8586c8: ArrayStore: r0[0] = d0  ; List_8
    //     0x8586c8: stur            d0, [x0, #0x17]
    // 0x8586cc: ldur            d0, [fp, #-8]
    // 0x8586d0: StoreField: r0->field_1f = d0
    //     0x8586d0: stur            d0, [x0, #0x1f]
    // 0x8586d4: LeaveFrame
    //     0x8586d4: mov             SP, fp
    //     0x8586d8: ldp             fp, lr, [SP], #0x10
    // 0x8586dc: ret
    //     0x8586dc: ret             
  }
  EdgeInsets *(EdgeInsets, double) {
    // ** addr: 0x8586f8, size: 0x50
    // 0x8586f8: EnterFrame
    //     0x8586f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8586fc: mov             fp, SP
    // 0x858700: CheckStackOverflow
    //     0x858700: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858704: cmp             SP, x16
    //     0x858708: b.ls            #0x858728
    // 0x85870c: ldr             x0, [fp, #0x10]
    // 0x858710: LoadField: d0 = r0->field_7
    //     0x858710: ldur            d0, [x0, #7]
    // 0x858714: ldr             x1, [fp, #0x18]
    // 0x858718: r0 = *()
    //     0x858718: bl              #0x1300e58  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0x85871c: LeaveFrame
    //     0x85871c: mov             SP, fp
    //     0x858720: ldp             fp, lr, [SP], #0x10
    // 0x858724: ret
    //     0x858724: ret             
    // 0x858728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85872c: b               #0x85870c
  }
  _ inflateRect(/* No info */) {
    // ** addr: 0x8685c4, size: 0x7c
    // 0x8685c4: EnterFrame
    //     0x8685c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8685c8: mov             fp, SP
    // 0x8685cc: AllocStack(0x20)
    //     0x8685cc: sub             SP, SP, #0x20
    // 0x8685d0: LoadField: d0 = r2->field_7
    //     0x8685d0: ldur            d0, [x2, #7]
    // 0x8685d4: LoadField: d1 = r1->field_7
    //     0x8685d4: ldur            d1, [x1, #7]
    // 0x8685d8: fsub            d2, d0, d1
    // 0x8685dc: stur            d2, [fp, #-0x20]
    // 0x8685e0: LoadField: d0 = r2->field_f
    //     0x8685e0: ldur            d0, [x2, #0xf]
    // 0x8685e4: LoadField: d1 = r1->field_f
    //     0x8685e4: ldur            d1, [x1, #0xf]
    // 0x8685e8: fsub            d3, d0, d1
    // 0x8685ec: stur            d3, [fp, #-0x18]
    // 0x8685f0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x8685f0: ldur            d0, [x2, #0x17]
    // 0x8685f4: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x8685f4: ldur            d1, [x1, #0x17]
    // 0x8685f8: fadd            d4, d0, d1
    // 0x8685fc: stur            d4, [fp, #-0x10]
    // 0x868600: LoadField: d0 = r2->field_1f
    //     0x868600: ldur            d0, [x2, #0x1f]
    // 0x868604: LoadField: d1 = r1->field_1f
    //     0x868604: ldur            d1, [x1, #0x1f]
    // 0x868608: fadd            d5, d0, d1
    // 0x86860c: stur            d5, [fp, #-8]
    // 0x868610: r0 = Rect()
    //     0x868610: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x868614: ldur            d0, [fp, #-0x20]
    // 0x868618: StoreField: r0->field_7 = d0
    //     0x868618: stur            d0, [x0, #7]
    // 0x86861c: ldur            d0, [fp, #-0x18]
    // 0x868620: StoreField: r0->field_f = d0
    //     0x868620: stur            d0, [x0, #0xf]
    // 0x868624: ldur            d0, [fp, #-0x10]
    // 0x868628: ArrayStore: r0[0] = d0  ; List_8
    //     0x868628: stur            d0, [x0, #0x17]
    // 0x86862c: ldur            d0, [fp, #-8]
    // 0x868630: StoreField: r0->field_1f = d0
    //     0x868630: stur            d0, [x0, #0x1f]
    // 0x868634: LeaveFrame
    //     0x868634: mov             SP, fp
    //     0x868638: ldp             fp, lr, [SP], #0x10
    // 0x86863c: ret
    //     0x86863c: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x868640, size: 0x41c
    // 0x868640: EnterFrame
    //     0x868640: stp             fp, lr, [SP, #-0x10]!
    //     0x868644: mov             fp, SP
    // 0x868648: AllocStack(0x38)
    //     0x868648: sub             SP, SP, #0x38
    // 0x86864c: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x86864c: mov             x4, x1
    //     0x868650: mov             x0, x2
    //     0x868654: stur            x1, [fp, #-0x10]
    //     0x868658: stur            x2, [fp, #-0x18]
    // 0x86865c: CheckStackOverflow
    //     0x86865c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x868660: cmp             SP, x16
    //     0x868664: b.ls            #0x86891c
    // 0x868668: cmp             w4, w0
    // 0x86866c: b.ne            #0x868680
    // 0x868670: mov             x0, x4
    // 0x868674: LeaveFrame
    //     0x868674: mov             SP, fp
    //     0x868678: ldp             fp, lr, [SP], #0x10
    // 0x86867c: ret
    //     0x86867c: ret             
    // 0x868680: cmp             w4, NULL
    // 0x868684: b.ne            #0x8686a4
    // 0x868688: cmp             w0, NULL
    // 0x86868c: b.eq            #0x868924
    // 0x868690: mov             x1, x0
    // 0x868694: r0 = *()
    //     0x868694: bl              #0x1300e58  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0x868698: LeaveFrame
    //     0x868698: mov             SP, fp
    //     0x86869c: ldp             fp, lr, [SP], #0x10
    // 0x8686a0: ret
    //     0x8686a0: ret             
    // 0x8686a4: cmp             w0, NULL
    // 0x8686a8: b.ne            #0x8686cc
    // 0x8686ac: d1 = 1.000000
    //     0x8686ac: fmov            d1, #1.00000000
    // 0x8686b0: fsub            d2, d1, d0
    // 0x8686b4: mov             x1, x4
    // 0x8686b8: mov             v0.16b, v2.16b
    // 0x8686bc: r0 = *()
    //     0x8686bc: bl              #0x1300e58  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0x8686c0: LeaveFrame
    //     0x8686c0: mov             SP, fp
    //     0x8686c4: ldp             fp, lr, [SP], #0x10
    // 0x8686c8: ret
    //     0x8686c8: ret             
    // 0x8686cc: LoadField: d1 = r4->field_7
    //     0x8686cc: ldur            d1, [x4, #7]
    // 0x8686d0: LoadField: d2 = r0->field_7
    //     0x8686d0: ldur            d2, [x0, #7]
    // 0x8686d4: r5 = inline_Allocate_Double()
    //     0x8686d4: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x8686d8: add             x5, x5, #0x10
    //     0x8686dc: cmp             x1, x5
    //     0x8686e0: b.ls            #0x868928
    //     0x8686e4: str             x5, [THR, #0x60]  ; THR::top
    //     0x8686e8: sub             x5, x5, #0xf
    //     0x8686ec: mov             x1, #0xe19c
    //     0x8686f0: movk            x1, #3, lsl #16
    //     0x8686f4: stur            x1, [x5, #-1]
    // 0x8686f8: dmb             ishst
    // 0x8686fc: StoreField: r5->field_7 = d0
    //     0x8686fc: stur            d0, [x5, #7]
    // 0x868700: stur            x5, [fp, #-8]
    // 0x868704: r1 = inline_Allocate_Double()
    //     0x868704: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x868708: add             x1, x1, #0x10
    //     0x86870c: cmp             x2, x1
    //     0x868710: b.ls            #0x86894c
    //     0x868714: str             x1, [THR, #0x60]  ; THR::top
    //     0x868718: sub             x1, x1, #0xf
    //     0x86871c: mov             x2, #0xe19c
    //     0x868720: movk            x2, #3, lsl #16
    //     0x868724: stur            x2, [x1, #-1]
    // 0x868728: dmb             ishst
    // 0x86872c: StoreField: r1->field_7 = d1
    //     0x86872c: stur            d1, [x1, #7]
    // 0x868730: r2 = inline_Allocate_Double()
    //     0x868730: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x868734: add             x2, x2, #0x10
    //     0x868738: cmp             x3, x2
    //     0x86873c: b.ls            #0x868970
    //     0x868740: str             x2, [THR, #0x60]  ; THR::top
    //     0x868744: sub             x2, x2, #0xf
    //     0x868748: mov             x3, #0xe19c
    //     0x86874c: movk            x3, #3, lsl #16
    //     0x868750: stur            x3, [x2, #-1]
    // 0x868754: dmb             ishst
    // 0x868758: StoreField: r2->field_7 = d2
    //     0x868758: stur            d2, [x2, #7]
    // 0x86875c: mov             x3, x5
    // 0x868760: r0 = lerpDouble()
    //     0x868760: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x868764: mov             x4, x0
    // 0x868768: ldur            x0, [fp, #-0x10]
    // 0x86876c: stur            x4, [fp, #-0x20]
    // 0x868770: LoadField: d0 = r0->field_f
    //     0x868770: ldur            d0, [x0, #0xf]
    // 0x868774: ldur            x5, [fp, #-0x18]
    // 0x868778: LoadField: d1 = r5->field_f
    //     0x868778: ldur            d1, [x5, #0xf]
    // 0x86877c: r1 = inline_Allocate_Double()
    //     0x86877c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x868780: add             x1, x1, #0x10
    //     0x868784: cmp             x2, x1
    //     0x868788: b.ls            #0x868994
    //     0x86878c: str             x1, [THR, #0x60]  ; THR::top
    //     0x868790: sub             x1, x1, #0xf
    //     0x868794: mov             x2, #0xe19c
    //     0x868798: movk            x2, #3, lsl #16
    //     0x86879c: stur            x2, [x1, #-1]
    // 0x8687a0: dmb             ishst
    // 0x8687a4: StoreField: r1->field_7 = d0
    //     0x8687a4: stur            d0, [x1, #7]
    // 0x8687a8: r2 = inline_Allocate_Double()
    //     0x8687a8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8687ac: add             x2, x2, #0x10
    //     0x8687b0: cmp             x3, x2
    //     0x8687b4: b.ls            #0x8689b8
    //     0x8687b8: str             x2, [THR, #0x60]  ; THR::top
    //     0x8687bc: sub             x2, x2, #0xf
    //     0x8687c0: mov             x3, #0xe19c
    //     0x8687c4: movk            x3, #3, lsl #16
    //     0x8687c8: stur            x3, [x2, #-1]
    // 0x8687cc: dmb             ishst
    // 0x8687d0: StoreField: r2->field_7 = d1
    //     0x8687d0: stur            d1, [x2, #7]
    // 0x8687d4: ldur            x3, [fp, #-8]
    // 0x8687d8: r0 = lerpDouble()
    //     0x8687d8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x8687dc: mov             x4, x0
    // 0x8687e0: ldur            x0, [fp, #-0x10]
    // 0x8687e4: stur            x4, [fp, #-0x28]
    // 0x8687e8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x8687e8: ldur            d0, [x0, #0x17]
    // 0x8687ec: ldur            x5, [fp, #-0x18]
    // 0x8687f0: ArrayLoad: d1 = r5[0]  ; List_8
    //     0x8687f0: ldur            d1, [x5, #0x17]
    // 0x8687f4: r1 = inline_Allocate_Double()
    //     0x8687f4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8687f8: add             x1, x1, #0x10
    //     0x8687fc: cmp             x2, x1
    //     0x868800: b.ls            #0x8689dc
    //     0x868804: str             x1, [THR, #0x60]  ; THR::top
    //     0x868808: sub             x1, x1, #0xf
    //     0x86880c: mov             x2, #0xe19c
    //     0x868810: movk            x2, #3, lsl #16
    //     0x868814: stur            x2, [x1, #-1]
    // 0x868818: dmb             ishst
    // 0x86881c: StoreField: r1->field_7 = d0
    //     0x86881c: stur            d0, [x1, #7]
    // 0x868820: r2 = inline_Allocate_Double()
    //     0x868820: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x868824: add             x2, x2, #0x10
    //     0x868828: cmp             x3, x2
    //     0x86882c: b.ls            #0x868a00
    //     0x868830: str             x2, [THR, #0x60]  ; THR::top
    //     0x868834: sub             x2, x2, #0xf
    //     0x868838: mov             x3, #0xe19c
    //     0x86883c: movk            x3, #3, lsl #16
    //     0x868840: stur            x3, [x2, #-1]
    // 0x868844: dmb             ishst
    // 0x868848: StoreField: r2->field_7 = d1
    //     0x868848: stur            d1, [x2, #7]
    // 0x86884c: ldur            x3, [fp, #-8]
    // 0x868850: r0 = lerpDouble()
    //     0x868850: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x868854: mov             x4, x0
    // 0x868858: ldur            x0, [fp, #-0x10]
    // 0x86885c: stur            x4, [fp, #-0x30]
    // 0x868860: LoadField: d0 = r0->field_1f
    //     0x868860: ldur            d0, [x0, #0x1f]
    // 0x868864: ldur            x0, [fp, #-0x18]
    // 0x868868: LoadField: d1 = r0->field_1f
    //     0x868868: ldur            d1, [x0, #0x1f]
    // 0x86886c: r1 = inline_Allocate_Double()
    //     0x86886c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x868870: add             x1, x1, #0x10
    //     0x868874: cmp             x0, x1
    //     0x868878: b.ls            #0x868a24
    //     0x86887c: str             x1, [THR, #0x60]  ; THR::top
    //     0x868880: sub             x1, x1, #0xf
    //     0x868884: mov             x0, #0xe19c
    //     0x868888: movk            x0, #3, lsl #16
    //     0x86888c: stur            x0, [x1, #-1]
    // 0x868890: dmb             ishst
    // 0x868894: StoreField: r1->field_7 = d0
    //     0x868894: stur            d0, [x1, #7]
    // 0x868898: r2 = inline_Allocate_Double()
    //     0x868898: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x86889c: add             x2, x2, #0x10
    //     0x8688a0: cmp             x0, x2
    //     0x8688a4: b.ls            #0x868a40
    //     0x8688a8: str             x2, [THR, #0x60]  ; THR::top
    //     0x8688ac: sub             x2, x2, #0xf
    //     0x8688b0: mov             x0, #0xe19c
    //     0x8688b4: movk            x0, #3, lsl #16
    //     0x8688b8: stur            x0, [x2, #-1]
    // 0x8688bc: dmb             ishst
    // 0x8688c0: StoreField: r2->field_7 = d1
    //     0x8688c0: stur            d1, [x2, #7]
    // 0x8688c4: ldur            x3, [fp, #-8]
    // 0x8688c8: r0 = lerpDouble()
    //     0x8688c8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x8688cc: mov             x1, x0
    // 0x8688d0: ldur            x0, [fp, #-0x20]
    // 0x8688d4: stur            x1, [fp, #-8]
    // 0x8688d8: LoadField: d0 = r0->field_7
    //     0x8688d8: ldur            d0, [x0, #7]
    // 0x8688dc: stur            d0, [fp, #-0x38]
    // 0x8688e0: r0 = EdgeInsets()
    //     0x8688e0: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8688e4: ldur            d0, [fp, #-0x38]
    // 0x8688e8: StoreField: r0->field_7 = d0
    //     0x8688e8: stur            d0, [x0, #7]
    // 0x8688ec: ldur            x1, [fp, #-0x28]
    // 0x8688f0: LoadField: d0 = r1->field_7
    //     0x8688f0: ldur            d0, [x1, #7]
    // 0x8688f4: StoreField: r0->field_f = d0
    //     0x8688f4: stur            d0, [x0, #0xf]
    // 0x8688f8: ldur            x1, [fp, #-0x30]
    // 0x8688fc: LoadField: d0 = r1->field_7
    //     0x8688fc: ldur            d0, [x1, #7]
    // 0x868900: ArrayStore: r0[0] = d0  ; List_8
    //     0x868900: stur            d0, [x0, #0x17]
    // 0x868904: ldur            x1, [fp, #-8]
    // 0x868908: LoadField: d0 = r1->field_7
    //     0x868908: ldur            d0, [x1, #7]
    // 0x86890c: StoreField: r0->field_1f = d0
    //     0x86890c: stur            d0, [x0, #0x1f]
    // 0x868910: LeaveFrame
    //     0x868910: mov             SP, fp
    //     0x868914: ldp             fp, lr, [SP], #0x10
    // 0x868918: ret
    //     0x868918: ret             
    // 0x86891c: r0 = StackOverflowSharedWithFPURegs()
    //     0x86891c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x868920: b               #0x868668
    // 0x868924: r0 = NullCastErrorSharedWithFPURegs()
    //     0x868924: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x868928: stp             q1, q2, [SP, #-0x20]!
    // 0x86892c: SaveReg d0
    //     0x86892c: str             q0, [SP, #-0x10]!
    // 0x868930: stp             x0, x4, [SP, #-0x10]!
    // 0x868934: r0 = AllocateDouble()
    //     0x868934: bl              #0x13df878  ; AllocateDoubleStub
    // 0x868938: mov             x5, x0
    // 0x86893c: ldp             x0, x4, [SP], #0x10
    // 0x868940: RestoreReg d0
    //     0x868940: ldr             q0, [SP], #0x10
    // 0x868944: ldp             q1, q2, [SP], #0x20
    // 0x868948: b               #0x8686fc
    // 0x86894c: stp             q1, q2, [SP, #-0x20]!
    // 0x868950: stp             x4, x5, [SP, #-0x10]!
    // 0x868954: SaveReg r0
    //     0x868954: str             x0, [SP, #-8]!
    // 0x868958: r0 = AllocateDouble()
    //     0x868958: bl              #0x13df878  ; AllocateDoubleStub
    // 0x86895c: mov             x1, x0
    // 0x868960: RestoreReg r0
    //     0x868960: ldr             x0, [SP], #8
    // 0x868964: ldp             x4, x5, [SP], #0x10
    // 0x868968: ldp             q1, q2, [SP], #0x20
    // 0x86896c: b               #0x86872c
    // 0x868970: SaveReg d2
    //     0x868970: str             q2, [SP, #-0x10]!
    // 0x868974: stp             x4, x5, [SP, #-0x10]!
    // 0x868978: stp             x0, x1, [SP, #-0x10]!
    // 0x86897c: r0 = AllocateDouble()
    //     0x86897c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x868980: mov             x2, x0
    // 0x868984: ldp             x0, x1, [SP], #0x10
    // 0x868988: ldp             x4, x5, [SP], #0x10
    // 0x86898c: RestoreReg d2
    //     0x86898c: ldr             q2, [SP], #0x10
    // 0x868990: b               #0x868758
    // 0x868994: stp             q0, q1, [SP, #-0x20]!
    // 0x868998: stp             x4, x5, [SP, #-0x10]!
    // 0x86899c: SaveReg r0
    //     0x86899c: str             x0, [SP, #-8]!
    // 0x8689a0: r0 = AllocateDouble()
    //     0x8689a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8689a4: mov             x1, x0
    // 0x8689a8: RestoreReg r0
    //     0x8689a8: ldr             x0, [SP], #8
    // 0x8689ac: ldp             x4, x5, [SP], #0x10
    // 0x8689b0: ldp             q0, q1, [SP], #0x20
    // 0x8689b4: b               #0x8687a4
    // 0x8689b8: SaveReg d1
    //     0x8689b8: str             q1, [SP, #-0x10]!
    // 0x8689bc: stp             x4, x5, [SP, #-0x10]!
    // 0x8689c0: stp             x0, x1, [SP, #-0x10]!
    // 0x8689c4: r0 = AllocateDouble()
    //     0x8689c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8689c8: mov             x2, x0
    // 0x8689cc: ldp             x0, x1, [SP], #0x10
    // 0x8689d0: ldp             x4, x5, [SP], #0x10
    // 0x8689d4: RestoreReg d1
    //     0x8689d4: ldr             q1, [SP], #0x10
    // 0x8689d8: b               #0x8687d0
    // 0x8689dc: stp             q0, q1, [SP, #-0x20]!
    // 0x8689e0: stp             x4, x5, [SP, #-0x10]!
    // 0x8689e4: SaveReg r0
    //     0x8689e4: str             x0, [SP, #-8]!
    // 0x8689e8: r0 = AllocateDouble()
    //     0x8689e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8689ec: mov             x1, x0
    // 0x8689f0: RestoreReg r0
    //     0x8689f0: ldr             x0, [SP], #8
    // 0x8689f4: ldp             x4, x5, [SP], #0x10
    // 0x8689f8: ldp             q0, q1, [SP], #0x20
    // 0x8689fc: b               #0x86881c
    // 0x868a00: SaveReg d1
    //     0x868a00: str             q1, [SP, #-0x10]!
    // 0x868a04: stp             x4, x5, [SP, #-0x10]!
    // 0x868a08: stp             x0, x1, [SP, #-0x10]!
    // 0x868a0c: r0 = AllocateDouble()
    //     0x868a0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x868a10: mov             x2, x0
    // 0x868a14: ldp             x0, x1, [SP], #0x10
    // 0x868a18: ldp             x4, x5, [SP], #0x10
    // 0x868a1c: RestoreReg d1
    //     0x868a1c: ldr             q1, [SP], #0x10
    // 0x868a20: b               #0x868848
    // 0x868a24: stp             q0, q1, [SP, #-0x20]!
    // 0x868a28: SaveReg r4
    //     0x868a28: str             x4, [SP, #-8]!
    // 0x868a2c: r0 = AllocateDouble()
    //     0x868a2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x868a30: mov             x1, x0
    // 0x868a34: RestoreReg r4
    //     0x868a34: ldr             x4, [SP], #8
    // 0x868a38: ldp             q0, q1, [SP], #0x20
    // 0x868a3c: b               #0x868894
    // 0x868a40: SaveReg d1
    //     0x868a40: str             q1, [SP, #-0x10]!
    // 0x868a44: stp             x1, x4, [SP, #-0x10]!
    // 0x868a48: r0 = AllocateDouble()
    //     0x868a48: bl              #0x13df878  ; AllocateDoubleStub
    // 0x868a4c: mov             x2, x0
    // 0x868a50: ldp             x1, x4, [SP], #0x10
    // 0x868a54: RestoreReg d1
    //     0x868a54: ldr             q1, [SP], #0x10
    // 0x868a58: b               #0x8688c0
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x86fd70, size: 0x1d4
    // 0x86fd70: EnterFrame
    //     0x86fd70: stp             fp, lr, [SP, #-0x10]!
    //     0x86fd74: mov             fp, SP
    // 0x86fd78: AllocStack(0x20)
    //     0x86fd78: sub             SP, SP, #0x20
    // 0x86fd7c: SetupParameters({dynamic bottom = Null /* r3 */, dynamic left = Null /* r5 */, dynamic right = Null /* r6 */, dynamic top = Null /* r0 */})
    //     0x86fd7c: ldur            w0, [x4, #0x13]
    //     0x86fd80: ldur            w2, [x4, #0x1f]
    //     0x86fd84: add             x2, x2, HEAP, lsl #32
    //     0x86fd88: ldr             x16, [PP, #0x57b8]  ; [pp+0x57b8] "bottom"
    //     0x86fd8c: cmp             w2, w16
    //     0x86fd90: b.ne            #0x86fdb4
    //     0x86fd94: ldur            w2, [x4, #0x23]
    //     0x86fd98: add             x2, x2, HEAP, lsl #32
    //     0x86fd9c: sub             w3, w0, w2
    //     0x86fda0: add             x2, fp, w3, sxtw #2
    //     0x86fda4: ldr             x2, [x2, #8]
    //     0x86fda8: mov             x3, x2
    //     0x86fdac: mov             x2, #1
    //     0x86fdb0: b               #0x86fdbc
    //     0x86fdb4: mov             x3, NULL
    //     0x86fdb8: mov             x2, #0
    //     0x86fdbc: lsl             x5, x2, #1
    //     0x86fdc0: lsl             w6, w5, #1
    //     0x86fdc4: add             w7, w6, #8
    //     0x86fdc8: add             x16, x4, w7, sxtw #1
    //     0x86fdcc: ldur            w8, [x16, #0xf]
    //     0x86fdd0: add             x8, x8, HEAP, lsl #32
    //     0x86fdd4: ldr             x16, [PP, #0x57c0]  ; [pp+0x57c0] "left"
    //     0x86fdd8: cmp             w8, w16
    //     0x86fddc: b.ne            #0x86fe10
    //     0x86fde0: add             w2, w6, #0xa
    //     0x86fde4: add             x16, x4, w2, sxtw #1
    //     0x86fde8: ldur            w6, [x16, #0xf]
    //     0x86fdec: add             x6, x6, HEAP, lsl #32
    //     0x86fdf0: sub             w2, w0, w6
    //     0x86fdf4: add             x6, fp, w2, sxtw #2
    //     0x86fdf8: ldr             x6, [x6, #8]
    //     0x86fdfc: add             w2, w5, #2
    //     0x86fe00: sbfx            x5, x2, #1, #0x1f
    //     0x86fe04: mov             x2, x5
    //     0x86fe08: mov             x5, x6
    //     0x86fe0c: b               #0x86fe14
    //     0x86fe10: mov             x5, NULL
    //     0x86fe14: lsl             x6, x2, #1
    //     0x86fe18: lsl             w7, w6, #1
    //     0x86fe1c: add             w8, w7, #8
    //     0x86fe20: add             x16, x4, w8, sxtw #1
    //     0x86fe24: ldur            w9, [x16, #0xf]
    //     0x86fe28: add             x9, x9, HEAP, lsl #32
    //     0x86fe2c: ldr             x16, [PP, #0x57c8]  ; [pp+0x57c8] "right"
    //     0x86fe30: cmp             w9, w16
    //     0x86fe34: b.ne            #0x86fe68
    //     0x86fe38: add             w2, w7, #0xa
    //     0x86fe3c: add             x16, x4, w2, sxtw #1
    //     0x86fe40: ldur            w7, [x16, #0xf]
    //     0x86fe44: add             x7, x7, HEAP, lsl #32
    //     0x86fe48: sub             w2, w0, w7
    //     0x86fe4c: add             x7, fp, w2, sxtw #2
    //     0x86fe50: ldr             x7, [x7, #8]
    //     0x86fe54: add             w2, w6, #2
    //     0x86fe58: sbfx            x6, x2, #1, #0x1f
    //     0x86fe5c: mov             x2, x6
    //     0x86fe60: mov             x6, x7
    //     0x86fe64: b               #0x86fe6c
    //     0x86fe68: mov             x6, NULL
    //     0x86fe6c: lsl             x7, x2, #1
    //     0x86fe70: lsl             w2, w7, #1
    //     0x86fe74: add             w7, w2, #8
    //     0x86fe78: add             x16, x4, w7, sxtw #1
    //     0x86fe7c: ldur            w8, [x16, #0xf]
    //     0x86fe80: add             x8, x8, HEAP, lsl #32
    //     0x86fe84: ldr             x16, [PP, #0x57d0]  ; [pp+0x57d0] "top"
    //     0x86fe88: cmp             w8, w16
    //     0x86fe8c: b.ne            #0x86feb0
    //     0x86fe90: add             w7, w2, #0xa
    //     0x86fe94: add             x16, x4, w7, sxtw #1
    //     0x86fe98: ldur            w2, [x16, #0xf]
    //     0x86fe9c: add             x2, x2, HEAP, lsl #32
    //     0x86fea0: sub             w4, w0, w2
    //     0x86fea4: add             x0, fp, w4, sxtw #2
    //     0x86fea8: ldr             x0, [x0, #8]
    //     0x86feac: b               #0x86feb4
    //     0x86feb0: mov             x0, NULL
    // 0x86feb4: cmp             w5, NULL
    // 0x86feb8: b.ne            #0x86fec4
    // 0x86febc: LoadField: d0 = r1->field_7
    //     0x86febc: ldur            d0, [x1, #7]
    // 0x86fec0: b               #0x86fec8
    // 0x86fec4: LoadField: d0 = r5->field_7
    //     0x86fec4: ldur            d0, [x5, #7]
    // 0x86fec8: stur            d0, [fp, #-0x20]
    // 0x86fecc: cmp             w0, NULL
    // 0x86fed0: b.ne            #0x86fedc
    // 0x86fed4: LoadField: d1 = r1->field_f
    //     0x86fed4: ldur            d1, [x1, #0xf]
    // 0x86fed8: b               #0x86fee0
    // 0x86fedc: LoadField: d1 = r0->field_7
    //     0x86fedc: ldur            d1, [x0, #7]
    // 0x86fee0: stur            d1, [fp, #-0x18]
    // 0x86fee4: cmp             w6, NULL
    // 0x86fee8: b.ne            #0x86fef4
    // 0x86feec: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x86feec: ldur            d2, [x1, #0x17]
    // 0x86fef0: b               #0x86fef8
    // 0x86fef4: LoadField: d2 = r6->field_7
    //     0x86fef4: ldur            d2, [x6, #7]
    // 0x86fef8: stur            d2, [fp, #-0x10]
    // 0x86fefc: cmp             w3, NULL
    // 0x86ff00: b.ne            #0x86ff0c
    // 0x86ff04: LoadField: d3 = r1->field_1f
    //     0x86ff04: ldur            d3, [x1, #0x1f]
    // 0x86ff08: b               #0x86ff10
    // 0x86ff0c: LoadField: d3 = r3->field_7
    //     0x86ff0c: ldur            d3, [x3, #7]
    // 0x86ff10: stur            d3, [fp, #-8]
    // 0x86ff14: r0 = EdgeInsets()
    //     0x86ff14: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x86ff18: ldur            d0, [fp, #-0x20]
    // 0x86ff1c: StoreField: r0->field_7 = d0
    //     0x86ff1c: stur            d0, [x0, #7]
    // 0x86ff20: ldur            d0, [fp, #-0x18]
    // 0x86ff24: StoreField: r0->field_f = d0
    //     0x86ff24: stur            d0, [x0, #0xf]
    // 0x86ff28: ldur            d0, [fp, #-0x10]
    // 0x86ff2c: ArrayStore: r0[0] = d0  ; List_8
    //     0x86ff2c: stur            d0, [x0, #0x17]
    // 0x86ff30: ldur            d0, [fp, #-8]
    // 0x86ff34: StoreField: r0->field_1f = d0
    //     0x86ff34: stur            d0, [x0, #0x1f]
    // 0x86ff38: LeaveFrame
    //     0x86ff38: mov             SP, fp
    //     0x86ff3c: ldp             fp, lr, [SP], #0x10
    // 0x86ff40: ret
    //     0x86ff40: ret             
  }
  _ EdgeInsets.fromViewPadding(/* No info */) {
    // ** addr: 0x8cf744, size: 0x38
    // 0x8cf744: LoadField: d1 = r2->field_7
    //     0x8cf744: ldur            d1, [x2, #7]
    // 0x8cf748: fdiv            d2, d1, d0
    // 0x8cf74c: StoreField: r1->field_7 = d2
    //     0x8cf74c: stur            d2, [x1, #7]
    // 0x8cf750: LoadField: d1 = r2->field_f
    //     0x8cf750: ldur            d1, [x2, #0xf]
    // 0x8cf754: fdiv            d2, d1, d0
    // 0x8cf758: StoreField: r1->field_f = d2
    //     0x8cf758: stur            d2, [x1, #0xf]
    // 0x8cf75c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x8cf75c: ldur            d1, [x2, #0x17]
    // 0x8cf760: fdiv            d2, d1, d0
    // 0x8cf764: ArrayStore: r1[0] = d2  ; List_8
    //     0x8cf764: stur            d2, [x1, #0x17]
    // 0x8cf768: LoadField: d1 = r2->field_1f
    //     0x8cf768: ldur            d1, [x2, #0x1f]
    // 0x8cf76c: fdiv            d2, d1, d0
    // 0x8cf770: StoreField: r1->field_1f = d2
    //     0x8cf770: stur            d2, [x1, #0x1f]
    // 0x8cf774: r0 = Null
    //     0x8cf774: mov             x0, NULL
    // 0x8cf778: ret
    //     0x8cf778: ret             
  }
  _ deflateRect(/* No info */) {
    // ** addr: 0xb7a1f4, size: 0x7c
    // 0xb7a1f4: EnterFrame
    //     0xb7a1f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a1f8: mov             fp, SP
    // 0xb7a1fc: AllocStack(0x20)
    //     0xb7a1fc: sub             SP, SP, #0x20
    // 0xb7a200: LoadField: d0 = r2->field_7
    //     0xb7a200: ldur            d0, [x2, #7]
    // 0xb7a204: LoadField: d1 = r1->field_7
    //     0xb7a204: ldur            d1, [x1, #7]
    // 0xb7a208: fadd            d2, d0, d1
    // 0xb7a20c: stur            d2, [fp, #-0x20]
    // 0xb7a210: LoadField: d0 = r2->field_f
    //     0xb7a210: ldur            d0, [x2, #0xf]
    // 0xb7a214: LoadField: d1 = r1->field_f
    //     0xb7a214: ldur            d1, [x1, #0xf]
    // 0xb7a218: fadd            d3, d0, d1
    // 0xb7a21c: stur            d3, [fp, #-0x18]
    // 0xb7a220: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xb7a220: ldur            d0, [x2, #0x17]
    // 0xb7a224: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb7a224: ldur            d1, [x1, #0x17]
    // 0xb7a228: fsub            d4, d0, d1
    // 0xb7a22c: stur            d4, [fp, #-0x10]
    // 0xb7a230: LoadField: d0 = r2->field_1f
    //     0xb7a230: ldur            d0, [x2, #0x1f]
    // 0xb7a234: LoadField: d1 = r1->field_1f
    //     0xb7a234: ldur            d1, [x1, #0x1f]
    // 0xb7a238: fsub            d5, d0, d1
    // 0xb7a23c: stur            d5, [fp, #-8]
    // 0xb7a240: r0 = Rect()
    //     0xb7a240: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7a244: ldur            d0, [fp, #-0x20]
    // 0xb7a248: StoreField: r0->field_7 = d0
    //     0xb7a248: stur            d0, [x0, #7]
    // 0xb7a24c: ldur            d0, [fp, #-0x18]
    // 0xb7a250: StoreField: r0->field_f = d0
    //     0xb7a250: stur            d0, [x0, #0xf]
    // 0xb7a254: ldur            d0, [fp, #-0x10]
    // 0xb7a258: ArrayStore: r0[0] = d0  ; List_8
    //     0xb7a258: stur            d0, [x0, #0x17]
    // 0xb7a25c: ldur            d0, [fp, #-8]
    // 0xb7a260: StoreField: r0->field_1f = d0
    //     0xb7a260: stur            d0, [x0, #0x1f]
    // 0xb7a264: LeaveFrame
    //     0xb7a264: mov             SP, fp
    //     0xb7a268: ldp             fp, lr, [SP], #0x10
    // 0xb7a26c: ret
    //     0xb7a26c: ret             
  }
  _ inflateRRect(/* No info */) {
    // ** addr: 0x12ee578, size: 0x240
    // 0x12ee578: EnterFrame
    //     0x12ee578: stp             fp, lr, [SP, #-0x10]!
    //     0x12ee57c: mov             fp, SP
    // 0x12ee580: AllocStack(0x98)
    //     0x12ee580: sub             SP, SP, #0x98
    // 0x12ee584: SetupParameters(EdgeInsets this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x12ee584: mov             x0, x1
    //     0x12ee588: mov             x1, x2
    //     0x12ee58c: stur            x2, [fp, #-8]
    // 0x12ee590: CheckStackOverflow
    //     0x12ee590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ee594: cmp             SP, x16
    //     0x12ee598: b.ls            #0x12ee7b0
    // 0x12ee59c: LoadField: d0 = r1->field_b
    //     0x12ee59c: ldur            d0, [x1, #0xb]
    // 0x12ee5a0: LoadField: d1 = r0->field_7
    //     0x12ee5a0: ldur            d1, [x0, #7]
    // 0x12ee5a4: stur            d1, [fp, #-0x78]
    // 0x12ee5a8: fsub            d2, d0, d1
    // 0x12ee5ac: stur            d2, [fp, #-0x70]
    // 0x12ee5b0: LoadField: d0 = r1->field_13
    //     0x12ee5b0: ldur            d0, [x1, #0x13]
    // 0x12ee5b4: LoadField: d3 = r0->field_f
    //     0x12ee5b4: ldur            d3, [x0, #0xf]
    // 0x12ee5b8: stur            d3, [fp, #-0x68]
    // 0x12ee5bc: fsub            d4, d0, d3
    // 0x12ee5c0: stur            d4, [fp, #-0x60]
    // 0x12ee5c4: LoadField: d0 = r1->field_1b
    //     0x12ee5c4: ldur            d0, [x1, #0x1b]
    // 0x12ee5c8: ArrayLoad: d5 = r0[0]  ; List_8
    //     0x12ee5c8: ldur            d5, [x0, #0x17]
    // 0x12ee5cc: stur            d5, [fp, #-0x58]
    // 0x12ee5d0: fadd            d6, d0, d5
    // 0x12ee5d4: stur            d6, [fp, #-0x50]
    // 0x12ee5d8: LoadField: d0 = r1->field_23
    //     0x12ee5d8: ldur            d0, [x1, #0x23]
    // 0x12ee5dc: LoadField: d7 = r0->field_1f
    //     0x12ee5dc: ldur            d7, [x0, #0x1f]
    // 0x12ee5e0: stur            d7, [fp, #-0x48]
    // 0x12ee5e4: fadd            d8, d0, d7
    // 0x12ee5e8: stur            d8, [fp, #-0x40]
    // 0x12ee5ec: LoadField: d0 = r1->field_2b
    //     0x12ee5ec: ldur            d0, [x1, #0x2b]
    // 0x12ee5f0: stur            d0, [fp, #-0x38]
    // 0x12ee5f4: LoadField: d9 = r1->field_33
    //     0x12ee5f4: ldur            d9, [x1, #0x33]
    // 0x12ee5f8: stur            d9, [fp, #-0x30]
    // 0x12ee5fc: r0 = Radius()
    //     0x12ee5fc: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee600: ldur            d0, [fp, #-0x38]
    // 0x12ee604: stur            x0, [fp, #-0x10]
    // 0x12ee608: StoreField: r0->field_7 = d0
    //     0x12ee608: stur            d0, [x0, #7]
    // 0x12ee60c: ldur            d0, [fp, #-0x30]
    // 0x12ee610: StoreField: r0->field_f = d0
    //     0x12ee610: stur            d0, [x0, #0xf]
    // 0x12ee614: r0 = Radius()
    //     0x12ee614: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee618: ldur            d0, [fp, #-0x78]
    // 0x12ee61c: StoreField: r0->field_7 = d0
    //     0x12ee61c: stur            d0, [x0, #7]
    // 0x12ee620: ldur            d1, [fp, #-0x68]
    // 0x12ee624: StoreField: r0->field_f = d1
    //     0x12ee624: stur            d1, [x0, #0xf]
    // 0x12ee628: ldur            x1, [fp, #-0x10]
    // 0x12ee62c: mov             x2, x0
    // 0x12ee630: r0 = +()
    //     0x12ee630: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12ee634: r16 = Instance_Radius
    //     0x12ee634: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee638: ldr             x16, [x16, #0x1a0]
    // 0x12ee63c: str             x16, [SP]
    // 0x12ee640: mov             x1, x0
    // 0x12ee644: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee644: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee648: ldr             x4, [x4, #0x678]
    // 0x12ee64c: r0 = clamp()
    //     0x12ee64c: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee650: ldur            x1, [fp, #-8]
    // 0x12ee654: stur            x0, [fp, #-0x10]
    // 0x12ee658: r0 = trRadius()
    //     0x12ee658: bl              #0x12ee7f4  ; [dart:ui] _RRectLike::trRadius
    // 0x12ee65c: stur            x0, [fp, #-0x18]
    // 0x12ee660: r0 = Radius()
    //     0x12ee660: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee664: ldur            d0, [fp, #-0x58]
    // 0x12ee668: StoreField: r0->field_7 = d0
    //     0x12ee668: stur            d0, [x0, #7]
    // 0x12ee66c: ldur            d1, [fp, #-0x68]
    // 0x12ee670: StoreField: r0->field_f = d1
    //     0x12ee670: stur            d1, [x0, #0xf]
    // 0x12ee674: ldur            x1, [fp, #-0x18]
    // 0x12ee678: mov             x2, x0
    // 0x12ee67c: r0 = +()
    //     0x12ee67c: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12ee680: r16 = Instance_Radius
    //     0x12ee680: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee684: ldr             x16, [x16, #0x1a0]
    // 0x12ee688: str             x16, [SP]
    // 0x12ee68c: mov             x1, x0
    // 0x12ee690: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee690: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee694: ldr             x4, [x4, #0x678]
    // 0x12ee698: r0 = clamp()
    //     0x12ee698: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee69c: ldur            x1, [fp, #-8]
    // 0x12ee6a0: stur            x0, [fp, #-0x18]
    // 0x12ee6a4: LoadField: d0 = r1->field_4b
    //     0x12ee6a4: ldur            d0, [x1, #0x4b]
    // 0x12ee6a8: stur            d0, [fp, #-0x38]
    // 0x12ee6ac: LoadField: d1 = r1->field_53
    //     0x12ee6ac: ldur            d1, [x1, #0x53]
    // 0x12ee6b0: stur            d1, [fp, #-0x30]
    // 0x12ee6b4: r0 = Radius()
    //     0x12ee6b4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee6b8: ldur            d0, [fp, #-0x38]
    // 0x12ee6bc: stur            x0, [fp, #-0x20]
    // 0x12ee6c0: StoreField: r0->field_7 = d0
    //     0x12ee6c0: stur            d0, [x0, #7]
    // 0x12ee6c4: ldur            d0, [fp, #-0x30]
    // 0x12ee6c8: StoreField: r0->field_f = d0
    //     0x12ee6c8: stur            d0, [x0, #0xf]
    // 0x12ee6cc: r0 = Radius()
    //     0x12ee6cc: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee6d0: ldur            d0, [fp, #-0x58]
    // 0x12ee6d4: StoreField: r0->field_7 = d0
    //     0x12ee6d4: stur            d0, [x0, #7]
    // 0x12ee6d8: ldur            d0, [fp, #-0x48]
    // 0x12ee6dc: StoreField: r0->field_f = d0
    //     0x12ee6dc: stur            d0, [x0, #0xf]
    // 0x12ee6e0: ldur            x1, [fp, #-0x20]
    // 0x12ee6e4: mov             x2, x0
    // 0x12ee6e8: r0 = +()
    //     0x12ee6e8: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12ee6ec: r16 = Instance_Radius
    //     0x12ee6ec: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee6f0: ldr             x16, [x16, #0x1a0]
    // 0x12ee6f4: str             x16, [SP]
    // 0x12ee6f8: mov             x1, x0
    // 0x12ee6fc: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee6fc: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee700: ldr             x4, [x4, #0x678]
    // 0x12ee704: r0 = clamp()
    //     0x12ee704: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee708: ldur            x1, [fp, #-8]
    // 0x12ee70c: stur            x0, [fp, #-8]
    // 0x12ee710: r0 = blRadius()
    //     0x12ee710: bl              #0x12ee7b8  ; [dart:ui] _RRectLike::blRadius
    // 0x12ee714: stur            x0, [fp, #-0x20]
    // 0x12ee718: r0 = Radius()
    //     0x12ee718: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee71c: ldur            d0, [fp, #-0x78]
    // 0x12ee720: StoreField: r0->field_7 = d0
    //     0x12ee720: stur            d0, [x0, #7]
    // 0x12ee724: ldur            d0, [fp, #-0x48]
    // 0x12ee728: StoreField: r0->field_f = d0
    //     0x12ee728: stur            d0, [x0, #0xf]
    // 0x12ee72c: ldur            x1, [fp, #-0x20]
    // 0x12ee730: mov             x2, x0
    // 0x12ee734: r0 = +()
    //     0x12ee734: bl              #0x8a51a0  ; [dart:ui] Radius::+
    // 0x12ee738: r16 = Instance_Radius
    //     0x12ee738: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee73c: ldr             x16, [x16, #0x1a0]
    // 0x12ee740: str             x16, [SP]
    // 0x12ee744: mov             x1, x0
    // 0x12ee748: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee748: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee74c: ldr             x4, [x4, #0x678]
    // 0x12ee750: r0 = clamp()
    //     0x12ee750: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee754: r1 = <RRect>
    //     0x12ee754: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12ee758: ldr             x1, [x1, #0x108]
    // 0x12ee75c: stur            x0, [fp, #-0x20]
    // 0x12ee760: r0 = RRect()
    //     0x12ee760: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12ee764: stur            x0, [fp, #-0x28]
    // 0x12ee768: ldur            x16, [fp, #-0x10]
    // 0x12ee76c: ldur            lr, [fp, #-0x18]
    // 0x12ee770: stp             lr, x16, [SP, #0x10]
    // 0x12ee774: ldur            x16, [fp, #-8]
    // 0x12ee778: ldur            lr, [fp, #-0x20]
    // 0x12ee77c: stp             lr, x16, [SP]
    // 0x12ee780: mov             x1, x0
    // 0x12ee784: ldur            d0, [fp, #-0x70]
    // 0x12ee788: ldur            d1, [fp, #-0x60]
    // 0x12ee78c: ldur            d2, [fp, #-0x50]
    // 0x12ee790: ldur            d3, [fp, #-0x40]
    // 0x12ee794: r4 = const [0, 0x9, 0x4, 0x5, bottomLeft, 0x8, bottomRight, 0x7, topLeft, 0x5, topRight, 0x6, null]
    //     0x12ee794: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0da0] List(13) [0, 0x9, 0x4, 0x5, "bottomLeft", 0x8, "bottomRight", 0x7, "topLeft", 0x5, "topRight", 0x6, Null]
    //     0x12ee798: ldr             x4, [x4, #0xda0]
    // 0x12ee79c: r0 = RRect.fromLTRBAndCorners()
    //     0x12ee79c: bl              #0xc24690  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0x12ee7a0: ldur            x0, [fp, #-0x28]
    // 0x12ee7a4: LeaveFrame
    //     0x12ee7a4: mov             SP, fp
    //     0x12ee7a8: ldp             fp, lr, [SP], #0x10
    // 0x12ee7ac: ret
    //     0x12ee7ac: ret             
    // 0x12ee7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ee7b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ee7b4: b               #0x12ee59c
  }
  _ deflateRRect(/* No info */) {
    // ** addr: 0x12ee830, size: 0x284
    // 0x12ee830: EnterFrame
    //     0x12ee830: stp             fp, lr, [SP, #-0x10]!
    //     0x12ee834: mov             fp, SP
    // 0x12ee838: AllocStack(0x98)
    //     0x12ee838: sub             SP, SP, #0x98
    // 0x12ee83c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x12ee83c: stur            x2, [fp, #-8]
    // 0x12ee840: CheckStackOverflow
    //     0x12ee840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ee844: cmp             SP, x16
    //     0x12ee848: b.ls            #0x12eeaac
    // 0x12ee84c: LoadField: d0 = r2->field_b
    //     0x12ee84c: ldur            d0, [x2, #0xb]
    // 0x12ee850: LoadField: d1 = r1->field_7
    //     0x12ee850: ldur            d1, [x1, #7]
    // 0x12ee854: stur            d1, [fp, #-0x78]
    // 0x12ee858: fadd            d2, d0, d1
    // 0x12ee85c: stur            d2, [fp, #-0x70]
    // 0x12ee860: LoadField: d0 = r2->field_13
    //     0x12ee860: ldur            d0, [x2, #0x13]
    // 0x12ee864: LoadField: d3 = r1->field_f
    //     0x12ee864: ldur            d3, [x1, #0xf]
    // 0x12ee868: stur            d3, [fp, #-0x68]
    // 0x12ee86c: fadd            d4, d0, d3
    // 0x12ee870: stur            d4, [fp, #-0x60]
    // 0x12ee874: LoadField: d0 = r2->field_1b
    //     0x12ee874: ldur            d0, [x2, #0x1b]
    // 0x12ee878: ArrayLoad: d5 = r1[0]  ; List_8
    //     0x12ee878: ldur            d5, [x1, #0x17]
    // 0x12ee87c: stur            d5, [fp, #-0x58]
    // 0x12ee880: fsub            d6, d0, d5
    // 0x12ee884: stur            d6, [fp, #-0x50]
    // 0x12ee888: LoadField: d0 = r2->field_23
    //     0x12ee888: ldur            d0, [x2, #0x23]
    // 0x12ee88c: LoadField: d7 = r1->field_1f
    //     0x12ee88c: ldur            d7, [x1, #0x1f]
    // 0x12ee890: stur            d7, [fp, #-0x48]
    // 0x12ee894: fsub            d8, d0, d7
    // 0x12ee898: stur            d8, [fp, #-0x40]
    // 0x12ee89c: LoadField: d0 = r2->field_2b
    //     0x12ee89c: ldur            d0, [x2, #0x2b]
    // 0x12ee8a0: stur            d0, [fp, #-0x38]
    // 0x12ee8a4: LoadField: d9 = r2->field_33
    //     0x12ee8a4: ldur            d9, [x2, #0x33]
    // 0x12ee8a8: stur            d9, [fp, #-0x30]
    // 0x12ee8ac: r0 = Radius()
    //     0x12ee8ac: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee8b0: ldur            d0, [fp, #-0x38]
    // 0x12ee8b4: stur            x0, [fp, #-0x10]
    // 0x12ee8b8: StoreField: r0->field_7 = d0
    //     0x12ee8b8: stur            d0, [x0, #7]
    // 0x12ee8bc: ldur            d0, [fp, #-0x30]
    // 0x12ee8c0: StoreField: r0->field_f = d0
    //     0x12ee8c0: stur            d0, [x0, #0xf]
    // 0x12ee8c4: r0 = Radius()
    //     0x12ee8c4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee8c8: ldur            d0, [fp, #-0x78]
    // 0x12ee8cc: StoreField: r0->field_7 = d0
    //     0x12ee8cc: stur            d0, [x0, #7]
    // 0x12ee8d0: ldur            d1, [fp, #-0x68]
    // 0x12ee8d4: StoreField: r0->field_f = d1
    //     0x12ee8d4: stur            d1, [x0, #0xf]
    // 0x12ee8d8: ldur            x1, [fp, #-0x10]
    // 0x12ee8dc: mov             x2, x0
    // 0x12ee8e0: r0 = -()
    //     0x12ee8e0: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12ee8e4: r16 = Instance_Radius
    //     0x12ee8e4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee8e8: ldr             x16, [x16, #0x1a0]
    // 0x12ee8ec: str             x16, [SP]
    // 0x12ee8f0: mov             x1, x0
    // 0x12ee8f4: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee8f4: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee8f8: ldr             x4, [x4, #0x678]
    // 0x12ee8fc: r0 = clamp()
    //     0x12ee8fc: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee900: mov             x1, x0
    // 0x12ee904: ldur            x0, [fp, #-8]
    // 0x12ee908: stur            x1, [fp, #-0x10]
    // 0x12ee90c: LoadField: d0 = r0->field_3b
    //     0x12ee90c: ldur            d0, [x0, #0x3b]
    // 0x12ee910: stur            d0, [fp, #-0x38]
    // 0x12ee914: LoadField: d1 = r0->field_43
    //     0x12ee914: ldur            d1, [x0, #0x43]
    // 0x12ee918: stur            d1, [fp, #-0x30]
    // 0x12ee91c: r0 = Radius()
    //     0x12ee91c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee920: ldur            d0, [fp, #-0x38]
    // 0x12ee924: stur            x0, [fp, #-0x18]
    // 0x12ee928: StoreField: r0->field_7 = d0
    //     0x12ee928: stur            d0, [x0, #7]
    // 0x12ee92c: ldur            d0, [fp, #-0x30]
    // 0x12ee930: StoreField: r0->field_f = d0
    //     0x12ee930: stur            d0, [x0, #0xf]
    // 0x12ee934: r0 = Radius()
    //     0x12ee934: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee938: ldur            d0, [fp, #-0x58]
    // 0x12ee93c: StoreField: r0->field_7 = d0
    //     0x12ee93c: stur            d0, [x0, #7]
    // 0x12ee940: ldur            d1, [fp, #-0x68]
    // 0x12ee944: StoreField: r0->field_f = d1
    //     0x12ee944: stur            d1, [x0, #0xf]
    // 0x12ee948: ldur            x1, [fp, #-0x18]
    // 0x12ee94c: mov             x2, x0
    // 0x12ee950: r0 = -()
    //     0x12ee950: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12ee954: r16 = Instance_Radius
    //     0x12ee954: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee958: ldr             x16, [x16, #0x1a0]
    // 0x12ee95c: str             x16, [SP]
    // 0x12ee960: mov             x1, x0
    // 0x12ee964: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee964: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee968: ldr             x4, [x4, #0x678]
    // 0x12ee96c: r0 = clamp()
    //     0x12ee96c: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee970: mov             x1, x0
    // 0x12ee974: ldur            x0, [fp, #-8]
    // 0x12ee978: stur            x1, [fp, #-0x18]
    // 0x12ee97c: LoadField: d0 = r0->field_4b
    //     0x12ee97c: ldur            d0, [x0, #0x4b]
    // 0x12ee980: stur            d0, [fp, #-0x38]
    // 0x12ee984: LoadField: d1 = r0->field_53
    //     0x12ee984: ldur            d1, [x0, #0x53]
    // 0x12ee988: stur            d1, [fp, #-0x30]
    // 0x12ee98c: r0 = Radius()
    //     0x12ee98c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee990: ldur            d0, [fp, #-0x38]
    // 0x12ee994: stur            x0, [fp, #-0x20]
    // 0x12ee998: StoreField: r0->field_7 = d0
    //     0x12ee998: stur            d0, [x0, #7]
    // 0x12ee99c: ldur            d0, [fp, #-0x30]
    // 0x12ee9a0: StoreField: r0->field_f = d0
    //     0x12ee9a0: stur            d0, [x0, #0xf]
    // 0x12ee9a4: r0 = Radius()
    //     0x12ee9a4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ee9a8: ldur            d0, [fp, #-0x58]
    // 0x12ee9ac: StoreField: r0->field_7 = d0
    //     0x12ee9ac: stur            d0, [x0, #7]
    // 0x12ee9b0: ldur            d0, [fp, #-0x48]
    // 0x12ee9b4: StoreField: r0->field_f = d0
    //     0x12ee9b4: stur            d0, [x0, #0xf]
    // 0x12ee9b8: ldur            x1, [fp, #-0x20]
    // 0x12ee9bc: mov             x2, x0
    // 0x12ee9c0: r0 = -()
    //     0x12ee9c0: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12ee9c4: r16 = Instance_Radius
    //     0x12ee9c4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12ee9c8: ldr             x16, [x16, #0x1a0]
    // 0x12ee9cc: str             x16, [SP]
    // 0x12ee9d0: mov             x1, x0
    // 0x12ee9d4: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12ee9d4: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12ee9d8: ldr             x4, [x4, #0x678]
    // 0x12ee9dc: r0 = clamp()
    //     0x12ee9dc: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12ee9e0: mov             x1, x0
    // 0x12ee9e4: ldur            x0, [fp, #-8]
    // 0x12ee9e8: stur            x1, [fp, #-0x20]
    // 0x12ee9ec: LoadField: d0 = r0->field_5b
    //     0x12ee9ec: ldur            d0, [x0, #0x5b]
    // 0x12ee9f0: stur            d0, [fp, #-0x38]
    // 0x12ee9f4: LoadField: d1 = r0->field_63
    //     0x12ee9f4: ldur            d1, [x0, #0x63]
    // 0x12ee9f8: stur            d1, [fp, #-0x30]
    // 0x12ee9fc: r0 = Radius()
    //     0x12ee9fc: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12eea00: ldur            d0, [fp, #-0x38]
    // 0x12eea04: stur            x0, [fp, #-8]
    // 0x12eea08: StoreField: r0->field_7 = d0
    //     0x12eea08: stur            d0, [x0, #7]
    // 0x12eea0c: ldur            d0, [fp, #-0x30]
    // 0x12eea10: StoreField: r0->field_f = d0
    //     0x12eea10: stur            d0, [x0, #0xf]
    // 0x12eea14: r0 = Radius()
    //     0x12eea14: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12eea18: ldur            d0, [fp, #-0x78]
    // 0x12eea1c: StoreField: r0->field_7 = d0
    //     0x12eea1c: stur            d0, [x0, #7]
    // 0x12eea20: ldur            d0, [fp, #-0x48]
    // 0x12eea24: StoreField: r0->field_f = d0
    //     0x12eea24: stur            d0, [x0, #0xf]
    // 0x12eea28: ldur            x1, [fp, #-8]
    // 0x12eea2c: mov             x2, x0
    // 0x12eea30: r0 = -()
    //     0x12eea30: bl              #0x8a504c  ; [dart:ui] Radius::-
    // 0x12eea34: r16 = Instance_Radius
    //     0x12eea34: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0x12eea38: ldr             x16, [x16, #0x1a0]
    // 0x12eea3c: str             x16, [SP]
    // 0x12eea40: mov             x1, x0
    // 0x12eea44: r4 = const [0, 0x2, 0x1, 0x1, minimum, 0x1, null]
    //     0x12eea44: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a678] List(7) [0, 0x2, 0x1, 0x1, "minimum", 0x1, Null]
    //     0x12eea48: ldr             x4, [x4, #0x678]
    // 0x12eea4c: r0 = clamp()
    //     0x12eea4c: bl              #0xb77b88  ; [dart:ui] Radius::clamp
    // 0x12eea50: r1 = <RRect>
    //     0x12eea50: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12eea54: ldr             x1, [x1, #0x108]
    // 0x12eea58: stur            x0, [fp, #-8]
    // 0x12eea5c: r0 = RRect()
    //     0x12eea5c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12eea60: stur            x0, [fp, #-0x28]
    // 0x12eea64: ldur            x16, [fp, #-0x10]
    // 0x12eea68: ldur            lr, [fp, #-0x18]
    // 0x12eea6c: stp             lr, x16, [SP, #0x10]
    // 0x12eea70: ldur            x16, [fp, #-0x20]
    // 0x12eea74: ldur            lr, [fp, #-8]
    // 0x12eea78: stp             lr, x16, [SP]
    // 0x12eea7c: mov             x1, x0
    // 0x12eea80: ldur            d0, [fp, #-0x70]
    // 0x12eea84: ldur            d1, [fp, #-0x60]
    // 0x12eea88: ldur            d2, [fp, #-0x50]
    // 0x12eea8c: ldur            d3, [fp, #-0x40]
    // 0x12eea90: r4 = const [0, 0x9, 0x4, 0x5, bottomLeft, 0x8, bottomRight, 0x7, topLeft, 0x5, topRight, 0x6, null]
    //     0x12eea90: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0da0] List(13) [0, 0x9, 0x4, 0x5, "bottomLeft", 0x8, "bottomRight", 0x7, "topLeft", 0x5, "topRight", 0x6, Null]
    //     0x12eea94: ldr             x4, [x4, #0xda0]
    // 0x12eea98: r0 = RRect.fromLTRBAndCorners()
    //     0x12eea98: bl              #0xc24690  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0x12eea9c: ldur            x0, [fp, #-0x28]
    // 0x12eeaa0: LeaveFrame
    //     0x12eeaa0: mov             SP, fp
    //     0x12eeaa4: ldp             fp, lr, [SP], #0x10
    // 0x12eeaa8: ret
    //     0x12eeaa8: ret             
    // 0x12eeaac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eeaac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eeab0: b               #0x12ee84c
  }
  EdgeInsets /(EdgeInsets, double) {
    // ** addr: 0x12f7e58, size: 0x70
    // 0x12f7e58: EnterFrame
    //     0x12f7e58: stp             fp, lr, [SP, #-0x10]!
    //     0x12f7e5c: mov             fp, SP
    // 0x12f7e60: AllocStack(0x20)
    //     0x12f7e60: sub             SP, SP, #0x20
    // 0x12f7e64: d1 = 2.000000
    //     0x12f7e64: fmov            d1, #2.00000000
    // 0x12f7e68: LoadField: d0 = r1->field_7
    //     0x12f7e68: ldur            d0, [x1, #7]
    // 0x12f7e6c: fdiv            d2, d0, d1
    // 0x12f7e70: stur            d2, [fp, #-0x20]
    // 0x12f7e74: LoadField: d0 = r1->field_f
    //     0x12f7e74: ldur            d0, [x1, #0xf]
    // 0x12f7e78: fdiv            d3, d0, d1
    // 0x12f7e7c: stur            d3, [fp, #-0x18]
    // 0x12f7e80: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x12f7e80: ldur            d0, [x1, #0x17]
    // 0x12f7e84: fdiv            d4, d0, d1
    // 0x12f7e88: stur            d4, [fp, #-0x10]
    // 0x12f7e8c: LoadField: d0 = r1->field_1f
    //     0x12f7e8c: ldur            d0, [x1, #0x1f]
    // 0x12f7e90: fdiv            d5, d0, d1
    // 0x12f7e94: stur            d5, [fp, #-8]
    // 0x12f7e98: r0 = EdgeInsets()
    //     0x12f7e98: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x12f7e9c: ldur            d0, [fp, #-0x20]
    // 0x12f7ea0: StoreField: r0->field_7 = d0
    //     0x12f7ea0: stur            d0, [x0, #7]
    // 0x12f7ea4: ldur            d0, [fp, #-0x18]
    // 0x12f7ea8: StoreField: r0->field_f = d0
    //     0x12f7ea8: stur            d0, [x0, #0xf]
    // 0x12f7eac: ldur            d0, [fp, #-0x10]
    // 0x12f7eb0: ArrayStore: r0[0] = d0  ; List_8
    //     0x12f7eb0: stur            d0, [x0, #0x17]
    // 0x12f7eb4: ldur            d0, [fp, #-8]
    // 0x12f7eb8: StoreField: r0->field_1f = d0
    //     0x12f7eb8: stur            d0, [x0, #0x1f]
    // 0x12f7ebc: LeaveFrame
    //     0x12f7ebc: mov             SP, fp
    //     0x12f7ec0: ldp             fp, lr, [SP], #0x10
    // 0x12f7ec4: ret
    //     0x12f7ec4: ret             
  }
  EdgeInsets *(EdgeInsets, double) {
    // ** addr: 0x1300e58, size: 0x6c
    // 0x1300e58: EnterFrame
    //     0x1300e58: stp             fp, lr, [SP, #-0x10]!
    //     0x1300e5c: mov             fp, SP
    // 0x1300e60: AllocStack(0x20)
    //     0x1300e60: sub             SP, SP, #0x20
    // 0x1300e64: LoadField: d1 = r1->field_7
    //     0x1300e64: ldur            d1, [x1, #7]
    // 0x1300e68: fmul            d2, d1, d0
    // 0x1300e6c: stur            d2, [fp, #-0x20]
    // 0x1300e70: LoadField: d1 = r1->field_f
    //     0x1300e70: ldur            d1, [x1, #0xf]
    // 0x1300e74: fmul            d3, d1, d0
    // 0x1300e78: stur            d3, [fp, #-0x18]
    // 0x1300e7c: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x1300e7c: ldur            d1, [x1, #0x17]
    // 0x1300e80: fmul            d4, d1, d0
    // 0x1300e84: stur            d4, [fp, #-0x10]
    // 0x1300e88: LoadField: d1 = r1->field_1f
    //     0x1300e88: ldur            d1, [x1, #0x1f]
    // 0x1300e8c: fmul            d5, d1, d0
    // 0x1300e90: stur            d5, [fp, #-8]
    // 0x1300e94: r0 = EdgeInsets()
    //     0x1300e94: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1300e98: ldur            d0, [fp, #-0x20]
    // 0x1300e9c: StoreField: r0->field_7 = d0
    //     0x1300e9c: stur            d0, [x0, #7]
    // 0x1300ea0: ldur            d0, [fp, #-0x18]
    // 0x1300ea4: StoreField: r0->field_f = d0
    //     0x1300ea4: stur            d0, [x0, #0xf]
    // 0x1300ea8: ldur            d0, [fp, #-0x10]
    // 0x1300eac: ArrayStore: r0[0] = d0  ; List_8
    //     0x1300eac: stur            d0, [x0, #0x17]
    // 0x1300eb0: ldur            d0, [fp, #-8]
    // 0x1300eb4: StoreField: r0->field_1f = d0
    //     0x1300eb4: stur            d0, [x0, #0x1f]
    // 0x1300eb8: LeaveFrame
    //     0x1300eb8: mov             SP, fp
    //     0x1300ebc: ldp             fp, lr, [SP], #0x10
    // 0x1300ec0: ret
    //     0x1300ec0: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0x1300ff4, size: 0x138
    // 0x1300ff4: EnterFrame
    //     0x1300ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x1300ff8: mov             fp, SP
    // 0x1300ffc: AllocStack(0x20)
    //     0x1300ffc: sub             SP, SP, #0x20
    // 0x1301000: r2 = Instance_EdgeInsets
    //     0x1301000: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1301004: r0 = Instance__MixedEdgeInsets
    //     0x1301004: add             x0, PP, #0x9a, lsl #12  ; [pp+0x9a790] Obj!_MixedEdgeInsets@129c7d1
    //     0x1301008: ldr             x0, [x0, #0x790]
    // 0x130100c: LoadField: d0 = r1->field_7
    //     0x130100c: ldur            d0, [x1, #7]
    // 0x1301010: LoadField: d1 = r2->field_7
    //     0x1301010: ldur            d1, [x2, #7]
    // 0x1301014: LoadField: d2 = r0->field_7
    //     0x1301014: ldur            d2, [x0, #7]
    // 0x1301018: fcmp            d1, d0
    // 0x130101c: b.le            #0x1301028
    // 0x1301020: mov             v0.16b, v1.16b
    // 0x1301024: b               #0x1301044
    // 0x1301028: fcmp            d0, d2
    // 0x130102c: b.le            #0x1301038
    // 0x1301030: mov             v0.16b, v2.16b
    // 0x1301034: b               #0x1301044
    // 0x1301038: fcmp            d0, d0
    // 0x130103c: b.vc            #0x1301044
    // 0x1301040: mov             v0.16b, v2.16b
    // 0x1301044: stur            d0, [fp, #-0x20]
    // 0x1301048: LoadField: d1 = r1->field_f
    //     0x1301048: ldur            d1, [x1, #0xf]
    // 0x130104c: LoadField: d2 = r2->field_f
    //     0x130104c: ldur            d2, [x2, #0xf]
    // 0x1301050: LoadField: d3 = r0->field_27
    //     0x1301050: ldur            d3, [x0, #0x27]
    // 0x1301054: fcmp            d2, d1
    // 0x1301058: b.le            #0x1301064
    // 0x130105c: mov             v1.16b, v2.16b
    // 0x1301060: b               #0x1301080
    // 0x1301064: fcmp            d1, d3
    // 0x1301068: b.le            #0x1301074
    // 0x130106c: mov             v1.16b, v3.16b
    // 0x1301070: b               #0x1301080
    // 0x1301074: fcmp            d1, d1
    // 0x1301078: b.vc            #0x1301080
    // 0x130107c: mov             v1.16b, v3.16b
    // 0x1301080: stur            d1, [fp, #-0x18]
    // 0x1301084: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x1301084: ldur            d2, [x1, #0x17]
    // 0x1301088: ArrayLoad: d3 = r2[0]  ; List_8
    //     0x1301088: ldur            d3, [x2, #0x17]
    // 0x130108c: LoadField: d4 = r0->field_f
    //     0x130108c: ldur            d4, [x0, #0xf]
    // 0x1301090: fcmp            d3, d2
    // 0x1301094: b.le            #0x13010a0
    // 0x1301098: mov             v2.16b, v3.16b
    // 0x130109c: b               #0x13010bc
    // 0x13010a0: fcmp            d2, d4
    // 0x13010a4: b.le            #0x13010b0
    // 0x13010a8: mov             v2.16b, v4.16b
    // 0x13010ac: b               #0x13010bc
    // 0x13010b0: fcmp            d2, d2
    // 0x13010b4: b.vc            #0x13010bc
    // 0x13010b8: mov             v2.16b, v4.16b
    // 0x13010bc: stur            d2, [fp, #-0x10]
    // 0x13010c0: LoadField: d3 = r1->field_1f
    //     0x13010c0: ldur            d3, [x1, #0x1f]
    // 0x13010c4: LoadField: d4 = r2->field_1f
    //     0x13010c4: ldur            d4, [x2, #0x1f]
    // 0x13010c8: LoadField: d5 = r0->field_2f
    //     0x13010c8: ldur            d5, [x0, #0x2f]
    // 0x13010cc: fcmp            d4, d3
    // 0x13010d0: b.le            #0x13010dc
    // 0x13010d4: mov             v3.16b, v4.16b
    // 0x13010d8: b               #0x13010f8
    // 0x13010dc: fcmp            d3, d5
    // 0x13010e0: b.le            #0x13010ec
    // 0x13010e4: mov             v3.16b, v5.16b
    // 0x13010e8: b               #0x13010f8
    // 0x13010ec: fcmp            d3, d3
    // 0x13010f0: b.vc            #0x13010f8
    // 0x13010f4: mov             v3.16b, v5.16b
    // 0x13010f8: stur            d3, [fp, #-8]
    // 0x13010fc: r0 = EdgeInsets()
    //     0x13010fc: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1301100: ldur            d0, [fp, #-0x20]
    // 0x1301104: StoreField: r0->field_7 = d0
    //     0x1301104: stur            d0, [x0, #7]
    // 0x1301108: ldur            d0, [fp, #-0x18]
    // 0x130110c: StoreField: r0->field_f = d0
    //     0x130110c: stur            d0, [x0, #0xf]
    // 0x1301110: ldur            d0, [fp, #-0x10]
    // 0x1301114: ArrayStore: r0[0] = d0  ; List_8
    //     0x1301114: stur            d0, [x0, #0x17]
    // 0x1301118: ldur            d0, [fp, #-8]
    // 0x130111c: StoreField: r0->field_1f = d0
    //     0x130111c: stur            d0, [x0, #0x1f]
    // 0x1301120: LeaveFrame
    //     0x1301120: mov             SP, fp
    //     0x1301124: ldp             fp, lr, [SP], #0x10
    // 0x1301128: ret
    //     0x1301128: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0x13013c0, size: 0x4c
    // 0x13013c0: EnterFrame
    //     0x13013c0: stp             fp, lr, [SP, #-0x10]!
    //     0x13013c4: mov             fp, SP
    // 0x13013c8: CheckStackOverflow
    //     0x13013c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13013cc: cmp             SP, x16
    //     0x13013d0: b.ls            #0x1301404
    // 0x13013d4: r0 = LoadClassIdInstr(r2)
    //     0x13013d4: ldur            x0, [x2, #-1]
    //     0x13013d8: ubfx            x0, x0, #0xc, #0x14
    // 0x13013dc: cmp             x0, #0xb7c
    // 0x13013e0: b.ne            #0x13013f4
    // 0x13013e4: r0 = +()
    //     0x13013e4: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x13013e8: LeaveFrame
    //     0x13013e8: mov             SP, fp
    //     0x13013ec: ldp             fp, lr, [SP], #0x10
    // 0x13013f0: ret
    //     0x13013f0: ret             
    // 0x13013f4: r0 = add()
    //     0x13013f4: bl              #0x1301438  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0x13013f8: LeaveFrame
    //     0x13013f8: mov             SP, fp
    //     0x13013fc: ldp             fp, lr, [SP], #0x10
    // 0x1301400: ret
    //     0x1301400: ret             
    // 0x1301404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1301404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1301408: b               #0x13013d4
  }
}
