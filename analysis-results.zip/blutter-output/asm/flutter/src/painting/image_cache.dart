// lib: , url: package:flutter/src/painting/image_cache.dart

// class id: 1048997, size: 0x8
class :: {
}

// class id: 2925, size: 0x10, field offset: 0x8
class _PendingImage extends Object {

  _ removeListener(/* No info */) {
    // ** addr: 0x87c4ac, size: 0x100
    // 0x87c4ac: EnterFrame
    //     0x87c4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x87c4b0: mov             fp, SP
    // 0x87c4b4: AllocStack(0x8)
    //     0x87c4b4: sub             SP, SP, #8
    // 0x87c4b8: CheckStackOverflow
    //     0x87c4b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c4bc: cmp             SP, x16
    //     0x87c4c0: b.ls            #0x87c5a4
    // 0x87c4c4: LoadField: r0 = r1->field_7
    //     0x87c4c4: ldur            w0, [x1, #7]
    // 0x87c4c8: DecompressPointer r0
    //     0x87c4c8: add             x0, x0, HEAP, lsl #32
    // 0x87c4cc: stur            x0, [fp, #-8]
    // 0x87c4d0: LoadField: r2 = r1->field_b
    //     0x87c4d0: ldur            w2, [x1, #0xb]
    // 0x87c4d4: DecompressPointer r2
    //     0x87c4d4: add             x2, x2, HEAP, lsl #32
    // 0x87c4d8: r1 = LoadClassIdInstr(r0)
    //     0x87c4d8: ldur            x1, [x0, #-1]
    //     0x87c4dc: ubfx            x1, x1, #0xc, #0x14
    // 0x87c4e0: r17 = 5244
    //     0x87c4e0: mov             x17, #0x147c
    // 0x87c4e4: cmp             x1, x17
    // 0x87c4e8: b.ne            #0x87c528
    // 0x87c4ec: mov             x1, x0
    // 0x87c4f0: r0 = removeListener()
    //     0x87c4f0: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x87c4f4: ldur            x0, [fp, #-8]
    // 0x87c4f8: LoadField: r1 = r0->field_7
    //     0x87c4f8: ldur            w1, [x0, #7]
    // 0x87c4fc: DecompressPointer r1
    //     0x87c4fc: add             x1, x1, HEAP, lsl #32
    // 0x87c500: LoadField: r2 = r1->field_b
    //     0x87c500: ldur            w2, [x1, #0xb]
    // 0x87c504: cbnz            w2, #0x87c594
    // 0x87c508: LoadField: r1 = r0->field_57
    //     0x87c508: ldur            w1, [x0, #0x57]
    // 0x87c50c: DecompressPointer r1
    //     0x87c50c: add             x1, x1, HEAP, lsl #32
    // 0x87c510: cmp             w1, NULL
    // 0x87c514: b.eq            #0x87c520
    // 0x87c518: r0 = cancel()
    //     0x87c518: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x87c51c: ldur            x0, [fp, #-8]
    // 0x87c520: StoreField: r0->field_57 = rNULL
    //     0x87c520: stur            NULL, [x0, #0x57]
    // 0x87c524: b               #0x87c594
    // 0x87c528: r17 = 5247
    //     0x87c528: mov             x17, #0x147f
    // 0x87c52c: cmp             x1, x17
    // 0x87c530: b.ne            #0x87c57c
    // 0x87c534: mov             x1, x0
    // 0x87c538: r0 = removeListener()
    //     0x87c538: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x87c53c: ldur            x0, [fp, #-8]
    // 0x87c540: LoadField: r1 = r0->field_7
    //     0x87c540: ldur            w1, [x0, #7]
    // 0x87c544: DecompressPointer r1
    //     0x87c544: add             x1, x1, HEAP, lsl #32
    // 0x87c548: LoadField: r2 = r1->field_b
    //     0x87c548: ldur            w2, [x1, #0xb]
    // 0x87c54c: cbnz            w2, #0x87c594
    // 0x87c550: LoadField: r1 = r0->field_57
    //     0x87c550: ldur            w1, [x0, #0x57]
    // 0x87c554: DecompressPointer r1
    //     0x87c554: add             x1, x1, HEAP, lsl #32
    // 0x87c558: cmp             w1, NULL
    // 0x87c55c: b.ne            #0x87c568
    // 0x87c560: mov             x1, x0
    // 0x87c564: b               #0x87c570
    // 0x87c568: r0 = cancel()
    //     0x87c568: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x87c56c: ldur            x1, [fp, #-8]
    // 0x87c570: StoreField: r1->field_57 = rNULL
    //     0x87c570: stur            NULL, [x1, #0x57]
    // 0x87c574: r0 = __maybeDispose()
    //     0x87c574: bl              #0x87c6d8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::__maybeDispose
    // 0x87c578: b               #0x87c594
    // 0x87c57c: mov             x1, x0
    // 0x87c580: r0 = LoadClassIdInstr(r1)
    //     0x87c580: ldur            x0, [x1, #-1]
    //     0x87c584: ubfx            x0, x0, #0xc, #0x14
    // 0x87c588: r0 = GDT[cid_x0 + 0x949]()
    //     0x87c588: add             lr, x0, #0x949
    //     0x87c58c: ldr             lr, [x21, lr, lsl #3]
    //     0x87c590: blr             lr
    // 0x87c594: r0 = Null
    //     0x87c594: mov             x0, NULL
    // 0x87c598: LeaveFrame
    //     0x87c598: mov             SP, fp
    //     0x87c59c: ldp             fp, lr, [SP], #0x10
    // 0x87c5a0: ret
    //     0x87c5a0: ret             
    // 0x87c5a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c5a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c5a8: b               #0x87c4c4
  }
}

// class id: 2926, size: 0x14, field offset: 0x8
abstract class _CachedImageBase extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x87c5ac, size: 0x12c
    // 0x87c5ac: EnterFrame
    //     0x87c5ac: stp             fp, lr, [SP, #-0x10]!
    //     0x87c5b0: mov             fp, SP
    // 0x87c5b4: AllocStack(0x18)
    //     0x87c5b4: sub             SP, SP, #0x18
    // 0x87c5b8: SetupParameters(_CachedImageBase this /* r1 => r1, fp-0x8 */)
    //     0x87c5b8: stur            x1, [fp, #-8]
    // 0x87c5bc: CheckStackOverflow
    //     0x87c5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c5c0: cmp             SP, x16
    //     0x87c5c4: b.ls            #0x87c6cc
    // 0x87c5c8: r1 = 1
    //     0x87c5c8: mov             x1, #1
    // 0x87c5cc: r0 = AllocateContext()
    //     0x87c5cc: bl              #0x13de838  ; AllocateContextStub
    // 0x87c5d0: mov             x1, x0
    // 0x87c5d4: ldur            x0, [fp, #-8]
    // 0x87c5d8: StoreField: r1->field_f = r0
    //     0x87c5d8: stur            w0, [x1, #0xf]
    // 0x87c5dc: r0 = LoadStaticField(0x5e4)
    //     0x87c5dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c5e0: ldr             x0, [x0, #0xbc8]
    // 0x87c5e4: cmp             w0, NULL
    // 0x87c5e8: b.eq            #0x87c6d4
    // 0x87c5ec: LoadField: r3 = r0->field_53
    //     0x87c5ec: ldur            w3, [x0, #0x53]
    // 0x87c5f0: DecompressPointer r3
    //     0x87c5f0: add             x3, x3, HEAP, lsl #32
    // 0x87c5f4: stur            x3, [fp, #-0x10]
    // 0x87c5f8: LoadField: r0 = r3->field_7
    //     0x87c5f8: ldur            w0, [x3, #7]
    // 0x87c5fc: DecompressPointer r0
    //     0x87c5fc: add             x0, x0, HEAP, lsl #32
    // 0x87c600: mov             x2, x1
    // 0x87c604: stur            x0, [fp, #-8]
    // 0x87c608: r1 = Function '<anonymous closure>':.
    //     0x87c608: ldr             x1, [PP, #0x3338]  ; [pp+0x3338] AnonymousClosure: (0x87c7c0), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x87c5ac)
    // 0x87c60c: r0 = AllocateClosure()
    //     0x87c60c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87c610: ldur            x2, [fp, #-8]
    // 0x87c614: mov             x3, x0
    // 0x87c618: r1 = Null
    //     0x87c618: mov             x1, NULL
    // 0x87c61c: stur            x3, [fp, #-8]
    // 0x87c620: cmp             w2, NULL
    // 0x87c624: b.eq            #0x87c644
    // 0x87c628: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87c628: ldur            w4, [x2, #0x17]
    // 0x87c62c: DecompressPointer r4
    //     0x87c62c: add             x4, x4, HEAP, lsl #32
    // 0x87c630: r8 = X0
    //     0x87c630: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87c634: LoadField: r9 = r4->field_7
    //     0x87c634: ldur            x9, [x4, #7]
    // 0x87c638: r3 = Null
    //     0x87c638: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d330] Null
    //     0x87c63c: ldr             x3, [x3, #0x330]
    // 0x87c640: blr             x9
    // 0x87c644: ldur            x0, [fp, #-0x10]
    // 0x87c648: LoadField: r1 = r0->field_b
    //     0x87c648: ldur            w1, [x0, #0xb]
    // 0x87c64c: LoadField: r2 = r0->field_f
    //     0x87c64c: ldur            w2, [x0, #0xf]
    // 0x87c650: DecompressPointer r2
    //     0x87c650: add             x2, x2, HEAP, lsl #32
    // 0x87c654: LoadField: r3 = r2->field_b
    //     0x87c654: ldur            w3, [x2, #0xb]
    // 0x87c658: r2 = LoadInt32Instr(r1)
    //     0x87c658: sbfx            x2, x1, #1, #0x1f
    // 0x87c65c: stur            x2, [fp, #-0x18]
    // 0x87c660: r1 = LoadInt32Instr(r3)
    //     0x87c660: sbfx            x1, x3, #1, #0x1f
    // 0x87c664: cmp             x2, x1
    // 0x87c668: b.ne            #0x87c674
    // 0x87c66c: mov             x1, x0
    // 0x87c670: r0 = _growToNextCapacity()
    //     0x87c670: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87c674: ldur            x2, [fp, #-0x10]
    // 0x87c678: ldur            x3, [fp, #-0x18]
    // 0x87c67c: add             x4, x3, #1
    // 0x87c680: lsl             x5, x4, #1
    // 0x87c684: StoreField: r2->field_b = r5
    //     0x87c684: stur            w5, [x2, #0xb]
    // 0x87c688: LoadField: r1 = r2->field_f
    //     0x87c688: ldur            w1, [x2, #0xf]
    // 0x87c68c: DecompressPointer r1
    //     0x87c68c: add             x1, x1, HEAP, lsl #32
    // 0x87c690: ldur            x0, [fp, #-8]
    // 0x87c694: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87c694: add             x25, x1, x3, lsl #2
    //     0x87c698: add             x25, x25, #0xf
    //     0x87c69c: str             w0, [x25]
    //     0x87c6a0: tbz             w0, #0, #0x87c6bc
    //     0x87c6a4: ldurb           w16, [x1, #-1]
    //     0x87c6a8: ldurb           w17, [x0, #-1]
    //     0x87c6ac: and             x16, x17, x16, lsr #2
    //     0x87c6b0: tst             x16, HEAP, lsr #32
    //     0x87c6b4: b.eq            #0x87c6bc
    //     0x87c6b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87c6bc: r0 = Null
    //     0x87c6bc: mov             x0, NULL
    // 0x87c6c0: LeaveFrame
    //     0x87c6c0: mov             SP, fp
    //     0x87c6c4: ldp             fp, lr, [SP], #0x10
    // 0x87c6c8: ret
    //     0x87c6c8: ret             
    // 0x87c6cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c6cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c6d0: b               #0x87c5c8
    // 0x87c6d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87c6d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x87c7c0, size: 0x84
    // 0x87c7c0: EnterFrame
    //     0x87c7c0: stp             fp, lr, [SP, #-0x10]!
    //     0x87c7c4: mov             fp, SP
    // 0x87c7c8: AllocStack(0x8)
    //     0x87c7c8: sub             SP, SP, #8
    // 0x87c7cc: SetupParameters([dynamic _ /* r0 */])
    //     0x87c7cc: ldr             x0, [fp, #0x18]
    //     0x87c7d0: ldur            w2, [x0, #0x17]
    //     0x87c7d4: add             x2, x2, HEAP, lsl #32
    //     0x87c7d8: stur            x2, [fp, #-8]
    // 0x87c7dc: CheckStackOverflow
    //     0x87c7dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c7e0: cmp             SP, x16
    //     0x87c7e4: b.ls            #0x87c83c
    // 0x87c7e8: LoadField: r0 = r2->field_f
    //     0x87c7e8: ldur            w0, [x2, #0xf]
    // 0x87c7ec: DecompressPointer r0
    //     0x87c7ec: add             x0, x0, HEAP, lsl #32
    // 0x87c7f0: LoadField: r1 = r0->field_f
    //     0x87c7f0: ldur            w1, [x0, #0xf]
    // 0x87c7f4: DecompressPointer r1
    //     0x87c7f4: add             x1, x1, HEAP, lsl #32
    // 0x87c7f8: cmp             w1, NULL
    // 0x87c7fc: b.ne            #0x87c808
    // 0x87c800: mov             x1, x2
    // 0x87c804: b               #0x87c820
    // 0x87c808: r0 = LoadClassIdInstr(r1)
    //     0x87c808: ldur            x0, [x1, #-1]
    //     0x87c80c: ubfx            x0, x0, #0xc, #0x14
    // 0x87c810: r0 = GDT[cid_x0 + -0x1000]()
    //     0x87c810: sub             lr, x0, #1, lsl #12
    //     0x87c814: ldr             lr, [x21, lr, lsl #3]
    //     0x87c818: blr             lr
    // 0x87c81c: ldur            x1, [fp, #-8]
    // 0x87c820: LoadField: r2 = r1->field_f
    //     0x87c820: ldur            w2, [x1, #0xf]
    // 0x87c824: DecompressPointer r2
    //     0x87c824: add             x2, x2, HEAP, lsl #32
    // 0x87c828: StoreField: r2->field_f = rNULL
    //     0x87c828: stur            NULL, [x2, #0xf]
    // 0x87c82c: r0 = Null
    //     0x87c82c: mov             x0, NULL
    // 0x87c830: LeaveFrame
    //     0x87c830: mov             SP, fp
    //     0x87c834: ldp             fp, lr, [SP], #0x10
    // 0x87c838: ret
    //     0x87c838: ret             
    // 0x87c83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c83c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c840: b               #0x87c7e8
  }
  _ _CachedImageBase(/* No info */) {
    // ** addr: 0xf300d0, size: 0x150
    // 0xf300d0: EnterFrame
    //     0xf300d0: stp             fp, lr, [SP, #-0x10]!
    //     0xf300d4: mov             fp, SP
    // 0xf300d8: AllocStack(0x18)
    //     0xf300d8: sub             SP, SP, #0x18
    // 0xf300dc: SetupParameters(_CachedImageBase this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, {dynamic sizeBytes = Null /* r1 */})
    //     0xf300dc: mov             x3, x1
    //     0xf300e0: stur            x1, [fp, #-8]
    //     0xf300e4: stur            x2, [fp, #-0x10]
    //     0xf300e8: ldur            w0, [x4, #0x13]
    //     0xf300ec: ldur            w1, [x4, #0x1f]
    //     0xf300f0: add             x1, x1, HEAP, lsl #32
    //     0xf300f4: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d350] "sizeBytes"
    //     0xf300f8: ldr             x16, [x16, #0x350]
    //     0xf300fc: cmp             w1, w16
    //     0xf30100: b.ne            #0xf30120
    //     0xf30104: ldur            w1, [x4, #0x23]
    //     0xf30108: add             x1, x1, HEAP, lsl #32
    //     0xf3010c: sub             w4, w0, w1
    //     0xf30110: add             x0, fp, w4, sxtw #2
    //     0xf30114: ldr             x0, [x0, #8]
    //     0xf30118: mov             x1, x0
    //     0xf3011c: b               #0xf30124
    //     0xf30120: mov             x1, NULL
    // 0xf30124: CheckStackOverflow
    //     0xf30124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30128: cmp             SP, x16
    //     0xf3012c: b.ls            #0xf30218
    // 0xf30130: mov             x0, x2
    // 0xf30134: StoreField: r3->field_7 = r0
    //     0xf30134: stur            w0, [x3, #7]
    //     0xf30138: ldurb           w16, [x3, #-1]
    //     0xf3013c: ldurb           w17, [x0, #-1]
    //     0xf30140: and             x16, x17, x16, lsr #2
    //     0xf30144: tst             x16, HEAP, lsr #32
    //     0xf30148: b.eq            #0xf30150
    //     0xf3014c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf30150: mov             x0, x1
    // 0xf30154: StoreField: r3->field_b = r0
    //     0xf30154: stur            w0, [x3, #0xb]
    //     0xf30158: tbz             w0, #0, #0xf30174
    //     0xf3015c: ldurb           w16, [x3, #-1]
    //     0xf30160: ldurb           w17, [x0, #-1]
    //     0xf30164: and             x16, x17, x16, lsr #2
    //     0xf30168: tst             x16, HEAP, lsr #32
    //     0xf3016c: b.eq            #0xf30174
    //     0xf30170: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf30174: r0 = LoadClassIdInstr(r2)
    //     0xf30174: ldur            x0, [x2, #-1]
    //     0xf30178: ubfx            x0, x0, #0xc, #0x14
    // 0xf3017c: r17 = -5244
    //     0xf3017c: mov             x17, #-0x147c
    // 0xf30180: add             x16, x0, x17
    // 0xf30184: cmp             x16, #2
    // 0xf30188: b.hi            #0xf301b8
    // 0xf3018c: mov             x1, x2
    // 0xf30190: r0 = _checkDisposed()
    //     0xf30190: bl              #0xd08b68  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xf30194: r0 = ImageStreamCompleterHandle()
    //     0xf30194: bl              #0xd09ce4  ; AllocateImageStreamCompleterHandleStub -> ImageStreamCompleterHandle (size=0xc)
    // 0xf30198: mov             x1, x0
    // 0xf3019c: ldur            x0, [fp, #-0x10]
    // 0xf301a0: StoreField: r1->field_7 = r0
    //     0xf301a0: stur            w0, [x1, #7]
    // 0xf301a4: LoadField: r2 = r0->field_1f
    //     0xf301a4: ldur            x2, [x0, #0x1f]
    // 0xf301a8: add             x3, x2, #1
    // 0xf301ac: StoreField: r0->field_1f = r3
    //     0xf301ac: stur            x3, [x0, #0x1f]
    // 0xf301b0: mov             x0, x1
    // 0xf301b4: b               #0xf301e8
    // 0xf301b8: mov             x0, x2
    // 0xf301bc: mov             x1, x0
    // 0xf301c0: r0 = keepAlive()
    //     0xf301c0: bl              #0x12490c8  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::keepAlive
    // 0xf301c4: stur            x0, [fp, #-0x18]
    // 0xf301c8: r0 = _MultiImageStreamCompleterHandle()
    //     0xf301c8: bl              #0xd09cd8  ; Allocate_MultiImageStreamCompleterHandleStub -> _MultiImageStreamCompleterHandle (size=0x10)
    // 0xf301cc: ldur            x1, [fp, #-0x10]
    // 0xf301d0: StoreField: r0->field_7 = r1
    //     0xf301d0: stur            w1, [x0, #7]
    // 0xf301d4: ldur            x2, [fp, #-0x18]
    // 0xf301d8: StoreField: r0->field_b = r2
    //     0xf301d8: stur            w2, [x0, #0xb]
    // 0xf301dc: LoadField: r2 = r1->field_6b
    //     0xf301dc: ldur            x2, [x1, #0x6b]
    // 0xf301e0: add             x3, x2, #1
    // 0xf301e4: StoreField: r1->field_6b = r3
    //     0xf301e4: stur            x3, [x1, #0x6b]
    // 0xf301e8: ldur            x1, [fp, #-8]
    // 0xf301ec: StoreField: r1->field_f = r0
    //     0xf301ec: stur            w0, [x1, #0xf]
    //     0xf301f0: ldurb           w16, [x1, #-1]
    //     0xf301f4: ldurb           w17, [x0, #-1]
    //     0xf301f8: and             x16, x17, x16, lsr #2
    //     0xf301fc: tst             x16, HEAP, lsr #32
    //     0xf30200: b.eq            #0xf30208
    //     0xf30204: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf30208: r0 = Null
    //     0xf30208: mov             x0, NULL
    // 0xf3020c: LeaveFrame
    //     0xf3020c: mov             SP, fp
    //     0xf30210: ldp             fp, lr, [SP], #0x10
    // 0xf30214: ret
    //     0xf30214: ret             
    // 0xf30218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3021c: b               #0xf30130
  }
}

// class id: 2927, size: 0x18, field offset: 0x14
class _LiveImage extends _CachedImageBase {

  late (dynamic) => void _handleRemove; // offset: 0x14

  _ dispose(/* No info */) {
    // ** addr: 0xec09dc, size: 0x6c
    // 0xec09dc: EnterFrame
    //     0xec09dc: stp             fp, lr, [SP, #-0x10]!
    //     0xec09e0: mov             fp, SP
    // 0xec09e4: AllocStack(0x8)
    //     0xec09e4: sub             SP, SP, #8
    // 0xec09e8: SetupParameters(_LiveImage this /* r1 => r0, fp-0x8 */)
    //     0xec09e8: mov             x0, x1
    //     0xec09ec: stur            x1, [fp, #-8]
    // 0xec09f0: CheckStackOverflow
    //     0xec09f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xec09f4: cmp             SP, x16
    //     0xec09f8: b.ls            #0xec0a34
    // 0xec09fc: LoadField: r1 = r0->field_7
    //     0xec09fc: ldur            w1, [x0, #7]
    // 0xec0a00: DecompressPointer r1
    //     0xec0a00: add             x1, x1, HEAP, lsl #32
    // 0xec0a04: LoadField: r2 = r0->field_13
    //     0xec0a04: ldur            w2, [x0, #0x13]
    // 0xec0a08: DecompressPointer r2
    //     0xec0a08: add             x2, x2, HEAP, lsl #32
    // 0xec0a0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xec0a10: cmp             w2, w16
    // 0xec0a14: b.eq            #0xec0a3c
    // 0xec0a18: r0 = removeOnLastListenerRemovedCallback()
    //     0xec0a18: bl              #0xec0a48  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeOnLastListenerRemovedCallback
    // 0xec0a1c: ldur            x1, [fp, #-8]
    // 0xec0a20: r0 = dispose()
    //     0xec0a20: bl              #0x87c5ac  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xec0a24: r0 = Null
    //     0xec0a24: mov             x0, NULL
    // 0xec0a28: LeaveFrame
    //     0xec0a28: mov             SP, fp
    //     0xec0a2c: ldp             fp, lr, [SP], #0x10
    // 0xec0a30: ret
    //     0xec0a30: ret             
    // 0xec0a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xec0a34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xec0a38: b               #0xec09fc
    // 0xec0a3c: r9 = _handleRemove
    //     0xec0a3c: add             x9, PP, #0x8d, lsl #12  ; [pp+0x8d370] Field <_LiveImage@173034022._handleRemove@173034022>: late (offset: 0x14)
    //     0xec0a40: ldr             x9, [x9, #0x370]
    // 0xec0a44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xec0a44: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _LiveImage(/* No info */) {
    // ** addr: 0xf3036c, size: 0xb0
    // 0xf3036c: EnterFrame
    //     0xf3036c: stp             fp, lr, [SP, #-0x10]!
    //     0xf30370: mov             fp, SP
    // 0xf30374: AllocStack(0x20)
    //     0xf30374: sub             SP, SP, #0x20
    // 0xf30378: SetupParameters(_LiveImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xf30378: stur            x1, [fp, #-8]
    //     0xf3037c: stur            x2, [fp, #-0x10]
    //     0xf30380: stur            x3, [fp, #-0x18]
    // 0xf30384: CheckStackOverflow
    //     0xf30384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30388: cmp             SP, x16
    //     0xf3038c: b.ls            #0xf30414
    // 0xf30390: r1 = 2
    //     0xf30390: mov             x1, #2
    // 0xf30394: r0 = AllocateContext()
    //     0xf30394: bl              #0x13de838  ; AllocateContextStub
    // 0xf30398: mov             x3, x0
    // 0xf3039c: ldur            x0, [fp, #-8]
    // 0xf303a0: stur            x3, [fp, #-0x20]
    // 0xf303a4: StoreField: r3->field_f = r0
    //     0xf303a4: stur            w0, [x3, #0xf]
    // 0xf303a8: ldur            x1, [fp, #-0x18]
    // 0xf303ac: StoreField: r3->field_13 = r1
    //     0xf303ac: stur            w1, [x3, #0x13]
    // 0xf303b0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf303b4: StoreField: r0->field_13 = r1
    //     0xf303b4: stur            w1, [x0, #0x13]
    // 0xf303b8: mov             x1, x0
    // 0xf303bc: ldur            x2, [fp, #-0x10]
    // 0xf303c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf303c0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf303c4: r0 = _CachedImageBase()
    //     0xf303c4: bl              #0xf300d0  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::_CachedImageBase
    // 0xf303c8: ldur            x2, [fp, #-0x20]
    // 0xf303cc: r1 = Function '<anonymous closure>':.
    //     0xf303cc: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d368] AnonymousClosure: (0xf30520), in [package:flutter/src/painting/image_cache.dart] _LiveImage::_LiveImage (0xf3036c)
    //     0xf303d0: ldr             x1, [x1, #0x368]
    // 0xf303d4: r0 = AllocateClosure()
    //     0xf303d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf303d8: mov             x2, x0
    // 0xf303dc: ldur            x1, [fp, #-8]
    // 0xf303e0: StoreField: r1->field_13 = r0
    //     0xf303e0: stur            w0, [x1, #0x13]
    //     0xf303e4: ldurb           w16, [x1, #-1]
    //     0xf303e8: ldurb           w17, [x0, #-1]
    //     0xf303ec: and             x16, x17, x16, lsr #2
    //     0xf303f0: tst             x16, HEAP, lsr #32
    //     0xf303f4: b.eq            #0xf303fc
    //     0xf303f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf303fc: ldur            x1, [fp, #-0x10]
    // 0xf30400: r0 = addOnLastListenerRemovedCallback()
    //     0xf30400: bl              #0xf3041c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addOnLastListenerRemovedCallback
    // 0xf30404: r0 = Null
    //     0xf30404: mov             x0, NULL
    // 0xf30408: LeaveFrame
    //     0xf30408: mov             SP, fp
    //     0xf3040c: ldp             fp, lr, [SP], #0x10
    // 0xf30410: ret
    //     0xf30410: ret             
    // 0xf30414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30418: b               #0xf30390
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf30520, size: 0x68
    // 0xf30520: EnterFrame
    //     0xf30520: stp             fp, lr, [SP, #-0x10]!
    //     0xf30524: mov             fp, SP
    // 0xf30528: AllocStack(0x10)
    //     0xf30528: sub             SP, SP, #0x10
    // 0xf3052c: SetupParameters([dynamic _ /* r0 */])
    //     0xf3052c: ldr             x0, [fp, #0x10]
    //     0xf30530: ldur            w1, [x0, #0x17]
    //     0xf30534: add             x1, x1, HEAP, lsl #32
    //     0xf30538: stur            x1, [fp, #-8]
    // 0xf3053c: CheckStackOverflow
    //     0xf3053c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30540: cmp             SP, x16
    //     0xf30544: b.ls            #0xf30580
    // 0xf30548: LoadField: r0 = r1->field_13
    //     0xf30548: ldur            w0, [x1, #0x13]
    // 0xf3054c: DecompressPointer r0
    //     0xf3054c: add             x0, x0, HEAP, lsl #32
    // 0xf30550: str             x0, [SP]
    // 0xf30554: ClosureCall
    //     0xf30554: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf30558: ldur            x2, [x0, #0x1f]
    //     0xf3055c: blr             x2
    // 0xf30560: ldur            x0, [fp, #-8]
    // 0xf30564: LoadField: r1 = r0->field_f
    //     0xf30564: ldur            w1, [x0, #0xf]
    // 0xf30568: DecompressPointer r1
    //     0xf30568: add             x1, x1, HEAP, lsl #32
    // 0xf3056c: r0 = dispose()
    //     0xf3056c: bl              #0xec09dc  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::dispose
    // 0xf30570: r0 = Null
    //     0xf30570: mov             x0, NULL
    // 0xf30574: LeaveFrame
    //     0xf30574: mov             SP, fp
    //     0xf30578: ldp             fp, lr, [SP], #0x10
    // 0xf3057c: ret
    //     0xf3057c: ret             
    // 0xf30580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30580: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30584: b               #0xf30548
  }
}

// class id: 2928, size: 0x14, field offset: 0x14
class _CachedImage extends _CachedImageBase {
}

// class id: 2929, size: 0x2c, field offset: 0x8
class ImageCache extends Object {

  _ ImageCache(/* No info */) {
    // ** addr: 0x8455e0, size: 0xd8
    // 0x8455e0: EnterFrame
    //     0x8455e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8455e4: mov             fp, SP
    // 0x8455e8: AllocStack(0x18)
    //     0x8455e8: sub             SP, SP, #0x18
    // 0x8455ec: r2 = 1000
    //     0x8455ec: mov             x2, #0x3e8
    // 0x8455f0: r0 = 104857600
    //     0x8455f0: mov             x0, #0x6400000
    // 0x8455f4: stur            x1, [fp, #-8]
    // 0x8455f8: CheckStackOverflow
    //     0x8455f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8455fc: cmp             SP, x16
    //     0x845600: b.ls            #0x8456b0
    // 0x845604: StoreField: r1->field_13 = r2
    //     0x845604: stur            x2, [x1, #0x13]
    // 0x845608: StoreField: r1->field_1b = r0
    //     0x845608: stur            x0, [x1, #0x1b]
    // 0x84560c: StoreField: r1->field_23 = rZR
    //     0x84560c: stur            xzr, [x1, #0x23]
    // 0x845610: r16 = <Object, _PendingImage>
    //     0x845610: ldr             x16, [PP, #0x3058]  ; [pp+0x3058] TypeArguments: <Object, _PendingImage>
    // 0x845614: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x845618: stp             lr, x16, [SP]
    // 0x84561c: r0 = Map._fromLiteral()
    //     0x84561c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x845620: ldur            x1, [fp, #-8]
    // 0x845624: StoreField: r1->field_7 = r0
    //     0x845624: stur            w0, [x1, #7]
    //     0x845628: ldurb           w16, [x1, #-1]
    //     0x84562c: ldurb           w17, [x0, #-1]
    //     0x845630: and             x16, x17, x16, lsr #2
    //     0x845634: tst             x16, HEAP, lsr #32
    //     0x845638: b.eq            #0x845640
    //     0x84563c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x845640: r16 = <Object, _CachedImage>
    //     0x845640: ldr             x16, [PP, #0x3060]  ; [pp+0x3060] TypeArguments: <Object, _CachedImage>
    // 0x845644: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x845648: stp             lr, x16, [SP]
    // 0x84564c: r0 = Map._fromLiteral()
    //     0x84564c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x845650: ldur            x1, [fp, #-8]
    // 0x845654: StoreField: r1->field_b = r0
    //     0x845654: stur            w0, [x1, #0xb]
    //     0x845658: ldurb           w16, [x1, #-1]
    //     0x84565c: ldurb           w17, [x0, #-1]
    //     0x845660: and             x16, x17, x16, lsr #2
    //     0x845664: tst             x16, HEAP, lsr #32
    //     0x845668: b.eq            #0x845670
    //     0x84566c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x845670: r16 = <Object, _LiveImage>
    //     0x845670: ldr             x16, [PP, #0x3068]  ; [pp+0x3068] TypeArguments: <Object, _LiveImage>
    // 0x845674: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x845678: stp             lr, x16, [SP]
    // 0x84567c: r0 = Map._fromLiteral()
    //     0x84567c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x845680: ldur            x1, [fp, #-8]
    // 0x845684: StoreField: r1->field_f = r0
    //     0x845684: stur            w0, [x1, #0xf]
    //     0x845688: ldurb           w16, [x1, #-1]
    //     0x84568c: ldurb           w17, [x0, #-1]
    //     0x845690: and             x16, x17, x16, lsr #2
    //     0x845694: tst             x16, HEAP, lsr #32
    //     0x845698: b.eq            #0x8456a0
    //     0x84569c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8456a0: r0 = Null
    //     0x8456a0: mov             x0, NULL
    // 0x8456a4: LeaveFrame
    //     0x8456a4: mov             SP, fp
    //     0x8456a8: ldp             fp, lr, [SP], #0x10
    // 0x8456ac: ret
    //     0x8456ac: ret             
    // 0x8456b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8456b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8456b4: b               #0x845604
  }
  bool containsKey(ImageCache, Object) {
    // ** addr: 0x8456d0, size: 0x70
    // 0x8456d0: EnterFrame
    //     0x8456d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8456d4: mov             fp, SP
    // 0x8456d8: CheckStackOverflow
    //     0x8456d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8456dc: cmp             SP, x16
    //     0x8456e0: b.ls            #0x845720
    // 0x8456e4: ldr             x0, [fp, #0x10]
    // 0x8456e8: r2 = Null
    //     0x8456e8: mov             x2, NULL
    // 0x8456ec: r1 = Null
    //     0x8456ec: mov             x1, NULL
    // 0x8456f0: cmp             w0, NULL
    // 0x8456f4: b.ne            #0x845708
    // 0x8456f8: r8 = Object
    //     0x8456f8: ldr             x8, [PP, #0xd0]  ; [pp+0xd0] Type: Object
    // 0x8456fc: r3 = Null
    //     0x8456fc: add             x3, PP, #0x82, lsl #12  ; [pp+0x82900] Null
    //     0x845700: ldr             x3, [x3, #0x900]
    // 0x845704: r0 = Object()
    //     0x845704: bl              #0x13ef428  ; IsType_Object_Stub
    // 0x845708: ldr             x1, [fp, #0x18]
    // 0x84570c: ldr             x2, [fp, #0x10]
    // 0x845710: r0 = containsKey()
    //     0x845710: bl              #0x845728  ; [package:flutter/src/painting/image_cache.dart] ImageCache::containsKey
    // 0x845714: LeaveFrame
    //     0x845714: mov             SP, fp
    //     0x845718: ldp             fp, lr, [SP], #0x10
    // 0x84571c: ret
    //     0x84571c: ret             
    // 0x845720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845724: b               #0x8456e4
  }
  bool containsKey(ImageCache, Object) {
    // ** addr: 0x845728, size: 0xcc
    // 0x845728: EnterFrame
    //     0x845728: stp             fp, lr, [SP, #-0x10]!
    //     0x84572c: mov             fp, SP
    // 0x845730: AllocStack(0x18)
    //     0x845730: sub             SP, SP, #0x18
    // 0x845734: SetupParameters(ImageCache this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x845734: mov             x3, x1
    //     0x845738: mov             x0, x2
    //     0x84573c: stur            x1, [fp, #-0x10]
    //     0x845740: stur            x2, [fp, #-0x18]
    // 0x845744: CheckStackOverflow
    //     0x845744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845748: cmp             SP, x16
    //     0x84574c: b.ls            #0x8457ec
    // 0x845750: LoadField: r4 = r3->field_7
    //     0x845750: ldur            w4, [x3, #7]
    // 0x845754: DecompressPointer r4
    //     0x845754: add             x4, x4, HEAP, lsl #32
    // 0x845758: mov             x1, x4
    // 0x84575c: mov             x2, x0
    // 0x845760: stur            x4, [fp, #-8]
    // 0x845764: r0 = _getValueOrData()
    //     0x845764: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x845768: mov             x1, x0
    // 0x84576c: ldur            x0, [fp, #-8]
    // 0x845770: LoadField: r2 = r0->field_f
    //     0x845770: ldur            w2, [x0, #0xf]
    // 0x845774: DecompressPointer r2
    //     0x845774: add             x2, x2, HEAP, lsl #32
    // 0x845778: cmp             w2, w1
    // 0x84577c: b.eq            #0x845790
    // 0x845780: cmp             w1, NULL
    // 0x845784: b.eq            #0x845790
    // 0x845788: r0 = true
    //     0x845788: add             x0, NULL, #0x20  ; true
    // 0x84578c: b               #0x8457e0
    // 0x845790: ldur            x0, [fp, #-0x10]
    // 0x845794: LoadField: r3 = r0->field_b
    //     0x845794: ldur            w3, [x0, #0xb]
    // 0x845798: DecompressPointer r3
    //     0x845798: add             x3, x3, HEAP, lsl #32
    // 0x84579c: mov             x1, x3
    // 0x8457a0: ldur            x2, [fp, #-0x18]
    // 0x8457a4: stur            x3, [fp, #-8]
    // 0x8457a8: r0 = _getValueOrData()
    //     0x8457a8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8457ac: ldur            x1, [fp, #-8]
    // 0x8457b0: LoadField: r2 = r1->field_f
    //     0x8457b0: ldur            w2, [x1, #0xf]
    // 0x8457b4: DecompressPointer r2
    //     0x8457b4: add             x2, x2, HEAP, lsl #32
    // 0x8457b8: cmp             w2, w0
    // 0x8457bc: b.ne            #0x8457c8
    // 0x8457c0: r1 = Null
    //     0x8457c0: mov             x1, NULL
    // 0x8457c4: b               #0x8457cc
    // 0x8457c8: mov             x1, x0
    // 0x8457cc: cmp             w1, NULL
    // 0x8457d0: r16 = true
    //     0x8457d0: add             x16, NULL, #0x20  ; true
    // 0x8457d4: r17 = false
    //     0x8457d4: add             x17, NULL, #0x30  ; false
    // 0x8457d8: csel            x2, x16, x17, ne
    // 0x8457dc: mov             x0, x2
    // 0x8457e0: LeaveFrame
    //     0x8457e0: mov             SP, fp
    //     0x8457e4: ldp             fp, lr, [SP], #0x10
    // 0x8457e8: ret
    //     0x8457e8: ret             
    // 0x8457ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8457ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8457f0: b               #0x845750
  }
  _ clear(/* No info */) {
    // ** addr: 0x87c138, size: 0x374
    // 0x87c138: EnterFrame
    //     0x87c138: stp             fp, lr, [SP, #-0x10]!
    //     0x87c13c: mov             fp, SP
    // 0x87c140: AllocStack(0x38)
    //     0x87c140: sub             SP, SP, #0x38
    // 0x87c144: SetupParameters(ImageCache this /* r1 => r0, fp-0x10 */)
    //     0x87c144: mov             x0, x1
    //     0x87c148: stur            x1, [fp, #-0x10]
    // 0x87c14c: CheckStackOverflow
    //     0x87c14c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c150: cmp             SP, x16
    //     0x87c154: b.ls            #0x87c490
    // 0x87c158: LoadField: r2 = r0->field_b
    //     0x87c158: ldur            w2, [x0, #0xb]
    // 0x87c15c: DecompressPointer r2
    //     0x87c15c: add             x2, x2, HEAP, lsl #32
    // 0x87c160: stur            x2, [fp, #-8]
    // 0x87c164: r1 = <_CachedImage>
    //     0x87c164: ldr             x1, [PP, #0x3320]  ; [pp+0x3320] TypeArguments: <_CachedImage>
    // 0x87c168: r0 = _CompactValuesIterable()
    //     0x87c168: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x87c16c: mov             x1, x0
    // 0x87c170: ldur            x0, [fp, #-8]
    // 0x87c174: StoreField: r1->field_b = r0
    //     0x87c174: stur            w0, [x1, #0xb]
    // 0x87c178: r0 = iterator()
    //     0x87c178: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x87c17c: stur            x0, [fp, #-0x20]
    // 0x87c180: LoadField: r2 = r0->field_7
    //     0x87c180: ldur            w2, [x0, #7]
    // 0x87c184: DecompressPointer r2
    //     0x87c184: add             x2, x2, HEAP, lsl #32
    // 0x87c188: stur            x2, [fp, #-0x18]
    // 0x87c18c: CheckStackOverflow
    //     0x87c18c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c190: cmp             SP, x16
    //     0x87c194: b.ls            #0x87c498
    // 0x87c198: mov             x1, x0
    // 0x87c19c: r0 = moveNext()
    //     0x87c19c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87c1a0: tbnz            w0, #4, #0x87c2e8
    // 0x87c1a4: ldur            x3, [fp, #-0x20]
    // 0x87c1a8: LoadField: r4 = r3->field_33
    //     0x87c1a8: ldur            w4, [x3, #0x33]
    // 0x87c1ac: DecompressPointer r4
    //     0x87c1ac: add             x4, x4, HEAP, lsl #32
    // 0x87c1b0: stur            x4, [fp, #-0x28]
    // 0x87c1b4: cmp             w4, NULL
    // 0x87c1b8: b.ne            #0x87c1e8
    // 0x87c1bc: mov             x0, x4
    // 0x87c1c0: ldur            x2, [fp, #-0x18]
    // 0x87c1c4: r1 = Null
    //     0x87c1c4: mov             x1, NULL
    // 0x87c1c8: cmp             w2, NULL
    // 0x87c1cc: b.eq            #0x87c1e8
    // 0x87c1d0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87c1d0: ldur            w4, [x2, #0x17]
    // 0x87c1d4: DecompressPointer r4
    //     0x87c1d4: add             x4, x4, HEAP, lsl #32
    // 0x87c1d8: r8 = X0
    //     0x87c1d8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87c1dc: LoadField: r9 = r4->field_7
    //     0x87c1dc: ldur            x9, [x4, #7]
    // 0x87c1e0: r3 = Null
    //     0x87c1e0: ldr             x3, [PP, #0x3328]  ; [pp+0x3328] Null
    // 0x87c1e4: blr             x9
    // 0x87c1e8: ldur            x0, [fp, #-0x28]
    // 0x87c1ec: r1 = 1
    //     0x87c1ec: mov             x1, #1
    // 0x87c1f0: r0 = AllocateContext()
    //     0x87c1f0: bl              #0x13de838  ; AllocateContextStub
    // 0x87c1f4: mov             x1, x0
    // 0x87c1f8: ldur            x0, [fp, #-0x28]
    // 0x87c1fc: StoreField: r1->field_f = r0
    //     0x87c1fc: stur            w0, [x1, #0xf]
    // 0x87c200: r0 = LoadStaticField(0x5e4)
    //     0x87c200: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c204: ldr             x0, [x0, #0xbc8]
    // 0x87c208: cmp             w0, NULL
    // 0x87c20c: b.eq            #0x87c4a0
    // 0x87c210: LoadField: r3 = r0->field_53
    //     0x87c210: ldur            w3, [x0, #0x53]
    // 0x87c214: DecompressPointer r3
    //     0x87c214: add             x3, x3, HEAP, lsl #32
    // 0x87c218: stur            x3, [fp, #-0x30]
    // 0x87c21c: LoadField: r0 = r3->field_7
    //     0x87c21c: ldur            w0, [x3, #7]
    // 0x87c220: DecompressPointer r0
    //     0x87c220: add             x0, x0, HEAP, lsl #32
    // 0x87c224: mov             x2, x1
    // 0x87c228: stur            x0, [fp, #-0x28]
    // 0x87c22c: r1 = Function '<anonymous closure>':.
    //     0x87c22c: ldr             x1, [PP, #0x3338]  ; [pp+0x3338] AnonymousClosure: (0x87c7c0), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x87c5ac)
    // 0x87c230: r0 = AllocateClosure()
    //     0x87c230: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87c234: ldur            x2, [fp, #-0x28]
    // 0x87c238: mov             x3, x0
    // 0x87c23c: r1 = Null
    //     0x87c23c: mov             x1, NULL
    // 0x87c240: stur            x3, [fp, #-0x28]
    // 0x87c244: cmp             w2, NULL
    // 0x87c248: b.eq            #0x87c264
    // 0x87c24c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87c24c: ldur            w4, [x2, #0x17]
    // 0x87c250: DecompressPointer r4
    //     0x87c250: add             x4, x4, HEAP, lsl #32
    // 0x87c254: r8 = X0
    //     0x87c254: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87c258: LoadField: r9 = r4->field_7
    //     0x87c258: ldur            x9, [x4, #7]
    // 0x87c25c: r3 = Null
    //     0x87c25c: ldr             x3, [PP, #0x3340]  ; [pp+0x3340] Null
    // 0x87c260: blr             x9
    // 0x87c264: ldur            x0, [fp, #-0x30]
    // 0x87c268: LoadField: r1 = r0->field_b
    //     0x87c268: ldur            w1, [x0, #0xb]
    // 0x87c26c: LoadField: r2 = r0->field_f
    //     0x87c26c: ldur            w2, [x0, #0xf]
    // 0x87c270: DecompressPointer r2
    //     0x87c270: add             x2, x2, HEAP, lsl #32
    // 0x87c274: LoadField: r3 = r2->field_b
    //     0x87c274: ldur            w3, [x2, #0xb]
    // 0x87c278: r2 = LoadInt32Instr(r1)
    //     0x87c278: sbfx            x2, x1, #1, #0x1f
    // 0x87c27c: stur            x2, [fp, #-0x38]
    // 0x87c280: r1 = LoadInt32Instr(r3)
    //     0x87c280: sbfx            x1, x3, #1, #0x1f
    // 0x87c284: cmp             x2, x1
    // 0x87c288: b.ne            #0x87c294
    // 0x87c28c: mov             x1, x0
    // 0x87c290: r0 = _growToNextCapacity()
    //     0x87c290: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87c294: ldur            x0, [fp, #-0x30]
    // 0x87c298: ldur            x2, [fp, #-0x38]
    // 0x87c29c: add             x1, x2, #1
    // 0x87c2a0: lsl             x3, x1, #1
    // 0x87c2a4: StoreField: r0->field_b = r3
    //     0x87c2a4: stur            w3, [x0, #0xb]
    // 0x87c2a8: LoadField: r1 = r0->field_f
    //     0x87c2a8: ldur            w1, [x0, #0xf]
    // 0x87c2ac: DecompressPointer r1
    //     0x87c2ac: add             x1, x1, HEAP, lsl #32
    // 0x87c2b0: ldur            x0, [fp, #-0x28]
    // 0x87c2b4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87c2b4: add             x25, x1, x2, lsl #2
    //     0x87c2b8: add             x25, x25, #0xf
    //     0x87c2bc: str             w0, [x25]
    //     0x87c2c0: tbz             w0, #0, #0x87c2dc
    //     0x87c2c4: ldurb           w16, [x1, #-1]
    //     0x87c2c8: ldurb           w17, [x0, #-1]
    //     0x87c2cc: and             x16, x17, x16, lsr #2
    //     0x87c2d0: tst             x16, HEAP, lsr #32
    //     0x87c2d4: b.eq            #0x87c2dc
    //     0x87c2d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87c2dc: ldur            x0, [fp, #-0x20]
    // 0x87c2e0: ldur            x2, [fp, #-0x18]
    // 0x87c2e4: b               #0x87c18c
    // 0x87c2e8: ldur            x0, [fp, #-0x10]
    // 0x87c2ec: ldur            x1, [fp, #-8]
    // 0x87c2f0: r0 = clear()
    //     0x87c2f0: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87c2f4: ldur            x0, [fp, #-0x10]
    // 0x87c2f8: LoadField: r2 = r0->field_7
    //     0x87c2f8: ldur            w2, [x0, #7]
    // 0x87c2fc: DecompressPointer r2
    //     0x87c2fc: add             x2, x2, HEAP, lsl #32
    // 0x87c300: stur            x2, [fp, #-8]
    // 0x87c304: r1 = <_PendingImage>
    //     0x87c304: ldr             x1, [PP, #0x3350]  ; [pp+0x3350] TypeArguments: <_PendingImage>
    // 0x87c308: r0 = _CompactValuesIterable()
    //     0x87c308: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x87c30c: mov             x1, x0
    // 0x87c310: ldur            x0, [fp, #-8]
    // 0x87c314: StoreField: r1->field_b = r0
    //     0x87c314: stur            w0, [x1, #0xb]
    // 0x87c318: r0 = iterator()
    //     0x87c318: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x87c31c: stur            x0, [fp, #-0x20]
    // 0x87c320: LoadField: r2 = r0->field_7
    //     0x87c320: ldur            w2, [x0, #7]
    // 0x87c324: DecompressPointer r2
    //     0x87c324: add             x2, x2, HEAP, lsl #32
    // 0x87c328: stur            x2, [fp, #-0x18]
    // 0x87c32c: CheckStackOverflow
    //     0x87c32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c330: cmp             SP, x16
    //     0x87c334: b.ls            #0x87c4a4
    // 0x87c338: mov             x1, x0
    // 0x87c33c: r0 = moveNext()
    //     0x87c33c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87c340: tbnz            w0, #4, #0x87c46c
    // 0x87c344: ldur            x3, [fp, #-0x20]
    // 0x87c348: LoadField: r4 = r3->field_33
    //     0x87c348: ldur            w4, [x3, #0x33]
    // 0x87c34c: DecompressPointer r4
    //     0x87c34c: add             x4, x4, HEAP, lsl #32
    // 0x87c350: stur            x4, [fp, #-0x28]
    // 0x87c354: cmp             w4, NULL
    // 0x87c358: b.ne            #0x87c388
    // 0x87c35c: mov             x0, x4
    // 0x87c360: ldur            x2, [fp, #-0x18]
    // 0x87c364: r1 = Null
    //     0x87c364: mov             x1, NULL
    // 0x87c368: cmp             w2, NULL
    // 0x87c36c: b.eq            #0x87c388
    // 0x87c370: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87c370: ldur            w4, [x2, #0x17]
    // 0x87c374: DecompressPointer r4
    //     0x87c374: add             x4, x4, HEAP, lsl #32
    // 0x87c378: r8 = X0
    //     0x87c378: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87c37c: LoadField: r9 = r4->field_7
    //     0x87c37c: ldur            x9, [x4, #7]
    // 0x87c380: r3 = Null
    //     0x87c380: ldr             x3, [PP, #0x3358]  ; [pp+0x3358] Null
    // 0x87c384: blr             x9
    // 0x87c388: ldur            x0, [fp, #-0x28]
    // 0x87c38c: LoadField: r3 = r0->field_7
    //     0x87c38c: ldur            w3, [x0, #7]
    // 0x87c390: DecompressPointer r3
    //     0x87c390: add             x3, x3, HEAP, lsl #32
    // 0x87c394: stur            x3, [fp, #-0x30]
    // 0x87c398: LoadField: r2 = r0->field_b
    //     0x87c398: ldur            w2, [x0, #0xb]
    // 0x87c39c: DecompressPointer r2
    //     0x87c39c: add             x2, x2, HEAP, lsl #32
    // 0x87c3a0: r0 = LoadClassIdInstr(r3)
    //     0x87c3a0: ldur            x0, [x3, #-1]
    //     0x87c3a4: ubfx            x0, x0, #0xc, #0x14
    // 0x87c3a8: r17 = 5244
    //     0x87c3a8: mov             x17, #0x147c
    // 0x87c3ac: cmp             x0, x17
    // 0x87c3b0: b.ne            #0x87c3f4
    // 0x87c3b4: mov             x1, x3
    // 0x87c3b8: r0 = removeListener()
    //     0x87c3b8: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x87c3bc: ldur            x1, [fp, #-0x30]
    // 0x87c3c0: r0 = isNotEmpty()
    //     0x87c3c0: bl              #0x86bfbc  ; [package:flutter/src/widgets/page_storage.dart] _StorageEntryIdentifier::isNotEmpty
    // 0x87c3c4: tbz             w0, #4, #0x87c460
    // 0x87c3c8: ldur            x0, [fp, #-0x30]
    // 0x87c3cc: LoadField: r1 = r0->field_57
    //     0x87c3cc: ldur            w1, [x0, #0x57]
    // 0x87c3d0: DecompressPointer r1
    //     0x87c3d0: add             x1, x1, HEAP, lsl #32
    // 0x87c3d4: cmp             w1, NULL
    // 0x87c3d8: b.ne            #0x87c3e4
    // 0x87c3dc: mov             x3, x0
    // 0x87c3e0: b               #0x87c3ec
    // 0x87c3e4: r0 = cancel()
    //     0x87c3e4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x87c3e8: ldur            x3, [fp, #-0x30]
    // 0x87c3ec: StoreField: r3->field_57 = rNULL
    //     0x87c3ec: stur            NULL, [x3, #0x57]
    // 0x87c3f0: b               #0x87c460
    // 0x87c3f4: r17 = 5247
    //     0x87c3f4: mov             x17, #0x147f
    // 0x87c3f8: cmp             x0, x17
    // 0x87c3fc: b.ne            #0x87c448
    // 0x87c400: mov             x1, x3
    // 0x87c404: r0 = removeListener()
    //     0x87c404: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x87c408: ldur            x0, [fp, #-0x30]
    // 0x87c40c: LoadField: r1 = r0->field_7
    //     0x87c40c: ldur            w1, [x0, #7]
    // 0x87c410: DecompressPointer r1
    //     0x87c410: add             x1, x1, HEAP, lsl #32
    // 0x87c414: LoadField: r2 = r1->field_b
    //     0x87c414: ldur            w2, [x1, #0xb]
    // 0x87c418: cbnz            w2, #0x87c460
    // 0x87c41c: LoadField: r1 = r0->field_57
    //     0x87c41c: ldur            w1, [x0, #0x57]
    // 0x87c420: DecompressPointer r1
    //     0x87c420: add             x1, x1, HEAP, lsl #32
    // 0x87c424: cmp             w1, NULL
    // 0x87c428: b.ne            #0x87c434
    // 0x87c42c: mov             x1, x0
    // 0x87c430: b               #0x87c43c
    // 0x87c434: r0 = cancel()
    //     0x87c434: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x87c438: ldur            x1, [fp, #-0x30]
    // 0x87c43c: StoreField: r1->field_57 = rNULL
    //     0x87c43c: stur            NULL, [x1, #0x57]
    // 0x87c440: r0 = __maybeDispose()
    //     0x87c440: bl              #0x87c6d8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::__maybeDispose
    // 0x87c444: b               #0x87c460
    // 0x87c448: mov             x1, x3
    // 0x87c44c: r0 = LoadClassIdInstr(r1)
    //     0x87c44c: ldur            x0, [x1, #-1]
    //     0x87c450: ubfx            x0, x0, #0xc, #0x14
    // 0x87c454: r0 = GDT[cid_x0 + 0x949]()
    //     0x87c454: add             lr, x0, #0x949
    //     0x87c458: ldr             lr, [x21, lr, lsl #3]
    //     0x87c45c: blr             lr
    // 0x87c460: ldur            x0, [fp, #-0x20]
    // 0x87c464: ldur            x2, [fp, #-0x18]
    // 0x87c468: b               #0x87c32c
    // 0x87c46c: ldur            x0, [fp, #-0x10]
    // 0x87c470: ldur            x1, [fp, #-8]
    // 0x87c474: r0 = clear()
    //     0x87c474: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87c478: ldur            x1, [fp, #-0x10]
    // 0x87c47c: StoreField: r1->field_23 = rZR
    //     0x87c47c: stur            xzr, [x1, #0x23]
    // 0x87c480: r0 = Null
    //     0x87c480: mov             x0, NULL
    // 0x87c484: LeaveFrame
    //     0x87c484: mov             SP, fp
    //     0x87c488: ldp             fp, lr, [SP], #0x10
    // 0x87c48c: ret
    //     0x87c48c: ret             
    // 0x87c490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c494: b               #0x87c158
    // 0x87c498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c49c: b               #0x87c198
    // 0x87c4a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87c4a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87c4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c4a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c4a8: b               #0x87c338
  }
  _ clearLiveImages(/* No info */) {
    // ** addr: 0xec08c0, size: 0x11c
    // 0xec08c0: EnterFrame
    //     0xec08c0: stp             fp, lr, [SP, #-0x10]!
    //     0xec08c4: mov             fp, SP
    // 0xec08c8: AllocStack(0x20)
    //     0xec08c8: sub             SP, SP, #0x20
    // 0xec08cc: CheckStackOverflow
    //     0xec08cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xec08d0: cmp             SP, x16
    //     0xec08d4: b.ls            #0xec09c0
    // 0xec08d8: LoadField: r0 = r1->field_f
    //     0xec08d8: ldur            w0, [x1, #0xf]
    // 0xec08dc: DecompressPointer r0
    //     0xec08dc: add             x0, x0, HEAP, lsl #32
    // 0xec08e0: stur            x0, [fp, #-8]
    // 0xec08e4: r1 = <_LiveImage>
    //     0xec08e4: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0fb8] TypeArguments: <_LiveImage>
    //     0xec08e8: ldr             x1, [x1, #0xfb8]
    // 0xec08ec: r0 = _CompactValuesIterable()
    //     0xec08ec: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xec08f0: mov             x1, x0
    // 0xec08f4: ldur            x0, [fp, #-8]
    // 0xec08f8: StoreField: r1->field_b = r0
    //     0xec08f8: stur            w0, [x1, #0xb]
    // 0xec08fc: r0 = iterator()
    //     0xec08fc: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xec0900: stur            x0, [fp, #-0x18]
    // 0xec0904: LoadField: r2 = r0->field_7
    //     0xec0904: ldur            w2, [x0, #7]
    // 0xec0908: DecompressPointer r2
    //     0xec0908: add             x2, x2, HEAP, lsl #32
    // 0xec090c: stur            x2, [fp, #-0x10]
    // 0xec0910: CheckStackOverflow
    //     0xec0910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xec0914: cmp             SP, x16
    //     0xec0918: b.ls            #0xec09c8
    // 0xec091c: mov             x1, x0
    // 0xec0920: r0 = moveNext()
    //     0xec0920: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xec0924: tbnz            w0, #4, #0xec09a8
    // 0xec0928: ldur            x3, [fp, #-0x18]
    // 0xec092c: LoadField: r4 = r3->field_33
    //     0xec092c: ldur            w4, [x3, #0x33]
    // 0xec0930: DecompressPointer r4
    //     0xec0930: add             x4, x4, HEAP, lsl #32
    // 0xec0934: stur            x4, [fp, #-0x20]
    // 0xec0938: cmp             w4, NULL
    // 0xec093c: b.ne            #0xec0970
    // 0xec0940: mov             x0, x4
    // 0xec0944: ldur            x2, [fp, #-0x10]
    // 0xec0948: r1 = Null
    //     0xec0948: mov             x1, NULL
    // 0xec094c: cmp             w2, NULL
    // 0xec0950: b.eq            #0xec0970
    // 0xec0954: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xec0954: ldur            w4, [x2, #0x17]
    // 0xec0958: DecompressPointer r4
    //     0xec0958: add             x4, x4, HEAP, lsl #32
    // 0xec095c: r8 = X0
    //     0xec095c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xec0960: LoadField: r9 = r4->field_7
    //     0xec0960: ldur            x9, [x4, #7]
    // 0xec0964: r3 = Null
    //     0xec0964: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0fc0] Null
    //     0xec0968: ldr             x3, [x3, #0xfc0]
    // 0xec096c: blr             x9
    // 0xec0970: ldur            x0, [fp, #-0x20]
    // 0xec0974: LoadField: r1 = r0->field_7
    //     0xec0974: ldur            w1, [x0, #7]
    // 0xec0978: DecompressPointer r1
    //     0xec0978: add             x1, x1, HEAP, lsl #32
    // 0xec097c: LoadField: r2 = r0->field_13
    //     0xec097c: ldur            w2, [x0, #0x13]
    // 0xec0980: DecompressPointer r2
    //     0xec0980: add             x2, x2, HEAP, lsl #32
    // 0xec0984: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xec0988: cmp             w2, w16
    // 0xec098c: b.eq            #0xec09d0
    // 0xec0990: r0 = removeOnLastListenerRemovedCallback()
    //     0xec0990: bl              #0xec0a48  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeOnLastListenerRemovedCallback
    // 0xec0994: ldur            x1, [fp, #-0x20]
    // 0xec0998: r0 = dispose()
    //     0xec0998: bl              #0x87c5ac  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xec099c: ldur            x0, [fp, #-0x18]
    // 0xec09a0: ldur            x2, [fp, #-0x10]
    // 0xec09a4: b               #0xec0910
    // 0xec09a8: ldur            x1, [fp, #-8]
    // 0xec09ac: r0 = clear()
    //     0xec09ac: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xec09b0: r0 = Null
    //     0xec09b0: mov             x0, NULL
    // 0xec09b4: LeaveFrame
    //     0xec09b4: mov             SP, fp
    //     0xec09b8: ldp             fp, lr, [SP], #0x10
    // 0xec09bc: ret
    //     0xec09bc: ret             
    // 0xec09c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xec09c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xec09c4: b               #0xec08d8
    // 0xec09c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xec09c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xec09cc: b               #0xec091c
    // 0xec09d0: r9 = _handleRemove
    //     0xec09d0: add             x9, PP, #0x8d, lsl #12  ; [pp+0x8d370] Field <_LiveImage@173034022._handleRemove@173034022>: late (offset: 0x14)
    //     0xec09d4: ldr             x9, [x9, #0x370]
    // 0xec09d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xec09d8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ putIfAbsent(/* No info */) {
    // ** addr: 0xf2f9e8, size: 0x3c4
    // 0xf2f9e8: EnterFrame
    //     0xf2f9e8: stp             fp, lr, [SP, #-0x10]!
    //     0xf2f9ec: mov             fp, SP
    // 0xf2f9f0: AllocStack(0x110)
    //     0xf2f9f0: sub             SP, SP, #0x110
    // 0xf2f9f4: SetupParameters(ImageCache this /* r1 => r1, fp-0xc0 */, dynamic _ /* r2 => r2, fp-0xc8 */, dynamic _ /* r3 => r0, fp-0xd0 */, {dynamic onError = Null /* r3, fp-0xb8 */})
    //     0xf2f9f4: mov             x0, x3
    //     0xf2f9f8: stur            x1, [fp, #-0xc0]
    //     0xf2f9fc: stur            x2, [fp, #-0xc8]
    //     0xf2fa00: stur            x3, [fp, #-0xd0]
    //     0xf2fa04: ldur            w3, [x4, #0x13]
    //     0xf2fa08: ldur            w5, [x4, #0x1f]
    //     0xf2fa0c: add             x5, x5, HEAP, lsl #32
    //     0xf2fa10: ldr             x16, [PP, #0x1f0]  ; [pp+0x1f0] "onError"
    //     0xf2fa14: cmp             w5, w16
    //     0xf2fa18: b.ne            #0xf2fa34
    //     0xf2fa1c: ldur            w5, [x4, #0x23]
    //     0xf2fa20: add             x5, x5, HEAP, lsl #32
    //     0xf2fa24: sub             w4, w3, w5
    //     0xf2fa28: add             x3, fp, w4, sxtw #2
    //     0xf2fa2c: ldr             x3, [x3, #8]
    //     0xf2fa30: b               #0xf2fa38
    //     0xf2fa34: mov             x3, NULL
    //     0xf2fa38: stur            x3, [fp, #-0xb8]
    // 0xf2fa3c: CheckStackOverflow
    //     0xf2fa3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf2fa40: cmp             SP, x16
    //     0xf2fa44: b.ls            #0xf2fda4
    // 0xf2fa48: r1 = 6
    //     0xf2fa48: mov             x1, #6
    // 0xf2fa4c: r0 = AllocateContext()
    //     0xf2fa4c: bl              #0x13de838  ; AllocateContextStub
    // 0xf2fa50: mov             x3, x0
    // 0xf2fa54: ldur            x0, [fp, #-0xc0]
    // 0xf2fa58: stur            x3, [fp, #-0xe0]
    // 0xf2fa5c: StoreField: r3->field_f = r0
    //     0xf2fa5c: stur            w0, [x3, #0xf]
    // 0xf2fa60: ldur            x2, [fp, #-0xc8]
    // 0xf2fa64: StoreField: r3->field_13 = r2
    //     0xf2fa64: stur            w2, [x3, #0x13]
    // 0xf2fa68: LoadField: r4 = r0->field_7
    //     0xf2fa68: ldur            w4, [x0, #7]
    // 0xf2fa6c: DecompressPointer r4
    //     0xf2fa6c: add             x4, x4, HEAP, lsl #32
    // 0xf2fa70: mov             x1, x4
    // 0xf2fa74: stur            x4, [fp, #-0xd8]
    // 0xf2fa78: r0 = _getValueOrData()
    //     0xf2fa78: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf2fa7c: ldur            x3, [fp, #-0xd8]
    // 0xf2fa80: LoadField: r1 = r3->field_f
    //     0xf2fa80: ldur            w1, [x3, #0xf]
    // 0xf2fa84: DecompressPointer r1
    //     0xf2fa84: add             x1, x1, HEAP, lsl #32
    // 0xf2fa88: cmp             w1, w0
    // 0xf2fa8c: b.ne            #0xf2fa94
    // 0xf2fa90: r0 = Null
    //     0xf2fa90: mov             x0, NULL
    // 0xf2fa94: cmp             w0, NULL
    // 0xf2fa98: b.ne            #0xf2faa4
    // 0xf2fa9c: r1 = Null
    //     0xf2fa9c: mov             x1, NULL
    // 0xf2faa0: b               #0xf2faac
    // 0xf2faa4: LoadField: r1 = r0->field_7
    //     0xf2faa4: ldur            w1, [x0, #7]
    // 0xf2faa8: DecompressPointer r1
    //     0xf2faa8: add             x1, x1, HEAP, lsl #32
    // 0xf2faac: ldur            x4, [fp, #-0xe0]
    // 0xf2fab0: mov             x0, x1
    // 0xf2fab4: ArrayStore: r4[0] = r0  ; List_4
    //     0xf2fab4: stur            w0, [x4, #0x17]
    //     0xf2fab8: ldurb           w16, [x4, #-1]
    //     0xf2fabc: ldurb           w17, [x0, #-1]
    //     0xf2fac0: and             x16, x17, x16, lsr #2
    //     0xf2fac4: tst             x16, HEAP, lsr #32
    //     0xf2fac8: b.eq            #0xf2fad0
    //     0xf2facc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf2fad0: cmp             w1, NULL
    // 0xf2fad4: b.eq            #0xf2fae8
    // 0xf2fad8: mov             x0, x1
    // 0xf2fadc: LeaveFrame
    //     0xf2fadc: mov             SP, fp
    //     0xf2fae0: ldp             fp, lr, [SP], #0x10
    // 0xf2fae4: ret
    //     0xf2fae4: ret             
    // 0xf2fae8: ldur            x0, [fp, #-0xc0]
    // 0xf2faec: LoadField: r5 = r0->field_b
    //     0xf2faec: ldur            w5, [x0, #0xb]
    // 0xf2faf0: DecompressPointer r5
    //     0xf2faf0: add             x5, x5, HEAP, lsl #32
    // 0xf2faf4: stur            x5, [fp, #-0xc8]
    // 0xf2faf8: LoadField: r2 = r4->field_13
    //     0xf2faf8: ldur            w2, [x4, #0x13]
    // 0xf2fafc: DecompressPointer r2
    //     0xf2fafc: add             x2, x2, HEAP, lsl #32
    // 0xf2fb00: mov             x1, x5
    // 0xf2fb04: r0 = remove()
    //     0xf2fb04: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf2fb08: stur            x0, [fp, #-0xf0]
    // 0xf2fb0c: cmp             w0, NULL
    // 0xf2fb10: b.eq            #0xf2fb68
    // 0xf2fb14: ldur            x4, [fp, #-0xe0]
    // 0xf2fb18: LoadField: r2 = r4->field_13
    //     0xf2fb18: ldur            w2, [x4, #0x13]
    // 0xf2fb1c: DecompressPointer r2
    //     0xf2fb1c: add             x2, x2, HEAP, lsl #32
    // 0xf2fb20: LoadField: r6 = r0->field_7
    //     0xf2fb20: ldur            w6, [x0, #7]
    // 0xf2fb24: DecompressPointer r6
    //     0xf2fb24: add             x6, x6, HEAP, lsl #32
    // 0xf2fb28: stur            x6, [fp, #-0xe8]
    // 0xf2fb2c: LoadField: r5 = r0->field_b
    //     0xf2fb2c: ldur            w5, [x0, #0xb]
    // 0xf2fb30: DecompressPointer r5
    //     0xf2fb30: add             x5, x5, HEAP, lsl #32
    // 0xf2fb34: ldur            x1, [fp, #-0xc0]
    // 0xf2fb38: mov             x3, x6
    // 0xf2fb3c: r0 = _trackLiveImage()
    //     0xf2fb3c: bl              #0xf3022c  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xf2fb40: ldur            x0, [fp, #-0xe0]
    // 0xf2fb44: LoadField: r2 = r0->field_13
    //     0xf2fb44: ldur            w2, [x0, #0x13]
    // 0xf2fb48: DecompressPointer r2
    //     0xf2fb48: add             x2, x2, HEAP, lsl #32
    // 0xf2fb4c: ldur            x1, [fp, #-0xc8]
    // 0xf2fb50: ldur            x3, [fp, #-0xf0]
    // 0xf2fb54: r0 = []=()
    //     0xf2fb54: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xf2fb58: ldur            x0, [fp, #-0xe8]
    // 0xf2fb5c: LeaveFrame
    //     0xf2fb5c: mov             SP, fp
    //     0xf2fb60: ldp             fp, lr, [SP], #0x10
    // 0xf2fb64: ret
    //     0xf2fb64: ret             
    // 0xf2fb68: ldur            x3, [fp, #-0xc0]
    // 0xf2fb6c: ldur            x0, [fp, #-0xe0]
    // 0xf2fb70: LoadField: r4 = r3->field_f
    //     0xf2fb70: ldur            w4, [x3, #0xf]
    // 0xf2fb74: DecompressPointer r4
    //     0xf2fb74: add             x4, x4, HEAP, lsl #32
    // 0xf2fb78: stur            x4, [fp, #-0xc8]
    // 0xf2fb7c: LoadField: r2 = r0->field_13
    //     0xf2fb7c: ldur            w2, [x0, #0x13]
    // 0xf2fb80: DecompressPointer r2
    //     0xf2fb80: add             x2, x2, HEAP, lsl #32
    // 0xf2fb84: mov             x1, x4
    // 0xf2fb88: r0 = _getValueOrData()
    //     0xf2fb88: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf2fb8c: mov             x1, x0
    // 0xf2fb90: ldur            x0, [fp, #-0xc8]
    // 0xf2fb94: LoadField: r2 = r0->field_f
    //     0xf2fb94: ldur            w2, [x0, #0xf]
    // 0xf2fb98: DecompressPointer r2
    //     0xf2fb98: add             x2, x2, HEAP, lsl #32
    // 0xf2fb9c: cmp             w2, w1
    // 0xf2fba0: b.ne            #0xf2fbac
    // 0xf2fba4: r0 = Null
    //     0xf2fba4: mov             x0, NULL
    // 0xf2fba8: b               #0xf2fbb0
    // 0xf2fbac: mov             x0, x1
    // 0xf2fbb0: cmp             w0, NULL
    // 0xf2fbb4: b.eq            #0xf2fc24
    // 0xf2fbb8: ldur            x2, [fp, #-0xe0]
    // 0xf2fbbc: LoadField: r1 = r2->field_13
    //     0xf2fbbc: ldur            w1, [x2, #0x13]
    // 0xf2fbc0: DecompressPointer r1
    //     0xf2fbc0: add             x1, x1, HEAP, lsl #32
    // 0xf2fbc4: stur            x1, [fp, #-0xf0]
    // 0xf2fbc8: LoadField: r2 = r0->field_7
    //     0xf2fbc8: ldur            w2, [x0, #7]
    // 0xf2fbcc: DecompressPointer r2
    //     0xf2fbcc: add             x2, x2, HEAP, lsl #32
    // 0xf2fbd0: stur            x2, [fp, #-0xe8]
    // 0xf2fbd4: LoadField: r3 = r0->field_b
    //     0xf2fbd4: ldur            w3, [x0, #0xb]
    // 0xf2fbd8: DecompressPointer r3
    //     0xf2fbd8: add             x3, x3, HEAP, lsl #32
    // 0xf2fbdc: stur            x3, [fp, #-0xc8]
    // 0xf2fbe0: r0 = _CachedImage()
    //     0xf2fbe0: bl              #0xf30220  ; Allocate_CachedImageStub -> _CachedImage (size=0x14)
    // 0xf2fbe4: stur            x0, [fp, #-0xf8]
    // 0xf2fbe8: ldur            x16, [fp, #-0xc8]
    // 0xf2fbec: str             x16, [SP]
    // 0xf2fbf0: mov             x1, x0
    // 0xf2fbf4: ldur            x2, [fp, #-0xe8]
    // 0xf2fbf8: r4 = const [0, 0x3, 0x1, 0x2, sizeBytes, 0x2, null]
    //     0xf2fbf8: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d318] List(7) [0, 0x3, 0x1, 0x2, "sizeBytes", 0x2, Null]
    //     0xf2fbfc: ldr             x4, [x4, #0x318]
    // 0xf2fc00: r0 = _CachedImageBase()
    //     0xf2fc00: bl              #0xf300d0  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::_CachedImageBase
    // 0xf2fc04: ldur            x1, [fp, #-0xc0]
    // 0xf2fc08: ldur            x2, [fp, #-0xf0]
    // 0xf2fc0c: ldur            x3, [fp, #-0xf8]
    // 0xf2fc10: r0 = _touch()
    //     0xf2fc10: bl              #0xf2fdb8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_touch
    // 0xf2fc14: ldur            x0, [fp, #-0xe8]
    // 0xf2fc18: LeaveFrame
    //     0xf2fc18: mov             SP, fp
    //     0xf2fc1c: ldp             fp, lr, [SP], #0x10
    // 0xf2fc20: ret
    //     0xf2fc20: ret             
    // 0xf2fc24: ldur            x2, [fp, #-0xe0]
    // 0xf2fc28: ldur            x16, [fp, #-0xd0]
    // 0xf2fc2c: str             x16, [SP]
    // 0xf2fc30: ldur            x0, [fp, #-0xd0]
    // 0xf2fc34: ClosureCall
    //     0xf2fc34: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf2fc38: ldur            x2, [x0, #0x1f]
    //     0xf2fc3c: blr             x2
    // 0xf2fc40: mov             x1, x0
    // 0xf2fc44: ldur            x4, [fp, #-0xe0]
    // 0xf2fc48: ArrayStore: r4[0] = r0  ; List_4
    //     0xf2fc48: stur            w0, [x4, #0x17]
    //     0xf2fc4c: tbz             w0, #0, #0xf2fc68
    //     0xf2fc50: ldurb           w16, [x4, #-1]
    //     0xf2fc54: ldurb           w17, [x0, #-1]
    //     0xf2fc58: and             x16, x17, x16, lsr #2
    //     0xf2fc5c: tst             x16, HEAP, lsr #32
    //     0xf2fc60: b.eq            #0xf2fc68
    //     0xf2fc64: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf2fc68: LoadField: r2 = r4->field_13
    //     0xf2fc68: ldur            w2, [x4, #0x13]
    // 0xf2fc6c: DecompressPointer r2
    //     0xf2fc6c: add             x2, x2, HEAP, lsl #32
    // 0xf2fc70: mov             x3, x1
    // 0xf2fc74: ldur            x1, [fp, #-0xc0]
    // 0xf2fc78: r5 = Null
    //     0xf2fc78: mov             x5, NULL
    // 0xf2fc7c: r0 = _trackLiveImage()
    //     0xf2fc7c: bl              #0xf3022c  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xf2fc80: ldur            x0, [fp, #-0xe0]
    // 0xf2fc84: r3 = false
    //     0xf2fc84: add             x3, NULL, #0x30  ; false
    // 0xf2fc88: r2 = true
    //     0xf2fc88: add             x2, NULL, #0x20  ; true
    // 0xf2fc8c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf2fc90: StoreField: r0->field_1b = r3
    //     0xf2fc90: stur            w3, [x0, #0x1b]
    // 0xf2fc94: StoreField: r0->field_1f = r2
    //     0xf2fc94: stur            w2, [x0, #0x1f]
    // 0xf2fc98: StoreField: r0->field_23 = r1
    //     0xf2fc98: stur            w1, [x0, #0x23]
    // 0xf2fc9c: mov             x2, x0
    // 0xf2fca0: r1 = Function 'listener':.
    //     0xf2fca0: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d320] AnonymousClosure: (0xf305f0), in [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent (0xf2f9e8)
    //     0xf2fca4: ldr             x1, [x1, #0x320]
    // 0xf2fca8: r0 = AllocateClosure()
    //     0xf2fca8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf2fcac: stur            x0, [fp, #-0xc0]
    // 0xf2fcb0: r0 = ImageStreamListener()
    //     0xf2fcb0: bl              #0xd097b8  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0xf2fcb4: mov             x1, x0
    // 0xf2fcb8: ldur            x0, [fp, #-0xc0]
    // 0xf2fcbc: stur            x1, [fp, #-0xc8]
    // 0xf2fcc0: StoreField: r1->field_7 = r0
    //     0xf2fcc0: stur            w0, [x1, #7]
    // 0xf2fcc4: ldur            x0, [fp, #-0xe0]
    // 0xf2fcc8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf2fcc8: ldur            w2, [x0, #0x17]
    // 0xf2fccc: DecompressPointer r2
    //     0xf2fccc: add             x2, x2, HEAP, lsl #32
    // 0xf2fcd0: stur            x2, [fp, #-0xc0]
    // 0xf2fcd4: r0 = _PendingImage()
    //     0xf2fcd4: bl              #0xf2fdac  ; Allocate_PendingImageStub -> _PendingImage (size=0x10)
    // 0xf2fcd8: mov             x1, x0
    // 0xf2fcdc: ldur            x0, [fp, #-0xc0]
    // 0xf2fce0: StoreField: r1->field_7 = r0
    //     0xf2fce0: stur            w0, [x1, #7]
    // 0xf2fce4: ldur            x4, [fp, #-0xc8]
    // 0xf2fce8: StoreField: r1->field_b = r4
    //     0xf2fce8: stur            w4, [x1, #0xb]
    // 0xf2fcec: mov             x0, x1
    // 0xf2fcf0: ldur            x5, [fp, #-0xe0]
    // 0xf2fcf4: StoreField: r5->field_23 = r0
    //     0xf2fcf4: stur            w0, [x5, #0x23]
    //     0xf2fcf8: ldurb           w16, [x5, #-1]
    //     0xf2fcfc: ldurb           w17, [x0, #-1]
    //     0xf2fd00: and             x16, x17, x16, lsr #2
    //     0xf2fd04: tst             x16, HEAP, lsr #32
    //     0xf2fd08: b.eq            #0xf2fd10
    //     0xf2fd0c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xf2fd10: LoadField: r2 = r5->field_13
    //     0xf2fd10: ldur            w2, [x5, #0x13]
    // 0xf2fd14: DecompressPointer r2
    //     0xf2fd14: add             x2, x2, HEAP, lsl #32
    // 0xf2fd18: mov             x3, x1
    // 0xf2fd1c: ldur            x1, [fp, #-0xd8]
    // 0xf2fd20: r0 = []=()
    //     0xf2fd20: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xf2fd24: ldur            x3, [fp, #-0xe0]
    // 0xf2fd28: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xf2fd28: ldur            w1, [x3, #0x17]
    // 0xf2fd2c: DecompressPointer r1
    //     0xf2fd2c: add             x1, x1, HEAP, lsl #32
    // 0xf2fd30: r0 = LoadClassIdInstr(r1)
    //     0xf2fd30: ldur            x0, [x1, #-1]
    //     0xf2fd34: ubfx            x0, x0, #0xc, #0x14
    // 0xf2fd38: ldur            x2, [fp, #-0xc8]
    // 0xf2fd3c: r0 = GDT[cid_x0 + 0xe1d]()
    //     0xf2fd3c: add             lr, x0, #0xe1d
    //     0xf2fd40: ldr             lr, [x21, lr, lsl #3]
    //     0xf2fd44: blr             lr
    // 0xf2fd48: ldur            x0, [fp, #-0xe0]
    // 0xf2fd4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf2fd4c: ldur            w1, [x0, #0x17]
    // 0xf2fd50: DecompressPointer r1
    //     0xf2fd50: add             x1, x1, HEAP, lsl #32
    // 0xf2fd54: mov             x0, x1
    // 0xf2fd58: LeaveFrame
    //     0xf2fd58: mov             SP, fp
    //     0xf2fd5c: ldp             fp, lr, [SP], #0x10
    // 0xf2fd60: ret
    //     0xf2fd60: ret             
    // 0xf2fd64: sub             SP, fp, #0x110
    // 0xf2fd68: ldur            x2, [fp, #-0xb8]
    // 0xf2fd6c: cmp             w2, NULL
    // 0xf2fd70: b.eq            #0xf2fd9c
    // 0xf2fd74: stp             x0, x2, [SP, #8]
    // 0xf2fd78: str             x1, [SP]
    // 0xf2fd7c: mov             x0, x2
    // 0xf2fd80: ClosureCall
    //     0xf2fd80: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xf2fd84: ldur            x2, [x0, #0x1f]
    //     0xf2fd88: blr             x2
    // 0xf2fd8c: r0 = Null
    //     0xf2fd8c: mov             x0, NULL
    // 0xf2fd90: LeaveFrame
    //     0xf2fd90: mov             SP, fp
    //     0xf2fd94: ldp             fp, lr, [SP], #0x10
    // 0xf2fd98: ret
    //     0xf2fd98: ret             
    // 0xf2fd9c: r0 = ReThrow()
    //     0xf2fd9c: bl              #0x13ddb00  ; ReThrowStub
    // 0xf2fda0: brk             #0
    // 0xf2fda4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf2fda4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf2fda8: b               #0xf2fa48
  }
  _ _touch(/* No info */) {
    // ** addr: 0xf2fdb8, size: 0x8c
    // 0xf2fdb8: EnterFrame
    //     0xf2fdb8: stp             fp, lr, [SP, #-0x10]!
    //     0xf2fdbc: mov             fp, SP
    // 0xf2fdc0: AllocStack(0x8)
    //     0xf2fdc0: sub             SP, SP, #8
    // 0xf2fdc4: SetupParameters(ImageCache this /* r1 => r0, fp-0x8 */)
    //     0xf2fdc4: mov             x0, x1
    //     0xf2fdc8: stur            x1, [fp, #-8]
    // 0xf2fdcc: CheckStackOverflow
    //     0xf2fdcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf2fdd0: cmp             SP, x16
    //     0xf2fdd4: b.ls            #0xf2fe3c
    // 0xf2fdd8: LoadField: r1 = r3->field_b
    //     0xf2fdd8: ldur            w1, [x3, #0xb]
    // 0xf2fddc: DecompressPointer r1
    //     0xf2fddc: add             x1, x1, HEAP, lsl #32
    // 0xf2fde0: cmp             w1, NULL
    // 0xf2fde4: b.eq            #0xf2fe24
    // 0xf2fde8: r4 = LoadInt32Instr(r1)
    //     0xf2fde8: sbfx            x4, x1, #1, #0x1f
    //     0xf2fdec: tbz             w1, #0, #0xf2fdf4
    //     0xf2fdf0: ldur            x4, [x1, #7]
    // 0xf2fdf4: r17 = 104857600
    //     0xf2fdf4: mov             x17, #0x6400000
    // 0xf2fdf8: cmp             x4, x17
    // 0xf2fdfc: b.gt            #0xf2fe24
    // 0xf2fe00: LoadField: r1 = r0->field_23
    //     0xf2fe00: ldur            x1, [x0, #0x23]
    // 0xf2fe04: add             x5, x1, x4
    // 0xf2fe08: StoreField: r0->field_23 = r5
    //     0xf2fe08: stur            x5, [x0, #0x23]
    // 0xf2fe0c: LoadField: r1 = r0->field_b
    //     0xf2fe0c: ldur            w1, [x0, #0xb]
    // 0xf2fe10: DecompressPointer r1
    //     0xf2fe10: add             x1, x1, HEAP, lsl #32
    // 0xf2fe14: r0 = []=()
    //     0xf2fe14: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xf2fe18: ldur            x1, [fp, #-8]
    // 0xf2fe1c: r0 = _checkCacheSize()
    //     0xf2fe1c: bl              #0xf2fe44  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_checkCacheSize
    // 0xf2fe20: b               #0xf2fe2c
    // 0xf2fe24: mov             x1, x3
    // 0xf2fe28: r0 = dispose()
    //     0xf2fe28: bl              #0x87c5ac  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xf2fe2c: r0 = Null
    //     0xf2fe2c: mov             x0, NULL
    // 0xf2fe30: LeaveFrame
    //     0xf2fe30: mov             SP, fp
    //     0xf2fe34: ldp             fp, lr, [SP], #0x10
    // 0xf2fe38: ret
    //     0xf2fe38: ret             
    // 0xf2fe3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf2fe3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf2fe40: b               #0xf2fdd8
  }
  _ _checkCacheSize(/* No info */) {
    // ** addr: 0xf2fe44, size: 0x28c
    // 0xf2fe44: EnterFrame
    //     0xf2fe44: stp             fp, lr, [SP, #-0x10]!
    //     0xf2fe48: mov             fp, SP
    // 0xf2fe4c: AllocStack(0x40)
    //     0xf2fe4c: sub             SP, SP, #0x40
    // 0xf2fe50: SetupParameters(ImageCache this /* r1 => r1, fp-0x8 */)
    //     0xf2fe50: stur            x1, [fp, #-8]
    // 0xf2fe54: CheckStackOverflow
    //     0xf2fe54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf2fe58: cmp             SP, x16
    //     0xf2fe5c: b.ls            #0xf300b4
    // 0xf2fe60: r16 = <String, dynamic>
    //     0xf2fe60: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xf2fe64: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xf2fe68: stp             lr, x16, [SP]
    // 0xf2fe6c: r0 = Map._fromLiteral()
    //     0xf2fe6c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf2fe70: ldur            x0, [fp, #-8]
    // 0xf2fe74: LoadField: r2 = r0->field_b
    //     0xf2fe74: ldur            w2, [x0, #0xb]
    // 0xf2fe78: DecompressPointer r2
    //     0xf2fe78: add             x2, x2, HEAP, lsl #32
    // 0xf2fe7c: stur            x2, [fp, #-0x10]
    // 0xf2fe80: CheckStackOverflow
    //     0xf2fe80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf2fe84: cmp             SP, x16
    //     0xf2fe88: b.ls            #0xf300bc
    // 0xf2fe8c: LoadField: r1 = r0->field_23
    //     0xf2fe8c: ldur            x1, [x0, #0x23]
    // 0xf2fe90: r17 = 104857600
    //     0xf2fe90: mov             x17, #0x6400000
    // 0xf2fe94: cmp             x1, x17
    // 0xf2fe98: b.gt            #0xf2febc
    // 0xf2fe9c: LoadField: r1 = r2->field_13
    //     0xf2fe9c: ldur            w1, [x2, #0x13]
    // 0xf2fea0: r3 = LoadInt32Instr(r1)
    //     0xf2fea0: sbfx            x3, x1, #1, #0x1f
    // 0xf2fea4: asr             x1, x3, #1
    // 0xf2fea8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xf2fea8: ldur            w3, [x2, #0x17]
    // 0xf2feac: r4 = LoadInt32Instr(r3)
    //     0xf2feac: sbfx            x4, x3, #1, #0x1f
    // 0xf2feb0: sub             x3, x1, x4
    // 0xf2feb4: cmp             x3, #0x3e8
    // 0xf2feb8: b.le            #0xf30098
    // 0xf2febc: r1 = <Object, _CachedImage>
    //     0xf2febc: ldr             x1, [PP, #0x3060]  ; [pp+0x3060] TypeArguments: <Object, _CachedImage>
    // 0xf2fec0: r0 = _CompactKeysIterable()
    //     0xf2fec0: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xf2fec4: mov             x1, x0
    // 0xf2fec8: ldur            x0, [fp, #-0x10]
    // 0xf2fecc: StoreField: r1->field_b = r0
    //     0xf2fecc: stur            w0, [x1, #0xb]
    // 0xf2fed0: r0 = iterator()
    //     0xf2fed0: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xf2fed4: mov             x2, x0
    // 0xf2fed8: stur            x2, [fp, #-0x18]
    // 0xf2fedc: r0 = LoadClassIdInstr(r2)
    //     0xf2fedc: ldur            x0, [x2, #-1]
    //     0xf2fee0: ubfx            x0, x0, #0xc, #0x14
    // 0xf2fee4: mov             x1, x2
    // 0xf2fee8: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xf2fee8: mov             x17, #0x845b
    //     0xf2feec: movk            x17, #1, lsl #16
    //     0xf2fef0: add             lr, x0, x17
    //     0xf2fef4: ldr             lr, [x21, lr, lsl #3]
    //     0xf2fef8: blr             lr
    // 0xf2fefc: tbnz            w0, #4, #0xf300a8
    // 0xf2ff00: ldur            x2, [fp, #-0x10]
    // 0xf2ff04: ldur            x1, [fp, #-0x18]
    // 0xf2ff08: r0 = LoadClassIdInstr(r1)
    //     0xf2ff08: ldur            x0, [x1, #-1]
    //     0xf2ff0c: ubfx            x0, x0, #0xc, #0x14
    // 0xf2ff10: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xf2ff10: mov             x17, #0x7d4c
    //     0xf2ff14: movk            x17, #1, lsl #16
    //     0xf2ff18: add             lr, x0, x17
    //     0xf2ff1c: ldr             lr, [x21, lr, lsl #3]
    //     0xf2ff20: blr             lr
    // 0xf2ff24: ldur            x1, [fp, #-0x10]
    // 0xf2ff28: mov             x2, x0
    // 0xf2ff2c: stur            x0, [fp, #-0x18]
    // 0xf2ff30: r0 = _getValueOrData()
    //     0xf2ff30: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf2ff34: ldur            x1, [fp, #-0x10]
    // 0xf2ff38: LoadField: r2 = r1->field_f
    //     0xf2ff38: ldur            w2, [x1, #0xf]
    // 0xf2ff3c: DecompressPointer r2
    //     0xf2ff3c: add             x2, x2, HEAP, lsl #32
    // 0xf2ff40: cmp             w2, w0
    // 0xf2ff44: b.ne            #0xf2ff50
    // 0xf2ff48: r2 = Null
    //     0xf2ff48: mov             x2, NULL
    // 0xf2ff4c: b               #0xf2ff54
    // 0xf2ff50: mov             x2, x0
    // 0xf2ff54: ldur            x0, [fp, #-8]
    // 0xf2ff58: stur            x2, [fp, #-0x20]
    // 0xf2ff5c: cmp             w2, NULL
    // 0xf2ff60: b.eq            #0xf300c4
    // 0xf2ff64: LoadField: r3 = r0->field_23
    //     0xf2ff64: ldur            x3, [x0, #0x23]
    // 0xf2ff68: LoadField: r4 = r2->field_b
    //     0xf2ff68: ldur            w4, [x2, #0xb]
    // 0xf2ff6c: DecompressPointer r4
    //     0xf2ff6c: add             x4, x4, HEAP, lsl #32
    // 0xf2ff70: cmp             w4, NULL
    // 0xf2ff74: b.eq            #0xf300c8
    // 0xf2ff78: r5 = LoadInt32Instr(r4)
    //     0xf2ff78: sbfx            x5, x4, #1, #0x1f
    //     0xf2ff7c: tbz             w4, #0, #0xf2ff84
    //     0xf2ff80: ldur            x5, [x4, #7]
    // 0xf2ff84: sub             x4, x3, x5
    // 0xf2ff88: StoreField: r0->field_23 = r4
    //     0xf2ff88: stur            x4, [x0, #0x23]
    // 0xf2ff8c: r1 = 1
    //     0xf2ff8c: mov             x1, #1
    // 0xf2ff90: r0 = AllocateContext()
    //     0xf2ff90: bl              #0x13de838  ; AllocateContextStub
    // 0xf2ff94: mov             x1, x0
    // 0xf2ff98: ldur            x0, [fp, #-0x20]
    // 0xf2ff9c: StoreField: r1->field_f = r0
    //     0xf2ff9c: stur            w0, [x1, #0xf]
    // 0xf2ffa0: r0 = LoadStaticField(0x5e4)
    //     0xf2ffa0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf2ffa4: ldr             x0, [x0, #0xbc8]
    // 0xf2ffa8: cmp             w0, NULL
    // 0xf2ffac: b.eq            #0xf300cc
    // 0xf2ffb0: LoadField: r3 = r0->field_53
    //     0xf2ffb0: ldur            w3, [x0, #0x53]
    // 0xf2ffb4: DecompressPointer r3
    //     0xf2ffb4: add             x3, x3, HEAP, lsl #32
    // 0xf2ffb8: stur            x3, [fp, #-0x28]
    // 0xf2ffbc: LoadField: r0 = r3->field_7
    //     0xf2ffbc: ldur            w0, [x3, #7]
    // 0xf2ffc0: DecompressPointer r0
    //     0xf2ffc0: add             x0, x0, HEAP, lsl #32
    // 0xf2ffc4: mov             x2, x1
    // 0xf2ffc8: stur            x0, [fp, #-0x20]
    // 0xf2ffcc: r1 = Function '<anonymous closure>':.
    //     0xf2ffcc: ldr             x1, [PP, #0x3338]  ; [pp+0x3338] AnonymousClosure: (0x87c7c0), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x87c5ac)
    // 0xf2ffd0: r0 = AllocateClosure()
    //     0xf2ffd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf2ffd4: ldur            x2, [fp, #-0x20]
    // 0xf2ffd8: mov             x3, x0
    // 0xf2ffdc: r1 = Null
    //     0xf2ffdc: mov             x1, NULL
    // 0xf2ffe0: stur            x3, [fp, #-0x20]
    // 0xf2ffe4: cmp             w2, NULL
    // 0xf2ffe8: b.eq            #0xf30008
    // 0xf2ffec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf2ffec: ldur            w4, [x2, #0x17]
    // 0xf2fff0: DecompressPointer r4
    //     0xf2fff0: add             x4, x4, HEAP, lsl #32
    // 0xf2fff4: r8 = X0
    //     0xf2fff4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf2fff8: LoadField: r9 = r4->field_7
    //     0xf2fff8: ldur            x9, [x4, #7]
    // 0xf2fffc: r3 = Null
    //     0xf2fffc: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d340] Null
    //     0xf30000: ldr             x3, [x3, #0x340]
    // 0xf30004: blr             x9
    // 0xf30008: ldur            x0, [fp, #-0x28]
    // 0xf3000c: LoadField: r1 = r0->field_b
    //     0xf3000c: ldur            w1, [x0, #0xb]
    // 0xf30010: LoadField: r2 = r0->field_f
    //     0xf30010: ldur            w2, [x0, #0xf]
    // 0xf30014: DecompressPointer r2
    //     0xf30014: add             x2, x2, HEAP, lsl #32
    // 0xf30018: LoadField: r3 = r2->field_b
    //     0xf30018: ldur            w3, [x2, #0xb]
    // 0xf3001c: r2 = LoadInt32Instr(r1)
    //     0xf3001c: sbfx            x2, x1, #1, #0x1f
    // 0xf30020: stur            x2, [fp, #-0x30]
    // 0xf30024: r1 = LoadInt32Instr(r3)
    //     0xf30024: sbfx            x1, x3, #1, #0x1f
    // 0xf30028: cmp             x2, x1
    // 0xf3002c: b.ne            #0xf30038
    // 0xf30030: mov             x1, x0
    // 0xf30034: r0 = _growToNextCapacity()
    //     0xf30034: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf30038: ldur            x0, [fp, #-0x28]
    // 0xf3003c: ldur            x2, [fp, #-0x30]
    // 0xf30040: add             x1, x2, #1
    // 0xf30044: lsl             x3, x1, #1
    // 0xf30048: StoreField: r0->field_b = r3
    //     0xf30048: stur            w3, [x0, #0xb]
    // 0xf3004c: LoadField: r1 = r0->field_f
    //     0xf3004c: ldur            w1, [x0, #0xf]
    // 0xf30050: DecompressPointer r1
    //     0xf30050: add             x1, x1, HEAP, lsl #32
    // 0xf30054: ldur            x0, [fp, #-0x20]
    // 0xf30058: ArrayStore: r1[r2] = r0  ; List_4
    //     0xf30058: add             x25, x1, x2, lsl #2
    //     0xf3005c: add             x25, x25, #0xf
    //     0xf30060: str             w0, [x25]
    //     0xf30064: tbz             w0, #0, #0xf30080
    //     0xf30068: ldurb           w16, [x1, #-1]
    //     0xf3006c: ldurb           w17, [x0, #-1]
    //     0xf30070: and             x16, x17, x16, lsr #2
    //     0xf30074: tst             x16, HEAP, lsr #32
    //     0xf30078: b.eq            #0xf30080
    //     0xf3007c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf30080: ldur            x1, [fp, #-0x10]
    // 0xf30084: ldur            x2, [fp, #-0x18]
    // 0xf30088: r0 = remove()
    //     0xf30088: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf3008c: ldur            x0, [fp, #-8]
    // 0xf30090: ldur            x2, [fp, #-0x10]
    // 0xf30094: b               #0xf2fe80
    // 0xf30098: r0 = Null
    //     0xf30098: mov             x0, NULL
    // 0xf3009c: LeaveFrame
    //     0xf3009c: mov             SP, fp
    //     0xf300a0: ldp             fp, lr, [SP], #0x10
    // 0xf300a4: ret
    //     0xf300a4: ret             
    // 0xf300a8: r0 = noElement()
    //     0xf300a8: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xf300ac: r0 = Throw()
    //     0xf300ac: bl              #0x13ddb2c  ; ThrowStub
    // 0xf300b0: brk             #0
    // 0xf300b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf300b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf300b8: b               #0xf2fe60
    // 0xf300bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf300bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf300c0: b               #0xf2fe8c
    // 0xf300c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf300c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf300c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf300c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf300cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf300cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _trackLiveImage(/* No info */) {
    // ** addr: 0xf3022c, size: 0xcc
    // 0xf3022c: EnterFrame
    //     0xf3022c: stp             fp, lr, [SP, #-0x10]!
    //     0xf30230: mov             fp, SP
    // 0xf30234: AllocStack(0x20)
    //     0xf30234: sub             SP, SP, #0x20
    // 0xf30238: SetupParameters(ImageCache this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0xf30238: mov             x0, x5
    //     0xf3023c: stur            x1, [fp, #-8]
    //     0xf30240: stur            x2, [fp, #-0x10]
    //     0xf30244: stur            x3, [fp, #-0x18]
    //     0xf30248: stur            x5, [fp, #-0x20]
    // 0xf3024c: CheckStackOverflow
    //     0xf3024c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30250: cmp             SP, x16
    //     0xf30254: b.ls            #0xf302f0
    // 0xf30258: r1 = 3
    //     0xf30258: mov             x1, #3
    // 0xf3025c: r0 = AllocateContext()
    //     0xf3025c: bl              #0x13de838  ; AllocateContextStub
    // 0xf30260: mov             x1, x0
    // 0xf30264: ldur            x0, [fp, #-8]
    // 0xf30268: StoreField: r1->field_f = r0
    //     0xf30268: stur            w0, [x1, #0xf]
    // 0xf3026c: ldur            x3, [fp, #-0x10]
    // 0xf30270: StoreField: r1->field_13 = r3
    //     0xf30270: stur            w3, [x1, #0x13]
    // 0xf30274: ldur            x2, [fp, #-0x18]
    // 0xf30278: ArrayStore: r1[0] = r2  ; List_4
    //     0xf30278: stur            w2, [x1, #0x17]
    // 0xf3027c: LoadField: r4 = r0->field_f
    //     0xf3027c: ldur            w4, [x0, #0xf]
    // 0xf30280: DecompressPointer r4
    //     0xf30280: add             x4, x4, HEAP, lsl #32
    // 0xf30284: mov             x2, x1
    // 0xf30288: stur            x4, [fp, #-0x18]
    // 0xf3028c: r1 = Function '<anonymous closure>':.
    //     0xf3028c: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d358] AnonymousClosure: (0xf302f8), in [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage (0xf3022c)
    //     0xf30290: ldr             x1, [x1, #0x358]
    // 0xf30294: r0 = AllocateClosure()
    //     0xf30294: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf30298: ldur            x1, [fp, #-0x18]
    // 0xf3029c: ldur            x2, [fp, #-0x10]
    // 0xf302a0: mov             x3, x0
    // 0xf302a4: r0 = putIfAbsent()
    //     0xf302a4: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xf302a8: mov             x1, x0
    // 0xf302ac: LoadField: r2 = r1->field_b
    //     0xf302ac: ldur            w2, [x1, #0xb]
    // 0xf302b0: DecompressPointer r2
    //     0xf302b0: add             x2, x2, HEAP, lsl #32
    // 0xf302b4: cmp             w2, NULL
    // 0xf302b8: b.ne            #0xf302e0
    // 0xf302bc: ldur            x0, [fp, #-0x20]
    // 0xf302c0: StoreField: r1->field_b = r0
    //     0xf302c0: stur            w0, [x1, #0xb]
    //     0xf302c4: tbz             w0, #0, #0xf302e0
    //     0xf302c8: ldurb           w16, [x1, #-1]
    //     0xf302cc: ldurb           w17, [x0, #-1]
    //     0xf302d0: and             x16, x17, x16, lsr #2
    //     0xf302d4: tst             x16, HEAP, lsr #32
    //     0xf302d8: b.eq            #0xf302e0
    //     0xf302dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf302e0: r0 = Null
    //     0xf302e0: mov             x0, NULL
    // 0xf302e4: LeaveFrame
    //     0xf302e4: mov             SP, fp
    //     0xf302e8: ldp             fp, lr, [SP], #0x10
    // 0xf302ec: ret
    //     0xf302ec: ret             
    // 0xf302f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf302f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf302f4: b               #0xf30258
  }
  [closure] _LiveImage <anonymous closure>(dynamic) {
    // ** addr: 0xf302f8, size: 0x74
    // 0xf302f8: EnterFrame
    //     0xf302f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf302fc: mov             fp, SP
    // 0xf30300: AllocStack(0x10)
    //     0xf30300: sub             SP, SP, #0x10
    // 0xf30304: SetupParameters([dynamic _ /* r0 */])
    //     0xf30304: ldr             x0, [fp, #0x10]
    //     0xf30308: ldur            w2, [x0, #0x17]
    //     0xf3030c: add             x2, x2, HEAP, lsl #32
    //     0xf30310: stur            x2, [fp, #-0x10]
    // 0xf30314: CheckStackOverflow
    //     0xf30314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30318: cmp             SP, x16
    //     0xf3031c: b.ls            #0xf30364
    // 0xf30320: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xf30320: ldur            w0, [x2, #0x17]
    // 0xf30324: DecompressPointer r0
    //     0xf30324: add             x0, x0, HEAP, lsl #32
    // 0xf30328: stur            x0, [fp, #-8]
    // 0xf3032c: r0 = _LiveImage()
    //     0xf3032c: bl              #0xf30588  ; Allocate_LiveImageStub -> _LiveImage (size=0x18)
    // 0xf30330: ldur            x2, [fp, #-0x10]
    // 0xf30334: r1 = Function '<anonymous closure>':.
    //     0xf30334: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d360] AnonymousClosure: (0xf30594), in [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage (0xf3022c)
    //     0xf30338: ldr             x1, [x1, #0x360]
    // 0xf3033c: stur            x0, [fp, #-0x10]
    // 0xf30340: r0 = AllocateClosure()
    //     0xf30340: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf30344: ldur            x1, [fp, #-0x10]
    // 0xf30348: ldur            x2, [fp, #-8]
    // 0xf3034c: mov             x3, x0
    // 0xf30350: r0 = _LiveImage()
    //     0xf30350: bl              #0xf3036c  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::_LiveImage
    // 0xf30354: ldur            x0, [fp, #-0x10]
    // 0xf30358: LeaveFrame
    //     0xf30358: mov             SP, fp
    //     0xf3035c: ldp             fp, lr, [SP], #0x10
    // 0xf30360: ret
    //     0xf30360: ret             
    // 0xf30364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30368: b               #0xf30320
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf30594, size: 0x5c
    // 0xf30594: EnterFrame
    //     0xf30594: stp             fp, lr, [SP, #-0x10]!
    //     0xf30598: mov             fp, SP
    // 0xf3059c: ldr             x0, [fp, #0x10]
    // 0xf305a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf305a0: ldur            w1, [x0, #0x17]
    // 0xf305a4: DecompressPointer r1
    //     0xf305a4: add             x1, x1, HEAP, lsl #32
    // 0xf305a8: CheckStackOverflow
    //     0xf305a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf305ac: cmp             SP, x16
    //     0xf305b0: b.ls            #0xf305e8
    // 0xf305b4: LoadField: r0 = r1->field_f
    //     0xf305b4: ldur            w0, [x1, #0xf]
    // 0xf305b8: DecompressPointer r0
    //     0xf305b8: add             x0, x0, HEAP, lsl #32
    // 0xf305bc: LoadField: r2 = r0->field_f
    //     0xf305bc: ldur            w2, [x0, #0xf]
    // 0xf305c0: DecompressPointer r2
    //     0xf305c0: add             x2, x2, HEAP, lsl #32
    // 0xf305c4: LoadField: r0 = r1->field_13
    //     0xf305c4: ldur            w0, [x1, #0x13]
    // 0xf305c8: DecompressPointer r0
    //     0xf305c8: add             x0, x0, HEAP, lsl #32
    // 0xf305cc: mov             x1, x2
    // 0xf305d0: mov             x2, x0
    // 0xf305d4: r0 = remove()
    //     0xf305d4: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf305d8: r0 = Null
    //     0xf305d8: mov             x0, NULL
    // 0xf305dc: LeaveFrame
    //     0xf305dc: mov             SP, fp
    //     0xf305e0: ldp             fp, lr, [SP], #0x10
    // 0xf305e4: ret
    //     0xf305e4: ret             
    // 0xf305e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf305e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf305ec: b               #0xf305b4
  }
  [closure] void listener(dynamic, ImageInfo?, bool) {
    // ** addr: 0xf305f0, size: 0x1a0
    // 0xf305f0: EnterFrame
    //     0xf305f0: stp             fp, lr, [SP, #-0x10]!
    //     0xf305f4: mov             fp, SP
    // 0xf305f8: AllocStack(0x30)
    //     0xf305f8: sub             SP, SP, #0x30
    // 0xf305fc: SetupParameters([dynamic _ /* r0 */])
    //     0xf305fc: ldr             x0, [fp, #0x20]
    //     0xf30600: ldur            w2, [x0, #0x17]
    //     0xf30604: add             x2, x2, HEAP, lsl #32
    //     0xf30608: stur            x2, [fp, #-0x10]
    // 0xf3060c: CheckStackOverflow
    //     0xf3060c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30610: cmp             SP, x16
    //     0xf30614: b.ls            #0xf30784
    // 0xf30618: ldr             x1, [fp, #0x18]
    // 0xf3061c: cmp             w1, NULL
    // 0xf30620: b.eq            #0xf30664
    // 0xf30624: LoadField: r0 = r1->field_7
    //     0xf30624: ldur            w0, [x1, #7]
    // 0xf30628: DecompressPointer r0
    //     0xf30628: add             x0, x0, HEAP, lsl #32
    // 0xf3062c: ArrayLoad: r3 = r0[0]  ; List_8
    //     0xf3062c: ldur            x3, [x0, #0x17]
    // 0xf30630: LoadField: r4 = r0->field_f
    //     0xf30630: ldur            x4, [x0, #0xf]
    // 0xf30634: mul             x0, x3, x4
    // 0xf30638: lsl             x3, x0, #2
    // 0xf3063c: stur            x3, [fp, #-8]
    // 0xf30640: r0 = dispose()
    //     0xf30640: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xf30644: ldur            x2, [fp, #-8]
    // 0xf30648: r0 = BoxInt64Instr(r2)
    //     0xf30648: sbfiz           x0, x2, #1, #0x1f
    //     0xf3064c: cmp             x2, x0, asr #1
    //     0xf30650: b.eq            #0xf3065c
    //     0xf30654: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf30658: stur            x2, [x0, #7]
    // 0xf3065c: mov             x5, x0
    // 0xf30660: b               #0xf30668
    // 0xf30664: r5 = Null
    //     0xf30664: mov             x5, NULL
    // 0xf30668: ldur            x0, [fp, #-0x10]
    // 0xf3066c: stur            x5, [fp, #-0x20]
    // 0xf30670: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf30670: ldur            w2, [x0, #0x17]
    // 0xf30674: DecompressPointer r2
    //     0xf30674: add             x2, x2, HEAP, lsl #32
    // 0xf30678: stur            x2, [fp, #-0x18]
    // 0xf3067c: cmp             w2, NULL
    // 0xf30680: b.eq            #0xf3078c
    // 0xf30684: r0 = _CachedImage()
    //     0xf30684: bl              #0xf30220  ; Allocate_CachedImageStub -> _CachedImage (size=0x14)
    // 0xf30688: stur            x0, [fp, #-0x28]
    // 0xf3068c: ldur            x16, [fp, #-0x20]
    // 0xf30690: str             x16, [SP]
    // 0xf30694: mov             x1, x0
    // 0xf30698: ldur            x2, [fp, #-0x18]
    // 0xf3069c: r4 = const [0, 0x3, 0x1, 0x2, sizeBytes, 0x2, null]
    //     0xf3069c: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d318] List(7) [0, 0x3, 0x1, 0x2, "sizeBytes", 0x2, Null]
    //     0xf306a0: ldr             x4, [x4, #0x318]
    // 0xf306a4: r0 = _CachedImageBase()
    //     0xf306a4: bl              #0xf300d0  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::_CachedImageBase
    // 0xf306a8: ldur            x0, [fp, #-0x10]
    // 0xf306ac: LoadField: r1 = r0->field_f
    //     0xf306ac: ldur            w1, [x0, #0xf]
    // 0xf306b0: DecompressPointer r1
    //     0xf306b0: add             x1, x1, HEAP, lsl #32
    // 0xf306b4: LoadField: r2 = r0->field_13
    //     0xf306b4: ldur            w2, [x0, #0x13]
    // 0xf306b8: DecompressPointer r2
    //     0xf306b8: add             x2, x2, HEAP, lsl #32
    // 0xf306bc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xf306bc: ldur            w3, [x0, #0x17]
    // 0xf306c0: DecompressPointer r3
    //     0xf306c0: add             x3, x3, HEAP, lsl #32
    // 0xf306c4: ldur            x5, [fp, #-0x20]
    // 0xf306c8: r0 = _trackLiveImage()
    //     0xf306c8: bl              #0xf3022c  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xf306cc: ldur            x0, [fp, #-0x10]
    // 0xf306d0: LoadField: r1 = r0->field_1f
    //     0xf306d0: ldur            w1, [x0, #0x1f]
    // 0xf306d4: DecompressPointer r1
    //     0xf306d4: add             x1, x1, HEAP, lsl #32
    // 0xf306d8: tbnz            w1, #4, #0xf306f8
    // 0xf306dc: LoadField: r1 = r0->field_f
    //     0xf306dc: ldur            w1, [x0, #0xf]
    // 0xf306e0: DecompressPointer r1
    //     0xf306e0: add             x1, x1, HEAP, lsl #32
    // 0xf306e4: LoadField: r2 = r0->field_13
    //     0xf306e4: ldur            w2, [x0, #0x13]
    // 0xf306e8: DecompressPointer r2
    //     0xf306e8: add             x2, x2, HEAP, lsl #32
    // 0xf306ec: ldur            x3, [fp, #-0x28]
    // 0xf306f0: r0 = _touch()
    //     0xf306f0: bl              #0xf2fdb8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_touch
    // 0xf306f4: b               #0xf30700
    // 0xf306f8: ldur            x1, [fp, #-0x28]
    // 0xf306fc: r0 = dispose()
    //     0xf306fc: bl              #0x87c5ac  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xf30700: ldur            x0, [fp, #-0x10]
    // 0xf30704: LoadField: r1 = r0->field_f
    //     0xf30704: ldur            w1, [x0, #0xf]
    // 0xf30708: DecompressPointer r1
    //     0xf30708: add             x1, x1, HEAP, lsl #32
    // 0xf3070c: LoadField: r2 = r1->field_7
    //     0xf3070c: ldur            w2, [x1, #7]
    // 0xf30710: DecompressPointer r2
    //     0xf30710: add             x2, x2, HEAP, lsl #32
    // 0xf30714: LoadField: r1 = r0->field_13
    //     0xf30714: ldur            w1, [x0, #0x13]
    // 0xf30718: DecompressPointer r1
    //     0xf30718: add             x1, x1, HEAP, lsl #32
    // 0xf3071c: mov             x16, x1
    // 0xf30720: mov             x1, x2
    // 0xf30724: mov             x2, x16
    // 0xf30728: r0 = remove()
    //     0xf30728: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf3072c: ldur            x0, [fp, #-0x10]
    // 0xf30730: LoadField: r1 = r0->field_1b
    //     0xf30730: ldur            w1, [x0, #0x1b]
    // 0xf30734: DecompressPointer r1
    //     0xf30734: add             x1, x1, HEAP, lsl #32
    // 0xf30738: tbz             w1, #4, #0xf30754
    // 0xf3073c: LoadField: r1 = r0->field_23
    //     0xf3073c: ldur            w1, [x0, #0x23]
    // 0xf30740: DecompressPointer r1
    //     0xf30740: add             x1, x1, HEAP, lsl #32
    // 0xf30744: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf30748: cmp             w1, w16
    // 0xf3074c: b.eq            #0xf30770
    // 0xf30750: r0 = removeListener()
    //     0xf30750: bl              #0x87c4ac  ; [package:flutter/src/painting/image_cache.dart] _PendingImage::removeListener
    // 0xf30754: ldur            x0, [fp, #-0x10]
    // 0xf30758: r1 = true
    //     0xf30758: add             x1, NULL, #0x20  ; true
    // 0xf3075c: StoreField: r0->field_1b = r1
    //     0xf3075c: stur            w1, [x0, #0x1b]
    // 0xf30760: r0 = Null
    //     0xf30760: mov             x0, NULL
    // 0xf30764: LeaveFrame
    //     0xf30764: mov             SP, fp
    //     0xf30768: ldp             fp, lr, [SP], #0x10
    // 0xf3076c: ret
    //     0xf3076c: ret             
    // 0xf30770: r16 = "pendingImage"
    //     0xf30770: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d328] "pendingImage"
    //     0xf30774: ldr             x16, [x16, #0x328]
    // 0xf30778: str             x16, [SP]
    // 0xf3077c: r0 = _throwLocalNotInitialized()
    //     0xf3077c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xf30780: brk             #0
    // 0xf30784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf30784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf30788: b               #0xf30618
    // 0xf3078c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3078c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool evict(ImageCache, Object) {
    // ** addr: 0x118b5f8, size: 0xf8
    // 0x118b5f8: EnterFrame
    //     0x118b5f8: stp             fp, lr, [SP, #-0x10]!
    //     0x118b5fc: mov             fp, SP
    // 0x118b600: AllocStack(0x10)
    //     0x118b600: sub             SP, SP, #0x10
    // 0x118b604: SetupParameters(ImageCache this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x118b604: mov             x3, x1
    //     0x118b608: mov             x0, x2
    //     0x118b60c: stur            x1, [fp, #-8]
    //     0x118b610: stur            x2, [fp, #-0x10]
    // 0x118b614: CheckStackOverflow
    //     0x118b614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118b618: cmp             SP, x16
    //     0x118b61c: b.ls            #0x118b6e4
    // 0x118b620: LoadField: r1 = r3->field_f
    //     0x118b620: ldur            w1, [x3, #0xf]
    // 0x118b624: DecompressPointer r1
    //     0x118b624: add             x1, x1, HEAP, lsl #32
    // 0x118b628: mov             x2, x0
    // 0x118b62c: r0 = remove()
    //     0x118b62c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x118b630: cmp             w0, NULL
    // 0x118b634: b.eq            #0x118b640
    // 0x118b638: mov             x1, x0
    // 0x118b63c: r0 = dispose()
    //     0x118b63c: bl              #0xec09dc  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::dispose
    // 0x118b640: ldur            x0, [fp, #-8]
    // 0x118b644: LoadField: r1 = r0->field_7
    //     0x118b644: ldur            w1, [x0, #7]
    // 0x118b648: DecompressPointer r1
    //     0x118b648: add             x1, x1, HEAP, lsl #32
    // 0x118b64c: ldur            x2, [fp, #-0x10]
    // 0x118b650: r0 = remove()
    //     0x118b650: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x118b654: cmp             w0, NULL
    // 0x118b658: b.eq            #0x118b674
    // 0x118b65c: mov             x1, x0
    // 0x118b660: r0 = removeListener()
    //     0x118b660: bl              #0x87c4ac  ; [package:flutter/src/painting/image_cache.dart] _PendingImage::removeListener
    // 0x118b664: r0 = true
    //     0x118b664: add             x0, NULL, #0x20  ; true
    // 0x118b668: LeaveFrame
    //     0x118b668: mov             SP, fp
    //     0x118b66c: ldp             fp, lr, [SP], #0x10
    // 0x118b670: ret
    //     0x118b670: ret             
    // 0x118b674: ldur            x0, [fp, #-8]
    // 0x118b678: LoadField: r1 = r0->field_b
    //     0x118b678: ldur            w1, [x0, #0xb]
    // 0x118b67c: DecompressPointer r1
    //     0x118b67c: add             x1, x1, HEAP, lsl #32
    // 0x118b680: ldur            x2, [fp, #-0x10]
    // 0x118b684: r0 = remove()
    //     0x118b684: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x118b688: cmp             w0, NULL
    // 0x118b68c: b.eq            #0x118b6d4
    // 0x118b690: ldur            x1, [fp, #-8]
    // 0x118b694: LoadField: r2 = r1->field_23
    //     0x118b694: ldur            x2, [x1, #0x23]
    // 0x118b698: LoadField: r3 = r0->field_b
    //     0x118b698: ldur            w3, [x0, #0xb]
    // 0x118b69c: DecompressPointer r3
    //     0x118b69c: add             x3, x3, HEAP, lsl #32
    // 0x118b6a0: cmp             w3, NULL
    // 0x118b6a4: b.eq            #0x118b6ec
    // 0x118b6a8: r4 = LoadInt32Instr(r3)
    //     0x118b6a8: sbfx            x4, x3, #1, #0x1f
    //     0x118b6ac: tbz             w3, #0, #0x118b6b4
    //     0x118b6b0: ldur            x4, [x3, #7]
    // 0x118b6b4: sub             x3, x2, x4
    // 0x118b6b8: StoreField: r1->field_23 = r3
    //     0x118b6b8: stur            x3, [x1, #0x23]
    // 0x118b6bc: mov             x1, x0
    // 0x118b6c0: r0 = dispose()
    //     0x118b6c0: bl              #0x87c5ac  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0x118b6c4: r0 = true
    //     0x118b6c4: add             x0, NULL, #0x20  ; true
    // 0x118b6c8: LeaveFrame
    //     0x118b6c8: mov             SP, fp
    //     0x118b6cc: ldp             fp, lr, [SP], #0x10
    // 0x118b6d0: ret
    //     0x118b6d0: ret             
    // 0x118b6d4: r0 = false
    //     0x118b6d4: add             x0, NULL, #0x30  ; false
    // 0x118b6d8: LeaveFrame
    //     0x118b6d8: mov             SP, fp
    //     0x118b6dc: ldp             fp, lr, [SP], #0x10
    // 0x118b6e0: ret
    //     0x118b6e0: ret             
    // 0x118b6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118b6e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118b6e8: b               #0x118b620
    // 0x118b6ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x118b6ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
