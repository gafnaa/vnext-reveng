// lib: , url: package:flutter/src/painting/strut_style.dart

// class id: 1049009, size: 0x8
class :: {
}

// class id: 5043, size: 0x34, field offset: 0x8
//   const constructor, 
class StrutStyle extends _MixinApplication3&Object&Diagnosticable {

  _Double field_18;
  _Double field_28;

  _ merge(/* No info */) {
    // ** addr: 0xd625b8, size: 0x190
    // 0xd625b8: EnterFrame
    //     0xd625b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd625bc: mov             fp, SP
    // 0xd625c0: AllocStack(0x50)
    //     0xd625c0: sub             SP, SP, #0x50
    // 0xd625c4: LoadField: r0 = r2->field_7
    //     0xd625c4: ldur            w0, [x2, #7]
    // 0xd625c8: DecompressPointer r0
    //     0xd625c8: add             x0, x0, HEAP, lsl #32
    // 0xd625cc: cmp             w0, NULL
    // 0xd625d0: b.ne            #0xd625dc
    // 0xd625d4: LoadField: r0 = r1->field_7
    //     0xd625d4: ldur            w0, [x1, #7]
    // 0xd625d8: DecompressPointer r0
    //     0xd625d8: add             x0, x0, HEAP, lsl #32
    // 0xd625dc: stur            x0, [fp, #-0x50]
    // 0xd625e0: LoadField: r3 = r2->field_b
    //     0xd625e0: ldur            w3, [x2, #0xb]
    // 0xd625e4: DecompressPointer r3
    //     0xd625e4: add             x3, x3, HEAP, lsl #32
    // 0xd625e8: cmp             w3, NULL
    // 0xd625ec: b.ne            #0xd625f8
    // 0xd625f0: LoadField: r3 = r1->field_b
    //     0xd625f0: ldur            w3, [x1, #0xb]
    // 0xd625f4: DecompressPointer r3
    //     0xd625f4: add             x3, x3, HEAP, lsl #32
    // 0xd625f8: stur            x3, [fp, #-0x48]
    // 0xd625fc: LoadField: r4 = r2->field_13
    //     0xd625fc: ldur            w4, [x2, #0x13]
    // 0xd62600: DecompressPointer r4
    //     0xd62600: add             x4, x4, HEAP, lsl #32
    // 0xd62604: cmp             w4, NULL
    // 0xd62608: b.ne            #0xd62614
    // 0xd6260c: LoadField: r4 = r1->field_13
    //     0xd6260c: ldur            w4, [x1, #0x13]
    // 0xd62610: DecompressPointer r4
    //     0xd62610: add             x4, x4, HEAP, lsl #32
    // 0xd62614: stur            x4, [fp, #-0x40]
    // 0xd62618: ArrayLoad: r5 = r2[0]  ; List_4
    //     0xd62618: ldur            w5, [x2, #0x17]
    // 0xd6261c: DecompressPointer r5
    //     0xd6261c: add             x5, x5, HEAP, lsl #32
    // 0xd62620: cmp             w5, NULL
    // 0xd62624: b.ne            #0xd62630
    // 0xd62628: ArrayLoad: r5 = r1[0]  ; List_4
    //     0xd62628: ldur            w5, [x1, #0x17]
    // 0xd6262c: DecompressPointer r5
    //     0xd6262c: add             x5, x5, HEAP, lsl #32
    // 0xd62630: stur            x5, [fp, #-0x38]
    // 0xd62634: LoadField: r6 = r2->field_1b
    //     0xd62634: ldur            w6, [x2, #0x1b]
    // 0xd62638: DecompressPointer r6
    //     0xd62638: add             x6, x6, HEAP, lsl #32
    // 0xd6263c: cmp             w6, NULL
    // 0xd62640: b.ne            #0xd6264c
    // 0xd62644: LoadField: r6 = r1->field_1b
    //     0xd62644: ldur            w6, [x1, #0x1b]
    // 0xd62648: DecompressPointer r6
    //     0xd62648: add             x6, x6, HEAP, lsl #32
    // 0xd6264c: stur            x6, [fp, #-0x30]
    // 0xd62650: LoadField: r7 = r2->field_27
    //     0xd62650: ldur            w7, [x2, #0x27]
    // 0xd62654: DecompressPointer r7
    //     0xd62654: add             x7, x7, HEAP, lsl #32
    // 0xd62658: cmp             w7, NULL
    // 0xd6265c: b.ne            #0xd62668
    // 0xd62660: LoadField: r7 = r1->field_27
    //     0xd62660: ldur            w7, [x1, #0x27]
    // 0xd62664: DecompressPointer r7
    //     0xd62664: add             x7, x7, HEAP, lsl #32
    // 0xd62668: stur            x7, [fp, #-0x28]
    // 0xd6266c: LoadField: r8 = r2->field_1f
    //     0xd6266c: ldur            w8, [x2, #0x1f]
    // 0xd62670: DecompressPointer r8
    //     0xd62670: add             x8, x8, HEAP, lsl #32
    // 0xd62674: cmp             w8, NULL
    // 0xd62678: b.ne            #0xd62684
    // 0xd6267c: LoadField: r8 = r1->field_1f
    //     0xd6267c: ldur            w8, [x1, #0x1f]
    // 0xd62680: DecompressPointer r8
    //     0xd62680: add             x8, x8, HEAP, lsl #32
    // 0xd62684: stur            x8, [fp, #-0x20]
    // 0xd62688: LoadField: r9 = r2->field_23
    //     0xd62688: ldur            w9, [x2, #0x23]
    // 0xd6268c: DecompressPointer r9
    //     0xd6268c: add             x9, x9, HEAP, lsl #32
    // 0xd62690: cmp             w9, NULL
    // 0xd62694: b.ne            #0xd626a0
    // 0xd62698: LoadField: r9 = r1->field_23
    //     0xd62698: ldur            w9, [x1, #0x23]
    // 0xd6269c: DecompressPointer r9
    //     0xd6269c: add             x9, x9, HEAP, lsl #32
    // 0xd626a0: stur            x9, [fp, #-0x18]
    // 0xd626a4: LoadField: r10 = r2->field_2b
    //     0xd626a4: ldur            w10, [x2, #0x2b]
    // 0xd626a8: DecompressPointer r10
    //     0xd626a8: add             x10, x10, HEAP, lsl #32
    // 0xd626ac: cmp             w10, NULL
    // 0xd626b0: b.ne            #0xd626bc
    // 0xd626b4: LoadField: r10 = r1->field_2b
    //     0xd626b4: ldur            w10, [x1, #0x2b]
    // 0xd626b8: DecompressPointer r10
    //     0xd626b8: add             x10, x10, HEAP, lsl #32
    // 0xd626bc: stur            x10, [fp, #-0x10]
    // 0xd626c0: LoadField: r11 = r2->field_2f
    //     0xd626c0: ldur            w11, [x2, #0x2f]
    // 0xd626c4: DecompressPointer r11
    //     0xd626c4: add             x11, x11, HEAP, lsl #32
    // 0xd626c8: cmp             w11, NULL
    // 0xd626cc: b.ne            #0xd626e0
    // 0xd626d0: LoadField: r2 = r1->field_2f
    //     0xd626d0: ldur            w2, [x1, #0x2f]
    // 0xd626d4: DecompressPointer r2
    //     0xd626d4: add             x2, x2, HEAP, lsl #32
    // 0xd626d8: mov             x1, x2
    // 0xd626dc: b               #0xd626e4
    // 0xd626e0: mov             x1, x11
    // 0xd626e4: stur            x1, [fp, #-8]
    // 0xd626e8: r0 = StrutStyle()
    //     0xd626e8: bl              #0xd62748  ; AllocateStrutStyleStub -> StrutStyle (size=0x34)
    // 0xd626ec: ldur            x1, [fp, #-0x40]
    // 0xd626f0: StoreField: r0->field_13 = r1
    //     0xd626f0: stur            w1, [x0, #0x13]
    // 0xd626f4: ldur            x1, [fp, #-0x38]
    // 0xd626f8: ArrayStore: r0[0] = r1  ; List_4
    //     0xd626f8: stur            w1, [x0, #0x17]
    // 0xd626fc: ldur            x1, [fp, #-0x30]
    // 0xd62700: StoreField: r0->field_1b = r1
    //     0xd62700: stur            w1, [x0, #0x1b]
    // 0xd62704: ldur            x1, [fp, #-0x28]
    // 0xd62708: StoreField: r0->field_27 = r1
    //     0xd62708: stur            w1, [x0, #0x27]
    // 0xd6270c: ldur            x1, [fp, #-0x20]
    // 0xd62710: StoreField: r0->field_1f = r1
    //     0xd62710: stur            w1, [x0, #0x1f]
    // 0xd62714: ldur            x1, [fp, #-0x18]
    // 0xd62718: StoreField: r0->field_23 = r1
    //     0xd62718: stur            w1, [x0, #0x23]
    // 0xd6271c: ldur            x1, [fp, #-0x10]
    // 0xd62720: StoreField: r0->field_2b = r1
    //     0xd62720: stur            w1, [x0, #0x2b]
    // 0xd62724: ldur            x1, [fp, #-8]
    // 0xd62728: StoreField: r0->field_2f = r1
    //     0xd62728: stur            w1, [x0, #0x2f]
    // 0xd6272c: ldur            x1, [fp, #-0x50]
    // 0xd62730: StoreField: r0->field_7 = r1
    //     0xd62730: stur            w1, [x0, #7]
    // 0xd62734: ldur            x1, [fp, #-0x48]
    // 0xd62738: StoreField: r0->field_b = r1
    //     0xd62738: stur            w1, [x0, #0xb]
    // 0xd6273c: LeaveFrame
    //     0xd6273c: mov             SP, fp
    //     0xd62740: ldp             fp, lr, [SP], #0x10
    // 0xd62744: ret
    //     0xd62744: ret             
  }
  _ inheritFromTextStyle(/* No info */) {
    // ** addr: 0xd627d0, size: 0x1e4
    // 0xd627d0: EnterFrame
    //     0xd627d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd627d4: mov             fp, SP
    // 0xd627d8: AllocStack(0x58)
    //     0xd627d8: sub             SP, SP, #0x58
    // 0xd627dc: SetupParameters(StrutStyle this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0xd627dc: mov             x0, x2
    //     0xd627e0: stur            x2, [fp, #-0x20]
    //     0xd627e4: mov             x2, x1
    //     0xd627e8: stur            x1, [fp, #-0x18]
    // 0xd627ec: CheckStackOverflow
    //     0xd627ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd627f0: cmp             SP, x16
    //     0xd627f4: b.ls            #0xd629ac
    // 0xd627f8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd627f8: ldur            w1, [x2, #0x17]
    // 0xd627fc: DecompressPointer r1
    //     0xd627fc: add             x1, x1, HEAP, lsl #32
    // 0xd62800: cmp             w1, NULL
    // 0xd62804: b.ne            #0xd62818
    // 0xd62808: LoadField: r1 = r0->field_37
    //     0xd62808: ldur            w1, [x0, #0x37]
    // 0xd6280c: DecompressPointer r1
    //     0xd6280c: add             x1, x1, HEAP, lsl #32
    // 0xd62810: mov             x3, x1
    // 0xd62814: b               #0xd6281c
    // 0xd62818: mov             x3, x1
    // 0xd6281c: stur            x3, [fp, #-0x10]
    // 0xd62820: LoadField: r1 = r2->field_7
    //     0xd62820: ldur            w1, [x2, #7]
    // 0xd62824: DecompressPointer r1
    //     0xd62824: add             x1, x1, HEAP, lsl #32
    // 0xd62828: cmp             w1, NULL
    // 0xd6282c: b.ne            #0xd62840
    // 0xd62830: LoadField: r1 = r0->field_13
    //     0xd62830: ldur            w1, [x0, #0x13]
    // 0xd62834: DecompressPointer r1
    //     0xd62834: add             x1, x1, HEAP, lsl #32
    // 0xd62838: mov             x4, x1
    // 0xd6283c: b               #0xd62844
    // 0xd62840: mov             x4, x1
    // 0xd62844: stur            x4, [fp, #-8]
    // 0xd62848: LoadField: r1 = r2->field_b
    //     0xd62848: ldur            w1, [x2, #0xb]
    // 0xd6284c: DecompressPointer r1
    //     0xd6284c: add             x1, x1, HEAP, lsl #32
    // 0xd62850: cmp             w1, NULL
    // 0xd62854: b.ne            #0xd62864
    // 0xd62858: mov             x1, x0
    // 0xd6285c: r0 = fontFamilyFallback()
    //     0xd6285c: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0xd62860: mov             x1, x0
    // 0xd62864: ldur            x0, [fp, #-0x18]
    // 0xd62868: stur            x1, [fp, #-0x58]
    // 0xd6286c: LoadField: r2 = r0->field_13
    //     0xd6286c: ldur            w2, [x0, #0x13]
    // 0xd62870: DecompressPointer r2
    //     0xd62870: add             x2, x2, HEAP, lsl #32
    // 0xd62874: cmp             w2, NULL
    // 0xd62878: b.ne            #0xd6288c
    // 0xd6287c: ldur            x3, [fp, #-0x20]
    // 0xd62880: LoadField: r2 = r3->field_1f
    //     0xd62880: ldur            w2, [x3, #0x1f]
    // 0xd62884: DecompressPointer r2
    //     0xd62884: add             x2, x2, HEAP, lsl #32
    // 0xd62888: b               #0xd62890
    // 0xd6288c: ldur            x3, [fp, #-0x20]
    // 0xd62890: stur            x2, [fp, #-0x50]
    // 0xd62894: LoadField: r4 = r0->field_27
    //     0xd62894: ldur            w4, [x0, #0x27]
    // 0xd62898: DecompressPointer r4
    //     0xd62898: add             x4, x4, HEAP, lsl #32
    // 0xd6289c: stur            x4, [fp, #-0x48]
    // 0xd628a0: LoadField: r5 = r0->field_1f
    //     0xd628a0: ldur            w5, [x0, #0x1f]
    // 0xd628a4: DecompressPointer r5
    //     0xd628a4: add             x5, x5, HEAP, lsl #32
    // 0xd628a8: cmp             w5, NULL
    // 0xd628ac: b.ne            #0xd628b8
    // 0xd628b0: LoadField: r5 = r3->field_23
    //     0xd628b0: ldur            w5, [x3, #0x23]
    // 0xd628b4: DecompressPointer r5
    //     0xd628b4: add             x5, x5, HEAP, lsl #32
    // 0xd628b8: stur            x5, [fp, #-0x40]
    // 0xd628bc: LoadField: r6 = r0->field_23
    //     0xd628bc: ldur            w6, [x0, #0x23]
    // 0xd628c0: DecompressPointer r6
    //     0xd628c0: add             x6, x6, HEAP, lsl #32
    // 0xd628c4: cmp             w6, NULL
    // 0xd628c8: b.ne            #0xd628d4
    // 0xd628cc: LoadField: r6 = r3->field_27
    //     0xd628cc: ldur            w6, [x3, #0x27]
    // 0xd628d0: DecompressPointer r6
    //     0xd628d0: add             x6, x6, HEAP, lsl #32
    // 0xd628d4: stur            x6, [fp, #-0x38]
    // 0xd628d8: LoadField: r7 = r0->field_2b
    //     0xd628d8: ldur            w7, [x0, #0x2b]
    // 0xd628dc: DecompressPointer r7
    //     0xd628dc: add             x7, x7, HEAP, lsl #32
    // 0xd628e0: stur            x7, [fp, #-0x30]
    // 0xd628e4: LoadField: r8 = r0->field_2f
    //     0xd628e4: ldur            w8, [x0, #0x2f]
    // 0xd628e8: DecompressPointer r8
    //     0xd628e8: add             x8, x8, HEAP, lsl #32
    // 0xd628ec: cmp             w8, NULL
    // 0xd628f0: b.ne            #0xd62904
    // 0xd628f4: LoadField: r8 = r3->field_5b
    //     0xd628f4: ldur            w8, [x3, #0x5b]
    // 0xd628f8: DecompressPointer r8
    //     0xd628f8: add             x8, x8, HEAP, lsl #32
    // 0xd628fc: mov             x9, x8
    // 0xd62900: b               #0xd62908
    // 0xd62904: mov             x9, x8
    // 0xd62908: ldur            x8, [fp, #-0x10]
    // 0xd6290c: stur            x9, [fp, #-0x28]
    // 0xd62910: cmp             w8, NULL
    // 0xd62914: b.eq            #0xd62940
    // 0xd62918: LoadField: r10 = r0->field_1b
    //     0xd62918: ldur            w10, [x0, #0x1b]
    // 0xd6291c: DecompressPointer r10
    //     0xd6291c: add             x10, x10, HEAP, lsl #32
    // 0xd62920: cmp             w10, NULL
    // 0xd62924: b.ne            #0xd62934
    // 0xd62928: LoadField: r0 = r3->field_3b
    //     0xd62928: ldur            w0, [x3, #0x3b]
    // 0xd6292c: DecompressPointer r0
    //     0xd6292c: add             x0, x0, HEAP, lsl #32
    // 0xd62930: b               #0xd62938
    // 0xd62934: mov             x0, x10
    // 0xd62938: mov             x3, x0
    // 0xd6293c: b               #0xd62944
    // 0xd62940: r3 = Null
    //     0xd62940: mov             x3, NULL
    // 0xd62944: ldur            x0, [fp, #-8]
    // 0xd62948: stur            x3, [fp, #-0x18]
    // 0xd6294c: r0 = StrutStyle()
    //     0xd6294c: bl              #0xd62748  ; AllocateStrutStyleStub -> StrutStyle (size=0x34)
    // 0xd62950: ldur            x1, [fp, #-0x50]
    // 0xd62954: StoreField: r0->field_13 = r1
    //     0xd62954: stur            w1, [x0, #0x13]
    // 0xd62958: ldur            x1, [fp, #-0x10]
    // 0xd6295c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd6295c: stur            w1, [x0, #0x17]
    // 0xd62960: ldur            x1, [fp, #-0x18]
    // 0xd62964: StoreField: r0->field_1b = r1
    //     0xd62964: stur            w1, [x0, #0x1b]
    // 0xd62968: ldur            x1, [fp, #-0x48]
    // 0xd6296c: StoreField: r0->field_27 = r1
    //     0xd6296c: stur            w1, [x0, #0x27]
    // 0xd62970: ldur            x1, [fp, #-0x40]
    // 0xd62974: StoreField: r0->field_1f = r1
    //     0xd62974: stur            w1, [x0, #0x1f]
    // 0xd62978: ldur            x1, [fp, #-0x38]
    // 0xd6297c: StoreField: r0->field_23 = r1
    //     0xd6297c: stur            w1, [x0, #0x23]
    // 0xd62980: ldur            x1, [fp, #-0x30]
    // 0xd62984: StoreField: r0->field_2b = r1
    //     0xd62984: stur            w1, [x0, #0x2b]
    // 0xd62988: ldur            x1, [fp, #-0x28]
    // 0xd6298c: StoreField: r0->field_2f = r1
    //     0xd6298c: stur            w1, [x0, #0x2f]
    // 0xd62990: ldur            x1, [fp, #-8]
    // 0xd62994: StoreField: r0->field_7 = r1
    //     0xd62994: stur            w1, [x0, #7]
    // 0xd62998: ldur            x1, [fp, #-0x58]
    // 0xd6299c: StoreField: r0->field_b = r1
    //     0xd6299c: stur            w1, [x0, #0xb]
    // 0xd629a0: LeaveFrame
    //     0xd629a0: mov             SP, fp
    //     0xd629a4: ldp             fp, lr, [SP], #0x10
    // 0xd629a8: ret
    //     0xd629a8: ret             
    // 0xd629ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd629ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd629b0: b               #0xd627f8
  }
  _ StrutStyle.fromTextStyle(/* No info */) {
    // ** addr: 0xd629b4, size: 0x194
    // 0xd629b4: EnterFrame
    //     0xd629b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd629b8: mov             fp, SP
    // 0xd629bc: AllocStack(0x18)
    //     0xd629bc: sub             SP, SP, #0x18
    // 0xd629c0: SetupParameters(StrutStyle this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd629c0: mov             x0, x2
    //     0xd629c4: stur            x2, [fp, #-0x18]
    //     0xd629c8: mov             x2, x1
    //     0xd629cc: stur            x1, [fp, #-0x10]
    // 0xd629d0: CheckStackOverflow
    //     0xd629d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd629d4: cmp             SP, x16
    //     0xd629d8: b.ls            #0xd62b40
    // 0xd629dc: LoadField: r3 = r0->field_13
    //     0xd629dc: ldur            w3, [x0, #0x13]
    // 0xd629e0: DecompressPointer r3
    //     0xd629e0: add             x3, x3, HEAP, lsl #32
    // 0xd629e4: mov             x1, x0
    // 0xd629e8: stur            x3, [fp, #-8]
    // 0xd629ec: r0 = fontFamilyFallback()
    //     0xd629ec: bl              #0x85c694  ; [package:flutter/src/painting/text_style.dart] TextStyle::fontFamilyFallback
    // 0xd629f0: mov             x2, x0
    // 0xd629f4: ldur            x1, [fp, #-0x18]
    // 0xd629f8: LoadField: r3 = r1->field_37
    //     0xd629f8: ldur            w3, [x1, #0x37]
    // 0xd629fc: DecompressPointer r3
    //     0xd629fc: add             x3, x3, HEAP, lsl #32
    // 0xd62a00: LoadField: r4 = r1->field_3b
    //     0xd62a00: ldur            w4, [x1, #0x3b]
    // 0xd62a04: DecompressPointer r4
    //     0xd62a04: add             x4, x4, HEAP, lsl #32
    // 0xd62a08: LoadField: r0 = r1->field_1f
    //     0xd62a08: ldur            w0, [x1, #0x1f]
    // 0xd62a0c: DecompressPointer r0
    //     0xd62a0c: add             x0, x0, HEAP, lsl #32
    // 0xd62a10: LoadField: r5 = r1->field_23
    //     0xd62a10: ldur            w5, [x1, #0x23]
    // 0xd62a14: DecompressPointer r5
    //     0xd62a14: add             x5, x5, HEAP, lsl #32
    // 0xd62a18: LoadField: r6 = r1->field_27
    //     0xd62a18: ldur            w6, [x1, #0x27]
    // 0xd62a1c: DecompressPointer r6
    //     0xd62a1c: add             x6, x6, HEAP, lsl #32
    // 0xd62a20: LoadField: r7 = r1->field_5b
    //     0xd62a20: ldur            w7, [x1, #0x5b]
    // 0xd62a24: DecompressPointer r7
    //     0xd62a24: add             x7, x7, HEAP, lsl #32
    // 0xd62a28: ldur            x1, [fp, #-0x10]
    // 0xd62a2c: StoreField: r1->field_13 = r0
    //     0xd62a2c: stur            w0, [x1, #0x13]
    //     0xd62a30: ldurb           w16, [x1, #-1]
    //     0xd62a34: ldurb           w17, [x0, #-1]
    //     0xd62a38: and             x16, x17, x16, lsr #2
    //     0xd62a3c: tst             x16, HEAP, lsr #32
    //     0xd62a40: b.eq            #0xd62a48
    //     0xd62a44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62a48: mov             x0, x3
    // 0xd62a4c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd62a4c: stur            w0, [x1, #0x17]
    //     0xd62a50: ldurb           w16, [x1, #-1]
    //     0xd62a54: ldurb           w17, [x0, #-1]
    //     0xd62a58: and             x16, x17, x16, lsr #2
    //     0xd62a5c: tst             x16, HEAP, lsr #32
    //     0xd62a60: b.eq            #0xd62a68
    //     0xd62a64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62a68: mov             x0, x4
    // 0xd62a6c: StoreField: r1->field_1b = r0
    //     0xd62a6c: stur            w0, [x1, #0x1b]
    //     0xd62a70: ldurb           w16, [x1, #-1]
    //     0xd62a74: ldurb           w17, [x0, #-1]
    //     0xd62a78: and             x16, x17, x16, lsr #2
    //     0xd62a7c: tst             x16, HEAP, lsr #32
    //     0xd62a80: b.eq            #0xd62a88
    //     0xd62a84: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62a88: mov             x0, x5
    // 0xd62a8c: StoreField: r1->field_1f = r0
    //     0xd62a8c: stur            w0, [x1, #0x1f]
    //     0xd62a90: ldurb           w16, [x1, #-1]
    //     0xd62a94: ldurb           w17, [x0, #-1]
    //     0xd62a98: and             x16, x17, x16, lsr #2
    //     0xd62a9c: tst             x16, HEAP, lsr #32
    //     0xd62aa0: b.eq            #0xd62aa8
    //     0xd62aa4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62aa8: mov             x0, x6
    // 0xd62aac: StoreField: r1->field_23 = r0
    //     0xd62aac: stur            w0, [x1, #0x23]
    //     0xd62ab0: ldurb           w16, [x1, #-1]
    //     0xd62ab4: ldurb           w17, [x0, #-1]
    //     0xd62ab8: and             x16, x17, x16, lsr #2
    //     0xd62abc: tst             x16, HEAP, lsr #32
    //     0xd62ac0: b.eq            #0xd62ac8
    //     0xd62ac4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62ac8: r3 = true
    //     0xd62ac8: add             x3, NULL, #0x20  ; true
    // 0xd62acc: StoreField: r1->field_2b = r3
    //     0xd62acc: stur            w3, [x1, #0x2b]
    // 0xd62ad0: mov             x0, x7
    // 0xd62ad4: StoreField: r1->field_2f = r0
    //     0xd62ad4: stur            w0, [x1, #0x2f]
    //     0xd62ad8: ldurb           w16, [x1, #-1]
    //     0xd62adc: ldurb           w17, [x0, #-1]
    //     0xd62ae0: and             x16, x17, x16, lsr #2
    //     0xd62ae4: tst             x16, HEAP, lsr #32
    //     0xd62ae8: b.eq            #0xd62af0
    //     0xd62aec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62af0: ldur            x0, [fp, #-8]
    // 0xd62af4: StoreField: r1->field_7 = r0
    //     0xd62af4: stur            w0, [x1, #7]
    //     0xd62af8: ldurb           w16, [x1, #-1]
    //     0xd62afc: ldurb           w17, [x0, #-1]
    //     0xd62b00: and             x16, x17, x16, lsr #2
    //     0xd62b04: tst             x16, HEAP, lsr #32
    //     0xd62b08: b.eq            #0xd62b10
    //     0xd62b0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62b10: mov             x0, x2
    // 0xd62b14: StoreField: r1->field_b = r0
    //     0xd62b14: stur            w0, [x1, #0xb]
    //     0xd62b18: ldurb           w16, [x1, #-1]
    //     0xd62b1c: ldurb           w17, [x0, #-1]
    //     0xd62b20: and             x16, x17, x16, lsr #2
    //     0xd62b24: tst             x16, HEAP, lsr #32
    //     0xd62b28: b.eq            #0xd62b30
    //     0xd62b2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd62b30: r0 = Null
    //     0xd62b30: mov             x0, NULL
    // 0xd62b34: LeaveFrame
    //     0xd62b34: mov             SP, fp
    //     0xd62b38: ldp             fp, lr, [SP], #0x10
    // 0xd62b3c: ret
    //     0xd62b3c: ret             
    // 0xd62b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd62b40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd62b44: b               #0xd629dc
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113b388, size: 0x98
    // 0x113b388: EnterFrame
    //     0x113b388: stp             fp, lr, [SP, #-0x10]!
    //     0x113b38c: mov             fp, SP
    // 0x113b390: AllocStack(0x28)
    //     0x113b390: sub             SP, SP, #0x28
    // 0x113b394: CheckStackOverflow
    //     0x113b394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b398: cmp             SP, x16
    //     0x113b39c: b.ls            #0x113b418
    // 0x113b3a0: ldr             x0, [fp, #0x10]
    // 0x113b3a4: LoadField: r1 = r0->field_7
    //     0x113b3a4: ldur            w1, [x0, #7]
    // 0x113b3a8: DecompressPointer r1
    //     0x113b3a8: add             x1, x1, HEAP, lsl #32
    // 0x113b3ac: LoadField: r2 = r0->field_13
    //     0x113b3ac: ldur            w2, [x0, #0x13]
    // 0x113b3b0: DecompressPointer r2
    //     0x113b3b0: add             x2, x2, HEAP, lsl #32
    // 0x113b3b4: LoadField: r3 = r0->field_1f
    //     0x113b3b4: ldur            w3, [x0, #0x1f]
    // 0x113b3b8: DecompressPointer r3
    //     0x113b3b8: add             x3, x3, HEAP, lsl #32
    // 0x113b3bc: LoadField: r4 = r0->field_23
    //     0x113b3bc: ldur            w4, [x0, #0x23]
    // 0x113b3c0: DecompressPointer r4
    //     0x113b3c0: add             x4, x4, HEAP, lsl #32
    // 0x113b3c4: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x113b3c4: ldur            w5, [x0, #0x17]
    // 0x113b3c8: DecompressPointer r5
    //     0x113b3c8: add             x5, x5, HEAP, lsl #32
    // 0x113b3cc: LoadField: r6 = r0->field_27
    //     0x113b3cc: ldur            w6, [x0, #0x27]
    // 0x113b3d0: DecompressPointer r6
    //     0x113b3d0: add             x6, x6, HEAP, lsl #32
    // 0x113b3d4: LoadField: r7 = r0->field_2b
    //     0x113b3d4: ldur            w7, [x0, #0x2b]
    // 0x113b3d8: DecompressPointer r7
    //     0x113b3d8: add             x7, x7, HEAP, lsl #32
    // 0x113b3dc: stp             x4, x3, [SP, #0x18]
    // 0x113b3e0: stp             x6, x5, [SP, #8]
    // 0x113b3e4: str             x7, [SP]
    // 0x113b3e8: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x113b3e8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x113b3ec: ldr             x4, [x4, #0x8a0]
    // 0x113b3f0: r0 = hash()
    //     0x113b3f0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b3f4: mov             x2, x0
    // 0x113b3f8: r0 = BoxInt64Instr(r2)
    //     0x113b3f8: sbfiz           x0, x2, #1, #0x1f
    //     0x113b3fc: cmp             x2, x0, asr #1
    //     0x113b400: b.eq            #0x113b40c
    //     0x113b404: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b408: stur            x2, [x0, #7]
    // 0x113b40c: LeaveFrame
    //     0x113b40c: mov             SP, fp
    //     0x113b410: ldp             fp, lr, [SP], #0x10
    // 0x113b414: ret
    //     0x113b414: ret             
    // 0x113b418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b41c: b               #0x113b3a0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1278980, size: 0x260
    // 0x1278980: EnterFrame
    //     0x1278980: stp             fp, lr, [SP, #-0x10]!
    //     0x1278984: mov             fp, SP
    // 0x1278988: AllocStack(0x20)
    //     0x1278988: sub             SP, SP, #0x20
    // 0x127898c: CheckStackOverflow
    //     0x127898c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1278990: cmp             SP, x16
    //     0x1278994: b.ls            #0x1278bd8
    // 0x1278998: ldr             x0, [fp, #0x10]
    // 0x127899c: cmp             w0, NULL
    // 0x12789a0: b.ne            #0x12789b4
    // 0x12789a4: r0 = false
    //     0x12789a4: add             x0, NULL, #0x30  ; false
    // 0x12789a8: LeaveFrame
    //     0x12789a8: mov             SP, fp
    //     0x12789ac: ldp             fp, lr, [SP], #0x10
    // 0x12789b0: ret
    //     0x12789b0: ret             
    // 0x12789b4: ldr             x1, [fp, #0x18]
    // 0x12789b8: cmp             w1, w0
    // 0x12789bc: b.ne            #0x12789d0
    // 0x12789c0: r0 = true
    //     0x12789c0: add             x0, NULL, #0x20  ; true
    // 0x12789c4: LeaveFrame
    //     0x12789c4: mov             SP, fp
    //     0x12789c8: ldp             fp, lr, [SP], #0x10
    // 0x12789cc: ret
    //     0x12789cc: ret             
    // 0x12789d0: str             x0, [SP]
    // 0x12789d4: r0 = runtimeType()
    //     0x12789d4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12789d8: r1 = LoadClassIdInstr(r0)
    //     0x12789d8: ldur            x1, [x0, #-1]
    //     0x12789dc: ubfx            x1, x1, #0xc, #0x14
    // 0x12789e0: r16 = StrutStyle
    //     0x12789e0: ldr             x16, [PP, #0x4c30]  ; [pp+0x4c30] Type: StrutStyle
    // 0x12789e4: stp             x16, x0, [SP]
    // 0x12789e8: mov             x0, x1
    // 0x12789ec: mov             lr, x0
    // 0x12789f0: ldr             lr, [x21, lr, lsl #3]
    // 0x12789f4: blr             lr
    // 0x12789f8: tbz             w0, #4, #0x1278a0c
    // 0x12789fc: r0 = false
    //     0x12789fc: add             x0, NULL, #0x30  ; false
    // 0x1278a00: LeaveFrame
    //     0x1278a00: mov             SP, fp
    //     0x1278a04: ldp             fp, lr, [SP], #0x10
    // 0x1278a08: ret
    //     0x1278a08: ret             
    // 0x1278a0c: ldr             x1, [fp, #0x10]
    // 0x1278a10: r0 = 60
    //     0x1278a10: mov             x0, #0x3c
    // 0x1278a14: branchIfSmi(r1, 0x1278a20)
    //     0x1278a14: tbz             w1, #0, #0x1278a20
    // 0x1278a18: r0 = LoadClassIdInstr(r1)
    //     0x1278a18: ldur            x0, [x1, #-1]
    //     0x1278a1c: ubfx            x0, x0, #0xc, #0x14
    // 0x1278a20: r17 = 5043
    //     0x1278a20: mov             x17, #0x13b3
    // 0x1278a24: cmp             x0, x17
    // 0x1278a28: b.ne            #0x1278bc8
    // 0x1278a2c: ldr             x2, [fp, #0x18]
    // 0x1278a30: LoadField: r0 = r1->field_7
    //     0x1278a30: ldur            w0, [x1, #7]
    // 0x1278a34: DecompressPointer r0
    //     0x1278a34: add             x0, x0, HEAP, lsl #32
    // 0x1278a38: LoadField: r3 = r2->field_7
    //     0x1278a38: ldur            w3, [x2, #7]
    // 0x1278a3c: DecompressPointer r3
    //     0x1278a3c: add             x3, x3, HEAP, lsl #32
    // 0x1278a40: r4 = LoadClassIdInstr(r0)
    //     0x1278a40: ldur            x4, [x0, #-1]
    //     0x1278a44: ubfx            x4, x4, #0xc, #0x14
    // 0x1278a48: stp             x3, x0, [SP]
    // 0x1278a4c: mov             x0, x4
    // 0x1278a50: mov             lr, x0
    // 0x1278a54: ldr             lr, [x21, lr, lsl #3]
    // 0x1278a58: blr             lr
    // 0x1278a5c: tbnz            w0, #4, #0x1278bc8
    // 0x1278a60: ldr             x2, [fp, #0x18]
    // 0x1278a64: ldr             x1, [fp, #0x10]
    // 0x1278a68: LoadField: r0 = r1->field_13
    //     0x1278a68: ldur            w0, [x1, #0x13]
    // 0x1278a6c: DecompressPointer r0
    //     0x1278a6c: add             x0, x0, HEAP, lsl #32
    // 0x1278a70: LoadField: r3 = r2->field_13
    //     0x1278a70: ldur            w3, [x2, #0x13]
    // 0x1278a74: DecompressPointer r3
    //     0x1278a74: add             x3, x3, HEAP, lsl #32
    // 0x1278a78: r4 = LoadClassIdInstr(r0)
    //     0x1278a78: ldur            x4, [x0, #-1]
    //     0x1278a7c: ubfx            x4, x4, #0xc, #0x14
    // 0x1278a80: stp             x3, x0, [SP]
    // 0x1278a84: mov             x0, x4
    // 0x1278a88: mov             lr, x0
    // 0x1278a8c: ldr             lr, [x21, lr, lsl #3]
    // 0x1278a90: blr             lr
    // 0x1278a94: tbnz            w0, #4, #0x1278bc8
    // 0x1278a98: ldr             x2, [fp, #0x18]
    // 0x1278a9c: ldr             x1, [fp, #0x10]
    // 0x1278aa0: LoadField: r0 = r1->field_1f
    //     0x1278aa0: ldur            w0, [x1, #0x1f]
    // 0x1278aa4: DecompressPointer r0
    //     0x1278aa4: add             x0, x0, HEAP, lsl #32
    // 0x1278aa8: LoadField: r3 = r2->field_1f
    //     0x1278aa8: ldur            w3, [x2, #0x1f]
    // 0x1278aac: DecompressPointer r3
    //     0x1278aac: add             x3, x3, HEAP, lsl #32
    // 0x1278ab0: r4 = LoadClassIdInstr(r0)
    //     0x1278ab0: ldur            x4, [x0, #-1]
    //     0x1278ab4: ubfx            x4, x4, #0xc, #0x14
    // 0x1278ab8: stp             x3, x0, [SP]
    // 0x1278abc: mov             x0, x4
    // 0x1278ac0: mov             lr, x0
    // 0x1278ac4: ldr             lr, [x21, lr, lsl #3]
    // 0x1278ac8: blr             lr
    // 0x1278acc: tbnz            w0, #4, #0x1278bc8
    // 0x1278ad0: ldr             x2, [fp, #0x18]
    // 0x1278ad4: ldr             x1, [fp, #0x10]
    // 0x1278ad8: LoadField: r0 = r1->field_23
    //     0x1278ad8: ldur            w0, [x1, #0x23]
    // 0x1278adc: DecompressPointer r0
    //     0x1278adc: add             x0, x0, HEAP, lsl #32
    // 0x1278ae0: LoadField: r3 = r2->field_23
    //     0x1278ae0: ldur            w3, [x2, #0x23]
    // 0x1278ae4: DecompressPointer r3
    //     0x1278ae4: add             x3, x3, HEAP, lsl #32
    // 0x1278ae8: cmp             w0, w3
    // 0x1278aec: b.ne            #0x1278bc8
    // 0x1278af0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1278af0: ldur            w0, [x1, #0x17]
    // 0x1278af4: DecompressPointer r0
    //     0x1278af4: add             x0, x0, HEAP, lsl #32
    // 0x1278af8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1278af8: ldur            w3, [x2, #0x17]
    // 0x1278afc: DecompressPointer r3
    //     0x1278afc: add             x3, x3, HEAP, lsl #32
    // 0x1278b00: stur            x3, [fp, #-8]
    // 0x1278b04: r4 = LoadClassIdInstr(r0)
    //     0x1278b04: ldur            x4, [x0, #-1]
    //     0x1278b08: ubfx            x4, x4, #0xc, #0x14
    // 0x1278b0c: stp             x3, x0, [SP]
    // 0x1278b10: mov             x0, x4
    // 0x1278b14: mov             lr, x0
    // 0x1278b18: ldr             lr, [x21, lr, lsl #3]
    // 0x1278b1c: blr             lr
    // 0x1278b20: tbnz            w0, #4, #0x1278bc8
    // 0x1278b24: ldr             x2, [fp, #0x18]
    // 0x1278b28: ldr             x1, [fp, #0x10]
    // 0x1278b2c: LoadField: r0 = r1->field_27
    //     0x1278b2c: ldur            w0, [x1, #0x27]
    // 0x1278b30: DecompressPointer r0
    //     0x1278b30: add             x0, x0, HEAP, lsl #32
    // 0x1278b34: LoadField: r3 = r2->field_27
    //     0x1278b34: ldur            w3, [x2, #0x27]
    // 0x1278b38: DecompressPointer r3
    //     0x1278b38: add             x3, x3, HEAP, lsl #32
    // 0x1278b3c: r4 = LoadClassIdInstr(r0)
    //     0x1278b3c: ldur            x4, [x0, #-1]
    //     0x1278b40: ubfx            x4, x4, #0xc, #0x14
    // 0x1278b44: stp             x3, x0, [SP]
    // 0x1278b48: mov             x0, x4
    // 0x1278b4c: mov             lr, x0
    // 0x1278b50: ldr             lr, [x21, lr, lsl #3]
    // 0x1278b54: blr             lr
    // 0x1278b58: tbnz            w0, #4, #0x1278bc8
    // 0x1278b5c: ldr             x1, [fp, #0x18]
    // 0x1278b60: ldr             x0, [fp, #0x10]
    // 0x1278b64: LoadField: r2 = r0->field_2b
    //     0x1278b64: ldur            w2, [x0, #0x2b]
    // 0x1278b68: DecompressPointer r2
    //     0x1278b68: add             x2, x2, HEAP, lsl #32
    // 0x1278b6c: LoadField: r3 = r1->field_2b
    //     0x1278b6c: ldur            w3, [x1, #0x2b]
    // 0x1278b70: DecompressPointer r3
    //     0x1278b70: add             x3, x3, HEAP, lsl #32
    // 0x1278b74: cmp             w2, w3
    // 0x1278b78: b.ne            #0x1278bc8
    // 0x1278b7c: ldur            x2, [fp, #-8]
    // 0x1278b80: cmp             w2, NULL
    // 0x1278b84: b.eq            #0x1278ba0
    // 0x1278b88: LoadField: r2 = r1->field_1b
    //     0x1278b88: ldur            w2, [x1, #0x1b]
    // 0x1278b8c: DecompressPointer r2
    //     0x1278b8c: add             x2, x2, HEAP, lsl #32
    // 0x1278b90: LoadField: r3 = r0->field_1b
    //     0x1278b90: ldur            w3, [x0, #0x1b]
    // 0x1278b94: DecompressPointer r3
    //     0x1278b94: add             x3, x3, HEAP, lsl #32
    // 0x1278b98: cmp             w2, w3
    // 0x1278b9c: b.ne            #0x1278bc8
    // 0x1278ba0: LoadField: r2 = r0->field_b
    //     0x1278ba0: ldur            w2, [x0, #0xb]
    // 0x1278ba4: DecompressPointer r2
    //     0x1278ba4: add             x2, x2, HEAP, lsl #32
    // 0x1278ba8: LoadField: r0 = r1->field_b
    //     0x1278ba8: ldur            w0, [x1, #0xb]
    // 0x1278bac: DecompressPointer r0
    //     0x1278bac: add             x0, x0, HEAP, lsl #32
    // 0x1278bb0: r16 = <String>
    //     0x1278bb0: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x1278bb4: stp             x2, x16, [SP, #8]
    // 0x1278bb8: str             x0, [SP]
    // 0x1278bbc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1278bbc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1278bc0: r0 = listEquals()
    //     0x1278bc0: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1278bc4: b               #0x1278bcc
    // 0x1278bc8: r0 = false
    //     0x1278bc8: add             x0, NULL, #0x30  ; false
    // 0x1278bcc: LeaveFrame
    //     0x1278bcc: mov             SP, fp
    //     0x1278bd0: ldp             fp, lr, [SP], #0x10
    // 0x1278bd4: ret
    //     0x1278bd4: ret             
    // 0x1278bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1278bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1278bdc: b               #0x1278998
  }
}
