// lib: , url: package:flutter/src/painting/text_scaler.dart

// class id: 1049011, size: 0x8
class :: {
}

// class id: 2895, size: 0x1c, field offset: 0x8
//   const constructor, 
class _ClampedTextScaler extends Object
    implements TextScaler {

  _ ==(/* No info */) {
    // ** addr: 0x1299978, size: 0xa8
    // 0x1299978: ldr             x1, [SP]
    // 0x129997c: cmp             w1, NULL
    // 0x1299980: b.ne            #0x129998c
    // 0x1299984: r0 = false
    //     0x1299984: add             x0, NULL, #0x30  ; false
    // 0x1299988: ret
    //     0x1299988: ret             
    // 0x129998c: ldr             x2, [SP, #8]
    // 0x1299990: cmp             w2, w1
    // 0x1299994: b.ne            #0x12999a0
    // 0x1299998: r0 = true
    //     0x1299998: add             x0, NULL, #0x20  ; true
    // 0x129999c: ret
    //     0x129999c: ret             
    // 0x12999a0: r3 = 60
    //     0x12999a0: mov             x3, #0x3c
    // 0x12999a4: branchIfSmi(r1, 0x12999b0)
    //     0x12999a4: tbz             w1, #0, #0x12999b0
    // 0x12999a8: r3 = LoadClassIdInstr(r1)
    //     0x12999a8: ldur            x3, [x1, #-1]
    //     0x12999ac: ubfx            x3, x3, #0xc, #0x14
    // 0x12999b0: cmp             x3, #0xb4f
    // 0x12999b4: b.ne            #0x1299a18
    // 0x12999b8: LoadField: d0 = r2->field_b
    //     0x12999b8: ldur            d0, [x2, #0xb]
    // 0x12999bc: LoadField: d1 = r1->field_b
    //     0x12999bc: ldur            d1, [x1, #0xb]
    // 0x12999c0: fcmp            d0, d1
    // 0x12999c4: b.ne            #0x1299a18
    // 0x12999c8: LoadField: d0 = r2->field_13
    //     0x12999c8: ldur            d0, [x2, #0x13]
    // 0x12999cc: LoadField: d1 = r1->field_13
    //     0x12999cc: ldur            d1, [x1, #0x13]
    // 0x12999d0: fcmp            d0, d1
    // 0x12999d4: b.ne            #0x1299a18
    // 0x12999d8: LoadField: r3 = r2->field_7
    //     0x12999d8: ldur            w3, [x2, #7]
    // 0x12999dc: DecompressPointer r3
    //     0x12999dc: add             x3, x3, HEAP, lsl #32
    // 0x12999e0: LoadField: r2 = r1->field_7
    //     0x12999e0: ldur            w2, [x1, #7]
    // 0x12999e4: DecompressPointer r2
    //     0x12999e4: add             x2, x2, HEAP, lsl #32
    // 0x12999e8: cmp             w3, w2
    // 0x12999ec: b.ne            #0x12999f8
    // 0x12999f0: r1 = true
    //     0x12999f0: add             x1, NULL, #0x20  ; true
    // 0x12999f4: b               #0x1299a10
    // 0x12999f8: LoadField: d0 = r2->field_b
    //     0x12999f8: ldur            d0, [x2, #0xb]
    // 0x12999fc: LoadField: d1 = r3->field_b
    //     0x12999fc: ldur            d1, [x3, #0xb]
    // 0x1299a00: fcmp            d1, d0
    // 0x1299a04: r16 = true
    //     0x1299a04: add             x16, NULL, #0x20  ; true
    // 0x1299a08: r17 = false
    //     0x1299a08: add             x17, NULL, #0x30  ; false
    // 0x1299a0c: csel            x1, x16, x17, eq
    // 0x1299a10: mov             x0, x1
    // 0x1299a14: b               #0x1299a1c
    // 0x1299a18: r0 = false
    //     0x1299a18: add             x0, NULL, #0x30  ; false
    // 0x1299a1c: ret
    //     0x1299a1c: ret             
  }
  get _ textScaleFactor(/* No info */) {
    // ** addr: 0x12f5950, size: 0x4c
    // 0x12f5950: LoadField: r0 = r1->field_7
    //     0x12f5950: ldur            w0, [x1, #7]
    // 0x12f5954: DecompressPointer r0
    //     0x12f5954: add             x0, x0, HEAP, lsl #32
    // 0x12f5958: LoadField: d1 = r0->field_b
    //     0x12f5958: ldur            d1, [x0, #0xb]
    // 0x12f595c: LoadField: d2 = r1->field_b
    //     0x12f595c: ldur            d2, [x1, #0xb]
    // 0x12f5960: LoadField: d3 = r1->field_13
    //     0x12f5960: ldur            d3, [x1, #0x13]
    // 0x12f5964: fcmp            d2, d1
    // 0x12f5968: b.le            #0x12f5974
    // 0x12f596c: mov             v0.16b, v2.16b
    // 0x12f5970: b               #0x12f5998
    // 0x12f5974: fcmp            d1, d3
    // 0x12f5978: b.le            #0x12f5984
    // 0x12f597c: mov             v0.16b, v3.16b
    // 0x12f5980: b               #0x12f5998
    // 0x12f5984: fcmp            d1, d1
    // 0x12f5988: b.vc            #0x12f5994
    // 0x12f598c: mov             v0.16b, v3.16b
    // 0x12f5990: b               #0x12f5998
    // 0x12f5994: mov             v0.16b, v1.16b
    // 0x12f5998: ret
    //     0x12f5998: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0x1307574, size: 0xdc
    // 0x1307574: EnterFrame
    //     0x1307574: stp             fp, lr, [SP, #-0x10]!
    //     0x1307578: mov             fp, SP
    // 0x130757c: AllocStack(0x20)
    //     0x130757c: sub             SP, SP, #0x20
    // 0x1307580: SetupParameters({_Double minScaleFactor = 0.000000 /* d1 */})
    //     0x1307580: ldur            w0, [x4, #0x13]
    //     0x1307584: ldur            w2, [x4, #0x1f]
    //     0x1307588: add             x2, x2, HEAP, lsl #32
    //     0x130758c: add             x16, PP, #0x90, lsl #12  ; [pp+0x90d88] "minScaleFactor"
    //     0x1307590: ldr             x16, [x16, #0xd88]
    //     0x1307594: cmp             w2, w16
    //     0x1307598: b.ne            #0x13075b8
    //     0x130759c: ldur            w2, [x4, #0x23]
    //     0x13075a0: add             x2, x2, HEAP, lsl #32
    //     0x13075a4: sub             w3, w0, w2
    //     0x13075a8: add             x0, fp, w3, sxtw #2
    //     0x13075ac: ldr             x0, [x0, #8]
    //     0x13075b0: ldur            d1, [x0, #7]
    //     0x13075b4: b               #0x13075bc
    //     0x13075b8: eor             v1.16b, v1.16b, v1.16b
    // 0x13075bc: LoadField: d2 = r1->field_b
    //     0x13075bc: ldur            d2, [x1, #0xb]
    // 0x13075c0: fmax            v3.2d, v2.2d, v1.2d
    // 0x13075c4: stur            d3, [fp, #-0x20]
    // 0x13075c8: LoadField: d4 = r1->field_13
    //     0x13075c8: ldur            d4, [x1, #0x13]
    // 0x13075cc: fmin            v5.2d, v4.2d, v0.2d
    // 0x13075d0: stur            d5, [fp, #-0x18]
    // 0x13075d4: fcmp            d3, d5
    // 0x13075d8: b.lt            #0x130761c
    // 0x13075dc: fcmp            d1, d2
    // 0x13075e0: b.le            #0x13075ec
    // 0x13075e4: mov             v0.16b, v1.16b
    // 0x13075e8: b               #0x1307600
    // 0x13075ec: fcmp            d2, d0
    // 0x13075f0: b.gt            #0x1307600
    // 0x13075f4: fcmp            d2, d2
    // 0x13075f8: b.vs            #0x1307600
    // 0x13075fc: mov             v0.16b, v2.16b
    // 0x1307600: stur            d0, [fp, #-0x10]
    // 0x1307604: r0 = _LinearTextScaler()
    //     0x1307604: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0x1307608: ldur            d0, [fp, #-0x10]
    // 0x130760c: StoreField: r0->field_7 = d0
    //     0x130760c: stur            d0, [x0, #7]
    // 0x1307610: LeaveFrame
    //     0x1307610: mov             SP, fp
    //     0x1307614: ldp             fp, lr, [SP], #0x10
    // 0x1307618: ret
    //     0x1307618: ret             
    // 0x130761c: LoadField: r0 = r1->field_7
    //     0x130761c: ldur            w0, [x1, #7]
    // 0x1307620: DecompressPointer r0
    //     0x1307620: add             x0, x0, HEAP, lsl #32
    // 0x1307624: stur            x0, [fp, #-8]
    // 0x1307628: r0 = _ClampedTextScaler()
    //     0x1307628: bl              #0x13074cc  ; Allocate_ClampedTextScalerStub -> _ClampedTextScaler (size=0x1c)
    // 0x130762c: ldur            x1, [fp, #-8]
    // 0x1307630: StoreField: r0->field_7 = r1
    //     0x1307630: stur            w1, [x0, #7]
    // 0x1307634: ldur            d0, [fp, #-0x20]
    // 0x1307638: StoreField: r0->field_b = d0
    //     0x1307638: stur            d0, [x0, #0xb]
    // 0x130763c: ldur            d0, [fp, #-0x18]
    // 0x1307640: StoreField: r0->field_13 = d0
    //     0x1307640: stur            d0, [x0, #0x13]
    // 0x1307644: LeaveFrame
    //     0x1307644: mov             SP, fp
    //     0x1307648: ldp             fp, lr, [SP], #0x10
    // 0x130764c: ret
    //     0x130764c: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0x1307ba0, size: 0xd0
    // 0x1307ba0: EnterFrame
    //     0x1307ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x1307ba4: mov             fp, SP
    // 0x1307ba8: AllocStack(0x10)
    //     0x1307ba8: sub             SP, SP, #0x10
    // 0x1307bac: SetupParameters(_ClampedTextScaler this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x10 */)
    //     0x1307bac: mov             x0, x1
    //     0x1307bb0: mov             v1.16b, v0.16b
    //     0x1307bb4: stur            x1, [fp, #-8]
    //     0x1307bb8: stur            d0, [fp, #-0x10]
    // 0x1307bbc: CheckStackOverflow
    //     0x1307bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1307bc0: cmp             SP, x16
    //     0x1307bc4: b.ls            #0x1307c58
    // 0x1307bc8: LoadField: r1 = r0->field_7
    //     0x1307bc8: ldur            w1, [x0, #7]
    // 0x1307bcc: DecompressPointer r1
    //     0x1307bcc: add             x1, x1, HEAP, lsl #32
    // 0x1307bd0: mov             v0.16b, v1.16b
    // 0x1307bd4: r0 = scale()
    //     0x1307bd4: bl              #0x1307650  ; [package:flutter/src/widgets/media_query.dart] SystemTextScaler::scale
    // 0x1307bd8: ldur            x1, [fp, #-8]
    // 0x1307bdc: LoadField: d0 = r1->field_b
    //     0x1307bdc: ldur            d0, [x1, #0xb]
    // 0x1307be0: ldur            d1, [fp, #-0x10]
    // 0x1307be4: fmul            d2, d0, d1
    // 0x1307be8: LoadField: d0 = r1->field_13
    //     0x1307be8: ldur            d0, [x1, #0x13]
    // 0x1307bec: fmul            d3, d0, d1
    // 0x1307bf0: LoadField: d0 = r0->field_7
    //     0x1307bf0: ldur            d0, [x0, #7]
    // 0x1307bf4: fcmp            d2, d0
    // 0x1307bf8: b.le            #0x1307c04
    // 0x1307bfc: mov             v0.16b, v2.16b
    // 0x1307c00: b               #0x1307c20
    // 0x1307c04: fcmp            d0, d3
    // 0x1307c08: b.le            #0x1307c14
    // 0x1307c0c: mov             v0.16b, v3.16b
    // 0x1307c10: b               #0x1307c20
    // 0x1307c14: fcmp            d0, d0
    // 0x1307c18: b.vc            #0x1307c20
    // 0x1307c1c: mov             v0.16b, v3.16b
    // 0x1307c20: r0 = inline_Allocate_Double()
    //     0x1307c20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1307c24: add             x0, x0, #0x10
    //     0x1307c28: cmp             x1, x0
    //     0x1307c2c: b.ls            #0x1307c60
    //     0x1307c30: str             x0, [THR, #0x60]  ; THR::top
    //     0x1307c34: sub             x0, x0, #0xf
    //     0x1307c38: mov             x1, #0xe19c
    //     0x1307c3c: movk            x1, #3, lsl #16
    //     0x1307c40: stur            x1, [x0, #-1]
    // 0x1307c44: dmb             ishst
    // 0x1307c48: StoreField: r0->field_7 = d0
    //     0x1307c48: stur            d0, [x0, #7]
    // 0x1307c4c: LeaveFrame
    //     0x1307c4c: mov             SP, fp
    //     0x1307c50: ldp             fp, lr, [SP], #0x10
    // 0x1307c54: ret
    //     0x1307c54: ret             
    // 0x1307c58: r0 = StackOverflowSharedWithFPURegs()
    //     0x1307c58: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1307c5c: b               #0x1307bc8
    // 0x1307c60: SaveReg d0
    //     0x1307c60: str             q0, [SP, #-0x10]!
    // 0x1307c64: r0 = AllocateDouble()
    //     0x1307c64: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1307c68: RestoreReg d0
    //     0x1307c68: ldr             q0, [SP], #0x10
    // 0x1307c6c: b               #0x1307c48
  }
}

// class id: 2896, size: 0x10, field offset: 0x8
//   const constructor, 
class _LinearTextScaler extends Object
    implements TextScaler {

  _Double field_8;

  _ ==(/* No info */) {
    // ** addr: 0x1299910, size: 0x68
    // 0x1299910: ldr             x1, [SP]
    // 0x1299914: cmp             w1, NULL
    // 0x1299918: b.ne            #0x1299924
    // 0x129991c: r0 = false
    //     0x129991c: add             x0, NULL, #0x30  ; false
    // 0x1299920: ret
    //     0x1299920: ret             
    // 0x1299924: ldr             x2, [SP, #8]
    // 0x1299928: cmp             w2, w1
    // 0x129992c: b.ne            #0x1299938
    // 0x1299930: r0 = true
    //     0x1299930: add             x0, NULL, #0x20  ; true
    // 0x1299934: ret
    //     0x1299934: ret             
    // 0x1299938: r3 = 60
    //     0x1299938: mov             x3, #0x3c
    // 0x129993c: branchIfSmi(r1, 0x1299948)
    //     0x129993c: tbz             w1, #0, #0x1299948
    // 0x1299940: r3 = LoadClassIdInstr(r1)
    //     0x1299940: ldur            x3, [x1, #-1]
    //     0x1299944: ubfx            x3, x3, #0xc, #0x14
    // 0x1299948: cmp             x3, #0xb50
    // 0x129994c: b.ne            #0x1299970
    // 0x1299950: LoadField: d0 = r1->field_7
    //     0x1299950: ldur            d0, [x1, #7]
    // 0x1299954: LoadField: d1 = r2->field_7
    //     0x1299954: ldur            d1, [x2, #7]
    // 0x1299958: fcmp            d0, d1
    // 0x129995c: r16 = true
    //     0x129995c: add             x16, NULL, #0x20  ; true
    // 0x1299960: r17 = false
    //     0x1299960: add             x17, NULL, #0x30  ; false
    // 0x1299964: csel            x1, x16, x17, eq
    // 0x1299968: mov             x0, x1
    // 0x129996c: b               #0x1299974
    // 0x1299970: r0 = false
    //     0x1299970: add             x0, NULL, #0x30  ; false
    // 0x1299974: ret
    //     0x1299974: ret             
  }
  const get _ textScaleFactor(/* No info */) {
    // ** addr: 0x12f5948, size: 0x8
    // 0x12f5948: LoadField: d0 = r1->field_7
    //     0x12f5948: ldur            d0, [x1, #7]
    // 0x12f594c: ret
    //     0x12f594c: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0x13074d8, size: 0x9c
    // 0x13074d8: EnterFrame
    //     0x13074d8: stp             fp, lr, [SP, #-0x10]!
    //     0x13074dc: mov             fp, SP
    // 0x13074e0: AllocStack(0x8)
    //     0x13074e0: sub             SP, SP, #8
    // 0x13074e4: SetupParameters({_Double minScaleFactor = 0.000000 /* d1 */})
    //     0x13074e4: ldur            w0, [x4, #0x13]
    //     0x13074e8: ldur            w2, [x4, #0x1f]
    //     0x13074ec: add             x2, x2, HEAP, lsl #32
    //     0x13074f0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90d88] "minScaleFactor"
    //     0x13074f4: ldr             x16, [x16, #0xd88]
    //     0x13074f8: cmp             w2, w16
    //     0x13074fc: b.ne            #0x130751c
    //     0x1307500: ldur            w2, [x4, #0x23]
    //     0x1307504: add             x2, x2, HEAP, lsl #32
    //     0x1307508: sub             w3, w0, w2
    //     0x130750c: add             x0, fp, w3, sxtw #2
    //     0x1307510: ldr             x0, [x0, #8]
    //     0x1307514: ldur            d1, [x0, #7]
    //     0x1307518: b               #0x1307520
    //     0x130751c: eor             v1.16b, v1.16b, v1.16b
    // 0x1307520: LoadField: d2 = r1->field_7
    //     0x1307520: ldur            d2, [x1, #7]
    // 0x1307524: fcmp            d1, d2
    // 0x1307528: b.le            #0x1307534
    // 0x130752c: mov             v0.16b, v1.16b
    // 0x1307530: b               #0x1307548
    // 0x1307534: fcmp            d2, d0
    // 0x1307538: b.gt            #0x1307548
    // 0x130753c: fcmp            d2, d2
    // 0x1307540: b.vs            #0x1307548
    // 0x1307544: mov             v0.16b, v2.16b
    // 0x1307548: stur            d0, [fp, #-8]
    // 0x130754c: fcmp            d0, d2
    // 0x1307550: b.ne            #0x130755c
    // 0x1307554: mov             x0, x1
    // 0x1307558: b               #0x1307568
    // 0x130755c: r0 = _LinearTextScaler()
    //     0x130755c: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0x1307560: ldur            d0, [fp, #-8]
    // 0x1307564: StoreField: r0->field_7 = d0
    //     0x1307564: stur            d0, [x0, #7]
    // 0x1307568: LeaveFrame
    //     0x1307568: mov             SP, fp
    //     0x130756c: ldp             fp, lr, [SP], #0x10
    // 0x1307570: ret
    //     0x1307570: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0x1307b48, size: 0x58
    // 0x1307b48: EnterFrame
    //     0x1307b48: stp             fp, lr, [SP, #-0x10]!
    //     0x1307b4c: mov             fp, SP
    // 0x1307b50: LoadField: d1 = r1->field_7
    //     0x1307b50: ldur            d1, [x1, #7]
    // 0x1307b54: fmul            d2, d0, d1
    // 0x1307b58: r0 = inline_Allocate_Double()
    //     0x1307b58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1307b5c: add             x0, x0, #0x10
    //     0x1307b60: cmp             x1, x0
    //     0x1307b64: b.ls            #0x1307b90
    //     0x1307b68: str             x0, [THR, #0x60]  ; THR::top
    //     0x1307b6c: sub             x0, x0, #0xf
    //     0x1307b70: mov             x1, #0xe19c
    //     0x1307b74: movk            x1, #3, lsl #16
    //     0x1307b78: stur            x1, [x0, #-1]
    // 0x1307b7c: dmb             ishst
    // 0x1307b80: StoreField: r0->field_7 = d2
    //     0x1307b80: stur            d2, [x0, #7]
    // 0x1307b84: LeaveFrame
    //     0x1307b84: mov             SP, fp
    //     0x1307b88: ldp             fp, lr, [SP], #0x10
    // 0x1307b8c: ret
    //     0x1307b8c: ret             
    // 0x1307b90: SaveReg d2
    //     0x1307b90: str             q2, [SP, #-0x10]!
    // 0x1307b94: r0 = AllocateDouble()
    //     0x1307b94: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1307b98: RestoreReg d2
    //     0x1307b98: ldr             q2, [SP], #0x10
    // 0x1307b9c: b               #0x1307b80
  }
}

// class id: 2897, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TextScaler extends Object {

  _ clamp(/* No info */) {
    // ** addr: 0x1307408, size: 0xc4
    // 0x1307408: EnterFrame
    //     0x1307408: stp             fp, lr, [SP, #-0x10]!
    //     0x130740c: mov             fp, SP
    // 0x1307410: AllocStack(0x18)
    //     0x1307410: sub             SP, SP, #0x18
    // 0x1307414: SetupParameters(TextScaler this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */, {_Double minScaleFactor = 0.000000 /* d2 */})
    //     0x1307414: mov             x0, x1
    //     0x1307418: stur            x1, [fp, #-8]
    //     0x130741c: stur            d0, [fp, #-0x18]
    //     0x1307420: ldur            w1, [x4, #0x13]
    //     0x1307424: ldur            w2, [x4, #0x1f]
    //     0x1307428: add             x2, x2, HEAP, lsl #32
    //     0x130742c: add             x16, PP, #0x90, lsl #12  ; [pp+0x90d88] "minScaleFactor"
    //     0x1307430: ldr             x16, [x16, #0xd88]
    //     0x1307434: cmp             w2, w16
    //     0x1307438: b.ne            #0x130745c
    //     0x130743c: ldur            w2, [x4, #0x23]
    //     0x1307440: add             x2, x2, HEAP, lsl #32
    //     0x1307444: sub             w3, w1, w2
    //     0x1307448: add             x1, fp, w3, sxtw #2
    //     0x130744c: ldr             x1, [x1, #8]
    //     0x1307450: ldur            d1, [x1, #7]
    //     0x1307454: mov             v2.16b, v1.16b
    //     0x1307458: b               #0x1307460
    //     0x130745c: eor             v2.16b, v2.16b, v2.16b
    // 0x1307460: d1 = 0.000000
    //     0x1307460: eor             v1.16b, v1.16b, v1.16b
    // 0x1307464: stur            d2, [fp, #-0x10]
    // 0x1307468: fcmp            d2, d1
    // 0x130746c: b.ne            #0x1307488
    // 0x1307470: d1 = inf
    //     0x1307470: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x1307474: fcmp            d0, d1
    // 0x1307478: b.ne            #0x1307488
    // 0x130747c: LeaveFrame
    //     0x130747c: mov             SP, fp
    //     0x1307480: ldp             fp, lr, [SP], #0x10
    // 0x1307484: ret
    //     0x1307484: ret             
    // 0x1307488: fcmp            d2, d0
    // 0x130748c: b.ne            #0x13074a0
    // 0x1307490: r0 = _LinearTextScaler()
    //     0x1307490: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0x1307494: ldur            d1, [fp, #-0x10]
    // 0x1307498: StoreField: r0->field_7 = d1
    //     0x1307498: stur            d1, [x0, #7]
    // 0x130749c: b               #0x13074c0
    // 0x13074a0: mov             v1.16b, v2.16b
    // 0x13074a4: r0 = _ClampedTextScaler()
    //     0x13074a4: bl              #0x13074cc  ; Allocate_ClampedTextScalerStub -> _ClampedTextScaler (size=0x1c)
    // 0x13074a8: ldur            x1, [fp, #-8]
    // 0x13074ac: StoreField: r0->field_7 = r1
    //     0x13074ac: stur            w1, [x0, #7]
    // 0x13074b0: ldur            d0, [fp, #-0x10]
    // 0x13074b4: StoreField: r0->field_b = d0
    //     0x13074b4: stur            d0, [x0, #0xb]
    // 0x13074b8: ldur            d0, [fp, #-0x18]
    // 0x13074bc: StoreField: r0->field_13 = d0
    //     0x13074bc: stur            d0, [x0, #0x13]
    // 0x13074c0: LeaveFrame
    //     0x13074c0: mov             SP, fp
    //     0x13074c4: ldp             fp, lr, [SP], #0x10
    // 0x13074c8: ret
    //     0x13074c8: ret             
  }
}
