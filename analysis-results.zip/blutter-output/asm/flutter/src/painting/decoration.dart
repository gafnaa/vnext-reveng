// lib: , url: package:flutter/src/painting/decoration.dart

// class id: 1048991, size: 0x8
class :: {
}

// class id: 3256, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class BoxPainter extends Object {
}

// class id: 5236, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Decoration extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x115f65c, size: 0x700
    // 0x115f65c: EnterFrame
    //     0x115f65c: stp             fp, lr, [SP, #-0x10]!
    //     0x115f660: mov             fp, SP
    // 0x115f664: AllocStack(0x30)
    //     0x115f664: sub             SP, SP, #0x30
    // 0x115f668: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x115f668: mov             x3, x1
    //     0x115f66c: mov             x0, x2
    //     0x115f670: stur            x2, [fp, #-8]
    //     0x115f674: stur            x1, [fp, #-0x10]
    //     0x115f678: stur            d0, [fp, #-0x30]
    // 0x115f67c: CheckStackOverflow
    //     0x115f67c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115f680: cmp             SP, x16
    //     0x115f684: b.ls            #0x115fcec
    // 0x115f688: cmp             w3, w0
    // 0x115f68c: b.ne            #0x115f6a0
    // 0x115f690: mov             x0, x3
    // 0x115f694: LeaveFrame
    //     0x115f694: mov             SP, fp
    //     0x115f698: ldp             fp, lr, [SP], #0x10
    // 0x115f69c: ret
    //     0x115f69c: ret             
    // 0x115f6a0: cmp             w3, NULL
    // 0x115f6a4: b.ne            #0x115f72c
    // 0x115f6a8: cmp             w0, NULL
    // 0x115f6ac: b.eq            #0x115fcf4
    // 0x115f6b0: r1 = LoadClassIdInstr(r0)
    //     0x115f6b0: ldur            x1, [x0, #-1]
    //     0x115f6b4: ubfx            x1, x1, #0xc, #0x14
    // 0x115f6b8: r17 = 5237
    //     0x115f6b8: mov             x17, #0x1475
    // 0x115f6bc: cmp             x1, x17
    // 0x115f6c0: b.ne            #0x115f6d4
    // 0x115f6c4: mov             x2, x0
    // 0x115f6c8: r1 = Null
    //     0x115f6c8: mov             x1, NULL
    // 0x115f6cc: r0 = lerp()
    //     0x115f6cc: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115f6d0: b               #0x115f714
    // 0x115f6d4: r17 = 5238
    //     0x115f6d4: mov             x17, #0x1476
    // 0x115f6d8: cmp             x1, x17
    // 0x115f6dc: b.ne            #0x115f6ec
    // 0x115f6e0: ldur            x1, [fp, #-8]
    // 0x115f6e4: r0 = scale()
    //     0x115f6e4: bl              #0x11637d0  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0x115f6e8: b               #0x115f714
    // 0x115f6ec: r17 = 5239
    //     0x115f6ec: mov             x17, #0x1477
    // 0x115f6f0: cmp             x1, x17
    // 0x115f6f4: b.ne            #0x115f700
    // 0x115f6f8: r0 = Null
    //     0x115f6f8: mov             x0, NULL
    // 0x115f6fc: b               #0x115f714
    // 0x115f700: ldur            x2, [fp, #-8]
    // 0x115f704: r1 = Null
    //     0x115f704: mov             x1, NULL
    // 0x115f708: r0 = lerp()
    //     0x115f708: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115f70c: cmp             w0, NULL
    // 0x115f710: b.eq            #0x115fcf8
    // 0x115f714: cmp             w0, NULL
    // 0x115f718: b.ne            #0x115f720
    // 0x115f71c: ldur            x0, [fp, #-8]
    // 0x115f720: LeaveFrame
    //     0x115f720: mov             SP, fp
    //     0x115f724: ldp             fp, lr, [SP], #0x10
    // 0x115f728: ret
    //     0x115f728: ret             
    // 0x115f72c: cmp             w0, NULL
    // 0x115f730: b.ne            #0x115f7b4
    // 0x115f734: r0 = LoadClassIdInstr(r3)
    //     0x115f734: ldur            x0, [x3, #-1]
    //     0x115f738: ubfx            x0, x0, #0xc, #0x14
    // 0x115f73c: r17 = 5237
    //     0x115f73c: mov             x17, #0x1475
    // 0x115f740: cmp             x0, x17
    // 0x115f744: b.ne            #0x115f758
    // 0x115f748: mov             x1, x3
    // 0x115f74c: r2 = Null
    //     0x115f74c: mov             x2, NULL
    // 0x115f750: r0 = lerp()
    //     0x115f750: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115f754: b               #0x115f79c
    // 0x115f758: r17 = 5238
    //     0x115f758: mov             x17, #0x1476
    // 0x115f75c: cmp             x0, x17
    // 0x115f760: b.ne            #0x115f77c
    // 0x115f764: d1 = 1.000000
    //     0x115f764: fmov            d1, #1.00000000
    // 0x115f768: fsub            d2, d1, d0
    // 0x115f76c: ldur            x1, [fp, #-0x10]
    // 0x115f770: mov             v0.16b, v2.16b
    // 0x115f774: r0 = scale()
    //     0x115f774: bl              #0x11637d0  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0x115f778: b               #0x115f79c
    // 0x115f77c: r17 = 5239
    //     0x115f77c: mov             x17, #0x1477
    // 0x115f780: cmp             x0, x17
    // 0x115f784: b.ne            #0x115f790
    // 0x115f788: r0 = Null
    //     0x115f788: mov             x0, NULL
    // 0x115f78c: b               #0x115f79c
    // 0x115f790: ldur            x1, [fp, #-0x10]
    // 0x115f794: r2 = Null
    //     0x115f794: mov             x2, NULL
    // 0x115f798: r0 = lerp()
    //     0x115f798: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115f79c: cmp             w0, NULL
    // 0x115f7a0: b.ne            #0x115f7a8
    // 0x115f7a4: ldur            x0, [fp, #-0x10]
    // 0x115f7a8: LeaveFrame
    //     0x115f7a8: mov             SP, fp
    //     0x115f7ac: ldp             fp, lr, [SP], #0x10
    // 0x115f7b0: ret
    //     0x115f7b0: ret             
    // 0x115f7b4: d1 = 1.000000
    //     0x115f7b4: fmov            d1, #1.00000000
    // 0x115f7b8: d2 = 0.000000
    //     0x115f7b8: eor             v2.16b, v2.16b, v2.16b
    // 0x115f7bc: fcmp            d0, d2
    // 0x115f7c0: b.ne            #0x115f7d4
    // 0x115f7c4: ldur            x0, [fp, #-0x10]
    // 0x115f7c8: LeaveFrame
    //     0x115f7c8: mov             SP, fp
    //     0x115f7cc: ldp             fp, lr, [SP], #0x10
    // 0x115f7d0: ret
    //     0x115f7d0: ret             
    // 0x115f7d4: fcmp            d0, d1
    // 0x115f7d8: b.ne            #0x115f7e8
    // 0x115f7dc: LeaveFrame
    //     0x115f7dc: mov             SP, fp
    //     0x115f7e0: ldp             fp, lr, [SP], #0x10
    // 0x115f7e4: ret
    //     0x115f7e4: ret             
    // 0x115f7e8: r3 = LoadClassIdInstr(r0)
    //     0x115f7e8: ldur            x3, [x0, #-1]
    //     0x115f7ec: ubfx            x3, x3, #0xc, #0x14
    // 0x115f7f0: stur            x3, [fp, #-0x18]
    // 0x115f7f4: r17 = 5237
    //     0x115f7f4: mov             x17, #0x1475
    // 0x115f7f8: cmp             x3, x17
    // 0x115f7fc: b.ne            #0x115f890
    // 0x115f800: ldur            x4, [fp, #-0x10]
    // 0x115f804: r1 = LoadClassIdInstr(r4)
    //     0x115f804: ldur            x1, [x4, #-1]
    //     0x115f808: ubfx            x1, x1, #0xc, #0x14
    // 0x115f80c: r17 = 5238
    //     0x115f80c: mov             x17, #0x1476
    // 0x115f810: cmp             x1, x17
    // 0x115f814: b.ne            #0x115f838
    // 0x115f818: mov             x2, x4
    // 0x115f81c: r1 = Null
    //     0x115f81c: mov             x1, NULL
    // 0x115f820: r0 = ShapeDecoration.fromBoxDecoration()
    //     0x115f820: bl              #0x1163084  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::ShapeDecoration.fromBoxDecoration
    // 0x115f824: mov             x1, x0
    // 0x115f828: ldur            x2, [fp, #-8]
    // 0x115f82c: ldur            d0, [fp, #-0x30]
    // 0x115f830: r0 = lerp()
    //     0x115f830: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115f834: b               #0x115f9dc
    // 0x115f838: ldur            x0, [fp, #-0x10]
    // 0x115f83c: r2 = Null
    //     0x115f83c: mov             x2, NULL
    // 0x115f840: r1 = Null
    //     0x115f840: mov             x1, NULL
    // 0x115f844: cmp             w0, NULL
    // 0x115f848: b.eq            #0x115f86c
    // 0x115f84c: branchIfSmi(r0, 0x115f864)
    //     0x115f84c: tbz             w0, #0, #0x115f864
    // 0x115f850: r3 = LoadClassIdInstr(r0)
    //     0x115f850: ldur            x3, [x0, #-1]
    //     0x115f854: ubfx            x3, x3, #0xc, #0x14
    // 0x115f858: r17 = 5237
    //     0x115f858: mov             x17, #0x1475
    // 0x115f85c: cmp             x3, x17
    // 0x115f860: b.eq            #0x115f86c
    // 0x115f864: r0 = false
    //     0x115f864: add             x0, NULL, #0x30  ; false
    // 0x115f868: b               #0x115f870
    // 0x115f86c: r0 = true
    //     0x115f86c: add             x0, NULL, #0x20  ; true
    // 0x115f870: tbnz            w0, #4, #0x115f888
    // 0x115f874: ldur            x1, [fp, #-0x10]
    // 0x115f878: ldur            x2, [fp, #-8]
    // 0x115f87c: ldur            d0, [fp, #-0x30]
    // 0x115f880: r0 = lerp()
    //     0x115f880: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115f884: b               #0x115f9dc
    // 0x115f888: r0 = Null
    //     0x115f888: mov             x0, NULL
    // 0x115f88c: b               #0x115f9dc
    // 0x115f890: mov             x0, x3
    // 0x115f894: r17 = 5238
    //     0x115f894: mov             x17, #0x1476
    // 0x115f898: cmp             x0, x17
    // 0x115f89c: b.ne            #0x115f8d4
    // 0x115f8a0: ldur            x3, [fp, #-0x10]
    // 0x115f8a4: r1 = LoadClassIdInstr(r3)
    //     0x115f8a4: ldur            x1, [x3, #-1]
    //     0x115f8a8: ubfx            x1, x1, #0xc, #0x14
    // 0x115f8ac: r17 = 5238
    //     0x115f8ac: mov             x17, #0x1476
    // 0x115f8b0: cmp             x1, x17
    // 0x115f8b4: b.ne            #0x115f8cc
    // 0x115f8b8: mov             x1, x3
    // 0x115f8bc: ldur            x2, [fp, #-8]
    // 0x115f8c0: ldur            d0, [fp, #-0x30]
    // 0x115f8c4: r0 = lerp()
    //     0x115f8c4: bl              #0x115fd5c  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::lerp
    // 0x115f8c8: b               #0x115f9dc
    // 0x115f8cc: r0 = Null
    //     0x115f8cc: mov             x0, NULL
    // 0x115f8d0: b               #0x115f9dc
    // 0x115f8d4: r17 = 5239
    //     0x115f8d4: mov             x17, #0x1477
    // 0x115f8d8: cmp             x0, x17
    // 0x115f8dc: b.ne            #0x115f998
    // 0x115f8e0: ldur            x3, [fp, #-0x10]
    // 0x115f8e4: r1 = LoadClassIdInstr(r3)
    //     0x115f8e4: ldur            x1, [x3, #-1]
    //     0x115f8e8: ubfx            x1, x1, #0xc, #0x14
    // 0x115f8ec: r17 = 5239
    //     0x115f8ec: mov             x17, #0x1477
    // 0x115f8f0: cmp             x1, x17
    // 0x115f8f4: b.ne            #0x115f990
    // 0x115f8f8: ldur            x4, [fp, #-8]
    // 0x115f8fc: ldur            d1, [fp, #-0x30]
    // 0x115f900: LoadField: r1 = r3->field_b
    //     0x115f900: ldur            w1, [x3, #0xb]
    // 0x115f904: DecompressPointer r1
    //     0x115f904: add             x1, x1, HEAP, lsl #32
    // 0x115f908: LoadField: r2 = r4->field_b
    //     0x115f908: ldur            w2, [x4, #0xb]
    // 0x115f90c: DecompressPointer r2
    //     0x115f90c: add             x2, x2, HEAP, lsl #32
    // 0x115f910: mov             v0.16b, v1.16b
    // 0x115f914: r0 = lerp()
    //     0x115f914: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x115f918: mov             x4, x0
    // 0x115f91c: ldur            x0, [fp, #-0x10]
    // 0x115f920: stur            x4, [fp, #-0x20]
    // 0x115f924: LoadField: r1 = r0->field_f
    //     0x115f924: ldur            w1, [x0, #0xf]
    // 0x115f928: DecompressPointer r1
    //     0x115f928: add             x1, x1, HEAP, lsl #32
    // 0x115f92c: ldur            x5, [fp, #-8]
    // 0x115f930: LoadField: r2 = r5->field_f
    //     0x115f930: ldur            w2, [x5, #0xf]
    // 0x115f934: DecompressPointer r2
    //     0x115f934: add             x2, x2, HEAP, lsl #32
    // 0x115f938: ldur            d0, [fp, #-0x30]
    // 0x115f93c: r3 = inline_Allocate_Double()
    //     0x115f93c: ldp             x3, x6, [THR, #0x60]  ; THR::top
    //     0x115f940: add             x3, x3, #0x10
    //     0x115f944: cmp             x6, x3
    //     0x115f948: b.ls            #0x115fcfc
    //     0x115f94c: str             x3, [THR, #0x60]  ; THR::top
    //     0x115f950: sub             x3, x3, #0xf
    //     0x115f954: mov             x6, #0xe19c
    //     0x115f958: movk            x6, #3, lsl #16
    //     0x115f95c: stur            x6, [x3, #-1]
    // 0x115f960: dmb             ishst
    // 0x115f964: StoreField: r3->field_7 = d0
    //     0x115f964: stur            d0, [x3, #7]
    // 0x115f968: r0 = lerp()
    //     0x115f968: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x115f96c: stur            x0, [fp, #-0x28]
    // 0x115f970: r0 = UnderlineTabIndicator()
    //     0x115f970: bl              #0xeb4770  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0x115f974: mov             x1, x0
    // 0x115f978: ldur            x0, [fp, #-0x20]
    // 0x115f97c: StoreField: r1->field_b = r0
    //     0x115f97c: stur            w0, [x1, #0xb]
    // 0x115f980: ldur            x0, [fp, #-0x28]
    // 0x115f984: StoreField: r1->field_f = r0
    //     0x115f984: stur            w0, [x1, #0xf]
    // 0x115f988: mov             x0, x1
    // 0x115f98c: b               #0x115f9dc
    // 0x115f990: r0 = Null
    //     0x115f990: mov             x0, NULL
    // 0x115f994: b               #0x115f9dc
    // 0x115f998: ldur            x0, [fp, #-0x10]
    // 0x115f99c: r1 = LoadClassIdInstr(r0)
    //     0x115f99c: ldur            x1, [x0, #-1]
    //     0x115f9a0: ubfx            x1, x1, #0xc, #0x14
    // 0x115f9a4: r17 = 5240
    //     0x115f9a4: mov             x17, #0x1478
    // 0x115f9a8: cmp             x1, x17
    // 0x115f9ac: b.ne            #0x115f9c4
    // 0x115f9b0: mov             x1, x0
    // 0x115f9b4: ldur            x2, [fp, #-8]
    // 0x115f9b8: ldur            d0, [fp, #-0x30]
    // 0x115f9bc: r0 = lerp()
    //     0x115f9bc: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115f9c0: b               #0x115f9dc
    // 0x115f9c4: ldur            x2, [fp, #-8]
    // 0x115f9c8: ldur            d0, [fp, #-0x30]
    // 0x115f9cc: r1 = Null
    //     0x115f9cc: mov             x1, NULL
    // 0x115f9d0: r0 = lerp()
    //     0x115f9d0: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115f9d4: cmp             w0, NULL
    // 0x115f9d8: b.eq            #0x115fd28
    // 0x115f9dc: cmp             w0, NULL
    // 0x115f9e0: b.ne            #0x115fbb0
    // 0x115f9e4: ldur            x0, [fp, #-0x10]
    // 0x115f9e8: r1 = LoadClassIdInstr(r0)
    //     0x115f9e8: ldur            x1, [x0, #-1]
    //     0x115f9ec: ubfx            x1, x1, #0xc, #0x14
    // 0x115f9f0: r17 = 5237
    //     0x115f9f0: mov             x17, #0x1475
    // 0x115f9f4: cmp             x1, x17
    // 0x115f9f8: b.ne            #0x115fa84
    // 0x115f9fc: ldur            x3, [fp, #-0x18]
    // 0x115fa00: r17 = 5238
    //     0x115fa00: mov             x17, #0x1476
    // 0x115fa04: cmp             x3, x17
    // 0x115fa08: b.ne            #0x115fa2c
    // 0x115fa0c: ldur            x2, [fp, #-8]
    // 0x115fa10: r1 = Null
    //     0x115fa10: mov             x1, NULL
    // 0x115fa14: r0 = ShapeDecoration.fromBoxDecoration()
    //     0x115fa14: bl              #0x1163084  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::ShapeDecoration.fromBoxDecoration
    // 0x115fa18: ldur            x1, [fp, #-0x10]
    // 0x115fa1c: mov             x2, x0
    // 0x115fa20: ldur            d0, [fp, #-0x30]
    // 0x115fa24: r0 = lerp()
    //     0x115fa24: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115fa28: b               #0x115fbb0
    // 0x115fa2c: ldur            x0, [fp, #-8]
    // 0x115fa30: r2 = Null
    //     0x115fa30: mov             x2, NULL
    // 0x115fa34: r1 = Null
    //     0x115fa34: mov             x1, NULL
    // 0x115fa38: cmp             w0, NULL
    // 0x115fa3c: b.eq            #0x115fa60
    // 0x115fa40: branchIfSmi(r0, 0x115fa58)
    //     0x115fa40: tbz             w0, #0, #0x115fa58
    // 0x115fa44: r3 = LoadClassIdInstr(r0)
    //     0x115fa44: ldur            x3, [x0, #-1]
    //     0x115fa48: ubfx            x3, x3, #0xc, #0x14
    // 0x115fa4c: r17 = 5237
    //     0x115fa4c: mov             x17, #0x1475
    // 0x115fa50: cmp             x3, x17
    // 0x115fa54: b.eq            #0x115fa60
    // 0x115fa58: r0 = false
    //     0x115fa58: add             x0, NULL, #0x30  ; false
    // 0x115fa5c: b               #0x115fa64
    // 0x115fa60: r0 = true
    //     0x115fa60: add             x0, NULL, #0x20  ; true
    // 0x115fa64: tbnz            w0, #4, #0x115fa7c
    // 0x115fa68: ldur            x1, [fp, #-0x10]
    // 0x115fa6c: ldur            x2, [fp, #-8]
    // 0x115fa70: ldur            d0, [fp, #-0x30]
    // 0x115fa74: r0 = lerp()
    //     0x115fa74: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115fa78: b               #0x115fbb0
    // 0x115fa7c: r0 = Null
    //     0x115fa7c: mov             x0, NULL
    // 0x115fa80: b               #0x115fbb0
    // 0x115fa84: r17 = 5238
    //     0x115fa84: mov             x17, #0x1476
    // 0x115fa88: cmp             x1, x17
    // 0x115fa8c: b.ne            #0x115fabc
    // 0x115fa90: ldur            x0, [fp, #-0x18]
    // 0x115fa94: r17 = 5238
    //     0x115fa94: mov             x17, #0x1476
    // 0x115fa98: cmp             x0, x17
    // 0x115fa9c: b.ne            #0x115fab4
    // 0x115faa0: ldur            x1, [fp, #-0x10]
    // 0x115faa4: ldur            x2, [fp, #-8]
    // 0x115faa8: ldur            d0, [fp, #-0x30]
    // 0x115faac: r0 = lerp()
    //     0x115faac: bl              #0x115fd5c  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::lerp
    // 0x115fab0: b               #0x115fbb0
    // 0x115fab4: r0 = Null
    //     0x115fab4: mov             x0, NULL
    // 0x115fab8: b               #0x115fbb0
    // 0x115fabc: r17 = 5239
    //     0x115fabc: mov             x17, #0x1477
    // 0x115fac0: cmp             x1, x17
    // 0x115fac4: b.ne            #0x115fb7c
    // 0x115fac8: ldur            x0, [fp, #-0x18]
    // 0x115facc: r17 = 5239
    //     0x115facc: mov             x17, #0x1477
    // 0x115fad0: cmp             x0, x17
    // 0x115fad4: b.ne            #0x115fb74
    // 0x115fad8: ldur            x3, [fp, #-0x10]
    // 0x115fadc: ldur            x4, [fp, #-8]
    // 0x115fae0: ldur            d1, [fp, #-0x30]
    // 0x115fae4: LoadField: r1 = r3->field_b
    //     0x115fae4: ldur            w1, [x3, #0xb]
    // 0x115fae8: DecompressPointer r1
    //     0x115fae8: add             x1, x1, HEAP, lsl #32
    // 0x115faec: LoadField: r2 = r4->field_b
    //     0x115faec: ldur            w2, [x4, #0xb]
    // 0x115faf0: DecompressPointer r2
    //     0x115faf0: add             x2, x2, HEAP, lsl #32
    // 0x115faf4: mov             v0.16b, v1.16b
    // 0x115faf8: r0 = lerp()
    //     0x115faf8: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x115fafc: mov             x4, x0
    // 0x115fb00: ldur            x0, [fp, #-0x10]
    // 0x115fb04: stur            x4, [fp, #-0x20]
    // 0x115fb08: LoadField: r1 = r0->field_f
    //     0x115fb08: ldur            w1, [x0, #0xf]
    // 0x115fb0c: DecompressPointer r1
    //     0x115fb0c: add             x1, x1, HEAP, lsl #32
    // 0x115fb10: ldur            x5, [fp, #-8]
    // 0x115fb14: LoadField: r2 = r5->field_f
    //     0x115fb14: ldur            w2, [x5, #0xf]
    // 0x115fb18: DecompressPointer r2
    //     0x115fb18: add             x2, x2, HEAP, lsl #32
    // 0x115fb1c: ldur            d0, [fp, #-0x30]
    // 0x115fb20: r3 = inline_Allocate_Double()
    //     0x115fb20: ldp             x3, x6, [THR, #0x60]  ; THR::top
    //     0x115fb24: add             x3, x3, #0x10
    //     0x115fb28: cmp             x6, x3
    //     0x115fb2c: b.ls            #0x115fd2c
    //     0x115fb30: str             x3, [THR, #0x60]  ; THR::top
    //     0x115fb34: sub             x3, x3, #0xf
    //     0x115fb38: mov             x6, #0xe19c
    //     0x115fb3c: movk            x6, #3, lsl #16
    //     0x115fb40: stur            x6, [x3, #-1]
    // 0x115fb44: dmb             ishst
    // 0x115fb48: StoreField: r3->field_7 = d0
    //     0x115fb48: stur            d0, [x3, #7]
    // 0x115fb4c: r0 = lerp()
    //     0x115fb4c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x115fb50: stur            x0, [fp, #-0x28]
    // 0x115fb54: r0 = UnderlineTabIndicator()
    //     0x115fb54: bl              #0xeb4770  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0x115fb58: mov             x1, x0
    // 0x115fb5c: ldur            x0, [fp, #-0x20]
    // 0x115fb60: StoreField: r1->field_b = r0
    //     0x115fb60: stur            w0, [x1, #0xb]
    // 0x115fb64: ldur            x0, [fp, #-0x28]
    // 0x115fb68: StoreField: r1->field_f = r0
    //     0x115fb68: stur            w0, [x1, #0xf]
    // 0x115fb6c: mov             x0, x1
    // 0x115fb70: b               #0x115fbb0
    // 0x115fb74: r0 = Null
    //     0x115fb74: mov             x0, NULL
    // 0x115fb78: b               #0x115fbb0
    // 0x115fb7c: ldur            x0, [fp, #-0x18]
    // 0x115fb80: r17 = 5240
    //     0x115fb80: mov             x17, #0x1478
    // 0x115fb84: cmp             x0, x17
    // 0x115fb88: b.ne            #0x115fba0
    // 0x115fb8c: ldur            x1, [fp, #-0x10]
    // 0x115fb90: ldur            x2, [fp, #-8]
    // 0x115fb94: ldur            d0, [fp, #-0x30]
    // 0x115fb98: r0 = lerp()
    //     0x115fb98: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115fb9c: b               #0x115fbb0
    // 0x115fba0: ldur            x1, [fp, #-0x10]
    // 0x115fba4: ldur            d0, [fp, #-0x30]
    // 0x115fba8: r2 = Null
    //     0x115fba8: mov             x2, NULL
    // 0x115fbac: r0 = lerp()
    //     0x115fbac: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115fbb0: cmp             w0, NULL
    // 0x115fbb4: b.ne            #0x115fce0
    // 0x115fbb8: ldur            d0, [fp, #-0x30]
    // 0x115fbbc: d1 = 0.500000
    //     0x115fbbc: fmov            d1, #0.50000000
    // 0x115fbc0: fcmp            d1, d0
    // 0x115fbc4: b.le            #0x115fc58
    // 0x115fbc8: ldur            x0, [fp, #-0x10]
    // 0x115fbcc: d2 = 2.000000
    //     0x115fbcc: fmov            d2, #2.00000000
    // 0x115fbd0: fmul            d1, d0, d2
    // 0x115fbd4: r1 = LoadClassIdInstr(r0)
    //     0x115fbd4: ldur            x1, [x0, #-1]
    //     0x115fbd8: ubfx            x1, x1, #0xc, #0x14
    // 0x115fbdc: r17 = 5237
    //     0x115fbdc: mov             x17, #0x1475
    // 0x115fbe0: cmp             x1, x17
    // 0x115fbe4: b.ne            #0x115fbfc
    // 0x115fbe8: mov             x1, x0
    // 0x115fbec: mov             v0.16b, v1.16b
    // 0x115fbf0: r2 = Null
    //     0x115fbf0: mov             x2, NULL
    // 0x115fbf4: r0 = lerp()
    //     0x115fbf4: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115fbf8: b               #0x115fc44
    // 0x115fbfc: r17 = 5238
    //     0x115fbfc: mov             x17, #0x1476
    // 0x115fc00: cmp             x1, x17
    // 0x115fc04: b.ne            #0x115fc20
    // 0x115fc08: d0 = 1.000000
    //     0x115fc08: fmov            d0, #1.00000000
    // 0x115fc0c: fsub            d2, d0, d1
    // 0x115fc10: ldur            x1, [fp, #-0x10]
    // 0x115fc14: mov             v0.16b, v2.16b
    // 0x115fc18: r0 = scale()
    //     0x115fc18: bl              #0x11637d0  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0x115fc1c: b               #0x115fc44
    // 0x115fc20: r17 = 5239
    //     0x115fc20: mov             x17, #0x1477
    // 0x115fc24: cmp             x1, x17
    // 0x115fc28: b.ne            #0x115fc34
    // 0x115fc2c: r0 = Null
    //     0x115fc2c: mov             x0, NULL
    // 0x115fc30: b               #0x115fc44
    // 0x115fc34: ldur            x1, [fp, #-0x10]
    // 0x115fc38: mov             v0.16b, v1.16b
    // 0x115fc3c: r2 = Null
    //     0x115fc3c: mov             x2, NULL
    // 0x115fc40: r0 = lerp()
    //     0x115fc40: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115fc44: cmp             w0, NULL
    // 0x115fc48: b.ne            #0x115fc50
    // 0x115fc4c: ldur            x0, [fp, #-0x10]
    // 0x115fc50: mov             x1, x0
    // 0x115fc54: b               #0x115fcdc
    // 0x115fc58: ldur            x0, [fp, #-0x18]
    // 0x115fc5c: d2 = 2.000000
    //     0x115fc5c: fmov            d2, #2.00000000
    // 0x115fc60: fsub            d3, d0, d1
    // 0x115fc64: fmul            d0, d3, d2
    // 0x115fc68: r17 = 5237
    //     0x115fc68: mov             x17, #0x1475
    // 0x115fc6c: cmp             x0, x17
    // 0x115fc70: b.ne            #0x115fc88
    // 0x115fc74: ldur            x2, [fp, #-8]
    // 0x115fc78: r1 = Null
    //     0x115fc78: mov             x1, NULL
    // 0x115fc7c: r0 = lerp()
    //     0x115fc7c: bl              #0x116398c  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0x115fc80: mov             x1, x0
    // 0x115fc84: b               #0x115fcd0
    // 0x115fc88: r17 = 5238
    //     0x115fc88: mov             x17, #0x1476
    // 0x115fc8c: cmp             x0, x17
    // 0x115fc90: b.ne            #0x115fca4
    // 0x115fc94: ldur            x1, [fp, #-8]
    // 0x115fc98: r0 = scale()
    //     0x115fc98: bl              #0x11637d0  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0x115fc9c: mov             x1, x0
    // 0x115fca0: b               #0x115fcd0
    // 0x115fca4: r17 = 5239
    //     0x115fca4: mov             x17, #0x1477
    // 0x115fca8: cmp             x0, x17
    // 0x115fcac: b.ne            #0x115fcb8
    // 0x115fcb0: r1 = Null
    //     0x115fcb0: mov             x1, NULL
    // 0x115fcb4: b               #0x115fcd0
    // 0x115fcb8: ldur            x2, [fp, #-8]
    // 0x115fcbc: r1 = Null
    //     0x115fcbc: mov             x1, NULL
    // 0x115fcc0: r0 = lerp()
    //     0x115fcc0: bl              #0x11631e4  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0x115fcc4: cmp             w0, NULL
    // 0x115fcc8: b.eq            #0x115fd58
    // 0x115fccc: mov             x1, x0
    // 0x115fcd0: cmp             w1, NULL
    // 0x115fcd4: b.ne            #0x115fcdc
    // 0x115fcd8: ldur            x1, [fp, #-8]
    // 0x115fcdc: mov             x0, x1
    // 0x115fce0: LeaveFrame
    //     0x115fce0: mov             SP, fp
    //     0x115fce4: ldp             fp, lr, [SP], #0x10
    // 0x115fce8: ret
    //     0x115fce8: ret             
    // 0x115fcec: r0 = StackOverflowSharedWithFPURegs()
    //     0x115fcec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115fcf0: b               #0x115f688
    // 0x115fcf4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115fcf4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x115fcf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115fcf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115fcfc: SaveReg d0
    //     0x115fcfc: str             q0, [SP, #-0x10]!
    // 0x115fd00: stp             x4, x5, [SP, #-0x10]!
    // 0x115fd04: stp             x1, x2, [SP, #-0x10]!
    // 0x115fd08: SaveReg r0
    //     0x115fd08: str             x0, [SP, #-8]!
    // 0x115fd0c: r0 = AllocateDouble()
    //     0x115fd0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115fd10: mov             x3, x0
    // 0x115fd14: RestoreReg r0
    //     0x115fd14: ldr             x0, [SP], #8
    // 0x115fd18: ldp             x1, x2, [SP], #0x10
    // 0x115fd1c: ldp             x4, x5, [SP], #0x10
    // 0x115fd20: RestoreReg d0
    //     0x115fd20: ldr             q0, [SP], #0x10
    // 0x115fd24: b               #0x115f964
    // 0x115fd28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115fd28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115fd2c: SaveReg d0
    //     0x115fd2c: str             q0, [SP, #-0x10]!
    // 0x115fd30: stp             x4, x5, [SP, #-0x10]!
    // 0x115fd34: stp             x1, x2, [SP, #-0x10]!
    // 0x115fd38: SaveReg r0
    //     0x115fd38: str             x0, [SP, #-8]!
    // 0x115fd3c: r0 = AllocateDouble()
    //     0x115fd3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115fd40: mov             x3, x0
    // 0x115fd44: RestoreReg r0
    //     0x115fd44: ldr             x0, [SP], #8
    // 0x115fd48: ldp             x1, x2, [SP], #0x10
    // 0x115fd4c: ldp             x4, x5, [SP], #0x10
    // 0x115fd50: RestoreReg d0
    //     0x115fd50: ldr             q0, [SP], #0x10
    // 0x115fd54: b               #0x115fb48
    // 0x115fd58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115fd58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getClipPath(/* No info */) {
    // ** addr: 0x1196cdc, size: 0x28
    // 0x1196cdc: EnterFrame
    //     0x1196cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1196ce0: mov             fp, SP
    // 0x1196ce4: r0 = UnsupportedError()
    //     0x1196ce4: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x1196ce8: mov             x1, x0
    // 0x1196cec: r0 = "This Decoration subclass does not expect to be used for clipping."
    //     0x1196cec: add             x0, PP, #0x97, lsl #12  ; [pp+0x97640] "This Decoration subclass does not expect to be used for clipping."
    //     0x1196cf0: ldr             x0, [x0, #0x640]
    // 0x1196cf4: StoreField: r1->field_b = r0
    //     0x1196cf4: stur            w0, [x1, #0xb]
    // 0x1196cf8: mov             x0, x1
    // 0x1196cfc: r0 = Throw()
    //     0x1196cfc: bl              #0x13ddb2c  ; ThrowStub
    // 0x1196d00: brk             #0
  }
}
