// lib: , url: package:flutter/src/painting/_network_image_io.dart

// class id: 1048976, size: 0x8
class :: {
}

// class id: 3601, size: 0x1c, field offset: 0xc
//   const constructor, 
class NetworkImage extends ImageProvider<dynamic>
    implements NetworkImage {

  static late final HttpClient _sharedHttpClient; // offset: 0x11e0

  get _ hashCode(/* No info */) {
    // ** addr: 0x11492ac, size: 0x7c
    // 0x11492ac: EnterFrame
    //     0x11492ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11492b0: mov             fp, SP
    // 0x11492b4: AllocStack(0x10)
    //     0x11492b4: sub             SP, SP, #0x10
    // 0x11492b8: CheckStackOverflow
    //     0x11492b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11492bc: cmp             SP, x16
    //     0x11492c0: b.ls            #0x1149320
    // 0x11492c4: ldr             x0, [fp, #0x10]
    // 0x11492c8: LoadField: r3 = r0->field_b
    //     0x11492c8: ldur            w3, [x0, #0xb]
    // 0x11492cc: DecompressPointer r3
    //     0x11492cc: add             x3, x3, HEAP, lsl #32
    // 0x11492d0: stur            x3, [fp, #-8]
    // 0x11492d4: r1 = Instance_MapEquality
    //     0x11492d4: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8af28] Obj!MapEquality<String, String>@129fff1
    //     0x11492d8: ldr             x1, [x1, #0xf28]
    // 0x11492dc: r2 = Null
    //     0x11492dc: mov             x2, NULL
    // 0x11492e0: r0 = hash()
    //     0x11492e0: bl              #0x12e8ebc  ; [package:collection/src/equality.dart] MapEquality::hash
    // 0x11492e4: r16 = 4022
    //     0x11492e4: mov             x16, #0xfb6
    // 0x11492e8: str             x16, [SP]
    // 0x11492ec: ldur            x1, [fp, #-8]
    // 0x11492f0: r2 = 1.000000
    //     0x11492f0: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x11492f4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x11492f4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x11492f8: r0 = hash()
    //     0x11492f8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11492fc: mov             x2, x0
    // 0x1149300: r0 = BoxInt64Instr(r2)
    //     0x1149300: sbfiz           x0, x2, #1, #0x1f
    //     0x1149304: cmp             x2, x0, asr #1
    //     0x1149308: b.eq            #0x1149314
    //     0x114930c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149310: stur            x2, [x0, #7]
    // 0x1149314: LeaveFrame
    //     0x1149314: mov             SP, fp
    //     0x1149318: ldp             fp, lr, [SP], #0x10
    // 0x114931c: ret
    //     0x114931c: ret             
    // 0x1149320: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149320: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149324: b               #0x11492c4
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0x115a8d0, size: 0x34
    // 0x115a8d0: EnterFrame
    //     0x115a8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x115a8d4: mov             fp, SP
    // 0x115a8d8: AllocStack(0x8)
    //     0x115a8d8: sub             SP, SP, #8
    // 0x115a8dc: SetupParameters(NetworkImage this /* r1 => r0, fp-0x8 */)
    //     0x115a8dc: mov             x0, x1
    //     0x115a8e0: stur            x1, [fp, #-8]
    // 0x115a8e4: r1 = <NetworkImage>
    //     0x115a8e4: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8af38] TypeArguments: <NetworkImage>
    //     0x115a8e8: ldr             x1, [x1, #0xf38]
    // 0x115a8ec: r0 = SynchronousFuture()
    //     0x115a8ec: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x115a8f0: ldur            x1, [fp, #-8]
    // 0x115a8f4: StoreField: r0->field_b = r1
    //     0x115a8f4: stur            w1, [x0, #0xb]
    // 0x115a8f8: LeaveFrame
    //     0x115a8f8: mov             SP, fp
    //     0x115a8fc: ldp             fp, lr, [SP], #0x10
    // 0x115a900: ret
    //     0x115a900: ret             
  }
  _ loadImage(/* No info */) {
    // ** addr: 0x1191930, size: 0x114
    // 0x1191930: EnterFrame
    //     0x1191930: stp             fp, lr, [SP, #-0x10]!
    //     0x1191934: mov             fp, SP
    // 0x1191938: AllocStack(0x38)
    //     0x1191938: sub             SP, SP, #0x38
    // 0x119193c: SetupParameters(NetworkImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x119193c: mov             x5, x3
    //     0x1191940: stur            x1, [fp, #-8]
    //     0x1191944: stur            x2, [fp, #-0x10]
    //     0x1191948: stur            x3, [fp, #-0x18]
    // 0x119194c: CheckStackOverflow
    //     0x119194c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191950: cmp             SP, x16
    //     0x1191954: b.ls            #0x1191a3c
    // 0x1191958: r1 = 2
    //     0x1191958: mov             x1, #2
    // 0x119195c: r0 = AllocateContext()
    //     0x119195c: bl              #0x13de838  ; AllocateContextStub
    // 0x1191960: mov             x2, x0
    // 0x1191964: ldur            x0, [fp, #-8]
    // 0x1191968: stur            x2, [fp, #-0x20]
    // 0x119196c: StoreField: r2->field_f = r0
    //     0x119196c: stur            w0, [x2, #0xf]
    // 0x1191970: ldur            x1, [fp, #-0x10]
    // 0x1191974: StoreField: r2->field_13 = r1
    //     0x1191974: stur            w1, [x2, #0x13]
    // 0x1191978: r1 = <ImageChunkEvent>
    //     0x1191978: add             x1, PP, #0x94, lsl #12  ; [pp+0x94cd8] TypeArguments: <ImageChunkEvent>
    //     0x119197c: ldr             x1, [x1, #0xcd8]
    // 0x1191980: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1191980: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1191984: r0 = StreamController()
    //     0x1191984: bl              #0x811820  ; [dart:async] StreamController::StreamController
    // 0x1191988: mov             x4, x0
    // 0x119198c: ldur            x0, [fp, #-0x20]
    // 0x1191990: stur            x4, [fp, #-0x10]
    // 0x1191994: LoadField: r2 = r0->field_13
    //     0x1191994: ldur            w2, [x0, #0x13]
    // 0x1191998: DecompressPointer r2
    //     0x1191998: add             x2, x2, HEAP, lsl #32
    // 0x119199c: ldur            x1, [fp, #-8]
    // 0x11919a0: mov             x3, x4
    // 0x11919a4: ldur            x5, [fp, #-0x18]
    // 0x11919a8: r0 = _loadAsync()
    //     0x11919a8: bl              #0x1191a50  ; [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync
    // 0x11919ac: mov             x2, x0
    // 0x11919b0: ldur            x0, [fp, #-0x10]
    // 0x11919b4: stur            x2, [fp, #-8]
    // 0x11919b8: LoadField: r1 = r0->field_7
    //     0x11919b8: ldur            w1, [x0, #7]
    // 0x11919bc: DecompressPointer r1
    //     0x11919bc: add             x1, x1, HEAP, lsl #32
    // 0x11919c0: r0 = _ControllerStream()
    //     0x11919c0: bl              #0x810928  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x10)
    // 0x11919c4: mov             x3, x0
    // 0x11919c8: ldur            x0, [fp, #-0x10]
    // 0x11919cc: stur            x3, [fp, #-0x18]
    // 0x11919d0: StoreField: r3->field_b = r0
    //     0x11919d0: stur            w0, [x3, #0xb]
    // 0x11919d4: ldur            x2, [fp, #-0x20]
    // 0x11919d8: LoadField: r0 = r2->field_13
    //     0x11919d8: ldur            w0, [x2, #0x13]
    // 0x11919dc: DecompressPointer r0
    //     0x11919dc: add             x0, x0, HEAP, lsl #32
    // 0x11919e0: LoadField: r4 = r0->field_b
    //     0x11919e0: ldur            w4, [x0, #0xb]
    // 0x11919e4: DecompressPointer r4
    //     0x11919e4: add             x4, x4, HEAP, lsl #32
    // 0x11919e8: stur            x4, [fp, #-0x10]
    // 0x11919ec: r1 = Function '<anonymous closure>':.
    //     0x11919ec: add             x1, PP, #0x94, lsl #12  ; [pp+0x94ce0] AnonymousClosure: (0x119208c), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::loadImage (0x1191930)
    //     0x11919f0: ldr             x1, [x1, #0xce0]
    // 0x11919f4: r0 = AllocateClosure()
    //     0x11919f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11919f8: stur            x0, [fp, #-0x20]
    // 0x11919fc: r0 = MultiFrameImageStreamCompleter()
    //     0x11919fc: bl              #0x1191a44  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0x1191a00: stur            x0, [fp, #-0x28]
    // 0x1191a04: ldur            x16, [fp, #-0x18]
    // 0x1191a08: ldur            lr, [fp, #-0x20]
    // 0x1191a0c: stp             lr, x16, [SP]
    // 0x1191a10: mov             x1, x0
    // 0x1191a14: ldur            x2, [fp, #-8]
    // 0x1191a18: ldur            x3, [fp, #-0x10]
    // 0x1191a1c: d0 = 1.000000
    //     0x1191a1c: fmov            d0, #1.00000000
    // 0x1191a20: r4 = const [0, 0x6, 0x2, 0x4, chunkEvents, 0x4, informationCollector, 0x5, null]
    //     0x1191a20: add             x4, PP, #0x94, lsl #12  ; [pp+0x94ce8] List(9) [0, 0x6, 0x2, 0x4, "chunkEvents", 0x4, "informationCollector", 0x5, Null]
    //     0x1191a24: ldr             x4, [x4, #0xce8]
    // 0x1191a28: r0 = MultiFrameImageStreamCompleter()
    //     0x1191a28: bl              #0x11864e8  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0x1191a2c: ldur            x0, [fp, #-0x28]
    // 0x1191a30: LeaveFrame
    //     0x1191a30: mov             SP, fp
    //     0x1191a34: ldp             fp, lr, [SP], #0x10
    // 0x1191a38: ret
    //     0x1191a38: ret             
    // 0x1191a3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191a3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191a40: b               #0x1191958
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0x1191a50, size: 0x3ac
    // 0x1191a50: EnterFrame
    //     0x1191a50: stp             fp, lr, [SP, #-0x10]!
    //     0x1191a54: mov             fp, SP
    // 0x1191a58: AllocStack(0x100)
    //     0x1191a58: sub             SP, SP, #0x100
    // 0x1191a5c: SetupParameters(NetworkImage this /* r1 => r1, fp-0xb0 */, dynamic _ /* r2 => r2, fp-0xb8 */, dynamic _ /* r3 => r3, fp-0xc0 */, dynamic _ /* r5 => r5, fp-0xc8 */)
    //     0x1191a5c: stur            NULL, [fp, #-8]
    //     0x1191a60: stur            x1, [fp, #-0xb0]
    //     0x1191a64: stur            x2, [fp, #-0xb8]
    //     0x1191a68: stur            x3, [fp, #-0xc0]
    //     0x1191a6c: stur            x5, [fp, #-0xc8]
    // 0x1191a70: CheckStackOverflow
    //     0x1191a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191a74: cmp             SP, x16
    //     0x1191a78: b.ls            #0x1191dec
    // 0x1191a7c: r1 = 3
    //     0x1191a7c: mov             x1, #3
    // 0x1191a80: r0 = AllocateContext()
    //     0x1191a80: bl              #0x13de838  ; AllocateContextStub
    // 0x1191a84: mov             x1, x0
    // 0x1191a88: ldur            x0, [fp, #-0xb8]
    // 0x1191a8c: stur            x1, [fp, #-0xd0]
    // 0x1191a90: StoreField: r1->field_f = r0
    //     0x1191a90: stur            w0, [x1, #0xf]
    // 0x1191a94: ldur            x0, [fp, #-0xc0]
    // 0x1191a98: StoreField: r1->field_13 = r0
    //     0x1191a98: stur            w0, [x1, #0x13]
    // 0x1191a9c: InitAsync() -> Future<Codec>
    //     0x1191a9c: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1191aa0: ldr             x0, [x0, #0x278]
    //     0x1191aa4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1191aa8: ldur            x2, [fp, #-0xd0]
    // 0x1191aac: r0 = LoadStaticField(0x178)
    //     0x1191aac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1191ab0: ldr             x0, [x0, #0x2f0]
    // 0x1191ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1191ab8: cmp             w0, w16
    // 0x1191abc: b.ne            #0x1191ac8
    // 0x1191ac0: r2 = _uriBaseClosure
    //     0x1191ac0: ldr             x2, [PP, #0x71a8]  ; [pp+0x71a8] Field <::._uriBaseClosure@0150898>: static late (offset: 0x178)
    // 0x1191ac4: r0 = InitLateStaticField()
    //     0x1191ac4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x1191ac8: mov             x1, x0
    // 0x1191acc: stur            x1, [fp, #-0xb8]
    // 0x1191ad0: str             x1, [SP]
    // 0x1191ad4: mov             x0, x1
    // 0x1191ad8: ClosureCall
    //     0x1191ad8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x1191adc: ldur            x2, [x0, #0x1f]
    //     0x1191ae0: blr             x2
    // 0x1191ae4: ldur            x3, [fp, #-0xd0]
    // 0x1191ae8: LoadField: r1 = r3->field_f
    //     0x1191ae8: ldur            w1, [x3, #0xf]
    // 0x1191aec: DecompressPointer r1
    //     0x1191aec: add             x1, x1, HEAP, lsl #32
    // 0x1191af0: LoadField: r2 = r1->field_b
    //     0x1191af0: ldur            w2, [x1, #0xb]
    // 0x1191af4: DecompressPointer r2
    //     0x1191af4: add             x2, x2, HEAP, lsl #32
    // 0x1191af8: r1 = LoadClassIdInstr(r0)
    //     0x1191af8: ldur            x1, [x0, #-1]
    //     0x1191afc: ubfx            x1, x1, #0xc, #0x14
    // 0x1191b00: mov             x16, x0
    // 0x1191b04: mov             x0, x1
    // 0x1191b08: mov             x1, x16
    // 0x1191b0c: r0 = GDT[cid_x0 + -0xe5c]()
    //     0x1191b0c: sub             lr, x0, #0xe5c
    //     0x1191b10: ldr             lr, [x21, lr, lsl #3]
    //     0x1191b14: blr             lr
    // 0x1191b18: stur            x0, [fp, #-0xb8]
    // 0x1191b1c: r0 = LoadStaticField(0x11e0)
    //     0x1191b1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1191b20: ldr             x0, [x0, #0x23c0]
    // 0x1191b24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1191b28: cmp             w0, w16
    // 0x1191b2c: b.ne            #0x1191b3c
    // 0x1191b30: r2 = _sharedHttpClient
    //     0x1191b30: add             x2, PP, #0x94, lsl #12  ; [pp+0x94d58] Field <NetworkImage._sharedHttpClient@1323199871>: static late final (offset: 0x11e0)
    //     0x1191b34: ldr             x2, [x2, #0xd58]
    // 0x1191b38: r0 = InitLateFinalStaticField()
    //     0x1191b38: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x1191b3c: mov             x1, x0
    // 0x1191b40: ldur            x2, [fp, #-0xb8]
    // 0x1191b44: r0 = getUrl()
    //     0x1191b44: bl              #0x1005024  ; [dart:_http] _HttpClient::getUrl
    // 0x1191b48: mov             x1, x0
    // 0x1191b4c: stur            x1, [fp, #-0xc0]
    // 0x1191b50: r0 = Await()
    //     0x1191b50: bl              #0x7f5c00  ; AwaitStub
    // 0x1191b54: mov             x1, x0
    // 0x1191b58: ldur            x2, [fp, #-0xd0]
    // 0x1191b5c: ArrayStore: r2[0] = r0  ; List_4
    //     0x1191b5c: stur            w0, [x2, #0x17]
    //     0x1191b60: tbz             w0, #0, #0x1191b7c
    //     0x1191b64: ldurb           w16, [x2, #-1]
    //     0x1191b68: ldurb           w17, [x0, #-1]
    //     0x1191b6c: and             x16, x17, x16, lsr #2
    //     0x1191b70: tst             x16, HEAP, lsr #32
    //     0x1191b74: b.eq            #0x1191b7c
    //     0x1191b78: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1191b7c: r0 = close()
    //     0x1191b7c: bl              #0x814a10  ; [dart:_http] _HttpClientRequest::close
    // 0x1191b80: mov             x1, x0
    // 0x1191b84: stur            x1, [fp, #-0xb0]
    // 0x1191b88: r0 = Await()
    //     0x1191b88: bl              #0x7f5c00  ; AwaitStub
    // 0x1191b8c: stur            x0, [fp, #-0xb0]
    // 0x1191b90: LoadField: r3 = r0->field_b
    //     0x1191b90: ldur            w3, [x0, #0xb]
    // 0x1191b94: DecompressPointer r3
    //     0x1191b94: add             x3, x3, HEAP, lsl #32
    // 0x1191b98: stur            x3, [fp, #-0xe8]
    // 0x1191b9c: LoadField: r1 = r3->field_1b
    //     0x1191b9c: ldur            w1, [x3, #0x1b]
    // 0x1191ba0: DecompressPointer r1
    //     0x1191ba0: add             x1, x1, HEAP, lsl #32
    // 0x1191ba4: cmp             w1, NULL
    // 0x1191ba8: b.eq            #0x1191df4
    // 0x1191bac: cmp             w1, #0x190
    // 0x1191bb0: b.ne            #0x1191c84
    // 0x1191bb4: ldur            x2, [fp, #-0xd0]
    // 0x1191bb8: r1 = Function '<anonymous closure>':.
    //     0x1191bb8: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d60] AnonymousClosure: (0x1191fc0), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0x1191a50)
    //     0x1191bbc: ldr             x1, [x1, #0xd60]
    // 0x1191bc0: r0 = AllocateClosure()
    //     0x1191bc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1191bc4: str             x0, [SP]
    // 0x1191bc8: ldur            x1, [fp, #-0xb0]
    // 0x1191bcc: r4 = const [0, 0x2, 0x1, 0x1, onBytesReceived, 0x1, null]
    //     0x1191bcc: add             x4, PP, #0x94, lsl #12  ; [pp+0x94d68] List(7) [0, 0x2, 0x1, 0x1, "onBytesReceived", 0x1, Null]
    //     0x1191bd0: ldr             x4, [x4, #0xd68]
    // 0x1191bd4: r0 = consolidateHttpClientResponseBytes()
    //     0x1191bd4: bl              #0x1004adc  ; [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes
    // 0x1191bd8: mov             x1, x0
    // 0x1191bdc: stur            x1, [fp, #-0xc0]
    // 0x1191be0: r0 = Await()
    //     0x1191be0: bl              #0x7f5c00  ; AwaitStub
    // 0x1191be4: mov             x2, x0
    // 0x1191be8: stur            x2, [fp, #-0xc0]
    // 0x1191bec: r0 = LoadClassIdInstr(r2)
    //     0x1191bec: ldur            x0, [x2, #-1]
    //     0x1191bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x1191bf4: mov             x1, x2
    // 0x1191bf8: r0 = GDT[cid_x0 + -0xbdd]()
    //     0x1191bf8: sub             lr, x0, #0xbdd
    //     0x1191bfc: ldr             lr, [x21, lr, lsl #3]
    //     0x1191c00: blr             lr
    // 0x1191c04: cbz             x0, #0x1191d08
    // 0x1191c08: ldur            x0, [fp, #-0xc8]
    // 0x1191c0c: ldur            x1, [fp, #-0xc0]
    // 0x1191c10: r0 = fromUint8List()
    //     0x1191c10: bl              #0xce7b70  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0x1191c14: mov             x1, x0
    // 0x1191c18: stur            x1, [fp, #-0xd8]
    // 0x1191c1c: r0 = Await()
    //     0x1191c1c: bl              #0x7f5c00  ; AwaitStub
    // 0x1191c20: mov             x3, x0
    // 0x1191c24: ldur            x0, [fp, #-0xc8]
    // 0x1191c28: stur            x3, [fp, #-0xe0]
    // 0x1191c2c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x1191c2c: ldur            w4, [x0, #0x17]
    // 0x1191c30: DecompressPointer r4
    //     0x1191c30: add             x4, x4, HEAP, lsl #32
    // 0x1191c34: mov             x1, x3
    // 0x1191c38: stur            x4, [fp, #-0xd8]
    // 0x1191c3c: r2 = Null
    //     0x1191c3c: mov             x2, NULL
    // 0x1191c40: r0 = instantiateImageCodecWithSize()
    //     0x1191c40: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x1191c44: stur            x0, [fp, #-0xc0]
    // 0x1191c48: ldur            x4, [fp, #-0xd0]
    // 0x1191c4c: LoadField: r1 = r4->field_13
    //     0x1191c4c: ldur            w1, [x4, #0x13]
    // 0x1191c50: DecompressPointer r1
    //     0x1191c50: add             x1, x1, HEAP, lsl #32
    // 0x1191c54: r0 = close()
    //     0x1191c54: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1191c58: r1 = Function '<anonymous closure>':.
    //     0x1191c58: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d70] AnonymousClosure: (0x1191f38), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0x1191a50)
    //     0x1191c5c: ldr             x1, [x1, #0xd70]
    // 0x1191c60: r2 = Null
    //     0x1191c60: mov             x2, NULL
    // 0x1191c64: stur            x0, [fp, #-0xc8]
    // 0x1191c68: r0 = AllocateClosure()
    //     0x1191c68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1191c6c: ldur            x1, [fp, #-0xc8]
    // 0x1191c70: mov             x2, x0
    // 0x1191c74: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1191c74: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1191c78: r0 = catchError()
    //     0x1191c78: bl              #0x1291b1c  ; [dart:async] _Future::catchError
    // 0x1191c7c: ldur            x0, [fp, #-0xc0]
    // 0x1191c80: r0 = ReturnAsync()
    //     0x1191c80: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x1191c84: ldur            x4, [fp, #-0xd0]
    // 0x1191c88: r1 = <int>
    //     0x1191c88: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x1191c8c: r2 = 0
    //     0x1191c8c: mov             x2, #0
    // 0x1191c90: r0 = _GrowableList()
    //     0x1191c90: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x1191c94: r16 = <List<int>>
    //     0x1191c94: add             x16, PP, #0xb, lsl #12  ; [pp+0xb958] TypeArguments: <List<int>>
    //     0x1191c98: ldr             x16, [x16, #0x958]
    // 0x1191c9c: ldur            lr, [fp, #-0xb0]
    // 0x1191ca0: stp             lr, x16, [SP, #8]
    // 0x1191ca4: str             x0, [SP]
    // 0x1191ca8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1191ca8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1191cac: r0 = drain()
    //     0x1191cac: bl              #0x810814  ; [dart:async] Stream::drain
    // 0x1191cb0: mov             x1, x0
    // 0x1191cb4: stur            x1, [fp, #-0xc0]
    // 0x1191cb8: r0 = Await()
    //     0x1191cb8: bl              #0x7f5c00  ; AwaitStub
    // 0x1191cbc: ldur            x0, [fp, #-0xe8]
    // 0x1191cc0: LoadField: r1 = r0->field_1b
    //     0x1191cc0: ldur            w1, [x0, #0x1b]
    // 0x1191cc4: DecompressPointer r1
    //     0x1191cc4: add             x1, x1, HEAP, lsl #32
    // 0x1191cc8: stur            x1, [fp, #-0xc0]
    // 0x1191ccc: cmp             w1, NULL
    // 0x1191cd0: b.eq            #0x1191df8
    // 0x1191cd4: r0 = NetworkImageLoadException()
    //     0x1191cd4: bl              #0x1191eb0  ; AllocateNetworkImageLoadExceptionStub -> NetworkImageLoadException (size=0xc)
    // 0x1191cd8: mov             x4, x0
    // 0x1191cdc: ldur            x0, [fp, #-0xc0]
    // 0x1191ce0: stur            x4, [fp, #-0xc8]
    // 0x1191ce4: r2 = LoadInt32Instr(r0)
    //     0x1191ce4: sbfx            x2, x0, #1, #0x1f
    //     0x1191ce8: tbz             w0, #0, #0x1191cf0
    //     0x1191cec: ldur            x2, [x0, #7]
    // 0x1191cf0: mov             x1, x4
    // 0x1191cf4: ldur            x3, [fp, #-0xb8]
    // 0x1191cf8: r0 = NetworkImageLoadException()
    //     0x1191cf8: bl              #0x1191dfc  ; [package:flutter/src/painting/image_provider.dart] NetworkImageLoadException::NetworkImageLoadException
    // 0x1191cfc: ldur            x0, [fp, #-0xc8]
    // 0x1191d00: r0 = Throw()
    //     0x1191d00: bl              #0x13ddb2c  ; ThrowStub
    // 0x1191d04: brk             #0
    // 0x1191d08: ldur            x0, [fp, #-0xb8]
    // 0x1191d0c: r1 = Null
    //     0x1191d0c: mov             x1, NULL
    // 0x1191d10: r2 = 4
    //     0x1191d10: mov             x2, #4
    // 0x1191d14: r0 = AllocateArray()
    //     0x1191d14: bl              #0x13df928  ; AllocateArrayStub
    // 0x1191d18: r16 = "NetworkImage is an empty file: "
    //     0x1191d18: add             x16, PP, #0x94, lsl #12  ; [pp+0x94d78] "NetworkImage is an empty file: "
    //     0x1191d1c: ldr             x16, [x16, #0xd78]
    // 0x1191d20: StoreField: r0->field_f = r16
    //     0x1191d20: stur            w16, [x0, #0xf]
    // 0x1191d24: ldur            x1, [fp, #-0xb8]
    // 0x1191d28: StoreField: r0->field_13 = r1
    //     0x1191d28: stur            w1, [x0, #0x13]
    // 0x1191d2c: str             x0, [SP]
    // 0x1191d30: r0 = _interpolate()
    //     0x1191d30: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1191d34: stur            x0, [fp, #-0xb0]
    // 0x1191d38: r0 = _Exception()
    //     0x1191d38: bl              #0x8220c0  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x1191d3c: mov             x1, x0
    // 0x1191d40: ldur            x0, [fp, #-0xb0]
    // 0x1191d44: stur            x1, [fp, #-0xc0]
    // 0x1191d48: StoreField: r1->field_7 = r0
    //     0x1191d48: stur            w0, [x1, #7]
    // 0x1191d4c: mov             x0, x1
    // 0x1191d50: r0 = Throw()
    //     0x1191d50: bl              #0x13ddb2c  ; ThrowStub
    // 0x1191d54: brk             #0
    // 0x1191d58: sub             SP, fp, #0x100
    // 0x1191d5c: ldur            x2, [fp, #-0xd0]
    // 0x1191d60: mov             x3, x0
    // 0x1191d64: stur            x0, [fp, #-0xb0]
    // 0x1191d68: mov             x0, x1
    // 0x1191d6c: stur            x1, [fp, #-0xb8]
    // 0x1191d70: r1 = Function '<anonymous closure>':.
    //     0x1191d70: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d80] AnonymousClosure: (0x1191ebc), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0x1191a50)
    //     0x1191d74: ldr             x1, [x1, #0xd80]
    // 0x1191d78: r0 = AllocateClosure()
    //     0x1191d78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1191d7c: str             x0, [SP]
    // 0x1191d80: r0 = scheduleMicrotask()
    //     0x1191d80: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0x1191d84: ldur            x0, [fp, #-0xb0]
    // 0x1191d88: ldur            x1, [fp, #-0xb8]
    // 0x1191d8c: r0 = ReThrow()
    //     0x1191d8c: bl              #0x13ddb00  ; ReThrowStub
    // 0x1191d90: brk             #0
    // 0x1191d94: sub             SP, fp, #0x100
    // 0x1191d98: ldur            x2, [fp, #-0xd0]
    // 0x1191d9c: mov             x3, x0
    // 0x1191da0: stur            x0, [fp, #-0xb0]
    // 0x1191da4: mov             x0, x1
    // 0x1191da8: stur            x1, [fp, #-0xb8]
    // 0x1191dac: LoadField: r1 = r2->field_13
    //     0x1191dac: ldur            w1, [x2, #0x13]
    // 0x1191db0: DecompressPointer r1
    //     0x1191db0: add             x1, x1, HEAP, lsl #32
    // 0x1191db4: r0 = close()
    //     0x1191db4: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1191db8: r1 = Function '<anonymous closure>':.
    //     0x1191db8: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d70] AnonymousClosure: (0x1191f38), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0x1191a50)
    //     0x1191dbc: ldr             x1, [x1, #0xd70]
    // 0x1191dc0: r2 = Null
    //     0x1191dc0: mov             x2, NULL
    // 0x1191dc4: stur            x0, [fp, #-0xc0]
    // 0x1191dc8: r0 = AllocateClosure()
    //     0x1191dc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1191dcc: ldur            x1, [fp, #-0xc0]
    // 0x1191dd0: mov             x2, x0
    // 0x1191dd4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1191dd4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1191dd8: r0 = catchError()
    //     0x1191dd8: bl              #0x1291b1c  ; [dart:async] _Future::catchError
    // 0x1191ddc: ldur            x0, [fp, #-0xb0]
    // 0x1191de0: ldur            x1, [fp, #-0xb8]
    // 0x1191de4: r0 = ReThrow()
    //     0x1191de4: bl              #0x13ddb00  ; ReThrowStub
    // 0x1191de8: brk             #0
    // 0x1191dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191df0: b               #0x1191a7c
    // 0x1191df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1191df4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1191df8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1191df8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x1191ebc, size: 0x7c
    // 0x1191ebc: EnterFrame
    //     0x1191ebc: stp             fp, lr, [SP, #-0x10]!
    //     0x1191ec0: mov             fp, SP
    // 0x1191ec4: ldr             x0, [fp, #0x10]
    // 0x1191ec8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1191ec8: ldur            w1, [x0, #0x17]
    // 0x1191ecc: DecompressPointer r1
    //     0x1191ecc: add             x1, x1, HEAP, lsl #32
    // 0x1191ed0: CheckStackOverflow
    //     0x1191ed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191ed4: cmp             SP, x16
    //     0x1191ed8: b.ls            #0x1191f24
    // 0x1191edc: r0 = LoadStaticField(0x780)
    //     0x1191edc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1191ee0: ldr             x0, [x0, #0xf00]
    // 0x1191ee4: cmp             w0, NULL
    // 0x1191ee8: b.eq            #0x1191f2c
    // 0x1191eec: LoadField: r2 = r0->field_ab
    //     0x1191eec: ldur            w2, [x0, #0xab]
    // 0x1191ef0: DecompressPointer r2
    //     0x1191ef0: add             x2, x2, HEAP, lsl #32
    // 0x1191ef4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1191ef8: cmp             w2, w16
    // 0x1191efc: b.eq            #0x1191f30
    // 0x1191f00: LoadField: r0 = r1->field_f
    //     0x1191f00: ldur            w0, [x1, #0xf]
    // 0x1191f04: DecompressPointer r0
    //     0x1191f04: add             x0, x0, HEAP, lsl #32
    // 0x1191f08: mov             x1, x2
    // 0x1191f0c: mov             x2, x0
    // 0x1191f10: r0 = evict()
    //     0x1191f10: bl              #0x118b5f8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0x1191f14: r0 = Null
    //     0x1191f14: mov             x0, NULL
    // 0x1191f18: LeaveFrame
    //     0x1191f18: mov             SP, fp
    //     0x1191f1c: ldp             fp, lr, [SP], #0x10
    // 0x1191f20: ret
    //     0x1191f20: ret             
    // 0x1191f24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191f24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191f28: b               #0x1191edc
    // 0x1191f2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1191f2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1191f30: r9 = _imageCache
    //     0x1191f30: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x1191f34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1191f34: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x1191f38, size: 0x88
    // 0x1191f38: EnterFrame
    //     0x1191f38: stp             fp, lr, [SP, #-0x10]!
    //     0x1191f3c: mov             fp, SP
    // 0x1191f40: AllocStack(0x8)
    //     0x1191f40: sub             SP, SP, #8
    // 0x1191f44: CheckStackOverflow
    //     0x1191f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191f48: cmp             SP, x16
    //     0x1191f4c: b.ls            #0x1191fb8
    // 0x1191f50: r1 = <List<Object>>
    //     0x1191f50: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x1191f54: r0 = ErrorDescription()
    //     0x1191f54: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1191f58: mov             x1, x0
    // 0x1191f5c: r2 = "while closing chunkEvents stream in NetworkImage.load"
    //     0x1191f5c: add             x2, PP, #0x94, lsl #12  ; [pp+0x94d88] "while closing chunkEvents stream in NetworkImage.load"
    //     0x1191f60: ldr             x2, [x2, #0xd88]
    // 0x1191f64: r3 = Instance_DiagnosticLevel
    //     0x1191f64: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1191f68: stur            x0, [fp, #-8]
    // 0x1191f6c: r0 = _ErrorDiagnostic()
    //     0x1191f6c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1191f70: r0 = FlutterErrorDetails()
    //     0x1191f70: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x1191f74: mov             x1, x0
    // 0x1191f78: ldr             x0, [fp, #0x18]
    // 0x1191f7c: StoreField: r1->field_7 = r0
    //     0x1191f7c: stur            w0, [x1, #7]
    // 0x1191f80: ldr             x0, [fp, #0x10]
    // 0x1191f84: StoreField: r1->field_b = r0
    //     0x1191f84: stur            w0, [x1, #0xb]
    // 0x1191f88: r0 = "painting library"
    //     0x1191f88: add             x0, PP, #0x85, lsl #12  ; [pp+0x851d0] "painting library"
    //     0x1191f8c: ldr             x0, [x0, #0x1d0]
    // 0x1191f90: StoreField: r1->field_f = r0
    //     0x1191f90: stur            w0, [x1, #0xf]
    // 0x1191f94: ldur            x0, [fp, #-8]
    // 0x1191f98: StoreField: r1->field_13 = r0
    //     0x1191f98: stur            w0, [x1, #0x13]
    // 0x1191f9c: r0 = false
    //     0x1191f9c: add             x0, NULL, #0x30  ; false
    // 0x1191fa0: StoreField: r1->field_1b = r0
    //     0x1191fa0: stur            w0, [x1, #0x1b]
    // 0x1191fa4: r0 = reportError()
    //     0x1191fa4: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x1191fa8: r0 = Null
    //     0x1191fa8: mov             x0, NULL
    // 0x1191fac: LeaveFrame
    //     0x1191fac: mov             SP, fp
    //     0x1191fb0: ldp             fp, lr, [SP], #0x10
    // 0x1191fb4: ret
    //     0x1191fb4: ret             
    // 0x1191fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191fb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191fbc: b               #0x1191f50
  }
  [closure] void <anonymous closure>(dynamic, int, int?) {
    // ** addr: 0x1191fc0, size: 0x80
    // 0x1191fc0: EnterFrame
    //     0x1191fc0: stp             fp, lr, [SP, #-0x10]!
    //     0x1191fc4: mov             fp, SP
    // 0x1191fc8: AllocStack(0x10)
    //     0x1191fc8: sub             SP, SP, #0x10
    // 0x1191fcc: SetupParameters([dynamic _ /* r0 */])
    //     0x1191fcc: ldr             x0, [fp, #0x20]
    //     0x1191fd0: ldur            w1, [x0, #0x17]
    //     0x1191fd4: add             x1, x1, HEAP, lsl #32
    // 0x1191fd8: CheckStackOverflow
    //     0x1191fd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1191fdc: cmp             SP, x16
    //     0x1191fe0: b.ls            #0x1192038
    // 0x1191fe4: LoadField: r0 = r1->field_13
    //     0x1191fe4: ldur            w0, [x1, #0x13]
    // 0x1191fe8: DecompressPointer r0
    //     0x1191fe8: add             x0, x0, HEAP, lsl #32
    // 0x1191fec: ldr             x1, [fp, #0x18]
    // 0x1191ff0: stur            x0, [fp, #-0x10]
    // 0x1191ff4: r2 = LoadInt32Instr(r1)
    //     0x1191ff4: sbfx            x2, x1, #1, #0x1f
    //     0x1191ff8: tbz             w1, #0, #0x1192000
    //     0x1191ffc: ldur            x2, [x1, #7]
    // 0x1192000: stur            x2, [fp, #-8]
    // 0x1192004: r0 = ImageChunkEvent()
    //     0x1192004: bl              #0x1187644  ; AllocateImageChunkEventStub -> ImageChunkEvent (size=0x14)
    // 0x1192008: mov             x1, x0
    // 0x119200c: ldur            x0, [fp, #-8]
    // 0x1192010: StoreField: r1->field_7 = r0
    //     0x1192010: stur            x0, [x1, #7]
    // 0x1192014: ldr             x0, [fp, #0x10]
    // 0x1192018: StoreField: r1->field_f = r0
    //     0x1192018: stur            w0, [x1, #0xf]
    // 0x119201c: mov             x2, x1
    // 0x1192020: ldur            x1, [fp, #-0x10]
    // 0x1192024: r0 = add()
    //     0x1192024: bl              #0x8014f8  ; [dart:async] _StreamController::add
    // 0x1192028: r0 = Null
    //     0x1192028: mov             x0, NULL
    // 0x119202c: LeaveFrame
    //     0x119202c: mov             SP, fp
    //     0x1192030: ldp             fp, lr, [SP], #0x10
    // 0x1192034: ret
    //     0x1192034: ret             
    // 0x1192038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192038: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119203c: b               #0x1191fe4
  }
  static HttpClient _sharedHttpClient() {
    // ** addr: 0x1192040, size: 0x4c
    // 0x1192040: EnterFrame
    //     0x1192040: stp             fp, lr, [SP, #-0x10]!
    //     0x1192044: mov             fp, SP
    // 0x1192048: AllocStack(0x8)
    //     0x1192048: sub             SP, SP, #8
    // 0x119204c: CheckStackOverflow
    //     0x119204c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192050: cmp             SP, x16
    //     0x1192054: b.ls            #0x1192084
    // 0x1192058: r0 = current()
    //     0x1192058: bl              #0x90c2d8  ; [dart:_http] HttpOverrides::current
    // 0x119205c: r0 = _HttpClient()
    //     0x119205c: bl              #0x90df74  ; Allocate_HttpClientStub -> _HttpClient (size=0x4c)
    // 0x1192060: mov             x1, x0
    // 0x1192064: stur            x0, [fp, #-8]
    // 0x1192068: r0 = _HttpClient()
    //     0x1192068: bl              #0x90dc50  ; [dart:_http] _HttpClient::_HttpClient
    // 0x119206c: ldur            x0, [fp, #-8]
    // 0x1192070: r1 = false
    //     0x1192070: add             x1, NULL, #0x30  ; false
    // 0x1192074: StoreField: r0->field_43 = r1
    //     0x1192074: stur            w1, [x0, #0x43]
    // 0x1192078: LeaveFrame
    //     0x1192078: mov             SP, fp
    //     0x119207c: ldp             fp, lr, [SP], #0x10
    // 0x1192080: ret
    //     0x1192080: ret             
    // 0x1192084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1192084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1192088: b               #0x1192058
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x119208c, size: 0xf8
    // 0x119208c: EnterFrame
    //     0x119208c: stp             fp, lr, [SP, #-0x10]!
    //     0x1192090: mov             fp, SP
    // 0x1192094: AllocStack(0x18)
    //     0x1192094: sub             SP, SP, #0x18
    // 0x1192098: SetupParameters([dynamic _ /* r0 */])
    //     0x1192098: ldr             x0, [fp, #0x10]
    //     0x119209c: ldur            w2, [x0, #0x17]
    //     0x11920a0: add             x2, x2, HEAP, lsl #32
    //     0x11920a4: stur            x2, [fp, #-0x10]
    // 0x11920a8: LoadField: r0 = r2->field_f
    //     0x11920a8: ldur            w0, [x2, #0xf]
    // 0x11920ac: DecompressPointer r0
    //     0x11920ac: add             x0, x0, HEAP, lsl #32
    // 0x11920b0: stur            x0, [fp, #-8]
    // 0x11920b4: r1 = <ImageProvider<Object>>
    //     0x11920b4: add             x1, PP, #0x94, lsl #12  ; [pp+0x94cf0] TypeArguments: <ImageProvider<Object>>
    //     0x11920b8: ldr             x1, [x1, #0xcf0]
    // 0x11920bc: r0 = DiagnosticsProperty()
    //     0x11920bc: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x11920c0: mov             x2, x0
    // 0x11920c4: r0 = Instance__NoDefaultValue
    //     0x11920c4: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x11920c8: stur            x2, [fp, #-0x18]
    // 0x11920cc: StoreField: r2->field_23 = r0
    //     0x11920cc: stur            w0, [x2, #0x23]
    // 0x11920d0: r3 = false
    //     0x11920d0: add             x3, NULL, #0x30  ; false
    // 0x11920d4: StoreField: r2->field_13 = r3
    //     0x11920d4: stur            w3, [x2, #0x13]
    // 0x11920d8: r4 = true
    //     0x11920d8: add             x4, NULL, #0x20  ; true
    // 0x11920dc: StoreField: r2->field_1b = r4
    //     0x11920dc: stur            w4, [x2, #0x1b]
    // 0x11920e0: ldur            x1, [fp, #-8]
    // 0x11920e4: ArrayStore: r2[0] = r1  ; List_4
    //     0x11920e4: stur            w1, [x2, #0x17]
    // 0x11920e8: r5 = Instance_DiagnosticLevel
    //     0x11920e8: ldr             x5, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x11920ec: StoreField: r2->field_27 = r5
    //     0x11920ec: stur            w5, [x2, #0x27]
    // 0x11920f0: ldur            x1, [fp, #-0x10]
    // 0x11920f4: LoadField: r6 = r1->field_13
    //     0x11920f4: ldur            w6, [x1, #0x13]
    // 0x11920f8: DecompressPointer r6
    //     0x11920f8: add             x6, x6, HEAP, lsl #32
    // 0x11920fc: stur            x6, [fp, #-8]
    // 0x1192100: r1 = <NetworkImage>
    //     0x1192100: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7bb68] TypeArguments: <NetworkImage>
    //     0x1192104: ldr             x1, [x1, #0xb68]
    // 0x1192108: r0 = DiagnosticsProperty()
    //     0x1192108: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x119210c: mov             x3, x0
    // 0x1192110: r0 = Instance__NoDefaultValue
    //     0x1192110: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x1192114: stur            x3, [fp, #-0x10]
    // 0x1192118: StoreField: r3->field_23 = r0
    //     0x1192118: stur            w0, [x3, #0x23]
    // 0x119211c: r0 = false
    //     0x119211c: add             x0, NULL, #0x30  ; false
    // 0x1192120: StoreField: r3->field_13 = r0
    //     0x1192120: stur            w0, [x3, #0x13]
    // 0x1192124: r0 = true
    //     0x1192124: add             x0, NULL, #0x20  ; true
    // 0x1192128: StoreField: r3->field_1b = r0
    //     0x1192128: stur            w0, [x3, #0x1b]
    // 0x119212c: ldur            x0, [fp, #-8]
    // 0x1192130: ArrayStore: r3[0] = r0  ; List_4
    //     0x1192130: stur            w0, [x3, #0x17]
    // 0x1192134: r0 = Instance_DiagnosticLevel
    //     0x1192134: ldr             x0, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1192138: StoreField: r3->field_27 = r0
    //     0x1192138: stur            w0, [x3, #0x27]
    // 0x119213c: r1 = Null
    //     0x119213c: mov             x1, NULL
    // 0x1192140: r2 = 4
    //     0x1192140: mov             x2, #4
    // 0x1192144: r0 = AllocateArray()
    //     0x1192144: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192148: mov             x2, x0
    // 0x119214c: ldur            x0, [fp, #-0x18]
    // 0x1192150: stur            x2, [fp, #-8]
    // 0x1192154: StoreField: r2->field_f = r0
    //     0x1192154: stur            w0, [x2, #0xf]
    // 0x1192158: ldur            x0, [fp, #-0x10]
    // 0x119215c: StoreField: r2->field_13 = r0
    //     0x119215c: stur            w0, [x2, #0x13]
    // 0x1192160: r1 = <DiagnosticsNode>
    //     0x1192160: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x1192164: r0 = AllocateGrowableArray()
    //     0x1192164: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1192168: ldur            x1, [fp, #-8]
    // 0x119216c: StoreField: r0->field_f = r1
    //     0x119216c: stur            w1, [x0, #0xf]
    // 0x1192170: r1 = 4
    //     0x1192170: mov             x1, #4
    // 0x1192174: StoreField: r0->field_b = r1
    //     0x1192174: stur            w1, [x0, #0xb]
    // 0x1192178: LeaveFrame
    //     0x1192178: mov             SP, fp
    //     0x119217c: ldp             fp, lr, [SP], #0x10
    // 0x1192180: ret
    //     0x1192180: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x129227c, size: 0x104
    // 0x129227c: EnterFrame
    //     0x129227c: stp             fp, lr, [SP, #-0x10]!
    //     0x1292280: mov             fp, SP
    // 0x1292284: AllocStack(0x18)
    //     0x1292284: sub             SP, SP, #0x18
    // 0x1292288: CheckStackOverflow
    //     0x1292288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129228c: cmp             SP, x16
    //     0x1292290: b.ls            #0x1292378
    // 0x1292294: ldr             x0, [fp, #0x10]
    // 0x1292298: cmp             w0, NULL
    // 0x129229c: b.ne            #0x12922b0
    // 0x12922a0: r0 = false
    //     0x12922a0: add             x0, NULL, #0x30  ; false
    // 0x12922a4: LeaveFrame
    //     0x12922a4: mov             SP, fp
    //     0x12922a8: ldp             fp, lr, [SP], #0x10
    // 0x12922ac: ret
    //     0x12922ac: ret             
    // 0x12922b0: str             x0, [SP]
    // 0x12922b4: r0 = runtimeType()
    //     0x12922b4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12922b8: r1 = LoadClassIdInstr(r0)
    //     0x12922b8: ldur            x1, [x0, #-1]
    //     0x12922bc: ubfx            x1, x1, #0xc, #0x14
    // 0x12922c0: r16 = NetworkImage
    //     0x12922c0: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8af30] Type: NetworkImage
    //     0x12922c4: ldr             x16, [x16, #0xf30]
    // 0x12922c8: stp             x16, x0, [SP]
    // 0x12922cc: mov             x0, x1
    // 0x12922d0: mov             lr, x0
    // 0x12922d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12922d8: blr             lr
    // 0x12922dc: tbz             w0, #4, #0x12922f0
    // 0x12922e0: r0 = false
    //     0x12922e0: add             x0, NULL, #0x30  ; false
    // 0x12922e4: LeaveFrame
    //     0x12922e4: mov             SP, fp
    //     0x12922e8: ldp             fp, lr, [SP], #0x10
    // 0x12922ec: ret
    //     0x12922ec: ret             
    // 0x12922f0: ldr             x0, [fp, #0x10]
    // 0x12922f4: r1 = 60
    //     0x12922f4: mov             x1, #0x3c
    // 0x12922f8: branchIfSmi(r0, 0x1292304)
    //     0x12922f8: tbz             w0, #0, #0x1292304
    // 0x12922fc: r1 = LoadClassIdInstr(r0)
    //     0x12922fc: ldur            x1, [x0, #-1]
    //     0x1292300: ubfx            x1, x1, #0xc, #0x14
    // 0x1292304: cmp             x1, #0xe11
    // 0x1292308: b.ne            #0x1292368
    // 0x129230c: ldr             x1, [fp, #0x18]
    // 0x1292310: LoadField: r2 = r0->field_b
    //     0x1292310: ldur            w2, [x0, #0xb]
    // 0x1292314: DecompressPointer r2
    //     0x1292314: add             x2, x2, HEAP, lsl #32
    // 0x1292318: LoadField: r0 = r1->field_b
    //     0x1292318: ldur            w0, [x1, #0xb]
    // 0x129231c: DecompressPointer r0
    //     0x129231c: add             x0, x0, HEAP, lsl #32
    // 0x1292320: r1 = LoadClassIdInstr(r2)
    //     0x1292320: ldur            x1, [x2, #-1]
    //     0x1292324: ubfx            x1, x1, #0xc, #0x14
    // 0x1292328: stp             x0, x2, [SP]
    // 0x129232c: mov             x0, x1
    // 0x1292330: mov             lr, x0
    // 0x1292334: ldr             lr, [x21, lr, lsl #3]
    // 0x1292338: blr             lr
    // 0x129233c: tbnz            w0, #4, #0x1292368
    // 0x1292340: d0 = 1.000000
    //     0x1292340: fmov            d0, #1.00000000
    // 0x1292344: fcmp            d0, d0
    // 0x1292348: b.ne            #0x1292368
    // 0x129234c: r16 = <String, String>
    //     0x129234c: ldr             x16, [PP, #0x7c88]  ; [pp+0x7c88] TypeArguments: <String, String>
    // 0x1292350: stp             NULL, x16, [SP, #8]
    // 0x1292354: str             NULL, [SP]
    // 0x1292358: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x1292358: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x129235c: r0 = mapEquals()
    //     0x129235c: bl              #0xc015b8  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0x1292360: r0 = true
    //     0x1292360: add             x0, NULL, #0x20  ; true
    // 0x1292364: b               #0x129236c
    // 0x1292368: r0 = false
    //     0x1292368: add             x0, NULL, #0x30  ; false
    // 0x129236c: LeaveFrame
    //     0x129236c: mov             SP, fp
    //     0x1292370: ldp             fp, lr, [SP], #0x10
    // 0x1292374: ret
    //     0x1292374: ret             
    // 0x1292378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129237c: b               #0x1292294
  }
}
