// lib: , url: package:flutter/src/painting/fractional_offset.dart

// class id: 1048994, size: 0x8
class :: {
}

// class id: 2959, size: 0x18, field offset: 0x18
//   const constructor, 
class FractionalOffset extends Alignment {

  _Mint field_8;
  _Mint field_10;

  Alignment +(FractionalOffset, Alignment) {
    // ** addr: 0xddbfd4, size: 0x88
    // 0xddbfd4: EnterFrame
    //     0xddbfd4: stp             fp, lr, [SP, #-0x10]!
    //     0xddbfd8: mov             fp, SP
    // 0xddbfdc: CheckStackOverflow
    //     0xddbfdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xddbfe0: cmp             SP, x16
    //     0xddbfe4: b.ls            #0xddc03c
    // 0xddbfe8: ldr             x0, [fp, #0x10]
    // 0xddbfec: r2 = Null
    //     0xddbfec: mov             x2, NULL
    // 0xddbff0: r1 = Null
    //     0xddbff0: mov             x1, NULL
    // 0xddbff4: r4 = 60
    //     0xddbff4: mov             x4, #0x3c
    // 0xddbff8: branchIfSmi(r0, 0xddc004)
    //     0xddbff8: tbz             w0, #0, #0xddc004
    // 0xddbffc: r4 = LoadClassIdInstr(r0)
    //     0xddbffc: ldur            x4, [x0, #-1]
    //     0xddc000: ubfx            x4, x4, #0xc, #0x14
    // 0xddc004: sub             x4, x4, #0xb8e
    // 0xddc008: cmp             x4, #1
    // 0xddc00c: b.ls            #0xddc024
    // 0xddc010: r8 = Alignment
    //     0xddc010: add             x8, PP, #0x82, lsl #12  ; [pp+0x827c0] Type: Alignment
    //     0xddc014: ldr             x8, [x8, #0x7c0]
    // 0xddc018: r3 = Null
    //     0xddc018: add             x3, PP, #0xaa, lsl #12  ; [pp+0xaafe8] Null
    //     0xddc01c: ldr             x3, [x3, #0xfe8]
    // 0xddc020: r0 = Alignment()
    //     0xddc020: bl              #0x82f6b8  ; IsType_Alignment_Stub
    // 0xddc024: ldr             x1, [fp, #0x18]
    // 0xddc028: ldr             x2, [fp, #0x10]
    // 0xddc02c: r0 = +()
    //     0xddc02c: bl              #0xddc044  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::+
    // 0xddc030: LeaveFrame
    //     0xddc030: mov             SP, fp
    //     0xddc034: ldp             fp, lr, [SP], #0x10
    // 0xddc038: ret
    //     0xddc038: ret             
    // 0xddc03c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xddc03c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xddc040: b               #0xddbfe8
  }
  Alignment +(FractionalOffset, Alignment) {
    // ** addr: 0xddc044, size: 0xb8
    // 0xddc044: EnterFrame
    //     0xddc044: stp             fp, lr, [SP, #-0x10]!
    //     0xddc048: mov             fp, SP
    // 0xddc04c: AllocStack(0x10)
    //     0xddc04c: sub             SP, SP, #0x10
    // 0xddc050: CheckStackOverflow
    //     0xddc050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xddc054: cmp             SP, x16
    //     0xddc058: b.ls            #0xddc0f4
    // 0xddc05c: r0 = LoadClassIdInstr(r2)
    //     0xddc05c: ldur            x0, [x2, #-1]
    //     0xddc060: ubfx            x0, x0, #0xc, #0x14
    // 0xddc064: cmp             x0, #0xb8f
    // 0xddc068: b.eq            #0xddc07c
    // 0xddc06c: r0 = +()
    //     0xddc06c: bl              #0x82f4d0  ; [package:flutter/src/painting/alignment.dart] Alignment::+
    // 0xddc070: LeaveFrame
    //     0xddc070: mov             SP, fp
    //     0xddc074: ldp             fp, lr, [SP], #0x10
    // 0xddc078: ret
    //     0xddc078: ret             
    // 0xddc07c: d1 = 1.000000
    //     0xddc07c: fmov            d1, #1.00000000
    // 0xddc080: d0 = 2.000000
    //     0xddc080: fmov            d0, #2.00000000
    // 0xddc084: LoadField: d2 = r1->field_7
    //     0xddc084: ldur            d2, [x1, #7]
    // 0xddc088: fadd            d3, d2, d1
    // 0xddc08c: fdiv            d2, d3, d0
    // 0xddc090: LoadField: d3 = r2->field_7
    //     0xddc090: ldur            d3, [x2, #7]
    // 0xddc094: fadd            d4, d3, d1
    // 0xddc098: fdiv            d3, d4, d0
    // 0xddc09c: fadd            d4, d2, d3
    // 0xddc0a0: LoadField: d2 = r1->field_f
    //     0xddc0a0: ldur            d2, [x1, #0xf]
    // 0xddc0a4: fadd            d3, d2, d1
    // 0xddc0a8: fdiv            d2, d3, d0
    // 0xddc0ac: LoadField: d3 = r2->field_f
    //     0xddc0ac: ldur            d3, [x2, #0xf]
    // 0xddc0b0: fadd            d5, d3, d1
    // 0xddc0b4: fdiv            d3, d5, d0
    // 0xddc0b8: fadd            d5, d2, d3
    // 0xddc0bc: fmul            d2, d4, d0
    // 0xddc0c0: fsub            d3, d2, d1
    // 0xddc0c4: stur            d3, [fp, #-0x10]
    // 0xddc0c8: fmul            d2, d5, d0
    // 0xddc0cc: fsub            d0, d2, d1
    // 0xddc0d0: stur            d0, [fp, #-8]
    // 0xddc0d4: r0 = FractionalOffset()
    //     0xddc0d4: bl              #0xddc0fc  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xddc0d8: ldur            d0, [fp, #-0x10]
    // 0xddc0dc: StoreField: r0->field_7 = d0
    //     0xddc0dc: stur            d0, [x0, #7]
    // 0xddc0e0: ldur            d0, [fp, #-8]
    // 0xddc0e4: StoreField: r0->field_f = d0
    //     0xddc0e4: stur            d0, [x0, #0xf]
    // 0xddc0e8: LeaveFrame
    //     0xddc0e8: mov             SP, fp
    //     0xddc0ec: ldp             fp, lr, [SP], #0x10
    // 0xddc0f0: ret
    //     0xddc0f0: ret             
    // 0xddc0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xddc0f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xddc0f8: b               #0xddc05c
  }
  double dyn:get:dy(FractionalOffset) {
    // ** addr: 0xddc120, size: 0x80
    // 0xddc120: EnterFrame
    //     0xddc120: stp             fp, lr, [SP, #-0x10]!
    //     0xddc124: mov             fp, SP
    // 0xddc128: d1 = 1.000000
    //     0xddc128: fmov            d1, #1.00000000
    // 0xddc12c: d0 = 2.000000
    //     0xddc12c: fmov            d0, #2.00000000
    // 0xddc130: ldr             x1, [fp, #0x10]
    // 0xddc134: LoadField: d2 = r1->field_f
    //     0xddc134: ldur            d2, [x1, #0xf]
    // 0xddc138: fadd            d3, d2, d1
    // 0xddc13c: fdiv            d1, d3, d0
    // 0xddc140: r0 = inline_Allocate_Double()
    //     0xddc140: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xddc144: add             x0, x0, #0x10
    //     0xddc148: cmp             x1, x0
    //     0xddc14c: b.ls            #0xddc178
    //     0xddc150: str             x0, [THR, #0x60]  ; THR::top
    //     0xddc154: sub             x0, x0, #0xf
    //     0xddc158: mov             x1, #0xe19c
    //     0xddc15c: movk            x1, #3, lsl #16
    //     0xddc160: stur            x1, [x0, #-1]
    // 0xddc164: dmb             ishst
    // 0xddc168: StoreField: r0->field_7 = d1
    //     0xddc168: stur            d1, [x0, #7]
    // 0xddc16c: LeaveFrame
    //     0xddc16c: mov             SP, fp
    //     0xddc170: ldp             fp, lr, [SP], #0x10
    // 0xddc174: ret
    //     0xddc174: ret             
    // 0xddc178: SaveReg d1
    //     0xddc178: str             q1, [SP, #-0x10]!
    // 0xddc17c: r0 = AllocateDouble()
    //     0xddc17c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xddc180: RestoreReg d1
    //     0xddc180: ldr             q1, [SP], #0x10
    // 0xddc184: b               #0xddc168
  }
  Alignment -(FractionalOffset, Alignment) {
    // ** addr: 0xddc1a0, size: 0x88
    // 0xddc1a0: EnterFrame
    //     0xddc1a0: stp             fp, lr, [SP, #-0x10]!
    //     0xddc1a4: mov             fp, SP
    // 0xddc1a8: CheckStackOverflow
    //     0xddc1a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xddc1ac: cmp             SP, x16
    //     0xddc1b0: b.ls            #0xddc208
    // 0xddc1b4: ldr             x0, [fp, #0x10]
    // 0xddc1b8: r2 = Null
    //     0xddc1b8: mov             x2, NULL
    // 0xddc1bc: r1 = Null
    //     0xddc1bc: mov             x1, NULL
    // 0xddc1c0: r4 = 60
    //     0xddc1c0: mov             x4, #0x3c
    // 0xddc1c4: branchIfSmi(r0, 0xddc1d0)
    //     0xddc1c4: tbz             w0, #0, #0xddc1d0
    // 0xddc1c8: r4 = LoadClassIdInstr(r0)
    //     0xddc1c8: ldur            x4, [x0, #-1]
    //     0xddc1cc: ubfx            x4, x4, #0xc, #0x14
    // 0xddc1d0: sub             x4, x4, #0xb8e
    // 0xddc1d4: cmp             x4, #1
    // 0xddc1d8: b.ls            #0xddc1f0
    // 0xddc1dc: r8 = Alignment
    //     0xddc1dc: add             x8, PP, #0x82, lsl #12  ; [pp+0x827c0] Type: Alignment
    //     0xddc1e0: ldr             x8, [x8, #0x7c0]
    // 0xddc1e4: r3 = Null
    //     0xddc1e4: add             x3, PP, #0xaa, lsl #12  ; [pp+0xaaff8] Null
    //     0xddc1e8: ldr             x3, [x3, #0xff8]
    // 0xddc1ec: r0 = Alignment()
    //     0xddc1ec: bl              #0x82f6b8  ; IsType_Alignment_Stub
    // 0xddc1f0: ldr             x1, [fp, #0x18]
    // 0xddc1f4: ldr             x2, [fp, #0x10]
    // 0xddc1f8: r0 = -()
    //     0xddc1f8: bl              #0xddc210  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::-
    // 0xddc1fc: LeaveFrame
    //     0xddc1fc: mov             SP, fp
    //     0xddc200: ldp             fp, lr, [SP], #0x10
    // 0xddc204: ret
    //     0xddc204: ret             
    // 0xddc208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xddc208: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xddc20c: b               #0xddc1b4
  }
  Alignment -(FractionalOffset, Alignment) {
    // ** addr: 0xddc210, size: 0xb8
    // 0xddc210: EnterFrame
    //     0xddc210: stp             fp, lr, [SP, #-0x10]!
    //     0xddc214: mov             fp, SP
    // 0xddc218: AllocStack(0x10)
    //     0xddc218: sub             SP, SP, #0x10
    // 0xddc21c: CheckStackOverflow
    //     0xddc21c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xddc220: cmp             SP, x16
    //     0xddc224: b.ls            #0xddc2c0
    // 0xddc228: r0 = LoadClassIdInstr(r2)
    //     0xddc228: ldur            x0, [x2, #-1]
    //     0xddc22c: ubfx            x0, x0, #0xc, #0x14
    // 0xddc230: cmp             x0, #0xb8f
    // 0xddc234: b.eq            #0xddc248
    // 0xddc238: r0 = -()
    //     0xddc238: bl              #0x82f66c  ; [package:flutter/src/painting/alignment.dart] Alignment::-
    // 0xddc23c: LeaveFrame
    //     0xddc23c: mov             SP, fp
    //     0xddc240: ldp             fp, lr, [SP], #0x10
    // 0xddc244: ret
    //     0xddc244: ret             
    // 0xddc248: d1 = 1.000000
    //     0xddc248: fmov            d1, #1.00000000
    // 0xddc24c: d0 = 2.000000
    //     0xddc24c: fmov            d0, #2.00000000
    // 0xddc250: LoadField: d2 = r1->field_7
    //     0xddc250: ldur            d2, [x1, #7]
    // 0xddc254: fadd            d3, d2, d1
    // 0xddc258: fdiv            d2, d3, d0
    // 0xddc25c: LoadField: d3 = r2->field_7
    //     0xddc25c: ldur            d3, [x2, #7]
    // 0xddc260: fadd            d4, d3, d1
    // 0xddc264: fdiv            d3, d4, d0
    // 0xddc268: fsub            d4, d2, d3
    // 0xddc26c: LoadField: d2 = r1->field_f
    //     0xddc26c: ldur            d2, [x1, #0xf]
    // 0xddc270: fadd            d3, d2, d1
    // 0xddc274: fdiv            d2, d3, d0
    // 0xddc278: LoadField: d3 = r2->field_f
    //     0xddc278: ldur            d3, [x2, #0xf]
    // 0xddc27c: fadd            d5, d3, d1
    // 0xddc280: fdiv            d3, d5, d0
    // 0xddc284: fsub            d5, d2, d3
    // 0xddc288: fmul            d2, d4, d0
    // 0xddc28c: fsub            d3, d2, d1
    // 0xddc290: stur            d3, [fp, #-0x10]
    // 0xddc294: fmul            d2, d5, d0
    // 0xddc298: fsub            d0, d2, d1
    // 0xddc29c: stur            d0, [fp, #-8]
    // 0xddc2a0: r0 = FractionalOffset()
    //     0xddc2a0: bl              #0xddc0fc  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xddc2a4: ldur            d0, [fp, #-0x10]
    // 0xddc2a8: StoreField: r0->field_7 = d0
    //     0xddc2a8: stur            d0, [x0, #7]
    // 0xddc2ac: ldur            d0, [fp, #-8]
    // 0xddc2b0: StoreField: r0->field_f = d0
    //     0xddc2b0: stur            d0, [x0, #0xf]
    // 0xddc2b4: LeaveFrame
    //     0xddc2b4: mov             SP, fp
    //     0xddc2b8: ldp             fp, lr, [SP], #0x10
    // 0xddc2bc: ret
    //     0xddc2bc: ret             
    // 0xddc2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xddc2c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xddc2c4: b               #0xddc228
  }
  double dyn:get:dx(FractionalOffset) {
    // ** addr: 0xddc2e0, size: 0x80
    // 0xddc2e0: EnterFrame
    //     0xddc2e0: stp             fp, lr, [SP, #-0x10]!
    //     0xddc2e4: mov             fp, SP
    // 0xddc2e8: d1 = 1.000000
    //     0xddc2e8: fmov            d1, #1.00000000
    // 0xddc2ec: d0 = 2.000000
    //     0xddc2ec: fmov            d0, #2.00000000
    // 0xddc2f0: ldr             x1, [fp, #0x10]
    // 0xddc2f4: LoadField: d2 = r1->field_7
    //     0xddc2f4: ldur            d2, [x1, #7]
    // 0xddc2f8: fadd            d3, d2, d1
    // 0xddc2fc: fdiv            d1, d3, d0
    // 0xddc300: r0 = inline_Allocate_Double()
    //     0xddc300: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xddc304: add             x0, x0, #0x10
    //     0xddc308: cmp             x1, x0
    //     0xddc30c: b.ls            #0xddc338
    //     0xddc310: str             x0, [THR, #0x60]  ; THR::top
    //     0xddc314: sub             x0, x0, #0xf
    //     0xddc318: mov             x1, #0xe19c
    //     0xddc31c: movk            x1, #3, lsl #16
    //     0xddc320: stur            x1, [x0, #-1]
    // 0xddc324: dmb             ishst
    // 0xddc328: StoreField: r0->field_7 = d1
    //     0xddc328: stur            d1, [x0, #7]
    // 0xddc32c: LeaveFrame
    //     0xddc32c: mov             SP, fp
    //     0xddc330: ldp             fp, lr, [SP], #0x10
    // 0xddc334: ret
    //     0xddc334: ret             
    // 0xddc338: SaveReg d1
    //     0xddc338: str             q1, [SP, #-0x10]!
    // 0xddc33c: r0 = AllocateDouble()
    //     0xddc33c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xddc340: RestoreReg d1
    //     0xddc340: ldr             q1, [SP], #0x10
    // 0xddc344: b               #0xddc328
  }
  FractionalOffset *(FractionalOffset, double) {
    // ** addr: 0xddc360, size: 0x50
    // 0xddc360: EnterFrame
    //     0xddc360: stp             fp, lr, [SP, #-0x10]!
    //     0xddc364: mov             fp, SP
    // 0xddc368: CheckStackOverflow
    //     0xddc368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xddc36c: cmp             SP, x16
    //     0xddc370: b.ls            #0xddc390
    // 0xddc374: ldr             x0, [fp, #0x10]
    // 0xddc378: LoadField: d0 = r0->field_7
    //     0xddc378: ldur            d0, [x0, #7]
    // 0xddc37c: ldr             x1, [fp, #0x18]
    // 0xddc380: r0 = *()
    //     0xddc380: bl              #0x12ffabc  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::*
    // 0xddc384: LeaveFrame
    //     0xddc384: mov             SP, fp
    //     0xddc388: ldp             fp, lr, [SP], #0x10
    // 0xddc38c: ret
    //     0xddc38c: ret             
    // 0xddc390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xddc390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xddc394: b               #0xddc374
  }
  FractionalOffset *(FractionalOffset, double) {
    // ** addr: 0x12ffabc, size: 0x6c
    // 0x12ffabc: EnterFrame
    //     0x12ffabc: stp             fp, lr, [SP, #-0x10]!
    //     0x12ffac0: mov             fp, SP
    // 0x12ffac4: AllocStack(0x10)
    //     0x12ffac4: sub             SP, SP, #0x10
    // 0x12ffac8: d2 = 1.000000
    //     0x12ffac8: fmov            d2, #1.00000000
    // 0x12ffacc: d1 = 2.000000
    //     0x12ffacc: fmov            d1, #2.00000000
    // 0x12ffad0: LoadField: d3 = r1->field_7
    //     0x12ffad0: ldur            d3, [x1, #7]
    // 0x12ffad4: fadd            d4, d3, d2
    // 0x12ffad8: fdiv            d3, d4, d1
    // 0x12ffadc: fmul            d4, d3, d0
    // 0x12ffae0: LoadField: d3 = r1->field_f
    //     0x12ffae0: ldur            d3, [x1, #0xf]
    // 0x12ffae4: fadd            d5, d3, d2
    // 0x12ffae8: fdiv            d3, d5, d1
    // 0x12ffaec: fmul            d5, d3, d0
    // 0x12ffaf0: fmul            d0, d4, d1
    // 0x12ffaf4: fsub            d3, d0, d2
    // 0x12ffaf8: stur            d3, [fp, #-0x10]
    // 0x12ffafc: fmul            d0, d5, d1
    // 0x12ffb00: fsub            d1, d0, d2
    // 0x12ffb04: stur            d1, [fp, #-8]
    // 0x12ffb08: r0 = FractionalOffset()
    //     0x12ffb08: bl              #0xddc0fc  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0x12ffb0c: ldur            d0, [fp, #-0x10]
    // 0x12ffb10: StoreField: r0->field_7 = d0
    //     0x12ffb10: stur            d0, [x0, #7]
    // 0x12ffb14: ldur            d0, [fp, #-8]
    // 0x12ffb18: StoreField: r0->field_f = d0
    //     0x12ffb18: stur            d0, [x0, #0xf]
    // 0x12ffb1c: LeaveFrame
    //     0x12ffb1c: mov             SP, fp
    //     0x12ffb20: ldp             fp, lr, [SP], #0x10
    // 0x12ffb24: ret
    //     0x12ffb24: ret             
  }
}
