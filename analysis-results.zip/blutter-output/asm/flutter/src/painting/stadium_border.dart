// lib: , url: package:flutter/src/painting/stadium_border.dart

// class id: 1049008, size: 0x8
class :: {
}

// class id: 3020, size: 0x18, field offset: 0xc
//   const constructor, 
class _StadiumToRoundedRectangleBorder extends OutlinedBorder {

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbff3d0, size: 0x38c
    // 0xbff3d0: EnterFrame
    //     0xbff3d0: stp             fp, lr, [SP, #-0x10]!
    //     0xbff3d4: mov             fp, SP
    // 0xbff3d8: AllocStack(0x50)
    //     0xbff3d8: sub             SP, SP, #0x50
    // 0xbff3dc: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, {dynamic textDirection = Null /* r4, fp-0x8 */})
    //     0xbff3dc: mov             x3, x1
    //     0xbff3e0: mov             x0, x2
    //     0xbff3e4: stur            x1, [fp, #-0x10]
    //     0xbff3e8: stur            x2, [fp, #-0x18]
    //     0xbff3ec: ldur            w1, [x4, #0x13]
    //     0xbff3f0: ldur            w2, [x4, #0x1f]
    //     0xbff3f4: add             x2, x2, HEAP, lsl #32
    //     0xbff3f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xbff3fc: ldr             x16, [x16, #0x210]
    //     0xbff400: cmp             w2, w16
    //     0xbff404: b.ne            #0xbff424
    //     0xbff408: ldur            w2, [x4, #0x23]
    //     0xbff40c: add             x2, x2, HEAP, lsl #32
    //     0xbff410: sub             w4, w1, w2
    //     0xbff414: add             x1, fp, w4, sxtw #2
    //     0xbff418: ldr             x1, [x1, #8]
    //     0xbff41c: mov             x4, x1
    //     0xbff420: b               #0xbff428
    //     0xbff424: mov             x4, NULL
    //     0xbff428: stur            x4, [fp, #-8]
    // 0xbff42c: CheckStackOverflow
    //     0xbff42c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbff430: cmp             SP, x16
    //     0xbff434: b.ls            #0xbff714
    // 0xbff438: mov             x1, x3
    // 0xbff43c: mov             x2, x0
    // 0xbff440: r0 = _adjustBorderRadius()
    //     0xbff440: bl              #0xbff75c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0xbff444: r1 = LoadClassIdInstr(r0)
    //     0xbff444: ldur            x1, [x0, #-1]
    //     0xbff448: ubfx            x1, x1, #0xc, #0x14
    // 0xbff44c: cmp             x1, #0xb88
    // 0xbff450: b.ne            #0xbff524
    // 0xbff454: ldur            x2, [fp, #-8]
    // 0xbff458: cmp             w2, NULL
    // 0xbff45c: b.eq            #0xbff71c
    // 0xbff460: LoadField: r1 = r2->field_7
    //     0xbff460: ldur            x1, [x2, #7]
    // 0xbff464: cmp             x1, #0
    // 0xbff468: b.gt            #0xbff4c8
    // 0xbff46c: LoadField: r1 = r0->field_b
    //     0xbff46c: ldur            w1, [x0, #0xb]
    // 0xbff470: DecompressPointer r1
    //     0xbff470: add             x1, x1, HEAP, lsl #32
    // 0xbff474: stur            x1, [fp, #-0x38]
    // 0xbff478: LoadField: r2 = r0->field_7
    //     0xbff478: ldur            w2, [x0, #7]
    // 0xbff47c: DecompressPointer r2
    //     0xbff47c: add             x2, x2, HEAP, lsl #32
    // 0xbff480: stur            x2, [fp, #-0x30]
    // 0xbff484: LoadField: r3 = r0->field_13
    //     0xbff484: ldur            w3, [x0, #0x13]
    // 0xbff488: DecompressPointer r3
    //     0xbff488: add             x3, x3, HEAP, lsl #32
    // 0xbff48c: stur            x3, [fp, #-0x28]
    // 0xbff490: LoadField: r4 = r0->field_f
    //     0xbff490: ldur            w4, [x0, #0xf]
    // 0xbff494: DecompressPointer r4
    //     0xbff494: add             x4, x4, HEAP, lsl #32
    // 0xbff498: stur            x4, [fp, #-0x20]
    // 0xbff49c: r0 = BorderRadius()
    //     0xbff49c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff4a0: mov             x1, x0
    // 0xbff4a4: ldur            x0, [fp, #-0x38]
    // 0xbff4a8: StoreField: r1->field_7 = r0
    //     0xbff4a8: stur            w0, [x1, #7]
    // 0xbff4ac: ldur            x0, [fp, #-0x30]
    // 0xbff4b0: StoreField: r1->field_b = r0
    //     0xbff4b0: stur            w0, [x1, #0xb]
    // 0xbff4b4: ldur            x0, [fp, #-0x28]
    // 0xbff4b8: StoreField: r1->field_f = r0
    //     0xbff4b8: stur            w0, [x1, #0xf]
    // 0xbff4bc: ldur            x0, [fp, #-0x20]
    // 0xbff4c0: StoreField: r1->field_13 = r0
    //     0xbff4c0: stur            w0, [x1, #0x13]
    // 0xbff4c4: b               #0xbff55c
    // 0xbff4c8: LoadField: r1 = r0->field_7
    //     0xbff4c8: ldur            w1, [x0, #7]
    // 0xbff4cc: DecompressPointer r1
    //     0xbff4cc: add             x1, x1, HEAP, lsl #32
    // 0xbff4d0: stur            x1, [fp, #-0x38]
    // 0xbff4d4: LoadField: r2 = r0->field_b
    //     0xbff4d4: ldur            w2, [x0, #0xb]
    // 0xbff4d8: DecompressPointer r2
    //     0xbff4d8: add             x2, x2, HEAP, lsl #32
    // 0xbff4dc: stur            x2, [fp, #-0x30]
    // 0xbff4e0: LoadField: r3 = r0->field_f
    //     0xbff4e0: ldur            w3, [x0, #0xf]
    // 0xbff4e4: DecompressPointer r3
    //     0xbff4e4: add             x3, x3, HEAP, lsl #32
    // 0xbff4e8: stur            x3, [fp, #-0x28]
    // 0xbff4ec: LoadField: r4 = r0->field_13
    //     0xbff4ec: ldur            w4, [x0, #0x13]
    // 0xbff4f0: DecompressPointer r4
    //     0xbff4f0: add             x4, x4, HEAP, lsl #32
    // 0xbff4f4: stur            x4, [fp, #-0x20]
    // 0xbff4f8: r0 = BorderRadius()
    //     0xbff4f8: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff4fc: mov             x1, x0
    // 0xbff500: ldur            x0, [fp, #-0x38]
    // 0xbff504: StoreField: r1->field_7 = r0
    //     0xbff504: stur            w0, [x1, #7]
    // 0xbff508: ldur            x0, [fp, #-0x30]
    // 0xbff50c: StoreField: r1->field_b = r0
    //     0xbff50c: stur            w0, [x1, #0xb]
    // 0xbff510: ldur            x0, [fp, #-0x28]
    // 0xbff514: StoreField: r1->field_f = r0
    //     0xbff514: stur            w0, [x1, #0xf]
    // 0xbff518: ldur            x0, [fp, #-0x20]
    // 0xbff51c: StoreField: r1->field_13 = r0
    //     0xbff51c: stur            w0, [x1, #0x13]
    // 0xbff520: b               #0xbff55c
    // 0xbff524: ldur            x2, [fp, #-8]
    // 0xbff528: cmp             x1, #0xb89
    // 0xbff52c: b.ne            #0xbff538
    // 0xbff530: mov             x1, x0
    // 0xbff534: b               #0xbff55c
    // 0xbff538: r1 = LoadClassIdInstr(r0)
    //     0xbff538: ldur            x1, [x0, #-1]
    //     0xbff53c: ubfx            x1, x1, #0xc, #0x14
    // 0xbff540: mov             x16, x0
    // 0xbff544: mov             x0, x1
    // 0xbff548: mov             x1, x16
    // 0xbff54c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbff54c: sub             lr, x0, #1, lsl #12
    //     0xbff550: ldr             lr, [x21, lr, lsl #3]
    //     0xbff554: blr             lr
    // 0xbff558: mov             x1, x0
    // 0xbff55c: ldur            x0, [fp, #-0x10]
    // 0xbff560: ldur            x2, [fp, #-0x18]
    // 0xbff564: r0 = toRRect()
    //     0xbff564: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbff568: mov             x4, x0
    // 0xbff56c: ldur            x0, [fp, #-0x10]
    // 0xbff570: stur            x4, [fp, #-8]
    // 0xbff574: LoadField: r1 = r0->field_7
    //     0xbff574: ldur            w1, [x0, #7]
    // 0xbff578: DecompressPointer r1
    //     0xbff578: add             x1, x1, HEAP, lsl #32
    // 0xbff57c: LoadField: d0 = r1->field_b
    //     0xbff57c: ldur            d0, [x1, #0xb]
    // 0xbff580: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xbff580: ldur            d1, [x1, #0x17]
    // 0xbff584: r1 = inline_Allocate_Double()
    //     0xbff584: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xbff588: add             x1, x1, #0x10
    //     0xbff58c: cmp             x0, x1
    //     0xbff590: b.ls            #0xbff720
    //     0xbff594: str             x1, [THR, #0x60]  ; THR::top
    //     0xbff598: sub             x1, x1, #0xf
    //     0xbff59c: mov             x0, #0xe19c
    //     0xbff5a0: movk            x0, #3, lsl #16
    //     0xbff5a4: stur            x0, [x1, #-1]
    // 0xbff5a8: dmb             ishst
    // 0xbff5ac: StoreField: r1->field_7 = d0
    //     0xbff5ac: stur            d0, [x1, #7]
    // 0xbff5b0: r3 = inline_Allocate_Double()
    //     0xbff5b0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbff5b4: add             x3, x3, #0x10
    //     0xbff5b8: cmp             x0, x3
    //     0xbff5bc: b.ls            #0xbff73c
    //     0xbff5c0: str             x3, [THR, #0x60]  ; THR::top
    //     0xbff5c4: sub             x3, x3, #0xf
    //     0xbff5c8: mov             x0, #0xe19c
    //     0xbff5cc: movk            x0, #3, lsl #16
    //     0xbff5d0: stur            x0, [x3, #-1]
    // 0xbff5d4: dmb             ishst
    // 0xbff5d8: StoreField: r3->field_7 = d1
    //     0xbff5d8: stur            d1, [x3, #7]
    // 0xbff5dc: r2 = 0
    //     0xbff5dc: mov             x2, #0
    // 0xbff5e0: r0 = lerpDouble()
    //     0xbff5e0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xbff5e4: LoadField: d0 = r0->field_7
    //     0xbff5e4: ldur            d0, [x0, #7]
    // 0xbff5e8: ldur            x1, [fp, #-8]
    // 0xbff5ec: r0 = deflate()
    //     0xbff5ec: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbff5f0: stur            x0, [fp, #-8]
    // 0xbff5f4: r0 = _NativePath()
    //     0xbff5f4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbff5f8: mov             x1, x0
    // 0xbff5fc: stur            x0, [fp, #-0x10]
    // 0xbff600: r0 = __constructor$Method$FfiNative()
    //     0xbff600: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbff604: ldur            x0, [fp, #-8]
    // 0xbff608: LoadField: d0 = r0->field_b
    //     0xbff608: ldur            d0, [x0, #0xb]
    // 0xbff60c: fcvt            s1, d0
    // 0xbff610: stur            d1, [fp, #-0x48]
    // 0xbff614: r4 = 24
    //     0xbff614: mov             x4, #0x18
    // 0xbff618: r0 = AllocateFloat32Array()
    //     0xbff618: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbff61c: ldur            d0, [fp, #-0x48]
    // 0xbff620: stur            x0, [fp, #-0x18]
    // 0xbff624: ArrayStore: r0[0] = d0  ; List_8
    //     0xbff624: stur            s0, [x0, #0x17]
    // 0xbff628: ldur            x1, [fp, #-8]
    // 0xbff62c: LoadField: d0 = r1->field_13
    //     0xbff62c: ldur            d0, [x1, #0x13]
    // 0xbff630: fcvt            s1, d0
    // 0xbff634: StoreField: r0->field_1b = d1
    //     0xbff634: stur            s1, [x0, #0x1b]
    // 0xbff638: LoadField: d0 = r1->field_1b
    //     0xbff638: ldur            d0, [x1, #0x1b]
    // 0xbff63c: fcvt            s1, d0
    // 0xbff640: StoreField: r0->field_1f = d1
    //     0xbff640: stur            s1, [x0, #0x1f]
    // 0xbff644: LoadField: d0 = r1->field_23
    //     0xbff644: ldur            d0, [x1, #0x23]
    // 0xbff648: fcvt            s1, d0
    // 0xbff64c: StoreField: r0->field_23 = d1
    //     0xbff64c: stur            s1, [x0, #0x23]
    // 0xbff650: LoadField: d0 = r1->field_2b
    //     0xbff650: ldur            d0, [x1, #0x2b]
    // 0xbff654: fcvt            s1, d0
    // 0xbff658: StoreField: r0->field_27 = d1
    //     0xbff658: stur            s1, [x0, #0x27]
    // 0xbff65c: LoadField: d0 = r1->field_33
    //     0xbff65c: ldur            d0, [x1, #0x33]
    // 0xbff660: fcvt            s1, d0
    // 0xbff664: StoreField: r0->field_2b = d1
    //     0xbff664: stur            s1, [x0, #0x2b]
    // 0xbff668: LoadField: d0 = r1->field_3b
    //     0xbff668: ldur            d0, [x1, #0x3b]
    // 0xbff66c: fcvt            s1, d0
    // 0xbff670: StoreField: r0->field_2f = d1
    //     0xbff670: stur            s1, [x0, #0x2f]
    // 0xbff674: LoadField: d0 = r1->field_43
    //     0xbff674: ldur            d0, [x1, #0x43]
    // 0xbff678: fcvt            s1, d0
    // 0xbff67c: StoreField: r0->field_33 = d1
    //     0xbff67c: stur            s1, [x0, #0x33]
    // 0xbff680: LoadField: d0 = r1->field_4b
    //     0xbff680: ldur            d0, [x1, #0x4b]
    // 0xbff684: fcvt            s1, d0
    // 0xbff688: StoreField: r0->field_37 = d1
    //     0xbff688: stur            s1, [x0, #0x37]
    // 0xbff68c: LoadField: d0 = r1->field_53
    //     0xbff68c: ldur            d0, [x1, #0x53]
    // 0xbff690: fcvt            s1, d0
    // 0xbff694: StoreField: r0->field_3b = d1
    //     0xbff694: stur            s1, [x0, #0x3b]
    // 0xbff698: LoadField: d0 = r1->field_5b
    //     0xbff698: ldur            d0, [x1, #0x5b]
    // 0xbff69c: fcvt            s1, d0
    // 0xbff6a0: StoreField: r0->field_3f = d1
    //     0xbff6a0: stur            s1, [x0, #0x3f]
    // 0xbff6a4: LoadField: d0 = r1->field_63
    //     0xbff6a4: ldur            d0, [x1, #0x63]
    // 0xbff6a8: fcvt            s1, d0
    // 0xbff6ac: StoreField: r0->field_43 = d1
    //     0xbff6ac: stur            s1, [x0, #0x43]
    // 0xbff6b0: ldur            x2, [fp, #-0x10]
    // 0xbff6b4: LoadField: r1 = r2->field_7
    //     0xbff6b4: ldur            w1, [x2, #7]
    // 0xbff6b8: DecompressPointer r1
    //     0xbff6b8: add             x1, x1, HEAP, lsl #32
    // 0xbff6bc: cmp             w1, NULL
    // 0xbff6c0: b.eq            #0xbff758
    // 0xbff6c4: LoadField: r3 = r1->field_7
    //     0xbff6c4: ldur            x3, [x1, #7]
    // 0xbff6c8: ldr             x1, [x3]
    // 0xbff6cc: cbz             x1, #0xbff704
    // 0xbff6d0: mov             x3, x1
    // 0xbff6d4: stur            x3, [fp, #-0x40]
    // 0xbff6d8: r1 = <Never>
    //     0xbff6d8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbff6dc: r0 = Pointer()
    //     0xbff6dc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbff6e0: mov             x1, x0
    // 0xbff6e4: ldur            x0, [fp, #-0x40]
    // 0xbff6e8: StoreField: r1->field_7 = r0
    //     0xbff6e8: stur            x0, [x1, #7]
    // 0xbff6ec: ldur            x2, [fp, #-0x18]
    // 0xbff6f0: r0 = __addRRect$Method$FfiNative()
    //     0xbff6f0: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbff6f4: ldur            x0, [fp, #-0x10]
    // 0xbff6f8: LeaveFrame
    //     0xbff6f8: mov             SP, fp
    //     0xbff6fc: ldp             fp, lr, [SP], #0x10
    // 0xbff700: ret
    //     0xbff700: ret             
    // 0xbff704: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbff704: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbff708: str             x16, [SP]
    // 0xbff70c: r0 = _throwNew()
    //     0xbff70c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbff710: brk             #0
    // 0xbff714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff718: b               #0xbff438
    // 0xbff71c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbff71c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbff720: stp             q0, q1, [SP, #-0x20]!
    // 0xbff724: SaveReg r4
    //     0xbff724: str             x4, [SP, #-8]!
    // 0xbff728: r0 = AllocateDouble()
    //     0xbff728: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbff72c: mov             x1, x0
    // 0xbff730: RestoreReg r4
    //     0xbff730: ldr             x4, [SP], #8
    // 0xbff734: ldp             q0, q1, [SP], #0x20
    // 0xbff738: b               #0xbff5ac
    // 0xbff73c: SaveReg d1
    //     0xbff73c: str             q1, [SP, #-0x10]!
    // 0xbff740: stp             x1, x4, [SP, #-0x10]!
    // 0xbff744: r0 = AllocateDouble()
    //     0xbff744: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbff748: mov             x3, x0
    // 0xbff74c: ldp             x1, x4, [SP], #0x10
    // 0xbff750: RestoreReg d1
    //     0xbff750: ldr             q1, [SP], #0x10
    // 0xbff754: b               #0xbff5d8
    // 0xbff758: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbff758: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0xbff75c, size: 0xa8
    // 0xbff75c: EnterFrame
    //     0xbff75c: stp             fp, lr, [SP, #-0x10]!
    //     0xbff760: mov             fp, SP
    // 0xbff764: AllocStack(0x20)
    //     0xbff764: sub             SP, SP, #0x20
    // 0xbff768: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xbff768: mov             x0, x1
    //     0xbff76c: stur            x1, [fp, #-0x10]
    //     0xbff770: mov             x1, x2
    // 0xbff774: CheckStackOverflow
    //     0xbff774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbff778: cmp             SP, x16
    //     0xbff77c: b.ls            #0xbff7fc
    // 0xbff780: LoadField: r2 = r0->field_b
    //     0xbff780: ldur            w2, [x0, #0xb]
    // 0xbff784: DecompressPointer r2
    //     0xbff784: add             x2, x2, HEAP, lsl #32
    // 0xbff788: stur            x2, [fp, #-8]
    // 0xbff78c: r0 = shortestSide()
    //     0xbff78c: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xbff790: mov             v1.16b, v0.16b
    // 0xbff794: d0 = 2.000000
    //     0xbff794: fmov            d0, #2.00000000
    // 0xbff798: fdiv            d2, d1, d0
    // 0xbff79c: stur            d2, [fp, #-0x20]
    // 0xbff7a0: r0 = Radius()
    //     0xbff7a0: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbff7a4: ldur            d0, [fp, #-0x20]
    // 0xbff7a8: stur            x0, [fp, #-0x18]
    // 0xbff7ac: StoreField: r0->field_7 = d0
    //     0xbff7ac: stur            d0, [x0, #7]
    // 0xbff7b0: StoreField: r0->field_f = d0
    //     0xbff7b0: stur            d0, [x0, #0xf]
    // 0xbff7b4: r0 = BorderRadius()
    //     0xbff7b4: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff7b8: mov             x1, x0
    // 0xbff7bc: ldur            x0, [fp, #-0x18]
    // 0xbff7c0: StoreField: r1->field_7 = r0
    //     0xbff7c0: stur            w0, [x1, #7]
    // 0xbff7c4: StoreField: r1->field_b = r0
    //     0xbff7c4: stur            w0, [x1, #0xb]
    // 0xbff7c8: StoreField: r1->field_f = r0
    //     0xbff7c8: stur            w0, [x1, #0xf]
    // 0xbff7cc: StoreField: r1->field_13 = r0
    //     0xbff7cc: stur            w0, [x1, #0x13]
    // 0xbff7d0: ldur            x0, [fp, #-0x10]
    // 0xbff7d4: LoadField: d0 = r0->field_f
    //     0xbff7d4: ldur            d0, [x0, #0xf]
    // 0xbff7d8: d1 = 1.000000
    //     0xbff7d8: fmov            d1, #1.00000000
    // 0xbff7dc: fsub            d2, d1, d0
    // 0xbff7e0: mov             x2, x1
    // 0xbff7e4: ldur            x1, [fp, #-8]
    // 0xbff7e8: mov             v0.16b, v2.16b
    // 0xbff7ec: r0 = lerp()
    //     0xbff7ec: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0xbff7f0: LeaveFrame
    //     0xbff7f0: mov             SP, fp
    //     0xbff7f4: ldp             fp, lr, [SP], #0x10
    // 0xbff7f8: ret
    //     0xbff7f8: ret             
    // 0xbff7fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff7fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff800: b               #0xbff780
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ee1b0, size: 0x2f0
    // 0x10ee1b0: EnterFrame
    //     0x10ee1b0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ee1b4: mov             fp, SP
    // 0x10ee1b8: AllocStack(0x38)
    //     0x10ee1b8: sub             SP, SP, #0x38
    // 0x10ee1bc: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x10ee1bc: mov             x3, x1
    //     0x10ee1c0: mov             x0, x2
    //     0x10ee1c4: mov             v1.16b, v0.16b
    //     0x10ee1c8: stur            x1, [fp, #-8]
    //     0x10ee1cc: stur            x2, [fp, #-0x20]
    //     0x10ee1d0: stur            d0, [fp, #-0x30]
    // 0x10ee1d4: CheckStackOverflow
    //     0x10ee1d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ee1d8: cmp             SP, x16
    //     0x10ee1dc: b.ls            #0x10ee434
    // 0x10ee1e0: r1 = LoadClassIdInstr(r0)
    //     0x10ee1e0: ldur            x1, [x0, #-1]
    //     0x10ee1e4: ubfx            x1, x1, #0xc, #0x14
    // 0x10ee1e8: cmp             x1, #0xbce
    // 0x10ee1ec: b.ne            #0x10ee25c
    // 0x10ee1f0: LoadField: r1 = r0->field_7
    //     0x10ee1f0: ldur            w1, [x0, #7]
    // 0x10ee1f4: DecompressPointer r1
    //     0x10ee1f4: add             x1, x1, HEAP, lsl #32
    // 0x10ee1f8: LoadField: r2 = r3->field_7
    //     0x10ee1f8: ldur            w2, [x3, #7]
    // 0x10ee1fc: DecompressPointer r2
    //     0x10ee1fc: add             x2, x2, HEAP, lsl #32
    // 0x10ee200: mov             v0.16b, v1.16b
    // 0x10ee204: r0 = lerp()
    //     0x10ee204: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee208: ldur            x3, [fp, #-8]
    // 0x10ee20c: stur            x0, [fp, #-0x18]
    // 0x10ee210: LoadField: r1 = r3->field_b
    //     0x10ee210: ldur            w1, [x3, #0xb]
    // 0x10ee214: DecompressPointer r1
    //     0x10ee214: add             x1, x1, HEAP, lsl #32
    // 0x10ee218: stur            x1, [fp, #-0x10]
    // 0x10ee21c: LoadField: d0 = r3->field_f
    //     0x10ee21c: ldur            d0, [x3, #0xf]
    // 0x10ee220: ldur            d1, [fp, #-0x30]
    // 0x10ee224: fmul            d2, d0, d1
    // 0x10ee228: stur            d2, [fp, #-0x38]
    // 0x10ee22c: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10ee22c: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10ee230: mov             x1, x0
    // 0x10ee234: ldur            x0, [fp, #-0x10]
    // 0x10ee238: StoreField: r1->field_b = r0
    //     0x10ee238: stur            w0, [x1, #0xb]
    // 0x10ee23c: ldur            d0, [fp, #-0x38]
    // 0x10ee240: StoreField: r1->field_f = d0
    //     0x10ee240: stur            d0, [x1, #0xf]
    // 0x10ee244: ldur            x0, [fp, #-0x18]
    // 0x10ee248: StoreField: r1->field_7 = r0
    //     0x10ee248: stur            w0, [x1, #7]
    // 0x10ee24c: mov             x0, x1
    // 0x10ee250: LeaveFrame
    //     0x10ee250: mov             SP, fp
    //     0x10ee254: ldp             fp, lr, [SP], #0x10
    // 0x10ee258: ret
    //     0x10ee258: ret             
    // 0x10ee25c: cmp             x1, #0xbd5
    // 0x10ee260: b.ne            #0x10ee2e0
    // 0x10ee264: LoadField: r1 = r0->field_7
    //     0x10ee264: ldur            w1, [x0, #7]
    // 0x10ee268: DecompressPointer r1
    //     0x10ee268: add             x1, x1, HEAP, lsl #32
    // 0x10ee26c: LoadField: r2 = r3->field_7
    //     0x10ee26c: ldur            w2, [x3, #7]
    // 0x10ee270: DecompressPointer r2
    //     0x10ee270: add             x2, x2, HEAP, lsl #32
    // 0x10ee274: mov             v0.16b, v1.16b
    // 0x10ee278: r0 = lerp()
    //     0x10ee278: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee27c: ldur            x3, [fp, #-8]
    // 0x10ee280: stur            x0, [fp, #-0x18]
    // 0x10ee284: LoadField: r1 = r3->field_b
    //     0x10ee284: ldur            w1, [x3, #0xb]
    // 0x10ee288: DecompressPointer r1
    //     0x10ee288: add             x1, x1, HEAP, lsl #32
    // 0x10ee28c: stur            x1, [fp, #-0x10]
    // 0x10ee290: LoadField: d0 = r3->field_f
    //     0x10ee290: ldur            d0, [x3, #0xf]
    // 0x10ee294: d1 = 1.000000
    //     0x10ee294: fmov            d1, #1.00000000
    // 0x10ee298: fsub            d2, d1, d0
    // 0x10ee29c: ldur            d3, [fp, #-0x30]
    // 0x10ee2a0: fsub            d4, d1, d3
    // 0x10ee2a4: fmul            d1, d2, d4
    // 0x10ee2a8: fadd            d2, d0, d1
    // 0x10ee2ac: stur            d2, [fp, #-0x38]
    // 0x10ee2b0: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10ee2b0: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10ee2b4: mov             x1, x0
    // 0x10ee2b8: ldur            x0, [fp, #-0x10]
    // 0x10ee2bc: StoreField: r1->field_b = r0
    //     0x10ee2bc: stur            w0, [x1, #0xb]
    // 0x10ee2c0: ldur            d0, [fp, #-0x38]
    // 0x10ee2c4: StoreField: r1->field_f = d0
    //     0x10ee2c4: stur            d0, [x1, #0xf]
    // 0x10ee2c8: ldur            x0, [fp, #-0x18]
    // 0x10ee2cc: StoreField: r1->field_7 = r0
    //     0x10ee2cc: stur            w0, [x1, #7]
    // 0x10ee2d0: mov             x0, x1
    // 0x10ee2d4: LeaveFrame
    //     0x10ee2d4: mov             SP, fp
    //     0x10ee2d8: ldp             fp, lr, [SP], #0x10
    // 0x10ee2dc: ret
    //     0x10ee2dc: ret             
    // 0x10ee2e0: mov             v3.16b, v1.16b
    // 0x10ee2e4: cmp             x1, #0xbcc
    // 0x10ee2e8: b.ne            #0x10ee408
    // 0x10ee2ec: LoadField: r1 = r0->field_7
    //     0x10ee2ec: ldur            w1, [x0, #7]
    // 0x10ee2f0: DecompressPointer r1
    //     0x10ee2f0: add             x1, x1, HEAP, lsl #32
    // 0x10ee2f4: LoadField: r2 = r3->field_7
    //     0x10ee2f4: ldur            w2, [x3, #7]
    // 0x10ee2f8: DecompressPointer r2
    //     0x10ee2f8: add             x2, x2, HEAP, lsl #32
    // 0x10ee2fc: mov             v0.16b, v3.16b
    // 0x10ee300: r0 = lerp()
    //     0x10ee300: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ee304: mov             x3, x0
    // 0x10ee308: ldur            x0, [fp, #-0x20]
    // 0x10ee30c: stur            x3, [fp, #-0x10]
    // 0x10ee310: LoadField: r1 = r0->field_b
    //     0x10ee310: ldur            w1, [x0, #0xb]
    // 0x10ee314: DecompressPointer r1
    //     0x10ee314: add             x1, x1, HEAP, lsl #32
    // 0x10ee318: ldur            x4, [fp, #-8]
    // 0x10ee31c: LoadField: r2 = r4->field_b
    //     0x10ee31c: ldur            w2, [x4, #0xb]
    // 0x10ee320: DecompressPointer r2
    //     0x10ee320: add             x2, x2, HEAP, lsl #32
    // 0x10ee324: ldur            d0, [fp, #-0x30]
    // 0x10ee328: r0 = lerp()
    //     0x10ee328: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10ee32c: mov             x4, x0
    // 0x10ee330: ldur            x0, [fp, #-0x20]
    // 0x10ee334: stur            x4, [fp, #-0x18]
    // 0x10ee338: LoadField: d0 = r0->field_f
    //     0x10ee338: ldur            d0, [x0, #0xf]
    // 0x10ee33c: ldur            x1, [fp, #-8]
    // 0x10ee340: LoadField: d1 = r1->field_f
    //     0x10ee340: ldur            d1, [x1, #0xf]
    // 0x10ee344: ldur            d2, [fp, #-0x30]
    // 0x10ee348: r3 = inline_Allocate_Double()
    //     0x10ee348: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x10ee34c: add             x3, x3, #0x10
    //     0x10ee350: cmp             x0, x3
    //     0x10ee354: b.ls            #0x10ee43c
    //     0x10ee358: str             x3, [THR, #0x60]  ; THR::top
    //     0x10ee35c: sub             x3, x3, #0xf
    //     0x10ee360: mov             x0, #0xe19c
    //     0x10ee364: movk            x0, #3, lsl #16
    //     0x10ee368: stur            x0, [x3, #-1]
    // 0x10ee36c: dmb             ishst
    // 0x10ee370: StoreField: r3->field_7 = d2
    //     0x10ee370: stur            d2, [x3, #7]
    // 0x10ee374: r1 = inline_Allocate_Double()
    //     0x10ee374: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x10ee378: add             x1, x1, #0x10
    //     0x10ee37c: cmp             x0, x1
    //     0x10ee380: b.ls            #0x10ee460
    //     0x10ee384: str             x1, [THR, #0x60]  ; THR::top
    //     0x10ee388: sub             x1, x1, #0xf
    //     0x10ee38c: mov             x0, #0xe19c
    //     0x10ee390: movk            x0, #3, lsl #16
    //     0x10ee394: stur            x0, [x1, #-1]
    // 0x10ee398: dmb             ishst
    // 0x10ee39c: StoreField: r1->field_7 = d0
    //     0x10ee39c: stur            d0, [x1, #7]
    // 0x10ee3a0: r2 = inline_Allocate_Double()
    //     0x10ee3a0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x10ee3a4: add             x2, x2, #0x10
    //     0x10ee3a8: cmp             x0, x2
    //     0x10ee3ac: b.ls            #0x10ee47c
    //     0x10ee3b0: str             x2, [THR, #0x60]  ; THR::top
    //     0x10ee3b4: sub             x2, x2, #0xf
    //     0x10ee3b8: mov             x0, #0xe19c
    //     0x10ee3bc: movk            x0, #3, lsl #16
    //     0x10ee3c0: stur            x0, [x2, #-1]
    // 0x10ee3c4: dmb             ishst
    // 0x10ee3c8: StoreField: r2->field_7 = d1
    //     0x10ee3c8: stur            d1, [x2, #7]
    // 0x10ee3cc: r0 = lerpDouble()
    //     0x10ee3cc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10ee3d0: stur            x0, [fp, #-0x28]
    // 0x10ee3d4: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10ee3d4: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10ee3d8: mov             x1, x0
    // 0x10ee3dc: ldur            x0, [fp, #-0x18]
    // 0x10ee3e0: StoreField: r1->field_b = r0
    //     0x10ee3e0: stur            w0, [x1, #0xb]
    // 0x10ee3e4: ldur            x0, [fp, #-0x28]
    // 0x10ee3e8: LoadField: d0 = r0->field_7
    //     0x10ee3e8: ldur            d0, [x0, #7]
    // 0x10ee3ec: StoreField: r1->field_f = d0
    //     0x10ee3ec: stur            d0, [x1, #0xf]
    // 0x10ee3f0: ldur            x0, [fp, #-0x10]
    // 0x10ee3f4: StoreField: r1->field_7 = r0
    //     0x10ee3f4: stur            w0, [x1, #7]
    // 0x10ee3f8: mov             x0, x1
    // 0x10ee3fc: LeaveFrame
    //     0x10ee3fc: mov             SP, fp
    //     0x10ee400: ldp             fp, lr, [SP], #0x10
    // 0x10ee404: ret
    //     0x10ee404: ret             
    // 0x10ee408: mov             x1, x3
    // 0x10ee40c: mov             v2.16b, v3.16b
    // 0x10ee410: cmp             w0, NULL
    // 0x10ee414: b.ne            #0x10ee424
    // 0x10ee418: mov             v0.16b, v2.16b
    // 0x10ee41c: r0 = scale()
    //     0x10ee41c: bl              #0x12fcdb8  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::scale
    // 0x10ee420: b               #0x10ee428
    // 0x10ee424: r0 = Null
    //     0x10ee424: mov             x0, NULL
    // 0x10ee428: LeaveFrame
    //     0x10ee428: mov             SP, fp
    //     0x10ee42c: ldp             fp, lr, [SP], #0x10
    // 0x10ee430: ret
    //     0x10ee430: ret             
    // 0x10ee434: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee434: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee438: b               #0x10ee1e0
    // 0x10ee43c: stp             q1, q2, [SP, #-0x20]!
    // 0x10ee440: SaveReg d0
    //     0x10ee440: str             q0, [SP, #-0x10]!
    // 0x10ee444: SaveReg r4
    //     0x10ee444: str             x4, [SP, #-8]!
    // 0x10ee448: r0 = AllocateDouble()
    //     0x10ee448: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee44c: mov             x3, x0
    // 0x10ee450: RestoreReg r4
    //     0x10ee450: ldr             x4, [SP], #8
    // 0x10ee454: RestoreReg d0
    //     0x10ee454: ldr             q0, [SP], #0x10
    // 0x10ee458: ldp             q1, q2, [SP], #0x20
    // 0x10ee45c: b               #0x10ee370
    // 0x10ee460: stp             q0, q1, [SP, #-0x20]!
    // 0x10ee464: stp             x3, x4, [SP, #-0x10]!
    // 0x10ee468: r0 = AllocateDouble()
    //     0x10ee468: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee46c: mov             x1, x0
    // 0x10ee470: ldp             x3, x4, [SP], #0x10
    // 0x10ee474: ldp             q0, q1, [SP], #0x20
    // 0x10ee478: b               #0x10ee39c
    // 0x10ee47c: SaveReg d1
    //     0x10ee47c: str             q1, [SP, #-0x10]!
    // 0x10ee480: stp             x3, x4, [SP, #-0x10]!
    // 0x10ee484: SaveReg r1
    //     0x10ee484: str             x1, [SP, #-8]!
    // 0x10ee488: r0 = AllocateDouble()
    //     0x10ee488: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee48c: mov             x2, x0
    // 0x10ee490: RestoreReg r1
    //     0x10ee490: ldr             x1, [SP], #8
    // 0x10ee494: ldp             x3, x4, [SP], #0x10
    // 0x10ee498: RestoreReg d1
    //     0x10ee498: ldr             q1, [SP], #0x10
    // 0x10ee49c: b               #0x10ee3c8
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f12f0, size: 0x2e4
    // 0x10f12f0: EnterFrame
    //     0x10f12f0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f12f4: mov             fp, SP
    // 0x10f12f8: AllocStack(0x38)
    //     0x10f12f8: sub             SP, SP, #0x38
    // 0x10f12fc: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x10f12fc: mov             x3, x1
    //     0x10f1300: mov             x0, x2
    //     0x10f1304: mov             v1.16b, v0.16b
    //     0x10f1308: stur            x1, [fp, #-8]
    //     0x10f130c: stur            x2, [fp, #-0x20]
    //     0x10f1310: stur            d0, [fp, #-0x30]
    // 0x10f1314: CheckStackOverflow
    //     0x10f1314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f1318: cmp             SP, x16
    //     0x10f131c: b.ls            #0x10f1568
    // 0x10f1320: r1 = LoadClassIdInstr(r0)
    //     0x10f1320: ldur            x1, [x0, #-1]
    //     0x10f1324: ubfx            x1, x1, #0xc, #0x14
    // 0x10f1328: cmp             x1, #0xbce
    // 0x10f132c: b.ne            #0x10f13a4
    // 0x10f1330: LoadField: r1 = r3->field_7
    //     0x10f1330: ldur            w1, [x3, #7]
    // 0x10f1334: DecompressPointer r1
    //     0x10f1334: add             x1, x1, HEAP, lsl #32
    // 0x10f1338: LoadField: r2 = r0->field_7
    //     0x10f1338: ldur            w2, [x0, #7]
    // 0x10f133c: DecompressPointer r2
    //     0x10f133c: add             x2, x2, HEAP, lsl #32
    // 0x10f1340: mov             v0.16b, v1.16b
    // 0x10f1344: r0 = lerp()
    //     0x10f1344: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f1348: ldur            x3, [fp, #-8]
    // 0x10f134c: stur            x0, [fp, #-0x18]
    // 0x10f1350: LoadField: r1 = r3->field_b
    //     0x10f1350: ldur            w1, [x3, #0xb]
    // 0x10f1354: DecompressPointer r1
    //     0x10f1354: add             x1, x1, HEAP, lsl #32
    // 0x10f1358: stur            x1, [fp, #-0x10]
    // 0x10f135c: LoadField: d0 = r3->field_f
    //     0x10f135c: ldur            d0, [x3, #0xf]
    // 0x10f1360: ldur            d1, [fp, #-0x30]
    // 0x10f1364: d2 = 1.000000
    //     0x10f1364: fmov            d2, #1.00000000
    // 0x10f1368: fsub            d3, d2, d1
    // 0x10f136c: fmul            d1, d0, d3
    // 0x10f1370: stur            d1, [fp, #-0x38]
    // 0x10f1374: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10f1374: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10f1378: mov             x1, x0
    // 0x10f137c: ldur            x0, [fp, #-0x10]
    // 0x10f1380: StoreField: r1->field_b = r0
    //     0x10f1380: stur            w0, [x1, #0xb]
    // 0x10f1384: ldur            d0, [fp, #-0x38]
    // 0x10f1388: StoreField: r1->field_f = d0
    //     0x10f1388: stur            d0, [x1, #0xf]
    // 0x10f138c: ldur            x0, [fp, #-0x18]
    // 0x10f1390: StoreField: r1->field_7 = r0
    //     0x10f1390: stur            w0, [x1, #7]
    // 0x10f1394: mov             x0, x1
    // 0x10f1398: LeaveFrame
    //     0x10f1398: mov             SP, fp
    //     0x10f139c: ldp             fp, lr, [SP], #0x10
    // 0x10f13a0: ret
    //     0x10f13a0: ret             
    // 0x10f13a4: d2 = 1.000000
    //     0x10f13a4: fmov            d2, #1.00000000
    // 0x10f13a8: cmp             x1, #0xbd5
    // 0x10f13ac: b.ne            #0x10f1428
    // 0x10f13b0: LoadField: r1 = r3->field_7
    //     0x10f13b0: ldur            w1, [x3, #7]
    // 0x10f13b4: DecompressPointer r1
    //     0x10f13b4: add             x1, x1, HEAP, lsl #32
    // 0x10f13b8: LoadField: r2 = r0->field_7
    //     0x10f13b8: ldur            w2, [x0, #7]
    // 0x10f13bc: DecompressPointer r2
    //     0x10f13bc: add             x2, x2, HEAP, lsl #32
    // 0x10f13c0: mov             v0.16b, v1.16b
    // 0x10f13c4: r0 = lerp()
    //     0x10f13c4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f13c8: ldur            x3, [fp, #-8]
    // 0x10f13cc: stur            x0, [fp, #-0x18]
    // 0x10f13d0: LoadField: r1 = r3->field_b
    //     0x10f13d0: ldur            w1, [x3, #0xb]
    // 0x10f13d4: DecompressPointer r1
    //     0x10f13d4: add             x1, x1, HEAP, lsl #32
    // 0x10f13d8: stur            x1, [fp, #-0x10]
    // 0x10f13dc: LoadField: d0 = r3->field_f
    //     0x10f13dc: ldur            d0, [x3, #0xf]
    // 0x10f13e0: d1 = 1.000000
    //     0x10f13e0: fmov            d1, #1.00000000
    // 0x10f13e4: fsub            d2, d1, d0
    // 0x10f13e8: ldur            d1, [fp, #-0x30]
    // 0x10f13ec: fmul            d3, d2, d1
    // 0x10f13f0: fadd            d1, d0, d3
    // 0x10f13f4: stur            d1, [fp, #-0x38]
    // 0x10f13f8: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10f13f8: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10f13fc: mov             x1, x0
    // 0x10f1400: ldur            x0, [fp, #-0x10]
    // 0x10f1404: StoreField: r1->field_b = r0
    //     0x10f1404: stur            w0, [x1, #0xb]
    // 0x10f1408: ldur            d0, [fp, #-0x38]
    // 0x10f140c: StoreField: r1->field_f = d0
    //     0x10f140c: stur            d0, [x1, #0xf]
    // 0x10f1410: ldur            x0, [fp, #-0x18]
    // 0x10f1414: StoreField: r1->field_7 = r0
    //     0x10f1414: stur            w0, [x1, #7]
    // 0x10f1418: mov             x0, x1
    // 0x10f141c: LeaveFrame
    //     0x10f141c: mov             SP, fp
    //     0x10f1420: ldp             fp, lr, [SP], #0x10
    // 0x10f1424: ret
    //     0x10f1424: ret             
    // 0x10f1428: cmp             x1, #0xbcc
    // 0x10f142c: b.ne            #0x10f1548
    // 0x10f1430: LoadField: r1 = r3->field_7
    //     0x10f1430: ldur            w1, [x3, #7]
    // 0x10f1434: DecompressPointer r1
    //     0x10f1434: add             x1, x1, HEAP, lsl #32
    // 0x10f1438: LoadField: r2 = r0->field_7
    //     0x10f1438: ldur            w2, [x0, #7]
    // 0x10f143c: DecompressPointer r2
    //     0x10f143c: add             x2, x2, HEAP, lsl #32
    // 0x10f1440: mov             v0.16b, v1.16b
    // 0x10f1444: r0 = lerp()
    //     0x10f1444: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f1448: mov             x3, x0
    // 0x10f144c: ldur            x0, [fp, #-8]
    // 0x10f1450: stur            x3, [fp, #-0x10]
    // 0x10f1454: LoadField: r1 = r0->field_b
    //     0x10f1454: ldur            w1, [x0, #0xb]
    // 0x10f1458: DecompressPointer r1
    //     0x10f1458: add             x1, x1, HEAP, lsl #32
    // 0x10f145c: ldur            x4, [fp, #-0x20]
    // 0x10f1460: LoadField: r2 = r4->field_b
    //     0x10f1460: ldur            w2, [x4, #0xb]
    // 0x10f1464: DecompressPointer r2
    //     0x10f1464: add             x2, x2, HEAP, lsl #32
    // 0x10f1468: ldur            d0, [fp, #-0x30]
    // 0x10f146c: r0 = lerp()
    //     0x10f146c: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x10f1470: ldur            x1, [fp, #-8]
    // 0x10f1474: stur            x0, [fp, #-0x18]
    // 0x10f1478: LoadField: d0 = r1->field_f
    //     0x10f1478: ldur            d0, [x1, #0xf]
    // 0x10f147c: ldur            x2, [fp, #-0x20]
    // 0x10f1480: LoadField: d1 = r2->field_f
    //     0x10f1480: ldur            d1, [x2, #0xf]
    // 0x10f1484: ldur            d2, [fp, #-0x30]
    // 0x10f1488: r3 = inline_Allocate_Double()
    //     0x10f1488: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x10f148c: add             x3, x3, #0x10
    //     0x10f1490: cmp             x1, x3
    //     0x10f1494: b.ls            #0x10f1570
    //     0x10f1498: str             x3, [THR, #0x60]  ; THR::top
    //     0x10f149c: sub             x3, x3, #0xf
    //     0x10f14a0: mov             x1, #0xe19c
    //     0x10f14a4: movk            x1, #3, lsl #16
    //     0x10f14a8: stur            x1, [x3, #-1]
    // 0x10f14ac: dmb             ishst
    // 0x10f14b0: StoreField: r3->field_7 = d2
    //     0x10f14b0: stur            d2, [x3, #7]
    // 0x10f14b4: r1 = inline_Allocate_Double()
    //     0x10f14b4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10f14b8: add             x1, x1, #0x10
    //     0x10f14bc: cmp             x2, x1
    //     0x10f14c0: b.ls            #0x10f1594
    //     0x10f14c4: str             x1, [THR, #0x60]  ; THR::top
    //     0x10f14c8: sub             x1, x1, #0xf
    //     0x10f14cc: mov             x2, #0xe19c
    //     0x10f14d0: movk            x2, #3, lsl #16
    //     0x10f14d4: stur            x2, [x1, #-1]
    // 0x10f14d8: dmb             ishst
    // 0x10f14dc: StoreField: r1->field_7 = d0
    //     0x10f14dc: stur            d0, [x1, #7]
    // 0x10f14e0: r2 = inline_Allocate_Double()
    //     0x10f14e0: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x10f14e4: add             x2, x2, #0x10
    //     0x10f14e8: cmp             x4, x2
    //     0x10f14ec: b.ls            #0x10f15b0
    //     0x10f14f0: str             x2, [THR, #0x60]  ; THR::top
    //     0x10f14f4: sub             x2, x2, #0xf
    //     0x10f14f8: mov             x4, #0xe19c
    //     0x10f14fc: movk            x4, #3, lsl #16
    //     0x10f1500: stur            x4, [x2, #-1]
    // 0x10f1504: dmb             ishst
    // 0x10f1508: StoreField: r2->field_7 = d1
    //     0x10f1508: stur            d1, [x2, #7]
    // 0x10f150c: r0 = lerpDouble()
    //     0x10f150c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10f1510: stur            x0, [fp, #-0x28]
    // 0x10f1514: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10f1514: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10f1518: mov             x1, x0
    // 0x10f151c: ldur            x0, [fp, #-0x18]
    // 0x10f1520: StoreField: r1->field_b = r0
    //     0x10f1520: stur            w0, [x1, #0xb]
    // 0x10f1524: ldur            x0, [fp, #-0x28]
    // 0x10f1528: LoadField: d0 = r0->field_7
    //     0x10f1528: ldur            d0, [x0, #7]
    // 0x10f152c: StoreField: r1->field_f = d0
    //     0x10f152c: stur            d0, [x1, #0xf]
    // 0x10f1530: ldur            x0, [fp, #-0x10]
    // 0x10f1534: StoreField: r1->field_7 = r0
    //     0x10f1534: stur            w0, [x1, #7]
    // 0x10f1538: mov             x0, x1
    // 0x10f153c: LeaveFrame
    //     0x10f153c: mov             SP, fp
    //     0x10f1540: ldp             fp, lr, [SP], #0x10
    // 0x10f1544: ret
    //     0x10f1544: ret             
    // 0x10f1548: mov             x1, x3
    // 0x10f154c: mov             x2, x0
    // 0x10f1550: mov             v2.16b, v1.16b
    // 0x10f1554: mov             v0.16b, v2.16b
    // 0x10f1558: r0 = lerpTo()
    //     0x10f1558: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f155c: LeaveFrame
    //     0x10f155c: mov             SP, fp
    //     0x10f1560: ldp             fp, lr, [SP], #0x10
    // 0x10f1564: ret
    //     0x10f1564: ret             
    // 0x10f1568: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f1568: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f156c: b               #0x10f1320
    // 0x10f1570: stp             q1, q2, [SP, #-0x20]!
    // 0x10f1574: SaveReg d0
    //     0x10f1574: str             q0, [SP, #-0x10]!
    // 0x10f1578: SaveReg r0
    //     0x10f1578: str             x0, [SP, #-8]!
    // 0x10f157c: r0 = AllocateDouble()
    //     0x10f157c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f1580: mov             x3, x0
    // 0x10f1584: RestoreReg r0
    //     0x10f1584: ldr             x0, [SP], #8
    // 0x10f1588: RestoreReg d0
    //     0x10f1588: ldr             q0, [SP], #0x10
    // 0x10f158c: ldp             q1, q2, [SP], #0x20
    // 0x10f1590: b               #0x10f14b0
    // 0x10f1594: stp             q0, q1, [SP, #-0x20]!
    // 0x10f1598: stp             x0, x3, [SP, #-0x10]!
    // 0x10f159c: r0 = AllocateDouble()
    //     0x10f159c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f15a0: mov             x1, x0
    // 0x10f15a4: ldp             x0, x3, [SP], #0x10
    // 0x10f15a8: ldp             q0, q1, [SP], #0x20
    // 0x10f15ac: b               #0x10f14dc
    // 0x10f15b0: SaveReg d1
    //     0x10f15b0: str             q1, [SP, #-0x10]!
    // 0x10f15b4: stp             x1, x3, [SP, #-0x10]!
    // 0x10f15b8: SaveReg r0
    //     0x10f15b8: str             x0, [SP, #-8]!
    // 0x10f15bc: r0 = AllocateDouble()
    //     0x10f15bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f15c0: mov             x2, x0
    // 0x10f15c4: RestoreReg r0
    //     0x10f15c4: ldr             x0, [SP], #8
    // 0x10f15c8: ldp             x1, x3, [SP], #0x10
    // 0x10f15cc: RestoreReg d1
    //     0x10f15cc: ldr             q1, [SP], #0x10
    // 0x10f15d0: b               #0x10f1508
  }
  _ ==(/* No info */) {
    // ** addr: 0x12964b4, size: 0x114
    // 0x12964b4: EnterFrame
    //     0x12964b4: stp             fp, lr, [SP, #-0x10]!
    //     0x12964b8: mov             fp, SP
    // 0x12964bc: AllocStack(0x10)
    //     0x12964bc: sub             SP, SP, #0x10
    // 0x12964c0: CheckStackOverflow
    //     0x12964c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12964c4: cmp             SP, x16
    //     0x12964c8: b.ls            #0x12965c0
    // 0x12964cc: ldr             x0, [fp, #0x10]
    // 0x12964d0: cmp             w0, NULL
    // 0x12964d4: b.ne            #0x12964e8
    // 0x12964d8: r0 = false
    //     0x12964d8: add             x0, NULL, #0x30  ; false
    // 0x12964dc: LeaveFrame
    //     0x12964dc: mov             SP, fp
    //     0x12964e0: ldp             fp, lr, [SP], #0x10
    // 0x12964e4: ret
    //     0x12964e4: ret             
    // 0x12964e8: str             x0, [SP]
    // 0x12964ec: r0 = runtimeType()
    //     0x12964ec: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12964f0: r1 = LoadClassIdInstr(r0)
    //     0x12964f0: ldur            x1, [x0, #-1]
    //     0x12964f4: ubfx            x1, x1, #0xc, #0x14
    // 0x12964f8: r16 = _StadiumToRoundedRectangleBorder
    //     0x12964f8: add             x16, PP, #0xaa, lsl #12  ; [pp+0xaafe0] Type: _StadiumToRoundedRectangleBorder
    //     0x12964fc: ldr             x16, [x16, #0xfe0]
    // 0x1296500: stp             x16, x0, [SP]
    // 0x1296504: mov             x0, x1
    // 0x1296508: mov             lr, x0
    // 0x129650c: ldr             lr, [x21, lr, lsl #3]
    // 0x1296510: blr             lr
    // 0x1296514: tbz             w0, #4, #0x1296528
    // 0x1296518: r0 = false
    //     0x1296518: add             x0, NULL, #0x30  ; false
    // 0x129651c: LeaveFrame
    //     0x129651c: mov             SP, fp
    //     0x1296520: ldp             fp, lr, [SP], #0x10
    // 0x1296524: ret
    //     0x1296524: ret             
    // 0x1296528: ldr             x0, [fp, #0x10]
    // 0x129652c: r1 = 60
    //     0x129652c: mov             x1, #0x3c
    // 0x1296530: branchIfSmi(r0, 0x129653c)
    //     0x1296530: tbz             w0, #0, #0x129653c
    // 0x1296534: r1 = LoadClassIdInstr(r0)
    //     0x1296534: ldur            x1, [x0, #-1]
    //     0x1296538: ubfx            x1, x1, #0xc, #0x14
    // 0x129653c: cmp             x1, #0xbcc
    // 0x1296540: b.ne            #0x12965b0
    // 0x1296544: ldr             x1, [fp, #0x18]
    // 0x1296548: LoadField: r2 = r0->field_7
    //     0x1296548: ldur            w2, [x0, #7]
    // 0x129654c: DecompressPointer r2
    //     0x129654c: add             x2, x2, HEAP, lsl #32
    // 0x1296550: LoadField: r3 = r1->field_7
    //     0x1296550: ldur            w3, [x1, #7]
    // 0x1296554: DecompressPointer r3
    //     0x1296554: add             x3, x3, HEAP, lsl #32
    // 0x1296558: stp             x3, x2, [SP]
    // 0x129655c: r0 = ==()
    //     0x129655c: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296560: tbnz            w0, #4, #0x12965b0
    // 0x1296564: ldr             x1, [fp, #0x18]
    // 0x1296568: ldr             x0, [fp, #0x10]
    // 0x129656c: LoadField: r2 = r0->field_b
    //     0x129656c: ldur            w2, [x0, #0xb]
    // 0x1296570: DecompressPointer r2
    //     0x1296570: add             x2, x2, HEAP, lsl #32
    // 0x1296574: LoadField: r3 = r1->field_b
    //     0x1296574: ldur            w3, [x1, #0xb]
    // 0x1296578: DecompressPointer r3
    //     0x1296578: add             x3, x3, HEAP, lsl #32
    // 0x129657c: stp             x3, x2, [SP]
    // 0x1296580: r0 = ==()
    //     0x1296580: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x1296584: tbnz            w0, #4, #0x12965b0
    // 0x1296588: ldr             x2, [fp, #0x18]
    // 0x129658c: ldr             x1, [fp, #0x10]
    // 0x1296590: LoadField: d0 = r1->field_f
    //     0x1296590: ldur            d0, [x1, #0xf]
    // 0x1296594: LoadField: d1 = r2->field_f
    //     0x1296594: ldur            d1, [x2, #0xf]
    // 0x1296598: fcmp            d0, d1
    // 0x129659c: r16 = true
    //     0x129659c: add             x16, NULL, #0x20  ; true
    // 0x12965a0: r17 = false
    //     0x12965a0: add             x17, NULL, #0x30  ; false
    // 0x12965a4: csel            x1, x16, x17, eq
    // 0x12965a8: mov             x0, x1
    // 0x12965ac: b               #0x12965b4
    // 0x12965b0: r0 = false
    //     0x12965b0: add             x0, NULL, #0x30  ; false
    // 0x12965b4: LeaveFrame
    //     0x12965b4: mov             SP, fp
    //     0x12965b8: ldp             fp, lr, [SP], #0x10
    // 0x12965bc: ret
    //     0x12965bc: ret             
    // 0x12965c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12965c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12965c4: b               #0x12964cc
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ec81c, size: 0x1f4
    // 0x12ec81c: EnterFrame
    //     0x12ec81c: stp             fp, lr, [SP, #-0x10]!
    //     0x12ec820: mov             fp, SP
    // 0x12ec824: AllocStack(0x58)
    //     0x12ec824: sub             SP, SP, #0x58
    // 0x12ec828: SetupParameters(dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */, {dynamic textDirection = Null /* r4, fp-0x8 */})
    //     0x12ec828: mov             x0, x3
    //     0x12ec82c: stur            x3, [fp, #-0x18]
    //     0x12ec830: mov             x3, x5
    //     0x12ec834: stur            x5, [fp, #-0x20]
    //     0x12ec838: mov             x5, x2
    //     0x12ec83c: stur            x2, [fp, #-0x10]
    //     0x12ec840: ldur            w2, [x4, #0x13]
    //     0x12ec844: ldur            w6, [x4, #0x1f]
    //     0x12ec848: add             x6, x6, HEAP, lsl #32
    //     0x12ec84c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12ec850: ldr             x16, [x16, #0x210]
    //     0x12ec854: cmp             w6, w16
    //     0x12ec858: b.ne            #0x12ec878
    //     0x12ec85c: ldur            w6, [x4, #0x23]
    //     0x12ec860: add             x6, x6, HEAP, lsl #32
    //     0x12ec864: sub             w4, w2, w6
    //     0x12ec868: add             x2, fp, w4, sxtw #2
    //     0x12ec86c: ldr             x2, [x2, #8]
    //     0x12ec870: mov             x4, x2
    //     0x12ec874: b               #0x12ec87c
    //     0x12ec878: mov             x4, NULL
    //     0x12ec87c: stur            x4, [fp, #-8]
    // 0x12ec880: CheckStackOverflow
    //     0x12ec880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ec884: cmp             SP, x16
    //     0x12ec888: b.ls            #0x12eca04
    // 0x12ec88c: mov             x2, x0
    // 0x12ec890: r0 = _adjustBorderRadius()
    //     0x12ec890: bl              #0xbff75c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0x12ec894: stur            x0, [fp, #-0x28]
    // 0x12ec898: r16 = Instance_BorderRadius
    //     0x12ec898: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12ec89c: ldr             x16, [x16, #0x508]
    // 0x12ec8a0: stp             x16, x0, [SP]
    // 0x12ec8a4: r0 = ==()
    //     0x12ec8a4: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12ec8a8: tbnz            w0, #4, #0x12ec8c0
    // 0x12ec8ac: ldur            x1, [fp, #-0x10]
    // 0x12ec8b0: ldur            x2, [fp, #-0x18]
    // 0x12ec8b4: ldur            x3, [fp, #-0x20]
    // 0x12ec8b8: r0 = drawRect()
    //     0x12ec8b8: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12ec8bc: b               #0x12ec9f4
    // 0x12ec8c0: ldur            x0, [fp, #-0x28]
    // 0x12ec8c4: r1 = LoadClassIdInstr(r0)
    //     0x12ec8c4: ldur            x1, [x0, #-1]
    //     0x12ec8c8: ubfx            x1, x1, #0xc, #0x14
    // 0x12ec8cc: cmp             x1, #0xb88
    // 0x12ec8d0: b.ne            #0x12ec9a4
    // 0x12ec8d4: ldur            x2, [fp, #-8]
    // 0x12ec8d8: cmp             w2, NULL
    // 0x12ec8dc: b.eq            #0x12eca0c
    // 0x12ec8e0: LoadField: r1 = r2->field_7
    //     0x12ec8e0: ldur            x1, [x2, #7]
    // 0x12ec8e4: cmp             x1, #0
    // 0x12ec8e8: b.gt            #0x12ec948
    // 0x12ec8ec: LoadField: r1 = r0->field_b
    //     0x12ec8ec: ldur            w1, [x0, #0xb]
    // 0x12ec8f0: DecompressPointer r1
    //     0x12ec8f0: add             x1, x1, HEAP, lsl #32
    // 0x12ec8f4: stur            x1, [fp, #-0x48]
    // 0x12ec8f8: LoadField: r2 = r0->field_7
    //     0x12ec8f8: ldur            w2, [x0, #7]
    // 0x12ec8fc: DecompressPointer r2
    //     0x12ec8fc: add             x2, x2, HEAP, lsl #32
    // 0x12ec900: stur            x2, [fp, #-0x40]
    // 0x12ec904: LoadField: r3 = r0->field_13
    //     0x12ec904: ldur            w3, [x0, #0x13]
    // 0x12ec908: DecompressPointer r3
    //     0x12ec908: add             x3, x3, HEAP, lsl #32
    // 0x12ec90c: stur            x3, [fp, #-0x38]
    // 0x12ec910: LoadField: r4 = r0->field_f
    //     0x12ec910: ldur            w4, [x0, #0xf]
    // 0x12ec914: DecompressPointer r4
    //     0x12ec914: add             x4, x4, HEAP, lsl #32
    // 0x12ec918: stur            x4, [fp, #-0x30]
    // 0x12ec91c: r0 = BorderRadius()
    //     0x12ec91c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ec920: mov             x1, x0
    // 0x12ec924: ldur            x0, [fp, #-0x48]
    // 0x12ec928: StoreField: r1->field_7 = r0
    //     0x12ec928: stur            w0, [x1, #7]
    // 0x12ec92c: ldur            x0, [fp, #-0x40]
    // 0x12ec930: StoreField: r1->field_b = r0
    //     0x12ec930: stur            w0, [x1, #0xb]
    // 0x12ec934: ldur            x0, [fp, #-0x38]
    // 0x12ec938: StoreField: r1->field_f = r0
    //     0x12ec938: stur            w0, [x1, #0xf]
    // 0x12ec93c: ldur            x0, [fp, #-0x30]
    // 0x12ec940: StoreField: r1->field_13 = r0
    //     0x12ec940: stur            w0, [x1, #0x13]
    // 0x12ec944: b               #0x12ec9dc
    // 0x12ec948: LoadField: r1 = r0->field_7
    //     0x12ec948: ldur            w1, [x0, #7]
    // 0x12ec94c: DecompressPointer r1
    //     0x12ec94c: add             x1, x1, HEAP, lsl #32
    // 0x12ec950: stur            x1, [fp, #-0x48]
    // 0x12ec954: LoadField: r2 = r0->field_b
    //     0x12ec954: ldur            w2, [x0, #0xb]
    // 0x12ec958: DecompressPointer r2
    //     0x12ec958: add             x2, x2, HEAP, lsl #32
    // 0x12ec95c: stur            x2, [fp, #-0x40]
    // 0x12ec960: LoadField: r3 = r0->field_f
    //     0x12ec960: ldur            w3, [x0, #0xf]
    // 0x12ec964: DecompressPointer r3
    //     0x12ec964: add             x3, x3, HEAP, lsl #32
    // 0x12ec968: stur            x3, [fp, #-0x38]
    // 0x12ec96c: LoadField: r4 = r0->field_13
    //     0x12ec96c: ldur            w4, [x0, #0x13]
    // 0x12ec970: DecompressPointer r4
    //     0x12ec970: add             x4, x4, HEAP, lsl #32
    // 0x12ec974: stur            x4, [fp, #-0x30]
    // 0x12ec978: r0 = BorderRadius()
    //     0x12ec978: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12ec97c: mov             x1, x0
    // 0x12ec980: ldur            x0, [fp, #-0x48]
    // 0x12ec984: StoreField: r1->field_7 = r0
    //     0x12ec984: stur            w0, [x1, #7]
    // 0x12ec988: ldur            x0, [fp, #-0x40]
    // 0x12ec98c: StoreField: r1->field_b = r0
    //     0x12ec98c: stur            w0, [x1, #0xb]
    // 0x12ec990: ldur            x0, [fp, #-0x38]
    // 0x12ec994: StoreField: r1->field_f = r0
    //     0x12ec994: stur            w0, [x1, #0xf]
    // 0x12ec998: ldur            x0, [fp, #-0x30]
    // 0x12ec99c: StoreField: r1->field_13 = r0
    //     0x12ec99c: stur            w0, [x1, #0x13]
    // 0x12ec9a0: b               #0x12ec9dc
    // 0x12ec9a4: ldur            x2, [fp, #-8]
    // 0x12ec9a8: cmp             x1, #0xb89
    // 0x12ec9ac: b.ne            #0x12ec9b8
    // 0x12ec9b0: mov             x1, x0
    // 0x12ec9b4: b               #0x12ec9dc
    // 0x12ec9b8: r1 = LoadClassIdInstr(r0)
    //     0x12ec9b8: ldur            x1, [x0, #-1]
    //     0x12ec9bc: ubfx            x1, x1, #0xc, #0x14
    // 0x12ec9c0: mov             x16, x0
    // 0x12ec9c4: mov             x0, x1
    // 0x12ec9c8: mov             x1, x16
    // 0x12ec9cc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ec9cc: sub             lr, x0, #1, lsl #12
    //     0x12ec9d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12ec9d4: blr             lr
    // 0x12ec9d8: mov             x1, x0
    // 0x12ec9dc: ldur            x2, [fp, #-0x18]
    // 0x12ec9e0: r0 = toRRect()
    //     0x12ec9e0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ec9e4: ldur            x1, [fp, #-0x10]
    // 0x12ec9e8: mov             x2, x0
    // 0x12ec9ec: ldur            x3, [fp, #-0x20]
    // 0x12ec9f0: r0 = drawRRect()
    //     0x12ec9f0: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ec9f4: r0 = Null
    //     0x12ec9f4: mov             x0, NULL
    // 0x12ec9f8: LeaveFrame
    //     0x12ec9f8: mov             SP, fp
    //     0x12ec9fc: ldp             fp, lr, [SP], #0x10
    // 0x12eca00: ret
    //     0x12eca00: ret             
    // 0x12eca04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eca04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eca08: b               #0x12ec88c
    // 0x12eca0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eca0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x12eda6c, size: 0x210
    // 0x12eda6c: EnterFrame
    //     0x12eda6c: stp             fp, lr, [SP, #-0x10]!
    //     0x12eda70: mov             fp, SP
    // 0x12eda74: AllocStack(0x40)
    //     0x12eda74: sub             SP, SP, #0x40
    // 0x12eda78: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */, {dynamic textDirection = Null /* r4, fp-0x10 */})
    //     0x12eda78: mov             x0, x3
    //     0x12eda7c: stur            x3, [fp, #-0x20]
    //     0x12eda80: mov             x3, x2
    //     0x12eda84: stur            x2, [fp, #-0x18]
    //     0x12eda88: ldur            w2, [x4, #0x13]
    //     0x12eda8c: ldur            w5, [x4, #0x1f]
    //     0x12eda90: add             x5, x5, HEAP, lsl #32
    //     0x12eda94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12eda98: ldr             x16, [x16, #0x210]
    //     0x12eda9c: cmp             w5, w16
    //     0x12edaa0: b.ne            #0x12edac0
    //     0x12edaa4: ldur            w5, [x4, #0x23]
    //     0x12edaa8: add             x5, x5, HEAP, lsl #32
    //     0x12edaac: sub             w4, w2, w5
    //     0x12edab0: add             x2, fp, w4, sxtw #2
    //     0x12edab4: ldr             x2, [x2, #8]
    //     0x12edab8: mov             x4, x2
    //     0x12edabc: b               #0x12edac4
    //     0x12edac0: mov             x4, NULL
    //     0x12edac4: stur            x4, [fp, #-0x10]
    // 0x12edac8: CheckStackOverflow
    //     0x12edac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12edacc: cmp             SP, x16
    //     0x12edad0: b.ls            #0x12edc70
    // 0x12edad4: LoadField: r5 = r1->field_7
    //     0x12edad4: ldur            w5, [x1, #7]
    // 0x12edad8: DecompressPointer r5
    //     0x12edad8: add             x5, x5, HEAP, lsl #32
    // 0x12edadc: stur            x5, [fp, #-8]
    // 0x12edae0: LoadField: r2 = r5->field_13
    //     0x12edae0: ldur            w2, [x5, #0x13]
    // 0x12edae4: DecompressPointer r2
    //     0x12edae4: add             x2, x2, HEAP, lsl #32
    // 0x12edae8: LoadField: r6 = r2->field_7
    //     0x12edae8: ldur            x6, [x2, #7]
    // 0x12edaec: cmp             x6, #0
    // 0x12edaf0: b.le            #0x12edc60
    // 0x12edaf4: mov             x2, x0
    // 0x12edaf8: r0 = _adjustBorderRadius()
    //     0x12edaf8: bl              #0xbff75c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0x12edafc: r1 = LoadClassIdInstr(r0)
    //     0x12edafc: ldur            x1, [x0, #-1]
    //     0x12edb00: ubfx            x1, x1, #0xc, #0x14
    // 0x12edb04: cmp             x1, #0xb88
    // 0x12edb08: b.ne            #0x12edbdc
    // 0x12edb0c: ldur            x2, [fp, #-0x10]
    // 0x12edb10: cmp             w2, NULL
    // 0x12edb14: b.eq            #0x12edc78
    // 0x12edb18: LoadField: r1 = r2->field_7
    //     0x12edb18: ldur            x1, [x2, #7]
    // 0x12edb1c: cmp             x1, #0
    // 0x12edb20: b.gt            #0x12edb80
    // 0x12edb24: LoadField: r1 = r0->field_b
    //     0x12edb24: ldur            w1, [x0, #0xb]
    // 0x12edb28: DecompressPointer r1
    //     0x12edb28: add             x1, x1, HEAP, lsl #32
    // 0x12edb2c: stur            x1, [fp, #-0x40]
    // 0x12edb30: LoadField: r2 = r0->field_7
    //     0x12edb30: ldur            w2, [x0, #7]
    // 0x12edb34: DecompressPointer r2
    //     0x12edb34: add             x2, x2, HEAP, lsl #32
    // 0x12edb38: stur            x2, [fp, #-0x38]
    // 0x12edb3c: LoadField: r3 = r0->field_13
    //     0x12edb3c: ldur            w3, [x0, #0x13]
    // 0x12edb40: DecompressPointer r3
    //     0x12edb40: add             x3, x3, HEAP, lsl #32
    // 0x12edb44: stur            x3, [fp, #-0x30]
    // 0x12edb48: LoadField: r4 = r0->field_f
    //     0x12edb48: ldur            w4, [x0, #0xf]
    // 0x12edb4c: DecompressPointer r4
    //     0x12edb4c: add             x4, x4, HEAP, lsl #32
    // 0x12edb50: stur            x4, [fp, #-0x28]
    // 0x12edb54: r0 = BorderRadius()
    //     0x12edb54: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12edb58: mov             x1, x0
    // 0x12edb5c: ldur            x0, [fp, #-0x40]
    // 0x12edb60: StoreField: r1->field_7 = r0
    //     0x12edb60: stur            w0, [x1, #7]
    // 0x12edb64: ldur            x0, [fp, #-0x38]
    // 0x12edb68: StoreField: r1->field_b = r0
    //     0x12edb68: stur            w0, [x1, #0xb]
    // 0x12edb6c: ldur            x0, [fp, #-0x30]
    // 0x12edb70: StoreField: r1->field_f = r0
    //     0x12edb70: stur            w0, [x1, #0xf]
    // 0x12edb74: ldur            x0, [fp, #-0x28]
    // 0x12edb78: StoreField: r1->field_13 = r0
    //     0x12edb78: stur            w0, [x1, #0x13]
    // 0x12edb7c: b               #0x12edc14
    // 0x12edb80: LoadField: r1 = r0->field_7
    //     0x12edb80: ldur            w1, [x0, #7]
    // 0x12edb84: DecompressPointer r1
    //     0x12edb84: add             x1, x1, HEAP, lsl #32
    // 0x12edb88: stur            x1, [fp, #-0x40]
    // 0x12edb8c: LoadField: r2 = r0->field_b
    //     0x12edb8c: ldur            w2, [x0, #0xb]
    // 0x12edb90: DecompressPointer r2
    //     0x12edb90: add             x2, x2, HEAP, lsl #32
    // 0x12edb94: stur            x2, [fp, #-0x38]
    // 0x12edb98: LoadField: r3 = r0->field_f
    //     0x12edb98: ldur            w3, [x0, #0xf]
    // 0x12edb9c: DecompressPointer r3
    //     0x12edb9c: add             x3, x3, HEAP, lsl #32
    // 0x12edba0: stur            x3, [fp, #-0x30]
    // 0x12edba4: LoadField: r4 = r0->field_13
    //     0x12edba4: ldur            w4, [x0, #0x13]
    // 0x12edba8: DecompressPointer r4
    //     0x12edba8: add             x4, x4, HEAP, lsl #32
    // 0x12edbac: stur            x4, [fp, #-0x28]
    // 0x12edbb0: r0 = BorderRadius()
    //     0x12edbb0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12edbb4: mov             x1, x0
    // 0x12edbb8: ldur            x0, [fp, #-0x40]
    // 0x12edbbc: StoreField: r1->field_7 = r0
    //     0x12edbbc: stur            w0, [x1, #7]
    // 0x12edbc0: ldur            x0, [fp, #-0x38]
    // 0x12edbc4: StoreField: r1->field_b = r0
    //     0x12edbc4: stur            w0, [x1, #0xb]
    // 0x12edbc8: ldur            x0, [fp, #-0x30]
    // 0x12edbcc: StoreField: r1->field_f = r0
    //     0x12edbcc: stur            w0, [x1, #0xf]
    // 0x12edbd0: ldur            x0, [fp, #-0x28]
    // 0x12edbd4: StoreField: r1->field_13 = r0
    //     0x12edbd4: stur            w0, [x1, #0x13]
    // 0x12edbd8: b               #0x12edc14
    // 0x12edbdc: ldur            x2, [fp, #-0x10]
    // 0x12edbe0: cmp             x1, #0xb89
    // 0x12edbe4: b.ne            #0x12edbf0
    // 0x12edbe8: mov             x1, x0
    // 0x12edbec: b               #0x12edc14
    // 0x12edbf0: r1 = LoadClassIdInstr(r0)
    //     0x12edbf0: ldur            x1, [x0, #-1]
    //     0x12edbf4: ubfx            x1, x1, #0xc, #0x14
    // 0x12edbf8: mov             x16, x0
    // 0x12edbfc: mov             x0, x1
    // 0x12edc00: mov             x1, x16
    // 0x12edc04: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12edc04: sub             lr, x0, #1, lsl #12
    //     0x12edc08: ldr             lr, [x21, lr, lsl #3]
    //     0x12edc0c: blr             lr
    // 0x12edc10: mov             x1, x0
    // 0x12edc14: ldur            x0, [fp, #-8]
    // 0x12edc18: ldur            x2, [fp, #-0x20]
    // 0x12edc1c: r0 = toRRect()
    //     0x12edc1c: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12edc20: mov             x1, x0
    // 0x12edc24: ldur            x0, [fp, #-8]
    // 0x12edc28: LoadField: d0 = r0->field_b
    //     0x12edc28: ldur            d0, [x0, #0xb]
    // 0x12edc2c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12edc2c: ldur            d1, [x0, #0x17]
    // 0x12edc30: fmul            d2, d0, d1
    // 0x12edc34: d0 = 2.000000
    //     0x12edc34: fmov            d0, #2.00000000
    // 0x12edc38: fdiv            d1, d2, d0
    // 0x12edc3c: mov             v0.16b, v1.16b
    // 0x12edc40: r0 = inflate()
    //     0x12edc40: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12edc44: ldur            x1, [fp, #-8]
    // 0x12edc48: stur            x0, [fp, #-8]
    // 0x12edc4c: r0 = toPaint()
    //     0x12edc4c: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12edc50: ldur            x1, [fp, #-0x18]
    // 0x12edc54: ldur            x2, [fp, #-8]
    // 0x12edc58: mov             x3, x0
    // 0x12edc5c: r0 = drawRRect()
    //     0x12edc5c: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12edc60: r0 = Null
    //     0x12edc60: mov             x0, NULL
    // 0x12edc64: LeaveFrame
    //     0x12edc64: mov             SP, fp
    //     0x12edc68: ldp             fp, lr, [SP], #0x10
    // 0x12edc6c: ret
    //     0x12edc6c: ret             
    // 0x12edc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12edc70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12edc74: b               #0x12edad4
    // 0x12edc78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12edc78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fcdb8, size: 0x1ec
    // 0x12fcdb8: EnterFrame
    //     0x12fcdb8: stp             fp, lr, [SP, #-0x10]!
    //     0x12fcdbc: mov             fp, SP
    // 0x12fcdc0: AllocStack(0x38)
    //     0x12fcdc0: sub             SP, SP, #0x38
    // 0x12fcdc4: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x38 */)
    //     0x12fcdc4: mov             x0, x1
    //     0x12fcdc8: mov             v1.16b, v0.16b
    //     0x12fcdcc: stur            x1, [fp, #-8]
    //     0x12fcdd0: stur            d0, [fp, #-0x38]
    // 0x12fcdd4: CheckStackOverflow
    //     0x12fcdd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcdd8: cmp             SP, x16
    //     0x12fcddc: b.ls            #0x12fcf9c
    // 0x12fcde0: LoadField: r1 = r0->field_7
    //     0x12fcde0: ldur            w1, [x0, #7]
    // 0x12fcde4: DecompressPointer r1
    //     0x12fcde4: add             x1, x1, HEAP, lsl #32
    // 0x12fcde8: mov             v0.16b, v1.16b
    // 0x12fcdec: r0 = scale()
    //     0x12fcdec: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fcdf0: mov             x2, x0
    // 0x12fcdf4: ldur            x0, [fp, #-8]
    // 0x12fcdf8: stur            x2, [fp, #-0x18]
    // 0x12fcdfc: LoadField: r3 = r0->field_b
    //     0x12fcdfc: ldur            w3, [x0, #0xb]
    // 0x12fce00: DecompressPointer r3
    //     0x12fce00: add             x3, x3, HEAP, lsl #32
    // 0x12fce04: stur            x3, [fp, #-0x10]
    // 0x12fce08: r0 = LoadClassIdInstr(r3)
    //     0x12fce08: ldur            x0, [x3, #-1]
    //     0x12fce0c: ubfx            x0, x0, #0xc, #0x14
    // 0x12fce10: cmp             x0, #0xb88
    // 0x12fce14: b.ne            #0x12fcea8
    // 0x12fce18: LoadField: r1 = r3->field_7
    //     0x12fce18: ldur            w1, [x3, #7]
    // 0x12fce1c: DecompressPointer r1
    //     0x12fce1c: add             x1, x1, HEAP, lsl #32
    // 0x12fce20: ldur            d0, [fp, #-0x38]
    // 0x12fce24: r0 = *()
    //     0x12fce24: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fce28: mov             x2, x0
    // 0x12fce2c: ldur            x0, [fp, #-0x10]
    // 0x12fce30: stur            x2, [fp, #-8]
    // 0x12fce34: LoadField: r1 = r0->field_b
    //     0x12fce34: ldur            w1, [x0, #0xb]
    // 0x12fce38: DecompressPointer r1
    //     0x12fce38: add             x1, x1, HEAP, lsl #32
    // 0x12fce3c: ldur            d0, [fp, #-0x38]
    // 0x12fce40: r0 = *()
    //     0x12fce40: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fce44: mov             x2, x0
    // 0x12fce48: ldur            x0, [fp, #-0x10]
    // 0x12fce4c: stur            x2, [fp, #-0x20]
    // 0x12fce50: LoadField: r1 = r0->field_f
    //     0x12fce50: ldur            w1, [x0, #0xf]
    // 0x12fce54: DecompressPointer r1
    //     0x12fce54: add             x1, x1, HEAP, lsl #32
    // 0x12fce58: ldur            d0, [fp, #-0x38]
    // 0x12fce5c: r0 = *()
    //     0x12fce5c: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fce60: ldur            x2, [fp, #-0x10]
    // 0x12fce64: stur            x0, [fp, #-0x28]
    // 0x12fce68: LoadField: r1 = r2->field_13
    //     0x12fce68: ldur            w1, [x2, #0x13]
    // 0x12fce6c: DecompressPointer r1
    //     0x12fce6c: add             x1, x1, HEAP, lsl #32
    // 0x12fce70: ldur            d0, [fp, #-0x38]
    // 0x12fce74: r0 = *()
    //     0x12fce74: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fce78: stur            x0, [fp, #-0x30]
    // 0x12fce7c: r0 = BorderRadiusDirectional()
    //     0x12fce7c: bl              #0xb777c4  ; AllocateBorderRadiusDirectionalStub -> BorderRadiusDirectional (size=0x18)
    // 0x12fce80: mov             x1, x0
    // 0x12fce84: ldur            x0, [fp, #-8]
    // 0x12fce88: StoreField: r1->field_7 = r0
    //     0x12fce88: stur            w0, [x1, #7]
    // 0x12fce8c: ldur            x0, [fp, #-0x20]
    // 0x12fce90: StoreField: r1->field_b = r0
    //     0x12fce90: stur            w0, [x1, #0xb]
    // 0x12fce94: ldur            x0, [fp, #-0x28]
    // 0x12fce98: StoreField: r1->field_f = r0
    //     0x12fce98: stur            w0, [x1, #0xf]
    // 0x12fce9c: ldur            x0, [fp, #-0x30]
    // 0x12fcea0: StoreField: r1->field_13 = r0
    //     0x12fcea0: stur            w0, [x1, #0x13]
    // 0x12fcea4: b               #0x12fcf68
    // 0x12fcea8: mov             x2, x3
    // 0x12fceac: cmp             x0, #0xb89
    // 0x12fceb0: b.ne            #0x12fcf48
    // 0x12fceb4: LoadField: r1 = r2->field_7
    //     0x12fceb4: ldur            w1, [x2, #7]
    // 0x12fceb8: DecompressPointer r1
    //     0x12fceb8: add             x1, x1, HEAP, lsl #32
    // 0x12fcebc: ldur            d0, [fp, #-0x38]
    // 0x12fcec0: r0 = *()
    //     0x12fcec0: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fcec4: mov             x2, x0
    // 0x12fcec8: ldur            x0, [fp, #-0x10]
    // 0x12fcecc: stur            x2, [fp, #-8]
    // 0x12fced0: LoadField: r1 = r0->field_b
    //     0x12fced0: ldur            w1, [x0, #0xb]
    // 0x12fced4: DecompressPointer r1
    //     0x12fced4: add             x1, x1, HEAP, lsl #32
    // 0x12fced8: ldur            d0, [fp, #-0x38]
    // 0x12fcedc: r0 = *()
    //     0x12fcedc: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fcee0: mov             x2, x0
    // 0x12fcee4: ldur            x0, [fp, #-0x10]
    // 0x12fcee8: stur            x2, [fp, #-0x20]
    // 0x12fceec: LoadField: r1 = r0->field_f
    //     0x12fceec: ldur            w1, [x0, #0xf]
    // 0x12fcef0: DecompressPointer r1
    //     0x12fcef0: add             x1, x1, HEAP, lsl #32
    // 0x12fcef4: ldur            d0, [fp, #-0x38]
    // 0x12fcef8: r0 = *()
    //     0x12fcef8: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fcefc: ldur            x1, [fp, #-0x10]
    // 0x12fcf00: stur            x0, [fp, #-0x28]
    // 0x12fcf04: LoadField: r2 = r1->field_13
    //     0x12fcf04: ldur            w2, [x1, #0x13]
    // 0x12fcf08: DecompressPointer r2
    //     0x12fcf08: add             x2, x2, HEAP, lsl #32
    // 0x12fcf0c: mov             x1, x2
    // 0x12fcf10: ldur            d0, [fp, #-0x38]
    // 0x12fcf14: r0 = *()
    //     0x12fcf14: bl              #0x8a523c  ; [dart:ui] Radius::*
    // 0x12fcf18: stur            x0, [fp, #-0x30]
    // 0x12fcf1c: r0 = BorderRadius()
    //     0x12fcf1c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x12fcf20: mov             x1, x0
    // 0x12fcf24: ldur            x0, [fp, #-8]
    // 0x12fcf28: StoreField: r1->field_7 = r0
    //     0x12fcf28: stur            w0, [x1, #7]
    // 0x12fcf2c: ldur            x0, [fp, #-0x20]
    // 0x12fcf30: StoreField: r1->field_b = r0
    //     0x12fcf30: stur            w0, [x1, #0xb]
    // 0x12fcf34: ldur            x0, [fp, #-0x28]
    // 0x12fcf38: StoreField: r1->field_f = r0
    //     0x12fcf38: stur            w0, [x1, #0xf]
    // 0x12fcf3c: ldur            x0, [fp, #-0x30]
    // 0x12fcf40: StoreField: r1->field_13 = r0
    //     0x12fcf40: stur            w0, [x1, #0x13]
    // 0x12fcf44: b               #0x12fcf68
    // 0x12fcf48: mov             x1, x2
    // 0x12fcf4c: r0 = LoadClassIdInstr(r1)
    //     0x12fcf4c: ldur            x0, [x1, #-1]
    //     0x12fcf50: ubfx            x0, x0, #0xc, #0x14
    // 0x12fcf54: ldur            d0, [fp, #-0x38]
    // 0x12fcf58: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x12fcf58: sub             lr, x0, #0xfb8
    //     0x12fcf5c: ldr             lr, [x21, lr, lsl #3]
    //     0x12fcf60: blr             lr
    // 0x12fcf64: mov             x1, x0
    // 0x12fcf68: ldur            d0, [fp, #-0x38]
    // 0x12fcf6c: ldur            x0, [fp, #-0x18]
    // 0x12fcf70: stur            x1, [fp, #-8]
    // 0x12fcf74: r0 = _StadiumToRoundedRectangleBorder()
    //     0x12fcf74: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x12fcf78: ldur            x1, [fp, #-8]
    // 0x12fcf7c: StoreField: r0->field_b = r1
    //     0x12fcf7c: stur            w1, [x0, #0xb]
    // 0x12fcf80: ldur            d0, [fp, #-0x38]
    // 0x12fcf84: StoreField: r0->field_f = d0
    //     0x12fcf84: stur            d0, [x0, #0xf]
    // 0x12fcf88: ldur            x1, [fp, #-0x18]
    // 0x12fcf8c: StoreField: r0->field_7 = r1
    //     0x12fcf8c: stur            w1, [x0, #7]
    // 0x12fcf90: LeaveFrame
    //     0x12fcf90: mov             SP, fp
    //     0x12fcf94: ldp             fp, lr, [SP], #0x10
    // 0x12fcf98: ret
    //     0x12fcf98: ret             
    // 0x12fcf9c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fcf9c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fcfa0: b               #0x12fcde0
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300810, size: 0x2bc
    // 0x1300810: EnterFrame
    //     0x1300810: stp             fp, lr, [SP, #-0x10]!
    //     0x1300814: mov             fp, SP
    // 0x1300818: AllocStack(0x50)
    //     0x1300818: sub             SP, SP, #0x50
    // 0x130081c: SetupParameters(_StadiumToRoundedRectangleBorder this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0x130081c: stur            x1, [fp, #-0x10]
    //     0x1300820: stur            x2, [fp, #-0x18]
    //     0x1300824: ldur            w0, [x4, #0x13]
    //     0x1300828: ldur            w3, [x4, #0x1f]
    //     0x130082c: add             x3, x3, HEAP, lsl #32
    //     0x1300830: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x1300834: ldr             x16, [x16, #0x210]
    //     0x1300838: cmp             w3, w16
    //     0x130083c: b.ne            #0x1300858
    //     0x1300840: ldur            w3, [x4, #0x23]
    //     0x1300844: add             x3, x3, HEAP, lsl #32
    //     0x1300848: sub             w4, w0, w3
    //     0x130084c: add             x0, fp, w4, sxtw #2
    //     0x1300850: ldr             x0, [x0, #8]
    //     0x1300854: b               #0x130085c
    //     0x1300858: mov             x0, NULL
    //     0x130085c: stur            x0, [fp, #-8]
    // 0x1300860: CheckStackOverflow
    //     0x1300860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1300864: cmp             SP, x16
    //     0x1300868: b.ls            #0x1300abc
    // 0x130086c: r0 = _NativePath()
    //     0x130086c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1300870: mov             x1, x0
    // 0x1300874: stur            x0, [fp, #-0x20]
    // 0x1300878: r0 = __constructor$Method$FfiNative()
    //     0x1300878: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x130087c: ldur            x1, [fp, #-0x10]
    // 0x1300880: ldur            x2, [fp, #-0x18]
    // 0x1300884: r0 = _adjustBorderRadius()
    //     0x1300884: bl              #0xbff75c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0x1300888: r1 = LoadClassIdInstr(r0)
    //     0x1300888: ldur            x1, [x0, #-1]
    //     0x130088c: ubfx            x1, x1, #0xc, #0x14
    // 0x1300890: cmp             x1, #0xb88
    // 0x1300894: b.ne            #0x1300968
    // 0x1300898: ldur            x2, [fp, #-8]
    // 0x130089c: cmp             w2, NULL
    // 0x13008a0: b.eq            #0x1300ac4
    // 0x13008a4: LoadField: r1 = r2->field_7
    //     0x13008a4: ldur            x1, [x2, #7]
    // 0x13008a8: cmp             x1, #0
    // 0x13008ac: b.gt            #0x130090c
    // 0x13008b0: LoadField: r1 = r0->field_b
    //     0x13008b0: ldur            w1, [x0, #0xb]
    // 0x13008b4: DecompressPointer r1
    //     0x13008b4: add             x1, x1, HEAP, lsl #32
    // 0x13008b8: stur            x1, [fp, #-0x38]
    // 0x13008bc: LoadField: r2 = r0->field_7
    //     0x13008bc: ldur            w2, [x0, #7]
    // 0x13008c0: DecompressPointer r2
    //     0x13008c0: add             x2, x2, HEAP, lsl #32
    // 0x13008c4: stur            x2, [fp, #-0x30]
    // 0x13008c8: LoadField: r3 = r0->field_13
    //     0x13008c8: ldur            w3, [x0, #0x13]
    // 0x13008cc: DecompressPointer r3
    //     0x13008cc: add             x3, x3, HEAP, lsl #32
    // 0x13008d0: stur            x3, [fp, #-0x28]
    // 0x13008d4: LoadField: r4 = r0->field_f
    //     0x13008d4: ldur            w4, [x0, #0xf]
    // 0x13008d8: DecompressPointer r4
    //     0x13008d8: add             x4, x4, HEAP, lsl #32
    // 0x13008dc: stur            x4, [fp, #-0x10]
    // 0x13008e0: r0 = BorderRadius()
    //     0x13008e0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x13008e4: mov             x1, x0
    // 0x13008e8: ldur            x0, [fp, #-0x38]
    // 0x13008ec: StoreField: r1->field_7 = r0
    //     0x13008ec: stur            w0, [x1, #7]
    // 0x13008f0: ldur            x0, [fp, #-0x30]
    // 0x13008f4: StoreField: r1->field_b = r0
    //     0x13008f4: stur            w0, [x1, #0xb]
    // 0x13008f8: ldur            x0, [fp, #-0x28]
    // 0x13008fc: StoreField: r1->field_f = r0
    //     0x13008fc: stur            w0, [x1, #0xf]
    // 0x1300900: ldur            x0, [fp, #-0x10]
    // 0x1300904: StoreField: r1->field_13 = r0
    //     0x1300904: stur            w0, [x1, #0x13]
    // 0x1300908: b               #0x13009a0
    // 0x130090c: LoadField: r1 = r0->field_7
    //     0x130090c: ldur            w1, [x0, #7]
    // 0x1300910: DecompressPointer r1
    //     0x1300910: add             x1, x1, HEAP, lsl #32
    // 0x1300914: stur            x1, [fp, #-0x38]
    // 0x1300918: LoadField: r2 = r0->field_b
    //     0x1300918: ldur            w2, [x0, #0xb]
    // 0x130091c: DecompressPointer r2
    //     0x130091c: add             x2, x2, HEAP, lsl #32
    // 0x1300920: stur            x2, [fp, #-0x30]
    // 0x1300924: LoadField: r3 = r0->field_f
    //     0x1300924: ldur            w3, [x0, #0xf]
    // 0x1300928: DecompressPointer r3
    //     0x1300928: add             x3, x3, HEAP, lsl #32
    // 0x130092c: stur            x3, [fp, #-0x28]
    // 0x1300930: LoadField: r4 = r0->field_13
    //     0x1300930: ldur            w4, [x0, #0x13]
    // 0x1300934: DecompressPointer r4
    //     0x1300934: add             x4, x4, HEAP, lsl #32
    // 0x1300938: stur            x4, [fp, #-0x10]
    // 0x130093c: r0 = BorderRadius()
    //     0x130093c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x1300940: mov             x1, x0
    // 0x1300944: ldur            x0, [fp, #-0x38]
    // 0x1300948: StoreField: r1->field_7 = r0
    //     0x1300948: stur            w0, [x1, #7]
    // 0x130094c: ldur            x0, [fp, #-0x30]
    // 0x1300950: StoreField: r1->field_b = r0
    //     0x1300950: stur            w0, [x1, #0xb]
    // 0x1300954: ldur            x0, [fp, #-0x28]
    // 0x1300958: StoreField: r1->field_f = r0
    //     0x1300958: stur            w0, [x1, #0xf]
    // 0x130095c: ldur            x0, [fp, #-0x10]
    // 0x1300960: StoreField: r1->field_13 = r0
    //     0x1300960: stur            w0, [x1, #0x13]
    // 0x1300964: b               #0x13009a0
    // 0x1300968: ldur            x2, [fp, #-8]
    // 0x130096c: cmp             x1, #0xb89
    // 0x1300970: b.ne            #0x130097c
    // 0x1300974: mov             x1, x0
    // 0x1300978: b               #0x13009a0
    // 0x130097c: r1 = LoadClassIdInstr(r0)
    //     0x130097c: ldur            x1, [x0, #-1]
    //     0x1300980: ubfx            x1, x1, #0xc, #0x14
    // 0x1300984: mov             x16, x0
    // 0x1300988: mov             x0, x1
    // 0x130098c: mov             x1, x16
    // 0x1300990: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1300990: sub             lr, x0, #1, lsl #12
    //     0x1300994: ldr             lr, [x21, lr, lsl #3]
    //     0x1300998: blr             lr
    // 0x130099c: mov             x1, x0
    // 0x13009a0: ldur            x0, [fp, #-0x20]
    // 0x13009a4: ldur            x2, [fp, #-0x18]
    // 0x13009a8: r0 = toRRect()
    //     0x13009a8: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x13009ac: stur            x0, [fp, #-8]
    // 0x13009b0: LoadField: d0 = r0->field_b
    //     0x13009b0: ldur            d0, [x0, #0xb]
    // 0x13009b4: fcvt            s1, d0
    // 0x13009b8: stur            d1, [fp, #-0x48]
    // 0x13009bc: r4 = 24
    //     0x13009bc: mov             x4, #0x18
    // 0x13009c0: r0 = AllocateFloat32Array()
    //     0x13009c0: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x13009c4: ldur            d0, [fp, #-0x48]
    // 0x13009c8: stur            x0, [fp, #-0x10]
    // 0x13009cc: ArrayStore: r0[0] = d0  ; List_8
    //     0x13009cc: stur            s0, [x0, #0x17]
    // 0x13009d0: ldur            x1, [fp, #-8]
    // 0x13009d4: LoadField: d0 = r1->field_13
    //     0x13009d4: ldur            d0, [x1, #0x13]
    // 0x13009d8: fcvt            s1, d0
    // 0x13009dc: StoreField: r0->field_1b = d1
    //     0x13009dc: stur            s1, [x0, #0x1b]
    // 0x13009e0: LoadField: d0 = r1->field_1b
    //     0x13009e0: ldur            d0, [x1, #0x1b]
    // 0x13009e4: fcvt            s1, d0
    // 0x13009e8: StoreField: r0->field_1f = d1
    //     0x13009e8: stur            s1, [x0, #0x1f]
    // 0x13009ec: LoadField: d0 = r1->field_23
    //     0x13009ec: ldur            d0, [x1, #0x23]
    // 0x13009f0: fcvt            s1, d0
    // 0x13009f4: StoreField: r0->field_23 = d1
    //     0x13009f4: stur            s1, [x0, #0x23]
    // 0x13009f8: LoadField: d0 = r1->field_2b
    //     0x13009f8: ldur            d0, [x1, #0x2b]
    // 0x13009fc: fcvt            s1, d0
    // 0x1300a00: StoreField: r0->field_27 = d1
    //     0x1300a00: stur            s1, [x0, #0x27]
    // 0x1300a04: LoadField: d0 = r1->field_33
    //     0x1300a04: ldur            d0, [x1, #0x33]
    // 0x1300a08: fcvt            s1, d0
    // 0x1300a0c: StoreField: r0->field_2b = d1
    //     0x1300a0c: stur            s1, [x0, #0x2b]
    // 0x1300a10: LoadField: d0 = r1->field_3b
    //     0x1300a10: ldur            d0, [x1, #0x3b]
    // 0x1300a14: fcvt            s1, d0
    // 0x1300a18: StoreField: r0->field_2f = d1
    //     0x1300a18: stur            s1, [x0, #0x2f]
    // 0x1300a1c: LoadField: d0 = r1->field_43
    //     0x1300a1c: ldur            d0, [x1, #0x43]
    // 0x1300a20: fcvt            s1, d0
    // 0x1300a24: StoreField: r0->field_33 = d1
    //     0x1300a24: stur            s1, [x0, #0x33]
    // 0x1300a28: LoadField: d0 = r1->field_4b
    //     0x1300a28: ldur            d0, [x1, #0x4b]
    // 0x1300a2c: fcvt            s1, d0
    // 0x1300a30: StoreField: r0->field_37 = d1
    //     0x1300a30: stur            s1, [x0, #0x37]
    // 0x1300a34: LoadField: d0 = r1->field_53
    //     0x1300a34: ldur            d0, [x1, #0x53]
    // 0x1300a38: fcvt            s1, d0
    // 0x1300a3c: StoreField: r0->field_3b = d1
    //     0x1300a3c: stur            s1, [x0, #0x3b]
    // 0x1300a40: LoadField: d0 = r1->field_5b
    //     0x1300a40: ldur            d0, [x1, #0x5b]
    // 0x1300a44: fcvt            s1, d0
    // 0x1300a48: StoreField: r0->field_3f = d1
    //     0x1300a48: stur            s1, [x0, #0x3f]
    // 0x1300a4c: LoadField: d0 = r1->field_63
    //     0x1300a4c: ldur            d0, [x1, #0x63]
    // 0x1300a50: fcvt            s1, d0
    // 0x1300a54: StoreField: r0->field_43 = d1
    //     0x1300a54: stur            s1, [x0, #0x43]
    // 0x1300a58: ldur            x2, [fp, #-0x20]
    // 0x1300a5c: LoadField: r1 = r2->field_7
    //     0x1300a5c: ldur            w1, [x2, #7]
    // 0x1300a60: DecompressPointer r1
    //     0x1300a60: add             x1, x1, HEAP, lsl #32
    // 0x1300a64: cmp             w1, NULL
    // 0x1300a68: b.eq            #0x1300ac8
    // 0x1300a6c: LoadField: r3 = r1->field_7
    //     0x1300a6c: ldur            x3, [x1, #7]
    // 0x1300a70: ldr             x1, [x3]
    // 0x1300a74: cbz             x1, #0x1300aac
    // 0x1300a78: mov             x3, x1
    // 0x1300a7c: stur            x3, [fp, #-0x40]
    // 0x1300a80: r1 = <Never>
    //     0x1300a80: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300a84: r0 = Pointer()
    //     0x1300a84: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1300a88: mov             x1, x0
    // 0x1300a8c: ldur            x0, [fp, #-0x40]
    // 0x1300a90: StoreField: r1->field_7 = r0
    //     0x1300a90: stur            x0, [x1, #7]
    // 0x1300a94: ldur            x2, [fp, #-0x10]
    // 0x1300a98: r0 = __addRRect$Method$FfiNative()
    //     0x1300a98: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x1300a9c: ldur            x0, [fp, #-0x20]
    // 0x1300aa0: LeaveFrame
    //     0x1300aa0: mov             SP, fp
    //     0x1300aa4: ldp             fp, lr, [SP], #0x10
    // 0x1300aa8: ret
    //     0x1300aa8: ret             
    // 0x1300aac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300aac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300ab0: str             x16, [SP]
    // 0x1300ab4: r0 = _throwNew()
    //     0x1300ab4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300ab8: brk             #0
    // 0x1300abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300abc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300ac0: b               #0x130086c
    // 0x1300ac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1300ac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1300ac8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300ac8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1301b44, size: 0x64
    // 0x1301b44: EnterFrame
    //     0x1301b44: stp             fp, lr, [SP, #-0x10]!
    //     0x1301b48: mov             fp, SP
    // 0x1301b4c: AllocStack(0x18)
    //     0x1301b4c: sub             SP, SP, #0x18
    // 0x1301b50: cmp             w2, NULL
    // 0x1301b54: b.ne            #0x1301b64
    // 0x1301b58: LoadField: r0 = r1->field_7
    //     0x1301b58: ldur            w0, [x1, #7]
    // 0x1301b5c: DecompressPointer r0
    //     0x1301b5c: add             x0, x0, HEAP, lsl #32
    // 0x1301b60: b               #0x1301b68
    // 0x1301b64: mov             x0, x2
    // 0x1301b68: stur            x0, [fp, #-0x10]
    // 0x1301b6c: LoadField: r2 = r1->field_b
    //     0x1301b6c: ldur            w2, [x1, #0xb]
    // 0x1301b70: DecompressPointer r2
    //     0x1301b70: add             x2, x2, HEAP, lsl #32
    // 0x1301b74: stur            x2, [fp, #-8]
    // 0x1301b78: LoadField: d0 = r1->field_f
    //     0x1301b78: ldur            d0, [x1, #0xf]
    // 0x1301b7c: stur            d0, [fp, #-0x18]
    // 0x1301b80: r0 = _StadiumToRoundedRectangleBorder()
    //     0x1301b80: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x1301b84: ldur            x1, [fp, #-8]
    // 0x1301b88: StoreField: r0->field_b = r1
    //     0x1301b88: stur            w1, [x0, #0xb]
    // 0x1301b8c: ldur            d0, [fp, #-0x18]
    // 0x1301b90: StoreField: r0->field_f = d0
    //     0x1301b90: stur            d0, [x0, #0xf]
    // 0x1301b94: ldur            x1, [fp, #-0x10]
    // 0x1301b98: StoreField: r0->field_7 = r1
    //     0x1301b98: stur            w1, [x0, #7]
    // 0x1301b9c: LeaveFrame
    //     0x1301b9c: mov             SP, fp
    //     0x1301ba0: ldp             fp, lr, [SP], #0x10
    // 0x1301ba4: ret
    //     0x1301ba4: ret             
  }
}

// class id: 3021, size: 0x1c, field offset: 0xc
//   const constructor, 
class _StadiumToCircleBorder extends OutlinedBorder {

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfef40, size: 0x1ac
    // 0xbfef40: EnterFrame
    //     0xbfef40: stp             fp, lr, [SP, #-0x10]!
    //     0xbfef44: mov             fp, SP
    // 0xbfef48: AllocStack(0x30)
    //     0xbfef48: sub             SP, SP, #0x30
    // 0xbfef4c: SetupParameters(_StadiumToCircleBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbfef4c: stur            x1, [fp, #-8]
    //     0xbfef50: stur            x2, [fp, #-0x10]
    // 0xbfef54: CheckStackOverflow
    //     0xbfef54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfef58: cmp             SP, x16
    //     0xbfef5c: b.ls            #0xbff0e0
    // 0xbfef60: r0 = _NativePath()
    //     0xbfef60: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfef64: mov             x1, x0
    // 0xbfef68: stur            x0, [fp, #-0x18]
    // 0xbfef6c: r0 = __constructor$Method$FfiNative()
    //     0xbfef6c: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfef70: ldur            x1, [fp, #-8]
    // 0xbfef74: ldur            x2, [fp, #-0x10]
    // 0xbfef78: r0 = _adjustBorderRadius()
    //     0xbfef78: bl              #0xbff21c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0xbfef7c: ldur            x1, [fp, #-8]
    // 0xbfef80: ldur            x2, [fp, #-0x10]
    // 0xbfef84: stur            x0, [fp, #-0x10]
    // 0xbfef88: r0 = _adjustRect()
    //     0xbfef88: bl              #0xbff0ec  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0xbfef8c: ldur            x1, [fp, #-0x10]
    // 0xbfef90: mov             x2, x0
    // 0xbfef94: r0 = toRRect()
    //     0xbfef94: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbfef98: mov             x1, x0
    // 0xbfef9c: ldur            x0, [fp, #-8]
    // 0xbfefa0: LoadField: r2 = r0->field_7
    //     0xbfefa0: ldur            w2, [x0, #7]
    // 0xbfefa4: DecompressPointer r2
    //     0xbfefa4: add             x2, x2, HEAP, lsl #32
    // 0xbfefa8: LoadField: d0 = r2->field_b
    //     0xbfefa8: ldur            d0, [x2, #0xb]
    // 0xbfefac: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbfefac: ldur            d1, [x2, #0x17]
    // 0xbfefb0: d2 = 1.000000
    //     0xbfefb0: fmov            d2, #1.00000000
    // 0xbfefb4: fadd            d3, d1, d2
    // 0xbfefb8: d1 = 2.000000
    //     0xbfefb8: fmov            d1, #2.00000000
    // 0xbfefbc: fdiv            d4, d3, d1
    // 0xbfefc0: fsub            d1, d2, d4
    // 0xbfefc4: fmul            d2, d0, d1
    // 0xbfefc8: mov             v0.16b, v2.16b
    // 0xbfefcc: r0 = deflate()
    //     0xbfefcc: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbfefd0: stur            x0, [fp, #-8]
    // 0xbfefd4: LoadField: d0 = r0->field_b
    //     0xbfefd4: ldur            d0, [x0, #0xb]
    // 0xbfefd8: fcvt            s1, d0
    // 0xbfefdc: stur            d1, [fp, #-0x28]
    // 0xbfefe0: r4 = 24
    //     0xbfefe0: mov             x4, #0x18
    // 0xbfefe4: r0 = AllocateFloat32Array()
    //     0xbfefe4: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbfefe8: ldur            d0, [fp, #-0x28]
    // 0xbfefec: stur            x0, [fp, #-0x10]
    // 0xbfeff0: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfeff0: stur            s0, [x0, #0x17]
    // 0xbfeff4: ldur            x1, [fp, #-8]
    // 0xbfeff8: LoadField: d0 = r1->field_13
    //     0xbfeff8: ldur            d0, [x1, #0x13]
    // 0xbfeffc: fcvt            s1, d0
    // 0xbff000: StoreField: r0->field_1b = d1
    //     0xbff000: stur            s1, [x0, #0x1b]
    // 0xbff004: LoadField: d0 = r1->field_1b
    //     0xbff004: ldur            d0, [x1, #0x1b]
    // 0xbff008: fcvt            s1, d0
    // 0xbff00c: StoreField: r0->field_1f = d1
    //     0xbff00c: stur            s1, [x0, #0x1f]
    // 0xbff010: LoadField: d0 = r1->field_23
    //     0xbff010: ldur            d0, [x1, #0x23]
    // 0xbff014: fcvt            s1, d0
    // 0xbff018: StoreField: r0->field_23 = d1
    //     0xbff018: stur            s1, [x0, #0x23]
    // 0xbff01c: LoadField: d0 = r1->field_2b
    //     0xbff01c: ldur            d0, [x1, #0x2b]
    // 0xbff020: fcvt            s1, d0
    // 0xbff024: StoreField: r0->field_27 = d1
    //     0xbff024: stur            s1, [x0, #0x27]
    // 0xbff028: LoadField: d0 = r1->field_33
    //     0xbff028: ldur            d0, [x1, #0x33]
    // 0xbff02c: fcvt            s1, d0
    // 0xbff030: StoreField: r0->field_2b = d1
    //     0xbff030: stur            s1, [x0, #0x2b]
    // 0xbff034: LoadField: d0 = r1->field_3b
    //     0xbff034: ldur            d0, [x1, #0x3b]
    // 0xbff038: fcvt            s1, d0
    // 0xbff03c: StoreField: r0->field_2f = d1
    //     0xbff03c: stur            s1, [x0, #0x2f]
    // 0xbff040: LoadField: d0 = r1->field_43
    //     0xbff040: ldur            d0, [x1, #0x43]
    // 0xbff044: fcvt            s1, d0
    // 0xbff048: StoreField: r0->field_33 = d1
    //     0xbff048: stur            s1, [x0, #0x33]
    // 0xbff04c: LoadField: d0 = r1->field_4b
    //     0xbff04c: ldur            d0, [x1, #0x4b]
    // 0xbff050: fcvt            s1, d0
    // 0xbff054: StoreField: r0->field_37 = d1
    //     0xbff054: stur            s1, [x0, #0x37]
    // 0xbff058: LoadField: d0 = r1->field_53
    //     0xbff058: ldur            d0, [x1, #0x53]
    // 0xbff05c: fcvt            s1, d0
    // 0xbff060: StoreField: r0->field_3b = d1
    //     0xbff060: stur            s1, [x0, #0x3b]
    // 0xbff064: LoadField: d0 = r1->field_5b
    //     0xbff064: ldur            d0, [x1, #0x5b]
    // 0xbff068: fcvt            s1, d0
    // 0xbff06c: StoreField: r0->field_3f = d1
    //     0xbff06c: stur            s1, [x0, #0x3f]
    // 0xbff070: LoadField: d0 = r1->field_63
    //     0xbff070: ldur            d0, [x1, #0x63]
    // 0xbff074: fcvt            s1, d0
    // 0xbff078: StoreField: r0->field_43 = d1
    //     0xbff078: stur            s1, [x0, #0x43]
    // 0xbff07c: ldur            x2, [fp, #-0x18]
    // 0xbff080: LoadField: r1 = r2->field_7
    //     0xbff080: ldur            w1, [x2, #7]
    // 0xbff084: DecompressPointer r1
    //     0xbff084: add             x1, x1, HEAP, lsl #32
    // 0xbff088: cmp             w1, NULL
    // 0xbff08c: b.eq            #0xbff0e8
    // 0xbff090: LoadField: r3 = r1->field_7
    //     0xbff090: ldur            x3, [x1, #7]
    // 0xbff094: ldr             x1, [x3]
    // 0xbff098: cbz             x1, #0xbff0d0
    // 0xbff09c: mov             x3, x1
    // 0xbff0a0: stur            x3, [fp, #-0x20]
    // 0xbff0a4: r1 = <Never>
    //     0xbff0a4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbff0a8: r0 = Pointer()
    //     0xbff0a8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbff0ac: mov             x1, x0
    // 0xbff0b0: ldur            x0, [fp, #-0x20]
    // 0xbff0b4: StoreField: r1->field_7 = r0
    //     0xbff0b4: stur            x0, [x1, #7]
    // 0xbff0b8: ldur            x2, [fp, #-0x10]
    // 0xbff0bc: r0 = __addRRect$Method$FfiNative()
    //     0xbff0bc: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbff0c0: ldur            x0, [fp, #-0x18]
    // 0xbff0c4: LeaveFrame
    //     0xbff0c4: mov             SP, fp
    //     0xbff0c8: ldp             fp, lr, [SP], #0x10
    // 0xbff0cc: ret
    //     0xbff0cc: ret             
    // 0xbff0d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbff0d0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbff0d4: str             x16, [SP]
    // 0xbff0d8: r0 = _throwNew()
    //     0xbff0d8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbff0dc: brk             #0
    // 0xbff0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff0e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff0e4: b               #0xbfef60
    // 0xbff0e8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbff0e8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0xbff0ec, size: 0x130
    // 0xbff0ec: EnterFrame
    //     0xbff0ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbff0f0: mov             fp, SP
    // 0xbff0f4: AllocStack(0x30)
    //     0xbff0f4: sub             SP, SP, #0x30
    // 0xbff0f8: d0 = 0.000000
    //     0xbff0f8: eor             v0.16b, v0.16b, v0.16b
    // 0xbff0fc: mov             x0, x2
    // 0xbff100: LoadField: d1 = r1->field_b
    //     0xbff100: ldur            d1, [x1, #0xb]
    // 0xbff104: fcmp            d1, d0
    // 0xbff108: b.eq            #0xbff13c
    // 0xbff10c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbff10c: ldur            d0, [x0, #0x17]
    // 0xbff110: stur            d0, [fp, #-0x20]
    // 0xbff114: LoadField: d2 = r0->field_7
    //     0xbff114: ldur            d2, [x0, #7]
    // 0xbff118: stur            d2, [fp, #-0x18]
    // 0xbff11c: fsub            d3, d0, d2
    // 0xbff120: LoadField: d4 = r0->field_1f
    //     0xbff120: ldur            d4, [x0, #0x1f]
    // 0xbff124: stur            d4, [fp, #-0x30]
    // 0xbff128: LoadField: d5 = r0->field_f
    //     0xbff128: ldur            d5, [x0, #0xf]
    // 0xbff12c: stur            d5, [fp, #-0x28]
    // 0xbff130: fsub            d6, d4, d5
    // 0xbff134: fcmp            d3, d6
    // 0xbff138: b.ne            #0xbff148
    // 0xbff13c: LeaveFrame
    //     0xbff13c: mov             SP, fp
    //     0xbff140: ldp             fp, lr, [SP], #0x10
    // 0xbff144: ret
    //     0xbff144: ret             
    // 0xbff148: fcmp            d6, d3
    // 0xbff14c: b.le            #0xbff1b0
    // 0xbff150: d8 = 2.000000
    //     0xbff150: fmov            d8, #2.00000000
    // 0xbff154: d7 = 1.000000
    //     0xbff154: fmov            d7, #1.00000000
    // 0xbff158: fsub            d9, d6, d3
    // 0xbff15c: fdiv            d3, d9, d8
    // 0xbff160: fmul            d6, d1, d3
    // 0xbff164: LoadField: d1 = r1->field_13
    //     0xbff164: ldur            d1, [x1, #0x13]
    // 0xbff168: fsub            d3, d7, d1
    // 0xbff16c: fmul            d1, d6, d3
    // 0xbff170: fadd            d3, d5, d1
    // 0xbff174: stur            d3, [fp, #-0x10]
    // 0xbff178: fsub            d5, d4, d1
    // 0xbff17c: stur            d5, [fp, #-8]
    // 0xbff180: r0 = Rect()
    //     0xbff180: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbff184: ldur            d0, [fp, #-0x18]
    // 0xbff188: StoreField: r0->field_7 = d0
    //     0xbff188: stur            d0, [x0, #7]
    // 0xbff18c: ldur            d0, [fp, #-0x10]
    // 0xbff190: StoreField: r0->field_f = d0
    //     0xbff190: stur            d0, [x0, #0xf]
    // 0xbff194: ldur            d2, [fp, #-0x20]
    // 0xbff198: ArrayStore: r0[0] = d2  ; List_8
    //     0xbff198: stur            d2, [x0, #0x17]
    // 0xbff19c: ldur            d0, [fp, #-8]
    // 0xbff1a0: StoreField: r0->field_1f = d0
    //     0xbff1a0: stur            d0, [x0, #0x1f]
    // 0xbff1a4: LeaveFrame
    //     0xbff1a4: mov             SP, fp
    //     0xbff1a8: ldp             fp, lr, [SP], #0x10
    // 0xbff1ac: ret
    //     0xbff1ac: ret             
    // 0xbff1b0: mov             v31.16b, v2.16b
    // 0xbff1b4: mov             v2.16b, v0.16b
    // 0xbff1b8: mov             v0.16b, v31.16b
    // 0xbff1bc: d8 = 2.000000
    //     0xbff1bc: fmov            d8, #2.00000000
    // 0xbff1c0: d7 = 1.000000
    //     0xbff1c0: fmov            d7, #1.00000000
    // 0xbff1c4: fsub            d9, d3, d6
    // 0xbff1c8: fdiv            d3, d9, d8
    // 0xbff1cc: fmul            d6, d1, d3
    // 0xbff1d0: LoadField: d1 = r1->field_13
    //     0xbff1d0: ldur            d1, [x1, #0x13]
    // 0xbff1d4: fsub            d3, d7, d1
    // 0xbff1d8: fmul            d1, d6, d3
    // 0xbff1dc: fadd            d3, d0, d1
    // 0xbff1e0: stur            d3, [fp, #-0x10]
    // 0xbff1e4: fsub            d0, d2, d1
    // 0xbff1e8: stur            d0, [fp, #-8]
    // 0xbff1ec: r0 = Rect()
    //     0xbff1ec: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbff1f0: ldur            d0, [fp, #-0x10]
    // 0xbff1f4: StoreField: r0->field_7 = d0
    //     0xbff1f4: stur            d0, [x0, #7]
    // 0xbff1f8: ldur            d0, [fp, #-0x28]
    // 0xbff1fc: StoreField: r0->field_f = d0
    //     0xbff1fc: stur            d0, [x0, #0xf]
    // 0xbff200: ldur            d0, [fp, #-8]
    // 0xbff204: ArrayStore: r0[0] = d0  ; List_8
    //     0xbff204: stur            d0, [x0, #0x17]
    // 0xbff208: ldur            d0, [fp, #-0x30]
    // 0xbff20c: StoreField: r0->field_1f = d0
    //     0xbff20c: stur            d0, [x0, #0x1f]
    // 0xbff210: LeaveFrame
    //     0xbff210: mov             SP, fp
    //     0xbff214: ldp             fp, lr, [SP], #0x10
    // 0xbff218: ret
    //     0xbff218: ret             
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0xbff21c, size: 0x1b4
    // 0xbff21c: EnterFrame
    //     0xbff21c: stp             fp, lr, [SP, #-0x10]!
    //     0xbff220: mov             fp, SP
    // 0xbff224: AllocStack(0x30)
    //     0xbff224: sub             SP, SP, #0x30
    // 0xbff228: SetupParameters(_StadiumToCircleBorder this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbff228: mov             x0, x2
    //     0xbff22c: stur            x2, [fp, #-0x10]
    //     0xbff230: mov             x2, x1
    //     0xbff234: stur            x1, [fp, #-8]
    // 0xbff238: CheckStackOverflow
    //     0xbff238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbff23c: cmp             SP, x16
    //     0xbff240: b.ls            #0xbff3c8
    // 0xbff244: mov             x1, x0
    // 0xbff248: r0 = shortestSide()
    //     0xbff248: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xbff24c: mov             v1.16b, v0.16b
    // 0xbff250: d0 = 2.000000
    //     0xbff250: fmov            d0, #2.00000000
    // 0xbff254: fdiv            d2, d1, d0
    // 0xbff258: stur            d2, [fp, #-0x28]
    // 0xbff25c: r0 = Radius()
    //     0xbff25c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbff260: ldur            d0, [fp, #-0x28]
    // 0xbff264: stur            x0, [fp, #-0x18]
    // 0xbff268: StoreField: r0->field_7 = d0
    //     0xbff268: stur            d0, [x0, #7]
    // 0xbff26c: StoreField: r0->field_f = d0
    //     0xbff26c: stur            d0, [x0, #0xf]
    // 0xbff270: r0 = BorderRadius()
    //     0xbff270: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff274: mov             x1, x0
    // 0xbff278: ldur            x0, [fp, #-0x18]
    // 0xbff27c: stur            x1, [fp, #-0x20]
    // 0xbff280: StoreField: r1->field_7 = r0
    //     0xbff280: stur            w0, [x1, #7]
    // 0xbff284: StoreField: r1->field_b = r0
    //     0xbff284: stur            w0, [x1, #0xb]
    // 0xbff288: StoreField: r1->field_f = r0
    //     0xbff288: stur            w0, [x1, #0xf]
    // 0xbff28c: StoreField: r1->field_13 = r0
    //     0xbff28c: stur            w0, [x1, #0x13]
    // 0xbff290: ldur            x0, [fp, #-8]
    // 0xbff294: LoadField: d0 = r0->field_13
    //     0xbff294: ldur            d0, [x0, #0x13]
    // 0xbff298: d1 = 0.000000
    //     0xbff298: eor             v1.16b, v1.16b, v1.16b
    // 0xbff29c: fcmp            d0, d1
    // 0xbff2a0: b.eq            #0xbff3b8
    // 0xbff2a4: ldur            x2, [fp, #-0x10]
    // 0xbff2a8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xbff2a8: ldur            d1, [x2, #0x17]
    // 0xbff2ac: LoadField: d2 = r2->field_7
    //     0xbff2ac: ldur            d2, [x2, #7]
    // 0xbff2b0: fsub            d3, d1, d2
    // 0xbff2b4: LoadField: d1 = r2->field_1f
    //     0xbff2b4: ldur            d1, [x2, #0x1f]
    // 0xbff2b8: LoadField: d2 = r2->field_f
    //     0xbff2b8: ldur            d2, [x2, #0xf]
    // 0xbff2bc: fsub            d4, d1, d2
    // 0xbff2c0: fcmp            d4, d3
    // 0xbff2c4: b.le            #0xbff340
    // 0xbff2c8: d1 = 2.000000
    //     0xbff2c8: fmov            d1, #2.00000000
    // 0xbff2cc: d2 = 0.500000
    //     0xbff2cc: fmov            d2, #0.50000000
    // 0xbff2d0: fdiv            d5, d3, d1
    // 0xbff2d4: stur            d5, [fp, #-0x30]
    // 0xbff2d8: fdiv            d3, d0, d1
    // 0xbff2dc: fadd            d0, d3, d2
    // 0xbff2e0: fmul            d2, d0, d4
    // 0xbff2e4: fdiv            d0, d2, d1
    // 0xbff2e8: stur            d0, [fp, #-0x28]
    // 0xbff2ec: r0 = Radius()
    //     0xbff2ec: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbff2f0: ldur            d0, [fp, #-0x30]
    // 0xbff2f4: stur            x0, [fp, #-0x10]
    // 0xbff2f8: StoreField: r0->field_7 = d0
    //     0xbff2f8: stur            d0, [x0, #7]
    // 0xbff2fc: ldur            d0, [fp, #-0x28]
    // 0xbff300: StoreField: r0->field_f = d0
    //     0xbff300: stur            d0, [x0, #0xf]
    // 0xbff304: r0 = BorderRadius()
    //     0xbff304: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff308: mov             x1, x0
    // 0xbff30c: ldur            x0, [fp, #-0x10]
    // 0xbff310: StoreField: r1->field_7 = r0
    //     0xbff310: stur            w0, [x1, #7]
    // 0xbff314: StoreField: r1->field_b = r0
    //     0xbff314: stur            w0, [x1, #0xb]
    // 0xbff318: StoreField: r1->field_f = r0
    //     0xbff318: stur            w0, [x1, #0xf]
    // 0xbff31c: StoreField: r1->field_13 = r0
    //     0xbff31c: stur            w0, [x1, #0x13]
    // 0xbff320: ldur            x0, [fp, #-8]
    // 0xbff324: LoadField: d0 = r0->field_b
    //     0xbff324: ldur            d0, [x0, #0xb]
    // 0xbff328: mov             x2, x1
    // 0xbff32c: ldur            x1, [fp, #-0x20]
    // 0xbff330: r0 = lerp()
    //     0xbff330: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbff334: LeaveFrame
    //     0xbff334: mov             SP, fp
    //     0xbff338: ldp             fp, lr, [SP], #0x10
    // 0xbff33c: ret
    //     0xbff33c: ret             
    // 0xbff340: d1 = 2.000000
    //     0xbff340: fmov            d1, #2.00000000
    // 0xbff344: d2 = 0.500000
    //     0xbff344: fmov            d2, #0.50000000
    // 0xbff348: fdiv            d5, d0, d1
    // 0xbff34c: fadd            d0, d5, d2
    // 0xbff350: fmul            d2, d0, d3
    // 0xbff354: fdiv            d0, d2, d1
    // 0xbff358: stur            d0, [fp, #-0x30]
    // 0xbff35c: fdiv            d2, d4, d1
    // 0xbff360: stur            d2, [fp, #-0x28]
    // 0xbff364: r0 = Radius()
    //     0xbff364: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbff368: ldur            d0, [fp, #-0x30]
    // 0xbff36c: stur            x0, [fp, #-0x10]
    // 0xbff370: StoreField: r0->field_7 = d0
    //     0xbff370: stur            d0, [x0, #7]
    // 0xbff374: ldur            d0, [fp, #-0x28]
    // 0xbff378: StoreField: r0->field_f = d0
    //     0xbff378: stur            d0, [x0, #0xf]
    // 0xbff37c: r0 = BorderRadius()
    //     0xbff37c: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xbff380: mov             x1, x0
    // 0xbff384: ldur            x0, [fp, #-0x10]
    // 0xbff388: StoreField: r1->field_7 = r0
    //     0xbff388: stur            w0, [x1, #7]
    // 0xbff38c: StoreField: r1->field_b = r0
    //     0xbff38c: stur            w0, [x1, #0xb]
    // 0xbff390: StoreField: r1->field_f = r0
    //     0xbff390: stur            w0, [x1, #0xf]
    // 0xbff394: StoreField: r1->field_13 = r0
    //     0xbff394: stur            w0, [x1, #0x13]
    // 0xbff398: ldur            x0, [fp, #-8]
    // 0xbff39c: LoadField: d0 = r0->field_b
    //     0xbff39c: ldur            d0, [x0, #0xb]
    // 0xbff3a0: mov             x2, x1
    // 0xbff3a4: ldur            x1, [fp, #-0x20]
    // 0xbff3a8: r0 = lerp()
    //     0xbff3a8: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbff3ac: LeaveFrame
    //     0xbff3ac: mov             SP, fp
    //     0xbff3b0: ldp             fp, lr, [SP], #0x10
    // 0xbff3b4: ret
    //     0xbff3b4: ret             
    // 0xbff3b8: ldur            x0, [fp, #-0x20]
    // 0xbff3bc: LeaveFrame
    //     0xbff3bc: mov             SP, fp
    //     0xbff3c0: ldp             fp, lr, [SP], #0x10
    // 0xbff3c4: ret
    //     0xbff3c4: ret             
    // 0xbff3c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbff3c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbff3cc: b               #0xbff244
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10ede10, size: 0x3a0
    // 0x10ede10: EnterFrame
    //     0x10ede10: stp             fp, lr, [SP, #-0x10]!
    //     0x10ede14: mov             fp, SP
    // 0x10ede18: AllocStack(0x40)
    //     0x10ede18: sub             SP, SP, #0x40
    // 0x10ede1c: SetupParameters(_StadiumToCircleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x10ede1c: mov             x3, x1
    //     0x10ede20: mov             x0, x2
    //     0x10ede24: mov             v1.16b, v0.16b
    //     0x10ede28: stur            x1, [fp, #-8]
    //     0x10ede2c: stur            x2, [fp, #-0x18]
    //     0x10ede30: stur            d0, [fp, #-0x30]
    // 0x10ede34: CheckStackOverflow
    //     0x10ede34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ede38: cmp             SP, x16
    //     0x10ede3c: b.ls            #0x10ee0f4
    // 0x10ede40: r1 = LoadClassIdInstr(r0)
    //     0x10ede40: ldur            x1, [x0, #-1]
    //     0x10ede44: ubfx            x1, x1, #0xc, #0x14
    // 0x10ede48: cmp             x1, #0xbce
    // 0x10ede4c: b.ne            #0x10edeb0
    // 0x10ede50: LoadField: r1 = r0->field_7
    //     0x10ede50: ldur            w1, [x0, #7]
    // 0x10ede54: DecompressPointer r1
    //     0x10ede54: add             x1, x1, HEAP, lsl #32
    // 0x10ede58: LoadField: r2 = r3->field_7
    //     0x10ede58: ldur            w2, [x3, #7]
    // 0x10ede5c: DecompressPointer r2
    //     0x10ede5c: add             x2, x2, HEAP, lsl #32
    // 0x10ede60: mov             v0.16b, v1.16b
    // 0x10ede64: r0 = lerp()
    //     0x10ede64: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10ede68: ldur            x3, [fp, #-8]
    // 0x10ede6c: stur            x0, [fp, #-0x10]
    // 0x10ede70: LoadField: d0 = r3->field_b
    //     0x10ede70: ldur            d0, [x3, #0xb]
    // 0x10ede74: ldur            d1, [fp, #-0x30]
    // 0x10ede78: fmul            d2, d0, d1
    // 0x10ede7c: stur            d2, [fp, #-0x40]
    // 0x10ede80: LoadField: d0 = r3->field_13
    //     0x10ede80: ldur            d0, [x3, #0x13]
    // 0x10ede84: stur            d0, [fp, #-0x38]
    // 0x10ede88: r0 = _StadiumToCircleBorder()
    //     0x10ede88: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10ede8c: ldur            d0, [fp, #-0x40]
    // 0x10ede90: StoreField: r0->field_b = d0
    //     0x10ede90: stur            d0, [x0, #0xb]
    // 0x10ede94: ldur            d0, [fp, #-0x38]
    // 0x10ede98: StoreField: r0->field_13 = d0
    //     0x10ede98: stur            d0, [x0, #0x13]
    // 0x10ede9c: ldur            x1, [fp, #-0x10]
    // 0x10edea0: StoreField: r0->field_7 = r1
    //     0x10edea0: stur            w1, [x0, #7]
    // 0x10edea4: LeaveFrame
    //     0x10edea4: mov             SP, fp
    //     0x10edea8: ldp             fp, lr, [SP], #0x10
    // 0x10edeac: ret
    //     0x10edeac: ret             
    // 0x10edeb0: cmp             x1, #0xbd2
    // 0x10edeb4: b.ne            #0x10edf30
    // 0x10edeb8: LoadField: r1 = r0->field_7
    //     0x10edeb8: ldur            w1, [x0, #7]
    // 0x10edebc: DecompressPointer r1
    //     0x10edebc: add             x1, x1, HEAP, lsl #32
    // 0x10edec0: LoadField: r2 = r3->field_7
    //     0x10edec0: ldur            w2, [x3, #7]
    // 0x10edec4: DecompressPointer r2
    //     0x10edec4: add             x2, x2, HEAP, lsl #32
    // 0x10edec8: mov             v0.16b, v1.16b
    // 0x10edecc: r0 = lerp()
    //     0x10edecc: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10eded0: mov             x1, x0
    // 0x10eded4: ldur            x0, [fp, #-8]
    // 0x10eded8: stur            x1, [fp, #-0x10]
    // 0x10ededc: LoadField: d0 = r0->field_b
    //     0x10ededc: ldur            d0, [x0, #0xb]
    // 0x10edee0: d1 = 1.000000
    //     0x10edee0: fmov            d1, #1.00000000
    // 0x10edee4: fsub            d2, d1, d0
    // 0x10edee8: ldur            d3, [fp, #-0x30]
    // 0x10edeec: fsub            d4, d1, d3
    // 0x10edef0: fmul            d1, d2, d4
    // 0x10edef4: fadd            d2, d0, d1
    // 0x10edef8: ldur            x3, [fp, #-0x18]
    // 0x10edefc: stur            d2, [fp, #-0x40]
    // 0x10edf00: LoadField: d0 = r3->field_b
    //     0x10edf00: ldur            d0, [x3, #0xb]
    // 0x10edf04: stur            d0, [fp, #-0x38]
    // 0x10edf08: r0 = _StadiumToCircleBorder()
    //     0x10edf08: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10edf0c: ldur            d0, [fp, #-0x40]
    // 0x10edf10: StoreField: r0->field_b = d0
    //     0x10edf10: stur            d0, [x0, #0xb]
    // 0x10edf14: ldur            d0, [fp, #-0x38]
    // 0x10edf18: StoreField: r0->field_13 = d0
    //     0x10edf18: stur            d0, [x0, #0x13]
    // 0x10edf1c: ldur            x1, [fp, #-0x10]
    // 0x10edf20: StoreField: r0->field_7 = r1
    //     0x10edf20: stur            w1, [x0, #7]
    // 0x10edf24: LeaveFrame
    //     0x10edf24: mov             SP, fp
    //     0x10edf28: ldp             fp, lr, [SP], #0x10
    // 0x10edf2c: ret
    //     0x10edf2c: ret             
    // 0x10edf30: mov             x16, x0
    // 0x10edf34: mov             x0, x3
    // 0x10edf38: mov             x3, x16
    // 0x10edf3c: mov             v3.16b, v1.16b
    // 0x10edf40: cmp             x1, #0xbcd
    // 0x10edf44: b.ne            #0x10ee0c4
    // 0x10edf48: LoadField: r1 = r3->field_7
    //     0x10edf48: ldur            w1, [x3, #7]
    // 0x10edf4c: DecompressPointer r1
    //     0x10edf4c: add             x1, x1, HEAP, lsl #32
    // 0x10edf50: LoadField: r2 = r0->field_7
    //     0x10edf50: ldur            w2, [x0, #7]
    // 0x10edf54: DecompressPointer r2
    //     0x10edf54: add             x2, x2, HEAP, lsl #32
    // 0x10edf58: mov             v0.16b, v3.16b
    // 0x10edf5c: r0 = lerp()
    //     0x10edf5c: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10edf60: mov             x4, x0
    // 0x10edf64: ldur            x0, [fp, #-0x18]
    // 0x10edf68: stur            x4, [fp, #-0x20]
    // 0x10edf6c: LoadField: d0 = r0->field_b
    //     0x10edf6c: ldur            d0, [x0, #0xb]
    // 0x10edf70: ldur            x5, [fp, #-8]
    // 0x10edf74: LoadField: d1 = r5->field_b
    //     0x10edf74: ldur            d1, [x5, #0xb]
    // 0x10edf78: ldur            d2, [fp, #-0x30]
    // 0x10edf7c: r6 = inline_Allocate_Double()
    //     0x10edf7c: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0x10edf80: add             x6, x6, #0x10
    //     0x10edf84: cmp             x1, x6
    //     0x10edf88: b.ls            #0x10ee0fc
    //     0x10edf8c: str             x6, [THR, #0x60]  ; THR::top
    //     0x10edf90: sub             x6, x6, #0xf
    //     0x10edf94: mov             x1, #0xe19c
    //     0x10edf98: movk            x1, #3, lsl #16
    //     0x10edf9c: stur            x1, [x6, #-1]
    // 0x10edfa0: dmb             ishst
    // 0x10edfa4: StoreField: r6->field_7 = d2
    //     0x10edfa4: stur            d2, [x6, #7]
    // 0x10edfa8: stur            x6, [fp, #-0x10]
    // 0x10edfac: r1 = inline_Allocate_Double()
    //     0x10edfac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10edfb0: add             x1, x1, #0x10
    //     0x10edfb4: cmp             x2, x1
    //     0x10edfb8: b.ls            #0x10ee128
    //     0x10edfbc: str             x1, [THR, #0x60]  ; THR::top
    //     0x10edfc0: sub             x1, x1, #0xf
    //     0x10edfc4: mov             x2, #0xe19c
    //     0x10edfc8: movk            x2, #3, lsl #16
    //     0x10edfcc: stur            x2, [x1, #-1]
    // 0x10edfd0: dmb             ishst
    // 0x10edfd4: StoreField: r1->field_7 = d0
    //     0x10edfd4: stur            d0, [x1, #7]
    // 0x10edfd8: r2 = inline_Allocate_Double()
    //     0x10edfd8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x10edfdc: add             x2, x2, #0x10
    //     0x10edfe0: cmp             x3, x2
    //     0x10edfe4: b.ls            #0x10ee14c
    //     0x10edfe8: str             x2, [THR, #0x60]  ; THR::top
    //     0x10edfec: sub             x2, x2, #0xf
    //     0x10edff0: mov             x3, #0xe19c
    //     0x10edff4: movk            x3, #3, lsl #16
    //     0x10edff8: stur            x3, [x2, #-1]
    // 0x10edffc: dmb             ishst
    // 0x10ee000: StoreField: r2->field_7 = d1
    //     0x10ee000: stur            d1, [x2, #7]
    // 0x10ee004: mov             x3, x6
    // 0x10ee008: r0 = lerpDouble()
    //     0x10ee008: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10ee00c: mov             x4, x0
    // 0x10ee010: ldur            x0, [fp, #-0x18]
    // 0x10ee014: stur            x4, [fp, #-0x28]
    // 0x10ee018: LoadField: d0 = r0->field_13
    //     0x10ee018: ldur            d0, [x0, #0x13]
    // 0x10ee01c: ldur            x1, [fp, #-8]
    // 0x10ee020: LoadField: d1 = r1->field_13
    //     0x10ee020: ldur            d1, [x1, #0x13]
    // 0x10ee024: r1 = inline_Allocate_Double()
    //     0x10ee024: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x10ee028: add             x1, x1, #0x10
    //     0x10ee02c: cmp             x0, x1
    //     0x10ee030: b.ls            #0x10ee178
    //     0x10ee034: str             x1, [THR, #0x60]  ; THR::top
    //     0x10ee038: sub             x1, x1, #0xf
    //     0x10ee03c: mov             x0, #0xe19c
    //     0x10ee040: movk            x0, #3, lsl #16
    //     0x10ee044: stur            x0, [x1, #-1]
    // 0x10ee048: dmb             ishst
    // 0x10ee04c: StoreField: r1->field_7 = d0
    //     0x10ee04c: stur            d0, [x1, #7]
    // 0x10ee050: r2 = inline_Allocate_Double()
    //     0x10ee050: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x10ee054: add             x2, x2, #0x10
    //     0x10ee058: cmp             x0, x2
    //     0x10ee05c: b.ls            #0x10ee194
    //     0x10ee060: str             x2, [THR, #0x60]  ; THR::top
    //     0x10ee064: sub             x2, x2, #0xf
    //     0x10ee068: mov             x0, #0xe19c
    //     0x10ee06c: movk            x0, #3, lsl #16
    //     0x10ee070: stur            x0, [x2, #-1]
    // 0x10ee074: dmb             ishst
    // 0x10ee078: StoreField: r2->field_7 = d1
    //     0x10ee078: stur            d1, [x2, #7]
    // 0x10ee07c: ldur            x3, [fp, #-0x10]
    // 0x10ee080: r0 = lerpDouble()
    //     0x10ee080: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10ee084: mov             x1, x0
    // 0x10ee088: ldur            x0, [fp, #-0x28]
    // 0x10ee08c: stur            x1, [fp, #-0x10]
    // 0x10ee090: LoadField: d0 = r0->field_7
    //     0x10ee090: ldur            d0, [x0, #7]
    // 0x10ee094: stur            d0, [fp, #-0x38]
    // 0x10ee098: r0 = _StadiumToCircleBorder()
    //     0x10ee098: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10ee09c: ldur            d0, [fp, #-0x38]
    // 0x10ee0a0: StoreField: r0->field_b = d0
    //     0x10ee0a0: stur            d0, [x0, #0xb]
    // 0x10ee0a4: ldur            x1, [fp, #-0x10]
    // 0x10ee0a8: LoadField: d0 = r1->field_7
    //     0x10ee0a8: ldur            d0, [x1, #7]
    // 0x10ee0ac: StoreField: r0->field_13 = d0
    //     0x10ee0ac: stur            d0, [x0, #0x13]
    // 0x10ee0b0: ldur            x1, [fp, #-0x20]
    // 0x10ee0b4: StoreField: r0->field_7 = r1
    //     0x10ee0b4: stur            w1, [x0, #7]
    // 0x10ee0b8: LeaveFrame
    //     0x10ee0b8: mov             SP, fp
    //     0x10ee0bc: ldp             fp, lr, [SP], #0x10
    // 0x10ee0c0: ret
    //     0x10ee0c0: ret             
    // 0x10ee0c4: mov             x1, x0
    // 0x10ee0c8: mov             x0, x3
    // 0x10ee0cc: mov             v2.16b, v3.16b
    // 0x10ee0d0: cmp             w0, NULL
    // 0x10ee0d4: b.ne            #0x10ee0e4
    // 0x10ee0d8: mov             v0.16b, v2.16b
    // 0x10ee0dc: r0 = scale()
    //     0x10ee0dc: bl              #0x12fcd3c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::scale
    // 0x10ee0e0: b               #0x10ee0e8
    // 0x10ee0e4: r0 = Null
    //     0x10ee0e4: mov             x0, NULL
    // 0x10ee0e8: LeaveFrame
    //     0x10ee0e8: mov             SP, fp
    //     0x10ee0ec: ldp             fp, lr, [SP], #0x10
    // 0x10ee0f0: ret
    //     0x10ee0f0: ret             
    // 0x10ee0f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x10ee0f4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10ee0f8: b               #0x10ede40
    // 0x10ee0fc: stp             q1, q2, [SP, #-0x20]!
    // 0x10ee100: SaveReg d0
    //     0x10ee100: str             q0, [SP, #-0x10]!
    // 0x10ee104: stp             x4, x5, [SP, #-0x10]!
    // 0x10ee108: SaveReg r0
    //     0x10ee108: str             x0, [SP, #-8]!
    // 0x10ee10c: r0 = AllocateDouble()
    //     0x10ee10c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee110: mov             x6, x0
    // 0x10ee114: RestoreReg r0
    //     0x10ee114: ldr             x0, [SP], #8
    // 0x10ee118: ldp             x4, x5, [SP], #0x10
    // 0x10ee11c: RestoreReg d0
    //     0x10ee11c: ldr             q0, [SP], #0x10
    // 0x10ee120: ldp             q1, q2, [SP], #0x20
    // 0x10ee124: b               #0x10edfa4
    // 0x10ee128: stp             q0, q1, [SP, #-0x20]!
    // 0x10ee12c: stp             x5, x6, [SP, #-0x10]!
    // 0x10ee130: stp             x0, x4, [SP, #-0x10]!
    // 0x10ee134: r0 = AllocateDouble()
    //     0x10ee134: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee138: mov             x1, x0
    // 0x10ee13c: ldp             x0, x4, [SP], #0x10
    // 0x10ee140: ldp             x5, x6, [SP], #0x10
    // 0x10ee144: ldp             q0, q1, [SP], #0x20
    // 0x10ee148: b               #0x10edfd4
    // 0x10ee14c: SaveReg d1
    //     0x10ee14c: str             q1, [SP, #-0x10]!
    // 0x10ee150: stp             x5, x6, [SP, #-0x10]!
    // 0x10ee154: stp             x1, x4, [SP, #-0x10]!
    // 0x10ee158: SaveReg r0
    //     0x10ee158: str             x0, [SP, #-8]!
    // 0x10ee15c: r0 = AllocateDouble()
    //     0x10ee15c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee160: mov             x2, x0
    // 0x10ee164: RestoreReg r0
    //     0x10ee164: ldr             x0, [SP], #8
    // 0x10ee168: ldp             x1, x4, [SP], #0x10
    // 0x10ee16c: ldp             x5, x6, [SP], #0x10
    // 0x10ee170: RestoreReg d1
    //     0x10ee170: ldr             q1, [SP], #0x10
    // 0x10ee174: b               #0x10ee000
    // 0x10ee178: stp             q0, q1, [SP, #-0x20]!
    // 0x10ee17c: SaveReg r4
    //     0x10ee17c: str             x4, [SP, #-8]!
    // 0x10ee180: r0 = AllocateDouble()
    //     0x10ee180: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee184: mov             x1, x0
    // 0x10ee188: RestoreReg r4
    //     0x10ee188: ldr             x4, [SP], #8
    // 0x10ee18c: ldp             q0, q1, [SP], #0x20
    // 0x10ee190: b               #0x10ee04c
    // 0x10ee194: SaveReg d1
    //     0x10ee194: str             q1, [SP, #-0x10]!
    // 0x10ee198: stp             x1, x4, [SP, #-0x10]!
    // 0x10ee19c: r0 = AllocateDouble()
    //     0x10ee19c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10ee1a0: mov             x2, x0
    // 0x10ee1a4: ldp             x1, x4, [SP], #0x10
    // 0x10ee1a8: RestoreReg d1
    //     0x10ee1a8: ldr             q1, [SP], #0x10
    // 0x10ee1ac: b               #0x10ee078
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f0f60, size: 0x390
    // 0x10f0f60: EnterFrame
    //     0x10f0f60: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0f64: mov             fp, SP
    // 0x10f0f68: AllocStack(0x40)
    //     0x10f0f68: sub             SP, SP, #0x40
    // 0x10f0f6c: SetupParameters(_StadiumToCircleBorder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x10f0f6c: mov             x3, x1
    //     0x10f0f70: mov             x0, x2
    //     0x10f0f74: mov             v1.16b, v0.16b
    //     0x10f0f78: stur            x1, [fp, #-8]
    //     0x10f0f7c: stur            x2, [fp, #-0x18]
    //     0x10f0f80: stur            d0, [fp, #-0x30]
    // 0x10f0f84: CheckStackOverflow
    //     0x10f0f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f0f88: cmp             SP, x16
    //     0x10f0f8c: b.ls            #0x10f1234
    // 0x10f0f90: r1 = LoadClassIdInstr(r0)
    //     0x10f0f90: ldur            x1, [x0, #-1]
    //     0x10f0f94: ubfx            x1, x1, #0xc, #0x14
    // 0x10f0f98: cmp             x1, #0xbce
    // 0x10f0f9c: b.ne            #0x10f1008
    // 0x10f0fa0: LoadField: r1 = r3->field_7
    //     0x10f0fa0: ldur            w1, [x3, #7]
    // 0x10f0fa4: DecompressPointer r1
    //     0x10f0fa4: add             x1, x1, HEAP, lsl #32
    // 0x10f0fa8: LoadField: r2 = r0->field_7
    //     0x10f0fa8: ldur            w2, [x0, #7]
    // 0x10f0fac: DecompressPointer r2
    //     0x10f0fac: add             x2, x2, HEAP, lsl #32
    // 0x10f0fb0: mov             v0.16b, v1.16b
    // 0x10f0fb4: r0 = lerp()
    //     0x10f0fb4: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0fb8: ldur            x3, [fp, #-8]
    // 0x10f0fbc: stur            x0, [fp, #-0x10]
    // 0x10f0fc0: LoadField: d0 = r3->field_b
    //     0x10f0fc0: ldur            d0, [x3, #0xb]
    // 0x10f0fc4: ldur            d1, [fp, #-0x30]
    // 0x10f0fc8: d2 = 1.000000
    //     0x10f0fc8: fmov            d2, #1.00000000
    // 0x10f0fcc: fsub            d3, d2, d1
    // 0x10f0fd0: fmul            d1, d0, d3
    // 0x10f0fd4: stur            d1, [fp, #-0x40]
    // 0x10f0fd8: LoadField: d0 = r3->field_13
    //     0x10f0fd8: ldur            d0, [x3, #0x13]
    // 0x10f0fdc: stur            d0, [fp, #-0x38]
    // 0x10f0fe0: r0 = _StadiumToCircleBorder()
    //     0x10f0fe0: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10f0fe4: ldur            d0, [fp, #-0x40]
    // 0x10f0fe8: StoreField: r0->field_b = d0
    //     0x10f0fe8: stur            d0, [x0, #0xb]
    // 0x10f0fec: ldur            d0, [fp, #-0x38]
    // 0x10f0ff0: StoreField: r0->field_13 = d0
    //     0x10f0ff0: stur            d0, [x0, #0x13]
    // 0x10f0ff4: ldur            x1, [fp, #-0x10]
    // 0x10f0ff8: StoreField: r0->field_7 = r1
    //     0x10f0ff8: stur            w1, [x0, #7]
    // 0x10f0ffc: LeaveFrame
    //     0x10f0ffc: mov             SP, fp
    //     0x10f1000: ldp             fp, lr, [SP], #0x10
    // 0x10f1004: ret
    //     0x10f1004: ret             
    // 0x10f1008: d2 = 1.000000
    //     0x10f1008: fmov            d2, #1.00000000
    // 0x10f100c: cmp             x1, #0xbd2
    // 0x10f1010: b.ne            #0x10f1088
    // 0x10f1014: LoadField: r1 = r3->field_7
    //     0x10f1014: ldur            w1, [x3, #7]
    // 0x10f1018: DecompressPointer r1
    //     0x10f1018: add             x1, x1, HEAP, lsl #32
    // 0x10f101c: LoadField: r2 = r0->field_7
    //     0x10f101c: ldur            w2, [x0, #7]
    // 0x10f1020: DecompressPointer r2
    //     0x10f1020: add             x2, x2, HEAP, lsl #32
    // 0x10f1024: mov             v0.16b, v1.16b
    // 0x10f1028: r0 = lerp()
    //     0x10f1028: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f102c: mov             x1, x0
    // 0x10f1030: ldur            x0, [fp, #-8]
    // 0x10f1034: stur            x1, [fp, #-0x10]
    // 0x10f1038: LoadField: d0 = r0->field_b
    //     0x10f1038: ldur            d0, [x0, #0xb]
    // 0x10f103c: d1 = 1.000000
    //     0x10f103c: fmov            d1, #1.00000000
    // 0x10f1040: fsub            d2, d1, d0
    // 0x10f1044: ldur            d1, [fp, #-0x30]
    // 0x10f1048: fmul            d3, d2, d1
    // 0x10f104c: fadd            d1, d0, d3
    // 0x10f1050: ldur            x3, [fp, #-0x18]
    // 0x10f1054: stur            d1, [fp, #-0x40]
    // 0x10f1058: LoadField: d0 = r3->field_b
    //     0x10f1058: ldur            d0, [x3, #0xb]
    // 0x10f105c: stur            d0, [fp, #-0x38]
    // 0x10f1060: r0 = _StadiumToCircleBorder()
    //     0x10f1060: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10f1064: ldur            d0, [fp, #-0x40]
    // 0x10f1068: StoreField: r0->field_b = d0
    //     0x10f1068: stur            d0, [x0, #0xb]
    // 0x10f106c: ldur            d0, [fp, #-0x38]
    // 0x10f1070: StoreField: r0->field_13 = d0
    //     0x10f1070: stur            d0, [x0, #0x13]
    // 0x10f1074: ldur            x1, [fp, #-0x10]
    // 0x10f1078: StoreField: r0->field_7 = r1
    //     0x10f1078: stur            w1, [x0, #7]
    // 0x10f107c: LeaveFrame
    //     0x10f107c: mov             SP, fp
    //     0x10f1080: ldp             fp, lr, [SP], #0x10
    // 0x10f1084: ret
    //     0x10f1084: ret             
    // 0x10f1088: mov             x16, x0
    // 0x10f108c: mov             x0, x3
    // 0x10f1090: mov             x3, x16
    // 0x10f1094: cmp             x1, #0xbcd
    // 0x10f1098: b.ne            #0x10f1214
    // 0x10f109c: LoadField: r1 = r0->field_7
    //     0x10f109c: ldur            w1, [x0, #7]
    // 0x10f10a0: DecompressPointer r1
    //     0x10f10a0: add             x1, x1, HEAP, lsl #32
    // 0x10f10a4: LoadField: r2 = r3->field_7
    //     0x10f10a4: ldur            w2, [x3, #7]
    // 0x10f10a8: DecompressPointer r2
    //     0x10f10a8: add             x2, x2, HEAP, lsl #32
    // 0x10f10ac: mov             v0.16b, v1.16b
    // 0x10f10b0: r0 = lerp()
    //     0x10f10b0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f10b4: mov             x4, x0
    // 0x10f10b8: ldur            x0, [fp, #-8]
    // 0x10f10bc: stur            x4, [fp, #-0x20]
    // 0x10f10c0: LoadField: d0 = r0->field_b
    //     0x10f10c0: ldur            d0, [x0, #0xb]
    // 0x10f10c4: ldur            x5, [fp, #-0x18]
    // 0x10f10c8: LoadField: d1 = r5->field_b
    //     0x10f10c8: ldur            d1, [x5, #0xb]
    // 0x10f10cc: ldur            d2, [fp, #-0x30]
    // 0x10f10d0: r6 = inline_Allocate_Double()
    //     0x10f10d0: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0x10f10d4: add             x6, x6, #0x10
    //     0x10f10d8: cmp             x1, x6
    //     0x10f10dc: b.ls            #0x10f123c
    //     0x10f10e0: str             x6, [THR, #0x60]  ; THR::top
    //     0x10f10e4: sub             x6, x6, #0xf
    //     0x10f10e8: mov             x1, #0xe19c
    //     0x10f10ec: movk            x1, #3, lsl #16
    //     0x10f10f0: stur            x1, [x6, #-1]
    // 0x10f10f4: dmb             ishst
    // 0x10f10f8: StoreField: r6->field_7 = d2
    //     0x10f10f8: stur            d2, [x6, #7]
    // 0x10f10fc: stur            x6, [fp, #-0x10]
    // 0x10f1100: r1 = inline_Allocate_Double()
    //     0x10f1100: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10f1104: add             x1, x1, #0x10
    //     0x10f1108: cmp             x2, x1
    //     0x10f110c: b.ls            #0x10f1268
    //     0x10f1110: str             x1, [THR, #0x60]  ; THR::top
    //     0x10f1114: sub             x1, x1, #0xf
    //     0x10f1118: mov             x2, #0xe19c
    //     0x10f111c: movk            x2, #3, lsl #16
    //     0x10f1120: stur            x2, [x1, #-1]
    // 0x10f1124: dmb             ishst
    // 0x10f1128: StoreField: r1->field_7 = d0
    //     0x10f1128: stur            d0, [x1, #7]
    // 0x10f112c: r2 = inline_Allocate_Double()
    //     0x10f112c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x10f1130: add             x2, x2, #0x10
    //     0x10f1134: cmp             x3, x2
    //     0x10f1138: b.ls            #0x10f128c
    //     0x10f113c: str             x2, [THR, #0x60]  ; THR::top
    //     0x10f1140: sub             x2, x2, #0xf
    //     0x10f1144: mov             x3, #0xe19c
    //     0x10f1148: movk            x3, #3, lsl #16
    //     0x10f114c: stur            x3, [x2, #-1]
    // 0x10f1150: dmb             ishst
    // 0x10f1154: StoreField: r2->field_7 = d1
    //     0x10f1154: stur            d1, [x2, #7]
    // 0x10f1158: mov             x3, x6
    // 0x10f115c: r0 = lerpDouble()
    //     0x10f115c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10f1160: ldur            x1, [fp, #-8]
    // 0x10f1164: stur            x0, [fp, #-0x28]
    // 0x10f1168: LoadField: d0 = r1->field_13
    //     0x10f1168: ldur            d0, [x1, #0x13]
    // 0x10f116c: ldur            x2, [fp, #-0x18]
    // 0x10f1170: LoadField: d1 = r2->field_13
    //     0x10f1170: ldur            d1, [x2, #0x13]
    // 0x10f1174: r1 = inline_Allocate_Double()
    //     0x10f1174: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x10f1178: add             x1, x1, #0x10
    //     0x10f117c: cmp             x2, x1
    //     0x10f1180: b.ls            #0x10f12b8
    //     0x10f1184: str             x1, [THR, #0x60]  ; THR::top
    //     0x10f1188: sub             x1, x1, #0xf
    //     0x10f118c: mov             x2, #0xe19c
    //     0x10f1190: movk            x2, #3, lsl #16
    //     0x10f1194: stur            x2, [x1, #-1]
    // 0x10f1198: dmb             ishst
    // 0x10f119c: StoreField: r1->field_7 = d0
    //     0x10f119c: stur            d0, [x1, #7]
    // 0x10f11a0: r2 = inline_Allocate_Double()
    //     0x10f11a0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x10f11a4: add             x2, x2, #0x10
    //     0x10f11a8: cmp             x3, x2
    //     0x10f11ac: b.ls            #0x10f12d4
    //     0x10f11b0: str             x2, [THR, #0x60]  ; THR::top
    //     0x10f11b4: sub             x2, x2, #0xf
    //     0x10f11b8: mov             x3, #0xe19c
    //     0x10f11bc: movk            x3, #3, lsl #16
    //     0x10f11c0: stur            x3, [x2, #-1]
    // 0x10f11c4: dmb             ishst
    // 0x10f11c8: StoreField: r2->field_7 = d1
    //     0x10f11c8: stur            d1, [x2, #7]
    // 0x10f11cc: ldur            x3, [fp, #-0x10]
    // 0x10f11d0: r0 = lerpDouble()
    //     0x10f11d0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x10f11d4: mov             x1, x0
    // 0x10f11d8: ldur            x0, [fp, #-0x28]
    // 0x10f11dc: stur            x1, [fp, #-0x10]
    // 0x10f11e0: LoadField: d0 = r0->field_7
    //     0x10f11e0: ldur            d0, [x0, #7]
    // 0x10f11e4: stur            d0, [fp, #-0x38]
    // 0x10f11e8: r0 = _StadiumToCircleBorder()
    //     0x10f11e8: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10f11ec: ldur            d0, [fp, #-0x38]
    // 0x10f11f0: StoreField: r0->field_b = d0
    //     0x10f11f0: stur            d0, [x0, #0xb]
    // 0x10f11f4: ldur            x1, [fp, #-0x10]
    // 0x10f11f8: LoadField: d0 = r1->field_7
    //     0x10f11f8: ldur            d0, [x1, #7]
    // 0x10f11fc: StoreField: r0->field_13 = d0
    //     0x10f11fc: stur            d0, [x0, #0x13]
    // 0x10f1200: ldur            x1, [fp, #-0x20]
    // 0x10f1204: StoreField: r0->field_7 = r1
    //     0x10f1204: stur            w1, [x0, #7]
    // 0x10f1208: LeaveFrame
    //     0x10f1208: mov             SP, fp
    //     0x10f120c: ldp             fp, lr, [SP], #0x10
    // 0x10f1210: ret
    //     0x10f1210: ret             
    // 0x10f1214: mov             x1, x0
    // 0x10f1218: mov             x2, x3
    // 0x10f121c: mov             v2.16b, v1.16b
    // 0x10f1220: mov             v0.16b, v2.16b
    // 0x10f1224: r0 = lerpTo()
    //     0x10f1224: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f1228: LeaveFrame
    //     0x10f1228: mov             SP, fp
    //     0x10f122c: ldp             fp, lr, [SP], #0x10
    // 0x10f1230: ret
    //     0x10f1230: ret             
    // 0x10f1234: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f1234: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f1238: b               #0x10f0f90
    // 0x10f123c: stp             q1, q2, [SP, #-0x20]!
    // 0x10f1240: SaveReg d0
    //     0x10f1240: str             q0, [SP, #-0x10]!
    // 0x10f1244: stp             x4, x5, [SP, #-0x10]!
    // 0x10f1248: SaveReg r0
    //     0x10f1248: str             x0, [SP, #-8]!
    // 0x10f124c: r0 = AllocateDouble()
    //     0x10f124c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f1250: mov             x6, x0
    // 0x10f1254: RestoreReg r0
    //     0x10f1254: ldr             x0, [SP], #8
    // 0x10f1258: ldp             x4, x5, [SP], #0x10
    // 0x10f125c: RestoreReg d0
    //     0x10f125c: ldr             q0, [SP], #0x10
    // 0x10f1260: ldp             q1, q2, [SP], #0x20
    // 0x10f1264: b               #0x10f10f8
    // 0x10f1268: stp             q0, q1, [SP, #-0x20]!
    // 0x10f126c: stp             x5, x6, [SP, #-0x10]!
    // 0x10f1270: stp             x0, x4, [SP, #-0x10]!
    // 0x10f1274: r0 = AllocateDouble()
    //     0x10f1274: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f1278: mov             x1, x0
    // 0x10f127c: ldp             x0, x4, [SP], #0x10
    // 0x10f1280: ldp             x5, x6, [SP], #0x10
    // 0x10f1284: ldp             q0, q1, [SP], #0x20
    // 0x10f1288: b               #0x10f1128
    // 0x10f128c: SaveReg d1
    //     0x10f128c: str             q1, [SP, #-0x10]!
    // 0x10f1290: stp             x5, x6, [SP, #-0x10]!
    // 0x10f1294: stp             x1, x4, [SP, #-0x10]!
    // 0x10f1298: SaveReg r0
    //     0x10f1298: str             x0, [SP, #-8]!
    // 0x10f129c: r0 = AllocateDouble()
    //     0x10f129c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f12a0: mov             x2, x0
    // 0x10f12a4: RestoreReg r0
    //     0x10f12a4: ldr             x0, [SP], #8
    // 0x10f12a8: ldp             x1, x4, [SP], #0x10
    // 0x10f12ac: ldp             x5, x6, [SP], #0x10
    // 0x10f12b0: RestoreReg d1
    //     0x10f12b0: ldr             q1, [SP], #0x10
    // 0x10f12b4: b               #0x10f1154
    // 0x10f12b8: stp             q0, q1, [SP, #-0x20]!
    // 0x10f12bc: SaveReg r0
    //     0x10f12bc: str             x0, [SP, #-8]!
    // 0x10f12c0: r0 = AllocateDouble()
    //     0x10f12c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f12c4: mov             x1, x0
    // 0x10f12c8: RestoreReg r0
    //     0x10f12c8: ldr             x0, [SP], #8
    // 0x10f12cc: ldp             q0, q1, [SP], #0x20
    // 0x10f12d0: b               #0x10f119c
    // 0x10f12d4: SaveReg d1
    //     0x10f12d4: str             q1, [SP, #-0x10]!
    // 0x10f12d8: stp             x0, x1, [SP, #-0x10]!
    // 0x10f12dc: r0 = AllocateDouble()
    //     0x10f12dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f12e0: mov             x2, x0
    // 0x10f12e4: ldp             x0, x1, [SP], #0x10
    // 0x10f12e8: RestoreReg d1
    //     0x10f12e8: ldr             q1, [SP], #0x10
    // 0x10f12ec: b               #0x10f11c8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114ad54, size: 0xa0
    // 0x114ad54: EnterFrame
    //     0x114ad54: stp             fp, lr, [SP, #-0x10]!
    //     0x114ad58: mov             fp, SP
    // 0x114ad5c: CheckStackOverflow
    //     0x114ad5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ad60: cmp             SP, x16
    //     0x114ad64: b.ls            #0x114add0
    // 0x114ad68: ldr             x0, [fp, #0x10]
    // 0x114ad6c: LoadField: r1 = r0->field_7
    //     0x114ad6c: ldur            w1, [x0, #7]
    // 0x114ad70: DecompressPointer r1
    //     0x114ad70: add             x1, x1, HEAP, lsl #32
    // 0x114ad74: LoadField: d0 = r0->field_b
    //     0x114ad74: ldur            d0, [x0, #0xb]
    // 0x114ad78: r2 = inline_Allocate_Double()
    //     0x114ad78: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x114ad7c: add             x2, x2, #0x10
    //     0x114ad80: cmp             x0, x2
    //     0x114ad84: b.ls            #0x114add8
    //     0x114ad88: str             x2, [THR, #0x60]  ; THR::top
    //     0x114ad8c: sub             x2, x2, #0xf
    //     0x114ad90: mov             x0, #0xe19c
    //     0x114ad94: movk            x0, #3, lsl #16
    //     0x114ad98: stur            x0, [x2, #-1]
    // 0x114ad9c: dmb             ishst
    // 0x114ada0: StoreField: r2->field_7 = d0
    //     0x114ada0: stur            d0, [x2, #7]
    // 0x114ada4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x114ada4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x114ada8: r0 = hash()
    //     0x114ada8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114adac: mov             x2, x0
    // 0x114adb0: r0 = BoxInt64Instr(r2)
    //     0x114adb0: sbfiz           x0, x2, #1, #0x1f
    //     0x114adb4: cmp             x2, x0, asr #1
    //     0x114adb8: b.eq            #0x114adc4
    //     0x114adbc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114adc0: stur            x2, [x0, #7]
    // 0x114adc4: LeaveFrame
    //     0x114adc4: mov             SP, fp
    //     0x114adc8: ldp             fp, lr, [SP], #0x10
    // 0x114adcc: ret
    //     0x114adcc: ret             
    // 0x114add0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114add0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114add4: b               #0x114ad68
    // 0x114add8: SaveReg d0
    //     0x114add8: str             q0, [SP, #-0x10]!
    // 0x114addc: SaveReg r1
    //     0x114addc: str             x1, [SP, #-8]!
    // 0x114ade0: r0 = AllocateDouble()
    //     0x114ade0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114ade4: mov             x2, x0
    // 0x114ade8: RestoreReg r1
    //     0x114ade8: ldr             x1, [SP], #8
    // 0x114adec: RestoreReg d0
    //     0x114adec: ldr             q0, [SP], #0x10
    // 0x114adf0: b               #0x114ada0
  }
  _ ==(/* No info */) {
    // ** addr: 0x12963c4, size: 0xf0
    // 0x12963c4: EnterFrame
    //     0x12963c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12963c8: mov             fp, SP
    // 0x12963cc: AllocStack(0x10)
    //     0x12963cc: sub             SP, SP, #0x10
    // 0x12963d0: CheckStackOverflow
    //     0x12963d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12963d4: cmp             SP, x16
    //     0x12963d8: b.ls            #0x12964ac
    // 0x12963dc: ldr             x0, [fp, #0x10]
    // 0x12963e0: cmp             w0, NULL
    // 0x12963e4: b.ne            #0x12963f8
    // 0x12963e8: r0 = false
    //     0x12963e8: add             x0, NULL, #0x30  ; false
    // 0x12963ec: LeaveFrame
    //     0x12963ec: mov             SP, fp
    //     0x12963f0: ldp             fp, lr, [SP], #0x10
    // 0x12963f4: ret
    //     0x12963f4: ret             
    // 0x12963f8: str             x0, [SP]
    // 0x12963fc: r0 = runtimeType()
    //     0x12963fc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1296400: r1 = LoadClassIdInstr(r0)
    //     0x1296400: ldur            x1, [x0, #-1]
    //     0x1296404: ubfx            x1, x1, #0xc, #0x14
    // 0x1296408: r16 = _StadiumToCircleBorder
    //     0x1296408: add             x16, PP, #0xaa, lsl #12  ; [pp+0xaafd0] Type: _StadiumToCircleBorder
    //     0x129640c: ldr             x16, [x16, #0xfd0]
    // 0x1296410: stp             x16, x0, [SP]
    // 0x1296414: mov             x0, x1
    // 0x1296418: mov             lr, x0
    // 0x129641c: ldr             lr, [x21, lr, lsl #3]
    // 0x1296420: blr             lr
    // 0x1296424: tbz             w0, #4, #0x1296438
    // 0x1296428: r0 = false
    //     0x1296428: add             x0, NULL, #0x30  ; false
    // 0x129642c: LeaveFrame
    //     0x129642c: mov             SP, fp
    //     0x1296430: ldp             fp, lr, [SP], #0x10
    // 0x1296434: ret
    //     0x1296434: ret             
    // 0x1296438: ldr             x0, [fp, #0x10]
    // 0x129643c: r1 = 60
    //     0x129643c: mov             x1, #0x3c
    // 0x1296440: branchIfSmi(r0, 0x129644c)
    //     0x1296440: tbz             w0, #0, #0x129644c
    // 0x1296444: r1 = LoadClassIdInstr(r0)
    //     0x1296444: ldur            x1, [x0, #-1]
    //     0x1296448: ubfx            x1, x1, #0xc, #0x14
    // 0x129644c: cmp             x1, #0xbcd
    // 0x1296450: b.ne            #0x129649c
    // 0x1296454: ldr             x1, [fp, #0x18]
    // 0x1296458: LoadField: r2 = r0->field_7
    //     0x1296458: ldur            w2, [x0, #7]
    // 0x129645c: DecompressPointer r2
    //     0x129645c: add             x2, x2, HEAP, lsl #32
    // 0x1296460: LoadField: r3 = r1->field_7
    //     0x1296460: ldur            w3, [x1, #7]
    // 0x1296464: DecompressPointer r3
    //     0x1296464: add             x3, x3, HEAP, lsl #32
    // 0x1296468: stp             x3, x2, [SP]
    // 0x129646c: r0 = ==()
    //     0x129646c: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x1296470: tbnz            w0, #4, #0x129649c
    // 0x1296474: ldr             x2, [fp, #0x18]
    // 0x1296478: ldr             x1, [fp, #0x10]
    // 0x129647c: LoadField: d0 = r1->field_b
    //     0x129647c: ldur            d0, [x1, #0xb]
    // 0x1296480: LoadField: d1 = r2->field_b
    //     0x1296480: ldur            d1, [x2, #0xb]
    // 0x1296484: fcmp            d0, d1
    // 0x1296488: r16 = true
    //     0x1296488: add             x16, NULL, #0x20  ; true
    // 0x129648c: r17 = false
    //     0x129648c: add             x17, NULL, #0x30  ; false
    // 0x1296490: csel            x1, x16, x17, eq
    // 0x1296494: mov             x0, x1
    // 0x1296498: b               #0x12964a0
    // 0x129649c: r0 = false
    //     0x129649c: add             x0, NULL, #0x30  ; false
    // 0x12964a0: LeaveFrame
    //     0x12964a0: mov             SP, fp
    //     0x12964a4: ldp             fp, lr, [SP], #0x10
    // 0x12964a8: ret
    //     0x12964a8: ret             
    // 0x12964ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12964ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12964b0: b               #0x12963dc
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ec794, size: 0x88
    // 0x12ec794: EnterFrame
    //     0x12ec794: stp             fp, lr, [SP, #-0x10]!
    //     0x12ec798: mov             fp, SP
    // 0x12ec79c: AllocStack(0x20)
    //     0x12ec79c: sub             SP, SP, #0x20
    // 0x12ec7a0: SetupParameters(_StadiumToCircleBorder this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */)
    //     0x12ec7a0: mov             x6, x1
    //     0x12ec7a4: mov             x0, x3
    //     0x12ec7a8: stur            x3, [fp, #-0x18]
    //     0x12ec7ac: mov             x3, x5
    //     0x12ec7b0: stur            x5, [fp, #-0x20]
    //     0x12ec7b4: mov             x5, x2
    //     0x12ec7b8: stur            x1, [fp, #-8]
    //     0x12ec7bc: stur            x2, [fp, #-0x10]
    // 0x12ec7c0: CheckStackOverflow
    //     0x12ec7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ec7c4: cmp             SP, x16
    //     0x12ec7c8: b.ls            #0x12ec814
    // 0x12ec7cc: mov             x1, x6
    // 0x12ec7d0: mov             x2, x0
    // 0x12ec7d4: r0 = _adjustBorderRadius()
    //     0x12ec7d4: bl              #0xbff21c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0x12ec7d8: ldur            x1, [fp, #-8]
    // 0x12ec7dc: ldur            x2, [fp, #-0x18]
    // 0x12ec7e0: stur            x0, [fp, #-8]
    // 0x12ec7e4: r0 = _adjustRect()
    //     0x12ec7e4: bl              #0xbff0ec  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0x12ec7e8: ldur            x1, [fp, #-8]
    // 0x12ec7ec: mov             x2, x0
    // 0x12ec7f0: r0 = toRRect()
    //     0x12ec7f0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12ec7f4: ldur            x1, [fp, #-0x10]
    // 0x12ec7f8: mov             x2, x0
    // 0x12ec7fc: ldur            x3, [fp, #-0x20]
    // 0x12ec800: r0 = drawRRect()
    //     0x12ec800: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ec804: r0 = Null
    //     0x12ec804: mov             x0, NULL
    // 0x12ec808: LeaveFrame
    //     0x12ec808: mov             SP, fp
    //     0x12ec80c: ldp             fp, lr, [SP], #0x10
    // 0x12ec810: ret
    //     0x12ec810: ret             
    // 0x12ec814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ec814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ec818: b               #0x12ec7cc
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ed99c, size: 0xd0
    // 0x12ed99c: EnterFrame
    //     0x12ed99c: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed9a0: mov             fp, SP
    // 0x12ed9a4: AllocStack(0x20)
    //     0x12ed9a4: sub             SP, SP, #0x20
    // 0x12ed9a8: SetupParameters(_StadiumToCircleBorder this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x12ed9a8: mov             x5, x1
    //     0x12ed9ac: mov             x0, x3
    //     0x12ed9b0: stur            x3, [fp, #-0x20]
    //     0x12ed9b4: mov             x3, x2
    //     0x12ed9b8: stur            x1, [fp, #-0x10]
    //     0x12ed9bc: stur            x2, [fp, #-0x18]
    // 0x12ed9c0: CheckStackOverflow
    //     0x12ed9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed9c4: cmp             SP, x16
    //     0x12ed9c8: b.ls            #0x12eda64
    // 0x12ed9cc: LoadField: r4 = r5->field_7
    //     0x12ed9cc: ldur            w4, [x5, #7]
    // 0x12ed9d0: DecompressPointer r4
    //     0x12ed9d0: add             x4, x4, HEAP, lsl #32
    // 0x12ed9d4: stur            x4, [fp, #-8]
    // 0x12ed9d8: LoadField: r1 = r4->field_13
    //     0x12ed9d8: ldur            w1, [x4, #0x13]
    // 0x12ed9dc: DecompressPointer r1
    //     0x12ed9dc: add             x1, x1, HEAP, lsl #32
    // 0x12ed9e0: LoadField: r2 = r1->field_7
    //     0x12ed9e0: ldur            x2, [x1, #7]
    // 0x12ed9e4: cmp             x2, #0
    // 0x12ed9e8: b.le            #0x12eda54
    // 0x12ed9ec: mov             x1, x5
    // 0x12ed9f0: mov             x2, x0
    // 0x12ed9f4: r0 = _adjustBorderRadius()
    //     0x12ed9f4: bl              #0xbff21c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0x12ed9f8: ldur            x1, [fp, #-0x10]
    // 0x12ed9fc: ldur            x2, [fp, #-0x20]
    // 0x12eda00: stur            x0, [fp, #-0x10]
    // 0x12eda04: r0 = _adjustRect()
    //     0x12eda04: bl              #0xbff0ec  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0x12eda08: ldur            x1, [fp, #-0x10]
    // 0x12eda0c: mov             x2, x0
    // 0x12eda10: r0 = toRRect()
    //     0x12eda10: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x12eda14: mov             x1, x0
    // 0x12eda18: ldur            x0, [fp, #-8]
    // 0x12eda1c: LoadField: d0 = r0->field_b
    //     0x12eda1c: ldur            d0, [x0, #0xb]
    // 0x12eda20: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12eda20: ldur            d1, [x0, #0x17]
    // 0x12eda24: fmul            d2, d0, d1
    // 0x12eda28: d0 = 2.000000
    //     0x12eda28: fmov            d0, #2.00000000
    // 0x12eda2c: fdiv            d1, d2, d0
    // 0x12eda30: mov             v0.16b, v1.16b
    // 0x12eda34: r0 = inflate()
    //     0x12eda34: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12eda38: ldur            x1, [fp, #-8]
    // 0x12eda3c: stur            x0, [fp, #-8]
    // 0x12eda40: r0 = toPaint()
    //     0x12eda40: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12eda44: ldur            x1, [fp, #-0x18]
    // 0x12eda48: ldur            x2, [fp, #-8]
    // 0x12eda4c: mov             x3, x0
    // 0x12eda50: r0 = drawRRect()
    //     0x12eda50: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12eda54: r0 = Null
    //     0x12eda54: mov             x0, NULL
    // 0x12eda58: LeaveFrame
    //     0x12eda58: mov             SP, fp
    //     0x12eda5c: ldp             fp, lr, [SP], #0x10
    // 0x12eda60: ret
    //     0x12eda60: ret             
    // 0x12eda64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eda64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eda68: b               #0x12ed9cc
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fcd3c, size: 0x7c
    // 0x12fcd3c: EnterFrame
    //     0x12fcd3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fcd40: mov             fp, SP
    // 0x12fcd44: AllocStack(0x20)
    //     0x12fcd44: sub             SP, SP, #0x20
    // 0x12fcd48: SetupParameters(_StadiumToCircleBorder this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x18 */)
    //     0x12fcd48: mov             x0, x1
    //     0x12fcd4c: mov             v1.16b, v0.16b
    //     0x12fcd50: stur            x1, [fp, #-8]
    //     0x12fcd54: stur            d0, [fp, #-0x18]
    // 0x12fcd58: CheckStackOverflow
    //     0x12fcd58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcd5c: cmp             SP, x16
    //     0x12fcd60: b.ls            #0x12fcdb0
    // 0x12fcd64: LoadField: r1 = r0->field_7
    //     0x12fcd64: ldur            w1, [x0, #7]
    // 0x12fcd68: DecompressPointer r1
    //     0x12fcd68: add             x1, x1, HEAP, lsl #32
    // 0x12fcd6c: mov             v0.16b, v1.16b
    // 0x12fcd70: r0 = scale()
    //     0x12fcd70: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fcd74: mov             x1, x0
    // 0x12fcd78: ldur            x0, [fp, #-8]
    // 0x12fcd7c: stur            x1, [fp, #-0x10]
    // 0x12fcd80: LoadField: d0 = r0->field_13
    //     0x12fcd80: ldur            d0, [x0, #0x13]
    // 0x12fcd84: stur            d0, [fp, #-0x20]
    // 0x12fcd88: r0 = _StadiumToCircleBorder()
    //     0x12fcd88: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x12fcd8c: ldur            d0, [fp, #-0x18]
    // 0x12fcd90: StoreField: r0->field_b = d0
    //     0x12fcd90: stur            d0, [x0, #0xb]
    // 0x12fcd94: ldur            d0, [fp, #-0x20]
    // 0x12fcd98: StoreField: r0->field_13 = d0
    //     0x12fcd98: stur            d0, [x0, #0x13]
    // 0x12fcd9c: ldur            x1, [fp, #-0x10]
    // 0x12fcda0: StoreField: r0->field_7 = r1
    //     0x12fcda0: stur            w1, [x0, #7]
    // 0x12fcda4: LeaveFrame
    //     0x12fcda4: mov             SP, fp
    //     0x12fcda8: ldp             fp, lr, [SP], #0x10
    // 0x12fcdac: ret
    //     0x12fcdac: ret             
    // 0x12fcdb0: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fcdb0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fcdb4: b               #0x12fcd64
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x130069c, size: 0x174
    // 0x130069c: EnterFrame
    //     0x130069c: stp             fp, lr, [SP, #-0x10]!
    //     0x13006a0: mov             fp, SP
    // 0x13006a4: AllocStack(0x30)
    //     0x13006a4: sub             SP, SP, #0x30
    // 0x13006a8: SetupParameters(_StadiumToCircleBorder this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x13006a8: stur            x1, [fp, #-8]
    //     0x13006ac: stur            x2, [fp, #-0x10]
    // 0x13006b0: CheckStackOverflow
    //     0x13006b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13006b4: cmp             SP, x16
    //     0x13006b8: b.ls            #0x1300804
    // 0x13006bc: r0 = _NativePath()
    //     0x13006bc: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x13006c0: mov             x1, x0
    // 0x13006c4: stur            x0, [fp, #-0x18]
    // 0x13006c8: r0 = __constructor$Method$FfiNative()
    //     0x13006c8: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x13006cc: ldur            x1, [fp, #-8]
    // 0x13006d0: ldur            x2, [fp, #-0x10]
    // 0x13006d4: r0 = _adjustBorderRadius()
    //     0x13006d4: bl              #0xbff21c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0x13006d8: ldur            x1, [fp, #-8]
    // 0x13006dc: ldur            x2, [fp, #-0x10]
    // 0x13006e0: stur            x0, [fp, #-8]
    // 0x13006e4: r0 = _adjustRect()
    //     0x13006e4: bl              #0xbff0ec  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0x13006e8: ldur            x1, [fp, #-8]
    // 0x13006ec: mov             x2, x0
    // 0x13006f0: r0 = toRRect()
    //     0x13006f0: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x13006f4: stur            x0, [fp, #-8]
    // 0x13006f8: LoadField: d0 = r0->field_b
    //     0x13006f8: ldur            d0, [x0, #0xb]
    // 0x13006fc: fcvt            s1, d0
    // 0x1300700: stur            d1, [fp, #-0x28]
    // 0x1300704: r4 = 24
    //     0x1300704: mov             x4, #0x18
    // 0x1300708: r0 = AllocateFloat32Array()
    //     0x1300708: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x130070c: ldur            d0, [fp, #-0x28]
    // 0x1300710: stur            x0, [fp, #-0x10]
    // 0x1300714: ArrayStore: r0[0] = d0  ; List_8
    //     0x1300714: stur            s0, [x0, #0x17]
    // 0x1300718: ldur            x1, [fp, #-8]
    // 0x130071c: LoadField: d0 = r1->field_13
    //     0x130071c: ldur            d0, [x1, #0x13]
    // 0x1300720: fcvt            s1, d0
    // 0x1300724: StoreField: r0->field_1b = d1
    //     0x1300724: stur            s1, [x0, #0x1b]
    // 0x1300728: LoadField: d0 = r1->field_1b
    //     0x1300728: ldur            d0, [x1, #0x1b]
    // 0x130072c: fcvt            s1, d0
    // 0x1300730: StoreField: r0->field_1f = d1
    //     0x1300730: stur            s1, [x0, #0x1f]
    // 0x1300734: LoadField: d0 = r1->field_23
    //     0x1300734: ldur            d0, [x1, #0x23]
    // 0x1300738: fcvt            s1, d0
    // 0x130073c: StoreField: r0->field_23 = d1
    //     0x130073c: stur            s1, [x0, #0x23]
    // 0x1300740: LoadField: d0 = r1->field_2b
    //     0x1300740: ldur            d0, [x1, #0x2b]
    // 0x1300744: fcvt            s1, d0
    // 0x1300748: StoreField: r0->field_27 = d1
    //     0x1300748: stur            s1, [x0, #0x27]
    // 0x130074c: LoadField: d0 = r1->field_33
    //     0x130074c: ldur            d0, [x1, #0x33]
    // 0x1300750: fcvt            s1, d0
    // 0x1300754: StoreField: r0->field_2b = d1
    //     0x1300754: stur            s1, [x0, #0x2b]
    // 0x1300758: LoadField: d0 = r1->field_3b
    //     0x1300758: ldur            d0, [x1, #0x3b]
    // 0x130075c: fcvt            s1, d0
    // 0x1300760: StoreField: r0->field_2f = d1
    //     0x1300760: stur            s1, [x0, #0x2f]
    // 0x1300764: LoadField: d0 = r1->field_43
    //     0x1300764: ldur            d0, [x1, #0x43]
    // 0x1300768: fcvt            s1, d0
    // 0x130076c: StoreField: r0->field_33 = d1
    //     0x130076c: stur            s1, [x0, #0x33]
    // 0x1300770: LoadField: d0 = r1->field_4b
    //     0x1300770: ldur            d0, [x1, #0x4b]
    // 0x1300774: fcvt            s1, d0
    // 0x1300778: StoreField: r0->field_37 = d1
    //     0x1300778: stur            s1, [x0, #0x37]
    // 0x130077c: LoadField: d0 = r1->field_53
    //     0x130077c: ldur            d0, [x1, #0x53]
    // 0x1300780: fcvt            s1, d0
    // 0x1300784: StoreField: r0->field_3b = d1
    //     0x1300784: stur            s1, [x0, #0x3b]
    // 0x1300788: LoadField: d0 = r1->field_5b
    //     0x1300788: ldur            d0, [x1, #0x5b]
    // 0x130078c: fcvt            s1, d0
    // 0x1300790: StoreField: r0->field_3f = d1
    //     0x1300790: stur            s1, [x0, #0x3f]
    // 0x1300794: LoadField: d0 = r1->field_63
    //     0x1300794: ldur            d0, [x1, #0x63]
    // 0x1300798: fcvt            s1, d0
    // 0x130079c: StoreField: r0->field_43 = d1
    //     0x130079c: stur            s1, [x0, #0x43]
    // 0x13007a0: ldur            x2, [fp, #-0x18]
    // 0x13007a4: LoadField: r1 = r2->field_7
    //     0x13007a4: ldur            w1, [x2, #7]
    // 0x13007a8: DecompressPointer r1
    //     0x13007a8: add             x1, x1, HEAP, lsl #32
    // 0x13007ac: cmp             w1, NULL
    // 0x13007b0: b.eq            #0x130080c
    // 0x13007b4: LoadField: r3 = r1->field_7
    //     0x13007b4: ldur            x3, [x1, #7]
    // 0x13007b8: ldr             x1, [x3]
    // 0x13007bc: cbz             x1, #0x13007f4
    // 0x13007c0: mov             x3, x1
    // 0x13007c4: stur            x3, [fp, #-0x20]
    // 0x13007c8: r1 = <Never>
    //     0x13007c8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x13007cc: r0 = Pointer()
    //     0x13007cc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x13007d0: mov             x1, x0
    // 0x13007d4: ldur            x0, [fp, #-0x20]
    // 0x13007d8: StoreField: r1->field_7 = r0
    //     0x13007d8: stur            x0, [x1, #7]
    // 0x13007dc: ldur            x2, [fp, #-0x10]
    // 0x13007e0: r0 = __addRRect$Method$FfiNative()
    //     0x13007e0: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x13007e4: ldur            x0, [fp, #-0x18]
    // 0x13007e8: LeaveFrame
    //     0x13007e8: mov             SP, fp
    //     0x13007ec: ldp             fp, lr, [SP], #0x10
    // 0x13007f0: ret
    //     0x13007f0: ret             
    // 0x13007f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x13007f4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x13007f8: str             x16, [SP]
    // 0x13007fc: r0 = _throwNew()
    //     0x13007fc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1300800: brk             #0
    // 0x1300804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300808: b               #0x13006bc
    // 0x130080c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x130080c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1301acc, size: 0x78
    // 0x1301acc: EnterFrame
    //     0x1301acc: stp             fp, lr, [SP, #-0x10]!
    //     0x1301ad0: mov             fp, SP
    // 0x1301ad4: AllocStack(0x18)
    //     0x1301ad4: sub             SP, SP, #0x18
    // 0x1301ad8: SetupParameters({dynamic circularity})
    //     0x1301ad8: ldur            w0, [x4, #0x1f]
    //     0x1301adc: add             x0, x0, HEAP, lsl #32
    //     0x1301ae0: add             x16, PP, #0xaa, lsl #12  ; [pp+0xaafd8] "circularity"
    //     0x1301ae4: ldr             x16, [x16, #0xfd8]
    //     0x1301ae8: cmp             w0, w16
    //     0x1301aec: b.eq            #0x1301af0
    // 0x1301af0: cmp             w2, NULL
    // 0x1301af4: b.ne            #0x1301b04
    // 0x1301af8: LoadField: r0 = r1->field_7
    //     0x1301af8: ldur            w0, [x1, #7]
    // 0x1301afc: DecompressPointer r0
    //     0x1301afc: add             x0, x0, HEAP, lsl #32
    // 0x1301b00: b               #0x1301b08
    // 0x1301b04: mov             x0, x2
    // 0x1301b08: stur            x0, [fp, #-8]
    // 0x1301b0c: LoadField: d0 = r1->field_b
    //     0x1301b0c: ldur            d0, [x1, #0xb]
    // 0x1301b10: stur            d0, [fp, #-0x18]
    // 0x1301b14: LoadField: d1 = r1->field_13
    //     0x1301b14: ldur            d1, [x1, #0x13]
    // 0x1301b18: stur            d1, [fp, #-0x10]
    // 0x1301b1c: r0 = _StadiumToCircleBorder()
    //     0x1301b1c: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x1301b20: ldur            d0, [fp, #-0x18]
    // 0x1301b24: StoreField: r0->field_b = d0
    //     0x1301b24: stur            d0, [x0, #0xb]
    // 0x1301b28: ldur            d0, [fp, #-0x10]
    // 0x1301b2c: StoreField: r0->field_13 = d0
    //     0x1301b2c: stur            d0, [x0, #0x13]
    // 0x1301b30: ldur            x1, [fp, #-8]
    // 0x1301b34: StoreField: r0->field_7 = r1
    //     0x1301b34: stur            w1, [x0, #7]
    // 0x1301b38: LeaveFrame
    //     0x1301b38: mov             SP, fp
    //     0x1301b3c: ldp             fp, lr, [SP], #0x10
    // 0x1301b40: ret
    //     0x1301b40: ret             
  }
}

// class id: 3022, size: 0xc, field offset: 0xc
//   const constructor, 
class StadiumBorder extends OutlinedBorder {

  BorderSide field_8;

  _ getInnerPath(/* No info */) {
    // ** addr: 0xbfed64, size: 0x1dc
    // 0xbfed64: EnterFrame
    //     0xbfed64: stp             fp, lr, [SP, #-0x10]!
    //     0xbfed68: mov             fp, SP
    // 0xbfed6c: AllocStack(0x30)
    //     0xbfed6c: sub             SP, SP, #0x30
    // 0xbfed70: SetupParameters(StadiumBorder this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbfed70: mov             x0, x2
    //     0xbfed74: stur            x2, [fp, #-0x10]
    //     0xbfed78: mov             x2, x1
    //     0xbfed7c: stur            x1, [fp, #-8]
    // 0xbfed80: CheckStackOverflow
    //     0xbfed80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfed84: cmp             SP, x16
    //     0xbfed88: b.ls            #0xbfef34
    // 0xbfed8c: mov             x1, x0
    // 0xbfed90: r0 = shortestSide()
    //     0xbfed90: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xbfed94: mov             v1.16b, v0.16b
    // 0xbfed98: d0 = 2.000000
    //     0xbfed98: fmov            d0, #2.00000000
    // 0xbfed9c: fdiv            d2, d1, d0
    // 0xbfeda0: stur            d2, [fp, #-0x28]
    // 0xbfeda4: r0 = Radius()
    //     0xbfeda4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbfeda8: ldur            d0, [fp, #-0x28]
    // 0xbfedac: stur            x0, [fp, #-0x18]
    // 0xbfedb0: StoreField: r0->field_7 = d0
    //     0xbfedb0: stur            d0, [x0, #7]
    // 0xbfedb4: StoreField: r0->field_f = d0
    //     0xbfedb4: stur            d0, [x0, #0xf]
    // 0xbfedb8: r1 = <RRect>
    //     0xbfedb8: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xbfedbc: ldr             x1, [x1, #0x108]
    // 0xbfedc0: r0 = RRect()
    //     0xbfedc0: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xbfedc4: mov             x1, x0
    // 0xbfedc8: ldur            x2, [fp, #-0x10]
    // 0xbfedcc: ldur            x3, [fp, #-0x18]
    // 0xbfedd0: stur            x0, [fp, #-0x10]
    // 0xbfedd4: r0 = RRect.fromRectAndRadius()
    //     0xbfedd4: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xbfedd8: ldur            x0, [fp, #-8]
    // 0xbfeddc: LoadField: r1 = r0->field_7
    //     0xbfeddc: ldur            w1, [x0, #7]
    // 0xbfede0: DecompressPointer r1
    //     0xbfede0: add             x1, x1, HEAP, lsl #32
    // 0xbfede4: LoadField: d0 = r1->field_b
    //     0xbfede4: ldur            d0, [x1, #0xb]
    // 0xbfede8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xbfede8: ldur            d1, [x1, #0x17]
    // 0xbfedec: d2 = 1.000000
    //     0xbfedec: fmov            d2, #1.00000000
    // 0xbfedf0: fadd            d3, d1, d2
    // 0xbfedf4: d1 = 2.000000
    //     0xbfedf4: fmov            d1, #2.00000000
    // 0xbfedf8: fdiv            d4, d3, d1
    // 0xbfedfc: fsub            d1, d2, d4
    // 0xbfee00: fmul            d2, d0, d1
    // 0xbfee04: ldur            x1, [fp, #-0x10]
    // 0xbfee08: mov             v0.16b, v2.16b
    // 0xbfee0c: r0 = deflate()
    //     0xbfee0c: bl              #0xbfdae4  ; [dart:ui] _RRectLike::deflate
    // 0xbfee10: stur            x0, [fp, #-8]
    // 0xbfee14: r0 = _NativePath()
    //     0xbfee14: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xbfee18: mov             x1, x0
    // 0xbfee1c: stur            x0, [fp, #-0x10]
    // 0xbfee20: r0 = __constructor$Method$FfiNative()
    //     0xbfee20: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xbfee24: ldur            x0, [fp, #-8]
    // 0xbfee28: LoadField: d0 = r0->field_b
    //     0xbfee28: ldur            d0, [x0, #0xb]
    // 0xbfee2c: fcvt            s1, d0
    // 0xbfee30: stur            d1, [fp, #-0x28]
    // 0xbfee34: r4 = 24
    //     0xbfee34: mov             x4, #0x18
    // 0xbfee38: r0 = AllocateFloat32Array()
    //     0xbfee38: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xbfee3c: ldur            d0, [fp, #-0x28]
    // 0xbfee40: stur            x0, [fp, #-0x18]
    // 0xbfee44: ArrayStore: r0[0] = d0  ; List_8
    //     0xbfee44: stur            s0, [x0, #0x17]
    // 0xbfee48: ldur            x1, [fp, #-8]
    // 0xbfee4c: LoadField: d0 = r1->field_13
    //     0xbfee4c: ldur            d0, [x1, #0x13]
    // 0xbfee50: fcvt            s1, d0
    // 0xbfee54: StoreField: r0->field_1b = d1
    //     0xbfee54: stur            s1, [x0, #0x1b]
    // 0xbfee58: LoadField: d0 = r1->field_1b
    //     0xbfee58: ldur            d0, [x1, #0x1b]
    // 0xbfee5c: fcvt            s1, d0
    // 0xbfee60: StoreField: r0->field_1f = d1
    //     0xbfee60: stur            s1, [x0, #0x1f]
    // 0xbfee64: LoadField: d0 = r1->field_23
    //     0xbfee64: ldur            d0, [x1, #0x23]
    // 0xbfee68: fcvt            s1, d0
    // 0xbfee6c: StoreField: r0->field_23 = d1
    //     0xbfee6c: stur            s1, [x0, #0x23]
    // 0xbfee70: LoadField: d0 = r1->field_2b
    //     0xbfee70: ldur            d0, [x1, #0x2b]
    // 0xbfee74: fcvt            s1, d0
    // 0xbfee78: StoreField: r0->field_27 = d1
    //     0xbfee78: stur            s1, [x0, #0x27]
    // 0xbfee7c: LoadField: d0 = r1->field_33
    //     0xbfee7c: ldur            d0, [x1, #0x33]
    // 0xbfee80: fcvt            s1, d0
    // 0xbfee84: StoreField: r0->field_2b = d1
    //     0xbfee84: stur            s1, [x0, #0x2b]
    // 0xbfee88: LoadField: d0 = r1->field_3b
    //     0xbfee88: ldur            d0, [x1, #0x3b]
    // 0xbfee8c: fcvt            s1, d0
    // 0xbfee90: StoreField: r0->field_2f = d1
    //     0xbfee90: stur            s1, [x0, #0x2f]
    // 0xbfee94: LoadField: d0 = r1->field_43
    //     0xbfee94: ldur            d0, [x1, #0x43]
    // 0xbfee98: fcvt            s1, d0
    // 0xbfee9c: StoreField: r0->field_33 = d1
    //     0xbfee9c: stur            s1, [x0, #0x33]
    // 0xbfeea0: LoadField: d0 = r1->field_4b
    //     0xbfeea0: ldur            d0, [x1, #0x4b]
    // 0xbfeea4: fcvt            s1, d0
    // 0xbfeea8: StoreField: r0->field_37 = d1
    //     0xbfeea8: stur            s1, [x0, #0x37]
    // 0xbfeeac: LoadField: d0 = r1->field_53
    //     0xbfeeac: ldur            d0, [x1, #0x53]
    // 0xbfeeb0: fcvt            s1, d0
    // 0xbfeeb4: StoreField: r0->field_3b = d1
    //     0xbfeeb4: stur            s1, [x0, #0x3b]
    // 0xbfeeb8: LoadField: d0 = r1->field_5b
    //     0xbfeeb8: ldur            d0, [x1, #0x5b]
    // 0xbfeebc: fcvt            s1, d0
    // 0xbfeec0: StoreField: r0->field_3f = d1
    //     0xbfeec0: stur            s1, [x0, #0x3f]
    // 0xbfeec4: LoadField: d0 = r1->field_63
    //     0xbfeec4: ldur            d0, [x1, #0x63]
    // 0xbfeec8: fcvt            s1, d0
    // 0xbfeecc: StoreField: r0->field_43 = d1
    //     0xbfeecc: stur            s1, [x0, #0x43]
    // 0xbfeed0: ldur            x2, [fp, #-0x10]
    // 0xbfeed4: LoadField: r1 = r2->field_7
    //     0xbfeed4: ldur            w1, [x2, #7]
    // 0xbfeed8: DecompressPointer r1
    //     0xbfeed8: add             x1, x1, HEAP, lsl #32
    // 0xbfeedc: cmp             w1, NULL
    // 0xbfeee0: b.eq            #0xbfef3c
    // 0xbfeee4: LoadField: r3 = r1->field_7
    //     0xbfeee4: ldur            x3, [x1, #7]
    // 0xbfeee8: ldr             x1, [x3]
    // 0xbfeeec: cbz             x1, #0xbfef24
    // 0xbfeef0: mov             x3, x1
    // 0xbfeef4: stur            x3, [fp, #-0x20]
    // 0xbfeef8: r1 = <Never>
    //     0xbfeef8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbfeefc: r0 = Pointer()
    //     0xbfeefc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbfef00: mov             x1, x0
    // 0xbfef04: ldur            x0, [fp, #-0x20]
    // 0xbfef08: StoreField: r1->field_7 = r0
    //     0xbfef08: stur            x0, [x1, #7]
    // 0xbfef0c: ldur            x2, [fp, #-0x18]
    // 0xbfef10: r0 = __addRRect$Method$FfiNative()
    //     0xbfef10: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xbfef14: ldur            x0, [fp, #-0x10]
    // 0xbfef18: LeaveFrame
    //     0xbfef18: mov             SP, fp
    //     0xbfef1c: ldp             fp, lr, [SP], #0x10
    // 0xbfef20: ret
    //     0xbfef20: ret             
    // 0xbfef24: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbfef24: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbfef28: str             x16, [SP]
    // 0xbfef2c: r0 = _throwNew()
    //     0xbfef2c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbfef30: brk             #0
    // 0xbfef34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfef34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfef38: b               #0xbfed8c
    // 0xbfef3c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbfef3c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x10edc4c, size: 0x1a0
    // 0x10edc4c: EnterFrame
    //     0x10edc4c: stp             fp, lr, [SP, #-0x10]!
    //     0x10edc50: mov             fp, SP
    // 0x10edc54: AllocStack(0x30)
    //     0x10edc54: sub             SP, SP, #0x30
    // 0x10edc58: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x10edc58: mov             x0, x2
    //     0x10edc5c: mov             v1.16b, v0.16b
    //     0x10edc60: stur            x2, [fp, #-0x10]
    //     0x10edc64: stur            d0, [fp, #-0x20]
    // 0x10edc68: CheckStackOverflow
    //     0x10edc68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10edc6c: cmp             SP, x16
    //     0x10edc70: b.ls            #0x10edde4
    // 0x10edc74: r2 = LoadClassIdInstr(r0)
    //     0x10edc74: ldur            x2, [x0, #-1]
    //     0x10edc78: ubfx            x2, x2, #0xc, #0x14
    // 0x10edc7c: cmp             x2, #0xbce
    // 0x10edc80: b.ne            #0x10edcc8
    // 0x10edc84: LoadField: r2 = r0->field_7
    //     0x10edc84: ldur            w2, [x0, #7]
    // 0x10edc88: DecompressPointer r2
    //     0x10edc88: add             x2, x2, HEAP, lsl #32
    // 0x10edc8c: LoadField: r0 = r1->field_7
    //     0x10edc8c: ldur            w0, [x1, #7]
    // 0x10edc90: DecompressPointer r0
    //     0x10edc90: add             x0, x0, HEAP, lsl #32
    // 0x10edc94: mov             x1, x2
    // 0x10edc98: mov             x2, x0
    // 0x10edc9c: mov             v0.16b, v1.16b
    // 0x10edca0: r0 = lerp()
    //     0x10edca0: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10edca4: stur            x0, [fp, #-8]
    // 0x10edca8: r0 = StadiumBorder()
    //     0x10edca8: bl              #0x10ede04  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x10edcac: mov             x1, x0
    // 0x10edcb0: ldur            x0, [fp, #-8]
    // 0x10edcb4: StoreField: r1->field_7 = r0
    //     0x10edcb4: stur            w0, [x1, #7]
    // 0x10edcb8: mov             x0, x1
    // 0x10edcbc: LeaveFrame
    //     0x10edcbc: mov             SP, fp
    //     0x10edcc0: ldp             fp, lr, [SP], #0x10
    // 0x10edcc4: ret
    //     0x10edcc4: ret             
    // 0x10edcc8: cmp             x2, #0xbd2
    // 0x10edccc: b.ne            #0x10edd38
    // 0x10edcd0: LoadField: r2 = r0->field_7
    //     0x10edcd0: ldur            w2, [x0, #7]
    // 0x10edcd4: DecompressPointer r2
    //     0x10edcd4: add             x2, x2, HEAP, lsl #32
    // 0x10edcd8: LoadField: r3 = r1->field_7
    //     0x10edcd8: ldur            w3, [x1, #7]
    // 0x10edcdc: DecompressPointer r3
    //     0x10edcdc: add             x3, x3, HEAP, lsl #32
    // 0x10edce0: mov             x1, x2
    // 0x10edce4: mov             x2, x3
    // 0x10edce8: mov             v0.16b, v1.16b
    // 0x10edcec: r0 = lerp()
    //     0x10edcec: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10edcf0: ldur            d1, [fp, #-0x20]
    // 0x10edcf4: d2 = 1.000000
    //     0x10edcf4: fmov            d2, #1.00000000
    // 0x10edcf8: stur            x0, [fp, #-8]
    // 0x10edcfc: fsub            d0, d2, d1
    // 0x10edd00: ldur            x3, [fp, #-0x10]
    // 0x10edd04: stur            d0, [fp, #-0x30]
    // 0x10edd08: LoadField: d1 = r3->field_b
    //     0x10edd08: ldur            d1, [x3, #0xb]
    // 0x10edd0c: stur            d1, [fp, #-0x28]
    // 0x10edd10: r0 = _StadiumToCircleBorder()
    //     0x10edd10: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10edd14: ldur            d0, [fp, #-0x30]
    // 0x10edd18: StoreField: r0->field_b = d0
    //     0x10edd18: stur            d0, [x0, #0xb]
    // 0x10edd1c: ldur            d0, [fp, #-0x28]
    // 0x10edd20: StoreField: r0->field_13 = d0
    //     0x10edd20: stur            d0, [x0, #0x13]
    // 0x10edd24: ldur            x1, [fp, #-8]
    // 0x10edd28: StoreField: r0->field_7 = r1
    //     0x10edd28: stur            w1, [x0, #7]
    // 0x10edd2c: LeaveFrame
    //     0x10edd2c: mov             SP, fp
    //     0x10edd30: ldp             fp, lr, [SP], #0x10
    // 0x10edd34: ret
    //     0x10edd34: ret             
    // 0x10edd38: mov             x3, x0
    // 0x10edd3c: d2 = 1.000000
    //     0x10edd3c: fmov            d2, #1.00000000
    // 0x10edd40: cmp             x2, #0xbd5
    // 0x10edd44: b.ne            #0x10eddbc
    // 0x10edd48: LoadField: r0 = r3->field_7
    //     0x10edd48: ldur            w0, [x3, #7]
    // 0x10edd4c: DecompressPointer r0
    //     0x10edd4c: add             x0, x0, HEAP, lsl #32
    // 0x10edd50: LoadField: r2 = r1->field_7
    //     0x10edd50: ldur            w2, [x1, #7]
    // 0x10edd54: DecompressPointer r2
    //     0x10edd54: add             x2, x2, HEAP, lsl #32
    // 0x10edd58: mov             x1, x0
    // 0x10edd5c: mov             v0.16b, v1.16b
    // 0x10edd60: r0 = lerp()
    //     0x10edd60: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10edd64: mov             x1, x0
    // 0x10edd68: ldur            x0, [fp, #-0x10]
    // 0x10edd6c: stur            x1, [fp, #-0x18]
    // 0x10edd70: LoadField: r2 = r0->field_b
    //     0x10edd70: ldur            w2, [x0, #0xb]
    // 0x10edd74: DecompressPointer r2
    //     0x10edd74: add             x2, x2, HEAP, lsl #32
    // 0x10edd78: ldur            d0, [fp, #-0x20]
    // 0x10edd7c: stur            x2, [fp, #-8]
    // 0x10edd80: d1 = 1.000000
    //     0x10edd80: fmov            d1, #1.00000000
    // 0x10edd84: fsub            d2, d1, d0
    // 0x10edd88: stur            d2, [fp, #-0x28]
    // 0x10edd8c: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10edd8c: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10edd90: mov             x1, x0
    // 0x10edd94: ldur            x0, [fp, #-8]
    // 0x10edd98: StoreField: r1->field_b = r0
    //     0x10edd98: stur            w0, [x1, #0xb]
    // 0x10edd9c: ldur            d0, [fp, #-0x28]
    // 0x10edda0: StoreField: r1->field_f = d0
    //     0x10edda0: stur            d0, [x1, #0xf]
    // 0x10edda4: ldur            x0, [fp, #-0x18]
    // 0x10edda8: StoreField: r1->field_7 = r0
    //     0x10edda8: stur            w0, [x1, #7]
    // 0x10eddac: mov             x0, x1
    // 0x10eddb0: LeaveFrame
    //     0x10eddb0: mov             SP, fp
    //     0x10eddb4: ldp             fp, lr, [SP], #0x10
    // 0x10eddb8: ret
    //     0x10eddb8: ret             
    // 0x10eddbc: mov             x0, x3
    // 0x10eddc0: mov             v0.16b, v1.16b
    // 0x10eddc4: cmp             w0, NULL
    // 0x10eddc8: b.ne            #0x10eddd4
    // 0x10eddcc: r0 = scale()
    //     0x10eddcc: bl              #0x12fccf0  ; [package:flutter/src/painting/stadium_border.dart] StadiumBorder::scale
    // 0x10eddd0: b               #0x10eddd8
    // 0x10eddd4: r0 = Null
    //     0x10eddd4: mov             x0, NULL
    // 0x10eddd8: LeaveFrame
    //     0x10eddd8: mov             SP, fp
    //     0x10edddc: ldp             fp, lr, [SP], #0x10
    // 0x10edde0: ret
    //     0x10edde0: ret             
    // 0x10edde4: r0 = StackOverflowSharedWithFPURegs()
    //     0x10edde4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10edde8: b               #0x10edc74
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x10f0de8, size: 0x178
    // 0x10f0de8: EnterFrame
    //     0x10f0de8: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0dec: mov             fp, SP
    // 0x10f0df0: AllocStack(0x28)
    //     0x10f0df0: sub             SP, SP, #0x28
    // 0x10f0df4: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x20 */)
    //     0x10f0df4: mov             x0, x2
    //     0x10f0df8: mov             v1.16b, v0.16b
    //     0x10f0dfc: stur            x2, [fp, #-0x10]
    //     0x10f0e00: stur            d0, [fp, #-0x20]
    // 0x10f0e04: CheckStackOverflow
    //     0x10f0e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f0e08: cmp             SP, x16
    //     0x10f0e0c: b.ls            #0x10f0f58
    // 0x10f0e10: r2 = LoadClassIdInstr(r0)
    //     0x10f0e10: ldur            x2, [x0, #-1]
    //     0x10f0e14: ubfx            x2, x2, #0xc, #0x14
    // 0x10f0e18: cmp             x2, #0xbce
    // 0x10f0e1c: b.ne            #0x10f0e68
    // 0x10f0e20: LoadField: r2 = r1->field_7
    //     0x10f0e20: ldur            w2, [x1, #7]
    // 0x10f0e24: DecompressPointer r2
    //     0x10f0e24: add             x2, x2, HEAP, lsl #32
    // 0x10f0e28: LoadField: r1 = r0->field_7
    //     0x10f0e28: ldur            w1, [x0, #7]
    // 0x10f0e2c: DecompressPointer r1
    //     0x10f0e2c: add             x1, x1, HEAP, lsl #32
    // 0x10f0e30: mov             x16, x1
    // 0x10f0e34: mov             x1, x2
    // 0x10f0e38: mov             x2, x16
    // 0x10f0e3c: mov             v0.16b, v1.16b
    // 0x10f0e40: r0 = lerp()
    //     0x10f0e40: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0e44: stur            x0, [fp, #-8]
    // 0x10f0e48: r0 = StadiumBorder()
    //     0x10f0e48: bl              #0x10ede04  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x10f0e4c: mov             x1, x0
    // 0x10f0e50: ldur            x0, [fp, #-8]
    // 0x10f0e54: StoreField: r1->field_7 = r0
    //     0x10f0e54: stur            w0, [x1, #7]
    // 0x10f0e58: mov             x0, x1
    // 0x10f0e5c: LeaveFrame
    //     0x10f0e5c: mov             SP, fp
    //     0x10f0e60: ldp             fp, lr, [SP], #0x10
    // 0x10f0e64: ret
    //     0x10f0e64: ret             
    // 0x10f0e68: cmp             x2, #0xbd2
    // 0x10f0e6c: b.ne            #0x10f0ed0
    // 0x10f0e70: LoadField: r2 = r1->field_7
    //     0x10f0e70: ldur            w2, [x1, #7]
    // 0x10f0e74: DecompressPointer r2
    //     0x10f0e74: add             x2, x2, HEAP, lsl #32
    // 0x10f0e78: LoadField: r1 = r0->field_7
    //     0x10f0e78: ldur            w1, [x0, #7]
    // 0x10f0e7c: DecompressPointer r1
    //     0x10f0e7c: add             x1, x1, HEAP, lsl #32
    // 0x10f0e80: mov             x16, x1
    // 0x10f0e84: mov             x1, x2
    // 0x10f0e88: mov             x2, x16
    // 0x10f0e8c: mov             v0.16b, v1.16b
    // 0x10f0e90: r0 = lerp()
    //     0x10f0e90: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0e94: mov             x1, x0
    // 0x10f0e98: ldur            x0, [fp, #-0x10]
    // 0x10f0e9c: stur            x1, [fp, #-8]
    // 0x10f0ea0: LoadField: d0 = r0->field_b
    //     0x10f0ea0: ldur            d0, [x0, #0xb]
    // 0x10f0ea4: stur            d0, [fp, #-0x28]
    // 0x10f0ea8: r0 = _StadiumToCircleBorder()
    //     0x10f0ea8: bl              #0x10eddf8  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x10f0eac: ldur            d1, [fp, #-0x20]
    // 0x10f0eb0: StoreField: r0->field_b = d1
    //     0x10f0eb0: stur            d1, [x0, #0xb]
    // 0x10f0eb4: ldur            d0, [fp, #-0x28]
    // 0x10f0eb8: StoreField: r0->field_13 = d0
    //     0x10f0eb8: stur            d0, [x0, #0x13]
    // 0x10f0ebc: ldur            x1, [fp, #-8]
    // 0x10f0ec0: StoreField: r0->field_7 = r1
    //     0x10f0ec0: stur            w1, [x0, #7]
    // 0x10f0ec4: LeaveFrame
    //     0x10f0ec4: mov             SP, fp
    //     0x10f0ec8: ldp             fp, lr, [SP], #0x10
    // 0x10f0ecc: ret
    //     0x10f0ecc: ret             
    // 0x10f0ed0: cmp             x2, #0xbd5
    // 0x10f0ed4: b.ne            #0x10f0f40
    // 0x10f0ed8: LoadField: r2 = r1->field_7
    //     0x10f0ed8: ldur            w2, [x1, #7]
    // 0x10f0edc: DecompressPointer r2
    //     0x10f0edc: add             x2, x2, HEAP, lsl #32
    // 0x10f0ee0: LoadField: r1 = r0->field_7
    //     0x10f0ee0: ldur            w1, [x0, #7]
    // 0x10f0ee4: DecompressPointer r1
    //     0x10f0ee4: add             x1, x1, HEAP, lsl #32
    // 0x10f0ee8: mov             x16, x1
    // 0x10f0eec: mov             x1, x2
    // 0x10f0ef0: mov             x2, x16
    // 0x10f0ef4: mov             v0.16b, v1.16b
    // 0x10f0ef8: r0 = lerp()
    //     0x10f0ef8: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x10f0efc: ldur            x2, [fp, #-0x10]
    // 0x10f0f00: stur            x0, [fp, #-0x18]
    // 0x10f0f04: LoadField: r1 = r2->field_b
    //     0x10f0f04: ldur            w1, [x2, #0xb]
    // 0x10f0f08: DecompressPointer r1
    //     0x10f0f08: add             x1, x1, HEAP, lsl #32
    // 0x10f0f0c: stur            x1, [fp, #-8]
    // 0x10f0f10: r0 = _StadiumToRoundedRectangleBorder()
    //     0x10f0f10: bl              #0x10eddec  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x10f0f14: mov             x1, x0
    // 0x10f0f18: ldur            x0, [fp, #-8]
    // 0x10f0f1c: StoreField: r1->field_b = r0
    //     0x10f0f1c: stur            w0, [x1, #0xb]
    // 0x10f0f20: ldur            d0, [fp, #-0x20]
    // 0x10f0f24: StoreField: r1->field_f = d0
    //     0x10f0f24: stur            d0, [x1, #0xf]
    // 0x10f0f28: ldur            x0, [fp, #-0x18]
    // 0x10f0f2c: StoreField: r1->field_7 = r0
    //     0x10f0f2c: stur            w0, [x1, #7]
    // 0x10f0f30: mov             x0, x1
    // 0x10f0f34: LeaveFrame
    //     0x10f0f34: mov             SP, fp
    //     0x10f0f38: ldp             fp, lr, [SP], #0x10
    // 0x10f0f3c: ret
    //     0x10f0f3c: ret             
    // 0x10f0f40: mov             x2, x0
    // 0x10f0f44: mov             v0.16b, v1.16b
    // 0x10f0f48: r0 = lerpTo()
    //     0x10f0f48: bl              #0x10f17e8  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x10f0f4c: LeaveFrame
    //     0x10f0f4c: mov             SP, fp
    //     0x10f0f50: ldp             fp, lr, [SP], #0x10
    // 0x10f0f54: ret
    //     0x10f0f54: ret             
    // 0x10f0f58: r0 = StackOverflowSharedWithFPURegs()
    //     0x10f0f58: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10f0f5c: b               #0x10f0e10
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114ad14, size: 0x40
    // 0x114ad14: EnterFrame
    //     0x114ad14: stp             fp, lr, [SP, #-0x10]!
    //     0x114ad18: mov             fp, SP
    // 0x114ad1c: AllocStack(0x8)
    //     0x114ad1c: sub             SP, SP, #8
    // 0x114ad20: CheckStackOverflow
    //     0x114ad20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ad24: cmp             SP, x16
    //     0x114ad28: b.ls            #0x114ad4c
    // 0x114ad2c: ldr             x0, [fp, #0x10]
    // 0x114ad30: LoadField: r1 = r0->field_7
    //     0x114ad30: ldur            w1, [x0, #7]
    // 0x114ad34: DecompressPointer r1
    //     0x114ad34: add             x1, x1, HEAP, lsl #32
    // 0x114ad38: str             x1, [SP]
    // 0x114ad3c: r0 = hashCode()
    //     0x114ad3c: bl              #0x113b284  ; [package:flutter/src/painting/borders.dart] BorderSide::hashCode
    // 0x114ad40: LeaveFrame
    //     0x114ad40: mov             SP, fp
    //     0x114ad44: ldp             fp, lr, [SP], #0x10
    // 0x114ad48: ret
    //     0x114ad48: ret             
    // 0x114ad4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ad4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ad50: b               #0x114ad2c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12962fc, size: 0xc8
    // 0x12962fc: EnterFrame
    //     0x12962fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1296300: mov             fp, SP
    // 0x1296304: AllocStack(0x10)
    //     0x1296304: sub             SP, SP, #0x10
    // 0x1296308: CheckStackOverflow
    //     0x1296308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129630c: cmp             SP, x16
    //     0x1296310: b.ls            #0x12963bc
    // 0x1296314: ldr             x0, [fp, #0x10]
    // 0x1296318: cmp             w0, NULL
    // 0x129631c: b.ne            #0x1296330
    // 0x1296320: r0 = false
    //     0x1296320: add             x0, NULL, #0x30  ; false
    // 0x1296324: LeaveFrame
    //     0x1296324: mov             SP, fp
    //     0x1296328: ldp             fp, lr, [SP], #0x10
    // 0x129632c: ret
    //     0x129632c: ret             
    // 0x1296330: str             x0, [SP]
    // 0x1296334: r0 = runtimeType()
    //     0x1296334: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1296338: r1 = LoadClassIdInstr(r0)
    //     0x1296338: ldur            x1, [x0, #-1]
    //     0x129633c: ubfx            x1, x1, #0xc, #0x14
    // 0x1296340: r16 = StadiumBorder
    //     0x1296340: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0cb0] Type: StadiumBorder
    //     0x1296344: ldr             x16, [x16, #0xcb0]
    // 0x1296348: stp             x16, x0, [SP]
    // 0x129634c: mov             x0, x1
    // 0x1296350: mov             lr, x0
    // 0x1296354: ldr             lr, [x21, lr, lsl #3]
    // 0x1296358: blr             lr
    // 0x129635c: tbz             w0, #4, #0x1296370
    // 0x1296360: r0 = false
    //     0x1296360: add             x0, NULL, #0x30  ; false
    // 0x1296364: LeaveFrame
    //     0x1296364: mov             SP, fp
    //     0x1296368: ldp             fp, lr, [SP], #0x10
    // 0x129636c: ret
    //     0x129636c: ret             
    // 0x1296370: ldr             x0, [fp, #0x10]
    // 0x1296374: r1 = 60
    //     0x1296374: mov             x1, #0x3c
    // 0x1296378: branchIfSmi(r0, 0x1296384)
    //     0x1296378: tbz             w0, #0, #0x1296384
    // 0x129637c: r1 = LoadClassIdInstr(r0)
    //     0x129637c: ldur            x1, [x0, #-1]
    //     0x1296380: ubfx            x1, x1, #0xc, #0x14
    // 0x1296384: cmp             x1, #0xbce
    // 0x1296388: b.ne            #0x12963ac
    // 0x129638c: ldr             x1, [fp, #0x18]
    // 0x1296390: LoadField: r2 = r0->field_7
    //     0x1296390: ldur            w2, [x0, #7]
    // 0x1296394: DecompressPointer r2
    //     0x1296394: add             x2, x2, HEAP, lsl #32
    // 0x1296398: LoadField: r0 = r1->field_7
    //     0x1296398: ldur            w0, [x1, #7]
    // 0x129639c: DecompressPointer r0
    //     0x129639c: add             x0, x0, HEAP, lsl #32
    // 0x12963a0: stp             x0, x2, [SP]
    // 0x12963a4: r0 = ==()
    //     0x12963a4: bl              #0x1278854  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0x12963a8: b               #0x12963b0
    // 0x12963ac: r0 = false
    //     0x12963ac: add             x0, NULL, #0x30  ; false
    // 0x12963b0: LeaveFrame
    //     0x12963b0: mov             SP, fp
    //     0x12963b4: ldp             fp, lr, [SP], #0x10
    // 0x12963b8: ret
    //     0x12963b8: ret             
    // 0x12963bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12963bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12963c0: b               #0x1296314
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x12ec6f4, size: 0xa0
    // 0x12ec6f4: EnterFrame
    //     0x12ec6f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12ec6f8: mov             fp, SP
    // 0x12ec6fc: AllocStack(0x28)
    //     0x12ec6fc: sub             SP, SP, #0x28
    // 0x12ec700: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0x12ec700: mov             x0, x3
    //     0x12ec704: stur            x3, [fp, #-0x10]
    //     0x12ec708: mov             x3, x5
    //     0x12ec70c: stur            x2, [fp, #-8]
    //     0x12ec710: stur            x5, [fp, #-0x18]
    // 0x12ec714: CheckStackOverflow
    //     0x12ec714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ec718: cmp             SP, x16
    //     0x12ec71c: b.ls            #0x12ec78c
    // 0x12ec720: mov             x1, x0
    // 0x12ec724: r0 = shortestSide()
    //     0x12ec724: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12ec728: mov             v1.16b, v0.16b
    // 0x12ec72c: d0 = 2.000000
    //     0x12ec72c: fmov            d0, #2.00000000
    // 0x12ec730: fdiv            d2, d1, d0
    // 0x12ec734: stur            d2, [fp, #-0x28]
    // 0x12ec738: r0 = Radius()
    //     0x12ec738: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ec73c: ldur            d0, [fp, #-0x28]
    // 0x12ec740: stur            x0, [fp, #-0x20]
    // 0x12ec744: StoreField: r0->field_7 = d0
    //     0x12ec744: stur            d0, [x0, #7]
    // 0x12ec748: StoreField: r0->field_f = d0
    //     0x12ec748: stur            d0, [x0, #0xf]
    // 0x12ec74c: r1 = <RRect>
    //     0x12ec74c: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12ec750: ldr             x1, [x1, #0x108]
    // 0x12ec754: r0 = RRect()
    //     0x12ec754: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12ec758: mov             x1, x0
    // 0x12ec75c: ldur            x2, [fp, #-0x10]
    // 0x12ec760: ldur            x3, [fp, #-0x20]
    // 0x12ec764: stur            x0, [fp, #-0x10]
    // 0x12ec768: r0 = RRect.fromRectAndRadius()
    //     0x12ec768: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x12ec76c: ldur            x1, [fp, #-8]
    // 0x12ec770: ldur            x2, [fp, #-0x10]
    // 0x12ec774: ldur            x3, [fp, #-0x18]
    // 0x12ec778: r0 = drawRRect()
    //     0x12ec778: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ec77c: r0 = Null
    //     0x12ec77c: mov             x0, NULL
    // 0x12ec780: LeaveFrame
    //     0x12ec780: mov             SP, fp
    //     0x12ec784: ldp             fp, lr, [SP], #0x10
    // 0x12ec788: ret
    //     0x12ec788: ret             
    // 0x12ec78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ec78c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ec790: b               #0x12ec720
  }
  _ paint(/* No info */) {
    // ** addr: 0x12ed8b4, size: 0xe8
    // 0x12ed8b4: EnterFrame
    //     0x12ed8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x12ed8b8: mov             fp, SP
    // 0x12ed8bc: AllocStack(0x28)
    //     0x12ed8bc: sub             SP, SP, #0x28
    // 0x12ed8c0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x12ed8c0: mov             x0, x3
    //     0x12ed8c4: stur            x2, [fp, #-0x10]
    //     0x12ed8c8: stur            x3, [fp, #-0x18]
    // 0x12ed8cc: CheckStackOverflow
    //     0x12ed8cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ed8d0: cmp             SP, x16
    //     0x12ed8d4: b.ls            #0x12ed994
    // 0x12ed8d8: LoadField: r3 = r1->field_7
    //     0x12ed8d8: ldur            w3, [x1, #7]
    // 0x12ed8dc: DecompressPointer r3
    //     0x12ed8dc: add             x3, x3, HEAP, lsl #32
    // 0x12ed8e0: stur            x3, [fp, #-8]
    // 0x12ed8e4: LoadField: r1 = r3->field_13
    //     0x12ed8e4: ldur            w1, [x3, #0x13]
    // 0x12ed8e8: DecompressPointer r1
    //     0x12ed8e8: add             x1, x1, HEAP, lsl #32
    // 0x12ed8ec: LoadField: r4 = r1->field_7
    //     0x12ed8ec: ldur            x4, [x1, #7]
    // 0x12ed8f0: cmp             x4, #0
    // 0x12ed8f4: b.le            #0x12ed984
    // 0x12ed8f8: mov             x1, x0
    // 0x12ed8fc: r0 = shortestSide()
    //     0x12ed8fc: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x12ed900: mov             v1.16b, v0.16b
    // 0x12ed904: d0 = 2.000000
    //     0x12ed904: fmov            d0, #2.00000000
    // 0x12ed908: fdiv            d2, d1, d0
    // 0x12ed90c: stur            d2, [fp, #-0x28]
    // 0x12ed910: r0 = Radius()
    //     0x12ed910: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x12ed914: ldur            d0, [fp, #-0x28]
    // 0x12ed918: stur            x0, [fp, #-0x20]
    // 0x12ed91c: StoreField: r0->field_7 = d0
    //     0x12ed91c: stur            d0, [x0, #7]
    // 0x12ed920: StoreField: r0->field_f = d0
    //     0x12ed920: stur            d0, [x0, #0xf]
    // 0x12ed924: r1 = <RRect>
    //     0x12ed924: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12ed928: ldr             x1, [x1, #0x108]
    // 0x12ed92c: r0 = RRect()
    //     0x12ed92c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12ed930: mov             x1, x0
    // 0x12ed934: ldur            x2, [fp, #-0x18]
    // 0x12ed938: ldur            x3, [fp, #-0x20]
    // 0x12ed93c: stur            x0, [fp, #-0x18]
    // 0x12ed940: r0 = RRect.fromRectAndRadius()
    //     0x12ed940: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x12ed944: ldur            x0, [fp, #-8]
    // 0x12ed948: LoadField: d0 = r0->field_b
    //     0x12ed948: ldur            d0, [x0, #0xb]
    // 0x12ed94c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x12ed94c: ldur            d1, [x0, #0x17]
    // 0x12ed950: fmul            d2, d0, d1
    // 0x12ed954: d0 = 2.000000
    //     0x12ed954: fmov            d0, #2.00000000
    // 0x12ed958: fdiv            d1, d2, d0
    // 0x12ed95c: ldur            x1, [fp, #-0x18]
    // 0x12ed960: mov             v0.16b, v1.16b
    // 0x12ed964: r0 = inflate()
    //     0x12ed964: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0x12ed968: ldur            x1, [fp, #-8]
    // 0x12ed96c: stur            x0, [fp, #-8]
    // 0x12ed970: r0 = toPaint()
    //     0x12ed970: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12ed974: ldur            x1, [fp, #-0x10]
    // 0x12ed978: ldur            x2, [fp, #-8]
    // 0x12ed97c: mov             x3, x0
    // 0x12ed980: r0 = drawRRect()
    //     0x12ed980: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12ed984: r0 = Null
    //     0x12ed984: mov             x0, NULL
    // 0x12ed988: LeaveFrame
    //     0x12ed988: mov             SP, fp
    //     0x12ed98c: ldp             fp, lr, [SP], #0x10
    // 0x12ed990: ret
    //     0x12ed990: ret             
    // 0x12ed994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ed994: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ed998: b               #0x12ed8d8
  }
  _ scale(/* No info */) {
    // ** addr: 0x12fccf0, size: 0x4c
    // 0x12fccf0: EnterFrame
    //     0x12fccf0: stp             fp, lr, [SP, #-0x10]!
    //     0x12fccf4: mov             fp, SP
    // 0x12fccf8: AllocStack(0x8)
    //     0x12fccf8: sub             SP, SP, #8
    // 0x12fccfc: CheckStackOverflow
    //     0x12fccfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcd00: cmp             SP, x16
    //     0x12fcd04: b.ls            #0x12fcd34
    // 0x12fcd08: LoadField: r0 = r1->field_7
    //     0x12fcd08: ldur            w0, [x1, #7]
    // 0x12fcd0c: DecompressPointer r0
    //     0x12fcd0c: add             x0, x0, HEAP, lsl #32
    // 0x12fcd10: mov             x1, x0
    // 0x12fcd14: r0 = scale()
    //     0x12fcd14: bl              #0x12fc608  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0x12fcd18: stur            x0, [fp, #-8]
    // 0x12fcd1c: r0 = StadiumBorder()
    //     0x12fcd1c: bl              #0x10ede04  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x12fcd20: ldur            x1, [fp, #-8]
    // 0x12fcd24: StoreField: r0->field_7 = r1
    //     0x12fcd24: stur            w1, [x0, #7]
    // 0x12fcd28: LeaveFrame
    //     0x12fcd28: mov             SP, fp
    //     0x12fcd2c: ldp             fp, lr, [SP], #0x10
    // 0x12fcd30: ret
    //     0x12fcd30: ret             
    // 0x12fcd34: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fcd34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fcd38: b               #0x12fcd08
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0x1300504, size: 0x198
    // 0x1300504: EnterFrame
    //     0x1300504: stp             fp, lr, [SP, #-0x10]!
    //     0x1300508: mov             fp, SP
    // 0x130050c: AllocStack(0x30)
    //     0x130050c: sub             SP, SP, #0x30
    // 0x1300510: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x1300510: mov             x0, x2
    //     0x1300514: stur            x2, [fp, #-8]
    // 0x1300518: CheckStackOverflow
    //     0x1300518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130051c: cmp             SP, x16
    //     0x1300520: b.ls            #0x1300690
    // 0x1300524: mov             x1, x0
    // 0x1300528: r0 = shortestSide()
    //     0x1300528: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0x130052c: mov             v1.16b, v0.16b
    // 0x1300530: d0 = 2.000000
    //     0x1300530: fmov            d0, #2.00000000
    // 0x1300534: fdiv            d2, d1, d0
    // 0x1300538: stur            d2, [fp, #-0x28]
    // 0x130053c: r0 = Radius()
    //     0x130053c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x1300540: ldur            d0, [fp, #-0x28]
    // 0x1300544: stur            x0, [fp, #-0x10]
    // 0x1300548: StoreField: r0->field_7 = d0
    //     0x1300548: stur            d0, [x0, #7]
    // 0x130054c: StoreField: r0->field_f = d0
    //     0x130054c: stur            d0, [x0, #0xf]
    // 0x1300550: r0 = _NativePath()
    //     0x1300550: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1300554: mov             x1, x0
    // 0x1300558: stur            x0, [fp, #-0x18]
    // 0x130055c: r0 = __constructor$Method$FfiNative()
    //     0x130055c: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1300560: r1 = <RRect>
    //     0x1300560: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x1300564: ldr             x1, [x1, #0x108]
    // 0x1300568: r0 = RRect()
    //     0x1300568: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x130056c: mov             x1, x0
    // 0x1300570: ldur            x2, [fp, #-8]
    // 0x1300574: ldur            x3, [fp, #-0x10]
    // 0x1300578: stur            x0, [fp, #-8]
    // 0x130057c: r0 = RRect.fromRectAndRadius()
    //     0x130057c: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x1300580: ldur            x0, [fp, #-8]
    // 0x1300584: LoadField: d0 = r0->field_b
    //     0x1300584: ldur            d0, [x0, #0xb]
    // 0x1300588: fcvt            s1, d0
    // 0x130058c: stur            d1, [fp, #-0x28]
    // 0x1300590: r4 = 24
    //     0x1300590: mov             x4, #0x18
    // 0x1300594: r0 = AllocateFloat32Array()
    //     0x1300594: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x1300598: ldur            d0, [fp, #-0x28]
    // 0x130059c: stur            x0, [fp, #-0x10]
    // 0x13005a0: ArrayStore: r0[0] = d0  ; List_8
    //     0x13005a0: stur            s0, [x0, #0x17]
    // 0x13005a4: ldur            x1, [fp, #-8]
    // 0x13005a8: LoadField: d0 = r1->field_13
    //     0x13005a8: ldur            d0, [x1, #0x13]
    // 0x13005ac: fcvt            s1, d0
    // 0x13005b0: StoreField: r0->field_1b = d1
    //     0x13005b0: stur            s1, [x0, #0x1b]
    // 0x13005b4: LoadField: d0 = r1->field_1b
    //     0x13005b4: ldur            d0, [x1, #0x1b]
    // 0x13005b8: fcvt            s1, d0
    // 0x13005bc: StoreField: r0->field_1f = d1
    //     0x13005bc: stur            s1, [x0, #0x1f]
    // 0x13005c0: LoadField: d0 = r1->field_23
    //     0x13005c0: ldur            d0, [x1, #0x23]
    // 0x13005c4: fcvt            s1, d0
    // 0x13005c8: StoreField: r0->field_23 = d1
    //     0x13005c8: stur            s1, [x0, #0x23]
    // 0x13005cc: LoadField: d0 = r1->field_2b
    //     0x13005cc: ldur            d0, [x1, #0x2b]
    // 0x13005d0: fcvt            s1, d0
    // 0x13005d4: StoreField: r0->field_27 = d1
    //     0x13005d4: stur            s1, [x0, #0x27]
    // 0x13005d8: LoadField: d0 = r1->field_33
    //     0x13005d8: ldur            d0, [x1, #0x33]
    // 0x13005dc: fcvt            s1, d0
    // 0x13005e0: StoreField: r0->field_2b = d1
    //     0x13005e0: stur            s1, [x0, #0x2b]
    // 0x13005e4: LoadField: d0 = r1->field_3b
    //     0x13005e4: ldur            d0, [x1, #0x3b]
    // 0x13005e8: fcvt            s1, d0
    // 0x13005ec: StoreField: r0->field_2f = d1
    //     0x13005ec: stur            s1, [x0, #0x2f]
    // 0x13005f0: LoadField: d0 = r1->field_43
    //     0x13005f0: ldur            d0, [x1, #0x43]
    // 0x13005f4: fcvt            s1, d0
    // 0x13005f8: StoreField: r0->field_33 = d1
    //     0x13005f8: stur            s1, [x0, #0x33]
    // 0x13005fc: LoadField: d0 = r1->field_4b
    //     0x13005fc: ldur            d0, [x1, #0x4b]
    // 0x1300600: fcvt            s1, d0
    // 0x1300604: StoreField: r0->field_37 = d1
    //     0x1300604: stur            s1, [x0, #0x37]
    // 0x1300608: LoadField: d0 = r1->field_53
    //     0x1300608: ldur            d0, [x1, #0x53]
    // 0x130060c: fcvt            s1, d0
    // 0x1300610: StoreField: r0->field_3b = d1
    //     0x1300610: stur            s1, [x0, #0x3b]
    // 0x1300614: LoadField: d0 = r1->field_5b
    //     0x1300614: ldur            d0, [x1, #0x5b]
    // 0x1300618: fcvt            s1, d0
    // 0x130061c: StoreField: r0->field_3f = d1
    //     0x130061c: stur            s1, [x0, #0x3f]
    // 0x1300620: LoadField: d0 = r1->field_63
    //     0x1300620: ldur            d0, [x1, #0x63]
    // 0x1300624: fcvt            s1, d0
    // 0x1300628: StoreField: r0->field_43 = d1
    //     0x1300628: stur            s1, [x0, #0x43]
    // 0x130062c: ldur            x2, [fp, #-0x18]
    // 0x1300630: LoadField: r1 = r2->field_7
    //     0x1300630: ldur            w1, [x2, #7]
    // 0x1300634: DecompressPointer r1
    //     0x1300634: add             x1, x1, HEAP, lsl #32
    // 0x1300638: cmp             w1, NULL
    // 0x130063c: b.eq            #0x1300698
    // 0x1300640: LoadField: r3 = r1->field_7
    //     0x1300640: ldur            x3, [x1, #7]
    // 0x1300644: ldr             x1, [x3]
    // 0x1300648: cbz             x1, #0x1300680
    // 0x130064c: mov             x3, x1
    // 0x1300650: stur            x3, [fp, #-0x20]
    // 0x1300654: r1 = <Never>
    //     0x1300654: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1300658: r0 = Pointer()
    //     0x1300658: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x130065c: mov             x1, x0
    // 0x1300660: ldur            x0, [fp, #-0x20]
    // 0x1300664: StoreField: r1->field_7 = r0
    //     0x1300664: stur            x0, [x1, #7]
    // 0x1300668: ldur            x2, [fp, #-0x10]
    // 0x130066c: r0 = __addRRect$Method$FfiNative()
    //     0x130066c: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x1300670: ldur            x0, [fp, #-0x18]
    // 0x1300674: LeaveFrame
    //     0x1300674: mov             SP, fp
    //     0x1300678: ldp             fp, lr, [SP], #0x10
    // 0x130067c: ret
    //     0x130067c: ret             
    // 0x1300680: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1300680: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1300684: str             x16, [SP]
    // 0x1300688: r0 = _throwNew()
    //     0x1300688: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x130068c: brk             #0
    // 0x1300690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1300690: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1300694: b               #0x1300524
    // 0x1300698: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1300698: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x1301a8c, size: 0x40
    // 0x1301a8c: EnterFrame
    //     0x1301a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301a90: mov             fp, SP
    // 0x1301a94: AllocStack(0x8)
    //     0x1301a94: sub             SP, SP, #8
    // 0x1301a98: cmp             w2, NULL
    // 0x1301a9c: b.ne            #0x1301aac
    // 0x1301aa0: LoadField: r0 = r1->field_7
    //     0x1301aa0: ldur            w0, [x1, #7]
    // 0x1301aa4: DecompressPointer r0
    //     0x1301aa4: add             x0, x0, HEAP, lsl #32
    // 0x1301aa8: b               #0x1301ab0
    // 0x1301aac: mov             x0, x2
    // 0x1301ab0: stur            x0, [fp, #-8]
    // 0x1301ab4: r0 = StadiumBorder()
    //     0x1301ab4: bl              #0x10ede04  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x1301ab8: ldur            x1, [fp, #-8]
    // 0x1301abc: StoreField: r0->field_7 = r1
    //     0x1301abc: stur            w1, [x0, #7]
    // 0x1301ac0: LeaveFrame
    //     0x1301ac0: mov             SP, fp
    //     0x1301ac4: ldp             fp, lr, [SP], #0x10
    // 0x1301ac8: ret
    //     0x1301ac8: ret             
  }
}
