// lib: , url: package:flutter/src/painting/geometry.dart

// class id: 1048995, size: 0x8
class :: {

  static _ positionDependentBox(/* No info */) {
    // ** addr: 0xd4b344, size: 0xfc
    // 0xd4b344: EnterFrame
    //     0xd4b344: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b348: mov             fp, SP
    // 0xd4b34c: AllocStack(0x10)
    //     0xd4b34c: sub             SP, SP, #0x10
    // 0xd4b350: d1 = 10.000000
    //     0xd4b350: fmov            d1, #10.00000000
    // 0xd4b354: LoadField: d2 = r3->field_f
    //     0xd4b354: ldur            d2, [x3, #0xf]
    // 0xd4b358: fadd            d3, d2, d0
    // 0xd4b35c: LoadField: d4 = r1->field_f
    //     0xd4b35c: ldur            d4, [x1, #0xf]
    // 0xd4b360: fadd            d5, d3, d4
    // 0xd4b364: LoadField: d6 = r2->field_f
    //     0xd4b364: ldur            d6, [x2, #0xf]
    // 0xd4b368: fsub            d7, d6, d1
    // 0xd4b36c: fcmp            d7, d5
    // 0xd4b370: r16 = true
    //     0xd4b370: add             x16, NULL, #0x20  ; true
    // 0xd4b374: r17 = false
    //     0xd4b374: add             x17, NULL, #0x30  ; false
    // 0xd4b378: csel            x0, x16, x17, ge
    // 0xd4b37c: fsub            d5, d2, d0
    // 0xd4b380: fsub            d0, d5, d4
    // 0xd4b384: fcmp            d0, d1
    // 0xd4b388: r16 = true
    //     0xd4b388: add             x16, NULL, #0x20  ; true
    // 0xd4b38c: r17 = false
    //     0xd4b38c: add             x17, NULL, #0x30  ; false
    // 0xd4b390: csel            x4, x16, x17, ge
    // 0xd4b394: cmp             w4, w0
    // 0xd4b398: b.eq            #0xd4b3a0
    // 0xd4b39c: tbnz            w0, #4, #0xd4b3ac
    // 0xd4b3a0: fmin            v0.2d, v3.2d, v7.2d
    // 0xd4b3a4: mov             v2.16b, v0.16b
    // 0xd4b3a8: b               #0xd4b3b0
    // 0xd4b3ac: fmax            v2.2d, v0.2d, v1.2d
    // 0xd4b3b0: d0 = 20.000000
    //     0xd4b3b0: fmov            d0, #20.00000000
    // 0xd4b3b4: stur            d2, [fp, #-0x10]
    // 0xd4b3b8: LoadField: d3 = r2->field_7
    //     0xd4b3b8: ldur            d3, [x2, #7]
    // 0xd4b3bc: LoadField: d4 = r1->field_7
    //     0xd4b3bc: ldur            d4, [x1, #7]
    // 0xd4b3c0: fsub            d5, d3, d4
    // 0xd4b3c4: fcmp            d0, d5
    // 0xd4b3c8: b.lt            #0xd4b3dc
    // 0xd4b3cc: d0 = 2.000000
    //     0xd4b3cc: fmov            d0, #2.00000000
    // 0xd4b3d0: fdiv            d1, d5, d0
    // 0xd4b3d4: mov             v0.16b, v1.16b
    // 0xd4b3d8: b               #0xd4b41c
    // 0xd4b3dc: d0 = 2.000000
    //     0xd4b3dc: fmov            d0, #2.00000000
    // 0xd4b3e0: LoadField: d3 = r3->field_7
    //     0xd4b3e0: ldur            d3, [x3, #7]
    // 0xd4b3e4: fdiv            d6, d4, d0
    // 0xd4b3e8: fsub            d0, d3, d6
    // 0xd4b3ec: fsub            d3, d5, d1
    // 0xd4b3f0: fcmp            d1, d0
    // 0xd4b3f4: b.le            #0xd4b400
    // 0xd4b3f8: d0 = 10.000000
    //     0xd4b3f8: fmov            d0, #10.00000000
    // 0xd4b3fc: b               #0xd4b41c
    // 0xd4b400: fcmp            d0, d3
    // 0xd4b404: b.le            #0xd4b410
    // 0xd4b408: mov             v0.16b, v3.16b
    // 0xd4b40c: b               #0xd4b41c
    // 0xd4b410: fcmp            d0, d0
    // 0xd4b414: b.vc            #0xd4b41c
    // 0xd4b418: mov             v0.16b, v3.16b
    // 0xd4b41c: stur            d0, [fp, #-8]
    // 0xd4b420: r0 = Offset()
    //     0xd4b420: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd4b424: ldur            d0, [fp, #-8]
    // 0xd4b428: StoreField: r0->field_7 = d0
    //     0xd4b428: stur            d0, [x0, #7]
    // 0xd4b42c: ldur            d0, [fp, #-0x10]
    // 0xd4b430: StoreField: r0->field_f = d0
    //     0xd4b430: stur            d0, [x0, #0xf]
    // 0xd4b434: LeaveFrame
    //     0xd4b434: mov             SP, fp
    //     0xd4b438: ldp             fp, lr, [SP], #0x10
    // 0xd4b43c: ret
    //     0xd4b43c: ret             
  }
}
