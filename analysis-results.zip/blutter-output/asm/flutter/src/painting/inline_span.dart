// lib: , url: package:flutter/src/painting/inline_span.dart

// class id: 1049001, size: 0x8
class :: {

  static _ combineSemanticsInfo(/* No info */) {
    // ** addr: 0xbfa964, size: 0x570
    // 0xbfa964: EnterFrame
    //     0xbfa964: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa968: mov             fp, SP
    // 0xbfa96c: AllocStack(0x88)
    //     0xbfa96c: sub             SP, SP, #0x88
    // 0xbfa970: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xbfa970: mov             x0, x1
    //     0xbfa974: stur            x1, [fp, #-8]
    // 0xbfa978: CheckStackOverflow
    //     0xbfa978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa97c: cmp             SP, x16
    //     0xbfa980: b.ls            #0xbfaebc
    // 0xbfa984: r1 = <InlineSpanSemanticsInformation>
    //     0xbfa984: add             x1, PP, #0x98, lsl #12  ; [pp+0x988c8] TypeArguments: <InlineSpanSemanticsInformation>
    //     0xbfa988: ldr             x1, [x1, #0x8c8]
    // 0xbfa98c: r2 = 0
    //     0xbfa98c: mov             x2, #0
    // 0xbfa990: r0 = _GrowableList()
    //     0xbfa990: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbfa994: r1 = <StringAttribute>
    //     0xbfa994: ldr             x1, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0xbfa998: r2 = 0
    //     0xbfa998: mov             x2, #0
    // 0xbfa99c: stur            x0, [fp, #-0x10]
    // 0xbfa9a0: r0 = _GrowableList()
    //     0xbfa9a0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbfa9a4: mov             x1, x0
    // 0xbfa9a8: ldur            x0, [fp, #-8]
    // 0xbfa9ac: LoadField: r2 = r0->field_b
    //     0xbfa9ac: ldur            w2, [x0, #0xb]
    // 0xbfa9b0: r3 = LoadInt32Instr(r2)
    //     0xbfa9b0: sbfx            x3, x2, #1, #0x1f
    // 0xbfa9b4: stur            x3, [fp, #-0x40]
    // 0xbfa9b8: mov             x4, x1
    // 0xbfa9bc: r6 = ""
    //     0xbfa9bc: ldr             x6, [PP, #0x900]  ; [pp+0x900] ""
    // 0xbfa9c0: r5 = ""
    //     0xbfa9c0: ldr             x5, [PP, #0x900]  ; [pp+0x900] ""
    // 0xbfa9c4: r2 = 0
    //     0xbfa9c4: mov             x2, #0
    // 0xbfa9c8: ldur            x1, [fp, #-0x10]
    // 0xbfa9cc: stur            x6, [fp, #-0x28]
    // 0xbfa9d0: stur            x5, [fp, #-0x30]
    // 0xbfa9d4: stur            x4, [fp, #-0x38]
    // 0xbfa9d8: CheckStackOverflow
    //     0xbfa9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa9dc: cmp             SP, x16
    //     0xbfa9e0: b.ls            #0xbfaec4
    // 0xbfa9e4: LoadField: r7 = r0->field_b
    //     0xbfa9e4: ldur            w7, [x0, #0xb]
    // 0xbfa9e8: r8 = LoadInt32Instr(r7)
    //     0xbfa9e8: sbfx            x8, x7, #1, #0x1f
    // 0xbfa9ec: cmp             x3, x8
    // 0xbfa9f0: b.ne            #0xbfaea0
    // 0xbfa9f4: cmp             x2, x8
    // 0xbfa9f8: b.ge            #0xbfadd8
    // 0xbfa9fc: LoadField: r7 = r0->field_f
    //     0xbfa9fc: ldur            w7, [x0, #0xf]
    // 0xbfaa00: DecompressPointer r7
    //     0xbfaa00: add             x7, x7, HEAP, lsl #32
    // 0xbfaa04: ArrayLoad: r8 = r7[r2]  ; Unknown_4
    //     0xbfaa04: add             x16, x7, x2, lsl #2
    //     0xbfaa08: ldur            w8, [x16, #0xf]
    // 0xbfaa0c: DecompressPointer r8
    //     0xbfaa0c: add             x8, x8, HEAP, lsl #32
    // 0xbfaa10: stur            x8, [fp, #-0x20]
    // 0xbfaa14: add             x7, x2, #1
    // 0xbfaa18: stur            x7, [fp, #-0x18]
    // 0xbfaa1c: LoadField: r2 = r8->field_1b
    //     0xbfaa1c: ldur            w2, [x8, #0x1b]
    // 0xbfaa20: DecompressPointer r2
    //     0xbfaa20: add             x2, x2, HEAP, lsl #32
    // 0xbfaa24: tbnz            w2, #4, #0xbfab70
    // 0xbfaa28: r0 = InlineSpanSemanticsInformation()
    //     0xbfaa28: bl              #0xbfaed4  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x24)
    // 0xbfaa2c: mov             x2, x0
    // 0xbfaa30: ldur            x0, [fp, #-0x28]
    // 0xbfaa34: stur            x2, [fp, #-0x50]
    // 0xbfaa38: StoreField: r2->field_7 = r0
    //     0xbfaa38: stur            w0, [x2, #7]
    // 0xbfaa3c: r0 = false
    //     0xbfaa3c: add             x0, NULL, #0x30  ; false
    // 0xbfaa40: ArrayStore: r2[0] = r0  ; List_4
    //     0xbfaa40: stur            w0, [x2, #0x17]
    // 0xbfaa44: ldur            x1, [fp, #-0x30]
    // 0xbfaa48: StoreField: r2->field_b = r1
    //     0xbfaa48: stur            w1, [x2, #0xb]
    // 0xbfaa4c: ldur            x3, [fp, #-0x38]
    // 0xbfaa50: StoreField: r2->field_1f = r3
    //     0xbfaa50: stur            w3, [x2, #0x1f]
    // 0xbfaa54: StoreField: r2->field_1b = r0
    //     0xbfaa54: stur            w0, [x2, #0x1b]
    // 0xbfaa58: ldur            x3, [fp, #-0x10]
    // 0xbfaa5c: LoadField: r1 = r3->field_b
    //     0xbfaa5c: ldur            w1, [x3, #0xb]
    // 0xbfaa60: LoadField: r4 = r3->field_f
    //     0xbfaa60: ldur            w4, [x3, #0xf]
    // 0xbfaa64: DecompressPointer r4
    //     0xbfaa64: add             x4, x4, HEAP, lsl #32
    // 0xbfaa68: LoadField: r5 = r4->field_b
    //     0xbfaa68: ldur            w5, [x4, #0xb]
    // 0xbfaa6c: r4 = LoadInt32Instr(r1)
    //     0xbfaa6c: sbfx            x4, x1, #1, #0x1f
    // 0xbfaa70: stur            x4, [fp, #-0x48]
    // 0xbfaa74: r1 = LoadInt32Instr(r5)
    //     0xbfaa74: sbfx            x1, x5, #1, #0x1f
    // 0xbfaa78: cmp             x4, x1
    // 0xbfaa7c: b.ne            #0xbfaa88
    // 0xbfaa80: mov             x1, x3
    // 0xbfaa84: r0 = _growToNextCapacity()
    //     0xbfaa84: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfaa88: ldur            x2, [fp, #-0x10]
    // 0xbfaa8c: ldur            x3, [fp, #-0x48]
    // 0xbfaa90: add             x4, x3, #1
    // 0xbfaa94: stur            x4, [fp, #-0x60]
    // 0xbfaa98: lsl             x0, x4, #1
    // 0xbfaa9c: StoreField: r2->field_b = r0
    //     0xbfaa9c: stur            w0, [x2, #0xb]
    // 0xbfaaa0: LoadField: r5 = r2->field_f
    //     0xbfaaa0: ldur            w5, [x2, #0xf]
    // 0xbfaaa4: DecompressPointer r5
    //     0xbfaaa4: add             x5, x5, HEAP, lsl #32
    // 0xbfaaa8: mov             x1, x5
    // 0xbfaaac: ldur            x0, [fp, #-0x50]
    // 0xbfaab0: stur            x5, [fp, #-0x58]
    // 0xbfaab4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbfaab4: add             x25, x1, x3, lsl #2
    //     0xbfaab8: add             x25, x25, #0xf
    //     0xbfaabc: str             w0, [x25]
    //     0xbfaac0: tbz             w0, #0, #0xbfaadc
    //     0xbfaac4: ldurb           w16, [x1, #-1]
    //     0xbfaac8: ldurb           w17, [x0, #-1]
    //     0xbfaacc: and             x16, x17, x16, lsr #2
    //     0xbfaad0: tst             x16, HEAP, lsr #32
    //     0xbfaad4: b.eq            #0xbfaadc
    //     0xbfaad8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfaadc: r1 = <StringAttribute>
    //     0xbfaadc: ldr             x1, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0xbfaae0: r0 = AllocateGrowableArray()
    //     0xbfaae0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xbfaae4: mov             x2, x0
    // 0xbfaae8: r0 = const []
    //     0xbfaae8: ldr             x0, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0xbfaaec: stur            x2, [fp, #-0x50]
    // 0xbfaaf0: StoreField: r2->field_f = r0
    //     0xbfaaf0: stur            w0, [x2, #0xf]
    // 0xbfaaf4: StoreField: r2->field_b = rZR
    //     0xbfaaf4: stur            wzr, [x2, #0xb]
    // 0xbfaaf8: ldur            x1, [fp, #-0x58]
    // 0xbfaafc: LoadField: r3 = r1->field_b
    //     0xbfaafc: ldur            w3, [x1, #0xb]
    // 0xbfab00: r1 = LoadInt32Instr(r3)
    //     0xbfab00: sbfx            x1, x3, #1, #0x1f
    // 0xbfab04: ldur            x3, [fp, #-0x60]
    // 0xbfab08: cmp             x3, x1
    // 0xbfab0c: b.ne            #0xbfab18
    // 0xbfab10: ldur            x1, [fp, #-0x10]
    // 0xbfab14: r0 = _growToNextCapacity()
    //     0xbfab14: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfab18: ldur            x4, [fp, #-0x10]
    // 0xbfab1c: ldur            x2, [fp, #-0x60]
    // 0xbfab20: add             x0, x2, #1
    // 0xbfab24: lsl             x1, x0, #1
    // 0xbfab28: StoreField: r4->field_b = r1
    //     0xbfab28: stur            w1, [x4, #0xb]
    // 0xbfab2c: LoadField: r1 = r4->field_f
    //     0xbfab2c: ldur            w1, [x4, #0xf]
    // 0xbfab30: DecompressPointer r1
    //     0xbfab30: add             x1, x1, HEAP, lsl #32
    // 0xbfab34: ldur            x0, [fp, #-0x20]
    // 0xbfab38: ArrayStore: r1[r2] = r0  ; List_4
    //     0xbfab38: add             x25, x1, x2, lsl #2
    //     0xbfab3c: add             x25, x25, #0xf
    //     0xbfab40: str             w0, [x25]
    //     0xbfab44: tbz             w0, #0, #0xbfab60
    //     0xbfab48: ldurb           w16, [x1, #-1]
    //     0xbfab4c: ldurb           w17, [x0, #-1]
    //     0xbfab50: and             x16, x17, x16, lsr #2
    //     0xbfab54: tst             x16, HEAP, lsr #32
    //     0xbfab58: b.eq            #0xbfab60
    //     0xbfab5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfab60: ldur            x4, [fp, #-0x50]
    // 0xbfab64: r6 = ""
    //     0xbfab64: ldr             x6, [PP, #0x900]  ; [pp+0x900] ""
    // 0xbfab68: r5 = ""
    //     0xbfab68: ldr             x5, [PP, #0x900]  ; [pp+0x900] ""
    // 0xbfab6c: b               #0xbfadc8
    // 0xbfab70: mov             x3, x4
    // 0xbfab74: mov             x4, x1
    // 0xbfab78: mov             x0, x6
    // 0xbfab7c: mov             x1, x5
    // 0xbfab80: mov             x2, x8
    // 0xbfab84: LoadField: r5 = r2->field_7
    //     0xbfab84: ldur            w5, [x2, #7]
    // 0xbfab88: DecompressPointer r5
    //     0xbfab88: add             x5, x5, HEAP, lsl #32
    // 0xbfab8c: stur            x5, [fp, #-0x50]
    // 0xbfab90: stp             x5, x0, [SP]
    // 0xbfab94: r0 = +()
    //     0xbfab94: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0xbfab98: mov             x2, x0
    // 0xbfab9c: ldur            x0, [fp, #-0x20]
    // 0xbfaba0: stur            x2, [fp, #-0x58]
    // 0xbfaba4: LoadField: r1 = r0->field_b
    //     0xbfaba4: ldur            w1, [x0, #0xb]
    // 0xbfaba8: DecompressPointer r1
    //     0xbfaba8: add             x1, x1, HEAP, lsl #32
    // 0xbfabac: cmp             w1, NULL
    // 0xbfabb0: b.ne            #0xbfabbc
    // 0xbfabb4: ldur            x5, [fp, #-0x50]
    // 0xbfabb8: b               #0xbfabc0
    // 0xbfabbc: mov             x5, x1
    // 0xbfabc0: ldur            x3, [fp, #-0x30]
    // 0xbfabc4: ldur            x4, [fp, #-0x38]
    // 0xbfabc8: stur            x5, [fp, #-0x50]
    // 0xbfabcc: LoadField: r1 = r0->field_1f
    //     0xbfabcc: ldur            w1, [x0, #0x1f]
    // 0xbfabd0: DecompressPointer r1
    //     0xbfabd0: add             x1, x1, HEAP, lsl #32
    // 0xbfabd4: r0 = LoadClassIdInstr(r1)
    //     0xbfabd4: ldur            x0, [x1, #-1]
    //     0xbfabd8: ubfx            x0, x0, #0xc, #0x14
    // 0xbfabdc: r0 = GDT[cid_x0 + 0x12641]()
    //     0xbfabdc: mov             x17, #0x2641
    //     0xbfabe0: movk            x17, #1, lsl #16
    //     0xbfabe4: add             lr, x0, x17
    //     0xbfabe8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfabec: blr             lr
    // 0xbfabf0: mov             x3, x0
    // 0xbfabf4: ldur            x2, [fp, #-0x30]
    // 0xbfabf8: stur            x3, [fp, #-0x68]
    // 0xbfabfc: LoadField: r0 = r2->field_7
    //     0xbfabfc: ldur            w0, [x2, #7]
    // 0xbfac00: r4 = LoadInt32Instr(r0)
    //     0xbfac00: sbfx            x4, x0, #1, #0x1f
    // 0xbfac04: ldur            x5, [fp, #-0x38]
    // 0xbfac08: stur            x4, [fp, #-0x48]
    // 0xbfac0c: LoadField: r6 = r5->field_7
    //     0xbfac0c: ldur            w6, [x5, #7]
    // 0xbfac10: DecompressPointer r6
    //     0xbfac10: add             x6, x6, HEAP, lsl #32
    // 0xbfac14: stur            x6, [fp, #-0x20]
    // 0xbfac18: CheckStackOverflow
    //     0xbfac18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfac1c: cmp             SP, x16
    //     0xbfac20: b.ls            #0xbfaecc
    // 0xbfac24: r0 = LoadClassIdInstr(r3)
    //     0xbfac24: ldur            x0, [x3, #-1]
    //     0xbfac28: ubfx            x0, x0, #0xc, #0x14
    // 0xbfac2c: mov             x1, x3
    // 0xbfac30: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xbfac30: mov             x17, #0x845b
    //     0xbfac34: movk            x17, #1, lsl #16
    //     0xbfac38: add             lr, x0, x17
    //     0xbfac3c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfac40: blr             lr
    // 0xbfac44: tbnz            w0, #4, #0xbfada8
    // 0xbfac48: ldur            x4, [fp, #-0x38]
    // 0xbfac4c: ldur            x2, [fp, #-0x68]
    // 0xbfac50: ldur            x3, [fp, #-0x48]
    // 0xbfac54: r0 = LoadClassIdInstr(r2)
    //     0xbfac54: ldur            x0, [x2, #-1]
    //     0xbfac58: ubfx            x0, x0, #0xc, #0x14
    // 0xbfac5c: mov             x1, x2
    // 0xbfac60: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xbfac60: mov             x17, #0x7d4c
    //     0xbfac64: movk            x17, #1, lsl #16
    //     0xbfac68: add             lr, x0, x17
    //     0xbfac6c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfac70: blr             lr
    // 0xbfac74: stur            x0, [fp, #-0x78]
    // 0xbfac78: LoadField: r1 = r0->field_b
    //     0xbfac78: ldur            w1, [x0, #0xb]
    // 0xbfac7c: DecompressPointer r1
    //     0xbfac7c: add             x1, x1, HEAP, lsl #32
    // 0xbfac80: LoadField: r2 = r1->field_7
    //     0xbfac80: ldur            x2, [x1, #7]
    // 0xbfac84: ldur            x3, [fp, #-0x48]
    // 0xbfac88: add             x4, x2, x3
    // 0xbfac8c: stur            x4, [fp, #-0x70]
    // 0xbfac90: LoadField: r2 = r1->field_f
    //     0xbfac90: ldur            x2, [x1, #0xf]
    // 0xbfac94: add             x1, x2, x3
    // 0xbfac98: stur            x1, [fp, #-0x60]
    // 0xbfac9c: r0 = TextRange()
    //     0xbfac9c: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0xbfaca0: mov             x1, x0
    // 0xbfaca4: ldur            x0, [fp, #-0x70]
    // 0xbfaca8: StoreField: r1->field_7 = r0
    //     0xbfaca8: stur            x0, [x1, #7]
    // 0xbfacac: ldur            x0, [fp, #-0x60]
    // 0xbfacb0: StoreField: r1->field_f = r0
    //     0xbfacb0: stur            x0, [x1, #0xf]
    // 0xbfacb4: ldur            x0, [fp, #-0x78]
    // 0xbfacb8: r2 = LoadClassIdInstr(r0)
    //     0xbfacb8: ldur            x2, [x0, #-1]
    //     0xbfacbc: ubfx            x2, x2, #0xc, #0x14
    // 0xbfacc0: mov             x16, x1
    // 0xbfacc4: mov             x1, x2
    // 0xbfacc8: mov             x2, x16
    // 0xbfaccc: mov             x16, x0
    // 0xbfacd0: mov             x0, x1
    // 0xbfacd4: mov             x1, x16
    // 0xbfacd8: r0 = GDT[cid_x0 + -0xfec]()
    //     0xbfacd8: sub             lr, x0, #0xfec
    //     0xbfacdc: ldr             lr, [x21, lr, lsl #3]
    //     0xbface0: blr             lr
    // 0xbface4: ldur            x2, [fp, #-0x20]
    // 0xbface8: mov             x3, x0
    // 0xbfacec: r1 = Null
    //     0xbfacec: mov             x1, NULL
    // 0xbfacf0: stur            x3, [fp, #-0x78]
    // 0xbfacf4: cmp             w2, NULL
    // 0xbfacf8: b.eq            #0xbfad18
    // 0xbfacfc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfacfc: ldur            w4, [x2, #0x17]
    // 0xbfad00: DecompressPointer r4
    //     0xbfad00: add             x4, x4, HEAP, lsl #32
    // 0xbfad04: r8 = X0
    //     0xbfad04: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xbfad08: LoadField: r9 = r4->field_7
    //     0xbfad08: ldur            x9, [x4, #7]
    // 0xbfad0c: r3 = Null
    //     0xbfad0c: add             x3, PP, #0x98, lsl #12  ; [pp+0x988d0] Null
    //     0xbfad10: ldr             x3, [x3, #0x8d0]
    // 0xbfad14: blr             x9
    // 0xbfad18: ldur            x0, [fp, #-0x38]
    // 0xbfad1c: LoadField: r1 = r0->field_b
    //     0xbfad1c: ldur            w1, [x0, #0xb]
    // 0xbfad20: LoadField: r2 = r0->field_f
    //     0xbfad20: ldur            w2, [x0, #0xf]
    // 0xbfad24: DecompressPointer r2
    //     0xbfad24: add             x2, x2, HEAP, lsl #32
    // 0xbfad28: LoadField: r3 = r2->field_b
    //     0xbfad28: ldur            w3, [x2, #0xb]
    // 0xbfad2c: r2 = LoadInt32Instr(r1)
    //     0xbfad2c: sbfx            x2, x1, #1, #0x1f
    // 0xbfad30: stur            x2, [fp, #-0x60]
    // 0xbfad34: r1 = LoadInt32Instr(r3)
    //     0xbfad34: sbfx            x1, x3, #1, #0x1f
    // 0xbfad38: cmp             x2, x1
    // 0xbfad3c: b.ne            #0xbfad48
    // 0xbfad40: mov             x1, x0
    // 0xbfad44: r0 = _growToNextCapacity()
    //     0xbfad44: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfad48: ldur            x2, [fp, #-0x38]
    // 0xbfad4c: ldur            x3, [fp, #-0x60]
    // 0xbfad50: add             x0, x3, #1
    // 0xbfad54: lsl             x1, x0, #1
    // 0xbfad58: StoreField: r2->field_b = r1
    //     0xbfad58: stur            w1, [x2, #0xb]
    // 0xbfad5c: LoadField: r1 = r2->field_f
    //     0xbfad5c: ldur            w1, [x2, #0xf]
    // 0xbfad60: DecompressPointer r1
    //     0xbfad60: add             x1, x1, HEAP, lsl #32
    // 0xbfad64: ldur            x0, [fp, #-0x78]
    // 0xbfad68: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbfad68: add             x25, x1, x3, lsl #2
    //     0xbfad6c: add             x25, x25, #0xf
    //     0xbfad70: str             w0, [x25]
    //     0xbfad74: tbz             w0, #0, #0xbfad90
    //     0xbfad78: ldurb           w16, [x1, #-1]
    //     0xbfad7c: ldurb           w17, [x0, #-1]
    //     0xbfad80: and             x16, x17, x16, lsr #2
    //     0xbfad84: tst             x16, HEAP, lsr #32
    //     0xbfad88: b.eq            #0xbfad90
    //     0xbfad8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfad90: mov             x5, x2
    // 0xbfad94: ldur            x2, [fp, #-0x30]
    // 0xbfad98: ldur            x3, [fp, #-0x68]
    // 0xbfad9c: ldur            x6, [fp, #-0x20]
    // 0xbfada0: ldur            x4, [fp, #-0x48]
    // 0xbfada4: b               #0xbfac18
    // 0xbfada8: ldur            x2, [fp, #-0x38]
    // 0xbfadac: ldur            x16, [fp, #-0x30]
    // 0xbfadb0: ldur            lr, [fp, #-0x50]
    // 0xbfadb4: stp             lr, x16, [SP]
    // 0xbfadb8: r0 = +()
    //     0xbfadb8: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0xbfadbc: ldur            x6, [fp, #-0x58]
    // 0xbfadc0: mov             x5, x0
    // 0xbfadc4: ldur            x4, [fp, #-0x38]
    // 0xbfadc8: ldur            x2, [fp, #-0x18]
    // 0xbfadcc: ldur            x0, [fp, #-8]
    // 0xbfadd0: ldur            x3, [fp, #-0x40]
    // 0xbfadd4: b               #0xbfa9c8
    // 0xbfadd8: mov             x3, x1
    // 0xbfaddc: mov             x0, x6
    // 0xbfade0: mov             x2, x5
    // 0xbfade4: mov             x1, x4
    // 0xbfade8: r0 = InlineSpanSemanticsInformation()
    //     0xbfade8: bl              #0xbfaed4  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x24)
    // 0xbfadec: mov             x2, x0
    // 0xbfadf0: ldur            x0, [fp, #-0x28]
    // 0xbfadf4: stur            x2, [fp, #-0x20]
    // 0xbfadf8: StoreField: r2->field_7 = r0
    //     0xbfadf8: stur            w0, [x2, #7]
    // 0xbfadfc: r0 = false
    //     0xbfadfc: add             x0, NULL, #0x30  ; false
    // 0xbfae00: ArrayStore: r2[0] = r0  ; List_4
    //     0xbfae00: stur            w0, [x2, #0x17]
    // 0xbfae04: ldur            x1, [fp, #-0x30]
    // 0xbfae08: StoreField: r2->field_b = r1
    //     0xbfae08: stur            w1, [x2, #0xb]
    // 0xbfae0c: ldur            x1, [fp, #-0x38]
    // 0xbfae10: StoreField: r2->field_1f = r1
    //     0xbfae10: stur            w1, [x2, #0x1f]
    // 0xbfae14: StoreField: r2->field_1b = r0
    //     0xbfae14: stur            w0, [x2, #0x1b]
    // 0xbfae18: ldur            x0, [fp, #-0x10]
    // 0xbfae1c: LoadField: r1 = r0->field_b
    //     0xbfae1c: ldur            w1, [x0, #0xb]
    // 0xbfae20: LoadField: r3 = r0->field_f
    //     0xbfae20: ldur            w3, [x0, #0xf]
    // 0xbfae24: DecompressPointer r3
    //     0xbfae24: add             x3, x3, HEAP, lsl #32
    // 0xbfae28: LoadField: r4 = r3->field_b
    //     0xbfae28: ldur            w4, [x3, #0xb]
    // 0xbfae2c: r3 = LoadInt32Instr(r1)
    //     0xbfae2c: sbfx            x3, x1, #1, #0x1f
    // 0xbfae30: stur            x3, [fp, #-0x18]
    // 0xbfae34: r1 = LoadInt32Instr(r4)
    //     0xbfae34: sbfx            x1, x4, #1, #0x1f
    // 0xbfae38: cmp             x3, x1
    // 0xbfae3c: b.ne            #0xbfae48
    // 0xbfae40: mov             x1, x0
    // 0xbfae44: r0 = _growToNextCapacity()
    //     0xbfae44: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfae48: ldur            x2, [fp, #-0x10]
    // 0xbfae4c: ldur            x3, [fp, #-0x18]
    // 0xbfae50: add             x0, x3, #1
    // 0xbfae54: lsl             x1, x0, #1
    // 0xbfae58: StoreField: r2->field_b = r1
    //     0xbfae58: stur            w1, [x2, #0xb]
    // 0xbfae5c: LoadField: r1 = r2->field_f
    //     0xbfae5c: ldur            w1, [x2, #0xf]
    // 0xbfae60: DecompressPointer r1
    //     0xbfae60: add             x1, x1, HEAP, lsl #32
    // 0xbfae64: ldur            x0, [fp, #-0x20]
    // 0xbfae68: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbfae68: add             x25, x1, x3, lsl #2
    //     0xbfae6c: add             x25, x25, #0xf
    //     0xbfae70: str             w0, [x25]
    //     0xbfae74: tbz             w0, #0, #0xbfae90
    //     0xbfae78: ldurb           w16, [x1, #-1]
    //     0xbfae7c: ldurb           w17, [x0, #-1]
    //     0xbfae80: and             x16, x17, x16, lsr #2
    //     0xbfae84: tst             x16, HEAP, lsr #32
    //     0xbfae88: b.eq            #0xbfae90
    //     0xbfae8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfae90: mov             x0, x2
    // 0xbfae94: LeaveFrame
    //     0xbfae94: mov             SP, fp
    //     0xbfae98: ldp             fp, lr, [SP], #0x10
    // 0xbfae9c: ret
    //     0xbfae9c: ret             
    // 0xbfaea0: r0 = ConcurrentModificationError()
    //     0xbfaea0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfaea4: mov             x1, x0
    // 0xbfaea8: ldur            x0, [fp, #-8]
    // 0xbfaeac: StoreField: r1->field_b = r0
    //     0xbfaeac: stur            w0, [x1, #0xb]
    // 0xbfaeb0: mov             x0, x1
    // 0xbfaeb4: r0 = Throw()
    //     0xbfaeb4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbfaeb8: brk             #0
    // 0xbfaebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaec0: b               #0xbfa984
    // 0xbfaec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaec8: b               #0xbfa9e4
    // 0xbfaecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfaecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfaed0: b               #0xbfac24
  }
}

// class id: 2918, size: 0x24, field offset: 0x8
//   const constructor, 
class InlineSpanSemanticsInformation extends Object {

  _TwoByteString field_8;
  bool field_18;
  bool field_1c;
  _ImmutableList<StringAttribute> field_20;

  get _ hashCode(/* No info */) {
    // ** addr: 0x114c19c, size: 0x7c
    // 0x114c19c: EnterFrame
    //     0x114c19c: stp             fp, lr, [SP, #-0x10]!
    //     0x114c1a0: mov             fp, SP
    // 0x114c1a4: AllocStack(0x18)
    //     0x114c1a4: sub             SP, SP, #0x18
    // 0x114c1a8: CheckStackOverflow
    //     0x114c1a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c1ac: cmp             SP, x16
    //     0x114c1b0: b.ls            #0x114c210
    // 0x114c1b4: ldr             x0, [fp, #0x10]
    // 0x114c1b8: LoadField: r1 = r0->field_7
    //     0x114c1b8: ldur            w1, [x0, #7]
    // 0x114c1bc: DecompressPointer r1
    //     0x114c1bc: add             x1, x1, HEAP, lsl #32
    // 0x114c1c0: LoadField: r2 = r0->field_b
    //     0x114c1c0: ldur            w2, [x0, #0xb]
    // 0x114c1c4: DecompressPointer r2
    //     0x114c1c4: add             x2, x2, HEAP, lsl #32
    // 0x114c1c8: LoadField: r3 = r0->field_13
    //     0x114c1c8: ldur            w3, [x0, #0x13]
    // 0x114c1cc: DecompressPointer r3
    //     0x114c1cc: add             x3, x3, HEAP, lsl #32
    // 0x114c1d0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x114c1d0: ldur            w4, [x0, #0x17]
    // 0x114c1d4: DecompressPointer r4
    //     0x114c1d4: add             x4, x4, HEAP, lsl #32
    // 0x114c1d8: stp             x3, NULL, [SP, #8]
    // 0x114c1dc: str             x4, [SP]
    // 0x114c1e0: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x114c1e0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x114c1e4: ldr             x4, [x4, #0xc80]
    // 0x114c1e8: r0 = hash()
    //     0x114c1e8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c1ec: mov             x2, x0
    // 0x114c1f0: r0 = BoxInt64Instr(r2)
    //     0x114c1f0: sbfiz           x0, x2, #1, #0x1f
    //     0x114c1f4: cmp             x2, x0, asr #1
    //     0x114c1f8: b.eq            #0x114c204
    //     0x114c1fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c200: stur            x2, [x0, #7]
    // 0x114c204: LeaveFrame
    //     0x114c204: mov             SP, fp
    //     0x114c208: ldp             fp, lr, [SP], #0x10
    // 0x114c20c: ret
    //     0x114c20c: ret             
    // 0x114c210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c214: b               #0x114c1b4
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299600, size: 0x150
    // 0x1299600: EnterFrame
    //     0x1299600: stp             fp, lr, [SP, #-0x10]!
    //     0x1299604: mov             fp, SP
    // 0x1299608: AllocStack(0x18)
    //     0x1299608: sub             SP, SP, #0x18
    // 0x129960c: CheckStackOverflow
    //     0x129960c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299610: cmp             SP, x16
    //     0x1299614: b.ls            #0x1299748
    // 0x1299618: ldr             x1, [fp, #0x10]
    // 0x129961c: cmp             w1, NULL
    // 0x1299620: b.ne            #0x1299634
    // 0x1299624: r0 = false
    //     0x1299624: add             x0, NULL, #0x30  ; false
    // 0x1299628: LeaveFrame
    //     0x1299628: mov             SP, fp
    //     0x129962c: ldp             fp, lr, [SP], #0x10
    // 0x1299630: ret
    //     0x1299630: ret             
    // 0x1299634: r0 = 60
    //     0x1299634: mov             x0, #0x3c
    // 0x1299638: branchIfSmi(r1, 0x1299644)
    //     0x1299638: tbz             w1, #0, #0x1299644
    // 0x129963c: r0 = LoadClassIdInstr(r1)
    //     0x129963c: ldur            x0, [x1, #-1]
    //     0x1299640: ubfx            x0, x0, #0xc, #0x14
    // 0x1299644: cmp             x0, #0xb66
    // 0x1299648: b.ne            #0x1299738
    // 0x129964c: ldr             x2, [fp, #0x18]
    // 0x1299650: LoadField: r0 = r1->field_7
    //     0x1299650: ldur            w0, [x1, #7]
    // 0x1299654: DecompressPointer r0
    //     0x1299654: add             x0, x0, HEAP, lsl #32
    // 0x1299658: LoadField: r3 = r2->field_7
    //     0x1299658: ldur            w3, [x2, #7]
    // 0x129965c: DecompressPointer r3
    //     0x129965c: add             x3, x3, HEAP, lsl #32
    // 0x1299660: r4 = LoadClassIdInstr(r0)
    //     0x1299660: ldur            x4, [x0, #-1]
    //     0x1299664: ubfx            x4, x4, #0xc, #0x14
    // 0x1299668: stp             x3, x0, [SP]
    // 0x129966c: mov             x0, x4
    // 0x1299670: mov             lr, x0
    // 0x1299674: ldr             lr, [x21, lr, lsl #3]
    // 0x1299678: blr             lr
    // 0x129967c: tbnz            w0, #4, #0x1299738
    // 0x1299680: ldr             x2, [fp, #0x18]
    // 0x1299684: ldr             x1, [fp, #0x10]
    // 0x1299688: LoadField: r0 = r1->field_b
    //     0x1299688: ldur            w0, [x1, #0xb]
    // 0x129968c: DecompressPointer r0
    //     0x129968c: add             x0, x0, HEAP, lsl #32
    // 0x1299690: LoadField: r3 = r2->field_b
    //     0x1299690: ldur            w3, [x2, #0xb]
    // 0x1299694: DecompressPointer r3
    //     0x1299694: add             x3, x3, HEAP, lsl #32
    // 0x1299698: r4 = LoadClassIdInstr(r0)
    //     0x1299698: ldur            x4, [x0, #-1]
    //     0x129969c: ubfx            x4, x4, #0xc, #0x14
    // 0x12996a0: stp             x3, x0, [SP]
    // 0x12996a4: mov             x0, x4
    // 0x12996a8: mov             lr, x0
    // 0x12996ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12996b0: blr             lr
    // 0x12996b4: tbnz            w0, #4, #0x1299738
    // 0x12996b8: ldr             x2, [fp, #0x18]
    // 0x12996bc: ldr             x1, [fp, #0x10]
    // 0x12996c0: LoadField: r0 = r1->field_13
    //     0x12996c0: ldur            w0, [x1, #0x13]
    // 0x12996c4: DecompressPointer r0
    //     0x12996c4: add             x0, x0, HEAP, lsl #32
    // 0x12996c8: LoadField: r3 = r2->field_13
    //     0x12996c8: ldur            w3, [x2, #0x13]
    // 0x12996cc: DecompressPointer r3
    //     0x12996cc: add             x3, x3, HEAP, lsl #32
    // 0x12996d0: r4 = LoadClassIdInstr(r0)
    //     0x12996d0: ldur            x4, [x0, #-1]
    //     0x12996d4: ubfx            x4, x4, #0xc, #0x14
    // 0x12996d8: stp             x3, x0, [SP]
    // 0x12996dc: mov             x0, x4
    // 0x12996e0: mov             lr, x0
    // 0x12996e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12996e8: blr             lr
    // 0x12996ec: tbnz            w0, #4, #0x1299738
    // 0x12996f0: ldr             x1, [fp, #0x18]
    // 0x12996f4: ldr             x0, [fp, #0x10]
    // 0x12996f8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12996f8: ldur            w2, [x0, #0x17]
    // 0x12996fc: DecompressPointer r2
    //     0x12996fc: add             x2, x2, HEAP, lsl #32
    // 0x1299700: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1299700: ldur            w3, [x1, #0x17]
    // 0x1299704: DecompressPointer r3
    //     0x1299704: add             x3, x3, HEAP, lsl #32
    // 0x1299708: cmp             w2, w3
    // 0x129970c: b.ne            #0x1299738
    // 0x1299710: LoadField: r2 = r0->field_1f
    //     0x1299710: ldur            w2, [x0, #0x1f]
    // 0x1299714: DecompressPointer r2
    //     0x1299714: add             x2, x2, HEAP, lsl #32
    // 0x1299718: LoadField: r0 = r1->field_1f
    //     0x1299718: ldur            w0, [x1, #0x1f]
    // 0x129971c: DecompressPointer r0
    //     0x129971c: add             x0, x0, HEAP, lsl #32
    // 0x1299720: r16 = <StringAttribute>
    //     0x1299720: ldr             x16, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0x1299724: stp             x2, x16, [SP, #8]
    // 0x1299728: str             x0, [SP]
    // 0x129972c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x129972c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1299730: r0 = listEquals()
    //     0x1299730: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1299734: b               #0x129973c
    // 0x1299738: r0 = false
    //     0x1299738: add             x0, NULL, #0x30  ; false
    // 0x129973c: LeaveFrame
    //     0x129973c: mov             SP, fp
    //     0x1299740: ldp             fp, lr, [SP], #0x10
    // 0x1299744: ret
    //     0x1299744: ret             
    // 0x1299748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129974c: b               #0x1299618
  }
}

// class id: 2919, size: 0x10, field offset: 0x8
class Accumulator extends Object {

  _ increment(/* No info */) {
    // ** addr: 0xb98390, size: 0x14
    // 0xb98390: LoadField: r3 = r1->field_7
    //     0xb98390: ldur            x3, [x1, #7]
    // 0xb98394: add             x4, x3, x2
    // 0xb98398: StoreField: r1->field_7 = r4
    //     0xb98398: stur            x4, [x1, #7]
    // 0xb9839c: r0 = Null
    //     0xb9839c: mov             x0, NULL
    // 0xb983a0: ret
    //     0xb983a0: ret             
  }
}

// class id: 5787, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class InlineSpan extends DiagnosticableTree {

  _ toPlainText(/* No info */) {
    // ** addr: 0x85f3d4, size: 0x98
    // 0x85f3d4: EnterFrame
    //     0x85f3d4: stp             fp, lr, [SP, #-0x10]!
    //     0x85f3d8: mov             fp, SP
    // 0x85f3dc: AllocStack(0x18)
    //     0x85f3dc: sub             SP, SP, #0x18
    // 0x85f3e0: SetupParameters(InlineSpan this /* r1 => r1, fp-0x8 */)
    //     0x85f3e0: stur            x1, [fp, #-8]
    // 0x85f3e4: CheckStackOverflow
    //     0x85f3e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f3e8: cmp             SP, x16
    //     0x85f3ec: b.ls            #0x85f464
    // 0x85f3f0: r0 = StringBuffer()
    //     0x85f3f0: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x85f3f4: mov             x1, x0
    // 0x85f3f8: stur            x0, [fp, #-0x10]
    // 0x85f3fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x85f3fc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x85f400: r0 = StringBuffer()
    //     0x85f400: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x85f404: ldur            x1, [fp, #-8]
    // 0x85f408: r0 = LoadClassIdInstr(r1)
    //     0x85f408: ldur            x0, [x1, #-1]
    //     0x85f40c: ubfx            x0, x0, #0xc, #0x14
    // 0x85f410: r17 = -5790
    //     0x85f410: mov             x17, #-0x169e
    // 0x85f414: add             x16, x0, x17
    // 0x85f418: cmp             x16, #1
    // 0x85f41c: b.hi            #0x85f430
    // 0x85f420: ldur            x1, [fp, #-0x10]
    // 0x85f424: r2 = 65532
    //     0x85f424: mov             x2, #0xfffc
    // 0x85f428: r0 = writeCharCode()
    //     0x85f428: bl              #0x7e69f0  ; [dart:core] StringBuffer::writeCharCode
    // 0x85f42c: b               #0x85f44c
    // 0x85f430: r0 = LoadClassIdInstr(r1)
    //     0x85f430: ldur            x0, [x1, #-1]
    //     0x85f434: ubfx            x0, x0, #0xc, #0x14
    // 0x85f438: ldur            x2, [fp, #-0x10]
    // 0x85f43c: r3 = true
    //     0x85f43c: add             x3, NULL, #0x20  ; true
    // 0x85f440: r0 = GDT[cid_x0 + -0x8a]()
    //     0x85f440: sub             lr, x0, #0x8a
    //     0x85f444: ldr             lr, [x21, lr, lsl #3]
    //     0x85f448: blr             lr
    // 0x85f44c: ldur            x16, [fp, #-0x10]
    // 0x85f450: str             x16, [SP]
    // 0x85f454: r0 = toString()
    //     0x85f454: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x85f458: LeaveFrame
    //     0x85f458: mov             SP, fp
    //     0x85f45c: ldp             fp, lr, [SP], #0x10
    // 0x85f460: ret
    //     0x85f460: ret             
    // 0x85f464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f468: b               #0x85f3f0
  }
  _ codeUnitAt(/* No info */) {
    // ** addr: 0xb97dec, size: 0x104
    // 0xb97dec: EnterFrame
    //     0xb97dec: stp             fp, lr, [SP, #-0x10]!
    //     0xb97df0: mov             fp, SP
    // 0xb97df4: AllocStack(0x30)
    //     0xb97df4: sub             SP, SP, #0x30
    // 0xb97df8: SetupParameters(InlineSpan this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb97df8: mov             x3, x1
    //     0xb97dfc: stur            x1, [fp, #-0x10]
    //     0xb97e00: stur            x2, [fp, #-0x18]
    // 0xb97e04: CheckStackOverflow
    //     0xb97e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb97e08: cmp             SP, x16
    //     0xb97e0c: b.ls            #0xb97ee8
    // 0xb97e10: r0 = BoxInt64Instr(r2)
    //     0xb97e10: sbfiz           x0, x2, #1, #0x1f
    //     0xb97e14: cmp             x2, x0, asr #1
    //     0xb97e18: b.eq            #0xb97e24
    //     0xb97e1c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb97e20: stur            x2, [x0, #7]
    // 0xb97e24: stur            x0, [fp, #-8]
    // 0xb97e28: r1 = 3
    //     0xb97e28: mov             x1, #3
    // 0xb97e2c: r0 = AllocateContext()
    //     0xb97e2c: bl              #0x13de838  ; AllocateContextStub
    // 0xb97e30: mov             x1, x0
    // 0xb97e34: ldur            x0, [fp, #-8]
    // 0xb97e38: stur            x1, [fp, #-0x20]
    // 0xb97e3c: StoreField: r1->field_f = r0
    //     0xb97e3c: stur            w0, [x1, #0xf]
    // 0xb97e40: ldur            x0, [fp, #-0x18]
    // 0xb97e44: tbz             x0, #0x3f, #0xb97e58
    // 0xb97e48: r0 = Null
    //     0xb97e48: mov             x0, NULL
    // 0xb97e4c: LeaveFrame
    //     0xb97e4c: mov             SP, fp
    //     0xb97e50: ldp             fp, lr, [SP], #0x10
    // 0xb97e54: ret
    //     0xb97e54: ret             
    // 0xb97e58: ldur            x0, [fp, #-0x10]
    // 0xb97e5c: r0 = Accumulator()
    //     0xb97e5c: bl              #0xb97ef0  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0xb97e60: StoreField: r0->field_7 = rZR
    //     0xb97e60: stur            xzr, [x0, #7]
    // 0xb97e64: ldur            x3, [fp, #-0x20]
    // 0xb97e68: StoreField: r3->field_13 = r0
    //     0xb97e68: stur            w0, [x3, #0x13]
    // 0xb97e6c: ArrayStore: r3[0] = rNULL  ; List_4
    //     0xb97e6c: stur            NULL, [x3, #0x17]
    // 0xb97e70: mov             x2, x3
    // 0xb97e74: r1 = Function '<anonymous closure>':.
    //     0xb97e74: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f7e0] AnonymousClosure: (0xb9822c), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0xb97dec)
    //     0xb97e78: ldr             x1, [x1, #0x7e0]
    // 0xb97e7c: r0 = AllocateClosure()
    //     0xb97e7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb97e80: ldur            x1, [fp, #-0x10]
    // 0xb97e84: r2 = LoadClassIdInstr(r1)
    //     0xb97e84: ldur            x2, [x1, #-1]
    //     0xb97e88: ubfx            x2, x2, #0xc, #0x14
    // 0xb97e8c: r17 = -5790
    //     0xb97e8c: mov             x17, #-0x169e
    // 0xb97e90: add             x16, x2, x17
    // 0xb97e94: cmp             x16, #1
    // 0xb97e98: b.hi            #0xb97eb0
    // 0xb97e9c: stp             x1, x0, [SP]
    // 0xb97ea0: ClosureCall
    //     0xb97ea0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb97ea4: ldur            x2, [x0, #0x1f]
    //     0xb97ea8: blr             x2
    // 0xb97eac: b               #0xb97ed0
    // 0xb97eb0: r2 = LoadClassIdInstr(r1)
    //     0xb97eb0: ldur            x2, [x1, #-1]
    //     0xb97eb4: ubfx            x2, x2, #0xc, #0x14
    // 0xb97eb8: mov             x16, x0
    // 0xb97ebc: mov             x0, x2
    // 0xb97ec0: mov             x2, x16
    // 0xb97ec4: r0 = GDT[cid_x0 + -0x18]()
    //     0xb97ec4: sub             lr, x0, #0x18
    //     0xb97ec8: ldr             lr, [x21, lr, lsl #3]
    //     0xb97ecc: blr             lr
    // 0xb97ed0: ldur            x1, [fp, #-0x20]
    // 0xb97ed4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb97ed4: ldur            w0, [x1, #0x17]
    // 0xb97ed8: DecompressPointer r0
    //     0xb97ed8: add             x0, x0, HEAP, lsl #32
    // 0xb97edc: LeaveFrame
    //     0xb97edc: mov             SP, fp
    //     0xb97ee0: ldp             fp, lr, [SP], #0x10
    // 0xb97ee4: ret
    //     0xb97ee4: ret             
    // 0xb97ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97ee8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb97eec: b               #0xb97e10
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0xb9822c, size: 0x164
    // 0xb9822c: EnterFrame
    //     0xb9822c: stp             fp, lr, [SP, #-0x10]!
    //     0xb98230: mov             fp, SP
    // 0xb98234: AllocStack(0x20)
    //     0xb98234: sub             SP, SP, #0x20
    // 0xb98238: SetupParameters([dynamic _ /* r0 */])
    //     0xb98238: ldr             x0, [fp, #0x18]
    //     0xb9823c: ldur            w3, [x0, #0x17]
    //     0xb98240: add             x3, x3, HEAP, lsl #32
    //     0xb98244: stur            x3, [fp, #-0x10]
    // 0xb98248: CheckStackOverflow
    //     0xb98248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9824c: cmp             SP, x16
    //     0xb98250: b.ls            #0xb98384
    // 0xb98254: LoadField: r0 = r3->field_f
    //     0xb98254: ldur            w0, [x3, #0xf]
    // 0xb98258: DecompressPointer r0
    //     0xb98258: add             x0, x0, HEAP, lsl #32
    // 0xb9825c: LoadField: r1 = r3->field_13
    //     0xb9825c: ldur            w1, [x3, #0x13]
    // 0xb98260: DecompressPointer r1
    //     0xb98260: add             x1, x1, HEAP, lsl #32
    // 0xb98264: ldr             x2, [fp, #0x10]
    // 0xb98268: r4 = LoadClassIdInstr(r2)
    //     0xb98268: ldur            x4, [x2, #-1]
    //     0xb9826c: ubfx            x4, x4, #0xc, #0x14
    // 0xb98270: r17 = -5790
    //     0xb98270: mov             x17, #-0x169e
    // 0xb98274: add             x16, x4, x17
    // 0xb98278: cmp             x16, #1
    // 0xb9827c: b.hi            #0xb982bc
    // 0xb98280: LoadField: r2 = r1->field_7
    //     0xb98280: ldur            x2, [x1, #7]
    // 0xb98284: r4 = LoadInt32Instr(r0)
    //     0xb98284: sbfx            x4, x0, #1, #0x1f
    //     0xb98288: tbz             w0, #0, #0xb98290
    //     0xb9828c: ldur            x4, [x0, #7]
    // 0xb98290: sub             x0, x4, x2
    // 0xb98294: stur            x0, [fp, #-8]
    // 0xb98298: r2 = 1
    //     0xb98298: mov             x2, #1
    // 0xb9829c: r0 = increment()
    //     0xb9829c: bl              #0xb98390  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0xb982a0: ldur            x0, [fp, #-8]
    // 0xb982a4: cbnz            x0, #0xb982b0
    // 0xb982a8: r0 = 131064
    //     0xb982a8: mov             x0, #0x1fff8
    // 0xb982ac: b               #0xb982b4
    // 0xb982b0: r0 = Null
    //     0xb982b0: mov             x0, NULL
    // 0xb982b4: mov             x2, x0
    // 0xb982b8: b               #0xb98360
    // 0xb982bc: LoadField: r3 = r2->field_b
    //     0xb982bc: ldur            w3, [x2, #0xb]
    // 0xb982c0: DecompressPointer r3
    //     0xb982c0: add             x3, x3, HEAP, lsl #32
    // 0xb982c4: stur            x3, [fp, #-0x20]
    // 0xb982c8: cmp             w3, NULL
    // 0xb982cc: b.ne            #0xb982d8
    // 0xb982d0: r2 = Null
    //     0xb982d0: mov             x2, NULL
    // 0xb982d4: b               #0xb98360
    // 0xb982d8: LoadField: r2 = r1->field_7
    //     0xb982d8: ldur            x2, [x1, #7]
    // 0xb982dc: r4 = LoadInt32Instr(r0)
    //     0xb982dc: sbfx            x4, x0, #1, #0x1f
    //     0xb982e0: tbz             w0, #0, #0xb982e8
    //     0xb982e4: ldur            x4, [x0, #7]
    // 0xb982e8: sub             x0, x4, x2
    // 0xb982ec: stur            x0, [fp, #-0x18]
    // 0xb982f0: LoadField: r2 = r3->field_7
    //     0xb982f0: ldur            w2, [x3, #7]
    // 0xb982f4: r4 = LoadInt32Instr(r2)
    //     0xb982f4: sbfx            x4, x2, #1, #0x1f
    // 0xb982f8: mov             x2, x4
    // 0xb982fc: stur            x4, [fp, #-8]
    // 0xb98300: r0 = increment()
    //     0xb98300: bl              #0xb98390  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0xb98304: ldur            x2, [fp, #-0x18]
    // 0xb98308: ldur            x0, [fp, #-8]
    // 0xb9830c: cmp             x2, x0
    // 0xb98310: b.ge            #0xb98358
    // 0xb98314: ldur            x3, [fp, #-0x20]
    // 0xb98318: mov             x1, x2
    // 0xb9831c: cmp             x1, x0
    // 0xb98320: b.hs            #0xb9838c
    // 0xb98324: r1 = LoadClassIdInstr(r3)
    //     0xb98324: ldur            x1, [x3, #-1]
    //     0xb98328: ubfx            x1, x1, #0xc, #0x14
    // 0xb9832c: lsl             x1, x1, #1
    // 0xb98330: cmp             w1, #0xbc
    // 0xb98334: b.ne            #0xb98344
    // 0xb98338: ArrayLoad: r1 = r3[r2]  ; TypedUnsigned_1
    //     0xb98338: add             x16, x3, x2
    //     0xb9833c: ldrb            w1, [x16, #0xf]
    // 0xb98340: b               #0xb9834c
    // 0xb98344: add             x16, x3, x2, lsl #1
    // 0xb98348: ldurh           w1, [x16, #0xf]
    // 0xb9834c: lsl             x2, x1, #1
    // 0xb98350: mov             x1, x2
    // 0xb98354: b               #0xb9835c
    // 0xb98358: r1 = Null
    //     0xb98358: mov             x1, NULL
    // 0xb9835c: mov             x2, x1
    // 0xb98360: ldur            x1, [fp, #-0x10]
    // 0xb98364: ArrayStore: r1[0] = r2  ; List_4
    //     0xb98364: stur            w2, [x1, #0x17]
    // 0xb98368: cmp             w2, NULL
    // 0xb9836c: r16 = true
    //     0xb9836c: add             x16, NULL, #0x20  ; true
    // 0xb98370: r17 = false
    //     0xb98370: add             x17, NULL, #0x30  ; false
    // 0xb98374: csel            x0, x16, x17, eq
    // 0xb98378: LeaveFrame
    //     0xb98378: mov             SP, fp
    //     0xb9837c: ldp             fp, lr, [SP], #0x10
    // 0xb98380: ret
    //     0xb98380: ret             
    // 0xb98384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb98384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb98388: b               #0xb98254
    // 0xb9838c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb9838c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getSemanticsInformation(/* No info */) {
    // ** addr: 0xbf8a84, size: 0xe4
    // 0xbf8a84: EnterFrame
    //     0xbf8a84: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8a88: mov             fp, SP
    // 0xbf8a8c: AllocStack(0x18)
    //     0xbf8a8c: sub             SP, SP, #0x18
    // 0xbf8a90: SetupParameters(InlineSpan this /* r1 => r0, fp-0x8 */)
    //     0xbf8a90: mov             x0, x1
    //     0xbf8a94: stur            x1, [fp, #-8]
    // 0xbf8a98: CheckStackOverflow
    //     0xbf8a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8a9c: cmp             SP, x16
    //     0xbf8aa0: b.ls            #0xbf8b60
    // 0xbf8aa4: r1 = <InlineSpanSemanticsInformation>
    //     0xbf8aa4: add             x1, PP, #0x98, lsl #12  ; [pp+0x988c8] TypeArguments: <InlineSpanSemanticsInformation>
    //     0xbf8aa8: ldr             x1, [x1, #0x8c8]
    // 0xbf8aac: r2 = 0
    //     0xbf8aac: mov             x2, #0
    // 0xbf8ab0: r0 = _GrowableList()
    //     0xbf8ab0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbf8ab4: ldur            x1, [fp, #-8]
    // 0xbf8ab8: stur            x0, [fp, #-0x18]
    // 0xbf8abc: r2 = LoadClassIdInstr(r1)
    //     0xbf8abc: ldur            x2, [x1, #-1]
    //     0xbf8ac0: ubfx            x2, x2, #0xc, #0x14
    // 0xbf8ac4: r17 = -5790
    //     0xbf8ac4: mov             x17, #-0x169e
    // 0xbf8ac8: add             x16, x2, x17
    // 0xbf8acc: cmp             x16, #1
    // 0xbf8ad0: b.hi            #0xbf8b30
    // 0xbf8ad4: LoadField: r1 = r0->field_b
    //     0xbf8ad4: ldur            w1, [x0, #0xb]
    // 0xbf8ad8: LoadField: r2 = r0->field_f
    //     0xbf8ad8: ldur            w2, [x0, #0xf]
    // 0xbf8adc: DecompressPointer r2
    //     0xbf8adc: add             x2, x2, HEAP, lsl #32
    // 0xbf8ae0: LoadField: r3 = r2->field_b
    //     0xbf8ae0: ldur            w3, [x2, #0xb]
    // 0xbf8ae4: r2 = LoadInt32Instr(r1)
    //     0xbf8ae4: sbfx            x2, x1, #1, #0x1f
    // 0xbf8ae8: stur            x2, [fp, #-0x10]
    // 0xbf8aec: r1 = LoadInt32Instr(r3)
    //     0xbf8aec: sbfx            x1, x3, #1, #0x1f
    // 0xbf8af0: cmp             x2, x1
    // 0xbf8af4: b.ne            #0xbf8b00
    // 0xbf8af8: mov             x1, x0
    // 0xbf8afc: r0 = _growToNextCapacity()
    //     0xbf8afc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbf8b00: ldur            x3, [fp, #-0x18]
    // 0xbf8b04: ldur            x0, [fp, #-0x10]
    // 0xbf8b08: add             x1, x0, #1
    // 0xbf8b0c: lsl             x2, x1, #1
    // 0xbf8b10: StoreField: r3->field_b = r2
    //     0xbf8b10: stur            w2, [x3, #0xb]
    // 0xbf8b14: LoadField: r1 = r3->field_f
    //     0xbf8b14: ldur            w1, [x3, #0xf]
    // 0xbf8b18: DecompressPointer r1
    //     0xbf8b18: add             x1, x1, HEAP, lsl #32
    // 0xbf8b1c: add             x2, x1, x0, lsl #2
    // 0xbf8b20: r16 = Instance_InlineSpanSemanticsInformation
    //     0xbf8b20: add             x16, PP, #0x98, lsl #12  ; [pp+0x98908] Obj!InlineSpanSemanticsInformation@129c6b1
    //     0xbf8b24: ldr             x16, [x16, #0x908]
    // 0xbf8b28: StoreField: r2->field_f = r16
    //     0xbf8b28: stur            w16, [x2, #0xf]
    // 0xbf8b2c: b               #0xbf8b50
    // 0xbf8b30: mov             x3, x0
    // 0xbf8b34: r0 = LoadClassIdInstr(r1)
    //     0xbf8b34: ldur            x0, [x1, #-1]
    //     0xbf8b38: ubfx            x0, x0, #0xc, #0x14
    // 0xbf8b3c: mov             x2, x3
    // 0xbf8b40: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbf8b40: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbf8b44: r0 = GDT[cid_x0 + -0x5c]()
    //     0xbf8b44: sub             lr, x0, #0x5c
    //     0xbf8b48: ldr             lr, [x21, lr, lsl #3]
    //     0xbf8b4c: blr             lr
    // 0xbf8b50: ldur            x0, [fp, #-0x18]
    // 0xbf8b54: LeaveFrame
    //     0xbf8b54: mov             SP, fp
    //     0xbf8b58: ldp             fp, lr, [SP], #0x10
    // 0xbf8b5c: ret
    //     0xbf8b5c: ret             
    // 0xbf8b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8b60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8b64: b               #0xbf8aa4
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x10eac04, size: 0xfc
    // 0x10eac04: EnterFrame
    //     0x10eac04: stp             fp, lr, [SP, #-0x10]!
    //     0x10eac08: mov             fp, SP
    // 0x10eac0c: AllocStack(0x8)
    //     0x10eac0c: sub             SP, SP, #8
    // 0x10eac10: SetupParameters([dynamic _ /* r0 */])
    //     0x10eac10: ldr             x0, [fp, #0x18]
    //     0x10eac14: ldur            w3, [x0, #0x17]
    //     0x10eac18: add             x3, x3, HEAP, lsl #32
    //     0x10eac1c: stur            x3, [fp, #-8]
    // 0x10eac20: CheckStackOverflow
    //     0x10eac20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eac24: cmp             SP, x16
    //     0x10eac28: b.ls            #0x10eacf8
    // 0x10eac2c: LoadField: r2 = r3->field_f
    //     0x10eac2c: ldur            w2, [x3, #0xf]
    // 0x10eac30: DecompressPointer r2
    //     0x10eac30: add             x2, x2, HEAP, lsl #32
    // 0x10eac34: LoadField: r1 = r3->field_13
    //     0x10eac34: ldur            w1, [x3, #0x13]
    // 0x10eac38: DecompressPointer r1
    //     0x10eac38: add             x1, x1, HEAP, lsl #32
    // 0x10eac3c: ldr             x0, [fp, #0x10]
    // 0x10eac40: r4 = LoadClassIdInstr(r0)
    //     0x10eac40: ldur            x4, [x0, #-1]
    //     0x10eac44: ubfx            x4, x4, #0xc, #0x14
    // 0x10eac48: r17 = -5790
    //     0x10eac48: mov             x17, #-0x169e
    // 0x10eac4c: add             x16, x4, x17
    // 0x10eac50: cmp             x16, #1
    // 0x10eac54: b.hi            #0x10eac88
    // 0x10eac58: LoadField: r4 = r2->field_7
    //     0x10eac58: ldur            x4, [x2, #7]
    // 0x10eac5c: LoadField: r2 = r1->field_7
    //     0x10eac5c: ldur            x2, [x1, #7]
    // 0x10eac60: cmp             x4, x2
    // 0x10eac64: b.ne            #0x10eac74
    // 0x10eac68: mov             x2, x0
    // 0x10eac6c: mov             x1, x3
    // 0x10eac70: b               #0x10eacbc
    // 0x10eac74: r2 = 1
    //     0x10eac74: mov             x2, #1
    // 0x10eac78: r0 = increment()
    //     0x10eac78: bl              #0xb98390  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x10eac7c: ldur            x1, [fp, #-8]
    // 0x10eac80: r2 = Null
    //     0x10eac80: mov             x2, NULL
    // 0x10eac84: b               #0x10eacbc
    // 0x10eac88: r3 = LoadClassIdInstr(r0)
    //     0x10eac88: ldur            x3, [x0, #-1]
    //     0x10eac8c: ubfx            x3, x3, #0xc, #0x14
    // 0x10eac90: mov             x16, x1
    // 0x10eac94: mov             x1, x3
    // 0x10eac98: mov             x3, x16
    // 0x10eac9c: mov             x16, x0
    // 0x10eaca0: mov             x0, x1
    // 0x10eaca4: mov             x1, x16
    // 0x10eaca8: r0 = GDT[cid_x0 + 0xdc4]()
    //     0x10eaca8: add             lr, x0, #0xdc4
    //     0x10eacac: ldr             lr, [x21, lr, lsl #3]
    //     0x10eacb0: blr             lr
    // 0x10eacb4: mov             x2, x0
    // 0x10eacb8: ldur            x1, [fp, #-8]
    // 0x10eacbc: mov             x0, x2
    // 0x10eacc0: ArrayStore: r1[0] = r0  ; List_4
    //     0x10eacc0: stur            w0, [x1, #0x17]
    //     0x10eacc4: ldurb           w16, [x1, #-1]
    //     0x10eacc8: ldurb           w17, [x0, #-1]
    //     0x10eaccc: and             x16, x17, x16, lsr #2
    //     0x10eacd0: tst             x16, HEAP, lsr #32
    //     0x10eacd4: b.eq            #0x10eacdc
    //     0x10eacd8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10eacdc: cmp             w2, NULL
    // 0x10eace0: r16 = true
    //     0x10eace0: add             x16, NULL, #0x20  ; true
    // 0x10eace4: r17 = false
    //     0x10eace4: add             x17, NULL, #0x30  ; false
    // 0x10eace8: csel            x0, x16, x17, eq
    // 0x10eacec: LeaveFrame
    //     0x10eacec: mov             SP, fp
    //     0x10eacf0: ldp             fp, lr, [SP], #0x10
    // 0x10eacf4: ret
    //     0x10eacf4: ret             
    // 0x10eacf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eacf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eacfc: b               #0x10eac2c
  }
  _ ==(/* No info */) {
    // ** addr: 0x125e62c, size: 0xc4
    // 0x125e62c: EnterFrame
    //     0x125e62c: stp             fp, lr, [SP, #-0x10]!
    //     0x125e630: mov             fp, SP
    // 0x125e634: AllocStack(0x10)
    //     0x125e634: sub             SP, SP, #0x10
    // 0x125e638: CheckStackOverflow
    //     0x125e638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125e63c: cmp             SP, x16
    //     0x125e640: b.ls            #0x125e6e8
    // 0x125e644: ldr             x1, [fp, #0x18]
    // 0x125e648: ldr             x0, [fp, #0x10]
    // 0x125e64c: cmp             w1, w0
    // 0x125e650: b.ne            #0x125e664
    // 0x125e654: r0 = true
    //     0x125e654: add             x0, NULL, #0x20  ; true
    // 0x125e658: LeaveFrame
    //     0x125e658: mov             SP, fp
    //     0x125e65c: ldp             fp, lr, [SP], #0x10
    // 0x125e660: ret
    //     0x125e660: ret             
    // 0x125e664: stp             x1, x0, [SP]
    // 0x125e668: r0 = _haveSameRuntimeType()
    //     0x125e668: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x125e66c: tbz             w0, #4, #0x125e680
    // 0x125e670: r0 = false
    //     0x125e670: add             x0, NULL, #0x30  ; false
    // 0x125e674: LeaveFrame
    //     0x125e674: mov             SP, fp
    //     0x125e678: ldp             fp, lr, [SP], #0x10
    // 0x125e67c: ret
    //     0x125e67c: ret             
    // 0x125e680: ldr             x0, [fp, #0x10]
    // 0x125e684: r1 = 60
    //     0x125e684: mov             x1, #0x3c
    // 0x125e688: branchIfSmi(r0, 0x125e694)
    //     0x125e688: tbz             w0, #0, #0x125e694
    // 0x125e68c: r1 = LoadClassIdInstr(r0)
    //     0x125e68c: ldur            x1, [x0, #-1]
    //     0x125e690: ubfx            x1, x1, #0xc, #0x14
    // 0x125e694: r17 = -5788
    //     0x125e694: mov             x17, #-0x169c
    // 0x125e698: add             x16, x1, x17
    // 0x125e69c: cmp             x16, #3
    // 0x125e6a0: b.hi            #0x125e6d8
    // 0x125e6a4: ldr             x1, [fp, #0x18]
    // 0x125e6a8: LoadField: r2 = r0->field_7
    //     0x125e6a8: ldur            w2, [x0, #7]
    // 0x125e6ac: DecompressPointer r2
    //     0x125e6ac: add             x2, x2, HEAP, lsl #32
    // 0x125e6b0: LoadField: r0 = r1->field_7
    //     0x125e6b0: ldur            w0, [x1, #7]
    // 0x125e6b4: DecompressPointer r0
    //     0x125e6b4: add             x0, x0, HEAP, lsl #32
    // 0x125e6b8: r1 = LoadClassIdInstr(r2)
    //     0x125e6b8: ldur            x1, [x2, #-1]
    //     0x125e6bc: ubfx            x1, x1, #0xc, #0x14
    // 0x125e6c0: stp             x0, x2, [SP]
    // 0x125e6c4: mov             x0, x1
    // 0x125e6c8: mov             lr, x0
    // 0x125e6cc: ldr             lr, [x21, lr, lsl #3]
    // 0x125e6d0: blr             lr
    // 0x125e6d4: b               #0x125e6dc
    // 0x125e6d8: r0 = false
    //     0x125e6d8: add             x0, NULL, #0x30  ; false
    // 0x125e6dc: LeaveFrame
    //     0x125e6dc: mov             SP, fp
    //     0x125e6e0: ldp             fp, lr, [SP], #0x10
    // 0x125e6e4: ret
    //     0x125e6e4: ret             
    // 0x125e6e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125e6e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125e6ec: b               #0x125e644
  }
}
