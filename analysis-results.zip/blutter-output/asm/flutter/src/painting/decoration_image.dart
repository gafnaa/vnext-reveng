// lib: , url: package:flutter/src/painting/decoration_image.dart

// class id: 1048992, size: 0x8
class :: {

  static _ paintImage(/* No info */) {
    // ** addr: 0xb88fd8, size: 0x8b8
    // 0xb88fd8: EnterFrame
    //     0xb88fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xb88fdc: mov             fp, SP
    // 0xb88fe0: AllocStack(0xc8)
    //     0xb88fe0: sub             SP, SP, #0xc8
    // 0xb88fe4: SetupParameters(dynamic _ /* r1 => r3, fp-0x40 */, dynamic _ /* r2 => r2, fp-0x48 */, dynamic _ /* r3 => r0, fp-0x50 */, {dynamic alignment = Instance_Alignment /* r6, fp-0x38 */, dynamic blendMode = Instance_BlendMode /* r7, fp-0x30 */, dynamic colorFilter = Null /* r8, fp-0x28 */, dynamic filterQuality = Instance_FilterQuality /* r9, fp-0x20 */, dynamic fit = Null /* r10, fp-0x18 */, dynamic invertColors = false /* r11, fp-0x10 */, _Double opacity = 1.000000 /* d0, fp-0xb0 */, dynamic repeat = Instance_ImageRepeat /* r12, fp-0x8 */, _Double scale = 1.000000 /* d1, fp-0xa8 */})
    //     0xb88fe4: mov             x0, x3
    //     0xb88fe8: stur            x3, [fp, #-0x50]
    //     0xb88fec: mov             x3, x1
    //     0xb88ff0: stur            x1, [fp, #-0x40]
    //     0xb88ff4: stur            x2, [fp, #-0x48]
    //     0xb88ff8: ldur            w1, [x4, #0x13]
    //     0xb88ffc: ldur            w5, [x4, #0x1f]
    //     0xb89000: add             x5, x5, HEAP, lsl #32
    //     0xb89004: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0xb89008: cmp             w5, w16
    //     0xb8900c: b.ne            #0xb89030
    //     0xb89010: ldur            w5, [x4, #0x23]
    //     0xb89014: add             x5, x5, HEAP, lsl #32
    //     0xb89018: sub             w6, w1, w5
    //     0xb8901c: add             x5, fp, w6, sxtw #2
    //     0xb89020: ldr             x5, [x5, #8]
    //     0xb89024: mov             x6, x5
    //     0xb89028: mov             x5, #1
    //     0xb8902c: b               #0xb8903c
    //     0xb89030: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xb89034: ldr             x6, [x6, #0xb80]
    //     0xb89038: mov             x5, #0
    //     0xb8903c: stur            x6, [fp, #-0x38]
    //     0xb89040: lsl             x7, x5, #1
    //     0xb89044: lsl             w8, w7, #1
    //     0xb89048: add             w9, w8, #8
    //     0xb8904c: add             x16, x4, w9, sxtw #1
    //     0xb89050: ldur            w10, [x16, #0xf]
    //     0xb89054: add             x10, x10, HEAP, lsl #32
    //     0xb89058: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1378] "blendMode"
    //     0xb8905c: ldr             x16, [x16, #0x378]
    //     0xb89060: cmp             w10, w16
    //     0xb89064: b.ne            #0xb89098
    //     0xb89068: add             w5, w8, #0xa
    //     0xb8906c: add             x16, x4, w5, sxtw #1
    //     0xb89070: ldur            w8, [x16, #0xf]
    //     0xb89074: add             x8, x8, HEAP, lsl #32
    //     0xb89078: sub             w5, w1, w8
    //     0xb8907c: add             x8, fp, w5, sxtw #2
    //     0xb89080: ldr             x8, [x8, #8]
    //     0xb89084: add             w5, w7, #2
    //     0xb89088: sbfx            x7, x5, #1, #0x1f
    //     0xb8908c: mov             x5, x7
    //     0xb89090: mov             x7, x8
    //     0xb89094: b               #0xb890a0
    //     0xb89098: add             x7, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xb8909c: ldr             x7, [x7, #0xeb8]
    //     0xb890a0: stur            x7, [fp, #-0x30]
    //     0xb890a4: lsl             x8, x5, #1
    //     0xb890a8: lsl             w9, w8, #1
    //     0xb890ac: add             w10, w9, #8
    //     0xb890b0: add             x16, x4, w10, sxtw #1
    //     0xb890b4: ldur            w11, [x16, #0xf]
    //     0xb890b8: add             x11, x11, HEAP, lsl #32
    //     0xb890bc: add             x16, PP, #0x17, lsl #12  ; [pp+0x17228] "colorFilter"
    //     0xb890c0: ldr             x16, [x16, #0x228]
    //     0xb890c4: cmp             w11, w16
    //     0xb890c8: b.ne            #0xb890fc
    //     0xb890cc: add             w5, w9, #0xa
    //     0xb890d0: add             x16, x4, w5, sxtw #1
    //     0xb890d4: ldur            w9, [x16, #0xf]
    //     0xb890d8: add             x9, x9, HEAP, lsl #32
    //     0xb890dc: sub             w5, w1, w9
    //     0xb890e0: add             x9, fp, w5, sxtw #2
    //     0xb890e4: ldr             x9, [x9, #8]
    //     0xb890e8: add             w5, w8, #2
    //     0xb890ec: sbfx            x8, x5, #1, #0x1f
    //     0xb890f0: mov             x5, x8
    //     0xb890f4: mov             x8, x9
    //     0xb890f8: b               #0xb89100
    //     0xb890fc: mov             x8, NULL
    //     0xb89100: stur            x8, [fp, #-0x28]
    //     0xb89104: lsl             x9, x5, #1
    //     0xb89108: lsl             w10, w9, #1
    //     0xb8910c: add             w11, w10, #8
    //     0xb89110: add             x16, x4, w11, sxtw #1
    //     0xb89114: ldur            w12, [x16, #0xf]
    //     0xb89118: add             x12, x12, HEAP, lsl #32
    //     0xb8911c: ldr             x16, [PP, #0x6f98]  ; [pp+0x6f98] "filterQuality"
    //     0xb89120: cmp             w12, w16
    //     0xb89124: b.ne            #0xb89158
    //     0xb89128: add             w5, w10, #0xa
    //     0xb8912c: add             x16, x4, w5, sxtw #1
    //     0xb89130: ldur            w10, [x16, #0xf]
    //     0xb89134: add             x10, x10, HEAP, lsl #32
    //     0xb89138: sub             w5, w1, w10
    //     0xb8913c: add             x10, fp, w5, sxtw #2
    //     0xb89140: ldr             x10, [x10, #8]
    //     0xb89144: add             w5, w9, #2
    //     0xb89148: sbfx            x9, x5, #1, #0x1f
    //     0xb8914c: mov             x5, x9
    //     0xb89150: mov             x9, x10
    //     0xb89154: b               #0xb89160
    //     0xb89158: add             x9, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0xb8915c: ldr             x9, [x9, #0xfc0]
    //     0xb89160: stur            x9, [fp, #-0x20]
    //     0xb89164: lsl             x10, x5, #1
    //     0xb89168: lsl             w11, w10, #1
    //     0xb8916c: add             w12, w11, #8
    //     0xb89170: add             x16, x4, w12, sxtw #1
    //     0xb89174: ldur            w13, [x16, #0xf]
    //     0xb89178: add             x13, x13, HEAP, lsl #32
    //     0xb8917c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fa8] "fit"
    //     0xb89180: ldr             x16, [x16, #0xfa8]
    //     0xb89184: cmp             w13, w16
    //     0xb89188: b.ne            #0xb891bc
    //     0xb8918c: add             w5, w11, #0xa
    //     0xb89190: add             x16, x4, w5, sxtw #1
    //     0xb89194: ldur            w11, [x16, #0xf]
    //     0xb89198: add             x11, x11, HEAP, lsl #32
    //     0xb8919c: sub             w5, w1, w11
    //     0xb891a0: add             x11, fp, w5, sxtw #2
    //     0xb891a4: ldr             x11, [x11, #8]
    //     0xb891a8: add             w5, w10, #2
    //     0xb891ac: sbfx            x10, x5, #1, #0x1f
    //     0xb891b0: mov             x5, x10
    //     0xb891b4: mov             x10, x11
    //     0xb891b8: b               #0xb891c0
    //     0xb891bc: mov             x10, NULL
    //     0xb891c0: stur            x10, [fp, #-0x18]
    //     0xb891c4: lsl             x11, x5, #1
    //     0xb891c8: lsl             w12, w11, #1
    //     0xb891cc: add             w13, w12, #8
    //     0xb891d0: add             x16, x4, w13, sxtw #1
    //     0xb891d4: ldur            w14, [x16, #0xf]
    //     0xb891d8: add             x14, x14, HEAP, lsl #32
    //     0xb891dc: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1380] "invertColors"
    //     0xb891e0: ldr             x16, [x16, #0x380]
    //     0xb891e4: cmp             w14, w16
    //     0xb891e8: b.ne            #0xb8921c
    //     0xb891ec: add             w5, w12, #0xa
    //     0xb891f0: add             x16, x4, w5, sxtw #1
    //     0xb891f4: ldur            w12, [x16, #0xf]
    //     0xb891f8: add             x12, x12, HEAP, lsl #32
    //     0xb891fc: sub             w5, w1, w12
    //     0xb89200: add             x12, fp, w5, sxtw #2
    //     0xb89204: ldr             x12, [x12, #8]
    //     0xb89208: add             w5, w11, #2
    //     0xb8920c: sbfx            x11, x5, #1, #0x1f
    //     0xb89210: mov             x5, x11
    //     0xb89214: mov             x11, x12
    //     0xb89218: b               #0xb89220
    //     0xb8921c: add             x11, NULL, #0x30  ; false
    //     0xb89220: stur            x11, [fp, #-0x10]
    //     0xb89224: lsl             x12, x5, #1
    //     0xb89228: lsl             w13, w12, #1
    //     0xb8922c: add             w14, w13, #8
    //     0xb89230: add             x16, x4, w14, sxtw #1
    //     0xb89234: ldur            w19, [x16, #0xf]
    //     0xb89238: add             x19, x19, HEAP, lsl #32
    //     0xb8923c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c48] "opacity"
    //     0xb89240: ldr             x16, [x16, #0xc48]
    //     0xb89244: cmp             w19, w16
    //     0xb89248: b.ne            #0xb8927c
    //     0xb8924c: add             w5, w13, #0xa
    //     0xb89250: add             x16, x4, w5, sxtw #1
    //     0xb89254: ldur            w13, [x16, #0xf]
    //     0xb89258: add             x13, x13, HEAP, lsl #32
    //     0xb8925c: sub             w5, w1, w13
    //     0xb89260: add             x13, fp, w5, sxtw #2
    //     0xb89264: ldr             x13, [x13, #8]
    //     0xb89268: add             w5, w12, #2
    //     0xb8926c: ldur            d0, [x13, #7]
    //     0xb89270: sbfx            x12, x5, #1, #0x1f
    //     0xb89274: mov             x5, x12
    //     0xb89278: b               #0xb89280
    //     0xb8927c: fmov            d0, #1.00000000
    //     0xb89280: stur            d0, [fp, #-0xb0]
    //     0xb89284: lsl             x12, x5, #1
    //     0xb89288: lsl             w13, w12, #1
    //     0xb8928c: add             w14, w13, #8
    //     0xb89290: add             x16, x4, w14, sxtw #1
    //     0xb89294: ldur            w19, [x16, #0xf]
    //     0xb89298: add             x19, x19, HEAP, lsl #32
    //     0xb8929c: add             x16, PP, #0x89, lsl #12  ; [pp+0x89e48] "repeat"
    //     0xb892a0: ldr             x16, [x16, #0xe48]
    //     0xb892a4: cmp             w19, w16
    //     0xb892a8: b.ne            #0xb892dc
    //     0xb892ac: add             w5, w13, #0xa
    //     0xb892b0: add             x16, x4, w5, sxtw #1
    //     0xb892b4: ldur            w13, [x16, #0xf]
    //     0xb892b8: add             x13, x13, HEAP, lsl #32
    //     0xb892bc: sub             w5, w1, w13
    //     0xb892c0: add             x13, fp, w5, sxtw #2
    //     0xb892c4: ldr             x13, [x13, #8]
    //     0xb892c8: add             w5, w12, #2
    //     0xb892cc: sbfx            x12, x5, #1, #0x1f
    //     0xb892d0: mov             x5, x12
    //     0xb892d4: mov             x12, x13
    //     0xb892d8: b               #0xb892e4
    //     0xb892dc: add             x12, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb892e0: ldr             x12, [x12, #0xfb8]
    //     0xb892e4: stur            x12, [fp, #-8]
    //     0xb892e8: lsl             x13, x5, #1
    //     0xb892ec: lsl             w5, w13, #1
    //     0xb892f0: add             w13, w5, #8
    //     0xb892f4: add             x16, x4, w13, sxtw #1
    //     0xb892f8: ldur            w14, [x16, #0xf]
    //     0xb892fc: add             x14, x14, HEAP, lsl #32
    //     0xb89300: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1388] "scale"
    //     0xb89304: ldr             x16, [x16, #0x388]
    //     0xb89308: cmp             w14, w16
    //     0xb8930c: b.ne            #0xb89334
    //     0xb89310: add             w13, w5, #0xa
    //     0xb89314: add             x16, x4, w13, sxtw #1
    //     0xb89318: ldur            w5, [x16, #0xf]
    //     0xb8931c: add             x5, x5, HEAP, lsl #32
    //     0xb89320: sub             w4, w1, w5
    //     0xb89324: add             x1, fp, w4, sxtw #2
    //     0xb89328: ldr             x1, [x1, #8]
    //     0xb8932c: ldur            d1, [x1, #7]
    //     0xb89330: b               #0xb89338
    //     0xb89334: fmov            d1, #1.00000000
    //     0xb89338: stur            d1, [fp, #-0xa8]
    // 0xb8933c: CheckStackOverflow
    //     0xb8933c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb89340: cmp             SP, x16
    //     0xb89344: b.ls            #0xb89878
    // 0xb89348: LoadField: d2 = r0->field_7
    //     0xb89348: ldur            d2, [x0, #7]
    // 0xb8934c: stur            d2, [fp, #-0xa0]
    // 0xb89350: ArrayLoad: d3 = r0[0]  ; List_8
    //     0xb89350: ldur            d3, [x0, #0x17]
    // 0xb89354: fcmp            d2, d3
    // 0xb89358: b.ge            #0xb89370
    // 0xb8935c: LoadField: d3 = r0->field_f
    //     0xb8935c: ldur            d3, [x0, #0xf]
    // 0xb89360: stur            d3, [fp, #-0x98]
    // 0xb89364: LoadField: d4 = r0->field_1f
    //     0xb89364: ldur            d4, [x0, #0x1f]
    // 0xb89368: fcmp            d3, d4
    // 0xb8936c: b.lt            #0xb89380
    // 0xb89370: r0 = Null
    //     0xb89370: mov             x0, NULL
    // 0xb89374: LeaveFrame
    //     0xb89374: mov             SP, fp
    //     0xb89378: ldp             fp, lr, [SP], #0x10
    // 0xb8937c: ret
    //     0xb8937c: ret             
    // 0xb89380: mov             x1, x0
    // 0xb89384: r0 = size()
    //     0xb89384: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xb89388: mov             x3, x0
    // 0xb8938c: ldur            x2, [fp, #-0x48]
    // 0xb89390: stur            x3, [fp, #-0x58]
    // 0xb89394: LoadField: r4 = r2->field_f
    //     0xb89394: ldur            x4, [x2, #0xf]
    // 0xb89398: r0 = BoxInt64Instr(r4)
    //     0xb89398: sbfiz           x0, x4, #1, #0x1f
    //     0xb8939c: cmp             x4, x0, asr #1
    //     0xb893a0: b.eq            #0xb893ac
    //     0xb893a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb893a8: stur            x4, [x0, #7]
    // 0xb893ac: stp             x0, NULL, [SP]
    // 0xb893b0: r0 = _Double.fromInteger()
    //     0xb893b0: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb893b4: mov             x3, x0
    // 0xb893b8: ldur            x2, [fp, #-0x48]
    // 0xb893bc: stur            x3, [fp, #-0x60]
    // 0xb893c0: ArrayLoad: r4 = r2[0]  ; List_8
    //     0xb893c0: ldur            x4, [x2, #0x17]
    // 0xb893c4: r0 = BoxInt64Instr(r4)
    //     0xb893c4: sbfiz           x0, x4, #1, #0x1f
    //     0xb893c8: cmp             x4, x0, asr #1
    //     0xb893cc: b.eq            #0xb893d8
    //     0xb893d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb893d4: stur            x4, [x0, #7]
    // 0xb893d8: stp             x0, NULL, [SP]
    // 0xb893dc: r0 = _Double.fromInteger()
    //     0xb893dc: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb893e0: mov             x1, x0
    // 0xb893e4: ldur            x0, [fp, #-0x60]
    // 0xb893e8: stur            x1, [fp, #-0x68]
    // 0xb893ec: LoadField: d0 = r0->field_7
    //     0xb893ec: ldur            d0, [x0, #7]
    // 0xb893f0: stur            d0, [fp, #-0xb8]
    // 0xb893f4: r0 = Size()
    //     0xb893f4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb893f8: ldur            d0, [fp, #-0xb8]
    // 0xb893fc: stur            x0, [fp, #-0x60]
    // 0xb89400: StoreField: r0->field_7 = d0
    //     0xb89400: stur            d0, [x0, #7]
    // 0xb89404: ldur            x1, [fp, #-0x68]
    // 0xb89408: LoadField: d0 = r1->field_7
    //     0xb89408: ldur            d0, [x1, #7]
    // 0xb8940c: StoreField: r0->field_f = d0
    //     0xb8940c: stur            d0, [x0, #0xf]
    // 0xb89410: ldur            x1, [fp, #-0x18]
    // 0xb89414: cmp             w1, NULL
    // 0xb89418: b.ne            #0xb89428
    // 0xb8941c: r3 = Instance_BoxFit
    //     0xb8941c: add             x3, PP, #0x89, lsl #12  ; [pp+0x89e58] Obj!BoxFit@12c48c1
    //     0xb89420: ldr             x3, [x3, #0xe58]
    // 0xb89424: b               #0xb8942c
    // 0xb89428: mov             x3, x1
    // 0xb8942c: ldur            x2, [fp, #-8]
    // 0xb89430: mov             x1, x0
    // 0xb89434: ldur            d0, [fp, #-0xa8]
    // 0xb89438: stur            x3, [fp, #-0x18]
    // 0xb8943c: r0 = /()
    //     0xb8943c: bl              #0x8a6e1c  ; [dart:ui] Size::/
    // 0xb89440: ldur            x1, [fp, #-0x18]
    // 0xb89444: mov             x2, x0
    // 0xb89448: ldur            x3, [fp, #-0x58]
    // 0xb8944c: r0 = applyBoxFit()
    //     0xb8944c: bl              #0xb8aba4  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0xb89450: stur            x0, [fp, #-0x18]
    // 0xb89454: LoadField: r1 = r0->field_7
    //     0xb89454: ldur            w1, [x0, #7]
    // 0xb89458: DecompressPointer r1
    //     0xb89458: add             x1, x1, HEAP, lsl #32
    // 0xb8945c: ldur            d0, [fp, #-0xa8]
    // 0xb89460: r0 = *()
    //     0xb89460: bl              #0x81d1f4  ; [dart:ui] Size::*
    // 0xb89464: mov             x1, x0
    // 0xb89468: ldur            x0, [fp, #-0x18]
    // 0xb8946c: stur            x1, [fp, #-0x70]
    // 0xb89470: LoadField: r2 = r0->field_b
    //     0xb89470: ldur            w2, [x0, #0xb]
    // 0xb89474: DecompressPointer r2
    //     0xb89474: add             x2, x2, HEAP, lsl #32
    // 0xb89478: ldur            x0, [fp, #-8]
    // 0xb8947c: stur            x2, [fp, #-0x68]
    // 0xb89480: r16 = Instance_ImageRepeat
    //     0xb89480: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb89484: ldr             x16, [x16, #0xfb8]
    // 0xb89488: cmp             w0, w16
    // 0xb8948c: b.eq            #0xb894c0
    // 0xb89490: ldur            x3, [fp, #-0x58]
    // 0xb89494: LoadField: d0 = r3->field_7
    //     0xb89494: ldur            d0, [x3, #7]
    // 0xb89498: LoadField: d1 = r2->field_7
    //     0xb89498: ldur            d1, [x2, #7]
    // 0xb8949c: fcmp            d0, d1
    // 0xb894a0: b.ne            #0xb894c4
    // 0xb894a4: LoadField: d0 = r3->field_f
    //     0xb894a4: ldur            d0, [x3, #0xf]
    // 0xb894a8: LoadField: d1 = r2->field_f
    //     0xb894a8: ldur            d1, [x2, #0xf]
    // 0xb894ac: fcmp            d0, d1
    // 0xb894b0: b.ne            #0xb894c4
    // 0xb894b4: r4 = Instance_ImageRepeat
    //     0xb894b4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb894b8: ldr             x4, [x4, #0xfb8]
    // 0xb894bc: b               #0xb894c8
    // 0xb894c0: ldur            x3, [fp, #-0x58]
    // 0xb894c4: mov             x4, x0
    // 0xb894c8: ldur            x0, [fp, #-0x28]
    // 0xb894cc: stur            x4, [fp, #-8]
    // 0xb894d0: r16 = 136
    //     0xb894d0: mov             x16, #0x88
    // 0xb894d4: stp             x16, NULL, [SP]
    // 0xb894d8: r0 = ByteData()
    //     0xb894d8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb894dc: stur            x0, [fp, #-0x18]
    // 0xb894e0: r0 = Paint()
    //     0xb894e0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb894e4: mov             x3, x0
    // 0xb894e8: ldur            x0, [fp, #-0x18]
    // 0xb894ec: stur            x3, [fp, #-0x80]
    // 0xb894f0: StoreField: r3->field_7 = r0
    //     0xb894f0: stur            w0, [x3, #7]
    // 0xb894f4: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb894f4: ldur            w4, [x0, #0x17]
    // 0xb894f8: DecompressPointer r4
    //     0xb894f8: add             x4, x4, HEAP, lsl #32
    // 0xb894fc: stur            x4, [fp, #-0x78]
    // 0xb89500: LoadField: r0 = r4->field_7
    //     0xb89500: ldur            x0, [x4, #7]
    // 0xb89504: r1 = 1
    //     0xb89504: mov             x1, #1
    // 0xb89508: str             w1, [x0]
    // 0xb8950c: ldur            x2, [fp, #-0x28]
    // 0xb89510: cmp             w2, NULL
    // 0xb89514: b.eq            #0xb89520
    // 0xb89518: mov             x1, x3
    // 0xb8951c: r0 = colorFilter=()
    //     0xb8951c: bl              #0xb89de4  ; [dart:ui] Paint::colorFilter=
    // 0xb89520: ldur            d0, [fp, #-0xb0]
    // 0xb89524: d1 = 0.000000
    //     0xb89524: eor             v1.16b, v1.16b, v1.16b
    // 0xb89528: fcmp            d1, d0
    // 0xb8952c: b.le            #0xb89538
    // 0xb89530: d2 = 0.000000
    //     0xb89530: eor             v2.16b, v2.16b, v2.16b
    // 0xb89534: b               #0xb89560
    // 0xb89538: d1 = 1.000000
    //     0xb89538: fmov            d1, #1.00000000
    // 0xb8953c: fcmp            d0, d1
    // 0xb89540: b.le            #0xb8954c
    // 0xb89544: d2 = 1.000000
    //     0xb89544: fmov            d2, #1.00000000
    // 0xb89548: b               #0xb89560
    // 0xb8954c: fcmp            d0, d0
    // 0xb89550: b.vc            #0xb8955c
    // 0xb89554: d2 = 1.000000
    //     0xb89554: fmov            d2, #1.00000000
    // 0xb89558: b               #0xb89560
    // 0xb8955c: mov             v2.16b, v0.16b
    // 0xb89560: ldur            x4, [fp, #-0x38]
    // 0xb89564: ldur            x5, [fp, #-0x20]
    // 0xb89568: ldur            x6, [fp, #-0x10]
    // 0xb8956c: ldur            x1, [fp, #-0x58]
    // 0xb89570: ldur            x2, [fp, #-0x68]
    // 0xb89574: ldur            x3, [fp, #-8]
    // 0xb89578: ldur            d0, [fp, #-0xa0]
    // 0xb8957c: ldur            d1, [fp, #-0x98]
    // 0xb89580: ldur            x0, [fp, #-0x78]
    // 0xb89584: stur            d2, [fp, #-0xa8]
    // 0xb89588: r0 = Color()
    //     0xb89588: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0xb8958c: mov             x1, x0
    // 0xb89590: r0 = Instance_ColorSpace
    //     0xb89590: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0xb89594: ldr             x0, [x0, #0x298]
    // 0xb89598: StoreField: r1->field_27 = r0
    //     0xb89598: stur            w0, [x1, #0x27]
    // 0xb8959c: ldur            d0, [fp, #-0xa8]
    // 0xb895a0: StoreField: r1->field_7 = d0
    //     0xb895a0: stur            d0, [x1, #7]
    // 0xb895a4: StoreField: r1->field_f = rZR
    //     0xb895a4: stur            xzr, [x1, #0xf]
    // 0xb895a8: ArrayStore: r1[0] = rZR  ; List_8
    //     0xb895a8: stur            xzr, [x1, #0x17]
    // 0xb895ac: StoreField: r1->field_1f = rZR
    //     0xb895ac: stur            xzr, [x1, #0x1f]
    // 0xb895b0: mov             x2, x1
    // 0xb895b4: ldur            x1, [fp, #-0x80]
    // 0xb895b8: r0 = color=()
    //     0xb895b8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb895bc: ldur            x0, [fp, #-0x20]
    // 0xb895c0: LoadField: r1 = r0->field_7
    //     0xb895c0: ldur            x1, [x0, #7]
    // 0xb895c4: sxtw            x1, w1
    // 0xb895c8: ldur            x0, [fp, #-0x78]
    // 0xb895cc: LoadField: r2 = r0->field_7
    //     0xb895cc: ldur            x2, [x0, #7]
    // 0xb895d0: str             w1, [x2, #0x30]
    // 0xb895d4: ldur            x1, [fp, #-0x10]
    // 0xb895d8: tst             x1, #0x10
    // 0xb895dc: cset            x2, eq
    // 0xb895e0: lsl             x2, x2, #1
    // 0xb895e4: r1 = LoadInt32Instr(r2)
    //     0xb895e4: sbfx            x1, x2, #1, #0x1f
    // 0xb895e8: LoadField: r2 = r0->field_7
    //     0xb895e8: ldur            x2, [x0, #7]
    // 0xb895ec: str             w1, [x2, #0x40]
    // 0xb895f0: ldur            x1, [fp, #-0x80]
    // 0xb895f4: ldur            x2, [fp, #-0x30]
    // 0xb895f8: r0 = blendMode=()
    //     0xb895f8: bl              #0xb89d38  ; [dart:ui] Paint::blendMode=
    // 0xb895fc: ldur            x0, [fp, #-0x58]
    // 0xb89600: LoadField: d0 = r0->field_7
    //     0xb89600: ldur            d0, [x0, #7]
    // 0xb89604: ldur            x2, [fp, #-0x68]
    // 0xb89608: LoadField: d1 = r2->field_7
    //     0xb89608: ldur            d1, [x2, #7]
    // 0xb8960c: fsub            d2, d0, d1
    // 0xb89610: d0 = 2.000000
    //     0xb89610: fmov            d0, #2.00000000
    // 0xb89614: fdiv            d1, d2, d0
    // 0xb89618: LoadField: d2 = r0->field_f
    //     0xb89618: ldur            d2, [x0, #0xf]
    // 0xb8961c: LoadField: d3 = r2->field_f
    //     0xb8961c: ldur            d3, [x2, #0xf]
    // 0xb89620: fsub            d4, d2, d3
    // 0xb89624: fdiv            d2, d4, d0
    // 0xb89628: ldur            x1, [fp, #-0x38]
    // 0xb8962c: LoadField: d0 = r1->field_7
    //     0xb8962c: ldur            d0, [x1, #7]
    // 0xb89630: fmul            d3, d0, d1
    // 0xb89634: fadd            d0, d1, d3
    // 0xb89638: stur            d0, [fp, #-0xb0]
    // 0xb8963c: LoadField: d1 = r1->field_f
    //     0xb8963c: ldur            d1, [x1, #0xf]
    // 0xb89640: fmul            d3, d1, d2
    // 0xb89644: fadd            d1, d2, d3
    // 0xb89648: stur            d1, [fp, #-0xa8]
    // 0xb8964c: r0 = Offset()
    //     0xb8964c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb89650: ldur            d0, [fp, #-0xa0]
    // 0xb89654: StoreField: r0->field_7 = d0
    //     0xb89654: stur            d0, [x0, #7]
    // 0xb89658: ldur            d0, [fp, #-0x98]
    // 0xb8965c: StoreField: r0->field_f = d0
    //     0xb8965c: stur            d0, [x0, #0xf]
    // 0xb89660: mov             x1, x0
    // 0xb89664: ldur            d0, [fp, #-0xb0]
    // 0xb89668: ldur            d1, [fp, #-0xa8]
    // 0xb8966c: r0 = translate()
    //     0xb8966c: bl              #0xb89cf4  ; [dart:ui] Offset::translate
    // 0xb89670: mov             x1, x0
    // 0xb89674: ldur            x2, [fp, #-0x68]
    // 0xb89678: r0 = &()
    //     0xb89678: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb8967c: ldur            x3, [fp, #-8]
    // 0xb89680: stur            x0, [fp, #-0x18]
    // 0xb89684: r16 = Instance_ImageRepeat
    //     0xb89684: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb89688: ldr             x16, [x16, #0xfb8]
    // 0xb8968c: cmp             w3, w16
    // 0xb89690: b.eq            #0xb8969c
    // 0xb89694: r2 = true
    //     0xb89694: add             x2, NULL, #0x20  ; true
    // 0xb89698: b               #0xb896a0
    // 0xb8969c: r2 = false
    //     0xb8969c: add             x2, NULL, #0x30  ; false
    // 0xb896a0: stur            x2, [fp, #-0x10]
    // 0xb896a4: tbnz            w2, #4, #0xb896e8
    // 0xb896a8: ldur            x4, [fp, #-0x40]
    // 0xb896ac: LoadField: r1 = r4->field_7
    //     0xb896ac: ldur            w1, [x4, #7]
    // 0xb896b0: DecompressPointer r1
    //     0xb896b0: add             x1, x1, HEAP, lsl #32
    // 0xb896b4: cmp             w1, NULL
    // 0xb896b8: b.eq            #0xb89880
    // 0xb896bc: LoadField: r5 = r1->field_7
    //     0xb896bc: ldur            x5, [x1, #7]
    // 0xb896c0: ldr             x1, [x5]
    // 0xb896c4: cbz             x1, #0xb8983c
    // 0xb896c8: mov             x5, x1
    // 0xb896cc: stur            x5, [fp, #-0x88]
    // 0xb896d0: r1 = <Never>
    //     0xb896d0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb896d4: r0 = Pointer()
    //     0xb896d4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb896d8: mov             x1, x0
    // 0xb896dc: ldur            x0, [fp, #-0x88]
    // 0xb896e0: StoreField: r1->field_7 = r0
    //     0xb896e0: stur            x0, [x1, #7]
    // 0xb896e4: r0 = _save$Method$FfiNative()
    //     0xb896e4: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xb896e8: ldur            x3, [fp, #-8]
    // 0xb896ec: r16 = Instance_ImageRepeat
    //     0xb896ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb896f0: ldr             x16, [x16, #0xfb8]
    // 0xb896f4: cmp             w3, w16
    // 0xb896f8: b.eq            #0xb8970c
    // 0xb896fc: ldur            x1, [fp, #-0x40]
    // 0xb89700: ldur            x2, [fp, #-0x50]
    // 0xb89704: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb89704: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb89708: r0 = clipRect()
    //     0xb89708: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0xb8970c: ldur            x3, [fp, #-8]
    // 0xb89710: ldur            x2, [fp, #-0x60]
    // 0xb89714: r1 = Instance_Offset
    //     0xb89714: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb89718: r0 = &()
    //     0xb89718: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb8971c: ldur            x1, [fp, #-0x38]
    // 0xb89720: ldur            x2, [fp, #-0x70]
    // 0xb89724: mov             x3, x0
    // 0xb89728: r0 = inscribe()
    //     0xb89728: bl              #0xb7da30  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0xb8972c: ldur            x3, [fp, #-8]
    // 0xb89730: stur            x0, [fp, #-0x20]
    // 0xb89734: r16 = Instance_ImageRepeat
    //     0xb89734: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xb89738: ldr             x16, [x16, #0xfb8]
    // 0xb8973c: cmp             w3, w16
    // 0xb89740: b.ne            #0xb89760
    // 0xb89744: ldur            x1, [fp, #-0x40]
    // 0xb89748: ldur            x2, [fp, #-0x48]
    // 0xb8974c: mov             x3, x0
    // 0xb89750: ldur            x5, [fp, #-0x18]
    // 0xb89754: ldur            x6, [fp, #-0x80]
    // 0xb89758: r0 = drawImageRect()
    //     0xb89758: bl              #0xb7d5e0  ; [dart:ui] _NativeCanvas::drawImageRect
    // 0xb8975c: b               #0xb897e4
    // 0xb89760: ldur            x1, [fp, #-0x50]
    // 0xb89764: ldur            x2, [fp, #-0x18]
    // 0xb89768: r0 = _generateImageTileRects()
    //     0xb89768: bl              #0xb89890  ; [package:flutter/src/painting/decoration_image.dart] ::_generateImageTileRects
    // 0xb8976c: stur            x0, [fp, #-8]
    // 0xb89770: LoadField: r1 = r0->field_b
    //     0xb89770: ldur            w1, [x0, #0xb]
    // 0xb89774: r4 = LoadInt32Instr(r1)
    //     0xb89774: sbfx            x4, x1, #1, #0x1f
    // 0xb89778: stur            x4, [fp, #-0x90]
    // 0xb8977c: r1 = 0
    //     0xb8977c: mov             x1, #0
    // 0xb89780: CheckStackOverflow
    //     0xb89780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb89784: cmp             SP, x16
    //     0xb89788: b.ls            #0xb89884
    // 0xb8978c: LoadField: r2 = r0->field_b
    //     0xb8978c: ldur            w2, [x0, #0xb]
    // 0xb89790: r3 = LoadInt32Instr(r2)
    //     0xb89790: sbfx            x3, x2, #1, #0x1f
    // 0xb89794: cmp             x4, x3
    // 0xb89798: b.ne            #0xb8985c
    // 0xb8979c: cmp             x1, x3
    // 0xb897a0: b.ge            #0xb897e4
    // 0xb897a4: LoadField: r2 = r0->field_f
    //     0xb897a4: ldur            w2, [x0, #0xf]
    // 0xb897a8: DecompressPointer r2
    //     0xb897a8: add             x2, x2, HEAP, lsl #32
    // 0xb897ac: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0xb897ac: add             x16, x2, x1, lsl #2
    //     0xb897b0: ldur            w5, [x16, #0xf]
    // 0xb897b4: DecompressPointer r5
    //     0xb897b4: add             x5, x5, HEAP, lsl #32
    // 0xb897b8: add             x7, x1, #1
    // 0xb897bc: ldur            x1, [fp, #-0x40]
    // 0xb897c0: ldur            x2, [fp, #-0x48]
    // 0xb897c4: ldur            x3, [fp, #-0x20]
    // 0xb897c8: ldur            x6, [fp, #-0x80]
    // 0xb897cc: stur            x7, [fp, #-0x88]
    // 0xb897d0: r0 = drawImageRect()
    //     0xb897d0: bl              #0xb7d5e0  ; [dart:ui] _NativeCanvas::drawImageRect
    // 0xb897d4: ldur            x1, [fp, #-0x88]
    // 0xb897d8: ldur            x0, [fp, #-8]
    // 0xb897dc: ldur            x4, [fp, #-0x90]
    // 0xb897e0: b               #0xb89780
    // 0xb897e4: ldur            x0, [fp, #-0x10]
    // 0xb897e8: tbnz            w0, #4, #0xb8982c
    // 0xb897ec: ldur            x0, [fp, #-0x40]
    // 0xb897f0: LoadField: r1 = r0->field_7
    //     0xb897f0: ldur            w1, [x0, #7]
    // 0xb897f4: DecompressPointer r1
    //     0xb897f4: add             x1, x1, HEAP, lsl #32
    // 0xb897f8: cmp             w1, NULL
    // 0xb897fc: b.eq            #0xb8988c
    // 0xb89800: LoadField: r2 = r1->field_7
    //     0xb89800: ldur            x2, [x1, #7]
    // 0xb89804: ldr             x1, [x2]
    // 0xb89808: cbz             x1, #0xb8984c
    // 0xb8980c: mov             x2, x1
    // 0xb89810: stur            x2, [fp, #-0x88]
    // 0xb89814: r1 = <Never>
    //     0xb89814: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb89818: r0 = Pointer()
    //     0xb89818: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb8981c: mov             x1, x0
    // 0xb89820: ldur            x0, [fp, #-0x88]
    // 0xb89824: StoreField: r1->field_7 = r0
    //     0xb89824: stur            x0, [x1, #7]
    // 0xb89828: r0 = _restore$Method$FfiNative()
    //     0xb89828: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xb8982c: r0 = Null
    //     0xb8982c: mov             x0, NULL
    // 0xb89830: LeaveFrame
    //     0xb89830: mov             SP, fp
    //     0xb89834: ldp             fp, lr, [SP], #0x10
    // 0xb89838: ret
    //     0xb89838: ret             
    // 0xb8983c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb8983c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb89840: str             x16, [SP]
    // 0xb89844: r0 = _throwNew()
    //     0xb89844: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb89848: brk             #0
    // 0xb8984c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb8984c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb89850: str             x16, [SP]
    // 0xb89854: r0 = _throwNew()
    //     0xb89854: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb89858: brk             #0
    // 0xb8985c: r0 = ConcurrentModificationError()
    //     0xb8985c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb89860: mov             x1, x0
    // 0xb89864: ldur            x0, [fp, #-8]
    // 0xb89868: StoreField: r1->field_b = r0
    //     0xb89868: stur            w0, [x1, #0xb]
    // 0xb8986c: mov             x0, x1
    // 0xb89870: r0 = Throw()
    //     0xb89870: bl              #0x13ddb2c  ; ThrowStub
    // 0xb89874: brk             #0
    // 0xb89878: r0 = StackOverflowSharedWithFPURegs()
    //     0xb89878: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb8987c: b               #0xb89348
    // 0xb89880: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb89880: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb89884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb89884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb89888: b               #0xb8978c
    // 0xb8988c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb8988c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _generateImageTileRects(/* No info */) {
    // ** addr: 0xb89890, size: 0x464
    // 0xb89890: EnterFrame
    //     0xb89890: stp             fp, lr, [SP, #-0x10]!
    //     0xb89894: mov             fp, SP
    // 0xb89898: AllocStack(0x90)
    //     0xb89898: sub             SP, SP, #0x90
    // 0xb8989c: CheckStackOverflow
    //     0xb8989c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb898a0: cmp             SP, x16
    //     0xb898a4: b.ls            #0xb89bb8
    // 0xb898a8: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xb898a8: ldur            d0, [x2, #0x17]
    // 0xb898ac: stur            d0, [fp, #-0x70]
    // 0xb898b0: LoadField: d1 = r2->field_7
    //     0xb898b0: ldur            d1, [x2, #7]
    // 0xb898b4: stur            d1, [fp, #-0x68]
    // 0xb898b8: fsub            d2, d0, d1
    // 0xb898bc: stur            d2, [fp, #-0x60]
    // 0xb898c0: LoadField: d3 = r2->field_1f
    //     0xb898c0: ldur            d3, [x2, #0x1f]
    // 0xb898c4: stur            d3, [fp, #-0x58]
    // 0xb898c8: LoadField: d4 = r2->field_f
    //     0xb898c8: ldur            d4, [x2, #0xf]
    // 0xb898cc: stur            d4, [fp, #-0x50]
    // 0xb898d0: fsub            d5, d3, d4
    // 0xb898d4: stur            d5, [fp, #-0x48]
    // 0xb898d8: r16 = Instance_ImageRepeat
    //     0xb898d8: add             x16, PP, #0x89, lsl #12  ; [pp+0x89e50] Obj!ImageRepeat@12c4881
    //     0xb898dc: ldr             x16, [x16, #0xe50]
    // 0xb898e0: cmp             w3, w16
    // 0xb898e4: b.eq            #0xb898f8
    // 0xb898e8: r16 = Instance_ImageRepeat
    //     0xb898e8: add             x16, PP, #0x89, lsl #12  ; [pp+0x89e30] Obj!ImageRepeat@12c4861
    //     0xb898ec: ldr             x16, [x16, #0xe30]
    // 0xb898f0: cmp             w3, w16
    // 0xb898f4: b.ne            #0xb89964
    // 0xb898f8: LoadField: d6 = r1->field_7
    //     0xb898f8: ldur            d6, [x1, #7]
    // 0xb898fc: fsub            d7, d6, d1
    // 0xb89900: fdiv            d6, d7, d2
    // 0xb89904: fcmp            d6, d6
    // 0xb89908: b.vs            #0xb89bc0
    // 0xb8990c: fcvtms          x0, d6
    // 0xb89910: asr             x16, x0, #0x1e
    // 0xb89914: cmp             x16, x0, asr #63
    // 0xb89918: b.ne            #0xb89bc0
    // 0xb8991c: lsl             x0, x0, #1
    // 0xb89920: ArrayLoad: d6 = r1[0]  ; List_8
    //     0xb89920: ldur            d6, [x1, #0x17]
    // 0xb89924: fsub            d7, d6, d0
    // 0xb89928: fdiv            d6, d7, d2
    // 0xb8992c: fcmp            d6, d6
    // 0xb89930: b.vs            #0xb89c00
    // 0xb89934: fcvtps          x2, d6
    // 0xb89938: asr             x16, x2, #0x1e
    // 0xb8993c: cmp             x16, x2, asr #63
    // 0xb89940: b.ne            #0xb89c00
    // 0xb89944: lsl             x2, x2, #1
    // 0xb89948: r4 = LoadInt32Instr(r0)
    //     0xb89948: sbfx            x4, x0, #1, #0x1f
    //     0xb8994c: tbz             w0, #0, #0xb89954
    //     0xb89950: ldur            x4, [x0, #7]
    // 0xb89954: r0 = LoadInt32Instr(r2)
    //     0xb89954: sbfx            x0, x2, #1, #0x1f
    //     0xb89958: tbz             w2, #0, #0xb89960
    //     0xb8995c: ldur            x0, [x2, #7]
    // 0xb89960: b               #0xb8996c
    // 0xb89964: r4 = 0
    //     0xb89964: mov             x4, #0
    // 0xb89968: r0 = 0
    //     0xb89968: mov             x0, #0
    // 0xb8996c: stur            x4, [fp, #-0x18]
    // 0xb89970: stur            x0, [fp, #-0x20]
    // 0xb89974: r16 = Instance_ImageRepeat
    //     0xb89974: add             x16, PP, #0x89, lsl #12  ; [pp+0x89e50] Obj!ImageRepeat@12c4881
    //     0xb89978: ldr             x16, [x16, #0xe50]
    // 0xb8997c: cmp             w3, w16
    // 0xb89980: b.eq            #0xb89994
    // 0xb89984: r16 = Instance_ImageRepeat
    //     0xb89984: add             x16, PP, #0x89, lsl #12  ; [pp+0x89e40] Obj!ImageRepeat@12c4841
    //     0xb89988: ldr             x16, [x16, #0xe40]
    // 0xb8998c: cmp             w3, w16
    // 0xb89990: b.ne            #0xb89a08
    // 0xb89994: LoadField: d6 = r1->field_f
    //     0xb89994: ldur            d6, [x1, #0xf]
    // 0xb89998: fsub            d7, d6, d4
    // 0xb8999c: fdiv            d6, d7, d5
    // 0xb899a0: fcmp            d6, d6
    // 0xb899a4: b.vs            #0xb89c4c
    // 0xb899a8: fcvtms          x2, d6
    // 0xb899ac: asr             x16, x2, #0x1e
    // 0xb899b0: cmp             x16, x2, asr #63
    // 0xb899b4: b.ne            #0xb89c4c
    // 0xb899b8: lsl             x2, x2, #1
    // 0xb899bc: LoadField: d6 = r1->field_1f
    //     0xb899bc: ldur            d6, [x1, #0x1f]
    // 0xb899c0: fsub            d7, d6, d3
    // 0xb899c4: fdiv            d6, d7, d5
    // 0xb899c8: fcmp            d6, d6
    // 0xb899cc: b.vs            #0xb89c98
    // 0xb899d0: fcvtps          x1, d6
    // 0xb899d4: asr             x16, x1, #0x1e
    // 0xb899d8: cmp             x16, x1, asr #63
    // 0xb899dc: b.ne            #0xb89c98
    // 0xb899e0: lsl             x1, x1, #1
    // 0xb899e4: r3 = LoadInt32Instr(r2)
    //     0xb899e4: sbfx            x3, x2, #1, #0x1f
    //     0xb899e8: tbz             w2, #0, #0xb899f0
    //     0xb899ec: ldur            x3, [x2, #7]
    // 0xb899f0: r2 = LoadInt32Instr(r1)
    //     0xb899f0: sbfx            x2, x1, #1, #0x1f
    //     0xb899f4: tbz             w1, #0, #0xb899fc
    //     0xb899f8: ldur            x2, [x1, #7]
    // 0xb899fc: mov             x5, x3
    // 0xb89a00: mov             x3, x2
    // 0xb89a04: b               #0xb89a10
    // 0xb89a08: r5 = 0
    //     0xb89a08: mov             x5, #0
    // 0xb89a0c: r3 = 0
    //     0xb89a0c: mov             x3, #0
    // 0xb89a10: stur            x5, [fp, #-8]
    // 0xb89a14: stur            x3, [fp, #-0x10]
    // 0xb89a18: r1 = <Rect>
    //     0xb89a18: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0xb89a1c: r2 = 0
    //     0xb89a1c: mov             x2, #0
    // 0xb89a20: r0 = _GrowableList()
    //     0xb89a20: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb89a24: stur            x0, [fp, #-0x30]
    // 0xb89a28: ldur            x3, [fp, #-0x18]
    // 0xb89a2c: ldur            x1, [fp, #-0x20]
    // 0xb89a30: ldur            x2, [fp, #-0x10]
    // 0xb89a34: ldur            d0, [fp, #-0x70]
    // 0xb89a38: ldur            d1, [fp, #-0x68]
    // 0xb89a3c: ldur            d2, [fp, #-0x60]
    // 0xb89a40: ldur            d3, [fp, #-0x58]
    // 0xb89a44: ldur            d4, [fp, #-0x50]
    // 0xb89a48: ldur            d5, [fp, #-0x48]
    // 0xb89a4c: stur            x3, [fp, #-0x28]
    // 0xb89a50: CheckStackOverflow
    //     0xb89a50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb89a54: cmp             SP, x16
    //     0xb89a58: b.ls            #0xb89ce4
    // 0xb89a5c: cmp             x3, x1
    // 0xb89a60: b.gt            #0xb89ba4
    // 0xb89a64: scvtf           d6, x3
    // 0xb89a68: fmul            d7, d6, d2
    // 0xb89a6c: fadd            d6, d1, d7
    // 0xb89a70: stur            d6, [fp, #-0x90]
    // 0xb89a74: fadd            d8, d0, d7
    // 0xb89a78: stur            d8, [fp, #-0x88]
    // 0xb89a7c: ldur            x4, [fp, #-8]
    // 0xb89a80: stur            x4, [fp, #-0x18]
    // 0xb89a84: CheckStackOverflow
    //     0xb89a84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb89a88: cmp             SP, x16
    //     0xb89a8c: b.ls            #0xb89cec
    // 0xb89a90: cmp             x4, x2
    // 0xb89a94: b.gt            #0xb89b90
    // 0xb89a98: scvtf           d7, x4
    // 0xb89a9c: fmul            d9, d7, d5
    // 0xb89aa0: fadd            d7, d4, d9
    // 0xb89aa4: stur            d7, [fp, #-0x80]
    // 0xb89aa8: fadd            d10, d3, d9
    // 0xb89aac: stur            d10, [fp, #-0x78]
    // 0xb89ab0: r0 = Rect()
    //     0xb89ab0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb89ab4: ldur            d0, [fp, #-0x90]
    // 0xb89ab8: stur            x0, [fp, #-0x40]
    // 0xb89abc: StoreField: r0->field_7 = d0
    //     0xb89abc: stur            d0, [x0, #7]
    // 0xb89ac0: ldur            d1, [fp, #-0x80]
    // 0xb89ac4: StoreField: r0->field_f = d1
    //     0xb89ac4: stur            d1, [x0, #0xf]
    // 0xb89ac8: ldur            d1, [fp, #-0x88]
    // 0xb89acc: ArrayStore: r0[0] = d1  ; List_8
    //     0xb89acc: stur            d1, [x0, #0x17]
    // 0xb89ad0: ldur            d2, [fp, #-0x78]
    // 0xb89ad4: StoreField: r0->field_1f = d2
    //     0xb89ad4: stur            d2, [x0, #0x1f]
    // 0xb89ad8: ldur            x2, [fp, #-0x30]
    // 0xb89adc: LoadField: r1 = r2->field_b
    //     0xb89adc: ldur            w1, [x2, #0xb]
    // 0xb89ae0: LoadField: r3 = r2->field_f
    //     0xb89ae0: ldur            w3, [x2, #0xf]
    // 0xb89ae4: DecompressPointer r3
    //     0xb89ae4: add             x3, x3, HEAP, lsl #32
    // 0xb89ae8: LoadField: r4 = r3->field_b
    //     0xb89ae8: ldur            w4, [x3, #0xb]
    // 0xb89aec: r3 = LoadInt32Instr(r1)
    //     0xb89aec: sbfx            x3, x1, #1, #0x1f
    // 0xb89af0: stur            x3, [fp, #-0x38]
    // 0xb89af4: r1 = LoadInt32Instr(r4)
    //     0xb89af4: sbfx            x1, x4, #1, #0x1f
    // 0xb89af8: cmp             x3, x1
    // 0xb89afc: b.ne            #0xb89b08
    // 0xb89b00: mov             x1, x2
    // 0xb89b04: r0 = _growToNextCapacity()
    //     0xb89b04: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb89b08: ldur            x2, [fp, #-0x30]
    // 0xb89b0c: ldur            x4, [fp, #-0x18]
    // 0xb89b10: ldur            x3, [fp, #-0x38]
    // 0xb89b14: add             x5, x3, #1
    // 0xb89b18: lsl             x6, x5, #1
    // 0xb89b1c: StoreField: r2->field_b = r6
    //     0xb89b1c: stur            w6, [x2, #0xb]
    // 0xb89b20: LoadField: r1 = r2->field_f
    //     0xb89b20: ldur            w1, [x2, #0xf]
    // 0xb89b24: DecompressPointer r1
    //     0xb89b24: add             x1, x1, HEAP, lsl #32
    // 0xb89b28: ldur            x0, [fp, #-0x40]
    // 0xb89b2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb89b2c: add             x25, x1, x3, lsl #2
    //     0xb89b30: add             x25, x25, #0xf
    //     0xb89b34: str             w0, [x25]
    //     0xb89b38: tbz             w0, #0, #0xb89b54
    //     0xb89b3c: ldurb           w16, [x1, #-1]
    //     0xb89b40: ldurb           w17, [x0, #-1]
    //     0xb89b44: and             x16, x17, x16, lsr #2
    //     0xb89b48: tst             x16, HEAP, lsr #32
    //     0xb89b4c: b.eq            #0xb89b54
    //     0xb89b50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb89b54: add             x0, x4, #1
    // 0xb89b58: mov             x4, x0
    // 0xb89b5c: ldur            x1, [fp, #-0x20]
    // 0xb89b60: mov             x0, x2
    // 0xb89b64: ldur            x2, [fp, #-0x10]
    // 0xb89b68: ldur            x3, [fp, #-0x28]
    // 0xb89b6c: ldur            d6, [fp, #-0x90]
    // 0xb89b70: ldur            d8, [fp, #-0x88]
    // 0xb89b74: ldur            d0, [fp, #-0x70]
    // 0xb89b78: ldur            d1, [fp, #-0x68]
    // 0xb89b7c: ldur            d2, [fp, #-0x60]
    // 0xb89b80: ldur            d3, [fp, #-0x58]
    // 0xb89b84: ldur            d4, [fp, #-0x50]
    // 0xb89b88: ldur            d5, [fp, #-0x48]
    // 0xb89b8c: b               #0xb89a80
    // 0xb89b90: mov             x2, x0
    // 0xb89b94: mov             x1, x3
    // 0xb89b98: add             x3, x1, #1
    // 0xb89b9c: mov             x0, x2
    // 0xb89ba0: b               #0xb89a2c
    // 0xb89ba4: mov             x2, x0
    // 0xb89ba8: mov             x0, x2
    // 0xb89bac: LeaveFrame
    //     0xb89bac: mov             SP, fp
    //     0xb89bb0: ldp             fp, lr, [SP], #0x10
    // 0xb89bb4: ret
    //     0xb89bb4: ret             
    // 0xb89bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb89bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb89bbc: b               #0xb898a8
    // 0xb89bc0: stp             q5, q6, [SP, #-0x20]!
    // 0xb89bc4: stp             q3, q4, [SP, #-0x20]!
    // 0xb89bc8: stp             q1, q2, [SP, #-0x20]!
    // 0xb89bcc: SaveReg d0
    //     0xb89bcc: str             q0, [SP, #-0x10]!
    // 0xb89bd0: stp             x1, x3, [SP, #-0x10]!
    // 0xb89bd4: d0 = 0.000000
    //     0xb89bd4: fmov            d0, d6
    // 0xb89bd8: r0 = 70
    //     0xb89bd8: mov             x0, #0x46
    // 0xb89bdc: r30 = DoubleToIntegerStub
    //     0xb89bdc: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb89be0: LoadField: r30 = r30->field_7
    //     0xb89be0: ldur            lr, [lr, #7]
    // 0xb89be4: blr             lr
    // 0xb89be8: ldp             x1, x3, [SP], #0x10
    // 0xb89bec: RestoreReg d0
    //     0xb89bec: ldr             q0, [SP], #0x10
    // 0xb89bf0: ldp             q1, q2, [SP], #0x20
    // 0xb89bf4: ldp             q3, q4, [SP], #0x20
    // 0xb89bf8: ldp             q5, q6, [SP], #0x20
    // 0xb89bfc: b               #0xb89920
    // 0xb89c00: stp             q5, q6, [SP, #-0x20]!
    // 0xb89c04: stp             q3, q4, [SP, #-0x20]!
    // 0xb89c08: stp             q1, q2, [SP, #-0x20]!
    // 0xb89c0c: SaveReg d0
    //     0xb89c0c: str             q0, [SP, #-0x10]!
    // 0xb89c10: stp             x1, x3, [SP, #-0x10]!
    // 0xb89c14: SaveReg r0
    //     0xb89c14: str             x0, [SP, #-8]!
    // 0xb89c18: d0 = 0.000000
    //     0xb89c18: fmov            d0, d6
    // 0xb89c1c: r0 = 66
    //     0xb89c1c: mov             x0, #0x42
    // 0xb89c20: r30 = DoubleToIntegerStub
    //     0xb89c20: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb89c24: LoadField: r30 = r30->field_7
    //     0xb89c24: ldur            lr, [lr, #7]
    // 0xb89c28: blr             lr
    // 0xb89c2c: mov             x2, x0
    // 0xb89c30: RestoreReg r0
    //     0xb89c30: ldr             x0, [SP], #8
    // 0xb89c34: ldp             x1, x3, [SP], #0x10
    // 0xb89c38: RestoreReg d0
    //     0xb89c38: ldr             q0, [SP], #0x10
    // 0xb89c3c: ldp             q1, q2, [SP], #0x20
    // 0xb89c40: ldp             q3, q4, [SP], #0x20
    // 0xb89c44: ldp             q5, q6, [SP], #0x20
    // 0xb89c48: b               #0xb89948
    // 0xb89c4c: stp             q5, q6, [SP, #-0x20]!
    // 0xb89c50: stp             q3, q4, [SP, #-0x20]!
    // 0xb89c54: stp             q1, q2, [SP, #-0x20]!
    // 0xb89c58: SaveReg d0
    //     0xb89c58: str             q0, [SP, #-0x10]!
    // 0xb89c5c: stp             x1, x4, [SP, #-0x10]!
    // 0xb89c60: SaveReg r0
    //     0xb89c60: str             x0, [SP, #-8]!
    // 0xb89c64: d0 = 0.000000
    //     0xb89c64: fmov            d0, d6
    // 0xb89c68: r0 = 70
    //     0xb89c68: mov             x0, #0x46
    // 0xb89c6c: r30 = DoubleToIntegerStub
    //     0xb89c6c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb89c70: LoadField: r30 = r30->field_7
    //     0xb89c70: ldur            lr, [lr, #7]
    // 0xb89c74: blr             lr
    // 0xb89c78: mov             x2, x0
    // 0xb89c7c: RestoreReg r0
    //     0xb89c7c: ldr             x0, [SP], #8
    // 0xb89c80: ldp             x1, x4, [SP], #0x10
    // 0xb89c84: RestoreReg d0
    //     0xb89c84: ldr             q0, [SP], #0x10
    // 0xb89c88: ldp             q1, q2, [SP], #0x20
    // 0xb89c8c: ldp             q3, q4, [SP], #0x20
    // 0xb89c90: ldp             q5, q6, [SP], #0x20
    // 0xb89c94: b               #0xb899bc
    // 0xb89c98: stp             q5, q6, [SP, #-0x20]!
    // 0xb89c9c: stp             q3, q4, [SP, #-0x20]!
    // 0xb89ca0: stp             q1, q2, [SP, #-0x20]!
    // 0xb89ca4: SaveReg d0
    //     0xb89ca4: str             q0, [SP, #-0x10]!
    // 0xb89ca8: stp             x2, x4, [SP, #-0x10]!
    // 0xb89cac: SaveReg r0
    //     0xb89cac: str             x0, [SP, #-8]!
    // 0xb89cb0: d0 = 0.000000
    //     0xb89cb0: fmov            d0, d6
    // 0xb89cb4: r0 = 66
    //     0xb89cb4: mov             x0, #0x42
    // 0xb89cb8: r30 = DoubleToIntegerStub
    //     0xb89cb8: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb89cbc: LoadField: r30 = r30->field_7
    //     0xb89cbc: ldur            lr, [lr, #7]
    // 0xb89cc0: blr             lr
    // 0xb89cc4: mov             x1, x0
    // 0xb89cc8: RestoreReg r0
    //     0xb89cc8: ldr             x0, [SP], #8
    // 0xb89ccc: ldp             x2, x4, [SP], #0x10
    // 0xb89cd0: RestoreReg d0
    //     0xb89cd0: ldr             q0, [SP], #0x10
    // 0xb89cd4: ldp             q1, q2, [SP], #0x20
    // 0xb89cd8: ldp             q3, q4, [SP], #0x20
    // 0xb89cdc: ldp             q5, q6, [SP], #0x20
    // 0xb89ce0: b               #0xb899e4
    // 0xb89ce4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb89ce4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb89ce8: b               #0xb89a5c
    // 0xb89cec: r0 = StackOverflowSharedWithFPURegs()
    //     0xb89cec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb89cf0: b               #0xb89a90
  }
}

// class id: 2941, size: 0x18, field offset: 0x8
class _BlendedDecorationImagePainter extends Object
    implements DecorationImagePainter {

  _ dispose(/* No info */) {
    // ** addr: 0x1303fe4, size: 0x8c
    // 0x1303fe4: EnterFrame
    //     0x1303fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x1303fe8: mov             fp, SP
    // 0x1303fec: AllocStack(0x8)
    //     0x1303fec: sub             SP, SP, #8
    // 0x1303ff0: SetupParameters(_BlendedDecorationImagePainter this /* r1 => r2, fp-0x8 */)
    //     0x1303ff0: mov             x2, x1
    //     0x1303ff4: stur            x1, [fp, #-8]
    // 0x1303ff8: CheckStackOverflow
    //     0x1303ff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303ffc: cmp             SP, x16
    //     0x1304000: b.ls            #0x1304068
    // 0x1304004: LoadField: r1 = r2->field_7
    //     0x1304004: ldur            w1, [x2, #7]
    // 0x1304008: DecompressPointer r1
    //     0x1304008: add             x1, x1, HEAP, lsl #32
    // 0x130400c: cmp             w1, NULL
    // 0x1304010: b.ne            #0x130401c
    // 0x1304014: mov             x0, x2
    // 0x1304018: b               #0x1304034
    // 0x130401c: r0 = LoadClassIdInstr(r1)
    //     0x130401c: ldur            x0, [x1, #-1]
    //     0x1304020: ubfx            x0, x0, #0xc, #0x14
    // 0x1304024: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x1304024: sub             lr, x0, #0xfb9
    //     0x1304028: ldr             lr, [x21, lr, lsl #3]
    //     0x130402c: blr             lr
    // 0x1304030: ldur            x0, [fp, #-8]
    // 0x1304034: LoadField: r1 = r0->field_b
    //     0x1304034: ldur            w1, [x0, #0xb]
    // 0x1304038: DecompressPointer r1
    //     0x1304038: add             x1, x1, HEAP, lsl #32
    // 0x130403c: cmp             w1, NULL
    // 0x1304040: b.eq            #0x1304058
    // 0x1304044: r0 = LoadClassIdInstr(r1)
    //     0x1304044: ldur            x0, [x1, #-1]
    //     0x1304048: ubfx            x0, x0, #0xc, #0x14
    // 0x130404c: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x130404c: sub             lr, x0, #0xfb9
    //     0x1304050: ldr             lr, [x21, lr, lsl #3]
    //     0x1304054: blr             lr
    // 0x1304058: r0 = Null
    //     0x1304058: mov             x0, NULL
    // 0x130405c: LeaveFrame
    //     0x130405c: mov             SP, fp
    //     0x1304060: ldp             fp, lr, [SP], #0x10
    // 0x1304064: ret
    //     0x1304064: ret             
    // 0x1304068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130406c: b               #0x1304004
  }
  _ paint(/* No info */) {
    // ** addr: 0x1304070, size: 0x310
    // 0x1304070: EnterFrame
    //     0x1304070: stp             fp, lr, [SP, #-0x10]!
    //     0x1304074: mov             fp, SP
    // 0x1304078: AllocStack(0x58)
    //     0x1304078: sub             SP, SP, #0x58
    // 0x130407c: SetupParameters(_BlendedDecorationImagePainter this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */, dynamic _ /* r6 => r6, fp-0x30 */, {_Double blend = 1.000000 /* d0, fp-0x48 */, dynamic blendMode = Instance_BlendMode /* r0, fp-0x8 */})
    //     0x130407c: stur            x1, [fp, #-0x10]
    //     0x1304080: stur            x2, [fp, #-0x18]
    //     0x1304084: stur            x3, [fp, #-0x20]
    //     0x1304088: stur            x5, [fp, #-0x28]
    //     0x130408c: stur            x6, [fp, #-0x30]
    //     0x1304090: ldur            w0, [x4, #0x13]
    //     0x1304094: ldur            w7, [x4, #0x1f]
    //     0x1304098: add             x7, x7, HEAP, lsl #32
    //     0x130409c: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b300] "blend"
    //     0x13040a0: ldr             x16, [x16, #0x300]
    //     0x13040a4: cmp             w7, w16
    //     0x13040a8: b.ne            #0x13040cc
    //     0x13040ac: ldur            w7, [x4, #0x23]
    //     0x13040b0: add             x7, x7, HEAP, lsl #32
    //     0x13040b4: sub             w8, w0, w7
    //     0x13040b8: add             x7, fp, w8, sxtw #2
    //     0x13040bc: ldr             x7, [x7, #8]
    //     0x13040c0: ldur            d0, [x7, #7]
    //     0x13040c4: mov             x7, #1
    //     0x13040c8: b               #0x13040d4
    //     0x13040cc: fmov            d0, #1.00000000
    //     0x13040d0: mov             x7, #0
    //     0x13040d4: stur            d0, [fp, #-0x48]
    //     0x13040d8: lsl             x8, x7, #1
    //     0x13040dc: lsl             w7, w8, #1
    //     0x13040e0: add             w8, w7, #8
    //     0x13040e4: add             x16, x4, w8, sxtw #1
    //     0x13040e8: ldur            w9, [x16, #0xf]
    //     0x13040ec: add             x9, x9, HEAP, lsl #32
    //     0x13040f0: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1378] "blendMode"
    //     0x13040f4: ldr             x16, [x16, #0x378]
    //     0x13040f8: cmp             w9, w16
    //     0x13040fc: b.ne            #0x1304120
    //     0x1304100: add             w8, w7, #0xa
    //     0x1304104: add             x16, x4, w8, sxtw #1
    //     0x1304108: ldur            w7, [x16, #0xf]
    //     0x130410c: add             x7, x7, HEAP, lsl #32
    //     0x1304110: sub             w4, w0, w7
    //     0x1304114: add             x0, fp, w4, sxtw #2
    //     0x1304118: ldr             x0, [x0, #8]
    //     0x130411c: b               #0x1304128
    //     0x1304120: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0x1304124: ldr             x0, [x0, #0xeb8]
    //     0x1304128: stur            x0, [fp, #-8]
    // 0x130412c: CheckStackOverflow
    //     0x130412c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304130: cmp             SP, x16
    //     0x1304134: b.ls            #0x130433c
    // 0x1304138: r16 = 136
    //     0x1304138: mov             x16, #0x88
    // 0x130413c: stp             x16, NULL, [SP]
    // 0x1304140: r0 = ByteData()
    //     0x1304140: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x1304144: ldur            x2, [fp, #-0x18]
    // 0x1304148: stur            x0, [fp, #-0x40]
    // 0x130414c: LoadField: r1 = r2->field_7
    //     0x130414c: ldur            w1, [x2, #7]
    // 0x1304150: DecompressPointer r1
    //     0x1304150: add             x1, x1, HEAP, lsl #32
    // 0x1304154: cmp             w1, NULL
    // 0x1304158: b.eq            #0x1304344
    // 0x130415c: LoadField: r3 = r1->field_7
    //     0x130415c: ldur            x3, [x1, #7]
    // 0x1304160: ldr             x1, [x3]
    // 0x1304164: cbz             x1, #0x130431c
    // 0x1304168: ldur            x3, [fp, #-0x10]
    // 0x130416c: mov             x4, x1
    // 0x1304170: stur            x4, [fp, #-0x38]
    // 0x1304174: r1 = <Never>
    //     0x1304174: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1304178: r0 = Pointer()
    //     0x1304178: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x130417c: mov             x1, x0
    // 0x1304180: ldur            x0, [fp, #-0x38]
    // 0x1304184: StoreField: r1->field_7 = r0
    //     0x1304184: stur            x0, [x1, #7]
    // 0x1304188: ldur            x3, [fp, #-0x40]
    // 0x130418c: r2 = Null
    //     0x130418c: mov             x2, NULL
    // 0x1304190: r0 = __saveLayerWithoutBounds$Method$FfiNative()
    //     0x1304190: bl              #0xf31ddc  ; [dart:ui] _NativeCanvas::__saveLayerWithoutBounds$Method$FfiNative
    // 0x1304194: ldur            x4, [fp, #-0x10]
    // 0x1304198: LoadField: r7 = r4->field_7
    //     0x1304198: ldur            w7, [x4, #7]
    // 0x130419c: DecompressPointer r7
    //     0x130419c: add             x7, x7, HEAP, lsl #32
    // 0x13041a0: stur            x7, [fp, #-0x40]
    // 0x13041a4: cmp             w7, NULL
    // 0x13041a8: b.ne            #0x13041b4
    // 0x13041ac: mov             x0, x4
    // 0x13041b0: b               #0x1304234
    // 0x13041b4: ldur            d0, [fp, #-0x48]
    // 0x13041b8: d1 = 1.000000
    //     0x13041b8: fmov            d1, #1.00000000
    // 0x13041bc: LoadField: d2 = r4->field_f
    //     0x13041bc: ldur            d2, [x4, #0xf]
    // 0x13041c0: fsub            d3, d1, d2
    // 0x13041c4: fmul            d1, d0, d3
    // 0x13041c8: r0 = inline_Allocate_Double()
    //     0x13041c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x13041cc: add             x0, x0, #0x10
    //     0x13041d0: cmp             x1, x0
    //     0x13041d4: b.ls            #0x1304348
    //     0x13041d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x13041dc: sub             x0, x0, #0xf
    //     0x13041e0: mov             x1, #0xe19c
    //     0x13041e4: movk            x1, #3, lsl #16
    //     0x13041e8: stur            x1, [x0, #-1]
    // 0x13041ec: dmb             ishst
    // 0x13041f0: StoreField: r0->field_7 = d1
    //     0x13041f0: stur            d1, [x0, #7]
    // 0x13041f4: r1 = LoadClassIdInstr(r7)
    //     0x13041f4: ldur            x1, [x7, #-1]
    //     0x13041f8: ubfx            x1, x1, #0xc, #0x14
    // 0x13041fc: ldur            x16, [fp, #-8]
    // 0x1304200: stp             x16, x0, [SP]
    // 0x1304204: mov             x0, x1
    // 0x1304208: mov             x1, x7
    // 0x130420c: ldur            x2, [fp, #-0x18]
    // 0x1304210: ldur            x3, [fp, #-0x20]
    // 0x1304214: ldur            x5, [fp, #-0x28]
    // 0x1304218: ldur            x6, [fp, #-0x30]
    // 0x130421c: r4 = const [0, 0x7, 0x2, 0x5, blend, 0x5, blendMode, 0x6, null]
    //     0x130421c: add             x4, PP, #0xb0, lsl #12  ; [pp+0xb0880] List(9) [0, 0x7, 0x2, 0x5, "blend", 0x5, "blendMode", 0x6, Null]
    //     0x1304220: ldr             x4, [x4, #0x880]
    // 0x1304224: r0 = GDT[cid_x0 + -0xfba]()
    //     0x1304224: sub             lr, x0, #0xfba
    //     0x1304228: ldr             lr, [x21, lr, lsl #3]
    //     0x130422c: blr             lr
    // 0x1304230: ldur            x0, [fp, #-0x10]
    // 0x1304234: LoadField: r1 = r0->field_b
    //     0x1304234: ldur            w1, [x0, #0xb]
    // 0x1304238: DecompressPointer r1
    //     0x1304238: add             x1, x1, HEAP, lsl #32
    // 0x130423c: cmp             w1, NULL
    // 0x1304240: b.eq            #0x13042cc
    // 0x1304244: ldur            d0, [fp, #-0x48]
    // 0x1304248: ldur            x2, [fp, #-0x40]
    // 0x130424c: LoadField: d1 = r0->field_f
    //     0x130424c: ldur            d1, [x0, #0xf]
    // 0x1304250: fmul            d2, d0, d1
    // 0x1304254: cmp             w2, NULL
    // 0x1304258: b.eq            #0x1304268
    // 0x130425c: r0 = Instance_BlendMode
    //     0x130425c: add             x0, PP, #0xb0, lsl #12  ; [pp+0xb0888] Obj!BlendMode@12c8541
    //     0x1304260: ldr             x0, [x0, #0x888]
    // 0x1304264: b               #0x130426c
    // 0x1304268: ldur            x0, [fp, #-8]
    // 0x130426c: r2 = inline_Allocate_Double()
    //     0x130426c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1304270: add             x2, x2, #0x10
    //     0x1304274: cmp             x3, x2
    //     0x1304278: b.ls            #0x1304360
    //     0x130427c: str             x2, [THR, #0x60]  ; THR::top
    //     0x1304280: sub             x2, x2, #0xf
    //     0x1304284: mov             x3, #0xe19c
    //     0x1304288: movk            x3, #3, lsl #16
    //     0x130428c: stur            x3, [x2, #-1]
    // 0x1304290: dmb             ishst
    // 0x1304294: StoreField: r2->field_7 = d2
    //     0x1304294: stur            d2, [x2, #7]
    // 0x1304298: r3 = LoadClassIdInstr(r1)
    //     0x1304298: ldur            x3, [x1, #-1]
    //     0x130429c: ubfx            x3, x3, #0xc, #0x14
    // 0x13042a0: stp             x0, x2, [SP]
    // 0x13042a4: mov             x0, x3
    // 0x13042a8: ldur            x2, [fp, #-0x18]
    // 0x13042ac: ldur            x3, [fp, #-0x20]
    // 0x13042b0: ldur            x5, [fp, #-0x28]
    // 0x13042b4: ldur            x6, [fp, #-0x30]
    // 0x13042b8: r4 = const [0, 0x7, 0x2, 0x5, blend, 0x5, blendMode, 0x6, null]
    //     0x13042b8: add             x4, PP, #0xb0, lsl #12  ; [pp+0xb0880] List(9) [0, 0x7, 0x2, 0x5, "blend", 0x5, "blendMode", 0x6, Null]
    //     0x13042bc: ldr             x4, [x4, #0x880]
    // 0x13042c0: r0 = GDT[cid_x0 + -0xfba]()
    //     0x13042c0: sub             lr, x0, #0xfba
    //     0x13042c4: ldr             lr, [x21, lr, lsl #3]
    //     0x13042c8: blr             lr
    // 0x13042cc: ldur            x0, [fp, #-0x18]
    // 0x13042d0: LoadField: r1 = r0->field_7
    //     0x13042d0: ldur            w1, [x0, #7]
    // 0x13042d4: DecompressPointer r1
    //     0x13042d4: add             x1, x1, HEAP, lsl #32
    // 0x13042d8: cmp             w1, NULL
    // 0x13042dc: b.eq            #0x130437c
    // 0x13042e0: LoadField: r2 = r1->field_7
    //     0x13042e0: ldur            x2, [x1, #7]
    // 0x13042e4: ldr             x1, [x2]
    // 0x13042e8: cbz             x1, #0x130432c
    // 0x13042ec: mov             x2, x1
    // 0x13042f0: stur            x2, [fp, #-0x38]
    // 0x13042f4: r1 = <Never>
    //     0x13042f4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x13042f8: r0 = Pointer()
    //     0x13042f8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x13042fc: mov             x1, x0
    // 0x1304300: ldur            x0, [fp, #-0x38]
    // 0x1304304: StoreField: r1->field_7 = r0
    //     0x1304304: stur            x0, [x1, #7]
    // 0x1304308: r0 = _restore$Method$FfiNative()
    //     0x1304308: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x130430c: r0 = Null
    //     0x130430c: mov             x0, NULL
    // 0x1304310: LeaveFrame
    //     0x1304310: mov             SP, fp
    //     0x1304314: ldp             fp, lr, [SP], #0x10
    // 0x1304318: ret
    //     0x1304318: ret             
    // 0x130431c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x130431c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1304320: str             x16, [SP]
    // 0x1304324: r0 = _throwNew()
    //     0x1304324: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1304328: brk             #0
    // 0x130432c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x130432c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1304330: str             x16, [SP]
    // 0x1304334: r0 = _throwNew()
    //     0x1304334: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1304338: brk             #0
    // 0x130433c: r0 = StackOverflowSharedWithFPURegs()
    //     0x130433c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1304340: b               #0x1304138
    // 0x1304344: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1304344: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1304348: stp             q0, q1, [SP, #-0x20]!
    // 0x130434c: stp             x4, x7, [SP, #-0x10]!
    // 0x1304350: r0 = AllocateDouble()
    //     0x1304350: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1304354: ldp             x4, x7, [SP], #0x10
    // 0x1304358: ldp             q0, q1, [SP], #0x20
    // 0x130435c: b               #0x13041f0
    // 0x1304360: SaveReg d2
    //     0x1304360: str             q2, [SP, #-0x10]!
    // 0x1304364: stp             x0, x1, [SP, #-0x10]!
    // 0x1304368: r0 = AllocateDouble()
    //     0x1304368: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130436c: mov             x2, x0
    // 0x1304370: ldp             x0, x1, [SP], #0x10
    // 0x1304374: RestoreReg d2
    //     0x1304374: ldr             q2, [SP], #0x10
    // 0x1304378: b               #0x1304294
    // 0x130437c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x130437c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2942, size: 0x18, field offset: 0x8
//   const constructor, 
class _BlendedDecorationImage extends Object
    implements DecorationImage {

  _ ==(/* No info */) {
    // ** addr: 0x1298b34, size: 0x158
    // 0x1298b34: EnterFrame
    //     0x1298b34: stp             fp, lr, [SP, #-0x10]!
    //     0x1298b38: mov             fp, SP
    // 0x1298b3c: AllocStack(0x10)
    //     0x1298b3c: sub             SP, SP, #0x10
    // 0x1298b40: CheckStackOverflow
    //     0x1298b40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1298b44: cmp             SP, x16
    //     0x1298b48: b.ls            #0x1298c84
    // 0x1298b4c: ldr             x0, [fp, #0x10]
    // 0x1298b50: cmp             w0, NULL
    // 0x1298b54: b.ne            #0x1298b68
    // 0x1298b58: r0 = false
    //     0x1298b58: add             x0, NULL, #0x30  ; false
    // 0x1298b5c: LeaveFrame
    //     0x1298b5c: mov             SP, fp
    //     0x1298b60: ldp             fp, lr, [SP], #0x10
    // 0x1298b64: ret
    //     0x1298b64: ret             
    // 0x1298b68: ldr             x1, [fp, #0x18]
    // 0x1298b6c: cmp             w1, w0
    // 0x1298b70: b.ne            #0x1298b84
    // 0x1298b74: r0 = true
    //     0x1298b74: add             x0, NULL, #0x20  ; true
    // 0x1298b78: LeaveFrame
    //     0x1298b78: mov             SP, fp
    //     0x1298b7c: ldp             fp, lr, [SP], #0x10
    // 0x1298b80: ret
    //     0x1298b80: ret             
    // 0x1298b84: str             x0, [SP]
    // 0x1298b88: r0 = runtimeType()
    //     0x1298b88: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1298b8c: r1 = LoadClassIdInstr(r0)
    //     0x1298b8c: ldur            x1, [x0, #-1]
    //     0x1298b90: ubfx            x1, x1, #0xc, #0x14
    // 0x1298b94: r16 = _BlendedDecorationImage
    //     0x1298b94: add             x16, PP, #0xab, lsl #12  ; [pp+0xab008] Type: _BlendedDecorationImage
    //     0x1298b98: ldr             x16, [x16, #8]
    // 0x1298b9c: stp             x16, x0, [SP]
    // 0x1298ba0: mov             x0, x1
    // 0x1298ba4: mov             lr, x0
    // 0x1298ba8: ldr             lr, [x21, lr, lsl #3]
    // 0x1298bac: blr             lr
    // 0x1298bb0: tbz             w0, #4, #0x1298bc4
    // 0x1298bb4: r0 = false
    //     0x1298bb4: add             x0, NULL, #0x30  ; false
    // 0x1298bb8: LeaveFrame
    //     0x1298bb8: mov             SP, fp
    //     0x1298bbc: ldp             fp, lr, [SP], #0x10
    // 0x1298bc0: ret
    //     0x1298bc0: ret             
    // 0x1298bc4: ldr             x1, [fp, #0x10]
    // 0x1298bc8: r0 = 60
    //     0x1298bc8: mov             x0, #0x3c
    // 0x1298bcc: branchIfSmi(r1, 0x1298bd8)
    //     0x1298bcc: tbz             w1, #0, #0x1298bd8
    // 0x1298bd0: r0 = LoadClassIdInstr(r1)
    //     0x1298bd0: ldur            x0, [x1, #-1]
    //     0x1298bd4: ubfx            x0, x0, #0xc, #0x14
    // 0x1298bd8: cmp             x0, #0xb7e
    // 0x1298bdc: b.ne            #0x1298c74
    // 0x1298be0: ldr             x2, [fp, #0x18]
    // 0x1298be4: LoadField: r0 = r1->field_7
    //     0x1298be4: ldur            w0, [x1, #7]
    // 0x1298be8: DecompressPointer r0
    //     0x1298be8: add             x0, x0, HEAP, lsl #32
    // 0x1298bec: LoadField: r3 = r2->field_7
    //     0x1298bec: ldur            w3, [x2, #7]
    // 0x1298bf0: DecompressPointer r3
    //     0x1298bf0: add             x3, x3, HEAP, lsl #32
    // 0x1298bf4: r4 = LoadClassIdInstr(r0)
    //     0x1298bf4: ldur            x4, [x0, #-1]
    //     0x1298bf8: ubfx            x4, x4, #0xc, #0x14
    // 0x1298bfc: stp             x3, x0, [SP]
    // 0x1298c00: mov             x0, x4
    // 0x1298c04: mov             lr, x0
    // 0x1298c08: ldr             lr, [x21, lr, lsl #3]
    // 0x1298c0c: blr             lr
    // 0x1298c10: tbnz            w0, #4, #0x1298c74
    // 0x1298c14: ldr             x2, [fp, #0x18]
    // 0x1298c18: ldr             x1, [fp, #0x10]
    // 0x1298c1c: LoadField: r0 = r1->field_b
    //     0x1298c1c: ldur            w0, [x1, #0xb]
    // 0x1298c20: DecompressPointer r0
    //     0x1298c20: add             x0, x0, HEAP, lsl #32
    // 0x1298c24: LoadField: r3 = r2->field_b
    //     0x1298c24: ldur            w3, [x2, #0xb]
    // 0x1298c28: DecompressPointer r3
    //     0x1298c28: add             x3, x3, HEAP, lsl #32
    // 0x1298c2c: r4 = LoadClassIdInstr(r0)
    //     0x1298c2c: ldur            x4, [x0, #-1]
    //     0x1298c30: ubfx            x4, x4, #0xc, #0x14
    // 0x1298c34: stp             x3, x0, [SP]
    // 0x1298c38: mov             x0, x4
    // 0x1298c3c: mov             lr, x0
    // 0x1298c40: ldr             lr, [x21, lr, lsl #3]
    // 0x1298c44: blr             lr
    // 0x1298c48: tbnz            w0, #4, #0x1298c74
    // 0x1298c4c: ldr             x2, [fp, #0x18]
    // 0x1298c50: ldr             x1, [fp, #0x10]
    // 0x1298c54: LoadField: d0 = r1->field_f
    //     0x1298c54: ldur            d0, [x1, #0xf]
    // 0x1298c58: LoadField: d1 = r2->field_f
    //     0x1298c58: ldur            d1, [x2, #0xf]
    // 0x1298c5c: fcmp            d0, d1
    // 0x1298c60: r16 = true
    //     0x1298c60: add             x16, NULL, #0x20  ; true
    // 0x1298c64: r17 = false
    //     0x1298c64: add             x17, NULL, #0x30  ; false
    // 0x1298c68: csel            x1, x16, x17, eq
    // 0x1298c6c: mov             x0, x1
    // 0x1298c70: b               #0x1298c78
    // 0x1298c74: r0 = false
    //     0x1298c74: add             x0, NULL, #0x30  ; false
    // 0x1298c78: LeaveFrame
    //     0x1298c78: mov             SP, fp
    //     0x1298c7c: ldp             fp, lr, [SP], #0x10
    // 0x1298c80: ret
    //     0x1298c80: ret             
    // 0x1298c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1298c84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1298c88: b               #0x1298b4c
  }
  _ createPainter(/* No info */) {
    // ** addr: 0x1303774, size: 0xe8
    // 0x1303774: EnterFrame
    //     0x1303774: stp             fp, lr, [SP, #-0x10]!
    //     0x1303778: mov             fp, SP
    // 0x130377c: AllocStack(0x20)
    //     0x130377c: sub             SP, SP, #0x20
    // 0x1303780: SetupParameters(_BlendedDecorationImage this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1303780: mov             x4, x1
    //     0x1303784: mov             x3, x2
    //     0x1303788: stur            x1, [fp, #-8]
    //     0x130378c: stur            x2, [fp, #-0x10]
    // 0x1303790: CheckStackOverflow
    //     0x1303790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303794: cmp             SP, x16
    //     0x1303798: b.ls            #0x1303854
    // 0x130379c: LoadField: r1 = r4->field_7
    //     0x130379c: ldur            w1, [x4, #7]
    // 0x13037a0: DecompressPointer r1
    //     0x13037a0: add             x1, x1, HEAP, lsl #32
    // 0x13037a4: cmp             w1, NULL
    // 0x13037a8: b.ne            #0x13037b8
    // 0x13037ac: mov             x3, x4
    // 0x13037b0: r4 = Null
    //     0x13037b0: mov             x4, NULL
    // 0x13037b4: b               #0x13037d8
    // 0x13037b8: r0 = LoadClassIdInstr(r1)
    //     0x13037b8: ldur            x0, [x1, #-1]
    //     0x13037bc: ubfx            x0, x0, #0xc, #0x14
    // 0x13037c0: mov             x2, x3
    // 0x13037c4: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x13037c4: sub             lr, x0, #0xfb3
    //     0x13037c8: ldr             lr, [x21, lr, lsl #3]
    //     0x13037cc: blr             lr
    // 0x13037d0: mov             x4, x0
    // 0x13037d4: ldur            x3, [fp, #-8]
    // 0x13037d8: stur            x4, [fp, #-0x18]
    // 0x13037dc: LoadField: r1 = r3->field_b
    //     0x13037dc: ldur            w1, [x3, #0xb]
    // 0x13037e0: DecompressPointer r1
    //     0x13037e0: add             x1, x1, HEAP, lsl #32
    // 0x13037e4: cmp             w1, NULL
    // 0x13037e8: b.ne            #0x13037fc
    // 0x13037ec: mov             x0, x3
    // 0x13037f0: mov             x1, x4
    // 0x13037f4: r2 = Null
    //     0x13037f4: mov             x2, NULL
    // 0x13037f8: b               #0x1303820
    // 0x13037fc: r0 = LoadClassIdInstr(r1)
    //     0x13037fc: ldur            x0, [x1, #-1]
    //     0x1303800: ubfx            x0, x0, #0xc, #0x14
    // 0x1303804: ldur            x2, [fp, #-0x10]
    // 0x1303808: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x1303808: sub             lr, x0, #0xfb3
    //     0x130380c: ldr             lr, [x21, lr, lsl #3]
    //     0x1303810: blr             lr
    // 0x1303814: mov             x2, x0
    // 0x1303818: ldur            x0, [fp, #-8]
    // 0x130381c: ldur            x1, [fp, #-0x18]
    // 0x1303820: stur            x2, [fp, #-0x10]
    // 0x1303824: LoadField: d0 = r0->field_f
    //     0x1303824: ldur            d0, [x0, #0xf]
    // 0x1303828: stur            d0, [fp, #-0x20]
    // 0x130382c: r0 = _BlendedDecorationImagePainter()
    //     0x130382c: bl              #0x130385c  ; Allocate_BlendedDecorationImagePainterStub -> _BlendedDecorationImagePainter (size=0x18)
    // 0x1303830: ldur            x1, [fp, #-0x18]
    // 0x1303834: StoreField: r0->field_7 = r1
    //     0x1303834: stur            w1, [x0, #7]
    // 0x1303838: ldur            x1, [fp, #-0x10]
    // 0x130383c: StoreField: r0->field_b = r1
    //     0x130383c: stur            w1, [x0, #0xb]
    // 0x1303840: ldur            d0, [fp, #-0x20]
    // 0x1303844: StoreField: r0->field_f = d0
    //     0x1303844: stur            d0, [x0, #0xf]
    // 0x1303848: LeaveFrame
    //     0x1303848: mov             SP, fp
    //     0x130384c: ldp             fp, lr, [SP], #0x10
    // 0x1303850: ret
    //     0x1303850: ret             
    // 0x1303854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1303854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1303858: b               #0x130379c
  }
  get _ invertColors(/* No info */) {
    // ** addr: 0x1304380, size: 0x9c
    // 0x1304380: EnterFrame
    //     0x1304380: stp             fp, lr, [SP, #-0x10]!
    //     0x1304384: mov             fp, SP
    // 0x1304388: AllocStack(0x8)
    //     0x1304388: sub             SP, SP, #8
    // 0x130438c: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x130438c: mov             x2, x1
    //     0x1304390: stur            x1, [fp, #-8]
    // 0x1304394: CheckStackOverflow
    //     0x1304394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304398: cmp             SP, x16
    //     0x130439c: b.ls            #0x1304410
    // 0x13043a0: LoadField: r1 = r2->field_b
    //     0x13043a0: ldur            w1, [x2, #0xb]
    // 0x13043a4: DecompressPointer r1
    //     0x13043a4: add             x1, x1, HEAP, lsl #32
    // 0x13043a8: cmp             w1, NULL
    // 0x13043ac: b.ne            #0x13043b8
    // 0x13043b0: r0 = Null
    //     0x13043b0: mov             x0, NULL
    // 0x13043b4: b               #0x13043d0
    // 0x13043b8: r0 = LoadClassIdInstr(r1)
    //     0x13043b8: ldur            x0, [x1, #-1]
    //     0x13043bc: ubfx            x0, x0, #0xc, #0x14
    // 0x13043c0: r0 = GDT[cid_x0 + -0xfd7]()
    //     0x13043c0: sub             lr, x0, #0xfd7
    //     0x13043c4: ldr             lr, [x21, lr, lsl #3]
    //     0x13043c8: blr             lr
    // 0x13043cc: r0 = false
    //     0x13043cc: add             x0, NULL, #0x30  ; false
    // 0x13043d0: cmp             w0, NULL
    // 0x13043d4: b.ne            #0x1304404
    // 0x13043d8: ldur            x0, [fp, #-8]
    // 0x13043dc: LoadField: r1 = r0->field_7
    //     0x13043dc: ldur            w1, [x0, #7]
    // 0x13043e0: DecompressPointer r1
    //     0x13043e0: add             x1, x1, HEAP, lsl #32
    // 0x13043e4: cmp             w1, NULL
    // 0x13043e8: b.eq            #0x1304418
    // 0x13043ec: r0 = LoadClassIdInstr(r1)
    //     0x13043ec: ldur            x0, [x1, #-1]
    //     0x13043f0: ubfx            x0, x0, #0xc, #0x14
    // 0x13043f4: r0 = GDT[cid_x0 + -0xfd7]()
    //     0x13043f4: sub             lr, x0, #0xfd7
    //     0x13043f8: ldr             lr, [x21, lr, lsl #3]
    //     0x13043fc: blr             lr
    // 0x1304400: r0 = false
    //     0x1304400: add             x0, NULL, #0x30  ; false
    // 0x1304404: LeaveFrame
    //     0x1304404: mov             SP, fp
    //     0x1304408: ldp             fp, lr, [SP], #0x10
    // 0x130440c: ret
    //     0x130440c: ret             
    // 0x1304410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304414: b               #0x13043a0
    // 0x1304418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ alignment(/* No info */) {
    // ** addr: 0x130441c, size: 0x94
    // 0x130441c: EnterFrame
    //     0x130441c: stp             fp, lr, [SP, #-0x10]!
    //     0x1304420: mov             fp, SP
    // 0x1304424: AllocStack(0x8)
    //     0x1304424: sub             SP, SP, #8
    // 0x1304428: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304428: mov             x2, x1
    //     0x130442c: stur            x1, [fp, #-8]
    // 0x1304430: CheckStackOverflow
    //     0x1304430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304434: cmp             SP, x16
    //     0x1304438: b.ls            #0x13044a4
    // 0x130443c: LoadField: r1 = r2->field_b
    //     0x130443c: ldur            w1, [x2, #0xb]
    // 0x1304440: DecompressPointer r1
    //     0x1304440: add             x1, x1, HEAP, lsl #32
    // 0x1304444: cmp             w1, NULL
    // 0x1304448: b.ne            #0x1304454
    // 0x130444c: r0 = Null
    //     0x130444c: mov             x0, NULL
    // 0x1304450: b               #0x1304468
    // 0x1304454: r0 = LoadClassIdInstr(r1)
    //     0x1304454: ldur            x0, [x1, #-1]
    //     0x1304458: ubfx            x0, x0, #0xc, #0x14
    // 0x130445c: r0 = GDT[cid_x0 + -0xfd8]()
    //     0x130445c: sub             lr, x0, #0xfd8
    //     0x1304460: ldr             lr, [x21, lr, lsl #3]
    //     0x1304464: blr             lr
    // 0x1304468: cmp             w0, NULL
    // 0x130446c: b.ne            #0x1304498
    // 0x1304470: ldur            x0, [fp, #-8]
    // 0x1304474: LoadField: r1 = r0->field_7
    //     0x1304474: ldur            w1, [x0, #7]
    // 0x1304478: DecompressPointer r1
    //     0x1304478: add             x1, x1, HEAP, lsl #32
    // 0x130447c: cmp             w1, NULL
    // 0x1304480: b.eq            #0x13044ac
    // 0x1304484: r0 = LoadClassIdInstr(r1)
    //     0x1304484: ldur            x0, [x1, #-1]
    //     0x1304488: ubfx            x0, x0, #0xc, #0x14
    // 0x130448c: r0 = GDT[cid_x0 + -0xfd8]()
    //     0x130448c: sub             lr, x0, #0xfd8
    //     0x1304490: ldr             lr, [x21, lr, lsl #3]
    //     0x1304494: blr             lr
    // 0x1304498: LeaveFrame
    //     0x1304498: mov             SP, fp
    //     0x130449c: ldp             fp, lr, [SP], #0x10
    // 0x13044a0: ret
    //     0x13044a0: ret             
    // 0x13044a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13044a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13044a8: b               #0x130443c
    // 0x13044ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13044ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ fit(/* No info */) {
    // ** addr: 0x13044b0, size: 0x94
    // 0x13044b0: EnterFrame
    //     0x13044b0: stp             fp, lr, [SP, #-0x10]!
    //     0x13044b4: mov             fp, SP
    // 0x13044b8: AllocStack(0x8)
    //     0x13044b8: sub             SP, SP, #8
    // 0x13044bc: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x13044bc: mov             x2, x1
    //     0x13044c0: stur            x1, [fp, #-8]
    // 0x13044c4: CheckStackOverflow
    //     0x13044c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13044c8: cmp             SP, x16
    //     0x13044cc: b.ls            #0x1304538
    // 0x13044d0: LoadField: r1 = r2->field_b
    //     0x13044d0: ldur            w1, [x2, #0xb]
    // 0x13044d4: DecompressPointer r1
    //     0x13044d4: add             x1, x1, HEAP, lsl #32
    // 0x13044d8: cmp             w1, NULL
    // 0x13044dc: b.ne            #0x13044e8
    // 0x13044e0: r0 = Null
    //     0x13044e0: mov             x0, NULL
    // 0x13044e4: b               #0x13044fc
    // 0x13044e8: r0 = LoadClassIdInstr(r1)
    //     0x13044e8: ldur            x0, [x1, #-1]
    //     0x13044ec: ubfx            x0, x0, #0xc, #0x14
    // 0x13044f0: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x13044f0: sub             lr, x0, #0xfd9
    //     0x13044f4: ldr             lr, [x21, lr, lsl #3]
    //     0x13044f8: blr             lr
    // 0x13044fc: cmp             w0, NULL
    // 0x1304500: b.ne            #0x130452c
    // 0x1304504: ldur            x0, [fp, #-8]
    // 0x1304508: LoadField: r1 = r0->field_7
    //     0x1304508: ldur            w1, [x0, #7]
    // 0x130450c: DecompressPointer r1
    //     0x130450c: add             x1, x1, HEAP, lsl #32
    // 0x1304510: cmp             w1, NULL
    // 0x1304514: b.eq            #0x1304540
    // 0x1304518: r0 = LoadClassIdInstr(r1)
    //     0x1304518: ldur            x0, [x1, #-1]
    //     0x130451c: ubfx            x0, x0, #0xc, #0x14
    // 0x1304520: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x1304520: sub             lr, x0, #0xfd9
    //     0x1304524: ldr             lr, [x21, lr, lsl #3]
    //     0x1304528: blr             lr
    // 0x130452c: LeaveFrame
    //     0x130452c: mov             SP, fp
    //     0x1304530: ldp             fp, lr, [SP], #0x10
    // 0x1304534: ret
    //     0x1304534: ret             
    // 0x1304538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130453c: b               #0x13044d0
    // 0x1304540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304540: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ opacity(/* No info */) {
    // ** addr: 0x130454c, size: 0xa8
    // 0x130454c: EnterFrame
    //     0x130454c: stp             fp, lr, [SP, #-0x10]!
    //     0x1304550: mov             fp, SP
    // 0x1304554: AllocStack(0x8)
    //     0x1304554: sub             SP, SP, #8
    // 0x1304558: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304558: mov             x2, x1
    //     0x130455c: stur            x1, [fp, #-8]
    // 0x1304560: CheckStackOverflow
    //     0x1304560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304564: cmp             SP, x16
    //     0x1304568: b.ls            #0x13045e8
    // 0x130456c: LoadField: r1 = r2->field_b
    //     0x130456c: ldur            w1, [x2, #0xb]
    // 0x1304570: DecompressPointer r1
    //     0x1304570: add             x1, x1, HEAP, lsl #32
    // 0x1304574: cmp             w1, NULL
    // 0x1304578: b.ne            #0x1304584
    // 0x130457c: r0 = Null
    //     0x130457c: mov             x0, NULL
    // 0x1304580: b               #0x130459c
    // 0x1304584: r0 = LoadClassIdInstr(r1)
    //     0x1304584: ldur            x0, [x1, #-1]
    //     0x1304588: ubfx            x0, x0, #0xc, #0x14
    // 0x130458c: r0 = GDT[cid_x0 + -0xfdd]()
    //     0x130458c: sub             lr, x0, #0xfdd
    //     0x1304590: ldr             lr, [x21, lr, lsl #3]
    //     0x1304594: blr             lr
    // 0x1304598: r0 = 1.000000
    //     0x1304598: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x130459c: cmp             w0, NULL
    // 0x13045a0: b.ne            #0x13045d4
    // 0x13045a4: ldur            x0, [fp, #-8]
    // 0x13045a8: LoadField: r1 = r0->field_7
    //     0x13045a8: ldur            w1, [x0, #7]
    // 0x13045ac: DecompressPointer r1
    //     0x13045ac: add             x1, x1, HEAP, lsl #32
    // 0x13045b0: cmp             w1, NULL
    // 0x13045b4: b.eq            #0x13045f0
    // 0x13045b8: r0 = LoadClassIdInstr(r1)
    //     0x13045b8: ldur            x0, [x1, #-1]
    //     0x13045bc: ubfx            x0, x0, #0xc, #0x14
    // 0x13045c0: r0 = GDT[cid_x0 + -0xfdd]()
    //     0x13045c0: sub             lr, x0, #0xfdd
    //     0x13045c4: ldr             lr, [x21, lr, lsl #3]
    //     0x13045c8: blr             lr
    // 0x13045cc: d0 = 1.000000
    //     0x13045cc: fmov            d0, #1.00000000
    // 0x13045d0: b               #0x13045dc
    // 0x13045d4: LoadField: d1 = r0->field_7
    //     0x13045d4: ldur            d1, [x0, #7]
    // 0x13045d8: mov             v0.16b, v1.16b
    // 0x13045dc: LeaveFrame
    //     0x13045dc: mov             SP, fp
    //     0x13045e0: ldp             fp, lr, [SP], #0x10
    // 0x13045e4: ret
    //     0x13045e4: ret             
    // 0x13045e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13045e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13045ec: b               #0x130456c
    // 0x13045f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13045f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ colorFilter(/* No info */) {
    // ** addr: 0x13045f4, size: 0x90
    // 0x13045f4: EnterFrame
    //     0x13045f4: stp             fp, lr, [SP, #-0x10]!
    //     0x13045f8: mov             fp, SP
    // 0x13045fc: AllocStack(0x8)
    //     0x13045fc: sub             SP, SP, #8
    // 0x1304600: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304600: mov             x2, x1
    //     0x1304604: stur            x1, [fp, #-8]
    // 0x1304608: CheckStackOverflow
    //     0x1304608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130460c: cmp             SP, x16
    //     0x1304610: b.ls            #0x1304678
    // 0x1304614: LoadField: r1 = r2->field_b
    //     0x1304614: ldur            w1, [x2, #0xb]
    // 0x1304618: DecompressPointer r1
    //     0x1304618: add             x1, x1, HEAP, lsl #32
    // 0x130461c: cmp             w1, NULL
    // 0x1304620: b.ne            #0x130462c
    // 0x1304624: mov             x0, x2
    // 0x1304628: b               #0x1304644
    // 0x130462c: r0 = LoadClassIdInstr(r1)
    //     0x130462c: ldur            x0, [x1, #-1]
    //     0x1304630: ubfx            x0, x0, #0xc, #0x14
    // 0x1304634: r0 = GDT[cid_x0 + -0xfde]()
    //     0x1304634: sub             lr, x0, #0xfde
    //     0x1304638: ldr             lr, [x21, lr, lsl #3]
    //     0x130463c: blr             lr
    // 0x1304640: ldur            x0, [fp, #-8]
    // 0x1304644: LoadField: r1 = r0->field_7
    //     0x1304644: ldur            w1, [x0, #7]
    // 0x1304648: DecompressPointer r1
    //     0x1304648: add             x1, x1, HEAP, lsl #32
    // 0x130464c: cmp             w1, NULL
    // 0x1304650: b.eq            #0x1304680
    // 0x1304654: r0 = LoadClassIdInstr(r1)
    //     0x1304654: ldur            x0, [x1, #-1]
    //     0x1304658: ubfx            x0, x0, #0xc, #0x14
    // 0x130465c: r0 = GDT[cid_x0 + -0xfde]()
    //     0x130465c: sub             lr, x0, #0xfde
    //     0x1304660: ldr             lr, [x21, lr, lsl #3]
    //     0x1304664: blr             lr
    // 0x1304668: r0 = Null
    //     0x1304668: mov             x0, NULL
    // 0x130466c: LeaveFrame
    //     0x130466c: mov             SP, fp
    //     0x1304670: ldp             fp, lr, [SP], #0x10
    // 0x1304674: ret
    //     0x1304674: ret             
    // 0x1304678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130467c: b               #0x1304614
    // 0x1304680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304680: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ image(/* No info */) {
    // ** addr: 0x1304684, size: 0x94
    // 0x1304684: EnterFrame
    //     0x1304684: stp             fp, lr, [SP, #-0x10]!
    //     0x1304688: mov             fp, SP
    // 0x130468c: AllocStack(0x8)
    //     0x130468c: sub             SP, SP, #8
    // 0x1304690: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304690: mov             x2, x1
    //     0x1304694: stur            x1, [fp, #-8]
    // 0x1304698: CheckStackOverflow
    //     0x1304698: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130469c: cmp             SP, x16
    //     0x13046a0: b.ls            #0x130470c
    // 0x13046a4: LoadField: r1 = r2->field_b
    //     0x13046a4: ldur            w1, [x2, #0xb]
    // 0x13046a8: DecompressPointer r1
    //     0x13046a8: add             x1, x1, HEAP, lsl #32
    // 0x13046ac: cmp             w1, NULL
    // 0x13046b0: b.ne            #0x13046bc
    // 0x13046b4: r0 = Null
    //     0x13046b4: mov             x0, NULL
    // 0x13046b8: b               #0x13046d0
    // 0x13046bc: r0 = LoadClassIdInstr(r1)
    //     0x13046bc: ldur            x0, [x1, #-1]
    //     0x13046c0: ubfx            x0, x0, #0xc, #0x14
    // 0x13046c4: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x13046c4: sub             lr, x0, #0xfdf
    //     0x13046c8: ldr             lr, [x21, lr, lsl #3]
    //     0x13046cc: blr             lr
    // 0x13046d0: cmp             w0, NULL
    // 0x13046d4: b.ne            #0x1304700
    // 0x13046d8: ldur            x0, [fp, #-8]
    // 0x13046dc: LoadField: r1 = r0->field_7
    //     0x13046dc: ldur            w1, [x0, #7]
    // 0x13046e0: DecompressPointer r1
    //     0x13046e0: add             x1, x1, HEAP, lsl #32
    // 0x13046e4: cmp             w1, NULL
    // 0x13046e8: b.eq            #0x1304714
    // 0x13046ec: r0 = LoadClassIdInstr(r1)
    //     0x13046ec: ldur            x0, [x1, #-1]
    //     0x13046f0: ubfx            x0, x0, #0xc, #0x14
    // 0x13046f4: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x13046f4: sub             lr, x0, #0xfdf
    //     0x13046f8: ldr             lr, [x21, lr, lsl #3]
    //     0x13046fc: blr             lr
    // 0x1304700: LeaveFrame
    //     0x1304700: mov             SP, fp
    //     0x1304704: ldp             fp, lr, [SP], #0x10
    // 0x1304708: ret
    //     0x1304708: ret             
    // 0x130470c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130470c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304710: b               #0x13046a4
    // 0x1304714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ centerSlice(/* No info */) {
    // ** addr: 0x1304718, size: 0x90
    // 0x1304718: EnterFrame
    //     0x1304718: stp             fp, lr, [SP, #-0x10]!
    //     0x130471c: mov             fp, SP
    // 0x1304720: AllocStack(0x8)
    //     0x1304720: sub             SP, SP, #8
    // 0x1304724: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304724: mov             x2, x1
    //     0x1304728: stur            x1, [fp, #-8]
    // 0x130472c: CheckStackOverflow
    //     0x130472c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304730: cmp             SP, x16
    //     0x1304734: b.ls            #0x130479c
    // 0x1304738: LoadField: r1 = r2->field_b
    //     0x1304738: ldur            w1, [x2, #0xb]
    // 0x130473c: DecompressPointer r1
    //     0x130473c: add             x1, x1, HEAP, lsl #32
    // 0x1304740: cmp             w1, NULL
    // 0x1304744: b.ne            #0x1304750
    // 0x1304748: mov             x0, x2
    // 0x130474c: b               #0x1304768
    // 0x1304750: r0 = LoadClassIdInstr(r1)
    //     0x1304750: ldur            x0, [x1, #-1]
    //     0x1304754: ubfx            x0, x0, #0xc, #0x14
    // 0x1304758: r0 = GDT[cid_x0 + -0xfe3]()
    //     0x1304758: sub             lr, x0, #0xfe3
    //     0x130475c: ldr             lr, [x21, lr, lsl #3]
    //     0x1304760: blr             lr
    // 0x1304764: ldur            x0, [fp, #-8]
    // 0x1304768: LoadField: r1 = r0->field_7
    //     0x1304768: ldur            w1, [x0, #7]
    // 0x130476c: DecompressPointer r1
    //     0x130476c: add             x1, x1, HEAP, lsl #32
    // 0x1304770: cmp             w1, NULL
    // 0x1304774: b.eq            #0x13047a4
    // 0x1304778: r0 = LoadClassIdInstr(r1)
    //     0x1304778: ldur            x0, [x1, #-1]
    //     0x130477c: ubfx            x0, x0, #0xc, #0x14
    // 0x1304780: r0 = GDT[cid_x0 + -0xfe3]()
    //     0x1304780: sub             lr, x0, #0xfe3
    //     0x1304784: ldr             lr, [x21, lr, lsl #3]
    //     0x1304788: blr             lr
    // 0x130478c: r0 = Null
    //     0x130478c: mov             x0, NULL
    // 0x1304790: LeaveFrame
    //     0x1304790: mov             SP, fp
    //     0x1304794: ldp             fp, lr, [SP], #0x10
    // 0x1304798: ret
    //     0x1304798: ret             
    // 0x130479c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130479c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13047a0: b               #0x1304738
    // 0x13047a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13047a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ repeat(/* No info */) {
    // ** addr: 0x13047a8, size: 0x94
    // 0x13047a8: EnterFrame
    //     0x13047a8: stp             fp, lr, [SP, #-0x10]!
    //     0x13047ac: mov             fp, SP
    // 0x13047b0: AllocStack(0x8)
    //     0x13047b0: sub             SP, SP, #8
    // 0x13047b4: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x13047b4: mov             x2, x1
    //     0x13047b8: stur            x1, [fp, #-8]
    // 0x13047bc: CheckStackOverflow
    //     0x13047bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13047c0: cmp             SP, x16
    //     0x13047c4: b.ls            #0x1304830
    // 0x13047c8: LoadField: r1 = r2->field_b
    //     0x13047c8: ldur            w1, [x2, #0xb]
    // 0x13047cc: DecompressPointer r1
    //     0x13047cc: add             x1, x1, HEAP, lsl #32
    // 0x13047d0: cmp             w1, NULL
    // 0x13047d4: b.ne            #0x13047e0
    // 0x13047d8: r0 = Null
    //     0x13047d8: mov             x0, NULL
    // 0x13047dc: b               #0x13047f4
    // 0x13047e0: r0 = LoadClassIdInstr(r1)
    //     0x13047e0: ldur            x0, [x1, #-1]
    //     0x13047e4: ubfx            x0, x0, #0xc, #0x14
    // 0x13047e8: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x13047e8: sub             lr, x0, #0xfe4
    //     0x13047ec: ldr             lr, [x21, lr, lsl #3]
    //     0x13047f0: blr             lr
    // 0x13047f4: cmp             w0, NULL
    // 0x13047f8: b.ne            #0x1304824
    // 0x13047fc: ldur            x0, [fp, #-8]
    // 0x1304800: LoadField: r1 = r0->field_7
    //     0x1304800: ldur            w1, [x0, #7]
    // 0x1304804: DecompressPointer r1
    //     0x1304804: add             x1, x1, HEAP, lsl #32
    // 0x1304808: cmp             w1, NULL
    // 0x130480c: b.eq            #0x1304838
    // 0x1304810: r0 = LoadClassIdInstr(r1)
    //     0x1304810: ldur            x0, [x1, #-1]
    //     0x1304814: ubfx            x0, x0, #0xc, #0x14
    // 0x1304818: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x1304818: sub             lr, x0, #0xfe4
    //     0x130481c: ldr             lr, [x21, lr, lsl #3]
    //     0x1304820: blr             lr
    // 0x1304824: LeaveFrame
    //     0x1304824: mov             SP, fp
    //     0x1304828: ldp             fp, lr, [SP], #0x10
    // 0x130482c: ret
    //     0x130482c: ret             
    // 0x1304830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304834: b               #0x13047c8
    // 0x1304838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304838: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ matchTextDirection(/* No info */) {
    // ** addr: 0x130483c, size: 0x9c
    // 0x130483c: EnterFrame
    //     0x130483c: stp             fp, lr, [SP, #-0x10]!
    //     0x1304840: mov             fp, SP
    // 0x1304844: AllocStack(0x8)
    //     0x1304844: sub             SP, SP, #8
    // 0x1304848: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304848: mov             x2, x1
    //     0x130484c: stur            x1, [fp, #-8]
    // 0x1304850: CheckStackOverflow
    //     0x1304850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304854: cmp             SP, x16
    //     0x1304858: b.ls            #0x13048cc
    // 0x130485c: LoadField: r1 = r2->field_b
    //     0x130485c: ldur            w1, [x2, #0xb]
    // 0x1304860: DecompressPointer r1
    //     0x1304860: add             x1, x1, HEAP, lsl #32
    // 0x1304864: cmp             w1, NULL
    // 0x1304868: b.ne            #0x1304874
    // 0x130486c: r0 = Null
    //     0x130486c: mov             x0, NULL
    // 0x1304870: b               #0x130488c
    // 0x1304874: r0 = LoadClassIdInstr(r1)
    //     0x1304874: ldur            x0, [x1, #-1]
    //     0x1304878: ubfx            x0, x0, #0xc, #0x14
    // 0x130487c: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x130487c: sub             lr, x0, #0xfe5
    //     0x1304880: ldr             lr, [x21, lr, lsl #3]
    //     0x1304884: blr             lr
    // 0x1304888: r0 = false
    //     0x1304888: add             x0, NULL, #0x30  ; false
    // 0x130488c: cmp             w0, NULL
    // 0x1304890: b.ne            #0x13048c0
    // 0x1304894: ldur            x0, [fp, #-8]
    // 0x1304898: LoadField: r1 = r0->field_7
    //     0x1304898: ldur            w1, [x0, #7]
    // 0x130489c: DecompressPointer r1
    //     0x130489c: add             x1, x1, HEAP, lsl #32
    // 0x13048a0: cmp             w1, NULL
    // 0x13048a4: b.eq            #0x13048d4
    // 0x13048a8: r0 = LoadClassIdInstr(r1)
    //     0x13048a8: ldur            x0, [x1, #-1]
    //     0x13048ac: ubfx            x0, x0, #0xc, #0x14
    // 0x13048b0: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x13048b0: sub             lr, x0, #0xfe5
    //     0x13048b4: ldr             lr, [x21, lr, lsl #3]
    //     0x13048b8: blr             lr
    // 0x13048bc: r0 = false
    //     0x13048bc: add             x0, NULL, #0x30  ; false
    // 0x13048c0: LeaveFrame
    //     0x13048c0: mov             SP, fp
    //     0x13048c4: ldp             fp, lr, [SP], #0x10
    // 0x13048c8: ret
    //     0x13048c8: ret             
    // 0x13048cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13048cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13048d0: b               #0x130485c
    // 0x13048d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13048d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ filterQuality(/* No info */) {
    // ** addr: 0x13048f8, size: 0xa4
    // 0x13048f8: EnterFrame
    //     0x13048f8: stp             fp, lr, [SP, #-0x10]!
    //     0x13048fc: mov             fp, SP
    // 0x1304900: AllocStack(0x8)
    //     0x1304900: sub             SP, SP, #8
    // 0x1304904: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304904: mov             x2, x1
    //     0x1304908: stur            x1, [fp, #-8]
    // 0x130490c: CheckStackOverflow
    //     0x130490c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304910: cmp             SP, x16
    //     0x1304914: b.ls            #0x1304990
    // 0x1304918: LoadField: r1 = r2->field_b
    //     0x1304918: ldur            w1, [x2, #0xb]
    // 0x130491c: DecompressPointer r1
    //     0x130491c: add             x1, x1, HEAP, lsl #32
    // 0x1304920: cmp             w1, NULL
    // 0x1304924: b.ne            #0x1304930
    // 0x1304928: r0 = Null
    //     0x1304928: mov             x0, NULL
    // 0x130492c: b               #0x130494c
    // 0x1304930: r0 = LoadClassIdInstr(r1)
    //     0x1304930: ldur            x0, [x1, #-1]
    //     0x1304934: ubfx            x0, x0, #0xc, #0x14
    // 0x1304938: r0 = GDT[cid_x0 + -0xfe9]()
    //     0x1304938: sub             lr, x0, #0xfe9
    //     0x130493c: ldr             lr, [x21, lr, lsl #3]
    //     0x1304940: blr             lr
    // 0x1304944: r0 = Instance_FilterQuality
    //     0x1304944: add             x0, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0x1304948: ldr             x0, [x0, #0xfc0]
    // 0x130494c: cmp             w0, NULL
    // 0x1304950: b.ne            #0x1304984
    // 0x1304954: ldur            x0, [fp, #-8]
    // 0x1304958: LoadField: r1 = r0->field_7
    //     0x1304958: ldur            w1, [x0, #7]
    // 0x130495c: DecompressPointer r1
    //     0x130495c: add             x1, x1, HEAP, lsl #32
    // 0x1304960: cmp             w1, NULL
    // 0x1304964: b.eq            #0x1304998
    // 0x1304968: r0 = LoadClassIdInstr(r1)
    //     0x1304968: ldur            x0, [x1, #-1]
    //     0x130496c: ubfx            x0, x0, #0xc, #0x14
    // 0x1304970: r0 = GDT[cid_x0 + -0xfe9]()
    //     0x1304970: sub             lr, x0, #0xfe9
    //     0x1304974: ldr             lr, [x21, lr, lsl #3]
    //     0x1304978: blr             lr
    // 0x130497c: r0 = Instance_FilterQuality
    //     0x130497c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0x1304980: ldr             x0, [x0, #0xfc0]
    // 0x1304984: LeaveFrame
    //     0x1304984: mov             SP, fp
    //     0x1304988: ldp             fp, lr, [SP], #0x10
    // 0x130498c: ret
    //     0x130498c: ret             
    // 0x1304990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304994: b               #0x1304918
    // 0x1304998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304998: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ scale(/* No info */) {
    // ** addr: 0x130499c, size: 0xa8
    // 0x130499c: EnterFrame
    //     0x130499c: stp             fp, lr, [SP, #-0x10]!
    //     0x13049a0: mov             fp, SP
    // 0x13049a4: AllocStack(0x8)
    //     0x13049a4: sub             SP, SP, #8
    // 0x13049a8: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x13049a8: mov             x2, x1
    //     0x13049ac: stur            x1, [fp, #-8]
    // 0x13049b0: CheckStackOverflow
    //     0x13049b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13049b4: cmp             SP, x16
    //     0x13049b8: b.ls            #0x1304a38
    // 0x13049bc: LoadField: r1 = r2->field_b
    //     0x13049bc: ldur            w1, [x2, #0xb]
    // 0x13049c0: DecompressPointer r1
    //     0x13049c0: add             x1, x1, HEAP, lsl #32
    // 0x13049c4: cmp             w1, NULL
    // 0x13049c8: b.ne            #0x13049d4
    // 0x13049cc: r0 = Null
    //     0x13049cc: mov             x0, NULL
    // 0x13049d0: b               #0x13049ec
    // 0x13049d4: r0 = LoadClassIdInstr(r1)
    //     0x13049d4: ldur            x0, [x1, #-1]
    //     0x13049d8: ubfx            x0, x0, #0xc, #0x14
    // 0x13049dc: r0 = GDT[cid_x0 + -0xfea]()
    //     0x13049dc: sub             lr, x0, #0xfea
    //     0x13049e0: ldr             lr, [x21, lr, lsl #3]
    //     0x13049e4: blr             lr
    // 0x13049e8: r0 = 1.000000
    //     0x13049e8: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x13049ec: cmp             w0, NULL
    // 0x13049f0: b.ne            #0x1304a24
    // 0x13049f4: ldur            x0, [fp, #-8]
    // 0x13049f8: LoadField: r1 = r0->field_7
    //     0x13049f8: ldur            w1, [x0, #7]
    // 0x13049fc: DecompressPointer r1
    //     0x13049fc: add             x1, x1, HEAP, lsl #32
    // 0x1304a00: cmp             w1, NULL
    // 0x1304a04: b.eq            #0x1304a40
    // 0x1304a08: r0 = LoadClassIdInstr(r1)
    //     0x1304a08: ldur            x0, [x1, #-1]
    //     0x1304a0c: ubfx            x0, x0, #0xc, #0x14
    // 0x1304a10: r0 = GDT[cid_x0 + -0xfea]()
    //     0x1304a10: sub             lr, x0, #0xfea
    //     0x1304a14: ldr             lr, [x21, lr, lsl #3]
    //     0x1304a18: blr             lr
    // 0x1304a1c: d0 = 1.000000
    //     0x1304a1c: fmov            d0, #1.00000000
    // 0x1304a20: b               #0x1304a2c
    // 0x1304a24: LoadField: d1 = r0->field_7
    //     0x1304a24: ldur            d1, [x0, #7]
    // 0x1304a28: mov             v0.16b, v1.16b
    // 0x1304a2c: LeaveFrame
    //     0x1304a2c: mov             SP, fp
    //     0x1304a30: ldp             fp, lr, [SP], #0x10
    // 0x1304a34: ret
    //     0x1304a34: ret             
    // 0x1304a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304a3c: b               #0x13049bc
    // 0x1304a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304a40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ isAntiAlias(/* No info */) {
    // ** addr: 0x1304a44, size: 0x9c
    // 0x1304a44: EnterFrame
    //     0x1304a44: stp             fp, lr, [SP, #-0x10]!
    //     0x1304a48: mov             fp, SP
    // 0x1304a4c: AllocStack(0x8)
    //     0x1304a4c: sub             SP, SP, #8
    // 0x1304a50: SetupParameters(_BlendedDecorationImage this /* r1 => r2, fp-0x8 */)
    //     0x1304a50: mov             x2, x1
    //     0x1304a54: stur            x1, [fp, #-8]
    // 0x1304a58: CheckStackOverflow
    //     0x1304a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1304a5c: cmp             SP, x16
    //     0x1304a60: b.ls            #0x1304ad4
    // 0x1304a64: LoadField: r1 = r2->field_b
    //     0x1304a64: ldur            w1, [x2, #0xb]
    // 0x1304a68: DecompressPointer r1
    //     0x1304a68: add             x1, x1, HEAP, lsl #32
    // 0x1304a6c: cmp             w1, NULL
    // 0x1304a70: b.ne            #0x1304a7c
    // 0x1304a74: r0 = Null
    //     0x1304a74: mov             x0, NULL
    // 0x1304a78: b               #0x1304a94
    // 0x1304a7c: r0 = LoadClassIdInstr(r1)
    //     0x1304a7c: ldur            x0, [x1, #-1]
    //     0x1304a80: ubfx            x0, x0, #0xc, #0x14
    // 0x1304a84: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x1304a84: sub             lr, x0, #0xfeb
    //     0x1304a88: ldr             lr, [x21, lr, lsl #3]
    //     0x1304a8c: blr             lr
    // 0x1304a90: r0 = false
    //     0x1304a90: add             x0, NULL, #0x30  ; false
    // 0x1304a94: cmp             w0, NULL
    // 0x1304a98: b.ne            #0x1304ac8
    // 0x1304a9c: ldur            x0, [fp, #-8]
    // 0x1304aa0: LoadField: r1 = r0->field_7
    //     0x1304aa0: ldur            w1, [x0, #7]
    // 0x1304aa4: DecompressPointer r1
    //     0x1304aa4: add             x1, x1, HEAP, lsl #32
    // 0x1304aa8: cmp             w1, NULL
    // 0x1304aac: b.eq            #0x1304adc
    // 0x1304ab0: r0 = LoadClassIdInstr(r1)
    //     0x1304ab0: ldur            x0, [x1, #-1]
    //     0x1304ab4: ubfx            x0, x0, #0xc, #0x14
    // 0x1304ab8: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x1304ab8: sub             lr, x0, #0xfeb
    //     0x1304abc: ldr             lr, [x21, lr, lsl #3]
    //     0x1304ac0: blr             lr
    // 0x1304ac4: r0 = false
    //     0x1304ac4: add             x0, NULL, #0x30  ; false
    // 0x1304ac8: LeaveFrame
    //     0x1304ac8: mov             SP, fp
    //     0x1304acc: ldp             fp, lr, [SP], #0x10
    // 0x1304ad0: ret
    //     0x1304ad0: ret             
    // 0x1304ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1304ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1304ad8: b               #0x1304a64
    // 0x1304adc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1304adc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2943, size: 0x18, field offset: 0x8
class _DecorationImagePainter extends Object
    implements DecorationImagePainter {

  _ dispose(/* No info */) {
    // ** addr: 0x13038b4, size: 0xa4
    // 0x13038b4: EnterFrame
    //     0x13038b4: stp             fp, lr, [SP, #-0x10]!
    //     0x13038b8: mov             fp, SP
    // 0x13038bc: AllocStack(0x18)
    //     0x13038bc: sub             SP, SP, #0x18
    // 0x13038c0: SetupParameters(_DecorationImagePainter this /* r1 => r2, fp-0x10 */)
    //     0x13038c0: mov             x2, x1
    //     0x13038c4: stur            x1, [fp, #-0x10]
    // 0x13038c8: CheckStackOverflow
    //     0x13038c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13038cc: cmp             SP, x16
    //     0x13038d0: b.ls            #0x1303950
    // 0x13038d4: LoadField: r1 = r2->field_f
    //     0x13038d4: ldur            w1, [x2, #0xf]
    // 0x13038d8: DecompressPointer r1
    //     0x13038d8: add             x1, x1, HEAP, lsl #32
    // 0x13038dc: stur            x1, [fp, #-8]
    // 0x13038e0: cmp             w1, NULL
    // 0x13038e4: b.ne            #0x13038f0
    // 0x13038e8: mov             x0, x2
    // 0x13038ec: b               #0x130391c
    // 0x13038f0: r0 = ImageStreamListener()
    //     0x13038f0: bl              #0xd097b8  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0x13038f4: ldur            x2, [fp, #-0x10]
    // 0x13038f8: r1 = Function '_handleImage@795297748':.
    //     0x13038f8: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0870] AnonymousClosure: (0x1303958), in [package:flutter/src/painting/decoration_image.dart] _DecorationImagePainter::_handleImage (0x1303998)
    //     0x13038fc: ldr             x1, [x1, #0x870]
    // 0x1303900: stur            x0, [fp, #-0x18]
    // 0x1303904: r0 = AllocateClosure()
    //     0x1303904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1303908: ldur            x2, [fp, #-0x18]
    // 0x130390c: StoreField: r2->field_7 = r0
    //     0x130390c: stur            w0, [x2, #7]
    // 0x1303910: ldur            x1, [fp, #-8]
    // 0x1303914: r0 = removeListener()
    //     0x1303914: bl              #0xd09490  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0x1303918: ldur            x0, [fp, #-0x10]
    // 0x130391c: LoadField: r1 = r0->field_13
    //     0x130391c: ldur            w1, [x0, #0x13]
    // 0x1303920: DecompressPointer r1
    //     0x1303920: add             x1, x1, HEAP, lsl #32
    // 0x1303924: cmp             w1, NULL
    // 0x1303928: b.ne            #0x1303934
    // 0x130392c: mov             x1, x0
    // 0x1303930: b               #0x130393c
    // 0x1303934: r0 = dispose()
    //     0x1303934: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0x1303938: ldur            x1, [fp, #-0x10]
    // 0x130393c: StoreField: r1->field_13 = rNULL
    //     0x130393c: stur            NULL, [x1, #0x13]
    // 0x1303940: r0 = Null
    //     0x1303940: mov             x0, NULL
    // 0x1303944: LeaveFrame
    //     0x1303944: mov             SP, fp
    //     0x1303948: ldp             fp, lr, [SP], #0x10
    // 0x130394c: ret
    //     0x130394c: ret             
    // 0x1303950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1303950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1303954: b               #0x13038d4
  }
  [closure] void _handleImage(dynamic, ImageInfo, bool) {
    // ** addr: 0x1303958, size: 0x40
    // 0x1303958: EnterFrame
    //     0x1303958: stp             fp, lr, [SP, #-0x10]!
    //     0x130395c: mov             fp, SP
    // 0x1303960: ldr             x0, [fp, #0x20]
    // 0x1303964: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1303964: ldur            w1, [x0, #0x17]
    // 0x1303968: DecompressPointer r1
    //     0x1303968: add             x1, x1, HEAP, lsl #32
    // 0x130396c: CheckStackOverflow
    //     0x130396c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303970: cmp             SP, x16
    //     0x1303974: b.ls            #0x1303990
    // 0x1303978: ldr             x2, [fp, #0x18]
    // 0x130397c: ldr             x3, [fp, #0x10]
    // 0x1303980: r0 = _handleImage()
    //     0x1303980: bl              #0x1303998  ; [package:flutter/src/painting/decoration_image.dart] _DecorationImagePainter::_handleImage
    // 0x1303984: LeaveFrame
    //     0x1303984: mov             SP, fp
    //     0x1303988: ldp             fp, lr, [SP], #0x10
    // 0x130398c: ret
    //     0x130398c: ret             
    // 0x1303990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1303990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1303994: b               #0x1303978
  }
  _ _handleImage(/* No info */) {
    // ** addr: 0x1303998, size: 0x110
    // 0x1303998: EnterFrame
    //     0x1303998: stp             fp, lr, [SP, #-0x10]!
    //     0x130399c: mov             fp, SP
    // 0x13039a0: AllocStack(0x28)
    //     0x13039a0: sub             SP, SP, #0x28
    // 0x13039a4: SetupParameters(_DecorationImagePainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x13039a4: stur            x1, [fp, #-8]
    //     0x13039a8: stur            x2, [fp, #-0x10]
    //     0x13039ac: stur            x3, [fp, #-0x18]
    // 0x13039b0: CheckStackOverflow
    //     0x13039b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13039b4: cmp             SP, x16
    //     0x13039b8: b.ls            #0x1303aa0
    // 0x13039bc: LoadField: r0 = r1->field_13
    //     0x13039bc: ldur            w0, [x1, #0x13]
    // 0x13039c0: DecompressPointer r0
    //     0x13039c0: add             x0, x0, HEAP, lsl #32
    // 0x13039c4: r4 = LoadClassIdInstr(r0)
    //     0x13039c4: ldur            x4, [x0, #-1]
    //     0x13039c8: ubfx            x4, x4, #0xc, #0x14
    // 0x13039cc: stp             x2, x0, [SP]
    // 0x13039d0: mov             x0, x4
    // 0x13039d4: mov             lr, x0
    // 0x13039d8: ldr             lr, [x21, lr, lsl #3]
    // 0x13039dc: blr             lr
    // 0x13039e0: tbnz            w0, #4, #0x13039f4
    // 0x13039e4: r0 = Null
    //     0x13039e4: mov             x0, NULL
    // 0x13039e8: LeaveFrame
    //     0x13039e8: mov             SP, fp
    //     0x13039ec: ldp             fp, lr, [SP], #0x10
    // 0x13039f0: ret
    //     0x13039f0: ret             
    // 0x13039f4: ldur            x0, [fp, #-8]
    // 0x13039f8: LoadField: r1 = r0->field_13
    //     0x13039f8: ldur            w1, [x0, #0x13]
    // 0x13039fc: DecompressPointer r1
    //     0x13039fc: add             x1, x1, HEAP, lsl #32
    // 0x1303a00: cmp             w1, NULL
    // 0x1303a04: b.eq            #0x1303a2c
    // 0x1303a08: ldur            x2, [fp, #-0x10]
    // 0x1303a0c: r0 = isCloneOf()
    //     0x1303a0c: bl              #0x1303aa8  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::isCloneOf
    // 0x1303a10: tbnz            w0, #4, #0x1303a2c
    // 0x1303a14: ldur            x1, [fp, #-0x10]
    // 0x1303a18: r0 = dispose()
    //     0x1303a18: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0x1303a1c: r0 = Null
    //     0x1303a1c: mov             x0, NULL
    // 0x1303a20: LeaveFrame
    //     0x1303a20: mov             SP, fp
    //     0x1303a24: ldp             fp, lr, [SP], #0x10
    // 0x1303a28: ret
    //     0x1303a28: ret             
    // 0x1303a2c: ldur            x0, [fp, #-8]
    // 0x1303a30: LoadField: r1 = r0->field_13
    //     0x1303a30: ldur            w1, [x0, #0x13]
    // 0x1303a34: DecompressPointer r1
    //     0x1303a34: add             x1, x1, HEAP, lsl #32
    // 0x1303a38: cmp             w1, NULL
    // 0x1303a3c: b.ne            #0x1303a48
    // 0x1303a40: mov             x1, x0
    // 0x1303a44: b               #0x1303a50
    // 0x1303a48: r0 = dispose()
    //     0x1303a48: bl              #0xd08b2c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0x1303a4c: ldur            x1, [fp, #-8]
    // 0x1303a50: ldur            x2, [fp, #-0x18]
    // 0x1303a54: ldur            x0, [fp, #-0x10]
    // 0x1303a58: StoreField: r1->field_13 = r0
    //     0x1303a58: stur            w0, [x1, #0x13]
    //     0x1303a5c: ldurb           w16, [x1, #-1]
    //     0x1303a60: ldurb           w17, [x0, #-1]
    //     0x1303a64: and             x16, x17, x16, lsr #2
    //     0x1303a68: tst             x16, HEAP, lsr #32
    //     0x1303a6c: b.eq            #0x1303a74
    //     0x1303a70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1303a74: tbz             w2, #4, #0x1303a90
    // 0x1303a78: LoadField: r0 = r1->field_b
    //     0x1303a78: ldur            w0, [x1, #0xb]
    // 0x1303a7c: DecompressPointer r0
    //     0x1303a7c: add             x0, x0, HEAP, lsl #32
    // 0x1303a80: str             x0, [SP]
    // 0x1303a84: ClosureCall
    //     0x1303a84: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x1303a88: ldur            x2, [x0, #0x1f]
    //     0x1303a8c: blr             x2
    // 0x1303a90: r0 = Null
    //     0x1303a90: mov             x0, NULL
    // 0x1303a94: LeaveFrame
    //     0x1303a94: mov             SP, fp
    //     0x1303a98: ldp             fp, lr, [SP], #0x10
    // 0x1303a9c: ret
    //     0x1303a9c: ret             
    // 0x1303aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1303aa0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1303aa4: b               #0x13039bc
  }
  _ paint(/* No info */) {
    // ** addr: 0x1303b3c, size: 0x4a8
    // 0x1303b3c: EnterFrame
    //     0x1303b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x1303b40: mov             fp, SP
    // 0x1303b44: AllocStack(0x98)
    //     0x1303b44: sub             SP, SP, #0x98
    // 0x1303b48: SetupParameters(_DecorationImagePainter this /* r1 => r6, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, dynamic _ /* r5 => r5, fp-0x30 */, dynamic _ /* r6 => r2 */, {_Double blend = 1.000000 /* d0, fp-0x50 */, dynamic blendMode = Instance_BlendMode /* r4, fp-0x10 */})
    //     0x1303b48: mov             x0, x2
    //     0x1303b4c: stur            x2, [fp, #-0x20]
    //     0x1303b50: mov             x2, x6
    //     0x1303b54: mov             x6, x1
    //     0x1303b58: stur            x1, [fp, #-0x18]
    //     0x1303b5c: stur            x3, [fp, #-0x28]
    //     0x1303b60: stur            x5, [fp, #-0x30]
    //     0x1303b64: ldur            w1, [x4, #0x13]
    //     0x1303b68: ldur            w7, [x4, #0x1f]
    //     0x1303b6c: add             x7, x7, HEAP, lsl #32
    //     0x1303b70: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b300] "blend"
    //     0x1303b74: ldr             x16, [x16, #0x300]
    //     0x1303b78: cmp             w7, w16
    //     0x1303b7c: b.ne            #0x1303ba0
    //     0x1303b80: ldur            w7, [x4, #0x23]
    //     0x1303b84: add             x7, x7, HEAP, lsl #32
    //     0x1303b88: sub             w8, w1, w7
    //     0x1303b8c: add             x7, fp, w8, sxtw #2
    //     0x1303b90: ldr             x7, [x7, #8]
    //     0x1303b94: ldur            d0, [x7, #7]
    //     0x1303b98: mov             x7, #1
    //     0x1303b9c: b               #0x1303ba8
    //     0x1303ba0: fmov            d0, #1.00000000
    //     0x1303ba4: mov             x7, #0
    //     0x1303ba8: stur            d0, [fp, #-0x50]
    //     0x1303bac: lsl             x8, x7, #1
    //     0x1303bb0: lsl             w7, w8, #1
    //     0x1303bb4: add             w8, w7, #8
    //     0x1303bb8: add             x16, x4, w8, sxtw #1
    //     0x1303bbc: ldur            w9, [x16, #0xf]
    //     0x1303bc0: add             x9, x9, HEAP, lsl #32
    //     0x1303bc4: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1378] "blendMode"
    //     0x1303bc8: ldr             x16, [x16, #0x378]
    //     0x1303bcc: cmp             w9, w16
    //     0x1303bd0: b.ne            #0x1303bf8
    //     0x1303bd4: add             w8, w7, #0xa
    //     0x1303bd8: add             x16, x4, w8, sxtw #1
    //     0x1303bdc: ldur            w7, [x16, #0xf]
    //     0x1303be0: add             x7, x7, HEAP, lsl #32
    //     0x1303be4: sub             w4, w1, w7
    //     0x1303be8: add             x1, fp, w4, sxtw #2
    //     0x1303bec: ldr             x1, [x1, #8]
    //     0x1303bf0: mov             x4, x1
    //     0x1303bf4: b               #0x1303c00
    //     0x1303bf8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0x1303bfc: ldr             x4, [x4, #0xeb8]
    //     0x1303c00: stur            x4, [fp, #-0x10]
    // 0x1303c04: CheckStackOverflow
    //     0x1303c04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303c08: cmp             SP, x16
    //     0x1303c0c: b.ls            #0x1303f70
    // 0x1303c10: LoadField: r7 = r6->field_7
    //     0x1303c10: ldur            w7, [x6, #7]
    // 0x1303c14: DecompressPointer r7
    //     0x1303c14: add             x7, x7, HEAP, lsl #32
    // 0x1303c18: stur            x7, [fp, #-8]
    // 0x1303c1c: LoadField: r1 = r7->field_7
    //     0x1303c1c: ldur            w1, [x7, #7]
    // 0x1303c20: DecompressPointer r1
    //     0x1303c20: add             x1, x1, HEAP, lsl #32
    // 0x1303c24: r0 = resolve()
    //     0x1303c24: bl              #0x919dcc  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve
    // 0x1303c28: mov             x1, x0
    // 0x1303c2c: stur            x1, [fp, #-0x38]
    // 0x1303c30: LoadField: r0 = r1->field_7
    //     0x1303c30: ldur            w0, [x1, #7]
    // 0x1303c34: DecompressPointer r0
    //     0x1303c34: add             x0, x0, HEAP, lsl #32
    // 0x1303c38: cmp             w0, NULL
    // 0x1303c3c: b.ne            #0x1303c44
    // 0x1303c40: mov             x0, x1
    // 0x1303c44: ldur            x2, [fp, #-0x18]
    // 0x1303c48: LoadField: r3 = r2->field_f
    //     0x1303c48: ldur            w3, [x2, #0xf]
    // 0x1303c4c: DecompressPointer r3
    //     0x1303c4c: add             x3, x3, HEAP, lsl #32
    // 0x1303c50: cmp             w3, NULL
    // 0x1303c54: b.ne            #0x1303c60
    // 0x1303c58: r3 = Null
    //     0x1303c58: mov             x3, NULL
    // 0x1303c5c: b               #0x1303c74
    // 0x1303c60: LoadField: r4 = r3->field_7
    //     0x1303c60: ldur            w4, [x3, #7]
    // 0x1303c64: DecompressPointer r4
    //     0x1303c64: add             x4, x4, HEAP, lsl #32
    // 0x1303c68: cmp             w4, NULL
    // 0x1303c6c: b.eq            #0x1303c74
    // 0x1303c70: mov             x3, x4
    // 0x1303c74: r4 = 60
    //     0x1303c74: mov             x4, #0x3c
    // 0x1303c78: branchIfSmi(r0, 0x1303c84)
    //     0x1303c78: tbz             w0, #0, #0x1303c84
    // 0x1303c7c: r4 = LoadClassIdInstr(r0)
    //     0x1303c7c: ldur            x4, [x0, #-1]
    //     0x1303c80: ubfx            x4, x4, #0xc, #0x14
    // 0x1303c84: stp             x3, x0, [SP]
    // 0x1303c88: mov             x0, x4
    // 0x1303c8c: mov             lr, x0
    // 0x1303c90: ldr             lr, [x21, lr, lsl #3]
    // 0x1303c94: blr             lr
    // 0x1303c98: tbz             w0, #4, #0x1303d10
    // 0x1303c9c: ldur            x2, [fp, #-0x18]
    // 0x1303ca0: r0 = ImageStreamListener()
    //     0x1303ca0: bl              #0xd097b8  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0x1303ca4: ldur            x2, [fp, #-0x18]
    // 0x1303ca8: r1 = Function '_handleImage@795297748':.
    //     0x1303ca8: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0870] AnonymousClosure: (0x1303958), in [package:flutter/src/painting/decoration_image.dart] _DecorationImagePainter::_handleImage (0x1303998)
    //     0x1303cac: ldr             x1, [x1, #0x870]
    // 0x1303cb0: stur            x0, [fp, #-0x40]
    // 0x1303cb4: r0 = AllocateClosure()
    //     0x1303cb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1303cb8: mov             x1, x0
    // 0x1303cbc: ldur            x0, [fp, #-0x40]
    // 0x1303cc0: StoreField: r0->field_7 = r1
    //     0x1303cc0: stur            w1, [x0, #7]
    // 0x1303cc4: ldur            x3, [fp, #-0x18]
    // 0x1303cc8: LoadField: r1 = r3->field_f
    //     0x1303cc8: ldur            w1, [x3, #0xf]
    // 0x1303ccc: DecompressPointer r1
    //     0x1303ccc: add             x1, x1, HEAP, lsl #32
    // 0x1303cd0: cmp             w1, NULL
    // 0x1303cd4: b.eq            #0x1303ce4
    // 0x1303cd8: mov             x2, x0
    // 0x1303cdc: r0 = removeListener()
    //     0x1303cdc: bl              #0xd09490  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0x1303ce0: ldur            x3, [fp, #-0x18]
    // 0x1303ce4: ldur            x0, [fp, #-0x38]
    // 0x1303ce8: StoreField: r3->field_f = r0
    //     0x1303ce8: stur            w0, [x3, #0xf]
    //     0x1303cec: ldurb           w16, [x3, #-1]
    //     0x1303cf0: ldurb           w17, [x0, #-1]
    //     0x1303cf4: and             x16, x17, x16, lsr #2
    //     0x1303cf8: tst             x16, HEAP, lsr #32
    //     0x1303cfc: b.eq            #0x1303d04
    //     0x1303d00: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1303d04: ldur            x1, [fp, #-0x38]
    // 0x1303d08: ldur            x2, [fp, #-0x40]
    // 0x1303d0c: r0 = addListener()
    //     0x1303d0c: bl              #0xd07ce0  ; [package:flutter/src/painting/image_stream.dart] ImageStream::addListener
    // 0x1303d10: ldur            x0, [fp, #-0x18]
    // 0x1303d14: LoadField: r1 = r0->field_13
    //     0x1303d14: ldur            w1, [x0, #0x13]
    // 0x1303d18: DecompressPointer r1
    //     0x1303d18: add             x1, x1, HEAP, lsl #32
    // 0x1303d1c: cmp             w1, NULL
    // 0x1303d20: b.ne            #0x1303d34
    // 0x1303d24: r0 = Null
    //     0x1303d24: mov             x0, NULL
    // 0x1303d28: LeaveFrame
    //     0x1303d28: mov             SP, fp
    //     0x1303d2c: ldp             fp, lr, [SP], #0x10
    // 0x1303d30: ret
    //     0x1303d30: ret             
    // 0x1303d34: ldur            x2, [fp, #-0x30]
    // 0x1303d38: cmp             w2, NULL
    // 0x1303d3c: b.eq            #0x1303e0c
    // 0x1303d40: ldur            x3, [fp, #-0x20]
    // 0x1303d44: LoadField: r1 = r3->field_7
    //     0x1303d44: ldur            w1, [x3, #7]
    // 0x1303d48: DecompressPointer r1
    //     0x1303d48: add             x1, x1, HEAP, lsl #32
    // 0x1303d4c: cmp             w1, NULL
    // 0x1303d50: b.eq            #0x1303f78
    // 0x1303d54: LoadField: r4 = r1->field_7
    //     0x1303d54: ldur            x4, [x1, #7]
    // 0x1303d58: ldr             x1, [x4]
    // 0x1303d5c: cbz             x1, #0x1303f40
    // 0x1303d60: mov             x4, x1
    // 0x1303d64: stur            x4, [fp, #-0x48]
    // 0x1303d68: r1 = <Never>
    //     0x1303d68: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1303d6c: r0 = Pointer()
    //     0x1303d6c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1303d70: mov             x1, x0
    // 0x1303d74: ldur            x0, [fp, #-0x48]
    // 0x1303d78: StoreField: r1->field_7 = r0
    //     0x1303d78: stur            x0, [x1, #7]
    // 0x1303d7c: r0 = _save$Method$FfiNative()
    //     0x1303d7c: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x1303d80: ldur            x0, [fp, #-0x20]
    // 0x1303d84: LoadField: r1 = r0->field_7
    //     0x1303d84: ldur            w1, [x0, #7]
    // 0x1303d88: DecompressPointer r1
    //     0x1303d88: add             x1, x1, HEAP, lsl #32
    // 0x1303d8c: cmp             w1, NULL
    // 0x1303d90: b.eq            #0x1303f7c
    // 0x1303d94: LoadField: r2 = r1->field_7
    //     0x1303d94: ldur            x2, [x1, #7]
    // 0x1303d98: ldr             x1, [x2]
    // 0x1303d9c: cbz             x1, #0x1303f50
    // 0x1303da0: ldur            x2, [fp, #-0x30]
    // 0x1303da4: mov             x3, x1
    // 0x1303da8: stur            x3, [fp, #-0x48]
    // 0x1303dac: r1 = <Never>
    //     0x1303dac: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1303db0: r0 = Pointer()
    //     0x1303db0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1303db4: mov             x2, x0
    // 0x1303db8: ldur            x0, [fp, #-0x48]
    // 0x1303dbc: stur            x2, [fp, #-0x38]
    // 0x1303dc0: StoreField: r2->field_7 = r0
    //     0x1303dc0: stur            x0, [x2, #7]
    // 0x1303dc4: ldur            x0, [fp, #-0x30]
    // 0x1303dc8: LoadField: r1 = r0->field_7
    //     0x1303dc8: ldur            w1, [x0, #7]
    // 0x1303dcc: DecompressPointer r1
    //     0x1303dcc: add             x1, x1, HEAP, lsl #32
    // 0x1303dd0: cmp             w1, NULL
    // 0x1303dd4: b.eq            #0x1303f80
    // 0x1303dd8: LoadField: r3 = r1->field_7
    //     0x1303dd8: ldur            x3, [x1, #7]
    // 0x1303ddc: ldr             x1, [x3]
    // 0x1303de0: mov             x3, x1
    // 0x1303de4: stur            x3, [fp, #-0x48]
    // 0x1303de8: r1 = <Never>
    //     0x1303de8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1303dec: r0 = Pointer()
    //     0x1303dec: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1303df0: mov             x1, x0
    // 0x1303df4: ldur            x0, [fp, #-0x48]
    // 0x1303df8: StoreField: r1->field_7 = r0
    //     0x1303df8: stur            x0, [x1, #7]
    // 0x1303dfc: mov             x2, x1
    // 0x1303e00: ldur            x1, [fp, #-0x38]
    // 0x1303e04: r3 = true
    //     0x1303e04: add             x3, NULL, #0x20  ; true
    // 0x1303e08: r0 = __clipPath$Method$FfiNative()
    //     0x1303e08: bl              #0xc1ac40  ; [dart:ui] _NativeCanvas::__clipPath$Method$FfiNative
    // 0x1303e0c: ldur            x1, [fp, #-0x18]
    // 0x1303e10: ldur            x0, [fp, #-0x30]
    // 0x1303e14: ldur            d0, [fp, #-0x50]
    // 0x1303e18: ldur            x2, [fp, #-8]
    // 0x1303e1c: LoadField: r3 = r1->field_13
    //     0x1303e1c: ldur            w3, [x1, #0x13]
    // 0x1303e20: DecompressPointer r3
    //     0x1303e20: add             x3, x3, HEAP, lsl #32
    // 0x1303e24: cmp             w3, NULL
    // 0x1303e28: b.eq            #0x1303f84
    // 0x1303e2c: LoadField: r1 = r3->field_7
    //     0x1303e2c: ldur            w1, [x3, #7]
    // 0x1303e30: DecompressPointer r1
    //     0x1303e30: add             x1, x1, HEAP, lsl #32
    // 0x1303e34: LoadField: d1 = r3->field_b
    //     0x1303e34: ldur            d1, [x3, #0xb]
    // 0x1303e38: LoadField: r3 = r2->field_13
    //     0x1303e38: ldur            w3, [x2, #0x13]
    // 0x1303e3c: DecompressPointer r3
    //     0x1303e3c: add             x3, x3, HEAP, lsl #32
    // 0x1303e40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1303e40: ldur            w4, [x2, #0x17]
    // 0x1303e44: DecompressPointer r4
    //     0x1303e44: add             x4, x4, HEAP, lsl #32
    // 0x1303e48: LoadField: r5 = r2->field_1f
    //     0x1303e48: ldur            w5, [x2, #0x1f]
    // 0x1303e4c: DecompressPointer r5
    //     0x1303e4c: add             x5, x5, HEAP, lsl #32
    // 0x1303e50: r2 = inline_Allocate_Double()
    //     0x1303e50: ldp             x2, x6, [THR, #0x60]  ; THR::top
    //     0x1303e54: add             x2, x2, #0x10
    //     0x1303e58: cmp             x6, x2
    //     0x1303e5c: b.ls            #0x1303f88
    //     0x1303e60: str             x2, [THR, #0x60]  ; THR::top
    //     0x1303e64: sub             x2, x2, #0xf
    //     0x1303e68: mov             x6, #0xe19c
    //     0x1303e6c: movk            x6, #3, lsl #16
    //     0x1303e70: stur            x6, [x2, #-1]
    // 0x1303e74: dmb             ishst
    // 0x1303e78: StoreField: r2->field_7 = d1
    //     0x1303e78: stur            d1, [x2, #7]
    // 0x1303e7c: r6 = inline_Allocate_Double()
    //     0x1303e7c: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x1303e80: add             x6, x6, #0x10
    //     0x1303e84: cmp             x7, x6
    //     0x1303e88: b.ls            #0x1303fb4
    //     0x1303e8c: str             x6, [THR, #0x60]  ; THR::top
    //     0x1303e90: sub             x6, x6, #0xf
    //     0x1303e94: mov             x7, #0xe19c
    //     0x1303e98: movk            x7, #3, lsl #16
    //     0x1303e9c: stur            x7, [x6, #-1]
    // 0x1303ea0: dmb             ishst
    // 0x1303ea4: StoreField: r6->field_7 = d0
    //     0x1303ea4: stur            d0, [x6, #7]
    // 0x1303ea8: stp             NULL, x2, [SP, #0x38]
    // 0x1303eac: stp             x4, x3, [SP, #0x28]
    // 0x1303eb0: stp             x6, x5, [SP, #0x18]
    // 0x1303eb4: r16 = Instance_FilterQuality
    //     0x1303eb4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0x1303eb8: ldr             x16, [x16, #0xfc0]
    // 0x1303ebc: r30 = false
    //     0x1303ebc: add             lr, NULL, #0x30  ; false
    // 0x1303ec0: stp             lr, x16, [SP, #8]
    // 0x1303ec4: ldur            x16, [fp, #-0x10]
    // 0x1303ec8: str             x16, [SP]
    // 0x1303ecc: mov             x2, x1
    // 0x1303ed0: ldur            x1, [fp, #-0x20]
    // 0x1303ed4: ldur            x3, [fp, #-0x28]
    // 0x1303ed8: r4 = const [0, 0xc, 0x9, 0x3, alignment, 0x6, blendMode, 0xb, colorFilter, 0x4, filterQuality, 0x9, fit, 0x5, invertColors, 0xa, opacity, 0x8, repeat, 0x7, scale, 0x3, null]
    //     0x1303ed8: add             x4, PP, #0xb0, lsl #12  ; [pp+0xb0878] List(23) [0, 0xc, 0x9, 0x3, "alignment", 0x6, "blendMode", 0xb, "colorFilter", 0x4, "filterQuality", 0x9, "fit", 0x5, "invertColors", 0xa, "opacity", 0x8, "repeat", 0x7, "scale", 0x3, Null]
    //     0x1303edc: ldr             x4, [x4, #0x878]
    // 0x1303ee0: r0 = paintImage()
    //     0x1303ee0: bl              #0xb88fd8  ; [package:flutter/src/painting/decoration_image.dart] ::paintImage
    // 0x1303ee4: ldur            x0, [fp, #-0x30]
    // 0x1303ee8: cmp             w0, NULL
    // 0x1303eec: b.eq            #0x1303f30
    // 0x1303ef0: ldur            x0, [fp, #-0x20]
    // 0x1303ef4: LoadField: r1 = r0->field_7
    //     0x1303ef4: ldur            w1, [x0, #7]
    // 0x1303ef8: DecompressPointer r1
    //     0x1303ef8: add             x1, x1, HEAP, lsl #32
    // 0x1303efc: cmp             w1, NULL
    // 0x1303f00: b.eq            #0x1303fe0
    // 0x1303f04: LoadField: r2 = r1->field_7
    //     0x1303f04: ldur            x2, [x1, #7]
    // 0x1303f08: ldr             x1, [x2]
    // 0x1303f0c: cbz             x1, #0x1303f60
    // 0x1303f10: mov             x2, x1
    // 0x1303f14: stur            x2, [fp, #-0x48]
    // 0x1303f18: r1 = <Never>
    //     0x1303f18: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1303f1c: r0 = Pointer()
    //     0x1303f1c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1303f20: mov             x1, x0
    // 0x1303f24: ldur            x0, [fp, #-0x48]
    // 0x1303f28: StoreField: r1->field_7 = r0
    //     0x1303f28: stur            x0, [x1, #7]
    // 0x1303f2c: r0 = _restore$Method$FfiNative()
    //     0x1303f2c: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x1303f30: r0 = Null
    //     0x1303f30: mov             x0, NULL
    // 0x1303f34: LeaveFrame
    //     0x1303f34: mov             SP, fp
    //     0x1303f38: ldp             fp, lr, [SP], #0x10
    // 0x1303f3c: ret
    //     0x1303f3c: ret             
    // 0x1303f40: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1303f40: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1303f44: str             x16, [SP]
    // 0x1303f48: r0 = _throwNew()
    //     0x1303f48: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1303f4c: brk             #0
    // 0x1303f50: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1303f50: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1303f54: str             x16, [SP]
    // 0x1303f58: r0 = _throwNew()
    //     0x1303f58: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1303f5c: brk             #0
    // 0x1303f60: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1303f60: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1303f64: str             x16, [SP]
    // 0x1303f68: r0 = _throwNew()
    //     0x1303f68: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1303f6c: brk             #0
    // 0x1303f70: r0 = StackOverflowSharedWithFPURegs()
    //     0x1303f70: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1303f74: b               #0x1303c10
    // 0x1303f78: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1303f78: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1303f7c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1303f7c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1303f80: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1303f80: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1303f84: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1303f84: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x1303f88: stp             q0, q1, [SP, #-0x20]!
    // 0x1303f8c: stp             x4, x5, [SP, #-0x10]!
    // 0x1303f90: stp             x1, x3, [SP, #-0x10]!
    // 0x1303f94: SaveReg r0
    //     0x1303f94: str             x0, [SP, #-8]!
    // 0x1303f98: r0 = AllocateDouble()
    //     0x1303f98: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1303f9c: mov             x2, x0
    // 0x1303fa0: RestoreReg r0
    //     0x1303fa0: ldr             x0, [SP], #8
    // 0x1303fa4: ldp             x1, x3, [SP], #0x10
    // 0x1303fa8: ldp             x4, x5, [SP], #0x10
    // 0x1303fac: ldp             q0, q1, [SP], #0x20
    // 0x1303fb0: b               #0x1303e78
    // 0x1303fb4: SaveReg d0
    //     0x1303fb4: str             q0, [SP, #-0x10]!
    // 0x1303fb8: stp             x4, x5, [SP, #-0x10]!
    // 0x1303fbc: stp             x2, x3, [SP, #-0x10]!
    // 0x1303fc0: stp             x0, x1, [SP, #-0x10]!
    // 0x1303fc4: r0 = AllocateDouble()
    //     0x1303fc4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1303fc8: mov             x6, x0
    // 0x1303fcc: ldp             x0, x1, [SP], #0x10
    // 0x1303fd0: ldp             x2, x3, [SP], #0x10
    // 0x1303fd4: ldp             x4, x5, [SP], #0x10
    // 0x1303fd8: RestoreReg d0
    //     0x1303fd8: ldr             q0, [SP], #0x10
    // 0x1303fdc: b               #0x1303ea4
    // 0x1303fe0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1303fe0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2944, size: 0x8, field offset: 0x8
abstract class DecorationImagePainter extends Object {
}

// class id: 2945, size: 0x44, field offset: 0x8
//   const constructor, 
class DecorationImage extends Object {

  AssetImage field_8;
  BoxFit field_14;
  Alignment field_18;
  ImageRepeat field_20;
  bool field_24;
  _Double field_28;
  _Double field_30;
  FilterQuality field_38;
  bool field_3c;
  bool field_40;

  get _ hashCode(/* No info */) {
    // ** addr: 0x114baa0, size: 0xa8
    // 0x114baa0: EnterFrame
    //     0x114baa0: stp             fp, lr, [SP, #-0x10]!
    //     0x114baa4: mov             fp, SP
    // 0x114baa8: AllocStack(0x50)
    //     0x114baa8: sub             SP, SP, #0x50
    // 0x114baac: CheckStackOverflow
    //     0x114baac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114bab0: cmp             SP, x16
    //     0x114bab4: b.ls            #0x114bb40
    // 0x114bab8: ldr             x0, [fp, #0x10]
    // 0x114babc: LoadField: r1 = r0->field_7
    //     0x114babc: ldur            w1, [x0, #7]
    // 0x114bac0: DecompressPointer r1
    //     0x114bac0: add             x1, x1, HEAP, lsl #32
    // 0x114bac4: LoadField: r2 = r0->field_13
    //     0x114bac4: ldur            w2, [x0, #0x13]
    // 0x114bac8: DecompressPointer r2
    //     0x114bac8: add             x2, x2, HEAP, lsl #32
    // 0x114bacc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x114bacc: ldur            w3, [x0, #0x17]
    // 0x114bad0: DecompressPointer r3
    //     0x114bad0: add             x3, x3, HEAP, lsl #32
    // 0x114bad4: LoadField: r4 = r0->field_1f
    //     0x114bad4: ldur            w4, [x0, #0x1f]
    // 0x114bad8: DecompressPointer r4
    //     0x114bad8: add             x4, x4, HEAP, lsl #32
    // 0x114badc: stp             x3, x2, [SP, #0x40]
    // 0x114bae0: stp             x4, NULL, [SP, #0x30]
    // 0x114bae4: r16 = false
    //     0x114bae4: add             x16, NULL, #0x30  ; false
    // 0x114bae8: r30 = 1.000000
    //     0x114bae8: ldr             lr, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x114baec: stp             lr, x16, [SP, #0x20]
    // 0x114baf0: r16 = 1.000000
    //     0x114baf0: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x114baf4: r30 = Instance_FilterQuality
    //     0x114baf4: add             lr, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0x114baf8: ldr             lr, [lr, #0xfc0]
    // 0x114bafc: stp             lr, x16, [SP, #0x10]
    // 0x114bb00: r16 = false
    //     0x114bb00: add             x16, NULL, #0x30  ; false
    // 0x114bb04: r30 = false
    //     0x114bb04: add             lr, NULL, #0x30  ; false
    // 0x114bb08: stp             lr, x16, [SP]
    // 0x114bb0c: r2 = Null
    //     0x114bb0c: mov             x2, NULL
    // 0x114bb10: r4 = const [0, 0xc, 0xa, 0xc, null]
    //     0x114bb10: add             x4, PP, #0x26, lsl #12  ; [pp+0x26270] List(5) [0, 0xc, 0xa, 0xc, Null]
    //     0x114bb14: ldr             x4, [x4, #0x270]
    // 0x114bb18: r0 = hash()
    //     0x114bb18: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114bb1c: mov             x2, x0
    // 0x114bb20: r0 = BoxInt64Instr(r2)
    //     0x114bb20: sbfiz           x0, x2, #1, #0x1f
    //     0x114bb24: cmp             x2, x0, asr #1
    //     0x114bb28: b.eq            #0x114bb34
    //     0x114bb2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114bb30: stur            x2, [x0, #7]
    // 0x114bb34: LeaveFrame
    //     0x114bb34: mov             SP, fp
    //     0x114bb38: ldp             fp, lr, [SP], #0x10
    // 0x114bb3c: ret
    //     0x114bb3c: ret             
    // 0x114bb40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114bb40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114bb44: b               #0x114bab8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1162ff8, size: 0x80
    // 0x1162ff8: EnterFrame
    //     0x1162ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x1162ffc: mov             fp, SP
    // 0x1163000: AllocStack(0x18)
    //     0x1163000: sub             SP, SP, #0x18
    // 0x1163004: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x1163004: mov             x0, x2
    //     0x1163008: stur            x1, [fp, #-8]
    //     0x116300c: stur            x2, [fp, #-0x10]
    //     0x1163010: stur            d0, [fp, #-0x18]
    // 0x1163014: cmp             w1, w0
    // 0x1163018: b.eq            #0x1163028
    // 0x116301c: d1 = 0.000000
    //     0x116301c: eor             v1.16b, v1.16b, v1.16b
    // 0x1163020: fcmp            d0, d1
    // 0x1163024: b.ne            #0x1163038
    // 0x1163028: mov             x0, x1
    // 0x116302c: LeaveFrame
    //     0x116302c: mov             SP, fp
    //     0x1163030: ldp             fp, lr, [SP], #0x10
    // 0x1163034: ret
    //     0x1163034: ret             
    // 0x1163038: d1 = 1.000000
    //     0x1163038: fmov            d1, #1.00000000
    // 0x116303c: fcmp            d0, d1
    // 0x1163040: b.ne            #0x1163050
    // 0x1163044: LeaveFrame
    //     0x1163044: mov             SP, fp
    //     0x1163048: ldp             fp, lr, [SP], #0x10
    // 0x116304c: ret
    //     0x116304c: ret             
    // 0x1163050: r0 = _BlendedDecorationImage()
    //     0x1163050: bl              #0x1163078  ; Allocate_BlendedDecorationImageStub -> _BlendedDecorationImage (size=0x18)
    // 0x1163054: ldur            x1, [fp, #-8]
    // 0x1163058: StoreField: r0->field_7 = r1
    //     0x1163058: stur            w1, [x0, #7]
    // 0x116305c: ldur            x1, [fp, #-0x10]
    // 0x1163060: StoreField: r0->field_b = r1
    //     0x1163060: stur            w1, [x0, #0xb]
    // 0x1163064: ldur            d0, [fp, #-0x18]
    // 0x1163068: StoreField: r0->field_f = d0
    //     0x1163068: stur            d0, [x0, #0xf]
    // 0x116306c: LeaveFrame
    //     0x116306c: mov             SP, fp
    //     0x1163070: ldp             fp, lr, [SP], #0x10
    // 0x1163074: ret
    //     0x1163074: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1298860, size: 0x2d4
    // 0x1298860: EnterFrame
    //     0x1298860: stp             fp, lr, [SP, #-0x10]!
    //     0x1298864: mov             fp, SP
    // 0x1298868: AllocStack(0x10)
    //     0x1298868: sub             SP, SP, #0x10
    // 0x129886c: CheckStackOverflow
    //     0x129886c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1298870: cmp             SP, x16
    //     0x1298874: b.ls            #0x1298b2c
    // 0x1298878: ldr             x0, [fp, #0x10]
    // 0x129887c: cmp             w0, NULL
    // 0x1298880: b.ne            #0x1298894
    // 0x1298884: r0 = false
    //     0x1298884: add             x0, NULL, #0x30  ; false
    // 0x1298888: LeaveFrame
    //     0x1298888: mov             SP, fp
    //     0x129888c: ldp             fp, lr, [SP], #0x10
    // 0x1298890: ret
    //     0x1298890: ret             
    // 0x1298894: ldr             x1, [fp, #0x18]
    // 0x1298898: cmp             w1, w0
    // 0x129889c: b.ne            #0x12988b0
    // 0x12988a0: r0 = true
    //     0x12988a0: add             x0, NULL, #0x20  ; true
    // 0x12988a4: LeaveFrame
    //     0x12988a4: mov             SP, fp
    //     0x12988a8: ldp             fp, lr, [SP], #0x10
    // 0x12988ac: ret
    //     0x12988ac: ret             
    // 0x12988b0: str             x0, [SP]
    // 0x12988b4: r0 = runtimeType()
    //     0x12988b4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12988b8: r1 = LoadClassIdInstr(r0)
    //     0x12988b8: ldur            x1, [x0, #-1]
    //     0x12988bc: ubfx            x1, x1, #0xc, #0x14
    // 0x12988c0: r16 = DecorationImage
    //     0x12988c0: add             x16, PP, #0x80, lsl #12  ; [pp+0x808a8] Type: DecorationImage
    //     0x12988c4: ldr             x16, [x16, #0x8a8]
    // 0x12988c8: stp             x16, x0, [SP]
    // 0x12988cc: mov             x0, x1
    // 0x12988d0: mov             lr, x0
    // 0x12988d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12988d8: blr             lr
    // 0x12988dc: tbz             w0, #4, #0x12988f0
    // 0x12988e0: r0 = false
    //     0x12988e0: add             x0, NULL, #0x30  ; false
    // 0x12988e4: LeaveFrame
    //     0x12988e4: mov             SP, fp
    //     0x12988e8: ldp             fp, lr, [SP], #0x10
    // 0x12988ec: ret
    //     0x12988ec: ret             
    // 0x12988f0: ldr             x0, [fp, #0x10]
    // 0x12988f4: r2 = Null
    //     0x12988f4: mov             x2, NULL
    // 0x12988f8: r1 = Null
    //     0x12988f8: mov             x1, NULL
    // 0x12988fc: cmp             w0, NULL
    // 0x1298900: b.eq            #0x1298920
    // 0x1298904: branchIfSmi(r0, 0x1298920)
    //     0x1298904: tbz             w0, #0, #0x1298920
    // 0x1298908: r3 = LoadClassIdInstr(r0)
    //     0x1298908: ldur            x3, [x0, #-1]
    //     0x129890c: ubfx            x3, x3, #0xc, #0x14
    // 0x1298910: cmp             x3, #0xb7e
    // 0x1298914: b.eq            #0x1298928
    // 0x1298918: cmp             x3, #0xb81
    // 0x129891c: b.eq            #0x1298928
    // 0x1298920: r0 = false
    //     0x1298920: add             x0, NULL, #0x30  ; false
    // 0x1298924: b               #0x129892c
    // 0x1298928: r0 = true
    //     0x1298928: add             x0, NULL, #0x20  ; true
    // 0x129892c: tbnz            w0, #4, #0x1298b1c
    // 0x1298930: ldr             x3, [fp, #0x18]
    // 0x1298934: ldr             x2, [fp, #0x10]
    // 0x1298938: r0 = LoadClassIdInstr(r2)
    //     0x1298938: ldur            x0, [x2, #-1]
    //     0x129893c: ubfx            x0, x0, #0xc, #0x14
    // 0x1298940: mov             x1, x2
    // 0x1298944: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x1298944: sub             lr, x0, #0xfdf
    //     0x1298948: ldr             lr, [x21, lr, lsl #3]
    //     0x129894c: blr             lr
    // 0x1298950: ldr             x1, [fp, #0x18]
    // 0x1298954: LoadField: r2 = r1->field_7
    //     0x1298954: ldur            w2, [x1, #7]
    // 0x1298958: DecompressPointer r2
    //     0x1298958: add             x2, x2, HEAP, lsl #32
    // 0x129895c: r3 = LoadClassIdInstr(r0)
    //     0x129895c: ldur            x3, [x0, #-1]
    //     0x1298960: ubfx            x3, x3, #0xc, #0x14
    // 0x1298964: stp             x2, x0, [SP]
    // 0x1298968: mov             x0, x3
    // 0x129896c: mov             lr, x0
    // 0x1298970: ldr             lr, [x21, lr, lsl #3]
    // 0x1298974: blr             lr
    // 0x1298978: tbnz            w0, #4, #0x1298b1c
    // 0x129897c: ldr             x2, [fp, #0x18]
    // 0x1298980: ldr             x3, [fp, #0x10]
    // 0x1298984: r0 = LoadClassIdInstr(r3)
    //     0x1298984: ldur            x0, [x3, #-1]
    //     0x1298988: ubfx            x0, x0, #0xc, #0x14
    // 0x129898c: mov             x1, x3
    // 0x1298990: r0 = GDT[cid_x0 + -0xfde]()
    //     0x1298990: sub             lr, x0, #0xfde
    //     0x1298994: ldr             lr, [x21, lr, lsl #3]
    //     0x1298998: blr             lr
    // 0x129899c: ldr             x2, [fp, #0x10]
    // 0x12989a0: r0 = LoadClassIdInstr(r2)
    //     0x12989a0: ldur            x0, [x2, #-1]
    //     0x12989a4: ubfx            x0, x0, #0xc, #0x14
    // 0x12989a8: mov             x1, x2
    // 0x12989ac: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x12989ac: sub             lr, x0, #0xfd9
    //     0x12989b0: ldr             lr, [x21, lr, lsl #3]
    //     0x12989b4: blr             lr
    // 0x12989b8: ldr             x2, [fp, #0x18]
    // 0x12989bc: LoadField: r1 = r2->field_13
    //     0x12989bc: ldur            w1, [x2, #0x13]
    // 0x12989c0: DecompressPointer r1
    //     0x12989c0: add             x1, x1, HEAP, lsl #32
    // 0x12989c4: cmp             w0, w1
    // 0x12989c8: b.ne            #0x1298b1c
    // 0x12989cc: ldr             x3, [fp, #0x10]
    // 0x12989d0: r0 = LoadClassIdInstr(r3)
    //     0x12989d0: ldur            x0, [x3, #-1]
    //     0x12989d4: ubfx            x0, x0, #0xc, #0x14
    // 0x12989d8: mov             x1, x3
    // 0x12989dc: r0 = GDT[cid_x0 + -0xfd8]()
    //     0x12989dc: sub             lr, x0, #0xfd8
    //     0x12989e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12989e4: blr             lr
    // 0x12989e8: mov             x1, x0
    // 0x12989ec: ldr             x0, [fp, #0x18]
    // 0x12989f0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12989f0: ldur            w2, [x0, #0x17]
    // 0x12989f4: DecompressPointer r2
    //     0x12989f4: add             x2, x2, HEAP, lsl #32
    // 0x12989f8: stp             x2, x1, [SP]
    // 0x12989fc: r0 = ==()
    //     0x12989fc: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x1298a00: tbnz            w0, #4, #0x1298b1c
    // 0x1298a04: ldr             x2, [fp, #0x18]
    // 0x1298a08: ldr             x3, [fp, #0x10]
    // 0x1298a0c: r0 = LoadClassIdInstr(r3)
    //     0x1298a0c: ldur            x0, [x3, #-1]
    //     0x1298a10: ubfx            x0, x0, #0xc, #0x14
    // 0x1298a14: mov             x1, x3
    // 0x1298a18: r0 = GDT[cid_x0 + -0xfe3]()
    //     0x1298a18: sub             lr, x0, #0xfe3
    //     0x1298a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x1298a20: blr             lr
    // 0x1298a24: ldr             x2, [fp, #0x10]
    // 0x1298a28: r0 = LoadClassIdInstr(r2)
    //     0x1298a28: ldur            x0, [x2, #-1]
    //     0x1298a2c: ubfx            x0, x0, #0xc, #0x14
    // 0x1298a30: mov             x1, x2
    // 0x1298a34: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x1298a34: sub             lr, x0, #0xfe4
    //     0x1298a38: ldr             lr, [x21, lr, lsl #3]
    //     0x1298a3c: blr             lr
    // 0x1298a40: mov             x1, x0
    // 0x1298a44: ldr             x0, [fp, #0x18]
    // 0x1298a48: LoadField: r2 = r0->field_1f
    //     0x1298a48: ldur            w2, [x0, #0x1f]
    // 0x1298a4c: DecompressPointer r2
    //     0x1298a4c: add             x2, x2, HEAP, lsl #32
    // 0x1298a50: cmp             w1, w2
    // 0x1298a54: b.ne            #0x1298b1c
    // 0x1298a58: ldr             x2, [fp, #0x10]
    // 0x1298a5c: r0 = LoadClassIdInstr(r2)
    //     0x1298a5c: ldur            x0, [x2, #-1]
    //     0x1298a60: ubfx            x0, x0, #0xc, #0x14
    // 0x1298a64: mov             x1, x2
    // 0x1298a68: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x1298a68: sub             lr, x0, #0xfe5
    //     0x1298a6c: ldr             lr, [x21, lr, lsl #3]
    //     0x1298a70: blr             lr
    // 0x1298a74: ldr             x2, [fp, #0x10]
    // 0x1298a78: r0 = LoadClassIdInstr(r2)
    //     0x1298a78: ldur            x0, [x2, #-1]
    //     0x1298a7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1298a80: mov             x1, x2
    // 0x1298a84: r0 = GDT[cid_x0 + -0xfea]()
    //     0x1298a84: sub             lr, x0, #0xfea
    //     0x1298a88: ldr             lr, [x21, lr, lsl #3]
    //     0x1298a8c: blr             lr
    // 0x1298a90: d0 = 1.000000
    //     0x1298a90: fmov            d0, #1.00000000
    // 0x1298a94: fcmp            d0, d0
    // 0x1298a98: b.ne            #0x1298b1c
    // 0x1298a9c: ldr             x2, [fp, #0x10]
    // 0x1298aa0: r0 = LoadClassIdInstr(r2)
    //     0x1298aa0: ldur            x0, [x2, #-1]
    //     0x1298aa4: ubfx            x0, x0, #0xc, #0x14
    // 0x1298aa8: mov             x1, x2
    // 0x1298aac: r0 = GDT[cid_x0 + -0xfdd]()
    //     0x1298aac: sub             lr, x0, #0xfdd
    //     0x1298ab0: ldr             lr, [x21, lr, lsl #3]
    //     0x1298ab4: blr             lr
    // 0x1298ab8: d0 = 1.000000
    //     0x1298ab8: fmov            d0, #1.00000000
    // 0x1298abc: fcmp            d0, d0
    // 0x1298ac0: b.ne            #0x1298b1c
    // 0x1298ac4: ldr             x2, [fp, #0x10]
    // 0x1298ac8: r0 = LoadClassIdInstr(r2)
    //     0x1298ac8: ldur            x0, [x2, #-1]
    //     0x1298acc: ubfx            x0, x0, #0xc, #0x14
    // 0x1298ad0: mov             x1, x2
    // 0x1298ad4: r0 = GDT[cid_x0 + -0xfe9]()
    //     0x1298ad4: sub             lr, x0, #0xfe9
    //     0x1298ad8: ldr             lr, [x21, lr, lsl #3]
    //     0x1298adc: blr             lr
    // 0x1298ae0: ldr             x2, [fp, #0x10]
    // 0x1298ae4: r0 = LoadClassIdInstr(r2)
    //     0x1298ae4: ldur            x0, [x2, #-1]
    //     0x1298ae8: ubfx            x0, x0, #0xc, #0x14
    // 0x1298aec: mov             x1, x2
    // 0x1298af0: r0 = GDT[cid_x0 + -0xfd7]()
    //     0x1298af0: sub             lr, x0, #0xfd7
    //     0x1298af4: ldr             lr, [x21, lr, lsl #3]
    //     0x1298af8: blr             lr
    // 0x1298afc: ldr             x1, [fp, #0x10]
    // 0x1298b00: r0 = LoadClassIdInstr(r1)
    //     0x1298b00: ldur            x0, [x1, #-1]
    //     0x1298b04: ubfx            x0, x0, #0xc, #0x14
    // 0x1298b08: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x1298b08: sub             lr, x0, #0xfeb
    //     0x1298b0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1298b10: blr             lr
    // 0x1298b14: r0 = true
    //     0x1298b14: add             x0, NULL, #0x20  ; true
    // 0x1298b18: b               #0x1298b20
    // 0x1298b1c: r0 = false
    //     0x1298b1c: add             x0, NULL, #0x30  ; false
    // 0x1298b20: LeaveFrame
    //     0x1298b20: mov             SP, fp
    //     0x1298b24: ldp             fp, lr, [SP], #0x10
    // 0x1298b28: ret
    //     0x1298b28: ret             
    // 0x1298b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1298b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1298b30: b               #0x1298878
  }
  _ createPainter(/* No info */) {
    // ** addr: 0x1301f9c, size: 0x34
    // 0x1301f9c: EnterFrame
    //     0x1301f9c: stp             fp, lr, [SP, #-0x10]!
    //     0x1301fa0: mov             fp, SP
    // 0x1301fa4: AllocStack(0x10)
    //     0x1301fa4: sub             SP, SP, #0x10
    // 0x1301fa8: SetupParameters(DecorationImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1301fa8: stur            x1, [fp, #-8]
    //     0x1301fac: stur            x2, [fp, #-0x10]
    // 0x1301fb0: r0 = _DecorationImagePainter()
    //     0x1301fb0: bl              #0x1301fd0  ; Allocate_DecorationImagePainterStub -> _DecorationImagePainter (size=0x18)
    // 0x1301fb4: ldur            x1, [fp, #-8]
    // 0x1301fb8: StoreField: r0->field_7 = r1
    //     0x1301fb8: stur            w1, [x0, #7]
    // 0x1301fbc: ldur            x1, [fp, #-0x10]
    // 0x1301fc0: StoreField: r0->field_b = r1
    //     0x1301fc0: stur            w1, [x0, #0xb]
    // 0x1301fc4: LeaveFrame
    //     0x1301fc4: mov             SP, fp
    //     0x1301fc8: ldp             fp, lr, [SP], #0x10
    // 0x1301fcc: ret
    //     0x1301fcc: ret             
  }
  const get _ opacity(/* No info */) {
    // ** addr: 0x1304544, size: 0x8
    // 0x1304544: LoadField: d0 = r1->field_2f
    //     0x1304544: ldur            d0, [x1, #0x2f]
    // 0x1304548: ret
    //     0x1304548: ret             
  }
  const get _ filterQuality(/* No info */) {
    // ** addr: 0x13048d8, size: 0xc
    // 0x13048d8: LoadField: r0 = r1->field_37
    //     0x13048d8: ldur            w0, [x1, #0x37]
    // 0x13048dc: DecompressPointer r0
    //     0x13048dc: add             x0, x0, HEAP, lsl #32
    // 0x13048e0: ret
    //     0x13048e0: ret             
  }
  const get _ scale(/* No info */) {
    // ** addr: 0x13048e4, size: 0x8
    // 0x13048e4: LoadField: d0 = r1->field_27
    //     0x13048e4: ldur            d0, [x1, #0x27]
    // 0x13048e8: ret
    //     0x13048e8: ret             
  }
  const get _ isAntiAlias(/* No info */) {
    // ** addr: 0x13048ec, size: 0xc
    // 0x13048ec: LoadField: r0 = r1->field_3f
    //     0x13048ec: ldur            w0, [x1, #0x3f]
    // 0x13048f0: DecompressPointer r0
    //     0x13048f0: add             x0, x0, HEAP, lsl #32
    // 0x13048f4: ret
    //     0x13048f4: ret             
  }
}

// class id: 8246, size: 0x14, field offset: 0x14
enum ImageRepeat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaddc, size: 0x64
    // 0x11aaddc: EnterFrame
    //     0x11aaddc: stp             fp, lr, [SP, #-0x10]!
    //     0x11aade0: mov             fp, SP
    // 0x11aade4: AllocStack(0x10)
    //     0x11aade4: sub             SP, SP, #0x10
    // 0x11aade8: SetupParameters(ImageRepeat this /* r1 => r0, fp-0x8 */)
    //     0x11aade8: mov             x0, x1
    //     0x11aadec: stur            x1, [fp, #-8]
    // 0x11aadf0: CheckStackOverflow
    //     0x11aadf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aadf4: cmp             SP, x16
    //     0x11aadf8: b.ls            #0x11aae38
    // 0x11aadfc: r1 = Null
    //     0x11aadfc: mov             x1, NULL
    // 0x11aae00: r2 = 4
    //     0x11aae00: mov             x2, #4
    // 0x11aae04: r0 = AllocateArray()
    //     0x11aae04: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aae08: r16 = "ImageRepeat."
    //     0x11aae08: add             x16, PP, #0x80, lsl #12  ; [pp+0x808a0] "ImageRepeat."
    //     0x11aae0c: ldr             x16, [x16, #0x8a0]
    // 0x11aae10: StoreField: r0->field_f = r16
    //     0x11aae10: stur            w16, [x0, #0xf]
    // 0x11aae14: ldur            x1, [fp, #-8]
    // 0x11aae18: LoadField: r2 = r1->field_f
    //     0x11aae18: ldur            w2, [x1, #0xf]
    // 0x11aae1c: DecompressPointer r2
    //     0x11aae1c: add             x2, x2, HEAP, lsl #32
    // 0x11aae20: StoreField: r0->field_13 = r2
    //     0x11aae20: stur            w2, [x0, #0x13]
    // 0x11aae24: str             x0, [SP]
    // 0x11aae28: r0 = _interpolate()
    //     0x11aae28: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aae2c: LeaveFrame
    //     0x11aae2c: mov             SP, fp
    //     0x11aae30: ldp             fp, lr, [SP], #0x10
    // 0x11aae34: ret
    //     0x11aae34: ret             
    // 0x11aae38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aae38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aae3c: b               #0x11aadfc
  }
}
