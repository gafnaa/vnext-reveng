// lib: , url: package:flutter/src/painting/clip.dart

// class id: 1048988, size: 0x8
class :: {
}

// class id: 2947, size: 0x8, field offset: 0x8
abstract class ClipContext extends Object {

  _ clipRectAndPaint(/* No info */) {
    // ** addr: 0xc193d4, size: 0x88
    // 0xc193d4: EnterFrame
    //     0xc193d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc193d8: mov             fp, SP
    // 0xc193dc: AllocStack(0x28)
    //     0xc193dc: sub             SP, SP, #0x28
    // 0xc193e0: SetupParameters(ClipContext this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xc193e0: stur            x1, [fp, #-8]
    //     0xc193e4: stur            x2, [fp, #-0x10]
    //     0xc193e8: stur            x3, [fp, #-0x18]
    //     0xc193ec: stur            x5, [fp, #-0x20]
    //     0xc193f0: stur            x6, [fp, #-0x28]
    // 0xc193f4: CheckStackOverflow
    //     0xc193f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc193f8: cmp             SP, x16
    //     0xc193fc: b.ls            #0xc19454
    // 0xc19400: r1 = 2
    //     0xc19400: mov             x1, #2
    // 0xc19404: r0 = AllocateContext()
    //     0xc19404: bl              #0x13de838  ; AllocateContextStub
    // 0xc19408: mov             x1, x0
    // 0xc1940c: ldur            x0, [fp, #-8]
    // 0xc19410: StoreField: r1->field_f = r0
    //     0xc19410: stur            w0, [x1, #0xf]
    // 0xc19414: ldur            x2, [fp, #-0x10]
    // 0xc19418: StoreField: r1->field_13 = r2
    //     0xc19418: stur            w2, [x1, #0x13]
    // 0xc1941c: mov             x2, x1
    // 0xc19420: r1 = Function '<anonymous closure>':.
    //     0xc19420: add             x1, PP, #0x90, lsl #12  ; [pp+0x90698] AnonymousClosure: (0xc19904), in [package:flutter/src/painting/clip.dart] ClipContext::clipRectAndPaint (0xc193d4)
    //     0xc19424: ldr             x1, [x1, #0x698]
    // 0xc19428: r0 = AllocateClosure()
    //     0xc19428: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1942c: ldur            x1, [fp, #-8]
    // 0xc19430: mov             x2, x0
    // 0xc19434: ldur            x3, [fp, #-0x18]
    // 0xc19438: ldur            x5, [fp, #-0x20]
    // 0xc1943c: ldur            x6, [fp, #-0x28]
    // 0xc19440: r0 = _clipAndPaint()
    //     0xc19440: bl              #0xc1945c  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0xc19444: r0 = Null
    //     0xc19444: mov             x0, NULL
    // 0xc19448: LeaveFrame
    //     0xc19448: mov             SP, fp
    //     0xc1944c: ldp             fp, lr, [SP], #0x10
    // 0xc19450: ret
    //     0xc19450: ret             
    // 0xc19454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19454: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19458: b               #0xc19400
  }
  _ _clipAndPaint(/* No info */) {
    // ** addr: 0xc1945c, size: 0x2cc
    // 0xc1945c: EnterFrame
    //     0xc1945c: stp             fp, lr, [SP, #-0x10]!
    //     0xc19460: mov             fp, SP
    // 0xc19464: AllocStack(0x68)
    //     0xc19464: sub             SP, SP, #0x68
    // 0xc19468: SetupParameters(ClipContext this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r0, fp-0x28 */)
    //     0xc19468: mov             x4, x1
    //     0xc1946c: mov             x0, x6
    //     0xc19470: stur            x1, [fp, #-8]
    //     0xc19474: stur            x2, [fp, #-0x10]
    //     0xc19478: stur            x3, [fp, #-0x18]
    //     0xc1947c: stur            x5, [fp, #-0x20]
    //     0xc19480: stur            x6, [fp, #-0x28]
    // 0xc19484: CheckStackOverflow
    //     0xc19484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19488: cmp             SP, x16
    //     0xc1948c: b.ls            #0xc19710
    // 0xc19490: mov             x1, x4
    // 0xc19494: r0 = canvas()
    //     0xc19494: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc19498: stur            x0, [fp, #-0x38]
    // 0xc1949c: LoadField: r1 = r0->field_7
    //     0xc1949c: ldur            w1, [x0, #7]
    // 0xc194a0: DecompressPointer r1
    //     0xc194a0: add             x1, x1, HEAP, lsl #32
    // 0xc194a4: cmp             w1, NULL
    // 0xc194a8: b.eq            #0xc19718
    // 0xc194ac: LoadField: r2 = r1->field_7
    //     0xc194ac: ldur            x2, [x1, #7]
    // 0xc194b0: ldr             x1, [x2]
    // 0xc194b4: cbz             x1, #0xc196d0
    // 0xc194b8: ldur            x2, [fp, #-0x18]
    // 0xc194bc: mov             x3, x1
    // 0xc194c0: stur            x3, [fp, #-0x30]
    // 0xc194c4: r1 = <Never>
    //     0xc194c4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc194c8: r0 = Pointer()
    //     0xc194c8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc194cc: mov             x1, x0
    // 0xc194d0: ldur            x0, [fp, #-0x30]
    // 0xc194d4: StoreField: r1->field_7 = r0
    //     0xc194d4: stur            x0, [x1, #7]
    // 0xc194d8: r0 = _save$Method$FfiNative()
    //     0xc194d8: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xc194dc: ldur            x1, [fp, #-0x18]
    // 0xc194e0: LoadField: r0 = r1->field_7
    //     0xc194e0: ldur            x0, [x1, #7]
    // 0xc194e4: cmp             x0, #1
    // 0xc194e8: b.gt            #0xc19518
    // 0xc194ec: cmp             x0, #0
    // 0xc194f0: b.le            #0xc19604
    // 0xc194f4: ldur            x16, [fp, #-0x10]
    // 0xc194f8: r30 = false
    //     0xc194f8: add             lr, NULL, #0x30  ; false
    // 0xc194fc: stp             lr, x16, [SP]
    // 0xc19500: ldur            x0, [fp, #-0x10]
    // 0xc19504: ClosureCall
    //     0xc19504: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc19508: ldur            x2, [x0, #0x1f]
    //     0xc1950c: blr             x2
    // 0xc19510: ldur            x1, [fp, #-0x18]
    // 0xc19514: b               #0xc19604
    // 0xc19518: cmp             x0, #2
    // 0xc1951c: b.gt            #0xc19544
    // 0xc19520: ldur            x16, [fp, #-0x10]
    // 0xc19524: r30 = true
    //     0xc19524: add             lr, NULL, #0x20  ; true
    // 0xc19528: stp             lr, x16, [SP]
    // 0xc1952c: ldur            x0, [fp, #-0x10]
    // 0xc19530: ClosureCall
    //     0xc19530: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc19534: ldur            x2, [x0, #0x1f]
    //     0xc19538: blr             x2
    // 0xc1953c: ldur            x1, [fp, #-0x18]
    // 0xc19540: b               #0xc19604
    // 0xc19544: ldur            x1, [fp, #-0x20]
    // 0xc19548: ldur            x16, [fp, #-0x10]
    // 0xc1954c: r30 = true
    //     0xc1954c: add             lr, NULL, #0x20  ; true
    // 0xc19550: stp             lr, x16, [SP]
    // 0xc19554: ldur            x0, [fp, #-0x10]
    // 0xc19558: ClosureCall
    //     0xc19558: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc1955c: ldur            x2, [x0, #0x1f]
    //     0xc19560: blr             x2
    // 0xc19564: ldur            x1, [fp, #-8]
    // 0xc19568: r0 = canvas()
    //     0xc19568: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1956c: stur            x0, [fp, #-0x10]
    // 0xc19570: r16 = 136
    //     0xc19570: mov             x16, #0x88
    // 0xc19574: stp             x16, NULL, [SP]
    // 0xc19578: r0 = ByteData()
    //     0xc19578: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc1957c: mov             x2, x0
    // 0xc19580: ldur            x0, [fp, #-0x20]
    // 0xc19584: stur            x2, [fp, #-0x38]
    // 0xc19588: LoadField: d0 = r0->field_7
    //     0xc19588: ldur            d0, [x0, #7]
    // 0xc1958c: stur            d0, [fp, #-0x58]
    // 0xc19590: LoadField: d1 = r0->field_f
    //     0xc19590: ldur            d1, [x0, #0xf]
    // 0xc19594: stur            d1, [fp, #-0x50]
    // 0xc19598: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xc19598: ldur            d2, [x0, #0x17]
    // 0xc1959c: stur            d2, [fp, #-0x48]
    // 0xc195a0: LoadField: d3 = r0->field_1f
    //     0xc195a0: ldur            d3, [x0, #0x1f]
    // 0xc195a4: ldur            x0, [fp, #-0x10]
    // 0xc195a8: stur            d3, [fp, #-0x40]
    // 0xc195ac: LoadField: r1 = r0->field_7
    //     0xc195ac: ldur            w1, [x0, #7]
    // 0xc195b0: DecompressPointer r1
    //     0xc195b0: add             x1, x1, HEAP, lsl #32
    // 0xc195b4: cmp             w1, NULL
    // 0xc195b8: b.eq            #0xc1971c
    // 0xc195bc: LoadField: r3 = r1->field_7
    //     0xc195bc: ldur            x3, [x1, #7]
    // 0xc195c0: ldr             x1, [x3]
    // 0xc195c4: cbz             x1, #0xc196e0
    // 0xc195c8: mov             x3, x1
    // 0xc195cc: stur            x3, [fp, #-0x30]
    // 0xc195d0: r1 = <Never>
    //     0xc195d0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc195d4: r0 = Pointer()
    //     0xc195d4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc195d8: mov             x1, x0
    // 0xc195dc: ldur            x0, [fp, #-0x30]
    // 0xc195e0: StoreField: r1->field_7 = r0
    //     0xc195e0: stur            x0, [x1, #7]
    // 0xc195e4: ldur            d0, [fp, #-0x58]
    // 0xc195e8: ldur            d1, [fp, #-0x50]
    // 0xc195ec: ldur            d2, [fp, #-0x48]
    // 0xc195f0: ldur            d3, [fp, #-0x40]
    // 0xc195f4: ldur            x3, [fp, #-0x38]
    // 0xc195f8: r2 = Null
    //     0xc195f8: mov             x2, NULL
    // 0xc195fc: r0 = __saveLayer$Method$FfiNative()
    //     0xc195fc: bl              #0xc19728  ; [dart:ui] _NativeCanvas::__saveLayer$Method$FfiNative
    // 0xc19600: ldur            x1, [fp, #-0x18]
    // 0xc19604: ldur            x16, [fp, #-0x28]
    // 0xc19608: str             x16, [SP]
    // 0xc1960c: ldur            x0, [fp, #-0x28]
    // 0xc19610: ClosureCall
    //     0xc19610: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc19614: ldur            x2, [x0, #0x1f]
    //     0xc19618: blr             x2
    // 0xc1961c: ldur            x0, [fp, #-0x18]
    // 0xc19620: r16 = Instance_Clip
    //     0xc19620: add             x16, PP, #0x90, lsl #12  ; [pp+0x906a8] Obj!Clip@12c8121
    //     0xc19624: ldr             x16, [x16, #0x6a8]
    // 0xc19628: cmp             w0, w16
    // 0xc1962c: b.ne            #0xc19678
    // 0xc19630: ldur            x1, [fp, #-8]
    // 0xc19634: r0 = canvas()
    //     0xc19634: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc19638: stur            x0, [fp, #-0x10]
    // 0xc1963c: LoadField: r1 = r0->field_7
    //     0xc1963c: ldur            w1, [x0, #7]
    // 0xc19640: DecompressPointer r1
    //     0xc19640: add             x1, x1, HEAP, lsl #32
    // 0xc19644: cmp             w1, NULL
    // 0xc19648: b.eq            #0xc19720
    // 0xc1964c: LoadField: r2 = r1->field_7
    //     0xc1964c: ldur            x2, [x1, #7]
    // 0xc19650: ldr             x1, [x2]
    // 0xc19654: cbz             x1, #0xc196f0
    // 0xc19658: mov             x2, x1
    // 0xc1965c: stur            x2, [fp, #-0x30]
    // 0xc19660: r1 = <Never>
    //     0xc19660: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc19664: r0 = Pointer()
    //     0xc19664: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc19668: mov             x1, x0
    // 0xc1966c: ldur            x0, [fp, #-0x30]
    // 0xc19670: StoreField: r1->field_7 = r0
    //     0xc19670: stur            x0, [x1, #7]
    // 0xc19674: r0 = _restore$Method$FfiNative()
    //     0xc19674: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc19678: ldur            x1, [fp, #-8]
    // 0xc1967c: r0 = canvas()
    //     0xc1967c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc19680: stur            x0, [fp, #-8]
    // 0xc19684: LoadField: r1 = r0->field_7
    //     0xc19684: ldur            w1, [x0, #7]
    // 0xc19688: DecompressPointer r1
    //     0xc19688: add             x1, x1, HEAP, lsl #32
    // 0xc1968c: cmp             w1, NULL
    // 0xc19690: b.eq            #0xc19724
    // 0xc19694: LoadField: r2 = r1->field_7
    //     0xc19694: ldur            x2, [x1, #7]
    // 0xc19698: ldr             x1, [x2]
    // 0xc1969c: cbz             x1, #0xc19700
    // 0xc196a0: mov             x2, x1
    // 0xc196a4: stur            x2, [fp, #-0x30]
    // 0xc196a8: r1 = <Never>
    //     0xc196a8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc196ac: r0 = Pointer()
    //     0xc196ac: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc196b0: mov             x1, x0
    // 0xc196b4: ldur            x0, [fp, #-0x30]
    // 0xc196b8: StoreField: r1->field_7 = r0
    //     0xc196b8: stur            x0, [x1, #7]
    // 0xc196bc: r0 = _restore$Method$FfiNative()
    //     0xc196bc: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc196c0: r0 = Null
    //     0xc196c0: mov             x0, NULL
    // 0xc196c4: LeaveFrame
    //     0xc196c4: mov             SP, fp
    //     0xc196c8: ldp             fp, lr, [SP], #0x10
    // 0xc196cc: ret
    //     0xc196cc: ret             
    // 0xc196d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc196d0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc196d4: str             x16, [SP]
    // 0xc196d8: r0 = _throwNew()
    //     0xc196d8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc196dc: brk             #0
    // 0xc196e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc196e0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc196e4: str             x16, [SP]
    // 0xc196e8: r0 = _throwNew()
    //     0xc196e8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc196ec: brk             #0
    // 0xc196f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc196f0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc196f4: str             x16, [SP]
    // 0xc196f8: r0 = _throwNew()
    //     0xc196f8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc196fc: brk             #0
    // 0xc19700: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc19700: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc19704: str             x16, [SP]
    // 0xc19708: r0 = _throwNew()
    //     0xc19708: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1970c: brk             #0
    // 0xc19710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19714: b               #0xc19490
    // 0xc19718: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc19718: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1971c: r0 = NullErrorSharedWithFPURegs()
    //     0xc1971c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc19720: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc19720: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc19724: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc19724: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xc19904, size: 0x70
    // 0xc19904: EnterFrame
    //     0xc19904: stp             fp, lr, [SP, #-0x10]!
    //     0xc19908: mov             fp, SP
    // 0xc1990c: AllocStack(0x10)
    //     0xc1990c: sub             SP, SP, #0x10
    // 0xc19910: SetupParameters([dynamic _ /* r0 */])
    //     0xc19910: ldr             x0, [fp, #0x18]
    //     0xc19914: ldur            w2, [x0, #0x17]
    //     0xc19918: add             x2, x2, HEAP, lsl #32
    //     0xc1991c: stur            x2, [fp, #-8]
    // 0xc19920: CheckStackOverflow
    //     0xc19920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19924: cmp             SP, x16
    //     0xc19928: b.ls            #0xc1996c
    // 0xc1992c: LoadField: r1 = r2->field_f
    //     0xc1992c: ldur            w1, [x2, #0xf]
    // 0xc19930: DecompressPointer r1
    //     0xc19930: add             x1, x1, HEAP, lsl #32
    // 0xc19934: r0 = canvas()
    //     0xc19934: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc19938: mov             x1, x0
    // 0xc1993c: ldur            x0, [fp, #-8]
    // 0xc19940: LoadField: r2 = r0->field_13
    //     0xc19940: ldur            w2, [x0, #0x13]
    // 0xc19944: DecompressPointer r2
    //     0xc19944: add             x2, x2, HEAP, lsl #32
    // 0xc19948: ldr             x16, [fp, #0x10]
    // 0xc1994c: str             x16, [SP]
    // 0xc19950: r4 = const [0, 0x3, 0x1, 0x2, doAntiAlias, 0x2, null]
    //     0xc19950: add             x4, PP, #0x90, lsl #12  ; [pp+0x906a0] List(7) [0, 0x3, 0x1, 0x2, "doAntiAlias", 0x2, Null]
    //     0xc19954: ldr             x4, [x4, #0x6a0]
    // 0xc19958: r0 = clipRect()
    //     0xc19958: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0xc1995c: r0 = Null
    //     0xc1995c: mov             x0, NULL
    // 0xc19960: LeaveFrame
    //     0xc19960: mov             SP, fp
    //     0xc19964: ldp             fp, lr, [SP], #0x10
    // 0xc19968: ret
    //     0xc19968: ret             
    // 0xc1996c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1996c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19970: b               #0xc1992c
  }
  _ clipRRectAndPaint(/* No info */) {
    // ** addr: 0xc19e28, size: 0x88
    // 0xc19e28: EnterFrame
    //     0xc19e28: stp             fp, lr, [SP, #-0x10]!
    //     0xc19e2c: mov             fp, SP
    // 0xc19e30: AllocStack(0x28)
    //     0xc19e30: sub             SP, SP, #0x28
    // 0xc19e34: SetupParameters(ClipContext this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xc19e34: stur            x1, [fp, #-8]
    //     0xc19e38: stur            x2, [fp, #-0x10]
    //     0xc19e3c: stur            x3, [fp, #-0x18]
    //     0xc19e40: stur            x5, [fp, #-0x20]
    //     0xc19e44: stur            x6, [fp, #-0x28]
    // 0xc19e48: CheckStackOverflow
    //     0xc19e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19e4c: cmp             SP, x16
    //     0xc19e50: b.ls            #0xc19ea8
    // 0xc19e54: r1 = 2
    //     0xc19e54: mov             x1, #2
    // 0xc19e58: r0 = AllocateContext()
    //     0xc19e58: bl              #0x13de838  ; AllocateContextStub
    // 0xc19e5c: mov             x1, x0
    // 0xc19e60: ldur            x0, [fp, #-8]
    // 0xc19e64: StoreField: r1->field_f = r0
    //     0xc19e64: stur            w0, [x1, #0xf]
    // 0xc19e68: ldur            x2, [fp, #-0x10]
    // 0xc19e6c: StoreField: r1->field_13 = r2
    //     0xc19e6c: stur            w2, [x1, #0x13]
    // 0xc19e70: mov             x2, x1
    // 0xc19e74: r1 = Function '<anonymous closure>':.
    //     0xc19e74: add             x1, PP, #0x90, lsl #12  ; [pp+0x90c10] AnonymousClosure: (0xc19eb0), in [package:flutter/src/painting/clip.dart] ClipContext::clipRRectAndPaint (0xc19e28)
    //     0xc19e78: ldr             x1, [x1, #0xc10]
    // 0xc19e7c: r0 = AllocateClosure()
    //     0xc19e7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc19e80: ldur            x1, [fp, #-8]
    // 0xc19e84: mov             x2, x0
    // 0xc19e88: ldur            x3, [fp, #-0x18]
    // 0xc19e8c: ldur            x5, [fp, #-0x20]
    // 0xc19e90: ldur            x6, [fp, #-0x28]
    // 0xc19e94: r0 = _clipAndPaint()
    //     0xc19e94: bl              #0xc1945c  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0xc19e98: r0 = Null
    //     0xc19e98: mov             x0, NULL
    // 0xc19e9c: LeaveFrame
    //     0xc19e9c: mov             SP, fp
    //     0xc19ea0: ldp             fp, lr, [SP], #0x10
    // 0xc19ea4: ret
    //     0xc19ea4: ret             
    // 0xc19ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19eac: b               #0xc19e54
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xc19eb0, size: 0x168
    // 0xc19eb0: EnterFrame
    //     0xc19eb0: stp             fp, lr, [SP, #-0x10]!
    //     0xc19eb4: mov             fp, SP
    // 0xc19eb8: AllocStack(0x30)
    //     0xc19eb8: sub             SP, SP, #0x30
    // 0xc19ebc: SetupParameters([dynamic _ /* r0 */])
    //     0xc19ebc: ldr             x0, [fp, #0x18]
    //     0xc19ec0: ldur            w2, [x0, #0x17]
    //     0xc19ec4: add             x2, x2, HEAP, lsl #32
    //     0xc19ec8: stur            x2, [fp, #-8]
    // 0xc19ecc: CheckStackOverflow
    //     0xc19ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19ed0: cmp             SP, x16
    //     0xc19ed4: b.ls            #0xc1a00c
    // 0xc19ed8: LoadField: r1 = r2->field_f
    //     0xc19ed8: ldur            w1, [x2, #0xf]
    // 0xc19edc: DecompressPointer r1
    //     0xc19edc: add             x1, x1, HEAP, lsl #32
    // 0xc19ee0: r0 = canvas()
    //     0xc19ee0: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc19ee4: mov             x1, x0
    // 0xc19ee8: ldur            x0, [fp, #-8]
    // 0xc19eec: stur            x1, [fp, #-0x18]
    // 0xc19ef0: LoadField: r2 = r0->field_13
    //     0xc19ef0: ldur            w2, [x0, #0x13]
    // 0xc19ef4: DecompressPointer r2
    //     0xc19ef4: add             x2, x2, HEAP, lsl #32
    // 0xc19ef8: stur            x2, [fp, #-0x10]
    // 0xc19efc: LoadField: d0 = r2->field_b
    //     0xc19efc: ldur            d0, [x2, #0xb]
    // 0xc19f00: fcvt            s1, d0
    // 0xc19f04: stur            d1, [fp, #-0x28]
    // 0xc19f08: r4 = 24
    //     0xc19f08: mov             x4, #0x18
    // 0xc19f0c: r0 = AllocateFloat32Array()
    //     0xc19f0c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xc19f10: ldur            d0, [fp, #-0x28]
    // 0xc19f14: stur            x0, [fp, #-8]
    // 0xc19f18: ArrayStore: r0[0] = d0  ; List_8
    //     0xc19f18: stur            s0, [x0, #0x17]
    // 0xc19f1c: ldur            x1, [fp, #-0x10]
    // 0xc19f20: LoadField: d0 = r1->field_13
    //     0xc19f20: ldur            d0, [x1, #0x13]
    // 0xc19f24: fcvt            s1, d0
    // 0xc19f28: StoreField: r0->field_1b = d1
    //     0xc19f28: stur            s1, [x0, #0x1b]
    // 0xc19f2c: LoadField: d0 = r1->field_1b
    //     0xc19f2c: ldur            d0, [x1, #0x1b]
    // 0xc19f30: fcvt            s1, d0
    // 0xc19f34: StoreField: r0->field_1f = d1
    //     0xc19f34: stur            s1, [x0, #0x1f]
    // 0xc19f38: LoadField: d0 = r1->field_23
    //     0xc19f38: ldur            d0, [x1, #0x23]
    // 0xc19f3c: fcvt            s1, d0
    // 0xc19f40: StoreField: r0->field_23 = d1
    //     0xc19f40: stur            s1, [x0, #0x23]
    // 0xc19f44: LoadField: d0 = r1->field_2b
    //     0xc19f44: ldur            d0, [x1, #0x2b]
    // 0xc19f48: fcvt            s1, d0
    // 0xc19f4c: StoreField: r0->field_27 = d1
    //     0xc19f4c: stur            s1, [x0, #0x27]
    // 0xc19f50: LoadField: d0 = r1->field_33
    //     0xc19f50: ldur            d0, [x1, #0x33]
    // 0xc19f54: fcvt            s1, d0
    // 0xc19f58: StoreField: r0->field_2b = d1
    //     0xc19f58: stur            s1, [x0, #0x2b]
    // 0xc19f5c: LoadField: d0 = r1->field_3b
    //     0xc19f5c: ldur            d0, [x1, #0x3b]
    // 0xc19f60: fcvt            s1, d0
    // 0xc19f64: StoreField: r0->field_2f = d1
    //     0xc19f64: stur            s1, [x0, #0x2f]
    // 0xc19f68: LoadField: d0 = r1->field_43
    //     0xc19f68: ldur            d0, [x1, #0x43]
    // 0xc19f6c: fcvt            s1, d0
    // 0xc19f70: StoreField: r0->field_33 = d1
    //     0xc19f70: stur            s1, [x0, #0x33]
    // 0xc19f74: LoadField: d0 = r1->field_4b
    //     0xc19f74: ldur            d0, [x1, #0x4b]
    // 0xc19f78: fcvt            s1, d0
    // 0xc19f7c: StoreField: r0->field_37 = d1
    //     0xc19f7c: stur            s1, [x0, #0x37]
    // 0xc19f80: LoadField: d0 = r1->field_53
    //     0xc19f80: ldur            d0, [x1, #0x53]
    // 0xc19f84: fcvt            s1, d0
    // 0xc19f88: StoreField: r0->field_3b = d1
    //     0xc19f88: stur            s1, [x0, #0x3b]
    // 0xc19f8c: LoadField: d0 = r1->field_5b
    //     0xc19f8c: ldur            d0, [x1, #0x5b]
    // 0xc19f90: fcvt            s1, d0
    // 0xc19f94: StoreField: r0->field_3f = d1
    //     0xc19f94: stur            s1, [x0, #0x3f]
    // 0xc19f98: LoadField: d0 = r1->field_63
    //     0xc19f98: ldur            d0, [x1, #0x63]
    // 0xc19f9c: fcvt            s1, d0
    // 0xc19fa0: StoreField: r0->field_43 = d1
    //     0xc19fa0: stur            s1, [x0, #0x43]
    // 0xc19fa4: ldur            x2, [fp, #-0x18]
    // 0xc19fa8: LoadField: r1 = r2->field_7
    //     0xc19fa8: ldur            w1, [x2, #7]
    // 0xc19fac: DecompressPointer r1
    //     0xc19fac: add             x1, x1, HEAP, lsl #32
    // 0xc19fb0: cmp             w1, NULL
    // 0xc19fb4: b.eq            #0xc1a014
    // 0xc19fb8: LoadField: r3 = r1->field_7
    //     0xc19fb8: ldur            x3, [x1, #7]
    // 0xc19fbc: ldr             x1, [x3]
    // 0xc19fc0: cbz             x1, #0xc19ffc
    // 0xc19fc4: mov             x3, x1
    // 0xc19fc8: stur            x3, [fp, #-0x20]
    // 0xc19fcc: r1 = <Never>
    //     0xc19fcc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc19fd0: r0 = Pointer()
    //     0xc19fd0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc19fd4: mov             x1, x0
    // 0xc19fd8: ldur            x0, [fp, #-0x20]
    // 0xc19fdc: StoreField: r1->field_7 = r0
    //     0xc19fdc: stur            x0, [x1, #7]
    // 0xc19fe0: ldur            x2, [fp, #-8]
    // 0xc19fe4: ldr             x3, [fp, #0x10]
    // 0xc19fe8: r0 = __clipRRect$Method$FfiNative()
    //     0xc19fe8: bl              #0xb6e74c  ; [dart:ui] _NativeCanvas::__clipRRect$Method$FfiNative
    // 0xc19fec: r0 = Null
    //     0xc19fec: mov             x0, NULL
    // 0xc19ff0: LeaveFrame
    //     0xc19ff0: mov             SP, fp
    //     0xc19ff4: ldp             fp, lr, [SP], #0x10
    // 0xc19ff8: ret
    //     0xc19ff8: ret             
    // 0xc19ffc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc19ffc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1a000: str             x16, [SP]
    // 0xc1a004: r0 = _throwNew()
    //     0xc1a004: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1a008: brk             #0
    // 0xc1a00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a010: b               #0xc19ed8
    // 0xc1a014: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1a014: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ clipRSuperellipseAndPaint(/* No info */) {
    // ** addr: 0xc1a408, size: 0x88
    // 0xc1a408: EnterFrame
    //     0xc1a408: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a40c: mov             fp, SP
    // 0xc1a410: AllocStack(0x28)
    //     0xc1a410: sub             SP, SP, #0x28
    // 0xc1a414: SetupParameters(ClipContext this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xc1a414: stur            x1, [fp, #-8]
    //     0xc1a418: stur            x2, [fp, #-0x10]
    //     0xc1a41c: stur            x3, [fp, #-0x18]
    //     0xc1a420: stur            x5, [fp, #-0x20]
    //     0xc1a424: stur            x6, [fp, #-0x28]
    // 0xc1a428: CheckStackOverflow
    //     0xc1a428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a42c: cmp             SP, x16
    //     0xc1a430: b.ls            #0xc1a488
    // 0xc1a434: r1 = 2
    //     0xc1a434: mov             x1, #2
    // 0xc1a438: r0 = AllocateContext()
    //     0xc1a438: bl              #0x13de838  ; AllocateContextStub
    // 0xc1a43c: mov             x1, x0
    // 0xc1a440: ldur            x0, [fp, #-8]
    // 0xc1a444: StoreField: r1->field_f = r0
    //     0xc1a444: stur            w0, [x1, #0xf]
    // 0xc1a448: ldur            x2, [fp, #-0x10]
    // 0xc1a44c: StoreField: r1->field_13 = r2
    //     0xc1a44c: stur            w2, [x1, #0x13]
    // 0xc1a450: mov             x2, x1
    // 0xc1a454: r1 = Function '<anonymous closure>':.
    //     0xc1a454: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1e88] AnonymousClosure: (0xc1a490), in [package:flutter/src/painting/clip.dart] ClipContext::clipRSuperellipseAndPaint (0xc1a408)
    //     0xc1a458: ldr             x1, [x1, #0xe88]
    // 0xc1a45c: r0 = AllocateClosure()
    //     0xc1a45c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1a460: ldur            x1, [fp, #-8]
    // 0xc1a464: mov             x2, x0
    // 0xc1a468: ldur            x3, [fp, #-0x18]
    // 0xc1a46c: ldur            x5, [fp, #-0x20]
    // 0xc1a470: ldur            x6, [fp, #-0x28]
    // 0xc1a474: r0 = _clipAndPaint()
    //     0xc1a474: bl              #0xc1945c  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0xc1a478: r0 = Null
    //     0xc1a478: mov             x0, NULL
    // 0xc1a47c: LeaveFrame
    //     0xc1a47c: mov             SP, fp
    //     0xc1a480: ldp             fp, lr, [SP], #0x10
    // 0xc1a484: ret
    //     0xc1a484: ret             
    // 0xc1a488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a48c: b               #0xc1a434
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xc1a490, size: 0x10c
    // 0xc1a490: EnterFrame
    //     0xc1a490: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a494: mov             fp, SP
    // 0xc1a498: AllocStack(0x28)
    //     0xc1a498: sub             SP, SP, #0x28
    // 0xc1a49c: SetupParameters([dynamic _ /* r0 */])
    //     0xc1a49c: ldr             x0, [fp, #0x18]
    //     0xc1a4a0: ldur            w2, [x0, #0x17]
    //     0xc1a4a4: add             x2, x2, HEAP, lsl #32
    //     0xc1a4a8: stur            x2, [fp, #-8]
    // 0xc1a4ac: CheckStackOverflow
    //     0xc1a4ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a4b0: cmp             SP, x16
    //     0xc1a4b4: b.ls            #0xc1a58c
    // 0xc1a4b8: LoadField: r1 = r2->field_f
    //     0xc1a4b8: ldur            w1, [x2, #0xf]
    // 0xc1a4bc: DecompressPointer r1
    //     0xc1a4bc: add             x1, x1, HEAP, lsl #32
    // 0xc1a4c0: r0 = canvas()
    //     0xc1a4c0: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1a4c4: mov             x2, x0
    // 0xc1a4c8: ldur            x0, [fp, #-8]
    // 0xc1a4cc: stur            x2, [fp, #-0x10]
    // 0xc1a4d0: LoadField: r1 = r0->field_13
    //     0xc1a4d0: ldur            w1, [x0, #0x13]
    // 0xc1a4d4: DecompressPointer r1
    //     0xc1a4d4: add             x1, x1, HEAP, lsl #32
    // 0xc1a4d8: r0 = _native()
    //     0xc1a4d8: bl              #0xaf867c  ; [dart:ui] RSuperellipse::_native
    // 0xc1a4dc: mov             x2, x0
    // 0xc1a4e0: ldur            x0, [fp, #-0x10]
    // 0xc1a4e4: stur            x2, [fp, #-8]
    // 0xc1a4e8: LoadField: r1 = r0->field_7
    //     0xc1a4e8: ldur            w1, [x0, #7]
    // 0xc1a4ec: DecompressPointer r1
    //     0xc1a4ec: add             x1, x1, HEAP, lsl #32
    // 0xc1a4f0: cmp             w1, NULL
    // 0xc1a4f4: b.eq            #0xc1a594
    // 0xc1a4f8: LoadField: r3 = r1->field_7
    //     0xc1a4f8: ldur            x3, [x1, #7]
    // 0xc1a4fc: ldr             x1, [x3]
    // 0xc1a500: cbz             x1, #0xc1a57c
    // 0xc1a504: mov             x3, x1
    // 0xc1a508: stur            x3, [fp, #-0x18]
    // 0xc1a50c: r1 = <Never>
    //     0xc1a50c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1a510: r0 = Pointer()
    //     0xc1a510: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1a514: mov             x2, x0
    // 0xc1a518: ldur            x0, [fp, #-0x18]
    // 0xc1a51c: stur            x2, [fp, #-0x20]
    // 0xc1a520: StoreField: r2->field_7 = r0
    //     0xc1a520: stur            x0, [x2, #7]
    // 0xc1a524: ldur            x0, [fp, #-8]
    // 0xc1a528: LoadField: r1 = r0->field_7
    //     0xc1a528: ldur            w1, [x0, #7]
    // 0xc1a52c: DecompressPointer r1
    //     0xc1a52c: add             x1, x1, HEAP, lsl #32
    // 0xc1a530: cmp             w1, NULL
    // 0xc1a534: b.eq            #0xc1a598
    // 0xc1a538: LoadField: r3 = r1->field_7
    //     0xc1a538: ldur            x3, [x1, #7]
    // 0xc1a53c: ldr             x1, [x3]
    // 0xc1a540: mov             x3, x1
    // 0xc1a544: stur            x3, [fp, #-0x18]
    // 0xc1a548: r1 = <Never>
    //     0xc1a548: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1a54c: r0 = Pointer()
    //     0xc1a54c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1a550: mov             x1, x0
    // 0xc1a554: ldur            x0, [fp, #-0x18]
    // 0xc1a558: StoreField: r1->field_7 = r0
    //     0xc1a558: stur            x0, [x1, #7]
    // 0xc1a55c: mov             x2, x1
    // 0xc1a560: ldur            x1, [fp, #-0x20]
    // 0xc1a564: ldr             x3, [fp, #0x10]
    // 0xc1a568: r0 = __clipRSuperellipse$Method$FfiNative()
    //     0xc1a568: bl              #0xc1a59c  ; [dart:ui] _NativeCanvas::__clipRSuperellipse$Method$FfiNative
    // 0xc1a56c: r0 = Null
    //     0xc1a56c: mov             x0, NULL
    // 0xc1a570: LeaveFrame
    //     0xc1a570: mov             SP, fp
    //     0xc1a574: ldp             fp, lr, [SP], #0x10
    // 0xc1a578: ret
    //     0xc1a578: ret             
    // 0xc1a57c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1a57c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1a580: str             x16, [SP]
    // 0xc1a584: r0 = _throwNew()
    //     0xc1a584: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1a588: brk             #0
    // 0xc1a58c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a58c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a590: b               #0xc1a4b8
    // 0xc1a594: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1a594: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1a598: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1a598: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ clipPathAndPaint(/* No info */) {
    // ** addr: 0xc1aabc, size: 0x88
    // 0xc1aabc: EnterFrame
    //     0xc1aabc: stp             fp, lr, [SP, #-0x10]!
    //     0xc1aac0: mov             fp, SP
    // 0xc1aac4: AllocStack(0x28)
    //     0xc1aac4: sub             SP, SP, #0x28
    // 0xc1aac8: SetupParameters(ClipContext this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xc1aac8: stur            x1, [fp, #-8]
    //     0xc1aacc: stur            x2, [fp, #-0x10]
    //     0xc1aad0: stur            x3, [fp, #-0x18]
    //     0xc1aad4: stur            x5, [fp, #-0x20]
    //     0xc1aad8: stur            x6, [fp, #-0x28]
    // 0xc1aadc: CheckStackOverflow
    //     0xc1aadc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1aae0: cmp             SP, x16
    //     0xc1aae4: b.ls            #0xc1ab3c
    // 0xc1aae8: r1 = 2
    //     0xc1aae8: mov             x1, #2
    // 0xc1aaec: r0 = AllocateContext()
    //     0xc1aaec: bl              #0x13de838  ; AllocateContextStub
    // 0xc1aaf0: mov             x1, x0
    // 0xc1aaf4: ldur            x0, [fp, #-8]
    // 0xc1aaf8: StoreField: r1->field_f = r0
    //     0xc1aaf8: stur            w0, [x1, #0xf]
    // 0xc1aafc: ldur            x2, [fp, #-0x10]
    // 0xc1ab00: StoreField: r1->field_13 = r2
    //     0xc1ab00: stur            w2, [x1, #0x13]
    // 0xc1ab04: mov             x2, x1
    // 0xc1ab08: r1 = Function '<anonymous closure>':.
    //     0xc1ab08: add             x1, PP, #0x90, lsl #12  ; [pp+0x90b78] AnonymousClosure: (0xc1ab44), in [package:flutter/src/painting/clip.dart] ClipContext::clipPathAndPaint (0xc1aabc)
    //     0xc1ab0c: ldr             x1, [x1, #0xb78]
    // 0xc1ab10: r0 = AllocateClosure()
    //     0xc1ab10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1ab14: ldur            x1, [fp, #-8]
    // 0xc1ab18: mov             x2, x0
    // 0xc1ab1c: ldur            x3, [fp, #-0x18]
    // 0xc1ab20: ldur            x5, [fp, #-0x20]
    // 0xc1ab24: ldur            x6, [fp, #-0x28]
    // 0xc1ab28: r0 = _clipAndPaint()
    //     0xc1ab28: bl              #0xc1945c  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0xc1ab2c: r0 = Null
    //     0xc1ab2c: mov             x0, NULL
    // 0xc1ab30: LeaveFrame
    //     0xc1ab30: mov             SP, fp
    //     0xc1ab34: ldp             fp, lr, [SP], #0x10
    // 0xc1ab38: ret
    //     0xc1ab38: ret             
    // 0xc1ab3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1ab3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1ab40: b               #0xc1aae8
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xc1ab44, size: 0xfc
    // 0xc1ab44: EnterFrame
    //     0xc1ab44: stp             fp, lr, [SP, #-0x10]!
    //     0xc1ab48: mov             fp, SP
    // 0xc1ab4c: AllocStack(0x28)
    //     0xc1ab4c: sub             SP, SP, #0x28
    // 0xc1ab50: SetupParameters([dynamic _ /* r0 */])
    //     0xc1ab50: ldr             x0, [fp, #0x18]
    //     0xc1ab54: ldur            w2, [x0, #0x17]
    //     0xc1ab58: add             x2, x2, HEAP, lsl #32
    //     0xc1ab5c: stur            x2, [fp, #-8]
    // 0xc1ab60: CheckStackOverflow
    //     0xc1ab60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1ab64: cmp             SP, x16
    //     0xc1ab68: b.ls            #0xc1ac30
    // 0xc1ab6c: LoadField: r1 = r2->field_f
    //     0xc1ab6c: ldur            w1, [x2, #0xf]
    // 0xc1ab70: DecompressPointer r1
    //     0xc1ab70: add             x1, x1, HEAP, lsl #32
    // 0xc1ab74: r0 = canvas()
    //     0xc1ab74: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1ab78: mov             x2, x0
    // 0xc1ab7c: ldur            x0, [fp, #-8]
    // 0xc1ab80: stur            x2, [fp, #-0x20]
    // 0xc1ab84: LoadField: r3 = r0->field_13
    //     0xc1ab84: ldur            w3, [x0, #0x13]
    // 0xc1ab88: DecompressPointer r3
    //     0xc1ab88: add             x3, x3, HEAP, lsl #32
    // 0xc1ab8c: stur            x3, [fp, #-0x18]
    // 0xc1ab90: LoadField: r0 = r2->field_7
    //     0xc1ab90: ldur            w0, [x2, #7]
    // 0xc1ab94: DecompressPointer r0
    //     0xc1ab94: add             x0, x0, HEAP, lsl #32
    // 0xc1ab98: cmp             w0, NULL
    // 0xc1ab9c: b.eq            #0xc1ac38
    // 0xc1aba0: LoadField: r1 = r0->field_7
    //     0xc1aba0: ldur            x1, [x0, #7]
    // 0xc1aba4: ldr             x0, [x1]
    // 0xc1aba8: cbz             x0, #0xc1ac20
    // 0xc1abac: stur            x0, [fp, #-0x10]
    // 0xc1abb0: r1 = <Never>
    //     0xc1abb0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1abb4: r0 = Pointer()
    //     0xc1abb4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1abb8: mov             x2, x0
    // 0xc1abbc: ldur            x0, [fp, #-0x10]
    // 0xc1abc0: stur            x2, [fp, #-8]
    // 0xc1abc4: StoreField: r2->field_7 = r0
    //     0xc1abc4: stur            x0, [x2, #7]
    // 0xc1abc8: ldur            x0, [fp, #-0x18]
    // 0xc1abcc: LoadField: r1 = r0->field_7
    //     0xc1abcc: ldur            w1, [x0, #7]
    // 0xc1abd0: DecompressPointer r1
    //     0xc1abd0: add             x1, x1, HEAP, lsl #32
    // 0xc1abd4: cmp             w1, NULL
    // 0xc1abd8: b.eq            #0xc1ac3c
    // 0xc1abdc: LoadField: r3 = r1->field_7
    //     0xc1abdc: ldur            x3, [x1, #7]
    // 0xc1abe0: ldr             x1, [x3]
    // 0xc1abe4: mov             x3, x1
    // 0xc1abe8: stur            x3, [fp, #-0x10]
    // 0xc1abec: r1 = <Never>
    //     0xc1abec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1abf0: r0 = Pointer()
    //     0xc1abf0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1abf4: mov             x1, x0
    // 0xc1abf8: ldur            x0, [fp, #-0x10]
    // 0xc1abfc: StoreField: r1->field_7 = r0
    //     0xc1abfc: stur            x0, [x1, #7]
    // 0xc1ac00: mov             x2, x1
    // 0xc1ac04: ldur            x1, [fp, #-8]
    // 0xc1ac08: ldr             x3, [fp, #0x10]
    // 0xc1ac0c: r0 = __clipPath$Method$FfiNative()
    //     0xc1ac0c: bl              #0xc1ac40  ; [dart:ui] _NativeCanvas::__clipPath$Method$FfiNative
    // 0xc1ac10: r0 = Null
    //     0xc1ac10: mov             x0, NULL
    // 0xc1ac14: LeaveFrame
    //     0xc1ac14: mov             SP, fp
    //     0xc1ac18: ldp             fp, lr, [SP], #0x10
    // 0xc1ac1c: ret
    //     0xc1ac1c: ret             
    // 0xc1ac20: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1ac20: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1ac24: str             x16, [SP]
    // 0xc1ac28: r0 = _throwNew()
    //     0xc1ac28: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1ac2c: brk             #0
    // 0xc1ac30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1ac30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1ac34: b               #0xc1ab6c
    // 0xc1ac38: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1ac38: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1ac3c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1ac3c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}
