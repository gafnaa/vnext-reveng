// lib: , url: package:flutter/src/animation/animation_controller.dart

// class id: 1048762, size: 0x8
class :: {

  static late final SpringDescription _kFlingSpringDescription; // offset: 0x644

  static SpringDescription _kFlingSpringDescription() {
    // ** addr: 0xb35c04, size: 0x38
    // 0xb35c04: EnterFrame
    //     0xb35c04: stp             fp, lr, [SP, #-0x10]!
    //     0xb35c08: mov             fp, SP
    // 0xb35c0c: r0 = SpringDescription()
    //     0xb35c0c: bl              #0xb35c3c  ; AllocateSpringDescriptionStub -> SpringDescription (size=0x20)
    // 0xb35c10: d0 = 1.000000
    //     0xb35c10: fmov            d0, #1.00000000
    // 0xb35c14: StoreField: r0->field_7 = d0
    //     0xb35c14: stur            d0, [x0, #7]
    // 0xb35c18: d0 = 500.000000
    //     0xb35c18: add             x17, PP, #0x83, lsl #12  ; [pp+0x83810] IMM: double(500) from 0x407f400000000000
    //     0xb35c1c: ldr             d0, [x17, #0x810]
    // 0xb35c20: StoreField: r0->field_f = d0
    //     0xb35c20: stur            d0, [x0, #0xf]
    // 0xb35c24: d0 = 44.721360
    //     0xb35c24: add             x17, PP, #0x83, lsl #12  ; [pp+0x83818] IMM: double(44.721359549995796) from 0x40465c55827df1d2
    //     0xb35c28: ldr             d0, [x17, #0x818]
    // 0xb35c2c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb35c2c: stur            d0, [x0, #0x17]
    // 0xb35c30: LeaveFrame
    //     0xb35c30: mov             SP, fp
    //     0xb35c34: ldp             fp, lr, [SP], #0x10
    // 0xb35c38: ret
    //     0xb35c38: ret             
  }
}

// class id: 3343, size: 0x38, field offset: 0xc
class _RepeatingSimulation extends Simulation {

  dynamic dx(dynamic) {
    // ** addr: 0x1183e34, size: 0x3c
    // 0x1183e34: EnterFrame
    //     0x1183e34: stp             fp, lr, [SP, #-0x10]!
    //     0x1183e38: mov             fp, SP
    // 0x1183e3c: ldr             x2, [fp, #0x10]
    // 0x1183e40: r1 = Function 'dx':.
    //     0x1183e40: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0630] AnonymousClosure: (0xf3bfec), in [package:flutter/src/animation/animation_controller.dart] _RepeatingSimulation::dx (0x12dc4c0)
    //     0x1183e44: ldr             x1, [x1, #0x630]
    // 0x1183e48: r0 = AllocateClosure()
    //     0x1183e48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1183e4c: LeaveFrame
    //     0x1183e4c: mov             SP, fp
    //     0x1183e50: ldp             fp, lr, [SP], #0x10
    // 0x1183e54: ret
    //     0x1183e54: ret             
  }
  _ _RepeatingSimulation(/* No info */) {
    // ** addr: 0xf3bf44, size: 0xa8
    // 0xf3bf44: d3 = 1000000.000000
    //     0xf3bf44: ldr             d3, [PP, #0x51e0]  ; [pp+0x51e0] IMM: double(1e+06) from 0x412e848000000000
    // 0xf3bf48: mov             x0, x5
    // 0xf3bf4c: StoreField: r1->field_b = d1
    //     0xf3bf4c: stur            d1, [x1, #0xb]
    // 0xf3bf50: StoreField: r1->field_13 = d2
    //     0xf3bf50: stur            d2, [x1, #0x13]
    // 0xf3bf54: StoreField: r1->field_1b = r2
    //     0xf3bf54: stur            w2, [x1, #0x1b]
    // 0xf3bf58: StoreField: r1->field_23 = r0
    //     0xf3bf58: stur            w0, [x1, #0x23]
    //     0xf3bf5c: ldurb           w16, [x1, #-1]
    //     0xf3bf60: ldurb           w17, [x0, #-1]
    //     0xf3bf64: and             x16, x17, x16, lsr #2
    //     0xf3bf68: tst             x16, HEAP, lsr #32
    //     0xf3bf6c: b.eq            #0xf3bf7c
    //     0xf3bf70: str             lr, [SP, #-8]!
    //     0xf3bf74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xf3bf78: ldr             lr, [SP], #8
    // 0xf3bf7c: LoadField: r2 = r3->field_7
    //     0xf3bf7c: ldur            x2, [x3, #7]
    // 0xf3bf80: scvtf           d4, x2
    // 0xf3bf84: fdiv            d5, d4, d3
    // 0xf3bf88: StoreField: r1->field_27 = d5
    //     0xf3bf88: stur            d5, [x1, #0x27]
    // 0xf3bf8c: fcmp            d2, d1
    // 0xf3bf90: b.ne            #0xf3bf9c
    // 0xf3bf94: d0 = 0.000000
    //     0xf3bf94: eor             v0.16b, v0.16b, v0.16b
    // 0xf3bf98: b               #0xf3bfd8
    // 0xf3bf9c: fcmp            d1, d0
    // 0xf3bfa0: b.le            #0xf3bfac
    // 0xf3bfa4: mov             v0.16b, v1.16b
    // 0xf3bfa8: b               #0xf3bfc8
    // 0xf3bfac: fcmp            d0, d2
    // 0xf3bfb0: b.le            #0xf3bfbc
    // 0xf3bfb4: mov             v0.16b, v2.16b
    // 0xf3bfb8: b               #0xf3bfc8
    // 0xf3bfbc: fcmp            d0, d0
    // 0xf3bfc0: b.vc            #0xf3bfc8
    // 0xf3bfc4: mov             v0.16b, v2.16b
    // 0xf3bfc8: fsub            d3, d0, d1
    // 0xf3bfcc: fsub            d0, d2, d1
    // 0xf3bfd0: fdiv            d1, d3, d0
    // 0xf3bfd4: fmul            d0, d1, d5
    // 0xf3bfd8: r2 = Instance_Tolerance
    //     0xf3bfd8: ldr             x2, [PP, #0x51d8]  ; [pp+0x51d8] Obj!Tolerance@129c5c1
    // 0xf3bfdc: StoreField: r1->field_2f = d0
    //     0xf3bfdc: stur            d0, [x1, #0x2f]
    // 0xf3bfe0: StoreField: r1->field_7 = r2
    //     0xf3bfe0: stur            w2, [x1, #7]
    // 0xf3bfe4: r0 = Null
    //     0xf3bfe4: mov             x0, NULL
    // 0xf3bfe8: ret
    //     0xf3bfe8: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xf3bfec, size: 0x70
    // 0xf3bfec: EnterFrame
    //     0xf3bfec: stp             fp, lr, [SP, #-0x10]!
    //     0xf3bff0: mov             fp, SP
    // 0xf3bff4: ldr             x1, [fp, #0x18]
    // 0xf3bff8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf3bff8: ldur            w2, [x1, #0x17]
    // 0xf3bffc: DecompressPointer r2
    //     0xf3bffc: add             x2, x2, HEAP, lsl #32
    // 0xf3c000: LoadField: d0 = r2->field_13
    //     0xf3c000: ldur            d0, [x2, #0x13]
    // 0xf3c004: LoadField: d1 = r2->field_b
    //     0xf3c004: ldur            d1, [x2, #0xb]
    // 0xf3c008: fsub            d2, d0, d1
    // 0xf3c00c: LoadField: d0 = r2->field_27
    //     0xf3c00c: ldur            d0, [x2, #0x27]
    // 0xf3c010: fdiv            d1, d2, d0
    // 0xf3c014: r0 = inline_Allocate_Double()
    //     0xf3c014: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf3c018: add             x0, x0, #0x10
    //     0xf3c01c: cmp             x1, x0
    //     0xf3c020: b.ls            #0xf3c04c
    //     0xf3c024: str             x0, [THR, #0x60]  ; THR::top
    //     0xf3c028: sub             x0, x0, #0xf
    //     0xf3c02c: mov             x1, #0xe19c
    //     0xf3c030: movk            x1, #3, lsl #16
    //     0xf3c034: stur            x1, [x0, #-1]
    // 0xf3c038: dmb             ishst
    // 0xf3c03c: StoreField: r0->field_7 = d1
    //     0xf3c03c: stur            d1, [x0, #7]
    // 0xf3c040: LeaveFrame
    //     0xf3c040: mov             SP, fp
    //     0xf3c044: ldp             fp, lr, [SP], #0x10
    // 0xf3c048: ret
    //     0xf3c048: ret             
    // 0xf3c04c: SaveReg d1
    //     0xf3c04c: str             q1, [SP, #-0x10]!
    // 0xf3c050: r0 = AllocateDouble()
    //     0xf3c050: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf3c054: RestoreReg d1
    //     0xf3c054: ldr             q1, [SP], #0x10
    // 0xf3c058: b               #0xf3c03c
  }
  _ dx(/* No info */) {
    // ** addr: 0x12dc4c0, size: 0x18
    // 0x12dc4c0: LoadField: d1 = r1->field_13
    //     0x12dc4c0: ldur            d1, [x1, #0x13]
    // 0x12dc4c4: LoadField: d2 = r1->field_b
    //     0x12dc4c4: ldur            d2, [x1, #0xb]
    // 0x12dc4c8: fsub            d3, d1, d2
    // 0x12dc4cc: LoadField: d1 = r1->field_27
    //     0x12dc4cc: ldur            d1, [x1, #0x27]
    // 0x12dc4d0: fdiv            d0, d3, d1
    // 0x12dc4d4: ret
    //     0x12dc4d4: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0x12f14a8, size: 0x380
    // 0x12f14a8: EnterFrame
    //     0x12f14a8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f14ac: mov             fp, SP
    // 0x12f14b0: AllocStack(0x30)
    //     0x12f14b0: sub             SP, SP, #0x30
    // 0x12f14b4: SetupParameters(_RepeatingSimulation this /* r1 => r19, fp-0x8 */)
    //     0x12f14b4: mov             x19, x1
    //     0x12f14b8: stur            x1, [fp, #-8]
    // 0x12f14bc: CheckStackOverflow
    //     0x12f14bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f14c0: cmp             SP, x16
    //     0x12f14c4: b.ls            #0x12f1744
    // 0x12f14c8: LoadField: d0 = r19->field_2f
    //     0x12f14c8: ldur            d0, [x19, #0x2f]
    // 0x12f14cc: LoadField: d1 = r2->field_7
    //     0x12f14cc: ldur            d1, [x2, #7]
    // 0x12f14d0: fadd            d2, d1, d0
    // 0x12f14d4: stur            d2, [fp, #-0x18]
    // 0x12f14d8: LoadField: d3 = r19->field_27
    //     0x12f14d8: ldur            d3, [x19, #0x27]
    // 0x12f14dc: stur            d3, [fp, #-0x10]
    // 0x12f14e0: fdiv            d0, d2, d3
    // 0x12f14e4: d1 = 1.000000
    //     0x12f14e4: fmov            d1, #1.00000000
    // 0x12f14e8: stp             fp, lr, [SP, #-0x10]!
    // 0x12f14ec: mov             fp, SP
    // 0x12f14f0: CallRuntime_DartModulo(double, double) -> double
    //     0x12f14f0: and             SP, SP, #0xfffffffffffffff0
    //     0x12f14f4: mov             sp, SP
    //     0x12f14f8: ldr             x16, [THR, #0x748]  ; THR::DartModulo
    //     0x12f14fc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f1500: blr             x16
    //     0x12f1504: mov             x16, #8
    //     0x12f1508: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f150c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12f1510: sub             sp, x16, #1, lsl #12
    //     0x12f1514: mov             SP, fp
    //     0x12f1518: ldp             fp, lr, [SP], #0x10
    // 0x12f151c: mov             v1.16b, v0.16b
    // 0x12f1520: ldur            d0, [fp, #-0x18]
    // 0x12f1524: stur            d1, [fp, #-0x20]
    // 0x12f1528: r0 = inline_Allocate_Double()
    //     0x12f1528: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f152c: add             x0, x0, #0x10
    //     0x12f1530: cmp             x1, x0
    //     0x12f1534: b.ls            #0x12f174c
    //     0x12f1538: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f153c: sub             x0, x0, #0xf
    //     0x12f1540: mov             x1, #0xe19c
    //     0x12f1544: movk            x1, #3, lsl #16
    //     0x12f1548: stur            x1, [x0, #-1]
    // 0x12f154c: dmb             ishst
    // 0x12f1550: StoreField: r0->field_7 = d0
    //     0x12f1550: stur            d0, [x0, #7]
    // 0x12f1554: ldur            d0, [fp, #-0x10]
    // 0x12f1558: r1 = inline_Allocate_Double()
    //     0x12f1558: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x12f155c: add             x1, x1, #0x10
    //     0x12f1560: cmp             x2, x1
    //     0x12f1564: b.ls            #0x12f1764
    //     0x12f1568: str             x1, [THR, #0x60]  ; THR::top
    //     0x12f156c: sub             x1, x1, #0xf
    //     0x12f1570: mov             x2, #0xe19c
    //     0x12f1574: movk            x2, #3, lsl #16
    //     0x12f1578: stur            x2, [x1, #-1]
    // 0x12f157c: dmb             ishst
    // 0x12f1580: StoreField: r1->field_7 = d0
    //     0x12f1580: stur            d0, [x1, #7]
    // 0x12f1584: stp             x1, x0, [SP]
    // 0x12f1588: r0 = ~/()
    //     0x12f1588: bl              #0x13d8ee8  ; [dart:core] _Double::~/
    // 0x12f158c: r1 = LoadInt32Instr(r0)
    //     0x12f158c: sbfx            x1, x0, #1, #0x1f
    //     0x12f1590: tbz             w0, #0, #0x12f1598
    //     0x12f1594: ldur            x1, [x0, #7]
    // 0x12f1598: and             w0, w1, #1
    // 0x12f159c: ldur            x3, [fp, #-8]
    // 0x12f15a0: LoadField: r1 = r3->field_1b
    //     0x12f15a0: ldur            w1, [x3, #0x1b]
    // 0x12f15a4: DecompressPointer r1
    //     0x12f15a4: add             x1, x1, HEAP, lsl #32
    // 0x12f15a8: tbnz            w1, #4, #0x12f167c
    // 0x12f15ac: cbz             w0, #0x12f1670
    // 0x12f15b0: ldur            d0, [fp, #-0x20]
    // 0x12f15b4: LoadField: r0 = r3->field_23
    //     0x12f15b4: ldur            w0, [x3, #0x23]
    // 0x12f15b8: DecompressPointer r0
    //     0x12f15b8: add             x0, x0, HEAP, lsl #32
    // 0x12f15bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12f15bc: ldur            w1, [x0, #0x17]
    // 0x12f15c0: DecompressPointer r1
    //     0x12f15c0: add             x1, x1, HEAP, lsl #32
    // 0x12f15c4: r2 = Instance__AnimationDirection
    //     0x12f15c4: ldr             x2, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0x12f15c8: r0 = _directionSetter()
    //     0x12f15c8: bl              #0xf3c0a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter
    // 0x12f15cc: ldur            x0, [fp, #-8]
    // 0x12f15d0: LoadField: d0 = r0->field_13
    //     0x12f15d0: ldur            d0, [x0, #0x13]
    // 0x12f15d4: LoadField: d1 = r0->field_b
    //     0x12f15d4: ldur            d1, [x0, #0xb]
    // 0x12f15d8: ldur            d2, [fp, #-0x20]
    // 0x12f15dc: r3 = inline_Allocate_Double()
    //     0x12f15dc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12f15e0: add             x3, x3, #0x10
    //     0x12f15e4: cmp             x0, x3
    //     0x12f15e8: b.ls            #0x12f1780
    //     0x12f15ec: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f15f0: sub             x3, x3, #0xf
    //     0x12f15f4: mov             x0, #0xe19c
    //     0x12f15f8: movk            x0, #3, lsl #16
    //     0x12f15fc: stur            x0, [x3, #-1]
    // 0x12f1600: dmb             ishst
    // 0x12f1604: StoreField: r3->field_7 = d2
    //     0x12f1604: stur            d2, [x3, #7]
    // 0x12f1608: r1 = inline_Allocate_Double()
    //     0x12f1608: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x12f160c: add             x1, x1, #0x10
    //     0x12f1610: cmp             x0, x1
    //     0x12f1614: b.ls            #0x12f179c
    //     0x12f1618: str             x1, [THR, #0x60]  ; THR::top
    //     0x12f161c: sub             x1, x1, #0xf
    //     0x12f1620: mov             x0, #0xe19c
    //     0x12f1624: movk            x0, #3, lsl #16
    //     0x12f1628: stur            x0, [x1, #-1]
    // 0x12f162c: dmb             ishst
    // 0x12f1630: StoreField: r1->field_7 = d0
    //     0x12f1630: stur            d0, [x1, #7]
    // 0x12f1634: r2 = inline_Allocate_Double()
    //     0x12f1634: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x12f1638: add             x2, x2, #0x10
    //     0x12f163c: cmp             x0, x2
    //     0x12f1640: b.ls            #0x12f17b8
    //     0x12f1644: str             x2, [THR, #0x60]  ; THR::top
    //     0x12f1648: sub             x2, x2, #0xf
    //     0x12f164c: mov             x0, #0xe19c
    //     0x12f1650: movk            x0, #3, lsl #16
    //     0x12f1654: stur            x0, [x2, #-1]
    // 0x12f1658: dmb             ishst
    // 0x12f165c: StoreField: r2->field_7 = d1
    //     0x12f165c: stur            d1, [x2, #7]
    // 0x12f1660: r0 = lerpDouble()
    //     0x12f1660: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x12f1664: LeaveFrame
    //     0x12f1664: mov             SP, fp
    //     0x12f1668: ldp             fp, lr, [SP], #0x10
    // 0x12f166c: ret
    //     0x12f166c: ret             
    // 0x12f1670: mov             x0, x3
    // 0x12f1674: ldur            d2, [fp, #-0x20]
    // 0x12f1678: b               #0x12f1684
    // 0x12f167c: mov             x0, x3
    // 0x12f1680: ldur            d2, [fp, #-0x20]
    // 0x12f1684: LoadField: r1 = r0->field_23
    //     0x12f1684: ldur            w1, [x0, #0x23]
    // 0x12f1688: DecompressPointer r1
    //     0x12f1688: add             x1, x1, HEAP, lsl #32
    // 0x12f168c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x12f168c: ldur            w2, [x1, #0x17]
    // 0x12f1690: DecompressPointer r2
    //     0x12f1690: add             x2, x2, HEAP, lsl #32
    // 0x12f1694: mov             x1, x2
    // 0x12f1698: r2 = Instance__AnimationDirection
    //     0x12f1698: ldr             x2, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x12f169c: r0 = _directionSetter()
    //     0x12f169c: bl              #0xf3c0a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter
    // 0x12f16a0: ldur            x0, [fp, #-8]
    // 0x12f16a4: LoadField: d0 = r0->field_b
    //     0x12f16a4: ldur            d0, [x0, #0xb]
    // 0x12f16a8: LoadField: d1 = r0->field_13
    //     0x12f16a8: ldur            d1, [x0, #0x13]
    // 0x12f16ac: ldur            d2, [fp, #-0x20]
    // 0x12f16b0: r3 = inline_Allocate_Double()
    //     0x12f16b0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12f16b4: add             x3, x3, #0x10
    //     0x12f16b8: cmp             x0, x3
    //     0x12f16bc: b.ls            #0x12f17d4
    //     0x12f16c0: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f16c4: sub             x3, x3, #0xf
    //     0x12f16c8: mov             x0, #0xe19c
    //     0x12f16cc: movk            x0, #3, lsl #16
    //     0x12f16d0: stur            x0, [x3, #-1]
    // 0x12f16d4: dmb             ishst
    // 0x12f16d8: StoreField: r3->field_7 = d2
    //     0x12f16d8: stur            d2, [x3, #7]
    // 0x12f16dc: r1 = inline_Allocate_Double()
    //     0x12f16dc: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x12f16e0: add             x1, x1, #0x10
    //     0x12f16e4: cmp             x0, x1
    //     0x12f16e8: b.ls            #0x12f17f0
    //     0x12f16ec: str             x1, [THR, #0x60]  ; THR::top
    //     0x12f16f0: sub             x1, x1, #0xf
    //     0x12f16f4: mov             x0, #0xe19c
    //     0x12f16f8: movk            x0, #3, lsl #16
    //     0x12f16fc: stur            x0, [x1, #-1]
    // 0x12f1700: dmb             ishst
    // 0x12f1704: StoreField: r1->field_7 = d0
    //     0x12f1704: stur            d0, [x1, #7]
    // 0x12f1708: r2 = inline_Allocate_Double()
    //     0x12f1708: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x12f170c: add             x2, x2, #0x10
    //     0x12f1710: cmp             x0, x2
    //     0x12f1714: b.ls            #0x12f180c
    //     0x12f1718: str             x2, [THR, #0x60]  ; THR::top
    //     0x12f171c: sub             x2, x2, #0xf
    //     0x12f1720: mov             x0, #0xe19c
    //     0x12f1724: movk            x0, #3, lsl #16
    //     0x12f1728: stur            x0, [x2, #-1]
    // 0x12f172c: dmb             ishst
    // 0x12f1730: StoreField: r2->field_7 = d1
    //     0x12f1730: stur            d1, [x2, #7]
    // 0x12f1734: r0 = lerpDouble()
    //     0x12f1734: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x12f1738: LeaveFrame
    //     0x12f1738: mov             SP, fp
    //     0x12f173c: ldp             fp, lr, [SP], #0x10
    // 0x12f1740: ret
    //     0x12f1740: ret             
    // 0x12f1744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f1744: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1748: b               #0x12f14c8
    // 0x12f174c: stp             q0, q1, [SP, #-0x20]!
    // 0x12f1750: SaveReg r19
    //     0x12f1750: str             x19, [SP, #-8]!
    // 0x12f1754: r0 = AllocateDouble()
    //     0x12f1754: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1758: RestoreReg r19
    //     0x12f1758: ldr             x19, [SP], #8
    // 0x12f175c: ldp             q0, q1, [SP], #0x20
    // 0x12f1760: b               #0x12f1550
    // 0x12f1764: stp             q0, q1, [SP, #-0x20]!
    // 0x12f1768: stp             x0, x19, [SP, #-0x10]!
    // 0x12f176c: r0 = AllocateDouble()
    //     0x12f176c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1770: mov             x1, x0
    // 0x12f1774: ldp             x0, x19, [SP], #0x10
    // 0x12f1778: ldp             q0, q1, [SP], #0x20
    // 0x12f177c: b               #0x12f1580
    // 0x12f1780: stp             q1, q2, [SP, #-0x20]!
    // 0x12f1784: SaveReg d0
    //     0x12f1784: str             q0, [SP, #-0x10]!
    // 0x12f1788: r0 = AllocateDouble()
    //     0x12f1788: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f178c: mov             x3, x0
    // 0x12f1790: RestoreReg d0
    //     0x12f1790: ldr             q0, [SP], #0x10
    // 0x12f1794: ldp             q1, q2, [SP], #0x20
    // 0x12f1798: b               #0x12f1604
    // 0x12f179c: stp             q0, q1, [SP, #-0x20]!
    // 0x12f17a0: SaveReg r3
    //     0x12f17a0: str             x3, [SP, #-8]!
    // 0x12f17a4: r0 = AllocateDouble()
    //     0x12f17a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f17a8: mov             x1, x0
    // 0x12f17ac: RestoreReg r3
    //     0x12f17ac: ldr             x3, [SP], #8
    // 0x12f17b0: ldp             q0, q1, [SP], #0x20
    // 0x12f17b4: b               #0x12f1630
    // 0x12f17b8: SaveReg d1
    //     0x12f17b8: str             q1, [SP, #-0x10]!
    // 0x12f17bc: stp             x1, x3, [SP, #-0x10]!
    // 0x12f17c0: r0 = AllocateDouble()
    //     0x12f17c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f17c4: mov             x2, x0
    // 0x12f17c8: ldp             x1, x3, [SP], #0x10
    // 0x12f17cc: RestoreReg d1
    //     0x12f17cc: ldr             q1, [SP], #0x10
    // 0x12f17d0: b               #0x12f165c
    // 0x12f17d4: stp             q1, q2, [SP, #-0x20]!
    // 0x12f17d8: SaveReg d0
    //     0x12f17d8: str             q0, [SP, #-0x10]!
    // 0x12f17dc: r0 = AllocateDouble()
    //     0x12f17dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f17e0: mov             x3, x0
    // 0x12f17e4: RestoreReg d0
    //     0x12f17e4: ldr             q0, [SP], #0x10
    // 0x12f17e8: ldp             q1, q2, [SP], #0x20
    // 0x12f17ec: b               #0x12f16d8
    // 0x12f17f0: stp             q0, q1, [SP, #-0x20]!
    // 0x12f17f4: SaveReg r3
    //     0x12f17f4: str             x3, [SP, #-8]!
    // 0x12f17f8: r0 = AllocateDouble()
    //     0x12f17f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f17fc: mov             x1, x0
    // 0x12f1800: RestoreReg r3
    //     0x12f1800: ldr             x3, [SP], #8
    // 0x12f1804: ldp             q0, q1, [SP], #0x20
    // 0x12f1808: b               #0x12f1704
    // 0x12f180c: SaveReg d1
    //     0x12f180c: str             q1, [SP, #-0x10]!
    // 0x12f1810: stp             x1, x3, [SP, #-0x10]!
    // 0x12f1814: r0 = AllocateDouble()
    //     0x12f1814: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1818: mov             x2, x0
    // 0x12f181c: ldp             x1, x3, [SP], #0x10
    // 0x12f1820: RestoreReg d1
    //     0x12f1820: ldr             q1, [SP], #0x10
    // 0x12f1824: b               #0x12f1730
  }
}

// class id: 3344, size: 0x28, field offset: 0xc
class _InterpolationSimulation extends Simulation {

  dynamic dx(dynamic) {
    // ** addr: 0x1183df8, size: 0x3c
    // 0x1183df8: EnterFrame
    //     0x1183df8: stp             fp, lr, [SP, #-0x10]!
    //     0x1183dfc: mov             fp, SP
    // 0x1183e00: ldr             x2, [fp, #0x10]
    // 0x1183e04: r1 = Function 'dx':.
    //     0x1183e04: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0638] AnonymousClosure: (0x866c68), in [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::dx (0x12dc3a4)
    //     0x1183e08: ldr             x1, [x1, #0x638]
    // 0x1183e0c: r0 = AllocateClosure()
    //     0x1183e0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1183e10: LeaveFrame
    //     0x1183e10: mov             SP, fp
    //     0x1183e14: ldp             fp, lr, [SP], #0x10
    // 0x1183e18: ret
    //     0x1183e18: ret             
  }
  _ _InterpolationSimulation(/* No info */) {
    // ** addr: 0x866c10, size: 0x58
    // 0x866c10: r4 = Instance_Tolerance
    //     0x866c10: ldr             x4, [PP, #0x51d8]  ; [pp+0x51d8] Obj!Tolerance@129c5c1
    // 0x866c14: d3 = 1000000.000000
    //     0x866c14: ldr             d3, [PP, #0x51e0]  ; [pp+0x51e0] IMM: double(1e+06) from 0x412e848000000000
    // 0x866c18: mov             x0, x3
    // 0x866c1c: StoreField: r1->field_13 = d0
    //     0x866c1c: stur            d0, [x1, #0x13]
    // 0x866c20: StoreField: r1->field_1b = d1
    //     0x866c20: stur            d1, [x1, #0x1b]
    // 0x866c24: StoreField: r1->field_23 = r0
    //     0x866c24: stur            w0, [x1, #0x23]
    //     0x866c28: ldurb           w16, [x1, #-1]
    //     0x866c2c: ldurb           w17, [x0, #-1]
    //     0x866c30: and             x16, x17, x16, lsr #2
    //     0x866c34: tst             x16, HEAP, lsr #32
    //     0x866c38: b.eq            #0x866c48
    //     0x866c3c: str             lr, [SP, #-8]!
    //     0x866c40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x866c44: ldr             lr, [SP], #8
    // 0x866c48: LoadField: r3 = r2->field_7
    //     0x866c48: ldur            x3, [x2, #7]
    // 0x866c4c: scvtf           d0, x3
    // 0x866c50: fmul            d1, d0, d2
    // 0x866c54: fdiv            d0, d1, d3
    // 0x866c58: StoreField: r1->field_b = d0
    //     0x866c58: stur            d0, [x1, #0xb]
    // 0x866c5c: StoreField: r1->field_7 = r4
    //     0x866c5c: stur            w4, [x1, #7]
    // 0x866c60: r0 = Null
    //     0x866c60: mov             x0, NULL
    // 0x866c64: ret
    //     0x866c64: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0x866c68, size: 0x78
    // 0x866c68: EnterFrame
    //     0x866c68: stp             fp, lr, [SP, #-0x10]!
    //     0x866c6c: mov             fp, SP
    // 0x866c70: ldr             x0, [fp, #0x18]
    // 0x866c74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x866c74: ldur            w1, [x0, #0x17]
    // 0x866c78: DecompressPointer r1
    //     0x866c78: add             x1, x1, HEAP, lsl #32
    // 0x866c7c: CheckStackOverflow
    //     0x866c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866c80: cmp             SP, x16
    //     0x866c84: b.ls            #0x866cc8
    // 0x866c88: ldr             x2, [fp, #0x10]
    // 0x866c8c: r0 = dx()
    //     0x866c8c: bl              #0x12dc3a4  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::dx
    // 0x866c90: r0 = inline_Allocate_Double()
    //     0x866c90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x866c94: add             x0, x0, #0x10
    //     0x866c98: cmp             x1, x0
    //     0x866c9c: b.ls            #0x866cd0
    //     0x866ca0: str             x0, [THR, #0x60]  ; THR::top
    //     0x866ca4: sub             x0, x0, #0xf
    //     0x866ca8: mov             x1, #0xe19c
    //     0x866cac: movk            x1, #3, lsl #16
    //     0x866cb0: stur            x1, [x0, #-1]
    // 0x866cb4: dmb             ishst
    // 0x866cb8: StoreField: r0->field_7 = d0
    //     0x866cb8: stur            d0, [x0, #7]
    // 0x866cbc: LeaveFrame
    //     0x866cbc: mov             SP, fp
    //     0x866cc0: ldp             fp, lr, [SP], #0x10
    // 0x866cc4: ret
    //     0x866cc4: ret             
    // 0x866cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866ccc: b               #0x866c88
    // 0x866cd0: SaveReg d0
    //     0x866cd0: str             q0, [SP, #-0x10]!
    // 0x866cd4: r0 = AllocateDouble()
    //     0x866cd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x866cd8: RestoreReg d0
    //     0x866cd8: ldr             q0, [SP], #0x10
    // 0x866cdc: b               #0x866cb8
  }
  _ isDone(/* No info */) {
    // ** addr: 0x12d8b18, size: 0x18
    // 0x12d8b18: LoadField: d1 = r1->field_b
    //     0x12d8b18: ldur            d1, [x1, #0xb]
    // 0x12d8b1c: fcmp            d0, d1
    // 0x12d8b20: r16 = true
    //     0x12d8b20: add             x16, NULL, #0x20  ; true
    // 0x12d8b24: r17 = false
    //     0x12d8b24: add             x17, NULL, #0x30  ; false
    // 0x12d8b28: csel            x0, x16, x17, gt
    // 0x12d8b2c: ret
    //     0x12d8b2c: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0x12dc3a4, size: 0x11c
    // 0x12dc3a4: EnterFrame
    //     0x12dc3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc3a8: mov             fp, SP
    // 0x12dc3ac: AllocStack(0x18)
    //     0x12dc3ac: sub             SP, SP, #0x18
    // 0x12dc3b0: d0 = 0.001000
    //     0x12dc3b0: ldr             d0, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x12dc3b4: mov             x0, x1
    // 0x12dc3b8: stur            x1, [fp, #-8]
    // 0x12dc3bc: CheckStackOverflow
    //     0x12dc3bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dc3c0: cmp             SP, x16
    //     0x12dc3c4: b.ls            #0x12dc478
    // 0x12dc3c8: LoadField: d1 = r2->field_7
    //     0x12dc3c8: ldur            d1, [x2, #7]
    // 0x12dc3cc: stur            d1, [fp, #-0x18]
    // 0x12dc3d0: fadd            d2, d1, d0
    // 0x12dc3d4: r2 = inline_Allocate_Double()
    //     0x12dc3d4: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x12dc3d8: add             x2, x2, #0x10
    //     0x12dc3dc: cmp             x1, x2
    //     0x12dc3e0: b.ls            #0x12dc480
    //     0x12dc3e4: str             x2, [THR, #0x60]  ; THR::top
    //     0x12dc3e8: sub             x2, x2, #0xf
    //     0x12dc3ec: mov             x1, #0xe19c
    //     0x12dc3f0: movk            x1, #3, lsl #16
    //     0x12dc3f4: stur            x1, [x2, #-1]
    // 0x12dc3f8: dmb             ishst
    // 0x12dc3fc: StoreField: r2->field_7 = d2
    //     0x12dc3fc: stur            d2, [x2, #7]
    // 0x12dc400: mov             x1, x0
    // 0x12dc404: r0 = x()
    //     0x12dc404: bl              #0x12f137c  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::x
    // 0x12dc408: ldur            d1, [fp, #-0x18]
    // 0x12dc40c: d0 = 0.001000
    //     0x12dc40c: ldr             d0, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x12dc410: stur            x0, [fp, #-0x10]
    // 0x12dc414: fsub            d2, d1, d0
    // 0x12dc418: r2 = inline_Allocate_Double()
    //     0x12dc418: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x12dc41c: add             x2, x2, #0x10
    //     0x12dc420: cmp             x1, x2
    //     0x12dc424: b.ls            #0x12dc4a4
    //     0x12dc428: str             x2, [THR, #0x60]  ; THR::top
    //     0x12dc42c: sub             x2, x2, #0xf
    //     0x12dc430: mov             x1, #0xe19c
    //     0x12dc434: movk            x1, #3, lsl #16
    //     0x12dc438: stur            x1, [x2, #-1]
    // 0x12dc43c: dmb             ishst
    // 0x12dc440: StoreField: r2->field_7 = d2
    //     0x12dc440: stur            d2, [x2, #7]
    // 0x12dc444: ldur            x1, [fp, #-8]
    // 0x12dc448: r0 = x()
    //     0x12dc448: bl              #0x12f137c  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::x
    // 0x12dc44c: mov             x1, x0
    // 0x12dc450: ldur            x0, [fp, #-0x10]
    // 0x12dc454: LoadField: d1 = r0->field_7
    //     0x12dc454: ldur            d1, [x0, #7]
    // 0x12dc458: LoadField: d2 = r1->field_7
    //     0x12dc458: ldur            d2, [x1, #7]
    // 0x12dc45c: fsub            d3, d1, d2
    // 0x12dc460: d1 = 0.002000
    //     0x12dc460: add             x17, PP, #0xe, lsl #12  ; [pp+0xe1e8] IMM: double(0.002) from 0x3f60624dd2f1a9fc
    //     0x12dc464: ldr             d1, [x17, #0x1e8]
    // 0x12dc468: fdiv            d0, d3, d1
    // 0x12dc46c: LeaveFrame
    //     0x12dc46c: mov             SP, fp
    //     0x12dc470: ldp             fp, lr, [SP], #0x10
    // 0x12dc474: ret
    //     0x12dc474: ret             
    // 0x12dc478: r0 = StackOverflowSharedWithFPURegs()
    //     0x12dc478: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12dc47c: b               #0x12dc3c8
    // 0x12dc480: stp             q1, q2, [SP, #-0x20]!
    // 0x12dc484: SaveReg d0
    //     0x12dc484: str             q0, [SP, #-0x10]!
    // 0x12dc488: SaveReg r0
    //     0x12dc488: str             x0, [SP, #-8]!
    // 0x12dc48c: r0 = AllocateDouble()
    //     0x12dc48c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12dc490: mov             x2, x0
    // 0x12dc494: RestoreReg r0
    //     0x12dc494: ldr             x0, [SP], #8
    // 0x12dc498: RestoreReg d0
    //     0x12dc498: ldr             q0, [SP], #0x10
    // 0x12dc49c: ldp             q1, q2, [SP], #0x20
    // 0x12dc4a0: b               #0x12dc3fc
    // 0x12dc4a4: SaveReg d2
    //     0x12dc4a4: str             q2, [SP, #-0x10]!
    // 0x12dc4a8: SaveReg r0
    //     0x12dc4a8: str             x0, [SP, #-8]!
    // 0x12dc4ac: r0 = AllocateDouble()
    //     0x12dc4ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12dc4b0: mov             x2, x0
    // 0x12dc4b4: RestoreReg r0
    //     0x12dc4b4: ldr             x0, [SP], #8
    // 0x12dc4b8: RestoreReg d2
    //     0x12dc4b8: ldr             q2, [SP], #0x10
    // 0x12dc4bc: b               #0x12dc440
  }
  _ x(/* No info */) {
    // ** addr: 0x12f137c, size: 0x12c
    // 0x12f137c: EnterFrame
    //     0x12f137c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f1380: mov             fp, SP
    // 0x12f1384: AllocStack(0x10)
    //     0x12f1384: sub             SP, SP, #0x10
    // 0x12f1388: d0 = 0.000000
    //     0x12f1388: eor             v0.16b, v0.16b, v0.16b
    // 0x12f138c: CheckStackOverflow
    //     0x12f138c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f1390: cmp             SP, x16
    //     0x12f1394: b.ls            #0x12f1490
    // 0x12f1398: LoadField: d1 = r1->field_b
    //     0x12f1398: ldur            d1, [x1, #0xb]
    // 0x12f139c: LoadField: d2 = r2->field_7
    //     0x12f139c: ldur            d2, [x2, #7]
    // 0x12f13a0: fdiv            d3, d2, d1
    // 0x12f13a4: fcmp            d0, d3
    // 0x12f13a8: b.le            #0x12f13b8
    // 0x12f13ac: d2 = 0.000000
    //     0x12f13ac: eor             v2.16b, v2.16b, v2.16b
    // 0x12f13b0: d1 = 1.000000
    //     0x12f13b0: fmov            d1, #1.00000000
    // 0x12f13b4: b               #0x12f13e0
    // 0x12f13b8: d1 = 1.000000
    //     0x12f13b8: fmov            d1, #1.00000000
    // 0x12f13bc: fcmp            d3, d1
    // 0x12f13c0: b.le            #0x12f13cc
    // 0x12f13c4: d2 = 1.000000
    //     0x12f13c4: fmov            d2, #1.00000000
    // 0x12f13c8: b               #0x12f13e0
    // 0x12f13cc: fcmp            d3, d3
    // 0x12f13d0: b.vc            #0x12f13dc
    // 0x12f13d4: d2 = 1.000000
    //     0x12f13d4: fmov            d2, #1.00000000
    // 0x12f13d8: b               #0x12f13e0
    // 0x12f13dc: mov             v2.16b, v3.16b
    // 0x12f13e0: fcmp            d2, d0
    // 0x12f13e4: b.ne            #0x12f13f0
    // 0x12f13e8: LoadField: d0 = r1->field_13
    //     0x12f13e8: ldur            d0, [x1, #0x13]
    // 0x12f13ec: b               #0x12f1458
    // 0x12f13f0: fcmp            d2, d1
    // 0x12f13f4: b.ne            #0x12f1400
    // 0x12f13f8: LoadField: d0 = r1->field_1b
    //     0x12f13f8: ldur            d0, [x1, #0x1b]
    // 0x12f13fc: b               #0x12f1458
    // 0x12f1400: LoadField: d1 = r1->field_13
    //     0x12f1400: ldur            d1, [x1, #0x13]
    // 0x12f1404: stur            d1, [fp, #-0x10]
    // 0x12f1408: LoadField: d0 = r1->field_1b
    //     0x12f1408: ldur            d0, [x1, #0x1b]
    // 0x12f140c: fsub            d3, d0, d1
    // 0x12f1410: stur            d3, [fp, #-8]
    // 0x12f1414: LoadField: r0 = r1->field_23
    //     0x12f1414: ldur            w0, [x1, #0x23]
    // 0x12f1418: DecompressPointer r0
    //     0x12f1418: add             x0, x0, HEAP, lsl #32
    // 0x12f141c: r1 = LoadClassIdInstr(r0)
    //     0x12f141c: ldur            x1, [x0, #-1]
    //     0x12f1420: ubfx            x1, x1, #0xc, #0x14
    // 0x12f1424: mov             x16, x0
    // 0x12f1428: mov             x0, x1
    // 0x12f142c: mov             x1, x16
    // 0x12f1430: mov             v0.16b, v2.16b
    // 0x12f1434: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f1434: sub             lr, x0, #1, lsl #12
    //     0x12f1438: ldr             lr, [x21, lr, lsl #3]
    //     0x12f143c: blr             lr
    // 0x12f1440: mov             v1.16b, v0.16b
    // 0x12f1444: ldur            d0, [fp, #-8]
    // 0x12f1448: fmul            d2, d0, d1
    // 0x12f144c: ldur            d0, [fp, #-0x10]
    // 0x12f1450: fadd            d1, d0, d2
    // 0x12f1454: mov             v0.16b, v1.16b
    // 0x12f1458: r0 = inline_Allocate_Double()
    //     0x12f1458: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f145c: add             x0, x0, #0x10
    //     0x12f1460: cmp             x1, x0
    //     0x12f1464: b.ls            #0x12f1498
    //     0x12f1468: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f146c: sub             x0, x0, #0xf
    //     0x12f1470: mov             x1, #0xe19c
    //     0x12f1474: movk            x1, #3, lsl #16
    //     0x12f1478: stur            x1, [x0, #-1]
    // 0x12f147c: dmb             ishst
    // 0x12f1480: StoreField: r0->field_7 = d0
    //     0x12f1480: stur            d0, [x0, #7]
    // 0x12f1484: LeaveFrame
    //     0x12f1484: mov             SP, fp
    //     0x12f1488: ldp             fp, lr, [SP], #0x10
    // 0x12f148c: ret
    //     0x12f148c: ret             
    // 0x12f1490: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f1490: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f1494: b               #0x12f1398
    // 0x12f1498: SaveReg d0
    //     0x12f1498: str             q0, [SP, #-0x10]!
    // 0x12f149c: r0 = AllocateDouble()
    //     0x12f149c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f14a0: RestoreReg d0
    //     0x12f14a0: ldr             q0, [SP], #0x10
    // 0x12f14a4: b               #0x12f1480
  }
}

// class id: 4369, size: 0x4c, field offset: 0x14
class AnimationController extends _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  late double _value; // offset: 0x38
  late AnimationStatus _status; // offset: 0x44

  set void value=(AnimationController, double) {
    // ** addr: 0x829534, size: 0x68
    // 0x829534: EnterFrame
    //     0x829534: stp             fp, lr, [SP, #-0x10]!
    //     0x829538: mov             fp, SP
    // 0x82953c: AllocStack(0x10)
    //     0x82953c: sub             SP, SP, #0x10
    // 0x829540: SetupParameters(AnimationController this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x829540: mov             x0, x1
    //     0x829544: stur            x1, [fp, #-8]
    //     0x829548: stur            x2, [fp, #-0x10]
    // 0x82954c: CheckStackOverflow
    //     0x82954c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829550: cmp             SP, x16
    //     0x829554: b.ls            #0x829594
    // 0x829558: mov             x1, x0
    // 0x82955c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82955c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x829560: r0 = stop()
    //     0x829560: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x829564: ldur            x0, [fp, #-0x10]
    // 0x829568: LoadField: d0 = r0->field_7
    //     0x829568: ldur            d0, [x0, #7]
    // 0x82956c: ldur            x1, [fp, #-8]
    // 0x829570: r0 = _internalSetValue()
    //     0x829570: bl              #0x82ea0c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x829574: ldur            x1, [fp, #-8]
    // 0x829578: r0 = notifyListeners()
    //     0x829578: bl              #0x82e55c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x82957c: ldur            x1, [fp, #-8]
    // 0x829580: r0 = _checkStatusChanged()
    //     0x829580: bl              #0x82970c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x829584: r0 = Null
    //     0x829584: mov             x0, NULL
    // 0x829588: LeaveFrame
    //     0x829588: mov             SP, fp
    //     0x82958c: ldp             fp, lr, [SP], #0x10
    // 0x829590: ret
    //     0x829590: ret             
    // 0x829594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829594: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829598: b               #0x829558
  }
  double dyn:get:value(AnimationController) {
    // ** addr: 0x8295b4, size: 0x44
    // 0x8295b4: ldr             x1, [SP]
    // 0x8295b8: LoadField: r0 = r1->field_37
    //     0x8295b8: ldur            w0, [x1, #0x37]
    // 0x8295bc: DecompressPointer r0
    //     0x8295bc: add             x0, x0, HEAP, lsl #32
    // 0x8295c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8295c4: cmp             w0, w16
    // 0x8295c8: b.eq            #0x8295d0
    // 0x8295cc: ret
    //     0x8295cc: ret             
    // 0x8295d0: EnterFrame
    //     0x8295d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8295d4: mov             fp, SP
    // 0x8295d8: r9 = _value
    //     0x8295d8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x8295dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8295dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  void dyn:set:value(AnimationController, double) {
    // ** addr: 0x8295f8, size: 0x80
    // 0x8295f8: EnterFrame
    //     0x8295f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8295fc: mov             fp, SP
    // 0x829600: CheckStackOverflow
    //     0x829600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829604: cmp             SP, x16
    //     0x829608: b.ls            #0x829658
    // 0x82960c: ldr             x0, [fp, #0x10]
    // 0x829610: r2 = Null
    //     0x829610: mov             x2, NULL
    // 0x829614: r1 = Null
    //     0x829614: mov             x1, NULL
    // 0x829618: r4 = 60
    //     0x829618: mov             x4, #0x3c
    // 0x82961c: branchIfSmi(r0, 0x829628)
    //     0x82961c: tbz             w0, #0, #0x829628
    // 0x829620: r4 = LoadClassIdInstr(r0)
    //     0x829620: ldur            x4, [x0, #-1]
    //     0x829624: ubfx            x4, x4, #0xc, #0x14
    // 0x829628: cmp             x4, #0x3e
    // 0x82962c: b.eq            #0x829640
    // 0x829630: r8 = double
    //     0x829630: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0x829634: r3 = Null
    //     0x829634: add             x3, PP, #0x85, lsl #12  ; [pp+0x85198] Null
    //     0x829638: ldr             x3, [x3, #0x198]
    // 0x82963c: r0 = double()
    //     0x82963c: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0x829640: ldr             x1, [fp, #0x18]
    // 0x829644: ldr             x2, [fp, #0x10]
    // 0x829648: r0 = value=()
    //     0x829648: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x82964c: LeaveFrame
    //     0x82964c: mov             SP, fp
    //     0x829650: ldp             fp, lr, [SP], #0x10
    // 0x829654: ret
    //     0x829654: ret             
    // 0x829658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82965c: b               #0x82960c
  }
  _ _checkStatusChanged(/* No info */) {
    // ** addr: 0x82970c, size: 0x7c
    // 0x82970c: EnterFrame
    //     0x82970c: stp             fp, lr, [SP, #-0x10]!
    //     0x829710: mov             fp, SP
    // 0x829714: CheckStackOverflow
    //     0x829714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829718: cmp             SP, x16
    //     0x82971c: b.ls            #0x829778
    // 0x829720: LoadField: r2 = r1->field_43
    //     0x829720: ldur            w2, [x1, #0x43]
    // 0x829724: DecompressPointer r2
    //     0x829724: add             x2, x2, HEAP, lsl #32
    // 0x829728: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82972c: cmp             w2, w16
    // 0x829730: b.eq            #0x829780
    // 0x829734: LoadField: r0 = r1->field_47
    //     0x829734: ldur            w0, [x1, #0x47]
    // 0x829738: DecompressPointer r0
    //     0x829738: add             x0, x0, HEAP, lsl #32
    // 0x82973c: cmp             w0, w2
    // 0x829740: b.eq            #0x829768
    // 0x829744: mov             x0, x2
    // 0x829748: StoreField: r1->field_47 = r0
    //     0x829748: stur            w0, [x1, #0x47]
    //     0x82974c: ldurb           w16, [x1, #-1]
    //     0x829750: ldurb           w17, [x0, #-1]
    //     0x829754: and             x16, x17, x16, lsr #2
    //     0x829758: tst             x16, HEAP, lsr #32
    //     0x82975c: b.eq            #0x829764
    //     0x829760: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x829764: r0 = notifyStatusListeners()
    //     0x829764: bl              #0x829788  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x829768: r0 = Null
    //     0x829768: mov             x0, NULL
    // 0x82976c: LeaveFrame
    //     0x82976c: mov             SP, fp
    //     0x829770: ldp             fp, lr, [SP], #0x10
    // 0x829774: ret
    //     0x829774: ret             
    // 0x829778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82977c: b               #0x829720
    // 0x829780: r9 = _status
    //     0x829780: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0x829784: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x829784: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  void _internalSetValue(AnimationController, double) {
    // ** addr: 0x82ea0c, size: 0x118
    // 0x82ea0c: EnterFrame
    //     0x82ea0c: stp             fp, lr, [SP, #-0x10]!
    //     0x82ea10: mov             fp, SP
    // 0x82ea14: LoadField: d1 = r1->field_13
    //     0x82ea14: ldur            d1, [x1, #0x13]
    // 0x82ea18: LoadField: d2 = r1->field_1b
    //     0x82ea18: ldur            d2, [x1, #0x1b]
    // 0x82ea1c: fcmp            d1, d0
    // 0x82ea20: b.le            #0x82ea2c
    // 0x82ea24: mov             v0.16b, v1.16b
    // 0x82ea28: b               #0x82ea48
    // 0x82ea2c: fcmp            d0, d2
    // 0x82ea30: b.le            #0x82ea3c
    // 0x82ea34: mov             v0.16b, v2.16b
    // 0x82ea38: b               #0x82ea48
    // 0x82ea3c: fcmp            d0, d0
    // 0x82ea40: b.vc            #0x82ea48
    // 0x82ea44: mov             v0.16b, v2.16b
    // 0x82ea48: r0 = inline_Allocate_Double()
    //     0x82ea48: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x82ea4c: add             x0, x0, #0x10
    //     0x82ea50: cmp             x2, x0
    //     0x82ea54: b.ls            #0x82eb04
    //     0x82ea58: str             x0, [THR, #0x60]  ; THR::top
    //     0x82ea5c: sub             x0, x0, #0xf
    //     0x82ea60: mov             x2, #0xe19c
    //     0x82ea64: movk            x2, #3, lsl #16
    //     0x82ea68: stur            x2, [x0, #-1]
    // 0x82ea6c: dmb             ishst
    // 0x82ea70: StoreField: r0->field_7 = d0
    //     0x82ea70: stur            d0, [x0, #7]
    // 0x82ea74: StoreField: r1->field_37 = r0
    //     0x82ea74: stur            w0, [x1, #0x37]
    //     0x82ea78: ldurb           w16, [x1, #-1]
    //     0x82ea7c: ldurb           w17, [x0, #-1]
    //     0x82ea80: and             x16, x17, x16, lsr #2
    //     0x82ea84: tst             x16, HEAP, lsr #32
    //     0x82ea88: b.eq            #0x82ea90
    //     0x82ea8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x82ea90: fcmp            d0, d1
    // 0x82ea94: b.ne            #0x82eaa4
    // 0x82ea98: r2 = Instance_AnimationStatus
    //     0x82ea98: ldr             x2, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x82ea9c: StoreField: r1->field_43 = r2
    //     0x82ea9c: stur            w2, [x1, #0x43]
    // 0x82eaa0: b               #0x82eaf4
    // 0x82eaa4: fcmp            d0, d2
    // 0x82eaa8: b.ne            #0x82eab8
    // 0x82eaac: r2 = Instance_AnimationStatus
    //     0x82eaac: ldr             x2, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x82eab0: StoreField: r1->field_43 = r2
    //     0x82eab0: stur            w2, [x1, #0x43]
    // 0x82eab4: b               #0x82eaf4
    // 0x82eab8: LoadField: r2 = r1->field_3f
    //     0x82eab8: ldur            w2, [x1, #0x3f]
    // 0x82eabc: DecompressPointer r2
    //     0x82eabc: add             x2, x2, HEAP, lsl #32
    // 0x82eac0: LoadField: r3 = r2->field_7
    //     0x82eac0: ldur            x3, [x2, #7]
    // 0x82eac4: cmp             x3, #0
    // 0x82eac8: b.gt            #0x82ead4
    // 0x82eacc: r0 = Instance_AnimationStatus
    //     0x82eacc: ldr             x0, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x82ead0: b               #0x82ead8
    // 0x82ead4: r0 = Instance_AnimationStatus
    //     0x82ead4: ldr             x0, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0x82ead8: StoreField: r1->field_43 = r0
    //     0x82ead8: stur            w0, [x1, #0x43]
    //     0x82eadc: ldurb           w16, [x1, #-1]
    //     0x82eae0: ldurb           w17, [x0, #-1]
    //     0x82eae4: and             x16, x17, x16, lsr #2
    //     0x82eae8: tst             x16, HEAP, lsr #32
    //     0x82eaec: b.eq            #0x82eaf4
    //     0x82eaf0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x82eaf4: r0 = Null
    //     0x82eaf4: mov             x0, NULL
    // 0x82eaf8: LeaveFrame
    //     0x82eaf8: mov             SP, fp
    //     0x82eafc: ldp             fp, lr, [SP], #0x10
    // 0x82eb00: ret
    //     0x82eb00: ret             
    // 0x82eb04: stp             q1, q2, [SP, #-0x20]!
    // 0x82eb08: SaveReg d0
    //     0x82eb08: str             q0, [SP, #-0x10]!
    // 0x82eb0c: SaveReg r1
    //     0x82eb0c: str             x1, [SP, #-8]!
    // 0x82eb10: r0 = AllocateDouble()
    //     0x82eb10: bl              #0x13df878  ; AllocateDoubleStub
    // 0x82eb14: RestoreReg r1
    //     0x82eb14: ldr             x1, [SP], #8
    // 0x82eb18: RestoreReg d0
    //     0x82eb18: ldr             q0, [SP], #0x10
    // 0x82eb1c: ldp             q1, q2, [SP], #0x20
    // 0x82eb20: b               #0x82ea70
  }
  _ stop(/* No info */) {
    // ** addr: 0x82eb24, size: 0x90
    // 0x82eb24: EnterFrame
    //     0x82eb24: stp             fp, lr, [SP, #-0x10]!
    //     0x82eb28: mov             fp, SP
    // 0x82eb2c: AllocStack(0x8)
    //     0x82eb2c: sub             SP, SP, #8
    // 0x82eb30: SetupParameters({dynamic canceled = true /* r0 */})
    //     0x82eb30: ldur            w0, [x4, #0x13]
    //     0x82eb34: ldur            w2, [x4, #0x1f]
    //     0x82eb38: add             x2, x2, HEAP, lsl #32
    //     0x82eb3c: ldr             x16, [PP, #0x5598]  ; [pp+0x5598] "canceled"
    //     0x82eb40: cmp             w2, w16
    //     0x82eb44: b.ne            #0x82eb60
    //     0x82eb48: ldur            w2, [x4, #0x23]
    //     0x82eb4c: add             x2, x2, HEAP, lsl #32
    //     0x82eb50: sub             w3, w0, w2
    //     0x82eb54: add             x0, fp, w3, sxtw #2
    //     0x82eb58: ldr             x0, [x0, #8]
    //     0x82eb5c: b               #0x82eb64
    //     0x82eb60: add             x0, NULL, #0x20  ; true
    // 0x82eb64: CheckStackOverflow
    //     0x82eb64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82eb68: cmp             SP, x16
    //     0x82eb6c: b.ls            #0x82eba8
    // 0x82eb70: StoreField: r1->field_33 = rNULL
    //     0x82eb70: stur            NULL, [x1, #0x33]
    // 0x82eb74: StoreField: r1->field_3b = rNULL
    //     0x82eb74: stur            NULL, [x1, #0x3b]
    // 0x82eb78: LoadField: r2 = r1->field_2f
    //     0x82eb78: ldur            w2, [x1, #0x2f]
    // 0x82eb7c: DecompressPointer r2
    //     0x82eb7c: add             x2, x2, HEAP, lsl #32
    // 0x82eb80: cmp             w2, NULL
    // 0x82eb84: b.eq            #0x82ebb0
    // 0x82eb88: str             x0, [SP]
    // 0x82eb8c: mov             x1, x2
    // 0x82eb90: r4 = const [0, 0x2, 0x1, 0x1, canceled, 0x1, null]
    //     0x82eb90: ldr             x4, [PP, #0x5570]  ; [pp+0x5570] List(7) [0, 0x2, 0x1, 0x1, "canceled", 0x1, Null]
    // 0x82eb94: r0 = stop()
    //     0x82eb94: bl              #0x82ebb4  ; [package:flutter/src/scheduler/ticker.dart] Ticker::stop
    // 0x82eb98: r0 = Null
    //     0x82eb98: mov             x0, NULL
    // 0x82eb9c: LeaveFrame
    //     0x82eb9c: mov             SP, fp
    //     0x82eba0: ldp             fp, lr, [SP], #0x10
    // 0x82eba4: ret
    //     0x82eba4: ret             
    // 0x82eba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82eba8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ebac: b               #0x82eb70
    // 0x82ebb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ebb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ animateTo(/* No info */) {
    // ** addr: 0x866084, size: 0xcc
    // 0x866084: EnterFrame
    //     0x866084: stp             fp, lr, [SP, #-0x10]!
    //     0x866088: mov             fp, SP
    // 0x86608c: AllocStack(0x10)
    //     0x86608c: sub             SP, SP, #0x10
    // 0x866090: SetupParameters({dynamic curve = Instance__Linear /* r3 */, dynamic duration = Null /* r2 */})
    //     0x866090: ldur            w0, [x4, #0x13]
    //     0x866094: ldur            w2, [x4, #0x1f]
    //     0x866098: add             x2, x2, HEAP, lsl #32
    //     0x86609c: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0x8660a0: cmp             w2, w16
    //     0x8660a4: b.ne            #0x8660c8
    //     0x8660a8: ldur            w2, [x4, #0x23]
    //     0x8660ac: add             x2, x2, HEAP, lsl #32
    //     0x8660b0: sub             w3, w0, w2
    //     0x8660b4: add             x2, fp, w3, sxtw #2
    //     0x8660b8: ldr             x2, [x2, #8]
    //     0x8660bc: mov             x3, x2
    //     0x8660c0: mov             x2, #1
    //     0x8660c4: b               #0x8660d0
    //     0x8660c8: ldr             x3, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    //     0x8660cc: mov             x2, #0
    //     0x8660d0: lsl             x5, x2, #1
    //     0x8660d4: lsl             w2, w5, #1
    //     0x8660d8: add             w5, w2, #8
    //     0x8660dc: add             x16, x4, w5, sxtw #1
    //     0x8660e0: ldur            w6, [x16, #0xf]
    //     0x8660e4: add             x6, x6, HEAP, lsl #32
    //     0x8660e8: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0x8660ec: cmp             w6, w16
    //     0x8660f0: b.ne            #0x866118
    //     0x8660f4: add             w5, w2, #0xa
    //     0x8660f8: add             x16, x4, w5, sxtw #1
    //     0x8660fc: ldur            w2, [x16, #0xf]
    //     0x866100: add             x2, x2, HEAP, lsl #32
    //     0x866104: sub             w4, w0, w2
    //     0x866108: add             x0, fp, w4, sxtw #2
    //     0x86610c: ldr             x0, [x0, #8]
    //     0x866110: mov             x2, x0
    //     0x866114: b               #0x86611c
    //     0x866118: mov             x2, NULL
    //     0x86611c: ldr             x0, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x86611c: r0 = Instance__AnimationDirection
    // 0x866120: CheckStackOverflow
    //     0x866120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866124: cmp             SP, x16
    //     0x866128: b.ls            #0x866148
    // 0x86612c: StoreField: r1->field_3f = r0
    //     0x86612c: stur            w0, [x1, #0x3f]
    // 0x866130: stp             x3, x2, [SP]
    // 0x866134: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x866134: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0x866138: r0 = _animateToInternal()
    //     0x866138: bl              #0x866150  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x86613c: LeaveFrame
    //     0x86613c: mov             SP, fp
    //     0x866140: ldp             fp, lr, [SP], #0x10
    // 0x866144: ret
    //     0x866144: ret             
    // 0x866148: r0 = StackOverflowSharedWithFPURegs()
    //     0x866148: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x86614c: b               #0x86612c
  }
  _ _animateToInternal(/* No info */) {
    // ** addr: 0x866150, size: 0x4c8
    // 0x866150: EnterFrame
    //     0x866150: stp             fp, lr, [SP, #-0x10]!
    //     0x866154: mov             fp, SP
    // 0x866158: AllocStack(0x58)
    //     0x866158: sub             SP, SP, #0x58
    // 0x86615c: SetupParameters(AnimationController this /* r1 => r0, fp-0x28 */, dynamic _ /* d0 => d0, fp-0x38 */, {dynamic curve = Instance__Linear /* r3, fp-0x20 */, dynamic duration = Null /* r2, fp-0x18 */})
    //     0x86615c: mov             x0, x1
    //     0x866160: stur            x1, [fp, #-0x28]
    //     0x866164: stur            d0, [fp, #-0x38]
    //     0x866168: ldur            w1, [x4, #0x13]
    //     0x86616c: ldur            w2, [x4, #0x1f]
    //     0x866170: add             x2, x2, HEAP, lsl #32
    //     0x866174: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0x866178: cmp             w2, w16
    //     0x86617c: b.ne            #0x8661a0
    //     0x866180: ldur            w2, [x4, #0x23]
    //     0x866184: add             x2, x2, HEAP, lsl #32
    //     0x866188: sub             w3, w1, w2
    //     0x86618c: add             x2, fp, w3, sxtw #2
    //     0x866190: ldr             x2, [x2, #8]
    //     0x866194: mov             x3, x2
    //     0x866198: mov             x2, #1
    //     0x86619c: b               #0x8661a8
    //     0x8661a0: ldr             x3, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    //     0x8661a4: mov             x2, #0
    //     0x8661a8: stur            x3, [fp, #-0x20]
    //     0x8661ac: lsl             x5, x2, #1
    //     0x8661b0: lsl             w2, w5, #1
    //     0x8661b4: add             w5, w2, #8
    //     0x8661b8: add             x16, x4, w5, sxtw #1
    //     0x8661bc: ldur            w6, [x16, #0xf]
    //     0x8661c0: add             x6, x6, HEAP, lsl #32
    //     0x8661c4: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0x8661c8: cmp             w6, w16
    //     0x8661cc: b.ne            #0x8661f4
    //     0x8661d0: add             w5, w2, #0xa
    //     0x8661d4: add             x16, x4, w5, sxtw #1
    //     0x8661d8: ldur            w2, [x16, #0xf]
    //     0x8661dc: add             x2, x2, HEAP, lsl #32
    //     0x8661e0: sub             w4, w1, w2
    //     0x8661e4: add             x1, fp, w4, sxtw #2
    //     0x8661e8: ldr             x1, [x1, #8]
    //     0x8661ec: mov             x2, x1
    //     0x8661f0: b               #0x8661f8
    //     0x8661f4: mov             x2, NULL
    //     0x8661f8: stur            x2, [fp, #-0x18]
    // 0x8661fc: CheckStackOverflow
    //     0x8661fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866200: cmp             SP, x16
    //     0x866204: b.ls            #0x8665ac
    // 0x866208: LoadField: r4 = r0->field_23
    //     0x866208: ldur            w4, [x0, #0x23]
    // 0x86620c: DecompressPointer r4
    //     0x86620c: add             x4, x4, HEAP, lsl #32
    // 0x866210: stur            x4, [fp, #-0x10]
    // 0x866214: r16 = Instance_AnimationBehavior
    //     0x866214: ldr             x16, [PP, #0x5180]  ; [pp+0x5180] Obj!AnimationBehavior@12c6101
    // 0x866218: cmp             w4, w16
    // 0x86621c: r16 = true
    //     0x86621c: add             x16, NULL, #0x20  ; true
    // 0x866220: r17 = false
    //     0x866220: add             x17, NULL, #0x30  ; false
    // 0x866224: csel            x5, x16, x17, eq
    // 0x866228: stur            x5, [fp, #-8]
    // 0x86622c: tbnz            w5, #4, #0x866250
    // 0x866230: r1 = LoadStaticField(0x7d4)
    //     0x866230: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x866234: ldr             x1, [x1, #0xfa8]
    // 0x866238: cmp             w1, NULL
    // 0x86623c: b.eq            #0x8665b4
    // 0x866240: r0 = disableAnimations()
    //     0x866240: bl              #0x866cf8  ; [dart:mixin_deduplication] _MixinApplication206&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding::disableAnimations
    // 0x866244: tbnz            w0, #4, #0x866250
    // 0x866248: r3 = 0.050000
    //     0x866248: ldr             x3, [PP, #0x5188]  ; [pp+0x5188] 0.05
    // 0x86624c: b               #0x866274
    // 0x866250: ldur            x0, [fp, #-8]
    // 0x866254: tbz             w0, #4, #0x866268
    // 0x866258: ldur            x0, [fp, #-0x10]
    // 0x86625c: r16 = Instance_AnimationBehavior
    //     0x86625c: ldr             x16, [PP, #0x5190]  ; [pp+0x5190] Obj!AnimationBehavior@12c60e1
    // 0x866260: cmp             w0, w16
    // 0x866264: b.ne            #0x866270
    // 0x866268: r3 = 1.000000
    //     0x866268: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x86626c: b               #0x866274
    // 0x866270: r3 = Null
    //     0x866270: mov             x3, NULL
    // 0x866274: ldur            x0, [fp, #-0x18]
    // 0x866278: stur            x3, [fp, #-8]
    // 0x86627c: cmp             w0, NULL
    // 0x866280: b.ne            #0x866384
    // 0x866284: ldur            x0, [fp, #-0x28]
    // 0x866288: LoadField: d0 = r0->field_1b
    //     0x866288: ldur            d0, [x0, #0x1b]
    // 0x86628c: LoadField: d1 = r0->field_13
    //     0x86628c: ldur            d1, [x0, #0x13]
    // 0x866290: fsub            d2, d0, d1
    // 0x866294: mov             x1, v2.d[0]
    // 0x866298: and             x1, x1, #0x7fffffffffffffff
    // 0x86629c: r17 = 9218868437227405312
    //     0x86629c: mov             x17, #0x7ff0000000000000
    // 0x8662a0: cmp             x1, x17
    // 0x8662a4: b.eq            #0x86630c
    // 0x8662a8: fcmp            d2, d2
    // 0x8662ac: b.vs            #0x866304
    // 0x8662b0: ldur            d0, [fp, #-0x38]
    // 0x8662b4: d1 = 0.000000
    //     0x8662b4: eor             v1.16b, v1.16b, v1.16b
    // 0x8662b8: LoadField: r1 = r0->field_37
    //     0x8662b8: ldur            w1, [x0, #0x37]
    // 0x8662bc: DecompressPointer r1
    //     0x8662bc: add             x1, x1, HEAP, lsl #32
    // 0x8662c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8662c4: cmp             w1, w16
    // 0x8662c8: b.eq            #0x8665b8
    // 0x8662cc: LoadField: d3 = r1->field_7
    //     0x8662cc: ldur            d3, [x1, #7]
    // 0x8662d0: fsub            d4, d0, d3
    // 0x8662d4: fcmp            d4, d1
    // 0x8662d8: b.ne            #0x8662e4
    // 0x8662dc: d1 = 0.000000
    //     0x8662dc: eor             v1.16b, v1.16b, v1.16b
    // 0x8662e0: b               #0x8662f8
    // 0x8662e4: fcmp            d1, d4
    // 0x8662e8: b.le            #0x8662f4
    // 0x8662ec: fneg            d1, d4
    // 0x8662f0: b               #0x8662f8
    // 0x8662f4: mov             v1.16b, v4.16b
    // 0x8662f8: fdiv            d3, d1, d2
    // 0x8662fc: mov             v1.16b, v3.16b
    // 0x866300: b               #0x866314
    // 0x866304: ldur            d0, [fp, #-0x38]
    // 0x866308: b               #0x866310
    // 0x86630c: ldur            d0, [fp, #-0x38]
    // 0x866310: d1 = 1.000000
    //     0x866310: fmov            d1, #1.00000000
    // 0x866314: LoadField: r1 = r0->field_3f
    //     0x866314: ldur            w1, [x0, #0x3f]
    // 0x866318: DecompressPointer r1
    //     0x866318: add             x1, x1, HEAP, lsl #32
    // 0x86631c: r16 = Instance__AnimationDirection
    //     0x86631c: ldr             x16, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0x866320: cmp             w1, w16
    // 0x866324: b.ne            #0x866338
    // 0x866328: LoadField: r1 = r0->field_2b
    //     0x866328: ldur            w1, [x0, #0x2b]
    // 0x86632c: DecompressPointer r1
    //     0x86632c: add             x1, x1, HEAP, lsl #32
    // 0x866330: cmp             w1, NULL
    // 0x866334: b.ne            #0x866348
    // 0x866338: LoadField: r1 = r0->field_27
    //     0x866338: ldur            w1, [x0, #0x27]
    // 0x86633c: DecompressPointer r1
    //     0x86633c: add             x1, x1, HEAP, lsl #32
    // 0x866340: cmp             w1, NULL
    // 0x866344: b.eq            #0x8665c0
    // 0x866348: r2 = inline_Allocate_Double()
    //     0x866348: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x86634c: add             x2, x2, #0x10
    //     0x866350: cmp             x4, x2
    //     0x866354: b.ls            #0x8665c4
    //     0x866358: str             x2, [THR, #0x60]  ; THR::top
    //     0x86635c: sub             x2, x2, #0xf
    //     0x866360: mov             x4, #0xe19c
    //     0x866364: movk            x4, #3, lsl #16
    //     0x866368: stur            x4, [x2, #-1]
    // 0x86636c: dmb             ishst
    // 0x866370: StoreField: r2->field_7 = d1
    //     0x866370: stur            d1, [x2, #7]
    // 0x866374: r0 = *()
    //     0x866374: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0x866378: ldur            x2, [fp, #-0x28]
    // 0x86637c: ldur            d0, [fp, #-0x38]
    // 0x866380: b               #0x8663b0
    // 0x866384: ldur            x2, [fp, #-0x28]
    // 0x866388: ldur            d0, [fp, #-0x38]
    // 0x86638c: LoadField: r1 = r2->field_37
    //     0x86638c: ldur            w1, [x2, #0x37]
    // 0x866390: DecompressPointer r1
    //     0x866390: add             x1, x1, HEAP, lsl #32
    // 0x866394: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x866398: cmp             w1, w16
    // 0x86639c: b.eq            #0x8665e8
    // 0x8663a0: LoadField: d1 = r1->field_7
    //     0x8663a0: ldur            d1, [x1, #7]
    // 0x8663a4: fcmp            d0, d1
    // 0x8663a8: b.ne            #0x8663b0
    // 0x8663ac: r0 = Instance_Duration
    //     0x8663ac: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x8663b0: mov             x1, x2
    // 0x8663b4: stur            x0, [fp, #-0x10]
    // 0x8663b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8663b8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8663bc: r0 = stop()
    //     0x8663bc: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x8663c0: ldur            x16, [fp, #-0x10]
    // 0x8663c4: r30 = Instance_Duration
    //     0x8663c4: ldr             lr, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x8663c8: stp             lr, x16, [SP]
    // 0x8663cc: r0 = ==()
    //     0x8663cc: bl              #0x124ef40  ; [dart:core] Duration::==
    // 0x8663d0: tbnz            w0, #4, #0x866540
    // 0x8663d4: ldur            x2, [fp, #-0x28]
    // 0x8663d8: ldur            d0, [fp, #-0x38]
    // 0x8663dc: LoadField: r0 = r2->field_37
    //     0x8663dc: ldur            w0, [x2, #0x37]
    // 0x8663e0: DecompressPointer r0
    //     0x8663e0: add             x0, x0, HEAP, lsl #32
    // 0x8663e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8663e8: cmp             w0, w16
    // 0x8663ec: b.eq            #0x8665f0
    // 0x8663f0: LoadField: d1 = r0->field_7
    //     0x8663f0: ldur            d1, [x0, #7]
    // 0x8663f4: fcmp            d1, d0
    // 0x8663f8: b.eq            #0x866480
    // 0x8663fc: LoadField: d1 = r2->field_13
    //     0x8663fc: ldur            d1, [x2, #0x13]
    // 0x866400: LoadField: d2 = r2->field_1b
    //     0x866400: ldur            d2, [x2, #0x1b]
    // 0x866404: fcmp            d1, d0
    // 0x866408: b.le            #0x866414
    // 0x86640c: mov             v0.16b, v1.16b
    // 0x866410: b               #0x866430
    // 0x866414: fcmp            d0, d2
    // 0x866418: b.le            #0x866424
    // 0x86641c: mov             v0.16b, v2.16b
    // 0x866420: b               #0x866430
    // 0x866424: fcmp            d0, d0
    // 0x866428: b.vc            #0x866430
    // 0x86642c: mov             v0.16b, v2.16b
    // 0x866430: r0 = inline_Allocate_Double()
    //     0x866430: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x866434: add             x0, x0, #0x10
    //     0x866438: cmp             x1, x0
    //     0x86643c: b.ls            #0x8665f8
    //     0x866440: str             x0, [THR, #0x60]  ; THR::top
    //     0x866444: sub             x0, x0, #0xf
    //     0x866448: mov             x1, #0xe19c
    //     0x86644c: movk            x1, #3, lsl #16
    //     0x866450: stur            x1, [x0, #-1]
    // 0x866454: dmb             ishst
    // 0x866458: StoreField: r0->field_7 = d0
    //     0x866458: stur            d0, [x0, #7]
    // 0x86645c: StoreField: r2->field_37 = r0
    //     0x86645c: stur            w0, [x2, #0x37]
    //     0x866460: ldurb           w16, [x2, #-1]
    //     0x866464: ldurb           w17, [x0, #-1]
    //     0x866468: and             x16, x17, x16, lsr #2
    //     0x86646c: tst             x16, HEAP, lsr #32
    //     0x866470: b.eq            #0x866478
    //     0x866474: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x866478: mov             x1, x2
    // 0x86647c: r0 = notifyListeners()
    //     0x86647c: bl              #0x82e55c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x866480: ldur            x1, [fp, #-0x28]
    // 0x866484: LoadField: r0 = r1->field_3f
    //     0x866484: ldur            w0, [x1, #0x3f]
    // 0x866488: DecompressPointer r0
    //     0x866488: add             x0, x0, HEAP, lsl #32
    // 0x86648c: r16 = Instance__AnimationDirection
    //     0x86648c: ldr             x16, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x866490: cmp             w0, w16
    // 0x866494: b.ne            #0x8664a0
    // 0x866498: r0 = Instance_AnimationStatus
    //     0x866498: ldr             x0, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x86649c: b               #0x8664a4
    // 0x8664a0: r0 = Instance_AnimationStatus
    //     0x8664a0: ldr             x0, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x8664a4: StoreField: r1->field_43 = r0
    //     0x8664a4: stur            w0, [x1, #0x43]
    //     0x8664a8: ldurb           w16, [x1, #-1]
    //     0x8664ac: ldurb           w17, [x0, #-1]
    //     0x8664b0: and             x16, x17, x16, lsr #2
    //     0x8664b4: tst             x16, HEAP, lsr #32
    //     0x8664b8: b.eq            #0x8664c0
    //     0x8664bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8664c0: r0 = _checkStatusChanged()
    //     0x8664c0: bl              #0x82970c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x8664c4: r1 = <void?>
    //     0x8664c4: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8664c8: r0 = _Future()
    //     0x8664c8: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8664cc: stur            x0, [fp, #-0x18]
    // 0x8664d0: StoreField: r0->field_b = rZR
    //     0x8664d0: stur            xzr, [x0, #0xb]
    // 0x8664d4: r0 = LoadStaticField(0x364)
    //     0x8664d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8664d8: ldr             x0, [x0, #0x6c8]
    // 0x8664dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8664e0: cmp             w0, w16
    // 0x8664e4: b.ne            #0x8664f0
    // 0x8664e8: r2 = _current
    //     0x8664e8: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8664ec: r0 = InitLateStaticField()
    //     0x8664ec: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8664f0: mov             x1, x0
    // 0x8664f4: ldur            x0, [fp, #-0x18]
    // 0x8664f8: StoreField: r0->field_13 = r1
    //     0x8664f8: stur            w1, [x0, #0x13]
    // 0x8664fc: r1 = <void?>
    //     0x8664fc: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x866500: r0 = _AsyncCompleter()
    //     0x866500: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x866504: mov             x1, x0
    // 0x866508: ldur            x0, [fp, #-0x18]
    // 0x86650c: stur            x1, [fp, #-0x30]
    // 0x866510: StoreField: r1->field_b = r0
    //     0x866510: stur            w0, [x1, #0xb]
    // 0x866514: r0 = TickerFuture()
    //     0x866514: bl              #0x866cec  ; AllocateTickerFutureStub -> TickerFuture (size=0x14)
    // 0x866518: mov             x2, x0
    // 0x86651c: ldur            x0, [fp, #-0x30]
    // 0x866520: stur            x2, [fp, #-0x18]
    // 0x866524: StoreField: r2->field_7 = r0
    //     0x866524: stur            w0, [x2, #7]
    // 0x866528: mov             x1, x2
    // 0x86652c: r0 = _complete()
    //     0x86652c: bl              #0x82ec7c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_complete
    // 0x866530: ldur            x0, [fp, #-0x18]
    // 0x866534: LeaveFrame
    //     0x866534: mov             SP, fp
    //     0x866538: ldp             fp, lr, [SP], #0x10
    // 0x86653c: ret
    //     0x86653c: ret             
    // 0x866540: ldur            x1, [fp, #-0x28]
    // 0x866544: ldur            d0, [fp, #-0x38]
    // 0x866548: ldur            x0, [fp, #-8]
    // 0x86654c: LoadField: r2 = r1->field_37
    //     0x86654c: ldur            w2, [x1, #0x37]
    // 0x866550: DecompressPointer r2
    //     0x866550: add             x2, x2, HEAP, lsl #32
    // 0x866554: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x866558: cmp             w2, w16
    // 0x86655c: b.eq            #0x866610
    // 0x866560: LoadField: d2 = r0->field_7
    //     0x866560: ldur            d2, [x0, #7]
    // 0x866564: stur            d2, [fp, #-0x48]
    // 0x866568: LoadField: d1 = r2->field_7
    //     0x866568: ldur            d1, [x2, #7]
    // 0x86656c: stur            d1, [fp, #-0x40]
    // 0x866570: r0 = _InterpolationSimulation()
    //     0x866570: bl              #0x866ce0  ; Allocate_InterpolationSimulationStub -> _InterpolationSimulation (size=0x28)
    // 0x866574: mov             x1, x0
    // 0x866578: ldur            d0, [fp, #-0x40]
    // 0x86657c: ldur            d1, [fp, #-0x38]
    // 0x866580: ldur            x2, [fp, #-0x10]
    // 0x866584: ldur            x3, [fp, #-0x20]
    // 0x866588: ldur            d2, [fp, #-0x48]
    // 0x86658c: stur            x0, [fp, #-8]
    // 0x866590: r0 = _InterpolationSimulation()
    //     0x866590: bl              #0x866c10  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::_InterpolationSimulation
    // 0x866594: ldur            x1, [fp, #-0x28]
    // 0x866598: ldur            x2, [fp, #-8]
    // 0x86659c: r0 = _startSimulation()
    //     0x86659c: bl              #0x866618  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x8665a0: LeaveFrame
    //     0x8665a0: mov             SP, fp
    //     0x8665a4: ldp             fp, lr, [SP], #0x10
    // 0x8665a8: ret
    //     0x8665a8: ret             
    // 0x8665ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x8665ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x8665b0: b               #0x866208
    // 0x8665b4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8665b4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x8665b8: r9 = _value
    //     0x8665b8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x8665bc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8665bc: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8665c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8665c0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x8665c4: stp             q0, q1, [SP, #-0x20]!
    // 0x8665c8: stp             x1, x3, [SP, #-0x10]!
    // 0x8665cc: SaveReg r0
    //     0x8665cc: str             x0, [SP, #-8]!
    // 0x8665d0: r0 = AllocateDouble()
    //     0x8665d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8665d4: mov             x2, x0
    // 0x8665d8: RestoreReg r0
    //     0x8665d8: ldr             x0, [SP], #8
    // 0x8665dc: ldp             x1, x3, [SP], #0x10
    // 0x8665e0: ldp             q0, q1, [SP], #0x20
    // 0x8665e4: b               #0x866370
    // 0x8665e8: r9 = _value
    //     0x8665e8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x8665ec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8665ec: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8665f0: r9 = _value
    //     0x8665f0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x8665f4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8665f4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8665f8: SaveReg d0
    //     0x8665f8: str             q0, [SP, #-0x10]!
    // 0x8665fc: SaveReg r2
    //     0x8665fc: str             x2, [SP, #-8]!
    // 0x866600: r0 = AllocateDouble()
    //     0x866600: bl              #0x13df878  ; AllocateDoubleStub
    // 0x866604: RestoreReg r2
    //     0x866604: ldr             x2, [SP], #8
    // 0x866608: RestoreReg d0
    //     0x866608: ldr             q0, [SP], #0x10
    // 0x86660c: b               #0x866458
    // 0x866610: r9 = _value
    //     0x866610: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x866614: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x866614: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _startSimulation(/* No info */) {
    // ** addr: 0x866618, size: 0x17c
    // 0x866618: EnterFrame
    //     0x866618: stp             fp, lr, [SP, #-0x10]!
    //     0x86661c: mov             fp, SP
    // 0x866620: AllocStack(0x10)
    //     0x866620: sub             SP, SP, #0x10
    // 0x866624: r3 = Instance_Duration
    //     0x866624: ldr             x3, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x866628: mov             x4, x1
    // 0x86662c: stur            x1, [fp, #-8]
    // 0x866630: mov             x1, x2
    // 0x866634: CheckStackOverflow
    //     0x866634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866638: cmp             SP, x16
    //     0x86663c: b.ls            #0x866770
    // 0x866640: mov             x0, x1
    // 0x866644: StoreField: r4->field_33 = r0
    //     0x866644: stur            w0, [x4, #0x33]
    //     0x866648: ldurb           w16, [x4, #-1]
    //     0x86664c: ldurb           w17, [x0, #-1]
    //     0x866650: and             x16, x17, x16, lsr #2
    //     0x866654: tst             x16, HEAP, lsr #32
    //     0x866658: b.eq            #0x866660
    //     0x86665c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x866660: StoreField: r4->field_3b = r3
    //     0x866660: stur            w3, [x4, #0x3b]
    // 0x866664: r0 = LoadClassIdInstr(r1)
    //     0x866664: ldur            x0, [x1, #-1]
    //     0x866668: ubfx            x0, x0, #0xc, #0x14
    // 0x86666c: r2 = 0.000000
    //     0x86666c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x866670: r0 = GDT[cid_x0 + -0xfca]()
    //     0x866670: sub             lr, x0, #0xfca
    //     0x866674: ldr             lr, [x21, lr, lsl #3]
    //     0x866678: blr             lr
    // 0x86667c: ldur            x2, [fp, #-8]
    // 0x866680: LoadField: d0 = r2->field_13
    //     0x866680: ldur            d0, [x2, #0x13]
    // 0x866684: LoadField: d1 = r2->field_1b
    //     0x866684: ldur            d1, [x2, #0x1b]
    // 0x866688: LoadField: d2 = r0->field_7
    //     0x866688: ldur            d2, [x0, #7]
    // 0x86668c: fcmp            d0, d2
    // 0x866690: b.gt            #0x8666b8
    // 0x866694: fcmp            d2, d1
    // 0x866698: b.le            #0x8666a4
    // 0x86669c: mov             v0.16b, v1.16b
    // 0x8666a0: b               #0x8666b8
    // 0x8666a4: fcmp            d2, d2
    // 0x8666a8: b.vc            #0x8666b4
    // 0x8666ac: mov             v0.16b, v1.16b
    // 0x8666b0: b               #0x8666b8
    // 0x8666b4: mov             v0.16b, v2.16b
    // 0x8666b8: r0 = inline_Allocate_Double()
    //     0x8666b8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8666bc: add             x0, x0, #0x10
    //     0x8666c0: cmp             x1, x0
    //     0x8666c4: b.ls            #0x866778
    //     0x8666c8: str             x0, [THR, #0x60]  ; THR::top
    //     0x8666cc: sub             x0, x0, #0xf
    //     0x8666d0: mov             x1, #0xe19c
    //     0x8666d4: movk            x1, #3, lsl #16
    //     0x8666d8: stur            x1, [x0, #-1]
    // 0x8666dc: dmb             ishst
    // 0x8666e0: StoreField: r0->field_7 = d0
    //     0x8666e0: stur            d0, [x0, #7]
    // 0x8666e4: StoreField: r2->field_37 = r0
    //     0x8666e4: stur            w0, [x2, #0x37]
    //     0x8666e8: ldurb           w16, [x2, #-1]
    //     0x8666ec: ldurb           w17, [x0, #-1]
    //     0x8666f0: and             x16, x17, x16, lsr #2
    //     0x8666f4: tst             x16, HEAP, lsr #32
    //     0x8666f8: b.eq            #0x866700
    //     0x8666fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x866700: LoadField: r1 = r2->field_2f
    //     0x866700: ldur            w1, [x2, #0x2f]
    // 0x866704: DecompressPointer r1
    //     0x866704: add             x1, x1, HEAP, lsl #32
    // 0x866708: cmp             w1, NULL
    // 0x86670c: b.eq            #0x866790
    // 0x866710: r0 = start()
    //     0x866710: bl              #0x866794  ; [package:flutter/src/scheduler/ticker.dart] Ticker::start
    // 0x866714: mov             x2, x0
    // 0x866718: ldur            x1, [fp, #-8]
    // 0x86671c: stur            x2, [fp, #-0x10]
    // 0x866720: LoadField: r0 = r1->field_3f
    //     0x866720: ldur            w0, [x1, #0x3f]
    // 0x866724: DecompressPointer r0
    //     0x866724: add             x0, x0, HEAP, lsl #32
    // 0x866728: r16 = Instance__AnimationDirection
    //     0x866728: ldr             x16, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x86672c: cmp             w0, w16
    // 0x866730: b.ne            #0x86673c
    // 0x866734: r0 = Instance_AnimationStatus
    //     0x866734: ldr             x0, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x866738: b               #0x866740
    // 0x86673c: r0 = Instance_AnimationStatus
    //     0x86673c: ldr             x0, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0x866740: StoreField: r1->field_43 = r0
    //     0x866740: stur            w0, [x1, #0x43]
    //     0x866744: ldurb           w16, [x1, #-1]
    //     0x866748: ldurb           w17, [x0, #-1]
    //     0x86674c: and             x16, x17, x16, lsr #2
    //     0x866750: tst             x16, HEAP, lsr #32
    //     0x866754: b.eq            #0x86675c
    //     0x866758: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86675c: r0 = _checkStatusChanged()
    //     0x86675c: bl              #0x82970c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x866760: ldur            x0, [fp, #-0x10]
    // 0x866764: LeaveFrame
    //     0x866764: mov             SP, fp
    //     0x866768: ldp             fp, lr, [SP], #0x10
    // 0x86676c: ret
    //     0x86676c: ret             
    // 0x866770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866774: b               #0x866640
    // 0x866778: SaveReg d0
    //     0x866778: str             q0, [SP, #-0x10]!
    // 0x86677c: SaveReg r2
    //     0x86677c: str             x2, [SP, #-8]!
    // 0x866780: r0 = AllocateDouble()
    //     0x866780: bl              #0x13df878  ; AllocateDoubleStub
    // 0x866784: RestoreReg r2
    //     0x866784: ldr             x2, [SP], #8
    // 0x866788: RestoreReg d0
    //     0x866788: ldr             q0, [SP], #0x10
    // 0x86678c: b               #0x8666e0
    // 0x866790: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866790: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ animateWith(/* No info */) {
    // ** addr: 0x866f9c, size: 0x58
    // 0x866f9c: EnterFrame
    //     0x866f9c: stp             fp, lr, [SP, #-0x10]!
    //     0x866fa0: mov             fp, SP
    // 0x866fa4: AllocStack(0x10)
    //     0x866fa4: sub             SP, SP, #0x10
    // 0x866fa8: SetupParameters(AnimationController this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x866fa8: mov             x0, x1
    //     0x866fac: stur            x1, [fp, #-8]
    //     0x866fb0: stur            x2, [fp, #-0x10]
    // 0x866fb4: CheckStackOverflow
    //     0x866fb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866fb8: cmp             SP, x16
    //     0x866fbc: b.ls            #0x866fec
    // 0x866fc0: mov             x1, x0
    // 0x866fc4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x866fc4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x866fc8: r0 = stop()
    //     0x866fc8: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x866fcc: ldur            x1, [fp, #-8]
    // 0x866fd0: r0 = Instance__AnimationDirection
    //     0x866fd0: ldr             x0, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x866fd4: StoreField: r1->field_3f = r0
    //     0x866fd4: stur            w0, [x1, #0x3f]
    // 0x866fd8: ldur            x2, [fp, #-0x10]
    // 0x866fdc: r0 = _startSimulation()
    //     0x866fdc: bl              #0x866618  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x866fe0: LeaveFrame
    //     0x866fe0: mov             SP, fp
    //     0x866fe4: ldp             fp, lr, [SP], #0x10
    // 0x866fe8: ret
    //     0x866fe8: ret             
    // 0x866fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866ff0: b               #0x866fc0
  }
  _ AnimationController.unbounded(/* No info */) {
    // ** addr: 0x86ef04, size: 0x1d0
    // 0x86ef04: EnterFrame
    //     0x86ef04: stp             fp, lr, [SP, #-0x10]!
    //     0x86ef08: mov             fp, SP
    // 0x86ef0c: AllocStack(0x30)
    //     0x86ef0c: sub             SP, SP, #0x30
    // 0x86ef10: SetupParameters(AnimationController this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, {_Double value = 0.000000 /* d2 */})
    //     0x86ef10: mov             x0, x2
    //     0x86ef14: stur            x2, [fp, #-0x10]
    //     0x86ef18: mov             x2, x1
    //     0x86ef1c: stur            x1, [fp, #-8]
    //     0x86ef20: ldur            w1, [x4, #0x13]
    //     0x86ef24: ldur            w3, [x4, #0x1f]
    //     0x86ef28: add             x3, x3, HEAP, lsl #32
    //     0x86ef2c: ldr             x16, [PP, #0x50c8]  ; [pp+0x50c8] "value"
    //     0x86ef30: cmp             w3, w16
    //     0x86ef34: b.ne            #0x86ef58
    //     0x86ef38: ldur            w3, [x4, #0x23]
    //     0x86ef3c: add             x3, x3, HEAP, lsl #32
    //     0x86ef40: sub             w4, w1, w3
    //     0x86ef44: add             x1, fp, w4, sxtw #2
    //     0x86ef48: ldr             x1, [x1, #8]
    //     0x86ef4c: ldur            d0, [x1, #7]
    //     0x86ef50: mov             v2.16b, v0.16b
    //     0x86ef54: b               #0x86ef5c
    //     0x86ef58: eor             v2.16b, v2.16b, v2.16b
    // 0x86ef5c: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x86ef60: r4 = Instance_AnimationStatus
    //     0x86ef60: ldr             x4, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x86ef64: r3 = Instance_AnimationBehavior
    //     0x86ef64: ldr             x3, [PP, #0x5190]  ; [pp+0x5190] Obj!AnimationBehavior@12c60e1
    // 0x86ef68: r1 = Instance__AnimationDirection
    //     0x86ef68: ldr             x1, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x86ef6c: d1 = -inf
    //     0x86ef6c: ldr             d1, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x86ef70: d0 = inf
    //     0x86ef70: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x86ef74: stur            d2, [fp, #-0x20]
    // 0x86ef78: CheckStackOverflow
    //     0x86ef78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86ef7c: cmp             SP, x16
    //     0x86ef80: b.ls            #0x86f0cc
    // 0x86ef84: StoreField: r2->field_37 = r5
    //     0x86ef84: stur            w5, [x2, #0x37]
    // 0x86ef88: StoreField: r2->field_43 = r5
    //     0x86ef88: stur            w5, [x2, #0x43]
    // 0x86ef8c: StoreField: r2->field_47 = r4
    //     0x86ef8c: stur            w4, [x2, #0x47]
    // 0x86ef90: StoreField: r2->field_23 = r3
    //     0x86ef90: stur            w3, [x2, #0x23]
    // 0x86ef94: StoreField: r2->field_13 = d1
    //     0x86ef94: stur            d1, [x2, #0x13]
    // 0x86ef98: StoreField: r2->field_1b = d0
    //     0x86ef98: stur            d0, [x2, #0x1b]
    // 0x86ef9c: StoreField: r2->field_3f = r1
    //     0x86ef9c: stur            w1, [x2, #0x3f]
    // 0x86efa0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x86efa0: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x86efa4: r0 = ObserverList()
    //     0x86efa4: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x86efa8: mov             x3, x0
    // 0x86efac: r0 = false
    //     0x86efac: add             x0, NULL, #0x30  ; false
    // 0x86efb0: stur            x3, [fp, #-0x18]
    // 0x86efb4: StoreField: r3->field_f = r0
    //     0x86efb4: stur            w0, [x3, #0xf]
    // 0x86efb8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x86efbc: StoreField: r3->field_13 = r0
    //     0x86efbc: stur            w0, [x3, #0x13]
    // 0x86efc0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x86efc0: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x86efc4: r2 = 0
    //     0x86efc4: mov             x2, #0
    // 0x86efc8: r0 = _GrowableList()
    //     0x86efc8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x86efcc: ldur            x1, [fp, #-0x18]
    // 0x86efd0: StoreField: r1->field_b = r0
    //     0x86efd0: stur            w0, [x1, #0xb]
    //     0x86efd4: ldurb           w16, [x1, #-1]
    //     0x86efd8: ldurb           w17, [x0, #-1]
    //     0x86efdc: and             x16, x17, x16, lsr #2
    //     0x86efe0: tst             x16, HEAP, lsr #32
    //     0x86efe4: b.eq            #0x86efec
    //     0x86efe8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86efec: mov             x0, x1
    // 0x86eff0: ldur            x2, [fp, #-8]
    // 0x86eff4: StoreField: r2->field_f = r0
    //     0x86eff4: stur            w0, [x2, #0xf]
    //     0x86eff8: ldurb           w16, [x2, #-1]
    //     0x86effc: ldurb           w17, [x0, #-1]
    //     0x86f000: and             x16, x17, x16, lsr #2
    //     0x86f004: tst             x16, HEAP, lsr #32
    //     0x86f008: b.eq            #0x86f010
    //     0x86f00c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x86f010: r16 = <(dynamic this) => void?, int>
    //     0x86f010: ldr             x16, [PP, #0x5790]  ; [pp+0x5790] TypeArguments: <(dynamic this) => void?, int>
    // 0x86f014: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x86f018: stp             lr, x16, [SP]
    // 0x86f01c: r0 = Map._fromLiteral()
    //     0x86f01c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x86f020: r1 = <(dynamic this) => void?>
    //     0x86f020: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0x86f024: stur            x0, [fp, #-0x18]
    // 0x86f028: r0 = HashedObserverList()
    //     0x86f028: bl              #0x83d31c  ; AllocateHashedObserverListStub -> HashedObserverList<X0> (size=0x10)
    // 0x86f02c: mov             x1, x0
    // 0x86f030: ldur            x0, [fp, #-0x18]
    // 0x86f034: StoreField: r1->field_b = r0
    //     0x86f034: stur            w0, [x1, #0xb]
    // 0x86f038: mov             x0, x1
    // 0x86f03c: ldur            x3, [fp, #-8]
    // 0x86f040: StoreField: r3->field_b = r0
    //     0x86f040: stur            w0, [x3, #0xb]
    //     0x86f044: ldurb           w16, [x3, #-1]
    //     0x86f048: ldurb           w17, [x0, #-1]
    //     0x86f04c: and             x16, x17, x16, lsr #2
    //     0x86f050: tst             x16, HEAP, lsr #32
    //     0x86f054: b.eq            #0x86f05c
    //     0x86f058: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x86f05c: mov             x2, x3
    // 0x86f060: r1 = Function '_tick@62066280':.
    //     0x86f060: ldr             x1, [PP, #0x5798]  ; [pp+0x5798] AnonymousClosure: (0x86f0d4), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick (0x86f110)
    // 0x86f064: r0 = AllocateClosure()
    //     0x86f064: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x86f068: ldur            x1, [fp, #-0x10]
    // 0x86f06c: r2 = LoadClassIdInstr(r1)
    //     0x86f06c: ldur            x2, [x1, #-1]
    //     0x86f070: ubfx            x2, x2, #0xc, #0x14
    // 0x86f074: mov             x16, x0
    // 0x86f078: mov             x0, x2
    // 0x86f07c: mov             x2, x16
    // 0x86f080: r0 = GDT[cid_x0 + 0x14dcd]()
    //     0x86f080: mov             x17, #0x4dcd
    //     0x86f084: movk            x17, #1, lsl #16
    //     0x86f088: add             lr, x0, x17
    //     0x86f08c: ldr             lr, [x21, lr, lsl #3]
    //     0x86f090: blr             lr
    // 0x86f094: ldur            x1, [fp, #-8]
    // 0x86f098: StoreField: r1->field_2f = r0
    //     0x86f098: stur            w0, [x1, #0x2f]
    //     0x86f09c: ldurb           w16, [x1, #-1]
    //     0x86f0a0: ldurb           w17, [x0, #-1]
    //     0x86f0a4: and             x16, x17, x16, lsr #2
    //     0x86f0a8: tst             x16, HEAP, lsr #32
    //     0x86f0ac: b.eq            #0x86f0b4
    //     0x86f0b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86f0b4: ldur            d0, [fp, #-0x20]
    // 0x86f0b8: r0 = _internalSetValue()
    //     0x86f0b8: bl              #0x82ea0c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x86f0bc: r0 = Null
    //     0x86f0bc: mov             x0, NULL
    // 0x86f0c0: LeaveFrame
    //     0x86f0c0: mov             SP, fp
    //     0x86f0c4: ldp             fp, lr, [SP], #0x10
    // 0x86f0c8: ret
    //     0x86f0c8: ret             
    // 0x86f0cc: r0 = StackOverflowSharedWithFPURegs()
    //     0x86f0cc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x86f0d0: b               #0x86ef84
  }
  [closure] void _tick(dynamic, Duration) {
    // ** addr: 0x86f0d4, size: 0x3c
    // 0x86f0d4: EnterFrame
    //     0x86f0d4: stp             fp, lr, [SP, #-0x10]!
    //     0x86f0d8: mov             fp, SP
    // 0x86f0dc: ldr             x0, [fp, #0x18]
    // 0x86f0e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x86f0e0: ldur            w1, [x0, #0x17]
    // 0x86f0e4: DecompressPointer r1
    //     0x86f0e4: add             x1, x1, HEAP, lsl #32
    // 0x86f0e8: CheckStackOverflow
    //     0x86f0e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86f0ec: cmp             SP, x16
    //     0x86f0f0: b.ls            #0x86f108
    // 0x86f0f4: ldr             x2, [fp, #0x10]
    // 0x86f0f8: r0 = _tick()
    //     0x86f0f8: bl              #0x86f110  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick
    // 0x86f0fc: LeaveFrame
    //     0x86f0fc: mov             SP, fp
    //     0x86f100: ldp             fp, lr, [SP], #0x10
    // 0x86f104: ret
    //     0x86f104: ret             
    // 0x86f108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86f108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86f10c: b               #0x86f0f4
  }
  _ _tick(/* No info */) {
    // ** addr: 0x86f110, size: 0x234
    // 0x86f110: EnterFrame
    //     0x86f110: stp             fp, lr, [SP, #-0x10]!
    //     0x86f114: mov             fp, SP
    // 0x86f118: AllocStack(0x20)
    //     0x86f118: sub             SP, SP, #0x20
    // 0x86f11c: SetupParameters(AnimationController this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x86f11c: stur            x1, [fp, #-8]
    //     0x86f120: mov             x16, x2
    //     0x86f124: mov             x2, x1
    //     0x86f128: mov             x1, x16
    // 0x86f12c: CheckStackOverflow
    //     0x86f12c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86f130: cmp             SP, x16
    //     0x86f134: b.ls            #0x86f300
    // 0x86f138: mov             x0, x1
    // 0x86f13c: StoreField: r2->field_3b = r0
    //     0x86f13c: stur            w0, [x2, #0x3b]
    //     0x86f140: ldurb           w16, [x2, #-1]
    //     0x86f144: ldurb           w17, [x0, #-1]
    //     0x86f148: and             x16, x17, x16, lsr #2
    //     0x86f14c: tst             x16, HEAP, lsr #32
    //     0x86f150: b.eq            #0x86f158
    //     0x86f154: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x86f158: LoadField: r3 = r1->field_7
    //     0x86f158: ldur            x3, [x1, #7]
    // 0x86f15c: r0 = BoxInt64Instr(r3)
    //     0x86f15c: sbfiz           x0, x3, #1, #0x1f
    //     0x86f160: cmp             x3, x0, asr #1
    //     0x86f164: b.eq            #0x86f170
    //     0x86f168: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x86f16c: stur            x3, [x0, #7]
    // 0x86f170: stp             x0, NULL, [SP]
    // 0x86f174: r0 = _Double.fromInteger()
    //     0x86f174: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x86f178: LoadField: d0 = r0->field_7
    //     0x86f178: ldur            d0, [x0, #7]
    // 0x86f17c: d1 = 1000000.000000
    //     0x86f17c: ldr             d1, [PP, #0x51e0]  ; [pp+0x51e0] IMM: double(1e+06) from 0x412e848000000000
    // 0x86f180: fdiv            d2, d0, d1
    // 0x86f184: ldur            x3, [fp, #-8]
    // 0x86f188: stur            d2, [fp, #-0x10]
    // 0x86f18c: LoadField: r1 = r3->field_33
    //     0x86f18c: ldur            w1, [x3, #0x33]
    // 0x86f190: DecompressPointer r1
    //     0x86f190: add             x1, x1, HEAP, lsl #32
    // 0x86f194: cmp             w1, NULL
    // 0x86f198: b.eq            #0x86f308
    // 0x86f19c: r2 = inline_Allocate_Double()
    //     0x86f19c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x86f1a0: add             x2, x2, #0x10
    //     0x86f1a4: cmp             x0, x2
    //     0x86f1a8: b.ls            #0x86f30c
    //     0x86f1ac: str             x2, [THR, #0x60]  ; THR::top
    //     0x86f1b0: sub             x2, x2, #0xf
    //     0x86f1b4: mov             x0, #0xe19c
    //     0x86f1b8: movk            x0, #3, lsl #16
    //     0x86f1bc: stur            x0, [x2, #-1]
    // 0x86f1c0: dmb             ishst
    // 0x86f1c4: StoreField: r2->field_7 = d2
    //     0x86f1c4: stur            d2, [x2, #7]
    // 0x86f1c8: r0 = LoadClassIdInstr(r1)
    //     0x86f1c8: ldur            x0, [x1, #-1]
    //     0x86f1cc: ubfx            x0, x0, #0xc, #0x14
    // 0x86f1d0: r0 = GDT[cid_x0 + -0xfca]()
    //     0x86f1d0: sub             lr, x0, #0xfca
    //     0x86f1d4: ldr             lr, [x21, lr, lsl #3]
    //     0x86f1d8: blr             lr
    // 0x86f1dc: ldur            x2, [fp, #-8]
    // 0x86f1e0: LoadField: d0 = r2->field_13
    //     0x86f1e0: ldur            d0, [x2, #0x13]
    // 0x86f1e4: LoadField: d1 = r2->field_1b
    //     0x86f1e4: ldur            d1, [x2, #0x1b]
    // 0x86f1e8: LoadField: d2 = r0->field_7
    //     0x86f1e8: ldur            d2, [x0, #7]
    // 0x86f1ec: fcmp            d0, d2
    // 0x86f1f0: b.gt            #0x86f218
    // 0x86f1f4: fcmp            d2, d1
    // 0x86f1f8: b.le            #0x86f204
    // 0x86f1fc: mov             v0.16b, v1.16b
    // 0x86f200: b               #0x86f218
    // 0x86f204: fcmp            d2, d2
    // 0x86f208: b.vc            #0x86f214
    // 0x86f20c: mov             v0.16b, v1.16b
    // 0x86f210: b               #0x86f218
    // 0x86f214: mov             v0.16b, v2.16b
    // 0x86f218: r0 = inline_Allocate_Double()
    //     0x86f218: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x86f21c: add             x0, x0, #0x10
    //     0x86f220: cmp             x1, x0
    //     0x86f224: b.ls            #0x86f328
    //     0x86f228: str             x0, [THR, #0x60]  ; THR::top
    //     0x86f22c: sub             x0, x0, #0xf
    //     0x86f230: mov             x1, #0xe19c
    //     0x86f234: movk            x1, #3, lsl #16
    //     0x86f238: stur            x1, [x0, #-1]
    // 0x86f23c: dmb             ishst
    // 0x86f240: StoreField: r0->field_7 = d0
    //     0x86f240: stur            d0, [x0, #7]
    // 0x86f244: StoreField: r2->field_37 = r0
    //     0x86f244: stur            w0, [x2, #0x37]
    //     0x86f248: ldurb           w16, [x2, #-1]
    //     0x86f24c: ldurb           w17, [x0, #-1]
    //     0x86f250: and             x16, x17, x16, lsr #2
    //     0x86f254: tst             x16, HEAP, lsr #32
    //     0x86f258: b.eq            #0x86f260
    //     0x86f25c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x86f260: LoadField: r1 = r2->field_33
    //     0x86f260: ldur            w1, [x2, #0x33]
    // 0x86f264: DecompressPointer r1
    //     0x86f264: add             x1, x1, HEAP, lsl #32
    // 0x86f268: cmp             w1, NULL
    // 0x86f26c: b.eq            #0x86f340
    // 0x86f270: r0 = LoadClassIdInstr(r1)
    //     0x86f270: ldur            x0, [x1, #-1]
    //     0x86f274: ubfx            x0, x0, #0xc, #0x14
    // 0x86f278: ldur            d0, [fp, #-0x10]
    // 0x86f27c: r0 = GDT[cid_x0 + -0xe46]()
    //     0x86f27c: sub             lr, x0, #0xe46
    //     0x86f280: ldr             lr, [x21, lr, lsl #3]
    //     0x86f284: blr             lr
    // 0x86f288: tbnz            w0, #4, #0x86f2e0
    // 0x86f28c: ldur            x2, [fp, #-8]
    // 0x86f290: LoadField: r0 = r2->field_3f
    //     0x86f290: ldur            w0, [x2, #0x3f]
    // 0x86f294: DecompressPointer r0
    //     0x86f294: add             x0, x0, HEAP, lsl #32
    // 0x86f298: r16 = Instance__AnimationDirection
    //     0x86f298: ldr             x16, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x86f29c: cmp             w0, w16
    // 0x86f2a0: b.ne            #0x86f2ac
    // 0x86f2a4: r0 = Instance_AnimationStatus
    //     0x86f2a4: ldr             x0, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x86f2a8: b               #0x86f2b0
    // 0x86f2ac: r0 = Instance_AnimationStatus
    //     0x86f2ac: ldr             x0, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x86f2b0: StoreField: r2->field_43 = r0
    //     0x86f2b0: stur            w0, [x2, #0x43]
    //     0x86f2b4: ldurb           w16, [x2, #-1]
    //     0x86f2b8: ldurb           w17, [x0, #-1]
    //     0x86f2bc: and             x16, x17, x16, lsr #2
    //     0x86f2c0: tst             x16, HEAP, lsr #32
    //     0x86f2c4: b.eq            #0x86f2cc
    //     0x86f2c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x86f2cc: r16 = false
    //     0x86f2cc: add             x16, NULL, #0x30  ; false
    // 0x86f2d0: str             x16, [SP]
    // 0x86f2d4: mov             x1, x2
    // 0x86f2d8: r4 = const [0, 0x2, 0x1, 0x1, canceled, 0x1, null]
    //     0x86f2d8: ldr             x4, [PP, #0x5570]  ; [pp+0x5570] List(7) [0, 0x2, 0x1, 0x1, "canceled", 0x1, Null]
    // 0x86f2dc: r0 = stop()
    //     0x86f2dc: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x86f2e0: ldur            x1, [fp, #-8]
    // 0x86f2e4: r0 = notifyListeners()
    //     0x86f2e4: bl              #0x82e55c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x86f2e8: ldur            x1, [fp, #-8]
    // 0x86f2ec: r0 = _checkStatusChanged()
    //     0x86f2ec: bl              #0x82970c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x86f2f0: r0 = Null
    //     0x86f2f0: mov             x0, NULL
    // 0x86f2f4: LeaveFrame
    //     0x86f2f4: mov             SP, fp
    //     0x86f2f8: ldp             fp, lr, [SP], #0x10
    // 0x86f2fc: ret
    //     0x86f2fc: ret             
    // 0x86f300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86f300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86f304: b               #0x86f138
    // 0x86f308: r0 = NullCastErrorSharedWithFPURegs()
    //     0x86f308: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x86f30c: SaveReg d2
    //     0x86f30c: str             q2, [SP, #-0x10]!
    // 0x86f310: stp             x1, x3, [SP, #-0x10]!
    // 0x86f314: r0 = AllocateDouble()
    //     0x86f314: bl              #0x13df878  ; AllocateDoubleStub
    // 0x86f318: mov             x2, x0
    // 0x86f31c: ldp             x1, x3, [SP], #0x10
    // 0x86f320: RestoreReg d2
    //     0x86f320: ldr             q2, [SP], #0x10
    // 0x86f324: b               #0x86f1c4
    // 0x86f328: SaveReg d0
    //     0x86f328: str             q0, [SP, #-0x10]!
    // 0x86f32c: SaveReg r2
    //     0x86f32c: str             x2, [SP, #-8]!
    // 0x86f330: r0 = AllocateDouble()
    //     0x86f330: bl              #0x13df878  ; AllocateDoubleStub
    // 0x86f334: RestoreReg r2
    //     0x86f334: ldr             x2, [SP], #8
    // 0x86f338: RestoreReg d0
    //     0x86f338: ldr             q0, [SP], #0x10
    // 0x86f33c: b               #0x86f240
    // 0x86f340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86f340: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  double velocity(AnimationController) {
    // ** addr: 0x86f930, size: 0x10c
    // 0x86f930: EnterFrame
    //     0x86f930: stp             fp, lr, [SP, #-0x10]!
    //     0x86f934: mov             fp, SP
    // 0x86f938: AllocStack(0x18)
    //     0x86f938: sub             SP, SP, #0x18
    // 0x86f93c: CheckStackOverflow
    //     0x86f93c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86f940: cmp             SP, x16
    //     0x86f944: b.ls            #0x86fa18
    // 0x86f948: LoadField: r0 = r1->field_2f
    //     0x86f948: ldur            w0, [x1, #0x2f]
    // 0x86f94c: DecompressPointer r0
    //     0x86f94c: add             x0, x0, HEAP, lsl #32
    // 0x86f950: cmp             w0, NULL
    // 0x86f954: b.eq            #0x86fa08
    // 0x86f958: LoadField: r2 = r0->field_7
    //     0x86f958: ldur            w2, [x0, #7]
    // 0x86f95c: DecompressPointer r2
    //     0x86f95c: add             x2, x2, HEAP, lsl #32
    // 0x86f960: cmp             w2, NULL
    // 0x86f964: b.eq            #0x86fa08
    // 0x86f968: LoadField: r2 = r1->field_33
    //     0x86f968: ldur            w2, [x1, #0x33]
    // 0x86f96c: DecompressPointer r2
    //     0x86f96c: add             x2, x2, HEAP, lsl #32
    // 0x86f970: stur            x2, [fp, #-8]
    // 0x86f974: cmp             w2, NULL
    // 0x86f978: b.eq            #0x86fa20
    // 0x86f97c: LoadField: r0 = r1->field_3b
    //     0x86f97c: ldur            w0, [x1, #0x3b]
    // 0x86f980: DecompressPointer r0
    //     0x86f980: add             x0, x0, HEAP, lsl #32
    // 0x86f984: cmp             w0, NULL
    // 0x86f988: b.eq            #0x86fa24
    // 0x86f98c: LoadField: r3 = r0->field_7
    //     0x86f98c: ldur            x3, [x0, #7]
    // 0x86f990: r0 = BoxInt64Instr(r3)
    //     0x86f990: sbfiz           x0, x3, #1, #0x1f
    //     0x86f994: cmp             x3, x0, asr #1
    //     0x86f998: b.eq            #0x86f9a4
    //     0x86f99c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x86f9a0: stur            x3, [x0, #7]
    // 0x86f9a4: stp             x0, NULL, [SP]
    // 0x86f9a8: r0 = _Double.fromInteger()
    //     0x86f9a8: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x86f9ac: LoadField: d0 = r0->field_7
    //     0x86f9ac: ldur            d0, [x0, #7]
    // 0x86f9b0: d1 = 1000000.000000
    //     0x86f9b0: ldr             d1, [PP, #0x51e0]  ; [pp+0x51e0] IMM: double(1e+06) from 0x412e848000000000
    // 0x86f9b4: fdiv            d2, d0, d1
    // 0x86f9b8: r2 = inline_Allocate_Double()
    //     0x86f9b8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x86f9bc: add             x2, x2, #0x10
    //     0x86f9c0: cmp             x0, x2
    //     0x86f9c4: b.ls            #0x86fa28
    //     0x86f9c8: str             x2, [THR, #0x60]  ; THR::top
    //     0x86f9cc: sub             x2, x2, #0xf
    //     0x86f9d0: mov             x0, #0xe19c
    //     0x86f9d4: movk            x0, #3, lsl #16
    //     0x86f9d8: stur            x0, [x2, #-1]
    // 0x86f9dc: dmb             ishst
    // 0x86f9e0: StoreField: r2->field_7 = d2
    //     0x86f9e0: stur            d2, [x2, #7]
    // 0x86f9e4: ldur            x1, [fp, #-8]
    // 0x86f9e8: r0 = LoadClassIdInstr(r1)
    //     0x86f9e8: ldur            x0, [x1, #-1]
    //     0x86f9ec: ubfx            x0, x0, #0xc, #0x14
    // 0x86f9f0: r0 = GDT[cid_x0 + -0xe69]()
    //     0x86f9f0: sub             lr, x0, #0xe69
    //     0x86f9f4: ldr             lr, [x21, lr, lsl #3]
    //     0x86f9f8: blr             lr
    // 0x86f9fc: LeaveFrame
    //     0x86f9fc: mov             SP, fp
    //     0x86fa00: ldp             fp, lr, [SP], #0x10
    // 0x86fa04: ret
    //     0x86fa04: ret             
    // 0x86fa08: d0 = 0.000000
    //     0x86fa08: eor             v0.16b, v0.16b, v0.16b
    // 0x86fa0c: LeaveFrame
    //     0x86fa0c: mov             SP, fp
    //     0x86fa10: ldp             fp, lr, [SP], #0x10
    // 0x86fa14: ret
    //     0x86fa14: ret             
    // 0x86fa18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86fa18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86fa1c: b               #0x86f948
    // 0x86fa20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86fa20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86fa24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86fa24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86fa28: SaveReg d2
    //     0x86fa28: str             q2, [SP, #-0x10]!
    // 0x86fa2c: r0 = AllocateDouble()
    //     0x86fa2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x86fa30: mov             x2, x0
    // 0x86fa34: RestoreReg d2
    //     0x86fa34: ldr             q2, [SP], #0x10
    // 0x86fa38: b               #0x86f9e0
  }
  _ AnimationController(/* No info */) {
    // ** addr: 0x874ea4, size: 0x388
    // 0x874ea4: EnterFrame
    //     0x874ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x874ea8: mov             fp, SP
    // 0x874eac: AllocStack(0x30)
    //     0x874eac: sub             SP, SP, #0x30
    // 0x874eb0: SetupParameters(AnimationController this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic animationBehavior = Instance_AnimationBehavior /* r5 */, dynamic duration = Null /* r6 */, dynamic reverseDuration = Null /* r7 */, _Double upperBound = 1.000000 /* d0 */, dynamic value = Null /* r8 */})
    //     0x874eb0: mov             x3, x1
    //     0x874eb4: stur            x1, [fp, #-0x10]
    //     0x874eb8: stur            x2, [fp, #-0x18]
    //     0x874ebc: ldur            w0, [x4, #0x13]
    //     0x874ec0: ldur            w1, [x4, #0x1f]
    //     0x874ec4: add             x1, x1, HEAP, lsl #32
    //     0x874ec8: ldr             x16, [PP, #0x5b28]  ; [pp+0x5b28] "animationBehavior"
    //     0x874ecc: cmp             w1, w16
    //     0x874ed0: b.ne            #0x874ef4
    //     0x874ed4: ldur            w1, [x4, #0x23]
    //     0x874ed8: add             x1, x1, HEAP, lsl #32
    //     0x874edc: sub             w5, w0, w1
    //     0x874ee0: add             x1, fp, w5, sxtw #2
    //     0x874ee4: ldr             x1, [x1, #8]
    //     0x874ee8: mov             x5, x1
    //     0x874eec: mov             x1, #1
    //     0x874ef0: b               #0x874efc
    //     0x874ef4: ldr             x5, [PP, #0x5180]  ; [pp+0x5180] Obj!AnimationBehavior@12c6101
    //     0x874ef8: mov             x1, #0
    //     0x874efc: lsl             x6, x1, #1
    //     0x874f00: lsl             w7, w6, #1
    //     0x874f04: add             w8, w7, #8
    //     0x874f08: add             x16, x4, w8, sxtw #1
    //     0x874f0c: ldur            w9, [x16, #0xf]
    //     0x874f10: add             x9, x9, HEAP, lsl #32
    //     0x874f14: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0x874f18: cmp             w9, w16
    //     0x874f1c: b.ne            #0x874f50
    //     0x874f20: add             w1, w7, #0xa
    //     0x874f24: add             x16, x4, w1, sxtw #1
    //     0x874f28: ldur            w7, [x16, #0xf]
    //     0x874f2c: add             x7, x7, HEAP, lsl #32
    //     0x874f30: sub             w1, w0, w7
    //     0x874f34: add             x7, fp, w1, sxtw #2
    //     0x874f38: ldr             x7, [x7, #8]
    //     0x874f3c: add             w1, w6, #2
    //     0x874f40: sbfx            x6, x1, #1, #0x1f
    //     0x874f44: mov             x1, x6
    //     0x874f48: mov             x6, x7
    //     0x874f4c: b               #0x874f54
    //     0x874f50: mov             x6, NULL
    //     0x874f54: lsl             x7, x1, #1
    //     0x874f58: lsl             w8, w7, #1
    //     0x874f5c: add             w9, w8, #8
    //     0x874f60: add             x16, x4, w9, sxtw #1
    //     0x874f64: ldur            w10, [x16, #0xf]
    //     0x874f68: add             x10, x10, HEAP, lsl #32
    //     0x874f6c: ldr             x16, [PP, #0x5b30]  ; [pp+0x5b30] "reverseDuration"
    //     0x874f70: cmp             w10, w16
    //     0x874f74: b.ne            #0x874fa8
    //     0x874f78: add             w1, w8, #0xa
    //     0x874f7c: add             x16, x4, w1, sxtw #1
    //     0x874f80: ldur            w8, [x16, #0xf]
    //     0x874f84: add             x8, x8, HEAP, lsl #32
    //     0x874f88: sub             w1, w0, w8
    //     0x874f8c: add             x8, fp, w1, sxtw #2
    //     0x874f90: ldr             x8, [x8, #8]
    //     0x874f94: add             w1, w7, #2
    //     0x874f98: sbfx            x7, x1, #1, #0x1f
    //     0x874f9c: mov             x1, x7
    //     0x874fa0: mov             x7, x8
    //     0x874fa4: b               #0x874fac
    //     0x874fa8: mov             x7, NULL
    //     0x874fac: lsl             x8, x1, #1
    //     0x874fb0: lsl             w9, w8, #1
    //     0x874fb4: add             w10, w9, #8
    //     0x874fb8: add             x16, x4, w10, sxtw #1
    //     0x874fbc: ldur            w11, [x16, #0xf]
    //     0x874fc0: add             x11, x11, HEAP, lsl #32
    //     0x874fc4: ldr             x16, [PP, #0x5b38]  ; [pp+0x5b38] "upperBound"
    //     0x874fc8: cmp             w11, w16
    //     0x874fcc: b.ne            #0x875000
    //     0x874fd0: add             w1, w9, #0xa
    //     0x874fd4: add             x16, x4, w1, sxtw #1
    //     0x874fd8: ldur            w9, [x16, #0xf]
    //     0x874fdc: add             x9, x9, HEAP, lsl #32
    //     0x874fe0: sub             w1, w0, w9
    //     0x874fe4: add             x9, fp, w1, sxtw #2
    //     0x874fe8: ldr             x9, [x9, #8]
    //     0x874fec: add             w1, w8, #2
    //     0x874ff0: ldur            d0, [x9, #7]
    //     0x874ff4: sbfx            x8, x1, #1, #0x1f
    //     0x874ff8: mov             x1, x8
    //     0x874ffc: b               #0x875004
    //     0x875000: fmov            d0, #1.00000000
    //     0x875004: lsl             x8, x1, #1
    //     0x875008: lsl             w1, w8, #1
    //     0x87500c: add             w8, w1, #8
    //     0x875010: add             x16, x4, w8, sxtw #1
    //     0x875014: ldur            w9, [x16, #0xf]
    //     0x875018: add             x9, x9, HEAP, lsl #32
    //     0x87501c: ldr             x16, [PP, #0x50c8]  ; [pp+0x50c8] "value"
    //     0x875020: cmp             w9, w16
    //     0x875024: b.ne            #0x87504c
    //     0x875028: add             w8, w1, #0xa
    //     0x87502c: add             x16, x4, w8, sxtw #1
    //     0x875030: ldur            w1, [x16, #0xf]
    //     0x875034: add             x1, x1, HEAP, lsl #32
    //     0x875038: sub             w4, w0, w1
    //     0x87503c: add             x0, fp, w4, sxtw #2
    //     0x875040: ldr             x0, [x0, #8]
    //     0x875044: mov             x8, x0
    //     0x875048: b               #0x875050
    //     0x87504c: mov             x8, NULL
    // 0x875050: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x875054: r0 = Instance_AnimationStatus
    //     0x875054: ldr             x0, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x875058: r1 = Instance__AnimationDirection
    //     0x875058: ldr             x1, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x87505c: stur            x8, [fp, #-8]
    // 0x875060: CheckStackOverflow
    //     0x875060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875064: cmp             SP, x16
    //     0x875068: b.ls            #0x875224
    // 0x87506c: StoreField: r3->field_37 = r4
    //     0x87506c: stur            w4, [x3, #0x37]
    // 0x875070: StoreField: r3->field_43 = r4
    //     0x875070: stur            w4, [x3, #0x43]
    // 0x875074: StoreField: r3->field_47 = r0
    //     0x875074: stur            w0, [x3, #0x47]
    // 0x875078: mov             x0, x6
    // 0x87507c: StoreField: r3->field_27 = r0
    //     0x87507c: stur            w0, [x3, #0x27]
    //     0x875080: ldurb           w16, [x3, #-1]
    //     0x875084: ldurb           w17, [x0, #-1]
    //     0x875088: and             x16, x17, x16, lsr #2
    //     0x87508c: tst             x16, HEAP, lsr #32
    //     0x875090: b.eq            #0x875098
    //     0x875094: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x875098: mov             x0, x7
    // 0x87509c: StoreField: r3->field_2b = r0
    //     0x87509c: stur            w0, [x3, #0x2b]
    //     0x8750a0: ldurb           w16, [x3, #-1]
    //     0x8750a4: ldurb           w17, [x0, #-1]
    //     0x8750a8: and             x16, x17, x16, lsr #2
    //     0x8750ac: tst             x16, HEAP, lsr #32
    //     0x8750b0: b.eq            #0x8750b8
    //     0x8750b4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8750b8: StoreField: r3->field_13 = rZR
    //     0x8750b8: stur            xzr, [x3, #0x13]
    // 0x8750bc: StoreField: r3->field_1b = d0
    //     0x8750bc: stur            d0, [x3, #0x1b]
    // 0x8750c0: mov             x0, x5
    // 0x8750c4: StoreField: r3->field_23 = r0
    //     0x8750c4: stur            w0, [x3, #0x23]
    //     0x8750c8: ldurb           w16, [x3, #-1]
    //     0x8750cc: ldurb           w17, [x0, #-1]
    //     0x8750d0: and             x16, x17, x16, lsr #2
    //     0x8750d4: tst             x16, HEAP, lsr #32
    //     0x8750d8: b.eq            #0x8750e0
    //     0x8750dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8750e0: StoreField: r3->field_3f = r1
    //     0x8750e0: stur            w1, [x3, #0x3f]
    // 0x8750e4: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x8750e4: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x8750e8: r0 = ObserverList()
    //     0x8750e8: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x8750ec: mov             x3, x0
    // 0x8750f0: r0 = false
    //     0x8750f0: add             x0, NULL, #0x30  ; false
    // 0x8750f4: stur            x3, [fp, #-0x20]
    // 0x8750f8: StoreField: r3->field_f = r0
    //     0x8750f8: stur            w0, [x3, #0xf]
    // 0x8750fc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x875100: StoreField: r3->field_13 = r0
    //     0x875100: stur            w0, [x3, #0x13]
    // 0x875104: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x875104: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x875108: r2 = 0
    //     0x875108: mov             x2, #0
    // 0x87510c: r0 = _GrowableList()
    //     0x87510c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x875110: ldur            x1, [fp, #-0x20]
    // 0x875114: StoreField: r1->field_b = r0
    //     0x875114: stur            w0, [x1, #0xb]
    //     0x875118: ldurb           w16, [x1, #-1]
    //     0x87511c: ldurb           w17, [x0, #-1]
    //     0x875120: and             x16, x17, x16, lsr #2
    //     0x875124: tst             x16, HEAP, lsr #32
    //     0x875128: b.eq            #0x875130
    //     0x87512c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x875130: mov             x0, x1
    // 0x875134: ldur            x2, [fp, #-0x10]
    // 0x875138: StoreField: r2->field_f = r0
    //     0x875138: stur            w0, [x2, #0xf]
    //     0x87513c: ldurb           w16, [x2, #-1]
    //     0x875140: ldurb           w17, [x0, #-1]
    //     0x875144: and             x16, x17, x16, lsr #2
    //     0x875148: tst             x16, HEAP, lsr #32
    //     0x87514c: b.eq            #0x875154
    //     0x875150: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x875154: r16 = <(dynamic this) => void?, int>
    //     0x875154: ldr             x16, [PP, #0x5790]  ; [pp+0x5790] TypeArguments: <(dynamic this) => void?, int>
    // 0x875158: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x87515c: stp             lr, x16, [SP]
    // 0x875160: r0 = Map._fromLiteral()
    //     0x875160: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x875164: r1 = <(dynamic this) => void?>
    //     0x875164: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0x875168: stur            x0, [fp, #-0x20]
    // 0x87516c: r0 = HashedObserverList()
    //     0x87516c: bl              #0x83d31c  ; AllocateHashedObserverListStub -> HashedObserverList<X0> (size=0x10)
    // 0x875170: mov             x1, x0
    // 0x875174: ldur            x0, [fp, #-0x20]
    // 0x875178: StoreField: r1->field_b = r0
    //     0x875178: stur            w0, [x1, #0xb]
    // 0x87517c: mov             x0, x1
    // 0x875180: ldur            x3, [fp, #-0x10]
    // 0x875184: StoreField: r3->field_b = r0
    //     0x875184: stur            w0, [x3, #0xb]
    //     0x875188: ldurb           w16, [x3, #-1]
    //     0x87518c: ldurb           w17, [x0, #-1]
    //     0x875190: and             x16, x17, x16, lsr #2
    //     0x875194: tst             x16, HEAP, lsr #32
    //     0x875198: b.eq            #0x8751a0
    //     0x87519c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8751a0: mov             x2, x3
    // 0x8751a4: r1 = Function '_tick@62066280':.
    //     0x8751a4: ldr             x1, [PP, #0x5798]  ; [pp+0x5798] AnonymousClosure: (0x86f0d4), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick (0x86f110)
    // 0x8751a8: r0 = AllocateClosure()
    //     0x8751a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8751ac: ldur            x1, [fp, #-0x18]
    // 0x8751b0: r2 = LoadClassIdInstr(r1)
    //     0x8751b0: ldur            x2, [x1, #-1]
    //     0x8751b4: ubfx            x2, x2, #0xc, #0x14
    // 0x8751b8: mov             x16, x0
    // 0x8751bc: mov             x0, x2
    // 0x8751c0: mov             x2, x16
    // 0x8751c4: r0 = GDT[cid_x0 + 0x14dcd]()
    //     0x8751c4: mov             x17, #0x4dcd
    //     0x8751c8: movk            x17, #1, lsl #16
    //     0x8751cc: add             lr, x0, x17
    //     0x8751d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8751d4: blr             lr
    // 0x8751d8: ldur            x1, [fp, #-0x10]
    // 0x8751dc: StoreField: r1->field_2f = r0
    //     0x8751dc: stur            w0, [x1, #0x2f]
    //     0x8751e0: ldurb           w16, [x1, #-1]
    //     0x8751e4: ldurb           w17, [x0, #-1]
    //     0x8751e8: and             x16, x17, x16, lsr #2
    //     0x8751ec: tst             x16, HEAP, lsr #32
    //     0x8751f0: b.eq            #0x8751f8
    //     0x8751f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8751f8: ldur            x0, [fp, #-8]
    // 0x8751fc: cmp             w0, NULL
    // 0x875200: b.ne            #0x87520c
    // 0x875204: d0 = 0.000000
    //     0x875204: eor             v0.16b, v0.16b, v0.16b
    // 0x875208: b               #0x875210
    // 0x87520c: LoadField: d0 = r0->field_7
    //     0x87520c: ldur            d0, [x0, #7]
    // 0x875210: r0 = _internalSetValue()
    //     0x875210: bl              #0x82ea0c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x875214: r0 = Null
    //     0x875214: mov             x0, NULL
    // 0x875218: LeaveFrame
    //     0x875218: mov             SP, fp
    //     0x87521c: ldp             fp, lr, [SP], #0x10
    // 0x875220: ret
    //     0x875220: ret             
    // 0x875224: r0 = StackOverflowSharedWithFPURegs()
    //     0x875224: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x875228: b               #0x87506c
  }
  _ reverse(/* No info */) {
    // ** addr: 0x8c8688, size: 0x94
    // 0x8c8688: EnterFrame
    //     0x8c8688: stp             fp, lr, [SP, #-0x10]!
    //     0x8c868c: mov             fp, SP
    // 0x8c8690: AllocStack(0x8)
    //     0x8c8690: sub             SP, SP, #8
    // 0x8c8694: SetupParameters(AnimationController this /* r1 => r0, fp-0x8 */, {dynamic from = Null /* r2 */})
    //     0x8c8694: mov             x0, x1
    //     0x8c8698: stur            x1, [fp, #-8]
    //     0x8c869c: ldur            w1, [x4, #0x13]
    //     0x8c86a0: ldur            w2, [x4, #0x1f]
    //     0x8c86a4: add             x2, x2, HEAP, lsl #32
    //     0x8c86a8: ldr             x16, [PP, #0x6360]  ; [pp+0x6360] "from"
    //     0x8c86ac: cmp             w2, w16
    //     0x8c86b0: b.ne            #0x8c86d0
    //     0x8c86b4: ldur            w2, [x4, #0x23]
    //     0x8c86b8: add             x2, x2, HEAP, lsl #32
    //     0x8c86bc: sub             w3, w1, w2
    //     0x8c86c0: add             x1, fp, w3, sxtw #2
    //     0x8c86c4: ldr             x1, [x1, #8]
    //     0x8c86c8: mov             x2, x1
    //     0x8c86cc: b               #0x8c86d4
    //     0x8c86d0: mov             x2, NULL
    //     0x8c86d4: ldr             x1, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0x8c86d4: r1 = Instance__AnimationDirection
    // 0x8c86d8: CheckStackOverflow
    //     0x8c86d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c86dc: cmp             SP, x16
    //     0x8c86e0: b.ls            #0x8c8714
    // 0x8c86e4: StoreField: r0->field_3f = r1
    //     0x8c86e4: stur            w1, [x0, #0x3f]
    // 0x8c86e8: cmp             w2, NULL
    // 0x8c86ec: b.eq            #0x8c86f8
    // 0x8c86f0: mov             x1, x0
    // 0x8c86f4: r0 = value=()
    //     0x8c86f4: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x8c86f8: ldur            x1, [fp, #-8]
    // 0x8c86fc: LoadField: d0 = r1->field_13
    //     0x8c86fc: ldur            d0, [x1, #0x13]
    // 0x8c8700: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c8700: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c8704: r0 = _animateToInternal()
    //     0x8c8704: bl              #0x866150  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x8c8708: LeaveFrame
    //     0x8c8708: mov             SP, fp
    //     0x8c870c: ldp             fp, lr, [SP], #0x10
    // 0x8c8710: ret
    //     0x8c8710: ret             
    // 0x8c8714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c8714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c8718: b               #0x8c86e4
  }
  [closure] TickerFuture reverse(dynamic, {double? from}) {
    // ** addr: 0x8c871c, size: 0x84
    // 0x8c871c: EnterFrame
    //     0x8c871c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c8720: mov             fp, SP
    // 0x8c8724: AllocStack(0x8)
    //     0x8c8724: sub             SP, SP, #8
    // 0x8c8728: SetupParameters(AnimationController this /* r2 */, {dynamic from = Null /* r0 */})
    //     0x8c8728: ldur            w0, [x4, #0x13]
    //     0x8c872c: sub             x1, x0, #2
    //     0x8c8730: add             x2, fp, w1, sxtw #2
    //     0x8c8734: ldr             x2, [x2, #0x10]
    //     0x8c8738: ldur            w1, [x4, #0x1f]
    //     0x8c873c: add             x1, x1, HEAP, lsl #32
    //     0x8c8740: ldr             x16, [PP, #0x6360]  ; [pp+0x6360] "from"
    //     0x8c8744: cmp             w1, w16
    //     0x8c8748: b.ne            #0x8c8764
    //     0x8c874c: ldur            w1, [x4, #0x23]
    //     0x8c8750: add             x1, x1, HEAP, lsl #32
    //     0x8c8754: sub             w3, w0, w1
    //     0x8c8758: add             x0, fp, w3, sxtw #2
    //     0x8c875c: ldr             x0, [x0, #8]
    //     0x8c8760: b               #0x8c8768
    //     0x8c8764: mov             x0, NULL
    //     0x8c8768: ldur            w1, [x2, #0x17]
    //     0x8c876c: add             x1, x1, HEAP, lsl #32
    // 0x8c8770: CheckStackOverflow
    //     0x8c8770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8774: cmp             SP, x16
    //     0x8c8778: b.ls            #0x8c8798
    // 0x8c877c: str             x0, [SP]
    // 0x8c8780: r4 = const [0, 0x2, 0x1, 0x1, from, 0x1, null]
    //     0x8c8780: add             x4, PP, #0x27, lsl #12  ; [pp+0x27420] List(7) [0, 0x2, 0x1, 0x1, "from", 0x1, Null]
    //     0x8c8784: ldr             x4, [x4, #0x420]
    // 0x8c8788: r0 = reverse()
    //     0x8c8788: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x8c878c: LeaveFrame
    //     0x8c878c: mov             SP, fp
    //     0x8c8790: ldp             fp, lr, [SP], #0x10
    // 0x8c8794: ret
    //     0x8c8794: ret             
    // 0x8c8798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c8798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c879c: b               #0x8c877c
  }
  _ forward(/* No info */) {
    // ** addr: 0x8cd83c, size: 0x94
    // 0x8cd83c: EnterFrame
    //     0x8cd83c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd840: mov             fp, SP
    // 0x8cd844: AllocStack(0x8)
    //     0x8cd844: sub             SP, SP, #8
    // 0x8cd848: SetupParameters(AnimationController this /* r1 => r0, fp-0x8 */, {dynamic from = Null /* r2 */})
    //     0x8cd848: mov             x0, x1
    //     0x8cd84c: stur            x1, [fp, #-8]
    //     0x8cd850: ldur            w1, [x4, #0x13]
    //     0x8cd854: ldur            w2, [x4, #0x1f]
    //     0x8cd858: add             x2, x2, HEAP, lsl #32
    //     0x8cd85c: ldr             x16, [PP, #0x6360]  ; [pp+0x6360] "from"
    //     0x8cd860: cmp             w2, w16
    //     0x8cd864: b.ne            #0x8cd884
    //     0x8cd868: ldur            w2, [x4, #0x23]
    //     0x8cd86c: add             x2, x2, HEAP, lsl #32
    //     0x8cd870: sub             w3, w1, w2
    //     0x8cd874: add             x1, fp, w3, sxtw #2
    //     0x8cd878: ldr             x1, [x1, #8]
    //     0x8cd87c: mov             x2, x1
    //     0x8cd880: b               #0x8cd888
    //     0x8cd884: mov             x2, NULL
    //     0x8cd888: ldr             x1, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0x8cd888: r1 = Instance__AnimationDirection
    // 0x8cd88c: CheckStackOverflow
    //     0x8cd88c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd890: cmp             SP, x16
    //     0x8cd894: b.ls            #0x8cd8c8
    // 0x8cd898: StoreField: r0->field_3f = r1
    //     0x8cd898: stur            w1, [x0, #0x3f]
    // 0x8cd89c: cmp             w2, NULL
    // 0x8cd8a0: b.eq            #0x8cd8ac
    // 0x8cd8a4: mov             x1, x0
    // 0x8cd8a8: r0 = value=()
    //     0x8cd8a8: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x8cd8ac: ldur            x1, [fp, #-8]
    // 0x8cd8b0: LoadField: d0 = r1->field_1b
    //     0x8cd8b0: ldur            d0, [x1, #0x1b]
    // 0x8cd8b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8cd8b4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8cd8b8: r0 = _animateToInternal()
    //     0x8cd8b8: bl              #0x866150  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x8cd8bc: LeaveFrame
    //     0x8cd8bc: mov             SP, fp
    //     0x8cd8c0: ldp             fp, lr, [SP], #0x10
    // 0x8cd8c4: ret
    //     0x8cd8c4: ret             
    // 0x8cd8c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd8c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd8cc: b               #0x8cd898
  }
  [closure] void reset(dynamic) {
    // ** addr: 0x915970, size: 0x38
    // 0x915970: EnterFrame
    //     0x915970: stp             fp, lr, [SP, #-0x10]!
    //     0x915974: mov             fp, SP
    // 0x915978: ldr             x0, [fp, #0x10]
    // 0x91597c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91597c: ldur            w1, [x0, #0x17]
    // 0x915980: DecompressPointer r1
    //     0x915980: add             x1, x1, HEAP, lsl #32
    // 0x915984: CheckStackOverflow
    //     0x915984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x915988: cmp             SP, x16
    //     0x91598c: b.ls            #0x9159a0
    // 0x915990: r0 = reset()
    //     0x915990: bl              #0x9159a8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reset
    // 0x915994: LeaveFrame
    //     0x915994: mov             SP, fp
    //     0x915998: ldp             fp, lr, [SP], #0x10
    // 0x91599c: ret
    //     0x91599c: ret             
    // 0x9159a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9159a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9159a4: b               #0x915990
  }
  _ reset(/* No info */) {
    // ** addr: 0x9159a8, size: 0x7c
    // 0x9159a8: EnterFrame
    //     0x9159a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9159ac: mov             fp, SP
    // 0x9159b0: CheckStackOverflow
    //     0x9159b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9159b4: cmp             SP, x16
    //     0x9159b8: b.ls            #0x915a00
    // 0x9159bc: LoadField: d0 = r1->field_13
    //     0x9159bc: ldur            d0, [x1, #0x13]
    // 0x9159c0: r2 = inline_Allocate_Double()
    //     0x9159c0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x9159c4: add             x2, x2, #0x10
    //     0x9159c8: cmp             x0, x2
    //     0x9159cc: b.ls            #0x915a08
    //     0x9159d0: str             x2, [THR, #0x60]  ; THR::top
    //     0x9159d4: sub             x2, x2, #0xf
    //     0x9159d8: mov             x0, #0xe19c
    //     0x9159dc: movk            x0, #3, lsl #16
    //     0x9159e0: stur            x0, [x2, #-1]
    // 0x9159e4: dmb             ishst
    // 0x9159e8: StoreField: r2->field_7 = d0
    //     0x9159e8: stur            d0, [x2, #7]
    // 0x9159ec: r0 = value=()
    //     0x9159ec: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x9159f0: r0 = Null
    //     0x9159f0: mov             x0, NULL
    // 0x9159f4: LeaveFrame
    //     0x9159f4: mov             SP, fp
    //     0x9159f8: ldp             fp, lr, [SP], #0x10
    // 0x9159fc: ret
    //     0x9159fc: ret             
    // 0x915a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x915a00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x915a04: b               #0x9159bc
    // 0x915a08: SaveReg d0
    //     0x915a08: str             q0, [SP, #-0x10]!
    // 0x915a0c: SaveReg r1
    //     0x915a0c: str             x1, [SP, #-8]!
    // 0x915a10: r0 = AllocateDouble()
    //     0x915a10: bl              #0x13df878  ; AllocateDoubleStub
    // 0x915a14: mov             x2, x0
    // 0x915a18: RestoreReg r1
    //     0x915a18: ldr             x1, [SP], #8
    // 0x915a1c: RestoreReg d0
    //     0x915a1c: ldr             q0, [SP], #0x10
    // 0x915a20: b               #0x9159e8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9164f4, size: 0xdc
    // 0x9164f4: EnterFrame
    //     0x9164f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9164f8: mov             fp, SP
    // 0x9164fc: AllocStack(0x18)
    //     0x9164fc: sub             SP, SP, #0x18
    // 0x916500: SetupParameters(AnimationController this /* r1 => r0, fp-0x18 */)
    //     0x916500: mov             x0, x1
    //     0x916504: stur            x1, [fp, #-0x18]
    // 0x916508: CheckStackOverflow
    //     0x916508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91650c: cmp             SP, x16
    //     0x916510: b.ls            #0x9165c4
    // 0x916514: LoadField: r2 = r0->field_2f
    //     0x916514: ldur            w2, [x0, #0x2f]
    // 0x916518: DecompressPointer r2
    //     0x916518: add             x2, x2, HEAP, lsl #32
    // 0x91651c: stur            x2, [fp, #-0x10]
    // 0x916520: cmp             w2, NULL
    // 0x916524: b.eq            #0x9165cc
    // 0x916528: r1 = LoadClassIdInstr(r2)
    //     0x916528: ldur            x1, [x2, #-1]
    //     0x91652c: ubfx            x1, x1, #0xc, #0x14
    // 0x916530: cmp             x1, #0xb0f
    // 0x916534: b.ne            #0x916568
    // 0x916538: LoadField: r3 = r2->field_7
    //     0x916538: ldur            w3, [x2, #7]
    // 0x91653c: DecompressPointer r3
    //     0x91653c: add             x3, x3, HEAP, lsl #32
    // 0x916540: stur            x3, [fp, #-8]
    // 0x916544: cmp             w3, NULL
    // 0x916548: b.eq            #0x91659c
    // 0x91654c: StoreField: r2->field_7 = rNULL
    //     0x91654c: stur            NULL, [x2, #7]
    // 0x916550: mov             x1, x2
    // 0x916554: r0 = unscheduleTick()
    //     0x916554: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x916558: ldur            x1, [fp, #-8]
    // 0x91655c: ldur            x2, [fp, #-0x10]
    // 0x916560: r0 = _cancel()
    //     0x916560: bl              #0x82ece8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_cancel
    // 0x916564: b               #0x91659c
    // 0x916568: mov             x3, x2
    // 0x91656c: LoadField: r1 = r3->field_1f
    //     0x91656c: ldur            w1, [x3, #0x1f]
    // 0x916570: DecompressPointer r1
    //     0x916570: add             x1, x1, HEAP, lsl #32
    // 0x916574: r0 = LoadClassIdInstr(r1)
    //     0x916574: ldur            x0, [x1, #-1]
    //     0x916578: ubfx            x0, x0, #0xc, #0x14
    // 0x91657c: mov             x2, x3
    // 0x916580: r0 = GDT[cid_x0 + 0x15885]()
    //     0x916580: mov             x17, #0x5885
    //     0x916584: movk            x17, #1, lsl #16
    //     0x916588: add             lr, x0, x17
    //     0x91658c: ldr             lr, [x21, lr, lsl #3]
    //     0x916590: blr             lr
    // 0x916594: ldur            x1, [fp, #-0x10]
    // 0x916598: r0 = dispose()
    //     0x916598: bl              #0x13084f4  ; [package:flutter/src/scheduler/ticker.dart] Ticker::dispose
    // 0x91659c: ldur            x0, [fp, #-0x18]
    // 0x9165a0: StoreField: r0->field_2f = rNULL
    //     0x9165a0: stur            NULL, [x0, #0x2f]
    // 0x9165a4: mov             x1, x0
    // 0x9165a8: r0 = clearStatusListeners()
    //     0x9165a8: bl              #0x916668  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::clearStatusListeners
    // 0x9165ac: ldur            x1, [fp, #-0x18]
    // 0x9165b0: r0 = clearListeners()
    //     0x9165b0: bl              #0x9165f0  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::clearListeners
    // 0x9165b4: r0 = Null
    //     0x9165b4: mov             x0, NULL
    // 0x9165b8: LeaveFrame
    //     0x9165b8: mov             SP, fp
    //     0x9165bc: ldp             fp, lr, [SP], #0x10
    // 0x9165c0: ret
    //     0x9165c0: ret             
    // 0x9165c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9165c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9165c8: b               #0x916514
    // 0x9165cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9165cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  double value(AnimationController) {
    // ** addr: 0xae65fc, size: 0x28
    // 0xae65fc: LoadField: r0 = r1->field_37
    //     0xae65fc: ldur            w0, [x1, #0x37]
    // 0xae6600: DecompressPointer r0
    //     0xae6600: add             x0, x0, HEAP, lsl #32
    // 0xae6604: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xae6608: cmp             w0, w16
    // 0xae660c: b.eq            #0xae6614
    // 0xae6610: ret
    //     0xae6610: ret             
    // 0xae6614: EnterFrame
    //     0xae6614: stp             fp, lr, [SP, #-0x10]!
    //     0xae6618: mov             fp, SP
    // 0xae661c: r9 = _value
    //     0xae661c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xae6620: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xae6620: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ isAnimating(/* No info */) {
    // ** addr: 0xb293bc, size: 0x38
    // 0xb293bc: LoadField: r2 = r1->field_2f
    //     0xb293bc: ldur            w2, [x1, #0x2f]
    // 0xb293c0: DecompressPointer r2
    //     0xb293c0: add             x2, x2, HEAP, lsl #32
    // 0xb293c4: cmp             w2, NULL
    // 0xb293c8: b.eq            #0xb293ec
    // 0xb293cc: LoadField: r1 = r2->field_7
    //     0xb293cc: ldur            w1, [x2, #7]
    // 0xb293d0: DecompressPointer r1
    //     0xb293d0: add             x1, x1, HEAP, lsl #32
    // 0xb293d4: cmp             w1, NULL
    // 0xb293d8: r16 = true
    //     0xb293d8: add             x16, NULL, #0x20  ; true
    // 0xb293dc: r17 = false
    //     0xb293dc: add             x17, NULL, #0x30  ; false
    // 0xb293e0: csel            x2, x16, x17, ne
    // 0xb293e4: mov             x0, x2
    // 0xb293e8: b               #0xb293f0
    // 0xb293ec: r0 = false
    //     0xb293ec: add             x0, NULL, #0x30  ; false
    // 0xb293f0: ret
    //     0xb293f0: ret             
  }
  _ fling(/* No info */) {
    // ** addr: 0xb34edc, size: 0x24c
    // 0xb34edc: EnterFrame
    //     0xb34edc: stp             fp, lr, [SP, #-0x10]!
    //     0xb34ee0: mov             fp, SP
    // 0xb34ee4: AllocStack(0x28)
    //     0xb34ee4: sub             SP, SP, #0x28
    // 0xb34ee8: SetupParameters(AnimationController this /* r1 => r1, fp-0x8 */, {dynamic springDescription, _Double velocity = 1.000000 /* d0, fp-0x18 */})
    //     0xb34ee8: stur            x1, [fp, #-8]
    //     0xb34eec: ldur            w0, [x4, #0x13]
    //     0xb34ef0: ldur            w2, [x4, #0x1f]
    //     0xb34ef4: add             x2, x2, HEAP, lsl #32
    //     0xb34ef8: add             x16, PP, #0x83, lsl #12  ; [pp+0x837e0] "springDescription"
    //     0xb34efc: ldr             x16, [x16, #0x7e0]
    //     0xb34f00: cmp             w2, w16
    //     0xb34f04: b.ne            #0xb34f10
    //     0xb34f08: mov             x2, #1
    //     0xb34f0c: b               #0xb34f14
    //     0xb34f10: mov             x2, #0
    //     0xb34f14: lsl             x3, x2, #1
    //     0xb34f18: lsl             w2, w3, #1
    //     0xb34f1c: add             w3, w2, #8
    //     0xb34f20: add             x16, x4, w3, sxtw #1
    //     0xb34f24: ldur            w5, [x16, #0xf]
    //     0xb34f28: add             x5, x5, HEAP, lsl #32
    //     0xb34f2c: add             x16, PP, #0x83, lsl #12  ; [pp+0x837e8] "velocity"
    //     0xb34f30: ldr             x16, [x16, #0x7e8]
    //     0xb34f34: cmp             w5, w16
    //     0xb34f38: b.ne            #0xb34f60
    //     0xb34f3c: add             w3, w2, #0xa
    //     0xb34f40: add             x16, x4, w3, sxtw #1
    //     0xb34f44: ldur            w2, [x16, #0xf]
    //     0xb34f48: add             x2, x2, HEAP, lsl #32
    //     0xb34f4c: sub             w3, w0, w2
    //     0xb34f50: add             x0, fp, w3, sxtw #2
    //     0xb34f54: ldr             x0, [x0, #8]
    //     0xb34f58: ldur            d0, [x0, #7]
    //     0xb34f5c: b               #0xb34f64
    //     0xb34f60: fmov            d0, #1.00000000
    //     0xb34f64: stur            d0, [fp, #-0x18]
    // 0xb34f68: CheckStackOverflow
    //     0xb34f68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34f6c: cmp             SP, x16
    //     0xb34f70: b.ls            #0xb3510c
    // 0xb34f74: r0 = LoadStaticField(0x644)
    //     0xb34f74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb34f78: ldr             x0, [x0, #0xc88]
    // 0xb34f7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb34f80: cmp             w0, w16
    // 0xb34f84: b.ne            #0xb34f94
    // 0xb34f88: r2 = _kFlingSpringDescription
    //     0xb34f88: add             x2, PP, #0x83, lsl #12  ; [pp+0x837f0] Field <::._kFlingSpringDescription@62066280>: static late final (offset: 0x644)
    //     0xb34f8c: ldr             x2, [x2, #0x7f0]
    // 0xb34f90: r0 = InitLateFinalStaticField()
    //     0xb34f90: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xb34f94: mov             x1, x0
    // 0xb34f98: ldur            d1, [fp, #-0x18]
    // 0xb34f9c: d0 = 0.000000
    //     0xb34f9c: eor             v0.16b, v0.16b, v0.16b
    // 0xb34fa0: stur            x1, [fp, #-0x10]
    // 0xb34fa4: fcmp            d0, d1
    // 0xb34fa8: b.le            #0xb34fb4
    // 0xb34fac: r0 = Instance__AnimationDirection
    //     0xb34fac: ldr             x0, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0xb34fb0: b               #0xb34fb8
    // 0xb34fb4: r0 = Instance__AnimationDirection
    //     0xb34fb4: ldr             x0, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0xb34fb8: ldur            x2, [fp, #-8]
    // 0xb34fbc: StoreField: r2->field_3f = r0
    //     0xb34fbc: stur            w0, [x2, #0x3f]
    //     0xb34fc0: ldurb           w16, [x2, #-1]
    //     0xb34fc4: ldurb           w17, [x0, #-1]
    //     0xb34fc8: and             x16, x17, x16, lsr #2
    //     0xb34fcc: tst             x16, HEAP, lsr #32
    //     0xb34fd0: b.eq            #0xb34fd8
    //     0xb34fd4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb34fd8: fcmp            d0, d1
    // 0xb34fdc: b.le            #0xb34ffc
    // 0xb34fe0: r0 = Instance_Tolerance
    //     0xb34fe0: add             x0, PP, #0x83, lsl #12  ; [pp+0x837f8] Obj!Tolerance@129c5e1
    //     0xb34fe4: ldr             x0, [x0, #0x7f8]
    // 0xb34fe8: LoadField: d0 = r2->field_13
    //     0xb34fe8: ldur            d0, [x2, #0x13]
    // 0xb34fec: LoadField: d2 = r0->field_7
    //     0xb34fec: ldur            d2, [x0, #7]
    // 0xb34ff0: fsub            d3, d0, d2
    // 0xb34ff4: mov             v0.16b, v3.16b
    // 0xb34ff8: b               #0xb35014
    // 0xb34ffc: r0 = Instance_Tolerance
    //     0xb34ffc: add             x0, PP, #0x83, lsl #12  ; [pp+0x837f8] Obj!Tolerance@129c5e1
    //     0xb35000: ldr             x0, [x0, #0x7f8]
    // 0xb35004: LoadField: d0 = r2->field_1b
    //     0xb35004: ldur            d0, [x2, #0x1b]
    // 0xb35008: LoadField: d2 = r0->field_7
    //     0xb35008: ldur            d2, [x0, #7]
    // 0xb3500c: fadd            d3, d0, d2
    // 0xb35010: mov             v0.16b, v3.16b
    // 0xb35014: stur            d0, [fp, #-0x28]
    // 0xb35018: LoadField: r3 = r2->field_23
    //     0xb35018: ldur            w3, [x2, #0x23]
    // 0xb3501c: DecompressPointer r3
    //     0xb3501c: add             x3, x3, HEAP, lsl #32
    // 0xb35020: r16 = Instance_AnimationBehavior
    //     0xb35020: ldr             x16, [PP, #0x5180]  ; [pp+0x5180] Obj!AnimationBehavior@12c6101
    // 0xb35024: cmp             w3, w16
    // 0xb35028: r16 = true
    //     0xb35028: add             x16, NULL, #0x20  ; true
    // 0xb3502c: r17 = false
    //     0xb3502c: add             x17, NULL, #0x30  ; false
    // 0xb35030: csel            x4, x16, x17, eq
    // 0xb35034: tbnz            w4, #4, #0xb35070
    // 0xb35038: r5 = LoadStaticField(0x7d4)
    //     0xb35038: ldr             x5, [THR, #0x78]  ; THR::field_table_values
    //     0xb3503c: ldr             x5, [x5, #0xfa8]
    // 0xb35040: cmp             w5, NULL
    // 0xb35044: b.eq            #0xb35114
    // 0xb35048: LoadField: r6 = r5->field_c7
    //     0xb35048: ldur            w6, [x5, #0xc7]
    // 0xb3504c: DecompressPointer r6
    //     0xb3504c: add             x6, x6, HEAP, lsl #32
    // 0xb35050: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb35054: cmp             w6, w16
    // 0xb35058: b.eq            #0xb35118
    // 0xb3505c: LoadField: r5 = r6->field_7
    //     0xb3505c: ldur            x5, [x6, #7]
    // 0xb35060: tbz             w5, #2, #0xb35070
    // 0xb35064: r3 = 200.000000
    //     0xb35064: add             x3, PP, #0x28, lsl #12  ; [pp+0x288e8] 200
    //     0xb35068: ldr             x3, [x3, #0x8e8]
    // 0xb3506c: b               #0xb3508c
    // 0xb35070: tbz             w4, #4, #0xb35080
    // 0xb35074: r16 = Instance_AnimationBehavior
    //     0xb35074: ldr             x16, [PP, #0x5190]  ; [pp+0x5190] Obj!AnimationBehavior@12c60e1
    // 0xb35078: cmp             w3, w16
    // 0xb3507c: b.ne            #0xb35088
    // 0xb35080: r3 = 1.000000
    //     0xb35080: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xb35084: b               #0xb3508c
    // 0xb35088: r3 = Null
    //     0xb35088: mov             x3, NULL
    // 0xb3508c: LoadField: r4 = r2->field_37
    //     0xb3508c: ldur            w4, [x2, #0x37]
    // 0xb35090: DecompressPointer r4
    //     0xb35090: add             x4, x4, HEAP, lsl #32
    // 0xb35094: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb35098: cmp             w4, w16
    // 0xb3509c: b.eq            #0xb35120
    // 0xb350a0: LoadField: d2 = r3->field_7
    //     0xb350a0: ldur            d2, [x3, #7]
    // 0xb350a4: fmul            d3, d1, d2
    // 0xb350a8: stur            d3, [fp, #-0x20]
    // 0xb350ac: LoadField: d1 = r4->field_7
    //     0xb350ac: ldur            d1, [x4, #7]
    // 0xb350b0: stur            d1, [fp, #-0x18]
    // 0xb350b4: r0 = SpringSimulation()
    //     0xb350b4: bl              #0xb35bf8  ; AllocateSpringSimulationStub -> SpringSimulation (size=0x1c)
    // 0xb350b8: mov             x1, x0
    // 0xb350bc: ldur            x2, [fp, #-0x10]
    // 0xb350c0: ldur            d0, [fp, #-0x18]
    // 0xb350c4: ldur            d1, [fp, #-0x28]
    // 0xb350c8: ldur            d2, [fp, #-0x20]
    // 0xb350cc: stur            x0, [fp, #-0x10]
    // 0xb350d0: r4 = const [0, 0x5, 0, 0x5, null]
    //     0xb350d0: ldr             x4, [PP, #0x1390]  ; [pp+0x1390] List(5) [0, 0x5, 0, 0x5, Null]
    // 0xb350d4: r0 = SpringSimulation()
    //     0xb350d4: bl              #0xb35128  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::SpringSimulation
    // 0xb350d8: ldur            x2, [fp, #-0x10]
    // 0xb350dc: r0 = Instance_Tolerance
    //     0xb350dc: add             x0, PP, #0x83, lsl #12  ; [pp+0x837f8] Obj!Tolerance@129c5e1
    //     0xb350e0: ldr             x0, [x0, #0x7f8]
    // 0xb350e4: StoreField: r2->field_7 = r0
    //     0xb350e4: stur            w0, [x2, #7]
    // 0xb350e8: ldur            x1, [fp, #-8]
    // 0xb350ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb350ec: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb350f0: r0 = stop()
    //     0xb350f0: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xb350f4: ldur            x1, [fp, #-8]
    // 0xb350f8: ldur            x2, [fp, #-0x10]
    // 0xb350fc: r0 = _startSimulation()
    //     0xb350fc: bl              #0x866618  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0xb35100: LeaveFrame
    //     0xb35100: mov             SP, fp
    //     0xb35104: ldp             fp, lr, [SP], #0x10
    // 0xb35108: ret
    //     0xb35108: ret             
    // 0xb3510c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb3510c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb35110: b               #0xb34f74
    // 0xb35114: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb35114: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb35118: r9 = _accessibilityFeatures
    //     0xb35118: ldr             x9, [PP, #0x5228]  ; [pp+0x5228] Field <_MixinApplication206&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding@18353248._accessibilityFeatures@154275577>: late (offset: 0xc8)
    // 0xb3511c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb3511c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb35120: r9 = _value
    //     0xb35120: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb35124: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb35124: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ animateBackWith(/* No info */) {
    // ** addr: 0xbaa720, size: 0x58
    // 0xbaa720: EnterFrame
    //     0xbaa720: stp             fp, lr, [SP, #-0x10]!
    //     0xbaa724: mov             fp, SP
    // 0xbaa728: AllocStack(0x10)
    //     0xbaa728: sub             SP, SP, #0x10
    // 0xbaa72c: SetupParameters(AnimationController this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbaa72c: mov             x0, x1
    //     0xbaa730: stur            x1, [fp, #-8]
    //     0xbaa734: stur            x2, [fp, #-0x10]
    // 0xbaa738: CheckStackOverflow
    //     0xbaa738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbaa73c: cmp             SP, x16
    //     0xbaa740: b.ls            #0xbaa770
    // 0xbaa744: mov             x1, x0
    // 0xbaa748: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbaa748: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbaa74c: r0 = stop()
    //     0xbaa74c: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xbaa750: ldur            x1, [fp, #-8]
    // 0xbaa754: r0 = Instance__AnimationDirection
    //     0xbaa754: ldr             x0, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0xbaa758: StoreField: r1->field_3f = r0
    //     0xbaa758: stur            w0, [x1, #0x3f]
    // 0xbaa75c: ldur            x2, [fp, #-0x10]
    // 0xbaa760: r0 = _startSimulation()
    //     0xbaa760: bl              #0x866618  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0xbaa764: LeaveFrame
    //     0xbaa764: mov             SP, fp
    //     0xbaa768: ldp             fp, lr, [SP], #0x10
    // 0xbaa76c: ret
    //     0xbaa76c: ret             
    // 0xbaa770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaa770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaa774: b               #0xbaa744
  }
  _ resync(/* No info */) {
    // ** addr: 0xcf5008, size: 0xa0
    // 0xcf5008: EnterFrame
    //     0xcf5008: stp             fp, lr, [SP, #-0x10]!
    //     0xcf500c: mov             fp, SP
    // 0xcf5010: AllocStack(0x18)
    //     0xcf5010: sub             SP, SP, #0x18
    // 0xcf5014: SetupParameters(AnimationController this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf5014: mov             x3, x1
    //     0xcf5018: mov             x0, x2
    //     0xcf501c: stur            x1, [fp, #-0x10]
    //     0xcf5020: stur            x2, [fp, #-0x18]
    // 0xcf5024: CheckStackOverflow
    //     0xcf5024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5028: cmp             SP, x16
    //     0xcf502c: b.ls            #0xcf509c
    // 0xcf5030: LoadField: r4 = r3->field_2f
    //     0xcf5030: ldur            w4, [x3, #0x2f]
    // 0xcf5034: DecompressPointer r4
    //     0xcf5034: add             x4, x4, HEAP, lsl #32
    // 0xcf5038: stur            x4, [fp, #-8]
    // 0xcf503c: cmp             w4, NULL
    // 0xcf5040: b.eq            #0xcf50a4
    // 0xcf5044: mov             x2, x3
    // 0xcf5048: r1 = Function '_tick@62066280':.
    //     0xcf5048: ldr             x1, [PP, #0x5798]  ; [pp+0x5798] AnonymousClosure: (0x86f0d4), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick (0x86f110)
    // 0xcf504c: r0 = AllocateClosure()
    //     0xcf504c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf5050: ldur            x1, [fp, #-0x18]
    // 0xcf5054: mov             x2, x0
    // 0xcf5058: r0 = createTicker()
    //     0xcf5058: bl              #0xad2bd4  ; [dart:mixin_deduplication] _MixinApplication188&State&SingleTickerProviderStateMixin::createTicker
    // 0xcf505c: mov             x2, x0
    // 0xcf5060: ldur            x1, [fp, #-0x10]
    // 0xcf5064: StoreField: r1->field_2f = r0
    //     0xcf5064: stur            w0, [x1, #0x2f]
    //     0xcf5068: ldurb           w16, [x1, #-1]
    //     0xcf506c: ldurb           w17, [x0, #-1]
    //     0xcf5070: and             x16, x17, x16, lsr #2
    //     0xcf5074: tst             x16, HEAP, lsr #32
    //     0xcf5078: b.eq            #0xcf5080
    //     0xcf507c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5080: mov             x1, x2
    // 0xcf5084: ldur            x2, [fp, #-8]
    // 0xcf5088: r0 = absorbTicker()
    //     0xcf5088: bl              #0xcf50a8  ; [package:flutter/src/scheduler/ticker.dart] Ticker::absorbTicker
    // 0xcf508c: r0 = Null
    //     0xcf508c: mov             x0, NULL
    // 0xcf5090: LeaveFrame
    //     0xcf5090: mov             SP, fp
    //     0xcf5094: ldp             fp, lr, [SP], #0x10
    // 0xcf5098: ret
    //     0xcf5098: ret             
    // 0xcf509c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf509c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf50a0: b               #0xcf5030
    // 0xcf50a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf50a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ repeat(/* No info */) {
    // ** addr: 0xf3bd88, size: 0x1bc
    // 0xf3bd88: EnterFrame
    //     0xf3bd88: stp             fp, lr, [SP, #-0x10]!
    //     0xf3bd8c: mov             fp, SP
    // 0xf3bd90: AllocStack(0x38)
    //     0xf3bd90: sub             SP, SP, #0x38
    // 0xf3bd94: SetupParameters(AnimationController this /* r1 => r0, fp-0x18 */, {dynamic max, dynamic min, dynamic period, dynamic reverse = false /* r2, fp-0x10 */})
    //     0xf3bd94: mov             x0, x1
    //     0xf3bd98: stur            x1, [fp, #-0x18]
    //     0xf3bd9c: ldur            w1, [x4, #0x13]
    //     0xf3bda0: ldur            w2, [x4, #0x1f]
    //     0xf3bda4: add             x2, x2, HEAP, lsl #32
    //     0xf3bda8: add             x16, PP, #0x16, lsl #12  ; [pp+0x169a8] "max"
    //     0xf3bdac: ldr             x16, [x16, #0x9a8]
    //     0xf3bdb0: cmp             w2, w16
    //     0xf3bdb4: b.ne            #0xf3bdc0
    //     0xf3bdb8: mov             x2, #1
    //     0xf3bdbc: b               #0xf3bdc4
    //     0xf3bdc0: mov             x2, #0
    //     0xf3bdc4: lsl             x3, x2, #1
    //     0xf3bdc8: lsl             w5, w3, #1
    //     0xf3bdcc: add             w6, w5, #8
    //     0xf3bdd0: add             x16, x4, w6, sxtw #1
    //     0xf3bdd4: ldur            w5, [x16, #0xf]
    //     0xf3bdd8: add             x5, x5, HEAP, lsl #32
    //     0xf3bddc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84910] "min"
    //     0xf3bde0: ldr             x16, [x16, #0x910]
    //     0xf3bde4: cmp             w5, w16
    //     0xf3bde8: b.ne            #0xf3bdf8
    //     0xf3bdec: add             w2, w3, #2
    //     0xf3bdf0: sbfx            x3, x2, #1, #0x1f
    //     0xf3bdf4: mov             x2, x3
    //     0xf3bdf8: lsl             x3, x2, #1
    //     0xf3bdfc: lsl             w5, w3, #1
    //     0xf3be00: add             w6, w5, #8
    //     0xf3be04: add             x16, x4, w6, sxtw #1
    //     0xf3be08: ldur            w5, [x16, #0xf]
    //     0xf3be0c: add             x5, x5, HEAP, lsl #32
    //     0xf3be10: add             x16, PP, #0x22, lsl #12  ; [pp+0x22c30] "period"
    //     0xf3be14: ldr             x16, [x16, #0xc30]
    //     0xf3be18: cmp             w5, w16
    //     0xf3be1c: b.ne            #0xf3be2c
    //     0xf3be20: add             w2, w3, #2
    //     0xf3be24: sbfx            x3, x2, #1, #0x1f
    //     0xf3be28: mov             x2, x3
    //     0xf3be2c: lsl             x3, x2, #1
    //     0xf3be30: lsl             w2, w3, #1
    //     0xf3be34: add             w3, w2, #8
    //     0xf3be38: add             x16, x4, w3, sxtw #1
    //     0xf3be3c: ldur            w5, [x16, #0xf]
    //     0xf3be40: add             x5, x5, HEAP, lsl #32
    //     0xf3be44: add             x16, PP, #0x15, lsl #12  ; [pp+0x15be0] "reverse"
    //     0xf3be48: ldr             x16, [x16, #0xbe0]
    //     0xf3be4c: cmp             w5, w16
    //     0xf3be50: b.ne            #0xf3be78
    //     0xf3be54: add             w3, w2, #0xa
    //     0xf3be58: add             x16, x4, w3, sxtw #1
    //     0xf3be5c: ldur            w2, [x16, #0xf]
    //     0xf3be60: add             x2, x2, HEAP, lsl #32
    //     0xf3be64: sub             w3, w1, w2
    //     0xf3be68: add             x1, fp, w3, sxtw #2
    //     0xf3be6c: ldr             x1, [x1, #8]
    //     0xf3be70: mov             x2, x1
    //     0xf3be74: b               #0xf3be7c
    //     0xf3be78: add             x2, NULL, #0x30  ; false
    //     0xf3be7c: stur            x2, [fp, #-0x10]
    // 0xf3be80: CheckStackOverflow
    //     0xf3be80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3be84: cmp             SP, x16
    //     0xf3be88: b.ls            #0xf3bf30
    // 0xf3be8c: LoadField: d1 = r0->field_13
    //     0xf3be8c: ldur            d1, [x0, #0x13]
    // 0xf3be90: stur            d1, [fp, #-0x30]
    // 0xf3be94: LoadField: d2 = r0->field_1b
    //     0xf3be94: ldur            d2, [x0, #0x1b]
    // 0xf3be98: stur            d2, [fp, #-0x28]
    // 0xf3be9c: LoadField: r3 = r0->field_27
    //     0xf3be9c: ldur            w3, [x0, #0x27]
    // 0xf3bea0: DecompressPointer r3
    //     0xf3bea0: add             x3, x3, HEAP, lsl #32
    // 0xf3bea4: mov             x1, x0
    // 0xf3bea8: stur            x3, [fp, #-8]
    // 0xf3beac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3beac: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3beb0: r0 = stop()
    //     0xf3beb0: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xf3beb4: ldur            x2, [fp, #-0x18]
    // 0xf3beb8: LoadField: r0 = r2->field_37
    //     0xf3beb8: ldur            w0, [x2, #0x37]
    // 0xf3bebc: DecompressPointer r0
    //     0xf3bebc: add             x0, x0, HEAP, lsl #32
    // 0xf3bec0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3bec4: cmp             w0, w16
    // 0xf3bec8: b.eq            #0xf3bf38
    // 0xf3becc: ldur            x3, [fp, #-8]
    // 0xf3bed0: cmp             w3, NULL
    // 0xf3bed4: b.eq            #0xf3bf40
    // 0xf3bed8: LoadField: d0 = r0->field_7
    //     0xf3bed8: ldur            d0, [x0, #7]
    // 0xf3bedc: stur            d0, [fp, #-0x38]
    // 0xf3bee0: r0 = _RepeatingSimulation()
    //     0xf3bee0: bl              #0xf3c05c  ; Allocate_RepeatingSimulationStub -> _RepeatingSimulation (size=0x38)
    // 0xf3bee4: ldur            x2, [fp, #-0x18]
    // 0xf3bee8: r1 = Function '_directionSetter@62066280':.
    //     0xf3bee8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84918] AnonymousClosure: (0xf3c068), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter (0xf3c0a4)
    //     0xf3beec: ldr             x1, [x1, #0x918]
    // 0xf3bef0: stur            x0, [fp, #-0x20]
    // 0xf3bef4: r0 = AllocateClosure()
    //     0xf3bef4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3bef8: ldur            x1, [fp, #-0x20]
    // 0xf3befc: ldur            d0, [fp, #-0x38]
    // 0xf3bf00: ldur            d1, [fp, #-0x30]
    // 0xf3bf04: ldur            d2, [fp, #-0x28]
    // 0xf3bf08: ldur            x2, [fp, #-0x10]
    // 0xf3bf0c: ldur            x3, [fp, #-8]
    // 0xf3bf10: mov             x5, x0
    // 0xf3bf14: r0 = _RepeatingSimulation()
    //     0xf3bf14: bl              #0xf3bf44  ; [package:flutter/src/animation/animation_controller.dart] _RepeatingSimulation::_RepeatingSimulation
    // 0xf3bf18: ldur            x1, [fp, #-0x18]
    // 0xf3bf1c: ldur            x2, [fp, #-0x20]
    // 0xf3bf20: r0 = _startSimulation()
    //     0xf3bf20: bl              #0x866618  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0xf3bf24: LeaveFrame
    //     0xf3bf24: mov             SP, fp
    //     0xf3bf28: ldp             fp, lr, [SP], #0x10
    // 0xf3bf2c: ret
    //     0xf3bf2c: ret             
    // 0xf3bf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3bf30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3bf34: b               #0xf3be8c
    // 0xf3bf38: r9 = _value
    //     0xf3bf38: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xf3bf3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3bf3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3bf40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bf40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _directionSetter(dynamic, _AnimationDirection) {
    // ** addr: 0xf3c068, size: 0x3c
    // 0xf3c068: EnterFrame
    //     0xf3c068: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c06c: mov             fp, SP
    // 0xf3c070: ldr             x0, [fp, #0x18]
    // 0xf3c074: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3c074: ldur            w1, [x0, #0x17]
    // 0xf3c078: DecompressPointer r1
    //     0xf3c078: add             x1, x1, HEAP, lsl #32
    // 0xf3c07c: CheckStackOverflow
    //     0xf3c07c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c080: cmp             SP, x16
    //     0xf3c084: b.ls            #0xf3c09c
    // 0xf3c088: ldr             x2, [fp, #0x10]
    // 0xf3c08c: r0 = _directionSetter()
    //     0xf3c08c: bl              #0xf3c0a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter
    // 0xf3c090: LeaveFrame
    //     0xf3c090: mov             SP, fp
    //     0xf3c094: ldp             fp, lr, [SP], #0x10
    // 0xf3c098: ret
    //     0xf3c098: ret             
    // 0xf3c09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c09c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c0a0: b               #0xf3c088
  }
  _ _directionSetter(/* No info */) {
    // ** addr: 0xf3c0a4, size: 0x94
    // 0xf3c0a4: EnterFrame
    //     0xf3c0a4: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c0a8: mov             fp, SP
    // 0xf3c0ac: mov             x16, x2
    // 0xf3c0b0: mov             x2, x1
    // 0xf3c0b4: mov             x1, x16
    // 0xf3c0b8: CheckStackOverflow
    //     0xf3c0b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c0bc: cmp             SP, x16
    //     0xf3c0c0: b.ls            #0xf3c130
    // 0xf3c0c4: mov             x0, x1
    // 0xf3c0c8: StoreField: r2->field_3f = r0
    //     0xf3c0c8: stur            w0, [x2, #0x3f]
    //     0xf3c0cc: ldurb           w16, [x2, #-1]
    //     0xf3c0d0: ldurb           w17, [x0, #-1]
    //     0xf3c0d4: and             x16, x17, x16, lsr #2
    //     0xf3c0d8: tst             x16, HEAP, lsr #32
    //     0xf3c0dc: b.eq            #0xf3c0e4
    //     0xf3c0e0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3c0e4: r16 = Instance__AnimationDirection
    //     0xf3c0e4: ldr             x16, [PP, #0x5178]  ; [pp+0x5178] Obj!_AnimationDirection@12c6141
    // 0xf3c0e8: cmp             w1, w16
    // 0xf3c0ec: b.ne            #0xf3c0f8
    // 0xf3c0f0: r0 = Instance_AnimationStatus
    //     0xf3c0f0: ldr             x0, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xf3c0f4: b               #0xf3c0fc
    // 0xf3c0f8: r0 = Instance_AnimationStatus
    //     0xf3c0f8: ldr             x0, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xf3c0fc: StoreField: r2->field_43 = r0
    //     0xf3c0fc: stur            w0, [x2, #0x43]
    //     0xf3c100: ldurb           w16, [x2, #-1]
    //     0xf3c104: ldurb           w17, [x0, #-1]
    //     0xf3c108: and             x16, x17, x16, lsr #2
    //     0xf3c10c: tst             x16, HEAP, lsr #32
    //     0xf3c110: b.eq            #0xf3c118
    //     0xf3c114: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3c118: mov             x1, x2
    // 0xf3c11c: r0 = _checkStatusChanged()
    //     0xf3c11c: bl              #0x82970c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0xf3c120: r0 = Null
    //     0xf3c120: mov             x0, NULL
    // 0xf3c124: LeaveFrame
    //     0xf3c124: mov             SP, fp
    //     0xf3c128: ldp             fp, lr, [SP], #0x10
    // 0xf3c12c: ret
    //     0xf3c12c: ret             
    // 0xf3c130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c134: b               #0xf3c0c4
  }
  _ animateBack(/* No info */) {
    // ** addr: 0xf8ee30, size: 0x44
    // 0xf8ee30: EnterFrame
    //     0xf8ee30: stp             fp, lr, [SP, #-0x10]!
    //     0xf8ee34: mov             fp, SP
    // 0xf8ee38: AllocStack(0x10)
    //     0xf8ee38: sub             SP, SP, #0x10
    // 0xf8ee3c: r0 = Instance__AnimationDirection
    //     0xf8ee3c: ldr             x0, [PP, #0x5198]  ; [pp+0x5198] Obj!_AnimationDirection@12c6121
    // 0xf8ee40: CheckStackOverflow
    //     0xf8ee40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8ee44: cmp             SP, x16
    //     0xf8ee48: b.ls            #0xf8ee6c
    // 0xf8ee4c: StoreField: r1->field_3f = r0
    //     0xf8ee4c: stur            w0, [x1, #0x3f]
    // 0xf8ee50: stp             x2, x3, [SP]
    // 0xf8ee54: d0 = 0.000000
    //     0xf8ee54: eor             v0.16b, v0.16b, v0.16b
    // 0xf8ee58: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xf8ee58: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xf8ee5c: r0 = _animateToInternal()
    //     0xf8ee5c: bl              #0x866150  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0xf8ee60: LeaveFrame
    //     0xf8ee60: mov             SP, fp
    //     0xf8ee64: ldp             fp, lr, [SP], #0x10
    // 0xf8ee68: ret
    //     0xf8ee68: ret             
    // 0xf8ee6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8ee6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8ee70: b               #0xf8ee4c
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284ce4, size: 0x28
    // 0x1284ce4: LoadField: r0 = r1->field_43
    //     0x1284ce4: ldur            w0, [x1, #0x43]
    // 0x1284ce8: DecompressPointer r0
    //     0x1284ce8: add             x0, x0, HEAP, lsl #32
    // 0x1284cec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1284cf0: cmp             w0, w16
    // 0x1284cf4: b.eq            #0x1284cfc
    // 0x1284cf8: ret
    //     0x1284cf8: ret             
    // 0x1284cfc: EnterFrame
    //     0x1284cfc: stp             fp, lr, [SP, #-0x10]!
    //     0x1284d00: mov             fp, SP
    // 0x1284d04: r9 = _status
    //     0x1284d04: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0x1284d08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1284d08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 8322, size: 0x14, field offset: 0x14
enum AnimationBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a95a4, size: 0x64
    // 0x11a95a4: EnterFrame
    //     0x11a95a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a95a8: mov             fp, SP
    // 0x11a95ac: AllocStack(0x10)
    //     0x11a95ac: sub             SP, SP, #0x10
    // 0x11a95b0: SetupParameters(AnimationBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11a95b0: mov             x0, x1
    //     0x11a95b4: stur            x1, [fp, #-8]
    // 0x11a95b8: CheckStackOverflow
    //     0x11a95b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a95bc: cmp             SP, x16
    //     0x11a95c0: b.ls            #0x11a9600
    // 0x11a95c4: r1 = Null
    //     0x11a95c4: mov             x1, NULL
    // 0x11a95c8: r2 = 4
    //     0x11a95c8: mov             x2, #4
    // 0x11a95cc: r0 = AllocateArray()
    //     0x11a95cc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a95d0: r16 = "AnimationBehavior."
    //     0x11a95d0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ea8] "AnimationBehavior."
    //     0x11a95d4: ldr             x16, [x16, #0xea8]
    // 0x11a95d8: StoreField: r0->field_f = r16
    //     0x11a95d8: stur            w16, [x0, #0xf]
    // 0x11a95dc: ldur            x1, [fp, #-8]
    // 0x11a95e0: LoadField: r2 = r1->field_f
    //     0x11a95e0: ldur            w2, [x1, #0xf]
    // 0x11a95e4: DecompressPointer r2
    //     0x11a95e4: add             x2, x2, HEAP, lsl #32
    // 0x11a95e8: StoreField: r0->field_13 = r2
    //     0x11a95e8: stur            w2, [x0, #0x13]
    // 0x11a95ec: str             x0, [SP]
    // 0x11a95f0: r0 = _interpolate()
    //     0x11a95f0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a95f4: LeaveFrame
    //     0x11a95f4: mov             SP, fp
    //     0x11a95f8: ldp             fp, lr, [SP], #0x10
    // 0x11a95fc: ret
    //     0x11a95fc: ret             
    // 0x11a9600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9600: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9604: b               #0x11a95c4
  }
}

// class id: 8323, size: 0x14, field offset: 0x14
enum _AnimationDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9540, size: 0x64
    // 0x11a9540: EnterFrame
    //     0x11a9540: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9544: mov             fp, SP
    // 0x11a9548: AllocStack(0x10)
    //     0x11a9548: sub             SP, SP, #0x10
    // 0x11a954c: SetupParameters(_AnimationDirection this /* r1 => r0, fp-0x8 */)
    //     0x11a954c: mov             x0, x1
    //     0x11a9550: stur            x1, [fp, #-8]
    // 0x11a9554: CheckStackOverflow
    //     0x11a9554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9558: cmp             SP, x16
    //     0x11a955c: b.ls            #0x11a959c
    // 0x11a9560: r1 = Null
    //     0x11a9560: mov             x1, NULL
    // 0x11a9564: r2 = 4
    //     0x11a9564: mov             x2, #4
    // 0x11a9568: r0 = AllocateArray()
    //     0x11a9568: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a956c: r16 = "_AnimationDirection."
    //     0x11a956c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10eb0] "_AnimationDirection."
    //     0x11a9570: ldr             x16, [x16, #0xeb0]
    // 0x11a9574: StoreField: r0->field_f = r16
    //     0x11a9574: stur            w16, [x0, #0xf]
    // 0x11a9578: ldur            x1, [fp, #-8]
    // 0x11a957c: LoadField: r2 = r1->field_f
    //     0x11a957c: ldur            w2, [x1, #0xf]
    // 0x11a9580: DecompressPointer r2
    //     0x11a9580: add             x2, x2, HEAP, lsl #32
    // 0x11a9584: StoreField: r0->field_13 = r2
    //     0x11a9584: stur            w2, [x0, #0x13]
    // 0x11a9588: str             x0, [SP]
    // 0x11a958c: r0 = _interpolate()
    //     0x11a958c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9590: LeaveFrame
    //     0x11a9590: mov             SP, fp
    //     0x11a9594: ldp             fp, lr, [SP], #0x10
    // 0x11a9598: ret
    //     0x11a9598: ret             
    // 0x11a959c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a959c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a95a0: b               #0x11a9560
  }
}
