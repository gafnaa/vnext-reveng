// lib: , url: package:flutter/src/animation/listener_helpers.dart

// class id: 1048766, size: 0x8
class :: {
}

// class id: 4170, size: 0x8, field offset: 0x8
abstract class AnimationEagerListenerMixin extends Object {
}

// class id: 4631, size: 0x8, field offset: 0x8
abstract class AnimationLocalStatusListenersMixin extends Object {
}

// class id: 4632, size: 0x8, field offset: 0x8
abstract class AnimationLocalListenersMixin extends Object {
}

// class id: 4633, size: 0x8, field offset: 0x8
abstract class AnimationLazyListenerMixin extends Object {
}
