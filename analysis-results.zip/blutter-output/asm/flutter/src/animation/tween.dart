// lib: , url: package:flutter/src/animation/tween.dart

// class id: 1048767, size: 0x8
class :: {
}

// class id: 3293, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Animatable<X0> extends Object {

  _ animate(/* No info */) {
    // ** addr: 0x915b2c, size: 0x40
    // 0x915b2c: EnterFrame
    //     0x915b2c: stp             fp, lr, [SP, #-0x10]!
    //     0x915b30: mov             fp, SP
    // 0x915b34: AllocStack(0x10)
    //     0x915b34: sub             SP, SP, #0x10
    // 0x915b38: SetupParameters(Animatable<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x915b38: mov             x0, x1
    //     0x915b3c: stur            x1, [fp, #-8]
    //     0x915b40: stur            x2, [fp, #-0x10]
    // 0x915b44: LoadField: r1 = r0->field_7
    //     0x915b44: ldur            w1, [x0, #7]
    // 0x915b48: DecompressPointer r1
    //     0x915b48: add             x1, x1, HEAP, lsl #32
    // 0x915b4c: r0 = _AnimatedEvaluation()
    //     0x915b4c: bl              #0x915b6c  ; Allocate_AnimatedEvaluationStub -> _AnimatedEvaluation<X0> (size=0x14)
    // 0x915b50: ldur            x1, [fp, #-0x10]
    // 0x915b54: StoreField: r0->field_b = r1
    //     0x915b54: stur            w1, [x0, #0xb]
    // 0x915b58: ldur            x1, [fp, #-8]
    // 0x915b5c: StoreField: r0->field_f = r1
    //     0x915b5c: stur            w1, [x0, #0xf]
    // 0x915b60: LeaveFrame
    //     0x915b60: mov             SP, fp
    //     0x915b64: ldp             fp, lr, [SP], #0x10
    // 0x915b68: ret
    //     0x915b68: ret             
  }
  _ chain(/* No info */) {
    // ** addr: 0xb28080, size: 0x40
    // 0xb28080: EnterFrame
    //     0xb28080: stp             fp, lr, [SP, #-0x10]!
    //     0xb28084: mov             fp, SP
    // 0xb28088: AllocStack(0x10)
    //     0xb28088: sub             SP, SP, #0x10
    // 0xb2808c: SetupParameters(Animatable<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2808c: mov             x0, x1
    //     0xb28090: stur            x1, [fp, #-8]
    //     0xb28094: stur            x2, [fp, #-0x10]
    // 0xb28098: LoadField: r1 = r0->field_7
    //     0xb28098: ldur            w1, [x0, #7]
    // 0xb2809c: DecompressPointer r1
    //     0xb2809c: add             x1, x1, HEAP, lsl #32
    // 0xb280a0: r0 = _ChainedEvaluation()
    //     0xb280a0: bl              #0xb280c0  ; Allocate_ChainedEvaluationStub -> _ChainedEvaluation<X0> (size=0x14)
    // 0xb280a4: ldur            x1, [fp, #-0x10]
    // 0xb280a8: StoreField: r0->field_b = r1
    //     0xb280a8: stur            w1, [x0, #0xb]
    // 0xb280ac: ldur            x1, [fp, #-8]
    // 0xb280b0: StoreField: r0->field_f = r1
    //     0xb280b0: stur            w1, [x0, #0xf]
    // 0xb280b4: LeaveFrame
    //     0xb280b4: mov             SP, fp
    //     0xb280b8: ldp             fp, lr, [SP], #0x10
    // 0xb280bc: ret
    //     0xb280bc: ret             
  }
  _ evaluate(/* No info */) {
    // ** addr: 0x112be60, size: 0x78
    // 0x112be60: EnterFrame
    //     0x112be60: stp             fp, lr, [SP, #-0x10]!
    //     0x112be64: mov             fp, SP
    // 0x112be68: AllocStack(0x8)
    //     0x112be68: sub             SP, SP, #8
    // 0x112be6c: SetupParameters(Animatable<X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x112be6c: stur            x1, [fp, #-8]
    //     0x112be70: mov             x16, x2
    //     0x112be74: mov             x2, x1
    //     0x112be78: mov             x1, x16
    // 0x112be7c: CheckStackOverflow
    //     0x112be7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112be80: cmp             SP, x16
    //     0x112be84: b.ls            #0x112bed0
    // 0x112be88: r0 = LoadClassIdInstr(r1)
    //     0x112be88: ldur            x0, [x1, #-1]
    //     0x112be8c: ubfx            x0, x0, #0xc, #0x14
    // 0x112be90: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x112be90: mov             x17, #0x4e2e
    //     0x112be94: movk            x17, #1, lsl #16
    //     0x112be98: add             lr, x0, x17
    //     0x112be9c: ldr             lr, [x21, lr, lsl #3]
    //     0x112bea0: blr             lr
    // 0x112bea4: LoadField: d0 = r0->field_7
    //     0x112bea4: ldur            d0, [x0, #7]
    // 0x112bea8: ldur            x1, [fp, #-8]
    // 0x112beac: r0 = LoadClassIdInstr(r1)
    //     0x112beac: ldur            x0, [x1, #-1]
    //     0x112beb0: ubfx            x0, x0, #0xc, #0x14
    // 0x112beb4: r0 = GDT[cid_x0 + 0xa1d0]()
    //     0x112beb4: mov             x17, #0xa1d0
    //     0x112beb8: add             lr, x0, x17
    //     0x112bebc: ldr             lr, [x21, lr, lsl #3]
    //     0x112bec0: blr             lr
    // 0x112bec4: LeaveFrame
    //     0x112bec4: mov             SP, fp
    //     0x112bec8: ldp             fp, lr, [SP], #0x10
    // 0x112becc: ret
    //     0x112becc: ret             
    // 0x112bed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112bed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112bed4: b               #0x112be88
  }
}

// class id: 3295, size: 0x10, field offset: 0xc
class CurveTween extends Animatable<dynamic> {

  _ transform(/* No info */) {
    // ** addr: 0x1103c04, size: 0xd4
    // 0x1103c04: EnterFrame
    //     0x1103c04: stp             fp, lr, [SP, #-0x10]!
    //     0x1103c08: mov             fp, SP
    // 0x1103c0c: d1 = 0.000000
    //     0x1103c0c: eor             v1.16b, v1.16b, v1.16b
    // 0x1103c10: CheckStackOverflow
    //     0x1103c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103c14: cmp             SP, x16
    //     0x1103c18: b.ls            #0x1103cb0
    // 0x1103c1c: fcmp            d0, d1
    // 0x1103c20: b.eq            #0x1103c30
    // 0x1103c24: d1 = 1.000000
    //     0x1103c24: fmov            d1, #1.00000000
    // 0x1103c28: fcmp            d0, d1
    // 0x1103c2c: b.ne            #0x1103c68
    // 0x1103c30: r0 = inline_Allocate_Double()
    //     0x1103c30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1103c34: add             x0, x0, #0x10
    //     0x1103c38: cmp             x1, x0
    //     0x1103c3c: b.ls            #0x1103cb8
    //     0x1103c40: str             x0, [THR, #0x60]  ; THR::top
    //     0x1103c44: sub             x0, x0, #0xf
    //     0x1103c48: mov             x1, #0xe19c
    //     0x1103c4c: movk            x1, #3, lsl #16
    //     0x1103c50: stur            x1, [x0, #-1]
    // 0x1103c54: dmb             ishst
    // 0x1103c58: StoreField: r0->field_7 = d0
    //     0x1103c58: stur            d0, [x0, #7]
    // 0x1103c5c: LeaveFrame
    //     0x1103c5c: mov             SP, fp
    //     0x1103c60: ldp             fp, lr, [SP], #0x10
    // 0x1103c64: ret
    //     0x1103c64: ret             
    // 0x1103c68: LoadField: r0 = r1->field_b
    //     0x1103c68: ldur            w0, [x1, #0xb]
    // 0x1103c6c: DecompressPointer r0
    //     0x1103c6c: add             x0, x0, HEAP, lsl #32
    // 0x1103c70: mov             x1, x0
    // 0x1103c74: r0 = transform()
    //     0x1103c74: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x1103c78: r0 = inline_Allocate_Double()
    //     0x1103c78: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1103c7c: add             x0, x0, #0x10
    //     0x1103c80: cmp             x1, x0
    //     0x1103c84: b.ls            #0x1103cc8
    //     0x1103c88: str             x0, [THR, #0x60]  ; THR::top
    //     0x1103c8c: sub             x0, x0, #0xf
    //     0x1103c90: mov             x1, #0xe19c
    //     0x1103c94: movk            x1, #3, lsl #16
    //     0x1103c98: stur            x1, [x0, #-1]
    // 0x1103c9c: dmb             ishst
    // 0x1103ca0: StoreField: r0->field_7 = d0
    //     0x1103ca0: stur            d0, [x0, #7]
    // 0x1103ca4: LeaveFrame
    //     0x1103ca4: mov             SP, fp
    //     0x1103ca8: ldp             fp, lr, [SP], #0x10
    // 0x1103cac: ret
    //     0x1103cac: ret             
    // 0x1103cb0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103cb0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103cb4: b               #0x1103c1c
    // 0x1103cb8: SaveReg d0
    //     0x1103cb8: str             q0, [SP, #-0x10]!
    // 0x1103cbc: r0 = AllocateDouble()
    //     0x1103cbc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1103cc0: RestoreReg d0
    //     0x1103cc0: ldr             q0, [SP], #0x10
    // 0x1103cc4: b               #0x1103c58
    // 0x1103cc8: SaveReg d0
    //     0x1103cc8: str             q0, [SP, #-0x10]!
    // 0x1103ccc: r0 = AllocateDouble()
    //     0x1103ccc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1103cd0: RestoreReg d0
    //     0x1103cd0: ldr             q0, [SP], #0x10
    // 0x1103cd4: b               #0x1103ca0
  }
}

// class id: 3296, size: 0x14, field offset: 0xc
class Tween<X0> extends Animatable<X0> {

  _ transform(/* No info */) {
    // ** addr: 0x1103af8, size: 0x10c
    // 0x1103af8: EnterFrame
    //     0x1103af8: stp             fp, lr, [SP, #-0x10]!
    //     0x1103afc: mov             fp, SP
    // 0x1103b00: AllocStack(0x8)
    //     0x1103b00: sub             SP, SP, #8
    // 0x1103b04: d1 = 0.000000
    //     0x1103b04: eor             v1.16b, v1.16b, v1.16b
    // 0x1103b08: CheckStackOverflow
    //     0x1103b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103b0c: cmp             SP, x16
    //     0x1103b10: b.ls            #0x1103bfc
    // 0x1103b14: fcmp            d0, d1
    // 0x1103b18: b.ne            #0x1103b74
    // 0x1103b1c: LoadField: r3 = r1->field_b
    //     0x1103b1c: ldur            w3, [x1, #0xb]
    // 0x1103b20: DecompressPointer r3
    //     0x1103b20: add             x3, x3, HEAP, lsl #32
    // 0x1103b24: stur            x3, [fp, #-8]
    // 0x1103b28: cmp             w3, NULL
    // 0x1103b2c: b.ne            #0x1103b64
    // 0x1103b30: LoadField: r2 = r1->field_7
    //     0x1103b30: ldur            w2, [x1, #7]
    // 0x1103b34: DecompressPointer r2
    //     0x1103b34: add             x2, x2, HEAP, lsl #32
    // 0x1103b38: mov             x0, x3
    // 0x1103b3c: r1 = Null
    //     0x1103b3c: mov             x1, NULL
    // 0x1103b40: cmp             w2, NULL
    // 0x1103b44: b.eq            #0x1103b64
    // 0x1103b48: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1103b48: ldur            w4, [x2, #0x17]
    // 0x1103b4c: DecompressPointer r4
    //     0x1103b4c: add             x4, x4, HEAP, lsl #32
    // 0x1103b50: r8 = X0
    //     0x1103b50: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1103b54: LoadField: r9 = r4->field_7
    //     0x1103b54: ldur            x9, [x4, #7]
    // 0x1103b58: r3 = Null
    //     0x1103b58: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb38] Null
    //     0x1103b5c: ldr             x3, [x3, #0xb38]
    // 0x1103b60: blr             x9
    // 0x1103b64: ldur            x0, [fp, #-8]
    // 0x1103b68: LeaveFrame
    //     0x1103b68: mov             SP, fp
    //     0x1103b6c: ldp             fp, lr, [SP], #0x10
    // 0x1103b70: ret
    //     0x1103b70: ret             
    // 0x1103b74: d1 = 1.000000
    //     0x1103b74: fmov            d1, #1.00000000
    // 0x1103b78: fcmp            d0, d1
    // 0x1103b7c: b.ne            #0x1103bd8
    // 0x1103b80: LoadField: r3 = r1->field_f
    //     0x1103b80: ldur            w3, [x1, #0xf]
    // 0x1103b84: DecompressPointer r3
    //     0x1103b84: add             x3, x3, HEAP, lsl #32
    // 0x1103b88: stur            x3, [fp, #-8]
    // 0x1103b8c: cmp             w3, NULL
    // 0x1103b90: b.ne            #0x1103bc8
    // 0x1103b94: LoadField: r2 = r1->field_7
    //     0x1103b94: ldur            w2, [x1, #7]
    // 0x1103b98: DecompressPointer r2
    //     0x1103b98: add             x2, x2, HEAP, lsl #32
    // 0x1103b9c: mov             x0, x3
    // 0x1103ba0: r1 = Null
    //     0x1103ba0: mov             x1, NULL
    // 0x1103ba4: cmp             w2, NULL
    // 0x1103ba8: b.eq            #0x1103bc8
    // 0x1103bac: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1103bac: ldur            w4, [x2, #0x17]
    // 0x1103bb0: DecompressPointer r4
    //     0x1103bb0: add             x4, x4, HEAP, lsl #32
    // 0x1103bb4: r8 = X0
    //     0x1103bb4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1103bb8: LoadField: r9 = r4->field_7
    //     0x1103bb8: ldur            x9, [x4, #7]
    // 0x1103bbc: r3 = Null
    //     0x1103bbc: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb48] Null
    //     0x1103bc0: ldr             x3, [x3, #0xb48]
    // 0x1103bc4: blr             x9
    // 0x1103bc8: ldur            x0, [fp, #-8]
    // 0x1103bcc: LeaveFrame
    //     0x1103bcc: mov             SP, fp
    //     0x1103bd0: ldp             fp, lr, [SP], #0x10
    // 0x1103bd4: ret
    //     0x1103bd4: ret             
    // 0x1103bd8: r0 = LoadClassIdInstr(r1)
    //     0x1103bd8: ldur            x0, [x1, #-1]
    //     0x1103bdc: ubfx            x0, x0, #0xc, #0x14
    // 0x1103be0: r0 = GDT[cid_x0 + 0x53c8]()
    //     0x1103be0: mov             x17, #0x53c8
    //     0x1103be4: add             lr, x0, x17
    //     0x1103be8: ldr             lr, [x21, lr, lsl #3]
    //     0x1103bec: blr             lr
    // 0x1103bf0: LeaveFrame
    //     0x1103bf0: mov             SP, fp
    //     0x1103bf4: ldp             fp, lr, [SP], #0x10
    // 0x1103bf8: ret
    //     0x1103bf8: ret             
    // 0x1103bfc: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103bfc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103c00: b               #0x1103b14
  }
  set _ begin=(/* No info */) {
    // ** addr: 0x1144e68, size: 0x90
    // 0x1144e68: EnterFrame
    //     0x1144e68: stp             fp, lr, [SP, #-0x10]!
    //     0x1144e6c: mov             fp, SP
    // 0x1144e70: AllocStack(0x10)
    //     0x1144e70: sub             SP, SP, #0x10
    // 0x1144e74: SetupParameters(Tween<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1144e74: mov             x4, x1
    //     0x1144e78: mov             x3, x2
    //     0x1144e7c: stur            x1, [fp, #-8]
    //     0x1144e80: stur            x2, [fp, #-0x10]
    // 0x1144e84: LoadField: r2 = r4->field_7
    //     0x1144e84: ldur            w2, [x4, #7]
    // 0x1144e88: DecompressPointer r2
    //     0x1144e88: add             x2, x2, HEAP, lsl #32
    // 0x1144e8c: mov             x0, x3
    // 0x1144e90: r1 = Null
    //     0x1144e90: mov             x1, NULL
    // 0x1144e94: cmp             w0, NULL
    // 0x1144e98: b.eq            #0x1144ec0
    // 0x1144e9c: cmp             w2, NULL
    // 0x1144ea0: b.eq            #0x1144ec0
    // 0x1144ea4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1144ea4: ldur            w4, [x2, #0x17]
    // 0x1144ea8: DecompressPointer r4
    //     0x1144ea8: add             x4, x4, HEAP, lsl #32
    // 0x1144eac: r8 = X0?
    //     0x1144eac: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1144eb0: LoadField: r9 = r4->field_7
    //     0x1144eb0: ldur            x9, [x4, #7]
    // 0x1144eb4: r3 = Null
    //     0x1144eb4: add             x3, PP, #0x96, lsl #12  ; [pp+0x960c0] Null
    //     0x1144eb8: ldr             x3, [x3, #0xc0]
    // 0x1144ebc: blr             x9
    // 0x1144ec0: ldur            x0, [fp, #-0x10]
    // 0x1144ec4: ldur            x1, [fp, #-8]
    // 0x1144ec8: StoreField: r1->field_b = r0
    //     0x1144ec8: stur            w0, [x1, #0xb]
    //     0x1144ecc: tbz             w0, #0, #0x1144ee8
    //     0x1144ed0: ldurb           w16, [x1, #-1]
    //     0x1144ed4: ldurb           w17, [x0, #-1]
    //     0x1144ed8: and             x16, x17, x16, lsr #2
    //     0x1144edc: tst             x16, HEAP, lsr #32
    //     0x1144ee0: b.eq            #0x1144ee8
    //     0x1144ee4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1144ee8: r0 = Null
    //     0x1144ee8: mov             x0, NULL
    // 0x1144eec: LeaveFrame
    //     0x1144eec: mov             SP, fp
    //     0x1144ef0: ldp             fp, lr, [SP], #0x10
    // 0x1144ef4: ret
    //     0x1144ef4: ret             
  }
  _ lerp(/* No info */) {
    // ** addr: 0x116bd3c, size: 0x124
    // 0x116bd3c: EnterFrame
    //     0x116bd3c: stp             fp, lr, [SP, #-0x10]!
    //     0x116bd40: mov             fp, SP
    // 0x116bd44: AllocStack(0x28)
    //     0x116bd44: sub             SP, SP, #0x28
    // 0x116bd48: SetupParameters(Tween<X0> this /* r1 => r1, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x116bd48: stur            x1, [fp, #-0x10]
    //     0x116bd4c: stur            d0, [fp, #-0x18]
    // 0x116bd50: CheckStackOverflow
    //     0x116bd50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116bd54: cmp             SP, x16
    //     0x116bd58: b.ls            #0x116be3c
    // 0x116bd5c: LoadField: r0 = r1->field_b
    //     0x116bd5c: ldur            w0, [x1, #0xb]
    // 0x116bd60: DecompressPointer r0
    //     0x116bd60: add             x0, x0, HEAP, lsl #32
    // 0x116bd64: stur            x0, [fp, #-8]
    // 0x116bd68: LoadField: r2 = r1->field_f
    //     0x116bd68: ldur            w2, [x1, #0xf]
    // 0x116bd6c: DecompressPointer r2
    //     0x116bd6c: add             x2, x2, HEAP, lsl #32
    // 0x116bd70: stp             x0, x2, [SP]
    // 0x116bd74: r4 = 0
    //     0x116bd74: mov             x4, #0
    // 0x116bd78: ldr             x0, [SP, #8]
    // 0x116bd7c: r30 = 139822029843448
    //     0x116bd7c: add             x16, PP, #0x96, lsl #12  ; [pp+0x96070] IMM: 0x7f2ada6babf8
    //     0x116bd80: ldp             lr, x5, [x16, #0x70]
    // 0x116bd84: blr             lr
    // 0x116bd88: ldur            d0, [fp, #-0x18]
    // 0x116bd8c: r1 = inline_Allocate_Double()
    //     0x116bd8c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x116bd90: add             x1, x1, #0x10
    //     0x116bd94: cmp             x2, x1
    //     0x116bd98: b.ls            #0x116be44
    //     0x116bd9c: str             x1, [THR, #0x60]  ; THR::top
    //     0x116bda0: sub             x1, x1, #0xf
    //     0x116bda4: mov             x2, #0xe19c
    //     0x116bda8: movk            x2, #3, lsl #16
    //     0x116bdac: stur            x2, [x1, #-1]
    // 0x116bdb0: dmb             ishst
    // 0x116bdb4: StoreField: r1->field_7 = d0
    //     0x116bdb4: stur            d0, [x1, #7]
    // 0x116bdb8: stp             x1, x0, [SP]
    // 0x116bdbc: r4 = 0
    //     0x116bdbc: mov             x4, #0
    // 0x116bdc0: ldr             x0, [SP, #8]
    // 0x116bdc4: r30 = 139822029843448
    //     0x116bdc4: add             x16, PP, #0x96, lsl #12  ; [pp+0x96080] IMM: 0x7f2ada6babf8
    //     0x116bdc8: ldp             lr, x5, [x16, #0x80]
    // 0x116bdcc: blr             lr
    // 0x116bdd0: ldur            x16, [fp, #-8]
    // 0x116bdd4: stp             x0, x16, [SP]
    // 0x116bdd8: r4 = 0
    //     0x116bdd8: mov             x4, #0
    // 0x116bddc: ldr             x0, [SP, #8]
    // 0x116bde0: r30 = 139822029843448
    //     0x116bde0: add             x16, PP, #0x96, lsl #12  ; [pp+0x96090] IMM: 0x7f2ada6babf8
    //     0x116bde4: ldp             lr, x5, [x16, #0x90]
    // 0x116bde8: blr             lr
    // 0x116bdec: mov             x3, x0
    // 0x116bdf0: ldur            x0, [fp, #-0x10]
    // 0x116bdf4: stur            x3, [fp, #-8]
    // 0x116bdf8: LoadField: r2 = r0->field_7
    //     0x116bdf8: ldur            w2, [x0, #7]
    // 0x116bdfc: DecompressPointer r2
    //     0x116bdfc: add             x2, x2, HEAP, lsl #32
    // 0x116be00: mov             x0, x3
    // 0x116be04: r1 = Null
    //     0x116be04: mov             x1, NULL
    // 0x116be08: cmp             w2, NULL
    // 0x116be0c: b.eq            #0x116be2c
    // 0x116be10: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x116be10: ldur            w4, [x2, #0x17]
    // 0x116be14: DecompressPointer r4
    //     0x116be14: add             x4, x4, HEAP, lsl #32
    // 0x116be18: r8 = X0
    //     0x116be18: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x116be1c: LoadField: r9 = r4->field_7
    //     0x116be1c: ldur            x9, [x4, #7]
    // 0x116be20: r3 = Null
    //     0x116be20: add             x3, PP, #0x96, lsl #12  ; [pp+0x960a0] Null
    //     0x116be24: ldr             x3, [x3, #0xa0]
    // 0x116be28: blr             x9
    // 0x116be2c: ldur            x0, [fp, #-8]
    // 0x116be30: LeaveFrame
    //     0x116be30: mov             SP, fp
    //     0x116be34: ldp             fp, lr, [SP], #0x10
    // 0x116be38: ret
    //     0x116be38: ret             
    // 0x116be3c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116be3c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116be40: b               #0x116bd5c
    // 0x116be44: SaveReg d0
    //     0x116be44: str             q0, [SP, #-0x10]!
    // 0x116be48: SaveReg r0
    //     0x116be48: str             x0, [SP, #-8]!
    // 0x116be4c: r0 = AllocateDouble()
    //     0x116be4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116be50: mov             x1, x0
    // 0x116be54: RestoreReg r0
    //     0x116be54: ldr             x0, [SP], #8
    // 0x116be58: RestoreReg d0
    //     0x116be58: ldr             q0, [SP], #0x10
    // 0x116be5c: b               #0x116bdb4
  }
  set _ end=(/* No info */) {
    // ** addr: 0x1196b04, size: 0x90
    // 0x1196b04: EnterFrame
    //     0x1196b04: stp             fp, lr, [SP, #-0x10]!
    //     0x1196b08: mov             fp, SP
    // 0x1196b0c: AllocStack(0x10)
    //     0x1196b0c: sub             SP, SP, #0x10
    // 0x1196b10: SetupParameters(Tween<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1196b10: mov             x4, x1
    //     0x1196b14: mov             x3, x2
    //     0x1196b18: stur            x1, [fp, #-8]
    //     0x1196b1c: stur            x2, [fp, #-0x10]
    // 0x1196b20: LoadField: r2 = r4->field_7
    //     0x1196b20: ldur            w2, [x4, #7]
    // 0x1196b24: DecompressPointer r2
    //     0x1196b24: add             x2, x2, HEAP, lsl #32
    // 0x1196b28: mov             x0, x3
    // 0x1196b2c: r1 = Null
    //     0x1196b2c: mov             x1, NULL
    // 0x1196b30: cmp             w0, NULL
    // 0x1196b34: b.eq            #0x1196b5c
    // 0x1196b38: cmp             w2, NULL
    // 0x1196b3c: b.eq            #0x1196b5c
    // 0x1196b40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1196b40: ldur            w4, [x2, #0x17]
    // 0x1196b44: DecompressPointer r4
    //     0x1196b44: add             x4, x4, HEAP, lsl #32
    // 0x1196b48: r8 = X0?
    //     0x1196b48: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1196b4c: LoadField: r9 = r4->field_7
    //     0x1196b4c: ldur            x9, [x4, #7]
    // 0x1196b50: r3 = Null
    //     0x1196b50: add             x3, PP, #0x96, lsl #12  ; [pp+0x960b0] Null
    //     0x1196b54: ldr             x3, [x3, #0xb0]
    // 0x1196b58: blr             x9
    // 0x1196b5c: ldur            x0, [fp, #-0x10]
    // 0x1196b60: ldur            x1, [fp, #-8]
    // 0x1196b64: StoreField: r1->field_f = r0
    //     0x1196b64: stur            w0, [x1, #0xf]
    //     0x1196b68: tbz             w0, #0, #0x1196b84
    //     0x1196b6c: ldurb           w16, [x1, #-1]
    //     0x1196b70: ldurb           w17, [x0, #-1]
    //     0x1196b74: and             x16, x17, x16, lsr #2
    //     0x1196b78: tst             x16, HEAP, lsr #32
    //     0x1196b7c: b.eq            #0x1196b84
    //     0x1196b80: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1196b84: r0 = Null
    //     0x1196b84: mov             x0, NULL
    // 0x1196b88: LeaveFrame
    //     0x1196b88: mov             SP, fp
    //     0x1196b8c: ldp             fp, lr, [SP], #0x10
    // 0x1196b90: ret
    //     0x1196b90: ret             
  }
}

// class id: 3312, size: 0x14, field offset: 0x14
class ConstantTween<X0> extends Tween<X0> {

  _ lerp(/* No info */) {
    // ** addr: 0x115d33c, size: 0x64
    // 0x115d33c: EnterFrame
    //     0x115d33c: stp             fp, lr, [SP, #-0x10]!
    //     0x115d340: mov             fp, SP
    // 0x115d344: AllocStack(0x8)
    //     0x115d344: sub             SP, SP, #8
    // 0x115d348: LoadField: r3 = r1->field_b
    //     0x115d348: ldur            w3, [x1, #0xb]
    // 0x115d34c: DecompressPointer r3
    //     0x115d34c: add             x3, x3, HEAP, lsl #32
    // 0x115d350: stur            x3, [fp, #-8]
    // 0x115d354: cmp             w3, NULL
    // 0x115d358: b.ne            #0x115d390
    // 0x115d35c: LoadField: r2 = r1->field_7
    //     0x115d35c: ldur            w2, [x1, #7]
    // 0x115d360: DecompressPointer r2
    //     0x115d360: add             x2, x2, HEAP, lsl #32
    // 0x115d364: mov             x0, x3
    // 0x115d368: r1 = Null
    //     0x115d368: mov             x1, NULL
    // 0x115d36c: cmp             w2, NULL
    // 0x115d370: b.eq            #0x115d390
    // 0x115d374: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x115d374: ldur            w4, [x2, #0x17]
    // 0x115d378: DecompressPointer r4
    //     0x115d378: add             x4, x4, HEAP, lsl #32
    // 0x115d37c: r8 = X0
    //     0x115d37c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x115d380: LoadField: r9 = r4->field_7
    //     0x115d380: ldur            x9, [x4, #7]
    // 0x115d384: r3 = Null
    //     0x115d384: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1098] Null
    //     0x115d388: ldr             x3, [x3, #0x98]
    // 0x115d38c: blr             x9
    // 0x115d390: ldur            x0, [fp, #-8]
    // 0x115d394: LeaveFrame
    //     0x115d394: mov             SP, fp
    //     0x115d398: ldp             fp, lr, [SP], #0x10
    // 0x115d39c: ret
    //     0x115d39c: ret             
  }
}

// class id: 3313, size: 0x14, field offset: 0x14
class IntTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115d1d0, size: 0x16c
    // 0x115d1d0: EnterFrame
    //     0x115d1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x115d1d4: mov             fp, SP
    // 0x115d1d8: AllocStack(0x20)
    //     0x115d1d8: sub             SP, SP, #0x20
    // 0x115d1dc: SetupParameters(dynamic _ /* d0 => d0, fp-0x10 */)
    //     0x115d1dc: stur            d0, [fp, #-0x10]
    // 0x115d1e0: CheckStackOverflow
    //     0x115d1e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d1e4: cmp             SP, x16
    //     0x115d1e8: b.ls            #0x115d300
    // 0x115d1ec: LoadField: r2 = r1->field_b
    //     0x115d1ec: ldur            w2, [x1, #0xb]
    // 0x115d1f0: DecompressPointer r2
    //     0x115d1f0: add             x2, x2, HEAP, lsl #32
    // 0x115d1f4: stur            x2, [fp, #-8]
    // 0x115d1f8: cmp             w2, NULL
    // 0x115d1fc: b.eq            #0x115d308
    // 0x115d200: LoadField: r0 = r1->field_f
    //     0x115d200: ldur            w0, [x1, #0xf]
    // 0x115d204: DecompressPointer r0
    //     0x115d204: add             x0, x0, HEAP, lsl #32
    // 0x115d208: cmp             w0, NULL
    // 0x115d20c: b.eq            #0x115d30c
    // 0x115d210: r1 = 60
    //     0x115d210: mov             x1, #0x3c
    // 0x115d214: branchIfSmi(r0, 0x115d220)
    //     0x115d214: tbz             w0, #0, #0x115d220
    // 0x115d218: r1 = LoadClassIdInstr(r0)
    //     0x115d218: ldur            x1, [x0, #-1]
    //     0x115d21c: ubfx            x1, x1, #0xc, #0x14
    // 0x115d220: stp             x2, x0, [SP]
    // 0x115d224: mov             x0, x1
    // 0x115d228: r0 = GDT[cid_x0 + -0xff7]()
    //     0x115d228: sub             lr, x0, #0xff7
    //     0x115d22c: ldr             lr, [x21, lr, lsl #3]
    //     0x115d230: blr             lr
    // 0x115d234: r1 = LoadInt32Instr(r0)
    //     0x115d234: sbfx            x1, x0, #1, #0x1f
    //     0x115d238: tbz             w0, #0, #0x115d240
    //     0x115d23c: ldur            x1, [x0, #7]
    // 0x115d240: scvtf           d0, x1
    // 0x115d244: ldur            d1, [fp, #-0x10]
    // 0x115d248: fmul            d2, d0, d1
    // 0x115d24c: r0 = inline_Allocate_Double()
    //     0x115d24c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115d250: add             x0, x0, #0x10
    //     0x115d254: cmp             x1, x0
    //     0x115d258: b.ls            #0x115d310
    //     0x115d25c: str             x0, [THR, #0x60]  ; THR::top
    //     0x115d260: sub             x0, x0, #0xf
    //     0x115d264: mov             x1, #0xe19c
    //     0x115d268: movk            x1, #3, lsl #16
    //     0x115d26c: stur            x1, [x0, #-1]
    // 0x115d270: dmb             ishst
    // 0x115d274: StoreField: r0->field_7 = d2
    //     0x115d274: stur            d2, [x0, #7]
    // 0x115d278: ldur            x1, [fp, #-8]
    // 0x115d27c: r2 = 60
    //     0x115d27c: mov             x2, #0x3c
    // 0x115d280: branchIfSmi(r1, 0x115d28c)
    //     0x115d280: tbz             w1, #0, #0x115d28c
    // 0x115d284: r2 = LoadClassIdInstr(r1)
    //     0x115d284: ldur            x2, [x1, #-1]
    //     0x115d288: ubfx            x2, x2, #0xc, #0x14
    // 0x115d28c: stp             x0, x1, [SP]
    // 0x115d290: mov             x0, x2
    // 0x115d294: r0 = GDT[cid_x0 + -0xff1]()
    //     0x115d294: sub             lr, x0, #0xff1
    //     0x115d298: ldr             lr, [x21, lr, lsl #3]
    //     0x115d29c: blr             lr
    // 0x115d2a0: LoadField: d0 = r0->field_7
    //     0x115d2a0: ldur            d0, [x0, #7]
    // 0x115d2a4: stp             fp, lr, [SP, #-0x10]!
    // 0x115d2a8: mov             fp, SP
    // 0x115d2ac: CallRuntime_LibcRound(double) -> double
    //     0x115d2ac: and             SP, SP, #0xfffffffffffffff0
    //     0x115d2b0: mov             sp, SP
    //     0x115d2b4: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x115d2b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d2bc: blr             x16
    //     0x115d2c0: mov             x16, #8
    //     0x115d2c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d2c8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115d2cc: sub             sp, x16, #1, lsl #12
    //     0x115d2d0: mov             SP, fp
    //     0x115d2d4: ldp             fp, lr, [SP], #0x10
    // 0x115d2d8: fcmp            d0, d0
    // 0x115d2dc: b.vs            #0x115d320
    // 0x115d2e0: fcvtzs          x0, d0
    // 0x115d2e4: asr             x16, x0, #0x1e
    // 0x115d2e8: cmp             x16, x0, asr #63
    // 0x115d2ec: b.ne            #0x115d320
    // 0x115d2f0: lsl             x0, x0, #1
    // 0x115d2f4: LeaveFrame
    //     0x115d2f4: mov             SP, fp
    //     0x115d2f8: ldp             fp, lr, [SP], #0x10
    // 0x115d2fc: ret
    //     0x115d2fc: ret             
    // 0x115d300: r0 = StackOverflowSharedWithFPURegs()
    //     0x115d300: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115d304: b               #0x115d1ec
    // 0x115d308: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115d308: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x115d30c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115d30c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x115d310: SaveReg d2
    //     0x115d310: str             q2, [SP, #-0x10]!
    // 0x115d314: r0 = AllocateDouble()
    //     0x115d314: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115d318: RestoreReg d2
    //     0x115d318: ldr             q2, [SP], #0x10
    // 0x115d31c: b               #0x115d274
    // 0x115d320: SaveReg d0
    //     0x115d320: str             q0, [SP, #-0x10]!
    // 0x115d324: r0 = 76
    //     0x115d324: mov             x0, #0x4c
    // 0x115d328: r30 = DoubleToIntegerStub
    //     0x115d328: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x115d32c: LoadField: r30 = r30->field_7
    //     0x115d32c: ldur            lr, [lr, #7]
    // 0x115d330: blr             lr
    // 0x115d334: RestoreReg d0
    //     0x115d334: ldr             q0, [SP], #0x10
    // 0x115d338: b               #0x115d2f4
  }
}

// class id: 3314, size: 0x14, field offset: 0x14
class RectTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115d190, size: 0x40
    // 0x115d190: EnterFrame
    //     0x115d190: stp             fp, lr, [SP, #-0x10]!
    //     0x115d194: mov             fp, SP
    // 0x115d198: CheckStackOverflow
    //     0x115d198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d19c: cmp             SP, x16
    //     0x115d1a0: b.ls            #0x115d1c8
    // 0x115d1a4: LoadField: r0 = r1->field_b
    //     0x115d1a4: ldur            w0, [x1, #0xb]
    // 0x115d1a8: DecompressPointer r0
    //     0x115d1a8: add             x0, x0, HEAP, lsl #32
    // 0x115d1ac: LoadField: r2 = r1->field_f
    //     0x115d1ac: ldur            w2, [x1, #0xf]
    // 0x115d1b0: DecompressPointer r2
    //     0x115d1b0: add             x2, x2, HEAP, lsl #32
    // 0x115d1b4: mov             x1, x0
    // 0x115d1b8: r0 = lerp()
    //     0x115d1b8: bl              #0xae0924  ; [dart:ui] Rect::lerp
    // 0x115d1bc: LeaveFrame
    //     0x115d1bc: mov             SP, fp
    //     0x115d1c0: ldp             fp, lr, [SP], #0x10
    // 0x115d1c4: ret
    //     0x115d1c4: ret             
    // 0x115d1c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x115d1c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115d1cc: b               #0x115d1a4
  }
}

// class id: 3316, size: 0x14, field offset: 0x14
class SizeTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115ca68, size: 0x88
    // 0x115ca68: EnterFrame
    //     0x115ca68: stp             fp, lr, [SP, #-0x10]!
    //     0x115ca6c: mov             fp, SP
    // 0x115ca70: CheckStackOverflow
    //     0x115ca70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115ca74: cmp             SP, x16
    //     0x115ca78: b.ls            #0x115cacc
    // 0x115ca7c: LoadField: r0 = r1->field_b
    //     0x115ca7c: ldur            w0, [x1, #0xb]
    // 0x115ca80: DecompressPointer r0
    //     0x115ca80: add             x0, x0, HEAP, lsl #32
    // 0x115ca84: LoadField: r2 = r1->field_f
    //     0x115ca84: ldur            w2, [x1, #0xf]
    // 0x115ca88: DecompressPointer r2
    //     0x115ca88: add             x2, x2, HEAP, lsl #32
    // 0x115ca8c: r3 = inline_Allocate_Double()
    //     0x115ca8c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x115ca90: add             x3, x3, #0x10
    //     0x115ca94: cmp             x1, x3
    //     0x115ca98: b.ls            #0x115cad4
    //     0x115ca9c: str             x3, [THR, #0x60]  ; THR::top
    //     0x115caa0: sub             x3, x3, #0xf
    //     0x115caa4: mov             x1, #0xe19c
    //     0x115caa8: movk            x1, #3, lsl #16
    //     0x115caac: stur            x1, [x3, #-1]
    // 0x115cab0: dmb             ishst
    // 0x115cab4: StoreField: r3->field_7 = d0
    //     0x115cab4: stur            d0, [x3, #7]
    // 0x115cab8: mov             x1, x0
    // 0x115cabc: r0 = lerp()
    //     0x115cabc: bl              #0xb6ee5c  ; [dart:ui] Size::lerp
    // 0x115cac0: LeaveFrame
    //     0x115cac0: mov             SP, fp
    //     0x115cac4: ldp             fp, lr, [SP], #0x10
    // 0x115cac8: ret
    //     0x115cac8: ret             
    // 0x115cacc: r0 = StackOverflowSharedWithFPURegs()
    //     0x115cacc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115cad0: b               #0x115ca7c
    // 0x115cad4: SaveReg d0
    //     0x115cad4: str             q0, [SP, #-0x10]!
    // 0x115cad8: stp             x0, x2, [SP, #-0x10]!
    // 0x115cadc: r0 = AllocateDouble()
    //     0x115cadc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115cae0: mov             x3, x0
    // 0x115cae4: ldp             x0, x2, [SP], #0x10
    // 0x115cae8: RestoreReg d0
    //     0x115cae8: ldr             q0, [SP], #0x10
    // 0x115caec: b               #0x115cab4
  }
}

// class id: 3317, size: 0x14, field offset: 0x14
class ColorTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115c9e0, size: 0x88
    // 0x115c9e0: EnterFrame
    //     0x115c9e0: stp             fp, lr, [SP, #-0x10]!
    //     0x115c9e4: mov             fp, SP
    // 0x115c9e8: CheckStackOverflow
    //     0x115c9e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c9ec: cmp             SP, x16
    //     0x115c9f0: b.ls            #0x115ca44
    // 0x115c9f4: LoadField: r0 = r1->field_b
    //     0x115c9f4: ldur            w0, [x1, #0xb]
    // 0x115c9f8: DecompressPointer r0
    //     0x115c9f8: add             x0, x0, HEAP, lsl #32
    // 0x115c9fc: LoadField: r2 = r1->field_f
    //     0x115c9fc: ldur            w2, [x1, #0xf]
    // 0x115ca00: DecompressPointer r2
    //     0x115ca00: add             x2, x2, HEAP, lsl #32
    // 0x115ca04: r3 = inline_Allocate_Double()
    //     0x115ca04: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x115ca08: add             x3, x3, #0x10
    //     0x115ca0c: cmp             x1, x3
    //     0x115ca10: b.ls            #0x115ca4c
    //     0x115ca14: str             x3, [THR, #0x60]  ; THR::top
    //     0x115ca18: sub             x3, x3, #0xf
    //     0x115ca1c: mov             x1, #0xe19c
    //     0x115ca20: movk            x1, #3, lsl #16
    //     0x115ca24: stur            x1, [x3, #-1]
    // 0x115ca28: dmb             ishst
    // 0x115ca2c: StoreField: r3->field_7 = d0
    //     0x115ca2c: stur            d0, [x3, #7]
    // 0x115ca30: mov             x1, x0
    // 0x115ca34: r0 = lerp()
    //     0x115ca34: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115ca38: LeaveFrame
    //     0x115ca38: mov             SP, fp
    //     0x115ca3c: ldp             fp, lr, [SP], #0x10
    // 0x115ca40: ret
    //     0x115ca40: ret             
    // 0x115ca44: r0 = StackOverflowSharedWithFPURegs()
    //     0x115ca44: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115ca48: b               #0x115c9f4
    // 0x115ca4c: SaveReg d0
    //     0x115ca4c: str             q0, [SP, #-0x10]!
    // 0x115ca50: stp             x0, x2, [SP, #-0x10]!
    // 0x115ca54: r0 = AllocateDouble()
    //     0x115ca54: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ca58: mov             x3, x0
    // 0x115ca5c: ldp             x0, x2, [SP], #0x10
    // 0x115ca60: RestoreReg d0
    //     0x115ca60: ldr             q0, [SP], #0x10
    // 0x115ca64: b               #0x115ca2c
  }
}

// class id: 3318, size: 0x18, field offset: 0x14
class ReverseTween<X0> extends Tween<X0> {

  _ lerp(/* No info */) {
    // ** addr: 0x115c980, size: 0x60
    // 0x115c980: EnterFrame
    //     0x115c980: stp             fp, lr, [SP, #-0x10]!
    //     0x115c984: mov             fp, SP
    // 0x115c988: d1 = 1.000000
    //     0x115c988: fmov            d1, #1.00000000
    // 0x115c98c: CheckStackOverflow
    //     0x115c98c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c990: cmp             SP, x16
    //     0x115c994: b.ls            #0x115c9d8
    // 0x115c998: LoadField: r0 = r1->field_13
    //     0x115c998: ldur            w0, [x1, #0x13]
    // 0x115c99c: DecompressPointer r0
    //     0x115c99c: add             x0, x0, HEAP, lsl #32
    // 0x115c9a0: fsub            d2, d1, d0
    // 0x115c9a4: r1 = LoadClassIdInstr(r0)
    //     0x115c9a4: ldur            x1, [x0, #-1]
    //     0x115c9a8: ubfx            x1, x1, #0xc, #0x14
    // 0x115c9ac: mov             x16, x0
    // 0x115c9b0: mov             x0, x1
    // 0x115c9b4: mov             x1, x16
    // 0x115c9b8: mov             v0.16b, v2.16b
    // 0x115c9bc: r0 = GDT[cid_x0 + 0x53c8]()
    //     0x115c9bc: mov             x17, #0x53c8
    //     0x115c9c0: add             lr, x0, x17
    //     0x115c9c4: ldr             lr, [x21, lr, lsl #3]
    //     0x115c9c8: blr             lr
    // 0x115c9cc: LeaveFrame
    //     0x115c9cc: mov             SP, fp
    //     0x115c9d0: ldp             fp, lr, [SP], #0x10
    // 0x115c9d4: ret
    //     0x115c9d4: ret             
    // 0x115c9d8: r0 = StackOverflowSharedWithFPURegs()
    //     0x115c9d8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115c9dc: b               #0x115c998
  }
}

// class id: 3319, size: 0x14, field offset: 0xc
class _ChainedEvaluation<X0> extends Animatable<X0> {

  _ transform(/* No info */) {
    // ** addr: 0x1103a74, size: 0x84
    // 0x1103a74: EnterFrame
    //     0x1103a74: stp             fp, lr, [SP, #-0x10]!
    //     0x1103a78: mov             fp, SP
    // 0x1103a7c: AllocStack(0x8)
    //     0x1103a7c: sub             SP, SP, #8
    // 0x1103a80: CheckStackOverflow
    //     0x1103a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103a84: cmp             SP, x16
    //     0x1103a88: b.ls            #0x1103af0
    // 0x1103a8c: LoadField: r2 = r1->field_f
    //     0x1103a8c: ldur            w2, [x1, #0xf]
    // 0x1103a90: DecompressPointer r2
    //     0x1103a90: add             x2, x2, HEAP, lsl #32
    // 0x1103a94: stur            x2, [fp, #-8]
    // 0x1103a98: LoadField: r0 = r1->field_b
    //     0x1103a98: ldur            w0, [x1, #0xb]
    // 0x1103a9c: DecompressPointer r0
    //     0x1103a9c: add             x0, x0, HEAP, lsl #32
    // 0x1103aa0: r1 = LoadClassIdInstr(r0)
    //     0x1103aa0: ldur            x1, [x0, #-1]
    //     0x1103aa4: ubfx            x1, x1, #0xc, #0x14
    // 0x1103aa8: mov             x16, x0
    // 0x1103aac: mov             x0, x1
    // 0x1103ab0: mov             x1, x16
    // 0x1103ab4: r0 = GDT[cid_x0 + 0xa1d0]()
    //     0x1103ab4: mov             x17, #0xa1d0
    //     0x1103ab8: add             lr, x0, x17
    //     0x1103abc: ldr             lr, [x21, lr, lsl #3]
    //     0x1103ac0: blr             lr
    // 0x1103ac4: LoadField: d0 = r0->field_7
    //     0x1103ac4: ldur            d0, [x0, #7]
    // 0x1103ac8: ldur            x1, [fp, #-8]
    // 0x1103acc: r0 = LoadClassIdInstr(r1)
    //     0x1103acc: ldur            x0, [x1, #-1]
    //     0x1103ad0: ubfx            x0, x0, #0xc, #0x14
    // 0x1103ad4: r0 = GDT[cid_x0 + 0xa1d0]()
    //     0x1103ad4: mov             x17, #0xa1d0
    //     0x1103ad8: add             lr, x0, x17
    //     0x1103adc: ldr             lr, [x21, lr, lsl #3]
    //     0x1103ae0: blr             lr
    // 0x1103ae4: LeaveFrame
    //     0x1103ae4: mov             SP, fp
    //     0x1103ae8: ldp             fp, lr, [SP], #0x10
    // 0x1103aec: ret
    //     0x1103aec: ret             
    // 0x1103af0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103af0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103af4: b               #0x1103a8c
  }
}

// class id: 4358, size: 0x14, field offset: 0xc
class _AnimatedEvaluation<X0> extends _MixinApplication461&Animation&AnimationWithParentMixin<X0> {

  X0 dyn:get:value(_AnimatedEvaluation<X0>) {
    // ** addr: 0x915b90, size: 0x6c
    // 0x915b90: EnterFrame
    //     0x915b90: stp             fp, lr, [SP, #-0x10]!
    //     0x915b94: mov             fp, SP
    // 0x915b98: CheckStackOverflow
    //     0x915b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x915b9c: cmp             SP, x16
    //     0x915ba0: b.ls            #0x915bdc
    // 0x915ba4: ldr             x0, [fp, #0x10]
    // 0x915ba8: LoadField: r1 = r0->field_f
    //     0x915ba8: ldur            w1, [x0, #0xf]
    // 0x915bac: DecompressPointer r1
    //     0x915bac: add             x1, x1, HEAP, lsl #32
    // 0x915bb0: LoadField: r2 = r0->field_b
    //     0x915bb0: ldur            w2, [x0, #0xb]
    // 0x915bb4: DecompressPointer r2
    //     0x915bb4: add             x2, x2, HEAP, lsl #32
    // 0x915bb8: r0 = LoadClassIdInstr(r1)
    //     0x915bb8: ldur            x0, [x1, #-1]
    //     0x915bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x915bc0: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x915bc0: mov             x17, #0x80ed
    //     0x915bc4: add             lr, x0, x17
    //     0x915bc8: ldr             lr, [x21, lr, lsl #3]
    //     0x915bcc: blr             lr
    // 0x915bd0: LeaveFrame
    //     0x915bd0: mov             SP, fp
    //     0x915bd4: ldp             fp, lr, [SP], #0x10
    // 0x915bd8: ret
    //     0x915bd8: ret             
    // 0x915bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x915bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x915be0: b               #0x915ba4
  }
  X0 value(_AnimatedEvaluation<X0>) {
    // ** addr: 0xae68a0, size: 0x5c
    // 0xae68a0: EnterFrame
    //     0xae68a0: stp             fp, lr, [SP, #-0x10]!
    //     0xae68a4: mov             fp, SP
    // 0xae68a8: CheckStackOverflow
    //     0xae68a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae68ac: cmp             SP, x16
    //     0xae68b0: b.ls            #0xae68f4
    // 0xae68b4: LoadField: r0 = r1->field_f
    //     0xae68b4: ldur            w0, [x1, #0xf]
    // 0xae68b8: DecompressPointer r0
    //     0xae68b8: add             x0, x0, HEAP, lsl #32
    // 0xae68bc: LoadField: r2 = r1->field_b
    //     0xae68bc: ldur            w2, [x1, #0xb]
    // 0xae68c0: DecompressPointer r2
    //     0xae68c0: add             x2, x2, HEAP, lsl #32
    // 0xae68c4: r1 = LoadClassIdInstr(r0)
    //     0xae68c4: ldur            x1, [x0, #-1]
    //     0xae68c8: ubfx            x1, x1, #0xc, #0x14
    // 0xae68cc: mov             x16, x0
    // 0xae68d0: mov             x0, x1
    // 0xae68d4: mov             x1, x16
    // 0xae68d8: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xae68d8: mov             x17, #0x80ed
    //     0xae68dc: add             lr, x0, x17
    //     0xae68e0: ldr             lr, [x21, lr, lsl #3]
    //     0xae68e4: blr             lr
    // 0xae68e8: LeaveFrame
    //     0xae68e8: mov             SP, fp
    //     0xae68ec: ldp             fp, lr, [SP], #0x10
    // 0xae68f0: ret
    //     0xae68f0: ret             
    // 0xae68f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae68f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae68f8: b               #0xae68b4
  }
}
