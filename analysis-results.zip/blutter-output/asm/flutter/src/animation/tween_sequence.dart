// lib: , url: package:flutter/src/animation/tween_sequence.dart

// class id: 1048768, size: 0x8
class :: {
}

// class id: 3291, size: 0x18, field offset: 0x8
//   const constructor, 
class _Interval extends Object {

  dynamic value(dynamic) {
    // ** addr: 0xb6f76c, size: 0x3c
    // 0xb6f76c: EnterFrame
    //     0xb6f76c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f770: mov             fp, SP
    // 0xb6f774: ldr             x2, [fp, #0x10]
    // 0xb6f778: r1 = Function 'value':.
    //     0xb6f778: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1080] AnonymousClosure: (0xb6f790), of [package:flutter/src/animation/tween_sequence.dart] _Interval
    //     0xb6f77c: ldr             x1, [x1, #0x80]
    // 0xb6f780: r0 = AllocateClosure()
    //     0xb6f780: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb6f784: LeaveFrame
    //     0xb6f784: mov             SP, fp
    //     0xb6f788: ldp             fp, lr, [SP], #0x10
    // 0xb6f78c: ret
    //     0xb6f78c: ret             
  }
  bool contains(_Interval, double) {
    // ** addr: 0xb6f6b4, size: 0x98
    // 0xb6f6b4: EnterFrame
    //     0xb6f6b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f6b8: mov             fp, SP
    // 0xb6f6bc: ldr             x0, [fp, #0x10]
    // 0xb6f6c0: r2 = Null
    //     0xb6f6c0: mov             x2, NULL
    // 0xb6f6c4: r1 = Null
    //     0xb6f6c4: mov             x1, NULL
    // 0xb6f6c8: r4 = 60
    //     0xb6f6c8: mov             x4, #0x3c
    // 0xb6f6cc: branchIfSmi(r0, 0xb6f6d8)
    //     0xb6f6cc: tbz             w0, #0, #0xb6f6d8
    // 0xb6f6d0: r4 = LoadClassIdInstr(r0)
    //     0xb6f6d0: ldur            x4, [x0, #-1]
    //     0xb6f6d4: ubfx            x4, x4, #0xc, #0x14
    // 0xb6f6d8: cmp             x4, #0x3e
    // 0xb6f6dc: b.eq            #0xb6f6f0
    // 0xb6f6e0: r8 = double
    //     0xb6f6e0: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0xb6f6e4: r3 = Null
    //     0xb6f6e4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1088] Null
    //     0xb6f6e8: ldr             x3, [x3, #0x88]
    // 0xb6f6ec: r0 = double()
    //     0xb6f6ec: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0xb6f6f0: ldr             x1, [fp, #0x18]
    // 0xb6f6f4: LoadField: d0 = r1->field_7
    //     0xb6f6f4: ldur            d0, [x1, #7]
    // 0xb6f6f8: ldr             x2, [fp, #0x10]
    // 0xb6f6fc: LoadField: d1 = r2->field_7
    //     0xb6f6fc: ldur            d1, [x2, #7]
    // 0xb6f700: fcmp            d1, d0
    // 0xb6f704: b.lt            #0xb6f724
    // 0xb6f708: LoadField: d0 = r1->field_f
    //     0xb6f708: ldur            d0, [x1, #0xf]
    // 0xb6f70c: fcmp            d0, d1
    // 0xb6f710: r16 = true
    //     0xb6f710: add             x16, NULL, #0x20  ; true
    // 0xb6f714: r17 = false
    //     0xb6f714: add             x17, NULL, #0x30  ; false
    // 0xb6f718: csel            x1, x16, x17, gt
    // 0xb6f71c: mov             x0, x1
    // 0xb6f720: b               #0xb6f728
    // 0xb6f724: r0 = false
    //     0xb6f724: add             x0, NULL, #0x30  ; false
    // 0xb6f728: LeaveFrame
    //     0xb6f728: mov             SP, fp
    //     0xb6f72c: ldp             fp, lr, [SP], #0x10
    // 0xb6f730: ret
    //     0xb6f730: ret             
  }
  [closure] double value(dynamic, double) {
    // ** addr: 0xb6f790, size: 0x78
    // 0xb6f790: EnterFrame
    //     0xb6f790: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f794: mov             fp, SP
    // 0xb6f798: ldr             x1, [fp, #0x18]
    // 0xb6f79c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb6f79c: ldur            w2, [x1, #0x17]
    // 0xb6f7a0: DecompressPointer r2
    //     0xb6f7a0: add             x2, x2, HEAP, lsl #32
    // 0xb6f7a4: LoadField: d0 = r2->field_7
    //     0xb6f7a4: ldur            d0, [x2, #7]
    // 0xb6f7a8: ldr             x1, [fp, #0x10]
    // 0xb6f7ac: LoadField: d1 = r1->field_7
    //     0xb6f7ac: ldur            d1, [x1, #7]
    // 0xb6f7b0: fsub            d2, d1, d0
    // 0xb6f7b4: LoadField: d1 = r2->field_f
    //     0xb6f7b4: ldur            d1, [x2, #0xf]
    // 0xb6f7b8: fsub            d3, d1, d0
    // 0xb6f7bc: fdiv            d0, d2, d3
    // 0xb6f7c0: r0 = inline_Allocate_Double()
    //     0xb6f7c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6f7c4: add             x0, x0, #0x10
    //     0xb6f7c8: cmp             x1, x0
    //     0xb6f7cc: b.ls            #0xb6f7f8
    //     0xb6f7d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6f7d4: sub             x0, x0, #0xf
    //     0xb6f7d8: mov             x1, #0xe19c
    //     0xb6f7dc: movk            x1, #3, lsl #16
    //     0xb6f7e0: stur            x1, [x0, #-1]
    // 0xb6f7e4: dmb             ishst
    // 0xb6f7e8: StoreField: r0->field_7 = d0
    //     0xb6f7e8: stur            d0, [x0, #7]
    // 0xb6f7ec: LeaveFrame
    //     0xb6f7ec: mov             SP, fp
    //     0xb6f7f0: ldp             fp, lr, [SP], #0x10
    // 0xb6f7f4: ret
    //     0xb6f7f4: ret             
    // 0xb6f7f8: SaveReg d0
    //     0xb6f7f8: str             q0, [SP, #-0x10]!
    // 0xb6f7fc: r0 = AllocateDouble()
    //     0xb6f7fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6f800: RestoreReg d0
    //     0xb6f800: ldr             q0, [SP], #0x10
    // 0xb6f804: b               #0xb6f7e8
  }
}

// class id: 3292, size: 0x18, field offset: 0x8
//   const constructor, 
class TweenSequenceItem<X0> extends Object {
}

// class id: 3294, size: 0x14, field offset: 0xc
class TweenSequence<X0> extends Animatable<X0> {

  _ TweenSequence(/* No info */) {
    // ** addr: 0xb6f43c, size: 0x254
    // 0xb6f43c: EnterFrame
    //     0xb6f43c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f440: mov             fp, SP
    // 0xb6f444: AllocStack(0x48)
    //     0xb6f444: sub             SP, SP, #0x48
    // 0xb6f448: SetupParameters(TweenSequence<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb6f448: mov             x4, x1
    //     0xb6f44c: mov             x0, x2
    //     0xb6f450: stur            x1, [fp, #-8]
    //     0xb6f454: stur            x2, [fp, #-0x10]
    // 0xb6f458: CheckStackOverflow
    //     0xb6f458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6f45c: cmp             SP, x16
    //     0xb6f460: b.ls            #0xb6f678
    // 0xb6f464: LoadField: r2 = r4->field_7
    //     0xb6f464: ldur            w2, [x4, #7]
    // 0xb6f468: DecompressPointer r2
    //     0xb6f468: add             x2, x2, HEAP, lsl #32
    // 0xb6f46c: r1 = Null
    //     0xb6f46c: mov             x1, NULL
    // 0xb6f470: r3 = <TweenSequenceItem<X0>>
    //     0xb6f470: add             x3, PP, #0x99, lsl #12  ; [pp+0x99600] TypeArguments: <TweenSequenceItem<X0>>
    //     0xb6f474: ldr             x3, [x3, #0x600]
    // 0xb6f478: r30 = InstantiateTypeArgumentsStub
    //     0xb6f478: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xb6f47c: LoadField: r30 = r30->field_7
    //     0xb6f47c: ldur            lr, [lr, #7]
    // 0xb6f480: blr             lr
    // 0xb6f484: mov             x1, x0
    // 0xb6f488: r2 = 0
    //     0xb6f488: mov             x2, #0
    // 0xb6f48c: r0 = _GrowableList()
    //     0xb6f48c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb6f490: mov             x4, x0
    // 0xb6f494: ldur            x3, [fp, #-8]
    // 0xb6f498: stur            x4, [fp, #-0x18]
    // 0xb6f49c: StoreField: r3->field_b = r0
    //     0xb6f49c: stur            w0, [x3, #0xb]
    //     0xb6f4a0: ldurb           w16, [x3, #-1]
    //     0xb6f4a4: ldurb           w17, [x0, #-1]
    //     0xb6f4a8: and             x16, x17, x16, lsr #2
    //     0xb6f4ac: tst             x16, HEAP, lsr #32
    //     0xb6f4b0: b.eq            #0xb6f4b8
    //     0xb6f4b4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb6f4b8: r1 = <_Interval>
    //     0xb6f4b8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99608] TypeArguments: <_Interval>
    //     0xb6f4bc: ldr             x1, [x1, #0x608]
    // 0xb6f4c0: r2 = 0
    //     0xb6f4c0: mov             x2, #0
    // 0xb6f4c4: r0 = _GrowableList()
    //     0xb6f4c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb6f4c8: mov             x3, x0
    // 0xb6f4cc: ldur            x1, [fp, #-8]
    // 0xb6f4d0: stur            x3, [fp, #-0x20]
    // 0xb6f4d4: StoreField: r1->field_f = r0
    //     0xb6f4d4: stur            w0, [x1, #0xf]
    //     0xb6f4d8: ldurb           w16, [x1, #-1]
    //     0xb6f4dc: ldurb           w17, [x0, #-1]
    //     0xb6f4e0: and             x16, x17, x16, lsr #2
    //     0xb6f4e4: tst             x16, HEAP, lsr #32
    //     0xb6f4e8: b.eq            #0xb6f4f0
    //     0xb6f4ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb6f4f0: ldur            x1, [fp, #-0x18]
    // 0xb6f4f4: ldur            x2, [fp, #-0x10]
    // 0xb6f4f8: r0 = addAll()
    //     0xb6f4f8: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xb6f4fc: ldur            x0, [fp, #-0x18]
    // 0xb6f500: LoadField: r1 = r0->field_b
    //     0xb6f500: ldur            w1, [x0, #0xb]
    // 0xb6f504: r2 = LoadInt32Instr(r1)
    //     0xb6f504: sbfx            x2, x1, #1, #0x1f
    // 0xb6f508: LoadField: r1 = r0->field_f
    //     0xb6f508: ldur            w1, [x0, #0xf]
    // 0xb6f50c: DecompressPointer r1
    //     0xb6f50c: add             x1, x1, HEAP, lsl #32
    // 0xb6f510: d0 = 0.000000
    //     0xb6f510: eor             v0.16b, v0.16b, v0.16b
    // 0xb6f514: r3 = 0
    //     0xb6f514: mov             x3, #0
    // 0xb6f518: stur            d0, [fp, #-0x48]
    // 0xb6f51c: CheckStackOverflow
    //     0xb6f51c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6f520: cmp             SP, x16
    //     0xb6f524: b.ls            #0xb6f680
    // 0xb6f528: cmp             x3, x2
    // 0xb6f52c: b.ge            #0xb6f554
    // 0xb6f530: ArrayLoad: r4 = r1[r3]  ; Unknown_4
    //     0xb6f530: add             x16, x1, x3, lsl #2
    //     0xb6f534: ldur            w4, [x16, #0xf]
    // 0xb6f538: DecompressPointer r4
    //     0xb6f538: add             x4, x4, HEAP, lsl #32
    // 0xb6f53c: add             x5, x3, #1
    // 0xb6f540: LoadField: d1 = r4->field_f
    //     0xb6f540: ldur            d1, [x4, #0xf]
    // 0xb6f544: fadd            d2, d0, d1
    // 0xb6f548: mov             v0.16b, v2.16b
    // 0xb6f54c: mov             x3, x5
    // 0xb6f550: b               #0xb6f518
    // 0xb6f554: ldur            x1, [fp, #-0x20]
    // 0xb6f558: d1 = 0.000000
    //     0xb6f558: eor             v1.16b, v1.16b, v1.16b
    // 0xb6f55c: r2 = 0
    //     0xb6f55c: mov             x2, #0
    // 0xb6f560: stur            x2, [fp, #-0x28]
    // 0xb6f564: stur            d1, [fp, #-0x40]
    // 0xb6f568: CheckStackOverflow
    //     0xb6f568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6f56c: cmp             SP, x16
    //     0xb6f570: b.ls            #0xb6f688
    // 0xb6f574: LoadField: r3 = r0->field_b
    //     0xb6f574: ldur            w3, [x0, #0xb]
    // 0xb6f578: r4 = LoadInt32Instr(r3)
    //     0xb6f578: sbfx            x4, x3, #1, #0x1f
    // 0xb6f57c: cmp             x2, x4
    // 0xb6f580: b.ge            #0xb6f668
    // 0xb6f584: sub             x3, x4, #1
    // 0xb6f588: cmp             x2, x3
    // 0xb6f58c: b.ne            #0xb6f598
    // 0xb6f590: d2 = 1.000000
    //     0xb6f590: fmov            d2, #1.00000000
    // 0xb6f594: b               #0xb6f5b8
    // 0xb6f598: LoadField: r3 = r0->field_f
    //     0xb6f598: ldur            w3, [x0, #0xf]
    // 0xb6f59c: DecompressPointer r3
    //     0xb6f59c: add             x3, x3, HEAP, lsl #32
    // 0xb6f5a0: ArrayLoad: r4 = r3[r2]  ; Unknown_4
    //     0xb6f5a0: add             x16, x3, x2, lsl #2
    //     0xb6f5a4: ldur            w4, [x16, #0xf]
    // 0xb6f5a8: DecompressPointer r4
    //     0xb6f5a8: add             x4, x4, HEAP, lsl #32
    // 0xb6f5ac: LoadField: d2 = r4->field_f
    //     0xb6f5ac: ldur            d2, [x4, #0xf]
    // 0xb6f5b0: fdiv            d3, d2, d0
    // 0xb6f5b4: fadd            d2, d1, d3
    // 0xb6f5b8: stur            d2, [fp, #-0x38]
    // 0xb6f5bc: r0 = _Interval()
    //     0xb6f5bc: bl              #0xb6f690  ; Allocate_IntervalStub -> _Interval (size=0x18)
    // 0xb6f5c0: ldur            d0, [fp, #-0x40]
    // 0xb6f5c4: stur            x0, [fp, #-8]
    // 0xb6f5c8: StoreField: r0->field_7 = d0
    //     0xb6f5c8: stur            d0, [x0, #7]
    // 0xb6f5cc: ldur            d1, [fp, #-0x38]
    // 0xb6f5d0: StoreField: r0->field_f = d1
    //     0xb6f5d0: stur            d1, [x0, #0xf]
    // 0xb6f5d4: ldur            x2, [fp, #-0x20]
    // 0xb6f5d8: LoadField: r1 = r2->field_b
    //     0xb6f5d8: ldur            w1, [x2, #0xb]
    // 0xb6f5dc: LoadField: r3 = r2->field_f
    //     0xb6f5dc: ldur            w3, [x2, #0xf]
    // 0xb6f5e0: DecompressPointer r3
    //     0xb6f5e0: add             x3, x3, HEAP, lsl #32
    // 0xb6f5e4: LoadField: r4 = r3->field_b
    //     0xb6f5e4: ldur            w4, [x3, #0xb]
    // 0xb6f5e8: r3 = LoadInt32Instr(r1)
    //     0xb6f5e8: sbfx            x3, x1, #1, #0x1f
    // 0xb6f5ec: stur            x3, [fp, #-0x30]
    // 0xb6f5f0: r1 = LoadInt32Instr(r4)
    //     0xb6f5f0: sbfx            x1, x4, #1, #0x1f
    // 0xb6f5f4: cmp             x3, x1
    // 0xb6f5f8: b.ne            #0xb6f604
    // 0xb6f5fc: mov             x1, x2
    // 0xb6f600: r0 = _growToNextCapacity()
    //     0xb6f600: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb6f604: ldur            x3, [fp, #-0x20]
    // 0xb6f608: ldur            x4, [fp, #-0x28]
    // 0xb6f60c: ldur            x2, [fp, #-0x30]
    // 0xb6f610: add             x5, x2, #1
    // 0xb6f614: lsl             x6, x5, #1
    // 0xb6f618: StoreField: r3->field_b = r6
    //     0xb6f618: stur            w6, [x3, #0xb]
    // 0xb6f61c: LoadField: r1 = r3->field_f
    //     0xb6f61c: ldur            w1, [x3, #0xf]
    // 0xb6f620: DecompressPointer r1
    //     0xb6f620: add             x1, x1, HEAP, lsl #32
    // 0xb6f624: ldur            x0, [fp, #-8]
    // 0xb6f628: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb6f628: add             x25, x1, x2, lsl #2
    //     0xb6f62c: add             x25, x25, #0xf
    //     0xb6f630: str             w0, [x25]
    //     0xb6f634: tbz             w0, #0, #0xb6f650
    //     0xb6f638: ldurb           w16, [x1, #-1]
    //     0xb6f63c: ldurb           w17, [x0, #-1]
    //     0xb6f640: and             x16, x17, x16, lsr #2
    //     0xb6f644: tst             x16, HEAP, lsr #32
    //     0xb6f648: b.eq            #0xb6f650
    //     0xb6f64c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb6f650: add             x2, x4, #1
    // 0xb6f654: ldur            d1, [fp, #-0x38]
    // 0xb6f658: ldur            x0, [fp, #-0x18]
    // 0xb6f65c: mov             x1, x3
    // 0xb6f660: ldur            d0, [fp, #-0x48]
    // 0xb6f664: b               #0xb6f560
    // 0xb6f668: r0 = Null
    //     0xb6f668: mov             x0, NULL
    // 0xb6f66c: LeaveFrame
    //     0xb6f66c: mov             SP, fp
    //     0xb6f670: ldp             fp, lr, [SP], #0x10
    // 0xb6f674: ret
    //     0xb6f674: ret             
    // 0xb6f678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6f678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6f67c: b               #0xb6f464
    // 0xb6f680: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6f680: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6f684: b               #0xb6f528
    // 0xb6f688: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6f688: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6f68c: b               #0xb6f574
  }
  _ transform(/* No info */) {
    // ** addr: 0x1103cd8, size: 0x198
    // 0x1103cd8: EnterFrame
    //     0x1103cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x1103cdc: mov             fp, SP
    // 0x1103ce0: AllocStack(0x18)
    //     0x1103ce0: sub             SP, SP, #0x18
    // 0x1103ce4: d1 = 1.000000
    //     0x1103ce4: fmov            d1, #1.00000000
    // 0x1103ce8: mov             x2, x1
    // 0x1103cec: stur            d0, [fp, #-0x10]
    // 0x1103cf0: CheckStackOverflow
    //     0x1103cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103cf4: cmp             SP, x16
    //     0x1103cf8: b.ls            #0x1103e40
    // 0x1103cfc: fcmp            d0, d1
    // 0x1103d00: b.ne            #0x1103d34
    // 0x1103d04: LoadField: r0 = r2->field_b
    //     0x1103d04: ldur            w0, [x2, #0xb]
    // 0x1103d08: DecompressPointer r0
    //     0x1103d08: add             x0, x0, HEAP, lsl #32
    // 0x1103d0c: LoadField: r1 = r0->field_b
    //     0x1103d0c: ldur            w1, [x0, #0xb]
    // 0x1103d10: r0 = LoadInt32Instr(r1)
    //     0x1103d10: sbfx            x0, x1, #1, #0x1f
    // 0x1103d14: sub             x1, x0, #1
    // 0x1103d18: mov             x16, x1
    // 0x1103d1c: mov             x1, x2
    // 0x1103d20: mov             x2, x16
    // 0x1103d24: r0 = _evaluateAt()
    //     0x1103d24: bl              #0x1103e70  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::_evaluateAt
    // 0x1103d28: LeaveFrame
    //     0x1103d28: mov             SP, fp
    //     0x1103d2c: ldp             fp, lr, [SP], #0x10
    // 0x1103d30: ret
    //     0x1103d30: ret             
    // 0x1103d34: LoadField: r0 = r2->field_b
    //     0x1103d34: ldur            w0, [x2, #0xb]
    // 0x1103d38: DecompressPointer r0
    //     0x1103d38: add             x0, x0, HEAP, lsl #32
    // 0x1103d3c: LoadField: r1 = r0->field_b
    //     0x1103d3c: ldur            w1, [x0, #0xb]
    // 0x1103d40: r3 = LoadInt32Instr(r1)
    //     0x1103d40: sbfx            x3, x1, #1, #0x1f
    // 0x1103d44: LoadField: r0 = r2->field_f
    //     0x1103d44: ldur            w0, [x2, #0xf]
    // 0x1103d48: DecompressPointer r0
    //     0x1103d48: add             x0, x0, HEAP, lsl #32
    // 0x1103d4c: LoadField: r1 = r0->field_b
    //     0x1103d4c: ldur            w1, [x0, #0xb]
    // 0x1103d50: r4 = LoadInt32Instr(r1)
    //     0x1103d50: sbfx            x4, x1, #1, #0x1f
    // 0x1103d54: LoadField: r5 = r0->field_f
    //     0x1103d54: ldur            w5, [x0, #0xf]
    // 0x1103d58: DecompressPointer r5
    //     0x1103d58: add             x5, x5, HEAP, lsl #32
    // 0x1103d5c: r6 = 0
    //     0x1103d5c: mov             x6, #0
    // 0x1103d60: CheckStackOverflow
    //     0x1103d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103d64: cmp             SP, x16
    //     0x1103d68: b.ls            #0x1103e48
    // 0x1103d6c: cmp             x6, x3
    // 0x1103d70: b.ge            #0x1103dcc
    // 0x1103d74: mov             x0, x4
    // 0x1103d78: mov             x1, x6
    // 0x1103d7c: cmp             x1, x0
    // 0x1103d80: b.hs            #0x1103e50
    // 0x1103d84: ArrayLoad: r0 = r5[r6]  ; Unknown_4
    //     0x1103d84: add             x16, x5, x6, lsl #2
    //     0x1103d88: ldur            w0, [x16, #0xf]
    // 0x1103d8c: DecompressPointer r0
    //     0x1103d8c: add             x0, x0, HEAP, lsl #32
    // 0x1103d90: LoadField: d1 = r0->field_7
    //     0x1103d90: ldur            d1, [x0, #7]
    // 0x1103d94: fcmp            d0, d1
    // 0x1103d98: b.lt            #0x1103dc0
    // 0x1103d9c: LoadField: d1 = r0->field_f
    //     0x1103d9c: ldur            d1, [x0, #0xf]
    // 0x1103da0: fcmp            d1, d0
    // 0x1103da4: b.le            #0x1103dc0
    // 0x1103da8: mov             x1, x2
    // 0x1103dac: mov             x2, x6
    // 0x1103db0: r0 = _evaluateAt()
    //     0x1103db0: bl              #0x1103e70  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::_evaluateAt
    // 0x1103db4: LeaveFrame
    //     0x1103db4: mov             SP, fp
    //     0x1103db8: ldp             fp, lr, [SP], #0x10
    // 0x1103dbc: ret
    //     0x1103dbc: ret             
    // 0x1103dc0: add             x0, x6, #1
    // 0x1103dc4: mov             x6, x0
    // 0x1103dc8: b               #0x1103d60
    // 0x1103dcc: r1 = Null
    //     0x1103dcc: mov             x1, NULL
    // 0x1103dd0: r2 = 4
    //     0x1103dd0: mov             x2, #4
    // 0x1103dd4: r0 = AllocateArray()
    //     0x1103dd4: bl              #0x13df928  ; AllocateArrayStub
    // 0x1103dd8: r16 = "TweenSequence.evaluate() could not find an interval for "
    //     0x1103dd8: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1078] "TweenSequence.evaluate() could not find an interval for "
    //     0x1103ddc: ldr             x16, [x16, #0x78]
    // 0x1103de0: StoreField: r0->field_f = r16
    //     0x1103de0: stur            w16, [x0, #0xf]
    // 0x1103de4: ldur            d0, [fp, #-0x10]
    // 0x1103de8: r1 = inline_Allocate_Double()
    //     0x1103de8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x1103dec: add             x1, x1, #0x10
    //     0x1103df0: cmp             x2, x1
    //     0x1103df4: b.ls            #0x1103e54
    //     0x1103df8: str             x1, [THR, #0x60]  ; THR::top
    //     0x1103dfc: sub             x1, x1, #0xf
    //     0x1103e00: mov             x2, #0xe19c
    //     0x1103e04: movk            x2, #3, lsl #16
    //     0x1103e08: stur            x2, [x1, #-1]
    // 0x1103e0c: dmb             ishst
    // 0x1103e10: StoreField: r1->field_7 = d0
    //     0x1103e10: stur            d0, [x1, #7]
    // 0x1103e14: StoreField: r0->field_13 = r1
    //     0x1103e14: stur            w1, [x0, #0x13]
    // 0x1103e18: str             x0, [SP]
    // 0x1103e1c: r0 = _interpolate()
    //     0x1103e1c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1103e20: stur            x0, [fp, #-8]
    // 0x1103e24: r0 = StateError()
    //     0x1103e24: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1103e28: mov             x1, x0
    // 0x1103e2c: ldur            x0, [fp, #-8]
    // 0x1103e30: StoreField: r1->field_b = r0
    //     0x1103e30: stur            w0, [x1, #0xb]
    // 0x1103e34: mov             x0, x1
    // 0x1103e38: r0 = Throw()
    //     0x1103e38: bl              #0x13ddb2c  ; ThrowStub
    // 0x1103e3c: brk             #0
    // 0x1103e40: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103e40: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103e44: b               #0x1103cfc
    // 0x1103e48: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103e48: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103e4c: b               #0x1103d6c
    // 0x1103e50: r0 = RangeErrorSharedWithFPURegs()
    //     0x1103e50: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x1103e54: SaveReg d0
    //     0x1103e54: str             q0, [SP, #-0x10]!
    // 0x1103e58: SaveReg r0
    //     0x1103e58: str             x0, [SP, #-8]!
    // 0x1103e5c: r0 = AllocateDouble()
    //     0x1103e5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1103e60: mov             x1, x0
    // 0x1103e64: RestoreReg r0
    //     0x1103e64: ldr             x0, [SP], #8
    // 0x1103e68: RestoreReg d0
    //     0x1103e68: ldr             q0, [SP], #0x10
    // 0x1103e6c: b               #0x1103e10
  }
  _ _evaluateAt(/* No info */) {
    // ** addr: 0x1103e70, size: 0xd0
    // 0x1103e70: EnterFrame
    //     0x1103e70: stp             fp, lr, [SP, #-0x10]!
    //     0x1103e74: mov             fp, SP
    // 0x1103e78: mov             x3, x1
    // 0x1103e7c: CheckStackOverflow
    //     0x1103e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103e80: cmp             SP, x16
    //     0x1103e84: b.ls            #0x1103f30
    // 0x1103e88: LoadField: r4 = r3->field_b
    //     0x1103e88: ldur            w4, [x3, #0xb]
    // 0x1103e8c: DecompressPointer r4
    //     0x1103e8c: add             x4, x4, HEAP, lsl #32
    // 0x1103e90: LoadField: r0 = r4->field_b
    //     0x1103e90: ldur            w0, [x4, #0xb]
    // 0x1103e94: r1 = LoadInt32Instr(r0)
    //     0x1103e94: sbfx            x1, x0, #1, #0x1f
    // 0x1103e98: mov             x0, x1
    // 0x1103e9c: mov             x1, x2
    // 0x1103ea0: cmp             x1, x0
    // 0x1103ea4: b.hs            #0x1103f38
    // 0x1103ea8: LoadField: r0 = r4->field_f
    //     0x1103ea8: ldur            w0, [x4, #0xf]
    // 0x1103eac: DecompressPointer r0
    //     0x1103eac: add             x0, x0, HEAP, lsl #32
    // 0x1103eb0: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0x1103eb0: add             x16, x0, x2, lsl #2
    //     0x1103eb4: ldur            w4, [x16, #0xf]
    // 0x1103eb8: DecompressPointer r4
    //     0x1103eb8: add             x4, x4, HEAP, lsl #32
    // 0x1103ebc: LoadField: r5 = r3->field_f
    //     0x1103ebc: ldur            w5, [x3, #0xf]
    // 0x1103ec0: DecompressPointer r5
    //     0x1103ec0: add             x5, x5, HEAP, lsl #32
    // 0x1103ec4: LoadField: r0 = r5->field_b
    //     0x1103ec4: ldur            w0, [x5, #0xb]
    // 0x1103ec8: r1 = LoadInt32Instr(r0)
    //     0x1103ec8: sbfx            x1, x0, #1, #0x1f
    // 0x1103ecc: mov             x0, x1
    // 0x1103ed0: mov             x1, x2
    // 0x1103ed4: cmp             x1, x0
    // 0x1103ed8: b.hs            #0x1103f3c
    // 0x1103edc: LoadField: r0 = r5->field_f
    //     0x1103edc: ldur            w0, [x5, #0xf]
    // 0x1103ee0: DecompressPointer r0
    //     0x1103ee0: add             x0, x0, HEAP, lsl #32
    // 0x1103ee4: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x1103ee4: add             x16, x0, x2, lsl #2
    //     0x1103ee8: ldur            w1, [x16, #0xf]
    // 0x1103eec: DecompressPointer r1
    //     0x1103eec: add             x1, x1, HEAP, lsl #32
    // 0x1103ef0: LoadField: d1 = r1->field_7
    //     0x1103ef0: ldur            d1, [x1, #7]
    // 0x1103ef4: fsub            d2, d0, d1
    // 0x1103ef8: LoadField: d0 = r1->field_f
    //     0x1103ef8: ldur            d0, [x1, #0xf]
    // 0x1103efc: fsub            d3, d0, d1
    // 0x1103f00: fdiv            d0, d2, d3
    // 0x1103f04: LoadField: r1 = r4->field_b
    //     0x1103f04: ldur            w1, [x4, #0xb]
    // 0x1103f08: DecompressPointer r1
    //     0x1103f08: add             x1, x1, HEAP, lsl #32
    // 0x1103f0c: r0 = LoadClassIdInstr(r1)
    //     0x1103f0c: ldur            x0, [x1, #-1]
    //     0x1103f10: ubfx            x0, x0, #0xc, #0x14
    // 0x1103f14: r0 = GDT[cid_x0 + 0xa1d0]()
    //     0x1103f14: mov             x17, #0xa1d0
    //     0x1103f18: add             lr, x0, x17
    //     0x1103f1c: ldr             lr, [x21, lr, lsl #3]
    //     0x1103f20: blr             lr
    // 0x1103f24: LeaveFrame
    //     0x1103f24: mov             SP, fp
    //     0x1103f28: ldp             fp, lr, [SP], #0x10
    // 0x1103f2c: ret
    //     0x1103f2c: ret             
    // 0x1103f30: r0 = StackOverflowSharedWithFPURegs()
    //     0x1103f30: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1103f34: b               #0x1103e88
    // 0x1103f38: r0 = RangeErrorSharedWithFPURegs()
    //     0x1103f38: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x1103f3c: r0 = RangeErrorSharedWithFPURegs()
    //     0x1103f3c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
}
