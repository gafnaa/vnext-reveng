// lib: , url: package:flutter/src/animation/animation.dart

// class id: 1048761, size: 0x8
class :: {
}

// class id: 4353, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Animation<X0> extends Listenable
    implements ValueListenable<X0> {

  get _ isCompleted(/* No info */) {
    // ** addr: 0x874e00, size: 0x54
    // 0x874e00: EnterFrame
    //     0x874e00: stp             fp, lr, [SP, #-0x10]!
    //     0x874e04: mov             fp, SP
    // 0x874e08: CheckStackOverflow
    //     0x874e08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874e0c: cmp             SP, x16
    //     0x874e10: b.ls            #0x874e4c
    // 0x874e14: r0 = LoadClassIdInstr(r1)
    //     0x874e14: ldur            x0, [x1, #-1]
    //     0x874e18: ubfx            x0, x0, #0xc, #0x14
    // 0x874e1c: r0 = GDT[cid_x0 + -0x52]()
    //     0x874e1c: sub             lr, x0, #0x52
    //     0x874e20: ldr             lr, [x21, lr, lsl #3]
    //     0x874e24: blr             lr
    // 0x874e28: r16 = Instance_AnimationStatus
    //     0x874e28: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x874e2c: cmp             w0, w16
    // 0x874e30: r16 = true
    //     0x874e30: add             x16, NULL, #0x20  ; true
    // 0x874e34: r17 = false
    //     0x874e34: add             x17, NULL, #0x30  ; false
    // 0x874e38: csel            x1, x16, x17, eq
    // 0x874e3c: mov             x0, x1
    // 0x874e40: LeaveFrame
    //     0x874e40: mov             SP, fp
    //     0x874e44: ldp             fp, lr, [SP], #0x10
    // 0x874e48: ret
    //     0x874e48: ret             
    // 0x874e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874e50: b               #0x874e14
  }
  get _ isAnimating(/* No info */) {
    // ** addr: 0xb293f4, size: 0x80
    // 0xb293f4: EnterFrame
    //     0xb293f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb293f8: mov             fp, SP
    // 0xb293fc: CheckStackOverflow
    //     0xb293fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29400: cmp             SP, x16
    //     0xb29404: b.ls            #0xb2946c
    // 0xb29408: r0 = LoadClassIdInstr(r1)
    //     0xb29408: ldur            x0, [x1, #-1]
    //     0xb2940c: ubfx            x0, x0, #0xc, #0x14
    // 0xb29410: r0 = GDT[cid_x0 + -0x52]()
    //     0xb29410: sub             lr, x0, #0x52
    //     0xb29414: ldr             lr, [x21, lr, lsl #3]
    //     0xb29418: blr             lr
    // 0xb2941c: r16 = Instance_AnimationStatus
    //     0xb2941c: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xb29420: cmp             w0, w16
    // 0xb29424: b.eq            #0xb29434
    // 0xb29428: r16 = Instance_AnimationStatus
    //     0xb29428: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xb2942c: cmp             w0, w16
    // 0xb29430: b.ne            #0xb2943c
    // 0xb29434: r0 = true
    //     0xb29434: add             x0, NULL, #0x20  ; true
    // 0xb29438: b               #0xb29460
    // 0xb2943c: r16 = Instance_AnimationStatus
    //     0xb2943c: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb29440: cmp             w0, w16
    // 0xb29444: b.eq            #0xb29454
    // 0xb29448: r16 = Instance_AnimationStatus
    //     0xb29448: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb2944c: cmp             w0, w16
    // 0xb29450: b.ne            #0xb2945c
    // 0xb29454: r0 = false
    //     0xb29454: add             x0, NULL, #0x30  ; false
    // 0xb29458: b               #0xb29460
    // 0xb2945c: r0 = Null
    //     0xb2945c: mov             x0, NULL
    // 0xb29460: LeaveFrame
    //     0xb29460: mov             SP, fp
    //     0xb29464: ldp             fp, lr, [SP], #0x10
    // 0xb29468: ret
    //     0xb29468: ret             
    // 0xb2946c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2946c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29470: b               #0xb29408
  }
  get _ isDismissed(/* No info */) {
    // ** addr: 0xb6c464, size: 0x54
    // 0xb6c464: EnterFrame
    //     0xb6c464: stp             fp, lr, [SP, #-0x10]!
    //     0xb6c468: mov             fp, SP
    // 0xb6c46c: CheckStackOverflow
    //     0xb6c46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6c470: cmp             SP, x16
    //     0xb6c474: b.ls            #0xb6c4b0
    // 0xb6c478: r0 = LoadClassIdInstr(r1)
    //     0xb6c478: ldur            x0, [x1, #-1]
    //     0xb6c47c: ubfx            x0, x0, #0xc, #0x14
    // 0xb6c480: r0 = GDT[cid_x0 + -0x52]()
    //     0xb6c480: sub             lr, x0, #0x52
    //     0xb6c484: ldr             lr, [x21, lr, lsl #3]
    //     0xb6c488: blr             lr
    // 0xb6c48c: r16 = Instance_AnimationStatus
    //     0xb6c48c: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6c490: cmp             w0, w16
    // 0xb6c494: r16 = true
    //     0xb6c494: add             x16, NULL, #0x20  ; true
    // 0xb6c498: r17 = false
    //     0xb6c498: add             x17, NULL, #0x30  ; false
    // 0xb6c49c: csel            x1, x16, x17, eq
    // 0xb6c4a0: mov             x0, x1
    // 0xb6c4a4: LeaveFrame
    //     0xb6c4a4: mov             SP, fp
    //     0xb6c4a8: ldp             fp, lr, [SP], #0x10
    // 0xb6c4ac: ret
    //     0xb6c4ac: ret             
    // 0xb6c4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6c4b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6c4b4: b               #0xb6c478
  }
  get _ isForwardOrCompleted(/* No info */) {
    // ** addr: 0xbadc14, size: 0x80
    // 0xbadc14: EnterFrame
    //     0xbadc14: stp             fp, lr, [SP, #-0x10]!
    //     0xbadc18: mov             fp, SP
    // 0xbadc1c: CheckStackOverflow
    //     0xbadc1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbadc20: cmp             SP, x16
    //     0xbadc24: b.ls            #0xbadc8c
    // 0xbadc28: r0 = LoadClassIdInstr(r1)
    //     0xbadc28: ldur            x0, [x1, #-1]
    //     0xbadc2c: ubfx            x0, x0, #0xc, #0x14
    // 0xbadc30: r0 = GDT[cid_x0 + -0x52]()
    //     0xbadc30: sub             lr, x0, #0x52
    //     0xbadc34: ldr             lr, [x21, lr, lsl #3]
    //     0xbadc38: blr             lr
    // 0xbadc3c: r16 = Instance_AnimationStatus
    //     0xbadc3c: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xbadc40: cmp             w0, w16
    // 0xbadc44: b.eq            #0xbadc54
    // 0xbadc48: r16 = Instance_AnimationStatus
    //     0xbadc48: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xbadc4c: cmp             w0, w16
    // 0xbadc50: b.ne            #0xbadc5c
    // 0xbadc54: r0 = true
    //     0xbadc54: add             x0, NULL, #0x20  ; true
    // 0xbadc58: b               #0xbadc80
    // 0xbadc5c: r16 = Instance_AnimationStatus
    //     0xbadc5c: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xbadc60: cmp             w0, w16
    // 0xbadc64: b.eq            #0xbadc74
    // 0xbadc68: r16 = Instance_AnimationStatus
    //     0xbadc68: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xbadc6c: cmp             w0, w16
    // 0xbadc70: b.ne            #0xbadc7c
    // 0xbadc74: r0 = false
    //     0xbadc74: add             x0, NULL, #0x30  ; false
    // 0xbadc78: b               #0xbadc80
    // 0xbadc7c: r0 = Null
    //     0xbadc7c: mov             x0, NULL
    // 0xbadc80: LeaveFrame
    //     0xbadc80: mov             SP, fp
    //     0xbadc84: ldp             fp, lr, [SP], #0x10
    // 0xbadc88: ret
    //     0xbadc88: ret             
    // 0xbadc8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbadc8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbadc90: b               #0xbadc28
  }
}

// class id: 8324, size: 0x14, field offset: 0x14
enum AnimationStatus extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a94dc, size: 0x64
    // 0x11a94dc: EnterFrame
    //     0x11a94dc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a94e0: mov             fp, SP
    // 0x11a94e4: AllocStack(0x10)
    //     0x11a94e4: sub             SP, SP, #0x10
    // 0x11a94e8: SetupParameters(AnimationStatus this /* r1 => r0, fp-0x8 */)
    //     0x11a94e8: mov             x0, x1
    //     0x11a94ec: stur            x1, [fp, #-8]
    // 0x11a94f0: CheckStackOverflow
    //     0x11a94f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a94f4: cmp             SP, x16
    //     0x11a94f8: b.ls            #0x11a9538
    // 0x11a94fc: r1 = Null
    //     0x11a94fc: mov             x1, NULL
    // 0x11a9500: r2 = 4
    //     0x11a9500: mov             x2, #4
    // 0x11a9504: r0 = AllocateArray()
    //     0x11a9504: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9508: r16 = "AnimationStatus."
    //     0x11a9508: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e28] "AnimationStatus."
    //     0x11a950c: ldr             x16, [x16, #0xe28]
    // 0x11a9510: StoreField: r0->field_f = r16
    //     0x11a9510: stur            w16, [x0, #0xf]
    // 0x11a9514: ldur            x1, [fp, #-8]
    // 0x11a9518: LoadField: r2 = r1->field_f
    //     0x11a9518: ldur            w2, [x1, #0xf]
    // 0x11a951c: DecompressPointer r2
    //     0x11a951c: add             x2, x2, HEAP, lsl #32
    // 0x11a9520: StoreField: r0->field_13 = r2
    //     0x11a9520: stur            w2, [x0, #0x13]
    // 0x11a9524: str             x0, [SP]
    // 0x11a9528: r0 = _interpolate()
    //     0x11a9528: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a952c: LeaveFrame
    //     0x11a952c: mov             SP, fp
    //     0x11a9530: ldp             fp, lr, [SP], #0x10
    // 0x11a9534: ret
    //     0x11a9534: ret             
    // 0x11a9538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a953c: b               #0x11a94fc
  }
}
