// lib: , url: package:flutter/src/animation/animation_style.dart

// class id: 1048763, size: 0x8
class :: {
}

// class id: 5242, size: 0x18, field offset: 0x8
//   const constructor, 
class AnimationStyle extends _MixinApplication3&Object&Diagnosticable {

  Cubic field_8;
  Duration field_c;
  Duration field_14;

  _ ==(/* No info */) {
    // ** addr: 0x1262878, size: 0x158
    // 0x1262878: EnterFrame
    //     0x1262878: stp             fp, lr, [SP, #-0x10]!
    //     0x126287c: mov             fp, SP
    // 0x1262880: AllocStack(0x10)
    //     0x1262880: sub             SP, SP, #0x10
    // 0x1262884: CheckStackOverflow
    //     0x1262884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1262888: cmp             SP, x16
    //     0x126288c: b.ls            #0x12629c8
    // 0x1262890: ldr             x0, [fp, #0x10]
    // 0x1262894: cmp             w0, NULL
    // 0x1262898: b.ne            #0x12628ac
    // 0x126289c: r0 = false
    //     0x126289c: add             x0, NULL, #0x30  ; false
    // 0x12628a0: LeaveFrame
    //     0x12628a0: mov             SP, fp
    //     0x12628a4: ldp             fp, lr, [SP], #0x10
    // 0x12628a8: ret
    //     0x12628a8: ret             
    // 0x12628ac: ldr             x1, [fp, #0x18]
    // 0x12628b0: cmp             w1, w0
    // 0x12628b4: b.ne            #0x12628c8
    // 0x12628b8: r0 = true
    //     0x12628b8: add             x0, NULL, #0x20  ; true
    // 0x12628bc: LeaveFrame
    //     0x12628bc: mov             SP, fp
    //     0x12628c0: ldp             fp, lr, [SP], #0x10
    // 0x12628c4: ret
    //     0x12628c4: ret             
    // 0x12628c8: str             x0, [SP]
    // 0x12628cc: r0 = runtimeType()
    //     0x12628cc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12628d0: r1 = LoadClassIdInstr(r0)
    //     0x12628d0: ldur            x1, [x0, #-1]
    //     0x12628d4: ubfx            x1, x1, #0xc, #0x14
    // 0x12628d8: r16 = AnimationStyle
    //     0x12628d8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb58] Type: AnimationStyle
    //     0x12628dc: ldr             x16, [x16, #0xb58]
    // 0x12628e0: stp             x16, x0, [SP]
    // 0x12628e4: mov             x0, x1
    // 0x12628e8: mov             lr, x0
    // 0x12628ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12628f0: blr             lr
    // 0x12628f4: tbz             w0, #4, #0x1262908
    // 0x12628f8: r0 = false
    //     0x12628f8: add             x0, NULL, #0x30  ; false
    // 0x12628fc: LeaveFrame
    //     0x12628fc: mov             SP, fp
    //     0x1262900: ldp             fp, lr, [SP], #0x10
    // 0x1262904: ret
    //     0x1262904: ret             
    // 0x1262908: ldr             x1, [fp, #0x10]
    // 0x126290c: r0 = 60
    //     0x126290c: mov             x0, #0x3c
    // 0x1262910: branchIfSmi(r1, 0x126291c)
    //     0x1262910: tbz             w1, #0, #0x126291c
    // 0x1262914: r0 = LoadClassIdInstr(r1)
    //     0x1262914: ldur            x0, [x1, #-1]
    //     0x1262918: ubfx            x0, x0, #0xc, #0x14
    // 0x126291c: r17 = 5242
    //     0x126291c: mov             x17, #0x147a
    // 0x1262920: cmp             x0, x17
    // 0x1262924: b.ne            #0x12629b8
    // 0x1262928: ldr             x2, [fp, #0x18]
    // 0x126292c: LoadField: r0 = r1->field_7
    //     0x126292c: ldur            w0, [x1, #7]
    // 0x1262930: DecompressPointer r0
    //     0x1262930: add             x0, x0, HEAP, lsl #32
    // 0x1262934: LoadField: r3 = r2->field_7
    //     0x1262934: ldur            w3, [x2, #7]
    // 0x1262938: DecompressPointer r3
    //     0x1262938: add             x3, x3, HEAP, lsl #32
    // 0x126293c: r4 = LoadClassIdInstr(r0)
    //     0x126293c: ldur            x4, [x0, #-1]
    //     0x1262940: ubfx            x4, x4, #0xc, #0x14
    // 0x1262944: stp             x3, x0, [SP]
    // 0x1262948: mov             x0, x4
    // 0x126294c: mov             lr, x0
    // 0x1262950: ldr             lr, [x21, lr, lsl #3]
    // 0x1262954: blr             lr
    // 0x1262958: tbnz            w0, #4, #0x12629b8
    // 0x126295c: ldr             x1, [fp, #0x18]
    // 0x1262960: ldr             x0, [fp, #0x10]
    // 0x1262964: LoadField: r2 = r0->field_b
    //     0x1262964: ldur            w2, [x0, #0xb]
    // 0x1262968: DecompressPointer r2
    //     0x1262968: add             x2, x2, HEAP, lsl #32
    // 0x126296c: LoadField: r3 = r1->field_b
    //     0x126296c: ldur            w3, [x1, #0xb]
    // 0x1262970: DecompressPointer r3
    //     0x1262970: add             x3, x3, HEAP, lsl #32
    // 0x1262974: stp             x3, x2, [SP]
    // 0x1262978: r0 = ==()
    //     0x1262978: bl              #0x124ef40  ; [dart:core] Duration::==
    // 0x126297c: tbnz            w0, #4, #0x12629b8
    // 0x1262980: ldr             x1, [fp, #0x18]
    // 0x1262984: ldr             x0, [fp, #0x10]
    // 0x1262988: LoadField: r2 = r0->field_13
    //     0x1262988: ldur            w2, [x0, #0x13]
    // 0x126298c: DecompressPointer r2
    //     0x126298c: add             x2, x2, HEAP, lsl #32
    // 0x1262990: LoadField: r0 = r1->field_13
    //     0x1262990: ldur            w0, [x1, #0x13]
    // 0x1262994: DecompressPointer r0
    //     0x1262994: add             x0, x0, HEAP, lsl #32
    // 0x1262998: r1 = LoadClassIdInstr(r2)
    //     0x1262998: ldur            x1, [x2, #-1]
    //     0x126299c: ubfx            x1, x1, #0xc, #0x14
    // 0x12629a0: stp             x0, x2, [SP]
    // 0x12629a4: mov             x0, x1
    // 0x12629a8: mov             lr, x0
    // 0x12629ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12629b0: blr             lr
    // 0x12629b4: b               #0x12629bc
    // 0x12629b8: r0 = false
    //     0x12629b8: add             x0, NULL, #0x30  ; false
    // 0x12629bc: LeaveFrame
    //     0x12629bc: mov             SP, fp
    //     0x12629c0: ldp             fp, lr, [SP], #0x10
    // 0x12629c4: ret
    //     0x12629c4: ret             
    // 0x12629c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12629c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12629cc: b               #0x1262890
  }
}
