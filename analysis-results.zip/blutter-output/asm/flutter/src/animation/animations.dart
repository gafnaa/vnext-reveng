// lib: , url: package:flutter/src/animation/animations.dart

// class id: 1048764, size: 0x8
class :: {
}

// class id: 4354, size: 0x10, field offset: 0xc
//   const constructor, 
class AlwaysStoppedAnimation<X0> extends Animation<X0> {

  MaterialColor field_c;

  get _ status(/* No info */) {
    // ** addr: 0x1284ec4, size: 0x8
    // 0x1284ec4: r0 = Instance_AnimationStatus
    //     0x1284ec4: ldr             x0, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x1284ec8: ret
    //     0x1284ec8: ret             
  }
}

// class id: 4355, size: 0xc, field offset: 0xc
//   const constructor, 
class _AlwaysDismissedAnimation extends Animation<dynamic> {

  double dyn:get:value(_AlwaysDismissedAnimation) {
    // ** addr: 0x8e0bcc, size: 0x20
    // 0x8e0bcc: r0 = 0.000000
    //     0x8e0bcc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x8e0bd0: ret
    //     0x8e0bd0: ret             
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284ebc, size: 0x8
    // 0x1284ebc: r0 = Instance_AnimationStatus
    //     0x1284ebc: ldr             x0, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x1284ec0: ret
    //     0x1284ec0: ret             
  }
}

// class id: 4356, size: 0xc, field offset: 0xc
//   const constructor, 
class _AlwaysCompleteAnimation extends Animation<dynamic> {

  double dyn:get:value(_AlwaysCompleteAnimation) {
    // ** addr: 0xf3acd0, size: 0x20
    // 0xf3acd0: r0 = 1.000000
    //     0xf3acd0: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3acd4: ret
    //     0xf3acd4: ret             
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284eb4, size: 0x8
    // 0x1284eb4: r0 = Instance_AnimationStatus
    //     0x1284eb4: ldr             x0, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x1284eb8: ret
    //     0x1284eb8: ret             
  }
}

// class id: 4361, size: 0x1c, field offset: 0x18
class ReverseAnimation extends _MixinApplication460&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin {

  double value(ReverseAnimation) {
    // ** addr: 0xae67b8, size: 0xa0
    // 0xae67b8: EnterFrame
    //     0xae67b8: stp             fp, lr, [SP, #-0x10]!
    //     0xae67bc: mov             fp, SP
    // 0xae67c0: CheckStackOverflow
    //     0xae67c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae67c4: cmp             SP, x16
    //     0xae67c8: b.ls            #0xae6840
    // 0xae67cc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xae67cc: ldur            w0, [x1, #0x17]
    // 0xae67d0: DecompressPointer r0
    //     0xae67d0: add             x0, x0, HEAP, lsl #32
    // 0xae67d4: r1 = LoadClassIdInstr(r0)
    //     0xae67d4: ldur            x1, [x0, #-1]
    //     0xae67d8: ubfx            x1, x1, #0xc, #0x14
    // 0xae67dc: mov             x16, x0
    // 0xae67e0: mov             x0, x1
    // 0xae67e4: mov             x1, x16
    // 0xae67e8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae67e8: mov             x17, #0x4e2e
    //     0xae67ec: movk            x17, #1, lsl #16
    //     0xae67f0: add             lr, x0, x17
    //     0xae67f4: ldr             lr, [x21, lr, lsl #3]
    //     0xae67f8: blr             lr
    // 0xae67fc: LoadField: d0 = r0->field_7
    //     0xae67fc: ldur            d0, [x0, #7]
    // 0xae6800: d1 = 1.000000
    //     0xae6800: fmov            d1, #1.00000000
    // 0xae6804: fsub            d2, d1, d0
    // 0xae6808: r0 = inline_Allocate_Double()
    //     0xae6808: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae680c: add             x0, x0, #0x10
    //     0xae6810: cmp             x1, x0
    //     0xae6814: b.ls            #0xae6848
    //     0xae6818: str             x0, [THR, #0x60]  ; THR::top
    //     0xae681c: sub             x0, x0, #0xf
    //     0xae6820: mov             x1, #0xe19c
    //     0xae6824: movk            x1, #3, lsl #16
    //     0xae6828: stur            x1, [x0, #-1]
    // 0xae682c: dmb             ishst
    // 0xae6830: StoreField: r0->field_7 = d2
    //     0xae6830: stur            d2, [x0, #7]
    // 0xae6834: LeaveFrame
    //     0xae6834: mov             SP, fp
    //     0xae6838: ldp             fp, lr, [SP], #0x10
    // 0xae683c: ret
    //     0xae683c: ret             
    // 0xae6840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae6840: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae6844: b               #0xae67cc
    // 0xae6848: SaveReg d2
    //     0xae6848: str             q2, [SP, #-0x10]!
    // 0xae684c: r0 = AllocateDouble()
    //     0xae684c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae6850: RestoreReg d2
    //     0xae6850: ldr             q2, [SP], #0x10
    // 0xae6854: b               #0xae6830
  }
  double dyn:get:value(ReverseAnimation) {
    // ** addr: 0xae6870, size: 0x48
    // 0xae6870: EnterFrame
    //     0xae6870: stp             fp, lr, [SP, #-0x10]!
    //     0xae6874: mov             fp, SP
    // 0xae6878: CheckStackOverflow
    //     0xae6878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae687c: cmp             SP, x16
    //     0xae6880: b.ls            #0xae6898
    // 0xae6884: ldr             x1, [fp, #0x10]
    // 0xae6888: r0 = value()
    //     0xae6888: bl              #0xae67b8  ; [package:flutter/src/animation/animations.dart] ReverseAnimation::value
    // 0xae688c: LeaveFrame
    //     0xae688c: mov             SP, fp
    //     0xae6890: ldp             fp, lr, [SP], #0x10
    // 0xae6894: ret
    //     0xae6894: ret             
    // 0xae6898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae6898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae689c: b               #0xae6884
  }
  [closure] void _statusChangeHandler(dynamic, AnimationStatus) {
    // ** addr: 0xd00e38, size: 0x3c
    // 0xd00e38: EnterFrame
    //     0xd00e38: stp             fp, lr, [SP, #-0x10]!
    //     0xd00e3c: mov             fp, SP
    // 0xd00e40: ldr             x0, [fp, #0x18]
    // 0xd00e44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd00e44: ldur            w1, [x0, #0x17]
    // 0xd00e48: DecompressPointer r1
    //     0xd00e48: add             x1, x1, HEAP, lsl #32
    // 0xd00e4c: CheckStackOverflow
    //     0xd00e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00e50: cmp             SP, x16
    //     0xd00e54: b.ls            #0xd00e6c
    // 0xd00e58: ldr             x2, [fp, #0x10]
    // 0xd00e5c: r0 = _statusChangeHandler()
    //     0xd00e5c: bl              #0xd00e74  ; [package:flutter/src/animation/animations.dart] ReverseAnimation::_statusChangeHandler
    // 0xd00e60: LeaveFrame
    //     0xd00e60: mov             SP, fp
    //     0xd00e64: ldp             fp, lr, [SP], #0x10
    // 0xd00e68: ret
    //     0xd00e68: ret             
    // 0xd00e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00e6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00e70: b               #0xd00e58
  }
  _ _statusChangeHandler(/* No info */) {
    // ** addr: 0xd00e74, size: 0x68
    // 0xd00e74: EnterFrame
    //     0xd00e74: stp             fp, lr, [SP, #-0x10]!
    //     0xd00e78: mov             fp, SP
    // 0xd00e7c: CheckStackOverflow
    //     0xd00e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00e80: cmp             SP, x16
    //     0xd00e84: b.ls            #0xd00ed4
    // 0xd00e88: LoadField: r0 = r2->field_7
    //     0xd00e88: ldur            x0, [x2, #7]
    // 0xd00e8c: cmp             x0, #1
    // 0xd00e90: b.gt            #0xd00eac
    // 0xd00e94: cmp             x0, #0
    // 0xd00e98: b.gt            #0xd00ea4
    // 0xd00e9c: r2 = Instance_AnimationStatus
    //     0xd00e9c: ldr             x2, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd00ea0: b               #0xd00ec0
    // 0xd00ea4: r2 = Instance_AnimationStatus
    //     0xd00ea4: ldr             x2, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xd00ea8: b               #0xd00ec0
    // 0xd00eac: cmp             x0, #2
    // 0xd00eb0: b.gt            #0xd00ebc
    // 0xd00eb4: r2 = Instance_AnimationStatus
    //     0xd00eb4: ldr             x2, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xd00eb8: b               #0xd00ec0
    // 0xd00ebc: r2 = Instance_AnimationStatus
    //     0xd00ebc: ldr             x2, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd00ec0: r0 = notifyStatusListeners()
    //     0xd00ec0: bl              #0xd00edc  ; [dart:mixin_deduplication] _MixinApplication460&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0xd00ec4: r0 = Null
    //     0xd00ec4: mov             x0, NULL
    // 0xd00ec8: LeaveFrame
    //     0xd00ec8: mov             SP, fp
    //     0xd00ecc: ldp             fp, lr, [SP], #0x10
    // 0xd00ed0: ret
    //     0xd00ed0: ret             
    // 0xd00ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00ed4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00ed8: b               #0xd00e88
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xd0117c, size: 0x60
    // 0xd0117c: EnterFrame
    //     0xd0117c: stp             fp, lr, [SP, #-0x10]!
    //     0xd01180: mov             fp, SP
    // 0xd01184: AllocStack(0x8)
    //     0xd01184: sub             SP, SP, #8
    // 0xd01188: SetupParameters(ReverseAnimation this /* r1 => r3, fp-0x8 */)
    //     0xd01188: mov             x3, x1
    //     0xd0118c: stur            x1, [fp, #-8]
    // 0xd01190: CheckStackOverflow
    //     0xd01190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01194: cmp             SP, x16
    //     0xd01198: b.ls            #0xd011d4
    // 0xd0119c: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xd0119c: ldur            w1, [x3, #0x17]
    // 0xd011a0: DecompressPointer r1
    //     0xd011a0: add             x1, x1, HEAP, lsl #32
    // 0xd011a4: r0 = LoadClassIdInstr(r1)
    //     0xd011a4: ldur            x0, [x1, #-1]
    //     0xd011a8: ubfx            x0, x0, #0xc, #0x14
    // 0xd011ac: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xd011ac: mov             x17, #0xe2a3
    //     0xd011b0: add             lr, x0, x17
    //     0xd011b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd011b8: blr             lr
    // 0xd011bc: ldur            x1, [fp, #-8]
    // 0xd011c0: r0 = didUnregisterListener()
    //     0xd011c0: bl              #0xd00d00  ; [dart:mixin_deduplication] _MixinApplication457&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0xd011c4: r0 = Null
    //     0xd011c4: mov             x0, NULL
    // 0xd011c8: LeaveFrame
    //     0xd011c8: mov             SP, fp
    //     0xd011cc: ldp             fp, lr, [SP], #0x10
    // 0xd011d0: ret
    //     0xd011d0: ret             
    // 0xd011d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd011d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd011d8: b               #0xd0119c
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd045e4, size: 0x6c
    // 0xd045e4: EnterFrame
    //     0xd045e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd045e8: mov             fp, SP
    // 0xd045ec: AllocStack(0x10)
    //     0xd045ec: sub             SP, SP, #0x10
    // 0xd045f0: SetupParameters(ReverseAnimation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd045f0: mov             x0, x1
    //     0xd045f4: stur            x1, [fp, #-8]
    //     0xd045f8: stur            x2, [fp, #-0x10]
    // 0xd045fc: CheckStackOverflow
    //     0xd045fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04600: cmp             SP, x16
    //     0xd04604: b.ls            #0xd04648
    // 0xd04608: mov             x1, x0
    // 0xd0460c: r0 = didRegisterListener()
    //     0xd0460c: bl              #0xd044a0  ; [dart:mixin_deduplication] _MixinApplication457&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0xd04610: ldur            x0, [fp, #-8]
    // 0xd04614: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd04614: ldur            w1, [x0, #0x17]
    // 0xd04618: DecompressPointer r1
    //     0xd04618: add             x1, x1, HEAP, lsl #32
    // 0xd0461c: r0 = LoadClassIdInstr(r1)
    //     0xd0461c: ldur            x0, [x1, #-1]
    //     0xd04620: ubfx            x0, x0, #0xc, #0x14
    // 0xd04624: ldur            x2, [fp, #-0x10]
    // 0xd04628: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xd04628: mov             x17, #0xe0ec
    //     0xd0462c: add             lr, x0, x17
    //     0xd04630: ldr             lr, [x21, lr, lsl #3]
    //     0xd04634: blr             lr
    // 0xd04638: r0 = Null
    //     0xd04638: mov             x0, NULL
    // 0xd0463c: LeaveFrame
    //     0xd0463c: mov             SP, fp
    //     0xd04640: ldp             fp, lr, [SP], #0x10
    // 0xd04644: ret
    //     0xd04644: ret             
    // 0xd04648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0464c: b               #0xd04608
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284ddc, size: 0x88
    // 0x1284ddc: EnterFrame
    //     0x1284ddc: stp             fp, lr, [SP, #-0x10]!
    //     0x1284de0: mov             fp, SP
    // 0x1284de4: CheckStackOverflow
    //     0x1284de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1284de8: cmp             SP, x16
    //     0x1284dec: b.ls            #0x1284e5c
    // 0x1284df0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1284df0: ldur            w0, [x1, #0x17]
    // 0x1284df4: DecompressPointer r0
    //     0x1284df4: add             x0, x0, HEAP, lsl #32
    // 0x1284df8: r1 = LoadClassIdInstr(r0)
    //     0x1284df8: ldur            x1, [x0, #-1]
    //     0x1284dfc: ubfx            x1, x1, #0xc, #0x14
    // 0x1284e00: mov             x16, x0
    // 0x1284e04: mov             x0, x1
    // 0x1284e08: mov             x1, x16
    // 0x1284e0c: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284e0c: sub             lr, x0, #0x52
    //     0x1284e10: ldr             lr, [x21, lr, lsl #3]
    //     0x1284e14: blr             lr
    // 0x1284e18: LoadField: r1 = r0->field_7
    //     0x1284e18: ldur            x1, [x0, #7]
    // 0x1284e1c: cmp             x1, #1
    // 0x1284e20: b.gt            #0x1284e3c
    // 0x1284e24: cmp             x1, #0
    // 0x1284e28: b.gt            #0x1284e34
    // 0x1284e2c: r0 = Instance_AnimationStatus
    //     0x1284e2c: ldr             x0, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x1284e30: b               #0x1284e50
    // 0x1284e34: r0 = Instance_AnimationStatus
    //     0x1284e34: ldr             x0, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0x1284e38: b               #0x1284e50
    // 0x1284e3c: cmp             x1, #2
    // 0x1284e40: b.gt            #0x1284e4c
    // 0x1284e44: r0 = Instance_AnimationStatus
    //     0x1284e44: ldr             x0, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x1284e48: b               #0x1284e50
    // 0x1284e4c: r0 = Instance_AnimationStatus
    //     0x1284e4c: ldr             x0, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x1284e50: LeaveFrame
    //     0x1284e50: mov             SP, fp
    //     0x1284e54: ldp             fp, lr, [SP], #0x10
    // 0x1284e58: ret
    //     0x1284e58: ret             
    // 0x1284e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1284e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1284e60: b               #0x1284df0
  }
}

// class id: 4364, size: 0x28, field offset: 0x1c
class ProxyAnimation extends _MixinApplication459&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  _ ProxyAnimation(/* No info */) {
    // ** addr: 0x8e09cc, size: 0x118
    // 0x8e09cc: EnterFrame
    //     0x8e09cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8e09d0: mov             fp, SP
    // 0x8e09d4: AllocStack(0x18)
    //     0x8e09d4: sub             SP, SP, #0x18
    // 0x8e09d8: SetupParameters(ProxyAnimation this /* r1 => r0, fp-0x10 */, [dynamic _ = Null /* r2, fp-0x8 */])
    //     0x8e09d8: mov             x0, x1
    //     0x8e09dc: stur            x1, [fp, #-0x10]
    //     0x8e09e0: ldur            w1, [x4, #0x13]
    //     0x8e09e4: sub             x2, x1, #2
    //     0x8e09e8: cmp             w2, #2
    //     0x8e09ec: b.lt            #0x8e0a00
    //     0x8e09f0: add             x1, fp, w2, sxtw #2
    //     0x8e09f4: ldr             x1, [x1, #8]
    //     0x8e09f8: mov             x2, x1
    //     0x8e09fc: b               #0x8e0a04
    //     0x8e0a00: mov             x2, NULL
    //     0x8e0a04: stur            x2, [fp, #-8]
    // 0x8e0a08: CheckStackOverflow
    //     0x8e0a08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0a0c: cmp             SP, x16
    //     0x8e0a10: b.ls            #0x8e0adc
    // 0x8e0a14: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x8e0a14: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x8e0a18: r0 = ObserverList()
    //     0x8e0a18: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x8e0a1c: mov             x3, x0
    // 0x8e0a20: r0 = false
    //     0x8e0a20: add             x0, NULL, #0x30  ; false
    // 0x8e0a24: stur            x3, [fp, #-0x18]
    // 0x8e0a28: StoreField: r3->field_f = r0
    //     0x8e0a28: stur            w0, [x3, #0xf]
    // 0x8e0a2c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8e0a30: StoreField: r3->field_13 = r0
    //     0x8e0a30: stur            w0, [x3, #0x13]
    // 0x8e0a34: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x8e0a34: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0x8e0a38: r2 = 0
    //     0x8e0a38: mov             x2, #0
    // 0x8e0a3c: r0 = _GrowableList()
    //     0x8e0a3c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8e0a40: ldur            x1, [fp, #-0x18]
    // 0x8e0a44: StoreField: r1->field_b = r0
    //     0x8e0a44: stur            w0, [x1, #0xb]
    //     0x8e0a48: ldurb           w16, [x1, #-1]
    //     0x8e0a4c: ldurb           w17, [x0, #-1]
    //     0x8e0a50: and             x16, x17, x16, lsr #2
    //     0x8e0a54: tst             x16, HEAP, lsr #32
    //     0x8e0a58: b.eq            #0x8e0a60
    //     0x8e0a5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8e0a60: mov             x0, x1
    // 0x8e0a64: ldur            x2, [fp, #-0x10]
    // 0x8e0a68: ArrayStore: r2[0] = r0  ; List_4
    //     0x8e0a68: stur            w0, [x2, #0x17]
    //     0x8e0a6c: ldurb           w16, [x2, #-1]
    //     0x8e0a70: ldurb           w17, [x0, #-1]
    //     0x8e0a74: and             x16, x17, x16, lsr #2
    //     0x8e0a78: tst             x16, HEAP, lsr #32
    //     0x8e0a7c: b.eq            #0x8e0a84
    //     0x8e0a80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8e0a84: mov             x1, x2
    // 0x8e0a88: r0 = _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin()
    //     0x8e0a88: bl              #0x8e0b2c  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::_MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin
    // 0x8e0a8c: ldur            x0, [fp, #-8]
    // 0x8e0a90: ldur            x1, [fp, #-0x10]
    // 0x8e0a94: StoreField: r1->field_23 = r0
    //     0x8e0a94: stur            w0, [x1, #0x23]
    //     0x8e0a98: ldurb           w16, [x1, #-1]
    //     0x8e0a9c: ldurb           w17, [x0, #-1]
    //     0x8e0aa0: and             x16, x17, x16, lsr #2
    //     0x8e0aa4: tst             x16, HEAP, lsr #32
    //     0x8e0aa8: b.eq            #0x8e0ab0
    //     0x8e0aac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8e0ab0: ldur            x2, [fp, #-8]
    // 0x8e0ab4: cmp             w2, NULL
    // 0x8e0ab8: b.ne            #0x8e0acc
    // 0x8e0abc: r3 = Instance_AnimationStatus
    //     0x8e0abc: ldr             x3, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x8e0ac0: r2 = 0.000000
    //     0x8e0ac0: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x8e0ac4: StoreField: r1->field_1b = r3
    //     0x8e0ac4: stur            w3, [x1, #0x1b]
    // 0x8e0ac8: StoreField: r1->field_1f = r2
    //     0x8e0ac8: stur            w2, [x1, #0x1f]
    // 0x8e0acc: r0 = Null
    //     0x8e0acc: mov             x0, NULL
    // 0x8e0ad0: LeaveFrame
    //     0x8e0ad0: mov             SP, fp
    //     0x8e0ad4: ldp             fp, lr, [SP], #0x10
    // 0x8e0ad8: ret
    //     0x8e0ad8: ret             
    // 0x8e0adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0adc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0ae0: b               #0x8e0a14
  }
  double dyn:get:value(ProxyAnimation) {
    // ** addr: 0x8e0afc, size: 0x48
    // 0x8e0afc: EnterFrame
    //     0x8e0afc: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0b00: mov             fp, SP
    // 0x8e0b04: CheckStackOverflow
    //     0x8e0b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0b08: cmp             SP, x16
    //     0x8e0b0c: b.ls            #0x8e0b24
    // 0x8e0b10: ldr             x1, [fp, #0x10]
    // 0x8e0b14: r0 = value()
    //     0x8e0b14: bl              #0xae66fc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0x8e0b18: LeaveFrame
    //     0x8e0b18: mov             SP, fp
    //     0x8e0b1c: ldp             fp, lr, [SP], #0x10
    // 0x8e0b20: ret
    //     0x8e0b20: ret             
    // 0x8e0b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0b28: b               #0x8e0b10
  }
  double value(ProxyAnimation) {
    // ** addr: 0xae66fc, size: 0xbc
    // 0xae66fc: EnterFrame
    //     0xae66fc: stp             fp, lr, [SP, #-0x10]!
    //     0xae6700: mov             fp, SP
    // 0xae6704: CheckStackOverflow
    //     0xae6704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae6708: cmp             SP, x16
    //     0xae670c: b.ls            #0xae679c
    // 0xae6710: LoadField: r0 = r1->field_23
    //     0xae6710: ldur            w0, [x1, #0x23]
    // 0xae6714: DecompressPointer r0
    //     0xae6714: add             x0, x0, HEAP, lsl #32
    // 0xae6718: cmp             w0, NULL
    // 0xae671c: b.eq            #0xae6750
    // 0xae6720: r1 = LoadClassIdInstr(r0)
    //     0xae6720: ldur            x1, [x0, #-1]
    //     0xae6724: ubfx            x1, x1, #0xc, #0x14
    // 0xae6728: mov             x16, x0
    // 0xae672c: mov             x0, x1
    // 0xae6730: mov             x1, x16
    // 0xae6734: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae6734: mov             x17, #0x4e2e
    //     0xae6738: movk            x17, #1, lsl #16
    //     0xae673c: add             lr, x0, x17
    //     0xae6740: ldr             lr, [x21, lr, lsl #3]
    //     0xae6744: blr             lr
    // 0xae6748: LoadField: d0 = r0->field_7
    //     0xae6748: ldur            d0, [x0, #7]
    // 0xae674c: b               #0xae6764
    // 0xae6750: LoadField: r2 = r1->field_1f
    //     0xae6750: ldur            w2, [x1, #0x1f]
    // 0xae6754: DecompressPointer r2
    //     0xae6754: add             x2, x2, HEAP, lsl #32
    // 0xae6758: cmp             w2, NULL
    // 0xae675c: b.eq            #0xae67a4
    // 0xae6760: LoadField: d0 = r2->field_7
    //     0xae6760: ldur            d0, [x2, #7]
    // 0xae6764: r0 = inline_Allocate_Double()
    //     0xae6764: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae6768: add             x0, x0, #0x10
    //     0xae676c: cmp             x1, x0
    //     0xae6770: b.ls            #0xae67a8
    //     0xae6774: str             x0, [THR, #0x60]  ; THR::top
    //     0xae6778: sub             x0, x0, #0xf
    //     0xae677c: mov             x1, #0xe19c
    //     0xae6780: movk            x1, #3, lsl #16
    //     0xae6784: stur            x1, [x0, #-1]
    // 0xae6788: dmb             ishst
    // 0xae678c: StoreField: r0->field_7 = d0
    //     0xae678c: stur            d0, [x0, #7]
    // 0xae6790: LeaveFrame
    //     0xae6790: mov             SP, fp
    //     0xae6794: ldp             fp, lr, [SP], #0x10
    // 0xae6798: ret
    //     0xae6798: ret             
    // 0xae679c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae679c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae67a0: b               #0xae6710
    // 0xae67a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae67a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xae67a8: SaveReg d0
    //     0xae67a8: str             q0, [SP, #-0x10]!
    // 0xae67ac: r0 = AllocateDouble()
    //     0xae67ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae67b0: RestoreReg d0
    //     0xae67b0: ldr             q0, [SP], #0x10
    // 0xae67b4: b               #0xae678c
  }
  set _ parent=(/* No info */) {
    // ** addr: 0xb72d4c, size: 0x268
    // 0xb72d4c: EnterFrame
    //     0xb72d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb72d50: mov             fp, SP
    // 0xb72d54: AllocStack(0x20)
    //     0xb72d54: sub             SP, SP, #0x20
    // 0xb72d58: SetupParameters(ProxyAnimation this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb72d58: stur            x1, [fp, #-8]
    //     0xb72d5c: mov             x16, x2
    //     0xb72d60: mov             x2, x1
    //     0xb72d64: mov             x1, x16
    //     0xb72d68: stur            x1, [fp, #-0x10]
    // 0xb72d6c: CheckStackOverflow
    //     0xb72d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb72d70: cmp             SP, x16
    //     0xb72d74: b.ls            #0xb72f9c
    // 0xb72d78: LoadField: r0 = r2->field_23
    //     0xb72d78: ldur            w0, [x2, #0x23]
    // 0xb72d7c: DecompressPointer r0
    //     0xb72d7c: add             x0, x0, HEAP, lsl #32
    // 0xb72d80: r3 = LoadClassIdInstr(r1)
    //     0xb72d80: ldur            x3, [x1, #-1]
    //     0xb72d84: ubfx            x3, x3, #0xc, #0x14
    // 0xb72d88: stp             x0, x1, [SP]
    // 0xb72d8c: mov             x0, x3
    // 0xb72d90: mov             lr, x0
    // 0xb72d94: ldr             lr, [x21, lr, lsl #3]
    // 0xb72d98: blr             lr
    // 0xb72d9c: tbnz            w0, #4, #0xb72db0
    // 0xb72da0: r0 = Null
    //     0xb72da0: mov             x0, NULL
    // 0xb72da4: LeaveFrame
    //     0xb72da4: mov             SP, fp
    //     0xb72da8: ldp             fp, lr, [SP], #0x10
    // 0xb72dac: ret
    //     0xb72dac: ret             
    // 0xb72db0: ldur            x2, [fp, #-8]
    // 0xb72db4: LoadField: r1 = r2->field_23
    //     0xb72db4: ldur            w1, [x2, #0x23]
    // 0xb72db8: DecompressPointer r1
    //     0xb72db8: add             x1, x1, HEAP, lsl #32
    // 0xb72dbc: cmp             w1, NULL
    // 0xb72dc0: b.eq            #0xb72e58
    // 0xb72dc4: r0 = LoadClassIdInstr(r1)
    //     0xb72dc4: ldur            x0, [x1, #-1]
    //     0xb72dc8: ubfx            x0, x0, #0xc, #0x14
    // 0xb72dcc: r0 = GDT[cid_x0 + -0x52]()
    //     0xb72dcc: sub             lr, x0, #0x52
    //     0xb72dd0: ldr             lr, [x21, lr, lsl #3]
    //     0xb72dd4: blr             lr
    // 0xb72dd8: ldur            x2, [fp, #-8]
    // 0xb72ddc: StoreField: r2->field_1b = r0
    //     0xb72ddc: stur            w0, [x2, #0x1b]
    //     0xb72de0: ldurb           w16, [x2, #-1]
    //     0xb72de4: ldurb           w17, [x0, #-1]
    //     0xb72de8: and             x16, x17, x16, lsr #2
    //     0xb72dec: tst             x16, HEAP, lsr #32
    //     0xb72df0: b.eq            #0xb72df8
    //     0xb72df4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb72df8: LoadField: r1 = r2->field_23
    //     0xb72df8: ldur            w1, [x2, #0x23]
    // 0xb72dfc: DecompressPointer r1
    //     0xb72dfc: add             x1, x1, HEAP, lsl #32
    // 0xb72e00: cmp             w1, NULL
    // 0xb72e04: b.eq            #0xb72fa4
    // 0xb72e08: r0 = LoadClassIdInstr(r1)
    //     0xb72e08: ldur            x0, [x1, #-1]
    //     0xb72e0c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72e10: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72e10: mov             x17, #0x4e2e
    //     0xb72e14: movk            x17, #1, lsl #16
    //     0xb72e18: add             lr, x0, x17
    //     0xb72e1c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72e20: blr             lr
    // 0xb72e24: ldur            x2, [fp, #-8]
    // 0xb72e28: StoreField: r2->field_1f = r0
    //     0xb72e28: stur            w0, [x2, #0x1f]
    //     0xb72e2c: ldurb           w16, [x2, #-1]
    //     0xb72e30: ldurb           w17, [x0, #-1]
    //     0xb72e34: and             x16, x17, x16, lsr #2
    //     0xb72e38: tst             x16, HEAP, lsr #32
    //     0xb72e3c: b.eq            #0xb72e44
    //     0xb72e40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb72e44: LoadField: r0 = r2->field_b
    //     0xb72e44: ldur            x0, [x2, #0xb]
    // 0xb72e48: cmp             x0, #0
    // 0xb72e4c: b.le            #0xb72e58
    // 0xb72e50: mov             x1, x2
    // 0xb72e54: r0 = didStopListening()
    //     0xb72e54: bl              #0x11d5fe0  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::didStopListening
    // 0xb72e58: ldur            x2, [fp, #-8]
    // 0xb72e5c: ldur            x1, [fp, #-0x10]
    // 0xb72e60: mov             x0, x1
    // 0xb72e64: StoreField: r2->field_23 = r0
    //     0xb72e64: stur            w0, [x2, #0x23]
    //     0xb72e68: ldurb           w16, [x2, #-1]
    //     0xb72e6c: ldurb           w17, [x0, #-1]
    //     0xb72e70: and             x16, x17, x16, lsr #2
    //     0xb72e74: tst             x16, HEAP, lsr #32
    //     0xb72e78: b.eq            #0xb72e80
    //     0xb72e7c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb72e80: cmp             w1, NULL
    // 0xb72e84: b.eq            #0xb72f8c
    // 0xb72e88: LoadField: r0 = r2->field_b
    //     0xb72e88: ldur            x0, [x2, #0xb]
    // 0xb72e8c: cmp             x0, #0
    // 0xb72e90: b.le            #0xb72e9c
    // 0xb72e94: mov             x1, x2
    // 0xb72e98: r0 = didStartListening()
    //     0xb72e98: bl              #0x121ccbc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::didStartListening
    // 0xb72e9c: ldur            x2, [fp, #-8]
    // 0xb72ea0: LoadField: r3 = r2->field_1f
    //     0xb72ea0: ldur            w3, [x2, #0x1f]
    // 0xb72ea4: DecompressPointer r3
    //     0xb72ea4: add             x3, x3, HEAP, lsl #32
    // 0xb72ea8: stur            x3, [fp, #-0x10]
    // 0xb72eac: LoadField: r1 = r2->field_23
    //     0xb72eac: ldur            w1, [x2, #0x23]
    // 0xb72eb0: DecompressPointer r1
    //     0xb72eb0: add             x1, x1, HEAP, lsl #32
    // 0xb72eb4: cmp             w1, NULL
    // 0xb72eb8: b.eq            #0xb72fa8
    // 0xb72ebc: r0 = LoadClassIdInstr(r1)
    //     0xb72ebc: ldur            x0, [x1, #-1]
    //     0xb72ec0: ubfx            x0, x0, #0xc, #0x14
    // 0xb72ec4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72ec4: mov             x17, #0x4e2e
    //     0xb72ec8: movk            x17, #1, lsl #16
    //     0xb72ecc: add             lr, x0, x17
    //     0xb72ed0: ldr             lr, [x21, lr, lsl #3]
    //     0xb72ed4: blr             lr
    // 0xb72ed8: mov             x1, x0
    // 0xb72edc: ldur            x0, [fp, #-0x10]
    // 0xb72ee0: r2 = LoadClassIdInstr(r0)
    //     0xb72ee0: ldur            x2, [x0, #-1]
    //     0xb72ee4: ubfx            x2, x2, #0xc, #0x14
    // 0xb72ee8: stp             x1, x0, [SP]
    // 0xb72eec: mov             x0, x2
    // 0xb72ef0: mov             lr, x0
    // 0xb72ef4: ldr             lr, [x21, lr, lsl #3]
    // 0xb72ef8: blr             lr
    // 0xb72efc: tbz             w0, #4, #0xb72f08
    // 0xb72f00: ldur            x1, [fp, #-8]
    // 0xb72f04: r0 = notifyListeners()
    //     0xb72f04: bl              #0xb73290  ; [dart:mixin_deduplication] _MixinApplication458&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0xb72f08: ldur            x2, [fp, #-8]
    // 0xb72f0c: LoadField: r3 = r2->field_1b
    //     0xb72f0c: ldur            w3, [x2, #0x1b]
    // 0xb72f10: DecompressPointer r3
    //     0xb72f10: add             x3, x3, HEAP, lsl #32
    // 0xb72f14: stur            x3, [fp, #-0x10]
    // 0xb72f18: LoadField: r1 = r2->field_23
    //     0xb72f18: ldur            w1, [x2, #0x23]
    // 0xb72f1c: DecompressPointer r1
    //     0xb72f1c: add             x1, x1, HEAP, lsl #32
    // 0xb72f20: cmp             w1, NULL
    // 0xb72f24: b.eq            #0xb72fac
    // 0xb72f28: r0 = LoadClassIdInstr(r1)
    //     0xb72f28: ldur            x0, [x1, #-1]
    //     0xb72f2c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72f30: r0 = GDT[cid_x0 + -0x52]()
    //     0xb72f30: sub             lr, x0, #0x52
    //     0xb72f34: ldr             lr, [x21, lr, lsl #3]
    //     0xb72f38: blr             lr
    // 0xb72f3c: mov             x1, x0
    // 0xb72f40: ldur            x0, [fp, #-0x10]
    // 0xb72f44: cmp             w0, w1
    // 0xb72f48: b.eq            #0xb72f80
    // 0xb72f4c: ldur            x2, [fp, #-8]
    // 0xb72f50: LoadField: r1 = r2->field_23
    //     0xb72f50: ldur            w1, [x2, #0x23]
    // 0xb72f54: DecompressPointer r1
    //     0xb72f54: add             x1, x1, HEAP, lsl #32
    // 0xb72f58: cmp             w1, NULL
    // 0xb72f5c: b.eq            #0xb72fb0
    // 0xb72f60: r0 = LoadClassIdInstr(r1)
    //     0xb72f60: ldur            x0, [x1, #-1]
    //     0xb72f64: ubfx            x0, x0, #0xc, #0x14
    // 0xb72f68: r0 = GDT[cid_x0 + -0x52]()
    //     0xb72f68: sub             lr, x0, #0x52
    //     0xb72f6c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72f70: blr             lr
    // 0xb72f74: ldur            x1, [fp, #-8]
    // 0xb72f78: mov             x2, x0
    // 0xb72f7c: r0 = notifyStatusListeners()
    //     0xb72f7c: bl              #0xb72fb4  ; [dart:mixin_deduplication] _MixinApplication459&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0xb72f80: ldur            x1, [fp, #-8]
    // 0xb72f84: StoreField: r1->field_1b = rNULL
    //     0xb72f84: stur            NULL, [x1, #0x1b]
    // 0xb72f88: StoreField: r1->field_1f = rNULL
    //     0xb72f88: stur            NULL, [x1, #0x1f]
    // 0xb72f8c: r0 = Null
    //     0xb72f8c: mov             x0, NULL
    // 0xb72f90: LeaveFrame
    //     0xb72f90: mov             SP, fp
    //     0xb72f94: ldp             fp, lr, [SP], #0x10
    // 0xb72f98: ret
    //     0xb72f98: ret             
    // 0xb72f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72f9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72fa0: b               #0xb72d78
    // 0xb72fa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72fa4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72fa8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72fa8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72fac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72fac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72fb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72fb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didStopListening(/* No info */) {
    // ** addr: 0x11d5fe0, size: 0xd0
    // 0x11d5fe0: EnterFrame
    //     0x11d5fe0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d5fe4: mov             fp, SP
    // 0x11d5fe8: AllocStack(0x10)
    //     0x11d5fe8: sub             SP, SP, #0x10
    // 0x11d5fec: SetupParameters(ProxyAnimation this /* r1 => r0, fp-0x10 */)
    //     0x11d5fec: mov             x0, x1
    //     0x11d5ff0: stur            x1, [fp, #-0x10]
    // 0x11d5ff4: CheckStackOverflow
    //     0x11d5ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d5ff8: cmp             SP, x16
    //     0x11d5ffc: b.ls            #0x11d60a4
    // 0x11d6000: LoadField: r3 = r0->field_23
    //     0x11d6000: ldur            w3, [x0, #0x23]
    // 0x11d6004: DecompressPointer r3
    //     0x11d6004: add             x3, x3, HEAP, lsl #32
    // 0x11d6008: stur            x3, [fp, #-8]
    // 0x11d600c: cmp             w3, NULL
    // 0x11d6010: b.eq            #0x11d6094
    // 0x11d6014: mov             x2, x0
    // 0x11d6018: r1 = Function 'notifyListeners':.
    //     0x11d6018: add             x1, PP, #0x26, lsl #12  ; [pp+0x26f08] AnonymousClosure: (0xb7353c), in [dart:mixin_deduplication] _MixinApplication458&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0xb73290)
    //     0x11d601c: ldr             x1, [x1, #0xf08]
    // 0x11d6020: r0 = AllocateClosure()
    //     0x11d6020: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11d6024: ldur            x1, [fp, #-8]
    // 0x11d6028: r2 = LoadClassIdInstr(r1)
    //     0x11d6028: ldur            x2, [x1, #-1]
    //     0x11d602c: ubfx            x2, x2, #0xc, #0x14
    // 0x11d6030: mov             x16, x0
    // 0x11d6034: mov             x0, x2
    // 0x11d6038: mov             x2, x16
    // 0x11d603c: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x11d603c: mov             x17, #0xe2a3
    //     0x11d6040: add             lr, x0, x17
    //     0x11d6044: ldr             lr, [x21, lr, lsl #3]
    //     0x11d6048: blr             lr
    // 0x11d604c: ldur            x2, [fp, #-0x10]
    // 0x11d6050: LoadField: r0 = r2->field_23
    //     0x11d6050: ldur            w0, [x2, #0x23]
    // 0x11d6054: DecompressPointer r0
    //     0x11d6054: add             x0, x0, HEAP, lsl #32
    // 0x11d6058: stur            x0, [fp, #-8]
    // 0x11d605c: cmp             w0, NULL
    // 0x11d6060: b.eq            #0x11d60ac
    // 0x11d6064: r1 = Function 'notifyStatusListeners':.
    //     0x11d6064: add             x1, PP, #0x26, lsl #12  ; [pp+0x26f10] AnonymousClosure: (0xb73254), in [dart:mixin_deduplication] _MixinApplication459&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0xb72fb4)
    //     0x11d6068: ldr             x1, [x1, #0xf10]
    // 0x11d606c: r0 = AllocateClosure()
    //     0x11d606c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11d6070: ldur            x1, [fp, #-8]
    // 0x11d6074: r2 = LoadClassIdInstr(r1)
    //     0x11d6074: ldur            x2, [x1, #-1]
    //     0x11d6078: ubfx            x2, x2, #0xc, #0x14
    // 0x11d607c: mov             x16, x0
    // 0x11d6080: mov             x0, x2
    // 0x11d6084: mov             x2, x16
    // 0x11d6088: r0 = GDT[cid_x0 + 0xabe]()
    //     0x11d6088: add             lr, x0, #0xabe
    //     0x11d608c: ldr             lr, [x21, lr, lsl #3]
    //     0x11d6090: blr             lr
    // 0x11d6094: r0 = Null
    //     0x11d6094: mov             x0, NULL
    // 0x11d6098: LeaveFrame
    //     0x11d6098: mov             SP, fp
    //     0x11d609c: ldp             fp, lr, [SP], #0x10
    // 0x11d60a0: ret
    //     0x11d60a0: ret             
    // 0x11d60a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d60a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d60a8: b               #0x11d6000
    // 0x11d60ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11d60ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didStartListening(/* No info */) {
    // ** addr: 0x121ccbc, size: 0xd0
    // 0x121ccbc: EnterFrame
    //     0x121ccbc: stp             fp, lr, [SP, #-0x10]!
    //     0x121ccc0: mov             fp, SP
    // 0x121ccc4: AllocStack(0x10)
    //     0x121ccc4: sub             SP, SP, #0x10
    // 0x121ccc8: SetupParameters(ProxyAnimation this /* r1 => r0, fp-0x10 */)
    //     0x121ccc8: mov             x0, x1
    //     0x121cccc: stur            x1, [fp, #-0x10]
    // 0x121ccd0: CheckStackOverflow
    //     0x121ccd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ccd4: cmp             SP, x16
    //     0x121ccd8: b.ls            #0x121cd80
    // 0x121ccdc: LoadField: r3 = r0->field_23
    //     0x121ccdc: ldur            w3, [x0, #0x23]
    // 0x121cce0: DecompressPointer r3
    //     0x121cce0: add             x3, x3, HEAP, lsl #32
    // 0x121cce4: stur            x3, [fp, #-8]
    // 0x121cce8: cmp             w3, NULL
    // 0x121ccec: b.eq            #0x121cd70
    // 0x121ccf0: mov             x2, x0
    // 0x121ccf4: r1 = Function 'notifyListeners':.
    //     0x121ccf4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26f08] AnonymousClosure: (0xb7353c), in [dart:mixin_deduplication] _MixinApplication458&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0xb73290)
    //     0x121ccf8: ldr             x1, [x1, #0xf08]
    // 0x121ccfc: r0 = AllocateClosure()
    //     0x121ccfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x121cd00: ldur            x1, [fp, #-8]
    // 0x121cd04: r2 = LoadClassIdInstr(r1)
    //     0x121cd04: ldur            x2, [x1, #-1]
    //     0x121cd08: ubfx            x2, x2, #0xc, #0x14
    // 0x121cd0c: mov             x16, x0
    // 0x121cd10: mov             x0, x2
    // 0x121cd14: mov             x2, x16
    // 0x121cd18: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0x121cd18: mov             x17, #0xe0ec
    //     0x121cd1c: add             lr, x0, x17
    //     0x121cd20: ldr             lr, [x21, lr, lsl #3]
    //     0x121cd24: blr             lr
    // 0x121cd28: ldur            x2, [fp, #-0x10]
    // 0x121cd2c: LoadField: r0 = r2->field_23
    //     0x121cd2c: ldur            w0, [x2, #0x23]
    // 0x121cd30: DecompressPointer r0
    //     0x121cd30: add             x0, x0, HEAP, lsl #32
    // 0x121cd34: stur            x0, [fp, #-8]
    // 0x121cd38: cmp             w0, NULL
    // 0x121cd3c: b.eq            #0x121cd88
    // 0x121cd40: r1 = Function 'notifyStatusListeners':.
    //     0x121cd40: add             x1, PP, #0x26, lsl #12  ; [pp+0x26f10] AnonymousClosure: (0xb73254), in [dart:mixin_deduplication] _MixinApplication459&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0xb72fb4)
    //     0x121cd44: ldr             x1, [x1, #0xf10]
    // 0x121cd48: r0 = AllocateClosure()
    //     0x121cd48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x121cd4c: ldur            x1, [fp, #-8]
    // 0x121cd50: r2 = LoadClassIdInstr(r1)
    //     0x121cd50: ldur            x2, [x1, #-1]
    //     0x121cd54: ubfx            x2, x2, #0xc, #0x14
    // 0x121cd58: mov             x16, x0
    // 0x121cd5c: mov             x0, x2
    // 0x121cd60: mov             x2, x16
    // 0x121cd64: r0 = GDT[cid_x0 + 0xbeb]()
    //     0x121cd64: add             lr, x0, #0xbeb
    //     0x121cd68: ldr             lr, [x21, lr, lsl #3]
    //     0x121cd6c: blr             lr
    // 0x121cd70: r0 = Null
    //     0x121cd70: mov             x0, NULL
    // 0x121cd74: LeaveFrame
    //     0x121cd74: mov             SP, fp
    //     0x121cd78: ldp             fp, lr, [SP], #0x10
    // 0x121cd7c: ret
    //     0x121cd7c: ret             
    // 0x121cd80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121cd80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121cd84: b               #0x121ccdc
    // 0x121cd88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121cd88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284d68, size: 0x74
    // 0x1284d68: EnterFrame
    //     0x1284d68: stp             fp, lr, [SP, #-0x10]!
    //     0x1284d6c: mov             fp, SP
    // 0x1284d70: CheckStackOverflow
    //     0x1284d70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1284d74: cmp             SP, x16
    //     0x1284d78: b.ls            #0x1284dd0
    // 0x1284d7c: LoadField: r0 = r1->field_23
    //     0x1284d7c: ldur            w0, [x1, #0x23]
    // 0x1284d80: DecompressPointer r0
    //     0x1284d80: add             x0, x0, HEAP, lsl #32
    // 0x1284d84: cmp             w0, NULL
    // 0x1284d88: b.eq            #0x1284db0
    // 0x1284d8c: r1 = LoadClassIdInstr(r0)
    //     0x1284d8c: ldur            x1, [x0, #-1]
    //     0x1284d90: ubfx            x1, x1, #0xc, #0x14
    // 0x1284d94: mov             x16, x0
    // 0x1284d98: mov             x0, x1
    // 0x1284d9c: mov             x1, x16
    // 0x1284da0: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284da0: sub             lr, x0, #0x52
    //     0x1284da4: ldr             lr, [x21, lr, lsl #3]
    //     0x1284da8: blr             lr
    // 0x1284dac: b               #0x1284dc4
    // 0x1284db0: LoadField: r2 = r1->field_1b
    //     0x1284db0: ldur            w2, [x1, #0x1b]
    // 0x1284db4: DecompressPointer r2
    //     0x1284db4: add             x2, x2, HEAP, lsl #32
    // 0x1284db8: cmp             w2, NULL
    // 0x1284dbc: b.eq            #0x1284dd8
    // 0x1284dc0: mov             x0, x2
    // 0x1284dc4: LeaveFrame
    //     0x1284dc4: mov             SP, fp
    //     0x1284dc8: ldp             fp, lr, [SP], #0x10
    // 0x1284dcc: ret
    //     0x1284dcc: ret             
    // 0x1284dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1284dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1284dd4: b               #0x1284d7c
    // 0x1284dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1284dd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4368, size: 0x2c, field offset: 0x14
class TrainHoppingAnimation extends _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  double value(TrainHoppingAnimation) {
    // ** addr: 0xae6624, size: 0x64
    // 0xae6624: EnterFrame
    //     0xae6624: stp             fp, lr, [SP, #-0x10]!
    //     0xae6628: mov             fp, SP
    // 0xae662c: CheckStackOverflow
    //     0xae662c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae6630: cmp             SP, x16
    //     0xae6634: b.ls            #0xae667c
    // 0xae6638: LoadField: r0 = r1->field_13
    //     0xae6638: ldur            w0, [x1, #0x13]
    // 0xae663c: DecompressPointer r0
    //     0xae663c: add             x0, x0, HEAP, lsl #32
    // 0xae6640: cmp             w0, NULL
    // 0xae6644: b.eq            #0xae6684
    // 0xae6648: r1 = LoadClassIdInstr(r0)
    //     0xae6648: ldur            x1, [x0, #-1]
    //     0xae664c: ubfx            x1, x1, #0xc, #0x14
    // 0xae6650: mov             x16, x0
    // 0xae6654: mov             x0, x1
    // 0xae6658: mov             x1, x16
    // 0xae665c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae665c: mov             x17, #0x4e2e
    //     0xae6660: movk            x17, #1, lsl #16
    //     0xae6664: add             lr, x0, x17
    //     0xae6668: ldr             lr, [x21, lr, lsl #3]
    //     0xae666c: blr             lr
    // 0xae6670: LeaveFrame
    //     0xae6670: mov             SP, fp
    //     0xae6674: ldp             fp, lr, [SP], #0x10
    // 0xae6678: ret
    //     0xae6678: ret             
    // 0xae667c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae667c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae6680: b               #0xae6638
    // 0xae6684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae6684: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  double dyn:get:value(TrainHoppingAnimation) {
    // ** addr: 0xae66a0, size: 0x74
    // 0xae66a0: EnterFrame
    //     0xae66a0: stp             fp, lr, [SP, #-0x10]!
    //     0xae66a4: mov             fp, SP
    // 0xae66a8: CheckStackOverflow
    //     0xae66a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae66ac: cmp             SP, x16
    //     0xae66b0: b.ls            #0xae66f0
    // 0xae66b4: ldr             x0, [fp, #0x10]
    // 0xae66b8: LoadField: r1 = r0->field_13
    //     0xae66b8: ldur            w1, [x0, #0x13]
    // 0xae66bc: DecompressPointer r1
    //     0xae66bc: add             x1, x1, HEAP, lsl #32
    // 0xae66c0: cmp             w1, NULL
    // 0xae66c4: b.eq            #0xae66f8
    // 0xae66c8: r0 = LoadClassIdInstr(r1)
    //     0xae66c8: ldur            x0, [x1, #-1]
    //     0xae66cc: ubfx            x0, x0, #0xc, #0x14
    // 0xae66d0: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae66d0: mov             x17, #0x4e2e
    //     0xae66d4: movk            x17, #1, lsl #16
    //     0xae66d8: add             lr, x0, x17
    //     0xae66dc: ldr             lr, [x21, lr, lsl #3]
    //     0xae66e0: blr             lr
    // 0xae66e4: LeaveFrame
    //     0xae66e4: mov             SP, fp
    //     0xae66e8: ldp             fp, lr, [SP], #0x10
    // 0xae66ec: ret
    //     0xae66ec: ret             
    // 0xae66f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae66f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae66f4: b               #0xae66b4
    // 0xae66f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae66f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ TrainHoppingAnimation(/* No info */) {
    // ** addr: 0xb724a0, size: 0x3dc
    // 0xb724a0: EnterFrame
    //     0xb724a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb724a4: mov             fp, SP
    // 0xb724a8: AllocStack(0x28)
    //     0xb724a8: sub             SP, SP, #0x28
    // 0xb724ac: SetupParameters(TrainHoppingAnimation this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r1 */, {dynamic onSwitchedTrain = Null /* r3 */})
    //     0xb724ac: mov             x0, x2
    //     0xb724b0: mov             x2, x1
    //     0xb724b4: stur            x1, [fp, #-8]
    //     0xb724b8: mov             x1, x3
    //     0xb724bc: ldur            w3, [x4, #0x13]
    //     0xb724c0: ldur            w5, [x4, #0x1f]
    //     0xb724c4: add             x5, x5, HEAP, lsl #32
    //     0xb724c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26ec8] "onSwitchedTrain"
    //     0xb724cc: ldr             x16, [x16, #0xec8]
    //     0xb724d0: cmp             w5, w16
    //     0xb724d4: b.ne            #0xb724f0
    //     0xb724d8: ldur            w5, [x4, #0x23]
    //     0xb724dc: add             x5, x5, HEAP, lsl #32
    //     0xb724e0: sub             w4, w3, w5
    //     0xb724e4: add             x3, fp, w4, sxtw #2
    //     0xb724e8: ldr             x3, [x3, #8]
    //     0xb724ec: b               #0xb724f4
    //     0xb724f0: mov             x3, NULL
    // 0xb724f4: CheckStackOverflow
    //     0xb724f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb724f8: cmp             SP, x16
    //     0xb724fc: b.ls            #0xb7285c
    // 0xb72500: StoreField: r2->field_13 = r0
    //     0xb72500: stur            w0, [x2, #0x13]
    //     0xb72504: ldurb           w16, [x2, #-1]
    //     0xb72508: ldurb           w17, [x0, #-1]
    //     0xb7250c: and             x16, x17, x16, lsr #2
    //     0xb72510: tst             x16, HEAP, lsr #32
    //     0xb72514: b.eq            #0xb7251c
    //     0xb72518: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb7251c: mov             x0, x1
    // 0xb72520: ArrayStore: r2[0] = r0  ; List_4
    //     0xb72520: stur            w0, [x2, #0x17]
    //     0xb72524: ldurb           w16, [x2, #-1]
    //     0xb72528: ldurb           w17, [x0, #-1]
    //     0xb7252c: and             x16, x17, x16, lsr #2
    //     0xb72530: tst             x16, HEAP, lsr #32
    //     0xb72534: b.eq            #0xb7253c
    //     0xb72538: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb7253c: mov             x0, x3
    // 0xb72540: StoreField: r2->field_1f = r0
    //     0xb72540: stur            w0, [x2, #0x1f]
    //     0xb72544: ldurb           w16, [x2, #-1]
    //     0xb72548: ldurb           w17, [x0, #-1]
    //     0xb7254c: and             x16, x17, x16, lsr #2
    //     0xb72550: tst             x16, HEAP, lsr #32
    //     0xb72554: b.eq            #0xb7255c
    //     0xb72558: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb7255c: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xb7255c: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xb72560: r0 = ObserverList()
    //     0xb72560: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xb72564: mov             x3, x0
    // 0xb72568: r0 = false
    //     0xb72568: add             x0, NULL, #0x30  ; false
    // 0xb7256c: stur            x3, [fp, #-0x10]
    // 0xb72570: StoreField: r3->field_f = r0
    //     0xb72570: stur            w0, [x3, #0xf]
    // 0xb72574: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xb72578: StoreField: r3->field_13 = r0
    //     0xb72578: stur            w0, [x3, #0x13]
    // 0xb7257c: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xb7257c: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xb72580: r2 = 0
    //     0xb72580: mov             x2, #0
    // 0xb72584: r0 = _GrowableList()
    //     0xb72584: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb72588: ldur            x1, [fp, #-0x10]
    // 0xb7258c: StoreField: r1->field_b = r0
    //     0xb7258c: stur            w0, [x1, #0xb]
    //     0xb72590: ldurb           w16, [x1, #-1]
    //     0xb72594: ldurb           w17, [x0, #-1]
    //     0xb72598: and             x16, x17, x16, lsr #2
    //     0xb7259c: tst             x16, HEAP, lsr #32
    //     0xb725a0: b.eq            #0xb725a8
    //     0xb725a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb725a8: mov             x0, x1
    // 0xb725ac: ldur            x2, [fp, #-8]
    // 0xb725b0: StoreField: r2->field_f = r0
    //     0xb725b0: stur            w0, [x2, #0xf]
    //     0xb725b4: ldurb           w16, [x2, #-1]
    //     0xb725b8: ldurb           w17, [x0, #-1]
    //     0xb725bc: and             x16, x17, x16, lsr #2
    //     0xb725c0: tst             x16, HEAP, lsr #32
    //     0xb725c4: b.eq            #0xb725cc
    //     0xb725c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb725cc: r16 = <(dynamic this) => void?, int>
    //     0xb725cc: ldr             x16, [PP, #0x5790]  ; [pp+0x5790] TypeArguments: <(dynamic this) => void?, int>
    // 0xb725d0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb725d4: stp             lr, x16, [SP]
    // 0xb725d8: r0 = Map._fromLiteral()
    //     0xb725d8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb725dc: r1 = <(dynamic this) => void?>
    //     0xb725dc: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0xb725e0: stur            x0, [fp, #-0x10]
    // 0xb725e4: r0 = HashedObserverList()
    //     0xb725e4: bl              #0x83d31c  ; AllocateHashedObserverListStub -> HashedObserverList<X0> (size=0x10)
    // 0xb725e8: mov             x1, x0
    // 0xb725ec: ldur            x0, [fp, #-0x10]
    // 0xb725f0: StoreField: r1->field_b = r0
    //     0xb725f0: stur            w0, [x1, #0xb]
    // 0xb725f4: mov             x0, x1
    // 0xb725f8: ldur            x2, [fp, #-8]
    // 0xb725fc: StoreField: r2->field_b = r0
    //     0xb725fc: stur            w0, [x2, #0xb]
    //     0xb72600: ldurb           w16, [x2, #-1]
    //     0xb72604: ldurb           w17, [x0, #-1]
    //     0xb72608: and             x16, x17, x16, lsr #2
    //     0xb7260c: tst             x16, HEAP, lsr #32
    //     0xb72610: b.eq            #0xb72618
    //     0xb72614: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb72618: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xb72618: ldur            w0, [x2, #0x17]
    // 0xb7261c: DecompressPointer r0
    //     0xb7261c: add             x0, x0, HEAP, lsl #32
    // 0xb72620: cmp             w0, NULL
    // 0xb72624: b.eq            #0xb72780
    // 0xb72628: LoadField: r1 = r2->field_13
    //     0xb72628: ldur            w1, [x2, #0x13]
    // 0xb7262c: DecompressPointer r1
    //     0xb7262c: add             x1, x1, HEAP, lsl #32
    // 0xb72630: cmp             w1, NULL
    // 0xb72634: b.eq            #0xb72864
    // 0xb72638: r0 = LoadClassIdInstr(r1)
    //     0xb72638: ldur            x0, [x1, #-1]
    //     0xb7263c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72640: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72640: mov             x17, #0x4e2e
    //     0xb72644: movk            x17, #1, lsl #16
    //     0xb72648: add             lr, x0, x17
    //     0xb7264c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72650: blr             lr
    // 0xb72654: mov             x3, x0
    // 0xb72658: ldur            x2, [fp, #-8]
    // 0xb7265c: stur            x3, [fp, #-0x10]
    // 0xb72660: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb72660: ldur            w1, [x2, #0x17]
    // 0xb72664: DecompressPointer r1
    //     0xb72664: add             x1, x1, HEAP, lsl #32
    // 0xb72668: cmp             w1, NULL
    // 0xb7266c: b.eq            #0xb72868
    // 0xb72670: r0 = LoadClassIdInstr(r1)
    //     0xb72670: ldur            x0, [x1, #-1]
    //     0xb72674: ubfx            x0, x0, #0xc, #0x14
    // 0xb72678: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72678: mov             x17, #0x4e2e
    //     0xb7267c: movk            x17, #1, lsl #16
    //     0xb72680: add             lr, x0, x17
    //     0xb72684: ldr             lr, [x21, lr, lsl #3]
    //     0xb72688: blr             lr
    // 0xb7268c: mov             x1, x0
    // 0xb72690: ldur            x0, [fp, #-0x10]
    // 0xb72694: LoadField: d0 = r0->field_7
    //     0xb72694: ldur            d0, [x0, #7]
    // 0xb72698: LoadField: d1 = r1->field_7
    //     0xb72698: ldur            d1, [x1, #7]
    // 0xb7269c: fcmp            d0, d1
    // 0xb726a0: b.ne            #0xb726d8
    // 0xb726a4: ldur            x2, [fp, #-8]
    // 0xb726a8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xb726a8: ldur            w0, [x2, #0x17]
    // 0xb726ac: DecompressPointer r0
    //     0xb726ac: add             x0, x0, HEAP, lsl #32
    // 0xb726b0: StoreField: r2->field_13 = r0
    //     0xb726b0: stur            w0, [x2, #0x13]
    //     0xb726b4: ldurb           w16, [x2, #-1]
    //     0xb726b8: ldurb           w17, [x0, #-1]
    //     0xb726bc: and             x16, x17, x16, lsr #2
    //     0xb726c0: tst             x16, HEAP, lsr #32
    //     0xb726c4: b.eq            #0xb726cc
    //     0xb726c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb726cc: ArrayStore: r2[0] = rNULL  ; List_4
    //     0xb726cc: stur            NULL, [x2, #0x17]
    // 0xb726d0: mov             x0, x2
    // 0xb726d4: b               #0xb72784
    // 0xb726d8: ldur            x2, [fp, #-8]
    // 0xb726dc: LoadField: r1 = r2->field_13
    //     0xb726dc: ldur            w1, [x2, #0x13]
    // 0xb726e0: DecompressPointer r1
    //     0xb726e0: add             x1, x1, HEAP, lsl #32
    // 0xb726e4: cmp             w1, NULL
    // 0xb726e8: b.eq            #0xb7286c
    // 0xb726ec: r0 = LoadClassIdInstr(r1)
    //     0xb726ec: ldur            x0, [x1, #-1]
    //     0xb726f0: ubfx            x0, x0, #0xc, #0x14
    // 0xb726f4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb726f4: mov             x17, #0x4e2e
    //     0xb726f8: movk            x17, #1, lsl #16
    //     0xb726fc: add             lr, x0, x17
    //     0xb72700: ldr             lr, [x21, lr, lsl #3]
    //     0xb72704: blr             lr
    // 0xb72708: mov             x3, x0
    // 0xb7270c: ldur            x2, [fp, #-8]
    // 0xb72710: stur            x3, [fp, #-0x10]
    // 0xb72714: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb72714: ldur            w1, [x2, #0x17]
    // 0xb72718: DecompressPointer r1
    //     0xb72718: add             x1, x1, HEAP, lsl #32
    // 0xb7271c: cmp             w1, NULL
    // 0xb72720: b.eq            #0xb72870
    // 0xb72724: r0 = LoadClassIdInstr(r1)
    //     0xb72724: ldur            x0, [x1, #-1]
    //     0xb72728: ubfx            x0, x0, #0xc, #0x14
    // 0xb7272c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb7272c: mov             x17, #0x4e2e
    //     0xb72730: movk            x17, #1, lsl #16
    //     0xb72734: add             lr, x0, x17
    //     0xb72738: ldr             lr, [x21, lr, lsl #3]
    //     0xb7273c: blr             lr
    // 0xb72740: mov             x1, x0
    // 0xb72744: ldur            x0, [fp, #-0x10]
    // 0xb72748: LoadField: d0 = r0->field_7
    //     0xb72748: ldur            d0, [x0, #7]
    // 0xb7274c: LoadField: d1 = r1->field_7
    //     0xb7274c: ldur            d1, [x1, #7]
    // 0xb72750: fcmp            d0, d1
    // 0xb72754: b.le            #0xb7276c
    // 0xb72758: ldur            x0, [fp, #-8]
    // 0xb7275c: r1 = Instance__TrainHoppingMode
    //     0xb7275c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ed0] Obj!_TrainHoppingMode@12c60c1
    //     0xb72760: ldr             x1, [x1, #0xed0]
    // 0xb72764: StoreField: r0->field_1b = r1
    //     0xb72764: stur            w1, [x0, #0x1b]
    // 0xb72768: b               #0xb72784
    // 0xb7276c: ldur            x0, [fp, #-8]
    // 0xb72770: r1 = Instance__TrainHoppingMode
    //     0xb72770: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ed8] Obj!_TrainHoppingMode@12c60a1
    //     0xb72774: ldr             x1, [x1, #0xed8]
    // 0xb72778: StoreField: r0->field_1b = r1
    //     0xb72778: stur            w1, [x0, #0x1b]
    // 0xb7277c: b               #0xb72784
    // 0xb72780: mov             x0, x2
    // 0xb72784: LoadField: r3 = r0->field_13
    //     0xb72784: ldur            w3, [x0, #0x13]
    // 0xb72788: DecompressPointer r3
    //     0xb72788: add             x3, x3, HEAP, lsl #32
    // 0xb7278c: stur            x3, [fp, #-0x10]
    // 0xb72790: cmp             w3, NULL
    // 0xb72794: b.eq            #0xb72874
    // 0xb72798: mov             x2, x0
    // 0xb7279c: r1 = Function '_statusChangeHandler@63411118':.
    //     0xb7279c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26eb8] AnonymousClosure: (0xb72c48), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xb72bc8)
    //     0xb727a0: ldr             x1, [x1, #0xeb8]
    // 0xb727a4: r0 = AllocateClosure()
    //     0xb727a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb727a8: ldur            x1, [fp, #-0x10]
    // 0xb727ac: r2 = LoadClassIdInstr(r1)
    //     0xb727ac: ldur            x2, [x1, #-1]
    //     0xb727b0: ubfx            x2, x2, #0xc, #0x14
    // 0xb727b4: mov             x16, x0
    // 0xb727b8: mov             x0, x2
    // 0xb727bc: mov             x2, x16
    // 0xb727c0: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xb727c0: add             lr, x0, #0xbeb
    //     0xb727c4: ldr             lr, [x21, lr, lsl #3]
    //     0xb727c8: blr             lr
    // 0xb727cc: ldur            x0, [fp, #-8]
    // 0xb727d0: LoadField: r3 = r0->field_13
    //     0xb727d0: ldur            w3, [x0, #0x13]
    // 0xb727d4: DecompressPointer r3
    //     0xb727d4: add             x3, x3, HEAP, lsl #32
    // 0xb727d8: stur            x3, [fp, #-0x10]
    // 0xb727dc: cmp             w3, NULL
    // 0xb727e0: b.eq            #0xb72878
    // 0xb727e4: mov             x2, x0
    // 0xb727e8: r1 = Function '_valueChangeHandler@63411118':.
    //     0xb727e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ec0] AnonymousClosure: (0xb7287c), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xb728b4)
    //     0xb727ec: ldr             x1, [x1, #0xec0]
    // 0xb727f0: r0 = AllocateClosure()
    //     0xb727f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb727f4: mov             x3, x0
    // 0xb727f8: ldur            x1, [fp, #-0x10]
    // 0xb727fc: stur            x3, [fp, #-0x18]
    // 0xb72800: r0 = LoadClassIdInstr(r1)
    //     0xb72800: ldur            x0, [x1, #-1]
    //     0xb72804: ubfx            x0, x0, #0xc, #0x14
    // 0xb72808: mov             x2, x3
    // 0xb7280c: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xb7280c: mov             x17, #0xe0ec
    //     0xb72810: add             lr, x0, x17
    //     0xb72814: ldr             lr, [x21, lr, lsl #3]
    //     0xb72818: blr             lr
    // 0xb7281c: ldur            x0, [fp, #-8]
    // 0xb72820: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb72820: ldur            w1, [x0, #0x17]
    // 0xb72824: DecompressPointer r1
    //     0xb72824: add             x1, x1, HEAP, lsl #32
    // 0xb72828: cmp             w1, NULL
    // 0xb7282c: b.eq            #0xb7284c
    // 0xb72830: r0 = LoadClassIdInstr(r1)
    //     0xb72830: ldur            x0, [x1, #-1]
    //     0xb72834: ubfx            x0, x0, #0xc, #0x14
    // 0xb72838: ldur            x2, [fp, #-0x18]
    // 0xb7283c: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xb7283c: mov             x17, #0xe0ec
    //     0xb72840: add             lr, x0, x17
    //     0xb72844: ldr             lr, [x21, lr, lsl #3]
    //     0xb72848: blr             lr
    // 0xb7284c: r0 = Null
    //     0xb7284c: mov             x0, NULL
    // 0xb72850: LeaveFrame
    //     0xb72850: mov             SP, fp
    //     0xb72854: ldp             fp, lr, [SP], #0x10
    // 0xb72858: ret
    //     0xb72858: ret             
    // 0xb7285c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7285c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72860: b               #0xb72500
    // 0xb72864: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72864: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72868: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72868: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7286c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7286c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72870: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72874: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72878: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _valueChangeHandler(dynamic) {
    // ** addr: 0xb7287c, size: 0x38
    // 0xb7287c: EnterFrame
    //     0xb7287c: stp             fp, lr, [SP, #-0x10]!
    //     0xb72880: mov             fp, SP
    // 0xb72884: ldr             x0, [fp, #0x10]
    // 0xb72888: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb72888: ldur            w1, [x0, #0x17]
    // 0xb7288c: DecompressPointer r1
    //     0xb7288c: add             x1, x1, HEAP, lsl #32
    // 0xb72890: CheckStackOverflow
    //     0xb72890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb72894: cmp             SP, x16
    //     0xb72898: b.ls            #0xb728ac
    // 0xb7289c: r0 = _valueChangeHandler()
    //     0xb7289c: bl              #0xb728b4  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler
    // 0xb728a0: LeaveFrame
    //     0xb728a0: mov             SP, fp
    //     0xb728a4: ldp             fp, lr, [SP], #0x10
    // 0xb728a8: ret
    //     0xb728a8: ret             
    // 0xb728ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb728ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb728b0: b               #0xb7289c
  }
  _ _valueChangeHandler(/* No info */) {
    // ** addr: 0xb728b4, size: 0x314
    // 0xb728b4: EnterFrame
    //     0xb728b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb728b8: mov             fp, SP
    // 0xb728bc: AllocStack(0x30)
    //     0xb728bc: sub             SP, SP, #0x30
    // 0xb728c0: SetupParameters(TrainHoppingAnimation this /* r1 => r2, fp-0x8 */)
    //     0xb728c0: mov             x2, x1
    //     0xb728c4: stur            x1, [fp, #-8]
    // 0xb728c8: CheckStackOverflow
    //     0xb728c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb728cc: cmp             SP, x16
    //     0xb728d0: b.ls            #0xb72ba8
    // 0xb728d4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb728d4: ldur            w1, [x2, #0x17]
    // 0xb728d8: DecompressPointer r1
    //     0xb728d8: add             x1, x1, HEAP, lsl #32
    // 0xb728dc: cmp             w1, NULL
    // 0xb728e0: b.eq            #0xb72b08
    // 0xb728e4: LoadField: r0 = r2->field_1b
    //     0xb728e4: ldur            w0, [x2, #0x1b]
    // 0xb728e8: DecompressPointer r0
    //     0xb728e8: add             x0, x0, HEAP, lsl #32
    // 0xb728ec: cmp             w0, NULL
    // 0xb728f0: b.eq            #0xb72bb0
    // 0xb728f4: LoadField: r3 = r0->field_7
    //     0xb728f4: ldur            x3, [x0, #7]
    // 0xb728f8: cmp             x3, #0
    // 0xb728fc: b.gt            #0xb72978
    // 0xb72900: r0 = LoadClassIdInstr(r1)
    //     0xb72900: ldur            x0, [x1, #-1]
    //     0xb72904: ubfx            x0, x0, #0xc, #0x14
    // 0xb72908: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72908: mov             x17, #0x4e2e
    //     0xb7290c: movk            x17, #1, lsl #16
    //     0xb72910: add             lr, x0, x17
    //     0xb72914: ldr             lr, [x21, lr, lsl #3]
    //     0xb72918: blr             lr
    // 0xb7291c: mov             x3, x0
    // 0xb72920: ldur            x2, [fp, #-8]
    // 0xb72924: stur            x3, [fp, #-0x10]
    // 0xb72928: LoadField: r1 = r2->field_13
    //     0xb72928: ldur            w1, [x2, #0x13]
    // 0xb7292c: DecompressPointer r1
    //     0xb7292c: add             x1, x1, HEAP, lsl #32
    // 0xb72930: cmp             w1, NULL
    // 0xb72934: b.eq            #0xb72bb4
    // 0xb72938: r0 = LoadClassIdInstr(r1)
    //     0xb72938: ldur            x0, [x1, #-1]
    //     0xb7293c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72940: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72940: mov             x17, #0x4e2e
    //     0xb72944: movk            x17, #1, lsl #16
    //     0xb72948: add             lr, x0, x17
    //     0xb7294c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72950: blr             lr
    // 0xb72954: mov             x1, x0
    // 0xb72958: ldur            x0, [fp, #-0x10]
    // 0xb7295c: LoadField: d0 = r0->field_7
    //     0xb7295c: ldur            d0, [x0, #7]
    // 0xb72960: LoadField: d1 = r1->field_7
    //     0xb72960: ldur            d1, [x1, #7]
    // 0xb72964: fcmp            d1, d0
    // 0xb72968: r16 = true
    //     0xb72968: add             x16, NULL, #0x20  ; true
    // 0xb7296c: r17 = false
    //     0xb7296c: add             x17, NULL, #0x30  ; false
    // 0xb72970: csel            x0, x16, x17, ge
    // 0xb72974: b               #0xb729ec
    // 0xb72978: r0 = LoadClassIdInstr(r1)
    //     0xb72978: ldur            x0, [x1, #-1]
    //     0xb7297c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72980: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb72980: mov             x17, #0x4e2e
    //     0xb72984: movk            x17, #1, lsl #16
    //     0xb72988: add             lr, x0, x17
    //     0xb7298c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72990: blr             lr
    // 0xb72994: mov             x3, x0
    // 0xb72998: ldur            x2, [fp, #-8]
    // 0xb7299c: stur            x3, [fp, #-0x10]
    // 0xb729a0: LoadField: r1 = r2->field_13
    //     0xb729a0: ldur            w1, [x2, #0x13]
    // 0xb729a4: DecompressPointer r1
    //     0xb729a4: add             x1, x1, HEAP, lsl #32
    // 0xb729a8: cmp             w1, NULL
    // 0xb729ac: b.eq            #0xb72bb8
    // 0xb729b0: r0 = LoadClassIdInstr(r1)
    //     0xb729b0: ldur            x0, [x1, #-1]
    //     0xb729b4: ubfx            x0, x0, #0xc, #0x14
    // 0xb729b8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xb729b8: mov             x17, #0x4e2e
    //     0xb729bc: movk            x17, #1, lsl #16
    //     0xb729c0: add             lr, x0, x17
    //     0xb729c4: ldr             lr, [x21, lr, lsl #3]
    //     0xb729c8: blr             lr
    // 0xb729cc: mov             x1, x0
    // 0xb729d0: ldur            x0, [fp, #-0x10]
    // 0xb729d4: LoadField: d0 = r0->field_7
    //     0xb729d4: ldur            d0, [x0, #7]
    // 0xb729d8: LoadField: d1 = r1->field_7
    //     0xb729d8: ldur            d1, [x1, #7]
    // 0xb729dc: fcmp            d0, d1
    // 0xb729e0: r16 = true
    //     0xb729e0: add             x16, NULL, #0x20  ; true
    // 0xb729e4: r17 = false
    //     0xb729e4: add             x17, NULL, #0x30  ; false
    // 0xb729e8: csel            x0, x16, x17, ge
    // 0xb729ec: stur            x0, [fp, #-0x18]
    // 0xb729f0: tbnz            w0, #4, #0xb72b00
    // 0xb729f4: ldur            x3, [fp, #-8]
    // 0xb729f8: LoadField: r4 = r3->field_13
    //     0xb729f8: ldur            w4, [x3, #0x13]
    // 0xb729fc: DecompressPointer r4
    //     0xb729fc: add             x4, x4, HEAP, lsl #32
    // 0xb72a00: stur            x4, [fp, #-0x10]
    // 0xb72a04: cmp             w4, NULL
    // 0xb72a08: b.eq            #0xb72bbc
    // 0xb72a0c: mov             x2, x3
    // 0xb72a10: r1 = Function '_statusChangeHandler@63411118':.
    //     0xb72a10: add             x1, PP, #0x26, lsl #12  ; [pp+0x26eb8] AnonymousClosure: (0xb72c48), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xb72bc8)
    //     0xb72a14: ldr             x1, [x1, #0xeb8]
    // 0xb72a18: r0 = AllocateClosure()
    //     0xb72a18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb72a1c: mov             x4, x0
    // 0xb72a20: ldur            x3, [fp, #-0x10]
    // 0xb72a24: stur            x4, [fp, #-0x20]
    // 0xb72a28: r0 = LoadClassIdInstr(r3)
    //     0xb72a28: ldur            x0, [x3, #-1]
    //     0xb72a2c: ubfx            x0, x0, #0xc, #0x14
    // 0xb72a30: mov             x1, x3
    // 0xb72a34: mov             x2, x4
    // 0xb72a38: r0 = GDT[cid_x0 + 0xabe]()
    //     0xb72a38: add             lr, x0, #0xabe
    //     0xb72a3c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72a40: blr             lr
    // 0xb72a44: ldur            x2, [fp, #-8]
    // 0xb72a48: r1 = Function '_valueChangeHandler@63411118':.
    //     0xb72a48: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ec0] AnonymousClosure: (0xb7287c), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xb728b4)
    //     0xb72a4c: ldr             x1, [x1, #0xec0]
    // 0xb72a50: r0 = AllocateClosure()
    //     0xb72a50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb72a54: ldur            x1, [fp, #-0x10]
    // 0xb72a58: r2 = LoadClassIdInstr(r1)
    //     0xb72a58: ldur            x2, [x1, #-1]
    //     0xb72a5c: ubfx            x2, x2, #0xc, #0x14
    // 0xb72a60: mov             x16, x0
    // 0xb72a64: mov             x0, x2
    // 0xb72a68: mov             x2, x16
    // 0xb72a6c: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xb72a6c: mov             x17, #0xe2a3
    //     0xb72a70: add             lr, x0, x17
    //     0xb72a74: ldr             lr, [x21, lr, lsl #3]
    //     0xb72a78: blr             lr
    // 0xb72a7c: ldur            x3, [fp, #-8]
    // 0xb72a80: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xb72a80: ldur            w1, [x3, #0x17]
    // 0xb72a84: DecompressPointer r1
    //     0xb72a84: add             x1, x1, HEAP, lsl #32
    // 0xb72a88: mov             x0, x1
    // 0xb72a8c: StoreField: r3->field_13 = r0
    //     0xb72a8c: stur            w0, [x3, #0x13]
    //     0xb72a90: ldurb           w16, [x3, #-1]
    //     0xb72a94: ldurb           w17, [x0, #-1]
    //     0xb72a98: and             x16, x17, x16, lsr #2
    //     0xb72a9c: tst             x16, HEAP, lsr #32
    //     0xb72aa0: b.eq            #0xb72aa8
    //     0xb72aa4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb72aa8: ArrayStore: r3[0] = rNULL  ; List_4
    //     0xb72aa8: stur            NULL, [x3, #0x17]
    // 0xb72aac: cmp             w1, NULL
    // 0xb72ab0: b.eq            #0xb72bc0
    // 0xb72ab4: r0 = LoadClassIdInstr(r1)
    //     0xb72ab4: ldur            x0, [x1, #-1]
    //     0xb72ab8: ubfx            x0, x0, #0xc, #0x14
    // 0xb72abc: ldur            x2, [fp, #-0x20]
    // 0xb72ac0: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xb72ac0: add             lr, x0, #0xbeb
    //     0xb72ac4: ldr             lr, [x21, lr, lsl #3]
    //     0xb72ac8: blr             lr
    // 0xb72acc: ldur            x2, [fp, #-8]
    // 0xb72ad0: LoadField: r1 = r2->field_13
    //     0xb72ad0: ldur            w1, [x2, #0x13]
    // 0xb72ad4: DecompressPointer r1
    //     0xb72ad4: add             x1, x1, HEAP, lsl #32
    // 0xb72ad8: cmp             w1, NULL
    // 0xb72adc: b.eq            #0xb72bc4
    // 0xb72ae0: r0 = LoadClassIdInstr(r1)
    //     0xb72ae0: ldur            x0, [x1, #-1]
    //     0xb72ae4: ubfx            x0, x0, #0xc, #0x14
    // 0xb72ae8: r0 = GDT[cid_x0 + -0x52]()
    //     0xb72ae8: sub             lr, x0, #0x52
    //     0xb72aec: ldr             lr, [x21, lr, lsl #3]
    //     0xb72af0: blr             lr
    // 0xb72af4: ldur            x1, [fp, #-8]
    // 0xb72af8: mov             x2, x0
    // 0xb72afc: r0 = _statusChangeHandler()
    //     0xb72afc: bl              #0xb72bc8  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler
    // 0xb72b00: ldur            x2, [fp, #-0x18]
    // 0xb72b04: b               #0xb72b0c
    // 0xb72b08: r2 = false
    //     0xb72b08: add             x2, NULL, #0x30  ; false
    // 0xb72b0c: ldur            x0, [fp, #-8]
    // 0xb72b10: mov             x1, x0
    // 0xb72b14: stur            x2, [fp, #-0x10]
    // 0xb72b18: r0 = value()
    //     0xb72b18: bl              #0xae6624  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::value
    // 0xb72b1c: ldur            x1, [fp, #-8]
    // 0xb72b20: stur            x0, [fp, #-0x18]
    // 0xb72b24: LoadField: r2 = r1->field_27
    //     0xb72b24: ldur            w2, [x1, #0x27]
    // 0xb72b28: DecompressPointer r2
    //     0xb72b28: add             x2, x2, HEAP, lsl #32
    // 0xb72b2c: stp             x2, x0, [SP]
    // 0xb72b30: r0 = ==()
    //     0xb72b30: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xb72b34: tbz             w0, #4, #0xb72b6c
    // 0xb72b38: ldur            x0, [fp, #-8]
    // 0xb72b3c: mov             x1, x0
    // 0xb72b40: r0 = notifyListeners()
    //     0xb72b40: bl              #0x82e55c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0xb72b44: ldur            x0, [fp, #-0x18]
    // 0xb72b48: ldur            x1, [fp, #-8]
    // 0xb72b4c: StoreField: r1->field_27 = r0
    //     0xb72b4c: stur            w0, [x1, #0x27]
    //     0xb72b50: ldurb           w16, [x1, #-1]
    //     0xb72b54: ldurb           w17, [x0, #-1]
    //     0xb72b58: and             x16, x17, x16, lsr #2
    //     0xb72b5c: tst             x16, HEAP, lsr #32
    //     0xb72b60: b.eq            #0xb72b68
    //     0xb72b64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb72b68: b               #0xb72b70
    // 0xb72b6c: ldur            x1, [fp, #-8]
    // 0xb72b70: ldur            x0, [fp, #-0x10]
    // 0xb72b74: tbnz            w0, #4, #0xb72b98
    // 0xb72b78: LoadField: r0 = r1->field_1f
    //     0xb72b78: ldur            w0, [x1, #0x1f]
    // 0xb72b7c: DecompressPointer r0
    //     0xb72b7c: add             x0, x0, HEAP, lsl #32
    // 0xb72b80: cmp             w0, NULL
    // 0xb72b84: b.eq            #0xb72b98
    // 0xb72b88: str             x0, [SP]
    // 0xb72b8c: ClosureCall
    //     0xb72b8c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb72b90: ldur            x2, [x0, #0x1f]
    //     0xb72b94: blr             x2
    // 0xb72b98: r0 = Null
    //     0xb72b98: mov             x0, NULL
    // 0xb72b9c: LeaveFrame
    //     0xb72b9c: mov             SP, fp
    //     0xb72ba0: ldp             fp, lr, [SP], #0x10
    // 0xb72ba4: ret
    //     0xb72ba4: ret             
    // 0xb72ba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72ba8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72bac: b               #0xb728d4
    // 0xb72bb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72bb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72bb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72bbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72bc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb72bc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb72bc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _statusChangeHandler(/* No info */) {
    // ** addr: 0xb72bc8, size: 0x80
    // 0xb72bc8: EnterFrame
    //     0xb72bc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb72bcc: mov             fp, SP
    // 0xb72bd0: AllocStack(0x10)
    //     0xb72bd0: sub             SP, SP, #0x10
    // 0xb72bd4: SetupParameters(TrainHoppingAnimation this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb72bd4: mov             x3, x1
    //     0xb72bd8: mov             x0, x2
    //     0xb72bdc: stur            x1, [fp, #-8]
    //     0xb72be0: stur            x2, [fp, #-0x10]
    // 0xb72be4: CheckStackOverflow
    //     0xb72be4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb72be8: cmp             SP, x16
    //     0xb72bec: b.ls            #0xb72c40
    // 0xb72bf0: LoadField: r1 = r3->field_23
    //     0xb72bf0: ldur            w1, [x3, #0x23]
    // 0xb72bf4: DecompressPointer r1
    //     0xb72bf4: add             x1, x1, HEAP, lsl #32
    // 0xb72bf8: cmp             w0, w1
    // 0xb72bfc: b.eq            #0xb72c30
    // 0xb72c00: mov             x1, x3
    // 0xb72c04: mov             x2, x0
    // 0xb72c08: r0 = notifyStatusListeners()
    //     0xb72c08: bl              #0x829788  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0xb72c0c: ldur            x0, [fp, #-0x10]
    // 0xb72c10: ldur            x1, [fp, #-8]
    // 0xb72c14: StoreField: r1->field_23 = r0
    //     0xb72c14: stur            w0, [x1, #0x23]
    //     0xb72c18: ldurb           w16, [x1, #-1]
    //     0xb72c1c: ldurb           w17, [x0, #-1]
    //     0xb72c20: and             x16, x17, x16, lsr #2
    //     0xb72c24: tst             x16, HEAP, lsr #32
    //     0xb72c28: b.eq            #0xb72c30
    //     0xb72c2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb72c30: r0 = Null
    //     0xb72c30: mov             x0, NULL
    // 0xb72c34: LeaveFrame
    //     0xb72c34: mov             SP, fp
    //     0xb72c38: ldp             fp, lr, [SP], #0x10
    // 0xb72c3c: ret
    //     0xb72c3c: ret             
    // 0xb72c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72c44: b               #0xb72bf0
  }
  [closure] void _statusChangeHandler(dynamic, AnimationStatus) {
    // ** addr: 0xb72c48, size: 0x3c
    // 0xb72c48: EnterFrame
    //     0xb72c48: stp             fp, lr, [SP, #-0x10]!
    //     0xb72c4c: mov             fp, SP
    // 0xb72c50: ldr             x0, [fp, #0x18]
    // 0xb72c54: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb72c54: ldur            w1, [x0, #0x17]
    // 0xb72c58: DecompressPointer r1
    //     0xb72c58: add             x1, x1, HEAP, lsl #32
    // 0xb72c5c: CheckStackOverflow
    //     0xb72c5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb72c60: cmp             SP, x16
    //     0xb72c64: b.ls            #0xb72c7c
    // 0xb72c68: ldr             x2, [fp, #0x10]
    // 0xb72c6c: r0 = _statusChangeHandler()
    //     0xb72c6c: bl              #0xb72bc8  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler
    // 0xb72c70: LeaveFrame
    //     0xb72c70: mov             SP, fp
    //     0xb72c74: ldp             fp, lr, [SP], #0x10
    // 0xb72c78: ret
    //     0xb72c78: ret             
    // 0xb72c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72c7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72c80: b               #0xb72c68
  }
  _ dispose(/* No info */) {
    // ** addr: 0xb7363c, size: 0x12c
    // 0xb7363c: EnterFrame
    //     0xb7363c: stp             fp, lr, [SP, #-0x10]!
    //     0xb73640: mov             fp, SP
    // 0xb73644: AllocStack(0x18)
    //     0xb73644: sub             SP, SP, #0x18
    // 0xb73648: SetupParameters(TrainHoppingAnimation this /* r1 => r0, fp-0x10 */)
    //     0xb73648: mov             x0, x1
    //     0xb7364c: stur            x1, [fp, #-0x10]
    // 0xb73650: CheckStackOverflow
    //     0xb73650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb73654: cmp             SP, x16
    //     0xb73658: b.ls            #0xb73758
    // 0xb7365c: LoadField: r3 = r0->field_13
    //     0xb7365c: ldur            w3, [x0, #0x13]
    // 0xb73660: DecompressPointer r3
    //     0xb73660: add             x3, x3, HEAP, lsl #32
    // 0xb73664: stur            x3, [fp, #-8]
    // 0xb73668: cmp             w3, NULL
    // 0xb7366c: b.eq            #0xb73760
    // 0xb73670: mov             x2, x0
    // 0xb73674: r1 = Function '_statusChangeHandler@63411118':.
    //     0xb73674: add             x1, PP, #0x26, lsl #12  ; [pp+0x26eb8] AnonymousClosure: (0xb72c48), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xb72bc8)
    //     0xb73678: ldr             x1, [x1, #0xeb8]
    // 0xb7367c: r0 = AllocateClosure()
    //     0xb7367c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb73680: ldur            x1, [fp, #-8]
    // 0xb73684: r2 = LoadClassIdInstr(r1)
    //     0xb73684: ldur            x2, [x1, #-1]
    //     0xb73688: ubfx            x2, x2, #0xc, #0x14
    // 0xb7368c: mov             x16, x0
    // 0xb73690: mov             x0, x2
    // 0xb73694: mov             x2, x16
    // 0xb73698: r0 = GDT[cid_x0 + 0xabe]()
    //     0xb73698: add             lr, x0, #0xabe
    //     0xb7369c: ldr             lr, [x21, lr, lsl #3]
    //     0xb736a0: blr             lr
    // 0xb736a4: ldur            x0, [fp, #-0x10]
    // 0xb736a8: LoadField: r3 = r0->field_13
    //     0xb736a8: ldur            w3, [x0, #0x13]
    // 0xb736ac: DecompressPointer r3
    //     0xb736ac: add             x3, x3, HEAP, lsl #32
    // 0xb736b0: stur            x3, [fp, #-8]
    // 0xb736b4: cmp             w3, NULL
    // 0xb736b8: b.eq            #0xb73764
    // 0xb736bc: mov             x2, x0
    // 0xb736c0: r1 = Function '_valueChangeHandler@63411118':.
    //     0xb736c0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ec0] AnonymousClosure: (0xb7287c), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xb728b4)
    //     0xb736c4: ldr             x1, [x1, #0xec0]
    // 0xb736c8: r0 = AllocateClosure()
    //     0xb736c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb736cc: mov             x3, x0
    // 0xb736d0: ldur            x1, [fp, #-8]
    // 0xb736d4: stur            x3, [fp, #-0x18]
    // 0xb736d8: r0 = LoadClassIdInstr(r1)
    //     0xb736d8: ldur            x0, [x1, #-1]
    //     0xb736dc: ubfx            x0, x0, #0xc, #0x14
    // 0xb736e0: mov             x2, x3
    // 0xb736e4: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xb736e4: mov             x17, #0xe2a3
    //     0xb736e8: add             lr, x0, x17
    //     0xb736ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb736f0: blr             lr
    // 0xb736f4: ldur            x3, [fp, #-0x10]
    // 0xb736f8: StoreField: r3->field_13 = rNULL
    //     0xb736f8: stur            NULL, [x3, #0x13]
    // 0xb736fc: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xb736fc: ldur            w1, [x3, #0x17]
    // 0xb73700: DecompressPointer r1
    //     0xb73700: add             x1, x1, HEAP, lsl #32
    // 0xb73704: cmp             w1, NULL
    // 0xb73708: b.ne            #0xb73714
    // 0xb7370c: mov             x0, x3
    // 0xb73710: b               #0xb73734
    // 0xb73714: r0 = LoadClassIdInstr(r1)
    //     0xb73714: ldur            x0, [x1, #-1]
    //     0xb73718: ubfx            x0, x0, #0xc, #0x14
    // 0xb7371c: ldur            x2, [fp, #-0x18]
    // 0xb73720: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xb73720: mov             x17, #0xe2a3
    //     0xb73724: add             lr, x0, x17
    //     0xb73728: ldr             lr, [x21, lr, lsl #3]
    //     0xb7372c: blr             lr
    // 0xb73730: ldur            x0, [fp, #-0x10]
    // 0xb73734: ArrayStore: r0[0] = rNULL  ; List_4
    //     0xb73734: stur            NULL, [x0, #0x17]
    // 0xb73738: mov             x1, x0
    // 0xb7373c: r0 = clearListeners()
    //     0xb7373c: bl              #0x9165f0  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::clearListeners
    // 0xb73740: ldur            x1, [fp, #-0x10]
    // 0xb73744: r0 = clearStatusListeners()
    //     0xb73744: bl              #0x916668  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::clearStatusListeners
    // 0xb73748: r0 = Null
    //     0xb73748: mov             x0, NULL
    // 0xb7374c: LeaveFrame
    //     0xb7374c: mov             SP, fp
    //     0xb73750: ldp             fp, lr, [SP], #0x10
    // 0xb73754: ret
    //     0xb73754: ret             
    // 0xb73758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb73758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7375c: b               #0xb7365c
    // 0xb73760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb73760: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb73764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb73764: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284d0c, size: 0x5c
    // 0x1284d0c: EnterFrame
    //     0x1284d0c: stp             fp, lr, [SP, #-0x10]!
    //     0x1284d10: mov             fp, SP
    // 0x1284d14: CheckStackOverflow
    //     0x1284d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1284d18: cmp             SP, x16
    //     0x1284d1c: b.ls            #0x1284d5c
    // 0x1284d20: LoadField: r0 = r1->field_13
    //     0x1284d20: ldur            w0, [x1, #0x13]
    // 0x1284d24: DecompressPointer r0
    //     0x1284d24: add             x0, x0, HEAP, lsl #32
    // 0x1284d28: cmp             w0, NULL
    // 0x1284d2c: b.eq            #0x1284d64
    // 0x1284d30: r1 = LoadClassIdInstr(r0)
    //     0x1284d30: ldur            x1, [x0, #-1]
    //     0x1284d34: ubfx            x1, x1, #0xc, #0x14
    // 0x1284d38: mov             x16, x0
    // 0x1284d3c: mov             x0, x1
    // 0x1284d40: mov             x1, x16
    // 0x1284d44: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284d44: sub             lr, x0, #0x52
    //     0x1284d48: ldr             lr, [x21, lr, lsl #3]
    //     0x1284d4c: blr             lr
    // 0x1284d50: LeaveFrame
    //     0x1284d50: mov             SP, fp
    //     0x1284d54: ldp             fp, lr, [SP], #0x10
    // 0x1284d58: ret
    //     0x1284d58: ret             
    // 0x1284d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1284d5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1284d60: b               #0x1284d20
    // 0x1284d64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1284d64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4373, size: 0x1c, field offset: 0xc
class CurvedAnimation extends _MixinApplication113&Animation&AnimationWithParentMixin {

  _ CurvedAnimation(/* No info */) {
    // ** addr: 0x915be4, size: 0x144
    // 0x915be4: EnterFrame
    //     0x915be4: stp             fp, lr, [SP, #-0x10]!
    //     0x915be8: mov             fp, SP
    // 0x915bec: AllocStack(0x10)
    //     0x915bec: sub             SP, SP, #0x10
    // 0x915bf0: SetupParameters(CurvedAnimation this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x915bf0: stur            x1, [fp, #-8]
    //     0x915bf4: mov             x16, x2
    //     0x915bf8: mov             x2, x1
    //     0x915bfc: mov             x1, x16
    //     0x915c00: mov             x16, x3
    //     0x915c04: mov             x3, x2
    //     0x915c08: mov             x2, x16
    //     0x915c0c: stur            x2, [fp, #-0x10]
    // 0x915c10: LoadField: r0 = r4->field_13
    //     0x915c10: ldur            w0, [x4, #0x13]
    // 0x915c14: LoadField: r5 = r4->field_1f
    //     0x915c14: ldur            w5, [x4, #0x1f]
    // 0x915c18: DecompressPointer r5
    //     0x915c18: add             x5, x5, HEAP, lsl #32
    // 0x915c1c: r16 = "reverseCurve"
    //     0x915c1c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16dd8] "reverseCurve"
    //     0x915c20: ldr             x16, [x16, #0xdd8]
    // 0x915c24: cmp             w5, w16
    // 0x915c28: b.ne            #0x915c48
    // 0x915c2c: LoadField: r5 = r4->field_23
    //     0x915c2c: ldur            w5, [x4, #0x23]
    // 0x915c30: DecompressPointer r5
    //     0x915c30: add             x5, x5, HEAP, lsl #32
    // 0x915c34: sub             w4, w0, w5
    // 0x915c38: add             x0, fp, w4, sxtw #2
    // 0x915c3c: ldr             x0, [x0, #8]
    // 0x915c40: mov             x4, x0
    // 0x915c44: b               #0x915c4c
    // 0x915c48: r4 = Null
    //     0x915c48: mov             x4, NULL
    // 0x915c4c: CheckStackOverflow
    //     0x915c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x915c50: cmp             SP, x16
    //     0x915c54: b.ls            #0x915d20
    // 0x915c58: mov             x0, x2
    // 0x915c5c: StoreField: r3->field_b = r0
    //     0x915c5c: stur            w0, [x3, #0xb]
    //     0x915c60: ldurb           w16, [x3, #-1]
    //     0x915c64: ldurb           w17, [x0, #-1]
    //     0x915c68: and             x16, x17, x16, lsr #2
    //     0x915c6c: tst             x16, HEAP, lsr #32
    //     0x915c70: b.eq            #0x915c78
    //     0x915c74: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x915c78: mov             x0, x1
    // 0x915c7c: StoreField: r3->field_f = r0
    //     0x915c7c: stur            w0, [x3, #0xf]
    //     0x915c80: ldurb           w16, [x3, #-1]
    //     0x915c84: ldurb           w17, [x0, #-1]
    //     0x915c88: and             x16, x17, x16, lsr #2
    //     0x915c8c: tst             x16, HEAP, lsr #32
    //     0x915c90: b.eq            #0x915c98
    //     0x915c94: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x915c98: mov             x0, x4
    // 0x915c9c: StoreField: r3->field_13 = r0
    //     0x915c9c: stur            w0, [x3, #0x13]
    //     0x915ca0: ldurb           w16, [x3, #-1]
    //     0x915ca4: ldurb           w17, [x0, #-1]
    //     0x915ca8: and             x16, x17, x16, lsr #2
    //     0x915cac: tst             x16, HEAP, lsr #32
    //     0x915cb0: b.eq            #0x915cb8
    //     0x915cb4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x915cb8: r0 = LoadClassIdInstr(r2)
    //     0x915cb8: ldur            x0, [x2, #-1]
    //     0x915cbc: ubfx            x0, x0, #0xc, #0x14
    // 0x915cc0: mov             x1, x2
    // 0x915cc4: r0 = GDT[cid_x0 + -0x52]()
    //     0x915cc4: sub             lr, x0, #0x52
    //     0x915cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x915ccc: blr             lr
    // 0x915cd0: ldur            x1, [fp, #-8]
    // 0x915cd4: mov             x2, x0
    // 0x915cd8: r0 = _updateCurveDirection()
    //     0x915cd8: bl              #0x915d94  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection
    // 0x915cdc: ldur            x2, [fp, #-8]
    // 0x915ce0: r1 = Function '_updateCurveDirection@63411118':.
    //     0x915ce0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0x915ce4: ldr             x1, [x1, #0xde0]
    // 0x915ce8: r0 = AllocateClosure()
    //     0x915ce8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x915cec: ldur            x1, [fp, #-0x10]
    // 0x915cf0: r2 = LoadClassIdInstr(r1)
    //     0x915cf0: ldur            x2, [x1, #-1]
    //     0x915cf4: ubfx            x2, x2, #0xc, #0x14
    // 0x915cf8: mov             x16, x0
    // 0x915cfc: mov             x0, x2
    // 0x915d00: mov             x2, x16
    // 0x915d04: r0 = GDT[cid_x0 + 0xbeb]()
    //     0x915d04: add             lr, x0, #0xbeb
    //     0x915d08: ldr             lr, [x21, lr, lsl #3]
    //     0x915d0c: blr             lr
    // 0x915d10: r0 = Null
    //     0x915d10: mov             x0, NULL
    // 0x915d14: LeaveFrame
    //     0x915d14: mov             SP, fp
    //     0x915d18: ldp             fp, lr, [SP], #0x10
    // 0x915d1c: ret
    //     0x915d1c: ret             
    // 0x915d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x915d20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x915d24: b               #0x915c58
  }
  double dyn:get:value(CurvedAnimation) {
    // ** addr: 0x915d40, size: 0x48
    // 0x915d40: EnterFrame
    //     0x915d40: stp             fp, lr, [SP, #-0x10]!
    //     0x915d44: mov             fp, SP
    // 0x915d48: CheckStackOverflow
    //     0x915d48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x915d4c: cmp             SP, x16
    //     0x915d50: b.ls            #0x915d68
    // 0x915d54: ldr             x1, [fp, #0x10]
    // 0x915d58: r0 = value()
    //     0x915d58: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x915d5c: LeaveFrame
    //     0x915d5c: mov             SP, fp
    //     0x915d60: ldp             fp, lr, [SP], #0x10
    // 0x915d64: ret
    //     0x915d64: ret             
    // 0x915d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x915d68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x915d6c: b               #0x915d54
  }
  _ _updateCurveDirection(/* No info */) {
    // ** addr: 0x915d94, size: 0x7c
    // 0x915d94: r16 = Instance_AnimationStatus
    //     0x915d94: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x915d98: cmp             w2, w16
    // 0x915d9c: b.eq            #0x915dac
    // 0x915da0: r16 = Instance_AnimationStatus
    //     0x915da0: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0x915da4: cmp             w2, w16
    // 0x915da8: b.ne            #0x915dc8
    // 0x915dac: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x915dac: ldur            w3, [x1, #0x17]
    // 0x915db0: DecompressPointer r3
    //     0x915db0: add             x3, x3, HEAP, lsl #32
    // 0x915db4: cmp             w3, NULL
    // 0x915db8: b.ne            #0x915dc0
    // 0x915dbc: mov             x3, x2
    // 0x915dc0: mov             x0, x3
    // 0x915dc4: b               #0x915de4
    // 0x915dc8: r16 = Instance_AnimationStatus
    //     0x915dc8: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x915dcc: cmp             w2, w16
    // 0x915dd0: b.eq            #0x915de0
    // 0x915dd4: r16 = Instance_AnimationStatus
    //     0x915dd4: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x915dd8: cmp             w2, w16
    // 0x915ddc: b.eq            #0x915de0
    // 0x915de0: r0 = Null
    //     0x915de0: mov             x0, NULL
    // 0x915de4: ArrayStore: r1[0] = r0  ; List_4
    //     0x915de4: stur            w0, [x1, #0x17]
    //     0x915de8: ldurb           w16, [x1, #-1]
    //     0x915dec: ldurb           w17, [x0, #-1]
    //     0x915df0: and             x16, x17, x16, lsr #2
    //     0x915df4: tst             x16, HEAP, lsr #32
    //     0x915df8: b.eq            #0x915e08
    //     0x915dfc: str             lr, [SP, #-8]!
    //     0x915e00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x915e04: ldr             lr, [SP], #8
    // 0x915e08: r0 = Null
    //     0x915e08: mov             x0, NULL
    // 0x915e0c: ret
    //     0x915e0c: ret             
  }
  [closure] void _updateCurveDirection(dynamic, AnimationStatus) {
    // ** addr: 0x915e10, size: 0x3c
    // 0x915e10: EnterFrame
    //     0x915e10: stp             fp, lr, [SP, #-0x10]!
    //     0x915e14: mov             fp, SP
    // 0x915e18: ldr             x0, [fp, #0x18]
    // 0x915e1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x915e1c: ldur            w1, [x0, #0x17]
    // 0x915e20: DecompressPointer r1
    //     0x915e20: add             x1, x1, HEAP, lsl #32
    // 0x915e24: CheckStackOverflow
    //     0x915e24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x915e28: cmp             SP, x16
    //     0x915e2c: b.ls            #0x915e44
    // 0x915e30: ldr             x2, [fp, #0x10]
    // 0x915e34: r0 = _updateCurveDirection()
    //     0x915e34: bl              #0x915d94  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection
    // 0x915e38: LeaveFrame
    //     0x915e38: mov             SP, fp
    //     0x915e3c: ldp             fp, lr, [SP], #0x10
    // 0x915e40: ret
    //     0x915e40: ret             
    // 0x915e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x915e44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x915e48: b               #0x915e30
  }
  double value(CurvedAnimation) {
    // ** addr: 0xae5f84, size: 0x120
    // 0xae5f84: EnterFrame
    //     0xae5f84: stp             fp, lr, [SP, #-0x10]!
    //     0xae5f88: mov             fp, SP
    // 0xae5f8c: AllocStack(0x10)
    //     0xae5f8c: sub             SP, SP, #0x10
    // 0xae5f90: SetupParameters(CurvedAnimation this /* r1 => r0, fp-0x8 */)
    //     0xae5f90: mov             x0, x1
    //     0xae5f94: stur            x1, [fp, #-8]
    // 0xae5f98: CheckStackOverflow
    //     0xae5f98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae5f9c: cmp             SP, x16
    //     0xae5fa0: b.ls            #0xae608c
    // 0xae5fa4: mov             x1, x0
    // 0xae5fa8: r0 = _useForwardCurve()
    //     0xae5fa8: bl              #0xae60a4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_useForwardCurve
    // 0xae5fac: tbnz            w0, #4, #0xae5fc4
    // 0xae5fb0: ldur            x0, [fp, #-8]
    // 0xae5fb4: LoadField: r1 = r0->field_f
    //     0xae5fb4: ldur            w1, [x0, #0xf]
    // 0xae5fb8: DecompressPointer r1
    //     0xae5fb8: add             x1, x1, HEAP, lsl #32
    // 0xae5fbc: mov             x2, x1
    // 0xae5fc0: b               #0xae5fd4
    // 0xae5fc4: ldur            x0, [fp, #-8]
    // 0xae5fc8: LoadField: r1 = r0->field_13
    //     0xae5fc8: ldur            w1, [x0, #0x13]
    // 0xae5fcc: DecompressPointer r1
    //     0xae5fcc: add             x1, x1, HEAP, lsl #32
    // 0xae5fd0: mov             x2, x1
    // 0xae5fd4: stur            x2, [fp, #-0x10]
    // 0xae5fd8: LoadField: r1 = r0->field_b
    //     0xae5fd8: ldur            w1, [x0, #0xb]
    // 0xae5fdc: DecompressPointer r1
    //     0xae5fdc: add             x1, x1, HEAP, lsl #32
    // 0xae5fe0: r0 = LoadClassIdInstr(r1)
    //     0xae5fe0: ldur            x0, [x1, #-1]
    //     0xae5fe4: ubfx            x0, x0, #0xc, #0x14
    // 0xae5fe8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae5fe8: mov             x17, #0x4e2e
    //     0xae5fec: movk            x17, #1, lsl #16
    //     0xae5ff0: add             lr, x0, x17
    //     0xae5ff4: ldr             lr, [x21, lr, lsl #3]
    //     0xae5ff8: blr             lr
    // 0xae5ffc: ldur            x1, [fp, #-0x10]
    // 0xae6000: cmp             w1, NULL
    // 0xae6004: b.ne            #0xae6014
    // 0xae6008: LeaveFrame
    //     0xae6008: mov             SP, fp
    //     0xae600c: ldp             fp, lr, [SP], #0x10
    // 0xae6010: ret
    //     0xae6010: ret             
    // 0xae6014: d0 = 0.000000
    //     0xae6014: eor             v0.16b, v0.16b, v0.16b
    // 0xae6018: LoadField: d1 = r0->field_7
    //     0xae6018: ldur            d1, [x0, #7]
    // 0xae601c: fcmp            d1, d0
    // 0xae6020: b.eq            #0xae6030
    // 0xae6024: d0 = 1.000000
    //     0xae6024: fmov            d0, #1.00000000
    // 0xae6028: fcmp            d1, d0
    // 0xae602c: b.ne            #0xae603c
    // 0xae6030: LeaveFrame
    //     0xae6030: mov             SP, fp
    //     0xae6034: ldp             fp, lr, [SP], #0x10
    // 0xae6038: ret
    //     0xae6038: ret             
    // 0xae603c: r0 = LoadClassIdInstr(r1)
    //     0xae603c: ldur            x0, [x1, #-1]
    //     0xae6040: ubfx            x0, x0, #0xc, #0x14
    // 0xae6044: mov             v0.16b, v1.16b
    // 0xae6048: r0 = GDT[cid_x0 + -0x1000]()
    //     0xae6048: sub             lr, x0, #1, lsl #12
    //     0xae604c: ldr             lr, [x21, lr, lsl #3]
    //     0xae6050: blr             lr
    // 0xae6054: r0 = inline_Allocate_Double()
    //     0xae6054: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae6058: add             x0, x0, #0x10
    //     0xae605c: cmp             x1, x0
    //     0xae6060: b.ls            #0xae6094
    //     0xae6064: str             x0, [THR, #0x60]  ; THR::top
    //     0xae6068: sub             x0, x0, #0xf
    //     0xae606c: mov             x1, #0xe19c
    //     0xae6070: movk            x1, #3, lsl #16
    //     0xae6074: stur            x1, [x0, #-1]
    // 0xae6078: dmb             ishst
    // 0xae607c: StoreField: r0->field_7 = d0
    //     0xae607c: stur            d0, [x0, #7]
    // 0xae6080: LeaveFrame
    //     0xae6080: mov             SP, fp
    //     0xae6084: ldp             fp, lr, [SP], #0x10
    // 0xae6088: ret
    //     0xae6088: ret             
    // 0xae608c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae608c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae6090: b               #0xae5fa4
    // 0xae6094: SaveReg d0
    //     0xae6094: str             q0, [SP, #-0x10]!
    // 0xae6098: r0 = AllocateDouble()
    //     0xae6098: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae609c: RestoreReg d0
    //     0xae609c: ldr             q0, [SP], #0x10
    // 0xae60a0: b               #0xae607c
  }
  get _ _useForwardCurve(/* No info */) {
    // ** addr: 0xae60a4, size: 0x9c
    // 0xae60a4: EnterFrame
    //     0xae60a4: stp             fp, lr, [SP, #-0x10]!
    //     0xae60a8: mov             fp, SP
    // 0xae60ac: CheckStackOverflow
    //     0xae60ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae60b0: cmp             SP, x16
    //     0xae60b4: b.ls            #0xae6138
    // 0xae60b8: LoadField: r0 = r1->field_13
    //     0xae60b8: ldur            w0, [x1, #0x13]
    // 0xae60bc: DecompressPointer r0
    //     0xae60bc: add             x0, x0, HEAP, lsl #32
    // 0xae60c0: cmp             w0, NULL
    // 0xae60c4: b.ne            #0xae60d0
    // 0xae60c8: r0 = true
    //     0xae60c8: add             x0, NULL, #0x20  ; true
    // 0xae60cc: b               #0xae612c
    // 0xae60d0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xae60d0: ldur            w0, [x1, #0x17]
    // 0xae60d4: DecompressPointer r0
    //     0xae60d4: add             x0, x0, HEAP, lsl #32
    // 0xae60d8: cmp             w0, NULL
    // 0xae60dc: b.ne            #0xae6110
    // 0xae60e0: LoadField: r0 = r1->field_b
    //     0xae60e0: ldur            w0, [x1, #0xb]
    // 0xae60e4: DecompressPointer r0
    //     0xae60e4: add             x0, x0, HEAP, lsl #32
    // 0xae60e8: r1 = LoadClassIdInstr(r0)
    //     0xae60e8: ldur            x1, [x0, #-1]
    //     0xae60ec: ubfx            x1, x1, #0xc, #0x14
    // 0xae60f0: mov             x16, x0
    // 0xae60f4: mov             x0, x1
    // 0xae60f8: mov             x1, x16
    // 0xae60fc: r0 = GDT[cid_x0 + -0x52]()
    //     0xae60fc: sub             lr, x0, #0x52
    //     0xae6100: ldr             lr, [x21, lr, lsl #3]
    //     0xae6104: blr             lr
    // 0xae6108: mov             x1, x0
    // 0xae610c: b               #0xae6114
    // 0xae6110: mov             x1, x0
    // 0xae6114: r16 = Instance_AnimationStatus
    //     0xae6114: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xae6118: cmp             w1, w16
    // 0xae611c: r16 = true
    //     0xae611c: add             x16, NULL, #0x20  ; true
    // 0xae6120: r17 = false
    //     0xae6120: add             x17, NULL, #0x30  ; false
    // 0xae6124: csel            x2, x16, x17, ne
    // 0xae6128: mov             x0, x2
    // 0xae612c: LeaveFrame
    //     0xae612c: mov             SP, fp
    //     0xae6130: ldp             fp, lr, [SP], #0x10
    // 0xae6134: ret
    //     0xae6134: ret             
    // 0xae6138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae6138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae613c: b               #0xae60b8
  }
  _ dispose(/* No info */) {
    // ** addr: 0xb29014, size: 0x70
    // 0xb29014: EnterFrame
    //     0xb29014: stp             fp, lr, [SP, #-0x10]!
    //     0xb29018: mov             fp, SP
    // 0xb2901c: AllocStack(0x8)
    //     0xb2901c: sub             SP, SP, #8
    // 0xb29020: SetupParameters(CurvedAnimation this /* r1 => r2 */)
    //     0xb29020: mov             x2, x1
    // 0xb29024: CheckStackOverflow
    //     0xb29024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29028: cmp             SP, x16
    //     0xb2902c: b.ls            #0xb2907c
    // 0xb29030: LoadField: r0 = r2->field_b
    //     0xb29030: ldur            w0, [x2, #0xb]
    // 0xb29034: DecompressPointer r0
    //     0xb29034: add             x0, x0, HEAP, lsl #32
    // 0xb29038: stur            x0, [fp, #-8]
    // 0xb2903c: r1 = Function '_updateCurveDirection@63411118':.
    //     0xb2903c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0xb29040: ldr             x1, [x1, #0xde0]
    // 0xb29044: r0 = AllocateClosure()
    //     0xb29044: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb29048: ldur            x1, [fp, #-8]
    // 0xb2904c: r2 = LoadClassIdInstr(r1)
    //     0xb2904c: ldur            x2, [x1, #-1]
    //     0xb29050: ubfx            x2, x2, #0xc, #0x14
    // 0xb29054: mov             x16, x0
    // 0xb29058: mov             x0, x2
    // 0xb2905c: mov             x2, x16
    // 0xb29060: r0 = GDT[cid_x0 + 0xabe]()
    //     0xb29060: add             lr, x0, #0xabe
    //     0xb29064: ldr             lr, [x21, lr, lsl #3]
    //     0xb29068: blr             lr
    // 0xb2906c: r0 = Null
    //     0xb2906c: mov             x0, NULL
    // 0xb29070: LeaveFrame
    //     0xb29070: mov             SP, fp
    //     0xb29074: ldp             fp, lr, [SP], #0x10
    // 0xb29078: ret
    //     0xb29078: ret             
    // 0xb2907c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2907c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29080: b               #0xb29030
  }
}

// class id: 4377, size: 0x2c, field offset: 0x1c
abstract class CompoundAnimation<X0> extends _MixinApplication69&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin<X0> {

  const Animation<X0> dyn:get:next(CompoundAnimation<X0>) {
    // ** addr: 0x855324, size: 0x28
    // 0x855324: ldr             x1, [SP]
    // 0x855328: LoadField: r0 = r1->field_1f
    //     0x855328: ldur            w0, [x1, #0x1f]
    // 0x85532c: DecompressPointer r0
    //     0x85532c: add             x0, x0, HEAP, lsl #32
    // 0x855330: ret
    //     0x855330: ret             
  }
  _ didStopListening(/* No info */) {
    // ** addr: 0x11d4de8, size: 0x100
    // 0x11d4de8: EnterFrame
    //     0x11d4de8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d4dec: mov             fp, SP
    // 0x11d4df0: AllocStack(0x20)
    //     0x11d4df0: sub             SP, SP, #0x20
    // 0x11d4df4: SetupParameters(CompoundAnimation<X0> this /* r1 => r0, fp-0x10 */)
    //     0x11d4df4: mov             x0, x1
    //     0x11d4df8: stur            x1, [fp, #-0x10]
    // 0x11d4dfc: CheckStackOverflow
    //     0x11d4dfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d4e00: cmp             SP, x16
    //     0x11d4e04: b.ls            #0x11d4ee0
    // 0x11d4e08: LoadField: r3 = r0->field_1b
    //     0x11d4e08: ldur            w3, [x0, #0x1b]
    // 0x11d4e0c: DecompressPointer r3
    //     0x11d4e0c: add             x3, x3, HEAP, lsl #32
    // 0x11d4e10: mov             x2, x0
    // 0x11d4e14: stur            x3, [fp, #-8]
    // 0x11d4e18: r1 = Function '_maybeNotifyListeners@63411118':.
    //     0x11d4e18: add             x1, PP, #0x99, lsl #12  ; [pp+0x99828] AnonymousClosure: (0x11d5258), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0x11d5290)
    //     0x11d4e1c: ldr             x1, [x1, #0x828]
    // 0x11d4e20: r0 = AllocateClosure()
    //     0x11d4e20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11d4e24: mov             x4, x0
    // 0x11d4e28: ldur            x3, [fp, #-8]
    // 0x11d4e2c: stur            x4, [fp, #-0x18]
    // 0x11d4e30: r0 = LoadClassIdInstr(r3)
    //     0x11d4e30: ldur            x0, [x3, #-1]
    //     0x11d4e34: ubfx            x0, x0, #0xc, #0x14
    // 0x11d4e38: mov             x1, x3
    // 0x11d4e3c: mov             x2, x4
    // 0x11d4e40: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x11d4e40: mov             x17, #0xe2a3
    //     0x11d4e44: add             lr, x0, x17
    //     0x11d4e48: ldr             lr, [x21, lr, lsl #3]
    //     0x11d4e4c: blr             lr
    // 0x11d4e50: ldur            x2, [fp, #-0x10]
    // 0x11d4e54: r1 = Function '_maybeNotifyStatusListeners@63411118':.
    //     0x11d4e54: add             x1, PP, #0x99, lsl #12  ; [pp+0x99830] AnonymousClosure: (0x11d4ee8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0x11d4f24)
    //     0x11d4e58: ldr             x1, [x1, #0x830]
    // 0x11d4e5c: r0 = AllocateClosure()
    //     0x11d4e5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11d4e60: mov             x3, x0
    // 0x11d4e64: ldur            x1, [fp, #-8]
    // 0x11d4e68: stur            x3, [fp, #-0x20]
    // 0x11d4e6c: r0 = LoadClassIdInstr(r1)
    //     0x11d4e6c: ldur            x0, [x1, #-1]
    //     0x11d4e70: ubfx            x0, x0, #0xc, #0x14
    // 0x11d4e74: mov             x2, x3
    // 0x11d4e78: r0 = GDT[cid_x0 + 0xabe]()
    //     0x11d4e78: add             lr, x0, #0xabe
    //     0x11d4e7c: ldr             lr, [x21, lr, lsl #3]
    //     0x11d4e80: blr             lr
    // 0x11d4e84: ldur            x0, [fp, #-0x10]
    // 0x11d4e88: LoadField: r3 = r0->field_1f
    //     0x11d4e88: ldur            w3, [x0, #0x1f]
    // 0x11d4e8c: DecompressPointer r3
    //     0x11d4e8c: add             x3, x3, HEAP, lsl #32
    // 0x11d4e90: stur            x3, [fp, #-8]
    // 0x11d4e94: r0 = LoadClassIdInstr(r3)
    //     0x11d4e94: ldur            x0, [x3, #-1]
    //     0x11d4e98: ubfx            x0, x0, #0xc, #0x14
    // 0x11d4e9c: mov             x1, x3
    // 0x11d4ea0: ldur            x2, [fp, #-0x18]
    // 0x11d4ea4: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x11d4ea4: mov             x17, #0xe2a3
    //     0x11d4ea8: add             lr, x0, x17
    //     0x11d4eac: ldr             lr, [x21, lr, lsl #3]
    //     0x11d4eb0: blr             lr
    // 0x11d4eb4: ldur            x1, [fp, #-8]
    // 0x11d4eb8: r0 = LoadClassIdInstr(r1)
    //     0x11d4eb8: ldur            x0, [x1, #-1]
    //     0x11d4ebc: ubfx            x0, x0, #0xc, #0x14
    // 0x11d4ec0: ldur            x2, [fp, #-0x20]
    // 0x11d4ec4: r0 = GDT[cid_x0 + 0xabe]()
    //     0x11d4ec4: add             lr, x0, #0xabe
    //     0x11d4ec8: ldr             lr, [x21, lr, lsl #3]
    //     0x11d4ecc: blr             lr
    // 0x11d4ed0: r0 = Null
    //     0x11d4ed0: mov             x0, NULL
    // 0x11d4ed4: LeaveFrame
    //     0x11d4ed4: mov             SP, fp
    //     0x11d4ed8: ldp             fp, lr, [SP], #0x10
    // 0x11d4edc: ret
    //     0x11d4edc: ret             
    // 0x11d4ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d4ee0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d4ee4: b               #0x11d4e08
  }
  [closure] void _maybeNotifyStatusListeners(dynamic, AnimationStatus) {
    // ** addr: 0x11d4ee8, size: 0x3c
    // 0x11d4ee8: EnterFrame
    //     0x11d4ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d4eec: mov             fp, SP
    // 0x11d4ef0: ldr             x0, [fp, #0x18]
    // 0x11d4ef4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11d4ef4: ldur            w1, [x0, #0x17]
    // 0x11d4ef8: DecompressPointer r1
    //     0x11d4ef8: add             x1, x1, HEAP, lsl #32
    // 0x11d4efc: CheckStackOverflow
    //     0x11d4efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d4f00: cmp             SP, x16
    //     0x11d4f04: b.ls            #0x11d4f1c
    // 0x11d4f08: ldr             x2, [fp, #0x10]
    // 0x11d4f0c: r0 = _maybeNotifyStatusListeners()
    //     0x11d4f0c: bl              #0x11d4f24  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners
    // 0x11d4f10: LeaveFrame
    //     0x11d4f10: mov             SP, fp
    //     0x11d4f14: ldp             fp, lr, [SP], #0x10
    // 0x11d4f18: ret
    //     0x11d4f18: ret             
    // 0x11d4f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d4f1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d4f20: b               #0x11d4f08
  }
  _ _maybeNotifyStatusListeners(/* No info */) {
    // ** addr: 0x11d4f24, size: 0x94
    // 0x11d4f24: EnterFrame
    //     0x11d4f24: stp             fp, lr, [SP, #-0x10]!
    //     0x11d4f28: mov             fp, SP
    // 0x11d4f2c: AllocStack(0x8)
    //     0x11d4f2c: sub             SP, SP, #8
    // 0x11d4f30: SetupParameters(CompoundAnimation<X0> this /* r1 => r0, fp-0x8 */)
    //     0x11d4f30: mov             x0, x1
    //     0x11d4f34: stur            x1, [fp, #-8]
    // 0x11d4f38: CheckStackOverflow
    //     0x11d4f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d4f3c: cmp             SP, x16
    //     0x11d4f40: b.ls            #0x11d4fb0
    // 0x11d4f44: mov             x1, x0
    // 0x11d4f48: r0 = status()
    //     0x11d4f48: bl              #0x1284a0c  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0x11d4f4c: mov             x1, x0
    // 0x11d4f50: ldur            x0, [fp, #-8]
    // 0x11d4f54: LoadField: r2 = r0->field_23
    //     0x11d4f54: ldur            w2, [x0, #0x23]
    // 0x11d4f58: DecompressPointer r2
    //     0x11d4f58: add             x2, x2, HEAP, lsl #32
    // 0x11d4f5c: cmp             w1, w2
    // 0x11d4f60: b.eq            #0x11d4fa0
    // 0x11d4f64: mov             x1, x0
    // 0x11d4f68: r0 = status()
    //     0x11d4f68: bl              #0x1284a0c  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0x11d4f6c: ldur            x2, [fp, #-8]
    // 0x11d4f70: StoreField: r2->field_23 = r0
    //     0x11d4f70: stur            w0, [x2, #0x23]
    //     0x11d4f74: ldurb           w16, [x2, #-1]
    //     0x11d4f78: ldurb           w17, [x0, #-1]
    //     0x11d4f7c: and             x16, x17, x16, lsr #2
    //     0x11d4f80: tst             x16, HEAP, lsr #32
    //     0x11d4f84: b.eq            #0x11d4f8c
    //     0x11d4f88: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d4f8c: mov             x1, x2
    // 0x11d4f90: r0 = status()
    //     0x11d4f90: bl              #0x1284a0c  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0x11d4f94: ldur            x1, [fp, #-8]
    // 0x11d4f98: mov             x2, x0
    // 0x11d4f9c: r0 = notifyStatusListeners()
    //     0x11d4f9c: bl              #0x11d4fb8  ; [dart:mixin_deduplication] _MixinApplication69&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x11d4fa0: r0 = Null
    //     0x11d4fa0: mov             x0, NULL
    // 0x11d4fa4: LeaveFrame
    //     0x11d4fa4: mov             SP, fp
    //     0x11d4fa8: ldp             fp, lr, [SP], #0x10
    // 0x11d4fac: ret
    //     0x11d4fac: ret             
    // 0x11d4fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d4fb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d4fb4: b               #0x11d4f44
  }
  [closure] void _maybeNotifyListeners(dynamic) {
    // ** addr: 0x11d5258, size: 0x38
    // 0x11d5258: EnterFrame
    //     0x11d5258: stp             fp, lr, [SP, #-0x10]!
    //     0x11d525c: mov             fp, SP
    // 0x11d5260: ldr             x0, [fp, #0x10]
    // 0x11d5264: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11d5264: ldur            w1, [x0, #0x17]
    // 0x11d5268: DecompressPointer r1
    //     0x11d5268: add             x1, x1, HEAP, lsl #32
    // 0x11d526c: CheckStackOverflow
    //     0x11d526c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d5270: cmp             SP, x16
    //     0x11d5274: b.ls            #0x11d5288
    // 0x11d5278: r0 = _maybeNotifyListeners()
    //     0x11d5278: bl              #0x11d5290  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners
    // 0x11d527c: LeaveFrame
    //     0x11d527c: mov             SP, fp
    //     0x11d5280: ldp             fp, lr, [SP], #0x10
    // 0x11d5284: ret
    //     0x11d5284: ret             
    // 0x11d5288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d5288: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d528c: b               #0x11d5278
  }
  _ _maybeNotifyListeners(/* No info */) {
    // ** addr: 0x11d5290, size: 0x5dc
    // 0x11d5290: EnterFrame
    //     0x11d5290: stp             fp, lr, [SP, #-0x10]!
    //     0x11d5294: mov             fp, SP
    // 0x11d5298: AllocStack(0x40)
    //     0x11d5298: sub             SP, SP, #0x40
    // 0x11d529c: SetupParameters(CompoundAnimation<X0> this /* r1 => r2, fp-0x10 */)
    //     0x11d529c: mov             x2, x1
    //     0x11d52a0: stur            x1, [fp, #-0x10]
    // 0x11d52a4: CheckStackOverflow
    //     0x11d52a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d52a8: cmp             SP, x16
    //     0x11d52ac: b.ls            #0x11d582c
    // 0x11d52b0: r3 = LoadClassIdInstr(r2)
    //     0x11d52b0: ldur            x3, [x2, #-1]
    //     0x11d52b4: ubfx            x3, x3, #0xc, #0x14
    // 0x11d52b8: stur            x3, [fp, #-8]
    // 0x11d52bc: r17 = 4378
    //     0x11d52bc: mov             x17, #0x111a
    // 0x11d52c0: cmp             x3, x17
    // 0x11d52c4: b.ne            #0x11d5344
    // 0x11d52c8: d0 = 0.500000
    //     0x11d52c8: fmov            d0, #0.50000000
    // 0x11d52cc: LoadField: r0 = r2->field_2b
    //     0x11d52cc: ldur            w0, [x2, #0x2b]
    // 0x11d52d0: DecompressPointer r0
    //     0x11d52d0: add             x0, x0, HEAP, lsl #32
    // 0x11d52d4: LoadField: r1 = r0->field_37
    //     0x11d52d4: ldur            w1, [x0, #0x37]
    // 0x11d52d8: DecompressPointer r1
    //     0x11d52d8: add             x1, x1, HEAP, lsl #32
    // 0x11d52dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d52e0: cmp             w1, w16
    // 0x11d52e4: b.eq            #0x11d5834
    // 0x11d52e8: LoadField: d1 = r1->field_7
    //     0x11d52e8: ldur            d1, [x1, #7]
    // 0x11d52ec: fcmp            d0, d1
    // 0x11d52f0: b.le            #0x11d531c
    // 0x11d52f4: LoadField: r1 = r2->field_1b
    //     0x11d52f4: ldur            w1, [x2, #0x1b]
    // 0x11d52f8: DecompressPointer r1
    //     0x11d52f8: add             x1, x1, HEAP, lsl #32
    // 0x11d52fc: r0 = LoadClassIdInstr(r1)
    //     0x11d52fc: ldur            x0, [x1, #-1]
    //     0x11d5300: ubfx            x0, x0, #0xc, #0x14
    // 0x11d5304: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d5304: mov             x17, #0x4e2e
    //     0x11d5308: movk            x17, #1, lsl #16
    //     0x11d530c: add             lr, x0, x17
    //     0x11d5310: ldr             lr, [x21, lr, lsl #3]
    //     0x11d5314: blr             lr
    // 0x11d5318: b               #0x11d5538
    // 0x11d531c: LoadField: r1 = r2->field_1f
    //     0x11d531c: ldur            w1, [x2, #0x1f]
    // 0x11d5320: DecompressPointer r1
    //     0x11d5320: add             x1, x1, HEAP, lsl #32
    // 0x11d5324: r0 = LoadClassIdInstr(r1)
    //     0x11d5324: ldur            x0, [x1, #-1]
    //     0x11d5328: ubfx            x0, x0, #0xc, #0x14
    // 0x11d532c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d532c: mov             x17, #0x4e2e
    //     0x11d5330: movk            x17, #1, lsl #16
    //     0x11d5334: add             lr, x0, x17
    //     0x11d5338: ldr             lr, [x21, lr, lsl #3]
    //     0x11d533c: blr             lr
    // 0x11d5340: b               #0x11d5538
    // 0x11d5344: LoadField: r3 = r2->field_7
    //     0x11d5344: ldur            w3, [x2, #7]
    // 0x11d5348: DecompressPointer r3
    //     0x11d5348: add             x3, x3, HEAP, lsl #32
    // 0x11d534c: stur            x3, [fp, #-0x18]
    // 0x11d5350: LoadField: r1 = r2->field_1b
    //     0x11d5350: ldur            w1, [x2, #0x1b]
    // 0x11d5354: DecompressPointer r1
    //     0x11d5354: add             x1, x1, HEAP, lsl #32
    // 0x11d5358: r0 = LoadClassIdInstr(r1)
    //     0x11d5358: ldur            x0, [x1, #-1]
    //     0x11d535c: ubfx            x0, x0, #0xc, #0x14
    // 0x11d5360: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d5360: mov             x17, #0x4e2e
    //     0x11d5364: movk            x17, #1, lsl #16
    //     0x11d5368: add             lr, x0, x17
    //     0x11d536c: ldr             lr, [x21, lr, lsl #3]
    //     0x11d5370: blr             lr
    // 0x11d5374: mov             x3, x0
    // 0x11d5378: ldur            x2, [fp, #-0x10]
    // 0x11d537c: stur            x3, [fp, #-0x20]
    // 0x11d5380: LoadField: r1 = r2->field_1f
    //     0x11d5380: ldur            w1, [x2, #0x1f]
    // 0x11d5384: DecompressPointer r1
    //     0x11d5384: add             x1, x1, HEAP, lsl #32
    // 0x11d5388: r0 = LoadClassIdInstr(r1)
    //     0x11d5388: ldur            x0, [x1, #-1]
    //     0x11d538c: ubfx            x0, x0, #0xc, #0x14
    // 0x11d5390: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d5390: mov             x17, #0x4e2e
    //     0x11d5394: movk            x17, #1, lsl #16
    //     0x11d5398: add             lr, x0, x17
    //     0x11d539c: ldr             lr, [x21, lr, lsl #3]
    //     0x11d53a0: blr             lr
    // 0x11d53a4: mov             x2, x0
    // 0x11d53a8: ldur            x1, [fp, #-0x20]
    // 0x11d53ac: stur            x2, [fp, #-0x28]
    // 0x11d53b0: r0 = 60
    //     0x11d53b0: mov             x0, #0x3c
    // 0x11d53b4: branchIfSmi(r1, 0x11d53c0)
    //     0x11d53b4: tbz             w1, #0, #0x11d53c0
    // 0x11d53b8: r0 = LoadClassIdInstr(r1)
    //     0x11d53b8: ldur            x0, [x1, #-1]
    //     0x11d53bc: ubfx            x0, x0, #0xc, #0x14
    // 0x11d53c0: stp             x2, x1, [SP]
    // 0x11d53c4: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x11d53c4: sub             lr, x0, #0xfe5
    //     0x11d53c8: ldr             lr, [x21, lr, lsl #3]
    //     0x11d53cc: blr             lr
    // 0x11d53d0: tbnz            w0, #4, #0x11d53dc
    // 0x11d53d4: ldur            x0, [fp, #-0x28]
    // 0x11d53d8: b               #0x11d5538
    // 0x11d53dc: ldur            x1, [fp, #-0x20]
    // 0x11d53e0: r0 = 60
    //     0x11d53e0: mov             x0, #0x3c
    // 0x11d53e4: branchIfSmi(r1, 0x11d53f0)
    //     0x11d53e4: tbz             w1, #0, #0x11d53f0
    // 0x11d53e8: r0 = LoadClassIdInstr(r1)
    //     0x11d53e8: ldur            x0, [x1, #-1]
    //     0x11d53ec: ubfx            x0, x0, #0xc, #0x14
    // 0x11d53f0: ldur            x16, [fp, #-0x28]
    // 0x11d53f4: stp             x16, x1, [SP]
    // 0x11d53f8: r0 = GDT[cid_x0 + -0xfe8]()
    //     0x11d53f8: sub             lr, x0, #0xfe8
    //     0x11d53fc: ldr             lr, [x21, lr, lsl #3]
    //     0x11d5400: blr             lr
    // 0x11d5404: tbnz            w0, #4, #0x11d5410
    // 0x11d5408: ldur            x0, [fp, #-0x20]
    // 0x11d540c: b               #0x11d5538
    // 0x11d5410: ldur            x1, [fp, #-0x28]
    // 0x11d5414: r0 = 60
    //     0x11d5414: mov             x0, #0x3c
    // 0x11d5418: branchIfSmi(r1, 0x11d5424)
    //     0x11d5418: tbz             w1, #0, #0x11d5424
    // 0x11d541c: r0 = LoadClassIdInstr(r1)
    //     0x11d541c: ldur            x0, [x1, #-1]
    //     0x11d5420: ubfx            x0, x0, #0xc, #0x14
    // 0x11d5424: cmp             x0, #0x3e
    // 0x11d5428: b.ne            #0x11d5534
    // 0x11d542c: ldur            x2, [fp, #-0x20]
    // 0x11d5430: r0 = 60
    //     0x11d5430: mov             x0, #0x3c
    // 0x11d5434: branchIfSmi(r2, 0x11d5440)
    //     0x11d5434: tbz             w2, #0, #0x11d5440
    // 0x11d5438: r0 = LoadClassIdInstr(r2)
    //     0x11d5438: ldur            x0, [x2, #-1]
    //     0x11d543c: ubfx            x0, x0, #0xc, #0x14
    // 0x11d5440: cmp             x0, #0x3e
    // 0x11d5444: b.ne            #0x11d54d4
    // 0x11d5448: d0 = 0.000000
    //     0x11d5448: eor             v0.16b, v0.16b, v0.16b
    // 0x11d544c: LoadField: d1 = r2->field_7
    //     0x11d544c: ldur            d1, [x2, #7]
    // 0x11d5450: fcmp            d1, d0
    // 0x11d5454: b.ne            #0x11d54d4
    // 0x11d5458: LoadField: d2 = r1->field_7
    //     0x11d5458: ldur            d2, [x1, #7]
    // 0x11d545c: fadd            d3, d1, d2
    // 0x11d5460: fmul            d4, d3, d1
    // 0x11d5464: fmul            d1, d4, d2
    // 0x11d5468: r3 = inline_Allocate_Double()
    //     0x11d5468: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x11d546c: add             x3, x3, #0x10
    //     0x11d5470: cmp             x0, x3
    //     0x11d5474: b.ls            #0x11d583c
    //     0x11d5478: str             x3, [THR, #0x60]  ; THR::top
    //     0x11d547c: sub             x3, x3, #0xf
    //     0x11d5480: mov             x0, #0xe19c
    //     0x11d5484: movk            x0, #3, lsl #16
    //     0x11d5488: stur            x0, [x3, #-1]
    // 0x11d548c: dmb             ishst
    // 0x11d5490: StoreField: r3->field_7 = d1
    //     0x11d5490: stur            d1, [x3, #7]
    // 0x11d5494: mov             x0, x3
    // 0x11d5498: ldur            x1, [fp, #-0x18]
    // 0x11d549c: stur            x3, [fp, #-0x30]
    // 0x11d54a0: r2 = Null
    //     0x11d54a0: mov             x2, NULL
    // 0x11d54a4: cmp             w1, NULL
    // 0x11d54a8: b.eq            #0x11d54cc
    // 0x11d54ac: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x11d54ac: ldur            w4, [x1, #0x17]
    // 0x11d54b0: DecompressPointer r4
    //     0x11d54b0: add             x4, x4, HEAP, lsl #32
    // 0x11d54b4: r8 = Y0 bound num
    //     0x11d54b4: add             x8, PP, #0xc, lsl #12  ; [pp+0xcb40] TypeParameter: Y0 bound num
    //     0x11d54b8: ldr             x8, [x8, #0xb40]
    // 0x11d54bc: LoadField: r9 = r4->field_7
    //     0x11d54bc: ldur            x9, [x4, #7]
    // 0x11d54c0: r3 = Null
    //     0x11d54c0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99848] Null
    //     0x11d54c4: ldr             x3, [x3, #0x848]
    // 0x11d54c8: blr             x9
    // 0x11d54cc: ldur            x0, [fp, #-0x30]
    // 0x11d54d0: b               #0x11d5538
    // 0x11d54d4: r0 = 60
    //     0x11d54d4: mov             x0, #0x3c
    // 0x11d54d8: branchIfSmi(r2, 0x11d54e4)
    //     0x11d54d8: tbz             w2, #0, #0x11d54e4
    // 0x11d54dc: r0 = LoadClassIdInstr(r2)
    //     0x11d54dc: ldur            x0, [x2, #-1]
    //     0x11d54e0: ubfx            x0, x0, #0xc, #0x14
    // 0x11d54e4: stp             xzr, x2, [SP]
    // 0x11d54e8: mov             lr, x0
    // 0x11d54ec: ldr             lr, [x21, lr, lsl #3]
    // 0x11d54f0: blr             lr
    // 0x11d54f4: tbnz            w0, #4, #0x11d551c
    // 0x11d54f8: ldur            x0, [fp, #-0x28]
    // 0x11d54fc: LoadField: d0 = r0->field_7
    //     0x11d54fc: ldur            d0, [x0, #7]
    // 0x11d5500: fcmp            d0, #0.0
    // 0x11d5504: b.vs            #0x11d5520
    // 0x11d5508: b.ne            #0x11d5514
    // 0x11d550c: r1 = 0.000000
    //     0x11d550c: fmov            x1, d0
    // 0x11d5510: cmp             x1, #0
    // 0x11d5514: b.ge            #0x11d5520
    // 0x11d5518: b               #0x11d5538
    // 0x11d551c: ldur            x0, [fp, #-0x28]
    // 0x11d5520: LoadField: d0 = r0->field_7
    //     0x11d5520: ldur            d0, [x0, #7]
    // 0x11d5524: fcmp            d0, d0
    // 0x11d5528: b.vs            #0x11d5538
    // 0x11d552c: ldur            x0, [fp, #-0x20]
    // 0x11d5530: b               #0x11d5538
    // 0x11d5534: ldur            x0, [fp, #-0x20]
    // 0x11d5538: ldur            x1, [fp, #-0x10]
    // 0x11d553c: LoadField: r2 = r1->field_27
    //     0x11d553c: ldur            w2, [x1, #0x27]
    // 0x11d5540: DecompressPointer r2
    //     0x11d5540: add             x2, x2, HEAP, lsl #32
    // 0x11d5544: r3 = 60
    //     0x11d5544: mov             x3, #0x3c
    // 0x11d5548: branchIfSmi(r0, 0x11d5554)
    //     0x11d5548: tbz             w0, #0, #0x11d5554
    // 0x11d554c: r3 = LoadClassIdInstr(r0)
    //     0x11d554c: ldur            x3, [x0, #-1]
    //     0x11d5550: ubfx            x3, x3, #0xc, #0x14
    // 0x11d5554: stp             x2, x0, [SP]
    // 0x11d5558: mov             x0, x3
    // 0x11d555c: mov             lr, x0
    // 0x11d5560: ldr             lr, [x21, lr, lsl #3]
    // 0x11d5564: blr             lr
    // 0x11d5568: tbz             w0, #4, #0x11d581c
    // 0x11d556c: ldur            x0, [fp, #-8]
    // 0x11d5570: r17 = 4378
    //     0x11d5570: mov             x17, #0x111a
    // 0x11d5574: cmp             x0, x17
    // 0x11d5578: b.ne            #0x11d55fc
    // 0x11d557c: ldur            x2, [fp, #-0x10]
    // 0x11d5580: d0 = 0.500000
    //     0x11d5580: fmov            d0, #0.50000000
    // 0x11d5584: LoadField: r0 = r2->field_2b
    //     0x11d5584: ldur            w0, [x2, #0x2b]
    // 0x11d5588: DecompressPointer r0
    //     0x11d5588: add             x0, x0, HEAP, lsl #32
    // 0x11d558c: LoadField: r1 = r0->field_37
    //     0x11d558c: ldur            w1, [x0, #0x37]
    // 0x11d5590: DecompressPointer r1
    //     0x11d5590: add             x1, x1, HEAP, lsl #32
    // 0x11d5594: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d5598: cmp             w1, w16
    // 0x11d559c: b.eq            #0x11d5850
    // 0x11d55a0: LoadField: d1 = r1->field_7
    //     0x11d55a0: ldur            d1, [x1, #7]
    // 0x11d55a4: fcmp            d0, d1
    // 0x11d55a8: b.le            #0x11d55d4
    // 0x11d55ac: LoadField: r1 = r2->field_1b
    //     0x11d55ac: ldur            w1, [x2, #0x1b]
    // 0x11d55b0: DecompressPointer r1
    //     0x11d55b0: add             x1, x1, HEAP, lsl #32
    // 0x11d55b4: r0 = LoadClassIdInstr(r1)
    //     0x11d55b4: ldur            x0, [x1, #-1]
    //     0x11d55b8: ubfx            x0, x0, #0xc, #0x14
    // 0x11d55bc: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d55bc: mov             x17, #0x4e2e
    //     0x11d55c0: movk            x17, #1, lsl #16
    //     0x11d55c4: add             lr, x0, x17
    //     0x11d55c8: ldr             lr, [x21, lr, lsl #3]
    //     0x11d55cc: blr             lr
    // 0x11d55d0: b               #0x11d57f4
    // 0x11d55d4: LoadField: r1 = r2->field_1f
    //     0x11d55d4: ldur            w1, [x2, #0x1f]
    // 0x11d55d8: DecompressPointer r1
    //     0x11d55d8: add             x1, x1, HEAP, lsl #32
    // 0x11d55dc: r0 = LoadClassIdInstr(r1)
    //     0x11d55dc: ldur            x0, [x1, #-1]
    //     0x11d55e0: ubfx            x0, x0, #0xc, #0x14
    // 0x11d55e4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d55e4: mov             x17, #0x4e2e
    //     0x11d55e8: movk            x17, #1, lsl #16
    //     0x11d55ec: add             lr, x0, x17
    //     0x11d55f0: ldr             lr, [x21, lr, lsl #3]
    //     0x11d55f4: blr             lr
    // 0x11d55f8: b               #0x11d57f4
    // 0x11d55fc: ldur            x2, [fp, #-0x10]
    // 0x11d5600: LoadField: r3 = r2->field_7
    //     0x11d5600: ldur            w3, [x2, #7]
    // 0x11d5604: DecompressPointer r3
    //     0x11d5604: add             x3, x3, HEAP, lsl #32
    // 0x11d5608: stur            x3, [fp, #-0x18]
    // 0x11d560c: LoadField: r1 = r2->field_1b
    //     0x11d560c: ldur            w1, [x2, #0x1b]
    // 0x11d5610: DecompressPointer r1
    //     0x11d5610: add             x1, x1, HEAP, lsl #32
    // 0x11d5614: r0 = LoadClassIdInstr(r1)
    //     0x11d5614: ldur            x0, [x1, #-1]
    //     0x11d5618: ubfx            x0, x0, #0xc, #0x14
    // 0x11d561c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d561c: mov             x17, #0x4e2e
    //     0x11d5620: movk            x17, #1, lsl #16
    //     0x11d5624: add             lr, x0, x17
    //     0x11d5628: ldr             lr, [x21, lr, lsl #3]
    //     0x11d562c: blr             lr
    // 0x11d5630: mov             x3, x0
    // 0x11d5634: ldur            x2, [fp, #-0x10]
    // 0x11d5638: stur            x3, [fp, #-0x20]
    // 0x11d563c: LoadField: r1 = r2->field_1f
    //     0x11d563c: ldur            w1, [x2, #0x1f]
    // 0x11d5640: DecompressPointer r1
    //     0x11d5640: add             x1, x1, HEAP, lsl #32
    // 0x11d5644: r0 = LoadClassIdInstr(r1)
    //     0x11d5644: ldur            x0, [x1, #-1]
    //     0x11d5648: ubfx            x0, x0, #0xc, #0x14
    // 0x11d564c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x11d564c: mov             x17, #0x4e2e
    //     0x11d5650: movk            x17, #1, lsl #16
    //     0x11d5654: add             lr, x0, x17
    //     0x11d5658: ldr             lr, [x21, lr, lsl #3]
    //     0x11d565c: blr             lr
    // 0x11d5660: mov             x2, x0
    // 0x11d5664: ldur            x1, [fp, #-0x20]
    // 0x11d5668: stur            x2, [fp, #-0x28]
    // 0x11d566c: r0 = 60
    //     0x11d566c: mov             x0, #0x3c
    // 0x11d5670: branchIfSmi(r1, 0x11d567c)
    //     0x11d5670: tbz             w1, #0, #0x11d567c
    // 0x11d5674: r0 = LoadClassIdInstr(r1)
    //     0x11d5674: ldur            x0, [x1, #-1]
    //     0x11d5678: ubfx            x0, x0, #0xc, #0x14
    // 0x11d567c: stp             x2, x1, [SP]
    // 0x11d5680: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x11d5680: sub             lr, x0, #0xfe5
    //     0x11d5684: ldr             lr, [x21, lr, lsl #3]
    //     0x11d5688: blr             lr
    // 0x11d568c: tbnz            w0, #4, #0x11d5698
    // 0x11d5690: ldur            x0, [fp, #-0x28]
    // 0x11d5694: b               #0x11d57f4
    // 0x11d5698: ldur            x1, [fp, #-0x20]
    // 0x11d569c: r0 = 60
    //     0x11d569c: mov             x0, #0x3c
    // 0x11d56a0: branchIfSmi(r1, 0x11d56ac)
    //     0x11d56a0: tbz             w1, #0, #0x11d56ac
    // 0x11d56a4: r0 = LoadClassIdInstr(r1)
    //     0x11d56a4: ldur            x0, [x1, #-1]
    //     0x11d56a8: ubfx            x0, x0, #0xc, #0x14
    // 0x11d56ac: ldur            x16, [fp, #-0x28]
    // 0x11d56b0: stp             x16, x1, [SP]
    // 0x11d56b4: r0 = GDT[cid_x0 + -0xfe8]()
    //     0x11d56b4: sub             lr, x0, #0xfe8
    //     0x11d56b8: ldr             lr, [x21, lr, lsl #3]
    //     0x11d56bc: blr             lr
    // 0x11d56c0: tbnz            w0, #4, #0x11d56cc
    // 0x11d56c4: ldur            x0, [fp, #-0x20]
    // 0x11d56c8: b               #0x11d57f4
    // 0x11d56cc: ldur            x1, [fp, #-0x28]
    // 0x11d56d0: r0 = 60
    //     0x11d56d0: mov             x0, #0x3c
    // 0x11d56d4: branchIfSmi(r1, 0x11d56e0)
    //     0x11d56d4: tbz             w1, #0, #0x11d56e0
    // 0x11d56d8: r0 = LoadClassIdInstr(r1)
    //     0x11d56d8: ldur            x0, [x1, #-1]
    //     0x11d56dc: ubfx            x0, x0, #0xc, #0x14
    // 0x11d56e0: cmp             x0, #0x3e
    // 0x11d56e4: b.ne            #0x11d57f0
    // 0x11d56e8: ldur            x2, [fp, #-0x20]
    // 0x11d56ec: r0 = 60
    //     0x11d56ec: mov             x0, #0x3c
    // 0x11d56f0: branchIfSmi(r2, 0x11d56fc)
    //     0x11d56f0: tbz             w2, #0, #0x11d56fc
    // 0x11d56f4: r0 = LoadClassIdInstr(r2)
    //     0x11d56f4: ldur            x0, [x2, #-1]
    //     0x11d56f8: ubfx            x0, x0, #0xc, #0x14
    // 0x11d56fc: cmp             x0, #0x3e
    // 0x11d5700: b.ne            #0x11d5790
    // 0x11d5704: d0 = 0.000000
    //     0x11d5704: eor             v0.16b, v0.16b, v0.16b
    // 0x11d5708: LoadField: d1 = r2->field_7
    //     0x11d5708: ldur            d1, [x2, #7]
    // 0x11d570c: fcmp            d1, d0
    // 0x11d5710: b.ne            #0x11d5790
    // 0x11d5714: LoadField: d0 = r1->field_7
    //     0x11d5714: ldur            d0, [x1, #7]
    // 0x11d5718: fadd            d2, d1, d0
    // 0x11d571c: fmul            d3, d2, d1
    // 0x11d5720: fmul            d1, d3, d0
    // 0x11d5724: r3 = inline_Allocate_Double()
    //     0x11d5724: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x11d5728: add             x3, x3, #0x10
    //     0x11d572c: cmp             x0, x3
    //     0x11d5730: b.ls            #0x11d5858
    //     0x11d5734: str             x3, [THR, #0x60]  ; THR::top
    //     0x11d5738: sub             x3, x3, #0xf
    //     0x11d573c: mov             x0, #0xe19c
    //     0x11d5740: movk            x0, #3, lsl #16
    //     0x11d5744: stur            x0, [x3, #-1]
    // 0x11d5748: dmb             ishst
    // 0x11d574c: StoreField: r3->field_7 = d1
    //     0x11d574c: stur            d1, [x3, #7]
    // 0x11d5750: mov             x0, x3
    // 0x11d5754: ldur            x1, [fp, #-0x18]
    // 0x11d5758: stur            x3, [fp, #-0x30]
    // 0x11d575c: r2 = Null
    //     0x11d575c: mov             x2, NULL
    // 0x11d5760: cmp             w1, NULL
    // 0x11d5764: b.eq            #0x11d5788
    // 0x11d5768: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x11d5768: ldur            w4, [x1, #0x17]
    // 0x11d576c: DecompressPointer r4
    //     0x11d576c: add             x4, x4, HEAP, lsl #32
    // 0x11d5770: r8 = Y0 bound num
    //     0x11d5770: add             x8, PP, #0xc, lsl #12  ; [pp+0xcb40] TypeParameter: Y0 bound num
    //     0x11d5774: ldr             x8, [x8, #0xb40]
    // 0x11d5778: LoadField: r9 = r4->field_7
    //     0x11d5778: ldur            x9, [x4, #7]
    // 0x11d577c: r3 = Null
    //     0x11d577c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99858] Null
    //     0x11d5780: ldr             x3, [x3, #0x858]
    // 0x11d5784: blr             x9
    // 0x11d5788: ldur            x0, [fp, #-0x30]
    // 0x11d578c: b               #0x11d57f4
    // 0x11d5790: r0 = 60
    //     0x11d5790: mov             x0, #0x3c
    // 0x11d5794: branchIfSmi(r2, 0x11d57a0)
    //     0x11d5794: tbz             w2, #0, #0x11d57a0
    // 0x11d5798: r0 = LoadClassIdInstr(r2)
    //     0x11d5798: ldur            x0, [x2, #-1]
    //     0x11d579c: ubfx            x0, x0, #0xc, #0x14
    // 0x11d57a0: stp             xzr, x2, [SP]
    // 0x11d57a4: mov             lr, x0
    // 0x11d57a8: ldr             lr, [x21, lr, lsl #3]
    // 0x11d57ac: blr             lr
    // 0x11d57b0: tbnz            w0, #4, #0x11d57d8
    // 0x11d57b4: ldur            x0, [fp, #-0x28]
    // 0x11d57b8: LoadField: d0 = r0->field_7
    //     0x11d57b8: ldur            d0, [x0, #7]
    // 0x11d57bc: fcmp            d0, #0.0
    // 0x11d57c0: b.vs            #0x11d57dc
    // 0x11d57c4: b.ne            #0x11d57d0
    // 0x11d57c8: r1 = 0.000000
    //     0x11d57c8: fmov            x1, d0
    // 0x11d57cc: cmp             x1, #0
    // 0x11d57d0: b.ge            #0x11d57dc
    // 0x11d57d4: b               #0x11d57f4
    // 0x11d57d8: ldur            x0, [fp, #-0x28]
    // 0x11d57dc: LoadField: d0 = r0->field_7
    //     0x11d57dc: ldur            d0, [x0, #7]
    // 0x11d57e0: fcmp            d0, d0
    // 0x11d57e4: b.vs            #0x11d57f4
    // 0x11d57e8: ldur            x0, [fp, #-0x20]
    // 0x11d57ec: b               #0x11d57f4
    // 0x11d57f0: ldur            x0, [fp, #-0x20]
    // 0x11d57f4: ldur            x1, [fp, #-0x10]
    // 0x11d57f8: StoreField: r1->field_27 = r0
    //     0x11d57f8: stur            w0, [x1, #0x27]
    //     0x11d57fc: tbz             w0, #0, #0x11d5818
    //     0x11d5800: ldurb           w16, [x1, #-1]
    //     0x11d5804: ldurb           w17, [x0, #-1]
    //     0x11d5808: and             x16, x17, x16, lsr #2
    //     0x11d580c: tst             x16, HEAP, lsr #32
    //     0x11d5810: b.eq            #0x11d5818
    //     0x11d5814: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5818: r0 = notifyListeners()
    //     0x11d5818: bl              #0x11d586c  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x11d581c: r0 = Null
    //     0x11d581c: mov             x0, NULL
    // 0x11d5820: LeaveFrame
    //     0x11d5820: mov             SP, fp
    //     0x11d5824: ldp             fp, lr, [SP], #0x10
    // 0x11d5828: ret
    //     0x11d5828: ret             
    // 0x11d582c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d582c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d5830: b               #0x11d52b0
    // 0x11d5834: r9 = _value
    //     0x11d5834: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x11d5838: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x11d5838: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x11d583c: stp             q0, q1, [SP, #-0x20]!
    // 0x11d5840: r0 = AllocateDouble()
    //     0x11d5840: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11d5844: mov             x3, x0
    // 0x11d5848: ldp             q0, q1, [SP], #0x20
    // 0x11d584c: b               #0x11d5490
    // 0x11d5850: r9 = _value
    //     0x11d5850: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x11d5854: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x11d5854: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x11d5858: SaveReg d1
    //     0x11d5858: str             q1, [SP, #-0x10]!
    // 0x11d585c: r0 = AllocateDouble()
    //     0x11d585c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11d5860: mov             x3, x0
    // 0x11d5864: RestoreReg d1
    //     0x11d5864: ldr             q1, [SP], #0x10
    // 0x11d5868: b               #0x11d574c
  }
  _ didStartListening(/* No info */) {
    // ** addr: 0x121bc94, size: 0x100
    // 0x121bc94: EnterFrame
    //     0x121bc94: stp             fp, lr, [SP, #-0x10]!
    //     0x121bc98: mov             fp, SP
    // 0x121bc9c: AllocStack(0x20)
    //     0x121bc9c: sub             SP, SP, #0x20
    // 0x121bca0: SetupParameters(CompoundAnimation<X0> this /* r1 => r0, fp-0x10 */)
    //     0x121bca0: mov             x0, x1
    //     0x121bca4: stur            x1, [fp, #-0x10]
    // 0x121bca8: CheckStackOverflow
    //     0x121bca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121bcac: cmp             SP, x16
    //     0x121bcb0: b.ls            #0x121bd8c
    // 0x121bcb4: LoadField: r3 = r0->field_1b
    //     0x121bcb4: ldur            w3, [x0, #0x1b]
    // 0x121bcb8: DecompressPointer r3
    //     0x121bcb8: add             x3, x3, HEAP, lsl #32
    // 0x121bcbc: mov             x2, x0
    // 0x121bcc0: stur            x3, [fp, #-8]
    // 0x121bcc4: r1 = Function '_maybeNotifyListeners@63411118':.
    //     0x121bcc4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99828] AnonymousClosure: (0x11d5258), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0x11d5290)
    //     0x121bcc8: ldr             x1, [x1, #0x828]
    // 0x121bccc: r0 = AllocateClosure()
    //     0x121bccc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x121bcd0: mov             x4, x0
    // 0x121bcd4: ldur            x3, [fp, #-8]
    // 0x121bcd8: stur            x4, [fp, #-0x18]
    // 0x121bcdc: r0 = LoadClassIdInstr(r3)
    //     0x121bcdc: ldur            x0, [x3, #-1]
    //     0x121bce0: ubfx            x0, x0, #0xc, #0x14
    // 0x121bce4: mov             x1, x3
    // 0x121bce8: mov             x2, x4
    // 0x121bcec: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0x121bcec: mov             x17, #0xe0ec
    //     0x121bcf0: add             lr, x0, x17
    //     0x121bcf4: ldr             lr, [x21, lr, lsl #3]
    //     0x121bcf8: blr             lr
    // 0x121bcfc: ldur            x2, [fp, #-0x10]
    // 0x121bd00: r1 = Function '_maybeNotifyStatusListeners@63411118':.
    //     0x121bd00: add             x1, PP, #0x99, lsl #12  ; [pp+0x99830] AnonymousClosure: (0x11d4ee8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0x11d4f24)
    //     0x121bd04: ldr             x1, [x1, #0x830]
    // 0x121bd08: r0 = AllocateClosure()
    //     0x121bd08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x121bd0c: mov             x3, x0
    // 0x121bd10: ldur            x1, [fp, #-8]
    // 0x121bd14: stur            x3, [fp, #-0x20]
    // 0x121bd18: r0 = LoadClassIdInstr(r1)
    //     0x121bd18: ldur            x0, [x1, #-1]
    //     0x121bd1c: ubfx            x0, x0, #0xc, #0x14
    // 0x121bd20: mov             x2, x3
    // 0x121bd24: r0 = GDT[cid_x0 + 0xbeb]()
    //     0x121bd24: add             lr, x0, #0xbeb
    //     0x121bd28: ldr             lr, [x21, lr, lsl #3]
    //     0x121bd2c: blr             lr
    // 0x121bd30: ldur            x0, [fp, #-0x10]
    // 0x121bd34: LoadField: r3 = r0->field_1f
    //     0x121bd34: ldur            w3, [x0, #0x1f]
    // 0x121bd38: DecompressPointer r3
    //     0x121bd38: add             x3, x3, HEAP, lsl #32
    // 0x121bd3c: stur            x3, [fp, #-8]
    // 0x121bd40: r0 = LoadClassIdInstr(r3)
    //     0x121bd40: ldur            x0, [x3, #-1]
    //     0x121bd44: ubfx            x0, x0, #0xc, #0x14
    // 0x121bd48: mov             x1, x3
    // 0x121bd4c: ldur            x2, [fp, #-0x18]
    // 0x121bd50: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0x121bd50: mov             x17, #0xe0ec
    //     0x121bd54: add             lr, x0, x17
    //     0x121bd58: ldr             lr, [x21, lr, lsl #3]
    //     0x121bd5c: blr             lr
    // 0x121bd60: ldur            x1, [fp, #-8]
    // 0x121bd64: r0 = LoadClassIdInstr(r1)
    //     0x121bd64: ldur            x0, [x1, #-1]
    //     0x121bd68: ubfx            x0, x0, #0xc, #0x14
    // 0x121bd6c: ldur            x2, [fp, #-0x20]
    // 0x121bd70: r0 = GDT[cid_x0 + 0xbeb]()
    //     0x121bd70: add             lr, x0, #0xbeb
    //     0x121bd74: ldr             lr, [x21, lr, lsl #3]
    //     0x121bd78: blr             lr
    // 0x121bd7c: r0 = Null
    //     0x121bd7c: mov             x0, NULL
    // 0x121bd80: LeaveFrame
    //     0x121bd80: mov             SP, fp
    //     0x121bd84: ldp             fp, lr, [SP], #0x10
    // 0x121bd88: ret
    //     0x121bd88: ret             
    // 0x121bd8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121bd8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121bd90: b               #0x121bcb4
  }
  get _ status(/* No info */) {
    // ** addr: 0x1284a0c, size: 0xc4
    // 0x1284a0c: EnterFrame
    //     0x1284a0c: stp             fp, lr, [SP, #-0x10]!
    //     0x1284a10: mov             fp, SP
    // 0x1284a14: AllocStack(0x10)
    //     0x1284a14: sub             SP, SP, #0x10
    // 0x1284a18: SetupParameters(CompoundAnimation<X0> this /* r1 => r2, fp-0x10 */)
    //     0x1284a18: mov             x2, x1
    //     0x1284a1c: stur            x1, [fp, #-0x10]
    // 0x1284a20: CheckStackOverflow
    //     0x1284a20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1284a24: cmp             SP, x16
    //     0x1284a28: b.ls            #0x1284ac8
    // 0x1284a2c: LoadField: r3 = r2->field_1f
    //     0x1284a2c: ldur            w3, [x2, #0x1f]
    // 0x1284a30: DecompressPointer r3
    //     0x1284a30: add             x3, x3, HEAP, lsl #32
    // 0x1284a34: stur            x3, [fp, #-8]
    // 0x1284a38: r0 = LoadClassIdInstr(r3)
    //     0x1284a38: ldur            x0, [x3, #-1]
    //     0x1284a3c: ubfx            x0, x0, #0xc, #0x14
    // 0x1284a40: mov             x1, x3
    // 0x1284a44: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284a44: sub             lr, x0, #0x52
    //     0x1284a48: ldr             lr, [x21, lr, lsl #3]
    //     0x1284a4c: blr             lr
    // 0x1284a50: r16 = Instance_AnimationStatus
    //     0x1284a50: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0x1284a54: cmp             w0, w16
    // 0x1284a58: b.eq            #0x1284a68
    // 0x1284a5c: r16 = Instance_AnimationStatus
    //     0x1284a5c: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0x1284a60: cmp             w0, w16
    // 0x1284a64: b.ne            #0x1284a84
    // 0x1284a68: ldur            x1, [fp, #-8]
    // 0x1284a6c: r0 = LoadClassIdInstr(r1)
    //     0x1284a6c: ldur            x0, [x1, #-1]
    //     0x1284a70: ubfx            x0, x0, #0xc, #0x14
    // 0x1284a74: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284a74: sub             lr, x0, #0x52
    //     0x1284a78: ldr             lr, [x21, lr, lsl #3]
    //     0x1284a7c: blr             lr
    // 0x1284a80: b               #0x1284abc
    // 0x1284a84: r16 = Instance_AnimationStatus
    //     0x1284a84: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x1284a88: cmp             w0, w16
    // 0x1284a8c: b.eq            #0x1284a9c
    // 0x1284a90: r16 = Instance_AnimationStatus
    //     0x1284a90: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0x1284a94: cmp             w0, w16
    // 0x1284a98: b.eq            #0x1284a9c
    // 0x1284a9c: ldur            x0, [fp, #-0x10]
    // 0x1284aa0: LoadField: r1 = r0->field_1b
    //     0x1284aa0: ldur            w1, [x0, #0x1b]
    // 0x1284aa4: DecompressPointer r1
    //     0x1284aa4: add             x1, x1, HEAP, lsl #32
    // 0x1284aa8: r0 = LoadClassIdInstr(r1)
    //     0x1284aa8: ldur            x0, [x1, #-1]
    //     0x1284aac: ubfx            x0, x0, #0xc, #0x14
    // 0x1284ab0: r0 = GDT[cid_x0 + -0x52]()
    //     0x1284ab0: sub             lr, x0, #0x52
    //     0x1284ab4: ldr             lr, [x21, lr, lsl #3]
    //     0x1284ab8: blr             lr
    // 0x1284abc: LeaveFrame
    //     0x1284abc: mov             SP, fp
    //     0x1284ac0: ldp             fp, lr, [SP], #0x10
    // 0x1284ac4: ret
    //     0x1284ac4: ret             
    // 0x1284ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1284ac8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1284acc: b               #0x1284a2c
  }
}

// class id: 4379, size: 0x2c, field offset: 0x2c
class AnimationMin<X0 bound num> extends CompoundAnimation<X0 bound num> {

  X0 value(AnimationMin<X0>) {
    // ** addr: 0xae5bf0, size: 0x244
    // 0xae5bf0: EnterFrame
    //     0xae5bf0: stp             fp, lr, [SP, #-0x10]!
    //     0xae5bf4: mov             fp, SP
    // 0xae5bf8: AllocStack(0x30)
    //     0xae5bf8: sub             SP, SP, #0x30
    // 0xae5bfc: SetupParameters(AnimationMin<X0 bound num> this /* r1 => r2, fp-0x10 */)
    //     0xae5bfc: mov             x2, x1
    //     0xae5c00: stur            x1, [fp, #-0x10]
    // 0xae5c04: CheckStackOverflow
    //     0xae5c04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae5c08: cmp             SP, x16
    //     0xae5c0c: b.ls            #0xae5e18
    // 0xae5c10: LoadField: r3 = r2->field_7
    //     0xae5c10: ldur            w3, [x2, #7]
    // 0xae5c14: DecompressPointer r3
    //     0xae5c14: add             x3, x3, HEAP, lsl #32
    // 0xae5c18: stur            x3, [fp, #-8]
    // 0xae5c1c: LoadField: r1 = r2->field_1b
    //     0xae5c1c: ldur            w1, [x2, #0x1b]
    // 0xae5c20: DecompressPointer r1
    //     0xae5c20: add             x1, x1, HEAP, lsl #32
    // 0xae5c24: r0 = LoadClassIdInstr(r1)
    //     0xae5c24: ldur            x0, [x1, #-1]
    //     0xae5c28: ubfx            x0, x0, #0xc, #0x14
    // 0xae5c2c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae5c2c: mov             x17, #0x4e2e
    //     0xae5c30: movk            x17, #1, lsl #16
    //     0xae5c34: add             lr, x0, x17
    //     0xae5c38: ldr             lr, [x21, lr, lsl #3]
    //     0xae5c3c: blr             lr
    // 0xae5c40: mov             x2, x0
    // 0xae5c44: ldur            x0, [fp, #-0x10]
    // 0xae5c48: stur            x2, [fp, #-0x18]
    // 0xae5c4c: LoadField: r1 = r0->field_1f
    //     0xae5c4c: ldur            w1, [x0, #0x1f]
    // 0xae5c50: DecompressPointer r1
    //     0xae5c50: add             x1, x1, HEAP, lsl #32
    // 0xae5c54: r0 = LoadClassIdInstr(r1)
    //     0xae5c54: ldur            x0, [x1, #-1]
    //     0xae5c58: ubfx            x0, x0, #0xc, #0x14
    // 0xae5c5c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae5c5c: mov             x17, #0x4e2e
    //     0xae5c60: movk            x17, #1, lsl #16
    //     0xae5c64: add             lr, x0, x17
    //     0xae5c68: ldr             lr, [x21, lr, lsl #3]
    //     0xae5c6c: blr             lr
    // 0xae5c70: mov             x2, x0
    // 0xae5c74: ldur            x1, [fp, #-0x18]
    // 0xae5c78: stur            x2, [fp, #-0x10]
    // 0xae5c7c: r0 = 60
    //     0xae5c7c: mov             x0, #0x3c
    // 0xae5c80: branchIfSmi(r1, 0xae5c8c)
    //     0xae5c80: tbz             w1, #0, #0xae5c8c
    // 0xae5c84: r0 = LoadClassIdInstr(r1)
    //     0xae5c84: ldur            x0, [x1, #-1]
    //     0xae5c88: ubfx            x0, x0, #0xc, #0x14
    // 0xae5c8c: stp             x2, x1, [SP]
    // 0xae5c90: r0 = GDT[cid_x0 + -0xfe5]()
    //     0xae5c90: sub             lr, x0, #0xfe5
    //     0xae5c94: ldr             lr, [x21, lr, lsl #3]
    //     0xae5c98: blr             lr
    // 0xae5c9c: tbnz            w0, #4, #0xae5ca8
    // 0xae5ca0: ldur            x0, [fp, #-0x10]
    // 0xae5ca4: b               #0xae5e0c
    // 0xae5ca8: ldur            x1, [fp, #-0x18]
    // 0xae5cac: r0 = 60
    //     0xae5cac: mov             x0, #0x3c
    // 0xae5cb0: branchIfSmi(r1, 0xae5cbc)
    //     0xae5cb0: tbz             w1, #0, #0xae5cbc
    // 0xae5cb4: r0 = LoadClassIdInstr(r1)
    //     0xae5cb4: ldur            x0, [x1, #-1]
    //     0xae5cb8: ubfx            x0, x0, #0xc, #0x14
    // 0xae5cbc: ldur            x16, [fp, #-0x10]
    // 0xae5cc0: stp             x16, x1, [SP]
    // 0xae5cc4: r0 = GDT[cid_x0 + -0xfe8]()
    //     0xae5cc4: sub             lr, x0, #0xfe8
    //     0xae5cc8: ldr             lr, [x21, lr, lsl #3]
    //     0xae5ccc: blr             lr
    // 0xae5cd0: tbnz            w0, #4, #0xae5cdc
    // 0xae5cd4: ldur            x0, [fp, #-0x18]
    // 0xae5cd8: b               #0xae5e0c
    // 0xae5cdc: ldur            x1, [fp, #-0x10]
    // 0xae5ce0: r0 = 60
    //     0xae5ce0: mov             x0, #0x3c
    // 0xae5ce4: branchIfSmi(r1, 0xae5cf0)
    //     0xae5ce4: tbz             w1, #0, #0xae5cf0
    // 0xae5ce8: r0 = LoadClassIdInstr(r1)
    //     0xae5ce8: ldur            x0, [x1, #-1]
    //     0xae5cec: ubfx            x0, x0, #0xc, #0x14
    // 0xae5cf0: cmp             x0, #0x3e
    // 0xae5cf4: b.ne            #0xae5e08
    // 0xae5cf8: ldur            x2, [fp, #-0x18]
    // 0xae5cfc: r0 = 60
    //     0xae5cfc: mov             x0, #0x3c
    // 0xae5d00: branchIfSmi(r2, 0xae5d0c)
    //     0xae5d00: tbz             w2, #0, #0xae5d0c
    // 0xae5d04: r0 = LoadClassIdInstr(r2)
    //     0xae5d04: ldur            x0, [x2, #-1]
    //     0xae5d08: ubfx            x0, x0, #0xc, #0x14
    // 0xae5d0c: cmp             x0, #0x3e
    // 0xae5d10: b.ne            #0xae5da0
    // 0xae5d14: d0 = 0.000000
    //     0xae5d14: eor             v0.16b, v0.16b, v0.16b
    // 0xae5d18: LoadField: d1 = r2->field_7
    //     0xae5d18: ldur            d1, [x2, #7]
    // 0xae5d1c: fcmp            d1, d0
    // 0xae5d20: b.ne            #0xae5da0
    // 0xae5d24: LoadField: d0 = r1->field_7
    //     0xae5d24: ldur            d0, [x1, #7]
    // 0xae5d28: fadd            d2, d1, d0
    // 0xae5d2c: fmul            d3, d2, d1
    // 0xae5d30: fmul            d1, d3, d0
    // 0xae5d34: r3 = inline_Allocate_Double()
    //     0xae5d34: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xae5d38: add             x3, x3, #0x10
    //     0xae5d3c: cmp             x0, x3
    //     0xae5d40: b.ls            #0xae5e20
    //     0xae5d44: str             x3, [THR, #0x60]  ; THR::top
    //     0xae5d48: sub             x3, x3, #0xf
    //     0xae5d4c: mov             x0, #0xe19c
    //     0xae5d50: movk            x0, #3, lsl #16
    //     0xae5d54: stur            x0, [x3, #-1]
    // 0xae5d58: dmb             ishst
    // 0xae5d5c: StoreField: r3->field_7 = d1
    //     0xae5d5c: stur            d1, [x3, #7]
    // 0xae5d60: mov             x0, x3
    // 0xae5d64: ldur            x1, [fp, #-8]
    // 0xae5d68: stur            x3, [fp, #-0x20]
    // 0xae5d6c: r2 = Null
    //     0xae5d6c: mov             x2, NULL
    // 0xae5d70: cmp             w1, NULL
    // 0xae5d74: b.eq            #0xae5d98
    // 0xae5d78: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xae5d78: ldur            w4, [x1, #0x17]
    // 0xae5d7c: DecompressPointer r4
    //     0xae5d7c: add             x4, x4, HEAP, lsl #32
    // 0xae5d80: r8 = Y0 bound num
    //     0xae5d80: add             x8, PP, #0xc, lsl #12  ; [pp+0xcb40] TypeParameter: Y0 bound num
    //     0xae5d84: ldr             x8, [x8, #0xb40]
    // 0xae5d88: LoadField: r9 = r4->field_7
    //     0xae5d88: ldur            x9, [x4, #7]
    // 0xae5d8c: r3 = Null
    //     0xae5d8c: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4088] Null
    //     0xae5d90: ldr             x3, [x3, #0x88]
    // 0xae5d94: blr             x9
    // 0xae5d98: ldur            x0, [fp, #-0x20]
    // 0xae5d9c: b               #0xae5e0c
    // 0xae5da0: r0 = 60
    //     0xae5da0: mov             x0, #0x3c
    // 0xae5da4: branchIfSmi(r2, 0xae5db0)
    //     0xae5da4: tbz             w2, #0, #0xae5db0
    // 0xae5da8: r0 = LoadClassIdInstr(r2)
    //     0xae5da8: ldur            x0, [x2, #-1]
    //     0xae5dac: ubfx            x0, x0, #0xc, #0x14
    // 0xae5db0: stp             xzr, x2, [SP]
    // 0xae5db4: mov             lr, x0
    // 0xae5db8: ldr             lr, [x21, lr, lsl #3]
    // 0xae5dbc: blr             lr
    // 0xae5dc0: tbnz            w0, #4, #0xae5de8
    // 0xae5dc4: ldur            x1, [fp, #-0x10]
    // 0xae5dc8: LoadField: d0 = r1->field_7
    //     0xae5dc8: ldur            d0, [x1, #7]
    // 0xae5dcc: fcmp            d0, #0.0
    // 0xae5dd0: b.vs            #0xae5dec
    // 0xae5dd4: b.ne            #0xae5de0
    // 0xae5dd8: r2 = 0.000000
    //     0xae5dd8: fmov            x2, d0
    // 0xae5ddc: cmp             x2, #0
    // 0xae5de0: b.ge            #0xae5dec
    // 0xae5de4: b               #0xae5df8
    // 0xae5de8: ldur            x1, [fp, #-0x10]
    // 0xae5dec: LoadField: d0 = r1->field_7
    //     0xae5dec: ldur            d0, [x1, #7]
    // 0xae5df0: fcmp            d0, d0
    // 0xae5df4: b.vc            #0xae5e00
    // 0xae5df8: mov             x0, x1
    // 0xae5dfc: b               #0xae5e0c
    // 0xae5e00: ldur            x0, [fp, #-0x18]
    // 0xae5e04: b               #0xae5e0c
    // 0xae5e08: ldur            x0, [fp, #-0x18]
    // 0xae5e0c: LeaveFrame
    //     0xae5e0c: mov             SP, fp
    //     0xae5e10: ldp             fp, lr, [SP], #0x10
    // 0xae5e14: ret
    //     0xae5e14: ret             
    // 0xae5e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5e18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5e1c: b               #0xae5c10
    // 0xae5e20: SaveReg d1
    //     0xae5e20: str             q1, [SP, #-0x10]!
    // 0xae5e24: r0 = AllocateDouble()
    //     0xae5e24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae5e28: mov             x3, x0
    // 0xae5e2c: RestoreReg d1
    //     0xae5e2c: ldr             q1, [SP], #0x10
    // 0xae5e30: b               #0xae5d5c
  }
  X0 dyn:get:value(AnimationMin<X0>) {
    // ** addr: 0xae5e4c, size: 0x48
    // 0xae5e4c: EnterFrame
    //     0xae5e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xae5e50: mov             fp, SP
    // 0xae5e54: CheckStackOverflow
    //     0xae5e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae5e58: cmp             SP, x16
    //     0xae5e5c: b.ls            #0xae5e74
    // 0xae5e60: ldr             x1, [fp, #0x10]
    // 0xae5e64: r0 = value()
    //     0xae5e64: bl              #0xae5bf0  ; [package:flutter/src/animation/animations.dart] AnimationMin::value
    // 0xae5e68: LeaveFrame
    //     0xae5e68: mov             SP, fp
    //     0xae5e6c: ldp             fp, lr, [SP], #0x10
    // 0xae5e70: ret
    //     0xae5e70: ret             
    // 0xae5e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5e78: b               #0xae5e60
  }
}

// class id: 4619, size: 0xc, field offset: 0x8
abstract class AnimationWithParentMixin<X0> extends Object {
}

// class id: 8321, size: 0x14, field offset: 0x14
enum _TrainHoppingMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9608, size: 0x64
    // 0x11a9608: EnterFrame
    //     0x11a9608: stp             fp, lr, [SP, #-0x10]!
    //     0x11a960c: mov             fp, SP
    // 0x11a9610: AllocStack(0x10)
    //     0x11a9610: sub             SP, SP, #0x10
    // 0x11a9614: SetupParameters(_TrainHoppingMode this /* r1 => r0, fp-0x8 */)
    //     0x11a9614: mov             x0, x1
    //     0x11a9618: stur            x1, [fp, #-8]
    // 0x11a961c: CheckStackOverflow
    //     0x11a961c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9620: cmp             SP, x16
    //     0x11a9624: b.ls            #0x11a9664
    // 0x11a9628: r1 = Null
    //     0x11a9628: mov             x1, NULL
    // 0x11a962c: r2 = 4
    //     0x11a962c: mov             x2, #4
    // 0x11a9630: r0 = AllocateArray()
    //     0x11a9630: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9634: r16 = "_TrainHoppingMode."
    //     0x11a9634: add             x16, PP, #0x85, lsl #12  ; [pp+0x85190] "_TrainHoppingMode."
    //     0x11a9638: ldr             x16, [x16, #0x190]
    // 0x11a963c: StoreField: r0->field_f = r16
    //     0x11a963c: stur            w16, [x0, #0xf]
    // 0x11a9640: ldur            x1, [fp, #-8]
    // 0x11a9644: LoadField: r2 = r1->field_f
    //     0x11a9644: ldur            w2, [x1, #0xf]
    // 0x11a9648: DecompressPointer r2
    //     0x11a9648: add             x2, x2, HEAP, lsl #32
    // 0x11a964c: StoreField: r0->field_13 = r2
    //     0x11a964c: stur            w2, [x0, #0x13]
    // 0x11a9650: str             x0, [SP]
    // 0x11a9654: r0 = _interpolate()
    //     0x11a9654: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9658: LeaveFrame
    //     0x11a9658: mov             SP, fp
    //     0x11a965c: ldp             fp, lr, [SP], #0x10
    // 0x11a9660: ret
    //     0x11a9660: ret             
    // 0x11a9664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9668: b               #0x11a9628
  }
}
