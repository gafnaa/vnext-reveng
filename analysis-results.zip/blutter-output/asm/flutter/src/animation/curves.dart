// lib: , url: package:flutter/src/animation/curves.dart

// class id: 1048765, size: 0x8
class :: {
}

// class id: 3320, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ParametricCurve<X0> extends Object {

  _ transform(/* No info */) {
    // ** addr: 0x12f4dfc, size: 0x40
    // 0x12f4dfc: EnterFrame
    //     0x12f4dfc: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4e00: mov             fp, SP
    // 0x12f4e04: CheckStackOverflow
    //     0x12f4e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4e08: cmp             SP, x16
    //     0x12f4e0c: b.ls            #0x12f4e34
    // 0x12f4e10: r0 = LoadClassIdInstr(r1)
    //     0x12f4e10: ldur            x0, [x1, #-1]
    //     0x12f4e14: ubfx            x0, x0, #0xc, #0x14
    // 0x12f4e18: r0 = GDT[cid_x0 + 0x3dca]()
    //     0x12f4e18: mov             x17, #0x3dca
    //     0x12f4e1c: add             lr, x0, x17
    //     0x12f4e20: ldr             lr, [x21, lr, lsl #3]
    //     0x12f4e24: blr             lr
    // 0x12f4e28: LeaveFrame
    //     0x12f4e28: mov             SP, fp
    //     0x12f4e2c: ldp             fp, lr, [SP], #0x10
    // 0x12f4e30: ret
    //     0x12f4e30: ret             
    // 0x12f4e34: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f4e34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f4e38: b               #0x12f4e10
  }
}

// class id: 3321, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class Curve extends ParametricCurve<dynamic> {

  get _ flipped(/* No info */) {
    // ** addr: 0xb6f40c, size: 0x30
    // 0xb6f40c: EnterFrame
    //     0xb6f40c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f410: mov             fp, SP
    // 0xb6f414: AllocStack(0x8)
    //     0xb6f414: sub             SP, SP, #8
    // 0xb6f418: SetupParameters(Curve this /* r1 => r0, fp-0x8 */)
    //     0xb6f418: mov             x0, x1
    //     0xb6f41c: stur            x1, [fp, #-8]
    // 0xb6f420: r1 = <double>
    //     0xb6f420: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f424: r0 = FlippedCurve()
    //     0xb6f424: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xb6f428: ldur            x1, [fp, #-8]
    // 0xb6f42c: StoreField: r0->field_b = r1
    //     0xb6f42c: stur            w1, [x0, #0xb]
    // 0xb6f430: LeaveFrame
    //     0xb6f430: mov             SP, fp
    //     0xb6f434: ldp             fp, lr, [SP], #0x10
    // 0xb6f438: ret
    //     0xb6f438: ret             
  }
  _ transform(/* No info */) {
    // ** addr: 0x12f4dac, size: 0x50
    // 0x12f4dac: EnterFrame
    //     0x12f4dac: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4db0: mov             fp, SP
    // 0x12f4db4: d1 = 0.000000
    //     0x12f4db4: eor             v1.16b, v1.16b, v1.16b
    // 0x12f4db8: CheckStackOverflow
    //     0x12f4db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4dbc: cmp             SP, x16
    //     0x12f4dc0: b.ls            #0x12f4df4
    // 0x12f4dc4: fcmp            d0, d1
    // 0x12f4dc8: b.eq            #0x12f4dd8
    // 0x12f4dcc: d1 = 1.000000
    //     0x12f4dcc: fmov            d1, #1.00000000
    // 0x12f4dd0: fcmp            d0, d1
    // 0x12f4dd4: b.ne            #0x12f4de4
    // 0x12f4dd8: LeaveFrame
    //     0x12f4dd8: mov             SP, fp
    //     0x12f4ddc: ldp             fp, lr, [SP], #0x10
    // 0x12f4de0: ret
    //     0x12f4de0: ret             
    // 0x12f4de4: r0 = transform()
    //     0x12f4de4: bl              #0x12f4dfc  ; [package:flutter/src/animation/curves.dart] ParametricCurve::transform
    // 0x12f4de8: LeaveFrame
    //     0x12f4de8: mov             SP, fp
    //     0x12f4dec: ldp             fp, lr, [SP], #0x10
    // 0x12f4df0: ret
    //     0x12f4df0: ret             
    // 0x12f4df4: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f4df4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f4df8: b               #0x12f4dc4
  }
}

// class id: 3325, size: 0xc, field offset: 0xc
//   const constructor, 
class _BounceInCurve extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0x1180250, size: 0xcc
    // 0x1180250: d2 = 0.363636
    //     0x1180250: add             x17, PP, #0x90, lsl #12  ; [pp+0x903b8] IMM: double(0.36363636363636365) from 0x3fd745d1745d1746
    //     0x1180254: ldr             d2, [x17, #0x3b8]
    // 0x1180258: d1 = 1.000000
    //     0x1180258: fmov            d1, #1.00000000
    // 0x118025c: fsub            d3, d1, d0
    // 0x1180260: fcmp            d2, d3
    // 0x1180264: b.le            #0x1180280
    // 0x1180268: d2 = 7.562500
    //     0x1180268: add             x17, PP, #0x90, lsl #12  ; [pp+0x903c0] IMM: double(7.5625) from 0x401e400000000000
    //     0x118026c: ldr             d2, [x17, #0x3c0]
    // 0x1180270: fmul            d4, d3, d2
    // 0x1180274: fmul            d5, d4, d3
    // 0x1180278: mov             v2.16b, v5.16b
    // 0x118027c: b               #0x1180314
    // 0x1180280: d4 = 0.727273
    //     0x1180280: add             x17, PP, #0x90, lsl #12  ; [pp+0x903c8] IMM: double(0.7272727272727273) from 0x3fe745d1745d1746
    //     0x1180284: ldr             d4, [x17, #0x3c8]
    // 0x1180288: d2 = 7.562500
    //     0x1180288: add             x17, PP, #0x90, lsl #12  ; [pp+0x903c0] IMM: double(7.5625) from 0x401e400000000000
    //     0x118028c: ldr             d2, [x17, #0x3c0]
    // 0x1180290: fcmp            d4, d3
    // 0x1180294: b.le            #0x11802bc
    // 0x1180298: d5 = 0.545455
    //     0x1180298: add             x17, PP, #0x90, lsl #12  ; [pp+0x903d0] IMM: double(0.5454545454545454) from 0x3fe1745d1745d174
    //     0x118029c: ldr             d5, [x17, #0x3d0]
    // 0x11802a0: d4 = 0.750000
    //     0x11802a0: fmov            d4, #0.75000000
    // 0x11802a4: fsub            d6, d3, d5
    // 0x11802a8: fmul            d5, d6, d2
    // 0x11802ac: fmul            d7, d5, d6
    // 0x11802b0: fadd            d5, d7, d4
    // 0x11802b4: mov             v2.16b, v5.16b
    // 0x11802b8: b               #0x1180314
    // 0x11802bc: d4 = 0.909091
    //     0x11802bc: add             x17, PP, #0x90, lsl #12  ; [pp+0x903d8] IMM: double(0.9090909090909091) from 0x3fed1745d1745d17
    //     0x11802c0: ldr             d4, [x17, #0x3d8]
    // 0x11802c4: fcmp            d4, d3
    // 0x11802c8: b.le            #0x11802f0
    // 0x11802cc: d5 = 0.818182
    //     0x11802cc: add             x17, PP, #0x90, lsl #12  ; [pp+0x903e0] IMM: double(0.8181818181818182) from 0x3fea2e8ba2e8ba2f
    //     0x11802d0: ldr             d5, [x17, #0x3e0]
    // 0x11802d4: d4 = 0.937500
    //     0x11802d4: fmov            d4, #0.93750000
    // 0x11802d8: fsub            d6, d3, d5
    // 0x11802dc: fmul            d5, d6, d2
    // 0x11802e0: fmul            d7, d5, d6
    // 0x11802e4: fadd            d5, d7, d4
    // 0x11802e8: mov             v2.16b, v5.16b
    // 0x11802ec: b               #0x1180314
    // 0x11802f0: d5 = 0.954545
    //     0x11802f0: add             x17, PP, #0x90, lsl #12  ; [pp+0x903e8] IMM: double(0.9545454545454546) from 0x3fee8ba2e8ba2e8c
    //     0x11802f4: ldr             d5, [x17, #0x3e8]
    // 0x11802f8: d4 = 0.984375
    //     0x11802f8: add             x17, PP, #0x90, lsl #12  ; [pp+0x903f0] IMM: double(0.984375) from 0x3fef800000000000
    //     0x11802fc: ldr             d4, [x17, #0x3f0]
    // 0x1180300: fsub            d6, d3, d5
    // 0x1180304: fmul            d3, d6, d2
    // 0x1180308: fmul            d2, d3, d6
    // 0x118030c: fadd            d3, d2, d4
    // 0x1180310: mov             v2.16b, v3.16b
    // 0x1180314: fsub            d0, d1, d2
    // 0x1180318: ret
    //     0x1180318: ret             
  }
}

// class id: 3326, size: 0xc, field offset: 0xc
//   const constructor, 
class _DecelerateCurve extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0x118023c, size: 0x14
    // 0x118023c: d1 = 1.000000
    //     0x118023c: fmov            d1, #1.00000000
    // 0x1180240: fsub            d2, d1, d0
    // 0x1180244: fmul            d3, d2, d2
    // 0x1180248: fsub            d0, d1, d3
    // 0x118024c: ret
    //     0x118024c: ret             
  }
}

// class id: 3327, size: 0x10, field offset: 0xc
//   const constructor, 
class FlippedCurve extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0x11801d4, size: 0x68
    // 0x11801d4: EnterFrame
    //     0x11801d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11801d8: mov             fp, SP
    // 0x11801dc: d1 = 1.000000
    //     0x11801dc: fmov            d1, #1.00000000
    // 0x11801e0: CheckStackOverflow
    //     0x11801e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11801e4: cmp             SP, x16
    //     0x11801e8: b.ls            #0x1180234
    // 0x11801ec: LoadField: r0 = r1->field_b
    //     0x11801ec: ldur            w0, [x1, #0xb]
    // 0x11801f0: DecompressPointer r0
    //     0x11801f0: add             x0, x0, HEAP, lsl #32
    // 0x11801f4: fsub            d2, d1, d0
    // 0x11801f8: r1 = LoadClassIdInstr(r0)
    //     0x11801f8: ldur            x1, [x0, #-1]
    //     0x11801fc: ubfx            x1, x1, #0xc, #0x14
    // 0x1180200: mov             x16, x0
    // 0x1180204: mov             x0, x1
    // 0x1180208: mov             x1, x16
    // 0x118020c: mov             v0.16b, v2.16b
    // 0x1180210: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1180210: sub             lr, x0, #1, lsl #12
    //     0x1180214: ldr             lr, [x21, lr, lsl #3]
    //     0x1180218: blr             lr
    // 0x118021c: d1 = 1.000000
    //     0x118021c: fmov            d1, #1.00000000
    // 0x1180220: fsub            d2, d1, d0
    // 0x1180224: mov             v0.16b, v2.16b
    // 0x1180228: LeaveFrame
    //     0x1180228: mov             SP, fp
    //     0x118022c: ldp             fp, lr, [SP], #0x10
    // 0x1180230: ret
    //     0x1180230: ret             
    // 0x1180234: r0 = StackOverflowSharedWithFPURegs()
    //     0x1180234: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1180238: b               #0x11801ec
  }
}

// class id: 3328, size: 0x20, field offset: 0xc
//   const constructor, 
class ThreePointCubic extends Curve {

  Offset field_c;
  Offset field_10;
  Offset field_14;
  Offset field_18;
  Offset field_1c;

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fff8, size: 0x1d0
    // 0x117fff8: EnterFrame
    //     0x117fff8: stp             fp, lr, [SP, #-0x10]!
    //     0x117fffc: mov             fp, SP
    // 0x1180000: AllocStack(0x38)
    //     0x1180000: sub             SP, SP, #0x38
    // 0x1180004: CheckStackOverflow
    //     0x1180004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1180008: cmp             SP, x16
    //     0x118000c: b.ls            #0x11801c0
    // 0x1180010: LoadField: r0 = r1->field_13
    //     0x1180010: ldur            w0, [x1, #0x13]
    // 0x1180014: DecompressPointer r0
    //     0x1180014: add             x0, x0, HEAP, lsl #32
    // 0x1180018: LoadField: d1 = r0->field_7
    //     0x1180018: ldur            d1, [x0, #7]
    // 0x118001c: fcmp            d1, d0
    // 0x1180020: r16 = true
    //     0x1180020: add             x16, NULL, #0x20  ; true
    // 0x1180024: r17 = false
    //     0x1180024: add             x17, NULL, #0x30  ; false
    // 0x1180028: csel            x2, x16, x17, gt
    // 0x118002c: tbnz            w2, #4, #0x118003c
    // 0x1180030: mov             v3.16b, v1.16b
    // 0x1180034: d2 = 1.000000
    //     0x1180034: fmov            d2, #1.00000000
    // 0x1180038: b               #0x1180044
    // 0x118003c: d2 = 1.000000
    //     0x118003c: fmov            d2, #1.00000000
    // 0x1180040: fsub            d3, d2, d1
    // 0x1180044: tbnz            w2, #4, #0x1180054
    // 0x1180048: LoadField: d2 = r0->field_f
    //     0x1180048: ldur            d2, [x0, #0xf]
    // 0x118004c: mov             v4.16b, v2.16b
    // 0x1180050: b               #0x1180064
    // 0x1180054: LoadField: d4 = r0->field_f
    //     0x1180054: ldur            d4, [x0, #0xf]
    // 0x1180058: fsub            d5, d2, d4
    // 0x118005c: mov             v2.16b, v4.16b
    // 0x1180060: mov             v4.16b, v5.16b
    // 0x1180064: stur            d4, [fp, #-0x30]
    // 0x1180068: stur            d2, [fp, #-0x38]
    // 0x118006c: tbnz            w2, #4, #0x1180078
    // 0x1180070: d5 = 0.000000
    //     0x1180070: eor             v5.16b, v5.16b, v5.16b
    // 0x1180074: b               #0x118007c
    // 0x1180078: mov             v5.16b, v1.16b
    // 0x118007c: fsub            d6, d0, d5
    // 0x1180080: fdiv            d0, d6, d3
    // 0x1180084: stur            d0, [fp, #-0x28]
    // 0x1180088: tbnz            w2, #4, #0x118011c
    // 0x118008c: LoadField: r0 = r1->field_b
    //     0x118008c: ldur            w0, [x1, #0xb]
    // 0x1180090: DecompressPointer r0
    //     0x1180090: add             x0, x0, HEAP, lsl #32
    // 0x1180094: LoadField: d1 = r0->field_7
    //     0x1180094: ldur            d1, [x0, #7]
    // 0x1180098: fdiv            d2, d1, d3
    // 0x118009c: stur            d2, [fp, #-0x20]
    // 0x11800a0: LoadField: d1 = r0->field_f
    //     0x11800a0: ldur            d1, [x0, #0xf]
    // 0x11800a4: fdiv            d5, d1, d4
    // 0x11800a8: stur            d5, [fp, #-0x18]
    // 0x11800ac: LoadField: r0 = r1->field_f
    //     0x11800ac: ldur            w0, [x1, #0xf]
    // 0x11800b0: DecompressPointer r0
    //     0x11800b0: add             x0, x0, HEAP, lsl #32
    // 0x11800b4: LoadField: d1 = r0->field_7
    //     0x11800b4: ldur            d1, [x0, #7]
    // 0x11800b8: fdiv            d6, d1, d3
    // 0x11800bc: stur            d6, [fp, #-0x10]
    // 0x11800c0: LoadField: d1 = r0->field_f
    //     0x11800c0: ldur            d1, [x0, #0xf]
    // 0x11800c4: fdiv            d3, d1, d4
    // 0x11800c8: stur            d3, [fp, #-8]
    // 0x11800cc: r1 = <double>
    //     0x11800cc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11800d0: r0 = Cubic()
    //     0x11800d0: bl              #0x11801c8  ; AllocateCubicStub -> Cubic (size=0x2c)
    // 0x11800d4: ldur            d0, [fp, #-0x20]
    // 0x11800d8: StoreField: r0->field_b = d0
    //     0x11800d8: stur            d0, [x0, #0xb]
    // 0x11800dc: ldur            d0, [fp, #-0x18]
    // 0x11800e0: StoreField: r0->field_13 = d0
    //     0x11800e0: stur            d0, [x0, #0x13]
    // 0x11800e4: ldur            d0, [fp, #-0x10]
    // 0x11800e8: StoreField: r0->field_1b = d0
    //     0x11800e8: stur            d0, [x0, #0x1b]
    // 0x11800ec: ldur            d0, [fp, #-8]
    // 0x11800f0: StoreField: r0->field_23 = d0
    //     0x11800f0: stur            d0, [x0, #0x23]
    // 0x11800f4: mov             x1, x0
    // 0x11800f8: ldur            d0, [fp, #-0x28]
    // 0x11800fc: r0 = transform()
    //     0x11800fc: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x1180100: mov             v1.16b, v0.16b
    // 0x1180104: ldur            d0, [fp, #-0x30]
    // 0x1180108: fmul            d2, d1, d0
    // 0x118010c: mov             v0.16b, v2.16b
    // 0x1180110: LeaveFrame
    //     0x1180110: mov             SP, fp
    //     0x1180114: ldp             fp, lr, [SP], #0x10
    // 0x1180118: ret
    //     0x1180118: ret             
    // 0x118011c: mov             v0.16b, v4.16b
    // 0x1180120: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1180120: ldur            w0, [x1, #0x17]
    // 0x1180124: DecompressPointer r0
    //     0x1180124: add             x0, x0, HEAP, lsl #32
    // 0x1180128: LoadField: d4 = r0->field_7
    //     0x1180128: ldur            d4, [x0, #7]
    // 0x118012c: fsub            d5, d4, d1
    // 0x1180130: fdiv            d4, d5, d3
    // 0x1180134: stur            d4, [fp, #-0x20]
    // 0x1180138: LoadField: d5 = r0->field_f
    //     0x1180138: ldur            d5, [x0, #0xf]
    // 0x118013c: fsub            d6, d5, d2
    // 0x1180140: fdiv            d5, d6, d0
    // 0x1180144: stur            d5, [fp, #-0x18]
    // 0x1180148: LoadField: r0 = r1->field_1b
    //     0x1180148: ldur            w0, [x1, #0x1b]
    // 0x118014c: DecompressPointer r0
    //     0x118014c: add             x0, x0, HEAP, lsl #32
    // 0x1180150: LoadField: d6 = r0->field_7
    //     0x1180150: ldur            d6, [x0, #7]
    // 0x1180154: fsub            d7, d6, d1
    // 0x1180158: fdiv            d1, d7, d3
    // 0x118015c: stur            d1, [fp, #-0x10]
    // 0x1180160: LoadField: d3 = r0->field_f
    //     0x1180160: ldur            d3, [x0, #0xf]
    // 0x1180164: fsub            d6, d3, d2
    // 0x1180168: fdiv            d3, d6, d0
    // 0x118016c: stur            d3, [fp, #-8]
    // 0x1180170: r1 = <double>
    //     0x1180170: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1180174: r0 = Cubic()
    //     0x1180174: bl              #0x11801c8  ; AllocateCubicStub -> Cubic (size=0x2c)
    // 0x1180178: ldur            d0, [fp, #-0x20]
    // 0x118017c: StoreField: r0->field_b = d0
    //     0x118017c: stur            d0, [x0, #0xb]
    // 0x1180180: ldur            d0, [fp, #-0x18]
    // 0x1180184: StoreField: r0->field_13 = d0
    //     0x1180184: stur            d0, [x0, #0x13]
    // 0x1180188: ldur            d0, [fp, #-0x10]
    // 0x118018c: StoreField: r0->field_1b = d0
    //     0x118018c: stur            d0, [x0, #0x1b]
    // 0x1180190: ldur            d0, [fp, #-8]
    // 0x1180194: StoreField: r0->field_23 = d0
    //     0x1180194: stur            d0, [x0, #0x23]
    // 0x1180198: mov             x1, x0
    // 0x118019c: ldur            d0, [fp, #-0x28]
    // 0x11801a0: r0 = transform()
    //     0x11801a0: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x11801a4: ldur            d1, [fp, #-0x30]
    // 0x11801a8: fmul            d2, d0, d1
    // 0x11801ac: ldur            d1, [fp, #-0x38]
    // 0x11801b0: fadd            d0, d2, d1
    // 0x11801b4: LeaveFrame
    //     0x11801b4: mov             SP, fp
    //     0x11801b8: ldp             fp, lr, [SP], #0x10
    // 0x11801bc: ret
    //     0x11801bc: ret             
    // 0x11801c0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11801c0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11801c4: b               #0x1180010
  }
}

// class id: 3329, size: 0x2c, field offset: 0xc
//   const constructor, 
class Cubic extends Curve {

  _Double field_c;
  _Double field_14;
  _Double field_1c;
  _Double field_24;

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fef0, size: 0x108
    // 0x117fef0: d1 = 3.000000
    //     0x117fef0: fmov            d1, #3.00000000
    // 0x117fef4: LoadField: d2 = r1->field_b
    //     0x117fef4: ldur            d2, [x1, #0xb]
    // 0x117fef8: LoadField: d3 = r1->field_1b
    //     0x117fef8: ldur            d3, [x1, #0x1b]
    // 0x117fefc: fmul            d4, d2, d1
    // 0x117ff00: fmul            d2, d3, d1
    // 0x117ff04: d9 = 0.000000
    //     0x117ff04: eor             v9.16b, v9.16b, v9.16b
    // 0x117ff08: d8 = 1.000000
    //     0x117ff08: fmov            d8, #1.00000000
    // 0x117ff0c: d7 = 1.000000
    //     0x117ff0c: fmov            d7, #1.00000000
    // 0x117ff10: d6 = 2.000000
    //     0x117ff10: fmov            d6, #2.00000000
    // 0x117ff14: d5 = 0.000000
    //     0x117ff14: eor             v5.16b, v5.16b, v5.16b
    // 0x117ff18: d3 = 0.001000
    //     0x117ff18: ldr             d3, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x117ff1c: CheckStackOverflow
    //     0x117ff1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x117ff20: cmp             SP, x16
    //     0x117ff24: b.ls            #0x117ffe0
    // 0x117ff28: fadd            d10, d9, d8
    // 0x117ff2c: fdiv            d11, d10, d6
    // 0x117ff30: fsub            d10, d7, d11
    // 0x117ff34: fmul            d12, d4, d10
    // 0x117ff38: fmul            d13, d12, d10
    // 0x117ff3c: fmul            d12, d13, d11
    // 0x117ff40: fmul            d13, d2, d10
    // 0x117ff44: fmul            d14, d13, d11
    // 0x117ff48: fmul            d13, d14, d11
    // 0x117ff4c: fadd            d14, d12, d13
    // 0x117ff50: fmul            d12, d11, d11
    // 0x117ff54: fmul            d13, d12, d11
    // 0x117ff58: fadd            d12, d14, d13
    // 0x117ff5c: fsub            d14, d0, d12
    // 0x117ff60: fcmp            d14, d5
    // 0x117ff64: b.ne            #0x117ff74
    // 0x117ff68: fcmp            d3, d5
    // 0x117ff6c: b.le            #0x117ff94
    // 0x117ff70: b               #0x117ffac
    // 0x117ff74: fcmp            d5, d14
    // 0x117ff78: b.le            #0x117ff8c
    // 0x117ff7c: fneg            d15, d14
    // 0x117ff80: fcmp            d3, d15
    // 0x117ff84: b.le            #0x117ff94
    // 0x117ff88: b               #0x117ffac
    // 0x117ff8c: fcmp            d3, d14
    // 0x117ff90: b.gt            #0x117ffac
    // 0x117ff94: fcmp            d0, d12
    // 0x117ff98: b.le            #0x117ffa4
    // 0x117ff9c: mov             v9.16b, v11.16b
    // 0x117ffa0: b               #0x117ff1c
    // 0x117ffa4: mov             v8.16b, v11.16b
    // 0x117ffa8: b               #0x117ff1c
    // 0x117ffac: LoadField: d2 = r1->field_13
    //     0x117ffac: ldur            d2, [x1, #0x13]
    // 0x117ffb0: LoadField: d3 = r1->field_23
    //     0x117ffb0: ldur            d3, [x1, #0x23]
    // 0x117ffb4: fmul            d4, d2, d1
    // 0x117ffb8: fmul            d2, d4, d10
    // 0x117ffbc: fmul            d4, d2, d10
    // 0x117ffc0: fmul            d2, d4, d11
    // 0x117ffc4: fmul            d4, d3, d1
    // 0x117ffc8: fmul            d1, d4, d10
    // 0x117ffcc: fmul            d3, d1, d11
    // 0x117ffd0: fmul            d1, d3, d11
    // 0x117ffd4: fadd            d3, d2, d1
    // 0x117ffd8: fadd            d0, d3, d13
    // 0x117ffdc: ret
    //     0x117ffdc: ret             
    // 0x117ffe0: EnterFrame
    //     0x117ffe0: stp             fp, lr, [SP, #-0x10]!
    //     0x117ffe4: mov             fp, SP
    // 0x117ffe8: r0 = StackOverflowSharedWithFPURegs()
    //     0x117ffe8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x117ffec: LeaveFrame
    //     0x117ffec: mov             SP, fp
    //     0x117fff0: ldp             fp, lr, [SP], #0x10
    // 0x117fff4: b               #0x117ff28
  }
}

// class id: 3330, size: 0x14, field offset: 0xc
//   const constructor, 
class Threshold extends Curve {

  _Mint field_c;

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fed4, size: 0x1c
    // 0x117fed4: LoadField: d1 = r1->field_b
    //     0x117fed4: ldur            d1, [x1, #0xb]
    // 0x117fed8: fcmp            d1, d0
    // 0x117fedc: b.le            #0x117fee8
    // 0x117fee0: d0 = 0.000000
    //     0x117fee0: eor             v0.16b, v0.16b, v0.16b
    // 0x117fee4: b               #0x117feec
    // 0x117fee8: d0 = 1.000000
    //     0x117fee8: fmov            d0, #1.00000000
    // 0x117feec: ret
    //     0x117feec: ret             
  }
}

// class id: 3331, size: 0x1c, field offset: 0xc
//   const constructor, 
class Split extends Curve {

  _ transform(/* No info */) {
    // ** addr: 0x12f4bc8, size: 0x1e4
    // 0x12f4bc8: EnterFrame
    //     0x12f4bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4bcc: mov             fp, SP
    // 0x12f4bd0: AllocStack(0x8)
    //     0x12f4bd0: sub             SP, SP, #8
    // 0x12f4bd4: d1 = 0.000000
    //     0x12f4bd4: eor             v1.16b, v1.16b, v1.16b
    // 0x12f4bd8: CheckStackOverflow
    //     0x12f4bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4bdc: cmp             SP, x16
    //     0x12f4be0: b.ls            #0x12f4d44
    // 0x12f4be4: fcmp            d0, d1
    // 0x12f4be8: b.eq            #0x12f4bf8
    // 0x12f4bec: d1 = 1.000000
    //     0x12f4bec: fmov            d1, #1.00000000
    // 0x12f4bf0: fcmp            d0, d1
    // 0x12f4bf4: b.ne            #0x12f4c04
    // 0x12f4bf8: LeaveFrame
    //     0x12f4bf8: mov             SP, fp
    //     0x12f4bfc: ldp             fp, lr, [SP], #0x10
    // 0x12f4c00: ret
    //     0x12f4c00: ret             
    // 0x12f4c04: LoadField: d2 = r1->field_b
    //     0x12f4c04: ldur            d2, [x1, #0xb]
    // 0x12f4c08: stur            d2, [fp, #-8]
    // 0x12f4c0c: fcmp            d0, d2
    // 0x12f4c10: b.ne            #0x12f4c24
    // 0x12f4c14: mov             v0.16b, v2.16b
    // 0x12f4c18: LeaveFrame
    //     0x12f4c18: mov             SP, fp
    //     0x12f4c1c: ldp             fp, lr, [SP], #0x10
    // 0x12f4c20: ret
    //     0x12f4c20: ret             
    // 0x12f4c24: fcmp            d2, d0
    // 0x12f4c28: b.le            #0x12f4cb0
    // 0x12f4c2c: fdiv            d1, d0, d2
    // 0x12f4c30: mov             v0.16b, v1.16b
    // 0x12f4c34: r1 = Instance__Linear
    //     0x12f4c34: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0x12f4c38: r0 = transform()
    //     0x12f4c38: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x12f4c3c: r3 = inline_Allocate_Double()
    //     0x12f4c3c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12f4c40: add             x3, x3, #0x10
    //     0x12f4c44: cmp             x0, x3
    //     0x12f4c48: b.ls            #0x12f4d4c
    //     0x12f4c4c: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f4c50: sub             x3, x3, #0xf
    //     0x12f4c54: mov             x0, #0xe19c
    //     0x12f4c58: movk            x0, #3, lsl #16
    //     0x12f4c5c: stur            x0, [x3, #-1]
    // 0x12f4c60: dmb             ishst
    // 0x12f4c64: StoreField: r3->field_7 = d0
    //     0x12f4c64: stur            d0, [x3, #7]
    // 0x12f4c68: ldur            d2, [fp, #-8]
    // 0x12f4c6c: r2 = inline_Allocate_Double()
    //     0x12f4c6c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x12f4c70: add             x2, x2, #0x10
    //     0x12f4c74: cmp             x0, x2
    //     0x12f4c78: b.ls            #0x12f4d60
    //     0x12f4c7c: str             x2, [THR, #0x60]  ; THR::top
    //     0x12f4c80: sub             x2, x2, #0xf
    //     0x12f4c84: mov             x0, #0xe19c
    //     0x12f4c88: movk            x0, #3, lsl #16
    //     0x12f4c8c: stur            x0, [x2, #-1]
    // 0x12f4c90: dmb             ishst
    // 0x12f4c94: StoreField: r2->field_7 = d2
    //     0x12f4c94: stur            d2, [x2, #7]
    // 0x12f4c98: r1 = 0
    //     0x12f4c98: mov             x1, #0
    // 0x12f4c9c: r0 = lerpDouble()
    //     0x12f4c9c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x12f4ca0: LoadField: d0 = r0->field_7
    //     0x12f4ca0: ldur            d0, [x0, #7]
    // 0x12f4ca4: LeaveFrame
    //     0x12f4ca4: mov             SP, fp
    //     0x12f4ca8: ldp             fp, lr, [SP], #0x10
    // 0x12f4cac: ret
    //     0x12f4cac: ret             
    // 0x12f4cb0: fsub            d3, d0, d2
    // 0x12f4cb4: fsub            d0, d1, d2
    // 0x12f4cb8: fdiv            d1, d3, d0
    // 0x12f4cbc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12f4cbc: ldur            w0, [x1, #0x17]
    // 0x12f4cc0: DecompressPointer r0
    //     0x12f4cc0: add             x0, x0, HEAP, lsl #32
    // 0x12f4cc4: mov             x1, x0
    // 0x12f4cc8: mov             v0.16b, v1.16b
    // 0x12f4ccc: r0 = transform()
    //     0x12f4ccc: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x12f4cd0: r3 = inline_Allocate_Double()
    //     0x12f4cd0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12f4cd4: add             x3, x3, #0x10
    //     0x12f4cd8: cmp             x0, x3
    //     0x12f4cdc: b.ls            #0x12f4d7c
    //     0x12f4ce0: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f4ce4: sub             x3, x3, #0xf
    //     0x12f4ce8: mov             x0, #0xe19c
    //     0x12f4cec: movk            x0, #3, lsl #16
    //     0x12f4cf0: stur            x0, [x3, #-1]
    // 0x12f4cf4: dmb             ishst
    // 0x12f4cf8: StoreField: r3->field_7 = d0
    //     0x12f4cf8: stur            d0, [x3, #7]
    // 0x12f4cfc: ldur            d0, [fp, #-8]
    // 0x12f4d00: r1 = inline_Allocate_Double()
    //     0x12f4d00: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x12f4d04: add             x1, x1, #0x10
    //     0x12f4d08: cmp             x0, x1
    //     0x12f4d0c: b.ls            #0x12f4d90
    //     0x12f4d10: str             x1, [THR, #0x60]  ; THR::top
    //     0x12f4d14: sub             x1, x1, #0xf
    //     0x12f4d18: mov             x0, #0xe19c
    //     0x12f4d1c: movk            x0, #3, lsl #16
    //     0x12f4d20: stur            x0, [x1, #-1]
    // 0x12f4d24: dmb             ishst
    // 0x12f4d28: StoreField: r1->field_7 = d0
    //     0x12f4d28: stur            d0, [x1, #7]
    // 0x12f4d2c: r2 = 2
    //     0x12f4d2c: mov             x2, #2
    // 0x12f4d30: r0 = lerpDouble()
    //     0x12f4d30: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x12f4d34: LoadField: d0 = r0->field_7
    //     0x12f4d34: ldur            d0, [x0, #7]
    // 0x12f4d38: LeaveFrame
    //     0x12f4d38: mov             SP, fp
    //     0x12f4d3c: ldp             fp, lr, [SP], #0x10
    // 0x12f4d40: ret
    //     0x12f4d40: ret             
    // 0x12f4d44: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f4d44: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f4d48: b               #0x12f4be4
    // 0x12f4d4c: SaveReg d0
    //     0x12f4d4c: str             q0, [SP, #-0x10]!
    // 0x12f4d50: r0 = AllocateDouble()
    //     0x12f4d50: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f4d54: mov             x3, x0
    // 0x12f4d58: RestoreReg d0
    //     0x12f4d58: ldr             q0, [SP], #0x10
    // 0x12f4d5c: b               #0x12f4c64
    // 0x12f4d60: SaveReg d2
    //     0x12f4d60: str             q2, [SP, #-0x10]!
    // 0x12f4d64: SaveReg r3
    //     0x12f4d64: str             x3, [SP, #-8]!
    // 0x12f4d68: r0 = AllocateDouble()
    //     0x12f4d68: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f4d6c: mov             x2, x0
    // 0x12f4d70: RestoreReg r3
    //     0x12f4d70: ldr             x3, [SP], #8
    // 0x12f4d74: RestoreReg d2
    //     0x12f4d74: ldr             q2, [SP], #0x10
    // 0x12f4d78: b               #0x12f4c94
    // 0x12f4d7c: SaveReg d0
    //     0x12f4d7c: str             q0, [SP, #-0x10]!
    // 0x12f4d80: r0 = AllocateDouble()
    //     0x12f4d80: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f4d84: mov             x3, x0
    // 0x12f4d88: RestoreReg d0
    //     0x12f4d88: ldr             q0, [SP], #0x10
    // 0x12f4d8c: b               #0x12f4cf8
    // 0x12f4d90: SaveReg d0
    //     0x12f4d90: str             q0, [SP, #-0x10]!
    // 0x12f4d94: SaveReg r3
    //     0x12f4d94: str             x3, [SP, #-8]!
    // 0x12f4d98: r0 = AllocateDouble()
    //     0x12f4d98: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f4d9c: mov             x1, x0
    // 0x12f4da0: RestoreReg r3
    //     0x12f4da0: ldr             x3, [SP], #8
    // 0x12f4da4: RestoreReg d0
    //     0x12f4da4: ldr             q0, [SP], #0x10
    // 0x12f4da8: b               #0x12f4d28
  }
}

// class id: 3332, size: 0x20, field offset: 0xc
//   const constructor, 
class Interval extends Curve {

  _Mint field_c;
  _Double field_14;
  Cubic field_1c;

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fe1c, size: 0xb8
    // 0x117fe1c: EnterFrame
    //     0x117fe1c: stp             fp, lr, [SP, #-0x10]!
    //     0x117fe20: mov             fp, SP
    // 0x117fe24: d1 = 0.000000
    //     0x117fe24: eor             v1.16b, v1.16b, v1.16b
    // 0x117fe28: CheckStackOverflow
    //     0x117fe28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x117fe2c: cmp             SP, x16
    //     0x117fe30: b.ls            #0x117fecc
    // 0x117fe34: LoadField: d2 = r1->field_b
    //     0x117fe34: ldur            d2, [x1, #0xb]
    // 0x117fe38: fsub            d3, d0, d2
    // 0x117fe3c: LoadField: d0 = r1->field_13
    //     0x117fe3c: ldur            d0, [x1, #0x13]
    // 0x117fe40: fsub            d4, d0, d2
    // 0x117fe44: fdiv            d0, d3, d4
    // 0x117fe48: fcmp            d1, d0
    // 0x117fe4c: b.le            #0x117fe5c
    // 0x117fe50: d0 = 0.000000
    //     0x117fe50: eor             v0.16b, v0.16b, v0.16b
    // 0x117fe54: d2 = 1.000000
    //     0x117fe54: fmov            d2, #1.00000000
    // 0x117fe58: b               #0x117fe7c
    // 0x117fe5c: d2 = 1.000000
    //     0x117fe5c: fmov            d2, #1.00000000
    // 0x117fe60: fcmp            d0, d2
    // 0x117fe64: b.le            #0x117fe70
    // 0x117fe68: d0 = 1.000000
    //     0x117fe68: fmov            d0, #1.00000000
    // 0x117fe6c: b               #0x117fe7c
    // 0x117fe70: fcmp            d0, d0
    // 0x117fe74: b.vc            #0x117fe7c
    // 0x117fe78: d0 = 1.000000
    //     0x117fe78: fmov            d0, #1.00000000
    // 0x117fe7c: fcmp            d0, d1
    // 0x117fe80: b.eq            #0x117fe8c
    // 0x117fe84: fcmp            d0, d2
    // 0x117fe88: b.ne            #0x117fe98
    // 0x117fe8c: LeaveFrame
    //     0x117fe8c: mov             SP, fp
    //     0x117fe90: ldp             fp, lr, [SP], #0x10
    // 0x117fe94: ret
    //     0x117fe94: ret             
    // 0x117fe98: LoadField: r0 = r1->field_1b
    //     0x117fe98: ldur            w0, [x1, #0x1b]
    // 0x117fe9c: DecompressPointer r0
    //     0x117fe9c: add             x0, x0, HEAP, lsl #32
    // 0x117fea0: r1 = LoadClassIdInstr(r0)
    //     0x117fea0: ldur            x1, [x0, #-1]
    //     0x117fea4: ubfx            x1, x1, #0xc, #0x14
    // 0x117fea8: mov             x16, x0
    // 0x117feac: mov             x0, x1
    // 0x117feb0: mov             x1, x16
    // 0x117feb4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x117feb4: sub             lr, x0, #1, lsl #12
    //     0x117feb8: ldr             lr, [x21, lr, lsl #3]
    //     0x117febc: blr             lr
    // 0x117fec0: LeaveFrame
    //     0x117fec0: mov             SP, fp
    //     0x117fec4: ldp             fp, lr, [SP], #0x10
    // 0x117fec8: ret
    //     0x117fec8: ret             
    // 0x117fecc: r0 = StackOverflowSharedWithFPURegs()
    //     0x117fecc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x117fed0: b               #0x117fe34
  }
}

// class id: 3333, size: 0x14, field offset: 0xc
//   const constructor, 
class SawTooth extends Curve {

  _Mint field_c;

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fdb0, size: 0x6c
    // 0x117fdb0: EnterFrame
    //     0x117fdb0: stp             fp, lr, [SP, #-0x10]!
    //     0x117fdb4: mov             fp, SP
    // 0x117fdb8: AllocStack(0x8)
    //     0x117fdb8: sub             SP, SP, #8
    // 0x117fdbc: LoadField: r19 = r1->field_b
    //     0x117fdbc: ldur            x19, [x1, #0xb]
    // 0x117fdc0: scvtf           d1, x19
    // 0x117fdc4: fmul            d2, d0, d1
    // 0x117fdc8: mov             v0.16b, v2.16b
    // 0x117fdcc: stur            d2, [fp, #-8]
    // 0x117fdd0: stp             fp, lr, [SP, #-0x10]!
    // 0x117fdd4: mov             fp, SP
    // 0x117fdd8: CallRuntime_LibcTrunc(double) -> double
    //     0x117fdd8: and             SP, SP, #0xfffffffffffffff0
    //     0x117fddc: mov             sp, SP
    //     0x117fde0: ldr             x16, [THR, #0x768]  ; THR::LibcTrunc
    //     0x117fde4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x117fde8: blr             x16
    //     0x117fdec: mov             x16, #8
    //     0x117fdf0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x117fdf4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x117fdf8: sub             sp, x16, #1, lsl #12
    //     0x117fdfc: mov             SP, fp
    //     0x117fe00: ldp             fp, lr, [SP], #0x10
    // 0x117fe04: ldur            d1, [fp, #-8]
    // 0x117fe08: fsub            d2, d1, d0
    // 0x117fe0c: mov             v0.16b, v2.16b
    // 0x117fe10: LeaveFrame
    //     0x117fe10: mov             SP, fp
    //     0x117fe14: ldp             fp, lr, [SP], #0x10
    // 0x117fe18: ret
    //     0x117fe18: ret             
  }
}

// class id: 3334, size: 0xc, field offset: 0xc
//   const constructor, 
class _Linear extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0x117fda8, size: 0x8
    // 0x117fda8: mov             v1.16b, v0.16b
    // 0x117fdac: ret
    //     0x117fdac: ret             
  }
}
