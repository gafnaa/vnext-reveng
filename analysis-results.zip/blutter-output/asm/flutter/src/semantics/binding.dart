// lib: , url: package:flutter/src/semantics/binding.dart

// class id: 1049061, size: 0x8
class :: {
}

// class id: 2828, size: 0xc, field offset: 0x8
class SemanticsHandle extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x8451e4, size: 0x40
    // 0x8451e4: EnterFrame
    //     0x8451e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8451e8: mov             fp, SP
    // 0x8451ec: CheckStackOverflow
    //     0x8451ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8451f0: cmp             SP, x16
    //     0x8451f4: b.ls            #0x84521c
    // 0x8451f8: LoadField: r0 = r1->field_7
    //     0x8451f8: ldur            w0, [x1, #7]
    // 0x8451fc: DecompressPointer r0
    //     0x8451fc: add             x0, x0, HEAP, lsl #32
    // 0x845200: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x845200: ldur            w1, [x0, #0x17]
    // 0x845204: DecompressPointer r1
    //     0x845204: add             x1, x1, HEAP, lsl #32
    // 0x845208: r0 = _didDisposeSemanticsHandle()
    //     0x845208: bl              #0x84525c  ; [dart:mixin_deduplication] _MixinApplication206&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding::_didDisposeSemanticsHandle
    // 0x84520c: r0 = Null
    //     0x84520c: mov             x0, NULL
    // 0x845210: LeaveFrame
    //     0x845210: mov             SP, fp
    //     0x845214: ldp             fp, lr, [SP], #0x10
    // 0x845218: ret
    //     0x845218: ret             
    // 0x84521c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84521c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845220: b               #0x8451f8
  }
}

// class id: 4610, size: 0x10, field offset: 0x10
abstract class SemanticsBinding extends BindingBase {

  get _ instance(/* No info */) {
    // ** addr: 0x83b718, size: 0x20
    // 0x83b718: r0 = LoadStaticField(0x7d4)
    //     0x83b718: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83b71c: ldr             x0, [x0, #0xfa8]
    // 0x83b720: cmp             w0, NULL
    // 0x83b724: b.eq            #0x83b72c
    // 0x83b728: ret
    //     0x83b728: ret             
    // 0x83b72c: EnterFrame
    //     0x83b72c: stp             fp, lr, [SP, #-0x10]!
    //     0x83b730: mov             fp, SP
    // 0x83b734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
