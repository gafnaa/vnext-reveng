// lib: , url: package:flutter/src/semantics/semantics_service.dart

// class id: 1049064, size: 0x8
class :: {
}

// class id: 2813, size: 0x8, field offset: 0x8
abstract class SemanticsService extends Object {

  static _ tooltip(/* No info */) async {
    // ** addr: 0xcfb9d0, size: 0x74
    // 0xcfb9d0: EnterFrame
    //     0xcfb9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb9d4: mov             fp, SP
    // 0xcfb9d8: AllocStack(0x10)
    //     0xcfb9d8: sub             SP, SP, #0x10
    // 0xcfb9dc: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xcfb9dc: stur            NULL, [fp, #-8]
    //     0xcfb9e0: stur            x1, [fp, #-0x10]
    // 0xcfb9e4: CheckStackOverflow
    //     0xcfb9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfb9e8: cmp             SP, x16
    //     0xcfb9ec: b.ls            #0xcfba3c
    // 0xcfb9f0: InitAsync() -> Future<void?>
    //     0xcfb9f0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xcfb9f4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xcfb9f8: r0 = TooltipSemanticsEvent()
    //     0xcfb9f8: bl              #0xcfba44  ; AllocateTooltipSemanticsEventStub -> TooltipSemanticsEvent (size=0x10)
    // 0xcfb9fc: mov             x1, x0
    // 0xcfba00: ldur            x0, [fp, #-0x10]
    // 0xcfba04: StoreField: r1->field_b = r0
    //     0xcfba04: stur            w0, [x1, #0xb]
    // 0xcfba08: r0 = "tooltip"
    //     0xcfba08: add             x0, PP, #0x15, lsl #12  ; [pp+0x15220] "tooltip"
    //     0xcfba0c: ldr             x0, [x0, #0x220]
    // 0xcfba10: StoreField: r1->field_7 = r0
    //     0xcfba10: stur            w0, [x1, #7]
    // 0xcfba14: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xcfba14: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xcfba18: r0 = toMap()
    //     0xcfba18: bl              #0x8cd444  ; [package:flutter/src/semantics/semantics_event.dart] SemanticsEvent::toMap
    // 0xcfba1c: mov             x2, x0
    // 0xcfba20: r1 = Instance_BasicMessageChannel
    //     0xcfba20: ldr             x1, [PP, #0x3088]  ; [pp+0x3088] Obj!BasicMessageChannel<Object?>@129bfe1
    // 0xcfba24: r0 = send()
    //     0xcfba24: bl              #0x8bf9c0  ; [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::send
    // 0xcfba28: mov             x1, x0
    // 0xcfba2c: stur            x1, [fp, #-0x10]
    // 0xcfba30: r0 = Await()
    //     0xcfba30: bl              #0x7f5c00  ; AwaitStub
    // 0xcfba34: r0 = Null
    //     0xcfba34: mov             x0, NULL
    // 0xcfba38: r0 = ReturnAsyncNotFuture()
    //     0xcfba38: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xcfba3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfba3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfba40: b               #0xcfb9f0
  }
  static _ sendAnnouncement(/* No info */) async {
    // ** addr: 0xd19630, size: 0xe4
    // 0xd19630: EnterFrame
    //     0xd19630: stp             fp, lr, [SP, #-0x10]!
    //     0xd19634: mov             fp, SP
    // 0xd19638: AllocStack(0x30)
    //     0xd19638: sub             SP, SP, #0x30
    // 0xd1963c: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, {dynamic assertiveness = Instance_Assertiveness /* r4, fp-0x10 */})
    //     0xd1963c: stur            NULL, [fp, #-8]
    //     0xd19640: stur            x1, [fp, #-0x18]
    //     0xd19644: stur            x2, [fp, #-0x20]
    //     0xd19648: stur            x3, [fp, #-0x28]
    //     0xd1964c: ldur            w0, [x4, #0x13]
    //     0xd19650: ldur            w5, [x4, #0x1f]
    //     0xd19654: add             x5, x5, HEAP, lsl #32
    //     0xd19658: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cc50] "assertiveness"
    //     0xd1965c: ldr             x16, [x16, #0xc50]
    //     0xd19660: cmp             w5, w16
    //     0xd19664: b.ne            #0xd19684
    //     0xd19668: ldur            w5, [x4, #0x23]
    //     0xd1966c: add             x5, x5, HEAP, lsl #32
    //     0xd19670: sub             w4, w0, w5
    //     0xd19674: add             x0, fp, w4, sxtw #2
    //     0xd19678: ldr             x0, [x0, #8]
    //     0xd1967c: mov             x4, x0
    //     0xd19680: b               #0xd1968c
    //     0xd19684: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cc58] Obj!Assertiveness@12c3e81
    //     0xd19688: ldr             x4, [x4, #0xc58]
    //     0xd1968c: stur            x4, [fp, #-0x10]
    // 0xd19690: CheckStackOverflow
    //     0xd19690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19694: cmp             SP, x16
    //     0xd19698: b.ls            #0xd1970c
    // 0xd1969c: InitAsync() -> Future<void?>
    //     0xd1969c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd196a0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd196a4: ldur            x0, [fp, #-0x18]
    // 0xd196a8: LoadField: r1 = r0->field_7
    //     0xd196a8: ldur            x1, [x0, #7]
    // 0xd196ac: stur            x1, [fp, #-0x30]
    // 0xd196b0: r0 = AnnounceSemanticsEvent()
    //     0xd196b0: bl              #0xd19714  ; AllocateAnnounceSemanticsEventStub -> AnnounceSemanticsEvent (size=0x20)
    // 0xd196b4: mov             x1, x0
    // 0xd196b8: ldur            x0, [fp, #-0x20]
    // 0xd196bc: StoreField: r1->field_13 = r0
    //     0xd196bc: stur            w0, [x1, #0x13]
    // 0xd196c0: ldur            x0, [fp, #-0x28]
    // 0xd196c4: ArrayStore: r1[0] = r0  ; List_4
    //     0xd196c4: stur            w0, [x1, #0x17]
    // 0xd196c8: ldur            x0, [fp, #-0x30]
    // 0xd196cc: StoreField: r1->field_b = r0
    //     0xd196cc: stur            x0, [x1, #0xb]
    // 0xd196d0: ldur            x0, [fp, #-0x10]
    // 0xd196d4: StoreField: r1->field_1b = r0
    //     0xd196d4: stur            w0, [x1, #0x1b]
    // 0xd196d8: r0 = "announce"
    //     0xd196d8: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cc60] "announce"
    //     0xd196dc: ldr             x0, [x0, #0xc60]
    // 0xd196e0: StoreField: r1->field_7 = r0
    //     0xd196e0: stur            w0, [x1, #7]
    // 0xd196e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd196e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd196e8: r0 = toMap()
    //     0xd196e8: bl              #0x8cd444  ; [package:flutter/src/semantics/semantics_event.dart] SemanticsEvent::toMap
    // 0xd196ec: mov             x2, x0
    // 0xd196f0: r1 = Instance_BasicMessageChannel
    //     0xd196f0: ldr             x1, [PP, #0x3088]  ; [pp+0x3088] Obj!BasicMessageChannel<Object?>@129bfe1
    // 0xd196f4: r0 = send()
    //     0xd196f4: bl              #0x8bf9c0  ; [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::send
    // 0xd196f8: mov             x1, x0
    // 0xd196fc: stur            x1, [fp, #-0x10]
    // 0xd19700: r0 = Await()
    //     0xd19700: bl              #0x7f5c00  ; AwaitStub
    // 0xd19704: r0 = Null
    //     0xd19704: mov             x0, NULL
    // 0xd19708: r0 = ReturnAsyncNotFuture()
    //     0xd19708: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd1970c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1970c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19710: b               #0xd1969c
  }
}
