// lib: , url: package:flutter/src/semantics/semantics_event.dart

// class id: 1049063, size: 0x8
class :: {
}

// class id: 2814, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class SemanticsEvent extends Object {

  _ toMap(/* No info */) {
    // ** addr: 0x8cd444, size: 0x110
    // 0x8cd444: EnterFrame
    //     0x8cd444: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd448: mov             fp, SP
    // 0x8cd44c: AllocStack(0x28)
    //     0x8cd44c: sub             SP, SP, #0x28
    // 0x8cd450: SetupParameters(SemanticsEvent this /* r1 => r0, fp-0x10 */, {dynamic nodeId = Null /* r3, fp-0x8 */})
    //     0x8cd450: mov             x0, x1
    //     0x8cd454: stur            x1, [fp, #-0x10]
    //     0x8cd458: ldur            w1, [x4, #0x13]
    //     0x8cd45c: ldur            w2, [x4, #0x1f]
    //     0x8cd460: add             x2, x2, HEAP, lsl #32
    //     0x8cd464: ldr             x16, [PP, #0x3270]  ; [pp+0x3270] "nodeId"
    //     0x8cd468: cmp             w2, w16
    //     0x8cd46c: b.ne            #0x8cd48c
    //     0x8cd470: ldur            w2, [x4, #0x23]
    //     0x8cd474: add             x2, x2, HEAP, lsl #32
    //     0x8cd478: sub             w3, w1, w2
    //     0x8cd47c: add             x1, fp, w3, sxtw #2
    //     0x8cd480: ldr             x1, [x1, #8]
    //     0x8cd484: mov             x3, x1
    //     0x8cd488: b               #0x8cd490
    //     0x8cd48c: mov             x3, NULL
    //     0x8cd490: stur            x3, [fp, #-8]
    // 0x8cd494: CheckStackOverflow
    //     0x8cd494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd498: cmp             SP, x16
    //     0x8cd49c: b.ls            #0x8cd54c
    // 0x8cd4a0: r1 = Null
    //     0x8cd4a0: mov             x1, NULL
    // 0x8cd4a4: r2 = 8
    //     0x8cd4a4: mov             x2, #8
    // 0x8cd4a8: r0 = AllocateArray()
    //     0x8cd4a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x8cd4ac: mov             x2, x0
    // 0x8cd4b0: stur            x2, [fp, #-0x18]
    // 0x8cd4b4: r16 = "type"
    //     0x8cd4b4: ldr             x16, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0x8cd4b8: StoreField: r2->field_f = r16
    //     0x8cd4b8: stur            w16, [x2, #0xf]
    // 0x8cd4bc: ldur            x1, [fp, #-0x10]
    // 0x8cd4c0: LoadField: r0 = r1->field_7
    //     0x8cd4c0: ldur            w0, [x1, #7]
    // 0x8cd4c4: DecompressPointer r0
    //     0x8cd4c4: add             x0, x0, HEAP, lsl #32
    // 0x8cd4c8: StoreField: r2->field_13 = r0
    //     0x8cd4c8: stur            w0, [x2, #0x13]
    // 0x8cd4cc: r16 = "data"
    //     0x8cd4cc: ldr             x16, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x8cd4d0: ArrayStore: r2[0] = r16  ; List_4
    //     0x8cd4d0: stur            w16, [x2, #0x17]
    // 0x8cd4d4: r0 = LoadClassIdInstr(r1)
    //     0x8cd4d4: ldur            x0, [x1, #-1]
    //     0x8cd4d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8cd4dc: r0 = GDT[cid_x0 + -0xc1f]()
    //     0x8cd4dc: sub             lr, x0, #0xc1f
    //     0x8cd4e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8cd4e4: blr             lr
    // 0x8cd4e8: ldur            x1, [fp, #-0x18]
    // 0x8cd4ec: ArrayStore: r1[3] = r0  ; List_4
    //     0x8cd4ec: add             x25, x1, #0x1b
    //     0x8cd4f0: str             w0, [x25]
    //     0x8cd4f4: tbz             w0, #0, #0x8cd510
    //     0x8cd4f8: ldurb           w16, [x1, #-1]
    //     0x8cd4fc: ldurb           w17, [x0, #-1]
    //     0x8cd500: and             x16, x17, x16, lsr #2
    //     0x8cd504: tst             x16, HEAP, lsr #32
    //     0x8cd508: b.eq            #0x8cd510
    //     0x8cd50c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8cd510: r16 = <String, dynamic>
    //     0x8cd510: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8cd514: ldur            lr, [fp, #-0x18]
    // 0x8cd518: stp             lr, x16, [SP]
    // 0x8cd51c: r0 = Map._fromLiteral()
    //     0x8cd51c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8cd520: ldur            x3, [fp, #-8]
    // 0x8cd524: stur            x0, [fp, #-0x10]
    // 0x8cd528: cmp             w3, NULL
    // 0x8cd52c: b.eq            #0x8cd53c
    // 0x8cd530: mov             x1, x0
    // 0x8cd534: r2 = "nodeId"
    //     0x8cd534: ldr             x2, [PP, #0x3270]  ; [pp+0x3270] "nodeId"
    // 0x8cd538: r0 = []=()
    //     0x8cd538: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8cd53c: ldur            x0, [fp, #-0x10]
    // 0x8cd540: LeaveFrame
    //     0x8cd540: mov             SP, fp
    //     0x8cd544: ldp             fp, lr, [SP], #0x10
    // 0x8cd548: ret
    //     0x8cd548: ret             
    // 0x8cd54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd54c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd550: b               #0x8cd4a0
  }
}

// class id: 2815, size: 0xc, field offset: 0xc
//   const constructor, 
class FocusSemanticEvent extends SemanticsEvent {

  _OneByteString field_8;

  _ getDataMap(/* No info */) {
    // ** addr: 0x12d8680, size: 0xc
    // 0x12d8680: r0 = _ConstMap len:0
    //     0x12d8680: add             x0, PP, #0x26, lsl #12  ; [pp+0x26d00] Map<String, dynamic>(0)
    //     0x12d8684: ldr             x0, [x0, #0xd00]
    // 0x12d8688: ret
    //     0x12d8688: ret             
  }
}

// class id: 2816, size: 0xc, field offset: 0xc
//   const constructor, 
class TapSemanticEvent extends SemanticsEvent {

  _OneByteString field_8;
}

// class id: 2817, size: 0xc, field offset: 0xc
//   const constructor, 
class LongPressSemanticsEvent extends SemanticsEvent {

  _OneByteString field_8;
}

// class id: 2818, size: 0x10, field offset: 0xc
//   const constructor, 
class TooltipSemanticsEvent extends SemanticsEvent {

  _ getDataMap(/* No info */) {
    // ** addr: 0x12d861c, size: 0x64
    // 0x12d861c: EnterFrame
    //     0x12d861c: stp             fp, lr, [SP, #-0x10]!
    //     0x12d8620: mov             fp, SP
    // 0x12d8624: AllocStack(0x18)
    //     0x12d8624: sub             SP, SP, #0x18
    // 0x12d8628: SetupParameters(TooltipSemanticsEvent this /* r1 => r0, fp-0x8 */)
    //     0x12d8628: mov             x0, x1
    //     0x12d862c: stur            x1, [fp, #-8]
    // 0x12d8630: CheckStackOverflow
    //     0x12d8630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12d8634: cmp             SP, x16
    //     0x12d8638: b.ls            #0x12d8678
    // 0x12d863c: r1 = Null
    //     0x12d863c: mov             x1, NULL
    // 0x12d8640: r2 = 4
    //     0x12d8640: mov             x2, #4
    // 0x12d8644: r0 = AllocateArray()
    //     0x12d8644: bl              #0x13df928  ; AllocateArrayStub
    // 0x12d8648: r16 = "message"
    //     0x12d8648: ldr             x16, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x12d864c: StoreField: r0->field_f = r16
    //     0x12d864c: stur            w16, [x0, #0xf]
    // 0x12d8650: ldur            x1, [fp, #-8]
    // 0x12d8654: LoadField: r2 = r1->field_b
    //     0x12d8654: ldur            w2, [x1, #0xb]
    // 0x12d8658: DecompressPointer r2
    //     0x12d8658: add             x2, x2, HEAP, lsl #32
    // 0x12d865c: StoreField: r0->field_13 = r2
    //     0x12d865c: stur            w2, [x0, #0x13]
    // 0x12d8660: r16 = <String, dynamic>
    //     0x12d8660: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x12d8664: stp             x0, x16, [SP]
    // 0x12d8668: r0 = Map._fromLiteral()
    //     0x12d8668: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x12d866c: LeaveFrame
    //     0x12d866c: mov             SP, fp
    //     0x12d8670: ldp             fp, lr, [SP], #0x10
    // 0x12d8674: ret
    //     0x12d8674: ret             
    // 0x12d8678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12d8678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12d867c: b               #0x12d863c
  }
}

// class id: 2819, size: 0x20, field offset: 0xc
//   const constructor, 
class AnnounceSemanticsEvent extends SemanticsEvent {

  _ getDataMap(/* No info */) {
    // ** addr: 0x12d84f8, size: 0x124
    // 0x12d84f8: EnterFrame
    //     0x12d84f8: stp             fp, lr, [SP, #-0x10]!
    //     0x12d84fc: mov             fp, SP
    // 0x12d8500: AllocStack(0x20)
    //     0x12d8500: sub             SP, SP, #0x20
    // 0x12d8504: SetupParameters(AnnounceSemanticsEvent this /* r1 => r1, fp-0x8 */)
    //     0x12d8504: stur            x1, [fp, #-8]
    // 0x12d8508: CheckStackOverflow
    //     0x12d8508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12d850c: cmp             SP, x16
    //     0x12d8510: b.ls            #0x12d8614
    // 0x12d8514: r16 = <String, dynamic>
    //     0x12d8514: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x12d8518: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x12d851c: stp             lr, x16, [SP]
    // 0x12d8520: r0 = Map._fromLiteral()
    //     0x12d8520: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x12d8524: mov             x5, x0
    // 0x12d8528: ldur            x4, [fp, #-8]
    // 0x12d852c: stur            x5, [fp, #-0x10]
    // 0x12d8530: LoadField: r2 = r4->field_b
    //     0x12d8530: ldur            x2, [x4, #0xb]
    // 0x12d8534: r0 = BoxInt64Instr(r2)
    //     0x12d8534: sbfiz           x0, x2, #1, #0x1f
    //     0x12d8538: cmp             x2, x0, asr #1
    //     0x12d853c: b.eq            #0x12d8548
    //     0x12d8540: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12d8544: stur            x2, [x0, #7]
    // 0x12d8548: mov             x1, x5
    // 0x12d854c: mov             x3, x0
    // 0x12d8550: r2 = "viewId"
    //     0x12d8550: ldr             x2, [PP, #0x6148]  ; [pp+0x6148] "viewId"
    // 0x12d8554: r0 = []=()
    //     0x12d8554: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x12d8558: ldur            x4, [fp, #-8]
    // 0x12d855c: LoadField: r3 = r4->field_13
    //     0x12d855c: ldur            w3, [x4, #0x13]
    // 0x12d8560: DecompressPointer r3
    //     0x12d8560: add             x3, x3, HEAP, lsl #32
    // 0x12d8564: ldur            x5, [fp, #-0x10]
    // 0x12d8568: r0 = LoadClassIdInstr(r5)
    //     0x12d8568: ldur            x0, [x5, #-1]
    //     0x12d856c: ubfx            x0, x0, #0xc, #0x14
    // 0x12d8570: mov             x1, x5
    // 0x12d8574: r2 = "message"
    //     0x12d8574: ldr             x2, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x12d8578: r0 = GDT[cid_x0 + -0xd50]()
    //     0x12d8578: sub             lr, x0, #0xd50
    //     0x12d857c: ldr             lr, [x21, lr, lsl #3]
    //     0x12d8580: blr             lr
    // 0x12d8584: ldur            x4, [fp, #-8]
    // 0x12d8588: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12d8588: ldur            w0, [x4, #0x17]
    // 0x12d858c: DecompressPointer r0
    //     0x12d858c: add             x0, x0, HEAP, lsl #32
    // 0x12d8590: LoadField: r2 = r0->field_7
    //     0x12d8590: ldur            x2, [x0, #7]
    // 0x12d8594: r0 = BoxInt64Instr(r2)
    //     0x12d8594: sbfiz           x0, x2, #1, #0x1f
    //     0x12d8598: cmp             x2, x0, asr #1
    //     0x12d859c: b.eq            #0x12d85a8
    //     0x12d85a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12d85a4: stur            x2, [x0, #7]
    // 0x12d85a8: ldur            x1, [fp, #-0x10]
    // 0x12d85ac: mov             x3, x0
    // 0x12d85b0: r2 = "textDirection"
    //     0x12d85b0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x12d85b4: ldr             x2, [x2, #0x210]
    // 0x12d85b8: r0 = []=()
    //     0x12d85b8: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x12d85bc: ldur            x0, [fp, #-8]
    // 0x12d85c0: LoadField: r1 = r0->field_1b
    //     0x12d85c0: ldur            w1, [x0, #0x1b]
    // 0x12d85c4: DecompressPointer r1
    //     0x12d85c4: add             x1, x1, HEAP, lsl #32
    // 0x12d85c8: r16 = Instance_Assertiveness
    //     0x12d85c8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cc58] Obj!Assertiveness@12c3e81
    //     0x12d85cc: ldr             x16, [x16, #0xc58]
    // 0x12d85d0: cmp             w1, w16
    // 0x12d85d4: b.eq            #0x12d8604
    // 0x12d85d8: LoadField: r2 = r1->field_7
    //     0x12d85d8: ldur            x2, [x1, #7]
    // 0x12d85dc: r0 = BoxInt64Instr(r2)
    //     0x12d85dc: sbfiz           x0, x2, #1, #0x1f
    //     0x12d85e0: cmp             x2, x0, asr #1
    //     0x12d85e4: b.eq            #0x12d85f0
    //     0x12d85e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12d85ec: stur            x2, [x0, #7]
    // 0x12d85f0: ldur            x1, [fp, #-0x10]
    // 0x12d85f4: mov             x3, x0
    // 0x12d85f8: r2 = "assertiveness"
    //     0x12d85f8: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cc50] "assertiveness"
    //     0x12d85fc: ldr             x2, [x2, #0xc50]
    // 0x12d8600: r0 = []=()
    //     0x12d8600: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x12d8604: ldur            x0, [fp, #-0x10]
    // 0x12d8608: LeaveFrame
    //     0x12d8608: mov             SP, fp
    //     0x12d860c: ldp             fp, lr, [SP], #0x10
    // 0x12d8610: ret
    //     0x12d8610: ret             
    // 0x12d8614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12d8614: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12d8618: b               #0x12d8514
  }
}

// class id: 8210, size: 0x14, field offset: 0x14
enum Assertiveness extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab548, size: 0x64
    // 0x11ab548: EnterFrame
    //     0x11ab548: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab54c: mov             fp, SP
    // 0x11ab550: AllocStack(0x10)
    //     0x11ab550: sub             SP, SP, #0x10
    // 0x11ab554: SetupParameters(Assertiveness this /* r1 => r0, fp-0x8 */)
    //     0x11ab554: mov             x0, x1
    //     0x11ab558: stur            x1, [fp, #-8]
    // 0x11ab55c: CheckStackOverflow
    //     0x11ab55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab560: cmp             SP, x16
    //     0x11ab564: b.ls            #0x11ab5a4
    // 0x11ab568: r1 = Null
    //     0x11ab568: mov             x1, NULL
    // 0x11ab56c: r2 = 4
    //     0x11ab56c: mov             x2, #4
    // 0x11ab570: r0 = AllocateArray()
    //     0x11ab570: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab574: r16 = "Assertiveness."
    //     0x11ab574: add             x16, PP, #0x85, lsl #12  ; [pp+0x85170] "Assertiveness."
    //     0x11ab578: ldr             x16, [x16, #0x170]
    // 0x11ab57c: StoreField: r0->field_f = r16
    //     0x11ab57c: stur            w16, [x0, #0xf]
    // 0x11ab580: ldur            x1, [fp, #-8]
    // 0x11ab584: LoadField: r2 = r1->field_f
    //     0x11ab584: ldur            w2, [x1, #0xf]
    // 0x11ab588: DecompressPointer r2
    //     0x11ab588: add             x2, x2, HEAP, lsl #32
    // 0x11ab58c: StoreField: r0->field_13 = r2
    //     0x11ab58c: stur            w2, [x0, #0x13]
    // 0x11ab590: str             x0, [SP]
    // 0x11ab594: r0 = _interpolate()
    //     0x11ab594: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab598: LeaveFrame
    //     0x11ab598: mov             SP, fp
    //     0x11ab59c: ldp             fp, lr, [SP], #0x10
    // 0x11ab5a0: ret
    //     0x11ab5a0: ret             
    // 0x11ab5a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab5a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab5a8: b               #0x11ab568
  }
}
