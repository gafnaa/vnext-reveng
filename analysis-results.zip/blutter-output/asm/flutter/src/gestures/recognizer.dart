// lib: , url: package:flutter/src/gestures/recognizer.dart

// class id: 1048831, size: 0x8
class :: {
}

// class id: 3156, size: 0x10, field offset: 0x8
//   const constructor, 
class OffsetPair extends Object {

  Offset field_8;
  Offset field_c;

  OffsetPair +(OffsetPair, OffsetPair) {
    // ** addr: 0xb954e4, size: 0x84
    // 0xb954e4: EnterFrame
    //     0xb954e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb954e8: mov             fp, SP
    // 0xb954ec: CheckStackOverflow
    //     0xb954ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb954f0: cmp             SP, x16
    //     0xb954f4: b.ls            #0xb95548
    // 0xb954f8: ldr             x0, [fp, #0x10]
    // 0xb954fc: r2 = Null
    //     0xb954fc: mov             x2, NULL
    // 0xb95500: r1 = Null
    //     0xb95500: mov             x1, NULL
    // 0xb95504: r4 = 60
    //     0xb95504: mov             x4, #0x3c
    // 0xb95508: branchIfSmi(r0, 0xb95514)
    //     0xb95508: tbz             w0, #0, #0xb95514
    // 0xb9550c: r4 = LoadClassIdInstr(r0)
    //     0xb9550c: ldur            x4, [x0, #-1]
    //     0xb95510: ubfx            x4, x4, #0xc, #0x14
    // 0xb95514: cmp             x4, #0xc54
    // 0xb95518: b.eq            #0xb95530
    // 0xb9551c: r8 = OffsetPair
    //     0xb9551c: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d48] Type: OffsetPair
    //     0xb95520: ldr             x8, [x8, #0xd48]
    // 0xb95524: r3 = Null
    //     0xb95524: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e700] Null
    //     0xb95528: ldr             x3, [x3, #0x700]
    // 0xb9552c: r0 = DefaultTypeTest()
    //     0xb9552c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb95530: ldr             x1, [fp, #0x18]
    // 0xb95534: ldr             x2, [fp, #0x10]
    // 0xb95538: r0 = +()
    //     0xb95538: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb9553c: LeaveFrame
    //     0xb9553c: mov             SP, fp
    //     0xb95540: ldp             fp, lr, [SP], #0x10
    // 0xb95544: ret
    //     0xb95544: ret             
    // 0xb95548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb95548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9554c: b               #0xb954f8
  }
  OffsetPair +(OffsetPair, OffsetPair) {
    // ** addr: 0xb95550, size: 0x8c
    // 0xb95550: EnterFrame
    //     0xb95550: stp             fp, lr, [SP, #-0x10]!
    //     0xb95554: mov             fp, SP
    // 0xb95558: AllocStack(0x18)
    //     0xb95558: sub             SP, SP, #0x18
    // 0xb9555c: SetupParameters(OffsetPair this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb9555c: mov             x3, x1
    //     0xb95560: mov             x0, x2
    //     0xb95564: stur            x1, [fp, #-8]
    //     0xb95568: stur            x2, [fp, #-0x10]
    // 0xb9556c: CheckStackOverflow
    //     0xb9556c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95570: cmp             SP, x16
    //     0xb95574: b.ls            #0xb955d4
    // 0xb95578: LoadField: r1 = r3->field_7
    //     0xb95578: ldur            w1, [x3, #7]
    // 0xb9557c: DecompressPointer r1
    //     0xb9557c: add             x1, x1, HEAP, lsl #32
    // 0xb95580: LoadField: r2 = r0->field_7
    //     0xb95580: ldur            w2, [x0, #7]
    // 0xb95584: DecompressPointer r2
    //     0xb95584: add             x2, x2, HEAP, lsl #32
    // 0xb95588: r0 = +()
    //     0xb95588: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb9558c: mov             x3, x0
    // 0xb95590: ldur            x0, [fp, #-8]
    // 0xb95594: stur            x3, [fp, #-0x18]
    // 0xb95598: LoadField: r1 = r0->field_b
    //     0xb95598: ldur            w1, [x0, #0xb]
    // 0xb9559c: DecompressPointer r1
    //     0xb9559c: add             x1, x1, HEAP, lsl #32
    // 0xb955a0: ldur            x0, [fp, #-0x10]
    // 0xb955a4: LoadField: r2 = r0->field_b
    //     0xb955a4: ldur            w2, [x0, #0xb]
    // 0xb955a8: DecompressPointer r2
    //     0xb955a8: add             x2, x2, HEAP, lsl #32
    // 0xb955ac: r0 = +()
    //     0xb955ac: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb955b0: stur            x0, [fp, #-8]
    // 0xb955b4: r0 = OffsetPair()
    //     0xb955b4: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb955b8: ldur            x1, [fp, #-0x18]
    // 0xb955bc: StoreField: r0->field_7 = r1
    //     0xb955bc: stur            w1, [x0, #7]
    // 0xb955c0: ldur            x1, [fp, #-8]
    // 0xb955c4: StoreField: r0->field_b = r1
    //     0xb955c4: stur            w1, [x0, #0xb]
    // 0xb955c8: LeaveFrame
    //     0xb955c8: mov             SP, fp
    //     0xb955cc: ldp             fp, lr, [SP], #0x10
    // 0xb955d0: ret
    //     0xb955d0: ret             
    // 0xb955d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb955d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb955d8: b               #0xb95578
  }
  OffsetPair -(OffsetPair, OffsetPair) {
    // ** addr: 0xb95600, size: 0x84
    // 0xb95600: EnterFrame
    //     0xb95600: stp             fp, lr, [SP, #-0x10]!
    //     0xb95604: mov             fp, SP
    // 0xb95608: CheckStackOverflow
    //     0xb95608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9560c: cmp             SP, x16
    //     0xb95610: b.ls            #0xb95664
    // 0xb95614: ldr             x0, [fp, #0x10]
    // 0xb95618: r2 = Null
    //     0xb95618: mov             x2, NULL
    // 0xb9561c: r1 = Null
    //     0xb9561c: mov             x1, NULL
    // 0xb95620: r4 = 60
    //     0xb95620: mov             x4, #0x3c
    // 0xb95624: branchIfSmi(r0, 0xb95630)
    //     0xb95624: tbz             w0, #0, #0xb95630
    // 0xb95628: r4 = LoadClassIdInstr(r0)
    //     0xb95628: ldur            x4, [x0, #-1]
    //     0xb9562c: ubfx            x4, x4, #0xc, #0x14
    // 0xb95630: cmp             x4, #0xc54
    // 0xb95634: b.eq            #0xb9564c
    // 0xb95638: r8 = OffsetPair
    //     0xb95638: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d48] Type: OffsetPair
    //     0xb9563c: ldr             x8, [x8, #0xd48]
    // 0xb95640: r3 = Null
    //     0xb95640: add             x3, PP, #0x81, lsl #12  ; [pp+0x81d50] Null
    //     0xb95644: ldr             x3, [x3, #0xd50]
    // 0xb95648: r0 = DefaultTypeTest()
    //     0xb95648: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9564c: ldr             x1, [fp, #0x18]
    // 0xb95650: ldr             x2, [fp, #0x10]
    // 0xb95654: r0 = -()
    //     0xb95654: bl              #0xb9566c  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::-
    // 0xb95658: LeaveFrame
    //     0xb95658: mov             SP, fp
    //     0xb9565c: ldp             fp, lr, [SP], #0x10
    // 0xb95660: ret
    //     0xb95660: ret             
    // 0xb95664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb95664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb95668: b               #0xb95614
  }
  OffsetPair -(OffsetPair, OffsetPair) {
    // ** addr: 0xb9566c, size: 0x8c
    // 0xb9566c: EnterFrame
    //     0xb9566c: stp             fp, lr, [SP, #-0x10]!
    //     0xb95670: mov             fp, SP
    // 0xb95674: AllocStack(0x18)
    //     0xb95674: sub             SP, SP, #0x18
    // 0xb95678: SetupParameters(OffsetPair this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb95678: mov             x3, x1
    //     0xb9567c: mov             x0, x2
    //     0xb95680: stur            x1, [fp, #-8]
    //     0xb95684: stur            x2, [fp, #-0x10]
    // 0xb95688: CheckStackOverflow
    //     0xb95688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9568c: cmp             SP, x16
    //     0xb95690: b.ls            #0xb956f0
    // 0xb95694: LoadField: r1 = r3->field_7
    //     0xb95694: ldur            w1, [x3, #7]
    // 0xb95698: DecompressPointer r1
    //     0xb95698: add             x1, x1, HEAP, lsl #32
    // 0xb9569c: LoadField: r2 = r0->field_7
    //     0xb9569c: ldur            w2, [x0, #7]
    // 0xb956a0: DecompressPointer r2
    //     0xb956a0: add             x2, x2, HEAP, lsl #32
    // 0xb956a4: r0 = -()
    //     0xb956a4: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb956a8: mov             x3, x0
    // 0xb956ac: ldur            x0, [fp, #-8]
    // 0xb956b0: stur            x3, [fp, #-0x18]
    // 0xb956b4: LoadField: r1 = r0->field_b
    //     0xb956b4: ldur            w1, [x0, #0xb]
    // 0xb956b8: DecompressPointer r1
    //     0xb956b8: add             x1, x1, HEAP, lsl #32
    // 0xb956bc: ldur            x0, [fp, #-0x10]
    // 0xb956c0: LoadField: r2 = r0->field_b
    //     0xb956c0: ldur            w2, [x0, #0xb]
    // 0xb956c4: DecompressPointer r2
    //     0xb956c4: add             x2, x2, HEAP, lsl #32
    // 0xb956c8: r0 = -()
    //     0xb956c8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb956cc: stur            x0, [fp, #-8]
    // 0xb956d0: r0 = OffsetPair()
    //     0xb956d0: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb956d4: ldur            x1, [fp, #-0x18]
    // 0xb956d8: StoreField: r0->field_7 = r1
    //     0xb956d8: stur            w1, [x0, #7]
    // 0xb956dc: ldur            x1, [fp, #-8]
    // 0xb956e0: StoreField: r0->field_b = r1
    //     0xb956e0: stur            w1, [x0, #0xb]
    // 0xb956e4: LeaveFrame
    //     0xb956e4: mov             SP, fp
    //     0xb956e8: ldp             fp, lr, [SP], #0x10
    // 0xb956ec: ret
    //     0xb956ec: ret             
    // 0xb956f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb956f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb956f4: b               #0xb95694
  }
  _ OffsetPair.fromEventPosition(/* No info */) {
    // ** addr: 0xb98730, size: 0xbc
    // 0xb98730: EnterFrame
    //     0xb98730: stp             fp, lr, [SP, #-0x10]!
    //     0xb98734: mov             fp, SP
    // 0xb98738: AllocStack(0x10)
    //     0xb98738: sub             SP, SP, #0x10
    // 0xb9873c: SetupParameters(OffsetPair this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb9873c: mov             x3, x1
    //     0xb98740: stur            x1, [fp, #-8]
    //     0xb98744: stur            x2, [fp, #-0x10]
    // 0xb98748: CheckStackOverflow
    //     0xb98748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9874c: cmp             SP, x16
    //     0xb98750: b.ls            #0xb987e4
    // 0xb98754: r0 = LoadClassIdInstr(r2)
    //     0xb98754: ldur            x0, [x2, #-1]
    //     0xb98758: ubfx            x0, x0, #0xc, #0x14
    // 0xb9875c: mov             x1, x2
    // 0xb98760: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb98760: mov             x17, #0x54ea
    //     0xb98764: movk            x17, #1, lsl #16
    //     0xb98768: add             lr, x0, x17
    //     0xb9876c: ldr             lr, [x21, lr, lsl #3]
    //     0xb98770: blr             lr
    // 0xb98774: ldur            x2, [fp, #-8]
    // 0xb98778: StoreField: r2->field_7 = r0
    //     0xb98778: stur            w0, [x2, #7]
    //     0xb9877c: ldurb           w16, [x2, #-1]
    //     0xb98780: ldurb           w17, [x0, #-1]
    //     0xb98784: and             x16, x17, x16, lsr #2
    //     0xb98788: tst             x16, HEAP, lsr #32
    //     0xb9878c: b.eq            #0xb98794
    //     0xb98790: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb98794: ldur            x1, [fp, #-0x10]
    // 0xb98798: r0 = LoadClassIdInstr(r1)
    //     0xb98798: ldur            x0, [x1, #-1]
    //     0xb9879c: ubfx            x0, x0, #0xc, #0x14
    // 0xb987a0: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb987a0: mov             x17, #0x3f27
    //     0xb987a4: movk            x17, #1, lsl #16
    //     0xb987a8: add             lr, x0, x17
    //     0xb987ac: ldr             lr, [x21, lr, lsl #3]
    //     0xb987b0: blr             lr
    // 0xb987b4: ldur            x1, [fp, #-8]
    // 0xb987b8: StoreField: r1->field_b = r0
    //     0xb987b8: stur            w0, [x1, #0xb]
    //     0xb987bc: ldurb           w16, [x1, #-1]
    //     0xb987c0: ldurb           w17, [x0, #-1]
    //     0xb987c4: and             x16, x17, x16, lsr #2
    //     0xb987c8: tst             x16, HEAP, lsr #32
    //     0xb987cc: b.eq            #0xb987d4
    //     0xb987d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb987d4: r0 = Null
    //     0xb987d4: mov             x0, NULL
    // 0xb987d8: LeaveFrame
    //     0xb987d8: mov             SP, fp
    //     0xb987dc: ldp             fp, lr, [SP], #0x10
    // 0xb987e0: ret
    //     0xb987e0: ret             
    // 0xb987e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb987e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb987e8: b               #0xb98754
  }
}

// class id: 4428, size: 0x18, field offset: 0x8
abstract class GestureRecognizer extends _MixinApplication231&GestureArenaMember&DiagnosticableTreeMixin {

  _ invokeCallback(/* No info */) {
    // ** addr: 0xadee70, size: 0xb8
    // 0xadee70: EnterFrame
    //     0xadee70: stp             fp, lr, [SP, #-0x10]!
    //     0xadee74: mov             fp, SP
    // 0xadee78: AllocStack(0x90)
    //     0xadee78: sub             SP, SP, #0x90
    // 0xadee7c: CheckStackOverflow
    //     0xadee7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadee80: cmp             SP, x16
    //     0xadee84: b.ls            #0xadef20
    // 0xadee88: ldr             x16, [fp, #0x10]
    // 0xadee8c: str             x16, [SP]
    // 0xadee90: ldr             x0, [fp, #0x10]
    // 0xadee94: ClosureCall
    //     0xadee94: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xadee98: ldur            x2, [x0, #0x1f]
    //     0xadee9c: blr             x2
    // 0xadeea0: b               #0xadef14
    // 0xadeea4: sub             SP, fp, #0x90
    // 0xadeea8: mov             x2, x0
    // 0xadeeac: stur            x0, [fp, #-0x78]
    // 0xadeeb0: mov             x0, x1
    // 0xadeeb4: stur            x1, [fp, #-0x80]
    // 0xadeeb8: r1 = <List<Object>>
    //     0xadeeb8: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xadeebc: r0 = ErrorDescription()
    //     0xadeebc: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xadeec0: mov             x1, x0
    // 0xadeec4: r2 = "while handling a gesture"
    //     0xadeec4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26660] "while handling a gesture"
    //     0xadeec8: ldr             x2, [x2, #0x660]
    // 0xadeecc: r3 = Instance_DiagnosticLevel
    //     0xadeecc: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xadeed0: stur            x0, [fp, #-0x88]
    // 0xadeed4: r0 = _ErrorDiagnostic()
    //     0xadeed4: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xadeed8: r0 = FlutterErrorDetails()
    //     0xadeed8: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0xadeedc: mov             x1, x0
    // 0xadeee0: ldur            x0, [fp, #-0x78]
    // 0xadeee4: StoreField: r1->field_7 = r0
    //     0xadeee4: stur            w0, [x1, #7]
    // 0xadeee8: ldur            x0, [fp, #-0x80]
    // 0xadeeec: StoreField: r1->field_b = r0
    //     0xadeeec: stur            w0, [x1, #0xb]
    // 0xadeef0: r0 = "gesture"
    //     0xadeef0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26668] "gesture"
    //     0xadeef4: ldr             x0, [x0, #0x668]
    // 0xadeef8: StoreField: r1->field_f = r0
    //     0xadeef8: stur            w0, [x1, #0xf]
    // 0xadeefc: ldur            x0, [fp, #-0x88]
    // 0xadef00: StoreField: r1->field_13 = r0
    //     0xadef00: stur            w0, [x1, #0x13]
    // 0xadef04: r0 = false
    //     0xadef04: add             x0, NULL, #0x30  ; false
    // 0xadef08: StoreField: r1->field_1b = r0
    //     0xadef08: stur            w0, [x1, #0x1b]
    // 0xadef0c: r0 = reportError()
    //     0xadef0c: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xadef10: r0 = Null
    //     0xadef10: mov             x0, NULL
    // 0xadef14: LeaveFrame
    //     0xadef14: mov             SP, fp
    //     0xadef18: ldp             fp, lr, [SP], #0x10
    // 0xadef1c: ret
    //     0xadef1c: ret             
    // 0xadef20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadef20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadef24: b               #0xadee88
  }
  _ getKindForPointer(/* No info */) {
    // ** addr: 0xb960b8, size: 0x7c
    // 0xb960b8: EnterFrame
    //     0xb960b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb960bc: mov             fp, SP
    // 0xb960c0: AllocStack(0x8)
    //     0xb960c0: sub             SP, SP, #8
    // 0xb960c4: CheckStackOverflow
    //     0xb960c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb960c8: cmp             SP, x16
    //     0xb960cc: b.ls            #0xb96128
    // 0xb960d0: LoadField: r3 = r1->field_13
    //     0xb960d0: ldur            w3, [x1, #0x13]
    // 0xb960d4: DecompressPointer r3
    //     0xb960d4: add             x3, x3, HEAP, lsl #32
    // 0xb960d8: stur            x3, [fp, #-8]
    // 0xb960dc: r0 = BoxInt64Instr(r2)
    //     0xb960dc: sbfiz           x0, x2, #1, #0x1f
    //     0xb960e0: cmp             x2, x0, asr #1
    //     0xb960e4: b.eq            #0xb960f0
    //     0xb960e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb960ec: stur            x2, [x0, #7]
    // 0xb960f0: mov             x1, x3
    // 0xb960f4: mov             x2, x0
    // 0xb960f8: r0 = _getValueOrData()
    //     0xb960f8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb960fc: ldur            x1, [fp, #-8]
    // 0xb96100: LoadField: r2 = r1->field_f
    //     0xb96100: ldur            w2, [x1, #0xf]
    // 0xb96104: DecompressPointer r2
    //     0xb96104: add             x2, x2, HEAP, lsl #32
    // 0xb96108: cmp             w2, w0
    // 0xb9610c: b.ne            #0xb96114
    // 0xb96110: r0 = Null
    //     0xb96110: mov             x0, NULL
    // 0xb96114: cmp             w0, NULL
    // 0xb96118: b.eq            #0xb96130
    // 0xb9611c: LeaveFrame
    //     0xb9611c: mov             SP, fp
    //     0xb96120: ldp             fp, lr, [SP], #0x10
    // 0xb96124: ret
    //     0xb96124: ret             
    // 0xb96128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb96128: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9612c: b               #0xb960d0
    // 0xb96130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb96130: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb75f8, size: 0x10c
    // 0xbb75f8: EnterFrame
    //     0xbb75f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbb75fc: mov             fp, SP
    // 0xbb7600: AllocStack(0x28)
    //     0xbb7600: sub             SP, SP, #0x28
    // 0xbb7604: SetupParameters(GestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xbb7604: mov             x3, x1
    //     0xbb7608: stur            x1, [fp, #-0x10]
    //     0xbb760c: stur            x2, [fp, #-0x18]
    // 0xbb7610: CheckStackOverflow
    //     0xbb7610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb7614: cmp             SP, x16
    //     0xbb7618: b.ls            #0xbb76fc
    // 0xbb761c: LoadField: r4 = r3->field_b
    //     0xbb761c: ldur            w4, [x3, #0xb]
    // 0xbb7620: DecompressPointer r4
    //     0xbb7620: add             x4, x4, HEAP, lsl #32
    // 0xbb7624: stur            x4, [fp, #-8]
    // 0xbb7628: cmp             w4, NULL
    // 0xbb762c: b.ne            #0xbb763c
    // 0xbb7630: mov             x1, x2
    // 0xbb7634: mov             x2, x3
    // 0xbb7638: b               #0xbb7694
    // 0xbb763c: r0 = LoadClassIdInstr(r2)
    //     0xbb763c: ldur            x0, [x2, #-1]
    //     0xbb7640: ubfx            x0, x0, #0xc, #0x14
    // 0xbb7644: mov             x1, x2
    // 0xbb7648: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xbb7648: mov             x17, #0x5e74
    //     0xbb764c: movk            x17, #1, lsl #16
    //     0xbb7650: add             lr, x0, x17
    //     0xbb7654: ldr             lr, [x21, lr, lsl #3]
    //     0xbb7658: blr             lr
    // 0xbb765c: ldur            x1, [fp, #-8]
    // 0xbb7660: r2 = LoadClassIdInstr(r1)
    //     0xbb7660: ldur            x2, [x1, #-1]
    //     0xbb7664: ubfx            x2, x2, #0xc, #0x14
    // 0xbb7668: mov             x16, x0
    // 0xbb766c: mov             x0, x2
    // 0xbb7670: mov             x2, x16
    // 0xbb7674: r0 = GDT[cid_x0 + 0x12929]()
    //     0xbb7674: mov             x17, #0x2929
    //     0xbb7678: movk            x17, #1, lsl #16
    //     0xbb767c: add             lr, x0, x17
    //     0xbb7680: ldr             lr, [x21, lr, lsl #3]
    //     0xbb7684: blr             lr
    // 0xbb7688: tbnz            w0, #4, #0xbb76ec
    // 0xbb768c: ldur            x2, [fp, #-0x10]
    // 0xbb7690: ldur            x1, [fp, #-0x18]
    // 0xbb7694: r0 = LoadClassIdInstr(r1)
    //     0xbb7694: ldur            x0, [x1, #-1]
    //     0xbb7698: ubfx            x0, x0, #0xc, #0x14
    // 0xbb769c: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbb769c: mov             x17, #0x6f9c
    //     0xbb76a0: movk            x17, #1, lsl #16
    //     0xbb76a4: add             lr, x0, x17
    //     0xbb76a8: ldr             lr, [x21, lr, lsl #3]
    //     0xbb76ac: blr             lr
    // 0xbb76b0: mov             x2, x0
    // 0xbb76b4: ldur            x0, [fp, #-0x10]
    // 0xbb76b8: LoadField: r3 = r0->field_f
    //     0xbb76b8: ldur            w3, [x0, #0xf]
    // 0xbb76bc: DecompressPointer r3
    //     0xbb76bc: add             x3, x3, HEAP, lsl #32
    // 0xbb76c0: r0 = BoxInt64Instr(r2)
    //     0xbb76c0: sbfiz           x0, x2, #1, #0x1f
    //     0xbb76c4: cmp             x2, x0, asr #1
    //     0xbb76c8: b.eq            #0xbb76d4
    //     0xbb76cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb76d0: stur            x2, [x0, #7]
    // 0xbb76d4: stp             x0, x3, [SP]
    // 0xbb76d8: mov             x0, x3
    // 0xbb76dc: ClosureCall
    //     0xbb76dc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbb76e0: ldur            x2, [x0, #0x1f]
    //     0xbb76e4: blr             x2
    // 0xbb76e8: b               #0xbb76f0
    // 0xbb76ec: r0 = false
    //     0xbb76ec: add             x0, NULL, #0x30  ; false
    // 0xbb76f0: LeaveFrame
    //     0xbb76f0: mov             SP, fp
    //     0xbb76f4: ldp             fp, lr, [SP], #0x10
    // 0xbb76f8: ret
    //     0xbb76f8: ret             
    // 0xbb76fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb76fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb7700: b               #0xbb761c
  }
  _ addPointerPanZoom(/* No info */) {
    // ** addr: 0xd04000, size: 0xfc
    // 0xd04000: EnterFrame
    //     0xd04000: stp             fp, lr, [SP, #-0x10]!
    //     0xd04004: mov             fp, SP
    // 0xd04008: AllocStack(0x20)
    //     0xd04008: sub             SP, SP, #0x20
    // 0xd0400c: SetupParameters(GestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xd0400c: mov             x3, x1
    //     0xd04010: stur            x1, [fp, #-0x10]
    //     0xd04014: stur            x2, [fp, #-0x18]
    // 0xd04018: CheckStackOverflow
    //     0xd04018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0401c: cmp             SP, x16
    //     0xd04020: b.ls            #0xd040f4
    // 0xd04024: LoadField: r4 = r3->field_13
    //     0xd04024: ldur            w4, [x3, #0x13]
    // 0xd04028: DecompressPointer r4
    //     0xd04028: add             x4, x4, HEAP, lsl #32
    // 0xd0402c: stur            x4, [fp, #-8]
    // 0xd04030: r0 = LoadClassIdInstr(r2)
    //     0xd04030: ldur            x0, [x2, #-1]
    //     0xd04034: ubfx            x0, x0, #0xc, #0x14
    // 0xd04038: mov             x1, x2
    // 0xd0403c: r0 = GDT[cid_x0 + -0x1]()
    //     0xd0403c: sub             lr, x0, #1
    //     0xd04040: ldr             lr, [x21, lr, lsl #3]
    //     0xd04044: blr             lr
    // 0xd04048: mov             x3, x0
    // 0xd0404c: ldur            x2, [fp, #-0x18]
    // 0xd04050: stur            x3, [fp, #-0x20]
    // 0xd04054: r0 = LoadClassIdInstr(r2)
    //     0xd04054: ldur            x0, [x2, #-1]
    //     0xd04058: ubfx            x0, x0, #0xc, #0x14
    // 0xd0405c: mov             x1, x2
    // 0xd04060: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xd04060: mov             x17, #0x5e74
    //     0xd04064: movk            x17, #1, lsl #16
    //     0xd04068: add             lr, x0, x17
    //     0xd0406c: ldr             lr, [x21, lr, lsl #3]
    //     0xd04070: blr             lr
    // 0xd04074: mov             x3, x0
    // 0xd04078: ldur            x2, [fp, #-0x20]
    // 0xd0407c: r0 = BoxInt64Instr(r2)
    //     0xd0407c: sbfiz           x0, x2, #1, #0x1f
    //     0xd04080: cmp             x2, x0, asr #1
    //     0xd04084: b.eq            #0xd04090
    //     0xd04088: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd0408c: stur            x2, [x0, #7]
    // 0xd04090: ldur            x1, [fp, #-8]
    // 0xd04094: mov             x2, x0
    // 0xd04098: r0 = []=()
    //     0xd04098: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd0409c: ldur            x3, [fp, #-0x10]
    // 0xd040a0: r0 = LoadClassIdInstr(r3)
    //     0xd040a0: ldur            x0, [x3, #-1]
    //     0xd040a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd040a8: mov             x1, x3
    // 0xd040ac: ldur            x2, [fp, #-0x18]
    // 0xd040b0: r0 = GDT[cid_x0 + 0xc7de]()
    //     0xd040b0: mov             x17, #0xc7de
    //     0xd040b4: add             lr, x0, x17
    //     0xd040b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd040bc: blr             lr
    // 0xd040c0: tbnz            w0, #4, #0xd040e4
    // 0xd040c4: ldur            x1, [fp, #-0x10]
    // 0xd040c8: r0 = LoadClassIdInstr(r1)
    //     0xd040c8: ldur            x0, [x1, #-1]
    //     0xd040cc: ubfx            x0, x0, #0xc, #0x14
    // 0xd040d0: ldur            x2, [fp, #-0x18]
    // 0xd040d4: r0 = GDT[cid_x0 + 0xe274]()
    //     0xd040d4: mov             x17, #0xe274
    //     0xd040d8: add             lr, x0, x17
    //     0xd040dc: ldr             lr, [x21, lr, lsl #3]
    //     0xd040e0: blr             lr
    // 0xd040e4: r0 = Null
    //     0xd040e4: mov             x0, NULL
    // 0xd040e8: LeaveFrame
    //     0xd040e8: mov             SP, fp
    //     0xd040ec: ldp             fp, lr, [SP], #0x10
    // 0xd040f0: ret
    //     0xd040f0: ret             
    // 0xd040f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd040f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd040f8: b               #0xd04024
  }
  _ addPointer(/* No info */) {
    // ** addr: 0xd04e70, size: 0x12c
    // 0xd04e70: EnterFrame
    //     0xd04e70: stp             fp, lr, [SP, #-0x10]!
    //     0xd04e74: mov             fp, SP
    // 0xd04e78: AllocStack(0x20)
    //     0xd04e78: sub             SP, SP, #0x20
    // 0xd04e7c: SetupParameters(GestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xd04e7c: mov             x3, x1
    //     0xd04e80: stur            x1, [fp, #-0x10]
    //     0xd04e84: stur            x2, [fp, #-0x18]
    // 0xd04e88: CheckStackOverflow
    //     0xd04e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04e8c: cmp             SP, x16
    //     0xd04e90: b.ls            #0xd04f94
    // 0xd04e94: LoadField: r4 = r3->field_13
    //     0xd04e94: ldur            w4, [x3, #0x13]
    // 0xd04e98: DecompressPointer r4
    //     0xd04e98: add             x4, x4, HEAP, lsl #32
    // 0xd04e9c: stur            x4, [fp, #-8]
    // 0xd04ea0: r0 = LoadClassIdInstr(r2)
    //     0xd04ea0: ldur            x0, [x2, #-1]
    //     0xd04ea4: ubfx            x0, x0, #0xc, #0x14
    // 0xd04ea8: mov             x1, x2
    // 0xd04eac: r0 = GDT[cid_x0 + -0x1]()
    //     0xd04eac: sub             lr, x0, #1
    //     0xd04eb0: ldr             lr, [x21, lr, lsl #3]
    //     0xd04eb4: blr             lr
    // 0xd04eb8: mov             x3, x0
    // 0xd04ebc: ldur            x2, [fp, #-0x18]
    // 0xd04ec0: stur            x3, [fp, #-0x20]
    // 0xd04ec4: r0 = LoadClassIdInstr(r2)
    //     0xd04ec4: ldur            x0, [x2, #-1]
    //     0xd04ec8: ubfx            x0, x0, #0xc, #0x14
    // 0xd04ecc: mov             x1, x2
    // 0xd04ed0: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xd04ed0: mov             x17, #0x5e74
    //     0xd04ed4: movk            x17, #1, lsl #16
    //     0xd04ed8: add             lr, x0, x17
    //     0xd04edc: ldr             lr, [x21, lr, lsl #3]
    //     0xd04ee0: blr             lr
    // 0xd04ee4: mov             x3, x0
    // 0xd04ee8: ldur            x2, [fp, #-0x20]
    // 0xd04eec: r0 = BoxInt64Instr(r2)
    //     0xd04eec: sbfiz           x0, x2, #1, #0x1f
    //     0xd04ef0: cmp             x2, x0, asr #1
    //     0xd04ef4: b.eq            #0xd04f00
    //     0xd04ef8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd04efc: stur            x2, [x0, #7]
    // 0xd04f00: ldur            x1, [fp, #-8]
    // 0xd04f04: mov             x2, x0
    // 0xd04f08: r0 = []=()
    //     0xd04f08: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd04f0c: ldur            x3, [fp, #-0x10]
    // 0xd04f10: r0 = LoadClassIdInstr(r3)
    //     0xd04f10: ldur            x0, [x3, #-1]
    //     0xd04f14: ubfx            x0, x0, #0xc, #0x14
    // 0xd04f18: mov             x1, x3
    // 0xd04f1c: ldur            x2, [fp, #-0x18]
    // 0xd04f20: r0 = GDT[cid_x0 + 0x115cd]()
    //     0xd04f20: mov             x17, #0x15cd
    //     0xd04f24: movk            x17, #1, lsl #16
    //     0xd04f28: add             lr, x0, x17
    //     0xd04f2c: ldr             lr, [x21, lr, lsl #3]
    //     0xd04f30: blr             lr
    // 0xd04f34: tbnz            w0, #4, #0xd04f60
    // 0xd04f38: ldur            x1, [fp, #-0x10]
    // 0xd04f3c: r0 = LoadClassIdInstr(r1)
    //     0xd04f3c: ldur            x0, [x1, #-1]
    //     0xd04f40: ubfx            x0, x0, #0xc, #0x14
    // 0xd04f44: ldur            x2, [fp, #-0x18]
    // 0xd04f48: r0 = GDT[cid_x0 + 0x11ac2]()
    //     0xd04f48: mov             x17, #0x1ac2
    //     0xd04f4c: movk            x17, #1, lsl #16
    //     0xd04f50: add             lr, x0, x17
    //     0xd04f54: ldr             lr, [x21, lr, lsl #3]
    //     0xd04f58: blr             lr
    // 0xd04f5c: b               #0xd04f84
    // 0xd04f60: ldur            x1, [fp, #-0x10]
    // 0xd04f64: r0 = LoadClassIdInstr(r1)
    //     0xd04f64: ldur            x0, [x1, #-1]
    //     0xd04f68: ubfx            x0, x0, #0xc, #0x14
    // 0xd04f6c: ldur            x2, [fp, #-0x18]
    // 0xd04f70: r0 = GDT[cid_x0 + 0x118b6]()
    //     0xd04f70: mov             x17, #0x18b6
    //     0xd04f74: movk            x17, #1, lsl #16
    //     0xd04f78: add             lr, x0, x17
    //     0xd04f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xd04f80: blr             lr
    // 0xd04f84: r0 = Null
    //     0xd04f84: mov             x0, NULL
    // 0xd04f88: LeaveFrame
    //     0xd04f88: mov             SP, fp
    //     0xd04f8c: ldp             fp, lr, [SP], #0x10
    // 0xd04f90: ret
    //     0xd04f90: ret             
    // 0xd04f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04f94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd04f98: b               #0xd04e94
  }
  _ isPointerPanZoomAllowed(/* No info */) {
    // ** addr: 0x10ef8ec, size: 0x98
    // 0x10ef8ec: EnterFrame
    //     0x10ef8ec: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef8f0: mov             fp, SP
    // 0x10ef8f4: AllocStack(0x8)
    //     0x10ef8f4: sub             SP, SP, #8
    // 0x10ef8f8: SetupParameters(GestureRecognizer this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x10ef8f8: mov             x0, x1
    //     0x10ef8fc: mov             x1, x2
    // 0x10ef900: CheckStackOverflow
    //     0x10ef900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef904: cmp             SP, x16
    //     0x10ef908: b.ls            #0x10ef97c
    // 0x10ef90c: LoadField: r2 = r0->field_b
    //     0x10ef90c: ldur            w2, [x0, #0xb]
    // 0x10ef910: DecompressPointer r2
    //     0x10ef910: add             x2, x2, HEAP, lsl #32
    // 0x10ef914: stur            x2, [fp, #-8]
    // 0x10ef918: cmp             w2, NULL
    // 0x10ef91c: b.ne            #0x10ef928
    // 0x10ef920: r0 = true
    //     0x10ef920: add             x0, NULL, #0x20  ; true
    // 0x10ef924: b               #0x10ef970
    // 0x10ef928: r0 = LoadClassIdInstr(r1)
    //     0x10ef928: ldur            x0, [x1, #-1]
    //     0x10ef92c: ubfx            x0, x0, #0xc, #0x14
    // 0x10ef930: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x10ef930: mov             x17, #0x5e74
    //     0x10ef934: movk            x17, #1, lsl #16
    //     0x10ef938: add             lr, x0, x17
    //     0x10ef93c: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef940: blr             lr
    // 0x10ef944: ldur            x1, [fp, #-8]
    // 0x10ef948: r2 = LoadClassIdInstr(r1)
    //     0x10ef948: ldur            x2, [x1, #-1]
    //     0x10ef94c: ubfx            x2, x2, #0xc, #0x14
    // 0x10ef950: mov             x16, x0
    // 0x10ef954: mov             x0, x2
    // 0x10ef958: mov             x2, x16
    // 0x10ef95c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x10ef95c: mov             x17, #0x2929
    //     0x10ef960: movk            x17, #1, lsl #16
    //     0x10ef964: add             lr, x0, x17
    //     0x10ef968: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef96c: blr             lr
    // 0x10ef970: LeaveFrame
    //     0x10ef970: mov             SP, fp
    //     0x10ef974: ldp             fp, lr, [SP], #0x10
    // 0x10ef978: ret
    //     0x10ef978: ret             
    // 0x10ef97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef97c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef980: b               #0x10ef90c
  }
}

// class id: 4431, size: 0x24, field offset: 0x18
abstract class OneSequenceGestureRecognizer extends GestureRecognizer {

  void resolve(OneSequenceGestureRecognizer, GestureDisposition) {
    // ** addr: 0xadf694, size: 0x88
    // 0xadf694: EnterFrame
    //     0xadf694: stp             fp, lr, [SP, #-0x10]!
    //     0xadf698: mov             fp, SP
    // 0xadf69c: CheckStackOverflow
    //     0xadf69c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf6a0: cmp             SP, x16
    //     0xadf6a4: b.ls            #0xadf6fc
    // 0xadf6a8: ldr             x0, [fp, #0x10]
    // 0xadf6ac: r2 = Null
    //     0xadf6ac: mov             x2, NULL
    // 0xadf6b0: r1 = Null
    //     0xadf6b0: mov             x1, NULL
    // 0xadf6b4: r4 = 60
    //     0xadf6b4: mov             x4, #0x3c
    // 0xadf6b8: branchIfSmi(r0, 0xadf6c4)
    //     0xadf6b8: tbz             w0, #0, #0xadf6c4
    // 0xadf6bc: r4 = LoadClassIdInstr(r0)
    //     0xadf6bc: ldur            x4, [x0, #-1]
    //     0xadf6c0: ubfx            x4, x4, #0xc, #0x14
    // 0xadf6c4: r17 = 8312
    //     0xadf6c4: mov             x17, #0x2078
    // 0xadf6c8: cmp             x4, x17
    // 0xadf6cc: b.eq            #0xadf6e4
    // 0xadf6d0: r8 = GestureDisposition
    //     0xadf6d0: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d30] Type: GestureDisposition
    //     0xadf6d4: ldr             x8, [x8, #0xd30]
    // 0xadf6d8: r3 = Null
    //     0xadf6d8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81d38] Null
    //     0xadf6dc: ldr             x3, [x3, #0xd38]
    // 0xadf6e0: r0 = DefaultTypeTest()
    //     0xadf6e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xadf6e4: ldr             x1, [fp, #0x18]
    // 0xadf6e8: ldr             x2, [fp, #0x10]
    // 0xadf6ec: r0 = resolve()
    //     0xadf6ec: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xadf6f0: LeaveFrame
    //     0xadf6f0: mov             SP, fp
    //     0xadf6f4: ldp             fp, lr, [SP], #0x10
    // 0xadf6f8: ret
    //     0xadf6f8: ret             
    // 0xadf6fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf6fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf700: b               #0xadf6a8
  }
  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0xb8be24, size: 0x10c
    // 0xb8be24: EnterFrame
    //     0xb8be24: stp             fp, lr, [SP, #-0x10]!
    //     0xb8be28: mov             fp, SP
    // 0xb8be2c: AllocStack(0x30)
    //     0xb8be2c: sub             SP, SP, #0x30
    // 0xb8be30: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xb8be30: mov             x3, x1
    //     0xb8be34: mov             x0, x2
    //     0xb8be38: stur            x1, [fp, #-0x10]
    //     0xb8be3c: stur            x2, [fp, #-0x18]
    // 0xb8be40: CheckStackOverflow
    //     0xb8be40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8be44: cmp             SP, x16
    //     0xb8be48: b.ls            #0xb8bf24
    // 0xb8be4c: LoadField: r4 = r3->field_1b
    //     0xb8be4c: ldur            w4, [x3, #0x1b]
    // 0xb8be50: DecompressPointer r4
    //     0xb8be50: add             x4, x4, HEAP, lsl #32
    // 0xb8be54: mov             x1, x4
    // 0xb8be58: mov             x2, x0
    // 0xb8be5c: stur            x4, [fp, #-8]
    // 0xb8be60: r0 = contains()
    //     0xb8be60: bl              #0xb06504  ; [dart:collection] _HashSet::contains
    // 0xb8be64: tbnz            w0, #4, #0xb8bf14
    // 0xb8be68: ldur            x1, [fp, #-0x10]
    // 0xb8be6c: ldur            x2, [fp, #-0x18]
    // 0xb8be70: ldur            x3, [fp, #-8]
    // 0xb8be74: r0 = LoadStaticField(0x7d0)
    //     0xb8be74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb8be78: ldr             x0, [x0, #0xfa0]
    // 0xb8be7c: cmp             w0, NULL
    // 0xb8be80: b.eq            #0xb8bf2c
    // 0xb8be84: LoadField: r4 = r0->field_13
    //     0xb8be84: ldur            w4, [x0, #0x13]
    // 0xb8be88: DecompressPointer r4
    //     0xb8be88: add             x4, x4, HEAP, lsl #32
    // 0xb8be8c: stur            x4, [fp, #-0x20]
    // 0xb8be90: r0 = LoadClassIdInstr(r1)
    //     0xb8be90: ldur            x0, [x1, #-1]
    //     0xb8be94: ubfx            x0, x0, #0xc, #0x14
    // 0xb8be98: str             x1, [SP]
    // 0xb8be9c: r0 = GDT[cid_x0 + 0x11c33]()
    //     0xb8be9c: mov             x17, #0x1c33
    //     0xb8bea0: movk            x17, #1, lsl #16
    //     0xb8bea4: add             lr, x0, x17
    //     0xb8bea8: ldr             lr, [x21, lr, lsl #3]
    //     0xb8beac: blr             lr
    // 0xb8beb0: mov             x1, x0
    // 0xb8beb4: ldur            x0, [fp, #-0x18]
    // 0xb8beb8: r4 = LoadInt32Instr(r0)
    //     0xb8beb8: sbfx            x4, x0, #1, #0x1f
    //     0xb8bebc: tbz             w0, #0, #0xb8bec4
    //     0xb8bec0: ldur            x4, [x0, #7]
    // 0xb8bec4: mov             x3, x1
    // 0xb8bec8: ldur            x1, [fp, #-0x20]
    // 0xb8becc: mov             x2, x4
    // 0xb8bed0: stur            x4, [fp, #-0x28]
    // 0xb8bed4: r0 = removeRoute()
    //     0xb8bed4: bl              #0xb8bf6c  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeRoute
    // 0xb8bed8: ldur            x1, [fp, #-8]
    // 0xb8bedc: ldur            x2, [fp, #-0x18]
    // 0xb8bee0: r0 = remove()
    //     0xb8bee0: bl              #0x1148f1c  ; [dart:collection] _HashSet::remove
    // 0xb8bee4: ldur            x0, [fp, #-8]
    // 0xb8bee8: LoadField: r1 = r0->field_f
    //     0xb8bee8: ldur            x1, [x0, #0xf]
    // 0xb8beec: cbnz            x1, #0xb8bf14
    // 0xb8bef0: ldur            x1, [fp, #-0x10]
    // 0xb8bef4: r0 = LoadClassIdInstr(r1)
    //     0xb8bef4: ldur            x0, [x1, #-1]
    //     0xb8bef8: ubfx            x0, x0, #0xc, #0x14
    // 0xb8befc: ldur            x2, [fp, #-0x28]
    // 0xb8bf00: r0 = GDT[cid_x0 + 0x11da7]()
    //     0xb8bf00: mov             x17, #0x1da7
    //     0xb8bf04: movk            x17, #1, lsl #16
    //     0xb8bf08: add             lr, x0, x17
    //     0xb8bf0c: ldr             lr, [x21, lr, lsl #3]
    //     0xb8bf10: blr             lr
    // 0xb8bf14: r0 = Null
    //     0xb8bf14: mov             x0, NULL
    // 0xb8bf18: LeaveFrame
    //     0xb8bf18: mov             SP, fp
    //     0xb8bf1c: ldp             fp, lr, [SP], #0x10
    // 0xb8bf20: ret
    //     0xb8bf20: ret             
    // 0xb8bf24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8bf24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8bf28: b               #0xb8be4c
    // 0xb8bf2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8bf2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void stopTrackingPointer(dynamic, int) {
    // ** addr: 0xb8bf30, size: 0x3c
    // 0xb8bf30: EnterFrame
    //     0xb8bf30: stp             fp, lr, [SP, #-0x10]!
    //     0xb8bf34: mov             fp, SP
    // 0xb8bf38: ldr             x0, [fp, #0x18]
    // 0xb8bf3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb8bf3c: ldur            w1, [x0, #0x17]
    // 0xb8bf40: DecompressPointer r1
    //     0xb8bf40: add             x1, x1, HEAP, lsl #32
    // 0xb8bf44: CheckStackOverflow
    //     0xb8bf44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8bf48: cmp             SP, x16
    //     0xb8bf4c: b.ls            #0xb8bf64
    // 0xb8bf50: ldr             x2, [fp, #0x10]
    // 0xb8bf54: r0 = stopTrackingPointer()
    //     0xb8bf54: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xb8bf58: LeaveFrame
    //     0xb8bf58: mov             SP, fp
    //     0xb8bf5c: ldp             fp, lr, [SP], #0x10
    // 0xb8bf60: ret
    //     0xb8bf60: ret             
    // 0xb8bf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8bf64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8bf68: b               #0xb8bf50
  }
  _ OneSequenceGestureRecognizer(/* No info */) {
    // ** addr: 0xb8d484, size: 0x1c8
    // 0xb8d484: EnterFrame
    //     0xb8d484: stp             fp, lr, [SP, #-0x10]!
    //     0xb8d488: mov             fp, SP
    // 0xb8d48c: AllocStack(0x30)
    //     0xb8d48c: sub             SP, SP, #0x30
    // 0xb8d490: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r1, fp-0x18 */, {dynamic allowedButtonsFilter = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. /* r3, fp-0x10 */, dynamic supportedDevices = Null /* r0, fp-0x8 */})
    //     0xb8d490: stur            x1, [fp, #-0x18]
    //     0xb8d494: ldur            w0, [x4, #0x13]
    //     0xb8d498: ldur            w2, [x4, #0x1f]
    //     0xb8d49c: add             x2, x2, HEAP, lsl #32
    //     0xb8d4a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15570] "allowedButtonsFilter"
    //     0xb8d4a4: ldr             x16, [x16, #0x570]
    //     0xb8d4a8: cmp             w2, w16
    //     0xb8d4ac: b.ne            #0xb8d4d0
    //     0xb8d4b0: ldur            w2, [x4, #0x23]
    //     0xb8d4b4: add             x2, x2, HEAP, lsl #32
    //     0xb8d4b8: sub             w3, w0, w2
    //     0xb8d4bc: add             x2, fp, w3, sxtw #2
    //     0xb8d4c0: ldr             x2, [x2, #8]
    //     0xb8d4c4: mov             x3, x2
    //     0xb8d4c8: mov             x2, #1
    //     0xb8d4cc: b               #0xb8d4dc
    //     0xb8d4d0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xb8d4d4: ldr             x3, [x3, #0x578]
    //     0xb8d4d8: mov             x2, #0
    //     0xb8d4dc: stur            x3, [fp, #-0x10]
    //     0xb8d4e0: lsl             x5, x2, #1
    //     0xb8d4e4: lsl             w2, w5, #1
    //     0xb8d4e8: add             w5, w2, #8
    //     0xb8d4ec: add             x16, x4, w5, sxtw #1
    //     0xb8d4f0: ldur            w6, [x16, #0xf]
    //     0xb8d4f4: add             x6, x6, HEAP, lsl #32
    //     0xb8d4f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15580] "supportedDevices"
    //     0xb8d4fc: ldr             x16, [x16, #0x580]
    //     0xb8d500: cmp             w6, w16
    //     0xb8d504: b.ne            #0xb8d528
    //     0xb8d508: add             w5, w2, #0xa
    //     0xb8d50c: add             x16, x4, w5, sxtw #1
    //     0xb8d510: ldur            w2, [x16, #0xf]
    //     0xb8d514: add             x2, x2, HEAP, lsl #32
    //     0xb8d518: sub             w4, w0, w2
    //     0xb8d51c: add             x0, fp, w4, sxtw #2
    //     0xb8d520: ldr             x0, [x0, #8]
    //     0xb8d524: b               #0xb8d52c
    //     0xb8d528: mov             x0, NULL
    //     0xb8d52c: stur            x0, [fp, #-8]
    // 0xb8d530: CheckStackOverflow
    //     0xb8d530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8d534: cmp             SP, x16
    //     0xb8d538: b.ls            #0xb8d644
    // 0xb8d53c: r16 = <int, GestureArenaEntry>
    //     0xb8d53c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15588] TypeArguments: <int, GestureArenaEntry>
    //     0xb8d540: ldr             x16, [x16, #0x588]
    // 0xb8d544: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb8d548: stp             lr, x16, [SP]
    // 0xb8d54c: r0 = Map._fromLiteral()
    //     0xb8d54c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb8d550: ldur            x2, [fp, #-0x18]
    // 0xb8d554: ArrayStore: r2[0] = r0  ; List_4
    //     0xb8d554: stur            w0, [x2, #0x17]
    //     0xb8d558: ldurb           w16, [x2, #-1]
    //     0xb8d55c: ldurb           w17, [x0, #-1]
    //     0xb8d560: and             x16, x17, x16, lsr #2
    //     0xb8d564: tst             x16, HEAP, lsr #32
    //     0xb8d568: b.eq            #0xb8d570
    //     0xb8d56c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb8d570: r1 = <int>
    //     0xb8d570: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xb8d574: r0 = _HashSet()
    //     0xb8d574: bl              #0x89f6f0  ; Allocate_HashSetStub -> _HashSet<X0> (size=0x20)
    // 0xb8d578: stur            x0, [fp, #-0x20]
    // 0xb8d57c: StoreField: r0->field_f = rZR
    //     0xb8d57c: stur            xzr, [x0, #0xf]
    // 0xb8d580: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb8d580: stur            xzr, [x0, #0x17]
    // 0xb8d584: r1 = <_HashSetEntry<int>?>
    //     0xb8d584: add             x1, PP, #0x15, lsl #12  ; [pp+0x15590] TypeArguments: <_HashSetEntry<int>?>
    //     0xb8d588: ldr             x1, [x1, #0x590]
    // 0xb8d58c: r2 = 16
    //     0xb8d58c: mov             x2, #0x10
    // 0xb8d590: r0 = AllocateArray()
    //     0xb8d590: bl              #0x13df928  ; AllocateArrayStub
    // 0xb8d594: mov             x1, x0
    // 0xb8d598: ldur            x0, [fp, #-0x20]
    // 0xb8d59c: StoreField: r0->field_b = r1
    //     0xb8d59c: stur            w1, [x0, #0xb]
    // 0xb8d5a0: ldur            x1, [fp, #-0x18]
    // 0xb8d5a4: StoreField: r1->field_1b = r0
    //     0xb8d5a4: stur            w0, [x1, #0x1b]
    //     0xb8d5a8: ldurb           w16, [x1, #-1]
    //     0xb8d5ac: ldurb           w17, [x0, #-1]
    //     0xb8d5b0: and             x16, x17, x16, lsr #2
    //     0xb8d5b4: tst             x16, HEAP, lsr #32
    //     0xb8d5b8: b.eq            #0xb8d5c0
    //     0xb8d5bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d5c0: r16 = <int, PointerDeviceKind>
    //     0xb8d5c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15598] TypeArguments: <int, PointerDeviceKind>
    //     0xb8d5c4: ldr             x16, [x16, #0x598]
    // 0xb8d5c8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb8d5cc: stp             lr, x16, [SP]
    // 0xb8d5d0: r0 = Map._fromLiteral()
    //     0xb8d5d0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb8d5d4: ldur            x1, [fp, #-0x18]
    // 0xb8d5d8: StoreField: r1->field_13 = r0
    //     0xb8d5d8: stur            w0, [x1, #0x13]
    //     0xb8d5dc: ldurb           w16, [x1, #-1]
    //     0xb8d5e0: ldurb           w17, [x0, #-1]
    //     0xb8d5e4: and             x16, x17, x16, lsr #2
    //     0xb8d5e8: tst             x16, HEAP, lsr #32
    //     0xb8d5ec: b.eq            #0xb8d5f4
    //     0xb8d5f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d5f4: ldur            x0, [fp, #-8]
    // 0xb8d5f8: StoreField: r1->field_b = r0
    //     0xb8d5f8: stur            w0, [x1, #0xb]
    //     0xb8d5fc: ldurb           w16, [x1, #-1]
    //     0xb8d600: ldurb           w17, [x0, #-1]
    //     0xb8d604: and             x16, x17, x16, lsr #2
    //     0xb8d608: tst             x16, HEAP, lsr #32
    //     0xb8d60c: b.eq            #0xb8d614
    //     0xb8d610: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d614: ldur            x0, [fp, #-0x10]
    // 0xb8d618: StoreField: r1->field_f = r0
    //     0xb8d618: stur            w0, [x1, #0xf]
    //     0xb8d61c: ldurb           w16, [x1, #-1]
    //     0xb8d620: ldurb           w17, [x0, #-1]
    //     0xb8d624: and             x16, x17, x16, lsr #2
    //     0xb8d628: tst             x16, HEAP, lsr #32
    //     0xb8d62c: b.eq            #0xb8d634
    //     0xb8d630: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d634: r0 = Null
    //     0xb8d634: mov             x0, NULL
    // 0xb8d638: LeaveFrame
    //     0xb8d638: mov             SP, fp
    //     0xb8d63c: ldp             fp, lr, [SP], #0x10
    // 0xb8d640: ret
    //     0xb8d640: ret             
    // 0xb8d644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8d644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8d648: b               #0xb8d53c
  }
  _ resolvePointer(/* No info */) {
    // ** addr: 0xb98f4c, size: 0xac
    // 0xb98f4c: EnterFrame
    //     0xb98f4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb98f50: mov             fp, SP
    // 0xb98f54: AllocStack(0x18)
    //     0xb98f54: sub             SP, SP, #0x18
    // 0xb98f58: CheckStackOverflow
    //     0xb98f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb98f5c: cmp             SP, x16
    //     0xb98f60: b.ls            #0xb98ff0
    // 0xb98f64: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xb98f64: ldur            w3, [x1, #0x17]
    // 0xb98f68: DecompressPointer r3
    //     0xb98f68: add             x3, x3, HEAP, lsl #32
    // 0xb98f6c: stur            x3, [fp, #-0x10]
    // 0xb98f70: r0 = BoxInt64Instr(r2)
    //     0xb98f70: sbfiz           x0, x2, #1, #0x1f
    //     0xb98f74: cmp             x2, x0, asr #1
    //     0xb98f78: b.eq            #0xb98f84
    //     0xb98f7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb98f80: stur            x2, [x0, #7]
    // 0xb98f84: mov             x1, x3
    // 0xb98f88: mov             x2, x0
    // 0xb98f8c: stur            x0, [fp, #-8]
    // 0xb98f90: r0 = _getValueOrData()
    //     0xb98f90: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb98f94: ldur            x1, [fp, #-0x10]
    // 0xb98f98: LoadField: r2 = r1->field_f
    //     0xb98f98: ldur            w2, [x1, #0xf]
    // 0xb98f9c: DecompressPointer r2
    //     0xb98f9c: add             x2, x2, HEAP, lsl #32
    // 0xb98fa0: cmp             w2, w0
    // 0xb98fa4: b.ne            #0xb98fac
    // 0xb98fa8: r0 = Null
    //     0xb98fa8: mov             x0, NULL
    // 0xb98fac: stur            x0, [fp, #-0x18]
    // 0xb98fb0: cmp             w0, NULL
    // 0xb98fb4: b.eq            #0xb98fe0
    // 0xb98fb8: ldur            x2, [fp, #-8]
    // 0xb98fbc: r0 = remove()
    //     0xb98fbc: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xb98fc0: ldur            x1, [fp, #-0x18]
    // 0xb98fc4: r0 = LoadClassIdInstr(r1)
    //     0xb98fc4: ldur            x0, [x1, #-1]
    //     0xb98fc8: ubfx            x0, x0, #0xc, #0x14
    // 0xb98fcc: r2 = Instance_GestureDisposition
    //     0xb98fcc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb98fd0: ldr             x2, [x2, #0x610]
    // 0xb98fd4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb98fd4: sub             lr, x0, #1, lsl #12
    //     0xb98fd8: ldr             lr, [x21, lr, lsl #3]
    //     0xb98fdc: blr             lr
    // 0xb98fe0: r0 = Null
    //     0xb98fe0: mov             x0, NULL
    // 0xb98fe4: LeaveFrame
    //     0xb98fe4: mov             SP, fp
    //     0xb98fe8: ldp             fp, lr, [SP], #0x10
    // 0xb98fec: ret
    //     0xb98fec: ret             
    // 0xb98ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb98ff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb98ff4: b               #0xb98f64
  }
  _ stopTrackingIfPointerNoLongerDown(/* No info */) {
    // ** addr: 0xb9c294, size: 0x178
    // 0xb9c294: EnterFrame
    //     0xb9c294: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c298: mov             fp, SP
    // 0xb9c29c: AllocStack(0x10)
    //     0xb9c29c: sub             SP, SP, #0x10
    // 0xb9c2a0: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb9c2a0: mov             x4, x1
    //     0xb9c2a4: mov             x3, x2
    //     0xb9c2a8: stur            x1, [fp, #-8]
    //     0xb9c2ac: stur            x2, [fp, #-0x10]
    // 0xb9c2b0: CheckStackOverflow
    //     0xb9c2b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9c2b4: cmp             SP, x16
    //     0xb9c2b8: b.ls            #0xb9c404
    // 0xb9c2bc: mov             x0, x3
    // 0xb9c2c0: r2 = Null
    //     0xb9c2c0: mov             x2, NULL
    // 0xb9c2c4: r1 = Null
    //     0xb9c2c4: mov             x1, NULL
    // 0xb9c2c8: cmp             w0, NULL
    // 0xb9c2cc: b.eq            #0xb9c2f4
    // 0xb9c2d0: branchIfSmi(r0, 0xb9c2f4)
    //     0xb9c2d0: tbz             w0, #0, #0xb9c2f4
    // 0xb9c2d4: r3 = LoadClassIdInstr(r0)
    //     0xb9c2d4: ldur            x3, [x0, #-1]
    //     0xb9c2d8: ubfx            x3, x3, #0xc, #0x14
    // 0xb9c2dc: r17 = 4155
    //     0xb9c2dc: mov             x17, #0x103b
    // 0xb9c2e0: cmp             x3, x17
    // 0xb9c2e4: b.eq            #0xb9c2fc
    // 0xb9c2e8: r17 = 5284
    //     0xb9c2e8: mov             x17, #0x14a4
    // 0xb9c2ec: cmp             x3, x17
    // 0xb9c2f0: b.eq            #0xb9c2fc
    // 0xb9c2f4: r0 = false
    //     0xb9c2f4: add             x0, NULL, #0x30  ; false
    // 0xb9c2f8: b               #0xb9c300
    // 0xb9c2fc: r0 = true
    //     0xb9c2fc: add             x0, NULL, #0x20  ; true
    // 0xb9c300: tbz             w0, #4, #0xb9c394
    // 0xb9c304: ldur            x0, [fp, #-0x10]
    // 0xb9c308: r2 = Null
    //     0xb9c308: mov             x2, NULL
    // 0xb9c30c: r1 = Null
    //     0xb9c30c: mov             x1, NULL
    // 0xb9c310: cmp             w0, NULL
    // 0xb9c314: b.eq            #0xb9c33c
    // 0xb9c318: branchIfSmi(r0, 0xb9c33c)
    //     0xb9c318: tbz             w0, #0, #0xb9c33c
    // 0xb9c31c: r3 = LoadClassIdInstr(r0)
    //     0xb9c31c: ldur            x3, [x0, #-1]
    //     0xb9c320: ubfx            x3, x3, #0xc, #0x14
    // 0xb9c324: r17 = 4139
    //     0xb9c324: mov             x17, #0x102b
    // 0xb9c328: cmp             x3, x17
    // 0xb9c32c: b.eq            #0xb9c344
    // 0xb9c330: r17 = 5276
    //     0xb9c330: mov             x17, #0x149c
    // 0xb9c334: cmp             x3, x17
    // 0xb9c338: b.eq            #0xb9c344
    // 0xb9c33c: r0 = false
    //     0xb9c33c: add             x0, NULL, #0x30  ; false
    // 0xb9c340: b               #0xb9c348
    // 0xb9c344: r0 = true
    //     0xb9c344: add             x0, NULL, #0x20  ; true
    // 0xb9c348: tbz             w0, #4, #0xb9c394
    // 0xb9c34c: ldur            x0, [fp, #-0x10]
    // 0xb9c350: r2 = Null
    //     0xb9c350: mov             x2, NULL
    // 0xb9c354: r1 = Null
    //     0xb9c354: mov             x1, NULL
    // 0xb9c358: cmp             w0, NULL
    // 0xb9c35c: b.eq            #0xb9c384
    // 0xb9c360: branchIfSmi(r0, 0xb9c384)
    //     0xb9c360: tbz             w0, #0, #0xb9c384
    // 0xb9c364: r3 = LoadClassIdInstr(r0)
    //     0xb9c364: ldur            x3, [x0, #-1]
    //     0xb9c368: ubfx            x3, x3, #0xc, #0x14
    // 0xb9c36c: r17 = 4141
    //     0xb9c36c: mov             x17, #0x102d
    // 0xb9c370: cmp             x3, x17
    // 0xb9c374: b.eq            #0xb9c38c
    // 0xb9c378: r17 = 5278
    //     0xb9c378: mov             x17, #0x149e
    // 0xb9c37c: cmp             x3, x17
    // 0xb9c380: b.eq            #0xb9c38c
    // 0xb9c384: r0 = false
    //     0xb9c384: add             x0, NULL, #0x30  ; false
    // 0xb9c388: b               #0xb9c390
    // 0xb9c38c: r0 = true
    //     0xb9c38c: add             x0, NULL, #0x20  ; true
    // 0xb9c390: tbnz            w0, #4, #0xb9c3f4
    // 0xb9c394: ldur            x2, [fp, #-8]
    // 0xb9c398: ldur            x1, [fp, #-0x10]
    // 0xb9c39c: r0 = LoadClassIdInstr(r1)
    //     0xb9c39c: ldur            x0, [x1, #-1]
    //     0xb9c3a0: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c3a4: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9c3a4: sub             lr, x0, #1
    //     0xb9c3a8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c3ac: blr             lr
    // 0xb9c3b0: mov             x2, x0
    // 0xb9c3b4: r0 = BoxInt64Instr(r2)
    //     0xb9c3b4: sbfiz           x0, x2, #1, #0x1f
    //     0xb9c3b8: cmp             x2, x0, asr #1
    //     0xb9c3bc: b.eq            #0xb9c3c8
    //     0xb9c3c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9c3c4: stur            x2, [x0, #7]
    // 0xb9c3c8: ldur            x1, [fp, #-8]
    // 0xb9c3cc: r2 = LoadClassIdInstr(r1)
    //     0xb9c3cc: ldur            x2, [x1, #-1]
    //     0xb9c3d0: ubfx            x2, x2, #0xc, #0x14
    // 0xb9c3d4: mov             x16, x0
    // 0xb9c3d8: mov             x0, x2
    // 0xb9c3dc: mov             x2, x16
    // 0xb9c3e0: r0 = GDT[cid_x0 + 0x11f1d]()
    //     0xb9c3e0: mov             x17, #0x1f1d
    //     0xb9c3e4: movk            x17, #1, lsl #16
    //     0xb9c3e8: add             lr, x0, x17
    //     0xb9c3ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c3f0: blr             lr
    // 0xb9c3f4: r0 = Null
    //     0xb9c3f4: mov             x0, NULL
    // 0xb9c3f8: LeaveFrame
    //     0xb9c3f8: mov             SP, fp
    //     0xb9c3fc: ldp             fp, lr, [SP], #0x10
    // 0xb9c400: ret
    //     0xb9c400: ret             
    // 0xb9c404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9c404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9c408: b               #0xb9c2bc
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba6ac8, size: 0xa4
    // 0xba6ac8: EnterFrame
    //     0xba6ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xba6acc: mov             fp, SP
    // 0xba6ad0: AllocStack(0x18)
    //     0xba6ad0: sub             SP, SP, #0x18
    // 0xba6ad4: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba6ad4: mov             x3, x1
    //     0xba6ad8: stur            x1, [fp, #-8]
    //     0xba6adc: stur            x2, [fp, #-0x10]
    // 0xba6ae0: CheckStackOverflow
    //     0xba6ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba6ae4: cmp             SP, x16
    //     0xba6ae8: b.ls            #0xba6b64
    // 0xba6aec: r0 = LoadClassIdInstr(r2)
    //     0xba6aec: ldur            x0, [x2, #-1]
    //     0xba6af0: ubfx            x0, x0, #0xc, #0x14
    // 0xba6af4: mov             x1, x2
    // 0xba6af8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba6af8: sub             lr, x0, #1
    //     0xba6afc: ldr             lr, [x21, lr, lsl #3]
    //     0xba6b00: blr             lr
    // 0xba6b04: mov             x2, x0
    // 0xba6b08: ldur            x1, [fp, #-0x10]
    // 0xba6b0c: stur            x2, [fp, #-0x18]
    // 0xba6b10: r0 = LoadClassIdInstr(r1)
    //     0xba6b10: ldur            x0, [x1, #-1]
    //     0xba6b14: ubfx            x0, x0, #0xc, #0x14
    // 0xba6b18: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba6b18: mov             x17, #0x5fe3
    //     0xba6b1c: movk            x17, #1, lsl #16
    //     0xba6b20: add             lr, x0, x17
    //     0xba6b24: ldr             lr, [x21, lr, lsl #3]
    //     0xba6b28: blr             lr
    // 0xba6b2c: ldur            x1, [fp, #-8]
    // 0xba6b30: r2 = LoadClassIdInstr(r1)
    //     0xba6b30: ldur            x2, [x1, #-1]
    //     0xba6b34: ubfx            x2, x2, #0xc, #0x14
    // 0xba6b38: mov             x3, x0
    // 0xba6b3c: mov             x0, x2
    // 0xba6b40: ldur            x2, [fp, #-0x18]
    // 0xba6b44: r0 = GDT[cid_x0 + 0xbd82]()
    //     0xba6b44: mov             x17, #0xbd82
    //     0xba6b48: add             lr, x0, x17
    //     0xba6b4c: ldr             lr, [x21, lr, lsl #3]
    //     0xba6b50: blr             lr
    // 0xba6b54: r0 = Null
    //     0xba6b54: mov             x0, NULL
    // 0xba6b58: LeaveFrame
    //     0xba6b58: mov             SP, fp
    //     0xba6b5c: ldp             fp, lr, [SP], #0x10
    // 0xba6b60: ret
    //     0xba6b60: ret             
    // 0xba6b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6b64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6b68: b               #0xba6aec
  }
  _ handleNonAllowedPointer(/* No info */) {
    // ** addr: 0xbae768, size: 0x4c
    // 0xbae768: EnterFrame
    //     0xbae768: stp             fp, lr, [SP, #-0x10]!
    //     0xbae76c: mov             fp, SP
    // 0xbae770: CheckStackOverflow
    //     0xbae770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbae774: cmp             SP, x16
    //     0xbae778: b.ls            #0xbae7ac
    // 0xbae77c: r0 = LoadClassIdInstr(r1)
    //     0xbae77c: ldur            x0, [x1, #-1]
    //     0xbae780: ubfx            x0, x0, #0xc, #0x14
    // 0xbae784: r2 = Instance_GestureDisposition
    //     0xbae784: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xbae788: ldr             x2, [x2, #0x610]
    // 0xbae78c: r0 = GDT[cid_x0 + 0xe1c6]()
    //     0xbae78c: mov             x17, #0xe1c6
    //     0xbae790: add             lr, x0, x17
    //     0xbae794: ldr             lr, [x21, lr, lsl #3]
    //     0xbae798: blr             lr
    // 0xbae79c: r0 = Null
    //     0xbae79c: mov             x0, NULL
    // 0xbae7a0: LeaveFrame
    //     0xbae7a0: mov             SP, fp
    //     0xbae7a4: ldp             fp, lr, [SP], #0x10
    // 0xbae7a8: ret
    //     0xbae7a8: ret             
    // 0xbae7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbae7ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbae7b0: b               #0xbae77c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb179c, size: 0x1f4
    // 0xbb179c: EnterFrame
    //     0xbb179c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb17a0: mov             fp, SP
    // 0xbb17a4: AllocStack(0x40)
    //     0xbb17a4: sub             SP, SP, #0x40
    // 0xbb17a8: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r3, fp-0x8 */)
    //     0xbb17a8: mov             x3, x1
    //     0xbb17ac: stur            x1, [fp, #-8]
    // 0xbb17b0: CheckStackOverflow
    //     0xbb17b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb17b4: cmp             SP, x16
    //     0xbb17b8: b.ls            #0xbb1978
    // 0xbb17bc: r0 = LoadClassIdInstr(r3)
    //     0xbb17bc: ldur            x0, [x3, #-1]
    //     0xbb17c0: ubfx            x0, x0, #0xc, #0x14
    // 0xbb17c4: mov             x1, x3
    // 0xbb17c8: r2 = Instance_GestureDisposition
    //     0xbb17c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xbb17cc: ldr             x2, [x2, #0x610]
    // 0xbb17d0: r0 = GDT[cid_x0 + 0xe1c6]()
    //     0xbb17d0: mov             x17, #0xe1c6
    //     0xbb17d4: add             lr, x0, x17
    //     0xbb17d8: ldr             lr, [x21, lr, lsl #3]
    //     0xbb17dc: blr             lr
    // 0xbb17e0: ldur            x0, [fp, #-8]
    // 0xbb17e4: LoadField: r2 = r0->field_1b
    //     0xbb17e4: ldur            w2, [x0, #0x1b]
    // 0xbb17e8: DecompressPointer r2
    //     0xbb17e8: add             x2, x2, HEAP, lsl #32
    // 0xbb17ec: stur            x2, [fp, #-0x10]
    // 0xbb17f0: r1 = <int>
    //     0xbb17f0: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xbb17f4: r0 = _HashSetIterator()
    //     0xbb17f4: bl              #0x90dac0  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0xbb17f8: stur            x0, [fp, #-0x18]
    // 0xbb17fc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbb17fc: stur            xzr, [x0, #0x17]
    // 0xbb1800: ldur            x2, [fp, #-0x10]
    // 0xbb1804: StoreField: r0->field_b = r2
    //     0xbb1804: stur            w2, [x0, #0xb]
    // 0xbb1808: ArrayLoad: r1 = r2[0]  ; List_8
    //     0xbb1808: ldur            x1, [x2, #0x17]
    // 0xbb180c: StoreField: r0->field_f = r1
    //     0xbb180c: stur            x1, [x0, #0xf]
    // 0xbb1810: ldur            x3, [fp, #-8]
    // 0xbb1814: CheckStackOverflow
    //     0xbb1814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1818: cmp             SP, x16
    //     0xbb181c: b.ls            #0xbb1980
    // 0xbb1820: mov             x1, x0
    // 0xbb1824: r0 = moveNext()
    //     0xbb1824: bl              #0x804abc  ; [dart:collection] _HashSetIterator::moveNext
    // 0xbb1828: tbnz            w0, #4, #0xbb1960
    // 0xbb182c: ldur            x3, [fp, #-0x18]
    // 0xbb1830: LoadField: r4 = r3->field_23
    //     0xbb1830: ldur            w4, [x3, #0x23]
    // 0xbb1834: DecompressPointer r4
    //     0xbb1834: add             x4, x4, HEAP, lsl #32
    // 0xbb1838: stur            x4, [fp, #-0x20]
    // 0xbb183c: cmp             w4, NULL
    // 0xbb1840: b.ne            #0xbb1878
    // 0xbb1844: r4 as int
    //     0xbb1844: mov             x0, x4
    //     0xbb1848: mov             x2, NULL
    //     0xbb184c: mov             x1, NULL
    //     0xbb1850: tbz             w0, #0, #0xbb1878
    //     0xbb1854: ldur            x4, [x0, #-1]
    //     0xbb1858: ubfx            x4, x4, #0xc, #0x14
    //     0xbb185c: sub             x4, x4, #0x3c
    //     0xbb1860: cmp             x4, #1
    //     0xbb1864: b.ls            #0xbb1878
    //     0xbb1868: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    //     0xbb186c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e6f0] Null
    //     0xbb1870: ldr             x3, [x3, #0x6f0]
    //     0xbb1874: bl              #0x13ee980  ; IsType_int_Stub
    // 0xbb1878: ldur            x1, [fp, #-8]
    // 0xbb187c: r0 = LoadStaticField(0x7d0)
    //     0xbb187c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xbb1880: ldr             x0, [x0, #0xfa0]
    // 0xbb1884: cmp             w0, NULL
    // 0xbb1888: b.eq            #0xbb1988
    // 0xbb188c: LoadField: r2 = r0->field_13
    //     0xbb188c: ldur            w2, [x0, #0x13]
    // 0xbb1890: DecompressPointer r2
    //     0xbb1890: add             x2, x2, HEAP, lsl #32
    // 0xbb1894: stur            x2, [fp, #-0x28]
    // 0xbb1898: r0 = LoadClassIdInstr(r1)
    //     0xbb1898: ldur            x0, [x1, #-1]
    //     0xbb189c: ubfx            x0, x0, #0xc, #0x14
    // 0xbb18a0: str             x1, [SP]
    // 0xbb18a4: r0 = GDT[cid_x0 + 0x11c33]()
    //     0xbb18a4: mov             x17, #0x1c33
    //     0xbb18a8: movk            x17, #1, lsl #16
    //     0xbb18ac: add             lr, x0, x17
    //     0xbb18b0: ldr             lr, [x21, lr, lsl #3]
    //     0xbb18b4: blr             lr
    // 0xbb18b8: mov             x3, x0
    // 0xbb18bc: ldur            x0, [fp, #-0x28]
    // 0xbb18c0: stur            x3, [fp, #-0x38]
    // 0xbb18c4: LoadField: r4 = r0->field_7
    //     0xbb18c4: ldur            w4, [x0, #7]
    // 0xbb18c8: DecompressPointer r4
    //     0xbb18c8: add             x4, x4, HEAP, lsl #32
    // 0xbb18cc: mov             x1, x4
    // 0xbb18d0: ldur            x2, [fp, #-0x20]
    // 0xbb18d4: stur            x4, [fp, #-0x30]
    // 0xbb18d8: r0 = _getValueOrData()
    //     0xbb18d8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xbb18dc: ldur            x3, [fp, #-0x30]
    // 0xbb18e0: LoadField: r1 = r3->field_f
    //     0xbb18e0: ldur            w1, [x3, #0xf]
    // 0xbb18e4: DecompressPointer r1
    //     0xbb18e4: add             x1, x1, HEAP, lsl #32
    // 0xbb18e8: cmp             w1, w0
    // 0xbb18ec: b.ne            #0xbb18f8
    // 0xbb18f0: r4 = Null
    //     0xbb18f0: mov             x4, NULL
    // 0xbb18f4: b               #0xbb18fc
    // 0xbb18f8: mov             x4, x0
    // 0xbb18fc: stur            x4, [fp, #-0x28]
    // 0xbb1900: cmp             w4, NULL
    // 0xbb1904: b.eq            #0xbb198c
    // 0xbb1908: r0 = LoadClassIdInstr(r4)
    //     0xbb1908: ldur            x0, [x4, #-1]
    //     0xbb190c: ubfx            x0, x0, #0xc, #0x14
    // 0xbb1910: mov             x1, x4
    // 0xbb1914: ldur            x2, [fp, #-0x38]
    // 0xbb1918: r0 = GDT[cid_x0 + 0x129dd]()
    //     0xbb1918: mov             x17, #0x29dd
    //     0xbb191c: movk            x17, #1, lsl #16
    //     0xbb1920: add             lr, x0, x17
    //     0xbb1924: ldr             lr, [x21, lr, lsl #3]
    //     0xbb1928: blr             lr
    // 0xbb192c: ldur            x1, [fp, #-0x28]
    // 0xbb1930: r0 = LoadClassIdInstr(r1)
    //     0xbb1930: ldur            x0, [x1, #-1]
    //     0xbb1934: ubfx            x0, x0, #0xc, #0x14
    // 0xbb1938: r0 = GDT[cid_x0 + 0x687]()
    //     0xbb1938: add             lr, x0, #0x687
    //     0xbb193c: ldr             lr, [x21, lr, lsl #3]
    //     0xbb1940: blr             lr
    // 0xbb1944: tbnz            w0, #4, #0xbb1954
    // 0xbb1948: ldur            x1, [fp, #-0x30]
    // 0xbb194c: ldur            x2, [fp, #-0x20]
    // 0xbb1950: r0 = remove()
    //     0xbb1950: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xbb1954: ldur            x2, [fp, #-0x10]
    // 0xbb1958: ldur            x0, [fp, #-0x18]
    // 0xbb195c: b               #0xbb1810
    // 0xbb1960: ldur            x1, [fp, #-0x10]
    // 0xbb1964: r0 = clear()
    //     0xbb1964: bl              #0x831198  ; [dart:collection] _HashSet::clear
    // 0xbb1968: r0 = Null
    //     0xbb1968: mov             x0, NULL
    // 0xbb196c: LeaveFrame
    //     0xbb196c: mov             SP, fp
    //     0xbb1970: ldp             fp, lr, [SP], #0x10
    // 0xbb1974: ret
    //     0xbb1974: ret             
    // 0xbb1978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb197c: b               #0xbb17bc
    // 0xbb1980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1980: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1984: b               #0xbb1820
    // 0xbb1988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb1988: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb198c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb198c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  void resolve(OneSequenceGestureRecognizer, GestureDisposition) {
    // ** addr: 0xd01818, size: 0x168
    // 0xd01818: EnterFrame
    //     0xd01818: stp             fp, lr, [SP, #-0x10]!
    //     0xd0181c: mov             fp, SP
    // 0xd01820: AllocStack(0x30)
    //     0xd01820: sub             SP, SP, #0x30
    // 0xd01824: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd01824: stur            x2, [fp, #-0x10]
    // 0xd01828: CheckStackOverflow
    //     0xd01828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0182c: cmp             SP, x16
    //     0xd01830: b.ls            #0xd01970
    // 0xd01834: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd01834: ldur            w0, [x1, #0x17]
    // 0xd01838: DecompressPointer r0
    //     0xd01838: add             x0, x0, HEAP, lsl #32
    // 0xd0183c: stur            x0, [fp, #-8]
    // 0xd01840: r1 = <GestureArenaEntry>
    //     0xd01840: add             x1, PP, #0x26, lsl #12  ; [pp+0x26640] TypeArguments: <GestureArenaEntry>
    //     0xd01844: ldr             x1, [x1, #0x640]
    // 0xd01848: r0 = _CompactValuesIterable()
    //     0xd01848: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xd0184c: mov             x1, x0
    // 0xd01850: ldur            x0, [fp, #-8]
    // 0xd01854: StoreField: r1->field_b = r0
    //     0xd01854: stur            w0, [x1, #0xb]
    // 0xd01858: mov             x2, x1
    // 0xd0185c: r1 = <GestureArenaEntry>
    //     0xd0185c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26640] TypeArguments: <GestureArenaEntry>
    //     0xd01860: ldr             x1, [x1, #0x640]
    // 0xd01864: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xd01864: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xd01868: ldur            x1, [fp, #-8]
    // 0xd0186c: stur            x0, [fp, #-8]
    // 0xd01870: r0 = clear()
    //     0xd01870: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xd01874: ldur            x3, [fp, #-8]
    // 0xd01878: LoadField: r4 = r3->field_7
    //     0xd01878: ldur            w4, [x3, #7]
    // 0xd0187c: DecompressPointer r4
    //     0xd0187c: add             x4, x4, HEAP, lsl #32
    // 0xd01880: stur            x4, [fp, #-0x30]
    // 0xd01884: LoadField: r0 = r3->field_b
    //     0xd01884: ldur            w0, [x3, #0xb]
    // 0xd01888: r5 = LoadInt32Instr(r0)
    //     0xd01888: sbfx            x5, x0, #1, #0x1f
    // 0xd0188c: stur            x5, [fp, #-0x28]
    // 0xd01890: r0 = 0
    //     0xd01890: mov             x0, #0
    // 0xd01894: CheckStackOverflow
    //     0xd01894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01898: cmp             SP, x16
    //     0xd0189c: b.ls            #0xd01978
    // 0xd018a0: LoadField: r1 = r3->field_b
    //     0xd018a0: ldur            w1, [x3, #0xb]
    // 0xd018a4: r2 = LoadInt32Instr(r1)
    //     0xd018a4: sbfx            x2, x1, #1, #0x1f
    // 0xd018a8: cmp             x5, x2
    // 0xd018ac: b.ne            #0xd01950
    // 0xd018b0: cmp             x0, x2
    // 0xd018b4: b.ge            #0xd01940
    // 0xd018b8: LoadField: r1 = r3->field_f
    //     0xd018b8: ldur            w1, [x3, #0xf]
    // 0xd018bc: DecompressPointer r1
    //     0xd018bc: add             x1, x1, HEAP, lsl #32
    // 0xd018c0: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0xd018c0: add             x16, x1, x0, lsl #2
    //     0xd018c4: ldur            w6, [x16, #0xf]
    // 0xd018c8: DecompressPointer r6
    //     0xd018c8: add             x6, x6, HEAP, lsl #32
    // 0xd018cc: stur            x6, [fp, #-0x20]
    // 0xd018d0: add             x7, x0, #1
    // 0xd018d4: stur            x7, [fp, #-0x18]
    // 0xd018d8: cmp             w6, NULL
    // 0xd018dc: b.ne            #0xd01910
    // 0xd018e0: mov             x0, x6
    // 0xd018e4: mov             x2, x4
    // 0xd018e8: r1 = Null
    //     0xd018e8: mov             x1, NULL
    // 0xd018ec: cmp             w2, NULL
    // 0xd018f0: b.eq            #0xd01910
    // 0xd018f4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd018f4: ldur            w4, [x2, #0x17]
    // 0xd018f8: DecompressPointer r4
    //     0xd018f8: add             x4, x4, HEAP, lsl #32
    // 0xd018fc: r8 = X0
    //     0xd018fc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd01900: LoadField: r9 = r4->field_7
    //     0xd01900: ldur            x9, [x4, #7]
    // 0xd01904: r3 = Null
    //     0xd01904: add             x3, PP, #0x26, lsl #12  ; [pp+0x26648] Null
    //     0xd01908: ldr             x3, [x3, #0x648]
    // 0xd0190c: blr             x9
    // 0xd01910: ldur            x1, [fp, #-0x20]
    // 0xd01914: r0 = LoadClassIdInstr(r1)
    //     0xd01914: ldur            x0, [x1, #-1]
    //     0xd01918: ubfx            x0, x0, #0xc, #0x14
    // 0xd0191c: ldur            x2, [fp, #-0x10]
    // 0xd01920: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd01920: sub             lr, x0, #1, lsl #12
    //     0xd01924: ldr             lr, [x21, lr, lsl #3]
    //     0xd01928: blr             lr
    // 0xd0192c: ldur            x0, [fp, #-0x18]
    // 0xd01930: ldur            x4, [fp, #-0x30]
    // 0xd01934: ldur            x3, [fp, #-8]
    // 0xd01938: ldur            x5, [fp, #-0x28]
    // 0xd0193c: b               #0xd01894
    // 0xd01940: r0 = Null
    //     0xd01940: mov             x0, NULL
    // 0xd01944: LeaveFrame
    //     0xd01944: mov             SP, fp
    //     0xd01948: ldp             fp, lr, [SP], #0x10
    // 0xd0194c: ret
    //     0xd0194c: ret             
    // 0xd01950: mov             x0, x3
    // 0xd01954: r0 = ConcurrentModificationError()
    //     0xd01954: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd01958: mov             x1, x0
    // 0xd0195c: ldur            x0, [fp, #-8]
    // 0xd01960: StoreField: r1->field_b = r0
    //     0xd01960: stur            w0, [x1, #0xb]
    // 0xd01964: mov             x0, x1
    // 0xd01968: r0 = Throw()
    //     0xd01968: bl              #0x13ddb2c  ; ThrowStub
    // 0xd0196c: brk             #0
    // 0xd01970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01974: b               #0xd01834
    // 0xd01978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0197c: b               #0xd018a0
  }
  _ startTrackingPointer(/* No info */) {
    // ** addr: 0x10f2e54, size: 0xf0
    // 0x10f2e54: EnterFrame
    //     0x10f2e54: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2e58: mov             fp, SP
    // 0x10f2e5c: AllocStack(0x28)
    //     0x10f2e5c: sub             SP, SP, #0x28
    // 0x10f2e60: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */)
    //     0x10f2e60: mov             x5, x3
    //     0x10f2e64: stur            x1, [fp, #-0x10]
    //     0x10f2e68: stur            x2, [fp, #-0x18]
    //     0x10f2e6c: stur            x3, [fp, #-0x20]
    // 0x10f2e70: CheckStackOverflow
    //     0x10f2e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2e74: cmp             SP, x16
    //     0x10f2e78: b.ls            #0x10f2f38
    // 0x10f2e7c: r0 = LoadStaticField(0x7d0)
    //     0x10f2e7c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10f2e80: ldr             x0, [x0, #0xfa0]
    // 0x10f2e84: cmp             w0, NULL
    // 0x10f2e88: b.eq            #0x10f2f40
    // 0x10f2e8c: LoadField: r3 = r0->field_13
    //     0x10f2e8c: ldur            w3, [x0, #0x13]
    // 0x10f2e90: DecompressPointer r3
    //     0x10f2e90: add             x3, x3, HEAP, lsl #32
    // 0x10f2e94: stur            x3, [fp, #-8]
    // 0x10f2e98: r0 = LoadClassIdInstr(r1)
    //     0x10f2e98: ldur            x0, [x1, #-1]
    //     0x10f2e9c: ubfx            x0, x0, #0xc, #0x14
    // 0x10f2ea0: str             x1, [SP]
    // 0x10f2ea4: r0 = GDT[cid_x0 + 0x11c33]()
    //     0x10f2ea4: mov             x17, #0x1c33
    //     0x10f2ea8: movk            x17, #1, lsl #16
    //     0x10f2eac: add             lr, x0, x17
    //     0x10f2eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f2eb4: blr             lr
    // 0x10f2eb8: ldur            x1, [fp, #-8]
    // 0x10f2ebc: ldur            x2, [fp, #-0x18]
    // 0x10f2ec0: mov             x3, x0
    // 0x10f2ec4: ldur            x5, [fp, #-0x20]
    // 0x10f2ec8: r0 = addRoute()
    //     0x10f2ec8: bl              #0xba8c10  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute
    // 0x10f2ecc: ldur            x3, [fp, #-0x10]
    // 0x10f2ed0: LoadField: r2 = r3->field_1b
    //     0x10f2ed0: ldur            w2, [x3, #0x1b]
    // 0x10f2ed4: DecompressPointer r2
    //     0x10f2ed4: add             x2, x2, HEAP, lsl #32
    // 0x10f2ed8: ldur            x4, [fp, #-0x18]
    // 0x10f2edc: r0 = BoxInt64Instr(r4)
    //     0x10f2edc: sbfiz           x0, x4, #1, #0x1f
    //     0x10f2ee0: cmp             x4, x0, asr #1
    //     0x10f2ee4: b.eq            #0x10f2ef0
    //     0x10f2ee8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f2eec: stur            x4, [x0, #7]
    // 0x10f2ef0: mov             x1, x2
    // 0x10f2ef4: mov             x2, x0
    // 0x10f2ef8: stur            x0, [fp, #-8]
    // 0x10f2efc: r0 = add()
    //     0x10f2efc: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0x10f2f00: ldur            x1, [fp, #-0x10]
    // 0x10f2f04: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x10f2f04: ldur            w0, [x1, #0x17]
    // 0x10f2f08: DecompressPointer r0
    //     0x10f2f08: add             x0, x0, HEAP, lsl #32
    // 0x10f2f0c: ldur            x2, [fp, #-0x18]
    // 0x10f2f10: stur            x0, [fp, #-0x20]
    // 0x10f2f14: r0 = _addPointerToArena()
    //     0x10f2f14: bl              #0x10f2f44  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::_addPointerToArena
    // 0x10f2f18: ldur            x1, [fp, #-0x20]
    // 0x10f2f1c: ldur            x2, [fp, #-8]
    // 0x10f2f20: mov             x3, x0
    // 0x10f2f24: r0 = []=()
    //     0x10f2f24: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x10f2f28: r0 = Null
    //     0x10f2f28: mov             x0, NULL
    // 0x10f2f2c: LeaveFrame
    //     0x10f2f2c: mov             SP, fp
    //     0x10f2f30: ldp             fp, lr, [SP], #0x10
    // 0x10f2f34: ret
    //     0x10f2f34: ret             
    // 0x10f2f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f2f38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f2f3c: b               #0x10f2e7c
    // 0x10f2f40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f2f40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addPointerToArena(/* No info */) {
    // ** addr: 0x10f2f44, size: 0x90
    // 0x10f2f44: EnterFrame
    //     0x10f2f44: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2f48: mov             fp, SP
    // 0x10f2f4c: AllocStack(0x10)
    //     0x10f2f4c: sub             SP, SP, #0x10
    // 0x10f2f50: SetupParameters(OneSequenceGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f2f50: mov             x4, x1
    //     0x10f2f54: mov             x0, x2
    //     0x10f2f58: stur            x1, [fp, #-8]
    //     0x10f2f5c: stur            x2, [fp, #-0x10]
    // 0x10f2f60: CheckStackOverflow
    //     0x10f2f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2f64: cmp             SP, x16
    //     0x10f2f68: b.ls            #0x10f2fc8
    // 0x10f2f6c: LoadField: r1 = r4->field_1f
    //     0x10f2f6c: ldur            w1, [x4, #0x1f]
    // 0x10f2f70: DecompressPointer r1
    //     0x10f2f70: add             x1, x1, HEAP, lsl #32
    // 0x10f2f74: cmp             w1, NULL
    // 0x10f2f78: b.ne            #0x10f2f84
    // 0x10f2f7c: r0 = Null
    //     0x10f2f7c: mov             x0, NULL
    // 0x10f2f80: b               #0x10f2f90
    // 0x10f2f84: mov             x2, x0
    // 0x10f2f88: mov             x3, x4
    // 0x10f2f8c: r0 = add()
    //     0x10f2f8c: bl              #0x10f2fd4  ; [package:flutter/src/gestures/team.dart] GestureArenaTeam::add
    // 0x10f2f90: cmp             w0, NULL
    // 0x10f2f94: b.ne            #0x10f2fbc
    // 0x10f2f98: r0 = LoadStaticField(0x7d0)
    //     0x10f2f98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10f2f9c: ldr             x0, [x0, #0xfa0]
    // 0x10f2fa0: cmp             w0, NULL
    // 0x10f2fa4: b.eq            #0x10f2fd0
    // 0x10f2fa8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10f2fa8: ldur            w1, [x0, #0x17]
    // 0x10f2fac: DecompressPointer r1
    //     0x10f2fac: add             x1, x1, HEAP, lsl #32
    // 0x10f2fb0: ldur            x2, [fp, #-0x10]
    // 0x10f2fb4: ldur            x3, [fp, #-8]
    // 0x10f2fb8: r0 = add()
    //     0x10f2fb8: bl              #0xba8eac  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x10f2fbc: LeaveFrame
    //     0x10f2fbc: mov             SP, fp
    //     0x10f2fc0: ldp             fp, lr, [SP], #0x10
    // 0x10f2fc4: ret
    //     0x10f2fc4: ret             
    // 0x10f2fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f2fc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f2fcc: b               #0x10f2f6c
    // 0x10f2fd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f2fd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4434, size: 0x48, field offset: 0x24
abstract class PrimaryPointerGestureRecognizer extends OneSequenceGestureRecognizer {

  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0xb997cc, size: 0x5c
    // 0xb997cc: EnterFrame
    //     0xb997cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb997d0: mov             fp, SP
    // 0xb997d4: AllocStack(0x8)
    //     0xb997d4: sub             SP, SP, #8
    // 0xb997d8: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb997d8: mov             x0, x1
    //     0xb997dc: stur            x1, [fp, #-8]
    // 0xb997e0: CheckStackOverflow
    //     0xb997e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb997e4: cmp             SP, x16
    //     0xb997e8: b.ls            #0xb99820
    // 0xb997ec: mov             x1, x0
    // 0xb997f0: r0 = _stopTimer()
    //     0xb997f0: bl              #0xb99828  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0xb997f4: ldur            x2, [fp, #-8]
    // 0xb997f8: r1 = Instance_GestureRecognizerState
    //     0xb997f8: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7ab90] Obj!GestureRecognizerState@12c5bc1
    //     0xb997fc: ldr             x1, [x1, #0xb90]
    // 0xb99800: StoreField: r2->field_33 = r1
    //     0xb99800: stur            w1, [x2, #0x33]
    // 0xb99804: StoreField: r2->field_3b = rNULL
    //     0xb99804: stur            NULL, [x2, #0x3b]
    // 0xb99808: r1 = false
    //     0xb99808: add             x1, NULL, #0x30  ; false
    // 0xb9980c: StoreField: r2->field_3f = r1
    //     0xb9980c: stur            w1, [x2, #0x3f]
    // 0xb99810: r0 = Null
    //     0xb99810: mov             x0, NULL
    // 0xb99814: LeaveFrame
    //     0xb99814: mov             SP, fp
    //     0xb99818: ldp             fp, lr, [SP], #0x10
    // 0xb9981c: ret
    //     0xb9981c: ret             
    // 0xb99820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb99820: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99824: b               #0xb997ec
  }
  _ _stopTimer(/* No info */) {
    // ** addr: 0xb99828, size: 0x54
    // 0xb99828: EnterFrame
    //     0xb99828: stp             fp, lr, [SP, #-0x10]!
    //     0xb9982c: mov             fp, SP
    // 0xb99830: AllocStack(0x8)
    //     0xb99830: sub             SP, SP, #8
    // 0xb99834: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb99834: mov             x0, x1
    //     0xb99838: stur            x1, [fp, #-8]
    // 0xb9983c: CheckStackOverflow
    //     0xb9983c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb99840: cmp             SP, x16
    //     0xb99844: b.ls            #0xb99874
    // 0xb99848: LoadField: r1 = r0->field_43
    //     0xb99848: ldur            w1, [x0, #0x43]
    // 0xb9984c: DecompressPointer r1
    //     0xb9984c: add             x1, x1, HEAP, lsl #32
    // 0xb99850: cmp             w1, NULL
    // 0xb99854: b.eq            #0xb99864
    // 0xb99858: r0 = cancel()
    //     0xb99858: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xb9985c: ldur            x1, [fp, #-8]
    // 0xb99860: StoreField: r1->field_43 = rNULL
    //     0xb99860: stur            NULL, [x1, #0x43]
    // 0xb99864: r0 = Null
    //     0xb99864: mov             x0, NULL
    // 0xb99868: LeaveFrame
    //     0xb99868: mov             SP, fp
    //     0xb9986c: ldp             fp, lr, [SP], #0x10
    // 0xb99870: ret
    //     0xb99870: ret             
    // 0xb99874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb99874: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99878: b               #0xb99848
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xba0254, size: 0x24
    // 0xba0254: EnterFrame
    //     0xba0254: stp             fp, lr, [SP, #-0x10]!
    //     0xba0258: mov             fp, SP
    // 0xba025c: ldr             x2, [fp, #0x10]
    // 0xba0260: r1 = Function 'handleEvent':.
    //     0xba0260: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e6d8] AnonymousClosure: (0xba0278), in [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::handleEvent (0xba02b4)
    //     0xba0264: ldr             x1, [x1, #0x6d8]
    // 0xba0268: r0 = AllocateClosure()
    //     0xba0268: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba026c: LeaveFrame
    //     0xba026c: mov             SP, fp
    //     0xba0270: ldp             fp, lr, [SP], #0x10
    // 0xba0274: ret
    //     0xba0274: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xba0278, size: 0x3c
    // 0xba0278: EnterFrame
    //     0xba0278: stp             fp, lr, [SP, #-0x10]!
    //     0xba027c: mov             fp, SP
    // 0xba0280: ldr             x0, [fp, #0x18]
    // 0xba0284: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba0284: ldur            w1, [x0, #0x17]
    // 0xba0288: DecompressPointer r1
    //     0xba0288: add             x1, x1, HEAP, lsl #32
    // 0xba028c: CheckStackOverflow
    //     0xba028c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba0290: cmp             SP, x16
    //     0xba0294: b.ls            #0xba02ac
    // 0xba0298: ldr             x2, [fp, #0x10]
    // 0xba029c: r0 = handleEvent()
    //     0xba029c: bl              #0xba02b4  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::handleEvent
    // 0xba02a0: LeaveFrame
    //     0xba02a0: mov             SP, fp
    //     0xba02a4: ldp             fp, lr, [SP], #0x10
    // 0xba02a8: ret
    //     0xba02a8: ret             
    // 0xba02ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba02ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba02b0: b               #0xba0298
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xba02b4, size: 0x2d4
    // 0xba02b4: EnterFrame
    //     0xba02b4: stp             fp, lr, [SP, #-0x10]!
    //     0xba02b8: mov             fp, SP
    // 0xba02bc: AllocStack(0x28)
    //     0xba02bc: sub             SP, SP, #0x28
    // 0xba02c0: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba02c0: mov             x3, x1
    //     0xba02c4: stur            x1, [fp, #-8]
    //     0xba02c8: stur            x2, [fp, #-0x10]
    // 0xba02cc: CheckStackOverflow
    //     0xba02cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba02d0: cmp             SP, x16
    //     0xba02d4: b.ls            #0xba0578
    // 0xba02d8: LoadField: r0 = r3->field_33
    //     0xba02d8: ldur            w0, [x3, #0x33]
    // 0xba02dc: DecompressPointer r0
    //     0xba02dc: add             x0, x0, HEAP, lsl #32
    // 0xba02e0: r16 = Instance_GestureRecognizerState
    //     0xba02e0: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cdd8] Obj!GestureRecognizerState@12c5be1
    //     0xba02e4: ldr             x16, [x16, #0xdd8]
    // 0xba02e8: cmp             w0, w16
    // 0xba02ec: b.ne            #0xba055c
    // 0xba02f0: r0 = LoadClassIdInstr(r2)
    //     0xba02f0: ldur            x0, [x2, #-1]
    //     0xba02f4: ubfx            x0, x0, #0xc, #0x14
    // 0xba02f8: mov             x1, x2
    // 0xba02fc: r0 = GDT[cid_x0 + -0x1]()
    //     0xba02fc: sub             lr, x0, #1
    //     0xba0300: ldr             lr, [x21, lr, lsl #3]
    //     0xba0304: blr             lr
    // 0xba0308: mov             x2, x0
    // 0xba030c: ldur            x3, [fp, #-8]
    // 0xba0310: LoadField: r4 = r3->field_37
    //     0xba0310: ldur            w4, [x3, #0x37]
    // 0xba0314: DecompressPointer r4
    //     0xba0314: add             x4, x4, HEAP, lsl #32
    // 0xba0318: r0 = BoxInt64Instr(r2)
    //     0xba0318: sbfiz           x0, x2, #1, #0x1f
    //     0xba031c: cmp             x2, x0, asr #1
    //     0xba0320: b.eq            #0xba032c
    //     0xba0324: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0328: stur            x2, [x0, #7]
    // 0xba032c: cmp             w0, w4
    // 0xba0330: b.eq            #0xba036c
    // 0xba0334: and             w16, w0, w4
    // 0xba0338: branchIfSmi(r16, 0xba055c)
    //     0xba0338: tbz             w16, #0, #0xba055c
    // 0xba033c: r16 = LoadClassIdInstr(r0)
    //     0xba033c: ldur            x16, [x0, #-1]
    //     0xba0340: ubfx            x16, x16, #0xc, #0x14
    // 0xba0344: cmp             x16, #0x3d
    // 0xba0348: b.ne            #0xba055c
    // 0xba034c: r16 = LoadClassIdInstr(r4)
    //     0xba034c: ldur            x16, [x4, #-1]
    //     0xba0350: ubfx            x16, x16, #0xc, #0x14
    // 0xba0354: cmp             x16, #0x3d
    // 0xba0358: b.ne            #0xba055c
    // 0xba035c: LoadField: r16 = r0->field_7
    //     0xba035c: ldur            x16, [x0, #7]
    // 0xba0360: LoadField: r17 = r4->field_7
    //     0xba0360: ldur            x17, [x4, #7]
    // 0xba0364: cmp             x16, x17
    // 0xba0368: b.ne            #0xba055c
    // 0xba036c: LoadField: r0 = r3->field_3f
    //     0xba036c: ldur            w0, [x3, #0x3f]
    // 0xba0370: DecompressPointer r0
    //     0xba0370: add             x0, x0, HEAP, lsl #32
    // 0xba0374: tbz             w0, #4, #0xba03cc
    // 0xba0378: d0 = -1.000000
    //     0xba0378: fmov            d0, #-1.00000000
    // 0xba037c: fcmp            d0, d0
    // 0xba0380: b.ne            #0xba0394
    // 0xba0384: LoadField: r0 = r3->field_7
    //     0xba0384: ldur            w0, [x3, #7]
    // 0xba0388: DecompressPointer r0
    //     0xba0388: add             x0, x0, HEAP, lsl #32
    // 0xba038c: cmp             w0, NULL
    // 0xba0390: b.eq            #0xba0394
    // 0xba0394: mov             x1, x3
    // 0xba0398: ldur            x2, [fp, #-0x10]
    // 0xba039c: r0 = _getGlobalDistance()
    //     0xba039c: bl              #0xba0918  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_getGlobalDistance
    // 0xba03a0: ldur            x1, [fp, #-8]
    // 0xba03a4: stur            d0, [fp, #-0x28]
    // 0xba03a8: r0 = preAcceptSlopTolerance()
    //     0xba03a8: bl              #0xba08c4  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::preAcceptSlopTolerance
    // 0xba03ac: mov             v1.16b, v0.16b
    // 0xba03b0: ldur            d0, [fp, #-0x28]
    // 0xba03b4: fcmp            d0, d1
    // 0xba03b8: r16 = true
    //     0xba03b8: add             x16, NULL, #0x20  ; true
    // 0xba03bc: r17 = false
    //     0xba03bc: add             x17, NULL, #0x30  ; false
    // 0xba03c0: csel            x0, x16, x17, gt
    // 0xba03c4: mov             x2, x0
    // 0xba03c8: b               #0xba03d0
    // 0xba03cc: r2 = false
    //     0xba03cc: add             x2, NULL, #0x30  ; false
    // 0xba03d0: ldur            x0, [fp, #-8]
    // 0xba03d4: stur            x2, [fp, #-0x18]
    // 0xba03d8: LoadField: r1 = r0->field_3f
    //     0xba03d8: ldur            w1, [x0, #0x3f]
    // 0xba03dc: DecompressPointer r1
    //     0xba03dc: add             x1, x1, HEAP, lsl #32
    // 0xba03e0: tbnz            w1, #4, #0xba0434
    // 0xba03e4: mov             x1, x0
    // 0xba03e8: r0 = postAcceptSlopTolerance()
    //     0xba03e8: bl              #0xba07e0  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::postAcceptSlopTolerance
    // 0xba03ec: cmp             w0, NULL
    // 0xba03f0: b.eq            #0xba0434
    // 0xba03f4: ldur            x1, [fp, #-8]
    // 0xba03f8: ldur            x2, [fp, #-0x10]
    // 0xba03fc: r0 = _getGlobalDistance()
    //     0xba03fc: bl              #0xba0918  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_getGlobalDistance
    // 0xba0400: ldur            x1, [fp, #-8]
    // 0xba0404: stur            d0, [fp, #-0x28]
    // 0xba0408: r0 = postAcceptSlopTolerance()
    //     0xba0408: bl              #0xba07e0  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::postAcceptSlopTolerance
    // 0xba040c: cmp             w0, NULL
    // 0xba0410: b.eq            #0xba0580
    // 0xba0414: LoadField: d0 = r0->field_7
    //     0xba0414: ldur            d0, [x0, #7]
    // 0xba0418: ldur            d1, [fp, #-0x28]
    // 0xba041c: fcmp            d1, d0
    // 0xba0420: r16 = true
    //     0xba0420: add             x16, NULL, #0x20  ; true
    // 0xba0424: r17 = false
    //     0xba0424: add             x17, NULL, #0x30  ; false
    // 0xba0428: csel            x0, x16, x17, gt
    // 0xba042c: mov             x3, x0
    // 0xba0430: b               #0xba0438
    // 0xba0434: r3 = false
    //     0xba0434: add             x3, NULL, #0x30  ; false
    // 0xba0438: ldur            x0, [fp, #-0x10]
    // 0xba043c: stur            x3, [fp, #-0x20]
    // 0xba0440: r2 = Null
    //     0xba0440: mov             x2, NULL
    // 0xba0444: r1 = Null
    //     0xba0444: mov             x1, NULL
    // 0xba0448: cmp             w0, NULL
    // 0xba044c: b.eq            #0xba0474
    // 0xba0450: branchIfSmi(r0, 0xba0474)
    //     0xba0450: tbz             w0, #0, #0xba0474
    // 0xba0454: r3 = LoadClassIdInstr(r0)
    //     0xba0454: ldur            x3, [x0, #-1]
    //     0xba0458: ubfx            x3, x3, #0xc, #0x14
    // 0xba045c: r17 = 4157
    //     0xba045c: mov             x17, #0x103d
    // 0xba0460: cmp             x3, x17
    // 0xba0464: b.eq            #0xba047c
    // 0xba0468: r17 = 5286
    //     0xba0468: mov             x17, #0x14a6
    // 0xba046c: cmp             x3, x17
    // 0xba0470: b.eq            #0xba047c
    // 0xba0474: r0 = false
    //     0xba0474: add             x0, NULL, #0x30  ; false
    // 0xba0478: b               #0xba0480
    // 0xba047c: r0 = true
    //     0xba047c: add             x0, NULL, #0x20  ; true
    // 0xba0480: tbnz            w0, #4, #0xba0538
    // 0xba0484: ldur            x0, [fp, #-0x18]
    // 0xba0488: tbz             w0, #4, #0xba0494
    // 0xba048c: ldur            x0, [fp, #-0x20]
    // 0xba0490: tbnz            w0, #4, #0xba0538
    // 0xba0494: ldur            x0, [fp, #-8]
    // 0xba0498: r1 = LoadClassIdInstr(r0)
    //     0xba0498: ldur            x1, [x0, #-1]
    //     0xba049c: ubfx            x1, x1, #0xc, #0x14
    // 0xba04a0: r17 = -4436
    //     0xba04a0: mov             x17, #-0x1154
    // 0xba04a4: add             x16, x1, x17
    // 0xba04a8: cmp             x16, #2
    // 0xba04ac: b.hi            #0xba04e8
    // 0xba04b0: LoadField: r1 = r0->field_4b
    //     0xba04b0: ldur            w1, [x0, #0x4b]
    // 0xba04b4: DecompressPointer r1
    //     0xba04b4: add             x1, x1, HEAP, lsl #32
    // 0xba04b8: tbnz            w1, #4, #0xba04d4
    // 0xba04bc: mov             x1, x0
    // 0xba04c0: r2 = "spontaneous"
    //     0xba04c0: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8e6e0] "spontaneous"
    //     0xba04c4: ldr             x2, [x2, #0x6e0]
    // 0xba04c8: r0 = _checkCancel()
    //     0xba04c8: bl              #0xba0770  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0xba04cc: ldur            x1, [fp, #-8]
    // 0xba04d0: r0 = _reset()
    //     0xba04d0: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xba04d4: ldur            x1, [fp, #-8]
    // 0xba04d8: r2 = Instance_GestureDisposition
    //     0xba04d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xba04dc: ldr             x2, [x2, #0x610]
    // 0xba04e0: r0 = resolve()
    //     0xba04e0: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba04e4: b               #0xba0518
    // 0xba04e8: LoadField: r1 = r0->field_47
    //     0xba04e8: ldur            w1, [x0, #0x47]
    // 0xba04ec: DecompressPointer r1
    //     0xba04ec: add             x1, x1, HEAP, lsl #32
    // 0xba04f0: tbnz            w1, #4, #0xba0500
    // 0xba04f4: mov             x1, x0
    // 0xba04f8: r0 = _reset()
    //     0xba04f8: bl              #0xba0738  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0xba04fc: b               #0xba0508
    // 0xba0500: ldur            x1, [fp, #-8]
    // 0xba0504: r0 = _checkLongPressCancel()
    //     0xba0504: bl              #0xba06bc  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0xba0508: ldur            x1, [fp, #-8]
    // 0xba050c: r2 = Instance_GestureDisposition
    //     0xba050c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xba0510: ldr             x2, [x2, #0x610]
    // 0xba0514: r0 = resolve()
    //     0xba0514: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba0518: ldur            x0, [fp, #-8]
    // 0xba051c: LoadField: r2 = r0->field_37
    //     0xba051c: ldur            w2, [x0, #0x37]
    // 0xba0520: DecompressPointer r2
    //     0xba0520: add             x2, x2, HEAP, lsl #32
    // 0xba0524: cmp             w2, NULL
    // 0xba0528: b.eq            #0xba0584
    // 0xba052c: mov             x1, x0
    // 0xba0530: r0 = stopTrackingPointer()
    //     0xba0530: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xba0534: b               #0xba055c
    // 0xba0538: ldur            x3, [fp, #-8]
    // 0xba053c: r0 = LoadClassIdInstr(r3)
    //     0xba053c: ldur            x0, [x3, #-1]
    //     0xba0540: ubfx            x0, x0, #0xc, #0x14
    // 0xba0544: mov             x1, x3
    // 0xba0548: ldur            x2, [fp, #-0x10]
    // 0xba054c: r0 = GDT[cid_x0 + 0x1ccd]()
    //     0xba054c: mov             x17, #0x1ccd
    //     0xba0550: add             lr, x0, x17
    //     0xba0554: ldr             lr, [x21, lr, lsl #3]
    //     0xba0558: blr             lr
    // 0xba055c: ldur            x1, [fp, #-8]
    // 0xba0560: ldur            x2, [fp, #-0x10]
    // 0xba0564: r0 = stopTrackingIfPointerNoLongerDown()
    //     0xba0564: bl              #0xb9c294  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0xba0568: r0 = Null
    //     0xba0568: mov             x0, NULL
    // 0xba056c: LeaveFrame
    //     0xba056c: mov             SP, fp
    //     0xba0570: ldp             fp, lr, [SP], #0x10
    // 0xba0574: ret
    //     0xba0574: ret             
    // 0xba0578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba0578: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba057c: b               #0xba02d8
    // 0xba0580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba0580: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba0584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba0584: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ postAcceptSlopTolerance(/* No info */) {
    // ** addr: 0xba07e0, size: 0xe4
    // 0xba07e0: EnterFrame
    //     0xba07e0: stp             fp, lr, [SP, #-0x10]!
    //     0xba07e4: mov             fp, SP
    // 0xba07e8: AllocStack(0x20)
    //     0xba07e8: sub             SP, SP, #0x20
    // 0xba07ec: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r1, fp-0x10 */)
    //     0xba07ec: stur            x1, [fp, #-0x10]
    // 0xba07f0: CheckStackOverflow
    //     0xba07f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba07f4: cmp             SP, x16
    //     0xba07f8: b.ls            #0xba08a8
    // 0xba07fc: LoadField: r2 = r1->field_2f
    //     0xba07fc: ldur            w2, [x1, #0x2f]
    // 0xba0800: DecompressPointer r2
    //     0xba0800: add             x2, x2, HEAP, lsl #32
    // 0xba0804: stur            x2, [fp, #-8]
    // 0xba0808: r0 = LoadClassIdInstr(r2)
    //     0xba0808: ldur            x0, [x2, #-1]
    //     0xba080c: ubfx            x0, x0, #0xc, #0x14
    // 0xba0810: r16 = -1.000000
    //     0xba0810: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0xba0814: ldr             x16, [x16, #0x2a8]
    // 0xba0818: stp             x16, x2, [SP]
    // 0xba081c: mov             lr, x0
    // 0xba0820: ldr             lr, [x21, lr, lsl #3]
    // 0xba0824: blr             lr
    // 0xba0828: tbnz            w0, #4, #0xba0898
    // 0xba082c: ldur            x1, [fp, #-0x10]
    // 0xba0830: LoadField: r2 = r1->field_7
    //     0xba0830: ldur            w2, [x1, #7]
    // 0xba0834: DecompressPointer r2
    //     0xba0834: add             x2, x2, HEAP, lsl #32
    // 0xba0838: cmp             w2, NULL
    // 0xba083c: b.ne            #0xba0848
    // 0xba0840: r1 = Null
    //     0xba0840: mov             x1, NULL
    // 0xba0844: b               #0xba0850
    // 0xba0848: LoadField: r1 = r2->field_7
    //     0xba0848: ldur            w1, [x2, #7]
    // 0xba084c: DecompressPointer r1
    //     0xba084c: add             x1, x1, HEAP, lsl #32
    // 0xba0850: cmp             w1, NULL
    // 0xba0854: b.ne            #0xba0860
    // 0xba0858: d0 = 18.000000
    //     0xba0858: fmov            d0, #18.00000000
    // 0xba085c: b               #0xba0864
    // 0xba0860: LoadField: d0 = r1->field_7
    //     0xba0860: ldur            d0, [x1, #7]
    // 0xba0864: r1 = inline_Allocate_Double()
    //     0xba0864: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xba0868: add             x1, x1, #0x10
    //     0xba086c: cmp             x2, x1
    //     0xba0870: b.ls            #0xba08b0
    //     0xba0874: str             x1, [THR, #0x60]  ; THR::top
    //     0xba0878: sub             x1, x1, #0xf
    //     0xba087c: mov             x2, #0xe19c
    //     0xba0880: movk            x2, #3, lsl #16
    //     0xba0884: stur            x2, [x1, #-1]
    // 0xba0888: dmb             ishst
    // 0xba088c: StoreField: r1->field_7 = d0
    //     0xba088c: stur            d0, [x1, #7]
    // 0xba0890: mov             x0, x1
    // 0xba0894: b               #0xba089c
    // 0xba0898: ldur            x0, [fp, #-8]
    // 0xba089c: LeaveFrame
    //     0xba089c: mov             SP, fp
    //     0xba08a0: ldp             fp, lr, [SP], #0x10
    // 0xba08a4: ret
    //     0xba08a4: ret             
    // 0xba08a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba08a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba08ac: b               #0xba07fc
    // 0xba08b0: SaveReg d0
    //     0xba08b0: str             q0, [SP, #-0x10]!
    // 0xba08b4: r0 = AllocateDouble()
    //     0xba08b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba08b8: mov             x1, x0
    // 0xba08bc: RestoreReg d0
    //     0xba08bc: ldr             q0, [SP], #0x10
    // 0xba08c0: b               #0xba088c
  }
  get _ preAcceptSlopTolerance(/* No info */) {
    // ** addr: 0xba08c4, size: 0x54
    // 0xba08c4: d1 = -1.000000
    //     0xba08c4: fmov            d1, #-1.00000000
    // 0xba08c8: fcmp            d1, d1
    // 0xba08cc: b.ne            #0xba0910
    // 0xba08d0: LoadField: r0 = r1->field_7
    //     0xba08d0: ldur            w0, [x1, #7]
    // 0xba08d4: DecompressPointer r0
    //     0xba08d4: add             x0, x0, HEAP, lsl #32
    // 0xba08d8: cmp             w0, NULL
    // 0xba08dc: b.ne            #0xba08e8
    // 0xba08e0: r0 = Null
    //     0xba08e0: mov             x0, NULL
    // 0xba08e4: b               #0xba08f4
    // 0xba08e8: LoadField: r1 = r0->field_7
    //     0xba08e8: ldur            w1, [x0, #7]
    // 0xba08ec: DecompressPointer r1
    //     0xba08ec: add             x1, x1, HEAP, lsl #32
    // 0xba08f0: mov             x0, x1
    // 0xba08f4: cmp             w0, NULL
    // 0xba08f8: b.ne            #0xba0904
    // 0xba08fc: d1 = 18.000000
    //     0xba08fc: fmov            d1, #18.00000000
    // 0xba0900: b               #0xba0908
    // 0xba0904: LoadField: d1 = r0->field_7
    //     0xba0904: ldur            d1, [x0, #7]
    // 0xba0908: mov             v0.16b, v1.16b
    // 0xba090c: b               #0xba0914
    // 0xba0910: d0 = -1.000000
    //     0xba0910: fmov            d0, #-1.00000000
    // 0xba0914: ret
    //     0xba0914: ret             
  }
  _ _getGlobalDistance(/* No info */) {
    // ** addr: 0xba0918, size: 0x9c
    // 0xba0918: EnterFrame
    //     0xba0918: stp             fp, lr, [SP, #-0x10]!
    //     0xba091c: mov             fp, SP
    // 0xba0920: AllocStack(0x8)
    //     0xba0920: sub             SP, SP, #8
    // 0xba0924: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xba0924: stur            x1, [fp, #-8]
    //     0xba0928: mov             x16, x2
    //     0xba092c: mov             x2, x1
    //     0xba0930: mov             x1, x16
    // 0xba0934: CheckStackOverflow
    //     0xba0934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba0938: cmp             SP, x16
    //     0xba093c: b.ls            #0xba09a8
    // 0xba0940: r0 = LoadClassIdInstr(r1)
    //     0xba0940: ldur            x0, [x1, #-1]
    //     0xba0944: ubfx            x0, x0, #0xc, #0x14
    // 0xba0948: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba0948: mov             x17, #0x3f27
    //     0xba094c: movk            x17, #1, lsl #16
    //     0xba0950: add             lr, x0, x17
    //     0xba0954: ldr             lr, [x21, lr, lsl #3]
    //     0xba0958: blr             lr
    // 0xba095c: mov             x1, x0
    // 0xba0960: ldur            x0, [fp, #-8]
    // 0xba0964: LoadField: r2 = r0->field_3b
    //     0xba0964: ldur            w2, [x0, #0x3b]
    // 0xba0968: DecompressPointer r2
    //     0xba0968: add             x2, x2, HEAP, lsl #32
    // 0xba096c: cmp             w2, NULL
    // 0xba0970: b.eq            #0xba09b0
    // 0xba0974: LoadField: r0 = r2->field_b
    //     0xba0974: ldur            w0, [x2, #0xb]
    // 0xba0978: DecompressPointer r0
    //     0xba0978: add             x0, x0, HEAP, lsl #32
    // 0xba097c: mov             x2, x0
    // 0xba0980: r0 = -()
    //     0xba0980: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xba0984: LoadField: d1 = r0->field_7
    //     0xba0984: ldur            d1, [x0, #7]
    // 0xba0988: fmul            d2, d1, d1
    // 0xba098c: LoadField: d1 = r0->field_f
    //     0xba098c: ldur            d1, [x0, #0xf]
    // 0xba0990: fmul            d3, d1, d1
    // 0xba0994: fadd            d1, d2, d3
    // 0xba0998: fsqrt           d0, d1
    // 0xba099c: LeaveFrame
    //     0xba099c: mov             SP, fp
    //     0xba09a0: ldp             fp, lr, [SP], #0x10
    // 0xba09a4: ret
    //     0xba09a4: ret             
    // 0xba09a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba09a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba09ac: b               #0xba0940
    // 0xba09b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba09b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba7f5c, size: 0x1b4
    // 0xba7f5c: EnterFrame
    //     0xba7f5c: stp             fp, lr, [SP, #-0x10]!
    //     0xba7f60: mov             fp, SP
    // 0xba7f64: AllocStack(0x20)
    //     0xba7f64: sub             SP, SP, #0x20
    // 0xba7f68: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba7f68: stur            x1, [fp, #-8]
    //     0xba7f6c: stur            x2, [fp, #-0x10]
    // 0xba7f70: CheckStackOverflow
    //     0xba7f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7f74: cmp             SP, x16
    //     0xba7f78: b.ls            #0xba8108
    // 0xba7f7c: r1 = 1
    //     0xba7f7c: mov             x1, #1
    // 0xba7f80: r0 = AllocateContext()
    //     0xba7f80: bl              #0x13de838  ; AllocateContextStub
    // 0xba7f84: mov             x3, x0
    // 0xba7f88: ldur            x0, [fp, #-8]
    // 0xba7f8c: stur            x3, [fp, #-0x18]
    // 0xba7f90: StoreField: r3->field_f = r0
    //     0xba7f90: stur            w0, [x3, #0xf]
    // 0xba7f94: mov             x1, x0
    // 0xba7f98: ldur            x2, [fp, #-0x10]
    // 0xba7f9c: r0 = addAllowedPointer()
    //     0xba7f9c: bl              #0xba6ac8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0xba7fa0: ldur            x2, [fp, #-8]
    // 0xba7fa4: LoadField: r0 = r2->field_33
    //     0xba7fa4: ldur            w0, [x2, #0x33]
    // 0xba7fa8: DecompressPointer r0
    //     0xba7fa8: add             x0, x0, HEAP, lsl #32
    // 0xba7fac: r16 = Instance_GestureRecognizerState
    //     0xba7fac: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7ab90] Obj!GestureRecognizerState@12c5bc1
    //     0xba7fb0: ldr             x16, [x16, #0xb90]
    // 0xba7fb4: cmp             w0, w16
    // 0xba7fb8: b.ne            #0xba80f8
    // 0xba7fbc: ldur            x3, [fp, #-0x10]
    // 0xba7fc0: r0 = Instance_GestureRecognizerState
    //     0xba7fc0: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8cdd8] Obj!GestureRecognizerState@12c5be1
    //     0xba7fc4: ldr             x0, [x0, #0xdd8]
    // 0xba7fc8: StoreField: r2->field_33 = r0
    //     0xba7fc8: stur            w0, [x2, #0x33]
    // 0xba7fcc: r0 = LoadClassIdInstr(r3)
    //     0xba7fcc: ldur            x0, [x3, #-1]
    //     0xba7fd0: ubfx            x0, x0, #0xc, #0x14
    // 0xba7fd4: mov             x1, x3
    // 0xba7fd8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba7fd8: sub             lr, x0, #1
    //     0xba7fdc: ldr             lr, [x21, lr, lsl #3]
    //     0xba7fe0: blr             lr
    // 0xba7fe4: mov             x2, x0
    // 0xba7fe8: r0 = BoxInt64Instr(r2)
    //     0xba7fe8: sbfiz           x0, x2, #1, #0x1f
    //     0xba7fec: cmp             x2, x0, asr #1
    //     0xba7ff0: b.eq            #0xba7ffc
    //     0xba7ff4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba7ff8: stur            x2, [x0, #7]
    // 0xba7ffc: ldur            x2, [fp, #-8]
    // 0xba8000: StoreField: r2->field_37 = r0
    //     0xba8000: stur            w0, [x2, #0x37]
    //     0xba8004: tbz             w0, #0, #0xba8020
    //     0xba8008: ldurb           w16, [x2, #-1]
    //     0xba800c: ldurb           w17, [x0, #-1]
    //     0xba8010: and             x16, x17, x16, lsr #2
    //     0xba8014: tst             x16, HEAP, lsr #32
    //     0xba8018: b.eq            #0xba8020
    //     0xba801c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba8020: ldur            x3, [fp, #-0x10]
    // 0xba8024: r0 = LoadClassIdInstr(r3)
    //     0xba8024: ldur            x0, [x3, #-1]
    //     0xba8028: ubfx            x0, x0, #0xc, #0x14
    // 0xba802c: mov             x1, x3
    // 0xba8030: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xba8030: mov             x17, #0x54ea
    //     0xba8034: movk            x17, #1, lsl #16
    //     0xba8038: add             lr, x0, x17
    //     0xba803c: ldr             lr, [x21, lr, lsl #3]
    //     0xba8040: blr             lr
    // 0xba8044: mov             x2, x0
    // 0xba8048: ldur            x1, [fp, #-0x10]
    // 0xba804c: stur            x2, [fp, #-0x20]
    // 0xba8050: r0 = LoadClassIdInstr(r1)
    //     0xba8050: ldur            x0, [x1, #-1]
    //     0xba8054: ubfx            x0, x0, #0xc, #0x14
    // 0xba8058: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba8058: mov             x17, #0x3f27
    //     0xba805c: movk            x17, #1, lsl #16
    //     0xba8060: add             lr, x0, x17
    //     0xba8064: ldr             lr, [x21, lr, lsl #3]
    //     0xba8068: blr             lr
    // 0xba806c: stur            x0, [fp, #-0x10]
    // 0xba8070: r0 = OffsetPair()
    //     0xba8070: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xba8074: mov             x1, x0
    // 0xba8078: ldur            x0, [fp, #-0x20]
    // 0xba807c: StoreField: r1->field_7 = r0
    //     0xba807c: stur            w0, [x1, #7]
    // 0xba8080: ldur            x0, [fp, #-0x10]
    // 0xba8084: StoreField: r1->field_b = r0
    //     0xba8084: stur            w0, [x1, #0xb]
    // 0xba8088: mov             x0, x1
    // 0xba808c: ldur            x3, [fp, #-8]
    // 0xba8090: StoreField: r3->field_3b = r0
    //     0xba8090: stur            w0, [x3, #0x3b]
    //     0xba8094: ldurb           w16, [x3, #-1]
    //     0xba8098: ldurb           w17, [x0, #-1]
    //     0xba809c: and             x16, x17, x16, lsr #2
    //     0xba80a0: tst             x16, HEAP, lsr #32
    //     0xba80a4: b.eq            #0xba80ac
    //     0xba80a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba80ac: LoadField: r0 = r3->field_23
    //     0xba80ac: ldur            w0, [x3, #0x23]
    // 0xba80b0: DecompressPointer r0
    //     0xba80b0: add             x0, x0, HEAP, lsl #32
    // 0xba80b4: ldur            x2, [fp, #-0x18]
    // 0xba80b8: stur            x0, [fp, #-0x10]
    // 0xba80bc: r1 = Function '<anonymous closure>':.
    //     0xba80bc: add             x1, PP, #0x98, lsl #12  ; [pp+0x98610] AnonymousClosure: (0xba8110), in [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::addAllowedPointer (0xba7f5c)
    //     0xba80c0: ldr             x1, [x1, #0x610]
    // 0xba80c4: r0 = AllocateClosure()
    //     0xba80c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba80c8: ldur            x2, [fp, #-0x10]
    // 0xba80cc: mov             x3, x0
    // 0xba80d0: r1 = Null
    //     0xba80d0: mov             x1, NULL
    // 0xba80d4: r0 = Timer()
    //     0xba80d4: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xba80d8: ldur            x1, [fp, #-8]
    // 0xba80dc: StoreField: r1->field_43 = r0
    //     0xba80dc: stur            w0, [x1, #0x43]
    //     0xba80e0: ldurb           w16, [x1, #-1]
    //     0xba80e4: ldurb           w17, [x0, #-1]
    //     0xba80e8: and             x16, x17, x16, lsr #2
    //     0xba80ec: tst             x16, HEAP, lsr #32
    //     0xba80f0: b.eq            #0xba80f8
    //     0xba80f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba80f8: r0 = Null
    //     0xba80f8: mov             x0, NULL
    // 0xba80fc: LeaveFrame
    //     0xba80fc: mov             SP, fp
    //     0xba8100: ldp             fp, lr, [SP], #0x10
    // 0xba8104: ret
    //     0xba8104: ret             
    // 0xba8108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba810c: b               #0xba7f7c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba8110, size: 0x48
    // 0xba8110: EnterFrame
    //     0xba8110: stp             fp, lr, [SP, #-0x10]!
    //     0xba8114: mov             fp, SP
    // 0xba8118: ldr             x0, [fp, #0x10]
    // 0xba811c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba811c: ldur            w1, [x0, #0x17]
    // 0xba8120: DecompressPointer r1
    //     0xba8120: add             x1, x1, HEAP, lsl #32
    // 0xba8124: CheckStackOverflow
    //     0xba8124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8128: cmp             SP, x16
    //     0xba812c: b.ls            #0xba8150
    // 0xba8130: LoadField: r0 = r1->field_f
    //     0xba8130: ldur            w0, [x1, #0xf]
    // 0xba8134: DecompressPointer r0
    //     0xba8134: add             x0, x0, HEAP, lsl #32
    // 0xba8138: mov             x1, x0
    // 0xba813c: r0 = didExceedDeadlineWithEvent()
    //     0xba813c: bl              #0xba8158  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::didExceedDeadlineWithEvent
    // 0xba8140: r0 = Null
    //     0xba8140: mov             x0, NULL
    // 0xba8144: LeaveFrame
    //     0xba8144: mov             SP, fp
    //     0xba8148: ldp             fp, lr, [SP], #0x10
    // 0xba814c: ret
    //     0xba814c: ret             
    // 0xba8150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8154: b               #0xba8130
  }
  _ didExceedDeadlineWithEvent(/* No info */) {
    // ** addr: 0xba8158, size: 0xa8
    // 0xba8158: EnterFrame
    //     0xba8158: stp             fp, lr, [SP, #-0x10]!
    //     0xba815c: mov             fp, SP
    // 0xba8160: AllocStack(0x8)
    //     0xba8160: sub             SP, SP, #8
    // 0xba8164: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba8164: mov             x0, x1
    //     0xba8168: stur            x1, [fp, #-8]
    // 0xba816c: CheckStackOverflow
    //     0xba816c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8170: cmp             SP, x16
    //     0xba8174: b.ls            #0xba81f4
    // 0xba8178: r1 = LoadClassIdInstr(r0)
    //     0xba8178: ldur            x1, [x0, #-1]
    //     0xba817c: ubfx            x1, x1, #0xc, #0x14
    // 0xba8180: r17 = -4436
    //     0xba8180: mov             x17, #-0x1154
    // 0xba8184: add             x16, x1, x17
    // 0xba8188: cmp             x16, #2
    // 0xba818c: b.hi            #0xba819c
    // 0xba8190: mov             x1, x0
    // 0xba8194: r0 = _checkDown()
    //     0xba8194: bl              #0xba8428  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkDown
    // 0xba8198: b               #0xba81e4
    // 0xba819c: mov             x1, x0
    // 0xba81a0: r2 = Instance_GestureDisposition
    //     0xba81a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba81a4: ldr             x2, [x2, #0x628]
    // 0xba81a8: r0 = resolve()
    //     0xba81a8: bl              #0xd01720  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0xba81ac: ldur            x0, [fp, #-8]
    // 0xba81b0: r1 = true
    //     0xba81b0: add             x1, NULL, #0x20  ; true
    // 0xba81b4: StoreField: r0->field_47 = r1
    //     0xba81b4: stur            w1, [x0, #0x47]
    // 0xba81b8: LoadField: r1 = r0->field_37
    //     0xba81b8: ldur            w1, [x0, #0x37]
    // 0xba81bc: DecompressPointer r1
    //     0xba81bc: add             x1, x1, HEAP, lsl #32
    // 0xba81c0: cmp             w1, NULL
    // 0xba81c4: b.eq            #0xba81fc
    // 0xba81c8: r2 = LoadInt32Instr(r1)
    //     0xba81c8: sbfx            x2, x1, #1, #0x1f
    //     0xba81cc: tbz             w1, #0, #0xba81d4
    //     0xba81d0: ldur            x2, [x1, #7]
    // 0xba81d4: mov             x1, x0
    // 0xba81d8: r0 = acceptGesture()
    //     0xba81d8: bl              #0xba8380  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::acceptGesture
    // 0xba81dc: ldur            x1, [fp, #-8]
    // 0xba81e0: r0 = _checkLongPressStart()
    //     0xba81e0: bl              #0xba8200  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressStart
    // 0xba81e4: r0 = Null
    //     0xba81e4: mov             x0, NULL
    // 0xba81e8: LeaveFrame
    //     0xba81e8: mov             SP, fp
    //     0xba81ec: ldp             fp, lr, [SP], #0x10
    // 0xba81f0: ret
    //     0xba81f0: ret             
    // 0xba81f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba81f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba81f8: b               #0xba8178
    // 0xba81fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba81fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xba8380, size: 0xa8
    // 0xba8380: EnterFrame
    //     0xba8380: stp             fp, lr, [SP, #-0x10]!
    //     0xba8384: mov             fp, SP
    // 0xba8388: AllocStack(0x8)
    //     0xba8388: sub             SP, SP, #8
    // 0xba838c: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r3, fp-0x8 */)
    //     0xba838c: mov             x3, x1
    //     0xba8390: stur            x1, [fp, #-8]
    // 0xba8394: CheckStackOverflow
    //     0xba8394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8398: cmp             SP, x16
    //     0xba839c: b.ls            #0xba8420
    // 0xba83a0: LoadField: r4 = r3->field_37
    //     0xba83a0: ldur            w4, [x3, #0x37]
    // 0xba83a4: DecompressPointer r4
    //     0xba83a4: add             x4, x4, HEAP, lsl #32
    // 0xba83a8: r0 = BoxInt64Instr(r2)
    //     0xba83a8: sbfiz           x0, x2, #1, #0x1f
    //     0xba83ac: cmp             x2, x0, asr #1
    //     0xba83b0: b.eq            #0xba83bc
    //     0xba83b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba83b8: stur            x2, [x0, #7]
    // 0xba83bc: cmp             w0, w4
    // 0xba83c0: b.eq            #0xba83fc
    // 0xba83c4: and             w16, w0, w4
    // 0xba83c8: branchIfSmi(r16, 0xba8410)
    //     0xba83c8: tbz             w16, #0, #0xba8410
    // 0xba83cc: r16 = LoadClassIdInstr(r0)
    //     0xba83cc: ldur            x16, [x0, #-1]
    //     0xba83d0: ubfx            x16, x16, #0xc, #0x14
    // 0xba83d4: cmp             x16, #0x3d
    // 0xba83d8: b.ne            #0xba8410
    // 0xba83dc: r16 = LoadClassIdInstr(r4)
    //     0xba83dc: ldur            x16, [x4, #-1]
    //     0xba83e0: ubfx            x16, x16, #0xc, #0x14
    // 0xba83e4: cmp             x16, #0x3d
    // 0xba83e8: b.ne            #0xba8410
    // 0xba83ec: LoadField: r16 = r0->field_7
    //     0xba83ec: ldur            x16, [x0, #7]
    // 0xba83f0: LoadField: r17 = r4->field_7
    //     0xba83f0: ldur            x17, [x4, #7]
    // 0xba83f4: cmp             x16, x17
    // 0xba83f8: b.ne            #0xba8410
    // 0xba83fc: mov             x1, x3
    // 0xba8400: r0 = _stopTimer()
    //     0xba8400: bl              #0xb99828  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0xba8404: ldur            x1, [fp, #-8]
    // 0xba8408: r2 = true
    //     0xba8408: add             x2, NULL, #0x20  ; true
    // 0xba840c: StoreField: r1->field_3f = r2
    //     0xba840c: stur            w2, [x1, #0x3f]
    // 0xba8410: r0 = Null
    //     0xba8410: mov             x0, NULL
    // 0xba8414: LeaveFrame
    //     0xba8414: mov             SP, fp
    //     0xba8418: ldp             fp, lr, [SP], #0x10
    // 0xba841c: ret
    //     0xba841c: ret             
    // 0xba8420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8424: b               #0xba83a0
  }
  _ handleNonAllowedPointer(/* No info */) {
    // ** addr: 0xbae72c, size: 0x3c
    // 0xbae72c: EnterFrame
    //     0xbae72c: stp             fp, lr, [SP, #-0x10]!
    //     0xbae730: mov             fp, SP
    // 0xbae734: CheckStackOverflow
    //     0xbae734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbae738: cmp             SP, x16
    //     0xbae73c: b.ls            #0xbae760
    // 0xbae740: LoadField: r0 = r1->field_3f
    //     0xbae740: ldur            w0, [x1, #0x3f]
    // 0xbae744: DecompressPointer r0
    //     0xbae744: add             x0, x0, HEAP, lsl #32
    // 0xbae748: tbz             w0, #4, #0xbae750
    // 0xbae74c: r0 = handleNonAllowedPointer()
    //     0xbae74c: bl              #0xbae768  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::handleNonAllowedPointer
    // 0xbae750: r0 = Null
    //     0xbae750: mov             x0, NULL
    // 0xbae754: LeaveFrame
    //     0xbae754: mov             SP, fp
    //     0xbae758: ldp             fp, lr, [SP], #0x10
    // 0xbae75c: ret
    //     0xbae75c: ret             
    // 0xbae760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbae760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbae764: b               #0xbae740
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb1708, size: 0x48
    // 0xbb1708: EnterFrame
    //     0xbb1708: stp             fp, lr, [SP, #-0x10]!
    //     0xbb170c: mov             fp, SP
    // 0xbb1710: AllocStack(0x8)
    //     0xbb1710: sub             SP, SP, #8
    // 0xbb1714: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xbb1714: mov             x0, x1
    //     0xbb1718: stur            x1, [fp, #-8]
    // 0xbb171c: CheckStackOverflow
    //     0xbb171c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1720: cmp             SP, x16
    //     0xbb1724: b.ls            #0xbb1748
    // 0xbb1728: mov             x1, x0
    // 0xbb172c: r0 = _stopTimer()
    //     0xbb172c: bl              #0xb99828  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0xbb1730: ldur            x1, [fp, #-8]
    // 0xbb1734: r0 = dispose()
    //     0xbb1734: bl              #0xbb179c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbb1738: r0 = Null
    //     0xbb1738: mov             x0, NULL
    // 0xbb173c: LeaveFrame
    //     0xbb173c: mov             SP, fp
    //     0xbb1740: ldp             fp, lr, [SP], #0x10
    // 0xbb1744: ret
    //     0xbb1744: ret             
    // 0xbb1748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb174c: b               #0xbb1728
  }
  _ PrimaryPointerGestureRecognizer(/* No info */) {
    // ** addr: 0xc0a0f8, size: 0xb8
    // 0xc0a0f8: EnterFrame
    //     0xc0a0f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a0fc: mov             fp, SP
    // 0xc0a100: AllocStack(0x10)
    //     0xc0a100: sub             SP, SP, #0x10
    // 0xc0a104: r4 = Instance_GestureRecognizerState
    //     0xc0a104: add             x4, PP, #0x7a, lsl #12  ; [pp+0x7ab90] Obj!GestureRecognizerState@12c5bc1
    //     0xc0a108: ldr             x4, [x4, #0xb90]
    // 0xc0a10c: r0 = false
    //     0xc0a10c: add             x0, NULL, #0x30  ; false
    // 0xc0a110: d0 = -1.000000
    //     0xc0a110: fmov            d0, #-1.00000000
    // 0xc0a114: mov             x16, x5
    // 0xc0a118: mov             x5, x1
    // 0xc0a11c: mov             x1, x16
    // 0xc0a120: mov             x16, x3
    // 0xc0a124: mov             x3, x2
    // 0xc0a128: mov             x2, x16
    // 0xc0a12c: CheckStackOverflow
    //     0xc0a12c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a130: cmp             SP, x16
    //     0xc0a134: b.ls            #0xc0a1a8
    // 0xc0a138: StoreField: r5->field_33 = r4
    //     0xc0a138: stur            w4, [x5, #0x33]
    // 0xc0a13c: StoreField: r5->field_3f = r0
    //     0xc0a13c: stur            w0, [x5, #0x3f]
    // 0xc0a140: mov             x0, x2
    // 0xc0a144: StoreField: r5->field_23 = r0
    //     0xc0a144: stur            w0, [x5, #0x23]
    //     0xc0a148: ldurb           w16, [x5, #-1]
    //     0xc0a14c: ldurb           w17, [x0, #-1]
    //     0xc0a150: and             x16, x17, x16, lsr #2
    //     0xc0a154: tst             x16, HEAP, lsr #32
    //     0xc0a158: b.eq            #0xc0a160
    //     0xc0a15c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xc0a160: StoreField: r5->field_27 = d0
    //     0xc0a160: stur            d0, [x5, #0x27]
    // 0xc0a164: mov             x0, x1
    // 0xc0a168: StoreField: r5->field_2f = r0
    //     0xc0a168: stur            w0, [x5, #0x2f]
    //     0xc0a16c: ldurb           w16, [x5, #-1]
    //     0xc0a170: ldurb           w17, [x0, #-1]
    //     0xc0a174: and             x16, x17, x16, lsr #2
    //     0xc0a178: tst             x16, HEAP, lsr #32
    //     0xc0a17c: b.eq            #0xc0a184
    //     0xc0a180: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xc0a184: stp             x3, x6, [SP]
    // 0xc0a188: mov             x1, x5
    // 0xc0a18c: r4 = const [0, 0x3, 0x2, 0x1, allowedButtonsFilter, 0x2, supportedDevices, 0x1, null]
    //     0xc0a18c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15560] List(9) [0, 0x3, 0x2, 0x1, "allowedButtonsFilter", 0x2, "supportedDevices", 0x1, Null]
    //     0xc0a190: ldr             x4, [x4, #0x560]
    // 0xc0a194: r0 = OneSequenceGestureRecognizer()
    //     0xc0a194: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xc0a198: r0 = Null
    //     0xc0a198: mov             x0, NULL
    // 0xc0a19c: LeaveFrame
    //     0xc0a19c: mov             SP, fp
    //     0xc0a1a0: ldp             fp, lr, [SP], #0x10
    // 0xc0a1a4: ret
    //     0xc0a1a4: ret             
    // 0xc0a1a8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc0a1a8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc0a1ac: b               #0xc0a138
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116cffc, size: 0xc4
    // 0x116cffc: EnterFrame
    //     0x116cffc: stp             fp, lr, [SP, #-0x10]!
    //     0x116d000: mov             fp, SP
    // 0x116d004: AllocStack(0x8)
    //     0x116d004: sub             SP, SP, #8
    // 0x116d008: SetupParameters(PrimaryPointerGestureRecognizer this /* r1 => r3, fp-0x8 */)
    //     0x116d008: mov             x3, x1
    //     0x116d00c: stur            x1, [fp, #-8]
    // 0x116d010: CheckStackOverflow
    //     0x116d010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d014: cmp             SP, x16
    //     0x116d018: b.ls            #0x116d0b8
    // 0x116d01c: LoadField: r4 = r3->field_37
    //     0x116d01c: ldur            w4, [x3, #0x37]
    // 0x116d020: DecompressPointer r4
    //     0x116d020: add             x4, x4, HEAP, lsl #32
    // 0x116d024: r0 = BoxInt64Instr(r2)
    //     0x116d024: sbfiz           x0, x2, #1, #0x1f
    //     0x116d028: cmp             x2, x0, asr #1
    //     0x116d02c: b.eq            #0x116d038
    //     0x116d030: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d034: stur            x2, [x0, #7]
    // 0x116d038: cmp             w0, w4
    // 0x116d03c: b.eq            #0x116d078
    // 0x116d040: and             w16, w0, w4
    // 0x116d044: branchIfSmi(r16, 0x116d0a8)
    //     0x116d044: tbz             w16, #0, #0x116d0a8
    // 0x116d048: r16 = LoadClassIdInstr(r0)
    //     0x116d048: ldur            x16, [x0, #-1]
    //     0x116d04c: ubfx            x16, x16, #0xc, #0x14
    // 0x116d050: cmp             x16, #0x3d
    // 0x116d054: b.ne            #0x116d0a8
    // 0x116d058: r16 = LoadClassIdInstr(r4)
    //     0x116d058: ldur            x16, [x4, #-1]
    //     0x116d05c: ubfx            x16, x16, #0xc, #0x14
    // 0x116d060: cmp             x16, #0x3d
    // 0x116d064: b.ne            #0x116d0a8
    // 0x116d068: LoadField: r16 = r0->field_7
    //     0x116d068: ldur            x16, [x0, #7]
    // 0x116d06c: LoadField: r17 = r4->field_7
    //     0x116d06c: ldur            x17, [x4, #7]
    // 0x116d070: cmp             x16, x17
    // 0x116d074: b.ne            #0x116d0a8
    // 0x116d078: LoadField: r0 = r3->field_33
    //     0x116d078: ldur            w0, [x3, #0x33]
    // 0x116d07c: DecompressPointer r0
    //     0x116d07c: add             x0, x0, HEAP, lsl #32
    // 0x116d080: r16 = Instance_GestureRecognizerState
    //     0x116d080: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cdd8] Obj!GestureRecognizerState@12c5be1
    //     0x116d084: ldr             x16, [x16, #0xdd8]
    // 0x116d088: cmp             w0, w16
    // 0x116d08c: b.ne            #0x116d0a8
    // 0x116d090: mov             x1, x3
    // 0x116d094: r0 = _stopTimer()
    //     0x116d094: bl              #0xb99828  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0x116d098: ldur            x1, [fp, #-8]
    // 0x116d09c: r2 = Instance_GestureRecognizerState
    //     0x116d09c: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8e6e8] Obj!GestureRecognizerState@12c5c01
    //     0x116d0a0: ldr             x2, [x2, #0x6e8]
    // 0x116d0a4: StoreField: r1->field_33 = r2
    //     0x116d0a4: stur            w2, [x1, #0x33]
    // 0x116d0a8: r0 = Null
    //     0x116d0a8: mov             x0, NULL
    // 0x116d0ac: LeaveFrame
    //     0x116d0ac: mov             SP, fp
    //     0x116d0b0: ldp             fp, lr, [SP], #0x10
    // 0x116d0b4: ret
    //     0x116d0b4: ret             
    // 0x116d0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d0b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d0bc: b               #0x116d01c
  }
}

// class id: 8306, size: 0x14, field offset: 0x14
enum GestureRecognizerState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9b1c, size: 0x64
    // 0x11a9b1c: EnterFrame
    //     0x11a9b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9b20: mov             fp, SP
    // 0x11a9b24: AllocStack(0x10)
    //     0x11a9b24: sub             SP, SP, #0x10
    // 0x11a9b28: SetupParameters(GestureRecognizerState this /* r1 => r0, fp-0x8 */)
    //     0x11a9b28: mov             x0, x1
    //     0x11a9b2c: stur            x1, [fp, #-8]
    // 0x11a9b30: CheckStackOverflow
    //     0x11a9b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9b34: cmp             SP, x16
    //     0x11a9b38: b.ls            #0x11a9b78
    // 0x11a9b3c: r1 = Null
    //     0x11a9b3c: mov             x1, NULL
    // 0x11a9b40: r2 = 4
    //     0x11a9b40: mov             x2, #4
    // 0x11a9b44: r0 = AllocateArray()
    //     0x11a9b44: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9b48: r16 = "GestureRecognizerState."
    //     0x11a9b48: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e6d0] "GestureRecognizerState."
    //     0x11a9b4c: ldr             x16, [x16, #0x6d0]
    // 0x11a9b50: StoreField: r0->field_f = r16
    //     0x11a9b50: stur            w16, [x0, #0xf]
    // 0x11a9b54: ldur            x1, [fp, #-8]
    // 0x11a9b58: LoadField: r2 = r1->field_f
    //     0x11a9b58: ldur            w2, [x1, #0xf]
    // 0x11a9b5c: DecompressPointer r2
    //     0x11a9b5c: add             x2, x2, HEAP, lsl #32
    // 0x11a9b60: StoreField: r0->field_13 = r2
    //     0x11a9b60: stur            w2, [x0, #0x13]
    // 0x11a9b64: str             x0, [SP]
    // 0x11a9b68: r0 = _interpolate()
    //     0x11a9b68: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9b6c: LeaveFrame
    //     0x11a9b6c: mov             SP, fp
    //     0x11a9b70: ldp             fp, lr, [SP], #0x10
    // 0x11a9b74: ret
    //     0x11a9b74: ret             
    // 0x11a9b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9b78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9b7c: b               #0x11a9b3c
  }
}

// class id: 8307, size: 0x14, field offset: 0x14
enum MultitouchDragStrategy extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9ab8, size: 0x64
    // 0x11a9ab8: EnterFrame
    //     0x11a9ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9abc: mov             fp, SP
    // 0x11a9ac0: AllocStack(0x10)
    //     0x11a9ac0: sub             SP, SP, #0x10
    // 0x11a9ac4: SetupParameters(MultitouchDragStrategy this /* r1 => r0, fp-0x8 */)
    //     0x11a9ac4: mov             x0, x1
    //     0x11a9ac8: stur            x1, [fp, #-8]
    // 0x11a9acc: CheckStackOverflow
    //     0x11a9acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9ad0: cmp             SP, x16
    //     0x11a9ad4: b.ls            #0x11a9b14
    // 0x11a9ad8: r1 = Null
    //     0x11a9ad8: mov             x1, NULL
    // 0x11a9adc: r2 = 4
    //     0x11a9adc: mov             x2, #4
    // 0x11a9ae0: r0 = AllocateArray()
    //     0x11a9ae0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9ae4: r16 = "MultitouchDragStrategy."
    //     0x11a9ae4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26870] "MultitouchDragStrategy."
    //     0x11a9ae8: ldr             x16, [x16, #0x870]
    // 0x11a9aec: StoreField: r0->field_f = r16
    //     0x11a9aec: stur            w16, [x0, #0xf]
    // 0x11a9af0: ldur            x1, [fp, #-8]
    // 0x11a9af4: LoadField: r2 = r1->field_f
    //     0x11a9af4: ldur            w2, [x1, #0xf]
    // 0x11a9af8: DecompressPointer r2
    //     0x11a9af8: add             x2, x2, HEAP, lsl #32
    // 0x11a9afc: StoreField: r0->field_13 = r2
    //     0x11a9afc: stur            w2, [x0, #0x13]
    // 0x11a9b00: str             x0, [SP]
    // 0x11a9b04: r0 = _interpolate()
    //     0x11a9b04: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9b08: LeaveFrame
    //     0x11a9b08: mov             SP, fp
    //     0x11a9b0c: ldp             fp, lr, [SP], #0x10
    // 0x11a9b10: ret
    //     0x11a9b10: ret             
    // 0x11a9b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9b14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9b18: b               #0x11a9ad8
  }
}

// class id: 8308, size: 0x14, field offset: 0x14
enum DragStartBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9a54, size: 0x64
    // 0x11a9a54: EnterFrame
    //     0x11a9a54: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9a58: mov             fp, SP
    // 0x11a9a5c: AllocStack(0x10)
    //     0x11a9a5c: sub             SP, SP, #0x10
    // 0x11a9a60: SetupParameters(DragStartBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11a9a60: mov             x0, x1
    //     0x11a9a64: stur            x1, [fp, #-8]
    // 0x11a9a68: CheckStackOverflow
    //     0x11a9a68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9a6c: cmp             SP, x16
    //     0x11a9a70: b.ls            #0x11a9ab0
    // 0x11a9a74: r1 = Null
    //     0x11a9a74: mov             x1, NULL
    // 0x11a9a78: r2 = 4
    //     0x11a9a78: mov             x2, #4
    // 0x11a9a7c: r0 = AllocateArray()
    //     0x11a9a7c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9a80: r16 = "DragStartBehavior."
    //     0x11a9a80: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ce8] "DragStartBehavior."
    //     0x11a9a84: ldr             x16, [x16, #0xce8]
    // 0x11a9a88: StoreField: r0->field_f = r16
    //     0x11a9a88: stur            w16, [x0, #0xf]
    // 0x11a9a8c: ldur            x1, [fp, #-8]
    // 0x11a9a90: LoadField: r2 = r1->field_f
    //     0x11a9a90: ldur            w2, [x1, #0xf]
    // 0x11a9a94: DecompressPointer r2
    //     0x11a9a94: add             x2, x2, HEAP, lsl #32
    // 0x11a9a98: StoreField: r0->field_13 = r2
    //     0x11a9a98: stur            w2, [x0, #0x13]
    // 0x11a9a9c: str             x0, [SP]
    // 0x11a9aa0: r0 = _interpolate()
    //     0x11a9aa0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9aa4: LeaveFrame
    //     0x11a9aa4: mov             SP, fp
    //     0x11a9aa8: ldp             fp, lr, [SP], #0x10
    // 0x11a9aac: ret
    //     0x11a9aac: ret             
    // 0x11a9ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9ab4: b               #0x11a9a74
  }
}
