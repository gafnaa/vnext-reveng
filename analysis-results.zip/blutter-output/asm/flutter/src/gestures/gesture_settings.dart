// lib: , url: package:flutter/src/gestures/gesture_settings.dart

// class id: 1048823, size: 0x8
class :: {
}

// class id: 3174, size: 0xc, field offset: 0x8
//   const constructor, 
class DeviceGestureSettings extends Object {

  _Double field_8;

  factory _ DeviceGestureSettings.fromView(/* No info */) {
    // ** addr: 0x8cf4d8, size: 0x170
    // 0x8cf4d8: EnterFrame
    //     0x8cf4d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf4dc: mov             fp, SP
    // 0x8cf4e0: AllocStack(0x18)
    //     0x8cf4e0: sub             SP, SP, #0x18
    // 0x8cf4e4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8cf4e4: mov             x0, x2
    //     0x8cf4e8: stur            x2, [fp, #-8]
    // 0x8cf4ec: CheckStackOverflow
    //     0x8cf4ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf4f0: cmp             SP, x16
    //     0x8cf4f4: b.ls            #0x8cf630
    // 0x8cf4f8: mov             x1, x0
    // 0x8cf4fc: r0 = gestureSettings()
    //     0x8cf4fc: bl              #0x8cf654  ; [dart:ui] FlutterView::gestureSettings
    // 0x8cf500: LoadField: r3 = r0->field_7
    //     0x8cf500: ldur            w3, [x0, #7]
    // 0x8cf504: DecompressPointer r3
    //     0x8cf504: add             x3, x3, HEAP, lsl #32
    // 0x8cf508: stur            x3, [fp, #-0x18]
    // 0x8cf50c: cmp             w3, NULL
    // 0x8cf510: b.ne            #0x8cf51c
    // 0x8cf514: r0 = Null
    //     0x8cf514: mov             x0, NULL
    // 0x8cf518: b               #0x8cf614
    // 0x8cf51c: ldur            x4, [fp, #-8]
    // 0x8cf520: r0 = LoadClassIdInstr(r4)
    //     0x8cf520: ldur            x0, [x4, #-1]
    //     0x8cf524: ubfx            x0, x0, #0xc, #0x14
    // 0x8cf528: cmp             x0, #0xe86
    // 0x8cf52c: b.ne            #0x8cf544
    // 0x8cf530: LoadField: r0 = r4->field_13
    //     0x8cf530: ldur            w0, [x4, #0x13]
    // 0x8cf534: DecompressPointer r0
    //     0x8cf534: add             x0, x0, HEAP, lsl #32
    // 0x8cf538: mov             x1, x0
    // 0x8cf53c: mov             x0, x3
    // 0x8cf540: b               #0x8cf5dc
    // 0x8cf544: LoadField: r0 = r4->field_f
    //     0x8cf544: ldur            w0, [x4, #0xf]
    // 0x8cf548: DecompressPointer r0
    //     0x8cf548: add             x0, x0, HEAP, lsl #32
    // 0x8cf54c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x8cf54c: ldur            w5, [x0, #0x17]
    // 0x8cf550: DecompressPointer r5
    //     0x8cf550: add             x5, x5, HEAP, lsl #32
    // 0x8cf554: stur            x5, [fp, #-0x10]
    // 0x8cf558: LoadField: r2 = r4->field_7
    //     0x8cf558: ldur            x2, [x4, #7]
    // 0x8cf55c: r0 = BoxInt64Instr(r2)
    //     0x8cf55c: sbfiz           x0, x2, #1, #0x1f
    //     0x8cf560: cmp             x2, x0, asr #1
    //     0x8cf564: b.eq            #0x8cf570
    //     0x8cf568: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cf56c: stur            x2, [x0, #7]
    // 0x8cf570: mov             x1, x5
    // 0x8cf574: mov             x2, x0
    // 0x8cf578: r0 = _getValueOrData()
    //     0x8cf578: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8cf57c: mov             x1, x0
    // 0x8cf580: ldur            x0, [fp, #-0x10]
    // 0x8cf584: LoadField: r2 = r0->field_f
    //     0x8cf584: ldur            w2, [x0, #0xf]
    // 0x8cf588: DecompressPointer r2
    //     0x8cf588: add             x2, x2, HEAP, lsl #32
    // 0x8cf58c: cmp             w2, w1
    // 0x8cf590: b.ne            #0x8cf598
    // 0x8cf594: r1 = Null
    //     0x8cf594: mov             x1, NULL
    // 0x8cf598: cmp             w1, NULL
    // 0x8cf59c: b.ne            #0x8cf5a8
    // 0x8cf5a0: r0 = Null
    //     0x8cf5a0: mov             x0, NULL
    // 0x8cf5a4: b               #0x8cf5bc
    // 0x8cf5a8: r0 = LoadClassIdInstr(r1)
    //     0x8cf5a8: ldur            x0, [x1, #-1]
    //     0x8cf5ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8cf5b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8cf5b0: sub             lr, x0, #1, lsl #12
    //     0x8cf5b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8cf5b8: blr             lr
    // 0x8cf5bc: cmp             w0, NULL
    // 0x8cf5c0: b.ne            #0x8cf5d4
    // 0x8cf5c4: ldur            x0, [fp, #-8]
    // 0x8cf5c8: LoadField: r1 = r0->field_13
    //     0x8cf5c8: ldur            w1, [x0, #0x13]
    // 0x8cf5cc: DecompressPointer r1
    //     0x8cf5cc: add             x1, x1, HEAP, lsl #32
    // 0x8cf5d0: mov             x0, x1
    // 0x8cf5d4: mov             x1, x0
    // 0x8cf5d8: ldur            x0, [fp, #-0x18]
    // 0x8cf5dc: LoadField: d0 = r1->field_13
    //     0x8cf5dc: ldur            d0, [x1, #0x13]
    // 0x8cf5e0: LoadField: d1 = r0->field_7
    //     0x8cf5e0: ldur            d1, [x0, #7]
    // 0x8cf5e4: fdiv            d2, d1, d0
    // 0x8cf5e8: r0 = inline_Allocate_Double()
    //     0x8cf5e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8cf5ec: add             x0, x0, #0x10
    //     0x8cf5f0: cmp             x1, x0
    //     0x8cf5f4: b.ls            #0x8cf638
    //     0x8cf5f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x8cf5fc: sub             x0, x0, #0xf
    //     0x8cf600: mov             x1, #0xe19c
    //     0x8cf604: movk            x1, #3, lsl #16
    //     0x8cf608: stur            x1, [x0, #-1]
    // 0x8cf60c: dmb             ishst
    // 0x8cf610: StoreField: r0->field_7 = d2
    //     0x8cf610: stur            d2, [x0, #7]
    // 0x8cf614: stur            x0, [fp, #-8]
    // 0x8cf618: r0 = DeviceGestureSettings()
    //     0x8cf618: bl              #0x8cf648  ; AllocateDeviceGestureSettingsStub -> DeviceGestureSettings (size=0xc)
    // 0x8cf61c: ldur            x1, [fp, #-8]
    // 0x8cf620: StoreField: r0->field_7 = r1
    //     0x8cf620: stur            w1, [x0, #7]
    // 0x8cf624: LeaveFrame
    //     0x8cf624: mov             SP, fp
    //     0x8cf628: ldp             fp, lr, [SP], #0x10
    // 0x8cf62c: ret
    //     0x8cf62c: ret             
    // 0x8cf630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf634: b               #0x8cf4f8
    // 0x8cf638: SaveReg d2
    //     0x8cf638: str             q2, [SP, #-0x10]!
    // 0x8cf63c: r0 = AllocateDouble()
    //     0x8cf63c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x8cf640: RestoreReg d2
    //     0x8cf640: ldr             q2, [SP], #0x10
    // 0x8cf644: b               #0x8cf610
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114abd0, size: 0x58
    // 0x114abd0: EnterFrame
    //     0x114abd0: stp             fp, lr, [SP, #-0x10]!
    //     0x114abd4: mov             fp, SP
    // 0x114abd8: CheckStackOverflow
    //     0x114abd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114abdc: cmp             SP, x16
    //     0x114abe0: b.ls            #0x114ac20
    // 0x114abe4: ldr             x0, [fp, #0x10]
    // 0x114abe8: LoadField: r1 = r0->field_7
    //     0x114abe8: ldur            w1, [x0, #7]
    // 0x114abec: DecompressPointer r1
    //     0x114abec: add             x1, x1, HEAP, lsl #32
    // 0x114abf0: r2 = 46
    //     0x114abf0: mov             x2, #0x2e
    // 0x114abf4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x114abf4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x114abf8: r0 = hash()
    //     0x114abf8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114abfc: mov             x2, x0
    // 0x114ac00: r0 = BoxInt64Instr(r2)
    //     0x114ac00: sbfiz           x0, x2, #1, #0x1f
    //     0x114ac04: cmp             x2, x0, asr #1
    //     0x114ac08: b.eq            #0x114ac14
    //     0x114ac0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ac10: stur            x2, [x0, #7]
    // 0x114ac14: LeaveFrame
    //     0x114ac14: mov             SP, fp
    //     0x114ac18: ldp             fp, lr, [SP], #0x10
    // 0x114ac1c: ret
    //     0x114ac1c: ret             
    // 0x114ac20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ac20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ac24: b               #0x114abe4
  }
  _ ==(/* No info */) {
    // ** addr: 0x1295aa4, size: 0xdc
    // 0x1295aa4: EnterFrame
    //     0x1295aa4: stp             fp, lr, [SP, #-0x10]!
    //     0x1295aa8: mov             fp, SP
    // 0x1295aac: AllocStack(0x10)
    //     0x1295aac: sub             SP, SP, #0x10
    // 0x1295ab0: CheckStackOverflow
    //     0x1295ab0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1295ab4: cmp             SP, x16
    //     0x1295ab8: b.ls            #0x1295b78
    // 0x1295abc: ldr             x0, [fp, #0x10]
    // 0x1295ac0: cmp             w0, NULL
    // 0x1295ac4: b.ne            #0x1295ad8
    // 0x1295ac8: r0 = false
    //     0x1295ac8: add             x0, NULL, #0x30  ; false
    // 0x1295acc: LeaveFrame
    //     0x1295acc: mov             SP, fp
    //     0x1295ad0: ldp             fp, lr, [SP], #0x10
    // 0x1295ad4: ret
    //     0x1295ad4: ret             
    // 0x1295ad8: str             x0, [SP]
    // 0x1295adc: r0 = runtimeType()
    //     0x1295adc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1295ae0: r1 = LoadClassIdInstr(r0)
    //     0x1295ae0: ldur            x1, [x0, #-1]
    //     0x1295ae4: ubfx            x1, x1, #0xc, #0x14
    // 0x1295ae8: r16 = DeviceGestureSettings
    //     0x1295ae8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26858] Type: DeviceGestureSettings
    //     0x1295aec: ldr             x16, [x16, #0x858]
    // 0x1295af0: stp             x16, x0, [SP]
    // 0x1295af4: mov             x0, x1
    // 0x1295af8: mov             lr, x0
    // 0x1295afc: ldr             lr, [x21, lr, lsl #3]
    // 0x1295b00: blr             lr
    // 0x1295b04: tbz             w0, #4, #0x1295b18
    // 0x1295b08: r0 = false
    //     0x1295b08: add             x0, NULL, #0x30  ; false
    // 0x1295b0c: LeaveFrame
    //     0x1295b0c: mov             SP, fp
    //     0x1295b10: ldp             fp, lr, [SP], #0x10
    // 0x1295b14: ret
    //     0x1295b14: ret             
    // 0x1295b18: ldr             x0, [fp, #0x10]
    // 0x1295b1c: r1 = 60
    //     0x1295b1c: mov             x1, #0x3c
    // 0x1295b20: branchIfSmi(r0, 0x1295b2c)
    //     0x1295b20: tbz             w0, #0, #0x1295b2c
    // 0x1295b24: r1 = LoadClassIdInstr(r0)
    //     0x1295b24: ldur            x1, [x0, #-1]
    //     0x1295b28: ubfx            x1, x1, #0xc, #0x14
    // 0x1295b2c: cmp             x1, #0xc66
    // 0x1295b30: b.ne            #0x1295b68
    // 0x1295b34: ldr             x1, [fp, #0x18]
    // 0x1295b38: LoadField: r2 = r0->field_7
    //     0x1295b38: ldur            w2, [x0, #7]
    // 0x1295b3c: DecompressPointer r2
    //     0x1295b3c: add             x2, x2, HEAP, lsl #32
    // 0x1295b40: LoadField: r0 = r1->field_7
    //     0x1295b40: ldur            w0, [x1, #7]
    // 0x1295b44: DecompressPointer r0
    //     0x1295b44: add             x0, x0, HEAP, lsl #32
    // 0x1295b48: r1 = LoadClassIdInstr(r2)
    //     0x1295b48: ldur            x1, [x2, #-1]
    //     0x1295b4c: ubfx            x1, x1, #0xc, #0x14
    // 0x1295b50: stp             x0, x2, [SP]
    // 0x1295b54: mov             x0, x1
    // 0x1295b58: mov             lr, x0
    // 0x1295b5c: ldr             lr, [x21, lr, lsl #3]
    // 0x1295b60: blr             lr
    // 0x1295b64: b               #0x1295b6c
    // 0x1295b68: r0 = false
    //     0x1295b68: add             x0, NULL, #0x30  ; false
    // 0x1295b6c: LeaveFrame
    //     0x1295b6c: mov             SP, fp
    //     0x1295b70: ldp             fp, lr, [SP], #0x10
    // 0x1295b74: ret
    //     0x1295b74: ret             
    // 0x1295b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1295b78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1295b7c: b               #0x1295abc
  }
}
