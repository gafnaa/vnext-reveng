// lib: , url: package:flutter/src/gestures/drag.dart

// class id: 1048818, size: 0x8
class :: {
}

// class id: 3176, size: 0x8, field offset: 0x8
abstract class Drag extends Object {
}
