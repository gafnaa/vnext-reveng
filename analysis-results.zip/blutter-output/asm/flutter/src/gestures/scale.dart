// lib: , url: package:flutter/src/gestures/scale.dart

// class id: 1048833, size: 0x8
class :: {

  static _ _isFlingGesture(/* No info */) {
    // ** addr: 0xadf0dc, size: 0x38
    // 0xadf0dc: d0 = 2500.000000
    //     0xadf0dc: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fd08] IMM: double(2500) from 0x40a3880000000000
    //     0xadf0e0: ldr             d0, [x17, #0xd08]
    // 0xadf0e4: LoadField: r2 = r1->field_7
    //     0xadf0e4: ldur            w2, [x1, #7]
    // 0xadf0e8: DecompressPointer r2
    //     0xadf0e8: add             x2, x2, HEAP, lsl #32
    // 0xadf0ec: LoadField: d1 = r2->field_7
    //     0xadf0ec: ldur            d1, [x2, #7]
    // 0xadf0f0: fmul            d2, d1, d1
    // 0xadf0f4: LoadField: d1 = r2->field_f
    //     0xadf0f4: ldur            d1, [x2, #0xf]
    // 0xadf0f8: fmul            d3, d1, d1
    // 0xadf0fc: fadd            d1, d2, d3
    // 0xadf100: fcmp            d1, d0
    // 0xadf104: r16 = true
    //     0xadf104: add             x16, NULL, #0x20  ; true
    // 0xadf108: r17 = false
    //     0xadf108: add             x17, NULL, #0x30  ; false
    // 0xadf10c: csel            x0, x16, x17, gt
    // 0xadf110: ret
    //     0xadf110: ret             
  }
}

// class id: 3153, size: 0x20, field offset: 0x8
class _LineBetweenPointers extends Object {
}

// class id: 3154, size: 0x24, field offset: 0x8
class _PointerPanZoomData extends Object {

  _ _PointerPanZoomData.fromUpdateEvent(/* No info */) {
    // ** addr: 0xba2ee0, size: 0x120
    // 0xba2ee0: EnterFrame
    //     0xba2ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xba2ee4: mov             fp, SP
    // 0xba2ee8: AllocStack(0x10)
    //     0xba2ee8: sub             SP, SP, #0x10
    // 0xba2eec: SetupParameters(_PointerPanZoomData this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0xba2eec: mov             x0, x2
    //     0xba2ef0: mov             x2, x3
    //     0xba2ef4: stur            x3, [fp, #-0x10]
    //     0xba2ef8: mov             x3, x1
    //     0xba2efc: stur            x1, [fp, #-8]
    // 0xba2f00: CheckStackOverflow
    //     0xba2f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2f04: cmp             SP, x16
    //     0xba2f08: b.ls            #0xba2ff8
    // 0xba2f0c: StoreField: r3->field_7 = r0
    //     0xba2f0c: stur            w0, [x3, #7]
    //     0xba2f10: ldurb           w16, [x3, #-1]
    //     0xba2f14: ldurb           w17, [x0, #-1]
    //     0xba2f18: and             x16, x17, x16, lsr #2
    //     0xba2f1c: tst             x16, HEAP, lsr #32
    //     0xba2f20: b.eq            #0xba2f28
    //     0xba2f24: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba2f28: r0 = LoadClassIdInstr(r2)
    //     0xba2f28: ldur            x0, [x2, #-1]
    //     0xba2f2c: ubfx            x0, x0, #0xc, #0x14
    // 0xba2f30: mov             x1, x2
    // 0xba2f34: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba2f34: mov             x17, #0x3f27
    //     0xba2f38: movk            x17, #1, lsl #16
    //     0xba2f3c: add             lr, x0, x17
    //     0xba2f40: ldr             lr, [x21, lr, lsl #3]
    //     0xba2f44: blr             lr
    // 0xba2f48: ldur            x2, [fp, #-8]
    // 0xba2f4c: StoreField: r2->field_b = r0
    //     0xba2f4c: stur            w0, [x2, #0xb]
    //     0xba2f50: ldurb           w16, [x2, #-1]
    //     0xba2f54: ldurb           w17, [x0, #-1]
    //     0xba2f58: and             x16, x17, x16, lsr #2
    //     0xba2f5c: tst             x16, HEAP, lsr #32
    //     0xba2f60: b.eq            #0xba2f68
    //     0xba2f64: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba2f68: ldur            x3, [fp, #-0x10]
    // 0xba2f6c: r0 = LoadClassIdInstr(r3)
    //     0xba2f6c: ldur            x0, [x3, #-1]
    //     0xba2f70: ubfx            x0, x0, #0xc, #0x14
    // 0xba2f74: mov             x1, x3
    // 0xba2f78: r0 = GDT[cid_x0 + -0xff5]()
    //     0xba2f78: sub             lr, x0, #0xff5
    //     0xba2f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xba2f80: blr             lr
    // 0xba2f84: ldur            x2, [fp, #-8]
    // 0xba2f88: StoreField: r2->field_f = r0
    //     0xba2f88: stur            w0, [x2, #0xf]
    //     0xba2f8c: ldurb           w16, [x2, #-1]
    //     0xba2f90: ldurb           w17, [x0, #-1]
    //     0xba2f94: and             x16, x17, x16, lsr #2
    //     0xba2f98: tst             x16, HEAP, lsr #32
    //     0xba2f9c: b.eq            #0xba2fa4
    //     0xba2fa0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba2fa4: ldur            x3, [fp, #-0x10]
    // 0xba2fa8: r0 = LoadClassIdInstr(r3)
    //     0xba2fa8: ldur            x0, [x3, #-1]
    //     0xba2fac: ubfx            x0, x0, #0xc, #0x14
    // 0xba2fb0: mov             x1, x3
    // 0xba2fb4: r0 = GDT[cid_x0 + 0x624]()
    //     0xba2fb4: add             lr, x0, #0x624
    //     0xba2fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xba2fbc: blr             lr
    // 0xba2fc0: ldur            x2, [fp, #-8]
    // 0xba2fc4: StoreField: r2->field_13 = d0
    //     0xba2fc4: stur            d0, [x2, #0x13]
    // 0xba2fc8: ldur            x1, [fp, #-0x10]
    // 0xba2fcc: r0 = LoadClassIdInstr(r1)
    //     0xba2fcc: ldur            x0, [x1, #-1]
    //     0xba2fd0: ubfx            x0, x0, #0xc, #0x14
    // 0xba2fd4: r0 = GDT[cid_x0 + 0x66c]()
    //     0xba2fd4: add             lr, x0, #0x66c
    //     0xba2fd8: ldr             lr, [x21, lr, lsl #3]
    //     0xba2fdc: blr             lr
    // 0xba2fe0: ldur            x1, [fp, #-8]
    // 0xba2fe4: StoreField: r1->field_1b = d0
    //     0xba2fe4: stur            d0, [x1, #0x1b]
    // 0xba2fe8: r0 = Null
    //     0xba2fe8: mov             x0, NULL
    // 0xba2fec: LeaveFrame
    //     0xba2fec: mov             SP, fp
    //     0xba2ff0: ldp             fp, lr, [SP], #0x10
    // 0xba2ff4: ret
    //     0xba2ff4: ret             
    // 0xba2ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2ff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2ffc: b               #0xba2f0c
  }
  _ _PointerPanZoomData.fromStartEvent(/* No info */) {
    // ** addr: 0xba3000, size: 0xac
    // 0xba3000: EnterFrame
    //     0xba3000: stp             fp, lr, [SP, #-0x10]!
    //     0xba3004: mov             fp, SP
    // 0xba3008: AllocStack(0x8)
    //     0xba3008: sub             SP, SP, #8
    // 0xba300c: SetupParameters(_PointerPanZoomData this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r1 */)
    //     0xba300c: mov             x0, x2
    //     0xba3010: mov             x2, x1
    //     0xba3014: stur            x1, [fp, #-8]
    //     0xba3018: mov             x1, x3
    // 0xba301c: CheckStackOverflow
    //     0xba301c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3020: cmp             SP, x16
    //     0xba3024: b.ls            #0xba30a4
    // 0xba3028: StoreField: r2->field_7 = r0
    //     0xba3028: stur            w0, [x2, #7]
    //     0xba302c: ldurb           w16, [x2, #-1]
    //     0xba3030: ldurb           w17, [x0, #-1]
    //     0xba3034: and             x16, x17, x16, lsr #2
    //     0xba3038: tst             x16, HEAP, lsr #32
    //     0xba303c: b.eq            #0xba3044
    //     0xba3040: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba3044: r0 = LoadClassIdInstr(r1)
    //     0xba3044: ldur            x0, [x1, #-1]
    //     0xba3048: ubfx            x0, x0, #0xc, #0x14
    // 0xba304c: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba304c: mov             x17, #0x3f27
    //     0xba3050: movk            x17, #1, lsl #16
    //     0xba3054: add             lr, x0, x17
    //     0xba3058: ldr             lr, [x21, lr, lsl #3]
    //     0xba305c: blr             lr
    // 0xba3060: ldur            x1, [fp, #-8]
    // 0xba3064: StoreField: r1->field_b = r0
    //     0xba3064: stur            w0, [x1, #0xb]
    //     0xba3068: ldurb           w16, [x1, #-1]
    //     0xba306c: ldurb           w17, [x0, #-1]
    //     0xba3070: and             x16, x17, x16, lsr #2
    //     0xba3074: tst             x16, HEAP, lsr #32
    //     0xba3078: b.eq            #0xba3080
    //     0xba307c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba3080: r2 = Instance_Offset
    //     0xba3080: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xba3084: StoreField: r1->field_f = r2
    //     0xba3084: stur            w2, [x1, #0xf]
    // 0xba3088: d0 = 1.000000
    //     0xba3088: fmov            d0, #1.00000000
    // 0xba308c: StoreField: r1->field_13 = d0
    //     0xba308c: stur            d0, [x1, #0x13]
    // 0xba3090: StoreField: r1->field_1b = rZR
    //     0xba3090: stur            xzr, [x1, #0x1b]
    // 0xba3094: r0 = Null
    //     0xba3094: mov             x0, NULL
    // 0xba3098: LeaveFrame
    //     0xba3098: mov             SP, fp
    //     0xba309c: ldp             fp, lr, [SP], #0x10
    // 0xba30a0: ret
    //     0xba30a0: ret             
    // 0xba30a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba30a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba30a8: b               #0xba3028
  }
}

// class id: 4433, size: 0x98, field offset: 0x24
class ScaleGestureRecognizer extends OneSequenceGestureRecognizer {

  late double _currentSpan; // offset: 0x4c
  late double _initialSpan; // offset: 0x48
  late Offset _initialFocalPoint; // offset: 0x40
  late Offset _localFocalPoint; // offset: 0x60
  late Offset _delta; // offset: 0x7c
  late double _initialVerticalSpan; // offset: 0x58
  late double _currentVerticalSpan; // offset: 0x5c
  late double _initialHorizontalSpan; // offset: 0x50
  late double _currentHorizontalSpan; // offset: 0x54

  [closure] double <anonymous closure>(dynamic, double, double) {
    // ** addr: 0xade914, size: 0x64
    // 0xade914: EnterFrame
    //     0xade914: stp             fp, lr, [SP, #-0x10]!
    //     0xade918: mov             fp, SP
    // 0xade91c: ldr             x1, [fp, #0x18]
    // 0xade920: LoadField: d0 = r1->field_7
    //     0xade920: ldur            d0, [x1, #7]
    // 0xade924: ldr             x1, [fp, #0x10]
    // 0xade928: LoadField: d1 = r1->field_7
    //     0xade928: ldur            d1, [x1, #7]
    // 0xade92c: fadd            d2, d0, d1
    // 0xade930: r0 = inline_Allocate_Double()
    //     0xade930: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xade934: add             x0, x0, #0x10
    //     0xade938: cmp             x1, x0
    //     0xade93c: b.ls            #0xade968
    //     0xade940: str             x0, [THR, #0x60]  ; THR::top
    //     0xade944: sub             x0, x0, #0xf
    //     0xade948: mov             x1, #0xe19c
    //     0xade94c: movk            x1, #3, lsl #16
    //     0xade950: stur            x1, [x0, #-1]
    // 0xade954: dmb             ishst
    // 0xade958: StoreField: r0->field_7 = d2
    //     0xade958: stur            d2, [x0, #7]
    // 0xade95c: LeaveFrame
    //     0xade95c: mov             SP, fp
    //     0xade960: ldp             fp, lr, [SP], #0x10
    // 0xade964: ret
    //     0xade964: ret             
    // 0xade968: SaveReg d2
    //     0xade968: str             q2, [SP, #-0x10]!
    // 0xade96c: r0 = AllocateDouble()
    //     0xade96c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xade970: RestoreReg d2
    //     0xade970: ldr             q2, [SP], #0x10
    // 0xade974: b               #0xade958
  }
  _ _reconfigure(/* No info */) {
    // ** addr: 0xade978, size: 0x4c8
    // 0xade978: EnterFrame
    //     0xade978: stp             fp, lr, [SP, #-0x10]!
    //     0xade97c: mov             fp, SP
    // 0xade980: AllocStack(0x40)
    //     0xade980: sub             SP, SP, #0x40
    // 0xade984: SetupParameters(ScaleGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xade984: stur            x1, [fp, #-8]
    //     0xade988: stur            x2, [fp, #-0x10]
    // 0xade98c: CheckStackOverflow
    //     0xade98c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xade990: cmp             SP, x16
    //     0xade994: b.ls            #0xadee0c
    // 0xade998: r1 = 2
    //     0xade998: mov             x1, #2
    // 0xade99c: r0 = AllocateContext()
    //     0xade99c: bl              #0x13de838  ; AllocateContextStub
    // 0xade9a0: mov             x3, x0
    // 0xade9a4: ldur            x2, [fp, #-8]
    // 0xade9a8: stur            x3, [fp, #-0x20]
    // 0xade9ac: StoreField: r3->field_f = r2
    //     0xade9ac: stur            w2, [x3, #0xf]
    // 0xade9b0: LoadField: r0 = r2->field_43
    //     0xade9b0: ldur            w0, [x2, #0x43]
    // 0xade9b4: DecompressPointer r0
    //     0xade9b4: add             x0, x0, HEAP, lsl #32
    // 0xade9b8: cmp             w0, NULL
    // 0xade9bc: b.eq            #0xadee14
    // 0xade9c0: StoreField: r2->field_3f = r0
    //     0xade9c0: stur            w0, [x2, #0x3f]
    //     0xade9c4: ldurb           w16, [x2, #-1]
    //     0xade9c8: ldurb           w17, [x0, #-1]
    //     0xade9cc: and             x16, x17, x16, lsr #2
    //     0xade9d0: tst             x16, HEAP, lsr #32
    //     0xade9d4: b.eq            #0xade9dc
    //     0xade9d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xade9dc: LoadField: r0 = r2->field_4b
    //     0xade9dc: ldur            w0, [x2, #0x4b]
    // 0xade9e0: DecompressPointer r0
    //     0xade9e0: add             x0, x0, HEAP, lsl #32
    // 0xade9e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xade9e8: cmp             w0, w16
    // 0xade9ec: b.eq            #0xadee18
    // 0xade9f0: StoreField: r2->field_47 = r0
    //     0xade9f0: stur            w0, [x2, #0x47]
    //     0xade9f4: ldurb           w16, [x2, #-1]
    //     0xade9f8: ldurb           w17, [x0, #-1]
    //     0xade9fc: and             x16, x17, x16, lsr #2
    //     0xadea00: tst             x16, HEAP, lsr #32
    //     0xadea04: b.eq            #0xadea0c
    //     0xadea08: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadea0c: LoadField: r0 = r2->field_67
    //     0xadea0c: ldur            w0, [x2, #0x67]
    // 0xadea10: DecompressPointer r0
    //     0xadea10: add             x0, x0, HEAP, lsl #32
    // 0xadea14: StoreField: r2->field_63 = r0
    //     0xadea14: stur            w0, [x2, #0x63]
    //     0xadea18: ldurb           w16, [x2, #-1]
    //     0xadea1c: ldurb           w17, [x0, #-1]
    //     0xadea20: and             x16, x17, x16, lsr #2
    //     0xadea24: tst             x16, HEAP, lsr #32
    //     0xadea28: b.eq            #0xadea30
    //     0xadea2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadea30: LoadField: r0 = r2->field_53
    //     0xadea30: ldur            w0, [x2, #0x53]
    // 0xadea34: DecompressPointer r0
    //     0xadea34: add             x0, x0, HEAP, lsl #32
    // 0xadea38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xadea3c: cmp             w0, w16
    // 0xadea40: b.eq            #0xadee24
    // 0xadea44: StoreField: r2->field_4f = r0
    //     0xadea44: stur            w0, [x2, #0x4f]
    //     0xadea48: ldurb           w16, [x2, #-1]
    //     0xadea4c: ldurb           w17, [x0, #-1]
    //     0xadea50: and             x16, x17, x16, lsr #2
    //     0xadea54: tst             x16, HEAP, lsr #32
    //     0xadea58: b.eq            #0xadea60
    //     0xadea5c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadea60: LoadField: r0 = r2->field_5b
    //     0xadea60: ldur            w0, [x2, #0x5b]
    // 0xadea64: DecompressPointer r0
    //     0xadea64: add             x0, x0, HEAP, lsl #32
    // 0xadea68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xadea6c: cmp             w0, w16
    // 0xadea70: b.eq            #0xadee30
    // 0xadea74: StoreField: r2->field_57 = r0
    //     0xadea74: stur            w0, [x2, #0x57]
    //     0xadea78: ldurb           w16, [x2, #-1]
    //     0xadea7c: ldurb           w17, [x0, #-1]
    //     0xadea80: and             x16, x17, x16, lsr #2
    //     0xadea84: tst             x16, HEAP, lsr #32
    //     0xadea88: b.eq            #0xadea90
    //     0xadea8c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadea90: LoadField: r0 = r2->field_7f
    //     0xadea90: ldur            w0, [x2, #0x7f]
    // 0xadea94: DecompressPointer r0
    //     0xadea94: add             x0, x0, HEAP, lsl #32
    // 0xadea98: stur            x0, [fp, #-0x18]
    // 0xadea9c: LoadField: r1 = r0->field_13
    //     0xadea9c: ldur            w1, [x0, #0x13]
    // 0xadeaa0: r4 = LoadInt32Instr(r1)
    //     0xadeaa0: sbfx            x4, x1, #1, #0x1f
    // 0xadeaa4: asr             x1, x4, #1
    // 0xadeaa8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xadeaa8: ldur            w4, [x0, #0x17]
    // 0xadeaac: r5 = LoadInt32Instr(r4)
    //     0xadeaac: sbfx            x5, x4, #1, #0x1f
    // 0xadeab0: sub             x4, x1, x5
    // 0xadeab4: cbnz            x4, #0xadeacc
    // 0xadeab8: d0 = 1.000000
    //     0xadeab8: fmov            d0, #1.00000000
    // 0xadeabc: StoreField: r2->field_83 = d0
    //     0xadeabc: stur            d0, [x2, #0x83]
    // 0xadeac0: StoreField: r2->field_8b = rZR
    //     0xadeac0: stur            xzr, [x2, #0x8b]
    // 0xadeac4: mov             x3, x2
    // 0xadeac8: b               #0xadeb88
    // 0xadeacc: mov             x1, x2
    // 0xadead0: r0 = _scaleFactor()
    //     0xadead0: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xadead4: ldur            x0, [fp, #-8]
    // 0xadead8: LoadField: r1 = r0->field_47
    //     0xadead8: ldur            w1, [x0, #0x47]
    // 0xadeadc: DecompressPointer r1
    //     0xadeadc: add             x1, x1, HEAP, lsl #32
    // 0xadeae0: LoadField: d1 = r1->field_7
    //     0xadeae0: ldur            d1, [x1, #7]
    // 0xadeae4: d2 = 0.000000
    //     0xadeae4: eor             v2.16b, v2.16b, v2.16b
    // 0xadeae8: fcmp            d1, d2
    // 0xadeaec: b.le            #0xadeb08
    // 0xadeaf0: LoadField: r1 = r0->field_4b
    //     0xadeaf0: ldur            w1, [x0, #0x4b]
    // 0xadeaf4: DecompressPointer r1
    //     0xadeaf4: add             x1, x1, HEAP, lsl #32
    // 0xadeaf8: LoadField: d2 = r1->field_7
    //     0xadeaf8: ldur            d2, [x1, #7]
    // 0xadeafc: fdiv            d3, d2, d1
    // 0xadeb00: mov             v1.16b, v3.16b
    // 0xadeb04: b               #0xadeb0c
    // 0xadeb08: d1 = 1.000000
    //     0xadeb08: fmov            d1, #1.00000000
    // 0xadeb0c: ldur            x2, [fp, #-0x18]
    // 0xadeb10: fdiv            d2, d0, d1
    // 0xadeb14: StoreField: r0->field_83 = d2
    //     0xadeb14: stur            d2, [x0, #0x83]
    // 0xadeb18: r1 = <_PointerPanZoomData>
    //     0xadeb18: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xadeb1c: ldr             x1, [x1, #0xca0]
    // 0xadeb20: r0 = _CompactValuesIterable()
    //     0xadeb20: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xadeb24: mov             x3, x0
    // 0xadeb28: ldur            x0, [fp, #-0x18]
    // 0xadeb2c: stur            x3, [fp, #-0x28]
    // 0xadeb30: StoreField: r3->field_b = r0
    //     0xadeb30: stur            w0, [x3, #0xb]
    // 0xadeb34: r1 = Function '<anonymous closure>':.
    //     0xadeb34: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd10] AnonymousClosure: (0xadf5b4), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xadeb38: ldr             x1, [x1, #0xd10]
    // 0xadeb3c: r2 = Null
    //     0xadeb3c: mov             x2, NULL
    // 0xadeb40: r0 = AllocateClosure()
    //     0xadeb40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xadeb44: r16 = <double>
    //     0xadeb44: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xadeb48: ldur            lr, [fp, #-0x28]
    // 0xadeb4c: stp             lr, x16, [SP, #8]
    // 0xadeb50: str             x0, [SP]
    // 0xadeb54: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xadeb54: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xadeb58: r0 = map()
    //     0xadeb58: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0xadeb5c: r1 = Function '<anonymous closure>':.
    //     0xadeb5c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd18] AnonymousClosure: (0xade914), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xadeb60: ldr             x1, [x1, #0xd18]
    // 0xadeb64: r2 = Null
    //     0xadeb64: mov             x2, NULL
    // 0xadeb68: stur            x0, [fp, #-0x18]
    // 0xadeb6c: r0 = AllocateClosure()
    //     0xadeb6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xadeb70: ldur            x1, [fp, #-0x18]
    // 0xadeb74: mov             x2, x0
    // 0xadeb78: r0 = reduce()
    //     0xadeb78: bl              #0xadf774  ; [dart:core] Iterable::reduce
    // 0xadeb7c: LoadField: d0 = r0->field_7
    //     0xadeb7c: ldur            d0, [x0, #7]
    // 0xadeb80: ldur            x3, [fp, #-8]
    // 0xadeb84: StoreField: r3->field_8b = d0
    //     0xadeb84: stur            d0, [x3, #0x8b]
    // 0xadeb88: LoadField: r0 = r3->field_33
    //     0xadeb88: ldur            w0, [x3, #0x33]
    // 0xadeb8c: DecompressPointer r0
    //     0xadeb8c: add             x0, x0, HEAP, lsl #32
    // 0xadeb90: r16 = Instance__ScaleState
    //     0xadeb90: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cc68] Obj!_ScaleState@12c5b61
    //     0xadeb94: ldr             x16, [x16, #0xc68]
    // 0xadeb98: cmp             w0, w16
    // 0xadeb9c: b.ne            #0xadeda4
    // 0xadeba0: LoadField: r0 = r3->field_2f
    //     0xadeba0: ldur            w0, [x3, #0x2f]
    // 0xadeba4: DecompressPointer r0
    //     0xadeba4: add             x0, x0, HEAP, lsl #32
    // 0xadeba8: cmp             w0, NULL
    // 0xadebac: b.eq            #0xaded34
    // 0xadebb0: ldur            x2, [fp, #-0x10]
    // 0xadebb4: LoadField: r4 = r3->field_73
    //     0xadebb4: ldur            w4, [x3, #0x73]
    // 0xadebb8: DecompressPointer r4
    //     0xadebb8: add             x4, x4, HEAP, lsl #32
    // 0xadebbc: stur            x4, [fp, #-0x18]
    // 0xadebc0: r0 = BoxInt64Instr(r2)
    //     0xadebc0: sbfiz           x0, x2, #1, #0x1f
    //     0xadebc4: cmp             x2, x0, asr #1
    //     0xadebc8: b.eq            #0xadebd4
    //     0xadebcc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xadebd0: stur            x2, [x0, #7]
    // 0xadebd4: mov             x1, x4
    // 0xadebd8: mov             x2, x0
    // 0xadebdc: r0 = _getValueOrData()
    //     0xadebdc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xadebe0: mov             x1, x0
    // 0xadebe4: ldur            x0, [fp, #-0x18]
    // 0xadebe8: LoadField: r2 = r0->field_f
    //     0xadebe8: ldur            w2, [x0, #0xf]
    // 0xadebec: DecompressPointer r2
    //     0xadebec: add             x2, x2, HEAP, lsl #32
    // 0xadebf0: cmp             w2, w1
    // 0xadebf4: b.ne            #0xadebfc
    // 0xadebf8: r1 = Null
    //     0xadebf8: mov             x1, NULL
    // 0xadebfc: ldur            x2, [fp, #-0x20]
    // 0xadec00: cmp             w1, NULL
    // 0xadec04: b.eq            #0xadee3c
    // 0xadec08: r0 = getVelocity()
    //     0xadec08: bl              #0xadf114  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocity
    // 0xadec0c: mov             x1, x0
    // 0xadec10: ldur            x2, [fp, #-0x20]
    // 0xadec14: StoreField: r2->field_13 = r0
    //     0xadec14: stur            w0, [x2, #0x13]
    //     0xadec18: ldurb           w16, [x2, #-1]
    //     0xadec1c: ldurb           w17, [x0, #-1]
    //     0xadec20: and             x16, x17, x16, lsr #2
    //     0xadec24: tst             x16, HEAP, lsr #32
    //     0xadec28: b.eq            #0xadec30
    //     0xadec2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadec30: r0 = _isFlingGesture()
    //     0xadec30: bl              #0xadf0dc  ; [package:flutter/src/gestures/scale.dart] ::_isFlingGesture
    // 0xadec34: tbnz            w0, #4, #0xaded0c
    // 0xadec38: ldur            x2, [fp, #-0x20]
    // 0xadec3c: LoadField: r0 = r2->field_13
    //     0xadec3c: ldur            w0, [x2, #0x13]
    // 0xadec40: DecompressPointer r0
    //     0xadec40: add             x0, x0, HEAP, lsl #32
    // 0xadec44: LoadField: r3 = r0->field_7
    //     0xadec44: ldur            w3, [x0, #7]
    // 0xadec48: DecompressPointer r3
    //     0xadec48: add             x3, x3, HEAP, lsl #32
    // 0xadec4c: mov             x1, x3
    // 0xadec50: stur            x3, [fp, #-0x18]
    // 0xadec54: r0 = distanceSquared()
    //     0xadec54: bl              #0xadf0c4  ; [dart:ui] Offset::distanceSquared
    // 0xadec58: mov             v1.16b, v0.16b
    // 0xadec5c: d0 = 64000000.000000
    //     0xadec5c: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cd20] IMM: double(6.4e+07) from 0x418e848000000000
    //     0xadec60: ldr             d0, [x17, #0xd20]
    // 0xadec64: fcmp            d1, d0
    // 0xadec68: b.le            #0xadece0
    // 0xadec6c: ldur            x2, [fp, #-0x20]
    // 0xadec70: ldur            x1, [fp, #-0x18]
    // 0xadec74: LoadField: d0 = r1->field_7
    //     0xadec74: ldur            d0, [x1, #7]
    // 0xadec78: fmul            d1, d0, d0
    // 0xadec7c: LoadField: d0 = r1->field_f
    //     0xadec7c: ldur            d0, [x1, #0xf]
    // 0xadec80: fmul            d2, d0, d0
    // 0xadec84: fadd            d0, d1, d2
    // 0xadec88: fsqrt           d1, d0
    // 0xadec8c: mov             v0.16b, v1.16b
    // 0xadec90: r0 = /()
    //     0xadec90: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0xadec94: mov             x1, x0
    // 0xadec98: d0 = 8000.000000
    //     0xadec98: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cd28] IMM: double(8000) from 0x40bf400000000000
    //     0xadec9c: ldr             d0, [x17, #0xd28]
    // 0xadeca0: r0 = *()
    //     0xadeca0: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0xadeca4: stur            x0, [fp, #-0x18]
    // 0xadeca8: r0 = Velocity()
    //     0xadeca8: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xadecac: mov             x1, x0
    // 0xadecb0: ldur            x0, [fp, #-0x18]
    // 0xadecb4: StoreField: r1->field_7 = r0
    //     0xadecb4: stur            w0, [x1, #7]
    // 0xadecb8: mov             x0, x1
    // 0xadecbc: ldur            x2, [fp, #-0x20]
    // 0xadecc0: StoreField: r2->field_13 = r0
    //     0xadecc0: stur            w0, [x2, #0x13]
    //     0xadecc4: ldurb           w16, [x2, #-1]
    //     0xadecc8: ldurb           w17, [x0, #-1]
    //     0xadeccc: and             x16, x17, x16, lsr #2
    //     0xadecd0: tst             x16, HEAP, lsr #32
    //     0xadecd4: b.eq            #0xadecdc
    //     0xadecd8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xadecdc: b               #0xadece4
    // 0xadece0: ldur            x2, [fp, #-0x20]
    // 0xadece4: r1 = Function '<anonymous closure>':.
    //     0xadece4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd30] AnonymousClosure: (0xadf48c), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xadece8: ldr             x1, [x1, #0xd30]
    // 0xadecec: r0 = AllocateClosure()
    //     0xadecec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xadecf0: r16 = <void?>
    //     0xadecf0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xadecf4: ldur            lr, [fp, #-8]
    // 0xadecf8: stp             lr, x16, [SP, #8]
    // 0xadecfc: str             x0, [SP]
    // 0xaded00: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xaded00: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xaded04: r0 = invokeCallback()
    //     0xaded04: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xaded08: b               #0xaded34
    // 0xaded0c: ldur            x2, [fp, #-0x20]
    // 0xaded10: r1 = Function '<anonymous closure>':.
    //     0xaded10: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd38] AnonymousClosure: (0xadf318), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xaded14: ldr             x1, [x1, #0xd38]
    // 0xaded18: r0 = AllocateClosure()
    //     0xaded18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xaded1c: r16 = <void?>
    //     0xaded1c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xaded20: ldur            lr, [fp, #-8]
    // 0xaded24: stp             lr, x16, [SP, #8]
    // 0xaded28: str             x0, [SP]
    // 0xaded2c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xaded2c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xaded30: r0 = invokeCallback()
    //     0xaded30: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xaded34: ldur            x0, [fp, #-8]
    // 0xaded38: r1 = Instance__ScaleState
    //     0xaded38: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc60] Obj!_ScaleState@12c5b41
    //     0xaded3c: ldr             x1, [x1, #0xc60]
    // 0xaded40: StoreField: r0->field_33 = r1
    //     0xaded40: stur            w1, [x0, #0x33]
    // 0xaded44: r0 = VelocityTracker()
    //     0xaded44: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0xaded48: stur            x0, [fp, #-0x18]
    // 0xaded4c: StoreField: r0->field_13 = rZR
    //     0xaded4c: stur            xzr, [x0, #0x13]
    // 0xaded50: r1 = <_PointAtTime?>
    //     0xaded50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0xaded54: ldr             x1, [x1, #0x568]
    // 0xaded58: r2 = 40
    //     0xaded58: mov             x2, #0x28
    // 0xaded5c: r0 = AllocateArray()
    //     0xaded5c: bl              #0x13df928  ; AllocateArrayStub
    // 0xaded60: mov             x1, x0
    // 0xaded64: ldur            x0, [fp, #-0x18]
    // 0xaded68: StoreField: r0->field_f = r1
    //     0xaded68: stur            w1, [x0, #0xf]
    // 0xaded6c: r1 = Instance_PointerDeviceKind
    //     0xaded6c: ldr             x1, [PP, #0x5380]  ; [pp+0x5380] Obj!PointerDeviceKind@12c7b61
    // 0xaded70: StoreField: r0->field_7 = r1
    //     0xaded70: stur            w1, [x0, #7]
    // 0xaded74: ldur            x2, [fp, #-8]
    // 0xaded78: StoreField: r2->field_77 = r0
    //     0xaded78: stur            w0, [x2, #0x77]
    //     0xaded7c: ldurb           w16, [x2, #-1]
    //     0xaded80: ldurb           w17, [x0, #-1]
    //     0xaded84: and             x16, x17, x16, lsr #2
    //     0xaded88: tst             x16, HEAP, lsr #32
    //     0xaded8c: b.eq            #0xaded94
    //     0xaded90: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xaded94: r0 = false
    //     0xaded94: add             x0, NULL, #0x30  ; false
    // 0xaded98: LeaveFrame
    //     0xaded98: mov             SP, fp
    //     0xaded9c: ldp             fp, lr, [SP], #0x10
    // 0xadeda0: ret
    //     0xadeda0: ret             
    // 0xadeda4: mov             x2, x3
    // 0xadeda8: r1 = Instance_PointerDeviceKind
    //     0xadeda8: ldr             x1, [PP, #0x5380]  ; [pp+0x5380] Obj!PointerDeviceKind@12c7b61
    // 0xadedac: r0 = VelocityTracker()
    //     0xadedac: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0xadedb0: stur            x0, [fp, #-0x18]
    // 0xadedb4: StoreField: r0->field_13 = rZR
    //     0xadedb4: stur            xzr, [x0, #0x13]
    // 0xadedb8: r1 = <_PointAtTime?>
    //     0xadedb8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0xadedbc: ldr             x1, [x1, #0x568]
    // 0xadedc0: r2 = 40
    //     0xadedc0: mov             x2, #0x28
    // 0xadedc4: r0 = AllocateArray()
    //     0xadedc4: bl              #0x13df928  ; AllocateArrayStub
    // 0xadedc8: mov             x1, x0
    // 0xadedcc: ldur            x0, [fp, #-0x18]
    // 0xadedd0: StoreField: r0->field_f = r1
    //     0xadedd0: stur            w1, [x0, #0xf]
    // 0xadedd4: r1 = Instance_PointerDeviceKind
    //     0xadedd4: ldr             x1, [PP, #0x5380]  ; [pp+0x5380] Obj!PointerDeviceKind@12c7b61
    // 0xadedd8: StoreField: r0->field_7 = r1
    //     0xadedd8: stur            w1, [x0, #7]
    // 0xadeddc: ldur            x1, [fp, #-8]
    // 0xadede0: StoreField: r1->field_77 = r0
    //     0xadede0: stur            w0, [x1, #0x77]
    //     0xadede4: ldurb           w16, [x1, #-1]
    //     0xadede8: ldurb           w17, [x0, #-1]
    //     0xadedec: and             x16, x17, x16, lsr #2
    //     0xadedf0: tst             x16, HEAP, lsr #32
    //     0xadedf4: b.eq            #0xadedfc
    //     0xadedf8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xadedfc: r0 = true
    //     0xadedfc: add             x0, NULL, #0x20  ; true
    // 0xadee00: LeaveFrame
    //     0xadee00: mov             SP, fp
    //     0xadee04: ldp             fp, lr, [SP], #0x10
    // 0xadee08: ret
    //     0xadee08: ret             
    // 0xadee0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadee0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadee10: b               #0xade998
    // 0xadee14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xadee14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xadee18: r9 = _currentSpan
    //     0xadee18: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc78] Field <ScaleGestureRecognizer._currentSpan@661213599>: late (offset: 0x4c)
    //     0xadee1c: ldr             x9, [x9, #0xc78]
    // 0xadee20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xadee20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xadee24: r9 = _currentHorizontalSpan
    //     0xadee24: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccf0] Field <ScaleGestureRecognizer._currentHorizontalSpan@661213599>: late (offset: 0x54)
    //     0xadee28: ldr             x9, [x9, #0xcf0]
    // 0xadee2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xadee2c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xadee30: r9 = _currentVerticalSpan
    //     0xadee30: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccd0] Field <ScaleGestureRecognizer._currentVerticalSpan@661213599>: late (offset: 0x5c)
    //     0xadee34: ldr             x9, [x9, #0xcd0]
    // 0xadee38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xadee38: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xadee3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xadee3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _scaleFactor(/* No info */) {
    // ** addr: 0xadf19c, size: 0x17c
    // 0xadf19c: EnterFrame
    //     0xadf19c: stp             fp, lr, [SP, #-0x10]!
    //     0xadf1a0: mov             fp, SP
    // 0xadf1a4: AllocStack(0x28)
    //     0xadf1a4: sub             SP, SP, #0x28
    // 0xadf1a8: d0 = 0.000000
    //     0xadf1a8: eor             v0.16b, v0.16b, v0.16b
    // 0xadf1ac: mov             x0, x1
    // 0xadf1b0: stur            x1, [fp, #-0x10]
    // 0xadf1b4: CheckStackOverflow
    //     0xadf1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf1b8: cmp             SP, x16
    //     0xadf1bc: b.ls            #0xadf2f0
    // 0xadf1c0: LoadField: r1 = r0->field_47
    //     0xadf1c0: ldur            w1, [x0, #0x47]
    // 0xadf1c4: DecompressPointer r1
    //     0xadf1c4: add             x1, x1, HEAP, lsl #32
    // 0xadf1c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xadf1cc: cmp             w1, w16
    // 0xadf1d0: b.eq            #0xadf2f8
    // 0xadf1d4: LoadField: d1 = r1->field_7
    //     0xadf1d4: ldur            d1, [x1, #7]
    // 0xadf1d8: fcmp            d1, d0
    // 0xadf1dc: b.le            #0xadf204
    // 0xadf1e0: LoadField: r1 = r0->field_4b
    //     0xadf1e0: ldur            w1, [x0, #0x4b]
    // 0xadf1e4: DecompressPointer r1
    //     0xadf1e4: add             x1, x1, HEAP, lsl #32
    // 0xadf1e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xadf1ec: cmp             w1, w16
    // 0xadf1f0: b.eq            #0xadf304
    // 0xadf1f4: LoadField: d0 = r1->field_7
    //     0xadf1f4: ldur            d0, [x1, #7]
    // 0xadf1f8: fdiv            d2, d0, d1
    // 0xadf1fc: mov             v0.16b, v2.16b
    // 0xadf200: b               #0xadf208
    // 0xadf204: d0 = 1.000000
    //     0xadf204: fmov            d0, #1.00000000
    // 0xadf208: stur            d0, [fp, #-0x28]
    // 0xadf20c: LoadField: r2 = r0->field_7f
    //     0xadf20c: ldur            w2, [x0, #0x7f]
    // 0xadf210: DecompressPointer r2
    //     0xadf210: add             x2, x2, HEAP, lsl #32
    // 0xadf214: stur            x2, [fp, #-8]
    // 0xadf218: r1 = <_PointerPanZoomData>
    //     0xadf218: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xadf21c: ldr             x1, [x1, #0xca0]
    // 0xadf220: r0 = _CompactValuesIterable()
    //     0xadf220: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xadf224: mov             x1, x0
    // 0xadf228: ldur            x0, [fp, #-8]
    // 0xadf22c: StoreField: r1->field_b = r0
    //     0xadf22c: stur            w0, [x1, #0xb]
    // 0xadf230: r0 = iterator()
    //     0xadf230: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xadf234: stur            x0, [fp, #-0x18]
    // 0xadf238: LoadField: r2 = r0->field_7
    //     0xadf238: ldur            w2, [x0, #7]
    // 0xadf23c: DecompressPointer r2
    //     0xadf23c: add             x2, x2, HEAP, lsl #32
    // 0xadf240: stur            x2, [fp, #-8]
    // 0xadf244: ldur            d0, [fp, #-0x28]
    // 0xadf248: ldur            x3, [fp, #-0x10]
    // 0xadf24c: stur            d0, [fp, #-0x28]
    // 0xadf250: CheckStackOverflow
    //     0xadf250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf254: cmp             SP, x16
    //     0xadf258: b.ls            #0xadf310
    // 0xadf25c: mov             x1, x0
    // 0xadf260: r0 = moveNext()
    //     0xadf260: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xadf264: tbnz            w0, #4, #0xadf2e0
    // 0xadf268: ldur            x3, [fp, #-0x18]
    // 0xadf26c: LoadField: r4 = r3->field_33
    //     0xadf26c: ldur            w4, [x3, #0x33]
    // 0xadf270: DecompressPointer r4
    //     0xadf270: add             x4, x4, HEAP, lsl #32
    // 0xadf274: stur            x4, [fp, #-0x20]
    // 0xadf278: cmp             w4, NULL
    // 0xadf27c: b.ne            #0xadf2b0
    // 0xadf280: mov             x0, x4
    // 0xadf284: ldur            x2, [fp, #-8]
    // 0xadf288: r1 = Null
    //     0xadf288: mov             x1, NULL
    // 0xadf28c: cmp             w2, NULL
    // 0xadf290: b.eq            #0xadf2b0
    // 0xadf294: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xadf294: ldur            w4, [x2, #0x17]
    // 0xadf298: DecompressPointer r4
    //     0xadf298: add             x4, x4, HEAP, lsl #32
    // 0xadf29c: r8 = X0
    //     0xadf29c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xadf2a0: LoadField: r9 = r4->field_7
    //     0xadf2a0: ldur            x9, [x4, #7]
    // 0xadf2a4: r3 = Null
    //     0xadf2a4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cd00] Null
    //     0xadf2a8: ldr             x3, [x3, #0xd00]
    // 0xadf2ac: blr             x9
    // 0xadf2b0: ldur            x1, [fp, #-0x10]
    // 0xadf2b4: ldur            d0, [fp, #-0x28]
    // 0xadf2b8: ldur            x0, [fp, #-0x20]
    // 0xadf2bc: LoadField: d1 = r0->field_13
    //     0xadf2bc: ldur            d1, [x0, #0x13]
    // 0xadf2c0: LoadField: d2 = r1->field_83
    //     0xadf2c0: ldur            d2, [x1, #0x83]
    // 0xadf2c4: fdiv            d3, d1, d2
    // 0xadf2c8: fmul            d1, d0, d3
    // 0xadf2cc: mov             v0.16b, v1.16b
    // 0xadf2d0: mov             x3, x1
    // 0xadf2d4: ldur            x0, [fp, #-0x18]
    // 0xadf2d8: ldur            x2, [fp, #-8]
    // 0xadf2dc: b               #0xadf24c
    // 0xadf2e0: ldur            d0, [fp, #-0x28]
    // 0xadf2e4: LeaveFrame
    //     0xadf2e4: mov             SP, fp
    //     0xadf2e8: ldp             fp, lr, [SP], #0x10
    // 0xadf2ec: ret
    //     0xadf2ec: ret             
    // 0xadf2f0: r0 = StackOverflowSharedWithFPURegs()
    //     0xadf2f0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xadf2f4: b               #0xadf1c0
    // 0xadf2f8: r9 = _initialSpan
    //     0xadf2f8: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc80] Field <ScaleGestureRecognizer._initialSpan@661213599>: late (offset: 0x48)
    //     0xadf2fc: ldr             x9, [x9, #0xc80]
    // 0xadf300: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xadf300: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xadf304: r9 = _currentSpan
    //     0xadf304: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc78] Field <ScaleGestureRecognizer._currentSpan@661213599>: late (offset: 0x4c)
    //     0xadf308: ldr             x9, [x9, #0xc78]
    // 0xadf30c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xadf30c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xadf310: r0 = StackOverflowSharedWithFPURegs()
    //     0xadf310: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xadf314: b               #0xadf25c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xadf318, size: 0x11c
    // 0xadf318: EnterFrame
    //     0xadf318: stp             fp, lr, [SP, #-0x10]!
    //     0xadf31c: mov             fp, SP
    // 0xadf320: AllocStack(0x28)
    //     0xadf320: sub             SP, SP, #0x28
    // 0xadf324: SetupParameters([dynamic _ /* r0 */])
    //     0xadf324: ldr             x0, [fp, #0x10]
    //     0xadf328: ldur            w2, [x0, #0x17]
    //     0xadf32c: add             x2, x2, HEAP, lsl #32
    //     0xadf330: stur            x2, [fp, #-0x10]
    // 0xadf334: CheckStackOverflow
    //     0xadf334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf338: cmp             SP, x16
    //     0xadf33c: b.ls            #0xadf418
    // 0xadf340: LoadField: r0 = r2->field_f
    //     0xadf340: ldur            w0, [x2, #0xf]
    // 0xadf344: DecompressPointer r0
    //     0xadf344: add             x0, x0, HEAP, lsl #32
    // 0xadf348: LoadField: r3 = r0->field_2f
    //     0xadf348: ldur            w3, [x0, #0x2f]
    // 0xadf34c: DecompressPointer r3
    //     0xadf34c: add             x3, x3, HEAP, lsl #32
    // 0xadf350: stur            x3, [fp, #-8]
    // 0xadf354: cmp             w3, NULL
    // 0xadf358: b.eq            #0xadf420
    // 0xadf35c: LoadField: r1 = r0->field_77
    //     0xadf35c: ldur            w1, [x0, #0x77]
    // 0xadf360: DecompressPointer r1
    //     0xadf360: add             x1, x1, HEAP, lsl #32
    // 0xadf364: cmp             w1, NULL
    // 0xadf368: b.ne            #0xadf374
    // 0xadf36c: r0 = Null
    //     0xadf36c: mov             x0, NULL
    // 0xadf370: b               #0xadf3b0
    // 0xadf374: r0 = getVelocity()
    //     0xadf374: bl              #0xadf114  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocity
    // 0xadf378: LoadField: r1 = r0->field_7
    //     0xadf378: ldur            w1, [x0, #7]
    // 0xadf37c: DecompressPointer r1
    //     0xadf37c: add             x1, x1, HEAP, lsl #32
    // 0xadf380: LoadField: d0 = r1->field_7
    //     0xadf380: ldur            d0, [x1, #7]
    // 0xadf384: r0 = inline_Allocate_Double()
    //     0xadf384: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xadf388: add             x0, x0, #0x10
    //     0xadf38c: cmp             x1, x0
    //     0xadf390: b.ls            #0xadf424
    //     0xadf394: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf398: sub             x0, x0, #0xf
    //     0xadf39c: mov             x1, #0xe19c
    //     0xadf3a0: movk            x1, #3, lsl #16
    //     0xadf3a4: stur            x1, [x0, #-1]
    // 0xadf3a8: dmb             ishst
    // 0xadf3ac: StoreField: r0->field_7 = d0
    //     0xadf3ac: stur            d0, [x0, #7]
    // 0xadf3b0: cmp             w0, NULL
    // 0xadf3b4: b.ne            #0xadf3c0
    // 0xadf3b8: d0 = -1.000000
    //     0xadf3b8: fmov            d0, #-1.00000000
    // 0xadf3bc: b               #0xadf3c4
    // 0xadf3c0: LoadField: d0 = r0->field_7
    //     0xadf3c0: ldur            d0, [x0, #7]
    // 0xadf3c4: ldur            x0, [fp, #-0x10]
    // 0xadf3c8: stur            d0, [fp, #-0x18]
    // 0xadf3cc: LoadField: r1 = r0->field_f
    //     0xadf3cc: ldur            w1, [x0, #0xf]
    // 0xadf3d0: DecompressPointer r1
    //     0xadf3d0: add             x1, x1, HEAP, lsl #32
    // 0xadf3d4: r0 = pointerCount()
    //     0xadf3d4: bl              #0xadf440  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::pointerCount
    // 0xadf3d8: r0 = ScaleEndDetails()
    //     0xadf3d8: bl              #0xadf434  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0xadf3dc: mov             x1, x0
    // 0xadf3e0: r0 = Instance_Velocity
    //     0xadf3e0: add             x0, PP, #0x80, lsl #12  ; [pp+0x80bb8] Obj!Velocity@129f141
    //     0xadf3e4: ldr             x0, [x0, #0xbb8]
    // 0xadf3e8: StoreField: r1->field_7 = r0
    //     0xadf3e8: stur            w0, [x1, #7]
    // 0xadf3ec: ldur            d0, [fp, #-0x18]
    // 0xadf3f0: StoreField: r1->field_b = d0
    //     0xadf3f0: stur            d0, [x1, #0xb]
    // 0xadf3f4: ldur            x16, [fp, #-8]
    // 0xadf3f8: stp             x1, x16, [SP]
    // 0xadf3fc: ldur            x0, [fp, #-8]
    // 0xadf400: ClosureCall
    //     0xadf400: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xadf404: ldur            x2, [x0, #0x1f]
    //     0xadf408: blr             x2
    // 0xadf40c: LeaveFrame
    //     0xadf40c: mov             SP, fp
    //     0xadf410: ldp             fp, lr, [SP], #0x10
    // 0xadf414: ret
    //     0xadf414: ret             
    // 0xadf418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf41c: b               #0xadf340
    // 0xadf420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xadf420: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xadf424: SaveReg d0
    //     0xadf424: str             q0, [SP, #-0x10]!
    // 0xadf428: r0 = AllocateDouble()
    //     0xadf428: bl              #0x13df878  ; AllocateDoubleStub
    // 0xadf42c: RestoreReg d0
    //     0xadf42c: ldr             q0, [SP], #0x10
    // 0xadf430: b               #0xadf3ac
  }
  get _ pointerCount(/* No info */) {
    // ** addr: 0xadf440, size: 0x4c
    // 0xadf440: EnterFrame
    //     0xadf440: stp             fp, lr, [SP, #-0x10]!
    //     0xadf444: mov             fp, SP
    // 0xadf448: LoadField: r2 = r1->field_7f
    //     0xadf448: ldur            w2, [x1, #0x7f]
    // 0xadf44c: DecompressPointer r2
    //     0xadf44c: add             x2, x2, HEAP, lsl #32
    // 0xadf450: LoadField: r3 = r2->field_13
    //     0xadf450: ldur            w3, [x2, #0x13]
    // 0xadf454: r4 = LoadInt32Instr(r3)
    //     0xadf454: sbfx            x4, x3, #1, #0x1f
    // 0xadf458: asr             x3, x4, #1
    // 0xadf45c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xadf45c: ldur            w4, [x2, #0x17]
    // 0xadf460: r2 = LoadInt32Instr(r4)
    //     0xadf460: sbfx            x2, x4, #1, #0x1f
    // 0xadf464: sub             x4, x3, x2
    // 0xadf468: lsl             x2, x4, #1
    // 0xadf46c: LoadField: r3 = r1->field_6f
    //     0xadf46c: ldur            w3, [x1, #0x6f]
    // 0xadf470: DecompressPointer r3
    //     0xadf470: add             x3, x3, HEAP, lsl #32
    // 0xadf474: LoadField: r1 = r3->field_b
    //     0xadf474: ldur            w1, [x3, #0xb]
    // 0xadf478: r3 = LoadInt32Instr(r1)
    //     0xadf478: sbfx            x3, x1, #1, #0x1f
    // 0xadf47c: add             x0, x2, x3
    // 0xadf480: LeaveFrame
    //     0xadf480: mov             SP, fp
    //     0xadf484: ldp             fp, lr, [SP], #0x10
    // 0xadf488: ret
    //     0xadf488: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xadf48c, size: 0x128
    // 0xadf48c: EnterFrame
    //     0xadf48c: stp             fp, lr, [SP, #-0x10]!
    //     0xadf490: mov             fp, SP
    // 0xadf494: AllocStack(0x30)
    //     0xadf494: sub             SP, SP, #0x30
    // 0xadf498: SetupParameters([dynamic _ /* r0 */])
    //     0xadf498: ldr             x0, [fp, #0x10]
    //     0xadf49c: ldur            w2, [x0, #0x17]
    //     0xadf4a0: add             x2, x2, HEAP, lsl #32
    //     0xadf4a4: stur            x2, [fp, #-0x18]
    // 0xadf4a8: CheckStackOverflow
    //     0xadf4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf4ac: cmp             SP, x16
    //     0xadf4b0: b.ls            #0xadf598
    // 0xadf4b4: LoadField: r0 = r2->field_f
    //     0xadf4b4: ldur            w0, [x2, #0xf]
    // 0xadf4b8: DecompressPointer r0
    //     0xadf4b8: add             x0, x0, HEAP, lsl #32
    // 0xadf4bc: LoadField: r3 = r0->field_2f
    //     0xadf4bc: ldur            w3, [x0, #0x2f]
    // 0xadf4c0: DecompressPointer r3
    //     0xadf4c0: add             x3, x3, HEAP, lsl #32
    // 0xadf4c4: stur            x3, [fp, #-0x10]
    // 0xadf4c8: cmp             w3, NULL
    // 0xadf4cc: b.eq            #0xadf5a0
    // 0xadf4d0: LoadField: r4 = r2->field_13
    //     0xadf4d0: ldur            w4, [x2, #0x13]
    // 0xadf4d4: DecompressPointer r4
    //     0xadf4d4: add             x4, x4, HEAP, lsl #32
    // 0xadf4d8: stur            x4, [fp, #-8]
    // 0xadf4dc: LoadField: r1 = r0->field_77
    //     0xadf4dc: ldur            w1, [x0, #0x77]
    // 0xadf4e0: DecompressPointer r1
    //     0xadf4e0: add             x1, x1, HEAP, lsl #32
    // 0xadf4e4: cmp             w1, NULL
    // 0xadf4e8: b.ne            #0xadf4f4
    // 0xadf4ec: r0 = Null
    //     0xadf4ec: mov             x0, NULL
    // 0xadf4f0: b               #0xadf530
    // 0xadf4f4: r0 = getVelocity()
    //     0xadf4f4: bl              #0xadf114  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocity
    // 0xadf4f8: LoadField: r1 = r0->field_7
    //     0xadf4f8: ldur            w1, [x0, #7]
    // 0xadf4fc: DecompressPointer r1
    //     0xadf4fc: add             x1, x1, HEAP, lsl #32
    // 0xadf500: LoadField: d0 = r1->field_7
    //     0xadf500: ldur            d0, [x1, #7]
    // 0xadf504: r0 = inline_Allocate_Double()
    //     0xadf504: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xadf508: add             x0, x0, #0x10
    //     0xadf50c: cmp             x1, x0
    //     0xadf510: b.ls            #0xadf5a4
    //     0xadf514: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf518: sub             x0, x0, #0xf
    //     0xadf51c: mov             x1, #0xe19c
    //     0xadf520: movk            x1, #3, lsl #16
    //     0xadf524: stur            x1, [x0, #-1]
    // 0xadf528: dmb             ishst
    // 0xadf52c: StoreField: r0->field_7 = d0
    //     0xadf52c: stur            d0, [x0, #7]
    // 0xadf530: cmp             w0, NULL
    // 0xadf534: b.ne            #0xadf540
    // 0xadf538: d0 = -1.000000
    //     0xadf538: fmov            d0, #-1.00000000
    // 0xadf53c: b               #0xadf544
    // 0xadf540: LoadField: d0 = r0->field_7
    //     0xadf540: ldur            d0, [x0, #7]
    // 0xadf544: ldur            x0, [fp, #-0x18]
    // 0xadf548: ldur            x2, [fp, #-8]
    // 0xadf54c: stur            d0, [fp, #-0x20]
    // 0xadf550: LoadField: r1 = r0->field_f
    //     0xadf550: ldur            w1, [x0, #0xf]
    // 0xadf554: DecompressPointer r1
    //     0xadf554: add             x1, x1, HEAP, lsl #32
    // 0xadf558: r0 = pointerCount()
    //     0xadf558: bl              #0xadf440  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::pointerCount
    // 0xadf55c: r0 = ScaleEndDetails()
    //     0xadf55c: bl              #0xadf434  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0xadf560: mov             x1, x0
    // 0xadf564: ldur            x0, [fp, #-8]
    // 0xadf568: StoreField: r1->field_7 = r0
    //     0xadf568: stur            w0, [x1, #7]
    // 0xadf56c: ldur            d0, [fp, #-0x20]
    // 0xadf570: StoreField: r1->field_b = d0
    //     0xadf570: stur            d0, [x1, #0xb]
    // 0xadf574: ldur            x16, [fp, #-0x10]
    // 0xadf578: stp             x1, x16, [SP]
    // 0xadf57c: ldur            x0, [fp, #-0x10]
    // 0xadf580: ClosureCall
    //     0xadf580: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xadf584: ldur            x2, [x0, #0x1f]
    //     0xadf588: blr             x2
    // 0xadf58c: LeaveFrame
    //     0xadf58c: mov             SP, fp
    //     0xadf590: ldp             fp, lr, [SP], #0x10
    // 0xadf594: ret
    //     0xadf594: ret             
    // 0xadf598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf59c: b               #0xadf4b4
    // 0xadf5a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xadf5a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xadf5a4: SaveReg d0
    //     0xadf5a4: str             q0, [SP, #-0x10]!
    // 0xadf5a8: r0 = AllocateDouble()
    //     0xadf5a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xadf5ac: RestoreReg d0
    //     0xadf5ac: ldr             q0, [SP], #0x10
    // 0xadf5b0: b               #0xadf52c
  }
  [closure] double <anonymous closure>(dynamic, _PointerPanZoomData) {
    // ** addr: 0xadf5b4, size: 0x58
    // 0xadf5b4: EnterFrame
    //     0xadf5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xadf5b8: mov             fp, SP
    // 0xadf5bc: ldr             x1, [fp, #0x10]
    // 0xadf5c0: LoadField: d0 = r1->field_1b
    //     0xadf5c0: ldur            d0, [x1, #0x1b]
    // 0xadf5c4: r0 = inline_Allocate_Double()
    //     0xadf5c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xadf5c8: add             x0, x0, #0x10
    //     0xadf5cc: cmp             x1, x0
    //     0xadf5d0: b.ls            #0xadf5fc
    //     0xadf5d4: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf5d8: sub             x0, x0, #0xf
    //     0xadf5dc: mov             x1, #0xe19c
    //     0xadf5e0: movk            x1, #3, lsl #16
    //     0xadf5e4: stur            x1, [x0, #-1]
    // 0xadf5e8: dmb             ishst
    // 0xadf5ec: StoreField: r0->field_7 = d0
    //     0xadf5ec: stur            d0, [x0, #7]
    // 0xadf5f0: LeaveFrame
    //     0xadf5f0: mov             SP, fp
    //     0xadf5f4: ldp             fp, lr, [SP], #0x10
    // 0xadf5f8: ret
    //     0xadf5f8: ret             
    // 0xadf5fc: SaveReg d0
    //     0xadf5fc: str             q0, [SP, #-0x10]!
    // 0xadf600: r0 = AllocateDouble()
    //     0xadf600: bl              #0x13df878  ; AllocateDoubleStub
    // 0xadf604: RestoreReg d0
    //     0xadf604: ldr             q0, [SP], #0x10
    // 0xadf608: b               #0xadf5ec
  }
  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0xb9987c, size: 0x84
    // 0xb9987c: EnterFrame
    //     0xb9987c: stp             fp, lr, [SP, #-0x10]!
    //     0xb99880: mov             fp, SP
    // 0xb99884: AllocStack(0x8)
    //     0xb99884: sub             SP, SP, #8
    // 0xb99888: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb99888: mov             x0, x1
    //     0xb9988c: stur            x1, [fp, #-8]
    // 0xb99890: CheckStackOverflow
    //     0xb99890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb99894: cmp             SP, x16
    //     0xb99898: b.ls            #0xb998f8
    // 0xb9989c: LoadField: r1 = r0->field_33
    //     0xb9989c: ldur            w1, [x0, #0x33]
    // 0xb998a0: DecompressPointer r1
    //     0xb998a0: add             x1, x1, HEAP, lsl #32
    // 0xb998a4: LoadField: r2 = r1->field_7
    //     0xb998a4: ldur            x2, [x1, #7]
    // 0xb998a8: cmp             x2, #1
    // 0xb998ac: b.gt            #0xb998d8
    // 0xb998b0: cmp             x2, #0
    // 0xb998b4: b.gt            #0xb998c0
    // 0xb998b8: mov             x1, x0
    // 0xb998bc: b               #0xb998dc
    // 0xb998c0: mov             x1, x0
    // 0xb998c4: r2 = Instance_GestureDisposition
    //     0xb998c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb998c8: ldr             x2, [x2, #0x610]
    // 0xb998cc: r0 = resolve()
    //     0xb998cc: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb998d0: ldur            x1, [fp, #-8]
    // 0xb998d4: b               #0xb998dc
    // 0xb998d8: ldur            x1, [fp, #-8]
    // 0xb998dc: r2 = Instance__ScaleState
    //     0xb998dc: add             x2, PP, #0x84, lsl #12  ; [pp+0x84e10] Obj!_ScaleState@12c5b81
    //     0xb998e0: ldr             x2, [x2, #0xe10]
    // 0xb998e4: StoreField: r1->field_33 = r2
    //     0xb998e4: stur            w2, [x1, #0x33]
    // 0xb998e8: r0 = Null
    //     0xb998e8: mov             x0, NULL
    // 0xb998ec: LeaveFrame
    //     0xb998ec: mov             SP, fp
    //     0xb998f0: ldp             fp, lr, [SP], #0x10
    // 0xb998f4: ret
    //     0xb998f4: ret             
    // 0xb998f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb998f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb998fc: b               #0xb9989c
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xba09b4, size: 0x24
    // 0xba09b4: EnterFrame
    //     0xba09b4: stp             fp, lr, [SP, #-0x10]!
    //     0xba09b8: mov             fp, SP
    // 0xba09bc: ldr             x2, [fp, #0x10]
    // 0xba09c0: r1 = Function 'handleEvent':.
    //     0xba09c0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc48] AnonymousClosure: (0xba09d8), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::handleEvent (0xba0a14)
    //     0xba09c4: ldr             x1, [x1, #0xc48]
    // 0xba09c8: r0 = AllocateClosure()
    //     0xba09c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba09cc: LeaveFrame
    //     0xba09cc: mov             SP, fp
    //     0xba09d0: ldp             fp, lr, [SP], #0x10
    // 0xba09d4: ret
    //     0xba09d4: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xba09d8, size: 0x3c
    // 0xba09d8: EnterFrame
    //     0xba09d8: stp             fp, lr, [SP, #-0x10]!
    //     0xba09dc: mov             fp, SP
    // 0xba09e0: ldr             x0, [fp, #0x18]
    // 0xba09e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba09e4: ldur            w1, [x0, #0x17]
    // 0xba09e8: DecompressPointer r1
    //     0xba09e8: add             x1, x1, HEAP, lsl #32
    // 0xba09ec: CheckStackOverflow
    //     0xba09ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba09f0: cmp             SP, x16
    //     0xba09f4: b.ls            #0xba0a0c
    // 0xba09f8: ldr             x2, [fp, #0x10]
    // 0xba09fc: r0 = handleEvent()
    //     0xba09fc: bl              #0xba0a14  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::handleEvent
    // 0xba0a00: LeaveFrame
    //     0xba0a00: mov             SP, fp
    //     0xba0a04: ldp             fp, lr, [SP], #0x10
    // 0xba0a08: ret
    //     0xba0a08: ret             
    // 0xba0a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba0a0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba0a10: b               #0xba09f8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xba0a14, size: 0xa34
    // 0xba0a14: EnterFrame
    //     0xba0a14: stp             fp, lr, [SP, #-0x10]!
    //     0xba0a18: mov             fp, SP
    // 0xba0a1c: AllocStack(0x30)
    //     0xba0a1c: sub             SP, SP, #0x30
    // 0xba0a20: SetupParameters(ScaleGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xba0a20: mov             x4, x1
    //     0xba0a24: mov             x3, x2
    //     0xba0a28: stur            x1, [fp, #-8]
    //     0xba0a2c: stur            x2, [fp, #-0x10]
    // 0xba0a30: CheckStackOverflow
    //     0xba0a30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba0a34: cmp             SP, x16
    //     0xba0a38: b.ls            #0xba1438
    // 0xba0a3c: mov             x0, x3
    // 0xba0a40: r2 = Null
    //     0xba0a40: mov             x2, NULL
    // 0xba0a44: r1 = Null
    //     0xba0a44: mov             x1, NULL
    // 0xba0a48: cmp             w0, NULL
    // 0xba0a4c: b.eq            #0xba0a74
    // 0xba0a50: branchIfSmi(r0, 0xba0a74)
    //     0xba0a50: tbz             w0, #0, #0xba0a74
    // 0xba0a54: r3 = LoadClassIdInstr(r0)
    //     0xba0a54: ldur            x3, [x0, #-1]
    //     0xba0a58: ubfx            x3, x3, #0xc, #0x14
    // 0xba0a5c: r17 = 4157
    //     0xba0a5c: mov             x17, #0x103d
    // 0xba0a60: cmp             x3, x17
    // 0xba0a64: b.eq            #0xba0a7c
    // 0xba0a68: r17 = 5286
    //     0xba0a68: mov             x17, #0x14a6
    // 0xba0a6c: cmp             x3, x17
    // 0xba0a70: b.eq            #0xba0a7c
    // 0xba0a74: r0 = false
    //     0xba0a74: add             x0, NULL, #0x30  ; false
    // 0xba0a78: b               #0xba0a80
    // 0xba0a7c: r0 = true
    //     0xba0a7c: add             x0, NULL, #0x20  ; true
    // 0xba0a80: tbnz            w0, #4, #0xba0c74
    // 0xba0a84: ldur            x3, [fp, #-8]
    // 0xba0a88: ldur            x2, [fp, #-0x10]
    // 0xba0a8c: LoadField: r4 = r3->field_73
    //     0xba0a8c: ldur            w4, [x3, #0x73]
    // 0xba0a90: DecompressPointer r4
    //     0xba0a90: add             x4, x4, HEAP, lsl #32
    // 0xba0a94: stur            x4, [fp, #-0x18]
    // 0xba0a98: r0 = LoadClassIdInstr(r2)
    //     0xba0a98: ldur            x0, [x2, #-1]
    //     0xba0a9c: ubfx            x0, x0, #0xc, #0x14
    // 0xba0aa0: mov             x1, x2
    // 0xba0aa4: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0aa4: sub             lr, x0, #1
    //     0xba0aa8: ldr             lr, [x21, lr, lsl #3]
    //     0xba0aac: blr             lr
    // 0xba0ab0: mov             x2, x0
    // 0xba0ab4: r0 = BoxInt64Instr(r2)
    //     0xba0ab4: sbfiz           x0, x2, #1, #0x1f
    //     0xba0ab8: cmp             x2, x0, asr #1
    //     0xba0abc: b.eq            #0xba0ac8
    //     0xba0ac0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0ac4: stur            x2, [x0, #7]
    // 0xba0ac8: ldur            x1, [fp, #-0x18]
    // 0xba0acc: mov             x2, x0
    // 0xba0ad0: r0 = _getValueOrData()
    //     0xba0ad0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba0ad4: mov             x1, x0
    // 0xba0ad8: ldur            x0, [fp, #-0x18]
    // 0xba0adc: LoadField: r2 = r0->field_f
    //     0xba0adc: ldur            w2, [x0, #0xf]
    // 0xba0ae0: DecompressPointer r2
    //     0xba0ae0: add             x2, x2, HEAP, lsl #32
    // 0xba0ae4: cmp             w2, w1
    // 0xba0ae8: b.ne            #0xba0af4
    // 0xba0aec: r3 = Null
    //     0xba0aec: mov             x3, NULL
    // 0xba0af0: b               #0xba0af8
    // 0xba0af4: mov             x3, x1
    // 0xba0af8: ldur            x2, [fp, #-0x10]
    // 0xba0afc: stur            x3, [fp, #-0x18]
    // 0xba0b00: cmp             w3, NULL
    // 0xba0b04: b.eq            #0xba1440
    // 0xba0b08: r0 = LoadClassIdInstr(r2)
    //     0xba0b08: ldur            x0, [x2, #-1]
    //     0xba0b0c: ubfx            x0, x0, #0xc, #0x14
    // 0xba0b10: mov             x1, x2
    // 0xba0b14: r0 = GDT[cid_x0 + 0x15474]()
    //     0xba0b14: mov             x17, #0x5474
    //     0xba0b18: movk            x17, #1, lsl #16
    //     0xba0b1c: add             lr, x0, x17
    //     0xba0b20: ldr             lr, [x21, lr, lsl #3]
    //     0xba0b24: blr             lr
    // 0xba0b28: tbz             w0, #4, #0xba0ba4
    // 0xba0b2c: ldur            x2, [fp, #-0x10]
    // 0xba0b30: ldur            x3, [fp, #-0x18]
    // 0xba0b34: r0 = LoadClassIdInstr(r2)
    //     0xba0b34: ldur            x0, [x2, #-1]
    //     0xba0b38: ubfx            x0, x0, #0xc, #0x14
    // 0xba0b3c: mov             x1, x2
    // 0xba0b40: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba0b40: mov             x17, #0x5eb5
    //     0xba0b44: movk            x17, #1, lsl #16
    //     0xba0b48: add             lr, x0, x17
    //     0xba0b4c: ldr             lr, [x21, lr, lsl #3]
    //     0xba0b50: blr             lr
    // 0xba0b54: mov             x3, x0
    // 0xba0b58: ldur            x2, [fp, #-0x10]
    // 0xba0b5c: stur            x3, [fp, #-0x20]
    // 0xba0b60: r0 = LoadClassIdInstr(r2)
    //     0xba0b60: ldur            x0, [x2, #-1]
    //     0xba0b64: ubfx            x0, x0, #0xc, #0x14
    // 0xba0b68: mov             x1, x2
    // 0xba0b6c: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba0b6c: mov             x17, #0x3f27
    //     0xba0b70: movk            x17, #1, lsl #16
    //     0xba0b74: add             lr, x0, x17
    //     0xba0b78: ldr             lr, [x21, lr, lsl #3]
    //     0xba0b7c: blr             lr
    // 0xba0b80: ldur            x1, [fp, #-0x18]
    // 0xba0b84: r2 = LoadClassIdInstr(r1)
    //     0xba0b84: ldur            x2, [x1, #-1]
    //     0xba0b88: ubfx            x2, x2, #0xc, #0x14
    // 0xba0b8c: mov             x3, x0
    // 0xba0b90: mov             x0, x2
    // 0xba0b94: ldur            x2, [fp, #-0x20]
    // 0xba0b98: r0 = GDT[cid_x0 + -0xffc]()
    //     0xba0b98: sub             lr, x0, #0xffc
    //     0xba0b9c: ldr             lr, [x21, lr, lsl #3]
    //     0xba0ba0: blr             lr
    // 0xba0ba4: ldur            x3, [fp, #-8]
    // 0xba0ba8: ldur            x2, [fp, #-0x10]
    // 0xba0bac: LoadField: r4 = r3->field_6b
    //     0xba0bac: ldur            w4, [x3, #0x6b]
    // 0xba0bb0: DecompressPointer r4
    //     0xba0bb0: add             x4, x4, HEAP, lsl #32
    // 0xba0bb4: stur            x4, [fp, #-0x18]
    // 0xba0bb8: r0 = LoadClassIdInstr(r2)
    //     0xba0bb8: ldur            x0, [x2, #-1]
    //     0xba0bbc: ubfx            x0, x0, #0xc, #0x14
    // 0xba0bc0: mov             x1, x2
    // 0xba0bc4: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0bc4: sub             lr, x0, #1
    //     0xba0bc8: ldr             lr, [x21, lr, lsl #3]
    //     0xba0bcc: blr             lr
    // 0xba0bd0: mov             x3, x0
    // 0xba0bd4: ldur            x2, [fp, #-0x10]
    // 0xba0bd8: stur            x3, [fp, #-0x28]
    // 0xba0bdc: r0 = LoadClassIdInstr(r2)
    //     0xba0bdc: ldur            x0, [x2, #-1]
    //     0xba0be0: ubfx            x0, x0, #0xc, #0x14
    // 0xba0be4: mov             x1, x2
    // 0xba0be8: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba0be8: mov             x17, #0x3f27
    //     0xba0bec: movk            x17, #1, lsl #16
    //     0xba0bf0: add             lr, x0, x17
    //     0xba0bf4: ldr             lr, [x21, lr, lsl #3]
    //     0xba0bf8: blr             lr
    // 0xba0bfc: mov             x3, x0
    // 0xba0c00: ldur            x2, [fp, #-0x28]
    // 0xba0c04: r0 = BoxInt64Instr(r2)
    //     0xba0c04: sbfiz           x0, x2, #1, #0x1f
    //     0xba0c08: cmp             x2, x0, asr #1
    //     0xba0c0c: b.eq            #0xba0c18
    //     0xba0c10: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0c14: stur            x2, [x0, #7]
    // 0xba0c18: ldur            x1, [fp, #-0x18]
    // 0xba0c1c: mov             x2, x0
    // 0xba0c20: r0 = []=()
    //     0xba0c20: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba0c24: ldur            x2, [fp, #-0x10]
    // 0xba0c28: r0 = LoadClassIdInstr(r2)
    //     0xba0c28: ldur            x0, [x2, #-1]
    //     0xba0c2c: ubfx            x0, x0, #0xc, #0x14
    // 0xba0c30: mov             x1, x2
    // 0xba0c34: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba0c34: mov             x17, #0x5fe3
    //     0xba0c38: movk            x17, #1, lsl #16
    //     0xba0c3c: add             lr, x0, x17
    //     0xba0c40: ldr             lr, [x21, lr, lsl #3]
    //     0xba0c44: blr             lr
    // 0xba0c48: ldur            x3, [fp, #-8]
    // 0xba0c4c: StoreField: r3->field_37 = r0
    //     0xba0c4c: stur            w0, [x3, #0x37]
    //     0xba0c50: ldurb           w16, [x3, #-1]
    //     0xba0c54: ldurb           w17, [x0, #-1]
    //     0xba0c58: and             x16, x17, x16, lsr #2
    //     0xba0c5c: tst             x16, HEAP, lsr #32
    //     0xba0c60: b.eq            #0xba0c68
    //     0xba0c64: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba0c68: r0 = false
    //     0xba0c68: add             x0, NULL, #0x30  ; false
    // 0xba0c6c: r2 = true
    //     0xba0c6c: add             x2, NULL, #0x20  ; true
    // 0xba0c70: b               #0xba13c0
    // 0xba0c74: ldur            x3, [fp, #-8]
    // 0xba0c78: ldur            x0, [fp, #-0x10]
    // 0xba0c7c: r2 = Null
    //     0xba0c7c: mov             x2, NULL
    // 0xba0c80: r1 = Null
    //     0xba0c80: mov             x1, NULL
    // 0xba0c84: cmp             w0, NULL
    // 0xba0c88: b.eq            #0xba0cb0
    // 0xba0c8c: branchIfSmi(r0, 0xba0cb0)
    //     0xba0c8c: tbz             w0, #0, #0xba0cb0
    // 0xba0c90: r3 = LoadClassIdInstr(r0)
    //     0xba0c90: ldur            x3, [x0, #-1]
    //     0xba0c94: ubfx            x3, x3, #0xc, #0x14
    // 0xba0c98: r17 = 4159
    //     0xba0c98: mov             x17, #0x103f
    // 0xba0c9c: cmp             x3, x17
    // 0xba0ca0: b.eq            #0xba0cb8
    // 0xba0ca4: r17 = 5288
    //     0xba0ca4: mov             x17, #0x14a8
    // 0xba0ca8: cmp             x3, x17
    // 0xba0cac: b.eq            #0xba0cb8
    // 0xba0cb0: r0 = false
    //     0xba0cb0: add             x0, NULL, #0x30  ; false
    // 0xba0cb4: b               #0xba0cbc
    // 0xba0cb8: r0 = true
    //     0xba0cb8: add             x0, NULL, #0x20  ; true
    // 0xba0cbc: tbnz            w0, #4, #0xba0e58
    // 0xba0cc0: ldur            x2, [fp, #-8]
    // 0xba0cc4: ldur            x3, [fp, #-0x10]
    // 0xba0cc8: LoadField: r4 = r2->field_6b
    //     0xba0cc8: ldur            w4, [x2, #0x6b]
    // 0xba0ccc: DecompressPointer r4
    //     0xba0ccc: add             x4, x4, HEAP, lsl #32
    // 0xba0cd0: stur            x4, [fp, #-0x18]
    // 0xba0cd4: r0 = LoadClassIdInstr(r3)
    //     0xba0cd4: ldur            x0, [x3, #-1]
    //     0xba0cd8: ubfx            x0, x0, #0xc, #0x14
    // 0xba0cdc: mov             x1, x3
    // 0xba0ce0: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0ce0: sub             lr, x0, #1
    //     0xba0ce4: ldr             lr, [x21, lr, lsl #3]
    //     0xba0ce8: blr             lr
    // 0xba0cec: mov             x3, x0
    // 0xba0cf0: ldur            x2, [fp, #-0x10]
    // 0xba0cf4: stur            x3, [fp, #-0x28]
    // 0xba0cf8: r0 = LoadClassIdInstr(r2)
    //     0xba0cf8: ldur            x0, [x2, #-1]
    //     0xba0cfc: ubfx            x0, x0, #0xc, #0x14
    // 0xba0d00: mov             x1, x2
    // 0xba0d04: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba0d04: mov             x17, #0x3f27
    //     0xba0d08: movk            x17, #1, lsl #16
    //     0xba0d0c: add             lr, x0, x17
    //     0xba0d10: ldr             lr, [x21, lr, lsl #3]
    //     0xba0d14: blr             lr
    // 0xba0d18: mov             x3, x0
    // 0xba0d1c: ldur            x2, [fp, #-0x28]
    // 0xba0d20: r0 = BoxInt64Instr(r2)
    //     0xba0d20: sbfiz           x0, x2, #1, #0x1f
    //     0xba0d24: cmp             x2, x0, asr #1
    //     0xba0d28: b.eq            #0xba0d34
    //     0xba0d2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0d30: stur            x2, [x0, #7]
    // 0xba0d34: ldur            x1, [fp, #-0x18]
    // 0xba0d38: mov             x2, x0
    // 0xba0d3c: r0 = []=()
    //     0xba0d3c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba0d40: ldur            x2, [fp, #-8]
    // 0xba0d44: LoadField: r3 = r2->field_6f
    //     0xba0d44: ldur            w3, [x2, #0x6f]
    // 0xba0d48: DecompressPointer r3
    //     0xba0d48: add             x3, x3, HEAP, lsl #32
    // 0xba0d4c: ldur            x4, [fp, #-0x10]
    // 0xba0d50: stur            x3, [fp, #-0x18]
    // 0xba0d54: r0 = LoadClassIdInstr(r4)
    //     0xba0d54: ldur            x0, [x4, #-1]
    //     0xba0d58: ubfx            x0, x0, #0xc, #0x14
    // 0xba0d5c: mov             x1, x4
    // 0xba0d60: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0d60: sub             lr, x0, #1
    //     0xba0d64: ldr             lr, [x21, lr, lsl #3]
    //     0xba0d68: blr             lr
    // 0xba0d6c: mov             x2, x0
    // 0xba0d70: ldur            x0, [fp, #-0x18]
    // 0xba0d74: stur            x2, [fp, #-0x30]
    // 0xba0d78: LoadField: r1 = r0->field_b
    //     0xba0d78: ldur            w1, [x0, #0xb]
    // 0xba0d7c: LoadField: r3 = r0->field_f
    //     0xba0d7c: ldur            w3, [x0, #0xf]
    // 0xba0d80: DecompressPointer r3
    //     0xba0d80: add             x3, x3, HEAP, lsl #32
    // 0xba0d84: LoadField: r4 = r3->field_b
    //     0xba0d84: ldur            w4, [x3, #0xb]
    // 0xba0d88: r3 = LoadInt32Instr(r1)
    //     0xba0d88: sbfx            x3, x1, #1, #0x1f
    // 0xba0d8c: stur            x3, [fp, #-0x28]
    // 0xba0d90: r1 = LoadInt32Instr(r4)
    //     0xba0d90: sbfx            x1, x4, #1, #0x1f
    // 0xba0d94: cmp             x3, x1
    // 0xba0d98: b.ne            #0xba0da4
    // 0xba0d9c: mov             x1, x0
    // 0xba0da0: r0 = _growToNextCapacity()
    //     0xba0da0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xba0da4: ldur            x4, [fp, #-8]
    // 0xba0da8: ldur            x5, [fp, #-0x10]
    // 0xba0dac: ldur            x0, [fp, #-0x18]
    // 0xba0db0: ldur            x2, [fp, #-0x30]
    // 0xba0db4: ldur            x3, [fp, #-0x28]
    // 0xba0db8: add             x1, x3, #1
    // 0xba0dbc: lsl             x6, x1, #1
    // 0xba0dc0: StoreField: r0->field_b = r6
    //     0xba0dc0: stur            w6, [x0, #0xb]
    // 0xba0dc4: LoadField: r6 = r0->field_f
    //     0xba0dc4: ldur            w6, [x0, #0xf]
    // 0xba0dc8: DecompressPointer r6
    //     0xba0dc8: add             x6, x6, HEAP, lsl #32
    // 0xba0dcc: r0 = BoxInt64Instr(r2)
    //     0xba0dcc: sbfiz           x0, x2, #1, #0x1f
    //     0xba0dd0: cmp             x2, x0, asr #1
    //     0xba0dd4: b.eq            #0xba0de0
    //     0xba0dd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0ddc: stur            x2, [x0, #7]
    // 0xba0de0: mov             x1, x6
    // 0xba0de4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xba0de4: add             x25, x1, x3, lsl #2
    //     0xba0de8: add             x25, x25, #0xf
    //     0xba0dec: str             w0, [x25]
    //     0xba0df0: tbz             w0, #0, #0xba0e0c
    //     0xba0df4: ldurb           w16, [x1, #-1]
    //     0xba0df8: ldurb           w17, [x0, #-1]
    //     0xba0dfc: and             x16, x17, x16, lsr #2
    //     0xba0e00: tst             x16, HEAP, lsr #32
    //     0xba0e04: b.eq            #0xba0e0c
    //     0xba0e08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba0e0c: r0 = LoadClassIdInstr(r5)
    //     0xba0e0c: ldur            x0, [x5, #-1]
    //     0xba0e10: ubfx            x0, x0, #0xc, #0x14
    // 0xba0e14: mov             x1, x5
    // 0xba0e18: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba0e18: mov             x17, #0x5fe3
    //     0xba0e1c: movk            x17, #1, lsl #16
    //     0xba0e20: add             lr, x0, x17
    //     0xba0e24: ldr             lr, [x21, lr, lsl #3]
    //     0xba0e28: blr             lr
    // 0xba0e2c: ldur            x3, [fp, #-8]
    // 0xba0e30: StoreField: r3->field_37 = r0
    //     0xba0e30: stur            w0, [x3, #0x37]
    //     0xba0e34: ldurb           w16, [x3, #-1]
    //     0xba0e38: ldurb           w17, [x0, #-1]
    //     0xba0e3c: and             x16, x17, x16, lsr #2
    //     0xba0e40: tst             x16, HEAP, lsr #32
    //     0xba0e44: b.eq            #0xba0e4c
    //     0xba0e48: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba0e4c: r1 = true
    //     0xba0e4c: add             x1, NULL, #0x20  ; true
    // 0xba0e50: r0 = true
    //     0xba0e50: add             x0, NULL, #0x20  ; true
    // 0xba0e54: b               #0xba13b8
    // 0xba0e58: ldur            x3, [fp, #-8]
    // 0xba0e5c: ldur            x0, [fp, #-0x10]
    // 0xba0e60: r2 = Null
    //     0xba0e60: mov             x2, NULL
    // 0xba0e64: r1 = Null
    //     0xba0e64: mov             x1, NULL
    // 0xba0e68: cmp             w0, NULL
    // 0xba0e6c: b.eq            #0xba0e94
    // 0xba0e70: branchIfSmi(r0, 0xba0e94)
    //     0xba0e70: tbz             w0, #0, #0xba0e94
    // 0xba0e74: r3 = LoadClassIdInstr(r0)
    //     0xba0e74: ldur            x3, [x0, #-1]
    //     0xba0e78: ubfx            x3, x3, #0xc, #0x14
    // 0xba0e7c: r17 = 4155
    //     0xba0e7c: mov             x17, #0x103b
    // 0xba0e80: cmp             x3, x17
    // 0xba0e84: b.eq            #0xba0e9c
    // 0xba0e88: r17 = 5284
    //     0xba0e88: mov             x17, #0x14a4
    // 0xba0e8c: cmp             x3, x17
    // 0xba0e90: b.eq            #0xba0e9c
    // 0xba0e94: r0 = false
    //     0xba0e94: add             x0, NULL, #0x30  ; false
    // 0xba0e98: b               #0xba0ea0
    // 0xba0e9c: r0 = true
    //     0xba0e9c: add             x0, NULL, #0x20  ; true
    // 0xba0ea0: tbz             w0, #4, #0xba0eec
    // 0xba0ea4: ldur            x0, [fp, #-0x10]
    // 0xba0ea8: r2 = Null
    //     0xba0ea8: mov             x2, NULL
    // 0xba0eac: r1 = Null
    //     0xba0eac: mov             x1, NULL
    // 0xba0eb0: cmp             w0, NULL
    // 0xba0eb4: b.eq            #0xba0edc
    // 0xba0eb8: branchIfSmi(r0, 0xba0edc)
    //     0xba0eb8: tbz             w0, #0, #0xba0edc
    // 0xba0ebc: r3 = LoadClassIdInstr(r0)
    //     0xba0ebc: ldur            x3, [x0, #-1]
    //     0xba0ec0: ubfx            x3, x3, #0xc, #0x14
    // 0xba0ec4: r17 = 4139
    //     0xba0ec4: mov             x17, #0x102b
    // 0xba0ec8: cmp             x3, x17
    // 0xba0ecc: b.eq            #0xba0ee4
    // 0xba0ed0: r17 = 5276
    //     0xba0ed0: mov             x17, #0x149c
    // 0xba0ed4: cmp             x3, x17
    // 0xba0ed8: b.eq            #0xba0ee4
    // 0xba0edc: r0 = false
    //     0xba0edc: add             x0, NULL, #0x30  ; false
    // 0xba0ee0: b               #0xba0ee8
    // 0xba0ee4: r0 = true
    //     0xba0ee4: add             x0, NULL, #0x20  ; true
    // 0xba0ee8: tbnz            w0, #4, #0xba0fdc
    // 0xba0eec: ldur            x2, [fp, #-8]
    // 0xba0ef0: ldur            x3, [fp, #-0x10]
    // 0xba0ef4: LoadField: r4 = r2->field_6b
    //     0xba0ef4: ldur            w4, [x2, #0x6b]
    // 0xba0ef8: DecompressPointer r4
    //     0xba0ef8: add             x4, x4, HEAP, lsl #32
    // 0xba0efc: stur            x4, [fp, #-0x18]
    // 0xba0f00: r0 = LoadClassIdInstr(r3)
    //     0xba0f00: ldur            x0, [x3, #-1]
    //     0xba0f04: ubfx            x0, x0, #0xc, #0x14
    // 0xba0f08: mov             x1, x3
    // 0xba0f0c: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0f0c: sub             lr, x0, #1
    //     0xba0f10: ldr             lr, [x21, lr, lsl #3]
    //     0xba0f14: blr             lr
    // 0xba0f18: mov             x2, x0
    // 0xba0f1c: r0 = BoxInt64Instr(r2)
    //     0xba0f1c: sbfiz           x0, x2, #1, #0x1f
    //     0xba0f20: cmp             x2, x0, asr #1
    //     0xba0f24: b.eq            #0xba0f30
    //     0xba0f28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0f2c: stur            x2, [x0, #7]
    // 0xba0f30: ldur            x1, [fp, #-0x18]
    // 0xba0f34: mov             x2, x0
    // 0xba0f38: r0 = remove()
    //     0xba0f38: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba0f3c: ldur            x2, [fp, #-8]
    // 0xba0f40: LoadField: r3 = r2->field_6f
    //     0xba0f40: ldur            w3, [x2, #0x6f]
    // 0xba0f44: DecompressPointer r3
    //     0xba0f44: add             x3, x3, HEAP, lsl #32
    // 0xba0f48: ldur            x4, [fp, #-0x10]
    // 0xba0f4c: stur            x3, [fp, #-0x18]
    // 0xba0f50: r0 = LoadClassIdInstr(r4)
    //     0xba0f50: ldur            x0, [x4, #-1]
    //     0xba0f54: ubfx            x0, x0, #0xc, #0x14
    // 0xba0f58: mov             x1, x4
    // 0xba0f5c: r0 = GDT[cid_x0 + -0x1]()
    //     0xba0f5c: sub             lr, x0, #1
    //     0xba0f60: ldr             lr, [x21, lr, lsl #3]
    //     0xba0f64: blr             lr
    // 0xba0f68: mov             x2, x0
    // 0xba0f6c: r0 = BoxInt64Instr(r2)
    //     0xba0f6c: sbfiz           x0, x2, #1, #0x1f
    //     0xba0f70: cmp             x2, x0, asr #1
    //     0xba0f74: b.eq            #0xba0f80
    //     0xba0f78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba0f7c: stur            x2, [x0, #7]
    // 0xba0f80: ldur            x1, [fp, #-0x18]
    // 0xba0f84: mov             x2, x0
    // 0xba0f88: r0 = remove()
    //     0xba0f88: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xba0f8c: ldur            x2, [fp, #-0x10]
    // 0xba0f90: r0 = LoadClassIdInstr(r2)
    //     0xba0f90: ldur            x0, [x2, #-1]
    //     0xba0f94: ubfx            x0, x0, #0xc, #0x14
    // 0xba0f98: mov             x1, x2
    // 0xba0f9c: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba0f9c: mov             x17, #0x5fe3
    //     0xba0fa0: movk            x17, #1, lsl #16
    //     0xba0fa4: add             lr, x0, x17
    //     0xba0fa8: ldr             lr, [x21, lr, lsl #3]
    //     0xba0fac: blr             lr
    // 0xba0fb0: ldur            x3, [fp, #-8]
    // 0xba0fb4: StoreField: r3->field_37 = r0
    //     0xba0fb4: stur            w0, [x3, #0x37]
    //     0xba0fb8: ldurb           w16, [x3, #-1]
    //     0xba0fbc: ldurb           w17, [x0, #-1]
    //     0xba0fc0: and             x16, x17, x16, lsr #2
    //     0xba0fc4: tst             x16, HEAP, lsr #32
    //     0xba0fc8: b.eq            #0xba0fd0
    //     0xba0fcc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba0fd0: r1 = true
    //     0xba0fd0: add             x1, NULL, #0x20  ; true
    // 0xba0fd4: r0 = false
    //     0xba0fd4: add             x0, NULL, #0x30  ; false
    // 0xba0fd8: b               #0xba13b8
    // 0xba0fdc: ldur            x3, [fp, #-8]
    // 0xba0fe0: ldur            x0, [fp, #-0x10]
    // 0xba0fe4: r2 = Null
    //     0xba0fe4: mov             x2, NULL
    // 0xba0fe8: r1 = Null
    //     0xba0fe8: mov             x1, NULL
    // 0xba0fec: cmp             w0, NULL
    // 0xba0ff0: b.eq            #0xba1018
    // 0xba0ff4: branchIfSmi(r0, 0xba1018)
    //     0xba0ff4: tbz             w0, #0, #0xba1018
    // 0xba0ff8: r3 = LoadClassIdInstr(r0)
    //     0xba0ff8: ldur            x3, [x0, #-1]
    //     0xba0ffc: ubfx            x3, x3, #0xc, #0x14
    // 0xba1000: r17 = 4145
    //     0xba1000: mov             x17, #0x1031
    // 0xba1004: cmp             x3, x17
    // 0xba1008: b.eq            #0xba1020
    // 0xba100c: r17 = 5282
    //     0xba100c: mov             x17, #0x14a2
    // 0xba1010: cmp             x3, x17
    // 0xba1014: b.eq            #0xba1020
    // 0xba1018: r0 = false
    //     0xba1018: add             x0, NULL, #0x30  ; false
    // 0xba101c: b               #0xba1024
    // 0xba1020: r0 = true
    //     0xba1020: add             x0, NULL, #0x20  ; true
    // 0xba1024: tbnz            w0, #4, #0xba10e8
    // 0xba1028: ldur            x2, [fp, #-8]
    // 0xba102c: ldur            x3, [fp, #-0x10]
    // 0xba1030: LoadField: r4 = r2->field_7f
    //     0xba1030: ldur            w4, [x2, #0x7f]
    // 0xba1034: DecompressPointer r4
    //     0xba1034: add             x4, x4, HEAP, lsl #32
    // 0xba1038: stur            x4, [fp, #-0x18]
    // 0xba103c: r0 = LoadClassIdInstr(r3)
    //     0xba103c: ldur            x0, [x3, #-1]
    //     0xba1040: ubfx            x0, x0, #0xc, #0x14
    // 0xba1044: mov             x1, x3
    // 0xba1048: r0 = GDT[cid_x0 + -0x1]()
    //     0xba1048: sub             lr, x0, #1
    //     0xba104c: ldr             lr, [x21, lr, lsl #3]
    //     0xba1050: blr             lr
    // 0xba1054: stur            x0, [fp, #-0x28]
    // 0xba1058: r0 = _PointerPanZoomData()
    //     0xba1058: bl              #0xba30ac  ; Allocate_PointerPanZoomDataStub -> _PointerPanZoomData (size=0x24)
    // 0xba105c: mov             x1, x0
    // 0xba1060: ldur            x2, [fp, #-8]
    // 0xba1064: ldur            x3, [fp, #-0x10]
    // 0xba1068: stur            x0, [fp, #-0x20]
    // 0xba106c: r0 = _PointerPanZoomData.fromStartEvent()
    //     0xba106c: bl              #0xba3000  ; [package:flutter/src/gestures/scale.dart] _PointerPanZoomData::_PointerPanZoomData.fromStartEvent
    // 0xba1070: ldur            x2, [fp, #-0x28]
    // 0xba1074: r0 = BoxInt64Instr(r2)
    //     0xba1074: sbfiz           x0, x2, #1, #0x1f
    //     0xba1078: cmp             x2, x0, asr #1
    //     0xba107c: b.eq            #0xba1088
    //     0xba1080: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba1084: stur            x2, [x0, #7]
    // 0xba1088: ldur            x1, [fp, #-0x18]
    // 0xba108c: mov             x2, x0
    // 0xba1090: ldur            x3, [fp, #-0x20]
    // 0xba1094: r0 = []=()
    //     0xba1094: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba1098: ldur            x2, [fp, #-0x10]
    // 0xba109c: r0 = LoadClassIdInstr(r2)
    //     0xba109c: ldur            x0, [x2, #-1]
    //     0xba10a0: ubfx            x0, x0, #0xc, #0x14
    // 0xba10a4: mov             x1, x2
    // 0xba10a8: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba10a8: mov             x17, #0x5fe3
    //     0xba10ac: movk            x17, #1, lsl #16
    //     0xba10b0: add             lr, x0, x17
    //     0xba10b4: ldr             lr, [x21, lr, lsl #3]
    //     0xba10b8: blr             lr
    // 0xba10bc: ldur            x3, [fp, #-8]
    // 0xba10c0: StoreField: r3->field_37 = r0
    //     0xba10c0: stur            w0, [x3, #0x37]
    //     0xba10c4: ldurb           w16, [x3, #-1]
    //     0xba10c8: ldurb           w17, [x0, #-1]
    //     0xba10cc: and             x16, x17, x16, lsr #2
    //     0xba10d0: tst             x16, HEAP, lsr #32
    //     0xba10d4: b.eq            #0xba10dc
    //     0xba10d8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba10dc: r1 = true
    //     0xba10dc: add             x1, NULL, #0x20  ; true
    // 0xba10e0: r0 = true
    //     0xba10e0: add             x0, NULL, #0x20  ; true
    // 0xba10e4: b               #0xba13b8
    // 0xba10e8: ldur            x3, [fp, #-8]
    // 0xba10ec: ldur            x0, [fp, #-0x10]
    // 0xba10f0: r2 = Null
    //     0xba10f0: mov             x2, NULL
    // 0xba10f4: r1 = Null
    //     0xba10f4: mov             x1, NULL
    // 0xba10f8: cmp             w0, NULL
    // 0xba10fc: b.eq            #0xba1124
    // 0xba1100: branchIfSmi(r0, 0xba1124)
    //     0xba1100: tbz             w0, #0, #0xba1124
    // 0xba1104: r3 = LoadClassIdInstr(r0)
    //     0xba1104: ldur            x3, [x0, #-1]
    //     0xba1108: ubfx            x3, x3, #0xc, #0x14
    // 0xba110c: r17 = 4143
    //     0xba110c: mov             x17, #0x102f
    // 0xba1110: cmp             x3, x17
    // 0xba1114: b.eq            #0xba112c
    // 0xba1118: r17 = 5280
    //     0xba1118: mov             x17, #0x14a0
    // 0xba111c: cmp             x3, x17
    // 0xba1120: b.eq            #0xba112c
    // 0xba1124: r0 = false
    //     0xba1124: add             x0, NULL, #0x30  ; false
    // 0xba1128: b               #0xba1130
    // 0xba112c: r0 = true
    //     0xba112c: add             x0, NULL, #0x20  ; true
    // 0xba1130: tbnz            w0, #4, #0xba1308
    // 0xba1134: ldur            x2, [fp, #-0x10]
    // 0xba1138: r0 = LoadClassIdInstr(r2)
    //     0xba1138: ldur            x0, [x2, #-1]
    //     0xba113c: ubfx            x0, x0, #0xc, #0x14
    // 0xba1140: mov             x1, x2
    // 0xba1144: r0 = GDT[cid_x0 + 0x15474]()
    //     0xba1144: mov             x17, #0x5474
    //     0xba1148: movk            x17, #1, lsl #16
    //     0xba114c: add             lr, x0, x17
    //     0xba1150: ldr             lr, [x21, lr, lsl #3]
    //     0xba1154: blr             lr
    // 0xba1158: tbz             w0, #4, #0xba1248
    // 0xba115c: ldur            x3, [fp, #-8]
    // 0xba1160: ldur            x2, [fp, #-0x10]
    // 0xba1164: LoadField: r4 = r3->field_73
    //     0xba1164: ldur            w4, [x3, #0x73]
    // 0xba1168: DecompressPointer r4
    //     0xba1168: add             x4, x4, HEAP, lsl #32
    // 0xba116c: stur            x4, [fp, #-0x18]
    // 0xba1170: r0 = LoadClassIdInstr(r2)
    //     0xba1170: ldur            x0, [x2, #-1]
    //     0xba1174: ubfx            x0, x0, #0xc, #0x14
    // 0xba1178: mov             x1, x2
    // 0xba117c: r0 = GDT[cid_x0 + -0x1]()
    //     0xba117c: sub             lr, x0, #1
    //     0xba1180: ldr             lr, [x21, lr, lsl #3]
    //     0xba1184: blr             lr
    // 0xba1188: mov             x2, x0
    // 0xba118c: r0 = BoxInt64Instr(r2)
    //     0xba118c: sbfiz           x0, x2, #1, #0x1f
    //     0xba1190: cmp             x2, x0, asr #1
    //     0xba1194: b.eq            #0xba11a0
    //     0xba1198: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba119c: stur            x2, [x0, #7]
    // 0xba11a0: ldur            x1, [fp, #-0x18]
    // 0xba11a4: mov             x2, x0
    // 0xba11a8: r0 = _getValueOrData()
    //     0xba11a8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba11ac: mov             x1, x0
    // 0xba11b0: ldur            x0, [fp, #-0x18]
    // 0xba11b4: LoadField: r2 = r0->field_f
    //     0xba11b4: ldur            w2, [x0, #0xf]
    // 0xba11b8: DecompressPointer r2
    //     0xba11b8: add             x2, x2, HEAP, lsl #32
    // 0xba11bc: cmp             w2, w1
    // 0xba11c0: b.ne            #0xba11cc
    // 0xba11c4: r3 = Null
    //     0xba11c4: mov             x3, NULL
    // 0xba11c8: b               #0xba11d0
    // 0xba11cc: mov             x3, x1
    // 0xba11d0: ldur            x2, [fp, #-0x10]
    // 0xba11d4: stur            x3, [fp, #-0x18]
    // 0xba11d8: cmp             w3, NULL
    // 0xba11dc: b.eq            #0xba1444
    // 0xba11e0: r0 = LoadClassIdInstr(r2)
    //     0xba11e0: ldur            x0, [x2, #-1]
    //     0xba11e4: ubfx            x0, x0, #0xc, #0x14
    // 0xba11e8: mov             x1, x2
    // 0xba11ec: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba11ec: mov             x17, #0x5eb5
    //     0xba11f0: movk            x17, #1, lsl #16
    //     0xba11f4: add             lr, x0, x17
    //     0xba11f8: ldr             lr, [x21, lr, lsl #3]
    //     0xba11fc: blr             lr
    // 0xba1200: mov             x3, x0
    // 0xba1204: ldur            x2, [fp, #-0x10]
    // 0xba1208: stur            x3, [fp, #-0x20]
    // 0xba120c: r0 = LoadClassIdInstr(r2)
    //     0xba120c: ldur            x0, [x2, #-1]
    //     0xba1210: ubfx            x0, x0, #0xc, #0x14
    // 0xba1214: mov             x1, x2
    // 0xba1218: r0 = GDT[cid_x0 + -0xff5]()
    //     0xba1218: sub             lr, x0, #0xff5
    //     0xba121c: ldr             lr, [x21, lr, lsl #3]
    //     0xba1220: blr             lr
    // 0xba1224: ldur            x1, [fp, #-0x18]
    // 0xba1228: r2 = LoadClassIdInstr(r1)
    //     0xba1228: ldur            x2, [x1, #-1]
    //     0xba122c: ubfx            x2, x2, #0xc, #0x14
    // 0xba1230: mov             x3, x0
    // 0xba1234: mov             x0, x2
    // 0xba1238: ldur            x2, [fp, #-0x20]
    // 0xba123c: r0 = GDT[cid_x0 + -0xffc]()
    //     0xba123c: sub             lr, x0, #0xffc
    //     0xba1240: ldr             lr, [x21, lr, lsl #3]
    //     0xba1244: blr             lr
    // 0xba1248: ldur            x3, [fp, #-8]
    // 0xba124c: ldur            x2, [fp, #-0x10]
    // 0xba1250: LoadField: r4 = r3->field_7f
    //     0xba1250: ldur            w4, [x3, #0x7f]
    // 0xba1254: DecompressPointer r4
    //     0xba1254: add             x4, x4, HEAP, lsl #32
    // 0xba1258: stur            x4, [fp, #-0x18]
    // 0xba125c: r0 = LoadClassIdInstr(r2)
    //     0xba125c: ldur            x0, [x2, #-1]
    //     0xba1260: ubfx            x0, x0, #0xc, #0x14
    // 0xba1264: mov             x1, x2
    // 0xba1268: r0 = GDT[cid_x0 + -0x1]()
    //     0xba1268: sub             lr, x0, #1
    //     0xba126c: ldr             lr, [x21, lr, lsl #3]
    //     0xba1270: blr             lr
    // 0xba1274: stur            x0, [fp, #-0x28]
    // 0xba1278: r0 = _PointerPanZoomData()
    //     0xba1278: bl              #0xba30ac  ; Allocate_PointerPanZoomDataStub -> _PointerPanZoomData (size=0x24)
    // 0xba127c: mov             x1, x0
    // 0xba1280: ldur            x2, [fp, #-8]
    // 0xba1284: ldur            x3, [fp, #-0x10]
    // 0xba1288: stur            x0, [fp, #-0x20]
    // 0xba128c: r0 = _PointerPanZoomData.fromUpdateEvent()
    //     0xba128c: bl              #0xba2ee0  ; [package:flutter/src/gestures/scale.dart] _PointerPanZoomData::_PointerPanZoomData.fromUpdateEvent
    // 0xba1290: ldur            x2, [fp, #-0x28]
    // 0xba1294: r0 = BoxInt64Instr(r2)
    //     0xba1294: sbfiz           x0, x2, #1, #0x1f
    //     0xba1298: cmp             x2, x0, asr #1
    //     0xba129c: b.eq            #0xba12a8
    //     0xba12a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba12a4: stur            x2, [x0, #7]
    // 0xba12a8: ldur            x1, [fp, #-0x18]
    // 0xba12ac: mov             x2, x0
    // 0xba12b0: ldur            x3, [fp, #-0x20]
    // 0xba12b4: r0 = []=()
    //     0xba12b4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba12b8: ldur            x2, [fp, #-0x10]
    // 0xba12bc: r0 = LoadClassIdInstr(r2)
    //     0xba12bc: ldur            x0, [x2, #-1]
    //     0xba12c0: ubfx            x0, x0, #0xc, #0x14
    // 0xba12c4: mov             x1, x2
    // 0xba12c8: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba12c8: mov             x17, #0x5fe3
    //     0xba12cc: movk            x17, #1, lsl #16
    //     0xba12d0: add             lr, x0, x17
    //     0xba12d4: ldr             lr, [x21, lr, lsl #3]
    //     0xba12d8: blr             lr
    // 0xba12dc: ldur            x3, [fp, #-8]
    // 0xba12e0: StoreField: r3->field_37 = r0
    //     0xba12e0: stur            w0, [x3, #0x37]
    //     0xba12e4: ldurb           w16, [x3, #-1]
    //     0xba12e8: ldurb           w17, [x0, #-1]
    //     0xba12ec: and             x16, x17, x16, lsr #2
    //     0xba12f0: tst             x16, HEAP, lsr #32
    //     0xba12f4: b.eq            #0xba12fc
    //     0xba12f8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba12fc: r1 = false
    //     0xba12fc: add             x1, NULL, #0x30  ; false
    // 0xba1300: r0 = true
    //     0xba1300: add             x0, NULL, #0x20  ; true
    // 0xba1304: b               #0xba13b8
    // 0xba1308: ldur            x3, [fp, #-8]
    // 0xba130c: ldur            x0, [fp, #-0x10]
    // 0xba1310: r2 = Null
    //     0xba1310: mov             x2, NULL
    // 0xba1314: r1 = Null
    //     0xba1314: mov             x1, NULL
    // 0xba1318: cmp             w0, NULL
    // 0xba131c: b.eq            #0xba1344
    // 0xba1320: branchIfSmi(r0, 0xba1344)
    //     0xba1320: tbz             w0, #0, #0xba1344
    // 0xba1324: r3 = LoadClassIdInstr(r0)
    //     0xba1324: ldur            x3, [x0, #-1]
    //     0xba1328: ubfx            x3, x3, #0xc, #0x14
    // 0xba132c: r17 = 4141
    //     0xba132c: mov             x17, #0x102d
    // 0xba1330: cmp             x3, x17
    // 0xba1334: b.eq            #0xba134c
    // 0xba1338: r17 = 5278
    //     0xba1338: mov             x17, #0x149e
    // 0xba133c: cmp             x3, x17
    // 0xba1340: b.eq            #0xba134c
    // 0xba1344: r0 = false
    //     0xba1344: add             x0, NULL, #0x30  ; false
    // 0xba1348: b               #0xba1350
    // 0xba134c: r0 = true
    //     0xba134c: add             x0, NULL, #0x20  ; true
    // 0xba1350: tbnz            w0, #4, #0xba13ac
    // 0xba1354: ldur            x2, [fp, #-8]
    // 0xba1358: ldur            x3, [fp, #-0x10]
    // 0xba135c: LoadField: r4 = r2->field_7f
    //     0xba135c: ldur            w4, [x2, #0x7f]
    // 0xba1360: DecompressPointer r4
    //     0xba1360: add             x4, x4, HEAP, lsl #32
    // 0xba1364: stur            x4, [fp, #-0x18]
    // 0xba1368: r0 = LoadClassIdInstr(r3)
    //     0xba1368: ldur            x0, [x3, #-1]
    //     0xba136c: ubfx            x0, x0, #0xc, #0x14
    // 0xba1370: mov             x1, x3
    // 0xba1374: r0 = GDT[cid_x0 + -0x1]()
    //     0xba1374: sub             lr, x0, #1
    //     0xba1378: ldr             lr, [x21, lr, lsl #3]
    //     0xba137c: blr             lr
    // 0xba1380: mov             x2, x0
    // 0xba1384: r0 = BoxInt64Instr(r2)
    //     0xba1384: sbfiz           x0, x2, #1, #0x1f
    //     0xba1388: cmp             x2, x0, asr #1
    //     0xba138c: b.eq            #0xba1398
    //     0xba1390: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba1394: stur            x2, [x0, #7]
    // 0xba1398: ldur            x1, [fp, #-0x18]
    // 0xba139c: mov             x2, x0
    // 0xba13a0: r0 = remove()
    //     0xba13a0: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba13a4: r0 = true
    //     0xba13a4: add             x0, NULL, #0x20  ; true
    // 0xba13a8: b               #0xba13b0
    // 0xba13ac: r0 = false
    //     0xba13ac: add             x0, NULL, #0x30  ; false
    // 0xba13b0: mov             x1, x0
    // 0xba13b4: r0 = false
    //     0xba13b4: add             x0, NULL, #0x30  ; false
    // 0xba13b8: mov             x2, x0
    // 0xba13bc: mov             x0, x1
    // 0xba13c0: ldur            x1, [fp, #-8]
    // 0xba13c4: stur            x0, [fp, #-0x18]
    // 0xba13c8: stur            x2, [fp, #-0x20]
    // 0xba13cc: r0 = _updateLines()
    //     0xba13cc: bl              #0xba2ae0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_updateLines
    // 0xba13d0: ldur            x1, [fp, #-8]
    // 0xba13d4: r0 = _update()
    //     0xba13d4: bl              #0xba219c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_update
    // 0xba13d8: ldur            x0, [fp, #-0x18]
    // 0xba13dc: tbnz            w0, #4, #0xba140c
    // 0xba13e0: ldur            x2, [fp, #-0x10]
    // 0xba13e4: r0 = LoadClassIdInstr(r2)
    //     0xba13e4: ldur            x0, [x2, #-1]
    //     0xba13e8: ubfx            x0, x0, #0xc, #0x14
    // 0xba13ec: mov             x1, x2
    // 0xba13f0: r0 = GDT[cid_x0 + -0x1]()
    //     0xba13f0: sub             lr, x0, #1
    //     0xba13f4: ldr             lr, [x21, lr, lsl #3]
    //     0xba13f8: blr             lr
    // 0xba13fc: ldur            x1, [fp, #-8]
    // 0xba1400: mov             x2, x0
    // 0xba1404: r0 = _reconfigure()
    //     0xba1404: bl              #0xade978  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure
    // 0xba1408: tbnz            w0, #4, #0xba141c
    // 0xba140c: ldur            x1, [fp, #-8]
    // 0xba1410: ldur            x2, [fp, #-0x20]
    // 0xba1414: ldur            x3, [fp, #-0x10]
    // 0xba1418: r0 = _advanceStateMachine()
    //     0xba1418: bl              #0xba1448  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_advanceStateMachine
    // 0xba141c: ldur            x1, [fp, #-8]
    // 0xba1420: ldur            x2, [fp, #-0x10]
    // 0xba1424: r0 = stopTrackingIfPointerNoLongerDown()
    //     0xba1424: bl              #0xb9c294  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0xba1428: r0 = Null
    //     0xba1428: mov             x0, NULL
    // 0xba142c: LeaveFrame
    //     0xba142c: mov             SP, fp
    //     0xba1430: ldp             fp, lr, [SP], #0x10
    // 0xba1434: ret
    //     0xba1434: ret             
    // 0xba1438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba143c: b               #0xba0a3c
    // 0xba1440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1440: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba1444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1444: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _advanceStateMachine(/* No info */) {
    // ** addr: 0xba1448, size: 0x3ec
    // 0xba1448: EnterFrame
    //     0xba1448: stp             fp, lr, [SP, #-0x10]!
    //     0xba144c: mov             fp, SP
    // 0xba1450: AllocStack(0x48)
    //     0xba1450: sub             SP, SP, #0x48
    // 0xba1454: SetupParameters(ScaleGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xba1454: stur            x1, [fp, #-8]
    //     0xba1458: stur            x2, [fp, #-0x10]
    //     0xba145c: stur            x3, [fp, #-0x18]
    // 0xba1460: CheckStackOverflow
    //     0xba1460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1464: cmp             SP, x16
    //     0xba1468: b.ls            #0xba1804
    // 0xba146c: r1 = 2
    //     0xba146c: mov             x1, #2
    // 0xba1470: r0 = AllocateContext()
    //     0xba1470: bl              #0x13de838  ; AllocateContextStub
    // 0xba1474: mov             x3, x0
    // 0xba1478: ldur            x0, [fp, #-8]
    // 0xba147c: stur            x3, [fp, #-0x20]
    // 0xba1480: StoreField: r3->field_f = r0
    //     0xba1480: stur            w0, [x3, #0xf]
    // 0xba1484: ldur            x1, [fp, #-0x18]
    // 0xba1488: StoreField: r3->field_13 = r1
    //     0xba1488: stur            w1, [x3, #0x13]
    // 0xba148c: LoadField: r1 = r0->field_33
    //     0xba148c: ldur            w1, [x0, #0x33]
    // 0xba1490: DecompressPointer r1
    //     0xba1490: add             x1, x1, HEAP, lsl #32
    // 0xba1494: r16 = Instance__ScaleState
    //     0xba1494: add             x16, PP, #0x84, lsl #12  ; [pp+0x84e10] Obj!_ScaleState@12c5b81
    //     0xba1498: ldr             x16, [x16, #0xe10]
    // 0xba149c: cmp             w1, w16
    // 0xba14a0: b.ne            #0xba14b8
    // 0xba14a4: r1 = Instance__ScaleState
    //     0xba14a4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0xba14a8: ldr             x1, [x1, #0xc50]
    // 0xba14ac: StoreField: r0->field_33 = r1
    //     0xba14ac: stur            w1, [x0, #0x33]
    // 0xba14b0: r1 = Instance__ScaleState
    //     0xba14b0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0xba14b4: ldr             x1, [x1, #0xc50]
    // 0xba14b8: r16 = Instance__ScaleState
    //     0xba14b8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0xba14bc: ldr             x16, [x16, #0xc50]
    // 0xba14c0: cmp             w1, w16
    // 0xba14c4: b.ne            #0xba168c
    // 0xba14c8: d0 = 0.000000
    //     0xba14c8: eor             v0.16b, v0.16b, v0.16b
    // 0xba14cc: LoadField: r1 = r0->field_4b
    //     0xba14cc: ldur            w1, [x0, #0x4b]
    // 0xba14d0: DecompressPointer r1
    //     0xba14d0: add             x1, x1, HEAP, lsl #32
    // 0xba14d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba14d8: cmp             w1, w16
    // 0xba14dc: b.eq            #0xba180c
    // 0xba14e0: LoadField: r2 = r0->field_47
    //     0xba14e0: ldur            w2, [x0, #0x47]
    // 0xba14e4: DecompressPointer r2
    //     0xba14e4: add             x2, x2, HEAP, lsl #32
    // 0xba14e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba14ec: cmp             w2, w16
    // 0xba14f0: b.eq            #0xba1818
    // 0xba14f4: LoadField: d1 = r1->field_7
    //     0xba14f4: ldur            d1, [x1, #7]
    // 0xba14f8: LoadField: d2 = r2->field_7
    //     0xba14f8: ldur            d2, [x2, #7]
    // 0xba14fc: fsub            d3, d1, d2
    // 0xba1500: fcmp            d3, d0
    // 0xba1504: b.ne            #0xba1510
    // 0xba1508: d0 = 0.000000
    //     0xba1508: eor             v0.16b, v0.16b, v0.16b
    // 0xba150c: b               #0xba1524
    // 0xba1510: fcmp            d0, d3
    // 0xba1514: b.le            #0xba1520
    // 0xba1518: fneg            d0, d3
    // 0xba151c: b               #0xba1524
    // 0xba1520: mov             v0.16b, v3.16b
    // 0xba1524: stur            d0, [fp, #-0x28]
    // 0xba1528: LoadField: r1 = r0->field_43
    //     0xba1528: ldur            w1, [x0, #0x43]
    // 0xba152c: DecompressPointer r1
    //     0xba152c: add             x1, x1, HEAP, lsl #32
    // 0xba1530: cmp             w1, NULL
    // 0xba1534: b.eq            #0xba1824
    // 0xba1538: LoadField: r2 = r0->field_3f
    //     0xba1538: ldur            w2, [x0, #0x3f]
    // 0xba153c: DecompressPointer r2
    //     0xba153c: add             x2, x2, HEAP, lsl #32
    // 0xba1540: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1544: cmp             w2, w16
    // 0xba1548: b.eq            #0xba1828
    // 0xba154c: r0 = -()
    //     0xba154c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xba1550: LoadField: d0 = r0->field_7
    //     0xba1550: ldur            d0, [x0, #7]
    // 0xba1554: fmul            d1, d0, d0
    // 0xba1558: LoadField: d0 = r0->field_f
    //     0xba1558: ldur            d0, [x0, #0xf]
    // 0xba155c: fmul            d2, d0, d0
    // 0xba1560: fadd            d0, d1, d2
    // 0xba1564: fsqrt           d1, d0
    // 0xba1568: ldur            x2, [fp, #-0x20]
    // 0xba156c: stur            d1, [fp, #-0x30]
    // 0xba1570: LoadField: r1 = r2->field_13
    //     0xba1570: ldur            w1, [x2, #0x13]
    // 0xba1574: DecompressPointer r1
    //     0xba1574: add             x1, x1, HEAP, lsl #32
    // 0xba1578: r0 = LoadClassIdInstr(r1)
    //     0xba1578: ldur            x0, [x1, #-1]
    //     0xba157c: ubfx            x0, x0, #0xc, #0x14
    // 0xba1580: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xba1580: mov             x17, #0x5e74
    //     0xba1584: movk            x17, #1, lsl #16
    //     0xba1588: add             lr, x0, x17
    //     0xba158c: ldr             lr, [x21, lr, lsl #3]
    //     0xba1590: blr             lr
    // 0xba1594: LoadField: r1 = r0->field_7
    //     0xba1594: ldur            x1, [x0, #7]
    // 0xba1598: cmp             x1, #2
    // 0xba159c: b.gt            #0xba15b8
    // 0xba15a0: cmp             x1, #1
    // 0xba15a4: b.gt            #0xba15b8
    // 0xba15a8: cmp             x1, #0
    // 0xba15ac: b.le            #0xba15b8
    // 0xba15b0: d1 = 1.000000
    //     0xba15b0: fmov            d1, #1.00000000
    // 0xba15b4: b               #0xba15bc
    // 0xba15b8: d1 = 18.000000
    //     0xba15b8: fmov            d1, #18.00000000
    // 0xba15bc: ldur            d0, [fp, #-0x28]
    // 0xba15c0: fcmp            d0, d1
    // 0xba15c4: b.gt            #0xba1678
    // 0xba15c8: ldur            x3, [fp, #-8]
    // 0xba15cc: ldur            x2, [fp, #-0x20]
    // 0xba15d0: ldur            d0, [fp, #-0x30]
    // 0xba15d4: LoadField: r1 = r2->field_13
    //     0xba15d4: ldur            w1, [x2, #0x13]
    // 0xba15d8: DecompressPointer r1
    //     0xba15d8: add             x1, x1, HEAP, lsl #32
    // 0xba15dc: r0 = LoadClassIdInstr(r1)
    //     0xba15dc: ldur            x0, [x1, #-1]
    //     0xba15e0: ubfx            x0, x0, #0xc, #0x14
    // 0xba15e4: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xba15e4: mov             x17, #0x5e74
    //     0xba15e8: movk            x17, #1, lsl #16
    //     0xba15ec: add             lr, x0, x17
    //     0xba15f0: ldr             lr, [x21, lr, lsl #3]
    //     0xba15f4: blr             lr
    // 0xba15f8: mov             x1, x0
    // 0xba15fc: ldur            x0, [fp, #-8]
    // 0xba1600: LoadField: r2 = r0->field_7
    //     0xba1600: ldur            w2, [x0, #7]
    // 0xba1604: DecompressPointer r2
    //     0xba1604: add             x2, x2, HEAP, lsl #32
    // 0xba1608: r0 = computePanSlop()
    //     0xba1608: bl              #0xb9c828  ; [package:flutter/src/gestures/events.dart] ::computePanSlop
    // 0xba160c: mov             v1.16b, v0.16b
    // 0xba1610: ldur            d0, [fp, #-0x30]
    // 0xba1614: fcmp            d0, d1
    // 0xba1618: b.gt            #0xba1678
    // 0xba161c: ldur            x1, [fp, #-8]
    // 0xba1620: r0 = _scaleFactor()
    //     0xba1620: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xba1624: ldur            x1, [fp, #-8]
    // 0xba1628: stur            d0, [fp, #-0x28]
    // 0xba162c: r0 = _pointerScaleFactor()
    //     0xba162c: bl              #0xba1a38  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerScaleFactor
    // 0xba1630: mov             v1.16b, v0.16b
    // 0xba1634: ldur            d0, [fp, #-0x28]
    // 0xba1638: fdiv            d2, d0, d1
    // 0xba163c: ldur            x1, [fp, #-8]
    // 0xba1640: stur            d2, [fp, #-0x30]
    // 0xba1644: r0 = _pointerScaleFactor()
    //     0xba1644: bl              #0xba1a38  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerScaleFactor
    // 0xba1648: ldur            x1, [fp, #-8]
    // 0xba164c: stur            d0, [fp, #-0x28]
    // 0xba1650: r0 = _scaleFactor()
    //     0xba1650: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xba1654: mov             v1.16b, v0.16b
    // 0xba1658: ldur            d0, [fp, #-0x28]
    // 0xba165c: fdiv            d2, d0, d1
    // 0xba1660: ldur            d0, [fp, #-0x30]
    // 0xba1664: fmax            v1.2d, v0.2d, v2.2d
    // 0xba1668: d0 = 1.050000
    //     0xba1668: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cc58] IMM: double(1.05) from 0x3ff0cccccccccccd
    //     0xba166c: ldr             d0, [x17, #0xc58]
    // 0xba1670: fcmp            d1, d0
    // 0xba1674: b.le            #0xba16a8
    // 0xba1678: ldur            x1, [fp, #-8]
    // 0xba167c: r2 = Instance_GestureDisposition
    //     0xba167c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba1680: ldr             x2, [x2, #0x628]
    // 0xba1684: r0 = resolve()
    //     0xba1684: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba1688: b               #0xba16a8
    // 0xba168c: LoadField: r0 = r1->field_7
    //     0xba168c: ldur            x0, [x1, #7]
    // 0xba1690: cmp             x0, #2
    // 0xba1694: b.lt            #0xba16a8
    // 0xba1698: ldur            x1, [fp, #-8]
    // 0xba169c: r2 = Instance_GestureDisposition
    //     0xba169c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba16a0: ldr             x2, [x2, #0x628]
    // 0xba16a4: r0 = resolve()
    //     0xba16a4: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba16a8: ldur            x2, [fp, #-8]
    // 0xba16ac: LoadField: r0 = r2->field_33
    //     0xba16ac: ldur            w0, [x2, #0x33]
    // 0xba16b0: DecompressPointer r0
    //     0xba16b0: add             x0, x0, HEAP, lsl #32
    // 0xba16b4: r16 = Instance__ScaleState
    //     0xba16b4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cc60] Obj!_ScaleState@12c5b41
    //     0xba16b8: ldr             x16, [x16, #0xc60]
    // 0xba16bc: cmp             w0, w16
    // 0xba16c0: b.ne            #0xba1728
    // 0xba16c4: ldur            x0, [fp, #-0x10]
    // 0xba16c8: tbnz            w0, #4, #0xba1728
    // 0xba16cc: ldur            x3, [fp, #-0x20]
    // 0xba16d0: LoadField: r1 = r3->field_13
    //     0xba16d0: ldur            w1, [x3, #0x13]
    // 0xba16d4: DecompressPointer r1
    //     0xba16d4: add             x1, x1, HEAP, lsl #32
    // 0xba16d8: r0 = LoadClassIdInstr(r1)
    //     0xba16d8: ldur            x0, [x1, #-1]
    //     0xba16dc: ubfx            x0, x0, #0xc, #0x14
    // 0xba16e0: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba16e0: mov             x17, #0x5eb5
    //     0xba16e4: movk            x17, #1, lsl #16
    //     0xba16e8: add             lr, x0, x17
    //     0xba16ec: ldr             lr, [x21, lr, lsl #3]
    //     0xba16f0: blr             lr
    // 0xba16f4: ldur            x2, [fp, #-8]
    // 0xba16f8: StoreField: r2->field_93 = r0
    //     0xba16f8: stur            w0, [x2, #0x93]
    //     0xba16fc: ldurb           w16, [x2, #-1]
    //     0xba1700: ldurb           w17, [x0, #-1]
    //     0xba1704: and             x16, x17, x16, lsr #2
    //     0xba1708: tst             x16, HEAP, lsr #32
    //     0xba170c: b.eq            #0xba1714
    //     0xba1710: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba1714: r0 = Instance__ScaleState
    //     0xba1714: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8cc68] Obj!_ScaleState@12c5b61
    //     0xba1718: ldr             x0, [x0, #0xc68]
    // 0xba171c: StoreField: r2->field_33 = r0
    //     0xba171c: stur            w0, [x2, #0x33]
    // 0xba1720: mov             x1, x2
    // 0xba1724: r0 = _dispatchOnStartCallbackIfNeeded()
    //     0xba1724: bl              #0xba1834  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded
    // 0xba1728: ldur            x2, [fp, #-8]
    // 0xba172c: LoadField: r0 = r2->field_33
    //     0xba172c: ldur            w0, [x2, #0x33]
    // 0xba1730: DecompressPointer r0
    //     0xba1730: add             x0, x0, HEAP, lsl #32
    // 0xba1734: r16 = Instance__ScaleState
    //     0xba1734: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cc68] Obj!_ScaleState@12c5b61
    //     0xba1738: ldr             x16, [x16, #0xc68]
    // 0xba173c: cmp             w0, w16
    // 0xba1740: b.ne            #0xba17f4
    // 0xba1744: LoadField: r3 = r2->field_77
    //     0xba1744: ldur            w3, [x2, #0x77]
    // 0xba1748: DecompressPointer r3
    //     0xba1748: add             x3, x3, HEAP, lsl #32
    // 0xba174c: stur            x3, [fp, #-0x10]
    // 0xba1750: cmp             w3, NULL
    // 0xba1754: b.ne            #0xba1760
    // 0xba1758: mov             x0, x2
    // 0xba175c: b               #0xba17bc
    // 0xba1760: ldur            x4, [fp, #-0x20]
    // 0xba1764: LoadField: r1 = r4->field_13
    //     0xba1764: ldur            w1, [x4, #0x13]
    // 0xba1768: DecompressPointer r1
    //     0xba1768: add             x1, x1, HEAP, lsl #32
    // 0xba176c: r0 = LoadClassIdInstr(r1)
    //     0xba176c: ldur            x0, [x1, #-1]
    //     0xba1770: ubfx            x0, x0, #0xc, #0x14
    // 0xba1774: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba1774: mov             x17, #0x5eb5
    //     0xba1778: movk            x17, #1, lsl #16
    //     0xba177c: add             lr, x0, x17
    //     0xba1780: ldr             lr, [x21, lr, lsl #3]
    //     0xba1784: blr             lr
    // 0xba1788: ldur            x1, [fp, #-8]
    // 0xba178c: stur            x0, [fp, #-0x18]
    // 0xba1790: r0 = _scaleFactor()
    //     0xba1790: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xba1794: stur            d0, [fp, #-0x28]
    // 0xba1798: r0 = Offset()
    //     0xba1798: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xba179c: ldur            d0, [fp, #-0x28]
    // 0xba17a0: StoreField: r0->field_7 = d0
    //     0xba17a0: stur            d0, [x0, #7]
    // 0xba17a4: StoreField: r0->field_f = rZR
    //     0xba17a4: stur            xzr, [x0, #0xf]
    // 0xba17a8: ldur            x1, [fp, #-0x10]
    // 0xba17ac: ldur            x2, [fp, #-0x18]
    // 0xba17b0: mov             x3, x0
    // 0xba17b4: r0 = addPosition()
    //     0xba17b4: bl              #0x12fef8c  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0xba17b8: ldur            x0, [fp, #-8]
    // 0xba17bc: LoadField: r1 = r0->field_2b
    //     0xba17bc: ldur            w1, [x0, #0x2b]
    // 0xba17c0: DecompressPointer r1
    //     0xba17c0: add             x1, x1, HEAP, lsl #32
    // 0xba17c4: cmp             w1, NULL
    // 0xba17c8: b.eq            #0xba17f4
    // 0xba17cc: ldur            x2, [fp, #-0x20]
    // 0xba17d0: r1 = Function '<anonymous closure>':.
    //     0xba17d0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc70] AnonymousClosure: (0xba1ab0), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_advanceStateMachine (0xba1448)
    //     0xba17d4: ldr             x1, [x1, #0xc70]
    // 0xba17d8: r0 = AllocateClosure()
    //     0xba17d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba17dc: r16 = <void?>
    //     0xba17dc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba17e0: ldur            lr, [fp, #-8]
    // 0xba17e4: stp             lr, x16, [SP, #8]
    // 0xba17e8: str             x0, [SP]
    // 0xba17ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba17ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba17f0: r0 = invokeCallback()
    //     0xba17f0: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba17f4: r0 = Null
    //     0xba17f4: mov             x0, NULL
    // 0xba17f8: LeaveFrame
    //     0xba17f8: mov             SP, fp
    //     0xba17fc: ldp             fp, lr, [SP], #0x10
    // 0xba1800: ret
    //     0xba1800: ret             
    // 0xba1804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba1808: b               #0xba146c
    // 0xba180c: r9 = _currentSpan
    //     0xba180c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc78] Field <ScaleGestureRecognizer._currentSpan@661213599>: late (offset: 0x4c)
    //     0xba1810: ldr             x9, [x9, #0xc78]
    // 0xba1814: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1814: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xba1818: r9 = _initialSpan
    //     0xba1818: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc80] Field <ScaleGestureRecognizer._initialSpan@661213599>: late (offset: 0x48)
    //     0xba181c: ldr             x9, [x9, #0xc80]
    // 0xba1820: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1820: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xba1824: r0 = NullCastErrorSharedWithFPURegs()
    //     0xba1824: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xba1828: r9 = _initialFocalPoint
    //     0xba1828: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc88] Field <ScaleGestureRecognizer._initialFocalPoint@661213599>: late (offset: 0x40)
    //     0xba182c: ldr             x9, [x9, #0xc88]
    // 0xba1830: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1830: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _dispatchOnStartCallbackIfNeeded(/* No info */) {
    // ** addr: 0xba1834, size: 0x88
    // 0xba1834: EnterFrame
    //     0xba1834: stp             fp, lr, [SP, #-0x10]!
    //     0xba1838: mov             fp, SP
    // 0xba183c: AllocStack(0x20)
    //     0xba183c: sub             SP, SP, #0x20
    // 0xba1840: SetupParameters(ScaleGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xba1840: stur            x1, [fp, #-8]
    // 0xba1844: CheckStackOverflow
    //     0xba1844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1848: cmp             SP, x16
    //     0xba184c: b.ls            #0xba18b4
    // 0xba1850: r1 = 1
    //     0xba1850: mov             x1, #1
    // 0xba1854: r0 = AllocateContext()
    //     0xba1854: bl              #0x13de838  ; AllocateContextStub
    // 0xba1858: mov             x1, x0
    // 0xba185c: ldur            x0, [fp, #-8]
    // 0xba1860: StoreField: r1->field_f = r0
    //     0xba1860: stur            w0, [x1, #0xf]
    // 0xba1864: LoadField: r2 = r0->field_27
    //     0xba1864: ldur            w2, [x0, #0x27]
    // 0xba1868: DecompressPointer r2
    //     0xba1868: add             x2, x2, HEAP, lsl #32
    // 0xba186c: cmp             w2, NULL
    // 0xba1870: b.eq            #0xba189c
    // 0xba1874: mov             x2, x1
    // 0xba1878: r1 = Function '<anonymous closure>':.
    //     0xba1878: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8ccf8] AnonymousClosure: (0xba18bc), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded (0xba1834)
    //     0xba187c: ldr             x1, [x1, #0xcf8]
    // 0xba1880: r0 = AllocateClosure()
    //     0xba1880: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba1884: r16 = <void?>
    //     0xba1884: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba1888: ldur            lr, [fp, #-8]
    // 0xba188c: stp             lr, x16, [SP, #8]
    // 0xba1890: str             x0, [SP]
    // 0xba1894: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba1894: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba1898: r0 = invokeCallback()
    //     0xba1898: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba189c: ldur            x1, [fp, #-8]
    // 0xba18a0: StoreField: r1->field_93 = rNULL
    //     0xba18a0: stur            NULL, [x1, #0x93]
    // 0xba18a4: r0 = Null
    //     0xba18a4: mov             x0, NULL
    // 0xba18a8: LeaveFrame
    //     0xba18a8: mov             SP, fp
    //     0xba18ac: ldp             fp, lr, [SP], #0x10
    // 0xba18b0: ret
    //     0xba18b0: ret             
    // 0xba18b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba18b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba18b8: b               #0xba1850
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba18bc, size: 0x170
    // 0xba18bc: EnterFrame
    //     0xba18bc: stp             fp, lr, [SP, #-0x10]!
    //     0xba18c0: mov             fp, SP
    // 0xba18c4: AllocStack(0x38)
    //     0xba18c4: sub             SP, SP, #0x38
    // 0xba18c8: SetupParameters([dynamic _ /* r0 */])
    //     0xba18c8: ldr             x0, [fp, #0x10]
    //     0xba18cc: ldur            w2, [x0, #0x17]
    //     0xba18d0: add             x2, x2, HEAP, lsl #32
    //     0xba18d4: stur            x2, [fp, #-0x20]
    // 0xba18d8: CheckStackOverflow
    //     0xba18d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba18dc: cmp             SP, x16
    //     0xba18e0: b.ls            #0xba1a10
    // 0xba18e4: LoadField: r1 = r2->field_f
    //     0xba18e4: ldur            w1, [x2, #0xf]
    // 0xba18e8: DecompressPointer r1
    //     0xba18e8: add             x1, x1, HEAP, lsl #32
    // 0xba18ec: LoadField: r0 = r1->field_27
    //     0xba18ec: ldur            w0, [x1, #0x27]
    // 0xba18f0: DecompressPointer r0
    //     0xba18f0: add             x0, x0, HEAP, lsl #32
    // 0xba18f4: stur            x0, [fp, #-0x18]
    // 0xba18f8: cmp             w0, NULL
    // 0xba18fc: b.eq            #0xba1a18
    // 0xba1900: LoadField: r3 = r1->field_43
    //     0xba1900: ldur            w3, [x1, #0x43]
    // 0xba1904: DecompressPointer r3
    //     0xba1904: add             x3, x3, HEAP, lsl #32
    // 0xba1908: stur            x3, [fp, #-0x10]
    // 0xba190c: cmp             w3, NULL
    // 0xba1910: b.eq            #0xba1a1c
    // 0xba1914: LoadField: r4 = r1->field_5f
    //     0xba1914: ldur            w4, [x1, #0x5f]
    // 0xba1918: DecompressPointer r4
    //     0xba1918: add             x4, x4, HEAP, lsl #32
    // 0xba191c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1920: cmp             w4, w16
    // 0xba1924: b.eq            #0xba1a20
    // 0xba1928: stur            x4, [fp, #-8]
    // 0xba192c: r0 = pointerCount()
    //     0xba192c: bl              #0xadf440  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::pointerCount
    // 0xba1930: ldur            x0, [fp, #-0x20]
    // 0xba1934: LoadField: r2 = r0->field_f
    //     0xba1934: ldur            w2, [x0, #0xf]
    // 0xba1938: DecompressPointer r2
    //     0xba1938: add             x2, x2, HEAP, lsl #32
    // 0xba193c: stur            x2, [fp, #-0x28]
    // 0xba1940: LoadField: r1 = r2->field_6f
    //     0xba1940: ldur            w1, [x2, #0x6f]
    // 0xba1944: DecompressPointer r1
    //     0xba1944: add             x1, x1, HEAP, lsl #32
    // 0xba1948: LoadField: r0 = r1->field_b
    //     0xba1948: ldur            w0, [x1, #0xb]
    // 0xba194c: cbz             w0, #0xba196c
    // 0xba1950: r0 = first()
    //     0xba1950: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0xba1954: r2 = LoadInt32Instr(r0)
    //     0xba1954: sbfx            x2, x0, #1, #0x1f
    //     0xba1958: tbz             w0, #0, #0xba1960
    //     0xba195c: ldur            x2, [x0, #7]
    // 0xba1960: ldur            x1, [fp, #-0x28]
    // 0xba1964: r0 = getKindForPointer()
    //     0xba1964: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xba1968: b               #0xba19c8
    // 0xba196c: mov             x0, x2
    // 0xba1970: LoadField: r2 = r0->field_7f
    //     0xba1970: ldur            w2, [x0, #0x7f]
    // 0xba1974: DecompressPointer r2
    //     0xba1974: add             x2, x2, HEAP, lsl #32
    // 0xba1978: stur            x2, [fp, #-0x20]
    // 0xba197c: LoadField: r1 = r2->field_13
    //     0xba197c: ldur            w1, [x2, #0x13]
    // 0xba1980: r3 = LoadInt32Instr(r1)
    //     0xba1980: sbfx            x3, x1, #1, #0x1f
    // 0xba1984: asr             x1, x3, #1
    // 0xba1988: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xba1988: ldur            w3, [x2, #0x17]
    // 0xba198c: r4 = LoadInt32Instr(r3)
    //     0xba198c: sbfx            x4, x3, #1, #0x1f
    // 0xba1990: sub             x3, x1, x4
    // 0xba1994: cbz             x3, #0xba19c8
    // 0xba1998: r1 = <int, _PointerPanZoomData>
    //     0xba1998: add             x1, PP, #0x84, lsl #12  ; [pp+0x84e18] TypeArguments: <int, _PointerPanZoomData>
    //     0xba199c: ldr             x1, [x1, #0xe18]
    // 0xba19a0: r0 = _CompactKeysIterable()
    //     0xba19a0: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xba19a4: mov             x1, x0
    // 0xba19a8: ldur            x0, [fp, #-0x20]
    // 0xba19ac: StoreField: r1->field_b = r0
    //     0xba19ac: stur            w0, [x1, #0xb]
    // 0xba19b0: r0 = first()
    //     0xba19b0: bl              #0xb07084  ; [dart:core] Iterable::first
    // 0xba19b4: r2 = LoadInt32Instr(r0)
    //     0xba19b4: sbfx            x2, x0, #1, #0x1f
    //     0xba19b8: tbz             w0, #0, #0xba19c0
    //     0xba19bc: ldur            x2, [x0, #7]
    // 0xba19c0: ldur            x1, [fp, #-0x28]
    // 0xba19c4: r0 = getKindForPointer()
    //     0xba19c4: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xba19c8: ldur            x0, [fp, #-0x10]
    // 0xba19cc: ldur            x1, [fp, #-8]
    // 0xba19d0: r0 = ScaleStartDetails()
    //     0xba19d0: bl              #0xba1a2c  ; AllocateScaleStartDetailsStub -> ScaleStartDetails (size=0x10)
    // 0xba19d4: mov             x1, x0
    // 0xba19d8: ldur            x0, [fp, #-0x10]
    // 0xba19dc: StoreField: r1->field_7 = r0
    //     0xba19dc: stur            w0, [x1, #7]
    // 0xba19e0: ldur            x0, [fp, #-8]
    // 0xba19e4: StoreField: r1->field_b = r0
    //     0xba19e4: stur            w0, [x1, #0xb]
    // 0xba19e8: ldur            x16, [fp, #-0x18]
    // 0xba19ec: stp             x1, x16, [SP]
    // 0xba19f0: ldur            x0, [fp, #-0x18]
    // 0xba19f4: ClosureCall
    //     0xba19f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba19f8: ldur            x2, [x0, #0x1f]
    //     0xba19fc: blr             x2
    // 0xba1a00: r0 = Null
    //     0xba1a00: mov             x0, NULL
    // 0xba1a04: LeaveFrame
    //     0xba1a04: mov             SP, fp
    //     0xba1a08: ldp             fp, lr, [SP], #0x10
    // 0xba1a0c: ret
    //     0xba1a0c: ret             
    // 0xba1a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1a10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba1a14: b               #0xba18e4
    // 0xba1a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1a18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba1a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1a1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba1a20: r9 = _localFocalPoint
    //     0xba1a20: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc90] Field <ScaleGestureRecognizer._localFocalPoint@661213599>: late (offset: 0x60)
    //     0xba1a24: ldr             x9, [x9, #0xc90]
    // 0xba1a28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba1a28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _pointerScaleFactor(/* No info */) {
    // ** addr: 0xba1a38, size: 0x78
    // 0xba1a38: EnterFrame
    //     0xba1a38: stp             fp, lr, [SP, #-0x10]!
    //     0xba1a3c: mov             fp, SP
    // 0xba1a40: d1 = 0.000000
    //     0xba1a40: eor             v1.16b, v1.16b, v1.16b
    // 0xba1a44: LoadField: r0 = r1->field_47
    //     0xba1a44: ldur            w0, [x1, #0x47]
    // 0xba1a48: DecompressPointer r0
    //     0xba1a48: add             x0, x0, HEAP, lsl #32
    // 0xba1a4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1a50: cmp             w0, w16
    // 0xba1a54: b.eq            #0xba1a98
    // 0xba1a58: LoadField: d2 = r0->field_7
    //     0xba1a58: ldur            d2, [x0, #7]
    // 0xba1a5c: fcmp            d2, d1
    // 0xba1a60: b.le            #0xba1a88
    // 0xba1a64: LoadField: r0 = r1->field_4b
    //     0xba1a64: ldur            w0, [x1, #0x4b]
    // 0xba1a68: DecompressPointer r0
    //     0xba1a68: add             x0, x0, HEAP, lsl #32
    // 0xba1a6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1a70: cmp             w0, w16
    // 0xba1a74: b.eq            #0xba1aa4
    // 0xba1a78: LoadField: d1 = r0->field_7
    //     0xba1a78: ldur            d1, [x0, #7]
    // 0xba1a7c: fdiv            d3, d1, d2
    // 0xba1a80: mov             v0.16b, v3.16b
    // 0xba1a84: b               #0xba1a8c
    // 0xba1a88: d0 = 1.000000
    //     0xba1a88: fmov            d0, #1.00000000
    // 0xba1a8c: LeaveFrame
    //     0xba1a8c: mov             SP, fp
    //     0xba1a90: ldp             fp, lr, [SP], #0x10
    // 0xba1a94: ret
    //     0xba1a94: ret             
    // 0xba1a98: r9 = _initialSpan
    //     0xba1a98: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc80] Field <ScaleGestureRecognizer._initialSpan@661213599>: late (offset: 0x48)
    //     0xba1a9c: ldr             x9, [x9, #0xc80]
    // 0xba1aa0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1aa0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xba1aa4: r9 = _currentSpan
    //     0xba1aa4: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc78] Field <ScaleGestureRecognizer._currentSpan@661213599>: late (offset: 0x4c)
    //     0xba1aa8: ldr             x9, [x9, #0xc78]
    // 0xba1aac: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1aac: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba1ab0, size: 0x178
    // 0xba1ab0: EnterFrame
    //     0xba1ab0: stp             fp, lr, [SP, #-0x10]!
    //     0xba1ab4: mov             fp, SP
    // 0xba1ab8: AllocStack(0x40)
    //     0xba1ab8: sub             SP, SP, #0x40
    // 0xba1abc: SetupParameters([dynamic _ /* r0 */])
    //     0xba1abc: ldr             x0, [fp, #0x10]
    //     0xba1ac0: ldur            w2, [x0, #0x17]
    //     0xba1ac4: add             x2, x2, HEAP, lsl #32
    //     0xba1ac8: stur            x2, [fp, #-0x10]
    // 0xba1acc: CheckStackOverflow
    //     0xba1acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1ad0: cmp             SP, x16
    //     0xba1ad4: b.ls            #0xba1c00
    // 0xba1ad8: LoadField: r1 = r2->field_f
    //     0xba1ad8: ldur            w1, [x2, #0xf]
    // 0xba1adc: DecompressPointer r1
    //     0xba1adc: add             x1, x1, HEAP, lsl #32
    // 0xba1ae0: LoadField: r0 = r1->field_2b
    //     0xba1ae0: ldur            w0, [x1, #0x2b]
    // 0xba1ae4: DecompressPointer r0
    //     0xba1ae4: add             x0, x0, HEAP, lsl #32
    // 0xba1ae8: stur            x0, [fp, #-8]
    // 0xba1aec: cmp             w0, NULL
    // 0xba1af0: b.eq            #0xba1c08
    // 0xba1af4: r0 = _scaleFactor()
    //     0xba1af4: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xba1af8: ldur            x0, [fp, #-0x10]
    // 0xba1afc: stur            d0, [fp, #-0x28]
    // 0xba1b00: LoadField: r1 = r0->field_f
    //     0xba1b00: ldur            w1, [x0, #0xf]
    // 0xba1b04: DecompressPointer r1
    //     0xba1b04: add             x1, x1, HEAP, lsl #32
    // 0xba1b08: r0 = _horizontalScaleFactor()
    //     0xba1b08: bl              #0xba2000  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_horizontalScaleFactor
    // 0xba1b0c: ldur            x0, [fp, #-0x10]
    // 0xba1b10: LoadField: r1 = r0->field_f
    //     0xba1b10: ldur            w1, [x0, #0xf]
    // 0xba1b14: DecompressPointer r1
    //     0xba1b14: add             x1, x1, HEAP, lsl #32
    // 0xba1b18: r0 = _verticalScaleFactor()
    //     0xba1b18: bl              #0xba1e64  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_verticalScaleFactor
    // 0xba1b1c: ldur            x0, [fp, #-0x10]
    // 0xba1b20: LoadField: r1 = r0->field_f
    //     0xba1b20: ldur            w1, [x0, #0xf]
    // 0xba1b24: DecompressPointer r1
    //     0xba1b24: add             x1, x1, HEAP, lsl #32
    // 0xba1b28: LoadField: r2 = r1->field_43
    //     0xba1b28: ldur            w2, [x1, #0x43]
    // 0xba1b2c: DecompressPointer r2
    //     0xba1b2c: add             x2, x2, HEAP, lsl #32
    // 0xba1b30: stur            x2, [fp, #-0x20]
    // 0xba1b34: cmp             w2, NULL
    // 0xba1b38: b.eq            #0xba1c0c
    // 0xba1b3c: LoadField: r3 = r1->field_5f
    //     0xba1b3c: ldur            w3, [x1, #0x5f]
    // 0xba1b40: DecompressPointer r3
    //     0xba1b40: add             x3, x3, HEAP, lsl #32
    // 0xba1b44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1b48: cmp             w3, w16
    // 0xba1b4c: b.eq            #0xba1c10
    // 0xba1b50: stur            x3, [fp, #-0x18]
    // 0xba1b54: r0 = _computeRotationFactor()
    //     0xba1b54: bl              #0xba1c34  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_computeRotationFactor
    // 0xba1b58: ldur            x0, [fp, #-0x10]
    // 0xba1b5c: stur            d0, [fp, #-0x30]
    // 0xba1b60: LoadField: r1 = r0->field_f
    //     0xba1b60: ldur            w1, [x0, #0xf]
    // 0xba1b64: DecompressPointer r1
    //     0xba1b64: add             x1, x1, HEAP, lsl #32
    // 0xba1b68: r0 = pointerCount()
    //     0xba1b68: bl              #0xadf440  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::pointerCount
    // 0xba1b6c: ldur            x0, [fp, #-0x10]
    // 0xba1b70: LoadField: r1 = r0->field_f
    //     0xba1b70: ldur            w1, [x0, #0xf]
    // 0xba1b74: DecompressPointer r1
    //     0xba1b74: add             x1, x1, HEAP, lsl #32
    // 0xba1b78: LoadField: r2 = r1->field_7b
    //     0xba1b78: ldur            w2, [x1, #0x7b]
    // 0xba1b7c: DecompressPointer r2
    //     0xba1b7c: add             x2, x2, HEAP, lsl #32
    // 0xba1b80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1b84: cmp             w2, w16
    // 0xba1b88: b.eq            #0xba1c1c
    // 0xba1b8c: LoadField: r1 = r0->field_13
    //     0xba1b8c: ldur            w1, [x0, #0x13]
    // 0xba1b90: DecompressPointer r1
    //     0xba1b90: add             x1, x1, HEAP, lsl #32
    // 0xba1b94: r0 = LoadClassIdInstr(r1)
    //     0xba1b94: ldur            x0, [x1, #-1]
    //     0xba1b98: ubfx            x0, x0, #0xc, #0x14
    // 0xba1b9c: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba1b9c: mov             x17, #0x5eb5
    //     0xba1ba0: movk            x17, #1, lsl #16
    //     0xba1ba4: add             lr, x0, x17
    //     0xba1ba8: ldr             lr, [x21, lr, lsl #3]
    //     0xba1bac: blr             lr
    // 0xba1bb0: r0 = ScaleUpdateDetails()
    //     0xba1bb0: bl              #0xba1c28  ; AllocateScaleUpdateDetailsStub -> ScaleUpdateDetails (size=0x20)
    // 0xba1bb4: mov             x1, x0
    // 0xba1bb8: ldur            x0, [fp, #-0x20]
    // 0xba1bbc: StoreField: r1->field_7 = r0
    //     0xba1bbc: stur            w0, [x1, #7]
    // 0xba1bc0: ldur            d0, [fp, #-0x28]
    // 0xba1bc4: StoreField: r1->field_f = d0
    //     0xba1bc4: stur            d0, [x1, #0xf]
    // 0xba1bc8: ldur            d0, [fp, #-0x30]
    // 0xba1bcc: ArrayStore: r1[0] = d0  ; List_8
    //     0xba1bcc: stur            d0, [x1, #0x17]
    // 0xba1bd0: ldur            x0, [fp, #-0x18]
    // 0xba1bd4: StoreField: r1->field_b = r0
    //     0xba1bd4: stur            w0, [x1, #0xb]
    // 0xba1bd8: ldur            x16, [fp, #-8]
    // 0xba1bdc: stp             x1, x16, [SP]
    // 0xba1be0: ldur            x0, [fp, #-8]
    // 0xba1be4: ClosureCall
    //     0xba1be4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba1be8: ldur            x2, [x0, #0x1f]
    //     0xba1bec: blr             x2
    // 0xba1bf0: r0 = Null
    //     0xba1bf0: mov             x0, NULL
    // 0xba1bf4: LeaveFrame
    //     0xba1bf4: mov             SP, fp
    //     0xba1bf8: ldp             fp, lr, [SP], #0x10
    // 0xba1bfc: ret
    //     0xba1bfc: ret             
    // 0xba1c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba1c04: b               #0xba1ad8
    // 0xba1c08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1c08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba1c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba1c0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba1c10: r9 = _localFocalPoint
    //     0xba1c10: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc90] Field <ScaleGestureRecognizer._localFocalPoint@661213599>: late (offset: 0x60)
    //     0xba1c14: ldr             x9, [x9, #0xc90]
    // 0xba1c18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba1c18: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xba1c1c: r9 = _delta
    //     0xba1c1c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc98] Field <ScaleGestureRecognizer._delta@661213599>: late (offset: 0x7c)
    //     0xba1c20: ldr             x9, [x9, #0xc98]
    // 0xba1c24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba1c24: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _computeRotationFactor(/* No info */) {
    // ** addr: 0xba1c34, size: 0x230
    // 0xba1c34: EnterFrame
    //     0xba1c34: stp             fp, lr, [SP, #-0x10]!
    //     0xba1c38: mov             fp, SP
    // 0xba1c3c: AllocStack(0x48)
    //     0xba1c3c: sub             SP, SP, #0x48
    // 0xba1c40: SetupParameters(ScaleGestureRecognizer this /* r1 => r19, fp-0x10 */)
    //     0xba1c40: mov             x19, x1
    //     0xba1c44: stur            x1, [fp, #-0x10]
    // 0xba1c48: CheckStackOverflow
    //     0xba1c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1c4c: cmp             SP, x16
    //     0xba1c50: b.ls            #0xba1e54
    // 0xba1c54: LoadField: r0 = r19->field_63
    //     0xba1c54: ldur            w0, [x19, #0x63]
    // 0xba1c58: DecompressPointer r0
    //     0xba1c58: add             x0, x0, HEAP, lsl #32
    // 0xba1c5c: cmp             w0, NULL
    // 0xba1c60: b.eq            #0xba1d74
    // 0xba1c64: LoadField: r1 = r19->field_67
    //     0xba1c64: ldur            w1, [x19, #0x67]
    // 0xba1c68: DecompressPointer r1
    //     0xba1c68: add             x1, x1, HEAP, lsl #32
    // 0xba1c6c: cmp             w1, NULL
    // 0xba1c70: b.eq            #0xba1d74
    // 0xba1c74: LoadField: r2 = r0->field_7
    //     0xba1c74: ldur            w2, [x0, #7]
    // 0xba1c78: DecompressPointer r2
    //     0xba1c78: add             x2, x2, HEAP, lsl #32
    // 0xba1c7c: LoadField: d0 = r2->field_7
    //     0xba1c7c: ldur            d0, [x2, #7]
    // 0xba1c80: LoadField: d1 = r2->field_f
    //     0xba1c80: ldur            d1, [x2, #0xf]
    // 0xba1c84: LoadField: r2 = r0->field_13
    //     0xba1c84: ldur            w2, [x0, #0x13]
    // 0xba1c88: DecompressPointer r2
    //     0xba1c88: add             x2, x2, HEAP, lsl #32
    // 0xba1c8c: LoadField: d2 = r2->field_7
    //     0xba1c8c: ldur            d2, [x2, #7]
    // 0xba1c90: LoadField: d3 = r2->field_f
    //     0xba1c90: ldur            d3, [x2, #0xf]
    // 0xba1c94: LoadField: r0 = r1->field_7
    //     0xba1c94: ldur            w0, [x1, #7]
    // 0xba1c98: DecompressPointer r0
    //     0xba1c98: add             x0, x0, HEAP, lsl #32
    // 0xba1c9c: LoadField: d4 = r0->field_7
    //     0xba1c9c: ldur            d4, [x0, #7]
    // 0xba1ca0: stur            d4, [fp, #-0x40]
    // 0xba1ca4: LoadField: d5 = r0->field_f
    //     0xba1ca4: ldur            d5, [x0, #0xf]
    // 0xba1ca8: stur            d5, [fp, #-0x38]
    // 0xba1cac: LoadField: r0 = r1->field_13
    //     0xba1cac: ldur            w0, [x1, #0x13]
    // 0xba1cb0: DecompressPointer r0
    //     0xba1cb0: add             x0, x0, HEAP, lsl #32
    // 0xba1cb4: LoadField: d6 = r0->field_7
    //     0xba1cb4: ldur            d6, [x0, #7]
    // 0xba1cb8: stur            d6, [fp, #-0x30]
    // 0xba1cbc: LoadField: d7 = r0->field_f
    //     0xba1cbc: ldur            d7, [x0, #0xf]
    // 0xba1cc0: stur            d7, [fp, #-0x28]
    // 0xba1cc4: fsub            d8, d1, d3
    // 0xba1cc8: fsub            d1, d0, d2
    // 0xba1ccc: mov             v0.16b, v8.16b
    // 0xba1cd0: stp             fp, lr, [SP, #-0x10]!
    // 0xba1cd4: mov             fp, SP
    // 0xba1cd8: CallRuntime_LibcAtan2(double, double) -> double
    //     0xba1cd8: and             SP, SP, #0xfffffffffffffff0
    //     0xba1cdc: mov             sp, SP
    //     0xba1ce0: ldr             x16, [THR, #0x7a8]  ; THR::LibcAtan2
    //     0xba1ce4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xba1ce8: blr             x16
    //     0xba1cec: mov             x16, #8
    //     0xba1cf0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xba1cf4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xba1cf8: sub             sp, x16, #1, lsl #12
    //     0xba1cfc: mov             SP, fp
    //     0xba1d00: ldp             fp, lr, [SP], #0x10
    // 0xba1d04: mov             v2.16b, v0.16b
    // 0xba1d08: ldur            d0, [fp, #-0x38]
    // 0xba1d0c: ldur            d1, [fp, #-0x28]
    // 0xba1d10: stur            d2, [fp, #-0x48]
    // 0xba1d14: fsub            d3, d0, d1
    // 0xba1d18: ldur            d0, [fp, #-0x40]
    // 0xba1d1c: ldur            d1, [fp, #-0x30]
    // 0xba1d20: fsub            d4, d0, d1
    // 0xba1d24: mov             v0.16b, v3.16b
    // 0xba1d28: mov             v1.16b, v4.16b
    // 0xba1d2c: stp             fp, lr, [SP, #-0x10]!
    // 0xba1d30: mov             fp, SP
    // 0xba1d34: CallRuntime_LibcAtan2(double, double) -> double
    //     0xba1d34: and             SP, SP, #0xfffffffffffffff0
    //     0xba1d38: mov             sp, SP
    //     0xba1d3c: ldr             x16, [THR, #0x7a8]  ; THR::LibcAtan2
    //     0xba1d40: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xba1d44: blr             x16
    //     0xba1d48: mov             x16, #8
    //     0xba1d4c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xba1d50: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xba1d54: sub             sp, x16, #1, lsl #12
    //     0xba1d58: mov             SP, fp
    //     0xba1d5c: ldp             fp, lr, [SP], #0x10
    // 0xba1d60: mov             v1.16b, v0.16b
    // 0xba1d64: ldur            d0, [fp, #-0x48]
    // 0xba1d68: fsub            d2, d1, d0
    // 0xba1d6c: mov             v0.16b, v2.16b
    // 0xba1d70: b               #0xba1d78
    // 0xba1d74: d0 = 0.000000
    //     0xba1d74: eor             v0.16b, v0.16b, v0.16b
    // 0xba1d78: stur            d0, [fp, #-0x28]
    // 0xba1d7c: LoadField: r0 = r19->field_7f
    //     0xba1d7c: ldur            w0, [x19, #0x7f]
    // 0xba1d80: DecompressPointer r0
    //     0xba1d80: add             x0, x0, HEAP, lsl #32
    // 0xba1d84: stur            x0, [fp, #-8]
    // 0xba1d88: r1 = <_PointerPanZoomData>
    //     0xba1d88: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xba1d8c: ldr             x1, [x1, #0xca0]
    // 0xba1d90: r0 = _CompactValuesIterable()
    //     0xba1d90: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba1d94: mov             x1, x0
    // 0xba1d98: ldur            x0, [fp, #-8]
    // 0xba1d9c: StoreField: r1->field_b = r0
    //     0xba1d9c: stur            w0, [x1, #0xb]
    // 0xba1da0: r0 = iterator()
    //     0xba1da0: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xba1da4: stur            x0, [fp, #-0x18]
    // 0xba1da8: LoadField: r2 = r0->field_7
    //     0xba1da8: ldur            w2, [x0, #7]
    // 0xba1dac: DecompressPointer r2
    //     0xba1dac: add             x2, x2, HEAP, lsl #32
    // 0xba1db0: stur            x2, [fp, #-8]
    // 0xba1db4: ldur            d0, [fp, #-0x28]
    // 0xba1db8: stur            d0, [fp, #-0x28]
    // 0xba1dbc: CheckStackOverflow
    //     0xba1dbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1dc0: cmp             SP, x16
    //     0xba1dc4: b.ls            #0xba1e5c
    // 0xba1dc8: mov             x1, x0
    // 0xba1dcc: r0 = moveNext()
    //     0xba1dcc: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba1dd0: tbnz            w0, #4, #0xba1e38
    // 0xba1dd4: ldur            x3, [fp, #-0x18]
    // 0xba1dd8: LoadField: r4 = r3->field_33
    //     0xba1dd8: ldur            w4, [x3, #0x33]
    // 0xba1ddc: DecompressPointer r4
    //     0xba1ddc: add             x4, x4, HEAP, lsl #32
    // 0xba1de0: stur            x4, [fp, #-0x20]
    // 0xba1de4: cmp             w4, NULL
    // 0xba1de8: b.ne            #0xba1e1c
    // 0xba1dec: mov             x0, x4
    // 0xba1df0: ldur            x2, [fp, #-8]
    // 0xba1df4: r1 = Null
    //     0xba1df4: mov             x1, NULL
    // 0xba1df8: cmp             w2, NULL
    // 0xba1dfc: b.eq            #0xba1e1c
    // 0xba1e00: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba1e00: ldur            w4, [x2, #0x17]
    // 0xba1e04: DecompressPointer r4
    //     0xba1e04: add             x4, x4, HEAP, lsl #32
    // 0xba1e08: r8 = X0
    //     0xba1e08: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba1e0c: LoadField: r9 = r4->field_7
    //     0xba1e0c: ldur            x9, [x4, #7]
    // 0xba1e10: r3 = Null
    //     0xba1e10: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cca8] Null
    //     0xba1e14: ldr             x3, [x3, #0xca8]
    // 0xba1e18: blr             x9
    // 0xba1e1c: ldur            d1, [fp, #-0x28]
    // 0xba1e20: ldur            x0, [fp, #-0x20]
    // 0xba1e24: LoadField: d2 = r0->field_1b
    //     0xba1e24: ldur            d2, [x0, #0x1b]
    // 0xba1e28: fadd            d0, d1, d2
    // 0xba1e2c: ldur            x0, [fp, #-0x18]
    // 0xba1e30: ldur            x2, [fp, #-8]
    // 0xba1e34: b               #0xba1db8
    // 0xba1e38: ldur            x0, [fp, #-0x10]
    // 0xba1e3c: ldur            d1, [fp, #-0x28]
    // 0xba1e40: LoadField: d2 = r0->field_8b
    //     0xba1e40: ldur            d2, [x0, #0x8b]
    // 0xba1e44: fsub            d0, d1, d2
    // 0xba1e48: LeaveFrame
    //     0xba1e48: mov             SP, fp
    //     0xba1e4c: ldp             fp, lr, [SP], #0x10
    // 0xba1e50: ret
    //     0xba1e50: ret             
    // 0xba1e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba1e58: b               #0xba1c54
    // 0xba1e5c: r0 = StackOverflowSharedWithFPURegs()
    //     0xba1e5c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xba1e60: b               #0xba1dc8
  }
  get _ _verticalScaleFactor(/* No info */) {
    // ** addr: 0xba1e64, size: 0x124
    // 0xba1e64: EnterFrame
    //     0xba1e64: stp             fp, lr, [SP, #-0x10]!
    //     0xba1e68: mov             fp, SP
    // 0xba1e6c: AllocStack(0x28)
    //     0xba1e6c: sub             SP, SP, #0x28
    // 0xba1e70: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba1e70: mov             x0, x1
    //     0xba1e74: stur            x1, [fp, #-8]
    // 0xba1e78: CheckStackOverflow
    //     0xba1e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1e7c: cmp             SP, x16
    //     0xba1e80: b.ls            #0xba1f78
    // 0xba1e84: mov             x1, x0
    // 0xba1e88: r0 = _pointerVerticalScaleFactor()
    //     0xba1e88: bl              #0xba1f88  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerVerticalScaleFactor
    // 0xba1e8c: ldur            x0, [fp, #-8]
    // 0xba1e90: stur            d0, [fp, #-0x28]
    // 0xba1e94: LoadField: r2 = r0->field_7f
    //     0xba1e94: ldur            w2, [x0, #0x7f]
    // 0xba1e98: DecompressPointer r2
    //     0xba1e98: add             x2, x2, HEAP, lsl #32
    // 0xba1e9c: stur            x2, [fp, #-0x10]
    // 0xba1ea0: r1 = <_PointerPanZoomData>
    //     0xba1ea0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xba1ea4: ldr             x1, [x1, #0xca0]
    // 0xba1ea8: r0 = _CompactValuesIterable()
    //     0xba1ea8: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba1eac: mov             x1, x0
    // 0xba1eb0: ldur            x0, [fp, #-0x10]
    // 0xba1eb4: StoreField: r1->field_b = r0
    //     0xba1eb4: stur            w0, [x1, #0xb]
    // 0xba1eb8: r0 = iterator()
    //     0xba1eb8: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xba1ebc: stur            x0, [fp, #-0x18]
    // 0xba1ec0: LoadField: r2 = r0->field_7
    //     0xba1ec0: ldur            w2, [x0, #7]
    // 0xba1ec4: DecompressPointer r2
    //     0xba1ec4: add             x2, x2, HEAP, lsl #32
    // 0xba1ec8: stur            x2, [fp, #-0x10]
    // 0xba1ecc: ldur            d0, [fp, #-0x28]
    // 0xba1ed0: ldur            x3, [fp, #-8]
    // 0xba1ed4: stur            d0, [fp, #-0x28]
    // 0xba1ed8: CheckStackOverflow
    //     0xba1ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba1edc: cmp             SP, x16
    //     0xba1ee0: b.ls            #0xba1f80
    // 0xba1ee4: mov             x1, x0
    // 0xba1ee8: r0 = moveNext()
    //     0xba1ee8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba1eec: tbnz            w0, #4, #0xba1f68
    // 0xba1ef0: ldur            x3, [fp, #-0x18]
    // 0xba1ef4: LoadField: r4 = r3->field_33
    //     0xba1ef4: ldur            w4, [x3, #0x33]
    // 0xba1ef8: DecompressPointer r4
    //     0xba1ef8: add             x4, x4, HEAP, lsl #32
    // 0xba1efc: stur            x4, [fp, #-0x20]
    // 0xba1f00: cmp             w4, NULL
    // 0xba1f04: b.ne            #0xba1f38
    // 0xba1f08: mov             x0, x4
    // 0xba1f0c: ldur            x2, [fp, #-0x10]
    // 0xba1f10: r1 = Null
    //     0xba1f10: mov             x1, NULL
    // 0xba1f14: cmp             w2, NULL
    // 0xba1f18: b.eq            #0xba1f38
    // 0xba1f1c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba1f1c: ldur            w4, [x2, #0x17]
    // 0xba1f20: DecompressPointer r4
    //     0xba1f20: add             x4, x4, HEAP, lsl #32
    // 0xba1f24: r8 = X0
    //     0xba1f24: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba1f28: LoadField: r9 = r4->field_7
    //     0xba1f28: ldur            x9, [x4, #7]
    // 0xba1f2c: r3 = Null
    //     0xba1f2c: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ccb8] Null
    //     0xba1f30: ldr             x3, [x3, #0xcb8]
    // 0xba1f34: blr             x9
    // 0xba1f38: ldur            x1, [fp, #-8]
    // 0xba1f3c: ldur            d0, [fp, #-0x28]
    // 0xba1f40: ldur            x0, [fp, #-0x20]
    // 0xba1f44: LoadField: d1 = r0->field_13
    //     0xba1f44: ldur            d1, [x0, #0x13]
    // 0xba1f48: LoadField: d2 = r1->field_83
    //     0xba1f48: ldur            d2, [x1, #0x83]
    // 0xba1f4c: fdiv            d3, d1, d2
    // 0xba1f50: fmul            d1, d0, d3
    // 0xba1f54: mov             v0.16b, v1.16b
    // 0xba1f58: mov             x3, x1
    // 0xba1f5c: ldur            x0, [fp, #-0x18]
    // 0xba1f60: ldur            x2, [fp, #-0x10]
    // 0xba1f64: b               #0xba1ed4
    // 0xba1f68: ldur            d0, [fp, #-0x28]
    // 0xba1f6c: LeaveFrame
    //     0xba1f6c: mov             SP, fp
    //     0xba1f70: ldp             fp, lr, [SP], #0x10
    // 0xba1f74: ret
    //     0xba1f74: ret             
    // 0xba1f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba1f78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba1f7c: b               #0xba1e84
    // 0xba1f80: r0 = StackOverflowSharedWithFPURegs()
    //     0xba1f80: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xba1f84: b               #0xba1ee4
  }
  get _ _pointerVerticalScaleFactor(/* No info */) {
    // ** addr: 0xba1f88, size: 0x78
    // 0xba1f88: EnterFrame
    //     0xba1f88: stp             fp, lr, [SP, #-0x10]!
    //     0xba1f8c: mov             fp, SP
    // 0xba1f90: d1 = 0.000000
    //     0xba1f90: eor             v1.16b, v1.16b, v1.16b
    // 0xba1f94: LoadField: r0 = r1->field_57
    //     0xba1f94: ldur            w0, [x1, #0x57]
    // 0xba1f98: DecompressPointer r0
    //     0xba1f98: add             x0, x0, HEAP, lsl #32
    // 0xba1f9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1fa0: cmp             w0, w16
    // 0xba1fa4: b.eq            #0xba1fe8
    // 0xba1fa8: LoadField: d2 = r0->field_7
    //     0xba1fa8: ldur            d2, [x0, #7]
    // 0xba1fac: fcmp            d2, d1
    // 0xba1fb0: b.le            #0xba1fd8
    // 0xba1fb4: LoadField: r0 = r1->field_5b
    //     0xba1fb4: ldur            w0, [x1, #0x5b]
    // 0xba1fb8: DecompressPointer r0
    //     0xba1fb8: add             x0, x0, HEAP, lsl #32
    // 0xba1fbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba1fc0: cmp             w0, w16
    // 0xba1fc4: b.eq            #0xba1ff4
    // 0xba1fc8: LoadField: d1 = r0->field_7
    //     0xba1fc8: ldur            d1, [x0, #7]
    // 0xba1fcc: fdiv            d3, d1, d2
    // 0xba1fd0: mov             v0.16b, v3.16b
    // 0xba1fd4: b               #0xba1fdc
    // 0xba1fd8: d0 = 1.000000
    //     0xba1fd8: fmov            d0, #1.00000000
    // 0xba1fdc: LeaveFrame
    //     0xba1fdc: mov             SP, fp
    //     0xba1fe0: ldp             fp, lr, [SP], #0x10
    // 0xba1fe4: ret
    //     0xba1fe4: ret             
    // 0xba1fe8: r9 = _initialVerticalSpan
    //     0xba1fe8: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccc8] Field <ScaleGestureRecognizer._initialVerticalSpan@661213599>: late (offset: 0x58)
    //     0xba1fec: ldr             x9, [x9, #0xcc8]
    // 0xba1ff0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1ff0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xba1ff4: r9 = _currentVerticalSpan
    //     0xba1ff4: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccd0] Field <ScaleGestureRecognizer._currentVerticalSpan@661213599>: late (offset: 0x5c)
    //     0xba1ff8: ldr             x9, [x9, #0xcd0]
    // 0xba1ffc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba1ffc: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  get _ _horizontalScaleFactor(/* No info */) {
    // ** addr: 0xba2000, size: 0x124
    // 0xba2000: EnterFrame
    //     0xba2000: stp             fp, lr, [SP, #-0x10]!
    //     0xba2004: mov             fp, SP
    // 0xba2008: AllocStack(0x28)
    //     0xba2008: sub             SP, SP, #0x28
    // 0xba200c: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba200c: mov             x0, x1
    //     0xba2010: stur            x1, [fp, #-8]
    // 0xba2014: CheckStackOverflow
    //     0xba2014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2018: cmp             SP, x16
    //     0xba201c: b.ls            #0xba2114
    // 0xba2020: mov             x1, x0
    // 0xba2024: r0 = _pointerHorizontalScaleFactor()
    //     0xba2024: bl              #0xba2124  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerHorizontalScaleFactor
    // 0xba2028: ldur            x0, [fp, #-8]
    // 0xba202c: stur            d0, [fp, #-0x28]
    // 0xba2030: LoadField: r2 = r0->field_7f
    //     0xba2030: ldur            w2, [x0, #0x7f]
    // 0xba2034: DecompressPointer r2
    //     0xba2034: add             x2, x2, HEAP, lsl #32
    // 0xba2038: stur            x2, [fp, #-0x10]
    // 0xba203c: r1 = <_PointerPanZoomData>
    //     0xba203c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xba2040: ldr             x1, [x1, #0xca0]
    // 0xba2044: r0 = _CompactValuesIterable()
    //     0xba2044: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba2048: mov             x1, x0
    // 0xba204c: ldur            x0, [fp, #-0x10]
    // 0xba2050: StoreField: r1->field_b = r0
    //     0xba2050: stur            w0, [x1, #0xb]
    // 0xba2054: r0 = iterator()
    //     0xba2054: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xba2058: stur            x0, [fp, #-0x18]
    // 0xba205c: LoadField: r2 = r0->field_7
    //     0xba205c: ldur            w2, [x0, #7]
    // 0xba2060: DecompressPointer r2
    //     0xba2060: add             x2, x2, HEAP, lsl #32
    // 0xba2064: stur            x2, [fp, #-0x10]
    // 0xba2068: ldur            d0, [fp, #-0x28]
    // 0xba206c: ldur            x3, [fp, #-8]
    // 0xba2070: stur            d0, [fp, #-0x28]
    // 0xba2074: CheckStackOverflow
    //     0xba2074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2078: cmp             SP, x16
    //     0xba207c: b.ls            #0xba211c
    // 0xba2080: mov             x1, x0
    // 0xba2084: r0 = moveNext()
    //     0xba2084: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba2088: tbnz            w0, #4, #0xba2104
    // 0xba208c: ldur            x3, [fp, #-0x18]
    // 0xba2090: LoadField: r4 = r3->field_33
    //     0xba2090: ldur            w4, [x3, #0x33]
    // 0xba2094: DecompressPointer r4
    //     0xba2094: add             x4, x4, HEAP, lsl #32
    // 0xba2098: stur            x4, [fp, #-0x20]
    // 0xba209c: cmp             w4, NULL
    // 0xba20a0: b.ne            #0xba20d4
    // 0xba20a4: mov             x0, x4
    // 0xba20a8: ldur            x2, [fp, #-0x10]
    // 0xba20ac: r1 = Null
    //     0xba20ac: mov             x1, NULL
    // 0xba20b0: cmp             w2, NULL
    // 0xba20b4: b.eq            #0xba20d4
    // 0xba20b8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba20b8: ldur            w4, [x2, #0x17]
    // 0xba20bc: DecompressPointer r4
    //     0xba20bc: add             x4, x4, HEAP, lsl #32
    // 0xba20c0: r8 = X0
    //     0xba20c0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba20c4: LoadField: r9 = r4->field_7
    //     0xba20c4: ldur            x9, [x4, #7]
    // 0xba20c8: r3 = Null
    //     0xba20c8: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ccd8] Null
    //     0xba20cc: ldr             x3, [x3, #0xcd8]
    // 0xba20d0: blr             x9
    // 0xba20d4: ldur            x1, [fp, #-8]
    // 0xba20d8: ldur            d0, [fp, #-0x28]
    // 0xba20dc: ldur            x0, [fp, #-0x20]
    // 0xba20e0: LoadField: d1 = r0->field_13
    //     0xba20e0: ldur            d1, [x0, #0x13]
    // 0xba20e4: LoadField: d2 = r1->field_83
    //     0xba20e4: ldur            d2, [x1, #0x83]
    // 0xba20e8: fdiv            d3, d1, d2
    // 0xba20ec: fmul            d1, d0, d3
    // 0xba20f0: mov             v0.16b, v1.16b
    // 0xba20f4: mov             x3, x1
    // 0xba20f8: ldur            x0, [fp, #-0x18]
    // 0xba20fc: ldur            x2, [fp, #-0x10]
    // 0xba2100: b               #0xba2070
    // 0xba2104: ldur            d0, [fp, #-0x28]
    // 0xba2108: LeaveFrame
    //     0xba2108: mov             SP, fp
    //     0xba210c: ldp             fp, lr, [SP], #0x10
    // 0xba2110: ret
    //     0xba2110: ret             
    // 0xba2114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2118: b               #0xba2020
    // 0xba211c: r0 = StackOverflowSharedWithFPURegs()
    //     0xba211c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xba2120: b               #0xba2080
  }
  get _ _pointerHorizontalScaleFactor(/* No info */) {
    // ** addr: 0xba2124, size: 0x78
    // 0xba2124: EnterFrame
    //     0xba2124: stp             fp, lr, [SP, #-0x10]!
    //     0xba2128: mov             fp, SP
    // 0xba212c: d1 = 0.000000
    //     0xba212c: eor             v1.16b, v1.16b, v1.16b
    // 0xba2130: LoadField: r0 = r1->field_4f
    //     0xba2130: ldur            w0, [x1, #0x4f]
    // 0xba2134: DecompressPointer r0
    //     0xba2134: add             x0, x0, HEAP, lsl #32
    // 0xba2138: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba213c: cmp             w0, w16
    // 0xba2140: b.eq            #0xba2184
    // 0xba2144: LoadField: d2 = r0->field_7
    //     0xba2144: ldur            d2, [x0, #7]
    // 0xba2148: fcmp            d2, d1
    // 0xba214c: b.le            #0xba2174
    // 0xba2150: LoadField: r0 = r1->field_53
    //     0xba2150: ldur            w0, [x1, #0x53]
    // 0xba2154: DecompressPointer r0
    //     0xba2154: add             x0, x0, HEAP, lsl #32
    // 0xba2158: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba215c: cmp             w0, w16
    // 0xba2160: b.eq            #0xba2190
    // 0xba2164: LoadField: d1 = r0->field_7
    //     0xba2164: ldur            d1, [x0, #7]
    // 0xba2168: fdiv            d3, d1, d2
    // 0xba216c: mov             v0.16b, v3.16b
    // 0xba2170: b               #0xba2178
    // 0xba2174: d0 = 1.000000
    //     0xba2174: fmov            d0, #1.00000000
    // 0xba2178: LeaveFrame
    //     0xba2178: mov             SP, fp
    //     0xba217c: ldp             fp, lr, [SP], #0x10
    // 0xba2180: ret
    //     0xba2180: ret             
    // 0xba2184: r9 = _initialHorizontalSpan
    //     0xba2184: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cce8] Field <ScaleGestureRecognizer._initialHorizontalSpan@661213599>: late (offset: 0x50)
    //     0xba2188: ldr             x9, [x9, #0xce8]
    // 0xba218c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba218c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xba2190: r9 = _currentHorizontalSpan
    //     0xba2190: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccf0] Field <ScaleGestureRecognizer._currentHorizontalSpan@661213599>: late (offset: 0x54)
    //     0xba2194: ldr             x9, [x9, #0xcf0]
    // 0xba2198: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xba2198: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _update(/* No info */) {
    // ** addr: 0xba219c, size: 0x944
    // 0xba219c: EnterFrame
    //     0xba219c: stp             fp, lr, [SP, #-0x10]!
    //     0xba21a0: mov             fp, SP
    // 0xba21a4: AllocStack(0x90)
    //     0xba21a4: sub             SP, SP, #0x90
    // 0xba21a8: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x18 */)
    //     0xba21a8: mov             x0, x1
    //     0xba21ac: stur            x1, [fp, #-0x18]
    // 0xba21b0: CheckStackOverflow
    //     0xba21b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba21b4: cmp             SP, x16
    //     0xba21b8: b.ls            #0xba2a48
    // 0xba21bc: LoadField: r2 = r0->field_43
    //     0xba21bc: ldur            w2, [x0, #0x43]
    // 0xba21c0: DecompressPointer r2
    //     0xba21c0: add             x2, x2, HEAP, lsl #32
    // 0xba21c4: stur            x2, [fp, #-0x10]
    // 0xba21c8: LoadField: r3 = r0->field_6b
    //     0xba21c8: ldur            w3, [x0, #0x6b]
    // 0xba21cc: DecompressPointer r3
    //     0xba21cc: add             x3, x3, HEAP, lsl #32
    // 0xba21d0: stur            x3, [fp, #-8]
    // 0xba21d4: r1 = <int, Offset>
    //     0xba21d4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xba21d8: ldr             x1, [x1, #0x540]
    // 0xba21dc: r0 = _CompactKeysIterable()
    //     0xba21dc: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xba21e0: mov             x1, x0
    // 0xba21e4: ldur            x0, [fp, #-8]
    // 0xba21e8: StoreField: r1->field_b = r0
    //     0xba21e8: stur            w0, [x1, #0xb]
    // 0xba21ec: r0 = iterator()
    //     0xba21ec: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xba21f0: stur            x0, [fp, #-0x30]
    // 0xba21f4: LoadField: r2 = r0->field_7
    //     0xba21f4: ldur            w2, [x0, #7]
    // 0xba21f8: DecompressPointer r2
    //     0xba21f8: add             x2, x2, HEAP, lsl #32
    // 0xba21fc: stur            x2, [fp, #-0x28]
    // 0xba2200: r4 = Instance_Offset
    //     0xba2200: ldr             x4, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xba2204: ldur            x3, [fp, #-8]
    // 0xba2208: stur            x4, [fp, #-0x20]
    // 0xba220c: CheckStackOverflow
    //     0xba220c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2210: cmp             SP, x16
    //     0xba2214: b.ls            #0xba2a50
    // 0xba2218: mov             x1, x0
    // 0xba221c: r0 = moveNext()
    //     0xba221c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba2220: tbnz            w0, #4, #0xba22ec
    // 0xba2224: ldur            x3, [fp, #-0x30]
    // 0xba2228: LoadField: r4 = r3->field_33
    //     0xba2228: ldur            w4, [x3, #0x33]
    // 0xba222c: DecompressPointer r4
    //     0xba222c: add             x4, x4, HEAP, lsl #32
    // 0xba2230: stur            x4, [fp, #-0x38]
    // 0xba2234: cmp             w4, NULL
    // 0xba2238: b.ne            #0xba226c
    // 0xba223c: mov             x0, x4
    // 0xba2240: ldur            x2, [fp, #-0x28]
    // 0xba2244: r1 = Null
    //     0xba2244: mov             x1, NULL
    // 0xba2248: cmp             w2, NULL
    // 0xba224c: b.eq            #0xba226c
    // 0xba2250: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba2250: ldur            w4, [x2, #0x17]
    // 0xba2254: DecompressPointer r4
    //     0xba2254: add             x4, x4, HEAP, lsl #32
    // 0xba2258: r8 = X0
    //     0xba2258: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba225c: LoadField: r9 = r4->field_7
    //     0xba225c: ldur            x9, [x4, #7]
    // 0xba2260: r3 = Null
    //     0xba2260: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cd50] Null
    //     0xba2264: ldr             x3, [x3, #0xd50]
    // 0xba2268: blr             x9
    // 0xba226c: ldur            x0, [fp, #-8]
    // 0xba2270: mov             x1, x0
    // 0xba2274: ldur            x2, [fp, #-0x38]
    // 0xba2278: r0 = _getValueOrData()
    //     0xba2278: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba227c: ldur            x1, [fp, #-8]
    // 0xba2280: LoadField: r2 = r1->field_f
    //     0xba2280: ldur            w2, [x1, #0xf]
    // 0xba2284: DecompressPointer r2
    //     0xba2284: add             x2, x2, HEAP, lsl #32
    // 0xba2288: cmp             w2, w0
    // 0xba228c: b.ne            #0xba2298
    // 0xba2290: r2 = Null
    //     0xba2290: mov             x2, NULL
    // 0xba2294: b               #0xba229c
    // 0xba2298: mov             x2, x0
    // 0xba229c: ldur            x0, [fp, #-0x20]
    // 0xba22a0: cmp             w2, NULL
    // 0xba22a4: b.eq            #0xba2a58
    // 0xba22a8: LoadField: d0 = r0->field_7
    //     0xba22a8: ldur            d0, [x0, #7]
    // 0xba22ac: LoadField: d1 = r2->field_7
    //     0xba22ac: ldur            d1, [x2, #7]
    // 0xba22b0: fadd            d2, d0, d1
    // 0xba22b4: stur            d2, [fp, #-0x58]
    // 0xba22b8: LoadField: d0 = r0->field_f
    //     0xba22b8: ldur            d0, [x0, #0xf]
    // 0xba22bc: LoadField: d1 = r2->field_f
    //     0xba22bc: ldur            d1, [x2, #0xf]
    // 0xba22c0: fadd            d3, d0, d1
    // 0xba22c4: stur            d3, [fp, #-0x50]
    // 0xba22c8: r0 = Offset()
    //     0xba22c8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xba22cc: ldur            d0, [fp, #-0x58]
    // 0xba22d0: StoreField: r0->field_7 = d0
    //     0xba22d0: stur            d0, [x0, #7]
    // 0xba22d4: ldur            d0, [fp, #-0x50]
    // 0xba22d8: StoreField: r0->field_f = d0
    //     0xba22d8: stur            d0, [x0, #0xf]
    // 0xba22dc: mov             x4, x0
    // 0xba22e0: ldur            x0, [fp, #-0x30]
    // 0xba22e4: ldur            x2, [fp, #-0x28]
    // 0xba22e8: b               #0xba2204
    // 0xba22ec: ldur            x2, [fp, #-0x18]
    // 0xba22f0: ldur            x0, [fp, #-0x20]
    // 0xba22f4: LoadField: r3 = r2->field_7f
    //     0xba22f4: ldur            w3, [x2, #0x7f]
    // 0xba22f8: DecompressPointer r3
    //     0xba22f8: add             x3, x3, HEAP, lsl #32
    // 0xba22fc: stur            x3, [fp, #-0x28]
    // 0xba2300: r1 = <_PointerPanZoomData>
    //     0xba2300: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0xba2304: ldr             x1, [x1, #0xca0]
    // 0xba2308: r0 = _CompactValuesIterable()
    //     0xba2308: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba230c: mov             x1, x0
    // 0xba2310: ldur            x0, [fp, #-0x28]
    // 0xba2314: StoreField: r1->field_b = r0
    //     0xba2314: stur            w0, [x1, #0xb]
    // 0xba2318: r0 = iterator()
    //     0xba2318: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xba231c: stur            x0, [fp, #-0x38]
    // 0xba2320: LoadField: r2 = r0->field_7
    //     0xba2320: ldur            w2, [x0, #7]
    // 0xba2324: DecompressPointer r2
    //     0xba2324: add             x2, x2, HEAP, lsl #32
    // 0xba2328: stur            x2, [fp, #-0x30]
    // 0xba232c: ldur            x3, [fp, #-0x20]
    // 0xba2330: stur            x3, [fp, #-0x20]
    // 0xba2334: CheckStackOverflow
    //     0xba2334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2338: cmp             SP, x16
    //     0xba233c: b.ls            #0xba2a5c
    // 0xba2340: mov             x1, x0
    // 0xba2344: r0 = moveNext()
    //     0xba2344: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba2348: tbnz            w0, #4, #0xba23f8
    // 0xba234c: ldur            x3, [fp, #-0x38]
    // 0xba2350: LoadField: r4 = r3->field_33
    //     0xba2350: ldur            w4, [x3, #0x33]
    // 0xba2354: DecompressPointer r4
    //     0xba2354: add             x4, x4, HEAP, lsl #32
    // 0xba2358: stur            x4, [fp, #-0x40]
    // 0xba235c: cmp             w4, NULL
    // 0xba2360: b.ne            #0xba2394
    // 0xba2364: mov             x0, x4
    // 0xba2368: ldur            x2, [fp, #-0x30]
    // 0xba236c: r1 = Null
    //     0xba236c: mov             x1, NULL
    // 0xba2370: cmp             w2, NULL
    // 0xba2374: b.eq            #0xba2394
    // 0xba2378: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba2378: ldur            w4, [x2, #0x17]
    // 0xba237c: DecompressPointer r4
    //     0xba237c: add             x4, x4, HEAP, lsl #32
    // 0xba2380: r8 = X0
    //     0xba2380: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba2384: LoadField: r9 = r4->field_7
    //     0xba2384: ldur            x9, [x4, #7]
    // 0xba2388: r3 = Null
    //     0xba2388: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cd60] Null
    //     0xba238c: ldr             x3, [x3, #0xd60]
    // 0xba2390: blr             x9
    // 0xba2394: ldur            x3, [fp, #-0x20]
    // 0xba2398: ldur            x0, [fp, #-0x40]
    // 0xba239c: LoadField: r1 = r0->field_b
    //     0xba239c: ldur            w1, [x0, #0xb]
    // 0xba23a0: DecompressPointer r1
    //     0xba23a0: add             x1, x1, HEAP, lsl #32
    // 0xba23a4: LoadField: r2 = r0->field_f
    //     0xba23a4: ldur            w2, [x0, #0xf]
    // 0xba23a8: DecompressPointer r2
    //     0xba23a8: add             x2, x2, HEAP, lsl #32
    // 0xba23ac: r0 = +()
    //     0xba23ac: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xba23b0: ldur            x2, [fp, #-0x20]
    // 0xba23b4: LoadField: d0 = r2->field_7
    //     0xba23b4: ldur            d0, [x2, #7]
    // 0xba23b8: LoadField: d1 = r0->field_7
    //     0xba23b8: ldur            d1, [x0, #7]
    // 0xba23bc: fadd            d2, d0, d1
    // 0xba23c0: stur            d2, [fp, #-0x58]
    // 0xba23c4: LoadField: d0 = r2->field_f
    //     0xba23c4: ldur            d0, [x2, #0xf]
    // 0xba23c8: LoadField: d1 = r0->field_f
    //     0xba23c8: ldur            d1, [x0, #0xf]
    // 0xba23cc: fadd            d3, d0, d1
    // 0xba23d0: stur            d3, [fp, #-0x50]
    // 0xba23d4: r0 = Offset()
    //     0xba23d4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xba23d8: ldur            d0, [fp, #-0x58]
    // 0xba23dc: StoreField: r0->field_7 = d0
    //     0xba23dc: stur            d0, [x0, #7]
    // 0xba23e0: ldur            d0, [fp, #-0x50]
    // 0xba23e4: StoreField: r0->field_f = d0
    //     0xba23e4: stur            d0, [x0, #0xf]
    // 0xba23e8: mov             x3, x0
    // 0xba23ec: ldur            x0, [fp, #-0x38]
    // 0xba23f0: ldur            x2, [fp, #-0x30]
    // 0xba23f4: b               #0xba2330
    // 0xba23f8: ldur            x3, [fp, #-0x18]
    // 0xba23fc: ldur            x5, [fp, #-0x10]
    // 0xba2400: ldur            x4, [fp, #-8]
    // 0xba2404: ldur            x0, [fp, #-0x28]
    // 0xba2408: ldur            x2, [fp, #-0x20]
    // 0xba240c: r1 = 1
    //     0xba240c: mov             x1, #1
    // 0xba2410: LoadField: r6 = r4->field_13
    //     0xba2410: ldur            w6, [x4, #0x13]
    // 0xba2414: r7 = LoadInt32Instr(r6)
    //     0xba2414: sbfx            x7, x6, #1, #0x1f
    // 0xba2418: asr             x6, x7, #1
    // 0xba241c: ArrayLoad: r7 = r4[0]  ; List_4
    //     0xba241c: ldur            w7, [x4, #0x17]
    // 0xba2420: r8 = LoadInt32Instr(r7)
    //     0xba2420: sbfx            x8, x7, #1, #0x1f
    // 0xba2424: sub             x7, x6, x8
    // 0xba2428: LoadField: r6 = r0->field_13
    //     0xba2428: ldur            w6, [x0, #0x13]
    // 0xba242c: r8 = LoadInt32Instr(r6)
    //     0xba242c: sbfx            x8, x6, #1, #0x1f
    // 0xba2430: asr             x6, x8, #1
    // 0xba2434: ArrayLoad: r8 = r0[0]  ; List_4
    //     0xba2434: ldur            w8, [x0, #0x17]
    // 0xba2438: r0 = LoadInt32Instr(r8)
    //     0xba2438: sbfx            x0, x8, #1, #0x1f
    // 0xba243c: sub             x8, x6, x0
    // 0xba2440: add             x0, x7, x8
    // 0xba2444: cmp             x1, x0
    // 0xba2448: csel            x6, x0, x1, lt
    // 0xba244c: r0 = BoxInt64Instr(r6)
    //     0xba244c: sbfiz           x0, x6, #1, #0x1f
    //     0xba2450: cmp             x6, x0, asr #1
    //     0xba2454: b.eq            #0xba2460
    //     0xba2458: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba245c: stur            x6, [x0, #7]
    // 0xba2460: stp             x0, NULL, [SP]
    // 0xba2464: r0 = _Double.fromInteger()
    //     0xba2464: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xba2468: LoadField: d0 = r0->field_7
    //     0xba2468: ldur            d0, [x0, #7]
    // 0xba246c: ldur            x1, [fp, #-0x20]
    // 0xba2470: r0 = /()
    //     0xba2470: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0xba2474: mov             x1, x0
    // 0xba2478: ldur            x3, [fp, #-0x18]
    // 0xba247c: StoreField: r3->field_43 = r0
    //     0xba247c: stur            w0, [x3, #0x43]
    //     0xba2480: ldurb           w16, [x3, #-1]
    //     0xba2484: ldurb           w17, [x0, #-1]
    //     0xba2488: and             x16, x17, x16, lsr #2
    //     0xba248c: tst             x16, HEAP, lsr #32
    //     0xba2490: b.eq            #0xba2498
    //     0xba2494: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba2498: ldur            x0, [fp, #-0x10]
    // 0xba249c: cmp             w0, NULL
    // 0xba24a0: b.ne            #0xba24e8
    // 0xba24a4: LoadField: r0 = r3->field_37
    //     0xba24a4: ldur            w0, [x3, #0x37]
    // 0xba24a8: DecompressPointer r0
    //     0xba24a8: add             x0, x0, HEAP, lsl #32
    // 0xba24ac: mov             x2, x1
    // 0xba24b0: mov             x1, x0
    // 0xba24b4: r0 = transformPosition()
    //     0xba24b4: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xba24b8: ldur            x3, [fp, #-0x18]
    // 0xba24bc: StoreField: r3->field_5f = r0
    //     0xba24bc: stur            w0, [x3, #0x5f]
    //     0xba24c0: ldurb           w16, [x3, #-1]
    //     0xba24c4: ldurb           w17, [x0, #-1]
    //     0xba24c8: and             x16, x17, x16, lsr #2
    //     0xba24cc: tst             x16, HEAP, lsr #32
    //     0xba24d0: b.eq            #0xba24d8
    //     0xba24d4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba24d8: r0 = Instance_Offset
    //     0xba24d8: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xba24dc: StoreField: r3->field_7b = r0
    //     0xba24dc: stur            w0, [x3, #0x7b]
    // 0xba24e0: mov             x2, x3
    // 0xba24e4: b               #0xba2564
    // 0xba24e8: LoadField: r0 = r3->field_5f
    //     0xba24e8: ldur            w0, [x3, #0x5f]
    // 0xba24ec: DecompressPointer r0
    //     0xba24ec: add             x0, x0, HEAP, lsl #32
    // 0xba24f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba24f4: cmp             w0, w16
    // 0xba24f8: b.eq            #0xba2a64
    // 0xba24fc: stur            x0, [fp, #-0x10]
    // 0xba2500: LoadField: r2 = r3->field_37
    //     0xba2500: ldur            w2, [x3, #0x37]
    // 0xba2504: DecompressPointer r2
    //     0xba2504: add             x2, x2, HEAP, lsl #32
    // 0xba2508: mov             x16, x1
    // 0xba250c: mov             x1, x2
    // 0xba2510: mov             x2, x16
    // 0xba2514: r0 = transformPosition()
    //     0xba2514: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xba2518: mov             x1, x0
    // 0xba251c: ldur            x3, [fp, #-0x18]
    // 0xba2520: StoreField: r3->field_5f = r0
    //     0xba2520: stur            w0, [x3, #0x5f]
    //     0xba2524: ldurb           w16, [x3, #-1]
    //     0xba2528: ldurb           w17, [x0, #-1]
    //     0xba252c: and             x16, x17, x16, lsr #2
    //     0xba2530: tst             x16, HEAP, lsr #32
    //     0xba2534: b.eq            #0xba253c
    //     0xba2538: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba253c: ldur            x2, [fp, #-0x10]
    // 0xba2540: r0 = -()
    //     0xba2540: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xba2544: ldur            x2, [fp, #-0x18]
    // 0xba2548: StoreField: r2->field_7b = r0
    //     0xba2548: stur            w0, [x2, #0x7b]
    //     0xba254c: ldurb           w16, [x2, #-1]
    //     0xba2550: ldurb           w17, [x0, #-1]
    //     0xba2554: and             x16, x17, x16, lsr #2
    //     0xba2558: tst             x16, HEAP, lsr #32
    //     0xba255c: b.eq            #0xba2564
    //     0xba2560: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba2564: ldur            x0, [fp, #-8]
    // 0xba2568: LoadField: r1 = r0->field_13
    //     0xba2568: ldur            w1, [x0, #0x13]
    // 0xba256c: r3 = LoadInt32Instr(r1)
    //     0xba256c: sbfx            x3, x1, #1, #0x1f
    // 0xba2570: asr             x1, x3, #1
    // 0xba2574: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xba2574: ldur            w3, [x0, #0x17]
    // 0xba2578: r4 = LoadInt32Instr(r3)
    //     0xba2578: sbfx            x4, x3, #1, #0x1f
    // 0xba257c: sub             x3, x1, x4
    // 0xba2580: stur            x3, [fp, #-0x48]
    // 0xba2584: r1 = <int, Offset>
    //     0xba2584: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xba2588: ldr             x1, [x1, #0x540]
    // 0xba258c: r0 = _CompactKeysIterable()
    //     0xba258c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xba2590: mov             x1, x0
    // 0xba2594: ldur            x0, [fp, #-8]
    // 0xba2598: StoreField: r1->field_b = r0
    //     0xba2598: stur            w0, [x1, #0xb]
    // 0xba259c: r0 = iterator()
    //     0xba259c: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xba25a0: stur            x0, [fp, #-0x28]
    // 0xba25a4: LoadField: r2 = r0->field_7
    //     0xba25a4: ldur            w2, [x0, #7]
    // 0xba25a8: DecompressPointer r2
    //     0xba25a8: add             x2, x2, HEAP, lsl #32
    // 0xba25ac: stur            x2, [fp, #-0x20]
    // 0xba25b0: r4 = Instance_Offset
    //     0xba25b0: ldr             x4, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xba25b4: ldur            x3, [fp, #-8]
    // 0xba25b8: stur            x4, [fp, #-0x10]
    // 0xba25bc: CheckStackOverflow
    //     0xba25bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba25c0: cmp             SP, x16
    //     0xba25c4: b.ls            #0xba2a70
    // 0xba25c8: mov             x1, x0
    // 0xba25cc: r0 = moveNext()
    //     0xba25cc: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba25d0: tbnz            w0, #4, #0xba269c
    // 0xba25d4: ldur            x3, [fp, #-0x28]
    // 0xba25d8: LoadField: r4 = r3->field_33
    //     0xba25d8: ldur            w4, [x3, #0x33]
    // 0xba25dc: DecompressPointer r4
    //     0xba25dc: add             x4, x4, HEAP, lsl #32
    // 0xba25e0: stur            x4, [fp, #-0x30]
    // 0xba25e4: cmp             w4, NULL
    // 0xba25e8: b.ne            #0xba261c
    // 0xba25ec: mov             x0, x4
    // 0xba25f0: ldur            x2, [fp, #-0x20]
    // 0xba25f4: r1 = Null
    //     0xba25f4: mov             x1, NULL
    // 0xba25f8: cmp             w2, NULL
    // 0xba25fc: b.eq            #0xba261c
    // 0xba2600: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba2600: ldur            w4, [x2, #0x17]
    // 0xba2604: DecompressPointer r4
    //     0xba2604: add             x4, x4, HEAP, lsl #32
    // 0xba2608: r8 = X0
    //     0xba2608: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba260c: LoadField: r9 = r4->field_7
    //     0xba260c: ldur            x9, [x4, #7]
    // 0xba2610: r3 = Null
    //     0xba2610: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cd70] Null
    //     0xba2614: ldr             x3, [x3, #0xd70]
    // 0xba2618: blr             x9
    // 0xba261c: ldur            x0, [fp, #-8]
    // 0xba2620: mov             x1, x0
    // 0xba2624: ldur            x2, [fp, #-0x30]
    // 0xba2628: r0 = _getValueOrData()
    //     0xba2628: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba262c: ldur            x1, [fp, #-8]
    // 0xba2630: LoadField: r2 = r1->field_f
    //     0xba2630: ldur            w2, [x1, #0xf]
    // 0xba2634: DecompressPointer r2
    //     0xba2634: add             x2, x2, HEAP, lsl #32
    // 0xba2638: cmp             w2, w0
    // 0xba263c: b.ne            #0xba2648
    // 0xba2640: r2 = Null
    //     0xba2640: mov             x2, NULL
    // 0xba2644: b               #0xba264c
    // 0xba2648: mov             x2, x0
    // 0xba264c: ldur            x0, [fp, #-0x10]
    // 0xba2650: cmp             w2, NULL
    // 0xba2654: b.eq            #0xba2a78
    // 0xba2658: LoadField: d0 = r0->field_7
    //     0xba2658: ldur            d0, [x0, #7]
    // 0xba265c: LoadField: d1 = r2->field_7
    //     0xba265c: ldur            d1, [x2, #7]
    // 0xba2660: fadd            d2, d0, d1
    // 0xba2664: stur            d2, [fp, #-0x58]
    // 0xba2668: LoadField: d0 = r0->field_f
    //     0xba2668: ldur            d0, [x0, #0xf]
    // 0xba266c: LoadField: d1 = r2->field_f
    //     0xba266c: ldur            d1, [x2, #0xf]
    // 0xba2670: fadd            d3, d0, d1
    // 0xba2674: stur            d3, [fp, #-0x50]
    // 0xba2678: r0 = Offset()
    //     0xba2678: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xba267c: ldur            d0, [fp, #-0x58]
    // 0xba2680: StoreField: r0->field_7 = d0
    //     0xba2680: stur            d0, [x0, #7]
    // 0xba2684: ldur            d0, [fp, #-0x50]
    // 0xba2688: StoreField: r0->field_f = d0
    //     0xba2688: stur            d0, [x0, #0xf]
    // 0xba268c: mov             x4, x0
    // 0xba2690: ldur            x0, [fp, #-0x28]
    // 0xba2694: ldur            x2, [fp, #-0x20]
    // 0xba2698: b               #0xba25b4
    // 0xba269c: ldur            x0, [fp, #-0x10]
    // 0xba26a0: ldur            x1, [fp, #-0x48]
    // 0xba26a4: cmp             x1, #0
    // 0xba26a8: b.le            #0xba26cc
    // 0xba26ac: lsl             x2, x1, #1
    // 0xba26b0: stp             x2, NULL, [SP]
    // 0xba26b4: r0 = _Double.fromInteger()
    //     0xba26b4: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xba26b8: LoadField: d0 = r0->field_7
    //     0xba26b8: ldur            d0, [x0, #7]
    // 0xba26bc: ldur            x1, [fp, #-0x10]
    // 0xba26c0: r0 = /()
    //     0xba26c0: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0xba26c4: mov             x2, x0
    // 0xba26c8: b               #0xba26d0
    // 0xba26cc: ldur            x2, [fp, #-0x10]
    // 0xba26d0: ldur            x0, [fp, #-8]
    // 0xba26d4: stur            x2, [fp, #-0x10]
    // 0xba26d8: r1 = <int, Offset>
    //     0xba26d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xba26dc: ldr             x1, [x1, #0x540]
    // 0xba26e0: r0 = _CompactKeysIterable()
    //     0xba26e0: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xba26e4: mov             x1, x0
    // 0xba26e8: ldur            x0, [fp, #-8]
    // 0xba26ec: StoreField: r1->field_b = r0
    //     0xba26ec: stur            w0, [x1, #0xb]
    // 0xba26f0: r0 = iterator()
    //     0xba26f0: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xba26f4: mov             x2, x0
    // 0xba26f8: ldur            x0, [fp, #-0x10]
    // 0xba26fc: stur            x2, [fp, #-0x20]
    // 0xba2700: LoadField: d0 = r0->field_7
    //     0xba2700: ldur            d0, [x0, #7]
    // 0xba2704: stur            d0, [fp, #-0x70]
    // 0xba2708: LoadField: d1 = r0->field_f
    //     0xba2708: ldur            d1, [x0, #0xf]
    // 0xba270c: stur            d1, [fp, #-0x68]
    // 0xba2710: LoadField: r0 = r2->field_7
    //     0xba2710: ldur            w0, [x2, #7]
    // 0xba2714: DecompressPointer r0
    //     0xba2714: add             x0, x0, HEAP, lsl #32
    // 0xba2718: stur            x0, [fp, #-0x10]
    // 0xba271c: ldur            x3, [fp, #-8]
    // 0xba2720: d4 = 0.000000
    //     0xba2720: eor             v4.16b, v4.16b, v4.16b
    // 0xba2724: d3 = 0.000000
    //     0xba2724: eor             v3.16b, v3.16b, v3.16b
    // 0xba2728: d2 = 0.000000
    //     0xba2728: eor             v2.16b, v2.16b, v2.16b
    // 0xba272c: stur            d4, [fp, #-0x50]
    // 0xba2730: stur            d3, [fp, #-0x58]
    // 0xba2734: stur            d2, [fp, #-0x60]
    // 0xba2738: CheckStackOverflow
    //     0xba2738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba273c: cmp             SP, x16
    //     0xba2740: b.ls            #0xba2a7c
    // 0xba2744: mov             x1, x2
    // 0xba2748: r0 = moveNext()
    //     0xba2748: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba274c: tbnz            w0, #4, #0xba28f8
    // 0xba2750: ldur            x3, [fp, #-0x20]
    // 0xba2754: LoadField: r4 = r3->field_33
    //     0xba2754: ldur            w4, [x3, #0x33]
    // 0xba2758: DecompressPointer r4
    //     0xba2758: add             x4, x4, HEAP, lsl #32
    // 0xba275c: stur            x4, [fp, #-0x28]
    // 0xba2760: cmp             w4, NULL
    // 0xba2764: b.ne            #0xba2798
    // 0xba2768: mov             x0, x4
    // 0xba276c: ldur            x2, [fp, #-0x10]
    // 0xba2770: r1 = Null
    //     0xba2770: mov             x1, NULL
    // 0xba2774: cmp             w2, NULL
    // 0xba2778: b.eq            #0xba2798
    // 0xba277c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba277c: ldur            w4, [x2, #0x17]
    // 0xba2780: DecompressPointer r4
    //     0xba2780: add             x4, x4, HEAP, lsl #32
    // 0xba2784: r8 = X0
    //     0xba2784: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba2788: LoadField: r9 = r4->field_7
    //     0xba2788: ldur            x9, [x4, #7]
    // 0xba278c: r3 = Null
    //     0xba278c: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cd80] Null
    //     0xba2790: ldr             x3, [x3, #0xd80]
    // 0xba2794: blr             x9
    // 0xba2798: ldur            x0, [fp, #-8]
    // 0xba279c: mov             x1, x0
    // 0xba27a0: ldur            x2, [fp, #-0x28]
    // 0xba27a4: r0 = _getValueOrData()
    //     0xba27a4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba27a8: mov             x1, x0
    // 0xba27ac: ldur            x0, [fp, #-8]
    // 0xba27b0: LoadField: r2 = r0->field_f
    //     0xba27b0: ldur            w2, [x0, #0xf]
    // 0xba27b4: DecompressPointer r2
    //     0xba27b4: add             x2, x2, HEAP, lsl #32
    // 0xba27b8: cmp             w2, w1
    // 0xba27bc: b.ne            #0xba27c4
    // 0xba27c0: r1 = Null
    //     0xba27c0: mov             x1, NULL
    // 0xba27c4: ldur            d2, [fp, #-0x50]
    // 0xba27c8: ldur            d0, [fp, #-0x70]
    // 0xba27cc: ldur            d1, [fp, #-0x68]
    // 0xba27d0: cmp             w1, NULL
    // 0xba27d4: b.eq            #0xba2a84
    // 0xba27d8: LoadField: d3 = r1->field_7
    //     0xba27d8: ldur            d3, [x1, #7]
    // 0xba27dc: fsub            d4, d0, d3
    // 0xba27e0: LoadField: d3 = r1->field_f
    //     0xba27e0: ldur            d3, [x1, #0xf]
    // 0xba27e4: fsub            d5, d1, d3
    // 0xba27e8: fmul            d3, d4, d4
    // 0xba27ec: fmul            d4, d5, d5
    // 0xba27f0: fadd            d5, d3, d4
    // 0xba27f4: fsqrt           d3, d5
    // 0xba27f8: fadd            d4, d2, d3
    // 0xba27fc: mov             x1, x0
    // 0xba2800: ldur            x2, [fp, #-0x28]
    // 0xba2804: stur            d4, [fp, #-0x78]
    // 0xba2808: r0 = _getValueOrData()
    //     0xba2808: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba280c: mov             x1, x0
    // 0xba2810: ldur            x0, [fp, #-8]
    // 0xba2814: LoadField: r2 = r0->field_f
    //     0xba2814: ldur            w2, [x0, #0xf]
    // 0xba2818: DecompressPointer r2
    //     0xba2818: add             x2, x2, HEAP, lsl #32
    // 0xba281c: cmp             w2, w1
    // 0xba2820: b.ne            #0xba2828
    // 0xba2824: r1 = Null
    //     0xba2824: mov             x1, NULL
    // 0xba2828: ldur            d0, [fp, #-0x70]
    // 0xba282c: d1 = 0.000000
    //     0xba282c: eor             v1.16b, v1.16b, v1.16b
    // 0xba2830: cmp             w1, NULL
    // 0xba2834: b.eq            #0xba2a88
    // 0xba2838: LoadField: d2 = r1->field_7
    //     0xba2838: ldur            d2, [x1, #7]
    // 0xba283c: fsub            d5, d0, d2
    // 0xba2840: fcmp            d5, d1
    // 0xba2844: b.ne            #0xba2850
    // 0xba2848: d2 = 0.000000
    //     0xba2848: eor             v2.16b, v2.16b, v2.16b
    // 0xba284c: b               #0xba2864
    // 0xba2850: fcmp            d1, d5
    // 0xba2854: b.le            #0xba2860
    // 0xba2858: fneg            d6, d5
    // 0xba285c: mov             v5.16b, v6.16b
    // 0xba2860: mov             v2.16b, v5.16b
    // 0xba2864: ldur            d3, [fp, #-0x58]
    // 0xba2868: fadd            d4, d3, d2
    // 0xba286c: mov             x1, x0
    // 0xba2870: ldur            x2, [fp, #-0x28]
    // 0xba2874: stur            d4, [fp, #-0x80]
    // 0xba2878: r0 = _getValueOrData()
    //     0xba2878: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba287c: ldur            x1, [fp, #-8]
    // 0xba2880: LoadField: r2 = r1->field_f
    //     0xba2880: ldur            w2, [x1, #0xf]
    // 0xba2884: DecompressPointer r2
    //     0xba2884: add             x2, x2, HEAP, lsl #32
    // 0xba2888: cmp             w2, w0
    // 0xba288c: b.ne            #0xba2898
    // 0xba2890: r2 = Null
    //     0xba2890: mov             x2, NULL
    // 0xba2894: b               #0xba289c
    // 0xba2898: mov             x2, x0
    // 0xba289c: ldur            d1, [fp, #-0x68]
    // 0xba28a0: d0 = 0.000000
    //     0xba28a0: eor             v0.16b, v0.16b, v0.16b
    // 0xba28a4: cmp             w2, NULL
    // 0xba28a8: b.eq            #0xba2a8c
    // 0xba28ac: LoadField: d4 = r2->field_f
    //     0xba28ac: ldur            d4, [x2, #0xf]
    // 0xba28b0: fsub            d5, d1, d4
    // 0xba28b4: fcmp            d5, d0
    // 0xba28b8: b.ne            #0xba28c4
    // 0xba28bc: d5 = 0.000000
    //     0xba28bc: eor             v5.16b, v5.16b, v5.16b
    // 0xba28c0: b               #0xba28d4
    // 0xba28c4: fcmp            d0, d5
    // 0xba28c8: b.le            #0xba28d4
    // 0xba28cc: fneg            d6, d5
    // 0xba28d0: mov             v5.16b, v6.16b
    // 0xba28d4: ldur            d4, [fp, #-0x60]
    // 0xba28d8: fadd            d2, d4, d5
    // 0xba28dc: ldur            d4, [fp, #-0x78]
    // 0xba28e0: ldur            d3, [fp, #-0x80]
    // 0xba28e4: mov             x3, x1
    // 0xba28e8: ldur            x2, [fp, #-0x20]
    // 0xba28ec: ldur            x0, [fp, #-0x10]
    // 0xba28f0: ldur            d0, [fp, #-0x70]
    // 0xba28f4: b               #0xba272c
    // 0xba28f8: ldur            d2, [fp, #-0x50]
    // 0xba28fc: ldur            d3, [fp, #-0x58]
    // 0xba2900: ldur            d4, [fp, #-0x60]
    // 0xba2904: ldur            x1, [fp, #-0x48]
    // 0xba2908: cmp             x1, #0
    // 0xba290c: b.le            #0xba2920
    // 0xba2910: scvtf           d0, x1
    // 0xba2914: fdiv            d1, d2, d0
    // 0xba2918: mov             v0.16b, v1.16b
    // 0xba291c: b               #0xba2924
    // 0xba2920: d0 = 0.000000
    //     0xba2920: eor             v0.16b, v0.16b, v0.16b
    // 0xba2924: ldur            x2, [fp, #-0x18]
    // 0xba2928: r0 = inline_Allocate_Double()
    //     0xba2928: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xba292c: add             x0, x0, #0x10
    //     0xba2930: cmp             x3, x0
    //     0xba2934: b.ls            #0xba2a90
    //     0xba2938: str             x0, [THR, #0x60]  ; THR::top
    //     0xba293c: sub             x0, x0, #0xf
    //     0xba2940: mov             x3, #0xe19c
    //     0xba2944: movk            x3, #3, lsl #16
    //     0xba2948: stur            x3, [x0, #-1]
    // 0xba294c: dmb             ishst
    // 0xba2950: StoreField: r0->field_7 = d0
    //     0xba2950: stur            d0, [x0, #7]
    // 0xba2954: StoreField: r2->field_4b = r0
    //     0xba2954: stur            w0, [x2, #0x4b]
    //     0xba2958: ldurb           w16, [x2, #-1]
    //     0xba295c: ldurb           w17, [x0, #-1]
    //     0xba2960: and             x16, x17, x16, lsr #2
    //     0xba2964: tst             x16, HEAP, lsr #32
    //     0xba2968: b.eq            #0xba2970
    //     0xba296c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba2970: cmp             x1, #0
    // 0xba2974: b.le            #0xba2988
    // 0xba2978: scvtf           d0, x1
    // 0xba297c: fdiv            d1, d3, d0
    // 0xba2980: mov             v0.16b, v1.16b
    // 0xba2984: b               #0xba298c
    // 0xba2988: d0 = 0.000000
    //     0xba2988: eor             v0.16b, v0.16b, v0.16b
    // 0xba298c: r0 = inline_Allocate_Double()
    //     0xba298c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xba2990: add             x0, x0, #0x10
    //     0xba2994: cmp             x3, x0
    //     0xba2998: b.ls            #0xba2ab0
    //     0xba299c: str             x0, [THR, #0x60]  ; THR::top
    //     0xba29a0: sub             x0, x0, #0xf
    //     0xba29a4: mov             x3, #0xe19c
    //     0xba29a8: movk            x3, #3, lsl #16
    //     0xba29ac: stur            x3, [x0, #-1]
    // 0xba29b0: dmb             ishst
    // 0xba29b4: StoreField: r0->field_7 = d0
    //     0xba29b4: stur            d0, [x0, #7]
    // 0xba29b8: StoreField: r2->field_53 = r0
    //     0xba29b8: stur            w0, [x2, #0x53]
    //     0xba29bc: ldurb           w16, [x2, #-1]
    //     0xba29c0: ldurb           w17, [x0, #-1]
    //     0xba29c4: and             x16, x17, x16, lsr #2
    //     0xba29c8: tst             x16, HEAP, lsr #32
    //     0xba29cc: b.eq            #0xba29d4
    //     0xba29d0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba29d4: cmp             x1, #0
    // 0xba29d8: b.le            #0xba29ec
    // 0xba29dc: scvtf           d0, x1
    // 0xba29e0: fdiv            d1, d4, d0
    // 0xba29e4: mov             v0.16b, v1.16b
    // 0xba29e8: b               #0xba29f0
    // 0xba29ec: d0 = 0.000000
    //     0xba29ec: eor             v0.16b, v0.16b, v0.16b
    // 0xba29f0: r0 = inline_Allocate_Double()
    //     0xba29f0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba29f4: add             x0, x0, #0x10
    //     0xba29f8: cmp             x1, x0
    //     0xba29fc: b.ls            #0xba2ac8
    //     0xba2a00: str             x0, [THR, #0x60]  ; THR::top
    //     0xba2a04: sub             x0, x0, #0xf
    //     0xba2a08: mov             x1, #0xe19c
    //     0xba2a0c: movk            x1, #3, lsl #16
    //     0xba2a10: stur            x1, [x0, #-1]
    // 0xba2a14: dmb             ishst
    // 0xba2a18: StoreField: r0->field_7 = d0
    //     0xba2a18: stur            d0, [x0, #7]
    // 0xba2a1c: StoreField: r2->field_5b = r0
    //     0xba2a1c: stur            w0, [x2, #0x5b]
    //     0xba2a20: ldurb           w16, [x2, #-1]
    //     0xba2a24: ldurb           w17, [x0, #-1]
    //     0xba2a28: and             x16, x17, x16, lsr #2
    //     0xba2a2c: tst             x16, HEAP, lsr #32
    //     0xba2a30: b.eq            #0xba2a38
    //     0xba2a34: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba2a38: r0 = Null
    //     0xba2a38: mov             x0, NULL
    // 0xba2a3c: LeaveFrame
    //     0xba2a3c: mov             SP, fp
    //     0xba2a40: ldp             fp, lr, [SP], #0x10
    // 0xba2a44: ret
    //     0xba2a44: ret             
    // 0xba2a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2a48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2a4c: b               #0xba21bc
    // 0xba2a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2a50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2a54: b               #0xba2218
    // 0xba2a58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2a58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba2a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2a5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2a60: b               #0xba2340
    // 0xba2a64: r9 = _localFocalPoint
    //     0xba2a64: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc90] Field <ScaleGestureRecognizer._localFocalPoint@661213599>: late (offset: 0x60)
    //     0xba2a68: ldr             x9, [x9, #0xc90]
    // 0xba2a6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba2a6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xba2a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2a70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2a74: b               #0xba25c8
    // 0xba2a78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2a78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba2a7c: r0 = StackOverflowSharedWithFPURegs()
    //     0xba2a7c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xba2a80: b               #0xba2744
    // 0xba2a84: r0 = NullCastErrorSharedWithFPURegs()
    //     0xba2a84: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xba2a88: r0 = NullCastErrorSharedWithFPURegs()
    //     0xba2a88: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xba2a8c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xba2a8c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xba2a90: stp             q3, q4, [SP, #-0x20]!
    // 0xba2a94: SaveReg d0
    //     0xba2a94: str             q0, [SP, #-0x10]!
    // 0xba2a98: stp             x1, x2, [SP, #-0x10]!
    // 0xba2a9c: r0 = AllocateDouble()
    //     0xba2a9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba2aa0: ldp             x1, x2, [SP], #0x10
    // 0xba2aa4: RestoreReg d0
    //     0xba2aa4: ldr             q0, [SP], #0x10
    // 0xba2aa8: ldp             q3, q4, [SP], #0x20
    // 0xba2aac: b               #0xba2950
    // 0xba2ab0: stp             q0, q4, [SP, #-0x20]!
    // 0xba2ab4: stp             x1, x2, [SP, #-0x10]!
    // 0xba2ab8: r0 = AllocateDouble()
    //     0xba2ab8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba2abc: ldp             x1, x2, [SP], #0x10
    // 0xba2ac0: ldp             q0, q4, [SP], #0x20
    // 0xba2ac4: b               #0xba29b4
    // 0xba2ac8: SaveReg d0
    //     0xba2ac8: str             q0, [SP, #-0x10]!
    // 0xba2acc: SaveReg r2
    //     0xba2acc: str             x2, [SP, #-8]!
    // 0xba2ad0: r0 = AllocateDouble()
    //     0xba2ad0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba2ad4: RestoreReg r2
    //     0xba2ad4: ldr             x2, [SP], #8
    // 0xba2ad8: RestoreReg d0
    //     0xba2ad8: ldr             q0, [SP], #0x10
    // 0xba2adc: b               #0xba2a18
  }
  _ _updateLines(/* No info */) {
    // ** addr: 0xba2ae0, size: 0x3f4
    // 0xba2ae0: EnterFrame
    //     0xba2ae0: stp             fp, lr, [SP, #-0x10]!
    //     0xba2ae4: mov             fp, SP
    // 0xba2ae8: AllocStack(0x30)
    //     0xba2ae8: sub             SP, SP, #0x30
    // 0xba2aec: SetupParameters(ScaleGestureRecognizer this /* r1 => r3, fp-0x20 */)
    //     0xba2aec: mov             x3, x1
    //     0xba2af0: stur            x1, [fp, #-0x20]
    // 0xba2af4: CheckStackOverflow
    //     0xba2af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba2af8: cmp             SP, x16
    //     0xba2afc: b.ls            #0xba2ea8
    // 0xba2b00: LoadField: r4 = r3->field_6b
    //     0xba2b00: ldur            w4, [x3, #0x6b]
    // 0xba2b04: DecompressPointer r4
    //     0xba2b04: add             x4, x4, HEAP, lsl #32
    // 0xba2b08: stur            x4, [fp, #-0x18]
    // 0xba2b0c: LoadField: r0 = r4->field_13
    //     0xba2b0c: ldur            w0, [x4, #0x13]
    // 0xba2b10: r1 = LoadInt32Instr(r0)
    //     0xba2b10: sbfx            x1, x0, #1, #0x1f
    // 0xba2b14: asr             x0, x1, #1
    // 0xba2b18: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xba2b18: ldur            w1, [x4, #0x17]
    // 0xba2b1c: r2 = LoadInt32Instr(r1)
    //     0xba2b1c: sbfx            x2, x1, #1, #0x1f
    // 0xba2b20: sub             x1, x0, x2
    // 0xba2b24: cmp             x1, #2
    // 0xba2b28: b.ge            #0xba2b54
    // 0xba2b2c: LoadField: r0 = r3->field_67
    //     0xba2b2c: ldur            w0, [x3, #0x67]
    // 0xba2b30: DecompressPointer r0
    //     0xba2b30: add             x0, x0, HEAP, lsl #32
    // 0xba2b34: StoreField: r3->field_63 = r0
    //     0xba2b34: stur            w0, [x3, #0x63]
    //     0xba2b38: ldurb           w16, [x3, #-1]
    //     0xba2b3c: ldurb           w17, [x0, #-1]
    //     0xba2b40: and             x16, x17, x16, lsr #2
    //     0xba2b44: tst             x16, HEAP, lsr #32
    //     0xba2b48: b.eq            #0xba2b50
    //     0xba2b4c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba2b50: b               #0xba2e98
    // 0xba2b54: LoadField: r2 = r3->field_63
    //     0xba2b54: ldur            w2, [x3, #0x63]
    // 0xba2b58: DecompressPointer r2
    //     0xba2b58: add             x2, x2, HEAP, lsl #32
    // 0xba2b5c: cmp             w2, NULL
    // 0xba2b60: b.eq            #0xba2d1c
    // 0xba2b64: LoadField: r5 = r2->field_b
    //     0xba2b64: ldur            x5, [x2, #0xb]
    // 0xba2b68: LoadField: r6 = r3->field_6f
    //     0xba2b68: ldur            w6, [x3, #0x6f]
    // 0xba2b6c: DecompressPointer r6
    //     0xba2b6c: add             x6, x6, HEAP, lsl #32
    // 0xba2b70: stur            x6, [fp, #-0x10]
    // 0xba2b74: LoadField: r0 = r6->field_b
    //     0xba2b74: ldur            w0, [x6, #0xb]
    // 0xba2b78: r7 = LoadInt32Instr(r0)
    //     0xba2b78: sbfx            x7, x0, #1, #0x1f
    // 0xba2b7c: mov             x0, x7
    // 0xba2b80: r1 = 0
    //     0xba2b80: mov             x1, #0
    // 0xba2b84: cmp             x1, x0
    // 0xba2b88: b.hs            #0xba2eb0
    // 0xba2b8c: LoadField: r8 = r6->field_f
    //     0xba2b8c: ldur            w8, [x6, #0xf]
    // 0xba2b90: DecompressPointer r8
    //     0xba2b90: add             x8, x8, HEAP, lsl #32
    // 0xba2b94: LoadField: r9 = r8->field_f
    //     0xba2b94: ldur            w9, [x8, #0xf]
    // 0xba2b98: DecompressPointer r9
    //     0xba2b98: add             x9, x9, HEAP, lsl #32
    // 0xba2b9c: stur            x9, [fp, #-8]
    // 0xba2ba0: r0 = LoadInt32Instr(r9)
    //     0xba2ba0: sbfx            x0, x9, #1, #0x1f
    //     0xba2ba4: tbz             w9, #0, #0xba2bac
    //     0xba2ba8: ldur            x0, [x9, #7]
    // 0xba2bac: cmp             x5, x0
    // 0xba2bb0: b.ne            #0xba2d0c
    // 0xba2bb4: ArrayLoad: r5 = r2[0]  ; List_8
    //     0xba2bb4: ldur            x5, [x2, #0x17]
    // 0xba2bb8: mov             x0, x7
    // 0xba2bbc: r1 = 1
    //     0xba2bbc: mov             x1, #1
    // 0xba2bc0: cmp             x1, x0
    // 0xba2bc4: b.hs            #0xba2eb4
    // 0xba2bc8: LoadField: r0 = r8->field_13
    //     0xba2bc8: ldur            w0, [x8, #0x13]
    // 0xba2bcc: DecompressPointer r0
    //     0xba2bcc: add             x0, x0, HEAP, lsl #32
    // 0xba2bd0: r1 = LoadInt32Instr(r0)
    //     0xba2bd0: sbfx            x1, x0, #1, #0x1f
    //     0xba2bd4: tbz             w0, #0, #0xba2bdc
    //     0xba2bd8: ldur            x1, [x0, #7]
    // 0xba2bdc: cmp             x5, x1
    // 0xba2be0: b.ne            #0xba2cfc
    // 0xba2be4: mov             x1, x4
    // 0xba2be8: mov             x2, x9
    // 0xba2bec: r0 = _getValueOrData()
    //     0xba2bec: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba2bf0: ldur            x3, [fp, #-0x18]
    // 0xba2bf4: LoadField: r1 = r3->field_f
    //     0xba2bf4: ldur            w1, [x3, #0xf]
    // 0xba2bf8: DecompressPointer r1
    //     0xba2bf8: add             x1, x1, HEAP, lsl #32
    // 0xba2bfc: cmp             w1, w0
    // 0xba2c00: b.ne            #0xba2c0c
    // 0xba2c04: r4 = Null
    //     0xba2c04: mov             x4, NULL
    // 0xba2c08: b               #0xba2c10
    // 0xba2c0c: mov             x4, x0
    // 0xba2c10: ldur            x2, [fp, #-0x10]
    // 0xba2c14: stur            x4, [fp, #-0x28]
    // 0xba2c18: cmp             w4, NULL
    // 0xba2c1c: b.eq            #0xba2eb8
    // 0xba2c20: LoadField: r0 = r2->field_b
    //     0xba2c20: ldur            w0, [x2, #0xb]
    // 0xba2c24: r1 = LoadInt32Instr(r0)
    //     0xba2c24: sbfx            x1, x0, #1, #0x1f
    // 0xba2c28: mov             x0, x1
    // 0xba2c2c: r1 = 1
    //     0xba2c2c: mov             x1, #1
    // 0xba2c30: cmp             x1, x0
    // 0xba2c34: b.hs            #0xba2ebc
    // 0xba2c38: LoadField: r0 = r2->field_f
    //     0xba2c38: ldur            w0, [x2, #0xf]
    // 0xba2c3c: DecompressPointer r0
    //     0xba2c3c: add             x0, x0, HEAP, lsl #32
    // 0xba2c40: LoadField: r5 = r0->field_13
    //     0xba2c40: ldur            w5, [x0, #0x13]
    // 0xba2c44: DecompressPointer r5
    //     0xba2c44: add             x5, x5, HEAP, lsl #32
    // 0xba2c48: mov             x1, x3
    // 0xba2c4c: mov             x2, x5
    // 0xba2c50: stur            x5, [fp, #-0x10]
    // 0xba2c54: r0 = _getValueOrData()
    //     0xba2c54: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba2c58: ldur            x3, [fp, #-0x18]
    // 0xba2c5c: LoadField: r1 = r3->field_f
    //     0xba2c5c: ldur            w1, [x3, #0xf]
    // 0xba2c60: DecompressPointer r1
    //     0xba2c60: add             x1, x1, HEAP, lsl #32
    // 0xba2c64: cmp             w1, w0
    // 0xba2c68: b.ne            #0xba2c74
    // 0xba2c6c: r4 = Null
    //     0xba2c6c: mov             x4, NULL
    // 0xba2c70: b               #0xba2c78
    // 0xba2c74: mov             x4, x0
    // 0xba2c78: ldur            x2, [fp, #-0x20]
    // 0xba2c7c: ldur            x0, [fp, #-0x28]
    // 0xba2c80: ldur            x3, [fp, #-8]
    // 0xba2c84: ldur            x1, [fp, #-0x10]
    // 0xba2c88: stur            x4, [fp, #-0x30]
    // 0xba2c8c: cmp             w4, NULL
    // 0xba2c90: b.eq            #0xba2ec0
    // 0xba2c94: r0 = _LineBetweenPointers()
    //     0xba2c94: bl              #0xba2ed4  ; Allocate_LineBetweenPointersStub -> _LineBetweenPointers (size=0x20)
    // 0xba2c98: mov             x1, x0
    // 0xba2c9c: ldur            x0, [fp, #-0x28]
    // 0xba2ca0: StoreField: r1->field_7 = r0
    //     0xba2ca0: stur            w0, [x1, #7]
    // 0xba2ca4: ldur            x0, [fp, #-8]
    // 0xba2ca8: r2 = LoadInt32Instr(r0)
    //     0xba2ca8: sbfx            x2, x0, #1, #0x1f
    //     0xba2cac: tbz             w0, #0, #0xba2cb4
    //     0xba2cb0: ldur            x2, [x0, #7]
    // 0xba2cb4: StoreField: r1->field_b = r2
    //     0xba2cb4: stur            x2, [x1, #0xb]
    // 0xba2cb8: ldur            x0, [fp, #-0x30]
    // 0xba2cbc: StoreField: r1->field_13 = r0
    //     0xba2cbc: stur            w0, [x1, #0x13]
    // 0xba2cc0: ldur            x0, [fp, #-0x10]
    // 0xba2cc4: r2 = LoadInt32Instr(r0)
    //     0xba2cc4: sbfx            x2, x0, #1, #0x1f
    //     0xba2cc8: tbz             w0, #0, #0xba2cd0
    //     0xba2ccc: ldur            x2, [x0, #7]
    // 0xba2cd0: ArrayStore: r1[0] = r2  ; List_8
    //     0xba2cd0: stur            x2, [x1, #0x17]
    // 0xba2cd4: mov             x0, x1
    // 0xba2cd8: ldur            x4, [fp, #-0x20]
    // 0xba2cdc: StoreField: r4->field_67 = r0
    //     0xba2cdc: stur            w0, [x4, #0x67]
    //     0xba2ce0: ldurb           w16, [x4, #-1]
    //     0xba2ce4: ldurb           w17, [x0, #-1]
    //     0xba2ce8: and             x16, x17, x16, lsr #2
    //     0xba2cec: tst             x16, HEAP, lsr #32
    //     0xba2cf0: b.eq            #0xba2cf8
    //     0xba2cf4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xba2cf8: b               #0xba2e98
    // 0xba2cfc: mov             x16, x4
    // 0xba2d00: mov             x4, x3
    // 0xba2d04: mov             x3, x16
    // 0xba2d08: b               #0xba2d28
    // 0xba2d0c: mov             x16, x4
    // 0xba2d10: mov             x4, x3
    // 0xba2d14: mov             x3, x16
    // 0xba2d18: b               #0xba2d28
    // 0xba2d1c: mov             x16, x4
    // 0xba2d20: mov             x4, x3
    // 0xba2d24: mov             x3, x16
    // 0xba2d28: LoadField: r5 = r4->field_6f
    //     0xba2d28: ldur            w5, [x4, #0x6f]
    // 0xba2d2c: DecompressPointer r5
    //     0xba2d2c: add             x5, x5, HEAP, lsl #32
    // 0xba2d30: stur            x5, [fp, #-0x10]
    // 0xba2d34: LoadField: r0 = r5->field_b
    //     0xba2d34: ldur            w0, [x5, #0xb]
    // 0xba2d38: r1 = LoadInt32Instr(r0)
    //     0xba2d38: sbfx            x1, x0, #1, #0x1f
    // 0xba2d3c: mov             x0, x1
    // 0xba2d40: r1 = 0
    //     0xba2d40: mov             x1, #0
    // 0xba2d44: cmp             x1, x0
    // 0xba2d48: b.hs            #0xba2ec4
    // 0xba2d4c: LoadField: r0 = r5->field_f
    //     0xba2d4c: ldur            w0, [x5, #0xf]
    // 0xba2d50: DecompressPointer r0
    //     0xba2d50: add             x0, x0, HEAP, lsl #32
    // 0xba2d54: LoadField: r6 = r0->field_f
    //     0xba2d54: ldur            w6, [x0, #0xf]
    // 0xba2d58: DecompressPointer r6
    //     0xba2d58: add             x6, x6, HEAP, lsl #32
    // 0xba2d5c: mov             x1, x3
    // 0xba2d60: mov             x2, x6
    // 0xba2d64: stur            x6, [fp, #-8]
    // 0xba2d68: r0 = _getValueOrData()
    //     0xba2d68: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba2d6c: ldur            x3, [fp, #-0x18]
    // 0xba2d70: LoadField: r1 = r3->field_f
    //     0xba2d70: ldur            w1, [x3, #0xf]
    // 0xba2d74: DecompressPointer r1
    //     0xba2d74: add             x1, x1, HEAP, lsl #32
    // 0xba2d78: cmp             w1, w0
    // 0xba2d7c: b.ne            #0xba2d88
    // 0xba2d80: r4 = Null
    //     0xba2d80: mov             x4, NULL
    // 0xba2d84: b               #0xba2d8c
    // 0xba2d88: mov             x4, x0
    // 0xba2d8c: ldur            x2, [fp, #-0x10]
    // 0xba2d90: stur            x4, [fp, #-0x28]
    // 0xba2d94: cmp             w4, NULL
    // 0xba2d98: b.eq            #0xba2ec8
    // 0xba2d9c: LoadField: r0 = r2->field_b
    //     0xba2d9c: ldur            w0, [x2, #0xb]
    // 0xba2da0: r1 = LoadInt32Instr(r0)
    //     0xba2da0: sbfx            x1, x0, #1, #0x1f
    // 0xba2da4: mov             x0, x1
    // 0xba2da8: r1 = 1
    //     0xba2da8: mov             x1, #1
    // 0xba2dac: cmp             x1, x0
    // 0xba2db0: b.hs            #0xba2ecc
    // 0xba2db4: LoadField: r0 = r2->field_f
    //     0xba2db4: ldur            w0, [x2, #0xf]
    // 0xba2db8: DecompressPointer r0
    //     0xba2db8: add             x0, x0, HEAP, lsl #32
    // 0xba2dbc: LoadField: r5 = r0->field_13
    //     0xba2dbc: ldur            w5, [x0, #0x13]
    // 0xba2dc0: DecompressPointer r5
    //     0xba2dc0: add             x5, x5, HEAP, lsl #32
    // 0xba2dc4: mov             x1, x3
    // 0xba2dc8: mov             x2, x5
    // 0xba2dcc: stur            x5, [fp, #-0x10]
    // 0xba2dd0: r0 = _getValueOrData()
    //     0xba2dd0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba2dd4: mov             x1, x0
    // 0xba2dd8: ldur            x0, [fp, #-0x18]
    // 0xba2ddc: LoadField: r2 = r0->field_f
    //     0xba2ddc: ldur            w2, [x0, #0xf]
    // 0xba2de0: DecompressPointer r2
    //     0xba2de0: add             x2, x2, HEAP, lsl #32
    // 0xba2de4: cmp             w2, w1
    // 0xba2de8: b.ne            #0xba2df4
    // 0xba2dec: r4 = Null
    //     0xba2dec: mov             x4, NULL
    // 0xba2df0: b               #0xba2df8
    // 0xba2df4: mov             x4, x1
    // 0xba2df8: ldur            x2, [fp, #-0x20]
    // 0xba2dfc: ldur            x0, [fp, #-0x28]
    // 0xba2e00: ldur            x3, [fp, #-8]
    // 0xba2e04: ldur            x1, [fp, #-0x10]
    // 0xba2e08: stur            x4, [fp, #-0x18]
    // 0xba2e0c: cmp             w4, NULL
    // 0xba2e10: b.eq            #0xba2ed0
    // 0xba2e14: r0 = _LineBetweenPointers()
    //     0xba2e14: bl              #0xba2ed4  ; Allocate_LineBetweenPointersStub -> _LineBetweenPointers (size=0x20)
    // 0xba2e18: mov             x2, x0
    // 0xba2e1c: ldur            x1, [fp, #-0x28]
    // 0xba2e20: StoreField: r2->field_7 = r1
    //     0xba2e20: stur            w1, [x2, #7]
    // 0xba2e24: ldur            x1, [fp, #-8]
    // 0xba2e28: r3 = LoadInt32Instr(r1)
    //     0xba2e28: sbfx            x3, x1, #1, #0x1f
    //     0xba2e2c: tbz             w1, #0, #0xba2e34
    //     0xba2e30: ldur            x3, [x1, #7]
    // 0xba2e34: StoreField: r2->field_b = r3
    //     0xba2e34: stur            x3, [x2, #0xb]
    // 0xba2e38: ldur            x1, [fp, #-0x18]
    // 0xba2e3c: StoreField: r2->field_13 = r1
    //     0xba2e3c: stur            w1, [x2, #0x13]
    // 0xba2e40: ldur            x1, [fp, #-0x10]
    // 0xba2e44: r3 = LoadInt32Instr(r1)
    //     0xba2e44: sbfx            x3, x1, #1, #0x1f
    //     0xba2e48: tbz             w1, #0, #0xba2e50
    //     0xba2e4c: ldur            x3, [x1, #7]
    // 0xba2e50: ArrayStore: r2[0] = r3  ; List_8
    //     0xba2e50: stur            x3, [x2, #0x17]
    // 0xba2e54: mov             x0, x2
    // 0xba2e58: ldur            x1, [fp, #-0x20]
    // 0xba2e5c: StoreField: r1->field_63 = r0
    //     0xba2e5c: stur            w0, [x1, #0x63]
    //     0xba2e60: ldurb           w16, [x1, #-1]
    //     0xba2e64: ldurb           w17, [x0, #-1]
    //     0xba2e68: and             x16, x17, x16, lsr #2
    //     0xba2e6c: tst             x16, HEAP, lsr #32
    //     0xba2e70: b.eq            #0xba2e78
    //     0xba2e74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba2e78: mov             x0, x2
    // 0xba2e7c: StoreField: r1->field_67 = r0
    //     0xba2e7c: stur            w0, [x1, #0x67]
    //     0xba2e80: ldurb           w16, [x1, #-1]
    //     0xba2e84: ldurb           w17, [x0, #-1]
    //     0xba2e88: and             x16, x17, x16, lsr #2
    //     0xba2e8c: tst             x16, HEAP, lsr #32
    //     0xba2e90: b.eq            #0xba2e98
    //     0xba2e94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba2e98: r0 = Null
    //     0xba2e98: mov             x0, NULL
    // 0xba2e9c: LeaveFrame
    //     0xba2e9c: mov             SP, fp
    //     0xba2ea0: ldp             fp, lr, [SP], #0x10
    // 0xba2ea4: ret
    //     0xba2ea4: ret             
    // 0xba2ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba2ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba2eac: b               #0xba2b00
    // 0xba2eb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba2eb0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xba2eb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba2eb4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xba2eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2eb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba2ebc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba2ebc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xba2ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2ec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba2ec4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba2ec4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xba2ec8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2ec8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba2ecc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba2ecc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xba2ed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba2ed0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba8598, size: 0x178
    // 0xba8598: EnterFrame
    //     0xba8598: stp             fp, lr, [SP, #-0x10]!
    //     0xba859c: mov             fp, SP
    // 0xba85a0: AllocStack(0x30)
    //     0xba85a0: sub             SP, SP, #0x30
    // 0xba85a4: SetupParameters(ScaleGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba85a4: mov             x3, x1
    //     0xba85a8: mov             x0, x2
    //     0xba85ac: stur            x1, [fp, #-8]
    //     0xba85b0: stur            x2, [fp, #-0x10]
    // 0xba85b4: CheckStackOverflow
    //     0xba85b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba85b8: cmp             SP, x16
    //     0xba85bc: b.ls            #0xba8708
    // 0xba85c0: mov             x1, x3
    // 0xba85c4: mov             x2, x0
    // 0xba85c8: r0 = addAllowedPointer()
    //     0xba85c8: bl              #0xba6ac8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0xba85cc: ldur            x2, [fp, #-8]
    // 0xba85d0: LoadField: r3 = r2->field_73
    //     0xba85d0: ldur            w3, [x2, #0x73]
    // 0xba85d4: DecompressPointer r3
    //     0xba85d4: add             x3, x3, HEAP, lsl #32
    // 0xba85d8: ldur            x4, [fp, #-0x10]
    // 0xba85dc: stur            x3, [fp, #-0x18]
    // 0xba85e0: r0 = LoadClassIdInstr(r4)
    //     0xba85e0: ldur            x0, [x4, #-1]
    //     0xba85e4: ubfx            x0, x0, #0xc, #0x14
    // 0xba85e8: mov             x1, x4
    // 0xba85ec: r0 = GDT[cid_x0 + -0x1]()
    //     0xba85ec: sub             lr, x0, #1
    //     0xba85f0: ldr             lr, [x21, lr, lsl #3]
    //     0xba85f4: blr             lr
    // 0xba85f8: mov             x3, x0
    // 0xba85fc: ldur            x2, [fp, #-0x10]
    // 0xba8600: stur            x3, [fp, #-0x20]
    // 0xba8604: r0 = LoadClassIdInstr(r2)
    //     0xba8604: ldur            x0, [x2, #-1]
    //     0xba8608: ubfx            x0, x0, #0xc, #0x14
    // 0xba860c: mov             x1, x2
    // 0xba8610: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xba8610: mov             x17, #0x5e74
    //     0xba8614: movk            x17, #1, lsl #16
    //     0xba8618: add             lr, x0, x17
    //     0xba861c: ldr             lr, [x21, lr, lsl #3]
    //     0xba8620: blr             lr
    // 0xba8624: stur            x0, [fp, #-0x28]
    // 0xba8628: r0 = VelocityTracker()
    //     0xba8628: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0xba862c: stur            x0, [fp, #-0x30]
    // 0xba8630: StoreField: r0->field_13 = rZR
    //     0xba8630: stur            xzr, [x0, #0x13]
    // 0xba8634: r1 = <_PointAtTime?>
    //     0xba8634: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0xba8638: ldr             x1, [x1, #0x568]
    // 0xba863c: r2 = 40
    //     0xba863c: mov             x2, #0x28
    // 0xba8640: r0 = AllocateArray()
    //     0xba8640: bl              #0x13df928  ; AllocateArrayStub
    // 0xba8644: ldur            x3, [fp, #-0x30]
    // 0xba8648: StoreField: r3->field_f = r0
    //     0xba8648: stur            w0, [x3, #0xf]
    // 0xba864c: ldur            x0, [fp, #-0x28]
    // 0xba8650: StoreField: r3->field_7 = r0
    //     0xba8650: stur            w0, [x3, #7]
    // 0xba8654: ldur            x2, [fp, #-0x20]
    // 0xba8658: r0 = BoxInt64Instr(r2)
    //     0xba8658: sbfiz           x0, x2, #1, #0x1f
    //     0xba865c: cmp             x2, x0, asr #1
    //     0xba8660: b.eq            #0xba866c
    //     0xba8664: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba8668: stur            x2, [x0, #7]
    // 0xba866c: ldur            x1, [fp, #-0x18]
    // 0xba8670: mov             x2, x0
    // 0xba8674: r0 = []=()
    //     0xba8674: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba8678: ldur            x1, [fp, #-0x10]
    // 0xba867c: r0 = LoadClassIdInstr(r1)
    //     0xba867c: ldur            x0, [x1, #-1]
    //     0xba8680: ubfx            x0, x0, #0xc, #0x14
    // 0xba8684: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba8684: mov             x17, #0x5eb5
    //     0xba8688: movk            x17, #1, lsl #16
    //     0xba868c: add             lr, x0, x17
    //     0xba8690: ldr             lr, [x21, lr, lsl #3]
    //     0xba8694: blr             lr
    // 0xba8698: ldur            x1, [fp, #-8]
    // 0xba869c: StoreField: r1->field_93 = r0
    //     0xba869c: stur            w0, [x1, #0x93]
    //     0xba86a0: ldurb           w16, [x1, #-1]
    //     0xba86a4: ldurb           w17, [x0, #-1]
    //     0xba86a8: and             x16, x17, x16, lsr #2
    //     0xba86ac: tst             x16, HEAP, lsr #32
    //     0xba86b0: b.eq            #0xba86b8
    //     0xba86b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba86b8: LoadField: r2 = r1->field_33
    //     0xba86b8: ldur            w2, [x1, #0x33]
    // 0xba86bc: DecompressPointer r2
    //     0xba86bc: add             x2, x2, HEAP, lsl #32
    // 0xba86c0: r16 = Instance__ScaleState
    //     0xba86c0: add             x16, PP, #0x84, lsl #12  ; [pp+0x84e10] Obj!_ScaleState@12c5b81
    //     0xba86c4: ldr             x16, [x16, #0xe10]
    // 0xba86c8: cmp             w2, w16
    // 0xba86cc: b.ne            #0xba86f8
    // 0xba86d0: r3 = Instance__ScaleState
    //     0xba86d0: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0xba86d4: ldr             x3, [x3, #0xc50]
    // 0xba86d8: r2 = 0.000000
    //     0xba86d8: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xba86dc: StoreField: r1->field_33 = r3
    //     0xba86dc: stur            w3, [x1, #0x33]
    // 0xba86e0: StoreField: r1->field_47 = r2
    //     0xba86e0: stur            w2, [x1, #0x47]
    // 0xba86e4: StoreField: r1->field_4b = r2
    //     0xba86e4: stur            w2, [x1, #0x4b]
    // 0xba86e8: StoreField: r1->field_4f = r2
    //     0xba86e8: stur            w2, [x1, #0x4f]
    // 0xba86ec: StoreField: r1->field_53 = r2
    //     0xba86ec: stur            w2, [x1, #0x53]
    // 0xba86f0: StoreField: r1->field_57 = r2
    //     0xba86f0: stur            w2, [x1, #0x57]
    // 0xba86f4: StoreField: r1->field_5b = r2
    //     0xba86f4: stur            w2, [x1, #0x5b]
    // 0xba86f8: r0 = Null
    //     0xba86f8: mov             x0, NULL
    // 0xba86fc: LeaveFrame
    //     0xba86fc: mov             SP, fp
    //     0xba8700: ldp             fp, lr, [SP], #0x10
    // 0xba8704: ret
    //     0xba8704: ret             
    // 0xba8708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8708: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba870c: b               #0xba85c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb1750, size: 0x4c
    // 0xbb1750: EnterFrame
    //     0xbb1750: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1754: mov             fp, SP
    // 0xbb1758: AllocStack(0x8)
    //     0xbb1758: sub             SP, SP, #8
    // 0xbb175c: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xbb175c: mov             x0, x1
    //     0xbb1760: stur            x1, [fp, #-8]
    // 0xbb1764: CheckStackOverflow
    //     0xbb1764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1768: cmp             SP, x16
    //     0xbb176c: b.ls            #0xbb1794
    // 0xbb1770: LoadField: r1 = r0->field_73
    //     0xbb1770: ldur            w1, [x0, #0x73]
    // 0xbb1774: DecompressPointer r1
    //     0xbb1774: add             x1, x1, HEAP, lsl #32
    // 0xbb1778: r0 = clear()
    //     0xbb1778: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbb177c: ldur            x1, [fp, #-8]
    // 0xbb1780: r0 = dispose()
    //     0xbb1780: bl              #0xbb179c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbb1784: r0 = Null
    //     0xbb1784: mov             x0, NULL
    // 0xbb1788: LeaveFrame
    //     0xbb1788: mov             SP, fp
    //     0xbb178c: ldp             fp, lr, [SP], #0x10
    // 0xbb1790: ret
    //     0xbb1790: ret             
    // 0xbb1794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1798: b               #0xbb1770
  }
  _ addAllowedPointerPanZoom(/* No info */) {
    // ** addr: 0xd00808, size: 0x1ac
    // 0xd00808: EnterFrame
    //     0xd00808: stp             fp, lr, [SP, #-0x10]!
    //     0xd0080c: mov             fp, SP
    // 0xd00810: AllocStack(0x30)
    //     0xd00810: sub             SP, SP, #0x30
    // 0xd00814: SetupParameters(ScaleGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd00814: mov             x3, x1
    //     0xd00818: stur            x1, [fp, #-8]
    //     0xd0081c: stur            x2, [fp, #-0x10]
    // 0xd00820: CheckStackOverflow
    //     0xd00820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00824: cmp             SP, x16
    //     0xd00828: b.ls            #0xd009ac
    // 0xd0082c: r0 = LoadClassIdInstr(r2)
    //     0xd0082c: ldur            x0, [x2, #-1]
    //     0xd00830: ubfx            x0, x0, #0xc, #0x14
    // 0xd00834: mov             x1, x2
    // 0xd00838: r0 = GDT[cid_x0 + -0x1]()
    //     0xd00838: sub             lr, x0, #1
    //     0xd0083c: ldr             lr, [x21, lr, lsl #3]
    //     0xd00840: blr             lr
    // 0xd00844: mov             x3, x0
    // 0xd00848: ldur            x2, [fp, #-0x10]
    // 0xd0084c: stur            x3, [fp, #-0x18]
    // 0xd00850: r0 = LoadClassIdInstr(r2)
    //     0xd00850: ldur            x0, [x2, #-1]
    //     0xd00854: ubfx            x0, x0, #0xc, #0x14
    // 0xd00858: mov             x1, x2
    // 0xd0085c: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xd0085c: mov             x17, #0x5fe3
    //     0xd00860: movk            x17, #1, lsl #16
    //     0xd00864: add             lr, x0, x17
    //     0xd00868: ldr             lr, [x21, lr, lsl #3]
    //     0xd0086c: blr             lr
    // 0xd00870: ldur            x1, [fp, #-8]
    // 0xd00874: ldur            x2, [fp, #-0x18]
    // 0xd00878: mov             x3, x0
    // 0xd0087c: r0 = startTrackingPointer()
    //     0xd0087c: bl              #0x10f2e54  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0xd00880: ldur            x2, [fp, #-8]
    // 0xd00884: LoadField: r3 = r2->field_73
    //     0xd00884: ldur            w3, [x2, #0x73]
    // 0xd00888: DecompressPointer r3
    //     0xd00888: add             x3, x3, HEAP, lsl #32
    // 0xd0088c: ldur            x4, [fp, #-0x10]
    // 0xd00890: stur            x3, [fp, #-0x20]
    // 0xd00894: r0 = LoadClassIdInstr(r4)
    //     0xd00894: ldur            x0, [x4, #-1]
    //     0xd00898: ubfx            x0, x0, #0xc, #0x14
    // 0xd0089c: mov             x1, x4
    // 0xd008a0: r0 = GDT[cid_x0 + -0x1]()
    //     0xd008a0: sub             lr, x0, #1
    //     0xd008a4: ldr             lr, [x21, lr, lsl #3]
    //     0xd008a8: blr             lr
    // 0xd008ac: mov             x3, x0
    // 0xd008b0: ldur            x2, [fp, #-0x10]
    // 0xd008b4: stur            x3, [fp, #-0x18]
    // 0xd008b8: r0 = LoadClassIdInstr(r2)
    //     0xd008b8: ldur            x0, [x2, #-1]
    //     0xd008bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd008c0: mov             x1, x2
    // 0xd008c4: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xd008c4: mov             x17, #0x5e74
    //     0xd008c8: movk            x17, #1, lsl #16
    //     0xd008cc: add             lr, x0, x17
    //     0xd008d0: ldr             lr, [x21, lr, lsl #3]
    //     0xd008d4: blr             lr
    // 0xd008d8: stur            x0, [fp, #-0x28]
    // 0xd008dc: r0 = VelocityTracker()
    //     0xd008dc: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0xd008e0: stur            x0, [fp, #-0x30]
    // 0xd008e4: StoreField: r0->field_13 = rZR
    //     0xd008e4: stur            xzr, [x0, #0x13]
    // 0xd008e8: r1 = <_PointAtTime?>
    //     0xd008e8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0xd008ec: ldr             x1, [x1, #0x568]
    // 0xd008f0: r2 = 40
    //     0xd008f0: mov             x2, #0x28
    // 0xd008f4: r0 = AllocateArray()
    //     0xd008f4: bl              #0x13df928  ; AllocateArrayStub
    // 0xd008f8: ldur            x3, [fp, #-0x30]
    // 0xd008fc: StoreField: r3->field_f = r0
    //     0xd008fc: stur            w0, [x3, #0xf]
    // 0xd00900: ldur            x0, [fp, #-0x28]
    // 0xd00904: StoreField: r3->field_7 = r0
    //     0xd00904: stur            w0, [x3, #7]
    // 0xd00908: ldur            x2, [fp, #-0x18]
    // 0xd0090c: r0 = BoxInt64Instr(r2)
    //     0xd0090c: sbfiz           x0, x2, #1, #0x1f
    //     0xd00910: cmp             x2, x0, asr #1
    //     0xd00914: b.eq            #0xd00920
    //     0xd00918: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd0091c: stur            x2, [x0, #7]
    // 0xd00920: ldur            x1, [fp, #-0x20]
    // 0xd00924: mov             x2, x0
    // 0xd00928: r0 = []=()
    //     0xd00928: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd0092c: ldur            x1, [fp, #-0x10]
    // 0xd00930: r0 = LoadClassIdInstr(r1)
    //     0xd00930: ldur            x0, [x1, #-1]
    //     0xd00934: ubfx            x0, x0, #0xc, #0x14
    // 0xd00938: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xd00938: mov             x17, #0x5eb5
    //     0xd0093c: movk            x17, #1, lsl #16
    //     0xd00940: add             lr, x0, x17
    //     0xd00944: ldr             lr, [x21, lr, lsl #3]
    //     0xd00948: blr             lr
    // 0xd0094c: ldur            x1, [fp, #-8]
    // 0xd00950: StoreField: r1->field_93 = r0
    //     0xd00950: stur            w0, [x1, #0x93]
    //     0xd00954: ldurb           w16, [x1, #-1]
    //     0xd00958: ldurb           w17, [x0, #-1]
    //     0xd0095c: and             x16, x17, x16, lsr #2
    //     0xd00960: tst             x16, HEAP, lsr #32
    //     0xd00964: b.eq            #0xd0096c
    //     0xd00968: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd0096c: LoadField: r2 = r1->field_33
    //     0xd0096c: ldur            w2, [x1, #0x33]
    // 0xd00970: DecompressPointer r2
    //     0xd00970: add             x2, x2, HEAP, lsl #32
    // 0xd00974: r16 = Instance__ScaleState
    //     0xd00974: add             x16, PP, #0x84, lsl #12  ; [pp+0x84e10] Obj!_ScaleState@12c5b81
    //     0xd00978: ldr             x16, [x16, #0xe10]
    // 0xd0097c: cmp             w2, w16
    // 0xd00980: b.ne            #0xd0099c
    // 0xd00984: r2 = Instance__ScaleState
    //     0xd00984: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0xd00988: ldr             x2, [x2, #0xc50]
    // 0xd0098c: d0 = 1.000000
    //     0xd0098c: fmov            d0, #1.00000000
    // 0xd00990: StoreField: r1->field_33 = r2
    //     0xd00990: stur            w2, [x1, #0x33]
    // 0xd00994: StoreField: r1->field_83 = d0
    //     0xd00994: stur            d0, [x1, #0x83]
    // 0xd00998: StoreField: r1->field_8b = rZR
    //     0xd00998: stur            xzr, [x1, #0x8b]
    // 0xd0099c: r0 = Null
    //     0xd0099c: mov             x0, NULL
    // 0xd009a0: LeaveFrame
    //     0xd009a0: mov             SP, fp
    //     0xd009a4: ldp             fp, lr, [SP], #0x10
    // 0xd009a8: ret
    //     0xd009a8: ret             
    // 0xd009ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd009ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd009b0: b               #0xd0082c
  }
  _ ScaleGestureRecognizer(/* No info */) {
    // ** addr: 0xfc1c44, size: 0x168
    // 0xfc1c44: EnterFrame
    //     0xfc1c44: stp             fp, lr, [SP, #-0x10]!
    //     0xfc1c48: mov             fp, SP
    // 0xfc1c4c: AllocStack(0x18)
    //     0xfc1c4c: sub             SP, SP, #0x18
    // 0xfc1c50: r2 = Instance__ScaleState
    //     0xfc1c50: add             x2, PP, #0x84, lsl #12  ; [pp+0x84e10] Obj!_ScaleState@12c5b81
    //     0xfc1c54: ldr             x2, [x2, #0xe10]
    // 0xfc1c58: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfc1c5c: d0 = 1.000000
    //     0xfc1c5c: fmov            d0, #1.00000000
    // 0xfc1c60: stur            x1, [fp, #-8]
    // 0xfc1c64: CheckStackOverflow
    //     0xfc1c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfc1c68: cmp             SP, x16
    //     0xfc1c6c: b.ls            #0xfc1da4
    // 0xfc1c70: StoreField: r1->field_33 = r2
    //     0xfc1c70: stur            w2, [x1, #0x33]
    // 0xfc1c74: StoreField: r1->field_3f = r0
    //     0xfc1c74: stur            w0, [x1, #0x3f]
    // 0xfc1c78: StoreField: r1->field_47 = r0
    //     0xfc1c78: stur            w0, [x1, #0x47]
    // 0xfc1c7c: StoreField: r1->field_4b = r0
    //     0xfc1c7c: stur            w0, [x1, #0x4b]
    // 0xfc1c80: StoreField: r1->field_4f = r0
    //     0xfc1c80: stur            w0, [x1, #0x4f]
    // 0xfc1c84: StoreField: r1->field_53 = r0
    //     0xfc1c84: stur            w0, [x1, #0x53]
    // 0xfc1c88: StoreField: r1->field_57 = r0
    //     0xfc1c88: stur            w0, [x1, #0x57]
    // 0xfc1c8c: StoreField: r1->field_5b = r0
    //     0xfc1c8c: stur            w0, [x1, #0x5b]
    // 0xfc1c90: StoreField: r1->field_5f = r0
    //     0xfc1c90: stur            w0, [x1, #0x5f]
    // 0xfc1c94: StoreField: r1->field_7b = r0
    //     0xfc1c94: stur            w0, [x1, #0x7b]
    // 0xfc1c98: StoreField: r1->field_83 = d0
    //     0xfc1c98: stur            d0, [x1, #0x83]
    // 0xfc1c9c: StoreField: r1->field_8b = rZR
    //     0xfc1c9c: stur            xzr, [x1, #0x8b]
    // 0xfc1ca0: r16 = <int, Offset>
    //     0xfc1ca0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xfc1ca4: ldr             x16, [x16, #0x540]
    // 0xfc1ca8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfc1cac: stp             lr, x16, [SP]
    // 0xfc1cb0: r0 = Map._fromLiteral()
    //     0xfc1cb0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc1cb4: ldur            x3, [fp, #-8]
    // 0xfc1cb8: StoreField: r3->field_6b = r0
    //     0xfc1cb8: stur            w0, [x3, #0x6b]
    //     0xfc1cbc: ldurb           w16, [x3, #-1]
    //     0xfc1cc0: ldurb           w17, [x0, #-1]
    //     0xfc1cc4: and             x16, x17, x16, lsr #2
    //     0xfc1cc8: tst             x16, HEAP, lsr #32
    //     0xfc1ccc: b.eq            #0xfc1cd4
    //     0xfc1cd0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfc1cd4: r1 = <int>
    //     0xfc1cd4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xfc1cd8: r2 = 0
    //     0xfc1cd8: mov             x2, #0
    // 0xfc1cdc: r0 = _GrowableList()
    //     0xfc1cdc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfc1ce0: ldur            x1, [fp, #-8]
    // 0xfc1ce4: StoreField: r1->field_6f = r0
    //     0xfc1ce4: stur            w0, [x1, #0x6f]
    //     0xfc1ce8: ldurb           w16, [x1, #-1]
    //     0xfc1cec: ldurb           w17, [x0, #-1]
    //     0xfc1cf0: and             x16, x17, x16, lsr #2
    //     0xfc1cf4: tst             x16, HEAP, lsr #32
    //     0xfc1cf8: b.eq            #0xfc1d00
    //     0xfc1cfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfc1d00: r16 = <int, VelocityTracker>
    //     0xfc1d00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15538] TypeArguments: <int, VelocityTracker>
    //     0xfc1d04: ldr             x16, [x16, #0x538]
    // 0xfc1d08: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfc1d0c: stp             lr, x16, [SP]
    // 0xfc1d10: r0 = Map._fromLiteral()
    //     0xfc1d10: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc1d14: ldur            x1, [fp, #-8]
    // 0xfc1d18: StoreField: r1->field_73 = r0
    //     0xfc1d18: stur            w0, [x1, #0x73]
    //     0xfc1d1c: ldurb           w16, [x1, #-1]
    //     0xfc1d20: ldurb           w17, [x0, #-1]
    //     0xfc1d24: and             x16, x17, x16, lsr #2
    //     0xfc1d28: tst             x16, HEAP, lsr #32
    //     0xfc1d2c: b.eq            #0xfc1d34
    //     0xfc1d30: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfc1d34: r16 = <int, _PointerPanZoomData>
    //     0xfc1d34: add             x16, PP, #0x84, lsl #12  ; [pp+0x84e18] TypeArguments: <int, _PointerPanZoomData>
    //     0xfc1d38: ldr             x16, [x16, #0xe18]
    // 0xfc1d3c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfc1d40: stp             lr, x16, [SP]
    // 0xfc1d44: r0 = Map._fromLiteral()
    //     0xfc1d44: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc1d48: ldur            x1, [fp, #-8]
    // 0xfc1d4c: StoreField: r1->field_7f = r0
    //     0xfc1d4c: stur            w0, [x1, #0x7f]
    //     0xfc1d50: ldurb           w16, [x1, #-1]
    //     0xfc1d54: ldurb           w17, [x0, #-1]
    //     0xfc1d58: and             x16, x17, x16, lsr #2
    //     0xfc1d5c: tst             x16, HEAP, lsr #32
    //     0xfc1d60: b.eq            #0xfc1d68
    //     0xfc1d64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfc1d68: r0 = Instance_DragStartBehavior
    //     0xfc1d68: add             x0, PP, #0x84, lsl #12  ; [pp+0x84e20] Obj!DragStartBehavior@12c5c81
    //     0xfc1d6c: ldr             x0, [x0, #0xe20]
    // 0xfc1d70: StoreField: r1->field_23 = r0
    //     0xfc1d70: stur            w0, [x1, #0x23]
    // 0xfc1d74: r0 = false
    //     0xfc1d74: add             x0, NULL, #0x30  ; false
    // 0xfc1d78: StoreField: r1->field_3b = r0
    //     0xfc1d78: stur            w0, [x1, #0x3b]
    // 0xfc1d7c: r16 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static.
    //     0xfc1d7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xfc1d80: ldr             x16, [x16, #0x578]
    // 0xfc1d84: stp             x16, NULL, [SP]
    // 0xfc1d88: r4 = const [0, 0x3, 0x2, 0x1, allowedButtonsFilter, 0x2, supportedDevices, 0x1, null]
    //     0xfc1d88: add             x4, PP, #0x15, lsl #12  ; [pp+0x15560] List(9) [0, 0x3, 0x2, 0x1, "allowedButtonsFilter", 0x2, "supportedDevices", 0x1, Null]
    //     0xfc1d8c: ldr             x4, [x4, #0x560]
    // 0xfc1d90: r0 = OneSequenceGestureRecognizer()
    //     0xfc1d90: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xfc1d94: r0 = Null
    //     0xfc1d94: mov             x0, NULL
    // 0xfc1d98: LeaveFrame
    //     0xfc1d98: mov             SP, fp
    //     0xfc1d9c: ldp             fp, lr, [SP], #0x10
    // 0xfc1da0: ret
    //     0xfc1da0: ret             
    // 0xfc1da4: r0 = StackOverflowSharedWithFPURegs()
    //     0xfc1da4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xfc1da8: b               #0xfc1c70
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d194, size: 0x98
    // 0x116d194: EnterFrame
    //     0x116d194: stp             fp, lr, [SP, #-0x10]!
    //     0x116d198: mov             fp, SP
    // 0x116d19c: AllocStack(0x10)
    //     0x116d19c: sub             SP, SP, #0x10
    // 0x116d1a0: SetupParameters(ScaleGestureRecognizer this /* r1 => r3, fp-0x10 */)
    //     0x116d1a0: mov             x3, x1
    //     0x116d1a4: stur            x1, [fp, #-0x10]
    // 0x116d1a8: CheckStackOverflow
    //     0x116d1a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d1ac: cmp             SP, x16
    //     0x116d1b0: b.ls            #0x116d224
    // 0x116d1b4: LoadField: r4 = r3->field_7f
    //     0x116d1b4: ldur            w4, [x3, #0x7f]
    // 0x116d1b8: DecompressPointer r4
    //     0x116d1b8: add             x4, x4, HEAP, lsl #32
    // 0x116d1bc: r0 = BoxInt64Instr(r2)
    //     0x116d1bc: sbfiz           x0, x2, #1, #0x1f
    //     0x116d1c0: cmp             x2, x0, asr #1
    //     0x116d1c4: b.eq            #0x116d1d0
    //     0x116d1c8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d1cc: stur            x2, [x0, #7]
    // 0x116d1d0: mov             x1, x4
    // 0x116d1d4: mov             x2, x0
    // 0x116d1d8: stur            x0, [fp, #-8]
    // 0x116d1dc: r0 = remove()
    //     0x116d1dc: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x116d1e0: ldur            x0, [fp, #-0x10]
    // 0x116d1e4: LoadField: r1 = r0->field_6b
    //     0x116d1e4: ldur            w1, [x0, #0x6b]
    // 0x116d1e8: DecompressPointer r1
    //     0x116d1e8: add             x1, x1, HEAP, lsl #32
    // 0x116d1ec: ldur            x2, [fp, #-8]
    // 0x116d1f0: r0 = remove()
    //     0x116d1f0: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x116d1f4: ldur            x0, [fp, #-0x10]
    // 0x116d1f8: LoadField: r1 = r0->field_6f
    //     0x116d1f8: ldur            w1, [x0, #0x6f]
    // 0x116d1fc: DecompressPointer r1
    //     0x116d1fc: add             x1, x1, HEAP, lsl #32
    // 0x116d200: ldur            x2, [fp, #-8]
    // 0x116d204: r0 = remove()
    //     0x116d204: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0x116d208: ldur            x1, [fp, #-0x10]
    // 0x116d20c: ldur            x2, [fp, #-8]
    // 0x116d210: r0 = stopTrackingPointer()
    //     0x116d210: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x116d214: r0 = Null
    //     0x116d214: mov             x0, NULL
    // 0x116d218: LeaveFrame
    //     0x116d218: mov             SP, fp
    //     0x116d21c: ldp             fp, lr, [SP], #0x10
    // 0x116d220: ret
    //     0x116d220: ret             
    // 0x116d224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d228: b               #0x116d1b4
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119c7cc, size: 0x278
    // 0x119c7cc: EnterFrame
    //     0x119c7cc: stp             fp, lr, [SP, #-0x10]!
    //     0x119c7d0: mov             fp, SP
    // 0x119c7d4: AllocStack(0x30)
    //     0x119c7d4: sub             SP, SP, #0x30
    // 0x119c7d8: SetupParameters(ScaleGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0x119c7d8: mov             x0, x1
    //     0x119c7dc: stur            x1, [fp, #-8]
    // 0x119c7e0: CheckStackOverflow
    //     0x119c7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c7e4: cmp             SP, x16
    //     0x119c7e8: b.ls            #0x119ca14
    // 0x119c7ec: LoadField: r1 = r0->field_33
    //     0x119c7ec: ldur            w1, [x0, #0x33]
    // 0x119c7f0: DecompressPointer r1
    //     0x119c7f0: add             x1, x1, HEAP, lsl #32
    // 0x119c7f4: r16 = Instance__ScaleState
    //     0x119c7f4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cc50] Obj!_ScaleState@12c5ba1
    //     0x119c7f8: ldr             x16, [x16, #0xc50]
    // 0x119c7fc: cmp             w1, w16
    // 0x119c800: b.ne            #0x119ca04
    // 0x119c804: r1 = Instance__ScaleState
    //     0x119c804: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cc68] Obj!_ScaleState@12c5b61
    //     0x119c808: ldr             x1, [x1, #0xc68]
    // 0x119c80c: StoreField: r0->field_33 = r1
    //     0x119c80c: stur            w1, [x0, #0x33]
    // 0x119c810: mov             x1, x0
    // 0x119c814: r0 = _dispatchOnStartCallbackIfNeeded()
    //     0x119c814: bl              #0xba1834  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded
    // 0x119c818: ldur            x2, [fp, #-8]
    // 0x119c81c: LoadField: r0 = r2->field_23
    //     0x119c81c: ldur            w0, [x2, #0x23]
    // 0x119c820: DecompressPointer r0
    //     0x119c820: add             x0, x0, HEAP, lsl #32
    // 0x119c824: r16 = Instance_DragStartBehavior
    //     0x119c824: ldr             x16, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0x119c828: cmp             w0, w16
    // 0x119c82c: b.ne            #0x119ca04
    // 0x119c830: LoadField: r0 = r2->field_43
    //     0x119c830: ldur            w0, [x2, #0x43]
    // 0x119c834: DecompressPointer r0
    //     0x119c834: add             x0, x0, HEAP, lsl #32
    // 0x119c838: cmp             w0, NULL
    // 0x119c83c: b.eq            #0x119ca1c
    // 0x119c840: StoreField: r2->field_3f = r0
    //     0x119c840: stur            w0, [x2, #0x3f]
    //     0x119c844: ldurb           w16, [x2, #-1]
    //     0x119c848: ldurb           w17, [x0, #-1]
    //     0x119c84c: and             x16, x17, x16, lsr #2
    //     0x119c850: tst             x16, HEAP, lsr #32
    //     0x119c854: b.eq            #0x119c85c
    //     0x119c858: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119c85c: LoadField: r0 = r2->field_4b
    //     0x119c85c: ldur            w0, [x2, #0x4b]
    // 0x119c860: DecompressPointer r0
    //     0x119c860: add             x0, x0, HEAP, lsl #32
    // 0x119c864: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119c868: cmp             w0, w16
    // 0x119c86c: b.eq            #0x119ca20
    // 0x119c870: StoreField: r2->field_47 = r0
    //     0x119c870: stur            w0, [x2, #0x47]
    //     0x119c874: ldurb           w16, [x2, #-1]
    //     0x119c878: ldurb           w17, [x0, #-1]
    //     0x119c87c: and             x16, x17, x16, lsr #2
    //     0x119c880: tst             x16, HEAP, lsr #32
    //     0x119c884: b.eq            #0x119c88c
    //     0x119c888: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119c88c: LoadField: r0 = r2->field_67
    //     0x119c88c: ldur            w0, [x2, #0x67]
    // 0x119c890: DecompressPointer r0
    //     0x119c890: add             x0, x0, HEAP, lsl #32
    // 0x119c894: StoreField: r2->field_63 = r0
    //     0x119c894: stur            w0, [x2, #0x63]
    //     0x119c898: ldurb           w16, [x2, #-1]
    //     0x119c89c: ldurb           w17, [x0, #-1]
    //     0x119c8a0: and             x16, x17, x16, lsr #2
    //     0x119c8a4: tst             x16, HEAP, lsr #32
    //     0x119c8a8: b.eq            #0x119c8b0
    //     0x119c8ac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119c8b0: LoadField: r0 = r2->field_53
    //     0x119c8b0: ldur            w0, [x2, #0x53]
    // 0x119c8b4: DecompressPointer r0
    //     0x119c8b4: add             x0, x0, HEAP, lsl #32
    // 0x119c8b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119c8bc: cmp             w0, w16
    // 0x119c8c0: b.eq            #0x119ca2c
    // 0x119c8c4: StoreField: r2->field_4f = r0
    //     0x119c8c4: stur            w0, [x2, #0x4f]
    //     0x119c8c8: ldurb           w16, [x2, #-1]
    //     0x119c8cc: ldurb           w17, [x0, #-1]
    //     0x119c8d0: and             x16, x17, x16, lsr #2
    //     0x119c8d4: tst             x16, HEAP, lsr #32
    //     0x119c8d8: b.eq            #0x119c8e0
    //     0x119c8dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119c8e0: LoadField: r0 = r2->field_5b
    //     0x119c8e0: ldur            w0, [x2, #0x5b]
    // 0x119c8e4: DecompressPointer r0
    //     0x119c8e4: add             x0, x0, HEAP, lsl #32
    // 0x119c8e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119c8ec: cmp             w0, w16
    // 0x119c8f0: b.eq            #0x119ca38
    // 0x119c8f4: StoreField: r2->field_57 = r0
    //     0x119c8f4: stur            w0, [x2, #0x57]
    //     0x119c8f8: ldurb           w16, [x2, #-1]
    //     0x119c8fc: ldurb           w17, [x0, #-1]
    //     0x119c900: and             x16, x17, x16, lsr #2
    //     0x119c904: tst             x16, HEAP, lsr #32
    //     0x119c908: b.eq            #0x119c910
    //     0x119c90c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119c910: LoadField: r0 = r2->field_7f
    //     0x119c910: ldur            w0, [x2, #0x7f]
    // 0x119c914: DecompressPointer r0
    //     0x119c914: add             x0, x0, HEAP, lsl #32
    // 0x119c918: stur            x0, [fp, #-0x10]
    // 0x119c91c: LoadField: r1 = r0->field_13
    //     0x119c91c: ldur            w1, [x0, #0x13]
    // 0x119c920: r3 = LoadInt32Instr(r1)
    //     0x119c920: sbfx            x3, x1, #1, #0x1f
    // 0x119c924: asr             x1, x3, #1
    // 0x119c928: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x119c928: ldur            w3, [x0, #0x17]
    // 0x119c92c: r4 = LoadInt32Instr(r3)
    //     0x119c92c: sbfx            x4, x3, #1, #0x1f
    // 0x119c930: sub             x3, x1, x4
    // 0x119c934: cbnz            x3, #0x119c948
    // 0x119c938: d0 = 1.000000
    //     0x119c938: fmov            d0, #1.00000000
    // 0x119c93c: StoreField: r2->field_83 = d0
    //     0x119c93c: stur            d0, [x2, #0x83]
    // 0x119c940: StoreField: r2->field_8b = rZR
    //     0x119c940: stur            xzr, [x2, #0x8b]
    // 0x119c944: b               #0x119ca04
    // 0x119c948: mov             x1, x2
    // 0x119c94c: r0 = _scaleFactor()
    //     0x119c94c: bl              #0xadf19c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0x119c950: ldur            x0, [fp, #-8]
    // 0x119c954: LoadField: r1 = r0->field_47
    //     0x119c954: ldur            w1, [x0, #0x47]
    // 0x119c958: DecompressPointer r1
    //     0x119c958: add             x1, x1, HEAP, lsl #32
    // 0x119c95c: LoadField: d1 = r1->field_7
    //     0x119c95c: ldur            d1, [x1, #7]
    // 0x119c960: d2 = 0.000000
    //     0x119c960: eor             v2.16b, v2.16b, v2.16b
    // 0x119c964: fcmp            d1, d2
    // 0x119c968: b.le            #0x119c984
    // 0x119c96c: LoadField: r1 = r0->field_4b
    //     0x119c96c: ldur            w1, [x0, #0x4b]
    // 0x119c970: DecompressPointer r1
    //     0x119c970: add             x1, x1, HEAP, lsl #32
    // 0x119c974: LoadField: d2 = r1->field_7
    //     0x119c974: ldur            d2, [x1, #7]
    // 0x119c978: fdiv            d3, d2, d1
    // 0x119c97c: mov             v1.16b, v3.16b
    // 0x119c980: b               #0x119c988
    // 0x119c984: d1 = 1.000000
    //     0x119c984: fmov            d1, #1.00000000
    // 0x119c988: ldur            x2, [fp, #-0x10]
    // 0x119c98c: fdiv            d2, d0, d1
    // 0x119c990: StoreField: r0->field_83 = d2
    //     0x119c990: stur            d2, [x0, #0x83]
    // 0x119c994: r1 = <_PointerPanZoomData>
    //     0x119c994: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cca0] TypeArguments: <_PointerPanZoomData>
    //     0x119c998: ldr             x1, [x1, #0xca0]
    // 0x119c99c: r0 = _CompactValuesIterable()
    //     0x119c99c: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x119c9a0: mov             x3, x0
    // 0x119c9a4: ldur            x0, [fp, #-0x10]
    // 0x119c9a8: stur            x3, [fp, #-0x18]
    // 0x119c9ac: StoreField: r3->field_b = r0
    //     0x119c9ac: stur            w0, [x3, #0xb]
    // 0x119c9b0: r1 = Function '<anonymous closure>':.
    //     0x119c9b0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd90] AnonymousClosure: (0xadf5b4), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0x119c9b4: ldr             x1, [x1, #0xd90]
    // 0x119c9b8: r2 = Null
    //     0x119c9b8: mov             x2, NULL
    // 0x119c9bc: r0 = AllocateClosure()
    //     0x119c9bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119c9c0: r16 = <double>
    //     0x119c9c0: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x119c9c4: ldur            lr, [fp, #-0x18]
    // 0x119c9c8: stp             lr, x16, [SP, #8]
    // 0x119c9cc: str             x0, [SP]
    // 0x119c9d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x119c9d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x119c9d4: r0 = map()
    //     0x119c9d4: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x119c9d8: r1 = Function '<anonymous closure>':.
    //     0x119c9d8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cd98] AnonymousClosure: (0xade914), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0x119c9dc: ldr             x1, [x1, #0xd98]
    // 0x119c9e0: r2 = Null
    //     0x119c9e0: mov             x2, NULL
    // 0x119c9e4: stur            x0, [fp, #-0x10]
    // 0x119c9e8: r0 = AllocateClosure()
    //     0x119c9e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119c9ec: ldur            x1, [fp, #-0x10]
    // 0x119c9f0: mov             x2, x0
    // 0x119c9f4: r0 = reduce()
    //     0x119c9f4: bl              #0xadf774  ; [dart:core] Iterable::reduce
    // 0x119c9f8: LoadField: d0 = r0->field_7
    //     0x119c9f8: ldur            d0, [x0, #7]
    // 0x119c9fc: ldur            x1, [fp, #-8]
    // 0x119ca00: StoreField: r1->field_8b = d0
    //     0x119ca00: stur            d0, [x1, #0x8b]
    // 0x119ca04: r0 = Null
    //     0x119ca04: mov             x0, NULL
    // 0x119ca08: LeaveFrame
    //     0x119ca08: mov             SP, fp
    //     0x119ca0c: ldp             fp, lr, [SP], #0x10
    // 0x119ca10: ret
    //     0x119ca10: ret             
    // 0x119ca14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119ca14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119ca18: b               #0x119c7ec
    // 0x119ca1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119ca1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x119ca20: r9 = _currentSpan
    //     0x119ca20: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc78] Field <ScaleGestureRecognizer._currentSpan@661213599>: late (offset: 0x4c)
    //     0x119ca24: ldr             x9, [x9, #0xc78]
    // 0x119ca28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119ca28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119ca2c: r9 = _currentHorizontalSpan
    //     0x119ca2c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccf0] Field <ScaleGestureRecognizer._currentHorizontalSpan@661213599>: late (offset: 0x54)
    //     0x119ca30: ldr             x9, [x9, #0xcf0]
    // 0x119ca34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119ca34: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119ca38: r9 = _currentVerticalSpan
    //     0x119ca38: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ccd0] Field <ScaleGestureRecognizer._currentVerticalSpan@661213599>: late (offset: 0x5c)
    //     0x119ca3c: ldr             x9, [x9, #0xcd0]
    // 0x119ca40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119ca40: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5220, size: 0x14, field offset: 0x8
class ScaleEndDetails extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5221, size: 0x20, field offset: 0x8
class ScaleUpdateDetails extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5222, size: 0x10, field offset: 0x8
class ScaleStartDetails extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 8305, size: 0x14, field offset: 0x14
enum _ScaleState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9b80, size: 0x64
    // 0x11a9b80: EnterFrame
    //     0x11a9b80: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9b84: mov             fp, SP
    // 0x11a9b88: AllocStack(0x10)
    //     0x11a9b88: sub             SP, SP, #0x10
    // 0x11a9b8c: SetupParameters(_ScaleState this /* r1 => r0, fp-0x8 */)
    //     0x11a9b8c: mov             x0, x1
    //     0x11a9b90: stur            x1, [fp, #-8]
    // 0x11a9b94: CheckStackOverflow
    //     0x11a9b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9b98: cmp             SP, x16
    //     0x11a9b9c: b.ls            #0x11a9bdc
    // 0x11a9ba0: r1 = Null
    //     0x11a9ba0: mov             x1, NULL
    // 0x11a9ba4: r2 = 4
    //     0x11a9ba4: mov             x2, #4
    // 0x11a9ba8: r0 = AllocateArray()
    //     0x11a9ba8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9bac: r16 = "_ScaleState."
    //     0x11a9bac: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cda0] "_ScaleState."
    //     0x11a9bb0: ldr             x16, [x16, #0xda0]
    // 0x11a9bb4: StoreField: r0->field_f = r16
    //     0x11a9bb4: stur            w16, [x0, #0xf]
    // 0x11a9bb8: ldur            x1, [fp, #-8]
    // 0x11a9bbc: LoadField: r2 = r1->field_f
    //     0x11a9bbc: ldur            w2, [x1, #0xf]
    // 0x11a9bc0: DecompressPointer r2
    //     0x11a9bc0: add             x2, x2, HEAP, lsl #32
    // 0x11a9bc4: StoreField: r0->field_13 = r2
    //     0x11a9bc4: stur            w2, [x0, #0x13]
    // 0x11a9bc8: str             x0, [SP]
    // 0x11a9bcc: r0 = _interpolate()
    //     0x11a9bcc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9bd0: LeaveFrame
    //     0x11a9bd0: mov             SP, fp
    //     0x11a9bd4: ldp             fp, lr, [SP], #0x10
    // 0x11a9bd8: ret
    //     0x11a9bd8: ret             
    // 0x11a9bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9be0: b               #0x11a9ba0
  }
}
