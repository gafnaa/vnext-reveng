// lib: , url: package:flutter/src/gestures/gesture_details.dart

// class id: 1048822, size: 0x8
class :: {
}

// class id: 3175, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class PositionedGestureDetails extends Object {
}
