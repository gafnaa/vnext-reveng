// lib: , url: package:flutter/src/gestures/velocity_tracker.dart

// class id: 1048837, size: 0x8
class :: {
}

// class id: 3144, size: 0x1c, field offset: 0x8
class VelocityTracker extends Object {

  _ getVelocity(/* No info */) {
    // ** addr: 0xadf114, size: 0x88
    // 0xadf114: EnterFrame
    //     0xadf114: stp             fp, lr, [SP, #-0x10]!
    //     0xadf118: mov             fp, SP
    // 0xadf11c: AllocStack(0x18)
    //     0xadf11c: sub             SP, SP, #0x18
    // 0xadf120: CheckStackOverflow
    //     0xadf120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf124: cmp             SP, x16
    //     0xadf128: b.ls            #0xadf194
    // 0xadf12c: r0 = LoadClassIdInstr(r1)
    //     0xadf12c: ldur            x0, [x1, #-1]
    //     0xadf130: ubfx            x0, x0, #0xc, #0x14
    // 0xadf134: r0 = GDT[cid_x0 + -0xff8]()
    //     0xadf134: sub             lr, x0, #0xff8
    //     0xadf138: ldr             lr, [x21, lr, lsl #3]
    //     0xadf13c: blr             lr
    // 0xadf140: cmp             w0, NULL
    // 0xadf144: b.eq            #0xadf164
    // 0xadf148: LoadField: r1 = r0->field_7
    //     0xadf148: ldur            w1, [x0, #7]
    // 0xadf14c: DecompressPointer r1
    //     0xadf14c: add             x1, x1, HEAP, lsl #32
    // 0xadf150: stur            x1, [fp, #-8]
    // 0xadf154: r16 = Instance_Offset
    //     0xadf154: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xadf158: stp             x16, x1, [SP]
    // 0xadf15c: r0 = ==()
    //     0xadf15c: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xadf160: tbnz            w0, #4, #0xadf178
    // 0xadf164: r0 = Instance_Velocity
    //     0xadf164: add             x0, PP, #0x80, lsl #12  ; [pp+0x80bb8] Obj!Velocity@129f141
    //     0xadf168: ldr             x0, [x0, #0xbb8]
    // 0xadf16c: LeaveFrame
    //     0xadf16c: mov             SP, fp
    //     0xadf170: ldp             fp, lr, [SP], #0x10
    // 0xadf174: ret
    //     0xadf174: ret             
    // 0xadf178: ldur            x0, [fp, #-8]
    // 0xadf17c: r0 = Velocity()
    //     0xadf17c: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xadf180: ldur            x1, [fp, #-8]
    // 0xadf184: StoreField: r0->field_7 = r1
    //     0xadf184: stur            w1, [x0, #7]
    // 0xadf188: LeaveFrame
    //     0xadf188: mov             SP, fp
    //     0xadf18c: ldp             fp, lr, [SP], #0x10
    // 0xadf190: ret
    //     0xadf190: ret             
    // 0xadf194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf198: b               #0xadf12c
  }
  _ getVelocityEstimate(/* No info */) {
    // ** addr: 0x12fd6dc, size: 0x7a8
    // 0x12fd6dc: EnterFrame
    //     0x12fd6dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd6e0: mov             fp, SP
    // 0x12fd6e4: AllocStack(0x98)
    //     0x12fd6e4: sub             SP, SP, #0x98
    // 0x12fd6e8: SetupParameters(VelocityTracker this /* r1 => r0, fp-0x8 */)
    //     0x12fd6e8: mov             x0, x1
    //     0x12fd6ec: stur            x1, [fp, #-8]
    // 0x12fd6f0: CheckStackOverflow
    //     0x12fd6f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd6f4: cmp             SP, x16
    //     0x12fd6f8: b.ls            #0x12fdde4
    // 0x12fd6fc: mov             x1, x0
    // 0x12fd700: r0 = _sinceLastSample()
    //     0x12fd700: bl              #0x12fed50  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::_sinceLastSample
    // 0x12fd704: mov             x1, x0
    // 0x12fd708: r0 = elapsedMilliseconds()
    //     0x12fd708: bl              #0x10065c8  ; [dart:core] Stopwatch::elapsedMilliseconds
    // 0x12fd70c: cmp             x0, #0x28
    // 0x12fd710: b.le            #0x12fd728
    // 0x12fd714: r0 = Instance_VelocityEstimate
    //     0x12fd714: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8cc38] Obj!VelocityEstimate@129f121
    //     0x12fd718: ldr             x0, [x0, #0xc38]
    // 0x12fd71c: LeaveFrame
    //     0x12fd71c: mov             SP, fp
    //     0x12fd720: ldp             fp, lr, [SP], #0x10
    // 0x12fd724: ret
    //     0x12fd724: ret             
    // 0x12fd728: ldur            x0, [fp, #-8]
    // 0x12fd72c: r1 = <double>
    //     0x12fd72c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12fd730: r2 = 0
    //     0x12fd730: mov             x2, #0
    // 0x12fd734: r0 = _GrowableList()
    //     0x12fd734: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12fd738: r1 = <double>
    //     0x12fd738: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12fd73c: r2 = 0
    //     0x12fd73c: mov             x2, #0
    // 0x12fd740: stur            x0, [fp, #-0x10]
    // 0x12fd744: r0 = _GrowableList()
    //     0x12fd744: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12fd748: r1 = <double>
    //     0x12fd748: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12fd74c: r2 = 0
    //     0x12fd74c: mov             x2, #0
    // 0x12fd750: stur            x0, [fp, #-0x18]
    // 0x12fd754: r0 = _GrowableList()
    //     0x12fd754: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12fd758: r1 = <double>
    //     0x12fd758: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12fd75c: r2 = 0
    //     0x12fd75c: mov             x2, #0
    // 0x12fd760: stur            x0, [fp, #-0x20]
    // 0x12fd764: r0 = _GrowableList()
    //     0x12fd764: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x12fd768: mov             x2, x0
    // 0x12fd76c: ldur            x0, [fp, #-8]
    // 0x12fd770: stur            x2, [fp, #-0x78]
    // 0x12fd774: LoadField: r3 = r0->field_13
    //     0x12fd774: ldur            x3, [x0, #0x13]
    // 0x12fd778: LoadField: r4 = r0->field_f
    //     0x12fd778: ldur            w4, [x0, #0xf]
    // 0x12fd77c: DecompressPointer r4
    //     0x12fd77c: add             x4, x4, HEAP, lsl #32
    // 0x12fd780: stur            x4, [fp, #-0x70]
    // 0x12fd784: LoadField: r0 = r4->field_b
    //     0x12fd784: ldur            w0, [x4, #0xb]
    // 0x12fd788: r5 = LoadInt32Instr(r0)
    //     0x12fd788: sbfx            x5, x0, #1, #0x1f
    // 0x12fd78c: mov             x0, x5
    // 0x12fd790: mov             x1, x3
    // 0x12fd794: stur            x5, [fp, #-0x68]
    // 0x12fd798: cmp             x1, x0
    // 0x12fd79c: b.hs            #0x12fddec
    // 0x12fd7a0: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0x12fd7a0: add             x16, x4, x3, lsl #2
    //     0x12fd7a4: ldur            w6, [x16, #0xf]
    // 0x12fd7a8: DecompressPointer r6
    //     0x12fd7a8: add             x6, x6, HEAP, lsl #32
    // 0x12fd7ac: stur            x6, [fp, #-0x60]
    // 0x12fd7b0: cmp             w6, NULL
    // 0x12fd7b4: b.ne            #0x12fd7c8
    // 0x12fd7b8: r0 = Null
    //     0x12fd7b8: mov             x0, NULL
    // 0x12fd7bc: LeaveFrame
    //     0x12fd7bc: mov             SP, fp
    //     0x12fd7c0: ldp             fp, lr, [SP], #0x10
    // 0x12fd7c4: ret
    //     0x12fd7c4: ret             
    // 0x12fd7c8: LoadField: r0 = r6->field_7
    //     0x12fd7c8: ldur            w0, [x6, #7]
    // 0x12fd7cc: DecompressPointer r0
    //     0x12fd7cc: add             x0, x0, HEAP, lsl #32
    // 0x12fd7d0: LoadField: r7 = r0->field_7
    //     0x12fd7d0: ldur            x7, [x0, #7]
    // 0x12fd7d4: stur            x7, [fp, #-0x58]
    // 0x12fd7d8: mov             x12, x3
    // 0x12fd7dc: mov             x11, x6
    // 0x12fd7e0: mov             x10, x0
    // 0x12fd7e4: r13 = 0
    //     0x12fd7e4: mov             x13, #0
    // 0x12fd7e8: ldur            x9, [fp, #-0x10]
    // 0x12fd7ec: ldur            x8, [fp, #-0x18]
    // 0x12fd7f0: ldur            x3, [fp, #-0x20]
    // 0x12fd7f4: stur            x13, [fp, #-0x38]
    // 0x12fd7f8: stur            x12, [fp, #-0x40]
    // 0x12fd7fc: stur            x11, [fp, #-0x48]
    // 0x12fd800: stur            x10, [fp, #-0x50]
    // 0x12fd804: CheckStackOverflow
    //     0x12fd804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd808: cmp             SP, x16
    //     0x12fd80c: b.ls            #0x12fddf0
    // 0x12fd810: mov             x0, x5
    // 0x12fd814: mov             x1, x12
    // 0x12fd818: cmp             x1, x0
    // 0x12fd81c: b.hs            #0x12fddf8
    // 0x12fd820: ArrayLoad: r14 = r4[r12]  ; Unknown_4
    //     0x12fd820: add             x16, x4, x12, lsl #2
    //     0x12fd824: ldur            w14, [x16, #0xf]
    // 0x12fd828: DecompressPointer r14
    //     0x12fd828: add             x14, x14, HEAP, lsl #32
    // 0x12fd82c: stur            x14, [fp, #-0x30]
    // 0x12fd830: cmp             w14, NULL
    // 0x12fd834: b.eq            #0x12fdbd0
    // 0x12fd838: LoadField: r19 = r14->field_7
    //     0x12fd838: ldur            w19, [x14, #7]
    // 0x12fd83c: DecompressPointer r19
    //     0x12fd83c: add             x19, x19, HEAP, lsl #32
    // 0x12fd840: stur            x19, [fp, #-8]
    // 0x12fd844: LoadField: r20 = r19->field_7
    //     0x12fd844: ldur            x20, [x19, #7]
    // 0x12fd848: stur            x20, [fp, #-0x28]
    // 0x12fd84c: sub             x23, x7, x20
    // 0x12fd850: r0 = BoxInt64Instr(r23)
    //     0x12fd850: sbfiz           x0, x23, #1, #0x1f
    //     0x12fd854: cmp             x23, x0, asr #1
    //     0x12fd858: b.eq            #0x12fd864
    //     0x12fd85c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12fd860: stur            x23, [x0, #7]
    // 0x12fd864: stp             x0, NULL, [SP]
    // 0x12fd868: r0 = _Double.fromInteger()
    //     0x12fd868: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x12fd86c: LoadField: d0 = r0->field_7
    //     0x12fd86c: ldur            d0, [x0, #7]
    // 0x12fd870: d1 = 1000.000000
    //     0x12fd870: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0x12fd874: ldr             d1, [x17, #0xa58]
    // 0x12fd878: fdiv            d2, d0, d1
    // 0x12fd87c: ldur            x0, [fp, #-0x50]
    // 0x12fd880: stur            d2, [fp, #-0x80]
    // 0x12fd884: LoadField: r1 = r0->field_7
    //     0x12fd884: ldur            x1, [x0, #7]
    // 0x12fd888: ldur            x0, [fp, #-0x28]
    // 0x12fd88c: sub             x2, x0, x1
    // 0x12fd890: tbz             x2, #0x3f, #0x12fd89c
    // 0x12fd894: neg             x0, x2
    // 0x12fd898: mov             x2, x0
    // 0x12fd89c: r0 = BoxInt64Instr(r2)
    //     0x12fd89c: sbfiz           x0, x2, #1, #0x1f
    //     0x12fd8a0: cmp             x2, x0, asr #1
    //     0x12fd8a4: b.eq            #0x12fd8b0
    //     0x12fd8a8: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x12fd8ac: stur            x2, [x0, #7]
    // 0x12fd8b0: stp             x0, NULL, [SP]
    // 0x12fd8b4: r0 = _Double.fromInteger()
    //     0x12fd8b4: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x12fd8b8: LoadField: d0 = r0->field_7
    //     0x12fd8b8: ldur            d0, [x0, #7]
    // 0x12fd8bc: d1 = 1000.000000
    //     0x12fd8bc: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0x12fd8c0: ldr             d1, [x17, #0xa58]
    // 0x12fd8c4: fdiv            d2, d0, d1
    // 0x12fd8c8: ldur            d0, [fp, #-0x80]
    // 0x12fd8cc: d3 = 100.000000
    //     0x12fd8cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0x12fd8d0: ldr             d3, [x17, #0xa8]
    // 0x12fd8d4: fcmp            d0, d3
    // 0x12fd8d8: b.gt            #0x12fdbbc
    // 0x12fd8dc: d4 = 40.000000
    //     0x12fd8dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0x12fd8e0: ldr             d4, [x17, #0x168]
    // 0x12fd8e4: fcmp            d2, d4
    // 0x12fd8e8: b.gt            #0x12fdbb0
    // 0x12fd8ec: ldur            x0, [fp, #-0x10]
    // 0x12fd8f0: ldur            x11, [fp, #-0x30]
    // 0x12fd8f4: LoadField: r2 = r11->field_b
    //     0x12fd8f4: ldur            w2, [x11, #0xb]
    // 0x12fd8f8: DecompressPointer r2
    //     0x12fd8f8: add             x2, x2, HEAP, lsl #32
    // 0x12fd8fc: stur            x2, [fp, #-0x50]
    // 0x12fd900: LoadField: d2 = r2->field_7
    //     0x12fd900: ldur            d2, [x2, #7]
    // 0x12fd904: stur            d2, [fp, #-0x88]
    // 0x12fd908: LoadField: r1 = r0->field_b
    //     0x12fd908: ldur            w1, [x0, #0xb]
    // 0x12fd90c: LoadField: r3 = r0->field_f
    //     0x12fd90c: ldur            w3, [x0, #0xf]
    // 0x12fd910: DecompressPointer r3
    //     0x12fd910: add             x3, x3, HEAP, lsl #32
    // 0x12fd914: LoadField: r4 = r3->field_b
    //     0x12fd914: ldur            w4, [x3, #0xb]
    // 0x12fd918: r3 = LoadInt32Instr(r1)
    //     0x12fd918: sbfx            x3, x1, #1, #0x1f
    // 0x12fd91c: stur            x3, [fp, #-0x28]
    // 0x12fd920: r1 = LoadInt32Instr(r4)
    //     0x12fd920: sbfx            x1, x4, #1, #0x1f
    // 0x12fd924: cmp             x3, x1
    // 0x12fd928: b.ne            #0x12fd934
    // 0x12fd92c: mov             x1, x0
    // 0x12fd930: r0 = _growToNextCapacity()
    //     0x12fd930: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12fd934: ldur            x2, [fp, #-0x10]
    // 0x12fd938: ldur            x5, [fp, #-0x18]
    // 0x12fd93c: ldur            x3, [fp, #-0x50]
    // 0x12fd940: ldur            d0, [fp, #-0x88]
    // 0x12fd944: ldur            x4, [fp, #-0x28]
    // 0x12fd948: add             x0, x4, #1
    // 0x12fd94c: lsl             x1, x0, #1
    // 0x12fd950: StoreField: r2->field_b = r1
    //     0x12fd950: stur            w1, [x2, #0xb]
    // 0x12fd954: LoadField: r1 = r2->field_f
    //     0x12fd954: ldur            w1, [x2, #0xf]
    // 0x12fd958: DecompressPointer r1
    //     0x12fd958: add             x1, x1, HEAP, lsl #32
    // 0x12fd95c: r0 = inline_Allocate_Double()
    //     0x12fd95c: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0x12fd960: add             x0, x0, #0x10
    //     0x12fd964: cmp             x6, x0
    //     0x12fd968: b.ls            #0x12fddfc
    //     0x12fd96c: str             x0, [THR, #0x60]  ; THR::top
    //     0x12fd970: sub             x0, x0, #0xf
    //     0x12fd974: mov             x6, #0xe19c
    //     0x12fd978: movk            x6, #3, lsl #16
    //     0x12fd97c: stur            x6, [x0, #-1]
    // 0x12fd980: dmb             ishst
    // 0x12fd984: StoreField: r0->field_7 = d0
    //     0x12fd984: stur            d0, [x0, #7]
    // 0x12fd988: ArrayStore: r1[r4] = r0  ; List_4
    //     0x12fd988: add             x25, x1, x4, lsl #2
    //     0x12fd98c: add             x25, x25, #0xf
    //     0x12fd990: str             w0, [x25]
    //     0x12fd994: tbz             w0, #0, #0x12fd9b0
    //     0x12fd998: ldurb           w16, [x1, #-1]
    //     0x12fd99c: ldurb           w17, [x0, #-1]
    //     0x12fd9a0: and             x16, x17, x16, lsr #2
    //     0x12fd9a4: tst             x16, HEAP, lsr #32
    //     0x12fd9a8: b.eq            #0x12fd9b0
    //     0x12fd9ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fd9b0: LoadField: d0 = r3->field_f
    //     0x12fd9b0: ldur            d0, [x3, #0xf]
    // 0x12fd9b4: stur            d0, [fp, #-0x88]
    // 0x12fd9b8: LoadField: r0 = r5->field_b
    //     0x12fd9b8: ldur            w0, [x5, #0xb]
    // 0x12fd9bc: LoadField: r1 = r5->field_f
    //     0x12fd9bc: ldur            w1, [x5, #0xf]
    // 0x12fd9c0: DecompressPointer r1
    //     0x12fd9c0: add             x1, x1, HEAP, lsl #32
    // 0x12fd9c4: LoadField: r3 = r1->field_b
    //     0x12fd9c4: ldur            w3, [x1, #0xb]
    // 0x12fd9c8: r4 = LoadInt32Instr(r0)
    //     0x12fd9c8: sbfx            x4, x0, #1, #0x1f
    // 0x12fd9cc: stur            x4, [fp, #-0x28]
    // 0x12fd9d0: r0 = LoadInt32Instr(r3)
    //     0x12fd9d0: sbfx            x0, x3, #1, #0x1f
    // 0x12fd9d4: cmp             x4, x0
    // 0x12fd9d8: b.ne            #0x12fd9e4
    // 0x12fd9dc: mov             x1, x5
    // 0x12fd9e0: r0 = _growToNextCapacity()
    //     0x12fd9e0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12fd9e4: ldur            x2, [fp, #-0x18]
    // 0x12fd9e8: ldur            x4, [fp, #-0x20]
    // 0x12fd9ec: ldur            d0, [fp, #-0x88]
    // 0x12fd9f0: ldur            x3, [fp, #-0x28]
    // 0x12fd9f4: add             x0, x3, #1
    // 0x12fd9f8: lsl             x1, x0, #1
    // 0x12fd9fc: StoreField: r2->field_b = r1
    //     0x12fd9fc: stur            w1, [x2, #0xb]
    // 0x12fda00: LoadField: r1 = r2->field_f
    //     0x12fda00: ldur            w1, [x2, #0xf]
    // 0x12fda04: DecompressPointer r1
    //     0x12fda04: add             x1, x1, HEAP, lsl #32
    // 0x12fda08: r0 = inline_Allocate_Double()
    //     0x12fda08: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x12fda0c: add             x0, x0, #0x10
    //     0x12fda10: cmp             x5, x0
    //     0x12fda14: b.ls            #0x12fde24
    //     0x12fda18: str             x0, [THR, #0x60]  ; THR::top
    //     0x12fda1c: sub             x0, x0, #0xf
    //     0x12fda20: mov             x5, #0xe19c
    //     0x12fda24: movk            x5, #3, lsl #16
    //     0x12fda28: stur            x5, [x0, #-1]
    // 0x12fda2c: dmb             ishst
    // 0x12fda30: StoreField: r0->field_7 = d0
    //     0x12fda30: stur            d0, [x0, #7]
    // 0x12fda34: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fda34: add             x25, x1, x3, lsl #2
    //     0x12fda38: add             x25, x25, #0xf
    //     0x12fda3c: str             w0, [x25]
    //     0x12fda40: tbz             w0, #0, #0x12fda5c
    //     0x12fda44: ldurb           w16, [x1, #-1]
    //     0x12fda48: ldurb           w17, [x0, #-1]
    //     0x12fda4c: and             x16, x17, x16, lsr #2
    //     0x12fda50: tst             x16, HEAP, lsr #32
    //     0x12fda54: b.eq            #0x12fda5c
    //     0x12fda58: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fda5c: LoadField: r0 = r4->field_b
    //     0x12fda5c: ldur            w0, [x4, #0xb]
    // 0x12fda60: LoadField: r1 = r4->field_f
    //     0x12fda60: ldur            w1, [x4, #0xf]
    // 0x12fda64: DecompressPointer r1
    //     0x12fda64: add             x1, x1, HEAP, lsl #32
    // 0x12fda68: LoadField: r3 = r1->field_b
    //     0x12fda68: ldur            w3, [x1, #0xb]
    // 0x12fda6c: r5 = LoadInt32Instr(r0)
    //     0x12fda6c: sbfx            x5, x0, #1, #0x1f
    // 0x12fda70: stur            x5, [fp, #-0x28]
    // 0x12fda74: r0 = LoadInt32Instr(r3)
    //     0x12fda74: sbfx            x0, x3, #1, #0x1f
    // 0x12fda78: cmp             x5, x0
    // 0x12fda7c: b.ne            #0x12fda88
    // 0x12fda80: mov             x1, x4
    // 0x12fda84: r0 = _growToNextCapacity()
    //     0x12fda84: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12fda88: ldur            x0, [fp, #-0x20]
    // 0x12fda8c: ldur            x2, [fp, #-0x78]
    // 0x12fda90: ldur            d0, [fp, #-0x80]
    // 0x12fda94: ldur            x1, [fp, #-0x28]
    // 0x12fda98: add             x3, x1, #1
    // 0x12fda9c: lsl             x4, x3, #1
    // 0x12fdaa0: StoreField: r0->field_b = r4
    //     0x12fdaa0: stur            w4, [x0, #0xb]
    // 0x12fdaa4: LoadField: r3 = r0->field_f
    //     0x12fdaa4: ldur            w3, [x0, #0xf]
    // 0x12fdaa8: DecompressPointer r3
    //     0x12fdaa8: add             x3, x3, HEAP, lsl #32
    // 0x12fdaac: add             x4, x3, x1, lsl #2
    // 0x12fdab0: r16 = 1.000000
    //     0x12fdab0: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12fdab4: StoreField: r4->field_f = r16
    //     0x12fdab4: stur            w16, [x4, #0xf]
    // 0x12fdab8: fneg            d1, d0
    // 0x12fdabc: stur            d1, [fp, #-0x88]
    // 0x12fdac0: LoadField: r1 = r2->field_b
    //     0x12fdac0: ldur            w1, [x2, #0xb]
    // 0x12fdac4: LoadField: r3 = r2->field_f
    //     0x12fdac4: ldur            w3, [x2, #0xf]
    // 0x12fdac8: DecompressPointer r3
    //     0x12fdac8: add             x3, x3, HEAP, lsl #32
    // 0x12fdacc: LoadField: r4 = r3->field_b
    //     0x12fdacc: ldur            w4, [x3, #0xb]
    // 0x12fdad0: r3 = LoadInt32Instr(r1)
    //     0x12fdad0: sbfx            x3, x1, #1, #0x1f
    // 0x12fdad4: stur            x3, [fp, #-0x28]
    // 0x12fdad8: r1 = LoadInt32Instr(r4)
    //     0x12fdad8: sbfx            x1, x4, #1, #0x1f
    // 0x12fdadc: cmp             x3, x1
    // 0x12fdae0: b.ne            #0x12fdaec
    // 0x12fdae4: mov             x1, x2
    // 0x12fdae8: r0 = _growToNextCapacity()
    //     0x12fdae8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12fdaec: ldur            x2, [fp, #-0x78]
    // 0x12fdaf0: ldur            x4, [fp, #-0x40]
    // 0x12fdaf4: ldur            d0, [fp, #-0x88]
    // 0x12fdaf8: ldur            x3, [fp, #-0x28]
    // 0x12fdafc: add             x0, x3, #1
    // 0x12fdb00: lsl             x1, x0, #1
    // 0x12fdb04: StoreField: r2->field_b = r1
    //     0x12fdb04: stur            w1, [x2, #0xb]
    // 0x12fdb08: LoadField: r1 = r2->field_f
    //     0x12fdb08: ldur            w1, [x2, #0xf]
    // 0x12fdb0c: DecompressPointer r1
    //     0x12fdb0c: add             x1, x1, HEAP, lsl #32
    // 0x12fdb10: r0 = inline_Allocate_Double()
    //     0x12fdb10: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x12fdb14: add             x0, x0, #0x10
    //     0x12fdb18: cmp             x5, x0
    //     0x12fdb1c: b.ls            #0x12fde44
    //     0x12fdb20: str             x0, [THR, #0x60]  ; THR::top
    //     0x12fdb24: sub             x0, x0, #0xf
    //     0x12fdb28: mov             x5, #0xe19c
    //     0x12fdb2c: movk            x5, #3, lsl #16
    //     0x12fdb30: stur            x5, [x0, #-1]
    // 0x12fdb34: dmb             ishst
    // 0x12fdb38: StoreField: r0->field_7 = d0
    //     0x12fdb38: stur            d0, [x0, #7]
    // 0x12fdb3c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fdb3c: add             x25, x1, x3, lsl #2
    //     0x12fdb40: add             x25, x25, #0xf
    //     0x12fdb44: str             w0, [x25]
    //     0x12fdb48: tbz             w0, #0, #0x12fdb64
    //     0x12fdb4c: ldurb           w16, [x1, #-1]
    //     0x12fdb50: ldurb           w17, [x0, #-1]
    //     0x12fdb54: and             x16, x17, x16, lsr #2
    //     0x12fdb58: tst             x16, HEAP, lsr #32
    //     0x12fdb5c: b.eq            #0x12fdb64
    //     0x12fdb60: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fdb64: cbnz            x4, #0x12fdb70
    // 0x12fdb68: r1 = 20
    //     0x12fdb68: mov             x1, #0x14
    // 0x12fdb6c: b               #0x12fdb74
    // 0x12fdb70: mov             x1, x4
    // 0x12fdb74: ldur            x0, [fp, #-0x38]
    // 0x12fdb78: sub             x12, x1, #1
    // 0x12fdb7c: add             x13, x0, #1
    // 0x12fdb80: cmp             x13, #0x14
    // 0x12fdb84: b.ge            #0x12fdba4
    // 0x12fdb88: ldur            x11, [fp, #-0x30]
    // 0x12fdb8c: ldur            x10, [fp, #-8]
    // 0x12fdb90: ldur            x4, [fp, #-0x70]
    // 0x12fdb94: ldur            x7, [fp, #-0x58]
    // 0x12fdb98: ldur            x5, [fp, #-0x68]
    // 0x12fdb9c: ldur            x6, [fp, #-0x60]
    // 0x12fdba0: b               #0x12fd7e8
    // 0x12fdba4: mov             x1, x13
    // 0x12fdba8: ldur            x0, [fp, #-0x30]
    // 0x12fdbac: b               #0x12fdbdc
    // 0x12fdbb0: ldur            x2, [fp, #-0x78]
    // 0x12fdbb4: ldur            x0, [fp, #-0x38]
    // 0x12fdbb8: b               #0x12fdbc4
    // 0x12fdbbc: ldur            x2, [fp, #-0x78]
    // 0x12fdbc0: ldur            x0, [fp, #-0x38]
    // 0x12fdbc4: mov             x1, x0
    // 0x12fdbc8: ldur            x0, [fp, #-0x48]
    // 0x12fdbcc: b               #0x12fdbdc
    // 0x12fdbd0: mov             x0, x13
    // 0x12fdbd4: mov             x1, x0
    // 0x12fdbd8: ldur            x0, [fp, #-0x48]
    // 0x12fdbdc: stur            x0, [fp, #-8]
    // 0x12fdbe0: cmp             x1, #3
    // 0x12fdbe4: b.lt            #0x12fdd98
    // 0x12fdbe8: ldur            x3, [fp, #-0x10]
    // 0x12fdbec: ldur            x1, [fp, #-0x20]
    // 0x12fdbf0: r0 = LeastSquaresSolver()
    //     0x12fdbf0: bl              #0x12fed44  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0x12fdbf4: mov             x1, x0
    // 0x12fdbf8: ldur            x0, [fp, #-0x78]
    // 0x12fdbfc: StoreField: r1->field_7 = r0
    //     0x12fdbfc: stur            w0, [x1, #7]
    // 0x12fdc00: ldur            x2, [fp, #-0x10]
    // 0x12fdc04: StoreField: r1->field_b = r2
    //     0x12fdc04: stur            w2, [x1, #0xb]
    // 0x12fdc08: ldur            x2, [fp, #-0x20]
    // 0x12fdc0c: StoreField: r1->field_f = r2
    //     0x12fdc0c: stur            w2, [x1, #0xf]
    // 0x12fdc10: r0 = solve()
    //     0x12fdc10: bl              #0x12fde90  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0x12fdc14: stur            x0, [fp, #-0x10]
    // 0x12fdc18: cmp             w0, NULL
    // 0x12fdc1c: b.eq            #0x12fdd8c
    // 0x12fdc20: ldur            x3, [fp, #-0x18]
    // 0x12fdc24: ldur            x2, [fp, #-0x20]
    // 0x12fdc28: ldur            x1, [fp, #-0x78]
    // 0x12fdc2c: r0 = LeastSquaresSolver()
    //     0x12fdc2c: bl              #0x12fed44  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0x12fdc30: mov             x1, x0
    // 0x12fdc34: ldur            x0, [fp, #-0x78]
    // 0x12fdc38: StoreField: r1->field_7 = r0
    //     0x12fdc38: stur            w0, [x1, #7]
    // 0x12fdc3c: ldur            x0, [fp, #-0x18]
    // 0x12fdc40: StoreField: r1->field_b = r0
    //     0x12fdc40: stur            w0, [x1, #0xb]
    // 0x12fdc44: ldur            x0, [fp, #-0x20]
    // 0x12fdc48: StoreField: r1->field_f = r0
    //     0x12fdc48: stur            w0, [x1, #0xf]
    // 0x12fdc4c: r0 = solve()
    //     0x12fdc4c: bl              #0x12fde90  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0x12fdc50: mov             x2, x0
    // 0x12fdc54: stur            x2, [fp, #-0x18]
    // 0x12fdc58: cmp             w2, NULL
    // 0x12fdc5c: b.eq            #0x12fdd80
    // 0x12fdc60: ldur            x4, [fp, #-8]
    // 0x12fdc64: ldur            x3, [fp, #-0x10]
    // 0x12fdc68: ldur            x5, [fp, #-0x60]
    // 0x12fdc6c: d0 = 1000.000000
    //     0x12fdc6c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0x12fdc70: ldr             d0, [x17, #0xa58]
    // 0x12fdc74: LoadField: r6 = r3->field_7
    //     0x12fdc74: ldur            w6, [x3, #7]
    // 0x12fdc78: DecompressPointer r6
    //     0x12fdc78: add             x6, x6, HEAP, lsl #32
    // 0x12fdc7c: LoadField: r0 = r6->field_13
    //     0x12fdc7c: ldur            w0, [x6, #0x13]
    // 0x12fdc80: r1 = LoadInt32Instr(r0)
    //     0x12fdc80: sbfx            x1, x0, #1, #0x1f
    // 0x12fdc84: mov             x0, x1
    // 0x12fdc88: r1 = 1
    //     0x12fdc88: mov             x1, #1
    // 0x12fdc8c: cmp             x1, x0
    // 0x12fdc90: b.hs            #0x12fde64
    // 0x12fdc94: LoadField: d1 = r6->field_1f
    //     0x12fdc94: ldur            d1, [x6, #0x1f]
    // 0x12fdc98: fmul            d2, d1, d0
    // 0x12fdc9c: stur            d2, [fp, #-0x88]
    // 0x12fdca0: LoadField: r6 = r2->field_7
    //     0x12fdca0: ldur            w6, [x2, #7]
    // 0x12fdca4: DecompressPointer r6
    //     0x12fdca4: add             x6, x6, HEAP, lsl #32
    // 0x12fdca8: LoadField: r0 = r6->field_13
    //     0x12fdca8: ldur            w0, [x6, #0x13]
    // 0x12fdcac: r1 = LoadInt32Instr(r0)
    //     0x12fdcac: sbfx            x1, x0, #1, #0x1f
    // 0x12fdcb0: mov             x0, x1
    // 0x12fdcb4: r1 = 1
    //     0x12fdcb4: mov             x1, #1
    // 0x12fdcb8: cmp             x1, x0
    // 0x12fdcbc: b.hs            #0x12fde68
    // 0x12fdcc0: LoadField: d1 = r6->field_1f
    //     0x12fdcc0: ldur            d1, [x6, #0x1f]
    // 0x12fdcc4: fmul            d3, d1, d0
    // 0x12fdcc8: stur            d3, [fp, #-0x80]
    // 0x12fdccc: r0 = Offset()
    //     0x12fdccc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12fdcd0: ldur            d0, [fp, #-0x88]
    // 0x12fdcd4: stur            x0, [fp, #-0x20]
    // 0x12fdcd8: StoreField: r0->field_7 = d0
    //     0x12fdcd8: stur            d0, [x0, #7]
    // 0x12fdcdc: ldur            d0, [fp, #-0x80]
    // 0x12fdce0: StoreField: r0->field_f = d0
    //     0x12fdce0: stur            d0, [x0, #0xf]
    // 0x12fdce4: ldur            x1, [fp, #-0x10]
    // 0x12fdce8: LoadField: r2 = r1->field_b
    //     0x12fdce8: ldur            w2, [x1, #0xb]
    // 0x12fdcec: DecompressPointer r2
    //     0x12fdcec: add             x2, x2, HEAP, lsl #32
    // 0x12fdcf0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fdcf4: cmp             w2, w16
    // 0x12fdcf8: b.eq            #0x12fde6c
    // 0x12fdcfc: ldur            x1, [fp, #-0x18]
    // 0x12fdd00: LoadField: r3 = r1->field_b
    //     0x12fdd00: ldur            w3, [x1, #0xb]
    // 0x12fdd04: DecompressPointer r3
    //     0x12fdd04: add             x3, x3, HEAP, lsl #32
    // 0x12fdd08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fdd0c: cmp             w3, w16
    // 0x12fdd10: b.eq            #0x12fde78
    // 0x12fdd14: LoadField: d0 = r2->field_7
    //     0x12fdd14: ldur            d0, [x2, #7]
    // 0x12fdd18: LoadField: d1 = r3->field_7
    //     0x12fdd18: ldur            d1, [x3, #7]
    // 0x12fdd1c: fmul            d2, d0, d1
    // 0x12fdd20: ldur            x1, [fp, #-0x60]
    // 0x12fdd24: stur            d2, [fp, #-0x80]
    // 0x12fdd28: LoadField: r2 = r1->field_b
    //     0x12fdd28: ldur            w2, [x1, #0xb]
    // 0x12fdd2c: DecompressPointer r2
    //     0x12fdd2c: add             x2, x2, HEAP, lsl #32
    // 0x12fdd30: ldur            x3, [fp, #-8]
    // 0x12fdd34: LoadField: r1 = r3->field_b
    //     0x12fdd34: ldur            w1, [x3, #0xb]
    // 0x12fdd38: DecompressPointer r1
    //     0x12fdd38: add             x1, x1, HEAP, lsl #32
    // 0x12fdd3c: mov             x16, x1
    // 0x12fdd40: mov             x1, x2
    // 0x12fdd44: mov             x2, x16
    // 0x12fdd48: r0 = -()
    //     0x12fdd48: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12fdd4c: stur            x0, [fp, #-0x10]
    // 0x12fdd50: r0 = VelocityEstimate()
    //     0x12fdd50: bl              #0x12fde84  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x18)
    // 0x12fdd54: mov             x1, x0
    // 0x12fdd58: ldur            x0, [fp, #-0x20]
    // 0x12fdd5c: StoreField: r1->field_7 = r0
    //     0x12fdd5c: stur            w0, [x1, #7]
    // 0x12fdd60: ldur            d0, [fp, #-0x80]
    // 0x12fdd64: StoreField: r1->field_b = d0
    //     0x12fdd64: stur            d0, [x1, #0xb]
    // 0x12fdd68: ldur            x0, [fp, #-0x10]
    // 0x12fdd6c: StoreField: r1->field_13 = r0
    //     0x12fdd6c: stur            w0, [x1, #0x13]
    // 0x12fdd70: mov             x0, x1
    // 0x12fdd74: LeaveFrame
    //     0x12fdd74: mov             SP, fp
    //     0x12fdd78: ldp             fp, lr, [SP], #0x10
    // 0x12fdd7c: ret
    //     0x12fdd7c: ret             
    // 0x12fdd80: ldur            x3, [fp, #-8]
    // 0x12fdd84: ldur            x1, [fp, #-0x60]
    // 0x12fdd88: b               #0x12fdda0
    // 0x12fdd8c: ldur            x3, [fp, #-8]
    // 0x12fdd90: ldur            x1, [fp, #-0x60]
    // 0x12fdd94: b               #0x12fdda0
    // 0x12fdd98: mov             x3, x0
    // 0x12fdd9c: ldur            x1, [fp, #-0x60]
    // 0x12fdda0: LoadField: r0 = r1->field_b
    //     0x12fdda0: ldur            w0, [x1, #0xb]
    // 0x12fdda4: DecompressPointer r0
    //     0x12fdda4: add             x0, x0, HEAP, lsl #32
    // 0x12fdda8: LoadField: r2 = r3->field_b
    //     0x12fdda8: ldur            w2, [x3, #0xb]
    // 0x12fddac: DecompressPointer r2
    //     0x12fddac: add             x2, x2, HEAP, lsl #32
    // 0x12fddb0: mov             x1, x0
    // 0x12fddb4: r0 = -()
    //     0x12fddb4: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12fddb8: stur            x0, [fp, #-8]
    // 0x12fddbc: r0 = VelocityEstimate()
    //     0x12fddbc: bl              #0x12fde84  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x18)
    // 0x12fddc0: r1 = Instance_Offset
    //     0x12fddc0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12fddc4: StoreField: r0->field_7 = r1
    //     0x12fddc4: stur            w1, [x0, #7]
    // 0x12fddc8: d0 = 1.000000
    //     0x12fddc8: fmov            d0, #1.00000000
    // 0x12fddcc: StoreField: r0->field_b = d0
    //     0x12fddcc: stur            d0, [x0, #0xb]
    // 0x12fddd0: ldur            x1, [fp, #-8]
    // 0x12fddd4: StoreField: r0->field_13 = r1
    //     0x12fddd4: stur            w1, [x0, #0x13]
    // 0x12fddd8: LeaveFrame
    //     0x12fddd8: mov             SP, fp
    //     0x12fdddc: ldp             fp, lr, [SP], #0x10
    // 0x12fdde0: ret
    //     0x12fdde0: ret             
    // 0x12fdde4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fdde4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fdde8: b               #0x12fd6fc
    // 0x12fddec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fddec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fddf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fddf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fddf4: b               #0x12fd810
    // 0x12fddf8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fddf8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fddfc: SaveReg d0
    //     0x12fddfc: str             q0, [SP, #-0x10]!
    // 0x12fde00: stp             x4, x5, [SP, #-0x10]!
    // 0x12fde04: stp             x2, x3, [SP, #-0x10]!
    // 0x12fde08: SaveReg r1
    //     0x12fde08: str             x1, [SP, #-8]!
    // 0x12fde0c: r0 = AllocateDouble()
    //     0x12fde0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fde10: RestoreReg r1
    //     0x12fde10: ldr             x1, [SP], #8
    // 0x12fde14: ldp             x2, x3, [SP], #0x10
    // 0x12fde18: ldp             x4, x5, [SP], #0x10
    // 0x12fde1c: RestoreReg d0
    //     0x12fde1c: ldr             q0, [SP], #0x10
    // 0x12fde20: b               #0x12fd984
    // 0x12fde24: SaveReg d0
    //     0x12fde24: str             q0, [SP, #-0x10]!
    // 0x12fde28: stp             x3, x4, [SP, #-0x10]!
    // 0x12fde2c: stp             x1, x2, [SP, #-0x10]!
    // 0x12fde30: r0 = AllocateDouble()
    //     0x12fde30: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fde34: ldp             x1, x2, [SP], #0x10
    // 0x12fde38: ldp             x3, x4, [SP], #0x10
    // 0x12fde3c: RestoreReg d0
    //     0x12fde3c: ldr             q0, [SP], #0x10
    // 0x12fde40: b               #0x12fda30
    // 0x12fde44: SaveReg d0
    //     0x12fde44: str             q0, [SP, #-0x10]!
    // 0x12fde48: stp             x3, x4, [SP, #-0x10]!
    // 0x12fde4c: stp             x1, x2, [SP, #-0x10]!
    // 0x12fde50: r0 = AllocateDouble()
    //     0x12fde50: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fde54: ldp             x1, x2, [SP], #0x10
    // 0x12fde58: ldp             x3, x4, [SP], #0x10
    // 0x12fde5c: RestoreReg d0
    //     0x12fde5c: ldr             q0, [SP], #0x10
    // 0x12fde60: b               #0x12fdb38
    // 0x12fde64: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fde64: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fde68: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fde68: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fde6c: r9 = confidence
    //     0x12fde6c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc40] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0x12fde70: ldr             x9, [x9, #0xc40]
    // 0x12fde74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12fde74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12fde78: r9 = confidence
    //     0x12fde78: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8cc40] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0x12fde7c: ldr             x9, [x9, #0xc40]
    // 0x12fde80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12fde80: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _sinceLastSample(/* No info */) {
    // ** addr: 0x12fed50, size: 0x94
    // 0x12fed50: EnterFrame
    //     0x12fed50: stp             fp, lr, [SP, #-0x10]!
    //     0x12fed54: mov             fp, SP
    // 0x12fed58: AllocStack(0x8)
    //     0x12fed58: sub             SP, SP, #8
    // 0x12fed5c: SetupParameters(VelocityTracker this /* r1 => r0, fp-0x8 */)
    //     0x12fed5c: mov             x0, x1
    //     0x12fed60: stur            x1, [fp, #-8]
    // 0x12fed64: CheckStackOverflow
    //     0x12fed64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fed68: cmp             SP, x16
    //     0x12fed6c: b.ls            #0x12fedd8
    // 0x12fed70: LoadField: r1 = r0->field_b
    //     0x12fed70: ldur            w1, [x0, #0xb]
    // 0x12fed74: DecompressPointer r1
    //     0x12fed74: add             x1, x1, HEAP, lsl #32
    // 0x12fed78: cmp             w1, NULL
    // 0x12fed7c: b.ne            #0x12fedc8
    // 0x12fed80: r1 = LoadStaticField(0x7d0)
    //     0x12fed80: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x12fed84: ldr             x1, [x1, #0xfa0]
    // 0x12fed88: cmp             w1, NULL
    // 0x12fed8c: b.eq            #0x12fede0
    // 0x12fed90: r0 = samplingClock()
    //     0x12fed90: bl              #0x12fede4  ; [dart:mixin_deduplication] _MixinApplication202&BindingBase&GestureBinding::samplingClock
    // 0x12fed94: mov             x1, x0
    // 0x12fed98: r0 = stopwatch()
    //     0x12fed98: bl              #0x82ae34  ; [package:flutter/src/gestures/binding.dart] SamplingClock::stopwatch
    // 0x12fed9c: mov             x1, x0
    // 0x12feda0: ldur            x2, [fp, #-8]
    // 0x12feda4: StoreField: r2->field_b = r0
    //     0x12feda4: stur            w0, [x2, #0xb]
    //     0x12feda8: ldurb           w16, [x2, #-1]
    //     0x12fedac: ldurb           w17, [x0, #-1]
    //     0x12fedb0: and             x16, x17, x16, lsr #2
    //     0x12fedb4: tst             x16, HEAP, lsr #32
    //     0x12fedb8: b.eq            #0x12fedc0
    //     0x12fedbc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12fedc0: mov             x0, x1
    // 0x12fedc4: b               #0x12fedcc
    // 0x12fedc8: mov             x0, x1
    // 0x12fedcc: LeaveFrame
    //     0x12fedcc: mov             SP, fp
    //     0x12fedd0: ldp             fp, lr, [SP], #0x10
    // 0x12fedd4: ret
    //     0x12fedd4: ret             
    // 0x12fedd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fedd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12feddc: b               #0x12fed70
    // 0x12fede0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fede0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addPosition(/* No info */) {
    // ** addr: 0x12fef8c, size: 0x108
    // 0x12fef8c: EnterFrame
    //     0x12fef8c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fef90: mov             fp, SP
    // 0x12fef94: AllocStack(0x28)
    //     0x12fef94: sub             SP, SP, #0x28
    // 0x12fef98: SetupParameters(VelocityTracker this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12fef98: mov             x0, x1
    //     0x12fef9c: stur            x1, [fp, #-8]
    //     0x12fefa0: stur            x2, [fp, #-0x10]
    //     0x12fefa4: stur            x3, [fp, #-0x18]
    // 0x12fefa8: CheckStackOverflow
    //     0x12fefa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fefac: cmp             SP, x16
    //     0x12fefb0: b.ls            #0x12ff088
    // 0x12fefb4: mov             x1, x0
    // 0x12fefb8: r0 = _sinceLastSample()
    //     0x12fefb8: bl              #0x12fed50  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::_sinceLastSample
    // 0x12fefbc: mov             x1, x0
    // 0x12fefc0: r0 = start()
    //     0x12fefc0: bl              #0x82a468  ; [dart:core] Stopwatch::start
    // 0x12fefc4: ldur            x1, [fp, #-8]
    // 0x12fefc8: r0 = _sinceLastSample()
    //     0x12fefc8: bl              #0x12fed50  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::_sinceLastSample
    // 0x12fefcc: mov             x1, x0
    // 0x12fefd0: r0 = reset()
    //     0x12fefd0: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x12fefd4: ldur            x0, [fp, #-8]
    // 0x12fefd8: LoadField: r1 = r0->field_13
    //     0x12fefd8: ldur            x1, [x0, #0x13]
    // 0x12fefdc: add             x2, x1, #1
    // 0x12fefe0: StoreField: r0->field_13 = r2
    //     0x12fefe0: stur            x2, [x0, #0x13]
    // 0x12fefe4: cmp             x2, #0x14
    // 0x12fefe8: b.ne            #0x12feff8
    // 0x12fefec: StoreField: r0->field_13 = rZR
    //     0x12fefec: stur            xzr, [x0, #0x13]
    // 0x12feff0: r3 = 0
    //     0x12feff0: mov             x3, #0
    // 0x12feff4: b               #0x12feffc
    // 0x12feff8: mov             x3, x2
    // 0x12feffc: ldur            x2, [fp, #-0x10]
    // 0x12ff000: ldur            x1, [fp, #-0x18]
    // 0x12ff004: stur            x3, [fp, #-0x28]
    // 0x12ff008: LoadField: r4 = r0->field_f
    //     0x12ff008: ldur            w4, [x0, #0xf]
    // 0x12ff00c: DecompressPointer r4
    //     0x12ff00c: add             x4, x4, HEAP, lsl #32
    // 0x12ff010: stur            x4, [fp, #-0x20]
    // 0x12ff014: r0 = _PointAtTime()
    //     0x12ff014: bl              #0x12ff094  ; Allocate_PointAtTimeStub -> _PointAtTime (size=0x10)
    // 0x12ff018: mov             x3, x0
    // 0x12ff01c: ldur            x2, [fp, #-0x18]
    // 0x12ff020: StoreField: r3->field_b = r2
    //     0x12ff020: stur            w2, [x3, #0xb]
    // 0x12ff024: ldur            x2, [fp, #-0x10]
    // 0x12ff028: StoreField: r3->field_7 = r2
    //     0x12ff028: stur            w2, [x3, #7]
    // 0x12ff02c: ldur            x2, [fp, #-0x20]
    // 0x12ff030: LoadField: r4 = r2->field_b
    //     0x12ff030: ldur            w4, [x2, #0xb]
    // 0x12ff034: r0 = LoadInt32Instr(r4)
    //     0x12ff034: sbfx            x0, x4, #1, #0x1f
    // 0x12ff038: ldur            x1, [fp, #-0x28]
    // 0x12ff03c: cmp             x1, x0
    // 0x12ff040: b.hs            #0x12ff090
    // 0x12ff044: mov             x1, x2
    // 0x12ff048: mov             x0, x3
    // 0x12ff04c: ldur            x2, [fp, #-0x28]
    // 0x12ff050: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12ff050: add             x25, x1, x2, lsl #2
    //     0x12ff054: add             x25, x25, #0xf
    //     0x12ff058: str             w0, [x25]
    //     0x12ff05c: tbz             w0, #0, #0x12ff078
    //     0x12ff060: ldurb           w16, [x1, #-1]
    //     0x12ff064: ldurb           w17, [x0, #-1]
    //     0x12ff068: and             x16, x17, x16, lsr #2
    //     0x12ff06c: tst             x16, HEAP, lsr #32
    //     0x12ff070: b.eq            #0x12ff078
    //     0x12ff074: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12ff078: r0 = Null
    //     0x12ff078: mov             x0, NULL
    // 0x12ff07c: LeaveFrame
    //     0x12ff07c: mov             SP, fp
    //     0x12ff080: ldp             fp, lr, [SP], #0x10
    // 0x12ff084: ret
    //     0x12ff084: ret             
    // 0x12ff088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ff088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ff08c: b               #0x12fefb4
    // 0x12ff090: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12ff090: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3147, size: 0x10, field offset: 0x8
//   const constructor, 
class _PointAtTime extends Object {
}

// class id: 3148, size: 0x18, field offset: 0x8
//   const constructor, 
class VelocityEstimate extends Object {

  Offset field_8;
  _Double field_c;
  Offset field_14;
}

// class id: 3149, size: 0xc, field offset: 0x8
//   const constructor, 
class Velocity extends Object {

  Offset field_8;

  Velocity -(Velocity, Velocity) {
    // ** addr: 0xadef9c, size: 0x84
    // 0xadef9c: EnterFrame
    //     0xadef9c: stp             fp, lr, [SP, #-0x10]!
    //     0xadefa0: mov             fp, SP
    // 0xadefa4: CheckStackOverflow
    //     0xadefa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadefa8: cmp             SP, x16
    //     0xadefac: b.ls            #0xadf000
    // 0xadefb0: ldr             x0, [fp, #0x10]
    // 0xadefb4: r2 = Null
    //     0xadefb4: mov             x2, NULL
    // 0xadefb8: r1 = Null
    //     0xadefb8: mov             x1, NULL
    // 0xadefbc: r4 = 60
    //     0xadefbc: mov             x4, #0x3c
    // 0xadefc0: branchIfSmi(r0, 0xadefcc)
    //     0xadefc0: tbz             w0, #0, #0xadefcc
    // 0xadefc4: r4 = LoadClassIdInstr(r0)
    //     0xadefc4: ldur            x4, [x0, #-1]
    //     0xadefc8: ubfx            x4, x4, #0xc, #0x14
    // 0xadefcc: cmp             x4, #0xc4d
    // 0xadefd0: b.eq            #0xadefe8
    // 0xadefd4: r8 = Velocity
    //     0xadefd4: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cc10] Type: Velocity
    //     0xadefd8: ldr             x8, [x8, #0xc10]
    // 0xadefdc: r3 = Null
    //     0xadefdc: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cc28] Null
    //     0xadefe0: ldr             x3, [x3, #0xc28]
    // 0xadefe4: r0 = DefaultTypeTest()
    //     0xadefe4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xadefe8: ldr             x1, [fp, #0x18]
    // 0xadefec: ldr             x2, [fp, #0x10]
    // 0xadeff0: r0 = -()
    //     0xadeff0: bl              #0xadf008  ; [package:flutter/src/gestures/velocity_tracker.dart] Velocity::-
    // 0xadeff4: LeaveFrame
    //     0xadeff4: mov             SP, fp
    //     0xadeff8: ldp             fp, lr, [SP], #0x10
    // 0xadeffc: ret
    //     0xadeffc: ret             
    // 0xadf000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf004: b               #0xadefb0
  }
  Velocity -(Velocity, Velocity) {
    // ** addr: 0xadf008, size: 0x58
    // 0xadf008: EnterFrame
    //     0xadf008: stp             fp, lr, [SP, #-0x10]!
    //     0xadf00c: mov             fp, SP
    // 0xadf010: AllocStack(0x8)
    //     0xadf010: sub             SP, SP, #8
    // 0xadf014: CheckStackOverflow
    //     0xadf014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadf018: cmp             SP, x16
    //     0xadf01c: b.ls            #0xadf058
    // 0xadf020: LoadField: r0 = r1->field_7
    //     0xadf020: ldur            w0, [x1, #7]
    // 0xadf024: DecompressPointer r0
    //     0xadf024: add             x0, x0, HEAP, lsl #32
    // 0xadf028: LoadField: r1 = r2->field_7
    //     0xadf028: ldur            w1, [x2, #7]
    // 0xadf02c: DecompressPointer r1
    //     0xadf02c: add             x1, x1, HEAP, lsl #32
    // 0xadf030: mov             x2, x1
    // 0xadf034: mov             x1, x0
    // 0xadf038: r0 = -()
    //     0xadf038: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xadf03c: stur            x0, [fp, #-8]
    // 0xadf040: r0 = Velocity()
    //     0xadf040: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xadf044: ldur            x1, [fp, #-8]
    // 0xadf048: StoreField: r0->field_7 = r1
    //     0xadf048: stur            w1, [x0, #7]
    // 0xadf04c: LeaveFrame
    //     0xadf04c: mov             SP, fp
    //     0xadf050: ldp             fp, lr, [SP], #0x10
    // 0xadf054: ret
    //     0xadf054: ret             
    // 0xadf058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf058: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf05c: b               #0xadf020
  }
  Velocity +(Velocity, Velocity) {
    // ** addr: 0xadf078, size: 0x64
    // 0xadf078: EnterFrame
    //     0xadf078: stp             fp, lr, [SP, #-0x10]!
    //     0xadf07c: mov             fp, SP
    // 0xadf080: ldr             x0, [fp, #0x10]
    // 0xadf084: r2 = Null
    //     0xadf084: mov             x2, NULL
    // 0xadf088: r1 = Null
    //     0xadf088: mov             x1, NULL
    // 0xadf08c: r4 = 60
    //     0xadf08c: mov             x4, #0x3c
    // 0xadf090: branchIfSmi(r0, 0xadf09c)
    //     0xadf090: tbz             w0, #0, #0xadf09c
    // 0xadf094: r4 = LoadClassIdInstr(r0)
    //     0xadf094: ldur            x4, [x0, #-1]
    //     0xadf098: ubfx            x4, x4, #0xc, #0x14
    // 0xadf09c: cmp             x4, #0xc4d
    // 0xadf0a0: b.eq            #0xadf0b8
    // 0xadf0a4: r8 = Velocity
    //     0xadf0a4: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cc10] Type: Velocity
    //     0xadf0a8: ldr             x8, [x8, #0xc10]
    // 0xadf0ac: r3 = Null
    //     0xadf0ac: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cc18] Null
    //     0xadf0b0: ldr             x3, [x3, #0xc18]
    // 0xadf0b4: r0 = DefaultTypeTest()
    //     0xadf0b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xadf0b8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xadf0b8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xadf0bc: r0 = Throw()
    //     0xadf0bc: bl              #0x13ddb2c  ; ThrowStub
    // 0xadf0c0: brk             #0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114ac28, size: 0x40
    // 0x114ac28: EnterFrame
    //     0x114ac28: stp             fp, lr, [SP, #-0x10]!
    //     0x114ac2c: mov             fp, SP
    // 0x114ac30: AllocStack(0x8)
    //     0x114ac30: sub             SP, SP, #8
    // 0x114ac34: CheckStackOverflow
    //     0x114ac34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ac38: cmp             SP, x16
    //     0x114ac3c: b.ls            #0x114ac60
    // 0x114ac40: ldr             x0, [fp, #0x10]
    // 0x114ac44: LoadField: r1 = r0->field_7
    //     0x114ac44: ldur            w1, [x0, #7]
    // 0x114ac48: DecompressPointer r1
    //     0x114ac48: add             x1, x1, HEAP, lsl #32
    // 0x114ac4c: str             x1, [SP]
    // 0x114ac50: r0 = hashCode()
    //     0x114ac50: bl              #0x1155cac  ; [package:vector_graphics_compiler/src/geometry/basic_types.dart] Point::hashCode
    // 0x114ac54: LeaveFrame
    //     0x114ac54: mov             SP, fp
    //     0x114ac58: ldp             fp, lr, [SP], #0x10
    // 0x114ac5c: ret
    //     0x114ac5c: ret             
    // 0x114ac60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ac60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ac64: b               #0x114ac40
  }
  _ clampMagnitude(/* No info */) {
    // ** addr: 0x119f320, size: 0xe0
    // 0x119f320: EnterFrame
    //     0x119f320: stp             fp, lr, [SP, #-0x10]!
    //     0x119f324: mov             fp, SP
    // 0x119f328: AllocStack(0x18)
    //     0x119f328: sub             SP, SP, #0x18
    // 0x119f32c: SetupParameters(Velocity this /* r1 => r0 */, dynamic _ /* d0 => d2, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x10 */)
    //     0x119f32c: mov             x0, x1
    //     0x119f330: mov             v2.16b, v0.16b
    //     0x119f334: stur            d1, [fp, #-0x10]
    //     0x119f338: stur            d0, [fp, #-0x18]
    // 0x119f33c: CheckStackOverflow
    //     0x119f33c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f340: cmp             SP, x16
    //     0x119f344: b.ls            #0x119f3f8
    // 0x119f348: LoadField: r1 = r0->field_7
    //     0x119f348: ldur            w1, [x0, #7]
    // 0x119f34c: DecompressPointer r1
    //     0x119f34c: add             x1, x1, HEAP, lsl #32
    // 0x119f350: LoadField: d0 = r1->field_7
    //     0x119f350: ldur            d0, [x1, #7]
    // 0x119f354: fmul            d3, d0, d0
    // 0x119f358: LoadField: d0 = r1->field_f
    //     0x119f358: ldur            d0, [x1, #0xf]
    // 0x119f35c: fmul            d4, d0, d0
    // 0x119f360: fadd            d0, d3, d4
    // 0x119f364: fmul            d3, d1, d1
    // 0x119f368: fcmp            d0, d3
    // 0x119f36c: b.le            #0x119f3ac
    // 0x119f370: fsqrt           d2, d0
    // 0x119f374: mov             v0.16b, v2.16b
    // 0x119f378: r0 = /()
    //     0x119f378: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x119f37c: mov             x1, x0
    // 0x119f380: ldur            d0, [fp, #-0x10]
    // 0x119f384: r0 = *()
    //     0x119f384: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0x119f388: stur            x0, [fp, #-8]
    // 0x119f38c: r0 = Velocity()
    //     0x119f38c: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x119f390: mov             x1, x0
    // 0x119f394: ldur            x0, [fp, #-8]
    // 0x119f398: StoreField: r1->field_7 = r0
    //     0x119f398: stur            w0, [x1, #7]
    // 0x119f39c: mov             x0, x1
    // 0x119f3a0: LeaveFrame
    //     0x119f3a0: mov             SP, fp
    //     0x119f3a4: ldp             fp, lr, [SP], #0x10
    // 0x119f3a8: ret
    //     0x119f3a8: ret             
    // 0x119f3ac: fmul            d1, d2, d2
    // 0x119f3b0: fcmp            d1, d0
    // 0x119f3b4: b.le            #0x119f3ec
    // 0x119f3b8: fsqrt           d1, d0
    // 0x119f3bc: mov             v0.16b, v1.16b
    // 0x119f3c0: r0 = /()
    //     0x119f3c0: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x119f3c4: mov             x1, x0
    // 0x119f3c8: ldur            d0, [fp, #-0x18]
    // 0x119f3cc: r0 = *()
    //     0x119f3cc: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0x119f3d0: stur            x0, [fp, #-8]
    // 0x119f3d4: r0 = Velocity()
    //     0x119f3d4: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x119f3d8: ldur            x1, [fp, #-8]
    // 0x119f3dc: StoreField: r0->field_7 = r1
    //     0x119f3dc: stur            w1, [x0, #7]
    // 0x119f3e0: LeaveFrame
    //     0x119f3e0: mov             SP, fp
    //     0x119f3e4: ldp             fp, lr, [SP], #0x10
    // 0x119f3e8: ret
    //     0x119f3e8: ret             
    // 0x119f3ec: LeaveFrame
    //     0x119f3ec: mov             SP, fp
    //     0x119f3f0: ldp             fp, lr, [SP], #0x10
    // 0x119f3f4: ret
    //     0x119f3f4: ret             
    // 0x119f3f8: r0 = StackOverflowSharedWithFPURegs()
    //     0x119f3f8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x119f3fc: b               #0x119f348
  }
  _ unary-(/* No info */) {
    // ** addr: 0x123290c, size: 0x4c
    // 0x123290c: EnterFrame
    //     0x123290c: stp             fp, lr, [SP, #-0x10]!
    //     0x1232910: mov             fp, SP
    // 0x1232914: AllocStack(0x8)
    //     0x1232914: sub             SP, SP, #8
    // 0x1232918: CheckStackOverflow
    //     0x1232918: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123291c: cmp             SP, x16
    //     0x1232920: b.ls            #0x1232950
    // 0x1232924: LoadField: r0 = r1->field_7
    //     0x1232924: ldur            w0, [x1, #7]
    // 0x1232928: DecompressPointer r0
    //     0x1232928: add             x0, x0, HEAP, lsl #32
    // 0x123292c: mov             x1, x0
    // 0x1232930: r0 = unary-()
    //     0x1232930: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x1232934: stur            x0, [fp, #-8]
    // 0x1232938: r0 = Velocity()
    //     0x1232938: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x123293c: ldur            x1, [fp, #-8]
    // 0x1232940: StoreField: r0->field_7 = r1
    //     0x1232940: stur            w1, [x0, #7]
    // 0x1232944: LeaveFrame
    //     0x1232944: mov             SP, fp
    //     0x1232948: ldp             fp, lr, [SP], #0x10
    // 0x123294c: ret
    //     0x123294c: ret             
    // 0x1232950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1232950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1232954: b               #0x1232924
  }
  _ ==(/* No info */) {
    // ** addr: 0x1295b80, size: 0x84
    // 0x1295b80: EnterFrame
    //     0x1295b80: stp             fp, lr, [SP, #-0x10]!
    //     0x1295b84: mov             fp, SP
    // 0x1295b88: AllocStack(0x10)
    //     0x1295b88: sub             SP, SP, #0x10
    // 0x1295b8c: CheckStackOverflow
    //     0x1295b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1295b90: cmp             SP, x16
    //     0x1295b94: b.ls            #0x1295bfc
    // 0x1295b98: ldr             x0, [fp, #0x10]
    // 0x1295b9c: cmp             w0, NULL
    // 0x1295ba0: b.ne            #0x1295bb4
    // 0x1295ba4: r0 = false
    //     0x1295ba4: add             x0, NULL, #0x30  ; false
    // 0x1295ba8: LeaveFrame
    //     0x1295ba8: mov             SP, fp
    //     0x1295bac: ldp             fp, lr, [SP], #0x10
    // 0x1295bb0: ret
    //     0x1295bb0: ret             
    // 0x1295bb4: r1 = 60
    //     0x1295bb4: mov             x1, #0x3c
    // 0x1295bb8: branchIfSmi(r0, 0x1295bc4)
    //     0x1295bb8: tbz             w0, #0, #0x1295bc4
    // 0x1295bbc: r1 = LoadClassIdInstr(r0)
    //     0x1295bbc: ldur            x1, [x0, #-1]
    //     0x1295bc0: ubfx            x1, x1, #0xc, #0x14
    // 0x1295bc4: cmp             x1, #0xc4d
    // 0x1295bc8: b.ne            #0x1295bec
    // 0x1295bcc: ldr             x1, [fp, #0x18]
    // 0x1295bd0: LoadField: r2 = r0->field_7
    //     0x1295bd0: ldur            w2, [x0, #7]
    // 0x1295bd4: DecompressPointer r2
    //     0x1295bd4: add             x2, x2, HEAP, lsl #32
    // 0x1295bd8: LoadField: r0 = r1->field_7
    //     0x1295bd8: ldur            w0, [x1, #7]
    // 0x1295bdc: DecompressPointer r0
    //     0x1295bdc: add             x0, x0, HEAP, lsl #32
    // 0x1295be0: stp             x0, x2, [SP]
    // 0x1295be4: r0 = ==()
    //     0x1295be4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x1295be8: b               #0x1295bf0
    // 0x1295bec: r0 = false
    //     0x1295bec: add             x0, NULL, #0x30  ; false
    // 0x1295bf0: LeaveFrame
    //     0x1295bf0: mov             SP, fp
    //     0x1295bf4: ldp             fp, lr, [SP], #0x10
    // 0x1295bf8: ret
    //     0x1295bf8: ret             
    // 0x1295bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1295bfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1295c00: b               #0x1295b98
  }
}
