// lib: , url: package:flutter/src/gestures/team.dart

// class id: 1048836, size: 0x8
class :: {
}

// class id: 3150, size: 0x10, field offset: 0x8
class GestureArenaTeam extends Object {

  _ add(/* No info */) {
    // ** addr: 0x10f2fd4, size: 0xc4
    // 0x10f2fd4: EnterFrame
    //     0x10f2fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2fd8: mov             fp, SP
    // 0x10f2fdc: AllocStack(0x30)
    //     0x10f2fdc: sub             SP, SP, #0x30
    // 0x10f2fe0: SetupParameters(GestureArenaTeam this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10f2fe0: stur            x1, [fp, #-8]
    //     0x10f2fe4: stur            x2, [fp, #-0x10]
    //     0x10f2fe8: stur            x3, [fp, #-0x18]
    // 0x10f2fec: CheckStackOverflow
    //     0x10f2fec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2ff0: cmp             SP, x16
    //     0x10f2ff4: b.ls            #0x10f3090
    // 0x10f2ff8: r1 = 2
    //     0x10f2ff8: mov             x1, #2
    // 0x10f2ffc: r0 = AllocateContext()
    //     0x10f2ffc: bl              #0x13de838  ; AllocateContextStub
    // 0x10f3000: mov             x3, x0
    // 0x10f3004: ldur            x2, [fp, #-8]
    // 0x10f3008: stur            x3, [fp, #-0x30]
    // 0x10f300c: StoreField: r3->field_f = r2
    //     0x10f300c: stur            w2, [x3, #0xf]
    // 0x10f3010: ldur            x4, [fp, #-0x10]
    // 0x10f3014: r0 = BoxInt64Instr(r4)
    //     0x10f3014: sbfiz           x0, x4, #1, #0x1f
    //     0x10f3018: cmp             x4, x0, asr #1
    //     0x10f301c: b.eq            #0x10f3028
    //     0x10f3020: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f3024: stur            x4, [x0, #7]
    // 0x10f3028: stur            x0, [fp, #-0x28]
    // 0x10f302c: StoreField: r3->field_13 = r0
    //     0x10f302c: stur            w0, [x3, #0x13]
    // 0x10f3030: LoadField: r4 = r2->field_7
    //     0x10f3030: ldur            w4, [x2, #7]
    // 0x10f3034: DecompressPointer r4
    //     0x10f3034: add             x4, x4, HEAP, lsl #32
    // 0x10f3038: mov             x2, x3
    // 0x10f303c: stur            x4, [fp, #-0x20]
    // 0x10f3040: r1 = Function '<anonymous closure>':.
    //     0x10f3040: add             x1, PP, #0x96, lsl #12  ; [pp+0x960e0] AnonymousClosure: (0x10f3268), in [package:flutter/src/gestures/team.dart] GestureArenaTeam::add (0x10f2fd4)
    //     0x10f3044: ldr             x1, [x1, #0xe0]
    // 0x10f3048: r0 = AllocateClosure()
    //     0x10f3048: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f304c: ldur            x1, [fp, #-0x20]
    // 0x10f3050: ldur            x2, [fp, #-0x28]
    // 0x10f3054: mov             x3, x0
    // 0x10f3058: r0 = putIfAbsent()
    //     0x10f3058: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x10f305c: mov             x1, x0
    // 0x10f3060: ldur            x0, [fp, #-0x30]
    // 0x10f3064: LoadField: r2 = r0->field_13
    //     0x10f3064: ldur            w2, [x0, #0x13]
    // 0x10f3068: DecompressPointer r2
    //     0x10f3068: add             x2, x2, HEAP, lsl #32
    // 0x10f306c: r0 = LoadInt32Instr(r2)
    //     0x10f306c: sbfx            x0, x2, #1, #0x1f
    //     0x10f3070: tbz             w2, #0, #0x10f3078
    //     0x10f3074: ldur            x0, [x2, #7]
    // 0x10f3078: mov             x2, x0
    // 0x10f307c: ldur            x3, [fp, #-0x18]
    // 0x10f3080: r0 = _add()
    //     0x10f3080: bl              #0x10f3098  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_add
    // 0x10f3084: LeaveFrame
    //     0x10f3084: mov             SP, fp
    //     0x10f3088: ldp             fp, lr, [SP], #0x10
    // 0x10f308c: ret
    //     0x10f308c: ret             
    // 0x10f3090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f3090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f3094: b               #0x10f2ff8
  }
  [closure] _CombiningGestureArenaMember <anonymous closure>(dynamic) {
    // ** addr: 0x10f3268, size: 0xcc
    // 0x10f3268: EnterFrame
    //     0x10f3268: stp             fp, lr, [SP, #-0x10]!
    //     0x10f326c: mov             fp, SP
    // 0x10f3270: AllocStack(0x18)
    //     0x10f3270: sub             SP, SP, #0x18
    // 0x10f3274: SetupParameters([dynamic _ /* r0 */])
    //     0x10f3274: ldr             x0, [fp, #0x10]
    //     0x10f3278: ldur            w1, [x0, #0x17]
    //     0x10f327c: add             x1, x1, HEAP, lsl #32
    // 0x10f3280: CheckStackOverflow
    //     0x10f3280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f3284: cmp             SP, x16
    //     0x10f3288: b.ls            #0x10f332c
    // 0x10f328c: LoadField: r0 = r1->field_f
    //     0x10f328c: ldur            w0, [x1, #0xf]
    // 0x10f3290: DecompressPointer r0
    //     0x10f3290: add             x0, x0, HEAP, lsl #32
    // 0x10f3294: stur            x0, [fp, #-0x10]
    // 0x10f3298: LoadField: r2 = r1->field_13
    //     0x10f3298: ldur            w2, [x1, #0x13]
    // 0x10f329c: DecompressPointer r2
    //     0x10f329c: add             x2, x2, HEAP, lsl #32
    // 0x10f32a0: stur            x2, [fp, #-8]
    // 0x10f32a4: r0 = _CombiningGestureArenaMember()
    //     0x10f32a4: bl              #0x10f3334  ; Allocate_CombiningGestureArenaMemberStub -> _CombiningGestureArenaMember (size=0x24)
    // 0x10f32a8: mov             x3, x0
    // 0x10f32ac: r0 = false
    //     0x10f32ac: add             x0, NULL, #0x30  ; false
    // 0x10f32b0: stur            x3, [fp, #-0x18]
    // 0x10f32b4: ArrayStore: r3[0] = r0  ; List_4
    //     0x10f32b4: stur            w0, [x3, #0x17]
    // 0x10f32b8: r1 = <GestureArenaMember>
    //     0x10f32b8: add             x1, PP, #0x96, lsl #12  ; [pp+0x960d8] TypeArguments: <GestureArenaMember>
    //     0x10f32bc: ldr             x1, [x1, #0xd8]
    // 0x10f32c0: r2 = 0
    //     0x10f32c0: mov             x2, #0
    // 0x10f32c4: r0 = _GrowableList()
    //     0x10f32c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x10f32c8: ldur            x1, [fp, #-0x18]
    // 0x10f32cc: StoreField: r1->field_b = r0
    //     0x10f32cc: stur            w0, [x1, #0xb]
    //     0x10f32d0: ldurb           w16, [x1, #-1]
    //     0x10f32d4: ldurb           w17, [x0, #-1]
    //     0x10f32d8: and             x16, x17, x16, lsr #2
    //     0x10f32dc: tst             x16, HEAP, lsr #32
    //     0x10f32e0: b.eq            #0x10f32e8
    //     0x10f32e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f32e8: ldur            x0, [fp, #-0x10]
    // 0x10f32ec: StoreField: r1->field_7 = r0
    //     0x10f32ec: stur            w0, [x1, #7]
    //     0x10f32f0: ldurb           w16, [x1, #-1]
    //     0x10f32f4: ldurb           w17, [x0, #-1]
    //     0x10f32f8: and             x16, x17, x16, lsr #2
    //     0x10f32fc: tst             x16, HEAP, lsr #32
    //     0x10f3300: b.eq            #0x10f3308
    //     0x10f3304: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f3308: ldur            x2, [fp, #-8]
    // 0x10f330c: r3 = LoadInt32Instr(r2)
    //     0x10f330c: sbfx            x3, x2, #1, #0x1f
    //     0x10f3310: tbz             w2, #0, #0x10f3318
    //     0x10f3314: ldur            x3, [x2, #7]
    // 0x10f3318: StoreField: r1->field_f = r3
    //     0x10f3318: stur            x3, [x1, #0xf]
    // 0x10f331c: mov             x0, x1
    // 0x10f3320: LeaveFrame
    //     0x10f3320: mov             SP, fp
    //     0x10f3324: ldp             fp, lr, [SP], #0x10
    // 0x10f3328: ret
    //     0x10f3328: ret             
    // 0x10f332c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f332c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f3330: b               #0x10f328c
  }
}

// class id: 3151, size: 0x10, field offset: 0x8
class _CombiningGestureArenaEntry extends Object
    implements GestureArenaEntry {

  void resolve(_CombiningGestureArenaEntry, GestureDisposition) {
    // ** addr: 0x10f31f8, size: 0x88
    // 0x10f31f8: EnterFrame
    //     0x10f31f8: stp             fp, lr, [SP, #-0x10]!
    //     0x10f31fc: mov             fp, SP
    // 0x10f3200: CheckStackOverflow
    //     0x10f3200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f3204: cmp             SP, x16
    //     0x10f3208: b.ls            #0x10f3260
    // 0x10f320c: ldr             x0, [fp, #0x10]
    // 0x10f3210: r2 = Null
    //     0x10f3210: mov             x2, NULL
    // 0x10f3214: r1 = Null
    //     0x10f3214: mov             x1, NULL
    // 0x10f3218: r4 = 60
    //     0x10f3218: mov             x4, #0x3c
    // 0x10f321c: branchIfSmi(r0, 0x10f3228)
    //     0x10f321c: tbz             w0, #0, #0x10f3228
    // 0x10f3220: r4 = LoadClassIdInstr(r0)
    //     0x10f3220: ldur            x4, [x0, #-1]
    //     0x10f3224: ubfx            x4, x4, #0xc, #0x14
    // 0x10f3228: r17 = 8312
    //     0x10f3228: mov             x17, #0x2078
    // 0x10f322c: cmp             x4, x17
    // 0x10f3230: b.eq            #0x10f3248
    // 0x10f3234: r8 = GestureDisposition
    //     0x10f3234: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d30] Type: GestureDisposition
    //     0x10f3238: ldr             x8, [x8, #0xd30]
    // 0x10f323c: r3 = Null
    //     0x10f323c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa10d0] Null
    //     0x10f3240: ldr             x3, [x3, #0xd0]
    // 0x10f3244: r0 = DefaultTypeTest()
    //     0x10f3244: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10f3248: ldr             x1, [fp, #0x18]
    // 0x10f324c: ldr             x2, [fp, #0x10]
    // 0x10f3250: r0 = resolve()
    //     0x10f3250: bl              #0x12fee08  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaEntry::resolve
    // 0x10f3254: LeaveFrame
    //     0x10f3254: mov             SP, fp
    //     0x10f3258: ldp             fp, lr, [SP], #0x10
    // 0x10f325c: ret
    //     0x10f325c: ret             
    // 0x10f3260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f3260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f3264: b               #0x10f320c
  }
  void resolve(_CombiningGestureArenaEntry, GestureDisposition) {
    // ** addr: 0x12fee08, size: 0x48
    // 0x12fee08: EnterFrame
    //     0x12fee08: stp             fp, lr, [SP, #-0x10]!
    //     0x12fee0c: mov             fp, SP
    // 0x12fee10: mov             x3, x2
    // 0x12fee14: CheckStackOverflow
    //     0x12fee14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fee18: cmp             SP, x16
    //     0x12fee1c: b.ls            #0x12fee48
    // 0x12fee20: LoadField: r0 = r1->field_7
    //     0x12fee20: ldur            w0, [x1, #7]
    // 0x12fee24: DecompressPointer r0
    //     0x12fee24: add             x0, x0, HEAP, lsl #32
    // 0x12fee28: LoadField: r2 = r1->field_b
    //     0x12fee28: ldur            w2, [x1, #0xb]
    // 0x12fee2c: DecompressPointer r2
    //     0x12fee2c: add             x2, x2, HEAP, lsl #32
    // 0x12fee30: mov             x1, x0
    // 0x12fee34: r0 = _resolve()
    //     0x12fee34: bl              #0x12fee50  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_resolve
    // 0x12fee38: r0 = Null
    //     0x12fee38: mov             x0, NULL
    // 0x12fee3c: LeaveFrame
    //     0x12fee3c: mov             SP, fp
    //     0x12fee40: ldp             fp, lr, [SP], #0x10
    // 0x12fee44: ret
    //     0x12fee44: ret             
    // 0x12fee48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fee48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fee4c: b               #0x12fee20
  }
}

// class id: 4426, size: 0x24, field offset: 0x8
class _CombiningGestureArenaMember extends GestureArenaMember {

  _ _add(/* No info */) {
    // ** addr: 0x10f3098, size: 0x13c
    // 0x10f3098: EnterFrame
    //     0x10f3098: stp             fp, lr, [SP, #-0x10]!
    //     0x10f309c: mov             fp, SP
    // 0x10f30a0: AllocStack(0x28)
    //     0x10f30a0: sub             SP, SP, #0x28
    // 0x10f30a4: SetupParameters(_CombiningGestureArenaMember this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r0, fp-0x28 */)
    //     0x10f30a4: mov             x0, x3
    //     0x10f30a8: stur            x3, [fp, #-0x28]
    //     0x10f30ac: mov             x3, x1
    //     0x10f30b0: stur            x1, [fp, #-0x18]
    //     0x10f30b4: stur            x2, [fp, #-0x20]
    // 0x10f30b8: CheckStackOverflow
    //     0x10f30b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f30bc: cmp             SP, x16
    //     0x10f30c0: b.ls            #0x10f31c8
    // 0x10f30c4: LoadField: r4 = r3->field_b
    //     0x10f30c4: ldur            w4, [x3, #0xb]
    // 0x10f30c8: DecompressPointer r4
    //     0x10f30c8: add             x4, x4, HEAP, lsl #32
    // 0x10f30cc: stur            x4, [fp, #-0x10]
    // 0x10f30d0: LoadField: r1 = r4->field_b
    //     0x10f30d0: ldur            w1, [x4, #0xb]
    // 0x10f30d4: LoadField: r5 = r4->field_f
    //     0x10f30d4: ldur            w5, [x4, #0xf]
    // 0x10f30d8: DecompressPointer r5
    //     0x10f30d8: add             x5, x5, HEAP, lsl #32
    // 0x10f30dc: LoadField: r6 = r5->field_b
    //     0x10f30dc: ldur            w6, [x5, #0xb]
    // 0x10f30e0: r5 = LoadInt32Instr(r1)
    //     0x10f30e0: sbfx            x5, x1, #1, #0x1f
    // 0x10f30e4: stur            x5, [fp, #-8]
    // 0x10f30e8: r1 = LoadInt32Instr(r6)
    //     0x10f30e8: sbfx            x1, x6, #1, #0x1f
    // 0x10f30ec: cmp             x5, x1
    // 0x10f30f0: b.ne            #0x10f30fc
    // 0x10f30f4: mov             x1, x4
    // 0x10f30f8: r0 = _growToNextCapacity()
    //     0x10f30f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x10f30fc: ldur            x4, [fp, #-0x18]
    // 0x10f3100: ldur            x0, [fp, #-0x10]
    // 0x10f3104: ldur            x2, [fp, #-8]
    // 0x10f3108: add             x1, x2, #1
    // 0x10f310c: lsl             x3, x1, #1
    // 0x10f3110: StoreField: r0->field_b = r3
    //     0x10f3110: stur            w3, [x0, #0xb]
    // 0x10f3114: LoadField: r1 = r0->field_f
    //     0x10f3114: ldur            w1, [x0, #0xf]
    // 0x10f3118: DecompressPointer r1
    //     0x10f3118: add             x1, x1, HEAP, lsl #32
    // 0x10f311c: ldur            x0, [fp, #-0x28]
    // 0x10f3120: ArrayStore: r1[r2] = r0  ; List_4
    //     0x10f3120: add             x25, x1, x2, lsl #2
    //     0x10f3124: add             x25, x25, #0xf
    //     0x10f3128: str             w0, [x25]
    //     0x10f312c: tbz             w0, #0, #0x10f3148
    //     0x10f3130: ldurb           w16, [x1, #-1]
    //     0x10f3134: ldurb           w17, [x0, #-1]
    //     0x10f3138: and             x16, x17, x16, lsr #2
    //     0x10f313c: tst             x16, HEAP, lsr #32
    //     0x10f3140: b.eq            #0x10f3148
    //     0x10f3144: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x10f3148: LoadField: r0 = r4->field_1f
    //     0x10f3148: ldur            w0, [x4, #0x1f]
    // 0x10f314c: DecompressPointer r0
    //     0x10f314c: add             x0, x0, HEAP, lsl #32
    // 0x10f3150: cmp             w0, NULL
    // 0x10f3154: b.ne            #0x10f31a0
    // 0x10f3158: r0 = LoadStaticField(0x7d0)
    //     0x10f3158: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10f315c: ldr             x0, [x0, #0xfa0]
    // 0x10f3160: cmp             w0, NULL
    // 0x10f3164: b.eq            #0x10f31d0
    // 0x10f3168: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10f3168: ldur            w1, [x0, #0x17]
    // 0x10f316c: DecompressPointer r1
    //     0x10f316c: add             x1, x1, HEAP, lsl #32
    // 0x10f3170: ldur            x2, [fp, #-0x20]
    // 0x10f3174: mov             x3, x4
    // 0x10f3178: r0 = add()
    //     0x10f3178: bl              #0xba8eac  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x10f317c: ldur            x1, [fp, #-0x18]
    // 0x10f3180: StoreField: r1->field_1f = r0
    //     0x10f3180: stur            w0, [x1, #0x1f]
    //     0x10f3184: ldurb           w16, [x1, #-1]
    //     0x10f3188: ldurb           w17, [x0, #-1]
    //     0x10f318c: and             x16, x17, x16, lsr #2
    //     0x10f3190: tst             x16, HEAP, lsr #32
    //     0x10f3194: b.eq            #0x10f319c
    //     0x10f3198: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f319c: b               #0x10f31a4
    // 0x10f31a0: mov             x1, x4
    // 0x10f31a4: ldur            x0, [fp, #-0x28]
    // 0x10f31a8: r0 = _CombiningGestureArenaEntry()
    //     0x10f31a8: bl              #0x10f31d4  ; Allocate_CombiningGestureArenaEntryStub -> _CombiningGestureArenaEntry (size=0x10)
    // 0x10f31ac: ldur            x1, [fp, #-0x18]
    // 0x10f31b0: StoreField: r0->field_7 = r1
    //     0x10f31b0: stur            w1, [x0, #7]
    // 0x10f31b4: ldur            x1, [fp, #-0x28]
    // 0x10f31b8: StoreField: r0->field_b = r1
    //     0x10f31b8: stur            w1, [x0, #0xb]
    // 0x10f31bc: LeaveFrame
    //     0x10f31bc: mov             SP, fp
    //     0x10f31c0: ldp             fp, lr, [SP], #0x10
    // 0x10f31c4: ret
    //     0x10f31c4: ret             
    // 0x10f31c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f31c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f31cc: b               #0x10f30c4
    // 0x10f31d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f31d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d3ac, size: 0xfc
    // 0x116d3ac: EnterFrame
    //     0x116d3ac: stp             fp, lr, [SP, #-0x10]!
    //     0x116d3b0: mov             fp, SP
    // 0x116d3b4: AllocStack(0x28)
    //     0x116d3b4: sub             SP, SP, #0x28
    // 0x116d3b8: SetupParameters(_CombiningGestureArenaMember this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x116d3b8: mov             x0, x1
    //     0x116d3bc: stur            x1, [fp, #-8]
    //     0x116d3c0: stur            x2, [fp, #-0x10]
    // 0x116d3c4: CheckStackOverflow
    //     0x116d3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d3c8: cmp             SP, x16
    //     0x116d3cc: b.ls            #0x116d498
    // 0x116d3d0: mov             x1, x0
    // 0x116d3d4: r0 = _close()
    //     0x116d3d4: bl              #0x116d4a8  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_close
    // 0x116d3d8: ldur            x0, [fp, #-8]
    // 0x116d3dc: LoadField: r3 = r0->field_b
    //     0x116d3dc: ldur            w3, [x0, #0xb]
    // 0x116d3e0: DecompressPointer r3
    //     0x116d3e0: add             x3, x3, HEAP, lsl #32
    // 0x116d3e4: stur            x3, [fp, #-0x28]
    // 0x116d3e8: LoadField: r0 = r3->field_b
    //     0x116d3e8: ldur            w0, [x3, #0xb]
    // 0x116d3ec: r4 = LoadInt32Instr(r0)
    //     0x116d3ec: sbfx            x4, x0, #1, #0x1f
    // 0x116d3f0: stur            x4, [fp, #-0x20]
    // 0x116d3f4: r0 = 0
    //     0x116d3f4: mov             x0, #0
    // 0x116d3f8: CheckStackOverflow
    //     0x116d3f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d3fc: cmp             SP, x16
    //     0x116d400: b.ls            #0x116d4a0
    // 0x116d404: LoadField: r1 = r3->field_b
    //     0x116d404: ldur            w1, [x3, #0xb]
    // 0x116d408: r2 = LoadInt32Instr(r1)
    //     0x116d408: sbfx            x2, x1, #1, #0x1f
    // 0x116d40c: cmp             x4, x2
    // 0x116d410: b.ne            #0x116d478
    // 0x116d414: cmp             x0, x2
    // 0x116d418: b.ge            #0x116d468
    // 0x116d41c: LoadField: r1 = r3->field_f
    //     0x116d41c: ldur            w1, [x3, #0xf]
    // 0x116d420: DecompressPointer r1
    //     0x116d420: add             x1, x1, HEAP, lsl #32
    // 0x116d424: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0x116d424: add             x16, x1, x0, lsl #2
    //     0x116d428: ldur            w2, [x16, #0xf]
    // 0x116d42c: DecompressPointer r2
    //     0x116d42c: add             x2, x2, HEAP, lsl #32
    // 0x116d430: add             x5, x0, #1
    // 0x116d434: stur            x5, [fp, #-0x18]
    // 0x116d438: r0 = LoadClassIdInstr(r2)
    //     0x116d438: ldur            x0, [x2, #-1]
    //     0x116d43c: ubfx            x0, x0, #0xc, #0x14
    // 0x116d440: mov             x1, x2
    // 0x116d444: ldur            x2, [fp, #-0x10]
    // 0x116d448: r0 = GDT[cid_x0 + 0x4deb]()
    //     0x116d448: mov             x17, #0x4deb
    //     0x116d44c: add             lr, x0, x17
    //     0x116d450: ldr             lr, [x21, lr, lsl #3]
    //     0x116d454: blr             lr
    // 0x116d458: ldur            x0, [fp, #-0x18]
    // 0x116d45c: ldur            x3, [fp, #-0x28]
    // 0x116d460: ldur            x4, [fp, #-0x20]
    // 0x116d464: b               #0x116d3f8
    // 0x116d468: r0 = Null
    //     0x116d468: mov             x0, NULL
    // 0x116d46c: LeaveFrame
    //     0x116d46c: mov             SP, fp
    //     0x116d470: ldp             fp, lr, [SP], #0x10
    // 0x116d474: ret
    //     0x116d474: ret             
    // 0x116d478: mov             x0, x3
    // 0x116d47c: r0 = ConcurrentModificationError()
    //     0x116d47c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x116d480: mov             x1, x0
    // 0x116d484: ldur            x0, [fp, #-0x28]
    // 0x116d488: StoreField: r1->field_b = r0
    //     0x116d488: stur            w0, [x1, #0xb]
    // 0x116d48c: mov             x0, x1
    // 0x116d490: r0 = Throw()
    //     0x116d490: bl              #0x13ddb2c  ; ThrowStub
    // 0x116d494: brk             #0
    // 0x116d498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d49c: b               #0x116d3d0
    // 0x116d4a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d4a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d4a4: b               #0x116d404
  }
  _ _close(/* No info */) {
    // ** addr: 0x116d4a8, size: 0x68
    // 0x116d4a8: EnterFrame
    //     0x116d4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x116d4ac: mov             fp, SP
    // 0x116d4b0: r0 = true
    //     0x116d4b0: add             x0, NULL, #0x20  ; true
    // 0x116d4b4: CheckStackOverflow
    //     0x116d4b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d4b8: cmp             SP, x16
    //     0x116d4bc: b.ls            #0x116d508
    // 0x116d4c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x116d4c0: stur            w0, [x1, #0x17]
    // 0x116d4c4: LoadField: r0 = r1->field_7
    //     0x116d4c4: ldur            w0, [x1, #7]
    // 0x116d4c8: DecompressPointer r0
    //     0x116d4c8: add             x0, x0, HEAP, lsl #32
    // 0x116d4cc: LoadField: r2 = r0->field_7
    //     0x116d4cc: ldur            w2, [x0, #7]
    // 0x116d4d0: DecompressPointer r2
    //     0x116d4d0: add             x2, x2, HEAP, lsl #32
    // 0x116d4d4: LoadField: r3 = r1->field_f
    //     0x116d4d4: ldur            x3, [x1, #0xf]
    // 0x116d4d8: r0 = BoxInt64Instr(r3)
    //     0x116d4d8: sbfiz           x0, x3, #1, #0x1f
    //     0x116d4dc: cmp             x3, x0, asr #1
    //     0x116d4e0: b.eq            #0x116d4ec
    //     0x116d4e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d4e8: stur            x3, [x0, #7]
    // 0x116d4ec: mov             x1, x2
    // 0x116d4f0: mov             x2, x0
    // 0x116d4f4: r0 = remove()
    //     0x116d4f4: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x116d4f8: r0 = Null
    //     0x116d4f8: mov             x0, NULL
    // 0x116d4fc: LeaveFrame
    //     0x116d4fc: mov             SP, fp
    //     0x116d500: ldp             fp, lr, [SP], #0x10
    // 0x116d504: ret
    //     0x116d504: ret             
    // 0x116d508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d50c: b               #0x116d4c0
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119cbb0, size: 0x1c8
    // 0x119cbb0: EnterFrame
    //     0x119cbb0: stp             fp, lr, [SP, #-0x10]!
    //     0x119cbb4: mov             fp, SP
    // 0x119cbb8: AllocStack(0x28)
    //     0x119cbb8: sub             SP, SP, #0x28
    // 0x119cbbc: SetupParameters(_CombiningGestureArenaMember this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x119cbbc: mov             x0, x1
    //     0x119cbc0: stur            x1, [fp, #-8]
    //     0x119cbc4: stur            x2, [fp, #-0x10]
    // 0x119cbc8: CheckStackOverflow
    //     0x119cbc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119cbcc: cmp             SP, x16
    //     0x119cbd0: b.ls            #0x119cd60
    // 0x119cbd4: mov             x1, x0
    // 0x119cbd8: r0 = _close()
    //     0x119cbd8: bl              #0x116d4a8  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_close
    // 0x119cbdc: ldur            x3, [fp, #-8]
    // 0x119cbe0: LoadField: r0 = r3->field_1b
    //     0x119cbe0: ldur            w0, [x3, #0x1b]
    // 0x119cbe4: DecompressPointer r0
    //     0x119cbe4: add             x0, x0, HEAP, lsl #32
    // 0x119cbe8: cmp             w0, NULL
    // 0x119cbec: b.ne            #0x119cc60
    // 0x119cbf0: LoadField: r0 = r3->field_7
    //     0x119cbf0: ldur            w0, [x3, #7]
    // 0x119cbf4: DecompressPointer r0
    //     0x119cbf4: add             x0, x0, HEAP, lsl #32
    // 0x119cbf8: LoadField: r1 = r0->field_b
    //     0x119cbf8: ldur            w1, [x0, #0xb]
    // 0x119cbfc: DecompressPointer r1
    //     0x119cbfc: add             x1, x1, HEAP, lsl #32
    // 0x119cc00: cmp             w1, NULL
    // 0x119cc04: b.ne            #0x119cc40
    // 0x119cc08: LoadField: r2 = r3->field_b
    //     0x119cc08: ldur            w2, [x3, #0xb]
    // 0x119cc0c: DecompressPointer r2
    //     0x119cc0c: add             x2, x2, HEAP, lsl #32
    // 0x119cc10: LoadField: r0 = r2->field_b
    //     0x119cc10: ldur            w0, [x2, #0xb]
    // 0x119cc14: r1 = LoadInt32Instr(r0)
    //     0x119cc14: sbfx            x1, x0, #1, #0x1f
    // 0x119cc18: mov             x0, x1
    // 0x119cc1c: r1 = 0
    //     0x119cc1c: mov             x1, #0
    // 0x119cc20: cmp             x1, x0
    // 0x119cc24: b.hs            #0x119cd68
    // 0x119cc28: LoadField: r0 = r2->field_f
    //     0x119cc28: ldur            w0, [x2, #0xf]
    // 0x119cc2c: DecompressPointer r0
    //     0x119cc2c: add             x0, x0, HEAP, lsl #32
    // 0x119cc30: LoadField: r1 = r0->field_f
    //     0x119cc30: ldur            w1, [x0, #0xf]
    // 0x119cc34: DecompressPointer r1
    //     0x119cc34: add             x1, x1, HEAP, lsl #32
    // 0x119cc38: mov             x0, x1
    // 0x119cc3c: b               #0x119cc44
    // 0x119cc40: mov             x0, x1
    // 0x119cc44: StoreField: r3->field_1b = r0
    //     0x119cc44: stur            w0, [x3, #0x1b]
    //     0x119cc48: ldurb           w16, [x3, #-1]
    //     0x119cc4c: ldurb           w17, [x0, #-1]
    //     0x119cc50: and             x16, x17, x16, lsr #2
    //     0x119cc54: tst             x16, HEAP, lsr #32
    //     0x119cc58: b.eq            #0x119cc60
    //     0x119cc5c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x119cc60: LoadField: r4 = r3->field_b
    //     0x119cc60: ldur            w4, [x3, #0xb]
    // 0x119cc64: DecompressPointer r4
    //     0x119cc64: add             x4, x4, HEAP, lsl #32
    // 0x119cc68: stur            x4, [fp, #-0x28]
    // 0x119cc6c: LoadField: r0 = r4->field_b
    //     0x119cc6c: ldur            w0, [x4, #0xb]
    // 0x119cc70: r5 = LoadInt32Instr(r0)
    //     0x119cc70: sbfx            x5, x0, #1, #0x1f
    // 0x119cc74: stur            x5, [fp, #-0x20]
    // 0x119cc78: r0 = 0
    //     0x119cc78: mov             x0, #0
    // 0x119cc7c: CheckStackOverflow
    //     0x119cc7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119cc80: cmp             SP, x16
    //     0x119cc84: b.ls            #0x119cd6c
    // 0x119cc88: LoadField: r1 = r4->field_b
    //     0x119cc88: ldur            w1, [x4, #0xb]
    // 0x119cc8c: r2 = LoadInt32Instr(r1)
    //     0x119cc8c: sbfx            x2, x1, #1, #0x1f
    // 0x119cc90: cmp             x5, x2
    // 0x119cc94: b.ne            #0x119cd40
    // 0x119cc98: cmp             x0, x2
    // 0x119cc9c: b.ge            #0x119cd00
    // 0x119cca0: LoadField: r1 = r4->field_f
    //     0x119cca0: ldur            w1, [x4, #0xf]
    // 0x119cca4: DecompressPointer r1
    //     0x119cca4: add             x1, x1, HEAP, lsl #32
    // 0x119cca8: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0x119cca8: add             x16, x1, x0, lsl #2
    //     0x119ccac: ldur            w2, [x16, #0xf]
    // 0x119ccb0: DecompressPointer r2
    //     0x119ccb0: add             x2, x2, HEAP, lsl #32
    // 0x119ccb4: add             x6, x0, #1
    // 0x119ccb8: stur            x6, [fp, #-0x18]
    // 0x119ccbc: LoadField: r0 = r3->field_1b
    //     0x119ccbc: ldur            w0, [x3, #0x1b]
    // 0x119ccc0: DecompressPointer r0
    //     0x119ccc0: add             x0, x0, HEAP, lsl #32
    // 0x119ccc4: cmp             w2, w0
    // 0x119ccc8: b.eq            #0x119ccec
    // 0x119cccc: r0 = LoadClassIdInstr(r2)
    //     0x119cccc: ldur            x0, [x2, #-1]
    //     0x119ccd0: ubfx            x0, x0, #0xc, #0x14
    // 0x119ccd4: mov             x1, x2
    // 0x119ccd8: ldur            x2, [fp, #-0x10]
    // 0x119ccdc: r0 = GDT[cid_x0 + 0x4deb]()
    //     0x119ccdc: mov             x17, #0x4deb
    //     0x119cce0: add             lr, x0, x17
    //     0x119cce4: ldr             lr, [x21, lr, lsl #3]
    //     0x119cce8: blr             lr
    // 0x119ccec: ldur            x0, [fp, #-0x18]
    // 0x119ccf0: ldur            x3, [fp, #-8]
    // 0x119ccf4: ldur            x4, [fp, #-0x28]
    // 0x119ccf8: ldur            x5, [fp, #-0x20]
    // 0x119ccfc: b               #0x119cc7c
    // 0x119cd00: mov             x0, x3
    // 0x119cd04: LoadField: r1 = r0->field_1b
    //     0x119cd04: ldur            w1, [x0, #0x1b]
    // 0x119cd08: DecompressPointer r1
    //     0x119cd08: add             x1, x1, HEAP, lsl #32
    // 0x119cd0c: cmp             w1, NULL
    // 0x119cd10: b.eq            #0x119cd74
    // 0x119cd14: r0 = LoadClassIdInstr(r1)
    //     0x119cd14: ldur            x0, [x1, #-1]
    //     0x119cd18: ubfx            x0, x0, #0xc, #0x14
    // 0x119cd1c: ldur            x2, [fp, #-0x10]
    // 0x119cd20: r0 = GDT[cid_x0 + 0x2d08]()
    //     0x119cd20: mov             x17, #0x2d08
    //     0x119cd24: add             lr, x0, x17
    //     0x119cd28: ldr             lr, [x21, lr, lsl #3]
    //     0x119cd2c: blr             lr
    // 0x119cd30: r0 = Null
    //     0x119cd30: mov             x0, NULL
    // 0x119cd34: LeaveFrame
    //     0x119cd34: mov             SP, fp
    //     0x119cd38: ldp             fp, lr, [SP], #0x10
    // 0x119cd3c: ret
    //     0x119cd3c: ret             
    // 0x119cd40: mov             x0, x4
    // 0x119cd44: r0 = ConcurrentModificationError()
    //     0x119cd44: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x119cd48: mov             x1, x0
    // 0x119cd4c: ldur            x0, [fp, #-0x28]
    // 0x119cd50: StoreField: r1->field_b = r0
    //     0x119cd50: stur            w0, [x1, #0xb]
    // 0x119cd54: mov             x0, x1
    // 0x119cd58: r0 = Throw()
    //     0x119cd58: bl              #0x13ddb2c  ; ThrowStub
    // 0x119cd5c: brk             #0
    // 0x119cd60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119cd60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119cd64: b               #0x119cbd4
    // 0x119cd68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x119cd68: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x119cd6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119cd6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119cd70: b               #0x119cc88
    // 0x119cd74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119cd74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x12fee50, size: 0x13c
    // 0x12fee50: EnterFrame
    //     0x12fee50: stp             fp, lr, [SP, #-0x10]!
    //     0x12fee54: mov             fp, SP
    // 0x12fee58: AllocStack(0x20)
    //     0x12fee58: sub             SP, SP, #0x20
    // 0x12fee5c: SetupParameters(_CombiningGestureArenaMember this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12fee5c: mov             x4, x1
    //     0x12fee60: mov             x0, x2
    //     0x12fee64: stur            x1, [fp, #-0x10]
    //     0x12fee68: stur            x2, [fp, #-0x18]
    //     0x12fee6c: stur            x3, [fp, #-0x20]
    // 0x12fee70: CheckStackOverflow
    //     0x12fee70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fee74: cmp             SP, x16
    //     0x12fee78: b.ls            #0x12fef7c
    // 0x12fee7c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x12fee7c: ldur            w1, [x4, #0x17]
    // 0x12fee80: DecompressPointer r1
    //     0x12fee80: add             x1, x1, HEAP, lsl #32
    // 0x12fee84: tbnz            w1, #4, #0x12fee98
    // 0x12fee88: r0 = Null
    //     0x12fee88: mov             x0, NULL
    // 0x12fee8c: LeaveFrame
    //     0x12fee8c: mov             SP, fp
    //     0x12fee90: ldp             fp, lr, [SP], #0x10
    // 0x12fee94: ret
    //     0x12fee94: ret             
    // 0x12fee98: LoadField: r1 = r3->field_7
    //     0x12fee98: ldur            x1, [x3, #7]
    // 0x12fee9c: cmp             x1, #0
    // 0x12feea0: b.gt            #0x12fef08
    // 0x12feea4: LoadField: r1 = r4->field_1b
    //     0x12feea4: ldur            w1, [x4, #0x1b]
    // 0x12feea8: DecompressPointer r1
    //     0x12feea8: add             x1, x1, HEAP, lsl #32
    // 0x12feeac: cmp             w1, NULL
    // 0x12feeb0: b.ne            #0x12feeec
    // 0x12feeb4: LoadField: r1 = r4->field_7
    //     0x12feeb4: ldur            w1, [x4, #7]
    // 0x12feeb8: DecompressPointer r1
    //     0x12feeb8: add             x1, x1, HEAP, lsl #32
    // 0x12feebc: LoadField: r2 = r1->field_b
    //     0x12feebc: ldur            w2, [x1, #0xb]
    // 0x12feec0: DecompressPointer r2
    //     0x12feec0: add             x2, x2, HEAP, lsl #32
    // 0x12feec4: cmp             w2, NULL
    // 0x12feec8: b.eq            #0x12feed0
    // 0x12feecc: mov             x0, x2
    // 0x12feed0: StoreField: r4->field_1b = r0
    //     0x12feed0: stur            w0, [x4, #0x1b]
    //     0x12feed4: ldurb           w16, [x4, #-1]
    //     0x12feed8: ldurb           w17, [x0, #-1]
    //     0x12feedc: and             x16, x17, x16, lsr #2
    //     0x12feee0: tst             x16, HEAP, lsr #32
    //     0x12feee4: b.eq            #0x12feeec
    //     0x12feee8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x12feeec: LoadField: r1 = r4->field_1f
    //     0x12feeec: ldur            w1, [x4, #0x1f]
    // 0x12feef0: DecompressPointer r1
    //     0x12feef0: add             x1, x1, HEAP, lsl #32
    // 0x12feef4: cmp             w1, NULL
    // 0x12feef8: b.eq            #0x12fef84
    // 0x12feefc: mov             x2, x3
    // 0x12fef00: r0 = resolve()
    //     0x12fef00: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x12fef04: b               #0x12fef6c
    // 0x12fef08: LoadField: r5 = r4->field_b
    //     0x12fef08: ldur            w5, [x4, #0xb]
    // 0x12fef0c: DecompressPointer r5
    //     0x12fef0c: add             x5, x5, HEAP, lsl #32
    // 0x12fef10: mov             x1, x5
    // 0x12fef14: mov             x2, x0
    // 0x12fef18: stur            x5, [fp, #-8]
    // 0x12fef1c: r0 = remove()
    //     0x12fef1c: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0x12fef20: ldur            x3, [fp, #-0x10]
    // 0x12fef24: LoadField: r2 = r3->field_f
    //     0x12fef24: ldur            x2, [x3, #0xf]
    // 0x12fef28: ldur            x1, [fp, #-0x18]
    // 0x12fef2c: r0 = LoadClassIdInstr(r1)
    //     0x12fef2c: ldur            x0, [x1, #-1]
    //     0x12fef30: ubfx            x0, x0, #0xc, #0x14
    // 0x12fef34: r0 = GDT[cid_x0 + 0x4deb]()
    //     0x12fef34: mov             x17, #0x4deb
    //     0x12fef38: add             lr, x0, x17
    //     0x12fef3c: ldr             lr, [x21, lr, lsl #3]
    //     0x12fef40: blr             lr
    // 0x12fef44: ldur            x0, [fp, #-8]
    // 0x12fef48: LoadField: r1 = r0->field_b
    //     0x12fef48: ldur            w1, [x0, #0xb]
    // 0x12fef4c: cbnz            w1, #0x12fef6c
    // 0x12fef50: ldur            x0, [fp, #-0x10]
    // 0x12fef54: LoadField: r1 = r0->field_1f
    //     0x12fef54: ldur            w1, [x0, #0x1f]
    // 0x12fef58: DecompressPointer r1
    //     0x12fef58: add             x1, x1, HEAP, lsl #32
    // 0x12fef5c: cmp             w1, NULL
    // 0x12fef60: b.eq            #0x12fef88
    // 0x12fef64: ldur            x2, [fp, #-0x20]
    // 0x12fef68: r0 = resolve()
    //     0x12fef68: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x12fef6c: r0 = Null
    //     0x12fef6c: mov             x0, NULL
    // 0x12fef70: LeaveFrame
    //     0x12fef70: mov             SP, fp
    //     0x12fef74: ldp             fp, lr, [SP], #0x10
    // 0x12fef78: ret
    //     0x12fef78: ret             
    // 0x12fef7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fef7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fef80: b               #0x12fee7c
    // 0x12fef84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fef84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12fef88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fef88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
