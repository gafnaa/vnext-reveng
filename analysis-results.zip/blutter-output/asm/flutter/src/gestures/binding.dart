// lib: , url: package:flutter/src/gestures/binding.dart

// class id: 1048816, size: 0x8
class :: {
}

// class id: 3180, size: 0x14, field offset: 0x8
class _Resampler extends Object {

  _ stop(/* No info */) {
    // ** addr: 0x836eec, size: 0xd0
    // 0x836eec: EnterFrame
    //     0x836eec: stp             fp, lr, [SP, #-0x10]!
    //     0x836ef0: mov             fp, SP
    // 0x836ef4: AllocStack(0x10)
    //     0x836ef4: sub             SP, SP, #0x10
    // 0x836ef8: CheckStackOverflow
    //     0x836ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836efc: cmp             SP, x16
    //     0x836f00: b.ls            #0x836fac
    // 0x836f04: LoadField: r0 = r1->field_7
    //     0x836f04: ldur            w0, [x1, #7]
    // 0x836f08: DecompressPointer r0
    //     0x836f08: add             x0, x0, HEAP, lsl #32
    // 0x836f0c: stur            x0, [fp, #-8]
    // 0x836f10: r1 = <PointerEventResampler>
    //     0x836f10: ldr             x1, [PP, #0x4348]  ; [pp+0x4348] TypeArguments: <PointerEventResampler>
    // 0x836f14: r0 = _CompactValuesIterable()
    //     0x836f14: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x836f18: mov             x1, x0
    // 0x836f1c: ldur            x0, [fp, #-8]
    // 0x836f20: StoreField: r1->field_b = r0
    //     0x836f20: stur            w0, [x1, #0xb]
    // 0x836f24: r0 = iterator()
    //     0x836f24: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x836f28: stur            x0, [fp, #-0x10]
    // 0x836f2c: CheckStackOverflow
    //     0x836f2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836f30: cmp             SP, x16
    //     0x836f34: b.ls            #0x836fb4
    // 0x836f38: mov             x1, x0
    // 0x836f3c: r0 = moveNext()
    //     0x836f3c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x836f40: tbz             w0, #4, #0x836f5c
    // 0x836f44: ldur            x1, [fp, #-8]
    // 0x836f48: r0 = clear()
    //     0x836f48: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x836f4c: r0 = Null
    //     0x836f4c: mov             x0, NULL
    // 0x836f50: LeaveFrame
    //     0x836f50: mov             SP, fp
    //     0x836f54: ldp             fp, lr, [SP], #0x10
    // 0x836f58: ret
    //     0x836f58: ret             
    // 0x836f5c: ldur            x0, [fp, #-0x10]
    // 0x836f60: LoadField: r1 = r0->field_33
    //     0x836f60: ldur            w1, [x0, #0x33]
    // 0x836f64: DecompressPointer r1
    //     0x836f64: add             x1, x1, HEAP, lsl #32
    // 0x836f68: cmp             w1, NULL
    // 0x836f6c: b.ne            #0x836fa0
    // 0x836f70: LoadField: r2 = r0->field_7
    //     0x836f70: ldur            w2, [x0, #7]
    // 0x836f74: DecompressPointer r2
    //     0x836f74: add             x2, x2, HEAP, lsl #32
    // 0x836f78: mov             x0, x1
    // 0x836f7c: r1 = Null
    //     0x836f7c: mov             x1, NULL
    // 0x836f80: cmp             w2, NULL
    // 0x836f84: b.eq            #0x836fa0
    // 0x836f88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x836f88: ldur            w4, [x2, #0x17]
    // 0x836f8c: DecompressPointer r4
    //     0x836f8c: add             x4, x4, HEAP, lsl #32
    // 0x836f90: r8 = X0
    //     0x836f90: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x836f94: LoadField: r9 = r4->field_7
    //     0x836f94: ldur            x9, [x4, #7]
    // 0x836f98: r3 = Null
    //     0x836f98: ldr             x3, [PP, #0x4350]  ; [pp+0x4350] Null
    // 0x836f9c: blr             x9
    // 0x836fa0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x836fa0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x836fa4: r0 = Throw()
    //     0x836fa4: bl              #0x13ddb2c  ; ThrowStub
    // 0x836fa8: brk             #0
    // 0x836fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836fac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836fb0: b               #0x836f04
    // 0x836fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836fb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836fb8: b               #0x836f38
  }
}

// class id: 3181, size: 0x8, field offset: 0x8
class SamplingClock extends Object {

  _ stopwatch(/* No info */) {
    // ** addr: 0x82ae34, size: 0x60
    // 0x82ae34: EnterFrame
    //     0x82ae34: stp             fp, lr, [SP, #-0x10]!
    //     0x82ae38: mov             fp, SP
    // 0x82ae3c: AllocStack(0x8)
    //     0x82ae3c: sub             SP, SP, #8
    // 0x82ae40: CheckStackOverflow
    //     0x82ae40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ae44: cmp             SP, x16
    //     0x82ae48: b.ls            #0x82ae8c
    // 0x82ae4c: r0 = Stopwatch()
    //     0x82ae4c: bl              #0x82ae94  ; AllocateStopwatchStub -> Stopwatch (size=0x14)
    // 0x82ae50: stur            x0, [fp, #-8]
    // 0x82ae54: StoreField: r0->field_7 = rZR
    //     0x82ae54: stur            xzr, [x0, #7]
    // 0x82ae58: StoreField: r0->field_f = rZR
    //     0x82ae58: stur            wzr, [x0, #0xf]
    // 0x82ae5c: ldr             x0, [THR, #0x80]  ; THR::
    // 0x82ae60: add             x17, x0, #0x60
    // 0x82ae64: ldar            x0, [x17]
    // 0x82ae68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82ae6c: cmp             w0, w16
    // 0x82ae70: b.ne            #0x82ae7c
    // 0x82ae74: r2 = _frequency
    //     0x82ae74: ldr             x2, [PP, #0xb80]  ; [pp+0xb80] Field <Stopwatch._frequency@0150898>: static late final shared (offset: 0x30)
    // 0x82ae78: r0 = InitSharedLateStaticField()
    //     0x82ae78: bl              #0x13dd874  ; InitSharedLateStaticFieldStub
    // 0x82ae7c: ldur            x0, [fp, #-8]
    // 0x82ae80: LeaveFrame
    //     0x82ae80: mov             SP, fp
    //     0x82ae84: ldp             fp, lr, [SP], #0x10
    // 0x82ae88: ret
    //     0x82ae88: ret             
    // 0x82ae8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ae8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ae90: b               #0x82ae4c
  }
}

// class id: 4611, size: 0x10, field offset: 0x10
abstract class GestureBinding extends BindingBase
    implements HitTestable, HitTestDispatcher, HitTestTarget {

  get _ instance(/* No info */) {
    // ** addr: 0x83b818, size: 0x20
    // 0x83b818: r0 = LoadStaticField(0x7d0)
    //     0x83b818: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83b81c: ldr             x0, [x0, #0xfa0]
    // 0x83b820: cmp             w0, NULL
    // 0x83b824: b.eq            #0x83b82c
    // 0x83b828: ret
    //     0x83b828: ret             
    // 0x83b82c: EnterFrame
    //     0x83b82c: stp             fp, lr, [SP, #-0x10]!
    //     0x83b830: mov             fp, SP
    // 0x83b834: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b834: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5233, size: 0x20, field offset: 0x20
//   const constructor, 
class FlutterErrorDetailsForPointerEventDispatcher extends FlutterErrorDetails {
}
