// lib: , url: package:flutter/src/gestures/monodrag.dart

// class id: 1048827, size: 0x8
class :: {
}

// class id: 4441, size: 0x90, field offset: 0x24
abstract class DragGestureRecognizer extends OneSequenceGestureRecognizer {

  late OffsetPair _pendingDragOffset; // offset: 0x5c
  late OffsetPair _initialPosition; // offset: 0x58
  late double _globalDistanceMoved; // offset: 0x70
  late OffsetPair _lastPosition; // offset: 0x60

  _ DragGestureRecognizer(/* No info */) {
    // ** addr: 0xb8d344, size: 0x140
    // 0xb8d344: EnterFrame
    //     0xb8d344: stp             fp, lr, [SP, #-0x10]!
    //     0xb8d348: mov             fp, SP
    // 0xb8d34c: AllocStack(0x20)
    //     0xb8d34c: sub             SP, SP, #0x20
    // 0xb8d350: r5 = Instance__DragState
    //     0xb8d350: add             x5, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!_DragState@12c5ce1
    //     0xb8d354: ldr             x5, [x5, #0x530]
    // 0xb8d358: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xb8d35c: r3 = false
    //     0xb8d35c: add             x3, NULL, #0x30  ; false
    // 0xb8d360: r0 = Instance_Offset
    //     0xb8d360: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb8d364: stur            x1, [fp, #-8]
    // 0xb8d368: stur            x2, [fp, #-0x10]
    // 0xb8d36c: CheckStackOverflow
    //     0xb8d36c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8d370: cmp             SP, x16
    //     0xb8d374: b.ls            #0xb8d47c
    // 0xb8d378: StoreField: r1->field_53 = r5
    //     0xb8d378: stur            w5, [x1, #0x53]
    // 0xb8d37c: StoreField: r1->field_57 = r4
    //     0xb8d37c: stur            w4, [x1, #0x57]
    // 0xb8d380: StoreField: r1->field_5b = r4
    //     0xb8d380: stur            w4, [x1, #0x5b]
    // 0xb8d384: StoreField: r1->field_5f = r4
    //     0xb8d384: stur            w4, [x1, #0x5f]
    // 0xb8d388: StoreField: r1->field_6f = r4
    //     0xb8d388: stur            w4, [x1, #0x6f]
    // 0xb8d38c: StoreField: r1->field_73 = r3
    //     0xb8d38c: stur            w3, [x1, #0x73]
    // 0xb8d390: StoreField: r1->field_83 = r0
    //     0xb8d390: stur            w0, [x1, #0x83]
    // 0xb8d394: r16 = <int, VelocityTracker>
    //     0xb8d394: add             x16, PP, #0x15, lsl #12  ; [pp+0x15538] TypeArguments: <int, VelocityTracker>
    //     0xb8d398: ldr             x16, [x16, #0x538]
    // 0xb8d39c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb8d3a0: stp             lr, x16, [SP]
    // 0xb8d3a4: r0 = Map._fromLiteral()
    //     0xb8d3a4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb8d3a8: ldur            x1, [fp, #-8]
    // 0xb8d3ac: StoreField: r1->field_77 = r0
    //     0xb8d3ac: stur            w0, [x1, #0x77]
    //     0xb8d3b0: ldurb           w16, [x1, #-1]
    //     0xb8d3b4: ldurb           w17, [x0, #-1]
    //     0xb8d3b8: and             x16, x17, x16, lsr #2
    //     0xb8d3bc: tst             x16, HEAP, lsr #32
    //     0xb8d3c0: b.eq            #0xb8d3c8
    //     0xb8d3c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d3c8: r16 = <int, Offset>
    //     0xb8d3c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xb8d3cc: ldr             x16, [x16, #0x540]
    // 0xb8d3d0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb8d3d4: stp             lr, x16, [SP]
    // 0xb8d3d8: r0 = Map._fromLiteral()
    //     0xb8d3d8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb8d3dc: ldur            x3, [fp, #-8]
    // 0xb8d3e0: StoreField: r3->field_7b = r0
    //     0xb8d3e0: stur            w0, [x3, #0x7b]
    //     0xb8d3e4: ldurb           w16, [x3, #-1]
    //     0xb8d3e8: ldurb           w17, [x0, #-1]
    //     0xb8d3ec: and             x16, x17, x16, lsr #2
    //     0xb8d3f0: tst             x16, HEAP, lsr #32
    //     0xb8d3f4: b.eq            #0xb8d3fc
    //     0xb8d3f8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb8d3fc: r1 = <int>
    //     0xb8d3fc: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xb8d400: r2 = 0
    //     0xb8d400: mov             x2, #0
    // 0xb8d404: r0 = _GrowableList()
    //     0xb8d404: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb8d408: ldur            x1, [fp, #-8]
    // 0xb8d40c: StoreField: r1->field_87 = r0
    //     0xb8d40c: stur            w0, [x1, #0x87]
    //     0xb8d410: ldurb           w16, [x1, #-1]
    //     0xb8d414: ldurb           w17, [x0, #-1]
    //     0xb8d418: and             x16, x17, x16, lsr #2
    //     0xb8d41c: tst             x16, HEAP, lsr #32
    //     0xb8d420: b.eq            #0xb8d428
    //     0xb8d424: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8d428: r0 = Instance_DragStartBehavior
    //     0xb8d428: ldr             x0, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xb8d42c: StoreField: r1->field_23 = r0
    //     0xb8d42c: stur            w0, [x1, #0x23]
    // 0xb8d430: r0 = Instance_MultitouchDragStrategy
    //     0xb8d430: add             x0, PP, #0x15, lsl #12  ; [pp+0x15548] Obj!MultitouchDragStrategy@12c5c21
    //     0xb8d434: ldr             x0, [x0, #0x548]
    // 0xb8d438: StoreField: r1->field_27 = r0
    //     0xb8d438: stur            w0, [x1, #0x27]
    // 0xb8d43c: r0 = Closure: (PointerEvent) => VelocityTracker from Function '_defaultBuilder@658099969': static.
    //     0xb8d43c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15550] Closure: (PointerEvent) => VelocityTracker from Function '_defaultBuilder@658099969': static. (0x7f2adaa747a8)
    //     0xb8d440: ldr             x0, [x0, #0x550]
    // 0xb8d444: StoreField: r1->field_4f = r0
    //     0xb8d444: stur            w0, [x1, #0x4f]
    // 0xb8d448: r0 = false
    //     0xb8d448: add             x0, NULL, #0x30  ; false
    // 0xb8d44c: StoreField: r1->field_4b = r0
    //     0xb8d44c: stur            w0, [x1, #0x4b]
    // 0xb8d450: ldur            x16, [fp, #-0x10]
    // 0xb8d454: r30 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@658099969': static.
    //     0xb8d454: add             lr, PP, #0x15, lsl #12  ; [pp+0x15558] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@658099969': static. (0x7f2adaa74790)
    //     0xb8d458: ldr             lr, [lr, #0x558]
    // 0xb8d45c: stp             lr, x16, [SP]
    // 0xb8d460: r4 = const [0, 0x3, 0x2, 0x1, allowedButtonsFilter, 0x2, supportedDevices, 0x1, null]
    //     0xb8d460: add             x4, PP, #0x15, lsl #12  ; [pp+0x15560] List(9) [0, 0x3, 0x2, 0x1, "allowedButtonsFilter", 0x2, "supportedDevices", 0x1, Null]
    //     0xb8d464: ldr             x4, [x4, #0x560]
    // 0xb8d468: r0 = OneSequenceGestureRecognizer()
    //     0xb8d468: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xb8d46c: r0 = Null
    //     0xb8d46c: mov             x0, NULL
    // 0xb8d470: LeaveFrame
    //     0xb8d470: mov             SP, fp
    //     0xb8d474: ldp             fp, lr, [SP], #0x10
    // 0xb8d478: ret
    //     0xb8d478: ret             
    // 0xb8d47c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8d47c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8d480: b               #0xb8d378
  }
  [closure] static bool _defaultButtonAcceptBehavior(dynamic, int) {
    // ** addr: 0xb8d790, size: 0x18
    // 0xb8d790: ldr             x1, [SP]
    // 0xb8d794: cmp             w1, #2
    // 0xb8d798: r16 = true
    //     0xb8d798: add             x16, NULL, #0x20  ; true
    // 0xb8d79c: r17 = false
    //     0xb8d79c: add             x17, NULL, #0x30  ; false
    // 0xb8d7a0: csel            x0, x16, x17, eq
    // 0xb8d7a4: ret
    //     0xb8d7a4: ret             
  }
  [closure] static VelocityTracker _defaultBuilder(dynamic, PointerEvent) {
    // ** addr: 0xb8d7a8, size: 0x30
    // 0xb8d7a8: EnterFrame
    //     0xb8d7a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb8d7ac: mov             fp, SP
    // 0xb8d7b0: CheckStackOverflow
    //     0xb8d7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8d7b4: cmp             SP, x16
    //     0xb8d7b8: b.ls            #0xb8d7d0
    // 0xb8d7bc: ldr             x1, [fp, #0x10]
    // 0xb8d7c0: r0 = _defaultBuilder()
    //     0xb8d7c0: bl              #0xb8d7d8  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_defaultBuilder
    // 0xb8d7c4: LeaveFrame
    //     0xb8d7c4: mov             SP, fp
    //     0xb8d7c8: ldp             fp, lr, [SP], #0x10
    // 0xb8d7cc: ret
    //     0xb8d7cc: ret             
    // 0xb8d7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8d7d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8d7d4: b               #0xb8d7bc
  }
  static _ _defaultBuilder(/* No info */) {
    // ** addr: 0xb8d7d8, size: 0x7c
    // 0xb8d7d8: EnterFrame
    //     0xb8d7d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb8d7dc: mov             fp, SP
    // 0xb8d7e0: AllocStack(0x10)
    //     0xb8d7e0: sub             SP, SP, #0x10
    // 0xb8d7e4: CheckStackOverflow
    //     0xb8d7e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8d7e8: cmp             SP, x16
    //     0xb8d7ec: b.ls            #0xb8d84c
    // 0xb8d7f0: r0 = LoadClassIdInstr(r1)
    //     0xb8d7f0: ldur            x0, [x1, #-1]
    //     0xb8d7f4: ubfx            x0, x0, #0xc, #0x14
    // 0xb8d7f8: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb8d7f8: mov             x17, #0x5e74
    //     0xb8d7fc: movk            x17, #1, lsl #16
    //     0xb8d800: add             lr, x0, x17
    //     0xb8d804: ldr             lr, [x21, lr, lsl #3]
    //     0xb8d808: blr             lr
    // 0xb8d80c: stur            x0, [fp, #-8]
    // 0xb8d810: r0 = VelocityTracker()
    //     0xb8d810: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0xb8d814: stur            x0, [fp, #-0x10]
    // 0xb8d818: StoreField: r0->field_13 = rZR
    //     0xb8d818: stur            xzr, [x0, #0x13]
    // 0xb8d81c: r1 = <_PointAtTime?>
    //     0xb8d81c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0xb8d820: ldr             x1, [x1, #0x568]
    // 0xb8d824: r2 = 40
    //     0xb8d824: mov             x2, #0x28
    // 0xb8d828: r0 = AllocateArray()
    //     0xb8d828: bl              #0x13df928  ; AllocateArrayStub
    // 0xb8d82c: mov             x1, x0
    // 0xb8d830: ldur            x0, [fp, #-0x10]
    // 0xb8d834: StoreField: r0->field_f = r1
    //     0xb8d834: stur            w1, [x0, #0xf]
    // 0xb8d838: ldur            x1, [fp, #-8]
    // 0xb8d83c: StoreField: r0->field_7 = r1
    //     0xb8d83c: stur            w1, [x0, #7]
    // 0xb8d840: LeaveFrame
    //     0xb8d840: mov             SP, fp
    //     0xb8d844: ldp             fp, lr, [SP], #0x10
    // 0xb8d848: ret
    //     0xb8d848: ret             
    // 0xb8d84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8d84c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8d850: b               #0xb8d7f0
  }
  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0xb99074, size: 0xa8
    // 0xb99074: EnterFrame
    //     0xb99074: stp             fp, lr, [SP, #-0x10]!
    //     0xb99078: mov             fp, SP
    // 0xb9907c: AllocStack(0x8)
    //     0xb9907c: sub             SP, SP, #8
    // 0xb99080: SetupParameters(DragGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb99080: mov             x0, x1
    //     0xb99084: stur            x1, [fp, #-8]
    // 0xb99088: CheckStackOverflow
    //     0xb99088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9908c: cmp             SP, x16
    //     0xb99090: b.ls            #0xb99114
    // 0xb99094: LoadField: r1 = r0->field_53
    //     0xb99094: ldur            w1, [x0, #0x53]
    // 0xb99098: DecompressPointer r1
    //     0xb99098: add             x1, x1, HEAP, lsl #32
    // 0xb9909c: LoadField: r3 = r1->field_7
    //     0xb9909c: ldur            x3, [x1, #7]
    // 0xb990a0: cmp             x3, #1
    // 0xb990a4: b.gt            #0xb990d0
    // 0xb990a8: cmp             x3, #0
    // 0xb990ac: b.le            #0xb990dc
    // 0xb990b0: mov             x1, x0
    // 0xb990b4: r2 = Instance_GestureDisposition
    //     0xb990b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb990b8: ldr             x2, [x2, #0x610]
    // 0xb990bc: r0 = resolve()
    //     0xb990bc: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb990c0: ldur            x1, [fp, #-8]
    // 0xb990c4: r0 = _checkCancel()
    //     0xb990c4: bl              #0xb993cc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkCancel
    // 0xb990c8: ldur            x0, [fp, #-8]
    // 0xb990cc: b               #0xb990dc
    // 0xb990d0: ldur            x1, [fp, #-8]
    // 0xb990d4: r0 = _checkEnd()
    //     0xb990d4: bl              #0xb9911c  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkEnd
    // 0xb990d8: ldur            x0, [fp, #-8]
    // 0xb990dc: r1 = false
    //     0xb990dc: add             x1, NULL, #0x30  ; false
    // 0xb990e0: StoreField: r0->field_73 = r1
    //     0xb990e0: stur            w1, [x0, #0x73]
    // 0xb990e4: LoadField: r1 = r0->field_77
    //     0xb990e4: ldur            w1, [x0, #0x77]
    // 0xb990e8: DecompressPointer r1
    //     0xb990e8: add             x1, x1, HEAP, lsl #32
    // 0xb990ec: r0 = clear()
    //     0xb990ec: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xb990f0: ldur            x1, [fp, #-8]
    // 0xb990f4: StoreField: r1->field_67 = rNULL
    //     0xb990f4: stur            NULL, [x1, #0x67]
    // 0xb990f8: r2 = Instance__DragState
    //     0xb990f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!_DragState@12c5ce1
    //     0xb990fc: ldr             x2, [x2, #0x530]
    // 0xb99100: StoreField: r1->field_53 = r2
    //     0xb99100: stur            w2, [x1, #0x53]
    // 0xb99104: r0 = Null
    //     0xb99104: mov             x0, NULL
    // 0xb99108: LeaveFrame
    //     0xb99108: mov             SP, fp
    //     0xb9910c: ldp             fp, lr, [SP], #0x10
    // 0xb99110: ret
    //     0xb99110: ret             
    // 0xb99114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb99114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99118: b               #0xb99094
  }
  _ _checkEnd(/* No info */) {
    // ** addr: 0xb9911c, size: 0x228
    // 0xb9911c: EnterFrame
    //     0xb9911c: stp             fp, lr, [SP, #-0x10]!
    //     0xb99120: mov             fp, SP
    // 0xb99124: AllocStack(0x38)
    //     0xb99124: sub             SP, SP, #0x38
    // 0xb99128: SetupParameters(DragGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb99128: stur            x1, [fp, #-8]
    //     0xb9912c: stur            x2, [fp, #-0x10]
    // 0xb99130: CheckStackOverflow
    //     0xb99130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb99134: cmp             SP, x16
    //     0xb99138: b.ls            #0xb9932c
    // 0xb9913c: r1 = 3
    //     0xb9913c: mov             x1, #3
    // 0xb99140: r0 = AllocateContext()
    //     0xb99140: bl              #0x13de838  ; AllocateContextStub
    // 0xb99144: mov             x4, x0
    // 0xb99148: ldur            x3, [fp, #-8]
    // 0xb9914c: stur            x4, [fp, #-0x20]
    // 0xb99150: StoreField: r4->field_f = r3
    //     0xb99150: stur            w3, [x4, #0xf]
    // 0xb99154: LoadField: r0 = r3->field_37
    //     0xb99154: ldur            w0, [x3, #0x37]
    // 0xb99158: DecompressPointer r0
    //     0xb99158: add             x0, x0, HEAP, lsl #32
    // 0xb9915c: cmp             w0, NULL
    // 0xb99160: b.ne            #0xb99174
    // 0xb99164: r0 = Null
    //     0xb99164: mov             x0, NULL
    // 0xb99168: LeaveFrame
    //     0xb99168: mov             SP, fp
    //     0xb9916c: ldp             fp, lr, [SP], #0x10
    // 0xb99170: ret
    //     0xb99170: ret             
    // 0xb99174: ldur            x2, [fp, #-0x10]
    // 0xb99178: LoadField: r5 = r3->field_77
    //     0xb99178: ldur            w5, [x3, #0x77]
    // 0xb9917c: DecompressPointer r5
    //     0xb9917c: add             x5, x5, HEAP, lsl #32
    // 0xb99180: stur            x5, [fp, #-0x18]
    // 0xb99184: r0 = BoxInt64Instr(r2)
    //     0xb99184: sbfiz           x0, x2, #1, #0x1f
    //     0xb99188: cmp             x2, x0, asr #1
    //     0xb9918c: b.eq            #0xb99198
    //     0xb99190: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb99194: stur            x2, [x0, #7]
    // 0xb99198: mov             x1, x5
    // 0xb9919c: mov             x2, x0
    // 0xb991a0: r0 = _getValueOrData()
    //     0xb991a0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb991a4: mov             x1, x0
    // 0xb991a8: ldur            x0, [fp, #-0x18]
    // 0xb991ac: LoadField: r2 = r0->field_f
    //     0xb991ac: ldur            w2, [x0, #0xf]
    // 0xb991b0: DecompressPointer r2
    //     0xb991b0: add             x2, x2, HEAP, lsl #32
    // 0xb991b4: cmp             w2, w1
    // 0xb991b8: b.ne            #0xb991c4
    // 0xb991bc: r3 = Null
    //     0xb991bc: mov             x3, NULL
    // 0xb991c0: b               #0xb991c8
    // 0xb991c4: mov             x3, x1
    // 0xb991c8: ldur            x2, [fp, #-0x20]
    // 0xb991cc: stur            x3, [fp, #-0x18]
    // 0xb991d0: cmp             w3, NULL
    // 0xb991d4: b.eq            #0xb99334
    // 0xb991d8: r0 = LoadClassIdInstr(r3)
    //     0xb991d8: ldur            x0, [x3, #-1]
    //     0xb991dc: ubfx            x0, x0, #0xc, #0x14
    // 0xb991e0: mov             x1, x3
    // 0xb991e4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xb991e4: sub             lr, x0, #0xff8
    //     0xb991e8: ldr             lr, [x21, lr, lsl #3]
    //     0xb991ec: blr             lr
    // 0xb991f0: mov             x1, x0
    // 0xb991f4: ldur            x4, [fp, #-0x20]
    // 0xb991f8: StoreField: r4->field_13 = r0
    //     0xb991f8: stur            w0, [x4, #0x13]
    //     0xb991fc: ldurb           w16, [x4, #-1]
    //     0xb99200: ldurb           w17, [x0, #-1]
    //     0xb99204: and             x16, x17, x16, lsr #2
    //     0xb99208: tst             x16, HEAP, lsr #32
    //     0xb9920c: b.eq            #0xb99214
    //     0xb99210: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xb99214: ArrayStore: r4[0] = rNULL  ; List_4
    //     0xb99214: stur            NULL, [x4, #0x17]
    // 0xb99218: cmp             w1, NULL
    // 0xb9921c: b.ne            #0xb9922c
    // 0xb99220: mov             x2, x4
    // 0xb99224: r0 = Null
    //     0xb99224: mov             x0, NULL
    // 0xb99228: b               #0xb99284
    // 0xb9922c: ldur            x5, [fp, #-8]
    // 0xb99230: ldur            x0, [fp, #-0x18]
    // 0xb99234: LoadField: r3 = r0->field_7
    //     0xb99234: ldur            w3, [x0, #7]
    // 0xb99238: DecompressPointer r3
    //     0xb99238: add             x3, x3, HEAP, lsl #32
    // 0xb9923c: r0 = LoadClassIdInstr(r5)
    //     0xb9923c: ldur            x0, [x5, #-1]
    //     0xb99240: ubfx            x0, x0, #0xc, #0x14
    // 0xb99244: mov             x2, x1
    // 0xb99248: mov             x1, x5
    // 0xb9924c: r0 = GDT[cid_x0 + 0x2809]()
    //     0xb9924c: mov             x17, #0x2809
    //     0xb99250: add             lr, x0, x17
    //     0xb99254: ldr             lr, [x21, lr, lsl #3]
    //     0xb99258: blr             lr
    // 0xb9925c: mov             x1, x0
    // 0xb99260: ldur            x2, [fp, #-0x20]
    // 0xb99264: ArrayStore: r2[0] = r0  ; List_4
    //     0xb99264: stur            w0, [x2, #0x17]
    //     0xb99268: ldurb           w16, [x2, #-1]
    //     0xb9926c: ldurb           w17, [x0, #-1]
    //     0xb99270: and             x16, x17, x16, lsr #2
    //     0xb99274: tst             x16, HEAP, lsr #32
    //     0xb99278: b.eq            #0xb99280
    //     0xb9927c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb99280: mov             x0, x1
    // 0xb99284: cmp             w0, NULL
    // 0xb99288: b.ne            #0xb992f8
    // 0xb9928c: ldur            x0, [fp, #-8]
    // 0xb99290: LoadField: r1 = r0->field_5f
    //     0xb99290: ldur            w1, [x0, #0x5f]
    // 0xb99294: DecompressPointer r1
    //     0xb99294: add             x1, x1, HEAP, lsl #32
    // 0xb99298: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9929c: cmp             w1, w16
    // 0xb992a0: b.eq            #0xb99338
    // 0xb992a4: LoadField: r3 = r1->field_b
    //     0xb992a4: ldur            w3, [x1, #0xb]
    // 0xb992a8: DecompressPointer r3
    //     0xb992a8: add             x3, x3, HEAP, lsl #32
    // 0xb992ac: stur            x3, [fp, #-0x18]
    // 0xb992b0: r0 = DragEndDetails()
    //     0xb992b0: bl              #0xb99344  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x14)
    // 0xb992b4: mov             x1, x0
    // 0xb992b8: ldur            x0, [fp, #-0x18]
    // 0xb992bc: StoreField: r1->field_7 = r0
    //     0xb992bc: stur            w0, [x1, #7]
    // 0xb992c0: r0 = Instance_Velocity
    //     0xb992c0: add             x0, PP, #0x80, lsl #12  ; [pp+0x80bb8] Obj!Velocity@129f141
    //     0xb992c4: ldr             x0, [x0, #0xbb8]
    // 0xb992c8: StoreField: r1->field_b = r0
    //     0xb992c8: stur            w0, [x1, #0xb]
    // 0xb992cc: r0 = 0.000000
    //     0xb992cc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb992d0: StoreField: r1->field_f = r0
    //     0xb992d0: stur            w0, [x1, #0xf]
    // 0xb992d4: mov             x0, x1
    // 0xb992d8: ldur            x2, [fp, #-0x20]
    // 0xb992dc: ArrayStore: r2[0] = r0  ; List_4
    //     0xb992dc: stur            w0, [x2, #0x17]
    //     0xb992e0: ldurb           w16, [x2, #-1]
    //     0xb992e4: ldurb           w17, [x0, #-1]
    //     0xb992e8: and             x16, x17, x16, lsr #2
    //     0xb992ec: tst             x16, HEAP, lsr #32
    //     0xb992f0: b.eq            #0xb992f8
    //     0xb992f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb992f8: r1 = Function '<anonymous closure>':.
    //     0xb992f8: add             x1, PP, #0x80, lsl #12  ; [pp+0x80bc0] AnonymousClosure: (0xb99350), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkEnd (0xb9911c)
    //     0xb992fc: ldr             x1, [x1, #0xbc0]
    // 0xb99300: r0 = AllocateClosure()
    //     0xb99300: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb99304: r16 = <void?>
    //     0xb99304: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb99308: ldur            lr, [fp, #-8]
    // 0xb9930c: stp             lr, x16, [SP, #8]
    // 0xb99310: str             x0, [SP]
    // 0xb99314: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb99314: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb99318: r0 = invokeCallback()
    //     0xb99318: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb9931c: r0 = Null
    //     0xb9931c: mov             x0, NULL
    // 0xb99320: LeaveFrame
    //     0xb99320: mov             SP, fp
    //     0xb99324: ldp             fp, lr, [SP], #0x10
    // 0xb99328: ret
    //     0xb99328: ret             
    // 0xb9932c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9932c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99330: b               #0xb9913c
    // 0xb99334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb99334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb99338: r9 = _lastPosition
    //     0xb99338: add             x9, PP, #0x80, lsl #12  ; [pp+0x80bc8] Field <DragGestureRecognizer._lastPosition@658099969>: late (offset: 0x60)
    //     0xb9933c: ldr             x9, [x9, #0xbc8]
    // 0xb99340: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb99340: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb99350, size: 0x7c
    // 0xb99350: EnterFrame
    //     0xb99350: stp             fp, lr, [SP, #-0x10]!
    //     0xb99354: mov             fp, SP
    // 0xb99358: AllocStack(0x10)
    //     0xb99358: sub             SP, SP, #0x10
    // 0xb9935c: SetupParameters([dynamic _ /* r0 */])
    //     0xb9935c: ldr             x0, [fp, #0x10]
    //     0xb99360: ldur            w1, [x0, #0x17]
    //     0xb99364: add             x1, x1, HEAP, lsl #32
    // 0xb99368: CheckStackOverflow
    //     0xb99368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9936c: cmp             SP, x16
    //     0xb99370: b.ls            #0xb993bc
    // 0xb99374: LoadField: r0 = r1->field_f
    //     0xb99374: ldur            w0, [x1, #0xf]
    // 0xb99378: DecompressPointer r0
    //     0xb99378: add             x0, x0, HEAP, lsl #32
    // 0xb9937c: LoadField: r2 = r0->field_37
    //     0xb9937c: ldur            w2, [x0, #0x37]
    // 0xb99380: DecompressPointer r2
    //     0xb99380: add             x2, x2, HEAP, lsl #32
    // 0xb99384: cmp             w2, NULL
    // 0xb99388: b.eq            #0xb993c4
    // 0xb9938c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb9938c: ldur            w0, [x1, #0x17]
    // 0xb99390: DecompressPointer r0
    //     0xb99390: add             x0, x0, HEAP, lsl #32
    // 0xb99394: cmp             w0, NULL
    // 0xb99398: b.eq            #0xb993c8
    // 0xb9939c: stp             x0, x2, [SP]
    // 0xb993a0: mov             x0, x2
    // 0xb993a4: ClosureCall
    //     0xb993a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb993a8: ldur            x2, [x0, #0x1f]
    //     0xb993ac: blr             x2
    // 0xb993b0: LeaveFrame
    //     0xb993b0: mov             SP, fp
    //     0xb993b4: ldp             fp, lr, [SP], #0x10
    // 0xb993b8: ret
    //     0xb993b8: ret             
    // 0xb993bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb993bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb993c0: b               #0xb99374
    // 0xb993c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb993c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb993c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb993c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0xb993cc, size: 0x54
    // 0xb993cc: EnterFrame
    //     0xb993cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb993d0: mov             fp, SP
    // 0xb993d4: AllocStack(0x18)
    //     0xb993d4: sub             SP, SP, #0x18
    // 0xb993d8: CheckStackOverflow
    //     0xb993d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb993dc: cmp             SP, x16
    //     0xb993e0: b.ls            #0xb99418
    // 0xb993e4: LoadField: r0 = r1->field_3b
    //     0xb993e4: ldur            w0, [x1, #0x3b]
    // 0xb993e8: DecompressPointer r0
    //     0xb993e8: add             x0, x0, HEAP, lsl #32
    // 0xb993ec: cmp             w0, NULL
    // 0xb993f0: b.eq            #0xb99408
    // 0xb993f4: r16 = <void?>
    //     0xb993f4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb993f8: stp             x1, x16, [SP, #8]
    // 0xb993fc: str             x0, [SP]
    // 0xb99400: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb99400: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb99404: r0 = invokeCallback()
    //     0xb99404: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb99408: r0 = Null
    //     0xb99408: mov             x0, NULL
    // 0xb9940c: LeaveFrame
    //     0xb9940c: mov             SP, fp
    //     0xb99410: ldp             fp, lr, [SP], #0x10
    // 0xb99414: ret
    //     0xb99414: ret             
    // 0xb99418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb99418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9941c: b               #0xb993e4
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xb9d2a4, size: 0xf54
    // 0xb9d2a4: EnterFrame
    //     0xb9d2a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb9d2a8: mov             fp, SP
    // 0xb9d2ac: AllocStack(0x50)
    //     0xb9d2ac: sub             SP, SP, #0x50
    // 0xb9d2b0: SetupParameters(DragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb9d2b0: mov             x3, x1
    //     0xb9d2b4: stur            x1, [fp, #-8]
    //     0xb9d2b8: stur            x2, [fp, #-0x10]
    // 0xb9d2bc: CheckStackOverflow
    //     0xb9d2bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9d2c0: cmp             SP, x16
    //     0xb9d2c4: b.ls            #0xb9e1b8
    // 0xb9d2c8: r0 = LoadClassIdInstr(r2)
    //     0xb9d2c8: ldur            x0, [x2, #-1]
    //     0xb9d2cc: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d2d0: mov             x1, x2
    // 0xb9d2d4: r0 = GDT[cid_x0 + 0x15474]()
    //     0xb9d2d4: mov             x17, #0x5474
    //     0xb9d2d8: movk            x17, #1, lsl #16
    //     0xb9d2dc: add             lr, x0, x17
    //     0xb9d2e0: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d2e4: blr             lr
    // 0xb9d2e8: tbz             w0, #4, #0xb9d5c0
    // 0xb9d2ec: ldur            x0, [fp, #-0x10]
    // 0xb9d2f0: r2 = Null
    //     0xb9d2f0: mov             x2, NULL
    // 0xb9d2f4: r1 = Null
    //     0xb9d2f4: mov             x1, NULL
    // 0xb9d2f8: cmp             w0, NULL
    // 0xb9d2fc: b.eq            #0xb9d324
    // 0xb9d300: branchIfSmi(r0, 0xb9d324)
    //     0xb9d300: tbz             w0, #0, #0xb9d324
    // 0xb9d304: r3 = LoadClassIdInstr(r0)
    //     0xb9d304: ldur            x3, [x0, #-1]
    //     0xb9d308: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d30c: r17 = 4159
    //     0xb9d30c: mov             x17, #0x103f
    // 0xb9d310: cmp             x3, x17
    // 0xb9d314: b.eq            #0xb9d32c
    // 0xb9d318: r17 = 5288
    //     0xb9d318: mov             x17, #0x14a8
    // 0xb9d31c: cmp             x3, x17
    // 0xb9d320: b.eq            #0xb9d32c
    // 0xb9d324: r0 = false
    //     0xb9d324: add             x0, NULL, #0x30  ; false
    // 0xb9d328: b               #0xb9d330
    // 0xb9d32c: r0 = true
    //     0xb9d32c: add             x0, NULL, #0x20  ; true
    // 0xb9d330: tbz             w0, #4, #0xb9d40c
    // 0xb9d334: ldur            x0, [fp, #-0x10]
    // 0xb9d338: r2 = Null
    //     0xb9d338: mov             x2, NULL
    // 0xb9d33c: r1 = Null
    //     0xb9d33c: mov             x1, NULL
    // 0xb9d340: cmp             w0, NULL
    // 0xb9d344: b.eq            #0xb9d36c
    // 0xb9d348: branchIfSmi(r0, 0xb9d36c)
    //     0xb9d348: tbz             w0, #0, #0xb9d36c
    // 0xb9d34c: r3 = LoadClassIdInstr(r0)
    //     0xb9d34c: ldur            x3, [x0, #-1]
    //     0xb9d350: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d354: r17 = 4157
    //     0xb9d354: mov             x17, #0x103d
    // 0xb9d358: cmp             x3, x17
    // 0xb9d35c: b.eq            #0xb9d374
    // 0xb9d360: r17 = 5286
    //     0xb9d360: mov             x17, #0x14a6
    // 0xb9d364: cmp             x3, x17
    // 0xb9d368: b.eq            #0xb9d374
    // 0xb9d36c: r0 = false
    //     0xb9d36c: add             x0, NULL, #0x30  ; false
    // 0xb9d370: b               #0xb9d378
    // 0xb9d374: r0 = true
    //     0xb9d374: add             x0, NULL, #0x20  ; true
    // 0xb9d378: tbz             w0, #4, #0xb9d40c
    // 0xb9d37c: ldur            x0, [fp, #-0x10]
    // 0xb9d380: r2 = Null
    //     0xb9d380: mov             x2, NULL
    // 0xb9d384: r1 = Null
    //     0xb9d384: mov             x1, NULL
    // 0xb9d388: cmp             w0, NULL
    // 0xb9d38c: b.eq            #0xb9d3b4
    // 0xb9d390: branchIfSmi(r0, 0xb9d3b4)
    //     0xb9d390: tbz             w0, #0, #0xb9d3b4
    // 0xb9d394: r3 = LoadClassIdInstr(r0)
    //     0xb9d394: ldur            x3, [x0, #-1]
    //     0xb9d398: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d39c: r17 = 4145
    //     0xb9d39c: mov             x17, #0x1031
    // 0xb9d3a0: cmp             x3, x17
    // 0xb9d3a4: b.eq            #0xb9d3bc
    // 0xb9d3a8: r17 = 5282
    //     0xb9d3a8: mov             x17, #0x14a2
    // 0xb9d3ac: cmp             x3, x17
    // 0xb9d3b0: b.eq            #0xb9d3bc
    // 0xb9d3b4: r0 = false
    //     0xb9d3b4: add             x0, NULL, #0x30  ; false
    // 0xb9d3b8: b               #0xb9d3c0
    // 0xb9d3bc: r0 = true
    //     0xb9d3bc: add             x0, NULL, #0x20  ; true
    // 0xb9d3c0: tbz             w0, #4, #0xb9d40c
    // 0xb9d3c4: ldur            x0, [fp, #-0x10]
    // 0xb9d3c8: r2 = Null
    //     0xb9d3c8: mov             x2, NULL
    // 0xb9d3cc: r1 = Null
    //     0xb9d3cc: mov             x1, NULL
    // 0xb9d3d0: cmp             w0, NULL
    // 0xb9d3d4: b.eq            #0xb9d3fc
    // 0xb9d3d8: branchIfSmi(r0, 0xb9d3fc)
    //     0xb9d3d8: tbz             w0, #0, #0xb9d3fc
    // 0xb9d3dc: r3 = LoadClassIdInstr(r0)
    //     0xb9d3dc: ldur            x3, [x0, #-1]
    //     0xb9d3e0: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d3e4: r17 = 4143
    //     0xb9d3e4: mov             x17, #0x102f
    // 0xb9d3e8: cmp             x3, x17
    // 0xb9d3ec: b.eq            #0xb9d404
    // 0xb9d3f0: r17 = 5280
    //     0xb9d3f0: mov             x17, #0x14a0
    // 0xb9d3f4: cmp             x3, x17
    // 0xb9d3f8: b.eq            #0xb9d404
    // 0xb9d3fc: r0 = false
    //     0xb9d3fc: add             x0, NULL, #0x30  ; false
    // 0xb9d400: b               #0xb9d408
    // 0xb9d404: r0 = true
    //     0xb9d404: add             x0, NULL, #0x20  ; true
    // 0xb9d408: tbnz            w0, #4, #0xb9d5c0
    // 0xb9d40c: ldur            x0, [fp, #-0x10]
    // 0xb9d410: r2 = Null
    //     0xb9d410: mov             x2, NULL
    // 0xb9d414: r1 = Null
    //     0xb9d414: mov             x1, NULL
    // 0xb9d418: cmp             w0, NULL
    // 0xb9d41c: b.eq            #0xb9d444
    // 0xb9d420: branchIfSmi(r0, 0xb9d444)
    //     0xb9d420: tbz             w0, #0, #0xb9d444
    // 0xb9d424: r3 = LoadClassIdInstr(r0)
    //     0xb9d424: ldur            x3, [x0, #-1]
    //     0xb9d428: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d42c: r17 = 4145
    //     0xb9d42c: mov             x17, #0x1031
    // 0xb9d430: cmp             x3, x17
    // 0xb9d434: b.eq            #0xb9d44c
    // 0xb9d438: r17 = 5282
    //     0xb9d438: mov             x17, #0x14a2
    // 0xb9d43c: cmp             x3, x17
    // 0xb9d440: b.eq            #0xb9d44c
    // 0xb9d444: r0 = false
    //     0xb9d444: add             x0, NULL, #0x30  ; false
    // 0xb9d448: b               #0xb9d450
    // 0xb9d44c: r0 = true
    //     0xb9d44c: add             x0, NULL, #0x20  ; true
    // 0xb9d450: tbnz            w0, #4, #0xb9d45c
    // 0xb9d454: r4 = Instance_Offset
    //     0xb9d454: ldr             x4, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9d458: b               #0xb9d4f0
    // 0xb9d45c: ldur            x0, [fp, #-0x10]
    // 0xb9d460: r2 = Null
    //     0xb9d460: mov             x2, NULL
    // 0xb9d464: r1 = Null
    //     0xb9d464: mov             x1, NULL
    // 0xb9d468: cmp             w0, NULL
    // 0xb9d46c: b.eq            #0xb9d494
    // 0xb9d470: branchIfSmi(r0, 0xb9d494)
    //     0xb9d470: tbz             w0, #0, #0xb9d494
    // 0xb9d474: r3 = LoadClassIdInstr(r0)
    //     0xb9d474: ldur            x3, [x0, #-1]
    //     0xb9d478: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d47c: r17 = 4143
    //     0xb9d47c: mov             x17, #0x102f
    // 0xb9d480: cmp             x3, x17
    // 0xb9d484: b.eq            #0xb9d49c
    // 0xb9d488: r17 = 5280
    //     0xb9d488: mov             x17, #0x14a0
    // 0xb9d48c: cmp             x3, x17
    // 0xb9d490: b.eq            #0xb9d49c
    // 0xb9d494: r0 = false
    //     0xb9d494: add             x0, NULL, #0x30  ; false
    // 0xb9d498: b               #0xb9d4a0
    // 0xb9d49c: r0 = true
    //     0xb9d49c: add             x0, NULL, #0x20  ; true
    // 0xb9d4a0: tbnz            w0, #4, #0xb9d4c8
    // 0xb9d4a4: ldur            x2, [fp, #-0x10]
    // 0xb9d4a8: r0 = LoadClassIdInstr(r2)
    //     0xb9d4a8: ldur            x0, [x2, #-1]
    //     0xb9d4ac: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d4b0: mov             x1, x2
    // 0xb9d4b4: r0 = GDT[cid_x0 + -0xff5]()
    //     0xb9d4b4: sub             lr, x0, #0xff5
    //     0xb9d4b8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d4bc: blr             lr
    // 0xb9d4c0: mov             x4, x0
    // 0xb9d4c4: b               #0xb9d4f0
    // 0xb9d4c8: ldur            x2, [fp, #-0x10]
    // 0xb9d4cc: r0 = LoadClassIdInstr(r2)
    //     0xb9d4cc: ldur            x0, [x2, #-1]
    //     0xb9d4d0: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d4d4: mov             x1, x2
    // 0xb9d4d8: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb9d4d8: mov             x17, #0x54ea
    //     0xb9d4dc: movk            x17, #1, lsl #16
    //     0xb9d4e0: add             lr, x0, x17
    //     0xb9d4e4: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d4e8: blr             lr
    // 0xb9d4ec: mov             x4, x0
    // 0xb9d4f0: ldur            x3, [fp, #-8]
    // 0xb9d4f4: ldur            x2, [fp, #-0x10]
    // 0xb9d4f8: stur            x4, [fp, #-0x20]
    // 0xb9d4fc: LoadField: r5 = r3->field_77
    //     0xb9d4fc: ldur            w5, [x3, #0x77]
    // 0xb9d500: DecompressPointer r5
    //     0xb9d500: add             x5, x5, HEAP, lsl #32
    // 0xb9d504: stur            x5, [fp, #-0x18]
    // 0xb9d508: r0 = LoadClassIdInstr(r2)
    //     0xb9d508: ldur            x0, [x2, #-1]
    //     0xb9d50c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d510: mov             x1, x2
    // 0xb9d514: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9d514: sub             lr, x0, #1
    //     0xb9d518: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d51c: blr             lr
    // 0xb9d520: mov             x2, x0
    // 0xb9d524: r0 = BoxInt64Instr(r2)
    //     0xb9d524: sbfiz           x0, x2, #1, #0x1f
    //     0xb9d528: cmp             x2, x0, asr #1
    //     0xb9d52c: b.eq            #0xb9d538
    //     0xb9d530: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9d534: stur            x2, [x0, #7]
    // 0xb9d538: ldur            x1, [fp, #-0x18]
    // 0xb9d53c: mov             x2, x0
    // 0xb9d540: r0 = _getValueOrData()
    //     0xb9d540: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb9d544: mov             x1, x0
    // 0xb9d548: ldur            x0, [fp, #-0x18]
    // 0xb9d54c: LoadField: r2 = r0->field_f
    //     0xb9d54c: ldur            w2, [x0, #0xf]
    // 0xb9d550: DecompressPointer r2
    //     0xb9d550: add             x2, x2, HEAP, lsl #32
    // 0xb9d554: cmp             w2, w1
    // 0xb9d558: b.ne            #0xb9d564
    // 0xb9d55c: r3 = Null
    //     0xb9d55c: mov             x3, NULL
    // 0xb9d560: b               #0xb9d568
    // 0xb9d564: mov             x3, x1
    // 0xb9d568: ldur            x2, [fp, #-0x10]
    // 0xb9d56c: stur            x3, [fp, #-0x18]
    // 0xb9d570: cmp             w3, NULL
    // 0xb9d574: b.eq            #0xb9e1c0
    // 0xb9d578: r0 = LoadClassIdInstr(r2)
    //     0xb9d578: ldur            x0, [x2, #-1]
    //     0xb9d57c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d580: mov             x1, x2
    // 0xb9d584: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xb9d584: mov             x17, #0x5eb5
    //     0xb9d588: movk            x17, #1, lsl #16
    //     0xb9d58c: add             lr, x0, x17
    //     0xb9d590: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d594: blr             lr
    // 0xb9d598: ldur            x1, [fp, #-0x18]
    // 0xb9d59c: r2 = LoadClassIdInstr(r1)
    //     0xb9d59c: ldur            x2, [x1, #-1]
    //     0xb9d5a0: ubfx            x2, x2, #0xc, #0x14
    // 0xb9d5a4: mov             x16, x0
    // 0xb9d5a8: mov             x0, x2
    // 0xb9d5ac: mov             x2, x16
    // 0xb9d5b0: ldur            x3, [fp, #-0x20]
    // 0xb9d5b4: r0 = GDT[cid_x0 + -0xffc]()
    //     0xb9d5b4: sub             lr, x0, #0xffc
    //     0xb9d5b8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d5bc: blr             lr
    // 0xb9d5c0: ldur            x0, [fp, #-0x10]
    // 0xb9d5c4: r2 = Null
    //     0xb9d5c4: mov             x2, NULL
    // 0xb9d5c8: r1 = Null
    //     0xb9d5c8: mov             x1, NULL
    // 0xb9d5cc: cmp             w0, NULL
    // 0xb9d5d0: b.eq            #0xb9d5f8
    // 0xb9d5d4: branchIfSmi(r0, 0xb9d5f8)
    //     0xb9d5d4: tbz             w0, #0, #0xb9d5f8
    // 0xb9d5d8: r3 = LoadClassIdInstr(r0)
    //     0xb9d5d8: ldur            x3, [x0, #-1]
    //     0xb9d5dc: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d5e0: r17 = 4157
    //     0xb9d5e0: mov             x17, #0x103d
    // 0xb9d5e4: cmp             x3, x17
    // 0xb9d5e8: b.eq            #0xb9d600
    // 0xb9d5ec: r17 = 5286
    //     0xb9d5ec: mov             x17, #0x14a6
    // 0xb9d5f0: cmp             x3, x17
    // 0xb9d5f4: b.eq            #0xb9d600
    // 0xb9d5f8: r0 = false
    //     0xb9d5f8: add             x0, NULL, #0x30  ; false
    // 0xb9d5fc: b               #0xb9d604
    // 0xb9d600: r0 = true
    //     0xb9d600: add             x0, NULL, #0x20  ; true
    // 0xb9d604: tbnz            w0, #4, #0xb9d6d4
    // 0xb9d608: ldur            x3, [fp, #-8]
    // 0xb9d60c: ldur            x2, [fp, #-0x10]
    // 0xb9d610: r0 = LoadClassIdInstr(r2)
    //     0xb9d610: ldur            x0, [x2, #-1]
    //     0xb9d614: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d618: mov             x1, x2
    // 0xb9d61c: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xb9d61c: mov             x17, #0x6f9c
    //     0xb9d620: movk            x17, #1, lsl #16
    //     0xb9d624: add             lr, x0, x17
    //     0xb9d628: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d62c: blr             lr
    // 0xb9d630: mov             x3, x0
    // 0xb9d634: ldur            x2, [fp, #-8]
    // 0xb9d638: LoadField: r4 = r2->field_67
    //     0xb9d638: ldur            w4, [x2, #0x67]
    // 0xb9d63c: DecompressPointer r4
    //     0xb9d63c: add             x4, x4, HEAP, lsl #32
    // 0xb9d640: r0 = BoxInt64Instr(r3)
    //     0xb9d640: sbfiz           x0, x3, #1, #0x1f
    //     0xb9d644: cmp             x3, x0, asr #1
    //     0xb9d648: b.eq            #0xb9d654
    //     0xb9d64c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9d650: stur            x3, [x0, #7]
    // 0xb9d654: cmp             w0, w4
    // 0xb9d658: b.eq            #0xb9d6cc
    // 0xb9d65c: and             w16, w0, w4
    // 0xb9d660: branchIfSmi(r16, 0xb9d694)
    //     0xb9d660: tbz             w16, #0, #0xb9d694
    // 0xb9d664: r16 = LoadClassIdInstr(r0)
    //     0xb9d664: ldur            x16, [x0, #-1]
    //     0xb9d668: ubfx            x16, x16, #0xc, #0x14
    // 0xb9d66c: cmp             x16, #0x3d
    // 0xb9d670: b.ne            #0xb9d694
    // 0xb9d674: r16 = LoadClassIdInstr(r4)
    //     0xb9d674: ldur            x16, [x4, #-1]
    //     0xb9d678: ubfx            x16, x16, #0xc, #0x14
    // 0xb9d67c: cmp             x16, #0x3d
    // 0xb9d680: b.ne            #0xb9d694
    // 0xb9d684: LoadField: r16 = r0->field_7
    //     0xb9d684: ldur            x16, [x0, #7]
    // 0xb9d688: LoadField: r17 = r4->field_7
    //     0xb9d688: ldur            x17, [x4, #7]
    // 0xb9d68c: cmp             x16, x17
    // 0xb9d690: b.eq            #0xb9d6cc
    // 0xb9d694: ldur            x3, [fp, #-0x10]
    // 0xb9d698: r0 = LoadClassIdInstr(r3)
    //     0xb9d698: ldur            x0, [x3, #-1]
    //     0xb9d69c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d6a0: mov             x1, x3
    // 0xb9d6a4: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9d6a4: sub             lr, x0, #1
    //     0xb9d6a8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d6ac: blr             lr
    // 0xb9d6b0: ldur            x1, [fp, #-8]
    // 0xb9d6b4: mov             x2, x0
    // 0xb9d6b8: r0 = _giveUpPointer()
    //     0xb9d6b8: bl              #0xb9f334  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0xb9d6bc: r0 = Null
    //     0xb9d6bc: mov             x0, NULL
    // 0xb9d6c0: LeaveFrame
    //     0xb9d6c0: mov             SP, fp
    //     0xb9d6c4: ldp             fp, lr, [SP], #0x10
    // 0xb9d6c8: ret
    //     0xb9d6c8: ret             
    // 0xb9d6cc: ldur            x3, [fp, #-0x10]
    // 0xb9d6d0: b               #0xb9d6d8
    // 0xb9d6d4: ldur            x3, [fp, #-0x10]
    // 0xb9d6d8: mov             x0, x3
    // 0xb9d6dc: r2 = Null
    //     0xb9d6dc: mov             x2, NULL
    // 0xb9d6e0: r1 = Null
    //     0xb9d6e0: mov             x1, NULL
    // 0xb9d6e4: cmp             w0, NULL
    // 0xb9d6e8: b.eq            #0xb9d710
    // 0xb9d6ec: branchIfSmi(r0, 0xb9d710)
    //     0xb9d6ec: tbz             w0, #0, #0xb9d710
    // 0xb9d6f0: r3 = LoadClassIdInstr(r0)
    //     0xb9d6f0: ldur            x3, [x0, #-1]
    //     0xb9d6f4: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d6f8: r17 = 4157
    //     0xb9d6f8: mov             x17, #0x103d
    // 0xb9d6fc: cmp             x3, x17
    // 0xb9d700: b.eq            #0xb9d718
    // 0xb9d704: r17 = 5286
    //     0xb9d704: mov             x17, #0x14a6
    // 0xb9d708: cmp             x3, x17
    // 0xb9d70c: b.eq            #0xb9d718
    // 0xb9d710: r0 = false
    //     0xb9d710: add             x0, NULL, #0x30  ; false
    // 0xb9d714: b               #0xb9d71c
    // 0xb9d718: r0 = true
    //     0xb9d718: add             x0, NULL, #0x20  ; true
    // 0xb9d71c: tbz             w0, #4, #0xb9d768
    // 0xb9d720: ldur            x0, [fp, #-0x10]
    // 0xb9d724: r2 = Null
    //     0xb9d724: mov             x2, NULL
    // 0xb9d728: r1 = Null
    //     0xb9d728: mov             x1, NULL
    // 0xb9d72c: cmp             w0, NULL
    // 0xb9d730: b.eq            #0xb9d758
    // 0xb9d734: branchIfSmi(r0, 0xb9d758)
    //     0xb9d734: tbz             w0, #0, #0xb9d758
    // 0xb9d738: r3 = LoadClassIdInstr(r0)
    //     0xb9d738: ldur            x3, [x0, #-1]
    //     0xb9d73c: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d740: r17 = 4143
    //     0xb9d740: mov             x17, #0x102f
    // 0xb9d744: cmp             x3, x17
    // 0xb9d748: b.eq            #0xb9d760
    // 0xb9d74c: r17 = 5280
    //     0xb9d74c: mov             x17, #0x14a0
    // 0xb9d750: cmp             x3, x17
    // 0xb9d754: b.eq            #0xb9d760
    // 0xb9d758: r0 = false
    //     0xb9d758: add             x0, NULL, #0x30  ; false
    // 0xb9d75c: b               #0xb9d764
    // 0xb9d760: r0 = true
    //     0xb9d760: add             x0, NULL, #0x20  ; true
    // 0xb9d764: tbnz            w0, #4, #0xb9e0ac
    // 0xb9d768: ldur            x3, [fp, #-8]
    // 0xb9d76c: ldur            x2, [fp, #-0x10]
    // 0xb9d770: r0 = LoadClassIdInstr(r2)
    //     0xb9d770: ldur            x0, [x2, #-1]
    //     0xb9d774: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d778: mov             x1, x2
    // 0xb9d77c: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9d77c: sub             lr, x0, #1
    //     0xb9d780: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d784: blr             lr
    // 0xb9d788: ldur            x3, [fp, #-8]
    // 0xb9d78c: LoadField: r1 = r3->field_27
    //     0xb9d78c: ldur            w1, [x3, #0x27]
    // 0xb9d790: DecompressPointer r1
    //     0xb9d790: add             x1, x1, HEAP, lsl #32
    // 0xb9d794: LoadField: r2 = r1->field_7
    //     0xb9d794: ldur            x2, [x1, #7]
    // 0xb9d798: cmp             x2, #1
    // 0xb9d79c: b.gt            #0xb9d7cc
    // 0xb9d7a0: cmp             x2, #0
    // 0xb9d7a4: b.gt            #0xb9d7cc
    // 0xb9d7a8: LoadField: r1 = r3->field_8b
    //     0xb9d7a8: ldur            w1, [x3, #0x8b]
    // 0xb9d7ac: DecompressPointer r1
    //     0xb9d7ac: add             x1, x1, HEAP, lsl #32
    // 0xb9d7b0: cmp             w1, NULL
    // 0xb9d7b4: b.eq            #0xb9d7cc
    // 0xb9d7b8: r2 = LoadInt32Instr(r1)
    //     0xb9d7b8: sbfx            x2, x1, #1, #0x1f
    //     0xb9d7bc: tbz             w1, #0, #0xb9d7c4
    //     0xb9d7c0: ldur            x2, [x1, #7]
    // 0xb9d7c4: cmp             x0, x2
    // 0xb9d7c8: b.ne            #0xb9e0ac
    // 0xb9d7cc: ldur            x0, [fp, #-0x10]
    // 0xb9d7d0: r2 = Null
    //     0xb9d7d0: mov             x2, NULL
    // 0xb9d7d4: r1 = Null
    //     0xb9d7d4: mov             x1, NULL
    // 0xb9d7d8: cmp             w0, NULL
    // 0xb9d7dc: b.eq            #0xb9d804
    // 0xb9d7e0: branchIfSmi(r0, 0xb9d804)
    //     0xb9d7e0: tbz             w0, #0, #0xb9d804
    // 0xb9d7e4: r3 = LoadClassIdInstr(r0)
    //     0xb9d7e4: ldur            x3, [x0, #-1]
    //     0xb9d7e8: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d7ec: r17 = 4157
    //     0xb9d7ec: mov             x17, #0x103d
    // 0xb9d7f0: cmp             x3, x17
    // 0xb9d7f4: b.eq            #0xb9d80c
    // 0xb9d7f8: r17 = 5286
    //     0xb9d7f8: mov             x17, #0x14a6
    // 0xb9d7fc: cmp             x3, x17
    // 0xb9d800: b.eq            #0xb9d80c
    // 0xb9d804: r0 = false
    //     0xb9d804: add             x0, NULL, #0x30  ; false
    // 0xb9d808: b               #0xb9d810
    // 0xb9d80c: r0 = true
    //     0xb9d80c: add             x0, NULL, #0x20  ; true
    // 0xb9d810: tbnz            w0, #4, #0xb9d840
    // 0xb9d814: ldur            x2, [fp, #-0x10]
    // 0xb9d818: r0 = LoadClassIdInstr(r2)
    //     0xb9d818: ldur            x0, [x2, #-1]
    //     0xb9d81c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d820: mov             x1, x2
    // 0xb9d824: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0xb9d824: mov             x17, #0x5a8f
    //     0xb9d828: movk            x17, #1, lsl #16
    //     0xb9d82c: add             lr, x0, x17
    //     0xb9d830: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d834: blr             lr
    // 0xb9d838: mov             x3, x0
    // 0xb9d83c: b               #0xb9d8a4
    // 0xb9d840: ldur            x3, [fp, #-0x10]
    // 0xb9d844: mov             x0, x3
    // 0xb9d848: r2 = Null
    //     0xb9d848: mov             x2, NULL
    // 0xb9d84c: r1 = Null
    //     0xb9d84c: mov             x1, NULL
    // 0xb9d850: r4 = LoadClassIdInstr(r0)
    //     0xb9d850: ldur            x4, [x0, #-1]
    //     0xb9d854: ubfx            x4, x4, #0xc, #0x14
    // 0xb9d858: r17 = 4143
    //     0xb9d858: mov             x17, #0x102f
    // 0xb9d85c: cmp             x4, x17
    // 0xb9d860: b.eq            #0xb9d884
    // 0xb9d864: r17 = 5280
    //     0xb9d864: mov             x17, #0x14a0
    // 0xb9d868: cmp             x4, x17
    // 0xb9d86c: b.eq            #0xb9d884
    // 0xb9d870: r8 = PointerPanZoomUpdateEvent
    //     0xb9d870: add             x8, PP, #0x80, lsl #12  ; [pp+0x80b28] Type: PointerPanZoomUpdateEvent
    //     0xb9d874: ldr             x8, [x8, #0xb28]
    // 0xb9d878: r3 = Null
    //     0xb9d878: add             x3, PP, #0x80, lsl #12  ; [pp+0x80b30] Null
    //     0xb9d87c: ldr             x3, [x3, #0xb30]
    // 0xb9d880: r0 = DefaultTypeTest()
    //     0xb9d880: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9d884: ldur            x2, [fp, #-0x10]
    // 0xb9d888: r0 = LoadClassIdInstr(r2)
    //     0xb9d888: ldur            x0, [x2, #-1]
    //     0xb9d88c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d890: mov             x1, x2
    // 0xb9d894: r0 = GDT[cid_x0 + 0x603]()
    //     0xb9d894: add             lr, x0, #0x603
    //     0xb9d898: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d89c: blr             lr
    // 0xb9d8a0: mov             x3, x0
    // 0xb9d8a4: ldur            x0, [fp, #-0x10]
    // 0xb9d8a8: stur            x3, [fp, #-0x18]
    // 0xb9d8ac: r2 = Null
    //     0xb9d8ac: mov             x2, NULL
    // 0xb9d8b0: r1 = Null
    //     0xb9d8b0: mov             x1, NULL
    // 0xb9d8b4: cmp             w0, NULL
    // 0xb9d8b8: b.eq            #0xb9d8e0
    // 0xb9d8bc: branchIfSmi(r0, 0xb9d8e0)
    //     0xb9d8bc: tbz             w0, #0, #0xb9d8e0
    // 0xb9d8c0: r3 = LoadClassIdInstr(r0)
    //     0xb9d8c0: ldur            x3, [x0, #-1]
    //     0xb9d8c4: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d8c8: r17 = 4157
    //     0xb9d8c8: mov             x17, #0x103d
    // 0xb9d8cc: cmp             x3, x17
    // 0xb9d8d0: b.eq            #0xb9d8e8
    // 0xb9d8d4: r17 = 5286
    //     0xb9d8d4: mov             x17, #0x14a6
    // 0xb9d8d8: cmp             x3, x17
    // 0xb9d8dc: b.eq            #0xb9d8e8
    // 0xb9d8e0: r0 = false
    //     0xb9d8e0: add             x0, NULL, #0x30  ; false
    // 0xb9d8e4: b               #0xb9d8ec
    // 0xb9d8e8: r0 = true
    //     0xb9d8e8: add             x0, NULL, #0x20  ; true
    // 0xb9d8ec: tbnz            w0, #4, #0xb9d91c
    // 0xb9d8f0: ldur            x2, [fp, #-0x10]
    // 0xb9d8f4: r0 = LoadClassIdInstr(r2)
    //     0xb9d8f4: ldur            x0, [x2, #-1]
    //     0xb9d8f8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d8fc: mov             x1, x2
    // 0xb9d900: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb9d900: mov             x17, #0x545d
    //     0xb9d904: movk            x17, #1, lsl #16
    //     0xb9d908: add             lr, x0, x17
    //     0xb9d90c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d910: blr             lr
    // 0xb9d914: mov             x3, x0
    // 0xb9d918: b               #0xb9d980
    // 0xb9d91c: ldur            x3, [fp, #-0x10]
    // 0xb9d920: mov             x0, x3
    // 0xb9d924: r2 = Null
    //     0xb9d924: mov             x2, NULL
    // 0xb9d928: r1 = Null
    //     0xb9d928: mov             x1, NULL
    // 0xb9d92c: r4 = LoadClassIdInstr(r0)
    //     0xb9d92c: ldur            x4, [x0, #-1]
    //     0xb9d930: ubfx            x4, x4, #0xc, #0x14
    // 0xb9d934: r17 = 4143
    //     0xb9d934: mov             x17, #0x102f
    // 0xb9d938: cmp             x4, x17
    // 0xb9d93c: b.eq            #0xb9d960
    // 0xb9d940: r17 = 5280
    //     0xb9d940: mov             x17, #0x14a0
    // 0xb9d944: cmp             x4, x17
    // 0xb9d948: b.eq            #0xb9d960
    // 0xb9d94c: r8 = PointerPanZoomUpdateEvent
    //     0xb9d94c: add             x8, PP, #0x80, lsl #12  ; [pp+0x80b28] Type: PointerPanZoomUpdateEvent
    //     0xb9d950: ldr             x8, [x8, #0xb28]
    // 0xb9d954: r3 = Null
    //     0xb9d954: add             x3, PP, #0x80, lsl #12  ; [pp+0x80b40] Null
    //     0xb9d958: ldr             x3, [x3, #0xb40]
    // 0xb9d95c: r0 = DefaultTypeTest()
    //     0xb9d95c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9d960: ldur            x2, [fp, #-0x10]
    // 0xb9d964: r0 = LoadClassIdInstr(r2)
    //     0xb9d964: ldur            x0, [x2, #-1]
    //     0xb9d968: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d96c: mov             x1, x2
    // 0xb9d970: r0 = GDT[cid_x0 + 0x695]()
    //     0xb9d970: add             lr, x0, #0x695
    //     0xb9d974: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d978: blr             lr
    // 0xb9d97c: mov             x3, x0
    // 0xb9d980: ldur            x0, [fp, #-0x10]
    // 0xb9d984: stur            x3, [fp, #-0x20]
    // 0xb9d988: r2 = Null
    //     0xb9d988: mov             x2, NULL
    // 0xb9d98c: r1 = Null
    //     0xb9d98c: mov             x1, NULL
    // 0xb9d990: cmp             w0, NULL
    // 0xb9d994: b.eq            #0xb9d9bc
    // 0xb9d998: branchIfSmi(r0, 0xb9d9bc)
    //     0xb9d998: tbz             w0, #0, #0xb9d9bc
    // 0xb9d99c: r3 = LoadClassIdInstr(r0)
    //     0xb9d99c: ldur            x3, [x0, #-1]
    //     0xb9d9a0: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d9a4: r17 = 4157
    //     0xb9d9a4: mov             x17, #0x103d
    // 0xb9d9a8: cmp             x3, x17
    // 0xb9d9ac: b.eq            #0xb9d9c4
    // 0xb9d9b0: r17 = 5286
    //     0xb9d9b0: mov             x17, #0x14a6
    // 0xb9d9b4: cmp             x3, x17
    // 0xb9d9b8: b.eq            #0xb9d9c4
    // 0xb9d9bc: r0 = false
    //     0xb9d9bc: add             x0, NULL, #0x30  ; false
    // 0xb9d9c0: b               #0xb9d9c8
    // 0xb9d9c4: r0 = true
    //     0xb9d9c4: add             x0, NULL, #0x20  ; true
    // 0xb9d9c8: tbnz            w0, #4, #0xb9d9f8
    // 0xb9d9cc: ldur            x2, [fp, #-0x10]
    // 0xb9d9d0: r0 = LoadClassIdInstr(r2)
    //     0xb9d9d0: ldur            x0, [x2, #-1]
    //     0xb9d9d4: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d9d8: mov             x1, x2
    // 0xb9d9dc: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb9d9dc: mov             x17, #0x3f27
    //     0xb9d9e0: movk            x17, #1, lsl #16
    //     0xb9d9e4: add             lr, x0, x17
    //     0xb9d9e8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d9ec: blr             lr
    // 0xb9d9f0: mov             x3, x0
    // 0xb9d9f4: b               #0xb9da90
    // 0xb9d9f8: ldur            x2, [fp, #-0x10]
    // 0xb9d9fc: r0 = LoadClassIdInstr(r2)
    //     0xb9d9fc: ldur            x0, [x2, #-1]
    //     0xb9da00: ubfx            x0, x0, #0xc, #0x14
    // 0xb9da04: mov             x1, x2
    // 0xb9da08: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb9da08: mov             x17, #0x3f27
    //     0xb9da0c: movk            x17, #1, lsl #16
    //     0xb9da10: add             lr, x0, x17
    //     0xb9da14: ldr             lr, [x21, lr, lsl #3]
    //     0xb9da18: blr             lr
    // 0xb9da1c: mov             x3, x0
    // 0xb9da20: ldur            x0, [fp, #-0x10]
    // 0xb9da24: r2 = Null
    //     0xb9da24: mov             x2, NULL
    // 0xb9da28: r1 = Null
    //     0xb9da28: mov             x1, NULL
    // 0xb9da2c: stur            x3, [fp, #-0x28]
    // 0xb9da30: r4 = LoadClassIdInstr(r0)
    //     0xb9da30: ldur            x4, [x0, #-1]
    //     0xb9da34: ubfx            x4, x4, #0xc, #0x14
    // 0xb9da38: r17 = 4143
    //     0xb9da38: mov             x17, #0x102f
    // 0xb9da3c: cmp             x4, x17
    // 0xb9da40: b.eq            #0xb9da64
    // 0xb9da44: r17 = 5280
    //     0xb9da44: mov             x17, #0x14a0
    // 0xb9da48: cmp             x4, x17
    // 0xb9da4c: b.eq            #0xb9da64
    // 0xb9da50: r8 = PointerPanZoomUpdateEvent
    //     0xb9da50: add             x8, PP, #0x80, lsl #12  ; [pp+0x80b28] Type: PointerPanZoomUpdateEvent
    //     0xb9da54: ldr             x8, [x8, #0xb28]
    // 0xb9da58: r3 = Null
    //     0xb9da58: add             x3, PP, #0x80, lsl #12  ; [pp+0x80b50] Null
    //     0xb9da5c: ldr             x3, [x3, #0xb50]
    // 0xb9da60: r0 = DefaultTypeTest()
    //     0xb9da60: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9da64: ldur            x2, [fp, #-0x10]
    // 0xb9da68: r0 = LoadClassIdInstr(r2)
    //     0xb9da68: ldur            x0, [x2, #-1]
    //     0xb9da6c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9da70: mov             x1, x2
    // 0xb9da74: r0 = GDT[cid_x0 + -0xff5]()
    //     0xb9da74: sub             lr, x0, #0xff5
    //     0xb9da78: ldr             lr, [x21, lr, lsl #3]
    //     0xb9da7c: blr             lr
    // 0xb9da80: ldur            x1, [fp, #-0x28]
    // 0xb9da84: mov             x2, x0
    // 0xb9da88: r0 = +()
    //     0xb9da88: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb9da8c: mov             x3, x0
    // 0xb9da90: ldur            x0, [fp, #-0x10]
    // 0xb9da94: stur            x3, [fp, #-0x28]
    // 0xb9da98: r2 = Null
    //     0xb9da98: mov             x2, NULL
    // 0xb9da9c: r1 = Null
    //     0xb9da9c: mov             x1, NULL
    // 0xb9daa0: cmp             w0, NULL
    // 0xb9daa4: b.eq            #0xb9dacc
    // 0xb9daa8: branchIfSmi(r0, 0xb9dacc)
    //     0xb9daa8: tbz             w0, #0, #0xb9dacc
    // 0xb9daac: r3 = LoadClassIdInstr(r0)
    //     0xb9daac: ldur            x3, [x0, #-1]
    //     0xb9dab0: ubfx            x3, x3, #0xc, #0x14
    // 0xb9dab4: r17 = 4157
    //     0xb9dab4: mov             x17, #0x103d
    // 0xb9dab8: cmp             x3, x17
    // 0xb9dabc: b.eq            #0xb9dad4
    // 0xb9dac0: r17 = 5286
    //     0xb9dac0: mov             x17, #0x14a6
    // 0xb9dac4: cmp             x3, x17
    // 0xb9dac8: b.eq            #0xb9dad4
    // 0xb9dacc: r0 = false
    //     0xb9dacc: add             x0, NULL, #0x30  ; false
    // 0xb9dad0: b               #0xb9dad8
    // 0xb9dad4: r0 = true
    //     0xb9dad4: add             x0, NULL, #0x20  ; true
    // 0xb9dad8: tbnz            w0, #4, #0xb9db08
    // 0xb9dadc: ldur            x2, [fp, #-0x10]
    // 0xb9dae0: r0 = LoadClassIdInstr(r2)
    //     0xb9dae0: ldur            x0, [x2, #-1]
    //     0xb9dae4: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dae8: mov             x1, x2
    // 0xb9daec: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb9daec: mov             x17, #0x54ea
    //     0xb9daf0: movk            x17, #1, lsl #16
    //     0xb9daf4: add             lr, x0, x17
    //     0xb9daf8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dafc: blr             lr
    // 0xb9db00: mov             x2, x0
    // 0xb9db04: b               #0xb9dba0
    // 0xb9db08: ldur            x2, [fp, #-0x10]
    // 0xb9db0c: r0 = LoadClassIdInstr(r2)
    //     0xb9db0c: ldur            x0, [x2, #-1]
    //     0xb9db10: ubfx            x0, x0, #0xc, #0x14
    // 0xb9db14: mov             x1, x2
    // 0xb9db18: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb9db18: mov             x17, #0x54ea
    //     0xb9db1c: movk            x17, #1, lsl #16
    //     0xb9db20: add             lr, x0, x17
    //     0xb9db24: ldr             lr, [x21, lr, lsl #3]
    //     0xb9db28: blr             lr
    // 0xb9db2c: mov             x3, x0
    // 0xb9db30: ldur            x0, [fp, #-0x10]
    // 0xb9db34: r2 = Null
    //     0xb9db34: mov             x2, NULL
    // 0xb9db38: r1 = Null
    //     0xb9db38: mov             x1, NULL
    // 0xb9db3c: stur            x3, [fp, #-0x30]
    // 0xb9db40: r4 = LoadClassIdInstr(r0)
    //     0xb9db40: ldur            x4, [x0, #-1]
    //     0xb9db44: ubfx            x4, x4, #0xc, #0x14
    // 0xb9db48: r17 = 4143
    //     0xb9db48: mov             x17, #0x102f
    // 0xb9db4c: cmp             x4, x17
    // 0xb9db50: b.eq            #0xb9db74
    // 0xb9db54: r17 = 5280
    //     0xb9db54: mov             x17, #0x14a0
    // 0xb9db58: cmp             x4, x17
    // 0xb9db5c: b.eq            #0xb9db74
    // 0xb9db60: r8 = PointerPanZoomUpdateEvent
    //     0xb9db60: add             x8, PP, #0x80, lsl #12  ; [pp+0x80b28] Type: PointerPanZoomUpdateEvent
    //     0xb9db64: ldr             x8, [x8, #0xb28]
    // 0xb9db68: r3 = Null
    //     0xb9db68: add             x3, PP, #0x80, lsl #12  ; [pp+0x80b60] Null
    //     0xb9db6c: ldr             x3, [x3, #0xb60]
    // 0xb9db70: r0 = DefaultTypeTest()
    //     0xb9db70: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9db74: ldur            x2, [fp, #-0x10]
    // 0xb9db78: r0 = LoadClassIdInstr(r2)
    //     0xb9db78: ldur            x0, [x2, #-1]
    //     0xb9db7c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9db80: mov             x1, x2
    // 0xb9db84: r0 = GDT[cid_x0 + 0x66e]()
    //     0xb9db84: add             lr, x0, #0x66e
    //     0xb9db88: ldr             lr, [x21, lr, lsl #3]
    //     0xb9db8c: blr             lr
    // 0xb9db90: ldur            x1, [fp, #-0x30]
    // 0xb9db94: mov             x2, x0
    // 0xb9db98: r0 = +()
    //     0xb9db98: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb9db9c: mov             x2, x0
    // 0xb9dba0: ldur            x0, [fp, #-8]
    // 0xb9dba4: ldur            x1, [fp, #-0x10]
    // 0xb9dba8: ldur            x3, [fp, #-0x28]
    // 0xb9dbac: stur            x2, [fp, #-0x30]
    // 0xb9dbb0: r0 = OffsetPair()
    //     0xb9dbb0: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb9dbb4: ldur            x3, [fp, #-0x30]
    // 0xb9dbb8: StoreField: r0->field_7 = r3
    //     0xb9dbb8: stur            w3, [x0, #7]
    // 0xb9dbbc: ldur            x2, [fp, #-0x28]
    // 0xb9dbc0: StoreField: r0->field_b = r2
    //     0xb9dbc0: stur            w2, [x0, #0xb]
    // 0xb9dbc4: ldur            x4, [fp, #-8]
    // 0xb9dbc8: StoreField: r4->field_5f = r0
    //     0xb9dbc8: stur            w0, [x4, #0x5f]
    //     0xb9dbcc: ldurb           w16, [x4, #-1]
    //     0xb9dbd0: ldurb           w17, [x0, #-1]
    //     0xb9dbd4: and             x16, x17, x16, lsr #2
    //     0xb9dbd8: tst             x16, HEAP, lsr #32
    //     0xb9dbdc: b.eq            #0xb9dbe4
    //     0xb9dbe0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xb9dbe4: ldur            x5, [fp, #-0x10]
    // 0xb9dbe8: r0 = LoadClassIdInstr(r5)
    //     0xb9dbe8: ldur            x0, [x5, #-1]
    //     0xb9dbec: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dbf0: mov             x1, x5
    // 0xb9dbf4: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9dbf4: sub             lr, x0, #1
    //     0xb9dbf8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dbfc: blr             lr
    // 0xb9dc00: ldur            x1, [fp, #-8]
    // 0xb9dc04: mov             x2, x0
    // 0xb9dc08: ldur            x3, [fp, #-0x20]
    // 0xb9dc0c: r0 = _resolveLocalDeltaForMultitouch()
    //     0xb9dc0c: bl              #0xb9e970  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_resolveLocalDeltaForMultitouch
    // 0xb9dc10: mov             x2, x0
    // 0xb9dc14: ldur            x1, [fp, #-8]
    // 0xb9dc18: stur            x2, [fp, #-0x40]
    // 0xb9dc1c: LoadField: r0 = r1->field_53
    //     0xb9dc1c: ldur            w0, [x1, #0x53]
    // 0xb9dc20: DecompressPointer r0
    //     0xb9dc20: add             x0, x0, HEAP, lsl #32
    // 0xb9dc24: r16 = Instance__DragState
    //     0xb9dc24: add             x16, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!_DragState@12c5ce1
    //     0xb9dc28: ldr             x16, [x16, #0x530]
    // 0xb9dc2c: cmp             w0, w16
    // 0xb9dc30: b.eq            #0xb9dc44
    // 0xb9dc34: r16 = Instance__DragState
    //     0xb9dc34: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b70] Obj!_DragState@12c5d01
    //     0xb9dc38: ldr             x16, [x16, #0xb70]
    // 0xb9dc3c: cmp             w0, w16
    // 0xb9dc40: b.ne            #0xb9dfa8
    // 0xb9dc44: ldur            x0, [fp, #-0x10]
    // 0xb9dc48: ldur            x3, [fp, #-0x18]
    // 0xb9dc4c: ldur            x2, [fp, #-0x20]
    // 0xb9dc50: LoadField: r4 = r1->field_5b
    //     0xb9dc50: ldur            w4, [x1, #0x5b]
    // 0xb9dc54: DecompressPointer r4
    //     0xb9dc54: add             x4, x4, HEAP, lsl #32
    // 0xb9dc58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9dc5c: cmp             w4, w16
    // 0xb9dc60: b.eq            #0xb9e1c4
    // 0xb9dc64: stur            x4, [fp, #-0x38]
    // 0xb9dc68: r0 = OffsetPair()
    //     0xb9dc68: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb9dc6c: mov             x1, x0
    // 0xb9dc70: ldur            x0, [fp, #-0x20]
    // 0xb9dc74: StoreField: r1->field_7 = r0
    //     0xb9dc74: stur            w0, [x1, #7]
    // 0xb9dc78: ldur            x2, [fp, #-0x18]
    // 0xb9dc7c: StoreField: r1->field_b = r2
    //     0xb9dc7c: stur            w2, [x1, #0xb]
    // 0xb9dc80: mov             x2, x1
    // 0xb9dc84: ldur            x1, [fp, #-0x38]
    // 0xb9dc88: r0 = +()
    //     0xb9dc88: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb9dc8c: ldur            x2, [fp, #-8]
    // 0xb9dc90: StoreField: r2->field_5b = r0
    //     0xb9dc90: stur            w0, [x2, #0x5b]
    //     0xb9dc94: ldurb           w16, [x2, #-1]
    //     0xb9dc98: ldurb           w17, [x0, #-1]
    //     0xb9dc9c: and             x16, x17, x16, lsr #2
    //     0xb9dca0: tst             x16, HEAP, lsr #32
    //     0xb9dca4: b.eq            #0xb9dcac
    //     0xb9dca8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9dcac: ldur            x3, [fp, #-0x10]
    // 0xb9dcb0: r0 = LoadClassIdInstr(r3)
    //     0xb9dcb0: ldur            x0, [x3, #-1]
    //     0xb9dcb4: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dcb8: mov             x1, x3
    // 0xb9dcbc: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xb9dcbc: mov             x17, #0x5eb5
    //     0xb9dcc0: movk            x17, #1, lsl #16
    //     0xb9dcc4: add             lr, x0, x17
    //     0xb9dcc8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dccc: blr             lr
    // 0xb9dcd0: ldur            x2, [fp, #-8]
    // 0xb9dcd4: StoreField: r2->field_63 = r0
    //     0xb9dcd4: stur            w0, [x2, #0x63]
    //     0xb9dcd8: ldurb           w16, [x2, #-1]
    //     0xb9dcdc: ldurb           w17, [x0, #-1]
    //     0xb9dce0: and             x16, x17, x16, lsr #2
    //     0xb9dce4: tst             x16, HEAP, lsr #32
    //     0xb9dce8: b.eq            #0xb9dcf0
    //     0xb9dcec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9dcf0: ldur            x3, [fp, #-0x10]
    // 0xb9dcf4: r0 = LoadClassIdInstr(r3)
    //     0xb9dcf4: ldur            x0, [x3, #-1]
    //     0xb9dcf8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dcfc: mov             x1, x3
    // 0xb9dd00: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb9dd00: mov             x17, #0x5fe3
    //     0xb9dd04: movk            x17, #1, lsl #16
    //     0xb9dd08: add             lr, x0, x17
    //     0xb9dd0c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dd10: blr             lr
    // 0xb9dd14: ldur            x3, [fp, #-8]
    // 0xb9dd18: StoreField: r3->field_6b = r0
    //     0xb9dd18: stur            w0, [x3, #0x6b]
    //     0xb9dd1c: ldurb           w16, [x3, #-1]
    //     0xb9dd20: ldurb           w17, [x0, #-1]
    //     0xb9dd24: and             x16, x17, x16, lsr #2
    //     0xb9dd28: tst             x16, HEAP, lsr #32
    //     0xb9dd2c: b.eq            #0xb9dd34
    //     0xb9dd30: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb9dd34: r0 = LoadClassIdInstr(r3)
    //     0xb9dd34: ldur            x0, [x3, #-1]
    //     0xb9dd38: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dd3c: mov             x1, x3
    // 0xb9dd40: ldur            x2, [fp, #-0x20]
    // 0xb9dd44: r0 = GDT[cid_x0 + 0x16dc]()
    //     0xb9dd44: mov             x17, #0x16dc
    //     0xb9dd48: add             lr, x0, x17
    //     0xb9dd4c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dd50: blr             lr
    // 0xb9dd54: mov             x3, x0
    // 0xb9dd58: ldur            x2, [fp, #-0x10]
    // 0xb9dd5c: stur            x3, [fp, #-0x18]
    // 0xb9dd60: r0 = LoadClassIdInstr(r2)
    //     0xb9dd60: ldur            x0, [x2, #-1]
    //     0xb9dd64: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dd68: mov             x1, x2
    // 0xb9dd6c: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb9dd6c: mov             x17, #0x5fe3
    //     0xb9dd70: movk            x17, #1, lsl #16
    //     0xb9dd74: add             lr, x0, x17
    //     0xb9dd78: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dd7c: blr             lr
    // 0xb9dd80: cmp             w0, NULL
    // 0xb9dd84: b.ne            #0xb9dd90
    // 0xb9dd88: r1 = Null
    //     0xb9dd88: mov             x1, NULL
    // 0xb9dd8c: b               #0xb9ddc8
    // 0xb9dd90: ldur            x2, [fp, #-0x10]
    // 0xb9dd94: r0 = LoadClassIdInstr(r2)
    //     0xb9dd94: ldur            x0, [x2, #-1]
    //     0xb9dd98: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dd9c: mov             x1, x2
    // 0xb9dda0: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb9dda0: mov             x17, #0x5fe3
    //     0xb9dda4: movk            x17, #1, lsl #16
    //     0xb9dda8: add             lr, x0, x17
    //     0xb9ddac: ldr             lr, [x21, lr, lsl #3]
    //     0xb9ddb0: blr             lr
    // 0xb9ddb4: cmp             w0, NULL
    // 0xb9ddb8: b.eq            #0xb9e1d0
    // 0xb9ddbc: mov             x1, x0
    // 0xb9ddc0: r0 = tryInvert()
    //     0xb9ddc0: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xb9ddc4: mov             x1, x0
    // 0xb9ddc8: ldur            x0, [fp, #-8]
    // 0xb9ddcc: LoadField: r4 = r0->field_6f
    //     0xb9ddcc: ldur            w4, [x0, #0x6f]
    // 0xb9ddd0: DecompressPointer r4
    //     0xb9ddd0: add             x4, x4, HEAP, lsl #32
    // 0xb9ddd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9ddd8: cmp             w4, w16
    // 0xb9dddc: b.eq            #0xb9e1d4
    // 0xb9dde0: ldur            x2, [fp, #-0x18]
    // 0xb9dde4: ldur            x3, [fp, #-0x30]
    // 0xb9dde8: stur            x4, [fp, #-0x38]
    // 0xb9ddec: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb9ddec: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb9ddf0: r0 = transformDeltaViaPositions()
    //     0xb9ddf0: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xb9ddf4: mov             x1, x0
    // 0xb9ddf8: r0 = distance()
    //     0xb9ddf8: bl              #0xb9e954  ; [dart:ui] Offset::distance
    // 0xb9ddfc: ldur            x3, [fp, #-8]
    // 0xb9de00: stur            d0, [fp, #-0x48]
    // 0xb9de04: r0 = LoadClassIdInstr(r3)
    //     0xb9de04: ldur            x0, [x3, #-1]
    //     0xb9de08: ubfx            x0, x0, #0xc, #0x14
    // 0xb9de0c: mov             x1, x3
    // 0xb9de10: ldur            x2, [fp, #-0x18]
    // 0xb9de14: r0 = GDT[cid_x0 + 0x2cb6]()
    //     0xb9de14: mov             x17, #0x2cb6
    //     0xb9de18: add             lr, x0, x17
    //     0xb9de1c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9de20: blr             lr
    // 0xb9de24: cmp             w0, NULL
    // 0xb9de28: b.ne            #0xb9de34
    // 0xb9de2c: d1 = 1.000000
    //     0xb9de2c: fmov            d1, #1.00000000
    // 0xb9de30: b               #0xb9de3c
    // 0xb9de34: LoadField: d0 = r0->field_7
    //     0xb9de34: ldur            d0, [x0, #7]
    // 0xb9de38: mov             v1.16b, v0.16b
    // 0xb9de3c: d0 = 0.000000
    //     0xb9de3c: eor             v0.16b, v0.16b, v0.16b
    // 0xb9de40: fcmp            d1, d0
    // 0xb9de44: b.le            #0xb9de50
    // 0xb9de48: d1 = 1.000000
    //     0xb9de48: fmov            d1, #1.00000000
    // 0xb9de4c: b               #0xb9de5c
    // 0xb9de50: fcmp            d0, d1
    // 0xb9de54: b.le            #0xb9de5c
    // 0xb9de58: d1 = -1.000000
    //     0xb9de58: fmov            d1, #-1.00000000
    // 0xb9de5c: ldur            x2, [fp, #-8]
    // 0xb9de60: ldur            x3, [fp, #-0x10]
    // 0xb9de64: ldur            d0, [fp, #-0x48]
    // 0xb9de68: ldur            x0, [fp, #-0x38]
    // 0xb9de6c: fmul            d2, d0, d1
    // 0xb9de70: LoadField: d0 = r0->field_7
    //     0xb9de70: ldur            d0, [x0, #7]
    // 0xb9de74: fadd            d1, d0, d2
    // 0xb9de78: r0 = inline_Allocate_Double()
    //     0xb9de78: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9de7c: add             x0, x0, #0x10
    //     0xb9de80: cmp             x1, x0
    //     0xb9de84: b.ls            #0xb9e1e0
    //     0xb9de88: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9de8c: sub             x0, x0, #0xf
    //     0xb9de90: mov             x1, #0xe19c
    //     0xb9de94: movk            x1, #3, lsl #16
    //     0xb9de98: stur            x1, [x0, #-1]
    // 0xb9de9c: dmb             ishst
    // 0xb9dea0: StoreField: r0->field_7 = d1
    //     0xb9dea0: stur            d1, [x0, #7]
    // 0xb9dea4: StoreField: r2->field_6f = r0
    //     0xb9dea4: stur            w0, [x2, #0x6f]
    //     0xb9dea8: ldurb           w16, [x2, #-1]
    //     0xb9deac: ldurb           w17, [x0, #-1]
    //     0xb9deb0: and             x16, x17, x16, lsr #2
    //     0xb9deb4: tst             x16, HEAP, lsr #32
    //     0xb9deb8: b.eq            #0xb9dec0
    //     0xb9debc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9dec0: r0 = LoadClassIdInstr(r3)
    //     0xb9dec0: ldur            x0, [x3, #-1]
    //     0xb9dec4: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dec8: mov             x1, x3
    // 0xb9decc: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb9decc: mov             x17, #0x5e74
    //     0xb9ded0: movk            x17, #1, lsl #16
    //     0xb9ded4: add             lr, x0, x17
    //     0xb9ded8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dedc: blr             lr
    // 0xb9dee0: ldur            x3, [fp, #-8]
    // 0xb9dee4: r1 = LoadClassIdInstr(r3)
    //     0xb9dee4: ldur            x1, [x3, #-1]
    //     0xb9dee8: ubfx            x1, x1, #0xc, #0x14
    // 0xb9deec: mov             x2, x0
    // 0xb9def0: mov             x0, x1
    // 0xb9def4: mov             x1, x3
    // 0xb9def8: r0 = GDT[cid_x0 + 0x50c1]()
    //     0xb9def8: mov             x17, #0x50c1
    //     0xb9defc: add             lr, x0, x17
    //     0xb9df00: ldr             lr, [x21, lr, lsl #3]
    //     0xb9df04: blr             lr
    // 0xb9df08: tbnz            w0, #4, #0xb9e080
    // 0xb9df0c: ldur            x2, [fp, #-8]
    // 0xb9df10: ldur            x3, [fp, #-0x10]
    // 0xb9df14: r0 = true
    //     0xb9df14: add             x0, NULL, #0x20  ; true
    // 0xb9df18: StoreField: r2->field_73 = r0
    //     0xb9df18: stur            w0, [x2, #0x73]
    // 0xb9df1c: LoadField: r4 = r2->field_87
    //     0xb9df1c: ldur            w4, [x2, #0x87]
    // 0xb9df20: DecompressPointer r4
    //     0xb9df20: add             x4, x4, HEAP, lsl #32
    // 0xb9df24: stur            x4, [fp, #-0x18]
    // 0xb9df28: r0 = LoadClassIdInstr(r3)
    //     0xb9df28: ldur            x0, [x3, #-1]
    //     0xb9df2c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9df30: mov             x1, x3
    // 0xb9df34: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9df34: sub             lr, x0, #1
    //     0xb9df38: ldr             lr, [x21, lr, lsl #3]
    //     0xb9df3c: blr             lr
    // 0xb9df40: mov             x2, x0
    // 0xb9df44: r0 = BoxInt64Instr(r2)
    //     0xb9df44: sbfiz           x0, x2, #1, #0x1f
    //     0xb9df48: cmp             x2, x0, asr #1
    //     0xb9df4c: b.eq            #0xb9df58
    //     0xb9df50: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9df54: stur            x2, [x0, #7]
    // 0xb9df58: ldur            x1, [fp, #-0x18]
    // 0xb9df5c: mov             x2, x0
    // 0xb9df60: r0 = contains()
    //     0xb9df60: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0xb9df64: tbnz            w0, #4, #0xb9df94
    // 0xb9df68: ldur            x2, [fp, #-0x10]
    // 0xb9df6c: r0 = LoadClassIdInstr(r2)
    //     0xb9df6c: ldur            x0, [x2, #-1]
    //     0xb9df70: ubfx            x0, x0, #0xc, #0x14
    // 0xb9df74: mov             x1, x2
    // 0xb9df78: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9df78: sub             lr, x0, #1
    //     0xb9df7c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9df80: blr             lr
    // 0xb9df84: ldur            x1, [fp, #-8]
    // 0xb9df88: mov             x2, x0
    // 0xb9df8c: r0 = _checkDrag()
    //     0xb9df8c: bl              #0xb9e510  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDrag
    // 0xb9df90: b               #0xb9e080
    // 0xb9df94: ldur            x1, [fp, #-8]
    // 0xb9df98: r2 = Instance_GestureDisposition
    //     0xb9df98: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xb9df9c: ldr             x2, [x2, #0x628]
    // 0xb9dfa0: r0 = resolve()
    //     0xb9dfa0: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb9dfa4: b               #0xb9e080
    // 0xb9dfa8: r16 = Instance__DragState
    //     0xb9dfa8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26618] Obj!_DragState@12c5d21
    //     0xb9dfac: ldr             x16, [x16, #0x618]
    // 0xb9dfb0: cmp             w0, w16
    // 0xb9dfb4: b.ne            #0xb9e080
    // 0xb9dfb8: ldur            x4, [fp, #-8]
    // 0xb9dfbc: ldur            x3, [fp, #-0x10]
    // 0xb9dfc0: r0 = LoadClassIdInstr(r3)
    //     0xb9dfc0: ldur            x0, [x3, #-1]
    //     0xb9dfc4: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dfc8: mov             x1, x3
    // 0xb9dfcc: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xb9dfcc: mov             x17, #0x5eb5
    //     0xb9dfd0: movk            x17, #1, lsl #16
    //     0xb9dfd4: add             lr, x0, x17
    //     0xb9dfd8: ldr             lr, [x21, lr, lsl #3]
    //     0xb9dfdc: blr             lr
    // 0xb9dfe0: mov             x4, x0
    // 0xb9dfe4: ldur            x3, [fp, #-8]
    // 0xb9dfe8: stur            x4, [fp, #-0x18]
    // 0xb9dfec: r0 = LoadClassIdInstr(r3)
    //     0xb9dfec: ldur            x0, [x3, #-1]
    //     0xb9dff0: ubfx            x0, x0, #0xc, #0x14
    // 0xb9dff4: mov             x1, x3
    // 0xb9dff8: ldur            x2, [fp, #-0x40]
    // 0xb9dffc: r0 = GDT[cid_x0 + 0x16dc]()
    //     0xb9dffc: mov             x17, #0x16dc
    //     0xb9e000: add             lr, x0, x17
    //     0xb9e004: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e008: blr             lr
    // 0xb9e00c: mov             x4, x0
    // 0xb9e010: ldur            x3, [fp, #-8]
    // 0xb9e014: stur            x4, [fp, #-0x38]
    // 0xb9e018: r0 = LoadClassIdInstr(r3)
    //     0xb9e018: ldur            x0, [x3, #-1]
    //     0xb9e01c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9e020: mov             x1, x3
    // 0xb9e024: ldur            x2, [fp, #-0x40]
    // 0xb9e028: r0 = GDT[cid_x0 + 0x2cb6]()
    //     0xb9e028: mov             x17, #0x2cb6
    //     0xb9e02c: add             lr, x0, x17
    //     0xb9e030: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e034: blr             lr
    // 0xb9e038: mov             x3, x0
    // 0xb9e03c: ldur            x2, [fp, #-0x10]
    // 0xb9e040: stur            x3, [fp, #-0x40]
    // 0xb9e044: r0 = LoadClassIdInstr(r2)
    //     0xb9e044: ldur            x0, [x2, #-1]
    //     0xb9e048: ubfx            x0, x0, #0xc, #0x14
    // 0xb9e04c: mov             x1, x2
    // 0xb9e050: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9e050: sub             lr, x0, #1
    //     0xb9e054: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e058: blr             lr
    // 0xb9e05c: ldur            x16, [fp, #-0x18]
    // 0xb9e060: str             x16, [SP]
    // 0xb9e064: ldur            x1, [fp, #-8]
    // 0xb9e068: ldur            x2, [fp, #-0x38]
    // 0xb9e06c: ldur            x3, [fp, #-0x28]
    // 0xb9e070: ldur            x5, [fp, #-0x30]
    // 0xb9e074: mov             x6, x0
    // 0xb9e078: ldur            x7, [fp, #-0x40]
    // 0xb9e07c: r0 = _checkUpdate()
    //     0xb9e07c: bl              #0xb9e378  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate
    // 0xb9e080: ldur            x2, [fp, #-0x10]
    // 0xb9e084: r0 = LoadClassIdInstr(r2)
    //     0xb9e084: ldur            x0, [x2, #-1]
    //     0xb9e088: ubfx            x0, x0, #0xc, #0x14
    // 0xb9e08c: mov             x1, x2
    // 0xb9e090: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9e090: sub             lr, x0, #1
    //     0xb9e094: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e098: blr             lr
    // 0xb9e09c: ldur            x1, [fp, #-8]
    // 0xb9e0a0: mov             x2, x0
    // 0xb9e0a4: ldur            x3, [fp, #-0x20]
    // 0xb9e0a8: r0 = _recordMoveDeltaForMultitouch()
    //     0xb9e0a8: bl              #0xb9e234  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_recordMoveDeltaForMultitouch
    // 0xb9e0ac: ldur            x0, [fp, #-0x10]
    // 0xb9e0b0: r2 = Null
    //     0xb9e0b0: mov             x2, NULL
    // 0xb9e0b4: r1 = Null
    //     0xb9e0b4: mov             x1, NULL
    // 0xb9e0b8: cmp             w0, NULL
    // 0xb9e0bc: b.eq            #0xb9e0e4
    // 0xb9e0c0: branchIfSmi(r0, 0xb9e0e4)
    //     0xb9e0c0: tbz             w0, #0, #0xb9e0e4
    // 0xb9e0c4: r3 = LoadClassIdInstr(r0)
    //     0xb9e0c4: ldur            x3, [x0, #-1]
    //     0xb9e0c8: ubfx            x3, x3, #0xc, #0x14
    // 0xb9e0cc: r17 = 4155
    //     0xb9e0cc: mov             x17, #0x103b
    // 0xb9e0d0: cmp             x3, x17
    // 0xb9e0d4: b.eq            #0xb9e0ec
    // 0xb9e0d8: r17 = 5284
    //     0xb9e0d8: mov             x17, #0x14a4
    // 0xb9e0dc: cmp             x3, x17
    // 0xb9e0e0: b.eq            #0xb9e0ec
    // 0xb9e0e4: r0 = false
    //     0xb9e0e4: add             x0, NULL, #0x30  ; false
    // 0xb9e0e8: b               #0xb9e0f0
    // 0xb9e0ec: r0 = true
    //     0xb9e0ec: add             x0, NULL, #0x20  ; true
    // 0xb9e0f0: tbz             w0, #4, #0xb9e184
    // 0xb9e0f4: ldur            x0, [fp, #-0x10]
    // 0xb9e0f8: r2 = Null
    //     0xb9e0f8: mov             x2, NULL
    // 0xb9e0fc: r1 = Null
    //     0xb9e0fc: mov             x1, NULL
    // 0xb9e100: cmp             w0, NULL
    // 0xb9e104: b.eq            #0xb9e12c
    // 0xb9e108: branchIfSmi(r0, 0xb9e12c)
    //     0xb9e108: tbz             w0, #0, #0xb9e12c
    // 0xb9e10c: r3 = LoadClassIdInstr(r0)
    //     0xb9e10c: ldur            x3, [x0, #-1]
    //     0xb9e110: ubfx            x3, x3, #0xc, #0x14
    // 0xb9e114: r17 = 4139
    //     0xb9e114: mov             x17, #0x102b
    // 0xb9e118: cmp             x3, x17
    // 0xb9e11c: b.eq            #0xb9e134
    // 0xb9e120: r17 = 5276
    //     0xb9e120: mov             x17, #0x149c
    // 0xb9e124: cmp             x3, x17
    // 0xb9e128: b.eq            #0xb9e134
    // 0xb9e12c: r0 = false
    //     0xb9e12c: add             x0, NULL, #0x30  ; false
    // 0xb9e130: b               #0xb9e138
    // 0xb9e134: r0 = true
    //     0xb9e134: add             x0, NULL, #0x20  ; true
    // 0xb9e138: tbz             w0, #4, #0xb9e184
    // 0xb9e13c: ldur            x0, [fp, #-0x10]
    // 0xb9e140: r2 = Null
    //     0xb9e140: mov             x2, NULL
    // 0xb9e144: r1 = Null
    //     0xb9e144: mov             x1, NULL
    // 0xb9e148: cmp             w0, NULL
    // 0xb9e14c: b.eq            #0xb9e174
    // 0xb9e150: branchIfSmi(r0, 0xb9e174)
    //     0xb9e150: tbz             w0, #0, #0xb9e174
    // 0xb9e154: r3 = LoadClassIdInstr(r0)
    //     0xb9e154: ldur            x3, [x0, #-1]
    //     0xb9e158: ubfx            x3, x3, #0xc, #0x14
    // 0xb9e15c: r17 = 4141
    //     0xb9e15c: mov             x17, #0x102d
    // 0xb9e160: cmp             x3, x17
    // 0xb9e164: b.eq            #0xb9e17c
    // 0xb9e168: r17 = 5278
    //     0xb9e168: mov             x17, #0x149e
    // 0xb9e16c: cmp             x3, x17
    // 0xb9e170: b.eq            #0xb9e17c
    // 0xb9e174: r0 = false
    //     0xb9e174: add             x0, NULL, #0x30  ; false
    // 0xb9e178: b               #0xb9e180
    // 0xb9e17c: r0 = true
    //     0xb9e17c: add             x0, NULL, #0x20  ; true
    // 0xb9e180: tbnz            w0, #4, #0xb9e1a8
    // 0xb9e184: ldur            x1, [fp, #-0x10]
    // 0xb9e188: r0 = LoadClassIdInstr(r1)
    //     0xb9e188: ldur            x0, [x1, #-1]
    //     0xb9e18c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9e190: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9e190: sub             lr, x0, #1
    //     0xb9e194: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e198: blr             lr
    // 0xb9e19c: ldur            x1, [fp, #-8]
    // 0xb9e1a0: mov             x2, x0
    // 0xb9e1a4: r0 = _giveUpPointer()
    //     0xb9e1a4: bl              #0xb9f334  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0xb9e1a8: r0 = Null
    //     0xb9e1a8: mov             x0, NULL
    // 0xb9e1ac: LeaveFrame
    //     0xb9e1ac: mov             SP, fp
    //     0xb9e1b0: ldp             fp, lr, [SP], #0x10
    // 0xb9e1b4: ret
    //     0xb9e1b4: ret             
    // 0xb9e1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e1b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e1bc: b               #0xb9d2c8
    // 0xb9e1c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9e1c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb9e1c4: r9 = _pendingDragOffset
    //     0xb9e1c4: add             x9, PP, #0x26, lsl #12  ; [pp+0x26630] Field <DragGestureRecognizer._pendingDragOffset@658099969>: late (offset: 0x5c)
    //     0xb9e1c8: ldr             x9, [x9, #0x630]
    // 0xb9e1cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e1cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb9e1d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9e1d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb9e1d4: r9 = _globalDistanceMoved
    //     0xb9e1d4: add             x9, PP, #0x80, lsl #12  ; [pp+0x80b78] Field <DragGestureRecognizer._globalDistanceMoved@658099969>: late (offset: 0x70)
    //     0xb9e1d8: ldr             x9, [x9, #0xb78]
    // 0xb9e1dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e1dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb9e1e0: SaveReg d1
    //     0xb9e1e0: str             q1, [SP, #-0x10]!
    // 0xb9e1e4: stp             x2, x3, [SP, #-0x10]!
    // 0xb9e1e8: r0 = AllocateDouble()
    //     0xb9e1e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9e1ec: ldp             x2, x3, [SP], #0x10
    // 0xb9e1f0: RestoreReg d1
    //     0xb9e1f0: ldr             q1, [SP], #0x10
    // 0xb9e1f4: b               #0xb9dea0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xb9e1f8, size: 0x3c
    // 0xb9e1f8: EnterFrame
    //     0xb9e1f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e1fc: mov             fp, SP
    // 0xb9e200: ldr             x0, [fp, #0x18]
    // 0xb9e204: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9e204: ldur            w1, [x0, #0x17]
    // 0xb9e208: DecompressPointer r1
    //     0xb9e208: add             x1, x1, HEAP, lsl #32
    // 0xb9e20c: CheckStackOverflow
    //     0xb9e20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e210: cmp             SP, x16
    //     0xb9e214: b.ls            #0xb9e22c
    // 0xb9e218: ldr             x2, [fp, #0x10]
    // 0xb9e21c: r0 = handleEvent()
    //     0xb9e21c: bl              #0xb9d2a4  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::handleEvent
    // 0xb9e220: LeaveFrame
    //     0xb9e220: mov             SP, fp
    //     0xb9e224: ldp             fp, lr, [SP], #0x10
    // 0xb9e228: ret
    //     0xb9e228: ret             
    // 0xb9e22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e22c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e230: b               #0xb9e218
  }
  _ _recordMoveDeltaForMultitouch(/* No info */) {
    // ** addr: 0xb9e234, size: 0x144
    // 0xb9e234: EnterFrame
    //     0xb9e234: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e238: mov             fp, SP
    // 0xb9e23c: AllocStack(0x30)
    //     0xb9e23c: sub             SP, SP, #0x30
    // 0xb9e240: SetupParameters(DragGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb9e240: mov             x0, x2
    //     0xb9e244: stur            x2, [fp, #-0x10]
    //     0xb9e248: mov             x2, x3
    //     0xb9e24c: stur            x1, [fp, #-8]
    //     0xb9e250: stur            x3, [fp, #-0x18]
    // 0xb9e254: CheckStackOverflow
    //     0xb9e254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e258: cmp             SP, x16
    //     0xb9e25c: b.ls            #0xb9e36c
    // 0xb9e260: LoadField: r3 = r1->field_27
    //     0xb9e260: ldur            w3, [x1, #0x27]
    // 0xb9e264: DecompressPointer r3
    //     0xb9e264: add             x3, x3, HEAP, lsl #32
    // 0xb9e268: r16 = Instance_MultitouchDragStrategy
    //     0xb9e268: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b80] Obj!MultitouchDragStrategy@12c5c41
    //     0xb9e26c: ldr             x16, [x16, #0xb80]
    // 0xb9e270: cmp             w3, w16
    // 0xb9e274: b.eq            #0xb9e288
    // 0xb9e278: r0 = Null
    //     0xb9e278: mov             x0, NULL
    // 0xb9e27c: LeaveFrame
    //     0xb9e27c: mov             SP, fp
    //     0xb9e280: ldp             fp, lr, [SP], #0x10
    // 0xb9e284: ret
    //     0xb9e284: ret             
    // 0xb9e288: LoadField: r3 = r1->field_53
    //     0xb9e288: ldur            w3, [x1, #0x53]
    // 0xb9e28c: DecompressPointer r3
    //     0xb9e28c: add             x3, x3, HEAP, lsl #32
    // 0xb9e290: r16 = Instance__DragState
    //     0xb9e290: add             x16, PP, #0x26, lsl #12  ; [pp+0x26618] Obj!_DragState@12c5d21
    //     0xb9e294: ldr             x16, [x16, #0x618]
    // 0xb9e298: cmp             w3, w16
    // 0xb9e29c: b.ne            #0xb9e2b0
    // 0xb9e2a0: r16 = Instance_Offset
    //     0xb9e2a0: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9e2a4: stp             x16, x2, [SP]
    // 0xb9e2a8: r0 = ==()
    //     0xb9e2a8: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb9e2ac: tbnz            w0, #4, #0xb9e2c0
    // 0xb9e2b0: r0 = Null
    //     0xb9e2b0: mov             x0, NULL
    // 0xb9e2b4: LeaveFrame
    //     0xb9e2b4: mov             SP, fp
    //     0xb9e2b8: ldp             fp, lr, [SP], #0x10
    // 0xb9e2bc: ret
    //     0xb9e2bc: ret             
    // 0xb9e2c0: ldur            x0, [fp, #-8]
    // 0xb9e2c4: ldur            x2, [fp, #-0x10]
    // 0xb9e2c8: LoadField: r3 = r0->field_7b
    //     0xb9e2c8: ldur            w3, [x0, #0x7b]
    // 0xb9e2cc: DecompressPointer r3
    //     0xb9e2cc: add             x3, x3, HEAP, lsl #32
    // 0xb9e2d0: stur            x3, [fp, #-0x20]
    // 0xb9e2d4: r0 = BoxInt64Instr(r2)
    //     0xb9e2d4: sbfiz           x0, x2, #1, #0x1f
    //     0xb9e2d8: cmp             x2, x0, asr #1
    //     0xb9e2dc: b.eq            #0xb9e2e8
    //     0xb9e2e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9e2e4: stur            x2, [x0, #7]
    // 0xb9e2e8: mov             x1, x3
    // 0xb9e2ec: mov             x2, x0
    // 0xb9e2f0: stur            x0, [fp, #-8]
    // 0xb9e2f4: r0 = containsKey()
    //     0xb9e2f4: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xb9e2f8: tbnz            w0, #4, #0xb9e34c
    // 0xb9e2fc: ldur            x0, [fp, #-0x20]
    // 0xb9e300: mov             x1, x0
    // 0xb9e304: ldur            x2, [fp, #-8]
    // 0xb9e308: r0 = _getValueOrData()
    //     0xb9e308: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb9e30c: mov             x1, x0
    // 0xb9e310: ldur            x0, [fp, #-0x20]
    // 0xb9e314: LoadField: r2 = r0->field_f
    //     0xb9e314: ldur            w2, [x0, #0xf]
    // 0xb9e318: DecompressPointer r2
    //     0xb9e318: add             x2, x2, HEAP, lsl #32
    // 0xb9e31c: cmp             w2, w1
    // 0xb9e320: b.ne            #0xb9e328
    // 0xb9e324: r1 = Null
    //     0xb9e324: mov             x1, NULL
    // 0xb9e328: cmp             w1, NULL
    // 0xb9e32c: b.eq            #0xb9e374
    // 0xb9e330: ldur            x2, [fp, #-0x18]
    // 0xb9e334: r0 = +()
    //     0xb9e334: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb9e338: ldur            x1, [fp, #-0x20]
    // 0xb9e33c: ldur            x2, [fp, #-8]
    // 0xb9e340: mov             x3, x0
    // 0xb9e344: r0 = []=()
    //     0xb9e344: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xb9e348: b               #0xb9e35c
    // 0xb9e34c: ldur            x1, [fp, #-0x20]
    // 0xb9e350: ldur            x2, [fp, #-8]
    // 0xb9e354: ldur            x3, [fp, #-0x18]
    // 0xb9e358: r0 = []=()
    //     0xb9e358: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xb9e35c: r0 = Null
    //     0xb9e35c: mov             x0, NULL
    // 0xb9e360: LeaveFrame
    //     0xb9e360: mov             SP, fp
    //     0xb9e364: ldp             fp, lr, [SP], #0x10
    // 0xb9e368: ret
    //     0xb9e368: ret             
    // 0xb9e36c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e36c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e370: b               #0xb9e260
    // 0xb9e374: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9e374: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkUpdate(/* No info */) {
    // ** addr: 0xb9e378, size: 0x11c
    // 0xb9e378: EnterFrame
    //     0xb9e378: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e37c: mov             fp, SP
    // 0xb9e380: AllocStack(0x58)
    //     0xb9e380: sub             SP, SP, #0x58
    // 0xb9e384: SetupParameters(DragGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0xb9e384: mov             x0, x2
    //     0xb9e388: stur            x2, [fp, #-0x10]
    //     0xb9e38c: mov             x2, x6
    //     0xb9e390: stur            x1, [fp, #-8]
    //     0xb9e394: stur            x3, [fp, #-0x18]
    //     0xb9e398: stur            x5, [fp, #-0x20]
    //     0xb9e39c: stur            x6, [fp, #-0x28]
    //     0xb9e3a0: stur            x7, [fp, #-0x30]
    // 0xb9e3a4: CheckStackOverflow
    //     0xb9e3a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e3a8: cmp             SP, x16
    //     0xb9e3ac: b.ls            #0xb9e48c
    // 0xb9e3b0: r1 = 2
    //     0xb9e3b0: mov             x1, #2
    // 0xb9e3b4: r0 = AllocateContext()
    //     0xb9e3b4: bl              #0x13de838  ; AllocateContextStub
    // 0xb9e3b8: mov             x3, x0
    // 0xb9e3bc: ldur            x0, [fp, #-8]
    // 0xb9e3c0: stur            x3, [fp, #-0x38]
    // 0xb9e3c4: StoreField: r3->field_f = r0
    //     0xb9e3c4: stur            w0, [x3, #0xf]
    // 0xb9e3c8: LoadField: r1 = r0->field_33
    //     0xb9e3c8: ldur            w1, [x0, #0x33]
    // 0xb9e3cc: DecompressPointer r1
    //     0xb9e3cc: add             x1, x1, HEAP, lsl #32
    // 0xb9e3d0: cmp             w1, NULL
    // 0xb9e3d4: b.eq            #0xb9e47c
    // 0xb9e3d8: ldur            x7, [fp, #-0x10]
    // 0xb9e3dc: ldur            x6, [fp, #-0x18]
    // 0xb9e3e0: ldur            x5, [fp, #-0x20]
    // 0xb9e3e4: ldur            x4, [fp, #-0x30]
    // 0xb9e3e8: ldr             x8, [fp, #0x10]
    // 0xb9e3ec: mov             x1, x0
    // 0xb9e3f0: ldur            x2, [fp, #-0x28]
    // 0xb9e3f4: r0 = getKindForPointer()
    //     0xb9e3f4: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xb9e3f8: stur            x0, [fp, #-0x40]
    // 0xb9e3fc: r0 = DragUpdateDetails()
    //     0xb9e3fc: bl              #0xb9e494  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x20)
    // 0xb9e400: mov             x1, x0
    // 0xb9e404: ldur            x0, [fp, #-0x18]
    // 0xb9e408: StoreField: r1->field_7 = r0
    //     0xb9e408: stur            w0, [x1, #7]
    // 0xb9e40c: ldr             x0, [fp, #0x10]
    // 0xb9e410: StoreField: r1->field_f = r0
    //     0xb9e410: stur            w0, [x1, #0xf]
    // 0xb9e414: ldur            x0, [fp, #-0x10]
    // 0xb9e418: StoreField: r1->field_13 = r0
    //     0xb9e418: stur            w0, [x1, #0x13]
    // 0xb9e41c: ldur            x0, [fp, #-0x30]
    // 0xb9e420: ArrayStore: r1[0] = r0  ; List_4
    //     0xb9e420: stur            w0, [x1, #0x17]
    // 0xb9e424: ldur            x0, [fp, #-0x40]
    // 0xb9e428: StoreField: r1->field_1b = r0
    //     0xb9e428: stur            w0, [x1, #0x1b]
    // 0xb9e42c: ldur            x0, [fp, #-0x20]
    // 0xb9e430: StoreField: r1->field_b = r0
    //     0xb9e430: stur            w0, [x1, #0xb]
    // 0xb9e434: mov             x0, x1
    // 0xb9e438: ldur            x2, [fp, #-0x38]
    // 0xb9e43c: StoreField: r2->field_13 = r0
    //     0xb9e43c: stur            w0, [x2, #0x13]
    //     0xb9e440: ldurb           w16, [x2, #-1]
    //     0xb9e444: ldurb           w17, [x0, #-1]
    //     0xb9e448: and             x16, x17, x16, lsr #2
    //     0xb9e44c: tst             x16, HEAP, lsr #32
    //     0xb9e450: b.eq            #0xb9e458
    //     0xb9e454: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9e458: r1 = Function '<anonymous closure>':.
    //     0xb9e458: add             x1, PP, #0x26, lsl #12  ; [pp+0x26658] AnonymousClosure: (0xb9e4a0), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate (0xb9e378)
    //     0xb9e45c: ldr             x1, [x1, #0x658]
    // 0xb9e460: r0 = AllocateClosure()
    //     0xb9e460: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9e464: r16 = <void?>
    //     0xb9e464: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb9e468: ldur            lr, [fp, #-8]
    // 0xb9e46c: stp             lr, x16, [SP, #8]
    // 0xb9e470: str             x0, [SP]
    // 0xb9e474: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9e474: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb9e478: r0 = invokeCallback()
    //     0xb9e478: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb9e47c: r0 = Null
    //     0xb9e47c: mov             x0, NULL
    // 0xb9e480: LeaveFrame
    //     0xb9e480: mov             SP, fp
    //     0xb9e484: ldp             fp, lr, [SP], #0x10
    // 0xb9e488: ret
    //     0xb9e488: ret             
    // 0xb9e48c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e48c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e490: b               #0xb9e3b0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb9e4a0, size: 0x70
    // 0xb9e4a0: EnterFrame
    //     0xb9e4a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e4a4: mov             fp, SP
    // 0xb9e4a8: AllocStack(0x10)
    //     0xb9e4a8: sub             SP, SP, #0x10
    // 0xb9e4ac: SetupParameters([dynamic _ /* r0 */])
    //     0xb9e4ac: ldr             x0, [fp, #0x10]
    //     0xb9e4b0: ldur            w1, [x0, #0x17]
    //     0xb9e4b4: add             x1, x1, HEAP, lsl #32
    // 0xb9e4b8: CheckStackOverflow
    //     0xb9e4b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e4bc: cmp             SP, x16
    //     0xb9e4c0: b.ls            #0xb9e504
    // 0xb9e4c4: LoadField: r0 = r1->field_f
    //     0xb9e4c4: ldur            w0, [x1, #0xf]
    // 0xb9e4c8: DecompressPointer r0
    //     0xb9e4c8: add             x0, x0, HEAP, lsl #32
    // 0xb9e4cc: LoadField: r2 = r0->field_33
    //     0xb9e4cc: ldur            w2, [x0, #0x33]
    // 0xb9e4d0: DecompressPointer r2
    //     0xb9e4d0: add             x2, x2, HEAP, lsl #32
    // 0xb9e4d4: cmp             w2, NULL
    // 0xb9e4d8: b.eq            #0xb9e50c
    // 0xb9e4dc: LoadField: r0 = r1->field_13
    //     0xb9e4dc: ldur            w0, [x1, #0x13]
    // 0xb9e4e0: DecompressPointer r0
    //     0xb9e4e0: add             x0, x0, HEAP, lsl #32
    // 0xb9e4e4: stp             x0, x2, [SP]
    // 0xb9e4e8: mov             x0, x2
    // 0xb9e4ec: ClosureCall
    //     0xb9e4ec: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb9e4f0: ldur            x2, [x0, #0x1f]
    //     0xb9e4f4: blr             x2
    // 0xb9e4f8: LeaveFrame
    //     0xb9e4f8: mov             SP, fp
    //     0xb9e4fc: ldp             fp, lr, [SP], #0x10
    // 0xb9e500: ret
    //     0xb9e500: ret             
    // 0xb9e504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e508: b               #0xb9e4c4
    // 0xb9e50c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9e50c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDrag(/* No info */) {
    // ** addr: 0xb9e510, size: 0x2ac
    // 0xb9e510: EnterFrame
    //     0xb9e510: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e514: mov             fp, SP
    // 0xb9e518: AllocStack(0x38)
    //     0xb9e518: sub             SP, SP, #0x38
    // 0xb9e51c: SetupParameters(DragGestureRecognizer this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */)
    //     0xb9e51c: mov             x4, x1
    //     0xb9e520: mov             x3, x2
    //     0xb9e524: stur            x1, [fp, #-0x18]
    //     0xb9e528: stur            x2, [fp, #-0x20]
    // 0xb9e52c: CheckStackOverflow
    //     0xb9e52c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e530: cmp             SP, x16
    //     0xb9e534: b.ls            #0xb9e790
    // 0xb9e538: LoadField: r0 = r4->field_53
    //     0xb9e538: ldur            w0, [x4, #0x53]
    // 0xb9e53c: DecompressPointer r0
    //     0xb9e53c: add             x0, x0, HEAP, lsl #32
    // 0xb9e540: r16 = Instance__DragState
    //     0xb9e540: add             x16, PP, #0x26, lsl #12  ; [pp+0x26618] Obj!_DragState@12c5d21
    //     0xb9e544: ldr             x16, [x16, #0x618]
    // 0xb9e548: cmp             w0, w16
    // 0xb9e54c: b.ne            #0xb9e560
    // 0xb9e550: r0 = Null
    //     0xb9e550: mov             x0, NULL
    // 0xb9e554: LeaveFrame
    //     0xb9e554: mov             SP, fp
    //     0xb9e558: ldp             fp, lr, [SP], #0x10
    // 0xb9e55c: ret
    //     0xb9e55c: ret             
    // 0xb9e560: r0 = Instance__DragState
    //     0xb9e560: add             x0, PP, #0x26, lsl #12  ; [pp+0x26618] Obj!_DragState@12c5d21
    //     0xb9e564: ldr             x0, [x0, #0x618]
    // 0xb9e568: StoreField: r4->field_53 = r0
    //     0xb9e568: stur            w0, [x4, #0x53]
    // 0xb9e56c: LoadField: r2 = r4->field_5b
    //     0xb9e56c: ldur            w2, [x4, #0x5b]
    // 0xb9e570: DecompressPointer r2
    //     0xb9e570: add             x2, x2, HEAP, lsl #32
    // 0xb9e574: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9e578: cmp             w2, w16
    // 0xb9e57c: b.eq            #0xb9e798
    // 0xb9e580: LoadField: r5 = r4->field_63
    //     0xb9e580: ldur            w5, [x4, #0x63]
    // 0xb9e584: DecompressPointer r5
    //     0xb9e584: add             x5, x5, HEAP, lsl #32
    // 0xb9e588: stur            x5, [fp, #-0x10]
    // 0xb9e58c: LoadField: r6 = r4->field_6b
    //     0xb9e58c: ldur            w6, [x4, #0x6b]
    // 0xb9e590: DecompressPointer r6
    //     0xb9e590: add             x6, x6, HEAP, lsl #32
    // 0xb9e594: stur            x6, [fp, #-8]
    // 0xb9e598: LoadField: r0 = r4->field_23
    //     0xb9e598: ldur            w0, [x4, #0x23]
    // 0xb9e59c: DecompressPointer r0
    //     0xb9e59c: add             x0, x0, HEAP, lsl #32
    // 0xb9e5a0: LoadField: r1 = r0->field_7
    //     0xb9e5a0: ldur            x1, [x0, #7]
    // 0xb9e5a4: cmp             x1, #0
    // 0xb9e5a8: b.gt            #0xb9e5e4
    // 0xb9e5ac: LoadField: r0 = r2->field_7
    //     0xb9e5ac: ldur            w0, [x2, #7]
    // 0xb9e5b0: DecompressPointer r0
    //     0xb9e5b0: add             x0, x0, HEAP, lsl #32
    // 0xb9e5b4: r1 = LoadClassIdInstr(r4)
    //     0xb9e5b4: ldur            x1, [x4, #-1]
    //     0xb9e5b8: ubfx            x1, x1, #0xc, #0x14
    // 0xb9e5bc: mov             x2, x0
    // 0xb9e5c0: mov             x0, x1
    // 0xb9e5c4: mov             x1, x4
    // 0xb9e5c8: r0 = GDT[cid_x0 + 0x16dc]()
    //     0xb9e5c8: mov             x17, #0x16dc
    //     0xb9e5cc: add             lr, x0, x17
    //     0xb9e5d0: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e5d4: blr             lr
    // 0xb9e5d8: mov             x5, x0
    // 0xb9e5dc: ldur            x4, [fp, #-0x18]
    // 0xb9e5e0: b               #0xb9e624
    // 0xb9e5e4: mov             x0, x4
    // 0xb9e5e8: LoadField: r1 = r0->field_57
    //     0xb9e5e8: ldur            w1, [x0, #0x57]
    // 0xb9e5ec: DecompressPointer r1
    //     0xb9e5ec: add             x1, x1, HEAP, lsl #32
    // 0xb9e5f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9e5f4: cmp             w1, w16
    // 0xb9e5f8: b.eq            #0xb9e7a4
    // 0xb9e5fc: r0 = +()
    //     0xb9e5fc: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb9e600: ldur            x4, [fp, #-0x18]
    // 0xb9e604: StoreField: r4->field_57 = r0
    //     0xb9e604: stur            w0, [x4, #0x57]
    //     0xb9e608: ldurb           w16, [x4, #-1]
    //     0xb9e60c: ldurb           w17, [x0, #-1]
    //     0xb9e610: and             x16, x17, x16, lsr #2
    //     0xb9e614: tst             x16, HEAP, lsr #32
    //     0xb9e618: b.eq            #0xb9e620
    //     0xb9e61c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xb9e620: r5 = Instance_Offset
    //     0xb9e620: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9e624: r0 = Instance_OffsetPair
    //     0xb9e624: add             x0, PP, #0x26, lsl #12  ; [pp+0x26620] Obj!OffsetPair@129f151
    //     0xb9e628: ldr             x0, [x0, #0x620]
    // 0xb9e62c: stur            x5, [fp, #-0x28]
    // 0xb9e630: StoreField: r4->field_5b = r0
    //     0xb9e630: stur            w0, [x4, #0x5b]
    // 0xb9e634: StoreField: r4->field_63 = rNULL
    //     0xb9e634: stur            NULL, [x4, #0x63]
    // 0xb9e638: StoreField: r4->field_6b = rNULL
    //     0xb9e638: stur            NULL, [x4, #0x6b]
    // 0xb9e63c: mov             x1, x4
    // 0xb9e640: ldur            x2, [fp, #-0x10]
    // 0xb9e644: ldur            x3, [fp, #-0x20]
    // 0xb9e648: r0 = _checkStart()
    //     0xb9e648: bl              #0xb9e7bc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkStart
    // 0xb9e64c: ldur            x16, [fp, #-0x28]
    // 0xb9e650: r30 = Instance_Offset
    //     0xb9e650: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9e654: stp             lr, x16, [SP]
    // 0xb9e658: r0 = ==()
    //     0xb9e658: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb9e65c: tbz             w0, #4, #0xb9e770
    // 0xb9e660: ldur            x0, [fp, #-0x18]
    // 0xb9e664: LoadField: r1 = r0->field_33
    //     0xb9e664: ldur            w1, [x0, #0x33]
    // 0xb9e668: DecompressPointer r1
    //     0xb9e668: add             x1, x1, HEAP, lsl #32
    // 0xb9e66c: cmp             w1, NULL
    // 0xb9e670: b.eq            #0xb9e770
    // 0xb9e674: ldur            x1, [fp, #-8]
    // 0xb9e678: cmp             w1, NULL
    // 0xb9e67c: b.eq            #0xb9e68c
    // 0xb9e680: r0 = tryInvert()
    //     0xb9e680: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xb9e684: mov             x4, x0
    // 0xb9e688: b               #0xb9e690
    // 0xb9e68c: r4 = Null
    //     0xb9e68c: mov             x4, NULL
    // 0xb9e690: ldur            x0, [fp, #-0x18]
    // 0xb9e694: ldur            x3, [fp, #-0x28]
    // 0xb9e698: stur            x4, [fp, #-8]
    // 0xb9e69c: LoadField: r1 = r0->field_57
    //     0xb9e69c: ldur            w1, [x0, #0x57]
    // 0xb9e6a0: DecompressPointer r1
    //     0xb9e6a0: add             x1, x1, HEAP, lsl #32
    // 0xb9e6a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9e6a8: cmp             w1, w16
    // 0xb9e6ac: b.eq            #0xb9e7b0
    // 0xb9e6b0: LoadField: r2 = r1->field_7
    //     0xb9e6b0: ldur            w2, [x1, #7]
    // 0xb9e6b4: DecompressPointer r2
    //     0xb9e6b4: add             x2, x2, HEAP, lsl #32
    // 0xb9e6b8: mov             x1, x2
    // 0xb9e6bc: mov             x2, x3
    // 0xb9e6c0: r0 = +()
    //     0xb9e6c0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb9e6c4: ldur            x1, [fp, #-8]
    // 0xb9e6c8: ldur            x2, [fp, #-0x28]
    // 0xb9e6cc: mov             x3, x0
    // 0xb9e6d0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb9e6d0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb9e6d4: r0 = transformDeltaViaPositions()
    //     0xb9e6d4: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xb9e6d8: stur            x0, [fp, #-8]
    // 0xb9e6dc: r0 = OffsetPair()
    //     0xb9e6dc: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb9e6e0: mov             x1, x0
    // 0xb9e6e4: ldur            x0, [fp, #-0x28]
    // 0xb9e6e8: StoreField: r1->field_7 = r0
    //     0xb9e6e8: stur            w0, [x1, #7]
    // 0xb9e6ec: ldur            x2, [fp, #-8]
    // 0xb9e6f0: StoreField: r1->field_b = r2
    //     0xb9e6f0: stur            w2, [x1, #0xb]
    // 0xb9e6f4: ldur            x3, [fp, #-0x18]
    // 0xb9e6f8: LoadField: r2 = r3->field_57
    //     0xb9e6f8: ldur            w2, [x3, #0x57]
    // 0xb9e6fc: DecompressPointer r2
    //     0xb9e6fc: add             x2, x2, HEAP, lsl #32
    // 0xb9e700: mov             x16, x1
    // 0xb9e704: mov             x1, x2
    // 0xb9e708: mov             x2, x16
    // 0xb9e70c: r0 = +()
    //     0xb9e70c: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb9e710: mov             x4, x0
    // 0xb9e714: ldur            x3, [fp, #-0x18]
    // 0xb9e718: stur            x4, [fp, #-8]
    // 0xb9e71c: r0 = LoadClassIdInstr(r3)
    //     0xb9e71c: ldur            x0, [x3, #-1]
    //     0xb9e720: ubfx            x0, x0, #0xc, #0x14
    // 0xb9e724: mov             x1, x3
    // 0xb9e728: ldur            x2, [fp, #-0x28]
    // 0xb9e72c: r0 = GDT[cid_x0 + 0x2cb6]()
    //     0xb9e72c: mov             x17, #0x2cb6
    //     0xb9e730: add             lr, x0, x17
    //     0xb9e734: ldr             lr, [x21, lr, lsl #3]
    //     0xb9e738: blr             lr
    // 0xb9e73c: mov             x1, x0
    // 0xb9e740: ldur            x0, [fp, #-8]
    // 0xb9e744: LoadField: r3 = r0->field_b
    //     0xb9e744: ldur            w3, [x0, #0xb]
    // 0xb9e748: DecompressPointer r3
    //     0xb9e748: add             x3, x3, HEAP, lsl #32
    // 0xb9e74c: LoadField: r5 = r0->field_7
    //     0xb9e74c: ldur            w5, [x0, #7]
    // 0xb9e750: DecompressPointer r5
    //     0xb9e750: add             x5, x5, HEAP, lsl #32
    // 0xb9e754: ldur            x16, [fp, #-0x10]
    // 0xb9e758: str             x16, [SP]
    // 0xb9e75c: mov             x7, x1
    // 0xb9e760: ldur            x1, [fp, #-0x18]
    // 0xb9e764: ldur            x2, [fp, #-0x28]
    // 0xb9e768: ldur            x6, [fp, #-0x20]
    // 0xb9e76c: r0 = _checkUpdate()
    //     0xb9e76c: bl              #0xb9e378  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate
    // 0xb9e770: ldur            x1, [fp, #-0x18]
    // 0xb9e774: r2 = Instance_GestureDisposition
    //     0xb9e774: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xb9e778: ldr             x2, [x2, #0x628]
    // 0xb9e77c: r0 = resolve()
    //     0xb9e77c: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb9e780: r0 = Null
    //     0xb9e780: mov             x0, NULL
    // 0xb9e784: LeaveFrame
    //     0xb9e784: mov             SP, fp
    //     0xb9e788: ldp             fp, lr, [SP], #0x10
    // 0xb9e78c: ret
    //     0xb9e78c: ret             
    // 0xb9e790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e794: b               #0xb9e538
    // 0xb9e798: r9 = _pendingDragOffset
    //     0xb9e798: add             x9, PP, #0x26, lsl #12  ; [pp+0x26630] Field <DragGestureRecognizer._pendingDragOffset@658099969>: late (offset: 0x5c)
    //     0xb9e79c: ldr             x9, [x9, #0x630]
    // 0xb9e7a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e7a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb9e7a4: r9 = _initialPosition
    //     0xb9e7a4: add             x9, PP, #0x26, lsl #12  ; [pp+0x26638] Field <DragGestureRecognizer._initialPosition@658099969>: late (offset: 0x58)
    //     0xb9e7a8: ldr             x9, [x9, #0x638]
    // 0xb9e7ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e7ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb9e7b0: r9 = _initialPosition
    //     0xb9e7b0: add             x9, PP, #0x26, lsl #12  ; [pp+0x26638] Field <DragGestureRecognizer._initialPosition@658099969>: late (offset: 0x58)
    //     0xb9e7b4: ldr             x9, [x9, #0x638]
    // 0xb9e7b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e7b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _checkStart(/* No info */) {
    // ** addr: 0xb9e7bc, size: 0x128
    // 0xb9e7bc: EnterFrame
    //     0xb9e7bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e7c0: mov             fp, SP
    // 0xb9e7c4: AllocStack(0x50)
    //     0xb9e7c4: sub             SP, SP, #0x50
    // 0xb9e7c8: SetupParameters(DragGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb9e7c8: mov             x0, x2
    //     0xb9e7cc: stur            x2, [fp, #-0x10]
    //     0xb9e7d0: mov             x2, x3
    //     0xb9e7d4: stur            x1, [fp, #-8]
    //     0xb9e7d8: stur            x3, [fp, #-0x18]
    // 0xb9e7dc: CheckStackOverflow
    //     0xb9e7dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e7e0: cmp             SP, x16
    //     0xb9e7e4: b.ls            #0xb9e8d0
    // 0xb9e7e8: r1 = 2
    //     0xb9e7e8: mov             x1, #2
    // 0xb9e7ec: r0 = AllocateContext()
    //     0xb9e7ec: bl              #0x13de838  ; AllocateContextStub
    // 0xb9e7f0: mov             x3, x0
    // 0xb9e7f4: ldur            x0, [fp, #-8]
    // 0xb9e7f8: stur            x3, [fp, #-0x30]
    // 0xb9e7fc: StoreField: r3->field_f = r0
    //     0xb9e7fc: stur            w0, [x3, #0xf]
    // 0xb9e800: LoadField: r1 = r0->field_2f
    //     0xb9e800: ldur            w1, [x0, #0x2f]
    // 0xb9e804: DecompressPointer r1
    //     0xb9e804: add             x1, x1, HEAP, lsl #32
    // 0xb9e808: cmp             w1, NULL
    // 0xb9e80c: b.eq            #0xb9e8c0
    // 0xb9e810: ldur            x4, [fp, #-0x10]
    // 0xb9e814: LoadField: r1 = r0->field_57
    //     0xb9e814: ldur            w1, [x0, #0x57]
    // 0xb9e818: DecompressPointer r1
    //     0xb9e818: add             x1, x1, HEAP, lsl #32
    // 0xb9e81c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9e820: cmp             w1, w16
    // 0xb9e824: b.eq            #0xb9e8d8
    // 0xb9e828: LoadField: r5 = r1->field_b
    //     0xb9e828: ldur            w5, [x1, #0xb]
    // 0xb9e82c: DecompressPointer r5
    //     0xb9e82c: add             x5, x5, HEAP, lsl #32
    // 0xb9e830: stur            x5, [fp, #-0x28]
    // 0xb9e834: LoadField: r6 = r1->field_7
    //     0xb9e834: ldur            w6, [x1, #7]
    // 0xb9e838: DecompressPointer r6
    //     0xb9e838: add             x6, x6, HEAP, lsl #32
    // 0xb9e83c: mov             x1, x0
    // 0xb9e840: ldur            x2, [fp, #-0x18]
    // 0xb9e844: stur            x6, [fp, #-0x20]
    // 0xb9e848: r0 = getKindForPointer()
    //     0xb9e848: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xb9e84c: stur            x0, [fp, #-0x38]
    // 0xb9e850: r0 = DragStartDetails()
    //     0xb9e850: bl              #0x87110c  ; AllocateDragStartDetailsStub -> DragStartDetails (size=0x18)
    // 0xb9e854: mov             x1, x0
    // 0xb9e858: ldur            x0, [fp, #-0x28]
    // 0xb9e85c: StoreField: r1->field_7 = r0
    //     0xb9e85c: stur            w0, [x1, #7]
    // 0xb9e860: ldur            x0, [fp, #-0x10]
    // 0xb9e864: StoreField: r1->field_f = r0
    //     0xb9e864: stur            w0, [x1, #0xf]
    // 0xb9e868: ldur            x0, [fp, #-0x38]
    // 0xb9e86c: StoreField: r1->field_13 = r0
    //     0xb9e86c: stur            w0, [x1, #0x13]
    // 0xb9e870: ldur            x0, [fp, #-0x20]
    // 0xb9e874: StoreField: r1->field_b = r0
    //     0xb9e874: stur            w0, [x1, #0xb]
    // 0xb9e878: mov             x0, x1
    // 0xb9e87c: ldur            x2, [fp, #-0x30]
    // 0xb9e880: StoreField: r2->field_13 = r0
    //     0xb9e880: stur            w0, [x2, #0x13]
    //     0xb9e884: ldurb           w16, [x2, #-1]
    //     0xb9e888: ldurb           w17, [x0, #-1]
    //     0xb9e88c: and             x16, x17, x16, lsr #2
    //     0xb9e890: tst             x16, HEAP, lsr #32
    //     0xb9e894: b.eq            #0xb9e89c
    //     0xb9e898: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9e89c: r1 = Function '<anonymous closure>':.
    //     0xb9e89c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26678] AnonymousClosure: (0xb9e8e4), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkStart (0xb9e7bc)
    //     0xb9e8a0: ldr             x1, [x1, #0x678]
    // 0xb9e8a4: r0 = AllocateClosure()
    //     0xb9e8a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9e8a8: r16 = <void?>
    //     0xb9e8a8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb9e8ac: ldur            lr, [fp, #-8]
    // 0xb9e8b0: stp             lr, x16, [SP, #8]
    // 0xb9e8b4: str             x0, [SP]
    // 0xb9e8b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9e8b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb9e8bc: r0 = invokeCallback()
    //     0xb9e8bc: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb9e8c0: r0 = Null
    //     0xb9e8c0: mov             x0, NULL
    // 0xb9e8c4: LeaveFrame
    //     0xb9e8c4: mov             SP, fp
    //     0xb9e8c8: ldp             fp, lr, [SP], #0x10
    // 0xb9e8cc: ret
    //     0xb9e8cc: ret             
    // 0xb9e8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e8d4: b               #0xb9e7e8
    // 0xb9e8d8: r9 = _initialPosition
    //     0xb9e8d8: add             x9, PP, #0x26, lsl #12  ; [pp+0x26638] Field <DragGestureRecognizer._initialPosition@658099969>: late (offset: 0x58)
    //     0xb9e8dc: ldr             x9, [x9, #0x638]
    // 0xb9e8e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9e8e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb9e8e4, size: 0x70
    // 0xb9e8e4: EnterFrame
    //     0xb9e8e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e8e8: mov             fp, SP
    // 0xb9e8ec: AllocStack(0x10)
    //     0xb9e8ec: sub             SP, SP, #0x10
    // 0xb9e8f0: SetupParameters([dynamic _ /* r0 */])
    //     0xb9e8f0: ldr             x0, [fp, #0x10]
    //     0xb9e8f4: ldur            w1, [x0, #0x17]
    //     0xb9e8f8: add             x1, x1, HEAP, lsl #32
    // 0xb9e8fc: CheckStackOverflow
    //     0xb9e8fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e900: cmp             SP, x16
    //     0xb9e904: b.ls            #0xb9e948
    // 0xb9e908: LoadField: r0 = r1->field_f
    //     0xb9e908: ldur            w0, [x1, #0xf]
    // 0xb9e90c: DecompressPointer r0
    //     0xb9e90c: add             x0, x0, HEAP, lsl #32
    // 0xb9e910: LoadField: r2 = r0->field_2f
    //     0xb9e910: ldur            w2, [x0, #0x2f]
    // 0xb9e914: DecompressPointer r2
    //     0xb9e914: add             x2, x2, HEAP, lsl #32
    // 0xb9e918: cmp             w2, NULL
    // 0xb9e91c: b.eq            #0xb9e950
    // 0xb9e920: LoadField: r0 = r1->field_13
    //     0xb9e920: ldur            w0, [x1, #0x13]
    // 0xb9e924: DecompressPointer r0
    //     0xb9e924: add             x0, x0, HEAP, lsl #32
    // 0xb9e928: stp             x0, x2, [SP]
    // 0xb9e92c: mov             x0, x2
    // 0xb9e930: ClosureCall
    //     0xb9e930: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb9e934: ldur            x2, [x0, #0x1f]
    //     0xb9e938: blr             x2
    // 0xb9e93c: LeaveFrame
    //     0xb9e93c: mov             SP, fp
    //     0xb9e940: ldp             fp, lr, [SP], #0x10
    // 0xb9e944: ret
    //     0xb9e944: ret             
    // 0xb9e948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9e948: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9e94c: b               #0xb9e908
    // 0xb9e950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9e950: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolveLocalDeltaForMultitouch(/* No info */) {
    // ** addr: 0xb9e970, size: 0x2ec
    // 0xb9e970: EnterFrame
    //     0xb9e970: stp             fp, lr, [SP, #-0x10]!
    //     0xb9e974: mov             fp, SP
    // 0xb9e978: AllocStack(0x40)
    //     0xb9e978: sub             SP, SP, #0x40
    // 0xb9e97c: SetupParameters(DragGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x20 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xb9e97c: mov             x5, x2
    //     0xb9e980: stur            x2, [fp, #-0x20]
    //     0xb9e984: mov             x2, x1
    //     0xb9e988: mov             x0, x3
    //     0xb9e98c: stur            x1, [fp, #-8]
    //     0xb9e990: stur            x3, [fp, #-0x10]
    // 0xb9e994: CheckStackOverflow
    //     0xb9e994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9e998: cmp             SP, x16
    //     0xb9e99c: b.ls            #0xb9ec50
    // 0xb9e9a0: LoadField: r1 = r2->field_27
    //     0xb9e9a0: ldur            w1, [x2, #0x27]
    // 0xb9e9a4: DecompressPointer r1
    //     0xb9e9a4: add             x1, x1, HEAP, lsl #32
    // 0xb9e9a8: r16 = Instance_MultitouchDragStrategy
    //     0xb9e9a8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b80] Obj!MultitouchDragStrategy@12c5c41
    //     0xb9e9ac: ldr             x16, [x16, #0xb80]
    // 0xb9e9b0: cmp             w1, w16
    // 0xb9e9b4: b.eq            #0xb9e9f4
    // 0xb9e9b8: LoadField: r1 = r2->field_7f
    //     0xb9e9b8: ldur            w1, [x2, #0x7f]
    // 0xb9e9bc: DecompressPointer r1
    //     0xb9e9bc: add             x1, x1, HEAP, lsl #32
    // 0xb9e9c0: cmp             w1, NULL
    // 0xb9e9c4: b.eq            #0xb9e9e4
    // 0xb9e9c8: LoadField: r1 = r2->field_7b
    //     0xb9e9c8: ldur            w1, [x2, #0x7b]
    // 0xb9e9cc: DecompressPointer r1
    //     0xb9e9cc: add             x1, x1, HEAP, lsl #32
    // 0xb9e9d0: r0 = clear()
    //     0xb9e9d0: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xb9e9d4: ldur            x1, [fp, #-8]
    // 0xb9e9d8: StoreField: r1->field_7f = rNULL
    //     0xb9e9d8: stur            NULL, [x1, #0x7f]
    // 0xb9e9dc: r2 = Instance_Offset
    //     0xb9e9dc: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9e9e0: StoreField: r1->field_83 = r2
    //     0xb9e9e0: stur            w2, [x1, #0x83]
    // 0xb9e9e4: ldur            x0, [fp, #-0x10]
    // 0xb9e9e8: LeaveFrame
    //     0xb9e9e8: mov             SP, fp
    //     0xb9e9ec: ldp             fp, lr, [SP], #0x10
    // 0xb9e9f0: ret
    //     0xb9e9f0: ret             
    // 0xb9e9f4: mov             x1, x2
    // 0xb9e9f8: r2 = Instance_Offset
    //     0xb9e9f8: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9e9fc: r0 = LoadStaticField(0x5e4)
    //     0xb9e9fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb9ea00: ldr             x0, [x0, #0xbc8]
    // 0xb9ea04: cmp             w0, NULL
    // 0xb9ea08: b.eq            #0xb9ec58
    // 0xb9ea0c: LoadField: r3 = r0->field_73
    //     0xb9ea0c: ldur            w3, [x0, #0x73]
    // 0xb9ea10: DecompressPointer r3
    //     0xb9ea10: add             x3, x3, HEAP, lsl #32
    // 0xb9ea14: stur            x3, [fp, #-0x18]
    // 0xb9ea18: LoadField: r0 = r1->field_7f
    //     0xb9ea18: ldur            w0, [x1, #0x7f]
    // 0xb9ea1c: DecompressPointer r0
    //     0xb9ea1c: add             x0, x0, HEAP, lsl #32
    // 0xb9ea20: r4 = LoadClassIdInstr(r0)
    //     0xb9ea20: ldur            x4, [x0, #-1]
    //     0xb9ea24: ubfx            x4, x4, #0xc, #0x14
    // 0xb9ea28: stp             x3, x0, [SP]
    // 0xb9ea2c: mov             x0, x4
    // 0xb9ea30: mov             lr, x0
    // 0xb9ea34: ldr             lr, [x21, lr, lsl #3]
    // 0xb9ea38: blr             lr
    // 0xb9ea3c: tbz             w0, #4, #0xb9ea80
    // 0xb9ea40: ldur            x0, [fp, #-8]
    // 0xb9ea44: LoadField: r1 = r0->field_7b
    //     0xb9ea44: ldur            w1, [x0, #0x7b]
    // 0xb9ea48: DecompressPointer r1
    //     0xb9ea48: add             x1, x1, HEAP, lsl #32
    // 0xb9ea4c: r0 = clear()
    //     0xb9ea4c: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xb9ea50: ldur            x2, [fp, #-8]
    // 0xb9ea54: r0 = Instance_Offset
    //     0xb9ea54: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9ea58: StoreField: r2->field_83 = r0
    //     0xb9ea58: stur            w0, [x2, #0x83]
    // 0xb9ea5c: ldur            x0, [fp, #-0x18]
    // 0xb9ea60: StoreField: r2->field_7f = r0
    //     0xb9ea60: stur            w0, [x2, #0x7f]
    //     0xb9ea64: ldurb           w16, [x2, #-1]
    //     0xb9ea68: ldurb           w17, [x0, #-1]
    //     0xb9ea6c: and             x16, x17, x16, lsr #2
    //     0xb9ea70: tst             x16, HEAP, lsr #32
    //     0xb9ea74: b.eq            #0xb9ea7c
    //     0xb9ea78: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9ea7c: b               #0xb9ea84
    // 0xb9ea80: ldur            x2, [fp, #-8]
    // 0xb9ea84: r0 = LoadClassIdInstr(r2)
    //     0xb9ea84: ldur            x0, [x2, #-1]
    //     0xb9ea88: ubfx            x0, x0, #0xc, #0x14
    // 0xb9ea8c: mov             x1, x2
    // 0xb9ea90: r0 = GDT[cid_x0 + 0x1b52]()
    //     0xb9ea90: mov             x17, #0x1b52
    //     0xb9ea94: add             lr, x0, x17
    //     0xb9ea98: ldr             lr, [x21, lr, lsl #3]
    //     0xb9ea9c: blr             lr
    // 0xb9eaa0: ldur            x1, [fp, #-8]
    // 0xb9eaa4: stur            x0, [fp, #-0x18]
    // 0xb9eaa8: LoadField: r2 = r1->field_53
    //     0xb9eaa8: ldur            w2, [x1, #0x53]
    // 0xb9eaac: DecompressPointer r2
    //     0xb9eaac: add             x2, x2, HEAP, lsl #32
    // 0xb9eab0: r16 = Instance__DragState
    //     0xb9eab0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26618] Obj!_DragState@12c5d21
    //     0xb9eab4: ldr             x16, [x16, #0x618]
    // 0xb9eab8: cmp             w2, w16
    // 0xb9eabc: b.ne            #0xb9eb08
    // 0xb9eac0: ldur            x16, [fp, #-0x10]
    // 0xb9eac4: r30 = Instance_Offset
    //     0xb9eac4: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb9eac8: stp             lr, x16, [SP]
    // 0xb9eacc: r0 = ==()
    //     0xb9eacc: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb9ead0: tbz             w0, #4, #0xb9eb08
    // 0xb9ead4: ldur            x0, [fp, #-8]
    // 0xb9ead8: LoadField: r1 = r0->field_7b
    //     0xb9ead8: ldur            w1, [x0, #0x7b]
    // 0xb9eadc: DecompressPointer r1
    //     0xb9eadc: add             x1, x1, HEAP, lsl #32
    // 0xb9eae0: LoadField: r2 = r1->field_13
    //     0xb9eae0: ldur            w2, [x1, #0x13]
    // 0xb9eae4: r3 = LoadInt32Instr(r2)
    //     0xb9eae4: sbfx            x3, x2, #1, #0x1f
    // 0xb9eae8: asr             x2, x3, #1
    // 0xb9eaec: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xb9eaec: ldur            w3, [x1, #0x17]
    // 0xb9eaf0: r1 = LoadInt32Instr(r3)
    //     0xb9eaf0: sbfx            x1, x3, #1, #0x1f
    // 0xb9eaf4: sub             x3, x2, x1
    // 0xb9eaf8: cbnz            x3, #0xb9eb18
    // 0xb9eafc: ldur            x1, [fp, #-0x18]
    // 0xb9eb00: cmp             w1, NULL
    // 0xb9eb04: b.eq            #0xb9eb1c
    // 0xb9eb08: ldur            x0, [fp, #-0x10]
    // 0xb9eb0c: LeaveFrame
    //     0xb9eb0c: mov             SP, fp
    //     0xb9eb10: ldp             fp, lr, [SP], #0x10
    // 0xb9eb14: ret
    //     0xb9eb14: ret             
    // 0xb9eb18: ldur            x1, [fp, #-0x18]
    // 0xb9eb1c: r16 = Instance__DragDirection
    //     0xb9eb1c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9eb20: ldr             x16, [x16, #0xb88]
    // 0xb9eb24: cmp             w1, w16
    // 0xb9eb28: b.ne            #0xb9eb50
    // 0xb9eb2c: mov             x1, x0
    // 0xb9eb30: ldur            x3, [fp, #-0x10]
    // 0xb9eb34: ldur            x5, [fp, #-0x20]
    // 0xb9eb38: r2 = Instance__DragDirection
    //     0xb9eb38: add             x2, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9eb3c: ldr             x2, [x2, #0xb88]
    // 0xb9eb40: r0 = _resolveDelta()
    //     0xb9eb40: bl              #0xb9edcc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_resolveDelta
    // 0xb9eb44: mov             v1.16b, v0.16b
    // 0xb9eb48: d0 = 0.000000
    //     0xb9eb48: eor             v0.16b, v0.16b, v0.16b
    // 0xb9eb4c: b               #0xb9ec28
    // 0xb9eb50: r16 = Instance__DragDirection
    //     0xb9eb50: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0xb9eb54: ldr             x16, [x16, #0xb90]
    // 0xb9eb58: cmp             w1, w16
    // 0xb9eb5c: b.ne            #0xb9eb80
    // 0xb9eb60: mov             x1, x0
    // 0xb9eb64: ldur            x3, [fp, #-0x10]
    // 0xb9eb68: ldur            x5, [fp, #-0x20]
    // 0xb9eb6c: r2 = Instance__DragDirection
    //     0xb9eb6c: add             x2, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0xb9eb70: ldr             x2, [x2, #0xb90]
    // 0xb9eb74: r0 = _resolveDelta()
    //     0xb9eb74: bl              #0xb9edcc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_resolveDelta
    // 0xb9eb78: d1 = 0.000000
    //     0xb9eb78: eor             v1.16b, v1.16b, v1.16b
    // 0xb9eb7c: b               #0xb9ec28
    // 0xb9eb80: mov             x1, x0
    // 0xb9eb84: ldur            x3, [fp, #-0x10]
    // 0xb9eb88: r2 = Instance__DragDirection
    //     0xb9eb88: add             x2, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9eb8c: ldr             x2, [x2, #0xb88]
    // 0xb9eb90: r0 = _resolveDeltaForPanGesture()
    //     0xb9eb90: bl              #0xb9ec5c  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_resolveDeltaForPanGesture
    // 0xb9eb94: ldur            x1, [fp, #-8]
    // 0xb9eb98: ldur            x3, [fp, #-0x10]
    // 0xb9eb9c: r2 = Instance__DragDirection
    //     0xb9eb9c: add             x2, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0xb9eba0: ldr             x2, [x2, #0xb90]
    // 0xb9eba4: stur            d0, [fp, #-0x28]
    // 0xb9eba8: r0 = _resolveDeltaForPanGesture()
    //     0xb9eba8: bl              #0xb9ec5c  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_resolveDeltaForPanGesture
    // 0xb9ebac: stur            d0, [fp, #-0x30]
    // 0xb9ebb0: r0 = Offset()
    //     0xb9ebb0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb9ebb4: ldur            d0, [fp, #-0x28]
    // 0xb9ebb8: StoreField: r0->field_7 = d0
    //     0xb9ebb8: stur            d0, [x0, #7]
    // 0xb9ebbc: ldur            d1, [fp, #-0x30]
    // 0xb9ebc0: StoreField: r0->field_f = d1
    //     0xb9ebc0: stur            d1, [x0, #0xf]
    // 0xb9ebc4: ldur            x3, [fp, #-8]
    // 0xb9ebc8: LoadField: r2 = r3->field_83
    //     0xb9ebc8: ldur            w2, [x3, #0x83]
    // 0xb9ebcc: DecompressPointer r2
    //     0xb9ebcc: add             x2, x2, HEAP, lsl #32
    // 0xb9ebd0: mov             x1, x0
    // 0xb9ebd4: r0 = -()
    //     0xb9ebd4: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb9ebd8: stur            x0, [fp, #-0x10]
    // 0xb9ebdc: r0 = Offset()
    //     0xb9ebdc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb9ebe0: ldur            d0, [fp, #-0x28]
    // 0xb9ebe4: StoreField: r0->field_7 = d0
    //     0xb9ebe4: stur            d0, [x0, #7]
    // 0xb9ebe8: ldur            d0, [fp, #-0x30]
    // 0xb9ebec: StoreField: r0->field_f = d0
    //     0xb9ebec: stur            d0, [x0, #0xf]
    // 0xb9ebf0: ldur            x1, [fp, #-8]
    // 0xb9ebf4: StoreField: r1->field_83 = r0
    //     0xb9ebf4: stur            w0, [x1, #0x83]
    //     0xb9ebf8: ldurb           w16, [x1, #-1]
    //     0xb9ebfc: ldurb           w17, [x0, #-1]
    //     0xb9ec00: and             x16, x17, x16, lsr #2
    //     0xb9ec04: tst             x16, HEAP, lsr #32
    //     0xb9ec08: b.eq            #0xb9ec10
    //     0xb9ec0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb9ec10: ldur            x0, [fp, #-0x10]
    // 0xb9ec14: LoadField: d0 = r0->field_7
    //     0xb9ec14: ldur            d0, [x0, #7]
    // 0xb9ec18: LoadField: d1 = r0->field_f
    //     0xb9ec18: ldur            d1, [x0, #0xf]
    // 0xb9ec1c: mov             v31.16b, v1.16b
    // 0xb9ec20: mov             v1.16b, v0.16b
    // 0xb9ec24: mov             v0.16b, v31.16b
    // 0xb9ec28: stur            d1, [fp, #-0x28]
    // 0xb9ec2c: stur            d0, [fp, #-0x30]
    // 0xb9ec30: r0 = Offset()
    //     0xb9ec30: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb9ec34: ldur            d0, [fp, #-0x28]
    // 0xb9ec38: StoreField: r0->field_7 = d0
    //     0xb9ec38: stur            d0, [x0, #7]
    // 0xb9ec3c: ldur            d0, [fp, #-0x30]
    // 0xb9ec40: StoreField: r0->field_f = d0
    //     0xb9ec40: stur            d0, [x0, #0xf]
    // 0xb9ec44: LeaveFrame
    //     0xb9ec44: mov             SP, fp
    //     0xb9ec48: ldp             fp, lr, [SP], #0x10
    // 0xb9ec4c: ret
    //     0xb9ec4c: ret             
    // 0xb9ec50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9ec50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9ec54: b               #0xb9e9a0
    // 0xb9ec58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9ec58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolveDeltaForPanGesture(/* No info */) {
    // ** addr: 0xb9ec5c, size: 0x170
    // 0xb9ec5c: EnterFrame
    //     0xb9ec5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb9ec60: mov             fp, SP
    // 0xb9ec64: AllocStack(0x30)
    //     0xb9ec64: sub             SP, SP, #0x30
    // 0xb9ec68: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb9ec68: stur            x2, [fp, #-0x18]
    // 0xb9ec6c: CheckStackOverflow
    //     0xb9ec6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9ec70: cmp             SP, x16
    //     0xb9ec74: b.ls            #0xb9edbc
    // 0xb9ec78: r16 = Instance__DragDirection
    //     0xb9ec78: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9ec7c: ldr             x16, [x16, #0xb88]
    // 0xb9ec80: cmp             w2, w16
    // 0xb9ec84: b.ne            #0xb9ec90
    // 0xb9ec88: LoadField: d0 = r3->field_7
    //     0xb9ec88: ldur            d0, [x3, #7]
    // 0xb9ec8c: b               #0xb9ec94
    // 0xb9ec90: LoadField: d0 = r3->field_f
    //     0xb9ec90: ldur            d0, [x3, #0xf]
    // 0xb9ec94: stur            d0, [fp, #-0x30]
    // 0xb9ec98: LoadField: r0 = r1->field_87
    //     0xb9ec98: ldur            w0, [x1, #0x87]
    // 0xb9ec9c: DecompressPointer r0
    //     0xb9ec9c: add             x0, x0, HEAP, lsl #32
    // 0xb9eca0: LoadField: r3 = r0->field_b
    //     0xb9eca0: ldur            w3, [x0, #0xb]
    // 0xb9eca4: stur            x3, [fp, #-0x10]
    // 0xb9eca8: LoadField: r0 = r1->field_7b
    //     0xb9eca8: ldur            w0, [x1, #0x7b]
    // 0xb9ecac: DecompressPointer r0
    //     0xb9ecac: add             x0, x0, HEAP, lsl #32
    // 0xb9ecb0: stur            x0, [fp, #-8]
    // 0xb9ecb4: r1 = <Offset>
    //     0xb9ecb4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xb9ecb8: ldr             x1, [x1, #0xa48]
    // 0xb9ecbc: r0 = _CompactValuesIterable()
    //     0xb9ecbc: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xb9ecc0: mov             x1, x0
    // 0xb9ecc4: ldur            x0, [fp, #-8]
    // 0xb9ecc8: StoreField: r1->field_b = r0
    //     0xb9ecc8: stur            w0, [x1, #0xb]
    // 0xb9eccc: r0 = iterator()
    //     0xb9eccc: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xb9ecd0: stur            x0, [fp, #-0x20]
    // 0xb9ecd4: LoadField: r2 = r0->field_7
    //     0xb9ecd4: ldur            w2, [x0, #7]
    // 0xb9ecd8: DecompressPointer r2
    //     0xb9ecd8: add             x2, x2, HEAP, lsl #32
    // 0xb9ecdc: stur            x2, [fp, #-8]
    // 0xb9ece0: ldur            d0, [fp, #-0x30]
    // 0xb9ece4: ldur            x3, [fp, #-0x18]
    // 0xb9ece8: stur            d0, [fp, #-0x30]
    // 0xb9ecec: CheckStackOverflow
    //     0xb9ecec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9ecf0: cmp             SP, x16
    //     0xb9ecf4: b.ls            #0xb9edc4
    // 0xb9ecf8: mov             x1, x0
    // 0xb9ecfc: r0 = moveNext()
    //     0xb9ecfc: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xb9ed00: tbnz            w0, #4, #0xb9ed9c
    // 0xb9ed04: ldur            x3, [fp, #-0x20]
    // 0xb9ed08: LoadField: r4 = r3->field_33
    //     0xb9ed08: ldur            w4, [x3, #0x33]
    // 0xb9ed0c: DecompressPointer r4
    //     0xb9ed0c: add             x4, x4, HEAP, lsl #32
    // 0xb9ed10: stur            x4, [fp, #-0x28]
    // 0xb9ed14: cmp             w4, NULL
    // 0xb9ed18: b.ne            #0xb9ed4c
    // 0xb9ed1c: mov             x0, x4
    // 0xb9ed20: ldur            x2, [fp, #-8]
    // 0xb9ed24: r1 = Null
    //     0xb9ed24: mov             x1, NULL
    // 0xb9ed28: cmp             w2, NULL
    // 0xb9ed2c: b.eq            #0xb9ed4c
    // 0xb9ed30: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb9ed30: ldur            w4, [x2, #0x17]
    // 0xb9ed34: DecompressPointer r4
    //     0xb9ed34: add             x4, x4, HEAP, lsl #32
    // 0xb9ed38: r8 = X0
    //     0xb9ed38: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb9ed3c: LoadField: r9 = r4->field_7
    //     0xb9ed3c: ldur            x9, [x4, #7]
    // 0xb9ed40: r3 = Null
    //     0xb9ed40: add             x3, PP, #0x80, lsl #12  ; [pp+0x80b98] Null
    //     0xb9ed44: ldr             x3, [x3, #0xb98]
    // 0xb9ed48: blr             x9
    // 0xb9ed4c: ldur            x0, [fp, #-0x18]
    // 0xb9ed50: r16 = Instance__DragDirection
    //     0xb9ed50: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9ed54: ldr             x16, [x16, #0xb88]
    // 0xb9ed58: cmp             w0, w16
    // 0xb9ed5c: b.ne            #0xb9ed78
    // 0xb9ed60: ldur            d1, [fp, #-0x30]
    // 0xb9ed64: ldur            x1, [fp, #-0x28]
    // 0xb9ed68: LoadField: d2 = r1->field_7
    //     0xb9ed68: ldur            d2, [x1, #7]
    // 0xb9ed6c: fadd            d3, d1, d2
    // 0xb9ed70: mov             v0.16b, v3.16b
    // 0xb9ed74: b               #0xb9ed8c
    // 0xb9ed78: ldur            d1, [fp, #-0x30]
    // 0xb9ed7c: ldur            x1, [fp, #-0x28]
    // 0xb9ed80: LoadField: d2 = r1->field_f
    //     0xb9ed80: ldur            d2, [x1, #0xf]
    // 0xb9ed84: fadd            d3, d1, d2
    // 0xb9ed88: mov             v0.16b, v3.16b
    // 0xb9ed8c: mov             x3, x0
    // 0xb9ed90: ldur            x0, [fp, #-0x20]
    // 0xb9ed94: ldur            x2, [fp, #-8]
    // 0xb9ed98: b               #0xb9ece8
    // 0xb9ed9c: ldur            d1, [fp, #-0x30]
    // 0xb9eda0: ldur            x0, [fp, #-0x10]
    // 0xb9eda4: r16 = LoadInt32Instr(r0)
    //     0xb9eda4: sbfx            x16, x0, #1, #0x1f
    // 0xb9eda8: scvtf           d2, w16
    // 0xb9edac: fdiv            d0, d1, d2
    // 0xb9edb0: LeaveFrame
    //     0xb9edb0: mov             SP, fp
    //     0xb9edb4: ldp             fp, lr, [SP], #0x10
    // 0xb9edb8: ret
    //     0xb9edb8: ret             
    // 0xb9edbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9edbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9edc0: b               #0xb9ec78
    // 0xb9edc4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb9edc4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb9edc8: b               #0xb9ecf8
  }
  _ _resolveDelta(/* No info */) {
    // ** addr: 0xb9edcc, size: 0x1d8
    // 0xb9edcc: EnterFrame
    //     0xb9edcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb9edd0: mov             fp, SP
    // 0xb9edd4: AllocStack(0x30)
    //     0xb9edd4: sub             SP, SP, #0x30
    // 0xb9edd8: SetupParameters(DragGestureRecognizer this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0xb9edd8: mov             x0, x5
    //     0xb9eddc: stur            x5, [fp, #-0x20]
    //     0xb9ede0: mov             x5, x1
    //     0xb9ede4: mov             x4, x2
    //     0xb9ede8: stur            x1, [fp, #-0x10]
    //     0xb9edec: stur            x2, [fp, #-0x18]
    // 0xb9edf0: CheckStackOverflow
    //     0xb9edf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9edf4: cmp             SP, x16
    //     0xb9edf8: b.ls            #0xb9ef98
    // 0xb9edfc: r16 = Instance__DragDirection
    //     0xb9edfc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9ee00: ldr             x16, [x16, #0xb88]
    // 0xb9ee04: cmp             w4, w16
    // 0xb9ee08: b.ne            #0xb9ee2c
    // 0xb9ee0c: d0 = 0.000000
    //     0xb9ee0c: eor             v0.16b, v0.16b, v0.16b
    // 0xb9ee10: LoadField: d1 = r3->field_7
    //     0xb9ee10: ldur            d1, [x3, #7]
    // 0xb9ee14: fcmp            d1, d0
    // 0xb9ee18: r16 = true
    //     0xb9ee18: add             x16, NULL, #0x20  ; true
    // 0xb9ee1c: r17 = false
    //     0xb9ee1c: add             x17, NULL, #0x30  ; false
    // 0xb9ee20: csel            x1, x16, x17, gt
    // 0xb9ee24: mov             x6, x1
    // 0xb9ee28: b               #0xb9ee48
    // 0xb9ee2c: d0 = 0.000000
    //     0xb9ee2c: eor             v0.16b, v0.16b, v0.16b
    // 0xb9ee30: LoadField: d1 = r3->field_f
    //     0xb9ee30: ldur            d1, [x3, #0xf]
    // 0xb9ee34: fcmp            d1, d0
    // 0xb9ee38: r16 = true
    //     0xb9ee38: add             x16, NULL, #0x20  ; true
    // 0xb9ee3c: r17 = false
    //     0xb9ee3c: add             x17, NULL, #0x30  ; false
    // 0xb9ee40: csel            x1, x16, x17, gt
    // 0xb9ee44: mov             x6, x1
    // 0xb9ee48: stur            x6, [fp, #-8]
    // 0xb9ee4c: r16 = Instance__DragDirection
    //     0xb9ee4c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0xb9ee50: ldr             x16, [x16, #0xb88]
    // 0xb9ee54: cmp             w4, w16
    // 0xb9ee58: b.ne            #0xb9ee64
    // 0xb9ee5c: LoadField: d1 = r3->field_7
    //     0xb9ee5c: ldur            d1, [x3, #7]
    // 0xb9ee60: b               #0xb9ee68
    // 0xb9ee64: LoadField: d1 = r3->field_f
    //     0xb9ee64: ldur            d1, [x3, #0xf]
    // 0xb9ee68: mov             x1, x5
    // 0xb9ee6c: mov             x2, x4
    // 0xb9ee70: mov             x3, x6
    // 0xb9ee74: stur            d1, [fp, #-0x28]
    // 0xb9ee78: r0 = _getMaxSumDeltaPointer()
    //     0xb9ee78: bl              #0xb9f0d8  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_getMaxSumDeltaPointer
    // 0xb9ee7c: mov             x2, x0
    // 0xb9ee80: ldur            x4, [fp, #-0x20]
    // 0xb9ee84: r0 = BoxInt64Instr(r4)
    //     0xb9ee84: sbfiz           x0, x4, #1, #0x1f
    //     0xb9ee88: cmp             x4, x0, asr #1
    //     0xb9ee8c: b.eq            #0xb9ee98
    //     0xb9ee90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9ee94: stur            x4, [x0, #7]
    // 0xb9ee98: cmp             w2, w0
    // 0xb9ee9c: b.eq            #0xb9eed8
    // 0xb9eea0: and             w16, w2, w0
    // 0xb9eea4: branchIfSmi(r16, 0xb9eee8)
    //     0xb9eea4: tbz             w16, #0, #0xb9eee8
    // 0xb9eea8: r16 = LoadClassIdInstr(r2)
    //     0xb9eea8: ldur            x16, [x2, #-1]
    //     0xb9eeac: ubfx            x16, x16, #0xc, #0x14
    // 0xb9eeb0: cmp             x16, #0x3d
    // 0xb9eeb4: b.ne            #0xb9eee8
    // 0xb9eeb8: r16 = LoadClassIdInstr(r0)
    //     0xb9eeb8: ldur            x16, [x0, #-1]
    //     0xb9eebc: ubfx            x16, x16, #0xc, #0x14
    // 0xb9eec0: cmp             x16, #0x3d
    // 0xb9eec4: b.ne            #0xb9eee8
    // 0xb9eec8: LoadField: r16 = r2->field_7
    //     0xb9eec8: ldur            x16, [x2, #7]
    // 0xb9eecc: LoadField: r17 = r0->field_7
    //     0xb9eecc: ldur            x17, [x0, #7]
    // 0xb9eed0: cmp             x16, x17
    // 0xb9eed4: b.ne            #0xb9eee8
    // 0xb9eed8: ldur            d0, [fp, #-0x28]
    // 0xb9eedc: LeaveFrame
    //     0xb9eedc: mov             SP, fp
    //     0xb9eee0: ldp             fp, lr, [SP], #0x10
    // 0xb9eee4: ret
    //     0xb9eee4: ret             
    // 0xb9eee8: ldur            x0, [fp, #-8]
    // 0xb9eeec: cmp             w2, NULL
    // 0xb9eef0: b.eq            #0xb9efa0
    // 0xb9eef4: r3 = LoadInt32Instr(r2)
    //     0xb9eef4: sbfx            x3, x2, #1, #0x1f
    //     0xb9eef8: tbz             w2, #0, #0xb9ef00
    //     0xb9eefc: ldur            x3, [x2, #7]
    // 0xb9ef00: ldur            x1, [fp, #-0x10]
    // 0xb9ef04: ldur            x2, [fp, #-0x18]
    // 0xb9ef08: mov             x5, x0
    // 0xb9ef0c: r0 = _getSumDelta()
    //     0xb9ef0c: bl              #0xb9efa4  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_getSumDelta
    // 0xb9ef10: ldur            x1, [fp, #-0x10]
    // 0xb9ef14: ldur            x2, [fp, #-0x18]
    // 0xb9ef18: ldur            x3, [fp, #-0x20]
    // 0xb9ef1c: ldur            x5, [fp, #-8]
    // 0xb9ef20: stur            d0, [fp, #-0x30]
    // 0xb9ef24: r0 = _getSumDelta()
    //     0xb9ef24: bl              #0xb9efa4  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_getSumDelta
    // 0xb9ef28: ldur            x0, [fp, #-8]
    // 0xb9ef2c: tbnz            w0, #4, #0xb9ef64
    // 0xb9ef30: ldur            d2, [fp, #-0x28]
    // 0xb9ef34: ldur            d1, [fp, #-0x30]
    // 0xb9ef38: fadd            d3, d0, d2
    // 0xb9ef3c: fcmp            d3, d1
    // 0xb9ef40: b.le            #0xb9ef54
    // 0xb9ef44: fsub            d0, d3, d1
    // 0xb9ef48: LeaveFrame
    //     0xb9ef48: mov             SP, fp
    //     0xb9ef4c: ldp             fp, lr, [SP], #0x10
    // 0xb9ef50: ret
    //     0xb9ef50: ret             
    // 0xb9ef54: d0 = 0.000000
    //     0xb9ef54: eor             v0.16b, v0.16b, v0.16b
    // 0xb9ef58: LeaveFrame
    //     0xb9ef58: mov             SP, fp
    //     0xb9ef5c: ldp             fp, lr, [SP], #0x10
    // 0xb9ef60: ret
    //     0xb9ef60: ret             
    // 0xb9ef64: ldur            d2, [fp, #-0x28]
    // 0xb9ef68: ldur            d1, [fp, #-0x30]
    // 0xb9ef6c: fadd            d3, d0, d2
    // 0xb9ef70: fcmp            d1, d3
    // 0xb9ef74: b.le            #0xb9ef88
    // 0xb9ef78: fsub            d0, d3, d1
    // 0xb9ef7c: LeaveFrame
    //     0xb9ef7c: mov             SP, fp
    //     0xb9ef80: ldp             fp, lr, [SP], #0x10
    // 0xb9ef84: ret
    //     0xb9ef84: ret             
    // 0xb9ef88: d0 = 0.000000
    //     0xb9ef88: eor             v0.16b, v0.16b, v0.16b
    // 0xb9ef8c: LeaveFrame
    //     0xb9ef8c: mov             SP, fp
    //     0xb9ef90: ldp             fp, lr, [SP], #0x10
    // 0xb9ef94: ret
    //     0xb9ef94: ret             
    // 0xb9ef98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9ef98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9ef9c: b               #0xb9edfc
    // 0xb9efa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9efa0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getSumDelta(/* No info */) {
    // ** addr: 0xb9efa4, size: 0x134
    // 0xb9efa4: EnterFrame
    //     0xb9efa4: stp             fp, lr, [SP, #-0x10]!
    //     0xb9efa8: mov             fp, SP
    // 0xb9efac: AllocStack(0x20)
    //     0xb9efac: sub             SP, SP, #0x20
    // 0xb9efb0: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xb9efb0: mov             x4, x2
    //     0xb9efb4: stur            x2, [fp, #-0x18]
    //     0xb9efb8: stur            x5, [fp, #-0x20]
    // 0xb9efbc: CheckStackOverflow
    //     0xb9efbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9efc0: cmp             SP, x16
    //     0xb9efc4: b.ls            #0xb9f0cc
    // 0xb9efc8: LoadField: r6 = r1->field_7b
    //     0xb9efc8: ldur            w6, [x1, #0x7b]
    // 0xb9efcc: DecompressPointer r6
    //     0xb9efcc: add             x6, x6, HEAP, lsl #32
    // 0xb9efd0: stur            x6, [fp, #-0x10]
    // 0xb9efd4: r0 = BoxInt64Instr(r3)
    //     0xb9efd4: sbfiz           x0, x3, #1, #0x1f
    //     0xb9efd8: cmp             x3, x0, asr #1
    //     0xb9efdc: b.eq            #0xb9efe8
    //     0xb9efe0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9efe4: stur            x3, [x0, #7]
    // 0xb9efe8: mov             x1, x6
    // 0xb9efec: mov             x2, x0
    // 0xb9eff0: stur            x0, [fp, #-8]
    // 0xb9eff4: r0 = containsKey()
    //     0xb9eff4: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xb9eff8: tbz             w0, #4, #0xb9f00c
    // 0xb9effc: d0 = 0.000000
    //     0xb9effc: eor             v0.16b, v0.16b, v0.16b
    // 0xb9f000: LeaveFrame
    //     0xb9f000: mov             SP, fp
    //     0xb9f004: ldp             fp, lr, [SP], #0x10
    // 0xb9f008: ret
    //     0xb9f008: ret             
    // 0xb9f00c: ldur            x0, [fp, #-0x10]
    // 0xb9f010: mov             x1, x0
    // 0xb9f014: ldur            x2, [fp, #-8]
    // 0xb9f018: r0 = _getValueOrData()
    //     0xb9f018: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb9f01c: mov             x1, x0
    // 0xb9f020: ldur            x0, [fp, #-0x10]
    // 0xb9f024: LoadField: r2 = r0->field_f
    //     0xb9f024: ldur            w2, [x0, #0xf]
    // 0xb9f028: DecompressPointer r2
    //     0xb9f028: add             x2, x2, HEAP, lsl #32
    // 0xb9f02c: cmp             w2, w1
    // 0xb9f030: b.ne            #0xb9f038
    // 0xb9f034: r1 = Null
    //     0xb9f034: mov             x1, NULL
    // 0xb9f038: ldur            x0, [fp, #-0x20]
    // 0xb9f03c: cmp             w1, NULL
    // 0xb9f040: b.eq            #0xb9f0d4
    // 0xb9f044: tbnz            w0, #4, #0xb9f088
    // 0xb9f048: ldur            x0, [fp, #-0x18]
    // 0xb9f04c: r16 = Instance__DragDirection
    //     0xb9f04c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0xb9f050: ldr             x16, [x16, #0xb90]
    // 0xb9f054: cmp             w0, w16
    // 0xb9f058: b.ne            #0xb9f070
    // 0xb9f05c: d1 = 0.000000
    //     0xb9f05c: eor             v1.16b, v1.16b, v1.16b
    // 0xb9f060: LoadField: d2 = r1->field_f
    //     0xb9f060: ldur            d2, [x1, #0xf]
    // 0xb9f064: fmax            v3.2d, v2.2d, v1.2d
    // 0xb9f068: mov             v2.16b, v3.16b
    // 0xb9f06c: b               #0xb9f080
    // 0xb9f070: d1 = 0.000000
    //     0xb9f070: eor             v1.16b, v1.16b, v1.16b
    // 0xb9f074: LoadField: d2 = r1->field_7
    //     0xb9f074: ldur            d2, [x1, #7]
    // 0xb9f078: fmax            v3.2d, v2.2d, v1.2d
    // 0xb9f07c: mov             v2.16b, v3.16b
    // 0xb9f080: mov             v0.16b, v2.16b
    // 0xb9f084: b               #0xb9f0c0
    // 0xb9f088: ldur            x0, [fp, #-0x18]
    // 0xb9f08c: d1 = 0.000000
    //     0xb9f08c: eor             v1.16b, v1.16b, v1.16b
    // 0xb9f090: r16 = Instance__DragDirection
    //     0xb9f090: add             x16, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0xb9f094: ldr             x16, [x16, #0xb90]
    // 0xb9f098: cmp             w0, w16
    // 0xb9f09c: b.ne            #0xb9f0b0
    // 0xb9f0a0: LoadField: d2 = r1->field_f
    //     0xb9f0a0: ldur            d2, [x1, #0xf]
    // 0xb9f0a4: fmin            v3.2d, v2.2d, v1.2d
    // 0xb9f0a8: mov             v1.16b, v3.16b
    // 0xb9f0ac: b               #0xb9f0bc
    // 0xb9f0b0: LoadField: d2 = r1->field_7
    //     0xb9f0b0: ldur            d2, [x1, #7]
    // 0xb9f0b4: fmin            v3.2d, v2.2d, v1.2d
    // 0xb9f0b8: mov             v1.16b, v3.16b
    // 0xb9f0bc: mov             v0.16b, v1.16b
    // 0xb9f0c0: LeaveFrame
    //     0xb9f0c0: mov             SP, fp
    //     0xb9f0c4: ldp             fp, lr, [SP], #0x10
    // 0xb9f0c8: ret
    //     0xb9f0c8: ret             
    // 0xb9f0cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f0cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f0d0: b               #0xb9efc8
    // 0xb9f0d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9f0d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getMaxSumDeltaPointer(/* No info */) {
    // ** addr: 0xb9f0d8, size: 0x25c
    // 0xb9f0d8: EnterFrame
    //     0xb9f0d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f0dc: mov             fp, SP
    // 0xb9f0e0: AllocStack(0x48)
    //     0xb9f0e0: sub             SP, SP, #0x48
    // 0xb9f0e4: SetupParameters(DragGestureRecognizer this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */)
    //     0xb9f0e4: mov             x0, x1
    //     0xb9f0e8: mov             x5, x3
    //     0xb9f0ec: stur            x1, [fp, #-0x10]
    //     0xb9f0f0: stur            x2, [fp, #-0x18]
    //     0xb9f0f4: stur            x3, [fp, #-0x20]
    // 0xb9f0f8: CheckStackOverflow
    //     0xb9f0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f0fc: cmp             SP, x16
    //     0xb9f100: b.ls            #0xb9f300
    // 0xb9f104: LoadField: r3 = r0->field_7b
    //     0xb9f104: ldur            w3, [x0, #0x7b]
    // 0xb9f108: DecompressPointer r3
    //     0xb9f108: add             x3, x3, HEAP, lsl #32
    // 0xb9f10c: stur            x3, [fp, #-8]
    // 0xb9f110: LoadField: r1 = r3->field_13
    //     0xb9f110: ldur            w1, [x3, #0x13]
    // 0xb9f114: r4 = LoadInt32Instr(r1)
    //     0xb9f114: sbfx            x4, x1, #1, #0x1f
    // 0xb9f118: asr             x1, x4, #1
    // 0xb9f11c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xb9f11c: ldur            w4, [x3, #0x17]
    // 0xb9f120: r6 = LoadInt32Instr(r4)
    //     0xb9f120: sbfx            x6, x4, #1, #0x1f
    // 0xb9f124: sub             x4, x1, x6
    // 0xb9f128: cbnz            x4, #0xb9f13c
    // 0xb9f12c: r0 = Null
    //     0xb9f12c: mov             x0, NULL
    // 0xb9f130: LeaveFrame
    //     0xb9f130: mov             SP, fp
    //     0xb9f134: ldp             fp, lr, [SP], #0x10
    // 0xb9f138: ret
    //     0xb9f138: ret             
    // 0xb9f13c: r1 = <int, Offset>
    //     0xb9f13c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xb9f140: ldr             x1, [x1, #0x540]
    // 0xb9f144: r0 = _CompactKeysIterable()
    //     0xb9f144: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xb9f148: mov             x1, x0
    // 0xb9f14c: ldur            x0, [fp, #-8]
    // 0xb9f150: StoreField: r1->field_b = r0
    //     0xb9f150: stur            w0, [x1, #0xb]
    // 0xb9f154: r0 = iterator()
    //     0xb9f154: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xb9f158: stur            x0, [fp, #-0x38]
    // 0xb9f15c: LoadField: r2 = r0->field_7
    //     0xb9f15c: ldur            w2, [x0, #7]
    // 0xb9f160: DecompressPointer r2
    //     0xb9f160: add             x2, x2, HEAP, lsl #32
    // 0xb9f164: stur            x2, [fp, #-0x30]
    // 0xb9f168: ldur            x5, [fp, #-0x20]
    // 0xb9f16c: r4 = Null
    //     0xb9f16c: mov             x4, NULL
    // 0xb9f170: r3 = Null
    //     0xb9f170: mov             x3, NULL
    // 0xb9f174: stur            x4, [fp, #-8]
    // 0xb9f178: stur            x3, [fp, #-0x28]
    // 0xb9f17c: CheckStackOverflow
    //     0xb9f17c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f180: cmp             SP, x16
    //     0xb9f184: b.ls            #0xb9f308
    // 0xb9f188: mov             x1, x0
    // 0xb9f18c: r0 = moveNext()
    //     0xb9f18c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xb9f190: tbnz            w0, #4, #0xb9f2f0
    // 0xb9f194: ldur            x3, [fp, #-0x38]
    // 0xb9f198: LoadField: r4 = r3->field_33
    //     0xb9f198: ldur            w4, [x3, #0x33]
    // 0xb9f19c: DecompressPointer r4
    //     0xb9f19c: add             x4, x4, HEAP, lsl #32
    // 0xb9f1a0: stur            x4, [fp, #-0x40]
    // 0xb9f1a4: cmp             w4, NULL
    // 0xb9f1a8: b.ne            #0xb9f1dc
    // 0xb9f1ac: mov             x0, x4
    // 0xb9f1b0: ldur            x2, [fp, #-0x30]
    // 0xb9f1b4: r1 = Null
    //     0xb9f1b4: mov             x1, NULL
    // 0xb9f1b8: cmp             w2, NULL
    // 0xb9f1bc: b.eq            #0xb9f1dc
    // 0xb9f1c0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb9f1c0: ldur            w4, [x2, #0x17]
    // 0xb9f1c4: DecompressPointer r4
    //     0xb9f1c4: add             x4, x4, HEAP, lsl #32
    // 0xb9f1c8: r8 = X0
    //     0xb9f1c8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb9f1cc: LoadField: r9 = r4->field_7
    //     0xb9f1cc: ldur            x9, [x4, #7]
    // 0xb9f1d0: r3 = Null
    //     0xb9f1d0: add             x3, PP, #0x80, lsl #12  ; [pp+0x80ba8] Null
    //     0xb9f1d4: ldr             x3, [x3, #0xba8]
    // 0xb9f1d8: blr             x9
    // 0xb9f1dc: ldur            x4, [fp, #-8]
    // 0xb9f1e0: ldur            x0, [fp, #-0x40]
    // 0xb9f1e4: r6 = LoadInt32Instr(r0)
    //     0xb9f1e4: sbfx            x6, x0, #1, #0x1f
    //     0xb9f1e8: tbz             w0, #0, #0xb9f1f0
    //     0xb9f1ec: ldur            x6, [x0, #7]
    // 0xb9f1f0: ldur            x1, [fp, #-0x10]
    // 0xb9f1f4: ldur            x2, [fp, #-0x18]
    // 0xb9f1f8: mov             x3, x6
    // 0xb9f1fc: ldur            x5, [fp, #-0x20]
    // 0xb9f200: stur            x6, [fp, #-0x48]
    // 0xb9f204: r0 = _getSumDelta()
    //     0xb9f204: bl              #0xb9efa4  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_getSumDelta
    // 0xb9f208: ldur            x0, [fp, #-8]
    // 0xb9f20c: cmp             w0, NULL
    // 0xb9f210: b.ne            #0xb9f220
    // 0xb9f214: ldur            x3, [fp, #-0x48]
    // 0xb9f218: ldur            x2, [fp, #-0x20]
    // 0xb9f21c: b               #0xb9f29c
    // 0xb9f220: ldur            x2, [fp, #-0x20]
    // 0xb9f224: tbnz            w2, #4, #0xb9f264
    // 0xb9f228: ldur            x3, [fp, #-0x28]
    // 0xb9f22c: cmp             w3, NULL
    // 0xb9f230: b.eq            #0xb9f310
    // 0xb9f234: LoadField: d1 = r3->field_7
    //     0xb9f234: ldur            d1, [x3, #7]
    // 0xb9f238: fcmp            d0, d1
    // 0xb9f23c: b.le            #0xb9f24c
    // 0xb9f240: ldur            x0, [fp, #-0x48]
    // 0xb9f244: mov             v1.16b, v0.16b
    // 0xb9f248: b               #0xb9f25c
    // 0xb9f24c: r1 = LoadInt32Instr(r0)
    //     0xb9f24c: sbfx            x1, x0, #1, #0x1f
    //     0xb9f250: tbz             w0, #0, #0xb9f258
    //     0xb9f254: ldur            x1, [x0, #7]
    // 0xb9f258: mov             x0, x1
    // 0xb9f25c: mov             v0.16b, v1.16b
    // 0xb9f260: b               #0xb9f298
    // 0xb9f264: ldur            x3, [fp, #-0x28]
    // 0xb9f268: cmp             w3, NULL
    // 0xb9f26c: b.eq            #0xb9f314
    // 0xb9f270: LoadField: d1 = r3->field_7
    //     0xb9f270: ldur            d1, [x3, #7]
    // 0xb9f274: fcmp            d1, d0
    // 0xb9f278: b.le            #0xb9f284
    // 0xb9f27c: ldur            x0, [fp, #-0x48]
    // 0xb9f280: b               #0xb9f298
    // 0xb9f284: r1 = LoadInt32Instr(r0)
    //     0xb9f284: sbfx            x1, x0, #1, #0x1f
    //     0xb9f288: tbz             w0, #0, #0xb9f290
    //     0xb9f28c: ldur            x1, [x0, #7]
    // 0xb9f290: mov             x0, x1
    // 0xb9f294: mov             v0.16b, v1.16b
    // 0xb9f298: mov             x3, x0
    // 0xb9f29c: r0 = BoxInt64Instr(r3)
    //     0xb9f29c: sbfiz           x0, x3, #1, #0x1f
    //     0xb9f2a0: cmp             x3, x0, asr #1
    //     0xb9f2a4: b.eq            #0xb9f2b0
    //     0xb9f2a8: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb9f2ac: stur            x3, [x0, #7]
    // 0xb9f2b0: r3 = inline_Allocate_Double()
    //     0xb9f2b0: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb9f2b4: add             x3, x3, #0x10
    //     0xb9f2b8: cmp             x1, x3
    //     0xb9f2bc: b.ls            #0xb9f318
    //     0xb9f2c0: str             x3, [THR, #0x60]  ; THR::top
    //     0xb9f2c4: sub             x3, x3, #0xf
    //     0xb9f2c8: mov             x1, #0xe19c
    //     0xb9f2cc: movk            x1, #3, lsl #16
    //     0xb9f2d0: stur            x1, [x3, #-1]
    // 0xb9f2d4: dmb             ishst
    // 0xb9f2d8: StoreField: r3->field_7 = d0
    //     0xb9f2d8: stur            d0, [x3, #7]
    // 0xb9f2dc: mov             x4, x0
    // 0xb9f2e0: mov             x5, x2
    // 0xb9f2e4: ldur            x0, [fp, #-0x38]
    // 0xb9f2e8: ldur            x2, [fp, #-0x30]
    // 0xb9f2ec: b               #0xb9f174
    // 0xb9f2f0: ldur            x0, [fp, #-8]
    // 0xb9f2f4: LeaveFrame
    //     0xb9f2f4: mov             SP, fp
    //     0xb9f2f8: ldp             fp, lr, [SP], #0x10
    // 0xb9f2fc: ret
    //     0xb9f2fc: ret             
    // 0xb9f300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f304: b               #0xb9f104
    // 0xb9f308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f30c: b               #0xb9f188
    // 0xb9f310: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb9f310: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb9f314: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb9f314: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb9f318: SaveReg d0
    //     0xb9f318: str             q0, [SP, #-0x10]!
    // 0xb9f31c: stp             x0, x2, [SP, #-0x10]!
    // 0xb9f320: r0 = AllocateDouble()
    //     0xb9f320: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9f324: mov             x3, x0
    // 0xb9f328: ldp             x0, x2, [SP], #0x10
    // 0xb9f32c: RestoreReg d0
    //     0xb9f32c: ldr             q0, [SP], #0x10
    // 0xb9f330: b               #0xb9f2d8
  }
  _ _giveUpPointer(/* No info */) {
    // ** addr: 0xb9f334, size: 0x134
    // 0xb9f334: EnterFrame
    //     0xb9f334: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f338: mov             fp, SP
    // 0xb9f33c: AllocStack(0x20)
    //     0xb9f33c: sub             SP, SP, #0x20
    // 0xb9f340: SetupParameters(DragGestureRecognizer this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xb9f340: mov             x4, x1
    //     0xb9f344: mov             x3, x2
    //     0xb9f348: stur            x1, [fp, #-0x10]
    //     0xb9f34c: stur            x2, [fp, #-0x18]
    // 0xb9f350: CheckStackOverflow
    //     0xb9f350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f354: cmp             SP, x16
    //     0xb9f358: b.ls            #0xb9f460
    // 0xb9f35c: r0 = BoxInt64Instr(r3)
    //     0xb9f35c: sbfiz           x0, x3, #1, #0x1f
    //     0xb9f360: cmp             x3, x0, asr #1
    //     0xb9f364: b.eq            #0xb9f370
    //     0xb9f368: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9f36c: stur            x3, [x0, #7]
    // 0xb9f370: mov             x1, x4
    // 0xb9f374: mov             x2, x0
    // 0xb9f378: stur            x0, [fp, #-8]
    // 0xb9f37c: r0 = stopTrackingPointer()
    //     0xb9f37c: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xb9f380: ldur            x0, [fp, #-0x10]
    // 0xb9f384: LoadField: r3 = r0->field_87
    //     0xb9f384: ldur            w3, [x0, #0x87]
    // 0xb9f388: DecompressPointer r3
    //     0xb9f388: add             x3, x3, HEAP, lsl #32
    // 0xb9f38c: mov             x1, x3
    // 0xb9f390: ldur            x2, [fp, #-8]
    // 0xb9f394: stur            x3, [fp, #-0x20]
    // 0xb9f398: r0 = remove()
    //     0xb9f398: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xb9f39c: tbz             w0, #4, #0xb9f3ac
    // 0xb9f3a0: ldur            x1, [fp, #-0x10]
    // 0xb9f3a4: ldur            x2, [fp, #-0x18]
    // 0xb9f3a8: r0 = resolvePointer()
    //     0xb9f3a8: bl              #0xb98f4c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0xb9f3ac: ldur            x0, [fp, #-0x10]
    // 0xb9f3b0: ldur            x3, [fp, #-8]
    // 0xb9f3b4: LoadField: r1 = r0->field_7b
    //     0xb9f3b4: ldur            w1, [x0, #0x7b]
    // 0xb9f3b8: DecompressPointer r1
    //     0xb9f3b8: add             x1, x1, HEAP, lsl #32
    // 0xb9f3bc: mov             x2, x3
    // 0xb9f3c0: r0 = remove()
    //     0xb9f3c0: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xb9f3c4: ldur            x0, [fp, #-0x10]
    // 0xb9f3c8: LoadField: r1 = r0->field_8b
    //     0xb9f3c8: ldur            w1, [x0, #0x8b]
    // 0xb9f3cc: DecompressPointer r1
    //     0xb9f3cc: add             x1, x1, HEAP, lsl #32
    // 0xb9f3d0: ldur            x2, [fp, #-8]
    // 0xb9f3d4: cmp             w1, w2
    // 0xb9f3d8: b.eq            #0xb9f414
    // 0xb9f3dc: and             w16, w1, w2
    // 0xb9f3e0: branchIfSmi(r16, 0xb9f450)
    //     0xb9f3e0: tbz             w16, #0, #0xb9f450
    // 0xb9f3e4: r16 = LoadClassIdInstr(r1)
    //     0xb9f3e4: ldur            x16, [x1, #-1]
    //     0xb9f3e8: ubfx            x16, x16, #0xc, #0x14
    // 0xb9f3ec: cmp             x16, #0x3d
    // 0xb9f3f0: b.ne            #0xb9f450
    // 0xb9f3f4: r16 = LoadClassIdInstr(r2)
    //     0xb9f3f4: ldur            x16, [x2, #-1]
    //     0xb9f3f8: ubfx            x16, x16, #0xc, #0x14
    // 0xb9f3fc: cmp             x16, #0x3d
    // 0xb9f400: b.ne            #0xb9f450
    // 0xb9f404: LoadField: r16 = r1->field_7
    //     0xb9f404: ldur            x16, [x1, #7]
    // 0xb9f408: LoadField: r17 = r2->field_7
    //     0xb9f408: ldur            x17, [x2, #7]
    // 0xb9f40c: cmp             x16, x17
    // 0xb9f410: b.ne            #0xb9f450
    // 0xb9f414: ldur            x1, [fp, #-0x20]
    // 0xb9f418: LoadField: r2 = r1->field_b
    //     0xb9f418: ldur            w2, [x1, #0xb]
    // 0xb9f41c: cbz             w2, #0xb9f428
    // 0xb9f420: r0 = first()
    //     0xb9f420: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0xb9f424: b               #0xb9f42c
    // 0xb9f428: r0 = Null
    //     0xb9f428: mov             x0, NULL
    // 0xb9f42c: ldur            x1, [fp, #-0x10]
    // 0xb9f430: StoreField: r1->field_8b = r0
    //     0xb9f430: stur            w0, [x1, #0x8b]
    //     0xb9f434: tbz             w0, #0, #0xb9f450
    //     0xb9f438: ldurb           w16, [x1, #-1]
    //     0xb9f43c: ldurb           w17, [x0, #-1]
    //     0xb9f440: and             x16, x17, x16, lsr #2
    //     0xb9f444: tst             x16, HEAP, lsr #32
    //     0xb9f448: b.eq            #0xb9f450
    //     0xb9f44c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb9f450: r0 = Null
    //     0xb9f450: mov             x0, NULL
    // 0xb9f454: LeaveFrame
    //     0xb9f454: mov             SP, fp
    //     0xb9f458: ldp             fp, lr, [SP], #0x10
    // 0xb9f45c: ret
    //     0xb9f45c: ret             
    // 0xb9f460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f464: b               #0xb9f35c
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xb9f9c8, size: 0x24
    // 0xb9f9c8: EnterFrame
    //     0xb9f9c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f9cc: mov             fp, SP
    // 0xb9f9d0: ldr             x2, [fp, #0x10]
    // 0xb9f9d4: r1 = Function 'handleEvent':.
    //     0xb9f9d4: add             x1, PP, #0x80, lsl #12  ; [pp+0x80b20] AnonymousClosure: (0xb9e1f8), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::handleEvent (0xb9d2a4)
    //     0xb9f9d8: ldr             x1, [x1, #0xb20]
    // 0xb9f9dc: r0 = AllocateClosure()
    //     0xb9f9dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9f9e0: LeaveFrame
    //     0xb9f9e0: mov             SP, fp
    //     0xb9f9e4: ldp             fp, lr, [SP], #0x10
    // 0xb9f9e8: ret
    //     0xb9f9e8: ret             
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba7a18, size: 0xd8
    // 0xba7a18: EnterFrame
    //     0xba7a18: stp             fp, lr, [SP, #-0x10]!
    //     0xba7a1c: mov             fp, SP
    // 0xba7a20: AllocStack(0x10)
    //     0xba7a20: sub             SP, SP, #0x10
    // 0xba7a24: SetupParameters(DragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba7a24: mov             x3, x1
    //     0xba7a28: mov             x0, x2
    //     0xba7a2c: stur            x1, [fp, #-8]
    //     0xba7a30: stur            x2, [fp, #-0x10]
    // 0xba7a34: CheckStackOverflow
    //     0xba7a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7a38: cmp             SP, x16
    //     0xba7a3c: b.ls            #0xba7ae8
    // 0xba7a40: mov             x1, x3
    // 0xba7a44: mov             x2, x0
    // 0xba7a48: r0 = addAllowedPointer()
    //     0xba7a48: bl              #0xba6ac8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0xba7a4c: ldur            x2, [fp, #-8]
    // 0xba7a50: LoadField: r0 = r2->field_53
    //     0xba7a50: ldur            w0, [x2, #0x53]
    // 0xba7a54: DecompressPointer r0
    //     0xba7a54: add             x0, x0, HEAP, lsl #32
    // 0xba7a58: r16 = Instance__DragState
    //     0xba7a58: add             x16, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!_DragState@12c5ce1
    //     0xba7a5c: ldr             x16, [x16, #0x530]
    // 0xba7a60: cmp             w0, w16
    // 0xba7a64: b.ne            #0xba7acc
    // 0xba7a68: ldur            x3, [fp, #-0x10]
    // 0xba7a6c: r0 = LoadClassIdInstr(r3)
    //     0xba7a6c: ldur            x0, [x3, #-1]
    //     0xba7a70: ubfx            x0, x0, #0xc, #0x14
    // 0xba7a74: mov             x1, x3
    // 0xba7a78: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xba7a78: mov             x17, #0x6f9c
    //     0xba7a7c: movk            x17, #1, lsl #16
    //     0xba7a80: add             lr, x0, x17
    //     0xba7a84: ldr             lr, [x21, lr, lsl #3]
    //     0xba7a88: blr             lr
    // 0xba7a8c: mov             x2, x0
    // 0xba7a90: r0 = BoxInt64Instr(r2)
    //     0xba7a90: sbfiz           x0, x2, #1, #0x1f
    //     0xba7a94: cmp             x2, x0, asr #1
    //     0xba7a98: b.eq            #0xba7aa4
    //     0xba7a9c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba7aa0: stur            x2, [x0, #7]
    // 0xba7aa4: ldur            x1, [fp, #-8]
    // 0xba7aa8: StoreField: r1->field_67 = r0
    //     0xba7aa8: stur            w0, [x1, #0x67]
    //     0xba7aac: tbz             w0, #0, #0xba7ac8
    //     0xba7ab0: ldurb           w16, [x1, #-1]
    //     0xba7ab4: ldurb           w17, [x0, #-1]
    //     0xba7ab8: and             x16, x17, x16, lsr #2
    //     0xba7abc: tst             x16, HEAP, lsr #32
    //     0xba7ac0: b.eq            #0xba7ac8
    //     0xba7ac4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba7ac8: b               #0xba7ad0
    // 0xba7acc: mov             x1, x2
    // 0xba7ad0: ldur            x2, [fp, #-0x10]
    // 0xba7ad4: r0 = _addPointer()
    //     0xba7ad4: bl              #0xba7af0  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_addPointer
    // 0xba7ad8: r0 = Null
    //     0xba7ad8: mov             x0, NULL
    // 0xba7adc: LeaveFrame
    //     0xba7adc: mov             SP, fp
    //     0xba7ae0: ldp             fp, lr, [SP], #0x10
    // 0xba7ae4: ret
    //     0xba7ae4: ret             
    // 0xba7ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7aec: b               #0xba7a40
  }
  _ _addPointer(/* No info */) {
    // ** addr: 0xba7af0, size: 0x23c
    // 0xba7af0: EnterFrame
    //     0xba7af0: stp             fp, lr, [SP, #-0x10]!
    //     0xba7af4: mov             fp, SP
    // 0xba7af8: AllocStack(0x38)
    //     0xba7af8: sub             SP, SP, #0x38
    // 0xba7afc: SetupParameters(DragGestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xba7afc: mov             x3, x1
    //     0xba7b00: stur            x1, [fp, #-0x10]
    //     0xba7b04: stur            x2, [fp, #-0x18]
    // 0xba7b08: CheckStackOverflow
    //     0xba7b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7b0c: cmp             SP, x16
    //     0xba7b10: b.ls            #0xba7d24
    // 0xba7b14: LoadField: r4 = r3->field_77
    //     0xba7b14: ldur            w4, [x3, #0x77]
    // 0xba7b18: DecompressPointer r4
    //     0xba7b18: add             x4, x4, HEAP, lsl #32
    // 0xba7b1c: stur            x4, [fp, #-8]
    // 0xba7b20: r0 = LoadClassIdInstr(r2)
    //     0xba7b20: ldur            x0, [x2, #-1]
    //     0xba7b24: ubfx            x0, x0, #0xc, #0x14
    // 0xba7b28: mov             x1, x2
    // 0xba7b2c: r0 = GDT[cid_x0 + -0x1]()
    //     0xba7b2c: sub             lr, x0, #1
    //     0xba7b30: ldr             lr, [x21, lr, lsl #3]
    //     0xba7b34: blr             lr
    // 0xba7b38: mov             x2, x0
    // 0xba7b3c: ldur            x1, [fp, #-0x10]
    // 0xba7b40: stur            x2, [fp, #-0x20]
    // 0xba7b44: LoadField: r0 = r1->field_4f
    //     0xba7b44: ldur            w0, [x1, #0x4f]
    // 0xba7b48: DecompressPointer r0
    //     0xba7b48: add             x0, x0, HEAP, lsl #32
    // 0xba7b4c: ldur            x16, [fp, #-0x18]
    // 0xba7b50: stp             x16, x0, [SP]
    // 0xba7b54: ClosureCall
    //     0xba7b54: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba7b58: ldur            x2, [x0, #0x1f]
    //     0xba7b5c: blr             x2
    // 0xba7b60: mov             x3, x0
    // 0xba7b64: ldur            x2, [fp, #-0x20]
    // 0xba7b68: r0 = BoxInt64Instr(r2)
    //     0xba7b68: sbfiz           x0, x2, #1, #0x1f
    //     0xba7b6c: cmp             x2, x0, asr #1
    //     0xba7b70: b.eq            #0xba7b7c
    //     0xba7b74: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba7b78: stur            x2, [x0, #7]
    // 0xba7b7c: ldur            x1, [fp, #-8]
    // 0xba7b80: mov             x2, x0
    // 0xba7b84: r0 = []=()
    //     0xba7b84: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba7b88: ldur            x2, [fp, #-0x10]
    // 0xba7b8c: LoadField: r0 = r2->field_53
    //     0xba7b8c: ldur            w0, [x2, #0x53]
    // 0xba7b90: DecompressPointer r0
    //     0xba7b90: add             x0, x0, HEAP, lsl #32
    // 0xba7b94: LoadField: r1 = r0->field_7
    //     0xba7b94: ldur            x1, [x0, #7]
    // 0xba7b98: cmp             x1, #1
    // 0xba7b9c: b.gt            #0xba7d04
    // 0xba7ba0: cmp             x1, #0
    // 0xba7ba4: b.gt            #0xba7d14
    // 0xba7ba8: ldur            x3, [fp, #-0x18]
    // 0xba7bac: r0 = Instance__DragState
    //     0xba7bac: add             x0, PP, #0x80, lsl #12  ; [pp+0x80b70] Obj!_DragState@12c5d01
    //     0xba7bb0: ldr             x0, [x0, #0xb70]
    // 0xba7bb4: StoreField: r2->field_53 = r0
    //     0xba7bb4: stur            w0, [x2, #0x53]
    // 0xba7bb8: r0 = LoadClassIdInstr(r3)
    //     0xba7bb8: ldur            x0, [x3, #-1]
    //     0xba7bbc: ubfx            x0, x0, #0xc, #0x14
    // 0xba7bc0: mov             x1, x3
    // 0xba7bc4: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba7bc4: mov             x17, #0x3f27
    //     0xba7bc8: movk            x17, #1, lsl #16
    //     0xba7bcc: add             lr, x0, x17
    //     0xba7bd0: ldr             lr, [x21, lr, lsl #3]
    //     0xba7bd4: blr             lr
    // 0xba7bd8: mov             x3, x0
    // 0xba7bdc: ldur            x2, [fp, #-0x18]
    // 0xba7be0: stur            x3, [fp, #-8]
    // 0xba7be4: r0 = LoadClassIdInstr(r2)
    //     0xba7be4: ldur            x0, [x2, #-1]
    //     0xba7be8: ubfx            x0, x0, #0xc, #0x14
    // 0xba7bec: mov             x1, x2
    // 0xba7bf0: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xba7bf0: mov             x17, #0x54ea
    //     0xba7bf4: movk            x17, #1, lsl #16
    //     0xba7bf8: add             lr, x0, x17
    //     0xba7bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xba7c00: blr             lr
    // 0xba7c04: stur            x0, [fp, #-0x28]
    // 0xba7c08: r0 = OffsetPair()
    //     0xba7c08: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xba7c0c: mov             x1, x0
    // 0xba7c10: ldur            x0, [fp, #-0x28]
    // 0xba7c14: StoreField: r1->field_7 = r0
    //     0xba7c14: stur            w0, [x1, #7]
    // 0xba7c18: ldur            x0, [fp, #-8]
    // 0xba7c1c: StoreField: r1->field_b = r0
    //     0xba7c1c: stur            w0, [x1, #0xb]
    // 0xba7c20: mov             x0, x1
    // 0xba7c24: ldur            x2, [fp, #-0x10]
    // 0xba7c28: StoreField: r2->field_57 = r0
    //     0xba7c28: stur            w0, [x2, #0x57]
    //     0xba7c2c: ldurb           w16, [x2, #-1]
    //     0xba7c30: ldurb           w17, [x0, #-1]
    //     0xba7c34: and             x16, x17, x16, lsr #2
    //     0xba7c38: tst             x16, HEAP, lsr #32
    //     0xba7c3c: b.eq            #0xba7c44
    //     0xba7c40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba7c44: mov             x0, x1
    // 0xba7c48: StoreField: r2->field_5f = r0
    //     0xba7c48: stur            w0, [x2, #0x5f]
    //     0xba7c4c: ldurb           w16, [x2, #-1]
    //     0xba7c50: ldurb           w17, [x0, #-1]
    //     0xba7c54: and             x16, x17, x16, lsr #2
    //     0xba7c58: tst             x16, HEAP, lsr #32
    //     0xba7c5c: b.eq            #0xba7c64
    //     0xba7c60: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba7c64: r0 = Instance_OffsetPair
    //     0xba7c64: add             x0, PP, #0x26, lsl #12  ; [pp+0x26620] Obj!OffsetPair@129f151
    //     0xba7c68: ldr             x0, [x0, #0x620]
    // 0xba7c6c: StoreField: r2->field_5b = r0
    //     0xba7c6c: stur            w0, [x2, #0x5b]
    // 0xba7c70: r0 = 0.000000
    //     0xba7c70: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xba7c74: StoreField: r2->field_6f = r0
    //     0xba7c74: stur            w0, [x2, #0x6f]
    // 0xba7c78: ldur            x3, [fp, #-0x18]
    // 0xba7c7c: r0 = LoadClassIdInstr(r3)
    //     0xba7c7c: ldur            x0, [x3, #-1]
    //     0xba7c80: ubfx            x0, x0, #0xc, #0x14
    // 0xba7c84: mov             x1, x3
    // 0xba7c88: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba7c88: mov             x17, #0x5eb5
    //     0xba7c8c: movk            x17, #1, lsl #16
    //     0xba7c90: add             lr, x0, x17
    //     0xba7c94: ldr             lr, [x21, lr, lsl #3]
    //     0xba7c98: blr             lr
    // 0xba7c9c: ldur            x2, [fp, #-0x10]
    // 0xba7ca0: StoreField: r2->field_63 = r0
    //     0xba7ca0: stur            w0, [x2, #0x63]
    //     0xba7ca4: ldurb           w16, [x2, #-1]
    //     0xba7ca8: ldurb           w17, [x0, #-1]
    //     0xba7cac: and             x16, x17, x16, lsr #2
    //     0xba7cb0: tst             x16, HEAP, lsr #32
    //     0xba7cb4: b.eq            #0xba7cbc
    //     0xba7cb8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba7cbc: ldur            x1, [fp, #-0x18]
    // 0xba7cc0: r0 = LoadClassIdInstr(r1)
    //     0xba7cc0: ldur            x0, [x1, #-1]
    //     0xba7cc4: ubfx            x0, x0, #0xc, #0x14
    // 0xba7cc8: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba7cc8: mov             x17, #0x5fe3
    //     0xba7ccc: movk            x17, #1, lsl #16
    //     0xba7cd0: add             lr, x0, x17
    //     0xba7cd4: ldr             lr, [x21, lr, lsl #3]
    //     0xba7cd8: blr             lr
    // 0xba7cdc: ldur            x1, [fp, #-0x10]
    // 0xba7ce0: StoreField: r1->field_6b = r0
    //     0xba7ce0: stur            w0, [x1, #0x6b]
    //     0xba7ce4: ldurb           w16, [x1, #-1]
    //     0xba7ce8: ldurb           w17, [x0, #-1]
    //     0xba7cec: and             x16, x17, x16, lsr #2
    //     0xba7cf0: tst             x16, HEAP, lsr #32
    //     0xba7cf4: b.eq            #0xba7cfc
    //     0xba7cf8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba7cfc: r0 = _checkDown()
    //     0xba7cfc: bl              #0xba7d2c  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDown
    // 0xba7d00: b               #0xba7d14
    // 0xba7d04: mov             x1, x2
    // 0xba7d08: r2 = Instance_GestureDisposition
    //     0xba7d08: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba7d0c: ldr             x2, [x2, #0x628]
    // 0xba7d10: r0 = resolve()
    //     0xba7d10: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba7d14: r0 = Null
    //     0xba7d14: mov             x0, NULL
    // 0xba7d18: LeaveFrame
    //     0xba7d18: mov             SP, fp
    //     0xba7d1c: ldp             fp, lr, [SP], #0x10
    // 0xba7d20: ret
    //     0xba7d20: ret             
    // 0xba7d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7d24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7d28: b               #0xba7b14
  }
  _ _checkDown(/* No info */) {
    // ** addr: 0xba7d2c, size: 0xc4
    // 0xba7d2c: EnterFrame
    //     0xba7d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xba7d30: mov             fp, SP
    // 0xba7d34: AllocStack(0x30)
    //     0xba7d34: sub             SP, SP, #0x30
    // 0xba7d38: SetupParameters(DragGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xba7d38: stur            x1, [fp, #-8]
    // 0xba7d3c: CheckStackOverflow
    //     0xba7d3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7d40: cmp             SP, x16
    //     0xba7d44: b.ls            #0xba7ddc
    // 0xba7d48: r1 = 2
    //     0xba7d48: mov             x1, #2
    // 0xba7d4c: r0 = AllocateContext()
    //     0xba7d4c: bl              #0x13de838  ; AllocateContextStub
    // 0xba7d50: mov             x1, x0
    // 0xba7d54: ldur            x0, [fp, #-8]
    // 0xba7d58: stur            x1, [fp, #-0x18]
    // 0xba7d5c: StoreField: r1->field_f = r0
    //     0xba7d5c: stur            w0, [x1, #0xf]
    // 0xba7d60: LoadField: r2 = r0->field_2b
    //     0xba7d60: ldur            w2, [x0, #0x2b]
    // 0xba7d64: DecompressPointer r2
    //     0xba7d64: add             x2, x2, HEAP, lsl #32
    // 0xba7d68: cmp             w2, NULL
    // 0xba7d6c: b.eq            #0xba7dcc
    // 0xba7d70: LoadField: r2 = r0->field_57
    //     0xba7d70: ldur            w2, [x0, #0x57]
    // 0xba7d74: DecompressPointer r2
    //     0xba7d74: add             x2, x2, HEAP, lsl #32
    // 0xba7d78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba7d7c: cmp             w2, w16
    // 0xba7d80: b.eq            #0xba7de4
    // 0xba7d84: LoadField: r3 = r2->field_b
    //     0xba7d84: ldur            w3, [x2, #0xb]
    // 0xba7d88: DecompressPointer r3
    //     0xba7d88: add             x3, x3, HEAP, lsl #32
    // 0xba7d8c: stur            x3, [fp, #-0x10]
    // 0xba7d90: r0 = DragDownDetails()
    //     0xba7d90: bl              #0xba7df0  ; AllocateDragDownDetailsStub -> DragDownDetails (size=0xc)
    // 0xba7d94: mov             x1, x0
    // 0xba7d98: ldur            x0, [fp, #-0x10]
    // 0xba7d9c: StoreField: r1->field_7 = r0
    //     0xba7d9c: stur            w0, [x1, #7]
    // 0xba7da0: ldur            x2, [fp, #-0x18]
    // 0xba7da4: StoreField: r2->field_13 = r1
    //     0xba7da4: stur            w1, [x2, #0x13]
    // 0xba7da8: r1 = Function '<anonymous closure>':.
    //     0xba7da8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96108] AnonymousClosure: (0xba7dfc), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDown (0xba7d2c)
    //     0xba7dac: ldr             x1, [x1, #0x108]
    // 0xba7db0: r0 = AllocateClosure()
    //     0xba7db0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba7db4: r16 = <void?>
    //     0xba7db4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba7db8: ldur            lr, [fp, #-8]
    // 0xba7dbc: stp             lr, x16, [SP, #8]
    // 0xba7dc0: str             x0, [SP]
    // 0xba7dc4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba7dc4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba7dc8: r0 = invokeCallback()
    //     0xba7dc8: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba7dcc: r0 = Null
    //     0xba7dcc: mov             x0, NULL
    // 0xba7dd0: LeaveFrame
    //     0xba7dd0: mov             SP, fp
    //     0xba7dd4: ldp             fp, lr, [SP], #0x10
    // 0xba7dd8: ret
    //     0xba7dd8: ret             
    // 0xba7ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7ddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7de0: b               #0xba7d48
    // 0xba7de4: r9 = _initialPosition
    //     0xba7de4: add             x9, PP, #0x26, lsl #12  ; [pp+0x26638] Field <DragGestureRecognizer._initialPosition@658099969>: late (offset: 0x58)
    //     0xba7de8: ldr             x9, [x9, #0x638]
    // 0xba7dec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba7dec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba7dfc, size: 0x70
    // 0xba7dfc: EnterFrame
    //     0xba7dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xba7e00: mov             fp, SP
    // 0xba7e04: AllocStack(0x10)
    //     0xba7e04: sub             SP, SP, #0x10
    // 0xba7e08: SetupParameters([dynamic _ /* r0 */])
    //     0xba7e08: ldr             x0, [fp, #0x10]
    //     0xba7e0c: ldur            w1, [x0, #0x17]
    //     0xba7e10: add             x1, x1, HEAP, lsl #32
    // 0xba7e14: CheckStackOverflow
    //     0xba7e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7e18: cmp             SP, x16
    //     0xba7e1c: b.ls            #0xba7e60
    // 0xba7e20: LoadField: r0 = r1->field_f
    //     0xba7e20: ldur            w0, [x1, #0xf]
    // 0xba7e24: DecompressPointer r0
    //     0xba7e24: add             x0, x0, HEAP, lsl #32
    // 0xba7e28: LoadField: r2 = r0->field_2b
    //     0xba7e28: ldur            w2, [x0, #0x2b]
    // 0xba7e2c: DecompressPointer r2
    //     0xba7e2c: add             x2, x2, HEAP, lsl #32
    // 0xba7e30: cmp             w2, NULL
    // 0xba7e34: b.eq            #0xba7e68
    // 0xba7e38: LoadField: r0 = r1->field_13
    //     0xba7e38: ldur            w0, [x1, #0x13]
    // 0xba7e3c: DecompressPointer r0
    //     0xba7e3c: add             x0, x0, HEAP, lsl #32
    // 0xba7e40: stp             x0, x2, [SP]
    // 0xba7e44: mov             x0, x2
    // 0xba7e48: ClosureCall
    //     0xba7e48: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba7e4c: ldur            x2, [x0, #0x1f]
    //     0xba7e50: blr             x2
    // 0xba7e54: LeaveFrame
    //     0xba7e54: mov             SP, fp
    //     0xba7e58: ldp             fp, lr, [SP], #0x10
    // 0xba7e5c: ret
    //     0xba7e5c: ret             
    // 0xba7e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7e60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7e64: b               #0xba7e20
    // 0xba7e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba7e68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb16bc, size: 0x4c
    // 0xbb16bc: EnterFrame
    //     0xbb16bc: stp             fp, lr, [SP, #-0x10]!
    //     0xbb16c0: mov             fp, SP
    // 0xbb16c4: AllocStack(0x8)
    //     0xbb16c4: sub             SP, SP, #8
    // 0xbb16c8: SetupParameters(DragGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xbb16c8: mov             x0, x1
    //     0xbb16cc: stur            x1, [fp, #-8]
    // 0xbb16d0: CheckStackOverflow
    //     0xbb16d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb16d4: cmp             SP, x16
    //     0xbb16d8: b.ls            #0xbb1700
    // 0xbb16dc: LoadField: r1 = r0->field_77
    //     0xbb16dc: ldur            w1, [x0, #0x77]
    // 0xbb16e0: DecompressPointer r1
    //     0xbb16e0: add             x1, x1, HEAP, lsl #32
    // 0xbb16e4: r0 = clear()
    //     0xbb16e4: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbb16e8: ldur            x1, [fp, #-8]
    // 0xbb16ec: r0 = dispose()
    //     0xbb16ec: bl              #0xbb179c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbb16f0: r0 = Null
    //     0xbb16f0: mov             x0, NULL
    // 0xbb16f4: LeaveFrame
    //     0xbb16f4: mov             SP, fp
    //     0xbb16f8: ldp             fp, lr, [SP], #0x10
    // 0xbb16fc: ret
    //     0xbb16fc: ret             
    // 0xbb1700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1704: b               #0xbb16dc
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb6d44, size: 0x150
    // 0xbb6d44: EnterFrame
    //     0xbb6d44: stp             fp, lr, [SP, #-0x10]!
    //     0xbb6d48: mov             fp, SP
    // 0xbb6d4c: AllocStack(0x10)
    //     0xbb6d4c: sub             SP, SP, #0x10
    // 0xbb6d50: SetupParameters(DragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbb6d50: mov             x3, x1
    //     0xbb6d54: stur            x1, [fp, #-8]
    //     0xbb6d58: stur            x2, [fp, #-0x10]
    // 0xbb6d5c: CheckStackOverflow
    //     0xbb6d5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb6d60: cmp             SP, x16
    //     0xbb6d64: b.ls            #0xbb6e8c
    // 0xbb6d68: LoadField: r0 = r3->field_67
    //     0xbb6d68: ldur            w0, [x3, #0x67]
    // 0xbb6d6c: DecompressPointer r0
    //     0xbb6d6c: add             x0, x0, HEAP, lsl #32
    // 0xbb6d70: cmp             w0, NULL
    // 0xbb6d74: b.ne            #0xbb6de0
    // 0xbb6d78: LoadField: r0 = r3->field_2b
    //     0xbb6d78: ldur            w0, [x3, #0x2b]
    // 0xbb6d7c: DecompressPointer r0
    //     0xbb6d7c: add             x0, x0, HEAP, lsl #32
    // 0xbb6d80: cmp             w0, NULL
    // 0xbb6d84: b.ne            #0xbb6dd8
    // 0xbb6d88: LoadField: r0 = r3->field_2f
    //     0xbb6d88: ldur            w0, [x3, #0x2f]
    // 0xbb6d8c: DecompressPointer r0
    //     0xbb6d8c: add             x0, x0, HEAP, lsl #32
    // 0xbb6d90: cmp             w0, NULL
    // 0xbb6d94: b.ne            #0xbb6dd8
    // 0xbb6d98: LoadField: r0 = r3->field_33
    //     0xbb6d98: ldur            w0, [x3, #0x33]
    // 0xbb6d9c: DecompressPointer r0
    //     0xbb6d9c: add             x0, x0, HEAP, lsl #32
    // 0xbb6da0: cmp             w0, NULL
    // 0xbb6da4: b.ne            #0xbb6dd8
    // 0xbb6da8: LoadField: r0 = r3->field_37
    //     0xbb6da8: ldur            w0, [x3, #0x37]
    // 0xbb6dac: DecompressPointer r0
    //     0xbb6dac: add             x0, x0, HEAP, lsl #32
    // 0xbb6db0: cmp             w0, NULL
    // 0xbb6db4: b.ne            #0xbb6dd8
    // 0xbb6db8: LoadField: r0 = r3->field_3b
    //     0xbb6db8: ldur            w0, [x3, #0x3b]
    // 0xbb6dbc: DecompressPointer r0
    //     0xbb6dbc: add             x0, x0, HEAP, lsl #32
    // 0xbb6dc0: cmp             w0, NULL
    // 0xbb6dc4: b.ne            #0xbb6dd8
    // 0xbb6dc8: r0 = false
    //     0xbb6dc8: add             x0, NULL, #0x30  ; false
    // 0xbb6dcc: LeaveFrame
    //     0xbb6dcc: mov             SP, fp
    //     0xbb6dd0: ldp             fp, lr, [SP], #0x10
    // 0xbb6dd4: ret
    //     0xbb6dd4: ret             
    // 0xbb6dd8: mov             x2, x3
    // 0xbb6ddc: b               #0xbb6e74
    // 0xbb6de0: r0 = LoadClassIdInstr(r2)
    //     0xbb6de0: ldur            x0, [x2, #-1]
    //     0xbb6de4: ubfx            x0, x0, #0xc, #0x14
    // 0xbb6de8: mov             x1, x2
    // 0xbb6dec: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbb6dec: mov             x17, #0x6f9c
    //     0xbb6df0: movk            x17, #1, lsl #16
    //     0xbb6df4: add             lr, x0, x17
    //     0xbb6df8: ldr             lr, [x21, lr, lsl #3]
    //     0xbb6dfc: blr             lr
    // 0xbb6e00: mov             x3, x0
    // 0xbb6e04: ldur            x2, [fp, #-8]
    // 0xbb6e08: LoadField: r4 = r2->field_67
    //     0xbb6e08: ldur            w4, [x2, #0x67]
    // 0xbb6e0c: DecompressPointer r4
    //     0xbb6e0c: add             x4, x4, HEAP, lsl #32
    // 0xbb6e10: r0 = BoxInt64Instr(r3)
    //     0xbb6e10: sbfiz           x0, x3, #1, #0x1f
    //     0xbb6e14: cmp             x3, x0, asr #1
    //     0xbb6e18: b.eq            #0xbb6e24
    //     0xbb6e1c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb6e20: stur            x3, [x0, #7]
    // 0xbb6e24: cmp             w0, w4
    // 0xbb6e28: b.eq            #0xbb6e74
    // 0xbb6e2c: and             w16, w0, w4
    // 0xbb6e30: branchIfSmi(r16, 0xbb6e64)
    //     0xbb6e30: tbz             w16, #0, #0xbb6e64
    // 0xbb6e34: r16 = LoadClassIdInstr(r0)
    //     0xbb6e34: ldur            x16, [x0, #-1]
    //     0xbb6e38: ubfx            x16, x16, #0xc, #0x14
    // 0xbb6e3c: cmp             x16, #0x3d
    // 0xbb6e40: b.ne            #0xbb6e64
    // 0xbb6e44: r16 = LoadClassIdInstr(r4)
    //     0xbb6e44: ldur            x16, [x4, #-1]
    //     0xbb6e48: ubfx            x16, x16, #0xc, #0x14
    // 0xbb6e4c: cmp             x16, #0x3d
    // 0xbb6e50: b.ne            #0xbb6e64
    // 0xbb6e54: LoadField: r16 = r0->field_7
    //     0xbb6e54: ldur            x16, [x0, #7]
    // 0xbb6e58: LoadField: r17 = r4->field_7
    //     0xbb6e58: ldur            x17, [x4, #7]
    // 0xbb6e5c: cmp             x16, x17
    // 0xbb6e60: b.eq            #0xbb6e74
    // 0xbb6e64: r0 = false
    //     0xbb6e64: add             x0, NULL, #0x30  ; false
    // 0xbb6e68: LeaveFrame
    //     0xbb6e68: mov             SP, fp
    //     0xbb6e6c: ldp             fp, lr, [SP], #0x10
    // 0xbb6e70: ret
    //     0xbb6e70: ret             
    // 0xbb6e74: mov             x1, x2
    // 0xbb6e78: ldur            x2, [fp, #-0x10]
    // 0xbb6e7c: r0 = isPointerAllowed()
    //     0xbb6e7c: bl              #0xbb75f8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xbb6e80: LeaveFrame
    //     0xbb6e80: mov             SP, fp
    //     0xbb6e84: ldp             fp, lr, [SP], #0x10
    // 0xbb6e88: ret
    //     0xbb6e88: ret             
    // 0xbb6e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb6e8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb6e90: b               #0xbb6d68
  }
  _ addAllowedPointerPanZoom(/* No info */) {
    // ** addr: 0xd0074c, size: 0xbc
    // 0xd0074c: EnterFrame
    //     0xd0074c: stp             fp, lr, [SP, #-0x10]!
    //     0xd00750: mov             fp, SP
    // 0xd00754: AllocStack(0x18)
    //     0xd00754: sub             SP, SP, #0x18
    // 0xd00758: SetupParameters(DragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd00758: mov             x3, x1
    //     0xd0075c: stur            x1, [fp, #-8]
    //     0xd00760: stur            x2, [fp, #-0x10]
    // 0xd00764: CheckStackOverflow
    //     0xd00764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00768: cmp             SP, x16
    //     0xd0076c: b.ls            #0xd00800
    // 0xd00770: r0 = LoadClassIdInstr(r2)
    //     0xd00770: ldur            x0, [x2, #-1]
    //     0xd00774: ubfx            x0, x0, #0xc, #0x14
    // 0xd00778: mov             x1, x2
    // 0xd0077c: r0 = GDT[cid_x0 + -0x1]()
    //     0xd0077c: sub             lr, x0, #1
    //     0xd00780: ldr             lr, [x21, lr, lsl #3]
    //     0xd00784: blr             lr
    // 0xd00788: mov             x3, x0
    // 0xd0078c: ldur            x2, [fp, #-0x10]
    // 0xd00790: stur            x3, [fp, #-0x18]
    // 0xd00794: r0 = LoadClassIdInstr(r2)
    //     0xd00794: ldur            x0, [x2, #-1]
    //     0xd00798: ubfx            x0, x0, #0xc, #0x14
    // 0xd0079c: mov             x1, x2
    // 0xd007a0: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xd007a0: mov             x17, #0x5fe3
    //     0xd007a4: movk            x17, #1, lsl #16
    //     0xd007a8: add             lr, x0, x17
    //     0xd007ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd007b0: blr             lr
    // 0xd007b4: ldur            x1, [fp, #-8]
    // 0xd007b8: ldur            x2, [fp, #-0x18]
    // 0xd007bc: mov             x3, x0
    // 0xd007c0: r0 = startTrackingPointer()
    //     0xd007c0: bl              #0x10f2e54  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0xd007c4: ldur            x1, [fp, #-8]
    // 0xd007c8: LoadField: r0 = r1->field_53
    //     0xd007c8: ldur            w0, [x1, #0x53]
    // 0xd007cc: DecompressPointer r0
    //     0xd007cc: add             x0, x0, HEAP, lsl #32
    // 0xd007d0: r16 = Instance__DragState
    //     0xd007d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!_DragState@12c5ce1
    //     0xd007d4: ldr             x16, [x16, #0x530]
    // 0xd007d8: cmp             w0, w16
    // 0xd007dc: b.ne            #0xd007e8
    // 0xd007e0: r0 = 2
    //     0xd007e0: mov             x0, #2
    // 0xd007e4: StoreField: r1->field_67 = r0
    //     0xd007e4: stur            w0, [x1, #0x67]
    // 0xd007e8: ldur            x2, [fp, #-0x10]
    // 0xd007ec: r0 = _addPointer()
    //     0xd007ec: bl              #0xba7af0  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_addPointer
    // 0xd007f0: r0 = Null
    //     0xd007f0: mov             x0, NULL
    // 0xd007f4: LeaveFrame
    //     0xd007f4: mov             SP, fp
    //     0xd007f8: ldp             fp, lr, [SP], #0x10
    // 0xd007fc: ret
    //     0xd007fc: ret             
    // 0xd00800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00800: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00804: b               #0xd00770
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116cf60, size: 0x30
    // 0x116cf60: EnterFrame
    //     0x116cf60: stp             fp, lr, [SP, #-0x10]!
    //     0x116cf64: mov             fp, SP
    // 0x116cf68: CheckStackOverflow
    //     0x116cf68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116cf6c: cmp             SP, x16
    //     0x116cf70: b.ls            #0x116cf88
    // 0x116cf74: r0 = _giveUpPointer()
    //     0x116cf74: bl              #0xb9f334  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0x116cf78: r0 = Null
    //     0x116cf78: mov             x0, NULL
    // 0x116cf7c: LeaveFrame
    //     0x116cf7c: mov             SP, fp
    //     0x116cf80: ldp             fp, lr, [SP], #0x10
    // 0x116cf84: ret
    //     0x116cf84: ret             
    // 0x116cf88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116cf88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116cf8c: b               #0x116cf74
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119c370, size: 0x120
    // 0x119c370: EnterFrame
    //     0x119c370: stp             fp, lr, [SP, #-0x10]!
    //     0x119c374: mov             fp, SP
    // 0x119c378: AllocStack(0x20)
    //     0x119c378: sub             SP, SP, #0x20
    // 0x119c37c: SetupParameters(DragGestureRecognizer this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x119c37c: mov             x0, x1
    //     0x119c380: stur            x1, [fp, #-0x18]
    //     0x119c384: stur            x2, [fp, #-0x20]
    // 0x119c388: CheckStackOverflow
    //     0x119c388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c38c: cmp             SP, x16
    //     0x119c390: b.ls            #0x119c488
    // 0x119c394: LoadField: r3 = r0->field_87
    //     0x119c394: ldur            w3, [x0, #0x87]
    // 0x119c398: DecompressPointer r3
    //     0x119c398: add             x3, x3, HEAP, lsl #32
    // 0x119c39c: stur            x3, [fp, #-0x10]
    // 0x119c3a0: LoadField: r1 = r3->field_b
    //     0x119c3a0: ldur            w1, [x3, #0xb]
    // 0x119c3a4: LoadField: r4 = r3->field_f
    //     0x119c3a4: ldur            w4, [x3, #0xf]
    // 0x119c3a8: DecompressPointer r4
    //     0x119c3a8: add             x4, x4, HEAP, lsl #32
    // 0x119c3ac: LoadField: r5 = r4->field_b
    //     0x119c3ac: ldur            w5, [x4, #0xb]
    // 0x119c3b0: r4 = LoadInt32Instr(r1)
    //     0x119c3b0: sbfx            x4, x1, #1, #0x1f
    // 0x119c3b4: stur            x4, [fp, #-8]
    // 0x119c3b8: r1 = LoadInt32Instr(r5)
    //     0x119c3b8: sbfx            x1, x5, #1, #0x1f
    // 0x119c3bc: cmp             x4, x1
    // 0x119c3c0: b.ne            #0x119c3cc
    // 0x119c3c4: mov             x1, x3
    // 0x119c3c8: r0 = _growToNextCapacity()
    //     0x119c3c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x119c3cc: ldur            x3, [fp, #-0x18]
    // 0x119c3d0: ldur            x2, [fp, #-0x20]
    // 0x119c3d4: ldur            x0, [fp, #-0x10]
    // 0x119c3d8: ldur            x4, [fp, #-8]
    // 0x119c3dc: add             x1, x4, #1
    // 0x119c3e0: lsl             x5, x1, #1
    // 0x119c3e4: StoreField: r0->field_b = r5
    //     0x119c3e4: stur            w5, [x0, #0xb]
    // 0x119c3e8: LoadField: r5 = r0->field_f
    //     0x119c3e8: ldur            w5, [x0, #0xf]
    // 0x119c3ec: DecompressPointer r5
    //     0x119c3ec: add             x5, x5, HEAP, lsl #32
    // 0x119c3f0: r0 = BoxInt64Instr(r2)
    //     0x119c3f0: sbfiz           x0, x2, #1, #0x1f
    //     0x119c3f4: cmp             x2, x0, asr #1
    //     0x119c3f8: b.eq            #0x119c404
    //     0x119c3fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x119c400: stur            x2, [x0, #7]
    // 0x119c404: mov             x1, x5
    // 0x119c408: mov             x5, x0
    // 0x119c40c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x119c40c: add             x25, x1, x4, lsl #2
    //     0x119c410: add             x25, x25, #0xf
    //     0x119c414: str             w0, [x25]
    //     0x119c418: tbz             w0, #0, #0x119c434
    //     0x119c41c: ldurb           w16, [x1, #-1]
    //     0x119c420: ldurb           w17, [x0, #-1]
    //     0x119c424: and             x16, x17, x16, lsr #2
    //     0x119c428: tst             x16, HEAP, lsr #32
    //     0x119c42c: b.eq            #0x119c434
    //     0x119c430: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x119c434: mov             x0, x5
    // 0x119c438: StoreField: r3->field_8b = r0
    //     0x119c438: stur            w0, [x3, #0x8b]
    //     0x119c43c: tbz             w0, #0, #0x119c458
    //     0x119c440: ldurb           w16, [x3, #-1]
    //     0x119c444: ldurb           w17, [x0, #-1]
    //     0x119c448: and             x16, x17, x16, lsr #2
    //     0x119c44c: tst             x16, HEAP, lsr #32
    //     0x119c450: b.eq            #0x119c458
    //     0x119c454: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x119c458: LoadField: r0 = r3->field_4b
    //     0x119c458: ldur            w0, [x3, #0x4b]
    // 0x119c45c: DecompressPointer r0
    //     0x119c45c: add             x0, x0, HEAP, lsl #32
    // 0x119c460: tbnz            w0, #4, #0x119c470
    // 0x119c464: LoadField: r0 = r3->field_73
    //     0x119c464: ldur            w0, [x3, #0x73]
    // 0x119c468: DecompressPointer r0
    //     0x119c468: add             x0, x0, HEAP, lsl #32
    // 0x119c46c: tbnz            w0, #4, #0x119c478
    // 0x119c470: mov             x1, x3
    // 0x119c474: r0 = _checkDrag()
    //     0x119c474: bl              #0xb9e510  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDrag
    // 0x119c478: r0 = Null
    //     0x119c478: mov             x0, NULL
    // 0x119c47c: LeaveFrame
    //     0x119c47c: mov             SP, fp
    //     0x119c480: ldp             fp, lr, [SP], #0x10
    // 0x119c484: ret
    //     0x119c484: ret             
    // 0x119c488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c48c: b               #0x119c394
  }
}

// class id: 4442, size: 0x90, field offset: 0x90
class PanGestureRecognizer extends DragGestureRecognizer {

  _ hasSufficientGlobalDistanceToAccept(/* No info */) {
    // ** addr: 0x115c578, size: 0xa8
    // 0x115c578: EnterFrame
    //     0x115c578: stp             fp, lr, [SP, #-0x10]!
    //     0x115c57c: mov             fp, SP
    // 0x115c580: AllocStack(0x8)
    //     0x115c580: sub             SP, SP, #8
    // 0x115c584: d0 = 0.000000
    //     0x115c584: eor             v0.16b, v0.16b, v0.16b
    // 0x115c588: mov             x0, x1
    // 0x115c58c: mov             x1, x2
    // 0x115c590: CheckStackOverflow
    //     0x115c590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c594: cmp             SP, x16
    //     0x115c598: b.ls            #0x115c60c
    // 0x115c59c: LoadField: r2 = r0->field_6f
    //     0x115c59c: ldur            w2, [x0, #0x6f]
    // 0x115c5a0: DecompressPointer r2
    //     0x115c5a0: add             x2, x2, HEAP, lsl #32
    // 0x115c5a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115c5a8: cmp             w2, w16
    // 0x115c5ac: b.eq            #0x115c614
    // 0x115c5b0: LoadField: d1 = r2->field_7
    //     0x115c5b0: ldur            d1, [x2, #7]
    // 0x115c5b4: fcmp            d1, d0
    // 0x115c5b8: b.ne            #0x115c5c4
    // 0x115c5bc: d0 = 0.000000
    //     0x115c5bc: eor             v0.16b, v0.16b, v0.16b
    // 0x115c5c0: b               #0x115c5d8
    // 0x115c5c4: fcmp            d0, d1
    // 0x115c5c8: b.le            #0x115c5d4
    // 0x115c5cc: fneg            d0, d1
    // 0x115c5d0: b               #0x115c5d8
    // 0x115c5d4: mov             v0.16b, v1.16b
    // 0x115c5d8: stur            d0, [fp, #-8]
    // 0x115c5dc: LoadField: r2 = r0->field_7
    //     0x115c5dc: ldur            w2, [x0, #7]
    // 0x115c5e0: DecompressPointer r2
    //     0x115c5e0: add             x2, x2, HEAP, lsl #32
    // 0x115c5e4: r0 = computePanSlop()
    //     0x115c5e4: bl              #0xb9c828  ; [package:flutter/src/gestures/events.dart] ::computePanSlop
    // 0x115c5e8: mov             v1.16b, v0.16b
    // 0x115c5ec: ldur            d0, [fp, #-8]
    // 0x115c5f0: fcmp            d0, d1
    // 0x115c5f4: r16 = true
    //     0x115c5f4: add             x16, NULL, #0x20  ; true
    // 0x115c5f8: r17 = false
    //     0x115c5f8: add             x17, NULL, #0x30  ; false
    // 0x115c5fc: csel            x0, x16, x17, gt
    // 0x115c600: LeaveFrame
    //     0x115c600: mov             SP, fp
    //     0x115c604: ldp             fp, lr, [SP], #0x10
    // 0x115c608: ret
    //     0x115c608: ret             
    // 0x115c60c: r0 = StackOverflowSharedWithFPURegs()
    //     0x115c60c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115c610: b               #0x115c59c
    // 0x115c614: r9 = _globalDistanceMoved
    //     0x115c614: add             x9, PP, #0x80, lsl #12  ; [pp+0x80b78] Field <DragGestureRecognizer._globalDistanceMoved@658099969>: late (offset: 0x70)
    //     0x115c618: ldr             x9, [x9, #0xb78]
    // 0x115c61c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x115c61c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ considerFling(/* No info */) {
    // ** addr: 0x119f20c, size: 0x114
    // 0x119f20c: EnterFrame
    //     0x119f20c: stp             fp, lr, [SP, #-0x10]!
    //     0x119f210: mov             fp, SP
    // 0x119f214: AllocStack(0x18)
    //     0x119f214: sub             SP, SP, #0x18
    // 0x119f218: SetupParameters(PanGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119f218: mov             x4, x1
    //     0x119f21c: mov             x0, x2
    //     0x119f220: stur            x1, [fp, #-8]
    //     0x119f224: stur            x2, [fp, #-0x10]
    // 0x119f228: CheckStackOverflow
    //     0x119f228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f22c: cmp             SP, x16
    //     0x119f230: b.ls            #0x119f30c
    // 0x119f234: mov             x1, x4
    // 0x119f238: mov             x2, x0
    // 0x119f23c: r0 = isFlingGesture()
    //     0x119f23c: bl              #0x119f400  ; [package:flutter/src/gestures/monodrag.dart] PanGestureRecognizer::isFlingGesture
    // 0x119f240: tbz             w0, #4, #0x119f254
    // 0x119f244: r0 = Null
    //     0x119f244: mov             x0, NULL
    // 0x119f248: LeaveFrame
    //     0x119f248: mov             SP, fp
    //     0x119f24c: ldp             fp, lr, [SP], #0x10
    // 0x119f250: ret
    //     0x119f250: ret             
    // 0x119f254: ldur            x1, [fp, #-8]
    // 0x119f258: ldur            x0, [fp, #-0x10]
    // 0x119f25c: LoadField: r2 = r0->field_7
    //     0x119f25c: ldur            w2, [x0, #7]
    // 0x119f260: DecompressPointer r2
    //     0x119f260: add             x2, x2, HEAP, lsl #32
    // 0x119f264: stur            x2, [fp, #-0x18]
    // 0x119f268: r0 = Velocity()
    //     0x119f268: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x119f26c: mov             x1, x0
    // 0x119f270: ldur            x0, [fp, #-0x18]
    // 0x119f274: StoreField: r1->field_7 = r0
    //     0x119f274: stur            w0, [x1, #7]
    // 0x119f278: ldur            x0, [fp, #-8]
    // 0x119f27c: LoadField: r2 = r0->field_43
    //     0x119f27c: ldur            w2, [x0, #0x43]
    // 0x119f280: DecompressPointer r2
    //     0x119f280: add             x2, x2, HEAP, lsl #32
    // 0x119f284: cmp             w2, NULL
    // 0x119f288: b.ne            #0x119f298
    // 0x119f28c: d0 = 50.000000
    //     0x119f28c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0x119f290: ldr             d0, [x17, #0x1d0]
    // 0x119f294: b               #0x119f29c
    // 0x119f298: LoadField: d0 = r2->field_7
    //     0x119f298: ldur            d0, [x2, #7]
    // 0x119f29c: LoadField: r2 = r0->field_47
    //     0x119f29c: ldur            w2, [x0, #0x47]
    // 0x119f2a0: DecompressPointer r2
    //     0x119f2a0: add             x2, x2, HEAP, lsl #32
    // 0x119f2a4: cmp             w2, NULL
    // 0x119f2a8: b.ne            #0x119f2b8
    // 0x119f2ac: d1 = 8000.000000
    //     0x119f2ac: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cd28] IMM: double(8000) from 0x40bf400000000000
    //     0x119f2b0: ldr             d1, [x17, #0xd28]
    // 0x119f2b4: b               #0x119f2bc
    // 0x119f2b8: LoadField: d1 = r2->field_7
    //     0x119f2b8: ldur            d1, [x2, #7]
    // 0x119f2bc: r0 = clampMagnitude()
    //     0x119f2bc: bl              #0x119f320  ; [package:flutter/src/gestures/velocity_tracker.dart] Velocity::clampMagnitude
    // 0x119f2c0: mov             x1, x0
    // 0x119f2c4: ldur            x0, [fp, #-8]
    // 0x119f2c8: stur            x1, [fp, #-0x10]
    // 0x119f2cc: LoadField: r2 = r0->field_5f
    //     0x119f2cc: ldur            w2, [x0, #0x5f]
    // 0x119f2d0: DecompressPointer r2
    //     0x119f2d0: add             x2, x2, HEAP, lsl #32
    // 0x119f2d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119f2d8: cmp             w2, w16
    // 0x119f2dc: b.eq            #0x119f314
    // 0x119f2e0: LoadField: r0 = r2->field_b
    //     0x119f2e0: ldur            w0, [x2, #0xb]
    // 0x119f2e4: DecompressPointer r0
    //     0x119f2e4: add             x0, x0, HEAP, lsl #32
    // 0x119f2e8: stur            x0, [fp, #-8]
    // 0x119f2ec: r0 = DragEndDetails()
    //     0x119f2ec: bl              #0xb99344  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x14)
    // 0x119f2f0: ldur            x1, [fp, #-8]
    // 0x119f2f4: StoreField: r0->field_7 = r1
    //     0x119f2f4: stur            w1, [x0, #7]
    // 0x119f2f8: ldur            x1, [fp, #-0x10]
    // 0x119f2fc: StoreField: r0->field_b = r1
    //     0x119f2fc: stur            w1, [x0, #0xb]
    // 0x119f300: LeaveFrame
    //     0x119f300: mov             SP, fp
    //     0x119f304: ldp             fp, lr, [SP], #0x10
    // 0x119f308: ret
    //     0x119f308: ret             
    // 0x119f30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f30c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f310: b               #0x119f234
    // 0x119f314: r9 = _lastPosition
    //     0x119f314: add             x9, PP, #0x80, lsl #12  ; [pp+0x80bc8] Field <DragGestureRecognizer._lastPosition@658099969>: late (offset: 0x60)
    //     0x119f318: ldr             x9, [x9, #0xbc8]
    // 0x119f31c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119f31c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ isFlingGesture(/* No info */) {
    // ** addr: 0x119f400, size: 0xf8
    // 0x119f400: LoadField: r4 = r1->field_43
    //     0x119f400: ldur            w4, [x1, #0x43]
    // 0x119f404: DecompressPointer r4
    //     0x119f404: add             x4, x4, HEAP, lsl #32
    // 0x119f408: cmp             w4, NULL
    // 0x119f40c: b.ne            #0x119f41c
    // 0x119f410: d0 = 50.000000
    //     0x119f410: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0x119f414: ldr             d0, [x17, #0x1d0]
    // 0x119f418: b               #0x119f420
    // 0x119f41c: LoadField: d0 = r4->field_7
    //     0x119f41c: ldur            d0, [x4, #7]
    // 0x119f420: LoadField: r4 = r1->field_3f
    //     0x119f420: ldur            w4, [x1, #0x3f]
    // 0x119f424: DecompressPointer r4
    //     0x119f424: add             x4, x4, HEAP, lsl #32
    // 0x119f428: cmp             w4, NULL
    // 0x119f42c: b.ne            #0x119f48c
    // 0x119f430: LoadField: r5 = r1->field_7
    //     0x119f430: ldur            w5, [x1, #7]
    // 0x119f434: DecompressPointer r5
    //     0x119f434: add             x5, x5, HEAP, lsl #32
    // 0x119f438: LoadField: r1 = r3->field_7
    //     0x119f438: ldur            x1, [x3, #7]
    // 0x119f43c: cmp             x1, #2
    // 0x119f440: b.gt            #0x119f45c
    // 0x119f444: cmp             x1, #1
    // 0x119f448: b.gt            #0x119f45c
    // 0x119f44c: cmp             x1, #0
    // 0x119f450: b.le            #0x119f45c
    // 0x119f454: d1 = 1.000000
    //     0x119f454: fmov            d1, #1.00000000
    // 0x119f458: b               #0x119f490
    // 0x119f45c: cmp             w5, NULL
    // 0x119f460: b.ne            #0x119f46c
    // 0x119f464: r1 = Null
    //     0x119f464: mov             x1, NULL
    // 0x119f468: b               #0x119f474
    // 0x119f46c: LoadField: r1 = r5->field_7
    //     0x119f46c: ldur            w1, [x5, #7]
    // 0x119f470: DecompressPointer r1
    //     0x119f470: add             x1, x1, HEAP, lsl #32
    // 0x119f474: cmp             w1, NULL
    // 0x119f478: b.ne            #0x119f484
    // 0x119f47c: d1 = 18.000000
    //     0x119f47c: fmov            d1, #18.00000000
    // 0x119f480: b               #0x119f490
    // 0x119f484: LoadField: d1 = r1->field_7
    //     0x119f484: ldur            d1, [x1, #7]
    // 0x119f488: b               #0x119f490
    // 0x119f48c: LoadField: d1 = r4->field_7
    //     0x119f48c: ldur            d1, [x4, #7]
    // 0x119f490: LoadField: r1 = r2->field_7
    //     0x119f490: ldur            w1, [x2, #7]
    // 0x119f494: DecompressPointer r1
    //     0x119f494: add             x1, x1, HEAP, lsl #32
    // 0x119f498: LoadField: d2 = r1->field_7
    //     0x119f498: ldur            d2, [x1, #7]
    // 0x119f49c: fmul            d3, d2, d2
    // 0x119f4a0: LoadField: d2 = r1->field_f
    //     0x119f4a0: ldur            d2, [x1, #0xf]
    // 0x119f4a4: fmul            d4, d2, d2
    // 0x119f4a8: fadd            d2, d3, d4
    // 0x119f4ac: fmul            d3, d0, d0
    // 0x119f4b0: fcmp            d2, d3
    // 0x119f4b4: b.le            #0x119f4f0
    // 0x119f4b8: LoadField: r1 = r2->field_13
    //     0x119f4b8: ldur            w1, [x2, #0x13]
    // 0x119f4bc: DecompressPointer r1
    //     0x119f4bc: add             x1, x1, HEAP, lsl #32
    // 0x119f4c0: LoadField: d0 = r1->field_7
    //     0x119f4c0: ldur            d0, [x1, #7]
    // 0x119f4c4: fmul            d2, d0, d0
    // 0x119f4c8: LoadField: d0 = r1->field_f
    //     0x119f4c8: ldur            d0, [x1, #0xf]
    // 0x119f4cc: fmul            d3, d0, d0
    // 0x119f4d0: fadd            d0, d2, d3
    // 0x119f4d4: fmul            d2, d1, d1
    // 0x119f4d8: fcmp            d0, d2
    // 0x119f4dc: r16 = true
    //     0x119f4dc: add             x16, NULL, #0x20  ; true
    // 0x119f4e0: r17 = false
    //     0x119f4e0: add             x17, NULL, #0x30  ; false
    // 0x119f4e4: csel            x1, x16, x17, gt
    // 0x119f4e8: mov             x0, x1
    // 0x119f4ec: b               #0x119f4f4
    // 0x119f4f0: r0 = false
    //     0x119f4f0: add             x0, NULL, #0x30  ; false
    // 0x119f4f4: ret
    //     0x119f4f4: ret             
  }
}

// class id: 4443, size: 0x90, field offset: 0x90
class HorizontalDragGestureRecognizer extends DragGestureRecognizer {

  _ hasSufficientGlobalDistanceToAccept(/* No info */) {
    // ** addr: 0x115c4b8, size: 0xc0
    // 0x115c4b8: d0 = 0.000000
    //     0x115c4b8: eor             v0.16b, v0.16b, v0.16b
    // 0x115c4bc: LoadField: r3 = r1->field_6f
    //     0x115c4bc: ldur            w3, [x1, #0x6f]
    // 0x115c4c0: DecompressPointer r3
    //     0x115c4c0: add             x3, x3, HEAP, lsl #32
    // 0x115c4c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115c4c8: cmp             w3, w16
    // 0x115c4cc: b.eq            #0x115c564
    // 0x115c4d0: LoadField: d1 = r3->field_7
    //     0x115c4d0: ldur            d1, [x3, #7]
    // 0x115c4d4: fcmp            d1, d0
    // 0x115c4d8: b.ne            #0x115c4e4
    // 0x115c4dc: d0 = 0.000000
    //     0x115c4dc: eor             v0.16b, v0.16b, v0.16b
    // 0x115c4e0: b               #0x115c4f8
    // 0x115c4e4: fcmp            d0, d1
    // 0x115c4e8: b.le            #0x115c4f4
    // 0x115c4ec: fneg            d0, d1
    // 0x115c4f0: b               #0x115c4f8
    // 0x115c4f4: mov             v0.16b, v1.16b
    // 0x115c4f8: LoadField: r3 = r1->field_7
    //     0x115c4f8: ldur            w3, [x1, #7]
    // 0x115c4fc: DecompressPointer r3
    //     0x115c4fc: add             x3, x3, HEAP, lsl #32
    // 0x115c500: LoadField: r1 = r2->field_7
    //     0x115c500: ldur            x1, [x2, #7]
    // 0x115c504: cmp             x1, #2
    // 0x115c508: b.gt            #0x115c524
    // 0x115c50c: cmp             x1, #1
    // 0x115c510: b.gt            #0x115c524
    // 0x115c514: cmp             x1, #0
    // 0x115c518: b.le            #0x115c524
    // 0x115c51c: d1 = 1.000000
    //     0x115c51c: fmov            d1, #1.00000000
    // 0x115c520: b               #0x115c550
    // 0x115c524: cmp             w3, NULL
    // 0x115c528: b.ne            #0x115c534
    // 0x115c52c: r1 = Null
    //     0x115c52c: mov             x1, NULL
    // 0x115c530: b               #0x115c53c
    // 0x115c534: LoadField: r1 = r3->field_7
    //     0x115c534: ldur            w1, [x3, #7]
    // 0x115c538: DecompressPointer r1
    //     0x115c538: add             x1, x1, HEAP, lsl #32
    // 0x115c53c: cmp             w1, NULL
    // 0x115c540: b.ne            #0x115c54c
    // 0x115c544: d1 = 18.000000
    //     0x115c544: fmov            d1, #18.00000000
    // 0x115c548: b               #0x115c550
    // 0x115c54c: LoadField: d1 = r1->field_7
    //     0x115c54c: ldur            d1, [x1, #7]
    // 0x115c550: fcmp            d0, d1
    // 0x115c554: r16 = true
    //     0x115c554: add             x16, NULL, #0x20  ; true
    // 0x115c558: r17 = false
    //     0x115c558: add             x17, NULL, #0x30  ; false
    // 0x115c55c: csel            x0, x16, x17, gt
    // 0x115c560: ret
    //     0x115c560: ret             
    // 0x115c564: EnterFrame
    //     0x115c564: stp             fp, lr, [SP, #-0x10]!
    //     0x115c568: mov             fp, SP
    // 0x115c56c: r9 = _globalDistanceMoved
    //     0x115c56c: add             x9, PP, #0x80, lsl #12  ; [pp+0x80b78] Field <DragGestureRecognizer._globalDistanceMoved@658099969>: late (offset: 0x70)
    //     0x115c570: ldr             x9, [x9, #0xb78]
    // 0x115c574: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x115c574: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _getPrimaryValueFromOffset(/* No info */) {
    // ** addr: 0x119cdcc, size: 0x54
    // 0x119cdcc: EnterFrame
    //     0x119cdcc: stp             fp, lr, [SP, #-0x10]!
    //     0x119cdd0: mov             fp, SP
    // 0x119cdd4: LoadField: d0 = r2->field_7
    //     0x119cdd4: ldur            d0, [x2, #7]
    // 0x119cdd8: r0 = inline_Allocate_Double()
    //     0x119cdd8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x119cddc: add             x0, x0, #0x10
    //     0x119cde0: cmp             x1, x0
    //     0x119cde4: b.ls            #0x119ce10
    //     0x119cde8: str             x0, [THR, #0x60]  ; THR::top
    //     0x119cdec: sub             x0, x0, #0xf
    //     0x119cdf0: mov             x1, #0xe19c
    //     0x119cdf4: movk            x1, #3, lsl #16
    //     0x119cdf8: stur            x1, [x0, #-1]
    // 0x119cdfc: dmb             ishst
    // 0x119ce00: StoreField: r0->field_7 = d0
    //     0x119ce00: stur            d0, [x0, #7]
    // 0x119ce04: LeaveFrame
    //     0x119ce04: mov             SP, fp
    //     0x119ce08: ldp             fp, lr, [SP], #0x10
    // 0x119ce0c: ret
    //     0x119ce0c: ret             
    // 0x119ce10: SaveReg d0
    //     0x119ce10: str             q0, [SP, #-0x10]!
    // 0x119ce14: r0 = AllocateDouble()
    //     0x119ce14: bl              #0x13df878  ; AllocateDoubleStub
    // 0x119ce18: RestoreReg d0
    //     0x119ce18: ldr             q0, [SP], #0x10
    // 0x119ce1c: b               #0x119ce00
  }
  _ considerFling(/* No info */) {
    // ** addr: 0x119ef78, size: 0x178
    // 0x119ef78: EnterFrame
    //     0x119ef78: stp             fp, lr, [SP, #-0x10]!
    //     0x119ef7c: mov             fp, SP
    // 0x119ef80: AllocStack(0x20)
    //     0x119ef80: sub             SP, SP, #0x20
    // 0x119ef84: SetupParameters(HorizontalDragGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119ef84: mov             x4, x1
    //     0x119ef88: mov             x0, x2
    //     0x119ef8c: stur            x1, [fp, #-8]
    //     0x119ef90: stur            x2, [fp, #-0x10]
    // 0x119ef94: CheckStackOverflow
    //     0x119ef94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119ef98: cmp             SP, x16
    //     0x119ef9c: b.ls            #0x119f0c0
    // 0x119efa0: mov             x1, x4
    // 0x119efa4: mov             x2, x0
    // 0x119efa8: r0 = isFlingGesture()
    //     0x119efa8: bl              #0x119f0f0  ; [package:flutter/src/gestures/monodrag.dart] HorizontalDragGestureRecognizer::isFlingGesture
    // 0x119efac: tbz             w0, #4, #0x119efc0
    // 0x119efb0: r0 = Null
    //     0x119efb0: mov             x0, NULL
    // 0x119efb4: LeaveFrame
    //     0x119efb4: mov             SP, fp
    //     0x119efb8: ldp             fp, lr, [SP], #0x10
    // 0x119efbc: ret
    //     0x119efbc: ret             
    // 0x119efc0: ldur            x0, [fp, #-8]
    // 0x119efc4: LoadField: r1 = r0->field_47
    //     0x119efc4: ldur            w1, [x0, #0x47]
    // 0x119efc8: DecompressPointer r1
    //     0x119efc8: add             x1, x1, HEAP, lsl #32
    // 0x119efcc: cmp             w1, NULL
    // 0x119efd0: b.ne            #0x119efe0
    // 0x119efd4: d0 = 8000.000000
    //     0x119efd4: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cd28] IMM: double(8000) from 0x40bf400000000000
    //     0x119efd8: ldr             d0, [x17, #0xd28]
    // 0x119efdc: b               #0x119efe4
    // 0x119efe0: LoadField: d0 = r1->field_7
    //     0x119efe0: ldur            d0, [x1, #7]
    // 0x119efe4: ldur            x1, [fp, #-0x10]
    // 0x119efe8: LoadField: r2 = r1->field_7
    //     0x119efe8: ldur            w2, [x1, #7]
    // 0x119efec: DecompressPointer r2
    //     0x119efec: add             x2, x2, HEAP, lsl #32
    // 0x119eff0: LoadField: d1 = r2->field_7
    //     0x119eff0: ldur            d1, [x2, #7]
    // 0x119eff4: fneg            d2, d0
    // 0x119eff8: fcmp            d2, d1
    // 0x119effc: b.le            #0x119f008
    // 0x119f000: mov             v0.16b, v2.16b
    // 0x119f004: b               #0x119f01c
    // 0x119f008: fcmp            d1, d0
    // 0x119f00c: b.gt            #0x119f01c
    // 0x119f010: fcmp            d1, d1
    // 0x119f014: b.vs            #0x119f01c
    // 0x119f018: mov             v0.16b, v1.16b
    // 0x119f01c: stur            d0, [fp, #-0x20]
    // 0x119f020: r0 = Offset()
    //     0x119f020: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x119f024: ldur            d0, [fp, #-0x20]
    // 0x119f028: stur            x0, [fp, #-0x10]
    // 0x119f02c: StoreField: r0->field_7 = d0
    //     0x119f02c: stur            d0, [x0, #7]
    // 0x119f030: StoreField: r0->field_f = rZR
    //     0x119f030: stur            xzr, [x0, #0xf]
    // 0x119f034: r0 = Velocity()
    //     0x119f034: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x119f038: mov             x1, x0
    // 0x119f03c: ldur            x0, [fp, #-0x10]
    // 0x119f040: stur            x1, [fp, #-0x18]
    // 0x119f044: StoreField: r1->field_7 = r0
    //     0x119f044: stur            w0, [x1, #7]
    // 0x119f048: ldur            x0, [fp, #-8]
    // 0x119f04c: LoadField: r2 = r0->field_5f
    //     0x119f04c: ldur            w2, [x0, #0x5f]
    // 0x119f050: DecompressPointer r2
    //     0x119f050: add             x2, x2, HEAP, lsl #32
    // 0x119f054: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119f058: cmp             w2, w16
    // 0x119f05c: b.eq            #0x119f0c8
    // 0x119f060: LoadField: r0 = r2->field_b
    //     0x119f060: ldur            w0, [x2, #0xb]
    // 0x119f064: DecompressPointer r0
    //     0x119f064: add             x0, x0, HEAP, lsl #32
    // 0x119f068: stur            x0, [fp, #-8]
    // 0x119f06c: r0 = DragEndDetails()
    //     0x119f06c: bl              #0xb99344  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x14)
    // 0x119f070: ldur            x1, [fp, #-8]
    // 0x119f074: StoreField: r0->field_7 = r1
    //     0x119f074: stur            w1, [x0, #7]
    // 0x119f078: ldur            x1, [fp, #-0x18]
    // 0x119f07c: StoreField: r0->field_b = r1
    //     0x119f07c: stur            w1, [x0, #0xb]
    // 0x119f080: ldur            d0, [fp, #-0x20]
    // 0x119f084: r1 = inline_Allocate_Double()
    //     0x119f084: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x119f088: add             x1, x1, #0x10
    //     0x119f08c: cmp             x2, x1
    //     0x119f090: b.ls            #0x119f0d4
    //     0x119f094: str             x1, [THR, #0x60]  ; THR::top
    //     0x119f098: sub             x1, x1, #0xf
    //     0x119f09c: mov             x2, #0xe19c
    //     0x119f0a0: movk            x2, #3, lsl #16
    //     0x119f0a4: stur            x2, [x1, #-1]
    // 0x119f0a8: dmb             ishst
    // 0x119f0ac: StoreField: r1->field_7 = d0
    //     0x119f0ac: stur            d0, [x1, #7]
    // 0x119f0b0: StoreField: r0->field_f = r1
    //     0x119f0b0: stur            w1, [x0, #0xf]
    // 0x119f0b4: LeaveFrame
    //     0x119f0b4: mov             SP, fp
    //     0x119f0b8: ldp             fp, lr, [SP], #0x10
    // 0x119f0bc: ret
    //     0x119f0bc: ret             
    // 0x119f0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f0c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f0c4: b               #0x119efa0
    // 0x119f0c8: r9 = _lastPosition
    //     0x119f0c8: add             x9, PP, #0x80, lsl #12  ; [pp+0x80bc8] Field <DragGestureRecognizer._lastPosition@658099969>: late (offset: 0x60)
    //     0x119f0cc: ldr             x9, [x9, #0xbc8]
    // 0x119f0d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119f0d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119f0d4: SaveReg d0
    //     0x119f0d4: str             q0, [SP, #-0x10]!
    // 0x119f0d8: SaveReg r0
    //     0x119f0d8: str             x0, [SP, #-8]!
    // 0x119f0dc: r0 = AllocateDouble()
    //     0x119f0dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x119f0e0: mov             x1, x0
    // 0x119f0e4: RestoreReg r0
    //     0x119f0e4: ldr             x0, [SP], #8
    // 0x119f0e8: RestoreReg d0
    //     0x119f0e8: ldr             q0, [SP], #0x10
    // 0x119f0ec: b               #0x119f0ac
  }
  _ isFlingGesture(/* No info */) {
    // ** addr: 0x119f0f0, size: 0x11c
    // 0x119f0f0: LoadField: r4 = r1->field_43
    //     0x119f0f0: ldur            w4, [x1, #0x43]
    // 0x119f0f4: DecompressPointer r4
    //     0x119f0f4: add             x4, x4, HEAP, lsl #32
    // 0x119f0f8: cmp             w4, NULL
    // 0x119f0fc: b.ne            #0x119f10c
    // 0x119f100: d0 = 50.000000
    //     0x119f100: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0x119f104: ldr             d0, [x17, #0x1d0]
    // 0x119f108: b               #0x119f110
    // 0x119f10c: LoadField: d0 = r4->field_7
    //     0x119f10c: ldur            d0, [x4, #7]
    // 0x119f110: LoadField: r4 = r1->field_3f
    //     0x119f110: ldur            w4, [x1, #0x3f]
    // 0x119f114: DecompressPointer r4
    //     0x119f114: add             x4, x4, HEAP, lsl #32
    // 0x119f118: cmp             w4, NULL
    // 0x119f11c: b.ne            #0x119f180
    // 0x119f120: LoadField: r5 = r1->field_7
    //     0x119f120: ldur            w5, [x1, #7]
    // 0x119f124: DecompressPointer r5
    //     0x119f124: add             x5, x5, HEAP, lsl #32
    // 0x119f128: LoadField: r1 = r3->field_7
    //     0x119f128: ldur            x1, [x3, #7]
    // 0x119f12c: cmp             x1, #2
    // 0x119f130: b.gt            #0x119f14c
    // 0x119f134: cmp             x1, #1
    // 0x119f138: b.gt            #0x119f14c
    // 0x119f13c: cmp             x1, #0
    // 0x119f140: b.le            #0x119f14c
    // 0x119f144: d1 = 1.000000
    //     0x119f144: fmov            d1, #1.00000000
    // 0x119f148: b               #0x119f178
    // 0x119f14c: cmp             w5, NULL
    // 0x119f150: b.ne            #0x119f15c
    // 0x119f154: r1 = Null
    //     0x119f154: mov             x1, NULL
    // 0x119f158: b               #0x119f164
    // 0x119f15c: LoadField: r1 = r5->field_7
    //     0x119f15c: ldur            w1, [x5, #7]
    // 0x119f160: DecompressPointer r1
    //     0x119f160: add             x1, x1, HEAP, lsl #32
    // 0x119f164: cmp             w1, NULL
    // 0x119f168: b.ne            #0x119f174
    // 0x119f16c: d1 = 18.000000
    //     0x119f16c: fmov            d1, #18.00000000
    // 0x119f170: b               #0x119f178
    // 0x119f174: LoadField: d1 = r1->field_7
    //     0x119f174: ldur            d1, [x1, #7]
    // 0x119f178: mov             v2.16b, v1.16b
    // 0x119f17c: b               #0x119f188
    // 0x119f180: LoadField: d1 = r4->field_7
    //     0x119f180: ldur            d1, [x4, #7]
    // 0x119f184: mov             v2.16b, v1.16b
    // 0x119f188: d1 = 0.000000
    //     0x119f188: eor             v1.16b, v1.16b, v1.16b
    // 0x119f18c: LoadField: r1 = r2->field_7
    //     0x119f18c: ldur            w1, [x2, #7]
    // 0x119f190: DecompressPointer r1
    //     0x119f190: add             x1, x1, HEAP, lsl #32
    // 0x119f194: LoadField: d3 = r1->field_7
    //     0x119f194: ldur            d3, [x1, #7]
    // 0x119f198: fcmp            d3, d1
    // 0x119f19c: b.ne            #0x119f1a8
    // 0x119f1a0: d3 = 0.000000
    //     0x119f1a0: eor             v3.16b, v3.16b, v3.16b
    // 0x119f1a4: b               #0x119f1b8
    // 0x119f1a8: fcmp            d1, d3
    // 0x119f1ac: b.le            #0x119f1b8
    // 0x119f1b0: fneg            d4, d3
    // 0x119f1b4: mov             v3.16b, v4.16b
    // 0x119f1b8: fcmp            d3, d0
    // 0x119f1bc: b.le            #0x119f204
    // 0x119f1c0: LoadField: r1 = r2->field_13
    //     0x119f1c0: ldur            w1, [x2, #0x13]
    // 0x119f1c4: DecompressPointer r1
    //     0x119f1c4: add             x1, x1, HEAP, lsl #32
    // 0x119f1c8: LoadField: d0 = r1->field_7
    //     0x119f1c8: ldur            d0, [x1, #7]
    // 0x119f1cc: fcmp            d0, d1
    // 0x119f1d0: b.ne            #0x119f1dc
    // 0x119f1d4: d0 = 0.000000
    //     0x119f1d4: eor             v0.16b, v0.16b, v0.16b
    // 0x119f1d8: b               #0x119f1ec
    // 0x119f1dc: fcmp            d1, d0
    // 0x119f1e0: b.le            #0x119f1ec
    // 0x119f1e4: fneg            d1, d0
    // 0x119f1e8: mov             v0.16b, v1.16b
    // 0x119f1ec: fcmp            d0, d2
    // 0x119f1f0: r16 = true
    //     0x119f1f0: add             x16, NULL, #0x20  ; true
    // 0x119f1f4: r17 = false
    //     0x119f1f4: add             x17, NULL, #0x30  ; false
    // 0x119f1f8: csel            x1, x16, x17, gt
    // 0x119f1fc: mov             x0, x1
    // 0x119f200: b               #0x119f208
    // 0x119f204: r0 = false
    //     0x119f204: add             x0, NULL, #0x30  ; false
    // 0x119f208: ret
    //     0x119f208: ret             
  }
  _ _getPrimaryDragAxis(/* No info */) {
    // ** addr: 0x11b5f48, size: 0xc
    // 0x11b5f48: r0 = Instance__DragDirection
    //     0x11b5f48: add             x0, PP, #0x80, lsl #12  ; [pp+0x80b88] Obj!_DragDirection@12c5cc1
    //     0x11b5f4c: ldr             x0, [x0, #0xb88]
    // 0x11b5f50: ret
    //     0x11b5f50: ret             
  }
  _ _getDeltaForDetails(/* No info */) {
    // ** addr: 0x121b900, size: 0x30
    // 0x121b900: EnterFrame
    //     0x121b900: stp             fp, lr, [SP, #-0x10]!
    //     0x121b904: mov             fp, SP
    // 0x121b908: AllocStack(0x8)
    //     0x121b908: sub             SP, SP, #8
    // 0x121b90c: LoadField: d0 = r2->field_7
    //     0x121b90c: ldur            d0, [x2, #7]
    // 0x121b910: stur            d0, [fp, #-8]
    // 0x121b914: r0 = Offset()
    //     0x121b914: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x121b918: ldur            d0, [fp, #-8]
    // 0x121b91c: StoreField: r0->field_7 = d0
    //     0x121b91c: stur            d0, [x0, #7]
    // 0x121b920: StoreField: r0->field_f = rZR
    //     0x121b920: stur            xzr, [x0, #0xf]
    // 0x121b924: LeaveFrame
    //     0x121b924: mov             SP, fp
    //     0x121b928: ldp             fp, lr, [SP], #0x10
    // 0x121b92c: ret
    //     0x121b92c: ret             
  }
}

// class id: 4445, size: 0x90, field offset: 0x90
class VerticalDragGestureRecognizer extends DragGestureRecognizer {

  _ _getPrimaryValueFromOffset(/* No info */) {
    // ** addr: 0x119cd78, size: 0x54
    // 0x119cd78: EnterFrame
    //     0x119cd78: stp             fp, lr, [SP, #-0x10]!
    //     0x119cd7c: mov             fp, SP
    // 0x119cd80: LoadField: d0 = r2->field_f
    //     0x119cd80: ldur            d0, [x2, #0xf]
    // 0x119cd84: r0 = inline_Allocate_Double()
    //     0x119cd84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x119cd88: add             x0, x0, #0x10
    //     0x119cd8c: cmp             x1, x0
    //     0x119cd90: b.ls            #0x119cdbc
    //     0x119cd94: str             x0, [THR, #0x60]  ; THR::top
    //     0x119cd98: sub             x0, x0, #0xf
    //     0x119cd9c: mov             x1, #0xe19c
    //     0x119cda0: movk            x1, #3, lsl #16
    //     0x119cda4: stur            x1, [x0, #-1]
    // 0x119cda8: dmb             ishst
    // 0x119cdac: StoreField: r0->field_7 = d0
    //     0x119cdac: stur            d0, [x0, #7]
    // 0x119cdb0: LeaveFrame
    //     0x119cdb0: mov             SP, fp
    //     0x119cdb4: ldp             fp, lr, [SP], #0x10
    // 0x119cdb8: ret
    //     0x119cdb8: ret             
    // 0x119cdbc: SaveReg d0
    //     0x119cdbc: str             q0, [SP, #-0x10]!
    // 0x119cdc0: r0 = AllocateDouble()
    //     0x119cdc0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x119cdc4: RestoreReg d0
    //     0x119cdc4: ldr             q0, [SP], #0x10
    // 0x119cdc8: b               #0x119cdac
  }
  _ considerFling(/* No info */) {
    // ** addr: 0x119ece4, size: 0x178
    // 0x119ece4: EnterFrame
    //     0x119ece4: stp             fp, lr, [SP, #-0x10]!
    //     0x119ece8: mov             fp, SP
    // 0x119ecec: AllocStack(0x20)
    //     0x119ecec: sub             SP, SP, #0x20
    // 0x119ecf0: SetupParameters(VerticalDragGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119ecf0: mov             x4, x1
    //     0x119ecf4: mov             x0, x2
    //     0x119ecf8: stur            x1, [fp, #-8]
    //     0x119ecfc: stur            x2, [fp, #-0x10]
    // 0x119ed00: CheckStackOverflow
    //     0x119ed00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119ed04: cmp             SP, x16
    //     0x119ed08: b.ls            #0x119ee2c
    // 0x119ed0c: mov             x1, x4
    // 0x119ed10: mov             x2, x0
    // 0x119ed14: r0 = isFlingGesture()
    //     0x119ed14: bl              #0x119ee5c  ; [package:flutter/src/gestures/monodrag.dart] VerticalDragGestureRecognizer::isFlingGesture
    // 0x119ed18: tbz             w0, #4, #0x119ed2c
    // 0x119ed1c: r0 = Null
    //     0x119ed1c: mov             x0, NULL
    // 0x119ed20: LeaveFrame
    //     0x119ed20: mov             SP, fp
    //     0x119ed24: ldp             fp, lr, [SP], #0x10
    // 0x119ed28: ret
    //     0x119ed28: ret             
    // 0x119ed2c: ldur            x0, [fp, #-8]
    // 0x119ed30: LoadField: r1 = r0->field_47
    //     0x119ed30: ldur            w1, [x0, #0x47]
    // 0x119ed34: DecompressPointer r1
    //     0x119ed34: add             x1, x1, HEAP, lsl #32
    // 0x119ed38: cmp             w1, NULL
    // 0x119ed3c: b.ne            #0x119ed4c
    // 0x119ed40: d0 = 8000.000000
    //     0x119ed40: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cd28] IMM: double(8000) from 0x40bf400000000000
    //     0x119ed44: ldr             d0, [x17, #0xd28]
    // 0x119ed48: b               #0x119ed50
    // 0x119ed4c: LoadField: d0 = r1->field_7
    //     0x119ed4c: ldur            d0, [x1, #7]
    // 0x119ed50: ldur            x1, [fp, #-0x10]
    // 0x119ed54: LoadField: r2 = r1->field_7
    //     0x119ed54: ldur            w2, [x1, #7]
    // 0x119ed58: DecompressPointer r2
    //     0x119ed58: add             x2, x2, HEAP, lsl #32
    // 0x119ed5c: LoadField: d1 = r2->field_f
    //     0x119ed5c: ldur            d1, [x2, #0xf]
    // 0x119ed60: fneg            d2, d0
    // 0x119ed64: fcmp            d2, d1
    // 0x119ed68: b.le            #0x119ed74
    // 0x119ed6c: mov             v0.16b, v2.16b
    // 0x119ed70: b               #0x119ed88
    // 0x119ed74: fcmp            d1, d0
    // 0x119ed78: b.gt            #0x119ed88
    // 0x119ed7c: fcmp            d1, d1
    // 0x119ed80: b.vs            #0x119ed88
    // 0x119ed84: mov             v0.16b, v1.16b
    // 0x119ed88: stur            d0, [fp, #-0x20]
    // 0x119ed8c: r0 = Offset()
    //     0x119ed8c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x119ed90: stur            x0, [fp, #-0x10]
    // 0x119ed94: StoreField: r0->field_7 = rZR
    //     0x119ed94: stur            xzr, [x0, #7]
    // 0x119ed98: ldur            d0, [fp, #-0x20]
    // 0x119ed9c: StoreField: r0->field_f = d0
    //     0x119ed9c: stur            d0, [x0, #0xf]
    // 0x119eda0: r0 = Velocity()
    //     0x119eda0: bl              #0xadef78  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x119eda4: mov             x1, x0
    // 0x119eda8: ldur            x0, [fp, #-0x10]
    // 0x119edac: stur            x1, [fp, #-0x18]
    // 0x119edb0: StoreField: r1->field_7 = r0
    //     0x119edb0: stur            w0, [x1, #7]
    // 0x119edb4: ldur            x0, [fp, #-8]
    // 0x119edb8: LoadField: r2 = r0->field_5f
    //     0x119edb8: ldur            w2, [x0, #0x5f]
    // 0x119edbc: DecompressPointer r2
    //     0x119edbc: add             x2, x2, HEAP, lsl #32
    // 0x119edc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119edc4: cmp             w2, w16
    // 0x119edc8: b.eq            #0x119ee34
    // 0x119edcc: LoadField: r0 = r2->field_b
    //     0x119edcc: ldur            w0, [x2, #0xb]
    // 0x119edd0: DecompressPointer r0
    //     0x119edd0: add             x0, x0, HEAP, lsl #32
    // 0x119edd4: stur            x0, [fp, #-8]
    // 0x119edd8: r0 = DragEndDetails()
    //     0x119edd8: bl              #0xb99344  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x14)
    // 0x119eddc: ldur            x1, [fp, #-8]
    // 0x119ede0: StoreField: r0->field_7 = r1
    //     0x119ede0: stur            w1, [x0, #7]
    // 0x119ede4: ldur            x1, [fp, #-0x18]
    // 0x119ede8: StoreField: r0->field_b = r1
    //     0x119ede8: stur            w1, [x0, #0xb]
    // 0x119edec: ldur            d0, [fp, #-0x20]
    // 0x119edf0: r1 = inline_Allocate_Double()
    //     0x119edf0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x119edf4: add             x1, x1, #0x10
    //     0x119edf8: cmp             x2, x1
    //     0x119edfc: b.ls            #0x119ee40
    //     0x119ee00: str             x1, [THR, #0x60]  ; THR::top
    //     0x119ee04: sub             x1, x1, #0xf
    //     0x119ee08: mov             x2, #0xe19c
    //     0x119ee0c: movk            x2, #3, lsl #16
    //     0x119ee10: stur            x2, [x1, #-1]
    // 0x119ee14: dmb             ishst
    // 0x119ee18: StoreField: r1->field_7 = d0
    //     0x119ee18: stur            d0, [x1, #7]
    // 0x119ee1c: StoreField: r0->field_f = r1
    //     0x119ee1c: stur            w1, [x0, #0xf]
    // 0x119ee20: LeaveFrame
    //     0x119ee20: mov             SP, fp
    //     0x119ee24: ldp             fp, lr, [SP], #0x10
    // 0x119ee28: ret
    //     0x119ee28: ret             
    // 0x119ee2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119ee2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119ee30: b               #0x119ed0c
    // 0x119ee34: r9 = _lastPosition
    //     0x119ee34: add             x9, PP, #0x80, lsl #12  ; [pp+0x80bc8] Field <DragGestureRecognizer._lastPosition@658099969>: late (offset: 0x60)
    //     0x119ee38: ldr             x9, [x9, #0xbc8]
    // 0x119ee3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119ee3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119ee40: SaveReg d0
    //     0x119ee40: str             q0, [SP, #-0x10]!
    // 0x119ee44: SaveReg r0
    //     0x119ee44: str             x0, [SP, #-8]!
    // 0x119ee48: r0 = AllocateDouble()
    //     0x119ee48: bl              #0x13df878  ; AllocateDoubleStub
    // 0x119ee4c: mov             x1, x0
    // 0x119ee50: RestoreReg r0
    //     0x119ee50: ldr             x0, [SP], #8
    // 0x119ee54: RestoreReg d0
    //     0x119ee54: ldr             q0, [SP], #0x10
    // 0x119ee58: b               #0x119ee18
  }
  _ isFlingGesture(/* No info */) {
    // ** addr: 0x119ee5c, size: 0x11c
    // 0x119ee5c: LoadField: r4 = r1->field_43
    //     0x119ee5c: ldur            w4, [x1, #0x43]
    // 0x119ee60: DecompressPointer r4
    //     0x119ee60: add             x4, x4, HEAP, lsl #32
    // 0x119ee64: cmp             w4, NULL
    // 0x119ee68: b.ne            #0x119ee78
    // 0x119ee6c: d0 = 50.000000
    //     0x119ee6c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0x119ee70: ldr             d0, [x17, #0x1d0]
    // 0x119ee74: b               #0x119ee7c
    // 0x119ee78: LoadField: d0 = r4->field_7
    //     0x119ee78: ldur            d0, [x4, #7]
    // 0x119ee7c: LoadField: r4 = r1->field_3f
    //     0x119ee7c: ldur            w4, [x1, #0x3f]
    // 0x119ee80: DecompressPointer r4
    //     0x119ee80: add             x4, x4, HEAP, lsl #32
    // 0x119ee84: cmp             w4, NULL
    // 0x119ee88: b.ne            #0x119eeec
    // 0x119ee8c: LoadField: r5 = r1->field_7
    //     0x119ee8c: ldur            w5, [x1, #7]
    // 0x119ee90: DecompressPointer r5
    //     0x119ee90: add             x5, x5, HEAP, lsl #32
    // 0x119ee94: LoadField: r1 = r3->field_7
    //     0x119ee94: ldur            x1, [x3, #7]
    // 0x119ee98: cmp             x1, #2
    // 0x119ee9c: b.gt            #0x119eeb8
    // 0x119eea0: cmp             x1, #1
    // 0x119eea4: b.gt            #0x119eeb8
    // 0x119eea8: cmp             x1, #0
    // 0x119eeac: b.le            #0x119eeb8
    // 0x119eeb0: d1 = 1.000000
    //     0x119eeb0: fmov            d1, #1.00000000
    // 0x119eeb4: b               #0x119eee4
    // 0x119eeb8: cmp             w5, NULL
    // 0x119eebc: b.ne            #0x119eec8
    // 0x119eec0: r1 = Null
    //     0x119eec0: mov             x1, NULL
    // 0x119eec4: b               #0x119eed0
    // 0x119eec8: LoadField: r1 = r5->field_7
    //     0x119eec8: ldur            w1, [x5, #7]
    // 0x119eecc: DecompressPointer r1
    //     0x119eecc: add             x1, x1, HEAP, lsl #32
    // 0x119eed0: cmp             w1, NULL
    // 0x119eed4: b.ne            #0x119eee0
    // 0x119eed8: d1 = 18.000000
    //     0x119eed8: fmov            d1, #18.00000000
    // 0x119eedc: b               #0x119eee4
    // 0x119eee0: LoadField: d1 = r1->field_7
    //     0x119eee0: ldur            d1, [x1, #7]
    // 0x119eee4: mov             v2.16b, v1.16b
    // 0x119eee8: b               #0x119eef4
    // 0x119eeec: LoadField: d1 = r4->field_7
    //     0x119eeec: ldur            d1, [x4, #7]
    // 0x119eef0: mov             v2.16b, v1.16b
    // 0x119eef4: d1 = 0.000000
    //     0x119eef4: eor             v1.16b, v1.16b, v1.16b
    // 0x119eef8: LoadField: r1 = r2->field_7
    //     0x119eef8: ldur            w1, [x2, #7]
    // 0x119eefc: DecompressPointer r1
    //     0x119eefc: add             x1, x1, HEAP, lsl #32
    // 0x119ef00: LoadField: d3 = r1->field_f
    //     0x119ef00: ldur            d3, [x1, #0xf]
    // 0x119ef04: fcmp            d3, d1
    // 0x119ef08: b.ne            #0x119ef14
    // 0x119ef0c: d3 = 0.000000
    //     0x119ef0c: eor             v3.16b, v3.16b, v3.16b
    // 0x119ef10: b               #0x119ef24
    // 0x119ef14: fcmp            d1, d3
    // 0x119ef18: b.le            #0x119ef24
    // 0x119ef1c: fneg            d4, d3
    // 0x119ef20: mov             v3.16b, v4.16b
    // 0x119ef24: fcmp            d3, d0
    // 0x119ef28: b.le            #0x119ef70
    // 0x119ef2c: LoadField: r1 = r2->field_13
    //     0x119ef2c: ldur            w1, [x2, #0x13]
    // 0x119ef30: DecompressPointer r1
    //     0x119ef30: add             x1, x1, HEAP, lsl #32
    // 0x119ef34: LoadField: d0 = r1->field_f
    //     0x119ef34: ldur            d0, [x1, #0xf]
    // 0x119ef38: fcmp            d0, d1
    // 0x119ef3c: b.ne            #0x119ef48
    // 0x119ef40: d0 = 0.000000
    //     0x119ef40: eor             v0.16b, v0.16b, v0.16b
    // 0x119ef44: b               #0x119ef58
    // 0x119ef48: fcmp            d1, d0
    // 0x119ef4c: b.le            #0x119ef58
    // 0x119ef50: fneg            d1, d0
    // 0x119ef54: mov             v0.16b, v1.16b
    // 0x119ef58: fcmp            d0, d2
    // 0x119ef5c: r16 = true
    //     0x119ef5c: add             x16, NULL, #0x20  ; true
    // 0x119ef60: r17 = false
    //     0x119ef60: add             x17, NULL, #0x30  ; false
    // 0x119ef64: csel            x1, x16, x17, gt
    // 0x119ef68: mov             x0, x1
    // 0x119ef6c: b               #0x119ef74
    // 0x119ef70: r0 = false
    //     0x119ef70: add             x0, NULL, #0x30  ; false
    // 0x119ef74: ret
    //     0x119ef74: ret             
  }
  _ _getPrimaryDragAxis(/* No info */) {
    // ** addr: 0x11b5f3c, size: 0xc
    // 0x11b5f3c: r0 = Instance__DragDirection
    //     0x11b5f3c: add             x0, PP, #0x80, lsl #12  ; [pp+0x80b90] Obj!_DragDirection@12c5ca1
    //     0x11b5f40: ldr             x0, [x0, #0xb90]
    // 0x11b5f44: ret
    //     0x11b5f44: ret             
  }
  _ _getDeltaForDetails(/* No info */) {
    // ** addr: 0x121b8d0, size: 0x30
    // 0x121b8d0: EnterFrame
    //     0x121b8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x121b8d4: mov             fp, SP
    // 0x121b8d8: AllocStack(0x8)
    //     0x121b8d8: sub             SP, SP, #8
    // 0x121b8dc: LoadField: d0 = r2->field_f
    //     0x121b8dc: ldur            d0, [x2, #0xf]
    // 0x121b8e0: stur            d0, [fp, #-8]
    // 0x121b8e4: r0 = Offset()
    //     0x121b8e4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x121b8e8: StoreField: r0->field_7 = rZR
    //     0x121b8e8: stur            xzr, [x0, #7]
    // 0x121b8ec: ldur            d0, [fp, #-8]
    // 0x121b8f0: StoreField: r0->field_f = d0
    //     0x121b8f0: stur            d0, [x0, #0xf]
    // 0x121b8f4: LeaveFrame
    //     0x121b8f4: mov             SP, fp
    //     0x121b8f8: ldp             fp, lr, [SP], #0x10
    // 0x121b8fc: ret
    //     0x121b8fc: ret             
  }
}

// class id: 8309, size: 0x14, field offset: 0x14
enum _DragDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a99f0, size: 0x64
    // 0x11a99f0: EnterFrame
    //     0x11a99f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a99f4: mov             fp, SP
    // 0x11a99f8: AllocStack(0x10)
    //     0x11a99f8: sub             SP, SP, #0x10
    // 0x11a99fc: SetupParameters(_DragDirection this /* r1 => r0, fp-0x8 */)
    //     0x11a99fc: mov             x0, x1
    //     0x11a9a00: stur            x1, [fp, #-8]
    // 0x11a9a04: CheckStackOverflow
    //     0x11a9a04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9a08: cmp             SP, x16
    //     0x11a9a0c: b.ls            #0x11a9a4c
    // 0x11a9a10: r1 = Null
    //     0x11a9a10: mov             x1, NULL
    // 0x11a9a14: r2 = 4
    //     0x11a9a14: mov             x2, #4
    // 0x11a9a18: r0 = AllocateArray()
    //     0x11a9a18: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9a1c: r16 = "_DragDirection."
    //     0x11a9a1c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cdc0] "_DragDirection."
    //     0x11a9a20: ldr             x16, [x16, #0xdc0]
    // 0x11a9a24: StoreField: r0->field_f = r16
    //     0x11a9a24: stur            w16, [x0, #0xf]
    // 0x11a9a28: ldur            x1, [fp, #-8]
    // 0x11a9a2c: LoadField: r2 = r1->field_f
    //     0x11a9a2c: ldur            w2, [x1, #0xf]
    // 0x11a9a30: DecompressPointer r2
    //     0x11a9a30: add             x2, x2, HEAP, lsl #32
    // 0x11a9a34: StoreField: r0->field_13 = r2
    //     0x11a9a34: stur            w2, [x0, #0x13]
    // 0x11a9a38: str             x0, [SP]
    // 0x11a9a3c: r0 = _interpolate()
    //     0x11a9a3c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9a40: LeaveFrame
    //     0x11a9a40: mov             SP, fp
    //     0x11a9a44: ldp             fp, lr, [SP], #0x10
    // 0x11a9a48: ret
    //     0x11a9a48: ret             
    // 0x11a9a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9a4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9a50: b               #0x11a9a10
  }
}

// class id: 8310, size: 0x14, field offset: 0x14
enum _DragState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
