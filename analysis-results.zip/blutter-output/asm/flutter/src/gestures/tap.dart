// lib: , url: package:flutter/src/gestures/tap.dart

// class id: 1048834, size: 0x8
class :: {
}

// class id: 3152, size: 0xc, field offset: 0x8
class TapMoveDetails extends Object {
}

// class id: 4435, size: 0x58, field offset: 0x48
abstract class BaseTapGestureRecognizer extends PrimaryPointerGestureRecognizer {

  void resolve(BaseTapGestureRecognizer, GestureDisposition) {
    // ** addr: 0xba064c, size: 0x88
    // 0xba064c: EnterFrame
    //     0xba064c: stp             fp, lr, [SP, #-0x10]!
    //     0xba0650: mov             fp, SP
    // 0xba0654: CheckStackOverflow
    //     0xba0654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba0658: cmp             SP, x16
    //     0xba065c: b.ls            #0xba06b4
    // 0xba0660: ldr             x0, [fp, #0x10]
    // 0xba0664: r2 = Null
    //     0xba0664: mov             x2, NULL
    // 0xba0668: r1 = Null
    //     0xba0668: mov             x1, NULL
    // 0xba066c: r4 = 60
    //     0xba066c: mov             x4, #0x3c
    // 0xba0670: branchIfSmi(r0, 0xba067c)
    //     0xba0670: tbz             w0, #0, #0xba067c
    // 0xba0674: r4 = LoadClassIdInstr(r0)
    //     0xba0674: ldur            x4, [x0, #-1]
    //     0xba0678: ubfx            x4, x4, #0xc, #0x14
    // 0xba067c: r17 = 8312
    //     0xba067c: mov             x17, #0x2078
    // 0xba0680: cmp             x4, x17
    // 0xba0684: b.eq            #0xba069c
    // 0xba0688: r8 = GestureDisposition
    //     0xba0688: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d30] Type: GestureDisposition
    //     0xba068c: ldr             x8, [x8, #0xd30]
    // 0xba0690: r3 = Null
    //     0xba0690: add             x3, PP, #0x90, lsl #12  ; [pp+0x903a8] Null
    //     0xba0694: ldr             x3, [x3, #0x3a8]
    // 0xba0698: r0 = DefaultTypeTest()
    //     0xba0698: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xba069c: ldr             x1, [fp, #0x18]
    // 0xba06a0: ldr             x2, [fp, #0x10]
    // 0xba06a4: r0 = resolve()
    //     0xba06a4: bl              #0xd01798  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::resolve
    // 0xba06a8: LeaveFrame
    //     0xba06a8: mov             SP, fp
    //     0xba06ac: ldp             fp, lr, [SP], #0x10
    // 0xba06b0: ret
    //     0xba06b0: ret             
    // 0xba06b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba06b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba06b8: b               #0xba0660
  }
  _ _reset(/* No info */) {
    // ** addr: 0xba0754, size: 0x1c
    // 0xba0754: r2 = false
    //     0xba0754: add             x2, NULL, #0x30  ; false
    // 0xba0758: StoreField: r1->field_47 = r2
    //     0xba0758: stur            w2, [x1, #0x47]
    // 0xba075c: StoreField: r1->field_4b = r2
    //     0xba075c: stur            w2, [x1, #0x4b]
    // 0xba0760: StoreField: r1->field_53 = rNULL
    //     0xba0760: stur            NULL, [x1, #0x53]
    // 0xba0764: StoreField: r1->field_4f = rNULL
    //     0xba0764: stur            NULL, [x1, #0x4f]
    // 0xba0768: r0 = Null
    //     0xba0768: mov             x0, NULL
    // 0xba076c: ret
    //     0xba076c: ret             
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0xba0770, size: 0x70
    // 0xba0770: EnterFrame
    //     0xba0770: stp             fp, lr, [SP, #-0x10]!
    //     0xba0774: mov             fp, SP
    // 0xba0778: mov             x3, x2
    // 0xba077c: CheckStackOverflow
    //     0xba077c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba0780: cmp             SP, x16
    //     0xba0784: b.ls            #0xba07d4
    // 0xba0788: LoadField: r2 = r1->field_4f
    //     0xba0788: ldur            w2, [x1, #0x4f]
    // 0xba078c: DecompressPointer r2
    //     0xba078c: add             x2, x2, HEAP, lsl #32
    // 0xba0790: cmp             w2, NULL
    // 0xba0794: b.eq            #0xba07dc
    // 0xba0798: r0 = LoadClassIdInstr(r1)
    //     0xba0798: ldur            x0, [x1, #-1]
    //     0xba079c: ubfx            x0, x0, #0xc, #0x14
    // 0xba07a0: r17 = 4436
    //     0xba07a0: mov             x17, #0x1154
    // 0xba07a4: cmp             x0, x17
    // 0xba07a8: b.eq            #0xba07c4
    // 0xba07ac: r0 = LoadClassIdInstr(r1)
    //     0xba07ac: ldur            x0, [x1, #-1]
    //     0xba07b0: ubfx            x0, x0, #0xc, #0x14
    // 0xba07b4: r0 = GDT[cid_x0 + 0x237c]()
    //     0xba07b4: mov             x17, #0x237c
    //     0xba07b8: add             lr, x0, x17
    //     0xba07bc: ldr             lr, [x21, lr, lsl #3]
    //     0xba07c0: blr             lr
    // 0xba07c4: r0 = Null
    //     0xba07c4: mov             x0, NULL
    // 0xba07c8: LeaveFrame
    //     0xba07c8: mov             SP, fp
    //     0xba07cc: ldp             fp, lr, [SP], #0x10
    // 0xba07d0: ret
    //     0xba07d0: ret             
    // 0xba07d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba07d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba07d8: b               #0xba0788
    // 0xba07dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba07dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDown(/* No info */) {
    // ** addr: 0xba8428, size: 0xac
    // 0xba8428: EnterFrame
    //     0xba8428: stp             fp, lr, [SP, #-0x10]!
    //     0xba842c: mov             fp, SP
    // 0xba8430: AllocStack(0x8)
    //     0xba8430: sub             SP, SP, #8
    // 0xba8434: SetupParameters(BaseTapGestureRecognizer this /* r1 => r3, fp-0x8 */)
    //     0xba8434: mov             x3, x1
    //     0xba8438: stur            x1, [fp, #-8]
    // 0xba843c: CheckStackOverflow
    //     0xba843c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8440: cmp             SP, x16
    //     0xba8444: b.ls            #0xba84c8
    // 0xba8448: LoadField: r0 = r3->field_47
    //     0xba8448: ldur            w0, [x3, #0x47]
    // 0xba844c: DecompressPointer r0
    //     0xba844c: add             x0, x0, HEAP, lsl #32
    // 0xba8450: tbnz            w0, #4, #0xba8464
    // 0xba8454: r0 = Null
    //     0xba8454: mov             x0, NULL
    // 0xba8458: LeaveFrame
    //     0xba8458: mov             SP, fp
    //     0xba845c: ldp             fp, lr, [SP], #0x10
    // 0xba8460: ret
    //     0xba8460: ret             
    // 0xba8464: LoadField: r2 = r3->field_4f
    //     0xba8464: ldur            w2, [x3, #0x4f]
    // 0xba8468: DecompressPointer r2
    //     0xba8468: add             x2, x2, HEAP, lsl #32
    // 0xba846c: cmp             w2, NULL
    // 0xba8470: b.eq            #0xba84d0
    // 0xba8474: r0 = LoadClassIdInstr(r3)
    //     0xba8474: ldur            x0, [x3, #-1]
    //     0xba8478: ubfx            x0, x0, #0xc, #0x14
    // 0xba847c: r17 = 4436
    //     0xba847c: mov             x17, #0x1154
    // 0xba8480: cmp             x0, x17
    // 0xba8484: b.ne            #0xba8490
    // 0xba8488: mov             x1, x3
    // 0xba848c: b               #0xba84b0
    // 0xba8490: r0 = LoadClassIdInstr(r3)
    //     0xba8490: ldur            x0, [x3, #-1]
    //     0xba8494: ubfx            x0, x0, #0xc, #0x14
    // 0xba8498: mov             x1, x3
    // 0xba849c: r0 = GDT[cid_x0 + 0x2528]()
    //     0xba849c: mov             x17, #0x2528
    //     0xba84a0: add             lr, x0, x17
    //     0xba84a4: ldr             lr, [x21, lr, lsl #3]
    //     0xba84a8: blr             lr
    // 0xba84ac: ldur            x1, [fp, #-8]
    // 0xba84b0: r2 = true
    //     0xba84b0: add             x2, NULL, #0x20  ; true
    // 0xba84b4: StoreField: r1->field_47 = r2
    //     0xba84b4: stur            w2, [x1, #0x47]
    // 0xba84b8: r0 = Null
    //     0xba84b8: mov             x0, NULL
    // 0xba84bc: LeaveFrame
    //     0xba84bc: mov             SP, fp
    //     0xba84c0: ldp             fp, lr, [SP], #0x10
    // 0xba84c4: ret
    //     0xba84c4: ret             
    // 0xba84c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba84c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba84cc: b               #0xba8448
    // 0xba84d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba84d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba84d4, size: 0xc4
    // 0xba84d4: EnterFrame
    //     0xba84d4: stp             fp, lr, [SP, #-0x10]!
    //     0xba84d8: mov             fp, SP
    // 0xba84dc: AllocStack(0x10)
    //     0xba84dc: sub             SP, SP, #0x10
    // 0xba84e0: SetupParameters(BaseTapGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba84e0: mov             x0, x2
    //     0xba84e4: stur            x2, [fp, #-0x10]
    //     0xba84e8: mov             x2, x1
    //     0xba84ec: stur            x1, [fp, #-8]
    // 0xba84f0: CheckStackOverflow
    //     0xba84f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba84f4: cmp             SP, x16
    //     0xba84f8: b.ls            #0xba8590
    // 0xba84fc: LoadField: r1 = r2->field_33
    //     0xba84fc: ldur            w1, [x2, #0x33]
    // 0xba8500: DecompressPointer r1
    //     0xba8500: add             x1, x1, HEAP, lsl #32
    // 0xba8504: r16 = Instance_GestureRecognizerState
    //     0xba8504: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7ab90] Obj!GestureRecognizerState@12c5bc1
    //     0xba8508: ldr             x16, [x16, #0xb90]
    // 0xba850c: cmp             w1, w16
    // 0xba8510: b.ne            #0xba8564
    // 0xba8514: LoadField: r1 = r2->field_4f
    //     0xba8514: ldur            w1, [x2, #0x4f]
    // 0xba8518: DecompressPointer r1
    //     0xba8518: add             x1, x1, HEAP, lsl #32
    // 0xba851c: cmp             w1, NULL
    // 0xba8520: b.eq            #0xba853c
    // 0xba8524: LoadField: r1 = r2->field_53
    //     0xba8524: ldur            w1, [x2, #0x53]
    // 0xba8528: DecompressPointer r1
    //     0xba8528: add             x1, x1, HEAP, lsl #32
    // 0xba852c: cmp             w1, NULL
    // 0xba8530: b.eq            #0xba853c
    // 0xba8534: mov             x1, x2
    // 0xba8538: r0 = _reset()
    //     0xba8538: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xba853c: ldur            x1, [fp, #-8]
    // 0xba8540: ldur            x0, [fp, #-0x10]
    // 0xba8544: StoreField: r1->field_4f = r0
    //     0xba8544: stur            w0, [x1, #0x4f]
    //     0xba8548: ldurb           w16, [x1, #-1]
    //     0xba854c: ldurb           w17, [x0, #-1]
    //     0xba8550: and             x16, x17, x16, lsr #2
    //     0xba8554: tst             x16, HEAP, lsr #32
    //     0xba8558: b.eq            #0xba8560
    //     0xba855c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba8560: b               #0xba8568
    // 0xba8564: mov             x1, x2
    // 0xba8568: LoadField: r0 = r1->field_4f
    //     0xba8568: ldur            w0, [x1, #0x4f]
    // 0xba856c: DecompressPointer r0
    //     0xba856c: add             x0, x0, HEAP, lsl #32
    // 0xba8570: cmp             w0, NULL
    // 0xba8574: b.eq            #0xba8580
    // 0xba8578: ldur            x2, [fp, #-0x10]
    // 0xba857c: r0 = addAllowedPointer()
    //     0xba857c: bl              #0xba7f5c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::addAllowedPointer
    // 0xba8580: r0 = Null
    //     0xba8580: mov             x0, NULL
    // 0xba8584: LeaveFrame
    //     0xba8584: mov             SP, fp
    //     0xba8588: ldp             fp, lr, [SP], #0x10
    // 0xba858c: ret
    //     0xba858c: ret             
    // 0xba8590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8594: b               #0xba84fc
  }
  _ BaseTapGestureRecognizer(/* No info */) {
    // ** addr: 0xc0a1bc, size: 0xe0
    // 0xc0a1bc: EnterFrame
    //     0xc0a1bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a1c0: mov             fp, SP
    // 0xc0a1c4: LoadField: r0 = r4->field_13
    //     0xc0a1c4: ldur            w0, [x4, #0x13]
    // 0xc0a1c8: LoadField: r2 = r4->field_1f
    //     0xc0a1c8: ldur            w2, [x4, #0x1f]
    // 0xc0a1cc: DecompressPointer r2
    //     0xc0a1cc: add             x2, x2, HEAP, lsl #32
    // 0xc0a1d0: r16 = "postAcceptSlopTolerance"
    //     0xc0a1d0: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7ab88] "postAcceptSlopTolerance"
    //     0xc0a1d4: ldr             x16, [x16, #0xb88]
    // 0xc0a1d8: cmp             w2, w16
    // 0xc0a1dc: b.ne            #0xc0a200
    // 0xc0a1e0: LoadField: r2 = r4->field_23
    //     0xc0a1e0: ldur            w2, [x4, #0x23]
    // 0xc0a1e4: DecompressPointer r2
    //     0xc0a1e4: add             x2, x2, HEAP, lsl #32
    // 0xc0a1e8: sub             w3, w0, w2
    // 0xc0a1ec: add             x2, fp, w3, sxtw #2
    // 0xc0a1f0: ldr             x2, [x2, #8]
    // 0xc0a1f4: mov             x5, x2
    // 0xc0a1f8: r2 = 1
    //     0xc0a1f8: mov             x2, #1
    // 0xc0a1fc: b               #0xc0a20c
    // 0xc0a200: r5 = -1.000000
    //     0xc0a200: add             x5, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0xc0a204: ldr             x5, [x5, #0x2a8]
    // 0xc0a208: r2 = 0
    //     0xc0a208: mov             x2, #0
    // 0xc0a20c: lsl             x3, x2, #1
    // 0xc0a210: lsl             w2, w3, #1
    // 0xc0a214: add             w3, w2, #8
    // 0xc0a218: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0xc0a218: add             x16, x4, w3, sxtw #1
    //     0xc0a21c: ldur            w6, [x16, #0xf]
    // 0xc0a220: DecompressPointer r6
    //     0xc0a220: add             x6, x6, HEAP, lsl #32
    // 0xc0a224: r16 = "supportedDevices"
    //     0xc0a224: add             x16, PP, #0x15, lsl #12  ; [pp+0x15580] "supportedDevices"
    //     0xc0a228: ldr             x16, [x16, #0x580]
    // 0xc0a22c: cmp             w6, w16
    // 0xc0a230: b.ne            #0xc0a258
    // 0xc0a234: add             w3, w2, #0xa
    // 0xc0a238: ArrayLoad: r2 = r4[r3]  ; Unknown_4
    //     0xc0a238: add             x16, x4, w3, sxtw #1
    //     0xc0a23c: ldur            w2, [x16, #0xf]
    // 0xc0a240: DecompressPointer r2
    //     0xc0a240: add             x2, x2, HEAP, lsl #32
    // 0xc0a244: sub             w3, w0, w2
    // 0xc0a248: add             x0, fp, w3, sxtw #2
    // 0xc0a24c: ldr             x0, [x0, #8]
    // 0xc0a250: mov             x6, x0
    // 0xc0a254: b               #0xc0a25c
    // 0xc0a258: r6 = Null
    //     0xc0a258: mov             x6, NULL
    // 0xc0a25c: r0 = false
    //     0xc0a25c: add             x0, NULL, #0x30  ; false
    // 0xc0a260: CheckStackOverflow
    //     0xc0a260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a264: cmp             SP, x16
    //     0xc0a268: b.ls            #0xc0a294
    // 0xc0a26c: StoreField: r1->field_47 = r0
    //     0xc0a26c: stur            w0, [x1, #0x47]
    // 0xc0a270: StoreField: r1->field_4b = r0
    //     0xc0a270: stur            w0, [x1, #0x4b]
    // 0xc0a274: r2 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static.
    //     0xc0a274: add             x2, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xc0a278: ldr             x2, [x2, #0x578]
    // 0xc0a27c: r3 = Instance_Duration
    //     0xc0a27c: ldr             x3, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xc0a280: r0 = PrimaryPointerGestureRecognizer()
    //     0xc0a280: bl              #0xc0a0f8  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::PrimaryPointerGestureRecognizer
    // 0xc0a284: r0 = Null
    //     0xc0a284: mov             x0, NULL
    // 0xc0a288: LeaveFrame
    //     0xc0a288: mov             SP, fp
    //     0xc0a28c: ldp             fp, lr, [SP], #0x10
    // 0xc0a290: ret
    //     0xc0a290: ret             
    // 0xc0a294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a298: b               #0xc0a26c
  }
  void resolve(BaseTapGestureRecognizer, GestureDisposition) {
    // ** addr: 0xd01798, size: 0x80
    // 0xd01798: EnterFrame
    //     0xd01798: stp             fp, lr, [SP, #-0x10]!
    //     0xd0179c: mov             fp, SP
    // 0xd017a0: AllocStack(0x10)
    //     0xd017a0: sub             SP, SP, #0x10
    // 0xd017a4: SetupParameters(BaseTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd017a4: mov             x3, x1
    //     0xd017a8: mov             x0, x2
    //     0xd017ac: stur            x1, [fp, #-8]
    //     0xd017b0: stur            x2, [fp, #-0x10]
    // 0xd017b4: CheckStackOverflow
    //     0xd017b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd017b8: cmp             SP, x16
    //     0xd017bc: b.ls            #0xd01810
    // 0xd017c0: LoadField: r1 = r3->field_4b
    //     0xd017c0: ldur            w1, [x3, #0x4b]
    // 0xd017c4: DecompressPointer r1
    //     0xd017c4: add             x1, x1, HEAP, lsl #32
    // 0xd017c8: tbnz            w1, #4, #0xd017f4
    // 0xd017cc: r16 = Instance_GestureDisposition
    //     0xd017cc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xd017d0: ldr             x16, [x16, #0x610]
    // 0xd017d4: cmp             w0, w16
    // 0xd017d8: b.ne            #0xd017f4
    // 0xd017dc: mov             x1, x3
    // 0xd017e0: r2 = "spontaneous"
    //     0xd017e0: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8e6e0] "spontaneous"
    //     0xd017e4: ldr             x2, [x2, #0x6e0]
    // 0xd017e8: r0 = _checkCancel()
    //     0xd017e8: bl              #0xba0770  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0xd017ec: ldur            x1, [fp, #-8]
    // 0xd017f0: r0 = _reset()
    //     0xd017f0: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xd017f4: ldur            x1, [fp, #-8]
    // 0xd017f8: ldur            x2, [fp, #-0x10]
    // 0xd017fc: r0 = resolve()
    //     0xd017fc: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xd01800: r0 = Null
    //     0xd01800: mov             x0, NULL
    // 0xd01804: LeaveFrame
    //     0xd01804: mov             SP, fp
    //     0xd01808: ldp             fp, lr, [SP], #0x10
    // 0xd0180c: ret
    //     0xd0180c: ret             
    // 0xd01810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01814: b               #0xd017c0
  }
  _ startTrackingPointer(/* No info */) {
    // ** addr: 0x10f2e24, size: 0x30
    // 0x10f2e24: EnterFrame
    //     0x10f2e24: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2e28: mov             fp, SP
    // 0x10f2e2c: CheckStackOverflow
    //     0x10f2e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2e30: cmp             SP, x16
    //     0x10f2e34: b.ls            #0x10f2e4c
    // 0x10f2e38: r0 = startTrackingPointer()
    //     0x10f2e38: bl              #0x10f2e54  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0x10f2e3c: r0 = Null
    //     0x10f2e3c: mov             x0, NULL
    // 0x10f2e40: LeaveFrame
    //     0x10f2e40: mov             SP, fp
    //     0x10f2e44: ldp             fp, lr, [SP], #0x10
    // 0x10f2e48: ret
    //     0x10f2e48: ret             
    // 0x10f2e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f2e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f2e50: b               #0x10f2e38
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d0c0, size: 0xd4
    // 0x116d0c0: EnterFrame
    //     0x116d0c0: stp             fp, lr, [SP, #-0x10]!
    //     0x116d0c4: mov             fp, SP
    // 0x116d0c8: AllocStack(0x10)
    //     0x116d0c8: sub             SP, SP, #0x10
    // 0x116d0cc: SetupParameters(BaseTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x116d0cc: mov             x3, x1
    //     0x116d0d0: mov             x0, x2
    //     0x116d0d4: stur            x1, [fp, #-8]
    //     0x116d0d8: stur            x2, [fp, #-0x10]
    // 0x116d0dc: CheckStackOverflow
    //     0x116d0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d0e0: cmp             SP, x16
    //     0x116d0e4: b.ls            #0x116d18c
    // 0x116d0e8: mov             x1, x3
    // 0x116d0ec: mov             x2, x0
    // 0x116d0f0: r0 = rejectGesture()
    //     0x116d0f0: bl              #0x116cffc  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::rejectGesture
    // 0x116d0f4: ldur            x3, [fp, #-8]
    // 0x116d0f8: LoadField: r2 = r3->field_37
    //     0x116d0f8: ldur            w2, [x3, #0x37]
    // 0x116d0fc: DecompressPointer r2
    //     0x116d0fc: add             x2, x2, HEAP, lsl #32
    // 0x116d100: ldur            x4, [fp, #-0x10]
    // 0x116d104: r0 = BoxInt64Instr(r4)
    //     0x116d104: sbfiz           x0, x4, #1, #0x1f
    //     0x116d108: cmp             x4, x0, asr #1
    //     0x116d10c: b.eq            #0x116d118
    //     0x116d110: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d114: stur            x4, [x0, #7]
    // 0x116d118: cmp             w0, w2
    // 0x116d11c: b.eq            #0x116d158
    // 0x116d120: and             w16, w0, w2
    // 0x116d124: branchIfSmi(r16, 0x116d17c)
    //     0x116d124: tbz             w16, #0, #0x116d17c
    // 0x116d128: r16 = LoadClassIdInstr(r0)
    //     0x116d128: ldur            x16, [x0, #-1]
    //     0x116d12c: ubfx            x16, x16, #0xc, #0x14
    // 0x116d130: cmp             x16, #0x3d
    // 0x116d134: b.ne            #0x116d17c
    // 0x116d138: r16 = LoadClassIdInstr(r2)
    //     0x116d138: ldur            x16, [x2, #-1]
    //     0x116d13c: ubfx            x16, x16, #0xc, #0x14
    // 0x116d140: cmp             x16, #0x3d
    // 0x116d144: b.ne            #0x116d17c
    // 0x116d148: LoadField: r16 = r0->field_7
    //     0x116d148: ldur            x16, [x0, #7]
    // 0x116d14c: LoadField: r17 = r2->field_7
    //     0x116d14c: ldur            x17, [x2, #7]
    // 0x116d150: cmp             x16, x17
    // 0x116d154: b.ne            #0x116d17c
    // 0x116d158: LoadField: r0 = r3->field_47
    //     0x116d158: ldur            w0, [x3, #0x47]
    // 0x116d15c: DecompressPointer r0
    //     0x116d15c: add             x0, x0, HEAP, lsl #32
    // 0x116d160: tbnz            w0, #4, #0x116d174
    // 0x116d164: mov             x1, x3
    // 0x116d168: r2 = "forced"
    //     0x116d168: add             x2, PP, #0x90, lsl #12  ; [pp+0x903a0] "forced"
    //     0x116d16c: ldr             x2, [x2, #0x3a0]
    // 0x116d170: r0 = _checkCancel()
    //     0x116d170: bl              #0xba0770  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0x116d174: ldur            x1, [fp, #-8]
    // 0x116d178: r0 = _reset()
    //     0x116d178: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x116d17c: r0 = Null
    //     0x116d17c: mov             x0, NULL
    // 0x116d180: LeaveFrame
    //     0x116d180: mov             SP, fp
    //     0x116d184: ldp             fp, lr, [SP], #0x10
    // 0x116d188: ret
    //     0x116d188: ret             
    // 0x116d18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d18c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d190: b               #0x116d0e8
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119c620, size: 0xc8
    // 0x119c620: EnterFrame
    //     0x119c620: stp             fp, lr, [SP, #-0x10]!
    //     0x119c624: mov             fp, SP
    // 0x119c628: AllocStack(0x10)
    //     0x119c628: sub             SP, SP, #0x10
    // 0x119c62c: SetupParameters(BaseTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119c62c: mov             x3, x1
    //     0x119c630: mov             x0, x2
    //     0x119c634: stur            x1, [fp, #-8]
    //     0x119c638: stur            x2, [fp, #-0x10]
    // 0x119c63c: CheckStackOverflow
    //     0x119c63c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c640: cmp             SP, x16
    //     0x119c644: b.ls            #0x119c6e0
    // 0x119c648: mov             x1, x3
    // 0x119c64c: mov             x2, x0
    // 0x119c650: r0 = acceptGesture()
    //     0x119c650: bl              #0xba8380  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::acceptGesture
    // 0x119c654: ldur            x2, [fp, #-8]
    // 0x119c658: LoadField: r3 = r2->field_37
    //     0x119c658: ldur            w3, [x2, #0x37]
    // 0x119c65c: DecompressPointer r3
    //     0x119c65c: add             x3, x3, HEAP, lsl #32
    // 0x119c660: ldur            x4, [fp, #-0x10]
    // 0x119c664: r0 = BoxInt64Instr(r4)
    //     0x119c664: sbfiz           x0, x4, #1, #0x1f
    //     0x119c668: cmp             x4, x0, asr #1
    //     0x119c66c: b.eq            #0x119c678
    //     0x119c670: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x119c674: stur            x4, [x0, #7]
    // 0x119c678: cmp             w0, w3
    // 0x119c67c: b.eq            #0x119c6b8
    // 0x119c680: and             w16, w0, w3
    // 0x119c684: branchIfSmi(r16, 0x119c6d0)
    //     0x119c684: tbz             w16, #0, #0x119c6d0
    // 0x119c688: r16 = LoadClassIdInstr(r0)
    //     0x119c688: ldur            x16, [x0, #-1]
    //     0x119c68c: ubfx            x16, x16, #0xc, #0x14
    // 0x119c690: cmp             x16, #0x3d
    // 0x119c694: b.ne            #0x119c6d0
    // 0x119c698: r16 = LoadClassIdInstr(r3)
    //     0x119c698: ldur            x16, [x3, #-1]
    //     0x119c69c: ubfx            x16, x16, #0xc, #0x14
    // 0x119c6a0: cmp             x16, #0x3d
    // 0x119c6a4: b.ne            #0x119c6d0
    // 0x119c6a8: LoadField: r16 = r0->field_7
    //     0x119c6a8: ldur            x16, [x0, #7]
    // 0x119c6ac: LoadField: r17 = r3->field_7
    //     0x119c6ac: ldur            x17, [x3, #7]
    // 0x119c6b0: cmp             x16, x17
    // 0x119c6b4: b.ne            #0x119c6d0
    // 0x119c6b8: mov             x1, x2
    // 0x119c6bc: r0 = _checkDown()
    //     0x119c6bc: bl              #0xba8428  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkDown
    // 0x119c6c0: ldur            x1, [fp, #-8]
    // 0x119c6c4: r0 = true
    //     0x119c6c4: add             x0, NULL, #0x20  ; true
    // 0x119c6c8: StoreField: r1->field_4b = r0
    //     0x119c6c8: stur            w0, [x1, #0x4b]
    // 0x119c6cc: r0 = _checkUp()
    //     0x119c6cc: bl              #0x119c6e8  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkUp
    // 0x119c6d0: r0 = Null
    //     0x119c6d0: mov             x0, NULL
    // 0x119c6d4: LeaveFrame
    //     0x119c6d4: mov             SP, fp
    //     0x119c6d8: ldp             fp, lr, [SP], #0x10
    // 0x119c6dc: ret
    //     0x119c6dc: ret             
    // 0x119c6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c6e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c6e4: b               #0x119c648
  }
  _ _checkUp(/* No info */) {
    // ** addr: 0x119c6e8, size: 0xd8
    // 0x119c6e8: EnterFrame
    //     0x119c6e8: stp             fp, lr, [SP, #-0x10]!
    //     0x119c6ec: mov             fp, SP
    // 0x119c6f0: AllocStack(0x20)
    //     0x119c6f0: sub             SP, SP, #0x20
    // 0x119c6f4: SetupParameters(BaseTapGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0x119c6f4: stur            x1, [fp, #-8]
    // 0x119c6f8: CheckStackOverflow
    //     0x119c6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c6fc: cmp             SP, x16
    //     0x119c700: b.ls            #0x119c7b4
    // 0x119c704: LoadField: r0 = r1->field_4b
    //     0x119c704: ldur            w0, [x1, #0x4b]
    // 0x119c708: DecompressPointer r0
    //     0x119c708: add             x0, x0, HEAP, lsl #32
    // 0x119c70c: tbnz            w0, #4, #0x119c720
    // 0x119c710: LoadField: r3 = r1->field_53
    //     0x119c710: ldur            w3, [x1, #0x53]
    // 0x119c714: DecompressPointer r3
    //     0x119c714: add             x3, x3, HEAP, lsl #32
    // 0x119c718: cmp             w3, NULL
    // 0x119c71c: b.ne            #0x119c730
    // 0x119c720: r0 = Null
    //     0x119c720: mov             x0, NULL
    // 0x119c724: LeaveFrame
    //     0x119c724: mov             SP, fp
    //     0x119c728: ldp             fp, lr, [SP], #0x10
    // 0x119c72c: ret
    //     0x119c72c: ret             
    // 0x119c730: LoadField: r2 = r1->field_4f
    //     0x119c730: ldur            w2, [x1, #0x4f]
    // 0x119c734: DecompressPointer r2
    //     0x119c734: add             x2, x2, HEAP, lsl #32
    // 0x119c738: cmp             w2, NULL
    // 0x119c73c: b.eq            #0x119c7bc
    // 0x119c740: r0 = LoadClassIdInstr(r1)
    //     0x119c740: ldur            x0, [x1, #-1]
    //     0x119c744: ubfx            x0, x0, #0xc, #0x14
    // 0x119c748: r17 = 4436
    //     0x119c748: mov             x17, #0x1154
    // 0x119c74c: cmp             x0, x17
    // 0x119c750: b.ne            #0x119c77c
    // 0x119c754: LoadField: r0 = r1->field_57
    //     0x119c754: ldur            w0, [x1, #0x57]
    // 0x119c758: DecompressPointer r0
    //     0x119c758: add             x0, x0, HEAP, lsl #32
    // 0x119c75c: cmp             w0, NULL
    // 0x119c760: b.eq            #0x119c79c
    // 0x119c764: r16 = <void?>
    //     0x119c764: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x119c768: stp             x1, x16, [SP, #8]
    // 0x119c76c: str             x0, [SP]
    // 0x119c770: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x119c770: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x119c774: r0 = invokeCallback()
    //     0x119c774: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x119c778: b               #0x119c79c
    // 0x119c77c: mov             x4, x1
    // 0x119c780: r0 = LoadClassIdInstr(r4)
    //     0x119c780: ldur            x0, [x4, #-1]
    //     0x119c784: ubfx            x0, x0, #0xc, #0x14
    // 0x119c788: mov             x1, x4
    // 0x119c78c: r0 = GDT[cid_x0 + 0x2338]()
    //     0x119c78c: mov             x17, #0x2338
    //     0x119c790: add             lr, x0, x17
    //     0x119c794: ldr             lr, [x21, lr, lsl #3]
    //     0x119c798: blr             lr
    // 0x119c79c: ldur            x1, [fp, #-8]
    // 0x119c7a0: r0 = _reset()
    //     0x119c7a0: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x119c7a4: r0 = Null
    //     0x119c7a4: mov             x0, NULL
    // 0x119c7a8: LeaveFrame
    //     0x119c7a8: mov             SP, fp
    //     0x119c7ac: ldp             fp, lr, [SP], #0x10
    // 0x119c7b0: ret
    //     0x119c7b0: ret             
    // 0x119c7b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c7b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c7b8: b               #0x119c704
    // 0x119c7bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119c7bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handlePrimaryPointer(/* No info */) {
    // ** addr: 0x11adf44, size: 0x244
    // 0x11adf44: EnterFrame
    //     0x11adf44: stp             fp, lr, [SP, #-0x10]!
    //     0x11adf48: mov             fp, SP
    // 0x11adf4c: AllocStack(0x18)
    //     0x11adf4c: sub             SP, SP, #0x18
    // 0x11adf50: SetupParameters(BaseTapGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x11adf50: mov             x4, x1
    //     0x11adf54: mov             x3, x2
    //     0x11adf58: stur            x1, [fp, #-8]
    //     0x11adf5c: stur            x2, [fp, #-0x10]
    // 0x11adf60: CheckStackOverflow
    //     0x11adf60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11adf64: cmp             SP, x16
    //     0x11adf68: b.ls            #0x11ae178
    // 0x11adf6c: mov             x0, x3
    // 0x11adf70: r2 = Null
    //     0x11adf70: mov             x2, NULL
    // 0x11adf74: r1 = Null
    //     0x11adf74: mov             x1, NULL
    // 0x11adf78: cmp             w0, NULL
    // 0x11adf7c: b.eq            #0x11adfa4
    // 0x11adf80: branchIfSmi(r0, 0x11adfa4)
    //     0x11adf80: tbz             w0, #0, #0x11adfa4
    // 0x11adf84: r3 = LoadClassIdInstr(r0)
    //     0x11adf84: ldur            x3, [x0, #-1]
    //     0x11adf88: ubfx            x3, x3, #0xc, #0x14
    // 0x11adf8c: r17 = 4155
    //     0x11adf8c: mov             x17, #0x103b
    // 0x11adf90: cmp             x3, x17
    // 0x11adf94: b.eq            #0x11adfac
    // 0x11adf98: r17 = 5284
    //     0x11adf98: mov             x17, #0x14a4
    // 0x11adf9c: cmp             x3, x17
    // 0x11adfa0: b.eq            #0x11adfac
    // 0x11adfa4: r0 = false
    //     0x11adfa4: add             x0, NULL, #0x30  ; false
    // 0x11adfa8: b               #0x11adfb0
    // 0x11adfac: r0 = true
    //     0x11adfac: add             x0, NULL, #0x20  ; true
    // 0x11adfb0: tbnz            w0, #4, #0x11adfe4
    // 0x11adfb4: ldur            x3, [fp, #-8]
    // 0x11adfb8: ldur            x0, [fp, #-0x10]
    // 0x11adfbc: StoreField: r3->field_53 = r0
    //     0x11adfbc: stur            w0, [x3, #0x53]
    //     0x11adfc0: ldurb           w16, [x3, #-1]
    //     0x11adfc4: ldurb           w17, [x0, #-1]
    //     0x11adfc8: and             x16, x17, x16, lsr #2
    //     0x11adfcc: tst             x16, HEAP, lsr #32
    //     0x11adfd0: b.eq            #0x11adfd8
    //     0x11adfd4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11adfd8: mov             x1, x3
    // 0x11adfdc: r0 = _checkUp()
    //     0x11adfdc: bl              #0x119c6e8  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkUp
    // 0x11adfe0: b               #0x11ae168
    // 0x11adfe4: ldur            x3, [fp, #-8]
    // 0x11adfe8: ldur            x0, [fp, #-0x10]
    // 0x11adfec: r2 = Null
    //     0x11adfec: mov             x2, NULL
    // 0x11adff0: r1 = Null
    //     0x11adff0: mov             x1, NULL
    // 0x11adff4: cmp             w0, NULL
    // 0x11adff8: b.eq            #0x11ae020
    // 0x11adffc: branchIfSmi(r0, 0x11ae020)
    //     0x11adffc: tbz             w0, #0, #0x11ae020
    // 0x11ae000: r3 = LoadClassIdInstr(r0)
    //     0x11ae000: ldur            x3, [x0, #-1]
    //     0x11ae004: ubfx            x3, x3, #0xc, #0x14
    // 0x11ae008: r17 = 4139
    //     0x11ae008: mov             x17, #0x102b
    // 0x11ae00c: cmp             x3, x17
    // 0x11ae010: b.eq            #0x11ae028
    // 0x11ae014: r17 = 5276
    //     0x11ae014: mov             x17, #0x149c
    // 0x11ae018: cmp             x3, x17
    // 0x11ae01c: b.eq            #0x11ae028
    // 0x11ae020: r0 = false
    //     0x11ae020: add             x0, NULL, #0x30  ; false
    // 0x11ae024: b               #0x11ae02c
    // 0x11ae028: r0 = true
    //     0x11ae028: add             x0, NULL, #0x20  ; true
    // 0x11ae02c: tbnz            w0, #4, #0x11ae06c
    // 0x11ae030: ldur            x0, [fp, #-8]
    // 0x11ae034: mov             x1, x0
    // 0x11ae038: r2 = Instance_GestureDisposition
    //     0x11ae038: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0x11ae03c: ldr             x2, [x2, #0x610]
    // 0x11ae040: r0 = resolve()
    //     0x11ae040: bl              #0xd01798  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::resolve
    // 0x11ae044: ldur            x0, [fp, #-8]
    // 0x11ae048: LoadField: r1 = r0->field_47
    //     0x11ae048: ldur            w1, [x0, #0x47]
    // 0x11ae04c: DecompressPointer r1
    //     0x11ae04c: add             x1, x1, HEAP, lsl #32
    // 0x11ae050: tbnz            w1, #4, #0x11ae060
    // 0x11ae054: mov             x1, x0
    // 0x11ae058: r2 = ""
    //     0x11ae058: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x11ae05c: r0 = _checkCancel()
    //     0x11ae05c: bl              #0xba0770  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0x11ae060: ldur            x1, [fp, #-8]
    // 0x11ae064: r0 = _reset()
    //     0x11ae064: bl              #0xba0754  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x11ae068: b               #0x11ae168
    // 0x11ae06c: ldur            x2, [fp, #-8]
    // 0x11ae070: ldur            x3, [fp, #-0x10]
    // 0x11ae074: r0 = LoadClassIdInstr(r3)
    //     0x11ae074: ldur            x0, [x3, #-1]
    //     0x11ae078: ubfx            x0, x0, #0xc, #0x14
    // 0x11ae07c: mov             x1, x3
    // 0x11ae080: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11ae080: mov             x17, #0x6f9c
    //     0x11ae084: movk            x17, #1, lsl #16
    //     0x11ae088: add             lr, x0, x17
    //     0x11ae08c: ldr             lr, [x21, lr, lsl #3]
    //     0x11ae090: blr             lr
    // 0x11ae094: mov             x3, x0
    // 0x11ae098: ldur            x2, [fp, #-8]
    // 0x11ae09c: stur            x3, [fp, #-0x18]
    // 0x11ae0a0: LoadField: r1 = r2->field_4f
    //     0x11ae0a0: ldur            w1, [x2, #0x4f]
    // 0x11ae0a4: DecompressPointer r1
    //     0x11ae0a4: add             x1, x1, HEAP, lsl #32
    // 0x11ae0a8: cmp             w1, NULL
    // 0x11ae0ac: b.eq            #0x11ae180
    // 0x11ae0b0: r0 = LoadClassIdInstr(r1)
    //     0x11ae0b0: ldur            x0, [x1, #-1]
    //     0x11ae0b4: ubfx            x0, x0, #0xc, #0x14
    // 0x11ae0b8: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11ae0b8: mov             x17, #0x6f9c
    //     0x11ae0bc: movk            x17, #1, lsl #16
    //     0x11ae0c0: add             lr, x0, x17
    //     0x11ae0c4: ldr             lr, [x21, lr, lsl #3]
    //     0x11ae0c8: blr             lr
    // 0x11ae0cc: mov             x1, x0
    // 0x11ae0d0: ldur            x0, [fp, #-0x18]
    // 0x11ae0d4: cmp             x0, x1
    // 0x11ae0d8: b.eq            #0x11ae110
    // 0x11ae0dc: ldur            x0, [fp, #-8]
    // 0x11ae0e0: mov             x1, x0
    // 0x11ae0e4: r2 = Instance_GestureDisposition
    //     0x11ae0e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0x11ae0e8: ldr             x2, [x2, #0x610]
    // 0x11ae0ec: r0 = resolve()
    //     0x11ae0ec: bl              #0xd01798  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::resolve
    // 0x11ae0f0: ldur            x3, [fp, #-8]
    // 0x11ae0f4: LoadField: r2 = r3->field_37
    //     0x11ae0f4: ldur            w2, [x3, #0x37]
    // 0x11ae0f8: DecompressPointer r2
    //     0x11ae0f8: add             x2, x2, HEAP, lsl #32
    // 0x11ae0fc: cmp             w2, NULL
    // 0x11ae100: b.eq            #0x11ae184
    // 0x11ae104: mov             x1, x3
    // 0x11ae108: r0 = stopTrackingPointer()
    //     0x11ae108: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x11ae10c: b               #0x11ae168
    // 0x11ae110: ldur            x3, [fp, #-8]
    // 0x11ae114: ldur            x0, [fp, #-0x10]
    // 0x11ae118: r2 = Null
    //     0x11ae118: mov             x2, NULL
    // 0x11ae11c: r1 = Null
    //     0x11ae11c: mov             x1, NULL
    // 0x11ae120: cmp             w0, NULL
    // 0x11ae124: b.eq            #0x11ae14c
    // 0x11ae128: branchIfSmi(r0, 0x11ae14c)
    //     0x11ae128: tbz             w0, #0, #0x11ae14c
    // 0x11ae12c: r3 = LoadClassIdInstr(r0)
    //     0x11ae12c: ldur            x3, [x0, #-1]
    //     0x11ae130: ubfx            x3, x3, #0xc, #0x14
    // 0x11ae134: r17 = 4157
    //     0x11ae134: mov             x17, #0x103d
    // 0x11ae138: cmp             x3, x17
    // 0x11ae13c: b.eq            #0x11ae154
    // 0x11ae140: r17 = 5286
    //     0x11ae140: mov             x17, #0x14a6
    // 0x11ae144: cmp             x3, x17
    // 0x11ae148: b.eq            #0x11ae154
    // 0x11ae14c: r0 = false
    //     0x11ae14c: add             x0, NULL, #0x30  ; false
    // 0x11ae150: b               #0x11ae158
    // 0x11ae154: r0 = true
    //     0x11ae154: add             x0, NULL, #0x20  ; true
    // 0x11ae158: tbnz            w0, #4, #0x11ae168
    // 0x11ae15c: ldur            x1, [fp, #-8]
    // 0x11ae160: ldur            x2, [fp, #-0x10]
    // 0x11ae164: r0 = _checkMove()
    //     0x11ae164: bl              #0x11ae188  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkMove
    // 0x11ae168: r0 = Null
    //     0x11ae168: mov             x0, NULL
    // 0x11ae16c: LeaveFrame
    //     0x11ae16c: mov             SP, fp
    //     0x11ae170: ldp             fp, lr, [SP], #0x10
    // 0x11ae174: ret
    //     0x11ae174: ret             
    // 0x11ae178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ae178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ae17c: b               #0x11adf6c
    // 0x11ae180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11ae180: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11ae184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11ae184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkMove(/* No info */) {
    // ** addr: 0x11ae188, size: 0x58
    // 0x11ae188: EnterFrame
    //     0x11ae188: stp             fp, lr, [SP, #-0x10]!
    //     0x11ae18c: mov             fp, SP
    // 0x11ae190: CheckStackOverflow
    //     0x11ae190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ae194: cmp             SP, x16
    //     0x11ae198: b.ls            #0x11ae1d8
    // 0x11ae19c: r0 = LoadClassIdInstr(r1)
    //     0x11ae19c: ldur            x0, [x1, #-1]
    //     0x11ae1a0: ubfx            x0, x0, #0xc, #0x14
    // 0x11ae1a4: r17 = 4436
    //     0x11ae1a4: mov             x17, #0x1154
    // 0x11ae1a8: cmp             x0, x17
    // 0x11ae1ac: b.eq            #0x11ae1c8
    // 0x11ae1b0: r0 = LoadClassIdInstr(r1)
    //     0x11ae1b0: ldur            x0, [x1, #-1]
    //     0x11ae1b4: ubfx            x0, x0, #0xc, #0x14
    // 0x11ae1b8: r0 = GDT[cid_x0 + 0x17ee]()
    //     0x11ae1b8: mov             x17, #0x17ee
    //     0x11ae1bc: add             lr, x0, x17
    //     0x11ae1c0: ldr             lr, [x21, lr, lsl #3]
    //     0x11ae1c4: blr             lr
    // 0x11ae1c8: r0 = Null
    //     0x11ae1c8: mov             x0, NULL
    // 0x11ae1cc: LeaveFrame
    //     0x11ae1cc: mov             SP, fp
    //     0x11ae1d0: ldp             fp, lr, [SP], #0x10
    // 0x11ae1d4: ret
    //     0x11ae1d4: ret             
    // 0x11ae1d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ae1d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ae1dc: b               #0x11ae19c
  }
}

// class id: 4437, size: 0x88, field offset: 0x58
class TapGestureRecognizer extends BaseTapGestureRecognizer {

  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb7440, size: 0x16c
    // 0xbb7440: EnterFrame
    //     0xbb7440: stp             fp, lr, [SP, #-0x10]!
    //     0xbb7444: mov             fp, SP
    // 0xbb7448: AllocStack(0x10)
    //     0xbb7448: sub             SP, SP, #0x10
    // 0xbb744c: SetupParameters(TapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbb744c: mov             x3, x1
    //     0xbb7450: stur            x1, [fp, #-8]
    //     0xbb7454: stur            x2, [fp, #-0x10]
    // 0xbb7458: CheckStackOverflow
    //     0xbb7458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb745c: cmp             SP, x16
    //     0xbb7460: b.ls            #0xbb75a4
    // 0xbb7464: r0 = LoadClassIdInstr(r2)
    //     0xbb7464: ldur            x0, [x2, #-1]
    //     0xbb7468: ubfx            x0, x0, #0xc, #0x14
    // 0xbb746c: mov             x1, x2
    // 0xbb7470: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbb7470: mov             x17, #0x6f9c
    //     0xbb7474: movk            x17, #1, lsl #16
    //     0xbb7478: add             lr, x0, x17
    //     0xbb747c: ldr             lr, [x21, lr, lsl #3]
    //     0xbb7480: blr             lr
    // 0xbb7484: mov             x2, x0
    // 0xbb7488: cmp             x2, #2
    // 0xbb748c: b.gt            #0xbb7560
    // 0xbb7490: cmp             x2, #1
    // 0xbb7494: b.gt            #0xbb7518
    // 0xbb7498: r0 = BoxInt64Instr(r2)
    //     0xbb7498: sbfiz           x0, x2, #1, #0x1f
    //     0xbb749c: cmp             x2, x0, asr #1
    //     0xbb74a0: b.eq            #0xbb74ac
    //     0xbb74a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb74a8: stur            x2, [x0, #7]
    // 0xbb74ac: cmp             w0, #2
    // 0xbb74b0: b.ne            #0xbb7594
    // 0xbb74b4: ldur            x1, [fp, #-8]
    // 0xbb74b8: LoadField: r0 = r1->field_57
    //     0xbb74b8: ldur            w0, [x1, #0x57]
    // 0xbb74bc: DecompressPointer r0
    //     0xbb74bc: add             x0, x0, HEAP, lsl #32
    // 0xbb74c0: cmp             w0, NULL
    // 0xbb74c4: b.ne            #0xbb754c
    // 0xbb74c8: LoadField: r0 = r1->field_5f
    //     0xbb74c8: ldur            w0, [x1, #0x5f]
    // 0xbb74cc: DecompressPointer r0
    //     0xbb74cc: add             x0, x0, HEAP, lsl #32
    // 0xbb74d0: cmp             w0, NULL
    // 0xbb74d4: b.ne            #0xbb754c
    // 0xbb74d8: LoadField: r0 = r1->field_5b
    //     0xbb74d8: ldur            w0, [x1, #0x5b]
    // 0xbb74dc: DecompressPointer r0
    //     0xbb74dc: add             x0, x0, HEAP, lsl #32
    // 0xbb74e0: cmp             w0, NULL
    // 0xbb74e4: b.ne            #0xbb754c
    // 0xbb74e8: LoadField: r0 = r1->field_67
    //     0xbb74e8: ldur            w0, [x1, #0x67]
    // 0xbb74ec: DecompressPointer r0
    //     0xbb74ec: add             x0, x0, HEAP, lsl #32
    // 0xbb74f0: cmp             w0, NULL
    // 0xbb74f4: b.ne            #0xbb754c
    // 0xbb74f8: LoadField: r0 = r1->field_63
    //     0xbb74f8: ldur            w0, [x1, #0x63]
    // 0xbb74fc: DecompressPointer r0
    //     0xbb74fc: add             x0, x0, HEAP, lsl #32
    // 0xbb7500: cmp             w0, NULL
    // 0xbb7504: b.ne            #0xbb754c
    // 0xbb7508: r0 = false
    //     0xbb7508: add             x0, NULL, #0x30  ; false
    // 0xbb750c: LeaveFrame
    //     0xbb750c: mov             SP, fp
    //     0xbb7510: ldp             fp, lr, [SP], #0x10
    // 0xbb7514: ret
    //     0xbb7514: ret             
    // 0xbb7518: ldur            x1, [fp, #-8]
    // 0xbb751c: LoadField: r0 = r1->field_6b
    //     0xbb751c: ldur            w0, [x1, #0x6b]
    // 0xbb7520: DecompressPointer r0
    //     0xbb7520: add             x0, x0, HEAP, lsl #32
    // 0xbb7524: cmp             w0, NULL
    // 0xbb7528: b.ne            #0xbb754c
    // 0xbb752c: LoadField: r0 = r1->field_6f
    //     0xbb752c: ldur            w0, [x1, #0x6f]
    // 0xbb7530: DecompressPointer r0
    //     0xbb7530: add             x0, x0, HEAP, lsl #32
    // 0xbb7534: cmp             w0, NULL
    // 0xbb7538: b.ne            #0xbb754c
    // 0xbb753c: r0 = false
    //     0xbb753c: add             x0, NULL, #0x30  ; false
    // 0xbb7540: LeaveFrame
    //     0xbb7540: mov             SP, fp
    //     0xbb7544: ldp             fp, lr, [SP], #0x10
    // 0xbb7548: ret
    //     0xbb7548: ret             
    // 0xbb754c: ldur            x2, [fp, #-0x10]
    // 0xbb7550: r0 = isPointerAllowed()
    //     0xbb7550: bl              #0xbb75f8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xbb7554: LeaveFrame
    //     0xbb7554: mov             SP, fp
    //     0xbb7558: ldp             fp, lr, [SP], #0x10
    // 0xbb755c: ret
    //     0xbb755c: ret             
    // 0xbb7560: cmp             x2, #4
    // 0xbb7564: b.lt            #0xbb7594
    // 0xbb7568: r0 = BoxInt64Instr(r2)
    //     0xbb7568: sbfiz           x0, x2, #1, #0x1f
    //     0xbb756c: cmp             x2, x0, asr #1
    //     0xbb7570: b.eq            #0xbb757c
    //     0xbb7574: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb7578: stur            x2, [x0, #7]
    // 0xbb757c: cmp             w0, #8
    // 0xbb7580: b.ne            #0xbb7594
    // 0xbb7584: r0 = false
    //     0xbb7584: add             x0, NULL, #0x30  ; false
    // 0xbb7588: LeaveFrame
    //     0xbb7588: mov             SP, fp
    //     0xbb758c: ldp             fp, lr, [SP], #0x10
    // 0xbb7590: ret
    //     0xbb7590: ret             
    // 0xbb7594: r0 = false
    //     0xbb7594: add             x0, NULL, #0x30  ; false
    // 0xbb7598: LeaveFrame
    //     0xbb7598: mov             SP, fp
    //     0xbb759c: ldp             fp, lr, [SP], #0x10
    // 0xbb75a0: ret
    //     0xbb75a0: ret             
    // 0xbb75a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb75a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb75a8: b               #0xbb7464
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0x119fec0, size: 0x214
    // 0x119fec0: EnterFrame
    //     0x119fec0: stp             fp, lr, [SP, #-0x10]!
    //     0x119fec4: mov             fp, SP
    // 0x119fec8: AllocStack(0x48)
    //     0x119fec8: sub             SP, SP, #0x48
    // 0x119fecc: SetupParameters(TapGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x119fecc: mov             x0, x1
    //     0x119fed0: stur            x1, [fp, #-8]
    //     0x119fed4: mov             x1, x2
    //     0x119fed8: stur            x2, [fp, #-0x10]
    // 0x119fedc: CheckStackOverflow
    //     0x119fedc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fee0: cmp             SP, x16
    //     0x119fee4: b.ls            #0x11a00cc
    // 0x119fee8: r1 = 2
    //     0x119fee8: mov             x1, #2
    // 0x119feec: r0 = AllocateContext()
    //     0x119feec: bl              #0x13de838  ; AllocateContextStub
    // 0x119fef0: mov             x3, x0
    // 0x119fef4: ldur            x2, [fp, #-8]
    // 0x119fef8: stur            x3, [fp, #-0x18]
    // 0x119fefc: StoreField: r3->field_f = r2
    //     0x119fefc: stur            w2, [x3, #0xf]
    // 0x119ff00: ldur            x4, [fp, #-0x10]
    // 0x119ff04: r0 = LoadClassIdInstr(r4)
    //     0x119ff04: ldur            x0, [x4, #-1]
    //     0x119ff08: ubfx            x0, x0, #0xc, #0x14
    // 0x119ff0c: mov             x1, x4
    // 0x119ff10: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x119ff10: mov             x17, #0x3f27
    //     0x119ff14: movk            x17, #1, lsl #16
    //     0x119ff18: add             lr, x0, x17
    //     0x119ff1c: ldr             lr, [x21, lr, lsl #3]
    //     0x119ff20: blr             lr
    // 0x119ff24: mov             x3, x0
    // 0x119ff28: ldur            x2, [fp, #-0x10]
    // 0x119ff2c: stur            x3, [fp, #-0x20]
    // 0x119ff30: r0 = LoadClassIdInstr(r2)
    //     0x119ff30: ldur            x0, [x2, #-1]
    //     0x119ff34: ubfx            x0, x0, #0xc, #0x14
    // 0x119ff38: mov             x1, x2
    // 0x119ff3c: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x119ff3c: mov             x17, #0x54ea
    //     0x119ff40: movk            x17, #1, lsl #16
    //     0x119ff44: add             lr, x0, x17
    //     0x119ff48: ldr             lr, [x21, lr, lsl #3]
    //     0x119ff4c: blr             lr
    // 0x119ff50: mov             x3, x0
    // 0x119ff54: ldur            x2, [fp, #-0x10]
    // 0x119ff58: stur            x3, [fp, #-0x28]
    // 0x119ff5c: r0 = LoadClassIdInstr(r2)
    //     0x119ff5c: ldur            x0, [x2, #-1]
    //     0x119ff60: ubfx            x0, x0, #0xc, #0x14
    // 0x119ff64: mov             x1, x2
    // 0x119ff68: r0 = GDT[cid_x0 + -0x1]()
    //     0x119ff68: sub             lr, x0, #1
    //     0x119ff6c: ldr             lr, [x21, lr, lsl #3]
    //     0x119ff70: blr             lr
    // 0x119ff74: ldur            x1, [fp, #-8]
    // 0x119ff78: mov             x2, x0
    // 0x119ff7c: r0 = getKindForPointer()
    //     0x119ff7c: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0x119ff80: stur            x0, [fp, #-0x30]
    // 0x119ff84: r0 = TapDownDetails()
    //     0x119ff84: bl              #0xba7818  ; AllocateTapDownDetailsStub -> TapDownDetails (size=0x14)
    // 0x119ff88: mov             x1, x0
    // 0x119ff8c: ldur            x0, [fp, #-0x20]
    // 0x119ff90: StoreField: r1->field_7 = r0
    //     0x119ff90: stur            w0, [x1, #7]
    // 0x119ff94: ldur            x0, [fp, #-0x30]
    // 0x119ff98: StoreField: r1->field_f = r0
    //     0x119ff98: stur            w0, [x1, #0xf]
    // 0x119ff9c: ldur            x0, [fp, #-0x28]
    // 0x119ffa0: StoreField: r1->field_b = r0
    //     0x119ffa0: stur            w0, [x1, #0xb]
    // 0x119ffa4: mov             x0, x1
    // 0x119ffa8: ldur            x2, [fp, #-0x18]
    // 0x119ffac: StoreField: r2->field_13 = r0
    //     0x119ffac: stur            w0, [x2, #0x13]
    //     0x119ffb0: ldurb           w16, [x2, #-1]
    //     0x119ffb4: ldurb           w17, [x0, #-1]
    //     0x119ffb8: and             x16, x17, x16, lsr #2
    //     0x119ffbc: tst             x16, HEAP, lsr #32
    //     0x119ffc0: b.eq            #0x119ffc8
    //     0x119ffc4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x119ffc8: ldur            x1, [fp, #-0x10]
    // 0x119ffcc: r0 = LoadClassIdInstr(r1)
    //     0x119ffcc: ldur            x0, [x1, #-1]
    //     0x119ffd0: ubfx            x0, x0, #0xc, #0x14
    // 0x119ffd4: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x119ffd4: mov             x17, #0x6f9c
    //     0x119ffd8: movk            x17, #1, lsl #16
    //     0x119ffdc: add             lr, x0, x17
    //     0x119ffe0: ldr             lr, [x21, lr, lsl #3]
    //     0x119ffe4: blr             lr
    // 0x119ffe8: mov             x2, x0
    // 0x119ffec: cmp             x2, #2
    // 0x119fff0: b.gt            #0x11a0098
    // 0x119fff4: cmp             x2, #1
    // 0x119fff8: b.gt            #0x11a0058
    // 0x119fffc: r0 = BoxInt64Instr(r2)
    //     0x119fffc: sbfiz           x0, x2, #1, #0x1f
    //     0x11a0000: cmp             x2, x0, asr #1
    //     0x11a0004: b.eq            #0x11a0010
    //     0x11a0008: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a000c: stur            x2, [x0, #7]
    // 0x11a0010: cmp             w0, #2
    // 0x11a0014: b.ne            #0x11a00bc
    // 0x11a0018: ldur            x0, [fp, #-8]
    // 0x11a001c: LoadField: r1 = r0->field_57
    //     0x11a001c: ldur            w1, [x0, #0x57]
    // 0x11a0020: DecompressPointer r1
    //     0x11a0020: add             x1, x1, HEAP, lsl #32
    // 0x11a0024: cmp             w1, NULL
    // 0x11a0028: b.eq            #0x11a00bc
    // 0x11a002c: ldur            x2, [fp, #-0x18]
    // 0x11a0030: r1 = Function '<anonymous closure>':.
    //     0x11a0030: add             x1, PP, #0x99, lsl #12  ; [pp+0x99f30] AnonymousClosure: (0x11a0140), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapDown (0x119fec0)
    //     0x11a0034: ldr             x1, [x1, #0xf30]
    // 0x11a0038: r0 = AllocateClosure()
    //     0x11a0038: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a003c: r16 = <void?>
    //     0x11a003c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0040: ldur            lr, [fp, #-8]
    // 0x11a0044: stp             lr, x16, [SP, #8]
    // 0x11a0048: str             x0, [SP]
    // 0x11a004c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a004c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0050: r0 = invokeCallback()
    //     0x11a0050: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0054: b               #0x11a00bc
    // 0x11a0058: ldur            x0, [fp, #-8]
    // 0x11a005c: LoadField: r1 = r0->field_6f
    //     0x11a005c: ldur            w1, [x0, #0x6f]
    // 0x11a0060: DecompressPointer r1
    //     0x11a0060: add             x1, x1, HEAP, lsl #32
    // 0x11a0064: cmp             w1, NULL
    // 0x11a0068: b.eq            #0x11a00bc
    // 0x11a006c: ldur            x2, [fp, #-0x18]
    // 0x11a0070: r1 = Function '<anonymous closure>':.
    //     0x11a0070: add             x1, PP, #0x99, lsl #12  ; [pp+0x99f38] AnonymousClosure: (0x11a00d4), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapDown (0x119fec0)
    //     0x11a0074: ldr             x1, [x1, #0xf38]
    // 0x11a0078: r0 = AllocateClosure()
    //     0x11a0078: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a007c: r16 = <void?>
    //     0x11a007c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0080: ldur            lr, [fp, #-8]
    // 0x11a0084: stp             lr, x16, [SP, #8]
    // 0x11a0088: str             x0, [SP]
    // 0x11a008c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a008c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0090: r0 = invokeCallback()
    //     0x11a0090: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0094: b               #0x11a00bc
    // 0x11a0098: cmp             x2, #4
    // 0x11a009c: b.lt            #0x11a00bc
    // 0x11a00a0: r0 = BoxInt64Instr(r2)
    //     0x11a00a0: sbfiz           x0, x2, #1, #0x1f
    //     0x11a00a4: cmp             x2, x0, asr #1
    //     0x11a00a8: b.eq            #0x11a00b4
    //     0x11a00ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a00b0: stur            x2, [x0, #7]
    // 0x11a00b4: cmp             w0, #8
    // 0x11a00b8: b.eq            #0x11a00bc
    // 0x11a00bc: r0 = Null
    //     0x11a00bc: mov             x0, NULL
    // 0x11a00c0: LeaveFrame
    //     0x11a00c0: mov             SP, fp
    //     0x11a00c4: ldp             fp, lr, [SP], #0x10
    // 0x11a00c8: ret
    //     0x11a00c8: ret             
    // 0x11a00cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a00cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a00d0: b               #0x119fee8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11a00d4, size: 0x6c
    // 0x11a00d4: EnterFrame
    //     0x11a00d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a00d8: mov             fp, SP
    // 0x11a00dc: ldr             x0, [fp, #0x10]
    // 0x11a00e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a00e0: ldur            w1, [x0, #0x17]
    // 0x11a00e4: DecompressPointer r1
    //     0x11a00e4: add             x1, x1, HEAP, lsl #32
    // 0x11a00e8: CheckStackOverflow
    //     0x11a00e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a00ec: cmp             SP, x16
    //     0x11a00f0: b.ls            #0x11a0134
    // 0x11a00f4: LoadField: r0 = r1->field_f
    //     0x11a00f4: ldur            w0, [x1, #0xf]
    // 0x11a00f8: DecompressPointer r0
    //     0x11a00f8: add             x0, x0, HEAP, lsl #32
    // 0x11a00fc: LoadField: r2 = r0->field_6f
    //     0x11a00fc: ldur            w2, [x0, #0x6f]
    // 0x11a0100: DecompressPointer r2
    //     0x11a0100: add             x2, x2, HEAP, lsl #32
    // 0x11a0104: cmp             w2, NULL
    // 0x11a0108: b.eq            #0x11a013c
    // 0x11a010c: LoadField: r0 = r1->field_13
    //     0x11a010c: ldur            w0, [x1, #0x13]
    // 0x11a0110: DecompressPointer r0
    //     0x11a0110: add             x0, x0, HEAP, lsl #32
    // 0x11a0114: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x11a0114: ldur            w1, [x2, #0x17]
    // 0x11a0118: DecompressPointer r1
    //     0x11a0118: add             x1, x1, HEAP, lsl #32
    // 0x11a011c: mov             x2, x0
    // 0x11a0120: r0 = onSecondaryTapDown()
    //     0x11a0120: bl              #0xd473b4  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onSecondaryTapDown
    // 0x11a0124: r0 = Null
    //     0x11a0124: mov             x0, NULL
    // 0x11a0128: LeaveFrame
    //     0x11a0128: mov             SP, fp
    //     0x11a012c: ldp             fp, lr, [SP], #0x10
    // 0x11a0130: ret
    //     0x11a0130: ret             
    // 0x11a0134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a0134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a0138: b               #0x11a00f4
    // 0x11a013c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a013c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11a0140, size: 0x70
    // 0x11a0140: EnterFrame
    //     0x11a0140: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0144: mov             fp, SP
    // 0x11a0148: AllocStack(0x10)
    //     0x11a0148: sub             SP, SP, #0x10
    // 0x11a014c: SetupParameters([dynamic _ /* r0 */])
    //     0x11a014c: ldr             x0, [fp, #0x10]
    //     0x11a0150: ldur            w1, [x0, #0x17]
    //     0x11a0154: add             x1, x1, HEAP, lsl #32
    // 0x11a0158: CheckStackOverflow
    //     0x11a0158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a015c: cmp             SP, x16
    //     0x11a0160: b.ls            #0x11a01a4
    // 0x11a0164: LoadField: r0 = r1->field_f
    //     0x11a0164: ldur            w0, [x1, #0xf]
    // 0x11a0168: DecompressPointer r0
    //     0x11a0168: add             x0, x0, HEAP, lsl #32
    // 0x11a016c: LoadField: r2 = r0->field_57
    //     0x11a016c: ldur            w2, [x0, #0x57]
    // 0x11a0170: DecompressPointer r2
    //     0x11a0170: add             x2, x2, HEAP, lsl #32
    // 0x11a0174: cmp             w2, NULL
    // 0x11a0178: b.eq            #0x11a01ac
    // 0x11a017c: LoadField: r0 = r1->field_13
    //     0x11a017c: ldur            w0, [x1, #0x13]
    // 0x11a0180: DecompressPointer r0
    //     0x11a0180: add             x0, x0, HEAP, lsl #32
    // 0x11a0184: stp             x0, x2, [SP]
    // 0x11a0188: mov             x0, x2
    // 0x11a018c: ClosureCall
    //     0x11a018c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x11a0190: ldur            x2, [x0, #0x1f]
    //     0x11a0194: blr             x2
    // 0x11a0198: LeaveFrame
    //     0x11a0198: mov             SP, fp
    //     0x11a019c: ldp             fp, lr, [SP], #0x10
    // 0x11a01a0: ret
    //     0x11a01a0: ret             
    // 0x11a01a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a01a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a01a8: b               #0x11a0164
    // 0x11a01ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a01ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapCancel(/* No info */) {
    // ** addr: 0x11a09cc, size: 0x178
    // 0x11a09cc: EnterFrame
    //     0x11a09cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a09d0: mov             fp, SP
    // 0x11a09d4: AllocStack(0x30)
    //     0x11a09d4: sub             SP, SP, #0x30
    // 0x11a09d8: SetupParameters(TapGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x11a09d8: mov             x0, x1
    //     0x11a09dc: stur            x1, [fp, #-8]
    //     0x11a09e0: mov             x1, x2
    //     0x11a09e4: stur            x2, [fp, #-0x10]
    //     0x11a09e8: stur            x3, [fp, #-0x18]
    // 0x11a09ec: CheckStackOverflow
    //     0x11a09ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a09f0: cmp             SP, x16
    //     0x11a09f4: b.ls            #0x11a0b38
    // 0x11a09f8: r16 = ""
    //     0x11a09f8: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x11a09fc: stp             x16, x3, [SP]
    // 0x11a0a00: r0 = ==()
    //     0x11a0a00: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x11a0a04: tbnz            w0, #4, #0x11a0a10
    // 0x11a0a08: ldur            x2, [fp, #-0x18]
    // 0x11a0a0c: b               #0x11a0a40
    // 0x11a0a10: ldur            x0, [fp, #-0x18]
    // 0x11a0a14: r1 = Null
    //     0x11a0a14: mov             x1, NULL
    // 0x11a0a18: r2 = 4
    //     0x11a0a18: mov             x2, #4
    // 0x11a0a1c: r0 = AllocateArray()
    //     0x11a0a1c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a0a20: mov             x1, x0
    // 0x11a0a24: ldur            x0, [fp, #-0x18]
    // 0x11a0a28: StoreField: r1->field_f = r0
    //     0x11a0a28: stur            w0, [x1, #0xf]
    // 0x11a0a2c: r16 = " "
    //     0x11a0a2c: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x11a0a30: StoreField: r1->field_13 = r16
    //     0x11a0a30: stur            w16, [x1, #0x13]
    // 0x11a0a34: str             x1, [SP]
    // 0x11a0a38: r0 = _interpolate()
    //     0x11a0a38: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a0a3c: mov             x2, x0
    // 0x11a0a40: ldur            x1, [fp, #-0x10]
    // 0x11a0a44: stur            x2, [fp, #-0x18]
    // 0x11a0a48: r0 = LoadClassIdInstr(r1)
    //     0x11a0a48: ldur            x0, [x1, #-1]
    //     0x11a0a4c: ubfx            x0, x0, #0xc, #0x14
    // 0x11a0a50: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11a0a50: mov             x17, #0x6f9c
    //     0x11a0a54: movk            x17, #1, lsl #16
    //     0x11a0a58: add             lr, x0, x17
    //     0x11a0a5c: ldr             lr, [x21, lr, lsl #3]
    //     0x11a0a60: blr             lr
    // 0x11a0a64: mov             x2, x0
    // 0x11a0a68: cmp             x2, #2
    // 0x11a0a6c: b.gt            #0x11a0b04
    // 0x11a0a70: cmp             x2, #1
    // 0x11a0a74: b.gt            #0x11a0b28
    // 0x11a0a78: r0 = BoxInt64Instr(r2)
    //     0x11a0a78: sbfiz           x0, x2, #1, #0x1f
    //     0x11a0a7c: cmp             x2, x0, asr #1
    //     0x11a0a80: b.eq            #0x11a0a8c
    //     0x11a0a84: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a0a88: stur            x2, [x0, #7]
    // 0x11a0a8c: cmp             w0, #2
    // 0x11a0a90: b.ne            #0x11a0b28
    // 0x11a0a94: ldur            x0, [fp, #-8]
    // 0x11a0a98: LoadField: r1 = r0->field_67
    //     0x11a0a98: ldur            w1, [x0, #0x67]
    // 0x11a0a9c: DecompressPointer r1
    //     0x11a0a9c: add             x1, x1, HEAP, lsl #32
    // 0x11a0aa0: cmp             w1, NULL
    // 0x11a0aa4: b.eq            #0x11a0b28
    // 0x11a0aa8: ldur            x3, [fp, #-0x18]
    // 0x11a0aac: r1 = Null
    //     0x11a0aac: mov             x1, NULL
    // 0x11a0ab0: r2 = 4
    //     0x11a0ab0: mov             x2, #4
    // 0x11a0ab4: r0 = AllocateArray()
    //     0x11a0ab4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a0ab8: mov             x1, x0
    // 0x11a0abc: ldur            x0, [fp, #-0x18]
    // 0x11a0ac0: StoreField: r1->field_f = r0
    //     0x11a0ac0: stur            w0, [x1, #0xf]
    // 0x11a0ac4: r16 = "onTapCancel"
    //     0x11a0ac4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16f30] "onTapCancel"
    //     0x11a0ac8: ldr             x16, [x16, #0xf30]
    // 0x11a0acc: StoreField: r1->field_13 = r16
    //     0x11a0acc: stur            w16, [x1, #0x13]
    // 0x11a0ad0: str             x1, [SP]
    // 0x11a0ad4: r0 = _interpolate()
    //     0x11a0ad4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a0ad8: ldur            x0, [fp, #-8]
    // 0x11a0adc: LoadField: r1 = r0->field_67
    //     0x11a0adc: ldur            w1, [x0, #0x67]
    // 0x11a0ae0: DecompressPointer r1
    //     0x11a0ae0: add             x1, x1, HEAP, lsl #32
    // 0x11a0ae4: cmp             w1, NULL
    // 0x11a0ae8: b.eq            #0x11a0b40
    // 0x11a0aec: r16 = <void?>
    //     0x11a0aec: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0af0: stp             x0, x16, [SP, #8]
    // 0x11a0af4: str             x1, [SP]
    // 0x11a0af8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a0af8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0afc: r0 = invokeCallback()
    //     0x11a0afc: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0b00: b               #0x11a0b28
    // 0x11a0b04: cmp             x2, #4
    // 0x11a0b08: b.lt            #0x11a0b28
    // 0x11a0b0c: r0 = BoxInt64Instr(r2)
    //     0x11a0b0c: sbfiz           x0, x2, #1, #0x1f
    //     0x11a0b10: cmp             x2, x0, asr #1
    //     0x11a0b14: b.eq            #0x11a0b20
    //     0x11a0b18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a0b1c: stur            x2, [x0, #7]
    // 0x11a0b20: cmp             w0, #8
    // 0x11a0b24: b.eq            #0x11a0b28
    // 0x11a0b28: r0 = Null
    //     0x11a0b28: mov             x0, NULL
    // 0x11a0b2c: LeaveFrame
    //     0x11a0b2c: mov             SP, fp
    //     0x11a0b30: ldp             fp, lr, [SP], #0x10
    // 0x11a0b34: ret
    //     0x11a0b34: ret             
    // 0x11a0b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a0b38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a0b3c: b               #0x11a09f8
    // 0x11a0b40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a0b40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapUp(/* No info */) {
    // ** addr: 0x11a0c10, size: 0x220
    // 0x11a0c10: EnterFrame
    //     0x11a0c10: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0c14: mov             fp, SP
    // 0x11a0c18: AllocStack(0x40)
    //     0x11a0c18: sub             SP, SP, #0x40
    // 0x11a0c1c: SetupParameters(TapGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x11a0c1c: mov             x0, x2
    //     0x11a0c20: stur            x2, [fp, #-0x10]
    //     0x11a0c24: mov             x2, x1
    //     0x11a0c28: stur            x1, [fp, #-8]
    //     0x11a0c2c: mov             x1, x3
    //     0x11a0c30: stur            x3, [fp, #-0x18]
    // 0x11a0c34: CheckStackOverflow
    //     0x11a0c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a0c38: cmp             SP, x16
    //     0x11a0c3c: b.ls            #0x11a0e28
    // 0x11a0c40: r1 = 2
    //     0x11a0c40: mov             x1, #2
    // 0x11a0c44: r0 = AllocateContext()
    //     0x11a0c44: bl              #0x13de838  ; AllocateContextStub
    // 0x11a0c48: mov             x3, x0
    // 0x11a0c4c: ldur            x2, [fp, #-8]
    // 0x11a0c50: stur            x3, [fp, #-0x20]
    // 0x11a0c54: StoreField: r3->field_f = r2
    //     0x11a0c54: stur            w2, [x3, #0xf]
    // 0x11a0c58: ldur            x4, [fp, #-0x18]
    // 0x11a0c5c: r0 = LoadClassIdInstr(r4)
    //     0x11a0c5c: ldur            x0, [x4, #-1]
    //     0x11a0c60: ubfx            x0, x0, #0xc, #0x14
    // 0x11a0c64: mov             x1, x4
    // 0x11a0c68: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x11a0c68: mov             x17, #0x5e74
    //     0x11a0c6c: movk            x17, #1, lsl #16
    //     0x11a0c70: add             lr, x0, x17
    //     0x11a0c74: ldr             lr, [x21, lr, lsl #3]
    //     0x11a0c78: blr             lr
    // 0x11a0c7c: ldur            x2, [fp, #-0x18]
    // 0x11a0c80: r0 = LoadClassIdInstr(r2)
    //     0x11a0c80: ldur            x0, [x2, #-1]
    //     0x11a0c84: ubfx            x0, x0, #0xc, #0x14
    // 0x11a0c88: mov             x1, x2
    // 0x11a0c8c: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x11a0c8c: mov             x17, #0x3f27
    //     0x11a0c90: movk            x17, #1, lsl #16
    //     0x11a0c94: add             lr, x0, x17
    //     0x11a0c98: ldr             lr, [x21, lr, lsl #3]
    //     0x11a0c9c: blr             lr
    // 0x11a0ca0: mov             x2, x0
    // 0x11a0ca4: ldur            x1, [fp, #-0x18]
    // 0x11a0ca8: stur            x2, [fp, #-0x28]
    // 0x11a0cac: r0 = LoadClassIdInstr(r1)
    //     0x11a0cac: ldur            x0, [x1, #-1]
    //     0x11a0cb0: ubfx            x0, x0, #0xc, #0x14
    // 0x11a0cb4: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11a0cb4: mov             x17, #0x54ea
    //     0x11a0cb8: movk            x17, #1, lsl #16
    //     0x11a0cbc: add             lr, x0, x17
    //     0x11a0cc0: ldr             lr, [x21, lr, lsl #3]
    //     0x11a0cc4: blr             lr
    // 0x11a0cc8: r0 = TapUpDetails()
    //     0x11a0cc8: bl              #0xcfc010  ; AllocateTapUpDetailsStub -> TapUpDetails (size=0xc)
    // 0x11a0ccc: mov             x1, x0
    // 0x11a0cd0: ldur            x0, [fp, #-0x28]
    // 0x11a0cd4: StoreField: r1->field_7 = r0
    //     0x11a0cd4: stur            w0, [x1, #7]
    // 0x11a0cd8: mov             x0, x1
    // 0x11a0cdc: ldur            x2, [fp, #-0x20]
    // 0x11a0ce0: StoreField: r2->field_13 = r0
    //     0x11a0ce0: stur            w0, [x2, #0x13]
    //     0x11a0ce4: ldurb           w16, [x2, #-1]
    //     0x11a0ce8: ldurb           w17, [x0, #-1]
    //     0x11a0cec: and             x16, x17, x16, lsr #2
    //     0x11a0cf0: tst             x16, HEAP, lsr #32
    //     0x11a0cf4: b.eq            #0x11a0cfc
    //     0x11a0cf8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11a0cfc: ldur            x1, [fp, #-0x10]
    // 0x11a0d00: r0 = LoadClassIdInstr(r1)
    //     0x11a0d00: ldur            x0, [x1, #-1]
    //     0x11a0d04: ubfx            x0, x0, #0xc, #0x14
    // 0x11a0d08: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11a0d08: mov             x17, #0x6f9c
    //     0x11a0d0c: movk            x17, #1, lsl #16
    //     0x11a0d10: add             lr, x0, x17
    //     0x11a0d14: ldr             lr, [x21, lr, lsl #3]
    //     0x11a0d18: blr             lr
    // 0x11a0d1c: mov             x2, x0
    // 0x11a0d20: cmp             x2, #2
    // 0x11a0d24: b.gt            #0x11a0df4
    // 0x11a0d28: cmp             x2, #1
    // 0x11a0d2c: b.gt            #0x11a0db4
    // 0x11a0d30: r0 = BoxInt64Instr(r2)
    //     0x11a0d30: sbfiz           x0, x2, #1, #0x1f
    //     0x11a0d34: cmp             x2, x0, asr #1
    //     0x11a0d38: b.eq            #0x11a0d44
    //     0x11a0d3c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a0d40: stur            x2, [x0, #7]
    // 0x11a0d44: cmp             w0, #2
    // 0x11a0d48: b.ne            #0x11a0e18
    // 0x11a0d4c: ldur            x0, [fp, #-8]
    // 0x11a0d50: LoadField: r1 = r0->field_5b
    //     0x11a0d50: ldur            w1, [x0, #0x5b]
    // 0x11a0d54: DecompressPointer r1
    //     0x11a0d54: add             x1, x1, HEAP, lsl #32
    // 0x11a0d58: cmp             w1, NULL
    // 0x11a0d5c: b.eq            #0x11a0d88
    // 0x11a0d60: ldur            x2, [fp, #-0x20]
    // 0x11a0d64: r1 = Function '<anonymous closure>':.
    //     0x11a0d64: add             x1, PP, #0x99, lsl #12  ; [pp+0x99f20] AnonymousClosure: (0x11a0e94), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapUp (0x11a0c10)
    //     0x11a0d68: ldr             x1, [x1, #0xf20]
    // 0x11a0d6c: r0 = AllocateClosure()
    //     0x11a0d6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a0d70: r16 = <void?>
    //     0x11a0d70: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0d74: ldur            lr, [fp, #-8]
    // 0x11a0d78: stp             lr, x16, [SP, #8]
    // 0x11a0d7c: str             x0, [SP]
    // 0x11a0d80: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a0d80: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0d84: r0 = invokeCallback()
    //     0x11a0d84: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0d88: ldur            x0, [fp, #-8]
    // 0x11a0d8c: LoadField: r1 = r0->field_5f
    //     0x11a0d8c: ldur            w1, [x0, #0x5f]
    // 0x11a0d90: DecompressPointer r1
    //     0x11a0d90: add             x1, x1, HEAP, lsl #32
    // 0x11a0d94: cmp             w1, NULL
    // 0x11a0d98: b.eq            #0x11a0e18
    // 0x11a0d9c: r16 = <void?>
    //     0x11a0d9c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0da0: stp             x0, x16, [SP, #8]
    // 0x11a0da4: str             x1, [SP]
    // 0x11a0da8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a0da8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0dac: r0 = invokeCallback()
    //     0x11a0dac: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0db0: b               #0x11a0e18
    // 0x11a0db4: ldur            x0, [fp, #-8]
    // 0x11a0db8: LoadField: r1 = r0->field_6b
    //     0x11a0db8: ldur            w1, [x0, #0x6b]
    // 0x11a0dbc: DecompressPointer r1
    //     0x11a0dbc: add             x1, x1, HEAP, lsl #32
    // 0x11a0dc0: cmp             w1, NULL
    // 0x11a0dc4: b.eq            #0x11a0e18
    // 0x11a0dc8: ldur            x2, [fp, #-0x20]
    // 0x11a0dcc: r1 = Function '<anonymous closure>':.
    //     0x11a0dcc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99f28] AnonymousClosure: (0x11a0e30), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapUp (0x11a0c10)
    //     0x11a0dd0: ldr             x1, [x1, #0xf28]
    // 0x11a0dd4: r0 = AllocateClosure()
    //     0x11a0dd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a0dd8: r16 = <void?>
    //     0x11a0dd8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11a0ddc: ldur            lr, [fp, #-8]
    // 0x11a0de0: stp             lr, x16, [SP, #8]
    // 0x11a0de4: str             x0, [SP]
    // 0x11a0de8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11a0de8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11a0dec: r0 = invokeCallback()
    //     0x11a0dec: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11a0df0: b               #0x11a0e18
    // 0x11a0df4: cmp             x2, #4
    // 0x11a0df8: b.lt            #0x11a0e18
    // 0x11a0dfc: r0 = BoxInt64Instr(r2)
    //     0x11a0dfc: sbfiz           x0, x2, #1, #0x1f
    //     0x11a0e00: cmp             x2, x0, asr #1
    //     0x11a0e04: b.eq            #0x11a0e10
    //     0x11a0e08: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11a0e0c: stur            x2, [x0, #7]
    // 0x11a0e10: cmp             w0, #8
    // 0x11a0e14: b.eq            #0x11a0e18
    // 0x11a0e18: r0 = Null
    //     0x11a0e18: mov             x0, NULL
    // 0x11a0e1c: LeaveFrame
    //     0x11a0e1c: mov             SP, fp
    //     0x11a0e20: ldp             fp, lr, [SP], #0x10
    // 0x11a0e24: ret
    //     0x11a0e24: ret             
    // 0x11a0e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a0e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a0e2c: b               #0x11a0c40
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11a0e30, size: 0x64
    // 0x11a0e30: EnterFrame
    //     0x11a0e30: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0e34: mov             fp, SP
    // 0x11a0e38: ldr             x0, [fp, #0x10]
    // 0x11a0e3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a0e3c: ldur            w1, [x0, #0x17]
    // 0x11a0e40: DecompressPointer r1
    //     0x11a0e40: add             x1, x1, HEAP, lsl #32
    // 0x11a0e44: CheckStackOverflow
    //     0x11a0e44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a0e48: cmp             SP, x16
    //     0x11a0e4c: b.ls            #0x11a0e88
    // 0x11a0e50: LoadField: r0 = r1->field_f
    //     0x11a0e50: ldur            w0, [x1, #0xf]
    // 0x11a0e54: DecompressPointer r0
    //     0x11a0e54: add             x0, x0, HEAP, lsl #32
    // 0x11a0e58: LoadField: r1 = r0->field_6b
    //     0x11a0e58: ldur            w1, [x0, #0x6b]
    // 0x11a0e5c: DecompressPointer r1
    //     0x11a0e5c: add             x1, x1, HEAP, lsl #32
    // 0x11a0e60: cmp             w1, NULL
    // 0x11a0e64: b.eq            #0x11a0e90
    // 0x11a0e68: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x11a0e68: ldur            w0, [x1, #0x17]
    // 0x11a0e6c: DecompressPointer r0
    //     0x11a0e6c: add             x0, x0, HEAP, lsl #32
    // 0x11a0e70: mov             x1, x0
    // 0x11a0e74: r0 = onSecondaryTap()
    //     0x11a0e74: bl              #0xd47564  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onSecondaryTap
    // 0x11a0e78: r0 = Null
    //     0x11a0e78: mov             x0, NULL
    // 0x11a0e7c: LeaveFrame
    //     0x11a0e7c: mov             SP, fp
    //     0x11a0e80: ldp             fp, lr, [SP], #0x10
    // 0x11a0e84: ret
    //     0x11a0e84: ret             
    // 0x11a0e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a0e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a0e8c: b               #0x11a0e50
    // 0x11a0e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a0e90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11a0e94, size: 0x70
    // 0x11a0e94: EnterFrame
    //     0x11a0e94: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0e98: mov             fp, SP
    // 0x11a0e9c: AllocStack(0x10)
    //     0x11a0e9c: sub             SP, SP, #0x10
    // 0x11a0ea0: SetupParameters([dynamic _ /* r0 */])
    //     0x11a0ea0: ldr             x0, [fp, #0x10]
    //     0x11a0ea4: ldur            w1, [x0, #0x17]
    //     0x11a0ea8: add             x1, x1, HEAP, lsl #32
    // 0x11a0eac: CheckStackOverflow
    //     0x11a0eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a0eb0: cmp             SP, x16
    //     0x11a0eb4: b.ls            #0x11a0ef8
    // 0x11a0eb8: LoadField: r0 = r1->field_f
    //     0x11a0eb8: ldur            w0, [x1, #0xf]
    // 0x11a0ebc: DecompressPointer r0
    //     0x11a0ebc: add             x0, x0, HEAP, lsl #32
    // 0x11a0ec0: LoadField: r2 = r0->field_5b
    //     0x11a0ec0: ldur            w2, [x0, #0x5b]
    // 0x11a0ec4: DecompressPointer r2
    //     0x11a0ec4: add             x2, x2, HEAP, lsl #32
    // 0x11a0ec8: cmp             w2, NULL
    // 0x11a0ecc: b.eq            #0x11a0f00
    // 0x11a0ed0: LoadField: r0 = r1->field_13
    //     0x11a0ed0: ldur            w0, [x1, #0x13]
    // 0x11a0ed4: DecompressPointer r0
    //     0x11a0ed4: add             x0, x0, HEAP, lsl #32
    // 0x11a0ed8: stp             x0, x2, [SP]
    // 0x11a0edc: mov             x0, x2
    // 0x11a0ee0: ClosureCall
    //     0x11a0ee0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x11a0ee4: ldur            x2, [x0, #0x1f]
    //     0x11a0ee8: blr             x2
    // 0x11a0eec: LeaveFrame
    //     0x11a0eec: mov             SP, fp
    //     0x11a0ef0: ldp             fp, lr, [SP], #0x10
    // 0x11a0ef4: ret
    //     0x11a0ef4: ret             
    // 0x11a0ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a0ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a0efc: b               #0x11a0eb8
    // 0x11a0f00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a0f00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapMove(/* No info */) {
    // ** addr: 0x1205c64, size: 0x188
    // 0x1205c64: EnterFrame
    //     0x1205c64: stp             fp, lr, [SP, #-0x10]!
    //     0x1205c68: mov             fp, SP
    // 0x1205c6c: AllocStack(0x38)
    //     0x1205c6c: sub             SP, SP, #0x38
    // 0x1205c70: SetupParameters(TapGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x1205c70: mov             x0, x1
    //     0x1205c74: stur            x1, [fp, #-8]
    //     0x1205c78: mov             x1, x2
    //     0x1205c7c: stur            x2, [fp, #-0x10]
    // 0x1205c80: CheckStackOverflow
    //     0x1205c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1205c84: cmp             SP, x16
    //     0x1205c88: b.ls            #0x1205de4
    // 0x1205c8c: r1 = 2
    //     0x1205c8c: mov             x1, #2
    // 0x1205c90: r0 = AllocateContext()
    //     0x1205c90: bl              #0x13de838  ; AllocateContextStub
    // 0x1205c94: mov             x3, x0
    // 0x1205c98: ldur            x2, [fp, #-8]
    // 0x1205c9c: stur            x3, [fp, #-0x18]
    // 0x1205ca0: StoreField: r3->field_f = r2
    //     0x1205ca0: stur            w2, [x3, #0xf]
    // 0x1205ca4: LoadField: r0 = r2->field_63
    //     0x1205ca4: ldur            w0, [x2, #0x63]
    // 0x1205ca8: DecompressPointer r0
    //     0x1205ca8: add             x0, x0, HEAP, lsl #32
    // 0x1205cac: cmp             w0, NULL
    // 0x1205cb0: b.eq            #0x1205dd4
    // 0x1205cb4: ldur            x4, [fp, #-0x10]
    // 0x1205cb8: r0 = LoadClassIdInstr(r4)
    //     0x1205cb8: ldur            x0, [x4, #-1]
    //     0x1205cbc: ubfx            x0, x0, #0xc, #0x14
    // 0x1205cc0: mov             x1, x4
    // 0x1205cc4: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x1205cc4: mov             x17, #0x6f9c
    //     0x1205cc8: movk            x17, #1, lsl #16
    //     0x1205ccc: add             lr, x0, x17
    //     0x1205cd0: ldr             lr, [x21, lr, lsl #3]
    //     0x1205cd4: blr             lr
    // 0x1205cd8: cmp             x0, #1
    // 0x1205cdc: b.ne            #0x1205dd4
    // 0x1205ce0: ldur            x3, [fp, #-0x10]
    // 0x1205ce4: ldur            x2, [fp, #-0x18]
    // 0x1205ce8: r0 = LoadClassIdInstr(r3)
    //     0x1205ce8: ldur            x0, [x3, #-1]
    //     0x1205cec: ubfx            x0, x0, #0xc, #0x14
    // 0x1205cf0: mov             x1, x3
    // 0x1205cf4: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x1205cf4: mov             x17, #0x3f27
    //     0x1205cf8: movk            x17, #1, lsl #16
    //     0x1205cfc: add             lr, x0, x17
    //     0x1205d00: ldr             lr, [x21, lr, lsl #3]
    //     0x1205d04: blr             lr
    // 0x1205d08: mov             x3, x0
    // 0x1205d0c: ldur            x2, [fp, #-0x10]
    // 0x1205d10: stur            x3, [fp, #-0x20]
    // 0x1205d14: r0 = LoadClassIdInstr(r2)
    //     0x1205d14: ldur            x0, [x2, #-1]
    //     0x1205d18: ubfx            x0, x0, #0xc, #0x14
    // 0x1205d1c: mov             x1, x2
    // 0x1205d20: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x1205d20: mov             x17, #0x54ea
    //     0x1205d24: movk            x17, #1, lsl #16
    //     0x1205d28: add             lr, x0, x17
    //     0x1205d2c: ldr             lr, [x21, lr, lsl #3]
    //     0x1205d30: blr             lr
    // 0x1205d34: ldur            x2, [fp, #-0x10]
    // 0x1205d38: r0 = LoadClassIdInstr(r2)
    //     0x1205d38: ldur            x0, [x2, #-1]
    //     0x1205d3c: ubfx            x0, x0, #0xc, #0x14
    // 0x1205d40: mov             x1, x2
    // 0x1205d44: r0 = GDT[cid_x0 + -0x1]()
    //     0x1205d44: sub             lr, x0, #1
    //     0x1205d48: ldr             lr, [x21, lr, lsl #3]
    //     0x1205d4c: blr             lr
    // 0x1205d50: ldur            x1, [fp, #-8]
    // 0x1205d54: mov             x2, x0
    // 0x1205d58: r0 = getKindForPointer()
    //     0x1205d58: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0x1205d5c: ldur            x1, [fp, #-0x10]
    // 0x1205d60: r0 = LoadClassIdInstr(r1)
    //     0x1205d60: ldur            x0, [x1, #-1]
    //     0x1205d64: ubfx            x0, x0, #0xc, #0x14
    // 0x1205d68: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0x1205d68: mov             x17, #0x5a8f
    //     0x1205d6c: movk            x17, #1, lsl #16
    //     0x1205d70: add             lr, x0, x17
    //     0x1205d74: ldr             lr, [x21, lr, lsl #3]
    //     0x1205d78: blr             lr
    // 0x1205d7c: r0 = TapMoveDetails()
    //     0x1205d7c: bl              #0x1205dec  ; AllocateTapMoveDetailsStub -> TapMoveDetails (size=0xc)
    // 0x1205d80: mov             x1, x0
    // 0x1205d84: ldur            x0, [fp, #-0x20]
    // 0x1205d88: StoreField: r1->field_7 = r0
    //     0x1205d88: stur            w0, [x1, #7]
    // 0x1205d8c: mov             x0, x1
    // 0x1205d90: ldur            x2, [fp, #-0x18]
    // 0x1205d94: StoreField: r2->field_13 = r0
    //     0x1205d94: stur            w0, [x2, #0x13]
    //     0x1205d98: ldurb           w16, [x2, #-1]
    //     0x1205d9c: ldurb           w17, [x0, #-1]
    //     0x1205da0: and             x16, x17, x16, lsr #2
    //     0x1205da4: tst             x16, HEAP, lsr #32
    //     0x1205da8: b.eq            #0x1205db0
    //     0x1205dac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1205db0: r1 = Function '<anonymous closure>':.
    //     0x1205db0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4048] AnonymousClosure: (0x1205df8), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapMove (0x1205c64)
    //     0x1205db4: ldr             x1, [x1, #0x48]
    // 0x1205db8: r0 = AllocateClosure()
    //     0x1205db8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1205dbc: r16 = <void?>
    //     0x1205dbc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x1205dc0: ldur            lr, [fp, #-8]
    // 0x1205dc4: stp             lr, x16, [SP, #8]
    // 0x1205dc8: str             x0, [SP]
    // 0x1205dcc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1205dcc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1205dd0: r0 = invokeCallback()
    //     0x1205dd0: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x1205dd4: r0 = Null
    //     0x1205dd4: mov             x0, NULL
    // 0x1205dd8: LeaveFrame
    //     0x1205dd8: mov             SP, fp
    //     0x1205ddc: ldp             fp, lr, [SP], #0x10
    // 0x1205de0: ret
    //     0x1205de0: ret             
    // 0x1205de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1205de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1205de8: b               #0x1205c8c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x1205df8, size: 0x6c
    // 0x1205df8: EnterFrame
    //     0x1205df8: stp             fp, lr, [SP, #-0x10]!
    //     0x1205dfc: mov             fp, SP
    // 0x1205e00: ldr             x0, [fp, #0x10]
    // 0x1205e04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1205e04: ldur            w1, [x0, #0x17]
    // 0x1205e08: DecompressPointer r1
    //     0x1205e08: add             x1, x1, HEAP, lsl #32
    // 0x1205e0c: CheckStackOverflow
    //     0x1205e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1205e10: cmp             SP, x16
    //     0x1205e14: b.ls            #0x1205e58
    // 0x1205e18: LoadField: r0 = r1->field_f
    //     0x1205e18: ldur            w0, [x1, #0xf]
    // 0x1205e1c: DecompressPointer r0
    //     0x1205e1c: add             x0, x0, HEAP, lsl #32
    // 0x1205e20: LoadField: r2 = r0->field_63
    //     0x1205e20: ldur            w2, [x0, #0x63]
    // 0x1205e24: DecompressPointer r2
    //     0x1205e24: add             x2, x2, HEAP, lsl #32
    // 0x1205e28: cmp             w2, NULL
    // 0x1205e2c: b.eq            #0x1205e60
    // 0x1205e30: LoadField: r0 = r1->field_13
    //     0x1205e30: ldur            w0, [x1, #0x13]
    // 0x1205e34: DecompressPointer r0
    //     0x1205e34: add             x0, x0, HEAP, lsl #32
    // 0x1205e38: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1205e38: ldur            w1, [x2, #0x17]
    // 0x1205e3c: DecompressPointer r1
    //     0x1205e3c: add             x1, x1, HEAP, lsl #32
    // 0x1205e40: mov             x2, x0
    // 0x1205e44: r0 = _handleTapMove()
    //     0x1205e44: bl              #0xd7512c  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapMove
    // 0x1205e48: r0 = Null
    //     0x1205e48: mov             x0, NULL
    // 0x1205e4c: LeaveFrame
    //     0x1205e4c: mov             SP, fp
    //     0x1205e50: ldp             fp, lr, [SP], #0x10
    // 0x1205e54: ret
    //     0x1205e54: ret             
    // 0x1205e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1205e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1205e5c: b               #0x1205e18
    // 0x1205e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1205e60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5218, size: 0xc, field offset: 0x8
class TapUpDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5219, size: 0x14, field offset: 0x8
class TapDownDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}
