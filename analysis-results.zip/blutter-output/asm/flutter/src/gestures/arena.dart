// lib: , url: package:flutter/src/gestures/arena.dart

// class id: 1048815, size: 0x8
class :: {
}

// class id: 3182, size: 0xc, field offset: 0x8
class GestureArenaManager extends Object {

  _ add(/* No info */) {
    // ** addr: 0xba8eac, size: 0x12c
    // 0xba8eac: EnterFrame
    //     0xba8eac: stp             fp, lr, [SP, #-0x10]!
    //     0xba8eb0: mov             fp, SP
    // 0xba8eb4: AllocStack(0x30)
    //     0xba8eb4: sub             SP, SP, #0x30
    // 0xba8eb8: SetupParameters(GestureArenaManager this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r4, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0xba8eb8: mov             x5, x1
    //     0xba8ebc: mov             x4, x2
    //     0xba8ec0: stur            x1, [fp, #-0x18]
    //     0xba8ec4: stur            x2, [fp, #-0x20]
    //     0xba8ec8: stur            x3, [fp, #-0x28]
    // 0xba8ecc: CheckStackOverflow
    //     0xba8ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8ed0: cmp             SP, x16
    //     0xba8ed4: b.ls            #0xba8fd0
    // 0xba8ed8: LoadField: r6 = r5->field_7
    //     0xba8ed8: ldur            w6, [x5, #7]
    // 0xba8edc: DecompressPointer r6
    //     0xba8edc: add             x6, x6, HEAP, lsl #32
    // 0xba8ee0: stur            x6, [fp, #-0x10]
    // 0xba8ee4: r0 = BoxInt64Instr(r4)
    //     0xba8ee4: sbfiz           x0, x4, #1, #0x1f
    //     0xba8ee8: cmp             x4, x0, asr #1
    //     0xba8eec: b.eq            #0xba8ef8
    //     0xba8ef0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba8ef4: stur            x4, [x0, #7]
    // 0xba8ef8: r1 = Function '<anonymous closure>':.
    //     0xba8ef8: add             x1, PP, #0x96, lsl #12  ; [pp+0x960d0] AnonymousClosure: (0xba8fe4), in [package:flutter/src/gestures/arena.dart] GestureArenaManager::add (0xba8eac)
    //     0xba8efc: ldr             x1, [x1, #0xd0]
    // 0xba8f00: r2 = Null
    //     0xba8f00: mov             x2, NULL
    // 0xba8f04: stur            x0, [fp, #-8]
    // 0xba8f08: r0 = AllocateClosure()
    //     0xba8f08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba8f0c: ldur            x1, [fp, #-0x10]
    // 0xba8f10: ldur            x2, [fp, #-8]
    // 0xba8f14: mov             x3, x0
    // 0xba8f18: r0 = putIfAbsent()
    //     0xba8f18: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xba8f1c: LoadField: r2 = r0->field_7
    //     0xba8f1c: ldur            w2, [x0, #7]
    // 0xba8f20: DecompressPointer r2
    //     0xba8f20: add             x2, x2, HEAP, lsl #32
    // 0xba8f24: stur            x2, [fp, #-8]
    // 0xba8f28: LoadField: r0 = r2->field_b
    //     0xba8f28: ldur            w0, [x2, #0xb]
    // 0xba8f2c: LoadField: r1 = r2->field_f
    //     0xba8f2c: ldur            w1, [x2, #0xf]
    // 0xba8f30: DecompressPointer r1
    //     0xba8f30: add             x1, x1, HEAP, lsl #32
    // 0xba8f34: LoadField: r3 = r1->field_b
    //     0xba8f34: ldur            w3, [x1, #0xb]
    // 0xba8f38: r4 = LoadInt32Instr(r0)
    //     0xba8f38: sbfx            x4, x0, #1, #0x1f
    // 0xba8f3c: stur            x4, [fp, #-0x30]
    // 0xba8f40: r0 = LoadInt32Instr(r3)
    //     0xba8f40: sbfx            x0, x3, #1, #0x1f
    // 0xba8f44: cmp             x4, x0
    // 0xba8f48: b.ne            #0xba8f54
    // 0xba8f4c: mov             x1, x2
    // 0xba8f50: r0 = _growToNextCapacity()
    //     0xba8f50: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xba8f54: ldur            x5, [fp, #-0x18]
    // 0xba8f58: ldur            x4, [fp, #-0x20]
    // 0xba8f5c: ldur            x3, [fp, #-0x28]
    // 0xba8f60: ldur            x0, [fp, #-8]
    // 0xba8f64: ldur            x2, [fp, #-0x30]
    // 0xba8f68: add             x1, x2, #1
    // 0xba8f6c: lsl             x6, x1, #1
    // 0xba8f70: StoreField: r0->field_b = r6
    //     0xba8f70: stur            w6, [x0, #0xb]
    // 0xba8f74: LoadField: r1 = r0->field_f
    //     0xba8f74: ldur            w1, [x0, #0xf]
    // 0xba8f78: DecompressPointer r1
    //     0xba8f78: add             x1, x1, HEAP, lsl #32
    // 0xba8f7c: mov             x0, x3
    // 0xba8f80: ArrayStore: r1[r2] = r0  ; List_4
    //     0xba8f80: add             x25, x1, x2, lsl #2
    //     0xba8f84: add             x25, x25, #0xf
    //     0xba8f88: str             w0, [x25]
    //     0xba8f8c: tbz             w0, #0, #0xba8fa8
    //     0xba8f90: ldurb           w16, [x1, #-1]
    //     0xba8f94: ldurb           w17, [x0, #-1]
    //     0xba8f98: and             x16, x17, x16, lsr #2
    //     0xba8f9c: tst             x16, HEAP, lsr #32
    //     0xba8fa0: b.eq            #0xba8fa8
    //     0xba8fa4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba8fa8: r0 = GestureArenaEntry()
    //     0xba8fa8: bl              #0xba8fd8  ; AllocateGestureArenaEntryStub -> GestureArenaEntry (size=0x18)
    // 0xba8fac: ldur            x1, [fp, #-0x18]
    // 0xba8fb0: StoreField: r0->field_7 = r1
    //     0xba8fb0: stur            w1, [x0, #7]
    // 0xba8fb4: ldur            x1, [fp, #-0x20]
    // 0xba8fb8: StoreField: r0->field_b = r1
    //     0xba8fb8: stur            x1, [x0, #0xb]
    // 0xba8fbc: ldur            x1, [fp, #-0x28]
    // 0xba8fc0: StoreField: r0->field_13 = r1
    //     0xba8fc0: stur            w1, [x0, #0x13]
    // 0xba8fc4: LeaveFrame
    //     0xba8fc4: mov             SP, fp
    //     0xba8fc8: ldp             fp, lr, [SP], #0x10
    // 0xba8fcc: ret
    //     0xba8fcc: ret             
    // 0xba8fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8fd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8fd4: b               #0xba8ed8
  }
  [closure] _GestureArena <anonymous closure>(dynamic) {
    // ** addr: 0xba8fe4, size: 0x80
    // 0xba8fe4: EnterFrame
    //     0xba8fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xba8fe8: mov             fp, SP
    // 0xba8fec: AllocStack(0x8)
    //     0xba8fec: sub             SP, SP, #8
    // 0xba8ff0: CheckStackOverflow
    //     0xba8ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8ff4: cmp             SP, x16
    //     0xba8ff8: b.ls            #0xba905c
    // 0xba8ffc: r0 = _GestureArena()
    //     0xba8ffc: bl              #0xba9064  ; Allocate_GestureArenaStub -> _GestureArena (size=0x1c)
    // 0xba9000: mov             x3, x0
    // 0xba9004: r0 = true
    //     0xba9004: add             x0, NULL, #0x20  ; true
    // 0xba9008: stur            x3, [fp, #-8]
    // 0xba900c: StoreField: r3->field_b = r0
    //     0xba900c: stur            w0, [x3, #0xb]
    // 0xba9010: r0 = false
    //     0xba9010: add             x0, NULL, #0x30  ; false
    // 0xba9014: StoreField: r3->field_f = r0
    //     0xba9014: stur            w0, [x3, #0xf]
    // 0xba9018: StoreField: r3->field_13 = r0
    //     0xba9018: stur            w0, [x3, #0x13]
    // 0xba901c: r1 = <GestureArenaMember>
    //     0xba901c: add             x1, PP, #0x96, lsl #12  ; [pp+0x960d8] TypeArguments: <GestureArenaMember>
    //     0xba9020: ldr             x1, [x1, #0xd8]
    // 0xba9024: r2 = 0
    //     0xba9024: mov             x2, #0
    // 0xba9028: r0 = _GrowableList()
    //     0xba9028: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xba902c: ldur            x1, [fp, #-8]
    // 0xba9030: StoreField: r1->field_7 = r0
    //     0xba9030: stur            w0, [x1, #7]
    //     0xba9034: ldurb           w16, [x1, #-1]
    //     0xba9038: ldurb           w17, [x0, #-1]
    //     0xba903c: and             x16, x17, x16, lsr #2
    //     0xba9040: tst             x16, HEAP, lsr #32
    //     0xba9044: b.eq            #0xba904c
    //     0xba9048: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba904c: mov             x0, x1
    // 0xba9050: LeaveFrame
    //     0xba9050: mov             SP, fp
    //     0xba9054: ldp             fp, lr, [SP], #0x10
    // 0xba9058: ret
    //     0xba9058: ret             
    // 0xba905c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba905c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9060: b               #0xba8ffc
  }
  _ hold(/* No info */) {
    // ** addr: 0xba981c, size: 0x9c
    // 0xba981c: EnterFrame
    //     0xba981c: stp             fp, lr, [SP, #-0x10]!
    //     0xba9820: mov             fp, SP
    // 0xba9824: AllocStack(0x8)
    //     0xba9824: sub             SP, SP, #8
    // 0xba9828: CheckStackOverflow
    //     0xba9828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba982c: cmp             SP, x16
    //     0xba9830: b.ls            #0xba98b0
    // 0xba9834: LoadField: r3 = r1->field_7
    //     0xba9834: ldur            w3, [x1, #7]
    // 0xba9838: DecompressPointer r3
    //     0xba9838: add             x3, x3, HEAP, lsl #32
    // 0xba983c: stur            x3, [fp, #-8]
    // 0xba9840: r0 = BoxInt64Instr(r2)
    //     0xba9840: sbfiz           x0, x2, #1, #0x1f
    //     0xba9844: cmp             x2, x0, asr #1
    //     0xba9848: b.eq            #0xba9854
    //     0xba984c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba9850: stur            x2, [x0, #7]
    // 0xba9854: mov             x1, x3
    // 0xba9858: mov             x2, x0
    // 0xba985c: r0 = _getValueOrData()
    //     0xba985c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba9860: ldur            x1, [fp, #-8]
    // 0xba9864: LoadField: r2 = r1->field_f
    //     0xba9864: ldur            w2, [x1, #0xf]
    // 0xba9868: DecompressPointer r2
    //     0xba9868: add             x2, x2, HEAP, lsl #32
    // 0xba986c: cmp             w2, w0
    // 0xba9870: b.ne            #0xba987c
    // 0xba9874: r1 = Null
    //     0xba9874: mov             x1, NULL
    // 0xba9878: b               #0xba9880
    // 0xba987c: mov             x1, x0
    // 0xba9880: cmp             w1, NULL
    // 0xba9884: b.ne            #0xba9898
    // 0xba9888: r0 = Null
    //     0xba9888: mov             x0, NULL
    // 0xba988c: LeaveFrame
    //     0xba988c: mov             SP, fp
    //     0xba9890: ldp             fp, lr, [SP], #0x10
    // 0xba9894: ret
    //     0xba9894: ret             
    // 0xba9898: r2 = true
    //     0xba9898: add             x2, NULL, #0x20  ; true
    // 0xba989c: StoreField: r1->field_f = r2
    //     0xba989c: stur            w2, [x1, #0xf]
    // 0xba98a0: r0 = Null
    //     0xba98a0: mov             x0, NULL
    // 0xba98a4: LeaveFrame
    //     0xba98a4: mov             SP, fp
    //     0xba98a8: ldp             fp, lr, [SP], #0x10
    // 0xba98ac: ret
    //     0xba98ac: ret             
    // 0xba98b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba98b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba98b4: b               #0xba9834
  }
  _ release(/* No info */) {
    // ** addr: 0xba9a54, size: 0xc8
    // 0xba9a54: EnterFrame
    //     0xba9a54: stp             fp, lr, [SP, #-0x10]!
    //     0xba9a58: mov             fp, SP
    // 0xba9a5c: AllocStack(0x18)
    //     0xba9a5c: sub             SP, SP, #0x18
    // 0xba9a60: SetupParameters(GestureArenaManager this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xba9a60: mov             x4, x1
    //     0xba9a64: mov             x3, x2
    //     0xba9a68: stur            x1, [fp, #-0x10]
    //     0xba9a6c: stur            x2, [fp, #-0x18]
    // 0xba9a70: CheckStackOverflow
    //     0xba9a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9a74: cmp             SP, x16
    //     0xba9a78: b.ls            #0xba9b14
    // 0xba9a7c: LoadField: r5 = r4->field_7
    //     0xba9a7c: ldur            w5, [x4, #7]
    // 0xba9a80: DecompressPointer r5
    //     0xba9a80: add             x5, x5, HEAP, lsl #32
    // 0xba9a84: stur            x5, [fp, #-8]
    // 0xba9a88: r0 = BoxInt64Instr(r3)
    //     0xba9a88: sbfiz           x0, x3, #1, #0x1f
    //     0xba9a8c: cmp             x3, x0, asr #1
    //     0xba9a90: b.eq            #0xba9a9c
    //     0xba9a94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba9a98: stur            x3, [x0, #7]
    // 0xba9a9c: mov             x1, x5
    // 0xba9aa0: mov             x2, x0
    // 0xba9aa4: r0 = _getValueOrData()
    //     0xba9aa4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba9aa8: mov             x1, x0
    // 0xba9aac: ldur            x0, [fp, #-8]
    // 0xba9ab0: LoadField: r2 = r0->field_f
    //     0xba9ab0: ldur            w2, [x0, #0xf]
    // 0xba9ab4: DecompressPointer r2
    //     0xba9ab4: add             x2, x2, HEAP, lsl #32
    // 0xba9ab8: cmp             w2, w1
    // 0xba9abc: b.ne            #0xba9ac8
    // 0xba9ac0: r0 = Null
    //     0xba9ac0: mov             x0, NULL
    // 0xba9ac4: b               #0xba9acc
    // 0xba9ac8: mov             x0, x1
    // 0xba9acc: cmp             w0, NULL
    // 0xba9ad0: b.ne            #0xba9ae4
    // 0xba9ad4: r0 = Null
    //     0xba9ad4: mov             x0, NULL
    // 0xba9ad8: LeaveFrame
    //     0xba9ad8: mov             SP, fp
    //     0xba9adc: ldp             fp, lr, [SP], #0x10
    // 0xba9ae0: ret
    //     0xba9ae0: ret             
    // 0xba9ae4: r1 = false
    //     0xba9ae4: add             x1, NULL, #0x30  ; false
    // 0xba9ae8: StoreField: r0->field_f = r1
    //     0xba9ae8: stur            w1, [x0, #0xf]
    // 0xba9aec: LoadField: r1 = r0->field_13
    //     0xba9aec: ldur            w1, [x0, #0x13]
    // 0xba9af0: DecompressPointer r1
    //     0xba9af0: add             x1, x1, HEAP, lsl #32
    // 0xba9af4: tbnz            w1, #4, #0xba9b04
    // 0xba9af8: ldur            x1, [fp, #-0x10]
    // 0xba9afc: ldur            x2, [fp, #-0x18]
    // 0xba9b00: r0 = sweep()
    //     0xba9b00: bl              #0xba9b1c  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::sweep
    // 0xba9b04: r0 = Null
    //     0xba9b04: mov             x0, NULL
    // 0xba9b08: LeaveFrame
    //     0xba9b08: mov             SP, fp
    //     0xba9b0c: ldp             fp, lr, [SP], #0x10
    // 0xba9b10: ret
    //     0xba9b10: ret             
    // 0xba9b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9b14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9b18: b               #0xba9a7c
  }
  _ sweep(/* No info */) {
    // ** addr: 0xba9b1c, size: 0x17c
    // 0xba9b1c: EnterFrame
    //     0xba9b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xba9b20: mov             fp, SP
    // 0xba9b24: AllocStack(0x28)
    //     0xba9b24: sub             SP, SP, #0x28
    // 0xba9b28: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xba9b28: mov             x3, x2
    //     0xba9b2c: stur            x2, [fp, #-0x18]
    // 0xba9b30: CheckStackOverflow
    //     0xba9b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9b34: cmp             SP, x16
    //     0xba9b38: b.ls            #0xba9c88
    // 0xba9b3c: LoadField: r4 = r1->field_7
    //     0xba9b3c: ldur            w4, [x1, #7]
    // 0xba9b40: DecompressPointer r4
    //     0xba9b40: add             x4, x4, HEAP, lsl #32
    // 0xba9b44: stur            x4, [fp, #-0x10]
    // 0xba9b48: r0 = BoxInt64Instr(r3)
    //     0xba9b48: sbfiz           x0, x3, #1, #0x1f
    //     0xba9b4c: cmp             x3, x0, asr #1
    //     0xba9b50: b.eq            #0xba9b5c
    //     0xba9b54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba9b58: stur            x3, [x0, #7]
    // 0xba9b5c: mov             x1, x4
    // 0xba9b60: mov             x2, x0
    // 0xba9b64: stur            x0, [fp, #-8]
    // 0xba9b68: r0 = _getValueOrData()
    //     0xba9b68: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba9b6c: ldur            x1, [fp, #-0x10]
    // 0xba9b70: LoadField: r2 = r1->field_f
    //     0xba9b70: ldur            w2, [x1, #0xf]
    // 0xba9b74: DecompressPointer r2
    //     0xba9b74: add             x2, x2, HEAP, lsl #32
    // 0xba9b78: cmp             w2, w0
    // 0xba9b7c: b.ne            #0xba9b84
    // 0xba9b80: r0 = Null
    //     0xba9b80: mov             x0, NULL
    // 0xba9b84: stur            x0, [fp, #-0x20]
    // 0xba9b88: cmp             w0, NULL
    // 0xba9b8c: b.ne            #0xba9ba0
    // 0xba9b90: r0 = Null
    //     0xba9b90: mov             x0, NULL
    // 0xba9b94: LeaveFrame
    //     0xba9b94: mov             SP, fp
    //     0xba9b98: ldp             fp, lr, [SP], #0x10
    // 0xba9b9c: ret
    //     0xba9b9c: ret             
    // 0xba9ba0: LoadField: r2 = r0->field_f
    //     0xba9ba0: ldur            w2, [x0, #0xf]
    // 0xba9ba4: DecompressPointer r2
    //     0xba9ba4: add             x2, x2, HEAP, lsl #32
    // 0xba9ba8: tbnz            w2, #4, #0xba9bc4
    // 0xba9bac: r1 = true
    //     0xba9bac: add             x1, NULL, #0x20  ; true
    // 0xba9bb0: StoreField: r0->field_13 = r1
    //     0xba9bb0: stur            w1, [x0, #0x13]
    // 0xba9bb4: r0 = Null
    //     0xba9bb4: mov             x0, NULL
    // 0xba9bb8: LeaveFrame
    //     0xba9bb8: mov             SP, fp
    //     0xba9bbc: ldp             fp, lr, [SP], #0x10
    // 0xba9bc0: ret
    //     0xba9bc0: ret             
    // 0xba9bc4: ldur            x2, [fp, #-8]
    // 0xba9bc8: r0 = remove()
    //     0xba9bc8: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba9bcc: ldur            x0, [fp, #-0x20]
    // 0xba9bd0: LoadField: r2 = r0->field_7
    //     0xba9bd0: ldur            w2, [x0, #7]
    // 0xba9bd4: DecompressPointer r2
    //     0xba9bd4: add             x2, x2, HEAP, lsl #32
    // 0xba9bd8: stur            x2, [fp, #-8]
    // 0xba9bdc: LoadField: r0 = r2->field_b
    //     0xba9bdc: ldur            w0, [x2, #0xb]
    // 0xba9be0: cbz             w0, #0xba9c78
    // 0xba9be4: mov             x1, x2
    // 0xba9be8: r0 = first()
    //     0xba9be8: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0xba9bec: r1 = LoadClassIdInstr(r0)
    //     0xba9bec: ldur            x1, [x0, #-1]
    //     0xba9bf0: ubfx            x1, x1, #0xc, #0x14
    // 0xba9bf4: mov             x16, x0
    // 0xba9bf8: mov             x0, x1
    // 0xba9bfc: mov             x1, x16
    // 0xba9c00: ldur            x2, [fp, #-0x18]
    // 0xba9c04: r0 = GDT[cid_x0 + 0x2d08]()
    //     0xba9c04: mov             x17, #0x2d08
    //     0xba9c08: add             lr, x0, x17
    //     0xba9c0c: ldr             lr, [x21, lr, lsl #3]
    //     0xba9c10: blr             lr
    // 0xba9c14: r4 = 1
    //     0xba9c14: mov             x4, #1
    // 0xba9c18: ldur            x3, [fp, #-8]
    // 0xba9c1c: stur            x4, [fp, #-0x28]
    // 0xba9c20: CheckStackOverflow
    //     0xba9c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9c24: cmp             SP, x16
    //     0xba9c28: b.ls            #0xba9c90
    // 0xba9c2c: LoadField: r0 = r3->field_b
    //     0xba9c2c: ldur            w0, [x3, #0xb]
    // 0xba9c30: r1 = LoadInt32Instr(r0)
    //     0xba9c30: sbfx            x1, x0, #1, #0x1f
    // 0xba9c34: cmp             x4, x1
    // 0xba9c38: b.ge            #0xba9c78
    // 0xba9c3c: LoadField: r0 = r3->field_f
    //     0xba9c3c: ldur            w0, [x3, #0xf]
    // 0xba9c40: DecompressPointer r0
    //     0xba9c40: add             x0, x0, HEAP, lsl #32
    // 0xba9c44: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xba9c44: add             x16, x0, x4, lsl #2
    //     0xba9c48: ldur            w1, [x16, #0xf]
    // 0xba9c4c: DecompressPointer r1
    //     0xba9c4c: add             x1, x1, HEAP, lsl #32
    // 0xba9c50: r0 = LoadClassIdInstr(r1)
    //     0xba9c50: ldur            x0, [x1, #-1]
    //     0xba9c54: ubfx            x0, x0, #0xc, #0x14
    // 0xba9c58: ldur            x2, [fp, #-0x18]
    // 0xba9c5c: r0 = GDT[cid_x0 + 0x4deb]()
    //     0xba9c5c: mov             x17, #0x4deb
    //     0xba9c60: add             lr, x0, x17
    //     0xba9c64: ldr             lr, [x21, lr, lsl #3]
    //     0xba9c68: blr             lr
    // 0xba9c6c: ldur            x1, [fp, #-0x28]
    // 0xba9c70: add             x4, x1, #1
    // 0xba9c74: b               #0xba9c18
    // 0xba9c78: r0 = Null
    //     0xba9c78: mov             x0, NULL
    // 0xba9c7c: LeaveFrame
    //     0xba9c7c: mov             SP, fp
    //     0xba9c80: ldp             fp, lr, [SP], #0x10
    // 0xba9c84: ret
    //     0xba9c84: ret             
    // 0xba9c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9c8c: b               #0xba9b3c
    // 0xba9c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9c90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9c94: b               #0xba9c2c
  }
  _ close(/* No info */) {
    // ** addr: 0xce0f94, size: 0xbc
    // 0xce0f94: EnterFrame
    //     0xce0f94: stp             fp, lr, [SP, #-0x10]!
    //     0xce0f98: mov             fp, SP
    // 0xce0f9c: AllocStack(0x18)
    //     0xce0f9c: sub             SP, SP, #0x18
    // 0xce0fa0: SetupParameters(GestureArenaManager this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xce0fa0: mov             x4, x1
    //     0xce0fa4: mov             x3, x2
    //     0xce0fa8: stur            x1, [fp, #-0x10]
    //     0xce0fac: stur            x2, [fp, #-0x18]
    // 0xce0fb0: CheckStackOverflow
    //     0xce0fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce0fb4: cmp             SP, x16
    //     0xce0fb8: b.ls            #0xce1048
    // 0xce0fbc: LoadField: r5 = r4->field_7
    //     0xce0fbc: ldur            w5, [x4, #7]
    // 0xce0fc0: DecompressPointer r5
    //     0xce0fc0: add             x5, x5, HEAP, lsl #32
    // 0xce0fc4: stur            x5, [fp, #-8]
    // 0xce0fc8: r0 = BoxInt64Instr(r3)
    //     0xce0fc8: sbfiz           x0, x3, #1, #0x1f
    //     0xce0fcc: cmp             x3, x0, asr #1
    //     0xce0fd0: b.eq            #0xce0fdc
    //     0xce0fd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce0fd8: stur            x3, [x0, #7]
    // 0xce0fdc: mov             x1, x5
    // 0xce0fe0: mov             x2, x0
    // 0xce0fe4: r0 = _getValueOrData()
    //     0xce0fe4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xce0fe8: mov             x1, x0
    // 0xce0fec: ldur            x0, [fp, #-8]
    // 0xce0ff0: LoadField: r2 = r0->field_f
    //     0xce0ff0: ldur            w2, [x0, #0xf]
    // 0xce0ff4: DecompressPointer r2
    //     0xce0ff4: add             x2, x2, HEAP, lsl #32
    // 0xce0ff8: cmp             w2, w1
    // 0xce0ffc: b.ne            #0xce1008
    // 0xce1000: r3 = Null
    //     0xce1000: mov             x3, NULL
    // 0xce1004: b               #0xce100c
    // 0xce1008: mov             x3, x1
    // 0xce100c: cmp             w3, NULL
    // 0xce1010: b.ne            #0xce1024
    // 0xce1014: r0 = Null
    //     0xce1014: mov             x0, NULL
    // 0xce1018: LeaveFrame
    //     0xce1018: mov             SP, fp
    //     0xce101c: ldp             fp, lr, [SP], #0x10
    // 0xce1020: ret
    //     0xce1020: ret             
    // 0xce1024: r0 = false
    //     0xce1024: add             x0, NULL, #0x30  ; false
    // 0xce1028: StoreField: r3->field_b = r0
    //     0xce1028: stur            w0, [x3, #0xb]
    // 0xce102c: ldur            x1, [fp, #-0x10]
    // 0xce1030: ldur            x2, [fp, #-0x18]
    // 0xce1034: r0 = _tryToResolveArena()
    //     0xce1034: bl              #0xce1050  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena
    // 0xce1038: r0 = Null
    //     0xce1038: mov             x0, NULL
    // 0xce103c: LeaveFrame
    //     0xce103c: mov             SP, fp
    //     0xce1040: ldp             fp, lr, [SP], #0x10
    // 0xce1044: ret
    //     0xce1044: ret             
    // 0xce1048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce104c: b               #0xce0fbc
  }
  _ _tryToResolveArena(/* No info */) {
    // ** addr: 0xce1050, size: 0xdc
    // 0xce1050: EnterFrame
    //     0xce1050: stp             fp, lr, [SP, #-0x10]!
    //     0xce1054: mov             fp, SP
    // 0xce1058: AllocStack(0x20)
    //     0xce1058: sub             SP, SP, #0x20
    // 0xce105c: SetupParameters(GestureArenaManager this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xce105c: stur            x1, [fp, #-8]
    //     0xce1060: stur            x2, [fp, #-0x10]
    //     0xce1064: stur            x3, [fp, #-0x18]
    // 0xce1068: CheckStackOverflow
    //     0xce1068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce106c: cmp             SP, x16
    //     0xce1070: b.ls            #0xce1124
    // 0xce1074: r1 = 3
    //     0xce1074: mov             x1, #3
    // 0xce1078: r0 = AllocateContext()
    //     0xce1078: bl              #0x13de838  ; AllocateContextStub
    // 0xce107c: mov             x3, x0
    // 0xce1080: ldur            x2, [fp, #-8]
    // 0xce1084: StoreField: r3->field_f = r2
    //     0xce1084: stur            w2, [x3, #0xf]
    // 0xce1088: ldur            x4, [fp, #-0x10]
    // 0xce108c: r0 = BoxInt64Instr(r4)
    //     0xce108c: sbfiz           x0, x4, #1, #0x1f
    //     0xce1090: cmp             x4, x0, asr #1
    //     0xce1094: b.eq            #0xce10a0
    //     0xce1098: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce109c: stur            x4, [x0, #7]
    // 0xce10a0: StoreField: r3->field_13 = r0
    //     0xce10a0: stur            w0, [x3, #0x13]
    // 0xce10a4: ldur            x1, [fp, #-0x18]
    // 0xce10a8: ArrayStore: r3[0] = r1  ; List_4
    //     0xce10a8: stur            w1, [x3, #0x17]
    // 0xce10ac: LoadField: r5 = r1->field_7
    //     0xce10ac: ldur            w5, [x1, #7]
    // 0xce10b0: DecompressPointer r5
    //     0xce10b0: add             x5, x5, HEAP, lsl #32
    // 0xce10b4: LoadField: r6 = r5->field_b
    //     0xce10b4: ldur            w6, [x5, #0xb]
    // 0xce10b8: cmp             w6, #2
    // 0xce10bc: b.ne            #0xce10dc
    // 0xce10c0: mov             x2, x3
    // 0xce10c4: r1 = Function '<anonymous closure>':.
    //     0xce10c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3b0] AnonymousClosure: (0xce1280), in [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena (0xce1050)
    //     0xce10c8: ldr             x1, [x1, #0x3b0]
    // 0xce10cc: r0 = AllocateClosure()
    //     0xce10cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce10d0: str             x0, [SP]
    // 0xce10d4: r0 = scheduleMicrotask()
    //     0xce10d4: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0xce10d8: b               #0xce1114
    // 0xce10dc: cbnz            w6, #0xce10f4
    // 0xce10e0: LoadField: r1 = r2->field_7
    //     0xce10e0: ldur            w1, [x2, #7]
    // 0xce10e4: DecompressPointer r1
    //     0xce10e4: add             x1, x1, HEAP, lsl #32
    // 0xce10e8: mov             x2, x0
    // 0xce10ec: r0 = remove()
    //     0xce10ec: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xce10f0: b               #0xce1114
    // 0xce10f4: ArrayLoad: r5 = r1[0]  ; List_4
    //     0xce10f4: ldur            w5, [x1, #0x17]
    // 0xce10f8: DecompressPointer r5
    //     0xce10f8: add             x5, x5, HEAP, lsl #32
    // 0xce10fc: cmp             w5, NULL
    // 0xce1100: b.eq            #0xce1114
    // 0xce1104: mov             x3, x1
    // 0xce1108: mov             x1, x2
    // 0xce110c: mov             x2, x4
    // 0xce1110: r0 = _resolveInFavorOf()
    //     0xce1110: bl              #0xce112c  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveInFavorOf
    // 0xce1114: r0 = Null
    //     0xce1114: mov             x0, NULL
    // 0xce1118: LeaveFrame
    //     0xce1118: mov             SP, fp
    //     0xce111c: ldp             fp, lr, [SP], #0x10
    // 0xce1120: ret
    //     0xce1120: ret             
    // 0xce1124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1128: b               #0xce1074
  }
  _ _resolveInFavorOf(/* No info */) {
    // ** addr: 0xce112c, size: 0x154
    // 0xce112c: EnterFrame
    //     0xce112c: stp             fp, lr, [SP, #-0x10]!
    //     0xce1130: mov             fp, SP
    // 0xce1134: AllocStack(0x30)
    //     0xce1134: sub             SP, SP, #0x30
    // 0xce1138: SetupParameters(dynamic _ /* r2 => r5, fp-0x8 */, dynamic _ /* r3 => r4, fp-0x10 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0xce1138: mov             x4, x3
    //     0xce113c: stur            x3, [fp, #-0x10]
    //     0xce1140: mov             x3, x5
    //     0xce1144: stur            x5, [fp, #-0x18]
    //     0xce1148: mov             x5, x2
    //     0xce114c: stur            x2, [fp, #-8]
    // 0xce1150: CheckStackOverflow
    //     0xce1150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1154: cmp             SP, x16
    //     0xce1158: b.ls            #0xce1270
    // 0xce115c: LoadField: r2 = r1->field_7
    //     0xce115c: ldur            w2, [x1, #7]
    // 0xce1160: DecompressPointer r2
    //     0xce1160: add             x2, x2, HEAP, lsl #32
    // 0xce1164: r0 = BoxInt64Instr(r5)
    //     0xce1164: sbfiz           x0, x5, #1, #0x1f
    //     0xce1168: cmp             x5, x0, asr #1
    //     0xce116c: b.eq            #0xce1178
    //     0xce1170: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce1174: stur            x5, [x0, #7]
    // 0xce1178: mov             x1, x2
    // 0xce117c: mov             x2, x0
    // 0xce1180: r0 = remove()
    //     0xce1180: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xce1184: ldur            x0, [fp, #-0x10]
    // 0xce1188: LoadField: r3 = r0->field_7
    //     0xce1188: ldur            w3, [x0, #7]
    // 0xce118c: DecompressPointer r3
    //     0xce118c: add             x3, x3, HEAP, lsl #32
    // 0xce1190: stur            x3, [fp, #-0x30]
    // 0xce1194: LoadField: r0 = r3->field_b
    //     0xce1194: ldur            w0, [x3, #0xb]
    // 0xce1198: r4 = LoadInt32Instr(r0)
    //     0xce1198: sbfx            x4, x0, #1, #0x1f
    // 0xce119c: stur            x4, [fp, #-0x28]
    // 0xce11a0: r0 = 0
    //     0xce11a0: mov             x0, #0
    // 0xce11a4: ldur            x5, [fp, #-0x18]
    // 0xce11a8: CheckStackOverflow
    //     0xce11a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce11ac: cmp             SP, x16
    //     0xce11b0: b.ls            #0xce1278
    // 0xce11b4: LoadField: r1 = r3->field_b
    //     0xce11b4: ldur            w1, [x3, #0xb]
    // 0xce11b8: r2 = LoadInt32Instr(r1)
    //     0xce11b8: sbfx            x2, x1, #1, #0x1f
    // 0xce11bc: cmp             x4, x2
    // 0xce11c0: b.ne            #0xce1250
    // 0xce11c4: cmp             x0, x2
    // 0xce11c8: b.ge            #0xce1220
    // 0xce11cc: LoadField: r1 = r3->field_f
    //     0xce11cc: ldur            w1, [x3, #0xf]
    // 0xce11d0: DecompressPointer r1
    //     0xce11d0: add             x1, x1, HEAP, lsl #32
    // 0xce11d4: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xce11d4: add             x16, x1, x0, lsl #2
    //     0xce11d8: ldur            w2, [x16, #0xf]
    // 0xce11dc: DecompressPointer r2
    //     0xce11dc: add             x2, x2, HEAP, lsl #32
    // 0xce11e0: add             x6, x0, #1
    // 0xce11e4: stur            x6, [fp, #-0x20]
    // 0xce11e8: cmp             w2, w5
    // 0xce11ec: b.eq            #0xce1210
    // 0xce11f0: r0 = LoadClassIdInstr(r2)
    //     0xce11f0: ldur            x0, [x2, #-1]
    //     0xce11f4: ubfx            x0, x0, #0xc, #0x14
    // 0xce11f8: mov             x1, x2
    // 0xce11fc: ldur            x2, [fp, #-8]
    // 0xce1200: r0 = GDT[cid_x0 + 0x4deb]()
    //     0xce1200: mov             x17, #0x4deb
    //     0xce1204: add             lr, x0, x17
    //     0xce1208: ldr             lr, [x21, lr, lsl #3]
    //     0xce120c: blr             lr
    // 0xce1210: ldur            x0, [fp, #-0x20]
    // 0xce1214: ldur            x3, [fp, #-0x30]
    // 0xce1218: ldur            x4, [fp, #-0x28]
    // 0xce121c: b               #0xce11a4
    // 0xce1220: mov             x1, x5
    // 0xce1224: r0 = LoadClassIdInstr(r1)
    //     0xce1224: ldur            x0, [x1, #-1]
    //     0xce1228: ubfx            x0, x0, #0xc, #0x14
    // 0xce122c: ldur            x2, [fp, #-8]
    // 0xce1230: r0 = GDT[cid_x0 + 0x2d08]()
    //     0xce1230: mov             x17, #0x2d08
    //     0xce1234: add             lr, x0, x17
    //     0xce1238: ldr             lr, [x21, lr, lsl #3]
    //     0xce123c: blr             lr
    // 0xce1240: r0 = Null
    //     0xce1240: mov             x0, NULL
    // 0xce1244: LeaveFrame
    //     0xce1244: mov             SP, fp
    //     0xce1248: ldp             fp, lr, [SP], #0x10
    // 0xce124c: ret
    //     0xce124c: ret             
    // 0xce1250: mov             x0, x3
    // 0xce1254: r0 = ConcurrentModificationError()
    //     0xce1254: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xce1258: mov             x1, x0
    // 0xce125c: ldur            x0, [fp, #-0x30]
    // 0xce1260: StoreField: r1->field_b = r0
    //     0xce1260: stur            w0, [x1, #0xb]
    // 0xce1264: mov             x0, x1
    // 0xce1268: r0 = Throw()
    //     0xce1268: bl              #0x13ddb2c  ; ThrowStub
    // 0xce126c: brk             #0
    // 0xce1270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1274: b               #0xce115c
    // 0xce1278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1278: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce127c: b               #0xce11b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xce1280, size: 0x68
    // 0xce1280: EnterFrame
    //     0xce1280: stp             fp, lr, [SP, #-0x10]!
    //     0xce1284: mov             fp, SP
    // 0xce1288: ldr             x0, [fp, #0x10]
    // 0xce128c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xce128c: ldur            w1, [x0, #0x17]
    // 0xce1290: DecompressPointer r1
    //     0xce1290: add             x1, x1, HEAP, lsl #32
    // 0xce1294: CheckStackOverflow
    //     0xce1294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1298: cmp             SP, x16
    //     0xce129c: b.ls            #0xce12e0
    // 0xce12a0: LoadField: r0 = r1->field_f
    //     0xce12a0: ldur            w0, [x1, #0xf]
    // 0xce12a4: DecompressPointer r0
    //     0xce12a4: add             x0, x0, HEAP, lsl #32
    // 0xce12a8: LoadField: r2 = r1->field_13
    //     0xce12a8: ldur            w2, [x1, #0x13]
    // 0xce12ac: DecompressPointer r2
    //     0xce12ac: add             x2, x2, HEAP, lsl #32
    // 0xce12b0: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xce12b0: ldur            w3, [x1, #0x17]
    // 0xce12b4: DecompressPointer r3
    //     0xce12b4: add             x3, x3, HEAP, lsl #32
    // 0xce12b8: r1 = LoadInt32Instr(r2)
    //     0xce12b8: sbfx            x1, x2, #1, #0x1f
    //     0xce12bc: tbz             w2, #0, #0xce12c4
    //     0xce12c0: ldur            x1, [x2, #7]
    // 0xce12c4: mov             x2, x1
    // 0xce12c8: mov             x1, x0
    // 0xce12cc: r0 = _resolveByDefault()
    //     0xce12cc: bl              #0xce12e8  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveByDefault
    // 0xce12d0: r0 = Null
    //     0xce12d0: mov             x0, NULL
    // 0xce12d4: LeaveFrame
    //     0xce12d4: mov             SP, fp
    //     0xce12d8: ldp             fp, lr, [SP], #0x10
    // 0xce12dc: ret
    //     0xce12dc: ret             
    // 0xce12e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce12e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce12e4: b               #0xce12a0
  }
  _ _resolveByDefault(/* No info */) {
    // ** addr: 0xce12e8, size: 0xc8
    // 0xce12e8: EnterFrame
    //     0xce12e8: stp             fp, lr, [SP, #-0x10]!
    //     0xce12ec: mov             fp, SP
    // 0xce12f0: AllocStack(0x20)
    //     0xce12f0: sub             SP, SP, #0x20
    // 0xce12f4: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xce12f4: mov             x4, x2
    //     0xce12f8: stur            x2, [fp, #-0x18]
    //     0xce12fc: stur            x3, [fp, #-0x20]
    // 0xce1300: CheckStackOverflow
    //     0xce1300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1304: cmp             SP, x16
    //     0xce1308: b.ls            #0xce13a8
    // 0xce130c: LoadField: r5 = r1->field_7
    //     0xce130c: ldur            w5, [x1, #7]
    // 0xce1310: DecompressPointer r5
    //     0xce1310: add             x5, x5, HEAP, lsl #32
    // 0xce1314: stur            x5, [fp, #-0x10]
    // 0xce1318: r0 = BoxInt64Instr(r4)
    //     0xce1318: sbfiz           x0, x4, #1, #0x1f
    //     0xce131c: cmp             x4, x0, asr #1
    //     0xce1320: b.eq            #0xce132c
    //     0xce1324: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce1328: stur            x4, [x0, #7]
    // 0xce132c: mov             x1, x5
    // 0xce1330: mov             x2, x0
    // 0xce1334: stur            x0, [fp, #-8]
    // 0xce1338: r0 = containsKey()
    //     0xce1338: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xce133c: tbz             w0, #4, #0xce1350
    // 0xce1340: r0 = Null
    //     0xce1340: mov             x0, NULL
    // 0xce1344: LeaveFrame
    //     0xce1344: mov             SP, fp
    //     0xce1348: ldp             fp, lr, [SP], #0x10
    // 0xce134c: ret
    //     0xce134c: ret             
    // 0xce1350: ldur            x0, [fp, #-0x20]
    // 0xce1354: ldur            x1, [fp, #-0x10]
    // 0xce1358: ldur            x2, [fp, #-8]
    // 0xce135c: r0 = remove()
    //     0xce135c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xce1360: ldur            x0, [fp, #-0x20]
    // 0xce1364: LoadField: r1 = r0->field_7
    //     0xce1364: ldur            w1, [x0, #7]
    // 0xce1368: DecompressPointer r1
    //     0xce1368: add             x1, x1, HEAP, lsl #32
    // 0xce136c: r0 = first()
    //     0xce136c: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0xce1370: r1 = LoadClassIdInstr(r0)
    //     0xce1370: ldur            x1, [x0, #-1]
    //     0xce1374: ubfx            x1, x1, #0xc, #0x14
    // 0xce1378: mov             x16, x0
    // 0xce137c: mov             x0, x1
    // 0xce1380: mov             x1, x16
    // 0xce1384: ldur            x2, [fp, #-0x18]
    // 0xce1388: r0 = GDT[cid_x0 + 0x2d08]()
    //     0xce1388: mov             x17, #0x2d08
    //     0xce138c: add             lr, x0, x17
    //     0xce1390: ldr             lr, [x21, lr, lsl #3]
    //     0xce1394: blr             lr
    // 0xce1398: r0 = Null
    //     0xce1398: mov             x0, NULL
    // 0xce139c: LeaveFrame
    //     0xce139c: mov             SP, fp
    //     0xce13a0: ldp             fp, lr, [SP], #0x10
    // 0xce13a4: ret
    //     0xce13a4: ret             
    // 0xce13a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce13a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce13ac: b               #0xce130c
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x12fcb88, size: 0x168
    // 0x12fcb88: EnterFrame
    //     0x12fcb88: stp             fp, lr, [SP, #-0x10]!
    //     0x12fcb8c: mov             fp, SP
    // 0x12fcb90: AllocStack(0x28)
    //     0x12fcb90: sub             SP, SP, #0x28
    // 0x12fcb94: SetupParameters(GestureArenaManager this /* r1 => r6, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */)
    //     0x12fcb94: mov             x6, x1
    //     0x12fcb98: mov             x4, x2
    //     0x12fcb9c: stur            x1, [fp, #-0x10]
    //     0x12fcba0: stur            x2, [fp, #-0x18]
    //     0x12fcba4: stur            x3, [fp, #-0x20]
    //     0x12fcba8: stur            x5, [fp, #-0x28]
    // 0x12fcbac: CheckStackOverflow
    //     0x12fcbac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcbb0: cmp             SP, x16
    //     0x12fcbb4: b.ls            #0x12fcce8
    // 0x12fcbb8: LoadField: r7 = r6->field_7
    //     0x12fcbb8: ldur            w7, [x6, #7]
    // 0x12fcbbc: DecompressPointer r7
    //     0x12fcbbc: add             x7, x7, HEAP, lsl #32
    // 0x12fcbc0: stur            x7, [fp, #-8]
    // 0x12fcbc4: r0 = BoxInt64Instr(r4)
    //     0x12fcbc4: sbfiz           x0, x4, #1, #0x1f
    //     0x12fcbc8: cmp             x4, x0, asr #1
    //     0x12fcbcc: b.eq            #0x12fcbd8
    //     0x12fcbd0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12fcbd4: stur            x4, [x0, #7]
    // 0x12fcbd8: mov             x1, x7
    // 0x12fcbdc: mov             x2, x0
    // 0x12fcbe0: r0 = _getValueOrData()
    //     0x12fcbe0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x12fcbe4: mov             x1, x0
    // 0x12fcbe8: ldur            x0, [fp, #-8]
    // 0x12fcbec: LoadField: r2 = r0->field_f
    //     0x12fcbec: ldur            w2, [x0, #0xf]
    // 0x12fcbf0: DecompressPointer r2
    //     0x12fcbf0: add             x2, x2, HEAP, lsl #32
    // 0x12fcbf4: cmp             w2, w1
    // 0x12fcbf8: b.ne            #0x12fcc04
    // 0x12fcbfc: r3 = Null
    //     0x12fcbfc: mov             x3, NULL
    // 0x12fcc00: b               #0x12fcc08
    // 0x12fcc04: mov             x3, x1
    // 0x12fcc08: stur            x3, [fp, #-8]
    // 0x12fcc0c: cmp             w3, NULL
    // 0x12fcc10: b.ne            #0x12fcc24
    // 0x12fcc14: r0 = Null
    //     0x12fcc14: mov             x0, NULL
    // 0x12fcc18: LeaveFrame
    //     0x12fcc18: mov             SP, fp
    //     0x12fcc1c: ldp             fp, lr, [SP], #0x10
    // 0x12fcc20: ret
    //     0x12fcc20: ret             
    // 0x12fcc24: ldur            x0, [fp, #-0x28]
    // 0x12fcc28: LoadField: r1 = r0->field_7
    //     0x12fcc28: ldur            x1, [x0, #7]
    // 0x12fcc2c: cmp             x1, #0
    // 0x12fcc30: b.gt            #0x12fcc88
    // 0x12fcc34: LoadField: r0 = r3->field_b
    //     0x12fcc34: ldur            w0, [x3, #0xb]
    // 0x12fcc38: DecompressPointer r0
    //     0x12fcc38: add             x0, x0, HEAP, lsl #32
    // 0x12fcc3c: tbnz            w0, #4, #0x12fcc74
    // 0x12fcc40: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x12fcc40: ldur            w0, [x3, #0x17]
    // 0x12fcc44: DecompressPointer r0
    //     0x12fcc44: add             x0, x0, HEAP, lsl #32
    // 0x12fcc48: cmp             w0, NULL
    // 0x12fcc4c: b.ne            #0x12fccd8
    // 0x12fcc50: ldur            x0, [fp, #-0x20]
    // 0x12fcc54: ArrayStore: r3[0] = r0  ; List_4
    //     0x12fcc54: stur            w0, [x3, #0x17]
    //     0x12fcc58: ldurb           w16, [x3, #-1]
    //     0x12fcc5c: ldurb           w17, [x0, #-1]
    //     0x12fcc60: and             x16, x17, x16, lsr #2
    //     0x12fcc64: tst             x16, HEAP, lsr #32
    //     0x12fcc68: b.eq            #0x12fcc70
    //     0x12fcc6c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12fcc70: b               #0x12fccd8
    // 0x12fcc74: ldur            x1, [fp, #-0x10]
    // 0x12fcc78: ldur            x2, [fp, #-0x18]
    // 0x12fcc7c: ldur            x5, [fp, #-0x20]
    // 0x12fcc80: r0 = _resolveInFavorOf()
    //     0x12fcc80: bl              #0xce112c  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveInFavorOf
    // 0x12fcc84: b               #0x12fccd8
    // 0x12fcc88: ldur            x0, [fp, #-0x20]
    // 0x12fcc8c: LoadField: r1 = r3->field_7
    //     0x12fcc8c: ldur            w1, [x3, #7]
    // 0x12fcc90: DecompressPointer r1
    //     0x12fcc90: add             x1, x1, HEAP, lsl #32
    // 0x12fcc94: mov             x2, x0
    // 0x12fcc98: r0 = remove()
    //     0x12fcc98: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0x12fcc9c: ldur            x1, [fp, #-0x20]
    // 0x12fcca0: r0 = LoadClassIdInstr(r1)
    //     0x12fcca0: ldur            x0, [x1, #-1]
    //     0x12fcca4: ubfx            x0, x0, #0xc, #0x14
    // 0x12fcca8: ldur            x2, [fp, #-0x18]
    // 0x12fccac: r0 = GDT[cid_x0 + 0x4deb]()
    //     0x12fccac: mov             x17, #0x4deb
    //     0x12fccb0: add             lr, x0, x17
    //     0x12fccb4: ldr             lr, [x21, lr, lsl #3]
    //     0x12fccb8: blr             lr
    // 0x12fccbc: ldur            x3, [fp, #-8]
    // 0x12fccc0: LoadField: r0 = r3->field_b
    //     0x12fccc0: ldur            w0, [x3, #0xb]
    // 0x12fccc4: DecompressPointer r0
    //     0x12fccc4: add             x0, x0, HEAP, lsl #32
    // 0x12fccc8: tbz             w0, #4, #0x12fccd8
    // 0x12fcccc: ldur            x1, [fp, #-0x10]
    // 0x12fccd0: ldur            x2, [fp, #-0x18]
    // 0x12fccd4: r0 = _tryToResolveArena()
    //     0x12fccd4: bl              #0xce1050  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena
    // 0x12fccd8: r0 = Null
    //     0x12fccd8: mov             x0, NULL
    // 0x12fccdc: LeaveFrame
    //     0x12fccdc: mov             SP, fp
    //     0x12fcce0: ldp             fp, lr, [SP], #0x10
    // 0x12fcce4: ret
    //     0x12fcce4: ret             
    // 0x12fcce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fcce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fccec: b               #0x12fcbb8
  }
}

// class id: 3183, size: 0x1c, field offset: 0x8
class _GestureArena extends Object {
}

// class id: 3184, size: 0x18, field offset: 0x8
class GestureArenaEntry extends Object {

  void resolve(GestureArenaEntry, GestureDisposition) {
    // ** addr: 0xb8d6f8, size: 0x88
    // 0xb8d6f8: EnterFrame
    //     0xb8d6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb8d6fc: mov             fp, SP
    // 0xb8d700: CheckStackOverflow
    //     0xb8d700: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8d704: cmp             SP, x16
    //     0xb8d708: b.ls            #0xb8d760
    // 0xb8d70c: ldr             x0, [fp, #0x10]
    // 0xb8d710: r2 = Null
    //     0xb8d710: mov             x2, NULL
    // 0xb8d714: r1 = Null
    //     0xb8d714: mov             x1, NULL
    // 0xb8d718: r4 = 60
    //     0xb8d718: mov             x4, #0x3c
    // 0xb8d71c: branchIfSmi(r0, 0xb8d728)
    //     0xb8d71c: tbz             w0, #0, #0xb8d728
    // 0xb8d720: r4 = LoadClassIdInstr(r0)
    //     0xb8d720: ldur            x4, [x0, #-1]
    //     0xb8d724: ubfx            x4, x4, #0xc, #0x14
    // 0xb8d728: r17 = 8312
    //     0xb8d728: mov             x17, #0x2078
    // 0xb8d72c: cmp             x4, x17
    // 0xb8d730: b.eq            #0xb8d748
    // 0xb8d734: r8 = GestureDisposition
    //     0xb8d734: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d30] Type: GestureDisposition
    //     0xb8d738: ldr             x8, [x8, #0xd30]
    // 0xb8d73c: r3 = Null
    //     0xb8d73c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3338] Null
    //     0xb8d740: ldr             x3, [x3, #0x338]
    // 0xb8d744: r0 = DefaultTypeTest()
    //     0xb8d744: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb8d748: ldr             x1, [fp, #0x18]
    // 0xb8d74c: ldr             x2, [fp, #0x10]
    // 0xb8d750: r0 = resolve()
    //     0xb8d750: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xb8d754: LeaveFrame
    //     0xb8d754: mov             SP, fp
    //     0xb8d758: ldp             fp, lr, [SP], #0x10
    // 0xb8d75c: ret
    //     0xb8d75c: ret             
    // 0xb8d760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8d760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8d764: b               #0xb8d70c
  }
  void resolve(GestureArenaEntry, GestureDisposition) {
    // ** addr: 0x12fcb3c, size: 0x4c
    // 0x12fcb3c: EnterFrame
    //     0x12fcb3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fcb40: mov             fp, SP
    // 0x12fcb44: mov             x5, x2
    // 0x12fcb48: CheckStackOverflow
    //     0x12fcb48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fcb4c: cmp             SP, x16
    //     0x12fcb50: b.ls            #0x12fcb80
    // 0x12fcb54: LoadField: r0 = r1->field_7
    //     0x12fcb54: ldur            w0, [x1, #7]
    // 0x12fcb58: DecompressPointer r0
    //     0x12fcb58: add             x0, x0, HEAP, lsl #32
    // 0x12fcb5c: LoadField: r2 = r1->field_b
    //     0x12fcb5c: ldur            x2, [x1, #0xb]
    // 0x12fcb60: LoadField: r3 = r1->field_13
    //     0x12fcb60: ldur            w3, [x1, #0x13]
    // 0x12fcb64: DecompressPointer r3
    //     0x12fcb64: add             x3, x3, HEAP, lsl #32
    // 0x12fcb68: mov             x1, x0
    // 0x12fcb6c: r0 = _resolve()
    //     0x12fcb6c: bl              #0x12fcb88  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolve
    // 0x12fcb70: r0 = Null
    //     0x12fcb70: mov             x0, NULL
    // 0x12fcb74: LeaveFrame
    //     0x12fcb74: mov             SP, fp
    //     0x12fcb78: ldp             fp, lr, [SP], #0x10
    // 0x12fcb7c: ret
    //     0x12fcb7c: ret             
    // 0x12fcb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fcb80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fcb84: b               #0x12fcb54
  }
}

// class id: 4424, size: 0x8, field offset: 0x8
abstract class GestureArenaMember extends Object {
}

// class id: 8312, size: 0x14, field offset: 0x14
enum GestureDisposition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9928, size: 0x64
    // 0x11a9928: EnterFrame
    //     0x11a9928: stp             fp, lr, [SP, #-0x10]!
    //     0x11a992c: mov             fp, SP
    // 0x11a9930: AllocStack(0x10)
    //     0x11a9930: sub             SP, SP, #0x10
    // 0x11a9934: SetupParameters(GestureDisposition this /* r1 => r0, fp-0x8 */)
    //     0x11a9934: mov             x0, x1
    //     0x11a9938: stur            x1, [fp, #-8]
    // 0x11a993c: CheckStackOverflow
    //     0x11a993c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9940: cmp             SP, x16
    //     0x11a9944: b.ls            #0x11a9984
    // 0x11a9948: r1 = Null
    //     0x11a9948: mov             x1, NULL
    // 0x11a994c: r2 = 4
    //     0x11a994c: mov             x2, #4
    // 0x11a9950: r0 = AllocateArray()
    //     0x11a9950: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9954: r16 = "GestureDisposition."
    //     0x11a9954: add             x16, PP, #0x82, lsl #12  ; [pp+0x82938] "GestureDisposition."
    //     0x11a9958: ldr             x16, [x16, #0x938]
    // 0x11a995c: StoreField: r0->field_f = r16
    //     0x11a995c: stur            w16, [x0, #0xf]
    // 0x11a9960: ldur            x1, [fp, #-8]
    // 0x11a9964: LoadField: r2 = r1->field_f
    //     0x11a9964: ldur            w2, [x1, #0xf]
    // 0x11a9968: DecompressPointer r2
    //     0x11a9968: add             x2, x2, HEAP, lsl #32
    // 0x11a996c: StoreField: r0->field_13 = r2
    //     0x11a996c: stur            w2, [x0, #0x13]
    // 0x11a9970: str             x0, [SP]
    // 0x11a9974: r0 = _interpolate()
    //     0x11a9974: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9978: LeaveFrame
    //     0x11a9978: mov             SP, fp
    //     0x11a997c: ldp             fp, lr, [SP], #0x10
    // 0x11a9980: ret
    //     0x11a9980: ret             
    // 0x11a9984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9984: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9988: b               #0x11a9948
  }
}
