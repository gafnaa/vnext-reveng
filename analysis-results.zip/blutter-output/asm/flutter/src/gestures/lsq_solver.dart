// lib: , url: package:flutter/src/gestures/lsq_solver.dart

// class id: 1048826, size: 0x8
class :: {
}

// class id: 3161, size: 0x14, field offset: 0x8
class LeastSquaresSolver extends Object {

  _ solve(/* No info */) {
    // ** addr: 0x12fde90, size: 0xab0
    // 0x12fde90: EnterFrame
    //     0x12fde90: stp             fp, lr, [SP, #-0x10]!
    //     0x12fde94: mov             fp, SP
    // 0x12fde98: AllocStack(0x78)
    //     0x12fde98: sub             SP, SP, #0x78
    // 0x12fde9c: SetupParameters(LeastSquaresSolver this /* r1 => r1, fp-0x20 */)
    //     0x12fde9c: stur            x1, [fp, #-0x20]
    // 0x12fdea0: CheckStackOverflow
    //     0x12fdea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fdea4: cmp             SP, x16
    //     0x12fdea8: b.ls            #0x12fe824
    // 0x12fdeac: LoadField: r0 = r1->field_7
    //     0x12fdeac: ldur            w0, [x1, #7]
    // 0x12fdeb0: DecompressPointer r0
    //     0x12fdeb0: add             x0, x0, HEAP, lsl #32
    // 0x12fdeb4: stur            x0, [fp, #-0x18]
    // 0x12fdeb8: LoadField: r4 = r0->field_b
    //     0x12fdeb8: ldur            w4, [x0, #0xb]
    // 0x12fdebc: stur            x4, [fp, #-0x10]
    // 0x12fdec0: r2 = LoadInt32Instr(r4)
    //     0x12fdec0: sbfx            x2, x4, #1, #0x1f
    // 0x12fdec4: stur            x2, [fp, #-8]
    // 0x12fdec8: cmp             x2, #2
    // 0x12fdecc: b.ge            #0x12fdee0
    // 0x12fded0: r0 = Null
    //     0x12fded0: mov             x0, NULL
    // 0x12fded4: LeaveFrame
    //     0x12fded4: mov             SP, fp
    //     0x12fded8: ldp             fp, lr, [SP], #0x10
    // 0x12fdedc: ret
    //     0x12fdedc: ret             
    // 0x12fdee0: r0 = PolynomialFit()
    //     0x12fdee0: bl              #0x12fed38  ; AllocatePolynomialFitStub -> PolynomialFit (size=0x10)
    // 0x12fdee4: mov             x1, x0
    // 0x12fdee8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fdeec: stur            x1, [fp, #-0x28]
    // 0x12fdef0: StoreField: r1->field_b = r0
    //     0x12fdef0: stur            w0, [x1, #0xb]
    // 0x12fdef4: r4 = 6
    //     0x12fdef4: mov             x4, #6
    // 0x12fdef8: r0 = AllocateFloat64Array()
    //     0x12fdef8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12fdefc: mov             x1, x0
    // 0x12fdf00: ldur            x0, [fp, #-0x28]
    // 0x12fdf04: stur            x1, [fp, #-0x30]
    // 0x12fdf08: StoreField: r0->field_7 = r1
    //     0x12fdf08: stur            w1, [x0, #7]
    // 0x12fdf0c: r0 = _Matrix()
    //     0x12fdf0c: bl              #0x12fed2c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0x12fdf10: mov             x1, x0
    // 0x12fdf14: ldur            x0, [fp, #-8]
    // 0x12fdf18: stur            x1, [fp, #-0x48]
    // 0x12fdf1c: StoreField: r1->field_7 = r0
    //     0x12fdf1c: stur            x0, [x1, #7]
    // 0x12fdf20: r16 = 3
    //     0x12fdf20: mov             x16, #3
    // 0x12fdf24: mul             x2, x0, x16
    // 0x12fdf28: stur            x2, [fp, #-0x40]
    // 0x12fdf2c: lsl             x3, x2, #1
    // 0x12fdf30: mov             x4, x3
    // 0x12fdf34: stur            x3, [fp, #-0x38]
    // 0x12fdf38: r0 = AllocateFloat64Array()
    //     0x12fdf38: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12fdf3c: mov             x5, x0
    // 0x12fdf40: ldur            x4, [fp, #-0x48]
    // 0x12fdf44: stur            x5, [fp, #-0x60]
    // 0x12fdf48: StoreField: r4->field_f = r5
    //     0x12fdf48: stur            w5, [x4, #0xf]
    // 0x12fdf4c: ldur            x6, [fp, #-0x20]
    // 0x12fdf50: LoadField: r7 = r6->field_f
    //     0x12fdf50: ldur            w7, [x6, #0xf]
    // 0x12fdf54: DecompressPointer r7
    //     0x12fdf54: add             x7, x7, HEAP, lsl #32
    // 0x12fdf58: stur            x7, [fp, #-0x58]
    // 0x12fdf5c: ldur            x9, [fp, #-0x18]
    // 0x12fdf60: ldur            x8, [fp, #-8]
    // 0x12fdf64: r10 = 0
    //     0x12fdf64: mov             x10, #0
    // 0x12fdf68: stur            x10, [fp, #-0x50]
    // 0x12fdf6c: CheckStackOverflow
    //     0x12fdf6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fdf70: cmp             SP, x16
    //     0x12fdf74: b.ls            #0x12fe82c
    // 0x12fdf78: cmp             x10, x8
    // 0x12fdf7c: b.ge            #0x12fe088
    // 0x12fdf80: LoadField: r0 = r7->field_b
    //     0x12fdf80: ldur            w0, [x7, #0xb]
    // 0x12fdf84: r1 = LoadInt32Instr(r0)
    //     0x12fdf84: sbfx            x1, x0, #1, #0x1f
    // 0x12fdf88: mov             x0, x1
    // 0x12fdf8c: mov             x1, x10
    // 0x12fdf90: cmp             x1, x0
    // 0x12fdf94: b.hs            #0x12fe834
    // 0x12fdf98: LoadField: r0 = r7->field_f
    //     0x12fdf98: ldur            w0, [x7, #0xf]
    // 0x12fdf9c: DecompressPointer r0
    //     0x12fdf9c: add             x0, x0, HEAP, lsl #32
    // 0x12fdfa0: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x12fdfa0: add             x16, x0, x10, lsl #2
    //     0x12fdfa4: ldur            w1, [x16, #0xf]
    // 0x12fdfa8: DecompressPointer r1
    //     0x12fdfa8: add             x1, x1, HEAP, lsl #32
    // 0x12fdfac: LoadField: d0 = r1->field_7
    //     0x12fdfac: ldur            d0, [x1, #7]
    // 0x12fdfb0: mov             x1, x4
    // 0x12fdfb4: mov             x3, x10
    // 0x12fdfb8: r2 = 0
    //     0x12fdfb8: mov             x2, #0
    // 0x12fdfbc: r0 = set()
    //     0x12fdfbc: bl              #0x12fece8  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::set
    // 0x12fdfc0: ldur            x2, [fp, #-0x18]
    // 0x12fdfc4: LoadField: r0 = r2->field_b
    //     0x12fdfc4: ldur            w0, [x2, #0xb]
    // 0x12fdfc8: r3 = LoadInt32Instr(r0)
    //     0x12fdfc8: sbfx            x3, x0, #1, #0x1f
    // 0x12fdfcc: LoadField: r4 = r2->field_f
    //     0x12fdfcc: ldur            w4, [x2, #0xf]
    // 0x12fdfd0: DecompressPointer r4
    //     0x12fdfd0: add             x4, x4, HEAP, lsl #32
    // 0x12fdfd4: ldur            x7, [fp, #-0x50]
    // 0x12fdfd8: ldur            x5, [fp, #-0x60]
    // 0x12fdfdc: ldur            x6, [fp, #-8]
    // 0x12fdfe0: r8 = 1
    //     0x12fdfe0: mov             x8, #1
    // 0x12fdfe4: CheckStackOverflow
    //     0x12fdfe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fdfe8: cmp             SP, x16
    //     0x12fdfec: b.ls            #0x12fe838
    // 0x12fdff0: cmp             x8, #3
    // 0x12fdff4: b.ge            #0x12fe06c
    // 0x12fdff8: sub             x0, x8, #1
    // 0x12fdffc: mul             x1, x0, x6
    // 0x12fe000: add             x9, x1, x7
    // 0x12fe004: ldur            x0, [fp, #-0x40]
    // 0x12fe008: mov             x1, x9
    // 0x12fe00c: cmp             x1, x0
    // 0x12fe010: b.hs            #0x12fe840
    // 0x12fe014: ArrayLoad: d0 = r5[r9]  ; List_8
    //     0x12fe014: add             x16, x5, x9, lsl #3
    //     0x12fe018: ldur            d0, [x16, #0x17]
    // 0x12fe01c: mov             x0, x3
    // 0x12fe020: mov             x1, x7
    // 0x12fe024: cmp             x1, x0
    // 0x12fe028: b.hs            #0x12fe844
    // 0x12fe02c: ArrayLoad: r0 = r4[r7]  ; Unknown_4
    //     0x12fe02c: add             x16, x4, x7, lsl #2
    //     0x12fe030: ldur            w0, [x16, #0xf]
    // 0x12fe034: DecompressPointer r0
    //     0x12fe034: add             x0, x0, HEAP, lsl #32
    // 0x12fe038: LoadField: d1 = r0->field_7
    //     0x12fe038: ldur            d1, [x0, #7]
    // 0x12fe03c: fmul            d2, d0, d1
    // 0x12fe040: mul             x0, x8, x6
    // 0x12fe044: add             x9, x0, x7
    // 0x12fe048: ldur            x0, [fp, #-0x40]
    // 0x12fe04c: mov             x1, x9
    // 0x12fe050: cmp             x1, x0
    // 0x12fe054: b.hs            #0x12fe848
    // 0x12fe058: ArrayStore: r5[r9] = d2  ; List_8
    //     0x12fe058: add             x0, x5, x9, lsl #3
    //     0x12fe05c: stur            d2, [x0, #0x17]
    // 0x12fe060: add             x0, x8, #1
    // 0x12fe064: mov             x8, x0
    // 0x12fe068: b               #0x12fdfe4
    // 0x12fe06c: add             x10, x7, #1
    // 0x12fe070: mov             x8, x6
    // 0x12fe074: ldur            x6, [fp, #-0x20]
    // 0x12fe078: mov             x9, x2
    // 0x12fe07c: ldur            x4, [fp, #-0x48]
    // 0x12fe080: ldur            x7, [fp, #-0x58]
    // 0x12fe084: b               #0x12fdf68
    // 0x12fe088: mov             x2, x9
    // 0x12fe08c: mov             x6, x8
    // 0x12fe090: r0 = _Matrix()
    //     0x12fe090: bl              #0x12fed2c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0x12fe094: mov             x1, x0
    // 0x12fe098: ldur            x0, [fp, #-8]
    // 0x12fe09c: stur            x1, [fp, #-0x48]
    // 0x12fe0a0: StoreField: r1->field_7 = r0
    //     0x12fe0a0: stur            x0, [x1, #7]
    // 0x12fe0a4: ldur            x4, [fp, #-0x38]
    // 0x12fe0a8: r0 = AllocateFloat64Array()
    //     0x12fe0a8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12fe0ac: ldur            x1, [fp, #-0x48]
    // 0x12fe0b0: stur            x0, [fp, #-0x38]
    // 0x12fe0b4: StoreField: r1->field_f = r0
    //     0x12fe0b4: stur            w0, [x1, #0xf]
    // 0x12fe0b8: r0 = _Matrix()
    //     0x12fe0b8: bl              #0x12fed2c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0x12fe0bc: mov             x1, x0
    // 0x12fe0c0: r0 = 3
    //     0x12fe0c0: mov             x0, #3
    // 0x12fe0c4: stur            x1, [fp, #-0x68]
    // 0x12fe0c8: StoreField: r1->field_7 = r0
    //     0x12fe0c8: stur            x0, [x1, #7]
    // 0x12fe0cc: r4 = 18
    //     0x12fe0cc: mov             x4, #0x12
    // 0x12fe0d0: r0 = AllocateFloat64Array()
    //     0x12fe0d0: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12fe0d4: mov             x4, x0
    // 0x12fe0d8: ldur            x3, [fp, #-0x68]
    // 0x12fe0dc: stur            x4, [fp, #-0x70]
    // 0x12fe0e0: StoreField: r3->field_f = r4
    //     0x12fe0e0: stur            w4, [x3, #0xf]
    // 0x12fe0e4: ldur            x5, [fp, #-0x38]
    // 0x12fe0e8: ldur            x7, [fp, #-0x60]
    // 0x12fe0ec: ldur            x6, [fp, #-8]
    // 0x12fe0f0: r8 = 0
    //     0x12fe0f0: mov             x8, #0
    // 0x12fe0f4: stur            x8, [fp, #-0x50]
    // 0x12fe0f8: CheckStackOverflow
    //     0x12fe0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe0fc: cmp             SP, x16
    //     0x12fe100: b.ls            #0x12fe84c
    // 0x12fe104: cmp             x8, #3
    // 0x12fe108: b.ge            #0x12fe3e4
    // 0x12fe10c: mul             x2, x8, x6
    // 0x12fe110: r9 = 0
    //     0x12fe110: mov             x9, #0
    // 0x12fe114: CheckStackOverflow
    //     0x12fe114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe118: cmp             SP, x16
    //     0x12fe11c: b.ls            #0x12fe854
    // 0x12fe120: cmp             x9, x6
    // 0x12fe124: b.ge            #0x12fe158
    // 0x12fe128: add             x10, x2, x9
    // 0x12fe12c: ldur            x0, [fp, #-0x40]
    // 0x12fe130: mov             x1, x10
    // 0x12fe134: cmp             x1, x0
    // 0x12fe138: b.hs            #0x12fe85c
    // 0x12fe13c: ArrayLoad: d0 = r7[r10]  ; List_8
    //     0x12fe13c: add             x16, x7, x10, lsl #3
    //     0x12fe140: ldur            d0, [x16, #0x17]
    // 0x12fe144: ArrayStore: r5[r10] = d0  ; List_8
    //     0x12fe144: add             x0, x5, x10, lsl #3
    //     0x12fe148: stur            d0, [x0, #0x17]
    // 0x12fe14c: add             x0, x9, #1
    // 0x12fe150: mov             x9, x0
    // 0x12fe154: b               #0x12fe114
    // 0x12fe158: mul             x2, x8, x6
    // 0x12fe15c: r9 = 0
    //     0x12fe15c: mov             x9, #0
    // 0x12fe160: CheckStackOverflow
    //     0x12fe160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe164: cmp             SP, x16
    //     0x12fe168: b.ls            #0x12fe860
    // 0x12fe16c: cmp             x9, x8
    // 0x12fe170: b.ge            #0x12fe25c
    // 0x12fe174: mul             x10, x9, x6
    // 0x12fe178: d0 = 0.000000
    //     0x12fe178: eor             v0.16b, v0.16b, v0.16b
    // 0x12fe17c: r11 = 0
    //     0x12fe17c: mov             x11, #0
    // 0x12fe180: CheckStackOverflow
    //     0x12fe180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe184: cmp             SP, x16
    //     0x12fe188: b.ls            #0x12fe868
    // 0x12fe18c: cmp             x11, x6
    // 0x12fe190: b.ge            #0x12fe1e4
    // 0x12fe194: add             x12, x11, x2
    // 0x12fe198: ldur            x0, [fp, #-0x40]
    // 0x12fe19c: mov             x1, x12
    // 0x12fe1a0: cmp             x1, x0
    // 0x12fe1a4: b.hs            #0x12fe870
    // 0x12fe1a8: ArrayLoad: d1 = r5[r12]  ; List_8
    //     0x12fe1a8: add             x16, x5, x12, lsl #3
    //     0x12fe1ac: ldur            d1, [x16, #0x17]
    // 0x12fe1b0: add             x12, x11, x10
    // 0x12fe1b4: ldur            x0, [fp, #-0x40]
    // 0x12fe1b8: mov             x1, x12
    // 0x12fe1bc: cmp             x1, x0
    // 0x12fe1c0: b.hs            #0x12fe874
    // 0x12fe1c4: ArrayLoad: d2 = r5[r12]  ; List_8
    //     0x12fe1c4: add             x16, x5, x12, lsl #3
    //     0x12fe1c8: ldur            d2, [x16, #0x17]
    // 0x12fe1cc: fmul            d3, d1, d2
    // 0x12fe1d0: fadd            d1, d0, d3
    // 0x12fe1d4: add             x0, x11, #1
    // 0x12fe1d8: mov             v0.16b, v1.16b
    // 0x12fe1dc: mov             x11, x0
    // 0x12fe1e0: b               #0x12fe180
    // 0x12fe1e4: r11 = 0
    //     0x12fe1e4: mov             x11, #0
    // 0x12fe1e8: CheckStackOverflow
    //     0x12fe1e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe1ec: cmp             SP, x16
    //     0x12fe1f0: b.ls            #0x12fe878
    // 0x12fe1f4: cmp             x11, x6
    // 0x12fe1f8: b.ge            #0x12fe250
    // 0x12fe1fc: add             x12, x2, x11
    // 0x12fe200: ldur            x0, [fp, #-0x40]
    // 0x12fe204: mov             x1, x12
    // 0x12fe208: cmp             x1, x0
    // 0x12fe20c: b.hs            #0x12fe880
    // 0x12fe210: ArrayLoad: d1 = r5[r12]  ; List_8
    //     0x12fe210: add             x16, x5, x12, lsl #3
    //     0x12fe214: ldur            d1, [x16, #0x17]
    // 0x12fe218: add             x13, x10, x11
    // 0x12fe21c: ldur            x0, [fp, #-0x40]
    // 0x12fe220: mov             x1, x13
    // 0x12fe224: cmp             x1, x0
    // 0x12fe228: b.hs            #0x12fe884
    // 0x12fe22c: ArrayLoad: d2 = r5[r13]  ; List_8
    //     0x12fe22c: add             x16, x5, x13, lsl #3
    //     0x12fe230: ldur            d2, [x16, #0x17]
    // 0x12fe234: fmul            d3, d0, d2
    // 0x12fe238: fsub            d2, d1, d3
    // 0x12fe23c: ArrayStore: r5[r12] = d2  ; List_8
    //     0x12fe23c: add             x0, x5, x12, lsl #3
    //     0x12fe240: stur            d2, [x0, #0x17]
    // 0x12fe244: add             x0, x11, #1
    // 0x12fe248: mov             x11, x0
    // 0x12fe24c: b               #0x12fe1e8
    // 0x12fe250: add             x0, x9, #1
    // 0x12fe254: mov             x9, x0
    // 0x12fe258: b               #0x12fe160
    // 0x12fe25c: ldur            x1, [fp, #-0x48]
    // 0x12fe260: mov             x2, x8
    // 0x12fe264: r0 = getRow()
    //     0x12fe264: bl              #0x12fec98  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::getRow
    // 0x12fe268: mov             x1, x0
    // 0x12fe26c: r0 = norm()
    //     0x12fe26c: bl              #0x12fec5c  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::norm
    // 0x12fe270: mov             v1.16b, v0.16b
    // 0x12fe274: d0 = 0.000000
    //     0x12fe274: ldr             d0, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0x12fe278: fcmp            d0, d1
    // 0x12fe27c: b.gt            #0x12fe3d4
    // 0x12fe280: ldur            x3, [fp, #-0x50]
    // 0x12fe284: ldur            x2, [fp, #-8]
    // 0x12fe288: d2 = 1.000000
    //     0x12fe288: fmov            d2, #1.00000000
    // 0x12fe28c: fdiv            d3, d2, d1
    // 0x12fe290: mul             x4, x3, x2
    // 0x12fe294: ldur            x5, [fp, #-0x38]
    // 0x12fe298: r6 = 0
    //     0x12fe298: mov             x6, #0
    // 0x12fe29c: CheckStackOverflow
    //     0x12fe29c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe2a0: cmp             SP, x16
    //     0x12fe2a4: b.ls            #0x12fe888
    // 0x12fe2a8: cmp             x6, x2
    // 0x12fe2ac: b.ge            #0x12fe2e4
    // 0x12fe2b0: add             x7, x4, x6
    // 0x12fe2b4: ldur            x0, [fp, #-0x40]
    // 0x12fe2b8: mov             x1, x7
    // 0x12fe2bc: cmp             x1, x0
    // 0x12fe2c0: b.hs            #0x12fe890
    // 0x12fe2c4: ArrayLoad: d1 = r5[r7]  ; List_8
    //     0x12fe2c4: add             x16, x5, x7, lsl #3
    //     0x12fe2c8: ldur            d1, [x16, #0x17]
    // 0x12fe2cc: fmul            d4, d1, d3
    // 0x12fe2d0: ArrayStore: r5[r7] = d4  ; List_8
    //     0x12fe2d0: add             x0, x5, x7, lsl #3
    //     0x12fe2d4: stur            d4, [x0, #0x17]
    // 0x12fe2d8: add             x0, x6, #1
    // 0x12fe2dc: mov             x6, x0
    // 0x12fe2e0: b               #0x12fe29c
    // 0x12fe2e4: mul             x4, x3, x2
    // 0x12fe2e8: r16 = 3
    //     0x12fe2e8: mov             x16, #3
    // 0x12fe2ec: mul             x6, x3, x16
    // 0x12fe2f0: ldur            x7, [fp, #-0x70]
    // 0x12fe2f4: ldur            x8, [fp, #-0x60]
    // 0x12fe2f8: r9 = 0
    //     0x12fe2f8: mov             x9, #0
    // 0x12fe2fc: CheckStackOverflow
    //     0x12fe2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe300: cmp             SP, x16
    //     0x12fe304: b.ls            #0x12fe894
    // 0x12fe308: cmp             x9, #3
    // 0x12fe30c: b.ge            #0x12fe3b8
    // 0x12fe310: cmp             x9, x3
    // 0x12fe314: b.ge            #0x12fe320
    // 0x12fe318: d1 = 0.000000
    //     0x12fe318: eor             v1.16b, v1.16b, v1.16b
    // 0x12fe31c: b               #0x12fe390
    // 0x12fe320: mul             x10, x9, x2
    // 0x12fe324: d1 = 0.000000
    //     0x12fe324: eor             v1.16b, v1.16b, v1.16b
    // 0x12fe328: r11 = 0
    //     0x12fe328: mov             x11, #0
    // 0x12fe32c: CheckStackOverflow
    //     0x12fe32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe330: cmp             SP, x16
    //     0x12fe334: b.ls            #0x12fe89c
    // 0x12fe338: cmp             x11, x2
    // 0x12fe33c: b.ge            #0x12fe390
    // 0x12fe340: add             x12, x11, x4
    // 0x12fe344: ldur            x0, [fp, #-0x40]
    // 0x12fe348: mov             x1, x12
    // 0x12fe34c: cmp             x1, x0
    // 0x12fe350: b.hs            #0x12fe8a4
    // 0x12fe354: ArrayLoad: d3 = r5[r12]  ; List_8
    //     0x12fe354: add             x16, x5, x12, lsl #3
    //     0x12fe358: ldur            d3, [x16, #0x17]
    // 0x12fe35c: add             x12, x11, x10
    // 0x12fe360: ldur            x0, [fp, #-0x40]
    // 0x12fe364: mov             x1, x12
    // 0x12fe368: cmp             x1, x0
    // 0x12fe36c: b.hs            #0x12fe8a8
    // 0x12fe370: ArrayLoad: d4 = r8[r12]  ; List_8
    //     0x12fe370: add             x16, x8, x12, lsl #3
    //     0x12fe374: ldur            d4, [x16, #0x17]
    // 0x12fe378: fmul            d5, d3, d4
    // 0x12fe37c: fadd            d3, d1, d5
    // 0x12fe380: add             x0, x11, #1
    // 0x12fe384: mov             v1.16b, v3.16b
    // 0x12fe388: mov             x11, x0
    // 0x12fe38c: b               #0x12fe32c
    // 0x12fe390: add             x10, x6, x9
    // 0x12fe394: mov             x1, x10
    // 0x12fe398: r0 = 9
    //     0x12fe398: mov             x0, #9
    // 0x12fe39c: cmp             x1, x0
    // 0x12fe3a0: b.hs            #0x12fe8ac
    // 0x12fe3a4: ArrayStore: r7[r10] = d1  ; List_8
    //     0x12fe3a4: add             x0, x7, x10, lsl #3
    //     0x12fe3a8: stur            d1, [x0, #0x17]
    // 0x12fe3ac: add             x0, x9, #1
    // 0x12fe3b0: mov             x9, x0
    // 0x12fe3b4: b               #0x12fe2fc
    // 0x12fe3b8: add             x0, x3, #1
    // 0x12fe3bc: mov             x4, x7
    // 0x12fe3c0: mov             x7, x8
    // 0x12fe3c4: mov             x8, x0
    // 0x12fe3c8: ldur            x3, [fp, #-0x68]
    // 0x12fe3cc: mov             x6, x2
    // 0x12fe3d0: b               #0x12fe0f4
    // 0x12fe3d4: r0 = Null
    //     0x12fe3d4: mov             x0, NULL
    // 0x12fe3d8: LeaveFrame
    //     0x12fe3d8: mov             SP, fp
    //     0x12fe3dc: ldp             fp, lr, [SP], #0x10
    // 0x12fe3e0: ret
    //     0x12fe3e0: ret             
    // 0x12fe3e4: ldur            x0, [fp, #-0x20]
    // 0x12fe3e8: mov             x7, x4
    // 0x12fe3ec: mov             x2, x6
    // 0x12fe3f0: d0 = 0.000000
    //     0x12fe3f0: ldr             d0, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0x12fe3f4: d2 = 1.000000
    //     0x12fe3f4: fmov            d2, #1.00000000
    // 0x12fe3f8: r0 = _Vector()
    //     0x12fe3f8: bl              #0x12fec50  ; Allocate_VectorStub -> _Vector (size=0x1c)
    // 0x12fe3fc: stur            x0, [fp, #-0x38]
    // 0x12fe400: StoreField: r0->field_7 = rZR
    //     0x12fe400: stur            xzr, [x0, #7]
    // 0x12fe404: ldur            x1, [fp, #-8]
    // 0x12fe408: StoreField: r0->field_f = r1
    //     0x12fe408: stur            x1, [x0, #0xf]
    // 0x12fe40c: ldur            x4, [fp, #-0x10]
    // 0x12fe410: r0 = AllocateFloat64Array()
    //     0x12fe410: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12fe414: ldur            x4, [fp, #-0x38]
    // 0x12fe418: ArrayStore: r4[0] = r0  ; List_4
    //     0x12fe418: stur            w0, [x4, #0x17]
    // 0x12fe41c: ldur            x0, [fp, #-0x20]
    // 0x12fe420: LoadField: r5 = r0->field_b
    //     0x12fe420: ldur            w5, [x0, #0xb]
    // 0x12fe424: DecompressPointer r5
    //     0x12fe424: add             x5, x5, HEAP, lsl #32
    // 0x12fe428: stur            x5, [fp, #-0x60]
    // 0x12fe42c: r8 = 0
    //     0x12fe42c: mov             x8, #0
    // 0x12fe430: ldur            x7, [fp, #-0x58]
    // 0x12fe434: ldur            x6, [fp, #-8]
    // 0x12fe438: stur            x8, [fp, #-0x40]
    // 0x12fe43c: CheckStackOverflow
    //     0x12fe43c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe440: cmp             SP, x16
    //     0x12fe444: b.ls            #0x12fe8b0
    // 0x12fe448: cmp             x8, x6
    // 0x12fe44c: b.ge            #0x12fe500
    // 0x12fe450: LoadField: r0 = r5->field_b
    //     0x12fe450: ldur            w0, [x5, #0xb]
    // 0x12fe454: r1 = LoadInt32Instr(r0)
    //     0x12fe454: sbfx            x1, x0, #1, #0x1f
    // 0x12fe458: mov             x0, x1
    // 0x12fe45c: mov             x1, x8
    // 0x12fe460: cmp             x1, x0
    // 0x12fe464: b.hs            #0x12fe8b8
    // 0x12fe468: LoadField: r0 = r5->field_f
    //     0x12fe468: ldur            w0, [x5, #0xf]
    // 0x12fe46c: DecompressPointer r0
    //     0x12fe46c: add             x0, x0, HEAP, lsl #32
    // 0x12fe470: lsl             x2, x8, #1
    // 0x12fe474: ArrayLoad: r3 = r0[r8]  ; Unknown_4
    //     0x12fe474: add             x16, x0, x8, lsl #2
    //     0x12fe478: ldur            w3, [x16, #0xf]
    // 0x12fe47c: DecompressPointer r3
    //     0x12fe47c: add             x3, x3, HEAP, lsl #32
    // 0x12fe480: LoadField: r0 = r7->field_b
    //     0x12fe480: ldur            w0, [x7, #0xb]
    // 0x12fe484: r1 = LoadInt32Instr(r0)
    //     0x12fe484: sbfx            x1, x0, #1, #0x1f
    // 0x12fe488: mov             x0, x1
    // 0x12fe48c: mov             x1, x8
    // 0x12fe490: cmp             x1, x0
    // 0x12fe494: b.hs            #0x12fe8bc
    // 0x12fe498: LoadField: r0 = r7->field_f
    //     0x12fe498: ldur            w0, [x7, #0xf]
    // 0x12fe49c: DecompressPointer r0
    //     0x12fe49c: add             x0, x0, HEAP, lsl #32
    // 0x12fe4a0: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0x12fe4a0: add             x16, x0, x8, lsl #2
    //     0x12fe4a4: ldur            w1, [x16, #0xf]
    // 0x12fe4a8: DecompressPointer r1
    //     0x12fe4a8: add             x1, x1, HEAP, lsl #32
    // 0x12fe4ac: LoadField: d0 = r3->field_7
    //     0x12fe4ac: ldur            d0, [x3, #7]
    // 0x12fe4b0: LoadField: d1 = r1->field_7
    //     0x12fe4b0: ldur            d1, [x1, #7]
    // 0x12fe4b4: fmul            d2, d0, d1
    // 0x12fe4b8: r3 = inline_Allocate_Double()
    //     0x12fe4b8: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12fe4bc: add             x3, x3, #0x10
    //     0x12fe4c0: cmp             x0, x3
    //     0x12fe4c4: b.ls            #0x12fe8c0
    //     0x12fe4c8: str             x3, [THR, #0x60]  ; THR::top
    //     0x12fe4cc: sub             x3, x3, #0xf
    //     0x12fe4d0: mov             x0, #0xe19c
    //     0x12fe4d4: movk            x0, #3, lsl #16
    //     0x12fe4d8: stur            x0, [x3, #-1]
    // 0x12fe4dc: dmb             ishst
    // 0x12fe4e0: StoreField: r3->field_7 = d2
    //     0x12fe4e0: stur            d2, [x3, #7]
    // 0x12fe4e4: mov             x1, x4
    // 0x12fe4e8: r0 = []=()
    //     0x12fe4e8: bl              #0x12fec00  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::[]=
    // 0x12fe4ec: ldur            x0, [fp, #-0x40]
    // 0x12fe4f0: add             x8, x0, #1
    // 0x12fe4f4: ldur            x4, [fp, #-0x38]
    // 0x12fe4f8: ldur            x5, [fp, #-0x60]
    // 0x12fe4fc: b               #0x12fe430
    // 0x12fe500: ldur            x3, [fp, #-0x30]
    // 0x12fe504: r4 = 2
    //     0x12fe504: mov             x4, #2
    // 0x12fe508: ldur            x0, [fp, #-0x70]
    // 0x12fe50c: stur            x4, [fp, #-0x40]
    // 0x12fe510: CheckStackOverflow
    //     0x12fe510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe514: cmp             SP, x16
    //     0x12fe518: b.ls            #0x12fe8ec
    // 0x12fe51c: tbnz            x4, #0x3f, #0x12fe5ec
    // 0x12fe520: ldur            x1, [fp, #-0x48]
    // 0x12fe524: mov             x2, x4
    // 0x12fe528: r0 = getRow()
    //     0x12fe528: bl              #0x12fec98  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::getRow
    // 0x12fe52c: mov             x1, x0
    // 0x12fe530: ldur            x2, [fp, #-0x38]
    // 0x12fe534: r0 = *()
    //     0x12fe534: bl              #0x12feb44  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::*
    // 0x12fe538: ldur            x5, [fp, #-0x40]
    // 0x12fe53c: ldur            x4, [fp, #-0x30]
    // 0x12fe540: ArrayStore: r4[r5] = d0  ; List_8
    //     0x12fe540: add             x0, x4, x5, lsl #3
    //     0x12fe544: stur            d0, [x0, #0x17]
    // 0x12fe548: r16 = 3
    //     0x12fe548: mov             x16, #3
    // 0x12fe54c: mul             x2, x5, x16
    // 0x12fe550: ldur            x6, [fp, #-0x70]
    // 0x12fe554: r3 = 2
    //     0x12fe554: mov             x3, #2
    // 0x12fe558: stur            d0, [fp, #-0x78]
    // 0x12fe55c: CheckStackOverflow
    //     0x12fe55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe560: cmp             SP, x16
    //     0x12fe564: b.ls            #0x12fe8f4
    // 0x12fe568: cmp             x3, x5
    // 0x12fe56c: b.le            #0x12fe5b4
    // 0x12fe570: add             x7, x2, x3
    // 0x12fe574: mov             x1, x7
    // 0x12fe578: r0 = 9
    //     0x12fe578: mov             x0, #9
    // 0x12fe57c: cmp             x1, x0
    // 0x12fe580: b.hs            #0x12fe8fc
    // 0x12fe584: ArrayLoad: d1 = r6[r7]  ; List_8
    //     0x12fe584: add             x16, x6, x7, lsl #3
    //     0x12fe588: ldur            d1, [x16, #0x17]
    // 0x12fe58c: ArrayLoad: d2 = r4[r3]  ; List_8
    //     0x12fe58c: add             x16, x4, x3, lsl #3
    //     0x12fe590: ldur            d2, [x16, #0x17]
    // 0x12fe594: fmul            d3, d1, d2
    // 0x12fe598: fsub            d1, d0, d3
    // 0x12fe59c: ArrayStore: r4[r5] = d1  ; List_8
    //     0x12fe59c: add             x0, x4, x5, lsl #3
    //     0x12fe5a0: stur            d1, [x0, #0x17]
    // 0x12fe5a4: sub             x0, x3, #1
    // 0x12fe5a8: mov             x3, x0
    // 0x12fe5ac: mov             v0.16b, v1.16b
    // 0x12fe5b0: b               #0x12fe558
    // 0x12fe5b4: ldur            x1, [fp, #-0x68]
    // 0x12fe5b8: mov             x2, x5
    // 0x12fe5bc: mov             x3, x5
    // 0x12fe5c0: r0 = get()
    //     0x12fe5c0: bl              #0x12feb04  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::get
    // 0x12fe5c4: mov             v1.16b, v0.16b
    // 0x12fe5c8: ldur            d0, [fp, #-0x78]
    // 0x12fe5cc: fdiv            d2, d0, d1
    // 0x12fe5d0: ldur            x3, [fp, #-0x40]
    // 0x12fe5d4: ldur            x2, [fp, #-0x30]
    // 0x12fe5d8: ArrayStore: r2[r3] = d2  ; List_8
    //     0x12fe5d8: add             x4, x2, x3, lsl #3
    //     0x12fe5dc: stur            d2, [x4, #0x17]
    // 0x12fe5e0: sub             x4, x3, #1
    // 0x12fe5e4: mov             x3, x2
    // 0x12fe5e8: b               #0x12fe508
    // 0x12fe5ec: mov             x2, x3
    // 0x12fe5f0: ldur            x3, [fp, #-0x60]
    // 0x12fe5f4: LoadField: r4 = r3->field_b
    //     0x12fe5f4: ldur            w4, [x3, #0xb]
    // 0x12fe5f8: r5 = LoadInt32Instr(r4)
    //     0x12fe5f8: sbfx            x5, x4, #1, #0x1f
    // 0x12fe5fc: LoadField: r4 = r3->field_f
    //     0x12fe5fc: ldur            w4, [x3, #0xf]
    // 0x12fe600: DecompressPointer r4
    //     0x12fe600: add             x4, x4, HEAP, lsl #32
    // 0x12fe604: ldur            x6, [fp, #-8]
    // 0x12fe608: d0 = 0.000000
    //     0x12fe608: eor             v0.16b, v0.16b, v0.16b
    // 0x12fe60c: r7 = 0
    //     0x12fe60c: mov             x7, #0
    // 0x12fe610: CheckStackOverflow
    //     0x12fe610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe614: cmp             SP, x16
    //     0x12fe618: b.ls            #0x12fe900
    // 0x12fe61c: cmp             x7, x6
    // 0x12fe620: b.ge            #0x12fe658
    // 0x12fe624: mov             x0, x5
    // 0x12fe628: mov             x1, x7
    // 0x12fe62c: cmp             x1, x0
    // 0x12fe630: b.hs            #0x12fe908
    // 0x12fe634: ArrayLoad: r8 = r4[r7]  ; Unknown_4
    //     0x12fe634: add             x16, x4, x7, lsl #2
    //     0x12fe638: ldur            w8, [x16, #0xf]
    // 0x12fe63c: DecompressPointer r8
    //     0x12fe63c: add             x8, x8, HEAP, lsl #32
    // 0x12fe640: LoadField: d1 = r8->field_7
    //     0x12fe640: ldur            d1, [x8, #7]
    // 0x12fe644: fadd            d2, d0, d1
    // 0x12fe648: add             x0, x7, #1
    // 0x12fe64c: mov             v0.16b, v2.16b
    // 0x12fe650: mov             x7, x0
    // 0x12fe654: b               #0x12fe610
    // 0x12fe658: ldur            x5, [fp, #-0x18]
    // 0x12fe65c: ldur            x4, [fp, #-0x58]
    // 0x12fe660: ldur            x7, [fp, #-0x10]
    // 0x12fe664: r16 = LoadInt32Instr(r7)
    //     0x12fe664: sbfx            x16, x7, #1, #0x1f
    // 0x12fe668: scvtf           d1, w16
    // 0x12fe66c: fdiv            d2, d0, d1
    // 0x12fe670: LoadField: r7 = r3->field_b
    //     0x12fe670: ldur            w7, [x3, #0xb]
    // 0x12fe674: r8 = LoadInt32Instr(r7)
    //     0x12fe674: sbfx            x8, x7, #1, #0x1f
    // 0x12fe678: LoadField: r7 = r3->field_f
    //     0x12fe678: ldur            w7, [x3, #0xf]
    // 0x12fe67c: DecompressPointer r7
    //     0x12fe67c: add             x7, x7, HEAP, lsl #32
    // 0x12fe680: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x12fe680: ldur            d0, [x2, #0x17]
    // 0x12fe684: LoadField: r3 = r5->field_b
    //     0x12fe684: ldur            w3, [x5, #0xb]
    // 0x12fe688: r9 = LoadInt32Instr(r3)
    //     0x12fe688: sbfx            x9, x3, #1, #0x1f
    // 0x12fe68c: LoadField: r3 = r5->field_f
    //     0x12fe68c: ldur            w3, [x5, #0xf]
    // 0x12fe690: DecompressPointer r3
    //     0x12fe690: add             x3, x3, HEAP, lsl #32
    // 0x12fe694: LoadField: r5 = r4->field_b
    //     0x12fe694: ldur            w5, [x4, #0xb]
    // 0x12fe698: r10 = LoadInt32Instr(r5)
    //     0x12fe698: sbfx            x10, x5, #1, #0x1f
    // 0x12fe69c: LoadField: r5 = r4->field_f
    //     0x12fe69c: ldur            w5, [x4, #0xf]
    // 0x12fe6a0: DecompressPointer r5
    //     0x12fe6a0: add             x5, x5, HEAP, lsl #32
    // 0x12fe6a4: d3 = 0.000000
    //     0x12fe6a4: eor             v3.16b, v3.16b, v3.16b
    // 0x12fe6a8: d1 = 0.000000
    //     0x12fe6a8: eor             v1.16b, v1.16b, v1.16b
    // 0x12fe6ac: r4 = 0
    //     0x12fe6ac: mov             x4, #0
    // 0x12fe6b0: CheckStackOverflow
    //     0x12fe6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe6b4: cmp             SP, x16
    //     0x12fe6b8: b.ls            #0x12fe90c
    // 0x12fe6bc: cmp             x4, x6
    // 0x12fe6c0: b.ge            #0x12fe7a4
    // 0x12fe6c4: mov             x0, x8
    // 0x12fe6c8: mov             x1, x4
    // 0x12fe6cc: cmp             x1, x0
    // 0x12fe6d0: b.hs            #0x12fe914
    // 0x12fe6d4: ArrayLoad: r11 = r7[r4]  ; Unknown_4
    //     0x12fe6d4: add             x16, x7, x4, lsl #2
    //     0x12fe6d8: ldur            w11, [x16, #0xf]
    // 0x12fe6dc: DecompressPointer r11
    //     0x12fe6dc: add             x11, x11, HEAP, lsl #32
    // 0x12fe6e0: LoadField: d4 = r11->field_7
    //     0x12fe6e0: ldur            d4, [x11, #7]
    // 0x12fe6e4: fsub            d5, d4, d0
    // 0x12fe6e8: mov             x0, x9
    // 0x12fe6ec: mov             x1, x4
    // 0x12fe6f0: cmp             x1, x0
    // 0x12fe6f4: b.hs            #0x12fe918
    // 0x12fe6f8: ArrayLoad: r12 = r3[r4]  ; Unknown_4
    //     0x12fe6f8: add             x16, x3, x4, lsl #2
    //     0x12fe6fc: ldur            w12, [x16, #0xf]
    // 0x12fe700: DecompressPointer r12
    //     0x12fe700: add             x12, x12, HEAP, lsl #32
    // 0x12fe704: LoadField: d4 = r12->field_7
    //     0x12fe704: ldur            d4, [x12, #7]
    // 0x12fe708: d6 = 1.000000
    //     0x12fe708: fmov            d6, #1.00000000
    // 0x12fe70c: r12 = 1
    //     0x12fe70c: mov             x12, #1
    // 0x12fe710: CheckStackOverflow
    //     0x12fe710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fe714: cmp             SP, x16
    //     0x12fe718: b.ls            #0x12fe91c
    // 0x12fe71c: cmp             x12, #3
    // 0x12fe720: b.ge            #0x12fe74c
    // 0x12fe724: fmul            d7, d6, d4
    // 0x12fe728: ArrayLoad: d6 = r2[r12]  ; List_8
    //     0x12fe728: add             x16, x2, x12, lsl #3
    //     0x12fe72c: ldur            d6, [x16, #0x17]
    // 0x12fe730: fmul            d8, d7, d6
    // 0x12fe734: fsub            d9, d5, d8
    // 0x12fe738: add             x0, x12, #1
    // 0x12fe73c: mov             v6.16b, v7.16b
    // 0x12fe740: mov             v5.16b, v9.16b
    // 0x12fe744: mov             x12, x0
    // 0x12fe748: b               #0x12fe710
    // 0x12fe74c: mov             x0, x10
    // 0x12fe750: mov             x1, x4
    // 0x12fe754: cmp             x1, x0
    // 0x12fe758: b.hs            #0x12fe924
    // 0x12fe75c: ArrayLoad: r1 = r5[r4]  ; Unknown_4
    //     0x12fe75c: add             x16, x5, x4, lsl #2
    //     0x12fe760: ldur            w1, [x16, #0xf]
    // 0x12fe764: DecompressPointer r1
    //     0x12fe764: add             x1, x1, HEAP, lsl #32
    // 0x12fe768: LoadField: d4 = r1->field_7
    //     0x12fe768: ldur            d4, [x1, #7]
    // 0x12fe76c: fmul            d6, d4, d4
    // 0x12fe770: fmul            d4, d6, d5
    // 0x12fe774: fmul            d7, d4, d5
    // 0x12fe778: fadd            d4, d3, d7
    // 0x12fe77c: LoadField: d5 = r11->field_7
    //     0x12fe77c: ldur            d5, [x11, #7]
    // 0x12fe780: fsub            d7, d5, d2
    // 0x12fe784: fmul            d5, d6, d7
    // 0x12fe788: fmul            d6, d5, d7
    // 0x12fe78c: fadd            d5, d1, d6
    // 0x12fe790: add             x0, x4, #1
    // 0x12fe794: mov             v3.16b, v4.16b
    // 0x12fe798: mov             v1.16b, v5.16b
    // 0x12fe79c: mov             x4, x0
    // 0x12fe7a0: b               #0x12fe6b0
    // 0x12fe7a4: d0 = 0.000000
    //     0x12fe7a4: ldr             d0, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0x12fe7a8: fcmp            d0, d1
    // 0x12fe7ac: b.lt            #0x12fe7b8
    // 0x12fe7b0: d0 = 1.000000
    //     0x12fe7b0: fmov            d0, #1.00000000
    // 0x12fe7b4: b               #0x12fe7c8
    // 0x12fe7b8: d0 = 1.000000
    //     0x12fe7b8: fmov            d0, #1.00000000
    // 0x12fe7bc: fdiv            d2, d3, d1
    // 0x12fe7c0: fsub            d1, d0, d2
    // 0x12fe7c4: mov             v0.16b, v1.16b
    // 0x12fe7c8: ldur            x1, [fp, #-0x28]
    // 0x12fe7cc: r0 = inline_Allocate_Double()
    //     0x12fe7cc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x12fe7d0: add             x0, x0, #0x10
    //     0x12fe7d4: cmp             x2, x0
    //     0x12fe7d8: b.ls            #0x12fe928
    //     0x12fe7dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x12fe7e0: sub             x0, x0, #0xf
    //     0x12fe7e4: mov             x2, #0xe19c
    //     0x12fe7e8: movk            x2, #3, lsl #16
    //     0x12fe7ec: stur            x2, [x0, #-1]
    // 0x12fe7f0: dmb             ishst
    // 0x12fe7f4: StoreField: r0->field_7 = d0
    //     0x12fe7f4: stur            d0, [x0, #7]
    // 0x12fe7f8: StoreField: r1->field_b = r0
    //     0x12fe7f8: stur            w0, [x1, #0xb]
    //     0x12fe7fc: ldurb           w16, [x1, #-1]
    //     0x12fe800: ldurb           w17, [x0, #-1]
    //     0x12fe804: and             x16, x17, x16, lsr #2
    //     0x12fe808: tst             x16, HEAP, lsr #32
    //     0x12fe80c: b.eq            #0x12fe814
    //     0x12fe810: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12fe814: mov             x0, x1
    // 0x12fe818: LeaveFrame
    //     0x12fe818: mov             SP, fp
    //     0x12fe81c: ldp             fp, lr, [SP], #0x10
    // 0x12fe820: ret
    //     0x12fe820: ret             
    // 0x12fe824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe828: b               #0x12fdeac
    // 0x12fe82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe82c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe830: b               #0x12fdf78
    // 0x12fe834: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fe834: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fe838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe83c: b               #0x12fdff0
    // 0x12fe840: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fe840: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fe844: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe844: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe848: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe848: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe84c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe850: b               #0x12fe104
    // 0x12fe854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe858: b               #0x12fe120
    // 0x12fe85c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fe85c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fe860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe864: b               #0x12fe16c
    // 0x12fe868: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe868: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe86c: b               #0x12fe18c
    // 0x12fe870: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe870: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe874: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe874: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe878: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe878: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe87c: b               #0x12fe1f4
    // 0x12fe880: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe880: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe884: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe884: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe888: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe888: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe88c: b               #0x12fe2a8
    // 0x12fe890: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe890: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe894: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe894: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe898: b               #0x12fe308
    // 0x12fe89c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe89c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe8a0: b               #0x12fe338
    // 0x12fe8a4: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe8a4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe8a8: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe8a8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe8ac: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe8ac: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe8b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe8b4: b               #0x12fe448
    // 0x12fe8b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fe8b8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fe8bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fe8bc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fe8c0: SaveReg d2
    //     0x12fe8c0: str             q2, [SP, #-0x10]!
    // 0x12fe8c4: stp             x7, x8, [SP, #-0x10]!
    // 0x12fe8c8: stp             x5, x6, [SP, #-0x10]!
    // 0x12fe8cc: stp             x2, x4, [SP, #-0x10]!
    // 0x12fe8d0: r0 = AllocateDouble()
    //     0x12fe8d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fe8d4: mov             x3, x0
    // 0x12fe8d8: ldp             x2, x4, [SP], #0x10
    // 0x12fe8dc: ldp             x5, x6, [SP], #0x10
    // 0x12fe8e0: ldp             x7, x8, [SP], #0x10
    // 0x12fe8e4: RestoreReg d2
    //     0x12fe8e4: ldr             q2, [SP], #0x10
    // 0x12fe8e8: b               #0x12fe4e0
    // 0x12fe8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fe8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fe8f0: b               #0x12fe51c
    // 0x12fe8f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe8f4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe8f8: b               #0x12fe568
    // 0x12fe8fc: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe8fc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe900: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe900: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe904: b               #0x12fe61c
    // 0x12fe908: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe908: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe90c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe90c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe910: b               #0x12fe6bc
    // 0x12fe914: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe914: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe918: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe918: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe91c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12fe91c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12fe920: b               #0x12fe71c
    // 0x12fe924: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fe924: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12fe928: SaveReg d0
    //     0x12fe928: str             q0, [SP, #-0x10]!
    // 0x12fe92c: SaveReg r1
    //     0x12fe92c: str             x1, [SP, #-8]!
    // 0x12fe930: r0 = AllocateDouble()
    //     0x12fe930: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fe934: RestoreReg r1
    //     0x12fe934: ldr             x1, [SP], #8
    // 0x12fe938: RestoreReg d0
    //     0x12fe938: ldr             q0, [SP], #0x10
    // 0x12fe93c: b               #0x12fe7f4
  }
}

// class id: 3162, size: 0x10, field offset: 0x8
class PolynomialFit extends Object {

  late double confidence; // offset: 0xc
}

// class id: 3163, size: 0x14, field offset: 0x8
class _Matrix extends Object {

  _ get(/* No info */) {
    // ** addr: 0x12feb04, size: 0x40
    // 0x12feb04: LoadField: r4 = r1->field_f
    //     0x12feb04: ldur            w4, [x1, #0xf]
    // 0x12feb08: DecompressPointer r4
    //     0x12feb08: add             x4, x4, HEAP, lsl #32
    // 0x12feb0c: LoadField: r5 = r1->field_7
    //     0x12feb0c: ldur            x5, [x1, #7]
    // 0x12feb10: mul             x6, x2, x5
    // 0x12feb14: add             x2, x6, x3
    // 0x12feb18: LoadField: r3 = r4->field_13
    //     0x12feb18: ldur            w3, [x4, #0x13]
    // 0x12feb1c: r0 = LoadInt32Instr(r3)
    //     0x12feb1c: sbfx            x0, x3, #1, #0x1f
    // 0x12feb20: mov             x1, x2
    // 0x12feb24: cmp             x1, x0
    // 0x12feb28: b.hs            #0x12feb38
    // 0x12feb2c: ArrayLoad: d0 = r4[r2]  ; List_8
    //     0x12feb2c: add             x16, x4, x2, lsl #3
    //     0x12feb30: ldur            d0, [x16, #0x17]
    // 0x12feb34: ret
    //     0x12feb34: ret             
    // 0x12feb38: EnterFrame
    //     0x12feb38: stp             fp, lr, [SP, #-0x10]!
    //     0x12feb3c: mov             fp, SP
    // 0x12feb40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12feb40: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getRow(/* No info */) {
    // ** addr: 0x12fec98, size: 0x50
    // 0x12fec98: EnterFrame
    //     0x12fec98: stp             fp, lr, [SP, #-0x10]!
    //     0x12fec9c: mov             fp, SP
    // 0x12feca0: AllocStack(0x18)
    //     0x12feca0: sub             SP, SP, #0x18
    // 0x12feca4: LoadField: r0 = r1->field_f
    //     0x12feca4: ldur            w0, [x1, #0xf]
    // 0x12feca8: DecompressPointer r0
    //     0x12feca8: add             x0, x0, HEAP, lsl #32
    // 0x12fecac: stur            x0, [fp, #-0x18]
    // 0x12fecb0: LoadField: r3 = r1->field_7
    //     0x12fecb0: ldur            x3, [x1, #7]
    // 0x12fecb4: stur            x3, [fp, #-0x10]
    // 0x12fecb8: mul             x1, x2, x3
    // 0x12fecbc: stur            x1, [fp, #-8]
    // 0x12fecc0: r0 = _Vector()
    //     0x12fecc0: bl              #0x12fec50  ; Allocate_VectorStub -> _Vector (size=0x1c)
    // 0x12fecc4: ldur            x1, [fp, #-8]
    // 0x12fecc8: StoreField: r0->field_7 = r1
    //     0x12fecc8: stur            x1, [x0, #7]
    // 0x12feccc: ldur            x1, [fp, #-0x10]
    // 0x12fecd0: StoreField: r0->field_f = r1
    //     0x12fecd0: stur            x1, [x0, #0xf]
    // 0x12fecd4: ldur            x1, [fp, #-0x18]
    // 0x12fecd8: ArrayStore: r0[0] = r1  ; List_4
    //     0x12fecd8: stur            w1, [x0, #0x17]
    // 0x12fecdc: LeaveFrame
    //     0x12fecdc: mov             SP, fp
    //     0x12fece0: ldp             fp, lr, [SP], #0x10
    // 0x12fece4: ret
    //     0x12fece4: ret             
  }
  _ set(/* No info */) {
    // ** addr: 0x12fece8, size: 0x44
    // 0x12fece8: LoadField: r4 = r1->field_f
    //     0x12fece8: ldur            w4, [x1, #0xf]
    // 0x12fecec: DecompressPointer r4
    //     0x12fecec: add             x4, x4, HEAP, lsl #32
    // 0x12fecf0: LoadField: r5 = r1->field_7
    //     0x12fecf0: ldur            x5, [x1, #7]
    // 0x12fecf4: mul             x6, x2, x5
    // 0x12fecf8: add             x2, x6, x3
    // 0x12fecfc: LoadField: r3 = r4->field_13
    //     0x12fecfc: ldur            w3, [x4, #0x13]
    // 0x12fed00: r0 = LoadInt32Instr(r3)
    //     0x12fed00: sbfx            x0, x3, #1, #0x1f
    // 0x12fed04: mov             x1, x2
    // 0x12fed08: cmp             x1, x0
    // 0x12fed0c: b.hs            #0x12fed20
    // 0x12fed10: ArrayStore: r4[r2] = d0  ; List_8
    //     0x12fed10: add             x1, x4, x2, lsl #3
    //     0x12fed14: stur            d0, [x1, #0x17]
    // 0x12fed18: r0 = Null
    //     0x12fed18: mov             x0, NULL
    // 0x12fed1c: ret
    //     0x12fed1c: ret             
    // 0x12fed20: EnterFrame
    //     0x12fed20: stp             fp, lr, [SP, #-0x10]!
    //     0x12fed24: mov             fp, SP
    // 0x12fed28: r0 = RangeErrorSharedWithFPURegs()
    //     0x12fed28: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
}

// class id: 3164, size: 0x1c, field offset: 0x8
class _Vector extends Object {

  void []=(_Vector, int, double) {
    // ** addr: 0x12fe958, size: 0xe4
    // 0x12fe958: EnterFrame
    //     0x12fe958: stp             fp, lr, [SP, #-0x10]!
    //     0x12fe95c: mov             fp, SP
    // 0x12fe960: ldr             x0, [fp, #0x18]
    // 0x12fe964: r2 = Null
    //     0x12fe964: mov             x2, NULL
    // 0x12fe968: r1 = Null
    //     0x12fe968: mov             x1, NULL
    // 0x12fe96c: branchIfSmi(r0, 0x12fe994)
    //     0x12fe96c: tbz             w0, #0, #0x12fe994
    // 0x12fe970: r4 = LoadClassIdInstr(r0)
    //     0x12fe970: ldur            x4, [x0, #-1]
    //     0x12fe974: ubfx            x4, x4, #0xc, #0x14
    // 0x12fe978: sub             x4, x4, #0x3c
    // 0x12fe97c: cmp             x4, #1
    // 0x12fe980: b.ls            #0x12fe994
    // 0x12fe984: r8 = int
    //     0x12fe984: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x12fe988: r3 = Null
    //     0x12fe988: add             x3, PP, #0x96, lsl #12  ; [pp+0x96110] Null
    //     0x12fe98c: ldr             x3, [x3, #0x110]
    // 0x12fe990: r0 = int()
    //     0x12fe990: bl              #0x13ee980  ; IsType_int_Stub
    // 0x12fe994: ldr             x0, [fp, #0x10]
    // 0x12fe998: r2 = Null
    //     0x12fe998: mov             x2, NULL
    // 0x12fe99c: r1 = Null
    //     0x12fe99c: mov             x1, NULL
    // 0x12fe9a0: r4 = 60
    //     0x12fe9a0: mov             x4, #0x3c
    // 0x12fe9a4: branchIfSmi(r0, 0x12fe9b0)
    //     0x12fe9a4: tbz             w0, #0, #0x12fe9b0
    // 0x12fe9a8: r4 = LoadClassIdInstr(r0)
    //     0x12fe9a8: ldur            x4, [x0, #-1]
    //     0x12fe9ac: ubfx            x4, x4, #0xc, #0x14
    // 0x12fe9b0: cmp             x4, #0x3e
    // 0x12fe9b4: b.eq            #0x12fe9c8
    // 0x12fe9b8: r8 = double
    //     0x12fe9b8: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0x12fe9bc: r3 = Null
    //     0x12fe9bc: add             x3, PP, #0x96, lsl #12  ; [pp+0x96120] Null
    //     0x12fe9c0: ldr             x3, [x3, #0x120]
    // 0x12fe9c4: r0 = double()
    //     0x12fe9c4: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0x12fe9c8: ldr             x2, [fp, #0x20]
    // 0x12fe9cc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x12fe9cc: ldur            w3, [x2, #0x17]
    // 0x12fe9d0: DecompressPointer r3
    //     0x12fe9d0: add             x3, x3, HEAP, lsl #32
    // 0x12fe9d4: LoadField: r4 = r2->field_7
    //     0x12fe9d4: ldur            x4, [x2, #7]
    // 0x12fe9d8: ldr             x2, [fp, #0x18]
    // 0x12fe9dc: r5 = LoadInt32Instr(r2)
    //     0x12fe9dc: sbfx            x5, x2, #1, #0x1f
    //     0x12fe9e0: tbz             w2, #0, #0x12fe9e8
    //     0x12fe9e4: ldur            x5, [x2, #7]
    // 0x12fe9e8: add             x2, x5, x4
    // 0x12fe9ec: LoadField: r4 = r3->field_13
    //     0x12fe9ec: ldur            w4, [x3, #0x13]
    // 0x12fe9f0: r0 = LoadInt32Instr(r4)
    //     0x12fe9f0: sbfx            x0, x4, #1, #0x1f
    // 0x12fe9f4: mov             x1, x2
    // 0x12fe9f8: cmp             x1, x0
    // 0x12fe9fc: b.hs            #0x12fea20
    // 0x12fea00: ldr             x1, [fp, #0x10]
    // 0x12fea04: LoadField: d0 = r1->field_7
    //     0x12fea04: ldur            d0, [x1, #7]
    // 0x12fea08: ArrayStore: r3[r2] = d0  ; List_8
    //     0x12fea08: add             x1, x3, x2, lsl #3
    //     0x12fea0c: stur            d0, [x1, #0x17]
    // 0x12fea10: r0 = Null
    //     0x12fea10: mov             x0, NULL
    // 0x12fea14: LeaveFrame
    //     0x12fea14: mov             SP, fp
    //     0x12fea18: ldp             fp, lr, [SP], #0x10
    // 0x12fea1c: ret
    //     0x12fea1c: ret             
    // 0x12fea20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fea20: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  double [](_Vector, int) {
    // ** addr: 0x12fea3c, size: 0xe0
    // 0x12fea3c: EnterFrame
    //     0x12fea3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fea40: mov             fp, SP
    // 0x12fea44: ldr             x0, [fp, #0x10]
    // 0x12fea48: r2 = Null
    //     0x12fea48: mov             x2, NULL
    // 0x12fea4c: r1 = Null
    //     0x12fea4c: mov             x1, NULL
    // 0x12fea50: branchIfSmi(r0, 0x12fea78)
    //     0x12fea50: tbz             w0, #0, #0x12fea78
    // 0x12fea54: r4 = LoadClassIdInstr(r0)
    //     0x12fea54: ldur            x4, [x0, #-1]
    //     0x12fea58: ubfx            x4, x4, #0xc, #0x14
    // 0x12fea5c: sub             x4, x4, #0x3c
    // 0x12fea60: cmp             x4, #1
    // 0x12fea64: b.ls            #0x12fea78
    // 0x12fea68: r8 = int
    //     0x12fea68: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x12fea6c: r3 = Null
    //     0x12fea6c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96130] Null
    //     0x12fea70: ldr             x3, [x3, #0x130]
    // 0x12fea74: r0 = int()
    //     0x12fea74: bl              #0x13ee980  ; IsType_int_Stub
    // 0x12fea78: ldr             x2, [fp, #0x18]
    // 0x12fea7c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x12fea7c: ldur            w3, [x2, #0x17]
    // 0x12fea80: DecompressPointer r3
    //     0x12fea80: add             x3, x3, HEAP, lsl #32
    // 0x12fea84: LoadField: r4 = r2->field_7
    //     0x12fea84: ldur            x4, [x2, #7]
    // 0x12fea88: ldr             x2, [fp, #0x10]
    // 0x12fea8c: r5 = LoadInt32Instr(r2)
    //     0x12fea8c: sbfx            x5, x2, #1, #0x1f
    //     0x12fea90: tbz             w2, #0, #0x12fea98
    //     0x12fea94: ldur            x5, [x2, #7]
    // 0x12fea98: add             x2, x5, x4
    // 0x12fea9c: LoadField: r4 = r3->field_13
    //     0x12fea9c: ldur            w4, [x3, #0x13]
    // 0x12feaa0: r0 = LoadInt32Instr(r4)
    //     0x12feaa0: sbfx            x0, x4, #1, #0x1f
    // 0x12feaa4: mov             x1, x2
    // 0x12feaa8: cmp             x1, x0
    // 0x12feaac: b.hs            #0x12feaf0
    // 0x12feab0: ArrayLoad: d0 = r3[r2]  ; List_8
    //     0x12feab0: add             x16, x3, x2, lsl #3
    //     0x12feab4: ldur            d0, [x16, #0x17]
    // 0x12feab8: r0 = inline_Allocate_Double()
    //     0x12feab8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12feabc: add             x0, x0, #0x10
    //     0x12feac0: cmp             x1, x0
    //     0x12feac4: b.ls            #0x12feaf4
    //     0x12feac8: str             x0, [THR, #0x60]  ; THR::top
    //     0x12feacc: sub             x0, x0, #0xf
    //     0x12fead0: mov             x1, #0xe19c
    //     0x12fead4: movk            x1, #3, lsl #16
    //     0x12fead8: stur            x1, [x0, #-1]
    // 0x12feadc: dmb             ishst
    // 0x12feae0: StoreField: r0->field_7 = d0
    //     0x12feae0: stur            d0, [x0, #7]
    // 0x12feae4: LeaveFrame
    //     0x12feae4: mov             SP, fp
    //     0x12feae8: ldp             fp, lr, [SP], #0x10
    // 0x12feaec: ret
    //     0x12feaec: ret             
    // 0x12feaf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12feaf0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12feaf4: SaveReg d0
    //     0x12feaf4: str             q0, [SP, #-0x10]!
    // 0x12feaf8: r0 = AllocateDouble()
    //     0x12feaf8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12feafc: RestoreReg d0
    //     0x12feafc: ldr             q0, [SP], #0x10
    // 0x12feb00: b               #0x12feae0
  }
  _ *(/* No info */) {
    // ** addr: 0x12feb44, size: 0xbc
    // 0x12feb44: EnterFrame
    //     0x12feb44: stp             fp, lr, [SP, #-0x10]!
    //     0x12feb48: mov             fp, SP
    // 0x12feb4c: LoadField: r3 = r1->field_f
    //     0x12feb4c: ldur            x3, [x1, #0xf]
    // 0x12feb50: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x12feb50: ldur            w4, [x1, #0x17]
    // 0x12feb54: DecompressPointer r4
    //     0x12feb54: add             x4, x4, HEAP, lsl #32
    // 0x12feb58: LoadField: r5 = r1->field_7
    //     0x12feb58: ldur            x5, [x1, #7]
    // 0x12feb5c: LoadField: r6 = r4->field_13
    //     0x12feb5c: ldur            w6, [x4, #0x13]
    // 0x12feb60: r7 = LoadInt32Instr(r6)
    //     0x12feb60: sbfx            x7, x6, #1, #0x1f
    // 0x12feb64: ArrayLoad: r6 = r2[0]  ; List_4
    //     0x12feb64: ldur            w6, [x2, #0x17]
    // 0x12feb68: DecompressPointer r6
    //     0x12feb68: add             x6, x6, HEAP, lsl #32
    // 0x12feb6c: LoadField: r8 = r2->field_7
    //     0x12feb6c: ldur            x8, [x2, #7]
    // 0x12feb70: LoadField: r2 = r6->field_13
    //     0x12feb70: ldur            w2, [x6, #0x13]
    // 0x12feb74: r9 = LoadInt32Instr(r2)
    //     0x12feb74: sbfx            x9, x2, #1, #0x1f
    // 0x12feb78: d0 = 0.000000
    //     0x12feb78: eor             v0.16b, v0.16b, v0.16b
    // 0x12feb7c: r2 = 0
    //     0x12feb7c: mov             x2, #0
    // 0x12feb80: CheckStackOverflow
    //     0x12feb80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12feb84: cmp             SP, x16
    //     0x12feb88: b.ls            #0x12febf0
    // 0x12feb8c: cmp             x2, x3
    // 0x12feb90: b.ge            #0x12febe4
    // 0x12feb94: add             x10, x2, x5
    // 0x12feb98: mov             x0, x7
    // 0x12feb9c: mov             x1, x10
    // 0x12feba0: cmp             x1, x0
    // 0x12feba4: b.hs            #0x12febf8
    // 0x12feba8: ArrayLoad: d1 = r4[r10]  ; List_8
    //     0x12feba8: add             x16, x4, x10, lsl #3
    //     0x12febac: ldur            d1, [x16, #0x17]
    // 0x12febb0: add             x10, x2, x8
    // 0x12febb4: mov             x0, x9
    // 0x12febb8: mov             x1, x10
    // 0x12febbc: cmp             x1, x0
    // 0x12febc0: b.hs            #0x12febfc
    // 0x12febc4: ArrayLoad: d2 = r6[r10]  ; List_8
    //     0x12febc4: add             x16, x6, x10, lsl #3
    //     0x12febc8: ldur            d2, [x16, #0x17]
    // 0x12febcc: fmul            d3, d1, d2
    // 0x12febd0: fadd            d1, d0, d3
    // 0x12febd4: add             x0, x2, #1
    // 0x12febd8: mov             v0.16b, v1.16b
    // 0x12febdc: mov             x2, x0
    // 0x12febe0: b               #0x12feb80
    // 0x12febe4: LeaveFrame
    //     0x12febe4: mov             SP, fp
    //     0x12febe8: ldp             fp, lr, [SP], #0x10
    // 0x12febec: ret
    //     0x12febec: ret             
    // 0x12febf0: r0 = StackOverflowSharedWithFPURegs()
    //     0x12febf0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12febf4: b               #0x12feb8c
    // 0x12febf8: r0 = RangeErrorSharedWithFPURegs()
    //     0x12febf8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0x12febfc: r0 = RangeErrorSharedWithFPURegs()
    //     0x12febfc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  void []=(_Vector, int, double) {
    // ** addr: 0x12fec00, size: 0x50
    // 0x12fec00: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x12fec00: ldur            w4, [x1, #0x17]
    // 0x12fec04: DecompressPointer r4
    //     0x12fec04: add             x4, x4, HEAP, lsl #32
    // 0x12fec08: LoadField: r5 = r1->field_7
    //     0x12fec08: ldur            x5, [x1, #7]
    // 0x12fec0c: r6 = LoadInt32Instr(r2)
    //     0x12fec0c: sbfx            x6, x2, #1, #0x1f
    //     0x12fec10: tbz             w2, #0, #0x12fec18
    //     0x12fec14: ldur            x6, [x2, #7]
    // 0x12fec18: add             x2, x6, x5
    // 0x12fec1c: LoadField: r5 = r4->field_13
    //     0x12fec1c: ldur            w5, [x4, #0x13]
    // 0x12fec20: r0 = LoadInt32Instr(r5)
    //     0x12fec20: sbfx            x0, x5, #1, #0x1f
    // 0x12fec24: mov             x1, x2
    // 0x12fec28: cmp             x1, x0
    // 0x12fec2c: b.hs            #0x12fec44
    // 0x12fec30: LoadField: d0 = r3->field_7
    //     0x12fec30: ldur            d0, [x3, #7]
    // 0x12fec34: ArrayStore: r4[r2] = d0  ; List_8
    //     0x12fec34: add             x1, x4, x2, lsl #3
    //     0x12fec38: stur            d0, [x1, #0x17]
    // 0x12fec3c: r0 = Null
    //     0x12fec3c: mov             x0, NULL
    // 0x12fec40: ret
    //     0x12fec40: ret             
    // 0x12fec44: EnterFrame
    //     0x12fec44: stp             fp, lr, [SP, #-0x10]!
    //     0x12fec48: mov             fp, SP
    // 0x12fec4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fec4c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ norm(/* No info */) {
    // ** addr: 0x12fec5c, size: 0x3c
    // 0x12fec5c: EnterFrame
    //     0x12fec5c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fec60: mov             fp, SP
    // 0x12fec64: mov             x2, x1
    // 0x12fec68: CheckStackOverflow
    //     0x12fec68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fec6c: cmp             SP, x16
    //     0x12fec70: b.ls            #0x12fec90
    // 0x12fec74: mov             x1, x2
    // 0x12fec78: r0 = *()
    //     0x12fec78: bl              #0x12feb44  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::*
    // 0x12fec7c: fsqrt           d1, d0
    // 0x12fec80: mov             v0.16b, v1.16b
    // 0x12fec84: LeaveFrame
    //     0x12fec84: mov             SP, fp
    //     0x12fec88: ldp             fp, lr, [SP], #0x10
    // 0x12fec8c: ret
    //     0x12fec8c: ret             
    // 0x12fec90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fec90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fec94: b               #0x12fec74
  }
}
