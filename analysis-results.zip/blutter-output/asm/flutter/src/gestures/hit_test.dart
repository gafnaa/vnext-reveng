// lib: , url: package:flutter/src/gestures/hit_test.dart

// class id: 1048824, size: 0x8
class :: {
}

// class id: 3165, size: 0x14, field offset: 0x8
class HitTestResult extends Object {

  _ add(/* No info */) {
    // ** addr: 0x836754, size: 0xec
    // 0x836754: EnterFrame
    //     0x836754: stp             fp, lr, [SP, #-0x10]!
    //     0x836758: mov             fp, SP
    // 0x83675c: AllocStack(0x20)
    //     0x83675c: sub             SP, SP, #0x20
    // 0x836760: SetupParameters(HitTestResult this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x836760: mov             x0, x2
    //     0x836764: stur            x2, [fp, #-0x10]
    //     0x836768: mov             x2, x1
    //     0x83676c: stur            x1, [fp, #-8]
    // 0x836770: CheckStackOverflow
    //     0x836770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836774: cmp             SP, x16
    //     0x836778: b.ls            #0x836838
    // 0x83677c: mov             x1, x2
    // 0x836780: r0 = _lastTransform()
    //     0x836780: bl              #0x836864  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::_lastTransform
    // 0x836784: ldur            x2, [fp, #-0x10]
    // 0x836788: StoreField: r2->field_f = r0
    //     0x836788: stur            w0, [x2, #0xf]
    //     0x83678c: ldurb           w16, [x2, #-1]
    //     0x836790: ldurb           w17, [x0, #-1]
    //     0x836794: and             x16, x17, x16, lsr #2
    //     0x836798: tst             x16, HEAP, lsr #32
    //     0x83679c: b.eq            #0x8367a4
    //     0x8367a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8367a4: ldur            x0, [fp, #-8]
    // 0x8367a8: LoadField: r3 = r0->field_7
    //     0x8367a8: ldur            w3, [x0, #7]
    // 0x8367ac: DecompressPointer r3
    //     0x8367ac: add             x3, x3, HEAP, lsl #32
    // 0x8367b0: stur            x3, [fp, #-0x20]
    // 0x8367b4: LoadField: r0 = r3->field_b
    //     0x8367b4: ldur            w0, [x3, #0xb]
    // 0x8367b8: LoadField: r1 = r3->field_f
    //     0x8367b8: ldur            w1, [x3, #0xf]
    // 0x8367bc: DecompressPointer r1
    //     0x8367bc: add             x1, x1, HEAP, lsl #32
    // 0x8367c0: LoadField: r4 = r1->field_b
    //     0x8367c0: ldur            w4, [x1, #0xb]
    // 0x8367c4: r5 = LoadInt32Instr(r0)
    //     0x8367c4: sbfx            x5, x0, #1, #0x1f
    // 0x8367c8: stur            x5, [fp, #-0x18]
    // 0x8367cc: r0 = LoadInt32Instr(r4)
    //     0x8367cc: sbfx            x0, x4, #1, #0x1f
    // 0x8367d0: cmp             x5, x0
    // 0x8367d4: b.ne            #0x8367e0
    // 0x8367d8: mov             x1, x3
    // 0x8367dc: r0 = _growToNextCapacity()
    //     0x8367dc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8367e0: ldur            x2, [fp, #-0x20]
    // 0x8367e4: ldur            x3, [fp, #-0x18]
    // 0x8367e8: add             x4, x3, #1
    // 0x8367ec: lsl             x5, x4, #1
    // 0x8367f0: StoreField: r2->field_b = r5
    //     0x8367f0: stur            w5, [x2, #0xb]
    // 0x8367f4: LoadField: r1 = r2->field_f
    //     0x8367f4: ldur            w1, [x2, #0xf]
    // 0x8367f8: DecompressPointer r1
    //     0x8367f8: add             x1, x1, HEAP, lsl #32
    // 0x8367fc: ldur            x0, [fp, #-0x10]
    // 0x836800: ArrayStore: r1[r3] = r0  ; List_4
    //     0x836800: add             x25, x1, x3, lsl #2
    //     0x836804: add             x25, x25, #0xf
    //     0x836808: str             w0, [x25]
    //     0x83680c: tbz             w0, #0, #0x836828
    //     0x836810: ldurb           w16, [x1, #-1]
    //     0x836814: ldurb           w17, [x0, #-1]
    //     0x836818: and             x16, x17, x16, lsr #2
    //     0x83681c: tst             x16, HEAP, lsr #32
    //     0x836820: b.eq            #0x836828
    //     0x836824: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x836828: r0 = Null
    //     0x836828: mov             x0, NULL
    // 0x83682c: LeaveFrame
    //     0x83682c: mov             SP, fp
    //     0x836830: ldp             fp, lr, [SP], #0x10
    // 0x836834: ret
    //     0x836834: ret             
    // 0x836838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83683c: b               #0x83677c
  }
  get _ _lastTransform(/* No info */) {
    // ** addr: 0x836864, size: 0x4c
    // 0x836864: EnterFrame
    //     0x836864: stp             fp, lr, [SP, #-0x10]!
    //     0x836868: mov             fp, SP
    // 0x83686c: AllocStack(0x8)
    //     0x83686c: sub             SP, SP, #8
    // 0x836870: SetupParameters(HitTestResult this /* r1 => r0, fp-0x8 */)
    //     0x836870: mov             x0, x1
    //     0x836874: stur            x1, [fp, #-8]
    // 0x836878: CheckStackOverflow
    //     0x836878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83687c: cmp             SP, x16
    //     0x836880: b.ls            #0x8368a8
    // 0x836884: mov             x1, x0
    // 0x836888: r0 = _globalizeTransforms()
    //     0x836888: bl              #0x8368b0  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::_globalizeTransforms
    // 0x83688c: ldur            x0, [fp, #-8]
    // 0x836890: LoadField: r1 = r0->field_b
    //     0x836890: ldur            w1, [x0, #0xb]
    // 0x836894: DecompressPointer r1
    //     0x836894: add             x1, x1, HEAP, lsl #32
    // 0x836898: r0 = last()
    //     0x836898: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x83689c: LeaveFrame
    //     0x83689c: mov             SP, fp
    //     0x8368a0: ldp             fp, lr, [SP], #0x10
    // 0x8368a4: ret
    //     0x8368a4: ret             
    // 0x8368a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8368a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8368ac: b               #0x836884
  }
  _ _globalizeTransforms(/* No info */) {
    // ** addr: 0x8368b0, size: 0x1a4
    // 0x8368b0: EnterFrame
    //     0x8368b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8368b4: mov             fp, SP
    // 0x8368b8: AllocStack(0x30)
    //     0x8368b8: sub             SP, SP, #0x30
    // 0x8368bc: CheckStackOverflow
    //     0x8368bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8368c0: cmp             SP, x16
    //     0x8368c4: b.ls            #0x836a44
    // 0x8368c8: LoadField: r0 = r1->field_f
    //     0x8368c8: ldur            w0, [x1, #0xf]
    // 0x8368cc: DecompressPointer r0
    //     0x8368cc: add             x0, x0, HEAP, lsl #32
    // 0x8368d0: stur            x0, [fp, #-0x10]
    // 0x8368d4: LoadField: r2 = r0->field_b
    //     0x8368d4: ldur            w2, [x0, #0xb]
    // 0x8368d8: cbnz            w2, #0x8368ec
    // 0x8368dc: r0 = Null
    //     0x8368dc: mov             x0, NULL
    // 0x8368e0: LeaveFrame
    //     0x8368e0: mov             SP, fp
    //     0x8368e4: ldp             fp, lr, [SP], #0x10
    // 0x8368e8: ret
    //     0x8368e8: ret             
    // 0x8368ec: LoadField: r2 = r1->field_b
    //     0x8368ec: ldur            w2, [x1, #0xb]
    // 0x8368f0: DecompressPointer r2
    //     0x8368f0: add             x2, x2, HEAP, lsl #32
    // 0x8368f4: mov             x1, x2
    // 0x8368f8: stur            x2, [fp, #-8]
    // 0x8368fc: r0 = last()
    //     0x8368fc: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x836900: ldur            x3, [fp, #-0x10]
    // 0x836904: LoadField: r1 = r3->field_b
    //     0x836904: ldur            w1, [x3, #0xb]
    // 0x836908: r4 = LoadInt32Instr(r1)
    //     0x836908: sbfx            x4, x1, #1, #0x1f
    // 0x83690c: stur            x4, [fp, #-0x20]
    // 0x836910: mov             x2, x0
    // 0x836914: ldur            x5, [fp, #-8]
    // 0x836918: r0 = 0
    //     0x836918: mov             x0, #0
    // 0x83691c: CheckStackOverflow
    //     0x83691c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836920: cmp             SP, x16
    //     0x836924: b.ls            #0x836a4c
    // 0x836928: LoadField: r1 = r3->field_b
    //     0x836928: ldur            w1, [x3, #0xb]
    // 0x83692c: r6 = LoadInt32Instr(r1)
    //     0x83692c: sbfx            x6, x1, #1, #0x1f
    // 0x836930: cmp             x4, x6
    // 0x836934: b.ne            #0x836a24
    // 0x836938: cmp             x0, x6
    // 0x83693c: b.ge            #0x836a0c
    // 0x836940: LoadField: r1 = r3->field_f
    //     0x836940: ldur            w1, [x3, #0xf]
    // 0x836944: DecompressPointer r1
    //     0x836944: add             x1, x1, HEAP, lsl #32
    // 0x836948: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x836948: add             x16, x1, x0, lsl #2
    //     0x83694c: ldur            w6, [x16, #0xf]
    // 0x836950: DecompressPointer r6
    //     0x836950: add             x6, x6, HEAP, lsl #32
    // 0x836954: add             x7, x0, #1
    // 0x836958: stur            x7, [fp, #-0x18]
    // 0x83695c: r0 = LoadClassIdInstr(r6)
    //     0x83695c: ldur            x0, [x6, #-1]
    //     0x836960: ubfx            x0, x0, #0xc, #0x14
    // 0x836964: mov             x1, x6
    // 0x836968: r0 = GDT[cid_x0 + -0x1000]()
    //     0x836968: sub             lr, x0, #1, lsl #12
    //     0x83696c: ldr             lr, [x21, lr, lsl #3]
    //     0x836970: blr             lr
    // 0x836974: mov             x2, x0
    // 0x836978: ldur            x0, [fp, #-8]
    // 0x83697c: stur            x2, [fp, #-0x30]
    // 0x836980: LoadField: r1 = r0->field_b
    //     0x836980: ldur            w1, [x0, #0xb]
    // 0x836984: LoadField: r3 = r0->field_f
    //     0x836984: ldur            w3, [x0, #0xf]
    // 0x836988: DecompressPointer r3
    //     0x836988: add             x3, x3, HEAP, lsl #32
    // 0x83698c: LoadField: r4 = r3->field_b
    //     0x83698c: ldur            w4, [x3, #0xb]
    // 0x836990: r3 = LoadInt32Instr(r1)
    //     0x836990: sbfx            x3, x1, #1, #0x1f
    // 0x836994: stur            x3, [fp, #-0x28]
    // 0x836998: r1 = LoadInt32Instr(r4)
    //     0x836998: sbfx            x1, x4, #1, #0x1f
    // 0x83699c: cmp             x3, x1
    // 0x8369a0: b.ne            #0x8369ac
    // 0x8369a4: mov             x1, x0
    // 0x8369a8: r0 = _growToNextCapacity()
    //     0x8369a8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8369ac: ldur            x3, [fp, #-8]
    // 0x8369b0: ldur            x2, [fp, #-0x28]
    // 0x8369b4: add             x0, x2, #1
    // 0x8369b8: lsl             x1, x0, #1
    // 0x8369bc: StoreField: r3->field_b = r1
    //     0x8369bc: stur            w1, [x3, #0xb]
    // 0x8369c0: LoadField: r1 = r3->field_f
    //     0x8369c0: ldur            w1, [x3, #0xf]
    // 0x8369c4: DecompressPointer r1
    //     0x8369c4: add             x1, x1, HEAP, lsl #32
    // 0x8369c8: ldur            x0, [fp, #-0x30]
    // 0x8369cc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8369cc: add             x25, x1, x2, lsl #2
    //     0x8369d0: add             x25, x25, #0xf
    //     0x8369d4: str             w0, [x25]
    //     0x8369d8: tbz             w0, #0, #0x8369f4
    //     0x8369dc: ldurb           w16, [x1, #-1]
    //     0x8369e0: ldurb           w17, [x0, #-1]
    //     0x8369e4: and             x16, x17, x16, lsr #2
    //     0x8369e8: tst             x16, HEAP, lsr #32
    //     0x8369ec: b.eq            #0x8369f4
    //     0x8369f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8369f4: ldur            x2, [fp, #-0x30]
    // 0x8369f8: ldur            x0, [fp, #-0x18]
    // 0x8369fc: mov             x5, x3
    // 0x836a00: ldur            x3, [fp, #-0x10]
    // 0x836a04: ldur            x4, [fp, #-0x20]
    // 0x836a08: b               #0x83691c
    // 0x836a0c: ldur            x1, [fp, #-0x10]
    // 0x836a10: r0 = clear()
    //     0x836a10: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x836a14: r0 = Null
    //     0x836a14: mov             x0, NULL
    // 0x836a18: LeaveFrame
    //     0x836a18: mov             SP, fp
    //     0x836a1c: ldp             fp, lr, [SP], #0x10
    // 0x836a20: ret
    //     0x836a20: ret             
    // 0x836a24: mov             x0, x3
    // 0x836a28: r0 = ConcurrentModificationError()
    //     0x836a28: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x836a2c: mov             x1, x0
    // 0x836a30: ldur            x0, [fp, #-0x10]
    // 0x836a34: StoreField: r1->field_b = r0
    //     0x836a34: stur            w0, [x1, #0xb]
    // 0x836a38: mov             x0, x1
    // 0x836a3c: r0 = Throw()
    //     0x836a3c: bl              #0x13ddb2c  ; ThrowStub
    // 0x836a40: brk             #0
    // 0x836a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836a48: b               #0x8368c8
    // 0x836a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836a4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836a50: b               #0x836928
  }
  _ HitTestResult(/* No info */) {
    // ** addr: 0x836bac, size: 0x110
    // 0x836bac: EnterFrame
    //     0x836bac: stp             fp, lr, [SP, #-0x10]!
    //     0x836bb0: mov             fp, SP
    // 0x836bb4: AllocStack(0x18)
    //     0x836bb4: sub             SP, SP, #0x18
    // 0x836bb8: SetupParameters(HitTestResult this /* r1 => r0, fp-0x8 */)
    //     0x836bb8: mov             x0, x1
    //     0x836bbc: stur            x1, [fp, #-8]
    // 0x836bc0: CheckStackOverflow
    //     0x836bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836bc4: cmp             SP, x16
    //     0x836bc8: b.ls            #0x836cb4
    // 0x836bcc: r1 = <HitTestEntry<HitTestTarget>>
    //     0x836bcc: ldr             x1, [PP, #0x2ef8]  ; [pp+0x2ef8] TypeArguments: <HitTestEntry<HitTestTarget>>
    // 0x836bd0: r2 = 0
    //     0x836bd0: mov             x2, #0
    // 0x836bd4: r0 = _GrowableList()
    //     0x836bd4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x836bd8: ldur            x1, [fp, #-8]
    // 0x836bdc: StoreField: r1->field_7 = r0
    //     0x836bdc: stur            w0, [x1, #7]
    //     0x836be0: ldurb           w16, [x1, #-1]
    //     0x836be4: ldurb           w17, [x0, #-1]
    //     0x836be8: and             x16, x17, x16, lsr #2
    //     0x836bec: tst             x16, HEAP, lsr #32
    //     0x836bf0: b.eq            #0x836bf8
    //     0x836bf4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x836bf8: r0 = Matrix4()
    //     0x836bf8: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x836bfc: r4 = 32
    //     0x836bfc: mov             x4, #0x20
    // 0x836c00: stur            x0, [fp, #-0x10]
    // 0x836c04: r0 = AllocateFloat64Array()
    //     0x836c04: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x836c08: mov             x1, x0
    // 0x836c0c: ldur            x0, [fp, #-0x10]
    // 0x836c10: StoreField: r0->field_7 = r1
    //     0x836c10: stur            w1, [x0, #7]
    // 0x836c14: mov             x1, x0
    // 0x836c18: r0 = setIdentity()
    //     0x836c18: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x836c1c: r1 = Null
    //     0x836c1c: mov             x1, NULL
    // 0x836c20: r2 = 2
    //     0x836c20: mov             x2, #2
    // 0x836c24: r0 = AllocateArray()
    //     0x836c24: bl              #0x13df928  ; AllocateArrayStub
    // 0x836c28: mov             x2, x0
    // 0x836c2c: ldur            x0, [fp, #-0x10]
    // 0x836c30: stur            x2, [fp, #-0x18]
    // 0x836c34: StoreField: r2->field_f = r0
    //     0x836c34: stur            w0, [x2, #0xf]
    // 0x836c38: r1 = <Matrix4>
    //     0x836c38: ldr             x1, [PP, #0x2f00]  ; [pp+0x2f00] TypeArguments: <Matrix4>
    // 0x836c3c: r0 = AllocateGrowableArray()
    //     0x836c3c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x836c40: mov             x1, x0
    // 0x836c44: ldur            x0, [fp, #-0x18]
    // 0x836c48: StoreField: r1->field_f = r0
    //     0x836c48: stur            w0, [x1, #0xf]
    // 0x836c4c: r0 = 2
    //     0x836c4c: mov             x0, #2
    // 0x836c50: StoreField: r1->field_b = r0
    //     0x836c50: stur            w0, [x1, #0xb]
    // 0x836c54: mov             x0, x1
    // 0x836c58: ldur            x3, [fp, #-8]
    // 0x836c5c: StoreField: r3->field_b = r0
    //     0x836c5c: stur            w0, [x3, #0xb]
    //     0x836c60: ldurb           w16, [x3, #-1]
    //     0x836c64: ldurb           w17, [x0, #-1]
    //     0x836c68: and             x16, x17, x16, lsr #2
    //     0x836c6c: tst             x16, HEAP, lsr #32
    //     0x836c70: b.eq            #0x836c78
    //     0x836c74: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x836c78: r1 = <_TransformPart>
    //     0x836c78: ldr             x1, [PP, #0x2f08]  ; [pp+0x2f08] TypeArguments: <_TransformPart>
    // 0x836c7c: r2 = 0
    //     0x836c7c: mov             x2, #0
    // 0x836c80: r0 = _GrowableList()
    //     0x836c80: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x836c84: ldur            x1, [fp, #-8]
    // 0x836c88: StoreField: r1->field_f = r0
    //     0x836c88: stur            w0, [x1, #0xf]
    //     0x836c8c: ldurb           w16, [x1, #-1]
    //     0x836c90: ldurb           w17, [x0, #-1]
    //     0x836c94: and             x16, x17, x16, lsr #2
    //     0x836c98: tst             x16, HEAP, lsr #32
    //     0x836c9c: b.eq            #0x836ca4
    //     0x836ca0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x836ca4: r0 = Null
    //     0x836ca4: mov             x0, NULL
    // 0x836ca8: LeaveFrame
    //     0x836ca8: mov             SP, fp
    //     0x836cac: ldp             fp, lr, [SP], #0x10
    // 0x836cb0: ret
    //     0x836cb0: ret             
    // 0x836cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836cb8: b               #0x836bcc
  }
  _ popTransform(/* No info */) {
    // ** addr: 0xaf9850, size: 0x9c
    // 0xaf9850: EnterFrame
    //     0xaf9850: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9854: mov             fp, SP
    // 0xaf9858: CheckStackOverflow
    //     0xaf9858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf985c: cmp             SP, x16
    //     0xaf9860: b.ls            #0xaf98dc
    // 0xaf9864: LoadField: r2 = r1->field_f
    //     0xaf9864: ldur            w2, [x1, #0xf]
    // 0xaf9868: DecompressPointer r2
    //     0xaf9868: add             x2, x2, HEAP, lsl #32
    // 0xaf986c: LoadField: r0 = r2->field_b
    //     0xaf986c: ldur            w0, [x2, #0xb]
    // 0xaf9870: r3 = LoadInt32Instr(r0)
    //     0xaf9870: sbfx            x3, x0, #1, #0x1f
    // 0xaf9874: cbz             w0, #0xaf989c
    // 0xaf9878: sub             x4, x3, #1
    // 0xaf987c: mov             x0, x3
    // 0xaf9880: mov             x1, x4
    // 0xaf9884: cmp             x1, x0
    // 0xaf9888: b.hs            #0xaf98e4
    // 0xaf988c: mov             x1, x2
    // 0xaf9890: mov             x2, x4
    // 0xaf9894: r0 = length=()
    //     0xaf9894: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0xaf9898: b               #0xaf98cc
    // 0xaf989c: LoadField: r2 = r1->field_b
    //     0xaf989c: ldur            w2, [x1, #0xb]
    // 0xaf98a0: DecompressPointer r2
    //     0xaf98a0: add             x2, x2, HEAP, lsl #32
    // 0xaf98a4: LoadField: r0 = r2->field_b
    //     0xaf98a4: ldur            w0, [x2, #0xb]
    // 0xaf98a8: r1 = LoadInt32Instr(r0)
    //     0xaf98a8: sbfx            x1, x0, #1, #0x1f
    // 0xaf98ac: sub             x3, x1, #1
    // 0xaf98b0: mov             x0, x1
    // 0xaf98b4: mov             x1, x3
    // 0xaf98b8: cmp             x1, x0
    // 0xaf98bc: b.hs            #0xaf98e8
    // 0xaf98c0: mov             x1, x2
    // 0xaf98c4: mov             x2, x3
    // 0xaf98c8: r0 = length=()
    //     0xaf98c8: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0xaf98cc: r0 = Null
    //     0xaf98cc: mov             x0, NULL
    // 0xaf98d0: LeaveFrame
    //     0xaf98d0: mov             SP, fp
    //     0xaf98d4: ldp             fp, lr, [SP], #0x10
    // 0xaf98d8: ret
    //     0xaf98d8: ret             
    // 0xaf98dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf98dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf98e0: b               #0xaf9864
    // 0xaf98e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf98e4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf98e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf98e8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ pushTransform(/* No info */) {
    // ** addr: 0xaf98ec, size: 0xcc
    // 0xaf98ec: EnterFrame
    //     0xaf98ec: stp             fp, lr, [SP, #-0x10]!
    //     0xaf98f0: mov             fp, SP
    // 0xaf98f4: AllocStack(0x20)
    //     0xaf98f4: sub             SP, SP, #0x20
    // 0xaf98f8: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xaf98f8: stur            x2, [fp, #-0x10]
    // 0xaf98fc: CheckStackOverflow
    //     0xaf98fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9900: cmp             SP, x16
    //     0xaf9904: b.ls            #0xaf99b0
    // 0xaf9908: LoadField: r0 = r1->field_f
    //     0xaf9908: ldur            w0, [x1, #0xf]
    // 0xaf990c: DecompressPointer r0
    //     0xaf990c: add             x0, x0, HEAP, lsl #32
    // 0xaf9910: stur            x0, [fp, #-8]
    // 0xaf9914: r0 = _MatrixTransformPart()
    //     0xaf9914: bl              #0xaf99b8  ; Allocate_MatrixTransformPartStub -> _MatrixTransformPart (size=0xc)
    // 0xaf9918: mov             x2, x0
    // 0xaf991c: ldur            x0, [fp, #-0x10]
    // 0xaf9920: stur            x2, [fp, #-0x20]
    // 0xaf9924: StoreField: r2->field_7 = r0
    //     0xaf9924: stur            w0, [x2, #7]
    // 0xaf9928: ldur            x0, [fp, #-8]
    // 0xaf992c: LoadField: r1 = r0->field_b
    //     0xaf992c: ldur            w1, [x0, #0xb]
    // 0xaf9930: LoadField: r3 = r0->field_f
    //     0xaf9930: ldur            w3, [x0, #0xf]
    // 0xaf9934: DecompressPointer r3
    //     0xaf9934: add             x3, x3, HEAP, lsl #32
    // 0xaf9938: LoadField: r4 = r3->field_b
    //     0xaf9938: ldur            w4, [x3, #0xb]
    // 0xaf993c: r3 = LoadInt32Instr(r1)
    //     0xaf993c: sbfx            x3, x1, #1, #0x1f
    // 0xaf9940: stur            x3, [fp, #-0x18]
    // 0xaf9944: r1 = LoadInt32Instr(r4)
    //     0xaf9944: sbfx            x1, x4, #1, #0x1f
    // 0xaf9948: cmp             x3, x1
    // 0xaf994c: b.ne            #0xaf9958
    // 0xaf9950: mov             x1, x0
    // 0xaf9954: r0 = _growToNextCapacity()
    //     0xaf9954: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xaf9958: ldur            x2, [fp, #-8]
    // 0xaf995c: ldur            x3, [fp, #-0x18]
    // 0xaf9960: add             x4, x3, #1
    // 0xaf9964: lsl             x5, x4, #1
    // 0xaf9968: StoreField: r2->field_b = r5
    //     0xaf9968: stur            w5, [x2, #0xb]
    // 0xaf996c: LoadField: r1 = r2->field_f
    //     0xaf996c: ldur            w1, [x2, #0xf]
    // 0xaf9970: DecompressPointer r1
    //     0xaf9970: add             x1, x1, HEAP, lsl #32
    // 0xaf9974: ldur            x0, [fp, #-0x20]
    // 0xaf9978: ArrayStore: r1[r3] = r0  ; List_4
    //     0xaf9978: add             x25, x1, x3, lsl #2
    //     0xaf997c: add             x25, x25, #0xf
    //     0xaf9980: str             w0, [x25]
    //     0xaf9984: tbz             w0, #0, #0xaf99a0
    //     0xaf9988: ldurb           w16, [x1, #-1]
    //     0xaf998c: ldurb           w17, [x0, #-1]
    //     0xaf9990: and             x16, x17, x16, lsr #2
    //     0xaf9994: tst             x16, HEAP, lsr #32
    //     0xaf9998: b.eq            #0xaf99a0
    //     0xaf999c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xaf99a0: r0 = Null
    //     0xaf99a0: mov             x0, NULL
    // 0xaf99a4: LeaveFrame
    //     0xaf99a4: mov             SP, fp
    //     0xaf99a8: ldp             fp, lr, [SP], #0x10
    // 0xaf99ac: ret
    //     0xaf99ac: ret             
    // 0xaf99b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf99b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf99b4: b               #0xaf9908
  }
  _ pushOffset(/* No info */) {
    // ** addr: 0xaf9e0c, size: 0xcc
    // 0xaf9e0c: EnterFrame
    //     0xaf9e0c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9e10: mov             fp, SP
    // 0xaf9e14: AllocStack(0x20)
    //     0xaf9e14: sub             SP, SP, #0x20
    // 0xaf9e18: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xaf9e18: stur            x2, [fp, #-0x10]
    // 0xaf9e1c: CheckStackOverflow
    //     0xaf9e1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf9e20: cmp             SP, x16
    //     0xaf9e24: b.ls            #0xaf9ed0
    // 0xaf9e28: LoadField: r0 = r1->field_f
    //     0xaf9e28: ldur            w0, [x1, #0xf]
    // 0xaf9e2c: DecompressPointer r0
    //     0xaf9e2c: add             x0, x0, HEAP, lsl #32
    // 0xaf9e30: stur            x0, [fp, #-8]
    // 0xaf9e34: r0 = _OffsetTransformPart()
    //     0xaf9e34: bl              #0xaf9ed8  ; Allocate_OffsetTransformPartStub -> _OffsetTransformPart (size=0xc)
    // 0xaf9e38: mov             x2, x0
    // 0xaf9e3c: ldur            x0, [fp, #-0x10]
    // 0xaf9e40: stur            x2, [fp, #-0x20]
    // 0xaf9e44: StoreField: r2->field_7 = r0
    //     0xaf9e44: stur            w0, [x2, #7]
    // 0xaf9e48: ldur            x0, [fp, #-8]
    // 0xaf9e4c: LoadField: r1 = r0->field_b
    //     0xaf9e4c: ldur            w1, [x0, #0xb]
    // 0xaf9e50: LoadField: r3 = r0->field_f
    //     0xaf9e50: ldur            w3, [x0, #0xf]
    // 0xaf9e54: DecompressPointer r3
    //     0xaf9e54: add             x3, x3, HEAP, lsl #32
    // 0xaf9e58: LoadField: r4 = r3->field_b
    //     0xaf9e58: ldur            w4, [x3, #0xb]
    // 0xaf9e5c: r3 = LoadInt32Instr(r1)
    //     0xaf9e5c: sbfx            x3, x1, #1, #0x1f
    // 0xaf9e60: stur            x3, [fp, #-0x18]
    // 0xaf9e64: r1 = LoadInt32Instr(r4)
    //     0xaf9e64: sbfx            x1, x4, #1, #0x1f
    // 0xaf9e68: cmp             x3, x1
    // 0xaf9e6c: b.ne            #0xaf9e78
    // 0xaf9e70: mov             x1, x0
    // 0xaf9e74: r0 = _growToNextCapacity()
    //     0xaf9e74: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xaf9e78: ldur            x2, [fp, #-8]
    // 0xaf9e7c: ldur            x3, [fp, #-0x18]
    // 0xaf9e80: add             x4, x3, #1
    // 0xaf9e84: lsl             x5, x4, #1
    // 0xaf9e88: StoreField: r2->field_b = r5
    //     0xaf9e88: stur            w5, [x2, #0xb]
    // 0xaf9e8c: LoadField: r1 = r2->field_f
    //     0xaf9e8c: ldur            w1, [x2, #0xf]
    // 0xaf9e90: DecompressPointer r1
    //     0xaf9e90: add             x1, x1, HEAP, lsl #32
    // 0xaf9e94: ldur            x0, [fp, #-0x20]
    // 0xaf9e98: ArrayStore: r1[r3] = r0  ; List_4
    //     0xaf9e98: add             x25, x1, x3, lsl #2
    //     0xaf9e9c: add             x25, x25, #0xf
    //     0xaf9ea0: str             w0, [x25]
    //     0xaf9ea4: tbz             w0, #0, #0xaf9ec0
    //     0xaf9ea8: ldurb           w16, [x1, #-1]
    //     0xaf9eac: ldurb           w17, [x0, #-1]
    //     0xaf9eb0: and             x16, x17, x16, lsr #2
    //     0xaf9eb4: tst             x16, HEAP, lsr #32
    //     0xaf9eb8: b.eq            #0xaf9ec0
    //     0xaf9ebc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xaf9ec0: r0 = Null
    //     0xaf9ec0: mov             x0, NULL
    // 0xaf9ec4: LeaveFrame
    //     0xaf9ec4: mov             SP, fp
    //     0xaf9ec8: ldp             fp, lr, [SP], #0x10
    // 0xaf9ecc: ret
    //     0xaf9ecc: ret             
    // 0xaf9ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9ed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9ed4: b               #0xaf9e28
  }
}

// class id: 3168, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class _TransformPart extends Object {
}

// class id: 3169, size: 0xc, field offset: 0x8
//   const constructor, 
class _OffsetTransformPart extends _TransformPart {

  _ multiply(/* No info */) {
    // ** addr: 0x12fd1e4, size: 0x64
    // 0x12fd1e4: EnterFrame
    //     0x12fd1e4: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd1e8: mov             fp, SP
    // 0x12fd1ec: AllocStack(0x10)
    //     0x12fd1ec: sub             SP, SP, #0x10
    // 0x12fd1f0: SetupParameters(_OffsetTransformPart this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x12fd1f0: mov             x0, x1
    //     0x12fd1f4: stur            x1, [fp, #-8]
    //     0x12fd1f8: mov             x1, x2
    // 0x12fd1fc: CheckStackOverflow
    //     0x12fd1fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd200: cmp             SP, x16
    //     0x12fd204: b.ls            #0x12fd240
    // 0x12fd208: r0 = clone()
    //     0x12fd208: bl              #0x832afc  ; [package:vector_math/vector_math_64.dart] Matrix4::clone
    // 0x12fd20c: mov             x2, x0
    // 0x12fd210: ldur            x0, [fp, #-8]
    // 0x12fd214: stur            x2, [fp, #-0x10]
    // 0x12fd218: LoadField: r1 = r0->field_7
    //     0x12fd218: ldur            w1, [x0, #7]
    // 0x12fd21c: DecompressPointer r1
    //     0x12fd21c: add             x1, x1, HEAP, lsl #32
    // 0x12fd220: LoadField: d0 = r1->field_7
    //     0x12fd220: ldur            d0, [x1, #7]
    // 0x12fd224: LoadField: d1 = r1->field_f
    //     0x12fd224: ldur            d1, [x1, #0xf]
    // 0x12fd228: mov             x1, x2
    // 0x12fd22c: r0 = leftTranslateByDouble()
    //     0x12fd22c: bl              #0x12fd248  ; [package:vector_math/vector_math_64.dart] Matrix4::leftTranslateByDouble
    // 0x12fd230: ldur            x0, [fp, #-0x10]
    // 0x12fd234: LeaveFrame
    //     0x12fd234: mov             SP, fp
    //     0x12fd238: ldp             fp, lr, [SP], #0x10
    // 0x12fd23c: ret
    //     0x12fd23c: ret             
    // 0x12fd240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fd240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fd244: b               #0x12fd208
  }
}

// class id: 3170, size: 0xc, field offset: 0x8
//   const constructor, 
class _MatrixTransformPart extends _TransformPart {

  _ multiply(/* No info */) {
    // ** addr: 0x12fd164, size: 0x38
    // 0x12fd164: EnterFrame
    //     0x12fd164: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd168: mov             fp, SP
    // 0x12fd16c: CheckStackOverflow
    //     0x12fd16c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd170: cmp             SP, x16
    //     0x12fd174: b.ls            #0x12fd194
    // 0x12fd178: LoadField: r0 = r1->field_7
    //     0x12fd178: ldur            w0, [x1, #7]
    // 0x12fd17c: DecompressPointer r0
    //     0x12fd17c: add             x0, x0, HEAP, lsl #32
    // 0x12fd180: mov             x1, x0
    // 0x12fd184: r0 = multiplied()
    //     0x12fd184: bl              #0x12fd19c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiplied
    // 0x12fd188: LeaveFrame
    //     0x12fd188: mov             SP, fp
    //     0x12fd18c: ldp             fp, lr, [SP], #0x10
    // 0x12fd190: ret
    //     0x12fd190: ret             
    // 0x12fd194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fd194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fd198: b               #0x12fd178
  }
}

// class id: 3171, size: 0x14, field offset: 0x8
class HitTestEntry<X0 bound HitTestTarget> extends Object {
}

// class id: 3178, size: 0x8, field offset: 0x8
abstract class HitTestTarget extends Object {
}

// class id: 3179, size: 0x8, field offset: 0x8
abstract class HitTestDispatcher extends Object {
}

// class id: 4566, size: 0x8, field offset: 0x8
abstract class HitTestable extends Object {
}
