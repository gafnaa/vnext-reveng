// lib: , url: package:flutter/src/gestures/resampler.dart

// class id: 1048832, size: 0x8
class :: {
}

// class id: 3155, size: 0xc, field offset: 0x8
class PointerEventResampler extends Object {
}
