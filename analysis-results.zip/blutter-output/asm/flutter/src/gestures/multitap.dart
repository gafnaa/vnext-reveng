// lib: , url: package:flutter/src/gestures/multitap.dart

// class id: 1048828, size: 0x8
class :: {
}

// class id: 3159, size: 0x28, field offset: 0x8
class _TapTracker extends Object {

  _ startTrackingPointer(/* No info */) {
    // ** addr: 0xba8b7c, size: 0x74
    // 0xba8b7c: EnterFrame
    //     0xba8b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xba8b80: mov             fp, SP
    // 0xba8b84: mov             x5, x3
    // 0xba8b88: mov             x3, x2
    // 0xba8b8c: CheckStackOverflow
    //     0xba8b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8b90: cmp             SP, x16
    //     0xba8b94: b.ls            #0xba8be4
    // 0xba8b98: LoadField: r0 = r1->field_23
    //     0xba8b98: ldur            w0, [x1, #0x23]
    // 0xba8b9c: DecompressPointer r0
    //     0xba8b9c: add             x0, x0, HEAP, lsl #32
    // 0xba8ba0: tbz             w0, #4, #0xba8bd4
    // 0xba8ba4: r0 = true
    //     0xba8ba4: add             x0, NULL, #0x20  ; true
    // 0xba8ba8: StoreField: r1->field_23 = r0
    //     0xba8ba8: stur            w0, [x1, #0x23]
    // 0xba8bac: r0 = LoadStaticField(0x7d0)
    //     0xba8bac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xba8bb0: ldr             x0, [x0, #0xfa0]
    // 0xba8bb4: cmp             w0, NULL
    // 0xba8bb8: b.eq            #0xba8bec
    // 0xba8bbc: LoadField: r2 = r0->field_13
    //     0xba8bbc: ldur            w2, [x0, #0x13]
    // 0xba8bc0: DecompressPointer r2
    //     0xba8bc0: add             x2, x2, HEAP, lsl #32
    // 0xba8bc4: LoadField: r0 = r1->field_7
    //     0xba8bc4: ldur            x0, [x1, #7]
    // 0xba8bc8: mov             x1, x2
    // 0xba8bcc: mov             x2, x0
    // 0xba8bd0: r0 = addRoute()
    //     0xba8bd0: bl              #0xba8c10  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute
    // 0xba8bd4: r0 = Null
    //     0xba8bd4: mov             x0, NULL
    // 0xba8bd8: LeaveFrame
    //     0xba8bd8: mov             SP, fp
    //     0xba8bdc: ldp             fp, lr, [SP], #0x10
    // 0xba8be0: ret
    //     0xba8be0: ret             
    // 0xba8be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8be4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8be8: b               #0xba8b98
    // 0xba8bec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba8bec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _TapTracker(/* No info */) {
    // ** addr: 0xba8cf8, size: 0x154
    // 0xba8cf8: EnterFrame
    //     0xba8cf8: stp             fp, lr, [SP, #-0x10]!
    //     0xba8cfc: mov             fp, SP
    // 0xba8d00: AllocStack(0x10)
    //     0xba8d00: sub             SP, SP, #0x10
    // 0xba8d04: r4 = false
    //     0xba8d04: add             x4, NULL, #0x30  ; false
    // 0xba8d08: mov             x0, x2
    // 0xba8d0c: mov             x2, x3
    // 0xba8d10: stur            x3, [fp, #-0x10]
    // 0xba8d14: mov             x3, x1
    // 0xba8d18: stur            x1, [fp, #-8]
    // 0xba8d1c: CheckStackOverflow
    //     0xba8d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8d20: cmp             SP, x16
    //     0xba8d24: b.ls            #0xba8e44
    // 0xba8d28: StoreField: r3->field_23 = r4
    //     0xba8d28: stur            w4, [x3, #0x23]
    // 0xba8d2c: StoreField: r3->field_f = r0
    //     0xba8d2c: stur            w0, [x3, #0xf]
    //     0xba8d30: ldurb           w16, [x3, #-1]
    //     0xba8d34: ldurb           w17, [x0, #-1]
    //     0xba8d38: and             x16, x17, x16, lsr #2
    //     0xba8d3c: tst             x16, HEAP, lsr #32
    //     0xba8d40: b.eq            #0xba8d48
    //     0xba8d44: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba8d48: r0 = LoadClassIdInstr(r2)
    //     0xba8d48: ldur            x0, [x2, #-1]
    //     0xba8d4c: ubfx            x0, x0, #0xc, #0x14
    // 0xba8d50: mov             x1, x2
    // 0xba8d54: r0 = GDT[cid_x0 + -0x1]()
    //     0xba8d54: sub             lr, x0, #1
    //     0xba8d58: ldr             lr, [x21, lr, lsl #3]
    //     0xba8d5c: blr             lr
    // 0xba8d60: ldur            x2, [fp, #-8]
    // 0xba8d64: StoreField: r2->field_7 = r0
    //     0xba8d64: stur            x0, [x2, #7]
    // 0xba8d68: ldur            x3, [fp, #-0x10]
    // 0xba8d6c: r0 = LoadClassIdInstr(r3)
    //     0xba8d6c: ldur            x0, [x3, #-1]
    //     0xba8d70: ubfx            x0, x0, #0xc, #0x14
    // 0xba8d74: mov             x1, x3
    // 0xba8d78: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba8d78: mov             x17, #0x3f27
    //     0xba8d7c: movk            x17, #1, lsl #16
    //     0xba8d80: add             lr, x0, x17
    //     0xba8d84: ldr             lr, [x21, lr, lsl #3]
    //     0xba8d88: blr             lr
    // 0xba8d8c: ldur            x2, [fp, #-8]
    // 0xba8d90: StoreField: r2->field_13 = r0
    //     0xba8d90: stur            w0, [x2, #0x13]
    //     0xba8d94: ldurb           w16, [x2, #-1]
    //     0xba8d98: ldurb           w17, [x0, #-1]
    //     0xba8d9c: and             x16, x17, x16, lsr #2
    //     0xba8da0: tst             x16, HEAP, lsr #32
    //     0xba8da4: b.eq            #0xba8dac
    //     0xba8da8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba8dac: ldur            x1, [fp, #-0x10]
    // 0xba8db0: r0 = LoadClassIdInstr(r1)
    //     0xba8db0: ldur            x0, [x1, #-1]
    //     0xba8db4: ubfx            x0, x0, #0xc, #0x14
    // 0xba8db8: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xba8db8: mov             x17, #0x6f9c
    //     0xba8dbc: movk            x17, #1, lsl #16
    //     0xba8dc0: add             lr, x0, x17
    //     0xba8dc4: ldr             lr, [x21, lr, lsl #3]
    //     0xba8dc8: blr             lr
    // 0xba8dcc: mov             x1, x0
    // 0xba8dd0: ldur            x0, [fp, #-8]
    // 0xba8dd4: ArrayStore: r0[0] = r1  ; List_8
    //     0xba8dd4: stur            x1, [x0, #0x17]
    // 0xba8dd8: r0 = _CountdownZoned()
    //     0xba8dd8: bl              #0xba8e4c  ; Allocate_CountdownZonedStub -> _CountdownZoned (size=0xc)
    // 0xba8ddc: mov             x3, x0
    // 0xba8de0: r0 = false
    //     0xba8de0: add             x0, NULL, #0x30  ; false
    // 0xba8de4: stur            x3, [fp, #-0x10]
    // 0xba8de8: StoreField: r3->field_7 = r0
    //     0xba8de8: stur            w0, [x3, #7]
    // 0xba8dec: mov             x2, x3
    // 0xba8df0: r1 = Function '_onTimeout@659391311':.
    //     0xba8df0: add             x1, PP, #0x96, lsl #12  ; [pp+0x960f8] AnonymousClosure: (0xba8e58), in [package:flutter/src/gestures/multitap.dart] _CountdownZoned::_onTimeout (0xba8e90)
    //     0xba8df4: ldr             x1, [x1, #0xf8]
    // 0xba8df8: r0 = AllocateClosure()
    //     0xba8df8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba8dfc: mov             x3, x0
    // 0xba8e00: r1 = Null
    //     0xba8e00: mov             x1, NULL
    // 0xba8e04: r2 = Instance_Duration
    //     0xba8e04: add             x2, PP, #0x96, lsl #12  ; [pp+0x96100] Obj!Duration@12c8a41
    //     0xba8e08: ldr             x2, [x2, #0x100]
    // 0xba8e0c: r0 = Timer()
    //     0xba8e0c: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xba8e10: ldur            x0, [fp, #-0x10]
    // 0xba8e14: ldur            x1, [fp, #-8]
    // 0xba8e18: StoreField: r1->field_1f = r0
    //     0xba8e18: stur            w0, [x1, #0x1f]
    //     0xba8e1c: ldurb           w16, [x1, #-1]
    //     0xba8e20: ldurb           w17, [x0, #-1]
    //     0xba8e24: and             x16, x17, x16, lsr #2
    //     0xba8e28: tst             x16, HEAP, lsr #32
    //     0xba8e2c: b.eq            #0xba8e34
    //     0xba8e30: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba8e34: r0 = Null
    //     0xba8e34: mov             x0, NULL
    // 0xba8e38: LeaveFrame
    //     0xba8e38: mov             SP, fp
    //     0xba8e3c: ldp             fp, lr, [SP], #0x10
    // 0xba8e40: ret
    //     0xba8e40: ret             
    // 0xba8e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8e44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8e48: b               #0xba8d28
  }
  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0xba9494, size: 0x70
    // 0xba9494: EnterFrame
    //     0xba9494: stp             fp, lr, [SP, #-0x10]!
    //     0xba9498: mov             fp, SP
    // 0xba949c: mov             x3, x2
    // 0xba94a0: CheckStackOverflow
    //     0xba94a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba94a4: cmp             SP, x16
    //     0xba94a8: b.ls            #0xba94f8
    // 0xba94ac: LoadField: r0 = r1->field_23
    //     0xba94ac: ldur            w0, [x1, #0x23]
    // 0xba94b0: DecompressPointer r0
    //     0xba94b0: add             x0, x0, HEAP, lsl #32
    // 0xba94b4: tbnz            w0, #4, #0xba94e8
    // 0xba94b8: r0 = false
    //     0xba94b8: add             x0, NULL, #0x30  ; false
    // 0xba94bc: StoreField: r1->field_23 = r0
    //     0xba94bc: stur            w0, [x1, #0x23]
    // 0xba94c0: r0 = LoadStaticField(0x7d0)
    //     0xba94c0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xba94c4: ldr             x0, [x0, #0xfa0]
    // 0xba94c8: cmp             w0, NULL
    // 0xba94cc: b.eq            #0xba9500
    // 0xba94d0: LoadField: r2 = r0->field_13
    //     0xba94d0: ldur            w2, [x0, #0x13]
    // 0xba94d4: DecompressPointer r2
    //     0xba94d4: add             x2, x2, HEAP, lsl #32
    // 0xba94d8: LoadField: r0 = r1->field_7
    //     0xba94d8: ldur            x0, [x1, #7]
    // 0xba94dc: mov             x1, x2
    // 0xba94e0: mov             x2, x0
    // 0xba94e4: r0 = removeRoute()
    //     0xba94e4: bl              #0xb8bf6c  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeRoute
    // 0xba94e8: r0 = Null
    //     0xba94e8: mov             x0, NULL
    // 0xba94ec: LeaveFrame
    //     0xba94ec: mov             SP, fp
    //     0xba94f0: ldp             fp, lr, [SP], #0x10
    // 0xba94f4: ret
    //     0xba94f4: ret             
    // 0xba94f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba94f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba94fc: b               #0xba94ac
    // 0xba9500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba9500: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hasSameButton(/* No info */) {
    // ** addr: 0xba9c98, size: 0x74
    // 0xba9c98: EnterFrame
    //     0xba9c98: stp             fp, lr, [SP, #-0x10]!
    //     0xba9c9c: mov             fp, SP
    // 0xba9ca0: AllocStack(0x8)
    //     0xba9ca0: sub             SP, SP, #8
    // 0xba9ca4: SetupParameters(_TapTracker this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xba9ca4: stur            x1, [fp, #-8]
    //     0xba9ca8: mov             x16, x2
    //     0xba9cac: mov             x2, x1
    //     0xba9cb0: mov             x1, x16
    // 0xba9cb4: CheckStackOverflow
    //     0xba9cb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9cb8: cmp             SP, x16
    //     0xba9cbc: b.ls            #0xba9d04
    // 0xba9cc0: r0 = LoadClassIdInstr(r1)
    //     0xba9cc0: ldur            x0, [x1, #-1]
    //     0xba9cc4: ubfx            x0, x0, #0xc, #0x14
    // 0xba9cc8: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xba9cc8: mov             x17, #0x6f9c
    //     0xba9ccc: movk            x17, #1, lsl #16
    //     0xba9cd0: add             lr, x0, x17
    //     0xba9cd4: ldr             lr, [x21, lr, lsl #3]
    //     0xba9cd8: blr             lr
    // 0xba9cdc: ldur            x1, [fp, #-8]
    // 0xba9ce0: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xba9ce0: ldur            x2, [x1, #0x17]
    // 0xba9ce4: cmp             x0, x2
    // 0xba9ce8: r16 = true
    //     0xba9ce8: add             x16, NULL, #0x20  ; true
    // 0xba9cec: r17 = false
    //     0xba9cec: add             x17, NULL, #0x30  ; false
    // 0xba9cf0: csel            x1, x16, x17, eq
    // 0xba9cf4: mov             x0, x1
    // 0xba9cf8: LeaveFrame
    //     0xba9cf8: mov             SP, fp
    //     0xba9cfc: ldp             fp, lr, [SP], #0x10
    // 0xba9d00: ret
    //     0xba9d00: ret             
    // 0xba9d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9d04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9d08: b               #0xba9cc0
  }
  _ hasElapsedMinTime(/* No info */) {
    // ** addr: 0xba9d0c, size: 0x14
    // 0xba9d0c: LoadField: r2 = r1->field_1f
    //     0xba9d0c: ldur            w2, [x1, #0x1f]
    // 0xba9d10: DecompressPointer r2
    //     0xba9d10: add             x2, x2, HEAP, lsl #32
    // 0xba9d14: LoadField: r0 = r2->field_7
    //     0xba9d14: ldur            w0, [x2, #7]
    // 0xba9d18: DecompressPointer r0
    //     0xba9d18: add             x0, x0, HEAP, lsl #32
    // 0xba9d1c: ret
    //     0xba9d1c: ret             
  }
  _ isWithinGlobalTolerance(/* No info */) {
    // ** addr: 0xba9d20, size: 0x9c
    // 0xba9d20: EnterFrame
    //     0xba9d20: stp             fp, lr, [SP, #-0x10]!
    //     0xba9d24: mov             fp, SP
    // 0xba9d28: AllocStack(0x10)
    //     0xba9d28: sub             SP, SP, #0x10
    // 0xba9d2c: SetupParameters(_TapTracker this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xba9d2c: stur            x1, [fp, #-8]
    //     0xba9d30: mov             x16, x2
    //     0xba9d34: mov             x2, x1
    //     0xba9d38: mov             x1, x16
    //     0xba9d3c: stur            d0, [fp, #-0x10]
    // 0xba9d40: CheckStackOverflow
    //     0xba9d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9d44: cmp             SP, x16
    //     0xba9d48: b.ls            #0xba9db4
    // 0xba9d4c: r0 = LoadClassIdInstr(r1)
    //     0xba9d4c: ldur            x0, [x1, #-1]
    //     0xba9d50: ubfx            x0, x0, #0xc, #0x14
    // 0xba9d54: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba9d54: mov             x17, #0x3f27
    //     0xba9d58: movk            x17, #1, lsl #16
    //     0xba9d5c: add             lr, x0, x17
    //     0xba9d60: ldr             lr, [x21, lr, lsl #3]
    //     0xba9d64: blr             lr
    // 0xba9d68: mov             x1, x0
    // 0xba9d6c: ldur            x0, [fp, #-8]
    // 0xba9d70: LoadField: r2 = r0->field_13
    //     0xba9d70: ldur            w2, [x0, #0x13]
    // 0xba9d74: DecompressPointer r2
    //     0xba9d74: add             x2, x2, HEAP, lsl #32
    // 0xba9d78: r0 = -()
    //     0xba9d78: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xba9d7c: LoadField: d0 = r0->field_7
    //     0xba9d7c: ldur            d0, [x0, #7]
    // 0xba9d80: fmul            d1, d0, d0
    // 0xba9d84: LoadField: d0 = r0->field_f
    //     0xba9d84: ldur            d0, [x0, #0xf]
    // 0xba9d88: fmul            d2, d0, d0
    // 0xba9d8c: fadd            d0, d1, d2
    // 0xba9d90: fsqrt           d1, d0
    // 0xba9d94: ldur            d0, [fp, #-0x10]
    // 0xba9d98: fcmp            d0, d1
    // 0xba9d9c: r16 = true
    //     0xba9d9c: add             x16, NULL, #0x20  ; true
    // 0xba9da0: r17 = false
    //     0xba9da0: add             x17, NULL, #0x30  ; false
    // 0xba9da4: csel            x0, x16, x17, ge
    // 0xba9da8: LeaveFrame
    //     0xba9da8: mov             SP, fp
    //     0xba9dac: ldp             fp, lr, [SP], #0x10
    // 0xba9db0: ret
    //     0xba9db0: ret             
    // 0xba9db4: r0 = StackOverflowSharedWithFPURegs()
    //     0xba9db4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xba9db8: b               #0xba9d4c
  }
}

// class id: 3160, size: 0xc, field offset: 0x8
class _CountdownZoned extends Object {

  [closure] void _onTimeout(dynamic) {
    // ** addr: 0xba8e58, size: 0x38
    // 0xba8e58: EnterFrame
    //     0xba8e58: stp             fp, lr, [SP, #-0x10]!
    //     0xba8e5c: mov             fp, SP
    // 0xba8e60: ldr             x0, [fp, #0x10]
    // 0xba8e64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba8e64: ldur            w1, [x0, #0x17]
    // 0xba8e68: DecompressPointer r1
    //     0xba8e68: add             x1, x1, HEAP, lsl #32
    // 0xba8e6c: CheckStackOverflow
    //     0xba8e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8e70: cmp             SP, x16
    //     0xba8e74: b.ls            #0xba8e88
    // 0xba8e78: r0 = _onTimeout()
    //     0xba8e78: bl              #0xba8e90  ; [package:flutter/src/gestures/multitap.dart] _CountdownZoned::_onTimeout
    // 0xba8e7c: LeaveFrame
    //     0xba8e7c: mov             SP, fp
    //     0xba8e80: ldp             fp, lr, [SP], #0x10
    // 0xba8e84: ret
    //     0xba8e84: ret             
    // 0xba8e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8e8c: b               #0xba8e78
  }
  _ _onTimeout(/* No info */) {
    // ** addr: 0xba8e90, size: 0x10
    // 0xba8e90: r2 = true
    //     0xba8e90: add             x2, NULL, #0x20  ; true
    // 0xba8e94: StoreField: r1->field_7 = r2
    //     0xba8e94: stur            w2, [x1, #7]
    // 0xba8e98: r0 = Null
    //     0xba8e98: mov             x0, NULL
    // 0xba8e9c: ret
    //     0xba8e9c: ret             
  }
}

// class id: 4429, size: 0x30, field offset: 0x18
class DoubleTapGestureRecognizer extends GestureRecognizer {

  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba8814, size: 0x1fc
    // 0xba8814: EnterFrame
    //     0xba8814: stp             fp, lr, [SP, #-0x10]!
    //     0xba8818: mov             fp, SP
    // 0xba881c: AllocStack(0x48)
    //     0xba881c: sub             SP, SP, #0x48
    // 0xba8820: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba8820: stur            x1, [fp, #-8]
    //     0xba8824: stur            x2, [fp, #-0x10]
    // 0xba8828: CheckStackOverflow
    //     0xba8828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba882c: cmp             SP, x16
    //     0xba8830: b.ls            #0xba8a00
    // 0xba8834: r1 = 2
    //     0xba8834: mov             x1, #2
    // 0xba8838: r0 = AllocateContext()
    //     0xba8838: bl              #0x13de838  ; AllocateContextStub
    // 0xba883c: mov             x3, x0
    // 0xba8840: ldur            x0, [fp, #-8]
    // 0xba8844: stur            x3, [fp, #-0x18]
    // 0xba8848: StoreField: r3->field_f = r0
    //     0xba8848: stur            w0, [x3, #0xf]
    // 0xba884c: LoadField: r1 = r0->field_27
    //     0xba884c: ldur            w1, [x0, #0x27]
    // 0xba8850: DecompressPointer r1
    //     0xba8850: add             x1, x1, HEAP, lsl #32
    // 0xba8854: cmp             w1, NULL
    // 0xba8858: b.eq            #0xba89e4
    // 0xba885c: ldur            x2, [fp, #-0x10]
    // 0xba8860: d0 = 100.000000
    //     0xba8860: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xba8864: ldr             d0, [x17, #0xa8]
    // 0xba8868: r0 = isWithinGlobalTolerance()
    //     0xba8868: bl              #0xba9d20  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::isWithinGlobalTolerance
    // 0xba886c: tbz             w0, #4, #0xba8880
    // 0xba8870: r0 = Null
    //     0xba8870: mov             x0, NULL
    // 0xba8874: LeaveFrame
    //     0xba8874: mov             SP, fp
    //     0xba8878: ldp             fp, lr, [SP], #0x10
    // 0xba887c: ret
    //     0xba887c: ret             
    // 0xba8880: ldur            x0, [fp, #-8]
    // 0xba8884: LoadField: r1 = r0->field_27
    //     0xba8884: ldur            w1, [x0, #0x27]
    // 0xba8888: DecompressPointer r1
    //     0xba8888: add             x1, x1, HEAP, lsl #32
    // 0xba888c: cmp             w1, NULL
    // 0xba8890: b.eq            #0xba8a08
    // 0xba8894: r0 = hasElapsedMinTime()
    //     0xba8894: bl              #0xba9d0c  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::hasElapsedMinTime
    // 0xba8898: tbnz            w0, #4, #0xba88bc
    // 0xba889c: ldur            x0, [fp, #-8]
    // 0xba88a0: LoadField: r1 = r0->field_27
    //     0xba88a0: ldur            w1, [x0, #0x27]
    // 0xba88a4: DecompressPointer r1
    //     0xba88a4: add             x1, x1, HEAP, lsl #32
    // 0xba88a8: cmp             w1, NULL
    // 0xba88ac: b.eq            #0xba8a0c
    // 0xba88b0: ldur            x2, [fp, #-0x10]
    // 0xba88b4: r0 = hasSameButton()
    //     0xba88b4: bl              #0xba9c98  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::hasSameButton
    // 0xba88b8: tbz             w0, #4, #0xba88e0
    // 0xba88bc: ldur            x1, [fp, #-8]
    // 0xba88c0: r0 = _reset()
    //     0xba88c0: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xba88c4: ldur            x1, [fp, #-8]
    // 0xba88c8: ldur            x2, [fp, #-0x10]
    // 0xba88cc: r0 = _trackTap()
    //     0xba88cc: bl              #0xba8a34  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_trackTap
    // 0xba88d0: r0 = Null
    //     0xba88d0: mov             x0, NULL
    // 0xba88d4: LeaveFrame
    //     0xba88d4: mov             SP, fp
    //     0xba88d8: ldp             fp, lr, [SP], #0x10
    // 0xba88dc: ret
    //     0xba88dc: ret             
    // 0xba88e0: ldur            x2, [fp, #-8]
    // 0xba88e4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xba88e4: ldur            w0, [x2, #0x17]
    // 0xba88e8: DecompressPointer r0
    //     0xba88e8: add             x0, x0, HEAP, lsl #32
    // 0xba88ec: cmp             w0, NULL
    // 0xba88f0: b.eq            #0xba89e4
    // 0xba88f4: ldur            x4, [fp, #-0x10]
    // 0xba88f8: ldur            x3, [fp, #-0x18]
    // 0xba88fc: r0 = LoadClassIdInstr(r4)
    //     0xba88fc: ldur            x0, [x4, #-1]
    //     0xba8900: ubfx            x0, x0, #0xc, #0x14
    // 0xba8904: mov             x1, x4
    // 0xba8908: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba8908: mov             x17, #0x3f27
    //     0xba890c: movk            x17, #1, lsl #16
    //     0xba8910: add             lr, x0, x17
    //     0xba8914: ldr             lr, [x21, lr, lsl #3]
    //     0xba8918: blr             lr
    // 0xba891c: mov             x3, x0
    // 0xba8920: ldur            x2, [fp, #-0x10]
    // 0xba8924: stur            x3, [fp, #-0x20]
    // 0xba8928: r0 = LoadClassIdInstr(r2)
    //     0xba8928: ldur            x0, [x2, #-1]
    //     0xba892c: ubfx            x0, x0, #0xc, #0x14
    // 0xba8930: mov             x1, x2
    // 0xba8934: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xba8934: mov             x17, #0x54ea
    //     0xba8938: movk            x17, #1, lsl #16
    //     0xba893c: add             lr, x0, x17
    //     0xba8940: ldr             lr, [x21, lr, lsl #3]
    //     0xba8944: blr             lr
    // 0xba8948: mov             x3, x0
    // 0xba894c: ldur            x2, [fp, #-0x10]
    // 0xba8950: stur            x3, [fp, #-0x28]
    // 0xba8954: r0 = LoadClassIdInstr(r2)
    //     0xba8954: ldur            x0, [x2, #-1]
    //     0xba8958: ubfx            x0, x0, #0xc, #0x14
    // 0xba895c: mov             x1, x2
    // 0xba8960: r0 = GDT[cid_x0 + -0x1]()
    //     0xba8960: sub             lr, x0, #1
    //     0xba8964: ldr             lr, [x21, lr, lsl #3]
    //     0xba8968: blr             lr
    // 0xba896c: ldur            x1, [fp, #-8]
    // 0xba8970: mov             x2, x0
    // 0xba8974: r0 = getKindForPointer()
    //     0xba8974: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xba8978: stur            x0, [fp, #-0x30]
    // 0xba897c: r0 = TapDownDetails()
    //     0xba897c: bl              #0xba7818  ; AllocateTapDownDetailsStub -> TapDownDetails (size=0x14)
    // 0xba8980: mov             x1, x0
    // 0xba8984: ldur            x0, [fp, #-0x20]
    // 0xba8988: StoreField: r1->field_7 = r0
    //     0xba8988: stur            w0, [x1, #7]
    // 0xba898c: ldur            x0, [fp, #-0x30]
    // 0xba8990: StoreField: r1->field_f = r0
    //     0xba8990: stur            w0, [x1, #0xf]
    // 0xba8994: ldur            x0, [fp, #-0x28]
    // 0xba8998: StoreField: r1->field_b = r0
    //     0xba8998: stur            w0, [x1, #0xb]
    // 0xba899c: mov             x0, x1
    // 0xba89a0: ldur            x2, [fp, #-0x18]
    // 0xba89a4: StoreField: r2->field_13 = r0
    //     0xba89a4: stur            w0, [x2, #0x13]
    //     0xba89a8: ldurb           w16, [x2, #-1]
    //     0xba89ac: ldurb           w17, [x0, #-1]
    //     0xba89b0: and             x16, x17, x16, lsr #2
    //     0xba89b4: tst             x16, HEAP, lsr #32
    //     0xba89b8: b.eq            #0xba89c0
    //     0xba89bc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba89c0: r1 = Function '<anonymous closure>':.
    //     0xba89c0: add             x1, PP, #0x96, lsl #12  ; [pp+0x960f0] AnonymousClosure: (0xba9dbc), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::addAllowedPointer (0xba8814)
    //     0xba89c4: ldr             x1, [x1, #0xf0]
    // 0xba89c8: r0 = AllocateClosure()
    //     0xba89c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba89cc: r16 = <void?>
    //     0xba89cc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba89d0: ldur            lr, [fp, #-8]
    // 0xba89d4: stp             lr, x16, [SP, #8]
    // 0xba89d8: str             x0, [SP]
    // 0xba89dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba89dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba89e0: r0 = invokeCallback()
    //     0xba89e0: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba89e4: ldur            x1, [fp, #-8]
    // 0xba89e8: ldur            x2, [fp, #-0x10]
    // 0xba89ec: r0 = _trackTap()
    //     0xba89ec: bl              #0xba8a34  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_trackTap
    // 0xba89f0: r0 = Null
    //     0xba89f0: mov             x0, NULL
    // 0xba89f4: LeaveFrame
    //     0xba89f4: mov             SP, fp
    //     0xba89f8: ldp             fp, lr, [SP], #0x10
    // 0xba89fc: ret
    //     0xba89fc: ret             
    // 0xba8a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8a00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8a04: b               #0xba8834
    // 0xba8a08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba8a08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba8a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba8a0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _trackTap(/* No info */) {
    // ** addr: 0xba8a34, size: 0x148
    // 0xba8a34: EnterFrame
    //     0xba8a34: stp             fp, lr, [SP, #-0x10]!
    //     0xba8a38: mov             fp, SP
    // 0xba8a3c: AllocStack(0x20)
    //     0xba8a3c: sub             SP, SP, #0x20
    // 0xba8a40: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba8a40: mov             x0, x2
    //     0xba8a44: stur            x2, [fp, #-0x10]
    //     0xba8a48: mov             x2, x1
    //     0xba8a4c: stur            x1, [fp, #-8]
    // 0xba8a50: CheckStackOverflow
    //     0xba8a50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8a54: cmp             SP, x16
    //     0xba8a58: b.ls            #0xba8b70
    // 0xba8a5c: mov             x1, x2
    // 0xba8a60: r0 = _stopDoubleTapTimer()
    //     0xba8a60: bl              #0xba9070  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_stopDoubleTapTimer
    // 0xba8a64: r0 = LoadStaticField(0x7d0)
    //     0xba8a64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xba8a68: ldr             x0, [x0, #0xfa0]
    // 0xba8a6c: cmp             w0, NULL
    // 0xba8a70: b.eq            #0xba8b78
    // 0xba8a74: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xba8a74: ldur            w2, [x0, #0x17]
    // 0xba8a78: DecompressPointer r2
    //     0xba8a78: add             x2, x2, HEAP, lsl #32
    // 0xba8a7c: ldur            x3, [fp, #-0x10]
    // 0xba8a80: stur            x2, [fp, #-0x18]
    // 0xba8a84: r0 = LoadClassIdInstr(r3)
    //     0xba8a84: ldur            x0, [x3, #-1]
    //     0xba8a88: ubfx            x0, x0, #0xc, #0x14
    // 0xba8a8c: mov             x1, x3
    // 0xba8a90: r0 = GDT[cid_x0 + -0x1]()
    //     0xba8a90: sub             lr, x0, #1
    //     0xba8a94: ldr             lr, [x21, lr, lsl #3]
    //     0xba8a98: blr             lr
    // 0xba8a9c: ldur            x1, [fp, #-0x18]
    // 0xba8aa0: mov             x2, x0
    // 0xba8aa4: ldur            x3, [fp, #-8]
    // 0xba8aa8: r0 = add()
    //     0xba8aa8: bl              #0xba8eac  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0xba8aac: stur            x0, [fp, #-0x18]
    // 0xba8ab0: r0 = _TapTracker()
    //     0xba8ab0: bl              #0xba8ea0  ; Allocate_TapTrackerStub -> _TapTracker (size=0x28)
    // 0xba8ab4: mov             x1, x0
    // 0xba8ab8: ldur            x2, [fp, #-0x18]
    // 0xba8abc: ldur            x3, [fp, #-0x10]
    // 0xba8ac0: stur            x0, [fp, #-0x18]
    // 0xba8ac4: r0 = _TapTracker()
    //     0xba8ac4: bl              #0xba8cf8  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::_TapTracker
    // 0xba8ac8: ldur            x2, [fp, #-8]
    // 0xba8acc: LoadField: r3 = r2->field_2b
    //     0xba8acc: ldur            w3, [x2, #0x2b]
    // 0xba8ad0: DecompressPointer r3
    //     0xba8ad0: add             x3, x3, HEAP, lsl #32
    // 0xba8ad4: ldur            x4, [fp, #-0x10]
    // 0xba8ad8: stur            x3, [fp, #-0x20]
    // 0xba8adc: r0 = LoadClassIdInstr(r4)
    //     0xba8adc: ldur            x0, [x4, #-1]
    //     0xba8ae0: ubfx            x0, x0, #0xc, #0x14
    // 0xba8ae4: mov             x1, x4
    // 0xba8ae8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba8ae8: sub             lr, x0, #1
    //     0xba8aec: ldr             lr, [x21, lr, lsl #3]
    //     0xba8af0: blr             lr
    // 0xba8af4: mov             x2, x0
    // 0xba8af8: r0 = BoxInt64Instr(r2)
    //     0xba8af8: sbfiz           x0, x2, #1, #0x1f
    //     0xba8afc: cmp             x2, x0, asr #1
    //     0xba8b00: b.eq            #0xba8b0c
    //     0xba8b04: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba8b08: stur            x2, [x0, #7]
    // 0xba8b0c: ldur            x1, [fp, #-0x20]
    // 0xba8b10: mov             x2, x0
    // 0xba8b14: ldur            x3, [fp, #-0x18]
    // 0xba8b18: r0 = []=()
    //     0xba8b18: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba8b1c: ldur            x1, [fp, #-0x10]
    // 0xba8b20: r0 = LoadClassIdInstr(r1)
    //     0xba8b20: ldur            x0, [x1, #-1]
    //     0xba8b24: ubfx            x0, x0, #0xc, #0x14
    // 0xba8b28: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xba8b28: mov             x17, #0x5fe3
    //     0xba8b2c: movk            x17, #1, lsl #16
    //     0xba8b30: add             lr, x0, x17
    //     0xba8b34: ldr             lr, [x21, lr, lsl #3]
    //     0xba8b38: blr             lr
    // 0xba8b3c: ldur            x2, [fp, #-8]
    // 0xba8b40: r1 = Function '_handleEvent@659391311':.
    //     0xba8b40: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cdb0] AnonymousClosure: (0xba90c4), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent (0xba9100)
    //     0xba8b44: ldr             x1, [x1, #0xdb0]
    // 0xba8b48: stur            x0, [fp, #-8]
    // 0xba8b4c: r0 = AllocateClosure()
    //     0xba8b4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba8b50: ldur            x1, [fp, #-0x18]
    // 0xba8b54: mov             x2, x0
    // 0xba8b58: ldur            x3, [fp, #-8]
    // 0xba8b5c: r0 = startTrackingPointer()
    //     0xba8b5c: bl              #0xba8b7c  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::startTrackingPointer
    // 0xba8b60: r0 = Null
    //     0xba8b60: mov             x0, NULL
    // 0xba8b64: LeaveFrame
    //     0xba8b64: mov             SP, fp
    //     0xba8b68: ldp             fp, lr, [SP], #0x10
    // 0xba8b6c: ret
    //     0xba8b6c: ret             
    // 0xba8b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8b74: b               #0xba8a5c
    // 0xba8b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba8b78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _stopDoubleTapTimer(/* No info */) {
    // ** addr: 0xba9070, size: 0x54
    // 0xba9070: EnterFrame
    //     0xba9070: stp             fp, lr, [SP, #-0x10]!
    //     0xba9074: mov             fp, SP
    // 0xba9078: AllocStack(0x8)
    //     0xba9078: sub             SP, SP, #8
    // 0xba907c: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba907c: mov             x0, x1
    //     0xba9080: stur            x1, [fp, #-8]
    // 0xba9084: CheckStackOverflow
    //     0xba9084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9088: cmp             SP, x16
    //     0xba908c: b.ls            #0xba90bc
    // 0xba9090: LoadField: r1 = r0->field_23
    //     0xba9090: ldur            w1, [x0, #0x23]
    // 0xba9094: DecompressPointer r1
    //     0xba9094: add             x1, x1, HEAP, lsl #32
    // 0xba9098: cmp             w1, NULL
    // 0xba909c: b.eq            #0xba90ac
    // 0xba90a0: r0 = cancel()
    //     0xba90a0: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xba90a4: ldur            x1, [fp, #-8]
    // 0xba90a8: StoreField: r1->field_23 = rNULL
    //     0xba90a8: stur            NULL, [x1, #0x23]
    // 0xba90ac: r0 = Null
    //     0xba90ac: mov             x0, NULL
    // 0xba90b0: LeaveFrame
    //     0xba90b0: mov             SP, fp
    //     0xba90b4: ldp             fp, lr, [SP], #0x10
    // 0xba90b8: ret
    //     0xba90b8: ret             
    // 0xba90bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba90bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba90c0: b               #0xba9090
  }
  [closure] void _handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xba90c4, size: 0x3c
    // 0xba90c4: EnterFrame
    //     0xba90c4: stp             fp, lr, [SP, #-0x10]!
    //     0xba90c8: mov             fp, SP
    // 0xba90cc: ldr             x0, [fp, #0x18]
    // 0xba90d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba90d0: ldur            w1, [x0, #0x17]
    // 0xba90d4: DecompressPointer r1
    //     0xba90d4: add             x1, x1, HEAP, lsl #32
    // 0xba90d8: CheckStackOverflow
    //     0xba90d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba90dc: cmp             SP, x16
    //     0xba90e0: b.ls            #0xba90f8
    // 0xba90e4: ldr             x2, [fp, #0x10]
    // 0xba90e8: r0 = _handleEvent()
    //     0xba90e8: bl              #0xba9100  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent
    // 0xba90ec: LeaveFrame
    //     0xba90ec: mov             SP, fp
    //     0xba90f0: ldp             fp, lr, [SP], #0x10
    // 0xba90f4: ret
    //     0xba90f4: ret             
    // 0xba90f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba90f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba90fc: b               #0xba90e4
  }
  _ _handleEvent(/* No info */) {
    // ** addr: 0xba9100, size: 0x1f8
    // 0xba9100: EnterFrame
    //     0xba9100: stp             fp, lr, [SP, #-0x10]!
    //     0xba9104: mov             fp, SP
    // 0xba9108: AllocStack(0x18)
    //     0xba9108: sub             SP, SP, #0x18
    // 0xba910c: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xba910c: mov             x3, x1
    //     0xba9110: stur            x1, [fp, #-0x10]
    //     0xba9114: stur            x2, [fp, #-0x18]
    // 0xba9118: CheckStackOverflow
    //     0xba9118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba911c: cmp             SP, x16
    //     0xba9120: b.ls            #0xba92ec
    // 0xba9124: LoadField: r4 = r3->field_2b
    //     0xba9124: ldur            w4, [x3, #0x2b]
    // 0xba9128: DecompressPointer r4
    //     0xba9128: add             x4, x4, HEAP, lsl #32
    // 0xba912c: stur            x4, [fp, #-8]
    // 0xba9130: r0 = LoadClassIdInstr(r2)
    //     0xba9130: ldur            x0, [x2, #-1]
    //     0xba9134: ubfx            x0, x0, #0xc, #0x14
    // 0xba9138: mov             x1, x2
    // 0xba913c: r0 = GDT[cid_x0 + -0x1]()
    //     0xba913c: sub             lr, x0, #1
    //     0xba9140: ldr             lr, [x21, lr, lsl #3]
    //     0xba9144: blr             lr
    // 0xba9148: mov             x2, x0
    // 0xba914c: r0 = BoxInt64Instr(r2)
    //     0xba914c: sbfiz           x0, x2, #1, #0x1f
    //     0xba9150: cmp             x2, x0, asr #1
    //     0xba9154: b.eq            #0xba9160
    //     0xba9158: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba915c: stur            x2, [x0, #7]
    // 0xba9160: ldur            x1, [fp, #-8]
    // 0xba9164: mov             x2, x0
    // 0xba9168: r0 = _getValueOrData()
    //     0xba9168: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba916c: mov             x1, x0
    // 0xba9170: ldur            x0, [fp, #-8]
    // 0xba9174: LoadField: r2 = r0->field_f
    //     0xba9174: ldur            w2, [x0, #0xf]
    // 0xba9178: DecompressPointer r2
    //     0xba9178: add             x2, x2, HEAP, lsl #32
    // 0xba917c: cmp             w2, w1
    // 0xba9180: b.ne            #0xba918c
    // 0xba9184: r3 = Null
    //     0xba9184: mov             x3, NULL
    // 0xba9188: b               #0xba9190
    // 0xba918c: mov             x3, x1
    // 0xba9190: stur            x3, [fp, #-8]
    // 0xba9194: cmp             w3, NULL
    // 0xba9198: b.eq            #0xba92f4
    // 0xba919c: ldur            x0, [fp, #-0x18]
    // 0xba91a0: r2 = Null
    //     0xba91a0: mov             x2, NULL
    // 0xba91a4: r1 = Null
    //     0xba91a4: mov             x1, NULL
    // 0xba91a8: cmp             w0, NULL
    // 0xba91ac: b.eq            #0xba91d4
    // 0xba91b0: branchIfSmi(r0, 0xba91d4)
    //     0xba91b0: tbz             w0, #0, #0xba91d4
    // 0xba91b4: r3 = LoadClassIdInstr(r0)
    //     0xba91b4: ldur            x3, [x0, #-1]
    //     0xba91b8: ubfx            x3, x3, #0xc, #0x14
    // 0xba91bc: r17 = 4155
    //     0xba91bc: mov             x17, #0x103b
    // 0xba91c0: cmp             x3, x17
    // 0xba91c4: b.eq            #0xba91dc
    // 0xba91c8: r17 = 5284
    //     0xba91c8: mov             x17, #0x14a4
    // 0xba91cc: cmp             x3, x17
    // 0xba91d0: b.eq            #0xba91dc
    // 0xba91d4: r0 = false
    //     0xba91d4: add             x0, NULL, #0x30  ; false
    // 0xba91d8: b               #0xba91e0
    // 0xba91dc: r0 = true
    //     0xba91dc: add             x0, NULL, #0x20  ; true
    // 0xba91e0: tbnz            w0, #4, #0xba9218
    // 0xba91e4: ldur            x3, [fp, #-0x10]
    // 0xba91e8: LoadField: r0 = r3->field_27
    //     0xba91e8: ldur            w0, [x3, #0x27]
    // 0xba91ec: DecompressPointer r0
    //     0xba91ec: add             x0, x0, HEAP, lsl #32
    // 0xba91f0: cmp             w0, NULL
    // 0xba91f4: b.ne            #0xba9208
    // 0xba91f8: mov             x1, x3
    // 0xba91fc: ldur            x2, [fp, #-8]
    // 0xba9200: r0 = _registerFirstTap()
    //     0xba9200: bl              #0xba962c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_registerFirstTap
    // 0xba9204: b               #0xba92dc
    // 0xba9208: mov             x1, x3
    // 0xba920c: ldur            x2, [fp, #-8]
    // 0xba9210: r0 = _registerSecondTap()
    //     0xba9210: bl              #0xba9504  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_registerSecondTap
    // 0xba9214: b               #0xba92dc
    // 0xba9218: ldur            x3, [fp, #-0x10]
    // 0xba921c: ldur            x0, [fp, #-0x18]
    // 0xba9220: r2 = Null
    //     0xba9220: mov             x2, NULL
    // 0xba9224: r1 = Null
    //     0xba9224: mov             x1, NULL
    // 0xba9228: cmp             w0, NULL
    // 0xba922c: b.eq            #0xba9254
    // 0xba9230: branchIfSmi(r0, 0xba9254)
    //     0xba9230: tbz             w0, #0, #0xba9254
    // 0xba9234: r3 = LoadClassIdInstr(r0)
    //     0xba9234: ldur            x3, [x0, #-1]
    //     0xba9238: ubfx            x3, x3, #0xc, #0x14
    // 0xba923c: r17 = 4157
    //     0xba923c: mov             x17, #0x103d
    // 0xba9240: cmp             x3, x17
    // 0xba9244: b.eq            #0xba925c
    // 0xba9248: r17 = 5286
    //     0xba9248: mov             x17, #0x14a6
    // 0xba924c: cmp             x3, x17
    // 0xba9250: b.eq            #0xba925c
    // 0xba9254: r0 = false
    //     0xba9254: add             x0, NULL, #0x30  ; false
    // 0xba9258: b               #0xba9260
    // 0xba925c: r0 = true
    //     0xba925c: add             x0, NULL, #0x20  ; true
    // 0xba9260: tbnz            w0, #4, #0xba9288
    // 0xba9264: ldur            x1, [fp, #-8]
    // 0xba9268: ldur            x2, [fp, #-0x18]
    // 0xba926c: d0 = 18.000000
    //     0xba926c: fmov            d0, #18.00000000
    // 0xba9270: r0 = isWithinGlobalTolerance()
    //     0xba9270: bl              #0xba9d20  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::isWithinGlobalTolerance
    // 0xba9274: tbz             w0, #4, #0xba92dc
    // 0xba9278: ldur            x1, [fp, #-0x10]
    // 0xba927c: ldur            x2, [fp, #-8]
    // 0xba9280: r0 = _reject()
    //     0xba9280: bl              #0xba92f8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0xba9284: b               #0xba92dc
    // 0xba9288: ldur            x0, [fp, #-0x18]
    // 0xba928c: r2 = Null
    //     0xba928c: mov             x2, NULL
    // 0xba9290: r1 = Null
    //     0xba9290: mov             x1, NULL
    // 0xba9294: cmp             w0, NULL
    // 0xba9298: b.eq            #0xba92c0
    // 0xba929c: branchIfSmi(r0, 0xba92c0)
    //     0xba929c: tbz             w0, #0, #0xba92c0
    // 0xba92a0: r3 = LoadClassIdInstr(r0)
    //     0xba92a0: ldur            x3, [x0, #-1]
    //     0xba92a4: ubfx            x3, x3, #0xc, #0x14
    // 0xba92a8: r17 = 4139
    //     0xba92a8: mov             x17, #0x102b
    // 0xba92ac: cmp             x3, x17
    // 0xba92b0: b.eq            #0xba92c8
    // 0xba92b4: r17 = 5276
    //     0xba92b4: mov             x17, #0x149c
    // 0xba92b8: cmp             x3, x17
    // 0xba92bc: b.eq            #0xba92c8
    // 0xba92c0: r0 = false
    //     0xba92c0: add             x0, NULL, #0x30  ; false
    // 0xba92c4: b               #0xba92cc
    // 0xba92c8: r0 = true
    //     0xba92c8: add             x0, NULL, #0x20  ; true
    // 0xba92cc: tbnz            w0, #4, #0xba92dc
    // 0xba92d0: ldur            x1, [fp, #-0x10]
    // 0xba92d4: ldur            x2, [fp, #-8]
    // 0xba92d8: r0 = _reject()
    //     0xba92d8: bl              #0xba92f8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0xba92dc: r0 = Null
    //     0xba92dc: mov             x0, NULL
    // 0xba92e0: LeaveFrame
    //     0xba92e0: mov             SP, fp
    //     0xba92e4: ldp             fp, lr, [SP], #0x10
    // 0xba92e8: ret
    //     0xba92e8: ret             
    // 0xba92ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba92ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba92f0: b               #0xba9124
    // 0xba92f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba92f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reject(/* No info */) {
    // ** addr: 0xba92f8, size: 0xf4
    // 0xba92f8: EnterFrame
    //     0xba92f8: stp             fp, lr, [SP, #-0x10]!
    //     0xba92fc: mov             fp, SP
    // 0xba9300: AllocStack(0x18)
    //     0xba9300: sub             SP, SP, #0x18
    // 0xba9304: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xba9304: mov             x4, x1
    //     0xba9308: mov             x3, x2
    //     0xba930c: stur            x1, [fp, #-0x10]
    //     0xba9310: stur            x2, [fp, #-0x18]
    // 0xba9314: CheckStackOverflow
    //     0xba9314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9318: cmp             SP, x16
    //     0xba931c: b.ls            #0xba93e4
    // 0xba9320: LoadField: r5 = r4->field_2b
    //     0xba9320: ldur            w5, [x4, #0x2b]
    // 0xba9324: DecompressPointer r5
    //     0xba9324: add             x5, x5, HEAP, lsl #32
    // 0xba9328: stur            x5, [fp, #-8]
    // 0xba932c: LoadField: r2 = r3->field_7
    //     0xba932c: ldur            x2, [x3, #7]
    // 0xba9330: r0 = BoxInt64Instr(r2)
    //     0xba9330: sbfiz           x0, x2, #1, #0x1f
    //     0xba9334: cmp             x2, x0, asr #1
    //     0xba9338: b.eq            #0xba9344
    //     0xba933c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba9340: stur            x2, [x0, #7]
    // 0xba9344: mov             x1, x5
    // 0xba9348: mov             x2, x0
    // 0xba934c: r0 = remove()
    //     0xba934c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba9350: ldur            x0, [fp, #-0x18]
    // 0xba9354: LoadField: r1 = r0->field_f
    //     0xba9354: ldur            w1, [x0, #0xf]
    // 0xba9358: DecompressPointer r1
    //     0xba9358: add             x1, x1, HEAP, lsl #32
    // 0xba935c: r2 = Instance_GestureDisposition
    //     0xba935c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xba9360: ldr             x2, [x2, #0x610]
    // 0xba9364: r0 = resolve()
    //     0xba9364: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xba9368: ldur            x1, [fp, #-0x10]
    // 0xba936c: ldur            x2, [fp, #-0x18]
    // 0xba9370: r0 = _freezeTracker()
    //     0xba9370: bl              #0xba9440  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0xba9374: ldur            x0, [fp, #-0x10]
    // 0xba9378: LoadField: r1 = r0->field_27
    //     0xba9378: ldur            w1, [x0, #0x27]
    // 0xba937c: DecompressPointer r1
    //     0xba937c: add             x1, x1, HEAP, lsl #32
    // 0xba9380: cmp             w1, NULL
    // 0xba9384: b.eq            #0xba93d4
    // 0xba9388: ldur            x2, [fp, #-0x18]
    // 0xba938c: cmp             w2, w1
    // 0xba9390: b.ne            #0xba93a0
    // 0xba9394: mov             x1, x0
    // 0xba9398: r0 = _reset()
    //     0xba9398: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xba939c: b               #0xba93d4
    // 0xba93a0: ldur            x2, [fp, #-8]
    // 0xba93a4: mov             x1, x0
    // 0xba93a8: r0 = _checkCancel()
    //     0xba93a8: bl              #0xba93ec  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_checkCancel
    // 0xba93ac: ldur            x0, [fp, #-8]
    // 0xba93b0: LoadField: r1 = r0->field_13
    //     0xba93b0: ldur            w1, [x0, #0x13]
    // 0xba93b4: r2 = LoadInt32Instr(r1)
    //     0xba93b4: sbfx            x2, x1, #1, #0x1f
    // 0xba93b8: asr             x1, x2, #1
    // 0xba93bc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xba93bc: ldur            w2, [x0, #0x17]
    // 0xba93c0: r0 = LoadInt32Instr(r2)
    //     0xba93c0: sbfx            x0, x2, #1, #0x1f
    // 0xba93c4: sub             x2, x1, x0
    // 0xba93c8: cbnz            x2, #0xba93d4
    // 0xba93cc: ldur            x1, [fp, #-0x10]
    // 0xba93d0: r0 = _reset()
    //     0xba93d0: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xba93d4: r0 = Null
    //     0xba93d4: mov             x0, NULL
    // 0xba93d8: LeaveFrame
    //     0xba93d8: mov             SP, fp
    //     0xba93dc: ldp             fp, lr, [SP], #0x10
    // 0xba93e0: ret
    //     0xba93e0: ret             
    // 0xba93e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba93e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba93e8: b               #0xba9320
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0xba93ec, size: 0x54
    // 0xba93ec: EnterFrame
    //     0xba93ec: stp             fp, lr, [SP, #-0x10]!
    //     0xba93f0: mov             fp, SP
    // 0xba93f4: AllocStack(0x18)
    //     0xba93f4: sub             SP, SP, #0x18
    // 0xba93f8: CheckStackOverflow
    //     0xba93f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba93fc: cmp             SP, x16
    //     0xba9400: b.ls            #0xba9438
    // 0xba9404: LoadField: r0 = r1->field_1f
    //     0xba9404: ldur            w0, [x1, #0x1f]
    // 0xba9408: DecompressPointer r0
    //     0xba9408: add             x0, x0, HEAP, lsl #32
    // 0xba940c: cmp             w0, NULL
    // 0xba9410: b.eq            #0xba9428
    // 0xba9414: r16 = <void?>
    //     0xba9414: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba9418: stp             x1, x16, [SP, #8]
    // 0xba941c: str             x0, [SP]
    // 0xba9420: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba9420: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba9424: r0 = invokeCallback()
    //     0xba9424: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba9428: r0 = Null
    //     0xba9428: mov             x0, NULL
    // 0xba942c: LeaveFrame
    //     0xba942c: mov             SP, fp
    //     0xba9430: ldp             fp, lr, [SP], #0x10
    // 0xba9434: ret
    //     0xba9434: ret             
    // 0xba9438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba943c: b               #0xba9404
  }
  _ _freezeTracker(/* No info */) {
    // ** addr: 0xba9440, size: 0x54
    // 0xba9440: EnterFrame
    //     0xba9440: stp             fp, lr, [SP, #-0x10]!
    //     0xba9444: mov             fp, SP
    // 0xba9448: AllocStack(0x8)
    //     0xba9448: sub             SP, SP, #8
    // 0xba944c: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xba944c: mov             x0, x2
    //     0xba9450: stur            x2, [fp, #-8]
    //     0xba9454: mov             x2, x1
    // 0xba9458: CheckStackOverflow
    //     0xba9458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba945c: cmp             SP, x16
    //     0xba9460: b.ls            #0xba948c
    // 0xba9464: r1 = Function '_handleEvent@659391311':.
    //     0xba9464: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cdb0] AnonymousClosure: (0xba90c4), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent (0xba9100)
    //     0xba9468: ldr             x1, [x1, #0xdb0]
    // 0xba946c: r0 = AllocateClosure()
    //     0xba946c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba9470: ldur            x1, [fp, #-8]
    // 0xba9474: mov             x2, x0
    // 0xba9478: r0 = stopTrackingPointer()
    //     0xba9478: bl              #0xba9494  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::stopTrackingPointer
    // 0xba947c: r0 = Null
    //     0xba947c: mov             x0, NULL
    // 0xba9480: LeaveFrame
    //     0xba9480: mov             SP, fp
    //     0xba9484: ldp             fp, lr, [SP], #0x10
    // 0xba9488: ret
    //     0xba9488: ret             
    // 0xba948c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba948c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9490: b               #0xba9464
  }
  _ _registerSecondTap(/* No info */) {
    // ** addr: 0xba9504, size: 0xd4
    // 0xba9504: EnterFrame
    //     0xba9504: stp             fp, lr, [SP, #-0x10]!
    //     0xba9508: mov             fp, SP
    // 0xba950c: AllocStack(0x10)
    //     0xba950c: sub             SP, SP, #0x10
    // 0xba9510: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba9510: mov             x3, x1
    //     0xba9514: mov             x0, x2
    //     0xba9518: stur            x1, [fp, #-8]
    //     0xba951c: stur            x2, [fp, #-0x10]
    // 0xba9520: CheckStackOverflow
    //     0xba9520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9524: cmp             SP, x16
    //     0xba9528: b.ls            #0xba95cc
    // 0xba952c: LoadField: r1 = r3->field_27
    //     0xba952c: ldur            w1, [x3, #0x27]
    // 0xba9530: DecompressPointer r1
    //     0xba9530: add             x1, x1, HEAP, lsl #32
    // 0xba9534: cmp             w1, NULL
    // 0xba9538: b.eq            #0xba95d4
    // 0xba953c: LoadField: r2 = r1->field_f
    //     0xba953c: ldur            w2, [x1, #0xf]
    // 0xba9540: DecompressPointer r2
    //     0xba9540: add             x2, x2, HEAP, lsl #32
    // 0xba9544: mov             x1, x2
    // 0xba9548: r2 = Instance_GestureDisposition
    //     0xba9548: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba954c: ldr             x2, [x2, #0x628]
    // 0xba9550: r0 = resolve()
    //     0xba9550: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xba9554: ldur            x0, [fp, #-0x10]
    // 0xba9558: LoadField: r1 = r0->field_f
    //     0xba9558: ldur            w1, [x0, #0xf]
    // 0xba955c: DecompressPointer r1
    //     0xba955c: add             x1, x1, HEAP, lsl #32
    // 0xba9560: r2 = Instance_GestureDisposition
    //     0xba9560: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba9564: ldr             x2, [x2, #0x628]
    // 0xba9568: r0 = resolve()
    //     0xba9568: bl              #0x12fcb3c  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xba956c: ldur            x1, [fp, #-8]
    // 0xba9570: ldur            x2, [fp, #-0x10]
    // 0xba9574: r0 = _freezeTracker()
    //     0xba9574: bl              #0xba9440  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0xba9578: ldur            x3, [fp, #-8]
    // 0xba957c: LoadField: r2 = r3->field_2b
    //     0xba957c: ldur            w2, [x3, #0x2b]
    // 0xba9580: DecompressPointer r2
    //     0xba9580: add             x2, x2, HEAP, lsl #32
    // 0xba9584: ldur            x0, [fp, #-0x10]
    // 0xba9588: LoadField: r4 = r0->field_7
    //     0xba9588: ldur            x4, [x0, #7]
    // 0xba958c: r0 = BoxInt64Instr(r4)
    //     0xba958c: sbfiz           x0, x4, #1, #0x1f
    //     0xba9590: cmp             x4, x0, asr #1
    //     0xba9594: b.eq            #0xba95a0
    //     0xba9598: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba959c: stur            x4, [x0, #7]
    // 0xba95a0: mov             x1, x2
    // 0xba95a4: mov             x2, x0
    // 0xba95a8: r0 = remove()
    //     0xba95a8: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba95ac: ldur            x1, [fp, #-8]
    // 0xba95b0: r0 = _checkUp()
    //     0xba95b0: bl              #0xba95d8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_checkUp
    // 0xba95b4: ldur            x1, [fp, #-8]
    // 0xba95b8: r0 = _reset()
    //     0xba95b8: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xba95bc: r0 = Null
    //     0xba95bc: mov             x0, NULL
    // 0xba95c0: LeaveFrame
    //     0xba95c0: mov             SP, fp
    //     0xba95c4: ldp             fp, lr, [SP], #0x10
    // 0xba95c8: ret
    //     0xba95c8: ret             
    // 0xba95cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba95cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba95d0: b               #0xba952c
    // 0xba95d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba95d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkUp(/* No info */) {
    // ** addr: 0xba95d8, size: 0x54
    // 0xba95d8: EnterFrame
    //     0xba95d8: stp             fp, lr, [SP, #-0x10]!
    //     0xba95dc: mov             fp, SP
    // 0xba95e0: AllocStack(0x18)
    //     0xba95e0: sub             SP, SP, #0x18
    // 0xba95e4: CheckStackOverflow
    //     0xba95e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba95e8: cmp             SP, x16
    //     0xba95ec: b.ls            #0xba9624
    // 0xba95f0: LoadField: r0 = r1->field_1b
    //     0xba95f0: ldur            w0, [x1, #0x1b]
    // 0xba95f4: DecompressPointer r0
    //     0xba95f4: add             x0, x0, HEAP, lsl #32
    // 0xba95f8: cmp             w0, NULL
    // 0xba95fc: b.eq            #0xba9614
    // 0xba9600: r16 = <void?>
    //     0xba9600: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba9604: stp             x1, x16, [SP, #8]
    // 0xba9608: str             x0, [SP]
    // 0xba960c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba960c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba9610: r0 = invokeCallback()
    //     0xba9610: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba9614: r0 = Null
    //     0xba9614: mov             x0, NULL
    // 0xba9618: LeaveFrame
    //     0xba9618: mov             SP, fp
    //     0xba961c: ldp             fp, lr, [SP], #0x10
    // 0xba9620: ret
    //     0xba9620: ret             
    // 0xba9624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9628: b               #0xba95f0
  }
  _ _registerFirstTap(/* No info */) {
    // ** addr: 0xba962c, size: 0xdc
    // 0xba962c: EnterFrame
    //     0xba962c: stp             fp, lr, [SP, #-0x10]!
    //     0xba9630: mov             fp, SP
    // 0xba9634: AllocStack(0x18)
    //     0xba9634: sub             SP, SP, #0x18
    // 0xba9638: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba9638: mov             x0, x1
    //     0xba963c: stur            x1, [fp, #-8]
    //     0xba9640: stur            x2, [fp, #-0x10]
    // 0xba9644: CheckStackOverflow
    //     0xba9644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9648: cmp             SP, x16
    //     0xba964c: b.ls            #0xba96fc
    // 0xba9650: mov             x1, x0
    // 0xba9654: r0 = _startDoubleTapTimer()
    //     0xba9654: bl              #0xba98b8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_startDoubleTapTimer
    // 0xba9658: r0 = LoadStaticField(0x7d0)
    //     0xba9658: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xba965c: ldr             x0, [x0, #0xfa0]
    // 0xba9660: cmp             w0, NULL
    // 0xba9664: b.eq            #0xba9704
    // 0xba9668: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba9668: ldur            w1, [x0, #0x17]
    // 0xba966c: DecompressPointer r1
    //     0xba966c: add             x1, x1, HEAP, lsl #32
    // 0xba9670: ldur            x0, [fp, #-0x10]
    // 0xba9674: LoadField: r3 = r0->field_7
    //     0xba9674: ldur            x3, [x0, #7]
    // 0xba9678: mov             x2, x3
    // 0xba967c: stur            x3, [fp, #-0x18]
    // 0xba9680: r0 = hold()
    //     0xba9680: bl              #0xba981c  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::hold
    // 0xba9684: ldur            x1, [fp, #-8]
    // 0xba9688: ldur            x2, [fp, #-0x10]
    // 0xba968c: r0 = _freezeTracker()
    //     0xba968c: bl              #0xba9440  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0xba9690: ldur            x3, [fp, #-8]
    // 0xba9694: LoadField: r2 = r3->field_2b
    //     0xba9694: ldur            w2, [x3, #0x2b]
    // 0xba9698: DecompressPointer r2
    //     0xba9698: add             x2, x2, HEAP, lsl #32
    // 0xba969c: ldur            x4, [fp, #-0x18]
    // 0xba96a0: r0 = BoxInt64Instr(r4)
    //     0xba96a0: sbfiz           x0, x4, #1, #0x1f
    //     0xba96a4: cmp             x4, x0, asr #1
    //     0xba96a8: b.eq            #0xba96b4
    //     0xba96ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba96b0: stur            x4, [x0, #7]
    // 0xba96b4: mov             x1, x2
    // 0xba96b8: mov             x2, x0
    // 0xba96bc: r0 = remove()
    //     0xba96bc: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba96c0: ldur            x1, [fp, #-8]
    // 0xba96c4: r0 = _clearTrackers()
    //     0xba96c4: bl              #0xba9708  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_clearTrackers
    // 0xba96c8: ldur            x0, [fp, #-0x10]
    // 0xba96cc: ldur            x1, [fp, #-8]
    // 0xba96d0: StoreField: r1->field_27 = r0
    //     0xba96d0: stur            w0, [x1, #0x27]
    //     0xba96d4: ldurb           w16, [x1, #-1]
    //     0xba96d8: ldurb           w17, [x0, #-1]
    //     0xba96dc: and             x16, x17, x16, lsr #2
    //     0xba96e0: tst             x16, HEAP, lsr #32
    //     0xba96e4: b.eq            #0xba96ec
    //     0xba96e8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba96ec: r0 = Null
    //     0xba96ec: mov             x0, NULL
    // 0xba96f0: LeaveFrame
    //     0xba96f0: mov             SP, fp
    //     0xba96f4: ldp             fp, lr, [SP], #0x10
    // 0xba96f8: ret
    //     0xba96f8: ret             
    // 0xba96fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba96fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9700: b               #0xba9650
    // 0xba9704: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba9704: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clearTrackers(/* No info */) {
    // ** addr: 0xba9708, size: 0x114
    // 0xba9708: EnterFrame
    //     0xba9708: stp             fp, lr, [SP, #-0x10]!
    //     0xba970c: mov             fp, SP
    // 0xba9710: AllocStack(0x20)
    //     0xba9710: sub             SP, SP, #0x20
    // 0xba9714: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x10 */)
    //     0xba9714: mov             x0, x1
    //     0xba9718: stur            x1, [fp, #-0x10]
    // 0xba971c: CheckStackOverflow
    //     0xba971c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9720: cmp             SP, x16
    //     0xba9724: b.ls            #0xba9808
    // 0xba9728: LoadField: r2 = r0->field_2b
    //     0xba9728: ldur            w2, [x0, #0x2b]
    // 0xba972c: DecompressPointer r2
    //     0xba972c: add             x2, x2, HEAP, lsl #32
    // 0xba9730: stur            x2, [fp, #-8]
    // 0xba9734: r1 = <_TapTracker>
    //     0xba9734: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cda8] TypeArguments: <_TapTracker>
    //     0xba9738: ldr             x1, [x1, #0xda8]
    // 0xba973c: r0 = _CompactValuesIterable()
    //     0xba973c: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba9740: mov             x1, x0
    // 0xba9744: ldur            x0, [fp, #-8]
    // 0xba9748: StoreField: r1->field_b = r0
    //     0xba9748: stur            w0, [x1, #0xb]
    // 0xba974c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xba974c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xba9750: r0 = toList()
    //     0xba9750: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0xba9754: mov             x3, x0
    // 0xba9758: stur            x3, [fp, #-0x20]
    // 0xba975c: LoadField: r4 = r3->field_b
    //     0xba975c: ldur            w4, [x3, #0xb]
    // 0xba9760: stur            x4, [fp, #-8]
    // 0xba9764: r0 = LoadInt32Instr(r4)
    //     0xba9764: sbfx            x0, x4, #1, #0x1f
    // 0xba9768: r5 = 0
    //     0xba9768: mov             x5, #0
    // 0xba976c: stur            x5, [fp, #-0x18]
    // 0xba9770: CheckStackOverflow
    //     0xba9770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9774: cmp             SP, x16
    //     0xba9778: b.ls            #0xba9810
    // 0xba977c: cmp             x5, x0
    // 0xba9780: b.ge            #0xba97dc
    // 0xba9784: mov             x1, x5
    // 0xba9788: cmp             x1, x0
    // 0xba978c: b.hs            #0xba9818
    // 0xba9790: LoadField: r0 = r3->field_f
    //     0xba9790: ldur            w0, [x3, #0xf]
    // 0xba9794: DecompressPointer r0
    //     0xba9794: add             x0, x0, HEAP, lsl #32
    // 0xba9798: ArrayLoad: r2 = r0[r5]  ; Unknown_4
    //     0xba9798: add             x16, x0, x5, lsl #2
    //     0xba979c: ldur            w2, [x16, #0xf]
    // 0xba97a0: DecompressPointer r2
    //     0xba97a0: add             x2, x2, HEAP, lsl #32
    // 0xba97a4: ldur            x1, [fp, #-0x10]
    // 0xba97a8: r0 = _reject()
    //     0xba97a8: bl              #0xba92f8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0xba97ac: ldur            x1, [fp, #-0x20]
    // 0xba97b0: LoadField: r0 = r1->field_b
    //     0xba97b0: ldur            w0, [x1, #0xb]
    // 0xba97b4: ldur            x2, [fp, #-8]
    // 0xba97b8: cmp             w0, w2
    // 0xba97bc: b.ne            #0xba97ec
    // 0xba97c0: ldur            x3, [fp, #-0x18]
    // 0xba97c4: add             x5, x3, #1
    // 0xba97c8: r3 = LoadInt32Instr(r0)
    //     0xba97c8: sbfx            x3, x0, #1, #0x1f
    // 0xba97cc: mov             x0, x3
    // 0xba97d0: mov             x3, x1
    // 0xba97d4: mov             x4, x2
    // 0xba97d8: b               #0xba976c
    // 0xba97dc: r0 = Null
    //     0xba97dc: mov             x0, NULL
    // 0xba97e0: LeaveFrame
    //     0xba97e0: mov             SP, fp
    //     0xba97e4: ldp             fp, lr, [SP], #0x10
    // 0xba97e8: ret
    //     0xba97e8: ret             
    // 0xba97ec: r0 = ConcurrentModificationError()
    //     0xba97ec: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xba97f0: mov             x1, x0
    // 0xba97f4: ldur            x0, [fp, #-0x20]
    // 0xba97f8: StoreField: r1->field_b = r0
    //     0xba97f8: stur            w0, [x1, #0xb]
    // 0xba97fc: mov             x0, x1
    // 0xba9800: r0 = Throw()
    //     0xba9800: bl              #0x13ddb2c  ; ThrowStub
    // 0xba9804: brk             #0
    // 0xba9808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9808: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba980c: b               #0xba9728
    // 0xba9810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9814: b               #0xba977c
    // 0xba9818: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xba9818: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _startDoubleTapTimer(/* No info */) {
    // ** addr: 0xba98b8, size: 0x88
    // 0xba98b8: EnterFrame
    //     0xba98b8: stp             fp, lr, [SP, #-0x10]!
    //     0xba98bc: mov             fp, SP
    // 0xba98c0: AllocStack(0x8)
    //     0xba98c0: sub             SP, SP, #8
    // 0xba98c4: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba98c4: mov             x0, x1
    //     0xba98c8: stur            x1, [fp, #-8]
    // 0xba98cc: CheckStackOverflow
    //     0xba98cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba98d0: cmp             SP, x16
    //     0xba98d4: b.ls            #0xba9938
    // 0xba98d8: LoadField: r1 = r0->field_23
    //     0xba98d8: ldur            w1, [x0, #0x23]
    // 0xba98dc: DecompressPointer r1
    //     0xba98dc: add             x1, x1, HEAP, lsl #32
    // 0xba98e0: cmp             w1, NULL
    // 0xba98e4: b.ne            #0xba9928
    // 0xba98e8: mov             x2, x0
    // 0xba98ec: r1 = Function '_reset@659391311':.
    //     0xba98ec: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cdb8] AnonymousClosure: (0xba9940), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset (0xba9978)
    //     0xba98f0: ldr             x1, [x1, #0xdb8]
    // 0xba98f4: r0 = AllocateClosure()
    //     0xba98f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba98f8: mov             x3, x0
    // 0xba98fc: r1 = Null
    //     0xba98fc: mov             x1, NULL
    // 0xba9900: r2 = Instance_Duration
    //     0xba9900: ldr             x2, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xba9904: r0 = Timer()
    //     0xba9904: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xba9908: ldur            x1, [fp, #-8]
    // 0xba990c: StoreField: r1->field_23 = r0
    //     0xba990c: stur            w0, [x1, #0x23]
    //     0xba9910: ldurb           w16, [x1, #-1]
    //     0xba9914: ldurb           w17, [x0, #-1]
    //     0xba9918: and             x16, x17, x16, lsr #2
    //     0xba991c: tst             x16, HEAP, lsr #32
    //     0xba9920: b.eq            #0xba9928
    //     0xba9924: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba9928: r0 = Null
    //     0xba9928: mov             x0, NULL
    // 0xba992c: LeaveFrame
    //     0xba992c: mov             SP, fp
    //     0xba9930: ldp             fp, lr, [SP], #0x10
    // 0xba9934: ret
    //     0xba9934: ret             
    // 0xba9938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba993c: b               #0xba98d8
  }
  [closure] void _reset(dynamic) {
    // ** addr: 0xba9940, size: 0x38
    // 0xba9940: EnterFrame
    //     0xba9940: stp             fp, lr, [SP, #-0x10]!
    //     0xba9944: mov             fp, SP
    // 0xba9948: ldr             x0, [fp, #0x10]
    // 0xba994c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba994c: ldur            w1, [x0, #0x17]
    // 0xba9950: DecompressPointer r1
    //     0xba9950: add             x1, x1, HEAP, lsl #32
    // 0xba9954: CheckStackOverflow
    //     0xba9954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9958: cmp             SP, x16
    //     0xba995c: b.ls            #0xba9970
    // 0xba9960: r0 = _reset()
    //     0xba9960: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xba9964: LeaveFrame
    //     0xba9964: mov             SP, fp
    //     0xba9968: ldp             fp, lr, [SP], #0x10
    // 0xba996c: ret
    //     0xba996c: ret             
    // 0xba9970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9974: b               #0xba9960
  }
  _ _reset(/* No info */) {
    // ** addr: 0xba9978, size: 0xdc
    // 0xba9978: EnterFrame
    //     0xba9978: stp             fp, lr, [SP, #-0x10]!
    //     0xba997c: mov             fp, SP
    // 0xba9980: AllocStack(0x10)
    //     0xba9980: sub             SP, SP, #0x10
    // 0xba9984: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba9984: mov             x0, x1
    //     0xba9988: stur            x1, [fp, #-8]
    // 0xba998c: CheckStackOverflow
    //     0xba998c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9990: cmp             SP, x16
    //     0xba9994: b.ls            #0xba9a44
    // 0xba9998: mov             x1, x0
    // 0xba999c: r0 = _stopDoubleTapTimer()
    //     0xba999c: bl              #0xba9070  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_stopDoubleTapTimer
    // 0xba99a0: ldur            x0, [fp, #-8]
    // 0xba99a4: LoadField: r1 = r0->field_27
    //     0xba99a4: ldur            w1, [x0, #0x27]
    // 0xba99a8: DecompressPointer r1
    //     0xba99a8: add             x1, x1, HEAP, lsl #32
    // 0xba99ac: cmp             w1, NULL
    // 0xba99b0: b.eq            #0xba9a2c
    // 0xba99b4: LoadField: r1 = r0->field_2b
    //     0xba99b4: ldur            w1, [x0, #0x2b]
    // 0xba99b8: DecompressPointer r1
    //     0xba99b8: add             x1, x1, HEAP, lsl #32
    // 0xba99bc: LoadField: r2 = r1->field_13
    //     0xba99bc: ldur            w2, [x1, #0x13]
    // 0xba99c0: r3 = LoadInt32Instr(r2)
    //     0xba99c0: sbfx            x3, x2, #1, #0x1f
    // 0xba99c4: asr             x2, x3, #1
    // 0xba99c8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xba99c8: ldur            w3, [x1, #0x17]
    // 0xba99cc: r1 = LoadInt32Instr(r3)
    //     0xba99cc: sbfx            x1, x3, #1, #0x1f
    // 0xba99d0: sub             x3, x2, x1
    // 0xba99d4: cbz             x3, #0xba99e0
    // 0xba99d8: mov             x1, x0
    // 0xba99dc: r0 = _checkCancel()
    //     0xba99dc: bl              #0xba93ec  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_checkCancel
    // 0xba99e0: ldur            x0, [fp, #-8]
    // 0xba99e4: LoadField: r3 = r0->field_27
    //     0xba99e4: ldur            w3, [x0, #0x27]
    // 0xba99e8: DecompressPointer r3
    //     0xba99e8: add             x3, x3, HEAP, lsl #32
    // 0xba99ec: stur            x3, [fp, #-0x10]
    // 0xba99f0: cmp             w3, NULL
    // 0xba99f4: b.eq            #0xba9a4c
    // 0xba99f8: StoreField: r0->field_27 = rNULL
    //     0xba99f8: stur            NULL, [x0, #0x27]
    // 0xba99fc: mov             x1, x0
    // 0xba9a00: mov             x2, x3
    // 0xba9a04: r0 = _reject()
    //     0xba9a04: bl              #0xba92f8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0xba9a08: r0 = LoadStaticField(0x7d0)
    //     0xba9a08: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xba9a0c: ldr             x0, [x0, #0xfa0]
    // 0xba9a10: cmp             w0, NULL
    // 0xba9a14: b.eq            #0xba9a50
    // 0xba9a18: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba9a18: ldur            w1, [x0, #0x17]
    // 0xba9a1c: DecompressPointer r1
    //     0xba9a1c: add             x1, x1, HEAP, lsl #32
    // 0xba9a20: ldur            x0, [fp, #-0x10]
    // 0xba9a24: LoadField: r2 = r0->field_7
    //     0xba9a24: ldur            x2, [x0, #7]
    // 0xba9a28: r0 = release()
    //     0xba9a28: bl              #0xba9a54  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::release
    // 0xba9a2c: ldur            x1, [fp, #-8]
    // 0xba9a30: r0 = _clearTrackers()
    //     0xba9a30: bl              #0xba9708  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_clearTrackers
    // 0xba9a34: r0 = Null
    //     0xba9a34: mov             x0, NULL
    // 0xba9a38: LeaveFrame
    //     0xba9a38: mov             SP, fp
    //     0xba9a3c: ldp             fp, lr, [SP], #0x10
    // 0xba9a40: ret
    //     0xba9a40: ret             
    // 0xba9a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9a48: b               #0xba9998
    // 0xba9a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba9a4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba9a50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba9a50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba9dbc, size: 0x70
    // 0xba9dbc: EnterFrame
    //     0xba9dbc: stp             fp, lr, [SP, #-0x10]!
    //     0xba9dc0: mov             fp, SP
    // 0xba9dc4: AllocStack(0x10)
    //     0xba9dc4: sub             SP, SP, #0x10
    // 0xba9dc8: SetupParameters([dynamic _ /* r0 */])
    //     0xba9dc8: ldr             x0, [fp, #0x10]
    //     0xba9dcc: ldur            w1, [x0, #0x17]
    //     0xba9dd0: add             x1, x1, HEAP, lsl #32
    // 0xba9dd4: CheckStackOverflow
    //     0xba9dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba9dd8: cmp             SP, x16
    //     0xba9ddc: b.ls            #0xba9e20
    // 0xba9de0: LoadField: r0 = r1->field_f
    //     0xba9de0: ldur            w0, [x1, #0xf]
    // 0xba9de4: DecompressPointer r0
    //     0xba9de4: add             x0, x0, HEAP, lsl #32
    // 0xba9de8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xba9de8: ldur            w2, [x0, #0x17]
    // 0xba9dec: DecompressPointer r2
    //     0xba9dec: add             x2, x2, HEAP, lsl #32
    // 0xba9df0: cmp             w2, NULL
    // 0xba9df4: b.eq            #0xba9e28
    // 0xba9df8: LoadField: r0 = r1->field_13
    //     0xba9df8: ldur            w0, [x1, #0x13]
    // 0xba9dfc: DecompressPointer r0
    //     0xba9dfc: add             x0, x0, HEAP, lsl #32
    // 0xba9e00: stp             x0, x2, [SP]
    // 0xba9e04: mov             x0, x2
    // 0xba9e08: ClosureCall
    //     0xba9e08: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba9e0c: ldur            x2, [x0, #0x1f]
    //     0xba9e10: blr             x2
    // 0xba9e14: LeaveFrame
    //     0xba9e14: mov             SP, fp
    //     0xba9e18: ldp             fp, lr, [SP], #0x10
    // 0xba9e1c: ret
    //     0xba9e1c: ret             
    // 0xba9e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9e24: b               #0xba9de0
    // 0xba9e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba9e28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb19cc, size: 0x30
    // 0xbb19cc: EnterFrame
    //     0xbb19cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbb19d0: mov             fp, SP
    // 0xbb19d4: CheckStackOverflow
    //     0xbb19d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb19d8: cmp             SP, x16
    //     0xbb19dc: b.ls            #0xbb19f4
    // 0xbb19e0: r0 = _reset()
    //     0xbb19e0: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xbb19e4: r0 = Null
    //     0xbb19e4: mov             x0, NULL
    // 0xbb19e8: LeaveFrame
    //     0xbb19e8: mov             SP, fp
    //     0xbb19ec: ldp             fp, lr, [SP], #0x10
    // 0xbb19f0: ret
    //     0xbb19f0: ret             
    // 0xbb19f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb19f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb19f8: b               #0xbb19e0
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb7704, size: 0xa0
    // 0xbb7704: EnterFrame
    //     0xbb7704: stp             fp, lr, [SP, #-0x10]!
    //     0xbb7708: mov             fp, SP
    // 0xbb770c: AllocStack(0x10)
    //     0xbb770c: sub             SP, SP, #0x10
    // 0xbb7710: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xbb7710: mov             x0, x1
    //     0xbb7714: stur            x1, [fp, #-8]
    // 0xbb7718: CheckStackOverflow
    //     0xbb7718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb771c: cmp             SP, x16
    //     0xbb7720: b.ls            #0xbb779c
    // 0xbb7724: LoadField: r1 = r0->field_27
    //     0xbb7724: ldur            w1, [x0, #0x27]
    // 0xbb7728: DecompressPointer r1
    //     0xbb7728: add             x1, x1, HEAP, lsl #32
    // 0xbb772c: cmp             w1, NULL
    // 0xbb7730: b.ne            #0xbb7774
    // 0xbb7734: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbb7734: ldur            w1, [x0, #0x17]
    // 0xbb7738: DecompressPointer r1
    //     0xbb7738: add             x1, x1, HEAP, lsl #32
    // 0xbb773c: cmp             w1, NULL
    // 0xbb7740: b.ne            #0xbb7774
    // 0xbb7744: LoadField: r1 = r0->field_1b
    //     0xbb7744: ldur            w1, [x0, #0x1b]
    // 0xbb7748: DecompressPointer r1
    //     0xbb7748: add             x1, x1, HEAP, lsl #32
    // 0xbb774c: cmp             w1, NULL
    // 0xbb7750: b.ne            #0xbb7774
    // 0xbb7754: LoadField: r1 = r0->field_1f
    //     0xbb7754: ldur            w1, [x0, #0x1f]
    // 0xbb7758: DecompressPointer r1
    //     0xbb7758: add             x1, x1, HEAP, lsl #32
    // 0xbb775c: cmp             w1, NULL
    // 0xbb7760: b.ne            #0xbb7774
    // 0xbb7764: r0 = false
    //     0xbb7764: add             x0, NULL, #0x30  ; false
    // 0xbb7768: LeaveFrame
    //     0xbb7768: mov             SP, fp
    //     0xbb776c: ldp             fp, lr, [SP], #0x10
    // 0xbb7770: ret
    //     0xbb7770: ret             
    // 0xbb7774: mov             x1, x0
    // 0xbb7778: r0 = isPointerAllowed()
    //     0xbb7778: bl              #0xbb75f8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xbb777c: stur            x0, [fp, #-0x10]
    // 0xbb7780: tbz             w0, #4, #0xbb778c
    // 0xbb7784: ldur            x1, [fp, #-8]
    // 0xbb7788: r0 = _reset()
    //     0xbb7788: bl              #0xba9978  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xbb778c: ldur            x0, [fp, #-0x10]
    // 0xbb7790: LeaveFrame
    //     0xbb7790: mov             SP, fp
    //     0xbb7794: ldp             fp, lr, [SP], #0x10
    // 0xbb7798: ret
    //     0xbb7798: ret             
    // 0xbb779c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb779c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb77a0: b               #0xbb7724
  }
  _ DoubleTapGestureRecognizer(/* No info */) {
    // ** addr: 0xfc22bc, size: 0xa8
    // 0xfc22bc: EnterFrame
    //     0xfc22bc: stp             fp, lr, [SP, #-0x10]!
    //     0xfc22c0: mov             fp, SP
    // 0xfc22c4: AllocStack(0x18)
    //     0xfc22c4: sub             SP, SP, #0x18
    // 0xfc22c8: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xfc22c8: stur            x1, [fp, #-8]
    // 0xfc22cc: CheckStackOverflow
    //     0xfc22cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfc22d0: cmp             SP, x16
    //     0xfc22d4: b.ls            #0xfc235c
    // 0xfc22d8: r16 = <int, _TapTracker>
    //     0xfc22d8: add             x16, PP, #0x84, lsl #12  ; [pp+0x84e30] TypeArguments: <int, _TapTracker>
    //     0xfc22dc: ldr             x16, [x16, #0xe30]
    // 0xfc22e0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfc22e4: stp             lr, x16, [SP]
    // 0xfc22e8: r0 = Map._fromLiteral()
    //     0xfc22e8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc22ec: ldur            x1, [fp, #-8]
    // 0xfc22f0: StoreField: r1->field_2b = r0
    //     0xfc22f0: stur            w0, [x1, #0x2b]
    //     0xfc22f4: ldurb           w16, [x1, #-1]
    //     0xfc22f8: ldurb           w17, [x0, #-1]
    //     0xfc22fc: and             x16, x17, x16, lsr #2
    //     0xfc2300: tst             x16, HEAP, lsr #32
    //     0xfc2304: b.eq            #0xfc230c
    //     0xfc2308: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfc230c: r16 = <int, PointerDeviceKind>
    //     0xfc230c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15598] TypeArguments: <int, PointerDeviceKind>
    //     0xfc2310: ldr             x16, [x16, #0x598]
    // 0xfc2314: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfc2318: stp             lr, x16, [SP]
    // 0xfc231c: r0 = Map._fromLiteral()
    //     0xfc231c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc2320: ldur            x1, [fp, #-8]
    // 0xfc2324: StoreField: r1->field_13 = r0
    //     0xfc2324: stur            w0, [x1, #0x13]
    //     0xfc2328: ldurb           w16, [x1, #-1]
    //     0xfc232c: ldurb           w17, [x0, #-1]
    //     0xfc2330: and             x16, x17, x16, lsr #2
    //     0xfc2334: tst             x16, HEAP, lsr #32
    //     0xfc2338: b.eq            #0xfc2340
    //     0xfc233c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfc2340: r2 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@659391311': static.
    //     0xfc2340: add             x2, PP, #0x84, lsl #12  ; [pp+0x84e38] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@659391311': static. (0x7f2adaa74790)
    //     0xfc2344: ldr             x2, [x2, #0xe38]
    // 0xfc2348: StoreField: r1->field_f = r2
    //     0xfc2348: stur            w2, [x1, #0xf]
    // 0xfc234c: r0 = Null
    //     0xfc234c: mov             x0, NULL
    // 0xfc2350: LeaveFrame
    //     0xfc2350: mov             SP, fp
    //     0xfc2354: ldp             fp, lr, [SP], #0x10
    // 0xfc2358: ret
    //     0xfc2358: ret             
    // 0xfc235c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfc235c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfc2360: b               #0xfc22d8
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d2d8, size: 0xd4
    // 0x116d2d8: EnterFrame
    //     0x116d2d8: stp             fp, lr, [SP, #-0x10]!
    //     0x116d2dc: mov             fp, SP
    // 0x116d2e0: AllocStack(0x18)
    //     0x116d2e0: sub             SP, SP, #0x18
    // 0x116d2e4: SetupParameters(DoubleTapGestureRecognizer this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x116d2e4: mov             x4, x1
    //     0x116d2e8: mov             x3, x2
    //     0x116d2ec: stur            x1, [fp, #-0x10]
    //     0x116d2f0: stur            x2, [fp, #-0x18]
    // 0x116d2f4: CheckStackOverflow
    //     0x116d2f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d2f8: cmp             SP, x16
    //     0x116d2fc: b.ls            #0x116d3a4
    // 0x116d300: LoadField: r5 = r4->field_2b
    //     0x116d300: ldur            w5, [x4, #0x2b]
    // 0x116d304: DecompressPointer r5
    //     0x116d304: add             x5, x5, HEAP, lsl #32
    // 0x116d308: stur            x5, [fp, #-8]
    // 0x116d30c: r0 = BoxInt64Instr(r3)
    //     0x116d30c: sbfiz           x0, x3, #1, #0x1f
    //     0x116d310: cmp             x3, x0, asr #1
    //     0x116d314: b.eq            #0x116d320
    //     0x116d318: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d31c: stur            x3, [x0, #7]
    // 0x116d320: mov             x1, x5
    // 0x116d324: mov             x2, x0
    // 0x116d328: r0 = _getValueOrData()
    //     0x116d328: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x116d32c: mov             x1, x0
    // 0x116d330: ldur            x0, [fp, #-8]
    // 0x116d334: LoadField: r2 = r0->field_f
    //     0x116d334: ldur            w2, [x0, #0xf]
    // 0x116d338: DecompressPointer r2
    //     0x116d338: add             x2, x2, HEAP, lsl #32
    // 0x116d33c: cmp             w2, w1
    // 0x116d340: b.ne            #0x116d34c
    // 0x116d344: r0 = Null
    //     0x116d344: mov             x0, NULL
    // 0x116d348: b               #0x116d350
    // 0x116d34c: mov             x0, x1
    // 0x116d350: cmp             w0, NULL
    // 0x116d354: b.ne            #0x116d380
    // 0x116d358: ldur            x1, [fp, #-0x10]
    // 0x116d35c: LoadField: r2 = r1->field_27
    //     0x116d35c: ldur            w2, [x1, #0x27]
    // 0x116d360: DecompressPointer r2
    //     0x116d360: add             x2, x2, HEAP, lsl #32
    // 0x116d364: cmp             w2, NULL
    // 0x116d368: b.eq            #0x116d384
    // 0x116d36c: ldur            x3, [fp, #-0x18]
    // 0x116d370: LoadField: r4 = r2->field_7
    //     0x116d370: ldur            x4, [x2, #7]
    // 0x116d374: cmp             x4, x3
    // 0x116d378: b.ne            #0x116d384
    // 0x116d37c: b               #0x116d388
    // 0x116d380: ldur            x1, [fp, #-0x10]
    // 0x116d384: mov             x2, x0
    // 0x116d388: cmp             w2, NULL
    // 0x116d38c: b.eq            #0x116d394
    // 0x116d390: r0 = _reject()
    //     0x116d390: bl              #0xba92f8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0x116d394: r0 = Null
    //     0x116d394: mov             x0, NULL
    // 0x116d398: LeaveFrame
    //     0x116d398: mov             SP, fp
    //     0x116d39c: ldp             fp, lr, [SP], #0x10
    // 0x116d3a0: ret
    //     0x116d3a0: ret             
    // 0x116d3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d3a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d3a8: b               #0x116d300
  }
}
