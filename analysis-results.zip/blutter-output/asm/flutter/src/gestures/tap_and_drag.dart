// lib: , url: package:flutter/src/gestures/tap_and_drag.dart

// class id: 1048835, size: 0x8
class :: {

  static _ _getGlobalDistance(/* No info */) {
    // ** addr: 0xb9c9d8, size: 0x84
    // 0xb9c9d8: EnterFrame
    //     0xb9c9d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c9dc: mov             fp, SP
    // 0xb9c9e0: AllocStack(0x8)
    //     0xb9c9e0: sub             SP, SP, #8
    // 0xb9c9e4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xb9c9e4: stur            x2, [fp, #-8]
    // 0xb9c9e8: CheckStackOverflow
    //     0xb9c9e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9c9ec: cmp             SP, x16
    //     0xb9c9f0: b.ls            #0xb9ca50
    // 0xb9c9f4: r0 = LoadClassIdInstr(r1)
    //     0xb9c9f4: ldur            x0, [x1, #-1]
    //     0xb9c9f8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c9fc: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb9c9fc: mov             x17, #0x3f27
    //     0xb9ca00: movk            x17, #1, lsl #16
    //     0xb9ca04: add             lr, x0, x17
    //     0xb9ca08: ldr             lr, [x21, lr, lsl #3]
    //     0xb9ca0c: blr             lr
    // 0xb9ca10: mov             x1, x0
    // 0xb9ca14: ldur            x0, [fp, #-8]
    // 0xb9ca18: cmp             w0, NULL
    // 0xb9ca1c: b.eq            #0xb9ca58
    // 0xb9ca20: LoadField: r2 = r0->field_b
    //     0xb9ca20: ldur            w2, [x0, #0xb]
    // 0xb9ca24: DecompressPointer r2
    //     0xb9ca24: add             x2, x2, HEAP, lsl #32
    // 0xb9ca28: r0 = -()
    //     0xb9ca28: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb9ca2c: LoadField: d1 = r0->field_7
    //     0xb9ca2c: ldur            d1, [x0, #7]
    // 0xb9ca30: fmul            d2, d1, d1
    // 0xb9ca34: LoadField: d1 = r0->field_f
    //     0xb9ca34: ldur            d1, [x0, #0xf]
    // 0xb9ca38: fmul            d3, d1, d1
    // 0xb9ca3c: fadd            d1, d2, d3
    // 0xb9ca40: fsqrt           d0, d1
    // 0xb9ca44: LeaveFrame
    //     0xb9ca44: mov             SP, fp
    //     0xb9ca48: ldp             fp, lr, [SP], #0x10
    // 0xb9ca4c: ret
    //     0xb9ca4c: ret             
    // 0xb9ca50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9ca50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9ca54: b               #0xb9c9f4
    // 0xb9ca58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9ca58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4450, size: 0xac, field offset: 0x4c
abstract class BaseTapAndDragGestureRecognizer extends _MixinApplication499&OneSequenceGestureRecognizer&_TapStatusTrackerMixin {

  late OffsetPair _initialPosition; // offset: 0x94
  late double _globalDistanceMoved; // offset: 0x9c
  late double _globalDistanceMovedAllAxes; // offset: 0xa0
  late OffsetPair _currentPosition; // offset: 0x98

  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0xb94e30, size: 0x180
    // 0xb94e30: EnterFrame
    //     0xb94e30: stp             fp, lr, [SP, #-0x10]!
    //     0xb94e34: mov             fp, SP
    // 0xb94e38: AllocStack(0x10)
    //     0xb94e38: sub             SP, SP, #0x10
    // 0xb94e3c: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb94e3c: mov             x0, x1
    //     0xb94e40: mov             x3, x2
    //     0xb94e44: stur            x1, [fp, #-8]
    //     0xb94e48: stur            x2, [fp, #-0x10]
    // 0xb94e4c: CheckStackOverflow
    //     0xb94e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb94e50: cmp             SP, x16
    //     0xb94e54: b.ls            #0xb94fa4
    // 0xb94e58: LoadField: r1 = r0->field_8b
    //     0xb94e58: ldur            w1, [x0, #0x8b]
    // 0xb94e5c: DecompressPointer r1
    //     0xb94e5c: add             x1, x1, HEAP, lsl #32
    // 0xb94e60: LoadField: r2 = r1->field_7
    //     0xb94e60: ldur            x2, [x1, #7]
    // 0xb94e64: cmp             x2, #1
    // 0xb94e68: b.gt            #0xb94f64
    // 0xb94e6c: cmp             x2, #0
    // 0xb94e70: b.gt            #0xb94e90
    // 0xb94e74: mov             x1, x0
    // 0xb94e78: r0 = _checkCancel()
    //     0xb94e78: bl              #0xb98ff8  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkCancel
    // 0xb94e7c: ldur            x1, [fp, #-8]
    // 0xb94e80: r2 = Instance_GestureDisposition
    //     0xb94e80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb94e84: ldr             x2, [x2, #0x610]
    // 0xb94e88: r0 = resolve()
    //     0xb94e88: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb94e8c: b               #0xb94f6c
    // 0xb94e90: mov             x4, x0
    // 0xb94e94: LoadField: r0 = r4->field_73
    //     0xb94e94: ldur            w0, [x4, #0x73]
    // 0xb94e98: DecompressPointer r0
    //     0xb94e98: add             x0, x0, HEAP, lsl #32
    // 0xb94e9c: tbnz            w0, #4, #0xb94f44
    // 0xb94ea0: LoadField: r0 = r4->field_7b
    //     0xb94ea0: ldur            w0, [x4, #0x7b]
    // 0xb94ea4: DecompressPointer r0
    //     0xb94ea4: add             x0, x0, HEAP, lsl #32
    // 0xb94ea8: tbnz            w0, #4, #0xb94f28
    // 0xb94eac: LoadField: r0 = r4->field_23
    //     0xb94eac: ldur            w0, [x4, #0x23]
    // 0xb94eb0: DecompressPointer r0
    //     0xb94eb0: add             x0, x0, HEAP, lsl #32
    // 0xb94eb4: cmp             w0, NULL
    // 0xb94eb8: b.eq            #0xb94f6c
    // 0xb94ebc: LoadField: r2 = r4->field_a7
    //     0xb94ebc: ldur            w2, [x4, #0xa7]
    // 0xb94ec0: DecompressPointer r2
    //     0xb94ec0: add             x2, x2, HEAP, lsl #32
    // 0xb94ec4: r0 = BoxInt64Instr(r3)
    //     0xb94ec4: sbfiz           x0, x3, #1, #0x1f
    //     0xb94ec8: cmp             x3, x0, asr #1
    //     0xb94ecc: b.eq            #0xb94ed8
    //     0xb94ed0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb94ed4: stur            x3, [x0, #7]
    // 0xb94ed8: mov             x1, x2
    // 0xb94edc: mov             x2, x0
    // 0xb94ee0: r0 = remove()
    //     0xb94ee0: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xb94ee4: tbz             w0, #4, #0xb94ef4
    // 0xb94ee8: ldur            x1, [fp, #-8]
    // 0xb94eec: ldur            x2, [fp, #-0x10]
    // 0xb94ef0: r0 = resolvePointer()
    //     0xb94ef0: bl              #0xb98f4c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0xb94ef4: ldur            x0, [fp, #-8]
    // 0xb94ef8: r1 = Instance__DragState
    //     0xb94ef8: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0xb94efc: ldr             x1, [x1, #0xb28]
    // 0xb94f00: StoreField: r0->field_8b = r1
    //     0xb94f00: stur            w1, [x0, #0x8b]
    // 0xb94f04: LoadField: r2 = r0->field_23
    //     0xb94f04: ldur            w2, [x0, #0x23]
    // 0xb94f08: DecompressPointer r2
    //     0xb94f08: add             x2, x2, HEAP, lsl #32
    // 0xb94f0c: cmp             w2, NULL
    // 0xb94f10: b.eq            #0xb94fac
    // 0xb94f14: mov             x1, x0
    // 0xb94f18: r0 = _acceptDrag()
    //     0xb94f18: bl              #0xb95b1c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_acceptDrag
    // 0xb94f1c: ldur            x1, [fp, #-8]
    // 0xb94f20: r0 = _checkDragEnd()
    //     0xb94f20: bl              #0xb953f8  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragEnd
    // 0xb94f24: b               #0xb94f6c
    // 0xb94f28: ldur            x1, [fp, #-8]
    // 0xb94f2c: r0 = _checkCancel()
    //     0xb94f2c: bl              #0xb98ff8  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkCancel
    // 0xb94f30: ldur            x1, [fp, #-8]
    // 0xb94f34: r2 = Instance_GestureDisposition
    //     0xb94f34: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb94f38: ldr             x2, [x2, #0x610]
    // 0xb94f3c: r0 = resolve()
    //     0xb94f3c: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb94f40: b               #0xb94f6c
    // 0xb94f44: mov             x0, x4
    // 0xb94f48: LoadField: r2 = r0->field_27
    //     0xb94f48: ldur            w2, [x0, #0x27]
    // 0xb94f4c: DecompressPointer r2
    //     0xb94f4c: add             x2, x2, HEAP, lsl #32
    // 0xb94f50: cmp             w2, NULL
    // 0xb94f54: b.eq            #0xb94f6c
    // 0xb94f58: mov             x1, x0
    // 0xb94f5c: r0 = _checkTapUp()
    //     0xb94f5c: bl              #0xb95004  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapUp
    // 0xb94f60: b               #0xb94f6c
    // 0xb94f64: ldur            x1, [fp, #-8]
    // 0xb94f68: r0 = _checkDragEnd()
    //     0xb94f68: bl              #0xb953f8  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragEnd
    // 0xb94f6c: ldur            x0, [fp, #-8]
    // 0xb94f70: mov             x1, x0
    // 0xb94f74: r0 = _stopDeadlineTimer()
    //     0xb94f74: bl              #0xb94fb0  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_stopDeadlineTimer
    // 0xb94f78: ldur            x1, [fp, #-8]
    // 0xb94f7c: StoreField: r1->field_8f = rNULL
    //     0xb94f7c: stur            NULL, [x1, #0x8f]
    // 0xb94f80: r2 = Instance__DragState
    //     0xb94f80: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3e58] Obj!_DragState@12c5ae1
    //     0xb94f84: ldr             x2, [x2, #0xe58]
    // 0xb94f88: StoreField: r1->field_8b = r2
    //     0xb94f88: stur            w2, [x1, #0x8b]
    // 0xb94f8c: r2 = false
    //     0xb94f8c: add             x2, NULL, #0x30  ; false
    // 0xb94f90: StoreField: r1->field_73 = r2
    //     0xb94f90: stur            w2, [x1, #0x73]
    // 0xb94f94: r0 = Null
    //     0xb94f94: mov             x0, NULL
    // 0xb94f98: LeaveFrame
    //     0xb94f98: mov             SP, fp
    //     0xb94f9c: ldp             fp, lr, [SP], #0x10
    // 0xb94fa0: ret
    //     0xb94fa0: ret             
    // 0xb94fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb94fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb94fa8: b               #0xb94e58
    // 0xb94fac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb94fac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _stopDeadlineTimer(/* No info */) {
    // ** addr: 0xb94fb0, size: 0x54
    // 0xb94fb0: EnterFrame
    //     0xb94fb0: stp             fp, lr, [SP, #-0x10]!
    //     0xb94fb4: mov             fp, SP
    // 0xb94fb8: AllocStack(0x8)
    //     0xb94fb8: sub             SP, SP, #8
    // 0xb94fbc: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb94fbc: mov             x0, x1
    //     0xb94fc0: stur            x1, [fp, #-8]
    // 0xb94fc4: CheckStackOverflow
    //     0xb94fc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb94fc8: cmp             SP, x16
    //     0xb94fcc: b.ls            #0xb94ffc
    // 0xb94fd0: LoadField: r1 = r0->field_83
    //     0xb94fd0: ldur            w1, [x0, #0x83]
    // 0xb94fd4: DecompressPointer r1
    //     0xb94fd4: add             x1, x1, HEAP, lsl #32
    // 0xb94fd8: cmp             w1, NULL
    // 0xb94fdc: b.eq            #0xb94fec
    // 0xb94fe0: r0 = cancel()
    //     0xb94fe0: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xb94fe4: ldur            x1, [fp, #-8]
    // 0xb94fe8: StoreField: r1->field_83 = rNULL
    //     0xb94fe8: stur            NULL, [x1, #0x83]
    // 0xb94fec: r0 = Null
    //     0xb94fec: mov             x0, NULL
    // 0xb94ff0: LeaveFrame
    //     0xb94ff0: mov             SP, fp
    //     0xb94ff4: ldp             fp, lr, [SP], #0x10
    // 0xb94ff8: ret
    //     0xb94ff8: ret             
    // 0xb94ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb94ffc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb95000: b               #0xb94fd0
  }
  _ _checkTapUp(/* No info */) {
    // ** addr: 0xb95004, size: 0x1f0
    // 0xb95004: EnterFrame
    //     0xb95004: stp             fp, lr, [SP, #-0x10]!
    //     0xb95008: mov             fp, SP
    // 0xb9500c: AllocStack(0x40)
    //     0xb9500c: sub             SP, SP, #0x40
    // 0xb95010: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb95010: mov             x0, x1
    //     0xb95014: stur            x1, [fp, #-8]
    //     0xb95018: mov             x1, x2
    //     0xb9501c: stur            x2, [fp, #-0x10]
    // 0xb95020: CheckStackOverflow
    //     0xb95020: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95024: cmp             SP, x16
    //     0xb95028: b.ls            #0xb951ec
    // 0xb9502c: r1 = 2
    //     0xb9502c: mov             x1, #2
    // 0xb95030: r0 = AllocateContext()
    //     0xb95030: bl              #0x13de838  ; AllocateContextStub
    // 0xb95034: mov             x3, x0
    // 0xb95038: ldur            x2, [fp, #-8]
    // 0xb9503c: stur            x3, [fp, #-0x18]
    // 0xb95040: StoreField: r3->field_f = r2
    //     0xb95040: stur            w2, [x3, #0xf]
    // 0xb95044: LoadField: r0 = r2->field_7b
    //     0xb95044: ldur            w0, [x2, #0x7b]
    // 0xb95048: DecompressPointer r0
    //     0xb95048: add             x0, x0, HEAP, lsl #32
    // 0xb9504c: tbz             w0, #4, #0xb95060
    // 0xb95050: r0 = Null
    //     0xb95050: mov             x0, NULL
    // 0xb95054: LeaveFrame
    //     0xb95054: mov             SP, fp
    //     0xb95058: ldp             fp, lr, [SP], #0x10
    // 0xb9505c: ret
    //     0xb9505c: ret             
    // 0xb95060: ldur            x4, [fp, #-0x10]
    // 0xb95064: r0 = LoadClassIdInstr(r4)
    //     0xb95064: ldur            x0, [x4, #-1]
    //     0xb95068: ubfx            x0, x0, #0xc, #0x14
    // 0xb9506c: mov             x1, x4
    // 0xb95070: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb95070: mov             x17, #0x5e74
    //     0xb95074: movk            x17, #1, lsl #16
    //     0xb95078: add             lr, x0, x17
    //     0xb9507c: ldr             lr, [x21, lr, lsl #3]
    //     0xb95080: blr             lr
    // 0xb95084: ldur            x2, [fp, #-0x10]
    // 0xb95088: r0 = LoadClassIdInstr(r2)
    //     0xb95088: ldur            x0, [x2, #-1]
    //     0xb9508c: ubfx            x0, x0, #0xc, #0x14
    // 0xb95090: mov             x1, x2
    // 0xb95094: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb95094: mov             x17, #0x3f27
    //     0xb95098: movk            x17, #1, lsl #16
    //     0xb9509c: add             lr, x0, x17
    //     0xb950a0: ldr             lr, [x21, lr, lsl #3]
    //     0xb950a4: blr             lr
    // 0xb950a8: mov             x3, x0
    // 0xb950ac: ldur            x2, [fp, #-0x10]
    // 0xb950b0: stur            x3, [fp, #-0x20]
    // 0xb950b4: r0 = LoadClassIdInstr(r2)
    //     0xb950b4: ldur            x0, [x2, #-1]
    //     0xb950b8: ubfx            x0, x0, #0xc, #0x14
    // 0xb950bc: mov             x1, x2
    // 0xb950c0: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb950c0: mov             x17, #0x54ea
    //     0xb950c4: movk            x17, #1, lsl #16
    //     0xb950c8: add             lr, x0, x17
    //     0xb950cc: ldr             lr, [x21, lr, lsl #3]
    //     0xb950d0: blr             lr
    // 0xb950d4: ldur            x1, [fp, #-8]
    // 0xb950d8: LoadField: r0 = r1->field_2b
    //     0xb950d8: ldur            x0, [x1, #0x2b]
    // 0xb950dc: stur            x0, [fp, #-0x28]
    // 0xb950e0: r0 = TapDragUpDetails()
    //     0xb950e0: bl              #0xb9520c  ; AllocateTapDragUpDetailsStub -> TapDragUpDetails (size=0x14)
    // 0xb950e4: mov             x1, x0
    // 0xb950e8: ldur            x0, [fp, #-0x20]
    // 0xb950ec: StoreField: r1->field_7 = r0
    //     0xb950ec: stur            w0, [x1, #7]
    // 0xb950f0: ldur            x0, [fp, #-0x28]
    // 0xb950f4: StoreField: r1->field_b = r0
    //     0xb950f4: stur            x0, [x1, #0xb]
    // 0xb950f8: mov             x0, x1
    // 0xb950fc: ldur            x2, [fp, #-0x18]
    // 0xb95100: StoreField: r2->field_13 = r0
    //     0xb95100: stur            w0, [x2, #0x13]
    //     0xb95104: ldurb           w16, [x2, #-1]
    //     0xb95108: ldurb           w17, [x0, #-1]
    //     0xb9510c: and             x16, x17, x16, lsr #2
    //     0xb95110: tst             x16, HEAP, lsr #32
    //     0xb95114: b.eq            #0xb9511c
    //     0xb95118: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9511c: ldur            x0, [fp, #-8]
    // 0xb95120: LoadField: r1 = r0->field_5f
    //     0xb95120: ldur            w1, [x0, #0x5f]
    // 0xb95124: DecompressPointer r1
    //     0xb95124: add             x1, x1, HEAP, lsl #32
    // 0xb95128: cmp             w1, NULL
    // 0xb9512c: b.eq            #0xb95154
    // 0xb95130: r1 = Function '<anonymous closure>':.
    //     0xb95130: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb78] AnonymousClosure: (0xb95218), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapUp (0xb95004)
    //     0xb95134: ldr             x1, [x1, #0xb78]
    // 0xb95138: r0 = AllocateClosure()
    //     0xb95138: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9513c: r16 = <void?>
    //     0xb9513c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb95140: ldur            lr, [fp, #-8]
    // 0xb95144: stp             lr, x16, [SP, #8]
    // 0xb95148: str             x0, [SP]
    // 0xb9514c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9514c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb95150: r0 = invokeCallback()
    //     0xb95150: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb95154: ldur            x0, [fp, #-8]
    // 0xb95158: ldur            x2, [fp, #-0x10]
    // 0xb9515c: mov             x1, x0
    // 0xb95160: r0 = _resetTaps()
    //     0xb95160: bl              #0xb951f4  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_resetTaps
    // 0xb95164: ldur            x2, [fp, #-8]
    // 0xb95168: LoadField: r3 = r2->field_a7
    //     0xb95168: ldur            w3, [x2, #0xa7]
    // 0xb9516c: DecompressPointer r3
    //     0xb9516c: add             x3, x3, HEAP, lsl #32
    // 0xb95170: ldur            x4, [fp, #-0x10]
    // 0xb95174: stur            x3, [fp, #-0x18]
    // 0xb95178: r0 = LoadClassIdInstr(r4)
    //     0xb95178: ldur            x0, [x4, #-1]
    //     0xb9517c: ubfx            x0, x0, #0xc, #0x14
    // 0xb95180: mov             x1, x4
    // 0xb95184: r0 = GDT[cid_x0 + -0x1]()
    //     0xb95184: sub             lr, x0, #1
    //     0xb95188: ldr             lr, [x21, lr, lsl #3]
    //     0xb9518c: blr             lr
    // 0xb95190: mov             x2, x0
    // 0xb95194: r0 = BoxInt64Instr(r2)
    //     0xb95194: sbfiz           x0, x2, #1, #0x1f
    //     0xb95198: cmp             x2, x0, asr #1
    //     0xb9519c: b.eq            #0xb951a8
    //     0xb951a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb951a4: stur            x2, [x0, #7]
    // 0xb951a8: ldur            x1, [fp, #-0x18]
    // 0xb951ac: mov             x2, x0
    // 0xb951b0: r0 = remove()
    //     0xb951b0: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xb951b4: tbz             w0, #4, #0xb951dc
    // 0xb951b8: ldur            x1, [fp, #-0x10]
    // 0xb951bc: r0 = LoadClassIdInstr(r1)
    //     0xb951bc: ldur            x0, [x1, #-1]
    //     0xb951c0: ubfx            x0, x0, #0xc, #0x14
    // 0xb951c4: r0 = GDT[cid_x0 + -0x1]()
    //     0xb951c4: sub             lr, x0, #1
    //     0xb951c8: ldr             lr, [x21, lr, lsl #3]
    //     0xb951cc: blr             lr
    // 0xb951d0: ldur            x1, [fp, #-8]
    // 0xb951d4: mov             x2, x0
    // 0xb951d8: r0 = resolvePointer()
    //     0xb951d8: bl              #0xb98f4c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0xb951dc: r0 = Null
    //     0xb951dc: mov             x0, NULL
    // 0xb951e0: LeaveFrame
    //     0xb951e0: mov             SP, fp
    //     0xb951e4: ldp             fp, lr, [SP], #0x10
    // 0xb951e8: ret
    //     0xb951e8: ret             
    // 0xb951ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb951ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb951f0: b               #0xb9502c
  }
  _ _resetTaps(/* No info */) {
    // ** addr: 0xb951f4, size: 0x18
    // 0xb951f4: r2 = false
    //     0xb951f4: add             x2, NULL, #0x30  ; false
    // 0xb951f8: StoreField: r1->field_77 = r2
    //     0xb951f8: stur            w2, [x1, #0x77]
    // 0xb951fc: StoreField: r1->field_7b = r2
    //     0xb951fc: stur            w2, [x1, #0x7b]
    // 0xb95200: StoreField: r1->field_7f = rNULL
    //     0xb95200: stur            NULL, [x1, #0x7f]
    // 0xb95204: r0 = Null
    //     0xb95204: mov             x0, NULL
    // 0xb95208: ret
    //     0xb95208: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb95218, size: 0x6c
    // 0xb95218: EnterFrame
    //     0xb95218: stp             fp, lr, [SP, #-0x10]!
    //     0xb9521c: mov             fp, SP
    // 0xb95220: ldr             x0, [fp, #0x10]
    // 0xb95224: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb95224: ldur            w1, [x0, #0x17]
    // 0xb95228: DecompressPointer r1
    //     0xb95228: add             x1, x1, HEAP, lsl #32
    // 0xb9522c: CheckStackOverflow
    //     0xb9522c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95230: cmp             SP, x16
    //     0xb95234: b.ls            #0xb95278
    // 0xb95238: LoadField: r0 = r1->field_f
    //     0xb95238: ldur            w0, [x1, #0xf]
    // 0xb9523c: DecompressPointer r0
    //     0xb9523c: add             x0, x0, HEAP, lsl #32
    // 0xb95240: LoadField: r2 = r0->field_5f
    //     0xb95240: ldur            w2, [x0, #0x5f]
    // 0xb95244: DecompressPointer r2
    //     0xb95244: add             x2, x2, HEAP, lsl #32
    // 0xb95248: cmp             w2, NULL
    // 0xb9524c: b.eq            #0xb95280
    // 0xb95250: LoadField: r0 = r1->field_13
    //     0xb95250: ldur            w0, [x1, #0x13]
    // 0xb95254: DecompressPointer r0
    //     0xb95254: add             x0, x0, HEAP, lsl #32
    // 0xb95258: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb95258: ldur            w1, [x2, #0x17]
    // 0xb9525c: DecompressPointer r1
    //     0xb9525c: add             x1, x1, HEAP, lsl #32
    // 0xb95260: mov             x2, x0
    // 0xb95264: r0 = _handleTapUp()
    //     0xb95264: bl              #0xb952e4  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_handleTapUp
    // 0xb95268: r0 = Null
    //     0xb95268: mov             x0, NULL
    // 0xb9526c: LeaveFrame
    //     0xb9526c: mov             SP, fp
    //     0xb95270: ldp             fp, lr, [SP], #0x10
    // 0xb95274: ret
    //     0xb95274: ret             
    // 0xb95278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb95278: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9527c: b               #0xb95238
    // 0xb95280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb95280: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDragEnd(/* No info */) {
    // ** addr: 0xb953f8, size: 0xc8
    // 0xb953f8: EnterFrame
    //     0xb953f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb953fc: mov             fp, SP
    // 0xb95400: AllocStack(0x30)
    //     0xb95400: sub             SP, SP, #0x30
    // 0xb95404: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xb95404: stur            x1, [fp, #-8]
    // 0xb95408: CheckStackOverflow
    //     0xb95408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9540c: cmp             SP, x16
    //     0xb95410: b.ls            #0xb954ac
    // 0xb95414: r1 = 2
    //     0xb95414: mov             x1, #2
    // 0xb95418: r0 = AllocateContext()
    //     0xb95418: bl              #0x13de838  ; AllocateContextStub
    // 0xb9541c: ldur            x1, [fp, #-8]
    // 0xb95420: stur            x0, [fp, #-0x18]
    // 0xb95424: StoreField: r0->field_f = r1
    //     0xb95424: stur            w1, [x0, #0xf]
    // 0xb95428: LoadField: r2 = r1->field_97
    //     0xb95428: ldur            w2, [x1, #0x97]
    // 0xb9542c: DecompressPointer r2
    //     0xb9542c: add             x2, x2, HEAP, lsl #32
    // 0xb95430: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb95434: cmp             w2, w16
    // 0xb95438: b.eq            #0xb954b4
    // 0xb9543c: LoadField: r2 = r1->field_2b
    //     0xb9543c: ldur            x2, [x1, #0x2b]
    // 0xb95440: stur            x2, [fp, #-0x10]
    // 0xb95444: r0 = TapDragEndDetails()
    //     0xb95444: bl              #0xb954c0  ; AllocateTapDragEndDetailsStub -> TapDragEndDetails (size=0x10)
    // 0xb95448: mov             x1, x0
    // 0xb9544c: ldur            x0, [fp, #-0x10]
    // 0xb95450: StoreField: r1->field_7 = r0
    //     0xb95450: stur            x0, [x1, #7]
    // 0xb95454: ldur            x2, [fp, #-0x18]
    // 0xb95458: StoreField: r2->field_13 = r1
    //     0xb95458: stur            w1, [x2, #0x13]
    // 0xb9545c: ldur            x0, [fp, #-8]
    // 0xb95460: LoadField: r1 = r0->field_6b
    //     0xb95460: ldur            w1, [x0, #0x6b]
    // 0xb95464: DecompressPointer r1
    //     0xb95464: add             x1, x1, HEAP, lsl #32
    // 0xb95468: cmp             w1, NULL
    // 0xb9546c: b.eq            #0xb95494
    // 0xb95470: r1 = Function '<anonymous closure>':.
    //     0xb95470: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb80] AnonymousClosure: (0xb956f8), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragEnd (0xb953f8)
    //     0xb95474: ldr             x1, [x1, #0xb80]
    // 0xb95478: r0 = AllocateClosure()
    //     0xb95478: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9547c: r16 = <void?>
    //     0xb9547c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb95480: ldur            lr, [fp, #-8]
    // 0xb95484: stp             lr, x16, [SP, #8]
    // 0xb95488: str             x0, [SP]
    // 0xb9548c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9548c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb95490: r0 = invokeCallback()
    //     0xb95490: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb95494: ldur            x1, [fp, #-8]
    // 0xb95498: r0 = _resetTaps()
    //     0xb95498: bl              #0xb951f4  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_resetTaps
    // 0xb9549c: r0 = Null
    //     0xb9549c: mov             x0, NULL
    // 0xb954a0: LeaveFrame
    //     0xb954a0: mov             SP, fp
    //     0xb954a4: ldp             fp, lr, [SP], #0x10
    // 0xb954a8: ret
    //     0xb954a8: ret             
    // 0xb954ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb954ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb954b0: b               #0xb95414
    // 0xb954b4: r9 = _currentPosition
    //     0xb954b4: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb88] Field <BaseTapAndDragGestureRecognizer._currentPosition@307288344>: late (offset: 0x98)
    //     0xb954b8: ldr             x9, [x9, #0xb88]
    // 0xb954bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb954bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb956f8, size: 0x6c
    // 0xb956f8: EnterFrame
    //     0xb956f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb956fc: mov             fp, SP
    // 0xb95700: ldr             x0, [fp, #0x10]
    // 0xb95704: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb95704: ldur            w1, [x0, #0x17]
    // 0xb95708: DecompressPointer r1
    //     0xb95708: add             x1, x1, HEAP, lsl #32
    // 0xb9570c: CheckStackOverflow
    //     0xb9570c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95710: cmp             SP, x16
    //     0xb95714: b.ls            #0xb95758
    // 0xb95718: LoadField: r0 = r1->field_f
    //     0xb95718: ldur            w0, [x1, #0xf]
    // 0xb9571c: DecompressPointer r0
    //     0xb9571c: add             x0, x0, HEAP, lsl #32
    // 0xb95720: LoadField: r2 = r0->field_6b
    //     0xb95720: ldur            w2, [x0, #0x6b]
    // 0xb95724: DecompressPointer r2
    //     0xb95724: add             x2, x2, HEAP, lsl #32
    // 0xb95728: cmp             w2, NULL
    // 0xb9572c: b.eq            #0xb95760
    // 0xb95730: LoadField: r0 = r1->field_13
    //     0xb95730: ldur            w0, [x1, #0x13]
    // 0xb95734: DecompressPointer r0
    //     0xb95734: add             x0, x0, HEAP, lsl #32
    // 0xb95738: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb95738: ldur            w1, [x2, #0x17]
    // 0xb9573c: DecompressPointer r1
    //     0xb9573c: add             x1, x1, HEAP, lsl #32
    // 0xb95740: mov             x2, x0
    // 0xb95744: r0 = _handleDragEnd()
    //     0xb95744: bl              #0xb957a0  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_handleDragEnd
    // 0xb95748: r0 = Null
    //     0xb95748: mov             x0, NULL
    // 0xb9574c: LeaveFrame
    //     0xb9574c: mov             SP, fp
    //     0xb95750: ldp             fp, lr, [SP], #0x10
    // 0xb95754: ret
    //     0xb95754: ret             
    // 0xb95758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb95758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9575c: b               #0xb95718
    // 0xb95760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb95760: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _acceptDrag(/* No info */) {
    // ** addr: 0xb95b1c, size: 0x2e0
    // 0xb95b1c: EnterFrame
    //     0xb95b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb95b20: mov             fp, SP
    // 0xb95b24: AllocStack(0x38)
    //     0xb95b24: sub             SP, SP, #0x38
    // 0xb95b28: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb95b28: mov             x3, x1
    //     0xb95b2c: stur            x1, [fp, #-0x10]
    //     0xb95b30: stur            x2, [fp, #-0x18]
    // 0xb95b34: CheckStackOverflow
    //     0xb95b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95b38: cmp             SP, x16
    //     0xb95b3c: b.ls            #0xb95dd8
    // 0xb95b40: LoadField: r0 = r3->field_7b
    //     0xb95b40: ldur            w0, [x3, #0x7b]
    // 0xb95b44: DecompressPointer r0
    //     0xb95b44: add             x0, x0, HEAP, lsl #32
    // 0xb95b48: tbz             w0, #4, #0xb95b5c
    // 0xb95b4c: r0 = Null
    //     0xb95b4c: mov             x0, NULL
    // 0xb95b50: LeaveFrame
    //     0xb95b50: mov             SP, fp
    //     0xb95b54: ldp             fp, lr, [SP], #0x10
    // 0xb95b58: ret
    //     0xb95b58: ret             
    // 0xb95b5c: LoadField: r0 = r3->field_4b
    //     0xb95b5c: ldur            w0, [x3, #0x4b]
    // 0xb95b60: DecompressPointer r0
    //     0xb95b60: add             x0, x0, HEAP, lsl #32
    // 0xb95b64: r16 = Instance_DragStartBehavior
    //     0xb95b64: ldr             x16, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xb95b68: cmp             w0, w16
    // 0xb95b6c: b.ne            #0xb95c40
    // 0xb95b70: LoadField: r4 = r3->field_93
    //     0xb95b70: ldur            w4, [x3, #0x93]
    // 0xb95b74: DecompressPointer r4
    //     0xb95b74: add             x4, x4, HEAP, lsl #32
    // 0xb95b78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb95b7c: cmp             w4, w16
    // 0xb95b80: b.eq            #0xb95de0
    // 0xb95b84: stur            x4, [fp, #-8]
    // 0xb95b88: r0 = LoadClassIdInstr(r2)
    //     0xb95b88: ldur            x0, [x2, #-1]
    //     0xb95b8c: ubfx            x0, x0, #0xc, #0x14
    // 0xb95b90: mov             x1, x2
    // 0xb95b94: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0xb95b94: mov             x17, #0x5a8f
    //     0xb95b98: movk            x17, #1, lsl #16
    //     0xb95b9c: add             lr, x0, x17
    //     0xb95ba0: ldr             lr, [x21, lr, lsl #3]
    //     0xb95ba4: blr             lr
    // 0xb95ba8: mov             x3, x0
    // 0xb95bac: ldur            x2, [fp, #-0x18]
    // 0xb95bb0: stur            x3, [fp, #-0x20]
    // 0xb95bb4: r0 = LoadClassIdInstr(r2)
    //     0xb95bb4: ldur            x0, [x2, #-1]
    //     0xb95bb8: ubfx            x0, x0, #0xc, #0x14
    // 0xb95bbc: mov             x1, x2
    // 0xb95bc0: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb95bc0: mov             x17, #0x545d
    //     0xb95bc4: movk            x17, #1, lsl #16
    //     0xb95bc8: add             lr, x0, x17
    //     0xb95bcc: ldr             lr, [x21, lr, lsl #3]
    //     0xb95bd0: blr             lr
    // 0xb95bd4: stur            x0, [fp, #-0x28]
    // 0xb95bd8: r0 = OffsetPair()
    //     0xb95bd8: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb95bdc: mov             x1, x0
    // 0xb95be0: ldur            x0, [fp, #-0x28]
    // 0xb95be4: StoreField: r1->field_7 = r0
    //     0xb95be4: stur            w0, [x1, #7]
    // 0xb95be8: ldur            x0, [fp, #-0x20]
    // 0xb95bec: StoreField: r1->field_b = r0
    //     0xb95bec: stur            w0, [x1, #0xb]
    // 0xb95bf0: mov             x2, x1
    // 0xb95bf4: ldur            x1, [fp, #-8]
    // 0xb95bf8: r0 = +()
    //     0xb95bf8: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb95bfc: mov             x1, x0
    // 0xb95c00: ldur            x3, [fp, #-0x10]
    // 0xb95c04: StoreField: r3->field_93 = r0
    //     0xb95c04: stur            w0, [x3, #0x93]
    //     0xb95c08: ldurb           w16, [x3, #-1]
    //     0xb95c0c: ldurb           w17, [x0, #-1]
    //     0xb95c10: and             x16, x17, x16, lsr #2
    //     0xb95c14: tst             x16, HEAP, lsr #32
    //     0xb95c18: b.eq            #0xb95c20
    //     0xb95c1c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb95c20: mov             x0, x1
    // 0xb95c24: StoreField: r3->field_97 = r0
    //     0xb95c24: stur            w0, [x3, #0x97]
    //     0xb95c28: ldurb           w16, [x3, #-1]
    //     0xb95c2c: ldurb           w17, [x0, #-1]
    //     0xb95c30: and             x16, x17, x16, lsr #2
    //     0xb95c34: tst             x16, HEAP, lsr #32
    //     0xb95c38: b.eq            #0xb95c40
    //     0xb95c3c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb95c40: ldur            x0, [fp, #-0x18]
    // 0xb95c44: mov             x1, x3
    // 0xb95c48: mov             x2, x0
    // 0xb95c4c: r0 = _checkDragStart()
    //     0xb95c4c: bl              #0xb987ec  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragStart
    // 0xb95c50: ldur            x2, [fp, #-0x18]
    // 0xb95c54: r0 = LoadClassIdInstr(r2)
    //     0xb95c54: ldur            x0, [x2, #-1]
    //     0xb95c58: ubfx            x0, x0, #0xc, #0x14
    // 0xb95c5c: mov             x1, x2
    // 0xb95c60: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb95c60: mov             x17, #0x545d
    //     0xb95c64: movk            x17, #1, lsl #16
    //     0xb95c68: add             lr, x0, x17
    //     0xb95c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xb95c70: blr             lr
    // 0xb95c74: stur            x0, [fp, #-8]
    // 0xb95c78: r16 = Instance_Offset
    //     0xb95c78: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb95c7c: stp             x16, x0, [SP]
    // 0xb95c80: r0 = ==()
    //     0xb95c80: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb95c84: tbz             w0, #4, #0xb95dc8
    // 0xb95c88: ldur            x1, [fp, #-0x10]
    // 0xb95c8c: ldur            x2, [fp, #-0x18]
    // 0xb95c90: r0 = OffsetPair()
    //     0xb95c90: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb95c94: mov             x1, x0
    // 0xb95c98: ldur            x2, [fp, #-0x18]
    // 0xb95c9c: stur            x0, [fp, #-0x20]
    // 0xb95ca0: r0 = OffsetPair.fromEventPosition()
    //     0xb95ca0: bl              #0xb98730  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0xb95ca4: ldur            x0, [fp, #-0x20]
    // 0xb95ca8: ldur            x3, [fp, #-0x10]
    // 0xb95cac: StoreField: r3->field_97 = r0
    //     0xb95cac: stur            w0, [x3, #0x97]
    //     0xb95cb0: ldurb           w16, [x3, #-1]
    //     0xb95cb4: ldurb           w17, [x0, #-1]
    //     0xb95cb8: and             x16, x17, x16, lsr #2
    //     0xb95cbc: tst             x16, HEAP, lsr #32
    //     0xb95cc0: b.eq            #0xb95cc8
    //     0xb95cc4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb95cc8: LoadField: r0 = r3->field_93
    //     0xb95cc8: ldur            w0, [x3, #0x93]
    // 0xb95ccc: DecompressPointer r0
    //     0xb95ccc: add             x0, x0, HEAP, lsl #32
    // 0xb95cd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb95cd4: cmp             w0, w16
    // 0xb95cd8: b.eq            #0xb95dec
    // 0xb95cdc: LoadField: r1 = r0->field_7
    //     0xb95cdc: ldur            w1, [x0, #7]
    // 0xb95ce0: DecompressPointer r1
    //     0xb95ce0: add             x1, x1, HEAP, lsl #32
    // 0xb95ce4: ldur            x2, [fp, #-8]
    // 0xb95ce8: r0 = +()
    //     0xb95ce8: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb95cec: mov             x3, x0
    // 0xb95cf0: ldur            x2, [fp, #-0x18]
    // 0xb95cf4: stur            x3, [fp, #-0x20]
    // 0xb95cf8: r0 = LoadClassIdInstr(r2)
    //     0xb95cf8: ldur            x0, [x2, #-1]
    //     0xb95cfc: ubfx            x0, x0, #0xc, #0x14
    // 0xb95d00: mov             x1, x2
    // 0xb95d04: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb95d04: mov             x17, #0x5fe3
    //     0xb95d08: movk            x17, #1, lsl #16
    //     0xb95d0c: add             lr, x0, x17
    //     0xb95d10: ldr             lr, [x21, lr, lsl #3]
    //     0xb95d14: blr             lr
    // 0xb95d18: cmp             w0, NULL
    // 0xb95d1c: b.ne            #0xb95d28
    // 0xb95d20: r1 = Null
    //     0xb95d20: mov             x1, NULL
    // 0xb95d24: b               #0xb95d60
    // 0xb95d28: ldur            x2, [fp, #-0x18]
    // 0xb95d2c: r0 = LoadClassIdInstr(r2)
    //     0xb95d2c: ldur            x0, [x2, #-1]
    //     0xb95d30: ubfx            x0, x0, #0xc, #0x14
    // 0xb95d34: mov             x1, x2
    // 0xb95d38: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb95d38: mov             x17, #0x5fe3
    //     0xb95d3c: movk            x17, #1, lsl #16
    //     0xb95d40: add             lr, x0, x17
    //     0xb95d44: ldr             lr, [x21, lr, lsl #3]
    //     0xb95d48: blr             lr
    // 0xb95d4c: cmp             w0, NULL
    // 0xb95d50: b.eq            #0xb95df8
    // 0xb95d54: mov             x1, x0
    // 0xb95d58: r0 = tryInvert()
    //     0xb95d58: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xb95d5c: mov             x1, x0
    // 0xb95d60: ldur            x0, [fp, #-0x10]
    // 0xb95d64: ldur            x4, [fp, #-8]
    // 0xb95d68: mov             x2, x4
    // 0xb95d6c: ldur            x3, [fp, #-0x20]
    // 0xb95d70: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb95d70: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb95d74: r0 = transformDeltaViaPositions()
    //     0xb95d74: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xb95d78: stur            x0, [fp, #-0x20]
    // 0xb95d7c: r0 = OffsetPair()
    //     0xb95d7c: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb95d80: mov             x1, x0
    // 0xb95d84: ldur            x0, [fp, #-8]
    // 0xb95d88: StoreField: r1->field_7 = r0
    //     0xb95d88: stur            w0, [x1, #7]
    // 0xb95d8c: ldur            x0, [fp, #-0x20]
    // 0xb95d90: StoreField: r1->field_b = r0
    //     0xb95d90: stur            w0, [x1, #0xb]
    // 0xb95d94: ldur            x0, [fp, #-0x10]
    // 0xb95d98: LoadField: r2 = r0->field_93
    //     0xb95d98: ldur            w2, [x0, #0x93]
    // 0xb95d9c: DecompressPointer r2
    //     0xb95d9c: add             x2, x2, HEAP, lsl #32
    // 0xb95da0: mov             x16, x1
    // 0xb95da4: mov             x1, x2
    // 0xb95da8: mov             x2, x16
    // 0xb95dac: r0 = +()
    //     0xb95dac: bl              #0xb95550  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xb95db0: str             x0, [SP]
    // 0xb95db4: ldur            x1, [fp, #-0x10]
    // 0xb95db8: ldur            x2, [fp, #-0x18]
    // 0xb95dbc: r4 = const [0, 0x3, 0x1, 0x2, corrected, 0x2, null]
    //     0xb95dbc: add             x4, PP, #0xac, lsl #12  ; [pp+0xacb40] List(7) [0, 0x3, 0x1, 0x2, "corrected", 0x2, Null]
    //     0xb95dc0: ldr             x4, [x4, #0xb40]
    // 0xb95dc4: r0 = _checkDragUpdate()
    //     0xb95dc4: bl              #0xb95dfc  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragUpdate
    // 0xb95dc8: r0 = Null
    //     0xb95dc8: mov             x0, NULL
    // 0xb95dcc: LeaveFrame
    //     0xb95dcc: mov             SP, fp
    //     0xb95dd0: ldp             fp, lr, [SP], #0x10
    // 0xb95dd4: ret
    //     0xb95dd4: ret             
    // 0xb95dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb95dd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb95ddc: b               #0xb95b40
    // 0xb95de0: r9 = _initialPosition
    //     0xb95de0: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb38] Field <BaseTapAndDragGestureRecognizer._initialPosition@307288344>: late (offset: 0x94)
    //     0xb95de4: ldr             x9, [x9, #0xb38]
    // 0xb95de8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb95de8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb95dec: r9 = _initialPosition
    //     0xb95dec: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb38] Field <BaseTapAndDragGestureRecognizer._initialPosition@307288344>: late (offset: 0x94)
    //     0xb95df0: ldr             x9, [x9, #0xb38]
    // 0xb95df4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb95df4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb95df8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb95df8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDragUpdate(/* No info */) {
    // ** addr: 0xb95dfc, size: 0x2b0
    // 0xb95dfc: EnterFrame
    //     0xb95dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb95e00: mov             fp, SP
    // 0xb95e04: AllocStack(0x50)
    //     0xb95e04: sub             SP, SP, #0x50
    // 0xb95e08: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */, {dynamic corrected = Null /* r2, fp-0x8 */})
    //     0xb95e08: mov             x0, x1
    //     0xb95e0c: stur            x1, [fp, #-0x10]
    //     0xb95e10: mov             x1, x2
    //     0xb95e14: stur            x2, [fp, #-0x18]
    //     0xb95e18: ldur            w2, [x4, #0x13]
    //     0xb95e1c: ldur            w3, [x4, #0x1f]
    //     0xb95e20: add             x3, x3, HEAP, lsl #32
    //     0xb95e24: add             x16, PP, #0xac, lsl #12  ; [pp+0xacb60] "corrected"
    //     0xb95e28: ldr             x16, [x16, #0xb60]
    //     0xb95e2c: cmp             w3, w16
    //     0xb95e30: b.ne            #0xb95e4c
    //     0xb95e34: ldur            w3, [x4, #0x23]
    //     0xb95e38: add             x3, x3, HEAP, lsl #32
    //     0xb95e3c: sub             w4, w2, w3
    //     0xb95e40: add             x2, fp, w4, sxtw #2
    //     0xb95e44: ldr             x2, [x2, #8]
    //     0xb95e48: b               #0xb95e50
    //     0xb95e4c: mov             x2, NULL
    //     0xb95e50: stur            x2, [fp, #-8]
    // 0xb95e54: CheckStackOverflow
    //     0xb95e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb95e58: cmp             SP, x16
    //     0xb95e5c: b.ls            #0xb96098
    // 0xb95e60: r1 = 2
    //     0xb95e60: mov             x1, #2
    // 0xb95e64: r0 = AllocateContext()
    //     0xb95e64: bl              #0x13de838  ; AllocateContextStub
    // 0xb95e68: mov             x3, x0
    // 0xb95e6c: ldur            x2, [fp, #-0x10]
    // 0xb95e70: stur            x3, [fp, #-0x20]
    // 0xb95e74: StoreField: r3->field_f = r2
    //     0xb95e74: stur            w2, [x3, #0xf]
    // 0xb95e78: ldur            x4, [fp, #-8]
    // 0xb95e7c: cmp             w4, NULL
    // 0xb95e80: b.ne            #0xb95e8c
    // 0xb95e84: r0 = Null
    //     0xb95e84: mov             x0, NULL
    // 0xb95e88: b               #0xb95e94
    // 0xb95e8c: LoadField: r0 = r4->field_b
    //     0xb95e8c: ldur            w0, [x4, #0xb]
    // 0xb95e90: DecompressPointer r0
    //     0xb95e90: add             x0, x0, HEAP, lsl #32
    // 0xb95e94: cmp             w0, NULL
    // 0xb95e98: b.ne            #0xb95ec8
    // 0xb95e9c: ldur            x5, [fp, #-0x18]
    // 0xb95ea0: r0 = LoadClassIdInstr(r5)
    //     0xb95ea0: ldur            x0, [x5, #-1]
    //     0xb95ea4: ubfx            x0, x0, #0xc, #0x14
    // 0xb95ea8: mov             x1, x5
    // 0xb95eac: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb95eac: mov             x17, #0x3f27
    //     0xb95eb0: movk            x17, #1, lsl #16
    //     0xb95eb4: add             lr, x0, x17
    //     0xb95eb8: ldr             lr, [x21, lr, lsl #3]
    //     0xb95ebc: blr             lr
    // 0xb95ec0: mov             x2, x0
    // 0xb95ec4: b               #0xb95ecc
    // 0xb95ec8: mov             x2, x0
    // 0xb95ecc: ldur            x0, [fp, #-8]
    // 0xb95ed0: stur            x2, [fp, #-0x28]
    // 0xb95ed4: cmp             w0, NULL
    // 0xb95ed8: b.ne            #0xb95ee4
    // 0xb95edc: r0 = Null
    //     0xb95edc: mov             x0, NULL
    // 0xb95ee0: b               #0xb95ef0
    // 0xb95ee4: LoadField: r1 = r0->field_7
    //     0xb95ee4: ldur            w1, [x0, #7]
    // 0xb95ee8: DecompressPointer r1
    //     0xb95ee8: add             x1, x1, HEAP, lsl #32
    // 0xb95eec: mov             x0, x1
    // 0xb95ef0: cmp             w0, NULL
    // 0xb95ef4: b.ne            #0xb95f24
    // 0xb95ef8: ldur            x3, [fp, #-0x18]
    // 0xb95efc: r0 = LoadClassIdInstr(r3)
    //     0xb95efc: ldur            x0, [x3, #-1]
    //     0xb95f00: ubfx            x0, x0, #0xc, #0x14
    // 0xb95f04: mov             x1, x3
    // 0xb95f08: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb95f08: mov             x17, #0x54ea
    //     0xb95f0c: movk            x17, #1, lsl #16
    //     0xb95f10: add             lr, x0, x17
    //     0xb95f14: ldr             lr, [x21, lr, lsl #3]
    //     0xb95f18: blr             lr
    // 0xb95f1c: mov             x6, x0
    // 0xb95f20: b               #0xb95f28
    // 0xb95f24: mov             x6, x0
    // 0xb95f28: ldur            x4, [fp, #-0x10]
    // 0xb95f2c: ldur            x3, [fp, #-0x18]
    // 0xb95f30: ldur            x5, [fp, #-0x20]
    // 0xb95f34: ldur            x2, [fp, #-0x28]
    // 0xb95f38: stur            x6, [fp, #-8]
    // 0xb95f3c: r0 = LoadClassIdInstr(r3)
    //     0xb95f3c: ldur            x0, [x3, #-1]
    //     0xb95f40: ubfx            x0, x0, #0xc, #0x14
    // 0xb95f44: mov             x1, x3
    // 0xb95f48: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xb95f48: mov             x17, #0x5eb5
    //     0xb95f4c: movk            x17, #1, lsl #16
    //     0xb95f50: add             lr, x0, x17
    //     0xb95f54: ldr             lr, [x21, lr, lsl #3]
    //     0xb95f58: blr             lr
    // 0xb95f5c: ldur            x2, [fp, #-0x18]
    // 0xb95f60: r0 = LoadClassIdInstr(r2)
    //     0xb95f60: ldur            x0, [x2, #-1]
    //     0xb95f64: ubfx            x0, x0, #0xc, #0x14
    // 0xb95f68: mov             x1, x2
    // 0xb95f6c: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb95f6c: mov             x17, #0x545d
    //     0xb95f70: movk            x17, #1, lsl #16
    //     0xb95f74: add             lr, x0, x17
    //     0xb95f78: ldr             lr, [x21, lr, lsl #3]
    //     0xb95f7c: blr             lr
    // 0xb95f80: ldur            x1, [fp, #-0x18]
    // 0xb95f84: r0 = LoadClassIdInstr(r1)
    //     0xb95f84: ldur            x0, [x1, #-1]
    //     0xb95f88: ubfx            x0, x0, #0xc, #0x14
    // 0xb95f8c: r0 = GDT[cid_x0 + -0x1]()
    //     0xb95f8c: sub             lr, x0, #1
    //     0xb95f90: ldr             lr, [x21, lr, lsl #3]
    //     0xb95f94: blr             lr
    // 0xb95f98: ldur            x1, [fp, #-0x10]
    // 0xb95f9c: mov             x2, x0
    // 0xb95fa0: r0 = getKindForPointer()
    //     0xb95fa0: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xb95fa4: mov             x3, x0
    // 0xb95fa8: ldur            x0, [fp, #-0x10]
    // 0xb95fac: stur            x3, [fp, #-0x18]
    // 0xb95fb0: LoadField: r1 = r0->field_93
    //     0xb95fb0: ldur            w1, [x0, #0x93]
    // 0xb95fb4: DecompressPointer r1
    //     0xb95fb4: add             x1, x1, HEAP, lsl #32
    // 0xb95fb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb95fbc: cmp             w1, w16
    // 0xb95fc0: b.eq            #0xb960a0
    // 0xb95fc4: LoadField: r2 = r1->field_b
    //     0xb95fc4: ldur            w2, [x1, #0xb]
    // 0xb95fc8: DecompressPointer r2
    //     0xb95fc8: add             x2, x2, HEAP, lsl #32
    // 0xb95fcc: ldur            x1, [fp, #-0x28]
    // 0xb95fd0: r0 = -()
    //     0xb95fd0: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb95fd4: mov             x3, x0
    // 0xb95fd8: ldur            x0, [fp, #-0x10]
    // 0xb95fdc: stur            x3, [fp, #-0x30]
    // 0xb95fe0: LoadField: r1 = r0->field_93
    //     0xb95fe0: ldur            w1, [x0, #0x93]
    // 0xb95fe4: DecompressPointer r1
    //     0xb95fe4: add             x1, x1, HEAP, lsl #32
    // 0xb95fe8: LoadField: r2 = r1->field_7
    //     0xb95fe8: ldur            w2, [x1, #7]
    // 0xb95fec: DecompressPointer r2
    //     0xb95fec: add             x2, x2, HEAP, lsl #32
    // 0xb95ff0: ldur            x1, [fp, #-8]
    // 0xb95ff4: r0 = -()
    //     0xb95ff4: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb95ff8: ldur            x0, [fp, #-0x10]
    // 0xb95ffc: LoadField: r1 = r0->field_2b
    //     0xb95ffc: ldur            x1, [x0, #0x2b]
    // 0xb96000: stur            x1, [fp, #-0x38]
    // 0xb96004: r0 = TapDragUpdateDetails()
    //     0xb96004: bl              #0xb960ac  ; AllocateTapDragUpdateDetailsStub -> TapDragUpdateDetails (size=0x1c)
    // 0xb96008: mov             x1, x0
    // 0xb9600c: ldur            x0, [fp, #-0x28]
    // 0xb96010: StoreField: r1->field_7 = r0
    //     0xb96010: stur            w0, [x1, #7]
    // 0xb96014: ldur            x0, [fp, #-0x18]
    // 0xb96018: StoreField: r1->field_b = r0
    //     0xb96018: stur            w0, [x1, #0xb]
    // 0xb9601c: ldur            x0, [fp, #-0x30]
    // 0xb96020: StoreField: r1->field_f = r0
    //     0xb96020: stur            w0, [x1, #0xf]
    // 0xb96024: ldur            x0, [fp, #-0x38]
    // 0xb96028: StoreField: r1->field_13 = r0
    //     0xb96028: stur            x0, [x1, #0x13]
    // 0xb9602c: mov             x0, x1
    // 0xb96030: ldur            x2, [fp, #-0x20]
    // 0xb96034: StoreField: r2->field_13 = r0
    //     0xb96034: stur            w0, [x2, #0x13]
    //     0xb96038: ldurb           w16, [x2, #-1]
    //     0xb9603c: ldurb           w17, [x0, #-1]
    //     0xb96040: and             x16, x17, x16, lsr #2
    //     0xb96044: tst             x16, HEAP, lsr #32
    //     0xb96048: b.eq            #0xb96050
    //     0xb9604c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb96050: ldur            x0, [fp, #-0x10]
    // 0xb96054: LoadField: r1 = r0->field_67
    //     0xb96054: ldur            w1, [x0, #0x67]
    // 0xb96058: DecompressPointer r1
    //     0xb96058: add             x1, x1, HEAP, lsl #32
    // 0xb9605c: cmp             w1, NULL
    // 0xb96060: b.eq            #0xb96088
    // 0xb96064: r1 = Function '<anonymous closure>':.
    //     0xb96064: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb68] AnonymousClosure: (0xb96134), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragUpdate (0xb95dfc)
    //     0xb96068: ldr             x1, [x1, #0xb68]
    // 0xb9606c: r0 = AllocateClosure()
    //     0xb9606c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb96070: r16 = <void?>
    //     0xb96070: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb96074: ldur            lr, [fp, #-0x10]
    // 0xb96078: stp             lr, x16, [SP, #8]
    // 0xb9607c: str             x0, [SP]
    // 0xb96080: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb96080: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb96084: r0 = invokeCallback()
    //     0xb96084: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb96088: r0 = Null
    //     0xb96088: mov             x0, NULL
    // 0xb9608c: LeaveFrame
    //     0xb9608c: mov             SP, fp
    //     0xb96090: ldp             fp, lr, [SP], #0x10
    // 0xb96094: ret
    //     0xb96094: ret             
    // 0xb96098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb96098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9609c: b               #0xb95e60
    // 0xb960a0: r9 = _initialPosition
    //     0xb960a0: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb38] Field <BaseTapAndDragGestureRecognizer._initialPosition@307288344>: late (offset: 0x94)
    //     0xb960a4: ldr             x9, [x9, #0xb38]
    // 0xb960a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb960a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb96134, size: 0x6c
    // 0xb96134: EnterFrame
    //     0xb96134: stp             fp, lr, [SP, #-0x10]!
    //     0xb96138: mov             fp, SP
    // 0xb9613c: ldr             x0, [fp, #0x10]
    // 0xb96140: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb96140: ldur            w1, [x0, #0x17]
    // 0xb96144: DecompressPointer r1
    //     0xb96144: add             x1, x1, HEAP, lsl #32
    // 0xb96148: CheckStackOverflow
    //     0xb96148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9614c: cmp             SP, x16
    //     0xb96150: b.ls            #0xb96194
    // 0xb96154: LoadField: r0 = r1->field_f
    //     0xb96154: ldur            w0, [x1, #0xf]
    // 0xb96158: DecompressPointer r0
    //     0xb96158: add             x0, x0, HEAP, lsl #32
    // 0xb9615c: LoadField: r2 = r0->field_67
    //     0xb9615c: ldur            w2, [x0, #0x67]
    // 0xb96160: DecompressPointer r2
    //     0xb96160: add             x2, x2, HEAP, lsl #32
    // 0xb96164: cmp             w2, NULL
    // 0xb96168: b.eq            #0xb9619c
    // 0xb9616c: LoadField: r0 = r1->field_13
    //     0xb9616c: ldur            w0, [x1, #0x13]
    // 0xb96170: DecompressPointer r0
    //     0xb96170: add             x0, x0, HEAP, lsl #32
    // 0xb96174: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb96174: ldur            w1, [x2, #0x17]
    // 0xb96178: DecompressPointer r1
    //     0xb96178: add             x1, x1, HEAP, lsl #32
    // 0xb9617c: mov             x2, x0
    // 0xb96180: r0 = _handleDragUpdate()
    //     0xb96180: bl              #0xb961dc  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_handleDragUpdate
    // 0xb96184: r0 = Null
    //     0xb96184: mov             x0, NULL
    // 0xb96188: LeaveFrame
    //     0xb96188: mov             SP, fp
    //     0xb9618c: ldp             fp, lr, [SP], #0x10
    // 0xb96190: ret
    //     0xb96190: ret             
    // 0xb96194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb96194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb96198: b               #0xb96154
    // 0xb9619c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9619c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDragStart(/* No info */) {
    // ** addr: 0xb987ec, size: 0x164
    // 0xb987ec: EnterFrame
    //     0xb987ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb987f0: mov             fp, SP
    // 0xb987f4: AllocStack(0x40)
    //     0xb987f4: sub             SP, SP, #0x40
    // 0xb987f8: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb987f8: mov             x0, x1
    //     0xb987fc: stur            x1, [fp, #-8]
    //     0xb98800: mov             x1, x2
    //     0xb98804: stur            x2, [fp, #-0x10]
    // 0xb98808: CheckStackOverflow
    //     0xb98808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9880c: cmp             SP, x16
    //     0xb98810: b.ls            #0xb9893c
    // 0xb98814: r1 = 2
    //     0xb98814: mov             x1, #2
    // 0xb98818: r0 = AllocateContext()
    //     0xb98818: bl              #0x13de838  ; AllocateContextStub
    // 0xb9881c: mov             x3, x0
    // 0xb98820: ldur            x2, [fp, #-8]
    // 0xb98824: stur            x3, [fp, #-0x18]
    // 0xb98828: StoreField: r3->field_f = r2
    //     0xb98828: stur            w2, [x3, #0xf]
    // 0xb9882c: LoadField: r0 = r2->field_63
    //     0xb9882c: ldur            w0, [x2, #0x63]
    // 0xb98830: DecompressPointer r0
    //     0xb98830: add             x0, x0, HEAP, lsl #32
    // 0xb98834: cmp             w0, NULL
    // 0xb98838: b.eq            #0xb98924
    // 0xb9883c: ldur            x4, [fp, #-0x10]
    // 0xb98840: r0 = LoadClassIdInstr(r4)
    //     0xb98840: ldur            x0, [x4, #-1]
    //     0xb98844: ubfx            x0, x0, #0xc, #0x14
    // 0xb98848: mov             x1, x4
    // 0xb9884c: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xb9884c: mov             x17, #0x5eb5
    //     0xb98850: movk            x17, #1, lsl #16
    //     0xb98854: add             lr, x0, x17
    //     0xb98858: ldr             lr, [x21, lr, lsl #3]
    //     0xb9885c: blr             lr
    // 0xb98860: ldur            x2, [fp, #-8]
    // 0xb98864: LoadField: r0 = r2->field_93
    //     0xb98864: ldur            w0, [x2, #0x93]
    // 0xb98868: DecompressPointer r0
    //     0xb98868: add             x0, x0, HEAP, lsl #32
    // 0xb9886c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb98870: cmp             w0, w16
    // 0xb98874: b.eq            #0xb98944
    // 0xb98878: LoadField: r3 = r0->field_b
    //     0xb98878: ldur            w3, [x0, #0xb]
    // 0xb9887c: DecompressPointer r3
    //     0xb9887c: add             x3, x3, HEAP, lsl #32
    // 0xb98880: ldur            x1, [fp, #-0x10]
    // 0xb98884: stur            x3, [fp, #-0x20]
    // 0xb98888: r0 = LoadClassIdInstr(r1)
    //     0xb98888: ldur            x0, [x1, #-1]
    //     0xb9888c: ubfx            x0, x0, #0xc, #0x14
    // 0xb98890: r0 = GDT[cid_x0 + -0x1]()
    //     0xb98890: sub             lr, x0, #1
    //     0xb98894: ldr             lr, [x21, lr, lsl #3]
    //     0xb98898: blr             lr
    // 0xb9889c: ldur            x1, [fp, #-8]
    // 0xb988a0: mov             x2, x0
    // 0xb988a4: r0 = getKindForPointer()
    //     0xb988a4: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xb988a8: mov             x1, x0
    // 0xb988ac: ldur            x0, [fp, #-8]
    // 0xb988b0: stur            x1, [fp, #-0x10]
    // 0xb988b4: LoadField: r2 = r0->field_2b
    //     0xb988b4: ldur            x2, [x0, #0x2b]
    // 0xb988b8: stur            x2, [fp, #-0x28]
    // 0xb988bc: r0 = TapDragStartDetails()
    //     0xb988bc: bl              #0xb98950  ; AllocateTapDragStartDetailsStub -> TapDragStartDetails (size=0x18)
    // 0xb988c0: mov             x1, x0
    // 0xb988c4: ldur            x0, [fp, #-0x20]
    // 0xb988c8: StoreField: r1->field_7 = r0
    //     0xb988c8: stur            w0, [x1, #7]
    // 0xb988cc: ldur            x0, [fp, #-0x10]
    // 0xb988d0: StoreField: r1->field_b = r0
    //     0xb988d0: stur            w0, [x1, #0xb]
    // 0xb988d4: ldur            x0, [fp, #-0x28]
    // 0xb988d8: StoreField: r1->field_f = r0
    //     0xb988d8: stur            x0, [x1, #0xf]
    // 0xb988dc: mov             x0, x1
    // 0xb988e0: ldur            x2, [fp, #-0x18]
    // 0xb988e4: StoreField: r2->field_13 = r0
    //     0xb988e4: stur            w0, [x2, #0x13]
    //     0xb988e8: ldurb           w16, [x2, #-1]
    //     0xb988ec: ldurb           w17, [x0, #-1]
    //     0xb988f0: and             x16, x17, x16, lsr #2
    //     0xb988f4: tst             x16, HEAP, lsr #32
    //     0xb988f8: b.eq            #0xb98900
    //     0xb988fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb98900: r1 = Function '<anonymous closure>':.
    //     0xb98900: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb48] AnonymousClosure: (0xb9895c), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragStart (0xb987ec)
    //     0xb98904: ldr             x1, [x1, #0xb48]
    // 0xb98908: r0 = AllocateClosure()
    //     0xb98908: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9890c: r16 = <void?>
    //     0xb9890c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb98910: ldur            lr, [fp, #-8]
    // 0xb98914: stp             lr, x16, [SP, #8]
    // 0xb98918: str             x0, [SP]
    // 0xb9891c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9891c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb98920: r0 = invokeCallback()
    //     0xb98920: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb98924: ldur            x1, [fp, #-8]
    // 0xb98928: StoreField: r1->field_8f = rNULL
    //     0xb98928: stur            NULL, [x1, #0x8f]
    // 0xb9892c: r0 = Null
    //     0xb9892c: mov             x0, NULL
    // 0xb98930: LeaveFrame
    //     0xb98930: mov             SP, fp
    //     0xb98934: ldp             fp, lr, [SP], #0x10
    // 0xb98938: ret
    //     0xb98938: ret             
    // 0xb9893c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9893c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb98940: b               #0xb98814
    // 0xb98944: r9 = _initialPosition
    //     0xb98944: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb38] Field <BaseTapAndDragGestureRecognizer._initialPosition@307288344>: late (offset: 0x94)
    //     0xb98948: ldr             x9, [x9, #0xb38]
    // 0xb9894c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9894c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb9895c, size: 0x6c
    // 0xb9895c: EnterFrame
    //     0xb9895c: stp             fp, lr, [SP, #-0x10]!
    //     0xb98960: mov             fp, SP
    // 0xb98964: ldr             x0, [fp, #0x10]
    // 0xb98968: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb98968: ldur            w1, [x0, #0x17]
    // 0xb9896c: DecompressPointer r1
    //     0xb9896c: add             x1, x1, HEAP, lsl #32
    // 0xb98970: CheckStackOverflow
    //     0xb98970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb98974: cmp             SP, x16
    //     0xb98978: b.ls            #0xb989bc
    // 0xb9897c: LoadField: r0 = r1->field_f
    //     0xb9897c: ldur            w0, [x1, #0xf]
    // 0xb98980: DecompressPointer r0
    //     0xb98980: add             x0, x0, HEAP, lsl #32
    // 0xb98984: LoadField: r2 = r0->field_63
    //     0xb98984: ldur            w2, [x0, #0x63]
    // 0xb98988: DecompressPointer r2
    //     0xb98988: add             x2, x2, HEAP, lsl #32
    // 0xb9898c: cmp             w2, NULL
    // 0xb98990: b.eq            #0xb989c4
    // 0xb98994: LoadField: r0 = r1->field_13
    //     0xb98994: ldur            w0, [x1, #0x13]
    // 0xb98998: DecompressPointer r0
    //     0xb98998: add             x0, x0, HEAP, lsl #32
    // 0xb9899c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb9899c: ldur            w1, [x2, #0x17]
    // 0xb989a0: DecompressPointer r1
    //     0xb989a0: add             x1, x1, HEAP, lsl #32
    // 0xb989a4: mov             x2, x0
    // 0xb989a8: r0 = _handleDragStart()
    //     0xb989a8: bl              #0xb98a04  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_handleDragStart
    // 0xb989ac: r0 = Null
    //     0xb989ac: mov             x0, NULL
    // 0xb989b0: LeaveFrame
    //     0xb989b0: mov             SP, fp
    //     0xb989b4: ldp             fp, lr, [SP], #0x10
    // 0xb989b8: ret
    //     0xb989b8: ret             
    // 0xb989bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb989bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb989c0: b               #0xb9897c
    // 0xb989c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb989c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0xb98ff8, size: 0x7c
    // 0xb98ff8: EnterFrame
    //     0xb98ff8: stp             fp, lr, [SP, #-0x10]!
    //     0xb98ffc: mov             fp, SP
    // 0xb99000: AllocStack(0x20)
    //     0xb99000: sub             SP, SP, #0x20
    // 0xb99004: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xb99004: stur            x1, [fp, #-8]
    // 0xb99008: CheckStackOverflow
    //     0xb99008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9900c: cmp             SP, x16
    //     0xb99010: b.ls            #0xb9906c
    // 0xb99014: LoadField: r0 = r1->field_77
    //     0xb99014: ldur            w0, [x1, #0x77]
    // 0xb99018: DecompressPointer r0
    //     0xb99018: add             x0, x0, HEAP, lsl #32
    // 0xb9901c: tbz             w0, #4, #0xb99030
    // 0xb99020: r0 = Null
    //     0xb99020: mov             x0, NULL
    // 0xb99024: LeaveFrame
    //     0xb99024: mov             SP, fp
    //     0xb99028: ldp             fp, lr, [SP], #0x10
    // 0xb9902c: ret
    //     0xb9902c: ret             
    // 0xb99030: LoadField: r0 = r1->field_6f
    //     0xb99030: ldur            w0, [x1, #0x6f]
    // 0xb99034: DecompressPointer r0
    //     0xb99034: add             x0, x0, HEAP, lsl #32
    // 0xb99038: cmp             w0, NULL
    // 0xb9903c: b.eq            #0xb99054
    // 0xb99040: r16 = <void?>
    //     0xb99040: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb99044: stp             x1, x16, [SP, #8]
    // 0xb99048: str             x0, [SP]
    // 0xb9904c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9904c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb99050: r0 = invokeCallback()
    //     0xb99050: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb99054: ldur            x1, [fp, #-8]
    // 0xb99058: r0 = _resetTaps()
    //     0xb99058: bl              #0xb951f4  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_resetTaps
    // 0xb9905c: r0 = Null
    //     0xb9905c: mov             x0, NULL
    // 0xb99060: LeaveFrame
    //     0xb99060: mov             SP, fp
    //     0xb99064: ldp             fp, lr, [SP], #0x10
    // 0xb99068: ret
    //     0xb99068: ret             
    // 0xb9906c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9906c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99070: b               #0xb99014
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xb9bda4, size: 0x24
    // 0xb9bda4: EnterFrame
    //     0xb9bda4: stp             fp, lr, [SP, #-0x10]!
    //     0xb9bda8: mov             fp, SP
    // 0xb9bdac: ldr             x2, [fp, #0x10]
    // 0xb9bdb0: r1 = Function 'handleEvent':.
    //     0xb9bdb0: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb20] AnonymousClosure: (0xb9bdc8), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::handleEvent (0xb9be04)
    //     0xb9bdb4: ldr             x1, [x1, #0xb20]
    // 0xb9bdb8: r0 = AllocateClosure()
    //     0xb9bdb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9bdbc: LeaveFrame
    //     0xb9bdbc: mov             SP, fp
    //     0xb9bdc0: ldp             fp, lr, [SP], #0x10
    // 0xb9bdc4: ret
    //     0xb9bdc4: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xb9bdc8, size: 0x3c
    // 0xb9bdc8: EnterFrame
    //     0xb9bdc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9bdcc: mov             fp, SP
    // 0xb9bdd0: ldr             x0, [fp, #0x18]
    // 0xb9bdd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9bdd4: ldur            w1, [x0, #0x17]
    // 0xb9bdd8: DecompressPointer r1
    //     0xb9bdd8: add             x1, x1, HEAP, lsl #32
    // 0xb9bddc: CheckStackOverflow
    //     0xb9bddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9bde0: cmp             SP, x16
    //     0xb9bde4: b.ls            #0xb9bdfc
    // 0xb9bde8: ldr             x2, [fp, #0x10]
    // 0xb9bdec: r0 = handleEvent()
    //     0xb9bdec: bl              #0xb9be04  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::handleEvent
    // 0xb9bdf0: LeaveFrame
    //     0xb9bdf0: mov             SP, fp
    //     0xb9bdf4: ldp             fp, lr, [SP], #0x10
    // 0xb9bdf8: ret
    //     0xb9bdf8: ret             
    // 0xb9bdfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9bdfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9be00: b               #0xb9bde8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xb9be04, size: 0x408
    // 0xb9be04: EnterFrame
    //     0xb9be04: stp             fp, lr, [SP, #-0x10]!
    //     0xb9be08: mov             fp, SP
    // 0xb9be0c: AllocStack(0x20)
    //     0xb9be0c: sub             SP, SP, #0x20
    // 0xb9be10: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb9be10: mov             x3, x1
    //     0xb9be14: stur            x1, [fp, #-8]
    //     0xb9be18: stur            x2, [fp, #-0x10]
    // 0xb9be1c: CheckStackOverflow
    //     0xb9be1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9be20: cmp             SP, x16
    //     0xb9be24: b.ls            #0xb9c1f8
    // 0xb9be28: r0 = LoadClassIdInstr(r2)
    //     0xb9be28: ldur            x0, [x2, #-1]
    //     0xb9be2c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9be30: mov             x1, x2
    // 0xb9be34: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9be34: sub             lr, x0, #1
    //     0xb9be38: ldr             lr, [x21, lr, lsl #3]
    //     0xb9be3c: blr             lr
    // 0xb9be40: mov             x2, x0
    // 0xb9be44: ldur            x3, [fp, #-8]
    // 0xb9be48: LoadField: r4 = r3->field_7f
    //     0xb9be48: ldur            w4, [x3, #0x7f]
    // 0xb9be4c: DecompressPointer r4
    //     0xb9be4c: add             x4, x4, HEAP, lsl #32
    // 0xb9be50: r0 = BoxInt64Instr(r2)
    //     0xb9be50: sbfiz           x0, x2, #1, #0x1f
    //     0xb9be54: cmp             x2, x0, asr #1
    //     0xb9be58: b.eq            #0xb9be64
    //     0xb9be5c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9be60: stur            x2, [x0, #7]
    // 0xb9be64: cmp             w0, w4
    // 0xb9be68: b.eq            #0xb9beb4
    // 0xb9be6c: and             w16, w0, w4
    // 0xb9be70: branchIfSmi(r16, 0xb9bea4)
    //     0xb9be70: tbz             w16, #0, #0xb9bea4
    // 0xb9be74: r16 = LoadClassIdInstr(r0)
    //     0xb9be74: ldur            x16, [x0, #-1]
    //     0xb9be78: ubfx            x16, x16, #0xc, #0x14
    // 0xb9be7c: cmp             x16, #0x3d
    // 0xb9be80: b.ne            #0xb9bea4
    // 0xb9be84: r16 = LoadClassIdInstr(r4)
    //     0xb9be84: ldur            x16, [x4, #-1]
    //     0xb9be88: ubfx            x16, x16, #0xc, #0x14
    // 0xb9be8c: cmp             x16, #0x3d
    // 0xb9be90: b.ne            #0xb9bea4
    // 0xb9be94: LoadField: r16 = r0->field_7
    //     0xb9be94: ldur            x16, [x0, #7]
    // 0xb9be98: LoadField: r17 = r4->field_7
    //     0xb9be98: ldur            x17, [x4, #7]
    // 0xb9be9c: cmp             x16, x17
    // 0xb9bea0: b.eq            #0xb9beb4
    // 0xb9bea4: r0 = Null
    //     0xb9bea4: mov             x0, NULL
    // 0xb9bea8: LeaveFrame
    //     0xb9bea8: mov             SP, fp
    //     0xb9beac: ldp             fp, lr, [SP], #0x10
    // 0xb9beb0: ret
    //     0xb9beb0: ret             
    // 0xb9beb4: mov             x1, x3
    // 0xb9beb8: ldur            x2, [fp, #-0x10]
    // 0xb9bebc: r0 = handleEvent()
    //     0xb9bebc: bl              #0xb9ca5c  ; [dart:mixin_deduplication] _MixinApplication499&OneSequenceGestureRecognizer&_TapStatusTrackerMixin::handleEvent
    // 0xb9bec0: ldur            x0, [fp, #-0x10]
    // 0xb9bec4: r2 = Null
    //     0xb9bec4: mov             x2, NULL
    // 0xb9bec8: r1 = Null
    //     0xb9bec8: mov             x1, NULL
    // 0xb9becc: cmp             w0, NULL
    // 0xb9bed0: b.eq            #0xb9bef8
    // 0xb9bed4: branchIfSmi(r0, 0xb9bef8)
    //     0xb9bed4: tbz             w0, #0, #0xb9bef8
    // 0xb9bed8: r3 = LoadClassIdInstr(r0)
    //     0xb9bed8: ldur            x3, [x0, #-1]
    //     0xb9bedc: ubfx            x3, x3, #0xc, #0x14
    // 0xb9bee0: r17 = 4157
    //     0xb9bee0: mov             x17, #0x103d
    // 0xb9bee4: cmp             x3, x17
    // 0xb9bee8: b.eq            #0xb9bf00
    // 0xb9beec: r17 = 5286
    //     0xb9beec: mov             x17, #0x14a6
    // 0xb9bef0: cmp             x3, x17
    // 0xb9bef4: b.eq            #0xb9bf00
    // 0xb9bef8: r0 = false
    //     0xb9bef8: add             x0, NULL, #0x30  ; false
    // 0xb9befc: b               #0xb9bf04
    // 0xb9bf00: r0 = true
    //     0xb9bf00: add             x0, NULL, #0x20  ; true
    // 0xb9bf04: tbnz            w0, #4, #0xb9c0b4
    // 0xb9bf08: ldur            x2, [fp, #-8]
    // 0xb9bf0c: ldur            x3, [fp, #-0x10]
    // 0xb9bf10: r0 = LoadClassIdInstr(r3)
    //     0xb9bf10: ldur            x0, [x3, #-1]
    //     0xb9bf14: ubfx            x0, x0, #0xc, #0x14
    // 0xb9bf18: mov             x1, x3
    // 0xb9bf1c: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb9bf1c: mov             x17, #0x5e74
    //     0xb9bf20: movk            x17, #1, lsl #16
    //     0xb9bf24: add             lr, x0, x17
    //     0xb9bf28: ldr             lr, [x21, lr, lsl #3]
    //     0xb9bf2c: blr             lr
    // 0xb9bf30: mov             x1, x0
    // 0xb9bf34: ldur            x0, [fp, #-8]
    // 0xb9bf38: LoadField: r2 = r0->field_7
    //     0xb9bf38: ldur            w2, [x0, #7]
    // 0xb9bf3c: DecompressPointer r2
    //     0xb9bf3c: add             x2, x2, HEAP, lsl #32
    // 0xb9bf40: LoadField: r3 = r1->field_7
    //     0xb9bf40: ldur            x3, [x1, #7]
    // 0xb9bf44: cmp             x3, #2
    // 0xb9bf48: b.gt            #0xb9bf64
    // 0xb9bf4c: cmp             x3, #1
    // 0xb9bf50: b.gt            #0xb9bf64
    // 0xb9bf54: cmp             x3, #0
    // 0xb9bf58: b.le            #0xb9bf64
    // 0xb9bf5c: d0 = 1.000000
    //     0xb9bf5c: fmov            d0, #1.00000000
    // 0xb9bf60: b               #0xb9bf90
    // 0xb9bf64: cmp             w2, NULL
    // 0xb9bf68: b.ne            #0xb9bf74
    // 0xb9bf6c: r1 = Null
    //     0xb9bf6c: mov             x1, NULL
    // 0xb9bf70: b               #0xb9bf7c
    // 0xb9bf74: LoadField: r1 = r2->field_7
    //     0xb9bf74: ldur            w1, [x2, #7]
    // 0xb9bf78: DecompressPointer r1
    //     0xb9bf78: add             x1, x1, HEAP, lsl #32
    // 0xb9bf7c: cmp             w1, NULL
    // 0xb9bf80: b.ne            #0xb9bf8c
    // 0xb9bf84: d0 = 18.000000
    //     0xb9bf84: fmov            d0, #18.00000000
    // 0xb9bf88: b               #0xb9bf90
    // 0xb9bf8c: LoadField: d0 = r1->field_7
    //     0xb9bf8c: ldur            d0, [x1, #7]
    // 0xb9bf90: stur            d0, [fp, #-0x20]
    // 0xb9bf94: LoadField: r1 = r0->field_73
    //     0xb9bf94: ldur            w1, [x0, #0x73]
    // 0xb9bf98: DecompressPointer r1
    //     0xb9bf98: add             x1, x1, HEAP, lsl #32
    // 0xb9bf9c: tbnz            w1, #4, #0xb9bfac
    // 0xb9bfa0: mov             x1, x0
    // 0xb9bfa4: r0 = true
    //     0xb9bfa4: add             x0, NULL, #0x20  ; true
    // 0xb9bfa8: b               #0xb9bfe4
    // 0xb9bfac: LoadField: r2 = r0->field_93
    //     0xb9bfac: ldur            w2, [x0, #0x93]
    // 0xb9bfb0: DecompressPointer r2
    //     0xb9bfb0: add             x2, x2, HEAP, lsl #32
    // 0xb9bfb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9bfb8: cmp             w2, w16
    // 0xb9bfbc: b.eq            #0xb9c200
    // 0xb9bfc0: ldur            x1, [fp, #-0x10]
    // 0xb9bfc4: r0 = _getGlobalDistance()
    //     0xb9bfc4: bl              #0xb9c9d8  ; [package:flutter/src/gestures/tap_and_drag.dart] ::_getGlobalDistance
    // 0xb9bfc8: mov             v1.16b, v0.16b
    // 0xb9bfcc: ldur            d0, [fp, #-0x20]
    // 0xb9bfd0: fcmp            d1, d0
    // 0xb9bfd4: r16 = true
    //     0xb9bfd4: add             x16, NULL, #0x20  ; true
    // 0xb9bfd8: r17 = false
    //     0xb9bfd8: add             x17, NULL, #0x30  ; false
    // 0xb9bfdc: csel            x0, x16, x17, gt
    // 0xb9bfe0: ldur            x1, [fp, #-8]
    // 0xb9bfe4: StoreField: r1->field_73 = r0
    //     0xb9bfe4: stur            w0, [x1, #0x73]
    // 0xb9bfe8: LoadField: r0 = r1->field_8b
    //     0xb9bfe8: ldur            w0, [x1, #0x8b]
    // 0xb9bfec: DecompressPointer r0
    //     0xb9bfec: add             x0, x0, HEAP, lsl #32
    // 0xb9bff0: r16 = Instance__DragState
    //     0xb9bff0: add             x16, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0xb9bff4: ldr             x16, [x16, #0xb28]
    // 0xb9bff8: cmp             w0, w16
    // 0xb9bffc: b.ne            #0xb9c04c
    // 0xb9c000: r0 = OffsetPair()
    //     0xb9c000: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb9c004: mov             x1, x0
    // 0xb9c008: ldur            x2, [fp, #-0x10]
    // 0xb9c00c: stur            x0, [fp, #-0x18]
    // 0xb9c010: r0 = OffsetPair.fromEventPosition()
    //     0xb9c010: bl              #0xb98730  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0xb9c014: ldur            x0, [fp, #-0x18]
    // 0xb9c018: ldur            x3, [fp, #-8]
    // 0xb9c01c: StoreField: r3->field_97 = r0
    //     0xb9c01c: stur            w0, [x3, #0x97]
    //     0xb9c020: ldurb           w16, [x3, #-1]
    //     0xb9c024: ldurb           w17, [x0, #-1]
    //     0xb9c028: and             x16, x17, x16, lsr #2
    //     0xb9c02c: tst             x16, HEAP, lsr #32
    //     0xb9c030: b.eq            #0xb9c038
    //     0xb9c034: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb9c038: mov             x1, x3
    // 0xb9c03c: ldur            x2, [fp, #-0x10]
    // 0xb9c040: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb9c040: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb9c044: r0 = _checkDragUpdate()
    //     0xb9c044: bl              #0xb95dfc  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDragUpdate
    // 0xb9c048: b               #0xb9c1e8
    // 0xb9c04c: mov             x3, x1
    // 0xb9c050: r16 = Instance__DragState
    //     0xb9c050: add             x16, PP, #0xac, lsl #12  ; [pp+0xacb30] Obj!_DragState@12c5b21
    //     0xb9c054: ldr             x16, [x16, #0xb30]
    // 0xb9c058: cmp             w0, w16
    // 0xb9c05c: b.ne            #0xb9c1e8
    // 0xb9c060: LoadField: r0 = r3->field_8f
    //     0xb9c060: ldur            w0, [x3, #0x8f]
    // 0xb9c064: DecompressPointer r0
    //     0xb9c064: add             x0, x0, HEAP, lsl #32
    // 0xb9c068: cmp             w0, NULL
    // 0xb9c06c: b.ne            #0xb9c07c
    // 0xb9c070: mov             x1, x3
    // 0xb9c074: ldur            x2, [fp, #-0x10]
    // 0xb9c078: r0 = _checkDrag()
    //     0xb9c078: bl              #0xb9c40c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkDrag
    // 0xb9c07c: ldur            x3, [fp, #-8]
    // 0xb9c080: LoadField: r2 = r3->field_8f
    //     0xb9c080: ldur            w2, [x3, #0x8f]
    // 0xb9c084: DecompressPointer r2
    //     0xb9c084: add             x2, x2, HEAP, lsl #32
    // 0xb9c088: cmp             w2, NULL
    // 0xb9c08c: b.eq            #0xb9c1e8
    // 0xb9c090: LoadField: r0 = r3->field_7b
    //     0xb9c090: ldur            w0, [x3, #0x7b]
    // 0xb9c094: DecompressPointer r0
    //     0xb9c094: add             x0, x0, HEAP, lsl #32
    // 0xb9c098: tbnz            w0, #4, #0xb9c1e8
    // 0xb9c09c: r0 = Instance__DragState
    //     0xb9c09c: add             x0, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0xb9c0a0: ldr             x0, [x0, #0xb28]
    // 0xb9c0a4: StoreField: r3->field_8b = r0
    //     0xb9c0a4: stur            w0, [x3, #0x8b]
    // 0xb9c0a8: mov             x1, x3
    // 0xb9c0ac: r0 = _acceptDrag()
    //     0xb9c0ac: bl              #0xb95b1c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_acceptDrag
    // 0xb9c0b0: b               #0xb9c1e8
    // 0xb9c0b4: ldur            x3, [fp, #-8]
    // 0xb9c0b8: ldur            x0, [fp, #-0x10]
    // 0xb9c0bc: r2 = Null
    //     0xb9c0bc: mov             x2, NULL
    // 0xb9c0c0: r1 = Null
    //     0xb9c0c0: mov             x1, NULL
    // 0xb9c0c4: cmp             w0, NULL
    // 0xb9c0c8: b.eq            #0xb9c0f0
    // 0xb9c0cc: branchIfSmi(r0, 0xb9c0f0)
    //     0xb9c0cc: tbz             w0, #0, #0xb9c0f0
    // 0xb9c0d0: r3 = LoadClassIdInstr(r0)
    //     0xb9c0d0: ldur            x3, [x0, #-1]
    //     0xb9c0d4: ubfx            x3, x3, #0xc, #0x14
    // 0xb9c0d8: r17 = 4155
    //     0xb9c0d8: mov             x17, #0x103b
    // 0xb9c0dc: cmp             x3, x17
    // 0xb9c0e0: b.eq            #0xb9c0f8
    // 0xb9c0e4: r17 = 5284
    //     0xb9c0e4: mov             x17, #0x14a4
    // 0xb9c0e8: cmp             x3, x17
    // 0xb9c0ec: b.eq            #0xb9c0f8
    // 0xb9c0f0: r0 = false
    //     0xb9c0f0: add             x0, NULL, #0x30  ; false
    // 0xb9c0f4: b               #0xb9c0fc
    // 0xb9c0f8: r0 = true
    //     0xb9c0f8: add             x0, NULL, #0x20  ; true
    // 0xb9c0fc: tbnz            w0, #4, #0xb9c168
    // 0xb9c100: ldur            x2, [fp, #-8]
    // 0xb9c104: LoadField: r0 = r2->field_8b
    //     0xb9c104: ldur            w0, [x2, #0x8b]
    // 0xb9c108: DecompressPointer r0
    //     0xb9c108: add             x0, x0, HEAP, lsl #32
    // 0xb9c10c: r16 = Instance__DragState
    //     0xb9c10c: add             x16, PP, #0xac, lsl #12  ; [pp+0xacb30] Obj!_DragState@12c5b21
    //     0xb9c110: ldr             x16, [x16, #0xb30]
    // 0xb9c114: cmp             w0, w16
    // 0xb9c118: b.ne            #0xb9c12c
    // 0xb9c11c: mov             x1, x2
    // 0xb9c120: ldur            x2, [fp, #-0x10]
    // 0xb9c124: r0 = stopTrackingIfPointerNoLongerDown()
    //     0xb9c124: bl              #0xb9c294  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0xb9c128: b               #0xb9c1e8
    // 0xb9c12c: r16 = Instance__DragState
    //     0xb9c12c: add             x16, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0xb9c130: ldr             x16, [x16, #0xb28]
    // 0xb9c134: cmp             w0, w16
    // 0xb9c138: b.ne            #0xb9c1e8
    // 0xb9c13c: ldur            x3, [fp, #-0x10]
    // 0xb9c140: r0 = LoadClassIdInstr(r3)
    //     0xb9c140: ldur            x0, [x3, #-1]
    //     0xb9c144: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c148: mov             x1, x3
    // 0xb9c14c: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9c14c: sub             lr, x0, #1
    //     0xb9c150: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c154: blr             lr
    // 0xb9c158: ldur            x1, [fp, #-8]
    // 0xb9c15c: mov             x2, x0
    // 0xb9c160: r0 = _giveUpPointer()
    //     0xb9c160: bl              #0xb9c20c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_giveUpPointer
    // 0xb9c164: b               #0xb9c1e8
    // 0xb9c168: ldur            x3, [fp, #-0x10]
    // 0xb9c16c: mov             x0, x3
    // 0xb9c170: r2 = Null
    //     0xb9c170: mov             x2, NULL
    // 0xb9c174: r1 = Null
    //     0xb9c174: mov             x1, NULL
    // 0xb9c178: cmp             w0, NULL
    // 0xb9c17c: b.eq            #0xb9c1a4
    // 0xb9c180: branchIfSmi(r0, 0xb9c1a4)
    //     0xb9c180: tbz             w0, #0, #0xb9c1a4
    // 0xb9c184: r3 = LoadClassIdInstr(r0)
    //     0xb9c184: ldur            x3, [x0, #-1]
    //     0xb9c188: ubfx            x3, x3, #0xc, #0x14
    // 0xb9c18c: r17 = 4139
    //     0xb9c18c: mov             x17, #0x102b
    // 0xb9c190: cmp             x3, x17
    // 0xb9c194: b.eq            #0xb9c1ac
    // 0xb9c198: r17 = 5276
    //     0xb9c198: mov             x17, #0x149c
    // 0xb9c19c: cmp             x3, x17
    // 0xb9c1a0: b.eq            #0xb9c1ac
    // 0xb9c1a4: r0 = false
    //     0xb9c1a4: add             x0, NULL, #0x30  ; false
    // 0xb9c1a8: b               #0xb9c1b0
    // 0xb9c1ac: r0 = true
    //     0xb9c1ac: add             x0, NULL, #0x20  ; true
    // 0xb9c1b0: tbnz            w0, #4, #0xb9c1e8
    // 0xb9c1b4: ldur            x2, [fp, #-8]
    // 0xb9c1b8: ldur            x1, [fp, #-0x10]
    // 0xb9c1bc: r0 = Instance__DragState
    //     0xb9c1bc: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3e58] Obj!_DragState@12c5ae1
    //     0xb9c1c0: ldr             x0, [x0, #0xe58]
    // 0xb9c1c4: StoreField: r2->field_8b = r0
    //     0xb9c1c4: stur            w0, [x2, #0x8b]
    // 0xb9c1c8: r0 = LoadClassIdInstr(r1)
    //     0xb9c1c8: ldur            x0, [x1, #-1]
    //     0xb9c1cc: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c1d0: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9c1d0: sub             lr, x0, #1
    //     0xb9c1d4: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c1d8: blr             lr
    // 0xb9c1dc: ldur            x1, [fp, #-8]
    // 0xb9c1e0: mov             x2, x0
    // 0xb9c1e4: r0 = _giveUpPointer()
    //     0xb9c1e4: bl              #0xb9c20c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_giveUpPointer
    // 0xb9c1e8: r0 = Null
    //     0xb9c1e8: mov             x0, NULL
    // 0xb9c1ec: LeaveFrame
    //     0xb9c1ec: mov             SP, fp
    //     0xb9c1f0: ldp             fp, lr, [SP], #0x10
    // 0xb9c1f4: ret
    //     0xb9c1f4: ret             
    // 0xb9c1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9c1f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9c1fc: b               #0xb9be28
    // 0xb9c200: r9 = _initialPosition
    //     0xb9c200: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb38] Field <BaseTapAndDragGestureRecognizer._initialPosition@307288344>: late (offset: 0x94)
    //     0xb9c204: ldr             x9, [x9, #0xb38]
    // 0xb9c208: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb9c208: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _giveUpPointer(/* No info */) {
    // ** addr: 0xb9c20c, size: 0x88
    // 0xb9c20c: EnterFrame
    //     0xb9c20c: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c210: mov             fp, SP
    // 0xb9c214: AllocStack(0x18)
    //     0xb9c214: sub             SP, SP, #0x18
    // 0xb9c218: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xb9c218: mov             x4, x1
    //     0xb9c21c: mov             x3, x2
    //     0xb9c220: stur            x1, [fp, #-0x10]
    //     0xb9c224: stur            x2, [fp, #-0x18]
    // 0xb9c228: CheckStackOverflow
    //     0xb9c228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9c22c: cmp             SP, x16
    //     0xb9c230: b.ls            #0xb9c28c
    // 0xb9c234: r0 = BoxInt64Instr(r3)
    //     0xb9c234: sbfiz           x0, x3, #1, #0x1f
    //     0xb9c238: cmp             x3, x0, asr #1
    //     0xb9c23c: b.eq            #0xb9c248
    //     0xb9c240: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9c244: stur            x3, [x0, #7]
    // 0xb9c248: mov             x1, x4
    // 0xb9c24c: mov             x2, x0
    // 0xb9c250: stur            x0, [fp, #-8]
    // 0xb9c254: r0 = stopTrackingPointer()
    //     0xb9c254: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xb9c258: ldur            x0, [fp, #-0x10]
    // 0xb9c25c: LoadField: r1 = r0->field_a7
    //     0xb9c25c: ldur            w1, [x0, #0xa7]
    // 0xb9c260: DecompressPointer r1
    //     0xb9c260: add             x1, x1, HEAP, lsl #32
    // 0xb9c264: ldur            x2, [fp, #-8]
    // 0xb9c268: r0 = remove()
    //     0xb9c268: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xb9c26c: tbz             w0, #4, #0xb9c27c
    // 0xb9c270: ldur            x1, [fp, #-0x10]
    // 0xb9c274: ldur            x2, [fp, #-0x18]
    // 0xb9c278: r0 = resolvePointer()
    //     0xb9c278: bl              #0xb98f4c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0xb9c27c: r0 = Null
    //     0xb9c27c: mov             x0, NULL
    // 0xb9c280: LeaveFrame
    //     0xb9c280: mov             SP, fp
    //     0xb9c284: ldp             fp, lr, [SP], #0x10
    // 0xb9c288: ret
    //     0xb9c288: ret             
    // 0xb9c28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9c28c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9c290: b               #0xb9c234
  }
  _ _checkDrag(/* No info */) {
    // ** addr: 0xb9c40c, size: 0x41c
    // 0xb9c40c: EnterFrame
    //     0xb9c40c: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c410: mov             fp, SP
    // 0xb9c414: AllocStack(0x30)
    //     0xb9c414: sub             SP, SP, #0x30
    // 0xb9c418: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb9c418: mov             x3, x1
    //     0xb9c41c: stur            x1, [fp, #-8]
    //     0xb9c420: stur            x2, [fp, #-0x10]
    // 0xb9c424: CheckStackOverflow
    //     0xb9c424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9c428: cmp             SP, x16
    //     0xb9c42c: b.ls            #0xb9c7dc
    // 0xb9c430: r0 = LoadClassIdInstr(r2)
    //     0xb9c430: ldur            x0, [x2, #-1]
    //     0xb9c434: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c438: mov             x1, x2
    // 0xb9c43c: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb9c43c: mov             x17, #0x5fe3
    //     0xb9c440: movk            x17, #1, lsl #16
    //     0xb9c444: add             lr, x0, x17
    //     0xb9c448: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c44c: blr             lr
    // 0xb9c450: cmp             w0, NULL
    // 0xb9c454: b.ne            #0xb9c460
    // 0xb9c458: r4 = Null
    //     0xb9c458: mov             x4, NULL
    // 0xb9c45c: b               #0xb9c498
    // 0xb9c460: ldur            x2, [fp, #-0x10]
    // 0xb9c464: r0 = LoadClassIdInstr(r2)
    //     0xb9c464: ldur            x0, [x2, #-1]
    //     0xb9c468: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c46c: mov             x1, x2
    // 0xb9c470: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xb9c470: mov             x17, #0x5fe3
    //     0xb9c474: movk            x17, #1, lsl #16
    //     0xb9c478: add             lr, x0, x17
    //     0xb9c47c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c480: blr             lr
    // 0xb9c484: cmp             w0, NULL
    // 0xb9c488: b.eq            #0xb9c7e4
    // 0xb9c48c: mov             x1, x0
    // 0xb9c490: r0 = tryInvert()
    //     0xb9c490: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xb9c494: mov             x4, x0
    // 0xb9c498: ldur            x3, [fp, #-8]
    // 0xb9c49c: ldur            x2, [fp, #-0x10]
    // 0xb9c4a0: stur            x4, [fp, #-0x18]
    // 0xb9c4a4: r0 = LoadClassIdInstr(r2)
    //     0xb9c4a4: ldur            x0, [x2, #-1]
    //     0xb9c4a8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c4ac: mov             x1, x2
    // 0xb9c4b0: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb9c4b0: mov             x17, #0x545d
    //     0xb9c4b4: movk            x17, #1, lsl #16
    //     0xb9c4b8: add             lr, x0, x17
    //     0xb9c4bc: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c4c0: blr             lr
    // 0xb9c4c4: ldur            x1, [fp, #-8]
    // 0xb9c4c8: mov             x2, x0
    // 0xb9c4cc: r0 = _getDeltaForDetails()
    //     0xb9c4cc: bl              #0x121b900  ; [package:flutter/src/gestures/monodrag.dart] HorizontalDragGestureRecognizer::_getDeltaForDetails
    // 0xb9c4d0: mov             x3, x0
    // 0xb9c4d4: ldur            x2, [fp, #-8]
    // 0xb9c4d8: stur            x3, [fp, #-0x28]
    // 0xb9c4dc: LoadField: r4 = r2->field_9b
    //     0xb9c4dc: ldur            w4, [x2, #0x9b]
    // 0xb9c4e0: DecompressPointer r4
    //     0xb9c4e0: add             x4, x4, HEAP, lsl #32
    // 0xb9c4e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9c4e8: cmp             w4, w16
    // 0xb9c4ec: b.eq            #0xb9c7e8
    // 0xb9c4f0: ldur            x5, [fp, #-0x10]
    // 0xb9c4f4: stur            x4, [fp, #-0x20]
    // 0xb9c4f8: r0 = LoadClassIdInstr(r5)
    //     0xb9c4f8: ldur            x0, [x5, #-1]
    //     0xb9c4fc: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c500: mov             x1, x5
    // 0xb9c504: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb9c504: mov             x17, #0x54ea
    //     0xb9c508: movk            x17, #1, lsl #16
    //     0xb9c50c: add             lr, x0, x17
    //     0xb9c510: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c514: blr             lr
    // 0xb9c518: ldur            x1, [fp, #-0x18]
    // 0xb9c51c: ldur            x2, [fp, #-0x28]
    // 0xb9c520: mov             x3, x0
    // 0xb9c524: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb9c524: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb9c528: r0 = transformDeltaViaPositions()
    //     0xb9c528: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xb9c52c: LoadField: d0 = r0->field_7
    //     0xb9c52c: ldur            d0, [x0, #7]
    // 0xb9c530: fmul            d1, d0, d0
    // 0xb9c534: LoadField: d0 = r0->field_f
    //     0xb9c534: ldur            d0, [x0, #0xf]
    // 0xb9c538: fmul            d2, d0, d0
    // 0xb9c53c: fadd            d0, d1, d2
    // 0xb9c540: fsqrt           d1, d0
    // 0xb9c544: ldur            x0, [fp, #-0x28]
    // 0xb9c548: LoadField: d0 = r0->field_7
    //     0xb9c548: ldur            d0, [x0, #7]
    // 0xb9c54c: d2 = 0.000000
    //     0xb9c54c: eor             v2.16b, v2.16b, v2.16b
    // 0xb9c550: fcmp            d0, d2
    // 0xb9c554: b.le            #0xb9c560
    // 0xb9c558: d0 = 1.000000
    //     0xb9c558: fmov            d0, #1.00000000
    // 0xb9c55c: b               #0xb9c56c
    // 0xb9c560: fcmp            d2, d0
    // 0xb9c564: b.le            #0xb9c56c
    // 0xb9c568: d0 = -1.000000
    //     0xb9c568: fmov            d0, #-1.00000000
    // 0xb9c56c: ldur            x2, [fp, #-8]
    // 0xb9c570: ldur            x3, [fp, #-0x10]
    // 0xb9c574: ldur            x0, [fp, #-0x20]
    // 0xb9c578: fmul            d3, d1, d0
    // 0xb9c57c: LoadField: d0 = r0->field_7
    //     0xb9c57c: ldur            d0, [x0, #7]
    // 0xb9c580: fadd            d1, d0, d3
    // 0xb9c584: r0 = inline_Allocate_Double()
    //     0xb9c584: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9c588: add             x0, x0, #0x10
    //     0xb9c58c: cmp             x1, x0
    //     0xb9c590: b.ls            #0xb9c7f4
    //     0xb9c594: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9c598: sub             x0, x0, #0xf
    //     0xb9c59c: mov             x1, #0xe19c
    //     0xb9c5a0: movk            x1, #3, lsl #16
    //     0xb9c5a4: stur            x1, [x0, #-1]
    // 0xb9c5a8: dmb             ishst
    // 0xb9c5ac: StoreField: r0->field_7 = d1
    //     0xb9c5ac: stur            d1, [x0, #7]
    // 0xb9c5b0: StoreField: r2->field_9b = r0
    //     0xb9c5b0: stur            w0, [x2, #0x9b]
    //     0xb9c5b4: ldurb           w16, [x2, #-1]
    //     0xb9c5b8: ldurb           w17, [x0, #-1]
    //     0xb9c5bc: and             x16, x17, x16, lsr #2
    //     0xb9c5c0: tst             x16, HEAP, lsr #32
    //     0xb9c5c4: b.eq            #0xb9c5cc
    //     0xb9c5c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9c5cc: LoadField: r4 = r2->field_9f
    //     0xb9c5cc: ldur            w4, [x2, #0x9f]
    // 0xb9c5d0: DecompressPointer r4
    //     0xb9c5d0: add             x4, x4, HEAP, lsl #32
    // 0xb9c5d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9c5d8: cmp             w4, w16
    // 0xb9c5dc: b.eq            #0xb9c80c
    // 0xb9c5e0: stur            x4, [fp, #-0x20]
    // 0xb9c5e4: r0 = LoadClassIdInstr(r3)
    //     0xb9c5e4: ldur            x0, [x3, #-1]
    //     0xb9c5e8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c5ec: mov             x1, x3
    // 0xb9c5f0: r0 = GDT[cid_x0 + 0x1545d]()
    //     0xb9c5f0: mov             x17, #0x545d
    //     0xb9c5f4: movk            x17, #1, lsl #16
    //     0xb9c5f8: add             lr, x0, x17
    //     0xb9c5fc: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c600: blr             lr
    // 0xb9c604: mov             x3, x0
    // 0xb9c608: ldur            x2, [fp, #-0x10]
    // 0xb9c60c: stur            x3, [fp, #-0x28]
    // 0xb9c610: r0 = LoadClassIdInstr(r2)
    //     0xb9c610: ldur            x0, [x2, #-1]
    //     0xb9c614: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c618: mov             x1, x2
    // 0xb9c61c: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xb9c61c: mov             x17, #0x54ea
    //     0xb9c620: movk            x17, #1, lsl #16
    //     0xb9c624: add             lr, x0, x17
    //     0xb9c628: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c62c: blr             lr
    // 0xb9c630: ldur            x1, [fp, #-0x18]
    // 0xb9c634: ldur            x2, [fp, #-0x28]
    // 0xb9c638: mov             x3, x0
    // 0xb9c63c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb9c63c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb9c640: r0 = transformDeltaViaPositions()
    //     0xb9c640: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xb9c644: LoadField: d0 = r0->field_7
    //     0xb9c644: ldur            d0, [x0, #7]
    // 0xb9c648: fmul            d1, d0, d0
    // 0xb9c64c: LoadField: d0 = r0->field_f
    //     0xb9c64c: ldur            d0, [x0, #0xf]
    // 0xb9c650: fmul            d2, d0, d0
    // 0xb9c654: fadd            d0, d1, d2
    // 0xb9c658: fsqrt           d1, d0
    // 0xb9c65c: ldur            x0, [fp, #-0x20]
    // 0xb9c660: LoadField: d0 = r0->field_7
    //     0xb9c660: ldur            d0, [x0, #7]
    // 0xb9c664: fadd            d2, d0, d1
    // 0xb9c668: r0 = inline_Allocate_Double()
    //     0xb9c668: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9c66c: add             x0, x0, #0x10
    //     0xb9c670: cmp             x1, x0
    //     0xb9c674: b.ls            #0xb9c818
    //     0xb9c678: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9c67c: sub             x0, x0, #0xf
    //     0xb9c680: mov             x1, #0xe19c
    //     0xb9c684: movk            x1, #3, lsl #16
    //     0xb9c688: stur            x1, [x0, #-1]
    // 0xb9c68c: dmb             ishst
    // 0xb9c690: StoreField: r0->field_7 = d2
    //     0xb9c690: stur            d2, [x0, #7]
    // 0xb9c694: ldur            x2, [fp, #-8]
    // 0xb9c698: StoreField: r2->field_9f = r0
    //     0xb9c698: stur            w0, [x2, #0x9f]
    //     0xb9c69c: ldurb           w16, [x2, #-1]
    //     0xb9c6a0: ldurb           w17, [x0, #-1]
    //     0xb9c6a4: and             x16, x17, x16, lsr #2
    //     0xb9c6a8: tst             x16, HEAP, lsr #32
    //     0xb9c6ac: b.eq            #0xb9c6b4
    //     0xb9c6b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb9c6b4: ldur            x3, [fp, #-0x10]
    // 0xb9c6b8: r0 = LoadClassIdInstr(r3)
    //     0xb9c6b8: ldur            x0, [x3, #-1]
    //     0xb9c6bc: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c6c0: mov             x1, x3
    // 0xb9c6c4: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb9c6c4: mov             x17, #0x5e74
    //     0xb9c6c8: movk            x17, #1, lsl #16
    //     0xb9c6cc: add             lr, x0, x17
    //     0xb9c6d0: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c6d4: blr             lr
    // 0xb9c6d8: ldur            x1, [fp, #-8]
    // 0xb9c6dc: mov             x2, x0
    // 0xb9c6e0: r0 = _hasSufficientGlobalDistanceToAccept()
    //     0xb9c6e0: bl              #0xb9c8f4  ; [package:flutter/src/gestures/tap_and_drag.dart] TapAndHorizontalDragGestureRecognizer::_hasSufficientGlobalDistanceToAccept
    // 0xb9c6e4: tbz             w0, #4, #0xb9c778
    // 0xb9c6e8: ldur            x2, [fp, #-8]
    // 0xb9c6ec: LoadField: r0 = r2->field_7b
    //     0xb9c6ec: ldur            w0, [x2, #0x7b]
    // 0xb9c6f0: DecompressPointer r0
    //     0xb9c6f0: add             x0, x0, HEAP, lsl #32
    // 0xb9c6f4: tbnz            w0, #4, #0xb9c7cc
    // 0xb9c6f8: d0 = 0.000000
    //     0xb9c6f8: eor             v0.16b, v0.16b, v0.16b
    // 0xb9c6fc: LoadField: r0 = r2->field_9f
    //     0xb9c6fc: ldur            w0, [x2, #0x9f]
    // 0xb9c700: DecompressPointer r0
    //     0xb9c700: add             x0, x0, HEAP, lsl #32
    // 0xb9c704: LoadField: d1 = r0->field_7
    //     0xb9c704: ldur            d1, [x0, #7]
    // 0xb9c708: fcmp            d1, d0
    // 0xb9c70c: b.ne            #0xb9c718
    // 0xb9c710: d0 = 0.000000
    //     0xb9c710: eor             v0.16b, v0.16b, v0.16b
    // 0xb9c714: b               #0xb9c72c
    // 0xb9c718: fcmp            d0, d1
    // 0xb9c71c: b.le            #0xb9c728
    // 0xb9c720: fneg            d0, d1
    // 0xb9c724: b               #0xb9c72c
    // 0xb9c728: mov             v0.16b, v1.16b
    // 0xb9c72c: ldur            x3, [fp, #-0x10]
    // 0xb9c730: stur            d0, [fp, #-0x30]
    // 0xb9c734: r0 = LoadClassIdInstr(r3)
    //     0xb9c734: ldur            x0, [x3, #-1]
    //     0xb9c738: ubfx            x0, x0, #0xc, #0x14
    // 0xb9c73c: mov             x1, x3
    // 0xb9c740: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb9c740: mov             x17, #0x5e74
    //     0xb9c744: movk            x17, #1, lsl #16
    //     0xb9c748: add             lr, x0, x17
    //     0xb9c74c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9c750: blr             lr
    // 0xb9c754: mov             x1, x0
    // 0xb9c758: ldur            x0, [fp, #-8]
    // 0xb9c75c: LoadField: r2 = r0->field_7
    //     0xb9c75c: ldur            w2, [x0, #7]
    // 0xb9c760: DecompressPointer r2
    //     0xb9c760: add             x2, x2, HEAP, lsl #32
    // 0xb9c764: r0 = computePanSlop()
    //     0xb9c764: bl              #0xb9c828  ; [package:flutter/src/gestures/events.dart] ::computePanSlop
    // 0xb9c768: mov             v1.16b, v0.16b
    // 0xb9c76c: ldur            d0, [fp, #-0x30]
    // 0xb9c770: fcmp            d0, d1
    // 0xb9c774: b.le            #0xb9c7cc
    // 0xb9c778: ldur            x1, [fp, #-8]
    // 0xb9c77c: ldur            x0, [fp, #-0x10]
    // 0xb9c780: StoreField: r1->field_8f = r0
    //     0xb9c780: stur            w0, [x1, #0x8f]
    //     0xb9c784: ldurb           w16, [x1, #-1]
    //     0xb9c788: ldurb           w17, [x0, #-1]
    //     0xb9c78c: and             x16, x17, x16, lsr #2
    //     0xb9c790: tst             x16, HEAP, lsr #32
    //     0xb9c794: b.eq            #0xb9c79c
    //     0xb9c798: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb9c79c: LoadField: r0 = r1->field_57
    //     0xb9c79c: ldur            w0, [x1, #0x57]
    // 0xb9c7a0: DecompressPointer r0
    //     0xb9c7a0: add             x0, x0, HEAP, lsl #32
    // 0xb9c7a4: tbnz            w0, #4, #0xb9c7cc
    // 0xb9c7a8: r0 = Instance__DragState
    //     0xb9c7a8: add             x0, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0xb9c7ac: ldr             x0, [x0, #0xb28]
    // 0xb9c7b0: StoreField: r1->field_8b = r0
    //     0xb9c7b0: stur            w0, [x1, #0x8b]
    // 0xb9c7b4: LoadField: r0 = r1->field_7b
    //     0xb9c7b4: ldur            w0, [x1, #0x7b]
    // 0xb9c7b8: DecompressPointer r0
    //     0xb9c7b8: add             x0, x0, HEAP, lsl #32
    // 0xb9c7bc: tbz             w0, #4, #0xb9c7cc
    // 0xb9c7c0: r2 = Instance_GestureDisposition
    //     0xb9c7c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xb9c7c4: ldr             x2, [x2, #0x628]
    // 0xb9c7c8: r0 = resolve()
    //     0xb9c7c8: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb9c7cc: r0 = Null
    //     0xb9c7cc: mov             x0, NULL
    // 0xb9c7d0: LeaveFrame
    //     0xb9c7d0: mov             SP, fp
    //     0xb9c7d4: ldp             fp, lr, [SP], #0x10
    // 0xb9c7d8: ret
    //     0xb9c7d8: ret             
    // 0xb9c7dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9c7dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9c7e0: b               #0xb9c430
    // 0xb9c7e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9c7e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb9c7e8: r9 = _globalDistanceMoved
    //     0xb9c7e8: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb50] Field <BaseTapAndDragGestureRecognizer._globalDistanceMoved@307288344>: late (offset: 0x9c)
    //     0xb9c7ec: ldr             x9, [x9, #0xb50]
    // 0xb9c7f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9c7f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb9c7f4: stp             q1, q2, [SP, #-0x20]!
    // 0xb9c7f8: stp             x2, x3, [SP, #-0x10]!
    // 0xb9c7fc: r0 = AllocateDouble()
    //     0xb9c7fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9c800: ldp             x2, x3, [SP], #0x10
    // 0xb9c804: ldp             q1, q2, [SP], #0x20
    // 0xb9c808: b               #0xb9c5ac
    // 0xb9c80c: r9 = _globalDistanceMovedAllAxes
    //     0xb9c80c: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb58] Field <BaseTapAndDragGestureRecognizer._globalDistanceMovedAllAxes@307288344>: late (offset: 0xa0)
    //     0xb9c810: ldr             x9, [x9, #0xb58]
    // 0xb9c814: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb9c814: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb9c818: SaveReg d2
    //     0xb9c818: str             q2, [SP, #-0x10]!
    // 0xb9c81c: r0 = AllocateDouble()
    //     0xb9c81c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9c820: RestoreReg d2
    //     0xb9c820: ldr             q2, [SP], #0x10
    // 0xb9c824: b               #0xb9c690
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba62e4, size: 0x1d4
    // 0xba62e4: EnterFrame
    //     0xba62e4: stp             fp, lr, [SP, #-0x10]!
    //     0xba62e8: mov             fp, SP
    // 0xba62ec: AllocStack(0x20)
    //     0xba62ec: sub             SP, SP, #0x20
    // 0xba62f0: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba62f0: stur            x1, [fp, #-8]
    //     0xba62f4: stur            x2, [fp, #-0x10]
    // 0xba62f8: CheckStackOverflow
    //     0xba62f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba62fc: cmp             SP, x16
    //     0xba6300: b.ls            #0xba64b0
    // 0xba6304: r1 = 1
    //     0xba6304: mov             x1, #1
    // 0xba6308: r0 = AllocateContext()
    //     0xba6308: bl              #0x13de838  ; AllocateContextStub
    // 0xba630c: mov             x3, x0
    // 0xba6310: ldur            x0, [fp, #-8]
    // 0xba6314: stur            x3, [fp, #-0x18]
    // 0xba6318: StoreField: r3->field_f = r0
    //     0xba6318: stur            w0, [x3, #0xf]
    // 0xba631c: LoadField: r1 = r0->field_8b
    //     0xba631c: ldur            w1, [x0, #0x8b]
    // 0xba6320: DecompressPointer r1
    //     0xba6320: add             x1, x1, HEAP, lsl #32
    // 0xba6324: r16 = Instance__DragState
    //     0xba6324: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3e58] Obj!_DragState@12c5ae1
    //     0xba6328: ldr             x16, [x16, #0xe58]
    // 0xba632c: cmp             w1, w16
    // 0xba6330: b.ne            #0xba64a0
    // 0xba6334: ldur            x4, [fp, #-0x10]
    // 0xba6338: mov             x1, x0
    // 0xba633c: mov             x2, x4
    // 0xba6340: r0 = addAllowedPointer()
    //     0xba6340: bl              #0xba64b8  ; [dart:mixin_deduplication] _MixinApplication499&OneSequenceGestureRecognizer&_TapStatusTrackerMixin::addAllowedPointer
    // 0xba6344: ldur            x2, [fp, #-0x10]
    // 0xba6348: r0 = LoadClassIdInstr(r2)
    //     0xba6348: ldur            x0, [x2, #-1]
    //     0xba634c: ubfx            x0, x0, #0xc, #0x14
    // 0xba6350: mov             x1, x2
    // 0xba6354: r0 = GDT[cid_x0 + -0x1]()
    //     0xba6354: sub             lr, x0, #1
    //     0xba6358: ldr             lr, [x21, lr, lsl #3]
    //     0xba635c: blr             lr
    // 0xba6360: mov             x2, x0
    // 0xba6364: r0 = BoxInt64Instr(r2)
    //     0xba6364: sbfiz           x0, x2, #1, #0x1f
    //     0xba6368: cmp             x2, x0, asr #1
    //     0xba636c: b.eq            #0xba6378
    //     0xba6370: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba6374: stur            x2, [x0, #7]
    // 0xba6378: ldur            x2, [fp, #-8]
    // 0xba637c: StoreField: r2->field_7f = r0
    //     0xba637c: stur            w0, [x2, #0x7f]
    //     0xba6380: tbz             w0, #0, #0xba639c
    //     0xba6384: ldurb           w16, [x2, #-1]
    //     0xba6388: ldurb           w17, [x0, #-1]
    //     0xba638c: and             x16, x17, x16, lsr #2
    //     0xba6390: tst             x16, HEAP, lsr #32
    //     0xba6394: b.eq            #0xba639c
    //     0xba6398: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba639c: r0 = 0.000000
    //     0xba639c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xba63a0: StoreField: r2->field_9b = r0
    //     0xba63a0: stur            w0, [x2, #0x9b]
    // 0xba63a4: StoreField: r2->field_9f = r0
    //     0xba63a4: stur            w0, [x2, #0x9f]
    // 0xba63a8: r0 = Instance__DragState
    //     0xba63a8: add             x0, PP, #0xac, lsl #12  ; [pp+0xacb30] Obj!_DragState@12c5b21
    //     0xba63ac: ldr             x0, [x0, #0xb30]
    // 0xba63b0: StoreField: r2->field_8b = r0
    //     0xba63b0: stur            w0, [x2, #0x8b]
    // 0xba63b4: ldur            x3, [fp, #-0x10]
    // 0xba63b8: r0 = LoadClassIdInstr(r3)
    //     0xba63b8: ldur            x0, [x3, #-1]
    //     0xba63bc: ubfx            x0, x0, #0xc, #0x14
    // 0xba63c0: mov             x1, x3
    // 0xba63c4: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba63c4: mov             x17, #0x3f27
    //     0xba63c8: movk            x17, #1, lsl #16
    //     0xba63cc: add             lr, x0, x17
    //     0xba63d0: ldr             lr, [x21, lr, lsl #3]
    //     0xba63d4: blr             lr
    // 0xba63d8: mov             x2, x0
    // 0xba63dc: ldur            x1, [fp, #-0x10]
    // 0xba63e0: stur            x2, [fp, #-0x20]
    // 0xba63e4: r0 = LoadClassIdInstr(r1)
    //     0xba63e4: ldur            x0, [x1, #-1]
    //     0xba63e8: ubfx            x0, x0, #0xc, #0x14
    // 0xba63ec: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xba63ec: mov             x17, #0x54ea
    //     0xba63f0: movk            x17, #1, lsl #16
    //     0xba63f4: add             lr, x0, x17
    //     0xba63f8: ldr             lr, [x21, lr, lsl #3]
    //     0xba63fc: blr             lr
    // 0xba6400: stur            x0, [fp, #-0x10]
    // 0xba6404: r0 = OffsetPair()
    //     0xba6404: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xba6408: mov             x1, x0
    // 0xba640c: ldur            x0, [fp, #-0x10]
    // 0xba6410: StoreField: r1->field_7 = r0
    //     0xba6410: stur            w0, [x1, #7]
    // 0xba6414: ldur            x0, [fp, #-0x20]
    // 0xba6418: StoreField: r1->field_b = r0
    //     0xba6418: stur            w0, [x1, #0xb]
    // 0xba641c: mov             x0, x1
    // 0xba6420: ldur            x3, [fp, #-8]
    // 0xba6424: StoreField: r3->field_93 = r0
    //     0xba6424: stur            w0, [x3, #0x93]
    //     0xba6428: ldurb           w16, [x3, #-1]
    //     0xba642c: ldurb           w17, [x0, #-1]
    //     0xba6430: and             x16, x17, x16, lsr #2
    //     0xba6434: tst             x16, HEAP, lsr #32
    //     0xba6438: b.eq            #0xba6440
    //     0xba643c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba6440: mov             x0, x1
    // 0xba6444: StoreField: r3->field_97 = r0
    //     0xba6444: stur            w0, [x3, #0x97]
    //     0xba6448: ldurb           w16, [x3, #-1]
    //     0xba644c: ldurb           w17, [x0, #-1]
    //     0xba6450: and             x16, x17, x16, lsr #2
    //     0xba6454: tst             x16, HEAP, lsr #32
    //     0xba6458: b.eq            #0xba6460
    //     0xba645c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba6460: ldur            x2, [fp, #-0x18]
    // 0xba6464: r1 = Function '<anonymous closure>':.
    //     0xba6464: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb98] AnonymousClosure: (0xba6b6c), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::addAllowedPointer (0xba62e4)
    //     0xba6468: ldr             x1, [x1, #0xb98]
    // 0xba646c: r0 = AllocateClosure()
    //     0xba646c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba6470: mov             x3, x0
    // 0xba6474: r1 = Null
    //     0xba6474: mov             x1, NULL
    // 0xba6478: r2 = Instance_Duration
    //     0xba6478: ldr             x2, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xba647c: r0 = Timer()
    //     0xba647c: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xba6480: ldur            x1, [fp, #-8]
    // 0xba6484: StoreField: r1->field_83 = r0
    //     0xba6484: stur            w0, [x1, #0x83]
    //     0xba6488: ldurb           w16, [x1, #-1]
    //     0xba648c: ldurb           w17, [x0, #-1]
    //     0xba6490: and             x16, x17, x16, lsr #2
    //     0xba6494: tst             x16, HEAP, lsr #32
    //     0xba6498: b.eq            #0xba64a0
    //     0xba649c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba64a0: r0 = Null
    //     0xba64a0: mov             x0, NULL
    // 0xba64a4: LeaveFrame
    //     0xba64a4: mov             SP, fp
    //     0xba64a8: ldp             fp, lr, [SP], #0x10
    // 0xba64ac: ret
    //     0xba64ac: ret             
    // 0xba64b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba64b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba64b4: b               #0xba6304
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba6b6c, size: 0x48
    // 0xba6b6c: EnterFrame
    //     0xba6b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xba6b70: mov             fp, SP
    // 0xba6b74: ldr             x0, [fp, #0x10]
    // 0xba6b78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba6b78: ldur            w1, [x0, #0x17]
    // 0xba6b7c: DecompressPointer r1
    //     0xba6b7c: add             x1, x1, HEAP, lsl #32
    // 0xba6b80: CheckStackOverflow
    //     0xba6b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba6b84: cmp             SP, x16
    //     0xba6b88: b.ls            #0xba6bac
    // 0xba6b8c: LoadField: r0 = r1->field_f
    //     0xba6b8c: ldur            w0, [x1, #0xf]
    // 0xba6b90: DecompressPointer r0
    //     0xba6b90: add             x0, x0, HEAP, lsl #32
    // 0xba6b94: mov             x1, x0
    // 0xba6b98: r0 = _didExceedDeadline()
    //     0xba6b98: bl              #0xba6bb4  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_didExceedDeadline
    // 0xba6b9c: r0 = Null
    //     0xba6b9c: mov             x0, NULL
    // 0xba6ba0: LeaveFrame
    //     0xba6ba0: mov             SP, fp
    //     0xba6ba4: ldp             fp, lr, [SP], #0x10
    // 0xba6ba8: ret
    //     0xba6ba8: ret             
    // 0xba6bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6bac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6bb0: b               #0xba6b8c
  }
  _ _didExceedDeadline(/* No info */) {
    // ** addr: 0xba6bb4, size: 0x6c
    // 0xba6bb4: EnterFrame
    //     0xba6bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xba6bb8: mov             fp, SP
    // 0xba6bbc: AllocStack(0x8)
    //     0xba6bbc: sub             SP, SP, #8
    // 0xba6bc0: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xba6bc0: mov             x0, x1
    //     0xba6bc4: stur            x1, [fp, #-8]
    // 0xba6bc8: CheckStackOverflow
    //     0xba6bc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba6bcc: cmp             SP, x16
    //     0xba6bd0: b.ls            #0xba6c18
    // 0xba6bd4: LoadField: r2 = r0->field_23
    //     0xba6bd4: ldur            w2, [x0, #0x23]
    // 0xba6bd8: DecompressPointer r2
    //     0xba6bd8: add             x2, x2, HEAP, lsl #32
    // 0xba6bdc: cmp             w2, NULL
    // 0xba6be0: b.eq            #0xba6c08
    // 0xba6be4: mov             x1, x0
    // 0xba6be8: r0 = _checkTapDown()
    //     0xba6be8: bl              #0xba6c20  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapDown
    // 0xba6bec: ldur            x1, [fp, #-8]
    // 0xba6bf0: LoadField: r0 = r1->field_2b
    //     0xba6bf0: ldur            x0, [x1, #0x2b]
    // 0xba6bf4: cmp             x0, #1
    // 0xba6bf8: b.le            #0xba6c08
    // 0xba6bfc: r2 = Instance_GestureDisposition
    //     0xba6bfc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xba6c00: ldr             x2, [x2, #0x628]
    // 0xba6c04: r0 = resolve()
    //     0xba6c04: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba6c08: r0 = Null
    //     0xba6c08: mov             x0, NULL
    // 0xba6c0c: LeaveFrame
    //     0xba6c0c: mov             SP, fp
    //     0xba6c10: ldp             fp, lr, [SP], #0x10
    // 0xba6c14: ret
    //     0xba6c14: ret             
    // 0xba6c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6c1c: b               #0xba6bd4
  }
  _ _checkTapDown(/* No info */) {
    // ** addr: 0xba6c20, size: 0x184
    // 0xba6c20: EnterFrame
    //     0xba6c20: stp             fp, lr, [SP, #-0x10]!
    //     0xba6c24: mov             fp, SP
    // 0xba6c28: AllocStack(0x40)
    //     0xba6c28: sub             SP, SP, #0x40
    // 0xba6c2c: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xba6c2c: mov             x0, x1
    //     0xba6c30: stur            x1, [fp, #-8]
    //     0xba6c34: mov             x1, x2
    //     0xba6c38: stur            x2, [fp, #-0x10]
    // 0xba6c3c: CheckStackOverflow
    //     0xba6c3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba6c40: cmp             SP, x16
    //     0xba6c44: b.ls            #0xba6d9c
    // 0xba6c48: r1 = 2
    //     0xba6c48: mov             x1, #2
    // 0xba6c4c: r0 = AllocateContext()
    //     0xba6c4c: bl              #0x13de838  ; AllocateContextStub
    // 0xba6c50: mov             x3, x0
    // 0xba6c54: ldur            x2, [fp, #-8]
    // 0xba6c58: stur            x3, [fp, #-0x18]
    // 0xba6c5c: StoreField: r3->field_f = r2
    //     0xba6c5c: stur            w2, [x3, #0xf]
    // 0xba6c60: LoadField: r0 = r2->field_77
    //     0xba6c60: ldur            w0, [x2, #0x77]
    // 0xba6c64: DecompressPointer r0
    //     0xba6c64: add             x0, x0, HEAP, lsl #32
    // 0xba6c68: tbnz            w0, #4, #0xba6c7c
    // 0xba6c6c: r0 = Null
    //     0xba6c6c: mov             x0, NULL
    // 0xba6c70: LeaveFrame
    //     0xba6c70: mov             SP, fp
    //     0xba6c74: ldp             fp, lr, [SP], #0x10
    // 0xba6c78: ret
    //     0xba6c78: ret             
    // 0xba6c7c: ldur            x4, [fp, #-0x10]
    // 0xba6c80: r0 = LoadClassIdInstr(r4)
    //     0xba6c80: ldur            x0, [x4, #-1]
    //     0xba6c84: ubfx            x0, x0, #0xc, #0x14
    // 0xba6c88: mov             x1, x4
    // 0xba6c8c: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba6c8c: mov             x17, #0x3f27
    //     0xba6c90: movk            x17, #1, lsl #16
    //     0xba6c94: add             lr, x0, x17
    //     0xba6c98: ldr             lr, [x21, lr, lsl #3]
    //     0xba6c9c: blr             lr
    // 0xba6ca0: mov             x3, x0
    // 0xba6ca4: ldur            x2, [fp, #-0x10]
    // 0xba6ca8: stur            x3, [fp, #-0x20]
    // 0xba6cac: r0 = LoadClassIdInstr(r2)
    //     0xba6cac: ldur            x0, [x2, #-1]
    //     0xba6cb0: ubfx            x0, x0, #0xc, #0x14
    // 0xba6cb4: mov             x1, x2
    // 0xba6cb8: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xba6cb8: mov             x17, #0x54ea
    //     0xba6cbc: movk            x17, #1, lsl #16
    //     0xba6cc0: add             lr, x0, x17
    //     0xba6cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xba6cc8: blr             lr
    // 0xba6ccc: ldur            x1, [fp, #-0x10]
    // 0xba6cd0: r0 = LoadClassIdInstr(r1)
    //     0xba6cd0: ldur            x0, [x1, #-1]
    //     0xba6cd4: ubfx            x0, x0, #0xc, #0x14
    // 0xba6cd8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba6cd8: sub             lr, x0, #1
    //     0xba6cdc: ldr             lr, [x21, lr, lsl #3]
    //     0xba6ce0: blr             lr
    // 0xba6ce4: ldur            x1, [fp, #-8]
    // 0xba6ce8: mov             x2, x0
    // 0xba6cec: r0 = getKindForPointer()
    //     0xba6cec: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xba6cf0: mov             x1, x0
    // 0xba6cf4: ldur            x0, [fp, #-8]
    // 0xba6cf8: stur            x1, [fp, #-0x10]
    // 0xba6cfc: LoadField: r2 = r0->field_2b
    //     0xba6cfc: ldur            x2, [x0, #0x2b]
    // 0xba6d00: stur            x2, [fp, #-0x28]
    // 0xba6d04: r0 = TapDragDownDetails()
    //     0xba6d04: bl              #0xba6da4  ; AllocateTapDragDownDetailsStub -> TapDragDownDetails (size=0x18)
    // 0xba6d08: mov             x1, x0
    // 0xba6d0c: ldur            x0, [fp, #-0x20]
    // 0xba6d10: StoreField: r1->field_7 = r0
    //     0xba6d10: stur            w0, [x1, #7]
    // 0xba6d14: ldur            x0, [fp, #-0x10]
    // 0xba6d18: StoreField: r1->field_b = r0
    //     0xba6d18: stur            w0, [x1, #0xb]
    // 0xba6d1c: ldur            x0, [fp, #-0x28]
    // 0xba6d20: StoreField: r1->field_f = r0
    //     0xba6d20: stur            x0, [x1, #0xf]
    // 0xba6d24: mov             x0, x1
    // 0xba6d28: ldur            x2, [fp, #-0x18]
    // 0xba6d2c: StoreField: r2->field_13 = r0
    //     0xba6d2c: stur            w0, [x2, #0x13]
    //     0xba6d30: ldurb           w16, [x2, #-1]
    //     0xba6d34: ldurb           w17, [x0, #-1]
    //     0xba6d38: and             x16, x17, x16, lsr #2
    //     0xba6d3c: tst             x16, HEAP, lsr #32
    //     0xba6d40: b.eq            #0xba6d48
    //     0xba6d44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xba6d48: ldur            x0, [fp, #-8]
    // 0xba6d4c: LoadField: r1 = r0->field_5b
    //     0xba6d4c: ldur            w1, [x0, #0x5b]
    // 0xba6d50: DecompressPointer r1
    //     0xba6d50: add             x1, x1, HEAP, lsl #32
    // 0xba6d54: cmp             w1, NULL
    // 0xba6d58: b.eq            #0xba6d80
    // 0xba6d5c: r1 = Function '<anonymous closure>':.
    //     0xba6d5c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb90] AnonymousClosure: (0xba6db0), in [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapDown (0xba6c20)
    //     0xba6d60: ldr             x1, [x1, #0xb90]
    // 0xba6d64: r0 = AllocateClosure()
    //     0xba6d64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba6d68: r16 = <void?>
    //     0xba6d68: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba6d6c: ldur            lr, [fp, #-8]
    // 0xba6d70: stp             lr, x16, [SP, #8]
    // 0xba6d74: str             x0, [SP]
    // 0xba6d78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba6d78: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba6d7c: r0 = invokeCallback()
    //     0xba6d7c: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba6d80: ldur            x1, [fp, #-8]
    // 0xba6d84: r2 = true
    //     0xba6d84: add             x2, NULL, #0x20  ; true
    // 0xba6d88: StoreField: r1->field_77 = r2
    //     0xba6d88: stur            w2, [x1, #0x77]
    // 0xba6d8c: r0 = Null
    //     0xba6d8c: mov             x0, NULL
    // 0xba6d90: LeaveFrame
    //     0xba6d90: mov             SP, fp
    //     0xba6d94: ldp             fp, lr, [SP], #0x10
    // 0xba6d98: ret
    //     0xba6d98: ret             
    // 0xba6d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6d9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6da0: b               #0xba6c48
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba6db0, size: 0x6c
    // 0xba6db0: EnterFrame
    //     0xba6db0: stp             fp, lr, [SP, #-0x10]!
    //     0xba6db4: mov             fp, SP
    // 0xba6db8: ldr             x0, [fp, #0x10]
    // 0xba6dbc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba6dbc: ldur            w1, [x0, #0x17]
    // 0xba6dc0: DecompressPointer r1
    //     0xba6dc0: add             x1, x1, HEAP, lsl #32
    // 0xba6dc4: CheckStackOverflow
    //     0xba6dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba6dc8: cmp             SP, x16
    //     0xba6dcc: b.ls            #0xba6e10
    // 0xba6dd0: LoadField: r0 = r1->field_f
    //     0xba6dd0: ldur            w0, [x1, #0xf]
    // 0xba6dd4: DecompressPointer r0
    //     0xba6dd4: add             x0, x0, HEAP, lsl #32
    // 0xba6dd8: LoadField: r2 = r0->field_5b
    //     0xba6dd8: ldur            w2, [x0, #0x5b]
    // 0xba6ddc: DecompressPointer r2
    //     0xba6ddc: add             x2, x2, HEAP, lsl #32
    // 0xba6de0: cmp             w2, NULL
    // 0xba6de4: b.eq            #0xba6e18
    // 0xba6de8: LoadField: r0 = r1->field_13
    //     0xba6de8: ldur            w0, [x1, #0x13]
    // 0xba6dec: DecompressPointer r0
    //     0xba6dec: add             x0, x0, HEAP, lsl #32
    // 0xba6df0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xba6df0: ldur            w1, [x2, #0x17]
    // 0xba6df4: DecompressPointer r1
    //     0xba6df4: add             x1, x1, HEAP, lsl #32
    // 0xba6df8: mov             x2, x0
    // 0xba6dfc: r0 = _handleTapDown()
    //     0xba6dfc: bl              #0xba6e58  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_handleTapDown
    // 0xba6e00: r0 = Null
    //     0xba6e00: mov             x0, NULL
    // 0xba6e04: LeaveFrame
    //     0xba6e04: mov             SP, fp
    //     0xba6e08: ldp             fp, lr, [SP], #0x10
    // 0xba6e0c: ret
    //     0xba6e0c: ret             
    // 0xba6e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6e10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6e14: b               #0xba6dd0
    // 0xba6e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba6e18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleNonAllowedPointer(/* No info */) {
    // ** addr: 0xbae6b0, size: 0x7c
    // 0xbae6b0: EnterFrame
    //     0xbae6b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbae6b4: mov             fp, SP
    // 0xbae6b8: AllocStack(0x10)
    //     0xbae6b8: sub             SP, SP, #0x10
    // 0xbae6bc: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbae6bc: mov             x3, x1
    //     0xbae6c0: stur            x1, [fp, #-8]
    //     0xbae6c4: stur            x2, [fp, #-0x10]
    // 0xbae6c8: CheckStackOverflow
    //     0xbae6c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbae6cc: cmp             SP, x16
    //     0xbae6d0: b.ls            #0xbae724
    // 0xbae6d4: r0 = LoadClassIdInstr(r2)
    //     0xbae6d4: ldur            x0, [x2, #-1]
    //     0xbae6d8: ubfx            x0, x0, #0xc, #0x14
    // 0xbae6dc: mov             x1, x2
    // 0xbae6e0: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbae6e0: mov             x17, #0x6f9c
    //     0xbae6e4: movk            x17, #1, lsl #16
    //     0xbae6e8: add             lr, x0, x17
    //     0xbae6ec: ldr             lr, [x21, lr, lsl #3]
    //     0xbae6f0: blr             lr
    // 0xbae6f4: cmp             x0, #1
    // 0xbae6f8: b.eq            #0xbae714
    // 0xbae6fc: ldur            x1, [fp, #-8]
    // 0xbae700: LoadField: r0 = r1->field_7b
    //     0xbae700: ldur            w0, [x1, #0x7b]
    // 0xbae704: DecompressPointer r0
    //     0xbae704: add             x0, x0, HEAP, lsl #32
    // 0xbae708: tbz             w0, #4, #0xbae714
    // 0xbae70c: ldur            x2, [fp, #-0x10]
    // 0xbae710: r0 = handleNonAllowedPointer()
    //     0xbae710: bl              #0xbae768  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::handleNonAllowedPointer
    // 0xbae714: r0 = Null
    //     0xbae714: mov             x0, NULL
    // 0xbae718: LeaveFrame
    //     0xbae718: mov             SP, fp
    //     0xbae71c: ldp             fp, lr, [SP], #0x10
    // 0xbae720: ret
    //     0xbae720: ret             
    // 0xbae724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbae724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbae728: b               #0xbae6d4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb162c, size: 0x48
    // 0xbb162c: EnterFrame
    //     0xbb162c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1630: mov             fp, SP
    // 0xbb1634: AllocStack(0x8)
    //     0xbb1634: sub             SP, SP, #8
    // 0xbb1638: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xbb1638: mov             x0, x1
    //     0xbb163c: stur            x1, [fp, #-8]
    // 0xbb1640: CheckStackOverflow
    //     0xbb1640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1644: cmp             SP, x16
    //     0xbb1648: b.ls            #0xbb166c
    // 0xbb164c: mov             x1, x0
    // 0xbb1650: r0 = _stopDeadlineTimer()
    //     0xbb1650: bl              #0xb94fb0  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_stopDeadlineTimer
    // 0xbb1654: ldur            x1, [fp, #-8]
    // 0xbb1658: r0 = dispose()
    //     0xbb1658: bl              #0xbb1674  ; [dart:mixin_deduplication] _MixinApplication499&OneSequenceGestureRecognizer&_TapStatusTrackerMixin::dispose
    // 0xbb165c: r0 = Null
    //     0xbb165c: mov             x0, NULL
    // 0xbb1660: LeaveFrame
    //     0xbb1660: mov             SP, fp
    //     0xbb1664: ldp             fp, lr, [SP], #0x10
    // 0xbb1668: ret
    //     0xbb1668: ret             
    // 0xbb166c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb166c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1670: b               #0xbb164c
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb66f4, size: 0x1b0
    // 0xbb66f4: EnterFrame
    //     0xbb66f4: stp             fp, lr, [SP, #-0x10]!
    //     0xbb66f8: mov             fp, SP
    // 0xbb66fc: AllocStack(0x10)
    //     0xbb66fc: sub             SP, SP, #0x10
    // 0xbb6700: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbb6700: mov             x3, x1
    //     0xbb6704: stur            x1, [fp, #-8]
    //     0xbb6708: stur            x2, [fp, #-0x10]
    // 0xbb670c: CheckStackOverflow
    //     0xbb670c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb6710: cmp             SP, x16
    //     0xbb6714: b.ls            #0xbb689c
    // 0xbb6718: LoadField: r0 = r3->field_7f
    //     0xbb6718: ldur            w0, [x3, #0x7f]
    // 0xbb671c: DecompressPointer r0
    //     0xbb671c: add             x0, x0, HEAP, lsl #32
    // 0xbb6720: cmp             w0, NULL
    // 0xbb6724: b.ne            #0xbb67ec
    // 0xbb6728: r0 = LoadClassIdInstr(r2)
    //     0xbb6728: ldur            x0, [x2, #-1]
    //     0xbb672c: ubfx            x0, x0, #0xc, #0x14
    // 0xbb6730: mov             x1, x2
    // 0xbb6734: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbb6734: mov             x17, #0x6f9c
    //     0xbb6738: movk            x17, #1, lsl #16
    //     0xbb673c: add             lr, x0, x17
    //     0xbb6740: ldr             lr, [x21, lr, lsl #3]
    //     0xbb6744: blr             lr
    // 0xbb6748: mov             x2, x0
    // 0xbb674c: r0 = BoxInt64Instr(r2)
    //     0xbb674c: sbfiz           x0, x2, #1, #0x1f
    //     0xbb6750: cmp             x2, x0, asr #1
    //     0xbb6754: b.eq            #0xbb6760
    //     0xbb6758: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb675c: stur            x2, [x0, #7]
    // 0xbb6760: cmp             w0, #2
    // 0xbb6764: b.ne            #0xbb67dc
    // 0xbb6768: ldur            x2, [fp, #-8]
    // 0xbb676c: LoadField: r0 = r2->field_5b
    //     0xbb676c: ldur            w0, [x2, #0x5b]
    // 0xbb6770: DecompressPointer r0
    //     0xbb6770: add             x0, x0, HEAP, lsl #32
    // 0xbb6774: cmp             w0, NULL
    // 0xbb6778: b.ne            #0xbb6884
    // 0xbb677c: LoadField: r0 = r2->field_63
    //     0xbb677c: ldur            w0, [x2, #0x63]
    // 0xbb6780: DecompressPointer r0
    //     0xbb6780: add             x0, x0, HEAP, lsl #32
    // 0xbb6784: cmp             w0, NULL
    // 0xbb6788: b.ne            #0xbb6884
    // 0xbb678c: LoadField: r0 = r2->field_67
    //     0xbb678c: ldur            w0, [x2, #0x67]
    // 0xbb6790: DecompressPointer r0
    //     0xbb6790: add             x0, x0, HEAP, lsl #32
    // 0xbb6794: cmp             w0, NULL
    // 0xbb6798: b.ne            #0xbb6884
    // 0xbb679c: LoadField: r0 = r2->field_6b
    //     0xbb679c: ldur            w0, [x2, #0x6b]
    // 0xbb67a0: DecompressPointer r0
    //     0xbb67a0: add             x0, x0, HEAP, lsl #32
    // 0xbb67a4: cmp             w0, NULL
    // 0xbb67a8: b.ne            #0xbb6884
    // 0xbb67ac: LoadField: r0 = r2->field_5f
    //     0xbb67ac: ldur            w0, [x2, #0x5f]
    // 0xbb67b0: DecompressPointer r0
    //     0xbb67b0: add             x0, x0, HEAP, lsl #32
    // 0xbb67b4: cmp             w0, NULL
    // 0xbb67b8: b.ne            #0xbb6884
    // 0xbb67bc: LoadField: r0 = r2->field_6f
    //     0xbb67bc: ldur            w0, [x2, #0x6f]
    // 0xbb67c0: DecompressPointer r0
    //     0xbb67c0: add             x0, x0, HEAP, lsl #32
    // 0xbb67c4: cmp             w0, NULL
    // 0xbb67c8: b.ne            #0xbb6884
    // 0xbb67cc: r0 = false
    //     0xbb67cc: add             x0, NULL, #0x30  ; false
    // 0xbb67d0: LeaveFrame
    //     0xbb67d0: mov             SP, fp
    //     0xbb67d4: ldp             fp, lr, [SP], #0x10
    // 0xbb67d8: ret
    //     0xbb67d8: ret             
    // 0xbb67dc: r0 = false
    //     0xbb67dc: add             x0, NULL, #0x30  ; false
    // 0xbb67e0: LeaveFrame
    //     0xbb67e0: mov             SP, fp
    //     0xbb67e4: ldp             fp, lr, [SP], #0x10
    // 0xbb67e8: ret
    //     0xbb67e8: ret             
    // 0xbb67ec: mov             x16, x2
    // 0xbb67f0: mov             x2, x3
    // 0xbb67f4: mov             x3, x16
    // 0xbb67f8: r0 = LoadClassIdInstr(r3)
    //     0xbb67f8: ldur            x0, [x3, #-1]
    //     0xbb67fc: ubfx            x0, x0, #0xc, #0x14
    // 0xbb6800: mov             x1, x3
    // 0xbb6804: r0 = GDT[cid_x0 + -0x1]()
    //     0xbb6804: sub             lr, x0, #1
    //     0xbb6808: ldr             lr, [x21, lr, lsl #3]
    //     0xbb680c: blr             lr
    // 0xbb6810: mov             x3, x0
    // 0xbb6814: ldur            x2, [fp, #-8]
    // 0xbb6818: LoadField: r4 = r2->field_7f
    //     0xbb6818: ldur            w4, [x2, #0x7f]
    // 0xbb681c: DecompressPointer r4
    //     0xbb681c: add             x4, x4, HEAP, lsl #32
    // 0xbb6820: r0 = BoxInt64Instr(r3)
    //     0xbb6820: sbfiz           x0, x3, #1, #0x1f
    //     0xbb6824: cmp             x3, x0, asr #1
    //     0xbb6828: b.eq            #0xbb6834
    //     0xbb682c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb6830: stur            x3, [x0, #7]
    // 0xbb6834: cmp             w0, w4
    // 0xbb6838: b.eq            #0xbb6884
    // 0xbb683c: and             w16, w0, w4
    // 0xbb6840: branchIfSmi(r16, 0xbb6874)
    //     0xbb6840: tbz             w16, #0, #0xbb6874
    // 0xbb6844: r16 = LoadClassIdInstr(r0)
    //     0xbb6844: ldur            x16, [x0, #-1]
    //     0xbb6848: ubfx            x16, x16, #0xc, #0x14
    // 0xbb684c: cmp             x16, #0x3d
    // 0xbb6850: b.ne            #0xbb6874
    // 0xbb6854: r16 = LoadClassIdInstr(r4)
    //     0xbb6854: ldur            x16, [x4, #-1]
    //     0xbb6858: ubfx            x16, x16, #0xc, #0x14
    // 0xbb685c: cmp             x16, #0x3d
    // 0xbb6860: b.ne            #0xbb6874
    // 0xbb6864: LoadField: r16 = r0->field_7
    //     0xbb6864: ldur            x16, [x0, #7]
    // 0xbb6868: LoadField: r17 = r4->field_7
    //     0xbb6868: ldur            x17, [x4, #7]
    // 0xbb686c: cmp             x16, x17
    // 0xbb6870: b.eq            #0xbb6884
    // 0xbb6874: r0 = false
    //     0xbb6874: add             x0, NULL, #0x30  ; false
    // 0xbb6878: LeaveFrame
    //     0xbb6878: mov             SP, fp
    //     0xbb687c: ldp             fp, lr, [SP], #0x10
    // 0xbb6880: ret
    //     0xbb6880: ret             
    // 0xbb6884: mov             x1, x2
    // 0xbb6888: ldur            x2, [fp, #-0x10]
    // 0xbb688c: r0 = isPointerAllowed()
    //     0xbb688c: bl              #0xbb75f8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xbb6890: LeaveFrame
    //     0xbb6890: mov             SP, fp
    //     0xbb6894: ldp             fp, lr, [SP], #0x10
    // 0xbb6898: ret
    //     0xbb6898: ret             
    // 0xbb689c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb689c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb68a0: b               #0xbb6718
  }
  _ BaseTapAndDragGestureRecognizer(/* No info */) {
    // ** addr: 0xe1001c, size: 0xe8
    // 0xe1001c: EnterFrame
    //     0xe1001c: stp             fp, lr, [SP, #-0x10]!
    //     0xe10020: mov             fp, SP
    // 0xe10024: AllocStack(0x18)
    //     0xe10024: sub             SP, SP, #0x18
    // 0xe10028: r3 = false
    //     0xe10028: add             x3, NULL, #0x30  ; false
    // 0xe1002c: r2 = Instance__DragState
    //     0xe1002c: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3e58] Obj!_DragState@12c5ae1
    //     0xe10030: ldr             x2, [x2, #0xe58]
    // 0xe10034: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xe10038: mov             x4, x1
    // 0xe1003c: stur            x1, [fp, #-8]
    // 0xe10040: CheckStackOverflow
    //     0xe10040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe10044: cmp             SP, x16
    //     0xe10048: b.ls            #0xe100fc
    // 0xe1004c: StoreField: r4->field_73 = r3
    //     0xe1004c: stur            w3, [x4, #0x73]
    // 0xe10050: StoreField: r4->field_77 = r3
    //     0xe10050: stur            w3, [x4, #0x77]
    // 0xe10054: StoreField: r4->field_7b = r3
    //     0xe10054: stur            w3, [x4, #0x7b]
    // 0xe10058: StoreField: r4->field_8b = r2
    //     0xe10058: stur            w2, [x4, #0x8b]
    // 0xe1005c: StoreField: r4->field_93 = r0
    //     0xe1005c: stur            w0, [x4, #0x93]
    // 0xe10060: StoreField: r4->field_97 = r0
    //     0xe10060: stur            w0, [x4, #0x97]
    // 0xe10064: StoreField: r4->field_9b = r0
    //     0xe10064: stur            w0, [x4, #0x9b]
    // 0xe10068: StoreField: r4->field_9f = r0
    //     0xe10068: stur            w0, [x4, #0x9f]
    // 0xe1006c: r1 = <int>
    //     0xe1006c: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xe10070: r0 = _Set()
    //     0xe10070: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xe10074: mov             x1, x0
    // 0xe10078: r0 = _Uint32List
    //     0xe10078: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xe1007c: StoreField: r1->field_1b = r0
    //     0xe1007c: stur            w0, [x1, #0x1b]
    // 0xe10080: StoreField: r1->field_b = rZR
    //     0xe10080: stur            wzr, [x1, #0xb]
    // 0xe10084: r0 = const []
    //     0xe10084: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xe10088: StoreField: r1->field_f = r0
    //     0xe10088: stur            w0, [x1, #0xf]
    // 0xe1008c: StoreField: r1->field_13 = rZR
    //     0xe1008c: stur            wzr, [x1, #0x13]
    // 0xe10090: ArrayStore: r1[0] = rZR  ; List_4
    //     0xe10090: stur            wzr, [x1, #0x17]
    // 0xe10094: mov             x0, x1
    // 0xe10098: ldur            x1, [fp, #-8]
    // 0xe1009c: StoreField: r1->field_a7 = r0
    //     0xe1009c: stur            w0, [x1, #0xa7]
    //     0xe100a0: ldurb           w16, [x1, #-1]
    //     0xe100a4: ldurb           w17, [x0, #-1]
    //     0xe100a8: and             x16, x17, x16, lsr #2
    //     0xe100ac: tst             x16, HEAP, lsr #32
    //     0xe100b0: b.eq            #0xe100b8
    //     0xe100b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe100b8: r0 = true
    //     0xe100b8: add             x0, NULL, #0x20  ; true
    // 0xe100bc: StoreField: r1->field_57 = r0
    //     0xe100bc: stur            w0, [x1, #0x57]
    // 0xe100c0: r0 = Instance_Duration
    //     0xe100c0: ldr             x0, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xe100c4: StoreField: r1->field_87 = r0
    //     0xe100c4: stur            w0, [x1, #0x87]
    // 0xe100c8: r0 = Instance_DragStartBehavior
    //     0xe100c8: ldr             x0, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xe100cc: StoreField: r1->field_4b = r0
    //     0xe100cc: stur            w0, [x1, #0x4b]
    // 0xe100d0: StoreField: r1->field_2b = rZR
    //     0xe100d0: stur            xzr, [x1, #0x2b]
    // 0xe100d4: r16 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static.
    //     0xe100d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xe100d8: ldr             x16, [x16, #0x578]
    // 0xe100dc: stp             x16, NULL, [SP]
    // 0xe100e0: r4 = const [0, 0x3, 0x2, 0x1, allowedButtonsFilter, 0x2, supportedDevices, 0x1, null]
    //     0xe100e0: add             x4, PP, #0x15, lsl #12  ; [pp+0x15560] List(9) [0, 0x3, 0x2, 0x1, "allowedButtonsFilter", 0x2, "supportedDevices", 0x1, Null]
    //     0xe100e4: ldr             x4, [x4, #0x560]
    // 0xe100e8: r0 = OneSequenceGestureRecognizer()
    //     0xe100e8: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xe100ec: r0 = Null
    //     0xe100ec: mov             x0, NULL
    // 0xe100f0: LeaveFrame
    //     0xe100f0: mov             SP, fp
    //     0xe100f4: ldp             fp, lr, [SP], #0x10
    // 0xe100f8: ret
    //     0xe100f8: ret             
    // 0xe100fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe100fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe10100: b               #0xe1004c
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116cd9c, size: 0xcc
    // 0x116cd9c: EnterFrame
    //     0x116cd9c: stp             fp, lr, [SP, #-0x10]!
    //     0x116cda0: mov             fp, SP
    // 0x116cda4: AllocStack(0x10)
    //     0x116cda4: sub             SP, SP, #0x10
    // 0x116cda8: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x116cda8: mov             x3, x1
    //     0x116cdac: stur            x1, [fp, #-8]
    //     0x116cdb0: stur            x2, [fp, #-0x10]
    // 0x116cdb4: CheckStackOverflow
    //     0x116cdb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116cdb8: cmp             SP, x16
    //     0x116cdbc: b.ls            #0x116ce60
    // 0x116cdc0: LoadField: r4 = r3->field_7f
    //     0x116cdc0: ldur            w4, [x3, #0x7f]
    // 0x116cdc4: DecompressPointer r4
    //     0x116cdc4: add             x4, x4, HEAP, lsl #32
    // 0x116cdc8: r0 = BoxInt64Instr(r2)
    //     0x116cdc8: sbfiz           x0, x2, #1, #0x1f
    //     0x116cdcc: cmp             x2, x0, asr #1
    //     0x116cdd0: b.eq            #0x116cddc
    //     0x116cdd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116cdd8: stur            x2, [x0, #7]
    // 0x116cddc: cmp             w0, w4
    // 0x116cde0: b.eq            #0x116ce2c
    // 0x116cde4: and             w16, w0, w4
    // 0x116cde8: branchIfSmi(r16, 0x116ce1c)
    //     0x116cde8: tbz             w16, #0, #0x116ce1c
    // 0x116cdec: r16 = LoadClassIdInstr(r0)
    //     0x116cdec: ldur            x16, [x0, #-1]
    //     0x116cdf0: ubfx            x16, x16, #0xc, #0x14
    // 0x116cdf4: cmp             x16, #0x3d
    // 0x116cdf8: b.ne            #0x116ce1c
    // 0x116cdfc: r16 = LoadClassIdInstr(r4)
    //     0x116cdfc: ldur            x16, [x4, #-1]
    //     0x116ce00: ubfx            x16, x16, #0xc, #0x14
    // 0x116ce04: cmp             x16, #0x3d
    // 0x116ce08: b.ne            #0x116ce1c
    // 0x116ce0c: LoadField: r16 = r0->field_7
    //     0x116ce0c: ldur            x16, [x0, #7]
    // 0x116ce10: LoadField: r17 = r4->field_7
    //     0x116ce10: ldur            x17, [x4, #7]
    // 0x116ce14: cmp             x16, x17
    // 0x116ce18: b.eq            #0x116ce2c
    // 0x116ce1c: r0 = Null
    //     0x116ce1c: mov             x0, NULL
    // 0x116ce20: LeaveFrame
    //     0x116ce20: mov             SP, fp
    //     0x116ce24: ldp             fp, lr, [SP], #0x10
    // 0x116ce28: ret
    //     0x116ce28: ret             
    // 0x116ce2c: mov             x1, x3
    // 0x116ce30: r0 = _tapTrackerReset()
    //     0x116ce30: bl              #0xb9cccc  ; [dart:mixin_deduplication] _MixinApplication499&OneSequenceGestureRecognizer&_TapStatusTrackerMixin::_tapTrackerReset
    // 0x116ce34: ldur            x1, [fp, #-8]
    // 0x116ce38: r0 = _stopDeadlineTimer()
    //     0x116ce38: bl              #0xb94fb0  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_stopDeadlineTimer
    // 0x116ce3c: ldur            x1, [fp, #-8]
    // 0x116ce40: ldur            x2, [fp, #-0x10]
    // 0x116ce44: r0 = _giveUpPointer()
    //     0x116ce44: bl              #0xb9c20c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_giveUpPointer
    // 0x116ce48: ldur            x1, [fp, #-8]
    // 0x116ce4c: r0 = _resetTaps()
    //     0x116ce4c: bl              #0xb951f4  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_resetTaps
    // 0x116ce50: r0 = Null
    //     0x116ce50: mov             x0, NULL
    // 0x116ce54: LeaveFrame
    //     0x116ce54: mov             SP, fp
    //     0x116ce58: ldp             fp, lr, [SP], #0x10
    // 0x116ce5c: ret
    //     0x116ce5c: ret             
    // 0x116ce60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ce60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ce64: b               #0x116cdc0
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119c214, size: 0x15c
    // 0x119c214: EnterFrame
    //     0x119c214: stp             fp, lr, [SP, #-0x10]!
    //     0x119c218: mov             fp, SP
    // 0x119c21c: AllocStack(0x10)
    //     0x119c21c: sub             SP, SP, #0x10
    // 0x119c220: SetupParameters(BaseTapAndDragGestureRecognizer this /* r1 => r3, fp-0x10 */)
    //     0x119c220: mov             x3, x1
    //     0x119c224: stur            x1, [fp, #-0x10]
    // 0x119c228: CheckStackOverflow
    //     0x119c228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c22c: cmp             SP, x16
    //     0x119c230: b.ls            #0x119c368
    // 0x119c234: LoadField: r4 = r3->field_7f
    //     0x119c234: ldur            w4, [x3, #0x7f]
    // 0x119c238: DecompressPointer r4
    //     0x119c238: add             x4, x4, HEAP, lsl #32
    // 0x119c23c: r0 = BoxInt64Instr(r2)
    //     0x119c23c: sbfiz           x0, x2, #1, #0x1f
    //     0x119c240: cmp             x2, x0, asr #1
    //     0x119c244: b.eq            #0x119c250
    //     0x119c248: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x119c24c: stur            x2, [x0, #7]
    // 0x119c250: stur            x0, [fp, #-8]
    // 0x119c254: cmp             w0, w4
    // 0x119c258: b.eq            #0x119c2a4
    // 0x119c25c: and             w16, w0, w4
    // 0x119c260: branchIfSmi(r16, 0x119c294)
    //     0x119c260: tbz             w16, #0, #0x119c294
    // 0x119c264: r16 = LoadClassIdInstr(r0)
    //     0x119c264: ldur            x16, [x0, #-1]
    //     0x119c268: ubfx            x16, x16, #0xc, #0x14
    // 0x119c26c: cmp             x16, #0x3d
    // 0x119c270: b.ne            #0x119c294
    // 0x119c274: r16 = LoadClassIdInstr(r4)
    //     0x119c274: ldur            x16, [x4, #-1]
    //     0x119c278: ubfx            x16, x16, #0xc, #0x14
    // 0x119c27c: cmp             x16, #0x3d
    // 0x119c280: b.ne            #0x119c294
    // 0x119c284: LoadField: r16 = r0->field_7
    //     0x119c284: ldur            x16, [x0, #7]
    // 0x119c288: LoadField: r17 = r4->field_7
    //     0x119c288: ldur            x17, [x4, #7]
    // 0x119c28c: cmp             x16, x17
    // 0x119c290: b.eq            #0x119c2a4
    // 0x119c294: r0 = Null
    //     0x119c294: mov             x0, NULL
    // 0x119c298: LeaveFrame
    //     0x119c298: mov             SP, fp
    //     0x119c29c: ldp             fp, lr, [SP], #0x10
    // 0x119c2a0: ret
    //     0x119c2a0: ret             
    // 0x119c2a4: mov             x1, x3
    // 0x119c2a8: r0 = _stopDeadlineTimer()
    //     0x119c2a8: bl              #0xb94fb0  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_stopDeadlineTimer
    // 0x119c2ac: ldur            x0, [fp, #-0x10]
    // 0x119c2b0: LoadField: r1 = r0->field_a7
    //     0x119c2b0: ldur            w1, [x0, #0xa7]
    // 0x119c2b4: DecompressPointer r1
    //     0x119c2b4: add             x1, x1, HEAP, lsl #32
    // 0x119c2b8: ldur            x2, [fp, #-8]
    // 0x119c2bc: r0 = add()
    //     0x119c2bc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x119c2c0: ldur            x0, [fp, #-0x10]
    // 0x119c2c4: LoadField: r2 = r0->field_23
    //     0x119c2c4: ldur            w2, [x0, #0x23]
    // 0x119c2c8: DecompressPointer r2
    //     0x119c2c8: add             x2, x2, HEAP, lsl #32
    // 0x119c2cc: cmp             w2, NULL
    // 0x119c2d0: b.eq            #0x119c2dc
    // 0x119c2d4: mov             x1, x0
    // 0x119c2d8: r0 = _checkTapDown()
    //     0x119c2d8: bl              #0xba6c20  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapDown
    // 0x119c2dc: ldur            x0, [fp, #-0x10]
    // 0x119c2e0: r1 = true
    //     0x119c2e0: add             x1, NULL, #0x20  ; true
    // 0x119c2e4: StoreField: r0->field_7b = r1
    //     0x119c2e4: stur            w1, [x0, #0x7b]
    // 0x119c2e8: LoadField: r2 = r0->field_8f
    //     0x119c2e8: ldur            w2, [x0, #0x8f]
    // 0x119c2ec: DecompressPointer r2
    //     0x119c2ec: add             x2, x2, HEAP, lsl #32
    // 0x119c2f0: cmp             w2, NULL
    // 0x119c2f4: b.eq            #0x119c30c
    // 0x119c2f8: LoadField: r1 = r0->field_57
    //     0x119c2f8: ldur            w1, [x0, #0x57]
    // 0x119c2fc: DecompressPointer r1
    //     0x119c2fc: add             x1, x1, HEAP, lsl #32
    // 0x119c300: tbnz            w1, #4, #0x119c30c
    // 0x119c304: mov             x1, x0
    // 0x119c308: r0 = _acceptDrag()
    //     0x119c308: bl              #0xb95b1c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_acceptDrag
    // 0x119c30c: ldur            x0, [fp, #-0x10]
    // 0x119c310: LoadField: r2 = r0->field_8f
    //     0x119c310: ldur            w2, [x0, #0x8f]
    // 0x119c314: DecompressPointer r2
    //     0x119c314: add             x2, x2, HEAP, lsl #32
    // 0x119c318: cmp             w2, NULL
    // 0x119c31c: b.eq            #0x119c340
    // 0x119c320: LoadField: r1 = r0->field_57
    //     0x119c320: ldur            w1, [x0, #0x57]
    // 0x119c324: DecompressPointer r1
    //     0x119c324: add             x1, x1, HEAP, lsl #32
    // 0x119c328: tbz             w1, #4, #0x119c340
    // 0x119c32c: r1 = Instance__DragState
    //     0x119c32c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacb28] Obj!_DragState@12c5b01
    //     0x119c330: ldr             x1, [x1, #0xb28]
    // 0x119c334: StoreField: r0->field_8b = r1
    //     0x119c334: stur            w1, [x0, #0x8b]
    // 0x119c338: mov             x1, x0
    // 0x119c33c: r0 = _acceptDrag()
    //     0x119c33c: bl              #0xb95b1c  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_acceptDrag
    // 0x119c340: ldur            x1, [fp, #-0x10]
    // 0x119c344: LoadField: r2 = r1->field_27
    //     0x119c344: ldur            w2, [x1, #0x27]
    // 0x119c348: DecompressPointer r2
    //     0x119c348: add             x2, x2, HEAP, lsl #32
    // 0x119c34c: cmp             w2, NULL
    // 0x119c350: b.eq            #0x119c358
    // 0x119c354: r0 = _checkTapUp()
    //     0x119c354: bl              #0xb95004  ; [package:flutter/src/gestures/tap_and_drag.dart] BaseTapAndDragGestureRecognizer::_checkTapUp
    // 0x119c358: r0 = Null
    //     0x119c358: mov             x0, NULL
    // 0x119c35c: LeaveFrame
    //     0x119c35c: mov             SP, fp
    //     0x119c360: ldp             fp, lr, [SP], #0x10
    // 0x119c364: ret
    //     0x119c364: ret             
    // 0x119c368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c36c: b               #0x119c234
  }
}

// class id: 4451, size: 0xac, field offset: 0xac
class TapAndHorizontalDragGestureRecognizer extends BaseTapAndDragGestureRecognizer {

  _ _hasSufficientGlobalDistanceToAccept(/* No info */) {
    // ** addr: 0xb9c8f4, size: 0xc0
    // 0xb9c8f4: d0 = 0.000000
    //     0xb9c8f4: eor             v0.16b, v0.16b, v0.16b
    // 0xb9c8f8: LoadField: r3 = r1->field_9b
    //     0xb9c8f8: ldur            w3, [x1, #0x9b]
    // 0xb9c8fc: DecompressPointer r3
    //     0xb9c8fc: add             x3, x3, HEAP, lsl #32
    // 0xb9c900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9c904: cmp             w3, w16
    // 0xb9c908: b.eq            #0xb9c9a0
    // 0xb9c90c: LoadField: d1 = r3->field_7
    //     0xb9c90c: ldur            d1, [x3, #7]
    // 0xb9c910: fcmp            d1, d0
    // 0xb9c914: b.ne            #0xb9c920
    // 0xb9c918: d0 = 0.000000
    //     0xb9c918: eor             v0.16b, v0.16b, v0.16b
    // 0xb9c91c: b               #0xb9c934
    // 0xb9c920: fcmp            d0, d1
    // 0xb9c924: b.le            #0xb9c930
    // 0xb9c928: fneg            d0, d1
    // 0xb9c92c: b               #0xb9c934
    // 0xb9c930: mov             v0.16b, v1.16b
    // 0xb9c934: LoadField: r3 = r1->field_7
    //     0xb9c934: ldur            w3, [x1, #7]
    // 0xb9c938: DecompressPointer r3
    //     0xb9c938: add             x3, x3, HEAP, lsl #32
    // 0xb9c93c: LoadField: r1 = r2->field_7
    //     0xb9c93c: ldur            x1, [x2, #7]
    // 0xb9c940: cmp             x1, #2
    // 0xb9c944: b.gt            #0xb9c960
    // 0xb9c948: cmp             x1, #1
    // 0xb9c94c: b.gt            #0xb9c960
    // 0xb9c950: cmp             x1, #0
    // 0xb9c954: b.le            #0xb9c960
    // 0xb9c958: d1 = 1.000000
    //     0xb9c958: fmov            d1, #1.00000000
    // 0xb9c95c: b               #0xb9c98c
    // 0xb9c960: cmp             w3, NULL
    // 0xb9c964: b.ne            #0xb9c970
    // 0xb9c968: r1 = Null
    //     0xb9c968: mov             x1, NULL
    // 0xb9c96c: b               #0xb9c978
    // 0xb9c970: LoadField: r1 = r3->field_7
    //     0xb9c970: ldur            w1, [x3, #7]
    // 0xb9c974: DecompressPointer r1
    //     0xb9c974: add             x1, x1, HEAP, lsl #32
    // 0xb9c978: cmp             w1, NULL
    // 0xb9c97c: b.ne            #0xb9c988
    // 0xb9c980: d1 = 18.000000
    //     0xb9c980: fmov            d1, #18.00000000
    // 0xb9c984: b               #0xb9c98c
    // 0xb9c988: LoadField: d1 = r1->field_7
    //     0xb9c988: ldur            d1, [x1, #7]
    // 0xb9c98c: fcmp            d0, d1
    // 0xb9c990: r16 = true
    //     0xb9c990: add             x16, NULL, #0x20  ; true
    // 0xb9c994: r17 = false
    //     0xb9c994: add             x17, NULL, #0x30  ; false
    // 0xb9c998: csel            x0, x16, x17, gt
    // 0xb9c99c: ret
    //     0xb9c99c: ret             
    // 0xb9c9a0: EnterFrame
    //     0xb9c9a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c9a4: mov             fp, SP
    // 0xb9c9a8: r9 = _globalDistanceMoved
    //     0xb9c9a8: add             x9, PP, #0xac, lsl #12  ; [pp+0xacb50] Field <BaseTapAndDragGestureRecognizer._globalDistanceMoved@307288344>: late (offset: 0x9c)
    //     0xb9c9ac: ldr             x9, [x9, #0xb50]
    // 0xb9c9b0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb9c9b0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
}

// class id: 4452, size: 0x24, field offset: 0x24
abstract class _TapStatusTrackerMixin extends OneSequenceGestureRecognizer {
}

// class id: 5213, size: 0x10, field offset: 0x8
class TapDragEndDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5214, size: 0x1c, field offset: 0x8
class TapDragUpdateDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5215, size: 0x18, field offset: 0x8
class TapDragStartDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5216, size: 0x14, field offset: 0x8
class TapDragUpDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5217, size: 0x18, field offset: 0x8
class TapDragDownDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 8304, size: 0x14, field offset: 0x14
enum _DragState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9be4, size: 0x64
    // 0x11a9be4: EnterFrame
    //     0x11a9be4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9be8: mov             fp, SP
    // 0x11a9bec: AllocStack(0x10)
    //     0x11a9bec: sub             SP, SP, #0x10
    // 0x11a9bf0: SetupParameters(_DragState this /* r1 => r0, fp-0x8 */)
    //     0x11a9bf0: mov             x0, x1
    //     0x11a9bf4: stur            x1, [fp, #-8]
    // 0x11a9bf8: CheckStackOverflow
    //     0x11a9bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9bfc: cmp             SP, x16
    //     0x11a9c00: b.ls            #0x11a9c40
    // 0x11a9c04: r1 = Null
    //     0x11a9c04: mov             x1, NULL
    // 0x11a9c08: r2 = 4
    //     0x11a9c08: mov             x2, #4
    // 0x11a9c0c: r0 = AllocateArray()
    //     0x11a9c0c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9c10: r16 = "_DragState."
    //     0x11a9c10: add             x16, PP, #0x26, lsl #12  ; [pp+0x26608] "_DragState."
    //     0x11a9c14: ldr             x16, [x16, #0x608]
    // 0x11a9c18: StoreField: r0->field_f = r16
    //     0x11a9c18: stur            w16, [x0, #0xf]
    // 0x11a9c1c: ldur            x1, [fp, #-8]
    // 0x11a9c20: LoadField: r2 = r1->field_f
    //     0x11a9c20: ldur            w2, [x1, #0xf]
    // 0x11a9c24: DecompressPointer r2
    //     0x11a9c24: add             x2, x2, HEAP, lsl #32
    // 0x11a9c28: StoreField: r0->field_13 = r2
    //     0x11a9c28: stur            w2, [x0, #0x13]
    // 0x11a9c2c: str             x0, [SP]
    // 0x11a9c30: r0 = _interpolate()
    //     0x11a9c30: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9c34: LeaveFrame
    //     0x11a9c34: mov             SP, fp
    //     0x11a9c38: ldp             fp, lr, [SP], #0x10
    // 0x11a9c3c: ret
    //     0x11a9c3c: ret             
    // 0x11a9c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9c44: b               #0x11a9c04
  }
}
