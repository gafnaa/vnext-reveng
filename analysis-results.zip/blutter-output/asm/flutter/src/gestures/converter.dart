// lib: , url: package:flutter/src/gestures/converter.dart

// class id: 1048817, size: 0x8
class :: {
}

// class id: 3177, size: 0x8, field offset: 0x8
abstract class PointerEventConverter extends Object {

  static _ expand(/* No info */) {
    // ** addr: 0x85185c, size: 0x9c
    // 0x85185c: EnterFrame
    //     0x85185c: stp             fp, lr, [SP, #-0x10]!
    //     0x851860: mov             fp, SP
    // 0x851864: AllocStack(0x30)
    //     0x851864: sub             SP, SP, #0x30
    // 0x851868: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x851868: stur            x1, [fp, #-8]
    //     0x85186c: stur            x2, [fp, #-0x10]
    // 0x851870: CheckStackOverflow
    //     0x851870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851874: cmp             SP, x16
    //     0x851878: b.ls            #0x8518f0
    // 0x85187c: r1 = 1
    //     0x85187c: mov             x1, #1
    // 0x851880: r0 = AllocateContext()
    //     0x851880: bl              #0x13de838  ; AllocateContextStub
    // 0x851884: mov             x3, x0
    // 0x851888: ldur            x0, [fp, #-0x10]
    // 0x85188c: stur            x3, [fp, #-0x18]
    // 0x851890: StoreField: r3->field_f = r0
    //     0x851890: stur            w0, [x3, #0xf]
    // 0x851894: r1 = Function '<anonymous closure>': static.
    //     0x851894: ldr             x1, [PP, #0x4360]  ; [pp+0x4360] AnonymousClosure: static (0x852d88), in [package:flutter/src/gestures/converter.dart] PointerEventConverter::expand (0x85185c)
    // 0x851898: r2 = Null
    //     0x851898: mov             x2, NULL
    // 0x85189c: r0 = AllocateClosure()
    //     0x85189c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8518a0: ldur            x1, [fp, #-8]
    // 0x8518a4: mov             x2, x0
    // 0x8518a8: r0 = where()
    //     0x8518a8: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8518ac: ldur            x2, [fp, #-0x18]
    // 0x8518b0: r1 = Function '<anonymous closure>': static.
    //     0x8518b0: ldr             x1, [PP, #0x4368]  ; [pp+0x4368] AnonymousClosure: static (0x8518f8), in [package:flutter/src/gestures/converter.dart] PointerEventConverter::expand (0x85185c)
    // 0x8518b4: stur            x0, [fp, #-8]
    // 0x8518b8: r0 = AllocateClosure()
    //     0x8518b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8518bc: r16 = <PointerEvent?>
    //     0x8518bc: ldr             x16, [PP, #0x4370]  ; [pp+0x4370] TypeArguments: <PointerEvent?>
    // 0x8518c0: ldur            lr, [fp, #-8]
    // 0x8518c4: stp             lr, x16, [SP, #8]
    // 0x8518c8: str             x0, [SP]
    // 0x8518cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8518cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8518d0: r0 = map()
    //     0x8518d0: bl              #0xb00654  ; [dart:_internal] WhereIterable::map
    // 0x8518d4: r16 = <PointerEvent>
    //     0x8518d4: ldr             x16, [PP, #0x1848]  ; [pp+0x1848] TypeArguments: <PointerEvent>
    // 0x8518d8: stp             x0, x16, [SP]
    // 0x8518dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8518dc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8518e0: r0 = whereType()
    //     0x8518e0: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x8518e4: LeaveFrame
    //     0x8518e4: mov             SP, fp
    //     0x8518e8: ldp             fp, lr, [SP], #0x10
    // 0x8518ec: ret
    //     0x8518ec: ret             
    // 0x8518f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8518f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8518f4: b               #0x85187c
  }
  [closure] static _PointerEventDescription? <anonymous closure>(dynamic, PointerData) {
    // ** addr: 0x8518f8, size: 0x11b0
    // 0x8518f8: EnterFrame
    //     0x8518f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8518fc: mov             fp, SP
    // 0x851900: AllocStack(0xd8)
    //     0x851900: sub             SP, SP, #0xd8
    // 0x851904: SetupParameters([dynamic _ /* r0 */])
    //     0x851904: ldr             x0, [fp, #0x18]
    //     0x851908: ldur            w1, [x0, #0x17]
    //     0x85190c: add             x1, x1, HEAP, lsl #32
    // 0x851910: CheckStackOverflow
    //     0x851910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851914: cmp             SP, x16
    //     0x851918: b.ls            #0x852aa0
    // 0x85191c: LoadField: r0 = r1->field_f
    //     0x85191c: ldur            w0, [x1, #0xf]
    // 0x851920: DecompressPointer r0
    //     0x851920: add             x0, x0, HEAP, lsl #32
    // 0x851924: ldr             x3, [fp, #0x10]
    // 0x851928: LoadField: r4 = r3->field_7
    //     0x851928: ldur            x4, [x3, #7]
    // 0x85192c: stur            x4, [fp, #-8]
    // 0x851930: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x851930: ldur            w2, [x0, #0x17]
    // 0x851934: DecompressPointer r2
    //     0x851934: add             x2, x2, HEAP, lsl #32
    // 0x851938: r0 = BoxInt64Instr(r4)
    //     0x851938: sbfiz           x0, x4, #1, #0x1f
    //     0x85193c: cmp             x4, x0, asr #1
    //     0x851940: b.eq            #0x85194c
    //     0x851944: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x851948: stur            x4, [x0, #7]
    // 0x85194c: mov             x1, x2
    // 0x851950: mov             x2, x0
    // 0x851954: r0 = _devicePixelRatioForView()
    //     0x851954: bl              #0x852b88  ; [dart:mixin_deduplication] _MixinApplication202&BindingBase&GestureBinding::_devicePixelRatioForView
    // 0x851958: stur            x0, [fp, #-0x10]
    // 0x85195c: cmp             w0, NULL
    // 0x851960: b.ne            #0x851974
    // 0x851964: r0 = Null
    //     0x851964: mov             x0, NULL
    // 0x851968: LeaveFrame
    //     0x851968: mov             SP, fp
    //     0x85196c: ldp             fp, lr, [SP], #0x10
    // 0x851970: ret
    //     0x851970: ret             
    // 0x851974: ldr             x2, [fp, #0x10]
    // 0x851978: LoadField: d0 = r2->field_37
    //     0x851978: ldur            d0, [x2, #0x37]
    // 0x85197c: stur            d0, [fp, #-0x80]
    // 0x851980: LoadField: d1 = r2->field_3f
    //     0x851980: ldur            d1, [x2, #0x3f]
    // 0x851984: stur            d1, [fp, #-0x78]
    // 0x851988: r0 = Offset()
    //     0x851988: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85198c: ldur            d0, [fp, #-0x80]
    // 0x851990: StoreField: r0->field_7 = d0
    //     0x851990: stur            d0, [x0, #7]
    // 0x851994: ldur            d0, [fp, #-0x78]
    // 0x851998: StoreField: r0->field_f = d0
    //     0x851998: stur            d0, [x0, #0xf]
    // 0x85199c: ldur            x1, [fp, #-0x10]
    // 0x8519a0: LoadField: d1 = r1->field_7
    //     0x8519a0: ldur            d1, [x1, #7]
    // 0x8519a4: mov             x1, x0
    // 0x8519a8: mov             v0.16b, v1.16b
    // 0x8519ac: stur            d1, [fp, #-0x78]
    // 0x8519b0: r0 = /()
    //     0x8519b0: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x8519b4: ldr             x2, [fp, #0x10]
    // 0x8519b8: stur            x0, [fp, #-0x10]
    // 0x8519bc: LoadField: d0 = r2->field_47
    //     0x8519bc: ldur            d0, [x2, #0x47]
    // 0x8519c0: stur            d0, [fp, #-0x88]
    // 0x8519c4: LoadField: d1 = r2->field_4f
    //     0x8519c4: ldur            d1, [x2, #0x4f]
    // 0x8519c8: stur            d1, [fp, #-0x80]
    // 0x8519cc: r0 = Offset()
    //     0x8519cc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8519d0: ldur            d0, [fp, #-0x88]
    // 0x8519d4: StoreField: r0->field_7 = d0
    //     0x8519d4: stur            d0, [x0, #7]
    // 0x8519d8: ldur            d0, [fp, #-0x80]
    // 0x8519dc: StoreField: r0->field_f = d0
    //     0x8519dc: stur            d0, [x0, #0xf]
    // 0x8519e0: mov             x1, x0
    // 0x8519e4: ldur            d0, [fp, #-0x78]
    // 0x8519e8: r0 = /()
    //     0x8519e8: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x8519ec: ldr             x2, [fp, #0x10]
    // 0x8519f0: stur            x0, [fp, #-0x58]
    // 0x8519f4: LoadField: d0 = r2->field_9f
    //     0x8519f4: ldur            d0, [x2, #0x9f]
    // 0x8519f8: ldur            d1, [fp, #-0x78]
    // 0x8519fc: fdiv            d2, d0, d1
    // 0x851a00: stur            d2, [fp, #-0xd0]
    // 0x851a04: LoadField: d0 = r2->field_97
    //     0x851a04: ldur            d0, [x2, #0x97]
    // 0x851a08: fdiv            d3, d0, d1
    // 0x851a0c: stur            d3, [fp, #-0xc8]
    // 0x851a10: LoadField: d0 = r2->field_a7
    //     0x851a10: ldur            d0, [x2, #0xa7]
    // 0x851a14: fdiv            d4, d0, d1
    // 0x851a18: stur            d4, [fp, #-0xc0]
    // 0x851a1c: LoadField: d0 = r2->field_af
    //     0x851a1c: ldur            d0, [x2, #0xaf]
    // 0x851a20: fdiv            d5, d0, d1
    // 0x851a24: stur            d5, [fp, #-0xb8]
    // 0x851a28: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x851a28: ldur            w1, [x2, #0x17]
    // 0x851a2c: DecompressPointer r1
    //     0x851a2c: add             x1, x1, HEAP, lsl #32
    // 0x851a30: stur            x1, [fp, #-0x48]
    // 0x851a34: LoadField: r3 = r2->field_1f
    //     0x851a34: ldur            w3, [x2, #0x1f]
    // 0x851a38: DecompressPointer r3
    //     0x851a38: add             x3, x3, HEAP, lsl #32
    // 0x851a3c: stur            x3, [fp, #-0x40]
    // 0x851a40: LoadField: r4 = r2->field_23
    //     0x851a40: ldur            w4, [x2, #0x23]
    // 0x851a44: DecompressPointer r4
    //     0x851a44: add             x4, x4, HEAP, lsl #32
    // 0x851a48: LoadField: r5 = r4->field_7
    //     0x851a48: ldur            x5, [x4, #7]
    // 0x851a4c: cmp             x5, #2
    // 0x851a50: b.gt            #0x8529a0
    // 0x851a54: cmp             x5, #1
    // 0x851a58: b.gt            #0x8528dc
    // 0x851a5c: cmp             x5, #0
    // 0x851a60: b.gt            #0x852760
    // 0x851a64: LoadField: r4 = r2->field_1b
    //     0x851a64: ldur            w4, [x2, #0x1b]
    // 0x851a68: DecompressPointer r4
    //     0x851a68: add             x4, x4, HEAP, lsl #32
    // 0x851a6c: LoadField: r5 = r4->field_7
    //     0x851a6c: ldur            x5, [x4, #7]
    // 0x851a70: cmp             x5, #4
    // 0x851a74: b.gt            #0x8520ec
    // 0x851a78: cmp             x5, #2
    // 0x851a7c: b.gt            #0x851dfc
    // 0x851a80: cmp             x5, #1
    // 0x851a84: b.gt            #0x851cfc
    // 0x851a88: cmp             x5, #0
    // 0x851a8c: b.gt            #0x851bd0
    // 0x851a90: ldur            x4, [fp, #-8]
    // 0x851a94: ldur            x0, [fp, #-0x10]
    // 0x851a98: LoadField: r5 = r2->field_2f
    //     0x851a98: ldur            x5, [x2, #0x2f]
    // 0x851a9c: stur            x5, [fp, #-0x38]
    // 0x851aa0: LoadField: r6 = r2->field_27
    //     0x851aa0: ldur            x6, [x2, #0x27]
    // 0x851aa4: stur            x6, [fp, #-0x30]
    // 0x851aa8: LoadField: r7 = r2->field_57
    //     0x851aa8: ldur            x7, [x2, #0x57]
    // 0x851aac: stur            x7, [fp, #-0x28]
    // 0x851ab0: LoadField: r8 = r2->field_5f
    //     0x851ab0: ldur            w8, [x2, #0x5f]
    // 0x851ab4: DecompressPointer r8
    //     0x851ab4: add             x8, x8, HEAP, lsl #32
    // 0x851ab8: stur            x8, [fp, #-0x20]
    // 0x851abc: LoadField: d0 = r2->field_6f
    //     0x851abc: ldur            d0, [x2, #0x6f]
    // 0x851ac0: stur            d0, [fp, #-0xb0]
    // 0x851ac4: LoadField: d1 = r2->field_77
    //     0x851ac4: ldur            d1, [x2, #0x77]
    // 0x851ac8: stur            d1, [fp, #-0xa8]
    // 0x851acc: LoadField: d6 = r2->field_7f
    //     0x851acc: ldur            d6, [x2, #0x7f]
    // 0x851ad0: stur            d6, [fp, #-0xa0]
    // 0x851ad4: LoadField: d7 = r2->field_87
    //     0x851ad4: ldur            d7, [x2, #0x87]
    // 0x851ad8: stur            d7, [fp, #-0x98]
    // 0x851adc: LoadField: d8 = r2->field_8f
    //     0x851adc: ldur            d8, [x2, #0x8f]
    // 0x851ae0: stur            d8, [fp, #-0x90]
    // 0x851ae4: LoadField: d9 = r2->field_b7
    //     0x851ae4: ldur            d9, [x2, #0xb7]
    // 0x851ae8: stur            d9, [fp, #-0x88]
    // 0x851aec: LoadField: d10 = r2->field_bf
    //     0x851aec: ldur            d10, [x2, #0xbf]
    // 0x851af0: stur            d10, [fp, #-0x80]
    // 0x851af4: LoadField: r9 = r2->field_f
    //     0x851af4: ldur            x9, [x2, #0xf]
    // 0x851af8: stur            x9, [fp, #-0x18]
    // 0x851afc: r0 = PointerCancelEvent()
    //     0x851afc: bl              #0x852b38  ; AllocatePointerCancelEventStub -> PointerCancelEvent (size=0xbc)
    // 0x851b00: mov             x1, x0
    // 0x851b04: ldur            x0, [fp, #-8]
    // 0x851b08: StoreField: r1->field_7 = r0
    //     0x851b08: stur            x0, [x1, #7]
    // 0x851b0c: ldur            x0, [fp, #-0x18]
    // 0x851b10: StoreField: r1->field_f = r0
    //     0x851b10: stur            x0, [x1, #0xf]
    // 0x851b14: ldur            x3, [fp, #-0x48]
    // 0x851b18: ArrayStore: r1[0] = r3  ; List_4
    //     0x851b18: stur            w3, [x1, #0x17]
    // 0x851b1c: ldur            x0, [fp, #-0x38]
    // 0x851b20: StoreField: r1->field_1b = r0
    //     0x851b20: stur            x0, [x1, #0x1b]
    // 0x851b24: ldur            x4, [fp, #-0x40]
    // 0x851b28: StoreField: r1->field_23 = r4
    //     0x851b28: stur            w4, [x1, #0x23]
    // 0x851b2c: ldur            x0, [fp, #-0x30]
    // 0x851b30: StoreField: r1->field_27 = r0
    //     0x851b30: stur            x0, [x1, #0x27]
    // 0x851b34: ldur            x5, [fp, #-0x10]
    // 0x851b38: StoreField: r1->field_2f = r5
    //     0x851b38: stur            w5, [x1, #0x2f]
    // 0x851b3c: r6 = Instance_Offset
    //     0x851b3c: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851b40: StoreField: r1->field_33 = r6
    //     0x851b40: stur            w6, [x1, #0x33]
    // 0x851b44: ldur            x0, [fp, #-0x28]
    // 0x851b48: StoreField: r1->field_37 = r0
    //     0x851b48: stur            x0, [x1, #0x37]
    // 0x851b4c: r7 = false
    //     0x851b4c: add             x7, NULL, #0x30  ; false
    // 0x851b50: StoreField: r1->field_3f = r7
    //     0x851b50: stur            w7, [x1, #0x3f]
    // 0x851b54: ldur            x0, [fp, #-0x20]
    // 0x851b58: StoreField: r1->field_43 = r0
    //     0x851b58: stur            w0, [x1, #0x43]
    // 0x851b5c: StoreField: r1->field_47 = rZR
    //     0x851b5c: stur            xzr, [x1, #0x47]
    // 0x851b60: ldur            d0, [fp, #-0xb0]
    // 0x851b64: StoreField: r1->field_4f = d0
    //     0x851b64: stur            d0, [x1, #0x4f]
    // 0x851b68: ldur            d0, [fp, #-0xa8]
    // 0x851b6c: StoreField: r1->field_57 = d0
    //     0x851b6c: stur            d0, [x1, #0x57]
    // 0x851b70: ldur            d0, [fp, #-0xa0]
    // 0x851b74: StoreField: r1->field_5f = d0
    //     0x851b74: stur            d0, [x1, #0x5f]
    // 0x851b78: ldur            d0, [fp, #-0x98]
    // 0x851b7c: StoreField: r1->field_67 = d0
    //     0x851b7c: stur            d0, [x1, #0x67]
    // 0x851b80: ldur            d0, [fp, #-0x90]
    // 0x851b84: StoreField: r1->field_6f = d0
    //     0x851b84: stur            d0, [x1, #0x6f]
    // 0x851b88: ldur            d0, [fp, #-0xc8]
    // 0x851b8c: StoreField: r1->field_77 = d0
    //     0x851b8c: stur            d0, [x1, #0x77]
    // 0x851b90: ldur            d1, [fp, #-0xd0]
    // 0x851b94: StoreField: r1->field_7f = d1
    //     0x851b94: stur            d1, [x1, #0x7f]
    // 0x851b98: ldur            d0, [fp, #-0xc0]
    // 0x851b9c: StoreField: r1->field_87 = d0
    //     0x851b9c: stur            d0, [x1, #0x87]
    // 0x851ba0: ldur            d1, [fp, #-0xb8]
    // 0x851ba4: StoreField: r1->field_8f = d1
    //     0x851ba4: stur            d1, [x1, #0x8f]
    // 0x851ba8: ldur            d0, [fp, #-0x88]
    // 0x851bac: StoreField: r1->field_97 = d0
    //     0x851bac: stur            d0, [x1, #0x97]
    // 0x851bb0: ldur            d0, [fp, #-0x80]
    // 0x851bb4: StoreField: r1->field_9f = d0
    //     0x851bb4: stur            d0, [x1, #0x9f]
    // 0x851bb8: StoreField: r1->field_a7 = rZR
    //     0x851bb8: stur            xzr, [x1, #0xa7]
    // 0x851bbc: StoreField: r1->field_af = r7
    //     0x851bbc: stur            w7, [x1, #0xaf]
    // 0x851bc0: mov             x0, x1
    // 0x851bc4: LeaveFrame
    //     0x851bc4: mov             SP, fp
    //     0x851bc8: ldp             fp, lr, [SP], #0x10
    // 0x851bcc: ret
    //     0x851bcc: ret             
    // 0x851bd0: ldur            x0, [fp, #-8]
    // 0x851bd4: ldur            x5, [fp, #-0x10]
    // 0x851bd8: mov             x4, x3
    // 0x851bdc: mov             x3, x1
    // 0x851be0: mov             v0.16b, v4.16b
    // 0x851be4: mov             v1.16b, v5.16b
    // 0x851be8: r7 = false
    //     0x851be8: add             x7, NULL, #0x30  ; false
    // 0x851bec: r6 = Instance_Offset
    //     0x851bec: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851bf0: LoadField: r1 = r2->field_27
    //     0x851bf0: ldur            x1, [x2, #0x27]
    // 0x851bf4: stur            x1, [fp, #-0x28]
    // 0x851bf8: LoadField: r8 = r2->field_5f
    //     0x851bf8: ldur            w8, [x2, #0x5f]
    // 0x851bfc: DecompressPointer r8
    //     0x851bfc: add             x8, x8, HEAP, lsl #32
    // 0x851c00: stur            x8, [fp, #-0x20]
    // 0x851c04: LoadField: d2 = r2->field_6f
    //     0x851c04: ldur            d2, [x2, #0x6f]
    // 0x851c08: stur            d2, [fp, #-0xa8]
    // 0x851c0c: LoadField: d3 = r2->field_77
    //     0x851c0c: ldur            d3, [x2, #0x77]
    // 0x851c10: stur            d3, [fp, #-0xa0]
    // 0x851c14: LoadField: d4 = r2->field_7f
    //     0x851c14: ldur            d4, [x2, #0x7f]
    // 0x851c18: stur            d4, [fp, #-0x98]
    // 0x851c1c: LoadField: d5 = r2->field_87
    //     0x851c1c: ldur            d5, [x2, #0x87]
    // 0x851c20: stur            d5, [fp, #-0x90]
    // 0x851c24: LoadField: d6 = r2->field_b7
    //     0x851c24: ldur            d6, [x2, #0xb7]
    // 0x851c28: stur            d6, [fp, #-0x88]
    // 0x851c2c: LoadField: d7 = r2->field_bf
    //     0x851c2c: ldur            d7, [x2, #0xbf]
    // 0x851c30: stur            d7, [fp, #-0x80]
    // 0x851c34: LoadField: r9 = r2->field_f
    //     0x851c34: ldur            x9, [x2, #0xf]
    // 0x851c38: stur            x9, [fp, #-0x18]
    // 0x851c3c: r0 = PointerAddedEvent()
    //     0x851c3c: bl              #0x852b2c  ; AllocatePointerAddedEventStub -> PointerAddedEvent (size=0xbc)
    // 0x851c40: mov             x1, x0
    // 0x851c44: ldur            x0, [fp, #-8]
    // 0x851c48: StoreField: r1->field_7 = r0
    //     0x851c48: stur            x0, [x1, #7]
    // 0x851c4c: ldur            x0, [fp, #-0x18]
    // 0x851c50: StoreField: r1->field_f = r0
    //     0x851c50: stur            x0, [x1, #0xf]
    // 0x851c54: ldur            x3, [fp, #-0x48]
    // 0x851c58: ArrayStore: r1[0] = r3  ; List_4
    //     0x851c58: stur            w3, [x1, #0x17]
    // 0x851c5c: StoreField: r1->field_1b = rZR
    //     0x851c5c: stur            xzr, [x1, #0x1b]
    // 0x851c60: ldur            x4, [fp, #-0x40]
    // 0x851c64: StoreField: r1->field_23 = r4
    //     0x851c64: stur            w4, [x1, #0x23]
    // 0x851c68: ldur            x0, [fp, #-0x28]
    // 0x851c6c: StoreField: r1->field_27 = r0
    //     0x851c6c: stur            x0, [x1, #0x27]
    // 0x851c70: ldur            x5, [fp, #-0x10]
    // 0x851c74: StoreField: r1->field_2f = r5
    //     0x851c74: stur            w5, [x1, #0x2f]
    // 0x851c78: r6 = Instance_Offset
    //     0x851c78: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851c7c: StoreField: r1->field_33 = r6
    //     0x851c7c: stur            w6, [x1, #0x33]
    // 0x851c80: StoreField: r1->field_37 = rZR
    //     0x851c80: stur            xzr, [x1, #0x37]
    // 0x851c84: r7 = false
    //     0x851c84: add             x7, NULL, #0x30  ; false
    // 0x851c88: StoreField: r1->field_3f = r7
    //     0x851c88: stur            w7, [x1, #0x3f]
    // 0x851c8c: ldur            x0, [fp, #-0x20]
    // 0x851c90: StoreField: r1->field_43 = r0
    //     0x851c90: stur            w0, [x1, #0x43]
    // 0x851c94: StoreField: r1->field_47 = rZR
    //     0x851c94: stur            xzr, [x1, #0x47]
    // 0x851c98: ldur            d0, [fp, #-0xa8]
    // 0x851c9c: StoreField: r1->field_4f = d0
    //     0x851c9c: stur            d0, [x1, #0x4f]
    // 0x851ca0: ldur            d0, [fp, #-0xa0]
    // 0x851ca4: StoreField: r1->field_57 = d0
    //     0x851ca4: stur            d0, [x1, #0x57]
    // 0x851ca8: ldur            d0, [fp, #-0x98]
    // 0x851cac: StoreField: r1->field_5f = d0
    //     0x851cac: stur            d0, [x1, #0x5f]
    // 0x851cb0: ldur            d0, [fp, #-0x90]
    // 0x851cb4: StoreField: r1->field_67 = d0
    //     0x851cb4: stur            d0, [x1, #0x67]
    // 0x851cb8: StoreField: r1->field_6f = rZR
    //     0x851cb8: stur            xzr, [x1, #0x6f]
    // 0x851cbc: StoreField: r1->field_77 = rZR
    //     0x851cbc: stur            xzr, [x1, #0x77]
    // 0x851cc0: StoreField: r1->field_7f = rZR
    //     0x851cc0: stur            xzr, [x1, #0x7f]
    // 0x851cc4: ldur            d0, [fp, #-0xc0]
    // 0x851cc8: StoreField: r1->field_87 = d0
    //     0x851cc8: stur            d0, [x1, #0x87]
    // 0x851ccc: ldur            d1, [fp, #-0xb8]
    // 0x851cd0: StoreField: r1->field_8f = d1
    //     0x851cd0: stur            d1, [x1, #0x8f]
    // 0x851cd4: ldur            d0, [fp, #-0x88]
    // 0x851cd8: StoreField: r1->field_97 = d0
    //     0x851cd8: stur            d0, [x1, #0x97]
    // 0x851cdc: ldur            d0, [fp, #-0x80]
    // 0x851ce0: StoreField: r1->field_9f = d0
    //     0x851ce0: stur            d0, [x1, #0x9f]
    // 0x851ce4: StoreField: r1->field_a7 = rZR
    //     0x851ce4: stur            xzr, [x1, #0xa7]
    // 0x851ce8: StoreField: r1->field_af = r7
    //     0x851ce8: stur            w7, [x1, #0xaf]
    // 0x851cec: mov             x0, x1
    // 0x851cf0: LeaveFrame
    //     0x851cf0: mov             SP, fp
    //     0x851cf4: ldp             fp, lr, [SP], #0x10
    // 0x851cf8: ret
    //     0x851cf8: ret             
    // 0x851cfc: ldur            x0, [fp, #-8]
    // 0x851d00: ldur            x5, [fp, #-0x10]
    // 0x851d04: mov             x4, x3
    // 0x851d08: mov             x3, x1
    // 0x851d0c: mov             v0.16b, v4.16b
    // 0x851d10: mov             v1.16b, v5.16b
    // 0x851d14: r7 = false
    //     0x851d14: add             x7, NULL, #0x30  ; false
    // 0x851d18: r6 = Instance_Offset
    //     0x851d18: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851d1c: LoadField: r1 = r2->field_27
    //     0x851d1c: ldur            x1, [x2, #0x27]
    // 0x851d20: stur            x1, [fp, #-0x28]
    // 0x851d24: LoadField: r8 = r2->field_5f
    //     0x851d24: ldur            w8, [x2, #0x5f]
    // 0x851d28: DecompressPointer r8
    //     0x851d28: add             x8, x8, HEAP, lsl #32
    // 0x851d2c: stur            x8, [fp, #-0x20]
    // 0x851d30: LoadField: d2 = r2->field_6f
    //     0x851d30: ldur            d2, [x2, #0x6f]
    // 0x851d34: stur            d2, [fp, #-0x90]
    // 0x851d38: LoadField: d3 = r2->field_77
    //     0x851d38: ldur            d3, [x2, #0x77]
    // 0x851d3c: stur            d3, [fp, #-0x88]
    // 0x851d40: LoadField: d4 = r2->field_87
    //     0x851d40: ldur            d4, [x2, #0x87]
    // 0x851d44: stur            d4, [fp, #-0x80]
    // 0x851d48: LoadField: r9 = r2->field_f
    //     0x851d48: ldur            x9, [x2, #0xf]
    // 0x851d4c: stur            x9, [fp, #-0x18]
    // 0x851d50: r0 = PointerRemovedEvent()
    //     0x851d50: bl              #0x852b20  ; AllocatePointerRemovedEventStub -> PointerRemovedEvent (size=0xbc)
    // 0x851d54: ldur            x1, [fp, #-8]
    // 0x851d58: StoreField: r0->field_7 = r1
    //     0x851d58: stur            x1, [x0, #7]
    // 0x851d5c: ldur            x1, [fp, #-0x18]
    // 0x851d60: StoreField: r0->field_f = r1
    //     0x851d60: stur            x1, [x0, #0xf]
    // 0x851d64: ldur            x3, [fp, #-0x48]
    // 0x851d68: ArrayStore: r0[0] = r3  ; List_4
    //     0x851d68: stur            w3, [x0, #0x17]
    // 0x851d6c: StoreField: r0->field_1b = rZR
    //     0x851d6c: stur            xzr, [x0, #0x1b]
    // 0x851d70: ldur            x4, [fp, #-0x40]
    // 0x851d74: StoreField: r0->field_23 = r4
    //     0x851d74: stur            w4, [x0, #0x23]
    // 0x851d78: ldur            x1, [fp, #-0x28]
    // 0x851d7c: StoreField: r0->field_27 = r1
    //     0x851d7c: stur            x1, [x0, #0x27]
    // 0x851d80: ldur            x6, [fp, #-0x10]
    // 0x851d84: StoreField: r0->field_2f = r6
    //     0x851d84: stur            w6, [x0, #0x2f]
    // 0x851d88: r7 = Instance_Offset
    //     0x851d88: ldr             x7, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851d8c: StoreField: r0->field_33 = r7
    //     0x851d8c: stur            w7, [x0, #0x33]
    // 0x851d90: StoreField: r0->field_37 = rZR
    //     0x851d90: stur            xzr, [x0, #0x37]
    // 0x851d94: r8 = false
    //     0x851d94: add             x8, NULL, #0x30  ; false
    // 0x851d98: StoreField: r0->field_3f = r8
    //     0x851d98: stur            w8, [x0, #0x3f]
    // 0x851d9c: ldur            x1, [fp, #-0x20]
    // 0x851da0: StoreField: r0->field_43 = r1
    //     0x851da0: stur            w1, [x0, #0x43]
    // 0x851da4: StoreField: r0->field_47 = rZR
    //     0x851da4: stur            xzr, [x0, #0x47]
    // 0x851da8: ldur            d0, [fp, #-0x90]
    // 0x851dac: StoreField: r0->field_4f = d0
    //     0x851dac: stur            d0, [x0, #0x4f]
    // 0x851db0: ldur            d0, [fp, #-0x88]
    // 0x851db4: StoreField: r0->field_57 = d0
    //     0x851db4: stur            d0, [x0, #0x57]
    // 0x851db8: StoreField: r0->field_5f = rZR
    //     0x851db8: stur            xzr, [x0, #0x5f]
    // 0x851dbc: ldur            d0, [fp, #-0x80]
    // 0x851dc0: StoreField: r0->field_67 = d0
    //     0x851dc0: stur            d0, [x0, #0x67]
    // 0x851dc4: StoreField: r0->field_6f = rZR
    //     0x851dc4: stur            xzr, [x0, #0x6f]
    // 0x851dc8: StoreField: r0->field_77 = rZR
    //     0x851dc8: stur            xzr, [x0, #0x77]
    // 0x851dcc: StoreField: r0->field_7f = rZR
    //     0x851dcc: stur            xzr, [x0, #0x7f]
    // 0x851dd0: ldur            d2, [fp, #-0xc0]
    // 0x851dd4: StoreField: r0->field_87 = d2
    //     0x851dd4: stur            d2, [x0, #0x87]
    // 0x851dd8: ldur            d3, [fp, #-0xb8]
    // 0x851ddc: StoreField: r0->field_8f = d3
    //     0x851ddc: stur            d3, [x0, #0x8f]
    // 0x851de0: StoreField: r0->field_97 = rZR
    //     0x851de0: stur            xzr, [x0, #0x97]
    // 0x851de4: StoreField: r0->field_9f = rZR
    //     0x851de4: stur            xzr, [x0, #0x9f]
    // 0x851de8: StoreField: r0->field_a7 = rZR
    //     0x851de8: stur            xzr, [x0, #0xa7]
    // 0x851dec: StoreField: r0->field_af = r8
    //     0x851dec: stur            w8, [x0, #0xaf]
    // 0x851df0: LeaveFrame
    //     0x851df0: mov             SP, fp
    //     0x851df4: ldp             fp, lr, [SP], #0x10
    // 0x851df8: ret
    //     0x851df8: ret             
    // 0x851dfc: mov             x4, x3
    // 0x851e00: mov             x3, x1
    // 0x851e04: ldur            x1, [fp, #-8]
    // 0x851e08: ldur            x6, [fp, #-0x10]
    // 0x851e0c: mov             v1.16b, v2.16b
    // 0x851e10: mov             v0.16b, v3.16b
    // 0x851e14: mov             v2.16b, v4.16b
    // 0x851e18: mov             v3.16b, v5.16b
    // 0x851e1c: r8 = false
    //     0x851e1c: add             x8, NULL, #0x30  ; false
    // 0x851e20: r7 = Instance_Offset
    //     0x851e20: ldr             x7, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x851e24: cmp             x5, #3
    // 0x851e28: b.gt            #0x851f68
    // 0x851e2c: LoadField: r5 = r2->field_27
    //     0x851e2c: ldur            x5, [x2, #0x27]
    // 0x851e30: stur            x5, [fp, #-0x30]
    // 0x851e34: LoadField: r7 = r2->field_57
    //     0x851e34: ldur            x7, [x2, #0x57]
    // 0x851e38: stur            x7, [fp, #-0x28]
    // 0x851e3c: LoadField: r9 = r2->field_5f
    //     0x851e3c: ldur            w9, [x2, #0x5f]
    // 0x851e40: DecompressPointer r9
    //     0x851e40: add             x9, x9, HEAP, lsl #32
    // 0x851e44: stur            x9, [fp, #-0x50]
    // 0x851e48: LoadField: d4 = r2->field_6f
    //     0x851e48: ldur            d4, [x2, #0x6f]
    // 0x851e4c: stur            d4, [fp, #-0xb0]
    // 0x851e50: LoadField: d5 = r2->field_77
    //     0x851e50: ldur            d5, [x2, #0x77]
    // 0x851e54: stur            d5, [fp, #-0xa8]
    // 0x851e58: LoadField: d6 = r2->field_7f
    //     0x851e58: ldur            d6, [x2, #0x7f]
    // 0x851e5c: stur            d6, [fp, #-0xa0]
    // 0x851e60: LoadField: d7 = r2->field_87
    //     0x851e60: ldur            d7, [x2, #0x87]
    // 0x851e64: stur            d7, [fp, #-0x98]
    // 0x851e68: LoadField: d8 = r2->field_8f
    //     0x851e68: ldur            d8, [x2, #0x8f]
    // 0x851e6c: stur            d8, [fp, #-0x90]
    // 0x851e70: LoadField: d9 = r2->field_b7
    //     0x851e70: ldur            d9, [x2, #0xb7]
    // 0x851e74: stur            d9, [fp, #-0x88]
    // 0x851e78: LoadField: d10 = r2->field_bf
    //     0x851e78: ldur            d10, [x2, #0xbf]
    // 0x851e7c: stur            d10, [fp, #-0x80]
    // 0x851e80: LoadField: r10 = r2->field_63
    //     0x851e80: ldur            w10, [x2, #0x63]
    // 0x851e84: DecompressPointer r10
    //     0x851e84: add             x10, x10, HEAP, lsl #32
    // 0x851e88: stur            x10, [fp, #-0x20]
    // 0x851e8c: LoadField: r11 = r2->field_f
    //     0x851e8c: ldur            x11, [x2, #0xf]
    // 0x851e90: stur            x11, [fp, #-0x18]
    // 0x851e94: r0 = PointerHoverEvent()
    //     0x851e94: bl              #0x852b14  ; AllocatePointerHoverEventStub -> PointerHoverEvent (size=0xbc)
    // 0x851e98: mov             x1, x0
    // 0x851e9c: ldur            x0, [fp, #-8]
    // 0x851ea0: StoreField: r1->field_7 = r0
    //     0x851ea0: stur            x0, [x1, #7]
    // 0x851ea4: ldur            x0, [fp, #-0x18]
    // 0x851ea8: StoreField: r1->field_f = r0
    //     0x851ea8: stur            x0, [x1, #0xf]
    // 0x851eac: ldur            x3, [fp, #-0x48]
    // 0x851eb0: ArrayStore: r1[0] = r3  ; List_4
    //     0x851eb0: stur            w3, [x1, #0x17]
    // 0x851eb4: StoreField: r1->field_1b = rZR
    //     0x851eb4: stur            xzr, [x1, #0x1b]
    // 0x851eb8: ldur            x4, [fp, #-0x40]
    // 0x851ebc: StoreField: r1->field_23 = r4
    //     0x851ebc: stur            w4, [x1, #0x23]
    // 0x851ec0: ldur            x0, [fp, #-0x30]
    // 0x851ec4: StoreField: r1->field_27 = r0
    //     0x851ec4: stur            x0, [x1, #0x27]
    // 0x851ec8: ldur            x5, [fp, #-0x10]
    // 0x851ecc: StoreField: r1->field_2f = r5
    //     0x851ecc: stur            w5, [x1, #0x2f]
    // 0x851ed0: ldur            x0, [fp, #-0x58]
    // 0x851ed4: StoreField: r1->field_33 = r0
    //     0x851ed4: stur            w0, [x1, #0x33]
    // 0x851ed8: ldur            x0, [fp, #-0x28]
    // 0x851edc: StoreField: r1->field_37 = r0
    //     0x851edc: stur            x0, [x1, #0x37]
    // 0x851ee0: r6 = false
    //     0x851ee0: add             x6, NULL, #0x30  ; false
    // 0x851ee4: StoreField: r1->field_3f = r6
    //     0x851ee4: stur            w6, [x1, #0x3f]
    // 0x851ee8: ldur            x0, [fp, #-0x50]
    // 0x851eec: StoreField: r1->field_43 = r0
    //     0x851eec: stur            w0, [x1, #0x43]
    // 0x851ef0: StoreField: r1->field_47 = rZR
    //     0x851ef0: stur            xzr, [x1, #0x47]
    // 0x851ef4: ldur            d0, [fp, #-0xb0]
    // 0x851ef8: StoreField: r1->field_4f = d0
    //     0x851ef8: stur            d0, [x1, #0x4f]
    // 0x851efc: ldur            d0, [fp, #-0xa8]
    // 0x851f00: StoreField: r1->field_57 = d0
    //     0x851f00: stur            d0, [x1, #0x57]
    // 0x851f04: ldur            d0, [fp, #-0xa0]
    // 0x851f08: StoreField: r1->field_5f = d0
    //     0x851f08: stur            d0, [x1, #0x5f]
    // 0x851f0c: ldur            d0, [fp, #-0x98]
    // 0x851f10: StoreField: r1->field_67 = d0
    //     0x851f10: stur            d0, [x1, #0x67]
    // 0x851f14: ldur            d0, [fp, #-0x90]
    // 0x851f18: StoreField: r1->field_6f = d0
    //     0x851f18: stur            d0, [x1, #0x6f]
    // 0x851f1c: ldur            d0, [fp, #-0xc8]
    // 0x851f20: StoreField: r1->field_77 = d0
    //     0x851f20: stur            d0, [x1, #0x77]
    // 0x851f24: ldur            d1, [fp, #-0xd0]
    // 0x851f28: StoreField: r1->field_7f = d1
    //     0x851f28: stur            d1, [x1, #0x7f]
    // 0x851f2c: ldur            d2, [fp, #-0xc0]
    // 0x851f30: StoreField: r1->field_87 = d2
    //     0x851f30: stur            d2, [x1, #0x87]
    // 0x851f34: ldur            d3, [fp, #-0xb8]
    // 0x851f38: StoreField: r1->field_8f = d3
    //     0x851f38: stur            d3, [x1, #0x8f]
    // 0x851f3c: ldur            d0, [fp, #-0x88]
    // 0x851f40: StoreField: r1->field_97 = d0
    //     0x851f40: stur            d0, [x1, #0x97]
    // 0x851f44: ldur            d0, [fp, #-0x80]
    // 0x851f48: StoreField: r1->field_9f = d0
    //     0x851f48: stur            d0, [x1, #0x9f]
    // 0x851f4c: StoreField: r1->field_a7 = rZR
    //     0x851f4c: stur            xzr, [x1, #0xa7]
    // 0x851f50: ldur            x0, [fp, #-0x20]
    // 0x851f54: StoreField: r1->field_af = r0
    //     0x851f54: stur            w0, [x1, #0xaf]
    // 0x851f58: mov             x0, x1
    // 0x851f5c: LeaveFrame
    //     0x851f5c: mov             SP, fp
    //     0x851f60: ldp             fp, lr, [SP], #0x10
    // 0x851f64: ret
    //     0x851f64: ret             
    // 0x851f68: mov             x0, x1
    // 0x851f6c: mov             x5, x6
    // 0x851f70: mov             x6, x8
    // 0x851f74: LoadField: r1 = r2->field_2f
    //     0x851f74: ldur            x1, [x2, #0x2f]
    // 0x851f78: stur            x1, [fp, #-0x38]
    // 0x851f7c: LoadField: r8 = r2->field_27
    //     0x851f7c: ldur            x8, [x2, #0x27]
    // 0x851f80: stur            x8, [fp, #-0x30]
    // 0x851f84: LoadField: r9 = r2->field_57
    //     0x851f84: ldur            x9, [x2, #0x57]
    // 0x851f88: LoadField: r10 = r4->field_7
    //     0x851f88: ldur            x10, [x4, #7]
    // 0x851f8c: cmp             x10, #2
    // 0x851f90: b.gt            #0x851fa8
    // 0x851f94: cmp             x10, #1
    // 0x851f98: b.gt            #0x851fb8
    // 0x851f9c: cmp             x10, #0
    // 0x851fa0: b.gt            #0x851fcc
    // 0x851fa4: b               #0x851fb8
    // 0x851fa8: cmp             x10, #4
    // 0x851fac: b.gt            #0x851fc4
    // 0x851fb0: cmp             x10, #3
    // 0x851fb4: b.gt            #0x851fcc
    // 0x851fb8: cbnz            x9, #0x851fcc
    // 0x851fbc: r9 = 1
    //     0x851fbc: mov             x9, #1
    // 0x851fc0: b               #0x851fcc
    // 0x851fc4: cbnz            x9, #0x851fcc
    // 0x851fc8: r9 = 1
    //     0x851fc8: mov             x9, #1
    // 0x851fcc: stur            x9, [fp, #-0x28]
    // 0x851fd0: LoadField: r10 = r2->field_5f
    //     0x851fd0: ldur            w10, [x2, #0x5f]
    // 0x851fd4: DecompressPointer r10
    //     0x851fd4: add             x10, x10, HEAP, lsl #32
    // 0x851fd8: stur            x10, [fp, #-0x20]
    // 0x851fdc: LoadField: d4 = r2->field_67
    //     0x851fdc: ldur            d4, [x2, #0x67]
    // 0x851fe0: stur            d4, [fp, #-0xb0]
    // 0x851fe4: LoadField: d5 = r2->field_6f
    //     0x851fe4: ldur            d5, [x2, #0x6f]
    // 0x851fe8: stur            d5, [fp, #-0xa8]
    // 0x851fec: LoadField: d6 = r2->field_77
    //     0x851fec: ldur            d6, [x2, #0x77]
    // 0x851ff0: stur            d6, [fp, #-0xa0]
    // 0x851ff4: LoadField: d7 = r2->field_87
    //     0x851ff4: ldur            d7, [x2, #0x87]
    // 0x851ff8: stur            d7, [fp, #-0x98]
    // 0x851ffc: LoadField: d8 = r2->field_8f
    //     0x851ffc: ldur            d8, [x2, #0x8f]
    // 0x852000: stur            d8, [fp, #-0x90]
    // 0x852004: LoadField: d9 = r2->field_b7
    //     0x852004: ldur            d9, [x2, #0xb7]
    // 0x852008: stur            d9, [fp, #-0x88]
    // 0x85200c: LoadField: d10 = r2->field_bf
    //     0x85200c: ldur            d10, [x2, #0xbf]
    // 0x852010: stur            d10, [fp, #-0x80]
    // 0x852014: LoadField: r11 = r2->field_f
    //     0x852014: ldur            x11, [x2, #0xf]
    // 0x852018: stur            x11, [fp, #-0x18]
    // 0x85201c: r0 = PointerDownEvent()
    //     0x85201c: bl              #0x852b08  ; AllocatePointerDownEventStub -> PointerDownEvent (size=0xbc)
    // 0x852020: ldur            x1, [fp, #-8]
    // 0x852024: StoreField: r0->field_7 = r1
    //     0x852024: stur            x1, [x0, #7]
    // 0x852028: ldur            x1, [fp, #-0x18]
    // 0x85202c: StoreField: r0->field_f = r1
    //     0x85202c: stur            x1, [x0, #0xf]
    // 0x852030: ldur            x3, [fp, #-0x48]
    // 0x852034: ArrayStore: r0[0] = r3  ; List_4
    //     0x852034: stur            w3, [x0, #0x17]
    // 0x852038: ldur            x1, [fp, #-0x38]
    // 0x85203c: StoreField: r0->field_1b = r1
    //     0x85203c: stur            x1, [x0, #0x1b]
    // 0x852040: ldur            x4, [fp, #-0x40]
    // 0x852044: StoreField: r0->field_23 = r4
    //     0x852044: stur            w4, [x0, #0x23]
    // 0x852048: ldur            x1, [fp, #-0x30]
    // 0x85204c: StoreField: r0->field_27 = r1
    //     0x85204c: stur            x1, [x0, #0x27]
    // 0x852050: ldur            x6, [fp, #-0x10]
    // 0x852054: StoreField: r0->field_2f = r6
    //     0x852054: stur            w6, [x0, #0x2f]
    // 0x852058: r7 = Instance_Offset
    //     0x852058: ldr             x7, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x85205c: StoreField: r0->field_33 = r7
    //     0x85205c: stur            w7, [x0, #0x33]
    // 0x852060: ldur            x1, [fp, #-0x28]
    // 0x852064: StoreField: r0->field_37 = r1
    //     0x852064: stur            x1, [x0, #0x37]
    // 0x852068: r8 = true
    //     0x852068: add             x8, NULL, #0x20  ; true
    // 0x85206c: StoreField: r0->field_3f = r8
    //     0x85206c: stur            w8, [x0, #0x3f]
    // 0x852070: ldur            x1, [fp, #-0x20]
    // 0x852074: StoreField: r0->field_43 = r1
    //     0x852074: stur            w1, [x0, #0x43]
    // 0x852078: ldur            d0, [fp, #-0xb0]
    // 0x85207c: StoreField: r0->field_47 = d0
    //     0x85207c: stur            d0, [x0, #0x47]
    // 0x852080: ldur            d0, [fp, #-0xa8]
    // 0x852084: StoreField: r0->field_4f = d0
    //     0x852084: stur            d0, [x0, #0x4f]
    // 0x852088: ldur            d0, [fp, #-0xa0]
    // 0x85208c: StoreField: r0->field_57 = d0
    //     0x85208c: stur            d0, [x0, #0x57]
    // 0x852090: StoreField: r0->field_5f = rZR
    //     0x852090: stur            xzr, [x0, #0x5f]
    // 0x852094: ldur            d0, [fp, #-0x98]
    // 0x852098: StoreField: r0->field_67 = d0
    //     0x852098: stur            d0, [x0, #0x67]
    // 0x85209c: ldur            d0, [fp, #-0x90]
    // 0x8520a0: StoreField: r0->field_6f = d0
    //     0x8520a0: stur            d0, [x0, #0x6f]
    // 0x8520a4: ldur            d0, [fp, #-0xc8]
    // 0x8520a8: StoreField: r0->field_77 = d0
    //     0x8520a8: stur            d0, [x0, #0x77]
    // 0x8520ac: ldur            d2, [fp, #-0xd0]
    // 0x8520b0: StoreField: r0->field_7f = d2
    //     0x8520b0: stur            d2, [x0, #0x7f]
    // 0x8520b4: ldur            d3, [fp, #-0xc0]
    // 0x8520b8: StoreField: r0->field_87 = d3
    //     0x8520b8: stur            d3, [x0, #0x87]
    // 0x8520bc: ldur            d4, [fp, #-0xb8]
    // 0x8520c0: StoreField: r0->field_8f = d4
    //     0x8520c0: stur            d4, [x0, #0x8f]
    // 0x8520c4: ldur            d0, [fp, #-0x88]
    // 0x8520c8: StoreField: r0->field_97 = d0
    //     0x8520c8: stur            d0, [x0, #0x97]
    // 0x8520cc: ldur            d0, [fp, #-0x80]
    // 0x8520d0: StoreField: r0->field_9f = d0
    //     0x8520d0: stur            d0, [x0, #0x9f]
    // 0x8520d4: StoreField: r0->field_a7 = rZR
    //     0x8520d4: stur            xzr, [x0, #0xa7]
    // 0x8520d8: r9 = false
    //     0x8520d8: add             x9, NULL, #0x30  ; false
    // 0x8520dc: StoreField: r0->field_af = r9
    //     0x8520dc: stur            w9, [x0, #0xaf]
    // 0x8520e0: LeaveFrame
    //     0x8520e0: mov             SP, fp
    //     0x8520e4: ldp             fp, lr, [SP], #0x10
    // 0x8520e8: ret
    //     0x8520e8: ret             
    // 0x8520ec: mov             x4, x3
    // 0x8520f0: mov             x3, x1
    // 0x8520f4: ldur            x1, [fp, #-8]
    // 0x8520f8: ldur            x6, [fp, #-0x10]
    // 0x8520fc: mov             v0.16b, v3.16b
    // 0x852100: mov             v3.16b, v4.16b
    // 0x852104: mov             v4.16b, v5.16b
    // 0x852108: r8 = true
    //     0x852108: add             x8, NULL, #0x20  ; true
    // 0x85210c: r9 = false
    //     0x85210c: add             x9, NULL, #0x30  ; false
    // 0x852110: r7 = Instance_Offset
    //     0x852110: ldr             x7, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852114: cmp             x5, #7
    // 0x852118: b.gt            #0x8524f8
    // 0x85211c: cmp             x5, #6
    // 0x852120: b.gt            #0x85241c
    // 0x852124: cmp             x5, #5
    // 0x852128: b.gt            #0x8522c4
    // 0x85212c: LoadField: r5 = r2->field_2f
    //     0x85212c: ldur            x5, [x2, #0x2f]
    // 0x852130: stur            x5, [fp, #-0x60]
    // 0x852134: LoadField: r7 = r2->field_27
    //     0x852134: ldur            x7, [x2, #0x27]
    // 0x852138: stur            x7, [fp, #-0x38]
    // 0x85213c: LoadField: r9 = r2->field_57
    //     0x85213c: ldur            x9, [x2, #0x57]
    // 0x852140: LoadField: r10 = r4->field_7
    //     0x852140: ldur            x10, [x4, #7]
    // 0x852144: cmp             x10, #2
    // 0x852148: b.gt            #0x852160
    // 0x85214c: cmp             x10, #1
    // 0x852150: b.gt            #0x852170
    // 0x852154: cmp             x10, #0
    // 0x852158: b.gt            #0x852184
    // 0x85215c: b               #0x852170
    // 0x852160: cmp             x10, #4
    // 0x852164: b.gt            #0x85217c
    // 0x852168: cmp             x10, #3
    // 0x85216c: b.gt            #0x852184
    // 0x852170: cbnz            x9, #0x852184
    // 0x852174: r9 = 1
    //     0x852174: mov             x9, #1
    // 0x852178: b               #0x852184
    // 0x85217c: cbnz            x9, #0x852184
    // 0x852180: r9 = 1
    //     0x852180: mov             x9, #1
    // 0x852184: stur            x9, [fp, #-0x30]
    // 0x852188: LoadField: r10 = r2->field_5f
    //     0x852188: ldur            w10, [x2, #0x5f]
    // 0x85218c: DecompressPointer r10
    //     0x85218c: add             x10, x10, HEAP, lsl #32
    // 0x852190: stur            x10, [fp, #-0x50]
    // 0x852194: LoadField: d1 = r2->field_67
    //     0x852194: ldur            d1, [x2, #0x67]
    // 0x852198: stur            d1, [fp, #-0xb0]
    // 0x85219c: LoadField: d5 = r2->field_6f
    //     0x85219c: ldur            d5, [x2, #0x6f]
    // 0x8521a0: stur            d5, [fp, #-0xa8]
    // 0x8521a4: LoadField: d6 = r2->field_77
    //     0x8521a4: ldur            d6, [x2, #0x77]
    // 0x8521a8: stur            d6, [fp, #-0xa0]
    // 0x8521ac: LoadField: d7 = r2->field_87
    //     0x8521ac: ldur            d7, [x2, #0x87]
    // 0x8521b0: stur            d7, [fp, #-0x98]
    // 0x8521b4: LoadField: d8 = r2->field_8f
    //     0x8521b4: ldur            d8, [x2, #0x8f]
    // 0x8521b8: stur            d8, [fp, #-0x90]
    // 0x8521bc: LoadField: d9 = r2->field_b7
    //     0x8521bc: ldur            d9, [x2, #0xb7]
    // 0x8521c0: stur            d9, [fp, #-0x88]
    // 0x8521c4: LoadField: d10 = r2->field_bf
    //     0x8521c4: ldur            d10, [x2, #0xbf]
    // 0x8521c8: stur            d10, [fp, #-0x80]
    // 0x8521cc: LoadField: r11 = r2->field_c7
    //     0x8521cc: ldur            x11, [x2, #0xc7]
    // 0x8521d0: stur            x11, [fp, #-0x28]
    // 0x8521d4: LoadField: r12 = r2->field_63
    //     0x8521d4: ldur            w12, [x2, #0x63]
    // 0x8521d8: DecompressPointer r12
    //     0x8521d8: add             x12, x12, HEAP, lsl #32
    // 0x8521dc: stur            x12, [fp, #-0x20]
    // 0x8521e0: LoadField: r13 = r2->field_f
    //     0x8521e0: ldur            x13, [x2, #0xf]
    // 0x8521e4: stur            x13, [fp, #-0x18]
    // 0x8521e8: r0 = PointerMoveEvent()
    //     0x8521e8: bl              #0x852afc  ; AllocatePointerMoveEventStub -> PointerMoveEvent (size=0xbc)
    // 0x8521ec: mov             x1, x0
    // 0x8521f0: ldur            x0, [fp, #-8]
    // 0x8521f4: StoreField: r1->field_7 = r0
    //     0x8521f4: stur            x0, [x1, #7]
    // 0x8521f8: ldur            x0, [fp, #-0x18]
    // 0x8521fc: StoreField: r1->field_f = r0
    //     0x8521fc: stur            x0, [x1, #0xf]
    // 0x852200: ldur            x3, [fp, #-0x48]
    // 0x852204: ArrayStore: r1[0] = r3  ; List_4
    //     0x852204: stur            w3, [x1, #0x17]
    // 0x852208: ldur            x0, [fp, #-0x60]
    // 0x85220c: StoreField: r1->field_1b = r0
    //     0x85220c: stur            x0, [x1, #0x1b]
    // 0x852210: ldur            x4, [fp, #-0x40]
    // 0x852214: StoreField: r1->field_23 = r4
    //     0x852214: stur            w4, [x1, #0x23]
    // 0x852218: ldur            x0, [fp, #-0x38]
    // 0x85221c: StoreField: r1->field_27 = r0
    //     0x85221c: stur            x0, [x1, #0x27]
    // 0x852220: ldur            x5, [fp, #-0x10]
    // 0x852224: StoreField: r1->field_2f = r5
    //     0x852224: stur            w5, [x1, #0x2f]
    // 0x852228: ldur            x0, [fp, #-0x58]
    // 0x85222c: StoreField: r1->field_33 = r0
    //     0x85222c: stur            w0, [x1, #0x33]
    // 0x852230: ldur            x0, [fp, #-0x30]
    // 0x852234: StoreField: r1->field_37 = r0
    //     0x852234: stur            x0, [x1, #0x37]
    // 0x852238: r0 = true
    //     0x852238: add             x0, NULL, #0x20  ; true
    // 0x85223c: StoreField: r1->field_3f = r0
    //     0x85223c: stur            w0, [x1, #0x3f]
    // 0x852240: ldur            x0, [fp, #-0x50]
    // 0x852244: StoreField: r1->field_43 = r0
    //     0x852244: stur            w0, [x1, #0x43]
    // 0x852248: ldur            d0, [fp, #-0xb0]
    // 0x85224c: StoreField: r1->field_47 = d0
    //     0x85224c: stur            d0, [x1, #0x47]
    // 0x852250: ldur            d0, [fp, #-0xa8]
    // 0x852254: StoreField: r1->field_4f = d0
    //     0x852254: stur            d0, [x1, #0x4f]
    // 0x852258: ldur            d0, [fp, #-0xa0]
    // 0x85225c: StoreField: r1->field_57 = d0
    //     0x85225c: stur            d0, [x1, #0x57]
    // 0x852260: StoreField: r1->field_5f = rZR
    //     0x852260: stur            xzr, [x1, #0x5f]
    // 0x852264: ldur            d0, [fp, #-0x98]
    // 0x852268: StoreField: r1->field_67 = d0
    //     0x852268: stur            d0, [x1, #0x67]
    // 0x85226c: ldur            d0, [fp, #-0x90]
    // 0x852270: StoreField: r1->field_6f = d0
    //     0x852270: stur            d0, [x1, #0x6f]
    // 0x852274: ldur            d0, [fp, #-0xc8]
    // 0x852278: StoreField: r1->field_77 = d0
    //     0x852278: stur            d0, [x1, #0x77]
    // 0x85227c: ldur            d1, [fp, #-0xd0]
    // 0x852280: StoreField: r1->field_7f = d1
    //     0x852280: stur            d1, [x1, #0x7f]
    // 0x852284: ldur            d2, [fp, #-0xc0]
    // 0x852288: StoreField: r1->field_87 = d2
    //     0x852288: stur            d2, [x1, #0x87]
    // 0x85228c: ldur            d3, [fp, #-0xb8]
    // 0x852290: StoreField: r1->field_8f = d3
    //     0x852290: stur            d3, [x1, #0x8f]
    // 0x852294: ldur            d0, [fp, #-0x88]
    // 0x852298: StoreField: r1->field_97 = d0
    //     0x852298: stur            d0, [x1, #0x97]
    // 0x85229c: ldur            d0, [fp, #-0x80]
    // 0x8522a0: StoreField: r1->field_9f = d0
    //     0x8522a0: stur            d0, [x1, #0x9f]
    // 0x8522a4: ldur            x0, [fp, #-0x28]
    // 0x8522a8: StoreField: r1->field_a7 = r0
    //     0x8522a8: stur            x0, [x1, #0xa7]
    // 0x8522ac: ldur            x0, [fp, #-0x20]
    // 0x8522b0: StoreField: r1->field_af = r0
    //     0x8522b0: stur            w0, [x1, #0xaf]
    // 0x8522b4: mov             x0, x1
    // 0x8522b8: LeaveFrame
    //     0x8522b8: mov             SP, fp
    //     0x8522bc: ldp             fp, lr, [SP], #0x10
    // 0x8522c0: ret
    //     0x8522c0: ret             
    // 0x8522c4: mov             x0, x1
    // 0x8522c8: mov             x5, x6
    // 0x8522cc: mov             v1.16b, v2.16b
    // 0x8522d0: mov             v2.16b, v3.16b
    // 0x8522d4: mov             v3.16b, v4.16b
    // 0x8522d8: LoadField: r1 = r2->field_2f
    //     0x8522d8: ldur            x1, [x2, #0x2f]
    // 0x8522dc: stur            x1, [fp, #-0x38]
    // 0x8522e0: LoadField: r6 = r2->field_27
    //     0x8522e0: ldur            x6, [x2, #0x27]
    // 0x8522e4: stur            x6, [fp, #-0x30]
    // 0x8522e8: LoadField: r8 = r2->field_57
    //     0x8522e8: ldur            x8, [x2, #0x57]
    // 0x8522ec: stur            x8, [fp, #-0x28]
    // 0x8522f0: LoadField: r10 = r2->field_5f
    //     0x8522f0: ldur            w10, [x2, #0x5f]
    // 0x8522f4: DecompressPointer r10
    //     0x8522f4: add             x10, x10, HEAP, lsl #32
    // 0x8522f8: stur            x10, [fp, #-0x20]
    // 0x8522fc: LoadField: d4 = r2->field_67
    //     0x8522fc: ldur            d4, [x2, #0x67]
    // 0x852300: stur            d4, [fp, #-0xd8]
    // 0x852304: LoadField: d5 = r2->field_6f
    //     0x852304: ldur            d5, [x2, #0x6f]
    // 0x852308: stur            d5, [fp, #-0xb0]
    // 0x85230c: LoadField: d6 = r2->field_77
    //     0x85230c: ldur            d6, [x2, #0x77]
    // 0x852310: stur            d6, [fp, #-0xa8]
    // 0x852314: LoadField: d7 = r2->field_7f
    //     0x852314: ldur            d7, [x2, #0x7f]
    // 0x852318: stur            d7, [fp, #-0xa0]
    // 0x85231c: LoadField: d8 = r2->field_87
    //     0x85231c: ldur            d8, [x2, #0x87]
    // 0x852320: stur            d8, [fp, #-0x98]
    // 0x852324: LoadField: d9 = r2->field_8f
    //     0x852324: ldur            d9, [x2, #0x8f]
    // 0x852328: stur            d9, [fp, #-0x90]
    // 0x85232c: LoadField: d10 = r2->field_b7
    //     0x85232c: ldur            d10, [x2, #0xb7]
    // 0x852330: stur            d10, [fp, #-0x88]
    // 0x852334: LoadField: d11 = r2->field_bf
    //     0x852334: ldur            d11, [x2, #0xbf]
    // 0x852338: stur            d11, [fp, #-0x80]
    // 0x85233c: LoadField: r11 = r2->field_f
    //     0x85233c: ldur            x11, [x2, #0xf]
    // 0x852340: stur            x11, [fp, #-0x18]
    // 0x852344: r0 = PointerUpEvent()
    //     0x852344: bl              #0x852af0  ; AllocatePointerUpEventStub -> PointerUpEvent (size=0xbc)
    // 0x852348: mov             x1, x0
    // 0x85234c: ldur            x0, [fp, #-8]
    // 0x852350: StoreField: r1->field_7 = r0
    //     0x852350: stur            x0, [x1, #7]
    // 0x852354: ldur            x0, [fp, #-0x18]
    // 0x852358: StoreField: r1->field_f = r0
    //     0x852358: stur            x0, [x1, #0xf]
    // 0x85235c: ldur            x3, [fp, #-0x48]
    // 0x852360: ArrayStore: r1[0] = r3  ; List_4
    //     0x852360: stur            w3, [x1, #0x17]
    // 0x852364: ldur            x0, [fp, #-0x38]
    // 0x852368: StoreField: r1->field_1b = r0
    //     0x852368: stur            x0, [x1, #0x1b]
    // 0x85236c: ldur            x0, [fp, #-0x40]
    // 0x852370: StoreField: r1->field_23 = r0
    //     0x852370: stur            w0, [x1, #0x23]
    // 0x852374: ldur            x0, [fp, #-0x30]
    // 0x852378: StoreField: r1->field_27 = r0
    //     0x852378: stur            x0, [x1, #0x27]
    // 0x85237c: ldur            x4, [fp, #-0x10]
    // 0x852380: StoreField: r1->field_2f = r4
    //     0x852380: stur            w4, [x1, #0x2f]
    // 0x852384: r5 = Instance_Offset
    //     0x852384: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852388: StoreField: r1->field_33 = r5
    //     0x852388: stur            w5, [x1, #0x33]
    // 0x85238c: ldur            x0, [fp, #-0x28]
    // 0x852390: StoreField: r1->field_37 = r0
    //     0x852390: stur            x0, [x1, #0x37]
    // 0x852394: r6 = false
    //     0x852394: add             x6, NULL, #0x30  ; false
    // 0x852398: StoreField: r1->field_3f = r6
    //     0x852398: stur            w6, [x1, #0x3f]
    // 0x85239c: ldur            x0, [fp, #-0x20]
    // 0x8523a0: StoreField: r1->field_43 = r0
    //     0x8523a0: stur            w0, [x1, #0x43]
    // 0x8523a4: ldur            d0, [fp, #-0xd8]
    // 0x8523a8: StoreField: r1->field_47 = d0
    //     0x8523a8: stur            d0, [x1, #0x47]
    // 0x8523ac: ldur            d0, [fp, #-0xb0]
    // 0x8523b0: StoreField: r1->field_4f = d0
    //     0x8523b0: stur            d0, [x1, #0x4f]
    // 0x8523b4: ldur            d0, [fp, #-0xa8]
    // 0x8523b8: StoreField: r1->field_57 = d0
    //     0x8523b8: stur            d0, [x1, #0x57]
    // 0x8523bc: ldur            d0, [fp, #-0xa0]
    // 0x8523c0: StoreField: r1->field_5f = d0
    //     0x8523c0: stur            d0, [x1, #0x5f]
    // 0x8523c4: ldur            d0, [fp, #-0x98]
    // 0x8523c8: StoreField: r1->field_67 = d0
    //     0x8523c8: stur            d0, [x1, #0x67]
    // 0x8523cc: ldur            d0, [fp, #-0x90]
    // 0x8523d0: StoreField: r1->field_6f = d0
    //     0x8523d0: stur            d0, [x1, #0x6f]
    // 0x8523d4: ldur            d0, [fp, #-0xc8]
    // 0x8523d8: StoreField: r1->field_77 = d0
    //     0x8523d8: stur            d0, [x1, #0x77]
    // 0x8523dc: ldur            d0, [fp, #-0xd0]
    // 0x8523e0: StoreField: r1->field_7f = d0
    //     0x8523e0: stur            d0, [x1, #0x7f]
    // 0x8523e4: ldur            d0, [fp, #-0xc0]
    // 0x8523e8: StoreField: r1->field_87 = d0
    //     0x8523e8: stur            d0, [x1, #0x87]
    // 0x8523ec: ldur            d0, [fp, #-0xb8]
    // 0x8523f0: StoreField: r1->field_8f = d0
    //     0x8523f0: stur            d0, [x1, #0x8f]
    // 0x8523f4: ldur            d0, [fp, #-0x88]
    // 0x8523f8: StoreField: r1->field_97 = d0
    //     0x8523f8: stur            d0, [x1, #0x97]
    // 0x8523fc: ldur            d0, [fp, #-0x80]
    // 0x852400: StoreField: r1->field_9f = d0
    //     0x852400: stur            d0, [x1, #0x9f]
    // 0x852404: StoreField: r1->field_a7 = rZR
    //     0x852404: stur            xzr, [x1, #0xa7]
    // 0x852408: StoreField: r1->field_af = r6
    //     0x852408: stur            w6, [x1, #0xaf]
    // 0x85240c: mov             x0, x1
    // 0x852410: LeaveFrame
    //     0x852410: mov             SP, fp
    //     0x852414: ldp             fp, lr, [SP], #0x10
    // 0x852418: ret
    //     0x852418: ret             
    // 0x85241c: mov             x0, x1
    // 0x852420: mov             x4, x6
    // 0x852424: mov             x6, x9
    // 0x852428: mov             x5, x7
    // 0x85242c: LoadField: r1 = r2->field_2f
    //     0x85242c: ldur            x1, [x2, #0x2f]
    // 0x852430: stur            x1, [fp, #-0x30]
    // 0x852434: LoadField: r7 = r2->field_27
    //     0x852434: ldur            x7, [x2, #0x27]
    // 0x852438: stur            x7, [fp, #-0x28]
    // 0x85243c: LoadField: r8 = r2->field_f
    //     0x85243c: ldur            x8, [x2, #0xf]
    // 0x852440: stur            x8, [fp, #-0x18]
    // 0x852444: LoadField: r9 = r2->field_63
    //     0x852444: ldur            w9, [x2, #0x63]
    // 0x852448: DecompressPointer r9
    //     0x852448: add             x9, x9, HEAP, lsl #32
    // 0x85244c: stur            x9, [fp, #-0x20]
    // 0x852450: r0 = PointerPanZoomStartEvent()
    //     0x852450: bl              #0x852ae4  ; AllocatePointerPanZoomStartEventStub -> PointerPanZoomStartEvent (size=0xbc)
    // 0x852454: mov             x1, x0
    // 0x852458: ldur            x0, [fp, #-8]
    // 0x85245c: StoreField: r1->field_7 = r0
    //     0x85245c: stur            x0, [x1, #7]
    // 0x852460: ldur            x0, [fp, #-0x18]
    // 0x852464: StoreField: r1->field_f = r0
    //     0x852464: stur            x0, [x1, #0xf]
    // 0x852468: ldur            x3, [fp, #-0x48]
    // 0x85246c: ArrayStore: r1[0] = r3  ; List_4
    //     0x85246c: stur            w3, [x1, #0x17]
    // 0x852470: ldur            x0, [fp, #-0x30]
    // 0x852474: StoreField: r1->field_1b = r0
    //     0x852474: stur            x0, [x1, #0x1b]
    // 0x852478: r4 = Instance_PointerDeviceKind
    //     0x852478: ldr             x4, [PP, #0x4378]  ; [pp+0x4378] Obj!PointerDeviceKind@12c7ae1
    // 0x85247c: StoreField: r1->field_23 = r4
    //     0x85247c: stur            w4, [x1, #0x23]
    // 0x852480: ldur            x0, [fp, #-0x28]
    // 0x852484: StoreField: r1->field_27 = r0
    //     0x852484: stur            x0, [x1, #0x27]
    // 0x852488: ldur            x6, [fp, #-0x10]
    // 0x85248c: StoreField: r1->field_2f = r6
    //     0x85248c: stur            w6, [x1, #0x2f]
    // 0x852490: r7 = Instance_Offset
    //     0x852490: ldr             x7, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852494: StoreField: r1->field_33 = r7
    //     0x852494: stur            w7, [x1, #0x33]
    // 0x852498: StoreField: r1->field_37 = rZR
    //     0x852498: stur            xzr, [x1, #0x37]
    // 0x85249c: r8 = false
    //     0x85249c: add             x8, NULL, #0x30  ; false
    // 0x8524a0: StoreField: r1->field_3f = r8
    //     0x8524a0: stur            w8, [x1, #0x3f]
    // 0x8524a4: StoreField: r1->field_43 = r8
    //     0x8524a4: stur            w8, [x1, #0x43]
    // 0x8524a8: d0 = 1.000000
    //     0x8524a8: fmov            d0, #1.00000000
    // 0x8524ac: StoreField: r1->field_47 = d0
    //     0x8524ac: stur            d0, [x1, #0x47]
    // 0x8524b0: StoreField: r1->field_4f = d0
    //     0x8524b0: stur            d0, [x1, #0x4f]
    // 0x8524b4: StoreField: r1->field_57 = d0
    //     0x8524b4: stur            d0, [x1, #0x57]
    // 0x8524b8: StoreField: r1->field_5f = rZR
    //     0x8524b8: stur            xzr, [x1, #0x5f]
    // 0x8524bc: StoreField: r1->field_67 = rZR
    //     0x8524bc: stur            xzr, [x1, #0x67]
    // 0x8524c0: StoreField: r1->field_6f = rZR
    //     0x8524c0: stur            xzr, [x1, #0x6f]
    // 0x8524c4: StoreField: r1->field_77 = rZR
    //     0x8524c4: stur            xzr, [x1, #0x77]
    // 0x8524c8: StoreField: r1->field_7f = rZR
    //     0x8524c8: stur            xzr, [x1, #0x7f]
    // 0x8524cc: StoreField: r1->field_87 = rZR
    //     0x8524cc: stur            xzr, [x1, #0x87]
    // 0x8524d0: StoreField: r1->field_8f = rZR
    //     0x8524d0: stur            xzr, [x1, #0x8f]
    // 0x8524d4: StoreField: r1->field_97 = rZR
    //     0x8524d4: stur            xzr, [x1, #0x97]
    // 0x8524d8: StoreField: r1->field_9f = rZR
    //     0x8524d8: stur            xzr, [x1, #0x9f]
    // 0x8524dc: StoreField: r1->field_a7 = rZR
    //     0x8524dc: stur            xzr, [x1, #0xa7]
    // 0x8524e0: ldur            x0, [fp, #-0x20]
    // 0x8524e4: StoreField: r1->field_af = r0
    //     0x8524e4: stur            w0, [x1, #0xaf]
    // 0x8524e8: mov             x0, x1
    // 0x8524ec: LeaveFrame
    //     0x8524ec: mov             SP, fp
    //     0x8524f0: ldp             fp, lr, [SP], #0x10
    // 0x8524f4: ret
    //     0x8524f4: ret             
    // 0x8524f8: mov             x0, x1
    // 0x8524fc: mov             x8, x9
    // 0x852500: r4 = Instance_PointerDeviceKind
    //     0x852500: ldr             x4, [PP, #0x4378]  ; [pp+0x4378] Obj!PointerDeviceKind@12c7ae1
    // 0x852504: d0 = 1.000000
    //     0x852504: fmov            d0, #1.00000000
    // 0x852508: cmp             x5, #8
    // 0x85250c: b.gt            #0x852690
    // 0x852510: LoadField: d2 = r2->field_df
    //     0x852510: ldur            d2, [x2, #0xdf]
    // 0x852514: stur            d2, [fp, #-0x88]
    // 0x852518: LoadField: d3 = r2->field_e7
    //     0x852518: ldur            d3, [x2, #0xe7]
    // 0x85251c: stur            d3, [fp, #-0x80]
    // 0x852520: r0 = Offset()
    //     0x852520: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x852524: ldur            d0, [fp, #-0x88]
    // 0x852528: StoreField: r0->field_7 = d0
    //     0x852528: stur            d0, [x0, #7]
    // 0x85252c: ldur            d0, [fp, #-0x80]
    // 0x852530: StoreField: r0->field_f = d0
    //     0x852530: stur            d0, [x0, #0xf]
    // 0x852534: mov             x1, x0
    // 0x852538: ldur            d0, [fp, #-0x78]
    // 0x85253c: r0 = /()
    //     0x85253c: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x852540: ldr             x2, [fp, #0x10]
    // 0x852544: stur            x0, [fp, #-0x20]
    // 0x852548: LoadField: d0 = r2->field_ef
    //     0x852548: ldur            d0, [x2, #0xef]
    // 0x85254c: stur            d0, [fp, #-0x88]
    // 0x852550: LoadField: d1 = r2->field_f7
    //     0x852550: ldur            d1, [x2, #0xf7]
    // 0x852554: stur            d1, [fp, #-0x80]
    // 0x852558: r0 = Offset()
    //     0x852558: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85255c: ldur            d0, [fp, #-0x88]
    // 0x852560: StoreField: r0->field_7 = d0
    //     0x852560: stur            d0, [x0, #7]
    // 0x852564: ldur            d0, [fp, #-0x80]
    // 0x852568: StoreField: r0->field_f = d0
    //     0x852568: stur            d0, [x0, #0xf]
    // 0x85256c: mov             x1, x0
    // 0x852570: ldur            d0, [fp, #-0x78]
    // 0x852574: r0 = /()
    //     0x852574: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x852578: ldr             x2, [fp, #0x10]
    // 0x85257c: stur            x0, [fp, #-0x70]
    // 0x852580: LoadField: r1 = r2->field_2f
    //     0x852580: ldur            x1, [x2, #0x2f]
    // 0x852584: stur            x1, [fp, #-0x30]
    // 0x852588: LoadField: r3 = r2->field_27
    //     0x852588: ldur            x3, [x2, #0x27]
    // 0x85258c: stur            x3, [fp, #-0x28]
    // 0x852590: LoadField: r4 = r2->field_ff
    //     0x852590: ldur            w4, [x2, #0xff]
    // 0x852594: DecompressPointer r4
    //     0x852594: add             x4, x4, HEAP, lsl #32
    // 0x852598: stur            x4, [fp, #-0x68]
    // 0x85259c: r17 = 259
    //     0x85259c: mov             x17, #0x103
    // 0x8525a0: ldr             w5, [x2, x17]
    // 0x8525a4: DecompressPointer r5
    //     0x8525a4: add             x5, x5, HEAP, lsl #32
    // 0x8525a8: stur            x5, [fp, #-0x58]
    // 0x8525ac: LoadField: r6 = r2->field_f
    //     0x8525ac: ldur            x6, [x2, #0xf]
    // 0x8525b0: stur            x6, [fp, #-0x18]
    // 0x8525b4: LoadField: r7 = r2->field_63
    //     0x8525b4: ldur            w7, [x2, #0x63]
    // 0x8525b8: DecompressPointer r7
    //     0x8525b8: add             x7, x7, HEAP, lsl #32
    // 0x8525bc: stur            x7, [fp, #-0x50]
    // 0x8525c0: r0 = PointerPanZoomUpdateEvent()
    //     0x8525c0: bl              #0x852ad8  ; AllocatePointerPanZoomUpdateEventStub -> PointerPanZoomUpdateEvent (size=0xd4)
    // 0x8525c4: mov             x1, x0
    // 0x8525c8: ldur            x0, [fp, #-0x20]
    // 0x8525cc: StoreField: r1->field_bb = r0
    //     0x8525cc: stur            w0, [x1, #0xbb]
    // 0x8525d0: ldur            x0, [fp, #-0x70]
    // 0x8525d4: StoreField: r1->field_bf = r0
    //     0x8525d4: stur            w0, [x1, #0xbf]
    // 0x8525d8: ldur            x0, [fp, #-0x68]
    // 0x8525dc: LoadField: d0 = r0->field_7
    //     0x8525dc: ldur            d0, [x0, #7]
    // 0x8525e0: StoreField: r1->field_c3 = d0
    //     0x8525e0: stur            d0, [x1, #0xc3]
    // 0x8525e4: ldur            x0, [fp, #-0x58]
    // 0x8525e8: LoadField: d0 = r0->field_7
    //     0x8525e8: ldur            d0, [x0, #7]
    // 0x8525ec: StoreField: r1->field_cb = d0
    //     0x8525ec: stur            d0, [x1, #0xcb]
    // 0x8525f0: ldur            x0, [fp, #-8]
    // 0x8525f4: StoreField: r1->field_7 = r0
    //     0x8525f4: stur            x0, [x1, #7]
    // 0x8525f8: ldur            x0, [fp, #-0x18]
    // 0x8525fc: StoreField: r1->field_f = r0
    //     0x8525fc: stur            x0, [x1, #0xf]
    // 0x852600: ldur            x3, [fp, #-0x48]
    // 0x852604: ArrayStore: r1[0] = r3  ; List_4
    //     0x852604: stur            w3, [x1, #0x17]
    // 0x852608: ldur            x0, [fp, #-0x30]
    // 0x85260c: StoreField: r1->field_1b = r0
    //     0x85260c: stur            x0, [x1, #0x1b]
    // 0x852610: r4 = Instance_PointerDeviceKind
    //     0x852610: ldr             x4, [PP, #0x4378]  ; [pp+0x4378] Obj!PointerDeviceKind@12c7ae1
    // 0x852614: StoreField: r1->field_23 = r4
    //     0x852614: stur            w4, [x1, #0x23]
    // 0x852618: ldur            x0, [fp, #-0x28]
    // 0x85261c: StoreField: r1->field_27 = r0
    //     0x85261c: stur            x0, [x1, #0x27]
    // 0x852620: ldur            x5, [fp, #-0x10]
    // 0x852624: StoreField: r1->field_2f = r5
    //     0x852624: stur            w5, [x1, #0x2f]
    // 0x852628: r6 = Instance_Offset
    //     0x852628: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x85262c: StoreField: r1->field_33 = r6
    //     0x85262c: stur            w6, [x1, #0x33]
    // 0x852630: StoreField: r1->field_37 = rZR
    //     0x852630: stur            xzr, [x1, #0x37]
    // 0x852634: r7 = false
    //     0x852634: add             x7, NULL, #0x30  ; false
    // 0x852638: StoreField: r1->field_3f = r7
    //     0x852638: stur            w7, [x1, #0x3f]
    // 0x85263c: StoreField: r1->field_43 = r7
    //     0x85263c: stur            w7, [x1, #0x43]
    // 0x852640: d0 = 1.000000
    //     0x852640: fmov            d0, #1.00000000
    // 0x852644: StoreField: r1->field_47 = d0
    //     0x852644: stur            d0, [x1, #0x47]
    // 0x852648: StoreField: r1->field_4f = d0
    //     0x852648: stur            d0, [x1, #0x4f]
    // 0x85264c: StoreField: r1->field_57 = d0
    //     0x85264c: stur            d0, [x1, #0x57]
    // 0x852650: StoreField: r1->field_5f = rZR
    //     0x852650: stur            xzr, [x1, #0x5f]
    // 0x852654: StoreField: r1->field_67 = rZR
    //     0x852654: stur            xzr, [x1, #0x67]
    // 0x852658: StoreField: r1->field_6f = rZR
    //     0x852658: stur            xzr, [x1, #0x6f]
    // 0x85265c: StoreField: r1->field_77 = rZR
    //     0x85265c: stur            xzr, [x1, #0x77]
    // 0x852660: StoreField: r1->field_7f = rZR
    //     0x852660: stur            xzr, [x1, #0x7f]
    // 0x852664: StoreField: r1->field_87 = rZR
    //     0x852664: stur            xzr, [x1, #0x87]
    // 0x852668: StoreField: r1->field_8f = rZR
    //     0x852668: stur            xzr, [x1, #0x8f]
    // 0x85266c: StoreField: r1->field_97 = rZR
    //     0x85266c: stur            xzr, [x1, #0x97]
    // 0x852670: StoreField: r1->field_9f = rZR
    //     0x852670: stur            xzr, [x1, #0x9f]
    // 0x852674: StoreField: r1->field_a7 = rZR
    //     0x852674: stur            xzr, [x1, #0xa7]
    // 0x852678: ldur            x0, [fp, #-0x50]
    // 0x85267c: StoreField: r1->field_af = r0
    //     0x85267c: stur            w0, [x1, #0xaf]
    // 0x852680: mov             x0, x1
    // 0x852684: LeaveFrame
    //     0x852684: mov             SP, fp
    //     0x852688: ldp             fp, lr, [SP], #0x10
    // 0x85268c: ret
    //     0x85268c: ret             
    // 0x852690: mov             x5, x6
    // 0x852694: mov             x6, x7
    // 0x852698: mov             x7, x8
    // 0x85269c: LoadField: r1 = r2->field_2f
    //     0x85269c: ldur            x1, [x2, #0x2f]
    // 0x8526a0: stur            x1, [fp, #-0x30]
    // 0x8526a4: LoadField: r8 = r2->field_27
    //     0x8526a4: ldur            x8, [x2, #0x27]
    // 0x8526a8: stur            x8, [fp, #-0x28]
    // 0x8526ac: LoadField: r9 = r2->field_f
    //     0x8526ac: ldur            x9, [x2, #0xf]
    // 0x8526b0: stur            x9, [fp, #-0x18]
    // 0x8526b4: LoadField: r10 = r2->field_63
    //     0x8526b4: ldur            w10, [x2, #0x63]
    // 0x8526b8: DecompressPointer r10
    //     0x8526b8: add             x10, x10, HEAP, lsl #32
    // 0x8526bc: stur            x10, [fp, #-0x20]
    // 0x8526c0: r0 = PointerPanZoomEndEvent()
    //     0x8526c0: bl              #0x852acc  ; AllocatePointerPanZoomEndEventStub -> PointerPanZoomEndEvent (size=0xbc)
    // 0x8526c4: ldur            x1, [fp, #-8]
    // 0x8526c8: StoreField: r0->field_7 = r1
    //     0x8526c8: stur            x1, [x0, #7]
    // 0x8526cc: ldur            x1, [fp, #-0x18]
    // 0x8526d0: StoreField: r0->field_f = r1
    //     0x8526d0: stur            x1, [x0, #0xf]
    // 0x8526d4: ldur            x3, [fp, #-0x48]
    // 0x8526d8: ArrayStore: r0[0] = r3  ; List_4
    //     0x8526d8: stur            w3, [x0, #0x17]
    // 0x8526dc: ldur            x1, [fp, #-0x30]
    // 0x8526e0: StoreField: r0->field_1b = r1
    //     0x8526e0: stur            x1, [x0, #0x1b]
    // 0x8526e4: r1 = Instance_PointerDeviceKind
    //     0x8526e4: ldr             x1, [PP, #0x4378]  ; [pp+0x4378] Obj!PointerDeviceKind@12c7ae1
    // 0x8526e8: StoreField: r0->field_23 = r1
    //     0x8526e8: stur            w1, [x0, #0x23]
    // 0x8526ec: ldur            x1, [fp, #-0x28]
    // 0x8526f0: StoreField: r0->field_27 = r1
    //     0x8526f0: stur            x1, [x0, #0x27]
    // 0x8526f4: ldur            x4, [fp, #-0x10]
    // 0x8526f8: StoreField: r0->field_2f = r4
    //     0x8526f8: stur            w4, [x0, #0x2f]
    // 0x8526fc: r5 = Instance_Offset
    //     0x8526fc: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852700: StoreField: r0->field_33 = r5
    //     0x852700: stur            w5, [x0, #0x33]
    // 0x852704: StoreField: r0->field_37 = rZR
    //     0x852704: stur            xzr, [x0, #0x37]
    // 0x852708: r6 = false
    //     0x852708: add             x6, NULL, #0x30  ; false
    // 0x85270c: StoreField: r0->field_3f = r6
    //     0x85270c: stur            w6, [x0, #0x3f]
    // 0x852710: StoreField: r0->field_43 = r6
    //     0x852710: stur            w6, [x0, #0x43]
    // 0x852714: d0 = 1.000000
    //     0x852714: fmov            d0, #1.00000000
    // 0x852718: StoreField: r0->field_47 = d0
    //     0x852718: stur            d0, [x0, #0x47]
    // 0x85271c: StoreField: r0->field_4f = d0
    //     0x85271c: stur            d0, [x0, #0x4f]
    // 0x852720: StoreField: r0->field_57 = d0
    //     0x852720: stur            d0, [x0, #0x57]
    // 0x852724: StoreField: r0->field_5f = rZR
    //     0x852724: stur            xzr, [x0, #0x5f]
    // 0x852728: StoreField: r0->field_67 = rZR
    //     0x852728: stur            xzr, [x0, #0x67]
    // 0x85272c: StoreField: r0->field_6f = rZR
    //     0x85272c: stur            xzr, [x0, #0x6f]
    // 0x852730: StoreField: r0->field_77 = rZR
    //     0x852730: stur            xzr, [x0, #0x77]
    // 0x852734: StoreField: r0->field_7f = rZR
    //     0x852734: stur            xzr, [x0, #0x7f]
    // 0x852738: StoreField: r0->field_87 = rZR
    //     0x852738: stur            xzr, [x0, #0x87]
    // 0x85273c: StoreField: r0->field_8f = rZR
    //     0x85273c: stur            xzr, [x0, #0x8f]
    // 0x852740: StoreField: r0->field_97 = rZR
    //     0x852740: stur            xzr, [x0, #0x97]
    // 0x852744: StoreField: r0->field_9f = rZR
    //     0x852744: stur            xzr, [x0, #0x9f]
    // 0x852748: StoreField: r0->field_a7 = rZR
    //     0x852748: stur            xzr, [x0, #0xa7]
    // 0x85274c: ldur            x1, [fp, #-0x20]
    // 0x852750: StoreField: r0->field_af = r1
    //     0x852750: stur            w1, [x0, #0xaf]
    // 0x852754: LeaveFrame
    //     0x852754: mov             SP, fp
    //     0x852758: ldp             fp, lr, [SP], #0x10
    // 0x85275c: ret
    //     0x85275c: ret             
    // 0x852760: mov             x0, x3
    // 0x852764: mov             x3, x1
    // 0x852768: ldur            x1, [fp, #-8]
    // 0x85276c: ldur            x4, [fp, #-0x10]
    // 0x852770: r6 = false
    //     0x852770: add             x6, NULL, #0x30  ; false
    // 0x852774: r5 = Instance_Offset
    //     0x852774: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852778: d0 = 1.000000
    //     0x852778: fmov            d0, #1.00000000
    // 0x85277c: LoadField: d1 = r2->field_cf
    //     0x85277c: ldur            d1, [x2, #0xcf]
    // 0x852780: stur            d1, [fp, #-0x88]
    // 0x852784: mov             x7, v1.d[0]
    // 0x852788: and             x7, x7, #0x7fffffffffffffff
    // 0x85278c: r17 = 9218868437227405312
    //     0x85278c: mov             x17, #0x7ff0000000000000
    // 0x852790: cmp             x7, x17
    // 0x852794: b.eq            #0x8528cc
    // 0x852798: fcmp            d1, d1
    // 0x85279c: b.vs            #0x8528cc
    // 0x8527a0: LoadField: d2 = r2->field_d7
    //     0x8527a0: ldur            d2, [x2, #0xd7]
    // 0x8527a4: stur            d2, [fp, #-0x80]
    // 0x8527a8: mov             x7, v2.d[0]
    // 0x8527ac: and             x7, x7, #0x7fffffffffffffff
    // 0x8527b0: r17 = 9218868437227405312
    //     0x8527b0: mov             x17, #0x7ff0000000000000
    // 0x8527b4: cmp             x7, x17
    // 0x8527b8: b.eq            #0x8528cc
    // 0x8527bc: fcmp            d2, d2
    // 0x8527c0: b.vs            #0x8528cc
    // 0x8527c4: ldur            d3, [fp, #-0x78]
    // 0x8527c8: d4 = 0.000000
    //     0x8527c8: eor             v4.16b, v4.16b, v4.16b
    // 0x8527cc: fcmp            d4, d3
    // 0x8527d0: b.ge            #0x8528cc
    // 0x8527d4: r0 = Offset()
    //     0x8527d4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8527d8: ldur            d0, [fp, #-0x88]
    // 0x8527dc: StoreField: r0->field_7 = d0
    //     0x8527dc: stur            d0, [x0, #7]
    // 0x8527e0: ldur            d0, [fp, #-0x80]
    // 0x8527e4: StoreField: r0->field_f = d0
    //     0x8527e4: stur            d0, [x0, #0xf]
    // 0x8527e8: mov             x1, x0
    // 0x8527ec: ldur            d0, [fp, #-0x78]
    // 0x8527f0: r0 = /()
    //     0x8527f0: bl              #0x852b44  ; [dart:ui] Offset::/
    // 0x8527f4: ldr             x2, [fp, #0x10]
    // 0x8527f8: stur            x0, [fp, #-0x20]
    // 0x8527fc: LoadField: r1 = r2->field_27
    //     0x8527fc: ldur            x1, [x2, #0x27]
    // 0x852800: stur            x1, [fp, #-0x28]
    // 0x852804: LoadField: r3 = r2->field_f
    //     0x852804: ldur            x3, [x2, #0xf]
    // 0x852808: stur            x3, [fp, #-0x18]
    // 0x85280c: r0 = PointerScrollEvent()
    //     0x85280c: bl              #0x852ac0  ; AllocatePointerScrollEventStub -> PointerScrollEvent (size=0xc4)
    // 0x852810: mov             x3, x0
    // 0x852814: ldur            x0, [fp, #-0x20]
    // 0x852818: stur            x3, [fp, #-0x50]
    // 0x85281c: StoreField: r3->field_bb = r0
    //     0x85281c: stur            w0, [x3, #0xbb]
    // 0x852820: ldr             x2, [fp, #0x10]
    // 0x852824: r1 = Function 'respond':.
    //     0x852824: ldr             x1, [PP, #0x4380]  ; [pp+0x4380] AnonymousClosure: (0x852d70), of [dart:ui] PointerData
    // 0x852828: r0 = AllocateClosure()
    //     0x852828: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x85282c: mov             x1, x0
    // 0x852830: ldur            x0, [fp, #-0x50]
    // 0x852834: StoreField: r0->field_bf = r1
    //     0x852834: stur            w1, [x0, #0xbf]
    // 0x852838: ldur            x1, [fp, #-8]
    // 0x85283c: StoreField: r0->field_7 = r1
    //     0x85283c: stur            x1, [x0, #7]
    // 0x852840: ldur            x1, [fp, #-0x18]
    // 0x852844: StoreField: r0->field_f = r1
    //     0x852844: stur            x1, [x0, #0xf]
    // 0x852848: ldur            x2, [fp, #-0x48]
    // 0x85284c: ArrayStore: r0[0] = r2  ; List_4
    //     0x85284c: stur            w2, [x0, #0x17]
    // 0x852850: StoreField: r0->field_1b = rZR
    //     0x852850: stur            xzr, [x0, #0x1b]
    // 0x852854: ldur            x3, [fp, #-0x40]
    // 0x852858: StoreField: r0->field_23 = r3
    //     0x852858: stur            w3, [x0, #0x23]
    // 0x85285c: ldur            x1, [fp, #-0x28]
    // 0x852860: StoreField: r0->field_27 = r1
    //     0x852860: stur            x1, [x0, #0x27]
    // 0x852864: ldur            x4, [fp, #-0x10]
    // 0x852868: StoreField: r0->field_2f = r4
    //     0x852868: stur            w4, [x0, #0x2f]
    // 0x85286c: r5 = Instance_Offset
    //     0x85286c: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852870: StoreField: r0->field_33 = r5
    //     0x852870: stur            w5, [x0, #0x33]
    // 0x852874: StoreField: r0->field_37 = rZR
    //     0x852874: stur            xzr, [x0, #0x37]
    // 0x852878: r6 = false
    //     0x852878: add             x6, NULL, #0x30  ; false
    // 0x85287c: StoreField: r0->field_3f = r6
    //     0x85287c: stur            w6, [x0, #0x3f]
    // 0x852880: StoreField: r0->field_43 = r6
    //     0x852880: stur            w6, [x0, #0x43]
    // 0x852884: d0 = 1.000000
    //     0x852884: fmov            d0, #1.00000000
    // 0x852888: StoreField: r0->field_47 = d0
    //     0x852888: stur            d0, [x0, #0x47]
    // 0x85288c: StoreField: r0->field_4f = d0
    //     0x85288c: stur            d0, [x0, #0x4f]
    // 0x852890: StoreField: r0->field_57 = d0
    //     0x852890: stur            d0, [x0, #0x57]
    // 0x852894: StoreField: r0->field_5f = rZR
    //     0x852894: stur            xzr, [x0, #0x5f]
    // 0x852898: StoreField: r0->field_67 = rZR
    //     0x852898: stur            xzr, [x0, #0x67]
    // 0x85289c: StoreField: r0->field_6f = rZR
    //     0x85289c: stur            xzr, [x0, #0x6f]
    // 0x8528a0: StoreField: r0->field_77 = rZR
    //     0x8528a0: stur            xzr, [x0, #0x77]
    // 0x8528a4: StoreField: r0->field_7f = rZR
    //     0x8528a4: stur            xzr, [x0, #0x7f]
    // 0x8528a8: StoreField: r0->field_87 = rZR
    //     0x8528a8: stur            xzr, [x0, #0x87]
    // 0x8528ac: StoreField: r0->field_8f = rZR
    //     0x8528ac: stur            xzr, [x0, #0x8f]
    // 0x8528b0: StoreField: r0->field_97 = rZR
    //     0x8528b0: stur            xzr, [x0, #0x97]
    // 0x8528b4: StoreField: r0->field_9f = rZR
    //     0x8528b4: stur            xzr, [x0, #0x9f]
    // 0x8528b8: StoreField: r0->field_a7 = rZR
    //     0x8528b8: stur            xzr, [x0, #0xa7]
    // 0x8528bc: StoreField: r0->field_af = r6
    //     0x8528bc: stur            w6, [x0, #0xaf]
    // 0x8528c0: LeaveFrame
    //     0x8528c0: mov             SP, fp
    //     0x8528c4: ldp             fp, lr, [SP], #0x10
    // 0x8528c8: ret
    //     0x8528c8: ret             
    // 0x8528cc: r0 = Null
    //     0x8528cc: mov             x0, NULL
    // 0x8528d0: LeaveFrame
    //     0x8528d0: mov             SP, fp
    //     0x8528d4: ldp             fp, lr, [SP], #0x10
    // 0x8528d8: ret
    //     0x8528d8: ret             
    // 0x8528dc: mov             x0, x2
    // 0x8528e0: mov             x2, x1
    // 0x8528e4: ldur            x1, [fp, #-8]
    // 0x8528e8: ldur            x4, [fp, #-0x10]
    // 0x8528ec: r6 = false
    //     0x8528ec: add             x6, NULL, #0x30  ; false
    // 0x8528f0: r5 = Instance_Offset
    //     0x8528f0: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8528f4: d0 = 1.000000
    //     0x8528f4: fmov            d0, #1.00000000
    // 0x8528f8: LoadField: r7 = r0->field_27
    //     0x8528f8: ldur            x7, [x0, #0x27]
    // 0x8528fc: stur            x7, [fp, #-0x28]
    // 0x852900: LoadField: r8 = r0->field_f
    //     0x852900: ldur            x8, [x0, #0xf]
    // 0x852904: stur            x8, [fp, #-0x18]
    // 0x852908: r0 = PointerScrollInertiaCancelEvent()
    //     0x852908: bl              #0x852ab4  ; AllocatePointerScrollInertiaCancelEventStub -> PointerScrollInertiaCancelEvent (size=0xbc)
    // 0x85290c: ldur            x1, [fp, #-8]
    // 0x852910: StoreField: r0->field_7 = r1
    //     0x852910: stur            x1, [x0, #7]
    // 0x852914: ldur            x1, [fp, #-0x18]
    // 0x852918: StoreField: r0->field_f = r1
    //     0x852918: stur            x1, [x0, #0xf]
    // 0x85291c: ldur            x2, [fp, #-0x48]
    // 0x852920: ArrayStore: r0[0] = r2  ; List_4
    //     0x852920: stur            w2, [x0, #0x17]
    // 0x852924: StoreField: r0->field_1b = rZR
    //     0x852924: stur            xzr, [x0, #0x1b]
    // 0x852928: ldur            x3, [fp, #-0x40]
    // 0x85292c: StoreField: r0->field_23 = r3
    //     0x85292c: stur            w3, [x0, #0x23]
    // 0x852930: ldur            x1, [fp, #-0x28]
    // 0x852934: StoreField: r0->field_27 = r1
    //     0x852934: stur            x1, [x0, #0x27]
    // 0x852938: ldur            x4, [fp, #-0x10]
    // 0x85293c: StoreField: r0->field_2f = r4
    //     0x85293c: stur            w4, [x0, #0x2f]
    // 0x852940: r6 = Instance_Offset
    //     0x852940: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852944: StoreField: r0->field_33 = r6
    //     0x852944: stur            w6, [x0, #0x33]
    // 0x852948: StoreField: r0->field_37 = rZR
    //     0x852948: stur            xzr, [x0, #0x37]
    // 0x85294c: r7 = false
    //     0x85294c: add             x7, NULL, #0x30  ; false
    // 0x852950: StoreField: r0->field_3f = r7
    //     0x852950: stur            w7, [x0, #0x3f]
    // 0x852954: StoreField: r0->field_43 = r7
    //     0x852954: stur            w7, [x0, #0x43]
    // 0x852958: d0 = 1.000000
    //     0x852958: fmov            d0, #1.00000000
    // 0x85295c: StoreField: r0->field_47 = d0
    //     0x85295c: stur            d0, [x0, #0x47]
    // 0x852960: StoreField: r0->field_4f = d0
    //     0x852960: stur            d0, [x0, #0x4f]
    // 0x852964: StoreField: r0->field_57 = d0
    //     0x852964: stur            d0, [x0, #0x57]
    // 0x852968: StoreField: r0->field_5f = rZR
    //     0x852968: stur            xzr, [x0, #0x5f]
    // 0x85296c: StoreField: r0->field_67 = rZR
    //     0x85296c: stur            xzr, [x0, #0x67]
    // 0x852970: StoreField: r0->field_6f = rZR
    //     0x852970: stur            xzr, [x0, #0x6f]
    // 0x852974: StoreField: r0->field_77 = rZR
    //     0x852974: stur            xzr, [x0, #0x77]
    // 0x852978: StoreField: r0->field_7f = rZR
    //     0x852978: stur            xzr, [x0, #0x7f]
    // 0x85297c: StoreField: r0->field_87 = rZR
    //     0x85297c: stur            xzr, [x0, #0x87]
    // 0x852980: StoreField: r0->field_8f = rZR
    //     0x852980: stur            xzr, [x0, #0x8f]
    // 0x852984: StoreField: r0->field_97 = rZR
    //     0x852984: stur            xzr, [x0, #0x97]
    // 0x852988: StoreField: r0->field_9f = rZR
    //     0x852988: stur            xzr, [x0, #0x9f]
    // 0x85298c: StoreField: r0->field_a7 = rZR
    //     0x85298c: stur            xzr, [x0, #0xa7]
    // 0x852990: StoreField: r0->field_af = r7
    //     0x852990: stur            w7, [x0, #0xaf]
    // 0x852994: LeaveFrame
    //     0x852994: mov             SP, fp
    //     0x852998: ldp             fp, lr, [SP], #0x10
    // 0x85299c: ret
    //     0x85299c: ret             
    // 0x8529a0: mov             x0, x2
    // 0x8529a4: mov             x2, x1
    // 0x8529a8: ldur            x1, [fp, #-8]
    // 0x8529ac: ldur            x4, [fp, #-0x10]
    // 0x8529b0: r7 = false
    //     0x8529b0: add             x7, NULL, #0x30  ; false
    // 0x8529b4: r6 = Instance_Offset
    //     0x8529b4: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8529b8: d0 = 1.000000
    //     0x8529b8: fmov            d0, #1.00000000
    // 0x8529bc: cmp             x5, #3
    // 0x8529c0: b.gt            #0x852a84
    // 0x8529c4: LoadField: r5 = r0->field_27
    //     0x8529c4: ldur            x5, [x0, #0x27]
    // 0x8529c8: stur            x5, [fp, #-0x28]
    // 0x8529cc: LoadField: r8 = r0->field_f
    //     0x8529cc: ldur            x8, [x0, #0xf]
    // 0x8529d0: stur            x8, [fp, #-0x18]
    // 0x8529d4: LoadField: r9 = r0->field_ff
    //     0x8529d4: ldur            w9, [x0, #0xff]
    // 0x8529d8: DecompressPointer r9
    //     0x8529d8: add             x9, x9, HEAP, lsl #32
    // 0x8529dc: LoadField: d1 = r9->field_7
    //     0x8529dc: ldur            d1, [x9, #7]
    // 0x8529e0: stur            d1, [fp, #-0x78]
    // 0x8529e4: r0 = PointerScaleEvent()
    //     0x8529e4: bl              #0x852aa8  ; AllocatePointerScaleEventStub -> PointerScaleEvent (size=0xc4)
    // 0x8529e8: ldur            d0, [fp, #-0x78]
    // 0x8529ec: StoreField: r0->field_bb = d0
    //     0x8529ec: stur            d0, [x0, #0xbb]
    // 0x8529f0: ldur            x1, [fp, #-8]
    // 0x8529f4: StoreField: r0->field_7 = r1
    //     0x8529f4: stur            x1, [x0, #7]
    // 0x8529f8: ldur            x1, [fp, #-0x18]
    // 0x8529fc: StoreField: r0->field_f = r1
    //     0x8529fc: stur            x1, [x0, #0xf]
    // 0x852a00: ldur            x1, [fp, #-0x48]
    // 0x852a04: ArrayStore: r0[0] = r1  ; List_4
    //     0x852a04: stur            w1, [x0, #0x17]
    // 0x852a08: StoreField: r0->field_1b = rZR
    //     0x852a08: stur            xzr, [x0, #0x1b]
    // 0x852a0c: ldur            x1, [fp, #-0x40]
    // 0x852a10: StoreField: r0->field_23 = r1
    //     0x852a10: stur            w1, [x0, #0x23]
    // 0x852a14: ldur            x1, [fp, #-0x28]
    // 0x852a18: StoreField: r0->field_27 = r1
    //     0x852a18: stur            x1, [x0, #0x27]
    // 0x852a1c: ldur            x1, [fp, #-0x10]
    // 0x852a20: StoreField: r0->field_2f = r1
    //     0x852a20: stur            w1, [x0, #0x2f]
    // 0x852a24: r1 = Instance_Offset
    //     0x852a24: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x852a28: StoreField: r0->field_33 = r1
    //     0x852a28: stur            w1, [x0, #0x33]
    // 0x852a2c: StoreField: r0->field_37 = rZR
    //     0x852a2c: stur            xzr, [x0, #0x37]
    // 0x852a30: r1 = false
    //     0x852a30: add             x1, NULL, #0x30  ; false
    // 0x852a34: StoreField: r0->field_3f = r1
    //     0x852a34: stur            w1, [x0, #0x3f]
    // 0x852a38: StoreField: r0->field_43 = r1
    //     0x852a38: stur            w1, [x0, #0x43]
    // 0x852a3c: d0 = 1.000000
    //     0x852a3c: fmov            d0, #1.00000000
    // 0x852a40: StoreField: r0->field_47 = d0
    //     0x852a40: stur            d0, [x0, #0x47]
    // 0x852a44: StoreField: r0->field_4f = d0
    //     0x852a44: stur            d0, [x0, #0x4f]
    // 0x852a48: StoreField: r0->field_57 = d0
    //     0x852a48: stur            d0, [x0, #0x57]
    // 0x852a4c: StoreField: r0->field_5f = rZR
    //     0x852a4c: stur            xzr, [x0, #0x5f]
    // 0x852a50: StoreField: r0->field_67 = rZR
    //     0x852a50: stur            xzr, [x0, #0x67]
    // 0x852a54: StoreField: r0->field_6f = rZR
    //     0x852a54: stur            xzr, [x0, #0x6f]
    // 0x852a58: StoreField: r0->field_77 = rZR
    //     0x852a58: stur            xzr, [x0, #0x77]
    // 0x852a5c: StoreField: r0->field_7f = rZR
    //     0x852a5c: stur            xzr, [x0, #0x7f]
    // 0x852a60: StoreField: r0->field_87 = rZR
    //     0x852a60: stur            xzr, [x0, #0x87]
    // 0x852a64: StoreField: r0->field_8f = rZR
    //     0x852a64: stur            xzr, [x0, #0x8f]
    // 0x852a68: StoreField: r0->field_97 = rZR
    //     0x852a68: stur            xzr, [x0, #0x97]
    // 0x852a6c: StoreField: r0->field_9f = rZR
    //     0x852a6c: stur            xzr, [x0, #0x9f]
    // 0x852a70: StoreField: r0->field_a7 = rZR
    //     0x852a70: stur            xzr, [x0, #0xa7]
    // 0x852a74: StoreField: r0->field_af = r1
    //     0x852a74: stur            w1, [x0, #0xaf]
    // 0x852a78: LeaveFrame
    //     0x852a78: mov             SP, fp
    //     0x852a7c: ldp             fp, lr, [SP], #0x10
    // 0x852a80: ret
    //     0x852a80: ret             
    // 0x852a84: r0 = StateError()
    //     0x852a84: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x852a88: mov             x1, x0
    // 0x852a8c: r0 = "Unreachable"
    //     0x852a8c: ldr             x0, [PP, #0x4388]  ; [pp+0x4388] "Unreachable"
    // 0x852a90: StoreField: r1->field_b = r0
    //     0x852a90: stur            w0, [x1, #0xb]
    // 0x852a94: mov             x0, x1
    // 0x852a98: r0 = Throw()
    //     0x852a98: bl              #0x13ddb2c  ; ThrowStub
    // 0x852a9c: brk             #0
    // 0x852aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852aa0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852aa4: b               #0x85191c
  }
  [closure] static bool <anonymous closure>(dynamic, PointerData) {
    // ** addr: 0x852d88, size: 0x24
    // 0x852d88: ldr             x1, [SP]
    // 0x852d8c: LoadField: r2 = r1->field_23
    //     0x852d8c: ldur            w2, [x1, #0x23]
    // 0x852d90: DecompressPointer r2
    //     0x852d90: add             x2, x2, HEAP, lsl #32
    // 0x852d94: r16 = Instance_PointerSignalKind
    //     0x852d94: ldr             x16, [PP, #0x4390]  ; [pp+0x4390] Obj!PointerSignalKind@12c7a21
    // 0x852d98: cmp             w2, w16
    // 0x852d9c: r16 = true
    //     0x852d9c: add             x16, NULL, #0x20  ; true
    // 0x852da0: r17 = false
    //     0x852da0: add             x17, NULL, #0x30  ; false
    // 0x852da4: csel            x0, x16, x17, ne
    // 0x852da8: ret
    //     0x852da8: ret             
  }
}
