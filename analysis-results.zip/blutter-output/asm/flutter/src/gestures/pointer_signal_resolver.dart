// lib: , url: package:flutter/src/gestures/pointer_signal_resolver.dart

// class id: 1048830, size: 0x8
class :: {
}

// class id: 3157, size: 0x10, field offset: 0x8
class PointerSignalResolver extends Object {

  void resolve(PointerSignalResolver, PointerSignalEvent) {
    // ** addr: 0x89f424, size: 0x98
    // 0x89f424: EnterFrame
    //     0x89f424: stp             fp, lr, [SP, #-0x10]!
    //     0x89f428: mov             fp, SP
    // 0x89f42c: CheckStackOverflow
    //     0x89f42c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f430: cmp             SP, x16
    //     0x89f434: b.ls            #0x89f49c
    // 0x89f438: ldr             x0, [fp, #0x10]
    // 0x89f43c: r2 = Null
    //     0x89f43c: mov             x2, NULL
    // 0x89f440: r1 = Null
    //     0x89f440: mov             x1, NULL
    // 0x89f444: r4 = 60
    //     0x89f444: mov             x4, #0x3c
    // 0x89f448: branchIfSmi(r0, 0x89f454)
    //     0x89f448: tbz             w0, #0, #0x89f454
    // 0x89f44c: r4 = LoadClassIdInstr(r0)
    //     0x89f44c: ldur            x4, [x0, #-1]
    //     0x89f450: ubfx            x4, x4, #0xc, #0x14
    // 0x89f454: r17 = -4148
    //     0x89f454: mov             x17, #-0x1034
    // 0x89f458: add             x4, x4, x17
    // 0x89f45c: cmp             x4, #5
    // 0x89f460: b.ls            #0x89f484
    // 0x89f464: sub             x4, x4, #0x458
    // 0x89f468: cmp             x4, #4
    // 0x89f46c: b.ls            #0x89f484
    // 0x89f470: r8 = PointerSignalEvent
    //     0x89f470: add             x8, PP, #0x82, lsl #12  ; [pp+0x82920] Type: PointerSignalEvent
    //     0x89f474: ldr             x8, [x8, #0x920]
    // 0x89f478: r3 = Null
    //     0x89f478: add             x3, PP, #0x82, lsl #12  ; [pp+0x82928] Null
    //     0x89f47c: ldr             x3, [x3, #0x928]
    // 0x89f480: r0 = DefaultTypeTest()
    //     0x89f480: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x89f484: ldr             x1, [fp, #0x18]
    // 0x89f488: ldr             x2, [fp, #0x10]
    // 0x89f48c: r0 = resolve()
    //     0x89f48c: bl              #0x89f4a4  ; [package:flutter/src/gestures/pointer_signal_resolver.dart] PointerSignalResolver::resolve
    // 0x89f490: LeaveFrame
    //     0x89f490: mov             SP, fp
    //     0x89f494: ldp             fp, lr, [SP], #0x10
    // 0x89f498: ret
    //     0x89f498: ret             
    // 0x89f49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f49c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f4a0: b               #0x89f438
  }
  void resolve(PointerSignalResolver, PointerSignalEvent) {
    // ** addr: 0x89f4a4, size: 0x120
    // 0x89f4a4: EnterFrame
    //     0x89f4a4: stp             fp, lr, [SP, #-0x10]!
    //     0x89f4a8: mov             fp, SP
    // 0x89f4ac: AllocStack(0x80)
    //     0x89f4ac: sub             SP, SP, #0x80
    // 0x89f4b0: SetupParameters(PointerSignalResolver this /* r1 => r2, fp-0x60 */, dynamic _ /* r2 => r1 */)
    //     0x89f4b0: stur            x1, [fp, #-0x60]
    //     0x89f4b4: mov             x16, x2
    //     0x89f4b8: mov             x2, x1
    //     0x89f4bc: mov             x1, x16
    // 0x89f4c0: CheckStackOverflow
    //     0x89f4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f4c4: cmp             SP, x16
    //     0x89f4c8: b.ls            #0x89f5b8
    // 0x89f4cc: LoadField: r3 = r2->field_7
    //     0x89f4cc: ldur            w3, [x2, #7]
    // 0x89f4d0: DecompressPointer r3
    //     0x89f4d0: add             x3, x3, HEAP, lsl #32
    // 0x89f4d4: stur            x3, [fp, #-0x58]
    // 0x89f4d8: cmp             w3, NULL
    // 0x89f4dc: b.ne            #0x89f50c
    // 0x89f4e0: r0 = LoadClassIdInstr(r1)
    //     0x89f4e0: ldur            x0, [x1, #-1]
    //     0x89f4e4: ubfx            x0, x0, #0xc, #0x14
    // 0x89f4e8: r2 = true
    //     0x89f4e8: add             x2, NULL, #0x20  ; true
    // 0x89f4ec: r0 = GDT[cid_x0 + 0x1654]()
    //     0x89f4ec: mov             x17, #0x1654
    //     0x89f4f0: add             lr, x0, x17
    //     0x89f4f4: ldr             lr, [x21, lr, lsl #3]
    //     0x89f4f8: blr             lr
    // 0x89f4fc: r0 = Null
    //     0x89f4fc: mov             x0, NULL
    // 0x89f500: LeaveFrame
    //     0x89f500: mov             SP, fp
    //     0x89f504: ldp             fp, lr, [SP], #0x10
    // 0x89f508: ret
    //     0x89f508: ret             
    // 0x89f50c: LoadField: r0 = r2->field_b
    //     0x89f50c: ldur            w0, [x2, #0xb]
    // 0x89f510: DecompressPointer r0
    //     0x89f510: add             x0, x0, HEAP, lsl #32
    // 0x89f514: cmp             w0, NULL
    // 0x89f518: b.eq            #0x89f5c0
    // 0x89f51c: stp             x0, x3, [SP]
    // 0x89f520: mov             x0, x3
    // 0x89f524: ClosureCall
    //     0x89f524: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x89f528: ldur            x2, [x0, #0x1f]
    //     0x89f52c: blr             x2
    // 0x89f530: b               #0x89f59c
    // 0x89f534: sub             SP, fp, #0x80
    // 0x89f538: mov             x2, x0
    // 0x89f53c: stur            x0, [fp, #-0x58]
    // 0x89f540: mov             x0, x1
    // 0x89f544: stur            x1, [fp, #-0x68]
    // 0x89f548: r1 = <List<Object>>
    //     0x89f548: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x89f54c: r0 = ErrorDescription()
    //     0x89f54c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x89f550: mov             x1, x0
    // 0x89f554: r2 = "while resolving a PointerSignalEvent"
    //     0x89f554: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3a8] "while resolving a PointerSignalEvent"
    //     0x89f558: ldr             x2, [x2, #0x3a8]
    // 0x89f55c: r3 = Instance_DiagnosticLevel
    //     0x89f55c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x89f560: stur            x0, [fp, #-0x70]
    // 0x89f564: r0 = _ErrorDiagnostic()
    //     0x89f564: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x89f568: r0 = FlutterErrorDetails()
    //     0x89f568: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x89f56c: mov             x1, x0
    // 0x89f570: ldur            x0, [fp, #-0x58]
    // 0x89f574: StoreField: r1->field_7 = r0
    //     0x89f574: stur            w0, [x1, #7]
    // 0x89f578: ldur            x0, [fp, #-0x68]
    // 0x89f57c: StoreField: r1->field_b = r0
    //     0x89f57c: stur            w0, [x1, #0xb]
    // 0x89f580: r0 = "gesture library"
    //     0x89f580: ldr             x0, [PP, #0x42f0]  ; [pp+0x42f0] "gesture library"
    // 0x89f584: StoreField: r1->field_f = r0
    //     0x89f584: stur            w0, [x1, #0xf]
    // 0x89f588: ldur            x0, [fp, #-0x70]
    // 0x89f58c: StoreField: r1->field_13 = r0
    //     0x89f58c: stur            w0, [x1, #0x13]
    // 0x89f590: r0 = false
    //     0x89f590: add             x0, NULL, #0x30  ; false
    // 0x89f594: StoreField: r1->field_1b = r0
    //     0x89f594: stur            w0, [x1, #0x1b]
    // 0x89f598: r0 = reportError()
    //     0x89f598: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x89f59c: ldur            x1, [fp, #-0x60]
    // 0x89f5a0: StoreField: r1->field_7 = rNULL
    //     0x89f5a0: stur            NULL, [x1, #7]
    // 0x89f5a4: StoreField: r1->field_b = rNULL
    //     0x89f5a4: stur            NULL, [x1, #0xb]
    // 0x89f5a8: r0 = Null
    //     0x89f5a8: mov             x0, NULL
    // 0x89f5ac: LeaveFrame
    //     0x89f5ac: mov             SP, fp
    //     0x89f5b0: ldp             fp, lr, [SP], #0x10
    // 0x89f5b4: ret
    //     0x89f5b4: ret             
    // 0x89f5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f5b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f5bc: b               #0x89f4cc
    // 0x89f5c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89f5c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ register(/* No info */) {
    // ** addr: 0xd3aa08, size: 0x80
    // 0xd3aa08: EnterFrame
    //     0xd3aa08: stp             fp, lr, [SP, #-0x10]!
    //     0xd3aa0c: mov             fp, SP
    // 0xd3aa10: mov             x0, x2
    // 0xd3aa14: mov             x2, x1
    // 0xd3aa18: mov             x1, x3
    // 0xd3aa1c: LoadField: r3 = r2->field_7
    //     0xd3aa1c: ldur            w3, [x2, #7]
    // 0xd3aa20: DecompressPointer r3
    //     0xd3aa20: add             x3, x3, HEAP, lsl #32
    // 0xd3aa24: cmp             w3, NULL
    // 0xd3aa28: b.eq            #0xd3aa3c
    // 0xd3aa2c: r0 = Null
    //     0xd3aa2c: mov             x0, NULL
    // 0xd3aa30: LeaveFrame
    //     0xd3aa30: mov             SP, fp
    //     0xd3aa34: ldp             fp, lr, [SP], #0x10
    // 0xd3aa38: ret
    //     0xd3aa38: ret             
    // 0xd3aa3c: StoreField: r2->field_b = r0
    //     0xd3aa3c: stur            w0, [x2, #0xb]
    //     0xd3aa40: ldurb           w16, [x2, #-1]
    //     0xd3aa44: ldurb           w17, [x0, #-1]
    //     0xd3aa48: and             x16, x17, x16, lsr #2
    //     0xd3aa4c: tst             x16, HEAP, lsr #32
    //     0xd3aa50: b.eq            #0xd3aa58
    //     0xd3aa54: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3aa58: mov             x0, x1
    // 0xd3aa5c: StoreField: r2->field_7 = r0
    //     0xd3aa5c: stur            w0, [x2, #7]
    //     0xd3aa60: ldurb           w16, [x2, #-1]
    //     0xd3aa64: ldurb           w17, [x0, #-1]
    //     0xd3aa68: and             x16, x17, x16, lsr #2
    //     0xd3aa6c: tst             x16, HEAP, lsr #32
    //     0xd3aa70: b.eq            #0xd3aa78
    //     0xd3aa74: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3aa78: r0 = Null
    //     0xd3aa78: mov             x0, NULL
    // 0xd3aa7c: LeaveFrame
    //     0xd3aa7c: mov             SP, fp
    //     0xd3aa80: ldp             fp, lr, [SP], #0x10
    // 0xd3aa84: ret
    //     0xd3aa84: ret             
  }
}
