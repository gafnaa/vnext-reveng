// lib: , url: package:flutter/src/gestures/long_press.dart

// class id: 1048825, size: 0x8
class :: {
}

// class id: 4439, size: 0xac, field offset: 0x48
class LongPressGestureRecognizer extends PrimaryPointerGestureRecognizer {

  void resolve(LongPressGestureRecognizer, GestureDisposition) {
    // ** addr: 0xba05a0, size: 0x88
    // 0xba05a0: EnterFrame
    //     0xba05a0: stp             fp, lr, [SP, #-0x10]!
    //     0xba05a4: mov             fp, SP
    // 0xba05a8: CheckStackOverflow
    //     0xba05a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba05ac: cmp             SP, x16
    //     0xba05b0: b.ls            #0xba0608
    // 0xba05b4: ldr             x0, [fp, #0x10]
    // 0xba05b8: r2 = Null
    //     0xba05b8: mov             x2, NULL
    // 0xba05bc: r1 = Null
    //     0xba05bc: mov             x1, NULL
    // 0xba05c0: r4 = 60
    //     0xba05c0: mov             x4, #0x3c
    // 0xba05c4: branchIfSmi(r0, 0xba05d0)
    //     0xba05c4: tbz             w0, #0, #0xba05d0
    // 0xba05c8: r4 = LoadClassIdInstr(r0)
    //     0xba05c8: ldur            x4, [x0, #-1]
    //     0xba05cc: ubfx            x4, x4, #0xc, #0x14
    // 0xba05d0: r17 = 8312
    //     0xba05d0: mov             x17, #0x2078
    // 0xba05d4: cmp             x4, x17
    // 0xba05d8: b.eq            #0xba05f0
    // 0xba05dc: r8 = GestureDisposition
    //     0xba05dc: add             x8, PP, #0x81, lsl #12  ; [pp+0x81d30] Type: GestureDisposition
    //     0xba05e0: ldr             x8, [x8, #0xd30]
    // 0xba05e4: r3 = Null
    //     0xba05e4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cdc8] Null
    //     0xba05e8: ldr             x3, [x3, #0xdc8]
    // 0xba05ec: r0 = DefaultTypeTest()
    //     0xba05ec: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xba05f0: ldr             x1, [fp, #0x18]
    // 0xba05f4: ldr             x2, [fp, #0x10]
    // 0xba05f8: r0 = resolve()
    //     0xba05f8: bl              #0xd01720  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0xba05fc: LeaveFrame
    //     0xba05fc: mov             SP, fp
    //     0xba0600: ldp             fp, lr, [SP], #0x10
    // 0xba0604: ret
    //     0xba0604: ret             
    // 0xba0608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba0608: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba060c: b               #0xba05b4
  }
  _ _checkLongPressCancel(/* No info */) {
    // ** addr: 0xba06bc, size: 0x7c
    // 0xba06bc: EnterFrame
    //     0xba06bc: stp             fp, lr, [SP, #-0x10]!
    //     0xba06c0: mov             fp, SP
    // 0xba06c4: AllocStack(0x18)
    //     0xba06c4: sub             SP, SP, #0x18
    // 0xba06c8: CheckStackOverflow
    //     0xba06c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba06cc: cmp             SP, x16
    //     0xba06d0: b.ls            #0xba0730
    // 0xba06d4: LoadField: r0 = r1->field_33
    //     0xba06d4: ldur            w0, [x1, #0x33]
    // 0xba06d8: DecompressPointer r0
    //     0xba06d8: add             x0, x0, HEAP, lsl #32
    // 0xba06dc: r16 = Instance_GestureRecognizerState
    //     0xba06dc: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cdd8] Obj!GestureRecognizerState@12c5be1
    //     0xba06e0: ldr             x16, [x16, #0xdd8]
    // 0xba06e4: cmp             w0, w16
    // 0xba06e8: b.ne            #0xba0720
    // 0xba06ec: LoadField: r0 = r1->field_4f
    //     0xba06ec: ldur            w0, [x1, #0x4f]
    // 0xba06f0: DecompressPointer r0
    //     0xba06f0: add             x0, x0, HEAP, lsl #32
    // 0xba06f4: cmp             w0, #2
    // 0xba06f8: b.ne            #0xba0720
    // 0xba06fc: LoadField: r0 = r1->field_57
    //     0xba06fc: ldur            w0, [x1, #0x57]
    // 0xba0700: DecompressPointer r0
    //     0xba0700: add             x0, x0, HEAP, lsl #32
    // 0xba0704: cmp             w0, NULL
    // 0xba0708: b.eq            #0xba0720
    // 0xba070c: r16 = <void?>
    //     0xba070c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba0710: stp             x1, x16, [SP, #8]
    // 0xba0714: str             x0, [SP]
    // 0xba0718: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba0718: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba071c: r0 = invokeCallback()
    //     0xba071c: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba0720: r0 = Null
    //     0xba0720: mov             x0, NULL
    // 0xba0724: LeaveFrame
    //     0xba0724: mov             SP, fp
    //     0xba0728: ldp             fp, lr, [SP], #0x10
    // 0xba072c: ret
    //     0xba072c: ret             
    // 0xba0730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba0730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba0734: b               #0xba06d4
  }
  _ _reset(/* No info */) {
    // ** addr: 0xba0738, size: 0x1c
    // 0xba0738: r2 = false
    //     0xba0738: add             x2, NULL, #0x30  ; false
    // 0xba073c: StoreField: r1->field_47 = r2
    //     0xba073c: stur            w2, [x1, #0x47]
    // 0xba0740: StoreField: r1->field_4b = rNULL
    //     0xba0740: stur            NULL, [x1, #0x4b]
    // 0xba0744: StoreField: r1->field_4f = rNULL
    //     0xba0744: stur            NULL, [x1, #0x4f]
    // 0xba0748: StoreField: r1->field_a7 = rNULL
    //     0xba0748: stur            NULL, [x1, #0xa7]
    // 0xba074c: r0 = Null
    //     0xba074c: mov             x0, NULL
    // 0xba0750: ret
    //     0xba0750: ret             
  }
  _ _checkLongPressStart(/* No info */) {
    // ** addr: 0xba8200, size: 0x104
    // 0xba8200: EnterFrame
    //     0xba8200: stp             fp, lr, [SP, #-0x10]!
    //     0xba8204: mov             fp, SP
    // 0xba8208: AllocStack(0x38)
    //     0xba8208: sub             SP, SP, #0x38
    // 0xba820c: SetupParameters(LongPressGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xba820c: stur            x1, [fp, #-8]
    // 0xba8210: CheckStackOverflow
    //     0xba8210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8214: cmp             SP, x16
    //     0xba8218: b.ls            #0xba82f8
    // 0xba821c: r1 = 2
    //     0xba821c: mov             x1, #2
    // 0xba8220: r0 = AllocateContext()
    //     0xba8220: bl              #0x13de838  ; AllocateContextStub
    // 0xba8224: mov             x1, x0
    // 0xba8228: ldur            x0, [fp, #-8]
    // 0xba822c: stur            x1, [fp, #-0x20]
    // 0xba8230: StoreField: r1->field_f = r0
    //     0xba8230: stur            w0, [x1, #0xf]
    // 0xba8234: LoadField: r2 = r0->field_4f
    //     0xba8234: ldur            w2, [x0, #0x4f]
    // 0xba8238: DecompressPointer r2
    //     0xba8238: add             x2, x2, HEAP, lsl #32
    // 0xba823c: cmp             w2, #2
    // 0xba8240: b.ne            #0xba82e8
    // 0xba8244: LoadField: r2 = r0->field_5f
    //     0xba8244: ldur            w2, [x0, #0x5f]
    // 0xba8248: DecompressPointer r2
    //     0xba8248: add             x2, x2, HEAP, lsl #32
    // 0xba824c: cmp             w2, NULL
    // 0xba8250: b.eq            #0xba82c0
    // 0xba8254: LoadField: r2 = r0->field_4b
    //     0xba8254: ldur            w2, [x0, #0x4b]
    // 0xba8258: DecompressPointer r2
    //     0xba8258: add             x2, x2, HEAP, lsl #32
    // 0xba825c: cmp             w2, NULL
    // 0xba8260: b.eq            #0xba8300
    // 0xba8264: LoadField: r3 = r2->field_b
    //     0xba8264: ldur            w3, [x2, #0xb]
    // 0xba8268: DecompressPointer r3
    //     0xba8268: add             x3, x3, HEAP, lsl #32
    // 0xba826c: stur            x3, [fp, #-0x18]
    // 0xba8270: LoadField: r4 = r2->field_7
    //     0xba8270: ldur            w4, [x2, #7]
    // 0xba8274: DecompressPointer r4
    //     0xba8274: add             x4, x4, HEAP, lsl #32
    // 0xba8278: stur            x4, [fp, #-0x10]
    // 0xba827c: r0 = LongPressStartDetails()
    //     0xba827c: bl              #0xba8304  ; AllocateLongPressStartDetailsStub -> LongPressStartDetails (size=0x10)
    // 0xba8280: mov             x1, x0
    // 0xba8284: ldur            x0, [fp, #-0x18]
    // 0xba8288: StoreField: r1->field_7 = r0
    //     0xba8288: stur            w0, [x1, #7]
    // 0xba828c: ldur            x0, [fp, #-0x10]
    // 0xba8290: StoreField: r1->field_b = r0
    //     0xba8290: stur            w0, [x1, #0xb]
    // 0xba8294: ldur            x2, [fp, #-0x20]
    // 0xba8298: StoreField: r2->field_13 = r1
    //     0xba8298: stur            w1, [x2, #0x13]
    // 0xba829c: r1 = Function '<anonymous closure>':.
    //     0xba829c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98618] AnonymousClosure: (0xba8310), in [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressStart (0xba8200)
    //     0xba82a0: ldr             x1, [x1, #0x618]
    // 0xba82a4: r0 = AllocateClosure()
    //     0xba82a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba82a8: r16 = <void?>
    //     0xba82a8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba82ac: ldur            lr, [fp, #-8]
    // 0xba82b0: stp             lr, x16, [SP, #8]
    // 0xba82b4: str             x0, [SP]
    // 0xba82b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba82b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba82bc: r0 = invokeCallback()
    //     0xba82bc: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba82c0: ldur            x0, [fp, #-8]
    // 0xba82c4: LoadField: r1 = r0->field_5b
    //     0xba82c4: ldur            w1, [x0, #0x5b]
    // 0xba82c8: DecompressPointer r1
    //     0xba82c8: add             x1, x1, HEAP, lsl #32
    // 0xba82cc: cmp             w1, NULL
    // 0xba82d0: b.eq            #0xba82e8
    // 0xba82d4: r16 = <void?>
    //     0xba82d4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba82d8: stp             x0, x16, [SP, #8]
    // 0xba82dc: str             x1, [SP]
    // 0xba82e0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba82e0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba82e4: r0 = invokeCallback()
    //     0xba82e4: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xba82e8: r0 = Null
    //     0xba82e8: mov             x0, NULL
    // 0xba82ec: LeaveFrame
    //     0xba82ec: mov             SP, fp
    //     0xba82f0: ldp             fp, lr, [SP], #0x10
    // 0xba82f4: ret
    //     0xba82f4: ret             
    // 0xba82f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba82f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba82fc: b               #0xba821c
    // 0xba8300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba8300: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xba8310, size: 0x70
    // 0xba8310: EnterFrame
    //     0xba8310: stp             fp, lr, [SP, #-0x10]!
    //     0xba8314: mov             fp, SP
    // 0xba8318: AllocStack(0x10)
    //     0xba8318: sub             SP, SP, #0x10
    // 0xba831c: SetupParameters([dynamic _ /* r0 */])
    //     0xba831c: ldr             x0, [fp, #0x10]
    //     0xba8320: ldur            w1, [x0, #0x17]
    //     0xba8324: add             x1, x1, HEAP, lsl #32
    // 0xba8328: CheckStackOverflow
    //     0xba8328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba832c: cmp             SP, x16
    //     0xba8330: b.ls            #0xba8374
    // 0xba8334: LoadField: r0 = r1->field_f
    //     0xba8334: ldur            w0, [x1, #0xf]
    // 0xba8338: DecompressPointer r0
    //     0xba8338: add             x0, x0, HEAP, lsl #32
    // 0xba833c: LoadField: r2 = r0->field_5f
    //     0xba833c: ldur            w2, [x0, #0x5f]
    // 0xba8340: DecompressPointer r2
    //     0xba8340: add             x2, x2, HEAP, lsl #32
    // 0xba8344: cmp             w2, NULL
    // 0xba8348: b.eq            #0xba837c
    // 0xba834c: LoadField: r0 = r1->field_13
    //     0xba834c: ldur            w0, [x1, #0x13]
    // 0xba8350: DecompressPointer r0
    //     0xba8350: add             x0, x0, HEAP, lsl #32
    // 0xba8354: stp             x0, x2, [SP]
    // 0xba8358: mov             x0, x2
    // 0xba835c: ClosureCall
    //     0xba835c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba8360: ldur            x2, [x0, #0x1f]
    //     0xba8364: blr             x2
    // 0xba8368: LeaveFrame
    //     0xba8368: mov             SP, fp
    //     0xba836c: ldp             fp, lr, [SP], #0x10
    // 0xba8370: ret
    //     0xba8370: ret             
    // 0xba8374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8378: b               #0xba8334
    // 0xba837c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba837c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xbb6e94, size: 0x158
    // 0xbb6e94: EnterFrame
    //     0xbb6e94: stp             fp, lr, [SP, #-0x10]!
    //     0xbb6e98: mov             fp, SP
    // 0xbb6e9c: AllocStack(0x10)
    //     0xbb6e9c: sub             SP, SP, #0x10
    // 0xbb6ea0: SetupParameters(LongPressGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbb6ea0: mov             x3, x1
    //     0xbb6ea4: stur            x1, [fp, #-8]
    //     0xbb6ea8: stur            x2, [fp, #-0x10]
    // 0xbb6eac: CheckStackOverflow
    //     0xbb6eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb6eb0: cmp             SP, x16
    //     0xbb6eb4: b.ls            #0xbb6fe4
    // 0xbb6eb8: r0 = LoadClassIdInstr(r2)
    //     0xbb6eb8: ldur            x0, [x2, #-1]
    //     0xbb6ebc: ubfx            x0, x0, #0xc, #0x14
    // 0xbb6ec0: mov             x1, x2
    // 0xbb6ec4: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0xbb6ec4: mov             x17, #0x6f9c
    //     0xbb6ec8: movk            x17, #1, lsl #16
    //     0xbb6ecc: add             lr, x0, x17
    //     0xbb6ed0: ldr             lr, [x21, lr, lsl #3]
    //     0xbb6ed4: blr             lr
    // 0xbb6ed8: mov             x2, x0
    // 0xbb6edc: cmp             x2, #2
    // 0xbb6ee0: b.gt            #0xbb6fa0
    // 0xbb6ee4: cmp             x2, #1
    // 0xbb6ee8: b.gt            #0xbb6f90
    // 0xbb6eec: r0 = BoxInt64Instr(r2)
    //     0xbb6eec: sbfiz           x0, x2, #1, #0x1f
    //     0xbb6ef0: cmp             x2, x0, asr #1
    //     0xbb6ef4: b.eq            #0xbb6f00
    //     0xbb6ef8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb6efc: stur            x2, [x0, #7]
    // 0xbb6f00: cmp             w0, #2
    // 0xbb6f04: b.ne            #0xbb6fd4
    // 0xbb6f08: ldur            x1, [fp, #-8]
    // 0xbb6f0c: LoadField: r0 = r1->field_57
    //     0xbb6f0c: ldur            w0, [x1, #0x57]
    // 0xbb6f10: DecompressPointer r0
    //     0xbb6f10: add             x0, x0, HEAP, lsl #32
    // 0xbb6f14: cmp             w0, NULL
    // 0xbb6f18: b.ne            #0xbb6f7c
    // 0xbb6f1c: LoadField: r0 = r1->field_5f
    //     0xbb6f1c: ldur            w0, [x1, #0x5f]
    // 0xbb6f20: DecompressPointer r0
    //     0xbb6f20: add             x0, x0, HEAP, lsl #32
    // 0xbb6f24: cmp             w0, NULL
    // 0xbb6f28: b.ne            #0xbb6f7c
    // 0xbb6f2c: LoadField: r0 = r1->field_5b
    //     0xbb6f2c: ldur            w0, [x1, #0x5b]
    // 0xbb6f30: DecompressPointer r0
    //     0xbb6f30: add             x0, x0, HEAP, lsl #32
    // 0xbb6f34: cmp             w0, NULL
    // 0xbb6f38: b.ne            #0xbb6f7c
    // 0xbb6f3c: LoadField: r0 = r1->field_63
    //     0xbb6f3c: ldur            w0, [x1, #0x63]
    // 0xbb6f40: DecompressPointer r0
    //     0xbb6f40: add             x0, x0, HEAP, lsl #32
    // 0xbb6f44: cmp             w0, NULL
    // 0xbb6f48: b.ne            #0xbb6f7c
    // 0xbb6f4c: LoadField: r0 = r1->field_6b
    //     0xbb6f4c: ldur            w0, [x1, #0x6b]
    // 0xbb6f50: DecompressPointer r0
    //     0xbb6f50: add             x0, x0, HEAP, lsl #32
    // 0xbb6f54: cmp             w0, NULL
    // 0xbb6f58: b.ne            #0xbb6f7c
    // 0xbb6f5c: LoadField: r0 = r1->field_67
    //     0xbb6f5c: ldur            w0, [x1, #0x67]
    // 0xbb6f60: DecompressPointer r0
    //     0xbb6f60: add             x0, x0, HEAP, lsl #32
    // 0xbb6f64: cmp             w0, NULL
    // 0xbb6f68: b.ne            #0xbb6f7c
    // 0xbb6f6c: r0 = false
    //     0xbb6f6c: add             x0, NULL, #0x30  ; false
    // 0xbb6f70: LeaveFrame
    //     0xbb6f70: mov             SP, fp
    //     0xbb6f74: ldp             fp, lr, [SP], #0x10
    // 0xbb6f78: ret
    //     0xbb6f78: ret             
    // 0xbb6f7c: ldur            x2, [fp, #-0x10]
    // 0xbb6f80: r0 = isPointerAllowed()
    //     0xbb6f80: bl              #0xbb75f8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xbb6f84: LeaveFrame
    //     0xbb6f84: mov             SP, fp
    //     0xbb6f88: ldp             fp, lr, [SP], #0x10
    // 0xbb6f8c: ret
    //     0xbb6f8c: ret             
    // 0xbb6f90: r0 = false
    //     0xbb6f90: add             x0, NULL, #0x30  ; false
    // 0xbb6f94: LeaveFrame
    //     0xbb6f94: mov             SP, fp
    //     0xbb6f98: ldp             fp, lr, [SP], #0x10
    // 0xbb6f9c: ret
    //     0xbb6f9c: ret             
    // 0xbb6fa0: cmp             x2, #4
    // 0xbb6fa4: b.lt            #0xbb6fd4
    // 0xbb6fa8: r0 = BoxInt64Instr(r2)
    //     0xbb6fa8: sbfiz           x0, x2, #1, #0x1f
    //     0xbb6fac: cmp             x2, x0, asr #1
    //     0xbb6fb0: b.eq            #0xbb6fbc
    //     0xbb6fb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbb6fb8: stur            x2, [x0, #7]
    // 0xbb6fbc: cmp             w0, #8
    // 0xbb6fc0: b.ne            #0xbb6fd4
    // 0xbb6fc4: r0 = false
    //     0xbb6fc4: add             x0, NULL, #0x30  ; false
    // 0xbb6fc8: LeaveFrame
    //     0xbb6fc8: mov             SP, fp
    //     0xbb6fcc: ldp             fp, lr, [SP], #0x10
    // 0xbb6fd0: ret
    //     0xbb6fd0: ret             
    // 0xbb6fd4: r0 = false
    //     0xbb6fd4: add             x0, NULL, #0x30  ; false
    // 0xbb6fd8: LeaveFrame
    //     0xbb6fd8: mov             SP, fp
    //     0xbb6fdc: ldp             fp, lr, [SP], #0x10
    // 0xbb6fe0: ret
    //     0xbb6fe0: ret             
    // 0xbb6fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb6fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb6fe8: b               #0xbb6eb8
  }
  [closure] static bool _defaultButtonAcceptBehavior(dynamic, int) {
    // ** addr: 0xc0a540, size: 0x40
    // 0xc0a540: ldr             x1, [SP]
    // 0xc0a544: r2 = LoadInt32Instr(r1)
    //     0xc0a544: sbfx            x2, x1, #1, #0x1f
    //     0xc0a548: tbz             w1, #0, #0xc0a550
    //     0xc0a54c: ldur            x2, [x1, #7]
    // 0xc0a550: cmp             x2, #1
    // 0xc0a554: b.eq            #0xc0a560
    // 0xc0a558: cmp             x2, #2
    // 0xc0a55c: b.ne            #0xc0a568
    // 0xc0a560: r0 = true
    //     0xc0a560: add             x0, NULL, #0x20  ; true
    // 0xc0a564: b               #0xc0a57c
    // 0xc0a568: cmp             x2, #4
    // 0xc0a56c: r16 = true
    //     0xc0a56c: add             x16, NULL, #0x20  ; true
    // 0xc0a570: r17 = false
    //     0xc0a570: add             x17, NULL, #0x30  ; false
    // 0xc0a574: csel            x1, x16, x17, eq
    // 0xc0a578: mov             x0, x1
    // 0xc0a57c: ret
    //     0xc0a57c: ret             
  }
  void resolve(LongPressGestureRecognizer, GestureDisposition) {
    // ** addr: 0xd01720, size: 0x78
    // 0xd01720: EnterFrame
    //     0xd01720: stp             fp, lr, [SP, #-0x10]!
    //     0xd01724: mov             fp, SP
    // 0xd01728: AllocStack(0x10)
    //     0xd01728: sub             SP, SP, #0x10
    // 0xd0172c: SetupParameters(LongPressGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd0172c: mov             x0, x1
    //     0xd01730: stur            x1, [fp, #-8]
    //     0xd01734: stur            x2, [fp, #-0x10]
    // 0xd01738: CheckStackOverflow
    //     0xd01738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0173c: cmp             SP, x16
    //     0xd01740: b.ls            #0xd01790
    // 0xd01744: r16 = Instance_GestureDisposition
    //     0xd01744: add             x16, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xd01748: ldr             x16, [x16, #0x610]
    // 0xd0174c: cmp             w2, w16
    // 0xd01750: b.ne            #0xd01774
    // 0xd01754: LoadField: r1 = r0->field_47
    //     0xd01754: ldur            w1, [x0, #0x47]
    // 0xd01758: DecompressPointer r1
    //     0xd01758: add             x1, x1, HEAP, lsl #32
    // 0xd0175c: tbnz            w1, #4, #0xd0176c
    // 0xd01760: mov             x1, x0
    // 0xd01764: r0 = _reset()
    //     0xd01764: bl              #0xba0738  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0xd01768: b               #0xd01774
    // 0xd0176c: ldur            x1, [fp, #-8]
    // 0xd01770: r0 = _checkLongPressCancel()
    //     0xd01770: bl              #0xba06bc  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0xd01774: ldur            x1, [fp, #-8]
    // 0xd01778: ldur            x2, [fp, #-0x10]
    // 0xd0177c: r0 = resolve()
    //     0xd0177c: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xd01780: r0 = Null
    //     0xd01780: mov             x0, NULL
    // 0xd01784: LeaveFrame
    //     0xd01784: mov             SP, fp
    //     0xd01788: ldp             fp, lr, [SP], #0x10
    // 0xd0178c: ret
    //     0xd0178c: ret             
    // 0xd01790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01794: b               #0xd01744
  }
  _ handlePrimaryPointer(/* No info */) {
    // ** addr: 0x11ad54c, size: 0x554
    // 0x11ad54c: EnterFrame
    //     0x11ad54c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ad550: mov             fp, SP
    // 0x11ad554: AllocStack(0x20)
    //     0x11ad554: sub             SP, SP, #0x20
    // 0x11ad558: SetupParameters(LongPressGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11ad558: mov             x3, x1
    //     0x11ad55c: stur            x1, [fp, #-8]
    //     0x11ad560: stur            x2, [fp, #-0x10]
    // 0x11ad564: CheckStackOverflow
    //     0x11ad564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ad568: cmp             SP, x16
    //     0x11ad56c: b.ls            #0x11ada90
    // 0x11ad570: r0 = LoadClassIdInstr(r2)
    //     0x11ad570: ldur            x0, [x2, #-1]
    //     0x11ad574: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad578: mov             x1, x2
    // 0x11ad57c: r0 = GDT[cid_x0 + 0x15474]()
    //     0x11ad57c: mov             x17, #0x5474
    //     0x11ad580: movk            x17, #1, lsl #16
    //     0x11ad584: add             lr, x0, x17
    //     0x11ad588: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad58c: blr             lr
    // 0x11ad590: tbz             w0, #4, #0x11ad778
    // 0x11ad594: ldur            x0, [fp, #-0x10]
    // 0x11ad598: r2 = Null
    //     0x11ad598: mov             x2, NULL
    // 0x11ad59c: r1 = Null
    //     0x11ad59c: mov             x1, NULL
    // 0x11ad5a0: cmp             w0, NULL
    // 0x11ad5a4: b.eq            #0x11ad5cc
    // 0x11ad5a8: branchIfSmi(r0, 0x11ad5cc)
    //     0x11ad5a8: tbz             w0, #0, #0x11ad5cc
    // 0x11ad5ac: r3 = LoadClassIdInstr(r0)
    //     0x11ad5ac: ldur            x3, [x0, #-1]
    //     0x11ad5b0: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad5b4: r17 = 4159
    //     0x11ad5b4: mov             x17, #0x103f
    // 0x11ad5b8: cmp             x3, x17
    // 0x11ad5bc: b.eq            #0x11ad5d4
    // 0x11ad5c0: r17 = 5288
    //     0x11ad5c0: mov             x17, #0x14a8
    // 0x11ad5c4: cmp             x3, x17
    // 0x11ad5c8: b.eq            #0x11ad5d4
    // 0x11ad5cc: r0 = false
    //     0x11ad5cc: add             x0, NULL, #0x30  ; false
    // 0x11ad5d0: b               #0x11ad5d8
    // 0x11ad5d4: r0 = true
    //     0x11ad5d4: add             x0, NULL, #0x20  ; true
    // 0x11ad5d8: tbnz            w0, #4, #0x11ad6b8
    // 0x11ad5dc: ldur            x3, [fp, #-8]
    // 0x11ad5e0: ldur            x2, [fp, #-0x10]
    // 0x11ad5e4: r0 = LoadClassIdInstr(r2)
    //     0x11ad5e4: ldur            x0, [x2, #-1]
    //     0x11ad5e8: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad5ec: mov             x1, x2
    // 0x11ad5f0: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x11ad5f0: mov             x17, #0x5e74
    //     0x11ad5f4: movk            x17, #1, lsl #16
    //     0x11ad5f8: add             lr, x0, x17
    //     0x11ad5fc: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad600: blr             lr
    // 0x11ad604: stur            x0, [fp, #-0x18]
    // 0x11ad608: r0 = VelocityTracker()
    //     0x11ad608: bl              #0xadee64  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x1c)
    // 0x11ad60c: stur            x0, [fp, #-0x20]
    // 0x11ad610: StoreField: r0->field_13 = rZR
    //     0x11ad610: stur            xzr, [x0, #0x13]
    // 0x11ad614: r1 = <_PointAtTime?>
    //     0x11ad614: add             x1, PP, #0x15, lsl #12  ; [pp+0x15568] TypeArguments: <_PointAtTime?>
    //     0x11ad618: ldr             x1, [x1, #0x568]
    // 0x11ad61c: r2 = 40
    //     0x11ad61c: mov             x2, #0x28
    // 0x11ad620: r0 = AllocateArray()
    //     0x11ad620: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ad624: ldur            x2, [fp, #-0x20]
    // 0x11ad628: StoreField: r2->field_f = r0
    //     0x11ad628: stur            w0, [x2, #0xf]
    // 0x11ad62c: ldur            x0, [fp, #-0x18]
    // 0x11ad630: StoreField: r2->field_7 = r0
    //     0x11ad630: stur            w0, [x2, #7]
    // 0x11ad634: mov             x0, x2
    // 0x11ad638: ldur            x3, [fp, #-8]
    // 0x11ad63c: StoreField: r3->field_a7 = r0
    //     0x11ad63c: stur            w0, [x3, #0xa7]
    //     0x11ad640: ldurb           w16, [x3, #-1]
    //     0x11ad644: ldurb           w17, [x0, #-1]
    //     0x11ad648: and             x16, x17, x16, lsr #2
    //     0x11ad64c: tst             x16, HEAP, lsr #32
    //     0x11ad650: b.eq            #0x11ad658
    //     0x11ad654: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11ad658: ldur            x4, [fp, #-0x10]
    // 0x11ad65c: r0 = LoadClassIdInstr(r4)
    //     0x11ad65c: ldur            x0, [x4, #-1]
    //     0x11ad660: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad664: mov             x1, x4
    // 0x11ad668: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0x11ad668: mov             x17, #0x5eb5
    //     0x11ad66c: movk            x17, #1, lsl #16
    //     0x11ad670: add             lr, x0, x17
    //     0x11ad674: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad678: blr             lr
    // 0x11ad67c: mov             x3, x0
    // 0x11ad680: ldur            x2, [fp, #-0x10]
    // 0x11ad684: stur            x3, [fp, #-0x18]
    // 0x11ad688: r0 = LoadClassIdInstr(r2)
    //     0x11ad688: ldur            x0, [x2, #-1]
    //     0x11ad68c: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad690: mov             x1, x2
    // 0x11ad694: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11ad694: mov             x17, #0x54ea
    //     0x11ad698: movk            x17, #1, lsl #16
    //     0x11ad69c: add             lr, x0, x17
    //     0x11ad6a0: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad6a4: blr             lr
    // 0x11ad6a8: ldur            x1, [fp, #-0x20]
    // 0x11ad6ac: ldur            x2, [fp, #-0x18]
    // 0x11ad6b0: mov             x3, x0
    // 0x11ad6b4: r0 = addPosition()
    //     0x11ad6b4: bl              #0x12fef8c  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0x11ad6b8: ldur            x0, [fp, #-0x10]
    // 0x11ad6bc: r2 = Null
    //     0x11ad6bc: mov             x2, NULL
    // 0x11ad6c0: r1 = Null
    //     0x11ad6c0: mov             x1, NULL
    // 0x11ad6c4: cmp             w0, NULL
    // 0x11ad6c8: b.eq            #0x11ad6f0
    // 0x11ad6cc: branchIfSmi(r0, 0x11ad6f0)
    //     0x11ad6cc: tbz             w0, #0, #0x11ad6f0
    // 0x11ad6d0: r3 = LoadClassIdInstr(r0)
    //     0x11ad6d0: ldur            x3, [x0, #-1]
    //     0x11ad6d4: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad6d8: r17 = 4157
    //     0x11ad6d8: mov             x17, #0x103d
    // 0x11ad6dc: cmp             x3, x17
    // 0x11ad6e0: b.eq            #0x11ad6f8
    // 0x11ad6e4: r17 = 5286
    //     0x11ad6e4: mov             x17, #0x14a6
    // 0x11ad6e8: cmp             x3, x17
    // 0x11ad6ec: b.eq            #0x11ad6f8
    // 0x11ad6f0: r0 = false
    //     0x11ad6f0: add             x0, NULL, #0x30  ; false
    // 0x11ad6f4: b               #0x11ad6fc
    // 0x11ad6f8: r0 = true
    //     0x11ad6f8: add             x0, NULL, #0x20  ; true
    // 0x11ad6fc: tbnz            w0, #4, #0x11ad778
    // 0x11ad700: ldur            x3, [fp, #-8]
    // 0x11ad704: ldur            x2, [fp, #-0x10]
    // 0x11ad708: LoadField: r4 = r3->field_a7
    //     0x11ad708: ldur            w4, [x3, #0xa7]
    // 0x11ad70c: DecompressPointer r4
    //     0x11ad70c: add             x4, x4, HEAP, lsl #32
    // 0x11ad710: stur            x4, [fp, #-0x18]
    // 0x11ad714: cmp             w4, NULL
    // 0x11ad718: b.eq            #0x11ada98
    // 0x11ad71c: r0 = LoadClassIdInstr(r2)
    //     0x11ad71c: ldur            x0, [x2, #-1]
    //     0x11ad720: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad724: mov             x1, x2
    // 0x11ad728: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0x11ad728: mov             x17, #0x5eb5
    //     0x11ad72c: movk            x17, #1, lsl #16
    //     0x11ad730: add             lr, x0, x17
    //     0x11ad734: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad738: blr             lr
    // 0x11ad73c: mov             x3, x0
    // 0x11ad740: ldur            x2, [fp, #-0x10]
    // 0x11ad744: stur            x3, [fp, #-0x20]
    // 0x11ad748: r0 = LoadClassIdInstr(r2)
    //     0x11ad748: ldur            x0, [x2, #-1]
    //     0x11ad74c: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad750: mov             x1, x2
    // 0x11ad754: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11ad754: mov             x17, #0x54ea
    //     0x11ad758: movk            x17, #1, lsl #16
    //     0x11ad75c: add             lr, x0, x17
    //     0x11ad760: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad764: blr             lr
    // 0x11ad768: ldur            x1, [fp, #-0x18]
    // 0x11ad76c: ldur            x2, [fp, #-0x20]
    // 0x11ad770: mov             x3, x0
    // 0x11ad774: r0 = addPosition()
    //     0x11ad774: bl              #0x12fef8c  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0x11ad778: ldur            x0, [fp, #-0x10]
    // 0x11ad77c: r2 = Null
    //     0x11ad77c: mov             x2, NULL
    // 0x11ad780: r1 = Null
    //     0x11ad780: mov             x1, NULL
    // 0x11ad784: cmp             w0, NULL
    // 0x11ad788: b.eq            #0x11ad7b0
    // 0x11ad78c: branchIfSmi(r0, 0x11ad7b0)
    //     0x11ad78c: tbz             w0, #0, #0x11ad7b0
    // 0x11ad790: r3 = LoadClassIdInstr(r0)
    //     0x11ad790: ldur            x3, [x0, #-1]
    //     0x11ad794: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad798: r17 = 4155
    //     0x11ad798: mov             x17, #0x103b
    // 0x11ad79c: cmp             x3, x17
    // 0x11ad7a0: b.eq            #0x11ad7b8
    // 0x11ad7a4: r17 = 5284
    //     0x11ad7a4: mov             x17, #0x14a4
    // 0x11ad7a8: cmp             x3, x17
    // 0x11ad7ac: b.eq            #0x11ad7b8
    // 0x11ad7b0: r0 = false
    //     0x11ad7b0: add             x0, NULL, #0x30  ; false
    // 0x11ad7b4: b               #0x11ad7bc
    // 0x11ad7b8: r0 = true
    //     0x11ad7b8: add             x0, NULL, #0x20  ; true
    // 0x11ad7bc: tbnz            w0, #4, #0x11ad7fc
    // 0x11ad7c0: ldur            x0, [fp, #-8]
    // 0x11ad7c4: LoadField: r1 = r0->field_47
    //     0x11ad7c4: ldur            w1, [x0, #0x47]
    // 0x11ad7c8: DecompressPointer r1
    //     0x11ad7c8: add             x1, x1, HEAP, lsl #32
    // 0x11ad7cc: tbnz            w1, #4, #0x11ad7e0
    // 0x11ad7d0: mov             x1, x0
    // 0x11ad7d4: ldur            x2, [fp, #-0x10]
    // 0x11ad7d8: r0 = _checkLongPressEnd()
    //     0x11ad7d8: bl              #0x11add60  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressEnd
    // 0x11ad7dc: b               #0x11ad7f0
    // 0x11ad7e0: ldur            x1, [fp, #-8]
    // 0x11ad7e4: r2 = Instance_GestureDisposition
    //     0x11ad7e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0x11ad7e8: ldr             x2, [x2, #0x610]
    // 0x11ad7ec: r0 = resolve()
    //     0x11ad7ec: bl              #0xd01720  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0x11ad7f0: ldur            x1, [fp, #-8]
    // 0x11ad7f4: r0 = _reset()
    //     0x11ad7f4: bl              #0xba0738  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0x11ad7f8: b               #0x11ada80
    // 0x11ad7fc: ldur            x0, [fp, #-0x10]
    // 0x11ad800: r2 = Null
    //     0x11ad800: mov             x2, NULL
    // 0x11ad804: r1 = Null
    //     0x11ad804: mov             x1, NULL
    // 0x11ad808: cmp             w0, NULL
    // 0x11ad80c: b.eq            #0x11ad834
    // 0x11ad810: branchIfSmi(r0, 0x11ad834)
    //     0x11ad810: tbz             w0, #0, #0x11ad834
    // 0x11ad814: r3 = LoadClassIdInstr(r0)
    //     0x11ad814: ldur            x3, [x0, #-1]
    //     0x11ad818: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad81c: r17 = 4139
    //     0x11ad81c: mov             x17, #0x102b
    // 0x11ad820: cmp             x3, x17
    // 0x11ad824: b.eq            #0x11ad83c
    // 0x11ad828: r17 = 5276
    //     0x11ad828: mov             x17, #0x149c
    // 0x11ad82c: cmp             x3, x17
    // 0x11ad830: b.eq            #0x11ad83c
    // 0x11ad834: r0 = false
    //     0x11ad834: add             x0, NULL, #0x30  ; false
    // 0x11ad838: b               #0x11ad840
    // 0x11ad83c: r0 = true
    //     0x11ad83c: add             x0, NULL, #0x20  ; true
    // 0x11ad840: tbnz            w0, #4, #0x11ad858
    // 0x11ad844: ldur            x1, [fp, #-8]
    // 0x11ad848: r0 = _checkLongPressCancel()
    //     0x11ad848: bl              #0xba06bc  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0x11ad84c: ldur            x1, [fp, #-8]
    // 0x11ad850: r0 = _reset()
    //     0x11ad850: bl              #0xba0738  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0x11ad854: b               #0x11ada80
    // 0x11ad858: ldur            x0, [fp, #-0x10]
    // 0x11ad85c: r2 = Null
    //     0x11ad85c: mov             x2, NULL
    // 0x11ad860: r1 = Null
    //     0x11ad860: mov             x1, NULL
    // 0x11ad864: cmp             w0, NULL
    // 0x11ad868: b.eq            #0x11ad890
    // 0x11ad86c: branchIfSmi(r0, 0x11ad890)
    //     0x11ad86c: tbz             w0, #0, #0x11ad890
    // 0x11ad870: r3 = LoadClassIdInstr(r0)
    //     0x11ad870: ldur            x3, [x0, #-1]
    //     0x11ad874: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad878: r17 = 4159
    //     0x11ad878: mov             x17, #0x103f
    // 0x11ad87c: cmp             x3, x17
    // 0x11ad880: b.eq            #0x11ad898
    // 0x11ad884: r17 = 5288
    //     0x11ad884: mov             x17, #0x14a8
    // 0x11ad888: cmp             x3, x17
    // 0x11ad88c: b.eq            #0x11ad898
    // 0x11ad890: r0 = false
    //     0x11ad890: add             x0, NULL, #0x30  ; false
    // 0x11ad894: b               #0x11ad89c
    // 0x11ad898: r0 = true
    //     0x11ad898: add             x0, NULL, #0x20  ; true
    // 0x11ad89c: tbnz            w0, #4, #0x11ad950
    // 0x11ad8a0: ldur            x1, [fp, #-8]
    // 0x11ad8a4: ldur            x2, [fp, #-0x10]
    // 0x11ad8a8: r0 = OffsetPair()
    //     0x11ad8a8: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x11ad8ac: mov             x1, x0
    // 0x11ad8b0: ldur            x2, [fp, #-0x10]
    // 0x11ad8b4: stur            x0, [fp, #-0x18]
    // 0x11ad8b8: r0 = OffsetPair.fromEventPosition()
    //     0x11ad8b8: bl              #0xb98730  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0x11ad8bc: ldur            x0, [fp, #-0x18]
    // 0x11ad8c0: ldur            x2, [fp, #-8]
    // 0x11ad8c4: StoreField: r2->field_4b = r0
    //     0x11ad8c4: stur            w0, [x2, #0x4b]
    //     0x11ad8c8: ldurb           w16, [x2, #-1]
    //     0x11ad8cc: ldurb           w17, [x0, #-1]
    //     0x11ad8d0: and             x16, x17, x16, lsr #2
    //     0x11ad8d4: tst             x16, HEAP, lsr #32
    //     0x11ad8d8: b.eq            #0x11ad8e0
    //     0x11ad8dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11ad8e0: ldur            x3, [fp, #-0x10]
    // 0x11ad8e4: r0 = LoadClassIdInstr(r3)
    //     0x11ad8e4: ldur            x0, [x3, #-1]
    //     0x11ad8e8: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad8ec: mov             x1, x3
    // 0x11ad8f0: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11ad8f0: mov             x17, #0x6f9c
    //     0x11ad8f4: movk            x17, #1, lsl #16
    //     0x11ad8f8: add             lr, x0, x17
    //     0x11ad8fc: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad900: blr             lr
    // 0x11ad904: mov             x2, x0
    // 0x11ad908: r0 = BoxInt64Instr(r2)
    //     0x11ad908: sbfiz           x0, x2, #1, #0x1f
    //     0x11ad90c: cmp             x2, x0, asr #1
    //     0x11ad910: b.eq            #0x11ad91c
    //     0x11ad914: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11ad918: stur            x2, [x0, #7]
    // 0x11ad91c: ldur            x3, [fp, #-8]
    // 0x11ad920: StoreField: r3->field_4f = r0
    //     0x11ad920: stur            w0, [x3, #0x4f]
    //     0x11ad924: tbz             w0, #0, #0x11ad940
    //     0x11ad928: ldurb           w16, [x3, #-1]
    //     0x11ad92c: ldurb           w17, [x0, #-1]
    //     0x11ad930: and             x16, x17, x16, lsr #2
    //     0x11ad934: tst             x16, HEAP, lsr #32
    //     0x11ad938: b.eq            #0x11ad940
    //     0x11ad93c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11ad940: mov             x1, x3
    // 0x11ad944: ldur            x2, [fp, #-0x10]
    // 0x11ad948: r0 = _checkLongPressDown()
    //     0x11ad948: bl              #0x11adcec  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressDown
    // 0x11ad94c: b               #0x11ada80
    // 0x11ad950: ldur            x3, [fp, #-8]
    // 0x11ad954: ldur            x0, [fp, #-0x10]
    // 0x11ad958: r2 = Null
    //     0x11ad958: mov             x2, NULL
    // 0x11ad95c: r1 = Null
    //     0x11ad95c: mov             x1, NULL
    // 0x11ad960: cmp             w0, NULL
    // 0x11ad964: b.eq            #0x11ad98c
    // 0x11ad968: branchIfSmi(r0, 0x11ad98c)
    //     0x11ad968: tbz             w0, #0, #0x11ad98c
    // 0x11ad96c: r3 = LoadClassIdInstr(r0)
    //     0x11ad96c: ldur            x3, [x0, #-1]
    //     0x11ad970: ubfx            x3, x3, #0xc, #0x14
    // 0x11ad974: r17 = 4157
    //     0x11ad974: mov             x17, #0x103d
    // 0x11ad978: cmp             x3, x17
    // 0x11ad97c: b.eq            #0x11ad994
    // 0x11ad980: r17 = 5286
    //     0x11ad980: mov             x17, #0x14a6
    // 0x11ad984: cmp             x3, x17
    // 0x11ad988: b.eq            #0x11ad994
    // 0x11ad98c: r0 = false
    //     0x11ad98c: add             x0, NULL, #0x30  ; false
    // 0x11ad990: b               #0x11ad998
    // 0x11ad994: r0 = true
    //     0x11ad994: add             x0, NULL, #0x20  ; true
    // 0x11ad998: tbnz            w0, #4, #0x11ada80
    // 0x11ad99c: ldur            x2, [fp, #-8]
    // 0x11ad9a0: ldur            x3, [fp, #-0x10]
    // 0x11ad9a4: r0 = LoadClassIdInstr(r3)
    //     0x11ad9a4: ldur            x0, [x3, #-1]
    //     0x11ad9a8: ubfx            x0, x0, #0xc, #0x14
    // 0x11ad9ac: mov             x1, x3
    // 0x11ad9b0: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x11ad9b0: mov             x17, #0x6f9c
    //     0x11ad9b4: movk            x17, #1, lsl #16
    //     0x11ad9b8: add             lr, x0, x17
    //     0x11ad9bc: ldr             lr, [x21, lr, lsl #3]
    //     0x11ad9c0: blr             lr
    // 0x11ad9c4: mov             x2, x0
    // 0x11ad9c8: ldur            x3, [fp, #-8]
    // 0x11ad9cc: LoadField: r4 = r3->field_4f
    //     0x11ad9cc: ldur            w4, [x3, #0x4f]
    // 0x11ad9d0: DecompressPointer r4
    //     0x11ad9d0: add             x4, x4, HEAP, lsl #32
    // 0x11ad9d4: r0 = BoxInt64Instr(r2)
    //     0x11ad9d4: sbfiz           x0, x2, #1, #0x1f
    //     0x11ad9d8: cmp             x2, x0, asr #1
    //     0x11ad9dc: b.eq            #0x11ad9e8
    //     0x11ad9e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11ad9e4: stur            x2, [x0, #7]
    // 0x11ad9e8: cmp             w0, w4
    // 0x11ad9ec: b.eq            #0x11ada68
    // 0x11ad9f0: and             w16, w0, w4
    // 0x11ad9f4: branchIfSmi(r16, 0x11ada28)
    //     0x11ad9f4: tbz             w16, #0, #0x11ada28
    // 0x11ad9f8: r16 = LoadClassIdInstr(r0)
    //     0x11ad9f8: ldur            x16, [x0, #-1]
    //     0x11ad9fc: ubfx            x16, x16, #0xc, #0x14
    // 0x11ada00: cmp             x16, #0x3d
    // 0x11ada04: b.ne            #0x11ada28
    // 0x11ada08: r16 = LoadClassIdInstr(r4)
    //     0x11ada08: ldur            x16, [x4, #-1]
    //     0x11ada0c: ubfx            x16, x16, #0xc, #0x14
    // 0x11ada10: cmp             x16, #0x3d
    // 0x11ada14: b.ne            #0x11ada28
    // 0x11ada18: LoadField: r16 = r0->field_7
    //     0x11ada18: ldur            x16, [x0, #7]
    // 0x11ada1c: LoadField: r17 = r4->field_7
    //     0x11ada1c: ldur            x17, [x4, #7]
    // 0x11ada20: cmp             x16, x17
    // 0x11ada24: b.eq            #0x11ada68
    // 0x11ada28: LoadField: r0 = r3->field_47
    //     0x11ada28: ldur            w0, [x3, #0x47]
    // 0x11ada2c: DecompressPointer r0
    //     0x11ada2c: add             x0, x0, HEAP, lsl #32
    // 0x11ada30: tbz             w0, #4, #0x11ada60
    // 0x11ada34: mov             x1, x3
    // 0x11ada38: r2 = Instance_GestureDisposition
    //     0x11ada38: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0x11ada3c: ldr             x2, [x2, #0x610]
    // 0x11ada40: r0 = resolve()
    //     0x11ada40: bl              #0xd01720  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0x11ada44: ldur            x1, [fp, #-8]
    // 0x11ada48: LoadField: r2 = r1->field_37
    //     0x11ada48: ldur            w2, [x1, #0x37]
    // 0x11ada4c: DecompressPointer r2
    //     0x11ada4c: add             x2, x2, HEAP, lsl #32
    // 0x11ada50: cmp             w2, NULL
    // 0x11ada54: b.eq            #0x11ada9c
    // 0x11ada58: r0 = stopTrackingPointer()
    //     0x11ada58: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x11ada5c: b               #0x11ada80
    // 0x11ada60: mov             x1, x3
    // 0x11ada64: b               #0x11ada6c
    // 0x11ada68: mov             x1, x3
    // 0x11ada6c: LoadField: r0 = r1->field_47
    //     0x11ada6c: ldur            w0, [x1, #0x47]
    // 0x11ada70: DecompressPointer r0
    //     0x11ada70: add             x0, x0, HEAP, lsl #32
    // 0x11ada74: tbnz            w0, #4, #0x11ada80
    // 0x11ada78: ldur            x2, [fp, #-0x10]
    // 0x11ada7c: r0 = _checkLongPressMoveUpdate()
    //     0x11ada7c: bl              #0x11adaa0  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressMoveUpdate
    // 0x11ada80: r0 = Null
    //     0x11ada80: mov             x0, NULL
    // 0x11ada84: LeaveFrame
    //     0x11ada84: mov             SP, fp
    //     0x11ada88: ldp             fp, lr, [SP], #0x10
    // 0x11ada8c: ret
    //     0x11ada8c: ret             
    // 0x11ada90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ada90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ada94: b               #0x11ad570
    // 0x11ada98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11ada98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11ada9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11ada9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressMoveUpdate(/* No info */) {
    // ** addr: 0x11adaa0, size: 0x1d0
    // 0x11adaa0: EnterFrame
    //     0x11adaa0: stp             fp, lr, [SP, #-0x10]!
    //     0x11adaa4: mov             fp, SP
    // 0x11adaa8: AllocStack(0x40)
    //     0x11adaa8: sub             SP, SP, #0x40
    // 0x11adaac: SetupParameters(LongPressGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x11adaac: mov             x0, x1
    //     0x11adab0: stur            x1, [fp, #-8]
    //     0x11adab4: mov             x1, x2
    //     0x11adab8: stur            x2, [fp, #-0x10]
    // 0x11adabc: CheckStackOverflow
    //     0x11adabc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11adac0: cmp             SP, x16
    //     0x11adac4: b.ls            #0x11adc60
    // 0x11adac8: r1 = 2
    //     0x11adac8: mov             x1, #2
    // 0x11adacc: r0 = AllocateContext()
    //     0x11adacc: bl              #0x13de838  ; AllocateContextStub
    // 0x11adad0: mov             x3, x0
    // 0x11adad4: ldur            x2, [fp, #-8]
    // 0x11adad8: stur            x3, [fp, #-0x18]
    // 0x11adadc: StoreField: r3->field_f = r2
    //     0x11adadc: stur            w2, [x3, #0xf]
    // 0x11adae0: ldur            x4, [fp, #-0x10]
    // 0x11adae4: r0 = LoadClassIdInstr(r4)
    //     0x11adae4: ldur            x0, [x4, #-1]
    //     0x11adae8: ubfx            x0, x0, #0xc, #0x14
    // 0x11adaec: mov             x1, x4
    // 0x11adaf0: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x11adaf0: mov             x17, #0x3f27
    //     0x11adaf4: movk            x17, #1, lsl #16
    //     0x11adaf8: add             lr, x0, x17
    //     0x11adafc: ldr             lr, [x21, lr, lsl #3]
    //     0x11adb00: blr             lr
    // 0x11adb04: mov             x3, x0
    // 0x11adb08: ldur            x2, [fp, #-0x10]
    // 0x11adb0c: stur            x3, [fp, #-0x20]
    // 0x11adb10: r0 = LoadClassIdInstr(r2)
    //     0x11adb10: ldur            x0, [x2, #-1]
    //     0x11adb14: ubfx            x0, x0, #0xc, #0x14
    // 0x11adb18: mov             x1, x2
    // 0x11adb1c: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11adb1c: mov             x17, #0x54ea
    //     0x11adb20: movk            x17, #1, lsl #16
    //     0x11adb24: add             lr, x0, x17
    //     0x11adb28: ldr             lr, [x21, lr, lsl #3]
    //     0x11adb2c: blr             lr
    // 0x11adb30: ldur            x2, [fp, #-0x10]
    // 0x11adb34: r0 = LoadClassIdInstr(r2)
    //     0x11adb34: ldur            x0, [x2, #-1]
    //     0x11adb38: ubfx            x0, x0, #0xc, #0x14
    // 0x11adb3c: mov             x1, x2
    // 0x11adb40: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x11adb40: mov             x17, #0x3f27
    //     0x11adb44: movk            x17, #1, lsl #16
    //     0x11adb48: add             lr, x0, x17
    //     0x11adb4c: ldr             lr, [x21, lr, lsl #3]
    //     0x11adb50: blr             lr
    // 0x11adb54: mov             x1, x0
    // 0x11adb58: ldur            x0, [fp, #-8]
    // 0x11adb5c: LoadField: r2 = r0->field_4b
    //     0x11adb5c: ldur            w2, [x0, #0x4b]
    // 0x11adb60: DecompressPointer r2
    //     0x11adb60: add             x2, x2, HEAP, lsl #32
    // 0x11adb64: cmp             w2, NULL
    // 0x11adb68: b.eq            #0x11adc68
    // 0x11adb6c: LoadField: r3 = r2->field_b
    //     0x11adb6c: ldur            w3, [x2, #0xb]
    // 0x11adb70: DecompressPointer r3
    //     0x11adb70: add             x3, x3, HEAP, lsl #32
    // 0x11adb74: mov             x2, x3
    // 0x11adb78: r0 = -()
    //     0x11adb78: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x11adb7c: mov             x2, x0
    // 0x11adb80: ldur            x1, [fp, #-0x10]
    // 0x11adb84: stur            x2, [fp, #-0x28]
    // 0x11adb88: r0 = LoadClassIdInstr(r1)
    //     0x11adb88: ldur            x0, [x1, #-1]
    //     0x11adb8c: ubfx            x0, x0, #0xc, #0x14
    // 0x11adb90: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11adb90: mov             x17, #0x54ea
    //     0x11adb94: movk            x17, #1, lsl #16
    //     0x11adb98: add             lr, x0, x17
    //     0x11adb9c: ldr             lr, [x21, lr, lsl #3]
    //     0x11adba0: blr             lr
    // 0x11adba4: mov             x1, x0
    // 0x11adba8: ldur            x0, [fp, #-8]
    // 0x11adbac: LoadField: r2 = r0->field_4b
    //     0x11adbac: ldur            w2, [x0, #0x4b]
    // 0x11adbb0: DecompressPointer r2
    //     0x11adbb0: add             x2, x2, HEAP, lsl #32
    // 0x11adbb4: cmp             w2, NULL
    // 0x11adbb8: b.eq            #0x11adc6c
    // 0x11adbbc: LoadField: r3 = r2->field_7
    //     0x11adbbc: ldur            w3, [x2, #7]
    // 0x11adbc0: DecompressPointer r3
    //     0x11adbc0: add             x3, x3, HEAP, lsl #32
    // 0x11adbc4: mov             x2, x3
    // 0x11adbc8: r0 = -()
    //     0x11adbc8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x11adbcc: r0 = LongPressMoveUpdateDetails()
    //     0x11adbcc: bl              #0x11adc70  ; AllocateLongPressMoveUpdateDetailsStub -> LongPressMoveUpdateDetails (size=0x10)
    // 0x11adbd0: mov             x1, x0
    // 0x11adbd4: ldur            x0, [fp, #-0x20]
    // 0x11adbd8: StoreField: r1->field_7 = r0
    //     0x11adbd8: stur            w0, [x1, #7]
    // 0x11adbdc: ldur            x0, [fp, #-0x28]
    // 0x11adbe0: StoreField: r1->field_b = r0
    //     0x11adbe0: stur            w0, [x1, #0xb]
    // 0x11adbe4: mov             x0, x1
    // 0x11adbe8: ldur            x2, [fp, #-0x18]
    // 0x11adbec: StoreField: r2->field_13 = r0
    //     0x11adbec: stur            w0, [x2, #0x13]
    //     0x11adbf0: ldurb           w16, [x2, #-1]
    //     0x11adbf4: ldurb           w17, [x0, #-1]
    //     0x11adbf8: and             x16, x17, x16, lsr #2
    //     0x11adbfc: tst             x16, HEAP, lsr #32
    //     0x11adc00: b.eq            #0x11adc08
    //     0x11adc04: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11adc08: ldur            x0, [fp, #-8]
    // 0x11adc0c: LoadField: r1 = r0->field_4f
    //     0x11adc0c: ldur            w1, [x0, #0x4f]
    // 0x11adc10: DecompressPointer r1
    //     0x11adc10: add             x1, x1, HEAP, lsl #32
    // 0x11adc14: cmp             w1, #2
    // 0x11adc18: b.ne            #0x11adc50
    // 0x11adc1c: LoadField: r1 = r0->field_63
    //     0x11adc1c: ldur            w1, [x0, #0x63]
    // 0x11adc20: DecompressPointer r1
    //     0x11adc20: add             x1, x1, HEAP, lsl #32
    // 0x11adc24: cmp             w1, NULL
    // 0x11adc28: b.eq            #0x11adc50
    // 0x11adc2c: r1 = Function '<anonymous closure>':.
    //     0x11adc2c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96140] AnonymousClosure: (0x11adc7c), in [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressMoveUpdate (0x11adaa0)
    //     0x11adc30: ldr             x1, [x1, #0x140]
    // 0x11adc34: r0 = AllocateClosure()
    //     0x11adc34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11adc38: r16 = <void?>
    //     0x11adc38: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11adc3c: ldur            lr, [fp, #-8]
    // 0x11adc40: stp             lr, x16, [SP, #8]
    // 0x11adc44: str             x0, [SP]
    // 0x11adc48: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11adc48: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11adc4c: r0 = invokeCallback()
    //     0x11adc4c: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11adc50: r0 = Null
    //     0x11adc50: mov             x0, NULL
    // 0x11adc54: LeaveFrame
    //     0x11adc54: mov             SP, fp
    //     0x11adc58: ldp             fp, lr, [SP], #0x10
    // 0x11adc5c: ret
    //     0x11adc5c: ret             
    // 0x11adc60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11adc60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11adc64: b               #0x11adac8
    // 0x11adc68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11adc68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11adc6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11adc6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11adc7c, size: 0x70
    // 0x11adc7c: EnterFrame
    //     0x11adc7c: stp             fp, lr, [SP, #-0x10]!
    //     0x11adc80: mov             fp, SP
    // 0x11adc84: AllocStack(0x10)
    //     0x11adc84: sub             SP, SP, #0x10
    // 0x11adc88: SetupParameters([dynamic _ /* r0 */])
    //     0x11adc88: ldr             x0, [fp, #0x10]
    //     0x11adc8c: ldur            w1, [x0, #0x17]
    //     0x11adc90: add             x1, x1, HEAP, lsl #32
    // 0x11adc94: CheckStackOverflow
    //     0x11adc94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11adc98: cmp             SP, x16
    //     0x11adc9c: b.ls            #0x11adce0
    // 0x11adca0: LoadField: r0 = r1->field_f
    //     0x11adca0: ldur            w0, [x1, #0xf]
    // 0x11adca4: DecompressPointer r0
    //     0x11adca4: add             x0, x0, HEAP, lsl #32
    // 0x11adca8: LoadField: r2 = r0->field_63
    //     0x11adca8: ldur            w2, [x0, #0x63]
    // 0x11adcac: DecompressPointer r2
    //     0x11adcac: add             x2, x2, HEAP, lsl #32
    // 0x11adcb0: cmp             w2, NULL
    // 0x11adcb4: b.eq            #0x11adce8
    // 0x11adcb8: LoadField: r0 = r1->field_13
    //     0x11adcb8: ldur            w0, [x1, #0x13]
    // 0x11adcbc: DecompressPointer r0
    //     0x11adcbc: add             x0, x0, HEAP, lsl #32
    // 0x11adcc0: stp             x0, x2, [SP]
    // 0x11adcc4: mov             x0, x2
    // 0x11adcc8: ClosureCall
    //     0x11adcc8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x11adccc: ldur            x2, [x0, #0x1f]
    //     0x11adcd0: blr             x2
    // 0x11adcd4: LeaveFrame
    //     0x11adcd4: mov             SP, fp
    //     0x11adcd8: ldp             fp, lr, [SP], #0x10
    // 0x11adcdc: ret
    //     0x11adcdc: ret             
    // 0x11adce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11adce0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11adce4: b               #0x11adca0
    // 0x11adce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11adce8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressDown(/* No info */) {
    // ** addr: 0x11adcec, size: 0x74
    // 0x11adcec: EnterFrame
    //     0x11adcec: stp             fp, lr, [SP, #-0x10]!
    //     0x11adcf0: mov             fp, SP
    // 0x11adcf4: AllocStack(0x8)
    //     0x11adcf4: sub             SP, SP, #8
    // 0x11adcf8: SetupParameters(LongPressGestureRecognizer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x11adcf8: stur            x1, [fp, #-8]
    //     0x11adcfc: mov             x16, x2
    //     0x11add00: mov             x2, x1
    //     0x11add04: mov             x1, x16
    // 0x11add08: CheckStackOverflow
    //     0x11add08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11add0c: cmp             SP, x16
    //     0x11add10: b.ls            #0x11add54
    // 0x11add14: LoadField: r0 = r2->field_4b
    //     0x11add14: ldur            w0, [x2, #0x4b]
    // 0x11add18: DecompressPointer r0
    //     0x11add18: add             x0, x0, HEAP, lsl #32
    // 0x11add1c: cmp             w0, NULL
    // 0x11add20: b.eq            #0x11add5c
    // 0x11add24: r0 = LoadClassIdInstr(r1)
    //     0x11add24: ldur            x0, [x1, #-1]
    //     0x11add28: ubfx            x0, x0, #0xc, #0x14
    // 0x11add2c: r0 = GDT[cid_x0 + -0x1]()
    //     0x11add2c: sub             lr, x0, #1
    //     0x11add30: ldr             lr, [x21, lr, lsl #3]
    //     0x11add34: blr             lr
    // 0x11add38: ldur            x1, [fp, #-8]
    // 0x11add3c: mov             x2, x0
    // 0x11add40: r0 = getKindForPointer()
    //     0x11add40: bl              #0xb960b8  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0x11add44: r0 = Null
    //     0x11add44: mov             x0, NULL
    // 0x11add48: LeaveFrame
    //     0x11add48: mov             SP, fp
    //     0x11add4c: ldp             fp, lr, [SP], #0x10
    // 0x11add50: ret
    //     0x11add50: ret             
    // 0x11add54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11add54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11add58: b               #0x11add14
    // 0x11add5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11add5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressEnd(/* No info */) {
    // ** addr: 0x11add60, size: 0x174
    // 0x11add60: EnterFrame
    //     0x11add60: stp             fp, lr, [SP, #-0x10]!
    //     0x11add64: mov             fp, SP
    // 0x11add68: AllocStack(0x38)
    //     0x11add68: sub             SP, SP, #0x38
    // 0x11add6c: SetupParameters(LongPressGestureRecognizer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x11add6c: mov             x0, x1
    //     0x11add70: stur            x1, [fp, #-8]
    //     0x11add74: mov             x1, x2
    //     0x11add78: stur            x2, [fp, #-0x10]
    // 0x11add7c: CheckStackOverflow
    //     0x11add7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11add80: cmp             SP, x16
    //     0x11add84: b.ls            #0x11adec8
    // 0x11add88: r1 = 2
    //     0x11add88: mov             x1, #2
    // 0x11add8c: r0 = AllocateContext()
    //     0x11add8c: bl              #0x13de838  ; AllocateContextStub
    // 0x11add90: mov             x2, x0
    // 0x11add94: ldur            x0, [fp, #-8]
    // 0x11add98: stur            x2, [fp, #-0x18]
    // 0x11add9c: StoreField: r2->field_f = r0
    //     0x11add9c: stur            w0, [x2, #0xf]
    // 0x11adda0: LoadField: r1 = r0->field_a7
    //     0x11adda0: ldur            w1, [x0, #0xa7]
    // 0x11adda4: DecompressPointer r1
    //     0x11adda4: add             x1, x1, HEAP, lsl #32
    // 0x11adda8: cmp             w1, NULL
    // 0x11addac: b.eq            #0x11aded0
    // 0x11addb0: r0 = getVelocityEstimate()
    //     0x11addb0: bl              #0x12fd6dc  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocityEstimate
    // 0x11addb4: cmp             w0, NULL
    // 0x11addb8: b.eq            #0x11addbc
    // 0x11addbc: ldur            x2, [fp, #-8]
    // 0x11addc0: ldur            x4, [fp, #-0x10]
    // 0x11addc4: ldur            x3, [fp, #-0x18]
    // 0x11addc8: r0 = LoadClassIdInstr(r4)
    //     0x11addc8: ldur            x0, [x4, #-1]
    //     0x11addcc: ubfx            x0, x0, #0xc, #0x14
    // 0x11addd0: mov             x1, x4
    // 0x11addd4: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x11addd4: mov             x17, #0x3f27
    //     0x11addd8: movk            x17, #1, lsl #16
    //     0x11adddc: add             lr, x0, x17
    //     0x11adde0: ldr             lr, [x21, lr, lsl #3]
    //     0x11adde4: blr             lr
    // 0x11adde8: mov             x2, x0
    // 0x11addec: ldur            x1, [fp, #-0x10]
    // 0x11addf0: stur            x2, [fp, #-0x20]
    // 0x11addf4: r0 = LoadClassIdInstr(r1)
    //     0x11addf4: ldur            x0, [x1, #-1]
    //     0x11addf8: ubfx            x0, x0, #0xc, #0x14
    // 0x11addfc: r0 = GDT[cid_x0 + 0x154ea]()
    //     0x11addfc: mov             x17, #0x54ea
    //     0x11ade00: movk            x17, #1, lsl #16
    //     0x11ade04: add             lr, x0, x17
    //     0x11ade08: ldr             lr, [x21, lr, lsl #3]
    //     0x11ade0c: blr             lr
    // 0x11ade10: r0 = LongPressEndDetails()
    //     0x11ade10: bl              #0xcfbcd8  ; AllocateLongPressEndDetailsStub -> LongPressEndDetails (size=0xc)
    // 0x11ade14: mov             x1, x0
    // 0x11ade18: ldur            x0, [fp, #-0x20]
    // 0x11ade1c: StoreField: r1->field_7 = r0
    //     0x11ade1c: stur            w0, [x1, #7]
    // 0x11ade20: mov             x0, x1
    // 0x11ade24: ldur            x2, [fp, #-0x18]
    // 0x11ade28: StoreField: r2->field_13 = r0
    //     0x11ade28: stur            w0, [x2, #0x13]
    //     0x11ade2c: ldurb           w16, [x2, #-1]
    //     0x11ade30: ldurb           w17, [x0, #-1]
    //     0x11ade34: and             x16, x17, x16, lsr #2
    //     0x11ade38: tst             x16, HEAP, lsr #32
    //     0x11ade3c: b.eq            #0x11ade44
    //     0x11ade40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11ade44: ldur            x0, [fp, #-8]
    // 0x11ade48: StoreField: r0->field_a7 = rNULL
    //     0x11ade48: stur            NULL, [x0, #0xa7]
    // 0x11ade4c: LoadField: r1 = r0->field_4f
    //     0x11ade4c: ldur            w1, [x0, #0x4f]
    // 0x11ade50: DecompressPointer r1
    //     0x11ade50: add             x1, x1, HEAP, lsl #32
    // 0x11ade54: cmp             w1, #2
    // 0x11ade58: b.ne            #0x11adeb8
    // 0x11ade5c: LoadField: r1 = r0->field_6b
    //     0x11ade5c: ldur            w1, [x0, #0x6b]
    // 0x11ade60: DecompressPointer r1
    //     0x11ade60: add             x1, x1, HEAP, lsl #32
    // 0x11ade64: cmp             w1, NULL
    // 0x11ade68: b.eq            #0x11ade90
    // 0x11ade6c: r1 = Function '<anonymous closure>':.
    //     0x11ade6c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96148] AnonymousClosure: (0x11aded4), in [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressEnd (0x11add60)
    //     0x11ade70: ldr             x1, [x1, #0x148]
    // 0x11ade74: r0 = AllocateClosure()
    //     0x11ade74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11ade78: r16 = <void?>
    //     0x11ade78: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11ade7c: ldur            lr, [fp, #-8]
    // 0x11ade80: stp             lr, x16, [SP, #8]
    // 0x11ade84: str             x0, [SP]
    // 0x11ade88: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11ade88: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11ade8c: r0 = invokeCallback()
    //     0x11ade8c: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11ade90: ldur            x0, [fp, #-8]
    // 0x11ade94: LoadField: r1 = r0->field_67
    //     0x11ade94: ldur            w1, [x0, #0x67]
    // 0x11ade98: DecompressPointer r1
    //     0x11ade98: add             x1, x1, HEAP, lsl #32
    // 0x11ade9c: cmp             w1, NULL
    // 0x11adea0: b.eq            #0x11adeb8
    // 0x11adea4: r16 = <void?>
    //     0x11adea4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x11adea8: stp             x0, x16, [SP, #8]
    // 0x11adeac: str             x1, [SP]
    // 0x11adeb0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11adeb0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11adeb4: r0 = invokeCallback()
    //     0x11adeb4: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x11adeb8: r0 = Null
    //     0x11adeb8: mov             x0, NULL
    // 0x11adebc: LeaveFrame
    //     0x11adebc: mov             SP, fp
    //     0x11adec0: ldp             fp, lr, [SP], #0x10
    // 0x11adec4: ret
    //     0x11adec4: ret             
    // 0x11adec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11adec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11adecc: b               #0x11add88
    // 0x11aded0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11aded0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11aded4, size: 0x70
    // 0x11aded4: EnterFrame
    //     0x11aded4: stp             fp, lr, [SP, #-0x10]!
    //     0x11aded8: mov             fp, SP
    // 0x11adedc: AllocStack(0x10)
    //     0x11adedc: sub             SP, SP, #0x10
    // 0x11adee0: SetupParameters([dynamic _ /* r0 */])
    //     0x11adee0: ldr             x0, [fp, #0x10]
    //     0x11adee4: ldur            w1, [x0, #0x17]
    //     0x11adee8: add             x1, x1, HEAP, lsl #32
    // 0x11adeec: CheckStackOverflow
    //     0x11adeec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11adef0: cmp             SP, x16
    //     0x11adef4: b.ls            #0x11adf38
    // 0x11adef8: LoadField: r0 = r1->field_f
    //     0x11adef8: ldur            w0, [x1, #0xf]
    // 0x11adefc: DecompressPointer r0
    //     0x11adefc: add             x0, x0, HEAP, lsl #32
    // 0x11adf00: LoadField: r2 = r0->field_6b
    //     0x11adf00: ldur            w2, [x0, #0x6b]
    // 0x11adf04: DecompressPointer r2
    //     0x11adf04: add             x2, x2, HEAP, lsl #32
    // 0x11adf08: cmp             w2, NULL
    // 0x11adf0c: b.eq            #0x11adf40
    // 0x11adf10: LoadField: r0 = r1->field_13
    //     0x11adf10: ldur            w0, [x1, #0x13]
    // 0x11adf14: DecompressPointer r0
    //     0x11adf14: add             x0, x0, HEAP, lsl #32
    // 0x11adf18: stp             x0, x2, [SP]
    // 0x11adf1c: mov             x0, x2
    // 0x11adf20: ClosureCall
    //     0x11adf20: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x11adf24: ldur            x2, [x0, #0x1f]
    //     0x11adf28: blr             x2
    // 0x11adf2c: LeaveFrame
    //     0x11adf2c: mov             SP, fp
    //     0x11adf30: ldp             fp, lr, [SP], #0x10
    // 0x11adf34: ret
    //     0x11adf34: ret             
    // 0x11adf38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11adf38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11adf3c: b               #0x11adef8
    // 0x11adf40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11adf40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5223, size: 0xc, field offset: 0x8
//   const constructor, 
class LongPressEndDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5224, size: 0x10, field offset: 0x8
//   const constructor, 
class LongPressMoveUpdateDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5225, size: 0x10, field offset: 0x8
//   const constructor, 
class LongPressStartDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}
