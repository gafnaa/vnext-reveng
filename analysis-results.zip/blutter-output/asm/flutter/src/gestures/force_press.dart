// lib: , url: package:flutter/src/gestures/force_press.dart

// class id: 1048821, size: 0x8
class :: {
}

// class id: 4440, size: 0x4c, field offset: 0x24
class ForcePressGestureRecognizer extends OneSequenceGestureRecognizer {

  late OffsetPair _lastPosition; // offset: 0x40
  late double _lastPressure; // offset: 0x44

  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0xb99420, size: 0xfc
    // 0xb99420: EnterFrame
    //     0xb99420: stp             fp, lr, [SP, #-0x10]!
    //     0xb99424: mov             fp, SP
    // 0xb99428: AllocStack(0x20)
    //     0xb99428: sub             SP, SP, #0x20
    // 0xb9942c: SetupParameters(ForcePressGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0xb9942c: stur            x1, [fp, #-8]
    // 0xb99430: CheckStackOverflow
    //     0xb99430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb99434: cmp             SP, x16
    //     0xb99438: b.ls            #0xb99514
    // 0xb9943c: r1 = 1
    //     0xb9943c: mov             x1, #1
    // 0xb99440: r0 = AllocateContext()
    //     0xb99440: bl              #0x13de838  ; AllocateContextStub
    // 0xb99444: mov             x1, x0
    // 0xb99448: ldur            x0, [fp, #-8]
    // 0xb9944c: StoreField: r1->field_f = r0
    //     0xb9944c: stur            w0, [x1, #0xf]
    // 0xb99450: LoadField: r2 = r0->field_47
    //     0xb99450: ldur            w2, [x0, #0x47]
    // 0xb99454: DecompressPointer r2
    //     0xb99454: add             x2, x2, HEAP, lsl #32
    // 0xb99458: r16 = Instance__ForceState
    //     0xb99458: add             x16, PP, #0xab, lsl #12  ; [pp+0xab300] Obj!_ForceState@12c5da1
    //     0xb9945c: ldr             x16, [x16, #0x300]
    // 0xb99460: cmp             w2, w16
    // 0xb99464: b.ne            #0xb99470
    // 0xb99468: r3 = true
    //     0xb99468: add             x3, NULL, #0x20  ; true
    // 0xb9946c: b               #0xb99488
    // 0xb99470: r16 = Instance__ForceState
    //     0xb99470: add             x16, PP, #0xab, lsl #12  ; [pp+0xab320] Obj!_ForceState@12c5d41
    //     0xb99474: ldr             x16, [x16, #0x320]
    // 0xb99478: cmp             w2, w16
    // 0xb9947c: r16 = true
    //     0xb9947c: add             x16, NULL, #0x20  ; true
    // 0xb99480: r17 = false
    //     0xb99480: add             x17, NULL, #0x30  ; false
    // 0xb99484: csel            x3, x16, x17, eq
    // 0xb99488: r16 = Instance__ForceState
    //     0xb99488: add             x16, PP, #0xab, lsl #12  ; [pp+0xab2f8] Obj!_ForceState@12c5d81
    //     0xb9948c: ldr             x16, [x16, #0x2f8]
    // 0xb99490: cmp             w2, w16
    // 0xb99494: b.ne            #0xb994b8
    // 0xb99498: mov             x1, x0
    // 0xb9949c: r2 = Instance_GestureDisposition
    //     0xb9949c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb994a0: ldr             x2, [x2, #0x610]
    // 0xb994a4: r0 = resolve()
    //     0xb994a4: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb994a8: r0 = Null
    //     0xb994a8: mov             x0, NULL
    // 0xb994ac: LeaveFrame
    //     0xb994ac: mov             SP, fp
    //     0xb994b0: ldp             fp, lr, [SP], #0x10
    // 0xb994b4: ret
    //     0xb994b4: ret             
    // 0xb994b8: tbnz            w3, #4, #0xb994f4
    // 0xb994bc: LoadField: r2 = r0->field_2f
    //     0xb994bc: ldur            w2, [x0, #0x2f]
    // 0xb994c0: DecompressPointer r2
    //     0xb994c0: add             x2, x2, HEAP, lsl #32
    // 0xb994c4: cmp             w2, NULL
    // 0xb994c8: b.eq            #0xb994f4
    // 0xb994cc: mov             x2, x1
    // 0xb994d0: r1 = Function '<anonymous closure>':.
    //     0xb994d0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab328] AnonymousClosure: (0xb99540), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::didStopTrackingLastPointer (0xb99420)
    //     0xb994d4: ldr             x1, [x1, #0x328]
    // 0xb994d8: r0 = AllocateClosure()
    //     0xb994d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb994dc: r16 = <void?>
    //     0xb994dc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb994e0: ldur            lr, [fp, #-8]
    // 0xb994e4: stp             lr, x16, [SP, #8]
    // 0xb994e8: str             x0, [SP]
    // 0xb994ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb994ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb994f0: r0 = invokeCallback()
    //     0xb994f0: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb994f4: ldur            x1, [fp, #-8]
    // 0xb994f8: r2 = Instance__ForceState
    //     0xb994f8: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3e08] Obj!_ForceState@12c5d61
    //     0xb994fc: ldr             x2, [x2, #0xe08]
    // 0xb99500: StoreField: r1->field_47 = r2
    //     0xb99500: stur            w2, [x1, #0x47]
    // 0xb99504: r0 = Null
    //     0xb99504: mov             x0, NULL
    // 0xb99508: LeaveFrame
    //     0xb99508: mov             SP, fp
    //     0xb9950c: ldp             fp, lr, [SP], #0x10
    // 0xb99510: ret
    //     0xb99510: ret             
    // 0xb99514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb99514: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb99518: b               #0xb9943c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb99540, size: 0xb4
    // 0xb99540: EnterFrame
    //     0xb99540: stp             fp, lr, [SP, #-0x10]!
    //     0xb99544: mov             fp, SP
    // 0xb99548: AllocStack(0x10)
    //     0xb99548: sub             SP, SP, #0x10
    // 0xb9954c: SetupParameters([dynamic _ /* r0 */])
    //     0xb9954c: ldr             x0, [fp, #0x10]
    //     0xb99550: ldur            w1, [x0, #0x17]
    //     0xb99554: add             x1, x1, HEAP, lsl #32
    // 0xb99558: CheckStackOverflow
    //     0xb99558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9955c: cmp             SP, x16
    //     0xb99560: b.ls            #0xb995dc
    // 0xb99564: LoadField: r0 = r1->field_f
    //     0xb99564: ldur            w0, [x1, #0xf]
    // 0xb99568: DecompressPointer r0
    //     0xb99568: add             x0, x0, HEAP, lsl #32
    // 0xb9956c: LoadField: r1 = r0->field_2f
    //     0xb9956c: ldur            w1, [x0, #0x2f]
    // 0xb99570: DecompressPointer r1
    //     0xb99570: add             x1, x1, HEAP, lsl #32
    // 0xb99574: stur            x1, [fp, #-0x10]
    // 0xb99578: cmp             w1, NULL
    // 0xb9957c: b.eq            #0xb995e4
    // 0xb99580: LoadField: r2 = r0->field_3f
    //     0xb99580: ldur            w2, [x0, #0x3f]
    // 0xb99584: DecompressPointer r2
    //     0xb99584: add             x2, x2, HEAP, lsl #32
    // 0xb99588: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9958c: cmp             w2, w16
    // 0xb99590: b.eq            #0xb995e8
    // 0xb99594: LoadField: r0 = r2->field_b
    //     0xb99594: ldur            w0, [x2, #0xb]
    // 0xb99598: DecompressPointer r0
    //     0xb99598: add             x0, x0, HEAP, lsl #32
    // 0xb9959c: stur            x0, [fp, #-8]
    // 0xb995a0: r0 = ForcePressDetails()
    //     0xb995a0: bl              #0xb997c0  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0xb995a4: mov             x1, x0
    // 0xb995a8: ldur            x0, [fp, #-8]
    // 0xb995ac: StoreField: r1->field_7 = r0
    //     0xb995ac: stur            w0, [x1, #7]
    // 0xb995b0: ldur            x0, [fp, #-0x10]
    // 0xb995b4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb995b4: ldur            w2, [x0, #0x17]
    // 0xb995b8: DecompressPointer r2
    //     0xb995b8: add             x2, x2, HEAP, lsl #32
    // 0xb995bc: mov             x16, x1
    // 0xb995c0: mov             x1, x2
    // 0xb995c4: mov             x2, x16
    // 0xb995c8: r0 = _forcePressEnded()
    //     0xb995c8: bl              #0xb99630  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_forcePressEnded
    // 0xb995cc: r0 = Null
    //     0xb995cc: mov             x0, NULL
    // 0xb995d0: LeaveFrame
    //     0xb995d0: mov             SP, fp
    //     0xb995d4: ldp             fp, lr, [SP], #0x10
    // 0xb995d8: ret
    //     0xb995d8: ret             
    // 0xb995dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb995dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb995e0: b               #0xb99564
    // 0xb995e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb995e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb995e8: r9 = _lastPosition
    //     0xb995e8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab318] Field <ForcePressGestureRecognizer._lastPosition@654518508>: late (offset: 0x40)
    //     0xb995ec: ldr             x9, [x9, #0x318]
    // 0xb995f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb995f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xb9f9ec, size: 0x24
    // 0xb9f9ec: EnterFrame
    //     0xb9f9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f9f0: mov             fp, SP
    // 0xb9f9f4: ldr             x2, [fp, #0x10]
    // 0xb9f9f8: r1 = Function 'handleEvent':.
    //     0xb9f9f8: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2f0] AnonymousClosure: (0xb9fa10), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent (0xb9fa4c)
    //     0xb9f9fc: ldr             x1, [x1, #0x2f0]
    // 0xb9fa00: r0 = AllocateClosure()
    //     0xb9fa00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9fa04: LeaveFrame
    //     0xb9fa04: mov             SP, fp
    //     0xb9fa08: ldp             fp, lr, [SP], #0x10
    // 0xb9fa0c: ret
    //     0xb9fa0c: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xb9fa10, size: 0x3c
    // 0xb9fa10: EnterFrame
    //     0xb9fa10: stp             fp, lr, [SP, #-0x10]!
    //     0xb9fa14: mov             fp, SP
    // 0xb9fa18: ldr             x0, [fp, #0x18]
    // 0xb9fa1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9fa1c: ldur            w1, [x0, #0x17]
    // 0xb9fa20: DecompressPointer r1
    //     0xb9fa20: add             x1, x1, HEAP, lsl #32
    // 0xb9fa24: CheckStackOverflow
    //     0xb9fa24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9fa28: cmp             SP, x16
    //     0xb9fa2c: b.ls            #0xb9fa44
    // 0xb9fa30: ldr             x2, [fp, #0x10]
    // 0xb9fa34: r0 = handleEvent()
    //     0xb9fa34: bl              #0xb9fa4c  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent
    // 0xb9fa38: LeaveFrame
    //     0xb9fa38: mov             SP, fp
    //     0xb9fa3c: ldp             fp, lr, [SP], #0x10
    // 0xb9fa40: ret
    //     0xb9fa40: ret             
    // 0xb9fa44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9fa44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9fa48: b               #0xb9fa30
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xb9fa4c, size: 0x484
    // 0xb9fa4c: EnterFrame
    //     0xb9fa4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb9fa50: mov             fp, SP
    // 0xb9fa54: AllocStack(0x48)
    //     0xb9fa54: sub             SP, SP, #0x48
    // 0xb9fa58: SetupParameters(ForcePressGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb9fa58: mov             x0, x2
    //     0xb9fa5c: stur            x1, [fp, #-8]
    //     0xb9fa60: stur            x2, [fp, #-0x10]
    // 0xb9fa64: CheckStackOverflow
    //     0xb9fa64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9fa68: cmp             SP, x16
    //     0xb9fa6c: b.ls            #0xb9fe64
    // 0xb9fa70: r1 = 1
    //     0xb9fa70: mov             x1, #1
    // 0xb9fa74: r0 = AllocateContext()
    //     0xb9fa74: bl              #0x13de838  ; AllocateContextStub
    // 0xb9fa78: mov             x4, x0
    // 0xb9fa7c: ldur            x3, [fp, #-8]
    // 0xb9fa80: stur            x4, [fp, #-0x18]
    // 0xb9fa84: StoreField: r4->field_f = r3
    //     0xb9fa84: stur            w3, [x4, #0xf]
    // 0xb9fa88: ldur            x0, [fp, #-0x10]
    // 0xb9fa8c: r2 = Null
    //     0xb9fa8c: mov             x2, NULL
    // 0xb9fa90: r1 = Null
    //     0xb9fa90: mov             x1, NULL
    // 0xb9fa94: cmp             w0, NULL
    // 0xb9fa98: b.eq            #0xb9fac0
    // 0xb9fa9c: branchIfSmi(r0, 0xb9fac0)
    //     0xb9fa9c: tbz             w0, #0, #0xb9fac0
    // 0xb9faa0: r3 = LoadClassIdInstr(r0)
    //     0xb9faa0: ldur            x3, [x0, #-1]
    //     0xb9faa4: ubfx            x3, x3, #0xc, #0x14
    // 0xb9faa8: r17 = 4157
    //     0xb9faa8: mov             x17, #0x103d
    // 0xb9faac: cmp             x3, x17
    // 0xb9fab0: b.eq            #0xb9fac8
    // 0xb9fab4: r17 = 5286
    //     0xb9fab4: mov             x17, #0x14a6
    // 0xb9fab8: cmp             x3, x17
    // 0xb9fabc: b.eq            #0xb9fac8
    // 0xb9fac0: r0 = false
    //     0xb9fac0: add             x0, NULL, #0x30  ; false
    // 0xb9fac4: b               #0xb9facc
    // 0xb9fac8: r0 = true
    //     0xb9fac8: add             x0, NULL, #0x20  ; true
    // 0xb9facc: tbz             w0, #4, #0xb9fb18
    // 0xb9fad0: ldur            x0, [fp, #-0x10]
    // 0xb9fad4: r2 = Null
    //     0xb9fad4: mov             x2, NULL
    // 0xb9fad8: r1 = Null
    //     0xb9fad8: mov             x1, NULL
    // 0xb9fadc: cmp             w0, NULL
    // 0xb9fae0: b.eq            #0xb9fb08
    // 0xb9fae4: branchIfSmi(r0, 0xb9fb08)
    //     0xb9fae4: tbz             w0, #0, #0xb9fb08
    // 0xb9fae8: r3 = LoadClassIdInstr(r0)
    //     0xb9fae8: ldur            x3, [x0, #-1]
    //     0xb9faec: ubfx            x3, x3, #0xc, #0x14
    // 0xb9faf0: r17 = 4159
    //     0xb9faf0: mov             x17, #0x103f
    // 0xb9faf4: cmp             x3, x17
    // 0xb9faf8: b.eq            #0xb9fb10
    // 0xb9fafc: r17 = 5288
    //     0xb9fafc: mov             x17, #0x14a8
    // 0xb9fb00: cmp             x3, x17
    // 0xb9fb04: b.eq            #0xb9fb10
    // 0xb9fb08: r0 = false
    //     0xb9fb08: add             x0, NULL, #0x30  ; false
    // 0xb9fb0c: b               #0xb9fb14
    // 0xb9fb10: r0 = true
    //     0xb9fb10: add             x0, NULL, #0x20  ; true
    // 0xb9fb14: tbnz            w0, #4, #0xb9fe48
    // 0xb9fb18: ldur            x2, [fp, #-8]
    // 0xb9fb1c: ldur            x3, [fp, #-0x10]
    // 0xb9fb20: r0 = LoadClassIdInstr(r3)
    //     0xb9fb20: ldur            x0, [x3, #-1]
    //     0xb9fb24: ubfx            x0, x0, #0xc, #0x14
    // 0xb9fb28: mov             x1, x3
    // 0xb9fb2c: r0 = GDT[cid_x0 + 0x176b6]()
    //     0xb9fb2c: mov             x17, #0x76b6
    //     0xb9fb30: movk            x17, #1, lsl #16
    //     0xb9fb34: add             lr, x0, x17
    //     0xb9fb38: ldr             lr, [x21, lr, lsl #3]
    //     0xb9fb3c: blr             lr
    // 0xb9fb40: ldur            x2, [fp, #-0x10]
    // 0xb9fb44: stur            d0, [fp, #-0x28]
    // 0xb9fb48: r0 = LoadClassIdInstr(r2)
    //     0xb9fb48: ldur            x0, [x2, #-1]
    //     0xb9fb4c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9fb50: mov             x1, x2
    // 0xb9fb54: r0 = GDT[cid_x0 + 0x139f8]()
    //     0xb9fb54: mov             x17, #0x39f8
    //     0xb9fb58: movk            x17, #1, lsl #16
    //     0xb9fb5c: add             lr, x0, x17
    //     0xb9fb60: ldr             lr, [x21, lr, lsl #3]
    //     0xb9fb64: blr             lr
    // 0xb9fb68: ldur            x2, [fp, #-0x10]
    // 0xb9fb6c: stur            d0, [fp, #-0x30]
    // 0xb9fb70: r0 = LoadClassIdInstr(r2)
    //     0xb9fb70: ldur            x0, [x2, #-1]
    //     0xb9fb74: ubfx            x0, x0, #0xc, #0x14
    // 0xb9fb78: mov             x1, x2
    // 0xb9fb7c: r0 = GDT[cid_x0 + 0x70dd]()
    //     0xb9fb7c: mov             x17, #0x70dd
    //     0xb9fb80: add             lr, x0, x17
    //     0xb9fb84: ldr             lr, [x21, lr, lsl #3]
    //     0xb9fb88: blr             lr
    // 0xb9fb8c: mov             v1.16b, v0.16b
    // 0xb9fb90: ldur            d0, [fp, #-0x28]
    // 0xb9fb94: r1 = inline_Allocate_Double()
    //     0xb9fb94: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xb9fb98: add             x1, x1, #0x10
    //     0xb9fb9c: cmp             x0, x1
    //     0xb9fba0: b.ls            #0xb9fe6c
    //     0xb9fba4: str             x1, [THR, #0x60]  ; THR::top
    //     0xb9fba8: sub             x1, x1, #0xf
    //     0xb9fbac: mov             x0, #0xe19c
    //     0xb9fbb0: movk            x0, #3, lsl #16
    //     0xb9fbb4: stur            x0, [x1, #-1]
    // 0xb9fbb8: dmb             ishst
    // 0xb9fbbc: StoreField: r1->field_7 = d0
    //     0xb9fbbc: stur            d0, [x1, #7]
    // 0xb9fbc0: ldur            d0, [fp, #-0x30]
    // 0xb9fbc4: r2 = inline_Allocate_Double()
    //     0xb9fbc4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb9fbc8: add             x2, x2, #0x10
    //     0xb9fbcc: cmp             x0, x2
    //     0xb9fbd0: b.ls            #0xb9fe80
    //     0xb9fbd4: str             x2, [THR, #0x60]  ; THR::top
    //     0xb9fbd8: sub             x2, x2, #0xf
    //     0xb9fbdc: mov             x0, #0xe19c
    //     0xb9fbe0: movk            x0, #3, lsl #16
    //     0xb9fbe4: stur            x0, [x2, #-1]
    // 0xb9fbe8: dmb             ishst
    // 0xb9fbec: StoreField: r2->field_7 = d0
    //     0xb9fbec: stur            d0, [x2, #7]
    // 0xb9fbf0: r3 = inline_Allocate_Double()
    //     0xb9fbf0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb9fbf4: add             x3, x3, #0x10
    //     0xb9fbf8: cmp             x0, x3
    //     0xb9fbfc: b.ls            #0xb9fe9c
    //     0xb9fc00: str             x3, [THR, #0x60]  ; THR::top
    //     0xb9fc04: sub             x3, x3, #0xf
    //     0xb9fc08: mov             x0, #0xe19c
    //     0xb9fc0c: movk            x0, #3, lsl #16
    //     0xb9fc10: stur            x0, [x3, #-1]
    // 0xb9fc14: dmb             ishst
    // 0xb9fc18: StoreField: r3->field_7 = d1
    //     0xb9fc18: stur            d1, [x3, #7]
    // 0xb9fc1c: r0 = _inverseLerp()
    //     0xb9fc1c: bl              #0xb9ff44  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::_inverseLerp
    // 0xb9fc20: stur            d0, [fp, #-0x28]
    // 0xb9fc24: r0 = OffsetPair()
    //     0xb9fc24: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xb9fc28: mov             x1, x0
    // 0xb9fc2c: ldur            x2, [fp, #-0x10]
    // 0xb9fc30: stur            x0, [fp, #-0x20]
    // 0xb9fc34: r0 = OffsetPair.fromEventPosition()
    //     0xb9fc34: bl              #0xb98730  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0xb9fc38: ldur            x0, [fp, #-0x20]
    // 0xb9fc3c: ldur            x3, [fp, #-8]
    // 0xb9fc40: StoreField: r3->field_3f = r0
    //     0xb9fc40: stur            w0, [x3, #0x3f]
    //     0xb9fc44: ldurb           w16, [x3, #-1]
    //     0xb9fc48: ldurb           w17, [x0, #-1]
    //     0xb9fc4c: and             x16, x17, x16, lsr #2
    //     0xb9fc50: tst             x16, HEAP, lsr #32
    //     0xb9fc54: b.eq            #0xb9fc5c
    //     0xb9fc58: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb9fc5c: ldur            d0, [fp, #-0x28]
    // 0xb9fc60: r0 = inline_Allocate_Double()
    //     0xb9fc60: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9fc64: add             x0, x0, #0x10
    //     0xb9fc68: cmp             x1, x0
    //     0xb9fc6c: b.ls            #0xb9feb8
    //     0xb9fc70: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9fc74: sub             x0, x0, #0xf
    //     0xb9fc78: mov             x1, #0xe19c
    //     0xb9fc7c: movk            x1, #3, lsl #16
    //     0xb9fc80: stur            x1, [x0, #-1]
    // 0xb9fc84: dmb             ishst
    // 0xb9fc88: StoreField: r0->field_7 = d0
    //     0xb9fc88: stur            d0, [x0, #7]
    // 0xb9fc8c: StoreField: r3->field_43 = r0
    //     0xb9fc8c: stur            w0, [x3, #0x43]
    //     0xb9fc90: ldurb           w16, [x3, #-1]
    //     0xb9fc94: ldurb           w17, [x0, #-1]
    //     0xb9fc98: and             x16, x17, x16, lsr #2
    //     0xb9fc9c: tst             x16, HEAP, lsr #32
    //     0xb9fca0: b.eq            #0xb9fca8
    //     0xb9fca4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb9fca8: LoadField: r0 = r3->field_47
    //     0xb9fca8: ldur            w0, [x3, #0x47]
    // 0xb9fcac: DecompressPointer r0
    //     0xb9fcac: add             x0, x0, HEAP, lsl #32
    // 0xb9fcb0: r16 = Instance__ForceState
    //     0xb9fcb0: add             x16, PP, #0xab, lsl #12  ; [pp+0xab2f8] Obj!_ForceState@12c5d81
    //     0xb9fcb4: ldr             x16, [x16, #0x2f8]
    // 0xb9fcb8: cmp             w0, w16
    // 0xb9fcbc: b.ne            #0xb9fdd4
    // 0xb9fcc0: d1 = 0.400000
    //     0xb9fcc0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xb9fcc4: ldr             d1, [x17, #0x368]
    // 0xb9fcc8: fcmp            d0, d1
    // 0xb9fccc: b.le            #0xb9fcf0
    // 0xb9fcd0: r0 = Instance__ForceState
    //     0xb9fcd0: add             x0, PP, #0xab, lsl #12  ; [pp+0xab300] Obj!_ForceState@12c5da1
    //     0xb9fcd4: ldr             x0, [x0, #0x300]
    // 0xb9fcd8: StoreField: r3->field_47 = r0
    //     0xb9fcd8: stur            w0, [x3, #0x47]
    // 0xb9fcdc: mov             x1, x3
    // 0xb9fce0: r2 = Instance_GestureDisposition
    //     0xb9fce0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!GestureDisposition@12c5e01
    //     0xb9fce4: ldr             x2, [x2, #0x628]
    // 0xb9fce8: r0 = resolve()
    //     0xb9fce8: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb9fcec: b               #0xb9fdd4
    // 0xb9fcf0: mov             x2, x3
    // 0xb9fcf4: ldur            x3, [fp, #-0x10]
    // 0xb9fcf8: r0 = LoadClassIdInstr(r3)
    //     0xb9fcf8: ldur            x0, [x3, #-1]
    //     0xb9fcfc: ubfx            x0, x0, #0xc, #0x14
    // 0xb9fd00: mov             x1, x3
    // 0xb9fd04: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0xb9fd04: mov             x17, #0x5a8f
    //     0xb9fd08: movk            x17, #1, lsl #16
    //     0xb9fd0c: add             lr, x0, x17
    //     0xb9fd10: ldr             lr, [x21, lr, lsl #3]
    //     0xb9fd14: blr             lr
    // 0xb9fd18: LoadField: d0 = r0->field_7
    //     0xb9fd18: ldur            d0, [x0, #7]
    // 0xb9fd1c: fmul            d1, d0, d0
    // 0xb9fd20: LoadField: d0 = r0->field_f
    //     0xb9fd20: ldur            d0, [x0, #0xf]
    // 0xb9fd24: fmul            d2, d0, d0
    // 0xb9fd28: fadd            d0, d1, d2
    // 0xb9fd2c: ldur            x2, [fp, #-0x10]
    // 0xb9fd30: stur            d0, [fp, #-0x30]
    // 0xb9fd34: r0 = LoadClassIdInstr(r2)
    //     0xb9fd34: ldur            x0, [x2, #-1]
    //     0xb9fd38: ubfx            x0, x0, #0xc, #0x14
    // 0xb9fd3c: mov             x1, x2
    // 0xb9fd40: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xb9fd40: mov             x17, #0x5e74
    //     0xb9fd44: movk            x17, #1, lsl #16
    //     0xb9fd48: add             lr, x0, x17
    //     0xb9fd4c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9fd50: blr             lr
    // 0xb9fd54: mov             x1, x0
    // 0xb9fd58: ldur            x0, [fp, #-8]
    // 0xb9fd5c: LoadField: r2 = r0->field_7
    //     0xb9fd5c: ldur            w2, [x0, #7]
    // 0xb9fd60: DecompressPointer r2
    //     0xb9fd60: add             x2, x2, HEAP, lsl #32
    // 0xb9fd64: LoadField: r3 = r1->field_7
    //     0xb9fd64: ldur            x3, [x1, #7]
    // 0xb9fd68: cmp             x3, #2
    // 0xb9fd6c: b.gt            #0xb9fd88
    // 0xb9fd70: cmp             x3, #1
    // 0xb9fd74: b.gt            #0xb9fd88
    // 0xb9fd78: cmp             x3, #0
    // 0xb9fd7c: b.le            #0xb9fd88
    // 0xb9fd80: d1 = 1.000000
    //     0xb9fd80: fmov            d1, #1.00000000
    // 0xb9fd84: b               #0xb9fdb8
    // 0xb9fd88: cmp             w2, NULL
    // 0xb9fd8c: b.ne            #0xb9fd98
    // 0xb9fd90: r1 = Null
    //     0xb9fd90: mov             x1, NULL
    // 0xb9fd94: b               #0xb9fda0
    // 0xb9fd98: LoadField: r1 = r2->field_7
    //     0xb9fd98: ldur            w1, [x2, #7]
    // 0xb9fd9c: DecompressPointer r1
    //     0xb9fd9c: add             x1, x1, HEAP, lsl #32
    // 0xb9fda0: cmp             w1, NULL
    // 0xb9fda4: b.ne            #0xb9fdb0
    // 0xb9fda8: d0 = 18.000000
    //     0xb9fda8: fmov            d0, #18.00000000
    // 0xb9fdac: b               #0xb9fdb4
    // 0xb9fdb0: LoadField: d0 = r1->field_7
    //     0xb9fdb0: ldur            d0, [x1, #7]
    // 0xb9fdb4: mov             v1.16b, v0.16b
    // 0xb9fdb8: ldur            d0, [fp, #-0x30]
    // 0xb9fdbc: fcmp            d0, d1
    // 0xb9fdc0: b.le            #0xb9fdd4
    // 0xb9fdc4: mov             x1, x0
    // 0xb9fdc8: r2 = Instance_GestureDisposition
    //     0xb9fdc8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xb9fdcc: ldr             x2, [x2, #0x610]
    // 0xb9fdd0: r0 = resolve()
    //     0xb9fdd0: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xb9fdd4: ldur            d0, [fp, #-0x28]
    // 0xb9fdd8: d1 = 0.400000
    //     0xb9fdd8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xb9fddc: ldr             d1, [x17, #0x368]
    // 0xb9fde0: fcmp            d0, d1
    // 0xb9fde4: b.le            #0xb9fe48
    // 0xb9fde8: ldur            x0, [fp, #-8]
    // 0xb9fdec: LoadField: r1 = r0->field_47
    //     0xb9fdec: ldur            w1, [x0, #0x47]
    // 0xb9fdf0: DecompressPointer r1
    //     0xb9fdf0: add             x1, x1, HEAP, lsl #32
    // 0xb9fdf4: r16 = Instance__ForceState
    //     0xb9fdf4: add             x16, PP, #0xab, lsl #12  ; [pp+0xab308] Obj!_ForceState@12c5dc1
    //     0xb9fdf8: ldr             x16, [x16, #0x308]
    // 0xb9fdfc: cmp             w1, w16
    // 0xb9fe00: b.ne            #0xb9fe48
    // 0xb9fe04: r1 = Instance__ForceState
    //     0xb9fe04: add             x1, PP, #0xab, lsl #12  ; [pp+0xab300] Obj!_ForceState@12c5da1
    //     0xb9fe08: ldr             x1, [x1, #0x300]
    // 0xb9fe0c: StoreField: r0->field_47 = r1
    //     0xb9fe0c: stur            w1, [x0, #0x47]
    // 0xb9fe10: LoadField: r1 = r0->field_23
    //     0xb9fe10: ldur            w1, [x0, #0x23]
    // 0xb9fe14: DecompressPointer r1
    //     0xb9fe14: add             x1, x1, HEAP, lsl #32
    // 0xb9fe18: cmp             w1, NULL
    // 0xb9fe1c: b.eq            #0xb9fe48
    // 0xb9fe20: ldur            x2, [fp, #-0x18]
    // 0xb9fe24: r1 = Function '<anonymous closure>':.
    //     0xb9fe24: add             x1, PP, #0xab, lsl #12  ; [pp+0xab310] AnonymousClosure: (0xb9ffb0), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent (0xb9fa4c)
    //     0xb9fe28: ldr             x1, [x1, #0x310]
    // 0xb9fe2c: r0 = AllocateClosure()
    //     0xb9fe2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9fe30: r16 = <void?>
    //     0xb9fe30: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb9fe34: ldur            lr, [fp, #-8]
    // 0xb9fe38: stp             lr, x16, [SP, #8]
    // 0xb9fe3c: str             x0, [SP]
    // 0xb9fe40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb9fe40: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb9fe44: r0 = invokeCallback()
    //     0xb9fe44: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xb9fe48: ldur            x1, [fp, #-8]
    // 0xb9fe4c: ldur            x2, [fp, #-0x10]
    // 0xb9fe50: r0 = stopTrackingIfPointerNoLongerDown()
    //     0xb9fe50: bl              #0xb9c294  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0xb9fe54: r0 = Null
    //     0xb9fe54: mov             x0, NULL
    // 0xb9fe58: LeaveFrame
    //     0xb9fe58: mov             SP, fp
    //     0xb9fe5c: ldp             fp, lr, [SP], #0x10
    // 0xb9fe60: ret
    //     0xb9fe60: ret             
    // 0xb9fe64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9fe64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9fe68: b               #0xb9fa70
    // 0xb9fe6c: stp             q0, q1, [SP, #-0x20]!
    // 0xb9fe70: r0 = AllocateDouble()
    //     0xb9fe70: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9fe74: mov             x1, x0
    // 0xb9fe78: ldp             q0, q1, [SP], #0x20
    // 0xb9fe7c: b               #0xb9fbbc
    // 0xb9fe80: stp             q0, q1, [SP, #-0x20]!
    // 0xb9fe84: SaveReg r1
    //     0xb9fe84: str             x1, [SP, #-8]!
    // 0xb9fe88: r0 = AllocateDouble()
    //     0xb9fe88: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9fe8c: mov             x2, x0
    // 0xb9fe90: RestoreReg r1
    //     0xb9fe90: ldr             x1, [SP], #8
    // 0xb9fe94: ldp             q0, q1, [SP], #0x20
    // 0xb9fe98: b               #0xb9fbec
    // 0xb9fe9c: SaveReg d1
    //     0xb9fe9c: str             q1, [SP, #-0x10]!
    // 0xb9fea0: stp             x1, x2, [SP, #-0x10]!
    // 0xb9fea4: r0 = AllocateDouble()
    //     0xb9fea4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9fea8: mov             x3, x0
    // 0xb9feac: ldp             x1, x2, [SP], #0x10
    // 0xb9feb0: RestoreReg d1
    //     0xb9feb0: ldr             q1, [SP], #0x10
    // 0xb9feb4: b               #0xb9fc18
    // 0xb9feb8: SaveReg d0
    //     0xb9feb8: str             q0, [SP, #-0x10]!
    // 0xb9febc: SaveReg r3
    //     0xb9febc: str             x3, [SP, #-8]!
    // 0xb9fec0: r0 = AllocateDouble()
    //     0xb9fec0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9fec4: RestoreReg r3
    //     0xb9fec4: ldr             x3, [SP], #8
    // 0xb9fec8: RestoreReg d0
    //     0xb9fec8: ldr             q0, [SP], #0x10
    // 0xb9fecc: b               #0xb9fc88
  }
  [closure] static double _inverseLerp(dynamic, double, double, double) {
    // ** addr: 0xb9fed0, size: 0x74
    // 0xb9fed0: EnterFrame
    //     0xb9fed0: stp             fp, lr, [SP, #-0x10]!
    //     0xb9fed4: mov             fp, SP
    // 0xb9fed8: CheckStackOverflow
    //     0xb9fed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9fedc: cmp             SP, x16
    //     0xb9fee0: b.ls            #0xb9ff2c
    // 0xb9fee4: ldr             x1, [fp, #0x20]
    // 0xb9fee8: ldr             x2, [fp, #0x18]
    // 0xb9feec: ldr             x3, [fp, #0x10]
    // 0xb9fef0: r0 = _inverseLerp()
    //     0xb9fef0: bl              #0xb9ff44  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::_inverseLerp
    // 0xb9fef4: r0 = inline_Allocate_Double()
    //     0xb9fef4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9fef8: add             x0, x0, #0x10
    //     0xb9fefc: cmp             x1, x0
    //     0xb9ff00: b.ls            #0xb9ff34
    //     0xb9ff04: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9ff08: sub             x0, x0, #0xf
    //     0xb9ff0c: mov             x1, #0xe19c
    //     0xb9ff10: movk            x1, #3, lsl #16
    //     0xb9ff14: stur            x1, [x0, #-1]
    // 0xb9ff18: dmb             ishst
    // 0xb9ff1c: StoreField: r0->field_7 = d0
    //     0xb9ff1c: stur            d0, [x0, #7]
    // 0xb9ff20: LeaveFrame
    //     0xb9ff20: mov             SP, fp
    //     0xb9ff24: ldp             fp, lr, [SP], #0x10
    // 0xb9ff28: ret
    //     0xb9ff28: ret             
    // 0xb9ff2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9ff2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9ff30: b               #0xb9fee4
    // 0xb9ff34: SaveReg d0
    //     0xb9ff34: str             q0, [SP, #-0x10]!
    // 0xb9ff38: r0 = AllocateDouble()
    //     0xb9ff38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9ff3c: RestoreReg d0
    //     0xb9ff3c: ldr             q0, [SP], #0x10
    // 0xb9ff40: b               #0xb9ff1c
  }
  static _ _inverseLerp(/* No info */) {
    // ** addr: 0xb9ff44, size: 0x6c
    // 0xb9ff44: LoadField: d1 = r1->field_7
    //     0xb9ff44: ldur            d1, [x1, #7]
    // 0xb9ff48: LoadField: d2 = r3->field_7
    //     0xb9ff48: ldur            d2, [x3, #7]
    // 0xb9ff4c: fsub            d3, d2, d1
    // 0xb9ff50: LoadField: d2 = r2->field_7
    //     0xb9ff50: ldur            d2, [x2, #7]
    // 0xb9ff54: fsub            d4, d2, d1
    // 0xb9ff58: fdiv            d1, d3, d4
    // 0xb9ff5c: fcmp            d1, d1
    // 0xb9ff60: b.vs            #0xb9ffa8
    // 0xb9ff64: d2 = 0.000000
    //     0xb9ff64: eor             v2.16b, v2.16b, v2.16b
    // 0xb9ff68: fcmp            d2, d1
    // 0xb9ff6c: b.le            #0xb9ff78
    // 0xb9ff70: d2 = 0.000000
    //     0xb9ff70: eor             v2.16b, v2.16b, v2.16b
    // 0xb9ff74: b               #0xb9ffa0
    // 0xb9ff78: d2 = 1.000000
    //     0xb9ff78: fmov            d2, #1.00000000
    // 0xb9ff7c: fcmp            d1, d2
    // 0xb9ff80: b.le            #0xb9ff8c
    // 0xb9ff84: d2 = 1.000000
    //     0xb9ff84: fmov            d2, #1.00000000
    // 0xb9ff88: b               #0xb9ffa0
    // 0xb9ff8c: fcmp            d1, d1
    // 0xb9ff90: b.vc            #0xb9ff9c
    // 0xb9ff94: d2 = 1.000000
    //     0xb9ff94: fmov            d2, #1.00000000
    // 0xb9ff98: b               #0xb9ffa0
    // 0xb9ff9c: mov             v2.16b, v1.16b
    // 0xb9ffa0: mov             v0.16b, v2.16b
    // 0xb9ffa4: b               #0xb9ffac
    // 0xb9ffa8: mov             v0.16b, v1.16b
    // 0xb9ffac: ret
    //     0xb9ffac: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb9ffb0, size: 0xb4
    // 0xb9ffb0: EnterFrame
    //     0xb9ffb0: stp             fp, lr, [SP, #-0x10]!
    //     0xb9ffb4: mov             fp, SP
    // 0xb9ffb8: AllocStack(0x10)
    //     0xb9ffb8: sub             SP, SP, #0x10
    // 0xb9ffbc: SetupParameters([dynamic _ /* r0 */])
    //     0xb9ffbc: ldr             x0, [fp, #0x10]
    //     0xb9ffc0: ldur            w1, [x0, #0x17]
    //     0xb9ffc4: add             x1, x1, HEAP, lsl #32
    // 0xb9ffc8: CheckStackOverflow
    //     0xb9ffc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9ffcc: cmp             SP, x16
    //     0xb9ffd0: b.ls            #0xba004c
    // 0xb9ffd4: LoadField: r0 = r1->field_f
    //     0xb9ffd4: ldur            w0, [x1, #0xf]
    // 0xb9ffd8: DecompressPointer r0
    //     0xb9ffd8: add             x0, x0, HEAP, lsl #32
    // 0xb9ffdc: LoadField: r1 = r0->field_23
    //     0xb9ffdc: ldur            w1, [x0, #0x23]
    // 0xb9ffe0: DecompressPointer r1
    //     0xb9ffe0: add             x1, x1, HEAP, lsl #32
    // 0xb9ffe4: stur            x1, [fp, #-0x10]
    // 0xb9ffe8: cmp             w1, NULL
    // 0xb9ffec: b.eq            #0xba0054
    // 0xb9fff0: LoadField: r2 = r0->field_3f
    //     0xb9fff0: ldur            w2, [x0, #0x3f]
    // 0xb9fff4: DecompressPointer r2
    //     0xb9fff4: add             x2, x2, HEAP, lsl #32
    // 0xb9fff8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb9fffc: cmp             w2, w16
    // 0xba0000: b.eq            #0xba0058
    // 0xba0004: LoadField: r0 = r2->field_b
    //     0xba0004: ldur            w0, [x2, #0xb]
    // 0xba0008: DecompressPointer r0
    //     0xba0008: add             x0, x0, HEAP, lsl #32
    // 0xba000c: stur            x0, [fp, #-8]
    // 0xba0010: r0 = ForcePressDetails()
    //     0xba0010: bl              #0xb997c0  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0xba0014: mov             x1, x0
    // 0xba0018: ldur            x0, [fp, #-8]
    // 0xba001c: StoreField: r1->field_7 = r0
    //     0xba001c: stur            w0, [x1, #7]
    // 0xba0020: ldur            x0, [fp, #-0x10]
    // 0xba0024: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xba0024: ldur            w2, [x0, #0x17]
    // 0xba0028: DecompressPointer r2
    //     0xba0028: add             x2, x2, HEAP, lsl #32
    // 0xba002c: mov             x16, x1
    // 0xba0030: mov             x1, x2
    // 0xba0034: mov             x2, x16
    // 0xba0038: r0 = _forcePressStarted()
    //     0xba0038: bl              #0xba00a0  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_forcePressStarted
    // 0xba003c: r0 = Null
    //     0xba003c: mov             x0, NULL
    // 0xba0040: LeaveFrame
    //     0xba0040: mov             SP, fp
    //     0xba0044: ldp             fp, lr, [SP], #0x10
    // 0xba0048: ret
    //     0xba0048: ret             
    // 0xba004c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba004c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba0050: b               #0xb9ffd4
    // 0xba0054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba0054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba0058: r9 = _lastPosition
    //     0xba0058: add             x9, PP, #0xab, lsl #12  ; [pp+0xab318] Field <ForcePressGestureRecognizer._lastPosition@654518508>: late (offset: 0x40)
    //     0xba005c: ldr             x9, [x9, #0x318]
    // 0xba0060: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba0060: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba7e6c, size: 0xf0
    // 0xba7e6c: EnterFrame
    //     0xba7e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xba7e70: mov             fp, SP
    // 0xba7e74: AllocStack(0x10)
    //     0xba7e74: sub             SP, SP, #0x10
    // 0xba7e78: SetupParameters(ForcePressGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba7e78: mov             x3, x1
    //     0xba7e7c: stur            x1, [fp, #-8]
    //     0xba7e80: stur            x2, [fp, #-0x10]
    // 0xba7e84: CheckStackOverflow
    //     0xba7e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7e88: cmp             SP, x16
    //     0xba7e8c: b.ls            #0xba7f54
    // 0xba7e90: r0 = LoadClassIdInstr(r2)
    //     0xba7e90: ldur            x0, [x2, #-1]
    //     0xba7e94: ubfx            x0, x0, #0xc, #0x14
    // 0xba7e98: mov             x1, x2
    // 0xba7e9c: r0 = GDT[cid_x0 + 0x139f8]()
    //     0xba7e9c: mov             x17, #0x39f8
    //     0xba7ea0: movk            x17, #1, lsl #16
    //     0xba7ea4: add             lr, x0, x17
    //     0xba7ea8: ldr             lr, [x21, lr, lsl #3]
    //     0xba7eac: blr             lr
    // 0xba7eb0: mov             v1.16b, v0.16b
    // 0xba7eb4: d0 = 1.000000
    //     0xba7eb4: fmov            d0, #1.00000000
    // 0xba7eb8: fcmp            d0, d1
    // 0xba7ebc: b.lt            #0xba7ed4
    // 0xba7ec0: ldur            x1, [fp, #-8]
    // 0xba7ec4: r2 = Instance_GestureDisposition
    //     0xba7ec4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xba7ec8: ldr             x2, [x2, #0x610]
    // 0xba7ecc: r0 = resolve()
    //     0xba7ecc: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xba7ed0: b               #0xba7f44
    // 0xba7ed4: ldur            x0, [fp, #-8]
    // 0xba7ed8: mov             x1, x0
    // 0xba7edc: ldur            x2, [fp, #-0x10]
    // 0xba7ee0: r0 = addAllowedPointer()
    //     0xba7ee0: bl              #0xba6ac8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0xba7ee4: ldur            x0, [fp, #-8]
    // 0xba7ee8: LoadField: r1 = r0->field_47
    //     0xba7ee8: ldur            w1, [x0, #0x47]
    // 0xba7eec: DecompressPointer r1
    //     0xba7eec: add             x1, x1, HEAP, lsl #32
    // 0xba7ef0: r16 = Instance__ForceState
    //     0xba7ef0: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3e08] Obj!_ForceState@12c5d61
    //     0xba7ef4: ldr             x16, [x16, #0xe08]
    // 0xba7ef8: cmp             w1, w16
    // 0xba7efc: b.ne            #0xba7f44
    // 0xba7f00: r1 = Instance__ForceState
    //     0xba7f00: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2f8] Obj!_ForceState@12c5d81
    //     0xba7f04: ldr             x1, [x1, #0x2f8]
    // 0xba7f08: StoreField: r0->field_47 = r1
    //     0xba7f08: stur            w1, [x0, #0x47]
    // 0xba7f0c: r0 = OffsetPair()
    //     0xba7f0c: bl              #0xb955dc  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xba7f10: mov             x1, x0
    // 0xba7f14: ldur            x2, [fp, #-0x10]
    // 0xba7f18: stur            x0, [fp, #-0x10]
    // 0xba7f1c: r0 = OffsetPair.fromEventPosition()
    //     0xba7f1c: bl              #0xb98730  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0xba7f20: ldur            x0, [fp, #-0x10]
    // 0xba7f24: ldur            x1, [fp, #-8]
    // 0xba7f28: StoreField: r1->field_3f = r0
    //     0xba7f28: stur            w0, [x1, #0x3f]
    //     0xba7f2c: ldurb           w16, [x1, #-1]
    //     0xba7f30: ldurb           w17, [x0, #-1]
    //     0xba7f34: and             x16, x17, x16, lsr #2
    //     0xba7f38: tst             x16, HEAP, lsr #32
    //     0xba7f3c: b.eq            #0xba7f44
    //     0xba7f40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba7f44: r0 = Null
    //     0xba7f44: mov             x0, NULL
    // 0xba7f48: LeaveFrame
    //     0xba7f48: mov             SP, fp
    //     0xba7f4c: ldp             fp, lr, [SP], #0x10
    // 0xba7f50: ret
    //     0xba7f50: ret             
    // 0xba7f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7f54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7f58: b               #0xba7e90
  }
  _ ForcePressGestureRecognizer(/* No info */) {
    // ** addr: 0xe0fd14, size: 0x78
    // 0xe0fd14: EnterFrame
    //     0xe0fd14: stp             fp, lr, [SP, #-0x10]!
    //     0xe0fd18: mov             fp, SP
    // 0xe0fd1c: AllocStack(0x10)
    //     0xe0fd1c: sub             SP, SP, #0x10
    // 0xe0fd20: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0fd24: r2 = Instance__ForceState
    //     0xe0fd24: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3e08] Obj!_ForceState@12c5d61
    //     0xe0fd28: ldr             x2, [x2, #0xe08]
    // 0xe0fd2c: r0 = Closure: (double, double, double) => double from Function '_inverseLerp@654518508': static.
    //     0xe0fd2c: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3e10] Closure: (double, double, double) => double from Function '_inverseLerp@654518508': static. (0x7f2adaa86ed0)
    //     0xe0fd30: ldr             x0, [x0, #0xe10]
    // 0xe0fd34: d0 = 0.400000
    //     0xe0fd34: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xe0fd38: ldr             d0, [x17, #0x368]
    // 0xe0fd3c: CheckStackOverflow
    //     0xe0fd3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0fd40: cmp             SP, x16
    //     0xe0fd44: b.ls            #0xe0fd84
    // 0xe0fd48: StoreField: r1->field_3f = r3
    //     0xe0fd48: stur            w3, [x1, #0x3f]
    // 0xe0fd4c: StoreField: r1->field_43 = r3
    //     0xe0fd4c: stur            w3, [x1, #0x43]
    // 0xe0fd50: StoreField: r1->field_47 = r2
    //     0xe0fd50: stur            w2, [x1, #0x47]
    // 0xe0fd54: StoreField: r1->field_33 = d0
    //     0xe0fd54: stur            d0, [x1, #0x33]
    // 0xe0fd58: StoreField: r1->field_3b = r0
    //     0xe0fd58: stur            w0, [x1, #0x3b]
    // 0xe0fd5c: r16 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static.
    //     0xe0fd5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xe0fd60: ldr             x16, [x16, #0x578]
    // 0xe0fd64: stp             x16, NULL, [SP]
    // 0xe0fd68: r4 = const [0, 0x3, 0x2, 0x1, allowedButtonsFilter, 0x2, supportedDevices, 0x1, null]
    //     0xe0fd68: add             x4, PP, #0x15, lsl #12  ; [pp+0x15560] List(9) [0, 0x3, 0x2, 0x1, "allowedButtonsFilter", 0x2, "supportedDevices", 0x1, Null]
    //     0xe0fd6c: ldr             x4, [x4, #0x560]
    // 0xe0fd70: r0 = OneSequenceGestureRecognizer()
    //     0xe0fd70: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xe0fd74: r0 = Null
    //     0xe0fd74: mov             x0, NULL
    // 0xe0fd78: LeaveFrame
    //     0xe0fd78: mov             SP, fp
    //     0xe0fd7c: ldp             fp, lr, [SP], #0x10
    // 0xe0fd80: ret
    //     0xe0fd80: ret             
    // 0xe0fd84: r0 = StackOverflowSharedWithFPURegs()
    //     0xe0fd84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xe0fd88: b               #0xe0fd48
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116cf90, size: 0x6c
    // 0x116cf90: EnterFrame
    //     0x116cf90: stp             fp, lr, [SP, #-0x10]!
    //     0x116cf94: mov             fp, SP
    // 0x116cf98: AllocStack(0x10)
    //     0x116cf98: sub             SP, SP, #0x10
    // 0x116cf9c: SetupParameters(ForcePressGestureRecognizer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x116cf9c: mov             x4, x1
    //     0x116cfa0: mov             x3, x2
    //     0x116cfa4: stur            x1, [fp, #-8]
    //     0x116cfa8: stur            x2, [fp, #-0x10]
    // 0x116cfac: CheckStackOverflow
    //     0x116cfac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116cfb0: cmp             SP, x16
    //     0x116cfb4: b.ls            #0x116cff4
    // 0x116cfb8: r0 = BoxInt64Instr(r3)
    //     0x116cfb8: sbfiz           x0, x3, #1, #0x1f
    //     0x116cfbc: cmp             x3, x0, asr #1
    //     0x116cfc0: b.eq            #0x116cfcc
    //     0x116cfc4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116cfc8: stur            x3, [x0, #7]
    // 0x116cfcc: mov             x1, x4
    // 0x116cfd0: mov             x2, x0
    // 0x116cfd4: r0 = stopTrackingPointer()
    //     0x116cfd4: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x116cfd8: ldur            x1, [fp, #-8]
    // 0x116cfdc: ldur            x2, [fp, #-0x10]
    // 0x116cfe0: r0 = didStopTrackingLastPointer()
    //     0x116cfe0: bl              #0xb99420  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::didStopTrackingLastPointer
    // 0x116cfe4: r0 = Null
    //     0x116cfe4: mov             x0, NULL
    // 0x116cfe8: LeaveFrame
    //     0x116cfe8: mov             SP, fp
    //     0x116cfec: ldp             fp, lr, [SP], #0x10
    // 0x116cff0: ret
    //     0x116cff0: ret             
    // 0x116cff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116cff4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116cff8: b               #0x116cfb8
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119c490, size: 0xbc
    // 0x119c490: EnterFrame
    //     0x119c490: stp             fp, lr, [SP, #-0x10]!
    //     0x119c494: mov             fp, SP
    // 0x119c498: AllocStack(0x20)
    //     0x119c498: sub             SP, SP, #0x20
    // 0x119c49c: SetupParameters(ForcePressGestureRecognizer this /* r1 => r1, fp-0x8 */)
    //     0x119c49c: stur            x1, [fp, #-8]
    // 0x119c4a0: CheckStackOverflow
    //     0x119c4a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c4a4: cmp             SP, x16
    //     0x119c4a8: b.ls            #0x119c544
    // 0x119c4ac: r1 = 1
    //     0x119c4ac: mov             x1, #1
    // 0x119c4b0: r0 = AllocateContext()
    //     0x119c4b0: bl              #0x13de838  ; AllocateContextStub
    // 0x119c4b4: mov             x1, x0
    // 0x119c4b8: ldur            x0, [fp, #-8]
    // 0x119c4bc: StoreField: r1->field_f = r0
    //     0x119c4bc: stur            w0, [x1, #0xf]
    // 0x119c4c0: LoadField: r2 = r0->field_47
    //     0x119c4c0: ldur            w2, [x0, #0x47]
    // 0x119c4c4: DecompressPointer r2
    //     0x119c4c4: add             x2, x2, HEAP, lsl #32
    // 0x119c4c8: r16 = Instance__ForceState
    //     0x119c4c8: add             x16, PP, #0xab, lsl #12  ; [pp+0xab2f8] Obj!_ForceState@12c5d81
    //     0x119c4cc: ldr             x16, [x16, #0x2f8]
    // 0x119c4d0: cmp             w2, w16
    // 0x119c4d4: b.ne            #0x119c4ec
    // 0x119c4d8: r2 = Instance__ForceState
    //     0x119c4d8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab308] Obj!_ForceState@12c5dc1
    //     0x119c4dc: ldr             x2, [x2, #0x308]
    // 0x119c4e0: StoreField: r0->field_47 = r2
    //     0x119c4e0: stur            w2, [x0, #0x47]
    // 0x119c4e4: r2 = Instance__ForceState
    //     0x119c4e4: add             x2, PP, #0xab, lsl #12  ; [pp+0xab308] Obj!_ForceState@12c5dc1
    //     0x119c4e8: ldr             x2, [x2, #0x308]
    // 0x119c4ec: LoadField: r3 = r0->field_23
    //     0x119c4ec: ldur            w3, [x0, #0x23]
    // 0x119c4f0: DecompressPointer r3
    //     0x119c4f0: add             x3, x3, HEAP, lsl #32
    // 0x119c4f4: cmp             w3, NULL
    // 0x119c4f8: b.eq            #0x119c534
    // 0x119c4fc: r16 = Instance__ForceState
    //     0x119c4fc: add             x16, PP, #0xab, lsl #12  ; [pp+0xab300] Obj!_ForceState@12c5da1
    //     0x119c500: ldr             x16, [x16, #0x300]
    // 0x119c504: cmp             w2, w16
    // 0x119c508: b.ne            #0x119c534
    // 0x119c50c: mov             x2, x1
    // 0x119c510: r1 = Function '<anonymous closure>':.
    //     0x119c510: add             x1, PP, #0xab, lsl #12  ; [pp+0xab330] AnonymousClosure: (0x119c54c), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::acceptGesture (0x119c490)
    //     0x119c514: ldr             x1, [x1, #0x330]
    // 0x119c518: r0 = AllocateClosure()
    //     0x119c518: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119c51c: r16 = <void?>
    //     0x119c51c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x119c520: ldur            lr, [fp, #-8]
    // 0x119c524: stp             lr, x16, [SP, #8]
    // 0x119c528: str             x0, [SP]
    // 0x119c52c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x119c52c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x119c530: r0 = invokeCallback()
    //     0x119c530: bl              #0xadee70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x119c534: r0 = Null
    //     0x119c534: mov             x0, NULL
    // 0x119c538: LeaveFrame
    //     0x119c538: mov             SP, fp
    //     0x119c53c: ldp             fp, lr, [SP], #0x10
    // 0x119c540: ret
    //     0x119c540: ret             
    // 0x119c544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c548: b               #0x119c4ac
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x119c54c, size: 0xd4
    // 0x119c54c: EnterFrame
    //     0x119c54c: stp             fp, lr, [SP, #-0x10]!
    //     0x119c550: mov             fp, SP
    // 0x119c554: AllocStack(0x10)
    //     0x119c554: sub             SP, SP, #0x10
    // 0x119c558: SetupParameters([dynamic _ /* r0 */])
    //     0x119c558: ldr             x0, [fp, #0x10]
    //     0x119c55c: ldur            w1, [x0, #0x17]
    //     0x119c560: add             x1, x1, HEAP, lsl #32
    // 0x119c564: CheckStackOverflow
    //     0x119c564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119c568: cmp             SP, x16
    //     0x119c56c: b.ls            #0x119c5fc
    // 0x119c570: LoadField: r0 = r1->field_f
    //     0x119c570: ldur            w0, [x1, #0xf]
    // 0x119c574: DecompressPointer r0
    //     0x119c574: add             x0, x0, HEAP, lsl #32
    // 0x119c578: LoadField: r1 = r0->field_23
    //     0x119c578: ldur            w1, [x0, #0x23]
    // 0x119c57c: DecompressPointer r1
    //     0x119c57c: add             x1, x1, HEAP, lsl #32
    // 0x119c580: stur            x1, [fp, #-0x10]
    // 0x119c584: cmp             w1, NULL
    // 0x119c588: b.eq            #0x119c604
    // 0x119c58c: LoadField: r2 = r0->field_43
    //     0x119c58c: ldur            w2, [x0, #0x43]
    // 0x119c590: DecompressPointer r2
    //     0x119c590: add             x2, x2, HEAP, lsl #32
    // 0x119c594: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119c598: cmp             w2, w16
    // 0x119c59c: b.eq            #0x119c608
    // 0x119c5a0: LoadField: r2 = r0->field_3f
    //     0x119c5a0: ldur            w2, [x0, #0x3f]
    // 0x119c5a4: DecompressPointer r2
    //     0x119c5a4: add             x2, x2, HEAP, lsl #32
    // 0x119c5a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119c5ac: cmp             w2, w16
    // 0x119c5b0: b.eq            #0x119c614
    // 0x119c5b4: LoadField: r0 = r2->field_b
    //     0x119c5b4: ldur            w0, [x2, #0xb]
    // 0x119c5b8: DecompressPointer r0
    //     0x119c5b8: add             x0, x0, HEAP, lsl #32
    // 0x119c5bc: stur            x0, [fp, #-8]
    // 0x119c5c0: r0 = ForcePressDetails()
    //     0x119c5c0: bl              #0xb997c0  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0x119c5c4: mov             x1, x0
    // 0x119c5c8: ldur            x0, [fp, #-8]
    // 0x119c5cc: StoreField: r1->field_7 = r0
    //     0x119c5cc: stur            w0, [x1, #7]
    // 0x119c5d0: ldur            x0, [fp, #-0x10]
    // 0x119c5d4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x119c5d4: ldur            w2, [x0, #0x17]
    // 0x119c5d8: DecompressPointer r2
    //     0x119c5d8: add             x2, x2, HEAP, lsl #32
    // 0x119c5dc: mov             x16, x1
    // 0x119c5e0: mov             x1, x2
    // 0x119c5e4: mov             x2, x16
    // 0x119c5e8: r0 = _forcePressStarted()
    //     0x119c5e8: bl              #0xba00a0  ; [package:flutter/src/widgets/text_selection.dart] _TextSelectionGestureDetectorState::_forcePressStarted
    // 0x119c5ec: r0 = Null
    //     0x119c5ec: mov             x0, NULL
    // 0x119c5f0: LeaveFrame
    //     0x119c5f0: mov             SP, fp
    //     0x119c5f4: ldp             fp, lr, [SP], #0x10
    // 0x119c5f8: ret
    //     0x119c5f8: ret             
    // 0x119c5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119c5fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119c600: b               #0x119c570
    // 0x119c604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119c604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x119c608: r9 = _lastPressure
    //     0x119c608: add             x9, PP, #0xab, lsl #12  ; [pp+0xab338] Field <ForcePressGestureRecognizer._lastPressure@654518508>: late (offset: 0x44)
    //     0x119c60c: ldr             x9, [x9, #0x338]
    // 0x119c610: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119c610: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119c614: r9 = _lastPosition
    //     0x119c614: add             x9, PP, #0xab, lsl #12  ; [pp+0xab318] Field <ForcePressGestureRecognizer._lastPosition@654518508>: late (offset: 0x40)
    //     0x119c618: ldr             x9, [x9, #0x318]
    // 0x119c61c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119c61c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5227, size: 0xc, field offset: 0x8
class ForcePressDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 8311, size: 0x14, field offset: 0x14
enum _ForceState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a998c, size: 0x64
    // 0x11a998c: EnterFrame
    //     0x11a998c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9990: mov             fp, SP
    // 0x11a9994: AllocStack(0x10)
    //     0x11a9994: sub             SP, SP, #0x10
    // 0x11a9998: SetupParameters(_ForceState this /* r1 => r0, fp-0x8 */)
    //     0x11a9998: mov             x0, x1
    //     0x11a999c: stur            x1, [fp, #-8]
    // 0x11a99a0: CheckStackOverflow
    //     0x11a99a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a99a4: cmp             SP, x16
    //     0x11a99a8: b.ls            #0x11a99e8
    // 0x11a99ac: r1 = Null
    //     0x11a99ac: mov             x1, NULL
    // 0x11a99b0: r2 = 4
    //     0x11a99b0: mov             x2, #4
    // 0x11a99b4: r0 = AllocateArray()
    //     0x11a99b4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a99b8: r16 = "_ForceState."
    //     0x11a99b8: add             x16, PP, #0xab, lsl #12  ; [pp+0xab340] "_ForceState."
    //     0x11a99bc: ldr             x16, [x16, #0x340]
    // 0x11a99c0: StoreField: r0->field_f = r16
    //     0x11a99c0: stur            w16, [x0, #0xf]
    // 0x11a99c4: ldur            x1, [fp, #-8]
    // 0x11a99c8: LoadField: r2 = r1->field_f
    //     0x11a99c8: ldur            w2, [x1, #0xf]
    // 0x11a99cc: DecompressPointer r2
    //     0x11a99cc: add             x2, x2, HEAP, lsl #32
    // 0x11a99d0: StoreField: r0->field_13 = r2
    //     0x11a99d0: stur            w2, [x0, #0x13]
    // 0x11a99d4: str             x0, [SP]
    // 0x11a99d8: r0 = _interpolate()
    //     0x11a99d8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a99dc: LeaveFrame
    //     0x11a99dc: mov             SP, fp
    //     0x11a99e0: ldp             fp, lr, [SP], #0x10
    // 0x11a99e4: ret
    //     0x11a99e4: ret             
    // 0x11a99e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a99e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a99ec: b               #0x11a99ac
  }
}
