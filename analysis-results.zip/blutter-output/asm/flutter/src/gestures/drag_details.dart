// lib: , url: package:flutter/src/gestures/drag_details.dart

// class id: 1048819, size: 0x8
class :: {
}

// class id: 5228, size: 0x14, field offset: 0x8
class DragEndDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5229, size: 0x20, field offset: 0x8
class DragUpdateDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {

  _ DragUpdateDetails(/* No info */) {
    // ** addr: 0xbf5af8, size: 0x1ec
    // 0xbf5af8: EnterFrame
    //     0xbf5af8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5afc: mov             fp, SP
    // 0xbf5b00: mov             x16, x5
    // 0xbf5b04: mov             x5, x1
    // 0xbf5b08: mov             x1, x16
    // 0xbf5b0c: mov             x16, x3
    // 0xbf5b10: mov             x3, x2
    // 0xbf5b14: mov             x2, x16
    // 0xbf5b18: LoadField: r6 = r4->field_13
    //     0xbf5b18: ldur            w6, [x4, #0x13]
    // 0xbf5b1c: LoadField: r7 = r4->field_1f
    //     0xbf5b1c: ldur            w7, [x4, #0x1f]
    // 0xbf5b20: DecompressPointer r7
    //     0xbf5b20: add             x7, x7, HEAP, lsl #32
    // 0xbf5b24: r16 = "kind"
    //     0xbf5b24: ldr             x16, [PP, #0x21c0]  ; [pp+0x21c0] "kind"
    // 0xbf5b28: cmp             w7, w16
    // 0xbf5b2c: b.ne            #0xbf5b50
    // 0xbf5b30: LoadField: r7 = r4->field_23
    //     0xbf5b30: ldur            w7, [x4, #0x23]
    // 0xbf5b34: DecompressPointer r7
    //     0xbf5b34: add             x7, x7, HEAP, lsl #32
    // 0xbf5b38: sub             w8, w6, w7
    // 0xbf5b3c: add             x7, fp, w8, sxtw #2
    // 0xbf5b40: ldr             x7, [x7, #8]
    // 0xbf5b44: mov             x8, x7
    // 0xbf5b48: r7 = 1
    //     0xbf5b48: mov             x7, #1
    // 0xbf5b4c: b               #0xbf5b58
    // 0xbf5b50: r8 = Null
    //     0xbf5b50: mov             x8, NULL
    // 0xbf5b54: r7 = 0
    //     0xbf5b54: mov             x7, #0
    // 0xbf5b58: lsl             x9, x7, #1
    // 0xbf5b5c: lsl             w10, w9, #1
    // 0xbf5b60: add             w11, w10, #8
    // 0xbf5b64: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0xbf5b64: add             x16, x4, w11, sxtw #1
    //     0xbf5b68: ldur            w12, [x16, #0xf]
    // 0xbf5b6c: DecompressPointer r12
    //     0xbf5b6c: add             x12, x12, HEAP, lsl #32
    // 0xbf5b70: r16 = "localPosition"
    //     0xbf5b70: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a778] "localPosition"
    //     0xbf5b74: ldr             x16, [x16, #0x778]
    // 0xbf5b78: cmp             w12, w16
    // 0xbf5b7c: b.ne            #0xbf5bb0
    // 0xbf5b80: add             w11, w10, #0xa
    // 0xbf5b84: ArrayLoad: r10 = r4[r11]  ; Unknown_4
    //     0xbf5b84: add             x16, x4, w11, sxtw #1
    //     0xbf5b88: ldur            w10, [x16, #0xf]
    // 0xbf5b8c: DecompressPointer r10
    //     0xbf5b8c: add             x10, x10, HEAP, lsl #32
    // 0xbf5b90: sub             w11, w6, w10
    // 0xbf5b94: add             x10, fp, w11, sxtw #2
    // 0xbf5b98: ldr             x10, [x10, #8]
    // 0xbf5b9c: add             w11, w9, #2
    // 0xbf5ba0: r9 = LoadInt32Instr(r11)
    //     0xbf5ba0: sbfx            x9, x11, #1, #0x1f
    // 0xbf5ba4: mov             x7, x9
    // 0xbf5ba8: mov             x9, x10
    // 0xbf5bac: b               #0xbf5bb4
    // 0xbf5bb0: r9 = Null
    //     0xbf5bb0: mov             x9, NULL
    // 0xbf5bb4: lsl             x10, x7, #1
    // 0xbf5bb8: lsl             w7, w10, #1
    // 0xbf5bbc: add             w10, w7, #8
    // 0xbf5bc0: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0xbf5bc0: add             x16, x4, w10, sxtw #1
    //     0xbf5bc4: ldur            w11, [x16, #0xf]
    // 0xbf5bc8: DecompressPointer r11
    //     0xbf5bc8: add             x11, x11, HEAP, lsl #32
    // 0xbf5bcc: r16 = "sourceTimeStamp"
    //     0xbf5bcc: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a780] "sourceTimeStamp"
    //     0xbf5bd0: ldr             x16, [x16, #0x780]
    // 0xbf5bd4: cmp             w11, w16
    // 0xbf5bd8: b.ne            #0xbf5c00
    // 0xbf5bdc: add             w10, w7, #0xa
    // 0xbf5be0: ArrayLoad: r7 = r4[r10]  ; Unknown_4
    //     0xbf5be0: add             x16, x4, w10, sxtw #1
    //     0xbf5be4: ldur            w7, [x16, #0xf]
    // 0xbf5be8: DecompressPointer r7
    //     0xbf5be8: add             x7, x7, HEAP, lsl #32
    // 0xbf5bec: sub             w4, w6, w7
    // 0xbf5bf0: add             x6, fp, w4, sxtw #2
    // 0xbf5bf4: ldr             x6, [x6, #8]
    // 0xbf5bf8: mov             x4, x6
    // 0xbf5bfc: b               #0xbf5c04
    // 0xbf5c00: r4 = Null
    //     0xbf5c00: mov             x4, NULL
    // 0xbf5c04: mov             x0, x2
    // 0xbf5c08: StoreField: r5->field_7 = r0
    //     0xbf5c08: stur            w0, [x5, #7]
    //     0xbf5c0c: ldurb           w16, [x5, #-1]
    //     0xbf5c10: ldurb           w17, [x0, #-1]
    //     0xbf5c14: and             x16, x17, x16, lsr #2
    //     0xbf5c18: tst             x16, HEAP, lsr #32
    //     0xbf5c1c: b.eq            #0xbf5c24
    //     0xbf5c20: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5c24: mov             x0, x4
    // 0xbf5c28: StoreField: r5->field_f = r0
    //     0xbf5c28: stur            w0, [x5, #0xf]
    //     0xbf5c2c: ldurb           w16, [x5, #-1]
    //     0xbf5c30: ldurb           w17, [x0, #-1]
    //     0xbf5c34: and             x16, x17, x16, lsr #2
    //     0xbf5c38: tst             x16, HEAP, lsr #32
    //     0xbf5c3c: b.eq            #0xbf5c44
    //     0xbf5c40: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5c44: mov             x0, x3
    // 0xbf5c48: StoreField: r5->field_13 = r0
    //     0xbf5c48: stur            w0, [x5, #0x13]
    //     0xbf5c4c: ldurb           w16, [x5, #-1]
    //     0xbf5c50: ldurb           w17, [x0, #-1]
    //     0xbf5c54: and             x16, x17, x16, lsr #2
    //     0xbf5c58: tst             x16, HEAP, lsr #32
    //     0xbf5c5c: b.eq            #0xbf5c64
    //     0xbf5c60: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5c64: mov             x0, x1
    // 0xbf5c68: ArrayStore: r5[0] = r0  ; List_4
    //     0xbf5c68: stur            w0, [x5, #0x17]
    //     0xbf5c6c: ldurb           w16, [x5, #-1]
    //     0xbf5c70: ldurb           w17, [x0, #-1]
    //     0xbf5c74: and             x16, x17, x16, lsr #2
    //     0xbf5c78: tst             x16, HEAP, lsr #32
    //     0xbf5c7c: b.eq            #0xbf5c84
    //     0xbf5c80: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5c84: mov             x0, x8
    // 0xbf5c88: StoreField: r5->field_1b = r0
    //     0xbf5c88: stur            w0, [x5, #0x1b]
    //     0xbf5c8c: ldurb           w16, [x5, #-1]
    //     0xbf5c90: ldurb           w17, [x0, #-1]
    //     0xbf5c94: and             x16, x17, x16, lsr #2
    //     0xbf5c98: tst             x16, HEAP, lsr #32
    //     0xbf5c9c: b.eq            #0xbf5ca4
    //     0xbf5ca0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5ca4: cmp             w9, NULL
    // 0xbf5ca8: b.ne            #0xbf5cb4
    // 0xbf5cac: mov             x0, x2
    // 0xbf5cb0: b               #0xbf5cb8
    // 0xbf5cb4: mov             x0, x9
    // 0xbf5cb8: StoreField: r5->field_b = r0
    //     0xbf5cb8: stur            w0, [x5, #0xb]
    //     0xbf5cbc: ldurb           w16, [x5, #-1]
    //     0xbf5cc0: ldurb           w17, [x0, #-1]
    //     0xbf5cc4: and             x16, x17, x16, lsr #2
    //     0xbf5cc8: tst             x16, HEAP, lsr #32
    //     0xbf5ccc: b.eq            #0xbf5cd4
    //     0xbf5cd0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf5cd4: r0 = Null
    //     0xbf5cd4: mov             x0, NULL
    // 0xbf5cd8: LeaveFrame
    //     0xbf5cd8: mov             SP, fp
    //     0xbf5cdc: ldp             fp, lr, [SP], #0x10
    // 0xbf5ce0: ret
    //     0xbf5ce0: ret             
  }
}

// class id: 5230, size: 0x18, field offset: 0x8
class DragStartDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}

// class id: 5231, size: 0xc, field offset: 0x8
class DragDownDetails extends _MixinApplication3&Object&Diagnosticable
    implements PositionedGestureDetails {
}
