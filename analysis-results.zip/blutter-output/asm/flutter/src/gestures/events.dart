// lib: , url: package:flutter/src/gestures/events.dart

// class id: 1048820, size: 0x8
class :: {

  static _ computePanSlop(/* No info */) {
    // ** addr: 0xb9c828, size: 0xcc
    // 0xb9c828: EnterFrame
    //     0xb9c828: stp             fp, lr, [SP, #-0x10]!
    //     0xb9c82c: mov             fp, SP
    // 0xb9c830: LoadField: r0 = r1->field_7
    //     0xb9c830: ldur            x0, [x1, #7]
    // 0xb9c834: cmp             x0, #2
    // 0xb9c838: b.gt            #0xb9c85c
    // 0xb9c83c: cmp             x0, #1
    // 0xb9c840: b.gt            #0xb9c85c
    // 0xb9c844: cmp             x0, #0
    // 0xb9c848: b.le            #0xb9c85c
    // 0xb9c84c: d0 = 2.000000
    //     0xb9c84c: fmov            d0, #2.00000000
    // 0xb9c850: LeaveFrame
    //     0xb9c850: mov             SP, fp
    //     0xb9c854: ldp             fp, lr, [SP], #0x10
    // 0xb9c858: ret
    //     0xb9c858: ret             
    // 0xb9c85c: cmp             w2, NULL
    // 0xb9c860: b.ne            #0xb9c86c
    // 0xb9c864: r0 = Null
    //     0xb9c864: mov             x0, NULL
    // 0xb9c868: b               #0xb9c8bc
    // 0xb9c86c: LoadField: r0 = r2->field_7
    //     0xb9c86c: ldur            w0, [x2, #7]
    // 0xb9c870: DecompressPointer r0
    //     0xb9c870: add             x0, x0, HEAP, lsl #32
    // 0xb9c874: cmp             w0, NULL
    // 0xb9c878: b.eq            #0xb9c8b8
    // 0xb9c87c: d1 = 2.000000
    //     0xb9c87c: fmov            d1, #2.00000000
    // 0xb9c880: LoadField: d2 = r0->field_7
    //     0xb9c880: ldur            d2, [x0, #7]
    // 0xb9c884: fmul            d3, d2, d1
    // 0xb9c888: r0 = inline_Allocate_Double()
    //     0xb9c888: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb9c88c: add             x0, x0, #0x10
    //     0xb9c890: cmp             x1, x0
    //     0xb9c894: b.ls            #0xb9c8e4
    //     0xb9c898: str             x0, [THR, #0x60]  ; THR::top
    //     0xb9c89c: sub             x0, x0, #0xf
    //     0xb9c8a0: mov             x1, #0xe19c
    //     0xb9c8a4: movk            x1, #3, lsl #16
    //     0xb9c8a8: stur            x1, [x0, #-1]
    // 0xb9c8ac: dmb             ishst
    // 0xb9c8b0: StoreField: r0->field_7 = d3
    //     0xb9c8b0: stur            d3, [x0, #7]
    // 0xb9c8b4: b               #0xb9c8bc
    // 0xb9c8b8: r0 = Null
    //     0xb9c8b8: mov             x0, NULL
    // 0xb9c8bc: cmp             w0, NULL
    // 0xb9c8c0: b.ne            #0xb9c8d0
    // 0xb9c8c4: d0 = 36.000000
    //     0xb9c8c4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0xb9c8c8: ldr             d0, [x17, #0xca0]
    // 0xb9c8cc: b               #0xb9c8d8
    // 0xb9c8d0: LoadField: d1 = r0->field_7
    //     0xb9c8d0: ldur            d1, [x0, #7]
    // 0xb9c8d4: mov             v0.16b, v1.16b
    // 0xb9c8d8: LeaveFrame
    //     0xb9c8d8: mov             SP, fp
    //     0xb9c8dc: ldp             fp, lr, [SP], #0x10
    // 0xb9c8e0: ret
    //     0xb9c8e0: ret             
    // 0xb9c8e4: SaveReg d3
    //     0xb9c8e4: str             q3, [SP, #-0x10]!
    // 0xb9c8e8: r0 = AllocateDouble()
    //     0xb9c8e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb9c8ec: RestoreReg d3
    //     0xb9c8ec: ldr             q3, [SP], #0x10
    // 0xb9c8f0: b               #0xb9c8b0
  }
}

// class id: 4134, size: 0x8, field offset: 0x8
abstract class _AbstractPointerEvent extends Object
    implements PointerEvent {
}

// class id: 4137, size: 0x10, field offset: 0x8
abstract class _TransformedPointerEvent extends _MixinApplication463&_AbstractPointerEvent&Diagnosticable&_PointerEventDescription {

  late final Offset localDelta; // offset: 0xc
  late final Offset localPosition; // offset: 0x8

  get _ down(/* No info */) {
    // ** addr: 0xa072f4, size: 0x50
    // 0xa072f4: EnterFrame
    //     0xa072f4: stp             fp, lr, [SP, #-0x10]!
    //     0xa072f8: mov             fp, SP
    // 0xa072fc: CheckStackOverflow
    //     0xa072fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa07300: cmp             SP, x16
    //     0xa07304: b.ls            #0xa0733c
    // 0xa07308: r0 = LoadClassIdInstr(r1)
    //     0xa07308: ldur            x0, [x1, #-1]
    //     0xa0730c: ubfx            x0, x0, #0xc, #0x14
    // 0xa07310: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa07310: mov             x17, #0x5e41
    //     0xa07314: movk            x17, #1, lsl #16
    //     0xa07318: add             lr, x0, x17
    //     0xa0731c: ldr             lr, [x21, lr, lsl #3]
    //     0xa07320: blr             lr
    // 0xa07324: LoadField: r1 = r0->field_3f
    //     0xa07324: ldur            w1, [x0, #0x3f]
    // 0xa07328: DecompressPointer r1
    //     0xa07328: add             x1, x1, HEAP, lsl #32
    // 0xa0732c: mov             x0, x1
    // 0xa07330: LeaveFrame
    //     0xa07330: mov             SP, fp
    //     0xa07334: ldp             fp, lr, [SP], #0x10
    // 0xa07338: ret
    //     0xa07338: ret             
    // 0xa0733c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0733c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa07340: b               #0xa07308
  }
  get _ pressureMin(/* No info */) {
    // ** addr: 0xa07928, size: 0x48
    // 0xa07928: EnterFrame
    //     0xa07928: stp             fp, lr, [SP, #-0x10]!
    //     0xa0792c: mov             fp, SP
    // 0xa07930: CheckStackOverflow
    //     0xa07930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa07934: cmp             SP, x16
    //     0xa07938: b.ls            #0xa07968
    // 0xa0793c: r0 = LoadClassIdInstr(r1)
    //     0xa0793c: ldur            x0, [x1, #-1]
    //     0xa07940: ubfx            x0, x0, #0xc, #0x14
    // 0xa07944: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa07944: mov             x17, #0x5e41
    //     0xa07948: movk            x17, #1, lsl #16
    //     0xa0794c: add             lr, x0, x17
    //     0xa07950: ldr             lr, [x21, lr, lsl #3]
    //     0xa07954: blr             lr
    // 0xa07958: LoadField: d0 = r0->field_4f
    //     0xa07958: ldur            d0, [x0, #0x4f]
    // 0xa0795c: LeaveFrame
    //     0xa0795c: mov             SP, fp
    //     0xa07960: ldp             fp, lr, [SP], #0x10
    // 0xa07964: ret
    //     0xa07964: ret             
    // 0xa07968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa07968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0796c: b               #0xa0793c
  }
  get _ size(/* No info */) {
    // ** addr: 0xa0886c, size: 0x48
    // 0xa0886c: EnterFrame
    //     0xa0886c: stp             fp, lr, [SP, #-0x10]!
    //     0xa08870: mov             fp, SP
    // 0xa08874: CheckStackOverflow
    //     0xa08874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa08878: cmp             SP, x16
    //     0xa0887c: b.ls            #0xa088ac
    // 0xa08880: r0 = LoadClassIdInstr(r1)
    //     0xa08880: ldur            x0, [x1, #-1]
    //     0xa08884: ubfx            x0, x0, #0xc, #0x14
    // 0xa08888: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa08888: mov             x17, #0x5e41
    //     0xa0888c: movk            x17, #1, lsl #16
    //     0xa08890: add             lr, x0, x17
    //     0xa08894: ldr             lr, [x21, lr, lsl #3]
    //     0xa08898: blr             lr
    // 0xa0889c: LoadField: d0 = r0->field_6f
    //     0xa0889c: ldur            d0, [x0, #0x6f]
    // 0xa088a0: LeaveFrame
    //     0xa088a0: mov             SP, fp
    //     0xa088a4: ldp             fp, lr, [SP], #0x10
    // 0xa088a8: ret
    //     0xa088a8: ret             
    // 0xa088ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa088ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa088b0: b               #0xa08880
  }
  get _ embedderId(/* No info */) {
    // ** addr: 0xa0d26c, size: 0x4c
    // 0xa0d26c: EnterFrame
    //     0xa0d26c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d270: mov             fp, SP
    // 0xa0d274: CheckStackOverflow
    //     0xa0d274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0d278: cmp             SP, x16
    //     0xa0d27c: b.ls            #0xa0d2b0
    // 0xa0d280: r0 = LoadClassIdInstr(r1)
    //     0xa0d280: ldur            x0, [x1, #-1]
    //     0xa0d284: ubfx            x0, x0, #0xc, #0x14
    // 0xa0d288: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa0d288: mov             x17, #0x5e41
    //     0xa0d28c: movk            x17, #1, lsl #16
    //     0xa0d290: add             lr, x0, x17
    //     0xa0d294: ldr             lr, [x21, lr, lsl #3]
    //     0xa0d298: blr             lr
    // 0xa0d29c: LoadField: r1 = r0->field_f
    //     0xa0d29c: ldur            x1, [x0, #0xf]
    // 0xa0d2a0: mov             x0, x1
    // 0xa0d2a4: LeaveFrame
    //     0xa0d2a4: mov             SP, fp
    //     0xa0d2a8: ldp             fp, lr, [SP], #0x10
    // 0xa0d2ac: ret
    //     0xa0d2ac: ret             
    // 0xa0d2b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d2b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d2b4: b               #0xa0d280
  }
  get _ buttons(/* No info */) {
    // ** addr: 0xa0d2b8, size: 0x4c
    // 0xa0d2b8: EnterFrame
    //     0xa0d2b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0d2bc: mov             fp, SP
    // 0xa0d2c0: CheckStackOverflow
    //     0xa0d2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0d2c4: cmp             SP, x16
    //     0xa0d2c8: b.ls            #0xa0d2fc
    // 0xa0d2cc: r0 = LoadClassIdInstr(r1)
    //     0xa0d2cc: ldur            x0, [x1, #-1]
    //     0xa0d2d0: ubfx            x0, x0, #0xc, #0x14
    // 0xa0d2d4: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa0d2d4: mov             x17, #0x5e41
    //     0xa0d2d8: movk            x17, #1, lsl #16
    //     0xa0d2dc: add             lr, x0, x17
    //     0xa0d2e0: ldr             lr, [x21, lr, lsl #3]
    //     0xa0d2e4: blr             lr
    // 0xa0d2e8: LoadField: r1 = r0->field_37
    //     0xa0d2e8: ldur            x1, [x0, #0x37]
    // 0xa0d2ec: mov             x0, x1
    // 0xa0d2f0: LeaveFrame
    //     0xa0d2f0: mov             SP, fp
    //     0xa0d2f4: ldp             fp, lr, [SP], #0x10
    // 0xa0d2f8: ret
    //     0xa0d2f8: ret             
    // 0xa0d2fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0d2fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0d300: b               #0xa0d2cc
  }
  get _ orientation(/* No info */) {
    // ** addr: 0xa13700, size: 0x48
    // 0xa13700: EnterFrame
    //     0xa13700: stp             fp, lr, [SP, #-0x10]!
    //     0xa13704: mov             fp, SP
    // 0xa13708: CheckStackOverflow
    //     0xa13708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa1370c: cmp             SP, x16
    //     0xa13710: b.ls            #0xa13740
    // 0xa13714: r0 = LoadClassIdInstr(r1)
    //     0xa13714: ldur            x0, [x1, #-1]
    //     0xa13718: ubfx            x0, x0, #0xc, #0x14
    // 0xa1371c: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa1371c: mov             x17, #0x5e41
    //     0xa13720: movk            x17, #1, lsl #16
    //     0xa13724: add             lr, x0, x17
    //     0xa13728: ldr             lr, [x21, lr, lsl #3]
    //     0xa1372c: blr             lr
    // 0xa13730: LoadField: d0 = r0->field_97
    //     0xa13730: ldur            d0, [x0, #0x97]
    // 0xa13734: LeaveFrame
    //     0xa13734: mov             SP, fp
    //     0xa13738: ldp             fp, lr, [SP], #0x10
    // 0xa1373c: ret
    //     0xa1373c: ret             
    // 0xa13740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa13740: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa13744: b               #0xa13714
  }
  get _ distanceMax(/* No info */) {
    // ** addr: 0xa13748, size: 0x48
    // 0xa13748: EnterFrame
    //     0xa13748: stp             fp, lr, [SP, #-0x10]!
    //     0xa1374c: mov             fp, SP
    // 0xa13750: CheckStackOverflow
    //     0xa13750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa13754: cmp             SP, x16
    //     0xa13758: b.ls            #0xa13788
    // 0xa1375c: r0 = LoadClassIdInstr(r1)
    //     0xa1375c: ldur            x0, [x1, #-1]
    //     0xa13760: ubfx            x0, x0, #0xc, #0x14
    // 0xa13764: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa13764: mov             x17, #0x5e41
    //     0xa13768: movk            x17, #1, lsl #16
    //     0xa1376c: add             lr, x0, x17
    //     0xa13770: ldr             lr, [x21, lr, lsl #3]
    //     0xa13774: blr             lr
    // 0xa13778: LoadField: d0 = r0->field_67
    //     0xa13778: ldur            d0, [x0, #0x67]
    // 0xa1377c: LeaveFrame
    //     0xa1377c: mov             SP, fp
    //     0xa13780: ldp             fp, lr, [SP], #0x10
    // 0xa13784: ret
    //     0xa13784: ret             
    // 0xa13788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa13788: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1378c: b               #0xa1375c
  }
  get _ timeStamp(/* No info */) {
    // ** addr: 0xa138cc, size: 0x50
    // 0xa138cc: EnterFrame
    //     0xa138cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa138d0: mov             fp, SP
    // 0xa138d4: CheckStackOverflow
    //     0xa138d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa138d8: cmp             SP, x16
    //     0xa138dc: b.ls            #0xa13914
    // 0xa138e0: r0 = LoadClassIdInstr(r1)
    //     0xa138e0: ldur            x0, [x1, #-1]
    //     0xa138e4: ubfx            x0, x0, #0xc, #0x14
    // 0xa138e8: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa138e8: mov             x17, #0x5e41
    //     0xa138ec: movk            x17, #1, lsl #16
    //     0xa138f0: add             lr, x0, x17
    //     0xa138f4: ldr             lr, [x21, lr, lsl #3]
    //     0xa138f8: blr             lr
    // 0xa138fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xa138fc: ldur            w1, [x0, #0x17]
    // 0xa13900: DecompressPointer r1
    //     0xa13900: add             x1, x1, HEAP, lsl #32
    // 0xa13904: mov             x0, x1
    // 0xa13908: LeaveFrame
    //     0xa13908: mov             SP, fp
    //     0xa1390c: ldp             fp, lr, [SP], #0x10
    // 0xa13910: ret
    //     0xa13910: ret             
    // 0xa13914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa13914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa13918: b               #0xa138e0
  }
  get _ kind(/* No info */) {
    // ** addr: 0xa13964, size: 0x50
    // 0xa13964: EnterFrame
    //     0xa13964: stp             fp, lr, [SP, #-0x10]!
    //     0xa13968: mov             fp, SP
    // 0xa1396c: CheckStackOverflow
    //     0xa1396c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa13970: cmp             SP, x16
    //     0xa13974: b.ls            #0xa139ac
    // 0xa13978: r0 = LoadClassIdInstr(r1)
    //     0xa13978: ldur            x0, [x1, #-1]
    //     0xa1397c: ubfx            x0, x0, #0xc, #0x14
    // 0xa13980: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa13980: mov             x17, #0x5e41
    //     0xa13984: movk            x17, #1, lsl #16
    //     0xa13988: add             lr, x0, x17
    //     0xa1398c: ldr             lr, [x21, lr, lsl #3]
    //     0xa13990: blr             lr
    // 0xa13994: LoadField: r1 = r0->field_23
    //     0xa13994: ldur            w1, [x0, #0x23]
    // 0xa13998: DecompressPointer r1
    //     0xa13998: add             x1, x1, HEAP, lsl #32
    // 0xa1399c: mov             x0, x1
    // 0xa139a0: LeaveFrame
    //     0xa139a0: mov             SP, fp
    //     0xa139a4: ldp             fp, lr, [SP], #0x10
    // 0xa139a8: ret
    //     0xa139a8: ret             
    // 0xa139ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa139ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa139b0: b               #0xa13978
  }
  get _ radiusMajor(/* No info */) {
    // ** addr: 0xa139b4, size: 0x48
    // 0xa139b4: EnterFrame
    //     0xa139b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa139b8: mov             fp, SP
    // 0xa139bc: CheckStackOverflow
    //     0xa139bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa139c0: cmp             SP, x16
    //     0xa139c4: b.ls            #0xa139f4
    // 0xa139c8: r0 = LoadClassIdInstr(r1)
    //     0xa139c8: ldur            x0, [x1, #-1]
    //     0xa139cc: ubfx            x0, x0, #0xc, #0x14
    // 0xa139d0: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa139d0: mov             x17, #0x5e41
    //     0xa139d4: movk            x17, #1, lsl #16
    //     0xa139d8: add             lr, x0, x17
    //     0xa139dc: ldr             lr, [x21, lr, lsl #3]
    //     0xa139e0: blr             lr
    // 0xa139e4: LoadField: d0 = r0->field_77
    //     0xa139e4: ldur            d0, [x0, #0x77]
    // 0xa139e8: LeaveFrame
    //     0xa139e8: mov             SP, fp
    //     0xa139ec: ldp             fp, lr, [SP], #0x10
    // 0xa139f0: ret
    //     0xa139f0: ret             
    // 0xa139f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa139f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa139f8: b               #0xa139c8
  }
  get _ device(/* No info */) {
    // ** addr: 0xa153c4, size: 0x4c
    // 0xa153c4: EnterFrame
    //     0xa153c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa153c8: mov             fp, SP
    // 0xa153cc: CheckStackOverflow
    //     0xa153cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa153d0: cmp             SP, x16
    //     0xa153d4: b.ls            #0xa15408
    // 0xa153d8: r0 = LoadClassIdInstr(r1)
    //     0xa153d8: ldur            x0, [x1, #-1]
    //     0xa153dc: ubfx            x0, x0, #0xc, #0x14
    // 0xa153e0: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa153e0: mov             x17, #0x5e41
    //     0xa153e4: movk            x17, #1, lsl #16
    //     0xa153e8: add             lr, x0, x17
    //     0xa153ec: ldr             lr, [x21, lr, lsl #3]
    //     0xa153f0: blr             lr
    // 0xa153f4: LoadField: r1 = r0->field_27
    //     0xa153f4: ldur            x1, [x0, #0x27]
    // 0xa153f8: mov             x0, x1
    // 0xa153fc: LeaveFrame
    //     0xa153fc: mov             SP, fp
    //     0xa15400: ldp             fp, lr, [SP], #0x10
    // 0xa15404: ret
    //     0xa15404: ret             
    // 0xa15408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa15408: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1540c: b               #0xa153d8
  }
  Offset delta(_TransformedPointerEvent) {
    // ** addr: 0xa15410, size: 0x50
    // 0xa15410: EnterFrame
    //     0xa15410: stp             fp, lr, [SP, #-0x10]!
    //     0xa15414: mov             fp, SP
    // 0xa15418: CheckStackOverflow
    //     0xa15418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa1541c: cmp             SP, x16
    //     0xa15420: b.ls            #0xa15458
    // 0xa15424: r0 = LoadClassIdInstr(r1)
    //     0xa15424: ldur            x0, [x1, #-1]
    //     0xa15428: ubfx            x0, x0, #0xc, #0x14
    // 0xa1542c: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xa1542c: mov             x17, #0x5e41
    //     0xa15430: movk            x17, #1, lsl #16
    //     0xa15434: add             lr, x0, x17
    //     0xa15438: ldr             lr, [x21, lr, lsl #3]
    //     0xa1543c: blr             lr
    // 0xa15440: LoadField: r1 = r0->field_33
    //     0xa15440: ldur            w1, [x0, #0x33]
    // 0xa15444: DecompressPointer r1
    //     0xa15444: add             x1, x1, HEAP, lsl #32
    // 0xa15448: mov             x0, x1
    // 0xa1544c: LeaveFrame
    //     0xa1544c: mov             SP, fp
    //     0xa15450: ldp             fp, lr, [SP], #0x10
    // 0xa15454: ret
    //     0xa15454: ret             
    // 0xa15458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa15458: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1545c: b               #0xa15424
  }
  const Offset localPosition(_TransformedPointerEvent) {
    // ** addr: 0xacbaec, size: 0x38
    // 0xacbaec: EnterFrame
    //     0xacbaec: stp             fp, lr, [SP, #-0x10]!
    //     0xacbaf0: mov             fp, SP
    // 0xacbaf4: mov             x0, x1
    // 0xacbaf8: LoadField: r0 = r1->field_7
    //     0xacbaf8: ldur            w0, [x1, #7]
    // 0xacbafc: DecompressPointer r0
    //     0xacbafc: add             x0, x0, HEAP, lsl #32
    // 0xacbb00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xacbb04: cmp             w0, w16
    // 0xacbb08: b.ne            #0xacbb18
    // 0xacbb0c: r2 = localPosition
    //     0xacbb0c: add             x2, PP, #0x90, lsl #12  ; [pp+0x90ce0] Field <_TransformedPointerEvent@31050165.localPosition>: late final (offset: 0x8)
    //     0xacbb10: ldr             x2, [x2, #0xce0]
    // 0xacbb14: r0 = InitLateFinalInstanceField()
    //     0xacbb14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xacbb18: LeaveFrame
    //     0xacbb18: mov             SP, fp
    //     0xacbb1c: ldp             fp, lr, [SP], #0x10
    // 0xacbb20: ret
    //     0xacbb20: ret             
  }
  Offset localPosition(_TransformedPointerEvent) {
    // ** addr: 0xacbb24, size: 0x88
    // 0xacbb24: EnterFrame
    //     0xacbb24: stp             fp, lr, [SP, #-0x10]!
    //     0xacbb28: mov             fp, SP
    // 0xacbb2c: AllocStack(0x8)
    //     0xacbb2c: sub             SP, SP, #8
    // 0xacbb30: CheckStackOverflow
    //     0xacbb30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xacbb34: cmp             SP, x16
    //     0xacbb38: b.ls            #0xacbba4
    // 0xacbb3c: ldr             x2, [fp, #0x10]
    // 0xacbb40: r0 = LoadClassIdInstr(r2)
    //     0xacbb40: ldur            x0, [x2, #-1]
    //     0xacbb44: ubfx            x0, x0, #0xc, #0x14
    // 0xacbb48: mov             x1, x2
    // 0xacbb4c: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xacbb4c: mov             x17, #0x5fe3
    //     0xacbb50: movk            x17, #1, lsl #16
    //     0xacbb54: add             lr, x0, x17
    //     0xacbb58: ldr             lr, [x21, lr, lsl #3]
    //     0xacbb5c: blr             lr
    // 0xacbb60: mov             x2, x0
    // 0xacbb64: ldr             x1, [fp, #0x10]
    // 0xacbb68: stur            x2, [fp, #-8]
    // 0xacbb6c: r0 = LoadClassIdInstr(r1)
    //     0xacbb6c: ldur            x0, [x1, #-1]
    //     0xacbb70: ubfx            x0, x0, #0xc, #0x14
    // 0xacbb74: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xacbb74: mov             x17, #0x5e41
    //     0xacbb78: movk            x17, #1, lsl #16
    //     0xacbb7c: add             lr, x0, x17
    //     0xacbb80: ldr             lr, [x21, lr, lsl #3]
    //     0xacbb84: blr             lr
    // 0xacbb88: LoadField: r2 = r0->field_2f
    //     0xacbb88: ldur            w2, [x0, #0x2f]
    // 0xacbb8c: DecompressPointer r2
    //     0xacbb8c: add             x2, x2, HEAP, lsl #32
    // 0xacbb90: ldur            x1, [fp, #-8]
    // 0xacbb94: r0 = transformPosition()
    //     0xacbb94: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xacbb98: LeaveFrame
    //     0xacbb98: mov             SP, fp
    //     0xacbb9c: ldp             fp, lr, [SP], #0x10
    // 0xacbba0: ret
    //     0xacbba0: ret             
    // 0xacbba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacbba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacbba8: b               #0xacbb3c
  }
  get _ synthesized(/* No info */) {
    // ** addr: 0xacc9c4, size: 0x50
    // 0xacc9c4: EnterFrame
    //     0xacc9c4: stp             fp, lr, [SP, #-0x10]!
    //     0xacc9c8: mov             fp, SP
    // 0xacc9cc: CheckStackOverflow
    //     0xacc9cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xacc9d0: cmp             SP, x16
    //     0xacc9d4: b.ls            #0xacca0c
    // 0xacc9d8: r0 = LoadClassIdInstr(r1)
    //     0xacc9d8: ldur            x0, [x1, #-1]
    //     0xacc9dc: ubfx            x0, x0, #0xc, #0x14
    // 0xacc9e0: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xacc9e0: mov             x17, #0x5e41
    //     0xacc9e4: movk            x17, #1, lsl #16
    //     0xacc9e8: add             lr, x0, x17
    //     0xacc9ec: ldr             lr, [x21, lr, lsl #3]
    //     0xacc9f0: blr             lr
    // 0xacc9f4: LoadField: r1 = r0->field_af
    //     0xacc9f4: ldur            w1, [x0, #0xaf]
    // 0xacc9f8: DecompressPointer r1
    //     0xacc9f8: add             x1, x1, HEAP, lsl #32
    // 0xacc9fc: mov             x0, x1
    // 0xacca00: LeaveFrame
    //     0xacca00: mov             SP, fp
    //     0xacca04: ldp             fp, lr, [SP], #0x10
    // 0xacca08: ret
    //     0xacca08: ret             
    // 0xacca0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacca0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacca10: b               #0xacc9d8
  }
  const Offset localDelta(_TransformedPointerEvent) {
    // ** addr: 0xacca14, size: 0x38
    // 0xacca14: EnterFrame
    //     0xacca14: stp             fp, lr, [SP, #-0x10]!
    //     0xacca18: mov             fp, SP
    // 0xacca1c: mov             x0, x1
    // 0xacca20: LoadField: r0 = r1->field_b
    //     0xacca20: ldur            w0, [x1, #0xb]
    // 0xacca24: DecompressPointer r0
    //     0xacca24: add             x0, x0, HEAP, lsl #32
    // 0xacca28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xacca2c: cmp             w0, w16
    // 0xacca30: b.ne            #0xacca40
    // 0xacca34: r2 = localDelta
    //     0xacca34: add             x2, PP, #0x90, lsl #12  ; [pp+0x90cd8] Field <_TransformedPointerEvent@31050165.localDelta>: late final (offset: 0xc)
    //     0xacca38: ldr             x2, [x2, #0xcd8]
    // 0xacca3c: r0 = InitLateFinalInstanceField()
    //     0xacca3c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xacca40: LeaveFrame
    //     0xacca40: mov             SP, fp
    //     0xacca44: ldp             fp, lr, [SP], #0x10
    // 0xacca48: ret
    //     0xacca48: ret             
  }
  Offset localDelta(_TransformedPointerEvent) {
    // ** addr: 0xacca4c, size: 0xf8
    // 0xacca4c: EnterFrame
    //     0xacca4c: stp             fp, lr, [SP, #-0x10]!
    //     0xacca50: mov             fp, SP
    // 0xacca54: AllocStack(0x20)
    //     0xacca54: sub             SP, SP, #0x20
    // 0xacca58: CheckStackOverflow
    //     0xacca58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xacca5c: cmp             SP, x16
    //     0xacca60: b.ls            #0xaccb3c
    // 0xacca64: ldr             x2, [fp, #0x10]
    // 0xacca68: r0 = LoadClassIdInstr(r2)
    //     0xacca68: ldur            x0, [x2, #-1]
    //     0xacca6c: ubfx            x0, x0, #0xc, #0x14
    // 0xacca70: mov             x1, x2
    // 0xacca74: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0xacca74: mov             x17, #0x5fe3
    //     0xacca78: movk            x17, #1, lsl #16
    //     0xacca7c: add             lr, x0, x17
    //     0xacca80: ldr             lr, [x21, lr, lsl #3]
    //     0xacca84: blr             lr
    // 0xacca88: mov             x3, x0
    // 0xacca8c: ldr             x2, [fp, #0x10]
    // 0xacca90: stur            x3, [fp, #-8]
    // 0xacca94: r0 = LoadClassIdInstr(r2)
    //     0xacca94: ldur            x0, [x2, #-1]
    //     0xacca98: ubfx            x0, x0, #0xc, #0x14
    // 0xacca9c: mov             x1, x2
    // 0xaccaa0: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xaccaa0: mov             x17, #0x5e41
    //     0xaccaa4: movk            x17, #1, lsl #16
    //     0xaccaa8: add             lr, x0, x17
    //     0xaccaac: ldr             lr, [x21, lr, lsl #3]
    //     0xaccab0: blr             lr
    // 0xaccab4: LoadField: r2 = r0->field_33
    //     0xaccab4: ldur            w2, [x0, #0x33]
    // 0xaccab8: DecompressPointer r2
    //     0xaccab8: add             x2, x2, HEAP, lsl #32
    // 0xaccabc: ldr             x3, [fp, #0x10]
    // 0xaccac0: stur            x2, [fp, #-0x10]
    // 0xaccac4: r0 = LoadClassIdInstr(r3)
    //     0xaccac4: ldur            x0, [x3, #-1]
    //     0xaccac8: ubfx            x0, x0, #0xc, #0x14
    // 0xaccacc: mov             x1, x3
    // 0xaccad0: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xaccad0: mov             x17, #0x5e41
    //     0xaccad4: movk            x17, #1, lsl #16
    //     0xaccad8: add             lr, x0, x17
    //     0xaccadc: ldr             lr, [x21, lr, lsl #3]
    //     0xaccae0: blr             lr
    // 0xaccae4: LoadField: r3 = r0->field_2f
    //     0xaccae4: ldur            w3, [x0, #0x2f]
    // 0xaccae8: DecompressPointer r3
    //     0xaccae8: add             x3, x3, HEAP, lsl #32
    // 0xaccaec: ldr             x1, [fp, #0x10]
    // 0xaccaf0: stur            x3, [fp, #-0x18]
    // 0xaccaf4: LoadField: r0 = r1->field_7
    //     0xaccaf4: ldur            w0, [x1, #7]
    // 0xaccaf8: DecompressPointer r0
    //     0xaccaf8: add             x0, x0, HEAP, lsl #32
    // 0xaccafc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xaccb00: cmp             w0, w16
    // 0xaccb04: b.ne            #0xaccb14
    // 0xaccb08: r2 = localPosition
    //     0xaccb08: add             x2, PP, #0x90, lsl #12  ; [pp+0x90ce0] Field <_TransformedPointerEvent@31050165.localPosition>: late final (offset: 0x8)
    //     0xaccb0c: ldr             x2, [x2, #0xce0]
    // 0xaccb10: r0 = InitLateFinalInstanceField()
    //     0xaccb10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xaccb14: str             x0, [SP]
    // 0xaccb18: ldur            x1, [fp, #-8]
    // 0xaccb1c: ldur            x2, [fp, #-0x10]
    // 0xaccb20: ldur            x3, [fp, #-0x18]
    // 0xaccb24: r4 = const [0, 0x4, 0x1, 0x3, transformedEndPosition, 0x3, null]
    //     0xaccb24: add             x4, PP, #0x90, lsl #12  ; [pp+0x90cd0] List(7) [0, 0x4, 0x1, 0x3, "transformedEndPosition", 0x3, Null]
    //     0xaccb28: ldr             x4, [x4, #0xcd0]
    // 0xaccb2c: r0 = transformDeltaViaPositions()
    //     0xaccb2c: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xaccb30: LeaveFrame
    //     0xaccb30: mov             SP, fp
    //     0xaccb34: ldp             fp, lr, [SP], #0x10
    // 0xaccb38: ret
    //     0xaccb38: ret             
    // 0xaccb3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaccb3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaccb40: b               #0xacca64
  }
  get _ viewId(/* No info */) {
    // ** addr: 0xaef2f0, size: 0x4c
    // 0xaef2f0: EnterFrame
    //     0xaef2f0: stp             fp, lr, [SP, #-0x10]!
    //     0xaef2f4: mov             fp, SP
    // 0xaef2f8: CheckStackOverflow
    //     0xaef2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaef2fc: cmp             SP, x16
    //     0xaef300: b.ls            #0xaef334
    // 0xaef304: r0 = LoadClassIdInstr(r1)
    //     0xaef304: ldur            x0, [x1, #-1]
    //     0xaef308: ubfx            x0, x0, #0xc, #0x14
    // 0xaef30c: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xaef30c: mov             x17, #0x5e41
    //     0xaef310: movk            x17, #1, lsl #16
    //     0xaef314: add             lr, x0, x17
    //     0xaef318: ldr             lr, [x21, lr, lsl #3]
    //     0xaef31c: blr             lr
    // 0xaef320: LoadField: r1 = r0->field_7
    //     0xaef320: ldur            x1, [x0, #7]
    // 0xaef324: mov             x0, x1
    // 0xaef328: LeaveFrame
    //     0xaef328: mov             SP, fp
    //     0xaef32c: ldp             fp, lr, [SP], #0x10
    // 0xaef330: ret
    //     0xaef330: ret             
    // 0xaef334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaef334: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaef338: b               #0xaef304
  }
  get _ radiusMin(/* No info */) {
    // ** addr: 0xaf1c58, size: 0x48
    // 0xaf1c58: EnterFrame
    //     0xaf1c58: stp             fp, lr, [SP, #-0x10]!
    //     0xaf1c5c: mov             fp, SP
    // 0xaf1c60: CheckStackOverflow
    //     0xaf1c60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf1c64: cmp             SP, x16
    //     0xaf1c68: b.ls            #0xaf1c98
    // 0xaf1c6c: r0 = LoadClassIdInstr(r1)
    //     0xaf1c6c: ldur            x0, [x1, #-1]
    //     0xaf1c70: ubfx            x0, x0, #0xc, #0x14
    // 0xaf1c74: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xaf1c74: mov             x17, #0x5e41
    //     0xaf1c78: movk            x17, #1, lsl #16
    //     0xaf1c7c: add             lr, x0, x17
    //     0xaf1c80: ldr             lr, [x21, lr, lsl #3]
    //     0xaf1c84: blr             lr
    // 0xaf1c88: LoadField: d0 = r0->field_87
    //     0xaf1c88: ldur            d0, [x0, #0x87]
    // 0xaf1c8c: LeaveFrame
    //     0xaf1c8c: mov             SP, fp
    //     0xaf1c90: ldp             fp, lr, [SP], #0x10
    // 0xaf1c94: ret
    //     0xaf1c94: ret             
    // 0xaf1c98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf1c98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf1c9c: b               #0xaf1c6c
  }
  get _ radiusMinor(/* No info */) {
    // ** addr: 0xafbcb0, size: 0x48
    // 0xafbcb0: EnterFrame
    //     0xafbcb0: stp             fp, lr, [SP, #-0x10]!
    //     0xafbcb4: mov             fp, SP
    // 0xafbcb8: CheckStackOverflow
    //     0xafbcb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xafbcbc: cmp             SP, x16
    //     0xafbcc0: b.ls            #0xafbcf0
    // 0xafbcc4: r0 = LoadClassIdInstr(r1)
    //     0xafbcc4: ldur            x0, [x1, #-1]
    //     0xafbcc8: ubfx            x0, x0, #0xc, #0x14
    // 0xafbccc: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xafbccc: mov             x17, #0x5e41
    //     0xafbcd0: movk            x17, #1, lsl #16
    //     0xafbcd4: add             lr, x0, x17
    //     0xafbcd8: ldr             lr, [x21, lr, lsl #3]
    //     0xafbcdc: blr             lr
    // 0xafbce0: LoadField: d0 = r0->field_7f
    //     0xafbce0: ldur            d0, [x0, #0x7f]
    // 0xafbce4: LeaveFrame
    //     0xafbce4: mov             SP, fp
    //     0xafbce8: ldp             fp, lr, [SP], #0x10
    // 0xafbcec: ret
    //     0xafbcec: ret             
    // 0xafbcf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafbcf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafbcf4: b               #0xafbcc4
  }
  Offset position(_TransformedPointerEvent) {
    // ** addr: 0xafbcf8, size: 0x50
    // 0xafbcf8: EnterFrame
    //     0xafbcf8: stp             fp, lr, [SP, #-0x10]!
    //     0xafbcfc: mov             fp, SP
    // 0xafbd00: CheckStackOverflow
    //     0xafbd00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xafbd04: cmp             SP, x16
    //     0xafbd08: b.ls            #0xafbd40
    // 0xafbd0c: r0 = LoadClassIdInstr(r1)
    //     0xafbd0c: ldur            x0, [x1, #-1]
    //     0xafbd10: ubfx            x0, x0, #0xc, #0x14
    // 0xafbd14: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xafbd14: mov             x17, #0x5e41
    //     0xafbd18: movk            x17, #1, lsl #16
    //     0xafbd1c: add             lr, x0, x17
    //     0xafbd20: ldr             lr, [x21, lr, lsl #3]
    //     0xafbd24: blr             lr
    // 0xafbd28: LoadField: r1 = r0->field_2f
    //     0xafbd28: ldur            w1, [x0, #0x2f]
    // 0xafbd2c: DecompressPointer r1
    //     0xafbd2c: add             x1, x1, HEAP, lsl #32
    // 0xafbd30: mov             x0, x1
    // 0xafbd34: LeaveFrame
    //     0xafbd34: mov             SP, fp
    //     0xafbd38: ldp             fp, lr, [SP], #0x10
    // 0xafbd3c: ret
    //     0xafbd3c: ret             
    // 0xafbd40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafbd40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafbd44: b               #0xafbd0c
  }
  get _ pressureMax(/* No info */) {
    // ** addr: 0xb009a0, size: 0x48
    // 0xb009a0: EnterFrame
    //     0xb009a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb009a4: mov             fp, SP
    // 0xb009a8: CheckStackOverflow
    //     0xb009a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb009ac: cmp             SP, x16
    //     0xb009b0: b.ls            #0xb009e0
    // 0xb009b4: r0 = LoadClassIdInstr(r1)
    //     0xb009b4: ldur            x0, [x1, #-1]
    //     0xb009b8: ubfx            x0, x0, #0xc, #0x14
    // 0xb009bc: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xb009bc: mov             x17, #0x5e41
    //     0xb009c0: movk            x17, #1, lsl #16
    //     0xb009c4: add             lr, x0, x17
    //     0xb009c8: ldr             lr, [x21, lr, lsl #3]
    //     0xb009cc: blr             lr
    // 0xb009d0: LoadField: d0 = r0->field_57
    //     0xb009d0: ldur            d0, [x0, #0x57]
    // 0xb009d4: LeaveFrame
    //     0xb009d4: mov             SP, fp
    //     0xb009d8: ldp             fp, lr, [SP], #0x10
    // 0xb009dc: ret
    //     0xb009dc: ret             
    // 0xb009e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb009e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb009e4: b               #0xb009b4
  }
  get _ platformData(/* No info */) {
    // ** addr: 0xb01f7c, size: 0x4c
    // 0xb01f7c: EnterFrame
    //     0xb01f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb01f80: mov             fp, SP
    // 0xb01f84: CheckStackOverflow
    //     0xb01f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb01f88: cmp             SP, x16
    //     0xb01f8c: b.ls            #0xb01fc0
    // 0xb01f90: r0 = LoadClassIdInstr(r1)
    //     0xb01f90: ldur            x0, [x1, #-1]
    //     0xb01f94: ubfx            x0, x0, #0xc, #0x14
    // 0xb01f98: r0 = GDT[cid_x0 + 0x15e41]()
    //     0xb01f98: mov             x17, #0x5e41
    //     0xb01f9c: movk            x17, #1, lsl #16
    //     0xb01fa0: add             lr, x0, x17
    //     0xb01fa4: ldr             lr, [x21, lr, lsl #3]
    //     0xb01fa8: blr             lr
    // 0xb01fac: LoadField: r1 = r0->field_a7
    //     0xb01fac: ldur            x1, [x0, #0xa7]
    // 0xb01fb0: mov             x0, x1
    // 0xb01fb4: LeaveFrame
    //     0xb01fb4: mov             SP, fp
    //     0xb01fb8: ldp             fp, lr, [SP], #0x10
    // 0xb01fbc: ret
    //     0xb01fbc: ret             
    // 0xb01fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01fc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01fc4: b               #0xb01f90
  }
  get _ obscured(/* No info */) {
    // ** addr: 0x10f48b0, size: 0x50
    // 0x10f48b0: EnterFrame
    //     0x10f48b0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f48b4: mov             fp, SP
    // 0x10f48b8: CheckStackOverflow
    //     0x10f48b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f48bc: cmp             SP, x16
    //     0x10f48c0: b.ls            #0x10f48f8
    // 0x10f48c4: r0 = LoadClassIdInstr(r1)
    //     0x10f48c4: ldur            x0, [x1, #-1]
    //     0x10f48c8: ubfx            x0, x0, #0xc, #0x14
    // 0x10f48cc: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x10f48cc: mov             x17, #0x5e41
    //     0x10f48d0: movk            x17, #1, lsl #16
    //     0x10f48d4: add             lr, x0, x17
    //     0x10f48d8: ldr             lr, [x21, lr, lsl #3]
    //     0x10f48dc: blr             lr
    // 0x10f48e0: LoadField: r1 = r0->field_43
    //     0x10f48e0: ldur            w1, [x0, #0x43]
    // 0x10f48e4: DecompressPointer r1
    //     0x10f48e4: add             x1, x1, HEAP, lsl #32
    // 0x10f48e8: mov             x0, x1
    // 0x10f48ec: LeaveFrame
    //     0x10f48ec: mov             SP, fp
    //     0x10f48f0: ldp             fp, lr, [SP], #0x10
    // 0x10f48f4: ret
    //     0x10f48f4: ret             
    // 0x10f48f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f48f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f48fc: b               #0x10f48c4
  }
  get _ distance(/* No info */) {
    // ** addr: 0x11080c0, size: 0x48
    // 0x11080c0: EnterFrame
    //     0x11080c0: stp             fp, lr, [SP, #-0x10]!
    //     0x11080c4: mov             fp, SP
    // 0x11080c8: CheckStackOverflow
    //     0x11080c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11080cc: cmp             SP, x16
    //     0x11080d0: b.ls            #0x1108100
    // 0x11080d4: r0 = LoadClassIdInstr(r1)
    //     0x11080d4: ldur            x0, [x1, #-1]
    //     0x11080d8: ubfx            x0, x0, #0xc, #0x14
    // 0x11080dc: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x11080dc: mov             x17, #0x5e41
    //     0x11080e0: movk            x17, #1, lsl #16
    //     0x11080e4: add             lr, x0, x17
    //     0x11080e8: ldr             lr, [x21, lr, lsl #3]
    //     0x11080ec: blr             lr
    // 0x11080f0: LoadField: d0 = r0->field_5f
    //     0x11080f0: ldur            d0, [x0, #0x5f]
    // 0x11080f4: LeaveFrame
    //     0x11080f4: mov             SP, fp
    //     0x11080f8: ldp             fp, lr, [SP], #0x10
    // 0x11080fc: ret
    //     0x11080fc: ret             
    // 0x1108100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1108100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1108104: b               #0x11080d4
  }
  get _ pressure(/* No info */) {
    // ** addr: 0x1144fe0, size: 0x48
    // 0x1144fe0: EnterFrame
    //     0x1144fe0: stp             fp, lr, [SP, #-0x10]!
    //     0x1144fe4: mov             fp, SP
    // 0x1144fe8: CheckStackOverflow
    //     0x1144fe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1144fec: cmp             SP, x16
    //     0x1144ff0: b.ls            #0x1145020
    // 0x1144ff4: r0 = LoadClassIdInstr(r1)
    //     0x1144ff4: ldur            x0, [x1, #-1]
    //     0x1144ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x1144ffc: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x1144ffc: mov             x17, #0x5e41
    //     0x1145000: movk            x17, #1, lsl #16
    //     0x1145004: add             lr, x0, x17
    //     0x1145008: ldr             lr, [x21, lr, lsl #3]
    //     0x114500c: blr             lr
    // 0x1145010: LoadField: d0 = r0->field_47
    //     0x1145010: ldur            d0, [x0, #0x47]
    // 0x1145014: LeaveFrame
    //     0x1145014: mov             SP, fp
    //     0x1145018: ldp             fp, lr, [SP], #0x10
    // 0x114501c: ret
    //     0x114501c: ret             
    // 0x1145020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1145020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1145024: b               #0x1144ff4
  }
  get _ tilt(/* No info */) {
    // ** addr: 0x116be60, size: 0x48
    // 0x116be60: EnterFrame
    //     0x116be60: stp             fp, lr, [SP, #-0x10]!
    //     0x116be64: mov             fp, SP
    // 0x116be68: CheckStackOverflow
    //     0x116be68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116be6c: cmp             SP, x16
    //     0x116be70: b.ls            #0x116bea0
    // 0x116be74: r0 = LoadClassIdInstr(r1)
    //     0x116be74: ldur            x0, [x1, #-1]
    //     0x116be78: ubfx            x0, x0, #0xc, #0x14
    // 0x116be7c: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x116be7c: mov             x17, #0x5e41
    //     0x116be80: movk            x17, #1, lsl #16
    //     0x116be84: add             lr, x0, x17
    //     0x116be88: ldr             lr, [x21, lr, lsl #3]
    //     0x116be8c: blr             lr
    // 0x116be90: LoadField: d0 = r0->field_9f
    //     0x116be90: ldur            d0, [x0, #0x9f]
    // 0x116be94: LeaveFrame
    //     0x116be94: mov             SP, fp
    //     0x116be98: ldp             fp, lr, [SP], #0x10
    // 0x116be9c: ret
    //     0x116be9c: ret             
    // 0x116bea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116bea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116bea4: b               #0x116be74
  }
  get _ radiusMax(/* No info */) {
    // ** addr: 0x1198c80, size: 0x48
    // 0x1198c80: EnterFrame
    //     0x1198c80: stp             fp, lr, [SP, #-0x10]!
    //     0x1198c84: mov             fp, SP
    // 0x1198c88: CheckStackOverflow
    //     0x1198c88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1198c8c: cmp             SP, x16
    //     0x1198c90: b.ls            #0x1198cc0
    // 0x1198c94: r0 = LoadClassIdInstr(r1)
    //     0x1198c94: ldur            x0, [x1, #-1]
    //     0x1198c98: ubfx            x0, x0, #0xc, #0x14
    // 0x1198c9c: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x1198c9c: mov             x17, #0x5e41
    //     0x1198ca0: movk            x17, #1, lsl #16
    //     0x1198ca4: add             lr, x0, x17
    //     0x1198ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x1198cac: blr             lr
    // 0x1198cb0: LoadField: d0 = r0->field_8f
    //     0x1198cb0: ldur            d0, [x0, #0x8f]
    // 0x1198cb4: LeaveFrame
    //     0x1198cb4: mov             SP, fp
    //     0x1198cb8: ldp             fp, lr, [SP], #0x10
    // 0x1198cbc: ret
    //     0x1198cbc: ret             
    // 0x1198cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1198cc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1198cc4: b               #0x1198c94
  }
  get _ pointer(/* No info */) {
    // ** addr: 0x128524c, size: 0x4c
    // 0x128524c: EnterFrame
    //     0x128524c: stp             fp, lr, [SP, #-0x10]!
    //     0x1285250: mov             fp, SP
    // 0x1285254: CheckStackOverflow
    //     0x1285254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1285258: cmp             SP, x16
    //     0x128525c: b.ls            #0x1285290
    // 0x1285260: r0 = LoadClassIdInstr(r1)
    //     0x1285260: ldur            x0, [x1, #-1]
    //     0x1285264: ubfx            x0, x0, #0xc, #0x14
    // 0x1285268: r0 = GDT[cid_x0 + 0x15e41]()
    //     0x1285268: mov             x17, #0x5e41
    //     0x128526c: movk            x17, #1, lsl #16
    //     0x1285270: add             lr, x0, x17
    //     0x1285274: ldr             lr, [x21, lr, lsl #3]
    //     0x1285278: blr             lr
    // 0x128527c: LoadField: r1 = r0->field_1b
    //     0x128527c: ldur            x1, [x0, #0x1b]
    // 0x1285280: mov             x0, x1
    // 0x1285284: LeaveFrame
    //     0x1285284: mov             SP, fp
    //     0x1285288: ldp             fp, lr, [SP], #0x10
    // 0x128528c: ret
    //     0x128528c: ret             
    // 0x1285290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1285290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1285294: b               #0x1285260
  }
}

// class id: 4139, size: 0x18, field offset: 0x10
class _TransformedPointerCancelEvent extends _MixinApplication498&_TransformedPointerEvent&_CopyPointerCancelEvent
    implements PointerCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae7364, size: 0x38
    // 0xae7364: EnterFrame
    //     0xae7364: stp             fp, lr, [SP, #-0x10]!
    //     0xae7368: mov             fp, SP
    // 0xae736c: CheckStackOverflow
    //     0xae736c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7370: cmp             SP, x16
    //     0xae7374: b.ls            #0xae7394
    // 0xae7378: LoadField: r0 = r1->field_f
    //     0xae7378: ldur            w0, [x1, #0xf]
    // 0xae737c: DecompressPointer r0
    //     0xae737c: add             x0, x0, HEAP, lsl #32
    // 0xae7380: mov             x1, x0
    // 0xae7384: r0 = transformed()
    //     0xae7384: bl              #0xada534  ; [package:flutter/src/gestures/events.dart] PointerCancelEvent::transformed
    // 0xae7388: LeaveFrame
    //     0xae7388: mov             SP, fp
    //     0xae738c: ldp             fp, lr, [SP], #0x10
    // 0xae7390: ret
    //     0xae7390: ret             
    // 0xae7394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae7394: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7398: b               #0xae7378
  }
}

// class id: 4141, size: 0x18, field offset: 0x10
class _TransformedPointerPanZoomEndEvent extends _MixinApplication496&_TransformedPointerEvent&_CopyPointerPanZoomEndEvent
    implements PointerPanZoomEndEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae732c, size: 0x38
    // 0xae732c: EnterFrame
    //     0xae732c: stp             fp, lr, [SP, #-0x10]!
    //     0xae7330: mov             fp, SP
    // 0xae7334: CheckStackOverflow
    //     0xae7334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7338: cmp             SP, x16
    //     0xae733c: b.ls            #0xae735c
    // 0xae7340: LoadField: r0 = r1->field_f
    //     0xae7340: ldur            w0, [x1, #0xf]
    // 0xae7344: DecompressPointer r0
    //     0xae7344: add             x0, x0, HEAP, lsl #32
    // 0xae7348: mov             x1, x0
    // 0xae734c: r0 = transformed()
    //     0xae734c: bl              #0xada2b4  ; [package:flutter/src/gestures/events.dart] PointerPanZoomEndEvent::transformed
    // 0xae7350: LeaveFrame
    //     0xae7350: mov             SP, fp
    //     0xae7354: ldp             fp, lr, [SP], #0x10
    // 0xae7358: ret
    //     0xae7358: ret             
    // 0xae735c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae735c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7360: b               #0xae7340
  }
}

// class id: 4143, size: 0x20, field offset: 0x10
class _TransformedPointerPanZoomUpdateEvent extends _MixinApplication494&_TransformedPointerEvent&_CopyPointerPanZoomUpdateEvent
    implements PointerPanZoomUpdateEvent {

  late final Offset localPanDelta; // offset: 0x14
  late final Offset localPan; // offset: 0x10

  _ transformed(/* No info */) {
    // ** addr: 0xae72f4, size: 0x38
    // 0xae72f4: EnterFrame
    //     0xae72f4: stp             fp, lr, [SP, #-0x10]!
    //     0xae72f8: mov             fp, SP
    // 0xae72fc: CheckStackOverflow
    //     0xae72fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7300: cmp             SP, x16
    //     0xae7304: b.ls            #0xae7324
    // 0xae7308: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xae7308: ldur            w0, [x1, #0x17]
    // 0xae730c: DecompressPointer r0
    //     0xae730c: add             x0, x0, HEAP, lsl #32
    // 0xae7310: mov             x1, x0
    // 0xae7314: r0 = transformed()
    //     0xae7314: bl              #0xada02c  ; [package:flutter/src/gestures/events.dart] PointerPanZoomUpdateEvent::transformed
    // 0xae7318: LeaveFrame
    //     0xae7318: mov             SP, fp
    //     0xae731c: ldp             fp, lr, [SP], #0x10
    // 0xae7320: ret
    //     0xae7320: ret             
    // 0xae7324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae7324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7328: b               #0xae7308
  }
  const Offset localPanDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x125e33c, size: 0x38
    // 0x125e33c: EnterFrame
    //     0x125e33c: stp             fp, lr, [SP, #-0x10]!
    //     0x125e340: mov             fp, SP
    // 0x125e344: mov             x0, x1
    // 0x125e348: LoadField: r0 = r1->field_13
    //     0x125e348: ldur            w0, [x1, #0x13]
    // 0x125e34c: DecompressPointer r0
    //     0x125e34c: add             x0, x0, HEAP, lsl #32
    // 0x125e350: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x125e354: cmp             w0, w16
    // 0x125e358: b.ne            #0x125e368
    // 0x125e35c: r2 = localPanDelta
    //     0x125e35c: add             x2, PP, #0x90, lsl #12  ; [pp+0x90cc0] Field <_TransformedPointerPanZoomUpdateEvent@31050165.localPanDelta>: late final (offset: 0x14)
    //     0x125e360: ldr             x2, [x2, #0xcc0]
    // 0x125e364: r0 = InitLateFinalInstanceField()
    //     0x125e364: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x125e368: LeaveFrame
    //     0x125e368: mov             SP, fp
    //     0x125e36c: ldp             fp, lr, [SP], #0x10
    // 0x125e370: ret
    //     0x125e370: ret             
  }
  Offset localPanDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x125e374, size: 0x98
    // 0x125e374: EnterFrame
    //     0x125e374: stp             fp, lr, [SP, #-0x10]!
    //     0x125e378: mov             fp, SP
    // 0x125e37c: AllocStack(0x20)
    //     0x125e37c: sub             SP, SP, #0x20
    // 0x125e380: CheckStackOverflow
    //     0x125e380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125e384: cmp             SP, x16
    //     0x125e388: b.ls            #0x125e404
    // 0x125e38c: ldr             x1, [fp, #0x10]
    // 0x125e390: LoadField: r0 = r1->field_1b
    //     0x125e390: ldur            w0, [x1, #0x1b]
    // 0x125e394: DecompressPointer r0
    //     0x125e394: add             x0, x0, HEAP, lsl #32
    // 0x125e398: stur            x0, [fp, #-0x18]
    // 0x125e39c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x125e39c: ldur            w2, [x1, #0x17]
    // 0x125e3a0: DecompressPointer r2
    //     0x125e3a0: add             x2, x2, HEAP, lsl #32
    // 0x125e3a4: LoadField: r3 = r2->field_bf
    //     0x125e3a4: ldur            w3, [x2, #0xbf]
    // 0x125e3a8: DecompressPointer r3
    //     0x125e3a8: add             x3, x3, HEAP, lsl #32
    // 0x125e3ac: stur            x3, [fp, #-0x10]
    // 0x125e3b0: LoadField: r4 = r2->field_bb
    //     0x125e3b0: ldur            w4, [x2, #0xbb]
    // 0x125e3b4: DecompressPointer r4
    //     0x125e3b4: add             x4, x4, HEAP, lsl #32
    // 0x125e3b8: stur            x4, [fp, #-8]
    // 0x125e3bc: LoadField: r0 = r1->field_f
    //     0x125e3bc: ldur            w0, [x1, #0xf]
    // 0x125e3c0: DecompressPointer r0
    //     0x125e3c0: add             x0, x0, HEAP, lsl #32
    // 0x125e3c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x125e3c8: cmp             w0, w16
    // 0x125e3cc: b.ne            #0x125e3dc
    // 0x125e3d0: r2 = localPan
    //     0x125e3d0: add             x2, PP, #0x90, lsl #12  ; [pp+0x90cc8] Field <_TransformedPointerPanZoomUpdateEvent@31050165.localPan>: late final (offset: 0x10)
    //     0x125e3d4: ldr             x2, [x2, #0xcc8]
    // 0x125e3d8: r0 = InitLateFinalInstanceField()
    //     0x125e3d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x125e3dc: str             x0, [SP]
    // 0x125e3e0: ldur            x1, [fp, #-0x18]
    // 0x125e3e4: ldur            x2, [fp, #-0x10]
    // 0x125e3e8: ldur            x3, [fp, #-8]
    // 0x125e3ec: r4 = const [0, 0x4, 0x1, 0x3, transformedEndPosition, 0x3, null]
    //     0x125e3ec: add             x4, PP, #0x90, lsl #12  ; [pp+0x90cd0] List(7) [0, 0x4, 0x1, 0x3, "transformedEndPosition", 0x3, Null]
    //     0x125e3f0: ldr             x4, [x4, #0xcd0]
    // 0x125e3f4: r0 = transformDeltaViaPositions()
    //     0x125e3f4: bl              #0xaccb44  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0x125e3f8: LeaveFrame
    //     0x125e3f8: mov             SP, fp
    //     0x125e3fc: ldp             fp, lr, [SP], #0x10
    // 0x125e400: ret
    //     0x125e400: ret             
    // 0x125e404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125e404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125e408: b               #0x125e38c
  }
  Offset localPan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x125e40c, size: 0x4c
    // 0x125e40c: EnterFrame
    //     0x125e40c: stp             fp, lr, [SP, #-0x10]!
    //     0x125e410: mov             fp, SP
    // 0x125e414: CheckStackOverflow
    //     0x125e414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125e418: cmp             SP, x16
    //     0x125e41c: b.ls            #0x125e450
    // 0x125e420: ldr             x0, [fp, #0x10]
    // 0x125e424: LoadField: r1 = r0->field_1b
    //     0x125e424: ldur            w1, [x0, #0x1b]
    // 0x125e428: DecompressPointer r1
    //     0x125e428: add             x1, x1, HEAP, lsl #32
    // 0x125e42c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x125e42c: ldur            w2, [x0, #0x17]
    // 0x125e430: DecompressPointer r2
    //     0x125e430: add             x2, x2, HEAP, lsl #32
    // 0x125e434: LoadField: r0 = r2->field_bb
    //     0x125e434: ldur            w0, [x2, #0xbb]
    // 0x125e438: DecompressPointer r0
    //     0x125e438: add             x0, x0, HEAP, lsl #32
    // 0x125e43c: mov             x2, x0
    // 0x125e440: r0 = transformPosition()
    //     0x125e440: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x125e444: LeaveFrame
    //     0x125e444: mov             SP, fp
    //     0x125e448: ldp             fp, lr, [SP], #0x10
    // 0x125e44c: ret
    //     0x125e44c: ret             
    // 0x125e450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125e450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125e454: b               #0x125e420
  }
  const Offset localPan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x125e6f0, size: 0x38
    // 0x125e6f0: EnterFrame
    //     0x125e6f0: stp             fp, lr, [SP, #-0x10]!
    //     0x125e6f4: mov             fp, SP
    // 0x125e6f8: mov             x0, x1
    // 0x125e6fc: LoadField: r0 = r1->field_f
    //     0x125e6fc: ldur            w0, [x1, #0xf]
    // 0x125e700: DecompressPointer r0
    //     0x125e700: add             x0, x0, HEAP, lsl #32
    // 0x125e704: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x125e708: cmp             w0, w16
    // 0x125e70c: b.ne            #0x125e71c
    // 0x125e710: r2 = localPan
    //     0x125e710: add             x2, PP, #0x90, lsl #12  ; [pp+0x90cc8] Field <_TransformedPointerPanZoomUpdateEvent@31050165.localPan>: late final (offset: 0x10)
    //     0x125e714: ldr             x2, [x2, #0xcc8]
    // 0x125e718: r0 = InitLateFinalInstanceField()
    //     0x125e718: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x125e71c: LeaveFrame
    //     0x125e71c: mov             SP, fp
    //     0x125e720: ldp             fp, lr, [SP], #0x10
    // 0x125e724: ret
    //     0x125e724: ret             
  }
  get _ rotation(/* No info */) {
    // ** addr: 0x125e8ec, size: 0x10
    // 0x125e8ec: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x125e8ec: ldur            w0, [x1, #0x17]
    // 0x125e8f0: DecompressPointer r0
    //     0x125e8f0: add             x0, x0, HEAP, lsl #32
    // 0x125e8f4: LoadField: d0 = r0->field_cb
    //     0x125e8f4: ldur            d0, [x0, #0xcb]
    // 0x125e8f8: ret
    //     0x125e8f8: ret             
  }
  get _ scale(/* No info */) {
    // ** addr: 0x125ed58, size: 0x10
    // 0x125ed58: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x125ed58: ldur            w0, [x1, #0x17]
    // 0x125ed5c: DecompressPointer r0
    //     0x125ed5c: add             x0, x0, HEAP, lsl #32
    // 0x125ed60: LoadField: d0 = r0->field_c3
    //     0x125ed60: ldur            d0, [x0, #0xc3]
    // 0x125ed64: ret
    //     0x125ed64: ret             
  }
  Offset panDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x125f47c, size: 0x14
    // 0x125f47c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x125f47c: ldur            w2, [x1, #0x17]
    // 0x125f480: DecompressPointer r2
    //     0x125f480: add             x2, x2, HEAP, lsl #32
    // 0x125f484: LoadField: r0 = r2->field_bf
    //     0x125f484: ldur            w0, [x2, #0xbf]
    // 0x125f488: DecompressPointer r0
    //     0x125f488: add             x0, x0, HEAP, lsl #32
    // 0x125f48c: ret
    //     0x125f48c: ret             
  }
  Offset pan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0x12b7e60, size: 0x14
    // 0x12b7e60: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x12b7e60: ldur            w2, [x1, #0x17]
    // 0x12b7e64: DecompressPointer r2
    //     0x12b7e64: add             x2, x2, HEAP, lsl #32
    // 0x12b7e68: LoadField: r0 = r2->field_bb
    //     0x12b7e68: ldur            w0, [x2, #0xbb]
    // 0x12b7e6c: DecompressPointer r0
    //     0x12b7e6c: add             x0, x0, HEAP, lsl #32
    // 0x12b7e70: ret
    //     0x12b7e70: ret             
  }
}

// class id: 4145, size: 0x18, field offset: 0x10
class _TransformedPointerPanZoomStartEvent extends _MixinApplication492&_TransformedPointerEvent&_CopyPointerPanZoomStartEvent
    implements PointerPanZoomStartEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae72bc, size: 0x38
    // 0xae72bc: EnterFrame
    //     0xae72bc: stp             fp, lr, [SP, #-0x10]!
    //     0xae72c0: mov             fp, SP
    // 0xae72c4: CheckStackOverflow
    //     0xae72c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae72c8: cmp             SP, x16
    //     0xae72cc: b.ls            #0xae72ec
    // 0xae72d0: LoadField: r0 = r1->field_f
    //     0xae72d0: ldur            w0, [x1, #0xf]
    // 0xae72d4: DecompressPointer r0
    //     0xae72d4: add             x0, x0, HEAP, lsl #32
    // 0xae72d8: mov             x1, x0
    // 0xae72dc: r0 = transformed()
    //     0xae72dc: bl              #0xad9dac  ; [package:flutter/src/gestures/events.dart] PointerPanZoomStartEvent::transformed
    // 0xae72e0: LeaveFrame
    //     0xae72e0: mov             SP, fp
    //     0xae72e4: ldp             fp, lr, [SP], #0x10
    // 0xae72e8: ret
    //     0xae72e8: ret             
    // 0xae72ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae72ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae72f0: b               #0xae72d0
  }
}

// class id: 4148, size: 0x18, field offset: 0x10
class _TransformedPointerScaleEvent extends _MixinApplication490&_TransformedPointerEvent&_CopyPointerScaleEvent&_RespondablePointerEvent
    implements PointerScaleEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae7284, size: 0x38
    // 0xae7284: EnterFrame
    //     0xae7284: stp             fp, lr, [SP, #-0x10]!
    //     0xae7288: mov             fp, SP
    // 0xae728c: CheckStackOverflow
    //     0xae728c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7290: cmp             SP, x16
    //     0xae7294: b.ls            #0xae72b4
    // 0xae7298: LoadField: r0 = r1->field_f
    //     0xae7298: ldur            w0, [x1, #0xf]
    // 0xae729c: DecompressPointer r0
    //     0xae729c: add             x0, x0, HEAP, lsl #32
    // 0xae72a0: mov             x1, x0
    // 0xae72a4: r0 = transformed()
    //     0xae72a4: bl              #0xadb998  ; [package:flutter/src/gestures/events.dart] PointerScaleEvent::transformed
    // 0xae72a8: LeaveFrame
    //     0xae72a8: mov             SP, fp
    //     0xae72ac: ldp             fp, lr, [SP], #0x10
    // 0xae72b0: ret
    //     0xae72b0: ret             
    // 0xae72b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae72b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae72b8: b               #0xae7298
  }
  get _ scale(/* No info */) {
    // ** addr: 0x125f3e8, size: 0x10
    // 0x125f3e8: LoadField: r0 = r1->field_f
    //     0x125f3e8: ldur            w0, [x1, #0xf]
    // 0x125f3ec: DecompressPointer r0
    //     0x125f3ec: add             x0, x0, HEAP, lsl #32
    // 0x125f3f0: LoadField: d0 = r0->field_bb
    //     0x125f3f0: ldur            d0, [x0, #0xbb]
    // 0x125f3f4: ret
    //     0x125f3f4: ret             
  }
}

// class id: 4151, size: 0x18, field offset: 0x10
class _TransformedPointerScrollInertiaCancelEvent extends _MixinApplication487&_TransformedPointerEvent&_CopyPointerScrollInertiaCancelEvent&_RespondablePointerEvent
    implements PointerScrollInertiaCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae724c, size: 0x38
    // 0xae724c: EnterFrame
    //     0xae724c: stp             fp, lr, [SP, #-0x10]!
    //     0xae7250: mov             fp, SP
    // 0xae7254: CheckStackOverflow
    //     0xae7254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7258: cmp             SP, x16
    //     0xae725c: b.ls            #0xae727c
    // 0xae7260: LoadField: r0 = r1->field_f
    //     0xae7260: ldur            w0, [x1, #0xf]
    // 0xae7264: DecompressPointer r0
    //     0xae7264: add             x0, x0, HEAP, lsl #32
    // 0xae7268: mov             x1, x0
    // 0xae726c: r0 = transformed()
    //     0xae726c: bl              #0xadb6f0  ; [package:flutter/src/gestures/events.dart] PointerScrollInertiaCancelEvent::transformed
    // 0xae7270: LeaveFrame
    //     0xae7270: mov             SP, fp
    //     0xae7274: ldp             fp, lr, [SP], #0x10
    // 0xae7278: ret
    //     0xae7278: ret             
    // 0xae727c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae727c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7280: b               #0xae7260
  }
}

// class id: 4153, size: 0x18, field offset: 0x10
class _TransformedPointerScrollEvent extends _MixinApplication484&_TransformedPointerEvent&_CopyPointerScrollEvent
    implements PointerScrollEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae7214, size: 0x38
    // 0xae7214: EnterFrame
    //     0xae7214: stp             fp, lr, [SP, #-0x10]!
    //     0xae7218: mov             fp, SP
    // 0xae721c: CheckStackOverflow
    //     0xae721c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7220: cmp             SP, x16
    //     0xae7224: b.ls            #0xae7244
    // 0xae7228: LoadField: r0 = r1->field_f
    //     0xae7228: ldur            w0, [x1, #0xf]
    // 0xae722c: DecompressPointer r0
    //     0xae722c: add             x0, x0, HEAP, lsl #32
    // 0xae7230: mov             x1, x0
    // 0xae7234: r0 = transformed()
    //     0xae7234: bl              #0xadb470  ; [package:flutter/src/gestures/events.dart] PointerScrollEvent::transformed
    // 0xae7238: LeaveFrame
    //     0xae7238: mov             SP, fp
    //     0xae723c: ldp             fp, lr, [SP], #0x10
    // 0xae7240: ret
    //     0xae7240: ret             
    // 0xae7244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae7244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7248: b               #0xae7228
  }
  _ respond(/* No info */) {
    // ** addr: 0x122b744, size: 0x3c
    // 0x122b744: EnterFrame
    //     0x122b744: stp             fp, lr, [SP, #-0x10]!
    //     0x122b748: mov             fp, SP
    // 0x122b74c: CheckStackOverflow
    //     0x122b74c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122b750: cmp             SP, x16
    //     0x122b754: b.ls            #0x122b778
    // 0x122b758: LoadField: r0 = r1->field_f
    //     0x122b758: ldur            w0, [x1, #0xf]
    // 0x122b75c: DecompressPointer r0
    //     0x122b75c: add             x0, x0, HEAP, lsl #32
    // 0x122b760: mov             x1, x0
    // 0x122b764: r0 = respond()
    //     0x122b764: bl              #0x11e0f10  ; [package:flutter/src/gestures/events.dart] PointerScrollEvent::respond
    // 0x122b768: r0 = Null
    //     0x122b768: mov             x0, NULL
    // 0x122b76c: LeaveFrame
    //     0x122b76c: mov             SP, fp
    //     0x122b770: ldp             fp, lr, [SP], #0x10
    // 0x122b774: ret
    //     0x122b774: ret             
    // 0x122b778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122b778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122b77c: b               #0x122b758
  }
  get _ scrollDelta(/* No info */) {
    // ** addr: 0x12b73ac, size: 0x14
    // 0x12b73ac: LoadField: r2 = r1->field_f
    //     0x12b73ac: ldur            w2, [x1, #0xf]
    // 0x12b73b0: DecompressPointer r2
    //     0x12b73b0: add             x2, x2, HEAP, lsl #32
    // 0x12b73b4: LoadField: r0 = r2->field_bb
    //     0x12b73b4: ldur            w0, [x2, #0xbb]
    // 0x12b73b8: DecompressPointer r0
    //     0x12b73b8: add             x0, x0, HEAP, lsl #32
    // 0x12b73bc: ret
    //     0x12b73bc: ret             
  }
}

// class id: 4155, size: 0x18, field offset: 0x10
class _TransformedPointerUpEvent extends _MixinApplication480&_TransformedPointerEvent&_CopyPointerUpEvent
    implements PointerUpEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae71dc, size: 0x38
    // 0xae71dc: EnterFrame
    //     0xae71dc: stp             fp, lr, [SP, #-0x10]!
    //     0xae71e0: mov             fp, SP
    // 0xae71e4: CheckStackOverflow
    //     0xae71e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae71e8: cmp             SP, x16
    //     0xae71ec: b.ls            #0xae720c
    // 0xae71f0: LoadField: r0 = r1->field_f
    //     0xae71f0: ldur            w0, [x1, #0xf]
    // 0xae71f4: DecompressPointer r0
    //     0xae71f4: add             x0, x0, HEAP, lsl #32
    // 0xae71f8: mov             x1, x0
    // 0xae71fc: r0 = transformed()
    //     0xae71fc: bl              #0xad9b2c  ; [package:flutter/src/gestures/events.dart] PointerUpEvent::transformed
    // 0xae7200: LeaveFrame
    //     0xae7200: mov             SP, fp
    //     0xae7204: ldp             fp, lr, [SP], #0x10
    // 0xae7208: ret
    //     0xae7208: ret             
    // 0xae720c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae720c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7210: b               #0xae71f0
  }
}

// class id: 4157, size: 0x18, field offset: 0x10
class _TransformedPointerMoveEvent extends _MixinApplication478&_TransformedPointerEvent&_CopyPointerMoveEvent
    implements PointerMoveEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae71a4, size: 0x38
    // 0xae71a4: EnterFrame
    //     0xae71a4: stp             fp, lr, [SP, #-0x10]!
    //     0xae71a8: mov             fp, SP
    // 0xae71ac: CheckStackOverflow
    //     0xae71ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae71b0: cmp             SP, x16
    //     0xae71b4: b.ls            #0xae71d4
    // 0xae71b8: LoadField: r0 = r1->field_f
    //     0xae71b8: ldur            w0, [x1, #0xf]
    // 0xae71bc: DecompressPointer r0
    //     0xae71bc: add             x0, x0, HEAP, lsl #32
    // 0xae71c0: mov             x1, x0
    // 0xae71c4: r0 = transformed()
    //     0xae71c4: bl              #0xad9658  ; [package:flutter/src/gestures/events.dart] PointerMoveEvent::transformed
    // 0xae71c8: LeaveFrame
    //     0xae71c8: mov             SP, fp
    //     0xae71cc: ldp             fp, lr, [SP], #0x10
    // 0xae71d0: ret
    //     0xae71d0: ret             
    // 0xae71d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae71d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae71d8: b               #0xae71b8
  }
}

// class id: 4159, size: 0x18, field offset: 0x10
class _TransformedPointerDownEvent extends _MixinApplication476&_TransformedPointerEvent&_CopyPointerDownEvent
    implements PointerDownEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae716c, size: 0x38
    // 0xae716c: EnterFrame
    //     0xae716c: stp             fp, lr, [SP, #-0x10]!
    //     0xae7170: mov             fp, SP
    // 0xae7174: CheckStackOverflow
    //     0xae7174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7178: cmp             SP, x16
    //     0xae717c: b.ls            #0xae719c
    // 0xae7180: LoadField: r0 = r1->field_f
    //     0xae7180: ldur            w0, [x1, #0xf]
    // 0xae7184: DecompressPointer r0
    //     0xae7184: add             x0, x0, HEAP, lsl #32
    // 0xae7188: mov             x1, x0
    // 0xae718c: r0 = transformed()
    //     0xae718c: bl              #0xad95f4  ; [package:flutter/src/gestures/events.dart] PointerDownEvent::transformed
    // 0xae7190: LeaveFrame
    //     0xae7190: mov             SP, fp
    //     0xae7194: ldp             fp, lr, [SP], #0x10
    // 0xae7198: ret
    //     0xae7198: ret             
    // 0xae719c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae719c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae71a0: b               #0xae7180
  }
}

// class id: 4161, size: 0x18, field offset: 0x10
class _TransformedPointerExitEvent extends _MixinApplication474&_TransformedPointerEvent&_CopyPointerExitEvent
    implements PointerExitEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae7134, size: 0x38
    // 0xae7134: EnterFrame
    //     0xae7134: stp             fp, lr, [SP, #-0x10]!
    //     0xae7138: mov             fp, SP
    // 0xae713c: CheckStackOverflow
    //     0xae713c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7140: cmp             SP, x16
    //     0xae7144: b.ls            #0xae7164
    // 0xae7148: LoadField: r0 = r1->field_f
    //     0xae7148: ldur            w0, [x1, #0xf]
    // 0xae714c: DecompressPointer r0
    //     0xae714c: add             x0, x0, HEAP, lsl #32
    // 0xae7150: mov             x1, x0
    // 0xae7154: r0 = transformed()
    //     0xae7154: bl              #0xad9590  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::transformed
    // 0xae7158: LeaveFrame
    //     0xae7158: mov             SP, fp
    //     0xae715c: ldp             fp, lr, [SP], #0x10
    // 0xae7160: ret
    //     0xae7160: ret             
    // 0xae7164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae7164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7168: b               #0xae7148
  }
}

// class id: 4163, size: 0x18, field offset: 0x10
class _TransformedPointerEnterEvent extends _MixinApplication472&_TransformedPointerEvent&_CopyPointerEnterEvent
    implements PointerEnterEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae70fc, size: 0x38
    // 0xae70fc: EnterFrame
    //     0xae70fc: stp             fp, lr, [SP, #-0x10]!
    //     0xae7100: mov             fp, SP
    // 0xae7104: CheckStackOverflow
    //     0xae7104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7108: cmp             SP, x16
    //     0xae710c: b.ls            #0xae712c
    // 0xae7110: LoadField: r0 = r1->field_f
    //     0xae7110: ldur            w0, [x1, #0xf]
    // 0xae7114: DecompressPointer r0
    //     0xae7114: add             x0, x0, HEAP, lsl #32
    // 0xae7118: mov             x1, x0
    // 0xae711c: r0 = transformed()
    //     0xae711c: bl              #0xad952c  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::transformed
    // 0xae7120: LeaveFrame
    //     0xae7120: mov             SP, fp
    //     0xae7124: ldp             fp, lr, [SP], #0x10
    // 0xae7128: ret
    //     0xae7128: ret             
    // 0xae712c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae712c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7130: b               #0xae7110
  }
}

// class id: 4165, size: 0x18, field offset: 0x10
class _TransformedPointerHoverEvent extends _MixinApplication470&_TransformedPointerEvent&_CopyPointerHoverEvent
    implements PointerHoverEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae70c4, size: 0x38
    // 0xae70c4: EnterFrame
    //     0xae70c4: stp             fp, lr, [SP, #-0x10]!
    //     0xae70c8: mov             fp, SP
    // 0xae70cc: CheckStackOverflow
    //     0xae70cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae70d0: cmp             SP, x16
    //     0xae70d4: b.ls            #0xae70f4
    // 0xae70d8: LoadField: r0 = r1->field_f
    //     0xae70d8: ldur            w0, [x1, #0xf]
    // 0xae70dc: DecompressPointer r0
    //     0xae70dc: add             x0, x0, HEAP, lsl #32
    // 0xae70e0: mov             x1, x0
    // 0xae70e4: r0 = transformed()
    //     0xae70e4: bl              #0xad94c8  ; [package:flutter/src/gestures/events.dart] PointerHoverEvent::transformed
    // 0xae70e8: LeaveFrame
    //     0xae70e8: mov             SP, fp
    //     0xae70ec: ldp             fp, lr, [SP], #0x10
    // 0xae70f0: ret
    //     0xae70f0: ret             
    // 0xae70f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae70f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae70f8: b               #0xae70d8
  }
}

// class id: 4167, size: 0x18, field offset: 0x10
class _TransformedPointerRemovedEvent extends _MixinApplication468&_TransformedPointerEvent&_CopyPointerRemovedEvent
    implements PointerRemovedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae708c, size: 0x38
    // 0xae708c: EnterFrame
    //     0xae708c: stp             fp, lr, [SP, #-0x10]!
    //     0xae7090: mov             fp, SP
    // 0xae7094: CheckStackOverflow
    //     0xae7094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7098: cmp             SP, x16
    //     0xae709c: b.ls            #0xae70bc
    // 0xae70a0: LoadField: r0 = r1->field_f
    //     0xae70a0: ldur            w0, [x1, #0xf]
    // 0xae70a4: DecompressPointer r0
    //     0xae70a4: add             x0, x0, HEAP, lsl #32
    // 0xae70a8: mov             x1, x0
    // 0xae70ac: r0 = transformed()
    //     0xae70ac: bl              #0xad9464  ; [package:flutter/src/gestures/events.dart] PointerRemovedEvent::transformed
    // 0xae70b0: LeaveFrame
    //     0xae70b0: mov             SP, fp
    //     0xae70b4: ldp             fp, lr, [SP], #0x10
    // 0xae70b8: ret
    //     0xae70b8: ret             
    // 0xae70bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae70bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae70c0: b               #0xae70a0
  }
}

// class id: 4169, size: 0x18, field offset: 0x10
class _TransformedPointerAddedEvent extends _MixinApplication466&_TransformedPointerEvent&_CopyPointerAddedEvent
    implements PointerAddedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xae7054, size: 0x38
    // 0xae7054: EnterFrame
    //     0xae7054: stp             fp, lr, [SP, #-0x10]!
    //     0xae7058: mov             fp, SP
    // 0xae705c: CheckStackOverflow
    //     0xae705c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae7060: cmp             SP, x16
    //     0xae7064: b.ls            #0xae7084
    // 0xae7068: LoadField: r0 = r1->field_f
    //     0xae7068: ldur            w0, [x1, #0xf]
    // 0xae706c: DecompressPointer r0
    //     0xae706c: add             x0, x0, HEAP, lsl #32
    // 0xae7070: mov             x1, x0
    // 0xae7074: r0 = transformed()
    //     0xae7074: bl              #0xad9400  ; [package:flutter/src/gestures/events.dart] PointerAddedEvent::transformed
    // 0xae7078: LeaveFrame
    //     0xae7078: mov             SP, fp
    //     0xae707c: ldp             fp, lr, [SP], #0x10
    // 0xae7080: ret
    //     0xae7080: ret             
    // 0xae7084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae7084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae7088: b               #0xae7068
  }
}

// class id: 5248, size: 0xbc, field offset: 0x8
//   const constructor, 
abstract class PointerEvent extends _MixinApplication3&Object&Diagnosticable {

  const get _ pressureMin(/* No info */) {
    // ** addr: 0x9fb634, size: 0x8
    // 0x9fb634: LoadField: d0 = r1->field_4f
    //     0x9fb634: ldur            d0, [x1, #0x4f]
    // 0x9fb638: ret
    //     0x9fb638: ret             
  }
  const get _ size(/* No info */) {
    // ** addr: 0x9fbf38, size: 0x8
    // 0x9fbf38: LoadField: d0 = r1->field_6f
    //     0x9fbf38: ldur            d0, [x1, #0x6f]
    // 0x9fbf3c: ret
    //     0x9fbf3c: ret             
  }
  const get _ buttons(/* No info */) {
    // ** addr: 0xa0bcfc, size: 0x8
    // 0xa0bcfc: LoadField: r0 = r1->field_37
    //     0xa0bcfc: ldur            x0, [x1, #0x37]
    // 0xa0bd00: ret
    //     0xa0bd00: ret             
  }
  const get _ orientation(/* No info */) {
    // ** addr: 0xa12b4c, size: 0x8
    // 0xa12b4c: LoadField: d0 = r1->field_97
    //     0xa12b4c: ldur            d0, [x1, #0x97]
    // 0xa12b50: ret
    //     0xa12b50: ret             
  }
  const get _ distanceMax(/* No info */) {
    // ** addr: 0xa12b54, size: 0x8
    // 0xa12b54: LoadField: d0 = r1->field_67
    //     0xa12b54: ldur            d0, [x1, #0x67]
    // 0xa12b58: ret
    //     0xa12b58: ret             
  }
  const get _ radiusMajor(/* No info */) {
    // ** addr: 0xa132dc, size: 0x8
    // 0xa132dc: LoadField: d0 = r1->field_77
    //     0xa132dc: ldur            d0, [x1, #0x77]
    // 0xa132e0: ret
    //     0xa132e0: ret             
  }
  const get _ device(/* No info */) {
    // ** addr: 0xa138c4, size: 0x8
    // 0xa138c4: LoadField: r0 = r1->field_27
    //     0xa138c4: ldur            x0, [x1, #0x27]
    // 0xa138c8: ret
    //     0xa138c8: ret             
  }
  static _ transformPosition(/* No info */) {
    // ** addr: 0xacbbac, size: 0xe8
    // 0xacbbac: EnterFrame
    //     0xacbbac: stp             fp, lr, [SP, #-0x10]!
    //     0xacbbb0: mov             fp, SP
    // 0xacbbb4: AllocStack(0x20)
    //     0xacbbb4: sub             SP, SP, #0x20
    // 0xacbbb8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xacbbb8: mov             x0, x2
    //     0xacbbbc: stur            x1, [fp, #-8]
    // 0xacbbc0: CheckStackOverflow
    //     0xacbbc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xacbbc4: cmp             SP, x16
    //     0xacbbc8: b.ls            #0xacbc84
    // 0xacbbcc: cmp             w1, NULL
    // 0xacbbd0: b.ne            #0xacbbe0
    // 0xacbbd4: LeaveFrame
    //     0xacbbd4: mov             SP, fp
    //     0xacbbd8: ldp             fp, lr, [SP], #0x10
    // 0xacbbdc: ret
    //     0xacbbdc: ret             
    // 0xacbbe0: LoadField: d0 = r0->field_7
    //     0xacbbe0: ldur            d0, [x0, #7]
    // 0xacbbe4: stur            d0, [fp, #-0x20]
    // 0xacbbe8: LoadField: d1 = r0->field_f
    //     0xacbbe8: ldur            d1, [x0, #0xf]
    // 0xacbbec: stur            d1, [fp, #-0x18]
    // 0xacbbf0: r0 = Vector3()
    //     0xacbbf0: bl              #0x8682fc  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0xacbbf4: r4 = 6
    //     0xacbbf4: mov             x4, #6
    // 0xacbbf8: stur            x0, [fp, #-0x10]
    // 0xacbbfc: r0 = AllocateFloat64Array()
    //     0xacbbfc: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xacbc00: ldur            x2, [fp, #-0x10]
    // 0xacbc04: StoreField: r2->field_7 = r0
    //     0xacbc04: stur            w0, [x2, #7]
    // 0xacbc08: StoreField: r0->field_27 = rZR
    //     0xacbc08: stur            xzr, [x0, #0x27]
    // 0xacbc0c: ldur            d0, [fp, #-0x18]
    // 0xacbc10: StoreField: r0->field_1f = d0
    //     0xacbc10: stur            d0, [x0, #0x1f]
    // 0xacbc14: ldur            d0, [fp, #-0x20]
    // 0xacbc18: ArrayStore: r0[0] = d0  ; List_8
    //     0xacbc18: stur            d0, [x0, #0x17]
    // 0xacbc1c: ldur            x1, [fp, #-8]
    // 0xacbc20: r0 = perspectiveTransform()
    //     0xacbc20: bl              #0x868130  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0xacbc24: LoadField: r2 = r0->field_7
    //     0xacbc24: ldur            w2, [x0, #7]
    // 0xacbc28: DecompressPointer r2
    //     0xacbc28: add             x2, x2, HEAP, lsl #32
    // 0xacbc2c: LoadField: r0 = r2->field_13
    //     0xacbc2c: ldur            w0, [x2, #0x13]
    // 0xacbc30: r3 = LoadInt32Instr(r0)
    //     0xacbc30: sbfx            x3, x0, #1, #0x1f
    // 0xacbc34: mov             x0, x3
    // 0xacbc38: r1 = 0
    //     0xacbc38: mov             x1, #0
    // 0xacbc3c: cmp             x1, x0
    // 0xacbc40: b.hs            #0xacbc8c
    // 0xacbc44: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xacbc44: ldur            d0, [x2, #0x17]
    // 0xacbc48: mov             x0, x3
    // 0xacbc4c: stur            d0, [fp, #-0x20]
    // 0xacbc50: r1 = 1
    //     0xacbc50: mov             x1, #1
    // 0xacbc54: cmp             x1, x0
    // 0xacbc58: b.hs            #0xacbc90
    // 0xacbc5c: LoadField: d1 = r2->field_1f
    //     0xacbc5c: ldur            d1, [x2, #0x1f]
    // 0xacbc60: stur            d1, [fp, #-0x18]
    // 0xacbc64: r0 = Offset()
    //     0xacbc64: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xacbc68: ldur            d0, [fp, #-0x20]
    // 0xacbc6c: StoreField: r0->field_7 = d0
    //     0xacbc6c: stur            d0, [x0, #7]
    // 0xacbc70: ldur            d0, [fp, #-0x18]
    // 0xacbc74: StoreField: r0->field_f = d0
    //     0xacbc74: stur            d0, [x0, #0xf]
    // 0xacbc78: LeaveFrame
    //     0xacbc78: mov             SP, fp
    //     0xacbc7c: ldp             fp, lr, [SP], #0x10
    // 0xacbc80: ret
    //     0xacbc80: ret             
    // 0xacbc84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacbc84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacbc88: b               #0xacbbcc
    // 0xacbc8c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacbc8c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacbc90: r0 = RangeErrorSharedWithFPURegs()
    //     0xacbc90: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  static _ transformDeltaViaPositions(/* No info */) {
    // ** addr: 0xaccb44, size: 0xd8
    // 0xaccb44: EnterFrame
    //     0xaccb44: stp             fp, lr, [SP, #-0x10]!
    //     0xaccb48: mov             fp, SP
    // 0xaccb4c: AllocStack(0x20)
    //     0xaccb4c: sub             SP, SP, #0x20
    // 0xaccb50: SetupParameters(dynamic _ /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, {dynamic transformedEndPosition = Null /* r1 */})
    //     0xaccb50: mov             x5, x1
    //     0xaccb54: mov             x0, x3
    //     0xaccb58: stur            x3, [fp, #-0x18]
    //     0xaccb5c: mov             x3, x2
    //     0xaccb60: stur            x1, [fp, #-8]
    //     0xaccb64: stur            x2, [fp, #-0x10]
    //     0xaccb68: ldur            w1, [x4, #0x13]
    //     0xaccb6c: ldur            w2, [x4, #0x1f]
    //     0xaccb70: add             x2, x2, HEAP, lsl #32
    //     0xaccb74: add             x16, PP, #0x26, lsl #12  ; [pp+0x26670] "transformedEndPosition"
    //     0xaccb78: ldr             x16, [x16, #0x670]
    //     0xaccb7c: cmp             w2, w16
    //     0xaccb80: b.ne            #0xaccb9c
    //     0xaccb84: ldur            w2, [x4, #0x23]
    //     0xaccb88: add             x2, x2, HEAP, lsl #32
    //     0xaccb8c: sub             w4, w1, w2
    //     0xaccb90: add             x1, fp, w4, sxtw #2
    //     0xaccb94: ldr             x1, [x1, #8]
    //     0xaccb98: b               #0xaccba0
    //     0xaccb9c: mov             x1, NULL
    // 0xaccba0: CheckStackOverflow
    //     0xaccba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaccba4: cmp             SP, x16
    //     0xaccba8: b.ls            #0xaccc14
    // 0xaccbac: cmp             w5, NULL
    // 0xaccbb0: b.ne            #0xaccbc4
    // 0xaccbb4: mov             x0, x3
    // 0xaccbb8: LeaveFrame
    //     0xaccbb8: mov             SP, fp
    //     0xaccbbc: ldp             fp, lr, [SP], #0x10
    // 0xaccbc0: ret
    //     0xaccbc0: ret             
    // 0xaccbc4: cmp             w1, NULL
    // 0xaccbc8: b.ne            #0xaccbdc
    // 0xaccbcc: mov             x1, x5
    // 0xaccbd0: mov             x2, x0
    // 0xaccbd4: r0 = transformPosition()
    //     0xaccbd4: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xaccbd8: b               #0xaccbe0
    // 0xaccbdc: mov             x0, x1
    // 0xaccbe0: ldur            x1, [fp, #-0x18]
    // 0xaccbe4: ldur            x2, [fp, #-0x10]
    // 0xaccbe8: stur            x0, [fp, #-0x20]
    // 0xaccbec: r0 = -()
    //     0xaccbec: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xaccbf0: ldur            x1, [fp, #-8]
    // 0xaccbf4: mov             x2, x0
    // 0xaccbf8: r0 = transformPosition()
    //     0xaccbf8: bl              #0xacbbac  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xaccbfc: ldur            x1, [fp, #-0x20]
    // 0xaccc00: mov             x2, x0
    // 0xaccc04: r0 = -()
    //     0xaccc04: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xaccc08: LeaveFrame
    //     0xaccc08: mov             SP, fp
    //     0xaccc0c: ldp             fp, lr, [SP], #0x10
    // 0xaccc10: ret
    //     0xaccc10: ret             
    // 0xaccc14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaccc14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaccc18: b               #0xaccbac
  }
  const get _ radiusMin(/* No info */) {
    // ** addr: 0xaef848, size: 0x8
    // 0xaef848: LoadField: d0 = r1->field_87
    //     0xaef848: ldur            d0, [x1, #0x87]
    // 0xaef84c: ret
    //     0xaef84c: ret             
  }
  const get _ radiusMinor(/* No info */) {
    // ** addr: 0xaf1ca0, size: 0x8
    // 0xaf1ca0: LoadField: d0 = r1->field_7f
    //     0xaf1ca0: ldur            d0, [x1, #0x7f]
    // 0xaf1ca4: ret
    //     0xaf1ca4: ret             
  }
  const get _ pressureMax(/* No info */) {
    // ** addr: 0xafc360, size: 0x8
    // 0xafc360: LoadField: d0 = r1->field_57
    //     0xafc360: ldur            d0, [x1, #0x57]
    // 0xafc364: ret
    //     0xafc364: ret             
  }
  const get _ platformData(/* No info */) {
    // ** addr: 0xafd658, size: 0x8
    // 0xafd658: LoadField: r0 = r1->field_a7
    //     0xafd658: ldur            x0, [x1, #0xa7]
    // 0xafd65c: ret
    //     0xafd65c: ret             
  }
  static _ removePerspectiveTransform(/* No info */) {
    // ** addr: 0x10e8d34, size: 0xd8
    // 0x10e8d34: EnterFrame
    //     0x10e8d34: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8d38: mov             fp, SP
    // 0x10e8d3c: AllocStack(0x10)
    //     0x10e8d3c: sub             SP, SP, #0x10
    // 0x10e8d40: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x10e8d40: mov             x0, x1
    //     0x10e8d44: stur            x1, [fp, #-8]
    // 0x10e8d48: CheckStackOverflow
    //     0x10e8d48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8d4c: cmp             SP, x16
    //     0x10e8d50: b.ls            #0x10e8dfc
    // 0x10e8d54: r1 = Null
    //     0x10e8d54: mov             x1, NULL
    // 0x10e8d58: d0 = 0.000000
    //     0x10e8d58: eor             v0.16b, v0.16b, v0.16b
    // 0x10e8d5c: d1 = 0.000000
    //     0x10e8d5c: eor             v1.16b, v1.16b, v1.16b
    // 0x10e8d60: d2 = 1.000000
    //     0x10e8d60: fmov            d2, #1.00000000
    // 0x10e8d64: d3 = 0.000000
    //     0x10e8d64: eor             v3.16b, v3.16b, v3.16b
    // 0x10e8d68: r0 = Vector4()
    //     0x10e8d68: bl              #0x10e8f04  ; [package:vector_math/vector_math_64.dart] Vector4::Vector4
    // 0x10e8d6c: ldur            x1, [fp, #-8]
    // 0x10e8d70: stur            x0, [fp, #-8]
    // 0x10e8d74: r0 = clone()
    //     0x10e8d74: bl              #0x832afc  ; [package:vector_math/vector_math_64.dart] Matrix4::clone
    // 0x10e8d78: mov             x3, x0
    // 0x10e8d7c: ldur            x2, [fp, #-8]
    // 0x10e8d80: stur            x3, [fp, #-0x10]
    // 0x10e8d84: LoadField: r4 = r2->field_7
    //     0x10e8d84: ldur            w4, [x2, #7]
    // 0x10e8d88: DecompressPointer r4
    //     0x10e8d88: add             x4, x4, HEAP, lsl #32
    // 0x10e8d8c: LoadField: r5 = r3->field_7
    //     0x10e8d8c: ldur            w5, [x3, #7]
    // 0x10e8d90: DecompressPointer r5
    //     0x10e8d90: add             x5, x5, HEAP, lsl #32
    // 0x10e8d94: LoadField: r0 = r4->field_13
    //     0x10e8d94: ldur            w0, [x4, #0x13]
    // 0x10e8d98: r1 = LoadInt32Instr(r0)
    //     0x10e8d98: sbfx            x1, x0, #1, #0x1f
    // 0x10e8d9c: mov             x0, x1
    // 0x10e8da0: r1 = 3
    //     0x10e8da0: mov             x1, #3
    // 0x10e8da4: cmp             x1, x0
    // 0x10e8da8: b.hs            #0x10e8e04
    // 0x10e8dac: LoadField: d0 = r4->field_2f
    //     0x10e8dac: ldur            d0, [x4, #0x2f]
    // 0x10e8db0: LoadField: r0 = r5->field_13
    //     0x10e8db0: ldur            w0, [x5, #0x13]
    // 0x10e8db4: r1 = LoadInt32Instr(r0)
    //     0x10e8db4: sbfx            x1, x0, #1, #0x1f
    // 0x10e8db8: mov             x0, x1
    // 0x10e8dbc: r1 = 11
    //     0x10e8dbc: mov             x1, #0xb
    // 0x10e8dc0: cmp             x1, x0
    // 0x10e8dc4: b.hs            #0x10e8e08
    // 0x10e8dc8: StoreField: r5->field_6f = d0
    //     0x10e8dc8: stur            d0, [x5, #0x6f]
    // 0x10e8dcc: LoadField: d0 = r4->field_27
    //     0x10e8dcc: ldur            d0, [x4, #0x27]
    // 0x10e8dd0: StoreField: r5->field_67 = d0
    //     0x10e8dd0: stur            d0, [x5, #0x67]
    // 0x10e8dd4: LoadField: d0 = r4->field_1f
    //     0x10e8dd4: ldur            d0, [x4, #0x1f]
    // 0x10e8dd8: StoreField: r5->field_5f = d0
    //     0x10e8dd8: stur            d0, [x5, #0x5f]
    // 0x10e8ddc: ArrayLoad: d0 = r4[0]  ; List_8
    //     0x10e8ddc: ldur            d0, [x4, #0x17]
    // 0x10e8de0: StoreField: r5->field_57 = d0
    //     0x10e8de0: stur            d0, [x5, #0x57]
    // 0x10e8de4: mov             x1, x3
    // 0x10e8de8: r0 = setRow()
    //     0x10e8de8: bl              #0x10e8e0c  ; [package:vector_math/vector_math_64.dart] Matrix4::setRow
    // 0x10e8dec: ldur            x0, [fp, #-0x10]
    // 0x10e8df0: LeaveFrame
    //     0x10e8df0: mov             SP, fp
    //     0x10e8df4: ldp             fp, lr, [SP], #0x10
    // 0x10e8df8: ret
    //     0x10e8df8: ret             
    // 0x10e8dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8dfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8e00: b               #0x10e8d54
    // 0x10e8e04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10e8e04: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x10e8e08: r0 = RangeErrorSharedWithFPURegs()
    //     0x10e8e08: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  const get _ distance(/* No info */) {
    // ** addr: 0x1106c44, size: 0x8
    // 0x1106c44: LoadField: d0 = r1->field_5f
    //     0x1106c44: ldur            d0, [x1, #0x5f]
    // 0x1106c48: ret
    //     0x1106c48: ret             
  }
  const get _ pressure(/* No info */) {
    // ** addr: 0x112e2f4, size: 0x8
    // 0x112e2f4: LoadField: d0 = r1->field_47
    //     0x112e2f4: ldur            d0, [x1, #0x47]
    // 0x112e2f8: ret
    //     0x112e2f8: ret             
  }
  const get _ tilt(/* No info */) {
    // ** addr: 0x115a894, size: 0x8
    // 0x115a894: LoadField: d0 = r1->field_9f
    //     0x115a894: ldur            d0, [x1, #0x9f]
    // 0x115a898: ret
    //     0x115a898: ret             
  }
  const get _ radiusMax(/* No info */) {
    // ** addr: 0x1184074, size: 0x8
    // 0x1184074: LoadField: d0 = r1->field_8f
    //     0x1184074: ldur            d0, [x1, #0x8f]
    // 0x1184078: ret
    //     0x1184078: ret             
  }
}

// class id: 5249, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerCancelEvent extends PointerEvent {
}

// class id: 5250, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerPanZoomEndEvent extends PointerEvent {
}

// class id: 5251, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerPanZoomUpdateEvent extends PointerEvent {
}

// class id: 5252, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerPanZoomStartEvent extends PointerEvent {
}

// class id: 5253, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerScaleEvent extends PointerEvent {
}

// class id: 5254, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerScrollInertiaCancelEvent extends PointerEvent {
}

// class id: 5255, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerScrollEvent extends PointerEvent {
}

// class id: 5257, size: 0xbc, field offset: 0xbc
//   const constructor, 
abstract class PointerSignalEvent extends _MixinApplication481&PointerEvent&_RespondablePointerEvent {
}

// class id: 5260, size: 0xc4, field offset: 0xbc
//   const constructor, 
class PointerScaleEvent extends _MixinApplication488&PointerSignalEvent&_PointerEventDescription&_CopyPointerScaleEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xadb998, size: 0x80
    // 0xadb998: EnterFrame
    //     0xadb998: stp             fp, lr, [SP, #-0x10]!
    //     0xadb99c: mov             fp, SP
    // 0xadb9a0: AllocStack(0x18)
    //     0xadb9a0: sub             SP, SP, #0x18
    // 0xadb9a4: SetupParameters(PointerScaleEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xadb9a4: mov             x0, x1
    //     0xadb9a8: stur            x1, [fp, #-8]
    //     0xadb9ac: stur            x2, [fp, #-0x10]
    // 0xadb9b0: CheckStackOverflow
    //     0xadb9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadb9b4: cmp             SP, x16
    //     0xadb9b8: b.ls            #0xadba10
    // 0xadb9bc: cmp             w2, NULL
    // 0xadb9c0: b.ne            #0xadb9d0
    // 0xadb9c4: LeaveFrame
    //     0xadb9c4: mov             SP, fp
    //     0xadb9c8: ldp             fp, lr, [SP], #0x10
    // 0xadb9cc: ret
    //     0xadb9cc: ret             
    // 0xadb9d0: r0 = _TransformedPointerScaleEvent()
    //     0xadb9d0: bl              #0xadba18  ; Allocate_TransformedPointerScaleEventStub -> _TransformedPointerScaleEvent (size=0x18)
    // 0xadb9d4: mov             x2, x0
    // 0xadb9d8: ldur            x0, [fp, #-8]
    // 0xadb9dc: stur            x2, [fp, #-0x18]
    // 0xadb9e0: StoreField: r2->field_f = r0
    //     0xadb9e0: stur            w0, [x2, #0xf]
    // 0xadb9e4: ldur            x0, [fp, #-0x10]
    // 0xadb9e8: StoreField: r2->field_13 = r0
    //     0xadb9e8: stur            w0, [x2, #0x13]
    // 0xadb9ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xadb9f0: StoreField: r2->field_7 = r0
    //     0xadb9f0: stur            w0, [x2, #7]
    // 0xadb9f4: StoreField: r2->field_b = r0
    //     0xadb9f4: stur            w0, [x2, #0xb]
    // 0xadb9f8: mov             x1, x2
    // 0xadb9fc: r0 = Shader._()
    //     0xadb9fc: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xadba00: ldur            x0, [fp, #-0x18]
    // 0xadba04: LeaveFrame
    //     0xadba04: mov             SP, fp
    //     0xadba08: ldp             fp, lr, [SP], #0x10
    // 0xadba0c: ret
    //     0xadba0c: ret             
    // 0xadba10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadba10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadba14: b               #0xadb9bc
  }
  const get _ scale(/* No info */) {
    // ** addr: 0x125c260, size: 0x8
    // 0x125c260: LoadField: d0 = r1->field_bb
    //     0x125c260: ldur            d0, [x1, #0xbb]
    // 0x125c264: ret
    //     0x125c264: ret             
  }
}

// class id: 5262, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerScrollInertiaCancelEvent extends _MixinApplication485&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollInertiaCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xadb6f0, size: 0x80
    // 0xadb6f0: EnterFrame
    //     0xadb6f0: stp             fp, lr, [SP, #-0x10]!
    //     0xadb6f4: mov             fp, SP
    // 0xadb6f8: AllocStack(0x18)
    //     0xadb6f8: sub             SP, SP, #0x18
    // 0xadb6fc: SetupParameters(PointerScrollInertiaCancelEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xadb6fc: mov             x0, x1
    //     0xadb700: stur            x1, [fp, #-8]
    //     0xadb704: stur            x2, [fp, #-0x10]
    // 0xadb708: CheckStackOverflow
    //     0xadb708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xadb70c: cmp             SP, x16
    //     0xadb710: b.ls            #0xadb768
    // 0xadb714: cmp             w2, NULL
    // 0xadb718: b.ne            #0xadb728
    // 0xadb71c: LeaveFrame
    //     0xadb71c: mov             SP, fp
    //     0xadb720: ldp             fp, lr, [SP], #0x10
    // 0xadb724: ret
    //     0xadb724: ret             
    // 0xadb728: r0 = _TransformedPointerScrollInertiaCancelEvent()
    //     0xadb728: bl              #0xadb770  ; Allocate_TransformedPointerScrollInertiaCancelEventStub -> _TransformedPointerScrollInertiaCancelEvent (size=0x18)
    // 0xadb72c: mov             x2, x0
    // 0xadb730: ldur            x0, [fp, #-8]
    // 0xadb734: stur            x2, [fp, #-0x18]
    // 0xadb738: StoreField: r2->field_f = r0
    //     0xadb738: stur            w0, [x2, #0xf]
    // 0xadb73c: ldur            x0, [fp, #-0x10]
    // 0xadb740: StoreField: r2->field_13 = r0
    //     0xadb740: stur            w0, [x2, #0x13]
    // 0xadb744: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xadb748: StoreField: r2->field_7 = r0
    //     0xadb748: stur            w0, [x2, #7]
    // 0xadb74c: StoreField: r2->field_b = r0
    //     0xadb74c: stur            w0, [x2, #0xb]
    // 0xadb750: mov             x1, x2
    // 0xadb754: r0 = Shader._()
    //     0xadb754: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xadb758: ldur            x0, [fp, #-0x18]
    // 0xadb75c: LeaveFrame
    //     0xadb75c: mov             SP, fp
    //     0xadb760: ldp             fp, lr, [SP], #0x10
    // 0xadb764: ret
    //     0xadb764: ret             
    // 0xadb768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadb768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadb76c: b               #0xadb714
  }
}

// class id: 5264, size: 0xc4, field offset: 0xbc
//   const constructor, 
class PointerScrollEvent extends _MixinApplication483&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xadb470, size: 0x58
    // 0xadb470: EnterFrame
    //     0xadb470: stp             fp, lr, [SP, #-0x10]!
    //     0xadb474: mov             fp, SP
    // 0xadb478: AllocStack(0x10)
    //     0xadb478: sub             SP, SP, #0x10
    // 0xadb47c: SetupParameters(PointerScrollEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xadb47c: mov             x0, x1
    //     0xadb480: stur            x1, [fp, #-8]
    //     0xadb484: stur            x2, [fp, #-0x10]
    // 0xadb488: cmp             w2, NULL
    // 0xadb48c: b.ne            #0xadb49c
    // 0xadb490: LeaveFrame
    //     0xadb490: mov             SP, fp
    //     0xadb494: ldp             fp, lr, [SP], #0x10
    // 0xadb498: ret
    //     0xadb498: ret             
    // 0xadb49c: r0 = _TransformedPointerScrollEvent()
    //     0xadb49c: bl              #0xadb4c8  ; Allocate_TransformedPointerScrollEventStub -> _TransformedPointerScrollEvent (size=0x18)
    // 0xadb4a0: ldur            x1, [fp, #-8]
    // 0xadb4a4: StoreField: r0->field_f = r1
    //     0xadb4a4: stur            w1, [x0, #0xf]
    // 0xadb4a8: ldur            x1, [fp, #-0x10]
    // 0xadb4ac: StoreField: r0->field_13 = r1
    //     0xadb4ac: stur            w1, [x0, #0x13]
    // 0xadb4b0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xadb4b4: StoreField: r0->field_7 = r1
    //     0xadb4b4: stur            w1, [x0, #7]
    // 0xadb4b8: StoreField: r0->field_b = r1
    //     0xadb4b8: stur            w1, [x0, #0xb]
    // 0xadb4bc: LeaveFrame
    //     0xadb4bc: mov             SP, fp
    //     0xadb4c0: ldp             fp, lr, [SP], #0x10
    // 0xadb4c4: ret
    //     0xadb4c4: ret             
  }
  _ respond(/* No info */) {
    // ** addr: 0x11e0f10, size: 0x24
    // 0x11e0f10: LoadField: r2 = r1->field_bf
    //     0x11e0f10: ldur            w2, [x1, #0xbf]
    // 0x11e0f14: DecompressPointer r2
    //     0x11e0f14: add             x2, x2, HEAP, lsl #32
    // 0x11e0f18: cmp             w2, NULL
    // 0x11e0f1c: b.eq            #0x11e0f28
    // 0x11e0f20: r0 = Null
    //     0x11e0f20: mov             x0, NULL
    // 0x11e0f24: ret
    //     0x11e0f24: ret             
    // 0x11e0f28: EnterFrame
    //     0x11e0f28: stp             fp, lr, [SP, #-0x10]!
    //     0x11e0f2c: mov             fp, SP
    // 0x11e0f30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x11e0f30: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5265, size: 0xbc, field offset: 0xbc
abstract class _RespondablePointerEvent extends PointerEvent {
}

// class id: 5266, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerUpEvent extends PointerEvent {
}

// class id: 5267, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerMoveEvent extends PointerEvent {
}

// class id: 5268, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerDownEvent extends PointerEvent {
}

// class id: 5269, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerExitEvent extends PointerEvent {
}

// class id: 5270, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerEnterEvent extends PointerEvent {
}

// class id: 5271, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerHoverEvent extends PointerEvent {
}

// class id: 5272, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerRemovedEvent extends PointerEvent {
}

// class id: 5273, size: 0xbc, field offset: 0xbc
abstract class _CopyPointerAddedEvent extends PointerEvent {
}

// class id: 5276, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerCancelEvent extends _MixinApplication497&PointerEvent&_PointerEventDescription&_CopyPointerCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xada534, size: 0x58
    // 0xada534: EnterFrame
    //     0xada534: stp             fp, lr, [SP, #-0x10]!
    //     0xada538: mov             fp, SP
    // 0xada53c: AllocStack(0x10)
    //     0xada53c: sub             SP, SP, #0x10
    // 0xada540: SetupParameters(PointerCancelEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xada540: mov             x0, x1
    //     0xada544: stur            x1, [fp, #-8]
    //     0xada548: stur            x2, [fp, #-0x10]
    // 0xada54c: cmp             w2, NULL
    // 0xada550: b.ne            #0xada560
    // 0xada554: LeaveFrame
    //     0xada554: mov             SP, fp
    //     0xada558: ldp             fp, lr, [SP], #0x10
    // 0xada55c: ret
    //     0xada55c: ret             
    // 0xada560: r0 = _TransformedPointerCancelEvent()
    //     0xada560: bl              #0xada58c  ; Allocate_TransformedPointerCancelEventStub -> _TransformedPointerCancelEvent (size=0x18)
    // 0xada564: ldur            x1, [fp, #-8]
    // 0xada568: StoreField: r0->field_f = r1
    //     0xada568: stur            w1, [x0, #0xf]
    // 0xada56c: ldur            x1, [fp, #-0x10]
    // 0xada570: StoreField: r0->field_13 = r1
    //     0xada570: stur            w1, [x0, #0x13]
    // 0xada574: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xada578: StoreField: r0->field_7 = r1
    //     0xada578: stur            w1, [x0, #7]
    // 0xada57c: StoreField: r0->field_b = r1
    //     0xada57c: stur            w1, [x0, #0xb]
    // 0xada580: LeaveFrame
    //     0xada580: mov             SP, fp
    //     0xada584: ldp             fp, lr, [SP], #0x10
    // 0xada588: ret
    //     0xada588: ret             
  }
}

// class id: 5278, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerPanZoomEndEvent extends _MixinApplication495&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomEndEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xada2b4, size: 0x58
    // 0xada2b4: EnterFrame
    //     0xada2b4: stp             fp, lr, [SP, #-0x10]!
    //     0xada2b8: mov             fp, SP
    // 0xada2bc: AllocStack(0x10)
    //     0xada2bc: sub             SP, SP, #0x10
    // 0xada2c0: SetupParameters(PointerPanZoomEndEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xada2c0: mov             x0, x1
    //     0xada2c4: stur            x1, [fp, #-8]
    //     0xada2c8: stur            x2, [fp, #-0x10]
    // 0xada2cc: cmp             w2, NULL
    // 0xada2d0: b.ne            #0xada2e0
    // 0xada2d4: LeaveFrame
    //     0xada2d4: mov             SP, fp
    //     0xada2d8: ldp             fp, lr, [SP], #0x10
    // 0xada2dc: ret
    //     0xada2dc: ret             
    // 0xada2e0: r0 = _TransformedPointerPanZoomEndEvent()
    //     0xada2e0: bl              #0xada30c  ; Allocate_TransformedPointerPanZoomEndEventStub -> _TransformedPointerPanZoomEndEvent (size=0x18)
    // 0xada2e4: ldur            x1, [fp, #-8]
    // 0xada2e8: StoreField: r0->field_f = r1
    //     0xada2e8: stur            w1, [x0, #0xf]
    // 0xada2ec: ldur            x1, [fp, #-0x10]
    // 0xada2f0: StoreField: r0->field_13 = r1
    //     0xada2f0: stur            w1, [x0, #0x13]
    // 0xada2f4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xada2f8: StoreField: r0->field_7 = r1
    //     0xada2f8: stur            w1, [x0, #7]
    // 0xada2fc: StoreField: r0->field_b = r1
    //     0xada2fc: stur            w1, [x0, #0xb]
    // 0xada300: LeaveFrame
    //     0xada300: mov             SP, fp
    //     0xada304: ldp             fp, lr, [SP], #0x10
    // 0xada308: ret
    //     0xada308: ret             
  }
}

// class id: 5280, size: 0xd4, field offset: 0xbc
//   const constructor, 
class PointerPanZoomUpdateEvent extends _MixinApplication493&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomUpdateEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xada02c, size: 0x60
    // 0xada02c: EnterFrame
    //     0xada02c: stp             fp, lr, [SP, #-0x10]!
    //     0xada030: mov             fp, SP
    // 0xada034: AllocStack(0x10)
    //     0xada034: sub             SP, SP, #0x10
    // 0xada038: SetupParameters(PointerPanZoomUpdateEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xada038: mov             x0, x1
    //     0xada03c: stur            x1, [fp, #-8]
    //     0xada040: stur            x2, [fp, #-0x10]
    // 0xada044: cmp             w2, NULL
    // 0xada048: b.ne            #0xada058
    // 0xada04c: LeaveFrame
    //     0xada04c: mov             SP, fp
    //     0xada050: ldp             fp, lr, [SP], #0x10
    // 0xada054: ret
    //     0xada054: ret             
    // 0xada058: r0 = _TransformedPointerPanZoomUpdateEvent()
    //     0xada058: bl              #0xada08c  ; Allocate_TransformedPointerPanZoomUpdateEventStub -> _TransformedPointerPanZoomUpdateEvent (size=0x20)
    // 0xada05c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xada060: StoreField: r0->field_f = r1
    //     0xada060: stur            w1, [x0, #0xf]
    // 0xada064: StoreField: r0->field_13 = r1
    //     0xada064: stur            w1, [x0, #0x13]
    // 0xada068: ldur            x2, [fp, #-8]
    // 0xada06c: ArrayStore: r0[0] = r2  ; List_4
    //     0xada06c: stur            w2, [x0, #0x17]
    // 0xada070: ldur            x2, [fp, #-0x10]
    // 0xada074: StoreField: r0->field_1b = r2
    //     0xada074: stur            w2, [x0, #0x1b]
    // 0xada078: StoreField: r0->field_7 = r1
    //     0xada078: stur            w1, [x0, #7]
    // 0xada07c: StoreField: r0->field_b = r1
    //     0xada07c: stur            w1, [x0, #0xb]
    // 0xada080: LeaveFrame
    //     0xada080: mov             SP, fp
    //     0xada084: ldp             fp, lr, [SP], #0x10
    // 0xada088: ret
    //     0xada088: ret             
  }
  const get _ rotation(/* No info */) {
    // ** addr: 0x125b5e0, size: 0x8
    // 0x125b5e0: LoadField: d0 = r1->field_cb
    //     0x125b5e0: ldur            d0, [x1, #0xcb]
    // 0x125b5e4: ret
    //     0x125b5e4: ret             
  }
  const get _ scale(/* No info */) {
    // ** addr: 0x125bdcc, size: 0x8
    // 0x125bdcc: LoadField: d0 = r1->field_c3
    //     0x125bdcc: ldur            d0, [x1, #0xc3]
    // 0x125bdd0: ret
    //     0x125bdd0: ret             
  }
  const get _ panDelta(/* No info */) {
    // ** addr: 0x125bf4c, size: 0xc
    // 0x125bf4c: LoadField: r0 = r1->field_bf
    //     0x125bf4c: ldur            w0, [x1, #0xbf]
    // 0x125bf50: DecompressPointer r0
    //     0x125bf50: add             x0, x0, HEAP, lsl #32
    // 0x125bf54: ret
    //     0x125bf54: ret             
  }
}

// class id: 5282, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerPanZoomStartEvent extends _MixinApplication491&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomStartEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad9dac, size: 0x58
    // 0xad9dac: EnterFrame
    //     0xad9dac: stp             fp, lr, [SP, #-0x10]!
    //     0xad9db0: mov             fp, SP
    // 0xad9db4: AllocStack(0x10)
    //     0xad9db4: sub             SP, SP, #0x10
    // 0xad9db8: SetupParameters(PointerPanZoomStartEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9db8: mov             x0, x1
    //     0xad9dbc: stur            x1, [fp, #-8]
    //     0xad9dc0: stur            x2, [fp, #-0x10]
    // 0xad9dc4: cmp             w2, NULL
    // 0xad9dc8: b.ne            #0xad9dd8
    // 0xad9dcc: LeaveFrame
    //     0xad9dcc: mov             SP, fp
    //     0xad9dd0: ldp             fp, lr, [SP], #0x10
    // 0xad9dd4: ret
    //     0xad9dd4: ret             
    // 0xad9dd8: r0 = _TransformedPointerPanZoomStartEvent()
    //     0xad9dd8: bl              #0xad9e04  ; Allocate_TransformedPointerPanZoomStartEventStub -> _TransformedPointerPanZoomStartEvent (size=0x18)
    // 0xad9ddc: ldur            x1, [fp, #-8]
    // 0xad9de0: StoreField: r0->field_f = r1
    //     0xad9de0: stur            w1, [x0, #0xf]
    // 0xad9de4: ldur            x1, [fp, #-0x10]
    // 0xad9de8: StoreField: r0->field_13 = r1
    //     0xad9de8: stur            w1, [x0, #0x13]
    // 0xad9dec: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad9df0: StoreField: r0->field_7 = r1
    //     0xad9df0: stur            w1, [x0, #7]
    // 0xad9df4: StoreField: r0->field_b = r1
    //     0xad9df4: stur            w1, [x0, #0xb]
    // 0xad9df8: LeaveFrame
    //     0xad9df8: mov             SP, fp
    //     0xad9dfc: ldp             fp, lr, [SP], #0x10
    // 0xad9e00: ret
    //     0xad9e00: ret             
  }
}

// class id: 5284, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerUpEvent extends _MixinApplication479&PointerEvent&_PointerEventDescription&_CopyPointerUpEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad9b2c, size: 0x58
    // 0xad9b2c: EnterFrame
    //     0xad9b2c: stp             fp, lr, [SP, #-0x10]!
    //     0xad9b30: mov             fp, SP
    // 0xad9b34: AllocStack(0x10)
    //     0xad9b34: sub             SP, SP, #0x10
    // 0xad9b38: SetupParameters(PointerUpEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9b38: mov             x0, x1
    //     0xad9b3c: stur            x1, [fp, #-8]
    //     0xad9b40: stur            x2, [fp, #-0x10]
    // 0xad9b44: cmp             w2, NULL
    // 0xad9b48: b.ne            #0xad9b58
    // 0xad9b4c: LeaveFrame
    //     0xad9b4c: mov             SP, fp
    //     0xad9b50: ldp             fp, lr, [SP], #0x10
    // 0xad9b54: ret
    //     0xad9b54: ret             
    // 0xad9b58: r0 = _TransformedPointerUpEvent()
    //     0xad9b58: bl              #0xad9b84  ; Allocate_TransformedPointerUpEventStub -> _TransformedPointerUpEvent (size=0x18)
    // 0xad9b5c: ldur            x1, [fp, #-8]
    // 0xad9b60: StoreField: r0->field_f = r1
    //     0xad9b60: stur            w1, [x0, #0xf]
    // 0xad9b64: ldur            x1, [fp, #-0x10]
    // 0xad9b68: StoreField: r0->field_13 = r1
    //     0xad9b68: stur            w1, [x0, #0x13]
    // 0xad9b6c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad9b70: StoreField: r0->field_7 = r1
    //     0xad9b70: stur            w1, [x0, #7]
    // 0xad9b74: StoreField: r0->field_b = r1
    //     0xad9b74: stur            w1, [x0, #0xb]
    // 0xad9b78: LeaveFrame
    //     0xad9b78: mov             SP, fp
    //     0xad9b7c: ldp             fp, lr, [SP], #0x10
    // 0xad9b80: ret
    //     0xad9b80: ret             
  }
}

// class id: 5286, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerMoveEvent extends _MixinApplication477&PointerEvent&_PointerEventDescription&_CopyPointerMoveEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad9658, size: 0x58
    // 0xad9658: EnterFrame
    //     0xad9658: stp             fp, lr, [SP, #-0x10]!
    //     0xad965c: mov             fp, SP
    // 0xad9660: AllocStack(0x10)
    //     0xad9660: sub             SP, SP, #0x10
    // 0xad9664: SetupParameters(PointerMoveEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9664: mov             x0, x1
    //     0xad9668: stur            x1, [fp, #-8]
    //     0xad966c: stur            x2, [fp, #-0x10]
    // 0xad9670: cmp             w2, NULL
    // 0xad9674: b.ne            #0xad9684
    // 0xad9678: LeaveFrame
    //     0xad9678: mov             SP, fp
    //     0xad967c: ldp             fp, lr, [SP], #0x10
    // 0xad9680: ret
    //     0xad9680: ret             
    // 0xad9684: r0 = _TransformedPointerMoveEvent()
    //     0xad9684: bl              #0xad96b0  ; Allocate_TransformedPointerMoveEventStub -> _TransformedPointerMoveEvent (size=0x18)
    // 0xad9688: ldur            x1, [fp, #-8]
    // 0xad968c: StoreField: r0->field_f = r1
    //     0xad968c: stur            w1, [x0, #0xf]
    // 0xad9690: ldur            x1, [fp, #-0x10]
    // 0xad9694: StoreField: r0->field_13 = r1
    //     0xad9694: stur            w1, [x0, #0x13]
    // 0xad9698: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad969c: StoreField: r0->field_7 = r1
    //     0xad969c: stur            w1, [x0, #7]
    // 0xad96a0: StoreField: r0->field_b = r1
    //     0xad96a0: stur            w1, [x0, #0xb]
    // 0xad96a4: LeaveFrame
    //     0xad96a4: mov             SP, fp
    //     0xad96a8: ldp             fp, lr, [SP], #0x10
    // 0xad96ac: ret
    //     0xad96ac: ret             
  }
}

// class id: 5288, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerDownEvent extends _MixinApplication475&PointerEvent&_PointerEventDescription&_CopyPointerDownEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad95f4, size: 0x58
    // 0xad95f4: EnterFrame
    //     0xad95f4: stp             fp, lr, [SP, #-0x10]!
    //     0xad95f8: mov             fp, SP
    // 0xad95fc: AllocStack(0x10)
    //     0xad95fc: sub             SP, SP, #0x10
    // 0xad9600: SetupParameters(PointerDownEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9600: mov             x0, x1
    //     0xad9604: stur            x1, [fp, #-8]
    //     0xad9608: stur            x2, [fp, #-0x10]
    // 0xad960c: cmp             w2, NULL
    // 0xad9610: b.ne            #0xad9620
    // 0xad9614: LeaveFrame
    //     0xad9614: mov             SP, fp
    //     0xad9618: ldp             fp, lr, [SP], #0x10
    // 0xad961c: ret
    //     0xad961c: ret             
    // 0xad9620: r0 = _TransformedPointerDownEvent()
    //     0xad9620: bl              #0xad964c  ; Allocate_TransformedPointerDownEventStub -> _TransformedPointerDownEvent (size=0x18)
    // 0xad9624: ldur            x1, [fp, #-8]
    // 0xad9628: StoreField: r0->field_f = r1
    //     0xad9628: stur            w1, [x0, #0xf]
    // 0xad962c: ldur            x1, [fp, #-0x10]
    // 0xad9630: StoreField: r0->field_13 = r1
    //     0xad9630: stur            w1, [x0, #0x13]
    // 0xad9634: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad9638: StoreField: r0->field_7 = r1
    //     0xad9638: stur            w1, [x0, #7]
    // 0xad963c: StoreField: r0->field_b = r1
    //     0xad963c: stur            w1, [x0, #0xb]
    // 0xad9640: LeaveFrame
    //     0xad9640: mov             SP, fp
    //     0xad9644: ldp             fp, lr, [SP], #0x10
    // 0xad9648: ret
    //     0xad9648: ret             
  }
}

// class id: 5290, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerExitEvent extends _MixinApplication473&PointerEvent&_PointerEventDescription&_CopyPointerExitEvent {

  factory _ PointerExitEvent.fromMouseEvent(/* No info */) {
    // ** addr: 0x835d28, size: 0x4a0
    // 0x835d28: EnterFrame
    //     0x835d28: stp             fp, lr, [SP, #-0x10]!
    //     0x835d2c: mov             fp, SP
    // 0x835d30: AllocStack(0xc0)
    //     0x835d30: sub             SP, SP, #0xc0
    // 0x835d34: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x835d34: stur            x2, [fp, #-8]
    // 0x835d38: CheckStackOverflow
    //     0x835d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x835d3c: cmp             SP, x16
    //     0x835d40: b.ls            #0x8361c0
    // 0x835d44: r0 = LoadClassIdInstr(r2)
    //     0x835d44: ldur            x0, [x2, #-1]
    //     0x835d48: ubfx            x0, x0, #0xc, #0x14
    // 0x835d4c: mov             x1, x2
    // 0x835d50: r0 = GDT[cid_x0 + 0x149dc]()
    //     0x835d50: mov             x17, #0x49dc
    //     0x835d54: movk            x17, #1, lsl #16
    //     0x835d58: add             lr, x0, x17
    //     0x835d5c: ldr             lr, [x21, lr, lsl #3]
    //     0x835d60: blr             lr
    // 0x835d64: mov             x3, x0
    // 0x835d68: ldur            x2, [fp, #-8]
    // 0x835d6c: stur            x3, [fp, #-0x10]
    // 0x835d70: r0 = LoadClassIdInstr(r2)
    //     0x835d70: ldur            x0, [x2, #-1]
    //     0x835d74: ubfx            x0, x0, #0xc, #0x14
    // 0x835d78: mov             x1, x2
    // 0x835d7c: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0x835d7c: mov             x17, #0x5eb5
    //     0x835d80: movk            x17, #1, lsl #16
    //     0x835d84: add             lr, x0, x17
    //     0x835d88: ldr             lr, [x21, lr, lsl #3]
    //     0x835d8c: blr             lr
    // 0x835d90: mov             x3, x0
    // 0x835d94: ldur            x2, [fp, #-8]
    // 0x835d98: stur            x3, [fp, #-0x18]
    // 0x835d9c: r0 = LoadClassIdInstr(r2)
    //     0x835d9c: ldur            x0, [x2, #-1]
    //     0x835da0: ubfx            x0, x0, #0xc, #0x14
    // 0x835da4: mov             x1, x2
    // 0x835da8: r0 = GDT[cid_x0 + -0x1]()
    //     0x835da8: sub             lr, x0, #1
    //     0x835dac: ldr             lr, [x21, lr, lsl #3]
    //     0x835db0: blr             lr
    // 0x835db4: mov             x3, x0
    // 0x835db8: ldur            x2, [fp, #-8]
    // 0x835dbc: stur            x3, [fp, #-0x20]
    // 0x835dc0: r0 = LoadClassIdInstr(r2)
    //     0x835dc0: ldur            x0, [x2, #-1]
    //     0x835dc4: ubfx            x0, x0, #0xc, #0x14
    // 0x835dc8: mov             x1, x2
    // 0x835dcc: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x835dcc: mov             x17, #0x5e74
    //     0x835dd0: movk            x17, #1, lsl #16
    //     0x835dd4: add             lr, x0, x17
    //     0x835dd8: ldr             lr, [x21, lr, lsl #3]
    //     0x835ddc: blr             lr
    // 0x835de0: mov             x3, x0
    // 0x835de4: ldur            x2, [fp, #-8]
    // 0x835de8: stur            x3, [fp, #-0x28]
    // 0x835dec: r0 = LoadClassIdInstr(r2)
    //     0x835dec: ldur            x0, [x2, #-1]
    //     0x835df0: ubfx            x0, x0, #0xc, #0x14
    // 0x835df4: mov             x1, x2
    // 0x835df8: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x835df8: mov             x17, #0x5a90
    //     0x835dfc: movk            x17, #1, lsl #16
    //     0x835e00: add             lr, x0, x17
    //     0x835e04: ldr             lr, [x21, lr, lsl #3]
    //     0x835e08: blr             lr
    // 0x835e0c: mov             x3, x0
    // 0x835e10: ldur            x2, [fp, #-8]
    // 0x835e14: stur            x3, [fp, #-0x30]
    // 0x835e18: r0 = LoadClassIdInstr(r2)
    //     0x835e18: ldur            x0, [x2, #-1]
    //     0x835e1c: ubfx            x0, x0, #0xc, #0x14
    // 0x835e20: mov             x1, x2
    // 0x835e24: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x835e24: mov             x17, #0x3f27
    //     0x835e28: movk            x17, #1, lsl #16
    //     0x835e2c: add             lr, x0, x17
    //     0x835e30: ldr             lr, [x21, lr, lsl #3]
    //     0x835e34: blr             lr
    // 0x835e38: mov             x3, x0
    // 0x835e3c: ldur            x2, [fp, #-8]
    // 0x835e40: stur            x3, [fp, #-0x38]
    // 0x835e44: r0 = LoadClassIdInstr(r2)
    //     0x835e44: ldur            x0, [x2, #-1]
    //     0x835e48: ubfx            x0, x0, #0xc, #0x14
    // 0x835e4c: mov             x1, x2
    // 0x835e50: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0x835e50: mov             x17, #0x5a8f
    //     0x835e54: movk            x17, #1, lsl #16
    //     0x835e58: add             lr, x0, x17
    //     0x835e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x835e60: blr             lr
    // 0x835e64: mov             x3, x0
    // 0x835e68: ldur            x2, [fp, #-8]
    // 0x835e6c: stur            x3, [fp, #-0x40]
    // 0x835e70: r0 = LoadClassIdInstr(r2)
    //     0x835e70: ldur            x0, [x2, #-1]
    //     0x835e74: ubfx            x0, x0, #0xc, #0x14
    // 0x835e78: mov             x1, x2
    // 0x835e7c: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x835e7c: mov             x17, #0x6f9c
    //     0x835e80: movk            x17, #1, lsl #16
    //     0x835e84: add             lr, x0, x17
    //     0x835e88: ldr             lr, [x21, lr, lsl #3]
    //     0x835e8c: blr             lr
    // 0x835e90: mov             x3, x0
    // 0x835e94: ldur            x2, [fp, #-8]
    // 0x835e98: stur            x3, [fp, #-0x48]
    // 0x835e9c: r0 = LoadClassIdInstr(r2)
    //     0x835e9c: ldur            x0, [x2, #-1]
    //     0x835ea0: ubfx            x0, x0, #0xc, #0x14
    // 0x835ea4: mov             x1, x2
    // 0x835ea8: r0 = GDT[cid_x0 + 0xb2a3]()
    //     0x835ea8: mov             x17, #0xb2a3
    //     0x835eac: add             lr, x0, x17
    //     0x835eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x835eb4: blr             lr
    // 0x835eb8: mov             x3, x0
    // 0x835ebc: ldur            x2, [fp, #-8]
    // 0x835ec0: stur            x3, [fp, #-0x50]
    // 0x835ec4: r0 = LoadClassIdInstr(r2)
    //     0x835ec4: ldur            x0, [x2, #-1]
    //     0x835ec8: ubfx            x0, x0, #0xc, #0x14
    // 0x835ecc: mov             x1, x2
    // 0x835ed0: r0 = GDT[cid_x0 + 0x176b6]()
    //     0x835ed0: mov             x17, #0x76b6
    //     0x835ed4: movk            x17, #1, lsl #16
    //     0x835ed8: add             lr, x0, x17
    //     0x835edc: ldr             lr, [x21, lr, lsl #3]
    //     0x835ee0: blr             lr
    // 0x835ee4: ldur            x2, [fp, #-8]
    // 0x835ee8: stur            d0, [fp, #-0x70]
    // 0x835eec: r0 = LoadClassIdInstr(r2)
    //     0x835eec: ldur            x0, [x2, #-1]
    //     0x835ef0: ubfx            x0, x0, #0xc, #0x14
    // 0x835ef4: mov             x1, x2
    // 0x835ef8: r0 = GDT[cid_x0 + 0x139f8]()
    //     0x835ef8: mov             x17, #0x39f8
    //     0x835efc: movk            x17, #1, lsl #16
    //     0x835f00: add             lr, x0, x17
    //     0x835f04: ldr             lr, [x21, lr, lsl #3]
    //     0x835f08: blr             lr
    // 0x835f0c: ldur            x2, [fp, #-8]
    // 0x835f10: stur            d0, [fp, #-0x78]
    // 0x835f14: r0 = LoadClassIdInstr(r2)
    //     0x835f14: ldur            x0, [x2, #-1]
    //     0x835f18: ubfx            x0, x0, #0xc, #0x14
    // 0x835f1c: mov             x1, x2
    // 0x835f20: r0 = GDT[cid_x0 + 0x91c0]()
    //     0x835f20: mov             x17, #0x91c0
    //     0x835f24: add             lr, x0, x17
    //     0x835f28: ldr             lr, [x21, lr, lsl #3]
    //     0x835f2c: blr             lr
    // 0x835f30: ldur            x2, [fp, #-8]
    // 0x835f34: stur            d0, [fp, #-0x80]
    // 0x835f38: r0 = LoadClassIdInstr(r2)
    //     0x835f38: ldur            x0, [x2, #-1]
    //     0x835f3c: ubfx            x0, x0, #0xc, #0x14
    // 0x835f40: mov             x1, x2
    // 0x835f44: r0 = GDT[cid_x0 + 0x15fe4]()
    //     0x835f44: mov             x17, #0x5fe4
    //     0x835f48: movk            x17, #1, lsl #16
    //     0x835f4c: add             lr, x0, x17
    //     0x835f50: ldr             lr, [x21, lr, lsl #3]
    //     0x835f54: blr             lr
    // 0x835f58: ldur            x2, [fp, #-8]
    // 0x835f5c: stur            d0, [fp, #-0x88]
    // 0x835f60: r0 = LoadClassIdInstr(r2)
    //     0x835f60: ldur            x0, [x2, #-1]
    //     0x835f64: ubfx            x0, x0, #0xc, #0x14
    // 0x835f68: mov             x1, x2
    // 0x835f6c: r0 = GDT[cid_x0 + 0x175dc]()
    //     0x835f6c: mov             x17, #0x75dc
    //     0x835f70: movk            x17, #1, lsl #16
    //     0x835f74: add             lr, x0, x17
    //     0x835f78: ldr             lr, [x21, lr, lsl #3]
    //     0x835f7c: blr             lr
    // 0x835f80: ldur            x2, [fp, #-8]
    // 0x835f84: stur            d0, [fp, #-0x90]
    // 0x835f88: r0 = LoadClassIdInstr(r2)
    //     0x835f88: ldur            x0, [x2, #-1]
    //     0x835f8c: ubfx            x0, x0, #0xc, #0x14
    // 0x835f90: mov             x1, x2
    // 0x835f94: r0 = GDT[cid_x0 + 0x15e18]()
    //     0x835f94: mov             x17, #0x5e18
    //     0x835f98: movk            x17, #1, lsl #16
    //     0x835f9c: add             lr, x0, x17
    //     0x835fa0: ldr             lr, [x21, lr, lsl #3]
    //     0x835fa4: blr             lr
    // 0x835fa8: ldur            x2, [fp, #-8]
    // 0x835fac: stur            d0, [fp, #-0x98]
    // 0x835fb0: r0 = LoadClassIdInstr(r2)
    //     0x835fb0: ldur            x0, [x2, #-1]
    //     0x835fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x835fb8: mov             x1, x2
    // 0x835fbc: r0 = GDT[cid_x0 + 0x13f28]()
    //     0x835fbc: mov             x17, #0x3f28
    //     0x835fc0: movk            x17, #1, lsl #16
    //     0x835fc4: add             lr, x0, x17
    //     0x835fc8: ldr             lr, [x21, lr, lsl #3]
    //     0x835fcc: blr             lr
    // 0x835fd0: ldur            x2, [fp, #-8]
    // 0x835fd4: stur            d0, [fp, #-0xa0]
    // 0x835fd8: r0 = LoadClassIdInstr(r2)
    //     0x835fd8: ldur            x0, [x2, #-1]
    //     0x835fdc: ubfx            x0, x0, #0xc, #0x14
    // 0x835fe0: mov             x1, x2
    // 0x835fe4: r0 = GDT[cid_x0 + 0x143d8]()
    //     0x835fe4: mov             x17, #0x43d8
    //     0x835fe8: movk            x17, #1, lsl #16
    //     0x835fec: add             lr, x0, x17
    //     0x835ff0: ldr             lr, [x21, lr, lsl #3]
    //     0x835ff4: blr             lr
    // 0x835ff8: ldur            x2, [fp, #-8]
    // 0x835ffc: stur            d0, [fp, #-0xa8]
    // 0x836000: r0 = LoadClassIdInstr(r2)
    //     0x836000: ldur            x0, [x2, #-1]
    //     0x836004: ubfx            x0, x0, #0xc, #0x14
    // 0x836008: mov             x1, x2
    // 0x83600c: r0 = GDT[cid_x0 + 0x2f17]()
    //     0x83600c: mov             x17, #0x2f17
    //     0x836010: add             lr, x0, x17
    //     0x836014: ldr             lr, [x21, lr, lsl #3]
    //     0x836018: blr             lr
    // 0x83601c: ldur            x2, [fp, #-8]
    // 0x836020: stur            d0, [fp, #-0xb0]
    // 0x836024: r0 = LoadClassIdInstr(r2)
    //     0x836024: ldur            x0, [x2, #-1]
    //     0x836028: ubfx            x0, x0, #0xc, #0x14
    // 0x83602c: mov             x1, x2
    // 0x836030: r0 = GDT[cid_x0 + 0x1600b]()
    //     0x836030: mov             x17, #0x600b
    //     0x836034: movk            x17, #1, lsl #16
    //     0x836038: add             lr, x0, x17
    //     0x83603c: ldr             lr, [x21, lr, lsl #3]
    //     0x836040: blr             lr
    // 0x836044: ldur            x2, [fp, #-8]
    // 0x836048: stur            d0, [fp, #-0xb8]
    // 0x83604c: r0 = LoadClassIdInstr(r2)
    //     0x83604c: ldur            x0, [x2, #-1]
    //     0x836050: ubfx            x0, x0, #0xc, #0x14
    // 0x836054: mov             x1, x2
    // 0x836058: r0 = GDT[cid_x0 + 0x4ffa]()
    //     0x836058: mov             x17, #0x4ffa
    //     0x83605c: add             lr, x0, x17
    //     0x836060: ldr             lr, [x21, lr, lsl #3]
    //     0x836064: blr             lr
    // 0x836068: ldur            x2, [fp, #-8]
    // 0x83606c: stur            d0, [fp, #-0xc0]
    // 0x836070: r0 = LoadClassIdInstr(r2)
    //     0x836070: ldur            x0, [x2, #-1]
    //     0x836074: ubfx            x0, x0, #0xc, #0x14
    // 0x836078: mov             x1, x2
    // 0x83607c: r0 = GDT[cid_x0 + 0x176f1]()
    //     0x83607c: mov             x17, #0x76f1
    //     0x836080: movk            x17, #1, lsl #16
    //     0x836084: add             lr, x0, x17
    //     0x836088: ldr             lr, [x21, lr, lsl #3]
    //     0x83608c: blr             lr
    // 0x836090: mov             x3, x0
    // 0x836094: ldur            x2, [fp, #-8]
    // 0x836098: stur            x3, [fp, #-0x58]
    // 0x83609c: r0 = LoadClassIdInstr(r2)
    //     0x83609c: ldur            x0, [x2, #-1]
    //     0x8360a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8360a4: mov             x1, x2
    // 0x8360a8: r0 = GDT[cid_x0 + 0x15474]()
    //     0x8360a8: mov             x17, #0x5474
    //     0x8360ac: movk            x17, #1, lsl #16
    //     0x8360b0: add             lr, x0, x17
    //     0x8360b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8360b8: blr             lr
    // 0x8360bc: stur            x0, [fp, #-0x60]
    // 0x8360c0: r0 = PointerExitEvent()
    //     0x8360c0: bl              #0x8361c8  ; AllocatePointerExitEventStub -> PointerExitEvent (size=0xbc)
    // 0x8360c4: mov             x2, x0
    // 0x8360c8: ldur            x0, [fp, #-0x10]
    // 0x8360cc: stur            x2, [fp, #-0x68]
    // 0x8360d0: StoreField: r2->field_7 = r0
    //     0x8360d0: stur            x0, [x2, #7]
    // 0x8360d4: StoreField: r2->field_f = rZR
    //     0x8360d4: stur            xzr, [x2, #0xf]
    // 0x8360d8: ldur            x0, [fp, #-0x18]
    // 0x8360dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8360dc: stur            w0, [x2, #0x17]
    // 0x8360e0: ldur            x0, [fp, #-0x20]
    // 0x8360e4: StoreField: r2->field_1b = r0
    //     0x8360e4: stur            x0, [x2, #0x1b]
    // 0x8360e8: ldur            x0, [fp, #-0x28]
    // 0x8360ec: StoreField: r2->field_23 = r0
    //     0x8360ec: stur            w0, [x2, #0x23]
    // 0x8360f0: ldur            x0, [fp, #-0x30]
    // 0x8360f4: StoreField: r2->field_27 = r0
    //     0x8360f4: stur            x0, [x2, #0x27]
    // 0x8360f8: ldur            x0, [fp, #-0x38]
    // 0x8360fc: StoreField: r2->field_2f = r0
    //     0x8360fc: stur            w0, [x2, #0x2f]
    // 0x836100: ldur            x0, [fp, #-0x40]
    // 0x836104: StoreField: r2->field_33 = r0
    //     0x836104: stur            w0, [x2, #0x33]
    // 0x836108: ldur            x0, [fp, #-0x48]
    // 0x83610c: StoreField: r2->field_37 = r0
    //     0x83610c: stur            x0, [x2, #0x37]
    // 0x836110: ldur            x0, [fp, #-0x58]
    // 0x836114: StoreField: r2->field_3f = r0
    //     0x836114: stur            w0, [x2, #0x3f]
    // 0x836118: ldur            x0, [fp, #-0x50]
    // 0x83611c: StoreField: r2->field_43 = r0
    //     0x83611c: stur            w0, [x2, #0x43]
    // 0x836120: StoreField: r2->field_47 = rZR
    //     0x836120: stur            xzr, [x2, #0x47]
    // 0x836124: ldur            d0, [fp, #-0x70]
    // 0x836128: StoreField: r2->field_4f = d0
    //     0x836128: stur            d0, [x2, #0x4f]
    // 0x83612c: ldur            d0, [fp, #-0x78]
    // 0x836130: StoreField: r2->field_57 = d0
    //     0x836130: stur            d0, [x2, #0x57]
    // 0x836134: ldur            d0, [fp, #-0x80]
    // 0x836138: StoreField: r2->field_5f = d0
    //     0x836138: stur            d0, [x2, #0x5f]
    // 0x83613c: ldur            d0, [fp, #-0x88]
    // 0x836140: StoreField: r2->field_67 = d0
    //     0x836140: stur            d0, [x2, #0x67]
    // 0x836144: ldur            d0, [fp, #-0x90]
    // 0x836148: StoreField: r2->field_6f = d0
    //     0x836148: stur            d0, [x2, #0x6f]
    // 0x83614c: ldur            d0, [fp, #-0x98]
    // 0x836150: StoreField: r2->field_77 = d0
    //     0x836150: stur            d0, [x2, #0x77]
    // 0x836154: ldur            d0, [fp, #-0xa0]
    // 0x836158: StoreField: r2->field_7f = d0
    //     0x836158: stur            d0, [x2, #0x7f]
    // 0x83615c: ldur            d0, [fp, #-0xa8]
    // 0x836160: StoreField: r2->field_87 = d0
    //     0x836160: stur            d0, [x2, #0x87]
    // 0x836164: ldur            d0, [fp, #-0xb0]
    // 0x836168: StoreField: r2->field_8f = d0
    //     0x836168: stur            d0, [x2, #0x8f]
    // 0x83616c: ldur            d0, [fp, #-0xb8]
    // 0x836170: StoreField: r2->field_97 = d0
    //     0x836170: stur            d0, [x2, #0x97]
    // 0x836174: ldur            d0, [fp, #-0xc0]
    // 0x836178: StoreField: r2->field_9f = d0
    //     0x836178: stur            d0, [x2, #0x9f]
    // 0x83617c: StoreField: r2->field_a7 = rZR
    //     0x83617c: stur            xzr, [x2, #0xa7]
    // 0x836180: ldur            x0, [fp, #-0x60]
    // 0x836184: StoreField: r2->field_af = r0
    //     0x836184: stur            w0, [x2, #0xaf]
    // 0x836188: ldur            x1, [fp, #-8]
    // 0x83618c: r0 = LoadClassIdInstr(r1)
    //     0x83618c: ldur            x0, [x1, #-1]
    //     0x836190: ubfx            x0, x0, #0xc, #0x14
    // 0x836194: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0x836194: mov             x17, #0x5fe3
    //     0x836198: movk            x17, #1, lsl #16
    //     0x83619c: add             lr, x0, x17
    //     0x8361a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8361a4: blr             lr
    // 0x8361a8: ldur            x1, [fp, #-0x68]
    // 0x8361ac: mov             x2, x0
    // 0x8361b0: r0 = transformed()
    //     0x8361b0: bl              #0xad9590  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::transformed
    // 0x8361b4: LeaveFrame
    //     0x8361b4: mov             SP, fp
    //     0x8361b8: ldp             fp, lr, [SP], #0x10
    // 0x8361bc: ret
    //     0x8361bc: ret             
    // 0x8361c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8361c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8361c4: b               #0x835d44
  }
  _ transformed(/* No info */) {
    // ** addr: 0xad9590, size: 0x58
    // 0xad9590: EnterFrame
    //     0xad9590: stp             fp, lr, [SP, #-0x10]!
    //     0xad9594: mov             fp, SP
    // 0xad9598: AllocStack(0x10)
    //     0xad9598: sub             SP, SP, #0x10
    // 0xad959c: SetupParameters(PointerExitEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad959c: mov             x0, x1
    //     0xad95a0: stur            x1, [fp, #-8]
    //     0xad95a4: stur            x2, [fp, #-0x10]
    // 0xad95a8: cmp             w2, NULL
    // 0xad95ac: b.ne            #0xad95bc
    // 0xad95b0: LeaveFrame
    //     0xad95b0: mov             SP, fp
    //     0xad95b4: ldp             fp, lr, [SP], #0x10
    // 0xad95b8: ret
    //     0xad95b8: ret             
    // 0xad95bc: r0 = _TransformedPointerExitEvent()
    //     0xad95bc: bl              #0xad95e8  ; Allocate_TransformedPointerExitEventStub -> _TransformedPointerExitEvent (size=0x18)
    // 0xad95c0: ldur            x1, [fp, #-8]
    // 0xad95c4: StoreField: r0->field_f = r1
    //     0xad95c4: stur            w1, [x0, #0xf]
    // 0xad95c8: ldur            x1, [fp, #-0x10]
    // 0xad95cc: StoreField: r0->field_13 = r1
    //     0xad95cc: stur            w1, [x0, #0x13]
    // 0xad95d0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad95d4: StoreField: r0->field_7 = r1
    //     0xad95d4: stur            w1, [x0, #7]
    // 0xad95d8: StoreField: r0->field_b = r1
    //     0xad95d8: stur            w1, [x0, #0xb]
    // 0xad95dc: LeaveFrame
    //     0xad95dc: mov             SP, fp
    //     0xad95e0: ldp             fp, lr, [SP], #0x10
    // 0xad95e4: ret
    //     0xad95e4: ret             
  }
}

// class id: 5292, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerEnterEvent extends _MixinApplication471&PointerEvent&_PointerEventDescription&_CopyPointerEnterEvent {

  factory _ PointerEnterEvent.fromMouseEvent(/* No info */) {
    // ** addr: 0x83587c, size: 0x4a0
    // 0x83587c: EnterFrame
    //     0x83587c: stp             fp, lr, [SP, #-0x10]!
    //     0x835880: mov             fp, SP
    // 0x835884: AllocStack(0xc0)
    //     0x835884: sub             SP, SP, #0xc0
    // 0x835888: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x835888: stur            x2, [fp, #-8]
    // 0x83588c: CheckStackOverflow
    //     0x83588c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x835890: cmp             SP, x16
    //     0x835894: b.ls            #0x835d14
    // 0x835898: r0 = LoadClassIdInstr(r2)
    //     0x835898: ldur            x0, [x2, #-1]
    //     0x83589c: ubfx            x0, x0, #0xc, #0x14
    // 0x8358a0: mov             x1, x2
    // 0x8358a4: r0 = GDT[cid_x0 + 0x149dc]()
    //     0x8358a4: mov             x17, #0x49dc
    //     0x8358a8: movk            x17, #1, lsl #16
    //     0x8358ac: add             lr, x0, x17
    //     0x8358b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8358b4: blr             lr
    // 0x8358b8: mov             x3, x0
    // 0x8358bc: ldur            x2, [fp, #-8]
    // 0x8358c0: stur            x3, [fp, #-0x10]
    // 0x8358c4: r0 = LoadClassIdInstr(r2)
    //     0x8358c4: ldur            x0, [x2, #-1]
    //     0x8358c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8358cc: mov             x1, x2
    // 0x8358d0: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0x8358d0: mov             x17, #0x5eb5
    //     0x8358d4: movk            x17, #1, lsl #16
    //     0x8358d8: add             lr, x0, x17
    //     0x8358dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8358e0: blr             lr
    // 0x8358e4: mov             x3, x0
    // 0x8358e8: ldur            x2, [fp, #-8]
    // 0x8358ec: stur            x3, [fp, #-0x18]
    // 0x8358f0: r0 = LoadClassIdInstr(r2)
    //     0x8358f0: ldur            x0, [x2, #-1]
    //     0x8358f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8358f8: mov             x1, x2
    // 0x8358fc: r0 = GDT[cid_x0 + -0x1]()
    //     0x8358fc: sub             lr, x0, #1
    //     0x835900: ldr             lr, [x21, lr, lsl #3]
    //     0x835904: blr             lr
    // 0x835908: mov             x3, x0
    // 0x83590c: ldur            x2, [fp, #-8]
    // 0x835910: stur            x3, [fp, #-0x20]
    // 0x835914: r0 = LoadClassIdInstr(r2)
    //     0x835914: ldur            x0, [x2, #-1]
    //     0x835918: ubfx            x0, x0, #0xc, #0x14
    // 0x83591c: mov             x1, x2
    // 0x835920: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x835920: mov             x17, #0x5e74
    //     0x835924: movk            x17, #1, lsl #16
    //     0x835928: add             lr, x0, x17
    //     0x83592c: ldr             lr, [x21, lr, lsl #3]
    //     0x835930: blr             lr
    // 0x835934: mov             x3, x0
    // 0x835938: ldur            x2, [fp, #-8]
    // 0x83593c: stur            x3, [fp, #-0x28]
    // 0x835940: r0 = LoadClassIdInstr(r2)
    //     0x835940: ldur            x0, [x2, #-1]
    //     0x835944: ubfx            x0, x0, #0xc, #0x14
    // 0x835948: mov             x1, x2
    // 0x83594c: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x83594c: mov             x17, #0x5a90
    //     0x835950: movk            x17, #1, lsl #16
    //     0x835954: add             lr, x0, x17
    //     0x835958: ldr             lr, [x21, lr, lsl #3]
    //     0x83595c: blr             lr
    // 0x835960: mov             x3, x0
    // 0x835964: ldur            x2, [fp, #-8]
    // 0x835968: stur            x3, [fp, #-0x30]
    // 0x83596c: r0 = LoadClassIdInstr(r2)
    //     0x83596c: ldur            x0, [x2, #-1]
    //     0x835970: ubfx            x0, x0, #0xc, #0x14
    // 0x835974: mov             x1, x2
    // 0x835978: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x835978: mov             x17, #0x3f27
    //     0x83597c: movk            x17, #1, lsl #16
    //     0x835980: add             lr, x0, x17
    //     0x835984: ldr             lr, [x21, lr, lsl #3]
    //     0x835988: blr             lr
    // 0x83598c: mov             x3, x0
    // 0x835990: ldur            x2, [fp, #-8]
    // 0x835994: stur            x3, [fp, #-0x38]
    // 0x835998: r0 = LoadClassIdInstr(r2)
    //     0x835998: ldur            x0, [x2, #-1]
    //     0x83599c: ubfx            x0, x0, #0xc, #0x14
    // 0x8359a0: mov             x1, x2
    // 0x8359a4: r0 = GDT[cid_x0 + 0x15a8f]()
    //     0x8359a4: mov             x17, #0x5a8f
    //     0x8359a8: movk            x17, #1, lsl #16
    //     0x8359ac: add             lr, x0, x17
    //     0x8359b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8359b4: blr             lr
    // 0x8359b8: mov             x3, x0
    // 0x8359bc: ldur            x2, [fp, #-8]
    // 0x8359c0: stur            x3, [fp, #-0x40]
    // 0x8359c4: r0 = LoadClassIdInstr(r2)
    //     0x8359c4: ldur            x0, [x2, #-1]
    //     0x8359c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8359cc: mov             x1, x2
    // 0x8359d0: r0 = GDT[cid_x0 + 0x16f9c]()
    //     0x8359d0: mov             x17, #0x6f9c
    //     0x8359d4: movk            x17, #1, lsl #16
    //     0x8359d8: add             lr, x0, x17
    //     0x8359dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8359e0: blr             lr
    // 0x8359e4: mov             x3, x0
    // 0x8359e8: ldur            x2, [fp, #-8]
    // 0x8359ec: stur            x3, [fp, #-0x48]
    // 0x8359f0: r0 = LoadClassIdInstr(r2)
    //     0x8359f0: ldur            x0, [x2, #-1]
    //     0x8359f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8359f8: mov             x1, x2
    // 0x8359fc: r0 = GDT[cid_x0 + 0xb2a3]()
    //     0x8359fc: mov             x17, #0xb2a3
    //     0x835a00: add             lr, x0, x17
    //     0x835a04: ldr             lr, [x21, lr, lsl #3]
    //     0x835a08: blr             lr
    // 0x835a0c: mov             x3, x0
    // 0x835a10: ldur            x2, [fp, #-8]
    // 0x835a14: stur            x3, [fp, #-0x50]
    // 0x835a18: r0 = LoadClassIdInstr(r2)
    //     0x835a18: ldur            x0, [x2, #-1]
    //     0x835a1c: ubfx            x0, x0, #0xc, #0x14
    // 0x835a20: mov             x1, x2
    // 0x835a24: r0 = GDT[cid_x0 + 0x176b6]()
    //     0x835a24: mov             x17, #0x76b6
    //     0x835a28: movk            x17, #1, lsl #16
    //     0x835a2c: add             lr, x0, x17
    //     0x835a30: ldr             lr, [x21, lr, lsl #3]
    //     0x835a34: blr             lr
    // 0x835a38: ldur            x2, [fp, #-8]
    // 0x835a3c: stur            d0, [fp, #-0x70]
    // 0x835a40: r0 = LoadClassIdInstr(r2)
    //     0x835a40: ldur            x0, [x2, #-1]
    //     0x835a44: ubfx            x0, x0, #0xc, #0x14
    // 0x835a48: mov             x1, x2
    // 0x835a4c: r0 = GDT[cid_x0 + 0x139f8]()
    //     0x835a4c: mov             x17, #0x39f8
    //     0x835a50: movk            x17, #1, lsl #16
    //     0x835a54: add             lr, x0, x17
    //     0x835a58: ldr             lr, [x21, lr, lsl #3]
    //     0x835a5c: blr             lr
    // 0x835a60: ldur            x2, [fp, #-8]
    // 0x835a64: stur            d0, [fp, #-0x78]
    // 0x835a68: r0 = LoadClassIdInstr(r2)
    //     0x835a68: ldur            x0, [x2, #-1]
    //     0x835a6c: ubfx            x0, x0, #0xc, #0x14
    // 0x835a70: mov             x1, x2
    // 0x835a74: r0 = GDT[cid_x0 + 0x91c0]()
    //     0x835a74: mov             x17, #0x91c0
    //     0x835a78: add             lr, x0, x17
    //     0x835a7c: ldr             lr, [x21, lr, lsl #3]
    //     0x835a80: blr             lr
    // 0x835a84: ldur            x2, [fp, #-8]
    // 0x835a88: stur            d0, [fp, #-0x80]
    // 0x835a8c: r0 = LoadClassIdInstr(r2)
    //     0x835a8c: ldur            x0, [x2, #-1]
    //     0x835a90: ubfx            x0, x0, #0xc, #0x14
    // 0x835a94: mov             x1, x2
    // 0x835a98: r0 = GDT[cid_x0 + 0x15fe4]()
    //     0x835a98: mov             x17, #0x5fe4
    //     0x835a9c: movk            x17, #1, lsl #16
    //     0x835aa0: add             lr, x0, x17
    //     0x835aa4: ldr             lr, [x21, lr, lsl #3]
    //     0x835aa8: blr             lr
    // 0x835aac: ldur            x2, [fp, #-8]
    // 0x835ab0: stur            d0, [fp, #-0x88]
    // 0x835ab4: r0 = LoadClassIdInstr(r2)
    //     0x835ab4: ldur            x0, [x2, #-1]
    //     0x835ab8: ubfx            x0, x0, #0xc, #0x14
    // 0x835abc: mov             x1, x2
    // 0x835ac0: r0 = GDT[cid_x0 + 0x175dc]()
    //     0x835ac0: mov             x17, #0x75dc
    //     0x835ac4: movk            x17, #1, lsl #16
    //     0x835ac8: add             lr, x0, x17
    //     0x835acc: ldr             lr, [x21, lr, lsl #3]
    //     0x835ad0: blr             lr
    // 0x835ad4: ldur            x2, [fp, #-8]
    // 0x835ad8: stur            d0, [fp, #-0x90]
    // 0x835adc: r0 = LoadClassIdInstr(r2)
    //     0x835adc: ldur            x0, [x2, #-1]
    //     0x835ae0: ubfx            x0, x0, #0xc, #0x14
    // 0x835ae4: mov             x1, x2
    // 0x835ae8: r0 = GDT[cid_x0 + 0x15e18]()
    //     0x835ae8: mov             x17, #0x5e18
    //     0x835aec: movk            x17, #1, lsl #16
    //     0x835af0: add             lr, x0, x17
    //     0x835af4: ldr             lr, [x21, lr, lsl #3]
    //     0x835af8: blr             lr
    // 0x835afc: ldur            x2, [fp, #-8]
    // 0x835b00: stur            d0, [fp, #-0x98]
    // 0x835b04: r0 = LoadClassIdInstr(r2)
    //     0x835b04: ldur            x0, [x2, #-1]
    //     0x835b08: ubfx            x0, x0, #0xc, #0x14
    // 0x835b0c: mov             x1, x2
    // 0x835b10: r0 = GDT[cid_x0 + 0x13f28]()
    //     0x835b10: mov             x17, #0x3f28
    //     0x835b14: movk            x17, #1, lsl #16
    //     0x835b18: add             lr, x0, x17
    //     0x835b1c: ldr             lr, [x21, lr, lsl #3]
    //     0x835b20: blr             lr
    // 0x835b24: ldur            x2, [fp, #-8]
    // 0x835b28: stur            d0, [fp, #-0xa0]
    // 0x835b2c: r0 = LoadClassIdInstr(r2)
    //     0x835b2c: ldur            x0, [x2, #-1]
    //     0x835b30: ubfx            x0, x0, #0xc, #0x14
    // 0x835b34: mov             x1, x2
    // 0x835b38: r0 = GDT[cid_x0 + 0x143d8]()
    //     0x835b38: mov             x17, #0x43d8
    //     0x835b3c: movk            x17, #1, lsl #16
    //     0x835b40: add             lr, x0, x17
    //     0x835b44: ldr             lr, [x21, lr, lsl #3]
    //     0x835b48: blr             lr
    // 0x835b4c: ldur            x2, [fp, #-8]
    // 0x835b50: stur            d0, [fp, #-0xa8]
    // 0x835b54: r0 = LoadClassIdInstr(r2)
    //     0x835b54: ldur            x0, [x2, #-1]
    //     0x835b58: ubfx            x0, x0, #0xc, #0x14
    // 0x835b5c: mov             x1, x2
    // 0x835b60: r0 = GDT[cid_x0 + 0x2f17]()
    //     0x835b60: mov             x17, #0x2f17
    //     0x835b64: add             lr, x0, x17
    //     0x835b68: ldr             lr, [x21, lr, lsl #3]
    //     0x835b6c: blr             lr
    // 0x835b70: ldur            x2, [fp, #-8]
    // 0x835b74: stur            d0, [fp, #-0xb0]
    // 0x835b78: r0 = LoadClassIdInstr(r2)
    //     0x835b78: ldur            x0, [x2, #-1]
    //     0x835b7c: ubfx            x0, x0, #0xc, #0x14
    // 0x835b80: mov             x1, x2
    // 0x835b84: r0 = GDT[cid_x0 + 0x1600b]()
    //     0x835b84: mov             x17, #0x600b
    //     0x835b88: movk            x17, #1, lsl #16
    //     0x835b8c: add             lr, x0, x17
    //     0x835b90: ldr             lr, [x21, lr, lsl #3]
    //     0x835b94: blr             lr
    // 0x835b98: ldur            x2, [fp, #-8]
    // 0x835b9c: stur            d0, [fp, #-0xb8]
    // 0x835ba0: r0 = LoadClassIdInstr(r2)
    //     0x835ba0: ldur            x0, [x2, #-1]
    //     0x835ba4: ubfx            x0, x0, #0xc, #0x14
    // 0x835ba8: mov             x1, x2
    // 0x835bac: r0 = GDT[cid_x0 + 0x4ffa]()
    //     0x835bac: mov             x17, #0x4ffa
    //     0x835bb0: add             lr, x0, x17
    //     0x835bb4: ldr             lr, [x21, lr, lsl #3]
    //     0x835bb8: blr             lr
    // 0x835bbc: ldur            x2, [fp, #-8]
    // 0x835bc0: stur            d0, [fp, #-0xc0]
    // 0x835bc4: r0 = LoadClassIdInstr(r2)
    //     0x835bc4: ldur            x0, [x2, #-1]
    //     0x835bc8: ubfx            x0, x0, #0xc, #0x14
    // 0x835bcc: mov             x1, x2
    // 0x835bd0: r0 = GDT[cid_x0 + 0x176f1]()
    //     0x835bd0: mov             x17, #0x76f1
    //     0x835bd4: movk            x17, #1, lsl #16
    //     0x835bd8: add             lr, x0, x17
    //     0x835bdc: ldr             lr, [x21, lr, lsl #3]
    //     0x835be0: blr             lr
    // 0x835be4: mov             x3, x0
    // 0x835be8: ldur            x2, [fp, #-8]
    // 0x835bec: stur            x3, [fp, #-0x58]
    // 0x835bf0: r0 = LoadClassIdInstr(r2)
    //     0x835bf0: ldur            x0, [x2, #-1]
    //     0x835bf4: ubfx            x0, x0, #0xc, #0x14
    // 0x835bf8: mov             x1, x2
    // 0x835bfc: r0 = GDT[cid_x0 + 0x15474]()
    //     0x835bfc: mov             x17, #0x5474
    //     0x835c00: movk            x17, #1, lsl #16
    //     0x835c04: add             lr, x0, x17
    //     0x835c08: ldr             lr, [x21, lr, lsl #3]
    //     0x835c0c: blr             lr
    // 0x835c10: stur            x0, [fp, #-0x60]
    // 0x835c14: r0 = PointerEnterEvent()
    //     0x835c14: bl              #0x835d1c  ; AllocatePointerEnterEventStub -> PointerEnterEvent (size=0xbc)
    // 0x835c18: mov             x2, x0
    // 0x835c1c: ldur            x0, [fp, #-0x10]
    // 0x835c20: stur            x2, [fp, #-0x68]
    // 0x835c24: StoreField: r2->field_7 = r0
    //     0x835c24: stur            x0, [x2, #7]
    // 0x835c28: StoreField: r2->field_f = rZR
    //     0x835c28: stur            xzr, [x2, #0xf]
    // 0x835c2c: ldur            x0, [fp, #-0x18]
    // 0x835c30: ArrayStore: r2[0] = r0  ; List_4
    //     0x835c30: stur            w0, [x2, #0x17]
    // 0x835c34: ldur            x0, [fp, #-0x20]
    // 0x835c38: StoreField: r2->field_1b = r0
    //     0x835c38: stur            x0, [x2, #0x1b]
    // 0x835c3c: ldur            x0, [fp, #-0x28]
    // 0x835c40: StoreField: r2->field_23 = r0
    //     0x835c40: stur            w0, [x2, #0x23]
    // 0x835c44: ldur            x0, [fp, #-0x30]
    // 0x835c48: StoreField: r2->field_27 = r0
    //     0x835c48: stur            x0, [x2, #0x27]
    // 0x835c4c: ldur            x0, [fp, #-0x38]
    // 0x835c50: StoreField: r2->field_2f = r0
    //     0x835c50: stur            w0, [x2, #0x2f]
    // 0x835c54: ldur            x0, [fp, #-0x40]
    // 0x835c58: StoreField: r2->field_33 = r0
    //     0x835c58: stur            w0, [x2, #0x33]
    // 0x835c5c: ldur            x0, [fp, #-0x48]
    // 0x835c60: StoreField: r2->field_37 = r0
    //     0x835c60: stur            x0, [x2, #0x37]
    // 0x835c64: ldur            x0, [fp, #-0x58]
    // 0x835c68: StoreField: r2->field_3f = r0
    //     0x835c68: stur            w0, [x2, #0x3f]
    // 0x835c6c: ldur            x0, [fp, #-0x50]
    // 0x835c70: StoreField: r2->field_43 = r0
    //     0x835c70: stur            w0, [x2, #0x43]
    // 0x835c74: StoreField: r2->field_47 = rZR
    //     0x835c74: stur            xzr, [x2, #0x47]
    // 0x835c78: ldur            d0, [fp, #-0x70]
    // 0x835c7c: StoreField: r2->field_4f = d0
    //     0x835c7c: stur            d0, [x2, #0x4f]
    // 0x835c80: ldur            d0, [fp, #-0x78]
    // 0x835c84: StoreField: r2->field_57 = d0
    //     0x835c84: stur            d0, [x2, #0x57]
    // 0x835c88: ldur            d0, [fp, #-0x80]
    // 0x835c8c: StoreField: r2->field_5f = d0
    //     0x835c8c: stur            d0, [x2, #0x5f]
    // 0x835c90: ldur            d0, [fp, #-0x88]
    // 0x835c94: StoreField: r2->field_67 = d0
    //     0x835c94: stur            d0, [x2, #0x67]
    // 0x835c98: ldur            d0, [fp, #-0x90]
    // 0x835c9c: StoreField: r2->field_6f = d0
    //     0x835c9c: stur            d0, [x2, #0x6f]
    // 0x835ca0: ldur            d0, [fp, #-0x98]
    // 0x835ca4: StoreField: r2->field_77 = d0
    //     0x835ca4: stur            d0, [x2, #0x77]
    // 0x835ca8: ldur            d0, [fp, #-0xa0]
    // 0x835cac: StoreField: r2->field_7f = d0
    //     0x835cac: stur            d0, [x2, #0x7f]
    // 0x835cb0: ldur            d0, [fp, #-0xa8]
    // 0x835cb4: StoreField: r2->field_87 = d0
    //     0x835cb4: stur            d0, [x2, #0x87]
    // 0x835cb8: ldur            d0, [fp, #-0xb0]
    // 0x835cbc: StoreField: r2->field_8f = d0
    //     0x835cbc: stur            d0, [x2, #0x8f]
    // 0x835cc0: ldur            d0, [fp, #-0xb8]
    // 0x835cc4: StoreField: r2->field_97 = d0
    //     0x835cc4: stur            d0, [x2, #0x97]
    // 0x835cc8: ldur            d0, [fp, #-0xc0]
    // 0x835ccc: StoreField: r2->field_9f = d0
    //     0x835ccc: stur            d0, [x2, #0x9f]
    // 0x835cd0: StoreField: r2->field_a7 = rZR
    //     0x835cd0: stur            xzr, [x2, #0xa7]
    // 0x835cd4: ldur            x0, [fp, #-0x60]
    // 0x835cd8: StoreField: r2->field_af = r0
    //     0x835cd8: stur            w0, [x2, #0xaf]
    // 0x835cdc: ldur            x1, [fp, #-8]
    // 0x835ce0: r0 = LoadClassIdInstr(r1)
    //     0x835ce0: ldur            x0, [x1, #-1]
    //     0x835ce4: ubfx            x0, x0, #0xc, #0x14
    // 0x835ce8: r0 = GDT[cid_x0 + 0x15fe3]()
    //     0x835ce8: mov             x17, #0x5fe3
    //     0x835cec: movk            x17, #1, lsl #16
    //     0x835cf0: add             lr, x0, x17
    //     0x835cf4: ldr             lr, [x21, lr, lsl #3]
    //     0x835cf8: blr             lr
    // 0x835cfc: ldur            x1, [fp, #-0x68]
    // 0x835d00: mov             x2, x0
    // 0x835d04: r0 = transformed()
    //     0x835d04: bl              #0xad952c  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::transformed
    // 0x835d08: LeaveFrame
    //     0x835d08: mov             SP, fp
    //     0x835d0c: ldp             fp, lr, [SP], #0x10
    // 0x835d10: ret
    //     0x835d10: ret             
    // 0x835d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x835d14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x835d18: b               #0x835898
  }
  _ transformed(/* No info */) {
    // ** addr: 0xad952c, size: 0x58
    // 0xad952c: EnterFrame
    //     0xad952c: stp             fp, lr, [SP, #-0x10]!
    //     0xad9530: mov             fp, SP
    // 0xad9534: AllocStack(0x10)
    //     0xad9534: sub             SP, SP, #0x10
    // 0xad9538: SetupParameters(PointerEnterEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9538: mov             x0, x1
    //     0xad953c: stur            x1, [fp, #-8]
    //     0xad9540: stur            x2, [fp, #-0x10]
    // 0xad9544: cmp             w2, NULL
    // 0xad9548: b.ne            #0xad9558
    // 0xad954c: LeaveFrame
    //     0xad954c: mov             SP, fp
    //     0xad9550: ldp             fp, lr, [SP], #0x10
    // 0xad9554: ret
    //     0xad9554: ret             
    // 0xad9558: r0 = _TransformedPointerEnterEvent()
    //     0xad9558: bl              #0xad9584  ; Allocate_TransformedPointerEnterEventStub -> _TransformedPointerEnterEvent (size=0x18)
    // 0xad955c: ldur            x1, [fp, #-8]
    // 0xad9560: StoreField: r0->field_f = r1
    //     0xad9560: stur            w1, [x0, #0xf]
    // 0xad9564: ldur            x1, [fp, #-0x10]
    // 0xad9568: StoreField: r0->field_13 = r1
    //     0xad9568: stur            w1, [x0, #0x13]
    // 0xad956c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad9570: StoreField: r0->field_7 = r1
    //     0xad9570: stur            w1, [x0, #7]
    // 0xad9574: StoreField: r0->field_b = r1
    //     0xad9574: stur            w1, [x0, #0xb]
    // 0xad9578: LeaveFrame
    //     0xad9578: mov             SP, fp
    //     0xad957c: ldp             fp, lr, [SP], #0x10
    // 0xad9580: ret
    //     0xad9580: ret             
  }
}

// class id: 5294, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerHoverEvent extends _MixinApplication469&PointerEvent&_PointerEventDescription&_CopyPointerHoverEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad94c8, size: 0x58
    // 0xad94c8: EnterFrame
    //     0xad94c8: stp             fp, lr, [SP, #-0x10]!
    //     0xad94cc: mov             fp, SP
    // 0xad94d0: AllocStack(0x10)
    //     0xad94d0: sub             SP, SP, #0x10
    // 0xad94d4: SetupParameters(PointerHoverEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad94d4: mov             x0, x1
    //     0xad94d8: stur            x1, [fp, #-8]
    //     0xad94dc: stur            x2, [fp, #-0x10]
    // 0xad94e0: cmp             w2, NULL
    // 0xad94e4: b.ne            #0xad94f4
    // 0xad94e8: LeaveFrame
    //     0xad94e8: mov             SP, fp
    //     0xad94ec: ldp             fp, lr, [SP], #0x10
    // 0xad94f0: ret
    //     0xad94f0: ret             
    // 0xad94f4: r0 = _TransformedPointerHoverEvent()
    //     0xad94f4: bl              #0xad9520  ; Allocate_TransformedPointerHoverEventStub -> _TransformedPointerHoverEvent (size=0x18)
    // 0xad94f8: ldur            x1, [fp, #-8]
    // 0xad94fc: StoreField: r0->field_f = r1
    //     0xad94fc: stur            w1, [x0, #0xf]
    // 0xad9500: ldur            x1, [fp, #-0x10]
    // 0xad9504: StoreField: r0->field_13 = r1
    //     0xad9504: stur            w1, [x0, #0x13]
    // 0xad9508: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad950c: StoreField: r0->field_7 = r1
    //     0xad950c: stur            w1, [x0, #7]
    // 0xad9510: StoreField: r0->field_b = r1
    //     0xad9510: stur            w1, [x0, #0xb]
    // 0xad9514: LeaveFrame
    //     0xad9514: mov             SP, fp
    //     0xad9518: ldp             fp, lr, [SP], #0x10
    // 0xad951c: ret
    //     0xad951c: ret             
  }
}

// class id: 5296, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerRemovedEvent extends _MixinApplication467&PointerEvent&_PointerEventDescription&_CopyPointerRemovedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad9464, size: 0x58
    // 0xad9464: EnterFrame
    //     0xad9464: stp             fp, lr, [SP, #-0x10]!
    //     0xad9468: mov             fp, SP
    // 0xad946c: AllocStack(0x10)
    //     0xad946c: sub             SP, SP, #0x10
    // 0xad9470: SetupParameters(PointerRemovedEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad9470: mov             x0, x1
    //     0xad9474: stur            x1, [fp, #-8]
    //     0xad9478: stur            x2, [fp, #-0x10]
    // 0xad947c: cmp             w2, NULL
    // 0xad9480: b.ne            #0xad9490
    // 0xad9484: LeaveFrame
    //     0xad9484: mov             SP, fp
    //     0xad9488: ldp             fp, lr, [SP], #0x10
    // 0xad948c: ret
    //     0xad948c: ret             
    // 0xad9490: r0 = _TransformedPointerRemovedEvent()
    //     0xad9490: bl              #0xad94bc  ; Allocate_TransformedPointerRemovedEventStub -> _TransformedPointerRemovedEvent (size=0x18)
    // 0xad9494: ldur            x1, [fp, #-8]
    // 0xad9498: StoreField: r0->field_f = r1
    //     0xad9498: stur            w1, [x0, #0xf]
    // 0xad949c: ldur            x1, [fp, #-0x10]
    // 0xad94a0: StoreField: r0->field_13 = r1
    //     0xad94a0: stur            w1, [x0, #0x13]
    // 0xad94a4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad94a8: StoreField: r0->field_7 = r1
    //     0xad94a8: stur            w1, [x0, #7]
    // 0xad94ac: StoreField: r0->field_b = r1
    //     0xad94ac: stur            w1, [x0, #0xb]
    // 0xad94b0: LeaveFrame
    //     0xad94b0: mov             SP, fp
    //     0xad94b4: ldp             fp, lr, [SP], #0x10
    // 0xad94b8: ret
    //     0xad94b8: ret             
  }
}

// class id: 5298, size: 0xbc, field offset: 0xbc
//   const constructor, 
class PointerAddedEvent extends _MixinApplication465&PointerEvent&_PointerEventDescription&_CopyPointerAddedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0xad9400, size: 0x58
    // 0xad9400: EnterFrame
    //     0xad9400: stp             fp, lr, [SP, #-0x10]!
    //     0xad9404: mov             fp, SP
    // 0xad9408: AllocStack(0x10)
    //     0xad9408: sub             SP, SP, #0x10
    // 0xad940c: SetupParameters(PointerAddedEvent this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xad940c: mov             x0, x1
    //     0xad9410: stur            x1, [fp, #-8]
    //     0xad9414: stur            x2, [fp, #-0x10]
    // 0xad9418: cmp             w2, NULL
    // 0xad941c: b.ne            #0xad942c
    // 0xad9420: LeaveFrame
    //     0xad9420: mov             SP, fp
    //     0xad9424: ldp             fp, lr, [SP], #0x10
    // 0xad9428: ret
    //     0xad9428: ret             
    // 0xad942c: r0 = _TransformedPointerAddedEvent()
    //     0xad942c: bl              #0xad9458  ; Allocate_TransformedPointerAddedEventStub -> _TransformedPointerAddedEvent (size=0x18)
    // 0xad9430: ldur            x1, [fp, #-8]
    // 0xad9434: StoreField: r0->field_f = r1
    //     0xad9434: stur            w1, [x0, #0xf]
    // 0xad9438: ldur            x1, [fp, #-0x10]
    // 0xad943c: StoreField: r0->field_13 = r1
    //     0xad943c: stur            w1, [x0, #0x13]
    // 0xad9440: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xad9444: StoreField: r0->field_7 = r1
    //     0xad9444: stur            w1, [x0, #7]
    // 0xad9448: StoreField: r0->field_b = r1
    //     0xad9448: stur            w1, [x0, #0xb]
    // 0xad944c: LeaveFrame
    //     0xad944c: mov             SP, fp
    //     0xad9450: ldp             fp, lr, [SP], #0x10
    // 0xad9454: ret
    //     0xad9454: ret             
  }
}

// class id: 5299, size: 0xbc, field offset: 0xbc
abstract class _PointerEventDescription extends PointerEvent {
}
