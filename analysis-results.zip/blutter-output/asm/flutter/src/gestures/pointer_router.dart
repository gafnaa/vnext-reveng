// lib: , url: package:flutter/src/gestures/pointer_router.dart

// class id: 1048829, size: 0x8
class :: {
}

// class id: 3158, size: 0x10, field offset: 0x8
class PointerRouter extends Object {

  _ route(/* No info */) {
    // ** addr: 0x832368, size: 0x110
    // 0x832368: EnterFrame
    //     0x832368: stp             fp, lr, [SP, #-0x10]!
    //     0x83236c: mov             fp, SP
    // 0x832370: AllocStack(0x28)
    //     0x832370: sub             SP, SP, #0x28
    // 0x832374: SetupParameters(PointerRouter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x832374: mov             x3, x1
    //     0x832378: stur            x1, [fp, #-0x10]
    //     0x83237c: stur            x2, [fp, #-0x18]
    // 0x832380: CheckStackOverflow
    //     0x832380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x832384: cmp             SP, x16
    //     0x832388: b.ls            #0x832470
    // 0x83238c: LoadField: r4 = r3->field_7
    //     0x83238c: ldur            w4, [x3, #7]
    // 0x832390: DecompressPointer r4
    //     0x832390: add             x4, x4, HEAP, lsl #32
    // 0x832394: stur            x4, [fp, #-8]
    // 0x832398: r0 = LoadClassIdInstr(r2)
    //     0x832398: ldur            x0, [x2, #-1]
    //     0x83239c: ubfx            x0, x0, #0xc, #0x14
    // 0x8323a0: mov             x1, x2
    // 0x8323a4: r0 = GDT[cid_x0 + -0x1]()
    //     0x8323a4: sub             lr, x0, #1
    //     0x8323a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8323ac: blr             lr
    // 0x8323b0: mov             x2, x0
    // 0x8323b4: r0 = BoxInt64Instr(r2)
    //     0x8323b4: sbfiz           x0, x2, #1, #0x1f
    //     0x8323b8: cmp             x2, x0, asr #1
    //     0x8323bc: b.eq            #0x8323c8
    //     0x8323c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8323c4: stur            x2, [x0, #7]
    // 0x8323c8: ldur            x1, [fp, #-8]
    // 0x8323cc: mov             x2, x0
    // 0x8323d0: r0 = _getValueOrData()
    //     0x8323d0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8323d4: mov             x1, x0
    // 0x8323d8: ldur            x0, [fp, #-8]
    // 0x8323dc: LoadField: r2 = r0->field_f
    //     0x8323dc: ldur            w2, [x0, #0xf]
    // 0x8323e0: DecompressPointer r2
    //     0x8323e0: add             x2, x2, HEAP, lsl #32
    // 0x8323e4: cmp             w2, w1
    // 0x8323e8: b.ne            #0x8323f4
    // 0x8323ec: r3 = Null
    //     0x8323ec: mov             x3, NULL
    // 0x8323f0: b               #0x8323f8
    // 0x8323f4: mov             x3, x1
    // 0x8323f8: ldur            x0, [fp, #-0x10]
    // 0x8323fc: stur            x3, [fp, #-0x20]
    // 0x832400: LoadField: r4 = r0->field_b
    //     0x832400: ldur            w4, [x0, #0xb]
    // 0x832404: DecompressPointer r4
    //     0x832404: add             x4, x4, HEAP, lsl #32
    // 0x832408: mov             x2, x4
    // 0x83240c: stur            x4, [fp, #-8]
    // 0x832410: r1 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x832410: ldr             x1, [PP, #0x4310]  ; [pp+0x4310] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x832414: r0 = LinkedHashMap.of()
    //     0x832414: bl              #0x833524  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x832418: mov             x3, x0
    // 0x83241c: ldur            x0, [fp, #-0x20]
    // 0x832420: stur            x3, [fp, #-0x28]
    // 0x832424: cmp             w0, NULL
    // 0x832428: b.eq            #0x83244c
    // 0x83242c: mov             x2, x0
    // 0x832430: r1 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x832430: ldr             x1, [PP, #0x4310]  ; [pp+0x4310] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x832434: r0 = LinkedHashMap.of()
    //     0x832434: bl              #0x833524  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x832438: ldur            x1, [fp, #-0x10]
    // 0x83243c: ldur            x2, [fp, #-0x18]
    // 0x832440: ldur            x3, [fp, #-0x20]
    // 0x832444: mov             x5, x0
    // 0x832448: r0 = _dispatchEventToRoutes()
    //     0x832448: bl              #0x832478  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes
    // 0x83244c: ldur            x1, [fp, #-0x10]
    // 0x832450: ldur            x2, [fp, #-0x18]
    // 0x832454: ldur            x3, [fp, #-8]
    // 0x832458: ldur            x5, [fp, #-0x28]
    // 0x83245c: r0 = _dispatchEventToRoutes()
    //     0x83245c: bl              #0x832478  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes
    // 0x832460: r0 = Null
    //     0x832460: mov             x0, NULL
    // 0x832464: LeaveFrame
    //     0x832464: mov             SP, fp
    //     0x832468: ldp             fp, lr, [SP], #0x10
    // 0x83246c: ret
    //     0x83246c: ret             
    // 0x832470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832474: b               #0x83238c
  }
  _ _dispatchEventToRoutes(/* No info */) {
    // ** addr: 0x832478, size: 0x84
    // 0x832478: EnterFrame
    //     0x832478: stp             fp, lr, [SP, #-0x10]!
    //     0x83247c: mov             fp, SP
    // 0x832480: AllocStack(0x20)
    //     0x832480: sub             SP, SP, #0x20
    // 0x832484: SetupParameters(PointerRouter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r1, fp-0x20 */)
    //     0x832484: mov             x0, x1
    //     0x832488: stur            x1, [fp, #-8]
    //     0x83248c: mov             x1, x5
    //     0x832490: stur            x2, [fp, #-0x10]
    //     0x832494: stur            x3, [fp, #-0x18]
    //     0x832498: stur            x5, [fp, #-0x20]
    // 0x83249c: CheckStackOverflow
    //     0x83249c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8324a0: cmp             SP, x16
    //     0x8324a4: b.ls            #0x8324f4
    // 0x8324a8: r1 = 3
    //     0x8324a8: mov             x1, #3
    // 0x8324ac: r0 = AllocateContext()
    //     0x8324ac: bl              #0x13de838  ; AllocateContextStub
    // 0x8324b0: mov             x1, x0
    // 0x8324b4: ldur            x0, [fp, #-8]
    // 0x8324b8: StoreField: r1->field_f = r0
    //     0x8324b8: stur            w0, [x1, #0xf]
    // 0x8324bc: ldur            x0, [fp, #-0x10]
    // 0x8324c0: StoreField: r1->field_13 = r0
    //     0x8324c0: stur            w0, [x1, #0x13]
    // 0x8324c4: ldur            x0, [fp, #-0x18]
    // 0x8324c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8324c8: stur            w0, [x1, #0x17]
    // 0x8324cc: mov             x2, x1
    // 0x8324d0: r1 = Function '<anonymous closure>':.
    //     0x8324d0: ldr             x1, [PP, #0x4318]  ; [pp+0x4318] AnonymousClosure: (0x8324fc), in [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes (0x832478)
    // 0x8324d4: r0 = AllocateClosure()
    //     0x8324d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8324d8: ldur            x1, [fp, #-0x20]
    // 0x8324dc: mov             x2, x0
    // 0x8324e0: r0 = forEach()
    //     0x8324e0: bl              #0x12a0da0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0x8324e4: r0 = Null
    //     0x8324e4: mov             x0, NULL
    // 0x8324e8: LeaveFrame
    //     0x8324e8: mov             SP, fp
    //     0x8324ec: ldp             fp, lr, [SP], #0x10
    // 0x8324f0: ret
    //     0x8324f0: ret             
    // 0x8324f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8324f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8324f8: b               #0x8324a8
  }
  [closure] void <anonymous closure>(dynamic, (dynamic, PointerEvent) => void, Matrix4?) {
    // ** addr: 0x8324fc, size: 0x84
    // 0x8324fc: EnterFrame
    //     0x8324fc: stp             fp, lr, [SP, #-0x10]!
    //     0x832500: mov             fp, SP
    // 0x832504: AllocStack(0x8)
    //     0x832504: sub             SP, SP, #8
    // 0x832508: SetupParameters([dynamic _ /* r0 */])
    //     0x832508: ldr             x0, [fp, #0x20]
    //     0x83250c: ldur            w3, [x0, #0x17]
    //     0x832510: add             x3, x3, HEAP, lsl #32
    //     0x832514: stur            x3, [fp, #-8]
    // 0x832518: CheckStackOverflow
    //     0x832518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83251c: cmp             SP, x16
    //     0x832520: b.ls            #0x832578
    // 0x832524: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x832524: ldur            w1, [x3, #0x17]
    // 0x832528: DecompressPointer r1
    //     0x832528: add             x1, x1, HEAP, lsl #32
    // 0x83252c: r0 = LoadClassIdInstr(r1)
    //     0x83252c: ldur            x0, [x1, #-1]
    //     0x832530: ubfx            x0, x0, #0xc, #0x14
    // 0x832534: ldr             x2, [fp, #0x18]
    // 0x832538: r0 = GDT[cid_x0 + -0x104]()
    //     0x832538: sub             lr, x0, #0x104
    //     0x83253c: ldr             lr, [x21, lr, lsl #3]
    //     0x832540: blr             lr
    // 0x832544: tbnz            w0, #4, #0x832568
    // 0x832548: ldur            x0, [fp, #-8]
    // 0x83254c: LoadField: r1 = r0->field_f
    //     0x83254c: ldur            w1, [x0, #0xf]
    // 0x832550: DecompressPointer r1
    //     0x832550: add             x1, x1, HEAP, lsl #32
    // 0x832554: LoadField: r2 = r0->field_13
    //     0x832554: ldur            w2, [x0, #0x13]
    // 0x832558: DecompressPointer r2
    //     0x832558: add             x2, x2, HEAP, lsl #32
    // 0x83255c: ldr             x3, [fp, #0x18]
    // 0x832560: ldr             x5, [fp, #0x10]
    // 0x832564: r0 = _dispatch()
    //     0x832564: bl              #0x832580  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatch
    // 0x832568: r0 = Null
    //     0x832568: mov             x0, NULL
    // 0x83256c: LeaveFrame
    //     0x83256c: mov             SP, fp
    //     0x832570: ldp             fp, lr, [SP], #0x10
    // 0x832574: ret
    //     0x832574: ret             
    // 0x832578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832578: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83257c: b               #0x832524
  }
  _ _dispatch(/* No info */) {
    // ** addr: 0x832580, size: 0xf4
    // 0x832580: EnterFrame
    //     0x832580: stp             fp, lr, [SP, #-0x10]!
    //     0x832584: mov             fp, SP
    // 0x832588: AllocStack(0x78)
    //     0x832588: sub             SP, SP, #0x78
    // 0x83258c: SetupParameters(dynamic _ /* r2 => r5, fp-0x58 */, dynamic _ /* r3 => r4, fp-0x60 */, dynamic _ /* r5 => r3, fp-0x68 */)
    //     0x83258c: mov             x4, x3
    //     0x832590: stur            x3, [fp, #-0x60]
    //     0x832594: mov             x3, x5
    //     0x832598: stur            x5, [fp, #-0x68]
    //     0x83259c: mov             x5, x2
    //     0x8325a0: stur            x2, [fp, #-0x58]
    // 0x8325a4: CheckStackOverflow
    //     0x8325a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8325a8: cmp             SP, x16
    //     0x8325ac: b.ls            #0x83266c
    // 0x8325b0: r0 = LoadClassIdInstr(r5)
    //     0x8325b0: ldur            x0, [x5, #-1]
    //     0x8325b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8325b8: mov             x1, x5
    // 0x8325bc: mov             x2, x3
    // 0x8325c0: r0 = GDT[cid_x0 + 0x14eda]()
    //     0x8325c0: mov             x17, #0x4eda
    //     0x8325c4: movk            x17, #1, lsl #16
    //     0x8325c8: add             lr, x0, x17
    //     0x8325cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8325d0: blr             lr
    // 0x8325d4: mov             x1, x0
    // 0x8325d8: stur            x1, [fp, #-0x58]
    // 0x8325dc: ldur            x16, [fp, #-0x60]
    // 0x8325e0: stp             x1, x16, [SP]
    // 0x8325e4: ldur            x0, [fp, #-0x60]
    // 0x8325e8: ClosureCall
    //     0x8325e8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8325ec: ldur            x2, [x0, #0x1f]
    //     0x8325f0: blr             x2
    // 0x8325f4: b               #0x83265c
    // 0x8325f8: sub             SP, fp, #0x78
    // 0x8325fc: mov             x2, x0
    // 0x832600: stur            x0, [fp, #-0x58]
    // 0x832604: mov             x0, x1
    // 0x832608: stur            x1, [fp, #-0x60]
    // 0x83260c: r1 = <List<Object>>
    //     0x83260c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x832610: r0 = ErrorDescription()
    //     0x832610: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x832614: mov             x1, x0
    // 0x832618: r2 = "while routing a pointer event"
    //     0x832618: ldr             x2, [PP, #0x4320]  ; [pp+0x4320] "while routing a pointer event"
    // 0x83261c: r3 = Instance_DiagnosticLevel
    //     0x83261c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x832620: stur            x0, [fp, #-0x68]
    // 0x832624: r0 = _ErrorDiagnostic()
    //     0x832624: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x832628: r0 = FlutterErrorDetails()
    //     0x832628: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x83262c: mov             x1, x0
    // 0x832630: ldur            x0, [fp, #-0x58]
    // 0x832634: StoreField: r1->field_7 = r0
    //     0x832634: stur            w0, [x1, #7]
    // 0x832638: ldur            x0, [fp, #-0x60]
    // 0x83263c: StoreField: r1->field_b = r0
    //     0x83263c: stur            w0, [x1, #0xb]
    // 0x832640: r0 = "gesture library"
    //     0x832640: ldr             x0, [PP, #0x42f0]  ; [pp+0x42f0] "gesture library"
    // 0x832644: StoreField: r1->field_f = r0
    //     0x832644: stur            w0, [x1, #0xf]
    // 0x832648: ldur            x0, [fp, #-0x68]
    // 0x83264c: StoreField: r1->field_13 = r0
    //     0x83264c: stur            w0, [x1, #0x13]
    // 0x832650: r0 = false
    //     0x832650: add             x0, NULL, #0x30  ; false
    // 0x832654: StoreField: r1->field_1b = r0
    //     0x832654: stur            w0, [x1, #0x1b]
    // 0x832658: r0 = reportError()
    //     0x832658: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x83265c: r0 = Null
    //     0x83265c: mov             x0, NULL
    // 0x832660: LeaveFrame
    //     0x832660: mov             SP, fp
    //     0x832664: ldp             fp, lr, [SP], #0x10
    // 0x832668: ret
    //     0x832668: ret             
    // 0x83266c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83266c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832670: b               #0x8325b0
  }
  _ addGlobalRoute(/* No info */) {
    // ** addr: 0x83b738, size: 0xe0
    // 0x83b738: EnterFrame
    //     0x83b738: stp             fp, lr, [SP, #-0x10]!
    //     0x83b73c: mov             fp, SP
    // 0x83b740: AllocStack(0x18)
    //     0x83b740: sub             SP, SP, #0x18
    // 0x83b744: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x83b744: mov             x3, x2
    //     0x83b748: stur            x2, [fp, #-0x18]
    // 0x83b74c: CheckStackOverflow
    //     0x83b74c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83b750: cmp             SP, x16
    //     0x83b754: b.ls            #0x83b810
    // 0x83b758: LoadField: r4 = r1->field_b
    //     0x83b758: ldur            w4, [x1, #0xb]
    // 0x83b75c: DecompressPointer r4
    //     0x83b75c: add             x4, x4, HEAP, lsl #32
    // 0x83b760: stur            x4, [fp, #-0x10]
    // 0x83b764: LoadField: r5 = r4->field_7
    //     0x83b764: ldur            w5, [x4, #7]
    // 0x83b768: DecompressPointer r5
    //     0x83b768: add             x5, x5, HEAP, lsl #32
    // 0x83b76c: mov             x0, x3
    // 0x83b770: mov             x2, x5
    // 0x83b774: stur            x5, [fp, #-8]
    // 0x83b778: r1 = Null
    //     0x83b778: mov             x1, NULL
    // 0x83b77c: cmp             w2, NULL
    // 0x83b780: b.eq            #0x83b79c
    // 0x83b784: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x83b784: ldur            w4, [x2, #0x17]
    // 0x83b788: DecompressPointer r4
    //     0x83b788: add             x4, x4, HEAP, lsl #32
    // 0x83b78c: r8 = X0
    //     0x83b78c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x83b790: LoadField: r9 = r4->field_7
    //     0x83b790: ldur            x9, [x4, #7]
    // 0x83b794: r3 = Null
    //     0x83b794: ldr             x3, [PP, #0x1de8]  ; [pp+0x1de8] Null
    // 0x83b798: blr             x9
    // 0x83b79c: ldur            x2, [fp, #-8]
    // 0x83b7a0: r0 = Null
    //     0x83b7a0: mov             x0, NULL
    // 0x83b7a4: r1 = Null
    //     0x83b7a4: mov             x1, NULL
    // 0x83b7a8: cmp             w2, NULL
    // 0x83b7ac: b.eq            #0x83b7c8
    // 0x83b7b0: LoadField: r4 = r2->field_1b
    //     0x83b7b0: ldur            w4, [x2, #0x1b]
    // 0x83b7b4: DecompressPointer r4
    //     0x83b7b4: add             x4, x4, HEAP, lsl #32
    // 0x83b7b8: r8 = X1
    //     0x83b7b8: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x83b7bc: LoadField: r9 = r4->field_7
    //     0x83b7bc: ldur            x9, [x4, #7]
    // 0x83b7c0: r3 = Null
    //     0x83b7c0: ldr             x3, [PP, #0x1df8]  ; [pp+0x1df8] Null
    // 0x83b7c4: blr             x9
    // 0x83b7c8: ldur            x1, [fp, #-0x10]
    // 0x83b7cc: ldur            x2, [fp, #-0x18]
    // 0x83b7d0: r0 = _hashCode()
    //     0x83b7d0: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x83b7d4: mov             x2, x0
    // 0x83b7d8: r0 = BoxInt64Instr(r2)
    //     0x83b7d8: sbfiz           x0, x2, #1, #0x1f
    //     0x83b7dc: cmp             x2, x0, asr #1
    //     0x83b7e0: b.eq            #0x83b7ec
    //     0x83b7e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x83b7e8: stur            x2, [x0, #7]
    // 0x83b7ec: ldur            x1, [fp, #-0x10]
    // 0x83b7f0: ldur            x2, [fp, #-0x18]
    // 0x83b7f4: mov             x5, x0
    // 0x83b7f8: r3 = Null
    //     0x83b7f8: mov             x3, NULL
    // 0x83b7fc: r0 = _set()
    //     0x83b7fc: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x83b800: r0 = Null
    //     0x83b800: mov             x0, NULL
    // 0x83b804: LeaveFrame
    //     0x83b804: mov             SP, fp
    //     0x83b808: ldp             fp, lr, [SP], #0x10
    // 0x83b80c: ret
    //     0x83b80c: ret             
    // 0x83b810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b814: b               #0x83b758
  }
  _ PointerRouter(/* No info */) {
    // ** addr: 0x89f5d0, size: 0x94
    // 0x89f5d0: EnterFrame
    //     0x89f5d0: stp             fp, lr, [SP, #-0x10]!
    //     0x89f5d4: mov             fp, SP
    // 0x89f5d8: AllocStack(0x18)
    //     0x89f5d8: sub             SP, SP, #0x18
    // 0x89f5dc: SetupParameters(PointerRouter this /* r1 => r1, fp-0x8 */)
    //     0x89f5dc: stur            x1, [fp, #-8]
    // 0x89f5e0: CheckStackOverflow
    //     0x89f5e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f5e4: cmp             SP, x16
    //     0x89f5e8: b.ls            #0x89f65c
    // 0x89f5ec: r16 = <int, Map<(dynamic this, PointerEvent) => void?, Matrix4?>>
    //     0x89f5ec: ldr             x16, [PP, #0x6230]  ; [pp+0x6230] TypeArguments: <int, Map<(dynamic this, PointerEvent) => void?, Matrix4?>>
    // 0x89f5f0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x89f5f4: stp             lr, x16, [SP]
    // 0x89f5f8: r0 = Map._fromLiteral()
    //     0x89f5f8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x89f5fc: ldur            x1, [fp, #-8]
    // 0x89f600: StoreField: r1->field_7 = r0
    //     0x89f600: stur            w0, [x1, #7]
    //     0x89f604: ldurb           w16, [x1, #-1]
    //     0x89f608: ldurb           w17, [x0, #-1]
    //     0x89f60c: and             x16, x17, x16, lsr #2
    //     0x89f610: tst             x16, HEAP, lsr #32
    //     0x89f614: b.eq            #0x89f61c
    //     0x89f618: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89f61c: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x89f61c: ldr             x16, [PP, #0x4310]  ; [pp+0x4310] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x89f620: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x89f624: stp             lr, x16, [SP]
    // 0x89f628: r0 = Map._fromLiteral()
    //     0x89f628: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x89f62c: ldur            x1, [fp, #-8]
    // 0x89f630: StoreField: r1->field_b = r0
    //     0x89f630: stur            w0, [x1, #0xb]
    //     0x89f634: ldurb           w16, [x1, #-1]
    //     0x89f638: ldurb           w17, [x0, #-1]
    //     0x89f63c: and             x16, x17, x16, lsr #2
    //     0x89f640: tst             x16, HEAP, lsr #32
    //     0x89f644: b.eq            #0x89f64c
    //     0x89f648: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89f64c: r0 = Null
    //     0x89f64c: mov             x0, NULL
    // 0x89f650: LeaveFrame
    //     0x89f650: mov             SP, fp
    //     0x89f654: ldp             fp, lr, [SP], #0x10
    // 0x89f658: ret
    //     0x89f658: ret             
    // 0x89f65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f65c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f660: b               #0x89f5ec
  }
  _ removeRoute(/* No info */) {
    // ** addr: 0xb8bf6c, size: 0xe0
    // 0xb8bf6c: EnterFrame
    //     0xb8bf6c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8bf70: mov             fp, SP
    // 0xb8bf74: AllocStack(0x20)
    //     0xb8bf74: sub             SP, SP, #0x20
    // 0xb8bf78: SetupParameters(dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb8bf78: stur            x3, [fp, #-0x18]
    // 0xb8bf7c: CheckStackOverflow
    //     0xb8bf7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8bf80: cmp             SP, x16
    //     0xb8bf84: b.ls            #0xb8c040
    // 0xb8bf88: LoadField: r4 = r1->field_7
    //     0xb8bf88: ldur            w4, [x1, #7]
    // 0xb8bf8c: DecompressPointer r4
    //     0xb8bf8c: add             x4, x4, HEAP, lsl #32
    // 0xb8bf90: stur            x4, [fp, #-0x10]
    // 0xb8bf94: r0 = BoxInt64Instr(r2)
    //     0xb8bf94: sbfiz           x0, x2, #1, #0x1f
    //     0xb8bf98: cmp             x2, x0, asr #1
    //     0xb8bf9c: b.eq            #0xb8bfa8
    //     0xb8bfa0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb8bfa4: stur            x2, [x0, #7]
    // 0xb8bfa8: mov             x1, x4
    // 0xb8bfac: mov             x2, x0
    // 0xb8bfb0: stur            x0, [fp, #-8]
    // 0xb8bfb4: r0 = _getValueOrData()
    //     0xb8bfb4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb8bfb8: ldur            x3, [fp, #-0x10]
    // 0xb8bfbc: LoadField: r1 = r3->field_f
    //     0xb8bfbc: ldur            w1, [x3, #0xf]
    // 0xb8bfc0: DecompressPointer r1
    //     0xb8bfc0: add             x1, x1, HEAP, lsl #32
    // 0xb8bfc4: cmp             w1, w0
    // 0xb8bfc8: b.ne            #0xb8bfd4
    // 0xb8bfcc: r4 = Null
    //     0xb8bfcc: mov             x4, NULL
    // 0xb8bfd0: b               #0xb8bfd8
    // 0xb8bfd4: mov             x4, x0
    // 0xb8bfd8: stur            x4, [fp, #-0x20]
    // 0xb8bfdc: cmp             w4, NULL
    // 0xb8bfe0: b.eq            #0xb8c048
    // 0xb8bfe4: r0 = LoadClassIdInstr(r4)
    //     0xb8bfe4: ldur            x0, [x4, #-1]
    //     0xb8bfe8: ubfx            x0, x0, #0xc, #0x14
    // 0xb8bfec: mov             x1, x4
    // 0xb8bff0: ldur            x2, [fp, #-0x18]
    // 0xb8bff4: r0 = GDT[cid_x0 + 0x129dd]()
    //     0xb8bff4: mov             x17, #0x29dd
    //     0xb8bff8: movk            x17, #1, lsl #16
    //     0xb8bffc: add             lr, x0, x17
    //     0xb8c000: ldr             lr, [x21, lr, lsl #3]
    //     0xb8c004: blr             lr
    // 0xb8c008: ldur            x1, [fp, #-0x20]
    // 0xb8c00c: r0 = LoadClassIdInstr(r1)
    //     0xb8c00c: ldur            x0, [x1, #-1]
    //     0xb8c010: ubfx            x0, x0, #0xc, #0x14
    // 0xb8c014: r0 = GDT[cid_x0 + 0x687]()
    //     0xb8c014: add             lr, x0, #0x687
    //     0xb8c018: ldr             lr, [x21, lr, lsl #3]
    //     0xb8c01c: blr             lr
    // 0xb8c020: tbnz            w0, #4, #0xb8c030
    // 0xb8c024: ldur            x1, [fp, #-0x10]
    // 0xb8c028: ldur            x2, [fp, #-8]
    // 0xb8c02c: r0 = remove()
    //     0xb8c02c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xb8c030: r0 = Null
    //     0xb8c030: mov             x0, NULL
    // 0xb8c034: LeaveFrame
    //     0xb8c034: mov             SP, fp
    //     0xb8c038: ldp             fp, lr, [SP], #0x10
    // 0xb8c03c: ret
    //     0xb8c03c: ret             
    // 0xb8c040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8c040: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8c044: b               #0xb8bf88
    // 0xb8c048: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8c048: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addRoute(/* No info */) {
    // ** addr: 0xba8c10, size: 0xac
    // 0xba8c10: EnterFrame
    //     0xba8c10: stp             fp, lr, [SP, #-0x10]!
    //     0xba8c14: mov             fp, SP
    // 0xba8c18: AllocStack(0x20)
    //     0xba8c18: sub             SP, SP, #0x20
    // 0xba8c1c: SetupParameters(dynamic _ /* r3 => r4, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */)
    //     0xba8c1c: mov             x4, x3
    //     0xba8c20: stur            x3, [fp, #-0x18]
    //     0xba8c24: mov             x3, x5
    //     0xba8c28: stur            x5, [fp, #-0x20]
    // 0xba8c2c: CheckStackOverflow
    //     0xba8c2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8c30: cmp             SP, x16
    //     0xba8c34: b.ls            #0xba8cb4
    // 0xba8c38: LoadField: r5 = r1->field_7
    //     0xba8c38: ldur            w5, [x1, #7]
    // 0xba8c3c: DecompressPointer r5
    //     0xba8c3c: add             x5, x5, HEAP, lsl #32
    // 0xba8c40: stur            x5, [fp, #-0x10]
    // 0xba8c44: r0 = BoxInt64Instr(r2)
    //     0xba8c44: sbfiz           x0, x2, #1, #0x1f
    //     0xba8c48: cmp             x2, x0, asr #1
    //     0xba8c4c: b.eq            #0xba8c58
    //     0xba8c50: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba8c54: stur            x2, [x0, #7]
    // 0xba8c58: r1 = Function '<anonymous closure>':.
    //     0xba8c58: add             x1, PP, #0x96, lsl #12  ; [pp+0x960e8] AnonymousClosure: (0xba8cbc), in [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute (0xba8c10)
    //     0xba8c5c: ldr             x1, [x1, #0xe8]
    // 0xba8c60: r2 = Null
    //     0xba8c60: mov             x2, NULL
    // 0xba8c64: stur            x0, [fp, #-8]
    // 0xba8c68: r0 = AllocateClosure()
    //     0xba8c68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba8c6c: ldur            x1, [fp, #-0x10]
    // 0xba8c70: ldur            x2, [fp, #-8]
    // 0xba8c74: mov             x3, x0
    // 0xba8c78: r0 = putIfAbsent()
    //     0xba8c78: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xba8c7c: r1 = LoadClassIdInstr(r0)
    //     0xba8c7c: ldur            x1, [x0, #-1]
    //     0xba8c80: ubfx            x1, x1, #0xc, #0x14
    // 0xba8c84: mov             x16, x0
    // 0xba8c88: mov             x0, x1
    // 0xba8c8c: mov             x1, x16
    // 0xba8c90: ldur            x2, [fp, #-0x18]
    // 0xba8c94: ldur            x3, [fp, #-0x20]
    // 0xba8c98: r0 = GDT[cid_x0 + -0xd50]()
    //     0xba8c98: sub             lr, x0, #0xd50
    //     0xba8c9c: ldr             lr, [x21, lr, lsl #3]
    //     0xba8ca0: blr             lr
    // 0xba8ca4: r0 = Null
    //     0xba8ca4: mov             x0, NULL
    // 0xba8ca8: LeaveFrame
    //     0xba8ca8: mov             SP, fp
    //     0xba8cac: ldp             fp, lr, [SP], #0x10
    // 0xba8cb0: ret
    //     0xba8cb0: ret             
    // 0xba8cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8cb8: b               #0xba8c38
  }
  [closure] Map<(dynamic, PointerEvent) => void, Matrix4?> <anonymous closure>(dynamic) {
    // ** addr: 0xba8cbc, size: 0x3c
    // 0xba8cbc: EnterFrame
    //     0xba8cbc: stp             fp, lr, [SP, #-0x10]!
    //     0xba8cc0: mov             fp, SP
    // 0xba8cc4: AllocStack(0x10)
    //     0xba8cc4: sub             SP, SP, #0x10
    // 0xba8cc8: CheckStackOverflow
    //     0xba8cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8ccc: cmp             SP, x16
    //     0xba8cd0: b.ls            #0xba8cf0
    // 0xba8cd4: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0xba8cd4: ldr             x16, [PP, #0x4310]  ; [pp+0x4310] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0xba8cd8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xba8cdc: stp             lr, x16, [SP]
    // 0xba8ce0: r0 = Map._fromLiteral()
    //     0xba8ce0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xba8ce4: LeaveFrame
    //     0xba8ce4: mov             SP, fp
    //     0xba8ce8: ldp             fp, lr, [SP], #0x10
    // 0xba8cec: ret
    //     0xba8cec: ret             
    // 0xba8cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba8cf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8cf4: b               #0xba8cd4
  }
}
