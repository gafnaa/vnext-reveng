// lib: , url: package:flutter/src/widgets/basic.dart

// class id: 1049120, size: 0x8
class :: {

  static _ getAxisDirectionFromAxisReverseAndDirectionality(/* No info */) {
    // ** addr: 0xfc4918, size: 0xc4
    // 0xfc4918: EnterFrame
    //     0xfc4918: stp             fp, lr, [SP, #-0x10]!
    //     0xfc491c: mov             fp, SP
    // 0xfc4920: AllocStack(0x8)
    //     0xfc4920: sub             SP, SP, #8
    // 0xfc4924: SetupParameters(dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xfc4924: stur            x3, [fp, #-8]
    // 0xfc4928: CheckStackOverflow
    //     0xfc4928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfc492c: cmp             SP, x16
    //     0xfc4930: b.ls            #0xfc49d4
    // 0xfc4934: LoadField: r0 = r2->field_7
    //     0xfc4934: ldur            x0, [x2, #7]
    // 0xfc4938: cmp             x0, #0
    // 0xfc493c: b.gt            #0xfc49b4
    // 0xfc4940: r0 = of()
    //     0xfc4940: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xfc4944: LoadField: r1 = r0->field_7
    //     0xfc4944: ldur            x1, [x0, #7]
    // 0xfc4948: cmp             x1, #0
    // 0xfc494c: b.gt            #0xfc4958
    // 0xfc4950: r2 = Instance_AxisDirection
    //     0xfc4950: ldr             x2, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xfc4954: b               #0xfc495c
    // 0xfc4958: r2 = Instance_AxisDirection
    //     0xfc4958: ldr             x2, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xfc495c: ldur            x1, [fp, #-8]
    // 0xfc4960: tbnz            w1, #4, #0xfc49a4
    // 0xfc4964: LoadField: r3 = r2->field_7
    //     0xfc4964: ldur            x3, [x2, #7]
    // 0xfc4968: cmp             x3, #1
    // 0xfc496c: b.gt            #0xfc4988
    // 0xfc4970: cmp             x3, #0
    // 0xfc4974: b.gt            #0xfc4980
    // 0xfc4978: r3 = Instance_AxisDirection
    //     0xfc4978: ldr             x3, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xfc497c: b               #0xfc499c
    // 0xfc4980: r3 = Instance_AxisDirection
    //     0xfc4980: ldr             x3, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xfc4984: b               #0xfc499c
    // 0xfc4988: cmp             x3, #2
    // 0xfc498c: b.gt            #0xfc4998
    // 0xfc4990: r3 = Instance_AxisDirection
    //     0xfc4990: ldr             x3, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xfc4994: b               #0xfc499c
    // 0xfc4998: r3 = Instance_AxisDirection
    //     0xfc4998: ldr             x3, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xfc499c: mov             x0, x3
    // 0xfc49a0: b               #0xfc49a8
    // 0xfc49a4: mov             x0, x2
    // 0xfc49a8: LeaveFrame
    //     0xfc49a8: mov             SP, fp
    //     0xfc49ac: ldp             fp, lr, [SP], #0x10
    // 0xfc49b0: ret
    //     0xfc49b0: ret             
    // 0xfc49b4: mov             x1, x3
    // 0xfc49b8: tbnz            w1, #4, #0xfc49c4
    // 0xfc49bc: r0 = Instance_AxisDirection
    //     0xfc49bc: ldr             x0, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xfc49c0: b               #0xfc49c8
    // 0xfc49c4: r0 = Instance_AxisDirection
    //     0xfc49c4: ldr             x0, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xfc49c8: LeaveFrame
    //     0xfc49c8: mov             SP, fp
    //     0xfc49cc: ldp             fp, lr, [SP], #0x10
    // 0xfc49d0: ret
    //     0xfc49d0: ret             
    // 0xfc49d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfc49d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfc49d8: b               #0xfc4934
  }
}

// class id: 4950, size: 0x60, field offset: 0x58
class _RenderColoredBox extends RenderProxyBoxWithHitTestBehavior {

  _ paint(/* No info */) {
    // ** addr: 0xc183e8, size: 0x110
    // 0xc183e8: EnterFrame
    //     0xc183e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc183ec: mov             fp, SP
    // 0xc183f0: AllocStack(0x48)
    //     0xc183f0: sub             SP, SP, #0x48
    // 0xc183f4: SetupParameters(_RenderColoredBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc183f4: mov             x0, x3
    //     0xc183f8: stur            x3, [fp, #-0x18]
    //     0xc183fc: mov             x3, x1
    //     0xc18400: stur            x1, [fp, #-8]
    //     0xc18404: stur            x2, [fp, #-0x10]
    // 0xc18408: CheckStackOverflow
    //     0xc18408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1840c: cmp             SP, x16
    //     0xc18410: b.ls            #0xc184f0
    // 0xc18414: mov             x1, x3
    // 0xc18418: r0 = size()
    //     0xc18418: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1841c: LoadField: d0 = r0->field_7
    //     0xc1841c: ldur            d0, [x0, #7]
    // 0xc18420: r1 = Instance_Size
    //     0xc18420: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xc18424: LoadField: d1 = r1->field_7
    //     0xc18424: ldur            d1, [x1, #7]
    // 0xc18428: fcmp            d0, d1
    // 0xc1842c: b.le            #0xc184c0
    // 0xc18430: LoadField: d0 = r0->field_f
    //     0xc18430: ldur            d0, [x0, #0xf]
    // 0xc18434: LoadField: d1 = r1->field_f
    //     0xc18434: ldur            d1, [x1, #0xf]
    // 0xc18438: fcmp            d0, d1
    // 0xc1843c: b.le            #0xc184c0
    // 0xc18440: ldur            x0, [fp, #-8]
    // 0xc18444: ldur            x1, [fp, #-0x10]
    // 0xc18448: r0 = canvas()
    //     0xc18448: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1844c: ldur            x1, [fp, #-8]
    // 0xc18450: stur            x0, [fp, #-0x20]
    // 0xc18454: r0 = size()
    //     0xc18454: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc18458: ldur            x1, [fp, #-0x18]
    // 0xc1845c: mov             x2, x0
    // 0xc18460: r0 = &()
    //     0xc18460: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc18464: stur            x0, [fp, #-0x28]
    // 0xc18468: r16 = 136
    //     0xc18468: mov             x16, #0x88
    // 0xc1846c: stp             x16, NULL, [SP]
    // 0xc18470: r0 = ByteData()
    //     0xc18470: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc18474: stur            x0, [fp, #-0x30]
    // 0xc18478: r0 = Paint()
    //     0xc18478: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1847c: mov             x3, x0
    // 0xc18480: ldur            x0, [fp, #-0x30]
    // 0xc18484: stur            x3, [fp, #-0x38]
    // 0xc18488: StoreField: r3->field_7 = r0
    //     0xc18488: stur            w0, [x3, #7]
    // 0xc1848c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1848c: ldur            w1, [x0, #0x17]
    // 0xc18490: DecompressPointer r1
    //     0xc18490: add             x1, x1, HEAP, lsl #32
    // 0xc18494: LoadField: r0 = r1->field_7
    //     0xc18494: ldur            x0, [x1, #7]
    // 0xc18498: str             wzr, [x0]
    // 0xc1849c: ldur            x0, [fp, #-8]
    // 0xc184a0: LoadField: r2 = r0->field_57
    //     0xc184a0: ldur            w2, [x0, #0x57]
    // 0xc184a4: DecompressPointer r2
    //     0xc184a4: add             x2, x2, HEAP, lsl #32
    // 0xc184a8: mov             x1, x3
    // 0xc184ac: r0 = color=()
    //     0xc184ac: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc184b0: ldur            x1, [fp, #-0x20]
    // 0xc184b4: ldur            x2, [fp, #-0x28]
    // 0xc184b8: ldur            x3, [fp, #-0x38]
    // 0xc184bc: r0 = drawRect()
    //     0xc184bc: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0xc184c0: ldur            x0, [fp, #-8]
    // 0xc184c4: LoadField: r2 = r0->field_4f
    //     0xc184c4: ldur            w2, [x0, #0x4f]
    // 0xc184c8: DecompressPointer r2
    //     0xc184c8: add             x2, x2, HEAP, lsl #32
    // 0xc184cc: cmp             w2, NULL
    // 0xc184d0: b.eq            #0xc184e0
    // 0xc184d4: ldur            x1, [fp, #-0x10]
    // 0xc184d8: ldur            x3, [fp, #-0x18]
    // 0xc184dc: r0 = paintChild()
    //     0xc184dc: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc184e0: r0 = Null
    //     0xc184e0: mov             x0, NULL
    // 0xc184e4: LeaveFrame
    //     0xc184e4: mov             SP, fp
    //     0xc184e8: ldp             fp, lr, [SP], #0x10
    // 0xc184ec: ret
    //     0xc184ec: ret             
    // 0xc184f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc184f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc184f4: b               #0xc18414
  }
  set _ color=(/* No info */) {
    // ** addr: 0xcf9bd8, size: 0xa4
    // 0xcf9bd8: EnterFrame
    //     0xcf9bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9bdc: mov             fp, SP
    // 0xcf9be0: AllocStack(0x20)
    //     0xcf9be0: sub             SP, SP, #0x20
    // 0xcf9be4: SetupParameters(_RenderColoredBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf9be4: stur            x1, [fp, #-8]
    //     0xcf9be8: mov             x16, x2
    //     0xcf9bec: mov             x2, x1
    //     0xcf9bf0: mov             x1, x16
    //     0xcf9bf4: stur            x1, [fp, #-0x10]
    // 0xcf9bf8: CheckStackOverflow
    //     0xcf9bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9bfc: cmp             SP, x16
    //     0xcf9c00: b.ls            #0xcf9c74
    // 0xcf9c04: LoadField: r0 = r2->field_57
    //     0xcf9c04: ldur            w0, [x2, #0x57]
    // 0xcf9c08: DecompressPointer r0
    //     0xcf9c08: add             x0, x0, HEAP, lsl #32
    // 0xcf9c0c: r3 = LoadClassIdInstr(r1)
    //     0xcf9c0c: ldur            x3, [x1, #-1]
    //     0xcf9c10: ubfx            x3, x3, #0xc, #0x14
    // 0xcf9c14: stp             x0, x1, [SP]
    // 0xcf9c18: mov             x0, x3
    // 0xcf9c1c: mov             lr, x0
    // 0xcf9c20: ldr             lr, [x21, lr, lsl #3]
    // 0xcf9c24: blr             lr
    // 0xcf9c28: tbnz            w0, #4, #0xcf9c3c
    // 0xcf9c2c: r0 = Null
    //     0xcf9c2c: mov             x0, NULL
    // 0xcf9c30: LeaveFrame
    //     0xcf9c30: mov             SP, fp
    //     0xcf9c34: ldp             fp, lr, [SP], #0x10
    // 0xcf9c38: ret
    //     0xcf9c38: ret             
    // 0xcf9c3c: ldur            x1, [fp, #-8]
    // 0xcf9c40: ldur            x0, [fp, #-0x10]
    // 0xcf9c44: StoreField: r1->field_57 = r0
    //     0xcf9c44: stur            w0, [x1, #0x57]
    //     0xcf9c48: ldurb           w16, [x1, #-1]
    //     0xcf9c4c: ldurb           w17, [x0, #-1]
    //     0xcf9c50: and             x16, x17, x16, lsr #2
    //     0xcf9c54: tst             x16, HEAP, lsr #32
    //     0xcf9c58: b.eq            #0xcf9c60
    //     0xcf9c5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf9c60: r0 = markNeedsPaint()
    //     0xcf9c60: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf9c64: r0 = Null
    //     0xcf9c64: mov             x0, NULL
    // 0xcf9c68: LeaveFrame
    //     0xcf9c68: mov             SP, fp
    //     0xcf9c6c: ldp             fp, lr, [SP], #0x10
    // 0xcf9c70: ret
    //     0xcf9c70: ret             
    // 0xcf9c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9c74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9c78: b               #0xcf9c04
  }
}

// class id: 5446, size: 0x14, field offset: 0x14
class _StatefulBuilderState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xe09428, size: 0x84
    // 0xe09428: EnterFrame
    //     0xe09428: stp             fp, lr, [SP, #-0x10]!
    //     0xe0942c: mov             fp, SP
    // 0xe09430: AllocStack(0x28)
    //     0xe09430: sub             SP, SP, #0x28
    // 0xe09434: SetupParameters(_StatefulBuilderState this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xe09434: mov             x0, x2
    //     0xe09438: stur            x2, [fp, #-0x10]
    //     0xe0943c: mov             x2, x1
    // 0xe09440: CheckStackOverflow
    //     0xe09440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe09444: cmp             SP, x16
    //     0xe09448: b.ls            #0xe094a0
    // 0xe0944c: LoadField: r1 = r2->field_b
    //     0xe0944c: ldur            w1, [x2, #0xb]
    // 0xe09450: DecompressPointer r1
    //     0xe09450: add             x1, x1, HEAP, lsl #32
    // 0xe09454: cmp             w1, NULL
    // 0xe09458: b.eq            #0xe094a8
    // 0xe0945c: LoadField: r3 = r1->field_b
    //     0xe0945c: ldur            w3, [x1, #0xb]
    // 0xe09460: DecompressPointer r3
    //     0xe09460: add             x3, x3, HEAP, lsl #32
    // 0xe09464: stur            x3, [fp, #-8]
    // 0xe09468: r1 = Function 'setState':.
    //     0xe09468: add             x1, PP, #0x99, lsl #12  ; [pp+0x99de0] AnonymousClosure: (0x8293f0), in [package:flutter/src/widgets/framework.dart] State::setState (0x82938c)
    //     0xe0946c: ldr             x1, [x1, #0xde0]
    // 0xe09470: r0 = AllocateClosure()
    //     0xe09470: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe09474: ldur            x16, [fp, #-8]
    // 0xe09478: ldur            lr, [fp, #-0x10]
    // 0xe0947c: stp             lr, x16, [SP, #8]
    // 0xe09480: str             x0, [SP]
    // 0xe09484: ldur            x0, [fp, #-8]
    // 0xe09488: ClosureCall
    //     0xe09488: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xe0948c: ldur            x2, [x0, #0x1f]
    //     0xe09490: blr             x2
    // 0xe09494: LeaveFrame
    //     0xe09494: mov             SP, fp
    //     0xe09498: ldp             fp, lr, [SP], #0x10
    // 0xe0949c: ret
    //     0xe0949c: ret             
    // 0xe094a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe094a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe094a4: b               #0xe0944c
    // 0xe094a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe094a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5813, size: 0x4c, field offset: 0x4c
class _IndexedStackElement extends MultiChildRenderObjectElement {

  get _ widget(/* No info */) {
    // ** addr: 0x124b574, size: 0x68
    // 0x124b574: EnterFrame
    //     0x124b574: stp             fp, lr, [SP, #-0x10]!
    //     0x124b578: mov             fp, SP
    // 0x124b57c: AllocStack(0x8)
    //     0x124b57c: sub             SP, SP, #8
    // 0x124b580: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x124b580: ldur            w3, [x1, #0x17]
    // 0x124b584: DecompressPointer r3
    //     0x124b584: add             x3, x3, HEAP, lsl #32
    // 0x124b588: stur            x3, [fp, #-8]
    // 0x124b58c: cmp             w3, NULL
    // 0x124b590: b.eq            #0x124b5d8
    // 0x124b594: mov             x0, x3
    // 0x124b598: r2 = Null
    //     0x124b598: mov             x2, NULL
    // 0x124b59c: r1 = Null
    //     0x124b59c: mov             x1, NULL
    // 0x124b5a0: r4 = LoadClassIdInstr(r0)
    //     0x124b5a0: ldur            x4, [x0, #-1]
    //     0x124b5a4: ubfx            x4, x4, #0xc, #0x14
    // 0x124b5a8: r17 = 6689
    //     0x124b5a8: mov             x17, #0x1a21
    // 0x124b5ac: cmp             x4, x17
    // 0x124b5b0: b.eq            #0x124b5c8
    // 0x124b5b4: r8 = _RawIndexedStack
    //     0x124b5b4: add             x8, PP, #0x99, lsl #12  ; [pp+0x99e28] Type: _RawIndexedStack
    //     0x124b5b8: ldr             x8, [x8, #0xe28]
    // 0x124b5bc: r3 = Null
    //     0x124b5bc: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e30] Null
    //     0x124b5c0: ldr             x3, [x3, #0xe30]
    // 0x124b5c4: r0 = DefaultTypeTest()
    //     0x124b5c4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124b5c8: ldur            x0, [fp, #-8]
    // 0x124b5cc: LeaveFrame
    //     0x124b5cc: mov             SP, fp
    //     0x124b5d0: ldp             fp, lr, [SP], #0x10
    // 0x124b5d4: ret
    //     0x124b5d4: ret             
    // 0x124b5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124b5d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5819, size: 0x48, field offset: 0x48
class _OffstageElement extends SingleChildRenderObjectElement {
}

// class id: 5839, size: 0x44, field offset: 0x44
class _UbiquitousInheritedElement extends InheritedElement {

  _ notifyClients(/* No info */) {
    // ** addr: 0x11b62cc, size: 0x70
    // 0x11b62cc: EnterFrame
    //     0x11b62cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11b62d0: mov             fp, SP
    // 0x11b62d4: AllocStack(0x10)
    //     0x11b62d4: sub             SP, SP, #0x10
    // 0x11b62d8: SetupParameters(_UbiquitousInheritedElement this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11b62d8: stur            x1, [fp, #-8]
    //     0x11b62dc: stur            x2, [fp, #-0x10]
    // 0x11b62e0: CheckStackOverflow
    //     0x11b62e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11b62e4: cmp             SP, x16
    //     0x11b62e8: b.ls            #0x11b6334
    // 0x11b62ec: r1 = 2
    //     0x11b62ec: mov             x1, #2
    // 0x11b62f0: r0 = AllocateContext()
    //     0x11b62f0: bl              #0x13de838  ; AllocateContextStub
    // 0x11b62f4: mov             x1, x0
    // 0x11b62f8: ldur            x0, [fp, #-8]
    // 0x11b62fc: StoreField: r1->field_f = r0
    //     0x11b62fc: stur            w0, [x1, #0xf]
    // 0x11b6300: ldur            x2, [fp, #-0x10]
    // 0x11b6304: StoreField: r1->field_13 = r2
    //     0x11b6304: stur            w2, [x1, #0x13]
    // 0x11b6308: mov             x2, x1
    // 0x11b630c: r1 = Function '<anonymous closure>':.
    //     0x11b630c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99dc0] AnonymousClosure: (0x11b642c), in [package:flutter/src/widgets/basic.dart] _UbiquitousInheritedElement::notifyClients (0x11b62cc)
    //     0x11b6310: ldr             x1, [x1, #0xdc0]
    // 0x11b6314: r0 = AllocateClosure()
    //     0x11b6314: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11b6318: ldur            x1, [fp, #-8]
    // 0x11b631c: mov             x2, x0
    // 0x11b6320: r0 = _recurseChildren()
    //     0x11b6320: bl              #0x11b633c  ; [package:flutter/src/widgets/basic.dart] _UbiquitousInheritedElement::_recurseChildren
    // 0x11b6324: r0 = Null
    //     0x11b6324: mov             x0, NULL
    // 0x11b6328: LeaveFrame
    //     0x11b6328: mov             SP, fp
    //     0x11b632c: ldp             fp, lr, [SP], #0x10
    // 0x11b6330: ret
    //     0x11b6330: ret             
    // 0x11b6334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11b6334: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11b6338: b               #0x11b62ec
  }
  static _ _recurseChildren(/* No info */) {
    // ** addr: 0x11b633c, size: 0xa8
    // 0x11b633c: EnterFrame
    //     0x11b633c: stp             fp, lr, [SP, #-0x10]!
    //     0x11b6340: mov             fp, SP
    // 0x11b6344: AllocStack(0x28)
    //     0x11b6344: sub             SP, SP, #0x28
    // 0x11b6348: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11b6348: stur            x1, [fp, #-8]
    //     0x11b634c: stur            x2, [fp, #-0x10]
    // 0x11b6350: CheckStackOverflow
    //     0x11b6350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11b6354: cmp             SP, x16
    //     0x11b6358: b.ls            #0x11b63dc
    // 0x11b635c: r1 = 1
    //     0x11b635c: mov             x1, #1
    // 0x11b6360: r0 = AllocateContext()
    //     0x11b6360: bl              #0x13de838  ; AllocateContextStub
    // 0x11b6364: mov             x3, x0
    // 0x11b6368: ldur            x0, [fp, #-0x10]
    // 0x11b636c: stur            x3, [fp, #-0x18]
    // 0x11b6370: StoreField: r3->field_f = r0
    //     0x11b6370: stur            w0, [x3, #0xf]
    // 0x11b6374: mov             x2, x3
    // 0x11b6378: r1 = Function '<anonymous closure>': static.
    //     0x11b6378: add             x1, PP, #0x99, lsl #12  ; [pp+0x99dc8] AnonymousClosure: static (0x11b63e4), in [package:flutter/src/widgets/basic.dart] _UbiquitousInheritedElement::_recurseChildren (0x11b633c)
    //     0x11b637c: ldr             x1, [x1, #0xdc8]
    // 0x11b6380: r0 = AllocateClosure()
    //     0x11b6380: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11b6384: ldur            x3, [fp, #-8]
    // 0x11b6388: r1 = LoadClassIdInstr(r3)
    //     0x11b6388: ldur            x1, [x3, #-1]
    //     0x11b638c: ubfx            x1, x1, #0xc, #0x14
    // 0x11b6390: mov             x2, x0
    // 0x11b6394: mov             x0, x1
    // 0x11b6398: mov             x1, x3
    // 0x11b639c: r0 = GDT[cid_x0 + 0xed6]()
    //     0x11b639c: add             lr, x0, #0xed6
    //     0x11b63a0: ldr             lr, [x21, lr, lsl #3]
    //     0x11b63a4: blr             lr
    // 0x11b63a8: ldur            x0, [fp, #-0x18]
    // 0x11b63ac: LoadField: r1 = r0->field_f
    //     0x11b63ac: ldur            w1, [x0, #0xf]
    // 0x11b63b0: DecompressPointer r1
    //     0x11b63b0: add             x1, x1, HEAP, lsl #32
    // 0x11b63b4: ldur            x16, [fp, #-8]
    // 0x11b63b8: stp             x16, x1, [SP]
    // 0x11b63bc: mov             x0, x1
    // 0x11b63c0: ClosureCall
    //     0x11b63c0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x11b63c4: ldur            x2, [x0, #0x1f]
    //     0x11b63c8: blr             x2
    // 0x11b63cc: r0 = Null
    //     0x11b63cc: mov             x0, NULL
    // 0x11b63d0: LeaveFrame
    //     0x11b63d0: mov             SP, fp
    //     0x11b63d4: ldp             fp, lr, [SP], #0x10
    // 0x11b63d8: ret
    //     0x11b63d8: ret             
    // 0x11b63dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11b63dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11b63e0: b               #0x11b635c
  }
  [closure] static void <anonymous closure>(dynamic, Element) {
    // ** addr: 0x11b63e4, size: 0x48
    // 0x11b63e4: EnterFrame
    //     0x11b63e4: stp             fp, lr, [SP, #-0x10]!
    //     0x11b63e8: mov             fp, SP
    // 0x11b63ec: ldr             x0, [fp, #0x18]
    // 0x11b63f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11b63f0: ldur            w1, [x0, #0x17]
    // 0x11b63f4: DecompressPointer r1
    //     0x11b63f4: add             x1, x1, HEAP, lsl #32
    // 0x11b63f8: CheckStackOverflow
    //     0x11b63f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11b63fc: cmp             SP, x16
    //     0x11b6400: b.ls            #0x11b6424
    // 0x11b6404: LoadField: r2 = r1->field_f
    //     0x11b6404: ldur            w2, [x1, #0xf]
    // 0x11b6408: DecompressPointer r2
    //     0x11b6408: add             x2, x2, HEAP, lsl #32
    // 0x11b640c: ldr             x1, [fp, #0x10]
    // 0x11b6410: r0 = _recurseChildren()
    //     0x11b6410: bl              #0x11b633c  ; [package:flutter/src/widgets/basic.dart] _UbiquitousInheritedElement::_recurseChildren
    // 0x11b6414: r0 = Null
    //     0x11b6414: mov             x0, NULL
    // 0x11b6418: LeaveFrame
    //     0x11b6418: mov             SP, fp
    //     0x11b641c: ldp             fp, lr, [SP], #0x10
    // 0x11b6420: ret
    //     0x11b6420: ret             
    // 0x11b6424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11b6424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11b6428: b               #0x11b6404
  }
  [closure] void <anonymous closure>(dynamic, Element) {
    // ** addr: 0x11b642c, size: 0x70
    // 0x11b642c: EnterFrame
    //     0x11b642c: stp             fp, lr, [SP, #-0x10]!
    //     0x11b6430: mov             fp, SP
    // 0x11b6434: AllocStack(0x8)
    //     0x11b6434: sub             SP, SP, #8
    // 0x11b6438: SetupParameters([dynamic _ /* r0 */])
    //     0x11b6438: ldr             x0, [fp, #0x18]
    //     0x11b643c: ldur            w3, [x0, #0x17]
    //     0x11b6440: add             x3, x3, HEAP, lsl #32
    //     0x11b6444: stur            x3, [fp, #-8]
    // 0x11b6448: CheckStackOverflow
    //     0x11b6448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11b644c: cmp             SP, x16
    //     0x11b6450: b.ls            #0x11b6494
    // 0x11b6454: LoadField: r2 = r3->field_f
    //     0x11b6454: ldur            w2, [x3, #0xf]
    // 0x11b6458: DecompressPointer r2
    //     0x11b6458: add             x2, x2, HEAP, lsl #32
    // 0x11b645c: ldr             x1, [fp, #0x10]
    // 0x11b6460: r0 = doesDependOnInheritedElement()
    //     0x11b6460: bl              #0x11b649c  ; [package:flutter/src/widgets/framework.dart] Element::doesDependOnInheritedElement
    // 0x11b6464: tbnz            w0, #4, #0x11b6484
    // 0x11b6468: ldur            x0, [fp, #-8]
    // 0x11b646c: LoadField: r1 = r0->field_f
    //     0x11b646c: ldur            w1, [x0, #0xf]
    // 0x11b6470: DecompressPointer r1
    //     0x11b6470: add             x1, x1, HEAP, lsl #32
    // 0x11b6474: LoadField: r2 = r0->field_13
    //     0x11b6474: ldur            w2, [x0, #0x13]
    // 0x11b6478: DecompressPointer r2
    //     0x11b6478: add             x2, x2, HEAP, lsl #32
    // 0x11b647c: ldr             x3, [fp, #0x10]
    // 0x11b6480: r0 = notifyDependent()
    //     0x11b6480: bl              #0x121a048  ; [package:flutter/src/widgets/framework.dart] InheritedElement::notifyDependent
    // 0x11b6484: r0 = Null
    //     0x11b6484: mov             x0, NULL
    // 0x11b6488: LeaveFrame
    //     0x11b6488: mov             SP, fp
    //     0x11b648c: ldp             fp, lr, [SP], #0x10
    // 0x11b6490: ret
    //     0x11b6490: ret             
    // 0x11b6494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11b6494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11b6498: b               #0x11b6454
  }
}

// class id: 6122, size: 0x10, field offset: 0xc
//   const constructor, 
class Builder extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf624, size: 0x44
    // 0xfbf624: EnterFrame
    //     0xfbf624: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf628: mov             fp, SP
    // 0xfbf62c: AllocStack(0x10)
    //     0xfbf62c: sub             SP, SP, #0x10
    // 0xfbf630: CheckStackOverflow
    //     0xfbf630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf634: cmp             SP, x16
    //     0xfbf638: b.ls            #0xfbf660
    // 0xfbf63c: LoadField: r0 = r1->field_b
    //     0xfbf63c: ldur            w0, [x1, #0xb]
    // 0xfbf640: DecompressPointer r0
    //     0xfbf640: add             x0, x0, HEAP, lsl #32
    // 0xfbf644: stp             x2, x0, [SP]
    // 0xfbf648: ClosureCall
    //     0xfbf648: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfbf64c: ldur            x2, [x0, #0x1f]
    //     0xfbf650: blr             x2
    // 0xfbf654: LeaveFrame
    //     0xfbf654: mov             SP, fp
    //     0xfbf658: ldp             fp, lr, [SP], #0x10
    // 0xfbf65c: ret
    //     0xfbf65c: ret             
    // 0xfbf660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf664: b               #0xfbf63c
  }
}

// class id: 6123, size: 0x10, field offset: 0xc
//   const constructor, 
class KeyedSubtree extends StatelessWidget {

  static _ ensureUniqueKeysForList(/* No info */) {
    // ** addr: 0xef7870, size: 0x258
    // 0xef7870: EnterFrame
    //     0xef7870: stp             fp, lr, [SP, #-0x10]!
    //     0xef7874: mov             fp, SP
    // 0xef7878: AllocStack(0x50)
    //     0xef7878: sub             SP, SP, #0x50
    // 0xef787c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xef787c: mov             x0, x1
    //     0xef7880: stur            x1, [fp, #-8]
    // 0xef7884: CheckStackOverflow
    //     0xef7884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef7888: cmp             SP, x16
    //     0xef788c: b.ls            #0xef7ab8
    // 0xef7890: LoadField: r1 = r0->field_b
    //     0xef7890: ldur            w1, [x0, #0xb]
    // 0xef7894: cbnz            w1, #0xef78a4
    // 0xef7898: LeaveFrame
    //     0xef7898: mov             SP, fp
    //     0xef789c: ldp             fp, lr, [SP], #0x10
    // 0xef78a0: ret
    //     0xef78a0: ret             
    // 0xef78a4: r1 = <Widget>
    //     0xef78a4: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xef78a8: r2 = 0
    //     0xef78a8: mov             x2, #0
    // 0xef78ac: r0 = _GrowableList()
    //     0xef78ac: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xef78b0: mov             x3, x0
    // 0xef78b4: ldur            x0, [fp, #-8]
    // 0xef78b8: stur            x3, [fp, #-0x30]
    // 0xef78bc: LoadField: r4 = r0->field_7
    //     0xef78bc: ldur            w4, [x0, #7]
    // 0xef78c0: DecompressPointer r4
    //     0xef78c0: add             x4, x4, HEAP, lsl #32
    // 0xef78c4: stur            x4, [fp, #-0x28]
    // 0xef78c8: LoadField: r1 = r0->field_b
    //     0xef78c8: ldur            w1, [x0, #0xb]
    // 0xef78cc: r5 = LoadInt32Instr(r1)
    //     0xef78cc: sbfx            x5, x1, #1, #0x1f
    // 0xef78d0: stur            x5, [fp, #-0x20]
    // 0xef78d4: r6 = 0
    //     0xef78d4: mov             x6, #0
    // 0xef78d8: r1 = -1
    //     0xef78d8: mov             x1, #-1
    // 0xef78dc: stur            x6, [fp, #-0x18]
    // 0xef78e0: CheckStackOverflow
    //     0xef78e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef78e4: cmp             SP, x16
    //     0xef78e8: b.ls            #0xef7ac0
    // 0xef78ec: add             x7, x1, #1
    // 0xef78f0: stur            x7, [fp, #-0x10]
    // 0xef78f4: tbnz            x7, #0x3f, #0xef7a78
    // 0xef78f8: LoadField: r1 = r0->field_b
    //     0xef78f8: ldur            w1, [x0, #0xb]
    // 0xef78fc: r2 = LoadInt32Instr(r1)
    //     0xef78fc: sbfx            x2, x1, #1, #0x1f
    // 0xef7900: cmp             x5, x2
    // 0xef7904: b.ne            #0xef7a98
    // 0xef7908: cmp             x6, x2
    // 0xef790c: b.ge            #0xef7a70
    // 0xef7910: mov             x1, x0
    // 0xef7914: mov             x2, x6
    // 0xef7918: r0 = elementAt()
    //     0xef7918: bl              #0xb94a50  ; [dart:core] _GrowableList::elementAt
    // 0xef791c: mov             x3, x0
    // 0xef7920: ldur            x0, [fp, #-0x18]
    // 0xef7924: stur            x3, [fp, #-0x40]
    // 0xef7928: add             x6, x0, #1
    // 0xef792c: ldur            x4, [fp, #-0x10]
    // 0xef7930: stur            x6, [fp, #-0x38]
    // 0xef7934: tbnz            x4, #0x3f, #0xef7a8c
    // 0xef7938: cmp             w3, NULL
    // 0xef793c: b.ne            #0xef7970
    // 0xef7940: mov             x0, x3
    // 0xef7944: ldur            x2, [fp, #-0x28]
    // 0xef7948: r1 = Null
    //     0xef7948: mov             x1, NULL
    // 0xef794c: cmp             w2, NULL
    // 0xef7950: b.eq            #0xef7970
    // 0xef7954: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef7954: ldur            w4, [x2, #0x17]
    // 0xef7958: DecompressPointer r4
    //     0xef7958: add             x4, x4, HEAP, lsl #32
    // 0xef795c: r8 = X0
    //     0xef795c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xef7960: LoadField: r9 = r4->field_7
    //     0xef7960: ldur            x9, [x4, #7]
    // 0xef7964: r3 = Null
    //     0xef7964: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c800] Null
    //     0xef7968: ldr             x3, [x3, #0x800]
    // 0xef796c: blr             x9
    // 0xef7970: ldur            x3, [fp, #-0x10]
    // 0xef7974: ldur            x2, [fp, #-0x40]
    // 0xef7978: r0 = BoxInt64Instr(r3)
    //     0xef7978: sbfiz           x0, x3, #1, #0x1f
    //     0xef797c: cmp             x3, x0, asr #1
    //     0xef7980: b.eq            #0xef798c
    //     0xef7984: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef7988: stur            x3, [x0, #7]
    // 0xef798c: stur            x0, [fp, #-0x48]
    // 0xef7990: r0 = KeyedSubtree()
    //     0xef7990: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xef7994: mov             x2, x0
    // 0xef7998: ldur            x0, [fp, #-0x40]
    // 0xef799c: stur            x2, [fp, #-0x50]
    // 0xef79a0: StoreField: r2->field_b = r0
    //     0xef79a0: stur            w0, [x2, #0xb]
    // 0xef79a4: LoadField: r3 = r0->field_7
    //     0xef79a4: ldur            w3, [x0, #7]
    // 0xef79a8: DecompressPointer r3
    //     0xef79a8: add             x3, x3, HEAP, lsl #32
    // 0xef79ac: cmp             w3, NULL
    // 0xef79b0: b.ne            #0xef79b8
    // 0xef79b4: ldur            x3, [fp, #-0x48]
    // 0xef79b8: ldur            x0, [fp, #-0x30]
    // 0xef79bc: stur            x3, [fp, #-0x40]
    // 0xef79c0: r1 = <Object>
    //     0xef79c0: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0xef79c4: r0 = ValueKey()
    //     0xef79c4: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xef79c8: mov             x1, x0
    // 0xef79cc: ldur            x0, [fp, #-0x40]
    // 0xef79d0: StoreField: r1->field_b = r0
    //     0xef79d0: stur            w0, [x1, #0xb]
    // 0xef79d4: ldur            x0, [fp, #-0x50]
    // 0xef79d8: StoreField: r0->field_7 = r1
    //     0xef79d8: stur            w1, [x0, #7]
    // 0xef79dc: ldur            x2, [fp, #-0x30]
    // 0xef79e0: LoadField: r1 = r2->field_b
    //     0xef79e0: ldur            w1, [x2, #0xb]
    // 0xef79e4: LoadField: r3 = r2->field_f
    //     0xef79e4: ldur            w3, [x2, #0xf]
    // 0xef79e8: DecompressPointer r3
    //     0xef79e8: add             x3, x3, HEAP, lsl #32
    // 0xef79ec: LoadField: r4 = r3->field_b
    //     0xef79ec: ldur            w4, [x3, #0xb]
    // 0xef79f0: r3 = LoadInt32Instr(r1)
    //     0xef79f0: sbfx            x3, x1, #1, #0x1f
    // 0xef79f4: stur            x3, [fp, #-0x18]
    // 0xef79f8: r1 = LoadInt32Instr(r4)
    //     0xef79f8: sbfx            x1, x4, #1, #0x1f
    // 0xef79fc: cmp             x3, x1
    // 0xef7a00: b.ne            #0xef7a0c
    // 0xef7a04: mov             x1, x2
    // 0xef7a08: r0 = _growToNextCapacity()
    //     0xef7a08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xef7a0c: ldur            x2, [fp, #-0x30]
    // 0xef7a10: ldur            x3, [fp, #-0x18]
    // 0xef7a14: add             x0, x3, #1
    // 0xef7a18: lsl             x1, x0, #1
    // 0xef7a1c: StoreField: r2->field_b = r1
    //     0xef7a1c: stur            w1, [x2, #0xb]
    // 0xef7a20: LoadField: r1 = r2->field_f
    //     0xef7a20: ldur            w1, [x2, #0xf]
    // 0xef7a24: DecompressPointer r1
    //     0xef7a24: add             x1, x1, HEAP, lsl #32
    // 0xef7a28: ldur            x0, [fp, #-0x50]
    // 0xef7a2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xef7a2c: add             x25, x1, x3, lsl #2
    //     0xef7a30: add             x25, x25, #0xf
    //     0xef7a34: str             w0, [x25]
    //     0xef7a38: tbz             w0, #0, #0xef7a54
    //     0xef7a3c: ldurb           w16, [x1, #-1]
    //     0xef7a40: ldurb           w17, [x0, #-1]
    //     0xef7a44: and             x16, x17, x16, lsr #2
    //     0xef7a48: tst             x16, HEAP, lsr #32
    //     0xef7a4c: b.eq            #0xef7a54
    //     0xef7a50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xef7a54: ldur            x6, [fp, #-0x38]
    // 0xef7a58: ldur            x1, [fp, #-0x10]
    // 0xef7a5c: ldur            x0, [fp, #-8]
    // 0xef7a60: mov             x3, x2
    // 0xef7a64: ldur            x4, [fp, #-0x28]
    // 0xef7a68: ldur            x5, [fp, #-0x20]
    // 0xef7a6c: b               #0xef78dc
    // 0xef7a70: mov             x2, x3
    // 0xef7a74: b               #0xef7a7c
    // 0xef7a78: mov             x2, x3
    // 0xef7a7c: mov             x0, x2
    // 0xef7a80: LeaveFrame
    //     0xef7a80: mov             SP, fp
    //     0xef7a84: ldp             fp, lr, [SP], #0x10
    // 0xef7a88: ret
    //     0xef7a88: ret             
    // 0xef7a8c: r0 = noElement()
    //     0xef7a8c: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xef7a90: r0 = Throw()
    //     0xef7a90: bl              #0x13ddb2c  ; ThrowStub
    // 0xef7a94: brk             #0
    // 0xef7a98: r0 = ConcurrentModificationError()
    //     0xef7a98: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xef7a9c: mov             x1, x0
    // 0xef7aa0: ldur            x2, [fp, #-8]
    // 0xef7aa4: stur            x0, [fp, #-8]
    // 0xef7aa8: r0 = ConcurrentModificationError()
    //     0xef7aa8: bl              #0xef7b64  ; [dart:core] ConcurrentModificationError::ConcurrentModificationError
    // 0xef7aac: ldur            x0, [fp, #-8]
    // 0xef7ab0: r0 = Throw()
    //     0xef7ab0: bl              #0x13ddb2c  ; ThrowStub
    // 0xef7ab4: brk             #0
    // 0xef7ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7abc: b               #0xef7890
    // 0xef7ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7ac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7ac4: b               #0xef78ec
  }
  _ KeyedSubtree.wrap(/* No info */) {
    // ** addr: 0xef7ac8, size: 0x9c
    // 0xef7ac8: EnterFrame
    //     0xef7ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xef7acc: mov             fp, SP
    // 0xef7ad0: AllocStack(0x10)
    //     0xef7ad0: sub             SP, SP, #0x10
    // 0xef7ad4: SetupParameters(KeyedSubtree this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0 */)
    //     0xef7ad4: mov             x0, x2
    //     0xef7ad8: mov             x4, x1
    //     0xef7adc: stur            x1, [fp, #-0x10]
    // 0xef7ae0: StoreField: r4->field_b = r0
    //     0xef7ae0: stur            w0, [x4, #0xb]
    //     0xef7ae4: ldurb           w16, [x4, #-1]
    //     0xef7ae8: ldurb           w17, [x0, #-1]
    //     0xef7aec: and             x16, x17, x16, lsr #2
    //     0xef7af0: tst             x16, HEAP, lsr #32
    //     0xef7af4: b.eq            #0xef7afc
    //     0xef7af8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xef7afc: LoadField: r0 = r2->field_7
    //     0xef7afc: ldur            w0, [x2, #7]
    // 0xef7b00: DecompressPointer r0
    //     0xef7b00: add             x0, x0, HEAP, lsl #32
    // 0xef7b04: cmp             w0, NULL
    // 0xef7b08: b.ne            #0xef7b20
    // 0xef7b0c: r0 = BoxInt64Instr(r3)
    //     0xef7b0c: sbfiz           x0, x3, #1, #0x1f
    //     0xef7b10: cmp             x3, x0, asr #1
    //     0xef7b14: b.eq            #0xef7b20
    //     0xef7b18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef7b1c: stur            x3, [x0, #7]
    // 0xef7b20: stur            x0, [fp, #-8]
    // 0xef7b24: r1 = <Object>
    //     0xef7b24: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0xef7b28: r0 = ValueKey()
    //     0xef7b28: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xef7b2c: ldur            x1, [fp, #-8]
    // 0xef7b30: StoreField: r0->field_b = r1
    //     0xef7b30: stur            w1, [x0, #0xb]
    // 0xef7b34: ldur            x1, [fp, #-0x10]
    // 0xef7b38: StoreField: r1->field_7 = r0
    //     0xef7b38: stur            w0, [x1, #7]
    //     0xef7b3c: ldurb           w16, [x1, #-1]
    //     0xef7b40: ldurb           w17, [x0, #-1]
    //     0xef7b44: and             x16, x17, x16, lsr #2
    //     0xef7b48: tst             x16, HEAP, lsr #32
    //     0xef7b4c: b.eq            #0xef7b54
    //     0xef7b50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef7b54: r0 = Null
    //     0xef7b54: mov             x0, NULL
    // 0xef7b58: LeaveFrame
    //     0xef7b58: mov             SP, fp
    //     0xef7b5c: ldp             fp, lr, [SP], #0x10
    // 0xef7b60: ret
    //     0xef7b60: ret             
  }
}

// class id: 6124, size: 0x38, field offset: 0xc
//   const constructor, 
class PositionedDirectional extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf560, size: 0xc4
    // 0xfbf560: EnterFrame
    //     0xfbf560: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf564: mov             fp, SP
    // 0xfbf568: AllocStack(0x28)
    //     0xfbf568: sub             SP, SP, #0x28
    // 0xfbf56c: SetupParameters(PositionedDirectional this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfbf56c: mov             x0, x1
    //     0xfbf570: stur            x1, [fp, #-8]
    //     0xfbf574: mov             x1, x2
    // 0xfbf578: CheckStackOverflow
    //     0xfbf578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf57c: cmp             SP, x16
    //     0xfbf580: b.ls            #0xfbf604
    // 0xfbf584: r0 = of()
    //     0xfbf584: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xfbf588: mov             x1, x0
    // 0xfbf58c: ldur            x0, [fp, #-8]
    // 0xfbf590: LoadField: d0 = r0->field_27
    //     0xfbf590: ldur            d0, [x0, #0x27]
    // 0xfbf594: LoadField: r2 = r0->field_33
    //     0xfbf594: ldur            w2, [x0, #0x33]
    // 0xfbf598: DecompressPointer r2
    //     0xfbf598: add             x2, x2, HEAP, lsl #32
    // 0xfbf59c: r0 = inline_Allocate_Double()
    //     0xfbf59c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xfbf5a0: add             x0, x0, #0x10
    //     0xfbf5a4: cmp             x3, x0
    //     0xfbf5a8: b.ls            #0xfbf60c
    //     0xfbf5ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xfbf5b0: sub             x0, x0, #0xf
    //     0xfbf5b4: mov             x3, #0xe19c
    //     0xfbf5b8: movk            x3, #3, lsl #16
    //     0xfbf5bc: stur            x3, [x0, #-1]
    // 0xfbf5c0: dmb             ishst
    // 0xfbf5c4: StoreField: r0->field_7 = d0
    //     0xfbf5c4: stur            d0, [x0, #7]
    // 0xfbf5c8: r16 = 0.000000
    //     0xfbf5c8: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfbf5cc: stp             NULL, x16, [SP, #0x10]
    // 0xfbf5d0: r16 = 0.000000
    //     0xfbf5d0: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfbf5d4: stp             x0, x16, [SP]
    // 0xfbf5d8: mov             x5, x1
    // 0xfbf5dc: r1 = <StackParentData>
    //     0xfbf5dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xfbf5e0: ldr             x1, [x1, #0x858]
    // 0xfbf5e4: r3 = Null
    //     0xfbf5e4: mov             x3, NULL
    // 0xfbf5e8: d0 = 0.000000
    //     0xfbf5e8: eor             v0.16b, v0.16b, v0.16b
    // 0xfbf5ec: r4 = const [0, 0x9, 0x4, 0x5, bottom, 0x7, end, 0x6, start, 0x5, width, 0x8, null]
    //     0xfbf5ec: add             x4, PP, #0xcd, lsl #12  ; [pp+0xcd860] List(13) [0, 0x9, 0x4, 0x5, "bottom", 0x7, "end", 0x6, "start", 0x5, "width", 0x8, Null]
    //     0xfbf5f0: ldr             x4, [x4, #0x860]
    // 0xfbf5f4: r0 = Positioned.directional()
    //     0xfbf5f4: bl              #0xebbd48  ; [package:flutter/src/widgets/basic.dart] Positioned::Positioned.directional
    // 0xfbf5f8: LeaveFrame
    //     0xfbf5f8: mov             SP, fp
    //     0xfbf5fc: ldp             fp, lr, [SP], #0x10
    // 0xfbf600: ret
    //     0xfbf600: ret             
    // 0xfbf604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf608: b               #0xfbf584
    // 0xfbf60c: SaveReg d0
    //     0xfbf60c: str             q0, [SP, #-0x10]!
    // 0xfbf610: stp             x1, x2, [SP, #-0x10]!
    // 0xfbf614: r0 = AllocateDouble()
    //     0xfbf614: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfbf618: ldp             x1, x2, [SP], #0x10
    // 0xfbf61c: RestoreReg d0
    //     0xfbf61c: ldr             q0, [SP], #0x10
    // 0xfbf620: b               #0xfbf5c4
  }
}

// class id: 6125, size: 0x24, field offset: 0xc
//   const constructor, 
class IndexedStack extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf374, size: 0x1e0
    // 0xfbf374: EnterFrame
    //     0xfbf374: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf378: mov             fp, SP
    // 0xfbf37c: AllocStack(0x50)
    //     0xfbf37c: sub             SP, SP, #0x50
    // 0xfbf380: SetupParameters(IndexedStack this /* r1 => r0, fp-0x10 */)
    //     0xfbf380: mov             x0, x1
    //     0xfbf384: stur            x1, [fp, #-0x10]
    // 0xfbf388: CheckStackOverflow
    //     0xfbf388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf38c: cmp             SP, x16
    //     0xfbf390: b.ls            #0xfbf540
    // 0xfbf394: LoadField: r3 = r0->field_1f
    //     0xfbf394: ldur            w3, [x0, #0x1f]
    // 0xfbf398: DecompressPointer r3
    //     0xfbf398: add             x3, x3, HEAP, lsl #32
    // 0xfbf39c: stur            x3, [fp, #-8]
    // 0xfbf3a0: LoadField: r1 = r3->field_b
    //     0xfbf3a0: ldur            w1, [x3, #0xb]
    // 0xfbf3a4: r2 = LoadInt32Instr(r1)
    //     0xfbf3a4: sbfx            x2, x1, #1, #0x1f
    // 0xfbf3a8: r1 = <Widget>
    //     0xfbf3a8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfbf3ac: r0 = _GrowableList()
    //     0xfbf3ac: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfbf3b0: mov             x2, x0
    // 0xfbf3b4: stur            x2, [fp, #-0x50]
    // 0xfbf3b8: LoadField: r0 = r2->field_b
    //     0xfbf3b8: ldur            w0, [x2, #0xb]
    // 0xfbf3bc: r3 = LoadInt32Instr(r0)
    //     0xfbf3bc: sbfx            x3, x0, #1, #0x1f
    // 0xfbf3c0: ldur            x4, [fp, #-0x10]
    // 0xfbf3c4: stur            x3, [fp, #-0x48]
    // 0xfbf3c8: LoadField: r5 = r4->field_1b
    //     0xfbf3c8: ldur            w5, [x4, #0x1b]
    // 0xfbf3cc: DecompressPointer r5
    //     0xfbf3cc: add             x5, x5, HEAP, lsl #32
    // 0xfbf3d0: ldur            x0, [fp, #-8]
    // 0xfbf3d4: stur            x5, [fp, #-0x40]
    // 0xfbf3d8: LoadField: r1 = r0->field_b
    //     0xfbf3d8: ldur            w1, [x0, #0xb]
    // 0xfbf3dc: r6 = LoadInt32Instr(r1)
    //     0xfbf3dc: sbfx            x6, x1, #1, #0x1f
    // 0xfbf3e0: stur            x6, [fp, #-0x38]
    // 0xfbf3e4: LoadField: r7 = r0->field_f
    //     0xfbf3e4: ldur            w7, [x0, #0xf]
    // 0xfbf3e8: DecompressPointer r7
    //     0xfbf3e8: add             x7, x7, HEAP, lsl #32
    // 0xfbf3ec: stur            x7, [fp, #-0x30]
    // 0xfbf3f0: LoadField: r8 = r2->field_f
    //     0xfbf3f0: ldur            w8, [x2, #0xf]
    // 0xfbf3f4: DecompressPointer r8
    //     0xfbf3f4: add             x8, x8, HEAP, lsl #32
    // 0xfbf3f8: stur            x8, [fp, #-0x28]
    // 0xfbf3fc: r9 = 0
    //     0xfbf3fc: mov             x9, #0
    // 0xfbf400: stur            x9, [fp, #-0x20]
    // 0xfbf404: CheckStackOverflow
    //     0xfbf404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf408: cmp             SP, x16
    //     0xfbf40c: b.ls            #0xfbf548
    // 0xfbf410: cmp             x9, x3
    // 0xfbf414: b.ge            #0xfbf4e8
    // 0xfbf418: lsl             x0, x9, #1
    // 0xfbf41c: cmp             w0, w5
    // 0xfbf420: r16 = true
    //     0xfbf420: add             x16, NULL, #0x20  ; true
    // 0xfbf424: r17 = false
    //     0xfbf424: add             x17, NULL, #0x30  ; false
    // 0xfbf428: csel            x10, x16, x17, eq
    // 0xfbf42c: mov             x0, x6
    // 0xfbf430: mov             x1, x9
    // 0xfbf434: stur            x10, [fp, #-0x18]
    // 0xfbf438: cmp             x1, x0
    // 0xfbf43c: b.hs            #0xfbf550
    // 0xfbf440: ArrayLoad: r0 = r7[r9]  ; Unknown_4
    //     0xfbf440: add             x16, x7, x9, lsl #2
    //     0xfbf444: ldur            w0, [x16, #0xf]
    // 0xfbf448: DecompressPointer r0
    //     0xfbf448: add             x0, x0, HEAP, lsl #32
    // 0xfbf44c: stur            x0, [fp, #-8]
    // 0xfbf450: r0 = Visibility()
    //     0xfbf450: bl              #0xd59568  ; AllocateVisibilityStub -> Visibility (size=0x30)
    // 0xfbf454: mov             x1, x0
    // 0xfbf458: ldur            x0, [fp, #-8]
    // 0xfbf45c: StoreField: r1->field_b = r0
    //     0xfbf45c: stur            w0, [x1, #0xb]
    // 0xfbf460: r2 = Instance_SizedBox
    //     0xfbf460: ldr             x2, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xfbf464: StoreField: r1->field_f = r2
    //     0xfbf464: stur            w2, [x1, #0xf]
    // 0xfbf468: ldur            x0, [fp, #-0x18]
    // 0xfbf46c: StoreField: r1->field_13 = r0
    //     0xfbf46c: stur            w0, [x1, #0x13]
    // 0xfbf470: r3 = true
    //     0xfbf470: add             x3, NULL, #0x20  ; true
    // 0xfbf474: ArrayStore: r1[0] = r3  ; List_4
    //     0xfbf474: stur            w3, [x1, #0x17]
    // 0xfbf478: StoreField: r1->field_1b = r3
    //     0xfbf478: stur            w3, [x1, #0x1b]
    // 0xfbf47c: StoreField: r1->field_1f = r3
    //     0xfbf47c: stur            w3, [x1, #0x1f]
    // 0xfbf480: r4 = false
    //     0xfbf480: add             x4, NULL, #0x30  ; false
    // 0xfbf484: StoreField: r1->field_23 = r4
    //     0xfbf484: stur            w4, [x1, #0x23]
    // 0xfbf488: StoreField: r1->field_27 = r3
    //     0xfbf488: stur            w3, [x1, #0x27]
    // 0xfbf48c: StoreField: r1->field_2b = r4
    //     0xfbf48c: stur            w4, [x1, #0x2b]
    // 0xfbf490: mov             x0, x1
    // 0xfbf494: ldur            x1, [fp, #-0x28]
    // 0xfbf498: ldur            x5, [fp, #-0x20]
    // 0xfbf49c: ArrayStore: r1[r5] = r0  ; List_4
    //     0xfbf49c: add             x25, x1, x5, lsl #2
    //     0xfbf4a0: add             x25, x25, #0xf
    //     0xfbf4a4: str             w0, [x25]
    //     0xfbf4a8: tbz             w0, #0, #0xfbf4c4
    //     0xfbf4ac: ldurb           w16, [x1, #-1]
    //     0xfbf4b0: ldurb           w17, [x0, #-1]
    //     0xfbf4b4: and             x16, x17, x16, lsr #2
    //     0xfbf4b8: tst             x16, HEAP, lsr #32
    //     0xfbf4bc: b.eq            #0xfbf4c4
    //     0xfbf4c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfbf4c4: add             x9, x5, #1
    // 0xfbf4c8: ldur            x4, [fp, #-0x10]
    // 0xfbf4cc: ldur            x2, [fp, #-0x50]
    // 0xfbf4d0: ldur            x8, [fp, #-0x28]
    // 0xfbf4d4: ldur            x5, [fp, #-0x40]
    // 0xfbf4d8: ldur            x7, [fp, #-0x30]
    // 0xfbf4dc: ldur            x3, [fp, #-0x48]
    // 0xfbf4e0: ldur            x6, [fp, #-0x38]
    // 0xfbf4e4: b               #0xfbf400
    // 0xfbf4e8: mov             x1, x4
    // 0xfbf4ec: mov             x0, x2
    // 0xfbf4f0: mov             x2, x5
    // 0xfbf4f4: LoadField: r3 = r1->field_b
    //     0xfbf4f4: ldur            w3, [x1, #0xb]
    // 0xfbf4f8: DecompressPointer r3
    //     0xfbf4f8: add             x3, x3, HEAP, lsl #32
    // 0xfbf4fc: stur            x3, [fp, #-8]
    // 0xfbf500: r0 = _RawIndexedStack()
    //     0xfbf500: bl              #0xfbf554  ; Allocate_RawIndexedStackStub -> _RawIndexedStack (size=0x24)
    // 0xfbf504: ldur            x1, [fp, #-0x40]
    // 0xfbf508: StoreField: r0->field_1f = r1
    //     0xfbf508: stur            w1, [x0, #0x1f]
    // 0xfbf50c: ldur            x1, [fp, #-8]
    // 0xfbf510: StoreField: r0->field_f = r1
    //     0xfbf510: stur            w1, [x0, #0xf]
    // 0xfbf514: r1 = Instance_StackFit
    //     0xfbf514: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xfbf518: ldr             x1, [x1, #0x8e0]
    // 0xfbf51c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbf51c: stur            w1, [x0, #0x17]
    // 0xfbf520: r1 = Instance_Clip
    //     0xfbf520: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfbf524: ldr             x1, [x1, #0x850]
    // 0xfbf528: StoreField: r0->field_1b = r1
    //     0xfbf528: stur            w1, [x0, #0x1b]
    // 0xfbf52c: ldur            x1, [fp, #-0x50]
    // 0xfbf530: StoreField: r0->field_b = r1
    //     0xfbf530: stur            w1, [x0, #0xb]
    // 0xfbf534: LeaveFrame
    //     0xfbf534: mov             SP, fp
    //     0xfbf538: ldp             fp, lr, [SP], #0x10
    // 0xfbf53c: ret
    //     0xfbf53c: ret             
    // 0xfbf540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf540: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf544: b               #0xfbf394
    // 0xfbf548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf54c: b               #0xfbf410
    // 0xfbf550: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfbf550: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 6126, size: 0x20, field offset: 0xc
//   const constructor, 
class UnconstrainedBox extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf308, size: 0x54
    // 0xfbf308: EnterFrame
    //     0xfbf308: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf30c: mov             fp, SP
    // 0xfbf310: AllocStack(0x8)
    //     0xfbf310: sub             SP, SP, #8
    // 0xfbf314: LoadField: r0 = r1->field_1b
    //     0xfbf314: ldur            w0, [x1, #0x1b]
    // 0xfbf318: DecompressPointer r0
    //     0xfbf318: add             x0, x0, HEAP, lsl #32
    // 0xfbf31c: stur            x0, [fp, #-8]
    // 0xfbf320: r0 = ConstraintsTransformBox()
    //     0xfbf320: bl              #0xfbf35c  ; AllocateConstraintsTransformBoxStub -> ConstraintsTransformBox (size=0x20)
    // 0xfbf324: r1 = Instance_Alignment
    //     0xfbf324: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfbf328: ldr             x1, [x1, #0xb80]
    // 0xfbf32c: StoreField: r0->field_13 = r1
    //     0xfbf32c: stur            w1, [x0, #0x13]
    // 0xfbf330: r1 = Closure: (BoxConstraints) => BoxConstraints from Function 'unconstrained': static.
    //     0xfbf330: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4b98] Closure: (BoxConstraints) => BoxConstraints from Function 'unconstrained': static. (0x7f2adaea6368)
    //     0xfbf334: ldr             x1, [x1, #0xb98]
    // 0xfbf338: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbf338: stur            w1, [x0, #0x17]
    // 0xfbf33c: r1 = Instance_Clip
    //     0xfbf33c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbf340: ldr             x1, [x1, #0x840]
    // 0xfbf344: StoreField: r0->field_1b = r1
    //     0xfbf344: stur            w1, [x0, #0x1b]
    // 0xfbf348: ldur            x1, [fp, #-8]
    // 0xfbf34c: StoreField: r0->field_b = r1
    //     0xfbf34c: stur            w1, [x0, #0xb]
    // 0xfbf350: LeaveFrame
    //     0xfbf350: mov             SP, fp
    //     0xfbf354: ldp             fp, lr, [SP], #0x10
    // 0xfbf358: ret
    //     0xfbf358: ret             
  }
}

// class id: 6399, size: 0x10, field offset: 0xc
//   const constructor, 
class StatefulBuilder extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa394c, size: 0x24
    // 0xfa394c: EnterFrame
    //     0xfa394c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3950: mov             fp, SP
    // 0xfa3954: mov             x0, x1
    // 0xfa3958: r1 = <StatefulBuilder>
    //     0xfa3958: add             x1, PP, #0x90, lsl #12  ; [pp+0x902b0] TypeArguments: <StatefulBuilder>
    //     0xfa395c: ldr             x1, [x1, #0x2b0]
    // 0xfa3960: r0 = _StatefulBuilderState()
    //     0xfa3960: bl              #0xfa3970  ; Allocate_StatefulBuilderStateStub -> _StatefulBuilderState (size=0x14)
    // 0xfa3964: LeaveFrame
    //     0xfa3964: mov             SP, fp
    //     0xfa3968: ldp             fp, lr, [SP], #0x10
    // 0xfa396c: ret
    //     0xfa396c: ret             
  }
}

// class id: 6598, size: 0x18, field offset: 0x10
//   const constructor, 
class ColoredBox extends SingleChildRenderObjectWidget {

  Color field_10;
  bool field_14;

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9b48, size: 0x90
    // 0xcf9b48: EnterFrame
    //     0xcf9b48: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9b4c: mov             fp, SP
    // 0xcf9b50: AllocStack(0x10)
    //     0xcf9b50: sub             SP, SP, #0x10
    // 0xcf9b54: SetupParameters(ColoredBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf9b54: mov             x4, x1
    //     0xcf9b58: stur            x1, [fp, #-8]
    //     0xcf9b5c: stur            x3, [fp, #-0x10]
    // 0xcf9b60: CheckStackOverflow
    //     0xcf9b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9b64: cmp             SP, x16
    //     0xcf9b68: b.ls            #0xcf9bd0
    // 0xcf9b6c: mov             x0, x3
    // 0xcf9b70: r2 = Null
    //     0xcf9b70: mov             x2, NULL
    // 0xcf9b74: r1 = Null
    //     0xcf9b74: mov             x1, NULL
    // 0xcf9b78: r4 = LoadClassIdInstr(r0)
    //     0xcf9b78: ldur            x4, [x0, #-1]
    //     0xcf9b7c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9b80: r17 = 4950
    //     0xcf9b80: mov             x17, #0x1356
    // 0xcf9b84: cmp             x4, x17
    // 0xcf9b88: b.eq            #0xcf9ba0
    // 0xcf9b8c: r8 = _RenderColoredBox
    //     0xcf9b8c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85110] Type: _RenderColoredBox
    //     0xcf9b90: ldr             x8, [x8, #0x110]
    // 0xcf9b94: r3 = Null
    //     0xcf9b94: add             x3, PP, #0x85, lsl #12  ; [pp+0x85118] Null
    //     0xcf9b98: ldr             x3, [x3, #0x118]
    // 0xcf9b9c: r0 = DefaultTypeTest()
    //     0xcf9b9c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9ba0: ldur            x0, [fp, #-8]
    // 0xcf9ba4: LoadField: r2 = r0->field_f
    //     0xcf9ba4: ldur            w2, [x0, #0xf]
    // 0xcf9ba8: DecompressPointer r2
    //     0xcf9ba8: add             x2, x2, HEAP, lsl #32
    // 0xcf9bac: ldur            x1, [fp, #-0x10]
    // 0xcf9bb0: r0 = color=()
    //     0xcf9bb0: bl              #0xcf9bd8  ; [package:flutter/src/widgets/basic.dart] _RenderColoredBox::color=
    // 0xcf9bb4: ldur            x1, [fp, #-0x10]
    // 0xcf9bb8: r2 = true
    //     0xcf9bb8: add             x2, NULL, #0x20  ; true
    // 0xcf9bbc: r0 = Shader._()
    //     0xcf9bbc: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf9bc0: r0 = Null
    //     0xcf9bc0: mov             x0, NULL
    // 0xcf9bc4: LeaveFrame
    //     0xcf9bc4: mov             SP, fp
    //     0xcf9bc8: ldp             fp, lr, [SP], #0x10
    // 0xcf9bcc: ret
    //     0xcf9bcc: ret             
    // 0xcf9bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9bd4: b               #0xcf9b6c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2ae8, size: 0x74
    // 0x11d2ae8: EnterFrame
    //     0x11d2ae8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2aec: mov             fp, SP
    // 0x11d2af0: AllocStack(0x18)
    //     0x11d2af0: sub             SP, SP, #0x18
    // 0x11d2af4: CheckStackOverflow
    //     0x11d2af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2af8: cmp             SP, x16
    //     0x11d2afc: b.ls            #0x11d2b54
    // 0x11d2b00: LoadField: r0 = r1->field_f
    //     0x11d2b00: ldur            w0, [x1, #0xf]
    // 0x11d2b04: DecompressPointer r0
    //     0x11d2b04: add             x0, x0, HEAP, lsl #32
    // 0x11d2b08: stur            x0, [fp, #-8]
    // 0x11d2b0c: r0 = _RenderColoredBox()
    //     0x11d2b0c: bl              #0x11d2b5c  ; Allocate_RenderColoredBoxStub -> _RenderColoredBox (size=0x60)
    // 0x11d2b10: mov             x2, x0
    // 0x11d2b14: ldur            x0, [fp, #-8]
    // 0x11d2b18: stur            x2, [fp, #-0x10]
    // 0x11d2b1c: StoreField: r2->field_57 = r0
    //     0x11d2b1c: stur            w0, [x2, #0x57]
    // 0x11d2b20: r0 = true
    //     0x11d2b20: add             x0, NULL, #0x20  ; true
    // 0x11d2b24: StoreField: r2->field_5b = r0
    //     0x11d2b24: stur            w0, [x2, #0x5b]
    // 0x11d2b28: r16 = Instance_HitTestBehavior
    //     0x11d2b28: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0x11d2b2c: ldr             x16, [x16, #0x5c0]
    // 0x11d2b30: str             x16, [SP]
    // 0x11d2b34: mov             x1, x2
    // 0x11d2b38: r4 = const [0, 0x2, 0x1, 0x1, behavior, 0x1, null]
    //     0x11d2b38: add             x4, PP, #0x12, lsl #12  ; [pp+0x123b8] List(7) [0, 0x2, 0x1, 0x1, "behavior", 0x1, Null]
    //     0x11d2b3c: ldr             x4, [x4, #0x3b8]
    // 0x11d2b40: r0 = RenderProxyBoxWithHitTestBehavior()
    //     0x11d2b40: bl              #0x11d2340  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::RenderProxyBoxWithHitTestBehavior
    // 0x11d2b44: ldur            x0, [fp, #-0x10]
    // 0x11d2b48: LeaveFrame
    //     0x11d2b48: mov             SP, fp
    //     0x11d2b4c: ldp             fp, lr, [SP], #0x10
    // 0x11d2b50: ret
    //     0x11d2b50: ret             
    // 0x11d2b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2b58: b               #0x11d2b00
  }
}

// class id: 6599, size: 0x18, field offset: 0x10
//   const constructor, 
class IndexedSemantics extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9a70, size: 0x88
    // 0xcf9a70: EnterFrame
    //     0xcf9a70: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9a74: mov             fp, SP
    // 0xcf9a78: AllocStack(0x10)
    //     0xcf9a78: sub             SP, SP, #0x10
    // 0xcf9a7c: SetupParameters(IndexedSemantics this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf9a7c: mov             x4, x1
    //     0xcf9a80: stur            x1, [fp, #-8]
    //     0xcf9a84: stur            x3, [fp, #-0x10]
    // 0xcf9a88: CheckStackOverflow
    //     0xcf9a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9a8c: cmp             SP, x16
    //     0xcf9a90: b.ls            #0xcf9af0
    // 0xcf9a94: mov             x0, x3
    // 0xcf9a98: r2 = Null
    //     0xcf9a98: mov             x2, NULL
    // 0xcf9a9c: r1 = Null
    //     0xcf9a9c: mov             x1, NULL
    // 0xcf9aa0: r4 = 60
    //     0xcf9aa0: mov             x4, #0x3c
    // 0xcf9aa4: branchIfSmi(r0, 0xcf9ab0)
    //     0xcf9aa4: tbz             w0, #0, #0xcf9ab0
    // 0xcf9aa8: r4 = LoadClassIdInstr(r0)
    //     0xcf9aa8: ldur            x4, [x0, #-1]
    //     0xcf9aac: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9ab0: r17 = 4917
    //     0xcf9ab0: mov             x17, #0x1335
    // 0xcf9ab4: cmp             x4, x17
    // 0xcf9ab8: b.eq            #0xcf9ad0
    // 0xcf9abc: r8 = RenderIndexedSemantics
    //     0xcf9abc: add             x8, PP, #0xad, lsl #12  ; [pp+0xadeb0] Type: RenderIndexedSemantics
    //     0xcf9ac0: ldr             x8, [x8, #0xeb0]
    // 0xcf9ac4: r3 = Null
    //     0xcf9ac4: add             x3, PP, #0xad, lsl #12  ; [pp+0xadeb8] Null
    //     0xcf9ac8: ldr             x3, [x3, #0xeb8]
    // 0xcf9acc: r0 = DefaultTypeTest()
    //     0xcf9acc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9ad0: ldur            x0, [fp, #-8]
    // 0xcf9ad4: LoadField: r2 = r0->field_f
    //     0xcf9ad4: ldur            x2, [x0, #0xf]
    // 0xcf9ad8: ldur            x1, [fp, #-0x10]
    // 0xcf9adc: r0 = index=()
    //     0xcf9adc: bl              #0xcf9af8  ; [package:flutter/src/rendering/proxy_box.dart] RenderIndexedSemantics::index=
    // 0xcf9ae0: r0 = Null
    //     0xcf9ae0: mov             x0, NULL
    // 0xcf9ae4: LeaveFrame
    //     0xcf9ae4: mov             SP, fp
    //     0xcf9ae8: ldp             fp, lr, [SP], #0x10
    // 0xcf9aec: ret
    //     0xcf9aec: ret             
    // 0xcf9af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9af0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9af4: b               #0xcf9a94
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2a20, size: 0x4c
    // 0x11d2a20: EnterFrame
    //     0x11d2a20: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2a24: mov             fp, SP
    // 0x11d2a28: AllocStack(0x10)
    //     0x11d2a28: sub             SP, SP, #0x10
    // 0x11d2a2c: CheckStackOverflow
    //     0x11d2a2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2a30: cmp             SP, x16
    //     0x11d2a34: b.ls            #0x11d2a64
    // 0x11d2a38: LoadField: r2 = r1->field_f
    //     0x11d2a38: ldur            x2, [x1, #0xf]
    // 0x11d2a3c: stur            x2, [fp, #-8]
    // 0x11d2a40: r0 = RenderIndexedSemantics()
    //     0x11d2a40: bl              #0x11d2adc  ; AllocateRenderIndexedSemanticsStub -> RenderIndexedSemantics (size=0x5c)
    // 0x11d2a44: mov             x1, x0
    // 0x11d2a48: ldur            x2, [fp, #-8]
    // 0x11d2a4c: stur            x0, [fp, #-0x10]
    // 0x11d2a50: r0 = RenderIndexedSemantics()
    //     0x11d2a50: bl              #0x11d2a6c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIndexedSemantics::RenderIndexedSemantics
    // 0x11d2a54: ldur            x0, [fp, #-0x10]
    // 0x11d2a58: LeaveFrame
    //     0x11d2a58: mov             SP, fp
    //     0x11d2a5c: ldp             fp, lr, [SP], #0x10
    // 0x11d2a60: ret
    //     0x11d2a60: ret             
    // 0x11d2a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2a64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2a68: b               #0x11d2a38
  }
}

// class id: 6600, size: 0x14, field offset: 0x10
//   const constructor, 
class ExcludeSemantics extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf99e4, size: 0x8c
    // 0xcf99e4: EnterFrame
    //     0xcf99e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf99e8: mov             fp, SP
    // 0xcf99ec: AllocStack(0x10)
    //     0xcf99ec: sub             SP, SP, #0x10
    // 0xcf99f0: SetupParameters(ExcludeSemantics this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf99f0: mov             x4, x1
    //     0xcf99f4: stur            x1, [fp, #-8]
    //     0xcf99f8: stur            x3, [fp, #-0x10]
    // 0xcf99fc: CheckStackOverflow
    //     0xcf99fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9a00: cmp             SP, x16
    //     0xcf9a04: b.ls            #0xcf9a68
    // 0xcf9a08: mov             x0, x3
    // 0xcf9a0c: r2 = Null
    //     0xcf9a0c: mov             x2, NULL
    // 0xcf9a10: r1 = Null
    //     0xcf9a10: mov             x1, NULL
    // 0xcf9a14: r4 = 60
    //     0xcf9a14: mov             x4, #0x3c
    // 0xcf9a18: branchIfSmi(r0, 0xcf9a24)
    //     0xcf9a18: tbz             w0, #0, #0xcf9a24
    // 0xcf9a1c: r4 = LoadClassIdInstr(r0)
    //     0xcf9a1c: ldur            x4, [x0, #-1]
    //     0xcf9a20: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9a24: r17 = 4918
    //     0xcf9a24: mov             x17, #0x1336
    // 0xcf9a28: cmp             x4, x17
    // 0xcf9a2c: b.eq            #0xcf9a44
    // 0xcf9a30: r8 = RenderExcludeSemantics
    //     0xcf9a30: add             x8, PP, #0x12, lsl #12  ; [pp+0x124e8] Type: RenderExcludeSemantics
    //     0xcf9a34: ldr             x8, [x8, #0x4e8]
    // 0xcf9a38: r3 = Null
    //     0xcf9a38: add             x3, PP, #0x12, lsl #12  ; [pp+0x124f0] Null
    //     0xcf9a3c: ldr             x3, [x3, #0x4f0]
    // 0xcf9a40: r0 = DefaultTypeTest()
    //     0xcf9a40: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9a44: ldur            x0, [fp, #-8]
    // 0xcf9a48: LoadField: r2 = r0->field_f
    //     0xcf9a48: ldur            w2, [x0, #0xf]
    // 0xcf9a4c: DecompressPointer r2
    //     0xcf9a4c: add             x2, x2, HEAP, lsl #32
    // 0xcf9a50: ldur            x1, [fp, #-0x10]
    // 0xcf9a54: r0 = ignoring=()
    //     0xcf9a54: bl              #0x86fb34  ; [package:flutter/src/rendering/proxy_box.dart] RenderIgnorePointer::ignoring=
    // 0xcf9a58: r0 = Null
    //     0xcf9a58: mov             x0, NULL
    // 0xcf9a5c: LeaveFrame
    //     0xcf9a5c: mov             SP, fp
    //     0xcf9a60: ldp             fp, lr, [SP], #0x10
    // 0xcf9a64: ret
    //     0xcf9a64: ret             
    // 0xcf9a68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9a68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9a6c: b               #0xcf9a08
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d29c4, size: 0x50
    // 0x11d29c4: EnterFrame
    //     0x11d29c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d29c8: mov             fp, SP
    // 0x11d29cc: AllocStack(0x8)
    //     0x11d29cc: sub             SP, SP, #8
    // 0x11d29d0: CheckStackOverflow
    //     0x11d29d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d29d4: cmp             SP, x16
    //     0x11d29d8: b.ls            #0x11d2a0c
    // 0x11d29dc: LoadField: r2 = r1->field_f
    //     0x11d29dc: ldur            w2, [x1, #0xf]
    // 0x11d29e0: DecompressPointer r2
    //     0x11d29e0: add             x2, x2, HEAP, lsl #32
    // 0x11d29e4: stur            x2, [fp, #-8]
    // 0x11d29e8: r0 = RenderExcludeSemantics()
    //     0x11d29e8: bl              #0x11d2a14  ; AllocateRenderExcludeSemanticsStub -> RenderExcludeSemantics (size=0x58)
    // 0x11d29ec: mov             x1, x0
    // 0x11d29f0: ldur            x2, [fp, #-8]
    // 0x11d29f4: stur            x0, [fp, #-8]
    // 0x11d29f8: r0 = RenderAbsorbPointer()
    //     0x11d29f8: bl              #0x11d1c80  ; [package:flutter/src/rendering/proxy_box.dart] RenderAbsorbPointer::RenderAbsorbPointer
    // 0x11d29fc: ldur            x0, [fp, #-8]
    // 0x11d2a00: LeaveFrame
    //     0x11d2a00: mov             SP, fp
    //     0x11d2a04: ldp             fp, lr, [SP], #0x10
    // 0x11d2a08: ret
    //     0x11d2a08: ret             
    // 0x11d2a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2a0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2a10: b               #0x11d29dc
  }
}

// class id: 6601, size: 0x14, field offset: 0x10
//   const constructor, 
class BlockSemantics extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9968, size: 0x7c
    // 0xcf9968: EnterFrame
    //     0xcf9968: stp             fp, lr, [SP, #-0x10]!
    //     0xcf996c: mov             fp, SP
    // 0xcf9970: AllocStack(0x8)
    //     0xcf9970: sub             SP, SP, #8
    // 0xcf9974: SetupParameters(dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xcf9974: stur            x3, [fp, #-8]
    // 0xcf9978: CheckStackOverflow
    //     0xcf9978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf997c: cmp             SP, x16
    //     0xcf9980: b.ls            #0xcf99dc
    // 0xcf9984: mov             x0, x3
    // 0xcf9988: r2 = Null
    //     0xcf9988: mov             x2, NULL
    // 0xcf998c: r1 = Null
    //     0xcf998c: mov             x1, NULL
    // 0xcf9990: r4 = 60
    //     0xcf9990: mov             x4, #0x3c
    // 0xcf9994: branchIfSmi(r0, 0xcf99a0)
    //     0xcf9994: tbz             w0, #0, #0xcf99a0
    // 0xcf9998: r4 = LoadClassIdInstr(r0)
    //     0xcf9998: ldur            x4, [x0, #-1]
    //     0xcf999c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf99a0: r17 = 4920
    //     0xcf99a0: mov             x17, #0x1338
    // 0xcf99a4: cmp             x4, x17
    // 0xcf99a8: b.eq            #0xcf99c0
    // 0xcf99ac: r8 = RenderBlockSemantics
    //     0xcf99ac: add             x8, PP, #0x85, lsl #12  ; [pp+0x85128] Type: RenderBlockSemantics
    //     0xcf99b0: ldr             x8, [x8, #0x128]
    // 0xcf99b4: r3 = Null
    //     0xcf99b4: add             x3, PP, #0x85, lsl #12  ; [pp+0x85130] Null
    //     0xcf99b8: ldr             x3, [x3, #0x130]
    // 0xcf99bc: r0 = DefaultTypeTest()
    //     0xcf99bc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf99c0: ldur            x1, [fp, #-8]
    // 0xcf99c4: r2 = true
    //     0xcf99c4: add             x2, NULL, #0x20  ; true
    // 0xcf99c8: r0 = Shader._()
    //     0xcf99c8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf99cc: r0 = Null
    //     0xcf99cc: mov             x0, NULL
    // 0xcf99d0: LeaveFrame
    //     0xcf99d0: mov             SP, fp
    //     0xcf99d4: ldp             fp, lr, [SP], #0x10
    // 0xcf99d8: ret
    //     0xcf99d8: ret             
    // 0xcf99dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf99dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf99e0: b               #0xcf9984
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2904, size: 0x40
    // 0x11d2904: EnterFrame
    //     0x11d2904: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2908: mov             fp, SP
    // 0x11d290c: AllocStack(0x8)
    //     0x11d290c: sub             SP, SP, #8
    // 0x11d2910: CheckStackOverflow
    //     0x11d2910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2914: cmp             SP, x16
    //     0x11d2918: b.ls            #0x11d293c
    // 0x11d291c: r0 = RenderBlockSemantics()
    //     0x11d291c: bl              #0x11d29b8  ; AllocateRenderBlockSemanticsStub -> RenderBlockSemantics (size=0x58)
    // 0x11d2920: mov             x1, x0
    // 0x11d2924: stur            x0, [fp, #-8]
    // 0x11d2928: r0 = _MixinApplication245&RenderProxyBox&_RenderTheaterMixin&RenderObjectWithLayoutCallbackMixin()
    //     0x11d2928: bl              #0x11d2944  ; [dart:mixin_deduplication] _MixinApplication245&RenderProxyBox&_RenderTheaterMixin&RenderObjectWithLayoutCallbackMixin::_MixinApplication245&RenderProxyBox&_RenderTheaterMixin&RenderObjectWithLayoutCallbackMixin
    // 0x11d292c: ldur            x0, [fp, #-8]
    // 0x11d2930: LeaveFrame
    //     0x11d2930: mov             SP, fp
    //     0x11d2934: ldp             fp, lr, [SP], #0x10
    // 0x11d2938: ret
    //     0x11d2938: ret             
    // 0x11d293c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d293c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2940: b               #0x11d291c
  }
}

// class id: 6602, size: 0x10, field offset: 0x10
//   const constructor, 
class MergeSemantics extends SingleChildRenderObjectWidget {

  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d289c, size: 0x5c
    // 0x11d289c: EnterFrame
    //     0x11d289c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d28a0: mov             fp, SP
    // 0x11d28a4: AllocStack(0x8)
    //     0x11d28a4: sub             SP, SP, #8
    // 0x11d28a8: CheckStackOverflow
    //     0x11d28a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d28ac: cmp             SP, x16
    //     0x11d28b0: b.ls            #0x11d28f0
    // 0x11d28b4: r0 = RenderMergeSemantics()
    //     0x11d28b4: bl              #0x11d28f8  ; AllocateRenderMergeSemanticsStub -> RenderMergeSemantics (size=0x54)
    // 0x11d28b8: stur            x0, [fp, #-8]
    // 0x11d28bc: r0 = _LayoutCacheStorage()
    //     0x11d28bc: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d28c0: mov             x1, x0
    // 0x11d28c4: ldur            x0, [fp, #-8]
    // 0x11d28c8: StoreField: r0->field_47 = r1
    //     0x11d28c8: stur            w1, [x0, #0x47]
    // 0x11d28cc: mov             x1, x0
    // 0x11d28d0: r0 = RenderObject()
    //     0x11d28d0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d28d4: ldur            x1, [fp, #-8]
    // 0x11d28d8: r2 = Null
    //     0x11d28d8: mov             x2, NULL
    // 0x11d28dc: r0 = child=()
    //     0x11d28dc: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d28e0: ldur            x0, [fp, #-8]
    // 0x11d28e4: LeaveFrame
    //     0x11d28e4: mov             SP, fp
    //     0x11d28e8: ldp             fp, lr, [SP], #0x10
    // 0x11d28ec: ret
    //     0x11d28ec: ret             
    // 0x11d28f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d28f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d28f4: b               #0x11d28b4
  }
}

// class id: 6603, size: 0x18, field offset: 0x10
//   const constructor, 
class MetaData extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf98ac, size: 0xbc
    // 0xcf98ac: EnterFrame
    //     0xcf98ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcf98b0: mov             fp, SP
    // 0xcf98b4: AllocStack(0x10)
    //     0xcf98b4: sub             SP, SP, #0x10
    // 0xcf98b8: SetupParameters(MetaData this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xcf98b8: mov             x0, x3
    //     0xcf98bc: mov             x5, x1
    //     0xcf98c0: mov             x4, x2
    //     0xcf98c4: stur            x1, [fp, #-8]
    //     0xcf98c8: stur            x3, [fp, #-0x10]
    // 0xcf98cc: r2 = Null
    //     0xcf98cc: mov             x2, NULL
    // 0xcf98d0: r1 = Null
    //     0xcf98d0: mov             x1, NULL
    // 0xcf98d4: r4 = 60
    //     0xcf98d4: mov             x4, #0x3c
    // 0xcf98d8: branchIfSmi(r0, 0xcf98e4)
    //     0xcf98d8: tbz             w0, #0, #0xcf98e4
    // 0xcf98dc: r4 = LoadClassIdInstr(r0)
    //     0xcf98dc: ldur            x4, [x0, #-1]
    //     0xcf98e0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf98e4: r17 = 4952
    //     0xcf98e4: mov             x17, #0x1358
    // 0xcf98e8: cmp             x4, x17
    // 0xcf98ec: b.eq            #0xcf9904
    // 0xcf98f0: r8 = RenderMetaData
    //     0xcf98f0: add             x8, PP, #0x84, lsl #12  ; [pp+0x84cf0] Type: RenderMetaData
    //     0xcf98f4: ldr             x8, [x8, #0xcf0]
    // 0xcf98f8: r3 = Null
    //     0xcf98f8: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd850] Null
    //     0xcf98fc: ldr             x3, [x3, #0x850]
    // 0xcf9900: r0 = DefaultTypeTest()
    //     0xcf9900: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9904: ldur            x1, [fp, #-8]
    // 0xcf9908: LoadField: r0 = r1->field_f
    //     0xcf9908: ldur            w0, [x1, #0xf]
    // 0xcf990c: DecompressPointer r0
    //     0xcf990c: add             x0, x0, HEAP, lsl #32
    // 0xcf9910: ldur            x2, [fp, #-0x10]
    // 0xcf9914: StoreField: r2->field_57 = r0
    //     0xcf9914: stur            w0, [x2, #0x57]
    //     0xcf9918: tbz             w0, #0, #0xcf9934
    //     0xcf991c: ldurb           w16, [x2, #-1]
    //     0xcf9920: ldurb           w17, [x0, #-1]
    //     0xcf9924: and             x16, x17, x16, lsr #2
    //     0xcf9928: tst             x16, HEAP, lsr #32
    //     0xcf992c: b.eq            #0xcf9934
    //     0xcf9930: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf9934: LoadField: r0 = r1->field_13
    //     0xcf9934: ldur            w0, [x1, #0x13]
    // 0xcf9938: DecompressPointer r0
    //     0xcf9938: add             x0, x0, HEAP, lsl #32
    // 0xcf993c: StoreField: r2->field_53 = r0
    //     0xcf993c: stur            w0, [x2, #0x53]
    //     0xcf9940: ldurb           w16, [x2, #-1]
    //     0xcf9944: ldurb           w17, [x0, #-1]
    //     0xcf9948: and             x16, x17, x16, lsr #2
    //     0xcf994c: tst             x16, HEAP, lsr #32
    //     0xcf9950: b.eq            #0xcf9958
    //     0xcf9954: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf9958: r0 = Null
    //     0xcf9958: mov             x0, NULL
    // 0xcf995c: LeaveFrame
    //     0xcf995c: mov             SP, fp
    //     0xcf9960: ldp             fp, lr, [SP], #0x10
    // 0xcf9964: ret
    //     0xcf9964: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d281c, size: 0x74
    // 0x11d281c: EnterFrame
    //     0x11d281c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2820: mov             fp, SP
    // 0x11d2824: AllocStack(0x20)
    //     0x11d2824: sub             SP, SP, #0x20
    // 0x11d2828: CheckStackOverflow
    //     0x11d2828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d282c: cmp             SP, x16
    //     0x11d2830: b.ls            #0x11d2888
    // 0x11d2834: LoadField: r0 = r1->field_f
    //     0x11d2834: ldur            w0, [x1, #0xf]
    // 0x11d2838: DecompressPointer r0
    //     0x11d2838: add             x0, x0, HEAP, lsl #32
    // 0x11d283c: stur            x0, [fp, #-0x10]
    // 0x11d2840: LoadField: r2 = r1->field_13
    //     0x11d2840: ldur            w2, [x1, #0x13]
    // 0x11d2844: DecompressPointer r2
    //     0x11d2844: add             x2, x2, HEAP, lsl #32
    // 0x11d2848: stur            x2, [fp, #-8]
    // 0x11d284c: r0 = RenderMetaData()
    //     0x11d284c: bl              #0x11d2890  ; AllocateRenderMetaDataStub -> RenderMetaData (size=0x5c)
    // 0x11d2850: mov             x2, x0
    // 0x11d2854: ldur            x0, [fp, #-0x10]
    // 0x11d2858: stur            x2, [fp, #-0x18]
    // 0x11d285c: StoreField: r2->field_57 = r0
    //     0x11d285c: stur            w0, [x2, #0x57]
    // 0x11d2860: ldur            x16, [fp, #-8]
    // 0x11d2864: str             x16, [SP]
    // 0x11d2868: mov             x1, x2
    // 0x11d286c: r4 = const [0, 0x2, 0x1, 0x1, behavior, 0x1, null]
    //     0x11d286c: add             x4, PP, #0x12, lsl #12  ; [pp+0x123b8] List(7) [0, 0x2, 0x1, 0x1, "behavior", 0x1, Null]
    //     0x11d2870: ldr             x4, [x4, #0x3b8]
    // 0x11d2874: r0 = RenderProxyBoxWithHitTestBehavior()
    //     0x11d2874: bl              #0x11d2340  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::RenderProxyBoxWithHitTestBehavior
    // 0x11d2878: ldur            x0, [fp, #-0x18]
    // 0x11d287c: LeaveFrame
    //     0x11d287c: mov             SP, fp
    //     0x11d2880: ldp             fp, lr, [SP], #0x10
    // 0x11d2884: ret
    //     0x11d2884: ret             
    // 0x11d2888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d288c: b               #0x11d2834
  }
}

// class id: 6604, size: 0x18, field offset: 0x10
//   const constructor, 
class AbsorbPointer extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf97fc, size: 0xb0
    // 0xcf97fc: EnterFrame
    //     0xcf97fc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9800: mov             fp, SP
    // 0xcf9804: AllocStack(0x10)
    //     0xcf9804: sub             SP, SP, #0x10
    // 0xcf9808: SetupParameters(AbsorbPointer this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf9808: mov             x4, x1
    //     0xcf980c: stur            x1, [fp, #-8]
    //     0xcf9810: stur            x3, [fp, #-0x10]
    // 0xcf9814: CheckStackOverflow
    //     0xcf9814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9818: cmp             SP, x16
    //     0xcf981c: b.ls            #0xcf98a4
    // 0xcf9820: mov             x0, x3
    // 0xcf9824: r2 = Null
    //     0xcf9824: mov             x2, NULL
    // 0xcf9828: r1 = Null
    //     0xcf9828: mov             x1, NULL
    // 0xcf982c: r4 = 60
    //     0xcf982c: mov             x4, #0x3c
    // 0xcf9830: branchIfSmi(r0, 0xcf983c)
    //     0xcf9830: tbz             w0, #0, #0xcf983c
    // 0xcf9834: r4 = LoadClassIdInstr(r0)
    //     0xcf9834: ldur            x4, [x0, #-1]
    //     0xcf9838: ubfx            x4, x4, #0xc, #0x14
    // 0xcf983c: r17 = 4921
    //     0xcf983c: mov             x17, #0x1339
    // 0xcf9840: cmp             x4, x17
    // 0xcf9844: b.eq            #0xcf985c
    // 0xcf9848: r8 = RenderAbsorbPointer
    //     0xcf9848: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3f08] Type: RenderAbsorbPointer
    //     0xcf984c: ldr             x8, [x8, #0xf08]
    // 0xcf9850: r3 = Null
    //     0xcf9850: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3f10] Null
    //     0xcf9854: ldr             x3, [x3, #0xf10]
    // 0xcf9858: r0 = DefaultTypeTest()
    //     0xcf9858: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf985c: ldur            x0, [fp, #-8]
    // 0xcf9860: LoadField: r1 = r0->field_f
    //     0xcf9860: ldur            w1, [x0, #0xf]
    // 0xcf9864: DecompressPointer r1
    //     0xcf9864: add             x1, x1, HEAP, lsl #32
    // 0xcf9868: ldur            x0, [fp, #-0x10]
    // 0xcf986c: LoadField: r2 = r0->field_53
    //     0xcf986c: ldur            w2, [x0, #0x53]
    // 0xcf9870: DecompressPointer r2
    //     0xcf9870: add             x2, x2, HEAP, lsl #32
    // 0xcf9874: cmp             w2, w1
    // 0xcf9878: b.eq            #0xcf9888
    // 0xcf987c: StoreField: r0->field_53 = r1
    //     0xcf987c: stur            w1, [x0, #0x53]
    // 0xcf9880: mov             x1, x0
    // 0xcf9884: r0 = markNeedsSemanticsUpdate()
    //     0xcf9884: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf9888: ldur            x1, [fp, #-0x10]
    // 0xcf988c: r2 = Null
    //     0xcf988c: mov             x2, NULL
    // 0xcf9890: r0 = Shader._()
    //     0xcf9890: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf9894: r0 = Null
    //     0xcf9894: mov             x0, NULL
    // 0xcf9898: LeaveFrame
    //     0xcf9898: mov             SP, fp
    //     0xcf989c: ldp             fp, lr, [SP], #0x10
    // 0xcf98a0: ret
    //     0xcf98a0: ret             
    // 0xcf98a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf98a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf98a8: b               #0xcf9820
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d27c0, size: 0x50
    // 0x11d27c0: EnterFrame
    //     0x11d27c0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d27c4: mov             fp, SP
    // 0x11d27c8: AllocStack(0x8)
    //     0x11d27c8: sub             SP, SP, #8
    // 0x11d27cc: CheckStackOverflow
    //     0x11d27cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d27d0: cmp             SP, x16
    //     0x11d27d4: b.ls            #0x11d2808
    // 0x11d27d8: LoadField: r2 = r1->field_f
    //     0x11d27d8: ldur            w2, [x1, #0xf]
    // 0x11d27dc: DecompressPointer r2
    //     0x11d27dc: add             x2, x2, HEAP, lsl #32
    // 0x11d27e0: stur            x2, [fp, #-8]
    // 0x11d27e4: r0 = RenderAbsorbPointer()
    //     0x11d27e4: bl              #0x11d2810  ; AllocateRenderAbsorbPointerStub -> RenderAbsorbPointer (size=0x5c)
    // 0x11d27e8: mov             x1, x0
    // 0x11d27ec: ldur            x2, [fp, #-8]
    // 0x11d27f0: stur            x0, [fp, #-8]
    // 0x11d27f4: r0 = RenderAbsorbPointer()
    //     0x11d27f4: bl              #0x11d1c80  ; [package:flutter/src/rendering/proxy_box.dart] RenderAbsorbPointer::RenderAbsorbPointer
    // 0x11d27f8: ldur            x0, [fp, #-8]
    // 0x11d27fc: LeaveFrame
    //     0x11d27fc: mov             SP, fp
    //     0x11d2800: ldp             fp, lr, [SP], #0x10
    // 0x11d2804: ret
    //     0x11d2804: ret             
    // 0x11d2808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2808: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d280c: b               #0x11d27d8
  }
}

// class id: 6605, size: 0x18, field offset: 0x10
//   const constructor, 
class IgnorePointer extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9750, size: 0xac
    // 0xcf9750: EnterFrame
    //     0xcf9750: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9754: mov             fp, SP
    // 0xcf9758: AllocStack(0x10)
    //     0xcf9758: sub             SP, SP, #0x10
    // 0xcf975c: SetupParameters(IgnorePointer this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf975c: mov             x4, x1
    //     0xcf9760: stur            x1, [fp, #-8]
    //     0xcf9764: stur            x3, [fp, #-0x10]
    // 0xcf9768: CheckStackOverflow
    //     0xcf9768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf976c: cmp             SP, x16
    //     0xcf9770: b.ls            #0xcf97f4
    // 0xcf9774: mov             x0, x3
    // 0xcf9778: r2 = Null
    //     0xcf9778: mov             x2, NULL
    // 0xcf977c: r1 = Null
    //     0xcf977c: mov             x1, NULL
    // 0xcf9780: r4 = 60
    //     0xcf9780: mov             x4, #0x3c
    // 0xcf9784: branchIfSmi(r0, 0xcf9790)
    //     0xcf9784: tbz             w0, #0, #0xcf9790
    // 0xcf9788: r4 = LoadClassIdInstr(r0)
    //     0xcf9788: ldur            x4, [x0, #-1]
    //     0xcf978c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9790: r17 = 4923
    //     0xcf9790: mov             x17, #0x133b
    // 0xcf9794: cmp             x4, x17
    // 0xcf9798: b.eq            #0xcf97ac
    // 0xcf979c: r8 = RenderIgnorePointer
    //     0xcf979c: ldr             x8, [PP, #0x5580]  ; [pp+0x5580] Type: RenderIgnorePointer
    // 0xcf97a0: r3 = Null
    //     0xcf97a0: add             x3, PP, #0x85, lsl #12  ; [pp+0x85060] Null
    //     0xcf97a4: ldr             x3, [x3, #0x60]
    // 0xcf97a8: r0 = DefaultTypeTest()
    //     0xcf97a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf97ac: ldur            x0, [fp, #-8]
    // 0xcf97b0: LoadField: r1 = r0->field_f
    //     0xcf97b0: ldur            w1, [x0, #0xf]
    // 0xcf97b4: DecompressPointer r1
    //     0xcf97b4: add             x1, x1, HEAP, lsl #32
    // 0xcf97b8: ldur            x0, [fp, #-0x10]
    // 0xcf97bc: LoadField: r2 = r0->field_53
    //     0xcf97bc: ldur            w2, [x0, #0x53]
    // 0xcf97c0: DecompressPointer r2
    //     0xcf97c0: add             x2, x2, HEAP, lsl #32
    // 0xcf97c4: cmp             w1, w2
    // 0xcf97c8: b.eq            #0xcf97d8
    // 0xcf97cc: StoreField: r0->field_53 = r1
    //     0xcf97cc: stur            w1, [x0, #0x53]
    // 0xcf97d0: mov             x1, x0
    // 0xcf97d4: r0 = markNeedsSemanticsUpdate()
    //     0xcf97d4: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf97d8: ldur            x1, [fp, #-0x10]
    // 0xcf97dc: r2 = Null
    //     0xcf97dc: mov             x2, NULL
    // 0xcf97e0: r0 = Shader._()
    //     0xcf97e0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf97e4: r0 = Null
    //     0xcf97e4: mov             x0, NULL
    // 0xcf97e8: LeaveFrame
    //     0xcf97e8: mov             SP, fp
    //     0xcf97ec: ldp             fp, lr, [SP], #0x10
    // 0xcf97f0: ret
    //     0xcf97f0: ret             
    // 0xcf97f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf97f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf97f8: b               #0xcf9774
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2764, size: 0x50
    // 0x11d2764: EnterFrame
    //     0x11d2764: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2768: mov             fp, SP
    // 0x11d276c: AllocStack(0x8)
    //     0x11d276c: sub             SP, SP, #8
    // 0x11d2770: CheckStackOverflow
    //     0x11d2770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2774: cmp             SP, x16
    //     0x11d2778: b.ls            #0x11d27ac
    // 0x11d277c: LoadField: r2 = r1->field_f
    //     0x11d277c: ldur            w2, [x1, #0xf]
    // 0x11d2780: DecompressPointer r2
    //     0x11d2780: add             x2, x2, HEAP, lsl #32
    // 0x11d2784: stur            x2, [fp, #-8]
    // 0x11d2788: r0 = RenderIgnorePointer()
    //     0x11d2788: bl              #0x11d27b4  ; AllocateRenderIgnorePointerStub -> RenderIgnorePointer (size=0x5c)
    // 0x11d278c: mov             x1, x0
    // 0x11d2790: ldur            x2, [fp, #-8]
    // 0x11d2794: stur            x0, [fp, #-8]
    // 0x11d2798: r0 = RenderAbsorbPointer()
    //     0x11d2798: bl              #0x11d1c80  ; [package:flutter/src/rendering/proxy_box.dart] RenderAbsorbPointer::RenderAbsorbPointer
    // 0x11d279c: ldur            x0, [fp, #-8]
    // 0x11d27a0: LeaveFrame
    //     0x11d27a0: mov             SP, fp
    //     0x11d27a4: ldp             fp, lr, [SP], #0x10
    // 0x11d27a8: ret
    //     0x11d27a8: ret             
    // 0x11d27ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d27ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d27b0: b               #0x11d277c
  }
}

// class id: 6606, size: 0x10, field offset: 0x10
//   const constructor, 
class RepaintBoundary extends SingleChildRenderObjectWidget {

  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d26fc, size: 0x5c
    // 0x11d26fc: EnterFrame
    //     0x11d26fc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2700: mov             fp, SP
    // 0x11d2704: AllocStack(0x8)
    //     0x11d2704: sub             SP, SP, #8
    // 0x11d2708: CheckStackOverflow
    //     0x11d2708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d270c: cmp             SP, x16
    //     0x11d2710: b.ls            #0x11d2750
    // 0x11d2714: r0 = RenderRepaintBoundary()
    //     0x11d2714: bl              #0x11d2758  ; AllocateRenderRepaintBoundaryStub -> RenderRepaintBoundary (size=0x54)
    // 0x11d2718: stur            x0, [fp, #-8]
    // 0x11d271c: r0 = _LayoutCacheStorage()
    //     0x11d271c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d2720: mov             x1, x0
    // 0x11d2724: ldur            x0, [fp, #-8]
    // 0x11d2728: StoreField: r0->field_47 = r1
    //     0x11d2728: stur            w1, [x0, #0x47]
    // 0x11d272c: mov             x1, x0
    // 0x11d2730: r0 = RenderObject()
    //     0x11d2730: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d2734: ldur            x1, [fp, #-8]
    // 0x11d2738: r2 = Null
    //     0x11d2738: mov             x2, NULL
    // 0x11d273c: r0 = child=()
    //     0x11d273c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d2740: ldur            x0, [fp, #-8]
    // 0x11d2744: LeaveFrame
    //     0x11d2744: mov             SP, fp
    //     0x11d2748: ldp             fp, lr, [SP], #0x10
    // 0x11d274c: ret
    //     0x11d274c: ret             
    // 0x11d2750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2750: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2754: b               #0x11d2714
  }
}

// class id: 6607, size: 0x28, field offset: 0x10
//   const constructor, 
class MouseRegion extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9550, size: 0x118
    // 0xcf9550: EnterFrame
    //     0xcf9550: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9554: mov             fp, SP
    // 0xcf9558: AllocStack(0x10)
    //     0xcf9558: sub             SP, SP, #0x10
    // 0xcf955c: SetupParameters(MouseRegion this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf955c: mov             x4, x1
    //     0xcf9560: stur            x1, [fp, #-8]
    //     0xcf9564: stur            x3, [fp, #-0x10]
    // 0xcf9568: CheckStackOverflow
    //     0xcf9568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf956c: cmp             SP, x16
    //     0xcf9570: b.ls            #0xcf9660
    // 0xcf9574: mov             x0, x3
    // 0xcf9578: r2 = Null
    //     0xcf9578: mov             x2, NULL
    // 0xcf957c: r1 = Null
    //     0xcf957c: mov             x1, NULL
    // 0xcf9580: r4 = 60
    //     0xcf9580: mov             x4, #0x3c
    // 0xcf9584: branchIfSmi(r0, 0xcf9590)
    //     0xcf9584: tbz             w0, #0, #0xcf9590
    // 0xcf9588: r4 = LoadClassIdInstr(r0)
    //     0xcf9588: ldur            x4, [x0, #-1]
    //     0xcf958c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9590: r17 = -4953
    //     0xcf9590: mov             x17, #-0x1359
    // 0xcf9594: add             x4, x4, x17
    // 0xcf9598: cmp             x4, #1
    // 0xcf959c: b.ls            #0xcf95b4
    // 0xcf95a0: r8 = RenderMouseRegion
    //     0xcf95a0: add             x8, PP, #0x85, lsl #12  ; [pp+0x85140] Type: RenderMouseRegion
    //     0xcf95a4: ldr             x8, [x8, #0x140]
    // 0xcf95a8: r3 = Null
    //     0xcf95a8: add             x3, PP, #0x85, lsl #12  ; [pp+0x85148] Null
    //     0xcf95ac: ldr             x3, [x3, #0x148]
    // 0xcf95b0: r0 = DefaultTypeTest()
    //     0xcf95b0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf95b4: ldur            x1, [fp, #-8]
    // 0xcf95b8: LoadField: r0 = r1->field_f
    //     0xcf95b8: ldur            w0, [x1, #0xf]
    // 0xcf95bc: DecompressPointer r0
    //     0xcf95bc: add             x0, x0, HEAP, lsl #32
    // 0xcf95c0: ldur            x3, [fp, #-0x10]
    // 0xcf95c4: StoreField: r3->field_5b = r0
    //     0xcf95c4: stur            w0, [x3, #0x5b]
    //     0xcf95c8: ldurb           w16, [x3, #-1]
    //     0xcf95cc: ldurb           w17, [x0, #-1]
    //     0xcf95d0: and             x16, x17, x16, lsr #2
    //     0xcf95d4: tst             x16, HEAP, lsr #32
    //     0xcf95d8: b.eq            #0xcf95e0
    //     0xcf95dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf95e0: LoadField: r0 = r1->field_13
    //     0xcf95e0: ldur            w0, [x1, #0x13]
    // 0xcf95e4: DecompressPointer r0
    //     0xcf95e4: add             x0, x0, HEAP, lsl #32
    // 0xcf95e8: StoreField: r3->field_5f = r0
    //     0xcf95e8: stur            w0, [x3, #0x5f]
    //     0xcf95ec: ldurb           w16, [x3, #-1]
    //     0xcf95f0: ldurb           w17, [x0, #-1]
    //     0xcf95f4: and             x16, x17, x16, lsr #2
    //     0xcf95f8: tst             x16, HEAP, lsr #32
    //     0xcf95fc: b.eq            #0xcf9604
    //     0xcf9600: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf9604: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xcf9604: ldur            w0, [x1, #0x17]
    // 0xcf9608: DecompressPointer r0
    //     0xcf9608: add             x0, x0, HEAP, lsl #32
    // 0xcf960c: StoreField: r3->field_63 = r0
    //     0xcf960c: stur            w0, [x3, #0x63]
    //     0xcf9610: ldurb           w16, [x3, #-1]
    //     0xcf9614: ldurb           w17, [x0, #-1]
    //     0xcf9618: and             x16, x17, x16, lsr #2
    //     0xcf961c: tst             x16, HEAP, lsr #32
    //     0xcf9620: b.eq            #0xcf9628
    //     0xcf9624: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf9628: LoadField: r2 = r1->field_1b
    //     0xcf9628: ldur            w2, [x1, #0x1b]
    // 0xcf962c: DecompressPointer r2
    //     0xcf962c: add             x2, x2, HEAP, lsl #32
    // 0xcf9630: mov             x1, x3
    // 0xcf9634: r0 = cursor=()
    //     0xcf9634: bl              #0xcf96bc  ; [package:flutter/src/rendering/proxy_box.dart] RenderMouseRegion::cursor=
    // 0xcf9638: ldur            x1, [fp, #-0x10]
    // 0xcf963c: r2 = true
    //     0xcf963c: add             x2, NULL, #0x20  ; true
    // 0xcf9640: r0 = Shader._()
    //     0xcf9640: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf9644: ldur            x1, [fp, #-0x10]
    // 0xcf9648: r2 = Null
    //     0xcf9648: mov             x2, NULL
    // 0xcf964c: r0 = hitTestBehavior=()
    //     0xcf964c: bl              #0xcf9668  ; [package:flutter/src/rendering/proxy_box.dart] RenderMouseRegion::hitTestBehavior=
    // 0xcf9650: r0 = Null
    //     0xcf9650: mov             x0, NULL
    // 0xcf9654: LeaveFrame
    //     0xcf9654: mov             SP, fp
    //     0xcf9658: ldp             fp, lr, [SP], #0x10
    // 0xcf965c: ret
    //     0xcf965c: ret             
    // 0xcf9660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9664: b               #0xcf9574
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2660, size: 0x90
    // 0x11d2660: EnterFrame
    //     0x11d2660: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2664: mov             fp, SP
    // 0x11d2668: AllocStack(0x40)
    //     0x11d2668: sub             SP, SP, #0x40
    // 0x11d266c: CheckStackOverflow
    //     0x11d266c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2670: cmp             SP, x16
    //     0x11d2674: b.ls            #0x11d26e8
    // 0x11d2678: LoadField: r2 = r1->field_f
    //     0x11d2678: ldur            w2, [x1, #0xf]
    // 0x11d267c: DecompressPointer r2
    //     0x11d267c: add             x2, x2, HEAP, lsl #32
    // 0x11d2680: stur            x2, [fp, #-0x20]
    // 0x11d2684: LoadField: r0 = r1->field_13
    //     0x11d2684: ldur            w0, [x1, #0x13]
    // 0x11d2688: DecompressPointer r0
    //     0x11d2688: add             x0, x0, HEAP, lsl #32
    // 0x11d268c: stur            x0, [fp, #-0x18]
    // 0x11d2690: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x11d2690: ldur            w3, [x1, #0x17]
    // 0x11d2694: DecompressPointer r3
    //     0x11d2694: add             x3, x3, HEAP, lsl #32
    // 0x11d2698: stur            x3, [fp, #-0x10]
    // 0x11d269c: LoadField: r4 = r1->field_1b
    //     0x11d269c: ldur            w4, [x1, #0x1b]
    // 0x11d26a0: DecompressPointer r4
    //     0x11d26a0: add             x4, x4, HEAP, lsl #32
    // 0x11d26a4: stur            x4, [fp, #-8]
    // 0x11d26a8: r0 = RenderMouseRegion()
    //     0x11d26a8: bl              #0x11d26f0  ; AllocateRenderMouseRegionStub -> RenderMouseRegion (size=0x70)
    // 0x11d26ac: stur            x0, [fp, #-0x28]
    // 0x11d26b0: ldur            x16, [fp, #-0x18]
    // 0x11d26b4: ldur            lr, [fp, #-8]
    // 0x11d26b8: stp             lr, x16, [SP, #8]
    // 0x11d26bc: str             NULL, [SP]
    // 0x11d26c0: mov             x1, x0
    // 0x11d26c4: ldur            x2, [fp, #-0x20]
    // 0x11d26c8: ldur            x3, [fp, #-0x10]
    // 0x11d26cc: r4 = const [0, 0x6, 0x3, 0x3, cursor, 0x4, hitTestBehavior, 0x5, onHover, 0x3, null]
    //     0x11d26cc: add             x4, PP, #0x85, lsl #12  ; [pp+0x85158] List(11) [0, 0x6, 0x3, 0x3, "cursor", 0x4, "hitTestBehavior", 0x5, "onHover", 0x3, Null]
    //     0x11d26d0: ldr             x4, [x4, #0x158]
    // 0x11d26d4: r0 = RenderMouseRegion()
    //     0x11d26d4: bl              #0x11d2470  ; [package:flutter/src/rendering/proxy_box.dart] RenderMouseRegion::RenderMouseRegion
    // 0x11d26d8: ldur            x0, [fp, #-0x28]
    // 0x11d26dc: LeaveFrame
    //     0x11d26dc: mov             SP, fp
    //     0x11d26e0: ldp             fp, lr, [SP], #0x10
    // 0x11d26e4: ret
    //     0x11d26e4: ret             
    // 0x11d26e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d26e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d26ec: b               #0x11d2678
  }
}

// class id: 6609, size: 0x38, field offset: 0x10
//   const constructor, 
class Listener extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf93d8, size: 0x178
    // 0xcf93d8: EnterFrame
    //     0xcf93d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf93dc: mov             fp, SP
    // 0xcf93e0: AllocStack(0x10)
    //     0xcf93e0: sub             SP, SP, #0x10
    // 0xcf93e4: SetupParameters(Listener this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xcf93e4: mov             x0, x3
    //     0xcf93e8: mov             x5, x1
    //     0xcf93ec: mov             x4, x2
    //     0xcf93f0: stur            x1, [fp, #-8]
    //     0xcf93f4: stur            x3, [fp, #-0x10]
    // 0xcf93f8: r2 = Null
    //     0xcf93f8: mov             x2, NULL
    // 0xcf93fc: r1 = Null
    //     0xcf93fc: mov             x1, NULL
    // 0xcf9400: r4 = 60
    //     0xcf9400: mov             x4, #0x3c
    // 0xcf9404: branchIfSmi(r0, 0xcf9410)
    //     0xcf9404: tbz             w0, #0, #0xcf9410
    // 0xcf9408: r4 = LoadClassIdInstr(r0)
    //     0xcf9408: ldur            x4, [x0, #-1]
    //     0xcf940c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9410: r17 = 4955
    //     0xcf9410: mov             x17, #0x135b
    // 0xcf9414: cmp             x4, x17
    // 0xcf9418: b.eq            #0xcf9430
    // 0xcf941c: r8 = RenderPointerListener
    //     0xcf941c: add             x8, PP, #0x90, lsl #12  ; [pp+0x90298] Type: RenderPointerListener
    //     0xcf9420: ldr             x8, [x8, #0x298]
    // 0xcf9424: r3 = Null
    //     0xcf9424: add             x3, PP, #0x90, lsl #12  ; [pp+0x902a0] Null
    //     0xcf9428: ldr             x3, [x3, #0x2a0]
    // 0xcf942c: r0 = DefaultTypeTest()
    //     0xcf942c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9430: ldur            x1, [fp, #-8]
    // 0xcf9434: LoadField: r0 = r1->field_f
    //     0xcf9434: ldur            w0, [x1, #0xf]
    // 0xcf9438: DecompressPointer r0
    //     0xcf9438: add             x0, x0, HEAP, lsl #32
    // 0xcf943c: ldur            x2, [fp, #-0x10]
    // 0xcf9440: StoreField: r2->field_57 = r0
    //     0xcf9440: stur            w0, [x2, #0x57]
    //     0xcf9444: ldurb           w16, [x2, #-1]
    //     0xcf9448: ldurb           w17, [x0, #-1]
    //     0xcf944c: and             x16, x17, x16, lsr #2
    //     0xcf9450: tst             x16, HEAP, lsr #32
    //     0xcf9454: b.eq            #0xcf945c
    //     0xcf9458: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf945c: LoadField: r0 = r1->field_13
    //     0xcf945c: ldur            w0, [x1, #0x13]
    // 0xcf9460: DecompressPointer r0
    //     0xcf9460: add             x0, x0, HEAP, lsl #32
    // 0xcf9464: StoreField: r2->field_5b = r0
    //     0xcf9464: stur            w0, [x2, #0x5b]
    //     0xcf9468: ldurb           w16, [x2, #-1]
    //     0xcf946c: ldurb           w17, [x0, #-1]
    //     0xcf9470: and             x16, x17, x16, lsr #2
    //     0xcf9474: tst             x16, HEAP, lsr #32
    //     0xcf9478: b.eq            #0xcf9480
    //     0xcf947c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf9480: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xcf9480: ldur            w0, [x1, #0x17]
    // 0xcf9484: DecompressPointer r0
    //     0xcf9484: add             x0, x0, HEAP, lsl #32
    // 0xcf9488: StoreField: r2->field_5f = r0
    //     0xcf9488: stur            w0, [x2, #0x5f]
    //     0xcf948c: ldurb           w16, [x2, #-1]
    //     0xcf9490: ldurb           w17, [x0, #-1]
    //     0xcf9494: and             x16, x17, x16, lsr #2
    //     0xcf9498: tst             x16, HEAP, lsr #32
    //     0xcf949c: b.eq            #0xcf94a4
    //     0xcf94a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf94a4: StoreField: r2->field_63 = rNULL
    //     0xcf94a4: stur            NULL, [x2, #0x63]
    // 0xcf94a8: LoadField: r0 = r1->field_1f
    //     0xcf94a8: ldur            w0, [x1, #0x1f]
    // 0xcf94ac: DecompressPointer r0
    //     0xcf94ac: add             x0, x0, HEAP, lsl #32
    // 0xcf94b0: StoreField: r2->field_67 = r0
    //     0xcf94b0: stur            w0, [x2, #0x67]
    //     0xcf94b4: ldurb           w16, [x2, #-1]
    //     0xcf94b8: ldurb           w17, [x0, #-1]
    //     0xcf94bc: and             x16, x17, x16, lsr #2
    //     0xcf94c0: tst             x16, HEAP, lsr #32
    //     0xcf94c4: b.eq            #0xcf94cc
    //     0xcf94c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf94cc: LoadField: r0 = r1->field_23
    //     0xcf94cc: ldur            w0, [x1, #0x23]
    // 0xcf94d0: DecompressPointer r0
    //     0xcf94d0: add             x0, x0, HEAP, lsl #32
    // 0xcf94d4: StoreField: r2->field_6b = r0
    //     0xcf94d4: stur            w0, [x2, #0x6b]
    //     0xcf94d8: ldurb           w16, [x2, #-1]
    //     0xcf94dc: ldurb           w17, [x0, #-1]
    //     0xcf94e0: and             x16, x17, x16, lsr #2
    //     0xcf94e4: tst             x16, HEAP, lsr #32
    //     0xcf94e8: b.eq            #0xcf94f0
    //     0xcf94ec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf94f0: StoreField: r2->field_6f = rNULL
    //     0xcf94f0: stur            NULL, [x2, #0x6f]
    // 0xcf94f4: StoreField: r2->field_73 = rNULL
    //     0xcf94f4: stur            NULL, [x2, #0x73]
    // 0xcf94f8: LoadField: r0 = r1->field_2f
    //     0xcf94f8: ldur            w0, [x1, #0x2f]
    // 0xcf94fc: DecompressPointer r0
    //     0xcf94fc: add             x0, x0, HEAP, lsl #32
    // 0xcf9500: StoreField: r2->field_77 = r0
    //     0xcf9500: stur            w0, [x2, #0x77]
    //     0xcf9504: ldurb           w16, [x2, #-1]
    //     0xcf9508: ldurb           w17, [x0, #-1]
    //     0xcf950c: and             x16, x17, x16, lsr #2
    //     0xcf9510: tst             x16, HEAP, lsr #32
    //     0xcf9514: b.eq            #0xcf951c
    //     0xcf9518: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf951c: LoadField: r0 = r1->field_33
    //     0xcf951c: ldur            w0, [x1, #0x33]
    // 0xcf9520: DecompressPointer r0
    //     0xcf9520: add             x0, x0, HEAP, lsl #32
    // 0xcf9524: StoreField: r2->field_53 = r0
    //     0xcf9524: stur            w0, [x2, #0x53]
    //     0xcf9528: ldurb           w16, [x2, #-1]
    //     0xcf952c: ldurb           w17, [x0, #-1]
    //     0xcf9530: and             x16, x17, x16, lsr #2
    //     0xcf9534: tst             x16, HEAP, lsr #32
    //     0xcf9538: b.eq            #0xcf9540
    //     0xcf953c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf9540: r0 = Null
    //     0xcf9540: mov             x0, NULL
    // 0xcf9544: LeaveFrame
    //     0xcf9544: mov             SP, fp
    //     0xcf9548: ldp             fp, lr, [SP], #0x10
    // 0xcf954c: ret
    //     0xcf954c: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2178, size: 0xb4
    // 0x11d2178: EnterFrame
    //     0x11d2178: stp             fp, lr, [SP, #-0x10]!
    //     0x11d217c: mov             fp, SP
    // 0x11d2180: AllocStack(0x50)
    //     0x11d2180: sub             SP, SP, #0x50
    // 0x11d2184: CheckStackOverflow
    //     0x11d2184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2188: cmp             SP, x16
    //     0x11d218c: b.ls            #0x11d2224
    // 0x11d2190: LoadField: r5 = r1->field_f
    //     0x11d2190: ldur            w5, [x1, #0xf]
    // 0x11d2194: DecompressPointer r5
    //     0x11d2194: add             x5, x5, HEAP, lsl #32
    // 0x11d2198: stur            x5, [fp, #-0x38]
    // 0x11d219c: LoadField: r6 = r1->field_13
    //     0x11d219c: ldur            w6, [x1, #0x13]
    // 0x11d21a0: DecompressPointer r6
    //     0x11d21a0: add             x6, x6, HEAP, lsl #32
    // 0x11d21a4: stur            x6, [fp, #-0x30]
    // 0x11d21a8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x11d21a8: ldur            w0, [x1, #0x17]
    // 0x11d21ac: DecompressPointer r0
    //     0x11d21ac: add             x0, x0, HEAP, lsl #32
    // 0x11d21b0: stur            x0, [fp, #-0x28]
    // 0x11d21b4: LoadField: r3 = r1->field_1f
    //     0x11d21b4: ldur            w3, [x1, #0x1f]
    // 0x11d21b8: DecompressPointer r3
    //     0x11d21b8: add             x3, x3, HEAP, lsl #32
    // 0x11d21bc: stur            x3, [fp, #-0x20]
    // 0x11d21c0: LoadField: r7 = r1->field_23
    //     0x11d21c0: ldur            w7, [x1, #0x23]
    // 0x11d21c4: DecompressPointer r7
    //     0x11d21c4: add             x7, x7, HEAP, lsl #32
    // 0x11d21c8: stur            x7, [fp, #-0x18]
    // 0x11d21cc: LoadField: r2 = r1->field_2f
    //     0x11d21cc: ldur            w2, [x1, #0x2f]
    // 0x11d21d0: DecompressPointer r2
    //     0x11d21d0: add             x2, x2, HEAP, lsl #32
    // 0x11d21d4: stur            x2, [fp, #-0x10]
    // 0x11d21d8: LoadField: r4 = r1->field_33
    //     0x11d21d8: ldur            w4, [x1, #0x33]
    // 0x11d21dc: DecompressPointer r4
    //     0x11d21dc: add             x4, x4, HEAP, lsl #32
    // 0x11d21e0: stur            x4, [fp, #-8]
    // 0x11d21e4: r0 = RenderPointerListener()
    //     0x11d21e4: bl              #0x11d2400  ; AllocateRenderPointerListenerStub -> RenderPointerListener (size=0x7c)
    // 0x11d21e8: stur            x0, [fp, #-0x40]
    // 0x11d21ec: ldur            x16, [fp, #-0x10]
    // 0x11d21f0: ldur            lr, [fp, #-0x28]
    // 0x11d21f4: stp             lr, x16, [SP]
    // 0x11d21f8: mov             x1, x0
    // 0x11d21fc: ldur            x2, [fp, #-8]
    // 0x11d2200: ldur            x3, [fp, #-0x20]
    // 0x11d2204: ldur            x5, [fp, #-0x38]
    // 0x11d2208: ldur            x6, [fp, #-0x30]
    // 0x11d220c: ldur            x7, [fp, #-0x18]
    // 0x11d2210: r0 = RenderPointerListener()
    //     0x11d2210: bl              #0x11d222c  ; [package:flutter/src/rendering/proxy_box.dart] RenderPointerListener::RenderPointerListener
    // 0x11d2214: ldur            x0, [fp, #-0x40]
    // 0x11d2218: LeaveFrame
    //     0x11d2218: mov             SP, fp
    //     0x11d221c: ldp             fp, lr, [SP], #0x10
    // 0x11d2220: ret
    //     0x11d2220: ret             
    // 0x11d2224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2228: b               #0x11d2190
  }
}

// class id: 6610, size: 0x28, field offset: 0x10
//   const constructor, 
abstract class _SemanticsBase extends SingleChildRenderObjectWidget {

  _ _SemanticsBase(/* No info */) {
    // ** addr: 0x917b7c, size: 0x2c0
    // 0x917b7c: EnterFrame
    //     0x917b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x917b80: mov             fp, SP
    // 0x917b84: AllocStack(0x38)
    //     0x917b84: sub             SP, SP, #0x38
    // 0x917b88: SetupParameters(_SemanticsBase this /* r1 => r4, fp-0x8 */, dynamic _ /* r6 => r1 */)
    //     0x917b88: mov             x4, x1
    //     0x917b8c: stur            x1, [fp, #-8]
    //     0x917b90: mov             x1, x6
    // 0x917b94: ldr             x0, [fp, #0x68]
    // 0x917b98: stur            x2, [fp, #-0x10]
    // 0x917b9c: stur            x3, [fp, #-0x18]
    // 0x917ba0: stur            x5, [fp, #-0x20]
    // 0x917ba4: stur            x6, [fp, #-0x28]
    // 0x917ba8: stur            x7, [fp, #-0x30]
    // 0x917bac: cmp             w0, NULL
    // 0x917bb0: b.eq            #0x917bcc
    // 0x917bb4: r0 = SemanticsHintOverrides()
    //     0x917bb4: bl              #0x917e78  ; AllocateSemanticsHintOverridesStub -> SemanticsHintOverrides (size=0x10)
    // 0x917bb8: mov             x1, x0
    // 0x917bbc: ldr             x0, [fp, #0x68]
    // 0x917bc0: StoreField: r1->field_7 = r0
    //     0x917bc0: stur            w0, [x1, #7]
    // 0x917bc4: stur            x1, [fp, #-0x38]
    // 0x917bc8: b               #0x917bd8
    // 0x917bcc: SaveReg r0
    //     0x917bcc: str             x0, [SP, #-8]!
    // 0x917bd0: stur            NULL, [fp, #-0x38]
    // 0x917bd4: RestoreReg r0
    //     0x917bd4: ldr             x0, [SP], #8
    // 0x917bd8: ldur            x4, [fp, #-8]
    // 0x917bdc: ldur            x3, [fp, #-0x10]
    // 0x917be0: ldur            x2, [fp, #-0x18]
    // 0x917be4: ldur            x1, [fp, #-0x20]
    // 0x917be8: ldur            x0, [fp, #-0x30]
    // 0x917bec: ldr             x25, [fp, #0x88]
    // 0x917bf0: ldr             x24, [fp, #0x80]
    // 0x917bf4: ldr             x23, [fp, #0x78]
    // 0x917bf8: ldr             x20, [fp, #0x70]
    // 0x917bfc: ldr             x19, [fp, #0x60]
    // 0x917c00: ldr             x14, [fp, #0x58]
    // 0x917c04: ldr             x13, [fp, #0x50]
    // 0x917c08: ldr             x12, [fp, #0x48]
    // 0x917c0c: ldr             x11, [fp, #0x40]
    // 0x917c10: ldr             x10, [fp, #0x38]
    // 0x917c14: ldr             x9, [fp, #0x30]
    // 0x917c18: ldr             x8, [fp, #0x28]
    // 0x917c1c: ldr             x7, [fp, #0x20]
    // 0x917c20: ldr             x6, [fp, #0x18]
    // 0x917c24: ldr             x5, [fp, #0x10]
    // 0x917c28: r0 = SemanticsProperties()
    //     0x917c28: bl              #0x917e3c  ; AllocateSemanticsPropertiesStub -> SemanticsProperties (size=0x140)
    // 0x917c2c: mov             x2, x0
    // 0x917c30: ldr             x1, [fp, #0x150]
    // 0x917c34: StoreField: r2->field_7 = r1
    //     0x917c34: stur            w1, [x2, #7]
    // 0x917c38: ldur            x1, [fp, #-0x20]
    // 0x917c3c: StoreField: r2->field_b = r1
    //     0x917c3c: stur            w1, [x2, #0xb]
    // 0x917c40: ldr             x1, [fp, #0xc0]
    // 0x917c44: StoreField: r2->field_f = r1
    //     0x917c44: stur            w1, [x2, #0xf]
    // 0x917c48: ldr             x1, [fp, #0x140]
    // 0x917c4c: StoreField: r2->field_13 = r1
    //     0x917c4c: stur            w1, [x2, #0x13]
    // 0x917c50: ldr             x1, [fp, #0x50]
    // 0x917c54: StoreField: r2->field_1b = r1
    //     0x917c54: stur            w1, [x2, #0x1b]
    // 0x917c58: ldr             x1, [fp, #0x30]
    // 0x917c5c: ArrayStore: r2[0] = r1  ; List_4
    //     0x917c5c: stur            w1, [x2, #0x17]
    // 0x917c60: ldur            x1, [fp, #-0x18]
    // 0x917c64: StoreField: r2->field_1f = r1
    //     0x917c64: stur            w1, [x2, #0x1f]
    // 0x917c68: ldr             x1, [fp, #0x120]
    // 0x917c6c: StoreField: r2->field_27 = r1
    //     0x917c6c: stur            w1, [x2, #0x27]
    // 0x917c70: ldr             x1, [fp, #0x130]
    // 0x917c74: StoreField: r2->field_3b = r1
    //     0x917c74: stur            w1, [x2, #0x3b]
    // 0x917c78: ldr             x1, [fp, #0x128]
    // 0x917c7c: StoreField: r2->field_3f = r1
    //     0x917c7c: stur            w1, [x2, #0x3f]
    // 0x917c80: ldur            x1, [fp, #-0x10]
    // 0x917c84: StoreField: r2->field_43 = r1
    //     0x917c84: stur            w1, [x2, #0x43]
    // 0x917c88: ldr             x1, [fp, #0x100]
    // 0x917c8c: StoreField: r2->field_47 = r1
    //     0x917c8c: stur            w1, [x2, #0x47]
    // 0x917c90: ldr             x1, [fp, #0x58]
    // 0x917c94: StoreField: r2->field_57 = r1
    //     0x917c94: stur            w1, [x2, #0x57]
    // 0x917c98: ldr             x1, [fp, #0xb8]
    // 0x917c9c: StoreField: r2->field_5b = r1
    //     0x917c9c: stur            w1, [x2, #0x5b]
    // 0x917ca0: ldr             x1, [fp, #0x108]
    // 0x917ca4: StoreField: r2->field_5f = r1
    //     0x917ca4: stur            w1, [x2, #0x5f]
    // 0x917ca8: ldr             x1, [fp, #0xe8]
    // 0x917cac: StoreField: r2->field_63 = r1
    //     0x917cac: stur            w1, [x2, #0x63]
    // 0x917cb0: ldr             x1, [fp, #0xd0]
    // 0x917cb4: StoreField: r2->field_6b = r1
    //     0x917cb4: stur            w1, [x2, #0x6b]
    // 0x917cb8: ldr             x1, [fp, #0x158]
    // 0x917cbc: StoreField: r2->field_6f = r1
    //     0x917cbc: stur            w1, [x2, #0x6f]
    // 0x917cc0: ldr             x1, [fp, #0x20]
    // 0x917cc4: StoreField: r2->field_77 = r1
    //     0x917cc4: stur            w1, [x2, #0x77]
    // 0x917cc8: ldr             x1, [fp, #0xf0]
    // 0x917ccc: StoreField: r2->field_7f = r1
    //     0x917ccc: stur            w1, [x2, #0x7f]
    // 0x917cd0: ldr             x1, [fp, #0x10]
    // 0x917cd4: StoreField: r2->field_87 = r1
    //     0x917cd4: stur            w1, [x2, #0x87]
    // 0x917cd8: ldr             x1, [fp, #0x118]
    // 0x917cdc: StoreField: r2->field_9f = r1
    //     0x917cdc: stur            w1, [x2, #0x9f]
    // 0x917ce0: ldr             x1, [fp, #0x28]
    // 0x917ce4: StoreField: r2->field_a7 = r1
    //     0x917ce4: stur            w1, [x2, #0xa7]
    // 0x917ce8: ldur            x1, [fp, #-0x38]
    // 0x917cec: StoreField: r2->field_af = r1
    //     0x917cec: stur            w1, [x2, #0xaf]
    // 0x917cf0: ldr             x1, [fp, #0x38]
    // 0x917cf4: StoreField: r2->field_b3 = r1
    //     0x917cf4: stur            w1, [x2, #0xb3]
    // 0x917cf8: ldr             x1, [fp, #0x48]
    // 0x917cfc: StoreField: r2->field_b7 = r1
    //     0x917cfc: stur            w1, [x2, #0xb7]
    // 0x917d00: ldr             x1, [fp, #0x40]
    // 0x917d04: StoreField: r2->field_bb = r1
    //     0x917d04: stur            w1, [x2, #0xbb]
    // 0x917d08: ldr             x1, [fp, #0x60]
    // 0x917d0c: r17 = 291
    //     0x917d0c: mov             x17, #0x123
    // 0x917d10: str             w1, [x2, x17]
    // 0x917d14: ldr             x1, [fp, #0xf8]
    // 0x917d18: r17 = 307
    //     0x917d18: mov             x17, #0x133
    // 0x917d1c: str             w1, [x2, x17]
    // 0x917d20: ldr             x1, [fp, #0x18]
    // 0x917d24: r17 = 299
    //     0x917d24: mov             x17, #0x12b
    // 0x917d28: str             w1, [x2, x17]
    // 0x917d2c: ldr             x1, [fp, #0x110]
    // 0x917d30: r17 = 303
    //     0x917d30: mov             x17, #0x12f
    // 0x917d34: str             w1, [x2, x17]
    // 0x917d38: ldr             x1, [fp, #0x70]
    // 0x917d3c: StoreField: r2->field_c3 = r1
    //     0x917d3c: stur            w1, [x2, #0xc3]
    // 0x917d40: ldr             x1, [fp, #0x80]
    // 0x917d44: StoreField: r2->field_c7 = r1
    //     0x917d44: stur            w1, [x2, #0xc7]
    // 0x917d48: ldr             x1, [fp, #0xb0]
    // 0x917d4c: StoreField: r2->field_e3 = r1
    //     0x917d4c: stur            w1, [x2, #0xe3]
    // 0x917d50: ldr             x1, [fp, #0xa8]
    // 0x917d54: StoreField: r2->field_e7 = r1
    //     0x917d54: stur            w1, [x2, #0xe7]
    // 0x917d58: ldr             x1, [fp, #0x78]
    // 0x917d5c: StoreField: r2->field_eb = r1
    //     0x917d5c: stur            w1, [x2, #0xeb]
    // 0x917d60: ldr             x1, [fp, #0xa0]
    // 0x917d64: r17 = 263
    //     0x917d64: mov             x17, #0x107
    // 0x917d68: str             w1, [x2, x17]
    // 0x917d6c: ldr             x1, [fp, #0x98]
    // 0x917d70: r17 = 267
    //     0x917d70: mov             x17, #0x10b
    // 0x917d74: str             w1, [x2, x17]
    // 0x917d78: ldr             x1, [fp, #0x88]
    // 0x917d7c: r17 = 271
    //     0x917d7c: mov             x17, #0x10f
    // 0x917d80: str             w1, [x2, x17]
    // 0x917d84: ldr             x1, [fp, #0x90]
    // 0x917d88: r17 = 275
    //     0x917d88: mov             x17, #0x113
    // 0x917d8c: str             w1, [x2, x17]
    // 0x917d90: ldr             x1, [fp, #0xc8]
    // 0x917d94: r17 = 315
    //     0x917d94: mov             x17, #0x13b
    // 0x917d98: str             w1, [x2, x17]
    // 0x917d9c: ldr             x1, [fp, #0xd8]
    // 0x917da0: r17 = 311
    //     0x917da0: mov             x17, #0x137
    // 0x917da4: str             w1, [x2, x17]
    // 0x917da8: ldur            x3, [fp, #-8]
    // 0x917dac: ldur            x1, [fp, #-0x30]
    // 0x917db0: StoreField: r3->field_13 = r1
    //     0x917db0: stur            w1, [x3, #0x13]
    // 0x917db4: ldr             x1, [fp, #0x138]
    // 0x917db8: ArrayStore: r3[0] = r1  ; List_4
    //     0x917db8: stur            w1, [x3, #0x17]
    // 0x917dbc: ldr             x1, [fp, #0x148]
    // 0x917dc0: StoreField: r3->field_1f = r1
    //     0x917dc0: stur            w1, [x3, #0x1f]
    // 0x917dc4: r1 = false
    //     0x917dc4: add             x1, NULL, #0x30  ; false
    // 0x917dc8: StoreField: r3->field_23 = r1
    //     0x917dc8: stur            w1, [x3, #0x23]
    // 0x917dcc: ldr             x0, [fp, #0xe0]
    // 0x917dd0: StoreField: r3->field_1b = r0
    //     0x917dd0: stur            w0, [x3, #0x1b]
    //     0x917dd4: ldurb           w16, [x3, #-1]
    //     0x917dd8: ldurb           w17, [x0, #-1]
    //     0x917ddc: and             x16, x17, x16, lsr #2
    //     0x917de0: tst             x16, HEAP, lsr #32
    //     0x917de4: b.eq            #0x917dec
    //     0x917de8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x917dec: mov             x0, x2
    // 0x917df0: StoreField: r3->field_f = r0
    //     0x917df0: stur            w0, [x3, #0xf]
    //     0x917df4: ldurb           w16, [x3, #-1]
    //     0x917df8: ldurb           w17, [x0, #-1]
    //     0x917dfc: and             x16, x17, x16, lsr #2
    //     0x917e00: tst             x16, HEAP, lsr #32
    //     0x917e04: b.eq            #0x917e0c
    //     0x917e08: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x917e0c: ldur            x0, [fp, #-0x28]
    // 0x917e10: StoreField: r3->field_b = r0
    //     0x917e10: stur            w0, [x3, #0xb]
    //     0x917e14: ldurb           w16, [x3, #-1]
    //     0x917e18: ldurb           w17, [x0, #-1]
    //     0x917e1c: and             x16, x17, x16, lsr #2
    //     0x917e20: tst             x16, HEAP, lsr #32
    //     0x917e24: b.eq            #0x917e2c
    //     0x917e28: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x917e2c: r0 = Null
    //     0x917e2c: mov             x0, NULL
    // 0x917e30: LeaveFrame
    //     0x917e30: mov             SP, fp
    //     0x917e34: ldp             fp, lr, [SP], #0x10
    // 0x917e38: ret
    //     0x917e38: ret             
  }
  _ _getTextDirection(/* No info */) {
    // ** addr: 0xcf8f50, size: 0xa8
    // 0xcf8f50: EnterFrame
    //     0xcf8f50: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8f54: mov             fp, SP
    // 0xcf8f58: mov             x0, x1
    // 0xcf8f5c: mov             x1, x2
    // 0xcf8f60: CheckStackOverflow
    //     0xcf8f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8f64: cmp             SP, x16
    //     0xcf8f68: b.ls            #0xcf8ff0
    // 0xcf8f6c: LoadField: r2 = r0->field_f
    //     0xcf8f6c: ldur            w2, [x0, #0xf]
    // 0xcf8f70: DecompressPointer r2
    //     0xcf8f70: add             x2, x2, HEAP, lsl #32
    // 0xcf8f74: LoadField: r0 = r2->field_b3
    //     0xcf8f74: ldur            w0, [x2, #0xb3]
    // 0xcf8f78: DecompressPointer r0
    //     0xcf8f78: add             x0, x0, HEAP, lsl #32
    // 0xcf8f7c: cmp             w0, NULL
    // 0xcf8f80: b.eq            #0xcf8f90
    // 0xcf8f84: LeaveFrame
    //     0xcf8f84: mov             SP, fp
    //     0xcf8f88: ldp             fp, lr, [SP], #0x10
    // 0xcf8f8c: ret
    //     0xcf8f8c: ret             
    // 0xcf8f90: LoadField: r0 = r2->field_7f
    //     0xcf8f90: ldur            w0, [x2, #0x7f]
    // 0xcf8f94: DecompressPointer r0
    //     0xcf8f94: add             x0, x0, HEAP, lsl #32
    // 0xcf8f98: cmp             w0, NULL
    // 0xcf8f9c: b.ne            #0xcf8fe0
    // 0xcf8fa0: LoadField: r0 = r2->field_87
    //     0xcf8fa0: ldur            w0, [x2, #0x87]
    // 0xcf8fa4: DecompressPointer r0
    //     0xcf8fa4: add             x0, x0, HEAP, lsl #32
    // 0xcf8fa8: cmp             w0, NULL
    // 0xcf8fac: b.ne            #0xcf8fe0
    // 0xcf8fb0: LoadField: r0 = r2->field_9f
    //     0xcf8fb0: ldur            w0, [x2, #0x9f]
    // 0xcf8fb4: DecompressPointer r0
    //     0xcf8fb4: add             x0, x0, HEAP, lsl #32
    // 0xcf8fb8: cmp             w0, NULL
    // 0xcf8fbc: b.ne            #0xcf8fe0
    // 0xcf8fc0: LoadField: r0 = r2->field_a7
    //     0xcf8fc0: ldur            w0, [x2, #0xa7]
    // 0xcf8fc4: DecompressPointer r0
    //     0xcf8fc4: add             x0, x0, HEAP, lsl #32
    // 0xcf8fc8: cmp             w0, NULL
    // 0xcf8fcc: b.ne            #0xcf8fe0
    // 0xcf8fd0: r0 = Null
    //     0xcf8fd0: mov             x0, NULL
    // 0xcf8fd4: LeaveFrame
    //     0xcf8fd4: mov             SP, fp
    //     0xcf8fd8: ldp             fp, lr, [SP], #0x10
    // 0xcf8fdc: ret
    //     0xcf8fdc: ret             
    // 0xcf8fe0: r0 = maybeOf()
    //     0xcf8fe0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf8fe4: LeaveFrame
    //     0xcf8fe4: mov             SP, fp
    //     0xcf8fe8: ldp             fp, lr, [SP], #0x10
    // 0xcf8fec: ret
    //     0xcf8fec: ret             
    // 0xcf8ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8ff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8ff4: b               #0xcf8f6c
  }
}

// class id: 6611, size: 0x28, field offset: 0x28
//   const constructor, 
class Semantics extends _SemanticsBase {

  _ Semantics(/* No info */) {
    // ** addr: 0x9169c0, size: 0x11bc
    // 0x9169c0: EnterFrame
    //     0x9169c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9169c4: mov             fp, SP
    // 0x9169c8: AllocStack(0x258)
    //     0x9169c8: sub             SP, SP, #0x258
    // 0x9169cc: SetupParameters(Semantics this /* r1 => fp-0x8 */, {dynamic accessibilityFocusBlockType = Null /* fp-0x10 */, dynamic button = Null /* fp-0x18 */, dynamic checked = Null /* fp-0x20 */, dynamic child = Null /* fp-0x28 */, dynamic container = false /* fp-0x30 */, dynamic currentValueLength = Null /* r9 */, dynamic enabled = Null /* r10 */, dynamic excludeSemantics = false /* r11 */, dynamic expanded = Null /* r12 */, dynamic explicitChildNodes = false /* r13 */, dynamic focusable = Null /* r14 */, dynamic focused = Null /* r19 */, dynamic header = Null /* r20 */, dynamic hint = Null /* r2 */, dynamic hitTestBehavior = Null /* r3 */, dynamic image = Null /* r5 */, dynamic inMutuallyExclusiveGroup = Null /* r6 */, dynamic inputType = Null /* r7 */, dynamic label = Null /* fp-0x38 */, dynamic liveRegion = Null /* fp-0x40 */, dynamic localeForSubtree = Null /* fp-0x48 */, dynamic maxValue = Null /* fp-0x50 */, dynamic maxValueLength = Null /* fp-0x58 */, dynamic minValue = Null /* fp-0x60 */, dynamic mixed = Null /* fp-0x68 */, dynamic namesRoute = Null /* fp-0x70 */, dynamic onCopy = Null /* fp-0x78 */, dynamic onCut = Null /* fp-0x80 */, dynamic onDidGainAccessibilityFocus = Null /* fp-0x88 */, dynamic onDidLoseAccessibilityFocus = Null /* fp-0x90 */, dynamic onDismiss = Null /* fp-0x98 */, dynamic onFocus = Null /* fp-0xa0 */, dynamic onLongPress = Null /* fp-0xa8 */, dynamic onPaste = Null /* fp-0xb0 */, dynamic onTap = Null /* fp-0xb8 */, dynamic onTapHint = Null /* fp-0xc0 */, dynamic role = Null /* fp-0xc8 */, dynamic scopesRoute = Null /* fp-0xd0 */, dynamic selected = Null /* fp-0xd8 */, dynamic sortKey = Null /* fp-0xe0 */, dynamic tagForChildren = Null /* fp-0xe8 */, dynamic textDirection = Null /* fp-0xf0 */, dynamic toggled = Null /* fp-0xf8 */, dynamic tooltip = Null /* fp-0x100 */, dynamic traversalParentIdentifier = Null /* r8 */})
    //     0x9169cc: stur            x1, [fp, #-8]
    //     0x9169d0: ldur            w0, [x4, #0x13]
    //     0x9169d4: ldur            w2, [x4, #0x1f]
    //     0x9169d8: add             x2, x2, HEAP, lsl #32
    //     0x9169dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x150f0] "accessibilityFocusBlockType"
    //     0x9169e0: ldr             x16, [x16, #0xf0]
    //     0x9169e4: cmp             w2, w16
    //     0x9169e8: b.ne            #0x916a0c
    //     0x9169ec: ldur            w2, [x4, #0x23]
    //     0x9169f0: add             x2, x2, HEAP, lsl #32
    //     0x9169f4: sub             w3, w0, w2
    //     0x9169f8: add             x2, fp, w3, sxtw #2
    //     0x9169fc: ldr             x2, [x2, #8]
    //     0x916a00: mov             x3, x2
    //     0x916a04: mov             x2, #1
    //     0x916a08: b               #0x916a14
    //     0x916a0c: mov             x3, NULL
    //     0x916a10: mov             x2, #0
    //     0x916a14: stur            x3, [fp, #-0x10]
    //     0x916a18: lsl             x5, x2, #1
    //     0x916a1c: lsl             w6, w5, #1
    //     0x916a20: add             w7, w6, #8
    //     0x916a24: add             x16, x4, w7, sxtw #1
    //     0x916a28: ldur            w8, [x16, #0xf]
    //     0x916a2c: add             x8, x8, HEAP, lsl #32
    //     0x916a30: add             x16, PP, #0x15, lsl #12  ; [pp+0x150f8] "button"
    //     0x916a34: ldr             x16, [x16, #0xf8]
    //     0x916a38: cmp             w8, w16
    //     0x916a3c: b.ne            #0x916a70
    //     0x916a40: add             w2, w6, #0xa
    //     0x916a44: add             x16, x4, w2, sxtw #1
    //     0x916a48: ldur            w6, [x16, #0xf]
    //     0x916a4c: add             x6, x6, HEAP, lsl #32
    //     0x916a50: sub             w2, w0, w6
    //     0x916a54: add             x6, fp, w2, sxtw #2
    //     0x916a58: ldr             x6, [x6, #8]
    //     0x916a5c: add             w2, w5, #2
    //     0x916a60: sbfx            x5, x2, #1, #0x1f
    //     0x916a64: mov             x2, x5
    //     0x916a68: mov             x5, x6
    //     0x916a6c: b               #0x916a74
    //     0x916a70: mov             x5, NULL
    //     0x916a74: stur            x5, [fp, #-0x18]
    //     0x916a78: lsl             x6, x2, #1
    //     0x916a7c: lsl             w7, w6, #1
    //     0x916a80: add             w8, w7, #8
    //     0x916a84: add             x16, x4, w8, sxtw #1
    //     0x916a88: ldur            w9, [x16, #0xf]
    //     0x916a8c: add             x9, x9, HEAP, lsl #32
    //     0x916a90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15100] "checked"
    //     0x916a94: ldr             x16, [x16, #0x100]
    //     0x916a98: cmp             w9, w16
    //     0x916a9c: b.ne            #0x916ad0
    //     0x916aa0: add             w2, w7, #0xa
    //     0x916aa4: add             x16, x4, w2, sxtw #1
    //     0x916aa8: ldur            w7, [x16, #0xf]
    //     0x916aac: add             x7, x7, HEAP, lsl #32
    //     0x916ab0: sub             w2, w0, w7
    //     0x916ab4: add             x7, fp, w2, sxtw #2
    //     0x916ab8: ldr             x7, [x7, #8]
    //     0x916abc: add             w2, w6, #2
    //     0x916ac0: sbfx            x6, x2, #1, #0x1f
    //     0x916ac4: mov             x2, x6
    //     0x916ac8: mov             x6, x7
    //     0x916acc: b               #0x916ad4
    //     0x916ad0: mov             x6, NULL
    //     0x916ad4: stur            x6, [fp, #-0x20]
    //     0x916ad8: lsl             x7, x2, #1
    //     0x916adc: lsl             w8, w7, #1
    //     0x916ae0: add             w9, w8, #8
    //     0x916ae4: add             x16, x4, w9, sxtw #1
    //     0x916ae8: ldur            w10, [x16, #0xf]
    //     0x916aec: add             x10, x10, HEAP, lsl #32
    //     0x916af0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15108] "child"
    //     0x916af4: ldr             x16, [x16, #0x108]
    //     0x916af8: cmp             w10, w16
    //     0x916afc: b.ne            #0x916b30
    //     0x916b00: add             w2, w8, #0xa
    //     0x916b04: add             x16, x4, w2, sxtw #1
    //     0x916b08: ldur            w8, [x16, #0xf]
    //     0x916b0c: add             x8, x8, HEAP, lsl #32
    //     0x916b10: sub             w2, w0, w8
    //     0x916b14: add             x8, fp, w2, sxtw #2
    //     0x916b18: ldr             x8, [x8, #8]
    //     0x916b1c: add             w2, w7, #2
    //     0x916b20: sbfx            x7, x2, #1, #0x1f
    //     0x916b24: mov             x2, x7
    //     0x916b28: mov             x7, x8
    //     0x916b2c: b               #0x916b34
    //     0x916b30: mov             x7, NULL
    //     0x916b34: stur            x7, [fp, #-0x28]
    //     0x916b38: lsl             x8, x2, #1
    //     0x916b3c: lsl             w9, w8, #1
    //     0x916b40: add             w10, w9, #8
    //     0x916b44: add             x16, x4, w10, sxtw #1
    //     0x916b48: ldur            w11, [x16, #0xf]
    //     0x916b4c: add             x11, x11, HEAP, lsl #32
    //     0x916b50: add             x16, PP, #0x15, lsl #12  ; [pp+0x15110] "container"
    //     0x916b54: ldr             x16, [x16, #0x110]
    //     0x916b58: cmp             w11, w16
    //     0x916b5c: b.ne            #0x916b90
    //     0x916b60: add             w2, w9, #0xa
    //     0x916b64: add             x16, x4, w2, sxtw #1
    //     0x916b68: ldur            w9, [x16, #0xf]
    //     0x916b6c: add             x9, x9, HEAP, lsl #32
    //     0x916b70: sub             w2, w0, w9
    //     0x916b74: add             x9, fp, w2, sxtw #2
    //     0x916b78: ldr             x9, [x9, #8]
    //     0x916b7c: add             w2, w8, #2
    //     0x916b80: sbfx            x8, x2, #1, #0x1f
    //     0x916b84: mov             x2, x8
    //     0x916b88: mov             x8, x9
    //     0x916b8c: b               #0x916b94
    //     0x916b90: add             x8, NULL, #0x30  ; false
    //     0x916b94: stur            x8, [fp, #-0x30]
    //     0x916b98: lsl             x9, x2, #1
    //     0x916b9c: lsl             w10, w9, #1
    //     0x916ba0: add             w11, w10, #8
    //     0x916ba4: add             x16, x4, w11, sxtw #1
    //     0x916ba8: ldur            w12, [x16, #0xf]
    //     0x916bac: add             x12, x12, HEAP, lsl #32
    //     0x916bb0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15118] "currentValueLength"
    //     0x916bb4: ldr             x16, [x16, #0x118]
    //     0x916bb8: cmp             w12, w16
    //     0x916bbc: b.ne            #0x916bf0
    //     0x916bc0: add             w2, w10, #0xa
    //     0x916bc4: add             x16, x4, w2, sxtw #1
    //     0x916bc8: ldur            w10, [x16, #0xf]
    //     0x916bcc: add             x10, x10, HEAP, lsl #32
    //     0x916bd0: sub             w2, w0, w10
    //     0x916bd4: add             x10, fp, w2, sxtw #2
    //     0x916bd8: ldr             x10, [x10, #8]
    //     0x916bdc: add             w2, w9, #2
    //     0x916be0: sbfx            x9, x2, #1, #0x1f
    //     0x916be4: mov             x2, x9
    //     0x916be8: mov             x9, x10
    //     0x916bec: b               #0x916bf4
    //     0x916bf0: mov             x9, NULL
    //     0x916bf4: lsl             x10, x2, #1
    //     0x916bf8: lsl             w11, w10, #1
    //     0x916bfc: add             w12, w11, #8
    //     0x916c00: add             x16, x4, w12, sxtw #1
    //     0x916c04: ldur            w13, [x16, #0xf]
    //     0x916c08: add             x13, x13, HEAP, lsl #32
    //     0x916c0c: ldr             x16, [PP, #0x4180]  ; [pp+0x4180] "enabled"
    //     0x916c10: cmp             w13, w16
    //     0x916c14: b.ne            #0x916c48
    //     0x916c18: add             w2, w11, #0xa
    //     0x916c1c: add             x16, x4, w2, sxtw #1
    //     0x916c20: ldur            w11, [x16, #0xf]
    //     0x916c24: add             x11, x11, HEAP, lsl #32
    //     0x916c28: sub             w2, w0, w11
    //     0x916c2c: add             x11, fp, w2, sxtw #2
    //     0x916c30: ldr             x11, [x11, #8]
    //     0x916c34: add             w2, w10, #2
    //     0x916c38: sbfx            x10, x2, #1, #0x1f
    //     0x916c3c: mov             x2, x10
    //     0x916c40: mov             x10, x11
    //     0x916c44: b               #0x916c4c
    //     0x916c48: mov             x10, NULL
    //     0x916c4c: lsl             x11, x2, #1
    //     0x916c50: lsl             w12, w11, #1
    //     0x916c54: add             w13, w12, #8
    //     0x916c58: add             x16, x4, w13, sxtw #1
    //     0x916c5c: ldur            w14, [x16, #0xf]
    //     0x916c60: add             x14, x14, HEAP, lsl #32
    //     0x916c64: add             x16, PP, #0x15, lsl #12  ; [pp+0x15120] "excludeSemantics"
    //     0x916c68: ldr             x16, [x16, #0x120]
    //     0x916c6c: cmp             w14, w16
    //     0x916c70: b.ne            #0x916ca4
    //     0x916c74: add             w2, w12, #0xa
    //     0x916c78: add             x16, x4, w2, sxtw #1
    //     0x916c7c: ldur            w12, [x16, #0xf]
    //     0x916c80: add             x12, x12, HEAP, lsl #32
    //     0x916c84: sub             w2, w0, w12
    //     0x916c88: add             x12, fp, w2, sxtw #2
    //     0x916c8c: ldr             x12, [x12, #8]
    //     0x916c90: add             w2, w11, #2
    //     0x916c94: sbfx            x11, x2, #1, #0x1f
    //     0x916c98: mov             x2, x11
    //     0x916c9c: mov             x11, x12
    //     0x916ca0: b               #0x916ca8
    //     0x916ca4: add             x11, NULL, #0x30  ; false
    //     0x916ca8: lsl             x12, x2, #1
    //     0x916cac: lsl             w13, w12, #1
    //     0x916cb0: add             w14, w13, #8
    //     0x916cb4: add             x16, x4, w14, sxtw #1
    //     0x916cb8: ldur            w19, [x16, #0xf]
    //     0x916cbc: add             x19, x19, HEAP, lsl #32
    //     0x916cc0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15128] "expanded"
    //     0x916cc4: ldr             x16, [x16, #0x128]
    //     0x916cc8: cmp             w19, w16
    //     0x916ccc: b.ne            #0x916d00
    //     0x916cd0: add             w2, w13, #0xa
    //     0x916cd4: add             x16, x4, w2, sxtw #1
    //     0x916cd8: ldur            w13, [x16, #0xf]
    //     0x916cdc: add             x13, x13, HEAP, lsl #32
    //     0x916ce0: sub             w2, w0, w13
    //     0x916ce4: add             x13, fp, w2, sxtw #2
    //     0x916ce8: ldr             x13, [x13, #8]
    //     0x916cec: add             w2, w12, #2
    //     0x916cf0: sbfx            x12, x2, #1, #0x1f
    //     0x916cf4: mov             x2, x12
    //     0x916cf8: mov             x12, x13
    //     0x916cfc: b               #0x916d04
    //     0x916d00: mov             x12, NULL
    //     0x916d04: lsl             x13, x2, #1
    //     0x916d08: lsl             w14, w13, #1
    //     0x916d0c: add             w19, w14, #8
    //     0x916d10: add             x16, x4, w19, sxtw #1
    //     0x916d14: ldur            w20, [x16, #0xf]
    //     0x916d18: add             x20, x20, HEAP, lsl #32
    //     0x916d1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15130] "explicitChildNodes"
    //     0x916d20: ldr             x16, [x16, #0x130]
    //     0x916d24: cmp             w20, w16
    //     0x916d28: b.ne            #0x916d5c
    //     0x916d2c: add             w2, w14, #0xa
    //     0x916d30: add             x16, x4, w2, sxtw #1
    //     0x916d34: ldur            w14, [x16, #0xf]
    //     0x916d38: add             x14, x14, HEAP, lsl #32
    //     0x916d3c: sub             w2, w0, w14
    //     0x916d40: add             x14, fp, w2, sxtw #2
    //     0x916d44: ldr             x14, [x14, #8]
    //     0x916d48: add             w2, w13, #2
    //     0x916d4c: sbfx            x13, x2, #1, #0x1f
    //     0x916d50: mov             x2, x13
    //     0x916d54: mov             x13, x14
    //     0x916d58: b               #0x916d60
    //     0x916d5c: add             x13, NULL, #0x30  ; false
    //     0x916d60: lsl             x14, x2, #1
    //     0x916d64: lsl             w19, w14, #1
    //     0x916d68: add             w20, w19, #8
    //     0x916d6c: add             x16, x4, w20, sxtw #1
    //     0x916d70: ldur            w23, [x16, #0xf]
    //     0x916d74: add             x23, x23, HEAP, lsl #32
    //     0x916d78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15138] "focusable"
    //     0x916d7c: ldr             x16, [x16, #0x138]
    //     0x916d80: cmp             w23, w16
    //     0x916d84: b.ne            #0x916db8
    //     0x916d88: add             w2, w19, #0xa
    //     0x916d8c: add             x16, x4, w2, sxtw #1
    //     0x916d90: ldur            w19, [x16, #0xf]
    //     0x916d94: add             x19, x19, HEAP, lsl #32
    //     0x916d98: sub             w2, w0, w19
    //     0x916d9c: add             x19, fp, w2, sxtw #2
    //     0x916da0: ldr             x19, [x19, #8]
    //     0x916da4: add             w2, w14, #2
    //     0x916da8: sbfx            x14, x2, #1, #0x1f
    //     0x916dac: mov             x2, x14
    //     0x916db0: mov             x14, x19
    //     0x916db4: b               #0x916dbc
    //     0x916db8: mov             x14, NULL
    //     0x916dbc: lsl             x19, x2, #1
    //     0x916dc0: lsl             w20, w19, #1
    //     0x916dc4: add             w23, w20, #8
    //     0x916dc8: add             x16, x4, w23, sxtw #1
    //     0x916dcc: ldur            w24, [x16, #0xf]
    //     0x916dd0: add             x24, x24, HEAP, lsl #32
    //     0x916dd4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15140] "focused"
    //     0x916dd8: ldr             x16, [x16, #0x140]
    //     0x916ddc: cmp             w24, w16
    //     0x916de0: b.ne            #0x916e14
    //     0x916de4: add             w2, w20, #0xa
    //     0x916de8: add             x16, x4, w2, sxtw #1
    //     0x916dec: ldur            w20, [x16, #0xf]
    //     0x916df0: add             x20, x20, HEAP, lsl #32
    //     0x916df4: sub             w2, w0, w20
    //     0x916df8: add             x20, fp, w2, sxtw #2
    //     0x916dfc: ldr             x20, [x20, #8]
    //     0x916e00: add             w2, w19, #2
    //     0x916e04: sbfx            x19, x2, #1, #0x1f
    //     0x916e08: mov             x2, x19
    //     0x916e0c: mov             x19, x20
    //     0x916e10: b               #0x916e18
    //     0x916e14: mov             x19, NULL
    //     0x916e18: lsl             x20, x2, #1
    //     0x916e1c: lsl             w23, w20, #1
    //     0x916e20: add             w24, w23, #8
    //     0x916e24: add             x16, x4, w24, sxtw #1
    //     0x916e28: ldur            w25, [x16, #0xf]
    //     0x916e2c: add             x25, x25, HEAP, lsl #32
    //     0x916e30: add             x16, PP, #0x15, lsl #12  ; [pp+0x15148] "header"
    //     0x916e34: ldr             x16, [x16, #0x148]
    //     0x916e38: cmp             w25, w16
    //     0x916e3c: b.ne            #0x916e70
    //     0x916e40: add             w2, w23, #0xa
    //     0x916e44: add             x16, x4, w2, sxtw #1
    //     0x916e48: ldur            w23, [x16, #0xf]
    //     0x916e4c: add             x23, x23, HEAP, lsl #32
    //     0x916e50: sub             w2, w0, w23
    //     0x916e54: add             x23, fp, w2, sxtw #2
    //     0x916e58: ldr             x23, [x23, #8]
    //     0x916e5c: add             w2, w20, #2
    //     0x916e60: sbfx            x20, x2, #1, #0x1f
    //     0x916e64: mov             x2, x20
    //     0x916e68: mov             x20, x23
    //     0x916e6c: b               #0x916e74
    //     0x916e70: mov             x20, NULL
    //     0x916e74: lsl             x23, x2, #1
    //     0x916e78: lsl             w24, w23, #1
    //     0x916e7c: add             w25, w24, #8
    //     0x916e80: add             x16, x4, w25, sxtw #1
    //     0x916e84: ldur            w1, [x16, #0xf]
    //     0x916e88: add             x1, x1, HEAP, lsl #32
    //     0x916e8c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15150] "hint"
    //     0x916e90: ldr             x16, [x16, #0x150]
    //     0x916e94: cmp             w1, w16
    //     0x916e98: b.ne            #0x916ec8
    //     0x916e9c: add             w1, w24, #0xa
    //     0x916ea0: add             x16, x4, w1, sxtw #1
    //     0x916ea4: ldur            w2, [x16, #0xf]
    //     0x916ea8: add             x2, x2, HEAP, lsl #32
    //     0x916eac: sub             w1, w0, w2
    //     0x916eb0: add             x2, fp, w1, sxtw #2
    //     0x916eb4: ldr             x2, [x2, #8]
    //     0x916eb8: add             w1, w23, #2
    //     0x916ebc: sbfx            x23, x1, #1, #0x1f
    //     0x916ec0: mov             x1, x23
    //     0x916ec4: b               #0x916ed0
    //     0x916ec8: mov             x1, x2
    //     0x916ecc: mov             x2, NULL
    //     0x916ed0: lsl             x23, x1, #1
    //     0x916ed4: lsl             w24, w23, #1
    //     0x916ed8: add             w25, w24, #8
    //     0x916edc: add             x16, x4, w25, sxtw #1
    //     0x916ee0: ldur            w3, [x16, #0xf]
    //     0x916ee4: add             x3, x3, HEAP, lsl #32
    //     0x916ee8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15158] "hitTestBehavior"
    //     0x916eec: ldr             x16, [x16, #0x158]
    //     0x916ef0: cmp             w3, w16
    //     0x916ef4: b.ne            #0x916f24
    //     0x916ef8: add             w1, w24, #0xa
    //     0x916efc: add             x16, x4, w1, sxtw #1
    //     0x916f00: ldur            w3, [x16, #0xf]
    //     0x916f04: add             x3, x3, HEAP, lsl #32
    //     0x916f08: sub             w1, w0, w3
    //     0x916f0c: add             x3, fp, w1, sxtw #2
    //     0x916f10: ldr             x3, [x3, #8]
    //     0x916f14: add             w1, w23, #2
    //     0x916f18: sbfx            x23, x1, #1, #0x1f
    //     0x916f1c: mov             x1, x23
    //     0x916f20: b               #0x916f28
    //     0x916f24: mov             x3, NULL
    //     0x916f28: lsl             x23, x1, #1
    //     0x916f2c: lsl             w24, w23, #1
    //     0x916f30: add             w25, w24, #8
    //     0x916f34: add             x16, x4, w25, sxtw #1
    //     0x916f38: ldur            w5, [x16, #0xf]
    //     0x916f3c: add             x5, x5, HEAP, lsl #32
    //     0x916f40: ldr             x16, [PP, #0x6530]  ; [pp+0x6530] "image"
    //     0x916f44: cmp             w5, w16
    //     0x916f48: b.ne            #0x916f78
    //     0x916f4c: add             w1, w24, #0xa
    //     0x916f50: add             x16, x4, w1, sxtw #1
    //     0x916f54: ldur            w5, [x16, #0xf]
    //     0x916f58: add             x5, x5, HEAP, lsl #32
    //     0x916f5c: sub             w1, w0, w5
    //     0x916f60: add             x5, fp, w1, sxtw #2
    //     0x916f64: ldr             x5, [x5, #8]
    //     0x916f68: add             w1, w23, #2
    //     0x916f6c: sbfx            x23, x1, #1, #0x1f
    //     0x916f70: mov             x1, x23
    //     0x916f74: b               #0x916f7c
    //     0x916f78: mov             x5, NULL
    //     0x916f7c: lsl             x23, x1, #1
    //     0x916f80: lsl             w24, w23, #1
    //     0x916f84: add             w25, w24, #8
    //     0x916f88: add             x16, x4, w25, sxtw #1
    //     0x916f8c: ldur            w6, [x16, #0xf]
    //     0x916f90: add             x6, x6, HEAP, lsl #32
    //     0x916f94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15160] "inMutuallyExclusiveGroup"
    //     0x916f98: ldr             x16, [x16, #0x160]
    //     0x916f9c: cmp             w6, w16
    //     0x916fa0: b.ne            #0x916fd0
    //     0x916fa4: add             w1, w24, #0xa
    //     0x916fa8: add             x16, x4, w1, sxtw #1
    //     0x916fac: ldur            w6, [x16, #0xf]
    //     0x916fb0: add             x6, x6, HEAP, lsl #32
    //     0x916fb4: sub             w1, w0, w6
    //     0x916fb8: add             x6, fp, w1, sxtw #2
    //     0x916fbc: ldr             x6, [x6, #8]
    //     0x916fc0: add             w1, w23, #2
    //     0x916fc4: sbfx            x23, x1, #1, #0x1f
    //     0x916fc8: mov             x1, x23
    //     0x916fcc: b               #0x916fd4
    //     0x916fd0: mov             x6, NULL
    //     0x916fd4: lsl             x23, x1, #1
    //     0x916fd8: lsl             w24, w23, #1
    //     0x916fdc: add             w25, w24, #8
    //     0x916fe0: add             x16, x4, w25, sxtw #1
    //     0x916fe4: ldur            w7, [x16, #0xf]
    //     0x916fe8: add             x7, x7, HEAP, lsl #32
    //     0x916fec: ldr             x16, [PP, #0x60f8]  ; [pp+0x60f8] "inputType"
    //     0x916ff0: cmp             w7, w16
    //     0x916ff4: b.ne            #0x917024
    //     0x916ff8: add             w1, w24, #0xa
    //     0x916ffc: add             x16, x4, w1, sxtw #1
    //     0x917000: ldur            w7, [x16, #0xf]
    //     0x917004: add             x7, x7, HEAP, lsl #32
    //     0x917008: sub             w1, w0, w7
    //     0x91700c: add             x7, fp, w1, sxtw #2
    //     0x917010: ldr             x7, [x7, #8]
    //     0x917014: add             w1, w23, #2
    //     0x917018: sbfx            x23, x1, #1, #0x1f
    //     0x91701c: mov             x1, x23
    //     0x917020: b               #0x917028
    //     0x917024: mov             x7, NULL
    //     0x917028: lsl             x23, x1, #1
    //     0x91702c: lsl             w24, w23, #1
    //     0x917030: add             w25, w24, #8
    //     0x917034: add             x16, x4, w25, sxtw #1
    //     0x917038: ldur            w8, [x16, #0xf]
    //     0x91703c: add             x8, x8, HEAP, lsl #32
    //     0x917040: add             x16, PP, #0x15, lsl #12  ; [pp+0x15168] "label"
    //     0x917044: ldr             x16, [x16, #0x168]
    //     0x917048: cmp             w8, w16
    //     0x91704c: b.ne            #0x91707c
    //     0x917050: add             w1, w24, #0xa
    //     0x917054: add             x16, x4, w1, sxtw #1
    //     0x917058: ldur            w8, [x16, #0xf]
    //     0x91705c: add             x8, x8, HEAP, lsl #32
    //     0x917060: sub             w1, w0, w8
    //     0x917064: add             x8, fp, w1, sxtw #2
    //     0x917068: ldr             x8, [x8, #8]
    //     0x91706c: add             w1, w23, #2
    //     0x917070: sbfx            x23, x1, #1, #0x1f
    //     0x917074: mov             x1, x23
    //     0x917078: b               #0x917080
    //     0x91707c: mov             x8, NULL
    //     0x917080: stur            x8, [fp, #-0x38]
    //     0x917084: lsl             x23, x1, #1
    //     0x917088: lsl             w24, w23, #1
    //     0x91708c: add             w25, w24, #8
    //     0x917090: add             x16, x4, w25, sxtw #1
    //     0x917094: ldur            w8, [x16, #0xf]
    //     0x917098: add             x8, x8, HEAP, lsl #32
    //     0x91709c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15170] "liveRegion"
    //     0x9170a0: ldr             x16, [x16, #0x170]
    //     0x9170a4: cmp             w8, w16
    //     0x9170a8: b.ne            #0x9170d8
    //     0x9170ac: add             w1, w24, #0xa
    //     0x9170b0: add             x16, x4, w1, sxtw #1
    //     0x9170b4: ldur            w8, [x16, #0xf]
    //     0x9170b8: add             x8, x8, HEAP, lsl #32
    //     0x9170bc: sub             w1, w0, w8
    //     0x9170c0: add             x8, fp, w1, sxtw #2
    //     0x9170c4: ldr             x8, [x8, #8]
    //     0x9170c8: add             w1, w23, #2
    //     0x9170cc: sbfx            x23, x1, #1, #0x1f
    //     0x9170d0: mov             x1, x23
    //     0x9170d4: b               #0x9170dc
    //     0x9170d8: mov             x8, NULL
    //     0x9170dc: stur            x8, [fp, #-0x40]
    //     0x9170e0: lsl             x23, x1, #1
    //     0x9170e4: lsl             w24, w23, #1
    //     0x9170e8: add             w25, w24, #8
    //     0x9170ec: add             x16, x4, w25, sxtw #1
    //     0x9170f0: ldur            w8, [x16, #0xf]
    //     0x9170f4: add             x8, x8, HEAP, lsl #32
    //     0x9170f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15178] "localeForSubtree"
    //     0x9170fc: ldr             x16, [x16, #0x178]
    //     0x917100: cmp             w8, w16
    //     0x917104: b.ne            #0x917134
    //     0x917108: add             w1, w24, #0xa
    //     0x91710c: add             x16, x4, w1, sxtw #1
    //     0x917110: ldur            w8, [x16, #0xf]
    //     0x917114: add             x8, x8, HEAP, lsl #32
    //     0x917118: sub             w1, w0, w8
    //     0x91711c: add             x8, fp, w1, sxtw #2
    //     0x917120: ldr             x8, [x8, #8]
    //     0x917124: add             w1, w23, #2
    //     0x917128: sbfx            x23, x1, #1, #0x1f
    //     0x91712c: mov             x1, x23
    //     0x917130: b               #0x917138
    //     0x917134: mov             x8, NULL
    //     0x917138: stur            x8, [fp, #-0x48]
    //     0x91713c: lsl             x23, x1, #1
    //     0x917140: lsl             w24, w23, #1
    //     0x917144: add             w25, w24, #8
    //     0x917148: add             x16, x4, w25, sxtw #1
    //     0x91714c: ldur            w8, [x16, #0xf]
    //     0x917150: add             x8, x8, HEAP, lsl #32
    //     0x917154: add             x16, PP, #0x15, lsl #12  ; [pp+0x15180] "maxValue"
    //     0x917158: ldr             x16, [x16, #0x180]
    //     0x91715c: cmp             w8, w16
    //     0x917160: b.ne            #0x917190
    //     0x917164: add             w1, w24, #0xa
    //     0x917168: add             x16, x4, w1, sxtw #1
    //     0x91716c: ldur            w8, [x16, #0xf]
    //     0x917170: add             x8, x8, HEAP, lsl #32
    //     0x917174: sub             w1, w0, w8
    //     0x917178: add             x8, fp, w1, sxtw #2
    //     0x91717c: ldr             x8, [x8, #8]
    //     0x917180: add             w1, w23, #2
    //     0x917184: sbfx            x23, x1, #1, #0x1f
    //     0x917188: mov             x1, x23
    //     0x91718c: b               #0x917194
    //     0x917190: mov             x8, NULL
    //     0x917194: stur            x8, [fp, #-0x50]
    //     0x917198: lsl             x23, x1, #1
    //     0x91719c: lsl             w24, w23, #1
    //     0x9171a0: add             w25, w24, #8
    //     0x9171a4: add             x16, x4, w25, sxtw #1
    //     0x9171a8: ldur            w8, [x16, #0xf]
    //     0x9171ac: add             x8, x8, HEAP, lsl #32
    //     0x9171b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15188] "maxValueLength"
    //     0x9171b4: ldr             x16, [x16, #0x188]
    //     0x9171b8: cmp             w8, w16
    //     0x9171bc: b.ne            #0x9171ec
    //     0x9171c0: add             w1, w24, #0xa
    //     0x9171c4: add             x16, x4, w1, sxtw #1
    //     0x9171c8: ldur            w8, [x16, #0xf]
    //     0x9171cc: add             x8, x8, HEAP, lsl #32
    //     0x9171d0: sub             w1, w0, w8
    //     0x9171d4: add             x8, fp, w1, sxtw #2
    //     0x9171d8: ldr             x8, [x8, #8]
    //     0x9171dc: add             w1, w23, #2
    //     0x9171e0: sbfx            x23, x1, #1, #0x1f
    //     0x9171e4: mov             x1, x23
    //     0x9171e8: b               #0x9171f0
    //     0x9171ec: mov             x8, NULL
    //     0x9171f0: stur            x8, [fp, #-0x58]
    //     0x9171f4: lsl             x23, x1, #1
    //     0x9171f8: lsl             w24, w23, #1
    //     0x9171fc: add             w25, w24, #8
    //     0x917200: add             x16, x4, w25, sxtw #1
    //     0x917204: ldur            w8, [x16, #0xf]
    //     0x917208: add             x8, x8, HEAP, lsl #32
    //     0x91720c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15190] "minValue"
    //     0x917210: ldr             x16, [x16, #0x190]
    //     0x917214: cmp             w8, w16
    //     0x917218: b.ne            #0x917248
    //     0x91721c: add             w1, w24, #0xa
    //     0x917220: add             x16, x4, w1, sxtw #1
    //     0x917224: ldur            w8, [x16, #0xf]
    //     0x917228: add             x8, x8, HEAP, lsl #32
    //     0x91722c: sub             w1, w0, w8
    //     0x917230: add             x8, fp, w1, sxtw #2
    //     0x917234: ldr             x8, [x8, #8]
    //     0x917238: add             w1, w23, #2
    //     0x91723c: sbfx            x23, x1, #1, #0x1f
    //     0x917240: mov             x1, x23
    //     0x917244: b               #0x91724c
    //     0x917248: mov             x8, NULL
    //     0x91724c: stur            x8, [fp, #-0x60]
    //     0x917250: lsl             x23, x1, #1
    //     0x917254: lsl             w24, w23, #1
    //     0x917258: add             w25, w24, #8
    //     0x91725c: add             x16, x4, w25, sxtw #1
    //     0x917260: ldur            w8, [x16, #0xf]
    //     0x917264: add             x8, x8, HEAP, lsl #32
    //     0x917268: add             x16, PP, #0x15, lsl #12  ; [pp+0x15198] "mixed"
    //     0x91726c: ldr             x16, [x16, #0x198]
    //     0x917270: cmp             w8, w16
    //     0x917274: b.ne            #0x9172a4
    //     0x917278: add             w1, w24, #0xa
    //     0x91727c: add             x16, x4, w1, sxtw #1
    //     0x917280: ldur            w8, [x16, #0xf]
    //     0x917284: add             x8, x8, HEAP, lsl #32
    //     0x917288: sub             w1, w0, w8
    //     0x91728c: add             x8, fp, w1, sxtw #2
    //     0x917290: ldr             x8, [x8, #8]
    //     0x917294: add             w1, w23, #2
    //     0x917298: sbfx            x23, x1, #1, #0x1f
    //     0x91729c: mov             x1, x23
    //     0x9172a0: b               #0x9172a8
    //     0x9172a4: mov             x8, NULL
    //     0x9172a8: stur            x8, [fp, #-0x68]
    //     0x9172ac: lsl             x23, x1, #1
    //     0x9172b0: lsl             w24, w23, #1
    //     0x9172b4: add             w25, w24, #8
    //     0x9172b8: add             x16, x4, w25, sxtw #1
    //     0x9172bc: ldur            w8, [x16, #0xf]
    //     0x9172c0: add             x8, x8, HEAP, lsl #32
    //     0x9172c4: ldr             x16, [PP, #0x2818]  ; [pp+0x2818] "namesRoute"
    //     0x9172c8: cmp             w8, w16
    //     0x9172cc: b.ne            #0x9172fc
    //     0x9172d0: add             w1, w24, #0xa
    //     0x9172d4: add             x16, x4, w1, sxtw #1
    //     0x9172d8: ldur            w8, [x16, #0xf]
    //     0x9172dc: add             x8, x8, HEAP, lsl #32
    //     0x9172e0: sub             w1, w0, w8
    //     0x9172e4: add             x8, fp, w1, sxtw #2
    //     0x9172e8: ldr             x8, [x8, #8]
    //     0x9172ec: add             w1, w23, #2
    //     0x9172f0: sbfx            x23, x1, #1, #0x1f
    //     0x9172f4: mov             x1, x23
    //     0x9172f8: b               #0x917300
    //     0x9172fc: mov             x8, NULL
    //     0x917300: stur            x8, [fp, #-0x70]
    //     0x917304: lsl             x23, x1, #1
    //     0x917308: lsl             w24, w23, #1
    //     0x91730c: add             w25, w24, #8
    //     0x917310: add             x16, x4, w25, sxtw #1
    //     0x917314: ldur            w8, [x16, #0xf]
    //     0x917318: add             x8, x8, HEAP, lsl #32
    //     0x91731c: add             x16, PP, #0x15, lsl #12  ; [pp+0x151a0] "onCopy"
    //     0x917320: ldr             x16, [x16, #0x1a0]
    //     0x917324: cmp             w8, w16
    //     0x917328: b.ne            #0x917358
    //     0x91732c: add             w1, w24, #0xa
    //     0x917330: add             x16, x4, w1, sxtw #1
    //     0x917334: ldur            w8, [x16, #0xf]
    //     0x917338: add             x8, x8, HEAP, lsl #32
    //     0x91733c: sub             w1, w0, w8
    //     0x917340: add             x8, fp, w1, sxtw #2
    //     0x917344: ldr             x8, [x8, #8]
    //     0x917348: add             w1, w23, #2
    //     0x91734c: sbfx            x23, x1, #1, #0x1f
    //     0x917350: mov             x1, x23
    //     0x917354: b               #0x91735c
    //     0x917358: mov             x8, NULL
    //     0x91735c: stur            x8, [fp, #-0x78]
    //     0x917360: lsl             x23, x1, #1
    //     0x917364: lsl             w24, w23, #1
    //     0x917368: add             w25, w24, #8
    //     0x91736c: add             x16, x4, w25, sxtw #1
    //     0x917370: ldur            w8, [x16, #0xf]
    //     0x917374: add             x8, x8, HEAP, lsl #32
    //     0x917378: add             x16, PP, #0x15, lsl #12  ; [pp+0x151a8] "onCut"
    //     0x91737c: ldr             x16, [x16, #0x1a8]
    //     0x917380: cmp             w8, w16
    //     0x917384: b.ne            #0x9173b4
    //     0x917388: add             w1, w24, #0xa
    //     0x91738c: add             x16, x4, w1, sxtw #1
    //     0x917390: ldur            w8, [x16, #0xf]
    //     0x917394: add             x8, x8, HEAP, lsl #32
    //     0x917398: sub             w1, w0, w8
    //     0x91739c: add             x8, fp, w1, sxtw #2
    //     0x9173a0: ldr             x8, [x8, #8]
    //     0x9173a4: add             w1, w23, #2
    //     0x9173a8: sbfx            x23, x1, #1, #0x1f
    //     0x9173ac: mov             x1, x23
    //     0x9173b0: b               #0x9173b8
    //     0x9173b4: mov             x8, NULL
    //     0x9173b8: stur            x8, [fp, #-0x80]
    //     0x9173bc: lsl             x23, x1, #1
    //     0x9173c0: lsl             w24, w23, #1
    //     0x9173c4: add             w25, w24, #8
    //     0x9173c8: add             x16, x4, w25, sxtw #1
    //     0x9173cc: ldur            w8, [x16, #0xf]
    //     0x9173d0: add             x8, x8, HEAP, lsl #32
    //     0x9173d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x151b0] "onDidGainAccessibilityFocus"
    //     0x9173d8: ldr             x16, [x16, #0x1b0]
    //     0x9173dc: cmp             w8, w16
    //     0x9173e0: b.ne            #0x917410
    //     0x9173e4: add             w1, w24, #0xa
    //     0x9173e8: add             x16, x4, w1, sxtw #1
    //     0x9173ec: ldur            w8, [x16, #0xf]
    //     0x9173f0: add             x8, x8, HEAP, lsl #32
    //     0x9173f4: sub             w1, w0, w8
    //     0x9173f8: add             x8, fp, w1, sxtw #2
    //     0x9173fc: ldr             x8, [x8, #8]
    //     0x917400: add             w1, w23, #2
    //     0x917404: sbfx            x23, x1, #1, #0x1f
    //     0x917408: mov             x1, x23
    //     0x91740c: b               #0x917414
    //     0x917410: mov             x8, NULL
    //     0x917414: stur            x8, [fp, #-0x88]
    //     0x917418: lsl             x23, x1, #1
    //     0x91741c: lsl             w24, w23, #1
    //     0x917420: add             w25, w24, #8
    //     0x917424: add             x16, x4, w25, sxtw #1
    //     0x917428: ldur            w8, [x16, #0xf]
    //     0x91742c: add             x8, x8, HEAP, lsl #32
    //     0x917430: add             x16, PP, #0x15, lsl #12  ; [pp+0x151b8] "onDidLoseAccessibilityFocus"
    //     0x917434: ldr             x16, [x16, #0x1b8]
    //     0x917438: cmp             w8, w16
    //     0x91743c: b.ne            #0x91746c
    //     0x917440: add             w1, w24, #0xa
    //     0x917444: add             x16, x4, w1, sxtw #1
    //     0x917448: ldur            w8, [x16, #0xf]
    //     0x91744c: add             x8, x8, HEAP, lsl #32
    //     0x917450: sub             w1, w0, w8
    //     0x917454: add             x8, fp, w1, sxtw #2
    //     0x917458: ldr             x8, [x8, #8]
    //     0x91745c: add             w1, w23, #2
    //     0x917460: sbfx            x23, x1, #1, #0x1f
    //     0x917464: mov             x1, x23
    //     0x917468: b               #0x917470
    //     0x91746c: mov             x8, NULL
    //     0x917470: stur            x8, [fp, #-0x90]
    //     0x917474: lsl             x23, x1, #1
    //     0x917478: lsl             w24, w23, #1
    //     0x91747c: add             w25, w24, #8
    //     0x917480: add             x16, x4, w25, sxtw #1
    //     0x917484: ldur            w8, [x16, #0xf]
    //     0x917488: add             x8, x8, HEAP, lsl #32
    //     0x91748c: add             x16, PP, #0x15, lsl #12  ; [pp+0x151c0] "onDismiss"
    //     0x917490: ldr             x16, [x16, #0x1c0]
    //     0x917494: cmp             w8, w16
    //     0x917498: b.ne            #0x9174c8
    //     0x91749c: add             w1, w24, #0xa
    //     0x9174a0: add             x16, x4, w1, sxtw #1
    //     0x9174a4: ldur            w8, [x16, #0xf]
    //     0x9174a8: add             x8, x8, HEAP, lsl #32
    //     0x9174ac: sub             w1, w0, w8
    //     0x9174b0: add             x8, fp, w1, sxtw #2
    //     0x9174b4: ldr             x8, [x8, #8]
    //     0x9174b8: add             w1, w23, #2
    //     0x9174bc: sbfx            x23, x1, #1, #0x1f
    //     0x9174c0: mov             x1, x23
    //     0x9174c4: b               #0x9174cc
    //     0x9174c8: mov             x8, NULL
    //     0x9174cc: stur            x8, [fp, #-0x98]
    //     0x9174d0: lsl             x23, x1, #1
    //     0x9174d4: lsl             w24, w23, #1
    //     0x9174d8: add             w25, w24, #8
    //     0x9174dc: add             x16, x4, w25, sxtw #1
    //     0x9174e0: ldur            w8, [x16, #0xf]
    //     0x9174e4: add             x8, x8, HEAP, lsl #32
    //     0x9174e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x151c8] "onFocus"
    //     0x9174ec: ldr             x16, [x16, #0x1c8]
    //     0x9174f0: cmp             w8, w16
    //     0x9174f4: b.ne            #0x917524
    //     0x9174f8: add             w1, w24, #0xa
    //     0x9174fc: add             x16, x4, w1, sxtw #1
    //     0x917500: ldur            w8, [x16, #0xf]
    //     0x917504: add             x8, x8, HEAP, lsl #32
    //     0x917508: sub             w1, w0, w8
    //     0x91750c: add             x8, fp, w1, sxtw #2
    //     0x917510: ldr             x8, [x8, #8]
    //     0x917514: add             w1, w23, #2
    //     0x917518: sbfx            x23, x1, #1, #0x1f
    //     0x91751c: mov             x1, x23
    //     0x917520: b               #0x917528
    //     0x917524: mov             x8, NULL
    //     0x917528: stur            x8, [fp, #-0xa0]
    //     0x91752c: lsl             x23, x1, #1
    //     0x917530: lsl             w24, w23, #1
    //     0x917534: add             w25, w24, #8
    //     0x917538: add             x16, x4, w25, sxtw #1
    //     0x91753c: ldur            w8, [x16, #0xf]
    //     0x917540: add             x8, x8, HEAP, lsl #32
    //     0x917544: add             x16, PP, #0x15, lsl #12  ; [pp+0x151d0] "onLongPress"
    //     0x917548: ldr             x16, [x16, #0x1d0]
    //     0x91754c: cmp             w8, w16
    //     0x917550: b.ne            #0x917580
    //     0x917554: add             w1, w24, #0xa
    //     0x917558: add             x16, x4, w1, sxtw #1
    //     0x91755c: ldur            w8, [x16, #0xf]
    //     0x917560: add             x8, x8, HEAP, lsl #32
    //     0x917564: sub             w1, w0, w8
    //     0x917568: add             x8, fp, w1, sxtw #2
    //     0x91756c: ldr             x8, [x8, #8]
    //     0x917570: add             w1, w23, #2
    //     0x917574: sbfx            x23, x1, #1, #0x1f
    //     0x917578: mov             x1, x23
    //     0x91757c: b               #0x917584
    //     0x917580: mov             x8, NULL
    //     0x917584: stur            x8, [fp, #-0xa8]
    //     0x917588: lsl             x23, x1, #1
    //     0x91758c: lsl             w24, w23, #1
    //     0x917590: add             w25, w24, #8
    //     0x917594: add             x16, x4, w25, sxtw #1
    //     0x917598: ldur            w8, [x16, #0xf]
    //     0x91759c: add             x8, x8, HEAP, lsl #32
    //     0x9175a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x151d8] "onPaste"
    //     0x9175a4: ldr             x16, [x16, #0x1d8]
    //     0x9175a8: cmp             w8, w16
    //     0x9175ac: b.ne            #0x9175dc
    //     0x9175b0: add             w1, w24, #0xa
    //     0x9175b4: add             x16, x4, w1, sxtw #1
    //     0x9175b8: ldur            w8, [x16, #0xf]
    //     0x9175bc: add             x8, x8, HEAP, lsl #32
    //     0x9175c0: sub             w1, w0, w8
    //     0x9175c4: add             x8, fp, w1, sxtw #2
    //     0x9175c8: ldr             x8, [x8, #8]
    //     0x9175cc: add             w1, w23, #2
    //     0x9175d0: sbfx            x23, x1, #1, #0x1f
    //     0x9175d4: mov             x1, x23
    //     0x9175d8: b               #0x9175e0
    //     0x9175dc: mov             x8, NULL
    //     0x9175e0: stur            x8, [fp, #-0xb0]
    //     0x9175e4: lsl             x23, x1, #1
    //     0x9175e8: lsl             w24, w23, #1
    //     0x9175ec: add             w25, w24, #8
    //     0x9175f0: add             x16, x4, w25, sxtw #1
    //     0x9175f4: ldur            w8, [x16, #0xf]
    //     0x9175f8: add             x8, x8, HEAP, lsl #32
    //     0x9175fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x151e0] "onTap"
    //     0x917600: ldr             x16, [x16, #0x1e0]
    //     0x917604: cmp             w8, w16
    //     0x917608: b.ne            #0x917638
    //     0x91760c: add             w1, w24, #0xa
    //     0x917610: add             x16, x4, w1, sxtw #1
    //     0x917614: ldur            w8, [x16, #0xf]
    //     0x917618: add             x8, x8, HEAP, lsl #32
    //     0x91761c: sub             w1, w0, w8
    //     0x917620: add             x8, fp, w1, sxtw #2
    //     0x917624: ldr             x8, [x8, #8]
    //     0x917628: add             w1, w23, #2
    //     0x91762c: sbfx            x23, x1, #1, #0x1f
    //     0x917630: mov             x1, x23
    //     0x917634: b               #0x91763c
    //     0x917638: mov             x8, NULL
    //     0x91763c: stur            x8, [fp, #-0xb8]
    //     0x917640: lsl             x23, x1, #1
    //     0x917644: lsl             w24, w23, #1
    //     0x917648: add             w25, w24, #8
    //     0x91764c: add             x16, x4, w25, sxtw #1
    //     0x917650: ldur            w8, [x16, #0xf]
    //     0x917654: add             x8, x8, HEAP, lsl #32
    //     0x917658: add             x16, PP, #0x15, lsl #12  ; [pp+0x151e8] "onTapHint"
    //     0x91765c: ldr             x16, [x16, #0x1e8]
    //     0x917660: cmp             w8, w16
    //     0x917664: b.ne            #0x917694
    //     0x917668: add             w1, w24, #0xa
    //     0x91766c: add             x16, x4, w1, sxtw #1
    //     0x917670: ldur            w8, [x16, #0xf]
    //     0x917674: add             x8, x8, HEAP, lsl #32
    //     0x917678: sub             w1, w0, w8
    //     0x91767c: add             x8, fp, w1, sxtw #2
    //     0x917680: ldr             x8, [x8, #8]
    //     0x917684: add             w1, w23, #2
    //     0x917688: sbfx            x23, x1, #1, #0x1f
    //     0x91768c: mov             x1, x23
    //     0x917690: b               #0x917698
    //     0x917694: mov             x8, NULL
    //     0x917698: stur            x8, [fp, #-0xc0]
    //     0x91769c: lsl             x23, x1, #1
    //     0x9176a0: lsl             w24, w23, #1
    //     0x9176a4: add             w25, w24, #8
    //     0x9176a8: add             x16, x4, w25, sxtw #1
    //     0x9176ac: ldur            w8, [x16, #0xf]
    //     0x9176b0: add             x8, x8, HEAP, lsl #32
    //     0x9176b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x151f0] "role"
    //     0x9176b8: ldr             x16, [x16, #0x1f0]
    //     0x9176bc: cmp             w8, w16
    //     0x9176c0: b.ne            #0x9176f0
    //     0x9176c4: add             w1, w24, #0xa
    //     0x9176c8: add             x16, x4, w1, sxtw #1
    //     0x9176cc: ldur            w8, [x16, #0xf]
    //     0x9176d0: add             x8, x8, HEAP, lsl #32
    //     0x9176d4: sub             w1, w0, w8
    //     0x9176d8: add             x8, fp, w1, sxtw #2
    //     0x9176dc: ldr             x8, [x8, #8]
    //     0x9176e0: add             w1, w23, #2
    //     0x9176e4: sbfx            x23, x1, #1, #0x1f
    //     0x9176e8: mov             x1, x23
    //     0x9176ec: b               #0x9176f4
    //     0x9176f0: mov             x8, NULL
    //     0x9176f4: stur            x8, [fp, #-0xc8]
    //     0x9176f8: lsl             x23, x1, #1
    //     0x9176fc: lsl             w24, w23, #1
    //     0x917700: add             w25, w24, #8
    //     0x917704: add             x16, x4, w25, sxtw #1
    //     0x917708: ldur            w8, [x16, #0xf]
    //     0x91770c: add             x8, x8, HEAP, lsl #32
    //     0x917710: ldr             x16, [PP, #0x2820]  ; [pp+0x2820] "scopesRoute"
    //     0x917714: cmp             w8, w16
    //     0x917718: b.ne            #0x917748
    //     0x91771c: add             w1, w24, #0xa
    //     0x917720: add             x16, x4, w1, sxtw #1
    //     0x917724: ldur            w8, [x16, #0xf]
    //     0x917728: add             x8, x8, HEAP, lsl #32
    //     0x91772c: sub             w1, w0, w8
    //     0x917730: add             x8, fp, w1, sxtw #2
    //     0x917734: ldr             x8, [x8, #8]
    //     0x917738: add             w1, w23, #2
    //     0x91773c: sbfx            x23, x1, #1, #0x1f
    //     0x917740: mov             x1, x23
    //     0x917744: b               #0x91774c
    //     0x917748: mov             x8, NULL
    //     0x91774c: stur            x8, [fp, #-0xd0]
    //     0x917750: lsl             x23, x1, #1
    //     0x917754: lsl             w24, w23, #1
    //     0x917758: add             w25, w24, #8
    //     0x91775c: add             x16, x4, w25, sxtw #1
    //     0x917760: ldur            w8, [x16, #0xf]
    //     0x917764: add             x8, x8, HEAP, lsl #32
    //     0x917768: add             x16, PP, #0x15, lsl #12  ; [pp+0x151f8] "selected"
    //     0x91776c: ldr             x16, [x16, #0x1f8]
    //     0x917770: cmp             w8, w16
    //     0x917774: b.ne            #0x9177a4
    //     0x917778: add             w1, w24, #0xa
    //     0x91777c: add             x16, x4, w1, sxtw #1
    //     0x917780: ldur            w8, [x16, #0xf]
    //     0x917784: add             x8, x8, HEAP, lsl #32
    //     0x917788: sub             w1, w0, w8
    //     0x91778c: add             x8, fp, w1, sxtw #2
    //     0x917790: ldr             x8, [x8, #8]
    //     0x917794: add             w1, w23, #2
    //     0x917798: sbfx            x23, x1, #1, #0x1f
    //     0x91779c: mov             x1, x23
    //     0x9177a0: b               #0x9177a8
    //     0x9177a4: mov             x8, NULL
    //     0x9177a8: stur            x8, [fp, #-0xd8]
    //     0x9177ac: lsl             x23, x1, #1
    //     0x9177b0: lsl             w24, w23, #1
    //     0x9177b4: add             w25, w24, #8
    //     0x9177b8: add             x16, x4, w25, sxtw #1
    //     0x9177bc: ldur            w8, [x16, #0xf]
    //     0x9177c0: add             x8, x8, HEAP, lsl #32
    //     0x9177c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15200] "sortKey"
    //     0x9177c8: ldr             x16, [x16, #0x200]
    //     0x9177cc: cmp             w8, w16
    //     0x9177d0: b.ne            #0x917800
    //     0x9177d4: add             w1, w24, #0xa
    //     0x9177d8: add             x16, x4, w1, sxtw #1
    //     0x9177dc: ldur            w8, [x16, #0xf]
    //     0x9177e0: add             x8, x8, HEAP, lsl #32
    //     0x9177e4: sub             w1, w0, w8
    //     0x9177e8: add             x8, fp, w1, sxtw #2
    //     0x9177ec: ldr             x8, [x8, #8]
    //     0x9177f0: add             w1, w23, #2
    //     0x9177f4: sbfx            x23, x1, #1, #0x1f
    //     0x9177f8: mov             x1, x23
    //     0x9177fc: b               #0x917804
    //     0x917800: mov             x8, NULL
    //     0x917804: stur            x8, [fp, #-0xe0]
    //     0x917808: lsl             x23, x1, #1
    //     0x91780c: lsl             w24, w23, #1
    //     0x917810: add             w25, w24, #8
    //     0x917814: add             x16, x4, w25, sxtw #1
    //     0x917818: ldur            w8, [x16, #0xf]
    //     0x91781c: add             x8, x8, HEAP, lsl #32
    //     0x917820: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] "tagForChildren"
    //     0x917824: ldr             x16, [x16, #0x208]
    //     0x917828: cmp             w8, w16
    //     0x91782c: b.ne            #0x91785c
    //     0x917830: add             w1, w24, #0xa
    //     0x917834: add             x16, x4, w1, sxtw #1
    //     0x917838: ldur            w8, [x16, #0xf]
    //     0x91783c: add             x8, x8, HEAP, lsl #32
    //     0x917840: sub             w1, w0, w8
    //     0x917844: add             x8, fp, w1, sxtw #2
    //     0x917848: ldr             x8, [x8, #8]
    //     0x91784c: add             w1, w23, #2
    //     0x917850: sbfx            x23, x1, #1, #0x1f
    //     0x917854: mov             x1, x23
    //     0x917858: b               #0x917860
    //     0x91785c: mov             x8, NULL
    //     0x917860: stur            x8, [fp, #-0xe8]
    //     0x917864: lsl             x23, x1, #1
    //     0x917868: lsl             w24, w23, #1
    //     0x91786c: add             w25, w24, #8
    //     0x917870: add             x16, x4, w25, sxtw #1
    //     0x917874: ldur            w8, [x16, #0xf]
    //     0x917878: add             x8, x8, HEAP, lsl #32
    //     0x91787c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x917880: ldr             x16, [x16, #0x210]
    //     0x917884: cmp             w8, w16
    //     0x917888: b.ne            #0x9178b8
    //     0x91788c: add             w1, w24, #0xa
    //     0x917890: add             x16, x4, w1, sxtw #1
    //     0x917894: ldur            w8, [x16, #0xf]
    //     0x917898: add             x8, x8, HEAP, lsl #32
    //     0x91789c: sub             w1, w0, w8
    //     0x9178a0: add             x8, fp, w1, sxtw #2
    //     0x9178a4: ldr             x8, [x8, #8]
    //     0x9178a8: add             w1, w23, #2
    //     0x9178ac: sbfx            x23, x1, #1, #0x1f
    //     0x9178b0: mov             x1, x23
    //     0x9178b4: b               #0x9178bc
    //     0x9178b8: mov             x8, NULL
    //     0x9178bc: stur            x8, [fp, #-0xf0]
    //     0x9178c0: lsl             x23, x1, #1
    //     0x9178c4: lsl             w24, w23, #1
    //     0x9178c8: add             w25, w24, #8
    //     0x9178cc: add             x16, x4, w25, sxtw #1
    //     0x9178d0: ldur            w8, [x16, #0xf]
    //     0x9178d4: add             x8, x8, HEAP, lsl #32
    //     0x9178d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15218] "toggled"
    //     0x9178dc: ldr             x16, [x16, #0x218]
    //     0x9178e0: cmp             w8, w16
    //     0x9178e4: b.ne            #0x917914
    //     0x9178e8: add             w1, w24, #0xa
    //     0x9178ec: add             x16, x4, w1, sxtw #1
    //     0x9178f0: ldur            w8, [x16, #0xf]
    //     0x9178f4: add             x8, x8, HEAP, lsl #32
    //     0x9178f8: sub             w1, w0, w8
    //     0x9178fc: add             x8, fp, w1, sxtw #2
    //     0x917900: ldr             x8, [x8, #8]
    //     0x917904: add             w1, w23, #2
    //     0x917908: sbfx            x23, x1, #1, #0x1f
    //     0x91790c: mov             x1, x23
    //     0x917910: b               #0x917918
    //     0x917914: mov             x8, NULL
    //     0x917918: stur            x8, [fp, #-0xf8]
    //     0x91791c: lsl             x23, x1, #1
    //     0x917920: lsl             w24, w23, #1
    //     0x917924: add             w25, w24, #8
    //     0x917928: add             x16, x4, w25, sxtw #1
    //     0x91792c: ldur            w8, [x16, #0xf]
    //     0x917930: add             x8, x8, HEAP, lsl #32
    //     0x917934: add             x16, PP, #0x15, lsl #12  ; [pp+0x15220] "tooltip"
    //     0x917938: ldr             x16, [x16, #0x220]
    //     0x91793c: cmp             w8, w16
    //     0x917940: b.ne            #0x917970
    //     0x917944: add             w1, w24, #0xa
    //     0x917948: add             x16, x4, w1, sxtw #1
    //     0x91794c: ldur            w8, [x16, #0xf]
    //     0x917950: add             x8, x8, HEAP, lsl #32
    //     0x917954: sub             w1, w0, w8
    //     0x917958: add             x8, fp, w1, sxtw #2
    //     0x91795c: ldr             x8, [x8, #8]
    //     0x917960: add             w1, w23, #2
    //     0x917964: sbfx            x23, x1, #1, #0x1f
    //     0x917968: mov             x1, x23
    //     0x91796c: b               #0x917974
    //     0x917970: mov             x8, NULL
    //     0x917974: stur            x8, [fp, #-0x100]
    //     0x917978: lsl             x23, x1, #1
    //     0x91797c: lsl             w24, w23, #1
    //     0x917980: add             w25, w24, #8
    //     0x917984: add             x16, x4, w25, sxtw #1
    //     0x917988: ldur            w8, [x16, #0xf]
    //     0x91798c: add             x8, x8, HEAP, lsl #32
    //     0x917990: add             x16, PP, #0x15, lsl #12  ; [pp+0x15228] "traversalParentIdentifier"
    //     0x917994: ldr             x16, [x16, #0x228]
    //     0x917998: cmp             w8, w16
    //     0x91799c: b.ne            #0x9179cc
    //     0x9179a0: add             w1, w24, #0xa
    //     0x9179a4: add             x16, x4, w1, sxtw #1
    //     0x9179a8: ldur            w8, [x16, #0xf]
    //     0x9179ac: add             x8, x8, HEAP, lsl #32
    //     0x9179b0: sub             w1, w0, w8
    //     0x9179b4: add             x8, fp, w1, sxtw #2
    //     0x9179b8: ldr             x8, [x8, #8]
    //     0x9179bc: add             w1, w23, #2
    //     0x9179c0: sbfx            x23, x1, #1, #0x1f
    //     0x9179c4: mov             x1, x23
    //     0x9179c8: b               #0x9179d0
    //     0x9179cc: mov             x8, NULL
    //     0x9179d0: mov             x17, #-0x108
    // 0x9179d0: r17 = -264
    // 0x9179d4: str             x8, [fp, x17]
    // 0x9179d8: lsl             x23, x1, #1
    // 0x9179dc: lsl             w24, w23, #1
    // 0x9179e0: add             w25, w24, #8
    // 0x9179e4: ArrayLoad: r8 = r4[r25]  ; Unknown_4
    //     0x9179e4: add             x16, x4, w25, sxtw #1
    //     0x9179e8: ldur            w8, [x16, #0xf]
    // 0x9179ec: DecompressPointer r8
    //     0x9179ec: add             x8, x8, HEAP, lsl #32
    // 0x9179f0: r16 = "validationResult"
    //     0x9179f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15230] "validationResult"
    //     0x9179f4: ldr             x16, [x16, #0x230]
    // 0x9179f8: cmp             w8, w16
    // 0x9179fc: b.ne            #0x917a2c
    // 0x917a00: add             w1, w24, #0xa
    // 0x917a04: ArrayLoad: r8 = r4[r1]  ; Unknown_4
    //     0x917a04: add             x16, x4, w1, sxtw #1
    //     0x917a08: ldur            w8, [x16, #0xf]
    // 0x917a0c: DecompressPointer r8
    //     0x917a0c: add             x8, x8, HEAP, lsl #32
    // 0x917a10: sub             w1, w0, w8
    // 0x917a14: add             x8, fp, w1, sxtw #2
    // 0x917a18: ldr             x8, [x8, #8]
    // 0x917a1c: add             w1, w23, #2
    // 0x917a20: r23 = LoadInt32Instr(r1)
    //     0x917a20: sbfx            x23, x1, #1, #0x1f
    // 0x917a24: mov             x1, x23
    // 0x917a28: b               #0x917a30
    // 0x917a2c: r8 = Instance_SemanticsValidationResult
    //     0x917a2c: ldr             x8, [PP, #0x26f0]  ; [pp+0x26f0] Obj!SemanticsValidationResult@12c75e1
    // 0x917a30: lsl             x23, x1, #1
    // 0x917a34: lsl             w1, w23, #1
    // 0x917a38: add             w23, w1, #8
    // 0x917a3c: ArrayLoad: r24 = r4[r23]  ; Unknown_4
    //     0x917a3c: add             x16, x4, w23, sxtw #1
    //     0x917a40: ldur            w24, [x16, #0xf]
    // 0x917a44: DecompressPointer r24
    //     0x917a44: add             x24, x24, HEAP, lsl #32
    // 0x917a48: r16 = "value"
    //     0x917a48: ldr             x16, [PP, #0x50c8]  ; [pp+0x50c8] "value"
    // 0x917a4c: cmp             w24, w16
    // 0x917a50: b.ne            #0x917a74
    // 0x917a54: add             w23, w1, #0xa
    // 0x917a58: ArrayLoad: r1 = r4[r23]  ; Unknown_4
    //     0x917a58: add             x16, x4, w23, sxtw #1
    //     0x917a5c: ldur            w1, [x16, #0xf]
    // 0x917a60: DecompressPointer r1
    //     0x917a60: add             x1, x1, HEAP, lsl #32
    // 0x917a64: sub             w4, w0, w1
    // 0x917a68: add             x0, fp, w4, sxtw #2
    // 0x917a6c: ldr             x0, [x0, #8]
    // 0x917a70: b               #0x917a78
    // 0x917a74: r0 = Null
    //     0x917a74: mov             x0, NULL
    // 0x917a78: CheckStackOverflow
    //     0x917a78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x917a7c: cmp             SP, x16
    //     0x917a80: b.ls            #0x917b74
    // 0x917a84: stp             x10, x9, [SP, #0x140]
    // 0x917a88: stp             x12, x11, [SP, #0x130]
    // 0x917a8c: stp             x14, x13, [SP, #0x120]
    // 0x917a90: stp             x20, x19, [SP, #0x110]
    // 0x917a94: stp             x3, x2, [SP, #0x100]
    // 0x917a98: stp             x6, x5, [SP, #0xf0]
    // 0x917a9c: ldur            x16, [fp, #-0x38]
    // 0x917aa0: stp             x16, x7, [SP, #0xe0]
    // 0x917aa4: ldur            x16, [fp, #-0x40]
    // 0x917aa8: ldur            lr, [fp, #-0x48]
    // 0x917aac: stp             lr, x16, [SP, #0xd0]
    // 0x917ab0: ldur            x16, [fp, #-0x50]
    // 0x917ab4: ldur            lr, [fp, #-0x58]
    // 0x917ab8: stp             lr, x16, [SP, #0xc0]
    // 0x917abc: ldur            x16, [fp, #-0x60]
    // 0x917ac0: ldur            lr, [fp, #-0x68]
    // 0x917ac4: stp             lr, x16, [SP, #0xb0]
    // 0x917ac8: ldur            x16, [fp, #-0x70]
    // 0x917acc: ldur            lr, [fp, #-0x78]
    // 0x917ad0: stp             lr, x16, [SP, #0xa0]
    // 0x917ad4: ldur            x16, [fp, #-0x80]
    // 0x917ad8: ldur            lr, [fp, #-0x88]
    // 0x917adc: stp             lr, x16, [SP, #0x90]
    // 0x917ae0: ldur            x16, [fp, #-0x90]
    // 0x917ae4: ldur            lr, [fp, #-0x98]
    // 0x917ae8: stp             lr, x16, [SP, #0x80]
    // 0x917aec: ldur            x16, [fp, #-0xa0]
    // 0x917af0: ldur            lr, [fp, #-0xa8]
    // 0x917af4: stp             lr, x16, [SP, #0x70]
    // 0x917af8: ldur            x16, [fp, #-0xb0]
    // 0x917afc: ldur            lr, [fp, #-0xb8]
    // 0x917b00: stp             lr, x16, [SP, #0x60]
    // 0x917b04: ldur            x16, [fp, #-0xc0]
    // 0x917b08: ldur            lr, [fp, #-0xc8]
    // 0x917b0c: stp             lr, x16, [SP, #0x50]
    // 0x917b10: ldur            x16, [fp, #-0xd0]
    // 0x917b14: ldur            lr, [fp, #-0xd8]
    // 0x917b18: stp             lr, x16, [SP, #0x40]
    // 0x917b1c: ldur            x16, [fp, #-0xe0]
    // 0x917b20: ldur            lr, [fp, #-0xe8]
    // 0x917b24: stp             lr, x16, [SP, #0x30]
    // 0x917b28: ldur            x16, [fp, #-0xf0]
    // 0x917b2c: ldur            lr, [fp, #-0xf8]
    // 0x917b30: stp             lr, x16, [SP, #0x20]
    // 0x917b34: ldur            x16, [fp, #-0x100]
    // 0x917b38: r17 = -264
    //     0x917b38: mov             x17, #-0x108
    // 0x917b3c: ldr             lr, [fp, x17]
    // 0x917b40: stp             lr, x16, [SP, #0x10]
    // 0x917b44: stp             x0, x8, [SP]
    // 0x917b48: ldur            x1, [fp, #-8]
    // 0x917b4c: ldur            x2, [fp, #-0x10]
    // 0x917b50: ldur            x3, [fp, #-0x18]
    // 0x917b54: ldur            x5, [fp, #-0x20]
    // 0x917b58: ldur            x6, [fp, #-0x28]
    // 0x917b5c: ldur            x7, [fp, #-0x30]
    // 0x917b60: r0 = _SemanticsBase()
    //     0x917b60: bl              #0x917b7c  ; [package:flutter/src/widgets/basic.dart] _SemanticsBase::_SemanticsBase
    // 0x917b64: r0 = Null
    //     0x917b64: mov             x0, NULL
    // 0x917b68: LeaveFrame
    //     0x917b68: mov             SP, fp
    //     0x917b6c: ldp             fp, lr, [SP], #0x10
    // 0x917b70: ret
    //     0x917b70: ret             
    // 0x917b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x917b74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x917b78: b               #0x917a84
  }
  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf8d34, size: 0x108
    // 0xcf8d34: EnterFrame
    //     0xcf8d34: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8d38: mov             fp, SP
    // 0xcf8d3c: AllocStack(0x18)
    //     0xcf8d3c: sub             SP, SP, #0x18
    // 0xcf8d40: SetupParameters(Semantics this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf8d40: mov             x5, x1
    //     0xcf8d44: mov             x4, x2
    //     0xcf8d48: stur            x1, [fp, #-8]
    //     0xcf8d4c: stur            x2, [fp, #-0x10]
    //     0xcf8d50: stur            x3, [fp, #-0x18]
    // 0xcf8d54: CheckStackOverflow
    //     0xcf8d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8d58: cmp             SP, x16
    //     0xcf8d5c: b.ls            #0xcf8e34
    // 0xcf8d60: mov             x0, x3
    // 0xcf8d64: r2 = Null
    //     0xcf8d64: mov             x2, NULL
    // 0xcf8d68: r1 = Null
    //     0xcf8d68: mov             x1, NULL
    // 0xcf8d6c: r4 = 60
    //     0xcf8d6c: mov             x4, #0x3c
    // 0xcf8d70: branchIfSmi(r0, 0xcf8d7c)
    //     0xcf8d70: tbz             w0, #0, #0xcf8d7c
    // 0xcf8d74: r4 = LoadClassIdInstr(r0)
    //     0xcf8d74: ldur            x4, [x0, #-1]
    //     0xcf8d78: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8d7c: r17 = 4966
    //     0xcf8d7c: mov             x17, #0x1366
    // 0xcf8d80: cmp             x4, x17
    // 0xcf8d84: b.eq            #0xcf8d9c
    // 0xcf8d88: r8 = RenderSemanticsAnnotations
    //     0xcf8d88: add             x8, PP, #0x26, lsl #12  ; [pp+0x26c90] Type: RenderSemanticsAnnotations
    //     0xcf8d8c: ldr             x8, [x8, #0xc90]
    // 0xcf8d90: r3 = Null
    //     0xcf8d90: add             x3, PP, #0x26, lsl #12  ; [pp+0x26c98] Null
    //     0xcf8d94: ldr             x3, [x3, #0xc98]
    // 0xcf8d98: r0 = DefaultTypeTest()
    //     0xcf8d98: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8d9c: ldur            x0, [fp, #-8]
    // 0xcf8da0: LoadField: r2 = r0->field_13
    //     0xcf8da0: ldur            w2, [x0, #0x13]
    // 0xcf8da4: DecompressPointer r2
    //     0xcf8da4: add             x2, x2, HEAP, lsl #32
    // 0xcf8da8: ldur            x1, [fp, #-0x18]
    // 0xcf8dac: r0 = container=()
    //     0xcf8dac: bl              #0xcf936c  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::container=
    // 0xcf8db0: ldur            x0, [fp, #-8]
    // 0xcf8db4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf8db4: ldur            w2, [x0, #0x17]
    // 0xcf8db8: DecompressPointer r2
    //     0xcf8db8: add             x2, x2, HEAP, lsl #32
    // 0xcf8dbc: ldur            x1, [fp, #-0x18]
    // 0xcf8dc0: r0 = explicitChildNodes=()
    //     0xcf8dc0: bl              #0xcf9300  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::explicitChildNodes=
    // 0xcf8dc4: ldur            x0, [fp, #-8]
    // 0xcf8dc8: LoadField: r2 = r0->field_1f
    //     0xcf8dc8: ldur            w2, [x0, #0x1f]
    // 0xcf8dcc: DecompressPointer r2
    //     0xcf8dcc: add             x2, x2, HEAP, lsl #32
    // 0xcf8dd0: ldur            x1, [fp, #-0x18]
    // 0xcf8dd4: r0 = excludeSemantics=()
    //     0xcf8dd4: bl              #0xcf9294  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::excludeSemantics=
    // 0xcf8dd8: ldur            x1, [fp, #-0x18]
    // 0xcf8ddc: r2 = false
    //     0xcf8ddc: add             x2, NULL, #0x30  ; false
    // 0xcf8de0: r0 = blockUserActions=()
    //     0xcf8de0: bl              #0xcf9264  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::blockUserActions=
    // 0xcf8de4: ldur            x0, [fp, #-8]
    // 0xcf8de8: LoadField: r2 = r0->field_f
    //     0xcf8de8: ldur            w2, [x0, #0xf]
    // 0xcf8dec: DecompressPointer r2
    //     0xcf8dec: add             x2, x2, HEAP, lsl #32
    // 0xcf8df0: ldur            x1, [fp, #-0x18]
    // 0xcf8df4: r0 = properties=()
    //     0xcf8df4: bl              #0xcf8ff8  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::properties=
    // 0xcf8df8: ldur            x1, [fp, #-8]
    // 0xcf8dfc: ldur            x2, [fp, #-0x10]
    // 0xcf8e00: r0 = _getTextDirection()
    //     0xcf8e00: bl              #0xcf8f50  ; [package:flutter/src/widgets/basic.dart] _SemanticsBase::_getTextDirection
    // 0xcf8e04: ldur            x1, [fp, #-0x18]
    // 0xcf8e08: mov             x2, x0
    // 0xcf8e0c: r0 = textDirection=()
    //     0xcf8e0c: bl              #0xcf8ee0  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::textDirection=
    // 0xcf8e10: ldur            x0, [fp, #-8]
    // 0xcf8e14: LoadField: r2 = r0->field_1b
    //     0xcf8e14: ldur            w2, [x0, #0x1b]
    // 0xcf8e18: DecompressPointer r2
    //     0xcf8e18: add             x2, x2, HEAP, lsl #32
    // 0xcf8e1c: ldur            x1, [fp, #-0x18]
    // 0xcf8e20: r0 = localeForSubtree=()
    //     0xcf8e20: bl              #0xcf8e3c  ; [dart:mixin_deduplication] _MixinApplication442&RenderProxyBox&SemanticsAnnotationsMixin::localeForSubtree=
    // 0xcf8e24: r0 = Null
    //     0xcf8e24: mov             x0, NULL
    // 0xcf8e28: LeaveFrame
    //     0xcf8e28: mov             SP, fp
    //     0xcf8e2c: ldp             fp, lr, [SP], #0x10
    // 0xcf8e30: ret
    //     0xcf8e30: ret             
    // 0xcf8e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8e38: b               #0xcf8d60
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1f0c, size: 0xa0
    // 0x11d1f0c: EnterFrame
    //     0x11d1f0c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1f10: mov             fp, SP
    // 0x11d1f14: AllocStack(0x40)
    //     0x11d1f14: sub             SP, SP, #0x40
    // 0x11d1f18: CheckStackOverflow
    //     0x11d1f18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1f1c: cmp             SP, x16
    //     0x11d1f20: b.ls            #0x11d1fa4
    // 0x11d1f24: LoadField: r0 = r1->field_13
    //     0x11d1f24: ldur            w0, [x1, #0x13]
    // 0x11d1f28: DecompressPointer r0
    //     0x11d1f28: add             x0, x0, HEAP, lsl #32
    // 0x11d1f2c: stur            x0, [fp, #-0x28]
    // 0x11d1f30: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x11d1f30: ldur            w5, [x1, #0x17]
    // 0x11d1f34: DecompressPointer r5
    //     0x11d1f34: add             x5, x5, HEAP, lsl #32
    // 0x11d1f38: stur            x5, [fp, #-0x20]
    // 0x11d1f3c: LoadField: r3 = r1->field_1f
    //     0x11d1f3c: ldur            w3, [x1, #0x1f]
    // 0x11d1f40: DecompressPointer r3
    //     0x11d1f40: add             x3, x3, HEAP, lsl #32
    // 0x11d1f44: stur            x3, [fp, #-0x18]
    // 0x11d1f48: LoadField: r7 = r1->field_f
    //     0x11d1f48: ldur            w7, [x1, #0xf]
    // 0x11d1f4c: DecompressPointer r7
    //     0x11d1f4c: add             x7, x7, HEAP, lsl #32
    // 0x11d1f50: stur            x7, [fp, #-0x10]
    // 0x11d1f54: LoadField: r6 = r1->field_1b
    //     0x11d1f54: ldur            w6, [x1, #0x1b]
    // 0x11d1f58: DecompressPointer r6
    //     0x11d1f58: add             x6, x6, HEAP, lsl #32
    // 0x11d1f5c: stur            x6, [fp, #-8]
    // 0x11d1f60: r0 = _getTextDirection()
    //     0x11d1f60: bl              #0xcf8f50  ; [package:flutter/src/widgets/basic.dart] _SemanticsBase::_getTextDirection
    // 0x11d1f64: stur            x0, [fp, #-0x30]
    // 0x11d1f68: r0 = RenderSemanticsAnnotations()
    //     0x11d1f68: bl              #0x11d216c  ; AllocateRenderSemanticsAnnotationsStub -> RenderSemanticsAnnotations (size=0x84)
    // 0x11d1f6c: stur            x0, [fp, #-0x38]
    // 0x11d1f70: ldur            x16, [fp, #-0x30]
    // 0x11d1f74: str             x16, [SP]
    // 0x11d1f78: mov             x1, x0
    // 0x11d1f7c: ldur            x2, [fp, #-0x28]
    // 0x11d1f80: ldur            x3, [fp, #-0x18]
    // 0x11d1f84: ldur            x5, [fp, #-0x20]
    // 0x11d1f88: ldur            x6, [fp, #-8]
    // 0x11d1f8c: ldur            x7, [fp, #-0x10]
    // 0x11d1f90: r0 = RenderSemanticsAnnotations()
    //     0x11d1f90: bl              #0x11d1fac  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::RenderSemanticsAnnotations
    // 0x11d1f94: ldur            x0, [fp, #-0x38]
    // 0x11d1f98: LeaveFrame
    //     0x11d1f98: mov             SP, fp
    //     0x11d1f9c: ldp             fp, lr, [SP], #0x10
    // 0x11d1fa0: ret
    //     0x11d1fa0: ret             
    // 0x11d1fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1fa8: b               #0x11d1f24
  }
}

// class id: 6612, size: 0x14, field offset: 0x10
//   const constructor, 
class SliverPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf8b60, size: 0xa8
    // 0xcf8b60: EnterFrame
    //     0xcf8b60: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8b64: mov             fp, SP
    // 0xcf8b68: AllocStack(0x18)
    //     0xcf8b68: sub             SP, SP, #0x18
    // 0xcf8b6c: SetupParameters(SliverPadding this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf8b6c: mov             x5, x1
    //     0xcf8b70: mov             x4, x2
    //     0xcf8b74: stur            x1, [fp, #-8]
    //     0xcf8b78: stur            x2, [fp, #-0x10]
    //     0xcf8b7c: stur            x3, [fp, #-0x18]
    // 0xcf8b80: CheckStackOverflow
    //     0xcf8b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8b84: cmp             SP, x16
    //     0xcf8b88: b.ls            #0xcf8c00
    // 0xcf8b8c: mov             x0, x3
    // 0xcf8b90: r2 = Null
    //     0xcf8b90: mov             x2, NULL
    // 0xcf8b94: r1 = Null
    //     0xcf8b94: mov             x1, NULL
    // 0xcf8b98: r4 = 60
    //     0xcf8b98: mov             x4, #0x3c
    // 0xcf8b9c: branchIfSmi(r0, 0xcf8ba8)
    //     0xcf8b9c: tbz             w0, #0, #0xcf8ba8
    // 0xcf8ba0: r4 = LoadClassIdInstr(r0)
    //     0xcf8ba0: ldur            x4, [x0, #-1]
    //     0xcf8ba4: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8ba8: r17 = 4692
    //     0xcf8ba8: mov             x17, #0x1254
    // 0xcf8bac: cmp             x4, x17
    // 0xcf8bb0: b.eq            #0xcf8bc8
    // 0xcf8bb4: r8 = RenderSliverPadding
    //     0xcf8bb4: add             x8, PP, #0x90, lsl #12  ; [pp+0x902d0] Type: RenderSliverPadding
    //     0xcf8bb8: ldr             x8, [x8, #0x2d0]
    // 0xcf8bbc: r3 = Null
    //     0xcf8bbc: add             x3, PP, #0x90, lsl #12  ; [pp+0x902d8] Null
    //     0xcf8bc0: ldr             x3, [x3, #0x2d8]
    // 0xcf8bc4: r0 = DefaultTypeTest()
    //     0xcf8bc4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8bc8: ldur            x0, [fp, #-8]
    // 0xcf8bcc: LoadField: r2 = r0->field_f
    //     0xcf8bcc: ldur            w2, [x0, #0xf]
    // 0xcf8bd0: DecompressPointer r2
    //     0xcf8bd0: add             x2, x2, HEAP, lsl #32
    // 0xcf8bd4: ldur            x1, [fp, #-0x18]
    // 0xcf8bd8: r0 = padding=()
    //     0xcf8bd8: bl              #0xcf8cac  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::padding=
    // 0xcf8bdc: ldur            x1, [fp, #-0x10]
    // 0xcf8be0: r0 = of()
    //     0xcf8be0: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcf8be4: ldur            x1, [fp, #-0x18]
    // 0xcf8be8: mov             x2, x0
    // 0xcf8bec: r0 = textDirection=()
    //     0xcf8bec: bl              #0xcf8c08  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::textDirection=
    // 0xcf8bf0: r0 = Null
    //     0xcf8bf0: mov             x0, NULL
    // 0xcf8bf4: LeaveFrame
    //     0xcf8bf4: mov             SP, fp
    //     0xcf8bf8: ldp             fp, lr, [SP], #0x10
    // 0xcf8bfc: ret
    //     0xcf8bfc: ret             
    // 0xcf8c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8c04: b               #0xcf8b8c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1e84, size: 0x7c
    // 0x11d1e84: EnterFrame
    //     0x11d1e84: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1e88: mov             fp, SP
    // 0x11d1e8c: AllocStack(0x18)
    //     0x11d1e8c: sub             SP, SP, #0x18
    // 0x11d1e90: SetupParameters(SliverPadding this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d1e90: mov             x0, x1
    //     0x11d1e94: mov             x1, x2
    // 0x11d1e98: CheckStackOverflow
    //     0x11d1e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1e9c: cmp             SP, x16
    //     0x11d1ea0: b.ls            #0x11d1ef8
    // 0x11d1ea4: LoadField: r2 = r0->field_f
    //     0x11d1ea4: ldur            w2, [x0, #0xf]
    // 0x11d1ea8: DecompressPointer r2
    //     0x11d1ea8: add             x2, x2, HEAP, lsl #32
    // 0x11d1eac: stur            x2, [fp, #-8]
    // 0x11d1eb0: r0 = of()
    //     0x11d1eb0: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11d1eb4: stur            x0, [fp, #-0x10]
    // 0x11d1eb8: r0 = RenderSliverPadding()
    //     0x11d1eb8: bl              #0x11d1f00  ; AllocateRenderSliverPaddingStub -> RenderSliverPadding (size=0x5c)
    // 0x11d1ebc: mov             x2, x0
    // 0x11d1ec0: ldur            x0, [fp, #-8]
    // 0x11d1ec4: stur            x2, [fp, #-0x18]
    // 0x11d1ec8: StoreField: r2->field_53 = r0
    //     0x11d1ec8: stur            w0, [x2, #0x53]
    // 0x11d1ecc: ldur            x0, [fp, #-0x10]
    // 0x11d1ed0: StoreField: r2->field_57 = r0
    //     0x11d1ed0: stur            w0, [x2, #0x57]
    // 0x11d1ed4: mov             x1, x2
    // 0x11d1ed8: r0 = RenderObject()
    //     0x11d1ed8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1edc: ldur            x1, [fp, #-0x18]
    // 0x11d1ee0: r2 = Null
    //     0x11d1ee0: mov             x2, NULL
    // 0x11d1ee4: r0 = child=()
    //     0x11d1ee4: bl              #0xaef5f4  ; [dart:mixin_deduplication] _MixinApplication235&RenderSliver&RenderObjectWithChildMixin::child=
    // 0x11d1ee8: ldur            x0, [fp, #-0x18]
    // 0x11d1eec: LeaveFrame
    //     0x11d1eec: mov             SP, fp
    //     0x11d1ef0: ldp             fp, lr, [SP], #0x10
    // 0x11d1ef4: ret
    //     0x11d1ef4: ret             
    // 0x11d1ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1efc: b               #0x11d1ea4
  }
}

// class id: 6614, size: 0x10, field offset: 0x10
//   const constructor, 
class IntrinsicHeight extends SingleChildRenderObjectWidget {

  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1e1c, size: 0x5c
    // 0x11d1e1c: EnterFrame
    //     0x11d1e1c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1e20: mov             fp, SP
    // 0x11d1e24: AllocStack(0x8)
    //     0x11d1e24: sub             SP, SP, #8
    // 0x11d1e28: CheckStackOverflow
    //     0x11d1e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1e2c: cmp             SP, x16
    //     0x11d1e30: b.ls            #0x11d1e70
    // 0x11d1e34: r0 = RenderIntrinsicHeight()
    //     0x11d1e34: bl              #0x11d1e78  ; AllocateRenderIntrinsicHeightStub -> RenderIntrinsicHeight (size=0x54)
    // 0x11d1e38: stur            x0, [fp, #-8]
    // 0x11d1e3c: r0 = _LayoutCacheStorage()
    //     0x11d1e3c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1e40: mov             x1, x0
    // 0x11d1e44: ldur            x0, [fp, #-8]
    // 0x11d1e48: StoreField: r0->field_47 = r1
    //     0x11d1e48: stur            w1, [x0, #0x47]
    // 0x11d1e4c: mov             x1, x0
    // 0x11d1e50: r0 = RenderObject()
    //     0x11d1e50: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1e54: ldur            x1, [fp, #-8]
    // 0x11d1e58: r2 = Null
    //     0x11d1e58: mov             x2, NULL
    // 0x11d1e5c: r0 = child=()
    //     0x11d1e5c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1e60: ldur            x0, [fp, #-8]
    // 0x11d1e64: LeaveFrame
    //     0x11d1e64: mov             SP, fp
    //     0x11d1e68: ldp             fp, lr, [SP], #0x10
    // 0x11d1e6c: ret
    //     0x11d1e6c: ret             
    // 0x11d1e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1e70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1e74: b               #0x11d1e34
  }
}

// class id: 6615, size: 0x18, field offset: 0x10
//   const constructor, 
class IntrinsicWidth extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf8a64, size: 0x98
    // 0xcf8a64: EnterFrame
    //     0xcf8a64: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8a68: mov             fp, SP
    // 0xcf8a6c: AllocStack(0x10)
    //     0xcf8a6c: sub             SP, SP, #0x10
    // 0xcf8a70: SetupParameters(IntrinsicWidth this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf8a70: mov             x4, x1
    //     0xcf8a74: stur            x1, [fp, #-8]
    //     0xcf8a78: stur            x3, [fp, #-0x10]
    // 0xcf8a7c: CheckStackOverflow
    //     0xcf8a7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8a80: cmp             SP, x16
    //     0xcf8a84: b.ls            #0xcf8af4
    // 0xcf8a88: mov             x0, x3
    // 0xcf8a8c: r2 = Null
    //     0xcf8a8c: mov             x2, NULL
    // 0xcf8a90: r1 = Null
    //     0xcf8a90: mov             x1, NULL
    // 0xcf8a94: r4 = 60
    //     0xcf8a94: mov             x4, #0x3c
    // 0xcf8a98: branchIfSmi(r0, 0xcf8aa4)
    //     0xcf8a98: tbz             w0, #0, #0xcf8aa4
    // 0xcf8a9c: r4 = LoadClassIdInstr(r0)
    //     0xcf8a9c: ldur            x4, [x0, #-1]
    //     0xcf8aa0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8aa4: r17 = 4944
    //     0xcf8aa4: mov             x17, #0x1350
    // 0xcf8aa8: cmp             x4, x17
    // 0xcf8aac: b.eq            #0xcf8ac4
    // 0xcf8ab0: r8 = RenderIntrinsicWidth
    //     0xcf8ab0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90220] Type: RenderIntrinsicWidth
    //     0xcf8ab4: ldr             x8, [x8, #0x220]
    // 0xcf8ab8: r3 = Null
    //     0xcf8ab8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90228] Null
    //     0xcf8abc: ldr             x3, [x3, #0x228]
    // 0xcf8ac0: r0 = DefaultTypeTest()
    //     0xcf8ac0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8ac4: ldur            x1, [fp, #-8]
    // 0xcf8ac8: r0 = _stepWidth()
    //     0xcf8ac8: bl              #0xcf8afc  ; [package:flutter/src/widgets/basic.dart] IntrinsicWidth::_stepWidth
    // 0xcf8acc: ldur            x1, [fp, #-0x10]
    // 0xcf8ad0: mov             x2, x0
    // 0xcf8ad4: r0 = updateCallback()
    //     0xcf8ad4: bl              #0x129aa5c  ; [dart:mixin_deduplication] _MixinApplication670&RenderBox&RenderObjectWithChildMixin&CustomRenderConstrainedLayoutBuilder::updateCallback
    // 0xcf8ad8: ldur            x1, [fp, #-0x10]
    // 0xcf8adc: r2 = Null
    //     0xcf8adc: mov             x2, NULL
    // 0xcf8ae0: r0 = Shader._()
    //     0xcf8ae0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf8ae4: r0 = Null
    //     0xcf8ae4: mov             x0, NULL
    // 0xcf8ae8: LeaveFrame
    //     0xcf8ae8: mov             SP, fp
    //     0xcf8aec: ldp             fp, lr, [SP], #0x10
    // 0xcf8af0: ret
    //     0xcf8af0: ret             
    // 0xcf8af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8af4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8af8: b               #0xcf8a88
  }
  get _ _stepWidth(/* No info */) {
    // ** addr: 0xcf8afc, size: 0x64
    // 0xcf8afc: EnterFrame
    //     0xcf8afc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8b00: mov             fp, SP
    // 0xcf8b04: AllocStack(0x18)
    //     0xcf8b04: sub             SP, SP, #0x18
    // 0xcf8b08: CheckStackOverflow
    //     0xcf8b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8b0c: cmp             SP, x16
    //     0xcf8b10: b.ls            #0xcf8b58
    // 0xcf8b14: LoadField: r2 = r1->field_f
    //     0xcf8b14: ldur            w2, [x1, #0xf]
    // 0xcf8b18: DecompressPointer r2
    //     0xcf8b18: add             x2, x2, HEAP, lsl #32
    // 0xcf8b1c: stur            x2, [fp, #-8]
    // 0xcf8b20: r0 = LoadClassIdInstr(r2)
    //     0xcf8b20: ldur            x0, [x2, #-1]
    //     0xcf8b24: ubfx            x0, x0, #0xc, #0x14
    // 0xcf8b28: r16 = 0.000000
    //     0xcf8b28: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xcf8b2c: stp             x16, x2, [SP]
    // 0xcf8b30: mov             lr, x0
    // 0xcf8b34: ldr             lr, [x21, lr, lsl #3]
    // 0xcf8b38: blr             lr
    // 0xcf8b3c: tbnz            w0, #4, #0xcf8b48
    // 0xcf8b40: r0 = Null
    //     0xcf8b40: mov             x0, NULL
    // 0xcf8b44: b               #0xcf8b4c
    // 0xcf8b48: ldur            x0, [fp, #-8]
    // 0xcf8b4c: LeaveFrame
    //     0xcf8b4c: mov             SP, fp
    //     0xcf8b50: ldp             fp, lr, [SP], #0x10
    // 0xcf8b54: ret
    //     0xcf8b54: ret             
    // 0xcf8b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8b5c: b               #0xcf8b14
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1dc4, size: 0x4c
    // 0x11d1dc4: EnterFrame
    //     0x11d1dc4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1dc8: mov             fp, SP
    // 0x11d1dcc: AllocStack(0x8)
    //     0x11d1dcc: sub             SP, SP, #8
    // 0x11d1dd0: CheckStackOverflow
    //     0x11d1dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1dd4: cmp             SP, x16
    //     0x11d1dd8: b.ls            #0x11d1e08
    // 0x11d1ddc: r0 = _stepWidth()
    //     0x11d1ddc: bl              #0xcf8afc  ; [package:flutter/src/widgets/basic.dart] IntrinsicWidth::_stepWidth
    // 0x11d1de0: stur            x0, [fp, #-8]
    // 0x11d1de4: r0 = RenderIntrinsicWidth()
    //     0x11d1de4: bl              #0x11d1e10  ; AllocateRenderIntrinsicWidthStub -> RenderIntrinsicWidth (size=0x5c)
    // 0x11d1de8: mov             x1, x0
    // 0x11d1dec: ldur            x2, [fp, #-8]
    // 0x11d1df0: stur            x0, [fp, #-8]
    // 0x11d1df4: r0 = RenderIntrinsicWidth()
    //     0x11d1df4: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11d1df8: ldur            x0, [fp, #-8]
    // 0x11d1dfc: LeaveFrame
    //     0x11d1dfc: mov             SP, fp
    //     0x11d1e00: ldp             fp, lr, [SP], #0x10
    // 0x11d1e04: ret
    //     0x11d1e04: ret             
    // 0x11d1e08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1e08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1e0c: b               #0x11d1ddc
  }
}

// class id: 6616, size: 0x18, field offset: 0x10
//   const constructor, 
class AspectRatio extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf89dc, size: 0x88
    // 0xcf89dc: EnterFrame
    //     0xcf89dc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf89e0: mov             fp, SP
    // 0xcf89e4: AllocStack(0x10)
    //     0xcf89e4: sub             SP, SP, #0x10
    // 0xcf89e8: SetupParameters(AspectRatio this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf89e8: mov             x4, x1
    //     0xcf89ec: stur            x1, [fp, #-8]
    //     0xcf89f0: stur            x3, [fp, #-0x10]
    // 0xcf89f4: CheckStackOverflow
    //     0xcf89f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf89f8: cmp             SP, x16
    //     0xcf89fc: b.ls            #0xcf8a5c
    // 0xcf8a00: mov             x0, x3
    // 0xcf8a04: r2 = Null
    //     0xcf8a04: mov             x2, NULL
    // 0xcf8a08: r1 = Null
    //     0xcf8a08: mov             x1, NULL
    // 0xcf8a0c: r4 = 60
    //     0xcf8a0c: mov             x4, #0x3c
    // 0xcf8a10: branchIfSmi(r0, 0xcf8a1c)
    //     0xcf8a10: tbz             w0, #0, #0xcf8a1c
    // 0xcf8a14: r4 = LoadClassIdInstr(r0)
    //     0xcf8a14: ldur            x4, [x0, #-1]
    //     0xcf8a18: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8a1c: r17 = 4945
    //     0xcf8a1c: mov             x17, #0x1351
    // 0xcf8a20: cmp             x4, x17
    // 0xcf8a24: b.eq            #0xcf8a3c
    // 0xcf8a28: r8 = RenderAspectRatio
    //     0xcf8a28: add             x8, PP, #0x85, lsl #12  ; [pp+0x850d8] Type: RenderAspectRatio
    //     0xcf8a2c: ldr             x8, [x8, #0xd8]
    // 0xcf8a30: r3 = Null
    //     0xcf8a30: add             x3, PP, #0x85, lsl #12  ; [pp+0x850e0] Null
    //     0xcf8a34: ldr             x3, [x3, #0xe0]
    // 0xcf8a38: r0 = DefaultTypeTest()
    //     0xcf8a38: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8a3c: ldur            x0, [fp, #-8]
    // 0xcf8a40: LoadField: d0 = r0->field_f
    //     0xcf8a40: ldur            d0, [x0, #0xf]
    // 0xcf8a44: ldur            x1, [fp, #-0x10]
    // 0xcf8a48: r0 = aspectRatio=()
    //     0xcf8a48: bl              #0xcf8620  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::aspectRatio=
    // 0xcf8a4c: r0 = Null
    //     0xcf8a4c: mov             x0, NULL
    // 0xcf8a50: LeaveFrame
    //     0xcf8a50: mov             SP, fp
    //     0xcf8a54: ldp             fp, lr, [SP], #0x10
    // 0xcf8a58: ret
    //     0xcf8a58: ret             
    // 0xcf8a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8a5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8a60: b               #0xcf8a00
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1cfc, size: 0x4c
    // 0x11d1cfc: EnterFrame
    //     0x11d1cfc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1d00: mov             fp, SP
    // 0x11d1d04: AllocStack(0x10)
    //     0x11d1d04: sub             SP, SP, #0x10
    // 0x11d1d08: CheckStackOverflow
    //     0x11d1d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1d0c: cmp             SP, x16
    //     0x11d1d10: b.ls            #0x11d1d40
    // 0x11d1d14: LoadField: d0 = r1->field_f
    //     0x11d1d14: ldur            d0, [x1, #0xf]
    // 0x11d1d18: stur            d0, [fp, #-0x10]
    // 0x11d1d1c: r0 = RenderAspectRatio()
    //     0x11d1d1c: bl              #0x11d1db8  ; AllocateRenderAspectRatioStub -> RenderAspectRatio (size=0x5c)
    // 0x11d1d20: mov             x1, x0
    // 0x11d1d24: ldur            d0, [fp, #-0x10]
    // 0x11d1d28: stur            x0, [fp, #-8]
    // 0x11d1d2c: r0 = RenderAspectRatio()
    //     0x11d1d2c: bl              #0x11d1d48  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::RenderAspectRatio
    // 0x11d1d30: ldur            x0, [fp, #-8]
    // 0x11d1d34: LeaveFrame
    //     0x11d1d34: mov             SP, fp
    //     0x11d1d38: ldp             fp, lr, [SP], #0x10
    // 0x11d1d3c: ret
    //     0x11d1d3c: ret             
    // 0x11d1d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1d44: b               #0x11d1d14
  }
}

// class id: 6617, size: 0x14, field offset: 0x10
//   const constructor, 
class Offstage extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf88b4, size: 0x8c
    // 0xcf88b4: EnterFrame
    //     0xcf88b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf88b8: mov             fp, SP
    // 0xcf88bc: AllocStack(0x10)
    //     0xcf88bc: sub             SP, SP, #0x10
    // 0xcf88c0: SetupParameters(Offstage this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf88c0: mov             x4, x1
    //     0xcf88c4: stur            x1, [fp, #-8]
    //     0xcf88c8: stur            x3, [fp, #-0x10]
    // 0xcf88cc: CheckStackOverflow
    //     0xcf88cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf88d0: cmp             SP, x16
    //     0xcf88d4: b.ls            #0xcf8938
    // 0xcf88d8: mov             x0, x3
    // 0xcf88dc: r2 = Null
    //     0xcf88dc: mov             x2, NULL
    // 0xcf88e0: r1 = Null
    //     0xcf88e0: mov             x1, NULL
    // 0xcf88e4: r4 = 60
    //     0xcf88e4: mov             x4, #0x3c
    // 0xcf88e8: branchIfSmi(r0, 0xcf88f4)
    //     0xcf88e8: tbz             w0, #0, #0xcf88f4
    // 0xcf88ec: r4 = LoadClassIdInstr(r0)
    //     0xcf88ec: ldur            x4, [x0, #-1]
    //     0xcf88f0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf88f4: r17 = 4922
    //     0xcf88f4: mov             x17, #0x133a
    // 0xcf88f8: cmp             x4, x17
    // 0xcf88fc: b.eq            #0xcf8914
    // 0xcf8900: r8 = RenderOffstage
    //     0xcf8900: add             x8, PP, #0x90, lsl #12  ; [pp+0x901c0] Type: RenderOffstage
    //     0xcf8904: ldr             x8, [x8, #0x1c0]
    // 0xcf8908: r3 = Null
    //     0xcf8908: add             x3, PP, #0x90, lsl #12  ; [pp+0x901c8] Null
    //     0xcf890c: ldr             x3, [x3, #0x1c8]
    // 0xcf8910: r0 = DefaultTypeTest()
    //     0xcf8910: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8914: ldur            x0, [fp, #-8]
    // 0xcf8918: LoadField: r2 = r0->field_f
    //     0xcf8918: ldur            w2, [x0, #0xf]
    // 0xcf891c: DecompressPointer r2
    //     0xcf891c: add             x2, x2, HEAP, lsl #32
    // 0xcf8920: ldur            x1, [fp, #-0x10]
    // 0xcf8924: r0 = offstage=()
    //     0xcf8924: bl              #0xcf8940  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::offstage=
    // 0xcf8928: r0 = Null
    //     0xcf8928: mov             x0, NULL
    // 0xcf892c: LeaveFrame
    //     0xcf892c: mov             SP, fp
    //     0xcf8930: ldp             fp, lr, [SP], #0x10
    // 0xcf8934: ret
    //     0xcf8934: ret             
    // 0xcf8938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf893c: b               #0xcf88d8
  }
  _ createElement(/* No info */) {
    // ** addr: 0x10f2230, size: 0x4c
    // 0x10f2230: EnterFrame
    //     0x10f2230: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2234: mov             fp, SP
    // 0x10f2238: AllocStack(0x8)
    //     0x10f2238: sub             SP, SP, #8
    // 0x10f223c: SetupParameters(Offstage this /* r1 => r1, fp-0x8 */)
    //     0x10f223c: stur            x1, [fp, #-8]
    // 0x10f2240: r0 = _OffstageElement()
    //     0x10f2240: bl              #0x10f227c  ; Allocate_OffstageElementStub -> _OffstageElement (size=0x48)
    // 0x10f2244: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f2248: StoreField: r0->field_13 = r1
    //     0x10f2248: stur            w1, [x0, #0x13]
    // 0x10f224c: r1 = Instance__ElementLifecycle
    //     0x10f224c: ldr             x1, [PP, #0x7ef8]  ; [pp+0x7ef8] Obj!_ElementLifecycle@12c2fc1
    // 0x10f2250: StoreField: r0->field_23 = r1
    //     0x10f2250: stur            w1, [x0, #0x23]
    // 0x10f2254: r1 = false
    //     0x10f2254: add             x1, NULL, #0x30  ; false
    // 0x10f2258: StoreField: r0->field_2f = r1
    //     0x10f2258: stur            w1, [x0, #0x2f]
    // 0x10f225c: r2 = true
    //     0x10f225c: add             x2, NULL, #0x20  ; true
    // 0x10f2260: StoreField: r0->field_33 = r2
    //     0x10f2260: stur            w2, [x0, #0x33]
    // 0x10f2264: StoreField: r0->field_37 = r1
    //     0x10f2264: stur            w1, [x0, #0x37]
    // 0x10f2268: ldur            x1, [fp, #-8]
    // 0x10f226c: ArrayStore: r0[0] = r1  ; List_4
    //     0x10f226c: stur            w1, [x0, #0x17]
    // 0x10f2270: LeaveFrame
    //     0x10f2270: mov             SP, fp
    //     0x10f2274: ldp             fp, lr, [SP], #0x10
    // 0x10f2278: ret
    //     0x10f2278: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1c30, size: 0x50
    // 0x11d1c30: EnterFrame
    //     0x11d1c30: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1c34: mov             fp, SP
    // 0x11d1c38: AllocStack(0x8)
    //     0x11d1c38: sub             SP, SP, #8
    // 0x11d1c3c: CheckStackOverflow
    //     0x11d1c3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1c40: cmp             SP, x16
    //     0x11d1c44: b.ls            #0x11d1c78
    // 0x11d1c48: LoadField: r2 = r1->field_f
    //     0x11d1c48: ldur            w2, [x1, #0xf]
    // 0x11d1c4c: DecompressPointer r2
    //     0x11d1c4c: add             x2, x2, HEAP, lsl #32
    // 0x11d1c50: stur            x2, [fp, #-8]
    // 0x11d1c54: r0 = RenderOffstage()
    //     0x11d1c54: bl              #0x11d1cf0  ; AllocateRenderOffstageStub -> RenderOffstage (size=0x58)
    // 0x11d1c58: mov             x1, x0
    // 0x11d1c5c: ldur            x2, [fp, #-8]
    // 0x11d1c60: stur            x0, [fp, #-8]
    // 0x11d1c64: r0 = RenderAbsorbPointer()
    //     0x11d1c64: bl              #0x11d1c80  ; [package:flutter/src/rendering/proxy_box.dart] RenderAbsorbPointer::RenderAbsorbPointer
    // 0x11d1c68: ldur            x0, [fp, #-8]
    // 0x11d1c6c: LeaveFrame
    //     0x11d1c6c: mov             SP, fp
    //     0x11d1c70: ldp             fp, lr, [SP], #0x10
    // 0x11d1c74: ret
    //     0x11d1c74: ret             
    // 0x11d1c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1c78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1c7c: b               #0x11d1c48
  }
}

// class id: 6618, size: 0x38, field offset: 0x10
//   const constructor, 
class OverflowBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf8670, size: 0x104
    // 0xcf8670: EnterFrame
    //     0xcf8670: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8674: mov             fp, SP
    // 0xcf8678: AllocStack(0x10)
    //     0xcf8678: sub             SP, SP, #0x10
    // 0xcf867c: SetupParameters(dynamic _ /* r2 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf867c: mov             x4, x2
    //     0xcf8680: stur            x2, [fp, #-8]
    //     0xcf8684: stur            x3, [fp, #-0x10]
    // 0xcf8688: CheckStackOverflow
    //     0xcf8688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf868c: cmp             SP, x16
    //     0xcf8690: b.ls            #0xcf876c
    // 0xcf8694: mov             x0, x3
    // 0xcf8698: r2 = Null
    //     0xcf8698: mov             x2, NULL
    // 0xcf869c: r1 = Null
    //     0xcf869c: mov             x1, NULL
    // 0xcf86a0: r4 = 60
    //     0xcf86a0: mov             x4, #0x3c
    // 0xcf86a4: branchIfSmi(r0, 0xcf86b0)
    //     0xcf86a4: tbz             w0, #0, #0xcf86b0
    // 0xcf86a8: r4 = LoadClassIdInstr(r0)
    //     0xcf86a8: ldur            x4, [x0, #-1]
    //     0xcf86ac: ubfx            x4, x4, #0xc, #0x14
    // 0xcf86b0: r17 = 4885
    //     0xcf86b0: mov             x17, #0x1315
    // 0xcf86b4: cmp             x4, x17
    // 0xcf86b8: b.eq            #0xcf86d0
    // 0xcf86bc: r8 = RenderConstrainedOverflowBox
    //     0xcf86bc: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd35a0] Type: RenderConstrainedOverflowBox
    //     0xcf86c0: ldr             x8, [x8, #0x5a0]
    // 0xcf86c4: r3 = Null
    //     0xcf86c4: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd35a8] Null
    //     0xcf86c8: ldr             x3, [x3, #0x5a8]
    // 0xcf86cc: r0 = DefaultTypeTest()
    //     0xcf86cc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf86d0: ldur            x1, [fp, #-0x10]
    // 0xcf86d4: r2 = Instance_Alignment
    //     0xcf86d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf86d8: ldr             x2, [x2, #0x510]
    // 0xcf86dc: r0 = alignment=()
    //     0xcf86dc: bl              #0xcf5338  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignment=
    // 0xcf86e0: ldur            x1, [fp, #-0x10]
    // 0xcf86e4: d0 = 0.000000
    //     0xcf86e4: eor             v0.16b, v0.16b, v0.16b
    // 0xcf86e8: r0 = minWidth=()
    //     0xcf86e8: bl              #0xcf8864  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::minWidth=
    // 0xcf86ec: ldur            x1, [fp, #-0x10]
    // 0xcf86f0: d0 = inf
    //     0xcf86f0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf86f4: r0 = maxWidth=()
    //     0xcf86f4: bl              #0xcf8814  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::maxWidth=
    // 0xcf86f8: ldur            x1, [fp, #-0x10]
    // 0xcf86fc: d0 = 0.000000
    //     0xcf86fc: eor             v0.16b, v0.16b, v0.16b
    // 0xcf8700: r0 = minHeight=()
    //     0xcf8700: bl              #0xcf87c4  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::minHeight=
    // 0xcf8704: ldur            x1, [fp, #-0x10]
    // 0xcf8708: d0 = inf
    //     0xcf8708: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf870c: r0 = maxHeight=()
    //     0xcf870c: bl              #0xcf8774  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::maxHeight=
    // 0xcf8710: ldur            x1, [fp, #-0x10]
    // 0xcf8714: r2 = Instance_OverflowBoxFit
    //     0xcf8714: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2830] Obj!OverflowBoxFit@12c42c1
    //     0xcf8718: ldr             x2, [x2, #0x830]
    // 0xcf871c: r0 = Shader._()
    //     0xcf871c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf8720: ldur            x1, [fp, #-8]
    // 0xcf8724: r0 = maybeOf()
    //     0xcf8724: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf8728: ldur            x1, [fp, #-0x10]
    // 0xcf872c: LoadField: r2 = r1->field_5b
    //     0xcf872c: ldur            w2, [x1, #0x5b]
    // 0xcf8730: DecompressPointer r2
    //     0xcf8730: add             x2, x2, HEAP, lsl #32
    // 0xcf8734: cmp             w2, w0
    // 0xcf8738: b.eq            #0xcf875c
    // 0xcf873c: StoreField: r1->field_5b = r0
    //     0xcf873c: stur            w0, [x1, #0x5b]
    //     0xcf8740: ldurb           w16, [x1, #-1]
    //     0xcf8744: ldurb           w17, [x0, #-1]
    //     0xcf8748: and             x16, x17, x16, lsr #2
    //     0xcf874c: tst             x16, HEAP, lsr #32
    //     0xcf8750: b.eq            #0xcf8758
    //     0xcf8754: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf8758: r0 = _markNeedResolution()
    //     0xcf8758: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf875c: r0 = Null
    //     0xcf875c: mov             x0, NULL
    // 0xcf8760: LeaveFrame
    //     0xcf8760: mov             SP, fp
    //     0xcf8764: ldp             fp, lr, [SP], #0x10
    // 0xcf8768: ret
    //     0xcf8768: ret             
    // 0xcf876c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf876c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8770: b               #0xcf8694
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1b0c, size: 0x54
    // 0x11d1b0c: EnterFrame
    //     0x11d1b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1b10: mov             fp, SP
    // 0x11d1b14: AllocStack(0x8)
    //     0x11d1b14: sub             SP, SP, #8
    // 0x11d1b18: SetupParameters(OverflowBox this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d1b18: mov             x0, x1
    //     0x11d1b1c: mov             x1, x2
    // 0x11d1b20: CheckStackOverflow
    //     0x11d1b20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1b24: cmp             SP, x16
    //     0x11d1b28: b.ls            #0x11d1b58
    // 0x11d1b2c: r0 = maybeOf()
    //     0x11d1b2c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d1b30: stur            x0, [fp, #-8]
    // 0x11d1b34: r0 = RenderConstrainedOverflowBox()
    //     0x11d1b34: bl              #0x11d1c24  ; AllocateRenderConstrainedOverflowBoxStub -> RenderConstrainedOverflowBox (size=0x84)
    // 0x11d1b38: mov             x1, x0
    // 0x11d1b3c: ldur            x2, [fp, #-8]
    // 0x11d1b40: stur            x0, [fp, #-8]
    // 0x11d1b44: r0 = RenderConstrainedOverflowBox()
    //     0x11d1b44: bl              #0x11d1b60  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::RenderConstrainedOverflowBox
    // 0x11d1b48: ldur            x0, [fp, #-8]
    // 0x11d1b4c: LeaveFrame
    //     0x11d1b4c: mov             SP, fp
    //     0x11d1b50: ldp             fp, lr, [SP], #0x10
    // 0x11d1b54: ret
    //     0x11d1b54: ret             
    // 0x11d1b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1b5c: b               #0x11d1b2c
  }
}

// class id: 6619, size: 0x20, field offset: 0x10
//   const constructor, 
class LimitedBox extends SingleChildRenderObjectWidget {

  SizedBox field_c;
  _Mint field_10;
  _Mint field_18;

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf8588, size: 0x98
    // 0xcf8588: EnterFrame
    //     0xcf8588: stp             fp, lr, [SP, #-0x10]!
    //     0xcf858c: mov             fp, SP
    // 0xcf8590: AllocStack(0x10)
    //     0xcf8590: sub             SP, SP, #0x10
    // 0xcf8594: SetupParameters(LimitedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf8594: mov             x4, x1
    //     0xcf8598: stur            x1, [fp, #-8]
    //     0xcf859c: stur            x3, [fp, #-0x10]
    // 0xcf85a0: CheckStackOverflow
    //     0xcf85a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf85a4: cmp             SP, x16
    //     0xcf85a8: b.ls            #0xcf8618
    // 0xcf85ac: mov             x0, x3
    // 0xcf85b0: r2 = Null
    //     0xcf85b0: mov             x2, NULL
    // 0xcf85b4: r1 = Null
    //     0xcf85b4: mov             x1, NULL
    // 0xcf85b8: r4 = 60
    //     0xcf85b8: mov             x4, #0x3c
    // 0xcf85bc: branchIfSmi(r0, 0xcf85c8)
    //     0xcf85bc: tbz             w0, #0, #0xcf85c8
    // 0xcf85c0: r4 = LoadClassIdInstr(r0)
    //     0xcf85c0: ldur            x4, [x0, #-1]
    //     0xcf85c4: ubfx            x4, x4, #0xc, #0x14
    // 0xcf85c8: r17 = 4946
    //     0xcf85c8: mov             x17, #0x1352
    // 0xcf85cc: cmp             x4, x17
    // 0xcf85d0: b.eq            #0xcf85e8
    // 0xcf85d4: r8 = RenderLimitedBox
    //     0xcf85d4: add             x8, PP, #0x90, lsl #12  ; [pp+0x90238] Type: RenderLimitedBox
    //     0xcf85d8: ldr             x8, [x8, #0x238]
    // 0xcf85dc: r3 = Null
    //     0xcf85dc: add             x3, PP, #0x90, lsl #12  ; [pp+0x90240] Null
    //     0xcf85e0: ldr             x3, [x3, #0x240]
    // 0xcf85e4: r0 = DefaultTypeTest()
    //     0xcf85e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf85e8: ldur            x0, [fp, #-8]
    // 0xcf85ec: LoadField: d0 = r0->field_f
    //     0xcf85ec: ldur            d0, [x0, #0xf]
    // 0xcf85f0: ldur            x1, [fp, #-0x10]
    // 0xcf85f4: r0 = aspectRatio=()
    //     0xcf85f4: bl              #0xcf8620  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::aspectRatio=
    // 0xcf85f8: ldur            x0, [fp, #-8]
    // 0xcf85fc: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcf85fc: ldur            d0, [x0, #0x17]
    // 0xcf8600: ldur            x1, [fp, #-0x10]
    // 0xcf8604: r0 = maxHeight=()
    //     0xcf8604: bl              #0xcf47d4  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::maxHeight=
    // 0xcf8608: r0 = Null
    //     0xcf8608: mov             x0, NULL
    // 0xcf860c: LeaveFrame
    //     0xcf860c: mov             SP, fp
    //     0xcf8610: ldp             fp, lr, [SP], #0x10
    // 0xcf8614: ret
    //     0xcf8614: ret             
    // 0xcf8618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf861c: b               #0xcf85ac
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1a34, size: 0x58
    // 0x11d1a34: EnterFrame
    //     0x11d1a34: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1a38: mov             fp, SP
    // 0x11d1a3c: AllocStack(0x18)
    //     0x11d1a3c: sub             SP, SP, #0x18
    // 0x11d1a40: CheckStackOverflow
    //     0x11d1a40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1a44: cmp             SP, x16
    //     0x11d1a48: b.ls            #0x11d1a84
    // 0x11d1a4c: LoadField: d1 = r1->field_f
    //     0x11d1a4c: ldur            d1, [x1, #0xf]
    // 0x11d1a50: stur            d1, [fp, #-0x18]
    // 0x11d1a54: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x11d1a54: ldur            d0, [x1, #0x17]
    // 0x11d1a58: stur            d0, [fp, #-0x10]
    // 0x11d1a5c: r0 = RenderLimitedBox()
    //     0x11d1a5c: bl              #0x11d1b00  ; AllocateRenderLimitedBoxStub -> RenderLimitedBox (size=0x64)
    // 0x11d1a60: mov             x1, x0
    // 0x11d1a64: ldur            d0, [fp, #-0x10]
    // 0x11d1a68: ldur            d1, [fp, #-0x18]
    // 0x11d1a6c: stur            x0, [fp, #-8]
    // 0x11d1a70: r0 = RenderLimitedBox()
    //     0x11d1a70: bl              #0x11d1a8c  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::RenderLimitedBox
    // 0x11d1a74: ldur            x0, [fp, #-8]
    // 0x11d1a78: LeaveFrame
    //     0x11d1a78: mov             SP, fp
    //     0x11d1a7c: ldp             fp, lr, [SP], #0x10
    // 0x11d1a80: ret
    //     0x11d1a80: ret             
    // 0x11d1a84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1a84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1a88: b               #0x11d1a4c
  }
}

// class id: 6620, size: 0x20, field offset: 0x10
//   const constructor, 
class FractionallySizedBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf844c, size: 0xec
    // 0xcf844c: EnterFrame
    //     0xcf844c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8450: mov             fp, SP
    // 0xcf8454: AllocStack(0x18)
    //     0xcf8454: sub             SP, SP, #0x18
    // 0xcf8458: SetupParameters(FractionallySizedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf8458: mov             x5, x1
    //     0xcf845c: mov             x4, x2
    //     0xcf8460: stur            x1, [fp, #-8]
    //     0xcf8464: stur            x2, [fp, #-0x10]
    //     0xcf8468: stur            x3, [fp, #-0x18]
    // 0xcf846c: CheckStackOverflow
    //     0xcf846c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8470: cmp             SP, x16
    //     0xcf8474: b.ls            #0xcf8530
    // 0xcf8478: mov             x0, x3
    // 0xcf847c: r2 = Null
    //     0xcf847c: mov             x2, NULL
    // 0xcf8480: r1 = Null
    //     0xcf8480: mov             x1, NULL
    // 0xcf8484: r4 = 60
    //     0xcf8484: mov             x4, #0x3c
    // 0xcf8488: branchIfSmi(r0, 0xcf8494)
    //     0xcf8488: tbz             w0, #0, #0xcf8494
    // 0xcf848c: r4 = LoadClassIdInstr(r0)
    //     0xcf848c: ldur            x4, [x0, #-1]
    //     0xcf8490: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8494: r17 = 4884
    //     0xcf8494: mov             x17, #0x1314
    // 0xcf8498: cmp             x4, x17
    // 0xcf849c: b.eq            #0xcf84b4
    // 0xcf84a0: r8 = RenderFractionallySizedOverflowBox
    //     0xcf84a0: add             x8, PP, #0x99, lsl #12  ; [pp+0x99e10] Type: RenderFractionallySizedOverflowBox
    //     0xcf84a4: ldr             x8, [x8, #0xe10]
    // 0xcf84a8: r3 = Null
    //     0xcf84a8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e18] Null
    //     0xcf84ac: ldr             x3, [x3, #0xe18]
    // 0xcf84b0: r0 = DefaultTypeTest()
    //     0xcf84b0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf84b4: ldur            x0, [fp, #-8]
    // 0xcf84b8: LoadField: r2 = r0->field_1b
    //     0xcf84b8: ldur            w2, [x0, #0x1b]
    // 0xcf84bc: DecompressPointer r2
    //     0xcf84bc: add             x2, x2, HEAP, lsl #32
    // 0xcf84c0: ldur            x1, [fp, #-0x18]
    // 0xcf84c4: r0 = alignment=()
    //     0xcf84c4: bl              #0xcf5338  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignment=
    // 0xcf84c8: ldur            x1, [fp, #-0x18]
    // 0xcf84cc: r2 = Null
    //     0xcf84cc: mov             x2, NULL
    // 0xcf84d0: r0 = Shader._()
    //     0xcf84d0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf84d4: ldur            x0, [fp, #-8]
    // 0xcf84d8: LoadField: d0 = r0->field_13
    //     0xcf84d8: ldur            d0, [x0, #0x13]
    // 0xcf84dc: ldur            x1, [fp, #-0x18]
    // 0xcf84e0: r0 = heightFactor=()
    //     0xcf84e0: bl              #0xcf8538  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::heightFactor=
    // 0xcf84e4: ldur            x1, [fp, #-0x10]
    // 0xcf84e8: r0 = maybeOf()
    //     0xcf84e8: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf84ec: ldur            x1, [fp, #-0x18]
    // 0xcf84f0: LoadField: r2 = r1->field_5b
    //     0xcf84f0: ldur            w2, [x1, #0x5b]
    // 0xcf84f4: DecompressPointer r2
    //     0xcf84f4: add             x2, x2, HEAP, lsl #32
    // 0xcf84f8: cmp             w2, w0
    // 0xcf84fc: b.eq            #0xcf8520
    // 0xcf8500: StoreField: r1->field_5b = r0
    //     0xcf8500: stur            w0, [x1, #0x5b]
    //     0xcf8504: ldurb           w16, [x1, #-1]
    //     0xcf8508: ldurb           w17, [x0, #-1]
    //     0xcf850c: and             x16, x17, x16, lsr #2
    //     0xcf8510: tst             x16, HEAP, lsr #32
    //     0xcf8514: b.eq            #0xcf851c
    //     0xcf8518: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf851c: r0 = _markNeedResolution()
    //     0xcf851c: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf8520: r0 = Null
    //     0xcf8520: mov             x0, NULL
    // 0xcf8524: LeaveFrame
    //     0xcf8524: mov             SP, fp
    //     0xcf8528: ldp             fp, lr, [SP], #0x10
    // 0xcf852c: ret
    //     0xcf852c: ret             
    // 0xcf8530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8534: b               #0xcf8478
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1900, size: 0x70
    // 0x11d1900: EnterFrame
    //     0x11d1900: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1904: mov             fp, SP
    // 0x11d1908: AllocStack(0x18)
    //     0x11d1908: sub             SP, SP, #0x18
    // 0x11d190c: SetupParameters(FractionallySizedBox this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d190c: mov             x0, x1
    //     0x11d1910: mov             x1, x2
    // 0x11d1914: CheckStackOverflow
    //     0x11d1914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1918: cmp             SP, x16
    //     0x11d191c: b.ls            #0x11d1968
    // 0x11d1920: LoadField: r2 = r0->field_1b
    //     0x11d1920: ldur            w2, [x0, #0x1b]
    // 0x11d1924: DecompressPointer r2
    //     0x11d1924: add             x2, x2, HEAP, lsl #32
    // 0x11d1928: stur            x2, [fp, #-8]
    // 0x11d192c: LoadField: d0 = r0->field_13
    //     0x11d192c: ldur            d0, [x0, #0x13]
    // 0x11d1930: stur            d0, [fp, #-0x18]
    // 0x11d1934: r0 = maybeOf()
    //     0x11d1934: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d1938: stur            x0, [fp, #-0x10]
    // 0x11d193c: r0 = RenderFractionallySizedOverflowBox()
    //     0x11d193c: bl              #0x11d1a28  ; AllocateRenderFractionallySizedOverflowBoxStub -> RenderFractionallySizedOverflowBox (size=0x6c)
    // 0x11d1940: mov             x1, x0
    // 0x11d1944: ldur            x2, [fp, #-8]
    // 0x11d1948: ldur            d0, [fp, #-0x18]
    // 0x11d194c: ldur            x3, [fp, #-0x10]
    // 0x11d1950: stur            x0, [fp, #-8]
    // 0x11d1954: r0 = RenderFractionallySizedOverflowBox()
    //     0x11d1954: bl              #0x11d1970  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::RenderFractionallySizedOverflowBox
    // 0x11d1958: ldur            x0, [fp, #-8]
    // 0x11d195c: LeaveFrame
    //     0x11d195c: mov             SP, fp
    //     0x11d1960: ldp             fp, lr, [SP], #0x10
    // 0x11d1964: ret
    //     0x11d1964: ret             
    // 0x11d1968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d196c: b               #0x11d1920
  }
}

// class id: 6621, size: 0x20, field offset: 0x10
//   const constructor, 
class ConstraintsTransformBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf820c, size: 0xf8
    // 0xcf820c: EnterFrame
    //     0xcf820c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8210: mov             fp, SP
    // 0xcf8214: AllocStack(0x18)
    //     0xcf8214: sub             SP, SP, #0x18
    // 0xcf8218: SetupParameters(ConstraintsTransformBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf8218: mov             x5, x1
    //     0xcf821c: mov             x4, x2
    //     0xcf8220: stur            x1, [fp, #-8]
    //     0xcf8224: stur            x2, [fp, #-0x10]
    //     0xcf8228: stur            x3, [fp, #-0x18]
    // 0xcf822c: CheckStackOverflow
    //     0xcf822c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8230: cmp             SP, x16
    //     0xcf8234: b.ls            #0xcf82fc
    // 0xcf8238: mov             x0, x3
    // 0xcf823c: r2 = Null
    //     0xcf823c: mov             x2, NULL
    // 0xcf8240: r1 = Null
    //     0xcf8240: mov             x1, NULL
    // 0xcf8244: r4 = 60
    //     0xcf8244: mov             x4, #0x3c
    // 0xcf8248: branchIfSmi(r0, 0xcf8254)
    //     0xcf8248: tbz             w0, #0, #0xcf8254
    // 0xcf824c: r4 = LoadClassIdInstr(r0)
    //     0xcf824c: ldur            x4, [x0, #-1]
    //     0xcf8250: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8254: r17 = 4891
    //     0xcf8254: mov             x17, #0x131b
    // 0xcf8258: cmp             x4, x17
    // 0xcf825c: b.eq            #0xcf8274
    // 0xcf8260: r8 = RenderConstraintsTransformBox
    //     0xcf8260: add             x8, PP, #0x99, lsl #12  ; [pp+0x99e40] Type: RenderConstraintsTransformBox
    //     0xcf8264: ldr             x8, [x8, #0xe40]
    // 0xcf8268: r3 = Null
    //     0xcf8268: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e48] Null
    //     0xcf826c: ldr             x3, [x3, #0xe48]
    // 0xcf8270: r0 = DefaultTypeTest()
    //     0xcf8270: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf8274: ldur            x1, [fp, #-0x10]
    // 0xcf8278: r0 = maybeOf()
    //     0xcf8278: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf827c: ldur            x2, [fp, #-0x18]
    // 0xcf8280: LoadField: r1 = r2->field_5b
    //     0xcf8280: ldur            w1, [x2, #0x5b]
    // 0xcf8284: DecompressPointer r1
    //     0xcf8284: add             x1, x1, HEAP, lsl #32
    // 0xcf8288: cmp             w1, w0
    // 0xcf828c: b.eq            #0xcf82b4
    // 0xcf8290: StoreField: r2->field_5b = r0
    //     0xcf8290: stur            w0, [x2, #0x5b]
    //     0xcf8294: ldurb           w16, [x2, #-1]
    //     0xcf8298: ldurb           w17, [x0, #-1]
    //     0xcf829c: and             x16, x17, x16, lsr #2
    //     0xcf82a0: tst             x16, HEAP, lsr #32
    //     0xcf82a4: b.eq            #0xcf82ac
    //     0xcf82a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf82ac: mov             x1, x2
    // 0xcf82b0: r0 = _markNeedResolution()
    //     0xcf82b0: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf82b4: ldur            x0, [fp, #-8]
    // 0xcf82b8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf82b8: ldur            w2, [x0, #0x17]
    // 0xcf82bc: DecompressPointer r2
    //     0xcf82bc: add             x2, x2, HEAP, lsl #32
    // 0xcf82c0: ldur            x1, [fp, #-0x18]
    // 0xcf82c4: r0 = constraintsTransform=()
    //     0xcf82c4: bl              #0xcf8304  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::constraintsTransform=
    // 0xcf82c8: ldur            x0, [fp, #-8]
    // 0xcf82cc: LoadField: r2 = r0->field_13
    //     0xcf82cc: ldur            w2, [x0, #0x13]
    // 0xcf82d0: DecompressPointer r2
    //     0xcf82d0: add             x2, x2, HEAP, lsl #32
    // 0xcf82d4: ldur            x1, [fp, #-0x18]
    // 0xcf82d8: r0 = alignment=()
    //     0xcf82d8: bl              #0xcf5338  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignment=
    // 0xcf82dc: ldur            x1, [fp, #-0x18]
    // 0xcf82e0: r2 = Instance_Clip
    //     0xcf82e0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xcf82e4: ldr             x2, [x2, #0x840]
    // 0xcf82e8: r0 = Shader._()
    //     0xcf82e8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf82ec: r0 = Null
    //     0xcf82ec: mov             x0, NULL
    // 0xcf82f0: LeaveFrame
    //     0xcf82f0: mov             SP, fp
    //     0xcf82f4: ldp             fp, lr, [SP], #0x10
    // 0xcf82f8: ret
    //     0xcf82f8: ret             
    // 0xcf82fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf82fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8300: b               #0xcf8238
  }
  [closure] static BoxConstraints unconstrained(dynamic, BoxConstraints) {
    // ** addr: 0xfbf368, size: 0xc
    // 0xfbf368: r0 = Instance_BoxConstraints
    //     0xfbf368: add             x0, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xfbf36c: ldr             x0, [x0, #0xf0]
    // 0xfbf370: ret
    //     0xfbf370: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d1624, size: 0x80
    // 0x11d1624: EnterFrame
    //     0x11d1624: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1628: mov             fp, SP
    // 0x11d162c: AllocStack(0x20)
    //     0x11d162c: sub             SP, SP, #0x20
    // 0x11d1630: SetupParameters(ConstraintsTransformBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x11d1630: mov             x0, x1
    //     0x11d1634: stur            x1, [fp, #-8]
    //     0x11d1638: mov             x1, x2
    // 0x11d163c: CheckStackOverflow
    //     0x11d163c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1640: cmp             SP, x16
    //     0x11d1644: b.ls            #0x11d169c
    // 0x11d1648: r0 = maybeOf()
    //     0x11d1648: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d164c: mov             x1, x0
    // 0x11d1650: ldur            x0, [fp, #-8]
    // 0x11d1654: stur            x1, [fp, #-0x20]
    // 0x11d1658: LoadField: r2 = r0->field_13
    //     0x11d1658: ldur            w2, [x0, #0x13]
    // 0x11d165c: DecompressPointer r2
    //     0x11d165c: add             x2, x2, HEAP, lsl #32
    // 0x11d1660: stur            x2, [fp, #-0x18]
    // 0x11d1664: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x11d1664: ldur            w3, [x0, #0x17]
    // 0x11d1668: DecompressPointer r3
    //     0x11d1668: add             x3, x3, HEAP, lsl #32
    // 0x11d166c: stur            x3, [fp, #-0x10]
    // 0x11d1670: r0 = RenderConstraintsTransformBox()
    //     0x11d1670: bl              #0x11d18f4  ; AllocateRenderConstraintsTransformBoxStub -> RenderConstraintsTransformBox (size=0x80)
    // 0x11d1674: mov             x1, x0
    // 0x11d1678: ldur            x2, [fp, #-0x18]
    // 0x11d167c: ldur            x3, [fp, #-0x10]
    // 0x11d1680: ldur            x5, [fp, #-0x20]
    // 0x11d1684: stur            x0, [fp, #-8]
    // 0x11d1688: r0 = RenderConstraintsTransformBox()
    //     0x11d1688: bl              #0x11d16a4  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::RenderConstraintsTransformBox
    // 0x11d168c: ldur            x0, [fp, #-8]
    // 0x11d1690: LeaveFrame
    //     0x11d1690: mov             SP, fp
    //     0x11d1694: ldp             fp, lr, [SP], #0x10
    // 0x11d1698: ret
    //     0x11d1698: ret             
    // 0x11d169c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d169c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d16a0: b               #0x11d1648
  }
}

// class id: 6623, size: 0x14, field offset: 0x10
class ConstrainedBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf817c, size: 0x90
    // 0xcf817c: EnterFrame
    //     0xcf817c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8180: mov             fp, SP
    // 0xcf8184: AllocStack(0x10)
    //     0xcf8184: sub             SP, SP, #0x10
    // 0xcf8188: SetupParameters(ConstrainedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf8188: mov             x4, x1
    //     0xcf818c: stur            x1, [fp, #-8]
    //     0xcf8190: stur            x3, [fp, #-0x10]
    // 0xcf8194: CheckStackOverflow
    //     0xcf8194: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8198: cmp             SP, x16
    //     0xcf819c: b.ls            #0xcf8204
    // 0xcf81a0: mov             x0, x3
    // 0xcf81a4: r2 = Null
    //     0xcf81a4: mov             x2, NULL
    // 0xcf81a8: r1 = Null
    //     0xcf81a8: mov             x1, NULL
    // 0xcf81ac: r4 = 60
    //     0xcf81ac: mov             x4, #0x3c
    // 0xcf81b0: branchIfSmi(r0, 0xcf81bc)
    //     0xcf81b0: tbz             w0, #0, #0xcf81bc
    // 0xcf81b4: r4 = LoadClassIdInstr(r0)
    //     0xcf81b4: ldur            x4, [x0, #-1]
    //     0xcf81b8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf81bc: r17 = -4960
    //     0xcf81bc: mov             x17, #-0x1360
    // 0xcf81c0: add             x4, x4, x17
    // 0xcf81c4: cmp             x4, #2
    // 0xcf81c8: b.ls            #0xcf81e0
    // 0xcf81cc: r8 = RenderConstrainedBox
    //     0xcf81cc: add             x8, PP, #0x12, lsl #12  ; [pp+0x12500] Type: RenderConstrainedBox
    //     0xcf81d0: ldr             x8, [x8, #0x500]
    // 0xcf81d4: r3 = Null
    //     0xcf81d4: add             x3, PP, #0x85, lsl #12  ; [pp+0x85050] Null
    //     0xcf81d8: ldr             x3, [x3, #0x50]
    // 0xcf81dc: r0 = DefaultTypeTest()
    //     0xcf81dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf81e0: ldur            x0, [fp, #-8]
    // 0xcf81e4: LoadField: r2 = r0->field_f
    //     0xcf81e4: ldur            w2, [x0, #0xf]
    // 0xcf81e8: DecompressPointer r2
    //     0xcf81e8: add             x2, x2, HEAP, lsl #32
    // 0xcf81ec: ldur            x1, [fp, #-0x10]
    // 0xcf81f0: r0 = additionalConstraints=()
    //     0xcf81f0: bl              #0xcf7f84  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::additionalConstraints=
    // 0xcf81f4: r0 = Null
    //     0xcf81f4: mov             x0, NULL
    // 0xcf81f8: LeaveFrame
    //     0xcf81f8: mov             SP, fp
    //     0xcf81fc: ldp             fp, lr, [SP], #0x10
    // 0xcf8200: ret
    //     0xcf8200: ret             
    // 0xcf8204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8208: b               #0xcf81a0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d15d4, size: 0x50
    // 0x11d15d4: EnterFrame
    //     0x11d15d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d15d8: mov             fp, SP
    // 0x11d15dc: AllocStack(0x8)
    //     0x11d15dc: sub             SP, SP, #8
    // 0x11d15e0: CheckStackOverflow
    //     0x11d15e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d15e4: cmp             SP, x16
    //     0x11d15e8: b.ls            #0x11d161c
    // 0x11d15ec: LoadField: r2 = r1->field_f
    //     0x11d15ec: ldur            w2, [x1, #0xf]
    // 0x11d15f0: DecompressPointer r2
    //     0x11d15f0: add             x2, x2, HEAP, lsl #32
    // 0x11d15f4: stur            x2, [fp, #-8]
    // 0x11d15f8: r0 = RenderConstrainedBox()
    //     0x11d15f8: bl              #0x11d15c8  ; AllocateRenderConstrainedBoxStub -> RenderConstrainedBox (size=0x58)
    // 0x11d15fc: mov             x1, x0
    // 0x11d1600: ldur            x2, [fp, #-8]
    // 0x11d1604: stur            x0, [fp, #-8]
    // 0x11d1608: r0 = RenderIntrinsicWidth()
    //     0x11d1608: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11d160c: ldur            x0, [fp, #-8]
    // 0x11d1610: LeaveFrame
    //     0x11d1610: mov             SP, fp
    //     0x11d1614: ldp             fp, lr, [SP], #0x10
    // 0x11d1618: ret
    //     0x11d1618: ret             
    // 0x11d161c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d161c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1620: b               #0x11d15ec
  }
}

// class id: 6624, size: 0x18, field offset: 0x10
//   const constructor, 
class SizedBox extends SingleChildRenderObjectWidget {

  _Double field_10;
  _Double field_14;
  CupertinoActivityIndicator field_c;

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7ef4, size: 0x90
    // 0xcf7ef4: EnterFrame
    //     0xcf7ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7ef8: mov             fp, SP
    // 0xcf7efc: AllocStack(0x10)
    //     0xcf7efc: sub             SP, SP, #0x10
    // 0xcf7f00: SetupParameters(SizedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf7f00: mov             x4, x1
    //     0xcf7f04: stur            x1, [fp, #-8]
    //     0xcf7f08: stur            x3, [fp, #-0x10]
    // 0xcf7f0c: CheckStackOverflow
    //     0xcf7f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7f10: cmp             SP, x16
    //     0xcf7f14: b.ls            #0xcf7f7c
    // 0xcf7f18: mov             x0, x3
    // 0xcf7f1c: r2 = Null
    //     0xcf7f1c: mov             x2, NULL
    // 0xcf7f20: r1 = Null
    //     0xcf7f20: mov             x1, NULL
    // 0xcf7f24: r4 = 60
    //     0xcf7f24: mov             x4, #0x3c
    // 0xcf7f28: branchIfSmi(r0, 0xcf7f34)
    //     0xcf7f28: tbz             w0, #0, #0xcf7f34
    // 0xcf7f2c: r4 = LoadClassIdInstr(r0)
    //     0xcf7f2c: ldur            x4, [x0, #-1]
    //     0xcf7f30: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7f34: r17 = -4960
    //     0xcf7f34: mov             x17, #-0x1360
    // 0xcf7f38: add             x4, x4, x17
    // 0xcf7f3c: cmp             x4, #2
    // 0xcf7f40: b.ls            #0xcf7f58
    // 0xcf7f44: r8 = RenderConstrainedBox
    //     0xcf7f44: add             x8, PP, #0x12, lsl #12  ; [pp+0x12500] Type: RenderConstrainedBox
    //     0xcf7f48: ldr             x8, [x8, #0x500]
    // 0xcf7f4c: r3 = Null
    //     0xcf7f4c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12508] Null
    //     0xcf7f50: ldr             x3, [x3, #0x508]
    // 0xcf7f54: r0 = DefaultTypeTest()
    //     0xcf7f54: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7f58: ldur            x1, [fp, #-8]
    // 0xcf7f5c: r0 = _additionalConstraints()
    //     0xcf7f5c: bl              #0xcf80d8  ; [package:flutter/src/widgets/basic.dart] SizedBox::_additionalConstraints
    // 0xcf7f60: ldur            x1, [fp, #-0x10]
    // 0xcf7f64: mov             x2, x0
    // 0xcf7f68: r0 = additionalConstraints=()
    //     0xcf7f68: bl              #0xcf7f84  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::additionalConstraints=
    // 0xcf7f6c: r0 = Null
    //     0xcf7f6c: mov             x0, NULL
    // 0xcf7f70: LeaveFrame
    //     0xcf7f70: mov             SP, fp
    //     0xcf7f74: ldp             fp, lr, [SP], #0x10
    // 0xcf7f78: ret
    //     0xcf7f78: ret             
    // 0xcf7f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7f7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7f80: b               #0xcf7f18
  }
  get _ _additionalConstraints(/* No info */) {
    // ** addr: 0xcf80d8, size: 0xa4
    // 0xcf80d8: EnterFrame
    //     0xcf80d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf80dc: mov             fp, SP
    // 0xcf80e0: AllocStack(0x18)
    //     0xcf80e0: sub             SP, SP, #0x18
    // 0xcf80e4: LoadField: r0 = r1->field_f
    //     0xcf80e4: ldur            w0, [x1, #0xf]
    // 0xcf80e8: DecompressPointer r0
    //     0xcf80e8: add             x0, x0, HEAP, lsl #32
    // 0xcf80ec: stur            x0, [fp, #-0x10]
    // 0xcf80f0: LoadField: r2 = r1->field_13
    //     0xcf80f0: ldur            w2, [x1, #0x13]
    // 0xcf80f4: DecompressPointer r2
    //     0xcf80f4: add             x2, x2, HEAP, lsl #32
    // 0xcf80f8: stur            x2, [fp, #-8]
    // 0xcf80fc: cmp             w0, NULL
    // 0xcf8100: b.ne            #0xcf810c
    // 0xcf8104: d0 = 0.000000
    //     0xcf8104: eor             v0.16b, v0.16b, v0.16b
    // 0xcf8108: b               #0xcf8110
    // 0xcf810c: LoadField: d0 = r0->field_7
    //     0xcf810c: ldur            d0, [x0, #7]
    // 0xcf8110: stur            d0, [fp, #-0x18]
    // 0xcf8114: r0 = BoxConstraints()
    //     0xcf8114: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf8118: ldur            d0, [fp, #-0x18]
    // 0xcf811c: StoreField: r0->field_7 = d0
    //     0xcf811c: stur            d0, [x0, #7]
    // 0xcf8120: ldur            x1, [fp, #-0x10]
    // 0xcf8124: cmp             w1, NULL
    // 0xcf8128: b.ne            #0xcf8134
    // 0xcf812c: d0 = inf
    //     0xcf812c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf8130: b               #0xcf8138
    // 0xcf8134: LoadField: d0 = r1->field_7
    //     0xcf8134: ldur            d0, [x1, #7]
    // 0xcf8138: ldur            x1, [fp, #-8]
    // 0xcf813c: StoreField: r0->field_f = d0
    //     0xcf813c: stur            d0, [x0, #0xf]
    // 0xcf8140: cmp             w1, NULL
    // 0xcf8144: b.ne            #0xcf8150
    // 0xcf8148: d0 = 0.000000
    //     0xcf8148: eor             v0.16b, v0.16b, v0.16b
    // 0xcf814c: b               #0xcf8154
    // 0xcf8150: LoadField: d0 = r1->field_7
    //     0xcf8150: ldur            d0, [x1, #7]
    // 0xcf8154: ArrayStore: r0[0] = d0  ; List_8
    //     0xcf8154: stur            d0, [x0, #0x17]
    // 0xcf8158: cmp             w1, NULL
    // 0xcf815c: b.ne            #0xcf8168
    // 0xcf8160: d0 = inf
    //     0xcf8160: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf8164: b               #0xcf816c
    // 0xcf8168: LoadField: d0 = r1->field_7
    //     0xcf8168: ldur            d0, [x1, #7]
    // 0xcf816c: StoreField: r0->field_1f = d0
    //     0xcf816c: stur            d0, [x0, #0x1f]
    // 0xcf8170: LeaveFrame
    //     0xcf8170: mov             SP, fp
    //     0xcf8174: ldp             fp, lr, [SP], #0x10
    // 0xcf8178: ret
    //     0xcf8178: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d157c, size: 0x4c
    // 0x11d157c: EnterFrame
    //     0x11d157c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1580: mov             fp, SP
    // 0x11d1584: AllocStack(0x8)
    //     0x11d1584: sub             SP, SP, #8
    // 0x11d1588: CheckStackOverflow
    //     0x11d1588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d158c: cmp             SP, x16
    //     0x11d1590: b.ls            #0x11d15c0
    // 0x11d1594: r0 = _additionalConstraints()
    //     0x11d1594: bl              #0xcf80d8  ; [package:flutter/src/widgets/basic.dart] SizedBox::_additionalConstraints
    // 0x11d1598: stur            x0, [fp, #-8]
    // 0x11d159c: r0 = RenderConstrainedBox()
    //     0x11d159c: bl              #0x11d15c8  ; AllocateRenderConstrainedBoxStub -> RenderConstrainedBox (size=0x58)
    // 0x11d15a0: mov             x1, x0
    // 0x11d15a4: ldur            x2, [fp, #-8]
    // 0x11d15a8: stur            x0, [fp, #-8]
    // 0x11d15ac: r0 = RenderIntrinsicWidth()
    //     0x11d15ac: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11d15b0: ldur            x0, [fp, #-8]
    // 0x11d15b4: LeaveFrame
    //     0x11d15b4: mov             SP, fp
    //     0x11d15b8: ldp             fp, lr, [SP], #0x10
    // 0x11d15bc: ret
    //     0x11d15bc: ret             
    // 0x11d15c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d15c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d15c4: b               #0x11d1594
  }
}

// class id: 6625, size: 0x14, field offset: 0x10
//   const constructor, 
class CustomSingleChildLayout extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7da4, size: 0x8c
    // 0xcf7da4: EnterFrame
    //     0xcf7da4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7da8: mov             fp, SP
    // 0xcf7dac: AllocStack(0x10)
    //     0xcf7dac: sub             SP, SP, #0x10
    // 0xcf7db0: SetupParameters(CustomSingleChildLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf7db0: mov             x4, x1
    //     0xcf7db4: stur            x1, [fp, #-8]
    //     0xcf7db8: stur            x3, [fp, #-0x10]
    // 0xcf7dbc: CheckStackOverflow
    //     0xcf7dbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7dc0: cmp             SP, x16
    //     0xcf7dc4: b.ls            #0xcf7e28
    // 0xcf7dc8: mov             x0, x3
    // 0xcf7dcc: r2 = Null
    //     0xcf7dcc: mov             x2, NULL
    // 0xcf7dd0: r1 = Null
    //     0xcf7dd0: mov             x1, NULL
    // 0xcf7dd4: r4 = 60
    //     0xcf7dd4: mov             x4, #0x3c
    // 0xcf7dd8: branchIfSmi(r0, 0xcf7de4)
    //     0xcf7dd8: tbz             w0, #0, #0xcf7de4
    // 0xcf7ddc: r4 = LoadClassIdInstr(r0)
    //     0xcf7ddc: ldur            x4, [x0, #-1]
    //     0xcf7de0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7de4: r17 = 4876
    //     0xcf7de4: mov             x17, #0x130c
    // 0xcf7de8: cmp             x4, x17
    // 0xcf7dec: b.eq            #0xcf7e04
    // 0xcf7df0: r8 = RenderCustomSingleChildLayoutBox
    //     0xcf7df0: add             x8, PP, #0x99, lsl #12  ; [pp+0x99e68] Type: RenderCustomSingleChildLayoutBox
    //     0xcf7df4: ldr             x8, [x8, #0xe68]
    // 0xcf7df8: r3 = Null
    //     0xcf7df8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e70] Null
    //     0xcf7dfc: ldr             x3, [x3, #0xe70]
    // 0xcf7e00: r0 = DefaultTypeTest()
    //     0xcf7e00: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7e04: ldur            x0, [fp, #-8]
    // 0xcf7e08: LoadField: r2 = r0->field_f
    //     0xcf7e08: ldur            w2, [x0, #0xf]
    // 0xcf7e0c: DecompressPointer r2
    //     0xcf7e0c: add             x2, x2, HEAP, lsl #32
    // 0xcf7e10: ldur            x1, [fp, #-0x10]
    // 0xcf7e14: r0 = delegate=()
    //     0xcf7e14: bl              #0xcf7e30  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::delegate=
    // 0xcf7e18: r0 = Null
    //     0xcf7e18: mov             x0, NULL
    // 0xcf7e1c: LeaveFrame
    //     0xcf7e1c: mov             SP, fp
    //     0xcf7e20: ldp             fp, lr, [SP], #0x10
    // 0xcf7e24: ret
    //     0xcf7e24: ret             
    // 0xcf7e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7e2c: b               #0xcf7dc8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d14fc, size: 0x74
    // 0x11d14fc: EnterFrame
    //     0x11d14fc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1500: mov             fp, SP
    // 0x11d1504: AllocStack(0x10)
    //     0x11d1504: sub             SP, SP, #0x10
    // 0x11d1508: CheckStackOverflow
    //     0x11d1508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d150c: cmp             SP, x16
    //     0x11d1510: b.ls            #0x11d1568
    // 0x11d1514: LoadField: r0 = r1->field_f
    //     0x11d1514: ldur            w0, [x1, #0xf]
    // 0x11d1518: DecompressPointer r0
    //     0x11d1518: add             x0, x0, HEAP, lsl #32
    // 0x11d151c: stur            x0, [fp, #-8]
    // 0x11d1520: r0 = RenderCustomSingleChildLayoutBox()
    //     0x11d1520: bl              #0x11d1570  ; AllocateRenderCustomSingleChildLayoutBoxStub -> RenderCustomSingleChildLayoutBox (size=0x58)
    // 0x11d1524: mov             x1, x0
    // 0x11d1528: ldur            x0, [fp, #-8]
    // 0x11d152c: stur            x1, [fp, #-0x10]
    // 0x11d1530: StoreField: r1->field_53 = r0
    //     0x11d1530: stur            w0, [x1, #0x53]
    // 0x11d1534: r0 = _LayoutCacheStorage()
    //     0x11d1534: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1538: mov             x1, x0
    // 0x11d153c: ldur            x0, [fp, #-0x10]
    // 0x11d1540: StoreField: r0->field_47 = r1
    //     0x11d1540: stur            w1, [x0, #0x47]
    // 0x11d1544: mov             x1, x0
    // 0x11d1548: r0 = RenderObject()
    //     0x11d1548: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d154c: ldur            x1, [fp, #-0x10]
    // 0x11d1550: r2 = Null
    //     0x11d1550: mov             x2, NULL
    // 0x11d1554: r0 = child=()
    //     0x11d1554: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1558: ldur            x0, [fp, #-0x10]
    // 0x11d155c: LeaveFrame
    //     0x11d155c: mov             SP, fp
    //     0x11d1560: ldp             fp, lr, [SP], #0x10
    // 0x11d1564: ret
    //     0x11d1564: ret             
    // 0x11d1568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d156c: b               #0x11d1514
  }
}

// class id: 6626, size: 0x1c, field offset: 0x10
//   const constructor, 
class Align extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7b8c, size: 0xd0
    // 0xcf7b8c: EnterFrame
    //     0xcf7b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7b90: mov             fp, SP
    // 0xcf7b94: AllocStack(0x18)
    //     0xcf7b94: sub             SP, SP, #0x18
    // 0xcf7b98: SetupParameters(Align this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf7b98: mov             x5, x1
    //     0xcf7b9c: mov             x4, x2
    //     0xcf7ba0: stur            x1, [fp, #-8]
    //     0xcf7ba4: stur            x2, [fp, #-0x10]
    //     0xcf7ba8: stur            x3, [fp, #-0x18]
    // 0xcf7bac: CheckStackOverflow
    //     0xcf7bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7bb0: cmp             SP, x16
    //     0xcf7bb4: b.ls            #0xcf7c54
    // 0xcf7bb8: mov             x0, x3
    // 0xcf7bbc: r2 = Null
    //     0xcf7bbc: mov             x2, NULL
    // 0xcf7bc0: r1 = Null
    //     0xcf7bc0: mov             x1, NULL
    // 0xcf7bc4: r4 = 60
    //     0xcf7bc4: mov             x4, #0x3c
    // 0xcf7bc8: branchIfSmi(r0, 0xcf7bd4)
    //     0xcf7bc8: tbz             w0, #0, #0xcf7bd4
    // 0xcf7bcc: r4 = LoadClassIdInstr(r0)
    //     0xcf7bcc: ldur            x4, [x0, #-1]
    //     0xcf7bd0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7bd4: r17 = 4886
    //     0xcf7bd4: mov             x17, #0x1316
    // 0xcf7bd8: cmp             x4, x17
    // 0xcf7bdc: b.eq            #0xcf7bf4
    // 0xcf7be0: r8 = RenderPositionedBox
    //     0xcf7be0: add             x8, PP, #0x26, lsl #12  ; [pp+0x26ce8] Type: RenderPositionedBox
    //     0xcf7be4: ldr             x8, [x8, #0xce8]
    // 0xcf7be8: r3 = Null
    //     0xcf7be8: add             x3, PP, #0x26, lsl #12  ; [pp+0x26cf0] Null
    //     0xcf7bec: ldr             x3, [x3, #0xcf0]
    // 0xcf7bf0: r0 = DefaultTypeTest()
    //     0xcf7bf0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7bf4: ldur            x0, [fp, #-8]
    // 0xcf7bf8: LoadField: r2 = r0->field_f
    //     0xcf7bf8: ldur            w2, [x0, #0xf]
    // 0xcf7bfc: DecompressPointer r2
    //     0xcf7bfc: add             x2, x2, HEAP, lsl #32
    // 0xcf7c00: ldur            x1, [fp, #-0x18]
    // 0xcf7c04: r0 = alignment=()
    //     0xcf7c04: bl              #0xcf5338  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignment=
    // 0xcf7c08: ldur            x0, [fp, #-8]
    // 0xcf7c0c: LoadField: r2 = r0->field_13
    //     0xcf7c0c: ldur            w2, [x0, #0x13]
    // 0xcf7c10: DecompressPointer r2
    //     0xcf7c10: add             x2, x2, HEAP, lsl #32
    // 0xcf7c14: ldur            x1, [fp, #-0x18]
    // 0xcf7c18: r0 = widthFactor=()
    //     0xcf7c18: bl              #0xcf7d00  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::widthFactor=
    // 0xcf7c1c: ldur            x0, [fp, #-8]
    // 0xcf7c20: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf7c20: ldur            w2, [x0, #0x17]
    // 0xcf7c24: DecompressPointer r2
    //     0xcf7c24: add             x2, x2, HEAP, lsl #32
    // 0xcf7c28: ldur            x1, [fp, #-0x18]
    // 0xcf7c2c: r0 = heightFactor=()
    //     0xcf7c2c: bl              #0xcf7c5c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::heightFactor=
    // 0xcf7c30: ldur            x1, [fp, #-0x10]
    // 0xcf7c34: r0 = maybeOf()
    //     0xcf7c34: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf7c38: ldur            x1, [fp, #-0x18]
    // 0xcf7c3c: mov             x2, x0
    // 0xcf7c40: r0 = textDirection=()
    //     0xcf7c40: bl              #0xcf45d0  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::textDirection=
    // 0xcf7c44: r0 = Null
    //     0xcf7c44: mov             x0, NULL
    // 0xcf7c48: LeaveFrame
    //     0xcf7c48: mov             SP, fp
    //     0xcf7c4c: ldp             fp, lr, [SP], #0x10
    // 0xcf7c50: ret
    //     0xcf7c50: ret             
    // 0xcf7c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7c54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7c58: b               #0xcf7bb8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d136c, size: 0x84
    // 0x11d136c: EnterFrame
    //     0x11d136c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1370: mov             fp, SP
    // 0x11d1374: AllocStack(0x20)
    //     0x11d1374: sub             SP, SP, #0x20
    // 0x11d1378: SetupParameters(Align this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d1378: mov             x0, x1
    //     0x11d137c: mov             x1, x2
    // 0x11d1380: CheckStackOverflow
    //     0x11d1380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1384: cmp             SP, x16
    //     0x11d1388: b.ls            #0x11d13e8
    // 0x11d138c: LoadField: r2 = r0->field_f
    //     0x11d138c: ldur            w2, [x0, #0xf]
    // 0x11d1390: DecompressPointer r2
    //     0x11d1390: add             x2, x2, HEAP, lsl #32
    // 0x11d1394: stur            x2, [fp, #-0x18]
    // 0x11d1398: LoadField: r6 = r0->field_13
    //     0x11d1398: ldur            w6, [x0, #0x13]
    // 0x11d139c: DecompressPointer r6
    //     0x11d139c: add             x6, x6, HEAP, lsl #32
    // 0x11d13a0: stur            x6, [fp, #-0x10]
    // 0x11d13a4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x11d13a4: ldur            w3, [x0, #0x17]
    // 0x11d13a8: DecompressPointer r3
    //     0x11d13a8: add             x3, x3, HEAP, lsl #32
    // 0x11d13ac: stur            x3, [fp, #-8]
    // 0x11d13b0: r0 = maybeOf()
    //     0x11d13b0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d13b4: stur            x0, [fp, #-0x20]
    // 0x11d13b8: r0 = RenderPositionedBox()
    //     0x11d13b8: bl              #0x11d14f0  ; AllocateRenderPositionedBoxStub -> RenderPositionedBox (size=0x68)
    // 0x11d13bc: mov             x1, x0
    // 0x11d13c0: ldur            x2, [fp, #-0x18]
    // 0x11d13c4: ldur            x3, [fp, #-8]
    // 0x11d13c8: ldur            x5, [fp, #-0x20]
    // 0x11d13cc: ldur            x6, [fp, #-0x10]
    // 0x11d13d0: stur            x0, [fp, #-8]
    // 0x11d13d4: r0 = RenderPositionedBox()
    //     0x11d13d4: bl              #0x11d13f0  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::RenderPositionedBox
    // 0x11d13d8: ldur            x0, [fp, #-8]
    // 0x11d13dc: LeaveFrame
    //     0x11d13dc: mov             SP, fp
    //     0x11d13e0: ldp             fp, lr, [SP], #0x10
    // 0x11d13e4: ret
    //     0x11d13e4: ret             
    // 0x11d13e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d13e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d13ec: b               #0x11d138c
  }
}

// class id: 6627, size: 0x1c, field offset: 0x1c
//   const constructor, 
class Center extends Align {

  CircularProgressIndicator field_c;
  Alignment field_10;
}

// class id: 6628, size: 0x14, field offset: 0x10
//   const constructor, 
class Padding extends SingleChildRenderObjectWidget {

  Icon field_c;
  EdgeInsets field_10;

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf79ec, size: 0xa8
    // 0xcf79ec: EnterFrame
    //     0xcf79ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcf79f0: mov             fp, SP
    // 0xcf79f4: AllocStack(0x18)
    //     0xcf79f4: sub             SP, SP, #0x18
    // 0xcf79f8: SetupParameters(Padding this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf79f8: mov             x5, x1
    //     0xcf79fc: mov             x4, x2
    //     0xcf7a00: stur            x1, [fp, #-8]
    //     0xcf7a04: stur            x2, [fp, #-0x10]
    //     0xcf7a08: stur            x3, [fp, #-0x18]
    // 0xcf7a0c: CheckStackOverflow
    //     0xcf7a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7a10: cmp             SP, x16
    //     0xcf7a14: b.ls            #0xcf7a8c
    // 0xcf7a18: mov             x0, x3
    // 0xcf7a1c: r2 = Null
    //     0xcf7a1c: mov             x2, NULL
    // 0xcf7a20: r1 = Null
    //     0xcf7a20: mov             x1, NULL
    // 0xcf7a24: r4 = 60
    //     0xcf7a24: mov             x4, #0x3c
    // 0xcf7a28: branchIfSmi(r0, 0xcf7a34)
    //     0xcf7a28: tbz             w0, #0, #0xcf7a34
    // 0xcf7a2c: r4 = LoadClassIdInstr(r0)
    //     0xcf7a2c: ldur            x4, [x0, #-1]
    //     0xcf7a30: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7a34: r17 = 4877
    //     0xcf7a34: mov             x17, #0x130d
    // 0xcf7a38: cmp             x4, x17
    // 0xcf7a3c: b.eq            #0xcf7a54
    // 0xcf7a40: r8 = RenderPadding
    //     0xcf7a40: add             x8, PP, #0x26, lsl #12  ; [pp+0x26c78] Type: RenderPadding
    //     0xcf7a44: ldr             x8, [x8, #0xc78]
    // 0xcf7a48: r3 = Null
    //     0xcf7a48: add             x3, PP, #0x26, lsl #12  ; [pp+0x26c80] Null
    //     0xcf7a4c: ldr             x3, [x3, #0xc80]
    // 0xcf7a50: r0 = DefaultTypeTest()
    //     0xcf7a50: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7a54: ldur            x0, [fp, #-8]
    // 0xcf7a58: LoadField: r2 = r0->field_f
    //     0xcf7a58: ldur            w2, [x0, #0xf]
    // 0xcf7a5c: DecompressPointer r2
    //     0xcf7a5c: add             x2, x2, HEAP, lsl #32
    // 0xcf7a60: ldur            x1, [fp, #-0x18]
    // 0xcf7a64: r0 = padding=()
    //     0xcf7a64: bl              #0xcf7b04  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::padding=
    // 0xcf7a68: ldur            x1, [fp, #-0x10]
    // 0xcf7a6c: r0 = maybeOf()
    //     0xcf7a6c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf7a70: ldur            x1, [fp, #-0x18]
    // 0xcf7a74: mov             x2, x0
    // 0xcf7a78: r0 = textDirection=()
    //     0xcf7a78: bl              #0xcf7a94  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::textDirection=
    // 0xcf7a7c: r0 = Null
    //     0xcf7a7c: mov             x0, NULL
    // 0xcf7a80: LeaveFrame
    //     0xcf7a80: mov             SP, fp
    //     0xcf7a84: ldp             fp, lr, [SP], #0x10
    // 0xcf7a88: ret
    //     0xcf7a88: ret             
    // 0xcf7a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7a8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7a90: b               #0xcf7a18
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d12d4, size: 0x8c
    // 0x11d12d4: EnterFrame
    //     0x11d12d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d12d8: mov             fp, SP
    // 0x11d12dc: AllocStack(0x18)
    //     0x11d12dc: sub             SP, SP, #0x18
    // 0x11d12e0: SetupParameters(Padding this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d12e0: mov             x0, x1
    //     0x11d12e4: mov             x1, x2
    // 0x11d12e8: CheckStackOverflow
    //     0x11d12e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d12ec: cmp             SP, x16
    //     0x11d12f0: b.ls            #0x11d1358
    // 0x11d12f4: LoadField: r2 = r0->field_f
    //     0x11d12f4: ldur            w2, [x0, #0xf]
    // 0x11d12f8: DecompressPointer r2
    //     0x11d12f8: add             x2, x2, HEAP, lsl #32
    // 0x11d12fc: stur            x2, [fp, #-8]
    // 0x11d1300: r0 = maybeOf()
    //     0x11d1300: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d1304: stur            x0, [fp, #-0x10]
    // 0x11d1308: r0 = RenderPadding()
    //     0x11d1308: bl              #0x11d1360  ; AllocateRenderPaddingStub -> RenderPadding (size=0x60)
    // 0x11d130c: mov             x1, x0
    // 0x11d1310: ldur            x0, [fp, #-0x10]
    // 0x11d1314: stur            x1, [fp, #-0x18]
    // 0x11d1318: StoreField: r1->field_5b = r0
    //     0x11d1318: stur            w0, [x1, #0x5b]
    // 0x11d131c: ldur            x0, [fp, #-8]
    // 0x11d1320: StoreField: r1->field_57 = r0
    //     0x11d1320: stur            w0, [x1, #0x57]
    // 0x11d1324: r0 = _LayoutCacheStorage()
    //     0x11d1324: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1328: mov             x1, x0
    // 0x11d132c: ldur            x0, [fp, #-0x18]
    // 0x11d1330: StoreField: r0->field_47 = r1
    //     0x11d1330: stur            w1, [x0, #0x47]
    // 0x11d1334: mov             x1, x0
    // 0x11d1338: r0 = RenderObject()
    //     0x11d1338: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d133c: ldur            x1, [fp, #-0x18]
    // 0x11d1340: r2 = Null
    //     0x11d1340: mov             x2, NULL
    // 0x11d1344: r0 = child=()
    //     0x11d1344: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1348: ldur            x0, [fp, #-0x18]
    // 0x11d134c: LeaveFrame
    //     0x11d134c: mov             SP, fp
    //     0x11d1350: ldp             fp, lr, [SP], #0x10
    // 0x11d1354: ret
    //     0x11d1354: ret             
    // 0x11d1358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1358: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d135c: b               #0x11d12f4
  }
}

// class id: 6629, size: 0x18, field offset: 0x10
//   const constructor, 
class RotatedBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7914, size: 0x88
    // 0xcf7914: EnterFrame
    //     0xcf7914: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7918: mov             fp, SP
    // 0xcf791c: AllocStack(0x10)
    //     0xcf791c: sub             SP, SP, #0x10
    // 0xcf7920: SetupParameters(RotatedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf7920: mov             x4, x1
    //     0xcf7924: stur            x1, [fp, #-8]
    //     0xcf7928: stur            x3, [fp, #-0x10]
    // 0xcf792c: CheckStackOverflow
    //     0xcf792c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7930: cmp             SP, x16
    //     0xcf7934: b.ls            #0xcf7994
    // 0xcf7938: mov             x0, x3
    // 0xcf793c: r2 = Null
    //     0xcf793c: mov             x2, NULL
    // 0xcf7940: r1 = Null
    //     0xcf7940: mov             x1, NULL
    // 0xcf7944: r4 = 60
    //     0xcf7944: mov             x4, #0x3c
    // 0xcf7948: branchIfSmi(r0, 0xcf7954)
    //     0xcf7948: tbz             w0, #0, #0xcf7954
    // 0xcf794c: r4 = LoadClassIdInstr(r0)
    //     0xcf794c: ldur            x4, [x0, #-1]
    //     0xcf7950: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7954: r17 = 4868
    //     0xcf7954: mov             x17, #0x1304
    // 0xcf7958: cmp             x4, x17
    // 0xcf795c: b.eq            #0xcf7974
    // 0xcf7960: r8 = RenderRotatedBox
    //     0xcf7960: add             x8, PP, #0x90, lsl #12  ; [pp+0x901a0] Type: RenderRotatedBox
    //     0xcf7964: ldr             x8, [x8, #0x1a0]
    // 0xcf7968: r3 = Null
    //     0xcf7968: add             x3, PP, #0x90, lsl #12  ; [pp+0x901a8] Null
    //     0xcf796c: ldr             x3, [x3, #0x1a8]
    // 0xcf7970: r0 = DefaultTypeTest()
    //     0xcf7970: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7974: ldur            x0, [fp, #-8]
    // 0xcf7978: LoadField: r2 = r0->field_f
    //     0xcf7978: ldur            x2, [x0, #0xf]
    // 0xcf797c: ldur            x1, [fp, #-0x10]
    // 0xcf7980: r0 = quarterTurns=()
    //     0xcf7980: bl              #0xcf799c  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::quarterTurns=
    // 0xcf7984: r0 = Null
    //     0xcf7984: mov             x0, NULL
    // 0xcf7988: LeaveFrame
    //     0xcf7988: mov             SP, fp
    //     0xcf798c: ldp             fp, lr, [SP], #0x10
    // 0xcf7990: ret
    //     0xcf7990: ret             
    // 0xcf7994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7994: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7998: b               #0xcf7938
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d11d4, size: 0x4c
    // 0x11d11d4: EnterFrame
    //     0x11d11d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d11d8: mov             fp, SP
    // 0x11d11dc: AllocStack(0x10)
    //     0x11d11dc: sub             SP, SP, #0x10
    // 0x11d11e0: CheckStackOverflow
    //     0x11d11e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d11e4: cmp             SP, x16
    //     0x11d11e8: b.ls            #0x11d1218
    // 0x11d11ec: LoadField: r2 = r1->field_f
    //     0x11d11ec: ldur            x2, [x1, #0xf]
    // 0x11d11f0: stur            x2, [fp, #-8]
    // 0x11d11f4: r0 = RenderRotatedBox()
    //     0x11d11f4: bl              #0x11d12c8  ; AllocateRenderRotatedBoxStub -> RenderRotatedBox (size=0x64)
    // 0x11d11f8: mov             x1, x0
    // 0x11d11fc: ldur            x2, [fp, #-8]
    // 0x11d1200: stur            x0, [fp, #-0x10]
    // 0x11d1204: r0 = RenderRotatedBox()
    //     0x11d1204: bl              #0x11d1220  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::RenderRotatedBox
    // 0x11d1208: ldur            x0, [fp, #-0x10]
    // 0x11d120c: LeaveFrame
    //     0x11d120c: mov             SP, fp
    //     0x11d1210: ldp             fp, lr, [SP], #0x10
    // 0x11d1214: ret
    //     0x11d1214: ret             
    // 0x11d1218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d121c: b               #0x11d11ec
  }
}

// class id: 6630, size: 0x18, field offset: 0x10
//   const constructor, 
class FractionalTranslation extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf77e0, size: 0xa0
    // 0xcf77e0: EnterFrame
    //     0xcf77e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf77e4: mov             fp, SP
    // 0xcf77e8: AllocStack(0x10)
    //     0xcf77e8: sub             SP, SP, #0x10
    // 0xcf77ec: SetupParameters(FractionalTranslation this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf77ec: mov             x4, x1
    //     0xcf77f0: stur            x1, [fp, #-8]
    //     0xcf77f4: stur            x3, [fp, #-0x10]
    // 0xcf77f8: CheckStackOverflow
    //     0xcf77f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf77fc: cmp             SP, x16
    //     0xcf7800: b.ls            #0xcf7878
    // 0xcf7804: mov             x0, x3
    // 0xcf7808: r2 = Null
    //     0xcf7808: mov             x2, NULL
    // 0xcf780c: r1 = Null
    //     0xcf780c: mov             x1, NULL
    // 0xcf7810: r4 = 60
    //     0xcf7810: mov             x4, #0x3c
    // 0xcf7814: branchIfSmi(r0, 0xcf7820)
    //     0xcf7814: tbz             w0, #0, #0xcf7820
    // 0xcf7818: r4 = LoadClassIdInstr(r0)
    //     0xcf7818: ldur            x4, [x0, #-1]
    //     0xcf781c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7820: r17 = 4925
    //     0xcf7820: mov             x17, #0x133d
    // 0xcf7824: cmp             x4, x17
    // 0xcf7828: b.eq            #0xcf7840
    // 0xcf782c: r8 = RenderFractionalTranslation
    //     0xcf782c: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3f20] Type: RenderFractionalTranslation
    //     0xcf7830: ldr             x8, [x8, #0xf20]
    // 0xcf7834: r3 = Null
    //     0xcf7834: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3f28] Null
    //     0xcf7838: ldr             x3, [x3, #0xf28]
    // 0xcf783c: r0 = DefaultTypeTest()
    //     0xcf783c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7840: ldur            x0, [fp, #-8]
    // 0xcf7844: LoadField: r2 = r0->field_f
    //     0xcf7844: ldur            w2, [x0, #0xf]
    // 0xcf7848: DecompressPointer r2
    //     0xcf7848: add             x2, x2, HEAP, lsl #32
    // 0xcf784c: ldur            x1, [fp, #-0x10]
    // 0xcf7850: r0 = translation=()
    //     0xcf7850: bl              #0xcf7880  ; [package:flutter/src/rendering/proxy_box.dart] RenderFractionalTranslation::translation=
    // 0xcf7854: ldur            x1, [fp, #-8]
    // 0xcf7858: LoadField: r2 = r1->field_13
    //     0xcf7858: ldur            w2, [x1, #0x13]
    // 0xcf785c: DecompressPointer r2
    //     0xcf785c: add             x2, x2, HEAP, lsl #32
    // 0xcf7860: ldur            x1, [fp, #-0x10]
    // 0xcf7864: StoreField: r1->field_57 = r2
    //     0xcf7864: stur            w2, [x1, #0x57]
    // 0xcf7868: r0 = Null
    //     0xcf7868: mov             x0, NULL
    // 0xcf786c: LeaveFrame
    //     0xcf786c: mov             SP, fp
    //     0xcf7870: ldp             fp, lr, [SP], #0x10
    // 0xcf7874: ret
    //     0xcf7874: ret             
    // 0xcf7878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf787c: b               #0xcf7804
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d10d8, size: 0x60
    // 0x11d10d8: EnterFrame
    //     0x11d10d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d10dc: mov             fp, SP
    // 0x11d10e0: AllocStack(0x10)
    //     0x11d10e0: sub             SP, SP, #0x10
    // 0x11d10e4: CheckStackOverflow
    //     0x11d10e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d10e8: cmp             SP, x16
    //     0x11d10ec: b.ls            #0x11d1130
    // 0x11d10f0: LoadField: r3 = r1->field_f
    //     0x11d10f0: ldur            w3, [x1, #0xf]
    // 0x11d10f4: DecompressPointer r3
    //     0x11d10f4: add             x3, x3, HEAP, lsl #32
    // 0x11d10f8: stur            x3, [fp, #-0x10]
    // 0x11d10fc: LoadField: r2 = r1->field_13
    //     0x11d10fc: ldur            w2, [x1, #0x13]
    // 0x11d1100: DecompressPointer r2
    //     0x11d1100: add             x2, x2, HEAP, lsl #32
    // 0x11d1104: stur            x2, [fp, #-8]
    // 0x11d1108: r0 = RenderFractionalTranslation()
    //     0x11d1108: bl              #0x11d11c8  ; AllocateRenderFractionalTranslationStub -> RenderFractionalTranslation (size=0x5c)
    // 0x11d110c: mov             x1, x0
    // 0x11d1110: ldur            x2, [fp, #-8]
    // 0x11d1114: ldur            x3, [fp, #-0x10]
    // 0x11d1118: stur            x0, [fp, #-8]
    // 0x11d111c: r0 = RenderFractionalTranslation()
    //     0x11d111c: bl              #0x11d1138  ; [package:flutter/src/rendering/proxy_box.dart] RenderFractionalTranslation::RenderFractionalTranslation
    // 0x11d1120: ldur            x0, [fp, #-8]
    // 0x11d1124: LeaveFrame
    //     0x11d1124: mov             SP, fp
    //     0x11d1128: ldp             fp, lr, [SP], #0x10
    // 0x11d112c: ret
    //     0x11d112c: ret             
    // 0x11d1130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1134: b               #0x11d10f0
  }
}

// class id: 6631, size: 0x1c, field offset: 0x10
//   const constructor, 
class FittedBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf749c, size: 0xcc
    // 0xcf749c: EnterFrame
    //     0xcf749c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf74a0: mov             fp, SP
    // 0xcf74a4: AllocStack(0x18)
    //     0xcf74a4: sub             SP, SP, #0x18
    // 0xcf74a8: SetupParameters(FittedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf74a8: mov             x5, x1
    //     0xcf74ac: mov             x4, x2
    //     0xcf74b0: stur            x1, [fp, #-8]
    //     0xcf74b4: stur            x2, [fp, #-0x10]
    //     0xcf74b8: stur            x3, [fp, #-0x18]
    // 0xcf74bc: CheckStackOverflow
    //     0xcf74bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf74c0: cmp             SP, x16
    //     0xcf74c4: b.ls            #0xcf7560
    // 0xcf74c8: mov             x0, x3
    // 0xcf74cc: r2 = Null
    //     0xcf74cc: mov             x2, NULL
    // 0xcf74d0: r1 = Null
    //     0xcf74d0: mov             x1, NULL
    // 0xcf74d4: r4 = 60
    //     0xcf74d4: mov             x4, #0x3c
    // 0xcf74d8: branchIfSmi(r0, 0xcf74e4)
    //     0xcf74d8: tbz             w0, #0, #0xcf74e4
    // 0xcf74dc: r4 = LoadClassIdInstr(r0)
    //     0xcf74dc: ldur            x4, [x0, #-1]
    //     0xcf74e0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf74e4: r17 = 4926
    //     0xcf74e4: mov             x17, #0x133e
    // 0xcf74e8: cmp             x4, x17
    // 0xcf74ec: b.eq            #0xcf7504
    // 0xcf74f0: r8 = RenderFittedBox
    //     0xcf74f0: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ef0] Type: RenderFittedBox
    //     0xcf74f4: ldr             x8, [x8, #0xef0]
    // 0xcf74f8: r3 = Null
    //     0xcf74f8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ef8] Null
    //     0xcf74fc: ldr             x3, [x3, #0xef8]
    // 0xcf7500: r0 = DefaultTypeTest()
    //     0xcf7500: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf7504: ldur            x0, [fp, #-8]
    // 0xcf7508: LoadField: r2 = r0->field_f
    //     0xcf7508: ldur            w2, [x0, #0xf]
    // 0xcf750c: DecompressPointer r2
    //     0xcf750c: add             x2, x2, HEAP, lsl #32
    // 0xcf7510: ldur            x1, [fp, #-0x18]
    // 0xcf7514: r0 = fit=()
    //     0xcf7514: bl              #0xcf771c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::fit=
    // 0xcf7518: ldur            x1, [fp, #-0x18]
    // 0xcf751c: r2 = Instance_Alignment
    //     0xcf751c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xcf7520: ldr             x2, [x2, #0xb80]
    // 0xcf7524: r0 = alignment=()
    //     0xcf7524: bl              #0xcf769c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::alignment=
    // 0xcf7528: ldur            x1, [fp, #-0x10]
    // 0xcf752c: r0 = maybeOf()
    //     0xcf752c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf7530: ldur            x1, [fp, #-0x18]
    // 0xcf7534: mov             x2, x0
    // 0xcf7538: r0 = textDirection=()
    //     0xcf7538: bl              #0xcf75e0  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::textDirection=
    // 0xcf753c: ldur            x0, [fp, #-8]
    // 0xcf7540: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf7540: ldur            w2, [x0, #0x17]
    // 0xcf7544: DecompressPointer r2
    //     0xcf7544: add             x2, x2, HEAP, lsl #32
    // 0xcf7548: ldur            x1, [fp, #-0x18]
    // 0xcf754c: r0 = clipBehavior=()
    //     0xcf754c: bl              #0xcf7568  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::clipBehavior=
    // 0xcf7550: r0 = Null
    //     0xcf7550: mov             x0, NULL
    // 0xcf7554: LeaveFrame
    //     0xcf7554: mov             SP, fp
    //     0xcf7558: ldp             fp, lr, [SP], #0x10
    // 0xcf755c: ret
    //     0xcf755c: ret             
    // 0xcf7560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7560: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7564: b               #0xcf74c8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0f6c, size: 0x80
    // 0x11d0f6c: EnterFrame
    //     0x11d0f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0f70: mov             fp, SP
    // 0x11d0f74: AllocStack(0x20)
    //     0x11d0f74: sub             SP, SP, #0x20
    // 0x11d0f78: SetupParameters(FittedBox this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x11d0f78: mov             x0, x1
    //     0x11d0f7c: stur            x1, [fp, #-0x10]
    //     0x11d0f80: mov             x1, x2
    // 0x11d0f84: CheckStackOverflow
    //     0x11d0f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0f88: cmp             SP, x16
    //     0x11d0f8c: b.ls            #0x11d0fe4
    // 0x11d0f90: LoadField: r3 = r0->field_f
    //     0x11d0f90: ldur            w3, [x0, #0xf]
    // 0x11d0f94: DecompressPointer r3
    //     0x11d0f94: add             x3, x3, HEAP, lsl #32
    // 0x11d0f98: stur            x3, [fp, #-8]
    // 0x11d0f9c: r0 = maybeOf()
    //     0x11d0f9c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d0fa0: mov             x1, x0
    // 0x11d0fa4: ldur            x0, [fp, #-0x10]
    // 0x11d0fa8: stur            x1, [fp, #-0x20]
    // 0x11d0fac: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x11d0fac: ldur            w2, [x0, #0x17]
    // 0x11d0fb0: DecompressPointer r2
    //     0x11d0fb0: add             x2, x2, HEAP, lsl #32
    // 0x11d0fb4: stur            x2, [fp, #-0x18]
    // 0x11d0fb8: r0 = RenderFittedBox()
    //     0x11d0fb8: bl              #0x11d10cc  ; AllocateRenderFittedBoxStub -> RenderFittedBox (size=0x70)
    // 0x11d0fbc: mov             x1, x0
    // 0x11d0fc0: ldur            x2, [fp, #-0x18]
    // 0x11d0fc4: ldur            x3, [fp, #-8]
    // 0x11d0fc8: ldur            x5, [fp, #-0x20]
    // 0x11d0fcc: stur            x0, [fp, #-8]
    // 0x11d0fd0: r0 = RenderFittedBox()
    //     0x11d0fd0: bl              #0x11d0fec  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::RenderFittedBox
    // 0x11d0fd4: ldur            x0, [fp, #-8]
    // 0x11d0fd8: LeaveFrame
    //     0x11d0fd8: mov             SP, fp
    //     0x11d0fdc: ldp             fp, lr, [SP], #0x10
    // 0x11d0fe0: ret
    //     0x11d0fe0: ret             
    // 0x11d0fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0fe8: b               #0x11d0f90
  }
}

// class id: 6632, size: 0x24, field offset: 0x10
//   const constructor, 
class CompositedTransformFollower extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7194, size: 0xd4
    // 0xcf7194: EnterFrame
    //     0xcf7194: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7198: mov             fp, SP
    // 0xcf719c: AllocStack(0x10)
    //     0xcf719c: sub             SP, SP, #0x10
    // 0xcf71a0: SetupParameters(CompositedTransformFollower this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf71a0: mov             x4, x1
    //     0xcf71a4: stur            x1, [fp, #-8]
    //     0xcf71a8: stur            x3, [fp, #-0x10]
    // 0xcf71ac: CheckStackOverflow
    //     0xcf71ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf71b0: cmp             SP, x16
    //     0xcf71b4: b.ls            #0xcf7260
    // 0xcf71b8: mov             x0, x3
    // 0xcf71bc: r2 = Null
    //     0xcf71bc: mov             x2, NULL
    // 0xcf71c0: r1 = Null
    //     0xcf71c0: mov             x1, NULL
    // 0xcf71c4: r4 = 60
    //     0xcf71c4: mov             x4, #0x3c
    // 0xcf71c8: branchIfSmi(r0, 0xcf71d4)
    //     0xcf71c8: tbz             w0, #0, #0xcf71d4
    // 0xcf71cc: r4 = LoadClassIdInstr(r0)
    //     0xcf71cc: ldur            x4, [x0, #-1]
    //     0xcf71d0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf71d4: r17 = 4915
    //     0xcf71d4: mov             x17, #0x1333
    // 0xcf71d8: cmp             x4, x17
    // 0xcf71dc: b.eq            #0xcf71f4
    // 0xcf71e0: r8 = RenderFollowerLayer
    //     0xcf71e0: add             x8, PP, #0x26, lsl #12  ; [pp+0x26cd0] Type: RenderFollowerLayer
    //     0xcf71e4: ldr             x8, [x8, #0xcd0]
    // 0xcf71e8: r3 = Null
    //     0xcf71e8: add             x3, PP, #0x26, lsl #12  ; [pp+0x26cd8] Null
    //     0xcf71ec: ldr             x3, [x3, #0xcd8]
    // 0xcf71f0: r0 = DefaultTypeTest()
    //     0xcf71f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf71f4: ldur            x0, [fp, #-8]
    // 0xcf71f8: LoadField: r2 = r0->field_f
    //     0xcf71f8: ldur            w2, [x0, #0xf]
    // 0xcf71fc: DecompressPointer r2
    //     0xcf71fc: add             x2, x2, HEAP, lsl #32
    // 0xcf7200: ldur            x1, [fp, #-0x10]
    // 0xcf7204: r0 = link=()
    //     0xcf7204: bl              #0xcf742c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::link=
    // 0xcf7208: ldur            x0, [fp, #-8]
    // 0xcf720c: LoadField: r2 = r0->field_13
    //     0xcf720c: ldur            w2, [x0, #0x13]
    // 0xcf7210: DecompressPointer r2
    //     0xcf7210: add             x2, x2, HEAP, lsl #32
    // 0xcf7214: ldur            x1, [fp, #-0x10]
    // 0xcf7218: r0 = showWhenUnlinked=()
    //     0xcf7218: bl              #0xcf73d8  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::showWhenUnlinked=
    // 0xcf721c: ldur            x0, [fp, #-8]
    // 0xcf7220: LoadField: r2 = r0->field_1f
    //     0xcf7220: ldur            w2, [x0, #0x1f]
    // 0xcf7224: DecompressPointer r2
    //     0xcf7224: add             x2, x2, HEAP, lsl #32
    // 0xcf7228: ldur            x1, [fp, #-0x10]
    // 0xcf722c: r0 = offset=()
    //     0xcf722c: bl              #0xcf7350  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::offset=
    // 0xcf7230: ldur            x1, [fp, #-0x10]
    // 0xcf7234: r2 = Instance_Alignment
    //     0xcf7234: add             x2, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf7238: ldr             x2, [x2, #0x510]
    // 0xcf723c: r0 = leaderAnchor=()
    //     0xcf723c: bl              #0xcf72dc  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::leaderAnchor=
    // 0xcf7240: ldur            x1, [fp, #-0x10]
    // 0xcf7244: r2 = Instance_Alignment
    //     0xcf7244: add             x2, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xcf7248: ldr             x2, [x2, #0x510]
    // 0xcf724c: r0 = followerAnchor=()
    //     0xcf724c: bl              #0xcf7268  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::followerAnchor=
    // 0xcf7250: r0 = Null
    //     0xcf7250: mov             x0, NULL
    // 0xcf7254: LeaveFrame
    //     0xcf7254: mov             SP, fp
    //     0xcf7258: ldp             fp, lr, [SP], #0x10
    // 0xcf725c: ret
    //     0xcf725c: ret             
    // 0xcf7260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7264: b               #0xcf71b8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0e28, size: 0x70
    // 0x11d0e28: EnterFrame
    //     0x11d0e28: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0e2c: mov             fp, SP
    // 0x11d0e30: AllocStack(0x18)
    //     0x11d0e30: sub             SP, SP, #0x18
    // 0x11d0e34: CheckStackOverflow
    //     0x11d0e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0e38: cmp             SP, x16
    //     0x11d0e3c: b.ls            #0x11d0e90
    // 0x11d0e40: LoadField: r2 = r1->field_f
    //     0x11d0e40: ldur            w2, [x1, #0xf]
    // 0x11d0e44: DecompressPointer r2
    //     0x11d0e44: add             x2, x2, HEAP, lsl #32
    // 0x11d0e48: stur            x2, [fp, #-0x18]
    // 0x11d0e4c: LoadField: r5 = r1->field_13
    //     0x11d0e4c: ldur            w5, [x1, #0x13]
    // 0x11d0e50: DecompressPointer r5
    //     0x11d0e50: add             x5, x5, HEAP, lsl #32
    // 0x11d0e54: stur            x5, [fp, #-0x10]
    // 0x11d0e58: LoadField: r3 = r1->field_1f
    //     0x11d0e58: ldur            w3, [x1, #0x1f]
    // 0x11d0e5c: DecompressPointer r3
    //     0x11d0e5c: add             x3, x3, HEAP, lsl #32
    // 0x11d0e60: stur            x3, [fp, #-8]
    // 0x11d0e64: r0 = RenderFollowerLayer()
    //     0x11d0e64: bl              #0x11d0f60  ; AllocateRenderFollowerLayerStub -> RenderFollowerLayer (size=0x68)
    // 0x11d0e68: mov             x1, x0
    // 0x11d0e6c: ldur            x2, [fp, #-0x18]
    // 0x11d0e70: ldur            x3, [fp, #-8]
    // 0x11d0e74: ldur            x5, [fp, #-0x10]
    // 0x11d0e78: stur            x0, [fp, #-8]
    // 0x11d0e7c: r0 = RenderFollowerLayer()
    //     0x11d0e7c: bl              #0x11d0e98  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::RenderFollowerLayer
    // 0x11d0e80: ldur            x0, [fp, #-8]
    // 0x11d0e84: LeaveFrame
    //     0x11d0e84: mov             SP, fp
    //     0x11d0e88: ldp             fp, lr, [SP], #0x10
    // 0x11d0e8c: ret
    //     0x11d0e8c: ret             
    // 0x11d0e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0e90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0e94: b               #0x11d0e40
  }
}

// class id: 6633, size: 0x14, field offset: 0x10
//   const constructor, 
class CompositedTransformTarget extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf7058, size: 0x8c
    // 0xcf7058: EnterFrame
    //     0xcf7058: stp             fp, lr, [SP, #-0x10]!
    //     0xcf705c: mov             fp, SP
    // 0xcf7060: AllocStack(0x10)
    //     0xcf7060: sub             SP, SP, #0x10
    // 0xcf7064: SetupParameters(CompositedTransformTarget this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf7064: mov             x4, x1
    //     0xcf7068: stur            x1, [fp, #-8]
    //     0xcf706c: stur            x3, [fp, #-0x10]
    // 0xcf7070: CheckStackOverflow
    //     0xcf7070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7074: cmp             SP, x16
    //     0xcf7078: b.ls            #0xcf70dc
    // 0xcf707c: mov             x0, x3
    // 0xcf7080: r2 = Null
    //     0xcf7080: mov             x2, NULL
    // 0xcf7084: r1 = Null
    //     0xcf7084: mov             x1, NULL
    // 0xcf7088: r4 = 60
    //     0xcf7088: mov             x4, #0x3c
    // 0xcf708c: branchIfSmi(r0, 0xcf7098)
    //     0xcf708c: tbz             w0, #0, #0xcf7098
    // 0xcf7090: r4 = LoadClassIdInstr(r0)
    //     0xcf7090: ldur            x4, [x0, #-1]
    //     0xcf7094: ubfx            x4, x4, #0xc, #0x14
    // 0xcf7098: r17 = 4916
    //     0xcf7098: mov             x17, #0x1334
    // 0xcf709c: cmp             x4, x17
    // 0xcf70a0: b.eq            #0xcf70b8
    // 0xcf70a4: r8 = RenderLeaderLayer
    //     0xcf70a4: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ed8] Type: RenderLeaderLayer
    //     0xcf70a8: ldr             x8, [x8, #0xed8]
    // 0xcf70ac: r3 = Null
    //     0xcf70ac: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ee0] Null
    //     0xcf70b0: ldr             x3, [x3, #0xee0]
    // 0xcf70b4: r0 = DefaultTypeTest()
    //     0xcf70b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf70b8: ldur            x0, [fp, #-8]
    // 0xcf70bc: LoadField: r2 = r0->field_f
    //     0xcf70bc: ldur            w2, [x0, #0xf]
    // 0xcf70c0: DecompressPointer r2
    //     0xcf70c0: add             x2, x2, HEAP, lsl #32
    // 0xcf70c4: ldur            x1, [fp, #-0x10]
    // 0xcf70c8: r0 = link=()
    //     0xcf70c8: bl              #0xcf70e4  ; [package:flutter/src/rendering/proxy_box.dart] RenderLeaderLayer::link=
    // 0xcf70cc: r0 = Null
    //     0xcf70cc: mov             x0, NULL
    // 0xcf70d0: LeaveFrame
    //     0xcf70d0: mov             SP, fp
    //     0xcf70d4: ldp             fp, lr, [SP], #0x10
    // 0xcf70d8: ret
    //     0xcf70d8: ret             
    // 0xcf70dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf70dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf70e0: b               #0xcf707c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0dcc, size: 0x50
    // 0x11d0dcc: EnterFrame
    //     0x11d0dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0dd0: mov             fp, SP
    // 0x11d0dd4: AllocStack(0x8)
    //     0x11d0dd4: sub             SP, SP, #8
    // 0x11d0dd8: CheckStackOverflow
    //     0x11d0dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0ddc: cmp             SP, x16
    //     0x11d0de0: b.ls            #0x11d0e14
    // 0x11d0de4: LoadField: r2 = r1->field_f
    //     0x11d0de4: ldur            w2, [x1, #0xf]
    // 0x11d0de8: DecompressPointer r2
    //     0x11d0de8: add             x2, x2, HEAP, lsl #32
    // 0x11d0dec: stur            x2, [fp, #-8]
    // 0x11d0df0: r0 = RenderLeaderLayer()
    //     0x11d0df0: bl              #0x11d0e1c  ; AllocateRenderLeaderLayerStub -> RenderLeaderLayer (size=0x5c)
    // 0x11d0df4: mov             x1, x0
    // 0x11d0df8: ldur            x2, [fp, #-8]
    // 0x11d0dfc: stur            x0, [fp, #-8]
    // 0x11d0e00: r0 = RenderIntrinsicWidth()
    //     0x11d0e00: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11d0e04: ldur            x0, [fp, #-8]
    // 0x11d0e08: LeaveFrame
    //     0x11d0e08: mov             SP, fp
    //     0x11d0e0c: ldp             fp, lr, [SP], #0x10
    // 0x11d0e10: ret
    //     0x11d0e10: ret             
    // 0x11d0e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0e14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0e18: b               #0x11d0de4
  }
}

// class id: 6634, size: 0x24, field offset: 0x10
//   const constructor, 
class Transform extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6bcc, size: 0xfc
    // 0xcf6bcc: EnterFrame
    //     0xcf6bcc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6bd0: mov             fp, SP
    // 0xcf6bd4: AllocStack(0x18)
    //     0xcf6bd4: sub             SP, SP, #0x18
    // 0xcf6bd8: SetupParameters(Transform this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf6bd8: mov             x5, x1
    //     0xcf6bdc: mov             x4, x2
    //     0xcf6be0: stur            x1, [fp, #-8]
    //     0xcf6be4: stur            x2, [fp, #-0x10]
    //     0xcf6be8: stur            x3, [fp, #-0x18]
    // 0xcf6bec: CheckStackOverflow
    //     0xcf6bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6bf0: cmp             SP, x16
    //     0xcf6bf4: b.ls            #0xcf6cc0
    // 0xcf6bf8: mov             x0, x3
    // 0xcf6bfc: r2 = Null
    //     0xcf6bfc: mov             x2, NULL
    // 0xcf6c00: r1 = Null
    //     0xcf6c00: mov             x1, NULL
    // 0xcf6c04: r4 = 60
    //     0xcf6c04: mov             x4, #0x3c
    // 0xcf6c08: branchIfSmi(r0, 0xcf6c14)
    //     0xcf6c08: tbz             w0, #0, #0xcf6c14
    // 0xcf6c0c: r4 = LoadClassIdInstr(r0)
    //     0xcf6c0c: ldur            x4, [x0, #-1]
    //     0xcf6c10: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6c14: r17 = 4927
    //     0xcf6c14: mov             x17, #0x133f
    // 0xcf6c18: cmp             x4, x17
    // 0xcf6c1c: b.eq            #0xcf6c34
    // 0xcf6c20: r8 = RenderTransform
    //     0xcf6c20: add             x8, PP, #0x90, lsl #12  ; [pp+0x90350] Type: RenderTransform
    //     0xcf6c24: ldr             x8, [x8, #0x350]
    // 0xcf6c28: r3 = Null
    //     0xcf6c28: add             x3, PP, #0x90, lsl #12  ; [pp+0x90358] Null
    //     0xcf6c2c: ldr             x3, [x3, #0x358]
    // 0xcf6c30: r0 = DefaultTypeTest()
    //     0xcf6c30: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf6c34: ldur            x0, [fp, #-8]
    // 0xcf6c38: LoadField: r2 = r0->field_f
    //     0xcf6c38: ldur            w2, [x0, #0xf]
    // 0xcf6c3c: DecompressPointer r2
    //     0xcf6c3c: add             x2, x2, HEAP, lsl #32
    // 0xcf6c40: ldur            x1, [fp, #-0x18]
    // 0xcf6c44: r0 = transform=()
    //     0xcf6c44: bl              #0xcf6f88  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::transform=
    // 0xcf6c48: ldur            x0, [fp, #-8]
    // 0xcf6c4c: LoadField: r2 = r0->field_13
    //     0xcf6c4c: ldur            w2, [x0, #0x13]
    // 0xcf6c50: DecompressPointer r2
    //     0xcf6c50: add             x2, x2, HEAP, lsl #32
    // 0xcf6c54: ldur            x1, [fp, #-0x18]
    // 0xcf6c58: r0 = origin=()
    //     0xcf6c58: bl              #0xcf6ed8  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::origin=
    // 0xcf6c5c: ldur            x0, [fp, #-8]
    // 0xcf6c60: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf6c60: ldur            w2, [x0, #0x17]
    // 0xcf6c64: DecompressPointer r2
    //     0xcf6c64: add             x2, x2, HEAP, lsl #32
    // 0xcf6c68: ldur            x1, [fp, #-0x18]
    // 0xcf6c6c: r0 = alignment=()
    //     0xcf6c6c: bl              #0xcf6e28  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::alignment=
    // 0xcf6c70: ldur            x1, [fp, #-0x10]
    // 0xcf6c74: r0 = maybeOf()
    //     0xcf6c74: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf6c78: ldur            x1, [fp, #-0x18]
    // 0xcf6c7c: mov             x2, x0
    // 0xcf6c80: r0 = textDirection=()
    //     0xcf6c80: bl              #0xcf6da0  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::textDirection=
    // 0xcf6c84: ldur            x0, [fp, #-8]
    // 0xcf6c88: LoadField: r1 = r0->field_1b
    //     0xcf6c88: ldur            w1, [x0, #0x1b]
    // 0xcf6c8c: DecompressPointer r1
    //     0xcf6c8c: add             x1, x1, HEAP, lsl #32
    // 0xcf6c90: ldur            x2, [fp, #-0x18]
    // 0xcf6c94: StoreField: r2->field_5f = r1
    //     0xcf6c94: stur            w1, [x2, #0x5f]
    // 0xcf6c98: LoadField: r1 = r0->field_1f
    //     0xcf6c98: ldur            w1, [x0, #0x1f]
    // 0xcf6c9c: DecompressPointer r1
    //     0xcf6c9c: add             x1, x1, HEAP, lsl #32
    // 0xcf6ca0: mov             x16, x1
    // 0xcf6ca4: mov             x1, x2
    // 0xcf6ca8: mov             x2, x16
    // 0xcf6cac: r0 = filterQuality=()
    //     0xcf6cac: bl              #0xcf6cc8  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::filterQuality=
    // 0xcf6cb0: r0 = Null
    //     0xcf6cb0: mov             x0, NULL
    // 0xcf6cb4: LeaveFrame
    //     0xcf6cb4: mov             SP, fp
    //     0xcf6cb8: ldp             fp, lr, [SP], #0x10
    // 0xcf6cbc: ret
    //     0xcf6cbc: ret             
    // 0xcf6cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6cc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6cc4: b               #0xcf6bf8
  }
  _ Transform.scale(/* No info */) {
    // ** addr: 0xd2ffac, size: 0x110
    // 0xd2ffac: EnterFrame
    //     0xd2ffac: stp             fp, lr, [SP, #-0x10]!
    //     0xd2ffb0: mov             fp, SP
    // 0xd2ffb4: AllocStack(0x20)
    //     0xd2ffb4: sub             SP, SP, #0x20
    // 0xd2ffb8: SetupParameters(Transform this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r16 */)
    //     0xd2ffb8: stur            x1, [fp, #-8]
    //     0xd2ffbc: mov             x16, x2
    //     0xd2ffc0: mov             x2, x1
    // 0xd2ffc4: mov             x1, x16
    // 0xd2ffc8: stur            x1, [fp, #-0x10]
    // 0xd2ffcc: stur            d0, [fp, #-0x20]
    // 0xd2ffd0: LoadField: r0 = r4->field_13
    //     0xd2ffd0: ldur            w0, [x4, #0x13]
    // 0xd2ffd4: LoadField: r3 = r4->field_1f
    //     0xd2ffd4: ldur            w3, [x4, #0x1f]
    // 0xd2ffd8: DecompressPointer r3
    //     0xd2ffd8: add             x3, x3, HEAP, lsl #32
    // 0xd2ffdc: r16 = "origin"
    //     0xd2ffdc: add             x16, PP, #0x82, lsl #12  ; [pp+0x82a58] "origin"
    //     0xd2ffe0: ldr             x16, [x16, #0xa58]
    // 0xd2ffe4: cmp             w3, w16
    // 0xd2ffe8: b.ne            #0xd30004
    // 0xd2ffec: LoadField: r3 = r4->field_23
    //     0xd2ffec: ldur            w3, [x4, #0x23]
    // 0xd2fff0: DecompressPointer r3
    //     0xd2fff0: add             x3, x3, HEAP, lsl #32
    // 0xd2fff4: sub             w4, w0, w3
    // 0xd2fff8: add             x0, fp, w4, sxtw #2
    // 0xd2fffc: ldr             x0, [x0, #8]
    // 0xd30000: b               #0xd30008
    // 0xd30004: r0 = Null
    //     0xd30004: mov             x0, NULL
    // 0xd30008: r4 = Instance_Alignment
    //     0xd30008: add             x4, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd3000c: ldr             x4, [x4, #0xb80]
    // 0xd30010: r3 = true
    //     0xd30010: add             x3, NULL, #0x20  ; true
    // 0xd30014: StoreField: r2->field_13 = r0
    //     0xd30014: stur            w0, [x2, #0x13]
    //     0xd30018: ldurb           w16, [x2, #-1]
    //     0xd3001c: ldurb           w17, [x0, #-1]
    //     0xd30020: and             x16, x17, x16, lsr #2
    //     0xd30024: tst             x16, HEAP, lsr #32
    //     0xd30028: b.eq            #0xd30030
    //     0xd3002c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd30030: ArrayStore: r2[0] = r4  ; List_4
    //     0xd30030: stur            w4, [x2, #0x17]
    // 0xd30034: StoreField: r2->field_1b = r3
    //     0xd30034: stur            w3, [x2, #0x1b]
    // 0xd30038: r0 = Matrix4()
    //     0xd30038: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xd3003c: r4 = 32
    //     0xd3003c: mov             x4, #0x20
    // 0xd30040: stur            x0, [fp, #-0x18]
    // 0xd30044: r0 = AllocateFloat64Array()
    //     0xd30044: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xd30048: mov             x1, x0
    // 0xd3004c: ldur            x0, [fp, #-0x18]
    // 0xd30050: StoreField: r0->field_7 = r1
    //     0xd30050: stur            w1, [x0, #7]
    // 0xd30054: d0 = 1.000000
    //     0xd30054: fmov            d0, #1.00000000
    // 0xd30058: StoreField: r1->field_8f = d0
    //     0xd30058: stur            d0, [x1, #0x8f]
    // 0xd3005c: StoreField: r1->field_67 = d0
    //     0xd3005c: stur            d0, [x1, #0x67]
    // 0xd30060: ldur            d0, [fp, #-0x20]
    // 0xd30064: StoreField: r1->field_3f = d0
    //     0xd30064: stur            d0, [x1, #0x3f]
    // 0xd30068: ArrayStore: r1[0] = d0  ; List_8
    //     0xd30068: stur            d0, [x1, #0x17]
    // 0xd3006c: ldur            x1, [fp, #-8]
    // 0xd30070: StoreField: r1->field_f = r0
    //     0xd30070: stur            w0, [x1, #0xf]
    //     0xd30074: ldurb           w16, [x1, #-1]
    //     0xd30078: ldurb           w17, [x0, #-1]
    //     0xd3007c: and             x16, x17, x16, lsr #2
    //     0xd30080: tst             x16, HEAP, lsr #32
    //     0xd30084: b.eq            #0xd3008c
    //     0xd30088: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd3008c: ldur            x0, [fp, #-0x10]
    // 0xd30090: StoreField: r1->field_b = r0
    //     0xd30090: stur            w0, [x1, #0xb]
    //     0xd30094: ldurb           w16, [x1, #-1]
    //     0xd30098: ldurb           w17, [x0, #-1]
    //     0xd3009c: and             x16, x17, x16, lsr #2
    //     0xd300a0: tst             x16, HEAP, lsr #32
    //     0xd300a4: b.eq            #0xd300ac
    //     0xd300a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd300ac: r0 = Null
    //     0xd300ac: mov             x0, NULL
    // 0xd300b0: LeaveFrame
    //     0xd300b0: mov             SP, fp
    //     0xd300b4: ldp             fp, lr, [SP], #0x10
    // 0xd300b8: ret
    //     0xd300b8: ret             
  }
  _ Transform.translate(/* No info */) {
    // ** addr: 0xd300bc, size: 0x94
    // 0xd300bc: EnterFrame
    //     0xd300bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd300c0: mov             fp, SP
    // 0xd300c4: AllocStack(0x10)
    //     0xd300c4: sub             SP, SP, #0x10
    // 0xd300c8: r0 = true
    //     0xd300c8: add             x0, NULL, #0x20  ; true
    // 0xd300cc: mov             x4, x1
    // 0xd300d0: stur            x1, [fp, #-8]
    // 0xd300d4: stur            x2, [fp, #-0x10]
    // 0xd300d8: CheckStackOverflow
    //     0xd300d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd300dc: cmp             SP, x16
    //     0xd300e0: b.ls            #0xd30148
    // 0xd300e4: StoreField: r4->field_1b = r0
    //     0xd300e4: stur            w0, [x4, #0x1b]
    // 0xd300e8: LoadField: d0 = r3->field_7
    //     0xd300e8: ldur            d0, [x3, #7]
    // 0xd300ec: LoadField: d1 = r3->field_f
    //     0xd300ec: ldur            d1, [x3, #0xf]
    // 0xd300f0: r1 = Null
    //     0xd300f0: mov             x1, NULL
    // 0xd300f4: r0 = Matrix4.translationValues()
    //     0xd300f4: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xd300f8: ldur            x1, [fp, #-8]
    // 0xd300fc: StoreField: r1->field_f = r0
    //     0xd300fc: stur            w0, [x1, #0xf]
    //     0xd30100: ldurb           w16, [x1, #-1]
    //     0xd30104: ldurb           w17, [x0, #-1]
    //     0xd30108: and             x16, x17, x16, lsr #2
    //     0xd3010c: tst             x16, HEAP, lsr #32
    //     0xd30110: b.eq            #0xd30118
    //     0xd30114: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd30118: ldur            x0, [fp, #-0x10]
    // 0xd3011c: StoreField: r1->field_b = r0
    //     0xd3011c: stur            w0, [x1, #0xb]
    //     0xd30120: ldurb           w16, [x1, #-1]
    //     0xd30124: ldurb           w17, [x0, #-1]
    //     0xd30128: and             x16, x17, x16, lsr #2
    //     0xd3012c: tst             x16, HEAP, lsr #32
    //     0xd30130: b.eq            #0xd30138
    //     0xd30134: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd30138: r0 = Null
    //     0xd30138: mov             x0, NULL
    // 0xd3013c: LeaveFrame
    //     0xd3013c: mov             SP, fp
    //     0xd30140: ldp             fp, lr, [SP], #0x10
    // 0xd30144: ret
    //     0xd30144: ret             
    // 0xd30148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3014c: b               #0xd300e4
  }
  static _ _computeRotation(/* No info */) {
    // ** addr: 0xd31970, size: 0x15c
    // 0xd31970: EnterFrame
    //     0xd31970: stp             fp, lr, [SP, #-0x10]!
    //     0xd31974: mov             fp, SP
    // 0xd31978: AllocStack(0x18)
    //     0xd31978: sub             SP, SP, #0x18
    // 0xd3197c: d1 = 0.000000
    //     0xd3197c: eor             v1.16b, v1.16b, v1.16b
    // 0xd31980: mov             v2.16b, v0.16b
    // 0xd31984: stur            d0, [fp, #-0x10]
    // 0xd31988: CheckStackOverflow
    //     0xd31988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3198c: cmp             SP, x16
    //     0xd31990: b.ls            #0xd31ac4
    // 0xd31994: fcmp            d2, d1
    // 0xd31998: b.ne            #0xd319d0
    // 0xd3199c: r0 = Matrix4()
    //     0xd3199c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xd319a0: r4 = 32
    //     0xd319a0: mov             x4, #0x20
    // 0xd319a4: stur            x0, [fp, #-8]
    // 0xd319a8: r0 = AllocateFloat64Array()
    //     0xd319a8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xd319ac: mov             x1, x0
    // 0xd319b0: ldur            x0, [fp, #-8]
    // 0xd319b4: StoreField: r0->field_7 = r1
    //     0xd319b4: stur            w1, [x0, #7]
    // 0xd319b8: mov             x1, x0
    // 0xd319bc: r0 = setIdentity()
    //     0xd319bc: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xd319c0: ldur            x0, [fp, #-8]
    // 0xd319c4: LeaveFrame
    //     0xd319c4: mov             SP, fp
    //     0xd319c8: ldp             fp, lr, [SP], #0x10
    // 0xd319cc: ret
    //     0xd319cc: ret             
    // 0xd319d0: mov             v0.16b, v2.16b
    // 0xd319d4: stp             fp, lr, [SP, #-0x10]!
    // 0xd319d8: mov             fp, SP
    // 0xd319dc: CallRuntime_LibcSin(double) -> double
    //     0xd319dc: and             SP, SP, #0xfffffffffffffff0
    //     0xd319e0: mov             sp, SP
    //     0xd319e4: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0xd319e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd319ec: blr             x16
    //     0xd319f0: mov             x16, #8
    //     0xd319f4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd319f8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd319fc: sub             sp, x16, #1, lsl #12
    //     0xd31a00: mov             SP, fp
    //     0xd31a04: ldp             fp, lr, [SP], #0x10
    // 0xd31a08: mov             v1.16b, v0.16b
    // 0xd31a0c: d0 = 1.000000
    //     0xd31a0c: fmov            d0, #1.00000000
    // 0xd31a10: stur            d1, [fp, #-0x18]
    // 0xd31a14: fcmp            d1, d0
    // 0xd31a18: b.ne            #0xd31a30
    // 0xd31a1c: d1 = 0.000000
    //     0xd31a1c: eor             v1.16b, v1.16b, v1.16b
    // 0xd31a20: r0 = _createZRotation()
    //     0xd31a20: bl              #0xd31acc  ; [package:flutter/src/widgets/basic.dart] Transform::_createZRotation
    // 0xd31a24: LeaveFrame
    //     0xd31a24: mov             SP, fp
    //     0xd31a28: ldp             fp, lr, [SP], #0x10
    // 0xd31a2c: ret
    //     0xd31a2c: ret             
    // 0xd31a30: d2 = -1.000000
    //     0xd31a30: fmov            d2, #-1.00000000
    // 0xd31a34: fcmp            d1, d2
    // 0xd31a38: b.ne            #0xd31a54
    // 0xd31a3c: mov             v0.16b, v2.16b
    // 0xd31a40: d1 = 0.000000
    //     0xd31a40: eor             v1.16b, v1.16b, v1.16b
    // 0xd31a44: r0 = _createZRotation()
    //     0xd31a44: bl              #0xd31acc  ; [package:flutter/src/widgets/basic.dart] Transform::_createZRotation
    // 0xd31a48: LeaveFrame
    //     0xd31a48: mov             SP, fp
    //     0xd31a4c: ldp             fp, lr, [SP], #0x10
    // 0xd31a50: ret
    //     0xd31a50: ret             
    // 0xd31a54: ldur            d0, [fp, #-0x10]
    // 0xd31a58: stp             fp, lr, [SP, #-0x10]!
    // 0xd31a5c: mov             fp, SP
    // 0xd31a60: CallRuntime_LibcCos(double) -> double
    //     0xd31a60: and             SP, SP, #0xfffffffffffffff0
    //     0xd31a64: mov             sp, SP
    //     0xd31a68: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0xd31a6c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd31a70: blr             x16
    //     0xd31a74: mov             x16, #8
    //     0xd31a78: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd31a7c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd31a80: sub             sp, x16, #1, lsl #12
    //     0xd31a84: mov             SP, fp
    //     0xd31a88: ldp             fp, lr, [SP], #0x10
    // 0xd31a8c: d1 = -1.000000
    //     0xd31a8c: fmov            d1, #-1.00000000
    // 0xd31a90: fcmp            d0, d1
    // 0xd31a94: b.ne            #0xd31aac
    // 0xd31a98: d0 = 0.000000
    //     0xd31a98: eor             v0.16b, v0.16b, v0.16b
    // 0xd31a9c: r0 = _createZRotation()
    //     0xd31a9c: bl              #0xd31acc  ; [package:flutter/src/widgets/basic.dart] Transform::_createZRotation
    // 0xd31aa0: LeaveFrame
    //     0xd31aa0: mov             SP, fp
    //     0xd31aa4: ldp             fp, lr, [SP], #0x10
    // 0xd31aa8: ret
    //     0xd31aa8: ret             
    // 0xd31aac: mov             v1.16b, v0.16b
    // 0xd31ab0: ldur            d0, [fp, #-0x18]
    // 0xd31ab4: r0 = _createZRotation()
    //     0xd31ab4: bl              #0xd31acc  ; [package:flutter/src/widgets/basic.dart] Transform::_createZRotation
    // 0xd31ab8: LeaveFrame
    //     0xd31ab8: mov             SP, fp
    //     0xd31abc: ldp             fp, lr, [SP], #0x10
    // 0xd31ac0: ret
    //     0xd31ac0: ret             
    // 0xd31ac4: r0 = StackOverflowSharedWithFPURegs()
    //     0xd31ac4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd31ac8: b               #0xd31994
  }
  static _ _createZRotation(/* No info */) {
    // ** addr: 0xd31acc, size: 0x64
    // 0xd31acc: EnterFrame
    //     0xd31acc: stp             fp, lr, [SP, #-0x10]!
    //     0xd31ad0: mov             fp, SP
    // 0xd31ad4: AllocStack(0x18)
    //     0xd31ad4: sub             SP, SP, #0x18
    // 0xd31ad8: SetupParameters(dynamic _ /* d0 => d0, fp-0x10 */, dynamic _ /* d1 => d1, fp-0x18 */)
    //     0xd31ad8: stur            d0, [fp, #-0x10]
    //     0xd31adc: stur            d1, [fp, #-0x18]
    // 0xd31ae0: r0 = Matrix4()
    //     0xd31ae0: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xd31ae4: r4 = 32
    //     0xd31ae4: mov             x4, #0x20
    // 0xd31ae8: stur            x0, [fp, #-8]
    // 0xd31aec: r0 = AllocateFloat64Array()
    //     0xd31aec: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xd31af0: mov             x1, x0
    // 0xd31af4: ldur            x0, [fp, #-8]
    // 0xd31af8: StoreField: r0->field_7 = r1
    //     0xd31af8: stur            w1, [x0, #7]
    // 0xd31afc: ldur            d0, [fp, #-0x18]
    // 0xd31b00: ArrayStore: r1[0] = d0  ; List_8
    //     0xd31b00: stur            d0, [x1, #0x17]
    // 0xd31b04: ldur            d1, [fp, #-0x10]
    // 0xd31b08: StoreField: r1->field_1f = d1
    //     0xd31b08: stur            d1, [x1, #0x1f]
    // 0xd31b0c: fneg            d2, d1
    // 0xd31b10: StoreField: r1->field_37 = d2
    //     0xd31b10: stur            d2, [x1, #0x37]
    // 0xd31b14: StoreField: r1->field_3f = d0
    //     0xd31b14: stur            d0, [x1, #0x3f]
    // 0xd31b18: d0 = 1.000000
    //     0xd31b18: fmov            d0, #1.00000000
    // 0xd31b1c: StoreField: r1->field_67 = d0
    //     0xd31b1c: stur            d0, [x1, #0x67]
    // 0xd31b20: StoreField: r1->field_8f = d0
    //     0xd31b20: stur            d0, [x1, #0x8f]
    // 0xd31b24: LeaveFrame
    //     0xd31b24: mov             SP, fp
    //     0xd31b28: ldp             fp, lr, [SP], #0x10
    // 0xd31b2c: ret
    //     0xd31b2c: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0c30, size: 0xb4
    // 0x11d0c30: EnterFrame
    //     0x11d0c30: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0c34: mov             fp, SP
    // 0x11d0c38: AllocStack(0x40)
    //     0x11d0c38: sub             SP, SP, #0x40
    // 0x11d0c3c: SetupParameters(Transform this /* r1 => r0, fp-0x20 */, dynamic _ /* r2 => r1 */)
    //     0x11d0c3c: mov             x0, x1
    //     0x11d0c40: stur            x1, [fp, #-0x20]
    //     0x11d0c44: mov             x1, x2
    // 0x11d0c48: CheckStackOverflow
    //     0x11d0c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0c4c: cmp             SP, x16
    //     0x11d0c50: b.ls            #0x11d0cdc
    // 0x11d0c54: LoadField: r7 = r0->field_f
    //     0x11d0c54: ldur            w7, [x0, #0xf]
    // 0x11d0c58: DecompressPointer r7
    //     0x11d0c58: add             x7, x7, HEAP, lsl #32
    // 0x11d0c5c: stur            x7, [fp, #-0x18]
    // 0x11d0c60: LoadField: r5 = r0->field_13
    //     0x11d0c60: ldur            w5, [x0, #0x13]
    // 0x11d0c64: DecompressPointer r5
    //     0x11d0c64: add             x5, x5, HEAP, lsl #32
    // 0x11d0c68: stur            x5, [fp, #-0x10]
    // 0x11d0c6c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x11d0c6c: ldur            w2, [x0, #0x17]
    // 0x11d0c70: DecompressPointer r2
    //     0x11d0c70: add             x2, x2, HEAP, lsl #32
    // 0x11d0c74: stur            x2, [fp, #-8]
    // 0x11d0c78: r0 = maybeOf()
    //     0x11d0c78: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d0c7c: mov             x1, x0
    // 0x11d0c80: ldur            x0, [fp, #-0x20]
    // 0x11d0c84: stur            x1, [fp, #-0x38]
    // 0x11d0c88: LoadField: r2 = r0->field_1b
    //     0x11d0c88: ldur            w2, [x0, #0x1b]
    // 0x11d0c8c: DecompressPointer r2
    //     0x11d0c8c: add             x2, x2, HEAP, lsl #32
    // 0x11d0c90: stur            x2, [fp, #-0x30]
    // 0x11d0c94: LoadField: r3 = r0->field_1f
    //     0x11d0c94: ldur            w3, [x0, #0x1f]
    // 0x11d0c98: DecompressPointer r3
    //     0x11d0c98: add             x3, x3, HEAP, lsl #32
    // 0x11d0c9c: stur            x3, [fp, #-0x28]
    // 0x11d0ca0: r0 = RenderTransform()
    //     0x11d0ca0: bl              #0x11d0dc0  ; AllocateRenderTransformStub -> RenderTransform (size=0x6c)
    // 0x11d0ca4: stur            x0, [fp, #-0x20]
    // 0x11d0ca8: ldur            x16, [fp, #-0x30]
    // 0x11d0cac: str             x16, [SP]
    // 0x11d0cb0: mov             x1, x0
    // 0x11d0cb4: ldur            x2, [fp, #-8]
    // 0x11d0cb8: ldur            x3, [fp, #-0x28]
    // 0x11d0cbc: ldur            x5, [fp, #-0x10]
    // 0x11d0cc0: ldur            x6, [fp, #-0x38]
    // 0x11d0cc4: ldur            x7, [fp, #-0x18]
    // 0x11d0cc8: r0 = RenderTransform()
    //     0x11d0cc8: bl              #0x11d0ce4  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::RenderTransform
    // 0x11d0ccc: ldur            x0, [fp, #-0x20]
    // 0x11d0cd0: LeaveFrame
    //     0x11d0cd0: mov             SP, fp
    //     0x11d0cd4: ldp             fp, lr, [SP], #0x10
    // 0x11d0cd8: ret
    //     0x11d0cd8: ret             
    // 0x11d0cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0cdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0ce0: b               #0x11d0c54
  }
}

// class id: 6635, size: 0x28, field offset: 0x10
//   const constructor, 
class PhysicalShape extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6ac4, size: 0x108
    // 0xcf6ac4: EnterFrame
    //     0xcf6ac4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6ac8: mov             fp, SP
    // 0xcf6acc: AllocStack(0x10)
    //     0xcf6acc: sub             SP, SP, #0x10
    // 0xcf6ad0: SetupParameters(PhysicalShape this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf6ad0: mov             x4, x1
    //     0xcf6ad4: stur            x1, [fp, #-8]
    //     0xcf6ad8: stur            x3, [fp, #-0x10]
    // 0xcf6adc: CheckStackOverflow
    //     0xcf6adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6ae0: cmp             SP, x16
    //     0xcf6ae4: b.ls            #0xcf6bc4
    // 0xcf6ae8: mov             x0, x3
    // 0xcf6aec: r2 = Null
    //     0xcf6aec: mov             x2, NULL
    // 0xcf6af0: r1 = Null
    //     0xcf6af0: mov             x1, NULL
    // 0xcf6af4: r4 = 60
    //     0xcf6af4: mov             x4, #0x3c
    // 0xcf6af8: branchIfSmi(r0, 0xcf6b04)
    //     0xcf6af8: tbz             w0, #0, #0xcf6b04
    // 0xcf6afc: r4 = LoadClassIdInstr(r0)
    //     0xcf6afc: ldur            x4, [x0, #-1]
    //     0xcf6b00: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6b04: r17 = 4931
    //     0xcf6b04: mov             x17, #0x1343
    // 0xcf6b08: cmp             x4, x17
    // 0xcf6b0c: b.eq            #0xcf6b24
    // 0xcf6b10: r8 = RenderPhysicalShape
    //     0xcf6b10: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ec0] Type: RenderPhysicalShape
    //     0xcf6b14: ldr             x8, [x8, #0xec0]
    // 0xcf6b18: r3 = Null
    //     0xcf6b18: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ec8] Null
    //     0xcf6b1c: ldr             x3, [x3, #0xec8]
    // 0xcf6b20: r0 = DefaultTypeTest()
    //     0xcf6b20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf6b24: ldur            x0, [fp, #-8]
    // 0xcf6b28: LoadField: r2 = r0->field_f
    //     0xcf6b28: ldur            w2, [x0, #0xf]
    // 0xcf6b2c: DecompressPointer r2
    //     0xcf6b2c: add             x2, x2, HEAP, lsl #32
    // 0xcf6b30: ldur            x1, [fp, #-0x10]
    // 0xcf6b34: r0 = clipper=()
    //     0xcf6b34: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf6b38: ldur            x2, [fp, #-8]
    // 0xcf6b3c: LoadField: r0 = r2->field_13
    //     0xcf6b3c: ldur            w0, [x2, #0x13]
    // 0xcf6b40: DecompressPointer r0
    //     0xcf6b40: add             x0, x0, HEAP, lsl #32
    // 0xcf6b44: ldur            x3, [fp, #-0x10]
    // 0xcf6b48: LoadField: r1 = r3->field_5f
    //     0xcf6b48: ldur            w1, [x3, #0x5f]
    // 0xcf6b4c: DecompressPointer r1
    //     0xcf6b4c: add             x1, x1, HEAP, lsl #32
    // 0xcf6b50: cmp             w0, w1
    // 0xcf6b54: b.eq            #0xcf6b7c
    // 0xcf6b58: StoreField: r3->field_5f = r0
    //     0xcf6b58: stur            w0, [x3, #0x5f]
    //     0xcf6b5c: ldurb           w16, [x3, #-1]
    //     0xcf6b60: ldurb           w17, [x0, #-1]
    //     0xcf6b64: and             x16, x17, x16, lsr #2
    //     0xcf6b68: tst             x16, HEAP, lsr #32
    //     0xcf6b6c: b.eq            #0xcf6b74
    //     0xcf6b70: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf6b74: mov             x1, x3
    // 0xcf6b78: r0 = markNeedsPaint()
    //     0xcf6b78: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6b7c: ldur            x0, [fp, #-8]
    // 0xcf6b80: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcf6b80: ldur            d0, [x0, #0x17]
    // 0xcf6b84: ldur            x1, [fp, #-0x10]
    // 0xcf6b88: r0 = elevation=()
    //     0xcf6b88: bl              #0xcf6888  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::elevation=
    // 0xcf6b8c: ldur            x0, [fp, #-8]
    // 0xcf6b90: LoadField: r2 = r0->field_1f
    //     0xcf6b90: ldur            w2, [x0, #0x1f]
    // 0xcf6b94: DecompressPointer r2
    //     0xcf6b94: add             x2, x2, HEAP, lsl #32
    // 0xcf6b98: ldur            x1, [fp, #-0x10]
    // 0xcf6b9c: r0 = color=()
    //     0xcf6b9c: bl              #0xcf697c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::color=
    // 0xcf6ba0: ldur            x0, [fp, #-8]
    // 0xcf6ba4: LoadField: r2 = r0->field_23
    //     0xcf6ba4: ldur            w2, [x0, #0x23]
    // 0xcf6ba8: DecompressPointer r2
    //     0xcf6ba8: add             x2, x2, HEAP, lsl #32
    // 0xcf6bac: ldur            x1, [fp, #-0x10]
    // 0xcf6bb0: r0 = shadowColor=()
    //     0xcf6bb0: bl              #0xcf68d8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::shadowColor=
    // 0xcf6bb4: r0 = Null
    //     0xcf6bb4: mov             x0, NULL
    // 0xcf6bb8: LeaveFrame
    //     0xcf6bb8: mov             SP, fp
    //     0xcf6bbc: ldp             fp, lr, [SP], #0x10
    // 0xcf6bc0: ret
    //     0xcf6bc0: ret             
    // 0xcf6bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6bc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6bc8: b               #0xcf6ae8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0b84, size: 0xa0
    // 0x11d0b84: EnterFrame
    //     0x11d0b84: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0b88: mov             fp, SP
    // 0x11d0b8c: AllocStack(0x30)
    //     0x11d0b8c: sub             SP, SP, #0x30
    // 0x11d0b90: CheckStackOverflow
    //     0x11d0b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0b94: cmp             SP, x16
    //     0x11d0b98: b.ls            #0x11d0c1c
    // 0x11d0b9c: LoadField: r3 = r1->field_f
    //     0x11d0b9c: ldur            w3, [x1, #0xf]
    // 0x11d0ba0: DecompressPointer r3
    //     0x11d0ba0: add             x3, x3, HEAP, lsl #32
    // 0x11d0ba4: stur            x3, [fp, #-0x20]
    // 0x11d0ba8: LoadField: r2 = r1->field_13
    //     0x11d0ba8: ldur            w2, [x1, #0x13]
    // 0x11d0bac: DecompressPointer r2
    //     0x11d0bac: add             x2, x2, HEAP, lsl #32
    // 0x11d0bb0: stur            x2, [fp, #-0x18]
    // 0x11d0bb4: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x11d0bb4: ldur            d0, [x1, #0x17]
    // 0x11d0bb8: stur            d0, [fp, #-0x30]
    // 0x11d0bbc: LoadField: r0 = r1->field_1f
    //     0x11d0bbc: ldur            w0, [x1, #0x1f]
    // 0x11d0bc0: DecompressPointer r0
    //     0x11d0bc0: add             x0, x0, HEAP, lsl #32
    // 0x11d0bc4: stur            x0, [fp, #-0x10]
    // 0x11d0bc8: LoadField: r4 = r1->field_23
    //     0x11d0bc8: ldur            w4, [x1, #0x23]
    // 0x11d0bcc: DecompressPointer r4
    //     0x11d0bcc: add             x4, x4, HEAP, lsl #32
    // 0x11d0bd0: stur            x4, [fp, #-8]
    // 0x11d0bd4: r1 = <Path>
    //     0x11d0bd4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x11d0bd8: ldr             x1, [x1, #0xa60]
    // 0x11d0bdc: r0 = RenderPhysicalShape()
    //     0x11d0bdc: bl              #0x11d0c24  ; AllocateRenderPhysicalShapeStub -> RenderPhysicalShape (size=0x78)
    // 0x11d0be0: ldur            d0, [fp, #-0x30]
    // 0x11d0be4: stur            x0, [fp, #-0x28]
    // 0x11d0be8: StoreField: r0->field_67 = d0
    //     0x11d0be8: stur            d0, [x0, #0x67]
    // 0x11d0bec: ldur            x1, [fp, #-0x10]
    // 0x11d0bf0: StoreField: r0->field_73 = r1
    //     0x11d0bf0: stur            w1, [x0, #0x73]
    // 0x11d0bf4: ldur            x1, [fp, #-8]
    // 0x11d0bf8: StoreField: r0->field_6f = r1
    //     0x11d0bf8: stur            w1, [x0, #0x6f]
    // 0x11d0bfc: mov             x1, x0
    // 0x11d0c00: ldur            x2, [fp, #-0x18]
    // 0x11d0c04: ldur            x3, [fp, #-0x20]
    // 0x11d0c08: r0 = _RenderCustomClip()
    //     0x11d0c08: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0c0c: ldur            x0, [fp, #-0x28]
    // 0x11d0c10: LeaveFrame
    //     0x11d0c10: mov             SP, fp
    //     0x11d0c14: ldp             fp, lr, [SP], #0x10
    // 0x11d0c18: ret
    //     0x11d0c18: ret             
    // 0x11d0c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0c20: b               #0x11d0b9c
  }
}

// class id: 6636, size: 0x2c, field offset: 0x10
//   const constructor, 
class PhysicalModel extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6758, size: 0x130
    // 0xcf6758: EnterFrame
    //     0xcf6758: stp             fp, lr, [SP, #-0x10]!
    //     0xcf675c: mov             fp, SP
    // 0xcf6760: AllocStack(0x10)
    //     0xcf6760: sub             SP, SP, #0x10
    // 0xcf6764: SetupParameters(PhysicalModel this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf6764: mov             x4, x1
    //     0xcf6768: stur            x1, [fp, #-8]
    //     0xcf676c: stur            x3, [fp, #-0x10]
    // 0xcf6770: CheckStackOverflow
    //     0xcf6770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6774: cmp             SP, x16
    //     0xcf6778: b.ls            #0xcf6880
    // 0xcf677c: mov             x0, x3
    // 0xcf6780: r2 = Null
    //     0xcf6780: mov             x2, NULL
    // 0xcf6784: r1 = Null
    //     0xcf6784: mov             x1, NULL
    // 0xcf6788: r4 = 60
    //     0xcf6788: mov             x4, #0x3c
    // 0xcf678c: branchIfSmi(r0, 0xcf6798)
    //     0xcf678c: tbz             w0, #0, #0xcf6798
    // 0xcf6790: r4 = LoadClassIdInstr(r0)
    //     0xcf6790: ldur            x4, [x0, #-1]
    //     0xcf6794: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6798: r17 = 4932
    //     0xcf6798: mov             x17, #0x1344
    // 0xcf679c: cmp             x4, x17
    // 0xcf67a0: b.eq            #0xcf67b8
    // 0xcf67a4: r8 = RenderPhysicalModel
    //     0xcf67a4: add             x8, PP, #0xad, lsl #12  ; [pp+0xadec8] Type: RenderPhysicalModel
    //     0xcf67a8: ldr             x8, [x8, #0xec8]
    // 0xcf67ac: r3 = Null
    //     0xcf67ac: add             x3, PP, #0xad, lsl #12  ; [pp+0xaded0] Null
    //     0xcf67b0: ldr             x3, [x3, #0xed0]
    // 0xcf67b4: r0 = DefaultTypeTest()
    //     0xcf67b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf67b8: ldur            x1, [fp, #-0x10]
    // 0xcf67bc: r2 = Instance_BoxShape
    //     0xcf67bc: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xcf67c0: ldr             x2, [x2, #0x1f8]
    // 0xcf67c4: r0 = Shader._()
    //     0xcf67c4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf67c8: ldur            x2, [fp, #-8]
    // 0xcf67cc: LoadField: r0 = r2->field_13
    //     0xcf67cc: ldur            w0, [x2, #0x13]
    // 0xcf67d0: DecompressPointer r0
    //     0xcf67d0: add             x0, x0, HEAP, lsl #32
    // 0xcf67d4: ldur            x3, [fp, #-0x10]
    // 0xcf67d8: LoadField: r1 = r3->field_5f
    //     0xcf67d8: ldur            w1, [x3, #0x5f]
    // 0xcf67dc: DecompressPointer r1
    //     0xcf67dc: add             x1, x1, HEAP, lsl #32
    // 0xcf67e0: cmp             w0, w1
    // 0xcf67e4: b.eq            #0xcf680c
    // 0xcf67e8: StoreField: r3->field_5f = r0
    //     0xcf67e8: stur            w0, [x3, #0x5f]
    //     0xcf67ec: ldurb           w16, [x3, #-1]
    //     0xcf67f0: ldurb           w17, [x0, #-1]
    //     0xcf67f4: and             x16, x17, x16, lsr #2
    //     0xcf67f8: tst             x16, HEAP, lsr #32
    //     0xcf67fc: b.eq            #0xcf6804
    //     0xcf6800: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf6804: mov             x1, x3
    // 0xcf6808: r0 = markNeedsPaint()
    //     0xcf6808: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf680c: ldur            x0, [fp, #-8]
    // 0xcf6810: ldur            x3, [fp, #-0x10]
    // 0xcf6814: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf6814: ldur            w2, [x0, #0x17]
    // 0xcf6818: DecompressPointer r2
    //     0xcf6818: add             x2, x2, HEAP, lsl #32
    // 0xcf681c: mov             x1, x3
    // 0xcf6820: r0 = borderRadius=()
    //     0xcf6820: bl              #0xcf6a20  ; [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalModel::borderRadius=
    // 0xcf6824: ldur            x0, [fp, #-8]
    // 0xcf6828: LoadField: d0 = r0->field_1b
    //     0xcf6828: ldur            d0, [x0, #0x1b]
    // 0xcf682c: ldur            x2, [fp, #-0x10]
    // 0xcf6830: LoadField: d1 = r2->field_67
    //     0xcf6830: ldur            d1, [x2, #0x67]
    // 0xcf6834: fcmp            d1, d0
    // 0xcf6838: b.eq            #0xcf684c
    // 0xcf683c: StoreField: r2->field_67 = d0
    //     0xcf683c: stur            d0, [x2, #0x67]
    // 0xcf6840: mov             x1, x2
    // 0xcf6844: r0 = markNeedsPaint()
    //     0xcf6844: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6848: ldur            x0, [fp, #-8]
    // 0xcf684c: LoadField: r2 = r0->field_23
    //     0xcf684c: ldur            w2, [x0, #0x23]
    // 0xcf6850: DecompressPointer r2
    //     0xcf6850: add             x2, x2, HEAP, lsl #32
    // 0xcf6854: ldur            x1, [fp, #-0x10]
    // 0xcf6858: r0 = color=()
    //     0xcf6858: bl              #0xcf697c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::color=
    // 0xcf685c: ldur            x0, [fp, #-8]
    // 0xcf6860: LoadField: r2 = r0->field_27
    //     0xcf6860: ldur            w2, [x0, #0x27]
    // 0xcf6864: DecompressPointer r2
    //     0xcf6864: add             x2, x2, HEAP, lsl #32
    // 0xcf6868: ldur            x1, [fp, #-0x10]
    // 0xcf686c: r0 = shadowColor=()
    //     0xcf686c: bl              #0xcf68d8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::shadowColor=
    // 0xcf6870: r0 = Null
    //     0xcf6870: mov             x0, NULL
    // 0xcf6874: LeaveFrame
    //     0xcf6874: mov             SP, fp
    //     0xcf6878: ldp             fp, lr, [SP], #0x10
    // 0xcf687c: ret
    //     0xcf687c: ret             
    // 0xcf6880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6884: b               #0xcf677c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0a28, size: 0x94
    // 0x11d0a28: EnterFrame
    //     0x11d0a28: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0a2c: mov             fp, SP
    // 0x11d0a30: AllocStack(0x28)
    //     0x11d0a30: sub             SP, SP, #0x28
    // 0x11d0a34: CheckStackOverflow
    //     0x11d0a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0a38: cmp             SP, x16
    //     0x11d0a3c: b.ls            #0x11d0ab4
    // 0x11d0a40: LoadField: r3 = r1->field_13
    //     0x11d0a40: ldur            w3, [x1, #0x13]
    // 0x11d0a44: DecompressPointer r3
    //     0x11d0a44: add             x3, x3, HEAP, lsl #32
    // 0x11d0a48: stur            x3, [fp, #-0x20]
    // 0x11d0a4c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x11d0a4c: ldur            w2, [x1, #0x17]
    // 0x11d0a50: DecompressPointer r2
    //     0x11d0a50: add             x2, x2, HEAP, lsl #32
    // 0x11d0a54: stur            x2, [fp, #-0x18]
    // 0x11d0a58: LoadField: d0 = r1->field_1b
    //     0x11d0a58: ldur            d0, [x1, #0x1b]
    // 0x11d0a5c: stur            d0, [fp, #-0x28]
    // 0x11d0a60: LoadField: r5 = r1->field_23
    //     0x11d0a60: ldur            w5, [x1, #0x23]
    // 0x11d0a64: DecompressPointer r5
    //     0x11d0a64: add             x5, x5, HEAP, lsl #32
    // 0x11d0a68: stur            x5, [fp, #-0x10]
    // 0x11d0a6c: LoadField: r6 = r1->field_27
    //     0x11d0a6c: ldur            w6, [x1, #0x27]
    // 0x11d0a70: DecompressPointer r6
    //     0x11d0a70: add             x6, x6, HEAP, lsl #32
    // 0x11d0a74: stur            x6, [fp, #-8]
    // 0x11d0a78: r1 = <RRect>
    //     0x11d0a78: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x11d0a7c: ldr             x1, [x1, #0x108]
    // 0x11d0a80: r0 = RenderPhysicalModel()
    //     0x11d0a80: bl              #0x11d0b78  ; AllocateRenderPhysicalModelStub -> RenderPhysicalModel (size=0x80)
    // 0x11d0a84: mov             x1, x0
    // 0x11d0a88: ldur            x2, [fp, #-0x18]
    // 0x11d0a8c: ldur            x3, [fp, #-0x20]
    // 0x11d0a90: ldur            x5, [fp, #-0x10]
    // 0x11d0a94: ldur            d0, [fp, #-0x28]
    // 0x11d0a98: ldur            x6, [fp, #-8]
    // 0x11d0a9c: stur            x0, [fp, #-8]
    // 0x11d0aa0: r0 = RenderPhysicalModel()
    //     0x11d0aa0: bl              #0x11d0abc  ; [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalModel::RenderPhysicalModel
    // 0x11d0aa4: ldur            x0, [fp, #-8]
    // 0x11d0aa8: LeaveFrame
    //     0x11d0aa8: mov             SP, fp
    //     0x11d0aac: ldp             fp, lr, [SP], #0x10
    // 0x11d0ab0: ret
    //     0x11d0ab0: ret             
    // 0x11d0ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0ab8: b               #0x11d0a40
  }
}

// class id: 6637, size: 0x18, field offset: 0x10
//   const constructor, 
class ClipPath extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6684, size: 0xd4
    // 0xcf6684: EnterFrame
    //     0xcf6684: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6688: mov             fp, SP
    // 0xcf668c: AllocStack(0x10)
    //     0xcf668c: sub             SP, SP, #0x10
    // 0xcf6690: SetupParameters(ClipPath this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf6690: mov             x4, x1
    //     0xcf6694: stur            x1, [fp, #-8]
    //     0xcf6698: stur            x3, [fp, #-0x10]
    // 0xcf669c: CheckStackOverflow
    //     0xcf669c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf66a0: cmp             SP, x16
    //     0xcf66a4: b.ls            #0xcf6750
    // 0xcf66a8: mov             x0, x3
    // 0xcf66ac: r2 = Null
    //     0xcf66ac: mov             x2, NULL
    // 0xcf66b0: r1 = Null
    //     0xcf66b0: mov             x1, NULL
    // 0xcf66b4: r4 = 60
    //     0xcf66b4: mov             x4, #0x3c
    // 0xcf66b8: branchIfSmi(r0, 0xcf66c4)
    //     0xcf66b8: tbz             w0, #0, #0xcf66c4
    // 0xcf66bc: r4 = LoadClassIdInstr(r0)
    //     0xcf66bc: ldur            x4, [x0, #-1]
    //     0xcf66c0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf66c4: r17 = 4933
    //     0xcf66c4: mov             x17, #0x1345
    // 0xcf66c8: cmp             x4, x17
    // 0xcf66cc: b.eq            #0xcf66e4
    // 0xcf66d0: r8 = RenderClipPath
    //     0xcf66d0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90368] Type: RenderClipPath
    //     0xcf66d4: ldr             x8, [x8, #0x368]
    // 0xcf66d8: r3 = Null
    //     0xcf66d8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90380] Null
    //     0xcf66dc: ldr             x3, [x3, #0x380]
    // 0xcf66e0: r0 = DefaultTypeTest()
    //     0xcf66e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf66e4: ldur            x0, [fp, #-8]
    // 0xcf66e8: LoadField: r2 = r0->field_f
    //     0xcf66e8: ldur            w2, [x0, #0xf]
    // 0xcf66ec: DecompressPointer r2
    //     0xcf66ec: add             x2, x2, HEAP, lsl #32
    // 0xcf66f0: ldur            x1, [fp, #-0x10]
    // 0xcf66f4: r0 = clipper=()
    //     0xcf66f4: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf66f8: ldur            x0, [fp, #-8]
    // 0xcf66fc: LoadField: r1 = r0->field_13
    //     0xcf66fc: ldur            w1, [x0, #0x13]
    // 0xcf6700: DecompressPointer r1
    //     0xcf6700: add             x1, x1, HEAP, lsl #32
    // 0xcf6704: ldur            x2, [fp, #-0x10]
    // 0xcf6708: LoadField: r0 = r2->field_5f
    //     0xcf6708: ldur            w0, [x2, #0x5f]
    // 0xcf670c: DecompressPointer r0
    //     0xcf670c: add             x0, x0, HEAP, lsl #32
    // 0xcf6710: cmp             w1, w0
    // 0xcf6714: b.eq            #0xcf6740
    // 0xcf6718: mov             x0, x1
    // 0xcf671c: StoreField: r2->field_5f = r0
    //     0xcf671c: stur            w0, [x2, #0x5f]
    //     0xcf6720: ldurb           w16, [x2, #-1]
    //     0xcf6724: ldurb           w17, [x0, #-1]
    //     0xcf6728: and             x16, x17, x16, lsr #2
    //     0xcf672c: tst             x16, HEAP, lsr #32
    //     0xcf6730: b.eq            #0xcf6738
    //     0xcf6734: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6738: mov             x1, x2
    // 0xcf673c: r0 = markNeedsPaint()
    //     0xcf673c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6740: r0 = Null
    //     0xcf6740: mov             x0, NULL
    // 0xcf6744: LeaveFrame
    //     0xcf6744: mov             SP, fp
    //     0xcf6748: ldp             fp, lr, [SP], #0x10
    // 0xcf674c: ret
    //     0xcf674c: ret             
    // 0xcf6750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6750: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6754: b               #0xcf66a8
  }
  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0xcff218, size: 0x80
    // 0xcff218: EnterFrame
    //     0xcff218: stp             fp, lr, [SP, #-0x10]!
    //     0xcff21c: mov             fp, SP
    // 0xcff220: AllocStack(0x8)
    //     0xcff220: sub             SP, SP, #8
    // 0xcff224: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xcff224: mov             x3, x2
    //     0xcff228: stur            x2, [fp, #-8]
    // 0xcff22c: CheckStackOverflow
    //     0xcff22c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff230: cmp             SP, x16
    //     0xcff234: b.ls            #0xcff290
    // 0xcff238: mov             x0, x3
    // 0xcff23c: r2 = Null
    //     0xcff23c: mov             x2, NULL
    // 0xcff240: r1 = Null
    //     0xcff240: mov             x1, NULL
    // 0xcff244: r4 = 60
    //     0xcff244: mov             x4, #0x3c
    // 0xcff248: branchIfSmi(r0, 0xcff254)
    //     0xcff248: tbz             w0, #0, #0xcff254
    // 0xcff24c: r4 = LoadClassIdInstr(r0)
    //     0xcff24c: ldur            x4, [x0, #-1]
    //     0xcff250: ubfx            x4, x4, #0xc, #0x14
    // 0xcff254: r17 = 4933
    //     0xcff254: mov             x17, #0x1345
    // 0xcff258: cmp             x4, x17
    // 0xcff25c: b.eq            #0xcff274
    // 0xcff260: r8 = RenderClipPath
    //     0xcff260: add             x8, PP, #0x90, lsl #12  ; [pp+0x90368] Type: RenderClipPath
    //     0xcff264: ldr             x8, [x8, #0x368]
    // 0xcff268: r3 = Null
    //     0xcff268: add             x3, PP, #0x90, lsl #12  ; [pp+0x90370] Null
    //     0xcff26c: ldr             x3, [x3, #0x370]
    // 0xcff270: r0 = DefaultTypeTest()
    //     0xcff270: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcff274: ldur            x1, [fp, #-8]
    // 0xcff278: r2 = Null
    //     0xcff278: mov             x2, NULL
    // 0xcff27c: r0 = clipper=()
    //     0xcff27c: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcff280: r0 = Null
    //     0xcff280: mov             x0, NULL
    // 0xcff284: LeaveFrame
    //     0xcff284: mov             SP, fp
    //     0xcff288: ldp             fp, lr, [SP], #0x10
    // 0xcff28c: ret
    //     0xcff28c: ret             
    // 0xcff290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff294: b               #0xcff238
  }
  static _ shape(/* No info */) {
    // ** addr: 0xfc3b38, size: 0x5c
    // 0xfc3b38: EnterFrame
    //     0xfc3b38: stp             fp, lr, [SP, #-0x10]!
    //     0xfc3b3c: mov             fp, SP
    // 0xfc3b40: AllocStack(0x10)
    //     0xfc3b40: sub             SP, SP, #0x10
    // 0xfc3b44: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfc3b44: stur            x1, [fp, #-8]
    //     0xfc3b48: stur            x2, [fp, #-0x10]
    // 0xfc3b4c: r1 = 2
    //     0xfc3b4c: mov             x1, #2
    // 0xfc3b50: r0 = AllocateContext()
    //     0xfc3b50: bl              #0x13de838  ; AllocateContextStub
    // 0xfc3b54: mov             x1, x0
    // 0xfc3b58: ldur            x0, [fp, #-8]
    // 0xfc3b5c: StoreField: r1->field_f = r0
    //     0xfc3b5c: stur            w0, [x1, #0xf]
    // 0xfc3b60: ldur            x0, [fp, #-0x10]
    // 0xfc3b64: StoreField: r1->field_13 = r0
    //     0xfc3b64: stur            w0, [x1, #0x13]
    // 0xfc3b68: mov             x2, x1
    // 0xfc3b6c: r1 = Function '<anonymous closure>': static.
    //     0xfc3b6c: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0a80] AnonymousClosure: static (0xfc3b94), in [package:flutter/src/widgets/basic.dart] ClipPath::shape (0xfc3b38)
    //     0xfc3b70: ldr             x1, [x1, #0xa80]
    // 0xfc3b74: r0 = AllocateClosure()
    //     0xfc3b74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfc3b78: stur            x0, [fp, #-8]
    // 0xfc3b7c: r0 = Builder()
    //     0xfc3b7c: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xfc3b80: ldur            x1, [fp, #-8]
    // 0xfc3b84: StoreField: r0->field_b = r1
    //     0xfc3b84: stur            w1, [x0, #0xb]
    // 0xfc3b88: LeaveFrame
    //     0xfc3b88: mov             SP, fp
    //     0xfc3b8c: ldp             fp, lr, [SP], #0x10
    // 0xfc3b90: ret
    //     0xfc3b90: ret             
  }
  [closure] static ClipPath <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xfc3b94, size: 0xa8
    // 0xfc3b94: EnterFrame
    //     0xfc3b94: stp             fp, lr, [SP, #-0x10]!
    //     0xfc3b98: mov             fp, SP
    // 0xfc3b9c: AllocStack(0x20)
    //     0xfc3b9c: sub             SP, SP, #0x20
    // 0xfc3ba0: SetupParameters([dynamic _ /* r0 */])
    //     0xfc3ba0: ldr             x0, [fp, #0x18]
    //     0xfc3ba4: ldur            w2, [x0, #0x17]
    //     0xfc3ba8: add             x2, x2, HEAP, lsl #32
    //     0xfc3bac: stur            x2, [fp, #-0x10]
    // 0xfc3bb0: CheckStackOverflow
    //     0xfc3bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfc3bb4: cmp             SP, x16
    //     0xfc3bb8: b.ls            #0xfc3c34
    // 0xfc3bbc: LoadField: r0 = r2->field_13
    //     0xfc3bbc: ldur            w0, [x2, #0x13]
    // 0xfc3bc0: DecompressPointer r0
    //     0xfc3bc0: add             x0, x0, HEAP, lsl #32
    // 0xfc3bc4: ldr             x1, [fp, #0x10]
    // 0xfc3bc8: stur            x0, [fp, #-8]
    // 0xfc3bcc: r0 = maybeOf()
    //     0xfc3bcc: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xfc3bd0: r1 = <Path>
    //     0xfc3bd0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0xfc3bd4: ldr             x1, [x1, #0xa60]
    // 0xfc3bd8: stur            x0, [fp, #-0x18]
    // 0xfc3bdc: r0 = ShapeBorderClipper()
    //     0xfc3bdc: bl              #0xd2e6cc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0xfc3be0: mov             x1, x0
    // 0xfc3be4: ldur            x0, [fp, #-8]
    // 0xfc3be8: stur            x1, [fp, #-0x20]
    // 0xfc3bec: StoreField: r1->field_f = r0
    //     0xfc3bec: stur            w0, [x1, #0xf]
    // 0xfc3bf0: ldur            x0, [fp, #-0x18]
    // 0xfc3bf4: StoreField: r1->field_13 = r0
    //     0xfc3bf4: stur            w0, [x1, #0x13]
    // 0xfc3bf8: ldur            x0, [fp, #-0x10]
    // 0xfc3bfc: LoadField: r2 = r0->field_f
    //     0xfc3bfc: ldur            w2, [x0, #0xf]
    // 0xfc3c00: DecompressPointer r2
    //     0xfc3c00: add             x2, x2, HEAP, lsl #32
    // 0xfc3c04: stur            x2, [fp, #-8]
    // 0xfc3c08: r0 = ClipPath()
    //     0xfc3c08: bl              #0xb27f2c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0xfc3c0c: ldur            x1, [fp, #-0x20]
    // 0xfc3c10: StoreField: r0->field_f = r1
    //     0xfc3c10: stur            w1, [x0, #0xf]
    // 0xfc3c14: r1 = Instance_Clip
    //     0xfc3c14: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xfc3c18: ldr             x1, [x1, #0x6f0]
    // 0xfc3c1c: StoreField: r0->field_13 = r1
    //     0xfc3c1c: stur            w1, [x0, #0x13]
    // 0xfc3c20: ldur            x1, [fp, #-8]
    // 0xfc3c24: StoreField: r0->field_b = r1
    //     0xfc3c24: stur            w1, [x0, #0xb]
    // 0xfc3c28: LeaveFrame
    //     0xfc3c28: mov             SP, fp
    //     0xfc3c2c: ldp             fp, lr, [SP], #0x10
    // 0xfc3c30: ret
    //     0xfc3c30: ret             
    // 0xfc3c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfc3c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfc3c38: b               #0xfc3bbc
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d09b4, size: 0x68
    // 0x11d09b4: EnterFrame
    //     0x11d09b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d09b8: mov             fp, SP
    // 0x11d09bc: AllocStack(0x10)
    //     0x11d09bc: sub             SP, SP, #0x10
    // 0x11d09c0: CheckStackOverflow
    //     0x11d09c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d09c4: cmp             SP, x16
    //     0x11d09c8: b.ls            #0x11d0a14
    // 0x11d09cc: LoadField: r3 = r1->field_f
    //     0x11d09cc: ldur            w3, [x1, #0xf]
    // 0x11d09d0: DecompressPointer r3
    //     0x11d09d0: add             x3, x3, HEAP, lsl #32
    // 0x11d09d4: stur            x3, [fp, #-0x10]
    // 0x11d09d8: LoadField: r2 = r1->field_13
    //     0x11d09d8: ldur            w2, [x1, #0x13]
    // 0x11d09dc: DecompressPointer r2
    //     0x11d09dc: add             x2, x2, HEAP, lsl #32
    // 0x11d09e0: stur            x2, [fp, #-8]
    // 0x11d09e4: r1 = <Path>
    //     0x11d09e4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0x11d09e8: ldr             x1, [x1, #0xa60]
    // 0x11d09ec: r0 = RenderClipPath()
    //     0x11d09ec: bl              #0x11d0a1c  ; AllocateRenderClipPathStub -> RenderClipPath (size=0x68)
    // 0x11d09f0: mov             x1, x0
    // 0x11d09f4: ldur            x2, [fp, #-8]
    // 0x11d09f8: ldur            x3, [fp, #-0x10]
    // 0x11d09fc: stur            x0, [fp, #-8]
    // 0x11d0a00: r0 = _RenderCustomClip()
    //     0x11d0a00: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0a04: ldur            x0, [fp, #-8]
    // 0x11d0a08: LeaveFrame
    //     0x11d0a08: mov             SP, fp
    //     0x11d0a0c: ldp             fp, lr, [SP], #0x10
    // 0x11d0a10: ret
    //     0x11d0a10: ret             
    // 0x11d0a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0a18: b               #0x11d09cc
  }
}

// class id: 6638, size: 0x18, field offset: 0x10
//   const constructor, 
class ClipOval extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf65f8, size: 0x8c
    // 0xcf65f8: EnterFrame
    //     0xcf65f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf65fc: mov             fp, SP
    // 0xcf6600: AllocStack(0x8)
    //     0xcf6600: sub             SP, SP, #8
    // 0xcf6604: SetupParameters(dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xcf6604: stur            x3, [fp, #-8]
    // 0xcf6608: CheckStackOverflow
    //     0xcf6608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf660c: cmp             SP, x16
    //     0xcf6610: b.ls            #0xcf667c
    // 0xcf6614: mov             x0, x3
    // 0xcf6618: r2 = Null
    //     0xcf6618: mov             x2, NULL
    // 0xcf661c: r1 = Null
    //     0xcf661c: mov             x1, NULL
    // 0xcf6620: r4 = 60
    //     0xcf6620: mov             x4, #0x3c
    // 0xcf6624: branchIfSmi(r0, 0xcf6630)
    //     0xcf6624: tbz             w0, #0, #0xcf6630
    // 0xcf6628: r4 = LoadClassIdInstr(r0)
    //     0xcf6628: ldur            x4, [x0, #-1]
    //     0xcf662c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6630: r17 = 4934
    //     0xcf6630: mov             x17, #0x1346
    // 0xcf6634: cmp             x4, x17
    // 0xcf6638: b.eq            #0xcf6650
    // 0xcf663c: r8 = RenderClipOval
    //     0xcf663c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85070] Type: RenderClipOval
    //     0xcf6640: ldr             x8, [x8, #0x70]
    // 0xcf6644: r3 = Null
    //     0xcf6644: add             x3, PP, #0x85, lsl #12  ; [pp+0x850a8] Null
    //     0xcf6648: ldr             x3, [x3, #0xa8]
    // 0xcf664c: r0 = DefaultTypeTest()
    //     0xcf664c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf6650: ldur            x1, [fp, #-8]
    // 0xcf6654: r2 = Null
    //     0xcf6654: mov             x2, NULL
    // 0xcf6658: r0 = clipper=()
    //     0xcf6658: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf665c: ldur            x1, [fp, #-8]
    // 0xcf6660: r2 = Instance_Clip
    //     0xcf6660: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xcf6664: ldr             x2, [x2, #0x6f0]
    // 0xcf6668: r0 = clipBehavior=()
    //     0xcf6668: bl              #0xcf6040  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipBehavior=
    // 0xcf666c: r0 = Null
    //     0xcf666c: mov             x0, NULL
    // 0xcf6670: LeaveFrame
    //     0xcf6670: mov             SP, fp
    //     0xcf6674: ldp             fp, lr, [SP], #0x10
    // 0xcf6678: ret
    //     0xcf6678: ret             
    // 0xcf667c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf667c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6680: b               #0xcf6614
  }
  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0xcff198, size: 0x80
    // 0xcff198: EnterFrame
    //     0xcff198: stp             fp, lr, [SP, #-0x10]!
    //     0xcff19c: mov             fp, SP
    // 0xcff1a0: AllocStack(0x8)
    //     0xcff1a0: sub             SP, SP, #8
    // 0xcff1a4: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xcff1a4: mov             x3, x2
    //     0xcff1a8: stur            x2, [fp, #-8]
    // 0xcff1ac: CheckStackOverflow
    //     0xcff1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff1b0: cmp             SP, x16
    //     0xcff1b4: b.ls            #0xcff210
    // 0xcff1b8: mov             x0, x3
    // 0xcff1bc: r2 = Null
    //     0xcff1bc: mov             x2, NULL
    // 0xcff1c0: r1 = Null
    //     0xcff1c0: mov             x1, NULL
    // 0xcff1c4: r4 = 60
    //     0xcff1c4: mov             x4, #0x3c
    // 0xcff1c8: branchIfSmi(r0, 0xcff1d4)
    //     0xcff1c8: tbz             w0, #0, #0xcff1d4
    // 0xcff1cc: r4 = LoadClassIdInstr(r0)
    //     0xcff1cc: ldur            x4, [x0, #-1]
    //     0xcff1d0: ubfx            x4, x4, #0xc, #0x14
    // 0xcff1d4: r17 = 4934
    //     0xcff1d4: mov             x17, #0x1346
    // 0xcff1d8: cmp             x4, x17
    // 0xcff1dc: b.eq            #0xcff1f4
    // 0xcff1e0: r8 = RenderClipOval
    //     0xcff1e0: add             x8, PP, #0x85, lsl #12  ; [pp+0x85070] Type: RenderClipOval
    //     0xcff1e4: ldr             x8, [x8, #0x70]
    // 0xcff1e8: r3 = Null
    //     0xcff1e8: add             x3, PP, #0x85, lsl #12  ; [pp+0x85078] Null
    //     0xcff1ec: ldr             x3, [x3, #0x78]
    // 0xcff1f0: r0 = DefaultTypeTest()
    //     0xcff1f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcff1f4: ldur            x1, [fp, #-8]
    // 0xcff1f8: r2 = Null
    //     0xcff1f8: mov             x2, NULL
    // 0xcff1fc: r0 = clipper=()
    //     0xcff1fc: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcff200: r0 = Null
    //     0xcff200: mov             x0, NULL
    // 0xcff204: LeaveFrame
    //     0xcff204: mov             SP, fp
    //     0xcff208: ldp             fp, lr, [SP], #0x10
    // 0xcff20c: ret
    //     0xcff20c: ret             
    // 0xcff210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff214: b               #0xcff1b8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d094c, size: 0x5c
    // 0x11d094c: EnterFrame
    //     0x11d094c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0950: mov             fp, SP
    // 0x11d0954: AllocStack(0x8)
    //     0x11d0954: sub             SP, SP, #8
    // 0x11d0958: CheckStackOverflow
    //     0x11d0958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d095c: cmp             SP, x16
    //     0x11d0960: b.ls            #0x11d09a0
    // 0x11d0964: r1 = <Rect>
    //     0x11d0964: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x11d0968: r0 = RenderClipOval()
    //     0x11d0968: bl              #0x11d09a8  ; AllocateRenderClipOvalStub -> RenderClipOval (size=0x70)
    // 0x11d096c: mov             x4, x0
    // 0x11d0970: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d0974: stur            x4, [fp, #-8]
    // 0x11d0978: StoreField: r4->field_6b = r0
    //     0x11d0978: stur            w0, [x4, #0x6b]
    // 0x11d097c: mov             x1, x4
    // 0x11d0980: r2 = Instance_Clip
    //     0x11d0980: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0x11d0984: ldr             x2, [x2, #0x6f0]
    // 0x11d0988: r3 = Null
    //     0x11d0988: mov             x3, NULL
    // 0x11d098c: r0 = _RenderCustomClip()
    //     0x11d098c: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0990: ldur            x0, [fp, #-8]
    // 0x11d0994: LeaveFrame
    //     0x11d0994: mov             SP, fp
    //     0x11d0998: ldp             fp, lr, [SP], #0x10
    // 0x11d099c: ret
    //     0x11d099c: ret             
    // 0x11d09a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d09a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d09a4: b               #0x11d0964
  }
}

// class id: 6639, size: 0x1c, field offset: 0x10
//   const constructor, 
class ClipRSuperellipse extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6514, size: 0xe4
    // 0xcf6514: EnterFrame
    //     0xcf6514: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6518: mov             fp, SP
    // 0xcf651c: AllocStack(0x18)
    //     0xcf651c: sub             SP, SP, #0x18
    // 0xcf6520: SetupParameters(ClipRSuperellipse this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf6520: mov             x5, x1
    //     0xcf6524: mov             x4, x2
    //     0xcf6528: stur            x1, [fp, #-8]
    //     0xcf652c: stur            x2, [fp, #-0x10]
    //     0xcf6530: stur            x3, [fp, #-0x18]
    // 0xcf6534: CheckStackOverflow
    //     0xcf6534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6538: cmp             SP, x16
    //     0xcf653c: b.ls            #0xcf65f0
    // 0xcf6540: mov             x0, x3
    // 0xcf6544: r2 = Null
    //     0xcf6544: mov             x2, NULL
    // 0xcf6548: r1 = Null
    //     0xcf6548: mov             x1, NULL
    // 0xcf654c: r4 = 60
    //     0xcf654c: mov             x4, #0x3c
    // 0xcf6550: branchIfSmi(r0, 0xcf655c)
    //     0xcf6550: tbz             w0, #0, #0xcf655c
    // 0xcf6554: r4 = LoadClassIdInstr(r0)
    //     0xcf6554: ldur            x4, [x0, #-1]
    //     0xcf6558: ubfx            x4, x4, #0xc, #0x14
    // 0xcf655c: r17 = 4935
    //     0xcf655c: mov             x17, #0x1347
    // 0xcf6560: cmp             x4, x17
    // 0xcf6564: b.eq            #0xcf657c
    // 0xcf6568: r8 = RenderClipRSuperellipse
    //     0xcf6568: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd05e0] Type: RenderClipRSuperellipse
    //     0xcf656c: ldr             x8, [x8, #0x5e0]
    // 0xcf6570: r3 = Null
    //     0xcf6570: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd05e8] Null
    //     0xcf6574: ldr             x3, [x3, #0x5e8]
    // 0xcf6578: r0 = DefaultTypeTest()
    //     0xcf6578: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf657c: ldur            x0, [fp, #-8]
    // 0xcf6580: LoadField: r2 = r0->field_f
    //     0xcf6580: ldur            w2, [x0, #0xf]
    // 0xcf6584: DecompressPointer r2
    //     0xcf6584: add             x2, x2, HEAP, lsl #32
    // 0xcf6588: ldur            x1, [fp, #-0x18]
    // 0xcf658c: r0 = borderRadius=()
    //     0xcf658c: bl              #0xcf648c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipRSuperellipse::borderRadius=
    // 0xcf6590: ldur            x0, [fp, #-0x18]
    // 0xcf6594: LoadField: r1 = r0->field_5f
    //     0xcf6594: ldur            w1, [x0, #0x5f]
    // 0xcf6598: DecompressPointer r1
    //     0xcf6598: add             x1, x1, HEAP, lsl #32
    // 0xcf659c: r16 = Instance_Clip
    //     0xcf659c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xcf65a0: ldr             x16, [x16, #0x6f0]
    // 0xcf65a4: cmp             w1, w16
    // 0xcf65a8: b.eq            #0xcf65c0
    // 0xcf65ac: r1 = Instance_Clip
    //     0xcf65ac: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xcf65b0: ldr             x1, [x1, #0x6f0]
    // 0xcf65b4: StoreField: r0->field_5f = r1
    //     0xcf65b4: stur            w1, [x0, #0x5f]
    // 0xcf65b8: mov             x1, x0
    // 0xcf65bc: r0 = markNeedsPaint()
    //     0xcf65bc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf65c0: ldur            x1, [fp, #-0x18]
    // 0xcf65c4: r2 = Null
    //     0xcf65c4: mov             x2, NULL
    // 0xcf65c8: r0 = clipper=()
    //     0xcf65c8: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf65cc: ldur            x1, [fp, #-0x10]
    // 0xcf65d0: r0 = maybeOf()
    //     0xcf65d0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf65d4: ldur            x1, [fp, #-0x18]
    // 0xcf65d8: mov             x2, x0
    // 0xcf65dc: r0 = textDirection=()
    //     0xcf65dc: bl              #0xcf641c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipRSuperellipse::textDirection=
    // 0xcf65e0: r0 = Null
    //     0xcf65e0: mov             x0, NULL
    // 0xcf65e4: LeaveFrame
    //     0xcf65e4: mov             SP, fp
    //     0xcf65e8: ldp             fp, lr, [SP], #0x10
    // 0xcf65ec: ret
    //     0xcf65ec: ret             
    // 0xcf65f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf65f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf65f4: b               #0xcf6540
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d08bc, size: 0x84
    // 0x11d08bc: EnterFrame
    //     0x11d08bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11d08c0: mov             fp, SP
    // 0x11d08c4: AllocStack(0x18)
    //     0x11d08c4: sub             SP, SP, #0x18
    // 0x11d08c8: SetupParameters(ClipRSuperellipse this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d08c8: mov             x0, x1
    //     0x11d08cc: mov             x1, x2
    // 0x11d08d0: CheckStackOverflow
    //     0x11d08d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d08d4: cmp             SP, x16
    //     0x11d08d8: b.ls            #0x11d0938
    // 0x11d08dc: LoadField: r2 = r0->field_f
    //     0x11d08dc: ldur            w2, [x0, #0xf]
    // 0x11d08e0: DecompressPointer r2
    //     0x11d08e0: add             x2, x2, HEAP, lsl #32
    // 0x11d08e4: stur            x2, [fp, #-8]
    // 0x11d08e8: r0 = maybeOf()
    //     0x11d08e8: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d08ec: r1 = <RSuperellipse>
    //     0x11d08ec: add             x1, PP, #0x90, lsl #12  ; [pp+0x90c28] TypeArguments: <RSuperellipse>
    //     0x11d08f0: ldr             x1, [x1, #0xc28]
    // 0x11d08f4: stur            x0, [fp, #-0x10]
    // 0x11d08f8: r0 = RenderClipRSuperellipse()
    //     0x11d08f8: bl              #0x11d0940  ; AllocateRenderClipRSuperellipseStub -> RenderClipRSuperellipse (size=0x70)
    // 0x11d08fc: mov             x4, x0
    // 0x11d0900: ldur            x0, [fp, #-8]
    // 0x11d0904: stur            x4, [fp, #-0x18]
    // 0x11d0908: StoreField: r4->field_67 = r0
    //     0x11d0908: stur            w0, [x4, #0x67]
    // 0x11d090c: ldur            x0, [fp, #-0x10]
    // 0x11d0910: StoreField: r4->field_6b = r0
    //     0x11d0910: stur            w0, [x4, #0x6b]
    // 0x11d0914: mov             x1, x4
    // 0x11d0918: r2 = Instance_Clip
    //     0x11d0918: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0x11d091c: ldr             x2, [x2, #0x6f0]
    // 0x11d0920: r3 = Null
    //     0x11d0920: mov             x3, NULL
    // 0x11d0924: r0 = _RenderCustomClip()
    //     0x11d0924: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0928: ldur            x0, [fp, #-0x18]
    // 0x11d092c: LeaveFrame
    //     0x11d092c: mov             SP, fp
    //     0x11d0930: ldp             fp, lr, [SP], #0x10
    // 0x11d0934: ret
    //     0x11d0934: ret             
    // 0x11d0938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d093c: b               #0x11d08dc
  }
}

// class id: 6640, size: 0x1c, field offset: 0x10
//   const constructor, 
class ClipRRect extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf6320, size: 0xfc
    // 0xcf6320: EnterFrame
    //     0xcf6320: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6324: mov             fp, SP
    // 0xcf6328: AllocStack(0x18)
    //     0xcf6328: sub             SP, SP, #0x18
    // 0xcf632c: SetupParameters(ClipRRect this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf632c: mov             x5, x1
    //     0xcf6330: mov             x4, x2
    //     0xcf6334: stur            x1, [fp, #-8]
    //     0xcf6338: stur            x2, [fp, #-0x10]
    //     0xcf633c: stur            x3, [fp, #-0x18]
    // 0xcf6340: CheckStackOverflow
    //     0xcf6340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf6344: cmp             SP, x16
    //     0xcf6348: b.ls            #0xcf6414
    // 0xcf634c: mov             x0, x3
    // 0xcf6350: r2 = Null
    //     0xcf6350: mov             x2, NULL
    // 0xcf6354: r1 = Null
    //     0xcf6354: mov             x1, NULL
    // 0xcf6358: r4 = 60
    //     0xcf6358: mov             x4, #0x3c
    // 0xcf635c: branchIfSmi(r0, 0xcf6368)
    //     0xcf635c: tbz             w0, #0, #0xcf6368
    // 0xcf6360: r4 = LoadClassIdInstr(r0)
    //     0xcf6360: ldur            x4, [x0, #-1]
    //     0xcf6364: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6368: r17 = 4936
    //     0xcf6368: mov             x17, #0x1348
    // 0xcf636c: cmp             x4, x17
    // 0xcf6370: b.eq            #0xcf6388
    // 0xcf6374: r8 = RenderClipRRect
    //     0xcf6374: add             x8, PP, #0x85, lsl #12  ; [pp+0x850f0] Type: RenderClipRRect
    //     0xcf6378: ldr             x8, [x8, #0xf0]
    // 0xcf637c: r3 = Null
    //     0xcf637c: add             x3, PP, #0x85, lsl #12  ; [pp+0x850f8] Null
    //     0xcf6380: ldr             x3, [x3, #0xf8]
    // 0xcf6384: r0 = DefaultTypeTest()
    //     0xcf6384: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf6388: ldur            x0, [fp, #-8]
    // 0xcf638c: LoadField: r2 = r0->field_f
    //     0xcf638c: ldur            w2, [x0, #0xf]
    // 0xcf6390: DecompressPointer r2
    //     0xcf6390: add             x2, x2, HEAP, lsl #32
    // 0xcf6394: ldur            x1, [fp, #-0x18]
    // 0xcf6398: r0 = borderRadius=()
    //     0xcf6398: bl              #0xcf648c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipRSuperellipse::borderRadius=
    // 0xcf639c: ldur            x0, [fp, #-8]
    // 0xcf63a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcf63a0: ldur            w1, [x0, #0x17]
    // 0xcf63a4: DecompressPointer r1
    //     0xcf63a4: add             x1, x1, HEAP, lsl #32
    // 0xcf63a8: ldur            x2, [fp, #-0x18]
    // 0xcf63ac: LoadField: r0 = r2->field_5f
    //     0xcf63ac: ldur            w0, [x2, #0x5f]
    // 0xcf63b0: DecompressPointer r0
    //     0xcf63b0: add             x0, x0, HEAP, lsl #32
    // 0xcf63b4: cmp             w1, w0
    // 0xcf63b8: b.eq            #0xcf63e4
    // 0xcf63bc: mov             x0, x1
    // 0xcf63c0: StoreField: r2->field_5f = r0
    //     0xcf63c0: stur            w0, [x2, #0x5f]
    //     0xcf63c4: ldurb           w16, [x2, #-1]
    //     0xcf63c8: ldurb           w17, [x0, #-1]
    //     0xcf63cc: and             x16, x17, x16, lsr #2
    //     0xcf63d0: tst             x16, HEAP, lsr #32
    //     0xcf63d4: b.eq            #0xcf63dc
    //     0xcf63d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf63dc: mov             x1, x2
    // 0xcf63e0: r0 = markNeedsPaint()
    //     0xcf63e0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf63e4: ldur            x1, [fp, #-0x18]
    // 0xcf63e8: r2 = Null
    //     0xcf63e8: mov             x2, NULL
    // 0xcf63ec: r0 = clipper=()
    //     0xcf63ec: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf63f0: ldur            x1, [fp, #-0x10]
    // 0xcf63f4: r0 = maybeOf()
    //     0xcf63f4: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf63f8: ldur            x1, [fp, #-0x18]
    // 0xcf63fc: mov             x2, x0
    // 0xcf6400: r0 = textDirection=()
    //     0xcf6400: bl              #0xcf641c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipRSuperellipse::textDirection=
    // 0xcf6404: r0 = Null
    //     0xcf6404: mov             x0, NULL
    // 0xcf6408: LeaveFrame
    //     0xcf6408: mov             SP, fp
    //     0xcf640c: ldp             fp, lr, [SP], #0x10
    // 0xcf6410: ret
    //     0xcf6410: ret             
    // 0xcf6414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6418: b               #0xcf634c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0824, size: 0x8c
    // 0x11d0824: EnterFrame
    //     0x11d0824: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0828: mov             fp, SP
    // 0x11d082c: AllocStack(0x20)
    //     0x11d082c: sub             SP, SP, #0x20
    // 0x11d0830: SetupParameters(ClipRRect this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d0830: mov             x0, x1
    //     0x11d0834: mov             x1, x2
    // 0x11d0838: CheckStackOverflow
    //     0x11d0838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d083c: cmp             SP, x16
    //     0x11d0840: b.ls            #0x11d08a8
    // 0x11d0844: LoadField: r2 = r0->field_f
    //     0x11d0844: ldur            w2, [x0, #0xf]
    // 0x11d0848: DecompressPointer r2
    //     0x11d0848: add             x2, x2, HEAP, lsl #32
    // 0x11d084c: stur            x2, [fp, #-0x10]
    // 0x11d0850: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x11d0850: ldur            w3, [x0, #0x17]
    // 0x11d0854: DecompressPointer r3
    //     0x11d0854: add             x3, x3, HEAP, lsl #32
    // 0x11d0858: stur            x3, [fp, #-8]
    // 0x11d085c: r0 = maybeOf()
    //     0x11d085c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11d0860: r1 = <RRect>
    //     0x11d0860: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x11d0864: ldr             x1, [x1, #0x108]
    // 0x11d0868: stur            x0, [fp, #-0x18]
    // 0x11d086c: r0 = RenderClipRRect()
    //     0x11d086c: bl              #0x11d08b0  ; AllocateRenderClipRRectStub -> RenderClipRRect (size=0x70)
    // 0x11d0870: mov             x4, x0
    // 0x11d0874: ldur            x0, [fp, #-0x10]
    // 0x11d0878: stur            x4, [fp, #-0x20]
    // 0x11d087c: StoreField: r4->field_67 = r0
    //     0x11d087c: stur            w0, [x4, #0x67]
    // 0x11d0880: ldur            x0, [fp, #-0x18]
    // 0x11d0884: StoreField: r4->field_6b = r0
    //     0x11d0884: stur            w0, [x4, #0x6b]
    // 0x11d0888: mov             x1, x4
    // 0x11d088c: ldur            x2, [fp, #-8]
    // 0x11d0890: r3 = Null
    //     0x11d0890: mov             x3, NULL
    // 0x11d0894: r0 = _RenderCustomClip()
    //     0x11d0894: bl              #0x11d0760  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_RenderCustomClip
    // 0x11d0898: ldur            x0, [fp, #-0x20]
    // 0x11d089c: LeaveFrame
    //     0x11d089c: mov             SP, fp
    //     0x11d08a0: ldp             fp, lr, [SP], #0x10
    // 0x11d08a4: ret
    //     0x11d08a4: ret             
    // 0x11d08a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d08a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d08ac: b               #0x11d0844
  }
}

// class id: 6641, size: 0x18, field offset: 0x10
//   const constructor, 
class ClipRect extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf5f74, size: 0xcc
    // 0xcf5f74: EnterFrame
    //     0xcf5f74: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5f78: mov             fp, SP
    // 0xcf5f7c: AllocStack(0x10)
    //     0xcf5f7c: sub             SP, SP, #0x10
    // 0xcf5f80: SetupParameters(ClipRect this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf5f80: mov             x4, x1
    //     0xcf5f84: stur            x1, [fp, #-8]
    //     0xcf5f88: stur            x3, [fp, #-0x10]
    // 0xcf5f8c: CheckStackOverflow
    //     0xcf5f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5f90: cmp             SP, x16
    //     0xcf5f94: b.ls            #0xcf6038
    // 0xcf5f98: mov             x0, x3
    // 0xcf5f9c: r2 = Null
    //     0xcf5f9c: mov             x2, NULL
    // 0xcf5fa0: r1 = Null
    //     0xcf5fa0: mov             x1, NULL
    // 0xcf5fa4: r4 = 60
    //     0xcf5fa4: mov             x4, #0x3c
    // 0xcf5fa8: branchIfSmi(r0, 0xcf5fb4)
    //     0xcf5fa8: tbz             w0, #0, #0xcf5fb4
    // 0xcf5fac: r4 = LoadClassIdInstr(r0)
    //     0xcf5fac: ldur            x4, [x0, #-1]
    //     0xcf5fb0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5fb4: r17 = 4937
    //     0xcf5fb4: mov             x17, #0x1349
    // 0xcf5fb8: cmp             x4, x17
    // 0xcf5fbc: b.eq            #0xcf5fd4
    // 0xcf5fc0: r8 = RenderClipRect
    //     0xcf5fc0: add             x8, PP, #0x99, lsl #12  ; [pp+0x99de8] Type: RenderClipRect
    //     0xcf5fc4: ldr             x8, [x8, #0xde8]
    // 0xcf5fc8: r3 = Null
    //     0xcf5fc8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e00] Null
    //     0xcf5fcc: ldr             x3, [x3, #0xe00]
    // 0xcf5fd0: r0 = DefaultTypeTest()
    //     0xcf5fd0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf5fd4: ldur            x1, [fp, #-0x10]
    // 0xcf5fd8: r2 = Null
    //     0xcf5fd8: mov             x2, NULL
    // 0xcf5fdc: r0 = clipper=()
    //     0xcf5fdc: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcf5fe0: ldur            x0, [fp, #-8]
    // 0xcf5fe4: LoadField: r1 = r0->field_13
    //     0xcf5fe4: ldur            w1, [x0, #0x13]
    // 0xcf5fe8: DecompressPointer r1
    //     0xcf5fe8: add             x1, x1, HEAP, lsl #32
    // 0xcf5fec: ldur            x2, [fp, #-0x10]
    // 0xcf5ff0: LoadField: r0 = r2->field_5f
    //     0xcf5ff0: ldur            w0, [x2, #0x5f]
    // 0xcf5ff4: DecompressPointer r0
    //     0xcf5ff4: add             x0, x0, HEAP, lsl #32
    // 0xcf5ff8: cmp             w1, w0
    // 0xcf5ffc: b.eq            #0xcf6028
    // 0xcf6000: mov             x0, x1
    // 0xcf6004: StoreField: r2->field_5f = r0
    //     0xcf6004: stur            w0, [x2, #0x5f]
    //     0xcf6008: ldurb           w16, [x2, #-1]
    //     0xcf600c: ldurb           w17, [x0, #-1]
    //     0xcf6010: and             x16, x17, x16, lsr #2
    //     0xcf6014: tst             x16, HEAP, lsr #32
    //     0xcf6018: b.eq            #0xcf6020
    //     0xcf601c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf6020: mov             x1, x2
    // 0xcf6024: r0 = markNeedsPaint()
    //     0xcf6024: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf6028: r0 = Null
    //     0xcf6028: mov             x0, NULL
    // 0xcf602c: LeaveFrame
    //     0xcf602c: mov             SP, fp
    //     0xcf6030: ldp             fp, lr, [SP], #0x10
    // 0xcf6034: ret
    //     0xcf6034: ret             
    // 0xcf6038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6038: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf603c: b               #0xcf5f98
  }
  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0xcff118, size: 0x80
    // 0xcff118: EnterFrame
    //     0xcff118: stp             fp, lr, [SP, #-0x10]!
    //     0xcff11c: mov             fp, SP
    // 0xcff120: AllocStack(0x8)
    //     0xcff120: sub             SP, SP, #8
    // 0xcff124: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xcff124: mov             x3, x2
    //     0xcff128: stur            x2, [fp, #-8]
    // 0xcff12c: CheckStackOverflow
    //     0xcff12c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff130: cmp             SP, x16
    //     0xcff134: b.ls            #0xcff190
    // 0xcff138: mov             x0, x3
    // 0xcff13c: r2 = Null
    //     0xcff13c: mov             x2, NULL
    // 0xcff140: r1 = Null
    //     0xcff140: mov             x1, NULL
    // 0xcff144: r4 = 60
    //     0xcff144: mov             x4, #0x3c
    // 0xcff148: branchIfSmi(r0, 0xcff154)
    //     0xcff148: tbz             w0, #0, #0xcff154
    // 0xcff14c: r4 = LoadClassIdInstr(r0)
    //     0xcff14c: ldur            x4, [x0, #-1]
    //     0xcff150: ubfx            x4, x4, #0xc, #0x14
    // 0xcff154: r17 = 4937
    //     0xcff154: mov             x17, #0x1349
    // 0xcff158: cmp             x4, x17
    // 0xcff15c: b.eq            #0xcff174
    // 0xcff160: r8 = RenderClipRect
    //     0xcff160: add             x8, PP, #0x99, lsl #12  ; [pp+0x99de8] Type: RenderClipRect
    //     0xcff164: ldr             x8, [x8, #0xde8]
    // 0xcff168: r3 = Null
    //     0xcff168: add             x3, PP, #0x99, lsl #12  ; [pp+0x99df0] Null
    //     0xcff16c: ldr             x3, [x3, #0xdf0]
    // 0xcff170: r0 = DefaultTypeTest()
    //     0xcff170: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcff174: ldur            x1, [fp, #-8]
    // 0xcff178: r2 = Null
    //     0xcff178: mov             x2, NULL
    // 0xcff17c: r0 = clipper=()
    //     0xcff17c: bl              #0xcf60a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::clipper=
    // 0xcff180: r0 = Null
    //     0xcff180: mov             x0, NULL
    // 0xcff184: LeaveFrame
    //     0xcff184: mov             SP, fp
    //     0xcff188: ldp             fp, lr, [SP], #0x10
    // 0xcff18c: ret
    //     0xcff18c: ret             
    // 0xcff190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff194: b               #0xcff138
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d06d8, size: 0x54
    // 0x11d06d8: EnterFrame
    //     0x11d06d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d06dc: mov             fp, SP
    // 0x11d06e0: AllocStack(0x8)
    //     0x11d06e0: sub             SP, SP, #8
    // 0x11d06e4: CheckStackOverflow
    //     0x11d06e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d06e8: cmp             SP, x16
    //     0x11d06ec: b.ls            #0x11d0724
    // 0x11d06f0: LoadField: r2 = r1->field_13
    //     0x11d06f0: ldur            w2, [x1, #0x13]
    // 0x11d06f4: DecompressPointer r2
    //     0x11d06f4: add             x2, x2, HEAP, lsl #32
    // 0x11d06f8: stur            x2, [fp, #-8]
    // 0x11d06fc: r1 = <Rect>
    //     0x11d06fc: ldr             x1, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x11d0700: r0 = RenderClipRect()
    //     0x11d0700: bl              #0x11d0818  ; AllocateRenderClipRectStub -> RenderClipRect (size=0x68)
    // 0x11d0704: mov             x1, x0
    // 0x11d0708: ldur            x2, [fp, #-8]
    // 0x11d070c: stur            x0, [fp, #-8]
    // 0x11d0710: r0 = RenderClipRect()
    //     0x11d0710: bl              #0x11d072c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipRect::RenderClipRect
    // 0x11d0714: ldur            x0, [fp, #-8]
    // 0x11d0718: LeaveFrame
    //     0x11d0718: mov             SP, fp
    //     0x11d071c: ldp             fp, lr, [SP], #0x10
    // 0x11d0720: ret
    //     0x11d0720: ret             
    // 0x11d0724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0728: b               #0x11d06f0
  }
}

// class id: 6642, size: 0x24, field offset: 0x10
//   const constructor, 
class CustomPaint extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf5b10, size: 0xc4
    // 0xcf5b10: EnterFrame
    //     0xcf5b10: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5b14: mov             fp, SP
    // 0xcf5b18: AllocStack(0x10)
    //     0xcf5b18: sub             SP, SP, #0x10
    // 0xcf5b1c: SetupParameters(CustomPaint this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf5b1c: mov             x4, x1
    //     0xcf5b20: stur            x1, [fp, #-8]
    //     0xcf5b24: stur            x3, [fp, #-0x10]
    // 0xcf5b28: CheckStackOverflow
    //     0xcf5b28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5b2c: cmp             SP, x16
    //     0xcf5b30: b.ls            #0xcf5bcc
    // 0xcf5b34: mov             x0, x3
    // 0xcf5b38: r2 = Null
    //     0xcf5b38: mov             x2, NULL
    // 0xcf5b3c: r1 = Null
    //     0xcf5b3c: mov             x1, NULL
    // 0xcf5b40: r4 = 60
    //     0xcf5b40: mov             x4, #0x3c
    // 0xcf5b44: branchIfSmi(r0, 0xcf5b50)
    //     0xcf5b44: tbz             w0, #0, #0xcf5b50
    // 0xcf5b48: r4 = LoadClassIdInstr(r0)
    //     0xcf5b48: ldur            x4, [x0, #-1]
    //     0xcf5b4c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5b50: r17 = 4956
    //     0xcf5b50: mov             x17, #0x135c
    // 0xcf5b54: cmp             x4, x17
    // 0xcf5b58: b.eq            #0xcf5b70
    // 0xcf5b5c: r8 = RenderCustomPaint
    //     0xcf5b5c: add             x8, PP, #0x90, lsl #12  ; [pp+0x901d8] Type: RenderCustomPaint
    //     0xcf5b60: ldr             x8, [x8, #0x1d8]
    // 0xcf5b64: r3 = Null
    //     0xcf5b64: add             x3, PP, #0x90, lsl #12  ; [pp+0x901f8] Null
    //     0xcf5b68: ldr             x3, [x3, #0x1f8]
    // 0xcf5b6c: r0 = DefaultTypeTest()
    //     0xcf5b6c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf5b70: ldur            x0, [fp, #-8]
    // 0xcf5b74: LoadField: r2 = r0->field_f
    //     0xcf5b74: ldur            w2, [x0, #0xf]
    // 0xcf5b78: DecompressPointer r2
    //     0xcf5b78: add             x2, x2, HEAP, lsl #32
    // 0xcf5b7c: ldur            x1, [fp, #-0x10]
    // 0xcf5b80: r0 = painter=()
    //     0xcf5b80: bl              #0xcf5ec4  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::painter=
    // 0xcf5b84: ldur            x0, [fp, #-8]
    // 0xcf5b88: LoadField: r2 = r0->field_13
    //     0xcf5b88: ldur            w2, [x0, #0x13]
    // 0xcf5b8c: DecompressPointer r2
    //     0xcf5b8c: add             x2, x2, HEAP, lsl #32
    // 0xcf5b90: ldur            x1, [fp, #-0x10]
    // 0xcf5b94: r0 = foregroundPainter=()
    //     0xcf5b94: bl              #0xcf5c5c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::foregroundPainter=
    // 0xcf5b98: ldur            x0, [fp, #-8]
    // 0xcf5b9c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf5b9c: ldur            w2, [x0, #0x17]
    // 0xcf5ba0: DecompressPointer r2
    //     0xcf5ba0: add             x2, x2, HEAP, lsl #32
    // 0xcf5ba4: ldur            x1, [fp, #-0x10]
    // 0xcf5ba8: r0 = preferredSize=()
    //     0xcf5ba8: bl              #0xcf5bd4  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::preferredSize=
    // 0xcf5bac: ldur            x2, [fp, #-0x10]
    // 0xcf5bb0: r1 = false
    //     0xcf5bb0: add             x1, NULL, #0x30  ; false
    // 0xcf5bb4: StoreField: r2->field_5f = r1
    //     0xcf5bb4: stur            w1, [x2, #0x5f]
    // 0xcf5bb8: StoreField: r2->field_63 = r1
    //     0xcf5bb8: stur            w1, [x2, #0x63]
    // 0xcf5bbc: r0 = Null
    //     0xcf5bbc: mov             x0, NULL
    // 0xcf5bc0: LeaveFrame
    //     0xcf5bc0: mov             SP, fp
    //     0xcf5bc4: ldp             fp, lr, [SP], #0x10
    // 0xcf5bc8: ret
    //     0xcf5bc8: ret             
    // 0xcf5bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5bcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5bd0: b               #0xcf5b34
  }
  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0xcff08c, size: 0x8c
    // 0xcff08c: EnterFrame
    //     0xcff08c: stp             fp, lr, [SP, #-0x10]!
    //     0xcff090: mov             fp, SP
    // 0xcff094: AllocStack(0x8)
    //     0xcff094: sub             SP, SP, #8
    // 0xcff098: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xcff098: mov             x3, x2
    //     0xcff09c: stur            x2, [fp, #-8]
    // 0xcff0a0: CheckStackOverflow
    //     0xcff0a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff0a4: cmp             SP, x16
    //     0xcff0a8: b.ls            #0xcff110
    // 0xcff0ac: mov             x0, x3
    // 0xcff0b0: r2 = Null
    //     0xcff0b0: mov             x2, NULL
    // 0xcff0b4: r1 = Null
    //     0xcff0b4: mov             x1, NULL
    // 0xcff0b8: r4 = 60
    //     0xcff0b8: mov             x4, #0x3c
    // 0xcff0bc: branchIfSmi(r0, 0xcff0c8)
    //     0xcff0bc: tbz             w0, #0, #0xcff0c8
    // 0xcff0c0: r4 = LoadClassIdInstr(r0)
    //     0xcff0c0: ldur            x4, [x0, #-1]
    //     0xcff0c4: ubfx            x4, x4, #0xc, #0x14
    // 0xcff0c8: r17 = 4956
    //     0xcff0c8: mov             x17, #0x135c
    // 0xcff0cc: cmp             x4, x17
    // 0xcff0d0: b.eq            #0xcff0e8
    // 0xcff0d4: r8 = RenderCustomPaint
    //     0xcff0d4: add             x8, PP, #0x90, lsl #12  ; [pp+0x901d8] Type: RenderCustomPaint
    //     0xcff0d8: ldr             x8, [x8, #0x1d8]
    // 0xcff0dc: r3 = Null
    //     0xcff0dc: add             x3, PP, #0x90, lsl #12  ; [pp+0x901e0] Null
    //     0xcff0e0: ldr             x3, [x3, #0x1e0]
    // 0xcff0e4: r0 = DefaultTypeTest()
    //     0xcff0e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcff0e8: ldur            x1, [fp, #-8]
    // 0xcff0ec: r2 = Null
    //     0xcff0ec: mov             x2, NULL
    // 0xcff0f0: r0 = painter=()
    //     0xcff0f0: bl              #0xcf5ec4  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::painter=
    // 0xcff0f4: ldur            x1, [fp, #-8]
    // 0xcff0f8: r2 = Null
    //     0xcff0f8: mov             x2, NULL
    // 0xcff0fc: r0 = foregroundPainter=()
    //     0xcff0fc: bl              #0xcf5c5c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::foregroundPainter=
    // 0xcff100: r0 = Null
    //     0xcff100: mov             x0, NULL
    // 0xcff104: LeaveFrame
    //     0xcff104: mov             SP, fp
    //     0xcff108: ldp             fp, lr, [SP], #0x10
    // 0xcff10c: ret
    //     0xcff10c: ret             
    // 0xcff110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff114: b               #0xcff0ac
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0570, size: 0x70
    // 0x11d0570: EnterFrame
    //     0x11d0570: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0574: mov             fp, SP
    // 0x11d0578: AllocStack(0x18)
    //     0x11d0578: sub             SP, SP, #0x18
    // 0x11d057c: CheckStackOverflow
    //     0x11d057c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0580: cmp             SP, x16
    //     0x11d0584: b.ls            #0x11d05d8
    // 0x11d0588: LoadField: r3 = r1->field_f
    //     0x11d0588: ldur            w3, [x1, #0xf]
    // 0x11d058c: DecompressPointer r3
    //     0x11d058c: add             x3, x3, HEAP, lsl #32
    // 0x11d0590: stur            x3, [fp, #-0x18]
    // 0x11d0594: LoadField: r2 = r1->field_13
    //     0x11d0594: ldur            w2, [x1, #0x13]
    // 0x11d0598: DecompressPointer r2
    //     0x11d0598: add             x2, x2, HEAP, lsl #32
    // 0x11d059c: stur            x2, [fp, #-0x10]
    // 0x11d05a0: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x11d05a0: ldur            w5, [x1, #0x17]
    // 0x11d05a4: DecompressPointer r5
    //     0x11d05a4: add             x5, x5, HEAP, lsl #32
    // 0x11d05a8: stur            x5, [fp, #-8]
    // 0x11d05ac: r0 = RenderCustomPaint()
    //     0x11d05ac: bl              #0x11d06cc  ; AllocateRenderCustomPaintStub -> RenderCustomPaint (size=0x78)
    // 0x11d05b0: mov             x1, x0
    // 0x11d05b4: ldur            x2, [fp, #-0x10]
    // 0x11d05b8: ldur            x3, [fp, #-0x18]
    // 0x11d05bc: ldur            x5, [fp, #-8]
    // 0x11d05c0: stur            x0, [fp, #-8]
    // 0x11d05c4: r0 = RenderCustomPaint()
    //     0x11d05c4: bl              #0x11d05e0  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::RenderCustomPaint
    // 0x11d05c8: ldur            x0, [fp, #-8]
    // 0x11d05cc: LeaveFrame
    //     0x11d05cc: mov             SP, fp
    //     0x11d05d0: ldp             fp, lr, [SP], #0x10
    // 0x11d05d4: ret
    //     0x11d05d4: ret             
    // 0x11d05d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d05d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d05dc: b               #0x11d0588
  }
}

// class id: 6643, size: 0x28, field offset: 0x10
//   const constructor, 
class BackdropFilter extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf585c, size: 0xb4
    // 0xcf585c: EnterFrame
    //     0xcf585c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5860: mov             fp, SP
    // 0xcf5864: AllocStack(0x10)
    //     0xcf5864: sub             SP, SP, #0x10
    // 0xcf5868: SetupParameters(BackdropFilter this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf5868: mov             x4, x1
    //     0xcf586c: stur            x1, [fp, #-8]
    //     0xcf5870: stur            x3, [fp, #-0x10]
    // 0xcf5874: CheckStackOverflow
    //     0xcf5874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5878: cmp             SP, x16
    //     0xcf587c: b.ls            #0xcf5908
    // 0xcf5880: mov             x0, x3
    // 0xcf5884: r2 = Null
    //     0xcf5884: mov             x2, NULL
    // 0xcf5888: r1 = Null
    //     0xcf5888: mov             x1, NULL
    // 0xcf588c: r4 = 60
    //     0xcf588c: mov             x4, #0x3c
    // 0xcf5890: branchIfSmi(r0, 0xcf589c)
    //     0xcf5890: tbz             w0, #0, #0xcf589c
    // 0xcf5894: r4 = LoadClassIdInstr(r0)
    //     0xcf5894: ldur            x4, [x0, #-1]
    //     0xcf5898: ubfx            x4, x4, #0xc, #0x14
    // 0xcf589c: r17 = 4938
    //     0xcf589c: mov             x17, #0x134a
    // 0xcf58a0: cmp             x4, x17
    // 0xcf58a4: b.eq            #0xcf58bc
    // 0xcf58a8: r8 = RenderBackdropFilter
    //     0xcf58a8: add             x8, PP, #0x85, lsl #12  ; [pp+0x850b8] Type: RenderBackdropFilter
    //     0xcf58ac: ldr             x8, [x8, #0xb8]
    // 0xcf58b0: r3 = Null
    //     0xcf58b0: add             x3, PP, #0x85, lsl #12  ; [pp+0x850c0] Null
    //     0xcf58b4: ldr             x3, [x3, #0xc0]
    // 0xcf58b8: r0 = DefaultTypeTest()
    //     0xcf58b8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf58bc: ldur            x1, [fp, #-8]
    // 0xcf58c0: r0 = _effectiveFilterConfig()
    //     0xcf58c0: bl              #0xcf5ab8  ; [package:flutter/src/widgets/basic.dart] BackdropFilter::_effectiveFilterConfig
    // 0xcf58c4: ldur            x1, [fp, #-0x10]
    // 0xcf58c8: mov             x2, x0
    // 0xcf58cc: r0 = filterConfig=()
    //     0xcf58cc: bl              #0xcf5910  ; [package:flutter/src/rendering/proxy_box.dart] RenderBackdropFilter::filterConfig=
    // 0xcf58d0: ldur            x1, [fp, #-0x10]
    // 0xcf58d4: r2 = true
    //     0xcf58d4: add             x2, NULL, #0x20  ; true
    // 0xcf58d8: r0 = Shader._()
    //     0xcf58d8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf58dc: ldur            x1, [fp, #-0x10]
    // 0xcf58e0: r2 = Instance_BlendMode
    //     0xcf58e0: add             x2, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xcf58e4: ldr             x2, [x2, #0xeb8]
    // 0xcf58e8: r0 = Shader._()
    //     0xcf58e8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf58ec: ldur            x1, [fp, #-0x10]
    // 0xcf58f0: r2 = Null
    //     0xcf58f0: mov             x2, NULL
    // 0xcf58f4: r0 = Shader._()
    //     0xcf58f4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf58f8: r0 = Null
    //     0xcf58f8: mov             x0, NULL
    // 0xcf58fc: LeaveFrame
    //     0xcf58fc: mov             SP, fp
    //     0xcf5900: ldp             fp, lr, [SP], #0x10
    // 0xcf5904: ret
    //     0xcf5904: ret             
    // 0xcf5908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf590c: b               #0xcf5880
  }
  get _ _effectiveFilterConfig(/* No info */) {
    // ** addr: 0xcf5ab8, size: 0x4c
    // 0xcf5ab8: EnterFrame
    //     0xcf5ab8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5abc: mov             fp, SP
    // 0xcf5ac0: AllocStack(0x8)
    //     0xcf5ac0: sub             SP, SP, #8
    // 0xcf5ac4: LoadField: r0 = r1->field_13
    //     0xcf5ac4: ldur            w0, [x1, #0x13]
    // 0xcf5ac8: DecompressPointer r0
    //     0xcf5ac8: add             x0, x0, HEAP, lsl #32
    // 0xcf5acc: cmp             w0, NULL
    // 0xcf5ad0: b.ne            #0xcf5af4
    // 0xcf5ad4: LoadField: r0 = r1->field_f
    //     0xcf5ad4: ldur            w0, [x1, #0xf]
    // 0xcf5ad8: DecompressPointer r0
    //     0xcf5ad8: add             x0, x0, HEAP, lsl #32
    // 0xcf5adc: stur            x0, [fp, #-8]
    // 0xcf5ae0: cmp             w0, NULL
    // 0xcf5ae4: b.eq            #0xcf5b00
    // 0xcf5ae8: r0 = _DirectImageFilterConfig()
    //     0xcf5ae8: bl              #0xcf5b04  ; Allocate_DirectImageFilterConfigStub -> _DirectImageFilterConfig (size=0xc)
    // 0xcf5aec: ldur            x1, [fp, #-8]
    // 0xcf5af0: StoreField: r0->field_7 = r1
    //     0xcf5af0: stur            w1, [x0, #7]
    // 0xcf5af4: LeaveFrame
    //     0xcf5af4: mov             SP, fp
    //     0xcf5af8: ldp             fp, lr, [SP], #0x10
    // 0xcf5afc: ret
    //     0xcf5afc: ret             
    // 0xcf5b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf5b00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0438, size: 0x8c
    // 0x11d0438: EnterFrame
    //     0x11d0438: stp             fp, lr, [SP, #-0x10]!
    //     0x11d043c: mov             fp, SP
    // 0x11d0440: AllocStack(0x8)
    //     0x11d0440: sub             SP, SP, #8
    // 0x11d0444: CheckStackOverflow
    //     0x11d0444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0448: cmp             SP, x16
    //     0x11d044c: b.ls            #0x11d04b8
    // 0x11d0450: LoadField: r0 = r1->field_13
    //     0x11d0450: ldur            w0, [x1, #0x13]
    // 0x11d0454: DecompressPointer r0
    //     0x11d0454: add             x0, x0, HEAP, lsl #32
    // 0x11d0458: cmp             w0, NULL
    // 0x11d045c: b.ne            #0x11d048c
    // 0x11d0460: LoadField: r0 = r1->field_f
    //     0x11d0460: ldur            w0, [x1, #0xf]
    // 0x11d0464: DecompressPointer r0
    //     0x11d0464: add             x0, x0, HEAP, lsl #32
    // 0x11d0468: stur            x0, [fp, #-8]
    // 0x11d046c: cmp             w0, NULL
    // 0x11d0470: b.eq            #0x11d04c0
    // 0x11d0474: r0 = _DirectImageFilterConfig()
    //     0x11d0474: bl              #0xcf5b04  ; Allocate_DirectImageFilterConfigStub -> _DirectImageFilterConfig (size=0xc)
    // 0x11d0478: mov             x1, x0
    // 0x11d047c: ldur            x0, [fp, #-8]
    // 0x11d0480: StoreField: r1->field_7 = r0
    //     0x11d0480: stur            w0, [x1, #7]
    // 0x11d0484: mov             x2, x1
    // 0x11d0488: b               #0x11d0490
    // 0x11d048c: mov             x2, x0
    // 0x11d0490: stur            x2, [fp, #-8]
    // 0x11d0494: r0 = RenderBackdropFilter()
    //     0x11d0494: bl              #0x11d0564  ; AllocateRenderBackdropFilterStub -> RenderBackdropFilter (size=0x64)
    // 0x11d0498: mov             x1, x0
    // 0x11d049c: ldur            x2, [fp, #-8]
    // 0x11d04a0: stur            x0, [fp, #-8]
    // 0x11d04a4: r0 = RenderBackdropFilter()
    //     0x11d04a4: bl              #0x11d04c4  ; [package:flutter/src/rendering/proxy_box.dart] RenderBackdropFilter::RenderBackdropFilter
    // 0x11d04a8: ldur            x0, [fp, #-8]
    // 0x11d04ac: LeaveFrame
    //     0x11d04ac: mov             SP, fp
    //     0x11d04b0: ldp             fp, lr, [SP], #0x10
    // 0x11d04b4: ret
    //     0x11d04b4: ret             
    // 0x11d04b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d04b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d04bc: b               #0x11d0450
    // 0x11d04c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11d04c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6644, size: 0x18, field offset: 0x10
//   const constructor, 
class ShaderMask extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf56c4, size: 0xa0
    // 0xcf56c4: EnterFrame
    //     0xcf56c4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf56c8: mov             fp, SP
    // 0xcf56cc: AllocStack(0x10)
    //     0xcf56cc: sub             SP, SP, #0x10
    // 0xcf56d0: SetupParameters(ShaderMask this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf56d0: mov             x4, x1
    //     0xcf56d4: stur            x1, [fp, #-8]
    //     0xcf56d8: stur            x3, [fp, #-0x10]
    // 0xcf56dc: CheckStackOverflow
    //     0xcf56dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf56e0: cmp             SP, x16
    //     0xcf56e4: b.ls            #0xcf575c
    // 0xcf56e8: mov             x0, x3
    // 0xcf56ec: r2 = Null
    //     0xcf56ec: mov             x2, NULL
    // 0xcf56f0: r1 = Null
    //     0xcf56f0: mov             x1, NULL
    // 0xcf56f4: r4 = 60
    //     0xcf56f4: mov             x4, #0x3c
    // 0xcf56f8: branchIfSmi(r0, 0xcf5704)
    //     0xcf56f8: tbz             w0, #0, #0xcf5704
    // 0xcf56fc: r4 = LoadClassIdInstr(r0)
    //     0xcf56fc: ldur            x4, [x0, #-1]
    //     0xcf5700: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5704: r17 = 4939
    //     0xcf5704: mov             x17, #0x134b
    // 0xcf5708: cmp             x4, x17
    // 0xcf570c: b.eq            #0xcf5724
    // 0xcf5710: r8 = RenderShaderMask
    //     0xcf5710: add             x8, PP, #0x90, lsl #12  ; [pp+0x90300] Type: RenderShaderMask
    //     0xcf5714: ldr             x8, [x8, #0x300]
    // 0xcf5718: r3 = Null
    //     0xcf5718: add             x3, PP, #0x90, lsl #12  ; [pp+0x90308] Null
    //     0xcf571c: ldr             x3, [x3, #0x308]
    // 0xcf5720: r0 = DefaultTypeTest()
    //     0xcf5720: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf5724: ldur            x0, [fp, #-8]
    // 0xcf5728: LoadField: r2 = r0->field_f
    //     0xcf5728: ldur            w2, [x0, #0xf]
    // 0xcf572c: DecompressPointer r2
    //     0xcf572c: add             x2, x2, HEAP, lsl #32
    // 0xcf5730: ldur            x1, [fp, #-0x10]
    // 0xcf5734: r0 = shaderCallback=()
    //     0xcf5734: bl              #0xcf57d4  ; [package:flutter/src/rendering/proxy_box.dart] RenderShaderMask::shaderCallback=
    // 0xcf5738: ldur            x0, [fp, #-8]
    // 0xcf573c: LoadField: r2 = r0->field_13
    //     0xcf573c: ldur            w2, [x0, #0x13]
    // 0xcf5740: DecompressPointer r2
    //     0xcf5740: add             x2, x2, HEAP, lsl #32
    // 0xcf5744: ldur            x1, [fp, #-0x10]
    // 0xcf5748: r0 = blendMode=()
    //     0xcf5748: bl              #0xcf5764  ; [package:flutter/src/rendering/proxy_box.dart] RenderShaderMask::blendMode=
    // 0xcf574c: r0 = Null
    //     0xcf574c: mov             x0, NULL
    // 0xcf5750: LeaveFrame
    //     0xcf5750: mov             SP, fp
    //     0xcf5754: ldp             fp, lr, [SP], #0x10
    // 0xcf5758: ret
    //     0xcf5758: ret             
    // 0xcf575c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf575c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5760: b               #0xcf56e8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0314, size: 0x60
    // 0x11d0314: EnterFrame
    //     0x11d0314: stp             fp, lr, [SP, #-0x10]!
    //     0x11d0318: mov             fp, SP
    // 0x11d031c: AllocStack(0x10)
    //     0x11d031c: sub             SP, SP, #0x10
    // 0x11d0320: CheckStackOverflow
    //     0x11d0320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0324: cmp             SP, x16
    //     0x11d0328: b.ls            #0x11d036c
    // 0x11d032c: LoadField: r3 = r1->field_f
    //     0x11d032c: ldur            w3, [x1, #0xf]
    // 0x11d0330: DecompressPointer r3
    //     0x11d0330: add             x3, x3, HEAP, lsl #32
    // 0x11d0334: stur            x3, [fp, #-0x10]
    // 0x11d0338: LoadField: r2 = r1->field_13
    //     0x11d0338: ldur            w2, [x1, #0x13]
    // 0x11d033c: DecompressPointer r2
    //     0x11d033c: add             x2, x2, HEAP, lsl #32
    // 0x11d0340: stur            x2, [fp, #-8]
    // 0x11d0344: r0 = RenderShaderMask()
    //     0x11d0344: bl              #0x11d042c  ; AllocateRenderShaderMaskStub -> RenderShaderMask (size=0x5c)
    // 0x11d0348: mov             x1, x0
    // 0x11d034c: ldur            x2, [fp, #-8]
    // 0x11d0350: ldur            x3, [fp, #-0x10]
    // 0x11d0354: stur            x0, [fp, #-8]
    // 0x11d0358: r0 = RenderShaderMask()
    //     0x11d0358: bl              #0x11d0374  ; [package:flutter/src/rendering/proxy_box.dart] RenderShaderMask::RenderShaderMask
    // 0x11d035c: ldur            x0, [fp, #-8]
    // 0x11d0360: LeaveFrame
    //     0x11d0360: mov             SP, fp
    //     0x11d0364: ldp             fp, lr, [SP], #0x10
    // 0x11d0368: ret
    //     0x11d0368: ret             
    // 0x11d036c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d036c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0370: b               #0x11d032c
  }
}

// class id: 6645, size: 0x1c, field offset: 0x10
//   const constructor, 
class Opacity extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf5520, size: 0x98
    // 0xcf5520: EnterFrame
    //     0xcf5520: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5524: mov             fp, SP
    // 0xcf5528: AllocStack(0x10)
    //     0xcf5528: sub             SP, SP, #0x10
    // 0xcf552c: SetupParameters(Opacity this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf552c: mov             x4, x1
    //     0xcf5530: stur            x1, [fp, #-8]
    //     0xcf5534: stur            x3, [fp, #-0x10]
    // 0xcf5538: CheckStackOverflow
    //     0xcf5538: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf553c: cmp             SP, x16
    //     0xcf5540: b.ls            #0xcf55b0
    // 0xcf5544: mov             x0, x3
    // 0xcf5548: r2 = Null
    //     0xcf5548: mov             x2, NULL
    // 0xcf554c: r1 = Null
    //     0xcf554c: mov             x1, NULL
    // 0xcf5550: r4 = 60
    //     0xcf5550: mov             x4, #0x3c
    // 0xcf5554: branchIfSmi(r0, 0xcf5560)
    //     0xcf5554: tbz             w0, #0, #0xcf5560
    // 0xcf5558: r4 = LoadClassIdInstr(r0)
    //     0xcf5558: ldur            x4, [x0, #-1]
    //     0xcf555c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5560: r17 = -4940
    //     0xcf5560: mov             x17, #-0x134c
    // 0xcf5564: add             x4, x4, x17
    // 0xcf5568: cmp             x4, #2
    // 0xcf556c: b.ls            #0xcf5584
    // 0xcf5570: r8 = RenderOpacity
    //     0xcf5570: add             x8, PP, #0x90, lsl #12  ; [pp+0x90208] Type: RenderOpacity
    //     0xcf5574: ldr             x8, [x8, #0x208]
    // 0xcf5578: r3 = Null
    //     0xcf5578: add             x3, PP, #0x90, lsl #12  ; [pp+0x90210] Null
    //     0xcf557c: ldr             x3, [x3, #0x210]
    // 0xcf5580: r0 = DefaultTypeTest()
    //     0xcf5580: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf5584: ldur            x0, [fp, #-8]
    // 0xcf5588: LoadField: d0 = r0->field_f
    //     0xcf5588: ldur            d0, [x0, #0xf]
    // 0xcf558c: ldur            x1, [fp, #-0x10]
    // 0xcf5590: r0 = opacity=()
    //     0xcf5590: bl              #0xcf55b8  ; [package:flutter/src/rendering/proxy_box.dart] RenderOpacity::opacity=
    // 0xcf5594: ldur            x1, [fp, #-0x10]
    // 0xcf5598: r2 = false
    //     0xcf5598: add             x2, NULL, #0x30  ; false
    // 0xcf559c: r0 = Shader._()
    //     0xcf559c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf55a0: r0 = Null
    //     0xcf55a0: mov             x0, NULL
    // 0xcf55a4: LeaveFrame
    //     0xcf55a4: mov             SP, fp
    //     0xcf55a8: ldp             fp, lr, [SP], #0x10
    // 0xcf55ac: ret
    //     0xcf55ac: ret             
    // 0xcf55b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf55b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf55b4: b               #0xcf5544
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d0238, size: 0x4c
    // 0x11d0238: EnterFrame
    //     0x11d0238: stp             fp, lr, [SP, #-0x10]!
    //     0x11d023c: mov             fp, SP
    // 0x11d0240: AllocStack(0x10)
    //     0x11d0240: sub             SP, SP, #0x10
    // 0x11d0244: CheckStackOverflow
    //     0x11d0244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0248: cmp             SP, x16
    //     0x11d024c: b.ls            #0x11d027c
    // 0x11d0250: LoadField: d0 = r1->field_f
    //     0x11d0250: ldur            d0, [x1, #0xf]
    // 0x11d0254: stur            d0, [fp, #-0x10]
    // 0x11d0258: r0 = RenderOpacity()
    //     0x11d0258: bl              #0x11d0308  ; AllocateRenderOpacityStub -> RenderOpacity (size=0x68)
    // 0x11d025c: mov             x1, x0
    // 0x11d0260: ldur            d0, [fp, #-0x10]
    // 0x11d0264: stur            x0, [fp, #-8]
    // 0x11d0268: r0 = RenderOpacity()
    //     0x11d0268: bl              #0x11d0284  ; [package:flutter/src/rendering/proxy_box.dart] RenderOpacity::RenderOpacity
    // 0x11d026c: ldur            x0, [fp, #-8]
    // 0x11d0270: LeaveFrame
    //     0x11d0270: mov             SP, fp
    //     0x11d0274: ldp             fp, lr, [SP], #0x10
    // 0x11d0278: ret
    //     0x11d0278: ret             
    // 0x11d027c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d027c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0280: b               #0x11d0250
  }
}

// class id: 6686, size: 0x44, field offset: 0x10
class RichText extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcef5c8, size: 0x188
    // 0xcef5c8: EnterFrame
    //     0xcef5c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcef5cc: mov             fp, SP
    // 0xcef5d0: AllocStack(0x18)
    //     0xcef5d0: sub             SP, SP, #0x18
    // 0xcef5d4: SetupParameters(RichText this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcef5d4: mov             x5, x1
    //     0xcef5d8: mov             x4, x2
    //     0xcef5dc: stur            x1, [fp, #-8]
    //     0xcef5e0: stur            x2, [fp, #-0x10]
    //     0xcef5e4: stur            x3, [fp, #-0x18]
    // 0xcef5e8: CheckStackOverflow
    //     0xcef5e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef5ec: cmp             SP, x16
    //     0xcef5f0: b.ls            #0xcef748
    // 0xcef5f4: mov             x0, x3
    // 0xcef5f8: r2 = Null
    //     0xcef5f8: mov             x2, NULL
    // 0xcef5fc: r1 = Null
    //     0xcef5fc: mov             x1, NULL
    // 0xcef600: r4 = 60
    //     0xcef600: mov             x4, #0x3c
    // 0xcef604: branchIfSmi(r0, 0xcef610)
    //     0xcef604: tbz             w0, #0, #0xcef610
    // 0xcef608: r4 = LoadClassIdInstr(r0)
    //     0xcef608: ldur            x4, [x0, #-1]
    //     0xcef60c: ubfx            x4, x4, #0xc, #0x14
    // 0xcef610: r17 = 4814
    //     0xcef610: mov             x17, #0x12ce
    // 0xcef614: cmp             x4, x17
    // 0xcef618: b.eq            #0xcef630
    // 0xcef61c: r8 = RenderParagraph
    //     0xcef61c: add             x8, PP, #0x90, lsl #12  ; [pp+0x90318] Type: RenderParagraph
    //     0xcef620: ldr             x8, [x8, #0x318]
    // 0xcef624: r3 = Null
    //     0xcef624: add             x3, PP, #0x90, lsl #12  ; [pp+0x90320] Null
    //     0xcef628: ldr             x3, [x3, #0x320]
    // 0xcef62c: r0 = DefaultTypeTest()
    //     0xcef62c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcef630: ldur            x0, [fp, #-8]
    // 0xcef634: LoadField: r2 = r0->field_f
    //     0xcef634: ldur            w2, [x0, #0xf]
    // 0xcef638: DecompressPointer r2
    //     0xcef638: add             x2, x2, HEAP, lsl #32
    // 0xcef63c: ldur            x1, [fp, #-0x18]
    // 0xcef640: r0 = text=()
    //     0xcef640: bl              #0xcefc3c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::text=
    // 0xcef644: ldur            x0, [fp, #-8]
    // 0xcef648: LoadField: r2 = r0->field_13
    //     0xcef648: ldur            w2, [x0, #0x13]
    // 0xcef64c: DecompressPointer r2
    //     0xcef64c: add             x2, x2, HEAP, lsl #32
    // 0xcef650: ldur            x1, [fp, #-0x18]
    // 0xcef654: r0 = textAlign=()
    //     0xcef654: bl              #0xcefbd0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textAlign=
    // 0xcef658: ldur            x0, [fp, #-8]
    // 0xcef65c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcef65c: ldur            w1, [x0, #0x17]
    // 0xcef660: DecompressPointer r1
    //     0xcef660: add             x1, x1, HEAP, lsl #32
    // 0xcef664: cmp             w1, NULL
    // 0xcef668: b.ne            #0xcef67c
    // 0xcef66c: ldur            x1, [fp, #-0x10]
    // 0xcef670: r0 = of()
    //     0xcef670: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcef674: mov             x2, x0
    // 0xcef678: b               #0xcef680
    // 0xcef67c: mov             x2, x1
    // 0xcef680: ldur            x0, [fp, #-8]
    // 0xcef684: ldur            x1, [fp, #-0x18]
    // 0xcef688: r0 = textDirection=()
    //     0xcef688: bl              #0xcefb64  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textDirection=
    // 0xcef68c: ldur            x0, [fp, #-8]
    // 0xcef690: LoadField: r2 = r0->field_1b
    //     0xcef690: ldur            w2, [x0, #0x1b]
    // 0xcef694: DecompressPointer r2
    //     0xcef694: add             x2, x2, HEAP, lsl #32
    // 0xcef698: ldur            x1, [fp, #-0x18]
    // 0xcef69c: r0 = softWrap=()
    //     0xcef69c: bl              #0xcefb10  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::softWrap=
    // 0xcef6a0: ldur            x0, [fp, #-8]
    // 0xcef6a4: LoadField: r2 = r0->field_1f
    //     0xcef6a4: ldur            w2, [x0, #0x1f]
    // 0xcef6a8: DecompressPointer r2
    //     0xcef6a8: add             x2, x2, HEAP, lsl #32
    // 0xcef6ac: ldur            x1, [fp, #-0x18]
    // 0xcef6b0: r0 = overflow=()
    //     0xcef6b0: bl              #0xcefa5c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::overflow=
    // 0xcef6b4: ldur            x0, [fp, #-8]
    // 0xcef6b8: LoadField: r2 = r0->field_23
    //     0xcef6b8: ldur            w2, [x0, #0x23]
    // 0xcef6bc: DecompressPointer r2
    //     0xcef6bc: add             x2, x2, HEAP, lsl #32
    // 0xcef6c0: ldur            x1, [fp, #-0x18]
    // 0xcef6c4: r0 = textScaler=()
    //     0xcef6c4: bl              #0xcef9c4  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textScaler=
    // 0xcef6c8: ldur            x0, [fp, #-8]
    // 0xcef6cc: LoadField: r2 = r0->field_27
    //     0xcef6cc: ldur            w2, [x0, #0x27]
    // 0xcef6d0: DecompressPointer r2
    //     0xcef6d0: add             x2, x2, HEAP, lsl #32
    // 0xcef6d4: ldur            x1, [fp, #-0x18]
    // 0xcef6d8: r0 = maxLines=()
    //     0xcef6d8: bl              #0xcef91c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::maxLines=
    // 0xcef6dc: ldur            x1, [fp, #-0x18]
    // 0xcef6e0: r2 = Null
    //     0xcef6e0: mov             x2, NULL
    // 0xcef6e4: r0 = strutStyle=()
    //     0xcef6e4: bl              #0xcef888  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::strutStyle=
    // 0xcef6e8: ldur            x1, [fp, #-0x18]
    // 0xcef6ec: r2 = Instance_TextWidthBasis
    //     0xcef6ec: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xcef6f0: ldr             x2, [x2, #0x110]
    // 0xcef6f4: r0 = Shader._()
    //     0xcef6f4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcef6f8: ldur            x1, [fp, #-0x18]
    // 0xcef6fc: r2 = Null
    //     0xcef6fc: mov             x2, NULL
    // 0xcef700: r0 = Shader._()
    //     0xcef700: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcef704: ldur            x1, [fp, #-0x10]
    // 0xcef708: r0 = maybeLocaleOf()
    //     0xcef708: bl              #0x8d4664  ; [package:flutter/src/widgets/localizations.dart] Localizations::maybeLocaleOf
    // 0xcef70c: ldur            x1, [fp, #-0x18]
    // 0xcef710: mov             x2, x0
    // 0xcef714: r0 = locale=()
    //     0xcef714: bl              #0xcef7f0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::locale=
    // 0xcef718: ldur            x1, [fp, #-0x18]
    // 0xcef71c: r2 = Null
    //     0xcef71c: mov             x2, NULL
    // 0xcef720: r0 = Shader._()
    //     0xcef720: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcef724: ldur            x0, [fp, #-8]
    // 0xcef728: LoadField: r2 = r0->field_3f
    //     0xcef728: ldur            w2, [x0, #0x3f]
    // 0xcef72c: DecompressPointer r2
    //     0xcef72c: add             x2, x2, HEAP, lsl #32
    // 0xcef730: ldur            x1, [fp, #-0x18]
    // 0xcef734: r0 = selectionColor=()
    //     0xcef734: bl              #0xcef750  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::selectionColor=
    // 0xcef738: r0 = Null
    //     0xcef738: mov             x0, NULL
    // 0xcef73c: LeaveFrame
    //     0xcef73c: mov             SP, fp
    //     0xcef740: ldp             fp, lr, [SP], #0x10
    // 0xcef744: ret
    //     0xcef744: ret             
    // 0xcef748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef74c: b               #0xcef5f4
  }
  _ RichText(/* No info */) {
    // ** addr: 0xdd556c, size: 0x3c8
    // 0xdd556c: EnterFrame
    //     0xdd556c: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5570: mov             fp, SP
    // 0xdd5574: AllocStack(0x18)
    //     0xdd5574: sub             SP, SP, #0x18
    // 0xdd5578: SetupParameters(RichText this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic maxLines = Null /* r5 */, dynamic overflow = Instance_TextOverflow /* r6 */, dynamic selectionColor = Null /* r7 */, dynamic softWrap = true /* r8 */, dynamic textAlign = Instance_TextAlign /* r9 */, dynamic textDirection = Null /* r10 */, dynamic textScaler = Instance__LinearTextScaler /* r4, fp-0x8 */})
    //     0xdd5578: mov             x3, x1
    //     0xdd557c: stur            x1, [fp, #-0x10]
    //     0xdd5580: stur            x2, [fp, #-0x18]
    //     0xdd5584: ldur            w0, [x4, #0x13]
    //     0xdd5588: ldur            w1, [x4, #0x1f]
    //     0xdd558c: add             x1, x1, HEAP, lsl #32
    //     0xdd5590: ldr             x16, [PP, #0x4b68]  ; [pp+0x4b68] "maxLines"
    //     0xdd5594: cmp             w1, w16
    //     0xdd5598: b.ne            #0xdd55bc
    //     0xdd559c: ldur            w1, [x4, #0x23]
    //     0xdd55a0: add             x1, x1, HEAP, lsl #32
    //     0xdd55a4: sub             w5, w0, w1
    //     0xdd55a8: add             x1, fp, w5, sxtw #2
    //     0xdd55ac: ldr             x1, [x1, #8]
    //     0xdd55b0: mov             x5, x1
    //     0xdd55b4: mov             x1, #1
    //     0xdd55b8: b               #0xdd55c4
    //     0xdd55bc: mov             x5, NULL
    //     0xdd55c0: mov             x1, #0
    //     0xdd55c4: lsl             x6, x1, #1
    //     0xdd55c8: lsl             w7, w6, #1
    //     0xdd55cc: add             w8, w7, #8
    //     0xdd55d0: add             x16, x4, w8, sxtw #1
    //     0xdd55d4: ldur            w9, [x16, #0xf]
    //     0xdd55d8: add             x9, x9, HEAP, lsl #32
    //     0xdd55dc: ldr             x16, [PP, #0x6c28]  ; [pp+0x6c28] "overflow"
    //     0xdd55e0: cmp             w9, w16
    //     0xdd55e4: b.ne            #0xdd5618
    //     0xdd55e8: add             w1, w7, #0xa
    //     0xdd55ec: add             x16, x4, w1, sxtw #1
    //     0xdd55f0: ldur            w7, [x16, #0xf]
    //     0xdd55f4: add             x7, x7, HEAP, lsl #32
    //     0xdd55f8: sub             w1, w0, w7
    //     0xdd55fc: add             x7, fp, w1, sxtw #2
    //     0xdd5600: ldr             x7, [x7, #8]
    //     0xdd5604: add             w1, w6, #2
    //     0xdd5608: sbfx            x6, x1, #1, #0x1f
    //     0xdd560c: mov             x1, x6
    //     0xdd5610: mov             x6, x7
    //     0xdd5614: b               #0xdd5620
    //     0xdd5618: add             x6, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xdd561c: ldr             x6, [x6, #0x108]
    //     0xdd5620: lsl             x7, x1, #1
    //     0xdd5624: lsl             w8, w7, #1
    //     0xdd5628: add             w9, w8, #8
    //     0xdd562c: add             x16, x4, w9, sxtw #1
    //     0xdd5630: ldur            w10, [x16, #0xf]
    //     0xdd5634: add             x10, x10, HEAP, lsl #32
    //     0xdd5638: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cee8] "selectionColor"
    //     0xdd563c: ldr             x16, [x16, #0xee8]
    //     0xdd5640: cmp             w10, w16
    //     0xdd5644: b.ne            #0xdd5678
    //     0xdd5648: add             w1, w8, #0xa
    //     0xdd564c: add             x16, x4, w1, sxtw #1
    //     0xdd5650: ldur            w8, [x16, #0xf]
    //     0xdd5654: add             x8, x8, HEAP, lsl #32
    //     0xdd5658: sub             w1, w0, w8
    //     0xdd565c: add             x8, fp, w1, sxtw #2
    //     0xdd5660: ldr             x8, [x8, #8]
    //     0xdd5664: add             w1, w7, #2
    //     0xdd5668: sbfx            x7, x1, #1, #0x1f
    //     0xdd566c: mov             x1, x7
    //     0xdd5670: mov             x7, x8
    //     0xdd5674: b               #0xdd567c
    //     0xdd5678: mov             x7, NULL
    //     0xdd567c: lsl             x8, x1, #1
    //     0xdd5680: lsl             w9, w8, #1
    //     0xdd5684: add             w10, w9, #8
    //     0xdd5688: add             x16, x4, w10, sxtw #1
    //     0xdd568c: ldur            w11, [x16, #0xf]
    //     0xdd5690: add             x11, x11, HEAP, lsl #32
    //     0xdd5694: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cef0] "softWrap"
    //     0xdd5698: ldr             x16, [x16, #0xef0]
    //     0xdd569c: cmp             w11, w16
    //     0xdd56a0: b.ne            #0xdd56d4
    //     0xdd56a4: add             w1, w9, #0xa
    //     0xdd56a8: add             x16, x4, w1, sxtw #1
    //     0xdd56ac: ldur            w9, [x16, #0xf]
    //     0xdd56b0: add             x9, x9, HEAP, lsl #32
    //     0xdd56b4: sub             w1, w0, w9
    //     0xdd56b8: add             x9, fp, w1, sxtw #2
    //     0xdd56bc: ldr             x9, [x9, #8]
    //     0xdd56c0: add             w1, w8, #2
    //     0xdd56c4: sbfx            x8, x1, #1, #0x1f
    //     0xdd56c8: mov             x1, x8
    //     0xdd56cc: mov             x8, x9
    //     0xdd56d0: b               #0xdd56d8
    //     0xdd56d4: add             x8, NULL, #0x20  ; true
    //     0xdd56d8: lsl             x9, x1, #1
    //     0xdd56dc: lsl             w10, w9, #1
    //     0xdd56e0: add             w11, w10, #8
    //     0xdd56e4: add             x16, x4, w11, sxtw #1
    //     0xdd56e8: ldur            w12, [x16, #0xf]
    //     0xdd56ec: add             x12, x12, HEAP, lsl #32
    //     0xdd56f0: ldr             x16, [PP, #0x4b78]  ; [pp+0x4b78] "textAlign"
    //     0xdd56f4: cmp             w12, w16
    //     0xdd56f8: b.ne            #0xdd572c
    //     0xdd56fc: add             w1, w10, #0xa
    //     0xdd5700: add             x16, x4, w1, sxtw #1
    //     0xdd5704: ldur            w10, [x16, #0xf]
    //     0xdd5708: add             x10, x10, HEAP, lsl #32
    //     0xdd570c: sub             w1, w0, w10
    //     0xdd5710: add             x10, fp, w1, sxtw #2
    //     0xdd5714: ldr             x10, [x10, #8]
    //     0xdd5718: add             w1, w9, #2
    //     0xdd571c: sbfx            x9, x1, #1, #0x1f
    //     0xdd5720: mov             x1, x9
    //     0xdd5724: mov             x9, x10
    //     0xdd5728: b               #0xdd5730
    //     0xdd572c: ldr             x9, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    //     0xdd5730: lsl             x10, x1, #1
    //     0xdd5734: lsl             w11, w10, #1
    //     0xdd5738: add             w12, w11, #8
    //     0xdd573c: add             x16, x4, w12, sxtw #1
    //     0xdd5740: ldur            w13, [x16, #0xf]
    //     0xdd5744: add             x13, x13, HEAP, lsl #32
    //     0xdd5748: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0xdd574c: ldr             x16, [x16, #0x210]
    //     0xdd5750: cmp             w13, w16
    //     0xdd5754: b.ne            #0xdd5788
    //     0xdd5758: add             w1, w11, #0xa
    //     0xdd575c: add             x16, x4, w1, sxtw #1
    //     0xdd5760: ldur            w11, [x16, #0xf]
    //     0xdd5764: add             x11, x11, HEAP, lsl #32
    //     0xdd5768: sub             w1, w0, w11
    //     0xdd576c: add             x11, fp, w1, sxtw #2
    //     0xdd5770: ldr             x11, [x11, #8]
    //     0xdd5774: add             w1, w10, #2
    //     0xdd5778: sbfx            x10, x1, #1, #0x1f
    //     0xdd577c: mov             x1, x10
    //     0xdd5780: mov             x10, x11
    //     0xdd5784: b               #0xdd578c
    //     0xdd5788: mov             x10, NULL
    //     0xdd578c: lsl             x11, x1, #1
    //     0xdd5790: lsl             w1, w11, #1
    //     0xdd5794: add             w11, w1, #8
    //     0xdd5798: add             x16, x4, w11, sxtw #1
    //     0xdd579c: ldur            w12, [x16, #0xf]
    //     0xdd57a0: add             x12, x12, HEAP, lsl #32
    //     0xdd57a4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12840] "textScaler"
    //     0xdd57a8: ldr             x16, [x16, #0x840]
    //     0xdd57ac: cmp             w12, w16
    //     0xdd57b0: b.ne            #0xdd57d8
    //     0xdd57b4: add             w11, w1, #0xa
    //     0xdd57b8: add             x16, x4, w11, sxtw #1
    //     0xdd57bc: ldur            w1, [x16, #0xf]
    //     0xdd57c0: add             x1, x1, HEAP, lsl #32
    //     0xdd57c4: sub             w4, w0, w1
    //     0xdd57c8: add             x0, fp, w4, sxtw #2
    //     0xdd57cc: ldr             x0, [x0, #8]
    //     0xdd57d0: mov             x4, x0
    //     0xdd57d4: b               #0xdd57dc
    //     0xdd57d8: ldr             x4, [PP, #0x4a58]  ; [pp+0x4a58] Obj!_LinearTextScaler@129c641
    //     0xdd57dc: add             x1, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xdd57e0: ldr             x1, [x1, #0x110]
    //     0xdd57e4: stur            x4, [fp, #-8]
    // 0xdd57dc: r1 = Instance_TextWidthBasis
    // 0xdd57e8: CheckStackOverflow
    //     0xdd57e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd57ec: cmp             SP, x16
    //     0xdd57f0: b.ls            #0xdd592c
    // 0xdd57f4: mov             x0, x2
    // 0xdd57f8: StoreField: r3->field_f = r0
    //     0xdd57f8: stur            w0, [x3, #0xf]
    //     0xdd57fc: ldurb           w16, [x3, #-1]
    //     0xdd5800: ldurb           w17, [x0, #-1]
    //     0xdd5804: and             x16, x17, x16, lsr #2
    //     0xdd5808: tst             x16, HEAP, lsr #32
    //     0xdd580c: b.eq            #0xdd5814
    //     0xdd5810: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd5814: mov             x0, x9
    // 0xdd5818: StoreField: r3->field_13 = r0
    //     0xdd5818: stur            w0, [x3, #0x13]
    //     0xdd581c: ldurb           w16, [x3, #-1]
    //     0xdd5820: ldurb           w17, [x0, #-1]
    //     0xdd5824: and             x16, x17, x16, lsr #2
    //     0xdd5828: tst             x16, HEAP, lsr #32
    //     0xdd582c: b.eq            #0xdd5834
    //     0xdd5830: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd5834: mov             x0, x10
    // 0xdd5838: ArrayStore: r3[0] = r0  ; List_4
    //     0xdd5838: stur            w0, [x3, #0x17]
    //     0xdd583c: ldurb           w16, [x3, #-1]
    //     0xdd5840: ldurb           w17, [x0, #-1]
    //     0xdd5844: and             x16, x17, x16, lsr #2
    //     0xdd5848: tst             x16, HEAP, lsr #32
    //     0xdd584c: b.eq            #0xdd5854
    //     0xdd5850: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd5854: StoreField: r3->field_1b = r8
    //     0xdd5854: stur            w8, [x3, #0x1b]
    // 0xdd5858: mov             x0, x6
    // 0xdd585c: StoreField: r3->field_1f = r0
    //     0xdd585c: stur            w0, [x3, #0x1f]
    //     0xdd5860: ldurb           w16, [x3, #-1]
    //     0xdd5864: ldurb           w17, [x0, #-1]
    //     0xdd5868: and             x16, x17, x16, lsr #2
    //     0xdd586c: tst             x16, HEAP, lsr #32
    //     0xdd5870: b.eq            #0xdd5878
    //     0xdd5874: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd5878: mov             x0, x5
    // 0xdd587c: StoreField: r3->field_27 = r0
    //     0xdd587c: stur            w0, [x3, #0x27]
    //     0xdd5880: tbz             w0, #0, #0xdd589c
    //     0xdd5884: ldurb           w16, [x3, #-1]
    //     0xdd5888: ldurb           w17, [x0, #-1]
    //     0xdd588c: and             x16, x17, x16, lsr #2
    //     0xdd5890: tst             x16, HEAP, lsr #32
    //     0xdd5894: b.eq            #0xdd589c
    //     0xdd5898: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd589c: StoreField: r3->field_33 = r1
    //     0xdd589c: stur            w1, [x3, #0x33]
    // 0xdd58a0: mov             x0, x7
    // 0xdd58a4: StoreField: r3->field_3f = r0
    //     0xdd58a4: stur            w0, [x3, #0x3f]
    //     0xdd58a8: ldurb           w16, [x3, #-1]
    //     0xdd58ac: ldurb           w17, [x0, #-1]
    //     0xdd58b0: and             x16, x17, x16, lsr #2
    //     0xdd58b4: tst             x16, HEAP, lsr #32
    //     0xdd58b8: b.eq            #0xdd58c0
    //     0xdd58bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdd58c0: mov             x1, x4
    // 0xdd58c4: r0 = _effectiveTextScalerFrom()
    //     0xdd58c4: bl              #0xdd5934  ; [package:flutter/src/widgets/basic.dart] RichText::_effectiveTextScalerFrom
    // 0xdd58c8: ldur            x2, [fp, #-0x10]
    // 0xdd58cc: StoreField: r2->field_23 = r0
    //     0xdd58cc: stur            w0, [x2, #0x23]
    //     0xdd58d0: ldurb           w16, [x2, #-1]
    //     0xdd58d4: ldurb           w17, [x0, #-1]
    //     0xdd58d8: and             x16, x17, x16, lsr #2
    //     0xdd58dc: tst             x16, HEAP, lsr #32
    //     0xdd58e0: b.eq            #0xdd58e8
    //     0xdd58e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdd58e8: ldur            x1, [fp, #-8]
    // 0xdd58ec: r0 = _effectiveTextScalerFrom()
    //     0xdd58ec: bl              #0xdd5934  ; [package:flutter/src/widgets/basic.dart] RichText::_effectiveTextScalerFrom
    // 0xdd58f0: ldur            x1, [fp, #-0x18]
    // 0xdd58f4: mov             x2, x0
    // 0xdd58f8: r0 = extractFromInlineSpan()
    //     0xdd58f8: bl              #0xd61ef4  ; [package:flutter/src/widgets/widget_span.dart] WidgetSpan::extractFromInlineSpan
    // 0xdd58fc: ldur            x1, [fp, #-0x10]
    // 0xdd5900: StoreField: r1->field_b = r0
    //     0xdd5900: stur            w0, [x1, #0xb]
    //     0xdd5904: ldurb           w16, [x1, #-1]
    //     0xdd5908: ldurb           w17, [x0, #-1]
    //     0xdd590c: and             x16, x17, x16, lsr #2
    //     0xdd5910: tst             x16, HEAP, lsr #32
    //     0xdd5914: b.eq            #0xdd591c
    //     0xdd5918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd591c: r0 = Null
    //     0xdd591c: mov             x0, NULL
    // 0xdd5920: LeaveFrame
    //     0xdd5920: mov             SP, fp
    //     0xdd5924: ldp             fp, lr, [SP], #0x10
    // 0xdd5928: ret
    //     0xdd5928: ret             
    // 0xdd592c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd592c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd5930: b               #0xdd57f4
  }
  static _ _effectiveTextScalerFrom(/* No info */) {
    // ** addr: 0xdd5934, size: 0x6c
    // 0xdd5934: EnterFrame
    //     0xdd5934: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5938: mov             fp, SP
    // 0xdd593c: d0 = 1.000000
    //     0xdd593c: fmov            d0, #1.00000000
    // 0xdd5940: fcmp            d0, d0
    // 0xdd5944: b.ne            #0xdd5950
    // 0xdd5948: mov             x0, x1
    // 0xdd594c: b               #0xdd5994
    // 0xdd5950: r16 = Instance__LinearTextScaler
    //     0xdd5950: ldr             x16, [PP, #0x4a58]  ; [pp+0x4a58] Obj!_LinearTextScaler@129c641
    // 0xdd5954: cmp             w1, w16
    // 0xdd5958: b.eq            #0xdd5980
    // 0xdd595c: r0 = LoadClassIdInstr(r1)
    //     0xdd595c: ldur            x0, [x1, #-1]
    //     0xdd5960: ubfx            x0, x0, #0xc, #0x14
    // 0xdd5964: cmp             x0, #0xb50
    // 0xdd5968: b.ne            #0xdd5990
    // 0xdd596c: r0 = Instance__LinearTextScaler
    //     0xdd596c: ldr             x0, [PP, #0x4a58]  ; [pp+0x4a58] Obj!_LinearTextScaler@129c641
    // 0xdd5970: LoadField: d1 = r1->field_7
    //     0xdd5970: ldur            d1, [x1, #7]
    // 0xdd5974: LoadField: d2 = r0->field_7
    //     0xdd5974: ldur            d2, [x0, #7]
    // 0xdd5978: fcmp            d1, d2
    // 0xdd597c: b.ne            #0xdd5990
    // 0xdd5980: r0 = _LinearTextScaler()
    //     0xdd5980: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0xdd5984: d0 = 1.000000
    //     0xdd5984: fmov            d0, #1.00000000
    // 0xdd5988: StoreField: r0->field_7 = d0
    //     0xdd5988: stur            d0, [x0, #7]
    // 0xdd598c: b               #0xdd5994
    // 0xdd5990: mov             x0, x1
    // 0xdd5994: LeaveFrame
    //     0xdd5994: mov             SP, fp
    //     0xdd5998: ldp             fp, lr, [SP], #0x10
    // 0xdd599c: ret
    //     0xdd599c: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11caa10, size: 0x110
    // 0x11caa10: EnterFrame
    //     0x11caa10: stp             fp, lr, [SP, #-0x10]!
    //     0x11caa14: mov             fp, SP
    // 0x11caa18: AllocStack(0x70)
    //     0x11caa18: sub             SP, SP, #0x70
    // 0x11caa1c: SetupParameters(RichText this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x11caa1c: mov             x0, x2
    //     0x11caa20: stur            x2, [fp, #-0x20]
    //     0x11caa24: mov             x2, x1
    //     0x11caa28: stur            x1, [fp, #-0x18]
    // 0x11caa2c: CheckStackOverflow
    //     0x11caa2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11caa30: cmp             SP, x16
    //     0x11caa34: b.ls            #0x11cab18
    // 0x11caa38: LoadField: r3 = r2->field_f
    //     0x11caa38: ldur            w3, [x2, #0xf]
    // 0x11caa3c: DecompressPointer r3
    //     0x11caa3c: add             x3, x3, HEAP, lsl #32
    // 0x11caa40: stur            x3, [fp, #-0x10]
    // 0x11caa44: LoadField: r4 = r2->field_13
    //     0x11caa44: ldur            w4, [x2, #0x13]
    // 0x11caa48: DecompressPointer r4
    //     0x11caa48: add             x4, x4, HEAP, lsl #32
    // 0x11caa4c: stur            x4, [fp, #-8]
    // 0x11caa50: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x11caa50: ldur            w1, [x2, #0x17]
    // 0x11caa54: DecompressPointer r1
    //     0x11caa54: add             x1, x1, HEAP, lsl #32
    // 0x11caa58: cmp             w1, NULL
    // 0x11caa5c: b.ne            #0x11caa70
    // 0x11caa60: mov             x1, x0
    // 0x11caa64: r0 = of()
    //     0x11caa64: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11caa68: mov             x2, x0
    // 0x11caa6c: b               #0x11caa74
    // 0x11caa70: mov             x2, x1
    // 0x11caa74: ldur            x0, [fp, #-0x18]
    // 0x11caa78: stur            x2, [fp, #-0x48]
    // 0x11caa7c: LoadField: r3 = r0->field_1b
    //     0x11caa7c: ldur            w3, [x0, #0x1b]
    // 0x11caa80: DecompressPointer r3
    //     0x11caa80: add             x3, x3, HEAP, lsl #32
    // 0x11caa84: stur            x3, [fp, #-0x40]
    // 0x11caa88: LoadField: r6 = r0->field_1f
    //     0x11caa88: ldur            w6, [x0, #0x1f]
    // 0x11caa8c: DecompressPointer r6
    //     0x11caa8c: add             x6, x6, HEAP, lsl #32
    // 0x11caa90: stur            x6, [fp, #-0x38]
    // 0x11caa94: LoadField: r4 = r0->field_23
    //     0x11caa94: ldur            w4, [x0, #0x23]
    // 0x11caa98: DecompressPointer r4
    //     0x11caa98: add             x4, x4, HEAP, lsl #32
    // 0x11caa9c: stur            x4, [fp, #-0x30]
    // 0x11caaa0: LoadField: r5 = r0->field_27
    //     0x11caaa0: ldur            w5, [x0, #0x27]
    // 0x11caaa4: DecompressPointer r5
    //     0x11caaa4: add             x5, x5, HEAP, lsl #32
    // 0x11caaa8: ldur            x1, [fp, #-0x20]
    // 0x11caaac: stur            x5, [fp, #-0x28]
    // 0x11caab0: r0 = maybeLocaleOf()
    //     0x11caab0: bl              #0x8d4664  ; [package:flutter/src/widgets/localizations.dart] Localizations::maybeLocaleOf
    // 0x11caab4: mov             x1, x0
    // 0x11caab8: ldur            x0, [fp, #-0x18]
    // 0x11caabc: stur            x1, [fp, #-0x50]
    // 0x11caac0: LoadField: r7 = r0->field_3f
    //     0x11caac0: ldur            w7, [x0, #0x3f]
    // 0x11caac4: DecompressPointer r7
    //     0x11caac4: add             x7, x7, HEAP, lsl #32
    // 0x11caac8: stur            x7, [fp, #-0x20]
    // 0x11caacc: r0 = RenderParagraph()
    //     0x11caacc: bl              #0x11cacd8  ; AllocateRenderParagraphStub -> RenderParagraph (size=0x9c)
    // 0x11caad0: stur            x0, [fp, #-0x18]
    // 0x11caad4: ldur            x16, [fp, #-0x40]
    // 0x11caad8: ldur            lr, [fp, #-8]
    // 0x11caadc: stp             lr, x16, [SP, #0x10]
    // 0x11caae0: ldur            x16, [fp, #-0x48]
    // 0x11caae4: ldur            lr, [fp, #-0x30]
    // 0x11caae8: stp             lr, x16, [SP]
    // 0x11caaec: mov             x1, x0
    // 0x11caaf0: ldur            x2, [fp, #-0x10]
    // 0x11caaf4: ldur            x3, [fp, #-0x50]
    // 0x11caaf8: ldur            x5, [fp, #-0x28]
    // 0x11caafc: ldur            x6, [fp, #-0x38]
    // 0x11cab00: ldur            x7, [fp, #-0x20]
    // 0x11cab04: r0 = RenderParagraph()
    //     0x11cab04: bl              #0x11cab20  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::RenderParagraph
    // 0x11cab08: ldur            x0, [fp, #-0x18]
    // 0x11cab0c: LeaveFrame
    //     0x11cab0c: mov             SP, fp
    //     0x11cab10: ldp             fp, lr, [SP], #0x10
    // 0x11cab14: ret
    //     0x11cab14: ret             
    // 0x11cab18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cab18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cab1c: b               #0x11caa38
  }
}

// class id: 6687, size: 0x3c, field offset: 0x10
//   const constructor, 
class Wrap extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcef314, size: 0x124
    // 0xcef314: EnterFrame
    //     0xcef314: stp             fp, lr, [SP, #-0x10]!
    //     0xcef318: mov             fp, SP
    // 0xcef31c: AllocStack(0x18)
    //     0xcef31c: sub             SP, SP, #0x18
    // 0xcef320: SetupParameters(Wrap this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcef320: mov             x5, x1
    //     0xcef324: mov             x4, x2
    //     0xcef328: stur            x1, [fp, #-8]
    //     0xcef32c: stur            x2, [fp, #-0x10]
    //     0xcef330: stur            x3, [fp, #-0x18]
    // 0xcef334: CheckStackOverflow
    //     0xcef334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef338: cmp             SP, x16
    //     0xcef33c: b.ls            #0xcef430
    // 0xcef340: mov             x0, x3
    // 0xcef344: r2 = Null
    //     0xcef344: mov             x2, NULL
    // 0xcef348: r1 = Null
    //     0xcef348: mov             x1, NULL
    // 0xcef34c: r4 = 60
    //     0xcef34c: mov             x4, #0x3c
    // 0xcef350: branchIfSmi(r0, 0xcef35c)
    //     0xcef350: tbz             w0, #0, #0xcef35c
    // 0xcef354: r4 = LoadClassIdInstr(r0)
    //     0xcef354: ldur            x4, [x0, #-1]
    //     0xcef358: ubfx            x4, x4, #0xc, #0x14
    // 0xcef35c: r17 = 4806
    //     0xcef35c: mov             x17, #0x12c6
    // 0xcef360: cmp             x4, x17
    // 0xcef364: b.eq            #0xcef37c
    // 0xcef368: r8 = RenderWrap
    //     0xcef368: add             x8, PP, #0x84, lsl #12  ; [pp+0x84fb0] Type: RenderWrap
    //     0xcef36c: ldr             x8, [x8, #0xfb0]
    // 0xcef370: r3 = Null
    //     0xcef370: add             x3, PP, #0x84, lsl #12  ; [pp+0x84fb8] Null
    //     0xcef374: ldr             x3, [x3, #0xfb8]
    // 0xcef378: r0 = DefaultTypeTest()
    //     0xcef378: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcef37c: ldur            x0, [fp, #-8]
    // 0xcef380: LoadField: r2 = r0->field_f
    //     0xcef380: ldur            w2, [x0, #0xf]
    // 0xcef384: DecompressPointer r2
    //     0xcef384: add             x2, x2, HEAP, lsl #32
    // 0xcef388: ldur            x1, [fp, #-0x18]
    // 0xcef38c: r0 = textDirection=()
    //     0xcef38c: bl              #0xcde458  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::textDirection=
    // 0xcef390: ldur            x0, [fp, #-8]
    // 0xcef394: LoadField: r2 = r0->field_13
    //     0xcef394: ldur            w2, [x0, #0x13]
    // 0xcef398: DecompressPointer r2
    //     0xcef398: add             x2, x2, HEAP, lsl #32
    // 0xcef39c: ldur            x1, [fp, #-0x18]
    // 0xcef3a0: r0 = titleBaselineType=()
    //     0xcef3a0: bl              #0xcde3e8  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::titleBaselineType=
    // 0xcef3a4: ldur            x0, [fp, #-8]
    // 0xcef3a8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcef3a8: ldur            d0, [x0, #0x17]
    // 0xcef3ac: ldur            x1, [fp, #-0x18]
    // 0xcef3b0: r0 = spacing=()
    //     0xcef3b0: bl              #0xcef578  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::spacing=
    // 0xcef3b4: ldur            x0, [fp, #-8]
    // 0xcef3b8: LoadField: r2 = r0->field_1f
    //     0xcef3b8: ldur            w2, [x0, #0x1f]
    // 0xcef3bc: DecompressPointer r2
    //     0xcef3bc: add             x2, x2, HEAP, lsl #32
    // 0xcef3c0: ldur            x1, [fp, #-0x18]
    // 0xcef3c4: r0 = runAlignment=()
    //     0xcef3c4: bl              #0xcef508  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::runAlignment=
    // 0xcef3c8: ldur            x0, [fp, #-8]
    // 0xcef3cc: LoadField: d0 = r0->field_23
    //     0xcef3cc: ldur            d0, [x0, #0x23]
    // 0xcef3d0: ldur            x1, [fp, #-0x18]
    // 0xcef3d4: r0 = minVerticalPadding=()
    //     0xcef3d4: bl              #0xcde1e4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minVerticalPadding=
    // 0xcef3d8: ldur            x0, [fp, #-8]
    // 0xcef3dc: LoadField: r2 = r0->field_2b
    //     0xcef3dc: ldur            w2, [x0, #0x2b]
    // 0xcef3e0: DecompressPointer r2
    //     0xcef3e0: add             x2, x2, HEAP, lsl #32
    // 0xcef3e4: ldur            x1, [fp, #-0x18]
    // 0xcef3e8: r0 = textDirection=()
    //     0xcef3e8: bl              #0xcef498  ; [package:flutter/src/widgets/overflow_bar.dart] _RenderOverflowBar::textDirection=
    // 0xcef3ec: ldur            x1, [fp, #-0x10]
    // 0xcef3f0: r0 = maybeOf()
    //     0xcef3f0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcef3f4: ldur            x1, [fp, #-0x18]
    // 0xcef3f8: mov             x2, x0
    // 0xcef3fc: r0 = textDirection=()
    //     0xcef3fc: bl              #0xcef438  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::textDirection=
    // 0xcef400: ldur            x1, [fp, #-0x18]
    // 0xcef404: r2 = Instance_VerticalDirection
    //     0xcef404: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xcef408: ldr             x2, [x2, #0x838]
    // 0xcef40c: r0 = Shader._()
    //     0xcef40c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcef410: ldur            x1, [fp, #-0x18]
    // 0xcef414: r2 = Instance_Clip
    //     0xcef414: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xcef418: ldr             x2, [x2, #0x840]
    // 0xcef41c: r0 = Shader._()
    //     0xcef41c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcef420: r0 = Null
    //     0xcef420: mov             x0, NULL
    // 0xcef424: LeaveFrame
    //     0xcef424: mov             SP, fp
    //     0xcef428: ldp             fp, lr, [SP], #0x10
    // 0xcef42c: ret
    //     0xcef42c: ret             
    // 0xcef430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef434: b               #0xcef340
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca7c8, size: 0xac
    // 0x11ca7c8: EnterFrame
    //     0x11ca7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca7cc: mov             fp, SP
    // 0x11ca7d0: AllocStack(0x38)
    //     0x11ca7d0: sub             SP, SP, #0x38
    // 0x11ca7d4: SetupParameters(Wrap this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11ca7d4: mov             x0, x1
    //     0x11ca7d8: mov             x1, x2
    // 0x11ca7dc: CheckStackOverflow
    //     0x11ca7dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca7e0: cmp             SP, x16
    //     0x11ca7e4: b.ls            #0x11ca86c
    // 0x11ca7e8: LoadField: r5 = r0->field_f
    //     0x11ca7e8: ldur            w5, [x0, #0xf]
    // 0x11ca7ec: DecompressPointer r5
    //     0x11ca7ec: add             x5, x5, HEAP, lsl #32
    // 0x11ca7f0: stur            x5, [fp, #-0x20]
    // 0x11ca7f4: LoadField: r2 = r0->field_13
    //     0x11ca7f4: ldur            w2, [x0, #0x13]
    // 0x11ca7f8: DecompressPointer r2
    //     0x11ca7f8: add             x2, x2, HEAP, lsl #32
    // 0x11ca7fc: stur            x2, [fp, #-0x18]
    // 0x11ca800: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x11ca800: ldur            d1, [x0, #0x17]
    // 0x11ca804: stur            d1, [fp, #-0x38]
    // 0x11ca808: LoadField: r6 = r0->field_1f
    //     0x11ca808: ldur            w6, [x0, #0x1f]
    // 0x11ca80c: DecompressPointer r6
    //     0x11ca80c: add             x6, x6, HEAP, lsl #32
    // 0x11ca810: stur            x6, [fp, #-0x10]
    // 0x11ca814: LoadField: d0 = r0->field_23
    //     0x11ca814: ldur            d0, [x0, #0x23]
    // 0x11ca818: stur            d0, [fp, #-0x30]
    // 0x11ca81c: LoadField: r3 = r0->field_2b
    //     0x11ca81c: ldur            w3, [x0, #0x2b]
    // 0x11ca820: DecompressPointer r3
    //     0x11ca820: add             x3, x3, HEAP, lsl #32
    // 0x11ca824: stur            x3, [fp, #-8]
    // 0x11ca828: r0 = maybeOf()
    //     0x11ca828: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11ca82c: stur            x0, [fp, #-0x28]
    // 0x11ca830: r0 = RenderWrap()
    //     0x11ca830: bl              #0x11caa04  ; AllocateRenderWrapStub -> RenderWrap (size=0x94)
    // 0x11ca834: mov             x1, x0
    // 0x11ca838: ldur            x2, [fp, #-0x18]
    // 0x11ca83c: ldur            x3, [fp, #-8]
    // 0x11ca840: ldur            x5, [fp, #-0x20]
    // 0x11ca844: ldur            x6, [fp, #-0x10]
    // 0x11ca848: ldur            d0, [fp, #-0x30]
    // 0x11ca84c: ldur            d1, [fp, #-0x38]
    // 0x11ca850: ldur            x7, [fp, #-0x28]
    // 0x11ca854: stur            x0, [fp, #-8]
    // 0x11ca858: r0 = RenderWrap()
    //     0x11ca858: bl              #0x11ca874  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::RenderWrap
    // 0x11ca85c: ldur            x0, [fp, #-8]
    // 0x11ca860: LeaveFrame
    //     0x11ca860: mov             SP, fp
    //     0x11ca864: ldp             fp, lr, [SP], #0x10
    // 0x11ca868: ret
    //     0x11ca868: ret             
    // 0x11ca86c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca86c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca870: b               #0x11ca7e8
  }
}

// class id: 6688, size: 0x20, field offset: 0x10
//   const constructor, 
class Stack extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcef240, size: 0xd4
    // 0xcef240: EnterFrame
    //     0xcef240: stp             fp, lr, [SP, #-0x10]!
    //     0xcef244: mov             fp, SP
    // 0xcef248: AllocStack(0x18)
    //     0xcef248: sub             SP, SP, #0x18
    // 0xcef24c: SetupParameters(Stack this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcef24c: mov             x5, x1
    //     0xcef250: mov             x4, x2
    //     0xcef254: stur            x1, [fp, #-8]
    //     0xcef258: stur            x2, [fp, #-0x10]
    //     0xcef25c: stur            x3, [fp, #-0x18]
    // 0xcef260: CheckStackOverflow
    //     0xcef260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef264: cmp             SP, x16
    //     0xcef268: b.ls            #0xcef30c
    // 0xcef26c: mov             x0, x3
    // 0xcef270: r2 = Null
    //     0xcef270: mov             x2, NULL
    // 0xcef274: r1 = Null
    //     0xcef274: mov             x1, NULL
    // 0xcef278: r4 = 60
    //     0xcef278: mov             x4, #0x3c
    // 0xcef27c: branchIfSmi(r0, 0xcef288)
    //     0xcef27c: tbz             w0, #0, #0xcef288
    // 0xcef280: r4 = LoadClassIdInstr(r0)
    //     0xcef280: ldur            x4, [x0, #-1]
    //     0xcef284: ubfx            x4, x4, #0xc, #0x14
    // 0xcef288: r17 = -4823
    //     0xcef288: mov             x17, #-0x12d7
    // 0xcef28c: add             x4, x4, x17
    // 0xcef290: cmp             x4, #7
    // 0xcef294: b.ls            #0xcef2ac
    // 0xcef298: r8 = RenderStack
    //     0xcef298: add             x8, PP, #0x85, lsl #12  ; [pp+0x85028] Type: RenderStack
    //     0xcef29c: ldr             x8, [x8, #0x28]
    // 0xcef2a0: r3 = Null
    //     0xcef2a0: add             x3, PP, #0x85, lsl #12  ; [pp+0x85030] Null
    //     0xcef2a4: ldr             x3, [x3, #0x30]
    // 0xcef2a8: r0 = DefaultTypeTest()
    //     0xcef2a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcef2ac: ldur            x0, [fp, #-8]
    // 0xcef2b0: LoadField: r2 = r0->field_f
    //     0xcef2b0: ldur            w2, [x0, #0xf]
    // 0xcef2b4: DecompressPointer r2
    //     0xcef2b4: add             x2, x2, HEAP, lsl #32
    // 0xcef2b8: ldur            x1, [fp, #-0x18]
    // 0xcef2bc: r0 = alignment=()
    //     0xcef2bc: bl              #0xcef0a4  ; [package:flutter/src/rendering/stack.dart] RenderStack::alignment=
    // 0xcef2c0: ldur            x1, [fp, #-0x10]
    // 0xcef2c4: r0 = maybeOf()
    //     0xcef2c4: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcef2c8: ldur            x1, [fp, #-0x18]
    // 0xcef2cc: mov             x2, x0
    // 0xcef2d0: r0 = textDirection=()
    //     0xcef2d0: bl              #0xcef000  ; [package:flutter/src/rendering/stack.dart] RenderStack::textDirection=
    // 0xcef2d4: ldur            x0, [fp, #-8]
    // 0xcef2d8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcef2d8: ldur            w2, [x0, #0x17]
    // 0xcef2dc: DecompressPointer r2
    //     0xcef2dc: add             x2, x2, HEAP, lsl #32
    // 0xcef2e0: ldur            x1, [fp, #-0x18]
    // 0xcef2e4: r0 = crossAxisAlignment=()
    //     0xcef2e4: bl              #0xcee878  ; [package:flutter/src/rendering/flex.dart] RenderFlex::crossAxisAlignment=
    // 0xcef2e8: ldur            x0, [fp, #-8]
    // 0xcef2ec: LoadField: r2 = r0->field_1b
    //     0xcef2ec: ldur            w2, [x0, #0x1b]
    // 0xcef2f0: DecompressPointer r2
    //     0xcef2f0: add             x2, x2, HEAP, lsl #32
    // 0xcef2f4: ldur            x1, [fp, #-0x18]
    // 0xcef2f8: r0 = clipBehavior=()
    //     0xcef2f8: bl              #0xcef12c  ; [package:flutter/src/rendering/stack.dart] RenderStack::clipBehavior=
    // 0xcef2fc: r0 = Null
    //     0xcef2fc: mov             x0, NULL
    // 0xcef300: LeaveFrame
    //     0xcef300: mov             SP, fp
    //     0xcef304: ldp             fp, lr, [SP], #0x10
    // 0xcef308: ret
    //     0xcef308: ret             
    // 0xcef30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef30c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef310: b               #0xcef26c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca72c, size: 0x90
    // 0x11ca72c: EnterFrame
    //     0x11ca72c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca730: mov             fp, SP
    // 0x11ca734: AllocStack(0x28)
    //     0x11ca734: sub             SP, SP, #0x28
    // 0x11ca738: SetupParameters(Stack this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x11ca738: mov             x0, x1
    //     0x11ca73c: stur            x1, [fp, #-0x10]
    //     0x11ca740: mov             x1, x2
    // 0x11ca744: CheckStackOverflow
    //     0x11ca744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca748: cmp             SP, x16
    //     0x11ca74c: b.ls            #0x11ca7b4
    // 0x11ca750: LoadField: r2 = r0->field_f
    //     0x11ca750: ldur            w2, [x0, #0xf]
    // 0x11ca754: DecompressPointer r2
    //     0x11ca754: add             x2, x2, HEAP, lsl #32
    // 0x11ca758: stur            x2, [fp, #-8]
    // 0x11ca75c: r0 = maybeOf()
    //     0x11ca75c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11ca760: mov             x1, x0
    // 0x11ca764: ldur            x0, [fp, #-0x10]
    // 0x11ca768: stur            x1, [fp, #-0x28]
    // 0x11ca76c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11ca76c: ldur            w5, [x0, #0x17]
    // 0x11ca770: DecompressPointer r5
    //     0x11ca770: add             x5, x5, HEAP, lsl #32
    // 0x11ca774: stur            x5, [fp, #-0x20]
    // 0x11ca778: LoadField: r3 = r0->field_1b
    //     0x11ca778: ldur            w3, [x0, #0x1b]
    // 0x11ca77c: DecompressPointer r3
    //     0x11ca77c: add             x3, x3, HEAP, lsl #32
    // 0x11ca780: stur            x3, [fp, #-0x18]
    // 0x11ca784: r0 = RenderStack()
    //     0x11ca784: bl              #0x11ca7bc  ; AllocateRenderStackStub -> RenderStack (size=0x7c)
    // 0x11ca788: mov             x1, x0
    // 0x11ca78c: ldur            x2, [fp, #-8]
    // 0x11ca790: ldur            x3, [fp, #-0x18]
    // 0x11ca794: ldur            x5, [fp, #-0x20]
    // 0x11ca798: ldur            x6, [fp, #-0x28]
    // 0x11ca79c: stur            x0, [fp, #-8]
    // 0x11ca7a0: r0 = RenderStack()
    //     0x11ca7a0: bl              #0x11ca5e8  ; [package:flutter/src/rendering/stack.dart] RenderStack::RenderStack
    // 0x11ca7a4: ldur            x0, [fp, #-8]
    // 0x11ca7a8: LeaveFrame
    //     0x11ca7a8: mov             SP, fp
    //     0x11ca7ac: ldp             fp, lr, [SP], #0x10
    // 0x11ca7b0: ret
    //     0x11ca7b0: ret             
    // 0x11ca7b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca7b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca7b8: b               #0x11ca750
  }
}

// class id: 6689, size: 0x24, field offset: 0x20
//   const constructor, 
class _RawIndexedStack extends Stack {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xceeec0, size: 0x140
    // 0xceeec0: EnterFrame
    //     0xceeec0: stp             fp, lr, [SP, #-0x10]!
    //     0xceeec4: mov             fp, SP
    // 0xceeec8: AllocStack(0x18)
    //     0xceeec8: sub             SP, SP, #0x18
    // 0xceeecc: SetupParameters(_RawIndexedStack this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xceeecc: mov             x5, x1
    //     0xceeed0: mov             x4, x2
    //     0xceeed4: stur            x1, [fp, #-8]
    //     0xceeed8: stur            x2, [fp, #-0x10]
    //     0xceeedc: stur            x3, [fp, #-0x18]
    // 0xceeee0: CheckStackOverflow
    //     0xceeee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceeee4: cmp             SP, x16
    //     0xceeee8: b.ls            #0xceeff8
    // 0xceeeec: mov             x0, x3
    // 0xceeef0: r2 = Null
    //     0xceeef0: mov             x2, NULL
    // 0xceeef4: r1 = Null
    //     0xceeef4: mov             x1, NULL
    // 0xceeef8: r4 = 60
    //     0xceeef8: mov             x4, #0x3c
    // 0xceeefc: branchIfSmi(r0, 0xceef08)
    //     0xceeefc: tbz             w0, #0, #0xceef08
    // 0xceef00: r4 = LoadClassIdInstr(r0)
    //     0xceef00: ldur            x4, [x0, #-1]
    //     0xceef04: ubfx            x4, x4, #0xc, #0x14
    // 0xceef08: r17 = 4824
    //     0xceef08: mov             x17, #0x12d8
    // 0xceef0c: cmp             x4, x17
    // 0xceef10: b.eq            #0xceef28
    // 0xceef14: r8 = RenderIndexedStack
    //     0xceef14: add             x8, PP, #0x90, lsl #12  ; [pp+0x902b8] Type: RenderIndexedStack
    //     0xceef18: ldr             x8, [x8, #0x2b8]
    // 0xceef1c: r3 = Null
    //     0xceef1c: add             x3, PP, #0x90, lsl #12  ; [pp+0x902c0] Null
    //     0xceef20: ldr             x3, [x3, #0x2c0]
    // 0xceef24: r0 = DefaultTypeTest()
    //     0xceef24: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xceef28: ldur            x0, [fp, #-8]
    // 0xceef2c: LoadField: r2 = r0->field_1f
    //     0xceef2c: ldur            w2, [x0, #0x1f]
    // 0xceef30: DecompressPointer r2
    //     0xceef30: add             x2, x2, HEAP, lsl #32
    // 0xceef34: ldur            x1, [fp, #-0x18]
    // 0xceef38: r0 = index=()
    //     0xceef38: bl              #0xcef1a4  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::index=
    // 0xceef3c: ldur            x2, [fp, #-8]
    // 0xceef40: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xceef40: ldur            w0, [x2, #0x17]
    // 0xceef44: DecompressPointer r0
    //     0xceef44: add             x0, x0, HEAP, lsl #32
    // 0xceef48: ldur            x3, [fp, #-0x18]
    // 0xceef4c: LoadField: r1 = r3->field_6f
    //     0xceef4c: ldur            w1, [x3, #0x6f]
    // 0xceef50: DecompressPointer r1
    //     0xceef50: add             x1, x1, HEAP, lsl #32
    // 0xceef54: cmp             w1, w0
    // 0xceef58: b.eq            #0xceef80
    // 0xceef5c: StoreField: r3->field_6f = r0
    //     0xceef5c: stur            w0, [x3, #0x6f]
    //     0xceef60: ldurb           w16, [x3, #-1]
    //     0xceef64: ldurb           w17, [x0, #-1]
    //     0xceef68: and             x16, x17, x16, lsr #2
    //     0xceef6c: tst             x16, HEAP, lsr #32
    //     0xceef70: b.eq            #0xceef78
    //     0xceef74: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xceef78: mov             x1, x3
    // 0xceef7c: r0 = markNeedsLayout()
    //     0xceef7c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xceef80: ldur            x0, [fp, #-8]
    // 0xceef84: ldur            x3, [fp, #-0x18]
    // 0xceef88: LoadField: r2 = r0->field_1b
    //     0xceef88: ldur            w2, [x0, #0x1b]
    // 0xceef8c: DecompressPointer r2
    //     0xceef8c: add             x2, x2, HEAP, lsl #32
    // 0xceef90: mov             x1, x3
    // 0xceef94: r0 = clipBehavior=()
    //     0xceef94: bl              #0xcef12c  ; [package:flutter/src/rendering/stack.dart] RenderStack::clipBehavior=
    // 0xceef98: ldur            x0, [fp, #-8]
    // 0xceef9c: LoadField: r2 = r0->field_f
    //     0xceef9c: ldur            w2, [x0, #0xf]
    // 0xceefa0: DecompressPointer r2
    //     0xceefa0: add             x2, x2, HEAP, lsl #32
    // 0xceefa4: ldur            x1, [fp, #-0x18]
    // 0xceefa8: r0 = alignment=()
    //     0xceefa8: bl              #0xcef0a4  ; [package:flutter/src/rendering/stack.dart] RenderStack::alignment=
    // 0xceefac: ldur            x1, [fp, #-0x10]
    // 0xceefb0: r0 = maybeOf()
    //     0xceefb0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xceefb4: ldur            x1, [fp, #-0x18]
    // 0xceefb8: LoadField: r2 = r1->field_6b
    //     0xceefb8: ldur            w2, [x1, #0x6b]
    // 0xceefbc: DecompressPointer r2
    //     0xceefbc: add             x2, x2, HEAP, lsl #32
    // 0xceefc0: cmp             w2, w0
    // 0xceefc4: b.eq            #0xceefe8
    // 0xceefc8: StoreField: r1->field_6b = r0
    //     0xceefc8: stur            w0, [x1, #0x6b]
    //     0xceefcc: ldurb           w16, [x1, #-1]
    //     0xceefd0: ldurb           w17, [x0, #-1]
    //     0xceefd4: and             x16, x17, x16, lsr #2
    //     0xceefd8: tst             x16, HEAP, lsr #32
    //     0xceefdc: b.eq            #0xceefe4
    //     0xceefe0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xceefe4: r0 = _markNeedResolution()
    //     0xceefe4: bl              #0xcef070  ; [package:flutter/src/rendering/stack.dart] RenderStack::_markNeedResolution
    // 0xceefe8: r0 = Null
    //     0xceefe8: mov             x0, NULL
    // 0xceefec: LeaveFrame
    //     0xceefec: mov             SP, fp
    //     0xceeff0: ldp             fp, lr, [SP], #0x10
    // 0xceeff4: ret
    //     0xceeff4: ret             
    // 0xceeff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeffc: b               #0xceeeec
  }
  _ createElement(/* No info */) {
    // ** addr: 0x10f2028, size: 0x4c
    // 0x10f2028: EnterFrame
    //     0x10f2028: stp             fp, lr, [SP, #-0x10]!
    //     0x10f202c: mov             fp, SP
    // 0x10f2030: AllocStack(0x8)
    //     0x10f2030: sub             SP, SP, #8
    // 0x10f2034: SetupParameters(_RawIndexedStack this /* r1 => r2, fp-0x8 */)
    //     0x10f2034: mov             x2, x1
    //     0x10f2038: stur            x1, [fp, #-8]
    // 0x10f203c: CheckStackOverflow
    //     0x10f203c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2040: cmp             SP, x16
    //     0x10f2044: b.ls            #0x10f206c
    // 0x10f2048: r0 = _IndexedStackElement()
    //     0x10f2048: bl              #0x10f2074  ; Allocate_IndexedStackElementStub -> _IndexedStackElement (size=0x4c)
    // 0x10f204c: mov             x1, x0
    // 0x10f2050: ldur            x2, [fp, #-8]
    // 0x10f2054: stur            x0, [fp, #-8]
    // 0x10f2058: r0 = MultiChildRenderObjectElement()
    //     0x10f2058: bl              #0x10f1ecc  ; [package:flutter/src/widgets/framework.dart] MultiChildRenderObjectElement::MultiChildRenderObjectElement
    // 0x10f205c: ldur            x0, [fp, #-8]
    // 0x10f2060: LeaveFrame
    //     0x10f2060: mov             SP, fp
    //     0x10f2064: ldp             fp, lr, [SP], #0x10
    // 0x10f2068: ret
    //     0x10f2068: ret             
    // 0x10f206c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f206c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f2070: b               #0x10f2048
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca54c, size: 0x9c
    // 0x11ca54c: EnterFrame
    //     0x11ca54c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca550: mov             fp, SP
    // 0x11ca554: AllocStack(0x30)
    //     0x11ca554: sub             SP, SP, #0x30
    // 0x11ca558: SetupParameters(_RawIndexedStack this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11ca558: mov             x0, x1
    //     0x11ca55c: mov             x1, x2
    // 0x11ca560: CheckStackOverflow
    //     0x11ca560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca564: cmp             SP, x16
    //     0x11ca568: b.ls            #0x11ca5e0
    // 0x11ca56c: LoadField: r2 = r0->field_1f
    //     0x11ca56c: ldur            w2, [x0, #0x1f]
    // 0x11ca570: DecompressPointer r2
    //     0x11ca570: add             x2, x2, HEAP, lsl #32
    // 0x11ca574: stur            x2, [fp, #-0x20]
    // 0x11ca578: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11ca578: ldur            w5, [x0, #0x17]
    // 0x11ca57c: DecompressPointer r5
    //     0x11ca57c: add             x5, x5, HEAP, lsl #32
    // 0x11ca580: stur            x5, [fp, #-0x18]
    // 0x11ca584: LoadField: r3 = r0->field_1b
    //     0x11ca584: ldur            w3, [x0, #0x1b]
    // 0x11ca588: DecompressPointer r3
    //     0x11ca588: add             x3, x3, HEAP, lsl #32
    // 0x11ca58c: stur            x3, [fp, #-0x10]
    // 0x11ca590: LoadField: r4 = r0->field_f
    //     0x11ca590: ldur            w4, [x0, #0xf]
    // 0x11ca594: DecompressPointer r4
    //     0x11ca594: add             x4, x4, HEAP, lsl #32
    // 0x11ca598: stur            x4, [fp, #-8]
    // 0x11ca59c: r0 = maybeOf()
    //     0x11ca59c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11ca5a0: stur            x0, [fp, #-0x28]
    // 0x11ca5a4: r0 = RenderIndexedStack()
    //     0x11ca5a4: bl              #0x11ca720  ; AllocateRenderIndexedStackStub -> RenderIndexedStack (size=0x80)
    // 0x11ca5a8: mov             x4, x0
    // 0x11ca5ac: ldur            x0, [fp, #-0x20]
    // 0x11ca5b0: stur            x4, [fp, #-0x30]
    // 0x11ca5b4: StoreField: r4->field_7b = r0
    //     0x11ca5b4: stur            w0, [x4, #0x7b]
    // 0x11ca5b8: mov             x1, x4
    // 0x11ca5bc: ldur            x2, [fp, #-8]
    // 0x11ca5c0: ldur            x3, [fp, #-0x10]
    // 0x11ca5c4: ldur            x5, [fp, #-0x18]
    // 0x11ca5c8: ldur            x6, [fp, #-0x28]
    // 0x11ca5cc: r0 = RenderStack()
    //     0x11ca5cc: bl              #0x11ca5e8  ; [package:flutter/src/rendering/stack.dart] RenderStack::RenderStack
    // 0x11ca5d0: ldur            x0, [fp, #-0x30]
    // 0x11ca5d4: LeaveFrame
    //     0x11ca5d4: mov             SP, fp
    //     0x11ca5d8: ldp             fp, lr, [SP], #0x10
    // 0x11ca5dc: ret
    //     0x11ca5dc: ret             
    // 0x11ca5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca5e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca5e4: b               #0x11ca56c
  }
}

// class id: 6690, size: 0x18, field offset: 0x10
//   const constructor, 
class ListBody extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xceee20, size: 0x98
    // 0xceee20: EnterFrame
    //     0xceee20: stp             fp, lr, [SP, #-0x10]!
    //     0xceee24: mov             fp, SP
    // 0xceee28: AllocStack(0x18)
    //     0xceee28: sub             SP, SP, #0x18
    // 0xceee2c: SetupParameters(ListBody this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xceee2c: mov             x5, x1
    //     0xceee30: mov             x4, x2
    //     0xceee34: stur            x1, [fp, #-8]
    //     0xceee38: stur            x2, [fp, #-0x10]
    //     0xceee3c: stur            x3, [fp, #-0x18]
    // 0xceee40: CheckStackOverflow
    //     0xceee40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceee44: cmp             SP, x16
    //     0xceee48: b.ls            #0xceeeb0
    // 0xceee4c: mov             x0, x3
    // 0xceee50: r2 = Null
    //     0xceee50: mov             x2, NULL
    // 0xceee54: r1 = Null
    //     0xceee54: mov             x1, NULL
    // 0xceee58: r4 = 60
    //     0xceee58: mov             x4, #0x3c
    // 0xceee5c: branchIfSmi(r0, 0xceee68)
    //     0xceee5c: tbz             w0, #0, #0xceee68
    // 0xceee60: r4 = LoadClassIdInstr(r0)
    //     0xceee60: ldur            x4, [x0, #-1]
    //     0xceee64: ubfx            x4, x4, #0xc, #0x14
    // 0xceee68: r17 = 4852
    //     0xceee68: mov             x17, #0x12f4
    // 0xceee6c: cmp             x4, x17
    // 0xceee70: b.eq            #0xceee88
    // 0xceee74: r8 = RenderListBody
    //     0xceee74: add             x8, PP, #0xd2, lsl #12  ; [pp+0xd28c0] Type: RenderListBody
    //     0xceee78: ldr             x8, [x8, #0x8c0]
    // 0xceee7c: r3 = Null
    //     0xceee7c: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd28c8] Null
    //     0xceee80: ldr             x3, [x3, #0x8c8]
    // 0xceee84: r0 = DefaultTypeTest()
    //     0xceee84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xceee88: ldur            x1, [fp, #-8]
    // 0xceee8c: ldur            x2, [fp, #-0x10]
    // 0xceee90: r0 = _getDirection()
    //     0xceee90: bl              #0xceeeb8  ; [package:flutter/src/widgets/basic.dart] ListBody::_getDirection
    // 0xceee94: ldur            x1, [fp, #-0x18]
    // 0xceee98: mov             x2, x0
    // 0xceee9c: r0 = textDirection=()
    //     0xceee9c: bl              #0xcde458  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::textDirection=
    // 0xceeea0: r0 = Null
    //     0xceeea0: mov             x0, NULL
    // 0xceeea4: LeaveFrame
    //     0xceeea4: mov             SP, fp
    //     0xceeea8: ldp             fp, lr, [SP], #0x10
    // 0xceeeac: ret
    //     0xceeeac: ret             
    // 0xceeeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeeb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeeb4: b               #0xceee4c
  }
  _ _getDirection(/* No info */) {
    // ** addr: 0xceeeb8, size: 0x8
    // 0xceeeb8: r0 = Instance_AxisDirection
    //     0xceeeb8: ldr             x0, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xceeebc: ret
    //     0xceeebc: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca4d8, size: 0x68
    // 0x11ca4d8: EnterFrame
    //     0x11ca4d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca4dc: mov             fp, SP
    // 0x11ca4e0: AllocStack(0x10)
    //     0x11ca4e0: sub             SP, SP, #0x10
    // 0x11ca4e4: CheckStackOverflow
    //     0x11ca4e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca4e8: cmp             SP, x16
    //     0x11ca4ec: b.ls            #0x11ca538
    // 0x11ca4f0: r0 = _getDirection()
    //     0x11ca4f0: bl              #0xceeeb8  ; [package:flutter/src/widgets/basic.dart] ListBody::_getDirection
    // 0x11ca4f4: stur            x0, [fp, #-8]
    // 0x11ca4f8: r0 = RenderListBody()
    //     0x11ca4f8: bl              #0x11ca540  ; AllocateRenderListBodyStub -> RenderListBody (size=0x64)
    // 0x11ca4fc: mov             x1, x0
    // 0x11ca500: ldur            x0, [fp, #-8]
    // 0x11ca504: stur            x1, [fp, #-0x10]
    // 0x11ca508: StoreField: r1->field_5f = r0
    //     0x11ca508: stur            w0, [x1, #0x5f]
    // 0x11ca50c: StoreField: r1->field_4f = rZR
    //     0x11ca50c: stur            xzr, [x1, #0x4f]
    // 0x11ca510: r0 = _LayoutCacheStorage()
    //     0x11ca510: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11ca514: mov             x1, x0
    // 0x11ca518: ldur            x0, [fp, #-0x10]
    // 0x11ca51c: StoreField: r0->field_47 = r1
    //     0x11ca51c: stur            w1, [x0, #0x47]
    // 0x11ca520: mov             x1, x0
    // 0x11ca524: r0 = RenderObject()
    //     0x11ca524: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11ca528: ldur            x0, [fp, #-0x10]
    // 0x11ca52c: LeaveFrame
    //     0x11ca52c: mov             SP, fp
    //     0x11ca530: ldp             fp, lr, [SP], #0x10
    // 0x11ca534: ret
    //     0x11ca534: ret             
    // 0x11ca538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca53c: b               #0x11ca4f0
  }
}

// class id: 6691, size: 0x14, field offset: 0x10
//   const constructor, 
class CustomMultiChildLayout extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xceebc4, size: 0x8c
    // 0xceebc4: EnterFrame
    //     0xceebc4: stp             fp, lr, [SP, #-0x10]!
    //     0xceebc8: mov             fp, SP
    // 0xceebcc: AllocStack(0x10)
    //     0xceebcc: sub             SP, SP, #0x10
    // 0xceebd0: SetupParameters(CustomMultiChildLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xceebd0: mov             x4, x1
    //     0xceebd4: stur            x1, [fp, #-8]
    //     0xceebd8: stur            x3, [fp, #-0x10]
    // 0xceebdc: CheckStackOverflow
    //     0xceebdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceebe0: cmp             SP, x16
    //     0xceebe4: b.ls            #0xceec48
    // 0xceebe8: mov             x0, x3
    // 0xceebec: r2 = Null
    //     0xceebec: mov             x2, NULL
    // 0xceebf0: r1 = Null
    //     0xceebf0: mov             x1, NULL
    // 0xceebf4: r4 = 60
    //     0xceebf4: mov             x4, #0x3c
    // 0xceebf8: branchIfSmi(r0, 0xceec04)
    //     0xceebf8: tbz             w0, #0, #0xceec04
    // 0xceebfc: r4 = LoadClassIdInstr(r0)
    //     0xceebfc: ldur            x4, [x0, #-1]
    //     0xceec00: ubfx            x4, x4, #0xc, #0x14
    // 0xceec04: r17 = 4817
    //     0xceec04: mov             x17, #0x12d1
    // 0xceec08: cmp             x4, x17
    // 0xceec0c: b.eq            #0xceec24
    // 0xceec10: r8 = RenderCustomMultiChildLayoutBox
    //     0xceec10: add             x8, PP, #0x90, lsl #12  ; [pp+0x90250] Type: RenderCustomMultiChildLayoutBox
    //     0xceec14: ldr             x8, [x8, #0x250]
    // 0xceec18: r3 = Null
    //     0xceec18: add             x3, PP, #0x90, lsl #12  ; [pp+0x90258] Null
    //     0xceec1c: ldr             x3, [x3, #0x258]
    // 0xceec20: r0 = DefaultTypeTest()
    //     0xceec20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xceec24: ldur            x0, [fp, #-8]
    // 0xceec28: LoadField: r2 = r0->field_f
    //     0xceec28: ldur            w2, [x0, #0xf]
    // 0xceec2c: DecompressPointer r2
    //     0xceec2c: add             x2, x2, HEAP, lsl #32
    // 0xceec30: ldur            x1, [fp, #-0x10]
    // 0xceec34: r0 = delegate=()
    //     0xceec34: bl              #0xceec50  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::delegate=
    // 0xceec38: r0 = Null
    //     0xceec38: mov             x0, NULL
    // 0xceec3c: LeaveFrame
    //     0xceec3c: mov             SP, fp
    //     0xceec40: ldp             fp, lr, [SP], #0x10
    // 0xceec44: ret
    //     0xceec44: ret             
    // 0xceec48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceec48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceec4c: b               #0xceebe8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca460, size: 0x6c
    // 0x11ca460: EnterFrame
    //     0x11ca460: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca464: mov             fp, SP
    // 0x11ca468: AllocStack(0x10)
    //     0x11ca468: sub             SP, SP, #0x10
    // 0x11ca46c: CheckStackOverflow
    //     0x11ca46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca470: cmp             SP, x16
    //     0x11ca474: b.ls            #0x11ca4c4
    // 0x11ca478: LoadField: r0 = r1->field_f
    //     0x11ca478: ldur            w0, [x1, #0xf]
    // 0x11ca47c: DecompressPointer r0
    //     0x11ca47c: add             x0, x0, HEAP, lsl #32
    // 0x11ca480: stur            x0, [fp, #-8]
    // 0x11ca484: r0 = RenderCustomMultiChildLayoutBox()
    //     0x11ca484: bl              #0x11ca4cc  ; AllocateRenderCustomMultiChildLayoutBoxStub -> RenderCustomMultiChildLayoutBox (size=0x64)
    // 0x11ca488: mov             x1, x0
    // 0x11ca48c: ldur            x0, [fp, #-8]
    // 0x11ca490: stur            x1, [fp, #-0x10]
    // 0x11ca494: StoreField: r1->field_5f = r0
    //     0x11ca494: stur            w0, [x1, #0x5f]
    // 0x11ca498: StoreField: r1->field_4f = rZR
    //     0x11ca498: stur            xzr, [x1, #0x4f]
    // 0x11ca49c: r0 = _LayoutCacheStorage()
    //     0x11ca49c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11ca4a0: mov             x1, x0
    // 0x11ca4a4: ldur            x0, [fp, #-0x10]
    // 0x11ca4a8: StoreField: r0->field_47 = r1
    //     0x11ca4a8: stur            w1, [x0, #0x47]
    // 0x11ca4ac: mov             x1, x0
    // 0x11ca4b0: r0 = RenderObject()
    //     0x11ca4b0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11ca4b4: ldur            x0, [fp, #-0x10]
    // 0x11ca4b8: LeaveFrame
    //     0x11ca4b8: mov             SP, fp
    //     0x11ca4bc: ldp             fp, lr, [SP], #0x10
    // 0x11ca4c0: ret
    //     0x11ca4c0: ret             
    // 0x11ca4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca4c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca4c8: b               #0x11ca478
  }
}

// class id: 6693, size: 0x38, field offset: 0x10
//   const constructor, 
class Flex extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcee544, size: 0x134
    // 0xcee544: EnterFrame
    //     0xcee544: stp             fp, lr, [SP, #-0x10]!
    //     0xcee548: mov             fp, SP
    // 0xcee54c: AllocStack(0x18)
    //     0xcee54c: sub             SP, SP, #0x18
    // 0xcee550: SetupParameters(Flex this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcee550: mov             x5, x1
    //     0xcee554: mov             x4, x2
    //     0xcee558: stur            x1, [fp, #-8]
    //     0xcee55c: stur            x2, [fp, #-0x10]
    //     0xcee560: stur            x3, [fp, #-0x18]
    // 0xcee564: CheckStackOverflow
    //     0xcee564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee568: cmp             SP, x16
    //     0xcee56c: b.ls            #0xcee670
    // 0xcee570: mov             x0, x3
    // 0xcee574: r2 = Null
    //     0xcee574: mov             x2, NULL
    // 0xcee578: r1 = Null
    //     0xcee578: mov             x1, NULL
    // 0xcee57c: r4 = 60
    //     0xcee57c: mov             x4, #0x3c
    // 0xcee580: branchIfSmi(r0, 0xcee58c)
    //     0xcee580: tbz             w0, #0, #0xcee58c
    // 0xcee584: r4 = LoadClassIdInstr(r0)
    //     0xcee584: ldur            x4, [x0, #-1]
    //     0xcee588: ubfx            x4, x4, #0xc, #0x14
    // 0xcee58c: r17 = -4861
    //     0xcee58c: mov             x17, #-0x12fd
    // 0xcee590: add             x4, x4, x17
    // 0xcee594: cmp             x4, #3
    // 0xcee598: b.ls            #0xcee5b0
    // 0xcee59c: r8 = RenderFlex
    //     0xcee59c: add             x8, PP, #0x84, lsl #12  ; [pp+0x84fd0] Type: RenderFlex
    //     0xcee5a0: ldr             x8, [x8, #0xfd0]
    // 0xcee5a4: r3 = Null
    //     0xcee5a4: add             x3, PP, #0x84, lsl #12  ; [pp+0x84fd8] Null
    //     0xcee5a8: ldr             x3, [x3, #0xfd8]
    // 0xcee5ac: r0 = DefaultTypeTest()
    //     0xcee5ac: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcee5b0: ldur            x0, [fp, #-8]
    // 0xcee5b4: LoadField: r2 = r0->field_f
    //     0xcee5b4: ldur            w2, [x0, #0xf]
    // 0xcee5b8: DecompressPointer r2
    //     0xcee5b8: add             x2, x2, HEAP, lsl #32
    // 0xcee5bc: ldur            x1, [fp, #-0x18]
    // 0xcee5c0: r0 = direction=()
    //     0xcee5c0: bl              #0xcee998  ; [package:flutter/src/rendering/flex.dart] RenderFlex::direction=
    // 0xcee5c4: ldur            x0, [fp, #-8]
    // 0xcee5c8: LoadField: r2 = r0->field_13
    //     0xcee5c8: ldur            w2, [x0, #0x13]
    // 0xcee5cc: DecompressPointer r2
    //     0xcee5cc: add             x2, x2, HEAP, lsl #32
    // 0xcee5d0: ldur            x1, [fp, #-0x18]
    // 0xcee5d4: r0 = mainAxisAlignment=()
    //     0xcee5d4: bl              #0xcee938  ; [package:flutter/src/rendering/flex.dart] RenderFlex::mainAxisAlignment=
    // 0xcee5d8: ldur            x0, [fp, #-8]
    // 0xcee5dc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcee5dc: ldur            w2, [x0, #0x17]
    // 0xcee5e0: DecompressPointer r2
    //     0xcee5e0: add             x2, x2, HEAP, lsl #32
    // 0xcee5e4: ldur            x1, [fp, #-0x18]
    // 0xcee5e8: r0 = mainAxisSize=()
    //     0xcee5e8: bl              #0xcee8d8  ; [package:flutter/src/rendering/flex.dart] RenderFlex::mainAxisSize=
    // 0xcee5ec: ldur            x0, [fp, #-8]
    // 0xcee5f0: LoadField: r2 = r0->field_1b
    //     0xcee5f0: ldur            w2, [x0, #0x1b]
    // 0xcee5f4: DecompressPointer r2
    //     0xcee5f4: add             x2, x2, HEAP, lsl #32
    // 0xcee5f8: ldur            x1, [fp, #-0x18]
    // 0xcee5fc: r0 = crossAxisAlignment=()
    //     0xcee5fc: bl              #0xcee878  ; [package:flutter/src/rendering/flex.dart] RenderFlex::crossAxisAlignment=
    // 0xcee600: ldur            x1, [fp, #-8]
    // 0xcee604: ldur            x2, [fp, #-0x10]
    // 0xcee608: r0 = getEffectiveTextDirection()
    //     0xcee608: bl              #0xcee788  ; [package:flutter/src/widgets/basic.dart] Flex::getEffectiveTextDirection
    // 0xcee60c: ldur            x1, [fp, #-0x18]
    // 0xcee610: mov             x2, x0
    // 0xcee614: r0 = textDirection=()
    //     0xcee614: bl              #0xcee31c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::textDirection=
    // 0xcee618: ldur            x0, [fp, #-8]
    // 0xcee61c: LoadField: r2 = r0->field_23
    //     0xcee61c: ldur            w2, [x0, #0x23]
    // 0xcee620: DecompressPointer r2
    //     0xcee620: add             x2, x2, HEAP, lsl #32
    // 0xcee624: ldur            x1, [fp, #-0x18]
    // 0xcee628: r0 = verticalDirection=()
    //     0xcee628: bl              #0xcee728  ; [package:flutter/src/rendering/flex.dart] RenderFlex::verticalDirection=
    // 0xcee62c: ldur            x0, [fp, #-8]
    // 0xcee630: LoadField: r2 = r0->field_27
    //     0xcee630: ldur            w2, [x0, #0x27]
    // 0xcee634: DecompressPointer r2
    //     0xcee634: add             x2, x2, HEAP, lsl #32
    // 0xcee638: ldur            x1, [fp, #-0x18]
    // 0xcee63c: r0 = textBaseline=()
    //     0xcee63c: bl              #0xcee6c8  ; [package:flutter/src/rendering/flex.dart] RenderFlex::textBaseline=
    // 0xcee640: ldur            x1, [fp, #-0x18]
    // 0xcee644: r2 = Instance_Clip
    //     0xcee644: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xcee648: ldr             x2, [x2, #0x840]
    // 0xcee64c: r0 = Shader._()
    //     0xcee64c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcee650: ldur            x0, [fp, #-8]
    // 0xcee654: LoadField: d0 = r0->field_2f
    //     0xcee654: ldur            d0, [x0, #0x2f]
    // 0xcee658: ldur            x1, [fp, #-0x18]
    // 0xcee65c: r0 = spacing=()
    //     0xcee65c: bl              #0xcee678  ; [package:flutter/src/rendering/flex.dart] RenderFlex::spacing=
    // 0xcee660: r0 = Null
    //     0xcee660: mov             x0, NULL
    // 0xcee664: LeaveFrame
    //     0xcee664: mov             SP, fp
    //     0xcee668: ldp             fp, lr, [SP], #0x10
    // 0xcee66c: ret
    //     0xcee66c: ret             
    // 0xcee670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee670: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee674: b               #0xcee570
  }
  _ getEffectiveTextDirection(/* No info */) {
    // ** addr: 0xcee788, size: 0x98
    // 0xcee788: EnterFrame
    //     0xcee788: stp             fp, lr, [SP, #-0x10]!
    //     0xcee78c: mov             fp, SP
    // 0xcee790: mov             x0, x1
    // 0xcee794: mov             x1, x2
    // 0xcee798: CheckStackOverflow
    //     0xcee798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee79c: cmp             SP, x16
    //     0xcee7a0: b.ls            #0xcee818
    // 0xcee7a4: LoadField: r2 = r0->field_1f
    //     0xcee7a4: ldur            w2, [x0, #0x1f]
    // 0xcee7a8: DecompressPointer r2
    //     0xcee7a8: add             x2, x2, HEAP, lsl #32
    // 0xcee7ac: cmp             w2, NULL
    // 0xcee7b0: b.ne            #0xcee808
    // 0xcee7b4: LoadField: r2 = r0->field_f
    //     0xcee7b4: ldur            w2, [x0, #0xf]
    // 0xcee7b8: DecompressPointer r2
    //     0xcee7b8: add             x2, x2, HEAP, lsl #32
    // 0xcee7bc: LoadField: r3 = r2->field_7
    //     0xcee7bc: ldur            x3, [x2, #7]
    // 0xcee7c0: cmp             x3, #0
    // 0xcee7c4: b.le            #0xcee7f0
    // 0xcee7c8: LoadField: r2 = r0->field_1b
    //     0xcee7c8: ldur            w2, [x0, #0x1b]
    // 0xcee7cc: DecompressPointer r2
    //     0xcee7cc: add             x2, x2, HEAP, lsl #32
    // 0xcee7d0: r16 = Instance_CrossAxisAlignment
    //     0xcee7d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xcee7d4: ldr             x16, [x16, #0x830]
    // 0xcee7d8: cmp             w2, w16
    // 0xcee7dc: b.eq            #0xcee7f0
    // 0xcee7e0: r16 = Instance_CrossAxisAlignment
    //     0xcee7e0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] Obj!CrossAxisAlignment@12c4501
    //     0xcee7e4: ldr             x16, [x16, #0xbd8]
    // 0xcee7e8: cmp             w2, w16
    // 0xcee7ec: b.ne            #0xcee7fc
    // 0xcee7f0: r0 = maybeOf()
    //     0xcee7f0: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcee7f4: mov             x1, x0
    // 0xcee7f8: b               #0xcee800
    // 0xcee7fc: r1 = Null
    //     0xcee7fc: mov             x1, NULL
    // 0xcee800: mov             x0, x1
    // 0xcee804: b               #0xcee80c
    // 0xcee808: mov             x0, x2
    // 0xcee80c: LeaveFrame
    //     0xcee80c: mov             SP, fp
    //     0xcee810: ldp             fp, lr, [SP], #0x10
    // 0xcee814: ret
    //     0xcee814: ret             
    // 0xcee818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee81c: b               #0xcee7a4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca214, size: 0x12c
    // 0x11ca214: EnterFrame
    //     0x11ca214: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca218: mov             fp, SP
    // 0x11ca21c: AllocStack(0x70)
    //     0x11ca21c: sub             SP, SP, #0x70
    // 0x11ca220: SetupParameters(Flex this /* r1 => r0, fp-0x28 */)
    //     0x11ca220: mov             x0, x1
    //     0x11ca224: stur            x1, [fp, #-0x28]
    // 0x11ca228: CheckStackOverflow
    //     0x11ca228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca22c: cmp             SP, x16
    //     0x11ca230: b.ls            #0x11ca318
    // 0x11ca234: LoadField: r3 = r0->field_f
    //     0x11ca234: ldur            w3, [x0, #0xf]
    // 0x11ca238: DecompressPointer r3
    //     0x11ca238: add             x3, x3, HEAP, lsl #32
    // 0x11ca23c: stur            x3, [fp, #-0x20]
    // 0x11ca240: LoadField: r4 = r0->field_13
    //     0x11ca240: ldur            w4, [x0, #0x13]
    // 0x11ca244: DecompressPointer r4
    //     0x11ca244: add             x4, x4, HEAP, lsl #32
    // 0x11ca248: stur            x4, [fp, #-0x18]
    // 0x11ca24c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11ca24c: ldur            w5, [x0, #0x17]
    // 0x11ca250: DecompressPointer r5
    //     0x11ca250: add             x5, x5, HEAP, lsl #32
    // 0x11ca254: stur            x5, [fp, #-0x10]
    // 0x11ca258: LoadField: r6 = r0->field_1b
    //     0x11ca258: ldur            w6, [x0, #0x1b]
    // 0x11ca25c: DecompressPointer r6
    //     0x11ca25c: add             x6, x6, HEAP, lsl #32
    // 0x11ca260: mov             x1, x0
    // 0x11ca264: stur            x6, [fp, #-8]
    // 0x11ca268: r0 = getEffectiveTextDirection()
    //     0x11ca268: bl              #0xcee788  ; [package:flutter/src/widgets/basic.dart] Flex::getEffectiveTextDirection
    // 0x11ca26c: mov             x1, x0
    // 0x11ca270: ldur            x0, [fp, #-0x28]
    // 0x11ca274: stur            x1, [fp, #-0x40]
    // 0x11ca278: LoadField: r2 = r0->field_23
    //     0x11ca278: ldur            w2, [x0, #0x23]
    // 0x11ca27c: DecompressPointer r2
    //     0x11ca27c: add             x2, x2, HEAP, lsl #32
    // 0x11ca280: stur            x2, [fp, #-0x38]
    // 0x11ca284: LoadField: r3 = r0->field_27
    //     0x11ca284: ldur            w3, [x0, #0x27]
    // 0x11ca288: DecompressPointer r3
    //     0x11ca288: add             x3, x3, HEAP, lsl #32
    // 0x11ca28c: stur            x3, [fp, #-0x30]
    // 0x11ca290: LoadField: d0 = r0->field_2f
    //     0x11ca290: ldur            d0, [x0, #0x2f]
    // 0x11ca294: r0 = inline_Allocate_Double()
    //     0x11ca294: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x11ca298: add             x0, x0, #0x10
    //     0x11ca29c: cmp             x4, x0
    //     0x11ca2a0: b.ls            #0x11ca320
    //     0x11ca2a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x11ca2a8: sub             x0, x0, #0xf
    //     0x11ca2ac: mov             x4, #0xe19c
    //     0x11ca2b0: movk            x4, #3, lsl #16
    //     0x11ca2b4: stur            x4, [x0, #-1]
    // 0x11ca2b8: dmb             ishst
    // 0x11ca2bc: StoreField: r0->field_7 = d0
    //     0x11ca2bc: stur            d0, [x0, #7]
    // 0x11ca2c0: stur            x0, [fp, #-0x28]
    // 0x11ca2c4: r0 = RenderFlex()
    //     0x11ca2c4: bl              #0x11ca340  ; AllocateRenderFlexStub -> RenderFlex (size=0x98)
    // 0x11ca2c8: stur            x0, [fp, #-0x48]
    // 0x11ca2cc: ldur            x16, [fp, #-0x18]
    // 0x11ca2d0: ldur            lr, [fp, #-0x40]
    // 0x11ca2d4: stp             lr, x16, [SP, #0x18]
    // 0x11ca2d8: ldur            x16, [fp, #-0x38]
    // 0x11ca2dc: ldur            lr, [fp, #-0x30]
    // 0x11ca2e0: stp             lr, x16, [SP, #8]
    // 0x11ca2e4: ldur            x16, [fp, #-0x28]
    // 0x11ca2e8: str             x16, [SP]
    // 0x11ca2ec: mov             x1, x0
    // 0x11ca2f0: ldur            x2, [fp, #-8]
    // 0x11ca2f4: ldur            x3, [fp, #-0x20]
    // 0x11ca2f8: ldur            x5, [fp, #-0x10]
    // 0x11ca2fc: r4 = const [0, 0x9, 0x5, 0x4, mainAxisAlignment, 0x4, spacing, 0x8, textBaseline, 0x7, textDirection, 0x5, verticalDirection, 0x6, null]
    //     0x11ca2fc: add             x4, PP, #0x84, lsl #12  ; [pp+0x84fe8] List(15) [0, 0x9, 0x5, 0x4, "mainAxisAlignment", 0x4, "spacing", 0x8, "textBaseline", 0x7, "textDirection", 0x5, "verticalDirection", 0x6, Null]
    //     0x11ca300: ldr             x4, [x4, #0xfe8]
    // 0x11ca304: r0 = RenderFlex()
    //     0x11ca304: bl              #0x11c9c4c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x11ca308: ldur            x0, [fp, #-0x48]
    // 0x11ca30c: LeaveFrame
    //     0x11ca30c: mov             SP, fp
    //     0x11ca310: ldp             fp, lr, [SP], #0x10
    // 0x11ca314: ret
    //     0x11ca314: ret             
    // 0x11ca318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca318: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca31c: b               #0x11ca234
    // 0x11ca320: SaveReg d0
    //     0x11ca320: str             q0, [SP, #-0x10]!
    // 0x11ca324: stp             x2, x3, [SP, #-0x10]!
    // 0x11ca328: SaveReg r1
    //     0x11ca328: str             x1, [SP, #-8]!
    // 0x11ca32c: r0 = AllocateDouble()
    //     0x11ca32c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11ca330: RestoreReg r1
    //     0x11ca330: ldr             x1, [SP], #8
    // 0x11ca334: ldp             x2, x3, [SP], #0x10
    // 0x11ca338: RestoreReg d0
    //     0x11ca338: ldr             q0, [SP], #0x10
    // 0x11ca33c: b               #0x11ca2bc
  }
}

// class id: 6694, size: 0x38, field offset: 0x38
//   const constructor, 
class Column extends Flex {

  _ImmutableList<Widget> field_c;
  Axis field_10;
  MainAxisAlignment field_14;
  MainAxisSize field_18;
  CrossAxisAlignment field_1c;
  VerticalDirection field_24;
  Clip field_2c;
  _Mint field_30;
}

// class id: 6695, size: 0x38, field offset: 0x38
//   const constructor, 
class Row extends Flex {
}

// class id: 6728, size: 0x50, field offset: 0xc
//   const constructor, 
class RawImage extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xce2fe4, size: 0x1c8
    // 0xce2fe4: EnterFrame
    //     0xce2fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xce2fe8: mov             fp, SP
    // 0xce2fec: AllocStack(0x10)
    //     0xce2fec: sub             SP, SP, #0x10
    // 0xce2ff0: SetupParameters(RawImage this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xce2ff0: mov             x4, x1
    //     0xce2ff4: stur            x1, [fp, #-8]
    //     0xce2ff8: stur            x3, [fp, #-0x10]
    // 0xce2ffc: CheckStackOverflow
    //     0xce2ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3000: cmp             SP, x16
    //     0xce3004: b.ls            #0xce31a4
    // 0xce3008: mov             x0, x3
    // 0xce300c: r2 = Null
    //     0xce300c: mov             x2, NULL
    // 0xce3010: r1 = Null
    //     0xce3010: mov             x1, NULL
    // 0xce3014: r4 = 60
    //     0xce3014: mov             x4, #0x3c
    // 0xce3018: branchIfSmi(r0, 0xce3024)
    //     0xce3018: tbz             w0, #0, #0xce3024
    // 0xce301c: r4 = LoadClassIdInstr(r0)
    //     0xce301c: ldur            x4, [x0, #-1]
    //     0xce3020: ubfx            x4, x4, #0xc, #0x14
    // 0xce3024: r17 = 4725
    //     0xce3024: mov             x17, #0x1275
    // 0xce3028: cmp             x4, x17
    // 0xce302c: b.eq            #0xce3044
    // 0xce3030: r8 = RenderImage
    //     0xce3030: add             x8, PP, #0x99, lsl #12  ; [pp+0x99d98] Type: RenderImage
    //     0xce3034: ldr             x8, [x8, #0xd98]
    // 0xce3038: r3 = Null
    //     0xce3038: add             x3, PP, #0x99, lsl #12  ; [pp+0x99db0] Null
    //     0xce303c: ldr             x3, [x3, #0xdb0]
    // 0xce3040: r0 = DefaultTypeTest()
    //     0xce3040: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xce3044: ldur            x0, [fp, #-8]
    // 0xce3048: LoadField: r1 = r0->field_b
    //     0xce3048: ldur            w1, [x0, #0xb]
    // 0xce304c: DecompressPointer r1
    //     0xce304c: add             x1, x1, HEAP, lsl #32
    // 0xce3050: cmp             w1, NULL
    // 0xce3054: b.ne            #0xce3060
    // 0xce3058: r2 = Null
    //     0xce3058: mov             x2, NULL
    // 0xce305c: b               #0xce306c
    // 0xce3060: r0 = clone()
    //     0xce3060: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0xce3064: mov             x2, x0
    // 0xce3068: ldur            x0, [fp, #-8]
    // 0xce306c: ldur            x3, [fp, #-0x10]
    // 0xce3070: mov             x1, x3
    // 0xce3074: r0 = image=()
    //     0xce3074: bl              #0xce36e0  ; [package:flutter/src/rendering/image.dart] RenderImage::image=
    // 0xce3078: ldur            x3, [fp, #-8]
    // 0xce307c: LoadField: r0 = r3->field_f
    //     0xce307c: ldur            w0, [x3, #0xf]
    // 0xce3080: DecompressPointer r0
    //     0xce3080: add             x0, x0, HEAP, lsl #32
    // 0xce3084: ldur            x4, [fp, #-0x10]
    // 0xce3088: StoreField: r4->field_5b = r0
    //     0xce3088: stur            w0, [x4, #0x5b]
    //     0xce308c: ldurb           w16, [x4, #-1]
    //     0xce3090: ldurb           w17, [x0, #-1]
    //     0xce3094: and             x16, x17, x16, lsr #2
    //     0xce3098: tst             x16, HEAP, lsr #32
    //     0xce309c: b.eq            #0xce30a4
    //     0xce30a0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xce30a4: LoadField: r2 = r3->field_13
    //     0xce30a4: ldur            w2, [x3, #0x13]
    // 0xce30a8: DecompressPointer r2
    //     0xce30a8: add             x2, x2, HEAP, lsl #32
    // 0xce30ac: mov             x1, x4
    // 0xce30b0: r0 = width=()
    //     0xce30b0: bl              #0xce363c  ; [package:flutter/src/rendering/image.dart] RenderImage::width=
    // 0xce30b4: ldur            x0, [fp, #-8]
    // 0xce30b8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xce30b8: ldur            w2, [x0, #0x17]
    // 0xce30bc: DecompressPointer r2
    //     0xce30bc: add             x2, x2, HEAP, lsl #32
    // 0xce30c0: ldur            x1, [fp, #-0x10]
    // 0xce30c4: r0 = height=()
    //     0xce30c4: bl              #0xce3598  ; [package:flutter/src/rendering/image.dart] RenderImage::height=
    // 0xce30c8: ldur            x0, [fp, #-8]
    // 0xce30cc: LoadField: d0 = r0->field_1b
    //     0xce30cc: ldur            d0, [x0, #0x1b]
    // 0xce30d0: ldur            x1, [fp, #-0x10]
    // 0xce30d4: r0 = scale=()
    //     0xce30d4: bl              #0xce3548  ; [package:flutter/src/rendering/image.dart] RenderImage::scale=
    // 0xce30d8: ldur            x0, [fp, #-8]
    // 0xce30dc: LoadField: r2 = r0->field_23
    //     0xce30dc: ldur            w2, [x0, #0x23]
    // 0xce30e0: DecompressPointer r2
    //     0xce30e0: add             x2, x2, HEAP, lsl #32
    // 0xce30e4: ldur            x1, [fp, #-0x10]
    // 0xce30e8: r0 = color=()
    //     0xce30e8: bl              #0xce3410  ; [package:flutter/src/rendering/image.dart] RenderImage::color=
    // 0xce30ec: ldur            x1, [fp, #-0x10]
    // 0xce30f0: r2 = Null
    //     0xce30f0: mov             x2, NULL
    // 0xce30f4: r0 = Shader._()
    //     0xce30f4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce30f8: ldur            x1, [fp, #-0x10]
    // 0xce30fc: r2 = Null
    //     0xce30fc: mov             x2, NULL
    // 0xce3100: r0 = Shader._()
    //     0xce3100: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce3104: ldur            x0, [fp, #-8]
    // 0xce3108: LoadField: r2 = r0->field_33
    //     0xce3108: ldur            w2, [x0, #0x33]
    // 0xce310c: DecompressPointer r2
    //     0xce310c: add             x2, x2, HEAP, lsl #32
    // 0xce3110: ldur            x1, [fp, #-0x10]
    // 0xce3114: r0 = fit=()
    //     0xce3114: bl              #0xce33a0  ; [package:flutter/src/rendering/image.dart] RenderImage::fit=
    // 0xce3118: ldur            x0, [fp, #-8]
    // 0xce311c: LoadField: r2 = r0->field_37
    //     0xce311c: ldur            w2, [x0, #0x37]
    // 0xce3120: DecompressPointer r2
    //     0xce3120: add             x2, x2, HEAP, lsl #32
    // 0xce3124: ldur            x1, [fp, #-0x10]
    // 0xce3128: r0 = alignment=()
    //     0xce3128: bl              #0xce3318  ; [package:flutter/src/rendering/image.dart] RenderImage::alignment=
    // 0xce312c: ldur            x1, [fp, #-0x10]
    // 0xce3130: r2 = Instance_ImageRepeat
    //     0xce3130: add             x2, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xce3134: ldr             x2, [x2, #0xfb8]
    // 0xce3138: r0 = Shader._()
    //     0xce3138: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce313c: ldur            x1, [fp, #-0x10]
    // 0xce3140: r2 = Null
    //     0xce3140: mov             x2, NULL
    // 0xce3144: r0 = Shader._()
    //     0xce3144: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce3148: ldur            x1, [fp, #-0x10]
    // 0xce314c: r2 = false
    //     0xce314c: add             x2, NULL, #0x30  ; false
    // 0xce3150: r0 = Shader._()
    //     0xce3150: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce3154: ldur            x1, [fp, #-0x10]
    // 0xce3158: r2 = Null
    //     0xce3158: mov             x2, NULL
    // 0xce315c: r0 = textDirection=()
    //     0xce315c: bl              #0xce3270  ; [package:flutter/src/rendering/image.dart] RenderImage::textDirection=
    // 0xce3160: ldur            x0, [fp, #-8]
    // 0xce3164: LoadField: r2 = r0->field_47
    //     0xce3164: ldur            w2, [x0, #0x47]
    // 0xce3168: DecompressPointer r2
    //     0xce3168: add             x2, x2, HEAP, lsl #32
    // 0xce316c: ldur            x1, [fp, #-0x10]
    // 0xce3170: r0 = invertColors=()
    //     0xce3170: bl              #0xce321c  ; [package:flutter/src/rendering/image.dart] RenderImage::invertColors=
    // 0xce3174: ldur            x1, [fp, #-0x10]
    // 0xce3178: r2 = false
    //     0xce3178: add             x2, NULL, #0x30  ; false
    // 0xce317c: r0 = Shader._()
    //     0xce317c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce3180: ldur            x0, [fp, #-8]
    // 0xce3184: LoadField: r2 = r0->field_2b
    //     0xce3184: ldur            w2, [x0, #0x2b]
    // 0xce3188: DecompressPointer r2
    //     0xce3188: add             x2, x2, HEAP, lsl #32
    // 0xce318c: ldur            x1, [fp, #-0x10]
    // 0xce3190: r0 = filterQuality=()
    //     0xce3190: bl              #0xce31ac  ; [package:flutter/src/rendering/image.dart] RenderImage::filterQuality=
    // 0xce3194: r0 = Null
    //     0xce3194: mov             x0, NULL
    // 0xce3198: LeaveFrame
    //     0xce3198: mov             SP, fp
    //     0xce319c: ldp             fp, lr, [SP], #0x10
    // 0xce31a0: ret
    //     0xce31a0: ret             
    // 0xce31a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce31a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce31a8: b               #0xce3008
  }
  _ didUnmountRenderObject(/* No info */) {
    // ** addr: 0xcff00c, size: 0x80
    // 0xcff00c: EnterFrame
    //     0xcff00c: stp             fp, lr, [SP, #-0x10]!
    //     0xcff010: mov             fp, SP
    // 0xcff014: AllocStack(0x8)
    //     0xcff014: sub             SP, SP, #8
    // 0xcff018: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xcff018: mov             x3, x2
    //     0xcff01c: stur            x2, [fp, #-8]
    // 0xcff020: CheckStackOverflow
    //     0xcff020: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff024: cmp             SP, x16
    //     0xcff028: b.ls            #0xcff084
    // 0xcff02c: mov             x0, x3
    // 0xcff030: r2 = Null
    //     0xcff030: mov             x2, NULL
    // 0xcff034: r1 = Null
    //     0xcff034: mov             x1, NULL
    // 0xcff038: r4 = 60
    //     0xcff038: mov             x4, #0x3c
    // 0xcff03c: branchIfSmi(r0, 0xcff048)
    //     0xcff03c: tbz             w0, #0, #0xcff048
    // 0xcff040: r4 = LoadClassIdInstr(r0)
    //     0xcff040: ldur            x4, [x0, #-1]
    //     0xcff044: ubfx            x4, x4, #0xc, #0x14
    // 0xcff048: r17 = 4725
    //     0xcff048: mov             x17, #0x1275
    // 0xcff04c: cmp             x4, x17
    // 0xcff050: b.eq            #0xcff068
    // 0xcff054: r8 = RenderImage
    //     0xcff054: add             x8, PP, #0x99, lsl #12  ; [pp+0x99d98] Type: RenderImage
    //     0xcff058: ldr             x8, [x8, #0xd98]
    // 0xcff05c: r3 = Null
    //     0xcff05c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99da0] Null
    //     0xcff060: ldr             x3, [x3, #0xda0]
    // 0xcff064: r0 = DefaultTypeTest()
    //     0xcff064: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcff068: ldur            x1, [fp, #-8]
    // 0xcff06c: r2 = Null
    //     0xcff06c: mov             x2, NULL
    // 0xcff070: r0 = image=()
    //     0xcff070: bl              #0xce36e0  ; [package:flutter/src/rendering/image.dart] RenderImage::image=
    // 0xcff074: r0 = Null
    //     0xcff074: mov             x0, NULL
    // 0xcff078: LeaveFrame
    //     0xcff078: mov             SP, fp
    //     0xcff07c: ldp             fp, lr, [SP], #0x10
    // 0xcff080: ret
    //     0xcff080: ret             
    // 0xcff084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff088: b               #0xcff02c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11c0b3c, size: 0x10c
    // 0x11c0b3c: EnterFrame
    //     0x11c0b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0b40: mov             fp, SP
    // 0x11c0b44: AllocStack(0x80)
    //     0x11c0b44: sub             SP, SP, #0x80
    // 0x11c0b48: SetupParameters(RawImage this /* r1 => r0, fp-0x8 */)
    //     0x11c0b48: mov             x0, x1
    //     0x11c0b4c: stur            x1, [fp, #-8]
    // 0x11c0b50: CheckStackOverflow
    //     0x11c0b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0b54: cmp             SP, x16
    //     0x11c0b58: b.ls            #0x11c0c40
    // 0x11c0b5c: LoadField: r1 = r0->field_b
    //     0x11c0b5c: ldur            w1, [x0, #0xb]
    // 0x11c0b60: DecompressPointer r1
    //     0x11c0b60: add             x1, x1, HEAP, lsl #32
    // 0x11c0b64: cmp             w1, NULL
    // 0x11c0b68: b.ne            #0x11c0b74
    // 0x11c0b6c: r1 = Null
    //     0x11c0b6c: mov             x1, NULL
    // 0x11c0b70: b               #0x11c0b80
    // 0x11c0b74: r0 = clone()
    //     0x11c0b74: bl              #0xce393c  ; [dart:ui] Image::clone
    // 0x11c0b78: mov             x1, x0
    // 0x11c0b7c: ldur            x0, [fp, #-8]
    // 0x11c0b80: stur            x1, [fp, #-0x50]
    // 0x11c0b84: LoadField: r5 = r0->field_f
    //     0x11c0b84: ldur            w5, [x0, #0xf]
    // 0x11c0b88: DecompressPointer r5
    //     0x11c0b88: add             x5, x5, HEAP, lsl #32
    // 0x11c0b8c: stur            x5, [fp, #-0x48]
    // 0x11c0b90: LoadField: r2 = r0->field_13
    //     0x11c0b90: ldur            w2, [x0, #0x13]
    // 0x11c0b94: DecompressPointer r2
    //     0x11c0b94: add             x2, x2, HEAP, lsl #32
    // 0x11c0b98: stur            x2, [fp, #-0x40]
    // 0x11c0b9c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x11c0b9c: ldur            w3, [x0, #0x17]
    // 0x11c0ba0: DecompressPointer r3
    //     0x11c0ba0: add             x3, x3, HEAP, lsl #32
    // 0x11c0ba4: stur            x3, [fp, #-0x38]
    // 0x11c0ba8: LoadField: d0 = r0->field_1b
    //     0x11c0ba8: ldur            d0, [x0, #0x1b]
    // 0x11c0bac: stur            d0, [fp, #-0x58]
    // 0x11c0bb0: LoadField: r4 = r0->field_23
    //     0x11c0bb0: ldur            w4, [x0, #0x23]
    // 0x11c0bb4: DecompressPointer r4
    //     0x11c0bb4: add             x4, x4, HEAP, lsl #32
    // 0x11c0bb8: stur            x4, [fp, #-0x30]
    // 0x11c0bbc: LoadField: r7 = r0->field_33
    //     0x11c0bbc: ldur            w7, [x0, #0x33]
    // 0x11c0bc0: DecompressPointer r7
    //     0x11c0bc0: add             x7, x7, HEAP, lsl #32
    // 0x11c0bc4: stur            x7, [fp, #-0x28]
    // 0x11c0bc8: LoadField: r6 = r0->field_37
    //     0x11c0bc8: ldur            w6, [x0, #0x37]
    // 0x11c0bcc: DecompressPointer r6
    //     0x11c0bcc: add             x6, x6, HEAP, lsl #32
    // 0x11c0bd0: stur            x6, [fp, #-0x20]
    // 0x11c0bd4: LoadField: r8 = r0->field_47
    //     0x11c0bd4: ldur            w8, [x0, #0x47]
    // 0x11c0bd8: DecompressPointer r8
    //     0x11c0bd8: add             x8, x8, HEAP, lsl #32
    // 0x11c0bdc: stur            x8, [fp, #-0x18]
    // 0x11c0be0: LoadField: r9 = r0->field_2b
    //     0x11c0be0: ldur            w9, [x0, #0x2b]
    // 0x11c0be4: DecompressPointer r9
    //     0x11c0be4: add             x9, x9, HEAP, lsl #32
    // 0x11c0be8: stur            x9, [fp, #-0x10]
    // 0x11c0bec: r0 = RenderImage()
    //     0x11c0bec: bl              #0x11c0e04  ; AllocateRenderImageStub -> RenderImage (size=0xa4)
    // 0x11c0bf0: stur            x0, [fp, #-8]
    // 0x11c0bf4: ldur            x16, [fp, #-0x38]
    // 0x11c0bf8: ldur            lr, [fp, #-0x50]
    // 0x11c0bfc: stp             lr, x16, [SP, #0x18]
    // 0x11c0c00: ldur            x16, [fp, #-0x18]
    // 0x11c0c04: stp             NULL, x16, [SP, #8]
    // 0x11c0c08: ldur            x16, [fp, #-0x40]
    // 0x11c0c0c: str             x16, [SP]
    // 0x11c0c10: mov             x1, x0
    // 0x11c0c14: ldur            x2, [fp, #-0x20]
    // 0x11c0c18: ldur            x3, [fp, #-0x30]
    // 0x11c0c1c: ldur            x5, [fp, #-0x48]
    // 0x11c0c20: ldur            x6, [fp, #-0x10]
    // 0x11c0c24: ldur            x7, [fp, #-0x28]
    // 0x11c0c28: ldur            d0, [fp, #-0x58]
    // 0x11c0c2c: r0 = RenderImage()
    //     0x11c0c2c: bl              #0x11c0c48  ; [package:flutter/src/rendering/image.dart] RenderImage::RenderImage
    // 0x11c0c30: ldur            x0, [fp, #-8]
    // 0x11c0c34: LeaveFrame
    //     0x11c0c34: mov             SP, fp
    //     0x11c0c38: ldp             fp, lr, [SP], #0x10
    // 0x11c0c3c: ret
    //     0x11c0c3c: ret             
    // 0x11c0c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0c44: b               #0x11c0b5c
  }
}

// class id: 6757, size: 0x20, field offset: 0x14
//   const constructor, 
class Flexible extends ParentDataWidget<dynamic> {

  SizedBox field_c;
  _Mint field_14;
  FlexFit field_1c;

  _ applyParentData(/* No info */) {
    // ** addr: 0x1206820, size: 0x1ac
    // 0x1206820: EnterFrame
    //     0x1206820: stp             fp, lr, [SP, #-0x10]!
    //     0x1206824: mov             fp, SP
    // 0x1206828: AllocStack(0x18)
    //     0x1206828: sub             SP, SP, #0x18
    // 0x120682c: SetupParameters(Flexible this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x120682c: mov             x4, x1
    //     0x1206830: mov             x3, x2
    //     0x1206834: stur            x1, [fp, #-0x10]
    //     0x1206838: stur            x2, [fp, #-0x18]
    // 0x120683c: CheckStackOverflow
    //     0x120683c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1206840: cmp             SP, x16
    //     0x1206844: b.ls            #0x12069c0
    // 0x1206848: LoadField: r5 = r3->field_7
    //     0x1206848: ldur            w5, [x3, #7]
    // 0x120684c: DecompressPointer r5
    //     0x120684c: add             x5, x5, HEAP, lsl #32
    // 0x1206850: stur            x5, [fp, #-8]
    // 0x1206854: cmp             w5, NULL
    // 0x1206858: b.eq            #0x12069c8
    // 0x120685c: mov             x0, x5
    // 0x1206860: r2 = Null
    //     0x1206860: mov             x2, NULL
    // 0x1206864: r1 = Null
    //     0x1206864: mov             x1, NULL
    // 0x1206868: r4 = LoadClassIdInstr(r0)
    //     0x1206868: ldur            x4, [x0, #-1]
    //     0x120686c: ubfx            x4, x4, #0xc, #0x14
    // 0x1206870: r17 = 4212
    //     0x1206870: mov             x17, #0x1074
    // 0x1206874: cmp             x4, x17
    // 0x1206878: b.eq            #0x1206890
    // 0x120687c: r8 = FlexParentData
    //     0x120687c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0x1206880: ldr             x8, [x8, #0x10]
    // 0x1206884: r3 = Null
    //     0x1206884: add             x3, PP, #0x85, lsl #12  ; [pp+0x85018] Null
    //     0x1206888: ldr             x3, [x3, #0x18]
    // 0x120688c: r0 = DefaultTypeTest()
    //     0x120688c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1206890: ldur            x2, [fp, #-8]
    // 0x1206894: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1206894: ldur            w3, [x2, #0x17]
    // 0x1206898: DecompressPointer r3
    //     0x1206898: add             x3, x3, HEAP, lsl #32
    // 0x120689c: ldur            x4, [fp, #-0x10]
    // 0x12068a0: LoadField: r5 = r4->field_13
    //     0x12068a0: ldur            x5, [x4, #0x13]
    // 0x12068a4: r0 = BoxInt64Instr(r5)
    //     0x12068a4: sbfiz           x0, x5, #1, #0x1f
    //     0x12068a8: cmp             x5, x0, asr #1
    //     0x12068ac: b.eq            #0x12068b8
    //     0x12068b0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12068b4: stur            x5, [x0, #7]
    // 0x12068b8: cmp             w3, w0
    // 0x12068bc: b.eq            #0x1206920
    // 0x12068c0: and             w16, w3, w0
    // 0x12068c4: branchIfSmi(r16, 0x12068f8)
    //     0x12068c4: tbz             w16, #0, #0x12068f8
    // 0x12068c8: r16 = LoadClassIdInstr(r3)
    //     0x12068c8: ldur            x16, [x3, #-1]
    //     0x12068cc: ubfx            x16, x16, #0xc, #0x14
    // 0x12068d0: cmp             x16, #0x3d
    // 0x12068d4: b.ne            #0x12068f8
    // 0x12068d8: r16 = LoadClassIdInstr(r0)
    //     0x12068d8: ldur            x16, [x0, #-1]
    //     0x12068dc: ubfx            x16, x16, #0xc, #0x14
    // 0x12068e0: cmp             x16, #0x3d
    // 0x12068e4: b.ne            #0x12068f8
    // 0x12068e8: LoadField: r16 = r3->field_7
    //     0x12068e8: ldur            x16, [x3, #7]
    // 0x12068ec: LoadField: r17 = r0->field_7
    //     0x12068ec: ldur            x17, [x0, #7]
    // 0x12068f0: cmp             x16, x17
    // 0x12068f4: b.eq            #0x1206920
    // 0x12068f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x12068f8: stur            w0, [x2, #0x17]
    //     0x12068fc: tbz             w0, #0, #0x1206918
    //     0x1206900: ldurb           w16, [x2, #-1]
    //     0x1206904: ldurb           w17, [x0, #-1]
    //     0x1206908: and             x16, x17, x16, lsr #2
    //     0x120690c: tst             x16, HEAP, lsr #32
    //     0x1206910: b.eq            #0x1206918
    //     0x1206914: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1206918: r0 = true
    //     0x1206918: add             x0, NULL, #0x20  ; true
    // 0x120691c: b               #0x1206924
    // 0x1206920: r0 = false
    //     0x1206920: add             x0, NULL, #0x30  ; false
    // 0x1206924: LoadField: r1 = r2->field_1b
    //     0x1206924: ldur            w1, [x2, #0x1b]
    // 0x1206928: DecompressPointer r1
    //     0x1206928: add             x1, x1, HEAP, lsl #32
    // 0x120692c: LoadField: r3 = r4->field_1b
    //     0x120692c: ldur            w3, [x4, #0x1b]
    // 0x1206930: DecompressPointer r3
    //     0x1206930: add             x3, x3, HEAP, lsl #32
    // 0x1206934: cmp             w1, w3
    // 0x1206938: b.eq            #0x1206960
    // 0x120693c: mov             x0, x3
    // 0x1206940: StoreField: r2->field_1b = r0
    //     0x1206940: stur            w0, [x2, #0x1b]
    //     0x1206944: ldurb           w16, [x2, #-1]
    //     0x1206948: ldurb           w17, [x0, #-1]
    //     0x120694c: and             x16, x17, x16, lsr #2
    //     0x1206950: tst             x16, HEAP, lsr #32
    //     0x1206954: b.eq            #0x120695c
    //     0x1206958: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x120695c: b               #0x1206964
    // 0x1206960: tbnz            w0, #4, #0x12069b0
    // 0x1206964: ldur            x1, [fp, #-0x18]
    // 0x1206968: r0 = LoadClassIdInstr(r1)
    //     0x1206968: ldur            x0, [x1, #-1]
    //     0x120696c: ubfx            x0, x0, #0xc, #0x14
    // 0x1206970: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x1206970: mov             x17, #0xfc0
    //     0x1206974: movk            x17, #1, lsl #16
    //     0x1206978: add             lr, x0, x17
    //     0x120697c: ldr             lr, [x21, lr, lsl #3]
    //     0x1206980: blr             lr
    // 0x1206984: cmp             w0, NULL
    // 0x1206988: b.eq            #0x12069b0
    // 0x120698c: r1 = LoadClassIdInstr(r0)
    //     0x120698c: ldur            x1, [x0, #-1]
    //     0x1206990: ubfx            x1, x1, #0xc, #0x14
    // 0x1206994: mov             x16, x0
    // 0x1206998: mov             x0, x1
    // 0x120699c: mov             x1, x16
    // 0x12069a0: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0x12069a0: mov             x17, #0xfc6d
    //     0x12069a4: add             lr, x0, x17
    //     0x12069a8: ldr             lr, [x21, lr, lsl #3]
    //     0x12069ac: blr             lr
    // 0x12069b0: r0 = Null
    //     0x12069b0: mov             x0, NULL
    // 0x12069b4: LeaveFrame
    //     0x12069b4: mov             SP, fp
    //     0x12069b8: ldp             fp, lr, [SP], #0x10
    // 0x12069bc: ret
    //     0x12069bc: ret             
    // 0x12069c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12069c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12069c4: b               #0x1206848
    // 0x12069c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12069c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6758, size: 0x20, field offset: 0x20
//   const constructor, 
class Expanded extends Flexible {
}

// class id: 6759, size: 0x2c, field offset: 0x14
//   const constructor, 
class Positioned extends ParentDataWidget<dynamic> {

  factory _ Positioned.directional(/* No info */) {
    // ** addr: 0xebbd48, size: 0x260
    // 0xebbd48: EnterFrame
    //     0xebbd48: stp             fp, lr, [SP, #-0x10]!
    //     0xebbd4c: mov             fp, SP
    // 0xebbd50: AllocStack(0x38)
    //     0xebbd50: sub             SP, SP, #0x38
    // 0xebbd54: SetupParameters(dynamic _ /* r1 => r2 */, dynamic _ /* r2 => r16 */)
    //     0xebbd54: mov             x16, x2
    //     0xebbd58: mov             x2, x1
    // 0xebbd5c: mov             x1, x16
    // 0xebbd60: mov             x0, x3
    // 0xebbd64: stur            x1, [fp, #-0x18]
    // 0xebbd68: stur            x3, [fp, #-0x20]
    // 0xebbd6c: stur            d0, [fp, #-0x38]
    // 0xebbd70: LoadField: r2 = r4->field_13
    //     0xebbd70: ldur            w2, [x4, #0x13]
    // 0xebbd74: LoadField: r3 = r4->field_1f
    //     0xebbd74: ldur            w3, [x4, #0x1f]
    // 0xebbd78: DecompressPointer r3
    //     0xebbd78: add             x3, x3, HEAP, lsl #32
    // 0xebbd7c: r16 = "bottom"
    //     0xebbd7c: ldr             x16, [PP, #0x57b8]  ; [pp+0x57b8] "bottom"
    // 0xebbd80: cmp             w3, w16
    // 0xebbd84: b.ne            #0xebbda8
    // 0xebbd88: LoadField: r3 = r4->field_23
    //     0xebbd88: ldur            w3, [x4, #0x23]
    // 0xebbd8c: DecompressPointer r3
    //     0xebbd8c: add             x3, x3, HEAP, lsl #32
    // 0xebbd90: sub             w6, w2, w3
    // 0xebbd94: add             x3, fp, w6, sxtw #2
    // 0xebbd98: ldr             x3, [x3, #8]
    // 0xebbd9c: mov             x6, x3
    // 0xebbda0: r3 = 1
    //     0xebbda0: mov             x3, #1
    // 0xebbda4: b               #0xebbdb0
    // 0xebbda8: r6 = Null
    //     0xebbda8: mov             x6, NULL
    // 0xebbdac: r3 = 0
    //     0xebbdac: mov             x3, #0
    // 0xebbdb0: stur            x6, [fp, #-0x10]
    // 0xebbdb4: lsl             x7, x3, #1
    // 0xebbdb8: lsl             w8, w7, #1
    // 0xebbdbc: add             w9, w8, #8
    // 0xebbdc0: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0xebbdc0: add             x16, x4, w9, sxtw #1
    //     0xebbdc4: ldur            w10, [x16, #0xf]
    // 0xebbdc8: DecompressPointer r10
    //     0xebbdc8: add             x10, x10, HEAP, lsl #32
    // 0xebbdcc: r16 = "end"
    //     0xebbdcc: ldr             x16, [PP, #0x958]  ; [pp+0x958] "end"
    // 0xebbdd0: cmp             w10, w16
    // 0xebbdd4: b.ne            #0xebbe08
    // 0xebbdd8: add             w3, w8, #0xa
    // 0xebbddc: ArrayLoad: r8 = r4[r3]  ; Unknown_4
    //     0xebbddc: add             x16, x4, w3, sxtw #1
    //     0xebbde0: ldur            w8, [x16, #0xf]
    // 0xebbde4: DecompressPointer r8
    //     0xebbde4: add             x8, x8, HEAP, lsl #32
    // 0xebbde8: sub             w3, w2, w8
    // 0xebbdec: add             x8, fp, w3, sxtw #2
    // 0xebbdf0: ldr             x8, [x8, #8]
    // 0xebbdf4: add             w3, w7, #2
    // 0xebbdf8: r7 = LoadInt32Instr(r3)
    //     0xebbdf8: sbfx            x7, x3, #1, #0x1f
    // 0xebbdfc: mov             x3, x7
    // 0xebbe00: mov             x7, x8
    // 0xebbe04: b               #0xebbe0c
    // 0xebbe08: r7 = Null
    //     0xebbe08: mov             x7, NULL
    // 0xebbe0c: lsl             x8, x3, #1
    // 0xebbe10: lsl             w9, w8, #1
    // 0xebbe14: add             w10, w9, #8
    // 0xebbe18: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0xebbe18: add             x16, x4, w10, sxtw #1
    //     0xebbe1c: ldur            w11, [x16, #0xf]
    // 0xebbe20: DecompressPointer r11
    //     0xebbe20: add             x11, x11, HEAP, lsl #32
    // 0xebbe24: r16 = "start"
    //     0xebbe24: ldr             x16, [PP, #0x948]  ; [pp+0x948] "start"
    // 0xebbe28: cmp             w11, w16
    // 0xebbe2c: b.ne            #0xebbe60
    // 0xebbe30: add             w3, w9, #0xa
    // 0xebbe34: ArrayLoad: r9 = r4[r3]  ; Unknown_4
    //     0xebbe34: add             x16, x4, w3, sxtw #1
    //     0xebbe38: ldur            w9, [x16, #0xf]
    // 0xebbe3c: DecompressPointer r9
    //     0xebbe3c: add             x9, x9, HEAP, lsl #32
    // 0xebbe40: sub             w3, w2, w9
    // 0xebbe44: add             x9, fp, w3, sxtw #2
    // 0xebbe48: ldr             x9, [x9, #8]
    // 0xebbe4c: add             w3, w8, #2
    // 0xebbe50: r8 = LoadInt32Instr(r3)
    //     0xebbe50: sbfx            x8, x3, #1, #0x1f
    // 0xebbe54: mov             x3, x8
    // 0xebbe58: mov             x8, x9
    // 0xebbe5c: b               #0xebbe64
    // 0xebbe60: r8 = Null
    //     0xebbe60: mov             x8, NULL
    // 0xebbe64: lsl             x9, x3, #1
    // 0xebbe68: lsl             w3, w9, #1
    // 0xebbe6c: add             w9, w3, #8
    // 0xebbe70: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0xebbe70: add             x16, x4, w9, sxtw #1
    //     0xebbe74: ldur            w10, [x16, #0xf]
    // 0xebbe78: DecompressPointer r10
    //     0xebbe78: add             x10, x10, HEAP, lsl #32
    // 0xebbe7c: r16 = "width"
    //     0xebbe7c: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0xebbe80: cmp             w10, w16
    // 0xebbe84: b.ne            #0xebbeac
    // 0xebbe88: add             w9, w3, #0xa
    // 0xebbe8c: ArrayLoad: r3 = r4[r9]  ; Unknown_4
    //     0xebbe8c: add             x16, x4, w9, sxtw #1
    //     0xebbe90: ldur            w3, [x16, #0xf]
    // 0xebbe94: DecompressPointer r3
    //     0xebbe94: add             x3, x3, HEAP, lsl #32
    // 0xebbe98: sub             w4, w2, w3
    // 0xebbe9c: add             x2, fp, w4, sxtw #2
    // 0xebbea0: ldr             x2, [x2, #8]
    // 0xebbea4: mov             x4, x2
    // 0xebbea8: b               #0xebbeb0
    // 0xebbeac: r4 = Null
    //     0xebbeac: mov             x4, NULL
    // 0xebbeb0: stur            x4, [fp, #-8]
    // 0xebbeb4: LoadField: r2 = r5->field_7
    //     0xebbeb4: ldur            x2, [x5, #7]
    // 0xebbeb8: cmp             x2, #0
    // 0xebbebc: b.gt            #0xebbed4
    // 0xebbec0: mov             x2, x7
    // 0xebbec4: mov             x3, x8
    // 0xebbec8: r0 = AllocateRecord2()
    //     0xebbec8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xebbecc: mov             x1, x0
    // 0xebbed0: b               #0xebbee4
    // 0xebbed4: mov             x2, x8
    // 0xebbed8: mov             x3, x7
    // 0xebbedc: r0 = AllocateRecord2()
    //     0xebbedc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xebbee0: mov             x1, x0
    // 0xebbee4: ldur            x2, [fp, #-0x18]
    // 0xebbee8: ldur            x0, [fp, #-0x20]
    // 0xebbeec: ldur            d0, [fp, #-0x38]
    // 0xebbef0: ldur            x3, [fp, #-0x10]
    // 0xebbef4: ldur            x4, [fp, #-8]
    // 0xebbef8: LoadField: r5 = r1->field_f
    //     0xebbef8: ldur            w5, [x1, #0xf]
    // 0xebbefc: DecompressPointer r5
    //     0xebbefc: add             x5, x5, HEAP, lsl #32
    // 0xebbf00: stur            x5, [fp, #-0x30]
    // 0xebbf04: LoadField: r6 = r1->field_13
    //     0xebbf04: ldur            w6, [x1, #0x13]
    // 0xebbf08: DecompressPointer r6
    //     0xebbf08: add             x6, x6, HEAP, lsl #32
    // 0xebbf0c: stur            x6, [fp, #-0x28]
    // 0xebbf10: r1 = <StackParentData>
    //     0xebbf10: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xebbf14: ldr             x1, [x1, #0x858]
    // 0xebbf18: r0 = Positioned()
    //     0xebbf18: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xebbf1c: ldur            x1, [fp, #-0x30]
    // 0xebbf20: StoreField: r0->field_13 = r1
    //     0xebbf20: stur            w1, [x0, #0x13]
    // 0xebbf24: ldur            d0, [fp, #-0x38]
    // 0xebbf28: r1 = inline_Allocate_Double()
    //     0xebbf28: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xebbf2c: add             x1, x1, #0x10
    //     0xebbf30: cmp             x2, x1
    //     0xebbf34: b.ls            #0xebbf8c
    //     0xebbf38: str             x1, [THR, #0x60]  ; THR::top
    //     0xebbf3c: sub             x1, x1, #0xf
    //     0xebbf40: mov             x2, #0xe19c
    //     0xebbf44: movk            x2, #3, lsl #16
    //     0xebbf48: stur            x2, [x1, #-1]
    // 0xebbf4c: dmb             ishst
    // 0xebbf50: StoreField: r1->field_7 = d0
    //     0xebbf50: stur            d0, [x1, #7]
    // 0xebbf54: ArrayStore: r0[0] = r1  ; List_4
    //     0xebbf54: stur            w1, [x0, #0x17]
    // 0xebbf58: ldur            x1, [fp, #-0x28]
    // 0xebbf5c: StoreField: r0->field_1b = r1
    //     0xebbf5c: stur            w1, [x0, #0x1b]
    // 0xebbf60: ldur            x1, [fp, #-0x10]
    // 0xebbf64: StoreField: r0->field_1f = r1
    //     0xebbf64: stur            w1, [x0, #0x1f]
    // 0xebbf68: ldur            x1, [fp, #-8]
    // 0xebbf6c: StoreField: r0->field_23 = r1
    //     0xebbf6c: stur            w1, [x0, #0x23]
    // 0xebbf70: ldur            x1, [fp, #-0x20]
    // 0xebbf74: StoreField: r0->field_27 = r1
    //     0xebbf74: stur            w1, [x0, #0x27]
    // 0xebbf78: ldur            x1, [fp, #-0x18]
    // 0xebbf7c: StoreField: r0->field_b = r1
    //     0xebbf7c: stur            w1, [x0, #0xb]
    // 0xebbf80: LeaveFrame
    //     0xebbf80: mov             SP, fp
    //     0xebbf84: ldp             fp, lr, [SP], #0x10
    // 0xebbf88: ret
    //     0xebbf88: ret             
    // 0xebbf8c: SaveReg d0
    //     0xebbf8c: str             q0, [SP, #-0x10]!
    // 0xebbf90: SaveReg r0
    //     0xebbf90: str             x0, [SP, #-8]!
    // 0xebbf94: r0 = AllocateDouble()
    //     0xebbf94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xebbf98: mov             x1, x0
    // 0xebbf9c: RestoreReg r0
    //     0xebbf9c: ldr             x0, [SP], #8
    // 0xebbfa0: RestoreReg d0
    //     0xebbfa0: ldr             q0, [SP], #0x10
    // 0xebbfa4: b               #0xebbf50
  }
  _ applyParentData(/* No info */) {
    // ** addr: 0x12064ac, size: 0x374
    // 0x12064ac: EnterFrame
    //     0x12064ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12064b0: mov             fp, SP
    // 0x12064b4: AllocStack(0x38)
    //     0x12064b4: sub             SP, SP, #0x38
    // 0x12064b8: SetupParameters(Positioned this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x12064b8: mov             x4, x1
    //     0x12064bc: mov             x3, x2
    //     0x12064c0: stur            x1, [fp, #-0x10]
    //     0x12064c4: stur            x2, [fp, #-0x18]
    // 0x12064c8: CheckStackOverflow
    //     0x12064c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12064cc: cmp             SP, x16
    //     0x12064d0: b.ls            #0x1206814
    // 0x12064d4: LoadField: r5 = r3->field_7
    //     0x12064d4: ldur            w5, [x3, #7]
    // 0x12064d8: DecompressPointer r5
    //     0x12064d8: add             x5, x5, HEAP, lsl #32
    // 0x12064dc: stur            x5, [fp, #-8]
    // 0x12064e0: cmp             w5, NULL
    // 0x12064e4: b.eq            #0x120681c
    // 0x12064e8: mov             x0, x5
    // 0x12064ec: r2 = Null
    //     0x12064ec: mov             x2, NULL
    // 0x12064f0: r1 = Null
    //     0x12064f0: mov             x1, NULL
    // 0x12064f4: r4 = LoadClassIdInstr(r0)
    //     0x12064f4: ldur            x4, [x0, #-1]
    //     0x12064f8: ubfx            x4, x4, #0xc, #0x14
    // 0x12064fc: r17 = -4208
    //     0x12064fc: mov             x17, #-0x1070
    // 0x1206500: add             x4, x4, x17
    // 0x1206504: cmp             x4, #2
    // 0x1206508: b.ls            #0x1206520
    // 0x120650c: r8 = StackParentData
    //     0x120650c: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0x1206510: ldr             x8, [x8, #0xaa8]
    // 0x1206514: r3 = Null
    //     0x1206514: add             x3, PP, #0x85, lsl #12  ; [pp+0x85040] Null
    //     0x1206518: ldr             x3, [x3, #0x40]
    // 0x120651c: r0 = DefaultTypeTest()
    //     0x120651c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1206520: ldur            x1, [fp, #-8]
    // 0x1206524: LoadField: r0 = r1->field_23
    //     0x1206524: ldur            w0, [x1, #0x23]
    // 0x1206528: DecompressPointer r0
    //     0x1206528: add             x0, x0, HEAP, lsl #32
    // 0x120652c: ldur            x2, [fp, #-0x10]
    // 0x1206530: LoadField: r3 = r2->field_13
    //     0x1206530: ldur            w3, [x2, #0x13]
    // 0x1206534: DecompressPointer r3
    //     0x1206534: add             x3, x3, HEAP, lsl #32
    // 0x1206538: stur            x3, [fp, #-0x20]
    // 0x120653c: r4 = LoadClassIdInstr(r0)
    //     0x120653c: ldur            x4, [x0, #-1]
    //     0x1206540: ubfx            x4, x4, #0xc, #0x14
    // 0x1206544: stp             x3, x0, [SP]
    // 0x1206548: mov             x0, x4
    // 0x120654c: mov             lr, x0
    // 0x1206550: ldr             lr, [x21, lr, lsl #3]
    // 0x1206554: blr             lr
    // 0x1206558: tbz             w0, #4, #0x1206588
    // 0x120655c: ldur            x1, [fp, #-8]
    // 0x1206560: ldur            x0, [fp, #-0x20]
    // 0x1206564: StoreField: r1->field_23 = r0
    //     0x1206564: stur            w0, [x1, #0x23]
    //     0x1206568: ldurb           w16, [x1, #-1]
    //     0x120656c: ldurb           w17, [x0, #-1]
    //     0x1206570: and             x16, x17, x16, lsr #2
    //     0x1206574: tst             x16, HEAP, lsr #32
    //     0x1206578: b.eq            #0x1206580
    //     0x120657c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1206580: r3 = true
    //     0x1206580: add             x3, NULL, #0x20  ; true
    // 0x1206584: b               #0x1206590
    // 0x1206588: ldur            x1, [fp, #-8]
    // 0x120658c: r3 = false
    //     0x120658c: add             x3, NULL, #0x30  ; false
    // 0x1206590: ldur            x2, [fp, #-0x10]
    // 0x1206594: stur            x3, [fp, #-0x28]
    // 0x1206598: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1206598: ldur            w0, [x1, #0x17]
    // 0x120659c: DecompressPointer r0
    //     0x120659c: add             x0, x0, HEAP, lsl #32
    // 0x12065a0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12065a0: ldur            w4, [x2, #0x17]
    // 0x12065a4: DecompressPointer r4
    //     0x12065a4: add             x4, x4, HEAP, lsl #32
    // 0x12065a8: stur            x4, [fp, #-0x20]
    // 0x12065ac: r5 = LoadClassIdInstr(r0)
    //     0x12065ac: ldur            x5, [x0, #-1]
    //     0x12065b0: ubfx            x5, x5, #0xc, #0x14
    // 0x12065b4: stp             x4, x0, [SP]
    // 0x12065b8: mov             x0, x5
    // 0x12065bc: mov             lr, x0
    // 0x12065c0: ldr             lr, [x21, lr, lsl #3]
    // 0x12065c4: blr             lr
    // 0x12065c8: tbz             w0, #4, #0x12065f8
    // 0x12065cc: ldur            x1, [fp, #-8]
    // 0x12065d0: ldur            x0, [fp, #-0x20]
    // 0x12065d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x12065d4: stur            w0, [x1, #0x17]
    //     0x12065d8: ldurb           w16, [x1, #-1]
    //     0x12065dc: ldurb           w17, [x0, #-1]
    //     0x12065e0: and             x16, x17, x16, lsr #2
    //     0x12065e4: tst             x16, HEAP, lsr #32
    //     0x12065e8: b.eq            #0x12065f0
    //     0x12065ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12065f0: r3 = true
    //     0x12065f0: add             x3, NULL, #0x20  ; true
    // 0x12065f4: b               #0x1206600
    // 0x12065f8: ldur            x1, [fp, #-8]
    // 0x12065fc: ldur            x3, [fp, #-0x28]
    // 0x1206600: ldur            x2, [fp, #-0x10]
    // 0x1206604: stur            x3, [fp, #-0x28]
    // 0x1206608: LoadField: r0 = r1->field_1b
    //     0x1206608: ldur            w0, [x1, #0x1b]
    // 0x120660c: DecompressPointer r0
    //     0x120660c: add             x0, x0, HEAP, lsl #32
    // 0x1206610: LoadField: r4 = r2->field_1b
    //     0x1206610: ldur            w4, [x2, #0x1b]
    // 0x1206614: DecompressPointer r4
    //     0x1206614: add             x4, x4, HEAP, lsl #32
    // 0x1206618: stur            x4, [fp, #-0x20]
    // 0x120661c: r5 = LoadClassIdInstr(r0)
    //     0x120661c: ldur            x5, [x0, #-1]
    //     0x1206620: ubfx            x5, x5, #0xc, #0x14
    // 0x1206624: stp             x4, x0, [SP]
    // 0x1206628: mov             x0, x5
    // 0x120662c: mov             lr, x0
    // 0x1206630: ldr             lr, [x21, lr, lsl #3]
    // 0x1206634: blr             lr
    // 0x1206638: tbz             w0, #4, #0x1206668
    // 0x120663c: ldur            x1, [fp, #-8]
    // 0x1206640: ldur            x0, [fp, #-0x20]
    // 0x1206644: StoreField: r1->field_1b = r0
    //     0x1206644: stur            w0, [x1, #0x1b]
    //     0x1206648: ldurb           w16, [x1, #-1]
    //     0x120664c: ldurb           w17, [x0, #-1]
    //     0x1206650: and             x16, x17, x16, lsr #2
    //     0x1206654: tst             x16, HEAP, lsr #32
    //     0x1206658: b.eq            #0x1206660
    //     0x120665c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1206660: r3 = true
    //     0x1206660: add             x3, NULL, #0x20  ; true
    // 0x1206664: b               #0x1206670
    // 0x1206668: ldur            x1, [fp, #-8]
    // 0x120666c: ldur            x3, [fp, #-0x28]
    // 0x1206670: ldur            x2, [fp, #-0x10]
    // 0x1206674: stur            x3, [fp, #-0x28]
    // 0x1206678: LoadField: r0 = r1->field_1f
    //     0x1206678: ldur            w0, [x1, #0x1f]
    // 0x120667c: DecompressPointer r0
    //     0x120667c: add             x0, x0, HEAP, lsl #32
    // 0x1206680: LoadField: r4 = r2->field_1f
    //     0x1206680: ldur            w4, [x2, #0x1f]
    // 0x1206684: DecompressPointer r4
    //     0x1206684: add             x4, x4, HEAP, lsl #32
    // 0x1206688: stur            x4, [fp, #-0x20]
    // 0x120668c: r5 = LoadClassIdInstr(r0)
    //     0x120668c: ldur            x5, [x0, #-1]
    //     0x1206690: ubfx            x5, x5, #0xc, #0x14
    // 0x1206694: stp             x4, x0, [SP]
    // 0x1206698: mov             x0, x5
    // 0x120669c: mov             lr, x0
    // 0x12066a0: ldr             lr, [x21, lr, lsl #3]
    // 0x12066a4: blr             lr
    // 0x12066a8: tbz             w0, #4, #0x12066d8
    // 0x12066ac: ldur            x1, [fp, #-8]
    // 0x12066b0: ldur            x0, [fp, #-0x20]
    // 0x12066b4: StoreField: r1->field_1f = r0
    //     0x12066b4: stur            w0, [x1, #0x1f]
    //     0x12066b8: ldurb           w16, [x1, #-1]
    //     0x12066bc: ldurb           w17, [x0, #-1]
    //     0x12066c0: and             x16, x17, x16, lsr #2
    //     0x12066c4: tst             x16, HEAP, lsr #32
    //     0x12066c8: b.eq            #0x12066d0
    //     0x12066cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12066d0: r3 = true
    //     0x12066d0: add             x3, NULL, #0x20  ; true
    // 0x12066d4: b               #0x12066e0
    // 0x12066d8: ldur            x1, [fp, #-8]
    // 0x12066dc: ldur            x3, [fp, #-0x28]
    // 0x12066e0: ldur            x2, [fp, #-0x10]
    // 0x12066e4: stur            x3, [fp, #-0x28]
    // 0x12066e8: LoadField: r0 = r1->field_27
    //     0x12066e8: ldur            w0, [x1, #0x27]
    // 0x12066ec: DecompressPointer r0
    //     0x12066ec: add             x0, x0, HEAP, lsl #32
    // 0x12066f0: LoadField: r4 = r2->field_23
    //     0x12066f0: ldur            w4, [x2, #0x23]
    // 0x12066f4: DecompressPointer r4
    //     0x12066f4: add             x4, x4, HEAP, lsl #32
    // 0x12066f8: stur            x4, [fp, #-0x20]
    // 0x12066fc: r5 = LoadClassIdInstr(r0)
    //     0x12066fc: ldur            x5, [x0, #-1]
    //     0x1206700: ubfx            x5, x5, #0xc, #0x14
    // 0x1206704: stp             x4, x0, [SP]
    // 0x1206708: mov             x0, x5
    // 0x120670c: mov             lr, x0
    // 0x1206710: ldr             lr, [x21, lr, lsl #3]
    // 0x1206714: blr             lr
    // 0x1206718: tbz             w0, #4, #0x1206748
    // 0x120671c: ldur            x1, [fp, #-8]
    // 0x1206720: ldur            x0, [fp, #-0x20]
    // 0x1206724: StoreField: r1->field_27 = r0
    //     0x1206724: stur            w0, [x1, #0x27]
    //     0x1206728: ldurb           w16, [x1, #-1]
    //     0x120672c: ldurb           w17, [x0, #-1]
    //     0x1206730: and             x16, x17, x16, lsr #2
    //     0x1206734: tst             x16, HEAP, lsr #32
    //     0x1206738: b.eq            #0x1206740
    //     0x120673c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1206740: r2 = true
    //     0x1206740: add             x2, NULL, #0x20  ; true
    // 0x1206744: b               #0x1206750
    // 0x1206748: ldur            x1, [fp, #-8]
    // 0x120674c: ldur            x2, [fp, #-0x28]
    // 0x1206750: ldur            x0, [fp, #-0x10]
    // 0x1206754: stur            x2, [fp, #-0x28]
    // 0x1206758: LoadField: r3 = r1->field_2b
    //     0x1206758: ldur            w3, [x1, #0x2b]
    // 0x120675c: DecompressPointer r3
    //     0x120675c: add             x3, x3, HEAP, lsl #32
    // 0x1206760: LoadField: r4 = r0->field_27
    //     0x1206760: ldur            w4, [x0, #0x27]
    // 0x1206764: DecompressPointer r4
    //     0x1206764: add             x4, x4, HEAP, lsl #32
    // 0x1206768: stur            x4, [fp, #-0x20]
    // 0x120676c: r0 = LoadClassIdInstr(r3)
    //     0x120676c: ldur            x0, [x3, #-1]
    //     0x1206770: ubfx            x0, x0, #0xc, #0x14
    // 0x1206774: stp             x4, x3, [SP]
    // 0x1206778: mov             lr, x0
    // 0x120677c: ldr             lr, [x21, lr, lsl #3]
    // 0x1206780: blr             lr
    // 0x1206784: tbz             w0, #4, #0x12067b0
    // 0x1206788: ldur            x1, [fp, #-8]
    // 0x120678c: ldur            x0, [fp, #-0x20]
    // 0x1206790: StoreField: r1->field_2b = r0
    //     0x1206790: stur            w0, [x1, #0x2b]
    //     0x1206794: ldurb           w16, [x1, #-1]
    //     0x1206798: ldurb           w17, [x0, #-1]
    //     0x120679c: and             x16, x17, x16, lsr #2
    //     0x12067a0: tst             x16, HEAP, lsr #32
    //     0x12067a4: b.eq            #0x12067ac
    //     0x12067a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12067ac: b               #0x12067b8
    // 0x12067b0: ldur            x0, [fp, #-0x28]
    // 0x12067b4: tbnz            w0, #4, #0x1206804
    // 0x12067b8: ldur            x1, [fp, #-0x18]
    // 0x12067bc: r0 = LoadClassIdInstr(r1)
    //     0x12067bc: ldur            x0, [x1, #-1]
    //     0x12067c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12067c4: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x12067c4: mov             x17, #0xfc0
    //     0x12067c8: movk            x17, #1, lsl #16
    //     0x12067cc: add             lr, x0, x17
    //     0x12067d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12067d4: blr             lr
    // 0x12067d8: cmp             w0, NULL
    // 0x12067dc: b.eq            #0x1206804
    // 0x12067e0: r1 = LoadClassIdInstr(r0)
    //     0x12067e0: ldur            x1, [x0, #-1]
    //     0x12067e4: ubfx            x1, x1, #0xc, #0x14
    // 0x12067e8: mov             x16, x0
    // 0x12067ec: mov             x0, x1
    // 0x12067f0: mov             x1, x16
    // 0x12067f4: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0x12067f4: mov             x17, #0xfc6d
    //     0x12067f8: add             lr, x0, x17
    //     0x12067fc: ldr             lr, [x21, lr, lsl #3]
    //     0x1206800: blr             lr
    // 0x1206804: r0 = Null
    //     0x1206804: mov             x0, NULL
    // 0x1206808: LeaveFrame
    //     0x1206808: mov             SP, fp
    //     0x120680c: ldp             fp, lr, [SP], #0x10
    // 0x1206810: ret
    //     0x1206810: ret             
    // 0x1206814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1206814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1206818: b               #0x12064d4
    // 0x120681c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x120681c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6760, size: 0x18, field offset: 0x14
class LayoutId extends ParentDataWidget<dynamic> {

  _ applyParentData(/* No info */) {
    // ** addr: 0x1206364, size: 0x148
    // 0x1206364: EnterFrame
    //     0x1206364: stp             fp, lr, [SP, #-0x10]!
    //     0x1206368: mov             fp, SP
    // 0x120636c: AllocStack(0x30)
    //     0x120636c: sub             SP, SP, #0x30
    // 0x1206370: SetupParameters(LayoutId this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x1206370: mov             x4, x1
    //     0x1206374: mov             x3, x2
    //     0x1206378: stur            x1, [fp, #-0x10]
    //     0x120637c: stur            x2, [fp, #-0x18]
    // 0x1206380: CheckStackOverflow
    //     0x1206380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1206384: cmp             SP, x16
    //     0x1206388: b.ls            #0x12064a0
    // 0x120638c: LoadField: r5 = r3->field_7
    //     0x120638c: ldur            w5, [x3, #7]
    // 0x1206390: DecompressPointer r5
    //     0x1206390: add             x5, x5, HEAP, lsl #32
    // 0x1206394: stur            x5, [fp, #-8]
    // 0x1206398: cmp             w5, NULL
    // 0x120639c: b.eq            #0x12064a8
    // 0x12063a0: mov             x0, x5
    // 0x12063a4: r2 = Null
    //     0x12063a4: mov             x2, NULL
    // 0x12063a8: r1 = Null
    //     0x12063a8: mov             x1, NULL
    // 0x12063ac: r4 = LoadClassIdInstr(r0)
    //     0x12063ac: ldur            x4, [x0, #-1]
    //     0x12063b0: ubfx            x4, x4, #0xc, #0x14
    // 0x12063b4: r17 = 4213
    //     0x12063b4: mov             x17, #0x1075
    // 0x12063b8: cmp             x4, x17
    // 0x12063bc: b.eq            #0x12063d4
    // 0x12063c0: r8 = MultiChildLayoutParentData
    //     0x12063c0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90280] Type: MultiChildLayoutParentData
    //     0x12063c4: ldr             x8, [x8, #0x280]
    // 0x12063c8: r3 = Null
    //     0x12063c8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90288] Null
    //     0x12063cc: ldr             x3, [x3, #0x288]
    // 0x12063d0: r0 = DefaultTypeTest()
    //     0x12063d0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12063d4: ldur            x1, [fp, #-8]
    // 0x12063d8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12063d8: ldur            w0, [x1, #0x17]
    // 0x12063dc: DecompressPointer r0
    //     0x12063dc: add             x0, x0, HEAP, lsl #32
    // 0x12063e0: ldur            x2, [fp, #-0x10]
    // 0x12063e4: LoadField: r3 = r2->field_13
    //     0x12063e4: ldur            w3, [x2, #0x13]
    // 0x12063e8: DecompressPointer r3
    //     0x12063e8: add             x3, x3, HEAP, lsl #32
    // 0x12063ec: stur            x3, [fp, #-0x20]
    // 0x12063f0: r2 = 60
    //     0x12063f0: mov             x2, #0x3c
    // 0x12063f4: branchIfSmi(r0, 0x1206400)
    //     0x12063f4: tbz             w0, #0, #0x1206400
    // 0x12063f8: r2 = LoadClassIdInstr(r0)
    //     0x12063f8: ldur            x2, [x0, #-1]
    //     0x12063fc: ubfx            x2, x2, #0xc, #0x14
    // 0x1206400: stp             x3, x0, [SP]
    // 0x1206404: mov             x0, x2
    // 0x1206408: mov             lr, x0
    // 0x120640c: ldr             lr, [x21, lr, lsl #3]
    // 0x1206410: blr             lr
    // 0x1206414: tbz             w0, #4, #0x1206490
    // 0x1206418: ldur            x2, [fp, #-0x18]
    // 0x120641c: ldur            x1, [fp, #-8]
    // 0x1206420: ldur            x0, [fp, #-0x20]
    // 0x1206424: ArrayStore: r1[0] = r0  ; List_4
    //     0x1206424: stur            w0, [x1, #0x17]
    //     0x1206428: tbz             w0, #0, #0x1206444
    //     0x120642c: ldurb           w16, [x1, #-1]
    //     0x1206430: ldurb           w17, [x0, #-1]
    //     0x1206434: and             x16, x17, x16, lsr #2
    //     0x1206438: tst             x16, HEAP, lsr #32
    //     0x120643c: b.eq            #0x1206444
    //     0x1206440: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1206444: r0 = LoadClassIdInstr(r2)
    //     0x1206444: ldur            x0, [x2, #-1]
    //     0x1206448: ubfx            x0, x0, #0xc, #0x14
    // 0x120644c: mov             x1, x2
    // 0x1206450: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x1206450: mov             x17, #0xfc0
    //     0x1206454: movk            x17, #1, lsl #16
    //     0x1206458: add             lr, x0, x17
    //     0x120645c: ldr             lr, [x21, lr, lsl #3]
    //     0x1206460: blr             lr
    // 0x1206464: cmp             w0, NULL
    // 0x1206468: b.eq            #0x1206490
    // 0x120646c: r1 = LoadClassIdInstr(r0)
    //     0x120646c: ldur            x1, [x0, #-1]
    //     0x1206470: ubfx            x1, x1, #0xc, #0x14
    // 0x1206474: mov             x16, x0
    // 0x1206478: mov             x0, x1
    // 0x120647c: mov             x1, x16
    // 0x1206480: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0x1206480: mov             x17, #0xfc6d
    //     0x1206484: add             lr, x0, x17
    //     0x1206488: ldr             lr, [x21, lr, lsl #3]
    //     0x120648c: blr             lr
    // 0x1206490: r0 = Null
    //     0x1206490: mov             x0, NULL
    // 0x1206494: LeaveFrame
    //     0x1206494: mov             SP, fp
    //     0x1206498: ldp             fp, lr, [SP], #0x10
    // 0x120649c: ret
    //     0x120649c: ret             
    // 0x12064a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12064a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12064a4: b               #0x120638c
    // 0x12064a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12064a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6794, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DefaultAssetBundle extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xcfa00c, size: 0x5c
    // 0xcfa00c: EnterFrame
    //     0xcfa00c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa010: mov             fp, SP
    // 0xcfa014: AllocStack(0x10)
    //     0xcfa014: sub             SP, SP, #0x10
    // 0xcfa018: CheckStackOverflow
    //     0xcfa018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfa01c: cmp             SP, x16
    //     0xcfa020: b.ls            #0xcfa060
    // 0xcfa024: r16 = <DefaultAssetBundle>
    //     0xcfa024: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d180] TypeArguments: <DefaultAssetBundle>
    //     0xcfa028: ldr             x16, [x16, #0x180]
    // 0xcfa02c: stp             x1, x16, [SP]
    // 0xcfa030: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcfa030: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcfa034: r0 = dependOnInheritedWidgetOfExactType()
    //     0xcfa034: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xcfa038: r0 = LoadStaticField(0x824)
    //     0xcfa038: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xcfa03c: ldr             x0, [x0, #0x1048]
    // 0xcfa040: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcfa044: cmp             w0, w16
    // 0xcfa048: b.ne            #0xcfa054
    // 0xcfa04c: r2 = rootBundle
    //     0xcfa04c: ldr             x2, [PP, #0x3508]  ; [pp+0x3508] Field <::.rootBundle>: static late final (offset: 0x824)
    // 0xcfa050: r0 = InitLateFinalStaticField()
    //     0xcfa050: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xcfa054: LeaveFrame
    //     0xcfa054: mov             SP, fp
    //     0xcfa058: ldp             fp, lr, [SP], #0x10
    // 0xcfa05c: ret
    //     0xcfa05c: ret             
    // 0xcfa060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa060: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa064: b               #0xcfa024
  }
}

// class id: 6796, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class _UbiquitousInheritedWidget extends InheritedWidget {

  _ createElement(/* No info */) {
    // ** addr: 0x10f19a0, size: 0x4c
    // 0x10f19a0: EnterFrame
    //     0x10f19a0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f19a4: mov             fp, SP
    // 0x10f19a8: AllocStack(0x8)
    //     0x10f19a8: sub             SP, SP, #8
    // 0x10f19ac: SetupParameters(_UbiquitousInheritedWidget this /* r1 => r2, fp-0x8 */)
    //     0x10f19ac: mov             x2, x1
    //     0x10f19b0: stur            x1, [fp, #-8]
    // 0x10f19b4: CheckStackOverflow
    //     0x10f19b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f19b8: cmp             SP, x16
    //     0x10f19bc: b.ls            #0x10f19e4
    // 0x10f19c0: r0 = _UbiquitousInheritedElement()
    //     0x10f19c0: bl              #0x10f19ec  ; Allocate_UbiquitousInheritedElementStub -> _UbiquitousInheritedElement (size=0x44)
    // 0x10f19c4: mov             x1, x0
    // 0x10f19c8: ldur            x2, [fp, #-8]
    // 0x10f19cc: stur            x0, [fp, #-8]
    // 0x10f19d0: r0 = InheritedElement()
    //     0x10f19d0: bl              #0x10f18d0  ; [package:flutter/src/widgets/framework.dart] InheritedElement::InheritedElement
    // 0x10f19d4: ldur            x0, [fp, #-8]
    // 0x10f19d8: LeaveFrame
    //     0x10f19d8: mov             SP, fp
    //     0x10f19dc: ldp             fp, lr, [SP], #0x10
    // 0x10f19e0: ret
    //     0x10f19e0: ret             
    // 0x10f19e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f19e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f19e8: b               #0x10f19c0
  }
}

// class id: 6797, size: 0x14, field offset: 0x10
//   const constructor, 
class Directionality extends _UbiquitousInheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0x87371c, size: 0x54
    // 0x87371c: EnterFrame
    //     0x87371c: stp             fp, lr, [SP, #-0x10]!
    //     0x873720: mov             fp, SP
    // 0x873724: AllocStack(0x10)
    //     0x873724: sub             SP, SP, #0x10
    // 0x873728: CheckStackOverflow
    //     0x873728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87372c: cmp             SP, x16
    //     0x873730: b.ls            #0x873764
    // 0x873734: r16 = <Directionality>
    //     0x873734: ldr             x16, [PP, #0x59f8]  ; [pp+0x59f8] TypeArguments: <Directionality>
    // 0x873738: stp             x1, x16, [SP]
    // 0x87373c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x87373c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x873740: r0 = dependOnInheritedWidgetOfExactType()
    //     0x873740: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x873744: cmp             w0, NULL
    // 0x873748: b.eq            #0x87376c
    // 0x87374c: LoadField: r1 = r0->field_f
    //     0x87374c: ldur            w1, [x0, #0xf]
    // 0x873750: DecompressPointer r1
    //     0x873750: add             x1, x1, HEAP, lsl #32
    // 0x873754: mov             x0, x1
    // 0x873758: LeaveFrame
    //     0x873758: mov             SP, fp
    //     0x87375c: ldp             fp, lr, [SP], #0x10
    // 0x873760: ret
    //     0x873760: ret             
    // 0x873764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873768: b               #0x873734
    // 0x87376c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87376c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc01814, size: 0x8c
    // 0xc01814: EnterFrame
    //     0xc01814: stp             fp, lr, [SP, #-0x10]!
    //     0xc01818: mov             fp, SP
    // 0xc0181c: AllocStack(0x10)
    //     0xc0181c: sub             SP, SP, #0x10
    // 0xc01820: SetupParameters(Directionality this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc01820: mov             x0, x2
    //     0xc01824: mov             x4, x1
    //     0xc01828: mov             x3, x2
    //     0xc0182c: stur            x1, [fp, #-8]
    //     0xc01830: stur            x2, [fp, #-0x10]
    // 0xc01834: r2 = Null
    //     0xc01834: mov             x2, NULL
    // 0xc01838: r1 = Null
    //     0xc01838: mov             x1, NULL
    // 0xc0183c: r4 = 60
    //     0xc0183c: mov             x4, #0x3c
    // 0xc01840: branchIfSmi(r0, 0xc0184c)
    //     0xc01840: tbz             w0, #0, #0xc0184c
    // 0xc01844: r4 = LoadClassIdInstr(r0)
    //     0xc01844: ldur            x4, [x0, #-1]
    //     0xc01848: ubfx            x4, x4, #0xc, #0x14
    // 0xc0184c: r17 = 6797
    //     0xc0184c: mov             x17, #0x1a8d
    // 0xc01850: cmp             x4, x17
    // 0xc01854: b.eq            #0xc0186c
    // 0xc01858: r8 = Directionality
    //     0xc01858: add             x8, PP, #0xe, lsl #12  ; [pp+0xe168] Type: Directionality
    //     0xc0185c: ldr             x8, [x8, #0x168]
    // 0xc01860: r3 = Null
    //     0xc01860: add             x3, PP, #0x99, lsl #12  ; [pp+0x99dd0] Null
    //     0xc01864: ldr             x3, [x3, #0xdd0]
    // 0xc01868: r0 = Directionality()
    //     0xc01868: bl              #0x873770  ; IsType_Directionality_Stub
    // 0xc0186c: ldur            x1, [fp, #-8]
    // 0xc01870: LoadField: r2 = r1->field_f
    //     0xc01870: ldur            w2, [x1, #0xf]
    // 0xc01874: DecompressPointer r2
    //     0xc01874: add             x2, x2, HEAP, lsl #32
    // 0xc01878: ldur            x1, [fp, #-0x10]
    // 0xc0187c: LoadField: r3 = r1->field_f
    //     0xc0187c: ldur            w3, [x1, #0xf]
    // 0xc01880: DecompressPointer r3
    //     0xc01880: add             x3, x3, HEAP, lsl #32
    // 0xc01884: cmp             w2, w3
    // 0xc01888: r16 = true
    //     0xc01888: add             x16, NULL, #0x20  ; true
    // 0xc0188c: r17 = false
    //     0xc0188c: add             x17, NULL, #0x30  ; false
    // 0xc01890: csel            x0, x16, x17, ne
    // 0xc01894: LeaveFrame
    //     0xc01894: mov             SP, fp
    //     0xc01898: ldp             fp, lr, [SP], #0x10
    // 0xc0189c: ret
    //     0xc0189c: ret             
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xcee820, size: 0x58
    // 0xcee820: EnterFrame
    //     0xcee820: stp             fp, lr, [SP, #-0x10]!
    //     0xcee824: mov             fp, SP
    // 0xcee828: AllocStack(0x10)
    //     0xcee828: sub             SP, SP, #0x10
    // 0xcee82c: CheckStackOverflow
    //     0xcee82c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee830: cmp             SP, x16
    //     0xcee834: b.ls            #0xcee870
    // 0xcee838: r16 = <Directionality>
    //     0xcee838: ldr             x16, [PP, #0x59f8]  ; [pp+0x59f8] TypeArguments: <Directionality>
    // 0xcee83c: stp             x1, x16, [SP]
    // 0xcee840: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcee840: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcee844: r0 = dependOnInheritedWidgetOfExactType()
    //     0xcee844: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xcee848: cmp             w0, NULL
    // 0xcee84c: b.ne            #0xcee858
    // 0xcee850: r0 = Null
    //     0xcee850: mov             x0, NULL
    // 0xcee854: b               #0xcee864
    // 0xcee858: LoadField: r1 = r0->field_f
    //     0xcee858: ldur            w1, [x0, #0xf]
    // 0xcee85c: DecompressPointer r1
    //     0xcee85c: add             x1, x1, HEAP, lsl #32
    // 0xcee860: mov             x0, x1
    // 0xcee864: LeaveFrame
    //     0xcee864: mov             SP, fp
    //     0xcee868: ldp             fp, lr, [SP], #0x10
    // 0xcee86c: ret
    //     0xcee86c: ret             
    // 0xcee870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee874: b               #0xcee838
  }
}
