// lib: , url: package:flutter/src/widgets/bottom_navigation_bar_item.dart

// class id: 1049122, size: 0x8
class :: {
}

// class id: 2715, size: 0x24, field offset: 0x8
//   const constructor, 
class BottomNavigationBarItem extends Object {
}
