// lib: , url: package:flutter/src/widgets/animated_size.dart

// class id: 1049112, size: 0x8
class :: {
}

// class id: 5677, size: 0x1c, field offset: 0x1c
class _AnimatedSizeState extends _MixinApplication188&State&SingleTickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd5c228, size: 0x98
    // 0xd5c228: EnterFrame
    //     0xd5c228: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c22c: mov             fp, SP
    // 0xd5c230: AllocStack(0x28)
    //     0xd5c230: sub             SP, SP, #0x28
    // 0xd5c234: SetupParameters(_AnimatedSizeState this /* r1 => r1, fp-0x28 */)
    //     0xd5c234: stur            x1, [fp, #-0x28]
    // 0xd5c238: LoadField: r0 = r1->field_b
    //     0xd5c238: ldur            w0, [x1, #0xb]
    // 0xd5c23c: DecompressPointer r0
    //     0xd5c23c: add             x0, x0, HEAP, lsl #32
    // 0xd5c240: cmp             w0, NULL
    // 0xd5c244: b.eq            #0xd5c2bc
    // 0xd5c248: LoadField: r2 = r0->field_f
    //     0xd5c248: ldur            w2, [x0, #0xf]
    // 0xd5c24c: DecompressPointer r2
    //     0xd5c24c: add             x2, x2, HEAP, lsl #32
    // 0xd5c250: stur            x2, [fp, #-0x20]
    // 0xd5c254: LoadField: r3 = r0->field_13
    //     0xd5c254: ldur            w3, [x0, #0x13]
    // 0xd5c258: DecompressPointer r3
    //     0xd5c258: add             x3, x3, HEAP, lsl #32
    // 0xd5c25c: stur            x3, [fp, #-0x18]
    // 0xd5c260: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xd5c260: ldur            w4, [x0, #0x17]
    // 0xd5c264: DecompressPointer r4
    //     0xd5c264: add             x4, x4, HEAP, lsl #32
    // 0xd5c268: stur            x4, [fp, #-0x10]
    // 0xd5c26c: LoadField: r5 = r0->field_b
    //     0xd5c26c: ldur            w5, [x0, #0xb]
    // 0xd5c270: DecompressPointer r5
    //     0xd5c270: add             x5, x5, HEAP, lsl #32
    // 0xd5c274: stur            x5, [fp, #-8]
    // 0xd5c278: r0 = _AnimatedSize()
    //     0xd5c278: bl              #0xd5c2c0  ; Allocate_AnimatedSizeStub -> _AnimatedSize (size=0x2c)
    // 0xd5c27c: ldur            x1, [fp, #-0x20]
    // 0xd5c280: StoreField: r0->field_f = r1
    //     0xd5c280: stur            w1, [x0, #0xf]
    // 0xd5c284: ldur            x1, [fp, #-0x18]
    // 0xd5c288: StoreField: r0->field_13 = r1
    //     0xd5c288: stur            w1, [x0, #0x13]
    // 0xd5c28c: ldur            x1, [fp, #-0x10]
    // 0xd5c290: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5c290: stur            w1, [x0, #0x17]
    // 0xd5c294: ldur            x1, [fp, #-0x28]
    // 0xd5c298: StoreField: r0->field_1f = r1
    //     0xd5c298: stur            w1, [x0, #0x1f]
    // 0xd5c29c: r1 = Instance_Clip
    //     0xd5c29c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd5c2a0: ldr             x1, [x1, #0x850]
    // 0xd5c2a4: StoreField: r0->field_23 = r1
    //     0xd5c2a4: stur            w1, [x0, #0x23]
    // 0xd5c2a8: ldur            x1, [fp, #-8]
    // 0xd5c2ac: StoreField: r0->field_b = r1
    //     0xd5c2ac: stur            w1, [x0, #0xb]
    // 0xd5c2b0: LeaveFrame
    //     0xd5c2b0: mov             SP, fp
    //     0xd5c2b4: ldp             fp, lr, [SP], #0x10
    // 0xd5c2b8: ret
    //     0xd5c2b8: ret             
    // 0xd5c2bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5c2bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6407, size: 0x28, field offset: 0xc
//   const constructor, 
class AnimatedSize extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3734, size: 0x24
    // 0xfa3734: EnterFrame
    //     0xfa3734: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3738: mov             fp, SP
    // 0xfa373c: mov             x0, x1
    // 0xfa3740: r1 = <AnimatedSize>
    //     0xfa3740: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f408] TypeArguments: <AnimatedSize>
    //     0xfa3744: ldr             x1, [x1, #0x408]
    // 0xfa3748: r0 = _AnimatedSizeState()
    //     0xfa3748: bl              #0xfa3758  ; Allocate_AnimatedSizeStateStub -> _AnimatedSizeState (size=0x1c)
    // 0xfa374c: LeaveFrame
    //     0xfa374c: mov             SP, fp
    //     0xfa3750: ldp             fp, lr, [SP], #0x10
    // 0xfa3754: ret
    //     0xfa3754: ret             
  }
}

// class id: 6649, size: 0x2c, field offset: 0x10
//   const constructor, 
class _AnimatedSize extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4e2c, size: 0x138
    // 0xcf4e2c: EnterFrame
    //     0xcf4e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4e30: mov             fp, SP
    // 0xcf4e34: AllocStack(0x18)
    //     0xcf4e34: sub             SP, SP, #0x18
    // 0xcf4e38: SetupParameters(_AnimatedSize this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf4e38: mov             x5, x1
    //     0xcf4e3c: mov             x4, x2
    //     0xcf4e40: stur            x1, [fp, #-8]
    //     0xcf4e44: stur            x2, [fp, #-0x10]
    //     0xcf4e48: stur            x3, [fp, #-0x18]
    // 0xcf4e4c: CheckStackOverflow
    //     0xcf4e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4e50: cmp             SP, x16
    //     0xcf4e54: b.ls            #0xcf4f5c
    // 0xcf4e58: mov             x0, x3
    // 0xcf4e5c: r2 = Null
    //     0xcf4e5c: mov             x2, NULL
    // 0xcf4e60: r1 = Null
    //     0xcf4e60: mov             x1, NULL
    // 0xcf4e64: r4 = 60
    //     0xcf4e64: mov             x4, #0x3c
    // 0xcf4e68: branchIfSmi(r0, 0xcf4e74)
    //     0xcf4e68: tbz             w0, #0, #0xcf4e74
    // 0xcf4e6c: r4 = LoadClassIdInstr(r0)
    //     0xcf4e6c: ldur            x4, [x0, #-1]
    //     0xcf4e70: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4e74: r17 = 4887
    //     0xcf4e74: mov             x17, #0x1317
    // 0xcf4e78: cmp             x4, x17
    // 0xcf4e7c: b.eq            #0xcf4e94
    // 0xcf4e80: r8 = RenderAnimatedSize
    //     0xcf4e80: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3490] Type: RenderAnimatedSize
    //     0xcf4e84: ldr             x8, [x8, #0x490]
    // 0xcf4e88: r3 = Null
    //     0xcf4e88: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3498] Null
    //     0xcf4e8c: ldr             x3, [x3, #0x498]
    // 0xcf4e90: r0 = DefaultTypeTest()
    //     0xcf4e90: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4e94: ldur            x0, [fp, #-8]
    // 0xcf4e98: LoadField: r2 = r0->field_f
    //     0xcf4e98: ldur            w2, [x0, #0xf]
    // 0xcf4e9c: DecompressPointer r2
    //     0xcf4e9c: add             x2, x2, HEAP, lsl #32
    // 0xcf4ea0: ldur            x1, [fp, #-0x18]
    // 0xcf4ea4: r0 = alignment=()
    //     0xcf4ea4: bl              #0xcf5338  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignment=
    // 0xcf4ea8: ldur            x0, [fp, #-8]
    // 0xcf4eac: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf4eac: ldur            w2, [x0, #0x17]
    // 0xcf4eb0: DecompressPointer r2
    //     0xcf4eb0: add             x2, x2, HEAP, lsl #32
    // 0xcf4eb4: ldur            x1, [fp, #-0x18]
    // 0xcf4eb8: r0 = duration=()
    //     0xcf4eb8: bl              #0xcf528c  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::duration=
    // 0xcf4ebc: ldur            x1, [fp, #-0x18]
    // 0xcf4ec0: r2 = Null
    //     0xcf4ec0: mov             x2, NULL
    // 0xcf4ec4: r0 = reverseDuration=()
    //     0xcf4ec4: bl              #0xcf5240  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::reverseDuration=
    // 0xcf4ec8: ldur            x0, [fp, #-8]
    // 0xcf4ecc: LoadField: r2 = r0->field_13
    //     0xcf4ecc: ldur            w2, [x0, #0x13]
    // 0xcf4ed0: DecompressPointer r2
    //     0xcf4ed0: add             x2, x2, HEAP, lsl #32
    // 0xcf4ed4: ldur            x1, [fp, #-0x18]
    // 0xcf4ed8: r0 = curve=()
    //     0xcf4ed8: bl              #0xcf51d0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::curve=
    // 0xcf4edc: ldur            x0, [fp, #-8]
    // 0xcf4ee0: LoadField: r2 = r0->field_1f
    //     0xcf4ee0: ldur            w2, [x0, #0x1f]
    // 0xcf4ee4: DecompressPointer r2
    //     0xcf4ee4: add             x2, x2, HEAP, lsl #32
    // 0xcf4ee8: ldur            x1, [fp, #-0x18]
    // 0xcf4eec: r0 = vsync=()
    //     0xcf4eec: bl              #0xcf4f64  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::vsync=
    // 0xcf4ef0: ldur            x1, [fp, #-0x10]
    // 0xcf4ef4: r0 = maybeOf()
    //     0xcf4ef4: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xcf4ef8: ldur            x2, [fp, #-0x18]
    // 0xcf4efc: LoadField: r1 = r2->field_5b
    //     0xcf4efc: ldur            w1, [x2, #0x5b]
    // 0xcf4f00: DecompressPointer r1
    //     0xcf4f00: add             x1, x1, HEAP, lsl #32
    // 0xcf4f04: cmp             w1, w0
    // 0xcf4f08: b.eq            #0xcf4f30
    // 0xcf4f0c: StoreField: r2->field_5b = r0
    //     0xcf4f0c: stur            w0, [x2, #0x5b]
    //     0xcf4f10: ldurb           w16, [x2, #-1]
    //     0xcf4f14: ldurb           w17, [x0, #-1]
    //     0xcf4f18: and             x16, x17, x16, lsr #2
    //     0xcf4f1c: tst             x16, HEAP, lsr #32
    //     0xcf4f20: b.eq            #0xcf4f28
    //     0xcf4f24: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf4f28: mov             x1, x2
    // 0xcf4f2c: r0 = _markNeedResolution()
    //     0xcf4f2c: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf4f30: ldur            x1, [fp, #-0x18]
    // 0xcf4f34: r2 = Instance_Clip
    //     0xcf4f34: add             x2, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xcf4f38: ldr             x2, [x2, #0x850]
    // 0xcf4f3c: r0 = Shader._()
    //     0xcf4f3c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf4f40: ldur            x1, [fp, #-0x18]
    // 0xcf4f44: r2 = Null
    //     0xcf4f44: mov             x2, NULL
    // 0xcf4f48: r0 = Shader._()
    //     0xcf4f48: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf4f4c: r0 = Null
    //     0xcf4f4c: mov             x0, NULL
    // 0xcf4f50: LeaveFrame
    //     0xcf4f50: mov             SP, fp
    //     0xcf4f54: ldp             fp, lr, [SP], #0x10
    // 0xcf4f58: ret
    //     0xcf4f58: ret             
    // 0xcf4f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4f5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4f60: b               #0xcf4e58
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cfd04, size: 0x94
    // 0x11cfd04: EnterFrame
    //     0x11cfd04: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfd08: mov             fp, SP
    // 0x11cfd0c: AllocStack(0x28)
    //     0x11cfd0c: sub             SP, SP, #0x28
    // 0x11cfd10: SetupParameters(_AnimatedSize this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11cfd10: mov             x0, x1
    //     0x11cfd14: mov             x1, x2
    // 0x11cfd18: CheckStackOverflow
    //     0x11cfd18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfd1c: cmp             SP, x16
    //     0x11cfd20: b.ls            #0x11cfd90
    // 0x11cfd24: LoadField: r2 = r0->field_f
    //     0x11cfd24: ldur            w2, [x0, #0xf]
    // 0x11cfd28: DecompressPointer r2
    //     0x11cfd28: add             x2, x2, HEAP, lsl #32
    // 0x11cfd2c: stur            x2, [fp, #-0x20]
    // 0x11cfd30: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11cfd30: ldur            w5, [x0, #0x17]
    // 0x11cfd34: DecompressPointer r5
    //     0x11cfd34: add             x5, x5, HEAP, lsl #32
    // 0x11cfd38: stur            x5, [fp, #-0x18]
    // 0x11cfd3c: LoadField: r3 = r0->field_13
    //     0x11cfd3c: ldur            w3, [x0, #0x13]
    // 0x11cfd40: DecompressPointer r3
    //     0x11cfd40: add             x3, x3, HEAP, lsl #32
    // 0x11cfd44: stur            x3, [fp, #-0x10]
    // 0x11cfd48: LoadField: r7 = r0->field_1f
    //     0x11cfd48: ldur            w7, [x0, #0x1f]
    // 0x11cfd4c: DecompressPointer r7
    //     0x11cfd4c: add             x7, x7, HEAP, lsl #32
    // 0x11cfd50: stur            x7, [fp, #-8]
    // 0x11cfd54: r0 = maybeOf()
    //     0x11cfd54: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x11cfd58: stur            x0, [fp, #-0x28]
    // 0x11cfd5c: r0 = RenderAnimatedSize()
    //     0x11cfd5c: bl              #0x11d00e0  ; AllocateRenderAnimatedSizeStub -> RenderAnimatedSize (size=0x8c)
    // 0x11cfd60: mov             x1, x0
    // 0x11cfd64: ldur            x2, [fp, #-0x20]
    // 0x11cfd68: ldur            x3, [fp, #-0x10]
    // 0x11cfd6c: ldur            x5, [fp, #-0x18]
    // 0x11cfd70: ldur            x6, [fp, #-0x28]
    // 0x11cfd74: ldur            x7, [fp, #-8]
    // 0x11cfd78: stur            x0, [fp, #-8]
    // 0x11cfd7c: r0 = RenderAnimatedSize()
    //     0x11cfd7c: bl              #0x11cfd98  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::RenderAnimatedSize
    // 0x11cfd80: ldur            x0, [fp, #-8]
    // 0x11cfd84: LeaveFrame
    //     0x11cfd84: mov             SP, fp
    //     0x11cfd88: ldp             fp, lr, [SP], #0x10
    // 0x11cfd8c: ret
    //     0x11cfd8c: ret             
    // 0x11cfd90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfd90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfd94: b               #0x11cfd24
  }
}
