// lib: , url: package:flutter/src/widgets/context_menu_button_item.dart

// class id: 1049124, size: 0x8
class :: {
}

// class id: 2714, size: 0x14, field offset: 0x8
//   const constructor, 
class ContextMenuButtonItem extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114d174, size: 0x6c
    // 0x114d174: EnterFrame
    //     0x114d174: stp             fp, lr, [SP, #-0x10]!
    //     0x114d178: mov             fp, SP
    // 0x114d17c: AllocStack(0x8)
    //     0x114d17c: sub             SP, SP, #8
    // 0x114d180: CheckStackOverflow
    //     0x114d180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114d184: cmp             SP, x16
    //     0x114d188: b.ls            #0x114d1d8
    // 0x114d18c: ldr             x0, [fp, #0x10]
    // 0x114d190: LoadField: r1 = r0->field_f
    //     0x114d190: ldur            w1, [x0, #0xf]
    // 0x114d194: DecompressPointer r1
    //     0x114d194: add             x1, x1, HEAP, lsl #32
    // 0x114d198: LoadField: r2 = r0->field_7
    //     0x114d198: ldur            w2, [x0, #7]
    // 0x114d19c: DecompressPointer r2
    //     0x114d19c: add             x2, x2, HEAP, lsl #32
    // 0x114d1a0: LoadField: r3 = r0->field_b
    //     0x114d1a0: ldur            w3, [x0, #0xb]
    // 0x114d1a4: DecompressPointer r3
    //     0x114d1a4: add             x3, x3, HEAP, lsl #32
    // 0x114d1a8: str             x3, [SP]
    // 0x114d1ac: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114d1ac: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114d1b0: r0 = hash()
    //     0x114d1b0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114d1b4: mov             x2, x0
    // 0x114d1b8: r0 = BoxInt64Instr(r2)
    //     0x114d1b8: sbfiz           x0, x2, #1, #0x1f
    //     0x114d1bc: cmp             x2, x0, asr #1
    //     0x114d1c0: b.eq            #0x114d1cc
    //     0x114d1c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114d1c8: stur            x2, [x0, #7]
    // 0x114d1cc: LeaveFrame
    //     0x114d1cc: mov             SP, fp
    //     0x114d1d0: ldp             fp, lr, [SP], #0x10
    // 0x114d1d4: ret
    //     0x114d1d4: ret             
    // 0x114d1d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114d1d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114d1dc: b               #0x114d18c
  }
  _ ==(/* No info */) {
    // ** addr: 0x129b560, size: 0x144
    // 0x129b560: EnterFrame
    //     0x129b560: stp             fp, lr, [SP, #-0x10]!
    //     0x129b564: mov             fp, SP
    // 0x129b568: AllocStack(0x10)
    //     0x129b568: sub             SP, SP, #0x10
    // 0x129b56c: CheckStackOverflow
    //     0x129b56c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129b570: cmp             SP, x16
    //     0x129b574: b.ls            #0x129b69c
    // 0x129b578: ldr             x0, [fp, #0x10]
    // 0x129b57c: cmp             w0, NULL
    // 0x129b580: b.ne            #0x129b594
    // 0x129b584: r0 = false
    //     0x129b584: add             x0, NULL, #0x30  ; false
    // 0x129b588: LeaveFrame
    //     0x129b588: mov             SP, fp
    //     0x129b58c: ldp             fp, lr, [SP], #0x10
    // 0x129b590: ret
    //     0x129b590: ret             
    // 0x129b594: str             x0, [SP]
    // 0x129b598: r0 = runtimeType()
    //     0x129b598: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129b59c: r1 = LoadClassIdInstr(r0)
    //     0x129b59c: ldur            x1, [x0, #-1]
    //     0x129b5a0: ubfx            x1, x1, #0xc, #0x14
    // 0x129b5a4: r16 = ContextMenuButtonItem
    //     0x129b5a4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ee0] Type: ContextMenuButtonItem
    //     0x129b5a8: ldr             x16, [x16, #0xee0]
    // 0x129b5ac: stp             x16, x0, [SP]
    // 0x129b5b0: mov             x0, x1
    // 0x129b5b4: mov             lr, x0
    // 0x129b5b8: ldr             lr, [x21, lr, lsl #3]
    // 0x129b5bc: blr             lr
    // 0x129b5c0: tbz             w0, #4, #0x129b5d4
    // 0x129b5c4: r0 = false
    //     0x129b5c4: add             x0, NULL, #0x30  ; false
    // 0x129b5c8: LeaveFrame
    //     0x129b5c8: mov             SP, fp
    //     0x129b5cc: ldp             fp, lr, [SP], #0x10
    // 0x129b5d0: ret
    //     0x129b5d0: ret             
    // 0x129b5d4: ldr             x1, [fp, #0x10]
    // 0x129b5d8: r0 = 60
    //     0x129b5d8: mov             x0, #0x3c
    // 0x129b5dc: branchIfSmi(r1, 0x129b5e8)
    //     0x129b5dc: tbz             w1, #0, #0x129b5e8
    // 0x129b5e0: r0 = LoadClassIdInstr(r1)
    //     0x129b5e0: ldur            x0, [x1, #-1]
    //     0x129b5e4: ubfx            x0, x0, #0xc, #0x14
    // 0x129b5e8: cmp             x0, #0xa9a
    // 0x129b5ec: b.ne            #0x129b68c
    // 0x129b5f0: ldr             x2, [fp, #0x18]
    // 0x129b5f4: LoadField: r0 = r1->field_f
    //     0x129b5f4: ldur            w0, [x1, #0xf]
    // 0x129b5f8: DecompressPointer r0
    //     0x129b5f8: add             x0, x0, HEAP, lsl #32
    // 0x129b5fc: LoadField: r3 = r2->field_f
    //     0x129b5fc: ldur            w3, [x2, #0xf]
    // 0x129b600: DecompressPointer r3
    //     0x129b600: add             x3, x3, HEAP, lsl #32
    // 0x129b604: r4 = LoadClassIdInstr(r0)
    //     0x129b604: ldur            x4, [x0, #-1]
    //     0x129b608: ubfx            x4, x4, #0xc, #0x14
    // 0x129b60c: stp             x3, x0, [SP]
    // 0x129b610: mov             x0, x4
    // 0x129b614: mov             lr, x0
    // 0x129b618: ldr             lr, [x21, lr, lsl #3]
    // 0x129b61c: blr             lr
    // 0x129b620: tbnz            w0, #4, #0x129b68c
    // 0x129b624: ldr             x2, [fp, #0x18]
    // 0x129b628: ldr             x1, [fp, #0x10]
    // 0x129b62c: LoadField: r0 = r1->field_7
    //     0x129b62c: ldur            w0, [x1, #7]
    // 0x129b630: DecompressPointer r0
    //     0x129b630: add             x0, x0, HEAP, lsl #32
    // 0x129b634: LoadField: r3 = r2->field_7
    //     0x129b634: ldur            w3, [x2, #7]
    // 0x129b638: DecompressPointer r3
    //     0x129b638: add             x3, x3, HEAP, lsl #32
    // 0x129b63c: r4 = LoadClassIdInstr(r0)
    //     0x129b63c: ldur            x4, [x0, #-1]
    //     0x129b640: ubfx            x4, x4, #0xc, #0x14
    // 0x129b644: stp             x3, x0, [SP]
    // 0x129b648: mov             x0, x4
    // 0x129b64c: mov             lr, x0
    // 0x129b650: ldr             lr, [x21, lr, lsl #3]
    // 0x129b654: blr             lr
    // 0x129b658: tbnz            w0, #4, #0x129b68c
    // 0x129b65c: ldr             x2, [fp, #0x18]
    // 0x129b660: ldr             x1, [fp, #0x10]
    // 0x129b664: LoadField: r3 = r1->field_b
    //     0x129b664: ldur            w3, [x1, #0xb]
    // 0x129b668: DecompressPointer r3
    //     0x129b668: add             x3, x3, HEAP, lsl #32
    // 0x129b66c: LoadField: r1 = r2->field_b
    //     0x129b66c: ldur            w1, [x2, #0xb]
    // 0x129b670: DecompressPointer r1
    //     0x129b670: add             x1, x1, HEAP, lsl #32
    // 0x129b674: cmp             w3, w1
    // 0x129b678: r16 = true
    //     0x129b678: add             x16, NULL, #0x20  ; true
    // 0x129b67c: r17 = false
    //     0x129b67c: add             x17, NULL, #0x30  ; false
    // 0x129b680: csel            x2, x16, x17, eq
    // 0x129b684: mov             x0, x2
    // 0x129b688: b               #0x129b690
    // 0x129b68c: r0 = false
    //     0x129b68c: add             x0, NULL, #0x30  ; false
    // 0x129b690: LeaveFrame
    //     0x129b690: mov             SP, fp
    //     0x129b694: ldp             fp, lr, [SP], #0x10
    // 0x129b698: ret
    //     0x129b698: ret             
    // 0x129b69c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129b69c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129b6a0: b               #0x129b578
  }
}

// class id: 8188, size: 0x14, field offset: 0x14
enum ContextMenuButtonType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abddc, size: 0x64
    // 0x11abddc: EnterFrame
    //     0x11abddc: stp             fp, lr, [SP, #-0x10]!
    //     0x11abde0: mov             fp, SP
    // 0x11abde4: AllocStack(0x10)
    //     0x11abde4: sub             SP, SP, #0x10
    // 0x11abde8: SetupParameters(ContextMenuButtonType this /* r1 => r0, fp-0x8 */)
    //     0x11abde8: mov             x0, x1
    //     0x11abdec: stur            x1, [fp, #-8]
    // 0x11abdf0: CheckStackOverflow
    //     0x11abdf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abdf4: cmp             SP, x16
    //     0x11abdf8: b.ls            #0x11abe38
    // 0x11abdfc: r1 = Null
    //     0x11abdfc: mov             x1, NULL
    // 0x11abe00: r2 = 4
    //     0x11abe00: mov             x2, #4
    // 0x11abe04: r0 = AllocateArray()
    //     0x11abe04: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abe08: r16 = "ContextMenuButtonType."
    //     0x11abe08: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ee8] "ContextMenuButtonType."
    //     0x11abe0c: ldr             x16, [x16, #0xee8]
    // 0x11abe10: StoreField: r0->field_f = r16
    //     0x11abe10: stur            w16, [x0, #0xf]
    // 0x11abe14: ldur            x1, [fp, #-8]
    // 0x11abe18: LoadField: r2 = r1->field_f
    //     0x11abe18: ldur            w2, [x1, #0xf]
    // 0x11abe1c: DecompressPointer r2
    //     0x11abe1c: add             x2, x2, HEAP, lsl #32
    // 0x11abe20: StoreField: r0->field_13 = r2
    //     0x11abe20: stur            w2, [x0, #0x13]
    // 0x11abe24: str             x0, [SP]
    // 0x11abe28: r0 = _interpolate()
    //     0x11abe28: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abe2c: LeaveFrame
    //     0x11abe2c: mov             SP, fp
    //     0x11abe30: ldp             fp, lr, [SP], #0x10
    // 0x11abe34: ret
    //     0x11abe34: ret             
    // 0x11abe38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abe38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abe3c: b               #0x11abdfc
  }
}
