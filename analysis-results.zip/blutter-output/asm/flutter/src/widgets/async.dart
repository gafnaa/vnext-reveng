// lib: , url: package:flutter/src/widgets/async.dart

// class id: 1049117, size: 0x8
class :: {
}

// class id: 2716, size: 0x1c, field offset: 0x8
//   const constructor, 
class AsyncSnapshot<X0> extends Object {

  get _ requireData(/* No info */) {
    // ** addr: 0xe58c50, size: 0x88
    // 0xe58c50: EnterFrame
    //     0xe58c50: stp             fp, lr, [SP, #-0x10]!
    //     0xe58c54: mov             fp, SP
    // 0xe58c58: CheckStackOverflow
    //     0xe58c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe58c5c: cmp             SP, x16
    //     0xe58c60: b.ls            #0xe58ccc
    // 0xe58c64: LoadField: r0 = r1->field_f
    //     0xe58c64: ldur            w0, [x1, #0xf]
    // 0xe58c68: DecompressPointer r0
    //     0xe58c68: add             x0, x0, HEAP, lsl #32
    // 0xe58c6c: cmp             w0, NULL
    // 0xe58c70: b.eq            #0xe58c80
    // 0xe58c74: LeaveFrame
    //     0xe58c74: mov             SP, fp
    //     0xe58c78: ldp             fp, lr, [SP], #0x10
    // 0xe58c7c: ret
    //     0xe58c7c: ret             
    // 0xe58c80: LoadField: r0 = r1->field_13
    //     0xe58c80: ldur            w0, [x1, #0x13]
    // 0xe58c84: DecompressPointer r0
    //     0xe58c84: add             x0, x0, HEAP, lsl #32
    // 0xe58c88: cmp             w0, NULL
    // 0xe58c8c: b.eq            #0xe58cac
    // 0xe58c90: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xe58c90: ldur            w2, [x1, #0x17]
    // 0xe58c94: DecompressPointer r2
    //     0xe58c94: add             x2, x2, HEAP, lsl #32
    // 0xe58c98: cmp             w2, NULL
    // 0xe58c9c: b.eq            #0xe58cd4
    // 0xe58ca0: mov             x1, x0
    // 0xe58ca4: r0 = throwWithStackTrace()
    //     0xe58ca4: bl              #0x7f11c0  ; [dart:core] Error::throwWithStackTrace
    // 0xe58ca8: brk             #0
    // 0xe58cac: r0 = StateError()
    //     0xe58cac: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xe58cb0: mov             x1, x0
    // 0xe58cb4: r0 = "Snapshot has neither data nor error"
    //     0xe58cb4: add             x0, PP, #0x88, lsl #12  ; [pp+0x88e38] "Snapshot has neither data nor error"
    //     0xe58cb8: ldr             x0, [x0, #0xe38]
    // 0xe58cbc: StoreField: r1->field_b = r0
    //     0xe58cbc: stur            w0, [x1, #0xb]
    // 0xe58cc0: mov             x0, x1
    // 0xe58cc4: r0 = Throw()
    //     0xe58cc4: bl              #0x13ddb2c  ; ThrowStub
    // 0xe58cc8: brk             #0
    // 0xe58ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe58ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe58cd0: b               #0xe58c64
    // 0xe58cd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe58cd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ inState(/* No info */) {
    // ** addr: 0xf6ff54, size: 0x70
    // 0xf6ff54: EnterFrame
    //     0xf6ff54: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ff58: mov             fp, SP
    // 0xf6ff5c: AllocStack(0x20)
    //     0xf6ff5c: sub             SP, SP, #0x20
    // 0xf6ff60: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xf6ff60: stur            x2, [fp, #-0x20]
    // 0xf6ff64: LoadField: r0 = r1->field_7
    //     0xf6ff64: ldur            w0, [x1, #7]
    // 0xf6ff68: DecompressPointer r0
    //     0xf6ff68: add             x0, x0, HEAP, lsl #32
    // 0xf6ff6c: LoadField: r3 = r1->field_f
    //     0xf6ff6c: ldur            w3, [x1, #0xf]
    // 0xf6ff70: DecompressPointer r3
    //     0xf6ff70: add             x3, x3, HEAP, lsl #32
    // 0xf6ff74: stur            x3, [fp, #-0x18]
    // 0xf6ff78: LoadField: r4 = r1->field_13
    //     0xf6ff78: ldur            w4, [x1, #0x13]
    // 0xf6ff7c: DecompressPointer r4
    //     0xf6ff7c: add             x4, x4, HEAP, lsl #32
    // 0xf6ff80: stur            x4, [fp, #-0x10]
    // 0xf6ff84: ArrayLoad: r5 = r1[0]  ; List_4
    //     0xf6ff84: ldur            w5, [x1, #0x17]
    // 0xf6ff88: DecompressPointer r5
    //     0xf6ff88: add             x5, x5, HEAP, lsl #32
    // 0xf6ff8c: mov             x1, x0
    // 0xf6ff90: stur            x5, [fp, #-8]
    // 0xf6ff94: r0 = AsyncSnapshot()
    //     0xf6ff94: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf6ff98: ldur            x1, [fp, #-0x20]
    // 0xf6ff9c: StoreField: r0->field_b = r1
    //     0xf6ff9c: stur            w1, [x0, #0xb]
    // 0xf6ffa0: ldur            x1, [fp, #-0x18]
    // 0xf6ffa4: StoreField: r0->field_f = r1
    //     0xf6ffa4: stur            w1, [x0, #0xf]
    // 0xf6ffa8: ldur            x1, [fp, #-0x10]
    // 0xf6ffac: StoreField: r0->field_13 = r1
    //     0xf6ffac: stur            w1, [x0, #0x13]
    // 0xf6ffb0: ldur            x1, [fp, #-8]
    // 0xf6ffb4: ArrayStore: r0[0] = r1  ; List_4
    //     0xf6ffb4: stur            w1, [x0, #0x17]
    // 0xf6ffb8: LeaveFrame
    //     0xf6ffb8: mov             SP, fp
    //     0xf6ffbc: ldp             fp, lr, [SP], #0x10
    // 0xf6ffc0: ret
    //     0xf6ffc0: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114d108, size: 0x6c
    // 0x114d108: EnterFrame
    //     0x114d108: stp             fp, lr, [SP, #-0x10]!
    //     0x114d10c: mov             fp, SP
    // 0x114d110: AllocStack(0x8)
    //     0x114d110: sub             SP, SP, #8
    // 0x114d114: CheckStackOverflow
    //     0x114d114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114d118: cmp             SP, x16
    //     0x114d11c: b.ls            #0x114d16c
    // 0x114d120: ldr             x0, [fp, #0x10]
    // 0x114d124: LoadField: r1 = r0->field_b
    //     0x114d124: ldur            w1, [x0, #0xb]
    // 0x114d128: DecompressPointer r1
    //     0x114d128: add             x1, x1, HEAP, lsl #32
    // 0x114d12c: LoadField: r2 = r0->field_f
    //     0x114d12c: ldur            w2, [x0, #0xf]
    // 0x114d130: DecompressPointer r2
    //     0x114d130: add             x2, x2, HEAP, lsl #32
    // 0x114d134: LoadField: r3 = r0->field_13
    //     0x114d134: ldur            w3, [x0, #0x13]
    // 0x114d138: DecompressPointer r3
    //     0x114d138: add             x3, x3, HEAP, lsl #32
    // 0x114d13c: str             x3, [SP]
    // 0x114d140: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114d140: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114d144: r0 = hash()
    //     0x114d144: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114d148: mov             x2, x0
    // 0x114d14c: r0 = BoxInt64Instr(r2)
    //     0x114d14c: sbfiz           x0, x2, #1, #0x1f
    //     0x114d150: cmp             x2, x0, asr #1
    //     0x114d154: b.eq            #0x114d160
    //     0x114d158: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114d15c: stur            x2, [x0, #7]
    // 0x114d160: LeaveFrame
    //     0x114d160: mov             SP, fp
    //     0x114d164: ldp             fp, lr, [SP], #0x10
    // 0x114d168: ret
    //     0x114d168: ret             
    // 0x114d16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114d16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114d170: b               #0x114d120
  }
  _ ==(/* No info */) {
    // ** addr: 0x129b3b8, size: 0x1a8
    // 0x129b3b8: EnterFrame
    //     0x129b3b8: stp             fp, lr, [SP, #-0x10]!
    //     0x129b3bc: mov             fp, SP
    // 0x129b3c0: AllocStack(0x10)
    //     0x129b3c0: sub             SP, SP, #0x10
    // 0x129b3c4: CheckStackOverflow
    //     0x129b3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129b3c8: cmp             SP, x16
    //     0x129b3cc: b.ls            #0x129b558
    // 0x129b3d0: ldr             x3, [fp, #0x10]
    // 0x129b3d4: cmp             w3, NULL
    // 0x129b3d8: b.ne            #0x129b3ec
    // 0x129b3dc: r0 = false
    //     0x129b3dc: add             x0, NULL, #0x30  ; false
    // 0x129b3e0: LeaveFrame
    //     0x129b3e0: mov             SP, fp
    //     0x129b3e4: ldp             fp, lr, [SP], #0x10
    // 0x129b3e8: ret
    //     0x129b3e8: ret             
    // 0x129b3ec: ldr             x4, [fp, #0x18]
    // 0x129b3f0: cmp             w4, w3
    // 0x129b3f4: b.ne            #0x129b408
    // 0x129b3f8: r0 = true
    //     0x129b3f8: add             x0, NULL, #0x20  ; true
    // 0x129b3fc: LeaveFrame
    //     0x129b3fc: mov             SP, fp
    //     0x129b400: ldp             fp, lr, [SP], #0x10
    // 0x129b404: ret
    //     0x129b404: ret             
    // 0x129b408: LoadField: r2 = r4->field_7
    //     0x129b408: ldur            w2, [x4, #7]
    // 0x129b40c: DecompressPointer r2
    //     0x129b40c: add             x2, x2, HEAP, lsl #32
    // 0x129b410: mov             x0, x3
    // 0x129b414: r1 = Null
    //     0x129b414: mov             x1, NULL
    // 0x129b418: cmp             w0, NULL
    // 0x129b41c: b.eq            #0x129b468
    // 0x129b420: branchIfSmi(r0, 0x129b468)
    //     0x129b420: tbz             w0, #0, #0x129b468
    // 0x129b424: r3 = SubtypeTestCache
    //     0x129b424: add             x3, PP, #0x97, lsl #12  ; [pp+0x97648] SubtypeTestCache
    //     0x129b428: ldr             x3, [x3, #0x648]
    // 0x129b42c: r30 = Subtype3TestCacheStub
    //     0x129b42c: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x129b430: LoadField: r30 = r30->field_7
    //     0x129b430: ldur            lr, [lr, #7]
    // 0x129b434: blr             lr
    // 0x129b438: cmp             w7, NULL
    // 0x129b43c: b.eq            #0x129b448
    // 0x129b440: tbnz            w7, #4, #0x129b468
    // 0x129b444: b               #0x129b470
    // 0x129b448: r8 = AsyncSnapshot<X0>
    //     0x129b448: add             x8, PP, #0x97, lsl #12  ; [pp+0x97650] Type: AsyncSnapshot<X0>
    //     0x129b44c: ldr             x8, [x8, #0x650]
    // 0x129b450: r3 = SubtypeTestCache
    //     0x129b450: add             x3, PP, #0x97, lsl #12  ; [pp+0x97658] SubtypeTestCache
    //     0x129b454: ldr             x3, [x3, #0x658]
    // 0x129b458: r30 = InstanceOfStub
    //     0x129b458: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x129b45c: LoadField: r30 = r30->field_7
    //     0x129b45c: ldur            lr, [lr, #7]
    // 0x129b460: blr             lr
    // 0x129b464: b               #0x129b474
    // 0x129b468: r0 = false
    //     0x129b468: add             x0, NULL, #0x30  ; false
    // 0x129b46c: b               #0x129b474
    // 0x129b470: r0 = true
    //     0x129b470: add             x0, NULL, #0x20  ; true
    // 0x129b474: tbnz            w0, #4, #0x129b548
    // 0x129b478: ldr             x2, [fp, #0x18]
    // 0x129b47c: ldr             x1, [fp, #0x10]
    // 0x129b480: LoadField: r0 = r1->field_b
    //     0x129b480: ldur            w0, [x1, #0xb]
    // 0x129b484: DecompressPointer r0
    //     0x129b484: add             x0, x0, HEAP, lsl #32
    // 0x129b488: LoadField: r3 = r2->field_b
    //     0x129b488: ldur            w3, [x2, #0xb]
    // 0x129b48c: DecompressPointer r3
    //     0x129b48c: add             x3, x3, HEAP, lsl #32
    // 0x129b490: cmp             w0, w3
    // 0x129b494: b.ne            #0x129b548
    // 0x129b498: LoadField: r0 = r1->field_f
    //     0x129b498: ldur            w0, [x1, #0xf]
    // 0x129b49c: DecompressPointer r0
    //     0x129b49c: add             x0, x0, HEAP, lsl #32
    // 0x129b4a0: LoadField: r3 = r2->field_f
    //     0x129b4a0: ldur            w3, [x2, #0xf]
    // 0x129b4a4: DecompressPointer r3
    //     0x129b4a4: add             x3, x3, HEAP, lsl #32
    // 0x129b4a8: r4 = 60
    //     0x129b4a8: mov             x4, #0x3c
    // 0x129b4ac: branchIfSmi(r0, 0x129b4b8)
    //     0x129b4ac: tbz             w0, #0, #0x129b4b8
    // 0x129b4b0: r4 = LoadClassIdInstr(r0)
    //     0x129b4b0: ldur            x4, [x0, #-1]
    //     0x129b4b4: ubfx            x4, x4, #0xc, #0x14
    // 0x129b4b8: stp             x3, x0, [SP]
    // 0x129b4bc: mov             x0, x4
    // 0x129b4c0: mov             lr, x0
    // 0x129b4c4: ldr             lr, [x21, lr, lsl #3]
    // 0x129b4c8: blr             lr
    // 0x129b4cc: tbnz            w0, #4, #0x129b548
    // 0x129b4d0: ldr             x2, [fp, #0x18]
    // 0x129b4d4: ldr             x1, [fp, #0x10]
    // 0x129b4d8: LoadField: r0 = r1->field_13
    //     0x129b4d8: ldur            w0, [x1, #0x13]
    // 0x129b4dc: DecompressPointer r0
    //     0x129b4dc: add             x0, x0, HEAP, lsl #32
    // 0x129b4e0: LoadField: r3 = r2->field_13
    //     0x129b4e0: ldur            w3, [x2, #0x13]
    // 0x129b4e4: DecompressPointer r3
    //     0x129b4e4: add             x3, x3, HEAP, lsl #32
    // 0x129b4e8: r4 = 60
    //     0x129b4e8: mov             x4, #0x3c
    // 0x129b4ec: branchIfSmi(r0, 0x129b4f8)
    //     0x129b4ec: tbz             w0, #0, #0x129b4f8
    // 0x129b4f0: r4 = LoadClassIdInstr(r0)
    //     0x129b4f0: ldur            x4, [x0, #-1]
    //     0x129b4f4: ubfx            x4, x4, #0xc, #0x14
    // 0x129b4f8: stp             x3, x0, [SP]
    // 0x129b4fc: mov             x0, x4
    // 0x129b500: mov             lr, x0
    // 0x129b504: ldr             lr, [x21, lr, lsl #3]
    // 0x129b508: blr             lr
    // 0x129b50c: tbnz            w0, #4, #0x129b548
    // 0x129b510: ldr             x1, [fp, #0x18]
    // 0x129b514: ldr             x0, [fp, #0x10]
    // 0x129b518: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x129b518: ldur            w2, [x0, #0x17]
    // 0x129b51c: DecompressPointer r2
    //     0x129b51c: add             x2, x2, HEAP, lsl #32
    // 0x129b520: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x129b520: ldur            w0, [x1, #0x17]
    // 0x129b524: DecompressPointer r0
    //     0x129b524: add             x0, x0, HEAP, lsl #32
    // 0x129b528: r1 = LoadClassIdInstr(r2)
    //     0x129b528: ldur            x1, [x2, #-1]
    //     0x129b52c: ubfx            x1, x1, #0xc, #0x14
    // 0x129b530: stp             x0, x2, [SP]
    // 0x129b534: mov             x0, x1
    // 0x129b538: mov             lr, x0
    // 0x129b53c: ldr             lr, [x21, lr, lsl #3]
    // 0x129b540: blr             lr
    // 0x129b544: b               #0x129b54c
    // 0x129b548: r0 = false
    //     0x129b548: add             x0, NULL, #0x30  ; false
    // 0x129b54c: LeaveFrame
    //     0x129b54c: mov             SP, fp
    //     0x129b550: ldp             fp, lr, [SP], #0x10
    // 0x129b554: ret
    //     0x129b554: ret             
    // 0x129b558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129b558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129b55c: b               #0x129b3d0
  }
}

// class id: 5448, size: 0x1c, field offset: 0x14
class _FutureBuilderState<C1X0> extends State<C1X0> {

  late AsyncSnapshot<C1X0> _snapshot; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xe091ec, size: 0xc4
    // 0xe091ec: EnterFrame
    //     0xe091ec: stp             fp, lr, [SP, #-0x10]!
    //     0xe091f0: mov             fp, SP
    // 0xe091f4: AllocStack(0x30)
    //     0xe091f4: sub             SP, SP, #0x30
    // 0xe091f8: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xe091f8: mov             x3, x2
    //     0xe091fc: stur            x2, [fp, #-0x18]
    // 0xe09200: CheckStackOverflow
    //     0xe09200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe09204: cmp             SP, x16
    //     0xe09208: b.ls            #0xe09298
    // 0xe0920c: LoadField: r0 = r1->field_b
    //     0xe0920c: ldur            w0, [x1, #0xb]
    // 0xe09210: DecompressPointer r0
    //     0xe09210: add             x0, x0, HEAP, lsl #32
    // 0xe09214: cmp             w0, NULL
    // 0xe09218: b.eq            #0xe092a0
    // 0xe0921c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xe0921c: ldur            w4, [x1, #0x17]
    // 0xe09220: DecompressPointer r4
    //     0xe09220: add             x4, x4, HEAP, lsl #32
    // 0xe09224: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe09228: cmp             w4, w16
    // 0xe0922c: b.eq            #0xe092a4
    // 0xe09230: stur            x4, [fp, #-0x10]
    // 0xe09234: LoadField: r5 = r0->field_13
    //     0xe09234: ldur            w5, [x0, #0x13]
    // 0xe09238: DecompressPointer r5
    //     0xe09238: add             x5, x5, HEAP, lsl #32
    // 0xe0923c: stur            x5, [fp, #-8]
    // 0xe09240: LoadField: r2 = r1->field_7
    //     0xe09240: ldur            w2, [x1, #7]
    // 0xe09244: DecompressPointer r2
    //     0xe09244: add             x2, x2, HEAP, lsl #32
    // 0xe09248: mov             x0, x5
    // 0xe0924c: r1 = Null
    //     0xe0924c: mov             x1, NULL
    // 0xe09250: r8 = (dynamic this, BuildContext, AsyncSnapshot<C1X0>) => Widget
    //     0xe09250: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d1b0] FunctionType: (dynamic this, BuildContext, AsyncSnapshot<C1X0>) => Widget
    //     0xe09254: ldr             x8, [x8, #0x1b0]
    // 0xe09258: LoadField: r9 = r8->field_7
    //     0xe09258: ldur            x9, [x8, #7]
    // 0xe0925c: r3 = Null
    //     0xe0925c: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d1b8] Null
    //     0xe09260: ldr             x3, [x3, #0x1b8]
    // 0xe09264: blr             x9
    // 0xe09268: ldur            x16, [fp, #-8]
    // 0xe0926c: ldur            lr, [fp, #-0x18]
    // 0xe09270: stp             lr, x16, [SP, #8]
    // 0xe09274: ldur            x16, [fp, #-0x10]
    // 0xe09278: str             x16, [SP]
    // 0xe0927c: ldur            x0, [fp, #-8]
    // 0xe09280: ClosureCall
    //     0xe09280: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xe09284: ldur            x2, [x0, #0x1f]
    //     0xe09288: blr             x2
    // 0xe0928c: LeaveFrame
    //     0xe0928c: mov             SP, fp
    //     0xe09290: ldp             fp, lr, [SP], #0x10
    // 0xe09294: ret
    //     0xe09294: ret             
    // 0xe09298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe09298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0929c: b               #0xe0920c
    // 0xe092a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe092a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe092a4: r9 = _snapshot
    //     0xe092a4: add             x9, PP, #0x8d, lsl #12  ; [pp+0x8d1c8] Field <_FutureBuilderState@522480208._snapshot@522480208>: late (offset: 0x18)
    //     0xe092a8: ldr             x9, [x9, #0x1c8]
    // 0xe092ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe092ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf70598, size: 0x15c
    // 0xf70598: EnterFrame
    //     0xf70598: stp             fp, lr, [SP, #-0x10]!
    //     0xf7059c: mov             fp, SP
    // 0xf705a0: AllocStack(0x18)
    //     0xf705a0: sub             SP, SP, #0x18
    // 0xf705a4: SetupParameters(_FutureBuilderState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xf705a4: mov             x4, x1
    //     0xf705a8: mov             x3, x2
    //     0xf705ac: stur            x1, [fp, #-0x10]
    //     0xf705b0: stur            x2, [fp, #-0x18]
    // 0xf705b4: CheckStackOverflow
    //     0xf705b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf705b8: cmp             SP, x16
    //     0xf705bc: b.ls            #0xf706dc
    // 0xf705c0: LoadField: r5 = r4->field_7
    //     0xf705c0: ldur            w5, [x4, #7]
    // 0xf705c4: DecompressPointer r5
    //     0xf705c4: add             x5, x5, HEAP, lsl #32
    // 0xf705c8: mov             x0, x3
    // 0xf705cc: mov             x2, x5
    // 0xf705d0: stur            x5, [fp, #-8]
    // 0xf705d4: r1 = Null
    //     0xf705d4: mov             x1, NULL
    // 0xf705d8: r8 = FutureBuilder<C1X0>
    //     0xf705d8: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d1d0] Type: FutureBuilder<C1X0>
    //     0xf705dc: ldr             x8, [x8, #0x1d0]
    // 0xf705e0: LoadField: r9 = r8->field_7
    //     0xf705e0: ldur            x9, [x8, #7]
    // 0xf705e4: r3 = Null
    //     0xf705e4: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d1d8] Null
    //     0xf705e8: ldr             x3, [x3, #0x1d8]
    // 0xf705ec: blr             x9
    // 0xf705f0: ldur            x0, [fp, #-0x18]
    // 0xf705f4: ldur            x2, [fp, #-8]
    // 0xf705f8: r1 = Null
    //     0xf705f8: mov             x1, NULL
    // 0xf705fc: cmp             w2, NULL
    // 0xf70600: b.eq            #0xf70624
    // 0xf70604: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf70604: ldur            w4, [x2, #0x17]
    // 0xf70608: DecompressPointer r4
    //     0xf70608: add             x4, x4, HEAP, lsl #32
    // 0xf7060c: r8 = X0 bound StatefulWidget
    //     0xf7060c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf70610: ldr             x8, [x8, #0x498]
    // 0xf70614: LoadField: r9 = r4->field_7
    //     0xf70614: ldur            x9, [x4, #7]
    // 0xf70618: r3 = Null
    //     0xf70618: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d1e8] Null
    //     0xf7061c: ldr             x3, [x3, #0x1e8]
    // 0xf70620: blr             x9
    // 0xf70624: ldur            x0, [fp, #-0x18]
    // 0xf70628: LoadField: r1 = r0->field_f
    //     0xf70628: ldur            w1, [x0, #0xf]
    // 0xf7062c: DecompressPointer r1
    //     0xf7062c: add             x1, x1, HEAP, lsl #32
    // 0xf70630: ldur            x0, [fp, #-0x10]
    // 0xf70634: LoadField: r2 = r0->field_b
    //     0xf70634: ldur            w2, [x0, #0xb]
    // 0xf70638: DecompressPointer r2
    //     0xf70638: add             x2, x2, HEAP, lsl #32
    // 0xf7063c: cmp             w2, NULL
    // 0xf70640: b.eq            #0xf706e4
    // 0xf70644: LoadField: r3 = r2->field_f
    //     0xf70644: ldur            w3, [x2, #0xf]
    // 0xf70648: DecompressPointer r3
    //     0xf70648: add             x3, x3, HEAP, lsl #32
    // 0xf7064c: cmp             w1, w3
    // 0xf70650: b.ne            #0xf70664
    // 0xf70654: r0 = Null
    //     0xf70654: mov             x0, NULL
    // 0xf70658: LeaveFrame
    //     0xf70658: mov             SP, fp
    //     0xf7065c: ldp             fp, lr, [SP], #0x10
    // 0xf70660: ret
    //     0xf70660: ret             
    // 0xf70664: LoadField: r1 = r0->field_13
    //     0xf70664: ldur            w1, [x0, #0x13]
    // 0xf70668: DecompressPointer r1
    //     0xf70668: add             x1, x1, HEAP, lsl #32
    // 0xf7066c: cmp             w1, NULL
    // 0xf70670: b.eq            #0xf706c4
    // 0xf70674: mov             x1, x0
    // 0xf70678: r0 = dispose()
    //     0xf70678: bl              #0x10e6f64  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::dispose
    // 0xf7067c: ldur            x0, [fp, #-0x10]
    // 0xf70680: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf70680: ldur            w1, [x0, #0x17]
    // 0xf70684: DecompressPointer r1
    //     0xf70684: add             x1, x1, HEAP, lsl #32
    // 0xf70688: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7068c: cmp             w1, w16
    // 0xf70690: b.eq            #0xf706e8
    // 0xf70694: r2 = Instance_ConnectionState
    //     0xf70694: add             x2, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf70698: ldr             x2, [x2, #0x1f8]
    // 0xf7069c: r0 = inState()
    //     0xf7069c: bl              #0xf6ff54  ; [package:flutter/src/widgets/async.dart] AsyncSnapshot::inState
    // 0xf706a0: ldur            x1, [fp, #-0x10]
    // 0xf706a4: ArrayStore: r1[0] = r0  ; List_4
    //     0xf706a4: stur            w0, [x1, #0x17]
    //     0xf706a8: ldurb           w16, [x1, #-1]
    //     0xf706ac: ldurb           w17, [x0, #-1]
    //     0xf706b0: and             x16, x17, x16, lsr #2
    //     0xf706b4: tst             x16, HEAP, lsr #32
    //     0xf706b8: b.eq            #0xf706c0
    //     0xf706bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf706c0: b               #0xf706c8
    // 0xf706c4: mov             x1, x0
    // 0xf706c8: r0 = _subscribe()
    //     0xf706c8: bl              #0xf706f4  ; [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe
    // 0xf706cc: r0 = Null
    //     0xf706cc: mov             x0, NULL
    // 0xf706d0: LeaveFrame
    //     0xf706d0: mov             SP, fp
    //     0xf706d4: ldp             fp, lr, [SP], #0x10
    // 0xf706d8: ret
    //     0xf706d8: ret             
    // 0xf706dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf706dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf706e0: b               #0xf705c0
    // 0xf706e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf706e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf706e8: r9 = _snapshot
    //     0xf706e8: add             x9, PP, #0x8d, lsl #12  ; [pp+0x8d1c8] Field <_FutureBuilderState@522480208._snapshot@522480208>: late (offset: 0x18)
    //     0xf706ec: ldr             x9, [x9, #0x1c8]
    // 0xf706f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf706f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _subscribe(/* No info */) {
    // ** addr: 0xf706f4, size: 0x160
    // 0xf706f4: EnterFrame
    //     0xf706f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf706f8: mov             fp, SP
    // 0xf706fc: AllocStack(0x38)
    //     0xf706fc: sub             SP, SP, #0x38
    // 0xf70700: SetupParameters(_FutureBuilderState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xf70700: stur            x1, [fp, #-8]
    // 0xf70704: CheckStackOverflow
    //     0xf70704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70708: cmp             SP, x16
    //     0xf7070c: b.ls            #0xf7083c
    // 0xf70710: r1 = 2
    //     0xf70710: mov             x1, #2
    // 0xf70714: r0 = AllocateContext()
    //     0xf70714: bl              #0x13de838  ; AllocateContextStub
    // 0xf70718: mov             x1, x0
    // 0xf7071c: ldur            x0, [fp, #-8]
    // 0xf70720: stur            x1, [fp, #-0x18]
    // 0xf70724: StoreField: r1->field_f = r0
    //     0xf70724: stur            w0, [x1, #0xf]
    // 0xf70728: LoadField: r2 = r0->field_b
    //     0xf70728: ldur            w2, [x0, #0xb]
    // 0xf7072c: DecompressPointer r2
    //     0xf7072c: add             x2, x2, HEAP, lsl #32
    // 0xf70730: cmp             w2, NULL
    // 0xf70734: b.eq            #0xf70844
    // 0xf70738: LoadField: r3 = r2->field_f
    //     0xf70738: ldur            w3, [x2, #0xf]
    // 0xf7073c: DecompressPointer r3
    //     0xf7073c: add             x3, x3, HEAP, lsl #32
    // 0xf70740: stur            x3, [fp, #-0x10]
    // 0xf70744: cmp             w3, NULL
    // 0xf70748: b.ne            #0xf7075c
    // 0xf7074c: r0 = Null
    //     0xf7074c: mov             x0, NULL
    // 0xf70750: LeaveFrame
    //     0xf70750: mov             SP, fp
    //     0xf70754: ldp             fp, lr, [SP], #0x10
    // 0xf70758: ret
    //     0xf70758: ret             
    // 0xf7075c: r0 = Object()
    //     0xf7075c: bl              #0x7ed2a0  ; AllocateObjectStub -> Object (size=0x8)
    // 0xf70760: ldur            x4, [fp, #-0x18]
    // 0xf70764: StoreField: r4->field_13 = r0
    //     0xf70764: stur            w0, [x4, #0x13]
    // 0xf70768: ldur            x5, [fp, #-8]
    // 0xf7076c: StoreField: r5->field_13 = r0
    //     0xf7076c: stur            w0, [x5, #0x13]
    //     0xf70770: ldurb           w16, [x5, #-1]
    //     0xf70774: ldurb           w17, [x0, #-1]
    //     0xf70778: and             x16, x17, x16, lsr #2
    //     0xf7077c: tst             x16, HEAP, lsr #32
    //     0xf70780: b.eq            #0xf70788
    //     0xf70784: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xf70788: LoadField: r3 = r5->field_7
    //     0xf70788: ldur            w3, [x5, #7]
    // 0xf7078c: DecompressPointer r3
    //     0xf7078c: add             x3, x3, HEAP, lsl #32
    // 0xf70790: mov             x2, x4
    // 0xf70794: r1 = Function '<anonymous closure>':.
    //     0xf70794: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d200] AnonymousClosure: (0xf709c4), in [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe (0xf706f4)
    //     0xf70798: ldr             x1, [x1, #0x200]
    // 0xf7079c: r0 = AllocateClosureTA()
    //     0xf7079c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xf707a0: ldur            x2, [fp, #-0x18]
    // 0xf707a4: r1 = Function '<anonymous closure>':.
    //     0xf707a4: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d208] AnonymousClosure: (0xf70854), in [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe (0xf706f4)
    //     0xf707a8: ldr             x1, [x1, #0x208]
    // 0xf707ac: stur            x0, [fp, #-0x18]
    // 0xf707b0: r0 = AllocateClosure()
    //     0xf707b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf707b4: r16 = <void?>
    //     0xf707b4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf707b8: ldur            lr, [fp, #-0x10]
    // 0xf707bc: stp             lr, x16, [SP, #0x10]
    // 0xf707c0: ldur            x16, [fp, #-0x18]
    // 0xf707c4: stp             x0, x16, [SP]
    // 0xf707c8: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xf707c8: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xf707cc: r0 = then()
    //     0xf707cc: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xf707d0: ldur            x0, [fp, #-8]
    // 0xf707d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf707d4: ldur            w1, [x0, #0x17]
    // 0xf707d8: DecompressPointer r1
    //     0xf707d8: add             x1, x1, HEAP, lsl #32
    // 0xf707dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf707e0: cmp             w1, w16
    // 0xf707e4: b.eq            #0xf70848
    // 0xf707e8: LoadField: r2 = r1->field_b
    //     0xf707e8: ldur            w2, [x1, #0xb]
    // 0xf707ec: DecompressPointer r2
    //     0xf707ec: add             x2, x2, HEAP, lsl #32
    // 0xf707f0: r16 = Instance_ConnectionState
    //     0xf707f0: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d210] Obj!ConnectionState@12c3581
    //     0xf707f4: ldr             x16, [x16, #0x210]
    // 0xf707f8: cmp             w2, w16
    // 0xf707fc: b.eq            #0xf7082c
    // 0xf70800: r2 = Instance_ConnectionState
    //     0xf70800: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7b2a0] Obj!ConnectionState@12c3541
    //     0xf70804: ldr             x2, [x2, #0x2a0]
    // 0xf70808: r0 = inState()
    //     0xf70808: bl              #0xf6ff54  ; [package:flutter/src/widgets/async.dart] AsyncSnapshot::inState
    // 0xf7080c: ldur            x1, [fp, #-8]
    // 0xf70810: ArrayStore: r1[0] = r0  ; List_4
    //     0xf70810: stur            w0, [x1, #0x17]
    //     0xf70814: ldurb           w16, [x1, #-1]
    //     0xf70818: ldurb           w17, [x0, #-1]
    //     0xf7081c: and             x16, x17, x16, lsr #2
    //     0xf70820: tst             x16, HEAP, lsr #32
    //     0xf70824: b.eq            #0xf7082c
    //     0xf70828: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7082c: r0 = Null
    //     0xf7082c: mov             x0, NULL
    // 0xf70830: LeaveFrame
    //     0xf70830: mov             SP, fp
    //     0xf70834: ldp             fp, lr, [SP], #0x10
    // 0xf70838: ret
    //     0xf70838: ret             
    // 0xf7083c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7083c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70840: b               #0xf70710
    // 0xf70844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70844: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf70848: r9 = _snapshot
    //     0xf70848: add             x9, PP, #0x8d, lsl #12  ; [pp+0x8d1c8] Field <_FutureBuilderState@522480208._snapshot@522480208>: late (offset: 0x18)
    //     0xf7084c: ldr             x9, [x9, #0x1c8]
    // 0xf70850: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf70850: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xf70854, size: 0xa4
    // 0xf70854: EnterFrame
    //     0xf70854: stp             fp, lr, [SP, #-0x10]!
    //     0xf70858: mov             fp, SP
    // 0xf7085c: AllocStack(0x10)
    //     0xf7085c: sub             SP, SP, #0x10
    // 0xf70860: SetupParameters([dynamic _ /* r0 */])
    //     0xf70860: ldr             x0, [fp, #0x20]
    //     0xf70864: ldur            w1, [x0, #0x17]
    //     0xf70868: add             x1, x1, HEAP, lsl #32
    //     0xf7086c: stur            x1, [fp, #-8]
    // 0xf70870: CheckStackOverflow
    //     0xf70870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70874: cmp             SP, x16
    //     0xf70878: b.ls            #0xf708f0
    // 0xf7087c: r1 = 2
    //     0xf7087c: mov             x1, #2
    // 0xf70880: r0 = AllocateContext()
    //     0xf70880: bl              #0x13de838  ; AllocateContextStub
    // 0xf70884: mov             x1, x0
    // 0xf70888: ldur            x0, [fp, #-8]
    // 0xf7088c: StoreField: r1->field_b = r0
    //     0xf7088c: stur            w0, [x1, #0xb]
    // 0xf70890: ldr             x2, [fp, #0x18]
    // 0xf70894: StoreField: r1->field_f = r2
    //     0xf70894: stur            w2, [x1, #0xf]
    // 0xf70898: ldr             x2, [fp, #0x10]
    // 0xf7089c: StoreField: r1->field_13 = r2
    //     0xf7089c: stur            w2, [x1, #0x13]
    // 0xf708a0: LoadField: r3 = r0->field_f
    //     0xf708a0: ldur            w3, [x0, #0xf]
    // 0xf708a4: DecompressPointer r3
    //     0xf708a4: add             x3, x3, HEAP, lsl #32
    // 0xf708a8: stur            x3, [fp, #-0x10]
    // 0xf708ac: LoadField: r2 = r3->field_13
    //     0xf708ac: ldur            w2, [x3, #0x13]
    // 0xf708b0: DecompressPointer r2
    //     0xf708b0: add             x2, x2, HEAP, lsl #32
    // 0xf708b4: LoadField: r4 = r0->field_13
    //     0xf708b4: ldur            w4, [x0, #0x13]
    // 0xf708b8: DecompressPointer r4
    //     0xf708b8: add             x4, x4, HEAP, lsl #32
    // 0xf708bc: cmp             w2, w4
    // 0xf708c0: b.ne            #0xf708e0
    // 0xf708c4: mov             x2, x1
    // 0xf708c8: r1 = Function '<anonymous closure>':.
    //     0xf708c8: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d218] AnonymousClosure: (0xf708f8), in [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe (0xf706f4)
    //     0xf708cc: ldr             x1, [x1, #0x218]
    // 0xf708d0: r0 = AllocateClosure()
    //     0xf708d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf708d4: ldur            x1, [fp, #-0x10]
    // 0xf708d8: mov             x2, x0
    // 0xf708dc: r0 = setState()
    //     0xf708dc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf708e0: r0 = Null
    //     0xf708e0: mov             x0, NULL
    // 0xf708e4: LeaveFrame
    //     0xf708e4: mov             SP, fp
    //     0xf708e8: ldp             fp, lr, [SP], #0x10
    // 0xf708ec: ret
    //     0xf708ec: ret             
    // 0xf708f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf708f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf708f4: b               #0xf7087c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf708f8, size: 0xcc
    // 0xf708f8: EnterFrame
    //     0xf708f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf708fc: mov             fp, SP
    // 0xf70900: AllocStack(0x20)
    //     0xf70900: sub             SP, SP, #0x20
    // 0xf70904: SetupParameters([dynamic _ /* r0 */])
    //     0xf70904: ldr             x0, [fp, #0x10]
    //     0xf70908: ldur            w4, [x0, #0x17]
    //     0xf7090c: add             x4, x4, HEAP, lsl #32
    //     0xf70910: stur            x4, [fp, #-0x10]
    // 0xf70914: LoadField: r0 = r4->field_b
    //     0xf70914: ldur            w0, [x4, #0xb]
    // 0xf70918: DecompressPointer r0
    //     0xf70918: add             x0, x0, HEAP, lsl #32
    // 0xf7091c: LoadField: r5 = r0->field_f
    //     0xf7091c: ldur            w5, [x0, #0xf]
    // 0xf70920: DecompressPointer r5
    //     0xf70920: add             x5, x5, HEAP, lsl #32
    // 0xf70924: stur            x5, [fp, #-8]
    // 0xf70928: LoadField: r2 = r5->field_7
    //     0xf70928: ldur            w2, [x5, #7]
    // 0xf7092c: DecompressPointer r2
    //     0xf7092c: add             x2, x2, HEAP, lsl #32
    // 0xf70930: r1 = Null
    //     0xf70930: mov             x1, NULL
    // 0xf70934: r3 = <C1X0>
    //     0xf70934: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xf70938: ldr             x3, [x3, #0x880]
    // 0xf7093c: r0 = Null
    //     0xf7093c: mov             x0, NULL
    // 0xf70940: cmp             x2, x0
    // 0xf70944: b.eq            #0xf70954
    // 0xf70948: r30 = InstantiateTypeArgumentsStub
    //     0xf70948: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xf7094c: LoadField: r30 = r30->field_7
    //     0xf7094c: ldur            lr, [lr, #7]
    // 0xf70950: blr             lr
    // 0xf70954: mov             x1, x0
    // 0xf70958: ldur            x0, [fp, #-0x10]
    // 0xf7095c: LoadField: r2 = r0->field_f
    //     0xf7095c: ldur            w2, [x0, #0xf]
    // 0xf70960: DecompressPointer r2
    //     0xf70960: add             x2, x2, HEAP, lsl #32
    // 0xf70964: stur            x2, [fp, #-0x20]
    // 0xf70968: LoadField: r3 = r0->field_13
    //     0xf70968: ldur            w3, [x0, #0x13]
    // 0xf7096c: DecompressPointer r3
    //     0xf7096c: add             x3, x3, HEAP, lsl #32
    // 0xf70970: stur            x3, [fp, #-0x18]
    // 0xf70974: r0 = AsyncSnapshot()
    //     0xf70974: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf70978: r1 = Instance_ConnectionState
    //     0xf70978: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d210] Obj!ConnectionState@12c3581
    //     0xf7097c: ldr             x1, [x1, #0x210]
    // 0xf70980: StoreField: r0->field_b = r1
    //     0xf70980: stur            w1, [x0, #0xb]
    // 0xf70984: ldur            x1, [fp, #-0x20]
    // 0xf70988: StoreField: r0->field_13 = r1
    //     0xf70988: stur            w1, [x0, #0x13]
    // 0xf7098c: ldur            x1, [fp, #-0x18]
    // 0xf70990: ArrayStore: r0[0] = r1  ; List_4
    //     0xf70990: stur            w1, [x0, #0x17]
    // 0xf70994: ldur            x1, [fp, #-8]
    // 0xf70998: ArrayStore: r1[0] = r0  ; List_4
    //     0xf70998: stur            w0, [x1, #0x17]
    //     0xf7099c: ldurb           w16, [x1, #-1]
    //     0xf709a0: ldurb           w17, [x0, #-1]
    //     0xf709a4: and             x16, x17, x16, lsr #2
    //     0xf709a8: tst             x16, HEAP, lsr #32
    //     0xf709ac: b.eq            #0xf709b4
    //     0xf709b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf709b4: r0 = Null
    //     0xf709b4: mov             x0, NULL
    // 0xf709b8: LeaveFrame
    //     0xf709b8: mov             SP, fp
    //     0xf709bc: ldp             fp, lr, [SP], #0x10
    // 0xf709c0: ret
    //     0xf709c0: ret             
  }
  [closure] Null <anonymous closure>(dynamic, C1X0) {
    // ** addr: 0xf709c4, size: 0x9c
    // 0xf709c4: EnterFrame
    //     0xf709c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf709c8: mov             fp, SP
    // 0xf709cc: AllocStack(0x10)
    //     0xf709cc: sub             SP, SP, #0x10
    // 0xf709d0: SetupParameters([dynamic _ /* r0 */])
    //     0xf709d0: ldr             x0, [fp, #0x18]
    //     0xf709d4: ldur            w1, [x0, #0x17]
    //     0xf709d8: add             x1, x1, HEAP, lsl #32
    //     0xf709dc: stur            x1, [fp, #-8]
    // 0xf709e0: CheckStackOverflow
    //     0xf709e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf709e4: cmp             SP, x16
    //     0xf709e8: b.ls            #0xf70a58
    // 0xf709ec: r1 = 1
    //     0xf709ec: mov             x1, #1
    // 0xf709f0: r0 = AllocateContext()
    //     0xf709f0: bl              #0x13de838  ; AllocateContextStub
    // 0xf709f4: mov             x1, x0
    // 0xf709f8: ldur            x0, [fp, #-8]
    // 0xf709fc: StoreField: r1->field_b = r0
    //     0xf709fc: stur            w0, [x1, #0xb]
    // 0xf70a00: ldr             x2, [fp, #0x10]
    // 0xf70a04: StoreField: r1->field_f = r2
    //     0xf70a04: stur            w2, [x1, #0xf]
    // 0xf70a08: LoadField: r3 = r0->field_f
    //     0xf70a08: ldur            w3, [x0, #0xf]
    // 0xf70a0c: DecompressPointer r3
    //     0xf70a0c: add             x3, x3, HEAP, lsl #32
    // 0xf70a10: stur            x3, [fp, #-0x10]
    // 0xf70a14: LoadField: r2 = r3->field_13
    //     0xf70a14: ldur            w2, [x3, #0x13]
    // 0xf70a18: DecompressPointer r2
    //     0xf70a18: add             x2, x2, HEAP, lsl #32
    // 0xf70a1c: LoadField: r4 = r0->field_13
    //     0xf70a1c: ldur            w4, [x0, #0x13]
    // 0xf70a20: DecompressPointer r4
    //     0xf70a20: add             x4, x4, HEAP, lsl #32
    // 0xf70a24: cmp             w2, w4
    // 0xf70a28: b.ne            #0xf70a48
    // 0xf70a2c: mov             x2, x1
    // 0xf70a30: r1 = Function '<anonymous closure>':.
    //     0xf70a30: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d220] AnonymousClosure: (0xf70a60), in [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe (0xf706f4)
    //     0xf70a34: ldr             x1, [x1, #0x220]
    // 0xf70a38: r0 = AllocateClosure()
    //     0xf70a38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf70a3c: ldur            x1, [fp, #-0x10]
    // 0xf70a40: mov             x2, x0
    // 0xf70a44: r0 = setState()
    //     0xf70a44: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf70a48: r0 = Null
    //     0xf70a48: mov             x0, NULL
    // 0xf70a4c: LeaveFrame
    //     0xf70a4c: mov             SP, fp
    //     0xf70a50: ldp             fp, lr, [SP], #0x10
    // 0xf70a54: ret
    //     0xf70a54: ret             
    // 0xf70a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70a58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70a5c: b               #0xf709ec
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf70a60, size: 0xb8
    // 0xf70a60: EnterFrame
    //     0xf70a60: stp             fp, lr, [SP, #-0x10]!
    //     0xf70a64: mov             fp, SP
    // 0xf70a68: AllocStack(0x18)
    //     0xf70a68: sub             SP, SP, #0x18
    // 0xf70a6c: SetupParameters([dynamic _ /* r0 */])
    //     0xf70a6c: ldr             x0, [fp, #0x10]
    //     0xf70a70: ldur            w4, [x0, #0x17]
    //     0xf70a74: add             x4, x4, HEAP, lsl #32
    //     0xf70a78: stur            x4, [fp, #-0x10]
    // 0xf70a7c: LoadField: r0 = r4->field_b
    //     0xf70a7c: ldur            w0, [x4, #0xb]
    // 0xf70a80: DecompressPointer r0
    //     0xf70a80: add             x0, x0, HEAP, lsl #32
    // 0xf70a84: LoadField: r5 = r0->field_f
    //     0xf70a84: ldur            w5, [x0, #0xf]
    // 0xf70a88: DecompressPointer r5
    //     0xf70a88: add             x5, x5, HEAP, lsl #32
    // 0xf70a8c: stur            x5, [fp, #-8]
    // 0xf70a90: LoadField: r2 = r5->field_7
    //     0xf70a90: ldur            w2, [x5, #7]
    // 0xf70a94: DecompressPointer r2
    //     0xf70a94: add             x2, x2, HEAP, lsl #32
    // 0xf70a98: r1 = Null
    //     0xf70a98: mov             x1, NULL
    // 0xf70a9c: r3 = <C1X0>
    //     0xf70a9c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xf70aa0: ldr             x3, [x3, #0x880]
    // 0xf70aa4: r0 = Null
    //     0xf70aa4: mov             x0, NULL
    // 0xf70aa8: cmp             x2, x0
    // 0xf70aac: b.eq            #0xf70abc
    // 0xf70ab0: r30 = InstantiateTypeArgumentsStub
    //     0xf70ab0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xf70ab4: LoadField: r30 = r30->field_7
    //     0xf70ab4: ldur            lr, [lr, #7]
    // 0xf70ab8: blr             lr
    // 0xf70abc: mov             x1, x0
    // 0xf70ac0: ldur            x0, [fp, #-0x10]
    // 0xf70ac4: LoadField: r2 = r0->field_f
    //     0xf70ac4: ldur            w2, [x0, #0xf]
    // 0xf70ac8: DecompressPointer r2
    //     0xf70ac8: add             x2, x2, HEAP, lsl #32
    // 0xf70acc: stur            x2, [fp, #-0x18]
    // 0xf70ad0: r0 = AsyncSnapshot()
    //     0xf70ad0: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf70ad4: r1 = Instance_ConnectionState
    //     0xf70ad4: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d210] Obj!ConnectionState@12c3581
    //     0xf70ad8: ldr             x1, [x1, #0x210]
    // 0xf70adc: StoreField: r0->field_b = r1
    //     0xf70adc: stur            w1, [x0, #0xb]
    // 0xf70ae0: ldur            x1, [fp, #-0x18]
    // 0xf70ae4: StoreField: r0->field_f = r1
    //     0xf70ae4: stur            w1, [x0, #0xf]
    // 0xf70ae8: ldur            x1, [fp, #-8]
    // 0xf70aec: ArrayStore: r1[0] = r0  ; List_4
    //     0xf70aec: stur            w0, [x1, #0x17]
    //     0xf70af0: ldurb           w16, [x1, #-1]
    //     0xf70af4: ldurb           w17, [x0, #-1]
    //     0xf70af8: and             x16, x17, x16, lsr #2
    //     0xf70afc: tst             x16, HEAP, lsr #32
    //     0xf70b00: b.eq            #0xf70b08
    //     0xf70b04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf70b08: r0 = Null
    //     0xf70b08: mov             x0, NULL
    // 0xf70b0c: LeaveFrame
    //     0xf70b0c: mov             SP, fp
    //     0xf70b10: ldp             fp, lr, [SP], #0x10
    // 0xf70b14: ret
    //     0xf70b14: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91b04, size: 0xb8
    // 0xf91b04: EnterFrame
    //     0xf91b04: stp             fp, lr, [SP, #-0x10]!
    //     0xf91b08: mov             fp, SP
    // 0xf91b0c: AllocStack(0x8)
    //     0xf91b0c: sub             SP, SP, #8
    // 0xf91b10: SetupParameters(_FutureBuilderState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xf91b10: mov             x0, x1
    //     0xf91b14: stur            x1, [fp, #-8]
    // 0xf91b18: CheckStackOverflow
    //     0xf91b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91b1c: cmp             SP, x16
    //     0xf91b20: b.ls            #0xf91bb0
    // 0xf91b24: LoadField: r1 = r0->field_b
    //     0xf91b24: ldur            w1, [x0, #0xb]
    // 0xf91b28: DecompressPointer r1
    //     0xf91b28: add             x1, x1, HEAP, lsl #32
    // 0xf91b2c: cmp             w1, NULL
    // 0xf91b30: b.eq            #0xf91bb8
    // 0xf91b34: LoadField: r2 = r0->field_7
    //     0xf91b34: ldur            w2, [x0, #7]
    // 0xf91b38: DecompressPointer r2
    //     0xf91b38: add             x2, x2, HEAP, lsl #32
    // 0xf91b3c: r1 = Null
    //     0xf91b3c: mov             x1, NULL
    // 0xf91b40: r3 = <C1X0>
    //     0xf91b40: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xf91b44: ldr             x3, [x3, #0x880]
    // 0xf91b48: r0 = Null
    //     0xf91b48: mov             x0, NULL
    // 0xf91b4c: cmp             x2, x0
    // 0xf91b50: b.eq            #0xf91b60
    // 0xf91b54: r30 = InstantiateTypeArgumentsStub
    //     0xf91b54: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xf91b58: LoadField: r30 = r30->field_7
    //     0xf91b58: ldur            lr, [lr, #7]
    // 0xf91b5c: blr             lr
    // 0xf91b60: mov             x1, x0
    // 0xf91b64: r0 = AsyncSnapshot()
    //     0xf91b64: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf91b68: mov             x1, x0
    // 0xf91b6c: r0 = Instance_ConnectionState
    //     0xf91b6c: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf91b70: ldr             x0, [x0, #0x1f8]
    // 0xf91b74: StoreField: r1->field_b = r0
    //     0xf91b74: stur            w0, [x1, #0xb]
    // 0xf91b78: mov             x0, x1
    // 0xf91b7c: ldur            x1, [fp, #-8]
    // 0xf91b80: ArrayStore: r1[0] = r0  ; List_4
    //     0xf91b80: stur            w0, [x1, #0x17]
    //     0xf91b84: ldurb           w16, [x1, #-1]
    //     0xf91b88: ldurb           w17, [x0, #-1]
    //     0xf91b8c: and             x16, x17, x16, lsr #2
    //     0xf91b90: tst             x16, HEAP, lsr #32
    //     0xf91b94: b.eq            #0xf91b9c
    //     0xf91b98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf91b9c: r0 = _subscribe()
    //     0xf91b9c: bl              #0xf706f4  ; [package:flutter/src/widgets/async.dart] _FutureBuilderState::_subscribe
    // 0xf91ba0: r0 = Null
    //     0xf91ba0: mov             x0, NULL
    // 0xf91ba4: LeaveFrame
    //     0xf91ba4: mov             SP, fp
    //     0xf91ba8: ldp             fp, lr, [SP], #0x10
    // 0xf91bac: ret
    //     0xf91bac: ret             
    // 0xf91bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91bb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91bb4: b               #0xf91b24
    // 0xf91bb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91bb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e64a0, size: 0x30
    // 0x10e64a0: EnterFrame
    //     0x10e64a0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e64a4: mov             fp, SP
    // 0x10e64a8: CheckStackOverflow
    //     0x10e64a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e64ac: cmp             SP, x16
    //     0x10e64b0: b.ls            #0x10e64c8
    // 0x10e64b4: r0 = dispose()
    //     0x10e64b4: bl              #0x10e6f64  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::dispose
    // 0x10e64b8: r0 = Null
    //     0x10e64b8: mov             x0, NULL
    // 0x10e64bc: LeaveFrame
    //     0x10e64bc: mov             SP, fp
    //     0x10e64c0: ldp             fp, lr, [SP], #0x10
    // 0x10e64c4: ret
    //     0x10e64c4: ret             
    // 0x10e64c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e64c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e64cc: b               #0x10e64b4
  }
}

// class id: 5449, size: 0x1c, field offset: 0x14
class _StreamBuilderBaseState<C1X0, C1X1> extends State<C1X0> {

  late C1X1 _summary; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xe08e84, size: 0x64
    // 0xe08e84: EnterFrame
    //     0xe08e84: stp             fp, lr, [SP, #-0x10]!
    //     0xe08e88: mov             fp, SP
    // 0xe08e8c: CheckStackOverflow
    //     0xe08e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe08e90: cmp             SP, x16
    //     0xe08e94: b.ls            #0xe08ed0
    // 0xe08e98: LoadField: r0 = r1->field_b
    //     0xe08e98: ldur            w0, [x1, #0xb]
    // 0xe08e9c: DecompressPointer r0
    //     0xe08e9c: add             x0, x0, HEAP, lsl #32
    // 0xe08ea0: cmp             w0, NULL
    // 0xe08ea4: b.eq            #0xe08ed8
    // 0xe08ea8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xe08ea8: ldur            w3, [x1, #0x17]
    // 0xe08eac: DecompressPointer r3
    //     0xe08eac: add             x3, x3, HEAP, lsl #32
    // 0xe08eb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe08eb4: cmp             w3, w16
    // 0xe08eb8: b.eq            #0xe08edc
    // 0xe08ebc: mov             x1, x0
    // 0xe08ec0: r0 = build()
    //     0xe08ec0: bl              #0xe09078  ; [package:flutter/src/widgets/async.dart] StreamBuilder::build
    // 0xe08ec4: LeaveFrame
    //     0xe08ec4: mov             SP, fp
    //     0xe08ec8: ldp             fp, lr, [SP], #0x10
    // 0xe08ecc: ret
    //     0xe08ecc: ret             
    // 0xe08ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe08ed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe08ed4: b               #0xe08e98
    // 0xe08ed8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe08ed8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe08edc: r9 = _summary
    //     0xe08edc: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xe08ee0: ldr             x9, [x9, #0xcb8]
    // 0xe08ee4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe08ee4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6fc3c, size: 0x170
    // 0xf6fc3c: EnterFrame
    //     0xf6fc3c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6fc40: mov             fp, SP
    // 0xf6fc44: AllocStack(0x18)
    //     0xf6fc44: sub             SP, SP, #0x18
    // 0xf6fc48: SetupParameters(_StreamBuilderBaseState<C1X0, C1X1> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xf6fc48: mov             x4, x1
    //     0xf6fc4c: mov             x3, x2
    //     0xf6fc50: stur            x1, [fp, #-0x10]
    //     0xf6fc54: stur            x2, [fp, #-0x18]
    // 0xf6fc58: CheckStackOverflow
    //     0xf6fc58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6fc5c: cmp             SP, x16
    //     0xf6fc60: b.ls            #0xf6fd90
    // 0xf6fc64: LoadField: r5 = r4->field_7
    //     0xf6fc64: ldur            w5, [x4, #7]
    // 0xf6fc68: DecompressPointer r5
    //     0xf6fc68: add             x5, x5, HEAP, lsl #32
    // 0xf6fc6c: mov             x0, x3
    // 0xf6fc70: mov             x2, x5
    // 0xf6fc74: stur            x5, [fp, #-8]
    // 0xf6fc78: r1 = Null
    //     0xf6fc78: mov             x1, NULL
    // 0xf6fc7c: r8 = StreamBuilderBase<C1X0, C1X1>
    //     0xf6fc7c: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcd8] Type: StreamBuilderBase<C1X0, C1X1>
    //     0xf6fc80: ldr             x8, [x8, #0xcd8]
    // 0xf6fc84: LoadField: r9 = r8->field_7
    //     0xf6fc84: ldur            x9, [x8, #7]
    // 0xf6fc88: r3 = Null
    //     0xf6fc88: add             x3, PP, #0xab, lsl #12  ; [pp+0xabce0] Null
    //     0xf6fc8c: ldr             x3, [x3, #0xce0]
    // 0xf6fc90: blr             x9
    // 0xf6fc94: ldur            x0, [fp, #-0x18]
    // 0xf6fc98: ldur            x2, [fp, #-8]
    // 0xf6fc9c: r1 = Null
    //     0xf6fc9c: mov             x1, NULL
    // 0xf6fca0: cmp             w2, NULL
    // 0xf6fca4: b.eq            #0xf6fcc8
    // 0xf6fca8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6fca8: ldur            w4, [x2, #0x17]
    // 0xf6fcac: DecompressPointer r4
    //     0xf6fcac: add             x4, x4, HEAP, lsl #32
    // 0xf6fcb0: r8 = X0 bound StatefulWidget
    //     0xf6fcb0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6fcb4: ldr             x8, [x8, #0x498]
    // 0xf6fcb8: LoadField: r9 = r4->field_7
    //     0xf6fcb8: ldur            x9, [x4, #7]
    // 0xf6fcbc: r3 = Null
    //     0xf6fcbc: add             x3, PP, #0xab, lsl #12  ; [pp+0xabcf0] Null
    //     0xf6fcc0: ldr             x3, [x3, #0xcf0]
    // 0xf6fcc4: blr             x9
    // 0xf6fcc8: ldur            x0, [fp, #-0x18]
    // 0xf6fccc: LoadField: r1 = r0->field_f
    //     0xf6fccc: ldur            w1, [x0, #0xf]
    // 0xf6fcd0: DecompressPointer r1
    //     0xf6fcd0: add             x1, x1, HEAP, lsl #32
    // 0xf6fcd4: ldur            x0, [fp, #-0x10]
    // 0xf6fcd8: LoadField: r2 = r0->field_b
    //     0xf6fcd8: ldur            w2, [x0, #0xb]
    // 0xf6fcdc: DecompressPointer r2
    //     0xf6fcdc: add             x2, x2, HEAP, lsl #32
    // 0xf6fce0: cmp             w2, NULL
    // 0xf6fce4: b.eq            #0xf6fd98
    // 0xf6fce8: LoadField: r3 = r2->field_f
    //     0xf6fce8: ldur            w3, [x2, #0xf]
    // 0xf6fcec: DecompressPointer r3
    //     0xf6fcec: add             x3, x3, HEAP, lsl #32
    // 0xf6fcf0: cmp             w1, w3
    // 0xf6fcf4: b.eq            #0xf6fd80
    // 0xf6fcf8: LoadField: r2 = r3->field_b
    //     0xf6fcf8: ldur            w2, [x3, #0xb]
    // 0xf6fcfc: DecompressPointer r2
    //     0xf6fcfc: add             x2, x2, HEAP, lsl #32
    // 0xf6fd00: LoadField: r3 = r1->field_b
    //     0xf6fd00: ldur            w3, [x1, #0xb]
    // 0xf6fd04: DecompressPointer r3
    //     0xf6fd04: add             x3, x3, HEAP, lsl #32
    // 0xf6fd08: cmp             w2, w3
    // 0xf6fd0c: b.eq            #0xf6fd80
    // 0xf6fd10: LoadField: r1 = r0->field_13
    //     0xf6fd10: ldur            w1, [x0, #0x13]
    // 0xf6fd14: DecompressPointer r1
    //     0xf6fd14: add             x1, x1, HEAP, lsl #32
    // 0xf6fd18: cmp             w1, NULL
    // 0xf6fd1c: b.eq            #0xf6fd78
    // 0xf6fd20: mov             x1, x0
    // 0xf6fd24: r0 = _unsubscribe()
    //     0xf6fd24: bl              #0xf70534  ; [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_unsubscribe
    // 0xf6fd28: ldur            x0, [fp, #-0x10]
    // 0xf6fd2c: LoadField: r1 = r0->field_b
    //     0xf6fd2c: ldur            w1, [x0, #0xb]
    // 0xf6fd30: DecompressPointer r1
    //     0xf6fd30: add             x1, x1, HEAP, lsl #32
    // 0xf6fd34: cmp             w1, NULL
    // 0xf6fd38: b.eq            #0xf6fd9c
    // 0xf6fd3c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf6fd3c: ldur            w2, [x0, #0x17]
    // 0xf6fd40: DecompressPointer r2
    //     0xf6fd40: add             x2, x2, HEAP, lsl #32
    // 0xf6fd44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6fd48: cmp             w2, w16
    // 0xf6fd4c: b.eq            #0xf6fda0
    // 0xf6fd50: r0 = afterDisconnected()
    //     0xf6fd50: bl              #0xf704c8  ; [package:flutter/src/widgets/async.dart] StreamBuilder::afterDisconnected
    // 0xf6fd54: ldur            x1, [fp, #-0x10]
    // 0xf6fd58: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6fd58: stur            w0, [x1, #0x17]
    //     0xf6fd5c: ldurb           w16, [x1, #-1]
    //     0xf6fd60: ldurb           w17, [x0, #-1]
    //     0xf6fd64: and             x16, x17, x16, lsr #2
    //     0xf6fd68: tst             x16, HEAP, lsr #32
    //     0xf6fd6c: b.eq            #0xf6fd74
    //     0xf6fd70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6fd74: b               #0xf6fd7c
    // 0xf6fd78: mov             x1, x0
    // 0xf6fd7c: r0 = _subscribe()
    //     0xf6fd7c: bl              #0xf6fdac  ; [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe
    // 0xf6fd80: r0 = Null
    //     0xf6fd80: mov             x0, NULL
    // 0xf6fd84: LeaveFrame
    //     0xf6fd84: mov             SP, fp
    //     0xf6fd88: ldp             fp, lr, [SP], #0x10
    // 0xf6fd8c: ret
    //     0xf6fd8c: ret             
    // 0xf6fd90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6fd90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6fd94: b               #0xf6fc64
    // 0xf6fd98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fd98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6fd9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fd9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6fda0: r9 = _summary
    //     0xf6fda0: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xf6fda4: ldr             x9, [x9, #0xcb8]
    // 0xf6fda8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6fda8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _subscribe(/* No info */) {
    // ** addr: 0xf6fdac, size: 0x13c
    // 0xf6fdac: EnterFrame
    //     0xf6fdac: stp             fp, lr, [SP, #-0x10]!
    //     0xf6fdb0: mov             fp, SP
    // 0xf6fdb4: AllocStack(0x30)
    //     0xf6fdb4: sub             SP, SP, #0x30
    // 0xf6fdb8: SetupParameters(_StreamBuilderBaseState<C1X0, C1X1> this /* r1 => r1, fp-0x8 */)
    //     0xf6fdb8: stur            x1, [fp, #-8]
    // 0xf6fdbc: CheckStackOverflow
    //     0xf6fdbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6fdc0: cmp             SP, x16
    //     0xf6fdc4: b.ls            #0xf6fecc
    // 0xf6fdc8: r1 = 1
    //     0xf6fdc8: mov             x1, #1
    // 0xf6fdcc: r0 = AllocateContext()
    //     0xf6fdcc: bl              #0x13de838  ; AllocateContextStub
    // 0xf6fdd0: mov             x4, x0
    // 0xf6fdd4: ldur            x0, [fp, #-8]
    // 0xf6fdd8: stur            x4, [fp, #-0x18]
    // 0xf6fddc: StoreField: r4->field_f = r0
    //     0xf6fddc: stur            w0, [x4, #0xf]
    // 0xf6fde0: LoadField: r1 = r0->field_b
    //     0xf6fde0: ldur            w1, [x0, #0xb]
    // 0xf6fde4: DecompressPointer r1
    //     0xf6fde4: add             x1, x1, HEAP, lsl #32
    // 0xf6fde8: cmp             w1, NULL
    // 0xf6fdec: b.eq            #0xf6fed4
    // 0xf6fdf0: LoadField: r5 = r1->field_f
    //     0xf6fdf0: ldur            w5, [x1, #0xf]
    // 0xf6fdf4: DecompressPointer r5
    //     0xf6fdf4: add             x5, x5, HEAP, lsl #32
    // 0xf6fdf8: stur            x5, [fp, #-0x10]
    // 0xf6fdfc: LoadField: r3 = r0->field_7
    //     0xf6fdfc: ldur            w3, [x0, #7]
    // 0xf6fe00: DecompressPointer r3
    //     0xf6fe00: add             x3, x3, HEAP, lsl #32
    // 0xf6fe04: mov             x2, x4
    // 0xf6fe08: r1 = Function '<anonymous closure>':.
    //     0xf6fe08: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd00] AnonymousClosure: (0xf702f8), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf6fe0c: ldr             x1, [x1, #0xd00]
    // 0xf6fe10: r0 = AllocateClosureTA()
    //     0xf6fe10: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xf6fe14: ldur            x2, [fp, #-0x18]
    // 0xf6fe18: r1 = Function '<anonymous closure>':.
    //     0xf6fe18: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd08] AnonymousClosure: (0xf7013c), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf6fe1c: ldr             x1, [x1, #0xd08]
    // 0xf6fe20: stur            x0, [fp, #-0x20]
    // 0xf6fe24: r0 = AllocateClosure()
    //     0xf6fe24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6fe28: ldur            x2, [fp, #-0x18]
    // 0xf6fe2c: r1 = Function '<anonymous closure>':.
    //     0xf6fe2c: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd10] AnonymousClosure: (0xf6ffd0), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf6fe30: ldr             x1, [x1, #0xd10]
    // 0xf6fe34: stur            x0, [fp, #-0x18]
    // 0xf6fe38: r0 = AllocateClosure()
    //     0xf6fe38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6fe3c: ldur            x16, [fp, #-0x18]
    // 0xf6fe40: stp             x0, x16, [SP]
    // 0xf6fe44: ldur            x1, [fp, #-0x10]
    // 0xf6fe48: ldur            x2, [fp, #-0x20]
    // 0xf6fe4c: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0xf6fe4c: ldr             x4, [PP, #0x220]  ; [pp+0x220] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0xf6fe50: r0 = listen()
    //     0xf6fe50: bl              #0x123a37c  ; [dart:async] _StreamImpl::listen
    // 0xf6fe54: ldur            x3, [fp, #-8]
    // 0xf6fe58: StoreField: r3->field_13 = r0
    //     0xf6fe58: stur            w0, [x3, #0x13]
    //     0xf6fe5c: ldurb           w16, [x3, #-1]
    //     0xf6fe60: ldurb           w17, [x0, #-1]
    //     0xf6fe64: and             x16, x17, x16, lsr #2
    //     0xf6fe68: tst             x16, HEAP, lsr #32
    //     0xf6fe6c: b.eq            #0xf6fe74
    //     0xf6fe70: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf6fe74: LoadField: r1 = r3->field_b
    //     0xf6fe74: ldur            w1, [x3, #0xb]
    // 0xf6fe78: DecompressPointer r1
    //     0xf6fe78: add             x1, x1, HEAP, lsl #32
    // 0xf6fe7c: cmp             w1, NULL
    // 0xf6fe80: b.eq            #0xf6fed8
    // 0xf6fe84: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xf6fe84: ldur            w2, [x3, #0x17]
    // 0xf6fe88: DecompressPointer r2
    //     0xf6fe88: add             x2, x2, HEAP, lsl #32
    // 0xf6fe8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6fe90: cmp             w2, w16
    // 0xf6fe94: b.eq            #0xf6fedc
    // 0xf6fe98: r0 = afterConnected()
    //     0xf6fe98: bl              #0xf6fee8  ; [package:flutter/src/widgets/async.dart] StreamBuilder::afterConnected
    // 0xf6fe9c: ldur            x1, [fp, #-8]
    // 0xf6fea0: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6fea0: stur            w0, [x1, #0x17]
    //     0xf6fea4: ldurb           w16, [x1, #-1]
    //     0xf6fea8: ldurb           w17, [x0, #-1]
    //     0xf6feac: and             x16, x17, x16, lsr #2
    //     0xf6feb0: tst             x16, HEAP, lsr #32
    //     0xf6feb4: b.eq            #0xf6febc
    //     0xf6feb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6febc: r0 = Null
    //     0xf6febc: mov             x0, NULL
    // 0xf6fec0: LeaveFrame
    //     0xf6fec0: mov             SP, fp
    //     0xf6fec4: ldp             fp, lr, [SP], #0x10
    // 0xf6fec8: ret
    //     0xf6fec8: ret             
    // 0xf6fecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6fecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6fed0: b               #0xf6fdc8
    // 0xf6fed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fed4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6fed8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fed8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6fedc: r9 = _summary
    //     0xf6fedc: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xf6fee0: ldr             x9, [x9, #0xcb8]
    // 0xf6fee4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6fee4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf6ffd0, size: 0x60
    // 0xf6ffd0: EnterFrame
    //     0xf6ffd0: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ffd4: mov             fp, SP
    // 0xf6ffd8: AllocStack(0x8)
    //     0xf6ffd8: sub             SP, SP, #8
    // 0xf6ffdc: SetupParameters([dynamic _ /* r0 */])
    //     0xf6ffdc: ldr             x0, [fp, #0x10]
    //     0xf6ffe0: ldur            w2, [x0, #0x17]
    //     0xf6ffe4: add             x2, x2, HEAP, lsl #32
    // 0xf6ffe8: CheckStackOverflow
    //     0xf6ffe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ffec: cmp             SP, x16
    //     0xf6fff0: b.ls            #0xf70028
    // 0xf6fff4: LoadField: r0 = r2->field_f
    //     0xf6fff4: ldur            w0, [x2, #0xf]
    // 0xf6fff8: DecompressPointer r0
    //     0xf6fff8: add             x0, x0, HEAP, lsl #32
    // 0xf6fffc: stur            x0, [fp, #-8]
    // 0xf70000: r1 = Function '<anonymous closure>':.
    //     0xf70000: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd18] AnonymousClosure: (0xf70030), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf70004: ldr             x1, [x1, #0xd18]
    // 0xf70008: r0 = AllocateClosure()
    //     0xf70008: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7000c: ldur            x1, [fp, #-8]
    // 0xf70010: mov             x2, x0
    // 0xf70014: r0 = setState()
    //     0xf70014: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf70018: r0 = Null
    //     0xf70018: mov             x0, NULL
    // 0xf7001c: LeaveFrame
    //     0xf7001c: mov             SP, fp
    //     0xf70020: ldp             fp, lr, [SP], #0x10
    // 0xf70024: ret
    //     0xf70024: ret             
    // 0xf70028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7002c: b               #0xf6fff4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf70030, size: 0xa0
    // 0xf70030: EnterFrame
    //     0xf70030: stp             fp, lr, [SP, #-0x10]!
    //     0xf70034: mov             fp, SP
    // 0xf70038: AllocStack(0x8)
    //     0xf70038: sub             SP, SP, #8
    // 0xf7003c: SetupParameters([dynamic _ /* r0 */])
    //     0xf7003c: ldr             x0, [fp, #0x10]
    //     0xf70040: ldur            w1, [x0, #0x17]
    //     0xf70044: add             x1, x1, HEAP, lsl #32
    // 0xf70048: CheckStackOverflow
    //     0xf70048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7004c: cmp             SP, x16
    //     0xf70050: b.ls            #0xf700b8
    // 0xf70054: LoadField: r0 = r1->field_f
    //     0xf70054: ldur            w0, [x1, #0xf]
    // 0xf70058: DecompressPointer r0
    //     0xf70058: add             x0, x0, HEAP, lsl #32
    // 0xf7005c: stur            x0, [fp, #-8]
    // 0xf70060: LoadField: r1 = r0->field_b
    //     0xf70060: ldur            w1, [x0, #0xb]
    // 0xf70064: DecompressPointer r1
    //     0xf70064: add             x1, x1, HEAP, lsl #32
    // 0xf70068: cmp             w1, NULL
    // 0xf7006c: b.eq            #0xf700c0
    // 0xf70070: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf70070: ldur            w2, [x0, #0x17]
    // 0xf70074: DecompressPointer r2
    //     0xf70074: add             x2, x2, HEAP, lsl #32
    // 0xf70078: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7007c: cmp             w2, w16
    // 0xf70080: b.eq            #0xf700c4
    // 0xf70084: r0 = afterDone()
    //     0xf70084: bl              #0xf700d0  ; [package:flutter/src/widgets/async.dart] StreamBuilder::afterDone
    // 0xf70088: ldur            x1, [fp, #-8]
    // 0xf7008c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf7008c: stur            w0, [x1, #0x17]
    //     0xf70090: ldurb           w16, [x1, #-1]
    //     0xf70094: ldurb           w17, [x0, #-1]
    //     0xf70098: and             x16, x17, x16, lsr #2
    //     0xf7009c: tst             x16, HEAP, lsr #32
    //     0xf700a0: b.eq            #0xf700a8
    //     0xf700a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf700a8: r0 = Null
    //     0xf700a8: mov             x0, NULL
    // 0xf700ac: LeaveFrame
    //     0xf700ac: mov             SP, fp
    //     0xf700b0: ldp             fp, lr, [SP], #0x10
    // 0xf700b4: ret
    //     0xf700b4: ret             
    // 0xf700b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf700b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf700bc: b               #0xf70054
    // 0xf700c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf700c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf700c4: r9 = _summary
    //     0xf700c4: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xf700c8: ldr             x9, [x9, #0xcb8]
    // 0xf700cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf700cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xf7013c, size: 0x8c
    // 0xf7013c: EnterFrame
    //     0xf7013c: stp             fp, lr, [SP, #-0x10]!
    //     0xf70140: mov             fp, SP
    // 0xf70144: AllocStack(0x10)
    //     0xf70144: sub             SP, SP, #0x10
    // 0xf70148: SetupParameters([dynamic _ /* r0 */])
    //     0xf70148: ldr             x0, [fp, #0x20]
    //     0xf7014c: ldur            w1, [x0, #0x17]
    //     0xf70150: add             x1, x1, HEAP, lsl #32
    //     0xf70154: stur            x1, [fp, #-8]
    // 0xf70158: CheckStackOverflow
    //     0xf70158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7015c: cmp             SP, x16
    //     0xf70160: b.ls            #0xf701c0
    // 0xf70164: r1 = 2
    //     0xf70164: mov             x1, #2
    // 0xf70168: r0 = AllocateContext()
    //     0xf70168: bl              #0x13de838  ; AllocateContextStub
    // 0xf7016c: mov             x1, x0
    // 0xf70170: ldur            x0, [fp, #-8]
    // 0xf70174: StoreField: r1->field_b = r0
    //     0xf70174: stur            w0, [x1, #0xb]
    // 0xf70178: ldr             x2, [fp, #0x18]
    // 0xf7017c: StoreField: r1->field_f = r2
    //     0xf7017c: stur            w2, [x1, #0xf]
    // 0xf70180: ldr             x2, [fp, #0x10]
    // 0xf70184: StoreField: r1->field_13 = r2
    //     0xf70184: stur            w2, [x1, #0x13]
    // 0xf70188: LoadField: r3 = r0->field_f
    //     0xf70188: ldur            w3, [x0, #0xf]
    // 0xf7018c: DecompressPointer r3
    //     0xf7018c: add             x3, x3, HEAP, lsl #32
    // 0xf70190: mov             x2, x1
    // 0xf70194: stur            x3, [fp, #-0x10]
    // 0xf70198: r1 = Function '<anonymous closure>':.
    //     0xf70198: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd30] AnonymousClosure: (0xf701c8), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf7019c: ldr             x1, [x1, #0xd30]
    // 0xf701a0: r0 = AllocateClosure()
    //     0xf701a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf701a4: ldur            x1, [fp, #-0x10]
    // 0xf701a8: mov             x2, x0
    // 0xf701ac: r0 = setState()
    //     0xf701ac: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf701b0: r0 = Null
    //     0xf701b0: mov             x0, NULL
    // 0xf701b4: LeaveFrame
    //     0xf701b4: mov             SP, fp
    //     0xf701b8: ldp             fp, lr, [SP], #0x10
    // 0xf701bc: ret
    //     0xf701bc: ret             
    // 0xf701c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf701c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf701c4: b               #0xf70164
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf701c8, size: 0xbc
    // 0xf701c8: EnterFrame
    //     0xf701c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf701cc: mov             fp, SP
    // 0xf701d0: AllocStack(0x8)
    //     0xf701d0: sub             SP, SP, #8
    // 0xf701d4: SetupParameters([dynamic _ /* r0 */])
    //     0xf701d4: ldr             x0, [fp, #0x10]
    //     0xf701d8: ldur            w1, [x0, #0x17]
    //     0xf701dc: add             x1, x1, HEAP, lsl #32
    // 0xf701e0: CheckStackOverflow
    //     0xf701e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf701e4: cmp             SP, x16
    //     0xf701e8: b.ls            #0xf7026c
    // 0xf701ec: LoadField: r0 = r1->field_b
    //     0xf701ec: ldur            w0, [x1, #0xb]
    // 0xf701f0: DecompressPointer r0
    //     0xf701f0: add             x0, x0, HEAP, lsl #32
    // 0xf701f4: LoadField: r4 = r0->field_f
    //     0xf701f4: ldur            w4, [x0, #0xf]
    // 0xf701f8: DecompressPointer r4
    //     0xf701f8: add             x4, x4, HEAP, lsl #32
    // 0xf701fc: stur            x4, [fp, #-8]
    // 0xf70200: LoadField: r0 = r4->field_b
    //     0xf70200: ldur            w0, [x4, #0xb]
    // 0xf70204: DecompressPointer r0
    //     0xf70204: add             x0, x0, HEAP, lsl #32
    // 0xf70208: cmp             w0, NULL
    // 0xf7020c: b.eq            #0xf70274
    // 0xf70210: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xf70210: ldur            w2, [x4, #0x17]
    // 0xf70214: DecompressPointer r2
    //     0xf70214: add             x2, x2, HEAP, lsl #32
    // 0xf70218: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7021c: cmp             w2, w16
    // 0xf70220: b.eq            #0xf70278
    // 0xf70224: LoadField: r3 = r1->field_f
    //     0xf70224: ldur            w3, [x1, #0xf]
    // 0xf70228: DecompressPointer r3
    //     0xf70228: add             x3, x3, HEAP, lsl #32
    // 0xf7022c: LoadField: r5 = r1->field_13
    //     0xf7022c: ldur            w5, [x1, #0x13]
    // 0xf70230: DecompressPointer r5
    //     0xf70230: add             x5, x5, HEAP, lsl #32
    // 0xf70234: mov             x1, x0
    // 0xf70238: r0 = afterError()
    //     0xf70238: bl              #0xf70284  ; [package:flutter/src/widgets/async.dart] StreamBuilder::afterError
    // 0xf7023c: ldur            x1, [fp, #-8]
    // 0xf70240: ArrayStore: r1[0] = r0  ; List_4
    //     0xf70240: stur            w0, [x1, #0x17]
    //     0xf70244: ldurb           w16, [x1, #-1]
    //     0xf70248: ldurb           w17, [x0, #-1]
    //     0xf7024c: and             x16, x17, x16, lsr #2
    //     0xf70250: tst             x16, HEAP, lsr #32
    //     0xf70254: b.eq            #0xf7025c
    //     0xf70258: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7025c: r0 = Null
    //     0xf7025c: mov             x0, NULL
    // 0xf70260: LeaveFrame
    //     0xf70260: mov             SP, fp
    //     0xf70264: ldp             fp, lr, [SP], #0x10
    // 0xf70268: ret
    //     0xf70268: ret             
    // 0xf7026c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7026c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70270: b               #0xf701ec
    // 0xf70274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70274: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf70278: r9 = _summary
    //     0xf70278: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xf7027c: ldr             x9, [x9, #0xcb8]
    // 0xf70280: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf70280: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, C1X0) {
    // ** addr: 0xf702f8, size: 0x84
    // 0xf702f8: EnterFrame
    //     0xf702f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf702fc: mov             fp, SP
    // 0xf70300: AllocStack(0x10)
    //     0xf70300: sub             SP, SP, #0x10
    // 0xf70304: SetupParameters([dynamic _ /* r0 */])
    //     0xf70304: ldr             x0, [fp, #0x18]
    //     0xf70308: ldur            w1, [x0, #0x17]
    //     0xf7030c: add             x1, x1, HEAP, lsl #32
    //     0xf70310: stur            x1, [fp, #-8]
    // 0xf70314: CheckStackOverflow
    //     0xf70314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70318: cmp             SP, x16
    //     0xf7031c: b.ls            #0xf70374
    // 0xf70320: r1 = 1
    //     0xf70320: mov             x1, #1
    // 0xf70324: r0 = AllocateContext()
    //     0xf70324: bl              #0x13de838  ; AllocateContextStub
    // 0xf70328: mov             x1, x0
    // 0xf7032c: ldur            x0, [fp, #-8]
    // 0xf70330: StoreField: r1->field_b = r0
    //     0xf70330: stur            w0, [x1, #0xb]
    // 0xf70334: ldr             x2, [fp, #0x10]
    // 0xf70338: StoreField: r1->field_f = r2
    //     0xf70338: stur            w2, [x1, #0xf]
    // 0xf7033c: LoadField: r3 = r0->field_f
    //     0xf7033c: ldur            w3, [x0, #0xf]
    // 0xf70340: DecompressPointer r3
    //     0xf70340: add             x3, x3, HEAP, lsl #32
    // 0xf70344: mov             x2, x1
    // 0xf70348: stur            x3, [fp, #-0x10]
    // 0xf7034c: r1 = Function '<anonymous closure>':.
    //     0xf7034c: add             x1, PP, #0xab, lsl #12  ; [pp+0xabd48] AnonymousClosure: (0xf7037c), in [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe (0xf6fdac)
    //     0xf70350: ldr             x1, [x1, #0xd48]
    // 0xf70354: r0 = AllocateClosure()
    //     0xf70354: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf70358: ldur            x1, [fp, #-0x10]
    // 0xf7035c: mov             x2, x0
    // 0xf70360: r0 = setState()
    //     0xf70360: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf70364: r0 = Null
    //     0xf70364: mov             x0, NULL
    // 0xf70368: LeaveFrame
    //     0xf70368: mov             SP, fp
    //     0xf7036c: ldp             fp, lr, [SP], #0x10
    // 0xf70370: ret
    //     0xf70370: ret             
    // 0xf70374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70378: b               #0xf70320
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7037c, size: 0xb4
    // 0xf7037c: EnterFrame
    //     0xf7037c: stp             fp, lr, [SP, #-0x10]!
    //     0xf70380: mov             fp, SP
    // 0xf70384: AllocStack(0x8)
    //     0xf70384: sub             SP, SP, #8
    // 0xf70388: SetupParameters([dynamic _ /* r0 */])
    //     0xf70388: ldr             x0, [fp, #0x10]
    //     0xf7038c: ldur            w1, [x0, #0x17]
    //     0xf70390: add             x1, x1, HEAP, lsl #32
    // 0xf70394: CheckStackOverflow
    //     0xf70394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70398: cmp             SP, x16
    //     0xf7039c: b.ls            #0xf70418
    // 0xf703a0: LoadField: r0 = r1->field_b
    //     0xf703a0: ldur            w0, [x1, #0xb]
    // 0xf703a4: DecompressPointer r0
    //     0xf703a4: add             x0, x0, HEAP, lsl #32
    // 0xf703a8: LoadField: r4 = r0->field_f
    //     0xf703a8: ldur            w4, [x0, #0xf]
    // 0xf703ac: DecompressPointer r4
    //     0xf703ac: add             x4, x4, HEAP, lsl #32
    // 0xf703b0: stur            x4, [fp, #-8]
    // 0xf703b4: LoadField: r0 = r4->field_b
    //     0xf703b4: ldur            w0, [x4, #0xb]
    // 0xf703b8: DecompressPointer r0
    //     0xf703b8: add             x0, x0, HEAP, lsl #32
    // 0xf703bc: cmp             w0, NULL
    // 0xf703c0: b.eq            #0xf70420
    // 0xf703c4: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xf703c4: ldur            w2, [x4, #0x17]
    // 0xf703c8: DecompressPointer r2
    //     0xf703c8: add             x2, x2, HEAP, lsl #32
    // 0xf703cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf703d0: cmp             w2, w16
    // 0xf703d4: b.eq            #0xf70424
    // 0xf703d8: LoadField: r3 = r1->field_f
    //     0xf703d8: ldur            w3, [x1, #0xf]
    // 0xf703dc: DecompressPointer r3
    //     0xf703dc: add             x3, x3, HEAP, lsl #32
    // 0xf703e0: mov             x1, x0
    // 0xf703e4: r0 = afterData()
    //     0xf703e4: bl              #0xf70430  ; [package:flutter/src/widgets/async.dart] StreamBuilder::afterData
    // 0xf703e8: ldur            x1, [fp, #-8]
    // 0xf703ec: ArrayStore: r1[0] = r0  ; List_4
    //     0xf703ec: stur            w0, [x1, #0x17]
    //     0xf703f0: ldurb           w16, [x1, #-1]
    //     0xf703f4: ldurb           w17, [x0, #-1]
    //     0xf703f8: and             x16, x17, x16, lsr #2
    //     0xf703fc: tst             x16, HEAP, lsr #32
    //     0xf70400: b.eq            #0xf70408
    //     0xf70404: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf70408: r0 = Null
    //     0xf70408: mov             x0, NULL
    // 0xf7040c: LeaveFrame
    //     0xf7040c: mov             SP, fp
    //     0xf70410: ldp             fp, lr, [SP], #0x10
    // 0xf70414: ret
    //     0xf70414: ret             
    // 0xf70418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7041c: b               #0xf703a0
    // 0xf70420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70420: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf70424: r9 = _summary
    //     0xf70424: add             x9, PP, #0xab, lsl #12  ; [pp+0xabcb8] Field <_StreamBuilderBaseState@522480208._summary@522480208>: late (offset: 0x18)
    //     0xf70428: ldr             x9, [x9, #0xcb8]
    // 0xf7042c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf7042c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _unsubscribe(/* No info */) {
    // ** addr: 0xf70534, size: 0x64
    // 0xf70534: EnterFrame
    //     0xf70534: stp             fp, lr, [SP, #-0x10]!
    //     0xf70538: mov             fp, SP
    // 0xf7053c: AllocStack(0x8)
    //     0xf7053c: sub             SP, SP, #8
    // 0xf70540: SetupParameters(_StreamBuilderBaseState<C1X0, C1X1> this /* r1 => r2, fp-0x8 */)
    //     0xf70540: mov             x2, x1
    //     0xf70544: stur            x1, [fp, #-8]
    // 0xf70548: CheckStackOverflow
    //     0xf70548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7054c: cmp             SP, x16
    //     0xf70550: b.ls            #0xf70590
    // 0xf70554: LoadField: r1 = r2->field_13
    //     0xf70554: ldur            w1, [x2, #0x13]
    // 0xf70558: DecompressPointer r1
    //     0xf70558: add             x1, x1, HEAP, lsl #32
    // 0xf7055c: cmp             w1, NULL
    // 0xf70560: b.eq            #0xf70580
    // 0xf70564: r0 = LoadClassIdInstr(r1)
    //     0xf70564: ldur            x0, [x1, #-1]
    //     0xf70568: ubfx            x0, x0, #0xc, #0x14
    // 0xf7056c: r0 = GDT[cid_x0 + 0x549]()
    //     0xf7056c: add             lr, x0, #0x549
    //     0xf70570: ldr             lr, [x21, lr, lsl #3]
    //     0xf70574: blr             lr
    // 0xf70578: ldur            x1, [fp, #-8]
    // 0xf7057c: StoreField: r1->field_13 = rNULL
    //     0xf7057c: stur            NULL, [x1, #0x13]
    // 0xf70580: r0 = Null
    //     0xf70580: mov             x0, NULL
    // 0xf70584: LeaveFrame
    //     0xf70584: mov             SP, fp
    //     0xf70588: ldp             fp, lr, [SP], #0x10
    // 0xf7058c: ret
    //     0xf7058c: ret             
    // 0xf70590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70594: b               #0xf70554
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91a18, size: 0x74
    // 0xf91a18: EnterFrame
    //     0xf91a18: stp             fp, lr, [SP, #-0x10]!
    //     0xf91a1c: mov             fp, SP
    // 0xf91a20: AllocStack(0x8)
    //     0xf91a20: sub             SP, SP, #8
    // 0xf91a24: SetupParameters(_StreamBuilderBaseState<C1X0, C1X1> this /* r1 => r0, fp-0x8 */)
    //     0xf91a24: mov             x0, x1
    //     0xf91a28: stur            x1, [fp, #-8]
    // 0xf91a2c: CheckStackOverflow
    //     0xf91a2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91a30: cmp             SP, x16
    //     0xf91a34: b.ls            #0xf91a80
    // 0xf91a38: LoadField: r1 = r0->field_b
    //     0xf91a38: ldur            w1, [x0, #0xb]
    // 0xf91a3c: DecompressPointer r1
    //     0xf91a3c: add             x1, x1, HEAP, lsl #32
    // 0xf91a40: cmp             w1, NULL
    // 0xf91a44: b.eq            #0xf91a88
    // 0xf91a48: r0 = initial()
    //     0xf91a48: bl              #0xf91a8c  ; [package:flutter/src/widgets/async.dart] StreamBuilder::initial
    // 0xf91a4c: ldur            x1, [fp, #-8]
    // 0xf91a50: ArrayStore: r1[0] = r0  ; List_4
    //     0xf91a50: stur            w0, [x1, #0x17]
    //     0xf91a54: ldurb           w16, [x1, #-1]
    //     0xf91a58: ldurb           w17, [x0, #-1]
    //     0xf91a5c: and             x16, x17, x16, lsr #2
    //     0xf91a60: tst             x16, HEAP, lsr #32
    //     0xf91a64: b.eq            #0xf91a6c
    //     0xf91a68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf91a6c: r0 = _subscribe()
    //     0xf91a6c: bl              #0xf6fdac  ; [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_subscribe
    // 0xf91a70: r0 = Null
    //     0xf91a70: mov             x0, NULL
    // 0xf91a74: LeaveFrame
    //     0xf91a74: mov             SP, fp
    //     0xf91a78: ldp             fp, lr, [SP], #0x10
    // 0xf91a7c: ret
    //     0xf91a7c: ret             
    // 0xf91a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91a80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91a84: b               #0xf91a38
    // 0xf91a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91a88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e6470, size: 0x30
    // 0x10e6470: EnterFrame
    //     0x10e6470: stp             fp, lr, [SP, #-0x10]!
    //     0x10e6474: mov             fp, SP
    // 0x10e6478: CheckStackOverflow
    //     0x10e6478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e647c: cmp             SP, x16
    //     0x10e6480: b.ls            #0x10e6498
    // 0x10e6484: r0 = _unsubscribe()
    //     0x10e6484: bl              #0xf70534  ; [package:flutter/src/widgets/async.dart] _StreamBuilderBaseState::_unsubscribe
    // 0x10e6488: r0 = Null
    //     0x10e6488: mov             x0, NULL
    // 0x10e648c: LeaveFrame
    //     0x10e648c: mov             SP, fp
    //     0x10e6490: ldp             fp, lr, [SP], #0x10
    // 0x10e6494: ret
    //     0x10e6494: ret             
    // 0x10e6498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e6498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e649c: b               #0x10e6484
  }
}

// class id: 6402, size: 0x1c, field offset: 0xc
//   const constructor, 
class FutureBuilder<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa38bc, size: 0x44
    // 0xfa38bc: EnterFrame
    //     0xfa38bc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa38c0: mov             fp, SP
    // 0xfa38c4: LoadField: r2 = r1->field_b
    //     0xfa38c4: ldur            w2, [x1, #0xb]
    // 0xfa38c8: DecompressPointer r2
    //     0xfa38c8: add             x2, x2, HEAP, lsl #32
    // 0xfa38cc: r1 = Null
    //     0xfa38cc: mov             x1, NULL
    // 0xfa38d0: r3 = <FutureBuilder<X0>, X0>
    //     0xfa38d0: add             x3, PP, #0x80, lsl #12  ; [pp+0x80f00] TypeArguments: <FutureBuilder<X0>, X0>
    //     0xfa38d4: ldr             x3, [x3, #0xf00]
    // 0xfa38d8: r30 = InstantiateTypeArgumentsStub
    //     0xfa38d8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa38dc: LoadField: r30 = r30->field_7
    //     0xfa38dc: ldur            lr, [lr, #7]
    // 0xfa38e0: blr             lr
    // 0xfa38e4: mov             x1, x0
    // 0xfa38e8: r0 = _FutureBuilderState()
    //     0xfa38e8: bl              #0xfa3900  ; Allocate_FutureBuilderStateStub -> _FutureBuilderState<C1X0> (size=0x1c)
    // 0xfa38ec: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa38f0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa38f0: stur            w1, [x0, #0x17]
    // 0xfa38f4: LeaveFrame
    //     0xfa38f4: mov             SP, fp
    //     0xfa38f8: ldp             fp, lr, [SP], #0x10
    // 0xfa38fc: ret
    //     0xfa38fc: ret             
  }
}

// class id: 6403, size: 0x14, field offset: 0xc
//   const constructor, 
abstract class StreamBuilderBase<X0, X1> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa386c, size: 0x44
    // 0xfa386c: EnterFrame
    //     0xfa386c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3870: mov             fp, SP
    // 0xfa3874: LoadField: r2 = r1->field_b
    //     0xfa3874: ldur            w2, [x1, #0xb]
    // 0xfa3878: DecompressPointer r2
    //     0xfa3878: add             x2, x2, HEAP, lsl #32
    // 0xfa387c: r1 = Null
    //     0xfa387c: mov             x1, NULL
    // 0xfa3880: r3 = <StreamBuilderBase<X0, X1>, X0, X1>
    //     0xfa3880: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1a00] TypeArguments: <StreamBuilderBase<X0, X1>, X0, X1>
    //     0xfa3884: ldr             x3, [x3, #0xa00]
    // 0xfa3888: r30 = InstantiateTypeArgumentsStub
    //     0xfa3888: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa388c: LoadField: r30 = r30->field_7
    //     0xfa388c: ldur            lr, [lr, #7]
    // 0xfa3890: blr             lr
    // 0xfa3894: mov             x1, x0
    // 0xfa3898: r0 = _StreamBuilderBaseState()
    //     0xfa3898: bl              #0xfa38b0  ; Allocate_StreamBuilderBaseStateStub -> _StreamBuilderBaseState<C1X0, C1X1> (size=0x1c)
    // 0xfa389c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa38a0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa38a0: stur            w1, [x0, #0x17]
    // 0xfa38a4: LeaveFrame
    //     0xfa38a4: mov             SP, fp
    //     0xfa38a8: ldp             fp, lr, [SP], #0x10
    // 0xfa38ac: ret
    //     0xfa38ac: ret             
  }
}

// class id: 6404, size: 0x1c, field offset: 0x14
//   const constructor, 
class StreamBuilder<C2X0> extends StreamBuilderBase<C2X0, dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xe09078, size: 0x94
    // 0xe09078: EnterFrame
    //     0xe09078: stp             fp, lr, [SP, #-0x10]!
    //     0xe0907c: mov             fp, SP
    // 0xe09080: AllocStack(0x30)
    //     0xe09080: sub             SP, SP, #0x30
    // 0xe09084: SetupParameters(StreamBuilder<C2X0> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xe09084: mov             x5, x1
    //     0xe09088: mov             x4, x2
    //     0xe0908c: stur            x1, [fp, #-8]
    //     0xe09090: stur            x2, [fp, #-0x10]
    //     0xe09094: stur            x3, [fp, #-0x18]
    // 0xe09098: CheckStackOverflow
    //     0xe09098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0909c: cmp             SP, x16
    //     0xe090a0: b.ls            #0xe09104
    // 0xe090a4: LoadField: r2 = r5->field_b
    //     0xe090a4: ldur            w2, [x5, #0xb]
    // 0xe090a8: DecompressPointer r2
    //     0xe090a8: add             x2, x2, HEAP, lsl #32
    // 0xe090ac: mov             x0, x3
    // 0xe090b0: r1 = Null
    //     0xe090b0: mov             x1, NULL
    // 0xe090b4: r8 = AsyncSnapshot<C2X0>
    //     0xe090b4: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xe090b8: ldr             x8, [x8, #0xcc0]
    // 0xe090bc: LoadField: r9 = r8->field_7
    //     0xe090bc: ldur            x9, [x8, #7]
    // 0xe090c0: r3 = Null
    //     0xe090c0: add             x3, PP, #0xab, lsl #12  ; [pp+0xabcc8] Null
    //     0xe090c4: ldr             x3, [x3, #0xcc8]
    // 0xe090c8: blr             x9
    // 0xe090cc: ldur            x0, [fp, #-8]
    // 0xe090d0: LoadField: r1 = r0->field_13
    //     0xe090d0: ldur            w1, [x0, #0x13]
    // 0xe090d4: DecompressPointer r1
    //     0xe090d4: add             x1, x1, HEAP, lsl #32
    // 0xe090d8: ldur            x16, [fp, #-0x10]
    // 0xe090dc: stp             x16, x1, [SP, #8]
    // 0xe090e0: ldur            x16, [fp, #-0x18]
    // 0xe090e4: str             x16, [SP]
    // 0xe090e8: mov             x0, x1
    // 0xe090ec: ClosureCall
    //     0xe090ec: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xe090f0: ldur            x2, [x0, #0x1f]
    //     0xe090f4: blr             x2
    // 0xe090f8: LeaveFrame
    //     0xe090f8: mov             SP, fp
    //     0xe090fc: ldp             fp, lr, [SP], #0x10
    // 0xe09100: ret
    //     0xe09100: ret             
    // 0xe09104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe09104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe09108: b               #0xe090a4
  }
  _ afterConnected(/* No info */) {
    // ** addr: 0xf6fee8, size: 0x6c
    // 0xf6fee8: EnterFrame
    //     0xf6fee8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6feec: mov             fp, SP
    // 0xf6fef0: AllocStack(0x8)
    //     0xf6fef0: sub             SP, SP, #8
    // 0xf6fef4: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xf6fef4: mov             x3, x2
    //     0xf6fef8: stur            x2, [fp, #-8]
    // 0xf6fefc: CheckStackOverflow
    //     0xf6fefc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ff00: cmp             SP, x16
    //     0xf6ff04: b.ls            #0xf6ff4c
    // 0xf6ff08: LoadField: r2 = r1->field_b
    //     0xf6ff08: ldur            w2, [x1, #0xb]
    // 0xf6ff0c: DecompressPointer r2
    //     0xf6ff0c: add             x2, x2, HEAP, lsl #32
    // 0xf6ff10: mov             x0, x3
    // 0xf6ff14: r1 = Null
    //     0xf6ff14: mov             x1, NULL
    // 0xf6ff18: r8 = AsyncSnapshot<C2X0>
    //     0xf6ff18: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xf6ff1c: ldr             x8, [x8, #0xcc0]
    // 0xf6ff20: LoadField: r9 = r8->field_7
    //     0xf6ff20: ldur            x9, [x8, #7]
    // 0xf6ff24: r3 = Null
    //     0xf6ff24: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd70] Null
    //     0xf6ff28: ldr             x3, [x3, #0xd70]
    // 0xf6ff2c: blr             x9
    // 0xf6ff30: ldur            x1, [fp, #-8]
    // 0xf6ff34: r2 = Instance_ConnectionState
    //     0xf6ff34: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7b2a0] Obj!ConnectionState@12c3541
    //     0xf6ff38: ldr             x2, [x2, #0x2a0]
    // 0xf6ff3c: r0 = inState()
    //     0xf6ff3c: bl              #0xf6ff54  ; [package:flutter/src/widgets/async.dart] AsyncSnapshot::inState
    // 0xf6ff40: LeaveFrame
    //     0xf6ff40: mov             SP, fp
    //     0xf6ff44: ldp             fp, lr, [SP], #0x10
    // 0xf6ff48: ret
    //     0xf6ff48: ret             
    // 0xf6ff4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ff4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6ff50: b               #0xf6ff08
  }
  _ afterDone(/* No info */) {
    // ** addr: 0xf700d0, size: 0x6c
    // 0xf700d0: EnterFrame
    //     0xf700d0: stp             fp, lr, [SP, #-0x10]!
    //     0xf700d4: mov             fp, SP
    // 0xf700d8: AllocStack(0x8)
    //     0xf700d8: sub             SP, SP, #8
    // 0xf700dc: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xf700dc: mov             x3, x2
    //     0xf700e0: stur            x2, [fp, #-8]
    // 0xf700e4: CheckStackOverflow
    //     0xf700e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf700e8: cmp             SP, x16
    //     0xf700ec: b.ls            #0xf70134
    // 0xf700f0: LoadField: r2 = r1->field_b
    //     0xf700f0: ldur            w2, [x1, #0xb]
    // 0xf700f4: DecompressPointer r2
    //     0xf700f4: add             x2, x2, HEAP, lsl #32
    // 0xf700f8: mov             x0, x3
    // 0xf700fc: r1 = Null
    //     0xf700fc: mov             x1, NULL
    // 0xf70100: r8 = AsyncSnapshot<C2X0>
    //     0xf70100: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xf70104: ldr             x8, [x8, #0xcc0]
    // 0xf70108: LoadField: r9 = r8->field_7
    //     0xf70108: ldur            x9, [x8, #7]
    // 0xf7010c: r3 = Null
    //     0xf7010c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd20] Null
    //     0xf70110: ldr             x3, [x3, #0xd20]
    // 0xf70114: blr             x9
    // 0xf70118: ldur            x1, [fp, #-8]
    // 0xf7011c: r2 = Instance_ConnectionState
    //     0xf7011c: add             x2, PP, #0x8d, lsl #12  ; [pp+0x8d210] Obj!ConnectionState@12c3581
    //     0xf70120: ldr             x2, [x2, #0x210]
    // 0xf70124: r0 = inState()
    //     0xf70124: bl              #0xf6ff54  ; [package:flutter/src/widgets/async.dart] AsyncSnapshot::inState
    // 0xf70128: LeaveFrame
    //     0xf70128: mov             SP, fp
    //     0xf7012c: ldp             fp, lr, [SP], #0x10
    // 0xf70130: ret
    //     0xf70130: ret             
    // 0xf70134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70138: b               #0xf700f0
  }
  _ afterError(/* No info */) {
    // ** addr: 0xf70284, size: 0x74
    // 0xf70284: EnterFrame
    //     0xf70284: stp             fp, lr, [SP, #-0x10]!
    //     0xf70288: mov             fp, SP
    // 0xf7028c: AllocStack(0x18)
    //     0xf7028c: sub             SP, SP, #0x18
    // 0xf70290: SetupParameters(dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xf70290: mov             x0, x2
    //     0xf70294: stur            x3, [fp, #-0x10]
    //     0xf70298: stur            x5, [fp, #-0x18]
    // 0xf7029c: LoadField: r4 = r1->field_b
    //     0xf7029c: ldur            w4, [x1, #0xb]
    // 0xf702a0: DecompressPointer r4
    //     0xf702a0: add             x4, x4, HEAP, lsl #32
    // 0xf702a4: mov             x2, x4
    // 0xf702a8: stur            x4, [fp, #-8]
    // 0xf702ac: r1 = Null
    //     0xf702ac: mov             x1, NULL
    // 0xf702b0: r8 = AsyncSnapshot<C2X0>
    //     0xf702b0: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xf702b4: ldr             x8, [x8, #0xcc0]
    // 0xf702b8: LoadField: r9 = r8->field_7
    //     0xf702b8: ldur            x9, [x8, #7]
    // 0xf702bc: r3 = Null
    //     0xf702bc: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd38] Null
    //     0xf702c0: ldr             x3, [x3, #0xd38]
    // 0xf702c4: blr             x9
    // 0xf702c8: ldur            x1, [fp, #-8]
    // 0xf702cc: r0 = AsyncSnapshot()
    //     0xf702cc: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf702d0: r1 = Instance_ConnectionState
    //     0xf702d0: add             x1, PP, #0x92, lsl #12  ; [pp+0x922a0] Obj!ConnectionState@12c3561
    //     0xf702d4: ldr             x1, [x1, #0x2a0]
    // 0xf702d8: StoreField: r0->field_b = r1
    //     0xf702d8: stur            w1, [x0, #0xb]
    // 0xf702dc: ldur            x1, [fp, #-0x10]
    // 0xf702e0: StoreField: r0->field_13 = r1
    //     0xf702e0: stur            w1, [x0, #0x13]
    // 0xf702e4: ldur            x1, [fp, #-0x18]
    // 0xf702e8: ArrayStore: r0[0] = r1  ; List_4
    //     0xf702e8: stur            w1, [x0, #0x17]
    // 0xf702ec: LeaveFrame
    //     0xf702ec: mov             SP, fp
    //     0xf702f0: ldp             fp, lr, [SP], #0x10
    // 0xf702f4: ret
    //     0xf702f4: ret             
  }
  _ afterData(/* No info */) {
    // ** addr: 0xf70430, size: 0x98
    // 0xf70430: EnterFrame
    //     0xf70430: stp             fp, lr, [SP, #-0x10]!
    //     0xf70434: mov             fp, SP
    // 0xf70438: AllocStack(0x10)
    //     0xf70438: sub             SP, SP, #0x10
    // 0xf7043c: SetupParameters(dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xf7043c: mov             x0, x2
    //     0xf70440: stur            x3, [fp, #-0x10]
    // 0xf70444: LoadField: r4 = r1->field_b
    //     0xf70444: ldur            w4, [x1, #0xb]
    // 0xf70448: DecompressPointer r4
    //     0xf70448: add             x4, x4, HEAP, lsl #32
    // 0xf7044c: mov             x2, x4
    // 0xf70450: stur            x4, [fp, #-8]
    // 0xf70454: r1 = Null
    //     0xf70454: mov             x1, NULL
    // 0xf70458: r8 = AsyncSnapshot<C2X0>
    //     0xf70458: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xf7045c: ldr             x8, [x8, #0xcc0]
    // 0xf70460: LoadField: r9 = r8->field_7
    //     0xf70460: ldur            x9, [x8, #7]
    // 0xf70464: r3 = Null
    //     0xf70464: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd50] Null
    //     0xf70468: ldr             x3, [x3, #0xd50]
    // 0xf7046c: blr             x9
    // 0xf70470: ldur            x0, [fp, #-0x10]
    // 0xf70474: ldur            x2, [fp, #-8]
    // 0xf70478: r1 = Null
    //     0xf70478: mov             x1, NULL
    // 0xf7047c: cmp             w2, NULL
    // 0xf70480: b.eq            #0xf704a0
    // 0xf70484: LoadField: r4 = r2->field_1f
    //     0xf70484: ldur            w4, [x2, #0x1f]
    // 0xf70488: DecompressPointer r4
    //     0xf70488: add             x4, x4, HEAP, lsl #32
    // 0xf7048c: r8 = C2X0
    //     0xf7048c: ldr             x8, [PP, #0x758]  ; [pp+0x758] TypeParameter: C2X0
    // 0xf70490: LoadField: r9 = r4->field_7
    //     0xf70490: ldur            x9, [x4, #7]
    // 0xf70494: r3 = Null
    //     0xf70494: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd60] Null
    //     0xf70498: ldr             x3, [x3, #0xd60]
    // 0xf7049c: blr             x9
    // 0xf704a0: ldur            x1, [fp, #-8]
    // 0xf704a4: r0 = AsyncSnapshot()
    //     0xf704a4: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf704a8: r1 = Instance_ConnectionState
    //     0xf704a8: add             x1, PP, #0x92, lsl #12  ; [pp+0x922a0] Obj!ConnectionState@12c3561
    //     0xf704ac: ldr             x1, [x1, #0x2a0]
    // 0xf704b0: StoreField: r0->field_b = r1
    //     0xf704b0: stur            w1, [x0, #0xb]
    // 0xf704b4: ldur            x1, [fp, #-0x10]
    // 0xf704b8: StoreField: r0->field_f = r1
    //     0xf704b8: stur            w1, [x0, #0xf]
    // 0xf704bc: LeaveFrame
    //     0xf704bc: mov             SP, fp
    //     0xf704c0: ldp             fp, lr, [SP], #0x10
    // 0xf704c4: ret
    //     0xf704c4: ret             
  }
  _ afterDisconnected(/* No info */) {
    // ** addr: 0xf704c8, size: 0x6c
    // 0xf704c8: EnterFrame
    //     0xf704c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf704cc: mov             fp, SP
    // 0xf704d0: AllocStack(0x8)
    //     0xf704d0: sub             SP, SP, #8
    // 0xf704d4: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xf704d4: mov             x3, x2
    //     0xf704d8: stur            x2, [fp, #-8]
    // 0xf704dc: CheckStackOverflow
    //     0xf704dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf704e0: cmp             SP, x16
    //     0xf704e4: b.ls            #0xf7052c
    // 0xf704e8: LoadField: r2 = r1->field_b
    //     0xf704e8: ldur            w2, [x1, #0xb]
    // 0xf704ec: DecompressPointer r2
    //     0xf704ec: add             x2, x2, HEAP, lsl #32
    // 0xf704f0: mov             x0, x3
    // 0xf704f4: r1 = Null
    //     0xf704f4: mov             x1, NULL
    // 0xf704f8: r8 = AsyncSnapshot<C2X0>
    //     0xf704f8: add             x8, PP, #0xab, lsl #12  ; [pp+0xabcc0] Type: AsyncSnapshot<C2X0>
    //     0xf704fc: ldr             x8, [x8, #0xcc0]
    // 0xf70500: LoadField: r9 = r8->field_7
    //     0xf70500: ldur            x9, [x8, #7]
    // 0xf70504: r3 = Null
    //     0xf70504: add             x3, PP, #0xab, lsl #12  ; [pp+0xabd80] Null
    //     0xf70508: ldr             x3, [x3, #0xd80]
    // 0xf7050c: blr             x9
    // 0xf70510: ldur            x1, [fp, #-8]
    // 0xf70514: r2 = Instance_ConnectionState
    //     0xf70514: add             x2, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf70518: ldr             x2, [x2, #0x1f8]
    // 0xf7051c: r0 = inState()
    //     0xf7051c: bl              #0xf6ff54  ; [package:flutter/src/widgets/async.dart] AsyncSnapshot::inState
    // 0xf70520: LeaveFrame
    //     0xf70520: mov             SP, fp
    //     0xf70524: ldp             fp, lr, [SP], #0x10
    // 0xf70528: ret
    //     0xf70528: ret             
    // 0xf7052c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7052c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70530: b               #0xf704e8
  }
  _ initial(/* No info */) {
    // ** addr: 0xf91a8c, size: 0x78
    // 0xf91a8c: EnterFrame
    //     0xf91a8c: stp             fp, lr, [SP, #-0x10]!
    //     0xf91a90: mov             fp, SP
    // 0xf91a94: AllocStack(0x8)
    //     0xf91a94: sub             SP, SP, #8
    // 0xf91a98: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf91a98: ldur            w0, [x1, #0x17]
    // 0xf91a9c: DecompressPointer r0
    //     0xf91a9c: add             x0, x0, HEAP, lsl #32
    // 0xf91aa0: stur            x0, [fp, #-8]
    // 0xf91aa4: cmp             w0, NULL
    // 0xf91aa8: b.ne            #0xf91acc
    // 0xf91aac: LoadField: r0 = r1->field_b
    //     0xf91aac: ldur            w0, [x1, #0xb]
    // 0xf91ab0: DecompressPointer r0
    //     0xf91ab0: add             x0, x0, HEAP, lsl #32
    // 0xf91ab4: mov             x1, x0
    // 0xf91ab8: r0 = AsyncSnapshot()
    //     0xf91ab8: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf91abc: r2 = Instance_ConnectionState
    //     0xf91abc: add             x2, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf91ac0: ldr             x2, [x2, #0x1f8]
    // 0xf91ac4: StoreField: r0->field_b = r2
    //     0xf91ac4: stur            w2, [x0, #0xb]
    // 0xf91ac8: b               #0xf91af8
    // 0xf91acc: r2 = Instance_ConnectionState
    //     0xf91acc: add             x2, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf91ad0: ldr             x2, [x2, #0x1f8]
    // 0xf91ad4: LoadField: r3 = r1->field_b
    //     0xf91ad4: ldur            w3, [x1, #0xb]
    // 0xf91ad8: DecompressPointer r3
    //     0xf91ad8: add             x3, x3, HEAP, lsl #32
    // 0xf91adc: mov             x1, x3
    // 0xf91ae0: r0 = AsyncSnapshot()
    //     0xf91ae0: bl              #0xf6ffc4  ; AllocateAsyncSnapshotStub -> AsyncSnapshot<X0> (size=0x1c)
    // 0xf91ae4: r1 = Instance_ConnectionState
    //     0xf91ae4: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d1f8] Obj!ConnectionState@12c35a1
    //     0xf91ae8: ldr             x1, [x1, #0x1f8]
    // 0xf91aec: StoreField: r0->field_b = r1
    //     0xf91aec: stur            w1, [x0, #0xb]
    // 0xf91af0: ldur            x1, [fp, #-8]
    // 0xf91af4: StoreField: r0->field_f = r1
    //     0xf91af4: stur            w1, [x0, #0xf]
    // 0xf91af8: LeaveFrame
    //     0xf91af8: mov             SP, fp
    //     0xf91afc: ldp             fp, lr, [SP], #0x10
    // 0xf91b00: ret
    //     0xf91b00: ret             
  }
}

// class id: 8189, size: 0x14, field offset: 0x14
enum ConnectionState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abd78, size: 0x64
    // 0x11abd78: EnterFrame
    //     0x11abd78: stp             fp, lr, [SP, #-0x10]!
    //     0x11abd7c: mov             fp, SP
    // 0x11abd80: AllocStack(0x10)
    //     0x11abd80: sub             SP, SP, #0x10
    // 0x11abd84: SetupParameters(ConnectionState this /* r1 => r0, fp-0x8 */)
    //     0x11abd84: mov             x0, x1
    //     0x11abd88: stur            x1, [fp, #-8]
    // 0x11abd8c: CheckStackOverflow
    //     0x11abd8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abd90: cmp             SP, x16
    //     0x11abd94: b.ls            #0x11abdd4
    // 0x11abd98: r1 = Null
    //     0x11abd98: mov             x1, NULL
    // 0x11abd9c: r2 = 4
    //     0x11abd9c: mov             x2, #4
    // 0x11abda0: r0 = AllocateArray()
    //     0x11abda0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abda4: r16 = "ConnectionState."
    //     0x11abda4: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d1a8] "ConnectionState."
    //     0x11abda8: ldr             x16, [x16, #0x1a8]
    // 0x11abdac: StoreField: r0->field_f = r16
    //     0x11abdac: stur            w16, [x0, #0xf]
    // 0x11abdb0: ldur            x1, [fp, #-8]
    // 0x11abdb4: LoadField: r2 = r1->field_f
    //     0x11abdb4: ldur            w2, [x1, #0xf]
    // 0x11abdb8: DecompressPointer r2
    //     0x11abdb8: add             x2, x2, HEAP, lsl #32
    // 0x11abdbc: StoreField: r0->field_13 = r2
    //     0x11abdbc: stur            w2, [x0, #0x13]
    // 0x11abdc0: str             x0, [SP]
    // 0x11abdc4: r0 = _interpolate()
    //     0x11abdc4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abdc8: LeaveFrame
    //     0x11abdc8: mov             SP, fp
    //     0x11abdcc: ldp             fp, lr, [SP], #0x10
    // 0x11abdd0: ret
    //     0x11abdd0: ret             
    // 0x11abdd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abdd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abdd8: b               #0x11abd98
  }
}
