// lib: , url: package:flutter/src/widgets/annotated_region.dart

// class id: 1049114, size: 0x8
class :: {
}

// class id: 6648, size: 0x1c, field offset: 0x10
//   const constructor, 
class AnnotatedRegion<X0> extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf53c0, size: 0x84
    // 0xcf53c0: EnterFrame
    //     0xcf53c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf53c4: mov             fp, SP
    // 0xcf53c8: AllocStack(0x10)
    //     0xcf53c8: sub             SP, SP, #0x10
    // 0xcf53cc: SetupParameters(AnnotatedRegion<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf53cc: mov             x4, x1
    //     0xcf53d0: stur            x1, [fp, #-8]
    //     0xcf53d4: stur            x3, [fp, #-0x10]
    // 0xcf53d8: CheckStackOverflow
    //     0xcf53d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf53dc: cmp             SP, x16
    //     0xcf53e0: b.ls            #0xcf543c
    // 0xcf53e4: LoadField: r2 = r4->field_f
    //     0xcf53e4: ldur            w2, [x4, #0xf]
    // 0xcf53e8: DecompressPointer r2
    //     0xcf53e8: add             x2, x2, HEAP, lsl #32
    // 0xcf53ec: mov             x0, x3
    // 0xcf53f0: r1 = Null
    //     0xcf53f0: mov             x1, NULL
    // 0xcf53f4: r8 = RenderAnnotatedRegion<X0>
    //     0xcf53f4: add             x8, PP, #0x26, lsl #12  ; [pp+0x267b0] Type: RenderAnnotatedRegion<X0>
    //     0xcf53f8: ldr             x8, [x8, #0x7b0]
    // 0xcf53fc: LoadField: r9 = r8->field_7
    //     0xcf53fc: ldur            x9, [x8, #7]
    // 0xcf5400: r3 = Null
    //     0xcf5400: add             x3, PP, #0x26, lsl #12  ; [pp+0x267b8] Null
    //     0xcf5404: ldr             x3, [x3, #0x7b8]
    // 0xcf5408: blr             x9
    // 0xcf540c: ldur            x0, [fp, #-8]
    // 0xcf5410: LoadField: r2 = r0->field_13
    //     0xcf5410: ldur            w2, [x0, #0x13]
    // 0xcf5414: DecompressPointer r2
    //     0xcf5414: add             x2, x2, HEAP, lsl #32
    // 0xcf5418: ldur            x1, [fp, #-0x10]
    // 0xcf541c: r0 = value=()
    //     0xcf541c: bl              #0xc02bcc  ; [package:flutter/src/rendering/proxy_box.dart] RenderAnnotatedRegion::value=
    // 0xcf5420: ldur            x1, [fp, #-0x10]
    // 0xcf5424: r2 = true
    //     0xcf5424: add             x2, NULL, #0x20  ; true
    // 0xcf5428: r0 = Shader._()
    //     0xcf5428: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcf542c: r0 = Null
    //     0xcf542c: mov             x0, NULL
    // 0xcf5430: LeaveFrame
    //     0xcf5430: mov             SP, fp
    //     0xcf5434: ldp             fp, lr, [SP], #0x10
    // 0xcf5438: ret
    //     0xcf5438: ret             
    // 0xcf543c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf543c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5440: b               #0xcf53e4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d00ec, size: 0x5c
    // 0x11d00ec: EnterFrame
    //     0x11d00ec: stp             fp, lr, [SP, #-0x10]!
    //     0x11d00f0: mov             fp, SP
    // 0x11d00f4: AllocStack(0x8)
    //     0x11d00f4: sub             SP, SP, #8
    // 0x11d00f8: CheckStackOverflow
    //     0x11d00f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d00fc: cmp             SP, x16
    //     0x11d0100: b.ls            #0x11d0140
    // 0x11d0104: LoadField: r2 = r1->field_13
    //     0x11d0104: ldur            w2, [x1, #0x13]
    // 0x11d0108: DecompressPointer r2
    //     0x11d0108: add             x2, x2, HEAP, lsl #32
    // 0x11d010c: stur            x2, [fp, #-8]
    // 0x11d0110: LoadField: r0 = r1->field_f
    //     0x11d0110: ldur            w0, [x1, #0xf]
    // 0x11d0114: DecompressPointer r0
    //     0x11d0114: add             x0, x0, HEAP, lsl #32
    // 0x11d0118: mov             x1, x0
    // 0x11d011c: r0 = RenderAnnotatedRegion()
    //     0x11d011c: bl              #0x11d022c  ; AllocateRenderAnnotatedRegionStub -> RenderAnnotatedRegion<X0> (size=0x68)
    // 0x11d0120: mov             x1, x0
    // 0x11d0124: ldur            x2, [fp, #-8]
    // 0x11d0128: stur            x0, [fp, #-8]
    // 0x11d012c: r0 = RenderAnnotatedRegion()
    //     0x11d012c: bl              #0x11d0148  ; [package:flutter/src/rendering/proxy_box.dart] RenderAnnotatedRegion::RenderAnnotatedRegion
    // 0x11d0130: ldur            x0, [fp, #-8]
    // 0x11d0134: LeaveFrame
    //     0x11d0134: mov             SP, fp
    //     0x11d0138: ldp             fp, lr, [SP], #0x10
    // 0x11d013c: ret
    //     0x11d013c: ret             
    // 0x11d0140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0140: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0144: b               #0x11d0104
  }
}
