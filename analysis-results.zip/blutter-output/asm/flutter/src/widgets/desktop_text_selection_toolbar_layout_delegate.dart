// lib: , url: package:flutter/src/widgets/desktop_text_selection_toolbar_layout_delegate.dart

// class id: 1049129, size: 0x8
class :: {
}

// class id: 3130, size: 0x10, field offset: 0xc
class DesktopTextSelectionToolbarLayoutDelegate extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0x1142180, size: 0x9c
    // 0x1142180: EnterFrame
    //     0x1142180: stp             fp, lr, [SP, #-0x10]!
    //     0x1142184: mov             fp, SP
    // 0x1142188: AllocStack(0x20)
    //     0x1142188: sub             SP, SP, #0x20
    // 0x114218c: SetupParameters(DesktopTextSelectionToolbarLayoutDelegate this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x114218c: mov             x4, x1
    //     0x1142190: mov             x3, x2
    //     0x1142194: stur            x1, [fp, #-8]
    //     0x1142198: stur            x2, [fp, #-0x10]
    // 0x114219c: CheckStackOverflow
    //     0x114219c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11421a0: cmp             SP, x16
    //     0x11421a4: b.ls            #0x1142214
    // 0x11421a8: mov             x0, x3
    // 0x11421ac: r2 = Null
    //     0x11421ac: mov             x2, NULL
    // 0x11421b0: r1 = Null
    //     0x11421b0: mov             x1, NULL
    // 0x11421b4: r4 = 60
    //     0x11421b4: mov             x4, #0x3c
    // 0x11421b8: branchIfSmi(r0, 0x11421c4)
    //     0x11421b8: tbz             w0, #0, #0x11421c4
    // 0x11421bc: r4 = LoadClassIdInstr(r0)
    //     0x11421bc: ldur            x4, [x0, #-1]
    //     0x11421c0: ubfx            x4, x4, #0xc, #0x14
    // 0x11421c4: cmp             x4, #0xc3a
    // 0x11421c8: b.eq            #0x11421e0
    // 0x11421cc: r8 = DesktopTextSelectionToolbarLayoutDelegate
    //     0x11421cc: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa19e8] Type: DesktopTextSelectionToolbarLayoutDelegate
    //     0x11421d0: ldr             x8, [x8, #0x9e8]
    // 0x11421d4: r3 = Null
    //     0x11421d4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa19f0] Null
    //     0x11421d8: ldr             x3, [x3, #0x9f0]
    // 0x11421dc: r0 = DefaultTypeTest()
    //     0x11421dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x11421e0: ldur            x0, [fp, #-8]
    // 0x11421e4: LoadField: r1 = r0->field_b
    //     0x11421e4: ldur            w1, [x0, #0xb]
    // 0x11421e8: DecompressPointer r1
    //     0x11421e8: add             x1, x1, HEAP, lsl #32
    // 0x11421ec: ldur            x0, [fp, #-0x10]
    // 0x11421f0: LoadField: r2 = r0->field_b
    //     0x11421f0: ldur            w2, [x0, #0xb]
    // 0x11421f4: DecompressPointer r2
    //     0x11421f4: add             x2, x2, HEAP, lsl #32
    // 0x11421f8: stp             x2, x1, [SP]
    // 0x11421fc: r0 = ==()
    //     0x11421fc: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x1142200: eor             x1, x0, #0x10
    // 0x1142204: mov             x0, x1
    // 0x1142208: LeaveFrame
    //     0x1142208: mov             SP, fp
    //     0x114220c: ldp             fp, lr, [SP], #0x10
    // 0x1142210: ret
    //     0x1142210: ret             
    // 0x1142214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142218: b               #0x11421a8
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0x12e4894, size: 0x8c
    // 0x12e4894: EnterFrame
    //     0x12e4894: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4898: mov             fp, SP
    // 0x12e489c: AllocStack(0x10)
    //     0x12e489c: sub             SP, SP, #0x10
    // 0x12e48a0: d0 = 0.000000
    //     0x12e48a0: eor             v0.16b, v0.16b, v0.16b
    // 0x12e48a4: LoadField: r0 = r1->field_b
    //     0x12e48a4: ldur            w0, [x1, #0xb]
    // 0x12e48a8: DecompressPointer r0
    //     0x12e48a8: add             x0, x0, HEAP, lsl #32
    // 0x12e48ac: LoadField: d1 = r0->field_7
    //     0x12e48ac: ldur            d1, [x0, #7]
    // 0x12e48b0: LoadField: d2 = r3->field_7
    //     0x12e48b0: ldur            d2, [x3, #7]
    // 0x12e48b4: fadd            d3, d1, d2
    // 0x12e48b8: LoadField: d2 = r2->field_7
    //     0x12e48b8: ldur            d2, [x2, #7]
    // 0x12e48bc: fsub            d4, d3, d2
    // 0x12e48c0: LoadField: d2 = r0->field_f
    //     0x12e48c0: ldur            d2, [x0, #0xf]
    // 0x12e48c4: LoadField: d3 = r3->field_f
    //     0x12e48c4: ldur            d3, [x3, #0xf]
    // 0x12e48c8: fadd            d5, d2, d3
    // 0x12e48cc: LoadField: d3 = r2->field_f
    //     0x12e48cc: ldur            d3, [x2, #0xf]
    // 0x12e48d0: fsub            d6, d5, d3
    // 0x12e48d4: fcmp            d4, d0
    // 0x12e48d8: b.le            #0x12e48e4
    // 0x12e48dc: fsub            d3, d1, d4
    // 0x12e48e0: mov             v1.16b, v3.16b
    // 0x12e48e4: stur            d1, [fp, #-0x10]
    // 0x12e48e8: fcmp            d6, d0
    // 0x12e48ec: b.le            #0x12e48f8
    // 0x12e48f0: fsub            d0, d2, d6
    // 0x12e48f4: b               #0x12e48fc
    // 0x12e48f8: mov             v0.16b, v2.16b
    // 0x12e48fc: stur            d0, [fp, #-8]
    // 0x12e4900: r0 = Offset()
    //     0x12e4900: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12e4904: ldur            d0, [fp, #-0x10]
    // 0x12e4908: StoreField: r0->field_7 = d0
    //     0x12e4908: stur            d0, [x0, #7]
    // 0x12e490c: ldur            d0, [fp, #-8]
    // 0x12e4910: StoreField: r0->field_f = d0
    //     0x12e4910: stur            d0, [x0, #0xf]
    // 0x12e4914: LeaveFrame
    //     0x12e4914: mov             SP, fp
    //     0x12e4918: ldp             fp, lr, [SP], #0x10
    // 0x12e491c: ret
    //     0x12e491c: ret             
  }
}
