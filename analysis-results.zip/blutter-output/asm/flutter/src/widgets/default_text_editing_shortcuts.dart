// lib: , url: package:flutter/src/widgets/default_text_editing_shortcuts.dart

// class id: 1049128, size: 0x8
class :: {

  static _ intentForMacOSSelector(/* No info */) {
    // ** addr: 0x87a24c, size: 0x34
    // 0x87a24c: EnterFrame
    //     0x87a24c: stp             fp, lr, [SP, #-0x10]!
    //     0x87a250: mov             fp, SP
    // 0x87a254: mov             x2, x1
    // 0x87a258: CheckStackOverflow
    //     0x87a258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87a25c: cmp             SP, x16
    //     0x87a260: b.ls            #0x87a278
    // 0x87a264: r1 = _ConstMap len:42
    //     0x87a264: ldr             x1, [PP, #0x47c0]  ; [pp+0x47c0] Map<String, Intent>(42)
    // 0x87a268: r0 = []()
    //     0x87a268: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x87a26c: LeaveFrame
    //     0x87a26c: mov             SP, fp
    //     0x87a270: ldp             fp, lr, [SP], #0x10
    // 0x87a274: ret
    //     0x87a274: ret             
    // 0x87a278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87a278: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87a27c: b               #0x87a264
  }
}

// class id: 6119, size: 0x10, field offset: 0xc
//   const constructor, 
class DefaultTextEditingShortcuts extends StatelessWidget {

  static late final Map<ShortcutActivator, Intent> _androidShortcuts; // offset: 0xba0
  static late final Map<ShortcutActivator, Intent> _commonShortcuts; // offset: 0xb98
  static late final Map<ShortcutActivator, Intent> _clipboardShortcuts; // offset: 0xb9c

  _ build(/* No info */) {
    // ** addr: 0xfbfbf4, size: 0x84
    // 0xfbfbf4: EnterFrame
    //     0xfbfbf4: stp             fp, lr, [SP, #-0x10]!
    //     0xfbfbf8: mov             fp, SP
    // 0xfbfbfc: AllocStack(0x10)
    //     0xfbfbfc: sub             SP, SP, #0x10
    // 0xfbfc00: CheckStackOverflow
    //     0xfbfc00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbfc04: cmp             SP, x16
    //     0xfbfc08: b.ls            #0xfbfc70
    // 0xfbfc0c: LoadField: r0 = r1->field_b
    //     0xfbfc0c: ldur            w0, [x1, #0xb]
    // 0xfbfc10: DecompressPointer r0
    //     0xfbfc10: add             x0, x0, HEAP, lsl #32
    // 0xfbfc14: stur            x0, [fp, #-8]
    // 0xfbfc18: r0 = LoadStaticField(0xba0)
    //     0xfbfc18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbfc1c: ldr             x0, [x0, #0x1740]
    // 0xfbfc20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbfc24: cmp             w0, w16
    // 0xfbfc28: b.ne            #0xfbfc38
    // 0xfbfc2c: r2 = _androidShortcuts
    //     0xfbfc2c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9a0] Field <DefaultTextEditingShortcuts._androidShortcuts@528297651>: static late final (offset: 0xba0)
    //     0xfbfc30: ldr             x2, [x2, #0x9a0]
    // 0xfbfc34: r0 = InitLateFinalStaticField()
    //     0xfbfc34: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbfc38: stur            x0, [fp, #-0x10]
    // 0xfbfc3c: r0 = Shortcuts()
    //     0xfbfc3c: bl              #0xd188b8  ; AllocateShortcutsStub -> Shortcuts (size=0x20)
    // 0xfbfc40: ldur            x1, [fp, #-8]
    // 0xfbfc44: StoreField: r0->field_13 = r1
    //     0xfbfc44: stur            w1, [x0, #0x13]
    // 0xfbfc48: r1 = "<Default Text Editing Shortcuts>"
    //     0xfbfc48: add             x1, PP, #0xab, lsl #12  ; [pp+0xab9a8] "<Default Text Editing Shortcuts>"
    //     0xfbfc4c: ldr             x1, [x1, #0x9a8]
    // 0xfbfc50: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbfc50: stur            w1, [x0, #0x17]
    // 0xfbfc54: r1 = true
    //     0xfbfc54: add             x1, NULL, #0x20  ; true
    // 0xfbfc58: StoreField: r0->field_1b = r1
    //     0xfbfc58: stur            w1, [x0, #0x1b]
    // 0xfbfc5c: ldur            x1, [fp, #-0x10]
    // 0xfbfc60: StoreField: r0->field_f = r1
    //     0xfbfc60: stur            w1, [x0, #0xf]
    // 0xfbfc64: LeaveFrame
    //     0xfbfc64: mov             SP, fp
    //     0xfbfc68: ldp             fp, lr, [SP], #0x10
    // 0xfbfc6c: ret
    //     0xfbfc6c: ret             
    // 0xfbfc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbfc70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbfc74: b               #0xfbfc0c
  }
  static Map<ShortcutActivator, Intent> _androidShortcuts() {
    // ** addr: 0xfbfc78, size: 0x150
    // 0xfbfc78: EnterFrame
    //     0xfbfc78: stp             fp, lr, [SP, #-0x10]!
    //     0xfbfc7c: mov             fp, SP
    // 0xfbfc80: AllocStack(0x8)
    //     0xfbfc80: sub             SP, SP, #8
    // 0xfbfc84: CheckStackOverflow
    //     0xfbfc84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbfc88: cmp             SP, x16
    //     0xfbfc8c: b.ls            #0xfbfdc0
    // 0xfbfc90: r0 = LoadStaticField(0xb98)
    //     0xfbfc90: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbfc94: ldr             x0, [x0, #0x1730]
    // 0xfbfc98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbfc9c: cmp             w0, w16
    // 0xfbfca0: b.ne            #0xfbfcb0
    // 0xfbfca4: r2 = _commonShortcuts
    //     0xfbfca4: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9b0] Field <DefaultTextEditingShortcuts._commonShortcuts@528297651>: static late final (offset: 0xb98)
    //     0xfbfca8: ldr             x2, [x2, #0x9b0]
    // 0xfbfcac: r0 = InitLateFinalStaticField()
    //     0xfbfcac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbfcb0: mov             x2, x0
    // 0xfbfcb4: r1 = <ShortcutActivator, Intent>
    //     0xfbfcb4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab9b8] TypeArguments: <ShortcutActivator, Intent>
    //     0xfbfcb8: ldr             x1, [x1, #0x9b8]
    // 0xfbfcbc: r0 = LinkedHashMap.of()
    //     0xfbfcbc: bl              #0x833524  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0xfbfcc0: stur            x0, [fp, #-8]
    // 0xfbfcc4: r0 = LoadStaticField(0xb9c)
    //     0xfbfcc4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbfcc8: ldr             x0, [x0, #0x1738]
    // 0xfbfccc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbfcd0: cmp             w0, w16
    // 0xfbfcd4: b.ne            #0xfbfce4
    // 0xfbfcd8: r2 = _clipboardShortcuts
    //     0xfbfcd8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9c0] Field <DefaultTextEditingShortcuts._clipboardShortcuts@528297651>: static late final (offset: 0xb9c)
    //     0xfbfcdc: ldr             x2, [x2, #0x9c0]
    // 0xfbfce0: r0 = InitLateFinalStaticField()
    //     0xfbfce0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbfce4: ldur            x1, [fp, #-8]
    // 0xfbfce8: mov             x2, x0
    // 0xfbfcec: r0 = addAll()
    //     0xfbfcec: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0xfbfcf0: ldur            x1, [fp, #-8]
    // 0xfbfcf4: r2 = Instance_SingleActivator
    //     0xfbfcf4: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9c8] Obj!SingleActivator@12b44d1
    //     0xfbfcf8: ldr             x2, [x2, #0x9c8]
    // 0xfbfcfc: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfbfcfc: add             x3, PP, #0xab, lsl #12  ; [pp+0xab9d0] Obj!ExtendSelectionToLineBreakIntent@12b24f1
    //     0xfbfd00: ldr             x3, [x3, #0x9d0]
    // 0xfbfd04: r0 = []=()
    //     0xfbfd04: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd08: ldur            x1, [fp, #-8]
    // 0xfbfd0c: r2 = Instance_SingleActivator
    //     0xfbfd0c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9d8] Obj!SingleActivator@12b44a1
    //     0xfbfd10: ldr             x2, [x2, #0x9d8]
    // 0xfbfd14: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfbfd14: add             x3, PP, #0xab, lsl #12  ; [pp+0xab9e0] Obj!ExtendSelectionToLineBreakIntent@12b24d1
    //     0xfbfd18: ldr             x3, [x3, #0x9e0]
    // 0xfbfd1c: r0 = []=()
    //     0xfbfd1c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd20: ldur            x1, [fp, #-8]
    // 0xfbfd24: r2 = Instance_SingleActivator
    //     0xfbfd24: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9e8] Obj!SingleActivator@12b4471
    //     0xfbfd28: ldr             x2, [x2, #0x9e8]
    // 0xfbfd2c: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfbfd2c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab9f0] Obj!ExtendSelectionToLineBreakIntent@12b24b1
    //     0xfbfd30: ldr             x3, [x3, #0x9f0]
    // 0xfbfd34: r0 = []=()
    //     0xfbfd34: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd38: ldur            x1, [fp, #-8]
    // 0xfbfd3c: r2 = Instance_SingleActivator
    //     0xfbfd3c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab9f8] Obj!SingleActivator@12b4441
    //     0xfbfd40: ldr             x2, [x2, #0x9f8]
    // 0xfbfd44: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfbfd44: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba00] Obj!ExtendSelectionToLineBreakIntent@12b2491
    //     0xfbfd48: ldr             x3, [x3, #0xa00]
    // 0xfbfd4c: r0 = []=()
    //     0xfbfd4c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd50: ldur            x1, [fp, #-8]
    // 0xfbfd54: r2 = Instance_SingleActivator
    //     0xfbfd54: add             x2, PP, #0xab, lsl #12  ; [pp+0xaba08] Obj!SingleActivator@12b4411
    //     0xfbfd58: ldr             x2, [x2, #0xa08]
    // 0xfbfd5c: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfbfd5c: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba10] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2271
    //     0xfbfd60: ldr             x3, [x3, #0xa10]
    // 0xfbfd64: r0 = []=()
    //     0xfbfd64: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd68: ldur            x1, [fp, #-8]
    // 0xfbfd6c: r2 = Instance_SingleActivator
    //     0xfbfd6c: add             x2, PP, #0xab, lsl #12  ; [pp+0xaba18] Obj!SingleActivator@12b43e1
    //     0xfbfd70: ldr             x2, [x2, #0xa18]
    // 0xfbfd74: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfbfd74: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba20] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2251
    //     0xfbfd78: ldr             x3, [x3, #0xa20]
    // 0xfbfd7c: r0 = []=()
    //     0xfbfd7c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd80: ldur            x1, [fp, #-8]
    // 0xfbfd84: r2 = Instance_SingleActivator
    //     0xfbfd84: add             x2, PP, #0xab, lsl #12  ; [pp+0xaba28] Obj!SingleActivator@12b43b1
    //     0xfbfd88: ldr             x2, [x2, #0xa28]
    // 0xfbfd8c: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfbfd8c: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba30] Obj!ExtendSelectionToDocumentBoundaryIntent@12b22b1
    //     0xfbfd90: ldr             x3, [x3, #0xa30]
    // 0xfbfd94: r0 = []=()
    //     0xfbfd94: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfd98: ldur            x1, [fp, #-8]
    // 0xfbfd9c: r2 = Instance_SingleActivator
    //     0xfbfd9c: add             x2, PP, #0xab, lsl #12  ; [pp+0xaba38] Obj!SingleActivator@12b4381
    //     0xfbfda0: ldr             x2, [x2, #0xa38]
    // 0xfbfda4: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfbfda4: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba40] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2291
    //     0xfbfda8: ldr             x3, [x3, #0xa40]
    // 0xfbfdac: r0 = []=()
    //     0xfbfdac: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfbfdb0: ldur            x0, [fp, #-8]
    // 0xfbfdb4: LeaveFrame
    //     0xfbfdb4: mov             SP, fp
    //     0xfbfdb8: ldp             fp, lr, [SP], #0x10
    // 0xfbfdbc: ret
    //     0xfbfdbc: ret             
    // 0xfbfdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbfdc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbfdc4: b               #0xfbfc90
  }
  static Map<ShortcutActivator, Intent> _clipboardShortcuts() {
    // ** addr: 0xfbfdc8, size: 0x150
    // 0xfbfdc8: EnterFrame
    //     0xfbfdc8: stp             fp, lr, [SP, #-0x10]!
    //     0xfbfdcc: mov             fp, SP
    // 0xfbfdd0: AllocStack(0x10)
    //     0xfbfdd0: sub             SP, SP, #0x10
    // 0xfbfdd4: CheckStackOverflow
    //     0xfbfdd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbfdd8: cmp             SP, x16
    //     0xfbfddc: b.ls            #0xfbff10
    // 0xfbfde0: r1 = Null
    //     0xfbfde0: mov             x1, NULL
    // 0xfbfde4: r2 = 44
    //     0xfbfde4: mov             x2, #0x2c
    // 0xfbfde8: r0 = AllocateArray()
    //     0xfbfde8: bl              #0x13df928  ; AllocateArrayStub
    // 0xfbfdec: r16 = Instance_SingleActivator
    //     0xfbfdec: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba48] Obj!SingleActivator@12b4681
    //     0xfbfdf0: ldr             x16, [x16, #0xa48]
    // 0xfbfdf4: StoreField: r0->field_f = r16
    //     0xfbfdf4: stur            w16, [x0, #0xf]
    // 0xfbfdf8: r16 = Instance_CopySelectionTextIntent
    //     0xfbfdf8: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba50] Obj!CopySelectionTextIntent@12b2211
    //     0xfbfdfc: ldr             x16, [x16, #0xa50]
    // 0xfbfe00: StoreField: r0->field_13 = r16
    //     0xfbfe00: stur            w16, [x0, #0x13]
    // 0xfbfe04: r16 = Instance_SingleActivator
    //     0xfbfe04: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba58] Obj!SingleActivator@12b4651
    //     0xfbfe08: ldr             x16, [x16, #0xa58]
    // 0xfbfe0c: ArrayStore: r0[0] = r16  ; List_4
    //     0xfbfe0c: stur            w16, [x0, #0x17]
    // 0xfbfe10: r16 = Instance_CopySelectionTextIntent
    //     0xfbfe10: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba60] Obj!CopySelectionTextIntent@12b2201
    //     0xfbfe14: ldr             x16, [x16, #0xa60]
    // 0xfbfe18: StoreField: r0->field_1b = r16
    //     0xfbfe18: stur            w16, [x0, #0x1b]
    // 0xfbfe1c: r16 = Instance_SingleActivator
    //     0xfbfe1c: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba68] Obj!SingleActivator@12b4621
    //     0xfbfe20: ldr             x16, [x16, #0xa68]
    // 0xfbfe24: StoreField: r0->field_1f = r16
    //     0xfbfe24: stur            w16, [x0, #0x1f]
    // 0xfbfe28: r16 = Instance_PasteTextIntent
    //     0xfbfe28: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba70] Obj!PasteTextIntent@12b21f1
    //     0xfbfe2c: ldr             x16, [x16, #0xa70]
    // 0xfbfe30: StoreField: r0->field_23 = r16
    //     0xfbfe30: stur            w16, [x0, #0x23]
    // 0xfbfe34: r16 = Instance_SingleActivator
    //     0xfbfe34: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba78] Obj!SingleActivator@12b45f1
    //     0xfbfe38: ldr             x16, [x16, #0xa78]
    // 0xfbfe3c: StoreField: r0->field_27 = r16
    //     0xfbfe3c: stur            w16, [x0, #0x27]
    // 0xfbfe40: r16 = Instance_CopySelectionTextIntent
    //     0xfbfe40: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba50] Obj!CopySelectionTextIntent@12b2211
    //     0xfbfe44: ldr             x16, [x16, #0xa50]
    // 0xfbfe48: StoreField: r0->field_2b = r16
    //     0xfbfe48: stur            w16, [x0, #0x2b]
    // 0xfbfe4c: r16 = Instance_SingleActivator
    //     0xfbfe4c: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba80] Obj!SingleActivator@12b45c1
    //     0xfbfe50: ldr             x16, [x16, #0xa80]
    // 0xfbfe54: StoreField: r0->field_2f = r16
    //     0xfbfe54: stur            w16, [x0, #0x2f]
    // 0xfbfe58: r16 = Instance_CopySelectionTextIntent
    //     0xfbfe58: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba60] Obj!CopySelectionTextIntent@12b2201
    //     0xfbfe5c: ldr             x16, [x16, #0xa60]
    // 0xfbfe60: StoreField: r0->field_33 = r16
    //     0xfbfe60: stur            w16, [x0, #0x33]
    // 0xfbfe64: r16 = Instance_SingleActivator
    //     0xfbfe64: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba88] Obj!SingleActivator@12b4591
    //     0xfbfe68: ldr             x16, [x16, #0xa88]
    // 0xfbfe6c: StoreField: r0->field_37 = r16
    //     0xfbfe6c: stur            w16, [x0, #0x37]
    // 0xfbfe70: r16 = Instance_PasteTextIntent
    //     0xfbfe70: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba70] Obj!PasteTextIntent@12b21f1
    //     0xfbfe74: ldr             x16, [x16, #0xa70]
    // 0xfbfe78: StoreField: r0->field_3b = r16
    //     0xfbfe78: stur            w16, [x0, #0x3b]
    // 0xfbfe7c: r16 = Instance_SingleActivator
    //     0xfbfe7c: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba90] Obj!SingleActivator@12b4561
    //     0xfbfe80: ldr             x16, [x16, #0xa90]
    // 0xfbfe84: StoreField: r0->field_3f = r16
    //     0xfbfe84: stur            w16, [x0, #0x3f]
    // 0xfbfe88: r16 = Instance_SelectAllTextIntent
    //     0xfbfe88: add             x16, PP, #0xab, lsl #12  ; [pp+0xaba98] Obj!SelectAllTextIntent@12b2221
    //     0xfbfe8c: ldr             x16, [x16, #0xa98]
    // 0xfbfe90: StoreField: r0->field_43 = r16
    //     0xfbfe90: stur            w16, [x0, #0x43]
    // 0xfbfe94: r16 = Instance_SingleActivator
    //     0xfbfe94: add             x16, PP, #0xab, lsl #12  ; [pp+0xabaa0] Obj!SingleActivator@12b4531
    //     0xfbfe98: ldr             x16, [x16, #0xaa0]
    // 0xfbfe9c: StoreField: r0->field_47 = r16
    //     0xfbfe9c: stur            w16, [x0, #0x47]
    // 0xfbfea0: r16 = Instance_UndoTextIntent
    //     0xfbfea0: add             x16, PP, #0xab, lsl #12  ; [pp+0xabaa8] Obj!UndoTextIntent@12b21d1
    //     0xfbfea4: ldr             x16, [x16, #0xaa8]
    // 0xfbfea8: StoreField: r0->field_4b = r16
    //     0xfbfea8: stur            w16, [x0, #0x4b]
    // 0xfbfeac: r16 = Instance_SingleActivator
    //     0xfbfeac: add             x16, PP, #0xab, lsl #12  ; [pp+0xabab0] Obj!SingleActivator@12b4501
    //     0xfbfeb0: ldr             x16, [x16, #0xab0]
    // 0xfbfeb4: StoreField: r0->field_4f = r16
    //     0xfbfeb4: stur            w16, [x0, #0x4f]
    // 0xfbfeb8: r16 = Instance_RedoTextIntent
    //     0xfbfeb8: add             x16, PP, #0xab, lsl #12  ; [pp+0xabab8] Obj!RedoTextIntent@12b21e1
    //     0xfbfebc: ldr             x16, [x16, #0xab8]
    // 0xfbfec0: StoreField: r0->field_53 = r16
    //     0xfbfec0: stur            w16, [x0, #0x53]
    // 0xfbfec4: r16 = Instance_SingleActivator
    //     0xfbfec4: add             x16, PP, #0xab, lsl #12  ; [pp+0xabac0] Obj!SingleActivator@12b4321
    //     0xfbfec8: ldr             x16, [x16, #0xac0]
    // 0xfbfecc: StoreField: r0->field_57 = r16
    //     0xfbfecc: stur            w16, [x0, #0x57]
    // 0xfbfed0: r16 = Instance_DoNothingAndStopPropagationTextIntent
    //     0xfbfed0: add             x16, PP, #0xab, lsl #12  ; [pp+0xabac8] Obj!DoNothingAndStopPropagationTextIntent@12b2771
    //     0xfbfed4: ldr             x16, [x16, #0xac8]
    // 0xfbfed8: StoreField: r0->field_5b = r16
    //     0xfbfed8: stur            w16, [x0, #0x5b]
    // 0xfbfedc: r16 = Instance_SingleActivator
    //     0xfbfedc: add             x16, PP, #0xab, lsl #12  ; [pp+0xabad0] Obj!SingleActivator@12b4021
    //     0xfbfee0: ldr             x16, [x16, #0xad0]
    // 0xfbfee4: StoreField: r0->field_5f = r16
    //     0xfbfee4: stur            w16, [x0, #0x5f]
    // 0xfbfee8: r16 = Instance_DoNothingAndStopPropagationTextIntent
    //     0xfbfee8: add             x16, PP, #0xab, lsl #12  ; [pp+0xabac8] Obj!DoNothingAndStopPropagationTextIntent@12b2771
    //     0xfbfeec: ldr             x16, [x16, #0xac8]
    // 0xfbfef0: StoreField: r0->field_63 = r16
    //     0xfbfef0: stur            w16, [x0, #0x63]
    // 0xfbfef4: r16 = <ShortcutActivator, Intent>
    //     0xfbfef4: add             x16, PP, #0xab, lsl #12  ; [pp+0xab9b8] TypeArguments: <ShortcutActivator, Intent>
    //     0xfbfef8: ldr             x16, [x16, #0x9b8]
    // 0xfbfefc: stp             x0, x16, [SP]
    // 0xfbff00: r0 = Map._fromLiteral()
    //     0xfbff00: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfbff04: LeaveFrame
    //     0xfbff04: mov             SP, fp
    //     0xfbff08: ldp             fp, lr, [SP], #0x10
    // 0xfbff0c: ret
    //     0xfbff0c: ret             
    // 0xfbff10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbff10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbff14: b               #0xfbfde0
  }
  static Map<ShortcutActivator, Intent> _commonShortcuts() {
    // ** addr: 0xfbff18, size: 0x5b8
    // 0xfbff18: EnterFrame
    //     0xfbff18: stp             fp, lr, [SP, #-0x10]!
    //     0xfbff1c: mov             fp, SP
    // 0xfbff20: AllocStack(0x38)
    //     0xfbff20: sub             SP, SP, #0x38
    // 0xfbff24: CheckStackOverflow
    //     0xfbff24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbff28: cmp             SP, x16
    //     0xfbff2c: b.ls            #0xfc04c0
    // 0xfbff30: r16 = <ShortcutActivator, Intent>
    //     0xfbff30: add             x16, PP, #0xab, lsl #12  ; [pp+0xab9b8] TypeArguments: <ShortcutActivator, Intent>
    //     0xfbff34: ldr             x16, [x16, #0x9b8]
    // 0xfbff38: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfbff3c: stp             lr, x16, [SP]
    // 0xfbff40: r0 = Map._fromLiteral()
    //     0xfbff40: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfbff44: stur            x0, [fp, #-0x18]
    // 0xfbff48: r2 = 0
    //     0xfbff48: mov             x2, #0
    // 0xfbff4c: r1 = const [true, false]
    //     0xfbff4c: add             x1, PP, #0xab, lsl #12  ; [pp+0xabad8] List<bool>(2)
    //     0xfbff50: ldr             x1, [x1, #0xad8]
    // 0xfbff54: CheckStackOverflow
    //     0xfbff54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbff58: cmp             SP, x16
    //     0xfbff5c: b.ls            #0xfc04c8
    // 0xfbff60: cmp             x2, #2
    // 0xfbff64: b.ge            #0xfc0228
    // 0xfbff68: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0xfbff68: add             x16, x1, x2, lsl #2
    //     0xfbff6c: ldur            w3, [x16, #0xf]
    // 0xfbff70: DecompressPointer r3
    //     0xfbff70: add             x3, x3, HEAP, lsl #32
    // 0xfbff74: stur            x3, [fp, #-0x10]
    // 0xfbff78: add             x4, x2, #1
    // 0xfbff7c: stur            x4, [fp, #-8]
    // 0xfbff80: r0 = SingleActivator()
    //     0xfbff80: bl              #0xfc04d0  ; AllocateSingleActivatorStub -> SingleActivator (size=0x24)
    // 0xfbff84: mov             x3, x0
    // 0xfbff88: r0 = Instance_LogicalKeyboardKey
    //     0xfbff88: add             x0, PP, #0xab, lsl #12  ; [pp+0xabae0] Obj!LogicalKeyboardKey@12acea1
    //     0xfbff8c: ldr             x0, [x0, #0xae0]
    // 0xfbff90: stur            x3, [fp, #-0x20]
    // 0xfbff94: StoreField: r3->field_7 = r0
    //     0xfbff94: stur            w0, [x3, #7]
    // 0xfbff98: r4 = false
    //     0xfbff98: add             x4, NULL, #0x30  ; false
    // 0xfbff9c: StoreField: r3->field_b = r4
    //     0xfbff9c: stur            w4, [x3, #0xb]
    // 0xfbffa0: ldur            x5, [fp, #-0x10]
    // 0xfbffa4: StoreField: r3->field_f = r5
    //     0xfbffa4: stur            w5, [x3, #0xf]
    // 0xfbffa8: StoreField: r3->field_13 = r4
    //     0xfbffa8: stur            w4, [x3, #0x13]
    // 0xfbffac: ArrayStore: r3[0] = r4  ; List_4
    //     0xfbffac: stur            w4, [x3, #0x17]
    // 0xfbffb0: r6 = Instance_LockState
    //     0xfbffb0: add             x6, PP, #0xab, lsl #12  ; [pp+0xabae8] Obj!LockState@12c2581
    //     0xfbffb4: ldr             x6, [x6, #0xae8]
    // 0xfbffb8: StoreField: r3->field_1b = r6
    //     0xfbffb8: stur            w6, [x3, #0x1b]
    // 0xfbffbc: r7 = true
    //     0xfbffbc: add             x7, NULL, #0x20  ; true
    // 0xfbffc0: StoreField: r3->field_1f = r7
    //     0xfbffc0: stur            w7, [x3, #0x1f]
    // 0xfbffc4: r1 = Null
    //     0xfbffc4: mov             x1, NULL
    // 0xfbffc8: r2 = 20
    //     0xfbffc8: mov             x2, #0x14
    // 0xfbffcc: r0 = AllocateArray()
    //     0xfbffcc: bl              #0x13df928  ; AllocateArrayStub
    // 0xfbffd0: mov             x1, x0
    // 0xfbffd4: ldur            x0, [fp, #-0x20]
    // 0xfbffd8: stur            x1, [fp, #-0x28]
    // 0xfbffdc: StoreField: r1->field_f = r0
    //     0xfbffdc: stur            w0, [x1, #0xf]
    // 0xfbffe0: r16 = Instance_DeleteCharacterIntent
    //     0xfbffe0: add             x16, PP, #0xab, lsl #12  ; [pp+0xabaf0] Obj!DeleteCharacterIntent@12b2761
    //     0xfbffe4: ldr             x16, [x16, #0xaf0]
    // 0xfbffe8: StoreField: r1->field_13 = r16
    //     0xfbffe8: stur            w16, [x1, #0x13]
    // 0xfbffec: r0 = SingleActivator()
    //     0xfbffec: bl              #0xfc04d0  ; AllocateSingleActivatorStub -> SingleActivator (size=0x24)
    // 0xfbfff0: r2 = Instance_LogicalKeyboardKey
    //     0xfbfff0: add             x2, PP, #0xab, lsl #12  ; [pp+0xabae0] Obj!LogicalKeyboardKey@12acea1
    //     0xfbfff4: ldr             x2, [x2, #0xae0]
    // 0xfbfff8: StoreField: r0->field_7 = r2
    //     0xfbfff8: stur            w2, [x0, #7]
    // 0xfbfffc: r3 = true
    //     0xfbfffc: add             x3, NULL, #0x20  ; true
    // 0xfc0000: StoreField: r0->field_b = r3
    //     0xfc0000: stur            w3, [x0, #0xb]
    // 0xfc0004: ldur            x4, [fp, #-0x10]
    // 0xfc0008: StoreField: r0->field_f = r4
    //     0xfc0008: stur            w4, [x0, #0xf]
    // 0xfc000c: r5 = false
    //     0xfc000c: add             x5, NULL, #0x30  ; false
    // 0xfc0010: StoreField: r0->field_13 = r5
    //     0xfc0010: stur            w5, [x0, #0x13]
    // 0xfc0014: ArrayStore: r0[0] = r5  ; List_4
    //     0xfc0014: stur            w5, [x0, #0x17]
    // 0xfc0018: r6 = Instance_LockState
    //     0xfc0018: add             x6, PP, #0xab, lsl #12  ; [pp+0xabae8] Obj!LockState@12c2581
    //     0xfc001c: ldr             x6, [x6, #0xae8]
    // 0xfc0020: StoreField: r0->field_1b = r6
    //     0xfc0020: stur            w6, [x0, #0x1b]
    // 0xfc0024: StoreField: r0->field_1f = r3
    //     0xfc0024: stur            w3, [x0, #0x1f]
    // 0xfc0028: ldur            x1, [fp, #-0x28]
    // 0xfc002c: ArrayStore: r1[2] = r0  ; List_4
    //     0xfc002c: add             x25, x1, #0x17
    //     0xfc0030: str             w0, [x25]
    //     0xfc0034: tbz             w0, #0, #0xfc0050
    //     0xfc0038: ldurb           w16, [x1, #-1]
    //     0xfc003c: ldurb           w17, [x0, #-1]
    //     0xfc0040: and             x16, x17, x16, lsr #2
    //     0xfc0044: tst             x16, HEAP, lsr #32
    //     0xfc0048: b.eq            #0xfc0050
    //     0xfc004c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfc0050: ldur            x1, [fp, #-0x28]
    // 0xfc0054: r16 = Instance_DeleteToNextWordBoundaryIntent
    //     0xfc0054: add             x16, PP, #0xab, lsl #12  ; [pp+0xabaf8] Obj!DeleteToNextWordBoundaryIntent@12b2741
    //     0xfc0058: ldr             x16, [x16, #0xaf8]
    // 0xfc005c: StoreField: r1->field_1b = r16
    //     0xfc005c: stur            w16, [x1, #0x1b]
    // 0xfc0060: r0 = SingleActivator()
    //     0xfc0060: bl              #0xfc04d0  ; AllocateSingleActivatorStub -> SingleActivator (size=0x24)
    // 0xfc0064: r2 = Instance_LogicalKeyboardKey
    //     0xfc0064: add             x2, PP, #0xab, lsl #12  ; [pp+0xabae0] Obj!LogicalKeyboardKey@12acea1
    //     0xfc0068: ldr             x2, [x2, #0xae0]
    // 0xfc006c: StoreField: r0->field_7 = r2
    //     0xfc006c: stur            w2, [x0, #7]
    // 0xfc0070: r3 = false
    //     0xfc0070: add             x3, NULL, #0x30  ; false
    // 0xfc0074: StoreField: r0->field_b = r3
    //     0xfc0074: stur            w3, [x0, #0xb]
    // 0xfc0078: ldur            x4, [fp, #-0x10]
    // 0xfc007c: StoreField: r0->field_f = r4
    //     0xfc007c: stur            w4, [x0, #0xf]
    // 0xfc0080: r5 = true
    //     0xfc0080: add             x5, NULL, #0x20  ; true
    // 0xfc0084: StoreField: r0->field_13 = r5
    //     0xfc0084: stur            w5, [x0, #0x13]
    // 0xfc0088: ArrayStore: r0[0] = r3  ; List_4
    //     0xfc0088: stur            w3, [x0, #0x17]
    // 0xfc008c: r6 = Instance_LockState
    //     0xfc008c: add             x6, PP, #0xab, lsl #12  ; [pp+0xabae8] Obj!LockState@12c2581
    //     0xfc0090: ldr             x6, [x6, #0xae8]
    // 0xfc0094: StoreField: r0->field_1b = r6
    //     0xfc0094: stur            w6, [x0, #0x1b]
    // 0xfc0098: StoreField: r0->field_1f = r5
    //     0xfc0098: stur            w5, [x0, #0x1f]
    // 0xfc009c: ldur            x1, [fp, #-0x28]
    // 0xfc00a0: ArrayStore: r1[4] = r0  ; List_4
    //     0xfc00a0: add             x25, x1, #0x1f
    //     0xfc00a4: str             w0, [x25]
    //     0xfc00a8: tbz             w0, #0, #0xfc00c4
    //     0xfc00ac: ldurb           w16, [x1, #-1]
    //     0xfc00b0: ldurb           w17, [x0, #-1]
    //     0xfc00b4: and             x16, x17, x16, lsr #2
    //     0xfc00b8: tst             x16, HEAP, lsr #32
    //     0xfc00bc: b.eq            #0xfc00c4
    //     0xfc00c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfc00c4: ldur            x1, [fp, #-0x28]
    // 0xfc00c8: r16 = Instance_DeleteToLineBreakIntent
    //     0xfc00c8: add             x16, PP, #0xab, lsl #12  ; [pp+0xabb00] Obj!DeleteToLineBreakIntent@12b2721
    //     0xfc00cc: ldr             x16, [x16, #0xb00]
    // 0xfc00d0: StoreField: r1->field_23 = r16
    //     0xfc00d0: stur            w16, [x1, #0x23]
    // 0xfc00d4: r0 = SingleActivator()
    //     0xfc00d4: bl              #0xfc04d0  ; AllocateSingleActivatorStub -> SingleActivator (size=0x24)
    // 0xfc00d8: r2 = Instance_LogicalKeyboardKey
    //     0xfc00d8: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb08] Obj!LogicalKeyboardKey@12ace61
    //     0xfc00dc: ldr             x2, [x2, #0xb08]
    // 0xfc00e0: StoreField: r0->field_7 = r2
    //     0xfc00e0: stur            w2, [x0, #7]
    // 0xfc00e4: r3 = true
    //     0xfc00e4: add             x3, NULL, #0x20  ; true
    // 0xfc00e8: StoreField: r0->field_b = r3
    //     0xfc00e8: stur            w3, [x0, #0xb]
    // 0xfc00ec: ldur            x4, [fp, #-0x10]
    // 0xfc00f0: StoreField: r0->field_f = r4
    //     0xfc00f0: stur            w4, [x0, #0xf]
    // 0xfc00f4: r5 = false
    //     0xfc00f4: add             x5, NULL, #0x30  ; false
    // 0xfc00f8: StoreField: r0->field_13 = r5
    //     0xfc00f8: stur            w5, [x0, #0x13]
    // 0xfc00fc: ArrayStore: r0[0] = r5  ; List_4
    //     0xfc00fc: stur            w5, [x0, #0x17]
    // 0xfc0100: r6 = Instance_LockState
    //     0xfc0100: add             x6, PP, #0xab, lsl #12  ; [pp+0xabae8] Obj!LockState@12c2581
    //     0xfc0104: ldr             x6, [x6, #0xae8]
    // 0xfc0108: StoreField: r0->field_1b = r6
    //     0xfc0108: stur            w6, [x0, #0x1b]
    // 0xfc010c: StoreField: r0->field_1f = r3
    //     0xfc010c: stur            w3, [x0, #0x1f]
    // 0xfc0110: ldur            x1, [fp, #-0x28]
    // 0xfc0114: ArrayStore: r1[6] = r0  ; List_4
    //     0xfc0114: add             x25, x1, #0x27
    //     0xfc0118: str             w0, [x25]
    //     0xfc011c: tbz             w0, #0, #0xfc0138
    //     0xfc0120: ldurb           w16, [x1, #-1]
    //     0xfc0124: ldurb           w17, [x0, #-1]
    //     0xfc0128: and             x16, x17, x16, lsr #2
    //     0xfc012c: tst             x16, HEAP, lsr #32
    //     0xfc0130: b.eq            #0xfc0138
    //     0xfc0134: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfc0138: ldur            x1, [fp, #-0x28]
    // 0xfc013c: r16 = Instance_DeleteToNextWordBoundaryIntent
    //     0xfc013c: add             x16, PP, #0xab, lsl #12  ; [pp+0xabb10] Obj!DeleteToNextWordBoundaryIntent@12b2731
    //     0xfc0140: ldr             x16, [x16, #0xb10]
    // 0xfc0144: StoreField: r1->field_2b = r16
    //     0xfc0144: stur            w16, [x1, #0x2b]
    // 0xfc0148: r0 = SingleActivator()
    //     0xfc0148: bl              #0xfc04d0  ; AllocateSingleActivatorStub -> SingleActivator (size=0x24)
    // 0xfc014c: r2 = Instance_LogicalKeyboardKey
    //     0xfc014c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb08] Obj!LogicalKeyboardKey@12ace61
    //     0xfc0150: ldr             x2, [x2, #0xb08]
    // 0xfc0154: StoreField: r0->field_7 = r2
    //     0xfc0154: stur            w2, [x0, #7]
    // 0xfc0158: r3 = false
    //     0xfc0158: add             x3, NULL, #0x30  ; false
    // 0xfc015c: StoreField: r0->field_b = r3
    //     0xfc015c: stur            w3, [x0, #0xb]
    // 0xfc0160: ldur            x1, [fp, #-0x10]
    // 0xfc0164: StoreField: r0->field_f = r1
    //     0xfc0164: stur            w1, [x0, #0xf]
    // 0xfc0168: r4 = true
    //     0xfc0168: add             x4, NULL, #0x20  ; true
    // 0xfc016c: StoreField: r0->field_13 = r4
    //     0xfc016c: stur            w4, [x0, #0x13]
    // 0xfc0170: ArrayStore: r0[0] = r3  ; List_4
    //     0xfc0170: stur            w3, [x0, #0x17]
    // 0xfc0174: r5 = Instance_LockState
    //     0xfc0174: add             x5, PP, #0xab, lsl #12  ; [pp+0xabae8] Obj!LockState@12c2581
    //     0xfc0178: ldr             x5, [x5, #0xae8]
    // 0xfc017c: StoreField: r0->field_1b = r5
    //     0xfc017c: stur            w5, [x0, #0x1b]
    // 0xfc0180: StoreField: r0->field_1f = r4
    //     0xfc0180: stur            w4, [x0, #0x1f]
    // 0xfc0184: ldur            x1, [fp, #-0x28]
    // 0xfc0188: ArrayStore: r1[8] = r0  ; List_4
    //     0xfc0188: add             x25, x1, #0x2f
    //     0xfc018c: str             w0, [x25]
    //     0xfc0190: tbz             w0, #0, #0xfc01ac
    //     0xfc0194: ldurb           w16, [x1, #-1]
    //     0xfc0198: ldurb           w17, [x0, #-1]
    //     0xfc019c: and             x16, x17, x16, lsr #2
    //     0xfc01a0: tst             x16, HEAP, lsr #32
    //     0xfc01a4: b.eq            #0xfc01ac
    //     0xfc01a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfc01ac: ldur            x0, [fp, #-0x28]
    // 0xfc01b0: r16 = Instance_DeleteToLineBreakIntent
    //     0xfc01b0: add             x16, PP, #0xab, lsl #12  ; [pp+0xabb18] Obj!DeleteToLineBreakIntent@12b2711
    //     0xfc01b4: ldr             x16, [x16, #0xb18]
    // 0xfc01b8: StoreField: r0->field_33 = r16
    //     0xfc01b8: stur            w16, [x0, #0x33]
    // 0xfc01bc: r16 = <SingleActivator, Intent>
    //     0xfc01bc: add             x16, PP, #0xab, lsl #12  ; [pp+0xabb20] TypeArguments: <SingleActivator, Intent>
    //     0xfc01c0: ldr             x16, [x16, #0xb20]
    // 0xfc01c4: stp             x0, x16, [SP]
    // 0xfc01c8: r0 = Map._fromLiteral()
    //     0xfc01c8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfc01cc: stur            x0, [fp, #-0x10]
    // 0xfc01d0: r1 = LoadClassIdInstr(r0)
    //     0xfc01d0: ldur            x1, [x0, #-1]
    //     0xfc01d4: ubfx            x1, x1, #0xc, #0x14
    // 0xfc01d8: cmp             x1, #0x56
    // 0xfc01dc: b.ne            #0xfc0210
    // 0xfc01e0: ldur            x3, [fp, #-0x18]
    // 0xfc01e4: LoadField: r1 = r3->field_13
    //     0xfc01e4: ldur            w1, [x3, #0x13]
    // 0xfc01e8: r2 = LoadInt32Instr(r1)
    //     0xfc01e8: sbfx            x2, x1, #1, #0x1f
    // 0xfc01ec: asr             x1, x2, #1
    // 0xfc01f0: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xfc01f0: ldur            w2, [x3, #0x17]
    // 0xfc01f4: r4 = LoadInt32Instr(r2)
    //     0xfc01f4: sbfx            x4, x2, #1, #0x1f
    // 0xfc01f8: sub             x2, x1, x4
    // 0xfc01fc: cbnz            x2, #0xfc0210
    // 0xfc0200: mov             x1, x3
    // 0xfc0204: mov             x2, x0
    // 0xfc0208: r0 = _quickCopy()
    //     0xfc0208: bl              #0x84bf9c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase::_quickCopy
    // 0xfc020c: tbz             w0, #4, #0xfc021c
    // 0xfc0210: ldur            x1, [fp, #-0x18]
    // 0xfc0214: ldur            x2, [fp, #-0x10]
    // 0xfc0218: r0 = addAll()
    //     0xfc0218: bl              #0xbb0f18  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::addAll
    // 0xfc021c: ldur            x2, [fp, #-8]
    // 0xfc0220: ldur            x0, [fp, #-0x18]
    // 0xfc0224: b               #0xfbff4c
    // 0xfc0228: ldur            x1, [fp, #-0x18]
    // 0xfc022c: r2 = Instance_SingleActivator
    //     0xfc022c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb28] Obj!SingleActivator@12b4a11
    //     0xfc0230: ldr             x2, [x2, #0xb28]
    // 0xfc0234: r3 = Instance_DeleteCharacterIntent
    //     0xfc0234: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb30] Obj!DeleteCharacterIntent@12b2751
    //     0xfc0238: ldr             x3, [x3, #0xb30]
    // 0xfc023c: r0 = []=()
    //     0xfc023c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0240: ldur            x1, [fp, #-0x18]
    // 0xfc0244: r2 = Instance_SingleActivator
    //     0xfc0244: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb38] Obj!SingleActivator@12b4081
    //     0xfc0248: ldr             x2, [x2, #0xb38]
    // 0xfc024c: r3 = Instance_ExtendSelectionByCharacterIntent
    //     0xfc024c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb40] Obj!ExtendSelectionByCharacterIntent@12b26f1
    //     0xfc0250: ldr             x3, [x3, #0xb40]
    // 0xfc0254: r0 = []=()
    //     0xfc0254: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0258: ldur            x1, [fp, #-0x18]
    // 0xfc025c: r2 = Instance_SingleActivator
    //     0xfc025c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb48] Obj!SingleActivator@12b4051
    //     0xfc0260: ldr             x2, [x2, #0xb48]
    // 0xfc0264: r3 = Instance_ExtendSelectionByCharacterIntent
    //     0xfc0264: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb50] Obj!ExtendSelectionByCharacterIntent@12b26d1
    //     0xfc0268: ldr             x3, [x3, #0xb50]
    // 0xfc026c: r0 = []=()
    //     0xfc026c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0270: ldur            x1, [fp, #-0x18]
    // 0xfc0274: r2 = Instance_SingleActivator
    //     0xfc0274: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb58] Obj!SingleActivator@12b40e1
    //     0xfc0278: ldr             x2, [x2, #0xb58]
    // 0xfc027c: r3 = Instance_ExtendSelectionVerticallyToAdjacentLineIntent
    //     0xfc027c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb60] Obj!ExtendSelectionVerticallyToAdjacentLineIntent@12b2431
    //     0xfc0280: ldr             x3, [x3, #0xb60]
    // 0xfc0284: r0 = []=()
    //     0xfc0284: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0288: ldur            x1, [fp, #-0x18]
    // 0xfc028c: r2 = Instance_SingleActivator
    //     0xfc028c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb68] Obj!SingleActivator@12b40b1
    //     0xfc0290: ldr             x2, [x2, #0xb68]
    // 0xfc0294: r3 = Instance_ExtendSelectionVerticallyToAdjacentLineIntent
    //     0xfc0294: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb70] Obj!ExtendSelectionVerticallyToAdjacentLineIntent@12b2411
    //     0xfc0298: ldr             x3, [x3, #0xb70]
    // 0xfc029c: r0 = []=()
    //     0xfc029c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc02a0: ldur            x1, [fp, #-0x18]
    // 0xfc02a4: r2 = Instance_SingleActivator
    //     0xfc02a4: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb78] Obj!SingleActivator@12b49e1
    //     0xfc02a8: ldr             x2, [x2, #0xb78]
    // 0xfc02ac: r3 = Instance_ExtendSelectionByCharacterIntent
    //     0xfc02ac: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb80] Obj!ExtendSelectionByCharacterIntent@12b26b1
    //     0xfc02b0: ldr             x3, [x3, #0xb80]
    // 0xfc02b4: r0 = []=()
    //     0xfc02b4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc02b8: ldur            x1, [fp, #-0x18]
    // 0xfc02bc: r2 = Instance_SingleActivator
    //     0xfc02bc: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb88] Obj!SingleActivator@12b49b1
    //     0xfc02c0: ldr             x2, [x2, #0xb88]
    // 0xfc02c4: r3 = Instance_ExtendSelectionByCharacterIntent
    //     0xfc02c4: add             x3, PP, #0xab, lsl #12  ; [pp+0xabb90] Obj!ExtendSelectionByCharacterIntent@12b2691
    //     0xfc02c8: ldr             x3, [x3, #0xb90]
    // 0xfc02cc: r0 = []=()
    //     0xfc02cc: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc02d0: ldur            x1, [fp, #-0x18]
    // 0xfc02d4: r2 = Instance_SingleActivator
    //     0xfc02d4: add             x2, PP, #0xab, lsl #12  ; [pp+0xabb98] Obj!SingleActivator@12b4981
    //     0xfc02d8: ldr             x2, [x2, #0xb98]
    // 0xfc02dc: r3 = Instance_ExtendSelectionVerticallyToAdjacentLineIntent
    //     0xfc02dc: add             x3, PP, #0xab, lsl #12  ; [pp+0xabba0] Obj!ExtendSelectionVerticallyToAdjacentLineIntent@12b23f1
    //     0xfc02e0: ldr             x3, [x3, #0xba0]
    // 0xfc02e4: r0 = []=()
    //     0xfc02e4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc02e8: ldur            x1, [fp, #-0x18]
    // 0xfc02ec: r2 = Instance_SingleActivator
    //     0xfc02ec: add             x2, PP, #0xab, lsl #12  ; [pp+0xabba8] Obj!SingleActivator@12b4951
    //     0xfc02f0: ldr             x2, [x2, #0xba8]
    // 0xfc02f4: r3 = Instance_ExtendSelectionVerticallyToAdjacentLineIntent
    //     0xfc02f4: add             x3, PP, #0xab, lsl #12  ; [pp+0xabbb0] Obj!ExtendSelectionVerticallyToAdjacentLineIntent@12b23d1
    //     0xfc02f8: ldr             x3, [x3, #0xbb0]
    // 0xfc02fc: r0 = []=()
    //     0xfc02fc: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0300: ldur            x1, [fp, #-0x18]
    // 0xfc0304: r2 = Instance_SingleActivator
    //     0xfc0304: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbb8] Obj!SingleActivator@12b4921
    //     0xfc0308: ldr             x2, [x2, #0xbb8]
    // 0xfc030c: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfc030c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabbc0] Obj!ExtendSelectionToLineBreakIntent@12b2471
    //     0xfc0310: ldr             x3, [x3, #0xbc0]
    // 0xfc0314: r0 = []=()
    //     0xfc0314: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0318: ldur            x1, [fp, #-0x18]
    // 0xfc031c: r2 = Instance_SingleActivator
    //     0xfc031c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbc8] Obj!SingleActivator@12b48f1
    //     0xfc0320: ldr             x2, [x2, #0xbc8]
    // 0xfc0324: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfc0324: add             x3, PP, #0xab, lsl #12  ; [pp+0xabbd0] Obj!ExtendSelectionToLineBreakIntent@12b2451
    //     0xfc0328: ldr             x3, [x3, #0xbd0]
    // 0xfc032c: r0 = []=()
    //     0xfc032c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0330: ldur            x1, [fp, #-0x18]
    // 0xfc0334: r2 = Instance_SingleActivator
    //     0xfc0334: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbd8] Obj!SingleActivator@12b48c1
    //     0xfc0338: ldr             x2, [x2, #0xbd8]
    // 0xfc033c: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfc033c: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba10] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2271
    //     0xfc0340: ldr             x3, [x3, #0xa10]
    // 0xfc0344: r0 = []=()
    //     0xfc0344: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0348: ldur            x1, [fp, #-0x18]
    // 0xfc034c: r2 = Instance_SingleActivator
    //     0xfc034c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbe0] Obj!SingleActivator@12b4891
    //     0xfc0350: ldr             x2, [x2, #0xbe0]
    // 0xfc0354: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfc0354: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba20] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2251
    //     0xfc0358: ldr             x3, [x3, #0xa20]
    // 0xfc035c: r0 = []=()
    //     0xfc035c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0360: ldur            x1, [fp, #-0x18]
    // 0xfc0364: r2 = Instance_SingleActivator
    //     0xfc0364: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbe8] Obj!SingleActivator@12b4861
    //     0xfc0368: ldr             x2, [x2, #0xbe8]
    // 0xfc036c: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfc036c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabbf0] Obj!ExtendSelectionToLineBreakIntent@12b2531
    //     0xfc0370: ldr             x3, [x3, #0xbf0]
    // 0xfc0374: r0 = []=()
    //     0xfc0374: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0378: ldur            x1, [fp, #-0x18]
    // 0xfc037c: r2 = Instance_SingleActivator
    //     0xfc037c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabbf8] Obj!SingleActivator@12b4831
    //     0xfc0380: ldr             x2, [x2, #0xbf8]
    // 0xfc0384: r3 = Instance_ExtendSelectionToLineBreakIntent
    //     0xfc0384: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc00] Obj!ExtendSelectionToLineBreakIntent@12b2511
    //     0xfc0388: ldr             x3, [x3, #0xc00]
    // 0xfc038c: r0 = []=()
    //     0xfc038c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0390: ldur            x1, [fp, #-0x18]
    // 0xfc0394: r2 = Instance_SingleActivator
    //     0xfc0394: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc08] Obj!SingleActivator@12b4801
    //     0xfc0398: ldr             x2, [x2, #0xc08]
    // 0xfc039c: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfc039c: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba30] Obj!ExtendSelectionToDocumentBoundaryIntent@12b22b1
    //     0xfc03a0: ldr             x3, [x3, #0xa30]
    // 0xfc03a4: r0 = []=()
    //     0xfc03a4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc03a8: ldur            x1, [fp, #-0x18]
    // 0xfc03ac: r2 = Instance_SingleActivator
    //     0xfc03ac: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc10] Obj!SingleActivator@12b47d1
    //     0xfc03b0: ldr             x2, [x2, #0xc10]
    // 0xfc03b4: r3 = Instance_ExtendSelectionToDocumentBoundaryIntent
    //     0xfc03b4: add             x3, PP, #0xab, lsl #12  ; [pp+0xaba40] Obj!ExtendSelectionToDocumentBoundaryIntent@12b2291
    //     0xfc03b8: ldr             x3, [x3, #0xa40]
    // 0xfc03bc: r0 = []=()
    //     0xfc03bc: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc03c0: ldur            x1, [fp, #-0x18]
    // 0xfc03c4: r2 = Instance_SingleActivator
    //     0xfc03c4: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc18] Obj!SingleActivator@12b41a1
    //     0xfc03c8: ldr             x2, [x2, #0xc18]
    // 0xfc03cc: r3 = Instance_ExtendSelectionToNextWordBoundaryIntent
    //     0xfc03cc: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc20] Obj!ExtendSelectionToNextWordBoundaryIntent@12b2631
    //     0xfc03d0: ldr             x3, [x3, #0xc20]
    // 0xfc03d4: r0 = []=()
    //     0xfc03d4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc03d8: ldur            x1, [fp, #-0x18]
    // 0xfc03dc: r2 = Instance_SingleActivator
    //     0xfc03dc: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc28] Obj!SingleActivator@12b4171
    //     0xfc03e0: ldr             x2, [x2, #0xc28]
    // 0xfc03e4: r3 = Instance_ExtendSelectionToNextWordBoundaryIntent
    //     0xfc03e4: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc30] Obj!ExtendSelectionToNextWordBoundaryIntent@12b2611
    //     0xfc03e8: ldr             x3, [x3, #0xc30]
    // 0xfc03ec: r0 = []=()
    //     0xfc03ec: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc03f0: ldur            x1, [fp, #-0x18]
    // 0xfc03f4: r2 = Instance_SingleActivator
    //     0xfc03f4: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc38] Obj!SingleActivator@12b47a1
    //     0xfc03f8: ldr             x2, [x2, #0xc38]
    // 0xfc03fc: r3 = Instance_ExtendSelectionToNextWordBoundaryIntent
    //     0xfc03fc: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc40] Obj!ExtendSelectionToNextWordBoundaryIntent@12b2671
    //     0xfc0400: ldr             x3, [x3, #0xc40]
    // 0xfc0404: r0 = []=()
    //     0xfc0404: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0408: ldur            x1, [fp, #-0x18]
    // 0xfc040c: r2 = Instance_SingleActivator
    //     0xfc040c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc48] Obj!SingleActivator@12b4771
    //     0xfc0410: ldr             x2, [x2, #0xc48]
    // 0xfc0414: r3 = Instance_ExtendSelectionToNextWordBoundaryIntent
    //     0xfc0414: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc50] Obj!ExtendSelectionToNextWordBoundaryIntent@12b2651
    //     0xfc0418: ldr             x3, [x3, #0xc50]
    // 0xfc041c: r0 = []=()
    //     0xfc041c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0420: ldur            x1, [fp, #-0x18]
    // 0xfc0424: r2 = Instance_SingleActivator
    //     0xfc0424: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc58] Obj!SingleActivator@12b4741
    //     0xfc0428: ldr             x2, [x2, #0xc58]
    // 0xfc042c: r3 = Instance_ExtendSelectionToNextParagraphBoundaryIntent
    //     0xfc042c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc60] Obj!ExtendSelectionToNextParagraphBoundaryIntent@12b2331
    //     0xfc0430: ldr             x3, [x3, #0xc60]
    // 0xfc0434: r0 = []=()
    //     0xfc0434: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0438: ldur            x1, [fp, #-0x18]
    // 0xfc043c: r2 = Instance_SingleActivator
    //     0xfc043c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc68] Obj!SingleActivator@12b4711
    //     0xfc0440: ldr             x2, [x2, #0xc68]
    // 0xfc0444: r3 = Instance_ExtendSelectionToNextParagraphBoundaryIntent
    //     0xfc0444: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc70] Obj!ExtendSelectionToNextParagraphBoundaryIntent@12b2311
    //     0xfc0448: ldr             x3, [x3, #0xc70]
    // 0xfc044c: r0 = []=()
    //     0xfc044c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0450: ldur            x1, [fp, #-0x18]
    // 0xfc0454: r2 = Instance_SingleActivator
    //     0xfc0454: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc78] Obj!SingleActivator@12b4141
    //     0xfc0458: ldr             x2, [x2, #0xc78]
    // 0xfc045c: r3 = Instance_ExtendSelectionVerticallyToAdjacentPageIntent
    //     0xfc045c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc80] Obj!ExtendSelectionVerticallyToAdjacentPageIntent@12b23b1
    //     0xfc0460: ldr             x3, [x3, #0xc80]
    // 0xfc0464: r0 = []=()
    //     0xfc0464: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0468: ldur            x1, [fp, #-0x18]
    // 0xfc046c: r2 = Instance_SingleActivator
    //     0xfc046c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc88] Obj!SingleActivator@12b4111
    //     0xfc0470: ldr             x2, [x2, #0xc88]
    // 0xfc0474: r3 = Instance_ExtendSelectionVerticallyToAdjacentPageIntent
    //     0xfc0474: add             x3, PP, #0xab, lsl #12  ; [pp+0xabc90] Obj!ExtendSelectionVerticallyToAdjacentPageIntent@12b2391
    //     0xfc0478: ldr             x3, [x3, #0xc90]
    // 0xfc047c: r0 = []=()
    //     0xfc047c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0480: ldur            x1, [fp, #-0x18]
    // 0xfc0484: r2 = Instance_SingleActivator
    //     0xfc0484: add             x2, PP, #0xab, lsl #12  ; [pp+0xabc98] Obj!SingleActivator@12b46e1
    //     0xfc0488: ldr             x2, [x2, #0xc98]
    // 0xfc048c: r3 = Instance_ExtendSelectionVerticallyToAdjacentPageIntent
    //     0xfc048c: add             x3, PP, #0xab, lsl #12  ; [pp+0xabca0] Obj!ExtendSelectionVerticallyToAdjacentPageIntent@12b2371
    //     0xfc0490: ldr             x3, [x3, #0xca0]
    // 0xfc0494: r0 = []=()
    //     0xfc0494: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc0498: ldur            x1, [fp, #-0x18]
    // 0xfc049c: r2 = Instance_SingleActivator
    //     0xfc049c: add             x2, PP, #0xab, lsl #12  ; [pp+0xabca8] Obj!SingleActivator@12b46b1
    //     0xfc04a0: ldr             x2, [x2, #0xca8]
    // 0xfc04a4: r3 = Instance_ExtendSelectionVerticallyToAdjacentPageIntent
    //     0xfc04a4: add             x3, PP, #0xab, lsl #12  ; [pp+0xabcb0] Obj!ExtendSelectionVerticallyToAdjacentPageIntent@12b2351
    //     0xfc04a8: ldr             x3, [x3, #0xcb0]
    // 0xfc04ac: r0 = []=()
    //     0xfc04ac: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfc04b0: ldur            x0, [fp, #-0x18]
    // 0xfc04b4: LeaveFrame
    //     0xfc04b4: mov             SP, fp
    //     0xfc04b8: ldp             fp, lr, [SP], #0x10
    // 0xfc04bc: ret
    //     0xfc04bc: ret             
    // 0xfc04c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfc04c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfc04c4: b               #0xfbff30
    // 0xfc04c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfc04c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfc04cc: b               #0xfbff60
  }
}
