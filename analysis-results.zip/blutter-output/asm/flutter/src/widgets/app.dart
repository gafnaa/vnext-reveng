// lib: , url: package:flutter/src/widgets/app.dart

// class id: 1049115, size: 0x8
class :: {

  static _ basicLocaleListResolution(/* No info */) {
    // ** addr: 0x8da99c, size: 0x914
    // 0x8da99c: EnterFrame
    //     0x8da99c: stp             fp, lr, [SP, #-0x10]!
    //     0x8da9a0: mov             fp, SP
    // 0x8da9a4: AllocStack(0x80)
    //     0x8da9a4: sub             SP, SP, #0x80
    // 0x8da9a8: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x8da9a8: mov             x2, x1
    //     0x8da9ac: stur            x1, [fp, #-8]
    // 0x8da9b0: CheckStackOverflow
    //     0x8da9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da9b4: cmp             SP, x16
    //     0x8da9b8: b.ls            #0x8db298
    // 0x8da9bc: r0 = LoadClassIdInstr(r2)
    //     0x8da9bc: ldur            x0, [x2, #-1]
    //     0x8da9c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8da9c4: mov             x1, x2
    // 0x8da9c8: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x8da9c8: mov             x17, #0x2b36
    //     0x8da9cc: movk            x17, #1, lsl #16
    //     0x8da9d0: add             lr, x0, x17
    //     0x8da9d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8da9d8: blr             lr
    // 0x8da9dc: tbnz            w0, #4, #0x8da9f0
    // 0x8da9e0: r0 = Instance_Locale
    //     0x8da9e0: ldr             x0, [PP, #0x7fa0]  ; [pp+0x7fa0] Obj!Locale@12a0961
    // 0x8da9e4: LeaveFrame
    //     0x8da9e4: mov             SP, fp
    //     0x8da9e8: ldp             fp, lr, [SP], #0x10
    // 0x8da9ec: ret
    //     0x8da9ec: ret             
    // 0x8da9f0: r1 = <String, Locale>
    //     0x8da9f0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33c0] TypeArguments: <String, Locale>
    //     0x8da9f4: ldr             x1, [x1, #0x3c0]
    // 0x8da9f8: r0 = _HashMap()
    //     0x8da9f8: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x8da9fc: stur            x0, [fp, #-0x10]
    // 0x8daa00: StoreField: r0->field_b = rZR
    //     0x8daa00: stur            xzr, [x0, #0xb]
    // 0x8daa04: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8daa04: stur            xzr, [x0, #0x17]
    // 0x8daa08: r1 = <_HashMapEntry?>
    //     0x8daa08: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x8daa0c: ldr             x1, [x1, #0x930]
    // 0x8daa10: r2 = 16
    //     0x8daa10: mov             x2, #0x10
    // 0x8daa14: r0 = AllocateArray()
    //     0x8daa14: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daa18: mov             x1, x0
    // 0x8daa1c: ldur            x0, [fp, #-0x10]
    // 0x8daa20: StoreField: r0->field_13 = r1
    //     0x8daa20: stur            w1, [x0, #0x13]
    // 0x8daa24: r1 = <String, Locale>
    //     0x8daa24: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33c0] TypeArguments: <String, Locale>
    //     0x8daa28: ldr             x1, [x1, #0x3c0]
    // 0x8daa2c: r0 = _HashMap()
    //     0x8daa2c: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x8daa30: stur            x0, [fp, #-0x18]
    // 0x8daa34: StoreField: r0->field_b = rZR
    //     0x8daa34: stur            xzr, [x0, #0xb]
    // 0x8daa38: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8daa38: stur            xzr, [x0, #0x17]
    // 0x8daa3c: r1 = <_HashMapEntry?>
    //     0x8daa3c: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x8daa40: ldr             x1, [x1, #0x930]
    // 0x8daa44: r2 = 16
    //     0x8daa44: mov             x2, #0x10
    // 0x8daa48: r0 = AllocateArray()
    //     0x8daa48: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daa4c: mov             x1, x0
    // 0x8daa50: ldur            x0, [fp, #-0x18]
    // 0x8daa54: StoreField: r0->field_13 = r1
    //     0x8daa54: stur            w1, [x0, #0x13]
    // 0x8daa58: r1 = <String, Locale>
    //     0x8daa58: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33c0] TypeArguments: <String, Locale>
    //     0x8daa5c: ldr             x1, [x1, #0x3c0]
    // 0x8daa60: r0 = _HashMap()
    //     0x8daa60: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x8daa64: stur            x0, [fp, #-0x20]
    // 0x8daa68: StoreField: r0->field_b = rZR
    //     0x8daa68: stur            xzr, [x0, #0xb]
    // 0x8daa6c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8daa6c: stur            xzr, [x0, #0x17]
    // 0x8daa70: r1 = <_HashMapEntry?>
    //     0x8daa70: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x8daa74: ldr             x1, [x1, #0x930]
    // 0x8daa78: r2 = 16
    //     0x8daa78: mov             x2, #0x10
    // 0x8daa7c: r0 = AllocateArray()
    //     0x8daa7c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daa80: mov             x1, x0
    // 0x8daa84: ldur            x0, [fp, #-0x20]
    // 0x8daa88: StoreField: r0->field_13 = r1
    //     0x8daa88: stur            w1, [x0, #0x13]
    // 0x8daa8c: r1 = <String, Locale>
    //     0x8daa8c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33c0] TypeArguments: <String, Locale>
    //     0x8daa90: ldr             x1, [x1, #0x3c0]
    // 0x8daa94: r0 = _HashMap()
    //     0x8daa94: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x8daa98: stur            x0, [fp, #-0x28]
    // 0x8daa9c: StoreField: r0->field_b = rZR
    //     0x8daa9c: stur            xzr, [x0, #0xb]
    // 0x8daaa0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8daaa0: stur            xzr, [x0, #0x17]
    // 0x8daaa4: r1 = <_HashMapEntry?>
    //     0x8daaa4: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x8daaa8: ldr             x1, [x1, #0x930]
    // 0x8daaac: r2 = 16
    //     0x8daaac: mov             x2, #0x10
    // 0x8daab0: r0 = AllocateArray()
    //     0x8daab0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daab4: mov             x1, x0
    // 0x8daab8: ldur            x0, [fp, #-0x28]
    // 0x8daabc: StoreField: r0->field_13 = r1
    //     0x8daabc: stur            w1, [x0, #0x13]
    // 0x8daac0: r1 = <String?, Locale>
    //     0x8daac0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33c8] TypeArguments: <String?, Locale>
    //     0x8daac4: ldr             x1, [x1, #0x3c8]
    // 0x8daac8: r0 = _HashMap()
    //     0x8daac8: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x8daacc: stur            x0, [fp, #-0x30]
    // 0x8daad0: StoreField: r0->field_b = rZR
    //     0x8daad0: stur            xzr, [x0, #0xb]
    // 0x8daad4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8daad4: stur            xzr, [x0, #0x17]
    // 0x8daad8: r1 = <_HashMapEntry?>
    //     0x8daad8: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x8daadc: ldr             x1, [x1, #0x930]
    // 0x8daae0: r2 = 16
    //     0x8daae0: mov             x2, #0x10
    // 0x8daae4: r0 = AllocateArray()
    //     0x8daae4: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daae8: mov             x1, x0
    // 0x8daaec: ldur            x0, [fp, #-0x30]
    // 0x8daaf0: StoreField: r0->field_13 = r1
    //     0x8daaf0: stur            w1, [x0, #0x13]
    // 0x8daaf4: r1 = 0
    //     0x8daaf4: mov             x1, #0
    // 0x8daaf8: r3 = const [Instance of 'Locale', Instance of 'Locale']
    //     0x8daaf8: add             x3, PP, #0x12, lsl #12  ; [pp+0x127e8] List<Locale>(2)
    //     0x8daafc: ldr             x3, [x3, #0x7e8]
    // 0x8dab00: CheckStackOverflow
    //     0x8dab00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dab04: cmp             SP, x16
    //     0x8dab08: b.ls            #0x8db2a0
    // 0x8dab0c: cmp             x1, #2
    // 0x8dab10: b.ge            #0x8dadd8
    // 0x8dab14: ArrayLoad: r4 = r3[r1]  ; Unknown_4
    //     0x8dab14: add             x16, x3, x1, lsl #2
    //     0x8dab18: ldur            w4, [x16, #0xf]
    // 0x8dab1c: DecompressPointer r4
    //     0x8dab1c: add             x4, x4, HEAP, lsl #32
    // 0x8dab20: stur            x4, [fp, #-0x48]
    // 0x8dab24: add             x5, x1, #1
    // 0x8dab28: stur            x5, [fp, #-0x40]
    // 0x8dab2c: LoadField: r6 = r4->field_7
    //     0x8dab2c: ldur            w6, [x4, #7]
    // 0x8dab30: DecompressPointer r6
    //     0x8dab30: add             x6, x6, HEAP, lsl #32
    // 0x8dab34: mov             x2, x6
    // 0x8dab38: stur            x6, [fp, #-0x38]
    // 0x8dab3c: r1 = _ConstMap len:78
    //     0x8dab3c: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8dab40: r0 = []()
    //     0x8dab40: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dab44: cmp             w0, NULL
    // 0x8dab48: b.ne            #0x8dab50
    // 0x8dab4c: ldur            x0, [fp, #-0x38]
    // 0x8dab50: ldur            x3, [fp, #-0x48]
    // 0x8dab54: stur            x0, [fp, #-0x50]
    // 0x8dab58: r1 = Null
    //     0x8dab58: mov             x1, NULL
    // 0x8dab5c: r2 = 10
    //     0x8dab5c: mov             x2, #0xa
    // 0x8dab60: r0 = AllocateArray()
    //     0x8dab60: bl              #0x13df928  ; AllocateArrayStub
    // 0x8dab64: mov             x3, x0
    // 0x8dab68: ldur            x0, [fp, #-0x50]
    // 0x8dab6c: stur            x3, [fp, #-0x60]
    // 0x8dab70: StoreField: r3->field_f = r0
    //     0x8dab70: stur            w0, [x3, #0xf]
    // 0x8dab74: r16 = "_"
    //     0x8dab74: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8dab78: StoreField: r3->field_13 = r16
    //     0x8dab78: stur            w16, [x3, #0x13]
    // 0x8dab7c: ldur            x0, [fp, #-0x48]
    // 0x8dab80: LoadField: r4 = r0->field_b
    //     0x8dab80: ldur            w4, [x0, #0xb]
    // 0x8dab84: DecompressPointer r4
    //     0x8dab84: add             x4, x4, HEAP, lsl #32
    // 0x8dab88: stur            x4, [fp, #-0x58]
    // 0x8dab8c: ArrayStore: r3[0] = r4  ; List_4
    //     0x8dab8c: stur            w4, [x3, #0x17]
    // 0x8dab90: r16 = "_"
    //     0x8dab90: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8dab94: StoreField: r3->field_1b = r16
    //     0x8dab94: stur            w16, [x3, #0x1b]
    // 0x8dab98: LoadField: r5 = r0->field_f
    //     0x8dab98: ldur            w5, [x0, #0xf]
    // 0x8dab9c: DecompressPointer r5
    //     0x8dab9c: add             x5, x5, HEAP, lsl #32
    // 0x8daba0: mov             x2, x5
    // 0x8daba4: stur            x5, [fp, #-0x50]
    // 0x8daba8: r1 = _ConstMap len:6
    //     0x8daba8: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8dabac: r0 = []()
    //     0x8dabac: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dabb0: cmp             w0, NULL
    // 0x8dabb4: b.ne            #0x8dabbc
    // 0x8dabb8: ldur            x0, [fp, #-0x50]
    // 0x8dabbc: ldur            x1, [fp, #-0x60]
    // 0x8dabc0: ArrayStore: r1[4] = r0  ; List_4
    //     0x8dabc0: add             x25, x1, #0x1f
    //     0x8dabc4: str             w0, [x25]
    //     0x8dabc8: tbz             w0, #0, #0x8dabe4
    //     0x8dabcc: ldurb           w16, [x1, #-1]
    //     0x8dabd0: ldurb           w17, [x0, #-1]
    //     0x8dabd4: and             x16, x17, x16, lsr #2
    //     0x8dabd8: tst             x16, HEAP, lsr #32
    //     0x8dabdc: b.eq            #0x8dabe4
    //     0x8dabe0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8dabe4: ldur            x16, [fp, #-0x60]
    // 0x8dabe8: str             x16, [SP]
    // 0x8dabec: r0 = _interpolate()
    //     0x8dabec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8dabf0: ldur            x1, [fp, #-0x10]
    // 0x8dabf4: mov             x2, x0
    // 0x8dabf8: stur            x0, [fp, #-0x60]
    // 0x8dabfc: r0 = []()
    //     0x8dabfc: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dac00: cmp             w0, NULL
    // 0x8dac04: b.ne            #0x8dac18
    // 0x8dac08: ldur            x1, [fp, #-0x10]
    // 0x8dac0c: ldur            x2, [fp, #-0x60]
    // 0x8dac10: ldur            x3, [fp, #-0x48]
    // 0x8dac14: r0 = []=()
    //     0x8dac14: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x8dac18: ldur            x2, [fp, #-0x38]
    // 0x8dac1c: r1 = _ConstMap len:78
    //     0x8dac1c: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8dac20: r0 = []()
    //     0x8dac20: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dac24: cmp             w0, NULL
    // 0x8dac28: b.ne            #0x8dac34
    // 0x8dac2c: ldur            x3, [fp, #-0x38]
    // 0x8dac30: b               #0x8dac38
    // 0x8dac34: mov             x3, x0
    // 0x8dac38: ldur            x0, [fp, #-0x58]
    // 0x8dac3c: stur            x3, [fp, #-0x60]
    // 0x8dac40: r1 = Null
    //     0x8dac40: mov             x1, NULL
    // 0x8dac44: r2 = 6
    //     0x8dac44: mov             x2, #6
    // 0x8dac48: r0 = AllocateArray()
    //     0x8dac48: bl              #0x13df928  ; AllocateArrayStub
    // 0x8dac4c: mov             x1, x0
    // 0x8dac50: ldur            x0, [fp, #-0x60]
    // 0x8dac54: StoreField: r1->field_f = r0
    //     0x8dac54: stur            w0, [x1, #0xf]
    // 0x8dac58: r16 = "_"
    //     0x8dac58: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8dac5c: StoreField: r1->field_13 = r16
    //     0x8dac5c: stur            w16, [x1, #0x13]
    // 0x8dac60: ldur            x0, [fp, #-0x58]
    // 0x8dac64: ArrayStore: r1[0] = r0  ; List_4
    //     0x8dac64: stur            w0, [x1, #0x17]
    // 0x8dac68: str             x1, [SP]
    // 0x8dac6c: r0 = _interpolate()
    //     0x8dac6c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8dac70: ldur            x1, [fp, #-0x20]
    // 0x8dac74: mov             x2, x0
    // 0x8dac78: stur            x0, [fp, #-0x58]
    // 0x8dac7c: r0 = []()
    //     0x8dac7c: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dac80: cmp             w0, NULL
    // 0x8dac84: b.ne            #0x8dac98
    // 0x8dac88: ldur            x1, [fp, #-0x20]
    // 0x8dac8c: ldur            x2, [fp, #-0x58]
    // 0x8dac90: ldur            x3, [fp, #-0x48]
    // 0x8dac94: r0 = []=()
    //     0x8dac94: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x8dac98: ldur            x2, [fp, #-0x38]
    // 0x8dac9c: r1 = _ConstMap len:78
    //     0x8dac9c: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8daca0: r0 = []()
    //     0x8daca0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8daca4: cmp             w0, NULL
    // 0x8daca8: b.ne            #0x8dacb0
    // 0x8dacac: ldur            x0, [fp, #-0x38]
    // 0x8dacb0: stur            x0, [fp, #-0x58]
    // 0x8dacb4: r1 = Null
    //     0x8dacb4: mov             x1, NULL
    // 0x8dacb8: r2 = 6
    //     0x8dacb8: mov             x2, #6
    // 0x8dacbc: r0 = AllocateArray()
    //     0x8dacbc: bl              #0x13df928  ; AllocateArrayStub
    // 0x8dacc0: mov             x3, x0
    // 0x8dacc4: ldur            x0, [fp, #-0x58]
    // 0x8dacc8: stur            x3, [fp, #-0x60]
    // 0x8daccc: StoreField: r3->field_f = r0
    //     0x8daccc: stur            w0, [x3, #0xf]
    // 0x8dacd0: r16 = "_"
    //     0x8dacd0: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8dacd4: StoreField: r3->field_13 = r16
    //     0x8dacd4: stur            w16, [x3, #0x13]
    // 0x8dacd8: ldur            x2, [fp, #-0x50]
    // 0x8dacdc: r1 = _ConstMap len:6
    //     0x8dacdc: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8dace0: r0 = []()
    //     0x8dace0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dace4: cmp             w0, NULL
    // 0x8dace8: b.ne            #0x8dacf0
    // 0x8dacec: ldur            x0, [fp, #-0x50]
    // 0x8dacf0: ldur            x1, [fp, #-0x60]
    // 0x8dacf4: ArrayStore: r1[2] = r0  ; List_4
    //     0x8dacf4: add             x25, x1, #0x17
    //     0x8dacf8: str             w0, [x25]
    //     0x8dacfc: tbz             w0, #0, #0x8dad18
    //     0x8dad00: ldurb           w16, [x1, #-1]
    //     0x8dad04: ldurb           w17, [x0, #-1]
    //     0x8dad08: and             x16, x17, x16, lsr #2
    //     0x8dad0c: tst             x16, HEAP, lsr #32
    //     0x8dad10: b.eq            #0x8dad18
    //     0x8dad14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8dad18: ldur            x16, [fp, #-0x60]
    // 0x8dad1c: str             x16, [SP]
    // 0x8dad20: r0 = _interpolate()
    //     0x8dad20: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8dad24: ldur            x1, [fp, #-0x18]
    // 0x8dad28: mov             x2, x0
    // 0x8dad2c: stur            x0, [fp, #-0x58]
    // 0x8dad30: r0 = []()
    //     0x8dad30: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dad34: cmp             w0, NULL
    // 0x8dad38: b.ne            #0x8dad4c
    // 0x8dad3c: ldur            x1, [fp, #-0x18]
    // 0x8dad40: ldur            x2, [fp, #-0x58]
    // 0x8dad44: ldur            x3, [fp, #-0x48]
    // 0x8dad48: r0 = []=()
    //     0x8dad48: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x8dad4c: ldur            x2, [fp, #-0x38]
    // 0x8dad50: r1 = _ConstMap len:78
    //     0x8dad50: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8dad54: r0 = []()
    //     0x8dad54: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dad58: cmp             w0, NULL
    // 0x8dad5c: b.ne            #0x8dad64
    // 0x8dad60: ldur            x0, [fp, #-0x38]
    // 0x8dad64: ldur            x1, [fp, #-0x28]
    // 0x8dad68: mov             x2, x0
    // 0x8dad6c: stur            x0, [fp, #-0x38]
    // 0x8dad70: r0 = []()
    //     0x8dad70: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dad74: cmp             w0, NULL
    // 0x8dad78: b.ne            #0x8dad8c
    // 0x8dad7c: ldur            x1, [fp, #-0x28]
    // 0x8dad80: ldur            x2, [fp, #-0x38]
    // 0x8dad84: ldur            x3, [fp, #-0x48]
    // 0x8dad88: r0 = []=()
    //     0x8dad88: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x8dad8c: ldur            x2, [fp, #-0x50]
    // 0x8dad90: r1 = _ConstMap len:6
    //     0x8dad90: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8dad94: r0 = []()
    //     0x8dad94: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dad98: cmp             w0, NULL
    // 0x8dad9c: b.ne            #0x8dada4
    // 0x8dada0: ldur            x0, [fp, #-0x50]
    // 0x8dada4: ldur            x1, [fp, #-0x30]
    // 0x8dada8: mov             x2, x0
    // 0x8dadac: stur            x0, [fp, #-0x38]
    // 0x8dadb0: r0 = []()
    //     0x8dadb0: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dadb4: cmp             w0, NULL
    // 0x8dadb8: b.ne            #0x8dadcc
    // 0x8dadbc: ldur            x1, [fp, #-0x30]
    // 0x8dadc0: ldur            x2, [fp, #-0x38]
    // 0x8dadc4: ldur            x3, [fp, #-0x48]
    // 0x8dadc8: r0 = []=()
    //     0x8dadc8: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x8dadcc: ldur            x1, [fp, #-0x40]
    // 0x8dadd0: ldur            x0, [fp, #-0x30]
    // 0x8dadd4: b               #0x8daaf8
    // 0x8dadd8: r4 = Null
    //     0x8dadd8: mov             x4, NULL
    // 0x8daddc: r3 = Null
    //     0x8daddc: mov             x3, NULL
    // 0x8dade0: r2 = 0
    //     0x8dade0: mov             x2, #0
    // 0x8dade4: ldur            x1, [fp, #-8]
    // 0x8dade8: stur            x4, [fp, #-0x38]
    // 0x8dadec: stur            x3, [fp, #-0x48]
    // 0x8dadf0: stur            x2, [fp, #-0x40]
    // 0x8dadf4: CheckStackOverflow
    //     0x8dadf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dadf8: cmp             SP, x16
    //     0x8dadfc: b.ls            #0x8db2a8
    // 0x8dae00: r0 = LoadClassIdInstr(r1)
    //     0x8dae00: ldur            x0, [x1, #-1]
    //     0x8dae04: ubfx            x0, x0, #0xc, #0x14
    // 0x8dae08: str             x1, [SP]
    // 0x8dae0c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8dae0c: mov             x17, #0xf078
    //     0x8dae10: add             lr, x0, x17
    //     0x8dae14: ldr             lr, [x21, lr, lsl #3]
    //     0x8dae18: blr             lr
    // 0x8dae1c: r1 = LoadInt32Instr(r0)
    //     0x8dae1c: sbfx            x1, x0, #1, #0x1f
    // 0x8dae20: ldur            x2, [fp, #-0x40]
    // 0x8dae24: cmp             x2, x1
    // 0x8dae28: b.ge            #0x8db268
    // 0x8dae2c: ldur            x3, [fp, #-8]
    // 0x8dae30: r0 = BoxInt64Instr(r2)
    //     0x8dae30: sbfiz           x0, x2, #1, #0x1f
    //     0x8dae34: cmp             x2, x0, asr #1
    //     0x8dae38: b.eq            #0x8dae44
    //     0x8dae3c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8dae40: stur            x2, [x0, #7]
    // 0x8dae44: r1 = LoadClassIdInstr(r3)
    //     0x8dae44: ldur            x1, [x3, #-1]
    //     0x8dae48: ubfx            x1, x1, #0xc, #0x14
    // 0x8dae4c: stp             x0, x3, [SP]
    // 0x8dae50: mov             x0, x1
    // 0x8dae54: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8dae54: sub             lr, x0, #0xdfd
    //     0x8dae58: ldr             lr, [x21, lr, lsl #3]
    //     0x8dae5c: blr             lr
    // 0x8dae60: stur            x0, [fp, #-0x58]
    // 0x8dae64: LoadField: r3 = r0->field_7
    //     0x8dae64: ldur            w3, [x0, #7]
    // 0x8dae68: DecompressPointer r3
    //     0x8dae68: add             x3, x3, HEAP, lsl #32
    // 0x8dae6c: mov             x2, x3
    // 0x8dae70: stur            x3, [fp, #-0x50]
    // 0x8dae74: r1 = _ConstMap len:78
    //     0x8dae74: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8dae78: r0 = []()
    //     0x8dae78: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dae7c: cmp             w0, NULL
    // 0x8dae80: b.ne            #0x8dae8c
    // 0x8dae84: ldur            x3, [fp, #-0x50]
    // 0x8dae88: b               #0x8dae90
    // 0x8dae8c: mov             x3, x0
    // 0x8dae90: ldur            x0, [fp, #-0x58]
    // 0x8dae94: stur            x3, [fp, #-0x60]
    // 0x8dae98: r1 = Null
    //     0x8dae98: mov             x1, NULL
    // 0x8dae9c: r2 = 10
    //     0x8dae9c: mov             x2, #0xa
    // 0x8daea0: r0 = AllocateArray()
    //     0x8daea0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daea4: mov             x3, x0
    // 0x8daea8: ldur            x0, [fp, #-0x60]
    // 0x8daeac: stur            x3, [fp, #-0x70]
    // 0x8daeb0: StoreField: r3->field_f = r0
    //     0x8daeb0: stur            w0, [x3, #0xf]
    // 0x8daeb4: r16 = "_"
    //     0x8daeb4: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8daeb8: StoreField: r3->field_13 = r16
    //     0x8daeb8: stur            w16, [x3, #0x13]
    // 0x8daebc: ldur            x0, [fp, #-0x58]
    // 0x8daec0: LoadField: r4 = r0->field_b
    //     0x8daec0: ldur            w4, [x0, #0xb]
    // 0x8daec4: DecompressPointer r4
    //     0x8daec4: add             x4, x4, HEAP, lsl #32
    // 0x8daec8: stur            x4, [fp, #-0x68]
    // 0x8daecc: ArrayStore: r3[0] = r4  ; List_4
    //     0x8daecc: stur            w4, [x3, #0x17]
    // 0x8daed0: r16 = "_"
    //     0x8daed0: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8daed4: StoreField: r3->field_1b = r16
    //     0x8daed4: stur            w16, [x3, #0x1b]
    // 0x8daed8: LoadField: r5 = r0->field_f
    //     0x8daed8: ldur            w5, [x0, #0xf]
    // 0x8daedc: DecompressPointer r5
    //     0x8daedc: add             x5, x5, HEAP, lsl #32
    // 0x8daee0: mov             x2, x5
    // 0x8daee4: stur            x5, [fp, #-0x60]
    // 0x8daee8: r1 = _ConstMap len:6
    //     0x8daee8: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8daeec: r0 = []()
    //     0x8daeec: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8daef0: cmp             w0, NULL
    // 0x8daef4: b.ne            #0x8daefc
    // 0x8daef8: ldur            x0, [fp, #-0x60]
    // 0x8daefc: ldur            x1, [fp, #-0x70]
    // 0x8daf00: ArrayStore: r1[4] = r0  ; List_4
    //     0x8daf00: add             x25, x1, #0x1f
    //     0x8daf04: str             w0, [x25]
    //     0x8daf08: tbz             w0, #0, #0x8daf24
    //     0x8daf0c: ldurb           w16, [x1, #-1]
    //     0x8daf10: ldurb           w17, [x0, #-1]
    //     0x8daf14: and             x16, x17, x16, lsr #2
    //     0x8daf18: tst             x16, HEAP, lsr #32
    //     0x8daf1c: b.eq            #0x8daf24
    //     0x8daf20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8daf24: ldur            x16, [fp, #-0x70]
    // 0x8daf28: str             x16, [SP]
    // 0x8daf2c: r0 = _interpolate()
    //     0x8daf2c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8daf30: ldur            x1, [fp, #-0x10]
    // 0x8daf34: mov             x2, x0
    // 0x8daf38: r0 = containsKey()
    //     0x8daf38: bl              #0x12596dc  ; [dart:collection] _HashMap::containsKey
    // 0x8daf3c: tbz             w0, #4, #0x8db258
    // 0x8daf40: ldur            x0, [fp, #-0x68]
    // 0x8daf44: cmp             w0, NULL
    // 0x8daf48: b.eq            #0x8dafc4
    // 0x8daf4c: ldur            x2, [fp, #-0x50]
    // 0x8daf50: r1 = _ConstMap len:78
    //     0x8daf50: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8daf54: r0 = []()
    //     0x8daf54: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8daf58: cmp             w0, NULL
    // 0x8daf5c: b.ne            #0x8daf68
    // 0x8daf60: ldur            x3, [fp, #-0x50]
    // 0x8daf64: b               #0x8daf6c
    // 0x8daf68: mov             x3, x0
    // 0x8daf6c: ldur            x0, [fp, #-0x68]
    // 0x8daf70: stur            x3, [fp, #-0x70]
    // 0x8daf74: r1 = Null
    //     0x8daf74: mov             x1, NULL
    // 0x8daf78: r2 = 6
    //     0x8daf78: mov             x2, #6
    // 0x8daf7c: r0 = AllocateArray()
    //     0x8daf7c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8daf80: mov             x1, x0
    // 0x8daf84: ldur            x0, [fp, #-0x70]
    // 0x8daf88: StoreField: r1->field_f = r0
    //     0x8daf88: stur            w0, [x1, #0xf]
    // 0x8daf8c: r16 = "_"
    //     0x8daf8c: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8daf90: StoreField: r1->field_13 = r16
    //     0x8daf90: stur            w16, [x1, #0x13]
    // 0x8daf94: ldur            x0, [fp, #-0x68]
    // 0x8daf98: ArrayStore: r1[0] = r0  ; List_4
    //     0x8daf98: stur            w0, [x1, #0x17]
    // 0x8daf9c: str             x1, [SP]
    // 0x8dafa0: r0 = _interpolate()
    //     0x8dafa0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8dafa4: ldur            x1, [fp, #-0x20]
    // 0x8dafa8: mov             x2, x0
    // 0x8dafac: r0 = []()
    //     0x8dafac: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8dafb0: cmp             w0, NULL
    // 0x8dafb4: b.eq            #0x8dafc4
    // 0x8dafb8: LeaveFrame
    //     0x8dafb8: mov             SP, fp
    //     0x8dafbc: ldp             fp, lr, [SP], #0x10
    // 0x8dafc0: ret
    //     0x8dafc0: ret             
    // 0x8dafc4: ldur            x2, [fp, #-0x60]
    // 0x8dafc8: r1 = _ConstMap len:6
    //     0x8dafc8: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8dafcc: r0 = []()
    //     0x8dafcc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dafd0: cmp             w0, NULL
    // 0x8dafd4: b.ne            #0x8dafe8
    // 0x8dafd8: ldur            x0, [fp, #-0x60]
    // 0x8dafdc: cmp             w0, NULL
    // 0x8dafe0: b.eq            #0x8db08c
    // 0x8dafe4: b               #0x8dafec
    // 0x8dafe8: ldur            x0, [fp, #-0x60]
    // 0x8dafec: ldur            x2, [fp, #-0x50]
    // 0x8daff0: r1 = _ConstMap len:78
    //     0x8daff0: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8daff4: r0 = []()
    //     0x8daff4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8daff8: cmp             w0, NULL
    // 0x8daffc: b.ne            #0x8db004
    // 0x8db000: ldur            x0, [fp, #-0x50]
    // 0x8db004: stur            x0, [fp, #-0x68]
    // 0x8db008: r1 = Null
    //     0x8db008: mov             x1, NULL
    // 0x8db00c: r2 = 6
    //     0x8db00c: mov             x2, #6
    // 0x8db010: r0 = AllocateArray()
    //     0x8db010: bl              #0x13df928  ; AllocateArrayStub
    // 0x8db014: mov             x3, x0
    // 0x8db018: ldur            x0, [fp, #-0x68]
    // 0x8db01c: stur            x3, [fp, #-0x70]
    // 0x8db020: StoreField: r3->field_f = r0
    //     0x8db020: stur            w0, [x3, #0xf]
    // 0x8db024: r16 = "_"
    //     0x8db024: ldr             x16, [PP, #0x4a50]  ; [pp+0x4a50] "_"
    // 0x8db028: StoreField: r3->field_13 = r16
    //     0x8db028: stur            w16, [x3, #0x13]
    // 0x8db02c: ldur            x2, [fp, #-0x60]
    // 0x8db030: r1 = _ConstMap len:6
    //     0x8db030: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8db034: r0 = []()
    //     0x8db034: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db038: cmp             w0, NULL
    // 0x8db03c: b.ne            #0x8db044
    // 0x8db040: ldur            x0, [fp, #-0x60]
    // 0x8db044: ldur            x1, [fp, #-0x70]
    // 0x8db048: ArrayStore: r1[2] = r0  ; List_4
    //     0x8db048: add             x25, x1, #0x17
    //     0x8db04c: str             w0, [x25]
    //     0x8db050: tbz             w0, #0, #0x8db06c
    //     0x8db054: ldurb           w16, [x1, #-1]
    //     0x8db058: ldurb           w17, [x0, #-1]
    //     0x8db05c: and             x16, x17, x16, lsr #2
    //     0x8db060: tst             x16, HEAP, lsr #32
    //     0x8db064: b.eq            #0x8db06c
    //     0x8db068: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8db06c: ldur            x16, [fp, #-0x70]
    // 0x8db070: str             x16, [SP]
    // 0x8db074: r0 = _interpolate()
    //     0x8db074: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8db078: ldur            x1, [fp, #-0x18]
    // 0x8db07c: mov             x2, x0
    // 0x8db080: r0 = []()
    //     0x8db080: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8db084: cmp             w0, NULL
    // 0x8db088: b.ne            #0x8db24c
    // 0x8db08c: ldur            x0, [fp, #-0x38]
    // 0x8db090: cmp             w0, NULL
    // 0x8db094: b.ne            #0x8db23c
    // 0x8db098: ldur            x2, [fp, #-0x50]
    // 0x8db09c: r1 = _ConstMap len:78
    //     0x8db09c: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8db0a0: r0 = []()
    //     0x8db0a0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db0a4: cmp             w0, NULL
    // 0x8db0a8: b.ne            #0x8db0b4
    // 0x8db0ac: ldur            x2, [fp, #-0x50]
    // 0x8db0b0: b               #0x8db0b8
    // 0x8db0b4: mov             x2, x0
    // 0x8db0b8: ldur            x1, [fp, #-0x28]
    // 0x8db0bc: r0 = []()
    //     0x8db0bc: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8db0c0: mov             x1, x0
    // 0x8db0c4: stur            x1, [fp, #-0x68]
    // 0x8db0c8: cmp             w1, NULL
    // 0x8db0cc: b.eq            #0x8db1a8
    // 0x8db0d0: ldur            x2, [fp, #-0x40]
    // 0x8db0d4: cbnz            x2, #0x8db1a0
    // 0x8db0d8: ldur            x3, [fp, #-8]
    // 0x8db0dc: r0 = LoadClassIdInstr(r3)
    //     0x8db0dc: ldur            x0, [x3, #-1]
    //     0x8db0e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8db0e4: str             x3, [SP]
    // 0x8db0e8: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8db0e8: mov             x17, #0xf078
    //     0x8db0ec: add             lr, x0, x17
    //     0x8db0f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8db0f4: blr             lr
    // 0x8db0f8: r1 = LoadInt32Instr(r0)
    //     0x8db0f8: sbfx            x1, x0, #1, #0x1f
    // 0x8db0fc: cmp             x1, #1
    // 0x8db100: b.le            #0x8db190
    // 0x8db104: ldur            x1, [fp, #-8]
    // 0x8db108: r0 = LoadClassIdInstr(r1)
    //     0x8db108: ldur            x0, [x1, #-1]
    //     0x8db10c: ubfx            x0, x0, #0xc, #0x14
    // 0x8db110: r16 = 2
    //     0x8db110: mov             x16, #2
    // 0x8db114: stp             x16, x1, [SP]
    // 0x8db118: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8db118: sub             lr, x0, #0xdfd
    //     0x8db11c: ldr             lr, [x21, lr, lsl #3]
    //     0x8db120: blr             lr
    // 0x8db124: LoadField: r3 = r0->field_7
    //     0x8db124: ldur            w3, [x0, #7]
    // 0x8db128: DecompressPointer r3
    //     0x8db128: add             x3, x3, HEAP, lsl #32
    // 0x8db12c: mov             x2, x3
    // 0x8db130: stur            x3, [fp, #-0x70]
    // 0x8db134: r1 = _ConstMap len:78
    //     0x8db134: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8db138: r0 = []()
    //     0x8db138: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db13c: cmp             w0, NULL
    // 0x8db140: b.ne            #0x8db148
    // 0x8db144: ldur            x0, [fp, #-0x70]
    // 0x8db148: ldur            x2, [fp, #-0x50]
    // 0x8db14c: stur            x0, [fp, #-0x70]
    // 0x8db150: r1 = _ConstMap len:78
    //     0x8db150: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x8db154: r0 = []()
    //     0x8db154: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db158: cmp             w0, NULL
    // 0x8db15c: b.ne            #0x8db168
    // 0x8db160: ldur            x1, [fp, #-0x50]
    // 0x8db164: b               #0x8db16c
    // 0x8db168: mov             x1, x0
    // 0x8db16c: ldur            x0, [fp, #-0x70]
    // 0x8db170: r2 = LoadClassIdInstr(r0)
    //     0x8db170: ldur            x2, [x0, #-1]
    //     0x8db174: ubfx            x2, x2, #0xc, #0x14
    // 0x8db178: stp             x1, x0, [SP]
    // 0x8db17c: mov             x0, x2
    // 0x8db180: mov             lr, x0
    // 0x8db184: ldr             lr, [x21, lr, lsl #3]
    // 0x8db188: blr             lr
    // 0x8db18c: tbz             w0, #4, #0x8db1a0
    // 0x8db190: ldur            x0, [fp, #-0x68]
    // 0x8db194: LeaveFrame
    //     0x8db194: mov             SP, fp
    //     0x8db198: ldp             fp, lr, [SP], #0x10
    // 0x8db19c: ret
    //     0x8db19c: ret             
    // 0x8db1a0: ldur            x4, [fp, #-0x68]
    // 0x8db1a4: b               #0x8db1ac
    // 0x8db1a8: ldur            x4, [fp, #-0x38]
    // 0x8db1ac: ldur            x0, [fp, #-0x48]
    // 0x8db1b0: stur            x4, [fp, #-0x50]
    // 0x8db1b4: cmp             w0, NULL
    // 0x8db1b8: b.ne            #0x8db228
    // 0x8db1bc: ldur            x2, [fp, #-0x60]
    // 0x8db1c0: r1 = _ConstMap len:6
    //     0x8db1c0: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8db1c4: r0 = []()
    //     0x8db1c4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db1c8: cmp             w0, NULL
    // 0x8db1cc: b.ne            #0x8db1e0
    // 0x8db1d0: ldur            x0, [fp, #-0x60]
    // 0x8db1d4: cmp             w0, NULL
    // 0x8db1d8: b.eq            #0x8db228
    // 0x8db1dc: b               #0x8db1e4
    // 0x8db1e0: ldur            x0, [fp, #-0x60]
    // 0x8db1e4: mov             x2, x0
    // 0x8db1e8: r1 = _ConstMap len:6
    //     0x8db1e8: ldr             x1, [PP, #0x24f0]  ; [pp+0x24f0] Map<String, String>(6)
    // 0x8db1ec: r0 = []()
    //     0x8db1ec: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8db1f0: cmp             w0, NULL
    // 0x8db1f4: b.ne            #0x8db200
    // 0x8db1f8: ldur            x2, [fp, #-0x60]
    // 0x8db1fc: b               #0x8db204
    // 0x8db200: mov             x2, x0
    // 0x8db204: ldur            x1, [fp, #-0x30]
    // 0x8db208: r0 = []()
    //     0x8db208: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x8db20c: cmp             w0, NULL
    // 0x8db210: b.eq            #0x8db21c
    // 0x8db214: mov             x1, x0
    // 0x8db218: b               #0x8db220
    // 0x8db21c: ldur            x1, [fp, #-0x48]
    // 0x8db220: mov             x3, x1
    // 0x8db224: b               #0x8db22c
    // 0x8db228: ldur            x3, [fp, #-0x48]
    // 0x8db22c: ldur            x1, [fp, #-0x40]
    // 0x8db230: add             x2, x1, #1
    // 0x8db234: ldur            x4, [fp, #-0x50]
    // 0x8db238: b               #0x8dade4
    // 0x8db23c: ldur            x0, [fp, #-0x38]
    // 0x8db240: LeaveFrame
    //     0x8db240: mov             SP, fp
    //     0x8db244: ldp             fp, lr, [SP], #0x10
    // 0x8db248: ret
    //     0x8db248: ret             
    // 0x8db24c: LeaveFrame
    //     0x8db24c: mov             SP, fp
    //     0x8db250: ldp             fp, lr, [SP], #0x10
    // 0x8db254: ret
    //     0x8db254: ret             
    // 0x8db258: ldur            x0, [fp, #-0x58]
    // 0x8db25c: LeaveFrame
    //     0x8db25c: mov             SP, fp
    //     0x8db260: ldp             fp, lr, [SP], #0x10
    // 0x8db264: ret
    //     0x8db264: ret             
    // 0x8db268: ldur            x1, [fp, #-0x38]
    // 0x8db26c: cmp             w1, NULL
    // 0x8db270: b.ne            #0x8db278
    // 0x8db274: ldur            x1, [fp, #-0x48]
    // 0x8db278: cmp             w1, NULL
    // 0x8db27c: b.ne            #0x8db288
    // 0x8db280: r0 = Instance_Locale
    //     0x8db280: ldr             x0, [PP, #0x7fa0]  ; [pp+0x7fa0] Obj!Locale@12a0961
    // 0x8db284: b               #0x8db28c
    // 0x8db288: mov             x0, x1
    // 0x8db28c: LeaveFrame
    //     0x8db28c: mov             SP, fp
    //     0x8db290: ldp             fp, lr, [SP], #0x10
    // 0x8db294: ret
    //     0x8db294: ret             
    // 0x8db298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db29c: b               #0x8da9bc
    // 0x8db2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db2a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db2a4: b               #0x8dab0c
    // 0x8db2a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db2a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db2ac: b               #0x8dae00
  }
}

// class id: 5673, size: 0x24, field offset: 0x14
class _WidgetsAppState extends _MixinApplication190&State&WidgetsBindingObserver {

  late final LocalizationsResolver _localizationsResolver; // offset: 0x20

  _ didPopRoute(/* No info */) async {
    // ** addr: 0x8d2674, size: 0x88
    // 0x8d2674: EnterFrame
    //     0x8d2674: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2678: mov             fp, SP
    // 0x8d267c: AllocStack(0x20)
    //     0x8d267c: sub             SP, SP, #0x20
    // 0x8d2680: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x10 */)
    //     0x8d2680: stur            NULL, [fp, #-8]
    //     0x8d2684: stur            x1, [fp, #-0x10]
    // 0x8d2688: CheckStackOverflow
    //     0x8d2688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d268c: cmp             SP, x16
    //     0x8d2690: b.ls            #0x8d26f0
    // 0x8d2694: InitAsync() -> Future<bool>
    //     0x8d2694: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0x8d2698: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8d269c: ldur            x0, [fp, #-0x10]
    // 0x8d26a0: LoadField: r1 = r0->field_b
    //     0x8d26a0: ldur            w1, [x0, #0xb]
    // 0x8d26a4: DecompressPointer r1
    //     0x8d26a4: add             x1, x1, HEAP, lsl #32
    // 0x8d26a8: cmp             w1, NULL
    // 0x8d26ac: b.eq            #0x8d26f8
    // 0x8d26b0: LoadField: r1 = r0->field_1b
    //     0x8d26b0: ldur            w1, [x0, #0x1b]
    // 0x8d26b4: DecompressPointer r1
    //     0x8d26b4: add             x1, x1, HEAP, lsl #32
    // 0x8d26b8: cmp             w1, NULL
    // 0x8d26bc: b.ne            #0x8d26c8
    // 0x8d26c0: r0 = Null
    //     0x8d26c0: mov             x0, NULL
    // 0x8d26c4: b               #0x8d26cc
    // 0x8d26c8: r0 = currentState()
    //     0x8d26c8: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x8d26cc: cmp             w0, NULL
    // 0x8d26d0: b.ne            #0x8d26dc
    // 0x8d26d4: r0 = false
    //     0x8d26d4: add             x0, NULL, #0x30  ; false
    // 0x8d26d8: r0 = ReturnAsyncNotFuture()
    //     0x8d26d8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8d26dc: r16 = <Object?>
    //     0x8d26dc: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x8d26e0: stp             x0, x16, [SP]
    // 0x8d26e4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d26e4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d26e8: r0 = maybePop()
    //     0x8d26e8: bl              #0x8d2720  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x8d26ec: r0 = ReturnAsync()
    //     0x8d26ec: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8d26f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d26f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d26f4: b               #0x8d2694
    // 0x8d26f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d26f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Route<dynamic>? _onGenerateRoute(dynamic, RouteSettings) {
    // ** addr: 0x8dfe50, size: 0x3c
    // 0x8dfe50: EnterFrame
    //     0x8dfe50: stp             fp, lr, [SP, #-0x10]!
    //     0x8dfe54: mov             fp, SP
    // 0x8dfe58: ldr             x0, [fp, #0x18]
    // 0x8dfe5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8dfe5c: ldur            w1, [x0, #0x17]
    // 0x8dfe60: DecompressPointer r1
    //     0x8dfe60: add             x1, x1, HEAP, lsl #32
    // 0x8dfe64: CheckStackOverflow
    //     0x8dfe64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dfe68: cmp             SP, x16
    //     0x8dfe6c: b.ls            #0x8dfe84
    // 0x8dfe70: ldr             x2, [fp, #0x10]
    // 0x8dfe74: r0 = _onGenerateRoute()
    //     0x8dfe74: bl              #0x8dfebc  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_onGenerateRoute
    // 0x8dfe78: LeaveFrame
    //     0x8dfe78: mov             SP, fp
    //     0x8dfe7c: ldp             fp, lr, [SP], #0x10
    // 0x8dfe80: ret
    //     0x8dfe80: ret             
    // 0x8dfe84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dfe84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dfe88: b               #0x8dfe70
  }
  _ _onGenerateRoute(/* No info */) {
    // ** addr: 0x8dfebc, size: 0x16c
    // 0x8dfebc: EnterFrame
    //     0x8dfebc: stp             fp, lr, [SP, #-0x10]!
    //     0x8dfec0: mov             fp, SP
    // 0x8dfec4: AllocStack(0x38)
    //     0x8dfec4: sub             SP, SP, #0x38
    // 0x8dfec8: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8dfec8: stur            x1, [fp, #-0x10]
    //     0x8dfecc: stur            x2, [fp, #-0x18]
    // 0x8dfed0: CheckStackOverflow
    //     0x8dfed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dfed4: cmp             SP, x16
    //     0x8dfed8: b.ls            #0x8e0008
    // 0x8dfedc: r0 = LoadClassIdInstr(r2)
    //     0x8dfedc: ldur            x0, [x2, #-1]
    //     0x8dfee0: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfee4: cmp             x0, #0xa44
    // 0x8dfee8: b.eq            #0x8dff04
    // 0x8dfeec: cmp             x0, #0xa46
    // 0x8dfef0: b.ne            #0x8dff04
    // 0x8dfef4: LoadField: r0 = r2->field_6b
    //     0x8dfef4: ldur            w0, [x2, #0x6b]
    // 0x8dfef8: DecompressPointer r0
    //     0x8dfef8: add             x0, x0, HEAP, lsl #32
    // 0x8dfefc: mov             x3, x0
    // 0x8dff00: b               #0x8dff10
    // 0x8dff04: LoadField: r0 = r2->field_7
    //     0x8dff04: ldur            w0, [x2, #7]
    // 0x8dff08: DecompressPointer r0
    //     0x8dff08: add             x0, x0, HEAP, lsl #32
    // 0x8dff0c: mov             x3, x0
    // 0x8dff10: stur            x3, [fp, #-8]
    // 0x8dff14: r0 = LoadClassIdInstr(r3)
    //     0x8dff14: ldur            x0, [x3, #-1]
    //     0x8dff18: ubfx            x0, x0, #0xc, #0x14
    // 0x8dff1c: r16 = "/"
    //     0x8dff1c: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x8dff20: stp             x16, x3, [SP]
    // 0x8dff24: mov             lr, x0
    // 0x8dff28: ldr             lr, [x21, lr, lsl #3]
    // 0x8dff2c: blr             lr
    // 0x8dff30: tbnz            w0, #4, #0x8dff4c
    // 0x8dff34: ldur            x0, [fp, #-0x10]
    // 0x8dff38: LoadField: r1 = r0->field_b
    //     0x8dff38: ldur            w1, [x0, #0xb]
    // 0x8dff3c: DecompressPointer r1
    //     0x8dff3c: add             x1, x1, HEAP, lsl #32
    // 0x8dff40: cmp             w1, NULL
    // 0x8dff44: b.eq            #0x8e0010
    // 0x8dff48: b               #0x8dff50
    // 0x8dff4c: ldur            x0, [fp, #-0x10]
    // 0x8dff50: LoadField: r1 = r0->field_b
    //     0x8dff50: ldur            w1, [x0, #0xb]
    // 0x8dff54: DecompressPointer r1
    //     0x8dff54: add             x1, x1, HEAP, lsl #32
    // 0x8dff58: cmp             w1, NULL
    // 0x8dff5c: b.eq            #0x8e0014
    // 0x8dff60: ldur            x2, [fp, #-8]
    // 0x8dff64: r1 = _ConstMap len:0
    //     0x8dff64: add             x1, PP, #0x12, lsl #12  ; [pp+0x127c8] Map<String, (dynamic this, BuildContext) => Widget>(0)
    //     0x8dff68: ldr             x1, [x1, #0x7c8]
    // 0x8dff6c: r0 = []()
    //     0x8dff6c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8dff70: cmp             w0, NULL
    // 0x8dff74: b.eq            #0x8dffc4
    // 0x8dff78: ldur            x1, [fp, #-0x10]
    // 0x8dff7c: LoadField: r2 = r1->field_b
    //     0x8dff7c: ldur            w2, [x1, #0xb]
    // 0x8dff80: DecompressPointer r2
    //     0x8dff80: add             x2, x2, HEAP, lsl #32
    // 0x8dff84: cmp             w2, NULL
    // 0x8dff88: b.eq            #0x8e0018
    // 0x8dff8c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8dff8c: ldur            w1, [x2, #0x17]
    // 0x8dff90: DecompressPointer r1
    //     0x8dff90: add             x1, x1, HEAP, lsl #32
    // 0x8dff94: cmp             w1, NULL
    // 0x8dff98: b.eq            #0x8e001c
    // 0x8dff9c: stp             x1, NULL, [SP, #0x10]
    // 0x8dffa0: ldur            x16, [fp, #-0x18]
    // 0x8dffa4: stp             x0, x16, [SP]
    // 0x8dffa8: mov             x0, x1
    // 0x8dffac: ClosureCall
    //     0x8dffac: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    //     0x8dffb0: ldur            x2, [x0, #0x1f]
    //     0x8dffb4: blr             x2
    // 0x8dffb8: LeaveFrame
    //     0x8dffb8: mov             SP, fp
    //     0x8dffbc: ldp             fp, lr, [SP], #0x10
    // 0x8dffc0: ret
    //     0x8dffc0: ret             
    // 0x8dffc4: ldur            x1, [fp, #-0x10]
    // 0x8dffc8: LoadField: r0 = r1->field_b
    //     0x8dffc8: ldur            w0, [x1, #0xb]
    // 0x8dffcc: DecompressPointer r0
    //     0x8dffcc: add             x0, x0, HEAP, lsl #32
    // 0x8dffd0: cmp             w0, NULL
    // 0x8dffd4: b.eq            #0x8e0020
    // 0x8dffd8: LoadField: r1 = r0->field_f
    //     0x8dffd8: ldur            w1, [x0, #0xf]
    // 0x8dffdc: DecompressPointer r1
    //     0x8dffdc: add             x1, x1, HEAP, lsl #32
    // 0x8dffe0: cmp             w1, NULL
    // 0x8dffe4: b.eq            #0x8e0024
    // 0x8dffe8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8dffe8: ldur            w0, [x1, #0x17]
    // 0x8dffec: DecompressPointer r0
    //     0x8dffec: add             x0, x0, HEAP, lsl #32
    // 0x8dfff0: mov             x1, x0
    // 0x8dfff4: ldur            x2, [fp, #-0x18]
    // 0x8dfff8: r0 = generator()
    //     0x8dfff8: bl              #0x8e0064  ; [package:get/get_navigation/src/root/get_material_app.dart] GetMaterialApp::generator
    // 0x8dfffc: LeaveFrame
    //     0x8dfffc: mov             SP, fp
    //     0x8e0000: ldp             fp, lr, [SP], #0x10
    // 0x8e0004: ret
    //     0x8e0004: ret             
    // 0x8e0008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e000c: b               #0x8dfedc
    // 0x8e0010: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e0010: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8e0014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e0014: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8e0018: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e0018: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8e001c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8e001c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x8e0020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e0020: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8e0024: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8e0024: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didPushRouteInformation(/* No info */) async {
    // ** addr: 0x9ec484, size: 0x1f8
    // 0x9ec484: EnterFrame
    //     0x9ec484: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec488: mov             fp, SP
    // 0x9ec48c: AllocStack(0x40)
    //     0x9ec48c: sub             SP, SP, #0x40
    // 0x9ec490: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x9ec490: stur            NULL, [fp, #-8]
    //     0x9ec494: stur            x1, [fp, #-0x10]
    //     0x9ec498: stur            x2, [fp, #-0x18]
    // 0x9ec49c: CheckStackOverflow
    //     0x9ec49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec4a0: cmp             SP, x16
    //     0x9ec4a4: b.ls            #0x9ec670
    // 0x9ec4a8: InitAsync() -> Future<bool>
    //     0x9ec4a8: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0x9ec4ac: bl              #0x7f5e44  ; InitAsyncStub
    // 0x9ec4b0: ldur            x0, [fp, #-0x10]
    // 0x9ec4b4: LoadField: r1 = r0->field_b
    //     0x9ec4b4: ldur            w1, [x0, #0xb]
    // 0x9ec4b8: DecompressPointer r1
    //     0x9ec4b8: add             x1, x1, HEAP, lsl #32
    // 0x9ec4bc: cmp             w1, NULL
    // 0x9ec4c0: b.eq            #0x9ec678
    // 0x9ec4c4: LoadField: r1 = r0->field_1b
    //     0x9ec4c4: ldur            w1, [x0, #0x1b]
    // 0x9ec4c8: DecompressPointer r1
    //     0x9ec4c8: add             x1, x1, HEAP, lsl #32
    // 0x9ec4cc: cmp             w1, NULL
    // 0x9ec4d0: b.ne            #0x9ec4dc
    // 0x9ec4d4: r2 = Null
    //     0x9ec4d4: mov             x2, NULL
    // 0x9ec4d8: b               #0x9ec4e4
    // 0x9ec4dc: r0 = currentState()
    //     0x9ec4dc: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x9ec4e0: mov             x2, x0
    // 0x9ec4e4: stur            x2, [fp, #-0x20]
    // 0x9ec4e8: cmp             w2, NULL
    // 0x9ec4ec: b.ne            #0x9ec4f8
    // 0x9ec4f0: r0 = false
    //     0x9ec4f0: add             x0, NULL, #0x30  ; false
    // 0x9ec4f4: r0 = ReturnAsyncNotFuture()
    //     0x9ec4f4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x9ec4f8: ldur            x0, [fp, #-0x18]
    // 0x9ec4fc: LoadField: r3 = r0->field_7
    //     0x9ec4fc: ldur            w3, [x0, #7]
    // 0x9ec500: DecompressPointer r3
    //     0x9ec500: add             x3, x3, HEAP, lsl #32
    // 0x9ec504: stur            x3, [fp, #-0x10]
    // 0x9ec508: r0 = LoadClassIdInstr(r3)
    //     0x9ec508: ldur            x0, [x3, #-1]
    //     0x9ec50c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec510: mov             x1, x3
    // 0x9ec514: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x9ec514: sub             lr, x0, #0xfe0
    //     0x9ec518: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec51c: blr             lr
    // 0x9ec520: LoadField: r1 = r0->field_7
    //     0x9ec520: ldur            w1, [x0, #7]
    // 0x9ec524: cbnz            w1, #0x9ec530
    // 0x9ec528: r3 = "/"
    //     0x9ec528: ldr             x3, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x9ec52c: b               #0x9ec550
    // 0x9ec530: ldur            x2, [fp, #-0x10]
    // 0x9ec534: r0 = LoadClassIdInstr(r2)
    //     0x9ec534: ldur            x0, [x2, #-1]
    //     0x9ec538: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec53c: mov             x1, x2
    // 0x9ec540: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x9ec540: sub             lr, x0, #0xfe0
    //     0x9ec544: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec548: blr             lr
    // 0x9ec54c: mov             x3, x0
    // 0x9ec550: ldur            x2, [fp, #-0x10]
    // 0x9ec554: stur            x3, [fp, #-0x18]
    // 0x9ec558: r0 = LoadClassIdInstr(r2)
    //     0x9ec558: ldur            x0, [x2, #-1]
    //     0x9ec55c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec560: mov             x1, x2
    // 0x9ec564: r0 = GDT[cid_x0 + -0xf59]()
    //     0x9ec564: sub             lr, x0, #0xf59
    //     0x9ec568: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec56c: blr             lr
    // 0x9ec570: r1 = LoadClassIdInstr(r0)
    //     0x9ec570: ldur            x1, [x0, #-1]
    //     0x9ec574: ubfx            x1, x1, #0xc, #0x14
    // 0x9ec578: mov             x16, x0
    // 0x9ec57c: mov             x0, x1
    // 0x9ec580: mov             x1, x16
    // 0x9ec584: r0 = GDT[cid_x0 + 0x687]()
    //     0x9ec584: add             lr, x0, #0x687
    //     0x9ec588: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec58c: blr             lr
    // 0x9ec590: tbnz            w0, #4, #0x9ec59c
    // 0x9ec594: r3 = Null
    //     0x9ec594: mov             x3, NULL
    // 0x9ec598: b               #0x9ec5bc
    // 0x9ec59c: ldur            x2, [fp, #-0x10]
    // 0x9ec5a0: r0 = LoadClassIdInstr(r2)
    //     0x9ec5a0: ldur            x0, [x2, #-1]
    //     0x9ec5a4: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec5a8: mov             x1, x2
    // 0x9ec5ac: r0 = GDT[cid_x0 + -0xf59]()
    //     0x9ec5ac: sub             lr, x0, #0xf59
    //     0x9ec5b0: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec5b4: blr             lr
    // 0x9ec5b8: mov             x3, x0
    // 0x9ec5bc: ldur            x2, [fp, #-0x10]
    // 0x9ec5c0: stur            x3, [fp, #-0x28]
    // 0x9ec5c4: r0 = LoadClassIdInstr(r2)
    //     0x9ec5c4: ldur            x0, [x2, #-1]
    //     0x9ec5c8: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec5cc: mov             x1, x2
    // 0x9ec5d0: r0 = GDT[cid_x0 + -0xf8d]()
    //     0x9ec5d0: sub             lr, x0, #0xf8d
    //     0x9ec5d4: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec5d8: blr             lr
    // 0x9ec5dc: LoadField: r1 = r0->field_7
    //     0x9ec5dc: ldur            w1, [x0, #7]
    // 0x9ec5e0: cbnz            w1, #0x9ec5ec
    // 0x9ec5e4: r0 = Null
    //     0x9ec5e4: mov             x0, NULL
    // 0x9ec5e8: b               #0x9ec604
    // 0x9ec5ec: ldur            x1, [fp, #-0x10]
    // 0x9ec5f0: r0 = LoadClassIdInstr(r1)
    //     0x9ec5f0: ldur            x0, [x1, #-1]
    //     0x9ec5f4: ubfx            x0, x0, #0xc, #0x14
    // 0x9ec5f8: r0 = GDT[cid_x0 + -0xf8d]()
    //     0x9ec5f8: sub             lr, x0, #0xf8d
    //     0x9ec5fc: ldr             lr, [x21, lr, lsl #3]
    //     0x9ec600: blr             lr
    // 0x9ec604: ldur            x16, [fp, #-0x18]
    // 0x9ec608: ldur            lr, [fp, #-0x28]
    // 0x9ec60c: stp             lr, x16, [SP, #8]
    // 0x9ec610: str             x0, [SP]
    // 0x9ec614: r1 = Null
    //     0x9ec614: mov             x1, NULL
    // 0x9ec618: r4 = const [0, 0x4, 0x3, 0x1, fragment, 0x3, path, 0x1, queryParameters, 0x2, null]
    //     0x9ec618: add             x4, PP, #0xe, lsl #12  ; [pp+0xe1c8] List(11) [0, 0x4, 0x3, 0x1, "fragment", 0x3, "path", 0x1, "queryParameters", 0x2, Null]
    //     0x9ec61c: ldr             x4, [x4, #0x1c8]
    // 0x9ec620: r0 = _Uri()
    //     0x9ec620: bl              #0x7e2fd8  ; [dart:core] _Uri::_Uri
    // 0x9ec624: mov             x1, x0
    // 0x9ec628: LoadField: r0 = r1->field_23
    //     0x9ec628: ldur            w0, [x1, #0x23]
    // 0x9ec62c: DecompressPointer r0
    //     0x9ec62c: add             x0, x0, HEAP, lsl #32
    // 0x9ec630: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec634: cmp             w0, w16
    // 0x9ec638: b.ne            #0x9ec648
    // 0x9ec63c: r2 = _text
    //     0x9ec63c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe1d0] Field <_Uri@0150898._text@0150898>: late final (offset: 0x24)
    //     0x9ec640: ldr             x2, [x2, #0x1d0]
    // 0x9ec644: r0 = InitLateFinalInstanceField()
    //     0x9ec644: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x9ec648: mov             x1, x0
    // 0x9ec64c: r0 = decodeComponent()
    //     0x9ec64c: bl              #0x9ec868  ; [dart:core] Uri::decodeComponent
    // 0x9ec650: r16 = <Object?>
    //     0x9ec650: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x9ec654: ldur            lr, [fp, #-0x20]
    // 0x9ec658: stp             lr, x16, [SP, #8]
    // 0x9ec65c: str             x0, [SP]
    // 0x9ec660: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9ec660: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9ec664: r0 = pushNamed()
    //     0x9ec664: bl              #0x9ec67c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pushNamed
    // 0x9ec668: r0 = true
    //     0x9ec668: add             x0, NULL, #0x20  ; true
    // 0x9ec66c: r0 = ReturnAsyncNotFuture()
    //     0x9ec66c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x9ec670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec670: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec674: b               #0x9ec4a8
    // 0x9ec678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ec678: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xd5c534, size: 0x660
    // 0xd5c534: EnterFrame
    //     0xd5c534: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c538: mov             fp, SP
    // 0xd5c53c: AllocStack(0x48)
    //     0xd5c53c: sub             SP, SP, #0x48
    // 0xd5c540: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd5c540: stur            x1, [fp, #-8]
    //     0xd5c544: stur            x2, [fp, #-0x10]
    // 0xd5c548: CheckStackOverflow
    //     0xd5c548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5c54c: cmp             SP, x16
    //     0xd5c550: b.ls            #0xd5cb78
    // 0xd5c554: r1 = 4
    //     0xd5c554: mov             x1, #4
    // 0xd5c558: r0 = AllocateContext()
    //     0xd5c558: bl              #0x13de838  ; AllocateContextStub
    // 0xd5c55c: mov             x2, x0
    // 0xd5c560: ldur            x0, [fp, #-8]
    // 0xd5c564: stur            x2, [fp, #-0x18]
    // 0xd5c568: StoreField: r2->field_f = r0
    //     0xd5c568: stur            w0, [x2, #0xf]
    // 0xd5c56c: LoadField: r1 = r0->field_b
    //     0xd5c56c: ldur            w1, [x0, #0xb]
    // 0xd5c570: DecompressPointer r1
    //     0xd5c570: add             x1, x1, HEAP, lsl #32
    // 0xd5c574: cmp             w1, NULL
    // 0xd5c578: b.eq            #0xd5cb80
    // 0xd5c57c: mov             x1, x0
    // 0xd5c580: r0 = selectionEnabled()
    //     0xd5c580: bl              #0x12a39c8  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::selectionEnabled
    // 0xd5c584: tbnz            w0, #4, #0xd5c6c8
    // 0xd5c588: ldur            x0, [fp, #-8]
    // 0xd5c58c: ldur            x2, [fp, #-0x18]
    // 0xd5c590: LoadField: r3 = r0->field_1b
    //     0xd5c590: ldur            w3, [x0, #0x1b]
    // 0xd5c594: DecompressPointer r3
    //     0xd5c594: add             x3, x3, HEAP, lsl #32
    // 0xd5c598: mov             x1, x0
    // 0xd5c59c: stur            x3, [fp, #-0x20]
    // 0xd5c5a0: r0 = _initialRouteName()
    //     0xd5c5a0: bl              #0xd5cddc  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_initialRouteName
    // 0xd5c5a4: ldur            x2, [fp, #-8]
    // 0xd5c5a8: stur            x0, [fp, #-0x30]
    // 0xd5c5ac: LoadField: r1 = r2->field_b
    //     0xd5c5ac: ldur            w1, [x2, #0xb]
    // 0xd5c5b0: DecompressPointer r1
    //     0xd5c5b0: add             x1, x1, HEAP, lsl #32
    // 0xd5c5b4: cmp             w1, NULL
    // 0xd5c5b8: b.eq            #0xd5cb84
    // 0xd5c5bc: LoadField: r3 = r1->field_37
    //     0xd5c5bc: ldur            w3, [x1, #0x37]
    // 0xd5c5c0: DecompressPointer r3
    //     0xd5c5c0: add             x3, x3, HEAP, lsl #32
    // 0xd5c5c4: stur            x3, [fp, #-0x28]
    // 0xd5c5c8: r0 = Navigator()
    //     0xd5c5c8: bl              #0xd5cdd0  ; AllocateNavigatorStub -> Navigator (size=0x44)
    // 0xd5c5cc: mov             x3, x0
    // 0xd5c5d0: r0 = const []
    //     0xd5c5d0: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3348] List<Page>(0)
    //     0xd5c5d4: ldr             x0, [x0, #0x348]
    // 0xd5c5d8: stur            x3, [fp, #-0x38]
    // 0xd5c5dc: StoreField: r3->field_b = r0
    //     0xd5c5dc: stur            w0, [x3, #0xb]
    // 0xd5c5e0: ldur            x0, [fp, #-0x30]
    // 0xd5c5e4: StoreField: r3->field_1b = r0
    //     0xd5c5e4: stur            w0, [x3, #0x1b]
    // 0xd5c5e8: ldur            x2, [fp, #-0x18]
    // 0xd5c5ec: r1 = Function '<anonymous closure>':.
    //     0xd5c5ec: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3350] AnonymousClosure: (0xd5e5e4), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::build (0xd5c534)
    //     0xd5c5f0: ldr             x1, [x1, #0x350]
    // 0xd5c5f4: r0 = AllocateClosure()
    //     0xd5c5f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c5f8: mov             x1, x0
    // 0xd5c5fc: ldur            x0, [fp, #-0x38]
    // 0xd5c600: StoreField: r0->field_33 = r1
    //     0xd5c600: stur            w1, [x0, #0x33]
    // 0xd5c604: ldur            x2, [fp, #-8]
    // 0xd5c608: r1 = Function '_onGenerateRoute@150236006':.
    //     0xd5c608: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3358] AnonymousClosure: (0x8dfe50), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::_onGenerateRoute (0x8dfebc)
    //     0xd5c60c: ldr             x1, [x1, #0x358]
    // 0xd5c610: r0 = AllocateClosure()
    //     0xd5c610: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c614: mov             x1, x0
    // 0xd5c618: ldur            x0, [fp, #-0x38]
    // 0xd5c61c: StoreField: r0->field_1f = r1
    //     0xd5c61c: stur            w1, [x0, #0x1f]
    // 0xd5c620: r1 = Instance_DefaultTransitionDelegate
    //     0xd5c620: add             x1, PP, #0x80, lsl #12  ; [pp+0x80af0] Obj!DefaultTransitionDelegate@128a171
    //     0xd5c624: ldr             x1, [x1, #0xaf0]
    // 0xd5c628: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5c628: stur            w1, [x0, #0x17]
    // 0xd5c62c: r1 = true
    //     0xd5c62c: add             x1, NULL, #0x20  ; true
    // 0xd5c630: StoreField: r0->field_37 = r1
    //     0xd5c630: stur            w1, [x0, #0x37]
    // 0xd5c634: r2 = Instance_Clip
    //     0xd5c634: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd5c638: ldr             x2, [x2, #0x840]
    // 0xd5c63c: StoreField: r0->field_3b = r2
    //     0xd5c63c: stur            w2, [x0, #0x3b]
    // 0xd5c640: ldur            x2, [fp, #-0x28]
    // 0xd5c644: StoreField: r0->field_23 = r2
    //     0xd5c644: stur            w2, [x0, #0x23]
    // 0xd5c648: StoreField: r0->field_3f = r1
    //     0xd5c648: stur            w1, [x0, #0x3f]
    // 0xd5c64c: r2 = "nav"
    //     0xd5c64c: add             x2, PP, #0x7e, lsl #12  ; [pp+0x7e898] "nav"
    //     0xd5c650: ldr             x2, [x2, #0x898]
    // 0xd5c654: StoreField: r0->field_27 = r2
    //     0xd5c654: stur            w2, [x0, #0x27]
    // 0xd5c658: r2 = Instance_TraversalEdgeBehavior
    //     0xd5c658: add             x2, PP, #0x80, lsl #12  ; [pp+0x80b00] Obj!TraversalEdgeBehavior@12c3141
    //     0xd5c65c: ldr             x2, [x2, #0xb00]
    // 0xd5c660: StoreField: r0->field_2b = r2
    //     0xd5c660: stur            w2, [x0, #0x2b]
    // 0xd5c664: r2 = Instance_TraversalEdgeBehavior
    //     0xd5c664: ldr             x2, [PP, #0x2090]  ; [pp+0x2090] Obj!TraversalEdgeBehavior@12c3101
    // 0xd5c668: StoreField: r0->field_2f = r2
    //     0xd5c668: stur            w2, [x0, #0x2f]
    // 0xd5c66c: ldur            x2, [fp, #-0x20]
    // 0xd5c670: StoreField: r0->field_7 = r2
    //     0xd5c670: stur            w2, [x0, #7]
    // 0xd5c674: r0 = FocusScope()
    //     0xd5c674: bl              #0xd1a86c  ; AllocateFocusScopeStub -> FocusScope (size=0x40)
    // 0xd5c678: mov             x1, x0
    // 0xd5c67c: ldur            x0, [fp, #-0x38]
    // 0xd5c680: StoreField: r1->field_f = r0
    //     0xd5c680: stur            w0, [x1, #0xf]
    // 0xd5c684: r3 = true
    //     0xd5c684: add             x3, NULL, #0x20  ; true
    // 0xd5c688: ArrayStore: r1[0] = r3  ; List_4
    //     0xd5c688: stur            w3, [x1, #0x17]
    // 0xd5c68c: StoreField: r1->field_37 = r3
    //     0xd5c68c: stur            w3, [x1, #0x37]
    // 0xd5c690: r0 = "Navigator Scope"
    //     0xd5c690: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3360] "Navigator Scope"
    //     0xd5c694: ldr             x0, [x0, #0x360]
    // 0xd5c698: StoreField: r1->field_3b = r0
    //     0xd5c698: stur            w0, [x1, #0x3b]
    // 0xd5c69c: mov             x0, x1
    // 0xd5c6a0: ldur            x4, [fp, #-0x18]
    // 0xd5c6a4: StoreField: r4->field_13 = r0
    //     0xd5c6a4: stur            w0, [x4, #0x13]
    //     0xd5c6a8: ldurb           w16, [x4, #-1]
    //     0xd5c6ac: ldurb           w17, [x0, #-1]
    //     0xd5c6b0: and             x16, x17, x16, lsr #2
    //     0xd5c6b4: tst             x16, HEAP, lsr #32
    //     0xd5c6b8: b.eq            #0xd5c6c0
    //     0xd5c6bc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd5c6c0: ldur            x0, [fp, #-8]
    // 0xd5c6c4: b               #0xd5c6e4
    // 0xd5c6c8: ldur            x0, [fp, #-8]
    // 0xd5c6cc: ldur            x4, [fp, #-0x18]
    // 0xd5c6d0: r3 = true
    //     0xd5c6d0: add             x3, NULL, #0x20  ; true
    // 0xd5c6d4: LoadField: r1 = r0->field_b
    //     0xd5c6d4: ldur            w1, [x0, #0xb]
    // 0xd5c6d8: DecompressPointer r1
    //     0xd5c6d8: add             x1, x1, HEAP, lsl #32
    // 0xd5c6dc: cmp             w1, NULL
    // 0xd5c6e0: b.eq            #0xd5cb88
    // 0xd5c6e4: ArrayStore: r4[0] = rNULL  ; List_4
    //     0xd5c6e4: stur            NULL, [x4, #0x17]
    // 0xd5c6e8: mov             x2, x4
    // 0xd5c6ec: r1 = Function '<anonymous closure>':.
    //     0xd5c6ec: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3368] AnonymousClosure: (0xd5dffc), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::build (0xd5c534)
    //     0xd5c6f0: ldr             x1, [x1, #0x368]
    // 0xd5c6f4: r0 = AllocateClosure()
    //     0xd5c6f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c6f8: stur            x0, [fp, #-0x20]
    // 0xd5c6fc: r0 = Builder()
    //     0xd5c6fc: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd5c700: mov             x1, x0
    // 0xd5c704: ldur            x0, [fp, #-0x20]
    // 0xd5c708: StoreField: r1->field_b = r0
    //     0xd5c708: stur            w0, [x1, #0xb]
    // 0xd5c70c: mov             x0, x1
    // 0xd5c710: ldur            x2, [fp, #-0x18]
    // 0xd5c714: ArrayStore: r2[0] = r0  ; List_4
    //     0xd5c714: stur            w0, [x2, #0x17]
    //     0xd5c718: ldurb           w16, [x2, #-1]
    //     0xd5c71c: ldurb           w17, [x0, #-1]
    //     0xd5c720: and             x16, x17, x16, lsr #2
    //     0xd5c724: tst             x16, HEAP, lsr #32
    //     0xd5c728: b.eq            #0xd5c730
    //     0xd5c72c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5c730: r0 = LoadStaticField(0x878)
    //     0xd5c730: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd5c734: ldr             x0, [x0, #0x10f0]
    // 0xd5c738: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5c73c: cmp             w0, w16
    // 0xd5c740: b.ne            #0xd5c74c
    // 0xd5c744: r2 = isWindowingEnabled
    //     0xd5c744: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0xd5c748: r0 = InitLateStaticField()
    //     0xd5c748: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd5c74c: tbnz            w0, #4, #0xd5c798
    // 0xd5c750: ldur            x2, [fp, #-0x18]
    // 0xd5c754: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd5c754: ldur            w0, [x2, #0x17]
    // 0xd5c758: DecompressPointer r0
    //     0xd5c758: add             x0, x0, HEAP, lsl #32
    // 0xd5c75c: stur            x0, [fp, #-0x20]
    // 0xd5c760: r0 = WindowManager()
    //     0xd5c760: bl              #0xd5cda0  ; AllocateWindowManagerStub -> WindowManager (size=0x10)
    // 0xd5c764: mov             x1, x0
    // 0xd5c768: ldur            x0, [fp, #-0x20]
    // 0xd5c76c: StoreField: r1->field_b = r0
    //     0xd5c76c: stur            w0, [x1, #0xb]
    // 0xd5c770: mov             x0, x1
    // 0xd5c774: ldur            x2, [fp, #-0x18]
    // 0xd5c778: ArrayStore: r2[0] = r0  ; List_4
    //     0xd5c778: stur            w0, [x2, #0x17]
    //     0xd5c77c: ldurb           w16, [x2, #-1]
    //     0xd5c780: ldurb           w17, [x0, #-1]
    //     0xd5c784: and             x16, x17, x16, lsr #2
    //     0xd5c788: tst             x16, HEAP, lsr #32
    //     0xd5c78c: b.eq            #0xd5c794
    //     0xd5c790: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5c794: b               #0xd5c79c
    // 0xd5c798: ldur            x2, [fp, #-0x18]
    // 0xd5c79c: ldur            x1, [fp, #-8]
    // 0xd5c7a0: LoadField: r0 = r1->field_b
    //     0xd5c7a0: ldur            w0, [x1, #0xb]
    // 0xd5c7a4: DecompressPointer r0
    //     0xd5c7a4: add             x0, x0, HEAP, lsl #32
    // 0xd5c7a8: stur            x0, [fp, #-0x28]
    // 0xd5c7ac: cmp             w0, NULL
    // 0xd5c7b0: b.eq            #0xd5cb8c
    // 0xd5c7b4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd5c7b4: ldur            w3, [x2, #0x17]
    // 0xd5c7b8: DecompressPointer r3
    //     0xd5c7b8: add             x3, x3, HEAP, lsl #32
    // 0xd5c7bc: stur            x3, [fp, #-0x20]
    // 0xd5c7c0: r0 = DefaultTextStyle()
    //     0xd5c7c0: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xd5c7c4: mov             x1, x0
    // 0xd5c7c8: r0 = Instance_TextStyle
    //     0xd5c7c8: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8ca20] Obj!TextStyle@12b09a1
    //     0xd5c7cc: ldr             x0, [x0, #0xa20]
    // 0xd5c7d0: stur            x1, [fp, #-0x30]
    // 0xd5c7d4: StoreField: r1->field_f = r0
    //     0xd5c7d4: stur            w0, [x1, #0xf]
    // 0xd5c7d8: r2 = true
    //     0xd5c7d8: add             x2, NULL, #0x20  ; true
    // 0xd5c7dc: ArrayStore: r1[0] = r2  ; List_4
    //     0xd5c7dc: stur            w2, [x1, #0x17]
    // 0xd5c7e0: r0 = Instance_TextOverflow
    //     0xd5c7e0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xd5c7e4: ldr             x0, [x0, #0x108]
    // 0xd5c7e8: StoreField: r1->field_1b = r0
    //     0xd5c7e8: stur            w0, [x1, #0x1b]
    // 0xd5c7ec: r0 = Instance_TextWidthBasis
    //     0xd5c7ec: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xd5c7f0: ldr             x0, [x0, #0x110]
    // 0xd5c7f4: StoreField: r1->field_23 = r0
    //     0xd5c7f4: stur            w0, [x1, #0x23]
    // 0xd5c7f8: ldur            x0, [fp, #-0x20]
    // 0xd5c7fc: StoreField: r1->field_b = r0
    //     0xd5c7fc: stur            w0, [x1, #0xb]
    // 0xd5c800: mov             x0, x1
    // 0xd5c804: ldur            x3, [fp, #-0x18]
    // 0xd5c808: ArrayStore: r3[0] = r0  ; List_4
    //     0xd5c808: stur            w0, [x3, #0x17]
    //     0xd5c80c: ldurb           w16, [x3, #-1]
    //     0xd5c810: ldurb           w17, [x0, #-1]
    //     0xd5c814: and             x16, x17, x16, lsr #2
    //     0xd5c818: tst             x16, HEAP, lsr #32
    //     0xd5c81c: b.eq            #0xd5c824
    //     0xd5c820: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd5c824: r0 = Focus()
    //     0xd5c824: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xd5c828: mov             x3, x0
    // 0xd5c82c: ldur            x0, [fp, #-0x30]
    // 0xd5c830: stur            x3, [fp, #-0x20]
    // 0xd5c834: StoreField: r3->field_f = r0
    //     0xd5c834: stur            w0, [x3, #0xf]
    // 0xd5c838: r0 = false
    //     0xd5c838: add             x0, NULL, #0x30  ; false
    // 0xd5c83c: ArrayStore: r3[0] = r0  ; List_4
    //     0xd5c83c: stur            w0, [x3, #0x17]
    // 0xd5c840: r4 = true
    //     0xd5c840: add             x4, NULL, #0x20  ; true
    // 0xd5c844: StoreField: r3->field_37 = r4
    //     0xd5c844: stur            w4, [x3, #0x37]
    // 0xd5c848: r1 = Function '<anonymous closure>':.
    //     0xd5c848: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3370] AnonymousClosure: (0xd5ddd8), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::build (0xd5c534)
    //     0xd5c84c: ldr             x1, [x1, #0x370]
    // 0xd5c850: r2 = Null
    //     0xd5c850: mov             x2, NULL
    // 0xd5c854: r0 = AllocateClosure()
    //     0xd5c854: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c858: mov             x1, x0
    // 0xd5c85c: ldur            x0, [fp, #-0x20]
    // 0xd5c860: StoreField: r0->field_1f = r1
    //     0xd5c860: stur            w1, [x0, #0x1f]
    // 0xd5c864: r2 = false
    //     0xd5c864: add             x2, NULL, #0x30  ; false
    // 0xd5c868: StoreField: r0->field_27 = r2
    //     0xd5c868: stur            w2, [x0, #0x27]
    // 0xd5c86c: ldur            x3, [fp, #-0x18]
    // 0xd5c870: ArrayStore: r3[0] = r0  ; List_4
    //     0xd5c870: stur            w0, [x3, #0x17]
    //     0xd5c874: ldurb           w16, [x3, #-1]
    //     0xd5c878: ldurb           w17, [x0, #-1]
    //     0xd5c87c: and             x16, x17, x16, lsr #2
    //     0xd5c880: tst             x16, HEAP, lsr #32
    //     0xd5c884: b.eq            #0xd5c88c
    //     0xd5c888: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd5c88c: StoreField: r3->field_1b = rNULL
    //     0xd5c88c: stur            NULL, [x3, #0x1b]
    // 0xd5c890: ldur            x0, [fp, #-0x28]
    // 0xd5c894: LoadField: r4 = r0->field_3f
    //     0xd5c894: ldur            w4, [x0, #0x3f]
    // 0xd5c898: DecompressPointer r4
    //     0xd5c898: add             x4, x4, HEAP, lsl #32
    // 0xd5c89c: stur            x4, [fp, #-0x20]
    // 0xd5c8a0: LoadField: r1 = r0->field_4b
    //     0xd5c8a0: ldur            w1, [x0, #0x4b]
    // 0xd5c8a4: DecompressPointer r1
    //     0xd5c8a4: add             x1, x1, HEAP, lsl #32
    // 0xd5c8a8: r0 = LoadClassIdInstr(r1)
    //     0xd5c8a8: ldur            x0, [x1, #-1]
    //     0xd5c8ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd5c8b0: d0 = 1.000000
    //     0xd5c8b0: fmov            d0, #1.00000000
    // 0xd5c8b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd5c8b4: sub             lr, x0, #1, lsl #12
    //     0xd5c8b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd5c8bc: blr             lr
    // 0xd5c8c0: ldur            x2, [fp, #-0x18]
    // 0xd5c8c4: stur            x0, [fp, #-0x30]
    // 0xd5c8c8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd5c8c8: ldur            w1, [x2, #0x17]
    // 0xd5c8cc: DecompressPointer r1
    //     0xd5c8cc: add             x1, x1, HEAP, lsl #32
    // 0xd5c8d0: stur            x1, [fp, #-0x28]
    // 0xd5c8d4: r0 = Title()
    //     0xd5c8d4: bl              #0xd5cd70  ; AllocateTitleStub -> Title (size=0x18)
    // 0xd5c8d8: mov             x1, x0
    // 0xd5c8dc: ldur            x0, [fp, #-0x20]
    // 0xd5c8e0: StoreField: r1->field_b = r0
    //     0xd5c8e0: stur            w0, [x1, #0xb]
    // 0xd5c8e4: ldur            x0, [fp, #-0x30]
    // 0xd5c8e8: StoreField: r1->field_f = r0
    //     0xd5c8e8: stur            w0, [x1, #0xf]
    // 0xd5c8ec: ldur            x0, [fp, #-0x28]
    // 0xd5c8f0: StoreField: r1->field_13 = r0
    //     0xd5c8f0: stur            w0, [x1, #0x13]
    // 0xd5c8f4: mov             x0, x1
    // 0xd5c8f8: ldur            x2, [fp, #-0x18]
    // 0xd5c8fc: StoreField: r2->field_1b = r0
    //     0xd5c8fc: stur            w0, [x2, #0x1b]
    //     0xd5c900: ldurb           w16, [x2, #-1]
    //     0xd5c904: ldurb           w17, [x0, #-1]
    //     0xd5c908: and             x16, x17, x16, lsr #2
    //     0xd5c90c: tst             x16, HEAP, lsr #32
    //     0xd5c910: b.eq            #0xd5c918
    //     0xd5c914: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5c918: ldur            x1, [fp, #-8]
    // 0xd5c91c: LoadField: r0 = r1->field_b
    //     0xd5c91c: ldur            w0, [x1, #0xb]
    // 0xd5c920: DecompressPointer r0
    //     0xd5c920: add             x0, x0, HEAP, lsl #32
    // 0xd5c924: cmp             w0, NULL
    // 0xd5c928: b.eq            #0xd5cb90
    // 0xd5c92c: r0 = LoadStaticField(0x7cc)
    //     0xd5c92c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd5c930: ldr             x0, [x0, #0xf98]
    // 0xd5c934: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5c938: cmp             w0, w16
    // 0xd5c93c: b.ne            #0xd5c94c
    // 0xd5c940: r2 = defaultActions
    //     0xd5c940: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3378] Field <WidgetsApp.defaultActions>: static late (offset: 0x7cc)
    //     0xd5c944: ldr             x2, [x2, #0x378]
    // 0xd5c948: r0 = InitLateStaticField()
    //     0xd5c948: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd5c94c: mov             x2, x0
    // 0xd5c950: r1 = <Type, Action<Intent>>
    //     0xd5c950: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xd5c954: ldr             x1, [x1, #0xb80]
    // 0xd5c958: r0 = LinkedHashMap.of()
    //     0xd5c958: bl              #0x833524  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0xd5c95c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5c95c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5c960: ldr             x1, [x1, #0x7a0]
    // 0xd5c964: stur            x0, [fp, #-0x20]
    // 0xd5c968: r0 = ObserverList()
    //     0xd5c968: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5c96c: mov             x3, x0
    // 0xd5c970: r0 = false
    //     0xd5c970: add             x0, NULL, #0x30  ; false
    // 0xd5c974: stur            x3, [fp, #-0x28]
    // 0xd5c978: StoreField: r3->field_f = r0
    //     0xd5c978: stur            w0, [x3, #0xf]
    // 0xd5c97c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5c980: StoreField: r3->field_13 = r0
    //     0xd5c980: stur            w0, [x3, #0x13]
    // 0xd5c984: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5c984: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5c988: ldr             x1, [x1, #0x7a0]
    // 0xd5c98c: r2 = 0
    //     0xd5c98c: mov             x2, #0
    // 0xd5c990: r0 = _GrowableList()
    //     0xd5c990: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5c994: ldur            x2, [fp, #-0x28]
    // 0xd5c998: StoreField: r2->field_b = r0
    //     0xd5c998: stur            w0, [x2, #0xb]
    //     0xd5c99c: ldurb           w16, [x2, #-1]
    //     0xd5c9a0: ldurb           w17, [x0, #-1]
    //     0xd5c9a4: and             x16, x17, x16, lsr #2
    //     0xd5c9a8: tst             x16, HEAP, lsr #32
    //     0xd5c9ac: b.eq            #0xd5c9b4
    //     0xd5c9b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5c9b4: r1 = <ScrollIntent>
    //     0xd5c9b4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3118] TypeArguments: <ScrollIntent>
    //     0xd5c9b8: ldr             x1, [x1, #0x118]
    // 0xd5c9bc: r0 = ScrollAction()
    //     0xd5c9bc: bl              #0xd5cd64  ; AllocateScrollActionStub -> ScrollAction (size=0x14)
    // 0xd5c9c0: mov             x1, x0
    // 0xd5c9c4: ldur            x0, [fp, #-0x28]
    // 0xd5c9c8: StoreField: r1->field_b = r0
    //     0xd5c9c8: stur            w0, [x1, #0xb]
    // 0xd5c9cc: ldur            x2, [fp, #-0x10]
    // 0xd5c9d0: r0 = _makeOverridableAction()
    //     0xd5c9d0: bl              #0xb5cc84  ; [package:flutter/src/widgets/actions.dart] ContextAction::_makeOverridableAction
    // 0xd5c9d4: ldur            x1, [fp, #-0x20]
    // 0xd5c9d8: mov             x3, x0
    // 0xd5c9dc: r2 = ScrollIntent
    //     0xd5c9dc: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3110] Type: ScrollIntent
    //     0xd5c9e0: ldr             x2, [x2, #0x110]
    // 0xd5c9e4: r0 = []=()
    //     0xd5c9e4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd5c9e8: r16 = <FocusScopeNode, _DirectionalPolicyData>
    //     0xd5c9e8: ldr             x16, [PP, #0x5c58]  ; [pp+0x5c58] TypeArguments: <FocusScopeNode, _DirectionalPolicyData>
    // 0xd5c9ec: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xd5c9f0: stp             lr, x16, [SP]
    // 0xd5c9f4: r0 = Map._fromLiteral()
    //     0xd5c9f4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd5c9f8: stur            x0, [fp, #-0x10]
    // 0xd5c9fc: r0 = ReadingOrderTraversalPolicy()
    //     0xd5c9fc: bl              #0x84071c  ; AllocateReadingOrderTraversalPolicyStub -> ReadingOrderTraversalPolicy (size=0x10)
    // 0xd5ca00: mov             x2, x0
    // 0xd5ca04: ldur            x0, [fp, #-0x10]
    // 0xd5ca08: stur            x2, [fp, #-0x28]
    // 0xd5ca0c: StoreField: r2->field_b = r0
    //     0xd5ca0c: stur            w0, [x2, #0xb]
    // 0xd5ca10: r0 = Closure: (FocusNode, {ScrollPositionAlignmentPolicy? alignmentPolicy, double? alignment, Duration? duration, Curve? curve}) => void from Function 'defaultTraversalRequestFocusCallback': static.
    //     0xd5ca10: ldr             x0, [PP, #0x5c60]  ; [pp+0x5c60] Closure: (FocusNode, {ScrollPositionAlignmentPolicy? alignmentPolicy, double? alignment, Duration? duration, Curve? curve}) => void from Function 'defaultTraversalRequestFocusCallback': static. (0x7f2ada727728)
    // 0xd5ca14: StoreField: r2->field_7 = r0
    //     0xd5ca14: stur            w0, [x2, #7]
    // 0xd5ca18: ldur            x1, [fp, #-8]
    // 0xd5ca1c: LoadField: r0 = r1->field_1f
    //     0xd5ca1c: ldur            w0, [x1, #0x1f]
    // 0xd5ca20: DecompressPointer r0
    //     0xd5ca20: add             x0, x0, HEAP, lsl #32
    // 0xd5ca24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5ca28: cmp             w0, w16
    // 0xd5ca2c: b.ne            #0xd5ca3c
    // 0xd5ca30: r2 = _localizationsResolver
    //     0xd5ca30: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3380] Field <_WidgetsAppState@150236006._localizationsResolver@150236006>: late final (offset: 0x20)
    //     0xd5ca34: ldr             x2, [x2, #0x380]
    // 0xd5ca38: r0 = InitLateFinalInstanceField()
    //     0xd5ca38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd5ca3c: ldur            x2, [fp, #-0x18]
    // 0xd5ca40: r1 = Function '<anonymous closure>':.
    //     0xd5ca40: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3388] AnonymousClosure: (0xd5d194), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::build (0xd5c534)
    //     0xd5ca44: ldr             x1, [x1, #0x388]
    // 0xd5ca48: stur            x0, [fp, #-0x10]
    // 0xd5ca4c: r0 = AllocateClosure()
    //     0xd5ca4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5ca50: stur            x0, [fp, #-0x18]
    // 0xd5ca54: r0 = ListenableBuilder()
    //     0xd5ca54: bl              #0xd5cd58  ; AllocateListenableBuilderStub -> ListenableBuilder (size=0x18)
    // 0xd5ca58: mov             x1, x0
    // 0xd5ca5c: ldur            x0, [fp, #-0x18]
    // 0xd5ca60: stur            x1, [fp, #-0x30]
    // 0xd5ca64: StoreField: r1->field_f = r0
    //     0xd5ca64: stur            w0, [x1, #0xf]
    // 0xd5ca68: ldur            x0, [fp, #-0x10]
    // 0xd5ca6c: StoreField: r1->field_b = r0
    //     0xd5ca6c: stur            w0, [x1, #0xb]
    // 0xd5ca70: r0 = ShortcutRegistrar()
    //     0xd5ca70: bl              #0xd5cd28  ; AllocateShortcutRegistrarStub -> ShortcutRegistrar (size=0x10)
    // 0xd5ca74: mov             x1, x0
    // 0xd5ca78: ldur            x0, [fp, #-0x30]
    // 0xd5ca7c: stur            x1, [fp, #-0x10]
    // 0xd5ca80: StoreField: r1->field_b = r0
    //     0xd5ca80: stur            w0, [x1, #0xb]
    // 0xd5ca84: r0 = TapRegionSurface()
    //     0xd5ca84: bl              #0xd5cd1c  ; AllocateTapRegionSurfaceStub -> TapRegionSurface (size=0x10)
    // 0xd5ca88: mov             x1, x0
    // 0xd5ca8c: ldur            x0, [fp, #-0x10]
    // 0xd5ca90: stur            x1, [fp, #-0x18]
    // 0xd5ca94: StoreField: r1->field_b = r0
    //     0xd5ca94: stur            w0, [x1, #0xb]
    // 0xd5ca98: r0 = FocusTraversalGroup()
    //     0xd5ca98: bl              #0xd5cd10  ; AllocateFocusTraversalGroupStub -> FocusTraversalGroup (size=0x20)
    // 0xd5ca9c: mov             x1, x0
    // 0xd5caa0: ldur            x2, [fp, #-0x18]
    // 0xd5caa4: ldur            x3, [fp, #-0x28]
    // 0xd5caa8: stur            x0, [fp, #-0x10]
    // 0xd5caac: r0 = FocusTraversalGroup()
    //     0xd5caac: bl              #0xd5cc4c  ; [package:flutter/src/widgets/focus_traversal.dart] FocusTraversalGroup::FocusTraversalGroup
    // 0xd5cab0: r0 = Actions()
    //     0xd5cab0: bl              #0xd1c8a8  ; AllocateActionsStub -> Actions (size=0x18)
    // 0xd5cab4: mov             x1, x0
    // 0xd5cab8: ldur            x0, [fp, #-0x20]
    // 0xd5cabc: stur            x1, [fp, #-0x18]
    // 0xd5cac0: StoreField: r1->field_f = r0
    //     0xd5cac0: stur            w0, [x1, #0xf]
    // 0xd5cac4: ldur            x0, [fp, #-0x10]
    // 0xd5cac8: StoreField: r1->field_13 = r0
    //     0xd5cac8: stur            w0, [x1, #0x13]
    // 0xd5cacc: r0 = DefaultTextEditingShortcuts()
    //     0xd5cacc: bl              #0xd5cc40  ; AllocateDefaultTextEditingShortcutsStub -> DefaultTextEditingShortcuts (size=0x10)
    // 0xd5cad0: mov             x1, x0
    // 0xd5cad4: ldur            x0, [fp, #-0x18]
    // 0xd5cad8: stur            x1, [fp, #-0x10]
    // 0xd5cadc: StoreField: r1->field_b = r0
    //     0xd5cadc: stur            w0, [x1, #0xb]
    // 0xd5cae0: r0 = Shortcuts()
    //     0xd5cae0: bl              #0xd188b8  ; AllocateShortcutsStub -> Shortcuts (size=0x20)
    // 0xd5cae4: mov             x3, x0
    // 0xd5cae8: ldur            x0, [fp, #-0x10]
    // 0xd5caec: stur            x3, [fp, #-0x18]
    // 0xd5caf0: StoreField: r3->field_13 = r0
    //     0xd5caf0: stur            w0, [x3, #0x13]
    // 0xd5caf4: r0 = "<Default WidgetsApp Shortcuts>"
    //     0xd5caf4: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3390] "<Default WidgetsApp Shortcuts>"
    //     0xd5caf8: ldr             x0, [x0, #0x390]
    // 0xd5cafc: ArrayStore: r3[0] = r0  ; List_4
    //     0xd5cafc: stur            w0, [x3, #0x17]
    // 0xd5cb00: r0 = true
    //     0xd5cb00: add             x0, NULL, #0x20  ; true
    // 0xd5cb04: StoreField: r3->field_1b = r0
    //     0xd5cb04: stur            w0, [x3, #0x1b]
    // 0xd5cb08: r0 = _ConstMap len:18
    //     0xd5cb08: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3398] Map<ShortcutActivator, Intent>(18)
    //     0xd5cb0c: ldr             x0, [x0, #0x398]
    // 0xd5cb10: StoreField: r3->field_f = r0
    //     0xd5cb10: stur            w0, [x3, #0xf]
    // 0xd5cb14: ldur            x2, [fp, #-8]
    // 0xd5cb18: r1 = Function '_defaultOnNavigationNotification@150236006':.
    //     0xd5cb18: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33a0] AnonymousClosure: (0xd5d05c), in [package:flutter/src/widgets/app.dart] _WidgetsAppState::_defaultOnNavigationNotification (0xd5d098)
    //     0xd5cb1c: ldr             x1, [x1, #0x3a0]
    // 0xd5cb20: r0 = AllocateClosure()
    //     0xd5cb20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5cb24: r1 = <NavigationNotification>
    //     0xd5cb24: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a3c0] TypeArguments: <NavigationNotification>
    //     0xd5cb28: ldr             x1, [x1, #0x3c0]
    // 0xd5cb2c: stur            x0, [fp, #-8]
    // 0xd5cb30: r0 = NotificationListener()
    //     0xd5cb30: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xd5cb34: mov             x1, x0
    // 0xd5cb38: ldur            x0, [fp, #-8]
    // 0xd5cb3c: stur            x1, [fp, #-0x10]
    // 0xd5cb40: StoreField: r1->field_13 = r0
    //     0xd5cb40: stur            w0, [x1, #0x13]
    // 0xd5cb44: ldur            x0, [fp, #-0x18]
    // 0xd5cb48: StoreField: r1->field_b = r0
    //     0xd5cb48: stur            w0, [x1, #0xb]
    // 0xd5cb4c: r0 = SharedAppData()
    //     0xd5cb4c: bl              #0xd5cc10  ; AllocateSharedAppDataStub -> SharedAppData (size=0x10)
    // 0xd5cb50: mov             x1, x0
    // 0xd5cb54: ldur            x0, [fp, #-0x10]
    // 0xd5cb58: stur            x1, [fp, #-8]
    // 0xd5cb5c: StoreField: r1->field_b = r0
    //     0xd5cb5c: stur            w0, [x1, #0xb]
    // 0xd5cb60: r0 = RootRestorationScope()
    //     0xd5cb60: bl              #0xd5cbe0  ; AllocateRootRestorationScopeStub -> RootRestorationScope (size=0x14)
    // 0xd5cb64: ldur            x1, [fp, #-8]
    // 0xd5cb68: StoreField: r0->field_b = r1
    //     0xd5cb68: stur            w1, [x0, #0xb]
    // 0xd5cb6c: LeaveFrame
    //     0xd5cb6c: mov             SP, fp
    //     0xd5cb70: ldp             fp, lr, [SP], #0x10
    // 0xd5cb74: ret
    //     0xd5cb74: ret             
    // 0xd5cb78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5cb78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5cb7c: b               #0xd5c554
    // 0xd5cb80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5cb80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5cb84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5cb84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5cb88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5cb88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5cb8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5cb8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5cb90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5cb90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _initialRouteName(/* No info */) {
    // ** addr: 0xd5cddc, size: 0xc4
    // 0xd5cddc: EnterFrame
    //     0xd5cddc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5cde0: mov             fp, SP
    // 0xd5cde4: AllocStack(0x18)
    //     0xd5cde4: sub             SP, SP, #0x18
    // 0xd5cde8: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x8 */)
    //     0xd5cde8: stur            x1, [fp, #-8]
    // 0xd5cdec: CheckStackOverflow
    //     0xd5cdec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5cdf0: cmp             SP, x16
    //     0xd5cdf4: b.ls            #0xd5ce8c
    // 0xd5cdf8: r0 = LoadStaticField(0x6a0)
    //     0xd5cdf8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd5cdfc: ldr             x0, [x0, #0xd40]
    // 0xd5ce00: cmp             w0, NULL
    // 0xd5ce04: b.eq            #0xd5ce94
    // 0xd5ce08: r0 = LoadStaticField(0x58c)
    //     0xd5ce08: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd5ce0c: ldr             x0, [x0, #0xb18]
    // 0xd5ce10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5ce14: cmp             w0, w16
    // 0xd5ce18: b.ne            #0xd5ce24
    // 0xd5ce1c: r2 = _instance
    //     0xd5ce1c: ldr             x2, [PP, #0x1750]  ; [pp+0x1750] Field <PlatformDispatcher._instance@38065589>: static late final (offset: 0x58c)
    // 0xd5ce20: r0 = InitLateFinalStaticField()
    //     0xd5ce20: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd5ce24: r0 = __defaultRouteName$Method$FfiNative()
    //     0xd5ce24: bl              #0xd5cea0  ; [dart:ui] PlatformDispatcher::__defaultRouteName$Method$FfiNative
    // 0xd5ce28: r1 = LoadClassIdInstr(r0)
    //     0xd5ce28: ldur            x1, [x0, #-1]
    //     0xd5ce2c: ubfx            x1, x1, #0xc, #0x14
    // 0xd5ce30: r16 = "/"
    //     0xd5ce30: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xd5ce34: stp             x16, x0, [SP]
    // 0xd5ce38: mov             x0, x1
    // 0xd5ce3c: mov             lr, x0
    // 0xd5ce40: ldr             lr, [x21, lr, lsl #3]
    // 0xd5ce44: blr             lr
    // 0xd5ce48: tbz             w0, #4, #0xd5ce64
    // 0xd5ce4c: r0 = LoadStaticField(0x6a0)
    //     0xd5ce4c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd5ce50: ldr             x0, [x0, #0xd40]
    // 0xd5ce54: cmp             w0, NULL
    // 0xd5ce58: b.eq            #0xd5ce98
    // 0xd5ce5c: r0 = __defaultRouteName$Method$FfiNative()
    //     0xd5ce5c: bl              #0xd5cea0  ; [dart:ui] PlatformDispatcher::__defaultRouteName$Method$FfiNative
    // 0xd5ce60: b               #0xd5ce80
    // 0xd5ce64: ldur            x1, [fp, #-8]
    // 0xd5ce68: LoadField: r2 = r1->field_b
    //     0xd5ce68: ldur            w2, [x1, #0xb]
    // 0xd5ce6c: DecompressPointer r2
    //     0xd5ce6c: add             x2, x2, HEAP, lsl #32
    // 0xd5ce70: cmp             w2, NULL
    // 0xd5ce74: b.eq            #0xd5ce9c
    // 0xd5ce78: r0 = "/splash"
    //     0xd5ce78: add             x0, PP, #0x12, lsl #12  ; [pp+0x127d0] "/splash"
    //     0xd5ce7c: ldr             x0, [x0, #0x7d0]
    // 0xd5ce80: LeaveFrame
    //     0xd5ce80: mov             SP, fp
    //     0xd5ce84: ldp             fp, lr, [SP], #0x10
    // 0xd5ce88: ret
    //     0xd5ce88: ret             
    // 0xd5ce8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5ce8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5ce90: b               #0xd5cdf8
    // 0xd5ce94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5ce94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5ce98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5ce98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5ce9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5ce9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool _defaultOnNavigationNotification(dynamic, NavigationNotification) {
    // ** addr: 0xd5d05c, size: 0x3c
    // 0xd5d05c: EnterFrame
    //     0xd5d05c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d060: mov             fp, SP
    // 0xd5d064: ldr             x0, [fp, #0x18]
    // 0xd5d068: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5d068: ldur            w1, [x0, #0x17]
    // 0xd5d06c: DecompressPointer r1
    //     0xd5d06c: add             x1, x1, HEAP, lsl #32
    // 0xd5d070: CheckStackOverflow
    //     0xd5d070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d074: cmp             SP, x16
    //     0xd5d078: b.ls            #0xd5d090
    // 0xd5d07c: ldr             x2, [fp, #0x10]
    // 0xd5d080: r0 = _defaultOnNavigationNotification()
    //     0xd5d080: bl              #0xd5d098  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_defaultOnNavigationNotification
    // 0xd5d084: LeaveFrame
    //     0xd5d084: mov             SP, fp
    //     0xd5d088: ldp             fp, lr, [SP], #0x10
    // 0xd5d08c: ret
    //     0xd5d08c: ret             
    // 0xd5d090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5d090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5d094: b               #0xd5d07c
  }
  _ _defaultOnNavigationNotification(/* No info */) {
    // ** addr: 0xd5d098, size: 0xa4
    // 0xd5d098: EnterFrame
    //     0xd5d098: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d09c: mov             fp, SP
    // 0xd5d0a0: CheckStackOverflow
    //     0xd5d0a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d0a4: cmp             SP, x16
    //     0xd5d0a8: b.ls            #0xd5d134
    // 0xd5d0ac: LoadField: r0 = r1->field_13
    //     0xd5d0ac: ldur            w0, [x1, #0x13]
    // 0xd5d0b0: DecompressPointer r0
    //     0xd5d0b0: add             x0, x0, HEAP, lsl #32
    // 0xd5d0b4: cmp             w0, NULL
    // 0xd5d0b8: b.eq            #0xd5d0c8
    // 0xd5d0bc: r16 = Instance_AppLifecycleState
    //     0xd5d0bc: ldr             x16, [PP, #0x3178]  ; [pp+0x3178] Obj!AppLifecycleState@12c7f21
    // 0xd5d0c0: cmp             w0, w16
    // 0xd5d0c4: b.ne            #0xd5d0d8
    // 0xd5d0c8: r0 = true
    //     0xd5d0c8: add             x0, NULL, #0x20  ; true
    // 0xd5d0cc: LeaveFrame
    //     0xd5d0cc: mov             SP, fp
    //     0xd5d0d0: ldp             fp, lr, [SP], #0x10
    // 0xd5d0d4: ret
    //     0xd5d0d4: ret             
    // 0xd5d0d8: r16 = Instance_AppLifecycleState
    //     0xd5d0d8: ldr             x16, [PP, #0x31f8]  ; [pp+0x31f8] Obj!AppLifecycleState@12c7ea1
    // 0xd5d0dc: cmp             w0, w16
    // 0xd5d0e0: b.eq            #0xd5d108
    // 0xd5d0e4: r16 = Instance_AppLifecycleState
    //     0xd5d0e4: ldr             x16, [PP, #0x1e28]  ; [pp+0x1e28] Obj!AppLifecycleState@12c7ee1
    // 0xd5d0e8: cmp             w0, w16
    // 0xd5d0ec: b.eq            #0xd5d108
    // 0xd5d0f0: r16 = Instance_AppLifecycleState
    //     0xd5d0f0: ldr             x16, [PP, #0x3208]  ; [pp+0x3208] Obj!AppLifecycleState@12c7f01
    // 0xd5d0f4: cmp             w0, w16
    // 0xd5d0f8: b.eq            #0xd5d108
    // 0xd5d0fc: r16 = Instance_AppLifecycleState
    //     0xd5d0fc: ldr             x16, [PP, #0x3218]  ; [pp+0x3218] Obj!AppLifecycleState@12c7ec1
    // 0xd5d100: cmp             w0, w16
    // 0xd5d104: b.ne            #0xd5d124
    // 0xd5d108: LoadField: r1 = r2->field_7
    //     0xd5d108: ldur            w1, [x2, #7]
    // 0xd5d10c: DecompressPointer r1
    //     0xd5d10c: add             x1, x1, HEAP, lsl #32
    // 0xd5d110: r0 = setFrameworkHandlesBack()
    //     0xd5d110: bl              #0xd5d13c  ; [package:flutter/src/services/system_navigator.dart] SystemNavigator::setFrameworkHandlesBack
    // 0xd5d114: r0 = true
    //     0xd5d114: add             x0, NULL, #0x20  ; true
    // 0xd5d118: LeaveFrame
    //     0xd5d118: mov             SP, fp
    //     0xd5d11c: ldp             fp, lr, [SP], #0x10
    // 0xd5d120: ret
    //     0xd5d120: ret             
    // 0xd5d124: r0 = Null
    //     0xd5d124: mov             x0, NULL
    // 0xd5d128: LeaveFrame
    //     0xd5d128: mov             SP, fp
    //     0xd5d12c: ldp             fp, lr, [SP], #0x10
    // 0xd5d130: ret
    //     0xd5d130: ret             
    // 0xd5d134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5d134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5d138: b               #0xd5d0ac
  }
  [closure] Localizations <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd5d194, size: 0x104
    // 0xd5d194: EnterFrame
    //     0xd5d194: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d198: mov             fp, SP
    // 0xd5d19c: AllocStack(0x18)
    //     0xd5d19c: sub             SP, SP, #0x18
    // 0xd5d1a0: SetupParameters([dynamic _ /* r0 */])
    //     0xd5d1a0: ldr             x0, [fp, #0x20]
    //     0xd5d1a4: ldur            w2, [x0, #0x17]
    //     0xd5d1a8: add             x2, x2, HEAP, lsl #32
    //     0xd5d1ac: stur            x2, [fp, #-8]
    // 0xd5d1b0: CheckStackOverflow
    //     0xd5d1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d1b4: cmp             SP, x16
    //     0xd5d1b8: b.ls            #0xd5d290
    // 0xd5d1bc: LoadField: r1 = r2->field_f
    //     0xd5d1bc: ldur            w1, [x2, #0xf]
    // 0xd5d1c0: DecompressPointer r1
    //     0xd5d1c0: add             x1, x1, HEAP, lsl #32
    // 0xd5d1c4: LoadField: r0 = r1->field_1f
    //     0xd5d1c4: ldur            w0, [x1, #0x1f]
    // 0xd5d1c8: DecompressPointer r0
    //     0xd5d1c8: add             x0, x0, HEAP, lsl #32
    // 0xd5d1cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d1d0: cmp             w0, w16
    // 0xd5d1d4: b.ne            #0xd5d1e4
    // 0xd5d1d8: r2 = _localizationsResolver
    //     0xd5d1d8: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3380] Field <_WidgetsAppState@150236006._localizationsResolver@150236006>: late final (offset: 0x20)
    //     0xd5d1dc: ldr             x2, [x2, #0x380]
    // 0xd5d1e0: r0 = InitLateFinalInstanceField()
    //     0xd5d1e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd5d1e4: mov             x1, x0
    // 0xd5d1e8: r0 = locale()
    //     0xd5d1e8: bl              #0xd5d384  ; [package:flutter/src/widgets/localizations.dart] LocalizationsResolver::locale
    // 0xd5d1ec: mov             x2, x0
    // 0xd5d1f0: ldur            x0, [fp, #-8]
    // 0xd5d1f4: stur            x2, [fp, #-0x10]
    // 0xd5d1f8: LoadField: r1 = r0->field_f
    //     0xd5d1f8: ldur            w1, [x0, #0xf]
    // 0xd5d1fc: DecompressPointer r1
    //     0xd5d1fc: add             x1, x1, HEAP, lsl #32
    // 0xd5d200: LoadField: r0 = r1->field_1f
    //     0xd5d200: ldur            w0, [x1, #0x1f]
    // 0xd5d204: DecompressPointer r0
    //     0xd5d204: add             x0, x0, HEAP, lsl #32
    // 0xd5d208: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d20c: cmp             w0, w16
    // 0xd5d210: b.ne            #0xd5d220
    // 0xd5d214: r2 = _localizationsResolver
    //     0xd5d214: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3380] Field <_WidgetsAppState@150236006._localizationsResolver@150236006>: late final (offset: 0x20)
    //     0xd5d218: ldr             x2, [x2, #0x380]
    // 0xd5d21c: r0 = InitLateFinalInstanceField()
    //     0xd5d21c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd5d220: mov             x1, x0
    // 0xd5d224: r0 = localizationsDelegates()
    //     0xd5d224: bl              #0xd5d2a4  ; [package:flutter/src/widgets/localizations.dart] LocalizationsResolver::localizationsDelegates
    // 0xd5d228: mov             x1, x0
    // 0xd5d22c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd5d22c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd5d230: r0 = toList()
    //     0xd5d230: bl              #0xbb6108  ; [dart:core] _GrowableList::toList
    // 0xd5d234: mov             x1, x0
    // 0xd5d238: ldur            x0, [fp, #-8]
    // 0xd5d23c: stur            x1, [fp, #-0x18]
    // 0xd5d240: LoadField: r2 = r0->field_1b
    //     0xd5d240: ldur            w2, [x0, #0x1b]
    // 0xd5d244: DecompressPointer r2
    //     0xd5d244: add             x2, x2, HEAP, lsl #32
    // 0xd5d248: cmp             w2, NULL
    // 0xd5d24c: b.ne            #0xd5d258
    // 0xd5d250: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd5d250: ldur            w2, [x0, #0x17]
    // 0xd5d254: DecompressPointer r2
    //     0xd5d254: add             x2, x2, HEAP, lsl #32
    // 0xd5d258: ldur            x0, [fp, #-0x10]
    // 0xd5d25c: stur            x2, [fp, #-8]
    // 0xd5d260: r0 = Localizations()
    //     0xd5d260: bl              #0xd5d298  ; AllocateLocalizationsStub -> Localizations (size=0x1c)
    // 0xd5d264: ldur            x1, [fp, #-0x10]
    // 0xd5d268: StoreField: r0->field_b = r1
    //     0xd5d268: stur            w1, [x0, #0xb]
    // 0xd5d26c: ldur            x1, [fp, #-0x18]
    // 0xd5d270: StoreField: r0->field_f = r1
    //     0xd5d270: stur            w1, [x0, #0xf]
    // 0xd5d274: ldur            x1, [fp, #-8]
    // 0xd5d278: StoreField: r0->field_13 = r1
    //     0xd5d278: stur            w1, [x0, #0x13]
    // 0xd5d27c: r1 = true
    //     0xd5d27c: add             x1, NULL, #0x20  ; true
    // 0xd5d280: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5d280: stur            w1, [x0, #0x17]
    // 0xd5d284: LeaveFrame
    //     0xd5d284: mov             SP, fp
    //     0xd5d288: ldp             fp, lr, [SP], #0x10
    // 0xd5d28c: ret
    //     0xd5d28c: ret             
    // 0xd5d290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5d290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5d294: b               #0xd5d1bc
  }
  LocalizationsResolver _localizationsResolver(_WidgetsAppState) {
    // ** addr: 0xd5d40c, size: 0x78
    // 0xd5d40c: EnterFrame
    //     0xd5d40c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d410: mov             fp, SP
    // 0xd5d414: AllocStack(0x10)
    //     0xd5d414: sub             SP, SP, #0x10
    // 0xd5d418: CheckStackOverflow
    //     0xd5d418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d41c: cmp             SP, x16
    //     0xd5d420: b.ls            #0xd5d478
    // 0xd5d424: ldr             x0, [fp, #0x10]
    // 0xd5d428: LoadField: r1 = r0->field_b
    //     0xd5d428: ldur            w1, [x0, #0xb]
    // 0xd5d42c: DecompressPointer r1
    //     0xd5d42c: add             x1, x1, HEAP, lsl #32
    // 0xd5d430: cmp             w1, NULL
    // 0xd5d434: b.eq            #0xd5d480
    // 0xd5d438: LoadField: r2 = r1->field_4f
    //     0xd5d438: ldur            w2, [x1, #0x4f]
    // 0xd5d43c: DecompressPointer r2
    //     0xd5d43c: add             x2, x2, HEAP, lsl #32
    // 0xd5d440: stur            x2, [fp, #-0x10]
    // 0xd5d444: LoadField: r3 = r1->field_53
    //     0xd5d444: ldur            w3, [x1, #0x53]
    // 0xd5d448: DecompressPointer r3
    //     0xd5d448: add             x3, x3, HEAP, lsl #32
    // 0xd5d44c: stur            x3, [fp, #-8]
    // 0xd5d450: r0 = LocalizationsResolver()
    //     0xd5d450: bl              #0xd5d650  ; AllocateLocalizationsResolverStub -> LocalizationsResolver (size=0x3c)
    // 0xd5d454: mov             x1, x0
    // 0xd5d458: ldur            x2, [fp, #-0x10]
    // 0xd5d45c: ldur            x3, [fp, #-8]
    // 0xd5d460: stur            x0, [fp, #-8]
    // 0xd5d464: r0 = LocalizationsResolver()
    //     0xd5d464: bl              #0xd5d484  ; [package:flutter/src/widgets/localizations.dart] LocalizationsResolver::LocalizationsResolver
    // 0xd5d468: ldur            x0, [fp, #-8]
    // 0xd5d46c: LeaveFrame
    //     0xd5d46c: mov             SP, fp
    //     0xd5d470: ldp             fp, lr, [SP], #0x10
    // 0xd5d474: ret
    //     0xd5d474: ret             
    // 0xd5d478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5d478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5d47c: b               #0xd5d424
    // 0xd5d480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5d480: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] KeyEventResult <anonymous closure>(dynamic, FocusNode, KeyEvent) {
    // ** addr: 0xd5ddd8, size: 0xc8
    // 0xd5ddd8: EnterFrame
    //     0xd5ddd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd5dddc: mov             fp, SP
    // 0xd5dde0: AllocStack(0x18)
    //     0xd5dde0: sub             SP, SP, #0x18
    // 0xd5dde4: CheckStackOverflow
    //     0xd5dde4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5dde8: cmp             SP, x16
    //     0xd5ddec: b.ls            #0xd5de98
    // 0xd5ddf0: ldr             x0, [fp, #0x10]
    // 0xd5ddf4: r1 = LoadClassIdInstr(r0)
    //     0xd5ddf4: ldur            x1, [x0, #-1]
    //     0xd5ddf8: ubfx            x1, x1, #0xc, #0x14
    // 0xd5ddfc: r17 = 5032
    //     0xd5ddfc: mov             x17, #0x13a8
    // 0xd5de00: cmp             x1, x17
    // 0xd5de04: b.eq            #0xd5de14
    // 0xd5de08: r17 = 5030
    //     0xd5de08: mov             x17, #0x13a6
    // 0xd5de0c: cmp             x1, x17
    // 0xd5de10: b.ne            #0xd5de68
    // 0xd5de14: LoadField: r1 = r0->field_b
    //     0xd5de14: ldur            w1, [x0, #0xb]
    // 0xd5de18: DecompressPointer r1
    //     0xd5de18: add             x1, x1, HEAP, lsl #32
    // 0xd5de1c: stur            x1, [fp, #-8]
    // 0xd5de20: r16 = Instance_LogicalKeyboardKey
    //     0xd5de20: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa33d0] Obj!LogicalKeyboardKey@12ace71
    //     0xd5de24: ldr             x16, [x16, #0x3d0]
    // 0xd5de28: cmp             w1, w16
    // 0xd5de2c: b.eq            #0xd5de78
    // 0xd5de30: r16 = LogicalKeyboardKey
    //     0xd5de30: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xd5de34: ldr             x16, [x16, #0xd00]
    // 0xd5de38: r30 = LogicalKeyboardKey
    //     0xd5de38: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0xd5de3c: ldr             lr, [lr, #0xd00]
    // 0xd5de40: stp             lr, x16, [SP]
    // 0xd5de44: r0 = ==()
    //     0xd5de44: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xd5de48: tbnz            w0, #4, #0xd5de68
    // 0xd5de4c: ldur            x0, [fp, #-8]
    // 0xd5de50: r1 = Instance_LogicalKeyboardKey
    //     0xd5de50: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa33d0] Obj!LogicalKeyboardKey@12ace71
    //     0xd5de54: ldr             x1, [x1, #0x3d0]
    // 0xd5de58: LoadField: r2 = r1->field_7
    //     0xd5de58: ldur            x2, [x1, #7]
    // 0xd5de5c: LoadField: r1 = r0->field_7
    //     0xd5de5c: ldur            x1, [x0, #7]
    // 0xd5de60: cmp             x2, x1
    // 0xd5de64: b.eq            #0xd5de78
    // 0xd5de68: r0 = Instance_KeyEventResult
    //     0xd5de68: ldr             x0, [PP, #0x1d18]  ; [pp+0x1d18] Obj!KeyEventResult@12c3281
    // 0xd5de6c: LeaveFrame
    //     0xd5de6c: mov             SP, fp
    //     0xd5de70: ldp             fp, lr, [SP], #0x10
    // 0xd5de74: ret
    //     0xd5de74: ret             
    // 0xd5de78: r0 = dismissAllToolTips()
    //     0xd5de78: bl              #0xd5dea0  ; [package:flutter/src/widgets/raw_tooltip.dart] RawTooltip::dismissAllToolTips
    // 0xd5de7c: tbnz            w0, #4, #0xd5de88
    // 0xd5de80: r0 = Instance_KeyEventResult
    //     0xd5de80: ldr             x0, [PP, #0x1d08]  ; [pp+0x1d08] Obj!KeyEventResult@12c32c1
    // 0xd5de84: b               #0xd5de8c
    // 0xd5de88: r0 = Instance_KeyEventResult
    //     0xd5de88: ldr             x0, [PP, #0x1d18]  ; [pp+0x1d18] Obj!KeyEventResult@12c3281
    // 0xd5de8c: LeaveFrame
    //     0xd5de8c: mov             SP, fp
    //     0xd5de90: ldp             fp, lr, [SP], #0x10
    // 0xd5de94: ret
    //     0xd5de94: ret             
    // 0xd5de98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5de98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5de9c: b               #0xd5ddf0
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd5dffc, size: 0x7c
    // 0xd5dffc: EnterFrame
    //     0xd5dffc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e000: mov             fp, SP
    // 0xd5e004: ldr             x0, [fp, #0x18]
    // 0xd5e008: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e008: ldur            w1, [x0, #0x17]
    // 0xd5e00c: DecompressPointer r1
    //     0xd5e00c: add             x1, x1, HEAP, lsl #32
    // 0xd5e010: CheckStackOverflow
    //     0xd5e010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e014: cmp             SP, x16
    //     0xd5e018: b.ls            #0xd5e068
    // 0xd5e01c: LoadField: r0 = r1->field_f
    //     0xd5e01c: ldur            w0, [x1, #0xf]
    // 0xd5e020: DecompressPointer r0
    //     0xd5e020: add             x0, x0, HEAP, lsl #32
    // 0xd5e024: LoadField: r2 = r0->field_b
    //     0xd5e024: ldur            w2, [x0, #0xb]
    // 0xd5e028: DecompressPointer r2
    //     0xd5e028: add             x2, x2, HEAP, lsl #32
    // 0xd5e02c: cmp             w2, NULL
    // 0xd5e030: b.eq            #0xd5e070
    // 0xd5e034: LoadField: r0 = r2->field_3b
    //     0xd5e034: ldur            w0, [x2, #0x3b]
    // 0xd5e038: DecompressPointer r0
    //     0xd5e038: add             x0, x0, HEAP, lsl #32
    // 0xd5e03c: LoadField: r3 = r1->field_13
    //     0xd5e03c: ldur            w3, [x1, #0x13]
    // 0xd5e040: DecompressPointer r3
    //     0xd5e040: add             x3, x3, HEAP, lsl #32
    // 0xd5e044: cmp             w0, NULL
    // 0xd5e048: b.eq            #0xd5e074
    // 0xd5e04c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e04c: ldur            w1, [x0, #0x17]
    // 0xd5e050: DecompressPointer r1
    //     0xd5e050: add             x1, x1, HEAP, lsl #32
    // 0xd5e054: ldr             x2, [fp, #0x10]
    // 0xd5e058: r0 = _materialBuilder()
    //     0xd5e058: bl              #0xd5e0dc  ; [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder
    // 0xd5e05c: LeaveFrame
    //     0xd5e05c: mov             SP, fp
    //     0xd5e060: ldp             fp, lr, [SP], #0x10
    // 0xd5e064: ret
    //     0xd5e064: ret             
    // 0xd5e068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e06c: b               #0xd5e01c
    // 0xd5e070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e070: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e074: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd5e074: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] List<Route<dynamic>> <anonymous closure>(dynamic, NavigatorState, String) {
    // ** addr: 0xd5e5e4, size: 0x74
    // 0xd5e5e4: EnterFrame
    //     0xd5e5e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e5e8: mov             fp, SP
    // 0xd5e5ec: ldr             x0, [fp, #0x20]
    // 0xd5e5f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e5f0: ldur            w1, [x0, #0x17]
    // 0xd5e5f4: DecompressPointer r1
    //     0xd5e5f4: add             x1, x1, HEAP, lsl #32
    // 0xd5e5f8: CheckStackOverflow
    //     0xd5e5f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e5fc: cmp             SP, x16
    //     0xd5e600: b.ls            #0xd5e648
    // 0xd5e604: LoadField: r0 = r1->field_f
    //     0xd5e604: ldur            w0, [x1, #0xf]
    // 0xd5e608: DecompressPointer r0
    //     0xd5e608: add             x0, x0, HEAP, lsl #32
    // 0xd5e60c: LoadField: r1 = r0->field_b
    //     0xd5e60c: ldur            w1, [x0, #0xb]
    // 0xd5e610: DecompressPointer r1
    //     0xd5e610: add             x1, x1, HEAP, lsl #32
    // 0xd5e614: cmp             w1, NULL
    // 0xd5e618: b.eq            #0xd5e650
    // 0xd5e61c: LoadField: r0 = r1->field_13
    //     0xd5e61c: ldur            w0, [x1, #0x13]
    // 0xd5e620: DecompressPointer r0
    //     0xd5e620: add             x0, x0, HEAP, lsl #32
    // 0xd5e624: cmp             w0, NULL
    // 0xd5e628: b.eq            #0xd5e654
    // 0xd5e62c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e62c: ldur            w1, [x0, #0x17]
    // 0xd5e630: DecompressPointer r1
    //     0xd5e630: add             x1, x1, HEAP, lsl #32
    // 0xd5e634: ldr             x2, [fp, #0x10]
    // 0xd5e638: r0 = initialRoutesGenerate()
    //     0xd5e638: bl              #0xd5e694  ; [package:get/get_navigation/src/root/get_material_app.dart] GetMaterialApp::initialRoutesGenerate
    // 0xd5e63c: LeaveFrame
    //     0xd5e63c: mov             SP, fp
    //     0xd5e640: ldp             fp, lr, [SP], #0x10
    // 0xd5e644: ret
    //     0xd5e644: ret             
    // 0xd5e648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e64c: b               #0xd5e604
    // 0xd5e650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e650: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e654: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd5e654: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3f278, size: 0xdc
    // 0xf3f278: EnterFrame
    //     0xf3f278: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f27c: mov             fp, SP
    // 0xf3f280: AllocStack(0x18)
    //     0xf3f280: sub             SP, SP, #0x18
    // 0xf3f284: SetupParameters(_WidgetsAppState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3f284: mov             x4, x1
    //     0xf3f288: mov             x3, x2
    //     0xf3f28c: stur            x1, [fp, #-8]
    //     0xf3f290: stur            x2, [fp, #-0x10]
    // 0xf3f294: CheckStackOverflow
    //     0xf3f294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f298: cmp             SP, x16
    //     0xf3f29c: b.ls            #0xf3f34c
    // 0xf3f2a0: mov             x0, x3
    // 0xf3f2a4: r2 = Null
    //     0xf3f2a4: mov             x2, NULL
    // 0xf3f2a8: r1 = Null
    //     0xf3f2a8: mov             x1, NULL
    // 0xf3f2ac: r4 = 60
    //     0xf3f2ac: mov             x4, #0x3c
    // 0xf3f2b0: branchIfSmi(r0, 0xf3f2bc)
    //     0xf3f2b0: tbz             w0, #0, #0xf3f2bc
    // 0xf3f2b4: r4 = LoadClassIdInstr(r0)
    //     0xf3f2b4: ldur            x4, [x0, #-1]
    //     0xf3f2b8: ubfx            x4, x4, #0xc, #0x14
    // 0xf3f2bc: r17 = 6405
    //     0xf3f2bc: mov             x17, #0x1905
    // 0xf3f2c0: cmp             x4, x17
    // 0xf3f2c4: b.eq            #0xf3f2dc
    // 0xf3f2c8: r8 = WidgetsApp
    //     0xf3f2c8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3458] Type: WidgetsApp
    //     0xf3f2cc: ldr             x8, [x8, #0x458]
    // 0xf3f2d0: r3 = Null
    //     0xf3f2d0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3460] Null
    //     0xf3f2d4: ldr             x3, [x3, #0x460]
    // 0xf3f2d8: r0 = WidgetsApp()
    //     0xf3f2d8: bl              #0x8d26fc  ; IsType_WidgetsApp_Stub
    // 0xf3f2dc: ldur            x3, [fp, #-8]
    // 0xf3f2e0: LoadField: r2 = r3->field_7
    //     0xf3f2e0: ldur            w2, [x3, #7]
    // 0xf3f2e4: DecompressPointer r2
    //     0xf3f2e4: add             x2, x2, HEAP, lsl #32
    // 0xf3f2e8: ldur            x0, [fp, #-0x10]
    // 0xf3f2ec: r1 = Null
    //     0xf3f2ec: mov             x1, NULL
    // 0xf3f2f0: cmp             w2, NULL
    // 0xf3f2f4: b.eq            #0xf3f318
    // 0xf3f2f8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3f2f8: ldur            w4, [x2, #0x17]
    // 0xf3f2fc: DecompressPointer r4
    //     0xf3f2fc: add             x4, x4, HEAP, lsl #32
    // 0xf3f300: r8 = X0 bound StatefulWidget
    //     0xf3f300: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3f304: ldr             x8, [x8, #0x498]
    // 0xf3f308: LoadField: r9 = r4->field_7
    //     0xf3f308: ldur            x9, [x4, #7]
    // 0xf3f30c: r3 = Null
    //     0xf3f30c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3470] Null
    //     0xf3f310: ldr             x3, [x3, #0x470]
    // 0xf3f314: blr             x9
    // 0xf3f318: ldur            x16, [fp, #-0x10]
    // 0xf3f31c: str             x16, [SP]
    // 0xf3f320: ldur            x1, [fp, #-8]
    // 0xf3f324: r4 = const [0, 0x2, 0x1, 0x1, oldWidget, 0x1, null]
    //     0xf3f324: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3480] List(7) [0, 0x2, 0x1, 0x1, "oldWidget", 0x1, Null]
    //     0xf3f328: ldr             x4, [x4, #0x480]
    // 0xf3f32c: r0 = _updateRouting()
    //     0xf3f32c: bl              #0xf3f50c  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_updateRouting
    // 0xf3f330: ldur            x1, [fp, #-8]
    // 0xf3f334: ldur            x2, [fp, #-0x10]
    // 0xf3f338: r0 = _updateLocalizations()
    //     0xf3f338: bl              #0xf3f354  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_updateLocalizations
    // 0xf3f33c: r0 = Null
    //     0xf3f33c: mov             x0, NULL
    // 0xf3f340: LeaveFrame
    //     0xf3f340: mov             SP, fp
    //     0xf3f344: ldp             fp, lr, [SP], #0x10
    // 0xf3f348: ret
    //     0xf3f348: ret             
    // 0xf3f34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f34c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f350: b               #0xf3f2a0
  }
  _ _updateLocalizations(/* No info */) {
    // ** addr: 0xf3f354, size: 0xa0
    // 0xf3f354: EnterFrame
    //     0xf3f354: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f358: mov             fp, SP
    // 0xf3f35c: AllocStack(0x8)
    //     0xf3f35c: sub             SP, SP, #8
    // 0xf3f360: SetupParameters(_WidgetsAppState this /* r1 => r0, fp-0x8 */)
    //     0xf3f360: mov             x0, x1
    //     0xf3f364: stur            x1, [fp, #-8]
    // 0xf3f368: CheckStackOverflow
    //     0xf3f368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f36c: cmp             SP, x16
    //     0xf3f370: b.ls            #0xf3f3e8
    // 0xf3f374: mov             x1, x0
    // 0xf3f378: r0 = _shouldUpdateLocalizations()
    //     0xf3f378: bl              #0xf3f460  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_shouldUpdateLocalizations
    // 0xf3f37c: tbnz            w0, #4, #0xf3f3d8
    // 0xf3f380: ldur            x0, [fp, #-8]
    // 0xf3f384: mov             x1, x0
    // 0xf3f388: LoadField: r0 = r1->field_1f
    //     0xf3f388: ldur            w0, [x1, #0x1f]
    // 0xf3f38c: DecompressPointer r0
    //     0xf3f38c: add             x0, x0, HEAP, lsl #32
    // 0xf3f390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3f394: cmp             w0, w16
    // 0xf3f398: b.ne            #0xf3f3a8
    // 0xf3f39c: r2 = _localizationsResolver
    //     0xf3f39c: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3380] Field <_WidgetsAppState@150236006._localizationsResolver@150236006>: late final (offset: 0x20)
    //     0xf3f3a0: ldr             x2, [x2, #0x380]
    // 0xf3f3a4: r0 = InitLateFinalInstanceField()
    //     0xf3f3a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xf3f3a8: mov             x1, x0
    // 0xf3f3ac: ldur            x0, [fp, #-8]
    // 0xf3f3b0: LoadField: r2 = r0->field_b
    //     0xf3f3b0: ldur            w2, [x0, #0xb]
    // 0xf3f3b4: DecompressPointer r2
    //     0xf3f3b4: add             x2, x2, HEAP, lsl #32
    // 0xf3f3b8: cmp             w2, NULL
    // 0xf3f3bc: b.eq            #0xf3f3f0
    // 0xf3f3c0: LoadField: r0 = r2->field_4f
    //     0xf3f3c0: ldur            w0, [x2, #0x4f]
    // 0xf3f3c4: DecompressPointer r0
    //     0xf3f3c4: add             x0, x0, HEAP, lsl #32
    // 0xf3f3c8: LoadField: r3 = r2->field_53
    //     0xf3f3c8: ldur            w3, [x2, #0x53]
    // 0xf3f3cc: DecompressPointer r3
    //     0xf3f3cc: add             x3, x3, HEAP, lsl #32
    // 0xf3f3d0: mov             x2, x0
    // 0xf3f3d4: r0 = update()
    //     0xf3f3d4: bl              #0xf3f3f4  ; [package:flutter/src/widgets/localizations.dart] LocalizationsResolver::update
    // 0xf3f3d8: r0 = Null
    //     0xf3f3d8: mov             x0, NULL
    // 0xf3f3dc: LeaveFrame
    //     0xf3f3dc: mov             SP, fp
    //     0xf3f3e0: ldp             fp, lr, [SP], #0x10
    // 0xf3f3e4: ret
    //     0xf3f3e4: ret             
    // 0xf3f3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f3e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f3ec: b               #0xf3f374
    // 0xf3f3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f3f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldUpdateLocalizations(/* No info */) {
    // ** addr: 0xf3f460, size: 0xac
    // 0xf3f460: EnterFrame
    //     0xf3f460: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f464: mov             fp, SP
    // 0xf3f468: AllocStack(0x20)
    //     0xf3f468: sub             SP, SP, #0x20
    // 0xf3f46c: SetupParameters(_WidgetsAppState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf3f46c: stur            x1, [fp, #-8]
    //     0xf3f470: stur            x2, [fp, #-0x10]
    // 0xf3f474: CheckStackOverflow
    //     0xf3f474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f478: cmp             SP, x16
    //     0xf3f47c: b.ls            #0xf3f4fc
    // 0xf3f480: LoadField: r0 = r1->field_b
    //     0xf3f480: ldur            w0, [x1, #0xb]
    // 0xf3f484: DecompressPointer r0
    //     0xf3f484: add             x0, x0, HEAP, lsl #32
    // 0xf3f488: cmp             w0, NULL
    // 0xf3f48c: b.eq            #0xf3f504
    // 0xf3f490: LoadField: r3 = r0->field_4f
    //     0xf3f490: ldur            w3, [x0, #0x4f]
    // 0xf3f494: DecompressPointer r3
    //     0xf3f494: add             x3, x3, HEAP, lsl #32
    // 0xf3f498: LoadField: r0 = r2->field_4f
    //     0xf3f498: ldur            w0, [x2, #0x4f]
    // 0xf3f49c: DecompressPointer r0
    //     0xf3f49c: add             x0, x0, HEAP, lsl #32
    // 0xf3f4a0: stp             x0, x3, [SP]
    // 0xf3f4a4: r0 = ==()
    //     0xf3f4a4: bl              #0x128e544  ; [dart:ui] Locale::==
    // 0xf3f4a8: tbz             w0, #4, #0xf3f4b4
    // 0xf3f4ac: r0 = true
    //     0xf3f4ac: add             x0, NULL, #0x20  ; true
    // 0xf3f4b0: b               #0xf3f4f0
    // 0xf3f4b4: ldur            x2, [fp, #-8]
    // 0xf3f4b8: ldur            x1, [fp, #-0x10]
    // 0xf3f4bc: LoadField: r3 = r2->field_b
    //     0xf3f4bc: ldur            w3, [x2, #0xb]
    // 0xf3f4c0: DecompressPointer r3
    //     0xf3f4c0: add             x3, x3, HEAP, lsl #32
    // 0xf3f4c4: cmp             w3, NULL
    // 0xf3f4c8: b.eq            #0xf3f508
    // 0xf3f4cc: LoadField: r2 = r3->field_53
    //     0xf3f4cc: ldur            w2, [x3, #0x53]
    // 0xf3f4d0: DecompressPointer r2
    //     0xf3f4d0: add             x2, x2, HEAP, lsl #32
    // 0xf3f4d4: LoadField: r3 = r1->field_53
    //     0xf3f4d4: ldur            w3, [x1, #0x53]
    // 0xf3f4d8: DecompressPointer r3
    //     0xf3f4d8: add             x3, x3, HEAP, lsl #32
    // 0xf3f4dc: cmp             w2, w3
    // 0xf3f4e0: r16 = true
    //     0xf3f4e0: add             x16, NULL, #0x20  ; true
    // 0xf3f4e4: r17 = false
    //     0xf3f4e4: add             x17, NULL, #0x30  ; false
    // 0xf3f4e8: csel            x1, x16, x17, ne
    // 0xf3f4ec: mov             x0, x1
    // 0xf3f4f0: LeaveFrame
    //     0xf3f4f0: mov             SP, fp
    //     0xf3f4f4: ldp             fp, lr, [SP], #0x10
    // 0xf3f4f8: ret
    //     0xf3f4f8: ret             
    // 0xf3f4fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f4fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f500: b               #0xf3f480
    // 0xf3f504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f504: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3f508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f508: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateRouting(/* No info */) {
    // ** addr: 0xf3f50c, size: 0x11c
    // 0xf3f50c: EnterFrame
    //     0xf3f50c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f510: mov             fp, SP
    // 0xf3f514: AllocStack(0x10)
    //     0xf3f514: sub             SP, SP, #0x10
    // 0xf3f518: SetupParameters(_WidgetsAppState this /* r1 => r0, fp-0x10 */, {dynamic oldWidget = Null /* r2, fp-0x8 */})
    //     0xf3f518: mov             x0, x1
    //     0xf3f51c: stur            x1, [fp, #-0x10]
    //     0xf3f520: ldur            w1, [x4, #0x13]
    //     0xf3f524: ldur            w2, [x4, #0x1f]
    //     0xf3f528: add             x2, x2, HEAP, lsl #32
    //     0xf3f52c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3488] "oldWidget"
    //     0xf3f530: ldr             x16, [x16, #0x488]
    //     0xf3f534: cmp             w2, w16
    //     0xf3f538: b.ne            #0xf3f558
    //     0xf3f53c: ldur            w2, [x4, #0x23]
    //     0xf3f540: add             x2, x2, HEAP, lsl #32
    //     0xf3f544: sub             w3, w1, w2
    //     0xf3f548: add             x1, fp, w3, sxtw #2
    //     0xf3f54c: ldr             x1, [x1, #8]
    //     0xf3f550: mov             x2, x1
    //     0xf3f554: b               #0xf3f55c
    //     0xf3f558: mov             x2, NULL
    //     0xf3f55c: stur            x2, [fp, #-8]
    // 0xf3f560: CheckStackOverflow
    //     0xf3f560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f564: cmp             SP, x16
    //     0xf3f568: b.ls            #0xf3f610
    // 0xf3f56c: LoadField: r1 = r0->field_b
    //     0xf3f56c: ldur            w1, [x0, #0xb]
    // 0xf3f570: DecompressPointer r1
    //     0xf3f570: add             x1, x1, HEAP, lsl #32
    // 0xf3f574: cmp             w1, NULL
    // 0xf3f578: b.eq            #0xf3f618
    // 0xf3f57c: mov             x1, x0
    // 0xf3f580: r0 = detach()
    //     0xf3f580: bl              #0xc09564  ; [package:flutter/src/rendering/object.dart] RenderObject::detach
    // 0xf3f584: ldur            x1, [fp, #-0x10]
    // 0xf3f588: LoadField: r2 = r1->field_1b
    //     0xf3f588: ldur            w2, [x1, #0x1b]
    // 0xf3f58c: DecompressPointer r2
    //     0xf3f58c: add             x2, x2, HEAP, lsl #32
    // 0xf3f590: cmp             w2, NULL
    // 0xf3f594: b.eq            #0xf3f5cc
    // 0xf3f598: ldur            x2, [fp, #-8]
    // 0xf3f59c: LoadField: r3 = r1->field_b
    //     0xf3f59c: ldur            w3, [x1, #0xb]
    // 0xf3f5a0: DecompressPointer r3
    //     0xf3f5a0: add             x3, x3, HEAP, lsl #32
    // 0xf3f5a4: cmp             w3, NULL
    // 0xf3f5a8: b.eq            #0xf3f61c
    // 0xf3f5ac: LoadField: r4 = r3->field_b
    //     0xf3f5ac: ldur            w4, [x3, #0xb]
    // 0xf3f5b0: DecompressPointer r4
    //     0xf3f5b0: add             x4, x4, HEAP, lsl #32
    // 0xf3f5b4: cmp             w2, NULL
    // 0xf3f5b8: b.eq            #0xf3f620
    // 0xf3f5bc: LoadField: r3 = r2->field_b
    //     0xf3f5bc: ldur            w3, [x2, #0xb]
    // 0xf3f5c0: DecompressPointer r3
    //     0xf3f5c0: add             x3, x3, HEAP, lsl #32
    // 0xf3f5c4: cmp             w4, w3
    // 0xf3f5c8: b.eq            #0xf3f600
    // 0xf3f5cc: LoadField: r2 = r1->field_b
    //     0xf3f5cc: ldur            w2, [x1, #0xb]
    // 0xf3f5d0: DecompressPointer r2
    //     0xf3f5d0: add             x2, x2, HEAP, lsl #32
    // 0xf3f5d4: cmp             w2, NULL
    // 0xf3f5d8: b.eq            #0xf3f624
    // 0xf3f5dc: LoadField: r0 = r2->field_b
    //     0xf3f5dc: ldur            w0, [x2, #0xb]
    // 0xf3f5e0: DecompressPointer r0
    //     0xf3f5e0: add             x0, x0, HEAP, lsl #32
    // 0xf3f5e4: StoreField: r1->field_1b = r0
    //     0xf3f5e4: stur            w0, [x1, #0x1b]
    //     0xf3f5e8: ldurb           w16, [x1, #-1]
    //     0xf3f5ec: ldurb           w17, [x0, #-1]
    //     0xf3f5f0: and             x16, x17, x16, lsr #2
    //     0xf3f5f4: tst             x16, HEAP, lsr #32
    //     0xf3f5f8: b.eq            #0xf3f600
    //     0xf3f5fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3f600: r0 = Null
    //     0xf3f600: mov             x0, NULL
    // 0xf3f604: LeaveFrame
    //     0xf3f604: mov             SP, fp
    //     0xf3f608: ldp             fp, lr, [SP], #0x10
    // 0xf3f60c: ret
    //     0xf3f60c: ret             
    // 0xf3f610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f614: b               #0xf3f56c
    // 0xf3f618: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f618: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3f61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f61c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3f620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f620: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3f624: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f624: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf82970, size: 0x114
    // 0xf82970: EnterFrame
    //     0xf82970: stp             fp, lr, [SP, #-0x10]!
    //     0xf82974: mov             fp, SP
    // 0xf82978: AllocStack(0x18)
    //     0xf82978: sub             SP, SP, #0x18
    // 0xf8297c: SetupParameters(_WidgetsAppState this /* r1 => r0, fp-0x8 */)
    //     0xf8297c: mov             x0, x1
    //     0xf82980: stur            x1, [fp, #-8]
    // 0xf82984: CheckStackOverflow
    //     0xf82984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82988: cmp             SP, x16
    //     0xf8298c: b.ls            #0xf82a74
    // 0xf82990: mov             x1, x0
    // 0xf82994: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf82994: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf82998: r0 = _updateRouting()
    //     0xf82998: bl              #0xf3f50c  ; [package:flutter/src/widgets/app.dart] _WidgetsAppState::_updateRouting
    // 0xf8299c: r0 = LoadStaticField(0x6a0)
    //     0xf8299c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf829a0: ldr             x0, [x0, #0xd40]
    // 0xf829a4: cmp             w0, NULL
    // 0xf829a8: b.eq            #0xf82a7c
    // 0xf829ac: LoadField: r2 = r0->field_f3
    //     0xf829ac: ldur            w2, [x0, #0xf3]
    // 0xf829b0: DecompressPointer r2
    //     0xf829b0: add             x2, x2, HEAP, lsl #32
    // 0xf829b4: stur            x2, [fp, #-0x18]
    // 0xf829b8: LoadField: r0 = r2->field_b
    //     0xf829b8: ldur            w0, [x2, #0xb]
    // 0xf829bc: LoadField: r1 = r2->field_f
    //     0xf829bc: ldur            w1, [x2, #0xf]
    // 0xf829c0: DecompressPointer r1
    //     0xf829c0: add             x1, x1, HEAP, lsl #32
    // 0xf829c4: LoadField: r3 = r1->field_b
    //     0xf829c4: ldur            w3, [x1, #0xb]
    // 0xf829c8: r4 = LoadInt32Instr(r0)
    //     0xf829c8: sbfx            x4, x0, #1, #0x1f
    // 0xf829cc: stur            x4, [fp, #-0x10]
    // 0xf829d0: r0 = LoadInt32Instr(r3)
    //     0xf829d0: sbfx            x0, x3, #1, #0x1f
    // 0xf829d4: cmp             x4, x0
    // 0xf829d8: b.ne            #0xf829e4
    // 0xf829dc: mov             x1, x2
    // 0xf829e0: r0 = _growToNextCapacity()
    //     0xf829e0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf829e4: ldur            x4, [fp, #-8]
    // 0xf829e8: ldur            x2, [fp, #-0x18]
    // 0xf829ec: ldur            x3, [fp, #-0x10]
    // 0xf829f0: add             x5, x3, #1
    // 0xf829f4: lsl             x6, x5, #1
    // 0xf829f8: StoreField: r2->field_b = r6
    //     0xf829f8: stur            w6, [x2, #0xb]
    // 0xf829fc: LoadField: r1 = r2->field_f
    //     0xf829fc: ldur            w1, [x2, #0xf]
    // 0xf82a00: DecompressPointer r1
    //     0xf82a00: add             x1, x1, HEAP, lsl #32
    // 0xf82a04: mov             x0, x4
    // 0xf82a08: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf82a08: add             x25, x1, x3, lsl #2
    //     0xf82a0c: add             x25, x25, #0xf
    //     0xf82a10: str             w0, [x25]
    //     0xf82a14: tbz             w0, #0, #0xf82a30
    //     0xf82a18: ldurb           w16, [x1, #-1]
    //     0xf82a1c: ldurb           w17, [x0, #-1]
    //     0xf82a20: and             x16, x17, x16, lsr #2
    //     0xf82a24: tst             x16, HEAP, lsr #32
    //     0xf82a28: b.eq            #0xf82a30
    //     0xf82a2c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf82a30: r1 = LoadStaticField(0x6a0)
    //     0xf82a30: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xf82a34: ldr             x1, [x1, #0xd40]
    // 0xf82a38: cmp             w1, NULL
    // 0xf82a3c: b.eq            #0xf82a80
    // 0xf82a40: LoadField: r0 = r1->field_2f
    //     0xf82a40: ldur            w0, [x1, #0x2f]
    // 0xf82a44: DecompressPointer r0
    //     0xf82a44: add             x0, x0, HEAP, lsl #32
    // 0xf82a48: StoreField: r4->field_13 = r0
    //     0xf82a48: stur            w0, [x4, #0x13]
    //     0xf82a4c: ldurb           w16, [x4, #-1]
    //     0xf82a50: ldurb           w17, [x0, #-1]
    //     0xf82a54: and             x16, x17, x16, lsr #2
    //     0xf82a58: tst             x16, HEAP, lsr #32
    //     0xf82a5c: b.eq            #0xf82a64
    //     0xf82a60: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf82a64: r0 = Null
    //     0xf82a64: mov             x0, NULL
    // 0xf82a68: LeaveFrame
    //     0xf82a68: mov             SP, fp
    //     0xf82a6c: ldp             fp, lr, [SP], #0x10
    // 0xf82a70: ret
    //     0xf82a70: ret             
    // 0xf82a74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82a74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82a78: b               #0xf82990
    // 0xf82a7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf82a7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf82a80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf82a80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dee94, size: 0x80
    // 0x10dee94: EnterFrame
    //     0x10dee94: stp             fp, lr, [SP, #-0x10]!
    //     0x10dee98: mov             fp, SP
    // 0x10dee9c: AllocStack(0x8)
    //     0x10dee9c: sub             SP, SP, #8
    // 0x10deea0: SetupParameters(_WidgetsAppState this /* r1 => r0, fp-0x8 */)
    //     0x10deea0: mov             x0, x1
    //     0x10deea4: stur            x1, [fp, #-8]
    // 0x10deea8: CheckStackOverflow
    //     0x10deea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10deeac: cmp             SP, x16
    //     0x10deeb0: b.ls            #0x10def08
    // 0x10deeb4: r1 = LoadStaticField(0x6a0)
    //     0x10deeb4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x10deeb8: ldr             x1, [x1, #0xd40]
    // 0x10deebc: cmp             w1, NULL
    // 0x10deec0: b.eq            #0x10def10
    // 0x10deec4: mov             x2, x0
    // 0x10deec8: r0 = removeObserver()
    //     0x10deec8: bl              #0xb3ac3c  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x10deecc: ldur            x1, [fp, #-8]
    // 0x10deed0: LoadField: r0 = r1->field_1f
    //     0x10deed0: ldur            w0, [x1, #0x1f]
    // 0x10deed4: DecompressPointer r0
    //     0x10deed4: add             x0, x0, HEAP, lsl #32
    // 0x10deed8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10deedc: cmp             w0, w16
    // 0x10deee0: b.ne            #0x10deef0
    // 0x10deee4: r2 = _localizationsResolver
    //     0x10deee4: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3380] Field <_WidgetsAppState@150236006._localizationsResolver@150236006>: late final (offset: 0x20)
    //     0x10deee8: ldr             x2, [x2, #0x380]
    // 0x10deeec: r0 = InitLateFinalInstanceField()
    //     0x10deeec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10deef0: mov             x1, x0
    // 0x10deef4: r0 = dispose()
    //     0x10deef4: bl              #0x10eeeec  ; [package:flutter/src/widgets/localizations.dart] LocalizationsResolver::dispose
    // 0x10deef8: r0 = Null
    //     0x10deef8: mov             x0, NULL
    // 0x10deefc: LeaveFrame
    //     0x10deefc: mov             SP, fp
    //     0x10def00: ldp             fp, lr, [SP], #0x10
    // 0x10def04: ret
    //     0x10def04: ret             
    // 0x10def08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10def08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10def0c: b               #0x10deeb4
    // 0x10def10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10def10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6405, size: 0x78, field offset: 0xc
class WidgetsApp extends StatefulWidget {

  static late Map<Type, Action<Intent>> defaultActions; // offset: 0x7cc

  static Map<Type, Action<Intent>> defaultActions() {
    // ** addr: 0xd5d65c, size: 0x654
    // 0xd5d65c: EnterFrame
    //     0xd5d65c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d660: mov             fp, SP
    // 0xd5d664: AllocStack(0x28)
    //     0xd5d664: sub             SP, SP, #0x28
    // 0xd5d668: CheckStackOverflow
    //     0xd5d668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d66c: cmp             SP, x16
    //     0xd5d670: b.ls            #0xd5dca8
    // 0xd5d674: r1 = Null
    //     0xd5d674: mov             x1, NULL
    // 0xd5d678: r2 = 36
    //     0xd5d678: mov             x2, #0x24
    // 0xd5d67c: r0 = AllocateArray()
    //     0xd5d67c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd5d680: stur            x0, [fp, #-8]
    // 0xd5d684: r16 = DoNothingIntent
    //     0xd5d684: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa33f8] Type: DoNothingIntent
    //     0xd5d688: ldr             x16, [x16, #0x3f8]
    // 0xd5d68c: StoreField: r0->field_f = r16
    //     0xd5d68c: stur            w16, [x0, #0xf]
    // 0xd5d690: r1 = <Intent>
    //     0xd5d690: ldr             x1, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0xd5d694: r0 = DoNothingAction()
    //     0xd5d694: bl              #0xd5ddb0  ; AllocateDoNothingActionStub -> DoNothingAction (size=0x18)
    // 0xd5d698: mov             x2, x0
    // 0xd5d69c: r0 = true
    //     0xd5d69c: add             x0, NULL, #0x20  ; true
    // 0xd5d6a0: stur            x2, [fp, #-0x10]
    // 0xd5d6a4: StoreField: r2->field_13 = r0
    //     0xd5d6a4: stur            w0, [x2, #0x13]
    // 0xd5d6a8: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d6a8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d6ac: ldr             x1, [x1, #0x7a0]
    // 0xd5d6b0: r0 = ObserverList()
    //     0xd5d6b0: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5d6b4: mov             x3, x0
    // 0xd5d6b8: r0 = false
    //     0xd5d6b8: add             x0, NULL, #0x30  ; false
    // 0xd5d6bc: stur            x3, [fp, #-0x18]
    // 0xd5d6c0: StoreField: r3->field_f = r0
    //     0xd5d6c0: stur            w0, [x3, #0xf]
    // 0xd5d6c4: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d6c8: StoreField: r3->field_13 = r4
    //     0xd5d6c8: stur            w4, [x3, #0x13]
    // 0xd5d6cc: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d6cc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d6d0: ldr             x1, [x1, #0x7a0]
    // 0xd5d6d4: r2 = 0
    //     0xd5d6d4: mov             x2, #0
    // 0xd5d6d8: r0 = _GrowableList()
    //     0xd5d6d8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5d6dc: ldur            x1, [fp, #-0x18]
    // 0xd5d6e0: StoreField: r1->field_b = r0
    //     0xd5d6e0: stur            w0, [x1, #0xb]
    //     0xd5d6e4: ldurb           w16, [x1, #-1]
    //     0xd5d6e8: ldurb           w17, [x0, #-1]
    //     0xd5d6ec: and             x16, x17, x16, lsr #2
    //     0xd5d6f0: tst             x16, HEAP, lsr #32
    //     0xd5d6f4: b.eq            #0xd5d6fc
    //     0xd5d6f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5d6fc: mov             x0, x1
    // 0xd5d700: ldur            x1, [fp, #-0x10]
    // 0xd5d704: StoreField: r1->field_b = r0
    //     0xd5d704: stur            w0, [x1, #0xb]
    //     0xd5d708: ldurb           w16, [x1, #-1]
    //     0xd5d70c: ldurb           w17, [x0, #-1]
    //     0xd5d710: and             x16, x17, x16, lsr #2
    //     0xd5d714: tst             x16, HEAP, lsr #32
    //     0xd5d718: b.eq            #0xd5d720
    //     0xd5d71c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5d720: mov             x0, x1
    // 0xd5d724: ldur            x1, [fp, #-8]
    // 0xd5d728: ArrayStore: r1[1] = r0  ; List_4
    //     0xd5d728: add             x25, x1, #0x13
    //     0xd5d72c: str             w0, [x25]
    //     0xd5d730: tbz             w0, #0, #0xd5d74c
    //     0xd5d734: ldurb           w16, [x1, #-1]
    //     0xd5d738: ldurb           w17, [x0, #-1]
    //     0xd5d73c: and             x16, x17, x16, lsr #2
    //     0xd5d740: tst             x16, HEAP, lsr #32
    //     0xd5d744: b.eq            #0xd5d74c
    //     0xd5d748: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5d74c: ldur            x0, [fp, #-8]
    // 0xd5d750: r16 = DoNothingAndStopPropagationIntent
    //     0xd5d750: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3400] Type: DoNothingAndStopPropagationIntent
    //     0xd5d754: ldr             x16, [x16, #0x400]
    // 0xd5d758: ArrayStore: r0[0] = r16  ; List_4
    //     0xd5d758: stur            w16, [x0, #0x17]
    // 0xd5d75c: r1 = <Intent>
    //     0xd5d75c: ldr             x1, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0xd5d760: r0 = DoNothingAction()
    //     0xd5d760: bl              #0xd5ddb0  ; AllocateDoNothingActionStub -> DoNothingAction (size=0x18)
    // 0xd5d764: mov             x2, x0
    // 0xd5d768: r0 = false
    //     0xd5d768: add             x0, NULL, #0x30  ; false
    // 0xd5d76c: stur            x2, [fp, #-0x10]
    // 0xd5d770: StoreField: r2->field_13 = r0
    //     0xd5d770: stur            w0, [x2, #0x13]
    // 0xd5d774: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d774: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d778: ldr             x1, [x1, #0x7a0]
    // 0xd5d77c: r0 = ObserverList()
    //     0xd5d77c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5d780: mov             x3, x0
    // 0xd5d784: r0 = false
    //     0xd5d784: add             x0, NULL, #0x30  ; false
    // 0xd5d788: stur            x3, [fp, #-0x18]
    // 0xd5d78c: StoreField: r3->field_f = r0
    //     0xd5d78c: stur            w0, [x3, #0xf]
    // 0xd5d790: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d794: StoreField: r3->field_13 = r4
    //     0xd5d794: stur            w4, [x3, #0x13]
    // 0xd5d798: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d798: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d79c: ldr             x1, [x1, #0x7a0]
    // 0xd5d7a0: r2 = 0
    //     0xd5d7a0: mov             x2, #0
    // 0xd5d7a4: r0 = _GrowableList()
    //     0xd5d7a4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5d7a8: ldur            x1, [fp, #-0x18]
    // 0xd5d7ac: StoreField: r1->field_b = r0
    //     0xd5d7ac: stur            w0, [x1, #0xb]
    //     0xd5d7b0: ldurb           w16, [x1, #-1]
    //     0xd5d7b4: ldurb           w17, [x0, #-1]
    //     0xd5d7b8: and             x16, x17, x16, lsr #2
    //     0xd5d7bc: tst             x16, HEAP, lsr #32
    //     0xd5d7c0: b.eq            #0xd5d7c8
    //     0xd5d7c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5d7c8: mov             x0, x1
    // 0xd5d7cc: ldur            x1, [fp, #-0x10]
    // 0xd5d7d0: StoreField: r1->field_b = r0
    //     0xd5d7d0: stur            w0, [x1, #0xb]
    //     0xd5d7d4: ldurb           w16, [x1, #-1]
    //     0xd5d7d8: ldurb           w17, [x0, #-1]
    //     0xd5d7dc: and             x16, x17, x16, lsr #2
    //     0xd5d7e0: tst             x16, HEAP, lsr #32
    //     0xd5d7e4: b.eq            #0xd5d7ec
    //     0xd5d7e8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5d7ec: mov             x0, x1
    // 0xd5d7f0: ldur            x1, [fp, #-8]
    // 0xd5d7f4: ArrayStore: r1[3] = r0  ; List_4
    //     0xd5d7f4: add             x25, x1, #0x1b
    //     0xd5d7f8: str             w0, [x25]
    //     0xd5d7fc: tbz             w0, #0, #0xd5d818
    //     0xd5d800: ldurb           w16, [x1, #-1]
    //     0xd5d804: ldurb           w17, [x0, #-1]
    //     0xd5d808: and             x16, x17, x16, lsr #2
    //     0xd5d80c: tst             x16, HEAP, lsr #32
    //     0xd5d810: b.eq            #0xd5d818
    //     0xd5d814: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5d818: ldur            x0, [fp, #-8]
    // 0xd5d81c: r16 = RequestFocusIntent
    //     0xd5d81c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3408] Type: RequestFocusIntent
    //     0xd5d820: ldr             x16, [x16, #0x408]
    // 0xd5d824: StoreField: r0->field_1f = r16
    //     0xd5d824: stur            w16, [x0, #0x1f]
    // 0xd5d828: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d828: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d82c: ldr             x1, [x1, #0x7a0]
    // 0xd5d830: r0 = ObserverList()
    //     0xd5d830: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5d834: mov             x3, x0
    // 0xd5d838: r0 = false
    //     0xd5d838: add             x0, NULL, #0x30  ; false
    // 0xd5d83c: stur            x3, [fp, #-0x10]
    // 0xd5d840: StoreField: r3->field_f = r0
    //     0xd5d840: stur            w0, [x3, #0xf]
    // 0xd5d844: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d848: StoreField: r3->field_13 = r4
    //     0xd5d848: stur            w4, [x3, #0x13]
    // 0xd5d84c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d84c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d850: ldr             x1, [x1, #0x7a0]
    // 0xd5d854: r2 = 0
    //     0xd5d854: mov             x2, #0
    // 0xd5d858: r0 = _GrowableList()
    //     0xd5d858: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5d85c: ldur            x2, [fp, #-0x10]
    // 0xd5d860: StoreField: r2->field_b = r0
    //     0xd5d860: stur            w0, [x2, #0xb]
    //     0xd5d864: ldurb           w16, [x2, #-1]
    //     0xd5d868: ldurb           w17, [x0, #-1]
    //     0xd5d86c: and             x16, x17, x16, lsr #2
    //     0xd5d870: tst             x16, HEAP, lsr #32
    //     0xd5d874: b.eq            #0xd5d87c
    //     0xd5d878: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5d87c: r1 = <RequestFocusIntent>
    //     0xd5d87c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3410] TypeArguments: <RequestFocusIntent>
    //     0xd5d880: ldr             x1, [x1, #0x410]
    // 0xd5d884: r0 = RequestFocusAction()
    //     0xd5d884: bl              #0xd5dda4  ; AllocateRequestFocusActionStub -> RequestFocusAction (size=0x14)
    // 0xd5d888: mov             x1, x0
    // 0xd5d88c: ldur            x0, [fp, #-0x10]
    // 0xd5d890: StoreField: r1->field_b = r0
    //     0xd5d890: stur            w0, [x1, #0xb]
    // 0xd5d894: mov             x0, x1
    // 0xd5d898: ldur            x1, [fp, #-8]
    // 0xd5d89c: ArrayStore: r1[5] = r0  ; List_4
    //     0xd5d89c: add             x25, x1, #0x23
    //     0xd5d8a0: str             w0, [x25]
    //     0xd5d8a4: tbz             w0, #0, #0xd5d8c0
    //     0xd5d8a8: ldurb           w16, [x1, #-1]
    //     0xd5d8ac: ldurb           w17, [x0, #-1]
    //     0xd5d8b0: and             x16, x17, x16, lsr #2
    //     0xd5d8b4: tst             x16, HEAP, lsr #32
    //     0xd5d8b8: b.eq            #0xd5d8c0
    //     0xd5d8bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5d8c0: ldur            x0, [fp, #-8]
    // 0xd5d8c4: r16 = NextFocusIntent
    //     0xd5d8c4: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3418] Type: NextFocusIntent
    //     0xd5d8c8: ldr             x16, [x16, #0x418]
    // 0xd5d8cc: StoreField: r0->field_27 = r16
    //     0xd5d8cc: stur            w16, [x0, #0x27]
    // 0xd5d8d0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d8d0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d8d4: ldr             x1, [x1, #0x7a0]
    // 0xd5d8d8: r0 = ObserverList()
    //     0xd5d8d8: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5d8dc: mov             x3, x0
    // 0xd5d8e0: r0 = false
    //     0xd5d8e0: add             x0, NULL, #0x30  ; false
    // 0xd5d8e4: stur            x3, [fp, #-0x10]
    // 0xd5d8e8: StoreField: r3->field_f = r0
    //     0xd5d8e8: stur            w0, [x3, #0xf]
    // 0xd5d8ec: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d8f0: StoreField: r3->field_13 = r4
    //     0xd5d8f0: stur            w4, [x3, #0x13]
    // 0xd5d8f4: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d8f4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d8f8: ldr             x1, [x1, #0x7a0]
    // 0xd5d8fc: r2 = 0
    //     0xd5d8fc: mov             x2, #0
    // 0xd5d900: r0 = _GrowableList()
    //     0xd5d900: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5d904: ldur            x2, [fp, #-0x10]
    // 0xd5d908: StoreField: r2->field_b = r0
    //     0xd5d908: stur            w0, [x2, #0xb]
    //     0xd5d90c: ldurb           w16, [x2, #-1]
    //     0xd5d910: ldurb           w17, [x0, #-1]
    //     0xd5d914: and             x16, x17, x16, lsr #2
    //     0xd5d918: tst             x16, HEAP, lsr #32
    //     0xd5d91c: b.eq            #0xd5d924
    //     0xd5d920: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5d924: r1 = <NextFocusIntent>
    //     0xd5d924: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3420] TypeArguments: <NextFocusIntent>
    //     0xd5d928: ldr             x1, [x1, #0x420]
    // 0xd5d92c: r0 = NextFocusAction()
    //     0xd5d92c: bl              #0xd5dd98  ; AllocateNextFocusActionStub -> NextFocusAction (size=0x14)
    // 0xd5d930: mov             x1, x0
    // 0xd5d934: ldur            x0, [fp, #-0x10]
    // 0xd5d938: StoreField: r1->field_b = r0
    //     0xd5d938: stur            w0, [x1, #0xb]
    // 0xd5d93c: mov             x0, x1
    // 0xd5d940: ldur            x1, [fp, #-8]
    // 0xd5d944: ArrayStore: r1[7] = r0  ; List_4
    //     0xd5d944: add             x25, x1, #0x2b
    //     0xd5d948: str             w0, [x25]
    //     0xd5d94c: tbz             w0, #0, #0xd5d968
    //     0xd5d950: ldurb           w16, [x1, #-1]
    //     0xd5d954: ldurb           w17, [x0, #-1]
    //     0xd5d958: and             x16, x17, x16, lsr #2
    //     0xd5d95c: tst             x16, HEAP, lsr #32
    //     0xd5d960: b.eq            #0xd5d968
    //     0xd5d964: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5d968: ldur            x0, [fp, #-8]
    // 0xd5d96c: r16 = PreviousFocusIntent
    //     0xd5d96c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3428] Type: PreviousFocusIntent
    //     0xd5d970: ldr             x16, [x16, #0x428]
    // 0xd5d974: StoreField: r0->field_2f = r16
    //     0xd5d974: stur            w16, [x0, #0x2f]
    // 0xd5d978: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d978: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d97c: ldr             x1, [x1, #0x7a0]
    // 0xd5d980: r0 = ObserverList()
    //     0xd5d980: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5d984: mov             x3, x0
    // 0xd5d988: r0 = false
    //     0xd5d988: add             x0, NULL, #0x30  ; false
    // 0xd5d98c: stur            x3, [fp, #-0x10]
    // 0xd5d990: StoreField: r3->field_f = r0
    //     0xd5d990: stur            w0, [x3, #0xf]
    // 0xd5d994: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5d998: StoreField: r3->field_13 = r4
    //     0xd5d998: stur            w4, [x3, #0x13]
    // 0xd5d99c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5d99c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5d9a0: ldr             x1, [x1, #0x7a0]
    // 0xd5d9a4: r2 = 0
    //     0xd5d9a4: mov             x2, #0
    // 0xd5d9a8: r0 = _GrowableList()
    //     0xd5d9a8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5d9ac: ldur            x2, [fp, #-0x10]
    // 0xd5d9b0: StoreField: r2->field_b = r0
    //     0xd5d9b0: stur            w0, [x2, #0xb]
    //     0xd5d9b4: ldurb           w16, [x2, #-1]
    //     0xd5d9b8: ldurb           w17, [x0, #-1]
    //     0xd5d9bc: and             x16, x17, x16, lsr #2
    //     0xd5d9c0: tst             x16, HEAP, lsr #32
    //     0xd5d9c4: b.eq            #0xd5d9cc
    //     0xd5d9c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5d9cc: r1 = <PreviousFocusIntent>
    //     0xd5d9cc: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3430] TypeArguments: <PreviousFocusIntent>
    //     0xd5d9d0: ldr             x1, [x1, #0x430]
    // 0xd5d9d4: r0 = PreviousFocusAction()
    //     0xd5d9d4: bl              #0xd5dd8c  ; AllocatePreviousFocusActionStub -> PreviousFocusAction (size=0x14)
    // 0xd5d9d8: mov             x1, x0
    // 0xd5d9dc: ldur            x0, [fp, #-0x10]
    // 0xd5d9e0: StoreField: r1->field_b = r0
    //     0xd5d9e0: stur            w0, [x1, #0xb]
    // 0xd5d9e4: mov             x0, x1
    // 0xd5d9e8: ldur            x1, [fp, #-8]
    // 0xd5d9ec: ArrayStore: r1[9] = r0  ; List_4
    //     0xd5d9ec: add             x25, x1, #0x33
    //     0xd5d9f0: str             w0, [x25]
    //     0xd5d9f4: tbz             w0, #0, #0xd5da10
    //     0xd5d9f8: ldurb           w16, [x1, #-1]
    //     0xd5d9fc: ldurb           w17, [x0, #-1]
    //     0xd5da00: and             x16, x17, x16, lsr #2
    //     0xd5da04: tst             x16, HEAP, lsr #32
    //     0xd5da08: b.eq            #0xd5da10
    //     0xd5da0c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5da10: ldur            x0, [fp, #-8]
    // 0xd5da14: r16 = DirectionalFocusIntent
    //     0xd5da14: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3040] Type: DirectionalFocusIntent
    //     0xd5da18: ldr             x16, [x16, #0x40]
    // 0xd5da1c: StoreField: r0->field_37 = r16
    //     0xd5da1c: stur            w16, [x0, #0x37]
    // 0xd5da20: r1 = <DirectionalFocusIntent>
    //     0xd5da20: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3048] TypeArguments: <DirectionalFocusIntent>
    //     0xd5da24: ldr             x1, [x1, #0x48]
    // 0xd5da28: r0 = DirectionalFocusAction()
    //     0xd5da28: bl              #0xd5dd80  ; AllocateDirectionalFocusActionStub -> DirectionalFocusAction (size=0x18)
    // 0xd5da2c: mov             x1, x0
    // 0xd5da30: stur            x0, [fp, #-0x10]
    // 0xd5da34: r0 = DirectionalFocusAction()
    //     0xd5da34: bl              #0xd5dcc8  ; [package:flutter/src/widgets/focus_traversal.dart] DirectionalFocusAction::DirectionalFocusAction
    // 0xd5da38: ldur            x1, [fp, #-8]
    // 0xd5da3c: ldur            x0, [fp, #-0x10]
    // 0xd5da40: ArrayStore: r1[11] = r0  ; List_4
    //     0xd5da40: add             x25, x1, #0x3b
    //     0xd5da44: str             w0, [x25]
    //     0xd5da48: tbz             w0, #0, #0xd5da64
    //     0xd5da4c: ldurb           w16, [x1, #-1]
    //     0xd5da50: ldurb           w17, [x0, #-1]
    //     0xd5da54: and             x16, x17, x16, lsr #2
    //     0xd5da58: tst             x16, HEAP, lsr #32
    //     0xd5da5c: b.eq            #0xd5da64
    //     0xd5da60: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5da64: ldur            x0, [fp, #-8]
    // 0xd5da68: r16 = ScrollIntent
    //     0xd5da68: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3110] Type: ScrollIntent
    //     0xd5da6c: ldr             x16, [x16, #0x110]
    // 0xd5da70: StoreField: r0->field_3f = r16
    //     0xd5da70: stur            w16, [x0, #0x3f]
    // 0xd5da74: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5da74: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5da78: ldr             x1, [x1, #0x7a0]
    // 0xd5da7c: r0 = ObserverList()
    //     0xd5da7c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5da80: mov             x3, x0
    // 0xd5da84: r0 = false
    //     0xd5da84: add             x0, NULL, #0x30  ; false
    // 0xd5da88: stur            x3, [fp, #-0x10]
    // 0xd5da8c: StoreField: r3->field_f = r0
    //     0xd5da8c: stur            w0, [x3, #0xf]
    // 0xd5da90: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5da94: StoreField: r3->field_13 = r4
    //     0xd5da94: stur            w4, [x3, #0x13]
    // 0xd5da98: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5da98: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5da9c: ldr             x1, [x1, #0x7a0]
    // 0xd5daa0: r2 = 0
    //     0xd5daa0: mov             x2, #0
    // 0xd5daa4: r0 = _GrowableList()
    //     0xd5daa4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5daa8: ldur            x2, [fp, #-0x10]
    // 0xd5daac: StoreField: r2->field_b = r0
    //     0xd5daac: stur            w0, [x2, #0xb]
    //     0xd5dab0: ldurb           w16, [x2, #-1]
    //     0xd5dab4: ldurb           w17, [x0, #-1]
    //     0xd5dab8: and             x16, x17, x16, lsr #2
    //     0xd5dabc: tst             x16, HEAP, lsr #32
    //     0xd5dac0: b.eq            #0xd5dac8
    //     0xd5dac4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5dac8: r1 = <ScrollIntent>
    //     0xd5dac8: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3118] TypeArguments: <ScrollIntent>
    //     0xd5dacc: ldr             x1, [x1, #0x118]
    // 0xd5dad0: r0 = ScrollAction()
    //     0xd5dad0: bl              #0xd5cd64  ; AllocateScrollActionStub -> ScrollAction (size=0x14)
    // 0xd5dad4: mov             x1, x0
    // 0xd5dad8: ldur            x0, [fp, #-0x10]
    // 0xd5dadc: StoreField: r1->field_b = r0
    //     0xd5dadc: stur            w0, [x1, #0xb]
    // 0xd5dae0: mov             x0, x1
    // 0xd5dae4: ldur            x1, [fp, #-8]
    // 0xd5dae8: ArrayStore: r1[13] = r0  ; List_4
    //     0xd5dae8: add             x25, x1, #0x43
    //     0xd5daec: str             w0, [x25]
    //     0xd5daf0: tbz             w0, #0, #0xd5db0c
    //     0xd5daf4: ldurb           w16, [x1, #-1]
    //     0xd5daf8: ldurb           w17, [x0, #-1]
    //     0xd5dafc: and             x16, x17, x16, lsr #2
    //     0xd5db00: tst             x16, HEAP, lsr #32
    //     0xd5db04: b.eq            #0xd5db0c
    //     0xd5db08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5db0c: ldur            x0, [fp, #-8]
    // 0xd5db10: r16 = PrioritizedIntents
    //     0xd5db10: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3438] Type: PrioritizedIntents
    //     0xd5db14: ldr             x16, [x16, #0x438]
    // 0xd5db18: StoreField: r0->field_47 = r16
    //     0xd5db18: stur            w16, [x0, #0x47]
    // 0xd5db1c: r1 = <PrioritizedIntents>
    //     0xd5db1c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3440] TypeArguments: <PrioritizedIntents>
    //     0xd5db20: ldr             x1, [x1, #0x440]
    // 0xd5db24: r0 = PrioritizedAction()
    //     0xd5db24: bl              #0xd5dcbc  ; AllocatePrioritizedActionStub -> PrioritizedAction (size=0x1c)
    // 0xd5db28: mov             x2, x0
    // 0xd5db2c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5db30: stur            x2, [fp, #-0x10]
    // 0xd5db34: StoreField: r2->field_13 = r0
    //     0xd5db34: stur            w0, [x2, #0x13]
    // 0xd5db38: ArrayStore: r2[0] = r0  ; List_4
    //     0xd5db38: stur            w0, [x2, #0x17]
    // 0xd5db3c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5db3c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5db40: ldr             x1, [x1, #0x7a0]
    // 0xd5db44: r0 = ObserverList()
    //     0xd5db44: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5db48: mov             x3, x0
    // 0xd5db4c: r0 = false
    //     0xd5db4c: add             x0, NULL, #0x30  ; false
    // 0xd5db50: stur            x3, [fp, #-0x18]
    // 0xd5db54: StoreField: r3->field_f = r0
    //     0xd5db54: stur            w0, [x3, #0xf]
    // 0xd5db58: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5db5c: StoreField: r3->field_13 = r4
    //     0xd5db5c: stur            w4, [x3, #0x13]
    // 0xd5db60: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5db60: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5db64: ldr             x1, [x1, #0x7a0]
    // 0xd5db68: r2 = 0
    //     0xd5db68: mov             x2, #0
    // 0xd5db6c: r0 = _GrowableList()
    //     0xd5db6c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5db70: ldur            x1, [fp, #-0x18]
    // 0xd5db74: StoreField: r1->field_b = r0
    //     0xd5db74: stur            w0, [x1, #0xb]
    //     0xd5db78: ldurb           w16, [x1, #-1]
    //     0xd5db7c: ldurb           w17, [x0, #-1]
    //     0xd5db80: and             x16, x17, x16, lsr #2
    //     0xd5db84: tst             x16, HEAP, lsr #32
    //     0xd5db88: b.eq            #0xd5db90
    //     0xd5db8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5db90: mov             x0, x1
    // 0xd5db94: ldur            x1, [fp, #-0x10]
    // 0xd5db98: StoreField: r1->field_b = r0
    //     0xd5db98: stur            w0, [x1, #0xb]
    //     0xd5db9c: ldurb           w16, [x1, #-1]
    //     0xd5dba0: ldurb           w17, [x0, #-1]
    //     0xd5dba4: and             x16, x17, x16, lsr #2
    //     0xd5dba8: tst             x16, HEAP, lsr #32
    //     0xd5dbac: b.eq            #0xd5dbb4
    //     0xd5dbb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5dbb4: mov             x0, x1
    // 0xd5dbb8: ldur            x1, [fp, #-8]
    // 0xd5dbbc: ArrayStore: r1[15] = r0  ; List_4
    //     0xd5dbbc: add             x25, x1, #0x4b
    //     0xd5dbc0: str             w0, [x25]
    //     0xd5dbc4: tbz             w0, #0, #0xd5dbe0
    //     0xd5dbc8: ldurb           w16, [x1, #-1]
    //     0xd5dbcc: ldurb           w17, [x0, #-1]
    //     0xd5dbd0: and             x16, x17, x16, lsr #2
    //     0xd5dbd4: tst             x16, HEAP, lsr #32
    //     0xd5dbd8: b.eq            #0xd5dbe0
    //     0xd5dbdc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5dbe0: ldur            x0, [fp, #-8]
    // 0xd5dbe4: r16 = VoidCallbackIntent
    //     0xd5dbe4: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3448] Type: VoidCallbackIntent
    //     0xd5dbe8: ldr             x16, [x16, #0x448]
    // 0xd5dbec: StoreField: r0->field_4f = r16
    //     0xd5dbec: stur            w16, [x0, #0x4f]
    // 0xd5dbf0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5dbf0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5dbf4: ldr             x1, [x1, #0x7a0]
    // 0xd5dbf8: r0 = ObserverList()
    //     0xd5dbf8: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd5dbfc: mov             x3, x0
    // 0xd5dc00: r0 = false
    //     0xd5dc00: add             x0, NULL, #0x30  ; false
    // 0xd5dc04: stur            x3, [fp, #-0x10]
    // 0xd5dc08: StoreField: r3->field_f = r0
    //     0xd5dc08: stur            w0, [x3, #0xf]
    // 0xd5dc0c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5dc10: StoreField: r3->field_13 = r0
    //     0xd5dc10: stur            w0, [x3, #0x13]
    // 0xd5dc14: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd5dc14: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd5dc18: ldr             x1, [x1, #0x7a0]
    // 0xd5dc1c: r2 = 0
    //     0xd5dc1c: mov             x2, #0
    // 0xd5dc20: r0 = _GrowableList()
    //     0xd5dc20: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd5dc24: ldur            x2, [fp, #-0x10]
    // 0xd5dc28: StoreField: r2->field_b = r0
    //     0xd5dc28: stur            w0, [x2, #0xb]
    //     0xd5dc2c: ldurb           w16, [x2, #-1]
    //     0xd5dc30: ldurb           w17, [x0, #-1]
    //     0xd5dc34: and             x16, x17, x16, lsr #2
    //     0xd5dc38: tst             x16, HEAP, lsr #32
    //     0xd5dc3c: b.eq            #0xd5dc44
    //     0xd5dc40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd5dc44: r1 = <VoidCallbackIntent>
    //     0xd5dc44: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3450] TypeArguments: <VoidCallbackIntent>
    //     0xd5dc48: ldr             x1, [x1, #0x450]
    // 0xd5dc4c: r0 = VoidCallbackAction()
    //     0xd5dc4c: bl              #0xd5dcb0  ; AllocateVoidCallbackActionStub -> VoidCallbackAction (size=0x14)
    // 0xd5dc50: mov             x1, x0
    // 0xd5dc54: ldur            x0, [fp, #-0x10]
    // 0xd5dc58: StoreField: r1->field_b = r0
    //     0xd5dc58: stur            w0, [x1, #0xb]
    // 0xd5dc5c: mov             x0, x1
    // 0xd5dc60: ldur            x1, [fp, #-8]
    // 0xd5dc64: ArrayStore: r1[17] = r0  ; List_4
    //     0xd5dc64: add             x25, x1, #0x53
    //     0xd5dc68: str             w0, [x25]
    //     0xd5dc6c: tbz             w0, #0, #0xd5dc88
    //     0xd5dc70: ldurb           w16, [x1, #-1]
    //     0xd5dc74: ldurb           w17, [x0, #-1]
    //     0xd5dc78: and             x16, x17, x16, lsr #2
    //     0xd5dc7c: tst             x16, HEAP, lsr #32
    //     0xd5dc80: b.eq            #0xd5dc88
    //     0xd5dc84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5dc88: r16 = <Type, Action<Intent>>
    //     0xd5dc88: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xd5dc8c: ldr             x16, [x16, #0xb80]
    // 0xd5dc90: ldur            lr, [fp, #-8]
    // 0xd5dc94: stp             lr, x16, [SP]
    // 0xd5dc98: r0 = Map._fromLiteral()
    //     0xd5dc98: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd5dc9c: LeaveFrame
    //     0xd5dc9c: mov             SP, fp
    //     0xd5dca0: ldp             fp, lr, [SP], #0x10
    // 0xd5dca4: ret
    //     0xd5dca4: ret             
    // 0xd5dca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5dca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5dcac: b               #0xd5d674
  }
  _ WidgetsApp(/* No info */) {
    // ** addr: 0xde7db4, size: 0x1d8
    // 0xde7db4: EnterFrame
    //     0xde7db4: stp             fp, lr, [SP, #-0x10]!
    //     0xde7db8: mov             fp, SP
    // 0xde7dbc: r11 = "/splash"
    //     0xde7dbc: add             x11, PP, #0x12, lsl #12  ; [pp+0x127d0] "/splash"
    //     0xde7dc0: ldr             x11, [x11, #0x7d0]
    // 0xde7dc4: r10 = _ConstMap len:0
    //     0xde7dc4: add             x10, PP, #0x12, lsl #12  ; [pp+0x127c8] Map<String, (dynamic this, BuildContext) => Widget>(0)
    //     0xde7dc8: ldr             x10, [x10, #0x7c8]
    // 0xde7dcc: r9 = Instance_TextStyle
    //     0xde7dcc: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8ca20] Obj!TextStyle@12b09a1
    //     0xde7dd0: ldr             x9, [x9, #0xa20]
    // 0xde7dd4: r8 = const [Instance of 'Locale', Instance of 'Locale']
    //     0xde7dd4: add             x8, PP, #0x12, lsl #12  ; [pp+0x127e8] List<Locale>(2)
    //     0xde7dd8: ldr             x8, [x8, #0x7e8]
    // 0xde7ddc: r4 = false
    //     0xde7ddc: add             x4, NULL, #0x30  ; false
    // 0xde7de0: ldr             x0, [fp, #0x38]
    // 0xde7de4: mov             x16, x7
    // 0xde7de8: mov             x7, x1
    // 0xde7dec: mov             x1, x16
    // 0xde7df0: mov             x16, x6
    // 0xde7df4: mov             x6, x2
    // 0xde7df8: mov             x2, x16
    // 0xde7dfc: mov             x16, x5
    // 0xde7e00: mov             x5, x3
    // 0xde7e04: mov             x3, x16
    // 0xde7e08: StoreField: r7->field_b = r0
    //     0xde7e08: stur            w0, [x7, #0xb]
    //     0xde7e0c: ldurb           w16, [x7, #-1]
    //     0xde7e10: ldurb           w17, [x0, #-1]
    //     0xde7e14: and             x16, x17, x16, lsr #2
    //     0xde7e18: tst             x16, HEAP, lsr #32
    //     0xde7e1c: b.eq            #0xde7e24
    //     0xde7e20: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7e24: ldr             x0, [fp, #0x20]
    // 0xde7e28: StoreField: r7->field_f = r0
    //     0xde7e28: stur            w0, [x7, #0xf]
    //     0xde7e2c: ldurb           w16, [x7, #-1]
    //     0xde7e30: ldurb           w17, [x0, #-1]
    //     0xde7e34: and             x16, x17, x16, lsr #2
    //     0xde7e38: tst             x16, HEAP, lsr #32
    //     0xde7e3c: b.eq            #0xde7e44
    //     0xde7e40: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7e44: ldr             x0, [fp, #0x28]
    // 0xde7e48: StoreField: r7->field_13 = r0
    //     0xde7e48: stur            w0, [x7, #0x13]
    //     0xde7e4c: ldurb           w16, [x7, #-1]
    //     0xde7e50: ldurb           w17, [x0, #-1]
    //     0xde7e54: and             x16, x17, x16, lsr #2
    //     0xde7e58: tst             x16, HEAP, lsr #32
    //     0xde7e5c: b.eq            #0xde7e64
    //     0xde7e60: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7e64: ldr             x0, [fp, #0x30]
    // 0xde7e68: StoreField: r7->field_37 = r0
    //     0xde7e68: stur            w0, [x7, #0x37]
    //     0xde7e6c: ldurb           w16, [x7, #-1]
    //     0xde7e70: ldurb           w17, [x0, #-1]
    //     0xde7e74: and             x16, x17, x16, lsr #2
    //     0xde7e78: tst             x16, HEAP, lsr #32
    //     0xde7e7c: b.eq            #0xde7e84
    //     0xde7e80: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7e84: StoreField: r7->field_33 = r11
    //     0xde7e84: stur            w11, [x7, #0x33]
    // 0xde7e88: ldr             x0, [fp, #0x18]
    // 0xde7e8c: ArrayStore: r7[0] = r0  ; List_4
    //     0xde7e8c: stur            w0, [x7, #0x17]
    //     0xde7e90: ldurb           w16, [x7, #-1]
    //     0xde7e94: ldurb           w17, [x0, #-1]
    //     0xde7e98: and             x16, x17, x16, lsr #2
    //     0xde7e9c: tst             x16, HEAP, lsr #32
    //     0xde7ea0: b.eq            #0xde7ea8
    //     0xde7ea4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7ea8: StoreField: r7->field_27 = r10
    //     0xde7ea8: stur            w10, [x7, #0x27]
    // 0xde7eac: mov             x0, x6
    // 0xde7eb0: StoreField: r7->field_3b = r0
    //     0xde7eb0: stur            w0, [x7, #0x3b]
    //     0xde7eb4: ldurb           w16, [x7, #-1]
    //     0xde7eb8: ldurb           w17, [x0, #-1]
    //     0xde7ebc: and             x16, x17, x16, lsr #2
    //     0xde7ec0: tst             x16, HEAP, lsr #32
    //     0xde7ec4: b.eq            #0xde7ecc
    //     0xde7ec8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7ecc: ldr             x0, [fp, #0x10]
    // 0xde7ed0: StoreField: r7->field_3f = r0
    //     0xde7ed0: stur            w0, [x7, #0x3f]
    //     0xde7ed4: ldurb           w16, [x7, #-1]
    //     0xde7ed8: ldurb           w17, [x0, #-1]
    //     0xde7edc: and             x16, x17, x16, lsr #2
    //     0xde7ee0: tst             x16, HEAP, lsr #32
    //     0xde7ee4: b.eq            #0xde7eec
    //     0xde7ee8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7eec: StoreField: r7->field_47 = r9
    //     0xde7eec: stur            w9, [x7, #0x47]
    // 0xde7ef0: mov             x0, x5
    // 0xde7ef4: StoreField: r7->field_4b = r0
    //     0xde7ef4: stur            w0, [x7, #0x4b]
    //     0xde7ef8: ldurb           w16, [x7, #-1]
    //     0xde7efc: ldurb           w17, [x0, #-1]
    //     0xde7f00: and             x16, x17, x16, lsr #2
    //     0xde7f04: tst             x16, HEAP, lsr #32
    //     0xde7f08: b.eq            #0xde7f10
    //     0xde7f0c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7f10: mov             x0, x2
    // 0xde7f14: StoreField: r7->field_4f = r0
    //     0xde7f14: stur            w0, [x7, #0x4f]
    //     0xde7f18: ldurb           w16, [x7, #-1]
    //     0xde7f1c: ldurb           w17, [x0, #-1]
    //     0xde7f20: and             x16, x17, x16, lsr #2
    //     0xde7f24: tst             x16, HEAP, lsr #32
    //     0xde7f28: b.eq            #0xde7f30
    //     0xde7f2c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7f30: mov             x0, x1
    // 0xde7f34: StoreField: r7->field_53 = r0
    //     0xde7f34: stur            w0, [x7, #0x53]
    //     0xde7f38: ldurb           w16, [x7, #-1]
    //     0xde7f3c: ldurb           w17, [x0, #-1]
    //     0xde7f40: and             x16, x17, x16, lsr #2
    //     0xde7f44: tst             x16, HEAP, lsr #32
    //     0xde7f48: b.eq            #0xde7f50
    //     0xde7f4c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7f50: StoreField: r7->field_5f = r8
    //     0xde7f50: stur            w8, [x7, #0x5f]
    // 0xde7f54: StoreField: r7->field_63 = r4
    //     0xde7f54: stur            w4, [x7, #0x63]
    // 0xde7f58: StoreField: r7->field_67 = r4
    //     0xde7f58: stur            w4, [x7, #0x67]
    // 0xde7f5c: mov             x0, x3
    // 0xde7f60: StoreField: r7->field_7 = r0
    //     0xde7f60: stur            w0, [x7, #7]
    //     0xde7f64: ldurb           w16, [x7, #-1]
    //     0xde7f68: ldurb           w17, [x0, #-1]
    //     0xde7f6c: and             x16, x17, x16, lsr #2
    //     0xde7f70: tst             x16, HEAP, lsr #32
    //     0xde7f74: b.eq            #0xde7f7c
    //     0xde7f78: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xde7f7c: r0 = Null
    //     0xde7f7c: mov             x0, NULL
    // 0xde7f80: LeaveFrame
    //     0xde7f80: mov             SP, fp
    //     0xde7f84: ldp             fp, lr, [SP], #0x10
    // 0xde7f88: ret
    //     0xde7f88: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa3834, size: 0x2c
    // 0xfa3834: EnterFrame
    //     0xfa3834: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3838: mov             fp, SP
    // 0xfa383c: mov             x0, x1
    // 0xfa3840: r1 = <WidgetsApp>
    //     0xfa3840: add             x1, PP, #0x98, lsl #12  ; [pp+0x98d50] TypeArguments: <WidgetsApp>
    //     0xfa3844: ldr             x1, [x1, #0xd50]
    // 0xfa3848: r0 = _WidgetsAppState()
    //     0xfa3848: bl              #0xfa3860  ; Allocate_WidgetsAppStateStub -> _WidgetsAppState (size=0x24)
    // 0xfa384c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3850: StoreField: r0->field_1f = r1
    //     0xfa3850: stur            w1, [x0, #0x1f]
    // 0xfa3854: LeaveFrame
    //     0xfa3854: mov             SP, fp
    //     0xfa3858: ldp             fp, lr, [SP], #0x10
    // 0xfa385c: ret
    //     0xfa385c: ret             
  }
}
