// lib: , url: package:flutter/src/widgets/container.dart

// class id: 1049123, size: 0x8
class :: {
}

// class id: 4307, size: 0x18, field offset: 0x10
class _DecorationClipper extends CustomClipper<dynamic> {

  _ shouldReclip(/* No info */) {
    // ** addr: 0x119dcb4, size: 0x1a8
    // 0x119dcb4: EnterFrame
    //     0x119dcb4: stp             fp, lr, [SP, #-0x10]!
    //     0x119dcb8: mov             fp, SP
    // 0x119dcbc: AllocStack(0x30)
    //     0x119dcbc: sub             SP, SP, #0x30
    // 0x119dcc0: SetupParameters(_DecorationClipper this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x119dcc0: mov             x4, x1
    //     0x119dcc4: mov             x3, x2
    //     0x119dcc8: stur            x1, [fp, #-8]
    //     0x119dccc: stur            x2, [fp, #-0x10]
    // 0x119dcd0: CheckStackOverflow
    //     0x119dcd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119dcd4: cmp             SP, x16
    //     0x119dcd8: b.ls            #0x119de54
    // 0x119dcdc: mov             x0, x3
    // 0x119dce0: r2 = Null
    //     0x119dce0: mov             x2, NULL
    // 0x119dce4: r1 = Null
    //     0x119dce4: mov             x1, NULL
    // 0x119dce8: r4 = 60
    //     0x119dce8: mov             x4, #0x3c
    // 0x119dcec: branchIfSmi(r0, 0x119dcf8)
    //     0x119dcec: tbz             w0, #0, #0x119dcf8
    // 0x119dcf0: r4 = LoadClassIdInstr(r0)
    //     0x119dcf0: ldur            x4, [x0, #-1]
    //     0x119dcf4: ubfx            x4, x4, #0xc, #0x14
    // 0x119dcf8: r17 = 4307
    //     0x119dcf8: mov             x17, #0x10d3
    // 0x119dcfc: cmp             x4, x17
    // 0x119dd00: b.eq            #0x119dd18
    // 0x119dd04: r8 = _DecorationClipper
    //     0x119dd04: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d190] Type: _DecorationClipper
    //     0x119dd08: ldr             x8, [x8, #0x190]
    // 0x119dd0c: r3 = Null
    //     0x119dd0c: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d198] Null
    //     0x119dd10: ldr             x3, [x3, #0x198]
    // 0x119dd14: r0 = DefaultTypeTest()
    //     0x119dd14: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x119dd18: ldur            x0, [fp, #-0x10]
    // 0x119dd1c: LoadField: r1 = r0->field_13
    //     0x119dd1c: ldur            w1, [x0, #0x13]
    // 0x119dd20: DecompressPointer r1
    //     0x119dd20: add             x1, x1, HEAP, lsl #32
    // 0x119dd24: ldur            x2, [fp, #-8]
    // 0x119dd28: stur            x1, [fp, #-0x20]
    // 0x119dd2c: LoadField: r3 = r2->field_13
    //     0x119dd2c: ldur            w3, [x2, #0x13]
    // 0x119dd30: DecompressPointer r3
    //     0x119dd30: add             x3, x3, HEAP, lsl #32
    // 0x119dd34: stur            x3, [fp, #-0x18]
    // 0x119dd38: r4 = LoadClassIdInstr(r1)
    //     0x119dd38: ldur            x4, [x1, #-1]
    //     0x119dd3c: ubfx            x4, x4, #0xc, #0x14
    // 0x119dd40: r17 = 5239
    //     0x119dd40: mov             x17, #0x1477
    // 0x119dd44: cmp             x4, x17
    // 0x119dd48: b.ne            #0x119dd5c
    // 0x119dd4c: cmp             w1, w3
    // 0x119dd50: b.ne            #0x119de14
    // 0x119dd54: mov             x1, x0
    // 0x119dd58: b               #0x119de24
    // 0x119dd5c: r17 = 5240
    //     0x119dd5c: mov             x17, #0x1478
    // 0x119dd60: cmp             x4, x17
    // 0x119dd64: b.ne            #0x119ddf0
    // 0x119dd68: str             x3, [SP]
    // 0x119dd6c: r0 = runtimeType()
    //     0x119dd6c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x119dd70: r1 = LoadClassIdInstr(r0)
    //     0x119dd70: ldur            x1, [x0, #-1]
    //     0x119dd74: ubfx            x1, x1, #0xc, #0x14
    // 0x119dd78: r16 = _CupertinoEdgeShadowDecoration
    //     0x119dd78: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d188] Type: _CupertinoEdgeShadowDecoration
    //     0x119dd7c: ldr             x16, [x16, #0x188]
    // 0x119dd80: stp             x16, x0, [SP]
    // 0x119dd84: mov             x0, x1
    // 0x119dd88: mov             lr, x0
    // 0x119dd8c: ldr             lr, [x21, lr, lsl #3]
    // 0x119dd90: blr             lr
    // 0x119dd94: tbnz            w0, #4, #0x119de14
    // 0x119dd98: ldur            x0, [fp, #-0x18]
    // 0x119dd9c: r1 = LoadClassIdInstr(r0)
    //     0x119dd9c: ldur            x1, [x0, #-1]
    //     0x119dda0: ubfx            x1, x1, #0xc, #0x14
    // 0x119dda4: r17 = 5240
    //     0x119dda4: mov             x17, #0x1478
    // 0x119dda8: cmp             x1, x17
    // 0x119ddac: b.ne            #0x119de14
    // 0x119ddb0: ldur            x1, [fp, #-0x20]
    // 0x119ddb4: LoadField: r2 = r0->field_7
    //     0x119ddb4: ldur            w2, [x0, #7]
    // 0x119ddb8: DecompressPointer r2
    //     0x119ddb8: add             x2, x2, HEAP, lsl #32
    // 0x119ddbc: LoadField: r0 = r1->field_7
    //     0x119ddbc: ldur            w0, [x1, #7]
    // 0x119ddc0: DecompressPointer r0
    //     0x119ddc0: add             x0, x0, HEAP, lsl #32
    // 0x119ddc4: r1 = LoadClassIdInstr(r2)
    //     0x119ddc4: ldur            x1, [x2, #-1]
    //     0x119ddc8: ubfx            x1, x1, #0xc, #0x14
    // 0x119ddcc: stp             x0, x2, [SP]
    // 0x119ddd0: mov             x0, x1
    // 0x119ddd4: mov             lr, x0
    // 0x119ddd8: ldr             lr, [x21, lr, lsl #3]
    // 0x119dddc: blr             lr
    // 0x119dde0: tbnz            w0, #4, #0x119de14
    // 0x119dde4: ldur            x2, [fp, #-8]
    // 0x119dde8: ldur            x1, [fp, #-0x10]
    // 0x119ddec: b               #0x119de24
    // 0x119ddf0: mov             x0, x3
    // 0x119ddf4: r2 = LoadClassIdInstr(r1)
    //     0x119ddf4: ldur            x2, [x1, #-1]
    //     0x119ddf8: ubfx            x2, x2, #0xc, #0x14
    // 0x119ddfc: stp             x0, x1, [SP]
    // 0x119de00: mov             x0, x2
    // 0x119de04: mov             lr, x0
    // 0x119de08: ldr             lr, [x21, lr, lsl #3]
    // 0x119de0c: blr             lr
    // 0x119de10: tbz             w0, #4, #0x119de1c
    // 0x119de14: r0 = true
    //     0x119de14: add             x0, NULL, #0x20  ; true
    // 0x119de18: b               #0x119de48
    // 0x119de1c: ldur            x2, [fp, #-8]
    // 0x119de20: ldur            x1, [fp, #-0x10]
    // 0x119de24: LoadField: r3 = r1->field_f
    //     0x119de24: ldur            w3, [x1, #0xf]
    // 0x119de28: DecompressPointer r3
    //     0x119de28: add             x3, x3, HEAP, lsl #32
    // 0x119de2c: LoadField: r1 = r2->field_f
    //     0x119de2c: ldur            w1, [x2, #0xf]
    // 0x119de30: DecompressPointer r1
    //     0x119de30: add             x1, x1, HEAP, lsl #32
    // 0x119de34: cmp             w3, w1
    // 0x119de38: r16 = true
    //     0x119de38: add             x16, NULL, #0x20  ; true
    // 0x119de3c: r17 = false
    //     0x119de3c: add             x17, NULL, #0x30  ; false
    // 0x119de40: csel            x2, x16, x17, ne
    // 0x119de44: mov             x0, x2
    // 0x119de48: LeaveFrame
    //     0x119de48: mov             SP, fp
    //     0x119de4c: ldp             fp, lr, [SP], #0x10
    // 0x119de50: ret
    //     0x119de50: ret             
    // 0x119de54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119de54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119de58: b               #0x119dcdc
  }
  _ getClip(/* No info */) {
    // ** addr: 0x11d63f8, size: 0x104
    // 0x11d63f8: EnterFrame
    //     0x11d63f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11d63fc: mov             fp, SP
    // 0x11d6400: AllocStack(0x18)
    //     0x11d6400: sub             SP, SP, #0x18
    // 0x11d6404: SetupParameters(_DecorationClipper this /* r1 => r0, fp-0x10 */)
    //     0x11d6404: mov             x0, x1
    //     0x11d6408: stur            x1, [fp, #-0x10]
    // 0x11d640c: CheckStackOverflow
    //     0x11d640c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d6410: cmp             SP, x16
    //     0x11d6414: b.ls            #0x11d64f4
    // 0x11d6418: LoadField: r3 = r0->field_13
    //     0x11d6418: ldur            w3, [x0, #0x13]
    // 0x11d641c: DecompressPointer r3
    //     0x11d641c: add             x3, x3, HEAP, lsl #32
    // 0x11d6420: stur            x3, [fp, #-8]
    // 0x11d6424: r1 = Instance_Offset
    //     0x11d6424: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11d6428: r0 = &()
    //     0x11d6428: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x11d642c: mov             x1, x0
    // 0x11d6430: ldur            x0, [fp, #-0x10]
    // 0x11d6434: LoadField: r3 = r0->field_f
    //     0x11d6434: ldur            w3, [x0, #0xf]
    // 0x11d6438: DecompressPointer r3
    //     0x11d6438: add             x3, x3, HEAP, lsl #32
    // 0x11d643c: ldur            x0, [fp, #-8]
    // 0x11d6440: r2 = LoadClassIdInstr(r0)
    //     0x11d6440: ldur            x2, [x0, #-1]
    //     0x11d6444: ubfx            x2, x2, #0xc, #0x14
    // 0x11d6448: r17 = 5237
    //     0x11d6448: mov             x17, #0x1475
    // 0x11d644c: cmp             x2, x17
    // 0x11d6450: b.ne            #0x11d648c
    // 0x11d6454: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x11d6454: ldur            w2, [x0, #0x17]
    // 0x11d6458: DecompressPointer r2
    //     0x11d6458: add             x2, x2, HEAP, lsl #32
    // 0x11d645c: r0 = LoadClassIdInstr(r2)
    //     0x11d645c: ldur            x0, [x2, #-1]
    //     0x11d6460: ubfx            x0, x0, #0xc, #0x14
    // 0x11d6464: str             x3, [SP]
    // 0x11d6468: mov             x16, x1
    // 0x11d646c: mov             x1, x2
    // 0x11d6470: mov             x2, x16
    // 0x11d6474: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x11d6474: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x11d6478: ldr             x4, [x4, #0x638]
    // 0x11d647c: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x11d647c: sub             lr, x0, #0xfc1
    //     0x11d6480: ldr             lr, [x21, lr, lsl #3]
    //     0x11d6484: blr             lr
    // 0x11d6488: b               #0x11d64c8
    // 0x11d648c: r17 = 5240
    //     0x11d648c: mov             x17, #0x1478
    // 0x11d6490: cmp             x2, x17
    // 0x11d6494: b.eq            #0x11d64d4
    // 0x11d6498: r2 = LoadClassIdInstr(r0)
    //     0x11d6498: ldur            x2, [x0, #-1]
    //     0x11d649c: ubfx            x2, x2, #0xc, #0x14
    // 0x11d64a0: mov             x16, x1
    // 0x11d64a4: mov             x1, x2
    // 0x11d64a8: mov             x2, x16
    // 0x11d64ac: mov             x16, x0
    // 0x11d64b0: mov             x0, x1
    // 0x11d64b4: mov             x1, x16
    // 0x11d64b8: r0 = GDT[cid_x0 + 0x2b2e]()
    //     0x11d64b8: mov             x17, #0x2b2e
    //     0x11d64bc: add             lr, x0, x17
    //     0x11d64c0: ldr             lr, [x21, lr, lsl #3]
    //     0x11d64c4: blr             lr
    // 0x11d64c8: LeaveFrame
    //     0x11d64c8: mov             SP, fp
    //     0x11d64cc: ldp             fp, lr, [SP], #0x10
    // 0x11d64d0: ret
    //     0x11d64d0: ret             
    // 0x11d64d4: r0 = UnsupportedError()
    //     0x11d64d4: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x11d64d8: mov             x1, x0
    // 0x11d64dc: r0 = "This Decoration subclass does not expect to be used for clipping."
    //     0x11d64dc: add             x0, PP, #0x97, lsl #12  ; [pp+0x97640] "This Decoration subclass does not expect to be used for clipping."
    //     0x11d64e0: ldr             x0, [x0, #0x640]
    // 0x11d64e4: StoreField: r1->field_b = r0
    //     0x11d64e4: stur            w0, [x1, #0xb]
    // 0x11d64e8: mov             x0, x1
    // 0x11d64ec: r0 = Throw()
    //     0x11d64ec: bl              #0x13ddb2c  ; ThrowStub
    // 0x11d64f0: brk             #0
    // 0x11d64f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d64f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d64f8: b               #0x11d6418
  }
}

// class id: 6121, size: 0x38, field offset: 0xc
class Container extends StatelessWidget {

  _ Container(/* No info */) {
    // ** addr: 0x8a54e0, size: 0x618
    // 0x8a54e0: EnterFrame
    //     0x8a54e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a54e4: mov             fp, SP
    // 0x8a54e8: AllocStack(0x28)
    //     0x8a54e8: sub             SP, SP, #0x28
    // 0x8a54ec: SetupParameters(Container this /* r1 => r1, fp-0x20 */, {dynamic alignment = Null /* r3 */, dynamic child = Null /* r5 */, dynamic clipBehavior = Instance_Clip /* r6 */, dynamic color = Null /* r7 */, dynamic constraints = Null /* r8 */, dynamic decoration = Null /* r9 */, dynamic foregroundDecoration = Null /* r10 */, dynamic height = Null /* r11, fp-0x18 */, dynamic key = Null /* r12, fp-0x10 */, dynamic margin = Null /* r13 */, dynamic padding = Null /* r14 */, dynamic width = Null /* r4 */})
    //     0x8a54ec: stur            x1, [fp, #-0x20]
    //     0x8a54f0: ldur            w0, [x4, #0x13]
    //     0x8a54f4: ldur            w2, [x4, #0x1f]
    //     0x8a54f8: add             x2, x2, HEAP, lsl #32
    //     0x8a54fc: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0x8a5500: cmp             w2, w16
    //     0x8a5504: b.ne            #0x8a5528
    //     0x8a5508: ldur            w2, [x4, #0x23]
    //     0x8a550c: add             x2, x2, HEAP, lsl #32
    //     0x8a5510: sub             w3, w0, w2
    //     0x8a5514: add             x2, fp, w3, sxtw #2
    //     0x8a5518: ldr             x2, [x2, #8]
    //     0x8a551c: mov             x3, x2
    //     0x8a5520: mov             x2, #1
    //     0x8a5524: b               #0x8a5530
    //     0x8a5528: mov             x3, NULL
    //     0x8a552c: mov             x2, #0
    //     0x8a5530: lsl             x5, x2, #1
    //     0x8a5534: lsl             w6, w5, #1
    //     0x8a5538: add             w7, w6, #8
    //     0x8a553c: add             x16, x4, w7, sxtw #1
    //     0x8a5540: ldur            w8, [x16, #0xf]
    //     0x8a5544: add             x8, x8, HEAP, lsl #32
    //     0x8a5548: add             x16, PP, #0x15, lsl #12  ; [pp+0x15108] "child"
    //     0x8a554c: ldr             x16, [x16, #0x108]
    //     0x8a5550: cmp             w8, w16
    //     0x8a5554: b.ne            #0x8a5588
    //     0x8a5558: add             w2, w6, #0xa
    //     0x8a555c: add             x16, x4, w2, sxtw #1
    //     0x8a5560: ldur            w6, [x16, #0xf]
    //     0x8a5564: add             x6, x6, HEAP, lsl #32
    //     0x8a5568: sub             w2, w0, w6
    //     0x8a556c: add             x6, fp, w2, sxtw #2
    //     0x8a5570: ldr             x6, [x6, #8]
    //     0x8a5574: add             w2, w5, #2
    //     0x8a5578: sbfx            x5, x2, #1, #0x1f
    //     0x8a557c: mov             x2, x5
    //     0x8a5580: mov             x5, x6
    //     0x8a5584: b               #0x8a558c
    //     0x8a5588: mov             x5, NULL
    //     0x8a558c: lsl             x6, x2, #1
    //     0x8a5590: lsl             w7, w6, #1
    //     0x8a5594: add             w8, w7, #8
    //     0x8a5598: add             x16, x4, w8, sxtw #1
    //     0x8a559c: ldur            w9, [x16, #0xf]
    //     0x8a55a0: add             x9, x9, HEAP, lsl #32
    //     0x8a55a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15988] "clipBehavior"
    //     0x8a55a8: ldr             x16, [x16, #0x988]
    //     0x8a55ac: cmp             w9, w16
    //     0x8a55b0: b.ne            #0x8a55e4
    //     0x8a55b4: add             w2, w7, #0xa
    //     0x8a55b8: add             x16, x4, w2, sxtw #1
    //     0x8a55bc: ldur            w7, [x16, #0xf]
    //     0x8a55c0: add             x7, x7, HEAP, lsl #32
    //     0x8a55c4: sub             w2, w0, w7
    //     0x8a55c8: add             x7, fp, w2, sxtw #2
    //     0x8a55cc: ldr             x7, [x7, #8]
    //     0x8a55d0: add             w2, w6, #2
    //     0x8a55d4: sbfx            x6, x2, #1, #0x1f
    //     0x8a55d8: mov             x2, x6
    //     0x8a55dc: mov             x6, x7
    //     0x8a55e0: b               #0x8a55ec
    //     0x8a55e4: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x8a55e8: ldr             x6, [x6, #0x840]
    //     0x8a55ec: lsl             x7, x2, #1
    //     0x8a55f0: lsl             w8, w7, #1
    //     0x8a55f4: add             w9, w8, #8
    //     0x8a55f8: add             x16, x4, w9, sxtw #1
    //     0x8a55fc: ldur            w10, [x16, #0xf]
    //     0x8a5600: add             x10, x10, HEAP, lsl #32
    //     0x8a5604: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0x8a5608: cmp             w10, w16
    //     0x8a560c: b.ne            #0x8a5640
    //     0x8a5610: add             w2, w8, #0xa
    //     0x8a5614: add             x16, x4, w2, sxtw #1
    //     0x8a5618: ldur            w8, [x16, #0xf]
    //     0x8a561c: add             x8, x8, HEAP, lsl #32
    //     0x8a5620: sub             w2, w0, w8
    //     0x8a5624: add             x8, fp, w2, sxtw #2
    //     0x8a5628: ldr             x8, [x8, #8]
    //     0x8a562c: add             w2, w7, #2
    //     0x8a5630: sbfx            x7, x2, #1, #0x1f
    //     0x8a5634: mov             x2, x7
    //     0x8a5638: mov             x7, x8
    //     0x8a563c: b               #0x8a5644
    //     0x8a5640: mov             x7, NULL
    //     0x8a5644: lsl             x8, x2, #1
    //     0x8a5648: lsl             w9, w8, #1
    //     0x8a564c: add             w10, w9, #8
    //     0x8a5650: add             x16, x4, w10, sxtw #1
    //     0x8a5654: ldur            w11, [x16, #0xf]
    //     0x8a5658: add             x11, x11, HEAP, lsl #32
    //     0x8a565c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15990] "constraints"
    //     0x8a5660: ldr             x16, [x16, #0x990]
    //     0x8a5664: cmp             w11, w16
    //     0x8a5668: b.ne            #0x8a569c
    //     0x8a566c: add             w2, w9, #0xa
    //     0x8a5670: add             x16, x4, w2, sxtw #1
    //     0x8a5674: ldur            w9, [x16, #0xf]
    //     0x8a5678: add             x9, x9, HEAP, lsl #32
    //     0x8a567c: sub             w2, w0, w9
    //     0x8a5680: add             x9, fp, w2, sxtw #2
    //     0x8a5684: ldr             x9, [x9, #8]
    //     0x8a5688: add             w2, w8, #2
    //     0x8a568c: sbfx            x8, x2, #1, #0x1f
    //     0x8a5690: mov             x2, x8
    //     0x8a5694: mov             x8, x9
    //     0x8a5698: b               #0x8a56a0
    //     0x8a569c: mov             x8, NULL
    //     0x8a56a0: lsl             x9, x2, #1
    //     0x8a56a4: lsl             w10, w9, #1
    //     0x8a56a8: add             w11, w10, #8
    //     0x8a56ac: add             x16, x4, w11, sxtw #1
    //     0x8a56b0: ldur            w12, [x16, #0xf]
    //     0x8a56b4: add             x12, x12, HEAP, lsl #32
    //     0x8a56b8: ldr             x16, [PP, #0x4a78]  ; [pp+0x4a78] "decoration"
    //     0x8a56bc: cmp             w12, w16
    //     0x8a56c0: b.ne            #0x8a56f4
    //     0x8a56c4: add             w2, w10, #0xa
    //     0x8a56c8: add             x16, x4, w2, sxtw #1
    //     0x8a56cc: ldur            w10, [x16, #0xf]
    //     0x8a56d0: add             x10, x10, HEAP, lsl #32
    //     0x8a56d4: sub             w2, w0, w10
    //     0x8a56d8: add             x10, fp, w2, sxtw #2
    //     0x8a56dc: ldr             x10, [x10, #8]
    //     0x8a56e0: add             w2, w9, #2
    //     0x8a56e4: sbfx            x9, x2, #1, #0x1f
    //     0x8a56e8: mov             x2, x9
    //     0x8a56ec: mov             x9, x10
    //     0x8a56f0: b               #0x8a56f8
    //     0x8a56f4: mov             x9, NULL
    //     0x8a56f8: lsl             x10, x2, #1
    //     0x8a56fc: lsl             w11, w10, #1
    //     0x8a5700: add             w12, w11, #8
    //     0x8a5704: add             x16, x4, w12, sxtw #1
    //     0x8a5708: ldur            w13, [x16, #0xf]
    //     0x8a570c: add             x13, x13, HEAP, lsl #32
    //     0x8a5710: add             x16, PP, #0x15, lsl #12  ; [pp+0x15998] "foregroundDecoration"
    //     0x8a5714: ldr             x16, [x16, #0x998]
    //     0x8a5718: cmp             w13, w16
    //     0x8a571c: b.ne            #0x8a5750
    //     0x8a5720: add             w2, w11, #0xa
    //     0x8a5724: add             x16, x4, w2, sxtw #1
    //     0x8a5728: ldur            w11, [x16, #0xf]
    //     0x8a572c: add             x11, x11, HEAP, lsl #32
    //     0x8a5730: sub             w2, w0, w11
    //     0x8a5734: add             x11, fp, w2, sxtw #2
    //     0x8a5738: ldr             x11, [x11, #8]
    //     0x8a573c: add             w2, w10, #2
    //     0x8a5740: sbfx            x10, x2, #1, #0x1f
    //     0x8a5744: mov             x2, x10
    //     0x8a5748: mov             x10, x11
    //     0x8a574c: b               #0x8a5754
    //     0x8a5750: mov             x10, NULL
    //     0x8a5754: lsl             x11, x2, #1
    //     0x8a5758: lsl             w12, w11, #1
    //     0x8a575c: add             w13, w12, #8
    //     0x8a5760: add             x16, x4, w13, sxtw #1
    //     0x8a5764: ldur            w14, [x16, #0xf]
    //     0x8a5768: add             x14, x14, HEAP, lsl #32
    //     0x8a576c: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    //     0x8a5770: cmp             w14, w16
    //     0x8a5774: b.ne            #0x8a57a8
    //     0x8a5778: add             w2, w12, #0xa
    //     0x8a577c: add             x16, x4, w2, sxtw #1
    //     0x8a5780: ldur            w12, [x16, #0xf]
    //     0x8a5784: add             x12, x12, HEAP, lsl #32
    //     0x8a5788: sub             w2, w0, w12
    //     0x8a578c: add             x12, fp, w2, sxtw #2
    //     0x8a5790: ldr             x12, [x12, #8]
    //     0x8a5794: add             w2, w11, #2
    //     0x8a5798: sbfx            x11, x2, #1, #0x1f
    //     0x8a579c: mov             x2, x11
    //     0x8a57a0: mov             x11, x12
    //     0x8a57a4: b               #0x8a57ac
    //     0x8a57a8: mov             x11, NULL
    //     0x8a57ac: stur            x11, [fp, #-0x18]
    //     0x8a57b0: lsl             x12, x2, #1
    //     0x8a57b4: lsl             w13, w12, #1
    //     0x8a57b8: add             w14, w13, #8
    //     0x8a57bc: add             x16, x4, w14, sxtw #1
    //     0x8a57c0: ldur            w19, [x16, #0xf]
    //     0x8a57c4: add             x19, x19, HEAP, lsl #32
    //     0x8a57c8: ldr             x16, [PP, #0xf18]  ; [pp+0xf18] "key"
    //     0x8a57cc: cmp             w19, w16
    //     0x8a57d0: b.ne            #0x8a5804
    //     0x8a57d4: add             w2, w13, #0xa
    //     0x8a57d8: add             x16, x4, w2, sxtw #1
    //     0x8a57dc: ldur            w13, [x16, #0xf]
    //     0x8a57e0: add             x13, x13, HEAP, lsl #32
    //     0x8a57e4: sub             w2, w0, w13
    //     0x8a57e8: add             x13, fp, w2, sxtw #2
    //     0x8a57ec: ldr             x13, [x13, #8]
    //     0x8a57f0: add             w2, w12, #2
    //     0x8a57f4: sbfx            x12, x2, #1, #0x1f
    //     0x8a57f8: mov             x2, x12
    //     0x8a57fc: mov             x12, x13
    //     0x8a5800: b               #0x8a5808
    //     0x8a5804: mov             x12, NULL
    //     0x8a5808: stur            x12, [fp, #-0x10]
    //     0x8a580c: lsl             x13, x2, #1
    //     0x8a5810: lsl             w14, w13, #1
    //     0x8a5814: add             w19, w14, #8
    //     0x8a5818: add             x16, x4, w19, sxtw #1
    //     0x8a581c: ldur            w20, [x16, #0xf]
    //     0x8a5820: add             x20, x20, HEAP, lsl #32
    //     0x8a5824: add             x16, PP, #0x15, lsl #12  ; [pp+0x159a0] "margin"
    //     0x8a5828: ldr             x16, [x16, #0x9a0]
    //     0x8a582c: cmp             w20, w16
    //     0x8a5830: b.ne            #0x8a5864
    //     0x8a5834: add             w2, w14, #0xa
    //     0x8a5838: add             x16, x4, w2, sxtw #1
    //     0x8a583c: ldur            w14, [x16, #0xf]
    //     0x8a5840: add             x14, x14, HEAP, lsl #32
    //     0x8a5844: sub             w2, w0, w14
    //     0x8a5848: add             x14, fp, w2, sxtw #2
    //     0x8a584c: ldr             x14, [x14, #8]
    //     0x8a5850: add             w2, w13, #2
    //     0x8a5854: sbfx            x13, x2, #1, #0x1f
    //     0x8a5858: mov             x2, x13
    //     0x8a585c: mov             x13, x14
    //     0x8a5860: b               #0x8a5868
    //     0x8a5864: mov             x13, NULL
    //     0x8a5868: lsl             x14, x2, #1
    //     0x8a586c: lsl             w19, w14, #1
    //     0x8a5870: add             w20, w19, #8
    //     0x8a5874: add             x16, x4, w20, sxtw #1
    //     0x8a5878: ldur            w23, [x16, #0xf]
    //     0x8a587c: add             x23, x23, HEAP, lsl #32
    //     0x8a5880: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0x8a5884: ldr             x16, [x16, #0x838]
    //     0x8a5888: cmp             w23, w16
    //     0x8a588c: b.ne            #0x8a58c0
    //     0x8a5890: add             w2, w19, #0xa
    //     0x8a5894: add             x16, x4, w2, sxtw #1
    //     0x8a5898: ldur            w19, [x16, #0xf]
    //     0x8a589c: add             x19, x19, HEAP, lsl #32
    //     0x8a58a0: sub             w2, w0, w19
    //     0x8a58a4: add             x19, fp, w2, sxtw #2
    //     0x8a58a8: ldr             x19, [x19, #8]
    //     0x8a58ac: add             w2, w14, #2
    //     0x8a58b0: sbfx            x14, x2, #1, #0x1f
    //     0x8a58b4: mov             x2, x14
    //     0x8a58b8: mov             x14, x19
    //     0x8a58bc: b               #0x8a58c4
    //     0x8a58c0: mov             x14, NULL
    //     0x8a58c4: lsl             x19, x2, #1
    //     0x8a58c8: lsl             w2, w19, #1
    //     0x8a58cc: add             w19, w2, #8
    //     0x8a58d0: add             x16, x4, w19, sxtw #1
    //     0x8a58d4: ldur            w20, [x16, #0xf]
    //     0x8a58d8: add             x20, x20, HEAP, lsl #32
    //     0x8a58dc: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    //     0x8a58e0: cmp             w20, w16
    //     0x8a58e4: b.ne            #0x8a590c
    //     0x8a58e8: add             w19, w2, #0xa
    //     0x8a58ec: add             x16, x4, w19, sxtw #1
    //     0x8a58f0: ldur            w2, [x16, #0xf]
    //     0x8a58f4: add             x2, x2, HEAP, lsl #32
    //     0x8a58f8: sub             w4, w0, w2
    //     0x8a58fc: add             x0, fp, w4, sxtw #2
    //     0x8a5900: ldr             x0, [x0, #8]
    //     0x8a5904: mov             x4, x0
    //     0x8a5908: b               #0x8a5910
    //     0x8a590c: mov             x4, NULL
    // 0x8a5910: r2 = true
    //     0x8a5910: add             x2, NULL, #0x20  ; true
    // 0x8a5914: mov             x0, x3
    // 0x8a5918: stur            x4, [fp, #-8]
    // 0x8a591c: StoreField: r1->field_f = r0
    //     0x8a591c: stur            w0, [x1, #0xf]
    //     0x8a5920: ldurb           w16, [x1, #-1]
    //     0x8a5924: ldurb           w17, [x0, #-1]
    //     0x8a5928: and             x16, x17, x16, lsr #2
    //     0x8a592c: tst             x16, HEAP, lsr #32
    //     0x8a5930: b.eq            #0x8a5938
    //     0x8a5934: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5938: mov             x0, x14
    // 0x8a593c: StoreField: r1->field_13 = r0
    //     0x8a593c: stur            w0, [x1, #0x13]
    //     0x8a5940: ldurb           w16, [x1, #-1]
    //     0x8a5944: ldurb           w17, [x0, #-1]
    //     0x8a5948: and             x16, x17, x16, lsr #2
    //     0x8a594c: tst             x16, HEAP, lsr #32
    //     0x8a5950: b.eq            #0x8a5958
    //     0x8a5954: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5958: mov             x0, x7
    // 0x8a595c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a595c: stur            w0, [x1, #0x17]
    //     0x8a5960: ldurb           w16, [x1, #-1]
    //     0x8a5964: ldurb           w17, [x0, #-1]
    //     0x8a5968: and             x16, x17, x16, lsr #2
    //     0x8a596c: tst             x16, HEAP, lsr #32
    //     0x8a5970: b.eq            #0x8a5978
    //     0x8a5974: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5978: StoreField: r1->field_1b = r2
    //     0x8a5978: stur            w2, [x1, #0x1b]
    // 0x8a597c: mov             x0, x9
    // 0x8a5980: StoreField: r1->field_1f = r0
    //     0x8a5980: stur            w0, [x1, #0x1f]
    //     0x8a5984: ldurb           w16, [x1, #-1]
    //     0x8a5988: ldurb           w17, [x0, #-1]
    //     0x8a598c: and             x16, x17, x16, lsr #2
    //     0x8a5990: tst             x16, HEAP, lsr #32
    //     0x8a5994: b.eq            #0x8a599c
    //     0x8a5998: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a599c: mov             x0, x10
    // 0x8a59a0: StoreField: r1->field_23 = r0
    //     0x8a59a0: stur            w0, [x1, #0x23]
    //     0x8a59a4: ldurb           w16, [x1, #-1]
    //     0x8a59a8: ldurb           w17, [x0, #-1]
    //     0x8a59ac: and             x16, x17, x16, lsr #2
    //     0x8a59b0: tst             x16, HEAP, lsr #32
    //     0x8a59b4: b.eq            #0x8a59bc
    //     0x8a59b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a59bc: mov             x0, x13
    // 0x8a59c0: StoreField: r1->field_2b = r0
    //     0x8a59c0: stur            w0, [x1, #0x2b]
    //     0x8a59c4: ldurb           w16, [x1, #-1]
    //     0x8a59c8: ldurb           w17, [x0, #-1]
    //     0x8a59cc: and             x16, x17, x16, lsr #2
    //     0x8a59d0: tst             x16, HEAP, lsr #32
    //     0x8a59d4: b.eq            #0x8a59dc
    //     0x8a59d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a59dc: mov             x0, x5
    // 0x8a59e0: StoreField: r1->field_b = r0
    //     0x8a59e0: stur            w0, [x1, #0xb]
    //     0x8a59e4: ldurb           w16, [x1, #-1]
    //     0x8a59e8: ldurb           w17, [x0, #-1]
    //     0x8a59ec: and             x16, x17, x16, lsr #2
    //     0x8a59f0: tst             x16, HEAP, lsr #32
    //     0x8a59f4: b.eq            #0x8a59fc
    //     0x8a59f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a59fc: mov             x0, x6
    // 0x8a5a00: StoreField: r1->field_33 = r0
    //     0x8a5a00: stur            w0, [x1, #0x33]
    //     0x8a5a04: ldurb           w16, [x1, #-1]
    //     0x8a5a08: ldurb           w17, [x0, #-1]
    //     0x8a5a0c: and             x16, x17, x16, lsr #2
    //     0x8a5a10: tst             x16, HEAP, lsr #32
    //     0x8a5a14: b.eq            #0x8a5a1c
    //     0x8a5a18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5a1c: cmp             w4, NULL
    // 0x8a5a20: b.ne            #0x8a5a2c
    // 0x8a5a24: cmp             w11, NULL
    // 0x8a5a28: b.eq            #0x8a5aa4
    // 0x8a5a2c: cmp             w4, NULL
    // 0x8a5a30: b.ne            #0x8a5a3c
    // 0x8a5a34: d0 = 0.000000
    //     0x8a5a34: eor             v0.16b, v0.16b, v0.16b
    // 0x8a5a38: b               #0x8a5a40
    // 0x8a5a3c: LoadField: d0 = r4->field_7
    //     0x8a5a3c: ldur            d0, [x4, #7]
    // 0x8a5a40: stur            d0, [fp, #-0x28]
    // 0x8a5a44: r0 = BoxConstraints()
    //     0x8a5a44: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x8a5a48: ldur            d0, [fp, #-0x28]
    // 0x8a5a4c: StoreField: r0->field_7 = d0
    //     0x8a5a4c: stur            d0, [x0, #7]
    // 0x8a5a50: ldur            x1, [fp, #-8]
    // 0x8a5a54: cmp             w1, NULL
    // 0x8a5a58: b.ne            #0x8a5a64
    // 0x8a5a5c: d0 = inf
    //     0x8a5a5c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x8a5a60: b               #0x8a5a68
    // 0x8a5a64: LoadField: d0 = r1->field_7
    //     0x8a5a64: ldur            d0, [x1, #7]
    // 0x8a5a68: ldur            x1, [fp, #-0x18]
    // 0x8a5a6c: StoreField: r0->field_f = d0
    //     0x8a5a6c: stur            d0, [x0, #0xf]
    // 0x8a5a70: cmp             w1, NULL
    // 0x8a5a74: b.ne            #0x8a5a80
    // 0x8a5a78: d0 = 0.000000
    //     0x8a5a78: eor             v0.16b, v0.16b, v0.16b
    // 0x8a5a7c: b               #0x8a5a84
    // 0x8a5a80: LoadField: d0 = r1->field_7
    //     0x8a5a80: ldur            d0, [x1, #7]
    // 0x8a5a84: ArrayStore: r0[0] = d0  ; List_8
    //     0x8a5a84: stur            d0, [x0, #0x17]
    // 0x8a5a88: cmp             w1, NULL
    // 0x8a5a8c: b.ne            #0x8a5a98
    // 0x8a5a90: d0 = inf
    //     0x8a5a90: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x8a5a94: b               #0x8a5a9c
    // 0x8a5a98: LoadField: d0 = r1->field_7
    //     0x8a5a98: ldur            d0, [x1, #7]
    // 0x8a5a9c: StoreField: r0->field_1f = d0
    //     0x8a5a9c: stur            d0, [x0, #0x1f]
    // 0x8a5aa0: b               #0x8a5aa8
    // 0x8a5aa4: mov             x0, x8
    // 0x8a5aa8: ldur            x1, [fp, #-0x20]
    // 0x8a5aac: StoreField: r1->field_27 = r0
    //     0x8a5aac: stur            w0, [x1, #0x27]
    //     0x8a5ab0: ldurb           w16, [x1, #-1]
    //     0x8a5ab4: ldurb           w17, [x0, #-1]
    //     0x8a5ab8: and             x16, x17, x16, lsr #2
    //     0x8a5abc: tst             x16, HEAP, lsr #32
    //     0x8a5ac0: b.eq            #0x8a5ac8
    //     0x8a5ac4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5ac8: ldur            x0, [fp, #-0x10]
    // 0x8a5acc: StoreField: r1->field_7 = r0
    //     0x8a5acc: stur            w0, [x1, #7]
    //     0x8a5ad0: ldurb           w16, [x1, #-1]
    //     0x8a5ad4: ldurb           w17, [x0, #-1]
    //     0x8a5ad8: and             x16, x17, x16, lsr #2
    //     0x8a5adc: tst             x16, HEAP, lsr #32
    //     0x8a5ae0: b.eq            #0x8a5ae8
    //     0x8a5ae4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a5ae8: r0 = Null
    //     0x8a5ae8: mov             x0, NULL
    // 0x8a5aec: LeaveFrame
    //     0x8a5aec: mov             SP, fp
    //     0x8a5af0: ldp             fp, lr, [SP], #0x10
    // 0x8a5af4: ret
    //     0x8a5af4: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xfbf668, size: 0x364
    // 0xfbf668: EnterFrame
    //     0xfbf668: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf66c: mov             fp, SP
    // 0xfbf670: AllocStack(0x30)
    //     0xfbf670: sub             SP, SP, #0x30
    // 0xfbf674: SetupParameters(Container this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfbf674: mov             x0, x1
    //     0xfbf678: stur            x1, [fp, #-8]
    //     0xfbf67c: mov             x1, x2
    //     0xfbf680: stur            x2, [fp, #-0x10]
    // 0xfbf684: CheckStackOverflow
    //     0xfbf684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf688: cmp             SP, x16
    //     0xfbf68c: b.ls            #0xfbf9bc
    // 0xfbf690: LoadField: r2 = r0->field_b
    //     0xfbf690: ldur            w2, [x0, #0xb]
    // 0xfbf694: DecompressPointer r2
    //     0xfbf694: add             x2, x2, HEAP, lsl #32
    // 0xfbf698: stur            x2, [fp, #-0x20]
    // 0xfbf69c: cmp             w2, NULL
    // 0xfbf6a0: b.ne            #0xfbf718
    // 0xfbf6a4: LoadField: r3 = r0->field_27
    //     0xfbf6a4: ldur            w3, [x0, #0x27]
    // 0xfbf6a8: DecompressPointer r3
    //     0xfbf6a8: add             x3, x3, HEAP, lsl #32
    // 0xfbf6ac: cmp             w3, NULL
    // 0xfbf6b0: b.eq            #0xfbf6e8
    // 0xfbf6b4: LoadField: d0 = r3->field_7
    //     0xfbf6b4: ldur            d0, [x3, #7]
    // 0xfbf6b8: LoadField: d1 = r3->field_f
    //     0xfbf6b8: ldur            d1, [x3, #0xf]
    // 0xfbf6bc: fcmp            d0, d1
    // 0xfbf6c0: b.lt            #0xfbf6e8
    // 0xfbf6c4: ArrayLoad: d0 = r3[0]  ; List_8
    //     0xfbf6c4: ldur            d0, [x3, #0x17]
    // 0xfbf6c8: LoadField: d1 = r3->field_1f
    //     0xfbf6c8: ldur            d1, [x3, #0x1f]
    // 0xfbf6cc: fcmp            d0, d1
    // 0xfbf6d0: r16 = true
    //     0xfbf6d0: add             x16, NULL, #0x20  ; true
    // 0xfbf6d4: r17 = false
    //     0xfbf6d4: add             x17, NULL, #0x30  ; false
    // 0xfbf6d8: csel            x3, x16, x17, ge
    // 0xfbf6dc: tbnz            w3, #4, #0xfbf6e8
    // 0xfbf6e0: mov             x1, x0
    // 0xfbf6e4: b               #0xfbf71c
    // 0xfbf6e8: r0 = ConstrainedBox()
    //     0xfbf6e8: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfbf6ec: mov             x1, x0
    // 0xfbf6f0: r0 = Instance_BoxConstraints
    //     0xfbf6f0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16ea8] Obj!BoxConstraints@129c1a1
    //     0xfbf6f4: ldr             x0, [x0, #0xea8]
    // 0xfbf6f8: stur            x1, [fp, #-0x18]
    // 0xfbf6fc: StoreField: r1->field_f = r0
    //     0xfbf6fc: stur            w0, [x1, #0xf]
    // 0xfbf700: r0 = LimitedBox()
    //     0xfbf700: bl              #0xd1a978  ; AllocateLimitedBoxStub -> LimitedBox (size=0x20)
    // 0xfbf704: StoreField: r0->field_f = rZR
    //     0xfbf704: stur            xzr, [x0, #0xf]
    // 0xfbf708: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfbf708: stur            xzr, [x0, #0x17]
    // 0xfbf70c: ldur            x1, [fp, #-0x18]
    // 0xfbf710: StoreField: r0->field_b = r1
    //     0xfbf710: stur            w1, [x0, #0xb]
    // 0xfbf714: b               #0xfbf754
    // 0xfbf718: ldur            x1, [fp, #-8]
    // 0xfbf71c: LoadField: r0 = r1->field_f
    //     0xfbf71c: ldur            w0, [x1, #0xf]
    // 0xfbf720: DecompressPointer r0
    //     0xfbf720: add             x0, x0, HEAP, lsl #32
    // 0xfbf724: stur            x0, [fp, #-0x18]
    // 0xfbf728: cmp             w0, NULL
    // 0xfbf72c: b.eq            #0xfbf750
    // 0xfbf730: r0 = Align()
    //     0xfbf730: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfbf734: mov             x1, x0
    // 0xfbf738: ldur            x0, [fp, #-0x18]
    // 0xfbf73c: StoreField: r1->field_f = r0
    //     0xfbf73c: stur            w0, [x1, #0xf]
    // 0xfbf740: ldur            x0, [fp, #-0x20]
    // 0xfbf744: StoreField: r1->field_b = r0
    //     0xfbf744: stur            w0, [x1, #0xb]
    // 0xfbf748: mov             x0, x1
    // 0xfbf74c: b               #0xfbf754
    // 0xfbf750: mov             x0, x2
    // 0xfbf754: ldur            x1, [fp, #-8]
    // 0xfbf758: stur            x0, [fp, #-0x18]
    // 0xfbf75c: r0 = _paddingIncludingDecoration()
    //     0xfbf75c: bl              #0xfbf9d8  ; [package:flutter/src/widgets/container.dart] Container::_paddingIncludingDecoration
    // 0xfbf760: stur            x0, [fp, #-0x20]
    // 0xfbf764: cmp             w0, NULL
    // 0xfbf768: b.eq            #0xfbf78c
    // 0xfbf76c: ldur            x1, [fp, #-0x18]
    // 0xfbf770: r0 = Padding()
    //     0xfbf770: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfbf774: mov             x1, x0
    // 0xfbf778: ldur            x0, [fp, #-0x20]
    // 0xfbf77c: StoreField: r1->field_f = r0
    //     0xfbf77c: stur            w0, [x1, #0xf]
    // 0xfbf780: ldur            x0, [fp, #-0x18]
    // 0xfbf784: StoreField: r1->field_b = r0
    //     0xfbf784: stur            w0, [x1, #0xb]
    // 0xfbf788: b               #0xfbf794
    // 0xfbf78c: ldur            x0, [fp, #-0x18]
    // 0xfbf790: mov             x1, x0
    // 0xfbf794: ldur            x0, [fp, #-8]
    // 0xfbf798: stur            x1, [fp, #-0x20]
    // 0xfbf79c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfbf79c: ldur            w2, [x0, #0x17]
    // 0xfbf7a0: DecompressPointer r2
    //     0xfbf7a0: add             x2, x2, HEAP, lsl #32
    // 0xfbf7a4: stur            x2, [fp, #-0x18]
    // 0xfbf7a8: cmp             w2, NULL
    // 0xfbf7ac: b.eq            #0xfbf7d8
    // 0xfbf7b0: r0 = ColoredBox()
    //     0xfbf7b0: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xfbf7b4: mov             x1, x0
    // 0xfbf7b8: ldur            x0, [fp, #-0x18]
    // 0xfbf7bc: StoreField: r1->field_f = r0
    //     0xfbf7bc: stur            w0, [x1, #0xf]
    // 0xfbf7c0: r0 = true
    //     0xfbf7c0: add             x0, NULL, #0x20  ; true
    // 0xfbf7c4: StoreField: r1->field_13 = r0
    //     0xfbf7c4: stur            w0, [x1, #0x13]
    // 0xfbf7c8: ldur            x0, [fp, #-0x20]
    // 0xfbf7cc: StoreField: r1->field_b = r0
    //     0xfbf7cc: stur            w0, [x1, #0xb]
    // 0xfbf7d0: mov             x2, x1
    // 0xfbf7d4: b               #0xfbf7e0
    // 0xfbf7d8: mov             x0, x1
    // 0xfbf7dc: mov             x2, x0
    // 0xfbf7e0: ldur            x0, [fp, #-8]
    // 0xfbf7e4: stur            x2, [fp, #-0x20]
    // 0xfbf7e8: LoadField: r3 = r0->field_33
    //     0xfbf7e8: ldur            w3, [x0, #0x33]
    // 0xfbf7ec: DecompressPointer r3
    //     0xfbf7ec: add             x3, x3, HEAP, lsl #32
    // 0xfbf7f0: stur            x3, [fp, #-0x18]
    // 0xfbf7f4: r16 = Instance_Clip
    //     0xfbf7f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbf7f8: ldr             x16, [x16, #0x840]
    // 0xfbf7fc: cmp             w3, w16
    // 0xfbf800: b.eq            #0xfbf890
    // 0xfbf804: ldur            x1, [fp, #-0x10]
    // 0xfbf808: r0 = maybeOf()
    //     0xfbf808: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xfbf80c: mov             x2, x0
    // 0xfbf810: ldur            x0, [fp, #-8]
    // 0xfbf814: stur            x2, [fp, #-0x28]
    // 0xfbf818: LoadField: r3 = r0->field_1f
    //     0xfbf818: ldur            w3, [x0, #0x1f]
    // 0xfbf81c: DecompressPointer r3
    //     0xfbf81c: add             x3, x3, HEAP, lsl #32
    // 0xfbf820: stur            x3, [fp, #-0x10]
    // 0xfbf824: cmp             w3, NULL
    // 0xfbf828: b.eq            #0xfbf9c4
    // 0xfbf82c: r1 = <Path>
    //     0xfbf82c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0xfbf830: ldr             x1, [x1, #0xa60]
    // 0xfbf834: r0 = _DecorationClipper()
    //     0xfbf834: bl              #0xfbf9cc  ; Allocate_DecorationClipperStub -> _DecorationClipper (size=0x18)
    // 0xfbf838: mov             x1, x0
    // 0xfbf83c: ldur            x0, [fp, #-0x10]
    // 0xfbf840: stur            x1, [fp, #-0x30]
    // 0xfbf844: StoreField: r1->field_13 = r0
    //     0xfbf844: stur            w0, [x1, #0x13]
    // 0xfbf848: ldur            x0, [fp, #-0x28]
    // 0xfbf84c: cmp             w0, NULL
    // 0xfbf850: b.ne            #0xfbf85c
    // 0xfbf854: r3 = Instance_TextDirection
    //     0xfbf854: ldr             x3, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xfbf858: b               #0xfbf860
    // 0xfbf85c: mov             x3, x0
    // 0xfbf860: ldur            x0, [fp, #-0x20]
    // 0xfbf864: ldur            x2, [fp, #-0x18]
    // 0xfbf868: StoreField: r1->field_f = r3
    //     0xfbf868: stur            w3, [x1, #0xf]
    // 0xfbf86c: r0 = ClipPath()
    //     0xfbf86c: bl              #0xb27f2c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0xfbf870: mov             x1, x0
    // 0xfbf874: ldur            x0, [fp, #-0x30]
    // 0xfbf878: StoreField: r1->field_f = r0
    //     0xfbf878: stur            w0, [x1, #0xf]
    // 0xfbf87c: ldur            x0, [fp, #-0x18]
    // 0xfbf880: StoreField: r1->field_13 = r0
    //     0xfbf880: stur            w0, [x1, #0x13]
    // 0xfbf884: ldur            x0, [fp, #-0x20]
    // 0xfbf888: StoreField: r1->field_b = r0
    //     0xfbf888: stur            w0, [x1, #0xb]
    // 0xfbf88c: b               #0xfbf898
    // 0xfbf890: mov             x0, x2
    // 0xfbf894: mov             x1, x0
    // 0xfbf898: ldur            x0, [fp, #-8]
    // 0xfbf89c: stur            x1, [fp, #-0x18]
    // 0xfbf8a0: LoadField: r2 = r0->field_1f
    //     0xfbf8a0: ldur            w2, [x0, #0x1f]
    // 0xfbf8a4: DecompressPointer r2
    //     0xfbf8a4: add             x2, x2, HEAP, lsl #32
    // 0xfbf8a8: stur            x2, [fp, #-0x10]
    // 0xfbf8ac: cmp             w2, NULL
    // 0xfbf8b0: b.eq            #0xfbf8dc
    // 0xfbf8b4: r0 = DecoratedBox()
    //     0xfbf8b4: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfbf8b8: mov             x1, x0
    // 0xfbf8bc: ldur            x0, [fp, #-0x10]
    // 0xfbf8c0: StoreField: r1->field_f = r0
    //     0xfbf8c0: stur            w0, [x1, #0xf]
    // 0xfbf8c4: r0 = Instance_DecorationPosition
    //     0xfbf8c4: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xfbf8c8: ldr             x0, [x0, #0xef0]
    // 0xfbf8cc: StoreField: r1->field_13 = r0
    //     0xfbf8cc: stur            w0, [x1, #0x13]
    // 0xfbf8d0: ldur            x0, [fp, #-0x18]
    // 0xfbf8d4: StoreField: r1->field_b = r0
    //     0xfbf8d4: stur            w0, [x1, #0xb]
    // 0xfbf8d8: b               #0xfbf8e4
    // 0xfbf8dc: mov             x0, x1
    // 0xfbf8e0: mov             x1, x0
    // 0xfbf8e4: ldur            x0, [fp, #-8]
    // 0xfbf8e8: stur            x1, [fp, #-0x18]
    // 0xfbf8ec: LoadField: r2 = r0->field_23
    //     0xfbf8ec: ldur            w2, [x0, #0x23]
    // 0xfbf8f0: DecompressPointer r2
    //     0xfbf8f0: add             x2, x2, HEAP, lsl #32
    // 0xfbf8f4: stur            x2, [fp, #-0x10]
    // 0xfbf8f8: cmp             w2, NULL
    // 0xfbf8fc: b.eq            #0xfbf928
    // 0xfbf900: r0 = DecoratedBox()
    //     0xfbf900: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfbf904: mov             x1, x0
    // 0xfbf908: ldur            x0, [fp, #-0x10]
    // 0xfbf90c: StoreField: r1->field_f = r0
    //     0xfbf90c: stur            w0, [x1, #0xf]
    // 0xfbf910: r0 = Instance_DecorationPosition
    //     0xfbf910: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef8] Obj!DecorationPosition@12c4361
    //     0xfbf914: ldr             x0, [x0, #0xef8]
    // 0xfbf918: StoreField: r1->field_13 = r0
    //     0xfbf918: stur            w0, [x1, #0x13]
    // 0xfbf91c: ldur            x0, [fp, #-0x18]
    // 0xfbf920: StoreField: r1->field_b = r0
    //     0xfbf920: stur            w0, [x1, #0xb]
    // 0xfbf924: b               #0xfbf930
    // 0xfbf928: mov             x0, x1
    // 0xfbf92c: mov             x1, x0
    // 0xfbf930: ldur            x0, [fp, #-8]
    // 0xfbf934: stur            x1, [fp, #-0x18]
    // 0xfbf938: LoadField: r2 = r0->field_27
    //     0xfbf938: ldur            w2, [x0, #0x27]
    // 0xfbf93c: DecompressPointer r2
    //     0xfbf93c: add             x2, x2, HEAP, lsl #32
    // 0xfbf940: stur            x2, [fp, #-0x10]
    // 0xfbf944: cmp             w2, NULL
    // 0xfbf948: b.eq            #0xfbf968
    // 0xfbf94c: r0 = ConstrainedBox()
    //     0xfbf94c: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfbf950: mov             x1, x0
    // 0xfbf954: ldur            x0, [fp, #-0x10]
    // 0xfbf958: StoreField: r1->field_f = r0
    //     0xfbf958: stur            w0, [x1, #0xf]
    // 0xfbf95c: ldur            x0, [fp, #-0x18]
    // 0xfbf960: StoreField: r1->field_b = r0
    //     0xfbf960: stur            w0, [x1, #0xb]
    // 0xfbf964: b               #0xfbf970
    // 0xfbf968: mov             x0, x1
    // 0xfbf96c: mov             x1, x0
    // 0xfbf970: ldur            x0, [fp, #-8]
    // 0xfbf974: stur            x1, [fp, #-0x18]
    // 0xfbf978: LoadField: r2 = r0->field_2b
    //     0xfbf978: ldur            w2, [x0, #0x2b]
    // 0xfbf97c: DecompressPointer r2
    //     0xfbf97c: add             x2, x2, HEAP, lsl #32
    // 0xfbf980: stur            x2, [fp, #-0x10]
    // 0xfbf984: cmp             w2, NULL
    // 0xfbf988: b.eq            #0xfbf9a4
    // 0xfbf98c: r0 = Padding()
    //     0xfbf98c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfbf990: ldur            x1, [fp, #-0x10]
    // 0xfbf994: StoreField: r0->field_f = r1
    //     0xfbf994: stur            w1, [x0, #0xf]
    // 0xfbf998: ldur            x1, [fp, #-0x18]
    // 0xfbf99c: StoreField: r0->field_b = r1
    //     0xfbf99c: stur            w1, [x0, #0xb]
    // 0xfbf9a0: b               #0xfbf9a8
    // 0xfbf9a4: mov             x0, x1
    // 0xfbf9a8: cmp             w0, NULL
    // 0xfbf9ac: b.eq            #0xfbf9c8
    // 0xfbf9b0: LeaveFrame
    //     0xfbf9b0: mov             SP, fp
    //     0xfbf9b4: ldp             fp, lr, [SP], #0x10
    // 0xfbf9b8: ret
    //     0xfbf9b8: ret             
    // 0xfbf9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf9bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf9c0: b               #0xfbf690
    // 0xfbf9c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbf9c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbf9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbf9c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _paddingIncludingDecoration(/* No info */) {
    // ** addr: 0xfbf9d8, size: 0x1e8
    // 0xfbf9d8: EnterFrame
    //     0xfbf9d8: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf9dc: mov             fp, SP
    // 0xfbf9e0: AllocStack(0x10)
    //     0xfbf9e0: sub             SP, SP, #0x10
    // 0xfbf9e4: CheckStackOverflow
    //     0xfbf9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf9e8: cmp             SP, x16
    //     0xfbf9ec: b.ls            #0xfbfbb4
    // 0xfbf9f0: LoadField: r2 = r1->field_13
    //     0xfbf9f0: ldur            w2, [x1, #0x13]
    // 0xfbf9f4: DecompressPointer r2
    //     0xfbf9f4: add             x2, x2, HEAP, lsl #32
    // 0xfbf9f8: stur            x2, [fp, #-0x10]
    // 0xfbf9fc: LoadField: r3 = r1->field_1f
    //     0xfbf9fc: ldur            w3, [x1, #0x1f]
    // 0xfbfa00: DecompressPointer r3
    //     0xfbfa00: add             x3, x3, HEAP, lsl #32
    // 0xfbfa04: stur            x3, [fp, #-8]
    // 0xfbfa08: cmp             w3, NULL
    // 0xfbfa0c: b.ne            #0xfbfa18
    // 0xfbfa10: r0 = Null
    //     0xfbfa10: mov             x0, NULL
    // 0xfbfa14: b               #0xfbfa94
    // 0xfbfa18: r0 = LoadClassIdInstr(r3)
    //     0xfbfa18: ldur            x0, [x3, #-1]
    //     0xfbfa1c: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfa20: r17 = -5239
    //     0xfbfa20: mov             x17, #-0x1477
    // 0xfbfa24: add             x16, x0, x17
    // 0xfbfa28: cmp             x16, #1
    // 0xfbfa2c: b.hi            #0xfbfa38
    // 0xfbfa30: r0 = Instance_EdgeInsets
    //     0xfbfa30: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbfa34: b               #0xfbfa90
    // 0xfbfa38: r17 = 5237
    //     0xfbfa38: mov             x17, #0x1475
    // 0xfbfa3c: cmp             x0, x17
    // 0xfbfa40: b.ne            #0xfbfa64
    // 0xfbfa44: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xfbfa44: ldur            w1, [x3, #0x17]
    // 0xfbfa48: DecompressPointer r1
    //     0xfbfa48: add             x1, x1, HEAP, lsl #32
    // 0xfbfa4c: r0 = LoadClassIdInstr(r1)
    //     0xfbfa4c: ldur            x0, [x1, #-1]
    //     0xfbfa50: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfa54: r0 = GDT[cid_x0 + -0xee7]()
    //     0xfbfa54: sub             lr, x0, #0xee7
    //     0xfbfa58: ldr             lr, [x21, lr, lsl #3]
    //     0xfbfa5c: blr             lr
    // 0xfbfa60: b               #0xfbfa90
    // 0xfbfa64: mov             x0, x3
    // 0xfbfa68: LoadField: r1 = r0->field_f
    //     0xfbfa68: ldur            w1, [x0, #0xf]
    // 0xfbfa6c: DecompressPointer r1
    //     0xfbfa6c: add             x1, x1, HEAP, lsl #32
    // 0xfbfa70: cmp             w1, NULL
    // 0xfbfa74: b.ne            #0xfbfa80
    // 0xfbfa78: r0 = Null
    //     0xfbfa78: mov             x0, NULL
    // 0xfbfa7c: b               #0xfbfa84
    // 0xfbfa80: r0 = dimensions()
    //     0xfbfa80: bl              #0x12f56c4  ; [package:flutter/src/painting/box_border.dart] Border::dimensions
    // 0xfbfa84: cmp             w0, NULL
    // 0xfbfa88: b.ne            #0xfbfa90
    // 0xfbfa8c: r0 = Instance_EdgeInsets
    //     0xfbfa8c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbfa90: ldur            x2, [fp, #-0x10]
    // 0xfbfa94: cmp             w2, NULL
    // 0xfbfa98: b.eq            #0xfbfba8
    // 0xfbfa9c: cmp             w0, NULL
    // 0xfbfaa0: b.ne            #0xfbfaac
    // 0xfbfaa4: mov             x0, x2
    // 0xfbfaa8: b               #0xfbfba8
    // 0xfbfaac: ldur            x0, [fp, #-8]
    // 0xfbfab0: cmp             w0, NULL
    // 0xfbfab4: b.eq            #0xfbfbbc
    // 0xfbfab8: r1 = LoadClassIdInstr(r0)
    //     0xfbfab8: ldur            x1, [x0, #-1]
    //     0xfbfabc: ubfx            x1, x1, #0xc, #0x14
    // 0xfbfac0: r17 = -5239
    //     0xfbfac0: mov             x17, #-0x1477
    // 0xfbfac4: add             x16, x1, x17
    // 0xfbfac8: cmp             x16, #1
    // 0xfbfacc: b.hi            #0xfbfadc
    // 0xfbfad0: mov             x1, x2
    // 0xfbfad4: r2 = Instance_EdgeInsets
    //     0xfbfad4: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbfad8: b               #0xfbfb40
    // 0xfbfadc: r17 = 5237
    //     0xfbfadc: mov             x17, #0x1475
    // 0xfbfae0: cmp             x1, x17
    // 0xfbfae4: b.ne            #0xfbfb10
    // 0xfbfae8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfbfae8: ldur            w1, [x0, #0x17]
    // 0xfbfaec: DecompressPointer r1
    //     0xfbfaec: add             x1, x1, HEAP, lsl #32
    // 0xfbfaf0: r0 = LoadClassIdInstr(r1)
    //     0xfbfaf0: ldur            x0, [x1, #-1]
    //     0xfbfaf4: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfaf8: r0 = GDT[cid_x0 + -0xee7]()
    //     0xfbfaf8: sub             lr, x0, #0xee7
    //     0xfbfafc: ldr             lr, [x21, lr, lsl #3]
    //     0xfbfb00: blr             lr
    // 0xfbfb04: mov             x2, x0
    // 0xfbfb08: ldur            x1, [fp, #-0x10]
    // 0xfbfb0c: b               #0xfbfb40
    // 0xfbfb10: LoadField: r1 = r0->field_f
    //     0xfbfb10: ldur            w1, [x0, #0xf]
    // 0xfbfb14: DecompressPointer r1
    //     0xfbfb14: add             x1, x1, HEAP, lsl #32
    // 0xfbfb18: cmp             w1, NULL
    // 0xfbfb1c: b.ne            #0xfbfb28
    // 0xfbfb20: r0 = Null
    //     0xfbfb20: mov             x0, NULL
    // 0xfbfb24: b               #0xfbfb2c
    // 0xfbfb28: r0 = dimensions()
    //     0xfbfb28: bl              #0x12f56c4  ; [package:flutter/src/painting/box_border.dart] Border::dimensions
    // 0xfbfb2c: cmp             w0, NULL
    // 0xfbfb30: b.ne            #0xfbfb38
    // 0xfbfb34: r0 = Instance_EdgeInsets
    //     0xfbfb34: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbfb38: mov             x2, x0
    // 0xfbfb3c: ldur            x1, [fp, #-0x10]
    // 0xfbfb40: r0 = LoadClassIdInstr(r1)
    //     0xfbfb40: ldur            x0, [x1, #-1]
    //     0xfbfb44: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfb48: cmp             x0, #0xb7b
    // 0xfbfb4c: b.ne            #0xfbfb5c
    // 0xfbfb50: r0 = add()
    //     0xfbfb50: bl              #0x1301438  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0xfbfb54: mov             x1, x0
    // 0xfbfb58: b               #0xfbfba4
    // 0xfbfb5c: cmp             x0, #0xb7c
    // 0xfbfb60: b.ne            #0xfbfb8c
    // 0xfbfb64: r0 = LoadClassIdInstr(r2)
    //     0xfbfb64: ldur            x0, [x2, #-1]
    //     0xfbfb68: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfb6c: cmp             x0, #0xb7c
    // 0xfbfb70: b.ne            #0xfbfb80
    // 0xfbfb74: r0 = +()
    //     0xfbfb74: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xfbfb78: mov             x1, x0
    // 0xfbfb7c: b               #0xfbfba4
    // 0xfbfb80: r0 = add()
    //     0xfbfb80: bl              #0x1301438  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0xfbfb84: mov             x1, x0
    // 0xfbfb88: b               #0xfbfba4
    // 0xfbfb8c: r0 = LoadClassIdInstr(r1)
    //     0xfbfb8c: ldur            x0, [x1, #-1]
    //     0xfbfb90: ubfx            x0, x0, #0xc, #0x14
    // 0xfbfb94: r0 = GDT[cid_x0 + -0xf8e]()
    //     0xfbfb94: sub             lr, x0, #0xf8e
    //     0xfbfb98: ldr             lr, [x21, lr, lsl #3]
    //     0xfbfb9c: blr             lr
    // 0xfbfba0: mov             x1, x0
    // 0xfbfba4: mov             x0, x1
    // 0xfbfba8: LeaveFrame
    //     0xfbfba8: mov             SP, fp
    //     0xfbfbac: ldp             fp, lr, [SP], #0x10
    // 0xfbfbb0: ret
    //     0xfbfbb0: ret             
    // 0xfbfbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbfbb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbfbb8: b               #0xfbf9f0
    // 0xfbfbbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbfbbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6597, size: 0x18, field offset: 0x10
//   const constructor, 
class DecoratedBox extends SingleChildRenderObjectWidget {

  SizedBox field_c;
  BoxDecoration field_10;
  DecorationPosition field_14;

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf9c7c, size: 0xc0
    // 0xcf9c7c: EnterFrame
    //     0xcf9c7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9c80: mov             fp, SP
    // 0xcf9c84: AllocStack(0x18)
    //     0xcf9c84: sub             SP, SP, #0x18
    // 0xcf9c88: SetupParameters(DecoratedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcf9c88: mov             x5, x1
    //     0xcf9c8c: mov             x4, x2
    //     0xcf9c90: stur            x1, [fp, #-8]
    //     0xcf9c94: stur            x2, [fp, #-0x10]
    //     0xcf9c98: stur            x3, [fp, #-0x18]
    // 0xcf9c9c: CheckStackOverflow
    //     0xcf9c9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf9ca0: cmp             SP, x16
    //     0xcf9ca4: b.ls            #0xcf9d34
    // 0xcf9ca8: mov             x0, x3
    // 0xcf9cac: r2 = Null
    //     0xcf9cac: mov             x2, NULL
    // 0xcf9cb0: r1 = Null
    //     0xcf9cb0: mov             x1, NULL
    // 0xcf9cb4: r4 = 60
    //     0xcf9cb4: mov             x4, #0x3c
    // 0xcf9cb8: branchIfSmi(r0, 0xcf9cc4)
    //     0xcf9cb8: tbz             w0, #0, #0xcf9cc4
    // 0xcf9cbc: r4 = LoadClassIdInstr(r0)
    //     0xcf9cbc: ldur            x4, [x0, #-1]
    //     0xcf9cc0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9cc4: r17 = 4928
    //     0xcf9cc4: mov             x17, #0x1340
    // 0xcf9cc8: cmp             x4, x17
    // 0xcf9ccc: b.eq            #0xcf9ce4
    // 0xcf9cd0: r8 = RenderDecoratedBox
    //     0xcf9cd0: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d168] Type: RenderDecoratedBox
    //     0xcf9cd4: ldr             x8, [x8, #0x168]
    // 0xcf9cd8: r3 = Null
    //     0xcf9cd8: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d170] Null
    //     0xcf9cdc: ldr             x3, [x3, #0x170]
    // 0xcf9ce0: r0 = DefaultTypeTest()
    //     0xcf9ce0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf9ce4: ldur            x0, [fp, #-8]
    // 0xcf9ce8: LoadField: r2 = r0->field_f
    //     0xcf9ce8: ldur            w2, [x0, #0xf]
    // 0xcf9cec: DecompressPointer r2
    //     0xcf9cec: add             x2, x2, HEAP, lsl #32
    // 0xcf9cf0: ldur            x1, [fp, #-0x18]
    // 0xcf9cf4: r0 = decoration=()
    //     0xcf9cf4: bl              #0xcfa068  ; [package:flutter/src/rendering/proxy_box.dart] RenderDecoratedBox::decoration=
    // 0xcf9cf8: ldur            x1, [fp, #-0x10]
    // 0xcf9cfc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xcf9cfc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xcf9d00: r0 = createLocalImageConfiguration()
    //     0xcf9d00: bl              #0xcf9e34  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0xcf9d04: ldur            x1, [fp, #-0x18]
    // 0xcf9d08: mov             x2, x0
    // 0xcf9d0c: r0 = configuration=()
    //     0xcf9d0c: bl              #0xcf9dac  ; [package:flutter/src/rendering/proxy_box.dart] RenderDecoratedBox::configuration=
    // 0xcf9d10: ldur            x0, [fp, #-8]
    // 0xcf9d14: LoadField: r2 = r0->field_13
    //     0xcf9d14: ldur            w2, [x0, #0x13]
    // 0xcf9d18: DecompressPointer r2
    //     0xcf9d18: add             x2, x2, HEAP, lsl #32
    // 0xcf9d1c: ldur            x1, [fp, #-0x18]
    // 0xcf9d20: r0 = position=()
    //     0xcf9d20: bl              #0xcf9d3c  ; [package:flutter/src/rendering/proxy_box.dart] RenderDecoratedBox::position=
    // 0xcf9d24: r0 = Null
    //     0xcf9d24: mov             x0, NULL
    // 0xcf9d28: LeaveFrame
    //     0xcf9d28: mov             SP, fp
    //     0xcf9d2c: ldp             fp, lr, [SP], #0x10
    // 0xcf9d30: ret
    //     0xcf9d30: ret             
    // 0xcf9d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9d34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9d38: b               #0xcf9ca8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d2b68, size: 0x78
    // 0x11d2b68: EnterFrame
    //     0x11d2b68: stp             fp, lr, [SP, #-0x10]!
    //     0x11d2b6c: mov             fp, SP
    // 0x11d2b70: AllocStack(0x18)
    //     0x11d2b70: sub             SP, SP, #0x18
    // 0x11d2b74: SetupParameters(DecoratedBox this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11d2b74: mov             x0, x1
    //     0x11d2b78: mov             x1, x2
    // 0x11d2b7c: CheckStackOverflow
    //     0x11d2b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d2b80: cmp             SP, x16
    //     0x11d2b84: b.ls            #0x11d2bd8
    // 0x11d2b88: LoadField: r3 = r0->field_f
    //     0x11d2b88: ldur            w3, [x0, #0xf]
    // 0x11d2b8c: DecompressPointer r3
    //     0x11d2b8c: add             x3, x3, HEAP, lsl #32
    // 0x11d2b90: stur            x3, [fp, #-0x10]
    // 0x11d2b94: LoadField: r5 = r0->field_13
    //     0x11d2b94: ldur            w5, [x0, #0x13]
    // 0x11d2b98: DecompressPointer r5
    //     0x11d2b98: add             x5, x5, HEAP, lsl #32
    // 0x11d2b9c: stur            x5, [fp, #-8]
    // 0x11d2ba0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11d2ba0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11d2ba4: r0 = createLocalImageConfiguration()
    //     0x11d2ba4: bl              #0xcf9e34  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0x11d2ba8: stur            x0, [fp, #-0x18]
    // 0x11d2bac: r0 = RenderDecoratedBox()
    //     0x11d2bac: bl              #0x11d2cb4  ; AllocateRenderDecoratedBoxStub -> RenderDecoratedBox (size=0x64)
    // 0x11d2bb0: mov             x1, x0
    // 0x11d2bb4: ldur            x2, [fp, #-0x18]
    // 0x11d2bb8: ldur            x3, [fp, #-0x10]
    // 0x11d2bbc: ldur            x5, [fp, #-8]
    // 0x11d2bc0: stur            x0, [fp, #-8]
    // 0x11d2bc4: r0 = RenderDecoratedBox()
    //     0x11d2bc4: bl              #0x11d2be0  ; [package:flutter/src/rendering/proxy_box.dart] RenderDecoratedBox::RenderDecoratedBox
    // 0x11d2bc8: ldur            x0, [fp, #-8]
    // 0x11d2bcc: LeaveFrame
    //     0x11d2bcc: mov             SP, fp
    //     0x11d2bd0: ldp             fp, lr, [SP], #0x10
    // 0x11d2bd4: ret
    //     0x11d2bd4: ret             
    // 0x11d2bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d2bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d2bdc: b               #0x11d2b88
  }
}
