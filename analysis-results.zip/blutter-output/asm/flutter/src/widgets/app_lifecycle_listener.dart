// lib: , url: package:flutter/src/widgets/app_lifecycle_listener.dart

// class id: 1049116, size: 0x8
class :: {
}

// class id: 4579, size: 0x34, field offset: 0x8
class AppLifecycleListener extends _MixinApplication192&Object&WidgetsBindingObserver&Diagnosticable {

  _ didChangeAppLifecycleState(/* No info */) {
    // ** addr: 0x8d3d44, size: 0x11c
    // 0x8d3d44: EnterFrame
    //     0x8d3d44: stp             fp, lr, [SP, #-0x10]!
    //     0x8d3d48: mov             fp, SP
    // 0x8d3d4c: mov             x16, x2
    // 0x8d3d50: mov             x2, x1
    // 0x8d3d54: mov             x1, x16
    // 0x8d3d58: CheckStackOverflow
    //     0x8d3d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d3d5c: cmp             SP, x16
    //     0x8d3d60: b.ls            #0x8d3e54
    // 0x8d3d64: LoadField: r3 = r2->field_7
    //     0x8d3d64: ldur            w3, [x2, #7]
    // 0x8d3d68: DecompressPointer r3
    //     0x8d3d68: add             x3, x3, HEAP, lsl #32
    // 0x8d3d6c: cmp             w1, w3
    // 0x8d3d70: b.ne            #0x8d3d84
    // 0x8d3d74: r0 = Null
    //     0x8d3d74: mov             x0, NULL
    // 0x8d3d78: LeaveFrame
    //     0x8d3d78: mov             SP, fp
    //     0x8d3d7c: ldp             fp, lr, [SP], #0x10
    // 0x8d3d80: ret
    //     0x8d3d80: ret             
    // 0x8d3d84: mov             x0, x1
    // 0x8d3d88: StoreField: r2->field_7 = r0
    //     0x8d3d88: stur            w0, [x2, #7]
    //     0x8d3d8c: ldurb           w16, [x2, #-1]
    //     0x8d3d90: ldurb           w17, [x0, #-1]
    //     0x8d3d94: and             x16, x17, x16, lsr #2
    //     0x8d3d98: tst             x16, HEAP, lsr #32
    //     0x8d3d9c: b.eq            #0x8d3da4
    //     0x8d3da0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8d3da4: LoadField: r0 = r1->field_7
    //     0x8d3da4: ldur            x0, [x1, #7]
    // 0x8d3da8: cmp             x0, #2
    // 0x8d3dac: b.gt            #0x8d3e04
    // 0x8d3db0: cmp             x0, #1
    // 0x8d3db4: b.gt            #0x8d3de0
    // 0x8d3db8: cmp             x0, #0
    // 0x8d3dbc: b.le            #0x8d3e44
    // 0x8d3dc0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8d3dc0: ldur            w0, [x2, #0x17]
    // 0x8d3dc4: DecompressPointer r0
    //     0x8d3dc4: add             x0, x0, HEAP, lsl #32
    // 0x8d3dc8: cmp             w0, NULL
    // 0x8d3dcc: b.eq            #0x8d3e5c
    // 0x8d3dd0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d3dd0: ldur            w1, [x0, #0x17]
    // 0x8d3dd4: DecompressPointer r1
    //     0x8d3dd4: add             x1, x1, HEAP, lsl #32
    // 0x8d3dd8: r0 = _onResume()
    //     0x8d3dd8: bl              #0x8d3e98  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::_onResume
    // 0x8d3ddc: b               #0x8d3e44
    // 0x8d3de0: r16 = Instance_AppLifecycleState
    //     0x8d3de0: ldr             x16, [PP, #0x3208]  ; [pp+0x3208] Obj!AppLifecycleState@12c7f01
    // 0x8d3de4: cmp             w3, w16
    // 0x8d3de8: b.eq            #0x8d3e44
    // 0x8d3dec: cmp             w3, NULL
    // 0x8d3df0: b.eq            #0x8d3e44
    // 0x8d3df4: r16 = Instance_AppLifecycleState
    //     0x8d3df4: ldr             x16, [PP, #0x1e28]  ; [pp+0x1e28] Obj!AppLifecycleState@12c7ee1
    // 0x8d3df8: cmp             w3, w16
    // 0x8d3dfc: b.ne            #0x8d3e44
    // 0x8d3e00: b               #0x8d3e44
    // 0x8d3e04: cmp             x0, #3
    // 0x8d3e08: b.gt            #0x8d3e30
    // 0x8d3e0c: r16 = Instance_AppLifecycleState
    //     0x8d3e0c: ldr             x16, [PP, #0x3218]  ; [pp+0x3218] Obj!AppLifecycleState@12c7ec1
    // 0x8d3e10: cmp             w3, w16
    // 0x8d3e14: b.eq            #0x8d3e44
    // 0x8d3e18: cmp             w3, NULL
    // 0x8d3e1c: b.eq            #0x8d3e44
    // 0x8d3e20: r16 = Instance_AppLifecycleState
    //     0x8d3e20: ldr             x16, [PP, #0x31f8]  ; [pp+0x31f8] Obj!AppLifecycleState@12c7ea1
    // 0x8d3e24: cmp             w3, w16
    // 0x8d3e28: b.ne            #0x8d3e44
    // 0x8d3e2c: b               #0x8d3e44
    // 0x8d3e30: cmp             w3, NULL
    // 0x8d3e34: b.eq            #0x8d3e44
    // 0x8d3e38: r16 = Instance_AppLifecycleState
    //     0x8d3e38: ldr             x16, [PP, #0x3208]  ; [pp+0x3208] Obj!AppLifecycleState@12c7f01
    // 0x8d3e3c: cmp             w3, w16
    // 0x8d3e40: b.eq            #0x8d3e44
    // 0x8d3e44: r0 = Null
    //     0x8d3e44: mov             x0, NULL
    // 0x8d3e48: LeaveFrame
    //     0x8d3e48: mov             SP, fp
    //     0x8d3e4c: ldp             fp, lr, [SP], #0x10
    // 0x8d3e50: ret
    //     0x8d3e50: ret             
    // 0x8d3e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d3e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d3e58: b               #0x8d3d64
    // 0x8d3e5c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8d3e5c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ AppLifecycleListener(/* No info */) {
    // ** addr: 0xf83290, size: 0x130
    // 0xf83290: EnterFrame
    //     0xf83290: stp             fp, lr, [SP, #-0x10]!
    //     0xf83294: mov             fp, SP
    // 0xf83298: AllocStack(0x18)
    //     0xf83298: sub             SP, SP, #0x18
    // 0xf8329c: SetupParameters(AppLifecycleListener this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0 */)
    //     0xf8329c: mov             x0, x2
    //     0xf832a0: mov             x2, x1
    //     0xf832a4: stur            x1, [fp, #-0x18]
    // 0xf832a8: CheckStackOverflow
    //     0xf832a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf832ac: cmp             SP, x16
    //     0xf832b0: b.ls            #0xf833b4
    // 0xf832b4: ArrayStore: r2[0] = r0  ; List_4
    //     0xf832b4: stur            w0, [x2, #0x17]
    //     0xf832b8: ldurb           w16, [x2, #-1]
    //     0xf832bc: ldurb           w17, [x0, #-1]
    //     0xf832c0: and             x16, x17, x16, lsr #2
    //     0xf832c4: tst             x16, HEAP, lsr #32
    //     0xf832c8: b.eq            #0xf832d0
    //     0xf832cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf832d0: r1 = LoadStaticField(0x6a0)
    //     0xf832d0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xf832d4: ldr             x1, [x1, #0xd40]
    // 0xf832d8: cmp             w1, NULL
    // 0xf832dc: b.eq            #0xf833bc
    // 0xf832e0: mov             x0, x1
    // 0xf832e4: StoreField: r2->field_b = r0
    //     0xf832e4: stur            w0, [x2, #0xb]
    //     0xf832e8: ldurb           w16, [x2, #-1]
    //     0xf832ec: ldurb           w17, [x0, #-1]
    //     0xf832f0: and             x16, x17, x16, lsr #2
    //     0xf832f4: tst             x16, HEAP, lsr #32
    //     0xf832f8: b.eq            #0xf83300
    //     0xf832fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf83300: LoadField: r0 = r1->field_2f
    //     0xf83300: ldur            w0, [x1, #0x2f]
    // 0xf83304: DecompressPointer r0
    //     0xf83304: add             x0, x0, HEAP, lsl #32
    // 0xf83308: StoreField: r2->field_7 = r0
    //     0xf83308: stur            w0, [x2, #7]
    //     0xf8330c: ldurb           w16, [x2, #-1]
    //     0xf83310: ldurb           w17, [x0, #-1]
    //     0xf83314: and             x16, x17, x16, lsr #2
    //     0xf83318: tst             x16, HEAP, lsr #32
    //     0xf8331c: b.eq            #0xf83324
    //     0xf83320: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf83324: LoadField: r0 = r1->field_f3
    //     0xf83324: ldur            w0, [x1, #0xf3]
    // 0xf83328: DecompressPointer r0
    //     0xf83328: add             x0, x0, HEAP, lsl #32
    // 0xf8332c: stur            x0, [fp, #-0x10]
    // 0xf83330: LoadField: r1 = r0->field_b
    //     0xf83330: ldur            w1, [x0, #0xb]
    // 0xf83334: LoadField: r3 = r0->field_f
    //     0xf83334: ldur            w3, [x0, #0xf]
    // 0xf83338: DecompressPointer r3
    //     0xf83338: add             x3, x3, HEAP, lsl #32
    // 0xf8333c: LoadField: r4 = r3->field_b
    //     0xf8333c: ldur            w4, [x3, #0xb]
    // 0xf83340: r3 = LoadInt32Instr(r1)
    //     0xf83340: sbfx            x3, x1, #1, #0x1f
    // 0xf83344: stur            x3, [fp, #-8]
    // 0xf83348: r1 = LoadInt32Instr(r4)
    //     0xf83348: sbfx            x1, x4, #1, #0x1f
    // 0xf8334c: cmp             x3, x1
    // 0xf83350: b.ne            #0xf8335c
    // 0xf83354: mov             x1, x0
    // 0xf83358: r0 = _growToNextCapacity()
    //     0xf83358: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf8335c: ldur            x2, [fp, #-0x10]
    // 0xf83360: ldur            x3, [fp, #-8]
    // 0xf83364: add             x4, x3, #1
    // 0xf83368: lsl             x5, x4, #1
    // 0xf8336c: StoreField: r2->field_b = r5
    //     0xf8336c: stur            w5, [x2, #0xb]
    // 0xf83370: LoadField: r1 = r2->field_f
    //     0xf83370: ldur            w1, [x2, #0xf]
    // 0xf83374: DecompressPointer r1
    //     0xf83374: add             x1, x1, HEAP, lsl #32
    // 0xf83378: ldur            x0, [fp, #-0x18]
    // 0xf8337c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf8337c: add             x25, x1, x3, lsl #2
    //     0xf83380: add             x25, x25, #0xf
    //     0xf83384: str             w0, [x25]
    //     0xf83388: tbz             w0, #0, #0xf833a4
    //     0xf8338c: ldurb           w16, [x1, #-1]
    //     0xf83390: ldurb           w17, [x0, #-1]
    //     0xf83394: and             x16, x17, x16, lsr #2
    //     0xf83398: tst             x16, HEAP, lsr #32
    //     0xf8339c: b.eq            #0xf833a4
    //     0xf833a0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf833a4: r0 = Null
    //     0xf833a4: mov             x0, NULL
    // 0xf833a8: LeaveFrame
    //     0xf833a8: mov             SP, fp
    //     0xf833ac: ldp             fp, lr, [SP], #0x10
    // 0xf833b0: ret
    //     0xf833b0: ret             
    // 0xf833b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf833b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf833b8: b               #0xf832b4
    // 0xf833bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf833bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10df368, size: 0x3c
    // 0x10df368: EnterFrame
    //     0x10df368: stp             fp, lr, [SP, #-0x10]!
    //     0x10df36c: mov             fp, SP
    // 0x10df370: mov             x2, x1
    // 0x10df374: CheckStackOverflow
    //     0x10df374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10df378: cmp             SP, x16
    //     0x10df37c: b.ls            #0x10df39c
    // 0x10df380: LoadField: r1 = r2->field_b
    //     0x10df380: ldur            w1, [x2, #0xb]
    // 0x10df384: DecompressPointer r1
    //     0x10df384: add             x1, x1, HEAP, lsl #32
    // 0x10df388: r0 = removeObserver()
    //     0x10df388: bl              #0xb3ac3c  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x10df38c: r0 = Null
    //     0x10df38c: mov             x0, NULL
    // 0x10df390: LeaveFrame
    //     0x10df390: mov             SP, fp
    //     0x10df394: ldp             fp, lr, [SP], #0x10
    // 0x10df398: ret
    //     0x10df398: ret             
    // 0x10df39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10df39c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10df3a0: b               #0x10df380
  }
}
