// lib: , url: package:flutter/src/widgets/dialog.dart

// class id: 1049130, size: 0x8
class :: {

  static _ showRawDialog(/* No info */) {
    // ** addr: 0xd951e8, size: 0x1d8
    // 0xd951e8: EnterFrame
    //     0xd951e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd951ec: mov             fp, SP
    // 0xd951f0: AllocStack(0xc8)
    //     0xd951f0: sub             SP, SP, #0xc8
    // 0xd951f4: SetupParameters()
    //     0xd951f4: ldur            w0, [x4, #0xf]
    //     0xd951f8: cbnz            w0, #0xd95204
    //     0xd951fc: mov             x0, NULL
    //     0xd95200: b               #0xd95214
    //     0xd95204: ldur            w0, [x4, #0x17]
    //     0xd95208: add             x1, fp, w0, sxtw #2
    //     0xd9520c: ldr             x1, [x1, #0x10]
    //     0xd95210: mov             x0, x1
    //     0xd95214: stur            x0, [fp, #-0x98]
    // 0xd95218: CheckStackOverflow
    //     0xd95218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9521c: cmp             SP, x16
    //     0xd95220: b.ls            #0xd953b8
    // 0xd95224: r16 = true
    //     0xd95224: add             x16, NULL, #0x20  ; true
    // 0xd95228: str             x16, [SP]
    // 0xd9522c: ldr             x1, [fp, #0x20]
    // 0xd95230: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xd95230: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xd95234: ldr             x4, [x4, #0xa0]
    // 0xd95238: r0 = of()
    //     0xd95238: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xd9523c: ldr             x1, [fp, #0x20]
    // 0xd95240: stur            x0, [fp, #-0xa0]
    // 0xd95244: r0 = maybeOf()
    //     0xd95244: bl              #0xd956a8  ; [package:flutter/src/widgets/_window.dart] WindowRegistry::maybeOf
    // 0xd95248: cmp             w0, NULL
    // 0xd9524c: b.eq            #0xd9535c
    // 0xd95250: r0 = LoadStaticField(0x878)
    //     0xd95250: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd95254: ldr             x0, [x0, #0x10f0]
    // 0xd95258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd9525c: cmp             w0, w16
    // 0xd95260: b.ne            #0xd9526c
    // 0xd95264: r2 = isWindowingEnabled
    //     0xd95264: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0xd95268: r0 = InitLateStaticField()
    //     0xd95268: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd9526c: tbnz            w0, #4, #0xd9535c
    // 0xd95270: ldr             x1, [fp, #0x20]
    // 0xd95274: r0 = maybeContentSizeOf()
    //     0xd95274: bl              #0xd95664  ; [package:flutter/src/widgets/_window.dart] WindowScope::maybeContentSizeOf
    // 0xd95278: ldr             x1, [fp, #0x20]
    // 0xd9527c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd9527c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd95280: r0 = _maybeOf()
    //     0xd95280: bl              #0xd95598  ; [package:flutter/src/widgets/_window.dart] WindowScope::_maybeOf
    // 0xd95284: ldur            x1, [fp, #-0x98]
    // 0xd95288: r0 = _DialogWindowRoute()
    //     0xd95288: bl              #0xd9558c  ; Allocate_DialogWindowRouteStub -> _DialogWindowRoute<X0> (size=0x3c)
    // 0xd9528c: mov             x1, x0
    // 0xd95290: ldr             x2, [fp, #0x28]
    // 0xd95294: ldr             x3, [fp, #0x20]
    // 0xd95298: ldr             x5, [fp, #0x10]
    // 0xd9529c: stur            x0, [fp, #-0xa8]
    // 0xd952a0: r0 = _DialogWindowRoute()
    //     0xd952a0: bl              #0xd953c0  ; [package:flutter/src/widgets/dialog.dart] _DialogWindowRoute::_DialogWindowRoute
    // 0xd952a4: ldur            x16, [fp, #-0x98]
    // 0xd952a8: ldur            lr, [fp, #-0xa0]
    // 0xd952ac: stp             lr, x16, [SP, #8]
    // 0xd952b0: ldur            x16, [fp, #-0xa8]
    // 0xd952b4: str             x16, [SP]
    // 0xd952b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd952b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd952bc: r0 = push()
    //     0xd952bc: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xd952c0: LeaveFrame
    //     0xd952c0: mov             SP, fp
    //     0xd952c4: ldp             fp, lr, [SP], #0x10
    // 0xd952c8: ret
    //     0xd952c8: ret             
    // 0xd952cc: sub             SP, fp, #0xc8
    // 0xd952d0: mov             x4, x0
    // 0xd952d4: mov             x3, x1
    // 0xd952d8: stur            x0, [fp, #-0xa8]
    // 0xd952dc: stur            x1, [fp, #-0xb0]
    // 0xd952e0: r2 = Null
    //     0xd952e0: mov             x2, NULL
    // 0xd952e4: r1 = Null
    //     0xd952e4: mov             x1, NULL
    // 0xd952e8: cmp             w0, NULL
    // 0xd952ec: b.eq            #0xd95318
    // 0xd952f0: branchIfSmi(r0, 0xd95318)
    //     0xd952f0: tbz             w0, #0, #0xd95318
    // 0xd952f4: r3 = LoadClassIdInstr(r0)
    //     0xd952f4: ldur            x3, [x0, #-1]
    //     0xd952f8: ubfx            x3, x3, #0xc, #0x14
    // 0xd952fc: r17 = 7741
    //     0xd952fc: mov             x17, #0x1e3d
    // 0xd95300: cmp             x3, x17
    // 0xd95304: b.eq            #0xd95320
    // 0xd95308: r17 = -7774
    //     0xd95308: mov             x17, #-0x1e5e
    // 0xd9530c: add             x3, x3, x17
    // 0xd95310: cmp             x3, #1
    // 0xd95314: b.ls            #0xd95320
    // 0xd95318: r0 = false
    //     0xd95318: add             x0, NULL, #0x30  ; false
    // 0xd9531c: b               #0xd95324
    // 0xd95320: r0 = true
    //     0xd95320: add             x0, NULL, #0x20  ; true
    // 0xd95324: tbnz            w0, #4, #0xd953a4
    // 0xd95328: ldur            x0, [fp, #-0xa8]
    // 0xd9532c: ldur            x1, [fp, #-0xb0]
    // 0xd95330: r0 = FlutterErrorDetails()
    //     0xd95330: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0xd95334: mov             x1, x0
    // 0xd95338: ldur            x0, [fp, #-0xa8]
    // 0xd9533c: StoreField: r1->field_7 = r0
    //     0xd9533c: stur            w0, [x1, #7]
    // 0xd95340: ldur            x2, [fp, #-0xb0]
    // 0xd95344: StoreField: r1->field_b = r2
    //     0xd95344: stur            w2, [x1, #0xb]
    // 0xd95348: r0 = "widgets library"
    //     0xd95348: ldr             x0, [PP, #0x18b8]  ; [pp+0x18b8] "widgets library"
    // 0xd9534c: StoreField: r1->field_f = r0
    //     0xd9534c: stur            w0, [x1, #0xf]
    // 0xd95350: r0 = false
    //     0xd95350: add             x0, NULL, #0x30  ; false
    // 0xd95354: StoreField: r1->field_1b = r0
    //     0xd95354: stur            w0, [x1, #0x1b]
    // 0xd95358: r0 = reportError()
    //     0xd95358: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xd9535c: ldr             x16, [fp, #0x18]
    // 0xd95360: ldr             lr, [fp, #0x20]
    // 0xd95364: stp             lr, x16, [SP, #8]
    // 0xd95368: ldr             x16, [fp, #0x28]
    // 0xd9536c: str             x16, [SP]
    // 0xd95370: ldr             x0, [fp, #0x18]
    // 0xd95374: ClosureCall
    //     0xd95374: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xd95378: ldur            x2, [x0, #0x1f]
    //     0xd9537c: blr             x2
    // 0xd95380: ldur            x16, [fp, #-0x98]
    // 0xd95384: ldur            lr, [fp, #-0xa0]
    // 0xd95388: stp             lr, x16, [SP, #8]
    // 0xd9538c: str             x0, [SP]
    // 0xd95390: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd95390: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd95394: r0 = push()
    //     0xd95394: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xd95398: LeaveFrame
    //     0xd95398: mov             SP, fp
    //     0xd9539c: ldp             fp, lr, [SP], #0x10
    // 0xd953a0: ret
    //     0xd953a0: ret             
    // 0xd953a4: ldur            x0, [fp, #-0xa8]
    // 0xd953a8: ldur            x2, [fp, #-0xb0]
    // 0xd953ac: mov             x1, x2
    // 0xd953b0: r0 = ReThrow()
    //     0xd953b0: bl              #0x13ddb00  ; ReThrowStub
    // 0xd953b4: brk             #0
    // 0xd953b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd953b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd953bc: b               #0xd95224
  }
}

// class id: 2634, size: 0x3c, field offset: 0x24
class _DialogWindowRoute<X0> extends Route<X0> {

  late final List<OverlayEntry> _overlayEntries; // offset: 0x38

  _ didPush(/* No info */) {
    // ** addr: 0xb9abc8, size: 0x2c
    // 0xb9abc8: EnterFrame
    //     0xb9abc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9abcc: mov             fp, SP
    // 0xb9abd0: CheckStackOverflow
    //     0xb9abd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9abd4: cmp             SP, x16
    //     0xb9abd8: b.ls            #0xb9abec
    // 0xb9abdc: r0 = didPush()
    //     0xb9abdc: bl              #0xb99cc4  ; [package:flutter/src/widgets/navigator.dart] Route::didPush
    // 0xb9abe0: LeaveFrame
    //     0xb9abe0: mov             SP, fp
    //     0xb9abe4: ldp             fp, lr, [SP], #0x10
    // 0xb9abe8: ret
    //     0xb9abe8: ret             
    // 0xb9abec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9abec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9abf0: b               #0xb9abdc
  }
  _ didPop(/* No info */) {
    // ** addr: 0xbaa888, size: 0x88
    // 0xbaa888: EnterFrame
    //     0xbaa888: stp             fp, lr, [SP, #-0x10]!
    //     0xbaa88c: mov             fp, SP
    // 0xbaa890: AllocStack(0x10)
    //     0xbaa890: sub             SP, SP, #0x10
    // 0xbaa894: SetupParameters(_DialogWindowRoute<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xbaa894: mov             x4, x1
    //     0xbaa898: mov             x3, x2
    //     0xbaa89c: stur            x1, [fp, #-8]
    //     0xbaa8a0: stur            x2, [fp, #-0x10]
    // 0xbaa8a4: CheckStackOverflow
    //     0xbaa8a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbaa8a8: cmp             SP, x16
    //     0xbaa8ac: b.ls            #0xbaa908
    // 0xbaa8b0: LoadField: r2 = r4->field_7
    //     0xbaa8b0: ldur            w2, [x4, #7]
    // 0xbaa8b4: DecompressPointer r2
    //     0xbaa8b4: add             x2, x2, HEAP, lsl #32
    // 0xbaa8b8: mov             x0, x3
    // 0xbaa8bc: r1 = Null
    //     0xbaa8bc: mov             x1, NULL
    // 0xbaa8c0: cmp             w0, NULL
    // 0xbaa8c4: b.eq            #0xbaa8ec
    // 0xbaa8c8: cmp             w2, NULL
    // 0xbaa8cc: b.eq            #0xbaa8ec
    // 0xbaa8d0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbaa8d0: ldur            w4, [x2, #0x17]
    // 0xbaa8d4: DecompressPointer r4
    //     0xbaa8d4: add             x4, x4, HEAP, lsl #32
    // 0xbaa8d8: r8 = X0?
    //     0xbaa8d8: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbaa8dc: LoadField: r9 = r4->field_7
    //     0xbaa8dc: ldur            x9, [x4, #7]
    // 0xbaa8e0: r3 = Null
    //     0xbaa8e0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26788] Null
    //     0xbaa8e4: ldr             x3, [x3, #0x788]
    // 0xbaa8e8: blr             x9
    // 0xbaa8ec: ldur            x1, [fp, #-8]
    // 0xbaa8f0: ldur            x2, [fp, #-0x10]
    // 0xbaa8f4: r0 = didComplete()
    //     0xbaa8f4: bl              #0x8cc97c  ; [package:flutter/src/widgets/navigator.dart] Route::didComplete
    // 0xbaa8f8: r0 = true
    //     0xbaa8f8: add             x0, NULL, #0x20  ; true
    // 0xbaa8fc: LeaveFrame
    //     0xbaa8fc: mov             SP, fp
    //     0xbaa900: ldp             fp, lr, [SP], #0x10
    // 0xbaa904: ret
    //     0xbaa904: ret             
    // 0xbaa908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaa908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaa90c: b               #0xbaa8b0
  }
  _ install(/* No info */) {
    // ** addr: 0xbae588, size: 0x128
    // 0xbae588: EnterFrame
    //     0xbae588: stp             fp, lr, [SP, #-0x10]!
    //     0xbae58c: mov             fp, SP
    // 0xbae590: AllocStack(0x20)
    //     0xbae590: sub             SP, SP, #0x20
    // 0xbae594: SetupParameters(_DialogWindowRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0xbae594: mov             x0, x1
    //     0xbae598: stur            x1, [fp, #-8]
    // 0xbae59c: CheckStackOverflow
    //     0xbae59c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbae5a0: cmp             SP, x16
    //     0xbae5a4: b.ls            #0xbae6a0
    // 0xbae5a8: r1 = Function '<anonymous closure>':.
    //     0xbae5a8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26798] AnonymousClosure: (0x12e6390), in [package:flutter/src/widgets/dialog.dart] _DialogWindowRoute::install (0xbae588)
    //     0xbae5ac: ldr             x1, [x1, #0x798]
    // 0xbae5b0: r2 = Null
    //     0xbae5b0: mov             x2, NULL
    // 0xbae5b4: r0 = AllocateClosure()
    //     0xbae5b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbae5b8: stur            x0, [fp, #-0x10]
    // 0xbae5bc: r0 = OverlayEntry()
    //     0xbae5bc: bl              #0x856d58  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x28)
    // 0xbae5c0: mov             x1, x0
    // 0xbae5c4: ldur            x2, [fp, #-0x10]
    // 0xbae5c8: stur            x0, [fp, #-0x10]
    // 0xbae5cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbae5cc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbae5d0: r0 = OverlayEntry()
    //     0xbae5d0: bl              #0x856afc  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0xbae5d4: r1 = Null
    //     0xbae5d4: mov             x1, NULL
    // 0xbae5d8: r2 = 2
    //     0xbae5d8: mov             x2, #2
    // 0xbae5dc: r0 = AllocateArray()
    //     0xbae5dc: bl              #0x13df928  ; AllocateArrayStub
    // 0xbae5e0: mov             x2, x0
    // 0xbae5e4: ldur            x0, [fp, #-0x10]
    // 0xbae5e8: stur            x2, [fp, #-0x18]
    // 0xbae5ec: StoreField: r2->field_f = r0
    //     0xbae5ec: stur            w0, [x2, #0xf]
    // 0xbae5f0: r1 = <OverlayEntry>
    //     0xbae5f0: ldr             x1, [PP, #0x5340]  ; [pp+0x5340] TypeArguments: <OverlayEntry>
    // 0xbae5f4: r0 = AllocateGrowableArray()
    //     0xbae5f4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xbae5f8: mov             x1, x0
    // 0xbae5fc: ldur            x0, [fp, #-0x18]
    // 0xbae600: StoreField: r1->field_f = r0
    //     0xbae600: stur            w0, [x1, #0xf]
    // 0xbae604: r0 = 2
    //     0xbae604: mov             x0, #2
    // 0xbae608: StoreField: r1->field_b = r0
    //     0xbae608: stur            w0, [x1, #0xb]
    // 0xbae60c: ldur            x2, [fp, #-8]
    // 0xbae610: LoadField: r0 = r2->field_37
    //     0xbae610: ldur            w0, [x2, #0x37]
    // 0xbae614: DecompressPointer r0
    //     0xbae614: add             x0, x0, HEAP, lsl #32
    // 0xbae618: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbae61c: cmp             w0, w16
    // 0xbae620: b.ne            #0xbae68c
    // 0xbae624: mov             x0, x1
    // 0xbae628: StoreField: r2->field_37 = r0
    //     0xbae628: stur            w0, [x2, #0x37]
    //     0xbae62c: ldurb           w16, [x2, #-1]
    //     0xbae630: ldurb           w17, [x0, #-1]
    //     0xbae634: and             x16, x17, x16, lsr #2
    //     0xbae638: tst             x16, HEAP, lsr #32
    //     0xbae63c: b.eq            #0xbae644
    //     0xbae640: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbae644: LoadField: r0 = r2->field_f
    //     0xbae644: ldur            w0, [x2, #0xf]
    // 0xbae648: DecompressPointer r0
    //     0xbae648: add             x0, x0, HEAP, lsl #32
    // 0xbae64c: cmp             w0, NULL
    // 0xbae650: b.ne            #0xbae664
    // 0xbae654: r0 = Null
    //     0xbae654: mov             x0, NULL
    // 0xbae658: LeaveFrame
    //     0xbae658: mov             SP, fp
    //     0xbae65c: ldp             fp, lr, [SP], #0x10
    // 0xbae660: ret
    //     0xbae660: ret             
    // 0xbae664: r1 = Null
    //     0xbae664: mov             x1, NULL
    // 0xbae668: LoadField: r2 = r0->field_f
    //     0xbae668: ldur            w2, [x0, #0xf]
    // 0xbae66c: DecompressPointer r2
    //     0xbae66c: add             x2, x2, HEAP, lsl #32
    // 0xbae670: cmp             w2, NULL
    // 0xbae674: b.eq            #0xbae6a8
    // 0xbae678: cmp             w1, NULL
    // 0xbae67c: b.eq            #0xbae6ac
    // 0xbae680: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbae680: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbae684: r0 = Throw()
    //     0xbae684: bl              #0x13ddb2c  ; ThrowStub
    // 0xbae688: brk             #0
    // 0xbae68c: r16 = "_overlayEntries@530071048"
    //     0xbae68c: add             x16, PP, #0x26, lsl #12  ; [pp+0x267a0] "_overlayEntries@530071048"
    //     0xbae690: ldr             x16, [x16, #0x7a0]
    // 0xbae694: str             x16, [SP]
    // 0xbae698: r0 = _throwFieldAlreadyInitialized()
    //     0xbae698: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xbae69c: brk             #0
    // 0xbae6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbae6a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbae6a4: b               #0xbae5a8
    // 0xbae6a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbae6a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbae6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbae6ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb15f8, size: 0x34
    // 0xbb15f8: EnterFrame
    //     0xbb15f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbb15fc: mov             fp, SP
    // 0xbb1600: CheckStackOverflow
    //     0xbb1600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1604: cmp             SP, x16
    //     0xbb1608: b.ls            #0xbb1624
    // 0xbb160c: StoreField: r1->field_2f = rNULL
    //     0xbb160c: stur            NULL, [x1, #0x2f]
    // 0xbb1610: r0 = dispose()
    //     0xbb1610: bl              #0xbb12c8  ; [package:flutter/src/widgets/navigator.dart] Route::dispose
    // 0xbb1614: r0 = Null
    //     0xbb1614: mov             x0, NULL
    // 0xbb1618: LeaveFrame
    //     0xbb1618: mov             SP, fp
    //     0xbb161c: ldp             fp, lr, [SP], #0x10
    // 0xbb1620: ret
    //     0xbb1620: ret             
    // 0xbb1624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1628: b               #0xbb160c
  }
  get _ overlayEntries(/* No info */) {
    // ** addr: 0xbb66c8, size: 0x2c
    // 0xbb66c8: LoadField: r0 = r1->field_37
    //     0xbb66c8: ldur            w0, [x1, #0x37]
    // 0xbb66cc: DecompressPointer r0
    //     0xbb66cc: add             x0, x0, HEAP, lsl #32
    // 0xbb66d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbb66d4: cmp             w0, w16
    // 0xbb66d8: b.eq            #0xbb66e0
    // 0xbb66dc: ret
    //     0xbb66dc: ret             
    // 0xbb66e0: EnterFrame
    //     0xbb66e0: stp             fp, lr, [SP, #-0x10]!
    //     0xbb66e4: mov             fp, SP
    // 0xbb66e8: r9 = _overlayEntries
    //     0xbb66e8: add             x9, PP, #0x26, lsl #12  ; [pp+0x267a8] Field <_DialogWindowRoute@530071048._overlayEntries@530071048>: late final (offset: 0x38)
    //     0xbb66ec: ldr             x9, [x9, #0x7a8]
    // 0xbb66f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbb66f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _DialogWindowRoute(/* No info */) {
    // ** addr: 0xd953c0, size: 0xa8
    // 0xd953c0: EnterFrame
    //     0xd953c0: stp             fp, lr, [SP, #-0x10]!
    //     0xd953c4: mov             fp, SP
    // 0xd953c8: AllocStack(0x10)
    //     0xd953c8: sub             SP, SP, #0x10
    // 0xd953cc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd953d0: mov             x4, x1
    // 0xd953d4: stur            x1, [fp, #-8]
    // 0xd953d8: mov             x1, x3
    // 0xd953dc: mov             x3, x2
    // 0xd953e0: mov             x2, x5
    // 0xd953e4: stur            x5, [fp, #-0x10]
    // 0xd953e8: CheckStackOverflow
    //     0xd953e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd953ec: cmp             SP, x16
    //     0xd953f0: b.ls            #0xd95460
    // 0xd953f4: StoreField: r4->field_37 = r0
    //     0xd953f4: stur            w0, [x4, #0x37]
    // 0xd953f8: mov             x0, x3
    // 0xd953fc: StoreField: r4->field_23 = r0
    //     0xd953fc: stur            w0, [x4, #0x23]
    //     0xd95400: ldurb           w16, [x4, #-1]
    //     0xd95404: ldurb           w17, [x0, #-1]
    //     0xd95408: and             x16, x17, x16, lsr #2
    //     0xd9540c: tst             x16, HEAP, lsr #32
    //     0xd95410: b.eq            #0xd95418
    //     0xd95414: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd95418: r0 = maybeOf()
    //     0xd95418: bl              #0xd956a8  ; [package:flutter/src/widgets/_window.dart] WindowRegistry::maybeOf
    // 0xd9541c: ldur            x1, [fp, #-8]
    // 0xd95420: StoreField: r1->field_2b = r0
    //     0xd95420: stur            w0, [x1, #0x2b]
    //     0xd95424: ldurb           w16, [x1, #-1]
    //     0xd95428: ldurb           w17, [x0, #-1]
    //     0xd9542c: and             x16, x17, x16, lsr #2
    //     0xd95430: tst             x16, HEAP, lsr #32
    //     0xd95434: b.eq            #0xd9543c
    //     0xd95438: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd9543c: ldur            x2, [fp, #-0x10]
    // 0xd95440: r0 = Route()
    //     0xd95440: bl              #0x8e07e0  ; [package:flutter/src/widgets/navigator.dart] Route::Route
    // 0xd95444: r0 = _DialogWindowDelegate()
    //     0xd95444: bl              #0xd95580  ; Allocate_DialogWindowDelegateStub -> _DialogWindowDelegate (size=0x8)
    // 0xd95448: mov             x2, x0
    // 0xd9544c: r1 = Null
    //     0xd9544c: mov             x1, NULL
    // 0xd95450: r0 = DialogWindowController()
    //     0xd95450: bl              #0xd95468  ; [package:flutter/src/widgets/_window.dart] DialogWindowController::DialogWindowController
    // 0xd95454: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd95454: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd95458: r0 = Throw()
    //     0xd95458: bl              #0x13ddb2c  ; ThrowStub
    // 0xd9545c: brk             #0
    // 0xd95460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd95460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95464: b               #0xd953f4
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x12e6390, size: 0x8
    // 0x12e6390: r0 = Instance_SizedBox
    //     0x12e6390: ldr             x0, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0x12e6394: ret
    //     0x12e6394: ret             
  }
}

// class id: 2722, size: 0x8, field offset: 0x8
class _DialogWindowDelegate extends DialogWindowControllerDelegate {
}
