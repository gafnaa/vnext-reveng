// lib: , url: package:flutter/src/widgets/context_menu_controller.dart

// class id: 1049125, size: 0x8
class :: {
}

// class id: 2713, size: 0xc, field offset: 0x8
class ContextMenuController extends Object {

  _ show(/* No info */) {
    // ** addr: 0x8555b0, size: 0x124
    // 0x8555b0: EnterFrame
    //     0x8555b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8555b4: mov             fp, SP
    // 0x8555b8: AllocStack(0x28)
    //     0x8555b8: sub             SP, SP, #0x28
    // 0x8555bc: SetupParameters(ContextMenuController this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x8555bc: stur            x1, [fp, #-8]
    //     0x8555c0: mov             x16, x2
    //     0x8555c4: mov             x2, x1
    //     0x8555c8: mov             x1, x16
    //     0x8555cc: stur            x1, [fp, #-0x10]
    //     0x8555d0: stur            x3, [fp, #-0x18]
    // 0x8555d4: CheckStackOverflow
    //     0x8555d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8555d8: cmp             SP, x16
    //     0x8555dc: b.ls            #0x8556c8
    // 0x8555e0: r1 = 2
    //     0x8555e0: mov             x1, #2
    // 0x8555e4: r0 = AllocateContext()
    //     0x8555e4: bl              #0x13de838  ; AllocateContextStub
    // 0x8555e8: mov             x1, x0
    // 0x8555ec: ldur            x0, [fp, #-0x18]
    // 0x8555f0: stur            x1, [fp, #-0x20]
    // 0x8555f4: StoreField: r1->field_f = r0
    //     0x8555f4: stur            w0, [x1, #0xf]
    // 0x8555f8: r0 = removeAny()
    //     0x8555f8: bl              #0x855cf4  ; [package:flutter/src/widgets/context_menu_controller.dart] ContextMenuController::removeAny
    // 0x8555fc: r16 = true
    //     0x8555fc: add             x16, NULL, #0x20  ; true
    // 0x855600: str             x16, [SP]
    // 0x855604: ldur            x1, [fp, #-0x10]
    // 0x855608: r4 = const [0, 0x2, 0x1, 0x1, rootOverlay, 0x1, null]
    //     0x855608: ldr             x4, [PP, #0x4f30]  ; [pp+0x4f30] List(7) [0, 0x2, 0x1, 0x1, "rootOverlay", 0x1, Null]
    // 0x85560c: r0 = of()
    //     0x85560c: bl              #0x856338  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x855610: ldur            x1, [fp, #-0x10]
    // 0x855614: stur            x0, [fp, #-0x18]
    // 0x855618: r0 = maybeOf()
    //     0x855618: bl              #0x855aa8  ; [package:flutter/src/widgets/navigator.dart] Navigator::maybeOf
    // 0x85561c: cmp             w0, NULL
    // 0x855620: b.ne            #0x85562c
    // 0x855624: r2 = Null
    //     0x855624: mov             x2, NULL
    // 0x855628: b               #0x855640
    // 0x85562c: LoadField: r1 = r0->field_f
    //     0x85562c: ldur            w1, [x0, #0xf]
    // 0x855630: DecompressPointer r1
    //     0x855630: add             x1, x1, HEAP, lsl #32
    // 0x855634: cmp             w1, NULL
    // 0x855638: b.eq            #0x8556d0
    // 0x85563c: mov             x2, x1
    // 0x855640: ldur            x0, [fp, #-0x20]
    // 0x855644: ldur            x1, [fp, #-0x10]
    // 0x855648: r0 = capture()
    //     0x855648: bl              #0x8556d4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0x85564c: ldur            x2, [fp, #-0x20]
    // 0x855650: StoreField: r2->field_13 = r0
    //     0x855650: stur            w0, [x2, #0x13]
    //     0x855654: ldurb           w16, [x2, #-1]
    //     0x855658: ldurb           w17, [x0, #-1]
    //     0x85565c: and             x16, x17, x16, lsr #2
    //     0x855660: tst             x16, HEAP, lsr #32
    //     0x855664: b.eq            #0x85566c
    //     0x855668: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x85566c: r1 = Function '<anonymous closure>':.
    //     0x85566c: ldr             x1, [PP, #0x4f78]  ; [pp+0x4f78] AnonymousClosure: (0x8560a4), in [package:flutter/src/widgets/context_menu_controller.dart] ContextMenuController::show (0x8555b0)
    // 0x855670: r0 = AllocateClosure()
    //     0x855670: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x855674: stur            x0, [fp, #-0x10]
    // 0x855678: r0 = OverlayEntry()
    //     0x855678: bl              #0x856d58  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x28)
    // 0x85567c: mov             x1, x0
    // 0x855680: ldur            x2, [fp, #-0x10]
    // 0x855684: stur            x0, [fp, #-0x10]
    // 0x855688: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x855688: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85568c: r0 = OverlayEntry()
    //     0x85568c: bl              #0x856afc  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x855690: ldur            x2, [fp, #-0x10]
    // 0x855694: StoreStaticField(0xb94, r2)
    //     0x855694: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x855698: str             x2, [x0, #0x1728]
    // 0x85569c: ldur            x1, [fp, #-0x18]
    // 0x8556a0: ldur            x2, [fp, #-0x10]
    // 0x8556a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8556a4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8556a8: r0 = insert()
    //     0x8556a8: bl              #0x856158  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0x8556ac: ldur            x2, [fp, #-8]
    // 0x8556b0: StoreStaticField(0xb90, r2)
    //     0x8556b0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8556b4: str             x2, [x1, #0x1720]
    // 0x8556b8: r0 = Null
    //     0x8556b8: mov             x0, NULL
    // 0x8556bc: LeaveFrame
    //     0x8556bc: mov             SP, fp
    //     0x8556c0: ldp             fp, lr, [SP], #0x10
    // 0x8556c4: ret
    //     0x8556c4: ret             
    // 0x8556c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8556c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8556cc: b               #0x8555e0
    // 0x8556d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8556d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static void removeAny() {
    // ** addr: 0x855cf4, size: 0x7c
    // 0x855cf4: EnterFrame
    //     0x855cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x855cf8: mov             fp, SP
    // 0x855cfc: CheckStackOverflow
    //     0x855cfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x855d00: cmp             SP, x16
    //     0x855d04: b.ls            #0x855d68
    // 0x855d08: r1 = LoadStaticField(0xb94)
    //     0x855d08: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x855d0c: ldr             x1, [x1, #0x1728]
    // 0x855d10: cmp             w1, NULL
    // 0x855d14: b.eq            #0x855d1c
    // 0x855d18: r0 = remove()
    //     0x855d18: bl              #0x855e3c  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x855d1c: r1 = LoadStaticField(0xb94)
    //     0x855d1c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x855d20: ldr             x1, [x1, #0x1728]
    // 0x855d24: cmp             w1, NULL
    // 0x855d28: b.eq            #0x855d30
    // 0x855d2c: r0 = dispose()
    //     0x855d2c: bl              #0x855d70  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::dispose
    // 0x855d30: r2 = Null
    //     0x855d30: mov             x2, NULL
    // 0x855d34: StoreStaticField(0xb94, r2)
    //     0x855d34: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x855d38: str             x2, [x1, #0x1728]
    // 0x855d3c: r1 = LoadStaticField(0xb90)
    //     0x855d3c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x855d40: ldr             x1, [x1, #0x1720]
    // 0x855d44: cmp             w1, NULL
    // 0x855d48: b.eq            #0x855d58
    // 0x855d4c: r2 = Null
    //     0x855d4c: mov             x2, NULL
    // 0x855d50: StoreStaticField(0xb90, r2)
    //     0x855d50: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x855d54: str             x2, [x1, #0x1720]
    // 0x855d58: r0 = Null
    //     0x855d58: mov             x0, NULL
    // 0x855d5c: LeaveFrame
    //     0x855d5c: mov             SP, fp
    //     0x855d60: ldp             fp, lr, [SP], #0x10
    // 0x855d64: ret
    //     0x855d64: ret             
    // 0x855d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855d68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855d6c: b               #0x855d08
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8560a4, size: 0x6c
    // 0x8560a4: EnterFrame
    //     0x8560a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8560a8: mov             fp, SP
    // 0x8560ac: AllocStack(0x18)
    //     0x8560ac: sub             SP, SP, #0x18
    // 0x8560b0: SetupParameters([dynamic _ /* r0 */])
    //     0x8560b0: ldr             x0, [fp, #0x18]
    //     0x8560b4: ldur            w1, [x0, #0x17]
    //     0x8560b8: add             x1, x1, HEAP, lsl #32
    // 0x8560bc: CheckStackOverflow
    //     0x8560bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8560c0: cmp             SP, x16
    //     0x8560c4: b.ls            #0x856108
    // 0x8560c8: LoadField: r2 = r1->field_13
    //     0x8560c8: ldur            w2, [x1, #0x13]
    // 0x8560cc: DecompressPointer r2
    //     0x8560cc: add             x2, x2, HEAP, lsl #32
    // 0x8560d0: stur            x2, [fp, #-8]
    // 0x8560d4: LoadField: r0 = r1->field_f
    //     0x8560d4: ldur            w0, [x1, #0xf]
    // 0x8560d8: DecompressPointer r0
    //     0x8560d8: add             x0, x0, HEAP, lsl #32
    // 0x8560dc: ldr             x16, [fp, #0x10]
    // 0x8560e0: stp             x16, x0, [SP]
    // 0x8560e4: ClosureCall
    //     0x8560e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8560e8: ldur            x2, [x0, #0x1f]
    //     0x8560ec: blr             x2
    // 0x8560f0: ldur            x1, [fp, #-8]
    // 0x8560f4: mov             x2, x0
    // 0x8560f8: r0 = wrap()
    //     0x8560f8: bl              #0x856110  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0x8560fc: LeaveFrame
    //     0x8560fc: mov             SP, fp
    //     0x856100: ldp             fp, lr, [SP], #0x10
    // 0x856104: ret
    //     0x856104: ret             
    // 0x856108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85610c: b               #0x8560c8
  }
  _ markNeedsBuild(/* No info */) {
    // ** addr: 0x85911c, size: 0x40
    // 0x85911c: EnterFrame
    //     0x85911c: stp             fp, lr, [SP, #-0x10]!
    //     0x859120: mov             fp, SP
    // 0x859124: CheckStackOverflow
    //     0x859124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859128: cmp             SP, x16
    //     0x85912c: b.ls            #0x859154
    // 0x859130: r1 = LoadStaticField(0xb94)
    //     0x859130: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x859134: ldr             x1, [x1, #0x1728]
    // 0x859138: cmp             w1, NULL
    // 0x85913c: b.eq            #0x859144
    // 0x859140: r0 = markNeedsBuild()
    //     0x859140: bl              #0x85915c  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::markNeedsBuild
    // 0x859144: r0 = Null
    //     0x859144: mov             x0, NULL
    // 0x859148: LeaveFrame
    //     0x859148: mov             SP, fp
    //     0x85914c: ldp             fp, lr, [SP], #0x10
    // 0x859150: ret
    //     0x859150: ret             
    // 0x859154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859158: b               #0x859130
  }
  _ remove(/* No info */) {
    // ** addr: 0x862be0, size: 0x50
    // 0x862be0: EnterFrame
    //     0x862be0: stp             fp, lr, [SP, #-0x10]!
    //     0x862be4: mov             fp, SP
    // 0x862be8: CheckStackOverflow
    //     0x862be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x862bec: cmp             SP, x16
    //     0x862bf0: b.ls            #0x862c28
    // 0x862bf4: r0 = LoadStaticField(0xb90)
    //     0x862bf4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x862bf8: ldr             x0, [x0, #0x1720]
    // 0x862bfc: cmp             w0, w1
    // 0x862c00: b.eq            #0x862c14
    // 0x862c04: r0 = Null
    //     0x862c04: mov             x0, NULL
    // 0x862c08: LeaveFrame
    //     0x862c08: mov             SP, fp
    //     0x862c0c: ldp             fp, lr, [SP], #0x10
    // 0x862c10: ret
    //     0x862c10: ret             
    // 0x862c14: r0 = removeAny()
    //     0x862c14: bl              #0x855cf4  ; [package:flutter/src/widgets/context_menu_controller.dart] ContextMenuController::removeAny
    // 0x862c18: r0 = Null
    //     0x862c18: mov             x0, NULL
    // 0x862c1c: LeaveFrame
    //     0x862c1c: mov             SP, fp
    //     0x862c20: ldp             fp, lr, [SP], #0x10
    // 0x862c24: ret
    //     0x862c24: ret             
    // 0x862c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862c28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862c2c: b               #0x862bf4
  }
}
