// lib: , url: package:flutter/src/widgets/automatic_keep_alive.dart

// class id: 1049119, size: 0x8
class :: {
}

// class id: 4468, size: 0x24, field offset: 0x24
class KeepAliveHandle extends ChangeNotifier {

  _ dispose(/* No info */) {
    // ** addr: 0x10ef6c0, size: 0x48
    // 0x10ef6c0: EnterFrame
    //     0x10ef6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef6c4: mov             fp, SP
    // 0x10ef6c8: AllocStack(0x8)
    //     0x10ef6c8: sub             SP, SP, #8
    // 0x10ef6cc: SetupParameters(KeepAliveHandle this /* r1 => r0, fp-0x8 */)
    //     0x10ef6cc: mov             x0, x1
    //     0x10ef6d0: stur            x1, [fp, #-8]
    // 0x10ef6d4: CheckStackOverflow
    //     0x10ef6d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef6d8: cmp             SP, x16
    //     0x10ef6dc: b.ls            #0x10ef700
    // 0x10ef6e0: mov             x1, x0
    // 0x10ef6e4: r0 = notifyListeners()
    //     0x10ef6e4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x10ef6e8: ldur            x1, [fp, #-8]
    // 0x10ef6ec: r0 = dispose()
    //     0x10ef6ec: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ef6f0: r0 = Null
    //     0x10ef6f0: mov             x0, NULL
    // 0x10ef6f4: LeaveFrame
    //     0x10ef6f4: mov             SP, fp
    //     0x10ef6f8: ldp             fp, lr, [SP], #0x10
    // 0x10ef6fc: ret
    //     0x10ef6fc: ret             
    // 0x10ef700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef704: b               #0x10ef6e0
  }
}

// class id: 4548, size: 0xc, field offset: 0x8
//   const constructor, 
class KeepAliveNotification extends Notification {
}

// class id: 5447, size: 0x20, field offset: 0x14
class _AutomaticKeepAliveState extends State<dynamic> {

  late Widget _child; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xe09394, size: 0x64
    // 0xe09394: EnterFrame
    //     0xe09394: stp             fp, lr, [SP, #-0x10]!
    //     0xe09398: mov             fp, SP
    // 0xe0939c: AllocStack(0x10)
    //     0xe0939c: sub             SP, SP, #0x10
    // 0xe093a0: LoadField: r0 = r1->field_1b
    //     0xe093a0: ldur            w0, [x1, #0x1b]
    // 0xe093a4: DecompressPointer r0
    //     0xe093a4: add             x0, x0, HEAP, lsl #32
    // 0xe093a8: stur            x0, [fp, #-0x10]
    // 0xe093ac: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xe093ac: ldur            w2, [x1, #0x17]
    // 0xe093b0: DecompressPointer r2
    //     0xe093b0: add             x2, x2, HEAP, lsl #32
    // 0xe093b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe093b8: cmp             w2, w16
    // 0xe093bc: b.eq            #0xe093ec
    // 0xe093c0: stur            x2, [fp, #-8]
    // 0xe093c4: r1 = <KeepAliveParentDataMixin>
    //     0xe093c4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd480] TypeArguments: <KeepAliveParentDataMixin>
    //     0xe093c8: ldr             x1, [x1, #0x480]
    // 0xe093cc: r0 = KeepAlive()
    //     0xe093cc: bl              #0xe0941c  ; AllocateKeepAliveStub -> KeepAlive (size=0x18)
    // 0xe093d0: ldur            x1, [fp, #-0x10]
    // 0xe093d4: StoreField: r0->field_13 = r1
    //     0xe093d4: stur            w1, [x0, #0x13]
    // 0xe093d8: ldur            x1, [fp, #-8]
    // 0xe093dc: StoreField: r0->field_b = r1
    //     0xe093dc: stur            w1, [x0, #0xb]
    // 0xe093e0: LeaveFrame
    //     0xe093e0: mov             SP, fp
    //     0xe093e4: ldp             fp, lr, [SP], #0x10
    // 0xe093e8: ret
    //     0xe093e8: ret             
    // 0xe093ec: r9 = _child
    //     0xe093ec: add             x9, PP, #0xcd, lsl #12  ; [pp+0xcd488] Field <_AutomaticKeepAliveState@94490736._child@94490736>: late (offset: 0x18)
    //     0xe093f0: ldr             x9, [x9, #0x488]
    // 0xe093f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe093f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf70b18, size: 0xc0
    // 0xf70b18: EnterFrame
    //     0xf70b18: stp             fp, lr, [SP, #-0x10]!
    //     0xf70b1c: mov             fp, SP
    // 0xf70b20: AllocStack(0x10)
    //     0xf70b20: sub             SP, SP, #0x10
    // 0xf70b24: SetupParameters(_AutomaticKeepAliveState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf70b24: mov             x4, x1
    //     0xf70b28: mov             x3, x2
    //     0xf70b2c: stur            x1, [fp, #-8]
    //     0xf70b30: stur            x2, [fp, #-0x10]
    // 0xf70b34: CheckStackOverflow
    //     0xf70b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70b38: cmp             SP, x16
    //     0xf70b3c: b.ls            #0xf70bd0
    // 0xf70b40: mov             x0, x3
    // 0xf70b44: r2 = Null
    //     0xf70b44: mov             x2, NULL
    // 0xf70b48: r1 = Null
    //     0xf70b48: mov             x1, NULL
    // 0xf70b4c: r4 = 60
    //     0xf70b4c: mov             x4, #0x3c
    // 0xf70b50: branchIfSmi(r0, 0xf70b5c)
    //     0xf70b50: tbz             w0, #0, #0xf70b5c
    // 0xf70b54: r4 = LoadClassIdInstr(r0)
    //     0xf70b54: ldur            x4, [x0, #-1]
    //     0xf70b58: ubfx            x4, x4, #0xc, #0x14
    // 0xf70b5c: r17 = 6400
    //     0xf70b5c: mov             x17, #0x1900
    // 0xf70b60: cmp             x4, x17
    // 0xf70b64: b.eq            #0xf70b7c
    // 0xf70b68: r8 = AutomaticKeepAlive
    //     0xf70b68: add             x8, PP, #0xcd, lsl #12  ; [pp+0xcd4a0] Type: AutomaticKeepAlive
    //     0xf70b6c: ldr             x8, [x8, #0x4a0]
    // 0xf70b70: r3 = Null
    //     0xf70b70: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd4a8] Null
    //     0xf70b74: ldr             x3, [x3, #0x4a8]
    // 0xf70b78: r0 = AutomaticKeepAlive()
    //     0xf70b78: bl              #0xe093f8  ; IsType_AutomaticKeepAlive_Stub
    // 0xf70b7c: ldur            x3, [fp, #-8]
    // 0xf70b80: LoadField: r2 = r3->field_7
    //     0xf70b80: ldur            w2, [x3, #7]
    // 0xf70b84: DecompressPointer r2
    //     0xf70b84: add             x2, x2, HEAP, lsl #32
    // 0xf70b88: ldur            x0, [fp, #-0x10]
    // 0xf70b8c: r1 = Null
    //     0xf70b8c: mov             x1, NULL
    // 0xf70b90: cmp             w2, NULL
    // 0xf70b94: b.eq            #0xf70bb8
    // 0xf70b98: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf70b98: ldur            w4, [x2, #0x17]
    // 0xf70b9c: DecompressPointer r4
    //     0xf70b9c: add             x4, x4, HEAP, lsl #32
    // 0xf70ba0: r8 = X0 bound StatefulWidget
    //     0xf70ba0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf70ba4: ldr             x8, [x8, #0x498]
    // 0xf70ba8: LoadField: r9 = r4->field_7
    //     0xf70ba8: ldur            x9, [x4, #7]
    // 0xf70bac: r3 = Null
    //     0xf70bac: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd4b8] Null
    //     0xf70bb0: ldr             x3, [x3, #0x4b8]
    // 0xf70bb4: blr             x9
    // 0xf70bb8: ldur            x1, [fp, #-8]
    // 0xf70bbc: r0 = _updateChild()
    //     0xf70bbc: bl              #0xf70bd8  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_updateChild
    // 0xf70bc0: r0 = Null
    //     0xf70bc0: mov             x0, NULL
    // 0xf70bc4: LeaveFrame
    //     0xf70bc4: mov             SP, fp
    //     0xf70bc8: ldp             fp, lr, [SP], #0x10
    // 0xf70bcc: ret
    //     0xf70bcc: ret             
    // 0xf70bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70bd4: b               #0xf70b40
  }
  _ _updateChild(/* No info */) {
    // ** addr: 0xf70bd8, size: 0x94
    // 0xf70bd8: EnterFrame
    //     0xf70bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xf70bdc: mov             fp, SP
    // 0xf70be0: AllocStack(0x18)
    //     0xf70be0: sub             SP, SP, #0x18
    // 0xf70be4: SetupParameters(_AutomaticKeepAliveState this /* r1 => r0, fp-0x10 */)
    //     0xf70be4: mov             x0, x1
    //     0xf70be8: stur            x1, [fp, #-0x10]
    // 0xf70bec: LoadField: r1 = r0->field_b
    //     0xf70bec: ldur            w1, [x0, #0xb]
    // 0xf70bf0: DecompressPointer r1
    //     0xf70bf0: add             x1, x1, HEAP, lsl #32
    // 0xf70bf4: cmp             w1, NULL
    // 0xf70bf8: b.eq            #0xf70c68
    // 0xf70bfc: LoadField: r3 = r1->field_b
    //     0xf70bfc: ldur            w3, [x1, #0xb]
    // 0xf70c00: DecompressPointer r3
    //     0xf70c00: add             x3, x3, HEAP, lsl #32
    // 0xf70c04: mov             x2, x0
    // 0xf70c08: stur            x3, [fp, #-8]
    // 0xf70c0c: r1 = Function '_addClient@94490736':.
    //     0xf70c0c: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd4c8] AnonymousClosure: (0xf70c6c), in [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_addClient (0xf70ca8)
    //     0xf70c10: ldr             x1, [x1, #0x4c8]
    // 0xf70c14: r0 = AllocateClosure()
    //     0xf70c14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf70c18: r1 = <KeepAliveNotification>
    //     0xf70c18: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd4d0] TypeArguments: <KeepAliveNotification>
    //     0xf70c1c: ldr             x1, [x1, #0x4d0]
    // 0xf70c20: stur            x0, [fp, #-0x18]
    // 0xf70c24: r0 = NotificationListener()
    //     0xf70c24: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xf70c28: ldur            x1, [fp, #-0x18]
    // 0xf70c2c: StoreField: r0->field_13 = r1
    //     0xf70c2c: stur            w1, [x0, #0x13]
    // 0xf70c30: ldur            x1, [fp, #-8]
    // 0xf70c34: StoreField: r0->field_b = r1
    //     0xf70c34: stur            w1, [x0, #0xb]
    // 0xf70c38: ldur            x1, [fp, #-0x10]
    // 0xf70c3c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf70c3c: stur            w0, [x1, #0x17]
    //     0xf70c40: ldurb           w16, [x1, #-1]
    //     0xf70c44: ldurb           w17, [x0, #-1]
    //     0xf70c48: and             x16, x17, x16, lsr #2
    //     0xf70c4c: tst             x16, HEAP, lsr #32
    //     0xf70c50: b.eq            #0xf70c58
    //     0xf70c54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf70c58: r0 = Null
    //     0xf70c58: mov             x0, NULL
    // 0xf70c5c: LeaveFrame
    //     0xf70c5c: mov             SP, fp
    //     0xf70c60: ldp             fp, lr, [SP], #0x10
    // 0xf70c64: ret
    //     0xf70c64: ret             
    // 0xf70c68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70c68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool _addClient(dynamic, KeepAliveNotification) {
    // ** addr: 0xf70c6c, size: 0x3c
    // 0xf70c6c: EnterFrame
    //     0xf70c6c: stp             fp, lr, [SP, #-0x10]!
    //     0xf70c70: mov             fp, SP
    // 0xf70c74: ldr             x0, [fp, #0x18]
    // 0xf70c78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf70c78: ldur            w1, [x0, #0x17]
    // 0xf70c7c: DecompressPointer r1
    //     0xf70c7c: add             x1, x1, HEAP, lsl #32
    // 0xf70c80: CheckStackOverflow
    //     0xf70c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70c84: cmp             SP, x16
    //     0xf70c88: b.ls            #0xf70ca0
    // 0xf70c8c: ldr             x2, [fp, #0x10]
    // 0xf70c90: r0 = _addClient()
    //     0xf70c90: bl              #0xf70ca8  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_addClient
    // 0xf70c94: LeaveFrame
    //     0xf70c94: mov             SP, fp
    //     0xf70c98: ldp             fp, lr, [SP], #0x10
    // 0xf70c9c: ret
    //     0xf70c9c: ret             
    // 0xf70ca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70ca0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70ca4: b               #0xf70c8c
  }
  _ _addClient(/* No info */) {
    // ** addr: 0xf70ca8, size: 0x258
    // 0xf70ca8: EnterFrame
    //     0xf70ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xf70cac: mov             fp, SP
    // 0xf70cb0: AllocStack(0x38)
    //     0xf70cb0: sub             SP, SP, #0x38
    // 0xf70cb4: SetupParameters(_AutomaticKeepAliveState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf70cb4: stur            x1, [fp, #-8]
    //     0xf70cb8: stur            x2, [fp, #-0x10]
    // 0xf70cbc: CheckStackOverflow
    //     0xf70cbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70cc0: cmp             SP, x16
    //     0xf70cc4: b.ls            #0xf70eec
    // 0xf70cc8: r1 = 1
    //     0xf70cc8: mov             x1, #1
    // 0xf70ccc: r0 = AllocateContext()
    //     0xf70ccc: bl              #0x13de838  ; AllocateContextStub
    // 0xf70cd0: ldur            x1, [fp, #-8]
    // 0xf70cd4: stur            x0, [fp, #-0x20]
    // 0xf70cd8: StoreField: r0->field_f = r1
    //     0xf70cd8: stur            w1, [x0, #0xf]
    // 0xf70cdc: ldur            x2, [fp, #-0x10]
    // 0xf70ce0: LoadField: r3 = r2->field_7
    //     0xf70ce0: ldur            w3, [x2, #7]
    // 0xf70ce4: DecompressPointer r3
    //     0xf70ce4: add             x3, x3, HEAP, lsl #32
    // 0xf70ce8: stur            x3, [fp, #-0x18]
    // 0xf70cec: LoadField: r2 = r1->field_13
    //     0xf70cec: ldur            w2, [x1, #0x13]
    // 0xf70cf0: DecompressPointer r2
    //     0xf70cf0: add             x2, x2, HEAP, lsl #32
    // 0xf70cf4: cmp             w2, NULL
    // 0xf70cf8: b.ne            #0xf70d3c
    // 0xf70cfc: r16 = <Listenable, (dynamic this) => void?>
    //     0xf70cfc: add             x16, PP, #0xcd, lsl #12  ; [pp+0xcd4d8] TypeArguments: <Listenable, (dynamic this) => void?>
    //     0xf70d00: ldr             x16, [x16, #0x4d8]
    // 0xf70d04: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xf70d08: stp             lr, x16, [SP]
    // 0xf70d0c: r0 = Map._fromLiteral()
    //     0xf70d0c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf70d10: mov             x1, x0
    // 0xf70d14: ldur            x3, [fp, #-8]
    // 0xf70d18: StoreField: r3->field_13 = r0
    //     0xf70d18: stur            w0, [x3, #0x13]
    //     0xf70d1c: ldurb           w16, [x3, #-1]
    //     0xf70d20: ldurb           w17, [x0, #-1]
    //     0xf70d24: and             x16, x17, x16, lsr #2
    //     0xf70d28: tst             x16, HEAP, lsr #32
    //     0xf70d2c: b.eq            #0xf70d34
    //     0xf70d30: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf70d34: mov             x0, x1
    // 0xf70d38: b               #0xf70d44
    // 0xf70d3c: mov             x3, x1
    // 0xf70d40: mov             x0, x2
    // 0xf70d44: mov             x1, x3
    // 0xf70d48: ldur            x2, [fp, #-0x18]
    // 0xf70d4c: stur            x0, [fp, #-0x10]
    // 0xf70d50: r0 = _createCallback()
    //     0xf70d50: bl              #0xf715b4  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_createCallback
    // 0xf70d54: ldur            x1, [fp, #-0x10]
    // 0xf70d58: ldur            x2, [fp, #-0x18]
    // 0xf70d5c: mov             x3, x0
    // 0xf70d60: r0 = []=()
    //     0xf70d60: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xf70d64: ldur            x0, [fp, #-8]
    // 0xf70d68: LoadField: r3 = r0->field_13
    //     0xf70d68: ldur            w3, [x0, #0x13]
    // 0xf70d6c: DecompressPointer r3
    //     0xf70d6c: add             x3, x3, HEAP, lsl #32
    // 0xf70d70: stur            x3, [fp, #-0x10]
    // 0xf70d74: cmp             w3, NULL
    // 0xf70d78: b.eq            #0xf70ef4
    // 0xf70d7c: mov             x1, x3
    // 0xf70d80: ldur            x2, [fp, #-0x18]
    // 0xf70d84: r0 = _getValueOrData()
    //     0xf70d84: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf70d88: mov             x1, x0
    // 0xf70d8c: ldur            x0, [fp, #-0x10]
    // 0xf70d90: LoadField: r2 = r0->field_f
    //     0xf70d90: ldur            w2, [x0, #0xf]
    // 0xf70d94: DecompressPointer r2
    //     0xf70d94: add             x2, x2, HEAP, lsl #32
    // 0xf70d98: cmp             w2, w1
    // 0xf70d9c: b.ne            #0xf70da8
    // 0xf70da0: r2 = Null
    //     0xf70da0: mov             x2, NULL
    // 0xf70da4: b               #0xf70dac
    // 0xf70da8: mov             x2, x1
    // 0xf70dac: ldur            x0, [fp, #-8]
    // 0xf70db0: cmp             w2, NULL
    // 0xf70db4: b.eq            #0xf70ef8
    // 0xf70db8: ldur            x1, [fp, #-0x18]
    // 0xf70dbc: r0 = addListener()
    //     0xf70dbc: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf70dc0: ldur            x0, [fp, #-8]
    // 0xf70dc4: LoadField: r1 = r0->field_1b
    //     0xf70dc4: ldur            w1, [x0, #0x1b]
    // 0xf70dc8: DecompressPointer r1
    //     0xf70dc8: add             x1, x1, HEAP, lsl #32
    // 0xf70dcc: tbz             w1, #4, #0xf70edc
    // 0xf70dd0: r1 = true
    //     0xf70dd0: add             x1, NULL, #0x20  ; true
    // 0xf70dd4: StoreField: r0->field_1b = r1
    //     0xf70dd4: stur            w1, [x0, #0x1b]
    // 0xf70dd8: mov             x1, x0
    // 0xf70ddc: r0 = _getChildElement()
    //     0xf70ddc: bl              #0xf71484  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_getChildElement
    // 0xf70de0: cmp             w0, NULL
    // 0xf70de4: b.eq            #0xf70df8
    // 0xf70de8: ldur            x1, [fp, #-8]
    // 0xf70dec: mov             x2, x0
    // 0xf70df0: r0 = _updateParentDataOfChild()
    //     0xf70df0: bl              #0xf70f00  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_updateParentDataOfChild
    // 0xf70df4: b               #0xf70edc
    // 0xf70df8: r0 = LoadStaticField(0x5e4)
    //     0xf70df8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf70dfc: ldr             x0, [x0, #0xbc8]
    // 0xf70e00: cmp             w0, NULL
    // 0xf70e04: b.eq            #0xf70efc
    // 0xf70e08: LoadField: r3 = r0->field_53
    //     0xf70e08: ldur            w3, [x0, #0x53]
    // 0xf70e0c: DecompressPointer r3
    //     0xf70e0c: add             x3, x3, HEAP, lsl #32
    // 0xf70e10: stur            x3, [fp, #-0x10]
    // 0xf70e14: LoadField: r0 = r3->field_7
    //     0xf70e14: ldur            w0, [x3, #7]
    // 0xf70e18: DecompressPointer r0
    //     0xf70e18: add             x0, x0, HEAP, lsl #32
    // 0xf70e1c: ldur            x2, [fp, #-0x20]
    // 0xf70e20: stur            x0, [fp, #-8]
    // 0xf70e24: r1 = Function '<anonymous closure>':.
    //     0xf70e24: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd4e0] AnonymousClosure: (0xf7181c), in [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_addClient (0xf70ca8)
    //     0xf70e28: ldr             x1, [x1, #0x4e0]
    // 0xf70e2c: r0 = AllocateClosure()
    //     0xf70e2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf70e30: ldur            x2, [fp, #-8]
    // 0xf70e34: mov             x3, x0
    // 0xf70e38: r1 = Null
    //     0xf70e38: mov             x1, NULL
    // 0xf70e3c: stur            x3, [fp, #-8]
    // 0xf70e40: cmp             w2, NULL
    // 0xf70e44: b.eq            #0xf70e64
    // 0xf70e48: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf70e48: ldur            w4, [x2, #0x17]
    // 0xf70e4c: DecompressPointer r4
    //     0xf70e4c: add             x4, x4, HEAP, lsl #32
    // 0xf70e50: r8 = X0
    //     0xf70e50: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf70e54: LoadField: r9 = r4->field_7
    //     0xf70e54: ldur            x9, [x4, #7]
    // 0xf70e58: r3 = Null
    //     0xf70e58: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd4e8] Null
    //     0xf70e5c: ldr             x3, [x3, #0x4e8]
    // 0xf70e60: blr             x9
    // 0xf70e64: ldur            x0, [fp, #-0x10]
    // 0xf70e68: LoadField: r1 = r0->field_b
    //     0xf70e68: ldur            w1, [x0, #0xb]
    // 0xf70e6c: LoadField: r2 = r0->field_f
    //     0xf70e6c: ldur            w2, [x0, #0xf]
    // 0xf70e70: DecompressPointer r2
    //     0xf70e70: add             x2, x2, HEAP, lsl #32
    // 0xf70e74: LoadField: r3 = r2->field_b
    //     0xf70e74: ldur            w3, [x2, #0xb]
    // 0xf70e78: r2 = LoadInt32Instr(r1)
    //     0xf70e78: sbfx            x2, x1, #1, #0x1f
    // 0xf70e7c: stur            x2, [fp, #-0x28]
    // 0xf70e80: r1 = LoadInt32Instr(r3)
    //     0xf70e80: sbfx            x1, x3, #1, #0x1f
    // 0xf70e84: cmp             x2, x1
    // 0xf70e88: b.ne            #0xf70e94
    // 0xf70e8c: mov             x1, x0
    // 0xf70e90: r0 = _growToNextCapacity()
    //     0xf70e90: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf70e94: ldur            x2, [fp, #-0x10]
    // 0xf70e98: ldur            x3, [fp, #-0x28]
    // 0xf70e9c: add             x4, x3, #1
    // 0xf70ea0: lsl             x5, x4, #1
    // 0xf70ea4: StoreField: r2->field_b = r5
    //     0xf70ea4: stur            w5, [x2, #0xb]
    // 0xf70ea8: LoadField: r1 = r2->field_f
    //     0xf70ea8: ldur            w1, [x2, #0xf]
    // 0xf70eac: DecompressPointer r1
    //     0xf70eac: add             x1, x1, HEAP, lsl #32
    // 0xf70eb0: ldur            x0, [fp, #-8]
    // 0xf70eb4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf70eb4: add             x25, x1, x3, lsl #2
    //     0xf70eb8: add             x25, x25, #0xf
    //     0xf70ebc: str             w0, [x25]
    //     0xf70ec0: tbz             w0, #0, #0xf70edc
    //     0xf70ec4: ldurb           w16, [x1, #-1]
    //     0xf70ec8: ldurb           w17, [x0, #-1]
    //     0xf70ecc: and             x16, x17, x16, lsr #2
    //     0xf70ed0: tst             x16, HEAP, lsr #32
    //     0xf70ed4: b.eq            #0xf70edc
    //     0xf70ed8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf70edc: r0 = false
    //     0xf70edc: add             x0, NULL, #0x30  ; false
    // 0xf70ee0: LeaveFrame
    //     0xf70ee0: mov             SP, fp
    //     0xf70ee4: ldp             fp, lr, [SP], #0x10
    // 0xf70ee8: ret
    //     0xf70ee8: ret             
    // 0xf70eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70eec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70ef0: b               #0xf70cc8
    // 0xf70ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70ef4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf70ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70ef8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf70efc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70efc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateParentDataOfChild(/* No info */) {
    // ** addr: 0xf70f00, size: 0x5c
    // 0xf70f00: EnterFrame
    //     0xf70f00: stp             fp, lr, [SP, #-0x10]!
    //     0xf70f04: mov             fp, SP
    // 0xf70f08: AllocStack(0x8)
    //     0xf70f08: sub             SP, SP, #8
    // 0xf70f0c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xf70f0c: mov             x0, x2
    //     0xf70f10: stur            x2, [fp, #-8]
    // 0xf70f14: CheckStackOverflow
    //     0xf70f14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf70f18: cmp             SP, x16
    //     0xf70f1c: b.ls            #0xf70f50
    // 0xf70f20: LoadField: r2 = r1->field_f
    //     0xf70f20: ldur            w2, [x1, #0xf]
    // 0xf70f24: DecompressPointer r2
    //     0xf70f24: add             x2, x2, HEAP, lsl #32
    // 0xf70f28: cmp             w2, NULL
    // 0xf70f2c: b.eq            #0xf70f58
    // 0xf70f30: r0 = build()
    //     0xf70f30: bl              #0xe09394  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::build
    // 0xf70f34: ldur            x1, [fp, #-8]
    // 0xf70f38: mov             x2, x0
    // 0xf70f3c: r0 = applyWidgetOutOfTurn()
    //     0xf70f3c: bl              #0xf70f5c  ; [package:flutter/src/widgets/framework.dart] ParentDataElement::applyWidgetOutOfTurn
    // 0xf70f40: r0 = Null
    //     0xf70f40: mov             x0, NULL
    // 0xf70f44: LeaveFrame
    //     0xf70f44: mov             SP, fp
    //     0xf70f48: ldp             fp, lr, [SP], #0x10
    // 0xf70f4c: ret
    //     0xf70f4c: ret             
    // 0xf70f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf70f50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf70f54: b               #0xf70f20
    // 0xf70f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf70f58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getChildElement(/* No info */) {
    // ** addr: 0xf71484, size: 0xa0
    // 0xf71484: EnterFrame
    //     0xf71484: stp             fp, lr, [SP, #-0x10]!
    //     0xf71488: mov             fp, SP
    // 0xf7148c: AllocStack(0x10)
    //     0xf7148c: sub             SP, SP, #0x10
    // 0xf71490: CheckStackOverflow
    //     0xf71490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf71494: cmp             SP, x16
    //     0xf71498: b.ls            #0xf71518
    // 0xf7149c: LoadField: r0 = r1->field_f
    //     0xf7149c: ldur            w0, [x1, #0xf]
    // 0xf714a0: DecompressPointer r0
    //     0xf714a0: add             x0, x0, HEAP, lsl #32
    // 0xf714a4: stur            x0, [fp, #-8]
    // 0xf714a8: cmp             w0, NULL
    // 0xf714ac: b.eq            #0xf71520
    // 0xf714b0: r1 = 1
    //     0xf714b0: mov             x1, #1
    // 0xf714b4: r0 = AllocateContext()
    //     0xf714b4: bl              #0x13de838  ; AllocateContextStub
    // 0xf714b8: mov             x2, x0
    // 0xf714bc: r1 = Function '<anonymous closure>':.
    //     0xf714bc: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd508] AnonymousClosure: (0xbb7820), in [package:flutter/src/widgets/framework.dart] Element::renderObjectAttachingChild (0xbb77a4)
    //     0xf714c0: ldr             x1, [x1, #0x508]
    // 0xf714c4: stur            x0, [fp, #-0x10]
    // 0xf714c8: r0 = AllocateClosure()
    //     0xf714c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf714cc: ldur            x1, [fp, #-8]
    // 0xf714d0: mov             x2, x0
    // 0xf714d4: r0 = visitChildren()
    //     0xf714d4: bl              #0x1233b38  ; [package:flutter/src/widgets/framework.dart] ComponentElement::visitChildren
    // 0xf714d8: ldur            x0, [fp, #-0x10]
    // 0xf714dc: LoadField: r3 = r0->field_f
    //     0xf714dc: ldur            w3, [x0, #0xf]
    // 0xf714e0: DecompressPointer r3
    //     0xf714e0: add             x3, x3, HEAP, lsl #32
    // 0xf714e4: mov             x0, x3
    // 0xf714e8: stur            x3, [fp, #-8]
    // 0xf714ec: r2 = Null
    //     0xf714ec: mov             x2, NULL
    // 0xf714f0: r1 = Null
    //     0xf714f0: mov             x1, NULL
    // 0xf714f4: r8 = ParentDataElement<KeepAliveParentDataMixin>?
    //     0xf714f4: add             x8, PP, #0xcd, lsl #12  ; [pp+0xcd510] Type: ParentDataElement<KeepAliveParentDataMixin>?
    //     0xf714f8: ldr             x8, [x8, #0x510]
    // 0xf714fc: r3 = Null
    //     0xf714fc: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd518] Null
    //     0xf71500: ldr             x3, [x3, #0x518]
    // 0xf71504: r0 = ParentDataElement<KeepAliveParentDataMixin>?()
    //     0xf71504: bl              #0xf71524  ; IsType_ParentDataElement<KeepAliveParentDataMixin>?_Stub
    // 0xf71508: ldur            x0, [fp, #-8]
    // 0xf7150c: LeaveFrame
    //     0xf7150c: mov             SP, fp
    //     0xf71510: ldp             fp, lr, [SP], #0x10
    // 0xf71514: ret
    //     0xf71514: ret             
    // 0xf71518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf71518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7151c: b               #0xf7149c
    // 0xf71520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf71520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createCallback(/* No info */) {
    // ** addr: 0xf715b4, size: 0x60
    // 0xf715b4: EnterFrame
    //     0xf715b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf715b8: mov             fp, SP
    // 0xf715bc: AllocStack(0x18)
    //     0xf715bc: sub             SP, SP, #0x18
    // 0xf715c0: SetupParameters(_AutomaticKeepAliveState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf715c0: stur            x1, [fp, #-8]
    //     0xf715c4: stur            x2, [fp, #-0x10]
    // 0xf715c8: r1 = 3
    //     0xf715c8: mov             x1, #3
    // 0xf715cc: r0 = AllocateContext()
    //     0xf715cc: bl              #0x13de838  ; AllocateContextStub
    // 0xf715d0: mov             x3, x0
    // 0xf715d4: ldur            x0, [fp, #-8]
    // 0xf715d8: stur            x3, [fp, #-0x18]
    // 0xf715dc: StoreField: r3->field_f = r0
    //     0xf715dc: stur            w0, [x3, #0xf]
    // 0xf715e0: ldur            x0, [fp, #-0x10]
    // 0xf715e4: StoreField: r3->field_13 = r0
    //     0xf715e4: stur            w0, [x3, #0x13]
    // 0xf715e8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf715ec: ArrayStore: r3[0] = r0  ; List_4
    //     0xf715ec: stur            w0, [x3, #0x17]
    // 0xf715f0: mov             x2, x3
    // 0xf715f4: r1 = Function '<anonymous closure>':.
    //     0xf715f4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd528] AnonymousClosure: (0xf71614), in [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_createCallback (0xf715b4)
    //     0xf715f8: ldr             x1, [x1, #0x528]
    // 0xf715fc: r0 = AllocateClosure()
    //     0xf715fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf71600: ldur            x1, [fp, #-0x18]
    // 0xf71604: ArrayStore: r1[0] = r0  ; List_4
    //     0xf71604: stur            w0, [x1, #0x17]
    // 0xf71608: LeaveFrame
    //     0xf71608: mov             SP, fp
    //     0xf7160c: ldp             fp, lr, [SP], #0x10
    // 0xf71610: ret
    //     0xf71610: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf71614, size: 0x140
    // 0xf71614: EnterFrame
    //     0xf71614: stp             fp, lr, [SP, #-0x10]!
    //     0xf71618: mov             fp, SP
    // 0xf7161c: AllocStack(0x18)
    //     0xf7161c: sub             SP, SP, #0x18
    // 0xf71620: SetupParameters([dynamic _ /* r0 */])
    //     0xf71620: ldr             x0, [fp, #0x10]
    //     0xf71624: ldur            w3, [x0, #0x17]
    //     0xf71628: add             x3, x3, HEAP, lsl #32
    //     0xf7162c: stur            x3, [fp, #-8]
    // 0xf71630: CheckStackOverflow
    //     0xf71630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf71634: cmp             SP, x16
    //     0xf71638: b.ls            #0xf71740
    // 0xf7163c: LoadField: r0 = r3->field_f
    //     0xf7163c: ldur            w0, [x3, #0xf]
    // 0xf71640: DecompressPointer r0
    //     0xf71640: add             x0, x0, HEAP, lsl #32
    // 0xf71644: LoadField: r1 = r0->field_13
    //     0xf71644: ldur            w1, [x0, #0x13]
    // 0xf71648: DecompressPointer r1
    //     0xf71648: add             x1, x1, HEAP, lsl #32
    // 0xf7164c: cmp             w1, NULL
    // 0xf71650: b.eq            #0xf71748
    // 0xf71654: LoadField: r2 = r3->field_13
    //     0xf71654: ldur            w2, [x3, #0x13]
    // 0xf71658: DecompressPointer r2
    //     0xf71658: add             x2, x2, HEAP, lsl #32
    // 0xf7165c: r0 = remove()
    //     0xf7165c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf71660: ldur            x0, [fp, #-8]
    // 0xf71664: LoadField: r1 = r0->field_13
    //     0xf71664: ldur            w1, [x0, #0x13]
    // 0xf71668: DecompressPointer r1
    //     0xf71668: add             x1, x1, HEAP, lsl #32
    // 0xf7166c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf7166c: ldur            w2, [x0, #0x17]
    // 0xf71670: DecompressPointer r2
    //     0xf71670: add             x2, x2, HEAP, lsl #32
    // 0xf71674: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf71678: cmp             w2, w16
    // 0xf7167c: b.eq            #0xf7172c
    // 0xf71680: r0 = removeListener()
    //     0xf71680: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xf71684: ldur            x2, [fp, #-8]
    // 0xf71688: LoadField: r0 = r2->field_f
    //     0xf71688: ldur            w0, [x2, #0xf]
    // 0xf7168c: DecompressPointer r0
    //     0xf7168c: add             x0, x0, HEAP, lsl #32
    // 0xf71690: stur            x0, [fp, #-0x10]
    // 0xf71694: LoadField: r1 = r0->field_13
    //     0xf71694: ldur            w1, [x0, #0x13]
    // 0xf71698: DecompressPointer r1
    //     0xf71698: add             x1, x1, HEAP, lsl #32
    // 0xf7169c: cmp             w1, NULL
    // 0xf716a0: b.eq            #0xf7174c
    // 0xf716a4: LoadField: r3 = r1->field_13
    //     0xf716a4: ldur            w3, [x1, #0x13]
    // 0xf716a8: r4 = LoadInt32Instr(r3)
    //     0xf716a8: sbfx            x4, x3, #1, #0x1f
    // 0xf716ac: asr             x3, x4, #1
    // 0xf716b0: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xf716b0: ldur            w4, [x1, #0x17]
    // 0xf716b4: r1 = LoadInt32Instr(r4)
    //     0xf716b4: sbfx            x1, x4, #1, #0x1f
    // 0xf716b8: sub             x4, x3, x1
    // 0xf716bc: cbnz            x4, #0xf7171c
    // 0xf716c0: r1 = LoadStaticField(0x5e4)
    //     0xf716c0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xf716c4: ldr             x1, [x1, #0xbc8]
    // 0xf716c8: cmp             w1, NULL
    // 0xf716cc: b.eq            #0xf71750
    // 0xf716d0: LoadField: r3 = r1->field_5f
    //     0xf716d0: ldur            w3, [x1, #0x5f]
    // 0xf716d4: DecompressPointer r3
    //     0xf716d4: add             x3, x3, HEAP, lsl #32
    // 0xf716d8: LoadField: r1 = r3->field_7
    //     0xf716d8: ldur            x1, [x3, #7]
    // 0xf716dc: cmp             x1, #3
    // 0xf716e0: b.ge            #0xf71700
    // 0xf716e4: r1 = Function '<anonymous closure>':.
    //     0xf716e4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd530] AnonymousClosure: (0xf717f8), in [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_createCallback (0xf715b4)
    //     0xf716e8: ldr             x1, [x1, #0x530]
    // 0xf716ec: r0 = AllocateClosure()
    //     0xf716ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf716f0: ldur            x1, [fp, #-0x10]
    // 0xf716f4: mov             x2, x0
    // 0xf716f8: r0 = setState()
    //     0xf716f8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf716fc: b               #0xf7171c
    // 0xf71700: r1 = false
    //     0xf71700: add             x1, NULL, #0x30  ; false
    // 0xf71704: StoreField: r0->field_1b = r1
    //     0xf71704: stur            w1, [x0, #0x1b]
    // 0xf71708: r1 = Function '<anonymous closure>':.
    //     0xf71708: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd538] AnonymousClosure: (0xf71754), in [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_createCallback (0xf715b4)
    //     0xf7170c: ldr             x1, [x1, #0x538]
    // 0xf71710: r0 = AllocateClosure()
    //     0xf71710: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf71714: str             x0, [SP]
    // 0xf71718: r0 = scheduleMicrotask()
    //     0xf71718: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0xf7171c: r0 = Null
    //     0xf7171c: mov             x0, NULL
    // 0xf71720: LeaveFrame
    //     0xf71720: mov             SP, fp
    //     0xf71724: ldp             fp, lr, [SP], #0x10
    // 0xf71728: ret
    //     0xf71728: ret             
    // 0xf7172c: r16 = "callback"
    //     0xf7172c: add             x16, PP, #0xcd, lsl #12  ; [pp+0xcd540] "callback"
    //     0xf71730: ldr             x16, [x16, #0x540]
    // 0xf71734: str             x16, [SP]
    // 0xf71738: r0 = _throwLocalNotInitialized()
    //     0xf71738: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xf7173c: brk             #0
    // 0xf71740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf71740: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf71744: b               #0xf7163c
    // 0xf71748: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf71748: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7174c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7174c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf71750: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf71750: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf71754, size: 0xa4
    // 0xf71754: EnterFrame
    //     0xf71754: stp             fp, lr, [SP, #-0x10]!
    //     0xf71758: mov             fp, SP
    // 0xf7175c: AllocStack(0x8)
    //     0xf7175c: sub             SP, SP, #8
    // 0xf71760: SetupParameters([dynamic _ /* r0 */])
    //     0xf71760: ldr             x0, [fp, #0x10]
    //     0xf71764: ldur            w1, [x0, #0x17]
    //     0xf71768: add             x1, x1, HEAP, lsl #32
    // 0xf7176c: CheckStackOverflow
    //     0xf7176c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf71770: cmp             SP, x16
    //     0xf71774: b.ls            #0xf717ec
    // 0xf71778: LoadField: r0 = r1->field_f
    //     0xf71778: ldur            w0, [x1, #0xf]
    // 0xf7177c: DecompressPointer r0
    //     0xf7177c: add             x0, x0, HEAP, lsl #32
    // 0xf71780: stur            x0, [fp, #-8]
    // 0xf71784: LoadField: r1 = r0->field_f
    //     0xf71784: ldur            w1, [x0, #0xf]
    // 0xf71788: DecompressPointer r1
    //     0xf71788: add             x1, x1, HEAP, lsl #32
    // 0xf7178c: cmp             w1, NULL
    // 0xf71790: b.eq            #0xf717dc
    // 0xf71794: LoadField: r1 = r0->field_13
    //     0xf71794: ldur            w1, [x0, #0x13]
    // 0xf71798: DecompressPointer r1
    //     0xf71798: add             x1, x1, HEAP, lsl #32
    // 0xf7179c: cmp             w1, NULL
    // 0xf717a0: b.eq            #0xf717f4
    // 0xf717a4: LoadField: r2 = r1->field_13
    //     0xf717a4: ldur            w2, [x1, #0x13]
    // 0xf717a8: r3 = LoadInt32Instr(r2)
    //     0xf717a8: sbfx            x3, x2, #1, #0x1f
    // 0xf717ac: asr             x2, x3, #1
    // 0xf717b0: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xf717b0: ldur            w3, [x1, #0x17]
    // 0xf717b4: r1 = LoadInt32Instr(r3)
    //     0xf717b4: sbfx            x1, x3, #1, #0x1f
    // 0xf717b8: sub             x3, x2, x1
    // 0xf717bc: cbnz            x3, #0xf717dc
    // 0xf717c0: r1 = Function '<anonymous closure>':.
    //     0xf717c0: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd548] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf717c4: ldr             x1, [x1, #0x548]
    // 0xf717c8: r2 = Null
    //     0xf717c8: mov             x2, NULL
    // 0xf717cc: r0 = AllocateClosure()
    //     0xf717cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf717d0: ldur            x1, [fp, #-8]
    // 0xf717d4: mov             x2, x0
    // 0xf717d8: r0 = setState()
    //     0xf717d8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf717dc: r0 = Null
    //     0xf717dc: mov             x0, NULL
    // 0xf717e0: LeaveFrame
    //     0xf717e0: mov             SP, fp
    //     0xf717e4: ldp             fp, lr, [SP], #0x10
    // 0xf717e8: ret
    //     0xf717e8: ret             
    // 0xf717ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf717ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf717f0: b               #0xf71778
    // 0xf717f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf717f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf717f8, size: 0x24
    // 0xf717f8: r1 = false
    //     0xf717f8: add             x1, NULL, #0x30  ; false
    // 0xf717fc: ldr             x2, [SP]
    // 0xf71800: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xf71800: ldur            w3, [x2, #0x17]
    // 0xf71804: DecompressPointer r3
    //     0xf71804: add             x3, x3, HEAP, lsl #32
    // 0xf71808: LoadField: r2 = r3->field_f
    //     0xf71808: ldur            w2, [x3, #0xf]
    // 0xf7180c: DecompressPointer r2
    //     0xf7180c: add             x2, x2, HEAP, lsl #32
    // 0xf71810: StoreField: r2->field_1b = r1
    //     0xf71810: stur            w1, [x2, #0x1b]
    // 0xf71814: r0 = Null
    //     0xf71814: mov             x0, NULL
    // 0xf71818: ret
    //     0xf71818: ret             
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0xf7181c, size: 0x98
    // 0xf7181c: EnterFrame
    //     0xf7181c: stp             fp, lr, [SP, #-0x10]!
    //     0xf71820: mov             fp, SP
    // 0xf71824: AllocStack(0x8)
    //     0xf71824: sub             SP, SP, #8
    // 0xf71828: SetupParameters([dynamic _ /* r0 */])
    //     0xf71828: ldr             x0, [fp, #0x18]
    //     0xf7182c: ldur            w2, [x0, #0x17]
    //     0xf71830: add             x2, x2, HEAP, lsl #32
    //     0xf71834: stur            x2, [fp, #-8]
    // 0xf71838: CheckStackOverflow
    //     0xf71838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7183c: cmp             SP, x16
    //     0xf71840: b.ls            #0xf718a8
    // 0xf71844: LoadField: r1 = r2->field_f
    //     0xf71844: ldur            w1, [x2, #0xf]
    // 0xf71848: DecompressPointer r1
    //     0xf71848: add             x1, x1, HEAP, lsl #32
    // 0xf7184c: LoadField: r0 = r1->field_f
    //     0xf7184c: ldur            w0, [x1, #0xf]
    // 0xf71850: DecompressPointer r0
    //     0xf71850: add             x0, x0, HEAP, lsl #32
    // 0xf71854: cmp             w0, NULL
    // 0xf71858: b.ne            #0xf7186c
    // 0xf7185c: r0 = Null
    //     0xf7185c: mov             x0, NULL
    // 0xf71860: LeaveFrame
    //     0xf71860: mov             SP, fp
    //     0xf71864: ldp             fp, lr, [SP], #0x10
    // 0xf71868: ret
    //     0xf71868: ret             
    // 0xf7186c: r0 = _getChildElement()
    //     0xf7186c: bl              #0xf71484  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_getChildElement
    // 0xf71870: mov             x1, x0
    // 0xf71874: ldur            x0, [fp, #-8]
    // 0xf71878: LoadField: r2 = r0->field_f
    //     0xf71878: ldur            w2, [x0, #0xf]
    // 0xf7187c: DecompressPointer r2
    //     0xf7187c: add             x2, x2, HEAP, lsl #32
    // 0xf71880: cmp             w1, NULL
    // 0xf71884: b.eq            #0xf718b0
    // 0xf71888: mov             x16, x1
    // 0xf7188c: mov             x1, x2
    // 0xf71890: mov             x2, x16
    // 0xf71894: r0 = _updateParentDataOfChild()
    //     0xf71894: bl              #0xf70f00  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_updateParentDataOfChild
    // 0xf71898: r0 = Null
    //     0xf71898: mov             x0, NULL
    // 0xf7189c: LeaveFrame
    //     0xf7189c: mov             SP, fp
    //     0xf718a0: ldp             fp, lr, [SP], #0x10
    // 0xf718a4: ret
    //     0xf718a4: ret             
    // 0xf718a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf718a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf718ac: b               #0xf71844
    // 0xf718b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf718b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91bbc, size: 0x30
    // 0xf91bbc: EnterFrame
    //     0xf91bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xf91bc0: mov             fp, SP
    // 0xf91bc4: CheckStackOverflow
    //     0xf91bc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91bc8: cmp             SP, x16
    //     0xf91bcc: b.ls            #0xf91be4
    // 0xf91bd0: r0 = _updateChild()
    //     0xf91bd0: bl              #0xf70bd8  ; [package:flutter/src/widgets/automatic_keep_alive.dart] _AutomaticKeepAliveState::_updateChild
    // 0xf91bd4: r0 = Null
    //     0xf91bd4: mov             x0, NULL
    // 0xf91bd8: LeaveFrame
    //     0xf91bd8: mov             SP, fp
    //     0xf91bdc: ldp             fp, lr, [SP], #0x10
    // 0xf91be0: ret
    //     0xf91be0: ret             
    // 0xf91be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91be4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91be8: b               #0xf91bd0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e64d0, size: 0x164
    // 0x10e64d0: EnterFrame
    //     0x10e64d0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e64d4: mov             fp, SP
    // 0x10e64d8: AllocStack(0x28)
    //     0x10e64d8: sub             SP, SP, #0x28
    // 0x10e64dc: SetupParameters(_AutomaticKeepAliveState this /* r1 => r0, fp-0x10 */)
    //     0x10e64dc: mov             x0, x1
    //     0x10e64e0: stur            x1, [fp, #-0x10]
    // 0x10e64e4: CheckStackOverflow
    //     0x10e64e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e64e8: cmp             SP, x16
    //     0x10e64ec: b.ls            #0x10e661c
    // 0x10e64f0: LoadField: r2 = r0->field_13
    //     0x10e64f0: ldur            w2, [x0, #0x13]
    // 0x10e64f4: DecompressPointer r2
    //     0x10e64f4: add             x2, x2, HEAP, lsl #32
    // 0x10e64f8: stur            x2, [fp, #-8]
    // 0x10e64fc: cmp             w2, NULL
    // 0x10e6500: b.eq            #0x10e660c
    // 0x10e6504: LoadField: r1 = r2->field_7
    //     0x10e6504: ldur            w1, [x2, #7]
    // 0x10e6508: DecompressPointer r1
    //     0x10e6508: add             x1, x1, HEAP, lsl #32
    // 0x10e650c: r0 = _CompactKeysIterable()
    //     0x10e650c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x10e6510: mov             x1, x0
    // 0x10e6514: ldur            x0, [fp, #-8]
    // 0x10e6518: StoreField: r1->field_b = r0
    //     0x10e6518: stur            w0, [x1, #0xb]
    // 0x10e651c: r0 = iterator()
    //     0x10e651c: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0x10e6520: stur            x0, [fp, #-0x18]
    // 0x10e6524: LoadField: r2 = r0->field_7
    //     0x10e6524: ldur            w2, [x0, #7]
    // 0x10e6528: DecompressPointer r2
    //     0x10e6528: add             x2, x2, HEAP, lsl #32
    // 0x10e652c: stur            x2, [fp, #-8]
    // 0x10e6530: ldur            x3, [fp, #-0x10]
    // 0x10e6534: CheckStackOverflow
    //     0x10e6534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e6538: cmp             SP, x16
    //     0x10e653c: b.ls            #0x10e6624
    // 0x10e6540: mov             x1, x0
    // 0x10e6544: r0 = moveNext()
    //     0x10e6544: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x10e6548: tbnz            w0, #4, #0x10e660c
    // 0x10e654c: ldur            x3, [fp, #-0x18]
    // 0x10e6550: LoadField: r4 = r3->field_33
    //     0x10e6550: ldur            w4, [x3, #0x33]
    // 0x10e6554: DecompressPointer r4
    //     0x10e6554: add             x4, x4, HEAP, lsl #32
    // 0x10e6558: stur            x4, [fp, #-0x20]
    // 0x10e655c: cmp             w4, NULL
    // 0x10e6560: b.ne            #0x10e6594
    // 0x10e6564: mov             x0, x4
    // 0x10e6568: ldur            x2, [fp, #-8]
    // 0x10e656c: r1 = Null
    //     0x10e656c: mov             x1, NULL
    // 0x10e6570: cmp             w2, NULL
    // 0x10e6574: b.eq            #0x10e6594
    // 0x10e6578: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10e6578: ldur            w4, [x2, #0x17]
    // 0x10e657c: DecompressPointer r4
    //     0x10e657c: add             x4, x4, HEAP, lsl #32
    // 0x10e6580: r8 = X0
    //     0x10e6580: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10e6584: LoadField: r9 = r4->field_7
    //     0x10e6584: ldur            x9, [x4, #7]
    // 0x10e6588: r3 = Null
    //     0x10e6588: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd490] Null
    //     0x10e658c: ldr             x3, [x3, #0x490]
    // 0x10e6590: blr             x9
    // 0x10e6594: ldur            x0, [fp, #-0x10]
    // 0x10e6598: LoadField: r3 = r0->field_13
    //     0x10e6598: ldur            w3, [x0, #0x13]
    // 0x10e659c: DecompressPointer r3
    //     0x10e659c: add             x3, x3, HEAP, lsl #32
    // 0x10e65a0: stur            x3, [fp, #-0x28]
    // 0x10e65a4: cmp             w3, NULL
    // 0x10e65a8: b.eq            #0x10e662c
    // 0x10e65ac: mov             x1, x3
    // 0x10e65b0: ldur            x2, [fp, #-0x20]
    // 0x10e65b4: r0 = _getValueOrData()
    //     0x10e65b4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x10e65b8: mov             x1, x0
    // 0x10e65bc: ldur            x0, [fp, #-0x28]
    // 0x10e65c0: LoadField: r2 = r0->field_f
    //     0x10e65c0: ldur            w2, [x0, #0xf]
    // 0x10e65c4: DecompressPointer r2
    //     0x10e65c4: add             x2, x2, HEAP, lsl #32
    // 0x10e65c8: cmp             w2, w1
    // 0x10e65cc: b.ne            #0x10e65d8
    // 0x10e65d0: r2 = Null
    //     0x10e65d0: mov             x2, NULL
    // 0x10e65d4: b               #0x10e65dc
    // 0x10e65d8: mov             x2, x1
    // 0x10e65dc: ldur            x1, [fp, #-0x20]
    // 0x10e65e0: cmp             w2, NULL
    // 0x10e65e4: b.eq            #0x10e6630
    // 0x10e65e8: r0 = LoadClassIdInstr(r1)
    //     0x10e65e8: ldur            x0, [x1, #-1]
    //     0x10e65ec: ubfx            x0, x0, #0xc, #0x14
    // 0x10e65f0: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10e65f0: mov             x17, #0xe2a3
    //     0x10e65f4: add             lr, x0, x17
    //     0x10e65f8: ldr             lr, [x21, lr, lsl #3]
    //     0x10e65fc: blr             lr
    // 0x10e6600: ldur            x0, [fp, #-0x18]
    // 0x10e6604: ldur            x2, [fp, #-8]
    // 0x10e6608: b               #0x10e6530
    // 0x10e660c: r0 = Null
    //     0x10e660c: mov             x0, NULL
    // 0x10e6610: LeaveFrame
    //     0x10e6610: mov             SP, fp
    //     0x10e6614: ldp             fp, lr, [SP], #0x10
    // 0x10e6618: ret
    //     0x10e6618: ret             
    // 0x10e661c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e661c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e6620: b               #0x10e64f0
    // 0x10e6624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e6624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e6628: b               #0x10e6540
    // 0x10e662c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e662c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e6630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e6630: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5755, size: 0x14, field offset: 0x14
abstract class AutomaticKeepAliveClientMixin<X0 bound StatefulWidget> extends State<X0 bound StatefulWidget> {
}

// class id: 6127, size: 0xc, field offset: 0xc
//   const constructor, 
class _NullWidget extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf2d4, size: 0x34
    // 0xfbf2d4: EnterFrame
    //     0xfbf2d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf2d8: mov             fp, SP
    // 0xfbf2dc: CheckStackOverflow
    //     0xfbf2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf2e0: cmp             SP, x16
    //     0xfbf2e4: b.ls            #0xfbf300
    // 0xfbf2e8: r1 = Null
    //     0xfbf2e8: mov             x1, NULL
    // 0xfbf2ec: r2 = "Widgets that mix AutomaticKeepAliveClientMixin into their State must call super.build() but must ignore the return value of the superclass."
    //     0xfbf2ec: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fd28] "Widgets that mix AutomaticKeepAliveClientMixin into their State must call super.build() but must ignore the return value of the superclass."
    //     0xfbf2f0: ldr             x2, [x2, #0xd28]
    // 0xfbf2f4: r0 = FlutterError()
    //     0xfbf2f4: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xfbf2f8: r0 = Throw()
    //     0xfbf2f8: bl              #0x13ddb2c  ; ThrowStub
    // 0xfbf2fc: brk             #0
    // 0xfbf300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf304: b               #0xfbf2e8
  }
}

// class id: 6400, size: 0x10, field offset: 0xc
//   const constructor, 
class AutomaticKeepAlive extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa390c, size: 0x34
    // 0xfa390c: EnterFrame
    //     0xfa390c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3910: mov             fp, SP
    // 0xfa3914: mov             x0, x1
    // 0xfa3918: r1 = <AutomaticKeepAlive>
    //     0xfa3918: add             x1, PP, #0xad, lsl #12  ; [pp+0xade80] TypeArguments: <AutomaticKeepAlive>
    //     0xfa391c: ldr             x1, [x1, #0xe80]
    // 0xfa3920: r0 = _AutomaticKeepAliveState()
    //     0xfa3920: bl              #0xfa3940  ; Allocate_AutomaticKeepAliveStateStub -> _AutomaticKeepAliveState (size=0x20)
    // 0xfa3924: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3928: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa3928: stur            w1, [x0, #0x17]
    // 0xfa392c: r1 = false
    //     0xfa392c: add             x1, NULL, #0x30  ; false
    // 0xfa3930: StoreField: r0->field_1b = r1
    //     0xfa3930: stur            w1, [x0, #0x1b]
    // 0xfa3934: LeaveFrame
    //     0xfa3934: mov             SP, fp
    //     0xfa3938: ldp             fp, lr, [SP], #0x10
    // 0xfa393c: ret
    //     0xfa393c: ret             
  }
}
