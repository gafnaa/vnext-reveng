// lib: , url: package:flutter/src/widgets/animated_cross_fade.dart

// class id: 1049111, size: 0x8
class :: {
}

// class id: 5679, size: 0x28, field offset: 0x1c
class _AnimatedCrossFadeState extends _MixinApplication185&State&TickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c
  late Animation<double> _secondAnimation; // offset: 0x24
  late Animation<double> _firstAnimation; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xd5bd54, size: 0x388
    // 0xd5bd54: EnterFrame
    //     0xd5bd54: stp             fp, lr, [SP, #-0x10]!
    //     0xd5bd58: mov             fp, SP
    // 0xd5bd5c: AllocStack(0x48)
    //     0xd5bd5c: sub             SP, SP, #0x48
    // 0xd5bd60: SetupParameters(_AnimatedCrossFadeState this /* r1 => r0, fp-0x8 */)
    //     0xd5bd60: mov             x0, x1
    //     0xd5bd64: stur            x1, [fp, #-8]
    // 0xd5bd68: CheckStackOverflow
    //     0xd5bd68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5bd6c: cmp             SP, x16
    //     0xd5bd70: b.ls            #0xd5c090
    // 0xd5bd74: LoadField: r1 = r0->field_1b
    //     0xd5bd74: ldur            w1, [x0, #0x1b]
    // 0xd5bd78: DecompressPointer r1
    //     0xd5bd78: add             x1, x1, HEAP, lsl #32
    // 0xd5bd7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5bd80: cmp             w1, w16
    // 0xd5bd84: b.eq            #0xd5c098
    // 0xd5bd88: r0 = isForwardOrCompleted()
    //     0xd5bd88: bl              #0xbadc14  ; [package:flutter/src/animation/animation.dart] Animation::isForwardOrCompleted
    // 0xd5bd8c: tbnz            w0, #4, #0xd5be04
    // 0xd5bd90: ldur            x0, [fp, #-8]
    // 0xd5bd94: LoadField: r1 = r0->field_b
    //     0xd5bd94: ldur            w1, [x0, #0xb]
    // 0xd5bd98: DecompressPointer r1
    //     0xd5bd98: add             x1, x1, HEAP, lsl #32
    // 0xd5bd9c: cmp             w1, NULL
    // 0xd5bda0: b.eq            #0xd5c0a4
    // 0xd5bda4: LoadField: r2 = r1->field_f
    //     0xd5bda4: ldur            w2, [x1, #0xf]
    // 0xd5bda8: DecompressPointer r2
    //     0xd5bda8: add             x2, x2, HEAP, lsl #32
    // 0xd5bdac: LoadField: r3 = r0->field_23
    //     0xd5bdac: ldur            w3, [x0, #0x23]
    // 0xd5bdb0: DecompressPointer r3
    //     0xd5bdb0: add             x3, x3, HEAP, lsl #32
    // 0xd5bdb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5bdb8: cmp             w3, w16
    // 0xd5bdbc: b.eq            #0xd5c0a8
    // 0xd5bdc0: LoadField: r4 = r1->field_b
    //     0xd5bdc0: ldur            w4, [x1, #0xb]
    // 0xd5bdc4: DecompressPointer r4
    //     0xd5bdc4: add             x4, x4, HEAP, lsl #32
    // 0xd5bdc8: LoadField: r5 = r0->field_1f
    //     0xd5bdc8: ldur            w5, [x0, #0x1f]
    // 0xd5bdcc: DecompressPointer r5
    //     0xd5bdcc: add             x5, x5, HEAP, lsl #32
    // 0xd5bdd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5bdd4: cmp             w5, w16
    // 0xd5bdd8: b.eq            #0xd5c0b4
    // 0xd5bddc: mov             x6, x2
    // 0xd5bde0: mov             x16, x4
    // 0xd5bde4: mov             x4, x3
    // 0xd5bde8: mov             x3, x16
    // 0xd5bdec: mov             x2, x5
    // 0xd5bdf0: r7 = Instance_ValueKey
    //     0xd5bdf0: add             x7, PP, #0x98, lsl #12  ; [pp+0x98d58] Obj!ValueKey<CrossFadeState>@129f251
    //     0xd5bdf4: ldr             x7, [x7, #0xd58]
    // 0xd5bdf8: r5 = Instance_ValueKey
    //     0xd5bdf8: add             x5, PP, #0x98, lsl #12  ; [pp+0x98d60] Obj!ValueKey<CrossFadeState>@129f241
    //     0xd5bdfc: ldr             x5, [x5, #0xd60]
    // 0xd5be00: b               #0xd5be74
    // 0xd5be04: ldur            x0, [fp, #-8]
    // 0xd5be08: LoadField: r1 = r0->field_b
    //     0xd5be08: ldur            w1, [x0, #0xb]
    // 0xd5be0c: DecompressPointer r1
    //     0xd5be0c: add             x1, x1, HEAP, lsl #32
    // 0xd5be10: cmp             w1, NULL
    // 0xd5be14: b.eq            #0xd5c0c0
    // 0xd5be18: LoadField: r2 = r1->field_b
    //     0xd5be18: ldur            w2, [x1, #0xb]
    // 0xd5be1c: DecompressPointer r2
    //     0xd5be1c: add             x2, x2, HEAP, lsl #32
    // 0xd5be20: LoadField: r3 = r0->field_1f
    //     0xd5be20: ldur            w3, [x0, #0x1f]
    // 0xd5be24: DecompressPointer r3
    //     0xd5be24: add             x3, x3, HEAP, lsl #32
    // 0xd5be28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5be2c: cmp             w3, w16
    // 0xd5be30: b.eq            #0xd5c0c4
    // 0xd5be34: LoadField: r4 = r1->field_f
    //     0xd5be34: ldur            w4, [x1, #0xf]
    // 0xd5be38: DecompressPointer r4
    //     0xd5be38: add             x4, x4, HEAP, lsl #32
    // 0xd5be3c: LoadField: r5 = r0->field_23
    //     0xd5be3c: ldur            w5, [x0, #0x23]
    // 0xd5be40: DecompressPointer r5
    //     0xd5be40: add             x5, x5, HEAP, lsl #32
    // 0xd5be44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5be48: cmp             w5, w16
    // 0xd5be4c: b.eq            #0xd5c0d0
    // 0xd5be50: mov             x6, x2
    // 0xd5be54: mov             x16, x4
    // 0xd5be58: mov             x4, x3
    // 0xd5be5c: mov             x3, x16
    // 0xd5be60: mov             x2, x5
    // 0xd5be64: r7 = Instance_ValueKey
    //     0xd5be64: add             x7, PP, #0x98, lsl #12  ; [pp+0x98d60] Obj!ValueKey<CrossFadeState>@129f241
    //     0xd5be68: ldr             x7, [x7, #0xd60]
    // 0xd5be6c: r5 = Instance_ValueKey
    //     0xd5be6c: add             x5, PP, #0x98, lsl #12  ; [pp+0x98d58] Obj!ValueKey<CrossFadeState>@129f251
    //     0xd5be70: ldr             x5, [x5, #0xd58]
    // 0xd5be74: stur            x7, [fp, #-0x10]
    // 0xd5be78: stur            x6, [fp, #-0x18]
    // 0xd5be7c: stur            x4, [fp, #-0x20]
    // 0xd5be80: stur            x5, [fp, #-0x28]
    // 0xd5be84: stur            x3, [fp, #-0x30]
    // 0xd5be88: stur            x2, [fp, #-0x38]
    // 0xd5be8c: stur            x1, [fp, #-0x40]
    // 0xd5be90: LoadField: r8 = r0->field_1b
    //     0xd5be90: ldur            w8, [x0, #0x1b]
    // 0xd5be94: DecompressPointer r8
    //     0xd5be94: add             x8, x8, HEAP, lsl #32
    // 0xd5be98: LoadField: r0 = r8->field_2f
    //     0xd5be98: ldur            w0, [x8, #0x2f]
    // 0xd5be9c: DecompressPointer r0
    //     0xd5be9c: add             x0, x0, HEAP, lsl #32
    // 0xd5bea0: cmp             w0, NULL
    // 0xd5bea4: b.eq            #0xd5bec4
    // 0xd5bea8: LoadField: r8 = r0->field_7
    //     0xd5bea8: ldur            w8, [x0, #7]
    // 0xd5beac: DecompressPointer r8
    //     0xd5beac: add             x8, x8, HEAP, lsl #32
    // 0xd5beb0: cmp             w8, NULL
    // 0xd5beb4: r16 = true
    //     0xd5beb4: add             x16, NULL, #0x20  ; true
    // 0xd5beb8: r17 = false
    //     0xd5beb8: add             x17, NULL, #0x30  ; false
    // 0xd5bebc: csel            x0, x16, x17, ne
    // 0xd5bec0: b               #0xd5bec8
    // 0xd5bec4: r0 = false
    //     0xd5bec4: add             x0, NULL, #0x30  ; false
    // 0xd5bec8: stur            x0, [fp, #-8]
    // 0xd5becc: r0 = FadeTransition()
    //     0xd5becc: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xd5bed0: mov             x1, x0
    // 0xd5bed4: ldur            x0, [fp, #-0x38]
    // 0xd5bed8: stur            x1, [fp, #-0x48]
    // 0xd5bedc: StoreField: r1->field_f = r0
    //     0xd5bedc: stur            w0, [x1, #0xf]
    // 0xd5bee0: r0 = false
    //     0xd5bee0: add             x0, NULL, #0x30  ; false
    // 0xd5bee4: StoreField: r1->field_13 = r0
    //     0xd5bee4: stur            w0, [x1, #0x13]
    // 0xd5bee8: ldur            x2, [fp, #-0x30]
    // 0xd5beec: StoreField: r1->field_b = r2
    //     0xd5beec: stur            w2, [x1, #0xb]
    // 0xd5bef0: r0 = ExcludeFocus()
    //     0xd5bef0: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xd5bef4: mov             x1, x0
    // 0xd5bef8: r0 = true
    //     0xd5bef8: add             x0, NULL, #0x20  ; true
    // 0xd5befc: stur            x1, [fp, #-0x30]
    // 0xd5bf00: StoreField: r1->field_b = r0
    //     0xd5bf00: stur            w0, [x1, #0xb]
    // 0xd5bf04: ldur            x2, [fp, #-0x48]
    // 0xd5bf08: StoreField: r1->field_f = r2
    //     0xd5bf08: stur            w2, [x1, #0xf]
    // 0xd5bf0c: r0 = ExcludeSemantics()
    //     0xd5bf0c: bl              #0x86a6ac  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0xd5bf10: mov             x1, x0
    // 0xd5bf14: r0 = true
    //     0xd5bf14: add             x0, NULL, #0x20  ; true
    // 0xd5bf18: stur            x1, [fp, #-0x38]
    // 0xd5bf1c: StoreField: r1->field_f = r0
    //     0xd5bf1c: stur            w0, [x1, #0xf]
    // 0xd5bf20: ldur            x2, [fp, #-0x30]
    // 0xd5bf24: StoreField: r1->field_b = r2
    //     0xd5bf24: stur            w2, [x1, #0xb]
    // 0xd5bf28: r0 = IgnorePointer()
    //     0xd5bf28: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd5bf2c: mov             x1, x0
    // 0xd5bf30: r0 = true
    //     0xd5bf30: add             x0, NULL, #0x20  ; true
    // 0xd5bf34: stur            x1, [fp, #-0x30]
    // 0xd5bf38: StoreField: r1->field_f = r0
    //     0xd5bf38: stur            w0, [x1, #0xf]
    // 0xd5bf3c: ldur            x2, [fp, #-0x38]
    // 0xd5bf40: StoreField: r1->field_b = r2
    //     0xd5bf40: stur            w2, [x1, #0xb]
    // 0xd5bf44: r0 = TickerMode()
    //     0xd5bf44: bl              #0xd5c21c  ; AllocateTickerModeStub -> TickerMode (size=0x18)
    // 0xd5bf48: mov             x1, x0
    // 0xd5bf4c: ldur            x0, [fp, #-8]
    // 0xd5bf50: stur            x1, [fp, #-0x38]
    // 0xd5bf54: StoreField: r1->field_b = r0
    //     0xd5bf54: stur            w0, [x1, #0xb]
    // 0xd5bf58: ldur            x0, [fp, #-0x30]
    // 0xd5bf5c: StoreField: r1->field_13 = r0
    //     0xd5bf5c: stur            w0, [x1, #0x13]
    // 0xd5bf60: r0 = false
    //     0xd5bf60: add             x0, NULL, #0x30  ; false
    // 0xd5bf64: StoreField: r1->field_f = r0
    //     0xd5bf64: stur            w0, [x1, #0xf]
    // 0xd5bf68: ldur            x5, [fp, #-0x28]
    // 0xd5bf6c: StoreField: r1->field_7 = r5
    //     0xd5bf6c: stur            w5, [x1, #7]
    // 0xd5bf70: r0 = FadeTransition()
    //     0xd5bf70: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xd5bf74: mov             x1, x0
    // 0xd5bf78: ldur            x0, [fp, #-0x20]
    // 0xd5bf7c: stur            x1, [fp, #-8]
    // 0xd5bf80: StoreField: r1->field_f = r0
    //     0xd5bf80: stur            w0, [x1, #0xf]
    // 0xd5bf84: r0 = false
    //     0xd5bf84: add             x0, NULL, #0x30  ; false
    // 0xd5bf88: StoreField: r1->field_13 = r0
    //     0xd5bf88: stur            w0, [x1, #0x13]
    // 0xd5bf8c: ldur            x2, [fp, #-0x18]
    // 0xd5bf90: StoreField: r1->field_b = r2
    //     0xd5bf90: stur            w2, [x1, #0xb]
    // 0xd5bf94: r0 = ExcludeFocus()
    //     0xd5bf94: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xd5bf98: mov             x1, x0
    // 0xd5bf9c: r0 = false
    //     0xd5bf9c: add             x0, NULL, #0x30  ; false
    // 0xd5bfa0: stur            x1, [fp, #-0x18]
    // 0xd5bfa4: StoreField: r1->field_b = r0
    //     0xd5bfa4: stur            w0, [x1, #0xb]
    // 0xd5bfa8: ldur            x2, [fp, #-8]
    // 0xd5bfac: StoreField: r1->field_f = r2
    //     0xd5bfac: stur            w2, [x1, #0xf]
    // 0xd5bfb0: r0 = ExcludeSemantics()
    //     0xd5bfb0: bl              #0x86a6ac  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0xd5bfb4: mov             x1, x0
    // 0xd5bfb8: r0 = false
    //     0xd5bfb8: add             x0, NULL, #0x30  ; false
    // 0xd5bfbc: stur            x1, [fp, #-8]
    // 0xd5bfc0: StoreField: r1->field_f = r0
    //     0xd5bfc0: stur            w0, [x1, #0xf]
    // 0xd5bfc4: ldur            x2, [fp, #-0x18]
    // 0xd5bfc8: StoreField: r1->field_b = r2
    //     0xd5bfc8: stur            w2, [x1, #0xb]
    // 0xd5bfcc: r0 = IgnorePointer()
    //     0xd5bfcc: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd5bfd0: mov             x1, x0
    // 0xd5bfd4: r0 = false
    //     0xd5bfd4: add             x0, NULL, #0x30  ; false
    // 0xd5bfd8: stur            x1, [fp, #-0x18]
    // 0xd5bfdc: StoreField: r1->field_f = r0
    //     0xd5bfdc: stur            w0, [x1, #0xf]
    // 0xd5bfe0: ldur            x2, [fp, #-8]
    // 0xd5bfe4: StoreField: r1->field_b = r2
    //     0xd5bfe4: stur            w2, [x1, #0xb]
    // 0xd5bfe8: r0 = TickerMode()
    //     0xd5bfe8: bl              #0xd5c21c  ; AllocateTickerModeStub -> TickerMode (size=0x18)
    // 0xd5bfec: mov             x1, x0
    // 0xd5bff0: r0 = true
    //     0xd5bff0: add             x0, NULL, #0x20  ; true
    // 0xd5bff4: StoreField: r1->field_b = r0
    //     0xd5bff4: stur            w0, [x1, #0xb]
    // 0xd5bff8: ldur            x0, [fp, #-0x18]
    // 0xd5bffc: StoreField: r1->field_13 = r0
    //     0xd5bffc: stur            w0, [x1, #0x13]
    // 0xd5c000: r0 = false
    //     0xd5c000: add             x0, NULL, #0x30  ; false
    // 0xd5c004: StoreField: r1->field_f = r0
    //     0xd5c004: stur            w0, [x1, #0xf]
    // 0xd5c008: ldur            x2, [fp, #-0x10]
    // 0xd5c00c: StoreField: r1->field_7 = r2
    //     0xd5c00c: stur            w2, [x1, #7]
    // 0xd5c010: ldur            x0, [fp, #-0x40]
    // 0xd5c014: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xd5c014: ldur            w4, [x0, #0x17]
    // 0xd5c018: DecompressPointer r4
    //     0xd5c018: add             x4, x4, HEAP, lsl #32
    // 0xd5c01c: ldur            x3, [fp, #-0x38]
    // 0xd5c020: ldur            x5, [fp, #-0x28]
    // 0xd5c024: stur            x4, [fp, #-8]
    // 0xd5c028: r0 = defaultLayoutBuilder()
    //     0xd5c028: bl              #0xd5c124  ; [package:flutter/src/widgets/animated_cross_fade.dart] AnimatedCrossFade::defaultLayoutBuilder
    // 0xd5c02c: stur            x0, [fp, #-0x10]
    // 0xd5c030: r0 = AnimatedSize()
    //     0xd5c030: bl              #0xd4aad4  ; AllocateAnimatedSizeStub -> AnimatedSize (size=0x28)
    // 0xd5c034: mov             x1, x0
    // 0xd5c038: ldur            x0, [fp, #-0x10]
    // 0xd5c03c: stur            x1, [fp, #-0x18]
    // 0xd5c040: StoreField: r1->field_b = r0
    //     0xd5c040: stur            w0, [x1, #0xb]
    // 0xd5c044: r0 = Instance_Alignment
    //     0xd5c044: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xd5c048: ldr             x0, [x0, #0x7a8]
    // 0xd5c04c: StoreField: r1->field_f = r0
    //     0xd5c04c: stur            w0, [x1, #0xf]
    // 0xd5c050: r0 = Instance__Linear
    //     0xd5c050: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd5c054: StoreField: r1->field_13 = r0
    //     0xd5c054: stur            w0, [x1, #0x13]
    // 0xd5c058: ldur            x0, [fp, #-8]
    // 0xd5c05c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd5c05c: stur            w0, [x1, #0x17]
    // 0xd5c060: r0 = Instance_Clip
    //     0xd5c060: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd5c064: ldr             x0, [x0, #0x850]
    // 0xd5c068: StoreField: r1->field_1f = r0
    //     0xd5c068: stur            w0, [x1, #0x1f]
    // 0xd5c06c: r0 = ClipRect()
    //     0xd5c06c: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xd5c070: r1 = Instance_Clip
    //     0xd5c070: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd5c074: ldr             x1, [x1, #0x850]
    // 0xd5c078: StoreField: r0->field_13 = r1
    //     0xd5c078: stur            w1, [x0, #0x13]
    // 0xd5c07c: ldur            x1, [fp, #-0x18]
    // 0xd5c080: StoreField: r0->field_b = r1
    //     0xd5c080: stur            w1, [x0, #0xb]
    // 0xd5c084: LeaveFrame
    //     0xd5c084: mov             SP, fp
    //     0xd5c088: ldp             fp, lr, [SP], #0x10
    // 0xd5c08c: ret
    //     0xd5c08c: ret             
    // 0xd5c090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5c090: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5c094: b               #0xd5bd74
    // 0xd5c098: r9 = _controller
    //     0xd5c098: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0xd5c09c: ldr             x9, [x9, #0xd68]
    // 0xd5c0a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5c0a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5c0a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5c0a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5c0a8: r9 = _secondAnimation
    //     0xd5c0a8: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d70] Field <_AnimatedCrossFadeState@147463501._secondAnimation@147463501>: late (offset: 0x24)
    //     0xd5c0ac: ldr             x9, [x9, #0xd70]
    // 0xd5c0b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5c0b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5c0b4: r9 = _firstAnimation
    //     0xd5c0b4: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d78] Field <_AnimatedCrossFadeState@147463501._firstAnimation@147463501>: late (offset: 0x20)
    //     0xd5c0b8: ldr             x9, [x9, #0xd78]
    // 0xd5c0bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5c0bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5c0c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5c0c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5c0c4: r9 = _firstAnimation
    //     0xd5c0c4: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d78] Field <_AnimatedCrossFadeState@147463501._firstAnimation@147463501>: late (offset: 0x20)
    //     0xd5c0c8: ldr             x9, [x9, #0xd78]
    // 0xd5c0cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5c0cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5c0d0: r9 = _secondAnimation
    //     0xd5c0d0: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d70] Field <_AnimatedCrossFadeState@147463501._secondAnimation@147463501>: late (offset: 0x24)
    //     0xd5c0d4: ldr             x9, [x9, #0xd70]
    // 0xd5c0d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5c0d8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3e97c, size: 0x1f0
    // 0xf3e97c: EnterFrame
    //     0xf3e97c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e980: mov             fp, SP
    // 0xf3e984: AllocStack(0x20)
    //     0xf3e984: sub             SP, SP, #0x20
    // 0xf3e988: SetupParameters(_AnimatedCrossFadeState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3e988: mov             x4, x1
    //     0xf3e98c: mov             x3, x2
    //     0xf3e990: stur            x1, [fp, #-8]
    //     0xf3e994: stur            x2, [fp, #-0x10]
    // 0xf3e998: CheckStackOverflow
    //     0xf3e998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e99c: cmp             SP, x16
    //     0xf3e9a0: b.ls            #0xf3eb34
    // 0xf3e9a4: mov             x0, x3
    // 0xf3e9a8: r2 = Null
    //     0xf3e9a8: mov             x2, NULL
    // 0xf3e9ac: r1 = Null
    //     0xf3e9ac: mov             x1, NULL
    // 0xf3e9b0: r4 = 60
    //     0xf3e9b0: mov             x4, #0x3c
    // 0xf3e9b4: branchIfSmi(r0, 0xf3e9c0)
    //     0xf3e9b4: tbz             w0, #0, #0xf3e9c0
    // 0xf3e9b8: r4 = LoadClassIdInstr(r0)
    //     0xf3e9b8: ldur            x4, [x0, #-1]
    //     0xf3e9bc: ubfx            x4, x4, #0xc, #0x14
    // 0xf3e9c0: r17 = 6408
    //     0xf3e9c0: mov             x17, #0x1908
    // 0xf3e9c4: cmp             x4, x17
    // 0xf3e9c8: b.eq            #0xf3e9e0
    // 0xf3e9cc: r8 = AnimatedCrossFade
    //     0xf3e9cc: add             x8, PP, #0x98, lsl #12  ; [pp+0x98d80] Type: AnimatedCrossFade
    //     0xf3e9d0: ldr             x8, [x8, #0xd80]
    // 0xf3e9d4: r3 = Null
    //     0xf3e9d4: add             x3, PP, #0x98, lsl #12  ; [pp+0x98d88] Null
    //     0xf3e9d8: ldr             x3, [x3, #0xd88]
    // 0xf3e9dc: r0 = AnimatedCrossFade()
    //     0xf3e9dc: bl              #0xad28d0  ; IsType_AnimatedCrossFade_Stub
    // 0xf3e9e0: ldur            x3, [fp, #-8]
    // 0xf3e9e4: LoadField: r2 = r3->field_7
    //     0xf3e9e4: ldur            w2, [x3, #7]
    // 0xf3e9e8: DecompressPointer r2
    //     0xf3e9e8: add             x2, x2, HEAP, lsl #32
    // 0xf3e9ec: ldur            x0, [fp, #-0x10]
    // 0xf3e9f0: r1 = Null
    //     0xf3e9f0: mov             x1, NULL
    // 0xf3e9f4: cmp             w2, NULL
    // 0xf3e9f8: b.eq            #0xf3ea1c
    // 0xf3e9fc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3e9fc: ldur            w4, [x2, #0x17]
    // 0xf3ea00: DecompressPointer r4
    //     0xf3ea00: add             x4, x4, HEAP, lsl #32
    // 0xf3ea04: r8 = X0 bound StatefulWidget
    //     0xf3ea04: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3ea08: ldr             x8, [x8, #0x498]
    // 0xf3ea0c: LoadField: r9 = r4->field_7
    //     0xf3ea0c: ldur            x9, [x4, #7]
    // 0xf3ea10: r3 = Null
    //     0xf3ea10: add             x3, PP, #0x98, lsl #12  ; [pp+0x98d98] Null
    //     0xf3ea14: ldr             x3, [x3, #0xd98]
    // 0xf3ea18: blr             x9
    // 0xf3ea1c: ldur            x0, [fp, #-8]
    // 0xf3ea20: LoadField: r1 = r0->field_b
    //     0xf3ea20: ldur            w1, [x0, #0xb]
    // 0xf3ea24: DecompressPointer r1
    //     0xf3ea24: add             x1, x1, HEAP, lsl #32
    // 0xf3ea28: cmp             w1, NULL
    // 0xf3ea2c: b.eq            #0xf3eb3c
    // 0xf3ea30: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf3ea30: ldur            w2, [x1, #0x17]
    // 0xf3ea34: DecompressPointer r2
    //     0xf3ea34: add             x2, x2, HEAP, lsl #32
    // 0xf3ea38: ldur            x1, [fp, #-0x10]
    // 0xf3ea3c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xf3ea3c: ldur            w3, [x1, #0x17]
    // 0xf3ea40: DecompressPointer r3
    //     0xf3ea40: add             x3, x3, HEAP, lsl #32
    // 0xf3ea44: stp             x3, x2, [SP]
    // 0xf3ea48: r0 = ==()
    //     0xf3ea48: bl              #0x124ef40  ; [dart:core] Duration::==
    // 0xf3ea4c: tbz             w0, #4, #0xf3eaa4
    // 0xf3ea50: ldur            x1, [fp, #-8]
    // 0xf3ea54: LoadField: r2 = r1->field_1b
    //     0xf3ea54: ldur            w2, [x1, #0x1b]
    // 0xf3ea58: DecompressPointer r2
    //     0xf3ea58: add             x2, x2, HEAP, lsl #32
    // 0xf3ea5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3ea60: cmp             w2, w16
    // 0xf3ea64: b.eq            #0xf3eb40
    // 0xf3ea68: LoadField: r0 = r1->field_b
    //     0xf3ea68: ldur            w0, [x1, #0xb]
    // 0xf3ea6c: DecompressPointer r0
    //     0xf3ea6c: add             x0, x0, HEAP, lsl #32
    // 0xf3ea70: cmp             w0, NULL
    // 0xf3ea74: b.eq            #0xf3eb4c
    // 0xf3ea78: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xf3ea78: ldur            w3, [x0, #0x17]
    // 0xf3ea7c: DecompressPointer r3
    //     0xf3ea7c: add             x3, x3, HEAP, lsl #32
    // 0xf3ea80: mov             x0, x3
    // 0xf3ea84: StoreField: r2->field_27 = r0
    //     0xf3ea84: stur            w0, [x2, #0x27]
    //     0xf3ea88: ldurb           w16, [x2, #-1]
    //     0xf3ea8c: ldurb           w17, [x0, #-1]
    //     0xf3ea90: and             x16, x17, x16, lsr #2
    //     0xf3ea94: tst             x16, HEAP, lsr #32
    //     0xf3ea98: b.eq            #0xf3eaa0
    //     0xf3ea9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3eaa0: b               #0xf3eaa8
    // 0xf3eaa4: ldur            x1, [fp, #-8]
    // 0xf3eaa8: ldur            x0, [fp, #-0x10]
    // 0xf3eaac: LoadField: r2 = r1->field_b
    //     0xf3eaac: ldur            w2, [x1, #0xb]
    // 0xf3eab0: DecompressPointer r2
    //     0xf3eab0: add             x2, x2, HEAP, lsl #32
    // 0xf3eab4: cmp             w2, NULL
    // 0xf3eab8: b.eq            #0xf3eb50
    // 0xf3eabc: LoadField: r3 = r2->field_13
    //     0xf3eabc: ldur            w3, [x2, #0x13]
    // 0xf3eac0: DecompressPointer r3
    //     0xf3eac0: add             x3, x3, HEAP, lsl #32
    // 0xf3eac4: LoadField: r2 = r0->field_13
    //     0xf3eac4: ldur            w2, [x0, #0x13]
    // 0xf3eac8: DecompressPointer r2
    //     0xf3eac8: add             x2, x2, HEAP, lsl #32
    // 0xf3eacc: cmp             w3, w2
    // 0xf3ead0: b.eq            #0xf3eb24
    // 0xf3ead4: LoadField: r0 = r3->field_7
    //     0xf3ead4: ldur            x0, [x3, #7]
    // 0xf3ead8: cmp             x0, #0
    // 0xf3eadc: b.gt            #0xf3eb04
    // 0xf3eae0: LoadField: r0 = r1->field_1b
    //     0xf3eae0: ldur            w0, [x1, #0x1b]
    // 0xf3eae4: DecompressPointer r0
    //     0xf3eae4: add             x0, x0, HEAP, lsl #32
    // 0xf3eae8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3eaec: cmp             w0, w16
    // 0xf3eaf0: b.eq            #0xf3eb54
    // 0xf3eaf4: mov             x1, x0
    // 0xf3eaf8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3eaf8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3eafc: r0 = reverse()
    //     0xf3eafc: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf3eb00: b               #0xf3eb24
    // 0xf3eb04: LoadField: r0 = r1->field_1b
    //     0xf3eb04: ldur            w0, [x1, #0x1b]
    // 0xf3eb08: DecompressPointer r0
    //     0xf3eb08: add             x0, x0, HEAP, lsl #32
    // 0xf3eb0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3eb10: cmp             w0, w16
    // 0xf3eb14: b.eq            #0xf3eb60
    // 0xf3eb18: mov             x1, x0
    // 0xf3eb1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3eb1c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3eb20: r0 = forward()
    //     0xf3eb20: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf3eb24: r0 = Null
    //     0xf3eb24: mov             x0, NULL
    // 0xf3eb28: LeaveFrame
    //     0xf3eb28: mov             SP, fp
    //     0xf3eb2c: ldp             fp, lr, [SP], #0x10
    // 0xf3eb30: ret
    //     0xf3eb30: ret             
    // 0xf3eb34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3eb34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3eb38: b               #0xf3e9a4
    // 0xf3eb3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3eb3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3eb40: r9 = _controller
    //     0xf3eb40: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0xf3eb44: ldr             x9, [x9, #0xd68]
    // 0xf3eb48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3eb48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3eb4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3eb4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3eb50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3eb50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3eb54: r9 = _controller
    //     0xf3eb54: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0xf3eb58: ldr             x9, [x9, #0xd68]
    // 0xf3eb5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3eb5c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3eb60: r9 = _controller
    //     0xf3eb60: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0xf3eb64: ldr             x9, [x9, #0xd68]
    // 0xf3eb68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3eb68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf82628, size: 0x19c
    // 0xf82628: EnterFrame
    //     0xf82628: stp             fp, lr, [SP, #-0x10]!
    //     0xf8262c: mov             fp, SP
    // 0xf82630: AllocStack(0x30)
    //     0xf82630: sub             SP, SP, #0x30
    // 0xf82634: SetupParameters(_AnimatedCrossFadeState this /* r1 => r2, fp-0x8 */)
    //     0xf82634: mov             x2, x1
    //     0xf82638: stur            x1, [fp, #-8]
    // 0xf8263c: CheckStackOverflow
    //     0xf8263c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82640: cmp             SP, x16
    //     0xf82644: b.ls            #0xf827ac
    // 0xf82648: r1 = 1
    //     0xf82648: mov             x1, #1
    // 0xf8264c: r0 = AllocateContext()
    //     0xf8264c: bl              #0x13de838  ; AllocateContextStub
    // 0xf82650: ldur            x2, [fp, #-8]
    // 0xf82654: stur            x0, [fp, #-0x18]
    // 0xf82658: StoreField: r0->field_f = r2
    //     0xf82658: stur            w2, [x0, #0xf]
    // 0xf8265c: LoadField: r1 = r2->field_b
    //     0xf8265c: ldur            w1, [x2, #0xb]
    // 0xf82660: DecompressPointer r1
    //     0xf82660: add             x1, x1, HEAP, lsl #32
    // 0xf82664: cmp             w1, NULL
    // 0xf82668: b.eq            #0xf827b4
    // 0xf8266c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xf8266c: ldur            w3, [x1, #0x17]
    // 0xf82670: DecompressPointer r3
    //     0xf82670: add             x3, x3, HEAP, lsl #32
    // 0xf82674: stur            x3, [fp, #-0x10]
    // 0xf82678: r1 = <double>
    //     0xf82678: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf8267c: r0 = AnimationController()
    //     0xf8267c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf82680: stur            x0, [fp, #-0x20]
    // 0xf82684: ldur            x16, [fp, #-0x10]
    // 0xf82688: stp             NULL, x16, [SP]
    // 0xf8268c: mov             x1, x0
    // 0xf82690: ldur            x2, [fp, #-8]
    // 0xf82694: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0xf82694: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e860] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0xf82698: ldr             x4, [x4, #0x860]
    // 0xf8269c: r0 = AnimationController()
    //     0xf8269c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf826a0: ldur            x0, [fp, #-0x20]
    // 0xf826a4: ldur            x3, [fp, #-8]
    // 0xf826a8: StoreField: r3->field_1b = r0
    //     0xf826a8: stur            w0, [x3, #0x1b]
    //     0xf826ac: ldurb           w16, [x3, #-1]
    //     0xf826b0: ldurb           w17, [x0, #-1]
    //     0xf826b4: and             x16, x17, x16, lsr #2
    //     0xf826b8: tst             x16, HEAP, lsr #32
    //     0xf826bc: b.eq            #0xf826c4
    //     0xf826c0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf826c4: LoadField: r0 = r3->field_b
    //     0xf826c4: ldur            w0, [x3, #0xb]
    // 0xf826c8: DecompressPointer r0
    //     0xf826c8: add             x0, x0, HEAP, lsl #32
    // 0xf826cc: cmp             w0, NULL
    // 0xf826d0: b.eq            #0xf827b8
    // 0xf826d4: LoadField: r1 = r0->field_13
    //     0xf826d4: ldur            w1, [x0, #0x13]
    // 0xf826d8: DecompressPointer r1
    //     0xf826d8: add             x1, x1, HEAP, lsl #32
    // 0xf826dc: r16 = Instance_CrossFadeState
    //     0xf826dc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27540] Obj!CrossFadeState@12c35e1
    //     0xf826e0: ldr             x16, [x16, #0x540]
    // 0xf826e4: cmp             w1, w16
    // 0xf826e8: b.ne            #0xf826f8
    // 0xf826ec: ldur            x1, [fp, #-0x20]
    // 0xf826f0: r2 = 1.000000
    //     0xf826f0: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf826f4: r0 = value=()
    //     0xf826f4: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf826f8: ldur            x0, [fp, #-8]
    // 0xf826fc: LoadField: r1 = r0->field_b
    //     0xf826fc: ldur            w1, [x0, #0xb]
    // 0xf82700: DecompressPointer r1
    //     0xf82700: add             x1, x1, HEAP, lsl #32
    // 0xf82704: cmp             w1, NULL
    // 0xf82708: b.eq            #0xf827bc
    // 0xf8270c: mov             x1, x0
    // 0xf82710: r2 = true
    //     0xf82710: add             x2, NULL, #0x20  ; true
    // 0xf82714: r0 = _initAnimation()
    //     0xf82714: bl              #0xf827c4  ; [package:flutter/src/widgets/animated_cross_fade.dart] _AnimatedCrossFadeState::_initAnimation
    // 0xf82718: ldur            x3, [fp, #-8]
    // 0xf8271c: StoreField: r3->field_1f = r0
    //     0xf8271c: stur            w0, [x3, #0x1f]
    //     0xf82720: ldurb           w16, [x3, #-1]
    //     0xf82724: ldurb           w17, [x0, #-1]
    //     0xf82728: and             x16, x17, x16, lsr #2
    //     0xf8272c: tst             x16, HEAP, lsr #32
    //     0xf82730: b.eq            #0xf82738
    //     0xf82734: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf82738: LoadField: r0 = r3->field_b
    //     0xf82738: ldur            w0, [x3, #0xb]
    // 0xf8273c: DecompressPointer r0
    //     0xf8273c: add             x0, x0, HEAP, lsl #32
    // 0xf82740: cmp             w0, NULL
    // 0xf82744: b.eq            #0xf827c0
    // 0xf82748: mov             x1, x3
    // 0xf8274c: r2 = false
    //     0xf8274c: add             x2, NULL, #0x30  ; false
    // 0xf82750: r0 = _initAnimation()
    //     0xf82750: bl              #0xf827c4  ; [package:flutter/src/widgets/animated_cross_fade.dart] _AnimatedCrossFadeState::_initAnimation
    // 0xf82754: ldur            x1, [fp, #-8]
    // 0xf82758: StoreField: r1->field_23 = r0
    //     0xf82758: stur            w0, [x1, #0x23]
    //     0xf8275c: ldurb           w16, [x1, #-1]
    //     0xf82760: ldurb           w17, [x0, #-1]
    //     0xf82764: and             x16, x17, x16, lsr #2
    //     0xf82768: tst             x16, HEAP, lsr #32
    //     0xf8276c: b.eq            #0xf82774
    //     0xf82770: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf82774: LoadField: r0 = r1->field_1b
    //     0xf82774: ldur            w0, [x1, #0x1b]
    // 0xf82778: DecompressPointer r0
    //     0xf82778: add             x0, x0, HEAP, lsl #32
    // 0xf8277c: ldur            x2, [fp, #-0x18]
    // 0xf82780: stur            x0, [fp, #-0x10]
    // 0xf82784: r1 = Function '<anonymous closure>':.
    //     0xf82784: add             x1, PP, #0x98, lsl #12  ; [pp+0x98da8] AnonymousClosure: (0xf82898), in [package:flutter/src/widgets/animated_cross_fade.dart] _AnimatedCrossFadeState::initState (0xf82628)
    //     0xf82788: ldr             x1, [x1, #0xda8]
    // 0xf8278c: r0 = AllocateClosure()
    //     0xf8278c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf82790: ldur            x1, [fp, #-0x10]
    // 0xf82794: mov             x2, x0
    // 0xf82798: r0 = addStatusListener()
    //     0xf82798: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf8279c: r0 = Null
    //     0xf8279c: mov             x0, NULL
    // 0xf827a0: LeaveFrame
    //     0xf827a0: mov             SP, fp
    //     0xf827a4: ldp             fp, lr, [SP], #0x10
    // 0xf827a8: ret
    //     0xf827a8: ret             
    // 0xf827ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf827ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf827b0: b               #0xf82648
    // 0xf827b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf827b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf827b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf827b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf827bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf827bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf827c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf827c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initAnimation(/* No info */) {
    // ** addr: 0xf827c4, size: 0xd4
    // 0xf827c4: EnterFrame
    //     0xf827c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf827c8: mov             fp, SP
    // 0xf827cc: AllocStack(0x10)
    //     0xf827cc: sub             SP, SP, #0x10
    // 0xf827d0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf827d0: stur            x2, [fp, #-0x10]
    // 0xf827d4: CheckStackOverflow
    //     0xf827d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf827d8: cmp             SP, x16
    //     0xf827dc: b.ls            #0xf82884
    // 0xf827e0: LoadField: r0 = r1->field_1b
    //     0xf827e0: ldur            w0, [x1, #0x1b]
    // 0xf827e4: DecompressPointer r0
    //     0xf827e4: add             x0, x0, HEAP, lsl #32
    // 0xf827e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf827ec: cmp             w0, w16
    // 0xf827f0: b.eq            #0xf8288c
    // 0xf827f4: stur            x0, [fp, #-8]
    // 0xf827f8: r1 = <double>
    //     0xf827f8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf827fc: r0 = CurveTween()
    //     0xf827fc: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf82800: mov             x1, x0
    // 0xf82804: r0 = Instance__Linear
    //     0xf82804: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf82808: StoreField: r1->field_b = r0
    //     0xf82808: stur            w0, [x1, #0xb]
    // 0xf8280c: ldur            x2, [fp, #-8]
    // 0xf82810: r0 = animate()
    //     0xf82810: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf82814: mov             x2, x0
    // 0xf82818: ldur            x0, [fp, #-0x10]
    // 0xf8281c: stur            x2, [fp, #-8]
    // 0xf82820: tbnz            w0, #4, #0xf82874
    // 0xf82824: r1 = <double>
    //     0xf82824: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf82828: r0 = Tween()
    //     0xf82828: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf8282c: mov             x3, x0
    // 0xf82830: r0 = 1.000000
    //     0xf82830: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf82834: stur            x3, [fp, #-0x10]
    // 0xf82838: StoreField: r3->field_b = r0
    //     0xf82838: stur            w0, [x3, #0xb]
    // 0xf8283c: r0 = 0.000000
    //     0xf8283c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf82840: StoreField: r3->field_f = r0
    //     0xf82840: stur            w0, [x3, #0xf]
    // 0xf82844: ldur            x0, [fp, #-8]
    // 0xf82848: r2 = Null
    //     0xf82848: mov             x2, NULL
    // 0xf8284c: r1 = Null
    //     0xf8284c: mov             x1, NULL
    // 0xf82850: r8 = Animation<double>
    //     0xf82850: add             x8, PP, #0x80, lsl #12  ; [pp+0x809a8] Type: Animation<double>
    //     0xf82854: ldr             x8, [x8, #0x9a8]
    // 0xf82858: r3 = Null
    //     0xf82858: add             x3, PP, #0x98, lsl #12  ; [pp+0x98db8] Null
    //     0xf8285c: ldr             x3, [x3, #0xdb8]
    // 0xf82860: r0 = Animation<double>()
    //     0xf82860: bl              #0x829684  ; IsType_Animation<double>_Stub
    // 0xf82864: ldur            x1, [fp, #-0x10]
    // 0xf82868: ldur            x2, [fp, #-8]
    // 0xf8286c: r0 = animate()
    //     0xf8286c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf82870: b               #0xf82878
    // 0xf82874: ldur            x0, [fp, #-8]
    // 0xf82878: LeaveFrame
    //     0xf82878: mov             SP, fp
    //     0xf8287c: ldp             fp, lr, [SP], #0x10
    // 0xf82880: ret
    //     0xf82880: ret             
    // 0xf82884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82888: b               #0xf827e0
    // 0xf8288c: r9 = _controller
    //     0xf8288c: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0xf82890: ldr             x9, [x9, #0xd68]
    // 0xf82894: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf82894: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, AnimationStatus) {
    // ** addr: 0xf82898, size: 0xa4
    // 0xf82898: EnterFrame
    //     0xf82898: stp             fp, lr, [SP, #-0x10]!
    //     0xf8289c: mov             fp, SP
    // 0xf828a0: AllocStack(0x10)
    //     0xf828a0: sub             SP, SP, #0x10
    // 0xf828a4: SetupParameters([dynamic _ /* r0 */])
    //     0xf828a4: ldr             x0, [fp, #0x18]
    //     0xf828a8: ldur            w3, [x0, #0x17]
    //     0xf828ac: add             x3, x3, HEAP, lsl #32
    //     0xf828b0: stur            x3, [fp, #-0x10]
    // 0xf828b4: CheckStackOverflow
    //     0xf828b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf828b8: cmp             SP, x16
    //     0xf828bc: b.ls            #0xf82930
    // 0xf828c0: LoadField: r0 = r3->field_f
    //     0xf828c0: ldur            w0, [x3, #0xf]
    // 0xf828c4: DecompressPointer r0
    //     0xf828c4: add             x0, x0, HEAP, lsl #32
    // 0xf828c8: stur            x0, [fp, #-8]
    // 0xf828cc: r1 = Function '<anonymous closure>':.
    //     0xf828cc: add             x1, PP, #0x98, lsl #12  ; [pp+0x98db0] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf828d0: ldr             x1, [x1, #0xdb0]
    // 0xf828d4: r2 = Null
    //     0xf828d4: mov             x2, NULL
    // 0xf828d8: r0 = AllocateClosure()
    //     0xf828d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf828dc: ldur            x1, [fp, #-8]
    // 0xf828e0: mov             x2, x0
    // 0xf828e4: r0 = setState()
    //     0xf828e4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf828e8: ldr             x1, [fp, #0x10]
    // 0xf828ec: r16 = Instance_AnimationStatus
    //     0xf828ec: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xf828f0: cmp             w1, w16
    // 0xf828f4: b.eq            #0xf82904
    // 0xf828f8: r16 = Instance_AnimationStatus
    //     0xf828f8: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf828fc: cmp             w1, w16
    // 0xf82900: b.ne            #0xf82920
    // 0xf82904: ldur            x1, [fp, #-0x10]
    // 0xf82908: LoadField: r2 = r1->field_f
    //     0xf82908: ldur            w2, [x1, #0xf]
    // 0xf8290c: DecompressPointer r2
    //     0xf8290c: add             x2, x2, HEAP, lsl #32
    // 0xf82910: LoadField: r1 = r2->field_b
    //     0xf82910: ldur            w1, [x2, #0xb]
    // 0xf82914: DecompressPointer r1
    //     0xf82914: add             x1, x1, HEAP, lsl #32
    // 0xf82918: cmp             w1, NULL
    // 0xf8291c: b.eq            #0xf82938
    // 0xf82920: r0 = Null
    //     0xf82920: mov             x0, NULL
    // 0xf82924: LeaveFrame
    //     0xf82924: mov             SP, fp
    //     0xf82928: ldp             fp, lr, [SP], #0x10
    // 0xf8292c: ret
    //     0xf8292c: ret             
    // 0xf82930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82934: b               #0xf828c0
    // 0xf82938: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf82938: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10deb04, size: 0x64
    // 0x10deb04: EnterFrame
    //     0x10deb04: stp             fp, lr, [SP, #-0x10]!
    //     0x10deb08: mov             fp, SP
    // 0x10deb0c: AllocStack(0x8)
    //     0x10deb0c: sub             SP, SP, #8
    // 0x10deb10: SetupParameters(_AnimatedCrossFadeState this /* r1 => r0, fp-0x8 */)
    //     0x10deb10: mov             x0, x1
    //     0x10deb14: stur            x1, [fp, #-8]
    // 0x10deb18: CheckStackOverflow
    //     0x10deb18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10deb1c: cmp             SP, x16
    //     0x10deb20: b.ls            #0x10deb54
    // 0x10deb24: LoadField: r1 = r0->field_1b
    //     0x10deb24: ldur            w1, [x0, #0x1b]
    // 0x10deb28: DecompressPointer r1
    //     0x10deb28: add             x1, x1, HEAP, lsl #32
    // 0x10deb2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10deb30: cmp             w1, w16
    // 0x10deb34: b.eq            #0x10deb5c
    // 0x10deb38: r0 = dispose()
    //     0x10deb38: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10deb3c: ldur            x1, [fp, #-8]
    // 0x10deb40: r0 = dispose()
    //     0x10deb40: bl              #0x10deb68  ; [dart:mixin_deduplication] _MixinApplication185&State&TickerProviderStateMixin::dispose
    // 0x10deb44: r0 = Null
    //     0x10deb44: mov             x0, NULL
    // 0x10deb48: LeaveFrame
    //     0x10deb48: mov             SP, fp
    //     0x10deb4c: ldp             fp, lr, [SP], #0x10
    // 0x10deb50: ret
    //     0x10deb50: ret             
    // 0x10deb54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10deb54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10deb58: b               #0x10deb24
    // 0x10deb5c: r9 = _controller
    //     0x10deb5c: add             x9, PP, #0x98, lsl #12  ; [pp+0x98d68] Field <_AnimatedCrossFadeState@147463501._controller@147463501>: late (offset: 0x1c)
    //     0x10deb60: ldr             x9, [x9, #0xd68]
    // 0x10deb64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10deb64: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6408, size: 0x3c, field offset: 0xc
//   const constructor, 
class AnimatedCrossFade extends StatefulWidget {

  [closure] static Widget defaultLayoutBuilder(dynamic, Widget, Key, Widget, Key) {
    // ** addr: 0xd5c0dc, size: 0x3c
    // 0xd5c0dc: EnterFrame
    //     0xd5c0dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c0e0: mov             fp, SP
    // 0xd5c0e4: CheckStackOverflow
    //     0xd5c0e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5c0e8: cmp             SP, x16
    //     0xd5c0ec: b.ls            #0xd5c110
    // 0xd5c0f0: ldr             x1, [fp, #0x28]
    // 0xd5c0f4: ldr             x2, [fp, #0x20]
    // 0xd5c0f8: ldr             x3, [fp, #0x18]
    // 0xd5c0fc: ldr             x5, [fp, #0x10]
    // 0xd5c100: r0 = defaultLayoutBuilder()
    //     0xd5c100: bl              #0xd5c124  ; [package:flutter/src/widgets/animated_cross_fade.dart] AnimatedCrossFade::defaultLayoutBuilder
    // 0xd5c104: LeaveFrame
    //     0xd5c104: mov             SP, fp
    //     0xd5c108: ldp             fp, lr, [SP], #0x10
    // 0xd5c10c: ret
    //     0xd5c10c: ret             
    // 0xd5c110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5c110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5c114: b               #0xd5c0f0
  }
  static _ defaultLayoutBuilder(/* No info */) {
    // ** addr: 0xd5c124, size: 0xf8
    // 0xd5c124: EnterFrame
    //     0xd5c124: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c128: mov             fp, SP
    // 0xd5c12c: AllocStack(0x28)
    //     0xd5c12c: sub             SP, SP, #0x28
    // 0xd5c130: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xd5c130: mov             x0, x1
    //     0xd5c134: stur            x1, [fp, #-8]
    //     0xd5c138: stur            x2, [fp, #-0x10]
    //     0xd5c13c: stur            x3, [fp, #-0x18]
    //     0xd5c140: stur            x5, [fp, #-0x20]
    // 0xd5c144: r1 = <StackParentData>
    //     0xd5c144: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xd5c148: ldr             x1, [x1, #0x858]
    // 0xd5c14c: r0 = Positioned()
    //     0xd5c14c: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xd5c150: mov             x2, x0
    // 0xd5c154: r0 = 0.000000
    //     0xd5c154: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd5c158: stur            x2, [fp, #-0x28]
    // 0xd5c15c: StoreField: r2->field_13 = r0
    //     0xd5c15c: stur            w0, [x2, #0x13]
    // 0xd5c160: ArrayStore: r2[0] = r0  ; List_4
    //     0xd5c160: stur            w0, [x2, #0x17]
    // 0xd5c164: StoreField: r2->field_1b = r0
    //     0xd5c164: stur            w0, [x2, #0x1b]
    // 0xd5c168: ldur            x0, [fp, #-0x18]
    // 0xd5c16c: StoreField: r2->field_b = r0
    //     0xd5c16c: stur            w0, [x2, #0xb]
    // 0xd5c170: ldur            x0, [fp, #-0x20]
    // 0xd5c174: StoreField: r2->field_7 = r0
    //     0xd5c174: stur            w0, [x2, #7]
    // 0xd5c178: r1 = <StackParentData>
    //     0xd5c178: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xd5c17c: ldr             x1, [x1, #0x858]
    // 0xd5c180: r0 = Positioned()
    //     0xd5c180: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xd5c184: mov             x3, x0
    // 0xd5c188: ldur            x0, [fp, #-8]
    // 0xd5c18c: stur            x3, [fp, #-0x18]
    // 0xd5c190: StoreField: r3->field_b = r0
    //     0xd5c190: stur            w0, [x3, #0xb]
    // 0xd5c194: ldur            x0, [fp, #-0x10]
    // 0xd5c198: StoreField: r3->field_7 = r0
    //     0xd5c198: stur            w0, [x3, #7]
    // 0xd5c19c: r1 = Null
    //     0xd5c19c: mov             x1, NULL
    // 0xd5c1a0: r2 = 4
    //     0xd5c1a0: mov             x2, #4
    // 0xd5c1a4: r0 = AllocateArray()
    //     0xd5c1a4: bl              #0x13df928  ; AllocateArrayStub
    // 0xd5c1a8: mov             x2, x0
    // 0xd5c1ac: ldur            x0, [fp, #-0x28]
    // 0xd5c1b0: stur            x2, [fp, #-8]
    // 0xd5c1b4: StoreField: r2->field_f = r0
    //     0xd5c1b4: stur            w0, [x2, #0xf]
    // 0xd5c1b8: ldur            x0, [fp, #-0x18]
    // 0xd5c1bc: StoreField: r2->field_13 = r0
    //     0xd5c1bc: stur            w0, [x2, #0x13]
    // 0xd5c1c0: r1 = <Widget>
    //     0xd5c1c0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd5c1c4: r0 = AllocateGrowableArray()
    //     0xd5c1c4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd5c1c8: mov             x1, x0
    // 0xd5c1cc: ldur            x0, [fp, #-8]
    // 0xd5c1d0: stur            x1, [fp, #-0x10]
    // 0xd5c1d4: StoreField: r1->field_f = r0
    //     0xd5c1d4: stur            w0, [x1, #0xf]
    // 0xd5c1d8: r0 = 4
    //     0xd5c1d8: mov             x0, #4
    // 0xd5c1dc: StoreField: r1->field_b = r0
    //     0xd5c1dc: stur            w0, [x1, #0xb]
    // 0xd5c1e0: r0 = Stack()
    //     0xd5c1e0: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd5c1e4: r1 = Instance_AlignmentDirectional
    //     0xd5c1e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xd5c1e8: ldr             x1, [x1, #0x8d8]
    // 0xd5c1ec: StoreField: r0->field_f = r1
    //     0xd5c1ec: stur            w1, [x0, #0xf]
    // 0xd5c1f0: r1 = Instance_StackFit
    //     0xd5c1f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd5c1f4: ldr             x1, [x1, #0x8e0]
    // 0xd5c1f8: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5c1f8: stur            w1, [x0, #0x17]
    // 0xd5c1fc: r1 = Instance_Clip
    //     0xd5c1fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd5c200: ldr             x1, [x1, #0x840]
    // 0xd5c204: StoreField: r0->field_1b = r1
    //     0xd5c204: stur            w1, [x0, #0x1b]
    // 0xd5c208: ldur            x1, [fp, #-0x10]
    // 0xd5c20c: StoreField: r0->field_b = r1
    //     0xd5c20c: stur            w1, [x0, #0xb]
    // 0xd5c210: LeaveFrame
    //     0xd5c210: mov             SP, fp
    //     0xd5c214: ldp             fp, lr, [SP], #0x10
    // 0xd5c218: ret
    //     0xd5c218: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa36f4, size: 0x34
    // 0xfa36f4: EnterFrame
    //     0xfa36f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa36f8: mov             fp, SP
    // 0xfa36fc: mov             x0, x1
    // 0xfa3700: r1 = <AnimatedCrossFade>
    //     0xfa3700: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f418] TypeArguments: <AnimatedCrossFade>
    //     0xfa3704: ldr             x1, [x1, #0x418]
    // 0xfa3708: r0 = _AnimatedCrossFadeState()
    //     0xfa3708: bl              #0xfa3728  ; Allocate_AnimatedCrossFadeStateStub -> _AnimatedCrossFadeState (size=0x28)
    // 0xfa370c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3710: StoreField: r0->field_1b = r1
    //     0xfa3710: stur            w1, [x0, #0x1b]
    // 0xfa3714: StoreField: r0->field_1f = r1
    //     0xfa3714: stur            w1, [x0, #0x1f]
    // 0xfa3718: StoreField: r0->field_23 = r1
    //     0xfa3718: stur            w1, [x0, #0x23]
    // 0xfa371c: LeaveFrame
    //     0xfa371c: mov             SP, fp
    //     0xfa3720: ldp             fp, lr, [SP], #0x10
    // 0xfa3724: ret
    //     0xfa3724: ret             
  }
}

// class id: 8190, size: 0x14, field offset: 0x14
enum CrossFadeState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abd14, size: 0x64
    // 0x11abd14: EnterFrame
    //     0x11abd14: stp             fp, lr, [SP, #-0x10]!
    //     0x11abd18: mov             fp, SP
    // 0x11abd1c: AllocStack(0x10)
    //     0x11abd1c: sub             SP, SP, #0x10
    // 0x11abd20: SetupParameters(CrossFadeState this /* r1 => r0, fp-0x8 */)
    //     0x11abd20: mov             x0, x1
    //     0x11abd24: stur            x1, [fp, #-8]
    // 0x11abd28: CheckStackOverflow
    //     0x11abd28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abd2c: cmp             SP, x16
    //     0x11abd30: b.ls            #0x11abd70
    // 0x11abd34: r1 = Null
    //     0x11abd34: mov             x1, NULL
    // 0x11abd38: r2 = 4
    //     0x11abd38: mov             x2, #4
    // 0x11abd3c: r0 = AllocateArray()
    //     0x11abd3c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abd40: r16 = "CrossFadeState."
    //     0x11abd40: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f410] "CrossFadeState."
    //     0x11abd44: ldr             x16, [x16, #0x410]
    // 0x11abd48: StoreField: r0->field_f = r16
    //     0x11abd48: stur            w16, [x0, #0xf]
    // 0x11abd4c: ldur            x1, [fp, #-8]
    // 0x11abd50: LoadField: r2 = r1->field_f
    //     0x11abd50: ldur            w2, [x1, #0xf]
    // 0x11abd54: DecompressPointer r2
    //     0x11abd54: add             x2, x2, HEAP, lsl #32
    // 0x11abd58: StoreField: r0->field_13 = r2
    //     0x11abd58: stur            w2, [x0, #0x13]
    // 0x11abd5c: str             x0, [SP]
    // 0x11abd60: r0 = _interpolate()
    //     0x11abd60: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abd64: LeaveFrame
    //     0x11abd64: mov             SP, fp
    //     0x11abd68: ldp             fp, lr, [SP], #0x10
    // 0x11abd6c: ret
    //     0x11abd6c: ret             
    // 0x11abd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abd70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abd74: b               #0x11abd34
  }
}
