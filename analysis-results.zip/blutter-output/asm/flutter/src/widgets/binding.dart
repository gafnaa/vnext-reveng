// lib: , url: package:flutter/src/widgets/binding.dart

// class id: 1049121, size: 0x8
class :: {

  static _ runApp(/* No info */) {
    // ** addr: 0x13e5754, size: 0x58
    // 0x13e5754: EnterFrame
    //     0x13e5754: stp             fp, lr, [SP, #-0x10]!
    //     0x13e5758: mov             fp, SP
    // 0x13e575c: AllocStack(0x8)
    //     0x13e575c: sub             SP, SP, #8
    // 0x13e5760: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x13e5760: mov             x2, x1
    //     0x13e5764: stur            x1, [fp, #-8]
    // 0x13e5768: CheckStackOverflow
    //     0x13e5768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e576c: cmp             SP, x16
    //     0x13e5770: b.ls            #0x13e57a4
    // 0x13e5774: r0 = ensureInitialized()
    //     0x13e5774: bl              #0x8397cc  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0x13e5778: mov             x1, x0
    // 0x13e577c: ldur            x2, [fp, #-8]
    // 0x13e5780: stur            x0, [fp, #-8]
    // 0x13e5784: r0 = wrapWithDefaultView()
    //     0x13e5784: bl              #0x13e5c78  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::wrapWithDefaultView
    // 0x13e5788: mov             x1, x0
    // 0x13e578c: ldur            x2, [fp, #-8]
    // 0x13e5790: r0 = _runWidget()
    //     0x13e5790: bl              #0x13e57ac  ; [package:flutter/src/widgets/binding.dart] ::_runWidget
    // 0x13e5794: r0 = Null
    //     0x13e5794: mov             x0, NULL
    // 0x13e5798: LeaveFrame
    //     0x13e5798: mov             SP, fp
    //     0x13e579c: ldp             fp, lr, [SP], #0x10
    // 0x13e57a0: ret
    //     0x13e57a0: ret             
    // 0x13e57a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e57a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e57a8: b               #0x13e5774
  }
  static _ _runWidget(/* No info */) {
    // ** addr: 0x13e57ac, size: 0x4c
    // 0x13e57ac: EnterFrame
    //     0x13e57ac: stp             fp, lr, [SP, #-0x10]!
    //     0x13e57b0: mov             fp, SP
    // 0x13e57b4: AllocStack(0x8)
    //     0x13e57b4: sub             SP, SP, #8
    // 0x13e57b8: SetupParameters(dynamic _ /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x13e57b8: mov             x0, x2
    //     0x13e57bc: stur            x2, [fp, #-8]
    //     0x13e57c0: mov             x2, x1
    // 0x13e57c4: CheckStackOverflow
    //     0x13e57c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e57c8: cmp             SP, x16
    //     0x13e57cc: b.ls            #0x13e57f0
    // 0x13e57d0: mov             x1, x0
    // 0x13e57d4: r0 = scheduleAttachRootWidget()
    //     0x13e57d4: bl              #0x13e57f8  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::scheduleAttachRootWidget
    // 0x13e57d8: ldur            x1, [fp, #-8]
    // 0x13e57dc: r0 = scheduleWarmUpFrame()
    //     0x13e57dc: bl              #0x831574  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::scheduleWarmUpFrame
    // 0x13e57e0: r0 = Null
    //     0x13e57e0: mov             x0, NULL
    // 0x13e57e4: LeaveFrame
    //     0x13e57e4: mov             SP, fp
    //     0x13e57e8: ldp             fp, lr, [SP], #0x10
    // 0x13e57ec: ret
    //     0x13e57ec: ret             
    // 0x13e57f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e57f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e57f4: b               #0x13e57d0
  }
}

// class id: 4564, size: 0x8, field offset: 0x8
abstract class WidgetsBinding extends _MixinApplication200&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&RendererBinding&SemanticsBinding {
}

// class id: 4609, size: 0x110, field offset: 0x110
class WidgetsFlutterBinding extends _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding {

  static _ ensureInitialized(/* No info */) {
    // ** addr: 0x8397cc, size: 0x58
    // 0x8397cc: EnterFrame
    //     0x8397cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8397d0: mov             fp, SP
    // 0x8397d4: CheckStackOverflow
    //     0x8397d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8397d8: cmp             SP, x16
    //     0x8397dc: b.ls            #0x839818
    // 0x8397e0: r0 = LoadStaticField(0x6a0)
    //     0x8397e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8397e4: ldr             x0, [x0, #0xd40]
    // 0x8397e8: cmp             w0, NULL
    // 0x8397ec: b.ne            #0x8397fc
    // 0x8397f0: r0 = WidgetsFlutterBinding()
    //     0x8397f0: bl              #0x89f8c8  ; AllocateWidgetsFlutterBindingStub -> WidgetsFlutterBinding (size=0x110)
    // 0x8397f4: mov             x1, x0
    // 0x8397f8: r0 = _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding()
    //     0x8397f8: bl              #0x839824  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::_MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding
    // 0x8397fc: r0 = LoadStaticField(0x6a0)
    //     0x8397fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x839800: ldr             x0, [x0, #0xd40]
    // 0x839804: cmp             w0, NULL
    // 0x839808: b.eq            #0x839820
    // 0x83980c: LeaveFrame
    //     0x83980c: mov             SP, fp
    //     0x839810: ldp             fp, lr, [SP], #0x10
    // 0x839814: ret
    //     0x839814: ret             
    // 0x839818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83981c: b               #0x8397e0
    // 0x839820: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839820: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4634, size: 0x8, field offset: 0x8
abstract class WidgetsBindingObserver extends Object {
}

// class id: 5843, size: 0x44, field offset: 0x3c
class RootElement extends _MixinApplication201&Element&RootElementMixin {

  _ mount(/* No info */) {
    // ** addr: 0xb8c0ac, size: 0x50
    // 0xb8c0ac: EnterFrame
    //     0xb8c0ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb8c0b0: mov             fp, SP
    // 0xb8c0b4: AllocStack(0x8)
    //     0xb8c0b4: sub             SP, SP, #8
    // 0xb8c0b8: SetupParameters(RootElement this /* r1 => r0, fp-0x8 */)
    //     0xb8c0b8: mov             x0, x1
    //     0xb8c0bc: stur            x1, [fp, #-8]
    // 0xb8c0c0: CheckStackOverflow
    //     0xb8c0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8c0c4: cmp             SP, x16
    //     0xb8c0c8: b.ls            #0xb8c0f4
    // 0xb8c0cc: mov             x1, x0
    // 0xb8c0d0: r0 = mount()
    //     0xb8c0d0: bl              #0xb92550  ; [package:flutter/src/widgets/framework.dart] Element::mount
    // 0xb8c0d4: ldur            x1, [fp, #-8]
    // 0xb8c0d8: r0 = _rebuild()
    //     0xb8c0d8: bl              #0xb8c12c  ; [package:flutter/src/widgets/binding.dart] RootElement::_rebuild
    // 0xb8c0dc: ldur            x1, [fp, #-8]
    // 0xb8c0e0: r0 = performRebuild()
    //     0xb8c0e0: bl              #0xbb39cc  ; [package:flutter/src/widgets/framework.dart] Element::performRebuild
    // 0xb8c0e4: r0 = Null
    //     0xb8c0e4: mov             x0, NULL
    // 0xb8c0e8: LeaveFrame
    //     0xb8c0e8: mov             SP, fp
    //     0xb8c0ec: ldp             fp, lr, [SP], #0x10
    // 0xb8c0f0: ret
    //     0xb8c0f0: ret             
    // 0xb8c0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8c0f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8c0f8: b               #0xb8c0cc
  }
  _ _rebuild(/* No info */) {
    // ** addr: 0xb8c12c, size: 0x274
    // 0xb8c12c: EnterFrame
    //     0xb8c12c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8c130: mov             fp, SP
    // 0xb8c134: AllocStack(0x80)
    //     0xb8c134: sub             SP, SP, #0x80
    // 0xb8c138: SetupParameters(RootElement this /* r1 => r3, fp-0x68 */)
    //     0xb8c138: mov             x3, x1
    //     0xb8c13c: stur            x1, [fp, #-0x68]
    // 0xb8c140: CheckStackOverflow
    //     0xb8c140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8c144: cmp             SP, x16
    //     0xb8c148: b.ls            #0xb8c394
    // 0xb8c14c: LoadField: r4 = r3->field_3b
    //     0xb8c14c: ldur            w4, [x3, #0x3b]
    // 0xb8c150: DecompressPointer r4
    //     0xb8c150: add             x4, x4, HEAP, lsl #32
    // 0xb8c154: stur            x4, [fp, #-0x60]
    // 0xb8c158: ArrayLoad: r5 = r3[0]  ; List_4
    //     0xb8c158: ldur            w5, [x3, #0x17]
    // 0xb8c15c: DecompressPointer r5
    //     0xb8c15c: add             x5, x5, HEAP, lsl #32
    // 0xb8c160: stur            x5, [fp, #-0x58]
    // 0xb8c164: cmp             w5, NULL
    // 0xb8c168: b.eq            #0xb8c39c
    // 0xb8c16c: mov             x0, x5
    // 0xb8c170: r2 = Null
    //     0xb8c170: mov             x2, NULL
    // 0xb8c174: r1 = Null
    //     0xb8c174: mov             x1, NULL
    // 0xb8c178: r4 = LoadClassIdInstr(r0)
    //     0xb8c178: ldur            x4, [x0, #-1]
    //     0xb8c17c: ubfx            x4, x4, #0xc, #0x14
    // 0xb8c180: r17 = 5850
    //     0xb8c180: mov             x17, #0x16da
    // 0xb8c184: cmp             x4, x17
    // 0xb8c188: b.eq            #0xb8c198
    // 0xb8c18c: r8 = RootWidget
    //     0xb8c18c: ldr             x8, [PP, #0x7e38]  ; [pp+0x7e38] Type: RootWidget
    // 0xb8c190: r3 = Null
    //     0xb8c190: ldr             x3, [PP, #0x7e40]  ; [pp+0x7e40] Null
    // 0xb8c194: r0 = DefaultTypeTest()
    //     0xb8c194: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb8c198: ldur            x0, [fp, #-0x58]
    // 0xb8c19c: LoadField: r2 = r0->field_b
    //     0xb8c19c: ldur            w2, [x0, #0xb]
    // 0xb8c1a0: DecompressPointer r2
    //     0xb8c1a0: add             x2, x2, HEAP, lsl #32
    // 0xb8c1a4: ldur            x3, [fp, #-0x60]
    // 0xb8c1a8: stur            x2, [fp, #-0x70]
    // 0xb8c1ac: cmp             w3, NULL
    // 0xb8c1b0: b.eq            #0xb8c2e0
    // 0xb8c1b4: r0 = LoadClassIdInstr(r3)
    //     0xb8c1b4: ldur            x0, [x3, #-1]
    //     0xb8c1b8: ubfx            x0, x0, #0xc, #0x14
    // 0xb8c1bc: mov             x1, x3
    // 0xb8c1c0: r0 = GDT[cid_x0 + 0xb17]()
    //     0xb8c1c0: add             lr, x0, #0xb17
    //     0xb8c1c4: ldr             lr, [x21, lr, lsl #3]
    //     0xb8c1c8: blr             lr
    // 0xb8c1cc: ldur            x2, [fp, #-0x70]
    // 0xb8c1d0: cmp             w0, w2
    // 0xb8c1d4: b.ne            #0xb8c224
    // 0xb8c1d8: ldur            x2, [fp, #-0x60]
    // 0xb8c1dc: LoadField: r0 = r2->field_f
    //     0xb8c1dc: ldur            w0, [x2, #0xf]
    // 0xb8c1e0: DecompressPointer r0
    //     0xb8c1e0: add             x0, x0, HEAP, lsl #32
    // 0xb8c1e4: r1 = 60
    //     0xb8c1e4: mov             x1, #0x3c
    // 0xb8c1e8: branchIfSmi(r0, 0xb8c1f4)
    //     0xb8c1e8: tbz             w0, #0, #0xb8c1f4
    // 0xb8c1ec: r1 = LoadClassIdInstr(r0)
    //     0xb8c1ec: ldur            x1, [x0, #-1]
    //     0xb8c1f0: ubfx            x1, x1, #0xc, #0x14
    // 0xb8c1f4: stp             NULL, x0, [SP]
    // 0xb8c1f8: mov             x0, x1
    // 0xb8c1fc: mov             lr, x0
    // 0xb8c200: ldr             lr, [x21, lr, lsl #3]
    // 0xb8c204: blr             lr
    // 0xb8c208: tbz             w0, #4, #0xb8c21c
    // 0xb8c20c: ldur            x1, [fp, #-0x68]
    // 0xb8c210: ldur            x2, [fp, #-0x60]
    // 0xb8c214: r3 = Null
    //     0xb8c214: mov             x3, NULL
    // 0xb8c218: r0 = updateSlotForChild()
    //     0xb8c218: bl              #0xb49b58  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0xb8c21c: ldur            x0, [fp, #-0x60]
    // 0xb8c220: b               #0xb8c2f0
    // 0xb8c224: ldur            x3, [fp, #-0x60]
    // 0xb8c228: r0 = LoadClassIdInstr(r3)
    //     0xb8c228: ldur            x0, [x3, #-1]
    //     0xb8c22c: ubfx            x0, x0, #0xc, #0x14
    // 0xb8c230: mov             x1, x3
    // 0xb8c234: r0 = GDT[cid_x0 + 0xb17]()
    //     0xb8c234: add             lr, x0, #0xb17
    //     0xb8c238: ldr             lr, [x21, lr, lsl #3]
    //     0xb8c23c: blr             lr
    // 0xb8c240: mov             x1, x0
    // 0xb8c244: ldur            x2, [fp, #-0x70]
    // 0xb8c248: r0 = canUpdate()
    //     0xb8c248: bl              #0xb49ae0  ; [package:flutter/src/widgets/framework.dart] Widget::canUpdate
    // 0xb8c24c: tbnz            w0, #4, #0xb8c2c0
    // 0xb8c250: ldur            x2, [fp, #-0x60]
    // 0xb8c254: LoadField: r0 = r2->field_f
    //     0xb8c254: ldur            w0, [x2, #0xf]
    // 0xb8c258: DecompressPointer r0
    //     0xb8c258: add             x0, x0, HEAP, lsl #32
    // 0xb8c25c: r1 = 60
    //     0xb8c25c: mov             x1, #0x3c
    // 0xb8c260: branchIfSmi(r0, 0xb8c26c)
    //     0xb8c260: tbz             w0, #0, #0xb8c26c
    // 0xb8c264: r1 = LoadClassIdInstr(r0)
    //     0xb8c264: ldur            x1, [x0, #-1]
    //     0xb8c268: ubfx            x1, x1, #0xc, #0x14
    // 0xb8c26c: stp             NULL, x0, [SP]
    // 0xb8c270: mov             x0, x1
    // 0xb8c274: mov             lr, x0
    // 0xb8c278: ldr             lr, [x21, lr, lsl #3]
    // 0xb8c27c: blr             lr
    // 0xb8c280: tbz             w0, #4, #0xb8c294
    // 0xb8c284: ldur            x1, [fp, #-0x68]
    // 0xb8c288: ldur            x2, [fp, #-0x60]
    // 0xb8c28c: r3 = Null
    //     0xb8c28c: mov             x3, NULL
    // 0xb8c290: r0 = updateSlotForChild()
    //     0xb8c290: bl              #0xb49b58  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0xb8c294: ldur            x3, [fp, #-0x60]
    // 0xb8c298: r0 = LoadClassIdInstr(r3)
    //     0xb8c298: ldur            x0, [x3, #-1]
    //     0xb8c29c: ubfx            x0, x0, #0xc, #0x14
    // 0xb8c2a0: mov             x1, x3
    // 0xb8c2a4: ldur            x2, [fp, #-0x70]
    // 0xb8c2a8: r0 = GDT[cid_x0 + 0xab8a]()
    //     0xb8c2a8: mov             x17, #0xab8a
    //     0xb8c2ac: add             lr, x0, x17
    //     0xb8c2b0: ldr             lr, [x21, lr, lsl #3]
    //     0xb8c2b4: blr             lr
    // 0xb8c2b8: ldur            x0, [fp, #-0x60]
    // 0xb8c2bc: b               #0xb8c2f0
    // 0xb8c2c0: ldur            x1, [fp, #-0x68]
    // 0xb8c2c4: ldur            x2, [fp, #-0x60]
    // 0xb8c2c8: r0 = deactivateChild()
    //     0xb8c2c8: bl              #0xb49db8  ; [package:flutter/src/widgets/framework.dart] Element::deactivateChild
    // 0xb8c2cc: ldur            x1, [fp, #-0x68]
    // 0xb8c2d0: ldur            x2, [fp, #-0x70]
    // 0xb8c2d4: r3 = Null
    //     0xb8c2d4: mov             x3, NULL
    // 0xb8c2d8: r0 = inflateWidget()
    //     0xb8c2d8: bl              #0x1104b9c  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0xb8c2dc: b               #0xb8c2f0
    // 0xb8c2e0: ldur            x1, [fp, #-0x68]
    // 0xb8c2e4: ldur            x2, [fp, #-0x70]
    // 0xb8c2e8: r3 = Null
    //     0xb8c2e8: mov             x3, NULL
    // 0xb8c2ec: r0 = inflateWidget()
    //     0xb8c2ec: bl              #0x1104b9c  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0xb8c2f0: ldur            x2, [fp, #-0x68]
    // 0xb8c2f4: StoreField: r2->field_3b = r0
    //     0xb8c2f4: stur            w0, [x2, #0x3b]
    //     0xb8c2f8: ldurb           w16, [x2, #-1]
    //     0xb8c2fc: ldurb           w17, [x0, #-1]
    //     0xb8c300: and             x16, x17, x16, lsr #2
    //     0xb8c304: tst             x16, HEAP, lsr #32
    //     0xb8c308: b.eq            #0xb8c310
    //     0xb8c30c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb8c310: b               #0xb8c384
    // 0xb8c314: sub             SP, fp, #0x80
    // 0xb8c318: ldur            x2, [fp, #-0x68]
    // 0xb8c31c: mov             x3, x0
    // 0xb8c320: stur            x0, [fp, #-0x58]
    // 0xb8c324: mov             x0, x1
    // 0xb8c328: stur            x1, [fp, #-0x60]
    // 0xb8c32c: r1 = <List<Object>>
    //     0xb8c32c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xb8c330: r0 = ErrorDescription()
    //     0xb8c330: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xb8c334: mov             x1, x0
    // 0xb8c338: r2 = "attaching to the render tree"
    //     0xb8c338: ldr             x2, [PP, #0x7e50]  ; [pp+0x7e50] "attaching to the render tree"
    // 0xb8c33c: r3 = Instance_DiagnosticLevel
    //     0xb8c33c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xb8c340: stur            x0, [fp, #-0x70]
    // 0xb8c344: r0 = _ErrorDiagnostic()
    //     0xb8c344: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xb8c348: r0 = FlutterErrorDetails()
    //     0xb8c348: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0xb8c34c: mov             x1, x0
    // 0xb8c350: ldur            x0, [fp, #-0x58]
    // 0xb8c354: StoreField: r1->field_7 = r0
    //     0xb8c354: stur            w0, [x1, #7]
    // 0xb8c358: ldur            x0, [fp, #-0x60]
    // 0xb8c35c: StoreField: r1->field_b = r0
    //     0xb8c35c: stur            w0, [x1, #0xb]
    // 0xb8c360: r0 = "widgets library"
    //     0xb8c360: ldr             x0, [PP, #0x18b8]  ; [pp+0x18b8] "widgets library"
    // 0xb8c364: StoreField: r1->field_f = r0
    //     0xb8c364: stur            w0, [x1, #0xf]
    // 0xb8c368: ldur            x0, [fp, #-0x70]
    // 0xb8c36c: StoreField: r1->field_13 = r0
    //     0xb8c36c: stur            w0, [x1, #0x13]
    // 0xb8c370: r0 = false
    //     0xb8c370: add             x0, NULL, #0x30  ; false
    // 0xb8c374: StoreField: r1->field_1b = r0
    //     0xb8c374: stur            w0, [x1, #0x1b]
    // 0xb8c378: r0 = reportError()
    //     0xb8c378: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xb8c37c: ldur            x1, [fp, #-0x68]
    // 0xb8c380: StoreField: r1->field_3b = rNULL
    //     0xb8c380: stur            NULL, [x1, #0x3b]
    // 0xb8c384: r0 = Null
    //     0xb8c384: mov             x0, NULL
    // 0xb8c388: LeaveFrame
    //     0xb8c388: mov             SP, fp
    //     0xb8c38c: ldp             fp, lr, [SP], #0x10
    // 0xb8c390: ret
    //     0xb8c390: ret             
    // 0xb8c394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8c394: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8c398: b               #0xb8c14c
    // 0xb8c39c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8c39c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performRebuild(/* No info */) {
    // ** addr: 0xbb19fc, size: 0x5c
    // 0xbb19fc: EnterFrame
    //     0xbb19fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1a00: mov             fp, SP
    // 0xbb1a04: AllocStack(0x8)
    //     0xbb1a04: sub             SP, SP, #8
    // 0xbb1a08: SetupParameters(RootElement this /* r1 => r0, fp-0x8 */)
    //     0xbb1a08: mov             x0, x1
    //     0xbb1a0c: stur            x1, [fp, #-8]
    // 0xbb1a10: CheckStackOverflow
    //     0xbb1a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1a14: cmp             SP, x16
    //     0xbb1a18: b.ls            #0xbb1a50
    // 0xbb1a1c: LoadField: r2 = r0->field_3f
    //     0xbb1a1c: ldur            w2, [x0, #0x3f]
    // 0xbb1a20: DecompressPointer r2
    //     0xbb1a20: add             x2, x2, HEAP, lsl #32
    // 0xbb1a24: cmp             w2, NULL
    // 0xbb1a28: b.eq            #0xbb1a38
    // 0xbb1a2c: StoreField: r0->field_3f = rNULL
    //     0xbb1a2c: stur            NULL, [x0, #0x3f]
    // 0xbb1a30: mov             x1, x0
    // 0xbb1a34: r0 = update()
    //     0xbb1a34: bl              #0x10f9e54  ; [package:flutter/src/widgets/binding.dart] RootElement::update
    // 0xbb1a38: ldur            x1, [fp, #-8]
    // 0xbb1a3c: r0 = performRebuild()
    //     0xbb1a3c: bl              #0xbb39cc  ; [package:flutter/src/widgets/framework.dart] Element::performRebuild
    // 0xbb1a40: r0 = Null
    //     0xbb1a40: mov             x0, NULL
    // 0xbb1a44: LeaveFrame
    //     0xbb1a44: mov             SP, fp
    //     0xbb1a48: ldp             fp, lr, [SP], #0x10
    // 0xbb1a4c: ret
    //     0xbb1a4c: ret             
    // 0xbb1a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1a50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1a54: b               #0xbb1a1c
  }
  _ update(/* No info */) {
    // ** addr: 0x10f9e54, size: 0xa0
    // 0x10f9e54: EnterFrame
    //     0x10f9e54: stp             fp, lr, [SP, #-0x10]!
    //     0x10f9e58: mov             fp, SP
    // 0x10f9e5c: AllocStack(0x10)
    //     0x10f9e5c: sub             SP, SP, #0x10
    // 0x10f9e60: SetupParameters(RootElement this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x10f9e60: mov             x4, x1
    //     0x10f9e64: mov             x3, x2
    //     0x10f9e68: stur            x1, [fp, #-8]
    //     0x10f9e6c: stur            x2, [fp, #-0x10]
    // 0x10f9e70: CheckStackOverflow
    //     0x10f9e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f9e74: cmp             SP, x16
    //     0x10f9e78: b.ls            #0x10f9eec
    // 0x10f9e7c: mov             x0, x3
    // 0x10f9e80: r2 = Null
    //     0x10f9e80: mov             x2, NULL
    // 0x10f9e84: r1 = Null
    //     0x10f9e84: mov             x1, NULL
    // 0x10f9e88: r4 = 60
    //     0x10f9e88: mov             x4, #0x3c
    // 0x10f9e8c: branchIfSmi(r0, 0x10f9e98)
    //     0x10f9e8c: tbz             w0, #0, #0x10f9e98
    // 0x10f9e90: r4 = LoadClassIdInstr(r0)
    //     0x10f9e90: ldur            x4, [x0, #-1]
    //     0x10f9e94: ubfx            x4, x4, #0xc, #0x14
    // 0x10f9e98: r17 = 5850
    //     0x10f9e98: mov             x17, #0x16da
    // 0x10f9e9c: cmp             x4, x17
    // 0x10f9ea0: b.eq            #0x10f9eb4
    // 0x10f9ea4: r8 = RootWidget
    //     0x10f9ea4: ldr             x8, [PP, #0x7e38]  ; [pp+0x7e38] Type: RootWidget
    // 0x10f9ea8: r3 = Null
    //     0x10f9ea8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe1b8] Null
    //     0x10f9eac: ldr             x3, [x3, #0x1b8]
    // 0x10f9eb0: r0 = DefaultTypeTest()
    //     0x10f9eb0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10f9eb4: ldur            x0, [fp, #-0x10]
    // 0x10f9eb8: ldur            x1, [fp, #-8]
    // 0x10f9ebc: ArrayStore: r1[0] = r0  ; List_4
    //     0x10f9ebc: stur            w0, [x1, #0x17]
    //     0x10f9ec0: ldurb           w16, [x1, #-1]
    //     0x10f9ec4: ldurb           w17, [x0, #-1]
    //     0x10f9ec8: and             x16, x17, x16, lsr #2
    //     0x10f9ecc: tst             x16, HEAP, lsr #32
    //     0x10f9ed0: b.eq            #0x10f9ed8
    //     0x10f9ed4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f9ed8: r0 = _rebuild()
    //     0x10f9ed8: bl              #0xb8c12c  ; [package:flutter/src/widgets/binding.dart] RootElement::_rebuild
    // 0x10f9edc: r0 = Null
    //     0x10f9edc: mov             x0, NULL
    // 0x10f9ee0: LeaveFrame
    //     0x10f9ee0: mov             SP, fp
    //     0x10f9ee4: ldp             fp, lr, [SP], #0x10
    // 0x10f9ee8: ret
    //     0x10f9ee8: ret             
    // 0x10f9eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f9eec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f9ef0: b               #0x10f9e7c
  }
}

// class id: 5850, size: 0x10, field offset: 0xc
//   const constructor, 
class RootWidget extends Widget {

  _ createElement(/* No info */) {
    // ** addr: 0x10f2c74, size: 0x4c
    // 0x10f2c74: EnterFrame
    //     0x10f2c74: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2c78: mov             fp, SP
    // 0x10f2c7c: AllocStack(0x8)
    //     0x10f2c7c: sub             SP, SP, #8
    // 0x10f2c80: SetupParameters(RootWidget this /* r1 => r1, fp-0x8 */)
    //     0x10f2c80: stur            x1, [fp, #-8]
    // 0x10f2c84: r0 = RootElement()
    //     0x10f2c84: bl              #0x10f2cc0  ; AllocateRootElementStub -> RootElement (size=0x44)
    // 0x10f2c88: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f2c8c: StoreField: r0->field_13 = r1
    //     0x10f2c8c: stur            w1, [x0, #0x13]
    // 0x10f2c90: r1 = Instance__ElementLifecycle
    //     0x10f2c90: ldr             x1, [PP, #0x7ef8]  ; [pp+0x7ef8] Obj!_ElementLifecycle@12c2fc1
    // 0x10f2c94: StoreField: r0->field_23 = r1
    //     0x10f2c94: stur            w1, [x0, #0x23]
    // 0x10f2c98: r1 = false
    //     0x10f2c98: add             x1, NULL, #0x30  ; false
    // 0x10f2c9c: StoreField: r0->field_2f = r1
    //     0x10f2c9c: stur            w1, [x0, #0x2f]
    // 0x10f2ca0: r2 = true
    //     0x10f2ca0: add             x2, NULL, #0x20  ; true
    // 0x10f2ca4: StoreField: r0->field_33 = r2
    //     0x10f2ca4: stur            w2, [x0, #0x33]
    // 0x10f2ca8: StoreField: r0->field_37 = r1
    //     0x10f2ca8: stur            w1, [x0, #0x37]
    // 0x10f2cac: ldur            x1, [fp, #-8]
    // 0x10f2cb0: ArrayStore: r0[0] = r1  ; List_4
    //     0x10f2cb0: stur            w1, [x0, #0x17]
    // 0x10f2cb4: LeaveFrame
    //     0x10f2cb4: mov             SP, fp
    //     0x10f2cb8: ldp             fp, lr, [SP], #0x10
    // 0x10f2cbc: ret
    //     0x10f2cbc: ret             
  }
  _ attach(/* No info */) {
    // ** addr: 0x13e59c0, size: 0x110
    // 0x13e59c0: EnterFrame
    //     0x13e59c0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e59c4: mov             fp, SP
    // 0x13e59c8: AllocStack(0x30)
    //     0x13e59c8: sub             SP, SP, #0x30
    // 0x13e59cc: SetupParameters(RootWidget this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x13e59cc: mov             x0, x2
    //     0x13e59d0: stur            x2, [fp, #-0x10]
    //     0x13e59d4: mov             x2, x1
    //     0x13e59d8: stur            x1, [fp, #-8]
    //     0x13e59dc: mov             x1, x3
    //     0x13e59e0: stur            x3, [fp, #-0x18]
    // 0x13e59e4: CheckStackOverflow
    //     0x13e59e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e59e8: cmp             SP, x16
    //     0x13e59ec: b.ls            #0x13e5ac0
    // 0x13e59f0: r1 = 3
    //     0x13e59f0: mov             x1, #3
    // 0x13e59f4: r0 = AllocateContext()
    //     0x13e59f4: bl              #0x13de838  ; AllocateContextStub
    // 0x13e59f8: mov             x3, x0
    // 0x13e59fc: ldur            x0, [fp, #-8]
    // 0x13e5a00: stur            x3, [fp, #-0x20]
    // 0x13e5a04: StoreField: r3->field_f = r0
    //     0x13e5a04: stur            w0, [x3, #0xf]
    // 0x13e5a08: ldur            x4, [fp, #-0x10]
    // 0x13e5a0c: StoreField: r3->field_13 = r4
    //     0x13e5a0c: stur            w4, [x3, #0x13]
    // 0x13e5a10: ldur            x1, [fp, #-0x18]
    // 0x13e5a14: ArrayStore: r3[0] = r1  ; List_4
    //     0x13e5a14: stur            w1, [x3, #0x17]
    // 0x13e5a18: cmp             w1, NULL
    // 0x13e5a1c: b.ne            #0x13e5a80
    // 0x13e5a20: mov             x2, x3
    // 0x13e5a24: r1 = Function '<anonymous closure>':.
    //     0x13e5a24: ldr             x1, [PP, #0x7e28]  ; [pp+0x7e28] AnonymousClosure: (0x13e5b2c), in [package:flutter/src/widgets/binding.dart] RootWidget::attach (0x13e59c0)
    // 0x13e5a28: r0 = AllocateClosure()
    //     0x13e5a28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x13e5a2c: ldur            x1, [fp, #-0x10]
    // 0x13e5a30: mov             x2, x0
    // 0x13e5a34: r0 = lockState()
    //     0x13e5a34: bl              #0x8349d0  ; [package:flutter/src/widgets/framework.dart] BuildOwner::lockState
    // 0x13e5a38: ldur            x0, [fp, #-0x20]
    // 0x13e5a3c: LoadField: r3 = r0->field_13
    //     0x13e5a3c: ldur            w3, [x0, #0x13]
    // 0x13e5a40: DecompressPointer r3
    //     0x13e5a40: add             x3, x3, HEAP, lsl #32
    // 0x13e5a44: stur            x3, [fp, #-0x28]
    // 0x13e5a48: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x13e5a48: ldur            w4, [x0, #0x17]
    // 0x13e5a4c: DecompressPointer r4
    //     0x13e5a4c: add             x4, x4, HEAP, lsl #32
    // 0x13e5a50: stur            x4, [fp, #-0x10]
    // 0x13e5a54: cmp             w4, NULL
    // 0x13e5a58: b.eq            #0x13e5ac8
    // 0x13e5a5c: mov             x2, x0
    // 0x13e5a60: r1 = Function '<anonymous closure>':.
    //     0x13e5a60: ldr             x1, [PP, #0x7e30]  ; [pp+0x7e30] AnonymousClosure: (0x13e5ad0), in [package:flutter/src/widgets/binding.dart] RootWidget::attach (0x13e59c0)
    // 0x13e5a64: r0 = AllocateClosure()
    //     0x13e5a64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x13e5a68: str             x0, [SP]
    // 0x13e5a6c: ldur            x1, [fp, #-0x28]
    // 0x13e5a70: ldur            x2, [fp, #-0x10]
    // 0x13e5a74: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x13e5a74: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x13e5a78: r0 = buildScope()
    //     0x13e5a78: bl              #0x89b838  ; [package:flutter/src/widgets/framework.dart] BuildOwner::buildScope
    // 0x13e5a7c: b               #0x13e5aa0
    // 0x13e5a80: StoreField: r1->field_3f = r0
    //     0x13e5a80: stur            w0, [x1, #0x3f]
    //     0x13e5a84: ldurb           w16, [x1, #-1]
    //     0x13e5a88: ldurb           w17, [x0, #-1]
    //     0x13e5a8c: and             x16, x17, x16, lsr #2
    //     0x13e5a90: tst             x16, HEAP, lsr #32
    //     0x13e5a94: b.eq            #0x13e5a9c
    //     0x13e5a98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x13e5a9c: r0 = markNeedsBuild()
    //     0x13e5a9c: bl              #0xbfd208  ; [package:flutter/src/widgets/framework.dart] Element::markNeedsBuild
    // 0x13e5aa0: ldur            x1, [fp, #-0x20]
    // 0x13e5aa4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x13e5aa4: ldur            w0, [x1, #0x17]
    // 0x13e5aa8: DecompressPointer r0
    //     0x13e5aa8: add             x0, x0, HEAP, lsl #32
    // 0x13e5aac: cmp             w0, NULL
    // 0x13e5ab0: b.eq            #0x13e5acc
    // 0x13e5ab4: LeaveFrame
    //     0x13e5ab4: mov             SP, fp
    //     0x13e5ab8: ldp             fp, lr, [SP], #0x10
    // 0x13e5abc: ret
    //     0x13e5abc: ret             
    // 0x13e5ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e5ac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e5ac4: b               #0x13e59f0
    // 0x13e5ac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e5ac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x13e5acc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e5acc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x13e5ad0, size: 0x5c
    // 0x13e5ad0: EnterFrame
    //     0x13e5ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x13e5ad4: mov             fp, SP
    // 0x13e5ad8: ldr             x0, [fp, #0x10]
    // 0x13e5adc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x13e5adc: ldur            w1, [x0, #0x17]
    // 0x13e5ae0: DecompressPointer r1
    //     0x13e5ae0: add             x1, x1, HEAP, lsl #32
    // 0x13e5ae4: CheckStackOverflow
    //     0x13e5ae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e5ae8: cmp             SP, x16
    //     0x13e5aec: b.ls            #0x13e5b20
    // 0x13e5af0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x13e5af0: ldur            w0, [x1, #0x17]
    // 0x13e5af4: DecompressPointer r0
    //     0x13e5af4: add             x0, x0, HEAP, lsl #32
    // 0x13e5af8: cmp             w0, NULL
    // 0x13e5afc: b.eq            #0x13e5b28
    // 0x13e5b00: mov             x1, x0
    // 0x13e5b04: r2 = Null
    //     0x13e5b04: mov             x2, NULL
    // 0x13e5b08: r3 = Null
    //     0x13e5b08: mov             x3, NULL
    // 0x13e5b0c: r0 = mount()
    //     0x13e5b0c: bl              #0xb8c0ac  ; [package:flutter/src/widgets/binding.dart] RootElement::mount
    // 0x13e5b10: r0 = Null
    //     0x13e5b10: mov             x0, NULL
    // 0x13e5b14: LeaveFrame
    //     0x13e5b14: mov             SP, fp
    //     0x13e5b18: ldp             fp, lr, [SP], #0x10
    // 0x13e5b1c: ret
    //     0x13e5b1c: ret             
    // 0x13e5b20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e5b20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e5b24: b               #0x13e5af0
    // 0x13e5b28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13e5b28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x13e5b2c, size: 0x84
    // 0x13e5b2c: EnterFrame
    //     0x13e5b2c: stp             fp, lr, [SP, #-0x10]!
    //     0x13e5b30: mov             fp, SP
    // 0x13e5b34: AllocStack(0x8)
    //     0x13e5b34: sub             SP, SP, #8
    // 0x13e5b38: SetupParameters([dynamic _ /* r0 */])
    //     0x13e5b38: ldr             x0, [fp, #0x10]
    //     0x13e5b3c: ldur            w2, [x0, #0x17]
    //     0x13e5b40: add             x2, x2, HEAP, lsl #32
    //     0x13e5b44: stur            x2, [fp, #-8]
    // 0x13e5b48: CheckStackOverflow
    //     0x13e5b48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e5b4c: cmp             SP, x16
    //     0x13e5b50: b.ls            #0x13e5ba8
    // 0x13e5b54: LoadField: r1 = r2->field_f
    //     0x13e5b54: ldur            w1, [x2, #0xf]
    // 0x13e5b58: DecompressPointer r1
    //     0x13e5b58: add             x1, x1, HEAP, lsl #32
    // 0x13e5b5c: r0 = createElement()
    //     0x13e5b5c: bl              #0x10f2c74  ; [package:flutter/src/widgets/binding.dart] RootWidget::createElement
    // 0x13e5b60: mov             x2, x0
    // 0x13e5b64: ldur            x1, [fp, #-8]
    // 0x13e5b68: ArrayStore: r1[0] = r0  ; List_4
    //     0x13e5b68: stur            w0, [x1, #0x17]
    //     0x13e5b6c: ldurb           w16, [x1, #-1]
    //     0x13e5b70: ldurb           w17, [x0, #-1]
    //     0x13e5b74: and             x16, x17, x16, lsr #2
    //     0x13e5b78: tst             x16, HEAP, lsr #32
    //     0x13e5b7c: b.eq            #0x13e5b84
    //     0x13e5b80: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x13e5b84: LoadField: r0 = r1->field_13
    //     0x13e5b84: ldur            w0, [x1, #0x13]
    // 0x13e5b88: DecompressPointer r0
    //     0x13e5b88: add             x0, x0, HEAP, lsl #32
    // 0x13e5b8c: mov             x1, x2
    // 0x13e5b90: mov             x2, x0
    // 0x13e5b94: r0 = assignOwner()
    //     0x13e5b94: bl              #0x13e5bb0  ; [dart:mixin_deduplication] _MixinApplication201&Element&RootElementMixin::assignOwner
    // 0x13e5b98: r0 = Null
    //     0x13e5b98: mov             x0, NULL
    // 0x13e5b9c: LeaveFrame
    //     0x13e5b9c: mov             SP, fp
    //     0x13e5ba0: ldp             fp, lr, [SP], #0x10
    // 0x13e5ba4: ret
    //     0x13e5ba4: ret             
    // 0x13e5ba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e5ba8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e5bac: b               #0x13e5b54
  }
}
