// lib: , url: package:flutter/src/widgets/autofill.dart

// class id: 1049118, size: 0x8
class :: {
}

// class id: 6401, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class AutofillGroup extends StatefulWidget {

  static _ maybeOf(/* No info */) {
    // ** addr: 0xeef96c, size: 0x44
    // 0xeef96c: EnterFrame
    //     0xeef96c: stp             fp, lr, [SP, #-0x10]!
    //     0xeef970: mov             fp, SP
    // 0xeef974: AllocStack(0x10)
    //     0xeef974: sub             SP, SP, #0x10
    // 0xeef978: CheckStackOverflow
    //     0xeef978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef97c: cmp             SP, x16
    //     0xeef980: b.ls            #0xeef9a8
    // 0xeef984: r16 = <_AutofillScope>
    //     0xeef984: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa32e0] TypeArguments: <_AutofillScope>
    //     0xeef988: ldr             x16, [x16, #0x2e0]
    // 0xeef98c: stp             x1, x16, [SP]
    // 0xeef990: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeef990: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeef994: r0 = dependOnInheritedWidgetOfExactType()
    //     0xeef994: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xeef998: r0 = Null
    //     0xeef998: mov             x0, NULL
    // 0xeef99c: LeaveFrame
    //     0xeef99c: mov             SP, fp
    //     0xeef9a0: ldp             fp, lr, [SP], #0x10
    // 0xeef9a4: ret
    //     0xeef9a4: ret             
    // 0xeef9a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef9a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef9ac: b               #0xeef984
  }
}

// class id: 6798, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class _AutofillScope extends InheritedWidget {
}
