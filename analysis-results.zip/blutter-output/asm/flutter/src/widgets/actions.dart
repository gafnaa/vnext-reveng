// lib: , url: package:flutter/src/widgets/actions.dart

// class id: 1049110, size: 0x8
class :: {

  [closure] static bool <anonymous closure>(dynamic, Element) {
    // ** addr: 0x879a98, size: 0x80
    // 0x879a98: EnterFrame
    //     0x879a98: stp             fp, lr, [SP, #-0x10]!
    //     0x879a9c: mov             fp, SP
    // 0x879aa0: AllocStack(0x8)
    //     0x879aa0: sub             SP, SP, #8
    // 0x879aa4: SetupParameters([dynamic _ /* r0 */])
    //     0x879aa4: ldr             x0, [fp, #0x18]
    //     0x879aa8: ldur            w1, [x0, #0x17]
    //     0x879aac: add             x1, x1, HEAP, lsl #32
    // 0x879ab0: CheckStackOverflow
    //     0x879ab0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879ab4: cmp             SP, x16
    //     0x879ab8: b.ls            #0x879b10
    // 0x879abc: LoadField: r0 = r1->field_f
    //     0x879abc: ldur            w0, [x1, #0xf]
    // 0x879ac0: DecompressPointer r0
    //     0x879ac0: add             x0, x0, HEAP, lsl #32
    // 0x879ac4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x879ac8: cmp             w0, w16
    // 0x879acc: b.ne            #0x879b00
    // 0x879ad0: ldr             x0, [fp, #0x10]
    // 0x879ad4: StoreField: r1->field_f = r0
    //     0x879ad4: stur            w0, [x1, #0xf]
    //     0x879ad8: ldurb           w16, [x1, #-1]
    //     0x879adc: ldurb           w17, [x0, #-1]
    //     0x879ae0: and             x16, x17, x16, lsr #2
    //     0x879ae4: tst             x16, HEAP, lsr #32
    //     0x879ae8: b.eq            #0x879af0
    //     0x879aec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x879af0: r0 = false
    //     0x879af0: add             x0, NULL, #0x30  ; false
    // 0x879af4: LeaveFrame
    //     0x879af4: mov             SP, fp
    //     0x879af8: ldp             fp, lr, [SP], #0x10
    // 0x879afc: ret
    //     0x879afc: ret             
    // 0x879b00: r16 = "parent"
    //     0x879b00: ldr             x16, [PP, #0x47b8]  ; [pp+0x47b8] "parent"
    // 0x879b04: str             x16, [SP]
    // 0x879b08: r0 = _throwLocalAlreadyInitialized()
    //     0x879b08: bl              #0x82b684  ; [dart:_internal] LateError::_throwLocalAlreadyInitialized
    // 0x879b0c: brk             #0
    // 0x879b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879b10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879b14: b               #0x879abc
  }
}

// class id: 5007, size: 0x8, field offset: 0x8
//   const constructor, 
class ActionDispatcher extends _MixinApplication3&Object&Diagnosticable {

  _ invokeActionIfEnabled(/* No info */) {
    // ** addr: 0x1244530, size: 0x100
    // 0x1244530: EnterFrame
    //     0x1244530: stp             fp, lr, [SP, #-0x10]!
    //     0x1244534: mov             fp, SP
    // 0x1244538: AllocStack(0x18)
    //     0x1244538: sub             SP, SP, #0x18
    // 0x124453c: SetupParameters(dynamic _ /* r2 => r5, fp-0x8 */, dynamic _ /* r3 => r4, fp-0x10 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0x124453c: mov             x4, x3
    //     0x1244540: stur            x3, [fp, #-0x10]
    //     0x1244544: mov             x3, x5
    //     0x1244548: stur            x5, [fp, #-0x18]
    //     0x124454c: mov             x5, x2
    //     0x1244550: stur            x2, [fp, #-8]
    // 0x1244554: CheckStackOverflow
    //     0x1244554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1244558: cmp             SP, x16
    //     0x124455c: b.ls            #0x1244628
    // 0x1244560: mov             x0, x5
    // 0x1244564: r2 = Null
    //     0x1244564: mov             x2, NULL
    // 0x1244568: r1 = Null
    //     0x1244568: mov             x1, NULL
    // 0x124456c: r4 = 60
    //     0x124456c: mov             x4, #0x3c
    // 0x1244570: branchIfSmi(r0, 0x124457c)
    //     0x1244570: tbz             w0, #0, #0x124457c
    // 0x1244574: r4 = LoadClassIdInstr(r0)
    //     0x1244574: ldur            x4, [x0, #-1]
    //     0x1244578: ubfx            x4, x4, #0xc, #0x14
    // 0x124457c: r17 = -5315
    //     0x124457c: mov             x17, #-0x14c3
    // 0x1244580: add             x4, x4, x17
    // 0x1244584: cmp             x4, #0x1a
    // 0x1244588: b.ls            #0x124459c
    // 0x124458c: r8 = Action<Intent>
    //     0x124458c: ldr             x8, [PP, #0x46e8]  ; [pp+0x46e8] Type: Action<Intent>
    // 0x1244590: r3 = Null
    //     0x1244590: add             x3, PP, #0xac, lsl #12  ; [pp+0xacef0] Null
    //     0x1244594: ldr             x3, [x3, #0xef0]
    // 0x1244598: r0 = Action<Intent>()
    //     0x1244598: bl              #0x87a1d8  ; IsType_Action<Intent>_Stub
    // 0x124459c: ldur            x0, [fp, #-0x10]
    // 0x12445a0: r2 = Null
    //     0x12445a0: mov             x2, NULL
    // 0x12445a4: r1 = Null
    //     0x12445a4: mov             x1, NULL
    // 0x12445a8: r4 = 60
    //     0x12445a8: mov             x4, #0x3c
    // 0x12445ac: branchIfSmi(r0, 0x12445b8)
    //     0x12445ac: tbz             w0, #0, #0x12445b8
    // 0x12445b0: r4 = LoadClassIdInstr(r0)
    //     0x12445b0: ldur            x4, [x0, #-1]
    //     0x12445b4: ubfx            x4, x4, #0xc, #0x14
    // 0x12445b8: r17 = -5074
    //     0x12445b8: mov             x17, #-0x13d2
    // 0x12445bc: add             x4, x4, x17
    // 0x12445c0: cmp             x4, #0x28
    // 0x12445c4: b.ls            #0x12445dc
    // 0x12445c8: r8 = Intent
    //     0x12445c8: add             x8, PP, #0xac, lsl #12  ; [pp+0xacf00] Type: Intent
    //     0x12445cc: ldr             x8, [x8, #0xf00]
    // 0x12445d0: r3 = Null
    //     0x12445d0: add             x3, PP, #0xac, lsl #12  ; [pp+0xacf08] Null
    //     0x12445d4: ldr             x3, [x3, #0xf08]
    // 0x12445d8: r0 = Intent()
    //     0x12445d8: bl              #0x87a2a4  ; IsType_Intent_Stub
    // 0x12445dc: ldur            x1, [fp, #-8]
    // 0x12445e0: ldur            x2, [fp, #-0x10]
    // 0x12445e4: ldur            x3, [fp, #-0x18]
    // 0x12445e8: r0 = _isEnabled()
    //     0x12445e8: bl              #0x879f4c  ; [package:flutter/src/widgets/actions.dart] Action::_isEnabled
    // 0x12445ec: tbnz            w0, #4, #0x1244614
    // 0x12445f0: ldur            x1, [fp, #-8]
    // 0x12445f4: ldur            x2, [fp, #-0x10]
    // 0x12445f8: ldur            x3, [fp, #-0x18]
    // 0x12445fc: r0 = _invoke()
    //     0x12445fc: bl              #0x879d04  ; [package:flutter/src/widgets/actions.dart] Action::_invoke
    // 0x1244600: mov             x1, x0
    // 0x1244604: r0 = true
    //     0x1244604: add             x0, NULL, #0x20  ; true
    // 0x1244608: LeaveFrame
    //     0x1244608: mov             SP, fp
    //     0x124460c: ldp             fp, lr, [SP], #0x10
    // 0x1244610: ret
    //     0x1244610: ret             
    // 0x1244614: r0 = false
    //     0x1244614: add             x0, NULL, #0x30  ; false
    // 0x1244618: r1 = Null
    //     0x1244618: mov             x1, NULL
    // 0x124461c: LeaveFrame
    //     0x124461c: mov             SP, fp
    //     0x1244620: ldp             fp, lr, [SP], #0x10
    // 0x1244624: ret
    //     0x1244624: ret             
    // 0x1244628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1244628: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124462c: b               #0x1244560
  }
}

// class id: 5073, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Intent extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5107, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class PrioritizedIntents extends Intent {
}

// class id: 5108, size: 0x8, field offset: 0x8
//   const constructor, 
class DismissIntent extends Intent {
}

// class id: 5109, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ButtonActivateIntent extends Intent {
}

// class id: 5110, size: 0x8, field offset: 0x8
//   const constructor, 
class ActivateIntent extends Intent {
}

// class id: 5111, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DoNothingAndStopPropagationIntent extends Intent {
}

// class id: 5112, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DoNothingIntent extends Intent {
}

// class id: 5113, size: 0xc, field offset: 0x8
//   const constructor, 
class VoidCallbackIntent extends Intent {
}

// class id: 5314, size: 0x14, field offset: 0x8
abstract class Action<X0 bound Intent> extends _MixinApplication3&Object&Diagnosticable {

  _ _invoke(/* No info */) {
    // ** addr: 0x879d04, size: 0x134
    // 0x879d04: EnterFrame
    //     0x879d04: stp             fp, lr, [SP, #-0x10]!
    //     0x879d08: mov             fp, SP
    // 0x879d0c: AllocStack(0x28)
    //     0x879d0c: sub             SP, SP, #0x28
    // 0x879d10: SetupParameters(Action<X0 bound Intent> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x879d10: mov             x5, x1
    //     0x879d14: mov             x4, x2
    //     0x879d18: stur            x1, [fp, #-0x10]
    //     0x879d1c: stur            x2, [fp, #-0x18]
    //     0x879d20: stur            x3, [fp, #-0x20]
    // 0x879d24: CheckStackOverflow
    //     0x879d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879d28: cmp             SP, x16
    //     0x879d2c: b.ls            #0x879e30
    // 0x879d30: LoadField: r6 = r5->field_7
    //     0x879d30: ldur            w6, [x5, #7]
    // 0x879d34: DecompressPointer r6
    //     0x879d34: add             x6, x6, HEAP, lsl #32
    // 0x879d38: mov             x0, x4
    // 0x879d3c: mov             x2, x6
    // 0x879d40: stur            x6, [fp, #-8]
    // 0x879d44: r1 = Null
    //     0x879d44: mov             x1, NULL
    // 0x879d48: cmp             w2, NULL
    // 0x879d4c: b.eq            #0x879d68
    // 0x879d50: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x879d50: ldur            w4, [x2, #0x17]
    // 0x879d54: DecompressPointer r4
    //     0x879d54: add             x4, x4, HEAP, lsl #32
    // 0x879d58: r8 = X0 bound Intent
    //     0x879d58: ldr             x8, [PP, #0x4700]  ; [pp+0x4700] TypeParameter: X0 bound Intent
    // 0x879d5c: LoadField: r9 = r4->field_7
    //     0x879d5c: ldur            x9, [x4, #7]
    // 0x879d60: r3 = Null
    //     0x879d60: ldr             x3, [PP, #0x4708]  ; [pp+0x4708] Null
    // 0x879d64: blr             x9
    // 0x879d68: ldur            x0, [fp, #-0x10]
    // 0x879d6c: ldur            x2, [fp, #-8]
    // 0x879d70: r1 = Null
    //     0x879d70: mov             x1, NULL
    // 0x879d74: cmp             w0, NULL
    // 0x879d78: b.eq            #0x879db8
    // 0x879d7c: branchIfSmi(r0, 0x879db8)
    //     0x879d7c: tbz             w0, #0, #0x879db8
    // 0x879d80: r3 = SubtypeTestCache
    //     0x879d80: ldr             x3, [PP, #0x4718]  ; [pp+0x4718] SubtypeTestCache
    // 0x879d84: r30 = Subtype3TestCacheStub
    //     0x879d84: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x879d88: LoadField: r30 = r30->field_7
    //     0x879d88: ldur            lr, [lr, #7]
    // 0x879d8c: blr             lr
    // 0x879d90: cmp             w7, NULL
    // 0x879d94: b.eq            #0x879da0
    // 0x879d98: tbnz            w7, #4, #0x879db8
    // 0x879d9c: b               #0x879dc0
    // 0x879da0: r8 = ContextAction<X0 bound Intent>
    //     0x879da0: ldr             x8, [PP, #0x4720]  ; [pp+0x4720] Type: ContextAction<X0 bound Intent>
    // 0x879da4: r3 = SubtypeTestCache
    //     0x879da4: ldr             x3, [PP, #0x4728]  ; [pp+0x4728] SubtypeTestCache
    // 0x879da8: r30 = InstanceOfStub
    //     0x879da8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x879dac: LoadField: r30 = r30->field_7
    //     0x879dac: ldur            lr, [lr, #7]
    // 0x879db0: blr             lr
    // 0x879db4: b               #0x879dc4
    // 0x879db8: r0 = false
    //     0x879db8: add             x0, NULL, #0x30  ; false
    // 0x879dbc: b               #0x879dc4
    // 0x879dc0: r0 = true
    //     0x879dc0: add             x0, NULL, #0x20  ; true
    // 0x879dc4: tbnz            w0, #4, #0x879dfc
    // 0x879dc8: ldur            x1, [fp, #-0x10]
    // 0x879dcc: r0 = LoadClassIdInstr(r1)
    //     0x879dcc: ldur            x0, [x1, #-1]
    //     0x879dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x879dd4: ldur            x16, [fp, #-0x20]
    // 0x879dd8: str             x16, [SP]
    // 0x879ddc: ldur            x2, [fp, #-0x18]
    // 0x879de0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x879de0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x879de4: r0 = GDT[cid_x0 + 0x126f4]()
    //     0x879de4: mov             x17, #0x26f4
    //     0x879de8: movk            x17, #1, lsl #16
    //     0x879dec: add             lr, x0, x17
    //     0x879df0: ldr             lr, [x21, lr, lsl #3]
    //     0x879df4: blr             lr
    // 0x879df8: b               #0x879e24
    // 0x879dfc: ldur            x1, [fp, #-0x10]
    // 0x879e00: r0 = LoadClassIdInstr(r1)
    //     0x879e00: ldur            x0, [x1, #-1]
    //     0x879e04: ubfx            x0, x0, #0xc, #0x14
    // 0x879e08: ldur            x2, [fp, #-0x18]
    // 0x879e0c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x879e0c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x879e10: r0 = GDT[cid_x0 + 0x126f4]()
    //     0x879e10: mov             x17, #0x26f4
    //     0x879e14: movk            x17, #1, lsl #16
    //     0x879e18: add             lr, x0, x17
    //     0x879e1c: ldr             lr, [x21, lr, lsl #3]
    //     0x879e20: blr             lr
    // 0x879e24: LeaveFrame
    //     0x879e24: mov             SP, fp
    //     0x879e28: ldp             fp, lr, [SP], #0x10
    // 0x879e2c: ret
    //     0x879e2c: ret             
    // 0x879e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879e30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879e34: b               #0x879d30
  }
  _ _isEnabled(/* No info */) {
    // ** addr: 0x879f4c, size: 0x12c
    // 0x879f4c: EnterFrame
    //     0x879f4c: stp             fp, lr, [SP, #-0x10]!
    //     0x879f50: mov             fp, SP
    // 0x879f54: AllocStack(0x28)
    //     0x879f54: sub             SP, SP, #0x28
    // 0x879f58: SetupParameters(Action<X0 bound Intent> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x879f58: mov             x5, x1
    //     0x879f5c: mov             x4, x2
    //     0x879f60: stur            x1, [fp, #-0x10]
    //     0x879f64: stur            x2, [fp, #-0x18]
    //     0x879f68: stur            x3, [fp, #-0x20]
    // 0x879f6c: CheckStackOverflow
    //     0x879f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879f70: cmp             SP, x16
    //     0x879f74: b.ls            #0x87a070
    // 0x879f78: LoadField: r6 = r5->field_7
    //     0x879f78: ldur            w6, [x5, #7]
    // 0x879f7c: DecompressPointer r6
    //     0x879f7c: add             x6, x6, HEAP, lsl #32
    // 0x879f80: mov             x0, x4
    // 0x879f84: mov             x2, x6
    // 0x879f88: stur            x6, [fp, #-8]
    // 0x879f8c: r1 = Null
    //     0x879f8c: mov             x1, NULL
    // 0x879f90: cmp             w2, NULL
    // 0x879f94: b.eq            #0x879fb0
    // 0x879f98: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x879f98: ldur            w4, [x2, #0x17]
    // 0x879f9c: DecompressPointer r4
    //     0x879f9c: add             x4, x4, HEAP, lsl #32
    // 0x879fa0: r8 = X0 bound Intent
    //     0x879fa0: ldr             x8, [PP, #0x4700]  ; [pp+0x4700] TypeParameter: X0 bound Intent
    // 0x879fa4: LoadField: r9 = r4->field_7
    //     0x879fa4: ldur            x9, [x4, #7]
    // 0x879fa8: r3 = Null
    //     0x879fa8: ldr             x3, [PP, #0x4760]  ; [pp+0x4760] Null
    // 0x879fac: blr             x9
    // 0x879fb0: ldur            x0, [fp, #-0x10]
    // 0x879fb4: ldur            x2, [fp, #-8]
    // 0x879fb8: r1 = Null
    //     0x879fb8: mov             x1, NULL
    // 0x879fbc: cmp             w0, NULL
    // 0x879fc0: b.eq            #0x87a000
    // 0x879fc4: branchIfSmi(r0, 0x87a000)
    //     0x879fc4: tbz             w0, #0, #0x87a000
    // 0x879fc8: r3 = SubtypeTestCache
    //     0x879fc8: ldr             x3, [PP, #0x4770]  ; [pp+0x4770] SubtypeTestCache
    // 0x879fcc: r30 = Subtype3TestCacheStub
    //     0x879fcc: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x879fd0: LoadField: r30 = r30->field_7
    //     0x879fd0: ldur            lr, [lr, #7]
    // 0x879fd4: blr             lr
    // 0x879fd8: cmp             w7, NULL
    // 0x879fdc: b.eq            #0x879fe8
    // 0x879fe0: tbnz            w7, #4, #0x87a000
    // 0x879fe4: b               #0x87a008
    // 0x879fe8: r8 = ContextAction<X0 bound Intent>
    //     0x879fe8: ldr             x8, [PP, #0x4778]  ; [pp+0x4778] Type: ContextAction<X0 bound Intent>
    // 0x879fec: r3 = SubtypeTestCache
    //     0x879fec: ldr             x3, [PP, #0x4780]  ; [pp+0x4780] SubtypeTestCache
    // 0x879ff0: r30 = InstanceOfStub
    //     0x879ff0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x879ff4: LoadField: r30 = r30->field_7
    //     0x879ff4: ldur            lr, [lr, #7]
    // 0x879ff8: blr             lr
    // 0x879ffc: b               #0x87a00c
    // 0x87a000: r0 = false
    //     0x87a000: add             x0, NULL, #0x30  ; false
    // 0x87a004: b               #0x87a00c
    // 0x87a008: r0 = true
    //     0x87a008: add             x0, NULL, #0x20  ; true
    // 0x87a00c: tbnz            w0, #4, #0x87a040
    // 0x87a010: ldur            x1, [fp, #-0x10]
    // 0x87a014: r0 = LoadClassIdInstr(r1)
    //     0x87a014: ldur            x0, [x1, #-1]
    //     0x87a018: ubfx            x0, x0, #0xc, #0x14
    // 0x87a01c: ldur            x16, [fp, #-0x20]
    // 0x87a020: str             x16, [SP]
    // 0x87a024: ldur            x2, [fp, #-0x18]
    // 0x87a028: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x87a028: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x87a02c: r0 = GDT[cid_x0 + 0xf96a]()
    //     0x87a02c: mov             x17, #0xf96a
    //     0x87a030: add             lr, x0, x17
    //     0x87a034: ldr             lr, [x21, lr, lsl #3]
    //     0x87a038: blr             lr
    // 0x87a03c: b               #0x87a064
    // 0x87a040: ldur            x1, [fp, #-0x10]
    // 0x87a044: r0 = LoadClassIdInstr(r1)
    //     0x87a044: ldur            x0, [x1, #-1]
    //     0x87a048: ubfx            x0, x0, #0xc, #0x14
    // 0x87a04c: ldur            x2, [fp, #-0x18]
    // 0x87a050: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x87a050: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x87a054: r0 = GDT[cid_x0 + 0xf96a]()
    //     0x87a054: mov             x17, #0xf96a
    //     0x87a058: add             lr, x0, x17
    //     0x87a05c: ldr             lr, [x21, lr, lsl #3]
    //     0x87a060: blr             lr
    // 0x87a064: LeaveFrame
    //     0x87a064: mov             SP, fp
    //     0x87a068: ldp             fp, lr, [SP], #0x10
    // 0x87a06c: ret
    //     0x87a06c: ret             
    // 0x87a070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87a070: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87a074: b               #0x879f78
  }
  _ _updateCallingAction(/* No info */) {
    // ** addr: 0xb14ad0, size: 0x78
    // 0xb14ad0: EnterFrame
    //     0xb14ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xb14ad4: mov             fp, SP
    // 0xb14ad8: AllocStack(0x10)
    //     0xb14ad8: sub             SP, SP, #0x10
    // 0xb14adc: SetupParameters(Action<X0 bound Intent> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb14adc: mov             x4, x1
    //     0xb14ae0: mov             x3, x2
    //     0xb14ae4: stur            x1, [fp, #-8]
    //     0xb14ae8: stur            x2, [fp, #-0x10]
    // 0xb14aec: LoadField: r2 = r4->field_7
    //     0xb14aec: ldur            w2, [x4, #7]
    // 0xb14af0: DecompressPointer r2
    //     0xb14af0: add             x2, x2, HEAP, lsl #32
    // 0xb14af4: mov             x0, x3
    // 0xb14af8: r1 = Null
    //     0xb14af8: mov             x1, NULL
    // 0xb14afc: r8 = Action<X0 bound Intent>?
    //     0xb14afc: add             x8, PP, #0xcd, lsl #12  ; [pp+0xcd890] Type: Action<X0 bound Intent>?
    //     0xb14b00: ldr             x8, [x8, #0x890]
    // 0xb14b04: LoadField: r9 = r8->field_7
    //     0xb14b04: ldur            x9, [x8, #7]
    // 0xb14b08: r3 = Null
    //     0xb14b08: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd898] Null
    //     0xb14b0c: ldr             x3, [x3, #0x898]
    // 0xb14b10: blr             x9
    // 0xb14b14: ldur            x0, [fp, #-0x10]
    // 0xb14b18: ldur            x1, [fp, #-8]
    // 0xb14b1c: StoreField: r1->field_f = r0
    //     0xb14b1c: stur            w0, [x1, #0xf]
    //     0xb14b20: ldurb           w16, [x1, #-1]
    //     0xb14b24: ldurb           w17, [x0, #-1]
    //     0xb14b28: and             x16, x17, x16, lsr #2
    //     0xb14b2c: tst             x16, HEAP, lsr #32
    //     0xb14b30: b.eq            #0xb14b38
    //     0xb14b34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb14b38: r0 = Null
    //     0xb14b38: mov             x0, NULL
    // 0xb14b3c: LeaveFrame
    //     0xb14b3c: mov             SP, fp
    //     0xb14b40: ldp             fp, lr, [SP], #0x10
    // 0xb14b44: ret
    //     0xb14b44: ret             
  }
  _ addActionListener(/* No info */) {
    // ** addr: 0xb22974, size: 0x3c
    // 0xb22974: EnterFrame
    //     0xb22974: stp             fp, lr, [SP, #-0x10]!
    //     0xb22978: mov             fp, SP
    // 0xb2297c: CheckStackOverflow
    //     0xb2297c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22980: cmp             SP, x16
    //     0xb22984: b.ls            #0xb229a8
    // 0xb22988: LoadField: r0 = r1->field_b
    //     0xb22988: ldur            w0, [x1, #0xb]
    // 0xb2298c: DecompressPointer r0
    //     0xb2298c: add             x0, x0, HEAP, lsl #32
    // 0xb22990: mov             x1, x0
    // 0xb22994: r0 = add()
    //     0xb22994: bl              #0x83b5e8  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xb22998: r0 = Null
    //     0xb22998: mov             x0, NULL
    // 0xb2299c: LeaveFrame
    //     0xb2299c: mov             SP, fp
    //     0xb229a0: ldp             fp, lr, [SP], #0x10
    // 0xb229a4: ret
    //     0xb229a4: ret             
    // 0xb229a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb229a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb229ac: b               #0xb22988
  }
  _ toKeyEventResult(/* No info */) {
    // ** addr: 0xb2fa48, size: 0xa0
    // 0xb2fa48: EnterFrame
    //     0xb2fa48: stp             fp, lr, [SP, #-0x10]!
    //     0xb2fa4c: mov             fp, SP
    // 0xb2fa50: AllocStack(0x10)
    //     0xb2fa50: sub             SP, SP, #0x10
    // 0xb2fa54: SetupParameters(Action<X0 bound Intent> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */)
    //     0xb2fa54: mov             x5, x1
    //     0xb2fa58: mov             x4, x2
    //     0xb2fa5c: stur            x1, [fp, #-8]
    //     0xb2fa60: stur            x2, [fp, #-0x10]
    // 0xb2fa64: CheckStackOverflow
    //     0xb2fa64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2fa68: cmp             SP, x16
    //     0xb2fa6c: b.ls            #0xb2fae0
    // 0xb2fa70: LoadField: r2 = r5->field_7
    //     0xb2fa70: ldur            w2, [x5, #7]
    // 0xb2fa74: DecompressPointer r2
    //     0xb2fa74: add             x2, x2, HEAP, lsl #32
    // 0xb2fa78: mov             x0, x4
    // 0xb2fa7c: r1 = Null
    //     0xb2fa7c: mov             x1, NULL
    // 0xb2fa80: cmp             w2, NULL
    // 0xb2fa84: b.eq            #0xb2faa4
    // 0xb2fa88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb2fa88: ldur            w4, [x2, #0x17]
    // 0xb2fa8c: DecompressPointer r4
    //     0xb2fa8c: add             x4, x4, HEAP, lsl #32
    // 0xb2fa90: r8 = X0 bound Intent
    //     0xb2fa90: ldr             x8, [PP, #0x4700]  ; [pp+0x4700] TypeParameter: X0 bound Intent
    // 0xb2fa94: LoadField: r9 = r4->field_7
    //     0xb2fa94: ldur            x9, [x4, #7]
    // 0xb2fa98: r3 = Null
    //     0xb2fa98: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd880] Null
    //     0xb2fa9c: ldr             x3, [x3, #0x880]
    // 0xb2faa0: blr             x9
    // 0xb2faa4: ldur            x1, [fp, #-8]
    // 0xb2faa8: r0 = LoadClassIdInstr(r1)
    //     0xb2faa8: ldur            x0, [x1, #-1]
    //     0xb2faac: ubfx            x0, x0, #0xc, #0x14
    // 0xb2fab0: ldur            x2, [fp, #-0x10]
    // 0xb2fab4: r0 = GDT[cid_x0 + 0xe92f]()
    //     0xb2fab4: mov             x17, #0xe92f
    //     0xb2fab8: add             lr, x0, x17
    //     0xb2fabc: ldr             lr, [x21, lr, lsl #3]
    //     0xb2fac0: blr             lr
    // 0xb2fac4: tbnz            w0, #4, #0xb2fad0
    // 0xb2fac8: r0 = Instance_KeyEventResult
    //     0xb2fac8: ldr             x0, [PP, #0x1d08]  ; [pp+0x1d08] Obj!KeyEventResult@12c32c1
    // 0xb2facc: b               #0xb2fad4
    // 0xb2fad0: r0 = Instance_KeyEventResult
    //     0xb2fad0: ldr             x0, [PP, #0x1d10]  ; [pp+0x1d10] Obj!KeyEventResult@12c32a1
    // 0xb2fad4: LeaveFrame
    //     0xb2fad4: mov             SP, fp
    //     0xb2fad8: ldp             fp, lr, [SP], #0x10
    // 0xb2fadc: ret
    //     0xb2fadc: ret             
    // 0xb2fae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2fae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2fae4: b               #0xb2fa70
  }
  _ removeActionListener(/* No info */) {
    // ** addr: 0xb579f4, size: 0x38
    // 0xb579f4: EnterFrame
    //     0xb579f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb579f8: mov             fp, SP
    // 0xb579fc: CheckStackOverflow
    //     0xb579fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb57a00: cmp             SP, x16
    //     0xb57a04: b.ls            #0xb57a24
    // 0xb57a08: LoadField: r0 = r1->field_b
    //     0xb57a08: ldur            w0, [x1, #0xb]
    // 0xb57a0c: DecompressPointer r0
    //     0xb57a0c: add             x0, x0, HEAP, lsl #32
    // 0xb57a10: mov             x1, x0
    // 0xb57a14: r0 = remove()
    //     0xb57a14: bl              #0xb57a2c  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xb57a18: LeaveFrame
    //     0xb57a18: mov             SP, fp
    //     0xb57a1c: ldp             fp, lr, [SP], #0x10
    // 0xb57a20: ret
    //     0xb57a20: ret             
    // 0xb57a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb57a24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb57a28: b               #0xb57a08
  }
  _ _makeOverridableAction(/* No info */) {
    // ** addr: 0xb5cd68, size: 0xd8
    // 0xb5cd68: EnterFrame
    //     0xb5cd68: stp             fp, lr, [SP, #-0x10]!
    //     0xb5cd6c: mov             fp, SP
    // 0xb5cd70: AllocStack(0x18)
    //     0xb5cd70: sub             SP, SP, #0x18
    // 0xb5cd74: SetupParameters(Action<X0 bound Intent> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb5cd74: mov             x0, x1
    //     0xb5cd78: stur            x1, [fp, #-8]
    //     0xb5cd7c: stur            x2, [fp, #-0x10]
    // 0xb5cd80: CheckStackOverflow
    //     0xb5cd80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5cd84: cmp             SP, x16
    //     0xb5cd88: b.ls            #0xb5ce38
    // 0xb5cd8c: LoadField: r1 = r0->field_7
    //     0xb5cd8c: ldur            w1, [x0, #7]
    // 0xb5cd90: DecompressPointer r1
    //     0xb5cd90: add             x1, x1, HEAP, lsl #32
    // 0xb5cd94: r0 = _OverridableAction()
    //     0xb5cd94: bl              #0xb5ce40  ; Allocate_OverridableActionStub -> _OverridableAction<X0 bound Intent> (size=0x1c)
    // 0xb5cd98: mov             x2, x0
    // 0xb5cd9c: ldur            x0, [fp, #-8]
    // 0xb5cda0: stur            x2, [fp, #-0x18]
    // 0xb5cda4: StoreField: r2->field_13 = r0
    //     0xb5cda4: stur            w0, [x2, #0x13]
    // 0xb5cda8: ldur            x0, [fp, #-0x10]
    // 0xb5cdac: ArrayStore: r2[0] = r0  ; List_4
    //     0xb5cdac: stur            w0, [x2, #0x17]
    // 0xb5cdb0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xb5cdb0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xb5cdb4: ldr             x1, [x1, #0x7a0]
    // 0xb5cdb8: r0 = ObserverList()
    //     0xb5cdb8: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xb5cdbc: mov             x3, x0
    // 0xb5cdc0: r0 = false
    //     0xb5cdc0: add             x0, NULL, #0x30  ; false
    // 0xb5cdc4: stur            x3, [fp, #-8]
    // 0xb5cdc8: StoreField: r3->field_f = r0
    //     0xb5cdc8: stur            w0, [x3, #0xf]
    // 0xb5cdcc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xb5cdd0: StoreField: r3->field_13 = r0
    //     0xb5cdd0: stur            w0, [x3, #0x13]
    // 0xb5cdd4: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xb5cdd4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xb5cdd8: ldr             x1, [x1, #0x7a0]
    // 0xb5cddc: r2 = 0
    //     0xb5cddc: mov             x2, #0
    // 0xb5cde0: r0 = _GrowableList()
    //     0xb5cde0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb5cde4: ldur            x1, [fp, #-8]
    // 0xb5cde8: StoreField: r1->field_b = r0
    //     0xb5cde8: stur            w0, [x1, #0xb]
    //     0xb5cdec: ldurb           w16, [x1, #-1]
    //     0xb5cdf0: ldurb           w17, [x0, #-1]
    //     0xb5cdf4: and             x16, x17, x16, lsr #2
    //     0xb5cdf8: tst             x16, HEAP, lsr #32
    //     0xb5cdfc: b.eq            #0xb5ce04
    //     0xb5ce00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb5ce04: mov             x0, x1
    // 0xb5ce08: ldur            x1, [fp, #-0x18]
    // 0xb5ce0c: StoreField: r1->field_b = r0
    //     0xb5ce0c: stur            w0, [x1, #0xb]
    //     0xb5ce10: ldurb           w16, [x1, #-1]
    //     0xb5ce14: ldurb           w17, [x0, #-1]
    //     0xb5ce18: and             x16, x17, x16, lsr #2
    //     0xb5ce1c: tst             x16, HEAP, lsr #32
    //     0xb5ce20: b.eq            #0xb5ce28
    //     0xb5ce24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb5ce28: mov             x0, x1
    // 0xb5ce2c: LeaveFrame
    //     0xb5ce2c: mov             SP, fp
    //     0xb5ce30: ldp             fp, lr, [SP], #0x10
    // 0xb5ce34: ret
    //     0xb5ce34: ret             
    // 0xb5ce38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5ce38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5ce3c: b               #0xb5cd8c
  }
  _ isEnabled(/* No info */) {
    // ** addr: 0xbfcf24, size: 0x44
    // 0xbfcf24: EnterFrame
    //     0xbfcf24: stp             fp, lr, [SP, #-0x10]!
    //     0xbfcf28: mov             fp, SP
    // 0xbfcf2c: CheckStackOverflow
    //     0xbfcf2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfcf30: cmp             SP, x16
    //     0xbfcf34: b.ls            #0xbfcf60
    // 0xbfcf38: r0 = LoadClassIdInstr(r1)
    //     0xbfcf38: ldur            x0, [x1, #-1]
    //     0xbfcf3c: ubfx            x0, x0, #0xc, #0x14
    // 0xbfcf40: r0 = GDT[cid_x0 + 0x121ca]()
    //     0xbfcf40: mov             x17, #0x21ca
    //     0xbfcf44: movk            x17, #1, lsl #16
    //     0xbfcf48: add             lr, x0, x17
    //     0xbfcf4c: ldr             lr, [x21, lr, lsl #3]
    //     0xbfcf50: blr             lr
    // 0xbfcf54: LeaveFrame
    //     0xbfcf54: mov             SP, fp
    //     0xbfcf58: ldp             fp, lr, [SP], #0x10
    // 0xbfcf5c: ret
    //     0xbfcf5c: ret             
    // 0xbfcf60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfcf60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfcf64: b               #0xbfcf38
  }
  _ consumesKey(/* No info */) {
    // ** addr: 0xcce660, size: 0x4c
    // 0xcce660: EnterFrame
    //     0xcce660: stp             fp, lr, [SP, #-0x10]!
    //     0xcce664: mov             fp, SP
    // 0xcce668: mov             x0, x2
    // 0xcce66c: LoadField: r2 = r1->field_7
    //     0xcce66c: ldur            w2, [x1, #7]
    // 0xcce670: DecompressPointer r2
    //     0xcce670: add             x2, x2, HEAP, lsl #32
    // 0xcce674: r1 = Null
    //     0xcce674: mov             x1, NULL
    // 0xcce678: cmp             w2, NULL
    // 0xcce67c: b.eq            #0xcce69c
    // 0xcce680: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcce680: ldur            w4, [x2, #0x17]
    // 0xcce684: DecompressPointer r4
    //     0xcce684: add             x4, x4, HEAP, lsl #32
    // 0xcce688: r8 = X0 bound Intent
    //     0xcce688: ldr             x8, [PP, #0x4700]  ; [pp+0x4700] TypeParameter: X0 bound Intent
    // 0xcce68c: LoadField: r9 = r4->field_7
    //     0xcce68c: ldur            x9, [x4, #7]
    // 0xcce690: r3 = Null
    //     0xcce690: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0620] Null
    //     0xcce694: ldr             x3, [x3, #0x620]
    // 0xcce698: blr             x9
    // 0xcce69c: r0 = true
    //     0xcce69c: add             x0, NULL, #0x20  ; true
    // 0xcce6a0: LeaveFrame
    //     0xcce6a0: mov             SP, fp
    //     0xcce6a4: ldp             fp, lr, [SP], #0x10
    // 0xcce6a8: ret
    //     0xcce6a8: ret             
  }
  factory _ Action.overridable(/* No info */) {
    // ** addr: 0xd5cb94, size: 0x4c
    // 0xd5cb94: EnterFrame
    //     0xd5cb94: stp             fp, lr, [SP, #-0x10]!
    //     0xd5cb98: mov             fp, SP
    // 0xd5cb9c: mov             x0, x1
    // 0xd5cba0: mov             x1, x3
    // 0xd5cba4: CheckStackOverflow
    //     0xd5cba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5cba8: cmp             SP, x16
    //     0xd5cbac: b.ls            #0xd5cbd8
    // 0xd5cbb0: r0 = LoadClassIdInstr(r1)
    //     0xd5cbb0: ldur            x0, [x1, #-1]
    //     0xd5cbb4: ubfx            x0, x0, #0xc, #0x14
    // 0xd5cbb8: r0 = GDT[cid_x0 + 0x120a4]()
    //     0xd5cbb8: mov             x17, #0x20a4
    //     0xd5cbbc: movk            x17, #1, lsl #16
    //     0xd5cbc0: add             lr, x0, x17
    //     0xd5cbc4: ldr             lr, [x21, lr, lsl #3]
    //     0xd5cbc8: blr             lr
    // 0xd5cbcc: LeaveFrame
    //     0xd5cbcc: mov             SP, fp
    //     0xd5cbd0: ldp             fp, lr, [SP], #0x10
    // 0xd5cbd4: ret
    //     0xd5cbd4: ret             
    // 0xd5cbd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5cbd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5cbdc: b               #0xd5cbb0
  }
}

// class id: 5319, size: 0x1c, field offset: 0x14
class _ContextActionToActionAdapter<X0 bound Intent> extends Action<X0 bound Intent> {

  _ _updateCallingAction(/* No info */) {
    // ** addr: 0xb1496c, size: 0x7c
    // 0xb1496c: EnterFrame
    //     0xb1496c: stp             fp, lr, [SP, #-0x10]!
    //     0xb14970: mov             fp, SP
    // 0xb14974: AllocStack(0x10)
    //     0xb14974: sub             SP, SP, #0x10
    // 0xb14978: SetupParameters(_ContextActionToActionAdapter<X0 bound Intent> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb14978: mov             x4, x1
    //     0xb1497c: mov             x3, x2
    //     0xb14980: stur            x1, [fp, #-8]
    //     0xb14984: stur            x2, [fp, #-0x10]
    // 0xb14988: CheckStackOverflow
    //     0xb14988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1498c: cmp             SP, x16
    //     0xb14990: b.ls            #0xb149e0
    // 0xb14994: LoadField: r2 = r4->field_7
    //     0xb14994: ldur            w2, [x4, #7]
    // 0xb14998: DecompressPointer r2
    //     0xb14998: add             x2, x2, HEAP, lsl #32
    // 0xb1499c: mov             x0, x3
    // 0xb149a0: r1 = Null
    //     0xb149a0: mov             x1, NULL
    // 0xb149a4: r8 = Action<X0 bound Intent>?
    //     0xb149a4: add             x8, PP, #0xcd, lsl #12  ; [pp+0xcd868] Type: Action<X0 bound Intent>?
    //     0xb149a8: ldr             x8, [x8, #0x868]
    // 0xb149ac: LoadField: r9 = r8->field_7
    //     0xb149ac: ldur            x9, [x8, #7]
    // 0xb149b0: r3 = Null
    //     0xb149b0: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd870] Null
    //     0xb149b4: ldr             x3, [x3, #0x870]
    // 0xb149b8: blr             x9
    // 0xb149bc: ldur            x0, [fp, #-8]
    // 0xb149c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb149c0: ldur            w1, [x0, #0x17]
    // 0xb149c4: DecompressPointer r1
    //     0xb149c4: add             x1, x1, HEAP, lsl #32
    // 0xb149c8: ldur            x2, [fp, #-0x10]
    // 0xb149cc: r0 = _updateCallingAction()
    //     0xb149cc: bl              #0xb14ad0  ; [package:flutter/src/widgets/actions.dart] Action::_updateCallingAction
    // 0xb149d0: r0 = Null
    //     0xb149d0: mov             x0, NULL
    // 0xb149d4: LeaveFrame
    //     0xb149d4: mov             SP, fp
    //     0xb149d8: ldp             fp, lr, [SP], #0x10
    // 0xb149dc: ret
    //     0xb149dc: ret             
    // 0xb149e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb149e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb149e4: b               #0xb14994
  }
  _ addActionListener(/* No info */) {
    // ** addr: 0xb22914, size: 0x60
    // 0xb22914: EnterFrame
    //     0xb22914: stp             fp, lr, [SP, #-0x10]!
    //     0xb22918: mov             fp, SP
    // 0xb2291c: AllocStack(0x10)
    //     0xb2291c: sub             SP, SP, #0x10
    // 0xb22920: SetupParameters(_ContextActionToActionAdapter<X0 bound Intent> this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb22920: mov             x3, x1
    //     0xb22924: mov             x0, x2
    //     0xb22928: stur            x1, [fp, #-8]
    //     0xb2292c: stur            x2, [fp, #-0x10]
    // 0xb22930: CheckStackOverflow
    //     0xb22930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22934: cmp             SP, x16
    //     0xb22938: b.ls            #0xb2296c
    // 0xb2293c: mov             x1, x3
    // 0xb22940: mov             x2, x0
    // 0xb22944: r0 = addActionListener()
    //     0xb22944: bl              #0xb22974  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0xb22948: ldur            x0, [fp, #-8]
    // 0xb2294c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2294c: ldur            w1, [x0, #0x17]
    // 0xb22950: DecompressPointer r1
    //     0xb22950: add             x1, x1, HEAP, lsl #32
    // 0xb22954: ldur            x2, [fp, #-0x10]
    // 0xb22958: r0 = addActionListener()
    //     0xb22958: bl              #0xb22974  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0xb2295c: r0 = Null
    //     0xb2295c: mov             x0, NULL
    // 0xb22960: LeaveFrame
    //     0xb22960: mov             SP, fp
    //     0xb22964: ldp             fp, lr, [SP], #0x10
    // 0xb22968: ret
    //     0xb22968: ret             
    // 0xb2296c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2296c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22970: b               #0xb2293c
  }
  _ invoke(/* No info */) {
    // ** addr: 0xb36254, size: 0x6c
    // 0xb36254: EnterFrame
    //     0xb36254: stp             fp, lr, [SP, #-0x10]!
    //     0xb36258: mov             fp, SP
    // 0xb3625c: AllocStack(0x8)
    //     0xb3625c: sub             SP, SP, #8
    // 0xb36260: CheckStackOverflow
    //     0xb36260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb36264: cmp             SP, x16
    //     0xb36268: b.ls            #0xb362b8
    // 0xb3626c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb3626c: ldur            w0, [x1, #0x17]
    // 0xb36270: DecompressPointer r0
    //     0xb36270: add             x0, x0, HEAP, lsl #32
    // 0xb36274: LoadField: r3 = r1->field_13
    //     0xb36274: ldur            w3, [x1, #0x13]
    // 0xb36278: DecompressPointer r3
    //     0xb36278: add             x3, x3, HEAP, lsl #32
    // 0xb3627c: r1 = LoadClassIdInstr(r0)
    //     0xb3627c: ldur            x1, [x0, #-1]
    //     0xb36280: ubfx            x1, x1, #0xc, #0x14
    // 0xb36284: str             x3, [SP]
    // 0xb36288: mov             x16, x0
    // 0xb3628c: mov             x0, x1
    // 0xb36290: mov             x1, x16
    // 0xb36294: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xb36294: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xb36298: r0 = GDT[cid_x0 + 0x126f4]()
    //     0xb36298: mov             x17, #0x26f4
    //     0xb3629c: movk            x17, #1, lsl #16
    //     0xb362a0: add             lr, x0, x17
    //     0xb362a4: ldr             lr, [x21, lr, lsl #3]
    //     0xb362a8: blr             lr
    // 0xb362ac: LeaveFrame
    //     0xb362ac: mov             SP, fp
    //     0xb362b0: ldp             fp, lr, [SP], #0x10
    // 0xb362b4: ret
    //     0xb362b4: ret             
    // 0xb362b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb362b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb362bc: b               #0xb3626c
  }
  _ removeActionListener(/* No info */) {
    // ** addr: 0xb57994, size: 0x60
    // 0xb57994: EnterFrame
    //     0xb57994: stp             fp, lr, [SP, #-0x10]!
    //     0xb57998: mov             fp, SP
    // 0xb5799c: AllocStack(0x10)
    //     0xb5799c: sub             SP, SP, #0x10
    // 0xb579a0: SetupParameters(_ContextActionToActionAdapter<X0 bound Intent> this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb579a0: mov             x3, x1
    //     0xb579a4: mov             x0, x2
    //     0xb579a8: stur            x1, [fp, #-8]
    //     0xb579ac: stur            x2, [fp, #-0x10]
    // 0xb579b0: CheckStackOverflow
    //     0xb579b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb579b4: cmp             SP, x16
    //     0xb579b8: b.ls            #0xb579ec
    // 0xb579bc: mov             x1, x3
    // 0xb579c0: mov             x2, x0
    // 0xb579c4: r0 = removeActionListener()
    //     0xb579c4: bl              #0xb579f4  ; [package:flutter/src/widgets/actions.dart] Action::removeActionListener
    // 0xb579c8: ldur            x0, [fp, #-8]
    // 0xb579cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb579cc: ldur            w1, [x0, #0x17]
    // 0xb579d0: DecompressPointer r1
    //     0xb579d0: add             x1, x1, HEAP, lsl #32
    // 0xb579d4: ldur            x2, [fp, #-0x10]
    // 0xb579d8: r0 = removeActionListener()
    //     0xb579d8: bl              #0xb579f4  ; [package:flutter/src/widgets/actions.dart] Action::removeActionListener
    // 0xb579dc: r0 = Null
    //     0xb579dc: mov             x0, NULL
    // 0xb579e0: LeaveFrame
    //     0xb579e0: mov             SP, fp
    //     0xb579e4: ldp             fp, lr, [SP], #0x10
    // 0xb579e8: ret
    //     0xb579e8: ret             
    // 0xb579ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb579ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb579f0: b               #0xb579bc
  }
  _ isEnabled(/* No info */) {
    // ** addr: 0xbfcebc, size: 0x68
    // 0xbfcebc: EnterFrame
    //     0xbfcebc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfcec0: mov             fp, SP
    // 0xbfcec4: AllocStack(0x8)
    //     0xbfcec4: sub             SP, SP, #8
    // 0xbfcec8: CheckStackOverflow
    //     0xbfcec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfcecc: cmp             SP, x16
    //     0xbfced0: b.ls            #0xbfcf1c
    // 0xbfced4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbfced4: ldur            w0, [x1, #0x17]
    // 0xbfced8: DecompressPointer r0
    //     0xbfced8: add             x0, x0, HEAP, lsl #32
    // 0xbfcedc: LoadField: r3 = r1->field_13
    //     0xbfcedc: ldur            w3, [x1, #0x13]
    // 0xbfcee0: DecompressPointer r3
    //     0xbfcee0: add             x3, x3, HEAP, lsl #32
    // 0xbfcee4: r1 = LoadClassIdInstr(r0)
    //     0xbfcee4: ldur            x1, [x0, #-1]
    //     0xbfcee8: ubfx            x1, x1, #0xc, #0x14
    // 0xbfceec: str             x3, [SP]
    // 0xbfcef0: mov             x16, x0
    // 0xbfcef4: mov             x0, x1
    // 0xbfcef8: mov             x1, x16
    // 0xbfcefc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xbfcefc: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xbfcf00: r0 = GDT[cid_x0 + 0xf96a]()
    //     0xbfcf00: mov             x17, #0xf96a
    //     0xbfcf04: add             lr, x0, x17
    //     0xbfcf08: ldr             lr, [x21, lr, lsl #3]
    //     0xbfcf0c: blr             lr
    // 0xbfcf10: LeaveFrame
    //     0xbfcf10: mov             SP, fp
    //     0xbfcf14: ldp             fp, lr, [SP], #0x10
    // 0xbfcf18: ret
    //     0xbfcf18: ret             
    // 0xbfcf1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfcf1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfcf20: b               #0xbfced4
  }
  _ consumesKey(/* No info */) {
    // ** addr: 0xcce5bc, size: 0xa4
    // 0xcce5bc: EnterFrame
    //     0xcce5bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcce5c0: mov             fp, SP
    // 0xcce5c4: AllocStack(0x10)
    //     0xcce5c4: sub             SP, SP, #0x10
    // 0xcce5c8: SetupParameters(_ContextActionToActionAdapter<X0 bound Intent> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xcce5c8: mov             x4, x1
    //     0xcce5cc: mov             x3, x2
    //     0xcce5d0: stur            x1, [fp, #-8]
    //     0xcce5d4: stur            x2, [fp, #-0x10]
    // 0xcce5d8: LoadField: r2 = r4->field_7
    //     0xcce5d8: ldur            w2, [x4, #7]
    // 0xcce5dc: DecompressPointer r2
    //     0xcce5dc: add             x2, x2, HEAP, lsl #32
    // 0xcce5e0: mov             x0, x3
    // 0xcce5e4: r1 = Null
    //     0xcce5e4: mov             x1, NULL
    // 0xcce5e8: cmp             w2, NULL
    // 0xcce5ec: b.eq            #0xcce610
    // 0xcce5f0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcce5f0: ldur            w4, [x2, #0x17]
    // 0xcce5f4: DecompressPointer r4
    //     0xcce5f4: add             x4, x4, HEAP, lsl #32
    // 0xcce5f8: r8 = X0 bound Intent
    //     0xcce5f8: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd05f8] TypeParameter: X0 bound Intent
    //     0xcce5fc: ldr             x8, [x8, #0x5f8]
    // 0xcce600: LoadField: r9 = r4->field_7
    //     0xcce600: ldur            x9, [x4, #7]
    // 0xcce604: r3 = Null
    //     0xcce604: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0600] Null
    //     0xcce608: ldr             x3, [x3, #0x600]
    // 0xcce60c: blr             x9
    // 0xcce610: ldur            x0, [fp, #-8]
    // 0xcce614: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcce614: ldur            w1, [x0, #0x17]
    // 0xcce618: DecompressPointer r1
    //     0xcce618: add             x1, x1, HEAP, lsl #32
    // 0xcce61c: LoadField: r2 = r1->field_7
    //     0xcce61c: ldur            w2, [x1, #7]
    // 0xcce620: DecompressPointer r2
    //     0xcce620: add             x2, x2, HEAP, lsl #32
    // 0xcce624: ldur            x0, [fp, #-0x10]
    // 0xcce628: r1 = Null
    //     0xcce628: mov             x1, NULL
    // 0xcce62c: cmp             w2, NULL
    // 0xcce630: b.eq            #0xcce650
    // 0xcce634: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcce634: ldur            w4, [x2, #0x17]
    // 0xcce638: DecompressPointer r4
    //     0xcce638: add             x4, x4, HEAP, lsl #32
    // 0xcce63c: r8 = X0 bound Intent
    //     0xcce63c: ldr             x8, [PP, #0x4700]  ; [pp+0x4700] TypeParameter: X0 bound Intent
    // 0xcce640: LoadField: r9 = r4->field_7
    //     0xcce640: ldur            x9, [x4, #7]
    // 0xcce644: r3 = Null
    //     0xcce644: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0610] Null
    //     0xcce648: ldr             x3, [x3, #0x610]
    // 0xcce64c: blr             x9
    // 0xcce650: r0 = true
    //     0xcce650: add             x0, NULL, #0x20  ; true
    // 0xcce654: LeaveFrame
    //     0xcce654: mov             SP, fp
    //     0xcce658: ldp             fp, lr, [SP], #0x10
    // 0xcce65c: ret
    //     0xcce65c: ret             
  }
}

// class id: 5320, size: 0x18, field offset: 0x14
class DoNothingAction extends Action<dynamic> {
}

// class id: 5321, size: 0x14, field offset: 0x14
class VoidCallbackAction extends Action<dynamic> {

  _ invoke(/* No info */) {
    // ** addr: 0xb361e8, size: 0x48
    // 0xb361e8: EnterFrame
    //     0xb361e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb361ec: mov             fp, SP
    // 0xb361f0: AllocStack(0x8)
    //     0xb361f0: sub             SP, SP, #8
    // 0xb361f4: CheckStackOverflow
    //     0xb361f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb361f8: cmp             SP, x16
    //     0xb361fc: b.ls            #0xb36228
    // 0xb36200: LoadField: r0 = r2->field_7
    //     0xb36200: ldur            w0, [x2, #7]
    // 0xb36204: DecompressPointer r0
    //     0xb36204: add             x0, x0, HEAP, lsl #32
    // 0xb36208: str             x0, [SP]
    // 0xb3620c: ClosureCall
    //     0xb3620c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb36210: ldur            x2, [x0, #0x1f]
    //     0xb36214: blr             x2
    // 0xb36218: r0 = Null
    //     0xb36218: mov             x0, NULL
    // 0xb3621c: LeaveFrame
    //     0xb3621c: mov             SP, fp
    //     0xb36220: ldp             fp, lr, [SP], #0x10
    // 0xb36224: ret
    //     0xb36224: ret             
    // 0xb36228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb36228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3622c: b               #0xb36200
  }
}

// class id: 5322, size: 0x18, field offset: 0x14
class CallbackAction<X0 bound Intent> extends Action<X0 bound Intent> {

  _ invoke(/* No info */) {
    // ** addr: 0xb36150, size: 0x98
    // 0xb36150: EnterFrame
    //     0xb36150: stp             fp, lr, [SP, #-0x10]!
    //     0xb36154: mov             fp, SP
    // 0xb36158: AllocStack(0x20)
    //     0xb36158: sub             SP, SP, #0x20
    // 0xb3615c: SetupParameters(CallbackAction<X0 bound Intent> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb3615c: mov             x4, x1
    //     0xb36160: mov             x3, x2
    //     0xb36164: stur            x1, [fp, #-8]
    //     0xb36168: stur            x2, [fp, #-0x10]
    // 0xb3616c: CheckStackOverflow
    //     0xb3616c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb36170: cmp             SP, x16
    //     0xb36174: b.ls            #0xb361e0
    // 0xb36178: LoadField: r2 = r4->field_7
    //     0xb36178: ldur            w2, [x4, #7]
    // 0xb3617c: DecompressPointer r2
    //     0xb3617c: add             x2, x2, HEAP, lsl #32
    // 0xb36180: mov             x0, x3
    // 0xb36184: r1 = Null
    //     0xb36184: mov             x1, NULL
    // 0xb36188: cmp             w2, NULL
    // 0xb3618c: b.eq            #0xb361b0
    // 0xb36190: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb36190: ldur            w4, [x2, #0x17]
    // 0xb36194: DecompressPointer r4
    //     0xb36194: add             x4, x4, HEAP, lsl #32
    // 0xb36198: r8 = X0 bound Intent
    //     0xb36198: add             x8, PP, #0x99, lsl #12  ; [pp+0x99f00] TypeParameter: X0 bound Intent
    //     0xb3619c: ldr             x8, [x8, #0xf00]
    // 0xb361a0: LoadField: r9 = r4->field_7
    //     0xb361a0: ldur            x9, [x4, #7]
    // 0xb361a4: r3 = Null
    //     0xb361a4: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f08] Null
    //     0xb361a8: ldr             x3, [x3, #0xf08]
    // 0xb361ac: blr             x9
    // 0xb361b0: ldur            x0, [fp, #-8]
    // 0xb361b4: LoadField: r1 = r0->field_13
    //     0xb361b4: ldur            w1, [x0, #0x13]
    // 0xb361b8: DecompressPointer r1
    //     0xb361b8: add             x1, x1, HEAP, lsl #32
    // 0xb361bc: ldur            x16, [fp, #-0x10]
    // 0xb361c0: stp             x16, x1, [SP]
    // 0xb361c4: mov             x0, x1
    // 0xb361c8: ClosureCall
    //     0xb361c8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb361cc: ldur            x2, [x0, #0x1f]
    //     0xb361d0: blr             x2
    // 0xb361d4: LeaveFrame
    //     0xb361d4: mov             SP, fp
    //     0xb361d8: ldp             fp, lr, [SP], #0x10
    // 0xb361dc: ret
    //     0xb361dc: ret             
    // 0xb361e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb361e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb361e4: b               #0xb36178
  }
}

// class id: 5324, size: 0x14, field offset: 0x14
abstract class DismissAction extends Action<dynamic> {
}

// class id: 5327, size: 0x14, field offset: 0x14
abstract class _OverridableActionMixin<X0 bound Intent> extends Action<X0 bound Intent> {
}

// class id: 5328, size: 0x14, field offset: 0x14
abstract class ContextAction<X0 bound Intent> extends Action<X0 bound Intent> {

  _ _makeOverridableAction(/* No info */) {
    // ** addr: 0xb5cc84, size: 0xd8
    // 0xb5cc84: EnterFrame
    //     0xb5cc84: stp             fp, lr, [SP, #-0x10]!
    //     0xb5cc88: mov             fp, SP
    // 0xb5cc8c: AllocStack(0x18)
    //     0xb5cc8c: sub             SP, SP, #0x18
    // 0xb5cc90: SetupParameters(ContextAction<X0 bound Intent> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb5cc90: mov             x0, x1
    //     0xb5cc94: stur            x1, [fp, #-8]
    //     0xb5cc98: stur            x2, [fp, #-0x10]
    // 0xb5cc9c: CheckStackOverflow
    //     0xb5cc9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5cca0: cmp             SP, x16
    //     0xb5cca4: b.ls            #0xb5cd54
    // 0xb5cca8: LoadField: r1 = r0->field_7
    //     0xb5cca8: ldur            w1, [x0, #7]
    // 0xb5ccac: DecompressPointer r1
    //     0xb5ccac: add             x1, x1, HEAP, lsl #32
    // 0xb5ccb0: r0 = _OverridableContextAction()
    //     0xb5ccb0: bl              #0xb5cd5c  ; Allocate_OverridableContextActionStub -> _OverridableContextAction<X0 bound Intent> (size=0x1c)
    // 0xb5ccb4: mov             x2, x0
    // 0xb5ccb8: ldur            x0, [fp, #-8]
    // 0xb5ccbc: stur            x2, [fp, #-0x18]
    // 0xb5ccc0: StoreField: r2->field_13 = r0
    //     0xb5ccc0: stur            w0, [x2, #0x13]
    // 0xb5ccc4: ldur            x0, [fp, #-0x10]
    // 0xb5ccc8: ArrayStore: r2[0] = r0  ; List_4
    //     0xb5ccc8: stur            w0, [x2, #0x17]
    // 0xb5cccc: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xb5cccc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xb5ccd0: ldr             x1, [x1, #0x7a0]
    // 0xb5ccd4: r0 = ObserverList()
    //     0xb5ccd4: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xb5ccd8: mov             x3, x0
    // 0xb5ccdc: r0 = false
    //     0xb5ccdc: add             x0, NULL, #0x30  ; false
    // 0xb5cce0: stur            x3, [fp, #-8]
    // 0xb5cce4: StoreField: r3->field_f = r0
    //     0xb5cce4: stur            w0, [x3, #0xf]
    // 0xb5cce8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xb5ccec: StoreField: r3->field_13 = r0
    //     0xb5ccec: stur            w0, [x3, #0x13]
    // 0xb5ccf0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xb5ccf0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xb5ccf4: ldr             x1, [x1, #0x7a0]
    // 0xb5ccf8: r2 = 0
    //     0xb5ccf8: mov             x2, #0
    // 0xb5ccfc: r0 = _GrowableList()
    //     0xb5ccfc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb5cd00: ldur            x1, [fp, #-8]
    // 0xb5cd04: StoreField: r1->field_b = r0
    //     0xb5cd04: stur            w0, [x1, #0xb]
    //     0xb5cd08: ldurb           w16, [x1, #-1]
    //     0xb5cd0c: ldurb           w17, [x0, #-1]
    //     0xb5cd10: and             x16, x17, x16, lsr #2
    //     0xb5cd14: tst             x16, HEAP, lsr #32
    //     0xb5cd18: b.eq            #0xb5cd20
    //     0xb5cd1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb5cd20: mov             x0, x1
    // 0xb5cd24: ldur            x1, [fp, #-0x18]
    // 0xb5cd28: StoreField: r1->field_b = r0
    //     0xb5cd28: stur            w0, [x1, #0xb]
    //     0xb5cd2c: ldurb           w16, [x1, #-1]
    //     0xb5cd30: ldurb           w17, [x0, #-1]
    //     0xb5cd34: and             x16, x17, x16, lsr #2
    //     0xb5cd38: tst             x16, HEAP, lsr #32
    //     0xb5cd3c: b.eq            #0xb5cd44
    //     0xb5cd40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb5cd44: mov             x0, x1
    // 0xb5cd48: LeaveFrame
    //     0xb5cd48: mov             SP, fp
    //     0xb5cd4c: ldp             fp, lr, [SP], #0x10
    // 0xb5cd50: ret
    //     0xb5cd50: ret             
    // 0xb5cd54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5cd54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5cd58: b               #0xb5cca8
  }
  _ isEnabled(/* No info */) {
    // ** addr: 0xbfc928, size: 0x80
    // 0xbfc928: EnterFrame
    //     0xbfc928: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc92c: mov             fp, SP
    // 0xbfc930: AllocStack(0x10)
    //     0xbfc930: sub             SP, SP, #0x10
    // 0xbfc934: SetupParameters(ContextAction<X0 bound Intent> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xbfc934: mov             x5, x1
    //     0xbfc938: mov             x3, x2
    //     0xbfc93c: stur            x1, [fp, #-8]
    //     0xbfc940: stur            x2, [fp, #-0x10]
    // 0xbfc944: CheckStackOverflow
    //     0xbfc944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfc948: cmp             SP, x16
    //     0xbfc94c: b.ls            #0xbfc9a0
    // 0xbfc950: LoadField: r2 = r5->field_7
    //     0xbfc950: ldur            w2, [x5, #7]
    // 0xbfc954: DecompressPointer r2
    //     0xbfc954: add             x2, x2, HEAP, lsl #32
    // 0xbfc958: mov             x0, x3
    // 0xbfc95c: r1 = Null
    //     0xbfc95c: mov             x1, NULL
    // 0xbfc960: cmp             w2, NULL
    // 0xbfc964: b.eq            #0xbfc988
    // 0xbfc968: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfc968: ldur            w4, [x2, #0x17]
    // 0xbfc96c: DecompressPointer r4
    //     0xbfc96c: add             x4, x4, HEAP, lsl #32
    // 0xbfc970: r8 = X0 bound Intent
    //     0xbfc970: add             x8, PP, #0x85, lsl #12  ; [pp+0x85178] TypeParameter: X0 bound Intent
    //     0xbfc974: ldr             x8, [x8, #0x178]
    // 0xbfc978: LoadField: r9 = r4->field_7
    //     0xbfc978: ldur            x9, [x4, #7]
    // 0xbfc97c: r3 = Null
    //     0xbfc97c: add             x3, PP, #0x85, lsl #12  ; [pp+0x85180] Null
    //     0xbfc980: ldr             x3, [x3, #0x180]
    // 0xbfc984: blr             x9
    // 0xbfc988: ldur            x1, [fp, #-8]
    // 0xbfc98c: ldur            x2, [fp, #-0x10]
    // 0xbfc990: r0 = isEnabled()
    //     0xbfc990: bl              #0xbfcf24  ; [package:flutter/src/widgets/actions.dart] Action::isEnabled
    // 0xbfc994: LeaveFrame
    //     0xbfc994: mov             SP, fp
    //     0xbfc998: ldp             fp, lr, [SP], #0x10
    // 0xbfc99c: ret
    //     0xbfc99c: ret             
    // 0xbfc9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfc9a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfc9a4: b               #0xbfc950
  }
}

// class id: 5338, size: 0x1c, field offset: 0x14
class PrioritizedAction extends ContextAction<dynamic> {

  late Action<dynamic> _selectedAction; // offset: 0x14
  late Intent _selectedIntent; // offset: 0x18

  _ invoke(/* No info */) {
    // ** addr: 0xb300b8, size: 0x98
    // 0xb300b8: EnterFrame
    //     0xb300b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb300bc: mov             fp, SP
    // 0xb300c0: AllocStack(0x8)
    //     0xb300c0: sub             SP, SP, #8
    // 0xb300c4: SetupParameters(PrioritizedAction this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xb300c4: mov             x0, x2
    //     0xb300c8: mov             x5, x1
    //     0xb300cc: mov             x3, x2
    //     0xb300d0: stur            x1, [fp, #-8]
    // 0xb300d4: r2 = Null
    //     0xb300d4: mov             x2, NULL
    // 0xb300d8: r1 = Null
    //     0xb300d8: mov             x1, NULL
    // 0xb300dc: r4 = 60
    //     0xb300dc: mov             x4, #0x3c
    // 0xb300e0: branchIfSmi(r0, 0xb300ec)
    //     0xb300e0: tbz             w0, #0, #0xb300ec
    // 0xb300e4: r4 = LoadClassIdInstr(r0)
    //     0xb300e4: ldur            x4, [x0, #-1]
    //     0xb300e8: ubfx            x4, x4, #0xc, #0x14
    // 0xb300ec: r8 = PrioritizedIntents
    //     0xb300ec: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3438] Type: PrioritizedIntents
    //     0xb300f0: ldr             x8, [x8, #0x438]
    // 0xb300f4: r3 = Null
    //     0xb300f4: add             x3, PP, #0xad, lsl #12  ; [pp+0xadee0] Null
    //     0xb300f8: ldr             x3, [x3, #0xee0]
    // 0xb300fc: r0 = PrioritizedIntents()
    //     0xb300fc: bl              #0xb30150  ; IsType_PrioritizedIntents_Stub
    // 0xb30100: ldur            x0, [fp, #-8]
    // 0xb30104: LoadField: r1 = r0->field_13
    //     0xb30104: ldur            w1, [x0, #0x13]
    // 0xb30108: DecompressPointer r1
    //     0xb30108: add             x1, x1, HEAP, lsl #32
    // 0xb3010c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb30110: cmp             w1, w16
    // 0xb30114: b.eq            #0xb30138
    // 0xb30118: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb30118: ldur            w1, [x0, #0x17]
    // 0xb3011c: DecompressPointer r1
    //     0xb3011c: add             x1, x1, HEAP, lsl #32
    // 0xb30120: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb30124: cmp             w1, w16
    // 0xb30128: b.eq            #0xb30144
    // 0xb3012c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xb3012c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xb30130: r0 = Throw()
    //     0xb30130: bl              #0x13ddb2c  ; ThrowStub
    // 0xb30134: brk             #0
    // 0xb30138: r9 = _selectedAction
    //     0xb30138: add             x9, PP, #0xad, lsl #12  ; [pp+0xadef0] Field <PrioritizedAction._selectedAction@66441002>: late (offset: 0x14)
    //     0xb3013c: ldr             x9, [x9, #0xef0]
    // 0xb30140: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb30140: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb30144: r9 = _selectedIntent
    //     0xb30144: add             x9, PP, #0xad, lsl #12  ; [pp+0xadef8] Field <PrioritizedAction._selectedIntent@66441002>: late (offset: 0x18)
    //     0xb30148: ldr             x9, [x9, #0xef8]
    // 0xb3014c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb3014c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ isEnabled(/* No info */) {
    // ** addr: 0xbfc87c, size: 0xac
    // 0xbfc87c: EnterFrame
    //     0xbfc87c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfc880: mov             fp, SP
    // 0xbfc884: mov             x0, x2
    // 0xbfc888: mov             x5, x1
    // 0xbfc88c: mov             x3, x2
    // 0xbfc890: r2 = Null
    //     0xbfc890: mov             x2, NULL
    // 0xbfc894: r1 = Null
    //     0xbfc894: mov             x1, NULL
    // 0xbfc898: r4 = 60
    //     0xbfc898: mov             x4, #0x3c
    // 0xbfc89c: branchIfSmi(r0, 0xbfc8a8)
    //     0xbfc89c: tbz             w0, #0, #0xbfc8a8
    // 0xbfc8a0: r4 = LoadClassIdInstr(r0)
    //     0xbfc8a0: ldur            x4, [x0, #-1]
    //     0xbfc8a4: ubfx            x4, x4, #0xc, #0x14
    // 0xbfc8a8: r8 = PrioritizedIntents
    //     0xbfc8a8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3438] Type: PrioritizedIntents
    //     0xbfc8ac: ldr             x8, [x8, #0x438]
    // 0xbfc8b0: r3 = Null
    //     0xbfc8b0: add             x3, PP, #0xad, lsl #12  ; [pp+0xadf00] Null
    //     0xbfc8b4: ldr             x3, [x3, #0xf00]
    // 0xbfc8b8: r0 = PrioritizedIntents()
    //     0xbfc8b8: bl              #0xb30150  ; IsType_PrioritizedIntents_Stub
    // 0xbfc8bc: r0 = LoadStaticField(0x6a0)
    //     0xbfc8bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xbfc8c0: ldr             x0, [x0, #0xd40]
    // 0xbfc8c4: cmp             w0, NULL
    // 0xbfc8c8: b.eq            #0xbfc920
    // 0xbfc8cc: LoadField: r1 = r0->field_ef
    //     0xbfc8cc: ldur            w1, [x0, #0xef]
    // 0xbfc8d0: DecompressPointer r1
    //     0xbfc8d0: add             x1, x1, HEAP, lsl #32
    // 0xbfc8d4: cmp             w1, NULL
    // 0xbfc8d8: b.eq            #0xbfc924
    // 0xbfc8dc: LoadField: r0 = r1->field_13
    //     0xbfc8dc: ldur            w0, [x1, #0x13]
    // 0xbfc8e0: DecompressPointer r0
    //     0xbfc8e0: add             x0, x0, HEAP, lsl #32
    // 0xbfc8e4: LoadField: r1 = r0->field_2b
    //     0xbfc8e4: ldur            w1, [x0, #0x2b]
    // 0xbfc8e8: DecompressPointer r1
    //     0xbfc8e8: add             x1, x1, HEAP, lsl #32
    // 0xbfc8ec: cmp             w1, NULL
    // 0xbfc8f0: b.eq            #0xbfc904
    // 0xbfc8f4: LoadField: r0 = r1->field_33
    //     0xbfc8f4: ldur            w0, [x1, #0x33]
    // 0xbfc8f8: DecompressPointer r0
    //     0xbfc8f8: add             x0, x0, HEAP, lsl #32
    // 0xbfc8fc: cmp             w0, NULL
    // 0xbfc900: b.ne            #0xbfc914
    // 0xbfc904: r0 = false
    //     0xbfc904: add             x0, NULL, #0x30  ; false
    // 0xbfc908: LeaveFrame
    //     0xbfc908: mov             SP, fp
    //     0xbfc90c: ldp             fp, lr, [SP], #0x10
    // 0xbfc910: ret
    //     0xbfc910: ret             
    // 0xbfc914: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbfc914: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbfc918: r0 = Throw()
    //     0xbfc918: bl              #0x13ddb2c  ; ThrowStub
    // 0xbfc91c: brk             #0
    // 0xbfc920: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfc920: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfc924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfc924: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5340, size: 0x1c, field offset: 0x14
class _OverridableContextAction<X0 bound Intent> extends _MixinApplication183&ContextAction&_OverridableActionMixin<X0 bound Intent> {
}

// class id: 5341, size: 0x1c, field offset: 0x14
class _OverridableAction<X0 bound Intent> extends _MixinApplication183&ContextAction&_OverridableActionMixin<X0 bound Intent> {
}

// class id: 5450, size: 0x24, field offset: 0x14
class _FocusableActionDetectorState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xe01c64, size: 0x234
    // 0xe01c64: EnterFrame
    //     0xe01c64: stp             fp, lr, [SP, #-0x10]!
    //     0xe01c68: mov             fp, SP
    // 0xe01c6c: AllocStack(0x48)
    //     0xe01c6c: sub             SP, SP, #0x48
    // 0xe01c70: SetupParameters(_FocusableActionDetectorState this /* r1 => r0, fp-0x20 */)
    //     0xe01c70: mov             x0, x1
    //     0xe01c74: stur            x1, [fp, #-0x20]
    // 0xe01c78: CheckStackOverflow
    //     0xe01c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01c7c: cmp             SP, x16
    //     0xe01c80: b.ls            #0xe01e88
    // 0xe01c84: LoadField: r2 = r0->field_1f
    //     0xe01c84: ldur            w2, [x0, #0x1f]
    // 0xe01c88: DecompressPointer r2
    //     0xe01c88: add             x2, x2, HEAP, lsl #32
    // 0xe01c8c: stur            x2, [fp, #-0x18]
    // 0xe01c90: LoadField: r1 = r0->field_b
    //     0xe01c90: ldur            w1, [x0, #0xb]
    // 0xe01c94: DecompressPointer r1
    //     0xe01c94: add             x1, x1, HEAP, lsl #32
    // 0xe01c98: cmp             w1, NULL
    // 0xe01c9c: b.eq            #0xe01e90
    // 0xe01ca0: LoadField: r3 = r1->field_33
    //     0xe01ca0: ldur            w3, [x1, #0x33]
    // 0xe01ca4: DecompressPointer r3
    //     0xe01ca4: add             x3, x3, HEAP, lsl #32
    // 0xe01ca8: stur            x3, [fp, #-0x10]
    // 0xe01cac: LoadField: r4 = r1->field_f
    //     0xe01cac: ldur            w4, [x1, #0xf]
    // 0xe01cb0: DecompressPointer r4
    //     0xe01cb0: add             x4, x4, HEAP, lsl #32
    // 0xe01cb4: mov             x1, x0
    // 0xe01cb8: stur            x4, [fp, #-8]
    // 0xe01cbc: r0 = _canRequestFocus()
    //     0xe01cbc: bl              #0xe01e98  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_canRequestFocus
    // 0xe01cc0: ldur            x2, [fp, #-0x20]
    // 0xe01cc4: stur            x0, [fp, #-0x40]
    // 0xe01cc8: LoadField: r1 = r2->field_b
    //     0xe01cc8: ldur            w1, [x2, #0xb]
    // 0xe01ccc: DecompressPointer r1
    //     0xe01ccc: add             x1, x1, HEAP, lsl #32
    // 0xe01cd0: stur            x1, [fp, #-0x38]
    // 0xe01cd4: cmp             w1, NULL
    // 0xe01cd8: b.eq            #0xe01e94
    // 0xe01cdc: LoadField: r3 = r1->field_37
    //     0xe01cdc: ldur            w3, [x1, #0x37]
    // 0xe01ce0: DecompressPointer r3
    //     0xe01ce0: add             x3, x3, HEAP, lsl #32
    // 0xe01ce4: stur            x3, [fp, #-0x30]
    // 0xe01ce8: LoadField: r4 = r1->field_3b
    //     0xe01ce8: ldur            w4, [x1, #0x3b]
    // 0xe01cec: DecompressPointer r4
    //     0xe01cec: add             x4, x4, HEAP, lsl #32
    // 0xe01cf0: stur            x4, [fp, #-0x28]
    // 0xe01cf4: r0 = Focus()
    //     0xe01cf4: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xe01cf8: mov             x3, x0
    // 0xe01cfc: ldur            x0, [fp, #-0x28]
    // 0xe01d00: stur            x3, [fp, #-0x48]
    // 0xe01d04: StoreField: r3->field_f = r0
    //     0xe01d04: stur            w0, [x3, #0xf]
    // 0xe01d08: ldur            x0, [fp, #-8]
    // 0xe01d0c: StoreField: r3->field_13 = r0
    //     0xe01d0c: stur            w0, [x3, #0x13]
    // 0xe01d10: r0 = false
    //     0xe01d10: add             x0, NULL, #0x30  ; false
    // 0xe01d14: ArrayStore: r3[0] = r0  ; List_4
    //     0xe01d14: stur            w0, [x3, #0x17]
    // 0xe01d18: ldur            x2, [fp, #-0x20]
    // 0xe01d1c: r1 = Function '_handleFocusChange@66441002':.
    //     0xe01d1c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f60] AnonymousClosure: (0xe08d7c), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleFocusChange (0xe08db8)
    //     0xe01d20: ldr             x1, [x1, #0xf60]
    // 0xe01d24: r0 = AllocateClosure()
    //     0xe01d24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe01d28: mov             x1, x0
    // 0xe01d2c: ldur            x0, [fp, #-0x48]
    // 0xe01d30: StoreField: r0->field_1b = r1
    //     0xe01d30: stur            w1, [x0, #0x1b]
    // 0xe01d34: ldur            x1, [fp, #-0x30]
    // 0xe01d38: StoreField: r0->field_37 = r1
    //     0xe01d38: stur            w1, [x0, #0x37]
    // 0xe01d3c: ldur            x1, [fp, #-0x40]
    // 0xe01d40: StoreField: r0->field_27 = r1
    //     0xe01d40: stur            w1, [x0, #0x27]
    // 0xe01d44: r3 = true
    //     0xe01d44: add             x3, NULL, #0x20  ; true
    // 0xe01d48: StoreField: r0->field_2f = r3
    //     0xe01d48: stur            w3, [x0, #0x2f]
    // 0xe01d4c: StoreField: r0->field_33 = r3
    //     0xe01d4c: stur            w3, [x0, #0x33]
    // 0xe01d50: ldur            x2, [fp, #-0x20]
    // 0xe01d54: r1 = Function '_handleMouseEnter@66441002':.
    //     0xe01d54: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f68] AnonymousClosure: (0xe08cc8), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleMouseEnter (0xe08d04)
    //     0xe01d58: ldr             x1, [x1, #0xf68]
    // 0xe01d5c: r0 = AllocateClosure()
    //     0xe01d5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe01d60: stur            x0, [fp, #-8]
    // 0xe01d64: r0 = MouseRegion()
    //     0xe01d64: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xe01d68: mov             x3, x0
    // 0xe01d6c: ldur            x0, [fp, #-8]
    // 0xe01d70: stur            x3, [fp, #-0x28]
    // 0xe01d74: StoreField: r3->field_f = r0
    //     0xe01d74: stur            w0, [x3, #0xf]
    // 0xe01d78: ldur            x2, [fp, #-0x20]
    // 0xe01d7c: r1 = Function '_handleMouseExit@66441002':.
    //     0xe01d7c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f70] AnonymousClosure: (0xe01f40), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleMouseExit (0xe01f7c)
    //     0xe01d80: ldr             x1, [x1, #0xf70]
    // 0xe01d84: r0 = AllocateClosure()
    //     0xe01d84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe01d88: mov             x1, x0
    // 0xe01d8c: ldur            x0, [fp, #-0x28]
    // 0xe01d90: ArrayStore: r0[0] = r1  ; List_4
    //     0xe01d90: stur            w1, [x0, #0x17]
    // 0xe01d94: ldur            x1, [fp, #-0x10]
    // 0xe01d98: StoreField: r0->field_1b = r1
    //     0xe01d98: stur            w1, [x0, #0x1b]
    // 0xe01d9c: r1 = true
    //     0xe01d9c: add             x1, NULL, #0x20  ; true
    // 0xe01da0: StoreField: r0->field_1f = r1
    //     0xe01da0: stur            w1, [x0, #0x1f]
    // 0xe01da4: ldur            x2, [fp, #-0x48]
    // 0xe01da8: StoreField: r0->field_b = r2
    //     0xe01da8: stur            w2, [x0, #0xb]
    // 0xe01dac: ldur            x2, [fp, #-0x18]
    // 0xe01db0: StoreField: r0->field_7 = r2
    //     0xe01db0: stur            w2, [x0, #7]
    // 0xe01db4: ldur            x2, [fp, #-0x38]
    // 0xe01db8: LoadField: r3 = r2->field_b
    //     0xe01db8: ldur            w3, [x2, #0xb]
    // 0xe01dbc: DecompressPointer r3
    //     0xe01dbc: add             x3, x3, HEAP, lsl #32
    // 0xe01dc0: stur            x3, [fp, #-0x10]
    // 0xe01dc4: tbnz            w3, #4, #0xe01e14
    // 0xe01dc8: LoadField: r4 = r2->field_1f
    //     0xe01dc8: ldur            w4, [x2, #0x1f]
    // 0xe01dcc: DecompressPointer r4
    //     0xe01dcc: add             x4, x4, HEAP, lsl #32
    // 0xe01dd0: stur            x4, [fp, #-8]
    // 0xe01dd4: cmp             w4, NULL
    // 0xe01dd8: b.eq            #0xe01e14
    // 0xe01ddc: LoadField: r5 = r4->field_13
    //     0xe01ddc: ldur            w5, [x4, #0x13]
    // 0xe01de0: r6 = LoadInt32Instr(r5)
    //     0xe01de0: sbfx            x6, x5, #1, #0x1f
    // 0xe01de4: asr             x5, x6, #1
    // 0xe01de8: ArrayLoad: r6 = r4[0]  ; List_4
    //     0xe01de8: ldur            w6, [x4, #0x17]
    // 0xe01dec: r7 = LoadInt32Instr(r6)
    //     0xe01dec: sbfx            x7, x6, #1, #0x1f
    // 0xe01df0: sub             x6, x5, x7
    // 0xe01df4: cbz             x6, #0xe01e14
    // 0xe01df8: r0 = Actions()
    //     0xe01df8: bl              #0xd1c8a8  ; AllocateActionsStub -> Actions (size=0x18)
    // 0xe01dfc: mov             x1, x0
    // 0xe01e00: ldur            x0, [fp, #-8]
    // 0xe01e04: StoreField: r1->field_f = r0
    //     0xe01e04: stur            w0, [x1, #0xf]
    // 0xe01e08: ldur            x0, [fp, #-0x28]
    // 0xe01e0c: StoreField: r1->field_13 = r0
    //     0xe01e0c: stur            w0, [x1, #0x13]
    // 0xe01e10: b               #0xe01e18
    // 0xe01e14: mov             x1, x0
    // 0xe01e18: ldur            x0, [fp, #-0x10]
    // 0xe01e1c: stur            x1, [fp, #-0x18]
    // 0xe01e20: tbnz            w0, #4, #0xe01e78
    // 0xe01e24: ldur            x0, [fp, #-0x38]
    // 0xe01e28: LoadField: r2 = r0->field_23
    //     0xe01e28: ldur            w2, [x0, #0x23]
    // 0xe01e2c: DecompressPointer r2
    //     0xe01e2c: add             x2, x2, HEAP, lsl #32
    // 0xe01e30: stur            x2, [fp, #-8]
    // 0xe01e34: cmp             w2, NULL
    // 0xe01e38: b.eq            #0xe01e78
    // 0xe01e3c: LoadField: r0 = r2->field_13
    //     0xe01e3c: ldur            w0, [x2, #0x13]
    // 0xe01e40: r3 = LoadInt32Instr(r0)
    //     0xe01e40: sbfx            x3, x0, #1, #0x1f
    // 0xe01e44: asr             x0, x3, #1
    // 0xe01e48: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xe01e48: ldur            w3, [x2, #0x17]
    // 0xe01e4c: r4 = LoadInt32Instr(r3)
    //     0xe01e4c: sbfx            x4, x3, #1, #0x1f
    // 0xe01e50: sub             x3, x0, x4
    // 0xe01e54: cbz             x3, #0xe01e78
    // 0xe01e58: r0 = Shortcuts()
    //     0xe01e58: bl              #0xd188b8  ; AllocateShortcutsStub -> Shortcuts (size=0x20)
    // 0xe01e5c: ldur            x1, [fp, #-0x18]
    // 0xe01e60: StoreField: r0->field_13 = r1
    //     0xe01e60: stur            w1, [x0, #0x13]
    // 0xe01e64: r2 = true
    //     0xe01e64: add             x2, NULL, #0x20  ; true
    // 0xe01e68: StoreField: r0->field_1b = r2
    //     0xe01e68: stur            w2, [x0, #0x1b]
    // 0xe01e6c: ldur            x2, [fp, #-8]
    // 0xe01e70: StoreField: r0->field_f = r2
    //     0xe01e70: stur            w2, [x0, #0xf]
    // 0xe01e74: b               #0xe01e7c
    // 0xe01e78: mov             x0, x1
    // 0xe01e7c: LeaveFrame
    //     0xe01e7c: mov             SP, fp
    //     0xe01e80: ldp             fp, lr, [SP], #0x10
    // 0xe01e84: ret
    //     0xe01e84: ret             
    // 0xe01e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01e8c: b               #0xe01c84
    // 0xe01e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01e90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01e94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01e94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0xe01e98, size: 0xa8
    // 0xe01e98: EnterFrame
    //     0xe01e98: stp             fp, lr, [SP, #-0x10]!
    //     0xe01e9c: mov             fp, SP
    // 0xe01ea0: AllocStack(0x8)
    //     0xe01ea0: sub             SP, SP, #8
    // 0xe01ea4: SetupParameters(_FocusableActionDetectorState this /* r1 => r0, fp-0x8 */)
    //     0xe01ea4: mov             x0, x1
    //     0xe01ea8: stur            x1, [fp, #-8]
    // 0xe01eac: CheckStackOverflow
    //     0xe01eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01eb0: cmp             SP, x16
    //     0xe01eb4: b.ls            #0xe01f30
    // 0xe01eb8: LoadField: r1 = r0->field_f
    //     0xe01eb8: ldur            w1, [x0, #0xf]
    // 0xe01ebc: DecompressPointer r1
    //     0xe01ebc: add             x1, x1, HEAP, lsl #32
    // 0xe01ec0: cmp             w1, NULL
    // 0xe01ec4: b.eq            #0xe01f38
    // 0xe01ec8: r0 = maybeNavigationModeOf()
    //     0xe01ec8: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xe01ecc: r16 = Instance_NavigationMode
    //     0xe01ecc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xe01ed0: ldr             x16, [x16, #0x858]
    // 0xe01ed4: cmp             w0, w16
    // 0xe01ed8: b.eq            #0xe01ee4
    // 0xe01edc: cmp             w0, NULL
    // 0xe01ee0: b.ne            #0xe01f08
    // 0xe01ee4: ldur            x1, [fp, #-8]
    // 0xe01ee8: LoadField: r2 = r1->field_b
    //     0xe01ee8: ldur            w2, [x1, #0xb]
    // 0xe01eec: DecompressPointer r2
    //     0xe01eec: add             x2, x2, HEAP, lsl #32
    // 0xe01ef0: cmp             w2, NULL
    // 0xe01ef4: b.eq            #0xe01f3c
    // 0xe01ef8: LoadField: r1 = r2->field_b
    //     0xe01ef8: ldur            w1, [x2, #0xb]
    // 0xe01efc: DecompressPointer r1
    //     0xe01efc: add             x1, x1, HEAP, lsl #32
    // 0xe01f00: mov             x0, x1
    // 0xe01f04: b               #0xe01f24
    // 0xe01f08: r16 = Instance_NavigationMode
    //     0xe01f08: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xe01f0c: ldr             x16, [x16, #0x518]
    // 0xe01f10: cmp             w0, w16
    // 0xe01f14: b.ne            #0xe01f20
    // 0xe01f18: r0 = true
    //     0xe01f18: add             x0, NULL, #0x20  ; true
    // 0xe01f1c: b               #0xe01f24
    // 0xe01f20: r0 = Null
    //     0xe01f20: mov             x0, NULL
    // 0xe01f24: LeaveFrame
    //     0xe01f24: mov             SP, fp
    //     0xe01f28: ldp             fp, lr, [SP], #0x10
    // 0xe01f2c: ret
    //     0xe01f2c: ret             
    // 0xe01f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01f34: b               #0xe01eb8
    // 0xe01f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01f38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01f3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01f3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleMouseExit(dynamic, PointerExitEvent) {
    // ** addr: 0xe01f40, size: 0x3c
    // 0xe01f40: EnterFrame
    //     0xe01f40: stp             fp, lr, [SP, #-0x10]!
    //     0xe01f44: mov             fp, SP
    // 0xe01f48: ldr             x0, [fp, #0x18]
    // 0xe01f4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe01f4c: ldur            w1, [x0, #0x17]
    // 0xe01f50: DecompressPointer r1
    //     0xe01f50: add             x1, x1, HEAP, lsl #32
    // 0xe01f54: CheckStackOverflow
    //     0xe01f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01f58: cmp             SP, x16
    //     0xe01f5c: b.ls            #0xe01f74
    // 0xe01f60: ldr             x2, [fp, #0x10]
    // 0xe01f64: r0 = _handleMouseExit()
    //     0xe01f64: bl              #0xe01f7c  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleMouseExit
    // 0xe01f68: LeaveFrame
    //     0xe01f68: mov             SP, fp
    //     0xe01f6c: ldp             fp, lr, [SP], #0x10
    // 0xe01f70: ret
    //     0xe01f70: ret             
    // 0xe01f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01f74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01f78: b               #0xe01f60
  }
  _ _handleMouseExit(/* No info */) {
    // ** addr: 0xe01f7c, size: 0x78
    // 0xe01f7c: EnterFrame
    //     0xe01f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xe01f80: mov             fp, SP
    // 0xe01f84: AllocStack(0x10)
    //     0xe01f84: sub             SP, SP, #0x10
    // 0xe01f88: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x8 */)
    //     0xe01f88: stur            x1, [fp, #-8]
    // 0xe01f8c: CheckStackOverflow
    //     0xe01f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01f90: cmp             SP, x16
    //     0xe01f94: b.ls            #0xe01fec
    // 0xe01f98: r1 = 1
    //     0xe01f98: mov             x1, #1
    // 0xe01f9c: r0 = AllocateContext()
    //     0xe01f9c: bl              #0x13de838  ; AllocateContextStub
    // 0xe01fa0: mov             x1, x0
    // 0xe01fa4: ldur            x0, [fp, #-8]
    // 0xe01fa8: StoreField: r1->field_f = r0
    //     0xe01fa8: stur            w0, [x1, #0xf]
    // 0xe01fac: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xe01fac: ldur            w2, [x0, #0x17]
    // 0xe01fb0: DecompressPointer r2
    //     0xe01fb0: add             x2, x2, HEAP, lsl #32
    // 0xe01fb4: tbnz            w2, #4, #0xe01fdc
    // 0xe01fb8: mov             x2, x1
    // 0xe01fbc: r1 = Function '<anonymous closure>':.
    //     0xe01fbc: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f78] AnonymousClosure: (0xe02420), in [package:simaster_ugm/app/modules/reusable_component/web_view_page.dart] _WebViewPageState::initializeWebView (0xe024a4)
    //     0xe01fc0: ldr             x1, [x1, #0xf78]
    // 0xe01fc4: r0 = AllocateClosure()
    //     0xe01fc4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe01fc8: str             x0, [SP]
    // 0xe01fcc: ldur            x1, [fp, #-8]
    // 0xe01fd0: r4 = const [0, 0x2, 0x1, 0x1, task, 0x1, null]
    //     0xe01fd0: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3f80] List(7) [0, 0x2, 0x1, 0x1, "task", 0x1, Null]
    //     0xe01fd4: ldr             x4, [x4, #0xf80]
    // 0xe01fd8: r0 = _mayTriggerCallback()
    //     0xe01fd8: bl              #0xe01ff4  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback
    // 0xe01fdc: r0 = Null
    //     0xe01fdc: mov             x0, NULL
    // 0xe01fe0: LeaveFrame
    //     0xe01fe0: mov             SP, fp
    //     0xe01fe4: ldp             fp, lr, [SP], #0x10
    // 0xe01fe8: ret
    //     0xe01fe8: ret             
    // 0xe01fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01ff0: b               #0xe01f98
  }
  _ _mayTriggerCallback(/* No info */) {
    // ** addr: 0xe01ff4, size: 0x390
    // 0xe01ff4: EnterFrame
    //     0xe01ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xe01ff8: mov             fp, SP
    // 0xe01ffc: AllocStack(0x40)
    //     0xe01ffc: sub             SP, SP, #0x40
    // 0xe02000: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x18 */, {dynamic oldWidget = Null /* r3, fp-0x10 */, dynamic task = Null /* r0, fp-0x8 */})
    //     0xe02000: stur            x1, [fp, #-0x18]
    //     0xe02004: ldur            w0, [x4, #0x13]
    //     0xe02008: ldur            w2, [x4, #0x1f]
    //     0xe0200c: add             x2, x2, HEAP, lsl #32
    //     0xe02010: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3488] "oldWidget"
    //     0xe02014: ldr             x16, [x16, #0x488]
    //     0xe02018: cmp             w2, w16
    //     0xe0201c: b.ne            #0xe02040
    //     0xe02020: ldur            w2, [x4, #0x23]
    //     0xe02024: add             x2, x2, HEAP, lsl #32
    //     0xe02028: sub             w3, w0, w2
    //     0xe0202c: add             x2, fp, w3, sxtw #2
    //     0xe02030: ldr             x2, [x2, #8]
    //     0xe02034: mov             x3, x2
    //     0xe02038: mov             x2, #1
    //     0xe0203c: b               #0xe02048
    //     0xe02040: mov             x3, NULL
    //     0xe02044: mov             x2, #0
    //     0xe02048: stur            x3, [fp, #-0x10]
    //     0xe0204c: lsl             x5, x2, #1
    //     0xe02050: lsl             w2, w5, #1
    //     0xe02054: add             w5, w2, #8
    //     0xe02058: add             x16, x4, w5, sxtw #1
    //     0xe0205c: ldur            w6, [x16, #0xf]
    //     0xe02060: add             x6, x6, HEAP, lsl #32
    //     0xe02064: add             x16, PP, #0x24, lsl #12  ; [pp+0x24640] "task"
    //     0xe02068: ldr             x16, [x16, #0x640]
    //     0xe0206c: cmp             w6, w16
    //     0xe02070: b.ne            #0xe02094
    //     0xe02074: add             w5, w2, #0xa
    //     0xe02078: add             x16, x4, w5, sxtw #1
    //     0xe0207c: ldur            w2, [x16, #0xf]
    //     0xe02080: add             x2, x2, HEAP, lsl #32
    //     0xe02084: sub             w4, w0, w2
    //     0xe02088: add             x0, fp, w4, sxtw #2
    //     0xe0208c: ldr             x0, [x0, #8]
    //     0xe02090: b               #0xe02098
    //     0xe02094: mov             x0, NULL
    //     0xe02098: stur            x0, [fp, #-8]
    // 0xe0209c: CheckStackOverflow
    //     0xe0209c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe020a0: cmp             SP, x16
    //     0xe020a4: b.ls            #0xe02364
    // 0xe020a8: r1 = 2
    //     0xe020a8: mov             x1, #2
    // 0xe020ac: r0 = AllocateContext()
    //     0xe020ac: bl              #0x13de838  ; AllocateContextStub
    // 0xe020b0: mov             x3, x0
    // 0xe020b4: ldur            x0, [fp, #-0x18]
    // 0xe020b8: stur            x3, [fp, #-0x20]
    // 0xe020bc: StoreField: r3->field_f = r0
    //     0xe020bc: stur            w0, [x3, #0xf]
    // 0xe020c0: mov             x2, x3
    // 0xe020c4: r1 = Function 'canRequestFocus':.
    //     0xe020c4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f88] AnonymousClosure: (0xe02384), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback (0xe01ff4)
    //     0xe020c8: ldr             x1, [x1, #0xf88]
    // 0xe020cc: r0 = AllocateClosure()
    //     0xe020cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe020d0: mov             x1, x0
    // 0xe020d4: ldur            x0, [fp, #-0x20]
    // 0xe020d8: StoreField: r0->field_13 = r1
    //     0xe020d8: stur            w1, [x0, #0x13]
    // 0xe020dc: ldur            x1, [fp, #-0x10]
    // 0xe020e0: cmp             w1, NULL
    // 0xe020e4: b.ne            #0xe02104
    // 0xe020e8: ldur            x2, [fp, #-0x18]
    // 0xe020ec: LoadField: r1 = r2->field_b
    //     0xe020ec: ldur            w1, [x2, #0xb]
    // 0xe020f0: DecompressPointer r1
    //     0xe020f0: add             x1, x1, HEAP, lsl #32
    // 0xe020f4: cmp             w1, NULL
    // 0xe020f8: b.eq            #0xe0236c
    // 0xe020fc: mov             x3, x1
    // 0xe02100: b               #0xe0210c
    // 0xe02104: ldur            x2, [fp, #-0x18]
    // 0xe02108: mov             x3, x1
    // 0xe0210c: stur            x3, [fp, #-0x28]
    // 0xe02110: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xe02110: ldur            w1, [x2, #0x17]
    // 0xe02114: DecompressPointer r1
    //     0xe02114: add             x1, x1, HEAP, lsl #32
    // 0xe02118: tbnz            w1, #4, #0xe02138
    // 0xe0211c: LoadField: r1 = r3->field_b
    //     0xe0211c: ldur            w1, [x3, #0xb]
    // 0xe02120: DecompressPointer r1
    //     0xe02120: add             x1, x1, HEAP, lsl #32
    // 0xe02124: tbnz            w1, #4, #0xe02138
    // 0xe02128: LoadField: r1 = r2->field_13
    //     0xe02128: ldur            w1, [x2, #0x13]
    // 0xe0212c: DecompressPointer r1
    //     0xe0212c: add             x1, x1, HEAP, lsl #32
    // 0xe02130: mov             x4, x1
    // 0xe02134: b               #0xe0213c
    // 0xe02138: r4 = false
    //     0xe02138: add             x4, NULL, #0x30  ; false
    // 0xe0213c: stur            x4, [fp, #-0x10]
    // 0xe02140: LoadField: r1 = r2->field_1b
    //     0xe02140: ldur            w1, [x2, #0x1b]
    // 0xe02144: DecompressPointer r1
    //     0xe02144: add             x1, x1, HEAP, lsl #32
    // 0xe02148: tbnz            w1, #4, #0xe021c8
    // 0xe0214c: LoadField: r1 = r2->field_13
    //     0xe0214c: ldur            w1, [x2, #0x13]
    // 0xe02150: DecompressPointer r1
    //     0xe02150: add             x1, x1, HEAP, lsl #32
    // 0xe02154: tbnz            w1, #4, #0xe021c8
    // 0xe02158: LoadField: r1 = r0->field_f
    //     0xe02158: ldur            w1, [x0, #0xf]
    // 0xe0215c: DecompressPointer r1
    //     0xe0215c: add             x1, x1, HEAP, lsl #32
    // 0xe02160: LoadField: r5 = r1->field_f
    //     0xe02160: ldur            w5, [x1, #0xf]
    // 0xe02164: DecompressPointer r5
    //     0xe02164: add             x5, x5, HEAP, lsl #32
    // 0xe02168: cmp             w5, NULL
    // 0xe0216c: b.eq            #0xe02370
    // 0xe02170: mov             x1, x5
    // 0xe02174: r0 = maybeNavigationModeOf()
    //     0xe02174: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xe02178: r16 = Instance_NavigationMode
    //     0xe02178: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xe0217c: ldr             x16, [x16, #0x858]
    // 0xe02180: cmp             w0, w16
    // 0xe02184: b.eq            #0xe02190
    // 0xe02188: cmp             w0, NULL
    // 0xe0218c: b.ne            #0xe021a4
    // 0xe02190: ldur            x0, [fp, #-0x28]
    // 0xe02194: LoadField: r1 = r0->field_b
    //     0xe02194: ldur            w1, [x0, #0xb]
    // 0xe02198: DecompressPointer r1
    //     0xe02198: add             x1, x1, HEAP, lsl #32
    // 0xe0219c: mov             x0, x1
    // 0xe021a0: b               #0xe021c0
    // 0xe021a4: r16 = Instance_NavigationMode
    //     0xe021a4: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xe021a8: ldr             x16, [x16, #0x518]
    // 0xe021ac: cmp             w0, w16
    // 0xe021b0: b.ne            #0xe021bc
    // 0xe021b4: r0 = true
    //     0xe021b4: add             x0, NULL, #0x20  ; true
    // 0xe021b8: b               #0xe021c0
    // 0xe021bc: r0 = Null
    //     0xe021bc: mov             x0, NULL
    // 0xe021c0: mov             x1, x0
    // 0xe021c4: b               #0xe021cc
    // 0xe021c8: r1 = false
    //     0xe021c8: add             x1, NULL, #0x30  ; false
    // 0xe021cc: ldur            x0, [fp, #-8]
    // 0xe021d0: stur            x1, [fp, #-0x28]
    // 0xe021d4: cmp             w0, NULL
    // 0xe021d8: b.eq            #0xe021ec
    // 0xe021dc: str             x0, [SP]
    // 0xe021e0: ClosureCall
    //     0xe021e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xe021e4: ldur            x2, [x0, #0x1f]
    //     0xe021e8: blr             x2
    // 0xe021ec: ldur            x2, [fp, #-0x18]
    // 0xe021f0: ldur            x0, [fp, #-0x20]
    // 0xe021f4: LoadField: r3 = r2->field_b
    //     0xe021f4: ldur            w3, [x2, #0xb]
    // 0xe021f8: DecompressPointer r3
    //     0xe021f8: add             x3, x3, HEAP, lsl #32
    // 0xe021fc: stur            x3, [fp, #-0x30]
    // 0xe02200: cmp             w3, NULL
    // 0xe02204: b.eq            #0xe02374
    // 0xe02208: LoadField: r1 = r0->field_f
    //     0xe02208: ldur            w1, [x0, #0xf]
    // 0xe0220c: DecompressPointer r1
    //     0xe0220c: add             x1, x1, HEAP, lsl #32
    // 0xe02210: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xe02210: ldur            w4, [x1, #0x17]
    // 0xe02214: DecompressPointer r4
    //     0xe02214: add             x4, x4, HEAP, lsl #32
    // 0xe02218: tbnz            w4, #4, #0xe02234
    // 0xe0221c: LoadField: r4 = r3->field_b
    //     0xe0221c: ldur            w4, [x3, #0xb]
    // 0xe02220: DecompressPointer r4
    //     0xe02220: add             x4, x4, HEAP, lsl #32
    // 0xe02224: tbnz            w4, #4, #0xe02234
    // 0xe02228: LoadField: r4 = r1->field_13
    //     0xe02228: ldur            w4, [x1, #0x13]
    // 0xe0222c: DecompressPointer r4
    //     0xe0222c: add             x4, x4, HEAP, lsl #32
    // 0xe02230: b               #0xe02238
    // 0xe02234: r4 = false
    //     0xe02234: add             x4, NULL, #0x30  ; false
    // 0xe02238: stur            x4, [fp, #-8]
    // 0xe0223c: LoadField: r5 = r1->field_1b
    //     0xe0223c: ldur            w5, [x1, #0x1b]
    // 0xe02240: DecompressPointer r5
    //     0xe02240: add             x5, x5, HEAP, lsl #32
    // 0xe02244: tbnz            w5, #4, #0xe022c4
    // 0xe02248: LoadField: r5 = r1->field_13
    //     0xe02248: ldur            w5, [x1, #0x13]
    // 0xe0224c: DecompressPointer r5
    //     0xe0224c: add             x5, x5, HEAP, lsl #32
    // 0xe02250: tbnz            w5, #4, #0xe022c4
    // 0xe02254: LoadField: r1 = r0->field_f
    //     0xe02254: ldur            w1, [x0, #0xf]
    // 0xe02258: DecompressPointer r1
    //     0xe02258: add             x1, x1, HEAP, lsl #32
    // 0xe0225c: LoadField: r0 = r1->field_f
    //     0xe0225c: ldur            w0, [x1, #0xf]
    // 0xe02260: DecompressPointer r0
    //     0xe02260: add             x0, x0, HEAP, lsl #32
    // 0xe02264: cmp             w0, NULL
    // 0xe02268: b.eq            #0xe02378
    // 0xe0226c: mov             x1, x0
    // 0xe02270: r0 = maybeNavigationModeOf()
    //     0xe02270: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xe02274: r16 = Instance_NavigationMode
    //     0xe02274: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xe02278: ldr             x16, [x16, #0x858]
    // 0xe0227c: cmp             w0, w16
    // 0xe02280: b.eq            #0xe0228c
    // 0xe02284: cmp             w0, NULL
    // 0xe02288: b.ne            #0xe022a0
    // 0xe0228c: ldur            x0, [fp, #-0x30]
    // 0xe02290: LoadField: r1 = r0->field_b
    //     0xe02290: ldur            w1, [x0, #0xb]
    // 0xe02294: DecompressPointer r1
    //     0xe02294: add             x1, x1, HEAP, lsl #32
    // 0xe02298: mov             x0, x1
    // 0xe0229c: b               #0xe022bc
    // 0xe022a0: r16 = Instance_NavigationMode
    //     0xe022a0: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xe022a4: ldr             x16, [x16, #0x518]
    // 0xe022a8: cmp             w0, w16
    // 0xe022ac: b.ne            #0xe022b8
    // 0xe022b0: r0 = true
    //     0xe022b0: add             x0, NULL, #0x20  ; true
    // 0xe022b4: b               #0xe022bc
    // 0xe022b8: r0 = Null
    //     0xe022b8: mov             x0, NULL
    // 0xe022bc: mov             x1, x0
    // 0xe022c0: b               #0xe022c8
    // 0xe022c4: r1 = false
    //     0xe022c4: add             x1, NULL, #0x30  ; false
    // 0xe022c8: ldur            x0, [fp, #-0x28]
    // 0xe022cc: cmp             w0, w1
    // 0xe022d0: b.eq            #0xe0230c
    // 0xe022d4: ldur            x2, [fp, #-0x18]
    // 0xe022d8: LoadField: r0 = r2->field_b
    //     0xe022d8: ldur            w0, [x2, #0xb]
    // 0xe022dc: DecompressPointer r0
    //     0xe022dc: add             x0, x0, HEAP, lsl #32
    // 0xe022e0: cmp             w0, NULL
    // 0xe022e4: b.eq            #0xe0237c
    // 0xe022e8: LoadField: r3 = r0->field_27
    //     0xe022e8: ldur            w3, [x0, #0x27]
    // 0xe022ec: DecompressPointer r3
    //     0xe022ec: add             x3, x3, HEAP, lsl #32
    // 0xe022f0: cmp             w3, NULL
    // 0xe022f4: b.eq            #0xe0230c
    // 0xe022f8: stp             x1, x3, [SP]
    // 0xe022fc: mov             x0, x3
    // 0xe02300: ClosureCall
    //     0xe02300: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe02304: ldur            x2, [x0, #0x1f]
    //     0xe02308: blr             x2
    // 0xe0230c: ldur            x0, [fp, #-8]
    // 0xe02310: ldur            x1, [fp, #-0x10]
    // 0xe02314: cmp             w1, w0
    // 0xe02318: b.eq            #0xe02354
    // 0xe0231c: ldur            x1, [fp, #-0x18]
    // 0xe02320: LoadField: r2 = r1->field_b
    //     0xe02320: ldur            w2, [x1, #0xb]
    // 0xe02324: DecompressPointer r2
    //     0xe02324: add             x2, x2, HEAP, lsl #32
    // 0xe02328: cmp             w2, NULL
    // 0xe0232c: b.eq            #0xe02380
    // 0xe02330: LoadField: r1 = r2->field_2b
    //     0xe02330: ldur            w1, [x2, #0x2b]
    // 0xe02334: DecompressPointer r1
    //     0xe02334: add             x1, x1, HEAP, lsl #32
    // 0xe02338: cmp             w1, NULL
    // 0xe0233c: b.eq            #0xe02354
    // 0xe02340: stp             x0, x1, [SP]
    // 0xe02344: mov             x0, x1
    // 0xe02348: ClosureCall
    //     0xe02348: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe0234c: ldur            x2, [x0, #0x1f]
    //     0xe02350: blr             x2
    // 0xe02354: r0 = Null
    //     0xe02354: mov             x0, NULL
    // 0xe02358: LeaveFrame
    //     0xe02358: mov             SP, fp
    //     0xe0235c: ldp             fp, lr, [SP], #0x10
    // 0xe02360: ret
    //     0xe02360: ret             
    // 0xe02364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe02364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe02368: b               #0xe020a8
    // 0xe0236c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0236c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe02370: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe02370: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe02374: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe02374: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe02378: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe02378: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0237c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0237c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe02380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe02380: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool canRequestFocus(dynamic, FocusableActionDetector) {
    // ** addr: 0xe02384, size: 0x9c
    // 0xe02384: EnterFrame
    //     0xe02384: stp             fp, lr, [SP, #-0x10]!
    //     0xe02388: mov             fp, SP
    // 0xe0238c: ldr             x0, [fp, #0x18]
    // 0xe02390: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe02390: ldur            w1, [x0, #0x17]
    // 0xe02394: DecompressPointer r1
    //     0xe02394: add             x1, x1, HEAP, lsl #32
    // 0xe02398: CheckStackOverflow
    //     0xe02398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0239c: cmp             SP, x16
    //     0xe023a0: b.ls            #0xe02414
    // 0xe023a4: LoadField: r0 = r1->field_f
    //     0xe023a4: ldur            w0, [x1, #0xf]
    // 0xe023a8: DecompressPointer r0
    //     0xe023a8: add             x0, x0, HEAP, lsl #32
    // 0xe023ac: LoadField: r1 = r0->field_f
    //     0xe023ac: ldur            w1, [x0, #0xf]
    // 0xe023b0: DecompressPointer r1
    //     0xe023b0: add             x1, x1, HEAP, lsl #32
    // 0xe023b4: cmp             w1, NULL
    // 0xe023b8: b.eq            #0xe0241c
    // 0xe023bc: r0 = maybeNavigationModeOf()
    //     0xe023bc: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xe023c0: r16 = Instance_NavigationMode
    //     0xe023c0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xe023c4: ldr             x16, [x16, #0x858]
    // 0xe023c8: cmp             w0, w16
    // 0xe023cc: b.eq            #0xe023d8
    // 0xe023d0: cmp             w0, NULL
    // 0xe023d4: b.ne            #0xe023ec
    // 0xe023d8: ldr             x1, [fp, #0x10]
    // 0xe023dc: LoadField: r2 = r1->field_b
    //     0xe023dc: ldur            w2, [x1, #0xb]
    // 0xe023e0: DecompressPointer r2
    //     0xe023e0: add             x2, x2, HEAP, lsl #32
    // 0xe023e4: mov             x0, x2
    // 0xe023e8: b               #0xe02408
    // 0xe023ec: r16 = Instance_NavigationMode
    //     0xe023ec: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xe023f0: ldr             x16, [x16, #0x518]
    // 0xe023f4: cmp             w0, w16
    // 0xe023f8: b.ne            #0xe02404
    // 0xe023fc: r0 = true
    //     0xe023fc: add             x0, NULL, #0x20  ; true
    // 0xe02400: b               #0xe02408
    // 0xe02404: r0 = Null
    //     0xe02404: mov             x0, NULL
    // 0xe02408: LeaveFrame
    //     0xe02408: mov             SP, fp
    //     0xe0240c: ldp             fp, lr, [SP], #0x10
    // 0xe02410: ret
    //     0xe02410: ret             
    // 0xe02414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe02414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe02418: b               #0xe023a4
    // 0xe0241c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0241c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleMouseEnter(dynamic, PointerEnterEvent) {
    // ** addr: 0xe08cc8, size: 0x3c
    // 0xe08cc8: EnterFrame
    //     0xe08cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xe08ccc: mov             fp, SP
    // 0xe08cd0: ldr             x0, [fp, #0x18]
    // 0xe08cd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe08cd4: ldur            w1, [x0, #0x17]
    // 0xe08cd8: DecompressPointer r1
    //     0xe08cd8: add             x1, x1, HEAP, lsl #32
    // 0xe08cdc: CheckStackOverflow
    //     0xe08cdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe08ce0: cmp             SP, x16
    //     0xe08ce4: b.ls            #0xe08cfc
    // 0xe08ce8: ldr             x2, [fp, #0x10]
    // 0xe08cec: r0 = _handleMouseEnter()
    //     0xe08cec: bl              #0xe08d04  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleMouseEnter
    // 0xe08cf0: LeaveFrame
    //     0xe08cf0: mov             SP, fp
    //     0xe08cf4: ldp             fp, lr, [SP], #0x10
    // 0xe08cf8: ret
    //     0xe08cf8: ret             
    // 0xe08cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe08cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe08d00: b               #0xe08ce8
  }
  _ _handleMouseEnter(/* No info */) {
    // ** addr: 0xe08d04, size: 0x78
    // 0xe08d04: EnterFrame
    //     0xe08d04: stp             fp, lr, [SP, #-0x10]!
    //     0xe08d08: mov             fp, SP
    // 0xe08d0c: AllocStack(0x10)
    //     0xe08d0c: sub             SP, SP, #0x10
    // 0xe08d10: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x8 */)
    //     0xe08d10: stur            x1, [fp, #-8]
    // 0xe08d14: CheckStackOverflow
    //     0xe08d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe08d18: cmp             SP, x16
    //     0xe08d1c: b.ls            #0xe08d74
    // 0xe08d20: r1 = 1
    //     0xe08d20: mov             x1, #1
    // 0xe08d24: r0 = AllocateContext()
    //     0xe08d24: bl              #0x13de838  ; AllocateContextStub
    // 0xe08d28: mov             x1, x0
    // 0xe08d2c: ldur            x0, [fp, #-8]
    // 0xe08d30: StoreField: r1->field_f = r0
    //     0xe08d30: stur            w0, [x1, #0xf]
    // 0xe08d34: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xe08d34: ldur            w2, [x0, #0x17]
    // 0xe08d38: DecompressPointer r2
    //     0xe08d38: add             x2, x2, HEAP, lsl #32
    // 0xe08d3c: tbz             w2, #4, #0xe08d64
    // 0xe08d40: mov             x2, x1
    // 0xe08d44: r1 = Function '<anonymous closure>':.
    //     0xe08d44: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f90] AnonymousClosure: (0xe08848), in [package:simaster_ugm/app/modules/reusable_component/web_view_page.dart] _WebViewPageState::initializeWebView (0xe024a4)
    //     0xe08d48: ldr             x1, [x1, #0xf90]
    // 0xe08d4c: r0 = AllocateClosure()
    //     0xe08d4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe08d50: str             x0, [SP]
    // 0xe08d54: ldur            x1, [fp, #-8]
    // 0xe08d58: r4 = const [0, 0x2, 0x1, 0x1, task, 0x1, null]
    //     0xe08d58: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3f80] List(7) [0, 0x2, 0x1, 0x1, "task", 0x1, Null]
    //     0xe08d5c: ldr             x4, [x4, #0xf80]
    // 0xe08d60: r0 = _mayTriggerCallback()
    //     0xe08d60: bl              #0xe01ff4  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback
    // 0xe08d64: r0 = Null
    //     0xe08d64: mov             x0, NULL
    // 0xe08d68: LeaveFrame
    //     0xe08d68: mov             SP, fp
    //     0xe08d6c: ldp             fp, lr, [SP], #0x10
    // 0xe08d70: ret
    //     0xe08d70: ret             
    // 0xe08d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe08d74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe08d78: b               #0xe08d20
  }
  [closure] void _handleFocusChange(dynamic, bool) {
    // ** addr: 0xe08d7c, size: 0x3c
    // 0xe08d7c: EnterFrame
    //     0xe08d7c: stp             fp, lr, [SP, #-0x10]!
    //     0xe08d80: mov             fp, SP
    // 0xe08d84: ldr             x0, [fp, #0x18]
    // 0xe08d88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe08d88: ldur            w1, [x0, #0x17]
    // 0xe08d8c: DecompressPointer r1
    //     0xe08d8c: add             x1, x1, HEAP, lsl #32
    // 0xe08d90: CheckStackOverflow
    //     0xe08d90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe08d94: cmp             SP, x16
    //     0xe08d98: b.ls            #0xe08db0
    // 0xe08d9c: ldr             x2, [fp, #0x10]
    // 0xe08da0: r0 = _handleFocusChange()
    //     0xe08da0: bl              #0xe08db8  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleFocusChange
    // 0xe08da4: LeaveFrame
    //     0xe08da4: mov             SP, fp
    //     0xe08da8: ldp             fp, lr, [SP], #0x10
    // 0xe08dac: ret
    //     0xe08dac: ret             
    // 0xe08db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe08db0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe08db4: b               #0xe08d9c
  }
  _ _handleFocusChange(/* No info */) {
    // ** addr: 0xe08db8, size: 0xcc
    // 0xe08db8: EnterFrame
    //     0xe08db8: stp             fp, lr, [SP, #-0x10]!
    //     0xe08dbc: mov             fp, SP
    // 0xe08dc0: AllocStack(0x18)
    //     0xe08dc0: sub             SP, SP, #0x18
    // 0xe08dc4: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xe08dc4: stur            x1, [fp, #-8]
    //     0xe08dc8: stur            x2, [fp, #-0x10]
    // 0xe08dcc: CheckStackOverflow
    //     0xe08dcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe08dd0: cmp             SP, x16
    //     0xe08dd4: b.ls            #0xe08e78
    // 0xe08dd8: r1 = 2
    //     0xe08dd8: mov             x1, #2
    // 0xe08ddc: r0 = AllocateContext()
    //     0xe08ddc: bl              #0x13de838  ; AllocateContextStub
    // 0xe08de0: mov             x1, x0
    // 0xe08de4: ldur            x0, [fp, #-8]
    // 0xe08de8: StoreField: r1->field_f = r0
    //     0xe08de8: stur            w0, [x1, #0xf]
    // 0xe08dec: ldur            x2, [fp, #-0x10]
    // 0xe08df0: StoreField: r1->field_13 = r2
    //     0xe08df0: stur            w2, [x1, #0x13]
    // 0xe08df4: LoadField: r3 = r0->field_1b
    //     0xe08df4: ldur            w3, [x0, #0x1b]
    // 0xe08df8: DecompressPointer r3
    //     0xe08df8: add             x3, x3, HEAP, lsl #32
    // 0xe08dfc: cmp             w3, w2
    // 0xe08e00: b.eq            #0xe08e68
    // 0xe08e04: mov             x2, x1
    // 0xe08e08: r1 = Function '<anonymous closure>':.
    //     0xe08e08: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f98] AnonymousClosure: (0xdfcfa0), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged (0xdfcd54)
    //     0xe08e0c: ldr             x1, [x1, #0xf98]
    // 0xe08e10: r0 = AllocateClosure()
    //     0xe08e10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe08e14: str             x0, [SP]
    // 0xe08e18: ldur            x1, [fp, #-8]
    // 0xe08e1c: r4 = const [0, 0x2, 0x1, 0x1, task, 0x1, null]
    //     0xe08e1c: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3f80] List(7) [0, 0x2, 0x1, 0x1, "task", 0x1, Null]
    //     0xe08e20: ldr             x4, [x4, #0xf80]
    // 0xe08e24: r0 = _mayTriggerCallback()
    //     0xe08e24: bl              #0xe01ff4  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback
    // 0xe08e28: ldur            x0, [fp, #-8]
    // 0xe08e2c: LoadField: r1 = r0->field_b
    //     0xe08e2c: ldur            w1, [x0, #0xb]
    // 0xe08e30: DecompressPointer r1
    //     0xe08e30: add             x1, x1, HEAP, lsl #32
    // 0xe08e34: cmp             w1, NULL
    // 0xe08e38: b.eq            #0xe08e80
    // 0xe08e3c: LoadField: r2 = r1->field_2f
    //     0xe08e3c: ldur            w2, [x1, #0x2f]
    // 0xe08e40: DecompressPointer r2
    //     0xe08e40: add             x2, x2, HEAP, lsl #32
    // 0xe08e44: cmp             w2, NULL
    // 0xe08e48: b.eq            #0xe08e68
    // 0xe08e4c: LoadField: r1 = r0->field_1b
    //     0xe08e4c: ldur            w1, [x0, #0x1b]
    // 0xe08e50: DecompressPointer r1
    //     0xe08e50: add             x1, x1, HEAP, lsl #32
    // 0xe08e54: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xe08e54: ldur            w0, [x2, #0x17]
    // 0xe08e58: DecompressPointer r0
    //     0xe08e58: add             x0, x0, HEAP, lsl #32
    // 0xe08e5c: mov             x2, x1
    // 0xe08e60: mov             x1, x0
    // 0xe08e64: r0 = _handleGridFocusChange()
    //     0xe08e64: bl              #0xdef338  ; [package:flutter/src/material/calendar_date_picker.dart] _MonthPickerState::_handleGridFocusChange
    // 0xe08e68: r0 = Null
    //     0xe08e68: mov             x0, NULL
    // 0xe08e6c: LeaveFrame
    //     0xe08e6c: mov             SP, fp
    //     0xe08e70: ldp             fp, lr, [SP], #0x10
    // 0xe08e74: ret
    //     0xe08e74: ret             
    // 0xe08e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe08e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe08e7c: b               #0xe08dd8
    // 0xe08e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe08e80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6f9ec, size: 0x1f0
    // 0xf6f9ec: EnterFrame
    //     0xf6f9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f9f0: mov             fp, SP
    // 0xf6f9f4: AllocStack(0x20)
    //     0xf6f9f4: sub             SP, SP, #0x20
    // 0xf6f9f8: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf6f9f8: mov             x0, x2
    //     0xf6f9fc: stur            x1, [fp, #-8]
    //     0xf6fa00: stur            x2, [fp, #-0x10]
    // 0xf6fa04: CheckStackOverflow
    //     0xf6fa04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6fa08: cmp             SP, x16
    //     0xf6fa0c: b.ls            #0xf6fbcc
    // 0xf6fa10: r1 = 2
    //     0xf6fa10: mov             x1, #2
    // 0xf6fa14: r0 = AllocateContext()
    //     0xf6fa14: bl              #0x13de838  ; AllocateContextStub
    // 0xf6fa18: mov             x4, x0
    // 0xf6fa1c: ldur            x3, [fp, #-8]
    // 0xf6fa20: stur            x4, [fp, #-0x18]
    // 0xf6fa24: StoreField: r4->field_f = r3
    //     0xf6fa24: stur            w3, [x4, #0xf]
    // 0xf6fa28: ldur            x5, [fp, #-0x10]
    // 0xf6fa2c: StoreField: r4->field_13 = r5
    //     0xf6fa2c: stur            w5, [x4, #0x13]
    // 0xf6fa30: mov             x0, x5
    // 0xf6fa34: r2 = Null
    //     0xf6fa34: mov             x2, NULL
    // 0xf6fa38: r1 = Null
    //     0xf6fa38: mov             x1, NULL
    // 0xf6fa3c: r4 = 60
    //     0xf6fa3c: mov             x4, #0x3c
    // 0xf6fa40: branchIfSmi(r0, 0xf6fa4c)
    //     0xf6fa40: tbz             w0, #0, #0xf6fa4c
    // 0xf6fa44: r4 = LoadClassIdInstr(r0)
    //     0xf6fa44: ldur            x4, [x0, #-1]
    //     0xf6fa48: ubfx            x4, x4, #0xc, #0x14
    // 0xf6fa4c: r17 = 6409
    //     0xf6fa4c: mov             x17, #0x1909
    // 0xf6fa50: cmp             x4, x17
    // 0xf6fa54: b.eq            #0xf6fa6c
    // 0xf6fa58: r8 = FocusableActionDetector
    //     0xf6fa58: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3fe0] Type: FocusableActionDetector
    //     0xf6fa5c: ldr             x8, [x8, #0xfe0]
    // 0xf6fa60: r3 = Null
    //     0xf6fa60: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3fe8] Null
    //     0xf6fa64: ldr             x3, [x3, #0xfe8]
    // 0xf6fa68: r0 = FocusableActionDetector()
    //     0xf6fa68: bl              #0xd11ac0  ; IsType_FocusableActionDetector_Stub
    // 0xf6fa6c: ldur            x3, [fp, #-8]
    // 0xf6fa70: LoadField: r2 = r3->field_7
    //     0xf6fa70: ldur            w2, [x3, #7]
    // 0xf6fa74: DecompressPointer r2
    //     0xf6fa74: add             x2, x2, HEAP, lsl #32
    // 0xf6fa78: ldur            x0, [fp, #-0x10]
    // 0xf6fa7c: r1 = Null
    //     0xf6fa7c: mov             x1, NULL
    // 0xf6fa80: cmp             w2, NULL
    // 0xf6fa84: b.eq            #0xf6faa8
    // 0xf6fa88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6fa88: ldur            w4, [x2, #0x17]
    // 0xf6fa8c: DecompressPointer r4
    //     0xf6fa8c: add             x4, x4, HEAP, lsl #32
    // 0xf6fa90: r8 = X0 bound StatefulWidget
    //     0xf6fa90: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6fa94: ldr             x8, [x8, #0x498]
    // 0xf6fa98: LoadField: r9 = r4->field_7
    //     0xf6fa98: ldur            x9, [x4, #7]
    // 0xf6fa9c: r3 = Null
    //     0xf6fa9c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ff8] Null
    //     0xf6faa0: ldr             x3, [x3, #0xff8]
    // 0xf6faa4: blr             x9
    // 0xf6faa8: ldur            x0, [fp, #-8]
    // 0xf6faac: LoadField: r1 = r0->field_b
    //     0xf6faac: ldur            w1, [x0, #0xb]
    // 0xf6fab0: DecompressPointer r1
    //     0xf6fab0: add             x1, x1, HEAP, lsl #32
    // 0xf6fab4: cmp             w1, NULL
    // 0xf6fab8: b.eq            #0xf6fbd4
    // 0xf6fabc: LoadField: r0 = r1->field_b
    //     0xf6fabc: ldur            w0, [x1, #0xb]
    // 0xf6fac0: DecompressPointer r0
    //     0xf6fac0: add             x0, x0, HEAP, lsl #32
    // 0xf6fac4: ldur            x1, [fp, #-0x10]
    // 0xf6fac8: LoadField: r2 = r1->field_b
    //     0xf6fac8: ldur            w2, [x1, #0xb]
    // 0xf6facc: DecompressPointer r2
    //     0xf6facc: add             x2, x2, HEAP, lsl #32
    // 0xf6fad0: cmp             w0, w2
    // 0xf6fad4: b.eq            #0xf6fbbc
    // 0xf6fad8: r0 = LoadStaticField(0x5e4)
    //     0xf6fad8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6fadc: ldr             x0, [x0, #0xbc8]
    // 0xf6fae0: cmp             w0, NULL
    // 0xf6fae4: b.eq            #0xf6fbd8
    // 0xf6fae8: LoadField: r3 = r0->field_53
    //     0xf6fae8: ldur            w3, [x0, #0x53]
    // 0xf6faec: DecompressPointer r3
    //     0xf6faec: add             x3, x3, HEAP, lsl #32
    // 0xf6faf0: stur            x3, [fp, #-0x10]
    // 0xf6faf4: LoadField: r0 = r3->field_7
    //     0xf6faf4: ldur            w0, [x3, #7]
    // 0xf6faf8: DecompressPointer r0
    //     0xf6faf8: add             x0, x0, HEAP, lsl #32
    // 0xf6fafc: ldur            x2, [fp, #-0x18]
    // 0xf6fb00: stur            x0, [fp, #-8]
    // 0xf6fb04: r1 = Function '<anonymous closure>':.
    //     0xf6fb04: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4008] AnonymousClosure: (0xf6fbdc), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::didUpdateWidget (0xf6f9ec)
    //     0xf6fb08: ldr             x1, [x1, #8]
    // 0xf6fb0c: r0 = AllocateClosure()
    //     0xf6fb0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6fb10: ldur            x2, [fp, #-8]
    // 0xf6fb14: mov             x3, x0
    // 0xf6fb18: r1 = Null
    //     0xf6fb18: mov             x1, NULL
    // 0xf6fb1c: stur            x3, [fp, #-8]
    // 0xf6fb20: cmp             w2, NULL
    // 0xf6fb24: b.eq            #0xf6fb44
    // 0xf6fb28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6fb28: ldur            w4, [x2, #0x17]
    // 0xf6fb2c: DecompressPointer r4
    //     0xf6fb2c: add             x4, x4, HEAP, lsl #32
    // 0xf6fb30: r8 = X0
    //     0xf6fb30: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf6fb34: LoadField: r9 = r4->field_7
    //     0xf6fb34: ldur            x9, [x4, #7]
    // 0xf6fb38: r3 = Null
    //     0xf6fb38: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4010] Null
    //     0xf6fb3c: ldr             x3, [x3, #0x10]
    // 0xf6fb40: blr             x9
    // 0xf6fb44: ldur            x0, [fp, #-0x10]
    // 0xf6fb48: LoadField: r1 = r0->field_b
    //     0xf6fb48: ldur            w1, [x0, #0xb]
    // 0xf6fb4c: LoadField: r2 = r0->field_f
    //     0xf6fb4c: ldur            w2, [x0, #0xf]
    // 0xf6fb50: DecompressPointer r2
    //     0xf6fb50: add             x2, x2, HEAP, lsl #32
    // 0xf6fb54: LoadField: r3 = r2->field_b
    //     0xf6fb54: ldur            w3, [x2, #0xb]
    // 0xf6fb58: r2 = LoadInt32Instr(r1)
    //     0xf6fb58: sbfx            x2, x1, #1, #0x1f
    // 0xf6fb5c: stur            x2, [fp, #-0x20]
    // 0xf6fb60: r1 = LoadInt32Instr(r3)
    //     0xf6fb60: sbfx            x1, x3, #1, #0x1f
    // 0xf6fb64: cmp             x2, x1
    // 0xf6fb68: b.ne            #0xf6fb74
    // 0xf6fb6c: mov             x1, x0
    // 0xf6fb70: r0 = _growToNextCapacity()
    //     0xf6fb70: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf6fb74: ldur            x2, [fp, #-0x10]
    // 0xf6fb78: ldur            x3, [fp, #-0x20]
    // 0xf6fb7c: add             x4, x3, #1
    // 0xf6fb80: lsl             x5, x4, #1
    // 0xf6fb84: StoreField: r2->field_b = r5
    //     0xf6fb84: stur            w5, [x2, #0xb]
    // 0xf6fb88: LoadField: r1 = r2->field_f
    //     0xf6fb88: ldur            w1, [x2, #0xf]
    // 0xf6fb8c: DecompressPointer r1
    //     0xf6fb8c: add             x1, x1, HEAP, lsl #32
    // 0xf6fb90: ldur            x0, [fp, #-8]
    // 0xf6fb94: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf6fb94: add             x25, x1, x3, lsl #2
    //     0xf6fb98: add             x25, x25, #0xf
    //     0xf6fb9c: str             w0, [x25]
    //     0xf6fba0: tbz             w0, #0, #0xf6fbbc
    //     0xf6fba4: ldurb           w16, [x1, #-1]
    //     0xf6fba8: ldurb           w17, [x0, #-1]
    //     0xf6fbac: and             x16, x17, x16, lsr #2
    //     0xf6fbb0: tst             x16, HEAP, lsr #32
    //     0xf6fbb4: b.eq            #0xf6fbbc
    //     0xf6fbb8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf6fbbc: r0 = Null
    //     0xf6fbbc: mov             x0, NULL
    // 0xf6fbc0: LeaveFrame
    //     0xf6fbc0: mov             SP, fp
    //     0xf6fbc4: ldp             fp, lr, [SP], #0x10
    // 0xf6fbc8: ret
    //     0xf6fbc8: ret             
    // 0xf6fbcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6fbcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6fbd0: b               #0xf6fa10
    // 0xf6fbd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fbd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6fbd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6fbd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0xf6fbdc, size: 0x60
    // 0xf6fbdc: EnterFrame
    //     0xf6fbdc: stp             fp, lr, [SP, #-0x10]!
    //     0xf6fbe0: mov             fp, SP
    // 0xf6fbe4: AllocStack(0x8)
    //     0xf6fbe4: sub             SP, SP, #8
    // 0xf6fbe8: SetupParameters([dynamic _ /* r0 */])
    //     0xf6fbe8: ldr             x0, [fp, #0x18]
    //     0xf6fbec: ldur            w1, [x0, #0x17]
    //     0xf6fbf0: add             x1, x1, HEAP, lsl #32
    // 0xf6fbf4: CheckStackOverflow
    //     0xf6fbf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6fbf8: cmp             SP, x16
    //     0xf6fbfc: b.ls            #0xf6fc34
    // 0xf6fc00: LoadField: r0 = r1->field_f
    //     0xf6fc00: ldur            w0, [x1, #0xf]
    // 0xf6fc04: DecompressPointer r0
    //     0xf6fc04: add             x0, x0, HEAP, lsl #32
    // 0xf6fc08: LoadField: r2 = r1->field_13
    //     0xf6fc08: ldur            w2, [x1, #0x13]
    // 0xf6fc0c: DecompressPointer r2
    //     0xf6fc0c: add             x2, x2, HEAP, lsl #32
    // 0xf6fc10: str             x2, [SP]
    // 0xf6fc14: mov             x1, x0
    // 0xf6fc18: r4 = const [0, 0x2, 0x1, 0x1, oldWidget, 0x1, null]
    //     0xf6fc18: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3480] List(7) [0, 0x2, 0x1, 0x1, "oldWidget", 0x1, Null]
    //     0xf6fc1c: ldr             x4, [x4, #0x480]
    // 0xf6fc20: r0 = _mayTriggerCallback()
    //     0xf6fc20: bl              #0xe01ff4  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback
    // 0xf6fc24: r0 = Null
    //     0xf6fc24: mov             x0, NULL
    // 0xf6fc28: LeaveFrame
    //     0xf6fc28: mov             SP, fp
    //     0xf6fc2c: ldp             fp, lr, [SP], #0x10
    // 0xf6fc30: ret
    //     0xf6fc30: ret             
    // 0xf6fc34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6fc34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6fc38: b               #0xf6fc00
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91668, size: 0x184
    // 0xf91668: EnterFrame
    //     0xf91668: stp             fp, lr, [SP, #-0x10]!
    //     0xf9166c: mov             fp, SP
    // 0xf91670: AllocStack(0x20)
    //     0xf91670: sub             SP, SP, #0x20
    // 0xf91674: SetupParameters(_FocusableActionDetectorState this /* r1 => r2, fp-0x8 */)
    //     0xf91674: mov             x2, x1
    //     0xf91678: stur            x1, [fp, #-8]
    // 0xf9167c: CheckStackOverflow
    //     0xf9167c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91680: cmp             SP, x16
    //     0xf91684: b.ls            #0xf917d8
    // 0xf91688: r1 = 1
    //     0xf91688: mov             x1, #1
    // 0xf9168c: r0 = AllocateContext()
    //     0xf9168c: bl              #0x13de838  ; AllocateContextStub
    // 0xf91690: mov             x1, x0
    // 0xf91694: ldur            x0, [fp, #-8]
    // 0xf91698: StoreField: r1->field_f = r0
    //     0xf91698: stur            w0, [x1, #0xf]
    // 0xf9169c: r2 = LoadStaticField(0x5e4)
    //     0xf9169c: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0xf916a0: ldr             x2, [x2, #0xbc8]
    // 0xf916a4: cmp             w2, NULL
    // 0xf916a8: b.eq            #0xf917e0
    // 0xf916ac: LoadField: r3 = r2->field_53
    //     0xf916ac: ldur            w3, [x2, #0x53]
    // 0xf916b0: DecompressPointer r3
    //     0xf916b0: add             x3, x3, HEAP, lsl #32
    // 0xf916b4: stur            x3, [fp, #-0x18]
    // 0xf916b8: LoadField: r4 = r3->field_7
    //     0xf916b8: ldur            w4, [x3, #7]
    // 0xf916bc: DecompressPointer r4
    //     0xf916bc: add             x4, x4, HEAP, lsl #32
    // 0xf916c0: mov             x2, x1
    // 0xf916c4: stur            x4, [fp, #-0x10]
    // 0xf916c8: r1 = Function '<anonymous closure>':.
    //     0xf916c8: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4030] AnonymousClosure: (0xf917ec), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::initState (0xf91668)
    //     0xf916cc: ldr             x1, [x1, #0x30]
    // 0xf916d0: r0 = AllocateClosure()
    //     0xf916d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf916d4: ldur            x2, [fp, #-0x10]
    // 0xf916d8: mov             x3, x0
    // 0xf916dc: r1 = Null
    //     0xf916dc: mov             x1, NULL
    // 0xf916e0: stur            x3, [fp, #-0x10]
    // 0xf916e4: cmp             w2, NULL
    // 0xf916e8: b.eq            #0xf91708
    // 0xf916ec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf916ec: ldur            w4, [x2, #0x17]
    // 0xf916f0: DecompressPointer r4
    //     0xf916f0: add             x4, x4, HEAP, lsl #32
    // 0xf916f4: r8 = X0
    //     0xf916f4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf916f8: LoadField: r9 = r4->field_7
    //     0xf916f8: ldur            x9, [x4, #7]
    // 0xf916fc: r3 = Null
    //     0xf916fc: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4038] Null
    //     0xf91700: ldr             x3, [x3, #0x38]
    // 0xf91704: blr             x9
    // 0xf91708: ldur            x0, [fp, #-0x18]
    // 0xf9170c: LoadField: r1 = r0->field_b
    //     0xf9170c: ldur            w1, [x0, #0xb]
    // 0xf91710: LoadField: r2 = r0->field_f
    //     0xf91710: ldur            w2, [x0, #0xf]
    // 0xf91714: DecompressPointer r2
    //     0xf91714: add             x2, x2, HEAP, lsl #32
    // 0xf91718: LoadField: r3 = r2->field_b
    //     0xf91718: ldur            w3, [x2, #0xb]
    // 0xf9171c: r2 = LoadInt32Instr(r1)
    //     0xf9171c: sbfx            x2, x1, #1, #0x1f
    // 0xf91720: stur            x2, [fp, #-0x20]
    // 0xf91724: r1 = LoadInt32Instr(r3)
    //     0xf91724: sbfx            x1, x3, #1, #0x1f
    // 0xf91728: cmp             x2, x1
    // 0xf9172c: b.ne            #0xf91738
    // 0xf91730: mov             x1, x0
    // 0xf91734: r0 = _growToNextCapacity()
    //     0xf91734: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf91738: ldur            x0, [fp, #-0x18]
    // 0xf9173c: ldur            x2, [fp, #-0x20]
    // 0xf91740: add             x1, x2, #1
    // 0xf91744: lsl             x3, x1, #1
    // 0xf91748: StoreField: r0->field_b = r3
    //     0xf91748: stur            w3, [x0, #0xb]
    // 0xf9174c: LoadField: r1 = r0->field_f
    //     0xf9174c: ldur            w1, [x0, #0xf]
    // 0xf91750: DecompressPointer r1
    //     0xf91750: add             x1, x1, HEAP, lsl #32
    // 0xf91754: ldur            x0, [fp, #-0x10]
    // 0xf91758: ArrayStore: r1[r2] = r0  ; List_4
    //     0xf91758: add             x25, x1, x2, lsl #2
    //     0xf9175c: add             x25, x25, #0xf
    //     0xf91760: str             w0, [x25]
    //     0xf91764: tbz             w0, #0, #0xf91780
    //     0xf91768: ldurb           w16, [x1, #-1]
    //     0xf9176c: ldurb           w17, [x0, #-1]
    //     0xf91770: and             x16, x17, x16, lsr #2
    //     0xf91774: tst             x16, HEAP, lsr #32
    //     0xf91778: b.eq            #0xf91780
    //     0xf9177c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf91780: r0 = LoadStaticField(0x6a0)
    //     0xf91780: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf91784: ldr             x0, [x0, #0xd40]
    // 0xf91788: cmp             w0, NULL
    // 0xf9178c: b.eq            #0xf917e4
    // 0xf91790: LoadField: r1 = r0->field_ef
    //     0xf91790: ldur            w1, [x0, #0xef]
    // 0xf91794: DecompressPointer r1
    //     0xf91794: add             x1, x1, HEAP, lsl #32
    // 0xf91798: cmp             w1, NULL
    // 0xf9179c: b.eq            #0xf917e8
    // 0xf917a0: LoadField: r0 = r1->field_13
    //     0xf917a0: ldur            w0, [x1, #0x13]
    // 0xf917a4: DecompressPointer r0
    //     0xf917a4: add             x0, x0, HEAP, lsl #32
    // 0xf917a8: ldur            x2, [fp, #-8]
    // 0xf917ac: stur            x0, [fp, #-0x10]
    // 0xf917b0: r1 = Function '_handleFocusHighlightModeChange@66441002':.
    //     0xf917b0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4020] AnonymousClosure: (0xf9198c), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleFocusHighlightModeChange (0xf919c8)
    //     0xf917b4: ldr             x1, [x1, #0x20]
    // 0xf917b8: r0 = AllocateClosure()
    //     0xf917b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf917bc: ldur            x1, [fp, #-0x10]
    // 0xf917c0: mov             x2, x0
    // 0xf917c4: r0 = addHighlightModeListener()
    //     0xf917c4: bl              #0xf7a230  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::addHighlightModeListener
    // 0xf917c8: r0 = Null
    //     0xf917c8: mov             x0, NULL
    // 0xf917cc: LeaveFrame
    //     0xf917cc: mov             SP, fp
    //     0xf917d0: ldp             fp, lr, [SP], #0x10
    // 0xf917d4: ret
    //     0xf917d4: ret             
    // 0xf917d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf917d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf917dc: b               #0xf91688
    // 0xf917e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf917e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf917e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf917e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf917e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf917e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0xf917ec, size: 0x8c
    // 0xf917ec: EnterFrame
    //     0xf917ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf917f0: mov             fp, SP
    // 0xf917f4: AllocStack(0x8)
    //     0xf917f4: sub             SP, SP, #8
    // 0xf917f8: SetupParameters([dynamic _ /* r0 */])
    //     0xf917f8: ldr             x0, [fp, #0x18]
    //     0xf917fc: ldur            w2, [x0, #0x17]
    //     0xf91800: add             x2, x2, HEAP, lsl #32
    //     0xf91804: stur            x2, [fp, #-8]
    // 0xf91808: CheckStackOverflow
    //     0xf91808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9180c: cmp             SP, x16
    //     0xf91810: b.ls            #0xf91868
    // 0xf91814: r0 = LoadStaticField(0x6a0)
    //     0xf91814: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf91818: ldr             x0, [x0, #0xd40]
    // 0xf9181c: cmp             w0, NULL
    // 0xf91820: b.eq            #0xf91870
    // 0xf91824: LoadField: r1 = r0->field_ef
    //     0xf91824: ldur            w1, [x0, #0xef]
    // 0xf91828: DecompressPointer r1
    //     0xf91828: add             x1, x1, HEAP, lsl #32
    // 0xf9182c: cmp             w1, NULL
    // 0xf91830: b.eq            #0xf91874
    // 0xf91834: LoadField: r0 = r1->field_13
    //     0xf91834: ldur            w0, [x1, #0x13]
    // 0xf91838: DecompressPointer r0
    //     0xf91838: add             x0, x0, HEAP, lsl #32
    // 0xf9183c: LoadField: r1 = r0->field_23
    //     0xf9183c: ldur            w1, [x0, #0x23]
    // 0xf91840: DecompressPointer r1
    //     0xf91840: add             x1, x1, HEAP, lsl #32
    // 0xf91844: r0 = highlightMode()
    //     0xf91844: bl              #0x83bde4  ; [package:flutter/src/widgets/focus_manager.dart] _HighlightModeManager::highlightMode
    // 0xf91848: ldur            x0, [fp, #-8]
    // 0xf9184c: LoadField: r1 = r0->field_f
    //     0xf9184c: ldur            w1, [x0, #0xf]
    // 0xf91850: DecompressPointer r1
    //     0xf91850: add             x1, x1, HEAP, lsl #32
    // 0xf91854: r0 = _updateHighlightMode()
    //     0xf91854: bl              #0xf91878  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_updateHighlightMode
    // 0xf91858: r0 = Null
    //     0xf91858: mov             x0, NULL
    // 0xf9185c: LeaveFrame
    //     0xf9185c: mov             SP, fp
    //     0xf91860: ldp             fp, lr, [SP], #0x10
    // 0xf91864: ret
    //     0xf91864: ret             
    // 0xf91868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91868: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf9186c: b               #0xf91814
    // 0xf91870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91870: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91874: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateHighlightMode(/* No info */) {
    // ** addr: 0xf91878, size: 0x6c
    // 0xf91878: EnterFrame
    //     0xf91878: stp             fp, lr, [SP, #-0x10]!
    //     0xf9187c: mov             fp, SP
    // 0xf91880: AllocStack(0x10)
    //     0xf91880: sub             SP, SP, #0x10
    // 0xf91884: SetupParameters(_FocusableActionDetectorState this /* r1 => r1, fp-0x8 */)
    //     0xf91884: stur            x1, [fp, #-8]
    // 0xf91888: CheckStackOverflow
    //     0xf91888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9188c: cmp             SP, x16
    //     0xf91890: b.ls            #0xf918dc
    // 0xf91894: r1 = 1
    //     0xf91894: mov             x1, #1
    // 0xf91898: r0 = AllocateContext()
    //     0xf91898: bl              #0x13de838  ; AllocateContextStub
    // 0xf9189c: mov             x1, x0
    // 0xf918a0: ldur            x0, [fp, #-8]
    // 0xf918a4: StoreField: r1->field_f = r0
    //     0xf918a4: stur            w0, [x1, #0xf]
    // 0xf918a8: mov             x2, x1
    // 0xf918ac: r1 = Function '<anonymous closure>':.
    //     0xf918ac: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4028] AnonymousClosure: (0xf918e4), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_updateHighlightMode (0xf91878)
    //     0xf918b0: ldr             x1, [x1, #0x28]
    // 0xf918b4: r0 = AllocateClosure()
    //     0xf918b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf918b8: str             x0, [SP]
    // 0xf918bc: ldur            x1, [fp, #-8]
    // 0xf918c0: r4 = const [0, 0x2, 0x1, 0x1, task, 0x1, null]
    //     0xf918c0: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3f80] List(7) [0, 0x2, 0x1, 0x1, "task", 0x1, Null]
    //     0xf918c4: ldr             x4, [x4, #0xf80]
    // 0xf918c8: r0 = _mayTriggerCallback()
    //     0xf918c8: bl              #0xe01ff4  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_mayTriggerCallback
    // 0xf918cc: r0 = Null
    //     0xf918cc: mov             x0, NULL
    // 0xf918d0: LeaveFrame
    //     0xf918d0: mov             SP, fp
    //     0xf918d4: ldp             fp, lr, [SP], #0x10
    // 0xf918d8: ret
    //     0xf918d8: ret             
    // 0xf918dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf918dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf918e0: b               #0xf91894
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf918e4, size: 0xa8
    // 0xf918e4: EnterFrame
    //     0xf918e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf918e8: mov             fp, SP
    // 0xf918ec: AllocStack(0x8)
    //     0xf918ec: sub             SP, SP, #8
    // 0xf918f0: SetupParameters([dynamic _ /* r0 */])
    //     0xf918f0: ldr             x0, [fp, #0x10]
    //     0xf918f4: ldur            w1, [x0, #0x17]
    //     0xf918f8: add             x1, x1, HEAP, lsl #32
    // 0xf918fc: CheckStackOverflow
    //     0xf918fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91900: cmp             SP, x16
    //     0xf91904: b.ls            #0xf9197c
    // 0xf91908: LoadField: r0 = r1->field_f
    //     0xf91908: ldur            w0, [x1, #0xf]
    // 0xf9190c: DecompressPointer r0
    //     0xf9190c: add             x0, x0, HEAP, lsl #32
    // 0xf91910: stur            x0, [fp, #-8]
    // 0xf91914: r1 = LoadStaticField(0x6a0)
    //     0xf91914: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xf91918: ldr             x1, [x1, #0xd40]
    // 0xf9191c: cmp             w1, NULL
    // 0xf91920: b.eq            #0xf91984
    // 0xf91924: LoadField: r2 = r1->field_ef
    //     0xf91924: ldur            w2, [x1, #0xef]
    // 0xf91928: DecompressPointer r2
    //     0xf91928: add             x2, x2, HEAP, lsl #32
    // 0xf9192c: cmp             w2, NULL
    // 0xf91930: b.eq            #0xf91988
    // 0xf91934: LoadField: r1 = r2->field_13
    //     0xf91934: ldur            w1, [x2, #0x13]
    // 0xf91938: DecompressPointer r1
    //     0xf91938: add             x1, x1, HEAP, lsl #32
    // 0xf9193c: LoadField: r2 = r1->field_23
    //     0xf9193c: ldur            w2, [x1, #0x23]
    // 0xf91940: DecompressPointer r2
    //     0xf91940: add             x2, x2, HEAP, lsl #32
    // 0xf91944: mov             x1, x2
    // 0xf91948: r0 = highlightMode()
    //     0xf91948: bl              #0x83bde4  ; [package:flutter/src/widgets/focus_manager.dart] _HighlightModeManager::highlightMode
    // 0xf9194c: LoadField: r1 = r0->field_7
    //     0xf9194c: ldur            x1, [x0, #7]
    // 0xf91950: cmp             x1, #0
    // 0xf91954: b.gt            #0xf91960
    // 0xf91958: r2 = false
    //     0xf91958: add             x2, NULL, #0x30  ; false
    // 0xf9195c: b               #0xf91964
    // 0xf91960: r2 = true
    //     0xf91960: add             x2, NULL, #0x20  ; true
    // 0xf91964: ldur            x1, [fp, #-8]
    // 0xf91968: StoreField: r1->field_13 = r2
    //     0xf91968: stur            w2, [x1, #0x13]
    // 0xf9196c: r0 = Null
    //     0xf9196c: mov             x0, NULL
    // 0xf91970: LeaveFrame
    //     0xf91970: mov             SP, fp
    //     0xf91974: ldp             fp, lr, [SP], #0x10
    // 0xf91978: ret
    //     0xf91978: ret             
    // 0xf9197c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9197c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91980: b               #0xf91908
    // 0xf91984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91984: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91988: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusHighlightModeChange(dynamic, FocusHighlightMode) {
    // ** addr: 0xf9198c, size: 0x3c
    // 0xf9198c: EnterFrame
    //     0xf9198c: stp             fp, lr, [SP, #-0x10]!
    //     0xf91990: mov             fp, SP
    // 0xf91994: ldr             x0, [fp, #0x18]
    // 0xf91998: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf91998: ldur            w1, [x0, #0x17]
    // 0xf9199c: DecompressPointer r1
    //     0xf9199c: add             x1, x1, HEAP, lsl #32
    // 0xf919a0: CheckStackOverflow
    //     0xf919a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf919a4: cmp             SP, x16
    //     0xf919a8: b.ls            #0xf919c0
    // 0xf919ac: ldr             x2, [fp, #0x10]
    // 0xf919b0: r0 = _handleFocusHighlightModeChange()
    //     0xf919b0: bl              #0xf919c8  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleFocusHighlightModeChange
    // 0xf919b4: LeaveFrame
    //     0xf919b4: mov             SP, fp
    //     0xf919b8: ldp             fp, lr, [SP], #0x10
    // 0xf919bc: ret
    //     0xf919bc: ret             
    // 0xf919c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf919c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf919c4: b               #0xf919ac
  }
  _ _handleFocusHighlightModeChange(/* No info */) {
    // ** addr: 0xf919c8, size: 0x50
    // 0xf919c8: EnterFrame
    //     0xf919c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf919cc: mov             fp, SP
    // 0xf919d0: CheckStackOverflow
    //     0xf919d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf919d4: cmp             SP, x16
    //     0xf919d8: b.ls            #0xf91a10
    // 0xf919dc: LoadField: r0 = r1->field_f
    //     0xf919dc: ldur            w0, [x1, #0xf]
    // 0xf919e0: DecompressPointer r0
    //     0xf919e0: add             x0, x0, HEAP, lsl #32
    // 0xf919e4: cmp             w0, NULL
    // 0xf919e8: b.ne            #0xf919fc
    // 0xf919ec: r0 = Null
    //     0xf919ec: mov             x0, NULL
    // 0xf919f0: LeaveFrame
    //     0xf919f0: mov             SP, fp
    //     0xf919f4: ldp             fp, lr, [SP], #0x10
    // 0xf919f8: ret
    //     0xf919f8: ret             
    // 0xf919fc: r0 = _updateHighlightMode()
    //     0xf919fc: bl              #0xf91878  ; [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_updateHighlightMode
    // 0xf91a00: r0 = Null
    //     0xf91a00: mov             x0, NULL
    // 0xf91a04: LeaveFrame
    //     0xf91a04: mov             SP, fp
    //     0xf91a08: ldp             fp, lr, [SP], #0x10
    // 0xf91a0c: ret
    //     0xf91a0c: ret             
    // 0xf91a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91a10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91a14: b               #0xf919dc
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e63f0, size: 0x80
    // 0x10e63f0: EnterFrame
    //     0x10e63f0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e63f4: mov             fp, SP
    // 0x10e63f8: AllocStack(0x8)
    //     0x10e63f8: sub             SP, SP, #8
    // 0x10e63fc: SetupParameters(_FocusableActionDetectorState this /* r1 => r2 */)
    //     0x10e63fc: mov             x2, x1
    // 0x10e6400: CheckStackOverflow
    //     0x10e6400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e6404: cmp             SP, x16
    //     0x10e6408: b.ls            #0x10e6460
    // 0x10e640c: r0 = LoadStaticField(0x6a0)
    //     0x10e640c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e6410: ldr             x0, [x0, #0xd40]
    // 0x10e6414: cmp             w0, NULL
    // 0x10e6418: b.eq            #0x10e6468
    // 0x10e641c: LoadField: r1 = r0->field_ef
    //     0x10e641c: ldur            w1, [x0, #0xef]
    // 0x10e6420: DecompressPointer r1
    //     0x10e6420: add             x1, x1, HEAP, lsl #32
    // 0x10e6424: cmp             w1, NULL
    // 0x10e6428: b.eq            #0x10e646c
    // 0x10e642c: LoadField: r0 = r1->field_13
    //     0x10e642c: ldur            w0, [x1, #0x13]
    // 0x10e6430: DecompressPointer r0
    //     0x10e6430: add             x0, x0, HEAP, lsl #32
    // 0x10e6434: stur            x0, [fp, #-8]
    // 0x10e6438: r1 = Function '_handleFocusHighlightModeChange@66441002':.
    //     0x10e6438: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4020] AnonymousClosure: (0xf9198c), in [package:flutter/src/widgets/actions.dart] _FocusableActionDetectorState::_handleFocusHighlightModeChange (0xf919c8)
    //     0x10e643c: ldr             x1, [x1, #0x20]
    // 0x10e6440: r0 = AllocateClosure()
    //     0x10e6440: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e6444: ldur            x1, [fp, #-8]
    // 0x10e6448: mov             x2, x0
    // 0x10e644c: r0 = removeHighlightModeListener()
    //     0x10e644c: bl              #0x10dcd60  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::removeHighlightModeListener
    // 0x10e6450: r0 = Null
    //     0x10e6450: mov             x0, NULL
    // 0x10e6454: LeaveFrame
    //     0x10e6454: mov             SP, fp
    //     0x10e6458: ldp             fp, lr, [SP], #0x10
    // 0x10e645c: ret
    //     0x10e645c: ret             
    // 0x10e6460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e6460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e6464: b               #0x10e640c
    // 0x10e6468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e6468: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e646c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e646c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5451, size: 0x1c, field offset: 0x14
class _ActionsState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xe01bec, size: 0x6c
    // 0xe01bec: EnterFrame
    //     0xe01bec: stp             fp, lr, [SP, #-0x10]!
    //     0xe01bf0: mov             fp, SP
    // 0xe01bf4: AllocStack(0x18)
    //     0xe01bf4: sub             SP, SP, #0x18
    // 0xe01bf8: LoadField: r0 = r1->field_b
    //     0xe01bf8: ldur            w0, [x1, #0xb]
    // 0xe01bfc: DecompressPointer r0
    //     0xe01bfc: add             x0, x0, HEAP, lsl #32
    // 0xe01c00: cmp             w0, NULL
    // 0xe01c04: b.eq            #0xe01c54
    // 0xe01c08: LoadField: r2 = r0->field_f
    //     0xe01c08: ldur            w2, [x0, #0xf]
    // 0xe01c0c: DecompressPointer r2
    //     0xe01c0c: add             x2, x2, HEAP, lsl #32
    // 0xe01c10: stur            x2, [fp, #-0x18]
    // 0xe01c14: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xe01c14: ldur            w3, [x1, #0x17]
    // 0xe01c18: DecompressPointer r3
    //     0xe01c18: add             x3, x3, HEAP, lsl #32
    // 0xe01c1c: stur            x3, [fp, #-0x10]
    // 0xe01c20: LoadField: r1 = r0->field_13
    //     0xe01c20: ldur            w1, [x0, #0x13]
    // 0xe01c24: DecompressPointer r1
    //     0xe01c24: add             x1, x1, HEAP, lsl #32
    // 0xe01c28: stur            x1, [fp, #-8]
    // 0xe01c2c: r0 = _ActionsScope()
    //     0xe01c2c: bl              #0xe01c58  ; Allocate_ActionsScopeStub -> _ActionsScope (size=0x1c)
    // 0xe01c30: ldur            x1, [fp, #-0x18]
    // 0xe01c34: StoreField: r0->field_13 = r1
    //     0xe01c34: stur            w1, [x0, #0x13]
    // 0xe01c38: ldur            x1, [fp, #-0x10]
    // 0xe01c3c: ArrayStore: r0[0] = r1  ; List_4
    //     0xe01c3c: stur            w1, [x0, #0x17]
    // 0xe01c40: ldur            x1, [fp, #-8]
    // 0xe01c44: StoreField: r0->field_b = r1
    //     0xe01c44: stur            w1, [x0, #0xb]
    // 0xe01c48: LeaveFrame
    //     0xe01c48: mov             SP, fp
    //     0xe01c4c: ldp             fp, lr, [SP], #0x10
    // 0xe01c50: ret
    //     0xe01c50: ret             
    // 0xe01c54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01c54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6f5a8, size: 0xc0
    // 0xf6f5a8: EnterFrame
    //     0xf6f5a8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f5ac: mov             fp, SP
    // 0xf6f5b0: AllocStack(0x10)
    //     0xf6f5b0: sub             SP, SP, #0x10
    // 0xf6f5b4: SetupParameters(_ActionsState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6f5b4: mov             x4, x1
    //     0xf6f5b8: mov             x3, x2
    //     0xf6f5bc: stur            x1, [fp, #-8]
    //     0xf6f5c0: stur            x2, [fp, #-0x10]
    // 0xf6f5c4: CheckStackOverflow
    //     0xf6f5c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f5c8: cmp             SP, x16
    //     0xf6f5cc: b.ls            #0xf6f660
    // 0xf6f5d0: mov             x0, x3
    // 0xf6f5d4: r2 = Null
    //     0xf6f5d4: mov             x2, NULL
    // 0xf6f5d8: r1 = Null
    //     0xf6f5d8: mov             x1, NULL
    // 0xf6f5dc: r4 = 60
    //     0xf6f5dc: mov             x4, #0x3c
    // 0xf6f5e0: branchIfSmi(r0, 0xf6f5ec)
    //     0xf6f5e0: tbz             w0, #0, #0xf6f5ec
    // 0xf6f5e4: r4 = LoadClassIdInstr(r0)
    //     0xf6f5e4: ldur            x4, [x0, #-1]
    //     0xf6f5e8: ubfx            x4, x4, #0xc, #0x14
    // 0xf6f5ec: r17 = 6410
    //     0xf6f5ec: mov             x17, #0x190a
    // 0xf6f5f0: cmp             x4, x17
    // 0xf6f5f4: b.eq            #0xf6f60c
    // 0xf6f5f8: r8 = Actions
    //     0xf6f5f8: add             x8, PP, #0x99, lsl #12  ; [pp+0x99eb8] Type: Actions
    //     0xf6f5fc: ldr             x8, [x8, #0xeb8]
    // 0xf6f600: r3 = Null
    //     0xf6f600: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ec0] Null
    //     0xf6f604: ldr             x3, [x3, #0xec0]
    // 0xf6f608: r0 = Actions()
    //     0xf6f608: bl              #0x879918  ; IsType_Actions_Stub
    // 0xf6f60c: ldur            x3, [fp, #-8]
    // 0xf6f610: LoadField: r2 = r3->field_7
    //     0xf6f610: ldur            w2, [x3, #7]
    // 0xf6f614: DecompressPointer r2
    //     0xf6f614: add             x2, x2, HEAP, lsl #32
    // 0xf6f618: ldur            x0, [fp, #-0x10]
    // 0xf6f61c: r1 = Null
    //     0xf6f61c: mov             x1, NULL
    // 0xf6f620: cmp             w2, NULL
    // 0xf6f624: b.eq            #0xf6f648
    // 0xf6f628: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6f628: ldur            w4, [x2, #0x17]
    // 0xf6f62c: DecompressPointer r4
    //     0xf6f62c: add             x4, x4, HEAP, lsl #32
    // 0xf6f630: r8 = X0 bound StatefulWidget
    //     0xf6f630: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6f634: ldr             x8, [x8, #0x498]
    // 0xf6f638: LoadField: r9 = r4->field_7
    //     0xf6f638: ldur            x9, [x4, #7]
    // 0xf6f63c: r3 = Null
    //     0xf6f63c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ed0] Null
    //     0xf6f640: ldr             x3, [x3, #0xed0]
    // 0xf6f644: blr             x9
    // 0xf6f648: ldur            x1, [fp, #-8]
    // 0xf6f64c: r0 = _updateActionListeners()
    //     0xf6f64c: bl              #0xf6f668  ; [package:flutter/src/widgets/actions.dart] _ActionsState::_updateActionListeners
    // 0xf6f650: r0 = Null
    //     0xf6f650: mov             x0, NULL
    // 0xf6f654: LeaveFrame
    //     0xf6f654: mov             SP, fp
    //     0xf6f658: ldp             fp, lr, [SP], #0x10
    // 0xf6f65c: ret
    //     0xf6f65c: ret             
    // 0xf6f660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f664: b               #0xf6f5d0
  }
  _ _updateActionListeners(/* No info */) {
    // ** addr: 0xf6f668, size: 0x28c
    // 0xf6f668: EnterFrame
    //     0xf6f668: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f66c: mov             fp, SP
    // 0xf6f670: AllocStack(0x38)
    //     0xf6f670: sub             SP, SP, #0x38
    // 0xf6f674: SetupParameters(_ActionsState this /* r1 => r2, fp-0x10 */)
    //     0xf6f674: mov             x2, x1
    //     0xf6f678: stur            x1, [fp, #-0x10]
    // 0xf6f67c: CheckStackOverflow
    //     0xf6f67c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f680: cmp             SP, x16
    //     0xf6f684: b.ls            #0xf6f8d0
    // 0xf6f688: LoadField: r0 = r2->field_b
    //     0xf6f688: ldur            w0, [x2, #0xb]
    // 0xf6f68c: DecompressPointer r0
    //     0xf6f68c: add             x0, x0, HEAP, lsl #32
    // 0xf6f690: cmp             w0, NULL
    // 0xf6f694: b.eq            #0xf6f8d8
    // 0xf6f698: LoadField: r3 = r0->field_f
    //     0xf6f698: ldur            w3, [x0, #0xf]
    // 0xf6f69c: DecompressPointer r3
    //     0xf6f69c: add             x3, x3, HEAP, lsl #32
    // 0xf6f6a0: stur            x3, [fp, #-8]
    // 0xf6f6a4: r1 = <Action<Intent>>
    //     0xf6f6a4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90398] TypeArguments: <Action<Intent>>
    //     0xf6f6a8: ldr             x1, [x1, #0x398]
    // 0xf6f6ac: r0 = _CompactValuesIterable()
    //     0xf6f6ac: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xf6f6b0: mov             x1, x0
    // 0xf6f6b4: ldur            x0, [fp, #-8]
    // 0xf6f6b8: StoreField: r1->field_b = r0
    //     0xf6f6b8: stur            w0, [x1, #0xb]
    // 0xf6f6bc: r0 = toSet()
    //     0xf6f6bc: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xf6f6c0: mov             x3, x0
    // 0xf6f6c4: ldur            x0, [fp, #-0x10]
    // 0xf6f6c8: stur            x3, [fp, #-8]
    // 0xf6f6cc: LoadField: r1 = r0->field_13
    //     0xf6f6cc: ldur            w1, [x0, #0x13]
    // 0xf6f6d0: DecompressPointer r1
    //     0xf6f6d0: add             x1, x1, HEAP, lsl #32
    // 0xf6f6d4: cmp             w1, NULL
    // 0xf6f6d8: b.eq            #0xf6f8dc
    // 0xf6f6dc: mov             x2, x3
    // 0xf6f6e0: r0 = difference()
    //     0xf6f6e0: bl              #0x1140a2c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::difference
    // 0xf6f6e4: mov             x3, x0
    // 0xf6f6e8: ldur            x0, [fp, #-0x10]
    // 0xf6f6ec: stur            x3, [fp, #-0x18]
    // 0xf6f6f0: LoadField: r2 = r0->field_13
    //     0xf6f6f0: ldur            w2, [x0, #0x13]
    // 0xf6f6f4: DecompressPointer r2
    //     0xf6f6f4: add             x2, x2, HEAP, lsl #32
    // 0xf6f6f8: cmp             w2, NULL
    // 0xf6f6fc: b.eq            #0xf6f8e0
    // 0xf6f700: ldur            x1, [fp, #-8]
    // 0xf6f704: r0 = difference()
    //     0xf6f704: bl              #0x1140a2c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::difference
    // 0xf6f708: ldur            x1, [fp, #-0x18]
    // 0xf6f70c: stur            x0, [fp, #-0x18]
    // 0xf6f710: r0 = iterator()
    //     0xf6f710: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0xf6f714: ldur            x2, [fp, #-0x10]
    // 0xf6f718: r1 = Function '_handleActionChanged@66441002':.
    //     0xf6f718: add             x1, PP, #0x99, lsl #12  ; [pp+0x99e98] AnonymousClosure: (0xf6f8f4), in [package:flutter/src/widgets/actions.dart] _ActionsState::_handleActionChanged (0xf6f930)
    //     0xf6f71c: ldr             x1, [x1, #0xe98]
    // 0xf6f720: stur            x0, [fp, #-0x20]
    // 0xf6f724: r0 = AllocateClosure()
    //     0xf6f724: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6f728: mov             x2, x0
    // 0xf6f72c: ldur            x0, [fp, #-0x20]
    // 0xf6f730: stur            x2, [fp, #-0x30]
    // 0xf6f734: LoadField: r3 = r0->field_7
    //     0xf6f734: ldur            w3, [x0, #7]
    // 0xf6f738: DecompressPointer r3
    //     0xf6f738: add             x3, x3, HEAP, lsl #32
    // 0xf6f73c: stur            x3, [fp, #-0x28]
    // 0xf6f740: CheckStackOverflow
    //     0xf6f740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f744: cmp             SP, x16
    //     0xf6f748: b.ls            #0xf6f8e4
    // 0xf6f74c: mov             x1, x0
    // 0xf6f750: r0 = moveNext()
    //     0xf6f750: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xf6f754: tbnz            w0, #4, #0xf6f7d4
    // 0xf6f758: ldur            x3, [fp, #-0x20]
    // 0xf6f75c: LoadField: r4 = r3->field_33
    //     0xf6f75c: ldur            w4, [x3, #0x33]
    // 0xf6f760: DecompressPointer r4
    //     0xf6f760: add             x4, x4, HEAP, lsl #32
    // 0xf6f764: stur            x4, [fp, #-0x38]
    // 0xf6f768: cmp             w4, NULL
    // 0xf6f76c: b.ne            #0xf6f7a0
    // 0xf6f770: mov             x0, x4
    // 0xf6f774: ldur            x2, [fp, #-0x28]
    // 0xf6f778: r1 = Null
    //     0xf6f778: mov             x1, NULL
    // 0xf6f77c: cmp             w2, NULL
    // 0xf6f780: b.eq            #0xf6f7a0
    // 0xf6f784: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6f784: ldur            w4, [x2, #0x17]
    // 0xf6f788: DecompressPointer r4
    //     0xf6f788: add             x4, x4, HEAP, lsl #32
    // 0xf6f78c: r8 = X0
    //     0xf6f78c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf6f790: LoadField: r9 = r4->field_7
    //     0xf6f790: ldur            x9, [x4, #7]
    // 0xf6f794: r3 = Null
    //     0xf6f794: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ee0] Null
    //     0xf6f798: ldr             x3, [x3, #0xee0]
    // 0xf6f79c: blr             x9
    // 0xf6f7a0: ldur            x1, [fp, #-0x38]
    // 0xf6f7a4: r0 = LoadClassIdInstr(r1)
    //     0xf6f7a4: ldur            x0, [x1, #-1]
    //     0xf6f7a8: ubfx            x0, x0, #0xc, #0x14
    // 0xf6f7ac: ldur            x2, [fp, #-0x30]
    // 0xf6f7b0: r0 = GDT[cid_x0 + 0x12387]()
    //     0xf6f7b0: mov             x17, #0x2387
    //     0xf6f7b4: movk            x17, #1, lsl #16
    //     0xf6f7b8: add             lr, x0, x17
    //     0xf6f7bc: ldr             lr, [x21, lr, lsl #3]
    //     0xf6f7c0: blr             lr
    // 0xf6f7c4: ldur            x0, [fp, #-0x20]
    // 0xf6f7c8: ldur            x3, [fp, #-0x28]
    // 0xf6f7cc: ldur            x2, [fp, #-0x30]
    // 0xf6f7d0: b               #0xf6f740
    // 0xf6f7d4: ldur            x1, [fp, #-0x18]
    // 0xf6f7d8: r0 = iterator()
    //     0xf6f7d8: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0xf6f7dc: ldur            x2, [fp, #-0x10]
    // 0xf6f7e0: r1 = Function '_handleActionChanged@66441002':.
    //     0xf6f7e0: add             x1, PP, #0x99, lsl #12  ; [pp+0x99e98] AnonymousClosure: (0xf6f8f4), in [package:flutter/src/widgets/actions.dart] _ActionsState::_handleActionChanged (0xf6f930)
    //     0xf6f7e4: ldr             x1, [x1, #0xe98]
    // 0xf6f7e8: stur            x0, [fp, #-0x18]
    // 0xf6f7ec: r0 = AllocateClosure()
    //     0xf6f7ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6f7f0: mov             x2, x0
    // 0xf6f7f4: ldur            x0, [fp, #-0x18]
    // 0xf6f7f8: stur            x2, [fp, #-0x28]
    // 0xf6f7fc: LoadField: r3 = r0->field_7
    //     0xf6f7fc: ldur            w3, [x0, #7]
    // 0xf6f800: DecompressPointer r3
    //     0xf6f800: add             x3, x3, HEAP, lsl #32
    // 0xf6f804: stur            x3, [fp, #-0x20]
    // 0xf6f808: CheckStackOverflow
    //     0xf6f808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f80c: cmp             SP, x16
    //     0xf6f810: b.ls            #0xf6f8ec
    // 0xf6f814: mov             x1, x0
    // 0xf6f818: r0 = moveNext()
    //     0xf6f818: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xf6f81c: tbnz            w0, #4, #0xf6f89c
    // 0xf6f820: ldur            x3, [fp, #-0x18]
    // 0xf6f824: LoadField: r4 = r3->field_33
    //     0xf6f824: ldur            w4, [x3, #0x33]
    // 0xf6f828: DecompressPointer r4
    //     0xf6f828: add             x4, x4, HEAP, lsl #32
    // 0xf6f82c: stur            x4, [fp, #-0x30]
    // 0xf6f830: cmp             w4, NULL
    // 0xf6f834: b.ne            #0xf6f868
    // 0xf6f838: mov             x0, x4
    // 0xf6f83c: ldur            x2, [fp, #-0x20]
    // 0xf6f840: r1 = Null
    //     0xf6f840: mov             x1, NULL
    // 0xf6f844: cmp             w2, NULL
    // 0xf6f848: b.eq            #0xf6f868
    // 0xf6f84c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6f84c: ldur            w4, [x2, #0x17]
    // 0xf6f850: DecompressPointer r4
    //     0xf6f850: add             x4, x4, HEAP, lsl #32
    // 0xf6f854: r8 = X0
    //     0xf6f854: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf6f858: LoadField: r9 = r4->field_7
    //     0xf6f858: ldur            x9, [x4, #7]
    // 0xf6f85c: r3 = Null
    //     0xf6f85c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ef0] Null
    //     0xf6f860: ldr             x3, [x3, #0xef0]
    // 0xf6f864: blr             x9
    // 0xf6f868: ldur            x1, [fp, #-0x30]
    // 0xf6f86c: r0 = LoadClassIdInstr(r1)
    //     0xf6f86c: ldur            x0, [x1, #-1]
    //     0xf6f870: ubfx            x0, x0, #0xc, #0x14
    // 0xf6f874: ldur            x2, [fp, #-0x28]
    // 0xf6f878: r0 = GDT[cid_x0 + 0x12b1f]()
    //     0xf6f878: mov             x17, #0x2b1f
    //     0xf6f87c: movk            x17, #1, lsl #16
    //     0xf6f880: add             lr, x0, x17
    //     0xf6f884: ldr             lr, [x21, lr, lsl #3]
    //     0xf6f888: blr             lr
    // 0xf6f88c: ldur            x0, [fp, #-0x18]
    // 0xf6f890: ldur            x3, [fp, #-0x20]
    // 0xf6f894: ldur            x2, [fp, #-0x28]
    // 0xf6f898: b               #0xf6f808
    // 0xf6f89c: ldur            x1, [fp, #-0x10]
    // 0xf6f8a0: ldur            x0, [fp, #-8]
    // 0xf6f8a4: StoreField: r1->field_13 = r0
    //     0xf6f8a4: stur            w0, [x1, #0x13]
    //     0xf6f8a8: ldurb           w16, [x1, #-1]
    //     0xf6f8ac: ldurb           w17, [x0, #-1]
    //     0xf6f8b0: and             x16, x17, x16, lsr #2
    //     0xf6f8b4: tst             x16, HEAP, lsr #32
    //     0xf6f8b8: b.eq            #0xf6f8c0
    //     0xf6f8bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6f8c0: r0 = Null
    //     0xf6f8c0: mov             x0, NULL
    // 0xf6f8c4: LeaveFrame
    //     0xf6f8c4: mov             SP, fp
    //     0xf6f8c8: ldp             fp, lr, [SP], #0x10
    // 0xf6f8cc: ret
    //     0xf6f8cc: ret             
    // 0xf6f8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f8d4: b               #0xf6f688
    // 0xf6f8d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f8d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f8dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f8dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f8e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f8e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f8e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f8e8: b               #0xf6f74c
    // 0xf6f8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f8f0: b               #0xf6f814
  }
  [closure] void _handleActionChanged(dynamic, Action<Intent>) {
    // ** addr: 0xf6f8f4, size: 0x3c
    // 0xf6f8f4: EnterFrame
    //     0xf6f8f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f8f8: mov             fp, SP
    // 0xf6f8fc: ldr             x0, [fp, #0x18]
    // 0xf6f900: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6f900: ldur            w1, [x0, #0x17]
    // 0xf6f904: DecompressPointer r1
    //     0xf6f904: add             x1, x1, HEAP, lsl #32
    // 0xf6f908: CheckStackOverflow
    //     0xf6f908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f90c: cmp             SP, x16
    //     0xf6f910: b.ls            #0xf6f928
    // 0xf6f914: ldr             x2, [fp, #0x10]
    // 0xf6f918: r0 = _handleActionChanged()
    //     0xf6f918: bl              #0xf6f930  ; [package:flutter/src/widgets/actions.dart] _ActionsState::_handleActionChanged
    // 0xf6f91c: LeaveFrame
    //     0xf6f91c: mov             SP, fp
    //     0xf6f920: ldp             fp, lr, [SP], #0x10
    // 0xf6f924: ret
    //     0xf6f924: ret             
    // 0xf6f928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f928: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f92c: b               #0xf6f914
  }
  _ _handleActionChanged(/* No info */) {
    // ** addr: 0xf6f930, size: 0x64
    // 0xf6f930: EnterFrame
    //     0xf6f930: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f934: mov             fp, SP
    // 0xf6f938: AllocStack(0x8)
    //     0xf6f938: sub             SP, SP, #8
    // 0xf6f93c: SetupParameters(_ActionsState this /* r1 => r1, fp-0x8 */)
    //     0xf6f93c: stur            x1, [fp, #-8]
    // 0xf6f940: CheckStackOverflow
    //     0xf6f940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f944: cmp             SP, x16
    //     0xf6f948: b.ls            #0xf6f98c
    // 0xf6f94c: r1 = 1
    //     0xf6f94c: mov             x1, #1
    // 0xf6f950: r0 = AllocateContext()
    //     0xf6f950: bl              #0x13de838  ; AllocateContextStub
    // 0xf6f954: mov             x1, x0
    // 0xf6f958: ldur            x0, [fp, #-8]
    // 0xf6f95c: StoreField: r1->field_f = r0
    //     0xf6f95c: stur            w0, [x1, #0xf]
    // 0xf6f960: mov             x2, x1
    // 0xf6f964: r1 = Function '<anonymous closure>':.
    //     0xf6f964: add             x1, PP, #0x99, lsl #12  ; [pp+0x99eb0] AnonymousClosure: (0xf6f994), in [package:flutter/src/widgets/actions.dart] _ActionsState::_handleActionChanged (0xf6f930)
    //     0xf6f968: ldr             x1, [x1, #0xeb0]
    // 0xf6f96c: r0 = AllocateClosure()
    //     0xf6f96c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6f970: ldur            x1, [fp, #-8]
    // 0xf6f974: mov             x2, x0
    // 0xf6f978: r0 = setState()
    //     0xf6f978: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf6f97c: r0 = Null
    //     0xf6f97c: mov             x0, NULL
    // 0xf6f980: LeaveFrame
    //     0xf6f980: mov             SP, fp
    //     0xf6f984: ldp             fp, lr, [SP], #0x10
    // 0xf6f988: ret
    //     0xf6f988: ret             
    // 0xf6f98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f98c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f990: b               #0xf6f94c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf6f994, size: 0x58
    // 0xf6f994: EnterFrame
    //     0xf6f994: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f998: mov             fp, SP
    // 0xf6f99c: AllocStack(0x8)
    //     0xf6f99c: sub             SP, SP, #8
    // 0xf6f9a0: SetupParameters([dynamic _ /* r0 */])
    //     0xf6f9a0: ldr             x0, [fp, #0x10]
    //     0xf6f9a4: ldur            w1, [x0, #0x17]
    //     0xf6f9a8: add             x1, x1, HEAP, lsl #32
    // 0xf6f9ac: LoadField: r0 = r1->field_f
    //     0xf6f9ac: ldur            w0, [x1, #0xf]
    // 0xf6f9b0: DecompressPointer r0
    //     0xf6f9b0: add             x0, x0, HEAP, lsl #32
    // 0xf6f9b4: stur            x0, [fp, #-8]
    // 0xf6f9b8: r0 = Object()
    //     0xf6f9b8: bl              #0x7ed2a0  ; AllocateObjectStub -> Object (size=0x8)
    // 0xf6f9bc: ldur            x1, [fp, #-8]
    // 0xf6f9c0: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6f9c0: stur            w0, [x1, #0x17]
    //     0xf6f9c4: ldurb           w16, [x1, #-1]
    //     0xf6f9c8: ldurb           w17, [x0, #-1]
    //     0xf6f9cc: and             x16, x17, x16, lsr #2
    //     0xf6f9d0: tst             x16, HEAP, lsr #32
    //     0xf6f9d4: b.eq            #0xf6f9dc
    //     0xf6f9d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6f9dc: r0 = Null
    //     0xf6f9dc: mov             x0, NULL
    // 0xf6f9e0: LeaveFrame
    //     0xf6f9e0: mov             SP, fp
    //     0xf6f9e4: ldp             fp, lr, [SP], #0x10
    // 0xf6f9e8: ret
    //     0xf6f9e8: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91638, size: 0x30
    // 0xf91638: EnterFrame
    //     0xf91638: stp             fp, lr, [SP, #-0x10]!
    //     0xf9163c: mov             fp, SP
    // 0xf91640: CheckStackOverflow
    //     0xf91640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91644: cmp             SP, x16
    //     0xf91648: b.ls            #0xf91660
    // 0xf9164c: r0 = _updateActionListeners()
    //     0xf9164c: bl              #0xf6f668  ; [package:flutter/src/widgets/actions.dart] _ActionsState::_updateActionListeners
    // 0xf91650: r0 = Null
    //     0xf91650: mov             x0, NULL
    // 0xf91654: LeaveFrame
    //     0xf91654: mov             SP, fp
    //     0xf91658: ldp             fp, lr, [SP], #0x10
    // 0xf9165c: ret
    //     0xf9165c: ret             
    // 0xf91660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91664: b               #0xf9164c
  }
  _ _ActionsState(/* No info */) {
    // ** addr: 0xfa35f0, size: 0x98
    // 0xfa35f0: EnterFrame
    //     0xfa35f0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa35f4: mov             fp, SP
    // 0xfa35f8: AllocStack(0x8)
    //     0xfa35f8: sub             SP, SP, #8
    // 0xfa35fc: SetupParameters(_ActionsState this /* r1 => r0, fp-0x8 */)
    //     0xfa35fc: mov             x0, x1
    //     0xfa3600: stur            x1, [fp, #-8]
    // 0xfa3604: r1 = <Action<Intent>>
    //     0xfa3604: add             x1, PP, #0x90, lsl #12  ; [pp+0x90398] TypeArguments: <Action<Intent>>
    //     0xfa3608: ldr             x1, [x1, #0x398]
    // 0xfa360c: r0 = _Set()
    //     0xfa360c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfa3610: mov             x1, x0
    // 0xfa3614: r0 = _Uint32List
    //     0xfa3614: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfa3618: StoreField: r1->field_1b = r0
    //     0xfa3618: stur            w0, [x1, #0x1b]
    // 0xfa361c: StoreField: r1->field_b = rZR
    //     0xfa361c: stur            wzr, [x1, #0xb]
    // 0xfa3620: r0 = const []
    //     0xfa3620: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfa3624: StoreField: r1->field_f = r0
    //     0xfa3624: stur            w0, [x1, #0xf]
    // 0xfa3628: StoreField: r1->field_13 = rZR
    //     0xfa3628: stur            wzr, [x1, #0x13]
    // 0xfa362c: ArrayStore: r1[0] = rZR  ; List_4
    //     0xfa362c: stur            wzr, [x1, #0x17]
    // 0xfa3630: mov             x0, x1
    // 0xfa3634: ldur            x1, [fp, #-8]
    // 0xfa3638: StoreField: r1->field_13 = r0
    //     0xfa3638: stur            w0, [x1, #0x13]
    //     0xfa363c: ldurb           w16, [x1, #-1]
    //     0xfa3640: ldurb           w17, [x0, #-1]
    //     0xfa3644: and             x16, x17, x16, lsr #2
    //     0xfa3648: tst             x16, HEAP, lsr #32
    //     0xfa364c: b.eq            #0xfa3654
    //     0xfa3650: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3654: r0 = Object()
    //     0xfa3654: bl              #0x7ed2a0  ; AllocateObjectStub -> Object (size=0x8)
    // 0xfa3658: ldur            x1, [fp, #-8]
    // 0xfa365c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfa365c: stur            w0, [x1, #0x17]
    //     0xfa3660: ldurb           w16, [x1, #-1]
    //     0xfa3664: ldurb           w17, [x0, #-1]
    //     0xfa3668: and             x16, x17, x16, lsr #2
    //     0xfa366c: tst             x16, HEAP, lsr #32
    //     0xfa3670: b.eq            #0xfa3678
    //     0xfa3674: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3678: r0 = Null
    //     0xfa3678: mov             x0, NULL
    // 0xfa367c: LeaveFrame
    //     0xfa367c: mov             SP, fp
    //     0xfa3680: ldp             fp, lr, [SP], #0x10
    // 0xfa3684: ret
    //     0xfa3684: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e62d0, size: 0x120
    // 0x10e62d0: EnterFrame
    //     0x10e62d0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e62d4: mov             fp, SP
    // 0x10e62d8: AllocStack(0x28)
    //     0x10e62d8: sub             SP, SP, #0x28
    // 0x10e62dc: SetupParameters(_ActionsState this /* r1 => r2, fp-0x8 */)
    //     0x10e62dc: mov             x2, x1
    //     0x10e62e0: stur            x1, [fp, #-8]
    // 0x10e62e4: CheckStackOverflow
    //     0x10e62e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e62e8: cmp             SP, x16
    //     0x10e62ec: b.ls            #0x10e63dc
    // 0x10e62f0: LoadField: r1 = r2->field_13
    //     0x10e62f0: ldur            w1, [x2, #0x13]
    // 0x10e62f4: DecompressPointer r1
    //     0x10e62f4: add             x1, x1, HEAP, lsl #32
    // 0x10e62f8: cmp             w1, NULL
    // 0x10e62fc: b.eq            #0x10e63e4
    // 0x10e6300: r0 = iterator()
    //     0x10e6300: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x10e6304: ldur            x2, [fp, #-8]
    // 0x10e6308: r1 = Function '_handleActionChanged@66441002':.
    //     0x10e6308: add             x1, PP, #0x99, lsl #12  ; [pp+0x99e98] AnonymousClosure: (0xf6f8f4), in [package:flutter/src/widgets/actions.dart] _ActionsState::_handleActionChanged (0xf6f930)
    //     0x10e630c: ldr             x1, [x1, #0xe98]
    // 0x10e6310: stur            x0, [fp, #-0x10]
    // 0x10e6314: r0 = AllocateClosure()
    //     0x10e6314: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e6318: mov             x2, x0
    // 0x10e631c: ldur            x0, [fp, #-0x10]
    // 0x10e6320: stur            x2, [fp, #-0x20]
    // 0x10e6324: LoadField: r3 = r0->field_7
    //     0x10e6324: ldur            w3, [x0, #7]
    // 0x10e6328: DecompressPointer r3
    //     0x10e6328: add             x3, x3, HEAP, lsl #32
    // 0x10e632c: stur            x3, [fp, #-0x18]
    // 0x10e6330: CheckStackOverflow
    //     0x10e6330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e6334: cmp             SP, x16
    //     0x10e6338: b.ls            #0x10e63e8
    // 0x10e633c: mov             x1, x0
    // 0x10e6340: r0 = moveNext()
    //     0x10e6340: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x10e6344: tbnz            w0, #4, #0x10e63c4
    // 0x10e6348: ldur            x3, [fp, #-0x10]
    // 0x10e634c: LoadField: r4 = r3->field_33
    //     0x10e634c: ldur            w4, [x3, #0x33]
    // 0x10e6350: DecompressPointer r4
    //     0x10e6350: add             x4, x4, HEAP, lsl #32
    // 0x10e6354: stur            x4, [fp, #-0x28]
    // 0x10e6358: cmp             w4, NULL
    // 0x10e635c: b.ne            #0x10e6390
    // 0x10e6360: mov             x0, x4
    // 0x10e6364: ldur            x2, [fp, #-0x18]
    // 0x10e6368: r1 = Null
    //     0x10e6368: mov             x1, NULL
    // 0x10e636c: cmp             w2, NULL
    // 0x10e6370: b.eq            #0x10e6390
    // 0x10e6374: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10e6374: ldur            w4, [x2, #0x17]
    // 0x10e6378: DecompressPointer r4
    //     0x10e6378: add             x4, x4, HEAP, lsl #32
    // 0x10e637c: r8 = X0
    //     0x10e637c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10e6380: LoadField: r9 = r4->field_7
    //     0x10e6380: ldur            x9, [x4, #7]
    // 0x10e6384: r3 = Null
    //     0x10e6384: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ea0] Null
    //     0x10e6388: ldr             x3, [x3, #0xea0]
    // 0x10e638c: blr             x9
    // 0x10e6390: ldur            x1, [fp, #-0x28]
    // 0x10e6394: r0 = LoadClassIdInstr(r1)
    //     0x10e6394: ldur            x0, [x1, #-1]
    //     0x10e6398: ubfx            x0, x0, #0xc, #0x14
    // 0x10e639c: ldur            x2, [fp, #-0x20]
    // 0x10e63a0: r0 = GDT[cid_x0 + 0x12387]()
    //     0x10e63a0: mov             x17, #0x2387
    //     0x10e63a4: movk            x17, #1, lsl #16
    //     0x10e63a8: add             lr, x0, x17
    //     0x10e63ac: ldr             lr, [x21, lr, lsl #3]
    //     0x10e63b0: blr             lr
    // 0x10e63b4: ldur            x0, [fp, #-0x10]
    // 0x10e63b8: ldur            x3, [fp, #-0x18]
    // 0x10e63bc: ldur            x2, [fp, #-0x20]
    // 0x10e63c0: b               #0x10e6330
    // 0x10e63c4: ldur            x1, [fp, #-8]
    // 0x10e63c8: StoreField: r1->field_13 = rNULL
    //     0x10e63c8: stur            NULL, [x1, #0x13]
    // 0x10e63cc: r0 = Null
    //     0x10e63cc: mov             x0, NULL
    // 0x10e63d0: LeaveFrame
    //     0x10e63d0: mov             SP, fp
    //     0x10e63d4: ldp             fp, lr, [SP], #0x10
    // 0x10e63d8: ret
    //     0x10e63d8: ret             
    // 0x10e63dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e63dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e63e0: b               #0x10e62f0
    // 0x10e63e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e63e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e63e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e63e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e63ec: b               #0x10e633c
  }
}

// class id: 6409, size: 0x40, field offset: 0xc
//   const constructor, 
class FocusableActionDetector extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3694, size: 0x54
    // 0xfa3694: EnterFrame
    //     0xfa3694: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3698: mov             fp, SP
    // 0xfa369c: AllocStack(0x8)
    //     0xfa369c: sub             SP, SP, #8
    // 0xfa36a0: SetupParameters(FocusableActionDetector this /* r1 => r0 */)
    //     0xfa36a0: mov             x0, x1
    // 0xfa36a4: r1 = <FocusableActionDetector>
    //     0xfa36a4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99f18] TypeArguments: <FocusableActionDetector>
    //     0xfa36a8: ldr             x1, [x1, #0xf18]
    // 0xfa36ac: r0 = _FocusableActionDetectorState()
    //     0xfa36ac: bl              #0xfa36e8  ; Allocate_FocusableActionDetectorStateStub -> _FocusableActionDetectorState (size=0x24)
    // 0xfa36b0: mov             x2, x0
    // 0xfa36b4: r0 = false
    //     0xfa36b4: add             x0, NULL, #0x30  ; false
    // 0xfa36b8: stur            x2, [fp, #-8]
    // 0xfa36bc: StoreField: r2->field_13 = r0
    //     0xfa36bc: stur            w0, [x2, #0x13]
    // 0xfa36c0: ArrayStore: r2[0] = r0  ; List_4
    //     0xfa36c0: stur            w0, [x2, #0x17]
    // 0xfa36c4: StoreField: r2->field_1b = r0
    //     0xfa36c4: stur            w0, [x2, #0x1b]
    // 0xfa36c8: r1 = <State<StatefulWidget>>
    //     0xfa36c8: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa36cc: r0 = LabeledGlobalKey()
    //     0xfa36cc: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa36d0: mov             x1, x0
    // 0xfa36d4: ldur            x0, [fp, #-8]
    // 0xfa36d8: StoreField: r0->field_1f = r1
    //     0xfa36d8: stur            w1, [x0, #0x1f]
    // 0xfa36dc: LeaveFrame
    //     0xfa36dc: mov             SP, fp
    //     0xfa36e0: ldp             fp, lr, [SP], #0x10
    // 0xfa36e4: ret
    //     0xfa36e4: ret             
  }
}

// class id: 6410, size: 0x18, field offset: 0xc
//   const constructor, 
class Actions extends StatefulWidget {

  static _ invoke(/* No info */) {
    // ** addr: 0x879850, size: 0xc8
    // 0x879850: EnterFrame
    //     0x879850: stp             fp, lr, [SP, #-0x10]!
    //     0x879854: mov             fp, SP
    // 0x879858: AllocStack(0x18)
    //     0x879858: sub             SP, SP, #0x18
    // 0x87985c: SetupParameters([dynamic _ /* r1 */, dynamic _ /* r2 */])
    //     0x87985c: ldur            w0, [x4, #0xf]
    //     0x879860: stur            x0, [fp, #-0x10]
    //     0x879864: cbnz            w0, #0x879870
    //     0x879868: mov             x3, NULL
    //     0x87986c: b               #0x879880
    //     0x879870: ldur            w1, [x4, #0x17]
    //     0x879874: add             x2, fp, w1, sxtw #2
    //     0x879878: ldr             x2, [x2, #0x10]
    //     0x87987c: mov             x3, x2
    //     0x879880: ldr             x2, [fp, #0x18]
    //     0x879884: ldr             x1, [fp, #0x10]
    //     0x879888: stur            x3, [fp, #-8]
    // 0x87988c: CheckStackOverflow
    //     0x87988c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879890: cmp             SP, x16
    //     0x879894: b.ls            #0x879910
    // 0x879898: r1 = 3
    //     0x879898: mov             x1, #3
    // 0x87989c: r0 = AllocateContext()
    //     0x87989c: bl              #0x13de838  ; AllocateContextStub
    // 0x8798a0: mov             x3, x0
    // 0x8798a4: ldr             x0, [fp, #0x18]
    // 0x8798a8: stur            x3, [fp, #-0x18]
    // 0x8798ac: StoreField: r3->field_f = r0
    //     0x8798ac: stur            w0, [x3, #0xf]
    // 0x8798b0: ldr             x1, [fp, #0x10]
    // 0x8798b4: StoreField: r3->field_13 = r1
    //     0x8798b4: stur            w1, [x3, #0x13]
    // 0x8798b8: ldur            x1, [fp, #-0x10]
    // 0x8798bc: cbnz            w1, #0x8798c8
    // 0x8798c0: r4 = <Intent>
    //     0x8798c0: ldr             x4, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0x8798c4: b               #0x8798cc
    // 0x8798c8: ldur            x4, [fp, #-8]
    // 0x8798cc: stur            x4, [fp, #-8]
    // 0x8798d0: ArrayStore: r3[0] = rNULL  ; List_4
    //     0x8798d0: stur            NULL, [x3, #0x17]
    // 0x8798d4: mov             x2, x3
    // 0x8798d8: r1 = Function '<anonymous closure>': static.
    //     0x8798d8: ldr             x1, [PP, #0x46b8]  ; [pp+0x46b8] AnonymousClosure: static (0x879b18), in [package:flutter/src/widgets/actions.dart] Actions::invoke (0x879850)
    // 0x8798dc: r0 = AllocateClosure()
    //     0x8798dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8798e0: mov             x1, x0
    // 0x8798e4: ldur            x0, [fp, #-8]
    // 0x8798e8: StoreField: r1->field_b = r0
    //     0x8798e8: stur            w0, [x1, #0xb]
    // 0x8798ec: mov             x2, x1
    // 0x8798f0: ldr             x1, [fp, #0x18]
    // 0x8798f4: r0 = _visitActionsAncestors()
    //     0x8798f4: bl              #0x87993c  ; [package:flutter/src/widgets/actions.dart] Actions::_visitActionsAncestors
    // 0x8798f8: ldur            x1, [fp, #-0x18]
    // 0x8798fc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8798fc: ldur            w0, [x1, #0x17]
    // 0x879900: DecompressPointer r0
    //     0x879900: add             x0, x0, HEAP, lsl #32
    // 0x879904: LeaveFrame
    //     0x879904: mov             SP, fp
    //     0x879908: ldp             fp, lr, [SP], #0x10
    // 0x87990c: ret
    //     0x87990c: ret             
    // 0x879910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879910: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879914: b               #0x879898
  }
  static _ _visitActionsAncestors(/* No info */) {
    // ** addr: 0x87993c, size: 0x15c
    // 0x87993c: EnterFrame
    //     0x87993c: stp             fp, lr, [SP, #-0x10]!
    //     0x879940: mov             fp, SP
    // 0x879944: AllocStack(0x28)
    //     0x879944: sub             SP, SP, #0x28
    // 0x879948: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x879948: mov             x0, x1
    //     0x87994c: mov             x1, x2
    //     0x879950: stur            x2, [fp, #-8]
    // 0x879954: CheckStackOverflow
    //     0x879954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879958: cmp             SP, x16
    //     0x87995c: b.ls            #0x879a88
    // 0x879960: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x879960: ldur            w2, [x0, #0x17]
    // 0x879964: DecompressPointer r2
    //     0x879964: add             x2, x2, HEAP, lsl #32
    // 0x879968: cmp             w2, NULL
    // 0x87996c: b.ne            #0x879980
    // 0x879970: r0 = false
    //     0x879970: add             x0, NULL, #0x30  ; false
    // 0x879974: LeaveFrame
    //     0x879974: mov             SP, fp
    //     0x879978: ldp             fp, lr, [SP], #0x10
    // 0x87997c: ret
    //     0x87997c: ret             
    // 0x879980: r2 = LoadClassIdInstr(r0)
    //     0x879980: ldur            x2, [x0, #-1]
    //     0x879984: ubfx            x2, x2, #0xc, #0x14
    // 0x879988: r16 = <_ActionsScope>
    //     0x879988: ldr             x16, [PP, #0x47a8]  ; [pp+0x47a8] TypeArguments: <_ActionsScope>
    // 0x87998c: stp             x0, x16, [SP]
    // 0x879990: mov             x0, x2
    // 0x879994: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x879994: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x879998: r0 = GDT[cid_x0 + 0xf0a]()
    //     0x879998: add             lr, x0, #0xf0a
    //     0x87999c: ldr             lr, [x21, lr, lsl #3]
    //     0x8799a0: blr             lr
    // 0x8799a4: mov             x1, x0
    // 0x8799a8: stur            x1, [fp, #-0x10]
    // 0x8799ac: CheckStackOverflow
    //     0x8799ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8799b0: cmp             SP, x16
    //     0x8799b4: b.ls            #0x879a90
    // 0x8799b8: cmp             w1, NULL
    // 0x8799bc: b.eq            #0x879a54
    // 0x8799c0: ldur            x16, [fp, #-8]
    // 0x8799c4: stp             x1, x16, [SP]
    // 0x8799c8: ldur            x0, [fp, #-8]
    // 0x8799cc: ClosureCall
    //     0x8799cc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8799d0: ldur            x2, [x0, #0x1f]
    //     0x8799d4: blr             x2
    // 0x8799d8: r16 = true
    //     0x8799d8: add             x16, NULL, #0x20  ; true
    // 0x8799dc: cmp             w0, w16
    // 0x8799e0: b.eq            #0x879a54
    // 0x8799e4: r1 = 1
    //     0x8799e4: mov             x1, #1
    // 0x8799e8: r0 = AllocateContext()
    //     0x8799e8: bl              #0x13de838  ; AllocateContextStub
    // 0x8799ec: mov             x3, x0
    // 0x8799f0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8799f4: stur            x3, [fp, #-0x18]
    // 0x8799f8: StoreField: r3->field_f = r0
    //     0x8799f8: stur            w0, [x3, #0xf]
    // 0x8799fc: mov             x2, x3
    // 0x879a00: r1 = Function '<anonymous closure>': static.
    //     0x879a00: ldr             x1, [PP, #0x47b0]  ; [pp+0x47b0] AnonymousClosure: static (0x879a98), of [package:flutter/src/widgets/actions.dart] 
    // 0x879a04: r0 = AllocateClosure()
    //     0x879a04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x879a08: ldur            x1, [fp, #-0x10]
    // 0x879a0c: mov             x2, x0
    // 0x879a10: r0 = visitAncestorElements()
    //     0x879a10: bl              #0x855824  ; [package:flutter/src/widgets/framework.dart] Element::visitAncestorElements
    // 0x879a14: ldur            x0, [fp, #-0x18]
    // 0x879a18: LoadField: r1 = r0->field_f
    //     0x879a18: ldur            w1, [x0, #0xf]
    // 0x879a1c: DecompressPointer r1
    //     0x879a1c: add             x1, x1, HEAP, lsl #32
    // 0x879a20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x879a24: cmp             w1, w16
    // 0x879a28: b.eq            #0x879a78
    // 0x879a2c: r0 = LoadClassIdInstr(r1)
    //     0x879a2c: ldur            x0, [x1, #-1]
    //     0x879a30: ubfx            x0, x0, #0xc, #0x14
    // 0x879a34: r16 = <_ActionsScope>
    //     0x879a34: ldr             x16, [PP, #0x47a8]  ; [pp+0x47a8] TypeArguments: <_ActionsScope>
    // 0x879a38: stp             x1, x16, [SP]
    // 0x879a3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x879a3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x879a40: r0 = GDT[cid_x0 + 0xf0a]()
    //     0x879a40: add             lr, x0, #0xf0a
    //     0x879a44: ldr             lr, [x21, lr, lsl #3]
    //     0x879a48: blr             lr
    // 0x879a4c: mov             x1, x0
    // 0x879a50: b               #0x8799a8
    // 0x879a54: ldur            x0, [fp, #-0x10]
    // 0x879a58: cmp             w0, NULL
    // 0x879a5c: r16 = true
    //     0x879a5c: add             x16, NULL, #0x20  ; true
    // 0x879a60: r17 = false
    //     0x879a60: add             x17, NULL, #0x30  ; false
    // 0x879a64: csel            x1, x16, x17, ne
    // 0x879a68: mov             x0, x1
    // 0x879a6c: LeaveFrame
    //     0x879a6c: mov             SP, fp
    //     0x879a70: ldp             fp, lr, [SP], #0x10
    // 0x879a74: ret
    //     0x879a74: ret             
    // 0x879a78: r16 = "parent"
    //     0x879a78: ldr             x16, [PP, #0x47b8]  ; [pp+0x47b8] "parent"
    // 0x879a7c: str             x16, [SP]
    // 0x879a80: r0 = _throwLocalNotInitialized()
    //     0x879a80: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x879a84: brk             #0
    // 0x879a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879a88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879a8c: b               #0x879960
    // 0x879a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879a90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879a94: b               #0x8799b8
  }
  [closure] static bool <anonymous closure>(dynamic, InheritedElement) {
    // ** addr: 0x879b18, size: 0x1ec
    // 0x879b18: EnterFrame
    //     0x879b18: stp             fp, lr, [SP, #-0x10]!
    //     0x879b1c: mov             fp, SP
    // 0x879b20: AllocStack(0x38)
    //     0x879b20: sub             SP, SP, #0x38
    // 0x879b24: SetupParameters([dynamic _ /* r0 */])
    //     0x879b24: ldr             x0, [fp, #0x18]
    //     0x879b28: ldur            w3, [x0, #0x17]
    //     0x879b2c: add             x3, x3, HEAP, lsl #32
    //     0x879b30: stur            x3, [fp, #-0x18]
    // 0x879b34: CheckStackOverflow
    //     0x879b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879b38: cmp             SP, x16
    //     0x879b3c: b.ls            #0x879cf4
    // 0x879b40: LoadField: r4 = r0->field_b
    //     0x879b40: ldur            w4, [x0, #0xb]
    // 0x879b44: DecompressPointer r4
    //     0x879b44: add             x4, x4, HEAP, lsl #32
    // 0x879b48: ldr             x5, [fp, #0x10]
    // 0x879b4c: stur            x4, [fp, #-0x10]
    // 0x879b50: r0 = LoadClassIdInstr(r5)
    //     0x879b50: ldur            x0, [x5, #-1]
    //     0x879b54: ubfx            x0, x0, #0xc, #0x14
    // 0x879b58: r17 = -5837
    //     0x879b58: mov             x17, #-0x16cd
    // 0x879b5c: add             x16, x0, x17
    // 0x879b60: cmp             x16, #2
    // 0x879b64: b.ls            #0x879b74
    // 0x879b68: r17 = 5835
    //     0x879b68: mov             x17, #0x16cb
    // 0x879b6c: cmp             x0, x17
    // 0x879b70: b.ne            #0x879b8c
    // 0x879b74: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x879b74: ldur            w0, [x5, #0x17]
    // 0x879b78: DecompressPointer r0
    //     0x879b78: add             x0, x0, HEAP, lsl #32
    // 0x879b7c: cmp             w0, NULL
    // 0x879b80: b.eq            #0x879cfc
    // 0x879b84: mov             x4, x0
    // 0x879b88: b               #0x879bc8
    // 0x879b8c: ArrayLoad: r6 = r5[0]  ; List_4
    //     0x879b8c: ldur            w6, [x5, #0x17]
    // 0x879b90: DecompressPointer r6
    //     0x879b90: add             x6, x6, HEAP, lsl #32
    // 0x879b94: stur            x6, [fp, #-8]
    // 0x879b98: cmp             w6, NULL
    // 0x879b9c: b.eq            #0x879d00
    // 0x879ba0: LoadField: r2 = r5->field_43
    //     0x879ba0: ldur            w2, [x5, #0x43]
    // 0x879ba4: DecompressPointer r2
    //     0x879ba4: add             x2, x2, HEAP, lsl #32
    // 0x879ba8: mov             x0, x6
    // 0x879bac: r1 = Null
    //     0x879bac: mov             x1, NULL
    // 0x879bb0: r8 = _InheritedProviderScope<X0>
    //     0x879bb0: ldr             x8, [PP, #0x1fb0]  ; [pp+0x1fb0] Type: _InheritedProviderScope<X0>
    // 0x879bb4: LoadField: r9 = r8->field_7
    //     0x879bb4: ldur            x9, [x8, #7]
    // 0x879bb8: r3 = Null
    //     0x879bb8: ldr             x3, [PP, #0x46c0]  ; [pp+0x46c0] Null
    // 0x879bbc: blr             x9
    // 0x879bc0: ldur            x4, [fp, #-8]
    // 0x879bc4: ldur            x3, [fp, #-0x18]
    // 0x879bc8: mov             x0, x4
    // 0x879bcc: stur            x4, [fp, #-8]
    // 0x879bd0: r2 = Null
    //     0x879bd0: mov             x2, NULL
    // 0x879bd4: r1 = Null
    //     0x879bd4: mov             x1, NULL
    // 0x879bd8: r4 = LoadClassIdInstr(r0)
    //     0x879bd8: ldur            x4, [x0, #-1]
    //     0x879bdc: ubfx            x4, x4, #0xc, #0x14
    // 0x879be0: r17 = 6799
    //     0x879be0: mov             x17, #0x1a8f
    // 0x879be4: cmp             x4, x17
    // 0x879be8: b.eq            #0x879bf8
    // 0x879bec: r8 = _ActionsScope
    //     0x879bec: ldr             x8, [PP, #0x46d0]  ; [pp+0x46d0] Type: _ActionsScope
    // 0x879bf0: r3 = Null
    //     0x879bf0: ldr             x3, [PP, #0x46d8]  ; [pp+0x46d8] Null
    // 0x879bf4: r0 = DefaultTypeTest()
    //     0x879bf4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x879bf8: ldur            x0, [fp, #-0x18]
    // 0x879bfc: LoadField: r1 = r0->field_13
    //     0x879bfc: ldur            w1, [x0, #0x13]
    // 0x879c00: DecompressPointer r1
    //     0x879c00: add             x1, x1, HEAP, lsl #32
    // 0x879c04: ldur            x16, [fp, #-0x10]
    // 0x879c08: ldur            lr, [fp, #-8]
    // 0x879c0c: stp             lr, x16, [SP, #8]
    // 0x879c10: str             x1, [SP]
    // 0x879c14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x879c14: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x879c18: r0 = _castAction()
    //     0x879c18: bl              #0x87a078  ; [package:flutter/src/widgets/actions.dart] Actions::_castAction
    // 0x879c1c: stur            x0, [fp, #-8]
    // 0x879c20: cmp             w0, NULL
    // 0x879c24: b.eq            #0x879cd4
    // 0x879c28: ldur            x4, [fp, #-0x18]
    // 0x879c2c: LoadField: r2 = r4->field_13
    //     0x879c2c: ldur            w2, [x4, #0x13]
    // 0x879c30: DecompressPointer r2
    //     0x879c30: add             x2, x2, HEAP, lsl #32
    // 0x879c34: LoadField: r3 = r4->field_f
    //     0x879c34: ldur            w3, [x4, #0xf]
    // 0x879c38: DecompressPointer r3
    //     0x879c38: add             x3, x3, HEAP, lsl #32
    // 0x879c3c: mov             x1, x0
    // 0x879c40: r0 = _isEnabled()
    //     0x879c40: bl              #0x879f4c  ; [package:flutter/src/widgets/actions.dart] Action::_isEnabled
    // 0x879c44: tbnz            w0, #4, #0x879cd4
    // 0x879c48: ldur            x0, [fp, #-0x18]
    // 0x879c4c: ldr             x1, [fp, #0x10]
    // 0x879c50: r0 = _findDispatcher()
    //     0x879c50: bl              #0x879e38  ; [package:flutter/src/widgets/actions.dart] Actions::_findDispatcher
    // 0x879c54: ldur            x3, [fp, #-0x18]
    // 0x879c58: LoadField: r4 = r3->field_13
    //     0x879c58: ldur            w4, [x3, #0x13]
    // 0x879c5c: DecompressPointer r4
    //     0x879c5c: add             x4, x4, HEAP, lsl #32
    // 0x879c60: stur            x4, [fp, #-0x20]
    // 0x879c64: LoadField: r5 = r3->field_f
    //     0x879c64: ldur            w5, [x3, #0xf]
    // 0x879c68: DecompressPointer r5
    //     0x879c68: add             x5, x5, HEAP, lsl #32
    // 0x879c6c: ldur            x0, [fp, #-8]
    // 0x879c70: stur            x5, [fp, #-0x10]
    // 0x879c74: r2 = Null
    //     0x879c74: mov             x2, NULL
    // 0x879c78: r1 = Null
    //     0x879c78: mov             x1, NULL
    // 0x879c7c: r4 = LoadClassIdInstr(r0)
    //     0x879c7c: ldur            x4, [x0, #-1]
    //     0x879c80: ubfx            x4, x4, #0xc, #0x14
    // 0x879c84: r17 = -5315
    //     0x879c84: mov             x17, #-0x14c3
    // 0x879c88: add             x4, x4, x17
    // 0x879c8c: cmp             x4, #0x1a
    // 0x879c90: b.ls            #0x879ca0
    // 0x879c94: r8 = Action<Intent>
    //     0x879c94: ldr             x8, [PP, #0x46e8]  ; [pp+0x46e8] Type: Action<Intent>
    // 0x879c98: r3 = Null
    //     0x879c98: ldr             x3, [PP, #0x46f0]  ; [pp+0x46f0] Null
    // 0x879c9c: r0 = Action<Intent>()
    //     0x879c9c: bl              #0x87a1d8  ; IsType_Action<Intent>_Stub
    // 0x879ca0: ldur            x1, [fp, #-8]
    // 0x879ca4: ldur            x2, [fp, #-0x20]
    // 0x879ca8: ldur            x3, [fp, #-0x10]
    // 0x879cac: r0 = _invoke()
    //     0x879cac: bl              #0x879d04  ; [package:flutter/src/widgets/actions.dart] Action::_invoke
    // 0x879cb0: ldur            x1, [fp, #-0x18]
    // 0x879cb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x879cb4: stur            w0, [x1, #0x17]
    //     0x879cb8: tbz             w0, #0, #0x879cd4
    //     0x879cbc: ldurb           w16, [x1, #-1]
    //     0x879cc0: ldurb           w17, [x0, #-1]
    //     0x879cc4: and             x16, x17, x16, lsr #2
    //     0x879cc8: tst             x16, HEAP, lsr #32
    //     0x879ccc: b.eq            #0x879cd4
    //     0x879cd0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x879cd4: ldur            x1, [fp, #-8]
    // 0x879cd8: cmp             w1, NULL
    // 0x879cdc: r16 = true
    //     0x879cdc: add             x16, NULL, #0x20  ; true
    // 0x879ce0: r17 = false
    //     0x879ce0: add             x17, NULL, #0x30  ; false
    // 0x879ce4: csel            x0, x16, x17, ne
    // 0x879ce8: LeaveFrame
    //     0x879ce8: mov             SP, fp
    //     0x879cec: ldp             fp, lr, [SP], #0x10
    // 0x879cf0: ret
    //     0x879cf0: ret             
    // 0x879cf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879cf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879cf8: b               #0x879b40
    // 0x879cfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x879cfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x879d00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x879d00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _findDispatcher(/* No info */) {
    // ** addr: 0x879e38, size: 0x50
    // 0x879e38: EnterFrame
    //     0x879e38: stp             fp, lr, [SP, #-0x10]!
    //     0x879e3c: mov             fp, SP
    // 0x879e40: AllocStack(0x8)
    //     0x879e40: sub             SP, SP, #8
    // 0x879e44: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x879e44: mov             x0, x1
    //     0x879e48: stur            x1, [fp, #-8]
    // 0x879e4c: CheckStackOverflow
    //     0x879e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879e50: cmp             SP, x16
    //     0x879e54: b.ls            #0x879e80
    // 0x879e58: r1 = Function '<anonymous closure>': static.
    //     0x879e58: ldr             x1, [PP, #0x4730]  ; [pp+0x4730] AnonymousClosure: static (0x879e88), in [package:flutter/src/widgets/actions.dart] Actions::_findDispatcher (0x879e38)
    // 0x879e5c: r2 = Null
    //     0x879e5c: mov             x2, NULL
    // 0x879e60: r0 = AllocateClosure()
    //     0x879e60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x879e64: ldur            x1, [fp, #-8]
    // 0x879e68: mov             x2, x0
    // 0x879e6c: r0 = _visitActionsAncestors()
    //     0x879e6c: bl              #0x87993c  ; [package:flutter/src/widgets/actions.dart] Actions::_visitActionsAncestors
    // 0x879e70: r0 = Instance_ActionDispatcher
    //     0x879e70: ldr             x0, [PP, #0x4738]  ; [pp+0x4738] Obj!ActionDispatcher@12aa551
    // 0x879e74: LeaveFrame
    //     0x879e74: mov             SP, fp
    //     0x879e78: ldp             fp, lr, [SP], #0x10
    // 0x879e7c: ret
    //     0x879e7c: ret             
    // 0x879e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879e80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879e84: b               #0x879e58
  }
  [closure] static bool <anonymous closure>(dynamic, InheritedElement) {
    // ** addr: 0x879e88, size: 0xc4
    // 0x879e88: EnterFrame
    //     0x879e88: stp             fp, lr, [SP, #-0x10]!
    //     0x879e8c: mov             fp, SP
    // 0x879e90: AllocStack(0x8)
    //     0x879e90: sub             SP, SP, #8
    // 0x879e94: ldr             x0, [fp, #0x10]
    // 0x879e98: r1 = LoadClassIdInstr(r0)
    //     0x879e98: ldur            x1, [x0, #-1]
    //     0x879e9c: ubfx            x1, x1, #0xc, #0x14
    // 0x879ea0: r17 = -5837
    //     0x879ea0: mov             x17, #-0x16cd
    // 0x879ea4: add             x16, x1, x17
    // 0x879ea8: cmp             x16, #2
    // 0x879eac: b.ls            #0x879ebc
    // 0x879eb0: r17 = 5835
    //     0x879eb0: mov             x17, #0x16cb
    // 0x879eb4: cmp             x1, x17
    // 0x879eb8: b.ne            #0x879ed4
    // 0x879ebc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x879ebc: ldur            w1, [x0, #0x17]
    // 0x879ec0: DecompressPointer r1
    //     0x879ec0: add             x1, x1, HEAP, lsl #32
    // 0x879ec4: cmp             w1, NULL
    // 0x879ec8: b.eq            #0x879f44
    // 0x879ecc: mov             x0, x1
    // 0x879ed0: b               #0x879f0c
    // 0x879ed4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x879ed4: ldur            w3, [x0, #0x17]
    // 0x879ed8: DecompressPointer r3
    //     0x879ed8: add             x3, x3, HEAP, lsl #32
    // 0x879edc: stur            x3, [fp, #-8]
    // 0x879ee0: cmp             w3, NULL
    // 0x879ee4: b.eq            #0x879f48
    // 0x879ee8: LoadField: r2 = r0->field_43
    //     0x879ee8: ldur            w2, [x0, #0x43]
    // 0x879eec: DecompressPointer r2
    //     0x879eec: add             x2, x2, HEAP, lsl #32
    // 0x879ef0: mov             x0, x3
    // 0x879ef4: r1 = Null
    //     0x879ef4: mov             x1, NULL
    // 0x879ef8: r8 = _InheritedProviderScope<X0>
    //     0x879ef8: ldr             x8, [PP, #0x1fb0]  ; [pp+0x1fb0] Type: _InheritedProviderScope<X0>
    // 0x879efc: LoadField: r9 = r8->field_7
    //     0x879efc: ldur            x9, [x8, #7]
    // 0x879f00: r3 = Null
    //     0x879f00: ldr             x3, [PP, #0x4740]  ; [pp+0x4740] Null
    // 0x879f04: blr             x9
    // 0x879f08: ldur            x0, [fp, #-8]
    // 0x879f0c: r2 = Null
    //     0x879f0c: mov             x2, NULL
    // 0x879f10: r1 = Null
    //     0x879f10: mov             x1, NULL
    // 0x879f14: r4 = LoadClassIdInstr(r0)
    //     0x879f14: ldur            x4, [x0, #-1]
    //     0x879f18: ubfx            x4, x4, #0xc, #0x14
    // 0x879f1c: r17 = 6799
    //     0x879f1c: mov             x17, #0x1a8f
    // 0x879f20: cmp             x4, x17
    // 0x879f24: b.eq            #0x879f34
    // 0x879f28: r8 = _ActionsScope
    //     0x879f28: ldr             x8, [PP, #0x46d0]  ; [pp+0x46d0] Type: _ActionsScope
    // 0x879f2c: r3 = Null
    //     0x879f2c: ldr             x3, [PP, #0x4750]  ; [pp+0x4750] Null
    // 0x879f30: r0 = DefaultTypeTest()
    //     0x879f30: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x879f34: r0 = false
    //     0x879f34: add             x0, NULL, #0x30  ; false
    // 0x879f38: LeaveFrame
    //     0x879f38: mov             SP, fp
    //     0x879f3c: ldp             fp, lr, [SP], #0x10
    // 0x879f40: ret
    //     0x879f40: ret             
    // 0x879f44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x879f44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x879f48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x879f48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Action<Y0>? _castAction<Y0 extends Intent>(_ActionsScope, Y0?) {
    // ** addr: 0x87a078, size: 0x160
    // 0x87a078: EnterFrame
    //     0x87a078: stp             fp, lr, [SP, #-0x10]!
    //     0x87a07c: mov             fp, SP
    // 0x87a080: AllocStack(0x18)
    //     0x87a080: sub             SP, SP, #0x18
    // 0x87a084: SetupParameters()
    //     0x87a084: ldur            w0, [x4, #0xf]
    //     0x87a088: cbnz            w0, #0x87a094
    //     0x87a08c: mov             x1, NULL
    //     0x87a090: b               #0x87a0a4
    //     0x87a094: ldur            w1, [x4, #0x17]
    //     0x87a098: add             x2, fp, w1, sxtw #2
    //     0x87a09c: ldr             x2, [x2, #0x10]
    //     0x87a0a0: mov             x1, x2
    // 0x87a0a4: CheckStackOverflow
    //     0x87a0a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87a0a8: cmp             SP, x16
    //     0x87a0ac: b.ls            #0x87a1d0
    // 0x87a0b0: cbnz            w0, #0x87a0bc
    // 0x87a0b4: r2 = <Intent>
    //     0x87a0b4: ldr             x2, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0x87a0b8: b               #0x87a0c0
    // 0x87a0bc: mov             x2, x1
    // 0x87a0c0: ldr             x1, [fp, #0x18]
    // 0x87a0c4: ldr             x0, [fp, #0x10]
    // 0x87a0c8: stur            x2, [fp, #-0x10]
    // 0x87a0cc: LoadField: r3 = r1->field_13
    //     0x87a0cc: ldur            w3, [x1, #0x13]
    // 0x87a0d0: DecompressPointer r3
    //     0x87a0d0: add             x3, x3, HEAP, lsl #32
    // 0x87a0d4: stur            x3, [fp, #-8]
    // 0x87a0d8: cmp             w0, NULL
    // 0x87a0dc: b.ne            #0x87a0e8
    // 0x87a0e0: r0 = Null
    //     0x87a0e0: mov             x0, NULL
    // 0x87a0e4: b               #0x87a0f0
    // 0x87a0e8: str             x0, [SP]
    // 0x87a0ec: r0 = runtimeType()
    //     0x87a0ec: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x87a0f0: cmp             w0, NULL
    // 0x87a0f4: b.ne            #0x87a118
    // 0x87a0f8: ldur            x1, [fp, #-0x10]
    // 0x87a0fc: r2 = Null
    //     0x87a0fc: mov             x2, NULL
    // 0x87a100: r3 = Y0 bound Intent
    //     0x87a100: ldr             x3, [PP, #0x4788]  ; [pp+0x4788] TypeParameter: Y0 bound Intent
    // 0x87a104: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x87a104: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0x87a108: LoadField: r30 = r30->field_7
    //     0x87a108: ldur            lr, [lr, #7]
    // 0x87a10c: blr             lr
    // 0x87a110: mov             x2, x0
    // 0x87a114: b               #0x87a11c
    // 0x87a118: mov             x2, x0
    // 0x87a11c: ldur            x0, [fp, #-8]
    // 0x87a120: mov             x1, x0
    // 0x87a124: r0 = _getValueOrData()
    //     0x87a124: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87a128: mov             x1, x0
    // 0x87a12c: ldur            x0, [fp, #-8]
    // 0x87a130: LoadField: r2 = r0->field_f
    //     0x87a130: ldur            w2, [x0, #0xf]
    // 0x87a134: DecompressPointer r2
    //     0x87a134: add             x2, x2, HEAP, lsl #32
    // 0x87a138: cmp             w2, w1
    // 0x87a13c: b.ne            #0x87a148
    // 0x87a140: r3 = Null
    //     0x87a140: mov             x3, NULL
    // 0x87a144: b               #0x87a14c
    // 0x87a148: mov             x3, x1
    // 0x87a14c: mov             x0, x3
    // 0x87a150: ldur            x1, [fp, #-0x10]
    // 0x87a154: stur            x3, [fp, #-8]
    // 0x87a158: r2 = Null
    //     0x87a158: mov             x2, NULL
    // 0x87a15c: cmp             w0, NULL
    // 0x87a160: b.eq            #0x87a1a8
    // 0x87a164: branchIfSmi(r0, 0x87a1a0)
    //     0x87a164: tbz             w0, #0, #0x87a1a0
    // 0x87a168: r3 = SubtypeTestCache
    //     0x87a168: ldr             x3, [PP, #0x4790]  ; [pp+0x4790] SubtypeTestCache
    // 0x87a16c: r30 = Subtype4TestCacheStub
    //     0x87a16c: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0x87a170: LoadField: r30 = r30->field_7
    //     0x87a170: ldur            lr, [lr, #7]
    // 0x87a174: blr             lr
    // 0x87a178: cmp             w7, NULL
    // 0x87a17c: b.eq            #0x87a188
    // 0x87a180: tbnz            w7, #4, #0x87a1a0
    // 0x87a184: b               #0x87a1a8
    // 0x87a188: r8 = Action<Y0 bound Intent>?
    //     0x87a188: ldr             x8, [PP, #0x4798]  ; [pp+0x4798] Type: Action<Y0 bound Intent>?
    // 0x87a18c: r3 = SubtypeTestCache
    //     0x87a18c: ldr             x3, [PP, #0x47a0]  ; [pp+0x47a0] SubtypeTestCache
    // 0x87a190: r30 = InstanceOfStub
    //     0x87a190: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x87a194: LoadField: r30 = r30->field_7
    //     0x87a194: ldur            lr, [lr, #7]
    // 0x87a198: blr             lr
    // 0x87a19c: b               #0x87a1ac
    // 0x87a1a0: r0 = false
    //     0x87a1a0: add             x0, NULL, #0x30  ; false
    // 0x87a1a4: b               #0x87a1ac
    // 0x87a1a8: r0 = true
    //     0x87a1a8: add             x0, NULL, #0x20  ; true
    // 0x87a1ac: tbnz            w0, #4, #0x87a1c0
    // 0x87a1b0: ldur            x0, [fp, #-8]
    // 0x87a1b4: LeaveFrame
    //     0x87a1b4: mov             SP, fp
    //     0x87a1b8: ldp             fp, lr, [SP], #0x10
    // 0x87a1bc: ret
    //     0x87a1bc: ret             
    // 0x87a1c0: r0 = Null
    //     0x87a1c0: mov             x0, NULL
    // 0x87a1c4: LeaveFrame
    //     0x87a1c4: mov             SP, fp
    //     0x87a1c8: ldp             fp, lr, [SP], #0x10
    // 0x87a1cc: ret
    //     0x87a1cc: ret             
    // 0x87a1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87a1d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87a1d4: b               #0x87a0b0
  }
  static Action<Y0>? _maybeFindWithoutDependingOn<Y0 extends Intent>(BuildContext) {
    // ** addr: 0xb2fea8, size: 0xbc
    // 0xb2fea8: EnterFrame
    //     0xb2fea8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2feac: mov             fp, SP
    // 0xb2feb0: AllocStack(0x10)
    //     0xb2feb0: sub             SP, SP, #0x10
    // 0xb2feb4: SetupParameters()
    //     0xb2feb4: ldur            w0, [x4, #0xf]
    //     0xb2feb8: cbnz            w0, #0xb2fec4
    //     0xb2febc: mov             x1, NULL
    //     0xb2fec0: b               #0xb2fed4
    //     0xb2fec4: ldur            w1, [x4, #0x17]
    //     0xb2fec8: add             x2, fp, w1, sxtw #2
    //     0xb2fecc: ldr             x2, [x2, #0x10]
    //     0xb2fed0: mov             x1, x2
    // 0xb2fed4: CheckStackOverflow
    //     0xb2fed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2fed8: cmp             SP, x16
    //     0xb2fedc: b.ls            #0xb2ff5c
    // 0xb2fee0: cbnz            w0, #0xb2feec
    // 0xb2fee4: r0 = <Intent>
    //     0xb2fee4: ldr             x0, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0xb2fee8: b               #0xb2fef0
    // 0xb2feec: mov             x0, x1
    // 0xb2fef0: mov             x1, x0
    // 0xb2fef4: stur            x0, [fp, #-8]
    // 0xb2fef8: r2 = Null
    //     0xb2fef8: mov             x2, NULL
    // 0xb2fefc: r3 = Y0 bound Intent
    //     0xb2fefc: add             x3, PP, #0xae, lsl #12  ; [pp+0xae6b0] TypeParameter: Y0 bound Intent
    //     0xb2ff00: ldr             x3, [x3, #0x6b0]
    // 0xb2ff04: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0xb2ff04: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0xb2ff08: LoadField: r30 = r30->field_7
    //     0xb2ff08: ldur            lr, [lr, #7]
    // 0xb2ff0c: blr             lr
    // 0xb2ff10: r1 = 1
    //     0xb2ff10: mov             x1, #1
    // 0xb2ff14: r0 = AllocateContext()
    //     0xb2ff14: bl              #0x13de838  ; AllocateContextStub
    // 0xb2ff18: mov             x2, x0
    // 0xb2ff1c: r1 = Function '<anonymous closure>': static.
    //     0xb2ff1c: add             x1, PP, #0xae, lsl #12  ; [pp+0xae6b8] AnonymousClosure: static (0xb2ff64), in [package:flutter/src/widgets/actions.dart] Actions::_maybeFindWithoutDependingOn (0xb2fea8)
    //     0xb2ff20: ldr             x1, [x1, #0x6b8]
    // 0xb2ff24: stur            x0, [fp, #-0x10]
    // 0xb2ff28: r0 = AllocateClosure()
    //     0xb2ff28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2ff2c: mov             x1, x0
    // 0xb2ff30: ldur            x0, [fp, #-8]
    // 0xb2ff34: StoreField: r1->field_b = r0
    //     0xb2ff34: stur            w0, [x1, #0xb]
    // 0xb2ff38: mov             x2, x1
    // 0xb2ff3c: ldr             x1, [fp, #0x10]
    // 0xb2ff40: r0 = _visitActionsAncestors()
    //     0xb2ff40: bl              #0x87993c  ; [package:flutter/src/widgets/actions.dart] Actions::_visitActionsAncestors
    // 0xb2ff44: ldur            x1, [fp, #-0x10]
    // 0xb2ff48: LoadField: r0 = r1->field_f
    //     0xb2ff48: ldur            w0, [x1, #0xf]
    // 0xb2ff4c: DecompressPointer r0
    //     0xb2ff4c: add             x0, x0, HEAP, lsl #32
    // 0xb2ff50: LeaveFrame
    //     0xb2ff50: mov             SP, fp
    //     0xb2ff54: ldp             fp, lr, [SP], #0x10
    // 0xb2ff58: ret
    //     0xb2ff58: ret             
    // 0xb2ff5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ff5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ff60: b               #0xb2fee0
  }
  [closure] static bool <anonymous closure>(dynamic, InheritedElement) {
    // ** addr: 0xb2ff64, size: 0x154
    // 0xb2ff64: EnterFrame
    //     0xb2ff64: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ff68: mov             fp, SP
    // 0xb2ff6c: AllocStack(0x30)
    //     0xb2ff6c: sub             SP, SP, #0x30
    // 0xb2ff70: SetupParameters([dynamic _ /* r0 */])
    //     0xb2ff70: ldr             x0, [fp, #0x18]
    //     0xb2ff74: ldur            w3, [x0, #0x17]
    //     0xb2ff78: add             x3, x3, HEAP, lsl #32
    //     0xb2ff7c: stur            x3, [fp, #-0x18]
    // 0xb2ff80: CheckStackOverflow
    //     0xb2ff80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ff84: cmp             SP, x16
    //     0xb2ff88: b.ls            #0xb300a8
    // 0xb2ff8c: LoadField: r4 = r0->field_b
    //     0xb2ff8c: ldur            w4, [x0, #0xb]
    // 0xb2ff90: DecompressPointer r4
    //     0xb2ff90: add             x4, x4, HEAP, lsl #32
    // 0xb2ff94: ldr             x0, [fp, #0x10]
    // 0xb2ff98: stur            x4, [fp, #-0x10]
    // 0xb2ff9c: r1 = LoadClassIdInstr(r0)
    //     0xb2ff9c: ldur            x1, [x0, #-1]
    //     0xb2ffa0: ubfx            x1, x1, #0xc, #0x14
    // 0xb2ffa4: r17 = -5837
    //     0xb2ffa4: mov             x17, #-0x16cd
    // 0xb2ffa8: add             x16, x1, x17
    // 0xb2ffac: cmp             x16, #2
    // 0xb2ffb0: b.ls            #0xb2ffc0
    // 0xb2ffb4: r17 = 5835
    //     0xb2ffb4: mov             x17, #0x16cb
    // 0xb2ffb8: cmp             x1, x17
    // 0xb2ffbc: b.ne            #0xb2ffd8
    // 0xb2ffc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ffc0: ldur            w1, [x0, #0x17]
    // 0xb2ffc4: DecompressPointer r1
    //     0xb2ffc4: add             x1, x1, HEAP, lsl #32
    // 0xb2ffc8: cmp             w1, NULL
    // 0xb2ffcc: b.eq            #0xb300b0
    // 0xb2ffd0: mov             x3, x1
    // 0xb2ffd4: b               #0xb30014
    // 0xb2ffd8: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xb2ffd8: ldur            w5, [x0, #0x17]
    // 0xb2ffdc: DecompressPointer r5
    //     0xb2ffdc: add             x5, x5, HEAP, lsl #32
    // 0xb2ffe0: stur            x5, [fp, #-8]
    // 0xb2ffe4: cmp             w5, NULL
    // 0xb2ffe8: b.eq            #0xb300b4
    // 0xb2ffec: LoadField: r2 = r0->field_43
    //     0xb2ffec: ldur            w2, [x0, #0x43]
    // 0xb2fff0: DecompressPointer r2
    //     0xb2fff0: add             x2, x2, HEAP, lsl #32
    // 0xb2fff4: mov             x0, x5
    // 0xb2fff8: r1 = Null
    //     0xb2fff8: mov             x1, NULL
    // 0xb2fffc: r8 = _InheritedProviderScope<X0>
    //     0xb2fffc: ldr             x8, [PP, #0x1fb0]  ; [pp+0x1fb0] Type: _InheritedProviderScope<X0>
    // 0xb30000: LoadField: r9 = r8->field_7
    //     0xb30000: ldur            x9, [x8, #7]
    // 0xb30004: r3 = Null
    //     0xb30004: add             x3, PP, #0xae, lsl #12  ; [pp+0xae6c0] Null
    //     0xb30008: ldr             x3, [x3, #0x6c0]
    // 0xb3000c: blr             x9
    // 0xb30010: ldur            x3, [fp, #-8]
    // 0xb30014: mov             x0, x3
    // 0xb30018: stur            x3, [fp, #-8]
    // 0xb3001c: r2 = Null
    //     0xb3001c: mov             x2, NULL
    // 0xb30020: r1 = Null
    //     0xb30020: mov             x1, NULL
    // 0xb30024: r4 = LoadClassIdInstr(r0)
    //     0xb30024: ldur            x4, [x0, #-1]
    //     0xb30028: ubfx            x4, x4, #0xc, #0x14
    // 0xb3002c: r17 = 6799
    //     0xb3002c: mov             x17, #0x1a8f
    // 0xb30030: cmp             x4, x17
    // 0xb30034: b.eq            #0xb30048
    // 0xb30038: r8 = _ActionsScope
    //     0xb30038: ldr             x8, [PP, #0x46d0]  ; [pp+0x46d0] Type: _ActionsScope
    // 0xb3003c: r3 = Null
    //     0xb3003c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae6d0] Null
    //     0xb30040: ldr             x3, [x3, #0x6d0]
    // 0xb30044: r0 = DefaultTypeTest()
    //     0xb30044: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb30048: ldur            x16, [fp, #-0x10]
    // 0xb3004c: ldur            lr, [fp, #-8]
    // 0xb30050: stp             lr, x16, [SP, #8]
    // 0xb30054: str             NULL, [SP]
    // 0xb30058: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb30058: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb3005c: r0 = _castAction()
    //     0xb3005c: bl              #0x87a078  ; [package:flutter/src/widgets/actions.dart] Actions::_castAction
    // 0xb30060: cmp             w0, NULL
    // 0xb30064: b.eq            #0xb30098
    // 0xb30068: ldur            x1, [fp, #-0x18]
    // 0xb3006c: StoreField: r1->field_f = r0
    //     0xb3006c: stur            w0, [x1, #0xf]
    //     0xb30070: ldurb           w16, [x1, #-1]
    //     0xb30074: ldurb           w17, [x0, #-1]
    //     0xb30078: and             x16, x17, x16, lsr #2
    //     0xb3007c: tst             x16, HEAP, lsr #32
    //     0xb30080: b.eq            #0xb30088
    //     0xb30084: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb30088: r0 = true
    //     0xb30088: add             x0, NULL, #0x20  ; true
    // 0xb3008c: LeaveFrame
    //     0xb3008c: mov             SP, fp
    //     0xb30090: ldp             fp, lr, [SP], #0x10
    // 0xb30094: ret
    //     0xb30094: ret             
    // 0xb30098: r0 = false
    //     0xb30098: add             x0, NULL, #0x30  ; false
    // 0xb3009c: LeaveFrame
    //     0xb3009c: mov             SP, fp
    //     0xb300a0: ldp             fp, lr, [SP], #0x10
    // 0xb300a4: ret
    //     0xb300a4: ret             
    // 0xb300a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb300a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb300ac: b               #0xb2ff8c
    // 0xb300b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb300b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb300b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb300b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa35a8, size: 0x48
    // 0xfa35a8: EnterFrame
    //     0xfa35a8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa35ac: mov             fp, SP
    // 0xfa35b0: AllocStack(0x8)
    //     0xfa35b0: sub             SP, SP, #8
    // 0xfa35b4: CheckStackOverflow
    //     0xfa35b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa35b8: cmp             SP, x16
    //     0xfa35bc: b.ls            #0xfa35e8
    // 0xfa35c0: r1 = <Actions>
    //     0xfa35c0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90390] TypeArguments: <Actions>
    //     0xfa35c4: ldr             x1, [x1, #0x390]
    // 0xfa35c8: r0 = _ActionsState()
    //     0xfa35c8: bl              #0xfa3688  ; Allocate_ActionsStateStub -> _ActionsState (size=0x1c)
    // 0xfa35cc: mov             x1, x0
    // 0xfa35d0: stur            x0, [fp, #-8]
    // 0xfa35d4: r0 = _ActionsState()
    //     0xfa35d4: bl              #0xfa35f0  ; [package:flutter/src/widgets/actions.dart] _ActionsState::_ActionsState
    // 0xfa35d8: ldur            x0, [fp, #-8]
    // 0xfa35dc: LeaveFrame
    //     0xfa35dc: mov             SP, fp
    //     0xfa35e0: ldp             fp, lr, [SP], #0x10
    // 0xfa35e4: ret
    //     0xfa35e4: ret             
    // 0xfa35e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa35e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa35ec: b               #0xfa35c0
  }
  static _ of(/* No info */) {
    // ** addr: 0x1244630, size: 0x4c
    // 0x1244630: EnterFrame
    //     0x1244630: stp             fp, lr, [SP, #-0x10]!
    //     0x1244634: mov             fp, SP
    // 0x1244638: AllocStack(0x18)
    //     0x1244638: sub             SP, SP, #0x18
    // 0x124463c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x124463c: stur            x1, [fp, #-8]
    // 0x1244640: CheckStackOverflow
    //     0x1244640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1244644: cmp             SP, x16
    //     0x1244648: b.ls            #0x1244674
    // 0x124464c: r16 = <_ActionsScope>
    //     0x124464c: ldr             x16, [PP, #0x47a8]  ; [pp+0x47a8] TypeArguments: <_ActionsScope>
    // 0x1244650: stp             x1, x16, [SP]
    // 0x1244654: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1244654: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1244658: r0 = dependOnInheritedWidgetOfExactType()
    //     0x1244658: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x124465c: ldur            x1, [fp, #-8]
    // 0x1244660: r0 = _findDispatcher()
    //     0x1244660: bl              #0x879e38  ; [package:flutter/src/widgets/actions.dart] Actions::_findDispatcher
    // 0x1244664: r0 = Instance_ActionDispatcher
    //     0x1244664: ldr             x0, [PP, #0x4738]  ; [pp+0x4738] Obj!ActionDispatcher@12aa551
    // 0x1244668: LeaveFrame
    //     0x1244668: mov             SP, fp
    //     0x124466c: ldp             fp, lr, [SP], #0x10
    // 0x1244670: ret
    //     0x1244670: ret             
    // 0x1244674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1244674: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1244678: b               #0x124464c
  }
  static Action<Y0>? maybeFind<Y0 extends Intent>(BuildContext, Y0?) {
    // ** addr: 0x12458a0, size: 0x11c
    // 0x12458a0: EnterFrame
    //     0x12458a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12458a4: mov             fp, SP
    // 0x12458a8: AllocStack(0x20)
    //     0x12458a8: sub             SP, SP, #0x20
    // 0x12458ac: SetupParameters([dynamic _ /* r1 */, dynamic _ /* r2 */])
    //     0x12458ac: ldur            w0, [x4, #0xf]
    //     0x12458b0: stur            x0, [fp, #-0x10]
    //     0x12458b4: cbnz            w0, #0x12458c0
    //     0x12458b8: mov             x3, NULL
    //     0x12458bc: b               #0x12458d0
    //     0x12458c0: ldur            w1, [x4, #0x17]
    //     0x12458c4: add             x2, fp, w1, sxtw #2
    //     0x12458c8: ldr             x2, [x2, #0x10]
    //     0x12458cc: mov             x3, x2
    //     0x12458d0: ldr             x2, [fp, #0x18]
    //     0x12458d4: ldr             x1, [fp, #0x10]
    //     0x12458d8: stur            x3, [fp, #-8]
    // 0x12458dc: CheckStackOverflow
    //     0x12458dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12458e0: cmp             SP, x16
    //     0x12458e4: b.ls            #0x12459b4
    // 0x12458e8: r1 = 3
    //     0x12458e8: mov             x1, #3
    // 0x12458ec: r0 = AllocateContext()
    //     0x12458ec: bl              #0x13de838  ; AllocateContextStub
    // 0x12458f0: mov             x1, x0
    // 0x12458f4: ldr             x0, [fp, #0x18]
    // 0x12458f8: stur            x1, [fp, #-0x18]
    // 0x12458fc: StoreField: r1->field_f = r0
    //     0x12458fc: stur            w0, [x1, #0xf]
    // 0x1245900: ldr             x0, [fp, #0x10]
    // 0x1245904: StoreField: r1->field_13 = r0
    //     0x1245904: stur            w0, [x1, #0x13]
    // 0x1245908: ldur            x2, [fp, #-0x10]
    // 0x124590c: cbnz            w2, #0x1245918
    // 0x1245910: r2 = <Intent>
    //     0x1245910: ldr             x2, [PP, #0x46b0]  ; [pp+0x46b0] TypeArguments: <Intent>
    // 0x1245914: b               #0x124591c
    // 0x1245918: ldur            x2, [fp, #-8]
    // 0x124591c: stur            x2, [fp, #-8]
    // 0x1245920: ArrayStore: r1[0] = rNULL  ; List_4
    //     0x1245920: stur            NULL, [x1, #0x17]
    // 0x1245924: cmp             w0, NULL
    // 0x1245928: b.ne            #0x1245934
    // 0x124592c: r0 = Null
    //     0x124592c: mov             x0, NULL
    // 0x1245930: b               #0x124593c
    // 0x1245934: str             x0, [SP]
    // 0x1245938: r0 = runtimeType()
    //     0x1245938: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x124593c: cmp             w0, NULL
    // 0x1245940: b.ne            #0x1245960
    // 0x1245944: ldur            x1, [fp, #-8]
    // 0x1245948: r2 = Null
    //     0x1245948: mov             x2, NULL
    // 0x124594c: r3 = Y0 bound Intent
    //     0x124594c: add             x3, PP, #0xac, lsl #12  ; [pp+0xacec0] TypeParameter: Y0 bound Intent
    //     0x1245950: ldr             x3, [x3, #0xec0]
    // 0x1245954: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x1245954: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0x1245958: LoadField: r30 = r30->field_7
    //     0x1245958: ldur            lr, [lr, #7]
    // 0x124595c: blr             lr
    // 0x1245960: ldur            x0, [fp, #-0x18]
    // 0x1245964: ldur            x3, [fp, #-8]
    // 0x1245968: LoadField: r4 = r0->field_f
    //     0x1245968: ldur            w4, [x0, #0xf]
    // 0x124596c: DecompressPointer r4
    //     0x124596c: add             x4, x4, HEAP, lsl #32
    // 0x1245970: mov             x2, x0
    // 0x1245974: stur            x4, [fp, #-0x10]
    // 0x1245978: r1 = Function '<anonymous closure>': static.
    //     0x1245978: add             x1, PP, #0xac, lsl #12  ; [pp+0xacec8] AnonymousClosure: static (0x12459bc), in [package:flutter/src/widgets/actions.dart] Actions::maybeFind (0x12458a0)
    //     0x124597c: ldr             x1, [x1, #0xec8]
    // 0x1245980: r0 = AllocateClosure()
    //     0x1245980: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1245984: mov             x1, x0
    // 0x1245988: ldur            x0, [fp, #-8]
    // 0x124598c: StoreField: r1->field_b = r0
    //     0x124598c: stur            w0, [x1, #0xb]
    // 0x1245990: mov             x2, x1
    // 0x1245994: ldur            x1, [fp, #-0x10]
    // 0x1245998: r0 = _visitActionsAncestors()
    //     0x1245998: bl              #0x87993c  ; [package:flutter/src/widgets/actions.dart] Actions::_visitActionsAncestors
    // 0x124599c: ldur            x1, [fp, #-0x18]
    // 0x12459a0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12459a0: ldur            w0, [x1, #0x17]
    // 0x12459a4: DecompressPointer r0
    //     0x12459a4: add             x0, x0, HEAP, lsl #32
    // 0x12459a8: LeaveFrame
    //     0x12459a8: mov             SP, fp
    //     0x12459ac: ldp             fp, lr, [SP], #0x10
    // 0x12459b0: ret
    //     0x12459b0: ret             
    // 0x12459b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12459b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12459b8: b               #0x12458e8
  }
  [closure] static bool <anonymous closure>(dynamic, InheritedElement) {
    // ** addr: 0x12459bc, size: 0x184
    // 0x12459bc: EnterFrame
    //     0x12459bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12459c0: mov             fp, SP
    // 0x12459c4: AllocStack(0x30)
    //     0x12459c4: sub             SP, SP, #0x30
    // 0x12459c8: SetupParameters([dynamic _ /* r0 */])
    //     0x12459c8: ldr             x0, [fp, #0x18]
    //     0x12459cc: ldur            w3, [x0, #0x17]
    //     0x12459d0: add             x3, x3, HEAP, lsl #32
    //     0x12459d4: stur            x3, [fp, #-0x18]
    // 0x12459d8: CheckStackOverflow
    //     0x12459d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12459dc: cmp             SP, x16
    //     0x12459e0: b.ls            #0x1245b30
    // 0x12459e4: LoadField: r4 = r0->field_b
    //     0x12459e4: ldur            w4, [x0, #0xb]
    // 0x12459e8: DecompressPointer r4
    //     0x12459e8: add             x4, x4, HEAP, lsl #32
    // 0x12459ec: ldr             x5, [fp, #0x10]
    // 0x12459f0: stur            x4, [fp, #-0x10]
    // 0x12459f4: r0 = LoadClassIdInstr(r5)
    //     0x12459f4: ldur            x0, [x5, #-1]
    //     0x12459f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12459fc: r17 = -5837
    //     0x12459fc: mov             x17, #-0x16cd
    // 0x1245a00: add             x16, x0, x17
    // 0x1245a04: cmp             x16, #2
    // 0x1245a08: b.ls            #0x1245a18
    // 0x1245a0c: r17 = 5835
    //     0x1245a0c: mov             x17, #0x16cb
    // 0x1245a10: cmp             x0, x17
    // 0x1245a14: b.ne            #0x1245a30
    // 0x1245a18: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x1245a18: ldur            w0, [x5, #0x17]
    // 0x1245a1c: DecompressPointer r0
    //     0x1245a1c: add             x0, x0, HEAP, lsl #32
    // 0x1245a20: cmp             w0, NULL
    // 0x1245a24: b.eq            #0x1245b38
    // 0x1245a28: mov             x4, x0
    // 0x1245a2c: b               #0x1245a70
    // 0x1245a30: ArrayLoad: r6 = r5[0]  ; List_4
    //     0x1245a30: ldur            w6, [x5, #0x17]
    // 0x1245a34: DecompressPointer r6
    //     0x1245a34: add             x6, x6, HEAP, lsl #32
    // 0x1245a38: stur            x6, [fp, #-8]
    // 0x1245a3c: cmp             w6, NULL
    // 0x1245a40: b.eq            #0x1245b3c
    // 0x1245a44: LoadField: r2 = r5->field_43
    //     0x1245a44: ldur            w2, [x5, #0x43]
    // 0x1245a48: DecompressPointer r2
    //     0x1245a48: add             x2, x2, HEAP, lsl #32
    // 0x1245a4c: mov             x0, x6
    // 0x1245a50: r1 = Null
    //     0x1245a50: mov             x1, NULL
    // 0x1245a54: r8 = _InheritedProviderScope<X0>
    //     0x1245a54: ldr             x8, [PP, #0x1fb0]  ; [pp+0x1fb0] Type: _InheritedProviderScope<X0>
    // 0x1245a58: LoadField: r9 = r8->field_7
    //     0x1245a58: ldur            x9, [x8, #7]
    // 0x1245a5c: r3 = Null
    //     0x1245a5c: add             x3, PP, #0xac, lsl #12  ; [pp+0xaced0] Null
    //     0x1245a60: ldr             x3, [x3, #0xed0]
    // 0x1245a64: blr             x9
    // 0x1245a68: ldur            x4, [fp, #-8]
    // 0x1245a6c: ldur            x3, [fp, #-0x18]
    // 0x1245a70: mov             x0, x4
    // 0x1245a74: stur            x4, [fp, #-8]
    // 0x1245a78: r2 = Null
    //     0x1245a78: mov             x2, NULL
    // 0x1245a7c: r1 = Null
    //     0x1245a7c: mov             x1, NULL
    // 0x1245a80: r4 = LoadClassIdInstr(r0)
    //     0x1245a80: ldur            x4, [x0, #-1]
    //     0x1245a84: ubfx            x4, x4, #0xc, #0x14
    // 0x1245a88: r17 = 6799
    //     0x1245a88: mov             x17, #0x1a8f
    // 0x1245a8c: cmp             x4, x17
    // 0x1245a90: b.eq            #0x1245aa4
    // 0x1245a94: r8 = _ActionsScope
    //     0x1245a94: ldr             x8, [PP, #0x46d0]  ; [pp+0x46d0] Type: _ActionsScope
    // 0x1245a98: r3 = Null
    //     0x1245a98: add             x3, PP, #0xac, lsl #12  ; [pp+0xacee0] Null
    //     0x1245a9c: ldr             x3, [x3, #0xee0]
    // 0x1245aa0: r0 = DefaultTypeTest()
    //     0x1245aa0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1245aa4: ldur            x0, [fp, #-0x18]
    // 0x1245aa8: LoadField: r1 = r0->field_13
    //     0x1245aa8: ldur            w1, [x0, #0x13]
    // 0x1245aac: DecompressPointer r1
    //     0x1245aac: add             x1, x1, HEAP, lsl #32
    // 0x1245ab0: ldur            x16, [fp, #-0x10]
    // 0x1245ab4: ldur            lr, [fp, #-8]
    // 0x1245ab8: stp             lr, x16, [SP, #8]
    // 0x1245abc: str             x1, [SP]
    // 0x1245ac0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1245ac0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1245ac4: r0 = _castAction()
    //     0x1245ac4: bl              #0x87a078  ; [package:flutter/src/widgets/actions.dart] Actions::_castAction
    // 0x1245ac8: stur            x0, [fp, #-8]
    // 0x1245acc: cmp             w0, NULL
    // 0x1245ad0: b.eq            #0x1245b20
    // 0x1245ad4: ldur            x3, [fp, #-0x18]
    // 0x1245ad8: LoadField: r1 = r3->field_f
    //     0x1245ad8: ldur            w1, [x3, #0xf]
    // 0x1245adc: DecompressPointer r1
    //     0x1245adc: add             x1, x1, HEAP, lsl #32
    // 0x1245ae0: ldr             x2, [fp, #0x10]
    // 0x1245ae4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1245ae4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1245ae8: r0 = dependOnInheritedElement()
    //     0x1245ae8: bl              #0xb6f970  ; [package:flutter/src/widgets/framework.dart] StatefulElement::dependOnInheritedElement
    // 0x1245aec: ldur            x0, [fp, #-8]
    // 0x1245af0: ldur            x1, [fp, #-0x18]
    // 0x1245af4: ArrayStore: r1[0] = r0  ; List_4
    //     0x1245af4: stur            w0, [x1, #0x17]
    //     0x1245af8: ldurb           w16, [x1, #-1]
    //     0x1245afc: ldurb           w17, [x0, #-1]
    //     0x1245b00: and             x16, x17, x16, lsr #2
    //     0x1245b04: tst             x16, HEAP, lsr #32
    //     0x1245b08: b.eq            #0x1245b10
    //     0x1245b0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1245b10: r0 = true
    //     0x1245b10: add             x0, NULL, #0x20  ; true
    // 0x1245b14: LeaveFrame
    //     0x1245b14: mov             SP, fp
    //     0x1245b18: ldp             fp, lr, [SP], #0x10
    // 0x1245b1c: ret
    //     0x1245b1c: ret             
    // 0x1245b20: r0 = false
    //     0x1245b20: add             x0, NULL, #0x30  ; false
    // 0x1245b24: LeaveFrame
    //     0x1245b24: mov             SP, fp
    //     0x1245b28: ldp             fp, lr, [SP], #0x10
    // 0x1245b2c: ret
    //     0x1245b2c: ret             
    // 0x1245b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1245b30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1245b34: b               #0x12459e4
    // 0x1245b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1245b38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1245b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1245b3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6799, size: 0x1c, field offset: 0x10
//   const constructor, 
class _ActionsScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc014ec, size: 0xcc
    // 0xc014ec: EnterFrame
    //     0xc014ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc014f0: mov             fp, SP
    // 0xc014f4: AllocStack(0x28)
    //     0xc014f4: sub             SP, SP, #0x28
    // 0xc014f8: SetupParameters(_ActionsScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc014f8: mov             x4, x1
    //     0xc014fc: mov             x3, x2
    //     0xc01500: stur            x1, [fp, #-8]
    //     0xc01504: stur            x2, [fp, #-0x10]
    // 0xc01508: CheckStackOverflow
    //     0xc01508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0150c: cmp             SP, x16
    //     0xc01510: b.ls            #0xc015b0
    // 0xc01514: mov             x0, x3
    // 0xc01518: r2 = Null
    //     0xc01518: mov             x2, NULL
    // 0xc0151c: r1 = Null
    //     0xc0151c: mov             x1, NULL
    // 0xc01520: r4 = 60
    //     0xc01520: mov             x4, #0x3c
    // 0xc01524: branchIfSmi(r0, 0xc01530)
    //     0xc01524: tbz             w0, #0, #0xc01530
    // 0xc01528: r4 = LoadClassIdInstr(r0)
    //     0xc01528: ldur            x4, [x0, #-1]
    //     0xc0152c: ubfx            x4, x4, #0xc, #0x14
    // 0xc01530: r17 = 6799
    //     0xc01530: mov             x17, #0x1a8f
    // 0xc01534: cmp             x4, x17
    // 0xc01538: b.eq            #0xc0154c
    // 0xc0153c: r8 = _ActionsScope
    //     0xc0153c: ldr             x8, [PP, #0x46d0]  ; [pp+0x46d0] Type: _ActionsScope
    // 0xc01540: r3 = Null
    //     0xc01540: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3f50] Null
    //     0xc01544: ldr             x3, [x3, #0xf50]
    // 0xc01548: r0 = DefaultTypeTest()
    //     0xc01548: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc0154c: ldur            x0, [fp, #-8]
    // 0xc01550: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc01550: ldur            w1, [x0, #0x17]
    // 0xc01554: DecompressPointer r1
    //     0xc01554: add             x1, x1, HEAP, lsl #32
    // 0xc01558: ldur            x2, [fp, #-0x10]
    // 0xc0155c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc0155c: ldur            w3, [x2, #0x17]
    // 0xc01560: DecompressPointer r3
    //     0xc01560: add             x3, x3, HEAP, lsl #32
    // 0xc01564: cmp             w1, w3
    // 0xc01568: b.eq            #0xc01574
    // 0xc0156c: r0 = true
    //     0xc0156c: add             x0, NULL, #0x20  ; true
    // 0xc01570: b               #0xc015a4
    // 0xc01574: LoadField: r1 = r2->field_13
    //     0xc01574: ldur            w1, [x2, #0x13]
    // 0xc01578: DecompressPointer r1
    //     0xc01578: add             x1, x1, HEAP, lsl #32
    // 0xc0157c: LoadField: r2 = r0->field_13
    //     0xc0157c: ldur            w2, [x0, #0x13]
    // 0xc01580: DecompressPointer r2
    //     0xc01580: add             x2, x2, HEAP, lsl #32
    // 0xc01584: r16 = <Type, Action<Intent>>
    //     0xc01584: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xc01588: ldr             x16, [x16, #0xb80]
    // 0xc0158c: stp             x1, x16, [SP, #8]
    // 0xc01590: str             x2, [SP]
    // 0xc01594: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc01594: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0xc01598: r0 = mapEquals()
    //     0xc01598: bl              #0xc015b8  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0xc0159c: eor             x1, x0, #0x10
    // 0xc015a0: mov             x0, x1
    // 0xc015a4: LeaveFrame
    //     0xc015a4: mov             SP, fp
    //     0xc015a8: ldp             fp, lr, [SP], #0x10
    // 0xc015ac: ret
    //     0xc015ac: ret             
    // 0xc015b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc015b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc015b4: b               #0xc01514
  }
}
