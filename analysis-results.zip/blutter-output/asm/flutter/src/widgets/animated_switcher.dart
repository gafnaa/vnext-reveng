// lib: , url: package:flutter/src/widgets/animated_switcher.dart

// class id: 1049113, size: 0x8
class :: {
}

// class id: 2717, size: 0x18, field offset: 0x8
class _ChildEntry extends Object {
}

// class id: 5675, size: 0x30, field offset: 0x1c
class _AnimatedSwitcherState extends _MixinApplication189&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd5c2cc, size: 0xe8
    // 0xd5c2cc: EnterFrame
    //     0xd5c2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c2d0: mov             fp, SP
    // 0xd5c2d4: AllocStack(0x20)
    //     0xd5c2d4: sub             SP, SP, #0x20
    // 0xd5c2d8: SetupParameters(_AnimatedSwitcherState this /* r1 => r1, fp-0x8 */)
    //     0xd5c2d8: stur            x1, [fp, #-8]
    // 0xd5c2dc: CheckStackOverflow
    //     0xd5c2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5c2e0: cmp             SP, x16
    //     0xd5c2e4: b.ls            #0xd5c3a4
    // 0xd5c2e8: r1 = 1
    //     0xd5c2e8: mov             x1, #1
    // 0xd5c2ec: r0 = AllocateContext()
    //     0xd5c2ec: bl              #0x13de838  ; AllocateContextStub
    // 0xd5c2f0: mov             x2, x0
    // 0xd5c2f4: ldur            x0, [fp, #-8]
    // 0xd5c2f8: stur            x2, [fp, #-0x10]
    // 0xd5c2fc: StoreField: r2->field_f = r0
    //     0xd5c2fc: stur            w0, [x2, #0xf]
    // 0xd5c300: mov             x1, x0
    // 0xd5c304: r0 = _rebuildOutgoingWidgetsIfNeeded()
    //     0xd5c304: bl              #0xd5c3b4  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_rebuildOutgoingWidgetsIfNeeded
    // 0xd5c308: ldur            x0, [fp, #-8]
    // 0xd5c30c: LoadField: r1 = r0->field_b
    //     0xd5c30c: ldur            w1, [x0, #0xb]
    // 0xd5c310: DecompressPointer r1
    //     0xd5c310: add             x1, x1, HEAP, lsl #32
    // 0xd5c314: cmp             w1, NULL
    // 0xd5c318: b.eq            #0xd5c3ac
    // 0xd5c31c: LoadField: r1 = r0->field_1b
    //     0xd5c31c: ldur            w1, [x0, #0x1b]
    // 0xd5c320: DecompressPointer r1
    //     0xd5c320: add             x1, x1, HEAP, lsl #32
    // 0xd5c324: cmp             w1, NULL
    // 0xd5c328: b.ne            #0xd5c334
    // 0xd5c32c: r3 = Null
    //     0xd5c32c: mov             x3, NULL
    // 0xd5c330: b               #0xd5c340
    // 0xd5c334: LoadField: r2 = r1->field_f
    //     0xd5c334: ldur            w2, [x1, #0xf]
    // 0xd5c338: DecompressPointer r2
    //     0xd5c338: add             x2, x2, HEAP, lsl #32
    // 0xd5c33c: mov             x3, x2
    // 0xd5c340: stur            x3, [fp, #-0x20]
    // 0xd5c344: LoadField: r4 = r0->field_23
    //     0xd5c344: ldur            w4, [x0, #0x23]
    // 0xd5c348: DecompressPointer r4
    //     0xd5c348: add             x4, x4, HEAP, lsl #32
    // 0xd5c34c: stur            x4, [fp, #-0x18]
    // 0xd5c350: cmp             w4, NULL
    // 0xd5c354: b.eq            #0xd5c3b0
    // 0xd5c358: ldur            x2, [fp, #-0x10]
    // 0xd5c35c: r1 = Function '<anonymous closure>':.
    //     0xd5c35c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcccb8] AnonymousClosure: (0xd5c498), in [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::build (0xd5c2cc)
    //     0xd5c360: ldr             x1, [x1, #0xcb8]
    // 0xd5c364: r0 = AllocateClosure()
    //     0xd5c364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c368: ldur            x1, [fp, #-0x18]
    // 0xd5c36c: mov             x2, x0
    // 0xd5c370: r0 = where()
    //     0xd5c370: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xd5c374: mov             x1, x0
    // 0xd5c378: r0 = toSet()
    //     0xd5c378: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xd5c37c: LoadField: r1 = r0->field_7
    //     0xd5c37c: ldur            w1, [x0, #7]
    // 0xd5c380: DecompressPointer r1
    //     0xd5c380: add             x1, x1, HEAP, lsl #32
    // 0xd5c384: mov             x2, x0
    // 0xd5c388: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xd5c388: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xd5c38c: ldur            x1, [fp, #-0x20]
    // 0xd5c390: mov             x2, x0
    // 0xd5c394: r0 = _topStartLayout()
    //     0xd5c394: bl              #0xd2dd94  ; [package:flutter/src/material/input_decorator.dart] _InputDecoratorState::_topStartLayout
    // 0xd5c398: LeaveFrame
    //     0xd5c398: mov             SP, fp
    //     0xd5c39c: ldp             fp, lr, [SP], #0x10
    // 0xd5c3a0: ret
    //     0xd5c3a0: ret             
    // 0xd5c3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5c3a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5c3a8: b               #0xd5c2e8
    // 0xd5c3ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5c3ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5c3b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5c3b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _rebuildOutgoingWidgetsIfNeeded(/* No info */) {
    // ** addr: 0xd5c3b4, size: 0xc4
    // 0xd5c3b4: EnterFrame
    //     0xd5c3b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c3b8: mov             fp, SP
    // 0xd5c3bc: AllocStack(0x28)
    //     0xd5c3bc: sub             SP, SP, #0x28
    // 0xd5c3c0: SetupParameters(_AnimatedSwitcherState this /* r1 => r0, fp-0x10 */)
    //     0xd5c3c0: mov             x0, x1
    //     0xd5c3c4: stur            x1, [fp, #-0x10]
    // 0xd5c3c8: CheckStackOverflow
    //     0xd5c3c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5c3cc: cmp             SP, x16
    //     0xd5c3d0: b.ls            #0xd5c470
    // 0xd5c3d4: LoadField: r1 = r0->field_23
    //     0xd5c3d4: ldur            w1, [x0, #0x23]
    // 0xd5c3d8: DecompressPointer r1
    //     0xd5c3d8: add             x1, x1, HEAP, lsl #32
    // 0xd5c3dc: cmp             w1, NULL
    // 0xd5c3e0: b.ne            #0xd5c460
    // 0xd5c3e4: LoadField: r3 = r0->field_1f
    //     0xd5c3e4: ldur            w3, [x0, #0x1f]
    // 0xd5c3e8: DecompressPointer r3
    //     0xd5c3e8: add             x3, x3, HEAP, lsl #32
    // 0xd5c3ec: stur            x3, [fp, #-8]
    // 0xd5c3f0: r1 = Function '<anonymous closure>':.
    //     0xd5c3f0: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcccc0] Function: [package:flutter/src/widgets/icon_data.dart] IconData::fontFamily (0x12dc910)
    //     0xd5c3f4: ldr             x1, [x1, #0xcc0]
    // 0xd5c3f8: r2 = Null
    //     0xd5c3f8: mov             x2, NULL
    // 0xd5c3fc: r0 = AllocateClosure()
    //     0xd5c3fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5c400: r16 = <Widget>
    //     0xd5c400: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd5c404: ldur            lr, [fp, #-8]
    // 0xd5c408: stp             lr, x16, [SP, #8]
    // 0xd5c40c: str             x0, [SP]
    // 0xd5c410: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd5c410: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd5c414: r0 = map()
    //     0xd5c414: bl              #0xba5848  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::map
    // 0xd5c418: r16 = false
    //     0xd5c418: add             x16, NULL, #0x30  ; false
    // 0xd5c41c: str             x16, [SP]
    // 0xd5c420: mov             x2, x0
    // 0xd5c424: r1 = <Widget>
    //     0xd5c424: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd5c428: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0xd5c428: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0xd5c42c: r0 = List.from()
    //     0xd5c42c: bl              #0x876494  ; [dart:core] List::List.from
    // 0xd5c430: r16 = <Widget>
    //     0xd5c430: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd5c434: stp             x0, x16, [SP]
    // 0xd5c438: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5c438: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5c43c: r0 = makeFixedListUnmodifiable()
    //     0xd5c43c: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xd5c440: ldur            x1, [fp, #-0x10]
    // 0xd5c444: StoreField: r1->field_23 = r0
    //     0xd5c444: stur            w0, [x1, #0x23]
    //     0xd5c448: ldurb           w16, [x1, #-1]
    //     0xd5c44c: ldurb           w17, [x0, #-1]
    //     0xd5c450: and             x16, x17, x16, lsr #2
    //     0xd5c454: tst             x16, HEAP, lsr #32
    //     0xd5c458: b.eq            #0xd5c460
    //     0xd5c45c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd5c460: r0 = Null
    //     0xd5c460: mov             x0, NULL
    // 0xd5c464: LeaveFrame
    //     0xd5c464: mov             SP, fp
    //     0xd5c468: ldp             fp, lr, [SP], #0x10
    // 0xd5c46c: ret
    //     0xd5c46c: ret             
    // 0xd5c470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5c470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5c474: b               #0xd5c3d4
  }
  [closure] bool <anonymous closure>(dynamic, Widget) {
    // ** addr: 0xd5c498, size: 0x9c
    // 0xd5c498: EnterFrame
    //     0xd5c498: stp             fp, lr, [SP, #-0x10]!
    //     0xd5c49c: mov             fp, SP
    // 0xd5c4a0: AllocStack(0x10)
    //     0xd5c4a0: sub             SP, SP, #0x10
    // 0xd5c4a4: SetupParameters([dynamic _ /* r0 */])
    //     0xd5c4a4: ldr             x0, [fp, #0x18]
    //     0xd5c4a8: ldur            w1, [x0, #0x17]
    //     0xd5c4ac: add             x1, x1, HEAP, lsl #32
    // 0xd5c4b0: CheckStackOverflow
    //     0xd5c4b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5c4b4: cmp             SP, x16
    //     0xd5c4b8: b.ls            #0xd5c52c
    // 0xd5c4bc: ldr             x0, [fp, #0x10]
    // 0xd5c4c0: LoadField: r2 = r0->field_7
    //     0xd5c4c0: ldur            w2, [x0, #7]
    // 0xd5c4c4: DecompressPointer r2
    //     0xd5c4c4: add             x2, x2, HEAP, lsl #32
    // 0xd5c4c8: LoadField: r0 = r1->field_f
    //     0xd5c4c8: ldur            w0, [x1, #0xf]
    // 0xd5c4cc: DecompressPointer r0
    //     0xd5c4cc: add             x0, x0, HEAP, lsl #32
    // 0xd5c4d0: LoadField: r1 = r0->field_1b
    //     0xd5c4d0: ldur            w1, [x0, #0x1b]
    // 0xd5c4d4: DecompressPointer r1
    //     0xd5c4d4: add             x1, x1, HEAP, lsl #32
    // 0xd5c4d8: cmp             w1, NULL
    // 0xd5c4dc: b.ne            #0xd5c4e8
    // 0xd5c4e0: r0 = Null
    //     0xd5c4e0: mov             x0, NULL
    // 0xd5c4e4: b               #0xd5c4fc
    // 0xd5c4e8: LoadField: r0 = r1->field_f
    //     0xd5c4e8: ldur            w0, [x1, #0xf]
    // 0xd5c4ec: DecompressPointer r0
    //     0xd5c4ec: add             x0, x0, HEAP, lsl #32
    // 0xd5c4f0: LoadField: r1 = r0->field_7
    //     0xd5c4f0: ldur            w1, [x0, #7]
    // 0xd5c4f4: DecompressPointer r1
    //     0xd5c4f4: add             x1, x1, HEAP, lsl #32
    // 0xd5c4f8: mov             x0, x1
    // 0xd5c4fc: r1 = LoadClassIdInstr(r2)
    //     0xd5c4fc: ldur            x1, [x2, #-1]
    //     0xd5c500: ubfx            x1, x1, #0xc, #0x14
    // 0xd5c504: stp             x0, x2, [SP]
    // 0xd5c508: mov             x0, x1
    // 0xd5c50c: mov             lr, x0
    // 0xd5c510: ldr             lr, [x21, lr, lsl #3]
    // 0xd5c514: blr             lr
    // 0xd5c518: eor             x1, x0, #0x10
    // 0xd5c51c: mov             x0, x1
    // 0xd5c520: LeaveFrame
    //     0xd5c520: mov             SP, fp
    //     0xd5c524: ldp             fp, lr, [SP], #0x10
    // 0xd5c528: ret
    //     0xd5c528: ret             
    // 0xd5c52c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5c52c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5c530: b               #0xd5c4bc
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3eb6c, size: 0x210
    // 0xf3eb6c: EnterFrame
    //     0xf3eb6c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3eb70: mov             fp, SP
    // 0xf3eb74: AllocStack(0x20)
    //     0xf3eb74: sub             SP, SP, #0x20
    // 0xf3eb78: SetupParameters(_AnimatedSwitcherState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3eb78: mov             x4, x1
    //     0xf3eb7c: mov             x3, x2
    //     0xf3eb80: stur            x1, [fp, #-8]
    //     0xf3eb84: stur            x2, [fp, #-0x10]
    // 0xf3eb88: CheckStackOverflow
    //     0xf3eb88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3eb8c: cmp             SP, x16
    //     0xf3eb90: b.ls            #0xf3ed68
    // 0xf3eb94: mov             x0, x3
    // 0xf3eb98: r2 = Null
    //     0xf3eb98: mov             x2, NULL
    // 0xf3eb9c: r1 = Null
    //     0xf3eb9c: mov             x1, NULL
    // 0xf3eba0: r4 = 60
    //     0xf3eba0: mov             x4, #0x3c
    // 0xf3eba4: branchIfSmi(r0, 0xf3ebb0)
    //     0xf3eba4: tbz             w0, #0, #0xf3ebb0
    // 0xf3eba8: r4 = LoadClassIdInstr(r0)
    //     0xf3eba8: ldur            x4, [x0, #-1]
    //     0xf3ebac: ubfx            x4, x4, #0xc, #0x14
    // 0xf3ebb0: r17 = 6406
    //     0xf3ebb0: mov             x17, #0x1906
    // 0xf3ebb4: cmp             x4, x17
    // 0xf3ebb8: b.eq            #0xf3ebd0
    // 0xf3ebbc: r8 = AnimatedSwitcher
    //     0xf3ebbc: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcccd8] Type: AnimatedSwitcher
    //     0xf3ebc0: ldr             x8, [x8, #0xcd8]
    // 0xf3ebc4: r3 = Null
    //     0xf3ebc4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccce0] Null
    //     0xf3ebc8: ldr             x3, [x3, #0xce0]
    // 0xf3ebcc: r0 = AnimatedSwitcher()
    //     0xf3ebcc: bl              #0xad2f5c  ; IsType_AnimatedSwitcher_Stub
    // 0xf3ebd0: ldur            x3, [fp, #-8]
    // 0xf3ebd4: LoadField: r2 = r3->field_7
    //     0xf3ebd4: ldur            w2, [x3, #7]
    // 0xf3ebd8: DecompressPointer r2
    //     0xf3ebd8: add             x2, x2, HEAP, lsl #32
    // 0xf3ebdc: ldur            x0, [fp, #-0x10]
    // 0xf3ebe0: r1 = Null
    //     0xf3ebe0: mov             x1, NULL
    // 0xf3ebe4: cmp             w2, NULL
    // 0xf3ebe8: b.eq            #0xf3ec0c
    // 0xf3ebec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3ebec: ldur            w4, [x2, #0x17]
    // 0xf3ebf0: DecompressPointer r4
    //     0xf3ebf0: add             x4, x4, HEAP, lsl #32
    // 0xf3ebf4: r8 = X0 bound StatefulWidget
    //     0xf3ebf4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3ebf8: ldr             x8, [x8, #0x498]
    // 0xf3ebfc: LoadField: r9 = r4->field_7
    //     0xf3ebfc: ldur            x9, [x4, #7]
    // 0xf3ec00: r3 = Null
    //     0xf3ec00: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcccf0] Null
    //     0xf3ec04: ldr             x3, [x3, #0xcf0]
    // 0xf3ec08: blr             x9
    // 0xf3ec0c: ldur            x2, [fp, #-8]
    // 0xf3ec10: LoadField: r0 = r2->field_b
    //     0xf3ec10: ldur            w0, [x2, #0xb]
    // 0xf3ec14: DecompressPointer r0
    //     0xf3ec14: add             x0, x0, HEAP, lsl #32
    // 0xf3ec18: cmp             w0, NULL
    // 0xf3ec1c: b.eq            #0xf3ed70
    // 0xf3ec20: LoadField: r1 = r0->field_1f
    //     0xf3ec20: ldur            w1, [x0, #0x1f]
    // 0xf3ec24: DecompressPointer r1
    //     0xf3ec24: add             x1, x1, HEAP, lsl #32
    // 0xf3ec28: ldur            x0, [fp, #-0x10]
    // 0xf3ec2c: LoadField: r3 = r0->field_1f
    //     0xf3ec2c: ldur            w3, [x0, #0x1f]
    // 0xf3ec30: DecompressPointer r3
    //     0xf3ec30: add             x3, x3, HEAP, lsl #32
    // 0xf3ec34: stp             x3, x1, [SP]
    // 0xf3ec38: r0 = ==()
    //     0xf3ec38: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xf3ec3c: tbz             w0, #4, #0xf3ec90
    // 0xf3ec40: ldur            x0, [fp, #-8]
    // 0xf3ec44: LoadField: r3 = r0->field_1f
    //     0xf3ec44: ldur            w3, [x0, #0x1f]
    // 0xf3ec48: DecompressPointer r3
    //     0xf3ec48: add             x3, x3, HEAP, lsl #32
    // 0xf3ec4c: mov             x2, x0
    // 0xf3ec50: stur            x3, [fp, #-0x10]
    // 0xf3ec54: r1 = Function '_updateTransitionForEntry@149347078':.
    //     0xf3ec54: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccd00] AnonymousClosure: (0xf3f23c), in [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_updateTransitionForEntry (0xf3f174)
    //     0xf3ec58: ldr             x1, [x1, #0xd00]
    // 0xf3ec5c: r0 = AllocateClosure()
    //     0xf3ec5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3ec60: ldur            x1, [fp, #-0x10]
    // 0xf3ec64: mov             x2, x0
    // 0xf3ec68: r0 = forEach()
    //     0xf3ec68: bl              #0xb9bccc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::forEach
    // 0xf3ec6c: ldur            x0, [fp, #-8]
    // 0xf3ec70: LoadField: r2 = r0->field_1b
    //     0xf3ec70: ldur            w2, [x0, #0x1b]
    // 0xf3ec74: DecompressPointer r2
    //     0xf3ec74: add             x2, x2, HEAP, lsl #32
    // 0xf3ec78: cmp             w2, NULL
    // 0xf3ec7c: b.eq            #0xf3ec88
    // 0xf3ec80: mov             x1, x0
    // 0xf3ec84: r0 = _updateTransitionForEntry()
    //     0xf3ec84: bl              #0xf3f174  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_updateTransitionForEntry
    // 0xf3ec88: ldur            x1, [fp, #-8]
    // 0xf3ec8c: r0 = didChangeDependencies()
    //     0xf3ec8c: bl              #0xf15614  ; [package:flutter_widget_from_html_core/src/core_html_widget.dart] HtmlWidgetState::didChangeDependencies
    // 0xf3ec90: ldur            x0, [fp, #-8]
    // 0xf3ec94: LoadField: r1 = r0->field_b
    //     0xf3ec94: ldur            w1, [x0, #0xb]
    // 0xf3ec98: DecompressPointer r1
    //     0xf3ec98: add             x1, x1, HEAP, lsl #32
    // 0xf3ec9c: cmp             w1, NULL
    // 0xf3eca0: b.eq            #0xf3ed74
    // 0xf3eca4: LoadField: r2 = r0->field_1b
    //     0xf3eca4: ldur            w2, [x0, #0x1b]
    // 0xf3eca8: DecompressPointer r2
    //     0xf3eca8: add             x2, x2, HEAP, lsl #32
    // 0xf3ecac: cmp             w2, NULL
    // 0xf3ecb0: b.ne            #0xf3ecbc
    // 0xf3ecb4: mov             x3, x0
    // 0xf3ecb8: b               #0xf3ece0
    // 0xf3ecbc: LoadField: r3 = r1->field_b
    //     0xf3ecbc: ldur            w3, [x1, #0xb]
    // 0xf3ecc0: DecompressPointer r3
    //     0xf3ecc0: add             x3, x3, HEAP, lsl #32
    // 0xf3ecc4: LoadField: r1 = r2->field_13
    //     0xf3ecc4: ldur            w1, [x2, #0x13]
    // 0xf3ecc8: DecompressPointer r1
    //     0xf3ecc8: add             x1, x1, HEAP, lsl #32
    // 0xf3eccc: mov             x2, x1
    // 0xf3ecd0: mov             x1, x3
    // 0xf3ecd4: r0 = canUpdate()
    //     0xf3ecd4: bl              #0xb49ae0  ; [package:flutter/src/widgets/framework.dart] Widget::canUpdate
    // 0xf3ecd8: tbz             w0, #4, #0xf3ecfc
    // 0xf3ecdc: ldur            x3, [fp, #-8]
    // 0xf3ece0: LoadField: r0 = r3->field_27
    //     0xf3ece0: ldur            x0, [x3, #0x27]
    // 0xf3ece4: add             x1, x0, #1
    // 0xf3ece8: StoreField: r3->field_27 = r1
    //     0xf3ece8: stur            x1, [x3, #0x27]
    // 0xf3ecec: mov             x1, x3
    // 0xf3ecf0: r2 = true
    //     0xf3ecf0: add             x2, NULL, #0x20  ; true
    // 0xf3ecf4: r0 = _addEntryForNewChild()
    //     0xf3ecf4: bl              #0xf3ed7c  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_addEntryForNewChild
    // 0xf3ecf8: b               #0xf3ed58
    // 0xf3ecfc: ldur            x3, [fp, #-8]
    // 0xf3ed00: LoadField: r2 = r3->field_1b
    //     0xf3ed00: ldur            w2, [x3, #0x1b]
    // 0xf3ed04: DecompressPointer r2
    //     0xf3ed04: add             x2, x2, HEAP, lsl #32
    // 0xf3ed08: cmp             w2, NULL
    // 0xf3ed0c: b.eq            #0xf3ed58
    // 0xf3ed10: LoadField: r0 = r3->field_b
    //     0xf3ed10: ldur            w0, [x3, #0xb]
    // 0xf3ed14: DecompressPointer r0
    //     0xf3ed14: add             x0, x0, HEAP, lsl #32
    // 0xf3ed18: cmp             w0, NULL
    // 0xf3ed1c: b.eq            #0xf3ed78
    // 0xf3ed20: LoadField: r1 = r0->field_b
    //     0xf3ed20: ldur            w1, [x0, #0xb]
    // 0xf3ed24: DecompressPointer r1
    //     0xf3ed24: add             x1, x1, HEAP, lsl #32
    // 0xf3ed28: mov             x0, x1
    // 0xf3ed2c: StoreField: r2->field_13 = r0
    //     0xf3ed2c: stur            w0, [x2, #0x13]
    //     0xf3ed30: ldurb           w16, [x2, #-1]
    //     0xf3ed34: ldurb           w17, [x0, #-1]
    //     0xf3ed38: and             x16, x17, x16, lsr #2
    //     0xf3ed3c: tst             x16, HEAP, lsr #32
    //     0xf3ed40: b.eq            #0xf3ed48
    //     0xf3ed44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3ed48: mov             x1, x3
    // 0xf3ed4c: r0 = _updateTransitionForEntry()
    //     0xf3ed4c: bl              #0xf3f174  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_updateTransitionForEntry
    // 0xf3ed50: ldur            x1, [fp, #-8]
    // 0xf3ed54: r0 = didChangeDependencies()
    //     0xf3ed54: bl              #0xf15614  ; [package:flutter_widget_from_html_core/src/core_html_widget.dart] HtmlWidgetState::didChangeDependencies
    // 0xf3ed58: r0 = Null
    //     0xf3ed58: mov             x0, NULL
    // 0xf3ed5c: LeaveFrame
    //     0xf3ed5c: mov             SP, fp
    //     0xf3ed60: ldp             fp, lr, [SP], #0x10
    // 0xf3ed64: ret
    //     0xf3ed64: ret             
    // 0xf3ed68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ed68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ed6c: b               #0xf3eb94
    // 0xf3ed70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ed70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3ed74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ed74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3ed78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ed78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addEntryForNewChild(/* No info */) {
    // ** addr: 0xf3ed7c, size: 0x1ac
    // 0xf3ed7c: EnterFrame
    //     0xf3ed7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3ed80: mov             fp, SP
    // 0xf3ed84: AllocStack(0x30)
    //     0xf3ed84: sub             SP, SP, #0x30
    // 0xf3ed88: SetupParameters(_AnimatedSwitcherState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf3ed88: mov             x3, x1
    //     0xf3ed8c: mov             x0, x2
    //     0xf3ed90: stur            x1, [fp, #-8]
    //     0xf3ed94: stur            x2, [fp, #-0x10]
    // 0xf3ed98: CheckStackOverflow
    //     0xf3ed98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3ed9c: cmp             SP, x16
    //     0xf3eda0: b.ls            #0xf3ef10
    // 0xf3eda4: LoadField: r2 = r3->field_1b
    //     0xf3eda4: ldur            w2, [x3, #0x1b]
    // 0xf3eda8: DecompressPointer r2
    //     0xf3eda8: add             x2, x2, HEAP, lsl #32
    // 0xf3edac: cmp             w2, NULL
    // 0xf3edb0: b.eq            #0xf3edfc
    // 0xf3edb4: LoadField: r1 = r3->field_1f
    //     0xf3edb4: ldur            w1, [x3, #0x1f]
    // 0xf3edb8: DecompressPointer r1
    //     0xf3edb8: add             x1, x1, HEAP, lsl #32
    // 0xf3edbc: r0 = add()
    //     0xf3edbc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xf3edc0: ldur            x0, [fp, #-8]
    // 0xf3edc4: LoadField: r1 = r0->field_1b
    //     0xf3edc4: ldur            w1, [x0, #0x1b]
    // 0xf3edc8: DecompressPointer r1
    //     0xf3edc8: add             x1, x1, HEAP, lsl #32
    // 0xf3edcc: cmp             w1, NULL
    // 0xf3edd0: b.eq            #0xf3ef18
    // 0xf3edd4: LoadField: r2 = r1->field_7
    //     0xf3edd4: ldur            w2, [x1, #7]
    // 0xf3edd8: DecompressPointer r2
    //     0xf3edd8: add             x2, x2, HEAP, lsl #32
    // 0xf3eddc: mov             x1, x2
    // 0xf3ede0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3ede0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3ede4: r0 = reverse()
    //     0xf3ede4: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf3ede8: ldur            x1, [fp, #-8]
    // 0xf3edec: r0 = didChangeDependencies()
    //     0xf3edec: bl              #0xf15614  ; [package:flutter_widget_from_html_core/src/core_html_widget.dart] HtmlWidgetState::didChangeDependencies
    // 0xf3edf0: ldur            x2, [fp, #-8]
    // 0xf3edf4: StoreField: r2->field_1b = rNULL
    //     0xf3edf4: stur            NULL, [x2, #0x1b]
    // 0xf3edf8: b               #0xf3ee00
    // 0xf3edfc: mov             x2, x3
    // 0xf3ee00: ldur            x0, [fp, #-0x10]
    // 0xf3ee04: LoadField: r1 = r2->field_b
    //     0xf3ee04: ldur            w1, [x2, #0xb]
    // 0xf3ee08: DecompressPointer r1
    //     0xf3ee08: add             x1, x1, HEAP, lsl #32
    // 0xf3ee0c: cmp             w1, NULL
    // 0xf3ee10: b.eq            #0xf3ef1c
    // 0xf3ee14: LoadField: r3 = r1->field_f
    //     0xf3ee14: ldur            w3, [x1, #0xf]
    // 0xf3ee18: DecompressPointer r3
    //     0xf3ee18: add             x3, x3, HEAP, lsl #32
    // 0xf3ee1c: stur            x3, [fp, #-0x18]
    // 0xf3ee20: r1 = <double>
    //     0xf3ee20: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ee24: r0 = AnimationController()
    //     0xf3ee24: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf3ee28: stur            x0, [fp, #-0x20]
    // 0xf3ee2c: ldur            x16, [fp, #-0x18]
    // 0xf3ee30: stp             NULL, x16, [SP]
    // 0xf3ee34: mov             x1, x0
    // 0xf3ee38: ldur            x2, [fp, #-8]
    // 0xf3ee3c: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0xf3ee3c: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e860] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0xf3ee40: ldr             x4, [x4, #0x860]
    // 0xf3ee44: r0 = AnimationController()
    //     0xf3ee44: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf3ee48: ldur            x0, [fp, #-8]
    // 0xf3ee4c: LoadField: r1 = r0->field_b
    //     0xf3ee4c: ldur            w1, [x0, #0xb]
    // 0xf3ee50: DecompressPointer r1
    //     0xf3ee50: add             x1, x1, HEAP, lsl #32
    // 0xf3ee54: cmp             w1, NULL
    // 0xf3ee58: b.eq            #0xf3ef20
    // 0xf3ee5c: r1 = <double>
    //     0xf3ee5c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ee60: r0 = CurvedAnimation()
    //     0xf3ee60: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf3ee64: stur            x0, [fp, #-0x18]
    // 0xf3ee68: r16 = Instance__Linear
    //     0xf3ee68: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf3ee6c: str             x16, [SP]
    // 0xf3ee70: mov             x1, x0
    // 0xf3ee74: ldur            x3, [fp, #-0x20]
    // 0xf3ee78: r2 = Instance__Linear
    //     0xf3ee78: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf3ee7c: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf3ee7c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf3ee80: ldr             x4, [x4, #0xdc0]
    // 0xf3ee84: r0 = CurvedAnimation()
    //     0xf3ee84: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf3ee88: ldur            x0, [fp, #-8]
    // 0xf3ee8c: LoadField: r1 = r0->field_b
    //     0xf3ee8c: ldur            w1, [x0, #0xb]
    // 0xf3ee90: DecompressPointer r1
    //     0xf3ee90: add             x1, x1, HEAP, lsl #32
    // 0xf3ee94: cmp             w1, NULL
    // 0xf3ee98: b.eq            #0xf3ef24
    // 0xf3ee9c: LoadField: r5 = r1->field_b
    //     0xf3ee9c: ldur            w5, [x1, #0xb]
    // 0xf3eea0: DecompressPointer r5
    //     0xf3eea0: add             x5, x5, HEAP, lsl #32
    // 0xf3eea4: LoadField: r3 = r1->field_1f
    //     0xf3eea4: ldur            w3, [x1, #0x1f]
    // 0xf3eea8: DecompressPointer r3
    //     0xf3eea8: add             x3, x3, HEAP, lsl #32
    // 0xf3eeac: mov             x1, x0
    // 0xf3eeb0: ldur            x2, [fp, #-0x18]
    // 0xf3eeb4: ldur            x6, [fp, #-0x20]
    // 0xf3eeb8: r0 = _newEntry()
    //     0xf3eeb8: bl              #0xf3ef28  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_newEntry
    // 0xf3eebc: ldur            x1, [fp, #-8]
    // 0xf3eec0: StoreField: r1->field_1b = r0
    //     0xf3eec0: stur            w0, [x1, #0x1b]
    //     0xf3eec4: ldurb           w16, [x1, #-1]
    //     0xf3eec8: ldurb           w17, [x0, #-1]
    //     0xf3eecc: and             x16, x17, x16, lsr #2
    //     0xf3eed0: tst             x16, HEAP, lsr #32
    //     0xf3eed4: b.eq            #0xf3eedc
    //     0xf3eed8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3eedc: ldur            x0, [fp, #-0x10]
    // 0xf3eee0: tbnz            w0, #4, #0xf3eef4
    // 0xf3eee4: ldur            x1, [fp, #-0x20]
    // 0xf3eee8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3eee8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3eeec: r0 = forward()
    //     0xf3eeec: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf3eef0: b               #0xf3ef00
    // 0xf3eef4: ldur            x1, [fp, #-0x20]
    // 0xf3eef8: r2 = 1.000000
    //     0xf3eef8: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3eefc: r0 = value=()
    //     0xf3eefc: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf3ef00: r0 = Null
    //     0xf3ef00: mov             x0, NULL
    // 0xf3ef04: LeaveFrame
    //     0xf3ef04: mov             SP, fp
    //     0xf3ef08: ldp             fp, lr, [SP], #0x10
    // 0xf3ef0c: ret
    //     0xf3ef0c: ret             
    // 0xf3ef10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ef10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ef14: b               #0xf3eda4
    // 0xf3ef18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ef18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3ef1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ef1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3ef20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ef20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3ef24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3ef24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _newEntry(/* No info */) {
    // ** addr: 0xf3ef28, size: 0x13c
    // 0xf3ef28: EnterFrame
    //     0xf3ef28: stp             fp, lr, [SP, #-0x10]!
    //     0xf3ef2c: mov             fp, SP
    // 0xf3ef30: AllocStack(0x38)
    //     0xf3ef30: sub             SP, SP, #0x38
    // 0xf3ef34: SetupParameters(_AnimatedSwitcherState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xf3ef34: mov             x0, x2
    //     0xf3ef38: stur            x2, [fp, #-0x10]
    //     0xf3ef3c: mov             x2, x5
    //     0xf3ef40: stur            x1, [fp, #-8]
    //     0xf3ef44: stur            x3, [fp, #-0x18]
    //     0xf3ef48: stur            x5, [fp, #-0x20]
    //     0xf3ef4c: stur            x6, [fp, #-0x28]
    // 0xf3ef50: CheckStackOverflow
    //     0xf3ef50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3ef54: cmp             SP, x16
    //     0xf3ef58: b.ls            #0xf3f05c
    // 0xf3ef5c: r1 = 4
    //     0xf3ef5c: mov             x1, #4
    // 0xf3ef60: r0 = AllocateContext()
    //     0xf3ef60: bl              #0x13de838  ; AllocateContextStub
    // 0xf3ef64: mov             x4, x0
    // 0xf3ef68: ldur            x0, [fp, #-8]
    // 0xf3ef6c: stur            x4, [fp, #-0x30]
    // 0xf3ef70: StoreField: r4->field_f = r0
    //     0xf3ef70: stur            w0, [x4, #0xf]
    // 0xf3ef74: ldur            x3, [fp, #-0x10]
    // 0xf3ef78: StoreField: r4->field_13 = r3
    //     0xf3ef78: stur            w3, [x4, #0x13]
    // 0xf3ef7c: ldur            x1, [fp, #-0x28]
    // 0xf3ef80: ArrayStore: r4[0] = r1  ; List_4
    //     0xf3ef80: stur            w1, [x4, #0x17]
    // 0xf3ef84: ldur            x1, [fp, #-0x18]
    // 0xf3ef88: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf3ef88: ldur            w2, [x1, #0x17]
    // 0xf3ef8c: DecompressPointer r2
    //     0xf3ef8c: add             x2, x2, HEAP, lsl #32
    // 0xf3ef90: mov             x1, x2
    // 0xf3ef94: ldur            x2, [fp, #-0x20]
    // 0xf3ef98: r0 = _buildTransition()
    //     0xf3ef98: bl              #0xd2df04  ; [package:flutter/src/material/input_decorator.dart] _InputDecoratorState::_buildTransition
    // 0xf3ef9c: mov             x1, x0
    // 0xf3efa0: ldur            x0, [fp, #-8]
    // 0xf3efa4: stur            x1, [fp, #-0x10]
    // 0xf3efa8: LoadField: r3 = r0->field_27
    //     0xf3efa8: ldur            x3, [x0, #0x27]
    // 0xf3efac: stur            x3, [fp, #-0x38]
    // 0xf3efb0: r0 = KeyedSubtree()
    //     0xf3efb0: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xf3efb4: mov             x1, x0
    // 0xf3efb8: ldur            x2, [fp, #-0x10]
    // 0xf3efbc: ldur            x3, [fp, #-0x38]
    // 0xf3efc0: stur            x0, [fp, #-8]
    // 0xf3efc4: r0 = KeyedSubtree.wrap()
    //     0xf3efc4: bl              #0xef7ac8  ; [package:flutter/src/widgets/basic.dart] KeyedSubtree::KeyedSubtree.wrap
    // 0xf3efc8: ldur            x2, [fp, #-0x30]
    // 0xf3efcc: LoadField: r1 = r2->field_13
    //     0xf3efcc: ldur            w1, [x2, #0x13]
    // 0xf3efd0: DecompressPointer r1
    //     0xf3efd0: add             x1, x1, HEAP, lsl #32
    // 0xf3efd4: stur            x1, [fp, #-0x18]
    // 0xf3efd8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xf3efd8: ldur            w0, [x2, #0x17]
    // 0xf3efdc: DecompressPointer r0
    //     0xf3efdc: add             x0, x0, HEAP, lsl #32
    // 0xf3efe0: stur            x0, [fp, #-0x10]
    // 0xf3efe4: r0 = _ChildEntry()
    //     0xf3efe4: bl              #0xf3f064  ; Allocate_ChildEntryStub -> _ChildEntry (size=0x18)
    // 0xf3efe8: mov             x3, x0
    // 0xf3efec: ldur            x0, [fp, #-0x10]
    // 0xf3eff0: stur            x3, [fp, #-0x28]
    // 0xf3eff4: StoreField: r3->field_7 = r0
    //     0xf3eff4: stur            w0, [x3, #7]
    // 0xf3eff8: ldur            x4, [fp, #-0x18]
    // 0xf3effc: StoreField: r3->field_b = r4
    //     0xf3effc: stur            w4, [x3, #0xb]
    // 0xf3f000: ldur            x0, [fp, #-8]
    // 0xf3f004: StoreField: r3->field_f = r0
    //     0xf3f004: stur            w0, [x3, #0xf]
    // 0xf3f008: ldur            x0, [fp, #-0x20]
    // 0xf3f00c: StoreField: r3->field_13 = r0
    //     0xf3f00c: stur            w0, [x3, #0x13]
    // 0xf3f010: mov             x0, x3
    // 0xf3f014: ldur            x2, [fp, #-0x30]
    // 0xf3f018: StoreField: r2->field_1b = r0
    //     0xf3f018: stur            w0, [x2, #0x1b]
    //     0xf3f01c: ldurb           w16, [x2, #-1]
    //     0xf3f020: ldurb           w17, [x0, #-1]
    //     0xf3f024: and             x16, x17, x16, lsr #2
    //     0xf3f028: tst             x16, HEAP, lsr #32
    //     0xf3f02c: b.eq            #0xf3f034
    //     0xf3f030: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3f034: r1 = Function '<anonymous closure>':.
    //     0xf3f034: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccd08] AnonymousClosure: (0xf3f070), in [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_newEntry (0xf3ef28)
    //     0xf3f038: ldr             x1, [x1, #0xd08]
    // 0xf3f03c: r0 = AllocateClosure()
    //     0xf3f03c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3f040: ldur            x1, [fp, #-0x18]
    // 0xf3f044: mov             x2, x0
    // 0xf3f048: r0 = addStatusListener()
    //     0xf3f048: bl              #0x1254be8  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::addStatusListener
    // 0xf3f04c: ldur            x0, [fp, #-0x28]
    // 0xf3f050: LeaveFrame
    //     0xf3f050: mov             SP, fp
    //     0xf3f054: ldp             fp, lr, [SP], #0x10
    // 0xf3f058: ret
    //     0xf3f058: ret             
    // 0xf3f05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f05c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f060: b               #0xf3ef5c
  }
  [closure] void <anonymous closure>(dynamic, AnimationStatus) {
    // ** addr: 0xf3f070, size: 0x98
    // 0xf3f070: EnterFrame
    //     0xf3f070: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f074: mov             fp, SP
    // 0xf3f078: AllocStack(0x10)
    //     0xf3f078: sub             SP, SP, #0x10
    // 0xf3f07c: SetupParameters([dynamic _ /* r0 */])
    //     0xf3f07c: ldr             x0, [fp, #0x18]
    //     0xf3f080: ldur            w3, [x0, #0x17]
    //     0xf3f084: add             x3, x3, HEAP, lsl #32
    //     0xf3f088: stur            x3, [fp, #-0x10]
    // 0xf3f08c: CheckStackOverflow
    //     0xf3f08c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f090: cmp             SP, x16
    //     0xf3f094: b.ls            #0xf3f100
    // 0xf3f098: ldr             x0, [fp, #0x10]
    // 0xf3f09c: r16 = Instance_AnimationStatus
    //     0xf3f09c: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf3f0a0: cmp             w0, w16
    // 0xf3f0a4: b.ne            #0xf3f0f0
    // 0xf3f0a8: LoadField: r0 = r3->field_f
    //     0xf3f0a8: ldur            w0, [x3, #0xf]
    // 0xf3f0ac: DecompressPointer r0
    //     0xf3f0ac: add             x0, x0, HEAP, lsl #32
    // 0xf3f0b0: mov             x2, x3
    // 0xf3f0b4: stur            x0, [fp, #-8]
    // 0xf3f0b8: r1 = Function '<anonymous closure>':.
    //     0xf3f0b8: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccd10] AnonymousClosure: (0xf3f108), in [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_newEntry (0xf3ef28)
    //     0xf3f0bc: ldr             x1, [x1, #0xd10]
    // 0xf3f0c0: r0 = AllocateClosure()
    //     0xf3f0c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3f0c4: ldur            x1, [fp, #-8]
    // 0xf3f0c8: mov             x2, x0
    // 0xf3f0cc: r0 = setState()
    //     0xf3f0cc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf3f0d0: ldur            x0, [fp, #-0x10]
    // 0xf3f0d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3f0d4: ldur            w1, [x0, #0x17]
    // 0xf3f0d8: DecompressPointer r1
    //     0xf3f0d8: add             x1, x1, HEAP, lsl #32
    // 0xf3f0dc: r0 = dispose()
    //     0xf3f0dc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xf3f0e0: ldur            x0, [fp, #-0x10]
    // 0xf3f0e4: LoadField: r1 = r0->field_13
    //     0xf3f0e4: ldur            w1, [x0, #0x13]
    // 0xf3f0e8: DecompressPointer r1
    //     0xf3f0e8: add             x1, x1, HEAP, lsl #32
    // 0xf3f0ec: r0 = dispose()
    //     0xf3f0ec: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf3f0f0: r0 = Null
    //     0xf3f0f0: mov             x0, NULL
    // 0xf3f0f4: LeaveFrame
    //     0xf3f0f4: mov             SP, fp
    //     0xf3f0f8: ldp             fp, lr, [SP], #0x10
    // 0xf3f0fc: ret
    //     0xf3f0fc: ret             
    // 0xf3f100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f104: b               #0xf3f098
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf3f108, size: 0x6c
    // 0xf3f108: EnterFrame
    //     0xf3f108: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f10c: mov             fp, SP
    // 0xf3f110: AllocStack(0x8)
    //     0xf3f110: sub             SP, SP, #8
    // 0xf3f114: SetupParameters([dynamic _ /* r0 */])
    //     0xf3f114: ldr             x0, [fp, #0x10]
    //     0xf3f118: ldur            w3, [x0, #0x17]
    //     0xf3f11c: add             x3, x3, HEAP, lsl #32
    //     0xf3f120: stur            x3, [fp, #-8]
    // 0xf3f124: CheckStackOverflow
    //     0xf3f124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f128: cmp             SP, x16
    //     0xf3f12c: b.ls            #0xf3f16c
    // 0xf3f130: LoadField: r0 = r3->field_f
    //     0xf3f130: ldur            w0, [x3, #0xf]
    // 0xf3f134: DecompressPointer r0
    //     0xf3f134: add             x0, x0, HEAP, lsl #32
    // 0xf3f138: LoadField: r1 = r0->field_1f
    //     0xf3f138: ldur            w1, [x0, #0x1f]
    // 0xf3f13c: DecompressPointer r1
    //     0xf3f13c: add             x1, x1, HEAP, lsl #32
    // 0xf3f140: LoadField: r2 = r3->field_1b
    //     0xf3f140: ldur            w2, [x3, #0x1b]
    // 0xf3f144: DecompressPointer r2
    //     0xf3f144: add             x2, x2, HEAP, lsl #32
    // 0xf3f148: r0 = remove()
    //     0xf3f148: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xf3f14c: ldur            x0, [fp, #-8]
    // 0xf3f150: LoadField: r1 = r0->field_f
    //     0xf3f150: ldur            w1, [x0, #0xf]
    // 0xf3f154: DecompressPointer r1
    //     0xf3f154: add             x1, x1, HEAP, lsl #32
    // 0xf3f158: r0 = didChangeDependencies()
    //     0xf3f158: bl              #0xf15614  ; [package:flutter_widget_from_html_core/src/core_html_widget.dart] HtmlWidgetState::didChangeDependencies
    // 0xf3f15c: r0 = Null
    //     0xf3f15c: mov             x0, NULL
    // 0xf3f160: LeaveFrame
    //     0xf3f160: mov             SP, fp
    //     0xf3f164: ldp             fp, lr, [SP], #0x10
    // 0xf3f168: ret
    //     0xf3f168: ret             
    // 0xf3f16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f170: b               #0xf3f130
  }
  _ _updateTransitionForEntry(/* No info */) {
    // ** addr: 0xf3f174, size: 0xc8
    // 0xf3f174: EnterFrame
    //     0xf3f174: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f178: mov             fp, SP
    // 0xf3f17c: AllocStack(0x18)
    //     0xf3f17c: sub             SP, SP, #0x18
    // 0xf3f180: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf3f180: mov             x0, x2
    //     0xf3f184: stur            x2, [fp, #-0x10]
    // 0xf3f188: CheckStackOverflow
    //     0xf3f188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f18c: cmp             SP, x16
    //     0xf3f190: b.ls            #0xf3f230
    // 0xf3f194: LoadField: r2 = r0->field_f
    //     0xf3f194: ldur            w2, [x0, #0xf]
    // 0xf3f198: DecompressPointer r2
    //     0xf3f198: add             x2, x2, HEAP, lsl #32
    // 0xf3f19c: LoadField: r4 = r2->field_7
    //     0xf3f19c: ldur            w4, [x2, #7]
    // 0xf3f1a0: DecompressPointer r4
    //     0xf3f1a0: add             x4, x4, HEAP, lsl #32
    // 0xf3f1a4: stur            x4, [fp, #-8]
    // 0xf3f1a8: LoadField: r2 = r1->field_b
    //     0xf3f1a8: ldur            w2, [x1, #0xb]
    // 0xf3f1ac: DecompressPointer r2
    //     0xf3f1ac: add             x2, x2, HEAP, lsl #32
    // 0xf3f1b0: cmp             w2, NULL
    // 0xf3f1b4: b.eq            #0xf3f238
    // 0xf3f1b8: LoadField: r1 = r0->field_13
    //     0xf3f1b8: ldur            w1, [x0, #0x13]
    // 0xf3f1bc: DecompressPointer r1
    //     0xf3f1bc: add             x1, x1, HEAP, lsl #32
    // 0xf3f1c0: LoadField: r3 = r0->field_b
    //     0xf3f1c0: ldur            w3, [x0, #0xb]
    // 0xf3f1c4: DecompressPointer r3
    //     0xf3f1c4: add             x3, x3, HEAP, lsl #32
    // 0xf3f1c8: LoadField: r5 = r2->field_1f
    //     0xf3f1c8: ldur            w5, [x2, #0x1f]
    // 0xf3f1cc: DecompressPointer r5
    //     0xf3f1cc: add             x5, x5, HEAP, lsl #32
    // 0xf3f1d0: ArrayLoad: r2 = r5[0]  ; List_4
    //     0xf3f1d0: ldur            w2, [x5, #0x17]
    // 0xf3f1d4: DecompressPointer r2
    //     0xf3f1d4: add             x2, x2, HEAP, lsl #32
    // 0xf3f1d8: mov             x16, x1
    // 0xf3f1dc: mov             x1, x2
    // 0xf3f1e0: mov             x2, x16
    // 0xf3f1e4: r0 = _buildTransition()
    //     0xf3f1e4: bl              #0xd2df04  ; [package:flutter/src/material/input_decorator.dart] _InputDecoratorState::_buildTransition
    // 0xf3f1e8: stur            x0, [fp, #-0x18]
    // 0xf3f1ec: r0 = KeyedSubtree()
    //     0xf3f1ec: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xf3f1f0: ldur            x1, [fp, #-0x18]
    // 0xf3f1f4: StoreField: r0->field_b = r1
    //     0xf3f1f4: stur            w1, [x0, #0xb]
    // 0xf3f1f8: ldur            x1, [fp, #-8]
    // 0xf3f1fc: StoreField: r0->field_7 = r1
    //     0xf3f1fc: stur            w1, [x0, #7]
    // 0xf3f200: ldur            x1, [fp, #-0x10]
    // 0xf3f204: StoreField: r1->field_f = r0
    //     0xf3f204: stur            w0, [x1, #0xf]
    //     0xf3f208: ldurb           w16, [x1, #-1]
    //     0xf3f20c: ldurb           w17, [x0, #-1]
    //     0xf3f210: and             x16, x17, x16, lsr #2
    //     0xf3f214: tst             x16, HEAP, lsr #32
    //     0xf3f218: b.eq            #0xf3f220
    //     0xf3f21c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3f220: r0 = Null
    //     0xf3f220: mov             x0, NULL
    // 0xf3f224: LeaveFrame
    //     0xf3f224: mov             SP, fp
    //     0xf3f228: ldp             fp, lr, [SP], #0x10
    // 0xf3f22c: ret
    //     0xf3f22c: ret             
    // 0xf3f230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f230: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f234: b               #0xf3f194
    // 0xf3f238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3f238: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTransitionForEntry(dynamic, _ChildEntry) {
    // ** addr: 0xf3f23c, size: 0x3c
    // 0xf3f23c: EnterFrame
    //     0xf3f23c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3f240: mov             fp, SP
    // 0xf3f244: ldr             x0, [fp, #0x18]
    // 0xf3f248: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3f248: ldur            w1, [x0, #0x17]
    // 0xf3f24c: DecompressPointer r1
    //     0xf3f24c: add             x1, x1, HEAP, lsl #32
    // 0xf3f250: CheckStackOverflow
    //     0xf3f250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3f254: cmp             SP, x16
    //     0xf3f258: b.ls            #0xf3f270
    // 0xf3f25c: ldr             x2, [fp, #0x10]
    // 0xf3f260: r0 = _updateTransitionForEntry()
    //     0xf3f260: bl              #0xf3f174  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_updateTransitionForEntry
    // 0xf3f264: LeaveFrame
    //     0xf3f264: mov             SP, fp
    //     0xf3f268: ldp             fp, lr, [SP], #0x10
    // 0xf3f26c: ret
    //     0xf3f26c: ret             
    // 0xf3f270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3f270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3f274: b               #0xf3f25c
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8293c, size: 0x34
    // 0xf8293c: EnterFrame
    //     0xf8293c: stp             fp, lr, [SP, #-0x10]!
    //     0xf82940: mov             fp, SP
    // 0xf82944: CheckStackOverflow
    //     0xf82944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82948: cmp             SP, x16
    //     0xf8294c: b.ls            #0xf82968
    // 0xf82950: r2 = false
    //     0xf82950: add             x2, NULL, #0x30  ; false
    // 0xf82954: r0 = _addEntryForNewChild()
    //     0xf82954: bl              #0xf3ed7c  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_addEntryForNewChild
    // 0xf82958: r0 = Null
    //     0xf82958: mov             x0, NULL
    // 0xf8295c: LeaveFrame
    //     0xf8295c: mov             SP, fp
    //     0xf82960: ldp             fp, lr, [SP], #0x10
    // 0xf82964: ret
    //     0xf82964: ret             
    // 0xf82968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8296c: b               #0xf82950
  }
  _ _AnimatedSwitcherState(/* No info */) {
    // ** addr: 0xfa37ac, size: 0x7c
    // 0xfa37ac: EnterFrame
    //     0xfa37ac: stp             fp, lr, [SP, #-0x10]!
    //     0xfa37b0: mov             fp, SP
    // 0xfa37b4: AllocStack(0x8)
    //     0xfa37b4: sub             SP, SP, #8
    // 0xfa37b8: r0 = const []
    //     0xfa37b8: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1458] List<Widget>(0)
    //     0xfa37bc: ldr             x0, [x0, #0x458]
    // 0xfa37c0: mov             x2, x1
    // 0xfa37c4: stur            x1, [fp, #-8]
    // 0xfa37c8: StoreField: r2->field_23 = r0
    //     0xfa37c8: stur            w0, [x2, #0x23]
    // 0xfa37cc: StoreField: r2->field_27 = rZR
    //     0xfa37cc: stur            xzr, [x2, #0x27]
    // 0xfa37d0: r1 = <_ChildEntry>
    //     0xfa37d0: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6b8] TypeArguments: <_ChildEntry>
    //     0xfa37d4: ldr             x1, [x1, #0x6b8]
    // 0xfa37d8: r0 = _Set()
    //     0xfa37d8: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfa37dc: r1 = _Uint32List
    //     0xfa37dc: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfa37e0: StoreField: r0->field_1b = r1
    //     0xfa37e0: stur            w1, [x0, #0x1b]
    // 0xfa37e4: StoreField: r0->field_b = rZR
    //     0xfa37e4: stur            wzr, [x0, #0xb]
    // 0xfa37e8: r1 = const []
    //     0xfa37e8: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfa37ec: StoreField: r0->field_f = r1
    //     0xfa37ec: stur            w1, [x0, #0xf]
    // 0xfa37f0: StoreField: r0->field_13 = rZR
    //     0xfa37f0: stur            wzr, [x0, #0x13]
    // 0xfa37f4: ArrayStore: r0[0] = rZR  ; List_4
    //     0xfa37f4: stur            wzr, [x0, #0x17]
    // 0xfa37f8: ldur            x1, [fp, #-8]
    // 0xfa37fc: StoreField: r1->field_1f = r0
    //     0xfa37fc: stur            w0, [x1, #0x1f]
    //     0xfa3800: ldurb           w16, [x1, #-1]
    //     0xfa3804: ldurb           w17, [x0, #-1]
    //     0xfa3808: and             x16, x17, x16, lsr #2
    //     0xfa380c: tst             x16, HEAP, lsr #32
    //     0xfa3810: b.eq            #0xfa3818
    //     0xfa3814: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3818: r0 = Null
    //     0xfa3818: mov             x0, NULL
    // 0xfa381c: LeaveFrame
    //     0xfa381c: mov             SP, fp
    //     0xfa3820: ldp             fp, lr, [SP], #0x10
    // 0xfa3824: ret
    //     0xfa3824: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dec90, size: 0x170
    // 0x10dec90: EnterFrame
    //     0x10dec90: stp             fp, lr, [SP, #-0x10]!
    //     0x10dec94: mov             fp, SP
    // 0x10dec98: AllocStack(0x20)
    //     0x10dec98: sub             SP, SP, #0x20
    // 0x10dec9c: SetupParameters(_AnimatedSwitcherState this /* r1 => r0, fp-0x8 */)
    //     0x10dec9c: mov             x0, x1
    //     0x10deca0: stur            x1, [fp, #-8]
    // 0x10deca4: CheckStackOverflow
    //     0x10deca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10deca8: cmp             SP, x16
    //     0x10decac: b.ls            #0x10dedf0
    // 0x10decb0: LoadField: r1 = r0->field_1b
    //     0x10decb0: ldur            w1, [x0, #0x1b]
    // 0x10decb4: DecompressPointer r1
    //     0x10decb4: add             x1, x1, HEAP, lsl #32
    // 0x10decb8: cmp             w1, NULL
    // 0x10decbc: b.eq            #0x10decd4
    // 0x10decc0: LoadField: r2 = r1->field_7
    //     0x10decc0: ldur            w2, [x1, #7]
    // 0x10decc4: DecompressPointer r2
    //     0x10decc4: add             x2, x2, HEAP, lsl #32
    // 0x10decc8: mov             x1, x2
    // 0x10deccc: r0 = dispose()
    //     0x10deccc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10decd0: ldur            x0, [fp, #-8]
    // 0x10decd4: LoadField: r1 = r0->field_1b
    //     0x10decd4: ldur            w1, [x0, #0x1b]
    // 0x10decd8: DecompressPointer r1
    //     0x10decd8: add             x1, x1, HEAP, lsl #32
    // 0x10decdc: cmp             w1, NULL
    // 0x10dece0: b.eq            #0x10decf8
    // 0x10dece4: LoadField: r2 = r1->field_b
    //     0x10dece4: ldur            w2, [x1, #0xb]
    // 0x10dece8: DecompressPointer r2
    //     0x10dece8: add             x2, x2, HEAP, lsl #32
    // 0x10decec: mov             x1, x2
    // 0x10decf0: r0 = dispose()
    //     0x10decf0: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10decf4: ldur            x0, [fp, #-8]
    // 0x10decf8: LoadField: r1 = r0->field_1f
    //     0x10decf8: ldur            w1, [x0, #0x1f]
    // 0x10decfc: DecompressPointer r1
    //     0x10decfc: add             x1, x1, HEAP, lsl #32
    // 0x10ded00: r0 = iterator()
    //     0x10ded00: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x10ded04: stur            x0, [fp, #-0x18]
    // 0x10ded08: LoadField: r2 = r0->field_7
    //     0x10ded08: ldur            w2, [x0, #7]
    // 0x10ded0c: DecompressPointer r2
    //     0x10ded0c: add             x2, x2, HEAP, lsl #32
    // 0x10ded10: stur            x2, [fp, #-0x10]
    // 0x10ded14: CheckStackOverflow
    //     0x10ded14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ded18: cmp             SP, x16
    //     0x10ded1c: b.ls            #0x10dedf8
    // 0x10ded20: mov             x1, x0
    // 0x10ded24: r0 = moveNext()
    //     0x10ded24: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x10ded28: tbnz            w0, #4, #0x10dedd8
    // 0x10ded2c: ldur            x3, [fp, #-0x18]
    // 0x10ded30: LoadField: r4 = r3->field_33
    //     0x10ded30: ldur            w4, [x3, #0x33]
    // 0x10ded34: DecompressPointer r4
    //     0x10ded34: add             x4, x4, HEAP, lsl #32
    // 0x10ded38: stur            x4, [fp, #-0x20]
    // 0x10ded3c: cmp             w4, NULL
    // 0x10ded40: b.ne            #0x10ded74
    // 0x10ded44: mov             x0, x4
    // 0x10ded48: ldur            x2, [fp, #-0x10]
    // 0x10ded4c: r1 = Null
    //     0x10ded4c: mov             x1, NULL
    // 0x10ded50: cmp             w2, NULL
    // 0x10ded54: b.eq            #0x10ded74
    // 0x10ded58: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10ded58: ldur            w4, [x2, #0x17]
    // 0x10ded5c: DecompressPointer r4
    //     0x10ded5c: add             x4, x4, HEAP, lsl #32
    // 0x10ded60: r8 = X0
    //     0x10ded60: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10ded64: LoadField: r9 = r4->field_7
    //     0x10ded64: ldur            x9, [x4, #7]
    // 0x10ded68: r3 = Null
    //     0x10ded68: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcccc8] Null
    //     0x10ded6c: ldr             x3, [x3, #0xcc8]
    // 0x10ded70: blr             x9
    // 0x10ded74: ldur            x0, [fp, #-0x20]
    // 0x10ded78: LoadField: r1 = r0->field_7
    //     0x10ded78: ldur            w1, [x0, #7]
    // 0x10ded7c: DecompressPointer r1
    //     0x10ded7c: add             x1, x1, HEAP, lsl #32
    // 0x10ded80: r0 = dispose()
    //     0x10ded80: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ded84: ldur            x0, [fp, #-0x20]
    // 0x10ded88: LoadField: r2 = r0->field_b
    //     0x10ded88: ldur            w2, [x0, #0xb]
    // 0x10ded8c: DecompressPointer r2
    //     0x10ded8c: add             x2, x2, HEAP, lsl #32
    // 0x10ded90: LoadField: r0 = r2->field_b
    //     0x10ded90: ldur            w0, [x2, #0xb]
    // 0x10ded94: DecompressPointer r0
    //     0x10ded94: add             x0, x0, HEAP, lsl #32
    // 0x10ded98: stur            x0, [fp, #-0x20]
    // 0x10ded9c: r1 = Function '_updateCurveDirection@63411118':.
    //     0x10ded9c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0x10deda0: ldr             x1, [x1, #0xde0]
    // 0x10deda4: r0 = AllocateClosure()
    //     0x10deda4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10deda8: ldur            x1, [fp, #-0x20]
    // 0x10dedac: r2 = LoadClassIdInstr(r1)
    //     0x10dedac: ldur            x2, [x1, #-1]
    //     0x10dedb0: ubfx            x2, x2, #0xc, #0x14
    // 0x10dedb4: mov             x16, x0
    // 0x10dedb8: mov             x0, x2
    // 0x10dedbc: mov             x2, x16
    // 0x10dedc0: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10dedc0: add             lr, x0, #0xabe
    //     0x10dedc4: ldr             lr, [x21, lr, lsl #3]
    //     0x10dedc8: blr             lr
    // 0x10dedcc: ldur            x0, [fp, #-0x18]
    // 0x10dedd0: ldur            x2, [fp, #-0x10]
    // 0x10dedd4: b               #0x10ded14
    // 0x10dedd8: ldur            x1, [fp, #-8]
    // 0x10deddc: r0 = dispose()
    //     0x10deddc: bl              #0x10dee00  ; [dart:mixin_deduplication] _MixinApplication189&State&TickerProviderStateMixin::dispose
    // 0x10dede0: r0 = Null
    //     0x10dede0: mov             x0, NULL
    // 0x10dede4: LeaveFrame
    //     0x10dede4: mov             SP, fp
    //     0x10dede8: ldp             fp, lr, [SP], #0x10
    // 0x10dedec: ret
    //     0x10dedec: ret             
    // 0x10dedf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dedf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dedf4: b               #0x10decb0
    // 0x10dedf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dedf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dedfc: b               #0x10ded20
  }
}

// class id: 6406, size: 0x28, field offset: 0xc
//   const constructor, 
class AnimatedSwitcher extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3764, size: 0x48
    // 0xfa3764: EnterFrame
    //     0xfa3764: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3768: mov             fp, SP
    // 0xfa376c: AllocStack(0x8)
    //     0xfa376c: sub             SP, SP, #8
    // 0xfa3770: CheckStackOverflow
    //     0xfa3770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa3774: cmp             SP, x16
    //     0xfa3778: b.ls            #0xfa37a4
    // 0xfa377c: r1 = <AnimatedSwitcher>
    //     0xfa377c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6b0] TypeArguments: <AnimatedSwitcher>
    //     0xfa3780: ldr             x1, [x1, #0x6b0]
    // 0xfa3784: r0 = _AnimatedSwitcherState()
    //     0xfa3784: bl              #0xfa3828  ; Allocate_AnimatedSwitcherStateStub -> _AnimatedSwitcherState (size=0x30)
    // 0xfa3788: mov             x1, x0
    // 0xfa378c: stur            x0, [fp, #-8]
    // 0xfa3790: r0 = _AnimatedSwitcherState()
    //     0xfa3790: bl              #0xfa37ac  ; [package:flutter/src/widgets/animated_switcher.dart] _AnimatedSwitcherState::_AnimatedSwitcherState
    // 0xfa3794: ldur            x0, [fp, #-8]
    // 0xfa3798: LeaveFrame
    //     0xfa3798: mov             SP, fp
    //     0xfa379c: ldp             fp, lr, [SP], #0x10
    // 0xfa37a0: ret
    //     0xfa37a0: ret             
    // 0xfa37a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa37a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa37a8: b               #0xfa377c
  }
}
