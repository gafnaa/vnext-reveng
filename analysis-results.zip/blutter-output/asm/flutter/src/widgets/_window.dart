// lib: , url: package:flutter/src/widgets/_window.dart

// class id: 1049108, size: 0x8
class :: {

  static _ createDefaultWindowingOwner(/* No info */) {
    // ** addr: 0x83a350, size: 0x74
    // 0x83a350: EnterFrame
    //     0x83a350: stp             fp, lr, [SP, #-0x10]!
    //     0x83a354: mov             fp, SP
    // 0x83a358: CheckStackOverflow
    //     0x83a358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83a35c: cmp             SP, x16
    //     0x83a360: b.ls            #0x83a3bc
    // 0x83a364: r0 = LoadStaticField(0x878)
    //     0x83a364: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83a368: ldr             x0, [x0, #0x10f0]
    // 0x83a36c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83a370: cmp             w0, w16
    // 0x83a374: b.ne            #0x83a380
    // 0x83a378: r2 = isWindowingEnabled
    //     0x83a378: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0x83a37c: r0 = InitLateStaticField()
    //     0x83a37c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x83a380: tbz             w0, #4, #0x83a3a4
    // 0x83a384: r0 = _WindowingOwnerUnsupported()
    //     0x83a384: bl              #0x83a3c4  ; Allocate_WindowingOwnerUnsupportedStub -> _WindowingOwnerUnsupported (size=0xc)
    // 0x83a388: mov             x1, x0
    // 0x83a38c: r0 = "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    //     0x83a38c: ldr             x0, [PP, #0x1b80]  ; [pp+0x1b80] "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    // 0x83a390: StoreField: r1->field_7 = r0
    //     0x83a390: stur            w0, [x1, #7]
    // 0x83a394: mov             x0, x1
    // 0x83a398: LeaveFrame
    //     0x83a398: mov             SP, fp
    //     0x83a39c: ldp             fp, lr, [SP], #0x10
    // 0x83a3a0: ret
    //     0x83a3a0: ret             
    // 0x83a3a4: r0 = _WindowingOwnerUnsupported()
    //     0x83a3a4: bl              #0x83a3c4  ; Allocate_WindowingOwnerUnsupportedStub -> _WindowingOwnerUnsupported (size=0xc)
    // 0x83a3a8: r1 = "Windowing is unsupported on this platform."
    //     0x83a3a8: ldr             x1, [PP, #0x1b88]  ; [pp+0x1b88] "Windowing is unsupported on this platform."
    // 0x83a3ac: StoreField: r0->field_7 = r1
    //     0x83a3ac: stur            w1, [x0, #7]
    // 0x83a3b0: LeaveFrame
    //     0x83a3b0: mov             SP, fp
    //     0x83a3b4: ldp             fp, lr, [SP], #0x10
    // 0x83a3b8: ret
    //     0x83a3b8: ret             
    // 0x83a3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a3bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a3c0: b               #0x83a364
  }
}

// class id: 2718, size: 0xc, field offset: 0x8
class WindowEntry extends Object {
}

// class id: 2719, size: 0x8, field offset: 0x8
abstract class WindowingOwner extends Object {
}

// class id: 2720, size: 0xc, field offset: 0x8
class _WindowingOwnerUnsupported extends WindowingOwner {

  _ createDialogWindowController(/* No info */) {
    // ** addr: 0xd954b4, size: 0x34
    // 0xd954b4: EnterFrame
    //     0xd954b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd954b8: mov             fp, SP
    // 0xd954bc: AllocStack(0x8)
    //     0xd954bc: sub             SP, SP, #8
    // 0xd954c0: LoadField: r0 = r1->field_7
    //     0xd954c0: ldur            w0, [x1, #7]
    // 0xd954c4: DecompressPointer r0
    //     0xd954c4: add             x0, x0, HEAP, lsl #32
    // 0xd954c8: stur            x0, [fp, #-8]
    // 0xd954cc: r0 = UnsupportedError()
    //     0xd954cc: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xd954d0: mov             x1, x0
    // 0xd954d4: ldur            x0, [fp, #-8]
    // 0xd954d8: StoreField: r1->field_b = r0
    //     0xd954d8: stur            w0, [x1, #0xb]
    // 0xd954dc: mov             x0, x1
    // 0xd954e0: r0 = Throw()
    //     0xd954e0: bl              #0x13ddb2c  ; ThrowStub
    // 0xd954e4: brk             #0
  }
}

// class id: 2721, size: 0x8, field offset: 0x8
class DialogWindowControllerDelegate extends Object {
}

// class id: 4469, size: 0x28, field offset: 0x24
class WindowRegistry extends ChangeNotifier {

  static _ maybeOf(/* No info */) {
    // ** addr: 0xd956a8, size: 0x5c
    // 0xd956a8: EnterFrame
    //     0xd956a8: stp             fp, lr, [SP, #-0x10]!
    //     0xd956ac: mov             fp, SP
    // 0xd956b0: AllocStack(0x10)
    //     0xd956b0: sub             SP, SP, #0x10
    // 0xd956b4: CheckStackOverflow
    //     0xd956b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd956b8: cmp             SP, x16
    //     0xd956bc: b.ls            #0xd956fc
    // 0xd956c0: r16 = <_WindowRegistryScope>
    //     0xd956c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <_WindowRegistryScope>
    //     0xd956c4: ldr             x16, [x16, #0x268]
    // 0xd956c8: stp             x1, x16, [SP]
    // 0xd956cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd956cc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd956d0: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd956d0: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd956d4: cmp             w0, NULL
    // 0xd956d8: b.ne            #0xd956e4
    // 0xd956dc: r0 = Null
    //     0xd956dc: mov             x0, NULL
    // 0xd956e0: b               #0xd956f0
    // 0xd956e4: LoadField: r1 = r0->field_f
    //     0xd956e4: ldur            w1, [x0, #0xf]
    // 0xd956e8: DecompressPointer r1
    //     0xd956e8: add             x1, x1, HEAP, lsl #32
    // 0xd956ec: mov             x0, x1
    // 0xd956f0: LeaveFrame
    //     0xd956f0: mov             SP, fp
    //     0xd956f4: ldp             fp, lr, [SP], #0x10
    // 0xd956f8: ret
    //     0xd956f8: ret             
    // 0xd956fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd956fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95700: b               #0xd956c0
  }
  get _ windows(/* No info */) {
    // ** addr: 0xe01b6c, size: 0x60
    // 0xe01b6c: EnterFrame
    //     0xe01b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xe01b70: mov             fp, SP
    // 0xe01b74: AllocStack(0x10)
    //     0xe01b74: sub             SP, SP, #0x10
    // 0xe01b78: CheckStackOverflow
    //     0xe01b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01b7c: cmp             SP, x16
    //     0xe01b80: b.ls            #0xe01bc4
    // 0xe01b84: LoadField: r2 = r1->field_23
    //     0xe01b84: ldur            w2, [x1, #0x23]
    // 0xe01b88: DecompressPointer r2
    //     0xe01b88: add             x2, x2, HEAP, lsl #32
    // 0xe01b8c: r16 = false
    //     0xe01b8c: add             x16, NULL, #0x30  ; false
    // 0xe01b90: str             x16, [SP]
    // 0xe01b94: r1 = <WindowEntry>
    //     0xe01b94: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6a8] TypeArguments: <WindowEntry>
    //     0xe01b98: ldr             x1, [x1, #0x6a8]
    // 0xe01b9c: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0xe01b9c: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0xe01ba0: r0 = List.from()
    //     0xe01ba0: bl              #0x876494  ; [dart:core] List::List.from
    // 0xe01ba4: r16 = <WindowEntry>
    //     0xe01ba4: add             x16, PP, #0xad, lsl #12  ; [pp+0xad6a8] TypeArguments: <WindowEntry>
    //     0xe01ba8: ldr             x16, [x16, #0x6a8]
    // 0xe01bac: stp             x0, x16, [SP]
    // 0xe01bb0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe01bb0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe01bb4: r0 = makeFixedListUnmodifiable()
    //     0xe01bb4: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xe01bb8: LeaveFrame
    //     0xe01bb8: mov             SP, fp
    //     0xe01bbc: ldp             fp, lr, [SP], #0x10
    // 0xe01bc0: ret
    //     0xe01bc0: ret             
    // 0xe01bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01bc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01bc8: b               #0xe01b84
  }
  _ WindowRegistry(/* No info */) {
    // ** addr: 0xfa34b0, size: 0xec
    // 0xfa34b0: EnterFrame
    //     0xfa34b0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa34b4: mov             fp, SP
    // 0xfa34b8: AllocStack(0x8)
    //     0xfa34b8: sub             SP, SP, #8
    // 0xfa34bc: SetupParameters(WindowRegistry this /* r1 => r0, fp-0x8 */)
    //     0xfa34bc: mov             x0, x1
    //     0xfa34c0: stur            x1, [fp, #-8]
    // 0xfa34c4: CheckStackOverflow
    //     0xfa34c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa34c8: cmp             SP, x16
    //     0xfa34cc: b.ls            #0xfa3594
    // 0xfa34d0: r1 = <WindowEntry>
    //     0xfa34d0: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6a8] TypeArguments: <WindowEntry>
    //     0xfa34d4: ldr             x1, [x1, #0x6a8]
    // 0xfa34d8: r2 = 0
    //     0xfa34d8: mov             x2, #0
    // 0xfa34dc: r0 = _GrowableList()
    //     0xfa34dc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfa34e0: ldur            x1, [fp, #-8]
    // 0xfa34e4: StoreField: r1->field_23 = r0
    //     0xfa34e4: stur            w0, [x1, #0x23]
    //     0xfa34e8: ldurb           w16, [x1, #-1]
    //     0xfa34ec: ldurb           w17, [x0, #-1]
    //     0xfa34f0: and             x16, x17, x16, lsr #2
    //     0xfa34f4: tst             x16, HEAP, lsr #32
    //     0xfa34f8: b.eq            #0xfa3500
    //     0xfa34fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3500: StoreField: r1->field_7 = rZR
    //     0xfa3500: stur            xzr, [x1, #7]
    // 0xfa3504: StoreField: r1->field_13 = rZR
    //     0xfa3504: stur            xzr, [x1, #0x13]
    // 0xfa3508: StoreField: r1->field_1b = rZR
    //     0xfa3508: stur            xzr, [x1, #0x1b]
    // 0xfa350c: r0 = LoadStaticField(0x45c)
    //     0xfa350c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa3510: ldr             x0, [x0, #0x8b8]
    // 0xfa3514: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3518: cmp             w0, w16
    // 0xfa351c: b.ne            #0xfa3528
    // 0xfa3520: r2 = _emptyListeners
    //     0xfa3520: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa3524: r0 = InitLateFinalStaticField()
    //     0xfa3524: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa3528: ldur            x1, [fp, #-8]
    // 0xfa352c: StoreField: r1->field_f = r0
    //     0xfa352c: stur            w0, [x1, #0xf]
    //     0xfa3530: ldurb           w16, [x1, #-1]
    //     0xfa3534: ldurb           w17, [x0, #-1]
    //     0xfa3538: and             x16, x17, x16, lsr #2
    //     0xfa353c: tst             x16, HEAP, lsr #32
    //     0xfa3540: b.eq            #0xfa3548
    //     0xfa3544: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3548: r0 = LoadStaticField(0x878)
    //     0xfa3548: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa354c: ldr             x0, [x0, #0x10f0]
    // 0xfa3550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3554: cmp             w0, w16
    // 0xfa3558: b.ne            #0xfa3564
    // 0xfa355c: r2 = isWindowingEnabled
    //     0xfa355c: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0xfa3560: r0 = InitLateStaticField()
    //     0xfa3560: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xfa3564: tbnz            w0, #4, #0xfa3578
    // 0xfa3568: r0 = Null
    //     0xfa3568: mov             x0, NULL
    // 0xfa356c: LeaveFrame
    //     0xfa356c: mov             SP, fp
    //     0xfa3570: ldp             fp, lr, [SP], #0x10
    // 0xfa3574: ret
    //     0xfa3574: ret             
    // 0xfa3578: r0 = UnsupportedError()
    //     0xfa3578: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xfa357c: mov             x1, x0
    // 0xfa3580: r0 = "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    //     0xfa3580: ldr             x0, [PP, #0x1b80]  ; [pp+0x1b80] "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    // 0xfa3584: StoreField: r1->field_b = r0
    //     0xfa3584: stur            w0, [x1, #0xb]
    // 0xfa3588: mov             x0, x1
    // 0xfa358c: r0 = Throw()
    //     0xfa358c: bl              #0x13ddb2c  ; ThrowStub
    // 0xfa3590: brk             #0
    // 0xfa3594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa3594: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa3598: b               #0xfa34d0
  }
}

// class id: 4470, size: 0x24, field offset: 0x24
abstract class BaseWindowController extends ChangeNotifier {
}

// class id: 4474, size: 0x24, field offset: 0x24
abstract class DialogWindowController extends BaseWindowController {

  factory _ DialogWindowController(/* No info */) {
    // ** addr: 0xd95468, size: 0x4c
    // 0xd95468: EnterFrame
    //     0xd95468: stp             fp, lr, [SP, #-0x10]!
    //     0xd9546c: mov             fp, SP
    // 0xd95470: CheckStackOverflow
    //     0xd95470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95474: cmp             SP, x16
    //     0xd95478: b.ls            #0xd954a8
    // 0xd9547c: r0 = ensureInitialized()
    //     0xd9547c: bl              #0x8397cc  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0xd95480: r1 = LoadStaticField(0x6a0)
    //     0xd95480: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd95484: ldr             x1, [x1, #0xd40]
    // 0xd95488: cmp             w1, NULL
    // 0xd9548c: b.eq            #0xd954b0
    // 0xd95490: r0 = windowingOwner()
    //     0xd95490: bl              #0xd954e8  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::windowingOwner
    // 0xd95494: mov             x1, x0
    // 0xd95498: r0 = createDialogWindowController()
    //     0xd95498: bl              #0xd954b4  ; [package:flutter/src/widgets/_window.dart] _WindowingOwnerUnsupported::createDialogWindowController
    // 0xd9549c: LeaveFrame
    //     0xd9549c: mov             SP, fp
    //     0xd954a0: ldp             fp, lr, [SP], #0x10
    // 0xd954a4: ret
    //     0xd954a4: ret             
    // 0xd954a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd954a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd954ac: b               #0xd9547c
    // 0xd954b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd954b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5452, size: 0x18, field offset: 0x14
class _WindowManagerState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xe01850, size: 0x110
    // 0xe01850: EnterFrame
    //     0xe01850: stp             fp, lr, [SP, #-0x10]!
    //     0xe01854: mov             fp, SP
    // 0xe01858: AllocStack(0x20)
    //     0xe01858: sub             SP, SP, #0x20
    // 0xe0185c: SetupParameters(_WindowManagerState this /* r1 => r1, fp-0x8 */)
    //     0xe0185c: stur            x1, [fp, #-8]
    // 0xe01860: CheckStackOverflow
    //     0xe01860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01864: cmp             SP, x16
    //     0xe01868: b.ls            #0xe01950
    // 0xe0186c: r1 = 1
    //     0xe0186c: mov             x1, #1
    // 0xe01870: r0 = AllocateContext()
    //     0xe01870: bl              #0x13de838  ; AllocateContextStub
    // 0xe01874: mov             x1, x0
    // 0xe01878: ldur            x0, [fp, #-8]
    // 0xe0187c: stur            x1, [fp, #-0x10]
    // 0xe01880: StoreField: r1->field_f = r0
    //     0xe01880: stur            w0, [x1, #0xf]
    // 0xe01884: r0 = LoadStaticField(0x878)
    //     0xe01884: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe01888: ldr             x0, [x0, #0x10f0]
    // 0xe0188c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe01890: cmp             w0, w16
    // 0xe01894: b.ne            #0xe018a0
    // 0xe01898: r2 = isWindowingEnabled
    //     0xe01898: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0xe0189c: r0 = InitLateStaticField()
    //     0xe0189c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe018a0: tbz             w0, #4, #0xe018cc
    // 0xe018a4: ldur            x0, [fp, #-8]
    // 0xe018a8: LoadField: r1 = r0->field_b
    //     0xe018a8: ldur            w1, [x0, #0xb]
    // 0xe018ac: DecompressPointer r1
    //     0xe018ac: add             x1, x1, HEAP, lsl #32
    // 0xe018b0: cmp             w1, NULL
    // 0xe018b4: b.eq            #0xe01958
    // 0xe018b8: LoadField: r0 = r1->field_b
    //     0xe018b8: ldur            w0, [x1, #0xb]
    // 0xe018bc: DecompressPointer r0
    //     0xe018bc: add             x0, x0, HEAP, lsl #32
    // 0xe018c0: LeaveFrame
    //     0xe018c0: mov             SP, fp
    //     0xe018c4: ldp             fp, lr, [SP], #0x10
    // 0xe018c8: ret
    //     0xe018c8: ret             
    // 0xe018cc: ldur            x0, [fp, #-8]
    // 0xe018d0: LoadField: r3 = r0->field_13
    //     0xe018d0: ldur            w3, [x0, #0x13]
    // 0xe018d4: DecompressPointer r3
    //     0xe018d4: add             x3, x3, HEAP, lsl #32
    // 0xe018d8: stur            x3, [fp, #-0x18]
    // 0xe018dc: LoadField: r1 = r0->field_b
    //     0xe018dc: ldur            w1, [x0, #0xb]
    // 0xe018e0: DecompressPointer r1
    //     0xe018e0: add             x1, x1, HEAP, lsl #32
    // 0xe018e4: cmp             w1, NULL
    // 0xe018e8: b.eq            #0xe0195c
    // 0xe018ec: LoadField: r0 = r1->field_b
    //     0xe018ec: ldur            w0, [x1, #0xb]
    // 0xe018f0: DecompressPointer r0
    //     0xe018f0: add             x0, x0, HEAP, lsl #32
    // 0xe018f4: ldur            x2, [fp, #-0x10]
    // 0xe018f8: stur            x0, [fp, #-8]
    // 0xe018fc: r1 = Function '<anonymous closure>':.
    //     0xe018fc: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccc88] AnonymousClosure: (0xe0196c), in [package:flutter/src/widgets/_window.dart] _WindowManagerState::build (0xe01850)
    //     0xe01900: ldr             x1, [x1, #0xc88]
    // 0xe01904: r0 = AllocateClosure()
    //     0xe01904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe01908: stur            x0, [fp, #-0x10]
    // 0xe0190c: r0 = ListenableBuilder()
    //     0xe0190c: bl              #0xd5cd58  ; AllocateListenableBuilderStub -> ListenableBuilder (size=0x18)
    // 0xe01910: mov             x1, x0
    // 0xe01914: ldur            x0, [fp, #-0x10]
    // 0xe01918: stur            x1, [fp, #-0x20]
    // 0xe0191c: StoreField: r1->field_f = r0
    //     0xe0191c: stur            w0, [x1, #0xf]
    // 0xe01920: ldur            x0, [fp, #-8]
    // 0xe01924: StoreField: r1->field_13 = r0
    //     0xe01924: stur            w0, [x1, #0x13]
    // 0xe01928: ldur            x0, [fp, #-0x18]
    // 0xe0192c: StoreField: r1->field_b = r0
    //     0xe0192c: stur            w0, [x1, #0xb]
    // 0xe01930: r0 = _WindowRegistryScope()
    //     0xe01930: bl              #0xe01960  ; Allocate_WindowRegistryScopeStub -> _WindowRegistryScope (size=0x14)
    // 0xe01934: ldur            x1, [fp, #-0x18]
    // 0xe01938: StoreField: r0->field_f = r1
    //     0xe01938: stur            w1, [x0, #0xf]
    // 0xe0193c: ldur            x1, [fp, #-0x20]
    // 0xe01940: StoreField: r0->field_b = r1
    //     0xe01940: stur            w1, [x0, #0xb]
    // 0xe01944: LeaveFrame
    //     0xe01944: mov             SP, fp
    //     0xe01948: ldp             fp, lr, [SP], #0x10
    // 0xe0194c: ret
    //     0xe0194c: ret             
    // 0xe01950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01954: b               #0xe0186c
    // 0xe01958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01958: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0195c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0195c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xe0196c, size: 0x1e8
    // 0xe0196c: EnterFrame
    //     0xe0196c: stp             fp, lr, [SP, #-0x10]!
    //     0xe01970: mov             fp, SP
    // 0xe01974: AllocStack(0x28)
    //     0xe01974: sub             SP, SP, #0x28
    // 0xe01978: SetupParameters([dynamic _ /* r0 */])
    //     0xe01978: ldr             x0, [fp, #0x20]
    //     0xe0197c: ldur            w1, [x0, #0x17]
    //     0xe01980: add             x1, x1, HEAP, lsl #32
    // 0xe01984: CheckStackOverflow
    //     0xe01984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe01988: cmp             SP, x16
    //     0xe0198c: b.ls            #0xe01b48
    // 0xe01990: LoadField: r0 = r1->field_f
    //     0xe01990: ldur            w0, [x1, #0xf]
    // 0xe01994: DecompressPointer r0
    //     0xe01994: add             x0, x0, HEAP, lsl #32
    // 0xe01998: LoadField: r1 = r0->field_13
    //     0xe01998: ldur            w1, [x0, #0x13]
    // 0xe0199c: DecompressPointer r1
    //     0xe0199c: add             x1, x1, HEAP, lsl #32
    // 0xe019a0: r0 = windows()
    //     0xe019a0: bl              #0xe01b6c  ; [package:flutter/src/widgets/_window.dart] WindowRegistry::windows
    // 0xe019a4: r1 = Function '<anonymous closure>':.
    //     0xe019a4: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccc90] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xe019a8: ldr             x1, [x1, #0xc90]
    // 0xe019ac: r2 = Null
    //     0xe019ac: mov             x2, NULL
    // 0xe019b0: stur            x0, [fp, #-8]
    // 0xe019b4: r0 = AllocateClosure()
    //     0xe019b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe019b8: r16 = <StatelessWidget>
    //     0xe019b8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27530] TypeArguments: <StatelessWidget>
    //     0xe019bc: ldr             x16, [x16, #0x530]
    // 0xe019c0: ldur            lr, [fp, #-8]
    // 0xe019c4: stp             lr, x16, [SP, #8]
    // 0xe019c8: str             x0, [SP]
    // 0xe019cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe019cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe019d0: r0 = map()
    //     0xe019d0: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xe019d4: mov             x3, x0
    // 0xe019d8: stur            x3, [fp, #-0x10]
    // 0xe019dc: LoadField: r4 = r3->field_7
    //     0xe019dc: ldur            w4, [x3, #7]
    // 0xe019e0: DecompressPointer r4
    //     0xe019e0: add             x4, x4, HEAP, lsl #32
    // 0xe019e4: mov             x0, x3
    // 0xe019e8: stur            x4, [fp, #-8]
    // 0xe019ec: r2 = Null
    //     0xe019ec: mov             x2, NULL
    // 0xe019f0: r1 = Null
    //     0xe019f0: mov             x1, NULL
    // 0xe019f4: cmp             w0, NULL
    // 0xe019f8: b.eq            #0xe01a90
    // 0xe019fc: branchIfSmi(r0, 0xe01a90)
    //     0xe019fc: tbz             w0, #0, #0xe01a90
    // 0xe01a00: r3 = LoadClassIdInstr(r0)
    //     0xe01a00: ldur            x3, [x0, #-1]
    //     0xe01a04: ubfx            x3, x3, #0xc, #0x14
    // 0xe01a08: r17 = 7724
    //     0xe01a08: mov             x17, #0x1e2c
    // 0xe01a0c: cmp             x3, x17
    // 0xe01a10: b.eq            #0xe01a98
    // 0xe01a14: r4 = LoadClassIdInstr(r0)
    //     0xe01a14: ldur            x4, [x0, #-1]
    //     0xe01a18: ubfx            x4, x4, #0xc, #0x14
    // 0xe01a1c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xe01a20: ldr             x3, [x3, #0x18]
    // 0xe01a24: ldr             x3, [x3, x4, lsl #3]
    // 0xe01a28: LoadField: r3 = r3->field_2b
    //     0xe01a28: ldur            w3, [x3, #0x2b]
    // 0xe01a2c: DecompressPointer r3
    //     0xe01a2c: add             x3, x3, HEAP, lsl #32
    // 0xe01a30: cmp             w3, NULL
    // 0xe01a34: b.eq            #0xe01a90
    // 0xe01a38: LoadField: r3 = r3->field_f
    //     0xe01a38: ldur            w3, [x3, #0xf]
    // 0xe01a3c: lsr             x3, x3, #3
    // 0xe01a40: r17 = 7724
    //     0xe01a40: mov             x17, #0x1e2c
    // 0xe01a44: cmp             x3, x17
    // 0xe01a48: b.eq            #0xe01a98
    // 0xe01a4c: r3 = SubtypeTestCache
    //     0xe01a4c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccc98] SubtypeTestCache
    //     0xe01a50: ldr             x3, [x3, #0xc98]
    // 0xe01a54: r30 = Subtype1TestCacheStub
    //     0xe01a54: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xe01a58: LoadField: r30 = r30->field_7
    //     0xe01a58: ldur            lr, [lr, #7]
    // 0xe01a5c: blr             lr
    // 0xe01a60: cmp             w7, NULL
    // 0xe01a64: b.eq            #0xe01a70
    // 0xe01a68: tbnz            w7, #4, #0xe01a90
    // 0xe01a6c: b               #0xe01a98
    // 0xe01a70: r8 = EfficientLengthIterable
    //     0xe01a70: add             x8, PP, #0xcc, lsl #12  ; [pp+0xccca0] Type: EfficientLengthIterable
    //     0xe01a74: ldr             x8, [x8, #0xca0]
    // 0xe01a78: r3 = SubtypeTestCache
    //     0xe01a78: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccca8] SubtypeTestCache
    //     0xe01a7c: ldr             x3, [x3, #0xca8]
    // 0xe01a80: r30 = InstanceOfStub
    //     0xe01a80: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xe01a84: LoadField: r30 = r30->field_7
    //     0xe01a84: ldur            lr, [lr, #7]
    // 0xe01a88: blr             lr
    // 0xe01a8c: b               #0xe01a9c
    // 0xe01a90: r0 = false
    //     0xe01a90: add             x0, NULL, #0x30  ; false
    // 0xe01a94: b               #0xe01a9c
    // 0xe01a98: r0 = true
    //     0xe01a98: add             x0, NULL, #0x20  ; true
    // 0xe01a9c: tbnz            w0, #4, #0xe01ab0
    // 0xe01aa0: ldur            x1, [fp, #-8]
    // 0xe01aa4: ldur            x2, [fp, #-0x10]
    // 0xe01aa8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xe01aa8: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xe01aac: b               #0xe01abc
    // 0xe01ab0: ldur            x1, [fp, #-8]
    // 0xe01ab4: ldur            x2, [fp, #-0x10]
    // 0xe01ab8: r0 = _GrowableList._ofOther()
    //     0xe01ab8: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xe01abc: ldr             x1, [fp, #0x18]
    // 0xe01ac0: stur            x0, [fp, #-8]
    // 0xe01ac4: r0 = maybeOf()
    //     0xe01ac4: bl              #0x865020  ; [package:flutter/src/widgets/view.dart] View::maybeOf
    // 0xe01ac8: cmp             w0, NULL
    // 0xe01acc: b.ne            #0xe01af4
    // 0xe01ad0: ldur            x0, [fp, #-8]
    // 0xe01ad4: r0 = ViewCollection()
    //     0xe01ad4: bl              #0xe01b60  ; AllocateViewCollectionStub -> ViewCollection (size=0x14)
    // 0xe01ad8: mov             x1, x0
    // 0xe01adc: ldur            x0, [fp, #-8]
    // 0xe01ae0: StoreField: r1->field_b = r0
    //     0xe01ae0: stur            w0, [x1, #0xb]
    // 0xe01ae4: mov             x0, x1
    // 0xe01ae8: LeaveFrame
    //     0xe01ae8: mov             SP, fp
    //     0xe01aec: ldp             fp, lr, [SP], #0x10
    // 0xe01af0: ret
    //     0xe01af0: ret             
    // 0xe01af4: ldur            x0, [fp, #-8]
    // 0xe01af8: LoadField: r1 = r0->field_b
    //     0xe01af8: ldur            w1, [x0, #0xb]
    // 0xe01afc: cbz             w1, #0xe01b14
    // 0xe01b00: r0 = ViewCollection()
    //     0xe01b00: bl              #0xe01b60  ; AllocateViewCollectionStub -> ViewCollection (size=0x14)
    // 0xe01b04: mov             x1, x0
    // 0xe01b08: ldur            x0, [fp, #-8]
    // 0xe01b0c: StoreField: r1->field_b = r0
    //     0xe01b0c: stur            w0, [x1, #0xb]
    // 0xe01b10: b               #0xe01b18
    // 0xe01b14: r1 = Null
    //     0xe01b14: mov             x1, NULL
    // 0xe01b18: ldr             x0, [fp, #0x10]
    // 0xe01b1c: stur            x1, [fp, #-8]
    // 0xe01b20: cmp             w0, NULL
    // 0xe01b24: b.eq            #0xe01b50
    // 0xe01b28: r0 = ViewAnchor()
    //     0xe01b28: bl              #0xe01b54  ; AllocateViewAnchorStub -> ViewAnchor (size=0x14)
    // 0xe01b2c: ldur            x1, [fp, #-8]
    // 0xe01b30: StoreField: r0->field_b = r1
    //     0xe01b30: stur            w1, [x0, #0xb]
    // 0xe01b34: ldr             x1, [fp, #0x10]
    // 0xe01b38: StoreField: r0->field_f = r1
    //     0xe01b38: stur            w1, [x0, #0xf]
    // 0xe01b3c: LeaveFrame
    //     0xe01b3c: mov             SP, fp
    //     0xe01b40: ldp             fp, lr, [SP], #0x10
    // 0xe01b44: ret
    //     0xe01b44: ret             
    // 0xe01b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01b4c: b               #0xe01990
    // 0xe01b50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01b50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6411, size: 0x10, field offset: 0xc
//   const constructor, 
class WindowManager extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3454, size: 0x50
    // 0xfa3454: EnterFrame
    //     0xfa3454: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3458: mov             fp, SP
    // 0xfa345c: AllocStack(0x8)
    //     0xfa345c: sub             SP, SP, #8
    // 0xfa3460: CheckStackOverflow
    //     0xfa3460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa3464: cmp             SP, x16
    //     0xfa3468: b.ls            #0xfa349c
    // 0xfa346c: r0 = WindowRegistry()
    //     0xfa346c: bl              #0xfa359c  ; AllocateWindowRegistryStub -> WindowRegistry (size=0x28)
    // 0xfa3470: mov             x1, x0
    // 0xfa3474: stur            x0, [fp, #-8]
    // 0xfa3478: r0 = WindowRegistry()
    //     0xfa3478: bl              #0xfa34b0  ; [package:flutter/src/widgets/_window.dart] WindowRegistry::WindowRegistry
    // 0xfa347c: r1 = <WindowManager>
    //     0xfa347c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6a0] TypeArguments: <WindowManager>
    //     0xfa3480: ldr             x1, [x1, #0x6a0]
    // 0xfa3484: r0 = _WindowManagerState()
    //     0xfa3484: bl              #0xfa34a4  ; Allocate_WindowManagerStateStub -> _WindowManagerState (size=0x18)
    // 0xfa3488: ldur            x1, [fp, #-8]
    // 0xfa348c: StoreField: r0->field_13 = r1
    //     0xfa348c: stur            w1, [x0, #0x13]
    // 0xfa3490: LeaveFrame
    //     0xfa3490: mov             SP, fp
    //     0xfa3494: ldp             fp, lr, [SP], #0x10
    // 0xfa3498: ret
    //     0xfa3498: ret             
    // 0xfa349c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa349c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa34a0: b               #0xfa346c
  }
}

// class id: 6800, size: 0x14, field offset: 0x10
class _WindowRegistryScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc01460, size: 0x8c
    // 0xc01460: EnterFrame
    //     0xc01460: stp             fp, lr, [SP, #-0x10]!
    //     0xc01464: mov             fp, SP
    // 0xc01468: AllocStack(0x10)
    //     0xc01468: sub             SP, SP, #0x10
    // 0xc0146c: SetupParameters(_WindowRegistryScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc0146c: mov             x0, x2
    //     0xc01470: mov             x4, x1
    //     0xc01474: mov             x3, x2
    //     0xc01478: stur            x1, [fp, #-8]
    //     0xc0147c: stur            x2, [fp, #-0x10]
    // 0xc01480: r2 = Null
    //     0xc01480: mov             x2, NULL
    // 0xc01484: r1 = Null
    //     0xc01484: mov             x1, NULL
    // 0xc01488: r4 = 60
    //     0xc01488: mov             x4, #0x3c
    // 0xc0148c: branchIfSmi(r0, 0xc01498)
    //     0xc0148c: tbz             w0, #0, #0xc01498
    // 0xc01490: r4 = LoadClassIdInstr(r0)
    //     0xc01490: ldur            x4, [x0, #-1]
    //     0xc01494: ubfx            x4, x4, #0xc, #0x14
    // 0xc01498: r17 = 6800
    //     0xc01498: mov             x17, #0x1a90
    // 0xc0149c: cmp             x4, x17
    // 0xc014a0: b.eq            #0xc014b8
    // 0xc014a4: r8 = _WindowRegistryScope
    //     0xc014a4: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd0470] Type: _WindowRegistryScope
    //     0xc014a8: ldr             x8, [x8, #0x470]
    // 0xc014ac: r3 = Null
    //     0xc014ac: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0478] Null
    //     0xc014b0: ldr             x3, [x3, #0x478]
    // 0xc014b4: r0 = DefaultTypeTest()
    //     0xc014b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc014b8: ldur            x1, [fp, #-8]
    // 0xc014bc: LoadField: r2 = r1->field_f
    //     0xc014bc: ldur            w2, [x1, #0xf]
    // 0xc014c0: DecompressPointer r2
    //     0xc014c0: add             x2, x2, HEAP, lsl #32
    // 0xc014c4: ldur            x1, [fp, #-0x10]
    // 0xc014c8: LoadField: r3 = r1->field_f
    //     0xc014c8: ldur            w3, [x1, #0xf]
    // 0xc014cc: DecompressPointer r3
    //     0xc014cc: add             x3, x3, HEAP, lsl #32
    // 0xc014d0: cmp             w2, w3
    // 0xc014d4: r16 = true
    //     0xc014d4: add             x16, NULL, #0x20  ; true
    // 0xc014d8: r17 = false
    //     0xc014d8: add             x17, NULL, #0x30  ; false
    // 0xc014dc: csel            x0, x16, x17, ne
    // 0xc014e0: LeaveFrame
    //     0xc014e0: mov             SP, fp
    //     0xc014e4: ldp             fp, lr, [SP], #0x10
    // 0xc014e8: ret
    //     0xc014e8: ret             
  }
}

// class id: 6805, size: 0x18, field offset: 0x14
class WindowScope extends InheritedModel<dynamic> {

  static _ _maybeOf(/* No info */) {
    // ** addr: 0xd95598, size: 0xcc
    // 0xd95598: EnterFrame
    //     0xd95598: stp             fp, lr, [SP, #-0x10]!
    //     0xd9559c: mov             fp, SP
    // 0xd955a0: AllocStack(0x28)
    //     0xd955a0: sub             SP, SP, #0x28
    // 0xd955a4: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0xd955a4: stur            x1, [fp, #-0x10]
    //     0xd955a8: ldur            w0, [x4, #0x13]
    //     0xd955ac: sub             x2, x0, #2
    //     0xd955b0: cmp             w2, #2
    //     0xd955b4: b.lt            #0xd955c4
    //     0xd955b8: add             x0, fp, w2, sxtw #2
    //     0xd955bc: ldr             x0, [x0, #8]
    //     0xd955c0: b               #0xd955c8
    //     0xd955c4: mov             x0, NULL
    //     0xd955c8: stur            x0, [fp, #-8]
    // 0xd955cc: CheckStackOverflow
    //     0xd955cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd955d0: cmp             SP, x16
    //     0xd955d4: b.ls            #0xd9565c
    // 0xd955d8: r0 = LoadStaticField(0x878)
    //     0xd955d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd955dc: ldr             x0, [x0, #0x10f0]
    // 0xd955e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd955e4: cmp             w0, w16
    // 0xd955e8: b.ne            #0xd955f4
    // 0xd955ec: r2 = isWindowingEnabled
    //     0xd955ec: ldr             x2, [PP, #0x1b78]  ; [pp+0x1b78] Field <::.isWindowingEnabled>: static late (offset: 0x878)
    // 0xd955f0: r0 = InitLateStaticField()
    //     0xd955f0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd955f4: tbnz            w0, #4, #0xd95640
    // 0xd955f8: r16 = <WindowScope>
    //     0xd955f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15258] TypeArguments: <WindowScope>
    //     0xd955fc: ldr             x16, [x16, #0x258]
    // 0xd95600: ldur            lr, [fp, #-0x10]
    // 0xd95604: stp             lr, x16, [SP, #8]
    // 0xd95608: ldur            x16, [fp, #-8]
    // 0xd9560c: str             x16, [SP]
    // 0xd95610: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd95610: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd95614: r0 = inheritFrom()
    //     0xd95614: bl              #0x865244  ; [package:flutter/src/widgets/inherited_model.dart] InheritedModel::inheritFrom
    // 0xd95618: cmp             w0, NULL
    // 0xd9561c: b.ne            #0xd95628
    // 0xd95620: r0 = Null
    //     0xd95620: mov             x0, NULL
    // 0xd95624: b               #0xd95634
    // 0xd95628: LoadField: r1 = r0->field_13
    //     0xd95628: ldur            w1, [x0, #0x13]
    // 0xd9562c: DecompressPointer r1
    //     0xd9562c: add             x1, x1, HEAP, lsl #32
    // 0xd95630: mov             x0, x1
    // 0xd95634: LeaveFrame
    //     0xd95634: mov             SP, fp
    //     0xd95638: ldp             fp, lr, [SP], #0x10
    // 0xd9563c: ret
    //     0xd9563c: ret             
    // 0xd95640: r0 = UnsupportedError()
    //     0xd95640: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xd95644: mov             x1, x0
    // 0xd95648: r0 = "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    //     0xd95648: ldr             x0, [PP, #0x1b80]  ; [pp+0x1b80] "Windowing APIs are not enabled.\n\nWindowing APIs are currently experimental. Do not use windowing APIs in\nproduction applications or plugins published to pub.dev.\n\nTo try experimental windowing APIs:\n1. Switch to Flutter\'s main release channel.\n2. Turn on the windowing feature flag.\n\nSee: https://github.com/flutter/flutter/issues/30701.\n"
    // 0xd9564c: StoreField: r1->field_b = r0
    //     0xd9564c: stur            w0, [x1, #0xb]
    // 0xd95650: mov             x0, x1
    // 0xd95654: r0 = Throw()
    //     0xd95654: bl              #0x13ddb2c  ; ThrowStub
    // 0xd95658: brk             #0
    // 0xd9565c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9565c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95660: b               #0xd955d8
  }
  static _ maybeContentSizeOf(/* No info */) {
    // ** addr: 0xd95664, size: 0x44
    // 0xd95664: EnterFrame
    //     0xd95664: stp             fp, lr, [SP, #-0x10]!
    //     0xd95668: mov             fp, SP
    // 0xd9566c: AllocStack(0x8)
    //     0xd9566c: sub             SP, SP, #8
    // 0xd95670: CheckStackOverflow
    //     0xd95670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95674: cmp             SP, x16
    //     0xd95678: b.ls            #0xd956a0
    // 0xd9567c: r16 = Instance__WindowControllerAspect
    //     0xd9567c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15260] Obj!_WindowControllerAspect@12c3601
    //     0xd95680: ldr             x16, [x16, #0x260]
    // 0xd95684: str             x16, [SP]
    // 0xd95688: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd95688: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd9568c: r0 = _maybeOf()
    //     0xd9568c: bl              #0xd95598  ; [package:flutter/src/widgets/_window.dart] WindowScope::_maybeOf
    // 0xd95690: r0 = Null
    //     0xd95690: mov             x0, NULL
    // 0xd95694: LeaveFrame
    //     0xd95694: mov             SP, fp
    //     0xd95698: ldp             fp, lr, [SP], #0x10
    // 0xd9569c: ret
    //     0xd9569c: ret             
    // 0xd956a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd956a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd956a4: b               #0xd9567c
  }
  [closure] bool <anonymous closure>(dynamic, Object) {
    // ** addr: 0x1219298, size: 0x68
    // 0x1219298: EnterFrame
    //     0x1219298: stp             fp, lr, [SP, #-0x10]!
    //     0x121929c: mov             fp, SP
    // 0x12192a0: ldr             x0, [fp, #0x10]
    // 0x12192a4: r1 = 60
    //     0x12192a4: mov             x1, #0x3c
    // 0x12192a8: branchIfSmi(r0, 0x12192b4)
    //     0x12192a8: tbz             w0, #0, #0x12192b4
    // 0x12192ac: r1 = LoadClassIdInstr(r0)
    //     0x12192ac: ldur            x1, [x0, #-1]
    //     0x12192b0: ubfx            x1, x1, #0xc, #0x14
    // 0x12192b4: r17 = 8191
    //     0x12192b4: mov             x17, #0x1fff
    // 0x12192b8: cmp             x1, x17
    // 0x12192bc: b.ne            #0x12192e4
    // 0x12192c0: LoadField: r1 = r0->field_7
    //     0x12192c0: ldur            x1, [x0, #7]
    // 0x12192c4: cmp             x1, #2
    // 0x12192c8: b.gt            #0x12192dc
    // 0x12192cc: cmp             x1, #1
    // 0x12192d0: b.gt            #0x12192dc
    // 0x12192d4: cmp             x1, #0
    // 0x12192d8: b.le            #0x12192f4
    // 0x12192dc: r0 = Null
    //     0x12192dc: mov             x0, NULL
    // 0x12192e0: b               #0x12192e8
    // 0x12192e4: r0 = false
    //     0x12192e4: add             x0, NULL, #0x30  ; false
    // 0x12192e8: LeaveFrame
    //     0x12192e8: mov             SP, fp
    //     0x12192ec: ldp             fp, lr, [SP], #0x10
    // 0x12192f0: ret
    //     0x12192f0: ret             
    // 0x12192f4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12192f4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12192f8: r0 = Throw()
    //     0x12192f8: bl              #0x13ddb2c  ; ThrowStub
    // 0x12192fc: brk             #0
  }
}

// class id: 8191, size: 0x14, field offset: 0x14
enum _WindowControllerAspect extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abcb0, size: 0x64
    // 0x11abcb0: EnterFrame
    //     0x11abcb0: stp             fp, lr, [SP, #-0x10]!
    //     0x11abcb4: mov             fp, SP
    // 0x11abcb8: AllocStack(0x10)
    //     0x11abcb8: sub             SP, SP, #0x10
    // 0x11abcbc: SetupParameters(_WindowControllerAspect this /* r1 => r0, fp-0x8 */)
    //     0x11abcbc: mov             x0, x1
    //     0x11abcc0: stur            x1, [fp, #-8]
    // 0x11abcc4: CheckStackOverflow
    //     0x11abcc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abcc8: cmp             SP, x16
    //     0x11abccc: b.ls            #0x11abd0c
    // 0x11abcd0: r1 = Null
    //     0x11abcd0: mov             x1, NULL
    // 0x11abcd4: r2 = 4
    //     0x11abcd4: mov             x2, #4
    // 0x11abcd8: r0 = AllocateArray()
    //     0x11abcd8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abcdc: r16 = "_WindowControllerAspect."
    //     0x11abcdc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26998] "_WindowControllerAspect."
    //     0x11abce0: ldr             x16, [x16, #0x998]
    // 0x11abce4: StoreField: r0->field_f = r16
    //     0x11abce4: stur            w16, [x0, #0xf]
    // 0x11abce8: ldur            x1, [fp, #-8]
    // 0x11abcec: LoadField: r2 = r1->field_f
    //     0x11abcec: ldur            w2, [x1, #0xf]
    // 0x11abcf0: DecompressPointer r2
    //     0x11abcf0: add             x2, x2, HEAP, lsl #32
    // 0x11abcf4: StoreField: r0->field_13 = r2
    //     0x11abcf4: stur            w2, [x0, #0x13]
    // 0x11abcf8: str             x0, [SP]
    // 0x11abcfc: r0 = _interpolate()
    //     0x11abcfc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abd00: LeaveFrame
    //     0x11abd00: mov             SP, fp
    //     0x11abd04: ldp             fp, lr, [SP], #0x10
    // 0x11abd08: ret
    //     0x11abd08: ret             
    // 0x11abd0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abd0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abd10: b               #0x11abcd0
  }
}
