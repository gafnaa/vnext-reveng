// lib: , url: package:flutter/src/widgets/default_selection_style.dart

// class id: 1049127, size: 0x8
class :: {
}

// class id: 6120, size: 0xc, field offset: 0xc
//   const constructor, 
class _NullWidget extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbfbc0, size: 0x34
    // 0xfbfbc0: EnterFrame
    //     0xfbfbc0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbfbc4: mov             fp, SP
    // 0xfbfbc8: CheckStackOverflow
    //     0xfbfbc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbfbcc: cmp             SP, x16
    //     0xfbfbd0: b.ls            #0xfbfbec
    // 0xfbfbd4: r1 = Null
    //     0xfbfbd4: mov             x1, NULL
    // 0xfbfbd8: r2 = "A DefaultSelectionStyle constructed with DefaultSelectionStyle.fallback cannot be incorporated into the widget tree, it is meant only to provide a fallback value returned by DefaultSelectionStyle.of() when no enclosing default selection style is present in a BuildContext."
    //     0xfbfbd8: add             x2, PP, #0x80, lsl #12  ; [pp+0x80ed8] "A DefaultSelectionStyle constructed with DefaultSelectionStyle.fallback cannot be incorporated into the widget tree, it is meant only to provide a fallback value returned by DefaultSelectionStyle.of() when no enclosing default selection style is present in a BuildContext."
    //     0xfbfbdc: ldr             x2, [x2, #0xed8]
    // 0xfbfbe0: r0 = FlutterError()
    //     0xfbfbe0: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xfbfbe4: r0 = Throw()
    //     0xfbfbe4: bl              #0x13ddb2c  ; ThrowStub
    // 0xfbfbe8: brk             #0
    // 0xfbfbec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbfbec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbfbf0: b               #0xfbfbd4
  }
}

// class id: 6832, size: 0x1c, field offset: 0x10
//   const constructor, 
class DefaultSelectionStyle extends InheritedTheme {

  _NullWidget field_c;

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc0068c, size: 0x12c
    // 0xc0068c: EnterFrame
    //     0xc0068c: stp             fp, lr, [SP, #-0x10]!
    //     0xc00690: mov             fp, SP
    // 0xc00694: AllocStack(0x20)
    //     0xc00694: sub             SP, SP, #0x20
    // 0xc00698: SetupParameters(DefaultSelectionStyle this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc00698: mov             x4, x1
    //     0xc0069c: mov             x3, x2
    //     0xc006a0: stur            x1, [fp, #-8]
    //     0xc006a4: stur            x2, [fp, #-0x10]
    // 0xc006a8: CheckStackOverflow
    //     0xc006a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc006ac: cmp             SP, x16
    //     0xc006b0: b.ls            #0xc007b0
    // 0xc006b4: mov             x0, x3
    // 0xc006b8: r2 = Null
    //     0xc006b8: mov             x2, NULL
    // 0xc006bc: r1 = Null
    //     0xc006bc: mov             x1, NULL
    // 0xc006c0: r4 = 60
    //     0xc006c0: mov             x4, #0x3c
    // 0xc006c4: branchIfSmi(r0, 0xc006d0)
    //     0xc006c4: tbz             w0, #0, #0xc006d0
    // 0xc006c8: r4 = LoadClassIdInstr(r0)
    //     0xc006c8: ldur            x4, [x0, #-1]
    //     0xc006cc: ubfx            x4, x4, #0xc, #0x14
    // 0xc006d0: r17 = 6832
    //     0xc006d0: mov             x17, #0x1ab0
    // 0xc006d4: cmp             x4, x17
    // 0xc006d8: b.eq            #0xc006f0
    // 0xc006dc: r8 = DefaultSelectionStyle
    //     0xc006dc: add             x8, PP, #0x97, lsl #12  ; [pp+0x97620] Type: DefaultSelectionStyle
    //     0xc006e0: ldr             x8, [x8, #0x620]
    // 0xc006e4: r3 = Null
    //     0xc006e4: add             x3, PP, #0x97, lsl #12  ; [pp+0x97628] Null
    //     0xc006e8: ldr             x3, [x3, #0x628]
    // 0xc006ec: r0 = DefaultTypeTest()
    //     0xc006ec: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc006f0: ldur            x1, [fp, #-8]
    // 0xc006f4: LoadField: r0 = r1->field_f
    //     0xc006f4: ldur            w0, [x1, #0xf]
    // 0xc006f8: DecompressPointer r0
    //     0xc006f8: add             x0, x0, HEAP, lsl #32
    // 0xc006fc: ldur            x2, [fp, #-0x10]
    // 0xc00700: LoadField: r3 = r2->field_f
    //     0xc00700: ldur            w3, [x2, #0xf]
    // 0xc00704: DecompressPointer r3
    //     0xc00704: add             x3, x3, HEAP, lsl #32
    // 0xc00708: r4 = LoadClassIdInstr(r0)
    //     0xc00708: ldur            x4, [x0, #-1]
    //     0xc0070c: ubfx            x4, x4, #0xc, #0x14
    // 0xc00710: stp             x3, x0, [SP]
    // 0xc00714: mov             x0, x4
    // 0xc00718: mov             lr, x0
    // 0xc0071c: ldr             lr, [x21, lr, lsl #3]
    // 0xc00720: blr             lr
    // 0xc00724: tbnz            w0, #4, #0xc00760
    // 0xc00728: ldur            x1, [fp, #-8]
    // 0xc0072c: ldur            x2, [fp, #-0x10]
    // 0xc00730: LoadField: r0 = r1->field_13
    //     0xc00730: ldur            w0, [x1, #0x13]
    // 0xc00734: DecompressPointer r0
    //     0xc00734: add             x0, x0, HEAP, lsl #32
    // 0xc00738: LoadField: r3 = r2->field_13
    //     0xc00738: ldur            w3, [x2, #0x13]
    // 0xc0073c: DecompressPointer r3
    //     0xc0073c: add             x3, x3, HEAP, lsl #32
    // 0xc00740: r4 = LoadClassIdInstr(r0)
    //     0xc00740: ldur            x4, [x0, #-1]
    //     0xc00744: ubfx            x4, x4, #0xc, #0x14
    // 0xc00748: stp             x3, x0, [SP]
    // 0xc0074c: mov             x0, x4
    // 0xc00750: mov             lr, x0
    // 0xc00754: ldr             lr, [x21, lr, lsl #3]
    // 0xc00758: blr             lr
    // 0xc0075c: tbz             w0, #4, #0xc00768
    // 0xc00760: r0 = true
    //     0xc00760: add             x0, NULL, #0x20  ; true
    // 0xc00764: b               #0xc007a4
    // 0xc00768: ldur            x0, [fp, #-8]
    // 0xc0076c: ldur            x1, [fp, #-0x10]
    // 0xc00770: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xc00770: ldur            w2, [x0, #0x17]
    // 0xc00774: DecompressPointer r2
    //     0xc00774: add             x2, x2, HEAP, lsl #32
    // 0xc00778: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xc00778: ldur            w0, [x1, #0x17]
    // 0xc0077c: DecompressPointer r0
    //     0xc0077c: add             x0, x0, HEAP, lsl #32
    // 0xc00780: r1 = LoadClassIdInstr(r2)
    //     0xc00780: ldur            x1, [x2, #-1]
    //     0xc00784: ubfx            x1, x1, #0xc, #0x14
    // 0xc00788: stp             x0, x2, [SP]
    // 0xc0078c: mov             x0, x1
    // 0xc00790: mov             lr, x0
    // 0xc00794: ldr             lr, [x21, lr, lsl #3]
    // 0xc00798: blr             lr
    // 0xc0079c: eor             x1, x0, #0x10
    // 0xc007a0: mov             x0, x1
    // 0xc007a4: LeaveFrame
    //     0xc007a4: mov             SP, fp
    //     0xc007a8: ldp             fp, lr, [SP], #0x10
    // 0xc007ac: ret
    //     0xc007ac: ret             
    // 0xc007b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc007b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc007b4: b               #0xc006b4
  }
  static _ merge(/* No info */) {
    // ** addr: 0xd20868, size: 0x5c
    // 0xd20868: EnterFrame
    //     0xd20868: stp             fp, lr, [SP, #-0x10]!
    //     0xd2086c: mov             fp, SP
    // 0xd20870: AllocStack(0x10)
    //     0xd20870: sub             SP, SP, #0x10
    // 0xd20874: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd20874: stur            x1, [fp, #-8]
    //     0xd20878: stur            x2, [fp, #-0x10]
    // 0xd2087c: r1 = 2
    //     0xd2087c: mov             x1, #2
    // 0xd20880: r0 = AllocateContext()
    //     0xd20880: bl              #0x13de838  ; AllocateContextStub
    // 0xd20884: mov             x1, x0
    // 0xd20888: ldur            x0, [fp, #-8]
    // 0xd2088c: StoreField: r1->field_f = r0
    //     0xd2088c: stur            w0, [x1, #0xf]
    // 0xd20890: ldur            x0, [fp, #-0x10]
    // 0xd20894: StoreField: r1->field_13 = r0
    //     0xd20894: stur            w0, [x1, #0x13]
    // 0xd20898: mov             x2, x1
    // 0xd2089c: r1 = Function '<anonymous closure>': static.
    //     0xd2089c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99668] AnonymousClosure: static (0xd208c4), in [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::merge (0xd20868)
    //     0xd208a0: ldr             x1, [x1, #0x668]
    // 0xd208a4: r0 = AllocateClosure()
    //     0xd208a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd208a8: stur            x0, [fp, #-8]
    // 0xd208ac: r0 = Builder()
    //     0xd208ac: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd208b0: ldur            x1, [fp, #-8]
    // 0xd208b4: StoreField: r0->field_b = r1
    //     0xd208b4: stur            w1, [x0, #0xb]
    // 0xd208b8: LeaveFrame
    //     0xd208b8: mov             SP, fp
    //     0xd208bc: ldp             fp, lr, [SP], #0x10
    // 0xd208c0: ret
    //     0xd208c0: ret             
  }
  [closure] static DefaultSelectionStyle <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd208c4, size: 0x9c
    // 0xd208c4: EnterFrame
    //     0xd208c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd208c8: mov             fp, SP
    // 0xd208cc: AllocStack(0x28)
    //     0xd208cc: sub             SP, SP, #0x28
    // 0xd208d0: SetupParameters([dynamic _ /* r0 */])
    //     0xd208d0: ldr             x0, [fp, #0x18]
    //     0xd208d4: ldur            w2, [x0, #0x17]
    //     0xd208d8: add             x2, x2, HEAP, lsl #32
    //     0xd208dc: stur            x2, [fp, #-8]
    // 0xd208e0: CheckStackOverflow
    //     0xd208e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd208e4: cmp             SP, x16
    //     0xd208e8: b.ls            #0xd20958
    // 0xd208ec: ldr             x1, [fp, #0x10]
    // 0xd208f0: r0 = of()
    //     0xd208f0: bl              #0xd2096c  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0xd208f4: LoadField: r1 = r0->field_f
    //     0xd208f4: ldur            w1, [x0, #0xf]
    // 0xd208f8: DecompressPointer r1
    //     0xd208f8: add             x1, x1, HEAP, lsl #32
    // 0xd208fc: stur            x1, [fp, #-0x28]
    // 0xd20900: LoadField: r2 = r0->field_13
    //     0xd20900: ldur            w2, [x0, #0x13]
    // 0xd20904: DecompressPointer r2
    //     0xd20904: add             x2, x2, HEAP, lsl #32
    // 0xd20908: ldur            x0, [fp, #-8]
    // 0xd2090c: stur            x2, [fp, #-0x20]
    // 0xd20910: LoadField: r3 = r0->field_13
    //     0xd20910: ldur            w3, [x0, #0x13]
    // 0xd20914: DecompressPointer r3
    //     0xd20914: add             x3, x3, HEAP, lsl #32
    // 0xd20918: stur            x3, [fp, #-0x18]
    // 0xd2091c: LoadField: r4 = r0->field_f
    //     0xd2091c: ldur            w4, [x0, #0xf]
    // 0xd20920: DecompressPointer r4
    //     0xd20920: add             x4, x4, HEAP, lsl #32
    // 0xd20924: stur            x4, [fp, #-0x10]
    // 0xd20928: r0 = DefaultSelectionStyle()
    //     0xd20928: bl              #0xd20960  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x1c)
    // 0xd2092c: ldur            x1, [fp, #-0x28]
    // 0xd20930: StoreField: r0->field_f = r1
    //     0xd20930: stur            w1, [x0, #0xf]
    // 0xd20934: ldur            x1, [fp, #-0x20]
    // 0xd20938: StoreField: r0->field_13 = r1
    //     0xd20938: stur            w1, [x0, #0x13]
    // 0xd2093c: ldur            x1, [fp, #-0x18]
    // 0xd20940: ArrayStore: r0[0] = r1  ; List_4
    //     0xd20940: stur            w1, [x0, #0x17]
    // 0xd20944: ldur            x1, [fp, #-0x10]
    // 0xd20948: StoreField: r0->field_b = r1
    //     0xd20948: stur            w1, [x0, #0xb]
    // 0xd2094c: LeaveFrame
    //     0xd2094c: mov             SP, fp
    //     0xd20950: ldp             fp, lr, [SP], #0x10
    // 0xd20954: ret
    //     0xd20954: ret             
    // 0xd20958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2095c: b               #0xd208ec
  }
  static _ of(/* No info */) {
    // ** addr: 0xd2096c, size: 0x50
    // 0xd2096c: EnterFrame
    //     0xd2096c: stp             fp, lr, [SP, #-0x10]!
    //     0xd20970: mov             fp, SP
    // 0xd20974: AllocStack(0x10)
    //     0xd20974: sub             SP, SP, #0x10
    // 0xd20978: CheckStackOverflow
    //     0xd20978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2097c: cmp             SP, x16
    //     0xd20980: b.ls            #0xd209b4
    // 0xd20984: r16 = <DefaultSelectionStyle>
    //     0xd20984: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b30] TypeArguments: <DefaultSelectionStyle>
    //     0xd20988: ldr             x16, [x16, #0xb30]
    // 0xd2098c: stp             x1, x16, [SP]
    // 0xd20990: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd20990: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd20994: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd20994: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd20998: cmp             w0, NULL
    // 0xd2099c: b.ne            #0xd209a8
    // 0xd209a0: r0 = Instance_DefaultSelectionStyle
    //     0xd209a0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b38] Obj!DefaultSelectionStyle@12b7831
    //     0xd209a4: ldr             x0, [x0, #0xb38]
    // 0xd209a8: LeaveFrame
    //     0xd209a8: mov             SP, fp
    //     0xd209ac: ldp             fp, lr, [SP], #0x10
    // 0xd209b0: ret
    //     0xd209b0: ret             
    // 0xd209b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd209b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd209b8: b               #0xd20984
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200fa8, size: 0x64
    // 0x1200fa8: EnterFrame
    //     0x1200fa8: stp             fp, lr, [SP, #-0x10]!
    //     0x1200fac: mov             fp, SP
    // 0x1200fb0: AllocStack(0x20)
    //     0x1200fb0: sub             SP, SP, #0x20
    // 0x1200fb4: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x1200fb4: stur            x2, [fp, #-0x20]
    // 0x1200fb8: LoadField: r0 = r1->field_f
    //     0x1200fb8: ldur            w0, [x1, #0xf]
    // 0x1200fbc: DecompressPointer r0
    //     0x1200fbc: add             x0, x0, HEAP, lsl #32
    // 0x1200fc0: stur            x0, [fp, #-0x18]
    // 0x1200fc4: LoadField: r3 = r1->field_13
    //     0x1200fc4: ldur            w3, [x1, #0x13]
    // 0x1200fc8: DecompressPointer r3
    //     0x1200fc8: add             x3, x3, HEAP, lsl #32
    // 0x1200fcc: stur            x3, [fp, #-0x10]
    // 0x1200fd0: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x1200fd0: ldur            w4, [x1, #0x17]
    // 0x1200fd4: DecompressPointer r4
    //     0x1200fd4: add             x4, x4, HEAP, lsl #32
    // 0x1200fd8: stur            x4, [fp, #-8]
    // 0x1200fdc: r0 = DefaultSelectionStyle()
    //     0x1200fdc: bl              #0xd20960  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x1c)
    // 0x1200fe0: ldur            x1, [fp, #-0x18]
    // 0x1200fe4: StoreField: r0->field_f = r1
    //     0x1200fe4: stur            w1, [x0, #0xf]
    // 0x1200fe8: ldur            x1, [fp, #-0x10]
    // 0x1200fec: StoreField: r0->field_13 = r1
    //     0x1200fec: stur            w1, [x0, #0x13]
    // 0x1200ff0: ldur            x1, [fp, #-8]
    // 0x1200ff4: ArrayStore: r0[0] = r1  ; List_4
    //     0x1200ff4: stur            w1, [x0, #0x17]
    // 0x1200ff8: ldur            x1, [fp, #-0x20]
    // 0x1200ffc: StoreField: r0->field_b = r1
    //     0x1200ffc: stur            w1, [x0, #0xb]
    // 0x1201000: LeaveFrame
    //     0x1201000: mov             SP, fp
    //     0x1201004: ldp             fp, lr, [SP], #0x10
    // 0x1201008: ret
    //     0x1201008: ret             
  }
}
