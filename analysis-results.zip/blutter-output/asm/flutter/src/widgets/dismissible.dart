// lib: , url: package:flutter/src/widgets/dismissible.dart

// class id: 1049131, size: 0x8
class :: {
}

// class id: 5669, size: 0x44, field offset: 0x20
class _DismissibleState extends _MixinApplication210&State&TickerProviderStateMixin&AutomaticKeepAliveClientMixin {

  late Animation<Offset> _moveAnimation; // offset: 0x24
  late final AnimationController _moveController; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xd5f3b8, size: 0x25c
    // 0xd5f3b8: EnterFrame
    //     0xd5f3b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f3bc: mov             fp, SP
    // 0xd5f3c0: AllocStack(0x80)
    //     0xd5f3c0: sub             SP, SP, #0x80
    // 0xd5f3c4: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */)
    //     0xd5f3c4: mov             x0, x1
    //     0xd5f3c8: stur            x1, [fp, #-8]
    // 0xd5f3cc: CheckStackOverflow
    //     0xd5f3cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5f3d0: cmp             SP, x16
    //     0xd5f3d4: b.ls            #0xd5f5f8
    // 0xd5f3d8: mov             x1, x0
    // 0xd5f3dc: r0 = build()
    //     0xd5f3dc: bl              #0xd5f680  ; [dart:mixin_deduplication] _MixinApplication210&State&TickerProviderStateMixin&AutomaticKeepAliveClientMixin::build
    // 0xd5f3e0: ldur            x1, [fp, #-8]
    // 0xd5f3e4: LoadField: r0 = r1->field_b
    //     0xd5f3e4: ldur            w0, [x1, #0xb]
    // 0xd5f3e8: DecompressPointer r0
    //     0xd5f3e8: add             x0, x0, HEAP, lsl #32
    // 0xd5f3ec: stur            x0, [fp, #-0x28]
    // 0xd5f3f0: cmp             w0, NULL
    // 0xd5f3f4: b.eq            #0xd5f600
    // 0xd5f3f8: LoadField: r2 = r1->field_23
    //     0xd5f3f8: ldur            w2, [x1, #0x23]
    // 0xd5f3fc: DecompressPointer r2
    //     0xd5f3fc: add             x2, x2, HEAP, lsl #32
    // 0xd5f400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5f404: cmp             w2, w16
    // 0xd5f408: b.eq            #0xd5f604
    // 0xd5f40c: stur            x2, [fp, #-0x20]
    // 0xd5f410: LoadField: r3 = r1->field_3f
    //     0xd5f410: ldur            w3, [x1, #0x3f]
    // 0xd5f414: DecompressPointer r3
    //     0xd5f414: add             x3, x3, HEAP, lsl #32
    // 0xd5f418: stur            x3, [fp, #-0x18]
    // 0xd5f41c: LoadField: r4 = r0->field_b
    //     0xd5f41c: ldur            w4, [x0, #0xb]
    // 0xd5f420: DecompressPointer r4
    //     0xd5f420: add             x4, x4, HEAP, lsl #32
    // 0xd5f424: stur            x4, [fp, #-0x10]
    // 0xd5f428: r0 = KeyedSubtree()
    //     0xd5f428: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xd5f42c: mov             x1, x0
    // 0xd5f430: ldur            x0, [fp, #-0x10]
    // 0xd5f434: stur            x1, [fp, #-0x30]
    // 0xd5f438: StoreField: r1->field_b = r0
    //     0xd5f438: stur            w0, [x1, #0xb]
    // 0xd5f43c: ldur            x0, [fp, #-0x18]
    // 0xd5f440: StoreField: r1->field_7 = r0
    //     0xd5f440: stur            w0, [x1, #7]
    // 0xd5f444: r0 = SlideTransition()
    //     0xd5f444: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xd5f448: mov             x2, x0
    // 0xd5f44c: r0 = true
    //     0xd5f44c: add             x0, NULL, #0x20  ; true
    // 0xd5f450: stur            x2, [fp, #-0x10]
    // 0xd5f454: StoreField: r2->field_13 = r0
    //     0xd5f454: stur            w0, [x2, #0x13]
    // 0xd5f458: ldur            x0, [fp, #-0x30]
    // 0xd5f45c: ArrayStore: r2[0] = r0  ; List_4
    //     0xd5f45c: stur            w0, [x2, #0x17]
    // 0xd5f460: ldur            x0, [fp, #-0x20]
    // 0xd5f464: StoreField: r2->field_b = r0
    //     0xd5f464: stur            w0, [x2, #0xb]
    // 0xd5f468: ldur            x0, [fp, #-0x28]
    // 0xd5f46c: LoadField: r1 = r0->field_1f
    //     0xd5f46c: ldur            w1, [x0, #0x1f]
    // 0xd5f470: DecompressPointer r1
    //     0xd5f470: add             x1, x1, HEAP, lsl #32
    // 0xd5f474: r16 = Instance_DismissDirection
    //     0xd5f474: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f1e8] Obj!DismissDirection@12c33e1
    //     0xd5f478: ldr             x16, [x16, #0x1e8]
    // 0xd5f47c: cmp             w1, w16
    // 0xd5f480: b.ne            #0xd5f494
    // 0xd5f484: mov             x0, x2
    // 0xd5f488: LeaveFrame
    //     0xd5f488: mov             SP, fp
    //     0xd5f48c: ldp             fp, lr, [SP], #0x10
    // 0xd5f490: ret
    //     0xd5f490: ret             
    // 0xd5f494: ldur            x1, [fp, #-8]
    // 0xd5f498: r0 = _directionIsXAxis()
    //     0xd5f498: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f49c: tbnz            w0, #4, #0xd5f4b4
    // 0xd5f4a0: ldur            x2, [fp, #-8]
    // 0xd5f4a4: r1 = Function '_handleDragStart@187238936':.
    //     0xd5f4a4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f1f0] AnonymousClosure: (0xd6091c), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragStart (0xd60958)
    //     0xd5f4a8: ldr             x1, [x1, #0x1f0]
    // 0xd5f4ac: r0 = AllocateClosure()
    //     0xd5f4ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f4b0: b               #0xd5f4b8
    // 0xd5f4b4: r0 = Null
    //     0xd5f4b4: mov             x0, NULL
    // 0xd5f4b8: ldur            x1, [fp, #-8]
    // 0xd5f4bc: stur            x0, [fp, #-0x18]
    // 0xd5f4c0: r0 = _directionIsXAxis()
    //     0xd5f4c0: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f4c4: tbnz            w0, #4, #0xd5f4dc
    // 0xd5f4c8: ldur            x2, [fp, #-8]
    // 0xd5f4cc: r1 = Function '_handleDragUpdate@187238936':.
    //     0xd5f4cc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f1f8] AnonymousClosure: (0xd6030c), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragUpdate (0xd60348)
    //     0xd5f4d0: ldr             x1, [x1, #0x1f8]
    // 0xd5f4d4: r0 = AllocateClosure()
    //     0xd5f4d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f4d8: b               #0xd5f4e0
    // 0xd5f4dc: r0 = Null
    //     0xd5f4dc: mov             x0, NULL
    // 0xd5f4e0: ldur            x1, [fp, #-8]
    // 0xd5f4e4: stur            x0, [fp, #-0x20]
    // 0xd5f4e8: r0 = _directionIsXAxis()
    //     0xd5f4e8: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f4ec: tbnz            w0, #4, #0xd5f504
    // 0xd5f4f0: ldur            x2, [fp, #-8]
    // 0xd5f4f4: r1 = Function '_handleDragEnd@187238936':.
    //     0xd5f4f4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f200] AnonymousClosure: (0xd5f890), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragEnd (0xd5f8cc)
    //     0xd5f4f8: ldr             x1, [x1, #0x200]
    // 0xd5f4fc: r0 = AllocateClosure()
    //     0xd5f4fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f500: b               #0xd5f508
    // 0xd5f504: r0 = Null
    //     0xd5f504: mov             x0, NULL
    // 0xd5f508: ldur            x1, [fp, #-8]
    // 0xd5f50c: stur            x0, [fp, #-0x28]
    // 0xd5f510: r0 = _directionIsXAxis()
    //     0xd5f510: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f514: tbnz            w0, #4, #0xd5f520
    // 0xd5f518: r0 = Null
    //     0xd5f518: mov             x0, NULL
    // 0xd5f51c: b               #0xd5f530
    // 0xd5f520: ldur            x2, [fp, #-8]
    // 0xd5f524: r1 = Function '_handleDragStart@187238936':.
    //     0xd5f524: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f1f0] AnonymousClosure: (0xd6091c), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragStart (0xd60958)
    //     0xd5f528: ldr             x1, [x1, #0x1f0]
    // 0xd5f52c: r0 = AllocateClosure()
    //     0xd5f52c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f530: ldur            x1, [fp, #-8]
    // 0xd5f534: stur            x0, [fp, #-0x30]
    // 0xd5f538: r0 = _directionIsXAxis()
    //     0xd5f538: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f53c: tbnz            w0, #4, #0xd5f548
    // 0xd5f540: r0 = Null
    //     0xd5f540: mov             x0, NULL
    // 0xd5f544: b               #0xd5f558
    // 0xd5f548: ldur            x2, [fp, #-8]
    // 0xd5f54c: r1 = Function '_handleDragUpdate@187238936':.
    //     0xd5f54c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f1f8] AnonymousClosure: (0xd6030c), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragUpdate (0xd60348)
    //     0xd5f550: ldr             x1, [x1, #0x1f8]
    // 0xd5f554: r0 = AllocateClosure()
    //     0xd5f554: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f558: ldur            x1, [fp, #-8]
    // 0xd5f55c: stur            x0, [fp, #-0x38]
    // 0xd5f560: r0 = _directionIsXAxis()
    //     0xd5f560: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f564: tbnz            w0, #4, #0xd5f570
    // 0xd5f568: r1 = Null
    //     0xd5f568: mov             x1, NULL
    // 0xd5f56c: b               #0xd5f584
    // 0xd5f570: ldur            x2, [fp, #-8]
    // 0xd5f574: r1 = Function '_handleDragEnd@187238936':.
    //     0xd5f574: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f200] AnonymousClosure: (0xd5f890), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragEnd (0xd5f8cc)
    //     0xd5f578: ldr             x1, [x1, #0x200]
    // 0xd5f57c: r0 = AllocateClosure()
    //     0xd5f57c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5f580: mov             x1, x0
    // 0xd5f584: ldur            x0, [fp, #-8]
    // 0xd5f588: stur            x1, [fp, #-0x40]
    // 0xd5f58c: LoadField: r2 = r0->field_b
    //     0xd5f58c: ldur            w2, [x0, #0xb]
    // 0xd5f590: DecompressPointer r2
    //     0xd5f590: add             x2, x2, HEAP, lsl #32
    // 0xd5f594: cmp             w2, NULL
    // 0xd5f598: b.eq            #0xd5f610
    // 0xd5f59c: r0 = GestureDetector()
    //     0xd5f59c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd5f5a0: stur            x0, [fp, #-8]
    // 0xd5f5a4: ldur            x16, [fp, #-0x18]
    // 0xd5f5a8: ldur            lr, [fp, #-0x20]
    // 0xd5f5ac: stp             lr, x16, [SP, #0x30]
    // 0xd5f5b0: ldur            x16, [fp, #-0x28]
    // 0xd5f5b4: ldur            lr, [fp, #-0x30]
    // 0xd5f5b8: stp             lr, x16, [SP, #0x20]
    // 0xd5f5bc: ldur            x16, [fp, #-0x38]
    // 0xd5f5c0: ldur            lr, [fp, #-0x40]
    // 0xd5f5c4: stp             lr, x16, [SP, #0x10]
    // 0xd5f5c8: r16 = Instance_HitTestBehavior
    //     0xd5f5c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xd5f5cc: ldr             x16, [x16, #0x5c0]
    // 0xd5f5d0: ldur            lr, [fp, #-0x10]
    // 0xd5f5d4: stp             lr, x16, [SP]
    // 0xd5f5d8: mov             x1, x0
    // 0xd5f5dc: r4 = const [0, 0x9, 0x8, 0x1, behavior, 0x7, child, 0x8, onHorizontalDragEnd, 0x3, onHorizontalDragStart, 0x1, onHorizontalDragUpdate, 0x2, onVerticalDragEnd, 0x6, onVerticalDragStart, 0x4, onVerticalDragUpdate, 0x5, null]
    //     0xd5f5dc: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f208] List(21) [0, 0x9, 0x8, 0x1, "behavior", 0x7, "child", 0x8, "onHorizontalDragEnd", 0x3, "onHorizontalDragStart", 0x1, "onHorizontalDragUpdate", 0x2, "onVerticalDragEnd", 0x6, "onVerticalDragStart", 0x4, "onVerticalDragUpdate", 0x5, Null]
    //     0xd5f5e0: ldr             x4, [x4, #0x208]
    // 0xd5f5e4: r0 = GestureDetector()
    //     0xd5f5e4: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd5f5e8: ldur            x0, [fp, #-8]
    // 0xd5f5ec: LeaveFrame
    //     0xd5f5ec: mov             SP, fp
    //     0xd5f5f0: ldp             fp, lr, [SP], #0x10
    // 0xd5f5f4: ret
    //     0xd5f5f4: ret             
    // 0xd5f5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5f5f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5f5fc: b               #0xd5f3d8
    // 0xd5f600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5f600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5f604: r9 = _moveAnimation
    //     0xd5f604: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f210] Field <_DismissibleState@187238936._moveAnimation@187238936>: late (offset: 0x24)
    //     0xd5f608: ldr             x9, [x9, #0x210]
    // 0xd5f60c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5f60c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5f610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5f610: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _directionIsXAxis(/* No info */) {
    // ** addr: 0xd5f614, size: 0x6c
    // 0xd5f614: LoadField: r2 = r1->field_b
    //     0xd5f614: ldur            w2, [x1, #0xb]
    // 0xd5f618: DecompressPointer r2
    //     0xd5f618: add             x2, x2, HEAP, lsl #32
    // 0xd5f61c: cmp             w2, NULL
    // 0xd5f620: b.eq            #0xd5f674
    // 0xd5f624: LoadField: r1 = r2->field_1f
    //     0xd5f624: ldur            w1, [x2, #0x1f]
    // 0xd5f628: DecompressPointer r1
    //     0xd5f628: add             x1, x1, HEAP, lsl #32
    // 0xd5f62c: r16 = Instance_DismissDirection
    //     0xd5f62c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f268] Obj!DismissDirection@12c3381
    //     0xd5f630: ldr             x16, [x16, #0x268]
    // 0xd5f634: cmp             w1, w16
    // 0xd5f638: b.eq            #0xd5f64c
    // 0xd5f63c: r16 = Instance_DismissDirection
    //     0xd5f63c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f230] Obj!DismissDirection@12c33c1
    //     0xd5f640: ldr             x16, [x16, #0x230]
    // 0xd5f644: cmp             w1, w16
    // 0xd5f648: b.ne            #0xd5f654
    // 0xd5f64c: r0 = true
    //     0xd5f64c: add             x0, NULL, #0x20  ; true
    // 0xd5f650: b               #0xd5f670
    // 0xd5f654: r16 = Instance_DismissDirection
    //     0xd5f654: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f228] Obj!DismissDirection@12c33a1
    //     0xd5f658: ldr             x16, [x16, #0x228]
    // 0xd5f65c: cmp             w1, w16
    // 0xd5f660: r16 = true
    //     0xd5f660: add             x16, NULL, #0x20  ; true
    // 0xd5f664: r17 = false
    //     0xd5f664: add             x17, NULL, #0x30  ; false
    // 0xd5f668: csel            x2, x16, x17, eq
    // 0xd5f66c: mov             x0, x2
    // 0xd5f670: ret
    //     0xd5f670: ret             
    // 0xd5f674: EnterFrame
    //     0xd5f674: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f678: mov             fp, SP
    // 0xd5f67c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5f67c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ wantKeepAlive(/* No info */) {
    // ** addr: 0xd5f7a8, size: 0x74
    // 0xd5f7a8: EnterFrame
    //     0xd5f7a8: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f7ac: mov             fp, SP
    // 0xd5f7b0: CheckStackOverflow
    //     0xd5f7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5f7b4: cmp             SP, x16
    //     0xd5f7b8: b.ls            #0xd5f814
    // 0xd5f7bc: LoadField: r0 = r1->field_1f
    //     0xd5f7bc: ldur            w0, [x1, #0x1f]
    // 0xd5f7c0: DecompressPointer r0
    //     0xd5f7c0: add             x0, x0, HEAP, lsl #32
    // 0xd5f7c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5f7c8: cmp             w0, w16
    // 0xd5f7cc: b.ne            #0xd5f7dc
    // 0xd5f7d0: r2 = _moveController
    //     0xd5f7d0: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd5f7d4: ldr             x2, [x2, #0x218]
    // 0xd5f7d8: r0 = InitLateFinalInstanceField()
    //     0xd5f7d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd5f7dc: LoadField: r1 = r0->field_2f
    //     0xd5f7dc: ldur            w1, [x0, #0x2f]
    // 0xd5f7e0: DecompressPointer r1
    //     0xd5f7e0: add             x1, x1, HEAP, lsl #32
    // 0xd5f7e4: cmp             w1, NULL
    // 0xd5f7e8: b.eq            #0xd5f804
    // 0xd5f7ec: LoadField: r2 = r1->field_7
    //     0xd5f7ec: ldur            w2, [x1, #7]
    // 0xd5f7f0: DecompressPointer r2
    //     0xd5f7f0: add             x2, x2, HEAP, lsl #32
    // 0xd5f7f4: cmp             w2, NULL
    // 0xd5f7f8: b.eq            #0xd5f804
    // 0xd5f7fc: r0 = true
    //     0xd5f7fc: add             x0, NULL, #0x20  ; true
    // 0xd5f800: b               #0xd5f808
    // 0xd5f804: r0 = false
    //     0xd5f804: add             x0, NULL, #0x30  ; false
    // 0xd5f808: LeaveFrame
    //     0xd5f808: mov             SP, fp
    //     0xd5f80c: ldp             fp, lr, [SP], #0x10
    // 0xd5f810: ret
    //     0xd5f810: ret             
    // 0xd5f814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5f814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5f818: b               #0xd5f7bc
  }
  AnimationController _moveController(_DismissibleState) {
    // ** addr: 0xd5f81c, size: 0x74
    // 0xd5f81c: EnterFrame
    //     0xd5f81c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f820: mov             fp, SP
    // 0xd5f824: AllocStack(0x10)
    //     0xd5f824: sub             SP, SP, #0x10
    // 0xd5f828: CheckStackOverflow
    //     0xd5f828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5f82c: cmp             SP, x16
    //     0xd5f830: b.ls            #0xd5f884
    // 0xd5f834: ldr             x2, [fp, #0x10]
    // 0xd5f838: LoadField: r0 = r2->field_b
    //     0xd5f838: ldur            w0, [x2, #0xb]
    // 0xd5f83c: DecompressPointer r0
    //     0xd5f83c: add             x0, x0, HEAP, lsl #32
    // 0xd5f840: cmp             w0, NULL
    // 0xd5f844: b.eq            #0xd5f88c
    // 0xd5f848: r1 = <double>
    //     0xd5f848: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd5f84c: r0 = AnimationController()
    //     0xd5f84c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd5f850: stur            x0, [fp, #-8]
    // 0xd5f854: r16 = Instance_Duration
    //     0xd5f854: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd5f858: ldr             x16, [x16, #0x318]
    // 0xd5f85c: str             x16, [SP]
    // 0xd5f860: mov             x1, x0
    // 0xd5f864: ldr             x2, [fp, #0x10]
    // 0xd5f868: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd5f868: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd5f86c: ldr             x4, [x4, #0x5a0]
    // 0xd5f870: r0 = AnimationController()
    //     0xd5f870: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd5f874: ldur            x0, [fp, #-8]
    // 0xd5f878: LeaveFrame
    //     0xd5f878: mov             SP, fp
    //     0xd5f87c: ldp             fp, lr, [SP], #0x10
    // 0xd5f880: ret
    //     0xd5f880: ret             
    // 0xd5f884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5f884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5f888: b               #0xd5f834
    // 0xd5f88c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5f88c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0xd5f890, size: 0x3c
    // 0xd5f890: EnterFrame
    //     0xd5f890: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f894: mov             fp, SP
    // 0xd5f898: ldr             x0, [fp, #0x18]
    // 0xd5f89c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5f89c: ldur            w1, [x0, #0x17]
    // 0xd5f8a0: DecompressPointer r1
    //     0xd5f8a0: add             x1, x1, HEAP, lsl #32
    // 0xd5f8a4: CheckStackOverflow
    //     0xd5f8a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5f8a8: cmp             SP, x16
    //     0xd5f8ac: b.ls            #0xd5f8c4
    // 0xd5f8b0: ldr             x2, [fp, #0x10]
    // 0xd5f8b4: r0 = _handleDragEnd()
    //     0xd5f8b4: bl              #0xd5f8cc  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragEnd
    // 0xd5f8b8: LeaveFrame
    //     0xd5f8b8: mov             SP, fp
    //     0xd5f8bc: ldp             fp, lr, [SP], #0x10
    // 0xd5f8c0: ret
    //     0xd5f8c0: ret             
    // 0xd5f8c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5f8c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5f8c8: b               #0xd5f8b0
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xd5f8cc, size: 0x3a0
    // 0xd5f8cc: EnterFrame
    //     0xd5f8cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5f8d0: mov             fp, SP
    // 0xd5f8d4: AllocStack(0x20)
    //     0xd5f8d4: sub             SP, SP, #0x20
    // 0xd5f8d8: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd5f8d8: mov             x0, x1
    //     0xd5f8dc: stur            x1, [fp, #-8]
    //     0xd5f8e0: stur            x2, [fp, #-0x10]
    // 0xd5f8e4: CheckStackOverflow
    //     0xd5f8e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5f8e8: cmp             SP, x16
    //     0xd5f8ec: b.ls            #0xd5fc1c
    // 0xd5f8f0: LoadField: r1 = r0->field_3b
    //     0xd5f8f0: ldur            w1, [x0, #0x3b]
    // 0xd5f8f4: DecompressPointer r1
    //     0xd5f8f4: add             x1, x1, HEAP, lsl #32
    // 0xd5f8f8: tbnz            w1, #4, #0xd5f940
    // 0xd5f8fc: mov             x1, x0
    // 0xd5f900: LoadField: r0 = r1->field_1f
    //     0xd5f900: ldur            w0, [x1, #0x1f]
    // 0xd5f904: DecompressPointer r0
    //     0xd5f904: add             x0, x0, HEAP, lsl #32
    // 0xd5f908: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5f90c: cmp             w0, w16
    // 0xd5f910: b.ne            #0xd5f920
    // 0xd5f914: r2 = _moveController
    //     0xd5f914: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd5f918: ldr             x2, [x2, #0x218]
    // 0xd5f91c: r0 = InitLateFinalInstanceField()
    //     0xd5f91c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd5f920: LoadField: r1 = r0->field_2f
    //     0xd5f920: ldur            w1, [x0, #0x2f]
    // 0xd5f924: DecompressPointer r1
    //     0xd5f924: add             x1, x1, HEAP, lsl #32
    // 0xd5f928: cmp             w1, NULL
    // 0xd5f92c: b.eq            #0xd5f950
    // 0xd5f930: LoadField: r2 = r1->field_7
    //     0xd5f930: ldur            w2, [x1, #7]
    // 0xd5f934: DecompressPointer r2
    //     0xd5f934: add             x2, x2, HEAP, lsl #32
    // 0xd5f938: cmp             w2, NULL
    // 0xd5f93c: b.eq            #0xd5f950
    // 0xd5f940: r0 = Null
    //     0xd5f940: mov             x0, NULL
    // 0xd5f944: LeaveFrame
    //     0xd5f944: mov             SP, fp
    //     0xd5f948: ldp             fp, lr, [SP], #0x10
    // 0xd5f94c: ret
    //     0xd5f94c: ret             
    // 0xd5f950: ldur            x2, [fp, #-8]
    // 0xd5f954: r1 = false
    //     0xd5f954: add             x1, NULL, #0x30  ; false
    // 0xd5f958: StoreField: r2->field_3b = r1
    //     0xd5f958: stur            w1, [x2, #0x3b]
    // 0xd5f95c: LoadField: r1 = r0->field_43
    //     0xd5f95c: ldur            w1, [x0, #0x43]
    // 0xd5f960: DecompressPointer r1
    //     0xd5f960: add             x1, x1, HEAP, lsl #32
    // 0xd5f964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5f968: cmp             w1, w16
    // 0xd5f96c: b.eq            #0xd5fc24
    // 0xd5f970: r16 = Instance_AnimationStatus
    //     0xd5f970: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd5f974: cmp             w1, w16
    // 0xd5f978: b.ne            #0xd5f994
    // 0xd5f97c: mov             x1, x2
    // 0xd5f980: r0 = _handleMoveCompleted()
    //     0xd5f980: bl              #0xd6007c  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleMoveCompleted
    // 0xd5f984: r0 = Null
    //     0xd5f984: mov             x0, NULL
    // 0xd5f988: LeaveFrame
    //     0xd5f988: mov             SP, fp
    //     0xd5f98c: ldp             fp, lr, [SP], #0x10
    // 0xd5f990: ret
    //     0xd5f990: ret             
    // 0xd5f994: mov             x1, x2
    // 0xd5f998: r0 = _directionIsXAxis()
    //     0xd5f998: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5f99c: tbnz            w0, #4, #0xd5f9c0
    // 0xd5f9a0: ldur            x0, [fp, #-0x10]
    // 0xd5f9a4: LoadField: r1 = r0->field_b
    //     0xd5f9a4: ldur            w1, [x0, #0xb]
    // 0xd5f9a8: DecompressPointer r1
    //     0xd5f9a8: add             x1, x1, HEAP, lsl #32
    // 0xd5f9ac: LoadField: r0 = r1->field_7
    //     0xd5f9ac: ldur            w0, [x1, #7]
    // 0xd5f9b0: DecompressPointer r0
    //     0xd5f9b0: add             x0, x0, HEAP, lsl #32
    // 0xd5f9b4: LoadField: d0 = r0->field_7
    //     0xd5f9b4: ldur            d0, [x0, #7]
    // 0xd5f9b8: mov             x2, x1
    // 0xd5f9bc: b               #0xd5f9dc
    // 0xd5f9c0: ldur            x0, [fp, #-0x10]
    // 0xd5f9c4: LoadField: r1 = r0->field_b
    //     0xd5f9c4: ldur            w1, [x0, #0xb]
    // 0xd5f9c8: DecompressPointer r1
    //     0xd5f9c8: add             x1, x1, HEAP, lsl #32
    // 0xd5f9cc: LoadField: r0 = r1->field_7
    //     0xd5f9cc: ldur            w0, [x1, #7]
    // 0xd5f9d0: DecompressPointer r0
    //     0xd5f9d0: add             x0, x0, HEAP, lsl #32
    // 0xd5f9d4: LoadField: d0 = r0->field_f
    //     0xd5f9d4: ldur            d0, [x0, #0xf]
    // 0xd5f9d8: mov             x2, x1
    // 0xd5f9dc: ldur            x1, [fp, #-8]
    // 0xd5f9e0: stur            d0, [fp, #-0x18]
    // 0xd5f9e4: r0 = _describeFlingGesture()
    //     0xd5f9e4: bl              #0xd5fe38  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_describeFlingGesture
    // 0xd5f9e8: LoadField: r1 = r0->field_7
    //     0xd5f9e8: ldur            x1, [x0, #7]
    // 0xd5f9ec: cmp             x1, #1
    // 0xd5f9f0: b.gt            #0xd5fb64
    // 0xd5f9f4: cmp             x1, #0
    // 0xd5f9f8: b.gt            #0xd5fa88
    // 0xd5f9fc: ldur            x0, [fp, #-8]
    // 0xd5fa00: LoadField: r1 = r0->field_1f
    //     0xd5fa00: ldur            w1, [x0, #0x1f]
    // 0xd5fa04: DecompressPointer r1
    //     0xd5fa04: add             x1, x1, HEAP, lsl #32
    // 0xd5fa08: LoadField: r2 = r1->field_43
    //     0xd5fa08: ldur            w2, [x1, #0x43]
    // 0xd5fa0c: DecompressPointer r2
    //     0xd5fa0c: add             x2, x2, HEAP, lsl #32
    // 0xd5fa10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5fa14: cmp             w2, w16
    // 0xd5fa18: b.eq            #0xd5fc2c
    // 0xd5fa1c: r16 = Instance_AnimationStatus
    //     0xd5fa1c: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd5fa20: cmp             w2, w16
    // 0xd5fa24: b.eq            #0xd5fc0c
    // 0xd5fa28: LoadField: r2 = r1->field_37
    //     0xd5fa28: ldur            w2, [x1, #0x37]
    // 0xd5fa2c: DecompressPointer r2
    //     0xd5fa2c: add             x2, x2, HEAP, lsl #32
    // 0xd5fa30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd5fa34: cmp             w2, w16
    // 0xd5fa38: b.eq            #0xd5fc34
    // 0xd5fa3c: mov             x1, x0
    // 0xd5fa40: stur            x2, [fp, #-0x10]
    // 0xd5fa44: r0 = _dismissThreshold()
    //     0xd5fa44: bl              #0xd5fc6c  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_dismissThreshold
    // 0xd5fa48: ldur            x0, [fp, #-0x10]
    // 0xd5fa4c: LoadField: d1 = r0->field_7
    //     0xd5fa4c: ldur            d1, [x0, #7]
    // 0xd5fa50: fcmp            d1, d0
    // 0xd5fa54: b.le            #0xd5fa70
    // 0xd5fa58: ldur            x0, [fp, #-8]
    // 0xd5fa5c: LoadField: r1 = r0->field_1f
    //     0xd5fa5c: ldur            w1, [x0, #0x1f]
    // 0xd5fa60: DecompressPointer r1
    //     0xd5fa60: add             x1, x1, HEAP, lsl #32
    // 0xd5fa64: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd5fa64: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd5fa68: r0 = forward()
    //     0xd5fa68: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd5fa6c: b               #0xd5fc0c
    // 0xd5fa70: ldur            x0, [fp, #-8]
    // 0xd5fa74: LoadField: r1 = r0->field_1f
    //     0xd5fa74: ldur            w1, [x0, #0x1f]
    // 0xd5fa78: DecompressPointer r1
    //     0xd5fa78: add             x1, x1, HEAP, lsl #32
    // 0xd5fa7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd5fa7c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd5fa80: r0 = reverse()
    //     0xd5fa80: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd5fa84: b               #0xd5fc0c
    // 0xd5fa88: ldur            x0, [fp, #-8]
    // 0xd5fa8c: mov             x1, x0
    // 0xd5fa90: r0 = _dismissThreshold()
    //     0xd5fa90: bl              #0xd5fc6c  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_dismissThreshold
    // 0xd5fa94: mov             v1.16b, v0.16b
    // 0xd5fa98: d0 = 1.000000
    //     0xd5fa98: fmov            d0, #1.00000000
    // 0xd5fa9c: fcmp            d1, d0
    // 0xd5faa0: b.lt            #0xd5fabc
    // 0xd5faa4: ldur            x0, [fp, #-8]
    // 0xd5faa8: LoadField: r1 = r0->field_1f
    //     0xd5faa8: ldur            w1, [x0, #0x1f]
    // 0xd5faac: DecompressPointer r1
    //     0xd5faac: add             x1, x1, HEAP, lsl #32
    // 0xd5fab0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd5fab0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd5fab4: r0 = reverse()
    //     0xd5fab4: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd5fab8: b               #0xd5fc0c
    // 0xd5fabc: ldur            x0, [fp, #-8]
    // 0xd5fac0: ldur            d0, [fp, #-0x18]
    // 0xd5fac4: d1 = 0.000000
    //     0xd5fac4: eor             v1.16b, v1.16b, v1.16b
    // 0xd5fac8: fcmp            d0, d1
    // 0xd5facc: b.le            #0xd5fad8
    // 0xd5fad0: d2 = 1.000000
    //     0xd5fad0: fmov            d2, #1.00000000
    // 0xd5fad4: b               #0xd5faec
    // 0xd5fad8: fcmp            d1, d0
    // 0xd5fadc: b.le            #0xd5fae8
    // 0xd5fae0: d2 = -1.000000
    //     0xd5fae0: fmov            d2, #-1.00000000
    // 0xd5fae4: b               #0xd5faec
    // 0xd5fae8: mov             v2.16b, v0.16b
    // 0xd5faec: StoreField: r0->field_2f = d2
    //     0xd5faec: stur            d2, [x0, #0x2f]
    // 0xd5faf0: LoadField: r1 = r0->field_1f
    //     0xd5faf0: ldur            w1, [x0, #0x1f]
    // 0xd5faf4: DecompressPointer r1
    //     0xd5faf4: add             x1, x1, HEAP, lsl #32
    // 0xd5faf8: fcmp            d0, d1
    // 0xd5fafc: b.ne            #0xd5fb08
    // 0xd5fb00: d0 = 0.000000
    //     0xd5fb00: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fb04: b               #0xd5fb18
    // 0xd5fb08: fcmp            d1, d0
    // 0xd5fb0c: b.le            #0xd5fb18
    // 0xd5fb10: fneg            d1, d0
    // 0xd5fb14: mov             v0.16b, v1.16b
    // 0xd5fb18: d2 = 0.003333
    //     0xd5fb18: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f220] IMM: double(0.0033333333333333335) from 0x3f6b4e81b4e81b4f
    //     0xd5fb1c: ldr             d2, [x17, #0x220]
    // 0xd5fb20: fmul            d1, d0, d2
    // 0xd5fb24: r0 = inline_Allocate_Double()
    //     0xd5fb24: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd5fb28: add             x0, x0, #0x10
    //     0xd5fb2c: cmp             x2, x0
    //     0xd5fb30: b.ls            #0xd5fc3c
    //     0xd5fb34: str             x0, [THR, #0x60]  ; THR::top
    //     0xd5fb38: sub             x0, x0, #0xf
    //     0xd5fb3c: mov             x2, #0xe19c
    //     0xd5fb40: movk            x2, #3, lsl #16
    //     0xd5fb44: stur            x2, [x0, #-1]
    // 0xd5fb48: dmb             ishst
    // 0xd5fb4c: StoreField: r0->field_7 = d1
    //     0xd5fb4c: stur            d1, [x0, #7]
    // 0xd5fb50: str             x0, [SP]
    // 0xd5fb54: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xd5fb54: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xd5fb58: ldr             x4, [x4, #0x820]
    // 0xd5fb5c: r0 = fling()
    //     0xd5fb5c: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xd5fb60: b               #0xd5fc0c
    // 0xd5fb64: ldur            x0, [fp, #-8]
    // 0xd5fb68: ldur            d0, [fp, #-0x18]
    // 0xd5fb6c: d1 = 0.000000
    //     0xd5fb6c: eor             v1.16b, v1.16b, v1.16b
    // 0xd5fb70: d2 = 0.003333
    //     0xd5fb70: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f220] IMM: double(0.0033333333333333335) from 0x3f6b4e81b4e81b4f
    //     0xd5fb74: ldr             d2, [x17, #0x220]
    // 0xd5fb78: fcmp            d0, d1
    // 0xd5fb7c: b.le            #0xd5fb88
    // 0xd5fb80: d3 = 1.000000
    //     0xd5fb80: fmov            d3, #1.00000000
    // 0xd5fb84: b               #0xd5fb9c
    // 0xd5fb88: fcmp            d1, d0
    // 0xd5fb8c: b.le            #0xd5fb98
    // 0xd5fb90: d3 = -1.000000
    //     0xd5fb90: fmov            d3, #-1.00000000
    // 0xd5fb94: b               #0xd5fb9c
    // 0xd5fb98: mov             v3.16b, v0.16b
    // 0xd5fb9c: StoreField: r0->field_2f = d3
    //     0xd5fb9c: stur            d3, [x0, #0x2f]
    // 0xd5fba0: LoadField: r1 = r0->field_1f
    //     0xd5fba0: ldur            w1, [x0, #0x1f]
    // 0xd5fba4: DecompressPointer r1
    //     0xd5fba4: add             x1, x1, HEAP, lsl #32
    // 0xd5fba8: fcmp            d0, d1
    // 0xd5fbac: b.ne            #0xd5fbb8
    // 0xd5fbb0: d0 = 0.000000
    //     0xd5fbb0: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fbb4: b               #0xd5fbc8
    // 0xd5fbb8: fcmp            d1, d0
    // 0xd5fbbc: b.le            #0xd5fbc8
    // 0xd5fbc0: fneg            d1, d0
    // 0xd5fbc4: mov             v0.16b, v1.16b
    // 0xd5fbc8: fneg            d1, d0
    // 0xd5fbcc: fmul            d0, d1, d2
    // 0xd5fbd0: r0 = inline_Allocate_Double()
    //     0xd5fbd0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd5fbd4: add             x0, x0, #0x10
    //     0xd5fbd8: cmp             x2, x0
    //     0xd5fbdc: b.ls            #0xd5fc54
    //     0xd5fbe0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd5fbe4: sub             x0, x0, #0xf
    //     0xd5fbe8: mov             x2, #0xe19c
    //     0xd5fbec: movk            x2, #3, lsl #16
    //     0xd5fbf0: stur            x2, [x0, #-1]
    // 0xd5fbf4: dmb             ishst
    // 0xd5fbf8: StoreField: r0->field_7 = d0
    //     0xd5fbf8: stur            d0, [x0, #7]
    // 0xd5fbfc: str             x0, [SP]
    // 0xd5fc00: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xd5fc00: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xd5fc04: ldr             x4, [x4, #0x820]
    // 0xd5fc08: r0 = fling()
    //     0xd5fc08: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xd5fc0c: r0 = Null
    //     0xd5fc0c: mov             x0, NULL
    // 0xd5fc10: LeaveFrame
    //     0xd5fc10: mov             SP, fp
    //     0xd5fc14: ldp             fp, lr, [SP], #0x10
    // 0xd5fc18: ret
    //     0xd5fc18: ret             
    // 0xd5fc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5fc1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5fc20: b               #0xd5f8f0
    // 0xd5fc24: r9 = _status
    //     0xd5fc24: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd5fc28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5fc28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5fc2c: r9 = _status
    //     0xd5fc2c: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd5fc30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5fc30: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5fc34: r9 = _value
    //     0xd5fc34: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd5fc38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd5fc38: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd5fc3c: SaveReg d1
    //     0xd5fc3c: str             q1, [SP, #-0x10]!
    // 0xd5fc40: SaveReg r1
    //     0xd5fc40: str             x1, [SP, #-8]!
    // 0xd5fc44: r0 = AllocateDouble()
    //     0xd5fc44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd5fc48: RestoreReg r1
    //     0xd5fc48: ldr             x1, [SP], #8
    // 0xd5fc4c: RestoreReg d1
    //     0xd5fc4c: ldr             q1, [SP], #0x10
    // 0xd5fc50: b               #0xd5fb4c
    // 0xd5fc54: SaveReg d0
    //     0xd5fc54: str             q0, [SP, #-0x10]!
    // 0xd5fc58: SaveReg r1
    //     0xd5fc58: str             x1, [SP, #-8]!
    // 0xd5fc5c: r0 = AllocateDouble()
    //     0xd5fc5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd5fc60: RestoreReg r1
    //     0xd5fc60: ldr             x1, [SP], #8
    // 0xd5fc64: RestoreReg d0
    //     0xd5fc64: ldr             q0, [SP], #0x10
    // 0xd5fc68: b               #0xd5fbf8
  }
  get _ _dismissThreshold(/* No info */) {
    // ** addr: 0xd5fc6c, size: 0x6c
    // 0xd5fc6c: EnterFrame
    //     0xd5fc6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5fc70: mov             fp, SP
    // 0xd5fc74: CheckStackOverflow
    //     0xd5fc74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5fc78: cmp             SP, x16
    //     0xd5fc7c: b.ls            #0xd5fccc
    // 0xd5fc80: LoadField: r0 = r1->field_b
    //     0xd5fc80: ldur            w0, [x1, #0xb]
    // 0xd5fc84: DecompressPointer r0
    //     0xd5fc84: add             x0, x0, HEAP, lsl #32
    // 0xd5fc88: cmp             w0, NULL
    // 0xd5fc8c: b.eq            #0xd5fcd4
    // 0xd5fc90: r0 = _dismissDirection()
    //     0xd5fc90: bl              #0xd5fcd8  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_dismissDirection
    // 0xd5fc94: mov             x2, x0
    // 0xd5fc98: r1 = _ConstMap len:0
    //     0xd5fc98: add             x1, PP, #0x16, lsl #12  ; [pp+0x16e68] Map<DismissDirection, double>(0)
    //     0xd5fc9c: ldr             x1, [x1, #0xe68]
    // 0xd5fca0: r0 = []()
    //     0xd5fca0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd5fca4: cmp             w0, NULL
    // 0xd5fca8: b.ne            #0xd5fcb8
    // 0xd5fcac: d0 = 0.400000
    //     0xd5fcac: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd5fcb0: ldr             d0, [x17, #0x368]
    // 0xd5fcb4: b               #0xd5fcc0
    // 0xd5fcb8: LoadField: d1 = r0->field_7
    //     0xd5fcb8: ldur            d1, [x0, #7]
    // 0xd5fcbc: mov             v0.16b, v1.16b
    // 0xd5fcc0: LeaveFrame
    //     0xd5fcc0: mov             SP, fp
    //     0xd5fcc4: ldp             fp, lr, [SP], #0x10
    // 0xd5fcc8: ret
    //     0xd5fcc8: ret             
    // 0xd5fccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5fccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5fcd0: b               #0xd5fc80
    // 0xd5fcd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5fcd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _dismissDirection(/* No info */) {
    // ** addr: 0xd5fcd8, size: 0x30
    // 0xd5fcd8: EnterFrame
    //     0xd5fcd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd5fcdc: mov             fp, SP
    // 0xd5fce0: CheckStackOverflow
    //     0xd5fce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5fce4: cmp             SP, x16
    //     0xd5fce8: b.ls            #0xd5fd00
    // 0xd5fcec: LoadField: d0 = r1->field_2f
    //     0xd5fcec: ldur            d0, [x1, #0x2f]
    // 0xd5fcf0: r0 = _extentToDirection()
    //     0xd5fcf0: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd5fcf4: LeaveFrame
    //     0xd5fcf4: mov             SP, fp
    //     0xd5fcf8: ldp             fp, lr, [SP], #0x10
    // 0xd5fcfc: ret
    //     0xd5fcfc: ret             
    // 0xd5fd00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5fd00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5fd04: b               #0xd5fcec
  }
  _ _extentToDirection(/* No info */) {
    // ** addr: 0xd5fd08, size: 0x130
    // 0xd5fd08: EnterFrame
    //     0xd5fd08: stp             fp, lr, [SP, #-0x10]!
    //     0xd5fd0c: mov             fp, SP
    // 0xd5fd10: AllocStack(0x10)
    //     0xd5fd10: sub             SP, SP, #0x10
    // 0xd5fd14: d1 = 0.000000
    //     0xd5fd14: eor             v1.16b, v1.16b, v1.16b
    // 0xd5fd18: mov             x0, x1
    // 0xd5fd1c: stur            x1, [fp, #-8]
    // 0xd5fd20: stur            d0, [fp, #-0x10]
    // 0xd5fd24: CheckStackOverflow
    //     0xd5fd24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5fd28: cmp             SP, x16
    //     0xd5fd2c: b.ls            #0xd5fe2c
    // 0xd5fd30: fcmp            d0, d1
    // 0xd5fd34: b.ne            #0xd5fd4c
    // 0xd5fd38: r0 = Instance_DismissDirection
    //     0xd5fd38: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f1e8] Obj!DismissDirection@12c33e1
    //     0xd5fd3c: ldr             x0, [x0, #0x1e8]
    // 0xd5fd40: LeaveFrame
    //     0xd5fd40: mov             SP, fp
    //     0xd5fd44: ldp             fp, lr, [SP], #0x10
    // 0xd5fd48: ret
    //     0xd5fd48: ret             
    // 0xd5fd4c: mov             x1, x0
    // 0xd5fd50: r0 = _directionIsXAxis()
    //     0xd5fd50: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5fd54: tbnz            w0, #4, #0xd5fdfc
    // 0xd5fd58: ldur            x0, [fp, #-8]
    // 0xd5fd5c: LoadField: r1 = r0->field_f
    //     0xd5fd5c: ldur            w1, [x0, #0xf]
    // 0xd5fd60: DecompressPointer r1
    //     0xd5fd60: add             x1, x1, HEAP, lsl #32
    // 0xd5fd64: cmp             w1, NULL
    // 0xd5fd68: b.eq            #0xd5fe34
    // 0xd5fd6c: r0 = of()
    //     0xd5fd6c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd5fd70: r16 = Instance_TextDirection
    //     0xd5fd70: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xd5fd74: cmp             w0, w16
    // 0xd5fd78: r16 = true
    //     0xd5fd78: add             x16, NULL, #0x20  ; true
    // 0xd5fd7c: r17 = false
    //     0xd5fd7c: add             x17, NULL, #0x30  ; false
    // 0xd5fd80: csel            x1, x16, x17, eq
    // 0xd5fd84: tbnz            w1, #4, #0xd5fda4
    // 0xd5fd88: ldur            d1, [fp, #-0x10]
    // 0xd5fd8c: d0 = 0.000000
    //     0xd5fd8c: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fd90: fcmp            d0, d1
    // 0xd5fd94: b.le            #0xd5fdac
    // 0xd5fd98: r0 = Instance_DismissDirection
    //     0xd5fd98: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f228] Obj!DismissDirection@12c33a1
    //     0xd5fd9c: ldr             x0, [x0, #0x228]
    // 0xd5fda0: b               #0xd5fdf0
    // 0xd5fda4: ldur            d1, [fp, #-0x10]
    // 0xd5fda8: d0 = 0.000000
    //     0xd5fda8: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fdac: r16 = Instance_TextDirection
    //     0xd5fdac: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xd5fdb0: cmp             w0, w16
    // 0xd5fdb4: r16 = true
    //     0xd5fdb4: add             x16, NULL, #0x20  ; true
    // 0xd5fdb8: r17 = false
    //     0xd5fdb8: add             x17, NULL, #0x30  ; false
    // 0xd5fdbc: csel            x2, x16, x17, eq
    // 0xd5fdc0: tbnz            w2, #4, #0xd5fdd8
    // 0xd5fdc4: fcmp            d1, d0
    // 0xd5fdc8: b.le            #0xd5fdd8
    // 0xd5fdcc: r0 = Instance_DismissDirection
    //     0xd5fdcc: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f228] Obj!DismissDirection@12c33a1
    //     0xd5fdd0: ldr             x0, [x0, #0x228]
    // 0xd5fdd4: b               #0xd5fdf0
    // 0xd5fdd8: tbz             w1, #4, #0xd5fde0
    // 0xd5fddc: tbnz            w2, #4, #0xd5fdec
    // 0xd5fde0: r0 = Instance_DismissDirection
    //     0xd5fde0: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f230] Obj!DismissDirection@12c33c1
    //     0xd5fde4: ldr             x0, [x0, #0x230]
    // 0xd5fde8: b               #0xd5fdf0
    // 0xd5fdec: r0 = Null
    //     0xd5fdec: mov             x0, NULL
    // 0xd5fdf0: LeaveFrame
    //     0xd5fdf0: mov             SP, fp
    //     0xd5fdf4: ldp             fp, lr, [SP], #0x10
    // 0xd5fdf8: ret
    //     0xd5fdf8: ret             
    // 0xd5fdfc: ldur            d1, [fp, #-0x10]
    // 0xd5fe00: d0 = 0.000000
    //     0xd5fe00: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fe04: fcmp            d1, d0
    // 0xd5fe08: b.le            #0xd5fe18
    // 0xd5fe0c: r0 = Instance_DismissDirection
    //     0xd5fe0c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16e50] Obj!DismissDirection@12c3341
    //     0xd5fe10: ldr             x0, [x0, #0xe50]
    // 0xd5fe14: b               #0xd5fe20
    // 0xd5fe18: r0 = Instance_DismissDirection
    //     0xd5fe18: add             x0, PP, #0x16, lsl #12  ; [pp+0x16e48] Obj!DismissDirection@12c3361
    //     0xd5fe1c: ldr             x0, [x0, #0xe48]
    // 0xd5fe20: LeaveFrame
    //     0xd5fe20: mov             SP, fp
    //     0xd5fe24: ldp             fp, lr, [SP], #0x10
    // 0xd5fe28: ret
    //     0xd5fe28: ret             
    // 0xd5fe2c: r0 = StackOverflowSharedWithFPURegs()
    //     0xd5fe2c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd5fe30: b               #0xd5fd30
    // 0xd5fe34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5fe34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _describeFlingGesture(/* No info */) {
    // ** addr: 0xd5fe38, size: 0x244
    // 0xd5fe38: EnterFrame
    //     0xd5fe38: stp             fp, lr, [SP, #-0x10]!
    //     0xd5fe3c: mov             fp, SP
    // 0xd5fe40: AllocStack(0x20)
    //     0xd5fe40: sub             SP, SP, #0x20
    // 0xd5fe44: d0 = 0.000000
    //     0xd5fe44: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fe48: mov             x0, x1
    // 0xd5fe4c: stur            x1, [fp, #-8]
    // 0xd5fe50: CheckStackOverflow
    //     0xd5fe50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5fe54: cmp             SP, x16
    //     0xd5fe58: b.ls            #0xd60074
    // 0xd5fe5c: LoadField: d1 = r0->field_2f
    //     0xd5fe5c: ldur            d1, [x0, #0x2f]
    // 0xd5fe60: fcmp            d1, d0
    // 0xd5fe64: b.ne            #0xd5fe7c
    // 0xd5fe68: r0 = Instance__FlingGestureKind
    //     0xd5fe68: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f238] Obj!_FlingGestureKind@12c3321
    //     0xd5fe6c: ldr             x0, [x0, #0x238]
    // 0xd5fe70: LeaveFrame
    //     0xd5fe70: mov             SP, fp
    //     0xd5fe74: ldp             fp, lr, [SP], #0x10
    // 0xd5fe78: ret
    //     0xd5fe78: ret             
    // 0xd5fe7c: LoadField: r1 = r2->field_7
    //     0xd5fe7c: ldur            w1, [x2, #7]
    // 0xd5fe80: DecompressPointer r1
    //     0xd5fe80: add             x1, x1, HEAP, lsl #32
    // 0xd5fe84: LoadField: d1 = r1->field_7
    //     0xd5fe84: ldur            d1, [x1, #7]
    // 0xd5fe88: stur            d1, [fp, #-0x20]
    // 0xd5fe8c: LoadField: d2 = r1->field_f
    //     0xd5fe8c: ldur            d2, [x1, #0xf]
    // 0xd5fe90: mov             x1, x0
    // 0xd5fe94: stur            d2, [fp, #-0x18]
    // 0xd5fe98: r0 = _directionIsXAxis()
    //     0xd5fe98: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd5fe9c: tbnz            w0, #4, #0xd5ff70
    // 0xd5fea0: ldur            d1, [fp, #-0x20]
    // 0xd5fea4: d0 = 0.000000
    //     0xd5fea4: eor             v0.16b, v0.16b, v0.16b
    // 0xd5fea8: fcmp            d1, d0
    // 0xd5feac: b.ne            #0xd5feb8
    // 0xd5feb0: d3 = 0.000000
    //     0xd5feb0: eor             v3.16b, v3.16b, v3.16b
    // 0xd5feb4: b               #0xd5fed0
    // 0xd5feb8: fcmp            d0, d1
    // 0xd5febc: b.le            #0xd5fec8
    // 0xd5fec0: fneg            d2, d1
    // 0xd5fec4: b               #0xd5fecc
    // 0xd5fec8: mov             v2.16b, v1.16b
    // 0xd5fecc: mov             v3.16b, v2.16b
    // 0xd5fed0: ldur            d2, [fp, #-0x18]
    // 0xd5fed4: fcmp            d2, d0
    // 0xd5fed8: b.ne            #0xd5fee4
    // 0xd5fedc: d2 = 0.000000
    //     0xd5fedc: eor             v2.16b, v2.16b, v2.16b
    // 0xd5fee0: b               #0xd5fef4
    // 0xd5fee4: fcmp            d0, d2
    // 0xd5fee8: b.le            #0xd5fef4
    // 0xd5feec: fneg            d4, d2
    // 0xd5fef0: mov             v2.16b, v4.16b
    // 0xd5fef4: d4 = 400.000000
    //     0xd5fef4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13158] IMM: double(400) from 0x4079000000000000
    //     0xd5fef8: ldr             d4, [x17, #0x158]
    // 0xd5fefc: fsub            d5, d3, d2
    // 0xd5ff00: fcmp            d4, d5
    // 0xd5ff04: b.gt            #0xd5ff4c
    // 0xd5ff08: fcmp            d1, d0
    // 0xd5ff0c: b.ne            #0xd5ff24
    // 0xd5ff10: d3 = 700.000000
    //     0xd5ff10: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f240] IMM: double(700) from 0x4085e00000000000
    //     0xd5ff14: ldr             d3, [x17, #0x240]
    // 0xd5ff18: fcmp            d3, d0
    // 0xd5ff1c: b.le            #0xd5ff60
    // 0xd5ff20: b               #0xd5ff4c
    // 0xd5ff24: d3 = 700.000000
    //     0xd5ff24: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f240] IMM: double(700) from 0x4085e00000000000
    //     0xd5ff28: ldr             d3, [x17, #0x240]
    // 0xd5ff2c: fcmp            d0, d1
    // 0xd5ff30: b.le            #0xd5ff44
    // 0xd5ff34: fneg            d0, d1
    // 0xd5ff38: fcmp            d3, d0
    // 0xd5ff3c: b.le            #0xd5ff60
    // 0xd5ff40: b               #0xd5ff4c
    // 0xd5ff44: fcmp            d3, d1
    // 0xd5ff48: b.le            #0xd5ff60
    // 0xd5ff4c: r0 = Instance__FlingGestureKind
    //     0xd5ff4c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f238] Obj!_FlingGestureKind@12c3321
    //     0xd5ff50: ldr             x0, [x0, #0x238]
    // 0xd5ff54: LeaveFrame
    //     0xd5ff54: mov             SP, fp
    //     0xd5ff58: ldp             fp, lr, [SP], #0x10
    // 0xd5ff5c: ret
    //     0xd5ff5c: ret             
    // 0xd5ff60: ldur            x1, [fp, #-8]
    // 0xd5ff64: mov             v0.16b, v1.16b
    // 0xd5ff68: r0 = _extentToDirection()
    //     0xd5ff68: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd5ff6c: b               #0xd60030
    // 0xd5ff70: ldur            d1, [fp, #-0x20]
    // 0xd5ff74: ldur            d2, [fp, #-0x18]
    // 0xd5ff78: d0 = 0.000000
    //     0xd5ff78: eor             v0.16b, v0.16b, v0.16b
    // 0xd5ff7c: d4 = 400.000000
    //     0xd5ff7c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13158] IMM: double(400) from 0x4079000000000000
    //     0xd5ff80: ldr             d4, [x17, #0x158]
    // 0xd5ff84: d3 = 700.000000
    //     0xd5ff84: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f240] IMM: double(700) from 0x4085e00000000000
    //     0xd5ff88: ldr             d3, [x17, #0x240]
    // 0xd5ff8c: fcmp            d2, d0
    // 0xd5ff90: b.ne            #0xd5ff9c
    // 0xd5ff94: d5 = 0.000000
    //     0xd5ff94: eor             v5.16b, v5.16b, v5.16b
    // 0xd5ff98: b               #0xd5ffb0
    // 0xd5ff9c: fcmp            d0, d2
    // 0xd5ffa0: b.le            #0xd5ffac
    // 0xd5ffa4: fneg            d5, d2
    // 0xd5ffa8: b               #0xd5ffb0
    // 0xd5ffac: mov             v5.16b, v2.16b
    // 0xd5ffb0: fcmp            d1, d0
    // 0xd5ffb4: b.ne            #0xd5ffc0
    // 0xd5ffb8: d1 = 0.000000
    //     0xd5ffb8: eor             v1.16b, v1.16b, v1.16b
    // 0xd5ffbc: b               #0xd5ffd0
    // 0xd5ffc0: fcmp            d0, d1
    // 0xd5ffc4: b.le            #0xd5ffd0
    // 0xd5ffc8: fneg            d6, d1
    // 0xd5ffcc: mov             v1.16b, v6.16b
    // 0xd5ffd0: fsub            d6, d5, d1
    // 0xd5ffd4: fcmp            d4, d6
    // 0xd5ffd8: b.gt            #0xd60010
    // 0xd5ffdc: fcmp            d2, d0
    // 0xd5ffe0: b.ne            #0xd5fff0
    // 0xd5ffe4: fcmp            d3, d0
    // 0xd5ffe8: b.le            #0xd60024
    // 0xd5ffec: b               #0xd60010
    // 0xd5fff0: fcmp            d0, d2
    // 0xd5fff4: b.le            #0xd60008
    // 0xd5fff8: fneg            d0, d2
    // 0xd5fffc: fcmp            d3, d0
    // 0xd60000: b.le            #0xd60024
    // 0xd60004: b               #0xd60010
    // 0xd60008: fcmp            d3, d2
    // 0xd6000c: b.le            #0xd60024
    // 0xd60010: r0 = Instance__FlingGestureKind
    //     0xd60010: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f238] Obj!_FlingGestureKind@12c3321
    //     0xd60014: ldr             x0, [x0, #0x238]
    // 0xd60018: LeaveFrame
    //     0xd60018: mov             SP, fp
    //     0xd6001c: ldp             fp, lr, [SP], #0x10
    // 0xd60020: ret
    //     0xd60020: ret             
    // 0xd60024: ldur            x1, [fp, #-8]
    // 0xd60028: mov             v0.16b, v2.16b
    // 0xd6002c: r0 = _extentToDirection()
    //     0xd6002c: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd60030: ldur            x1, [fp, #-8]
    // 0xd60034: stur            x0, [fp, #-0x10]
    // 0xd60038: LoadField: d0 = r1->field_2f
    //     0xd60038: ldur            d0, [x1, #0x2f]
    // 0xd6003c: r0 = _extentToDirection()
    //     0xd6003c: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd60040: ldur            x1, [fp, #-0x10]
    // 0xd60044: cmp             w1, w0
    // 0xd60048: b.ne            #0xd60060
    // 0xd6004c: r0 = Instance__FlingGestureKind
    //     0xd6004c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f248] Obj!_FlingGestureKind@12c3301
    //     0xd60050: ldr             x0, [x0, #0x248]
    // 0xd60054: LeaveFrame
    //     0xd60054: mov             SP, fp
    //     0xd60058: ldp             fp, lr, [SP], #0x10
    // 0xd6005c: ret
    //     0xd6005c: ret             
    // 0xd60060: r0 = Instance__FlingGestureKind
    //     0xd60060: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f250] Obj!_FlingGestureKind@12c32e1
    //     0xd60064: ldr             x0, [x0, #0x250]
    // 0xd60068: LeaveFrame
    //     0xd60068: mov             SP, fp
    //     0xd6006c: ldp             fp, lr, [SP], #0x10
    // 0xd60070: ret
    //     0xd60070: ret             
    // 0xd60074: r0 = StackOverflowSharedWithFPURegs()
    //     0xd60074: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd60078: b               #0xd5fe5c
  }
  _ _handleMoveCompleted(/* No info */) async {
    // ** addr: 0xd6007c, size: 0xf4
    // 0xd6007c: EnterFrame
    //     0xd6007c: stp             fp, lr, [SP, #-0x10]!
    //     0xd60080: mov             fp, SP
    // 0xd60084: AllocStack(0x18)
    //     0xd60084: sub             SP, SP, #0x18
    // 0xd60088: SetupParameters(_DismissibleState this /* r1 => r1, fp-0x10 */)
    //     0xd60088: stur            NULL, [fp, #-8]
    //     0xd6008c: stur            x1, [fp, #-0x10]
    // 0xd60090: CheckStackOverflow
    //     0xd60090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60094: cmp             SP, x16
    //     0xd60098: b.ls            #0xd60168
    // 0xd6009c: InitAsync() -> Future<void?>
    //     0xd6009c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd600a0: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd600a4: ldur            x1, [fp, #-0x10]
    // 0xd600a8: r0 = _dismissThreshold()
    //     0xd600a8: bl              #0xd5fc6c  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_dismissThreshold
    // 0xd600ac: mov             v1.16b, v0.16b
    // 0xd600b0: d0 = 1.000000
    //     0xd600b0: fmov            d0, #1.00000000
    // 0xd600b4: fcmp            d1, d0
    // 0xd600b8: b.lt            #0xd600f4
    // 0xd600bc: ldur            x1, [fp, #-0x10]
    // 0xd600c0: LoadField: r0 = r1->field_1f
    //     0xd600c0: ldur            w0, [x1, #0x1f]
    // 0xd600c4: DecompressPointer r0
    //     0xd600c4: add             x0, x0, HEAP, lsl #32
    // 0xd600c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd600cc: cmp             w0, w16
    // 0xd600d0: b.ne            #0xd600e0
    // 0xd600d4: r2 = _moveController
    //     0xd600d4: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd600d8: ldr             x2, [x2, #0x218]
    // 0xd600dc: r0 = InitLateFinalInstanceField()
    //     0xd600dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd600e0: mov             x1, x0
    // 0xd600e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd600e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd600e8: r0 = reverse()
    //     0xd600e8: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd600ec: r0 = Null
    //     0xd600ec: mov             x0, NULL
    // 0xd600f0: r0 = ReturnAsyncNotFuture()
    //     0xd600f0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd600f4: ldur            x0, [fp, #-0x10]
    // 0xd600f8: mov             x1, x0
    // 0xd600fc: r0 = _confirmStartResizeAnimation()
    //     0xd600fc: bl              #0xd60208  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_confirmStartResizeAnimation
    // 0xd60100: mov             x1, x0
    // 0xd60104: stur            x1, [fp, #-0x18]
    // 0xd60108: r0 = Await()
    //     0xd60108: bl              #0x7f5c00  ; AwaitStub
    // 0xd6010c: ldur            x1, [fp, #-0x10]
    // 0xd60110: LoadField: r2 = r1->field_f
    //     0xd60110: ldur            w2, [x1, #0xf]
    // 0xd60114: DecompressPointer r2
    //     0xd60114: add             x2, x2, HEAP, lsl #32
    // 0xd60118: cmp             w2, NULL
    // 0xd6011c: b.eq            #0xd60160
    // 0xd60120: r16 = true
    //     0xd60120: add             x16, NULL, #0x20  ; true
    // 0xd60124: cmp             w0, w16
    // 0xd60128: b.ne            #0xd60134
    // 0xd6012c: r0 = _startResizeAnimation()
    //     0xd6012c: bl              #0xd60170  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_startResizeAnimation
    // 0xd60130: b               #0xd60160
    // 0xd60134: LoadField: r0 = r1->field_1f
    //     0xd60134: ldur            w0, [x1, #0x1f]
    // 0xd60138: DecompressPointer r0
    //     0xd60138: add             x0, x0, HEAP, lsl #32
    // 0xd6013c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd60140: cmp             w0, w16
    // 0xd60144: b.ne            #0xd60154
    // 0xd60148: r2 = _moveController
    //     0xd60148: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd6014c: ldr             x2, [x2, #0x218]
    // 0xd60150: r0 = InitLateFinalInstanceField()
    //     0xd60150: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd60154: mov             x1, x0
    // 0xd60158: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd60158: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd6015c: r0 = reverse()
    //     0xd6015c: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd60160: r0 = Null
    //     0xd60160: mov             x0, NULL
    // 0xd60164: r0 = ReturnAsyncNotFuture()
    //     0xd60164: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd60168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd60168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6016c: b               #0xd6009c
  }
  _ _startResizeAnimation(/* No info */) {
    // ** addr: 0xd60170, size: 0x98
    // 0xd60170: EnterFrame
    //     0xd60170: stp             fp, lr, [SP, #-0x10]!
    //     0xd60174: mov             fp, SP
    // 0xd60178: AllocStack(0x18)
    //     0xd60178: sub             SP, SP, #0x18
    // 0xd6017c: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */)
    //     0xd6017c: mov             x0, x1
    //     0xd60180: stur            x1, [fp, #-8]
    // 0xd60184: CheckStackOverflow
    //     0xd60184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60188: cmp             SP, x16
    //     0xd6018c: b.ls            #0xd601f4
    // 0xd60190: LoadField: r1 = r0->field_b
    //     0xd60190: ldur            w1, [x0, #0xb]
    // 0xd60194: DecompressPointer r1
    //     0xd60194: add             x1, x1, HEAP, lsl #32
    // 0xd60198: cmp             w1, NULL
    // 0xd6019c: b.eq            #0xd601fc
    // 0xd601a0: LoadField: d0 = r0->field_2f
    //     0xd601a0: ldur            d0, [x0, #0x2f]
    // 0xd601a4: mov             x1, x0
    // 0xd601a8: r0 = _extentToDirection()
    //     0xd601a8: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd601ac: mov             x1, x0
    // 0xd601b0: ldur            x0, [fp, #-8]
    // 0xd601b4: LoadField: r2 = r0->field_b
    //     0xd601b4: ldur            w2, [x0, #0xb]
    // 0xd601b8: DecompressPointer r2
    //     0xd601b8: add             x2, x2, HEAP, lsl #32
    // 0xd601bc: cmp             w2, NULL
    // 0xd601c0: b.eq            #0xd60200
    // 0xd601c4: LoadField: r0 = r2->field_1b
    //     0xd601c4: ldur            w0, [x2, #0x1b]
    // 0xd601c8: DecompressPointer r0
    //     0xd601c8: add             x0, x0, HEAP, lsl #32
    // 0xd601cc: cmp             w0, NULL
    // 0xd601d0: b.eq            #0xd60204
    // 0xd601d4: stp             x1, x0, [SP]
    // 0xd601d8: ClosureCall
    //     0xd601d8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd601dc: ldur            x2, [x0, #0x1f]
    //     0xd601e0: blr             x2
    // 0xd601e4: r0 = Null
    //     0xd601e4: mov             x0, NULL
    // 0xd601e8: LeaveFrame
    //     0xd601e8: mov             SP, fp
    //     0xd601ec: ldp             fp, lr, [SP], #0x10
    // 0xd601f0: ret
    //     0xd601f0: ret             
    // 0xd601f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd601f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd601f8: b               #0xd60190
    // 0xd601fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd601fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd60200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd60200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd60204: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd60204: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _confirmStartResizeAnimation(/* No info */) async {
    // ** addr: 0xd60208, size: 0x104
    // 0xd60208: EnterFrame
    //     0xd60208: stp             fp, lr, [SP, #-0x10]!
    //     0xd6020c: mov             fp, SP
    // 0xd60210: AllocStack(0x90)
    //     0xd60210: sub             SP, SP, #0x90
    // 0xd60214: SetupParameters(_DismissibleState this /* r1 => r1, fp-0x70 */)
    //     0xd60214: stur            NULL, [fp, #-8]
    //     0xd60218: stur            x1, [fp, #-0x70]
    // 0xd6021c: CheckStackOverflow
    //     0xd6021c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60220: cmp             SP, x16
    //     0xd60224: b.ls            #0xd602f8
    // 0xd60228: InitAsync() -> Future<bool>
    //     0xd60228: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0xd6022c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd60230: ldur            x0, [fp, #-0x70]
    // 0xd60234: LoadField: r1 = r0->field_b
    //     0xd60234: ldur            w1, [x0, #0xb]
    // 0xd60238: DecompressPointer r1
    //     0xd60238: add             x1, x1, HEAP, lsl #32
    // 0xd6023c: cmp             w1, NULL
    // 0xd60240: b.eq            #0xd60300
    // 0xd60244: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd60244: ldur            w2, [x1, #0x17]
    // 0xd60248: DecompressPointer r2
    //     0xd60248: add             x2, x2, HEAP, lsl #32
    // 0xd6024c: cmp             w2, NULL
    // 0xd60250: b.eq            #0xd602d4
    // 0xd60254: r1 = true
    //     0xd60254: add             x1, NULL, #0x20  ; true
    // 0xd60258: StoreField: r0->field_37 = r1
    //     0xd60258: stur            w1, [x0, #0x37]
    // 0xd6025c: LoadField: d0 = r0->field_2f
    //     0xd6025c: ldur            d0, [x0, #0x2f]
    // 0xd60260: mov             x1, x0
    // 0xd60264: r0 = _extentToDirection()
    //     0xd60264: bl              #0xd5fd08  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_extentToDirection
    // 0xd60268: mov             x1, x0
    // 0xd6026c: stur            x1, [fp, #-0x80]
    // 0xd60270: ldur            x2, [fp, #-0x70]
    // 0xd60274: LoadField: r0 = r2->field_b
    //     0xd60274: ldur            w0, [x2, #0xb]
    // 0xd60278: DecompressPointer r0
    //     0xd60278: add             x0, x0, HEAP, lsl #32
    // 0xd6027c: cmp             w0, NULL
    // 0xd60280: b.eq            #0xd60304
    // 0xd60284: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xd60284: ldur            w3, [x0, #0x17]
    // 0xd60288: DecompressPointer r3
    //     0xd60288: add             x3, x3, HEAP, lsl #32
    // 0xd6028c: stur            x3, [fp, #-0x78]
    // 0xd60290: cmp             w3, NULL
    // 0xd60294: b.eq            #0xd60308
    // 0xd60298: stp             x1, x3, [SP]
    // 0xd6029c: mov             x0, x3
    // 0xd602a0: ClosureCall
    //     0xd602a0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd602a4: ldur            x2, [x0, #0x1f]
    //     0xd602a8: blr             x2
    // 0xd602ac: mov             x1, x0
    // 0xd602b0: stur            x1, [fp, #-0x78]
    // 0xd602b4: r0 = Await()
    //     0xd602b4: bl              #0x7f5c00  ; AwaitStub
    // 0xd602b8: cmp             w0, NULL
    // 0xd602bc: b.ne            #0xd602c4
    // 0xd602c0: r0 = false
    //     0xd602c0: add             x0, NULL, #0x30  ; false
    // 0xd602c4: ldur            x2, [fp, #-0x70]
    // 0xd602c8: r3 = false
    //     0xd602c8: add             x3, NULL, #0x30  ; false
    // 0xd602cc: StoreField: r2->field_37 = r3
    //     0xd602cc: stur            w3, [x2, #0x37]
    // 0xd602d0: r0 = ReturnAsync()
    //     0xd602d0: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xd602d4: r1 = true
    //     0xd602d4: add             x1, NULL, #0x20  ; true
    // 0xd602d8: mov             x0, x1
    // 0xd602dc: r0 = ReturnAsyncNotFuture()
    //     0xd602dc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd602e0: sub             SP, fp, #0x90
    // 0xd602e4: ldur            x2, [fp, #-0x70]
    // 0xd602e8: r3 = false
    //     0xd602e8: add             x3, NULL, #0x30  ; false
    // 0xd602ec: StoreField: r2->field_37 = r3
    //     0xd602ec: stur            w3, [x2, #0x37]
    // 0xd602f0: r0 = ReThrow()
    //     0xd602f0: bl              #0x13ddb00  ; ReThrowStub
    // 0xd602f4: brk             #0
    // 0xd602f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd602f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd602fc: b               #0xd60228
    // 0xd60300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd60300: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd60304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd60304: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd60308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd60308: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0xd6030c, size: 0x3c
    // 0xd6030c: EnterFrame
    //     0xd6030c: stp             fp, lr, [SP, #-0x10]!
    //     0xd60310: mov             fp, SP
    // 0xd60314: ldr             x0, [fp, #0x18]
    // 0xd60318: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd60318: ldur            w1, [x0, #0x17]
    // 0xd6031c: DecompressPointer r1
    //     0xd6031c: add             x1, x1, HEAP, lsl #32
    // 0xd60320: CheckStackOverflow
    //     0xd60320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60324: cmp             SP, x16
    //     0xd60328: b.ls            #0xd60340
    // 0xd6032c: ldr             x2, [fp, #0x10]
    // 0xd60330: r0 = _handleDragUpdate()
    //     0xd60330: bl              #0xd60348  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragUpdate
    // 0xd60334: LeaveFrame
    //     0xd60334: mov             SP, fp
    //     0xd60338: ldp             fp, lr, [SP], #0x10
    // 0xd6033c: ret
    //     0xd6033c: ret             
    // 0xd60340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd60340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd60344: b               #0xd6032c
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0xd60348, size: 0x3b8
    // 0xd60348: EnterFrame
    //     0xd60348: stp             fp, lr, [SP, #-0x10]!
    //     0xd6034c: mov             fp, SP
    // 0xd60350: AllocStack(0x28)
    //     0xd60350: sub             SP, SP, #0x28
    // 0xd60354: SetupParameters(_DismissibleState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd60354: stur            x1, [fp, #-8]
    //     0xd60358: stur            x2, [fp, #-0x10]
    // 0xd6035c: CheckStackOverflow
    //     0xd6035c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60360: cmp             SP, x16
    //     0xd60364: b.ls            #0xd606d4
    // 0xd60368: r1 = 1
    //     0xd60368: mov             x1, #1
    // 0xd6036c: r0 = AllocateContext()
    //     0xd6036c: bl              #0x13de838  ; AllocateContextStub
    // 0xd60370: mov             x2, x0
    // 0xd60374: ldur            x0, [fp, #-8]
    // 0xd60378: stur            x2, [fp, #-0x18]
    // 0xd6037c: StoreField: r2->field_f = r0
    //     0xd6037c: stur            w0, [x2, #0xf]
    // 0xd60380: LoadField: r1 = r0->field_3b
    //     0xd60380: ldur            w1, [x0, #0x3b]
    // 0xd60384: DecompressPointer r1
    //     0xd60384: add             x1, x1, HEAP, lsl #32
    // 0xd60388: tbnz            w1, #4, #0xd603d0
    // 0xd6038c: mov             x1, x0
    // 0xd60390: LoadField: r0 = r1->field_1f
    //     0xd60390: ldur            w0, [x1, #0x1f]
    // 0xd60394: DecompressPointer r0
    //     0xd60394: add             x0, x0, HEAP, lsl #32
    // 0xd60398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd6039c: cmp             w0, w16
    // 0xd603a0: b.ne            #0xd603b0
    // 0xd603a4: r2 = _moveController
    //     0xd603a4: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd603a8: ldr             x2, [x2, #0x218]
    // 0xd603ac: r0 = InitLateFinalInstanceField()
    //     0xd603ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd603b0: LoadField: r1 = r0->field_2f
    //     0xd603b0: ldur            w1, [x0, #0x2f]
    // 0xd603b4: DecompressPointer r1
    //     0xd603b4: add             x1, x1, HEAP, lsl #32
    // 0xd603b8: cmp             w1, NULL
    // 0xd603bc: b.eq            #0xd603e0
    // 0xd603c0: LoadField: r0 = r1->field_7
    //     0xd603c0: ldur            w0, [x1, #7]
    // 0xd603c4: DecompressPointer r0
    //     0xd603c4: add             x0, x0, HEAP, lsl #32
    // 0xd603c8: cmp             w0, NULL
    // 0xd603cc: b.eq            #0xd603e0
    // 0xd603d0: r0 = Null
    //     0xd603d0: mov             x0, NULL
    // 0xd603d4: LeaveFrame
    //     0xd603d4: mov             SP, fp
    //     0xd603d8: ldp             fp, lr, [SP], #0x10
    // 0xd603dc: ret
    //     0xd603dc: ret             
    // 0xd603e0: ldur            x0, [fp, #-8]
    // 0xd603e4: ldur            x1, [fp, #-0x10]
    // 0xd603e8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd603e8: ldur            w2, [x1, #0x17]
    // 0xd603ec: DecompressPointer r2
    //     0xd603ec: add             x2, x2, HEAP, lsl #32
    // 0xd603f0: stur            x2, [fp, #-0x20]
    // 0xd603f4: cmp             w2, NULL
    // 0xd603f8: b.eq            #0xd606dc
    // 0xd603fc: LoadField: d0 = r0->field_2f
    //     0xd603fc: ldur            d0, [x0, #0x2f]
    // 0xd60400: stur            d0, [fp, #-0x28]
    // 0xd60404: LoadField: r1 = r0->field_b
    //     0xd60404: ldur            w1, [x0, #0xb]
    // 0xd60408: DecompressPointer r1
    //     0xd60408: add             x1, x1, HEAP, lsl #32
    // 0xd6040c: cmp             w1, NULL
    // 0xd60410: b.eq            #0xd606e0
    // 0xd60414: LoadField: r3 = r1->field_1f
    //     0xd60414: ldur            w3, [x1, #0x1f]
    // 0xd60418: DecompressPointer r3
    //     0xd60418: add             x3, x3, HEAP, lsl #32
    // 0xd6041c: LoadField: r1 = r3->field_7
    //     0xd6041c: ldur            x1, [x3, #7]
    // 0xd60420: cmp             x1, #3
    // 0xd60424: b.gt            #0xd60554
    // 0xd60428: cmp             x1, #1
    // 0xd6042c: b.gt            #0xd60448
    // 0xd60430: LoadField: d1 = r2->field_7
    //     0xd60430: ldur            d1, [x2, #7]
    // 0xd60434: fadd            d2, d0, d1
    // 0xd60438: StoreField: r0->field_2f = d2
    //     0xd60438: stur            d2, [x0, #0x2f]
    // 0xd6043c: mov             v1.16b, v0.16b
    // 0xd60440: d0 = 0.000000
    //     0xd60440: eor             v0.16b, v0.16b, v0.16b
    // 0xd60444: b               #0xd605c4
    // 0xd60448: cmp             x1, #2
    // 0xd6044c: b.gt            #0xd604d0
    // 0xd60450: LoadField: r1 = r0->field_f
    //     0xd60450: ldur            w1, [x0, #0xf]
    // 0xd60454: DecompressPointer r1
    //     0xd60454: add             x1, x1, HEAP, lsl #32
    // 0xd60458: cmp             w1, NULL
    // 0xd6045c: b.eq            #0xd606e4
    // 0xd60460: r0 = of()
    //     0xd60460: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd60464: LoadField: r1 = r0->field_7
    //     0xd60464: ldur            x1, [x0, #7]
    // 0xd60468: cmp             x1, #0
    // 0xd6046c: b.gt            #0xd6049c
    // 0xd60470: ldur            x0, [fp, #-8]
    // 0xd60474: ldur            x2, [fp, #-0x20]
    // 0xd60478: d0 = 0.000000
    //     0xd60478: eor             v0.16b, v0.16b, v0.16b
    // 0xd6047c: LoadField: d1 = r0->field_2f
    //     0xd6047c: ldur            d1, [x0, #0x2f]
    // 0xd60480: LoadField: d2 = r2->field_7
    //     0xd60480: ldur            d2, [x2, #7]
    // 0xd60484: fadd            d3, d1, d2
    // 0xd60488: fcmp            d3, d0
    // 0xd6048c: b.le            #0xd604c4
    // 0xd60490: StoreField: r0->field_2f = d3
    //     0xd60490: stur            d3, [x0, #0x2f]
    // 0xd60494: mov             v1.16b, v3.16b
    // 0xd60498: b               #0xd604c4
    // 0xd6049c: ldur            x0, [fp, #-8]
    // 0xd604a0: ldur            x2, [fp, #-0x20]
    // 0xd604a4: d0 = 0.000000
    //     0xd604a4: eor             v0.16b, v0.16b, v0.16b
    // 0xd604a8: LoadField: d1 = r0->field_2f
    //     0xd604a8: ldur            d1, [x0, #0x2f]
    // 0xd604ac: LoadField: d2 = r2->field_7
    //     0xd604ac: ldur            d2, [x2, #7]
    // 0xd604b0: fadd            d3, d1, d2
    // 0xd604b4: fcmp            d0, d3
    // 0xd604b8: b.le            #0xd604c4
    // 0xd604bc: StoreField: r0->field_2f = d3
    //     0xd604bc: stur            d3, [x0, #0x2f]
    // 0xd604c0: mov             v1.16b, v3.16b
    // 0xd604c4: mov             v2.16b, v1.16b
    // 0xd604c8: ldur            d1, [fp, #-0x28]
    // 0xd604cc: b               #0xd605c4
    // 0xd604d0: d0 = 0.000000
    //     0xd604d0: eor             v0.16b, v0.16b, v0.16b
    // 0xd604d4: LoadField: r1 = r0->field_f
    //     0xd604d4: ldur            w1, [x0, #0xf]
    // 0xd604d8: DecompressPointer r1
    //     0xd604d8: add             x1, x1, HEAP, lsl #32
    // 0xd604dc: cmp             w1, NULL
    // 0xd604e0: b.eq            #0xd606e8
    // 0xd604e4: r0 = of()
    //     0xd604e4: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd604e8: LoadField: r1 = r0->field_7
    //     0xd604e8: ldur            x1, [x0, #7]
    // 0xd604ec: cmp             x1, #0
    // 0xd604f0: b.gt            #0xd60520
    // 0xd604f4: ldur            x0, [fp, #-8]
    // 0xd604f8: ldur            x2, [fp, #-0x20]
    // 0xd604fc: d0 = 0.000000
    //     0xd604fc: eor             v0.16b, v0.16b, v0.16b
    // 0xd60500: LoadField: d1 = r0->field_2f
    //     0xd60500: ldur            d1, [x0, #0x2f]
    // 0xd60504: LoadField: d2 = r2->field_7
    //     0xd60504: ldur            d2, [x2, #7]
    // 0xd60508: fadd            d3, d1, d2
    // 0xd6050c: fcmp            d0, d3
    // 0xd60510: b.le            #0xd60548
    // 0xd60514: StoreField: r0->field_2f = d3
    //     0xd60514: stur            d3, [x0, #0x2f]
    // 0xd60518: mov             v1.16b, v3.16b
    // 0xd6051c: b               #0xd60548
    // 0xd60520: ldur            x0, [fp, #-8]
    // 0xd60524: ldur            x2, [fp, #-0x20]
    // 0xd60528: d0 = 0.000000
    //     0xd60528: eor             v0.16b, v0.16b, v0.16b
    // 0xd6052c: LoadField: d1 = r0->field_2f
    //     0xd6052c: ldur            d1, [x0, #0x2f]
    // 0xd60530: LoadField: d2 = r2->field_7
    //     0xd60530: ldur            d2, [x2, #7]
    // 0xd60534: fadd            d3, d1, d2
    // 0xd60538: fcmp            d3, d0
    // 0xd6053c: b.le            #0xd60548
    // 0xd60540: StoreField: r0->field_2f = d3
    //     0xd60540: stur            d3, [x0, #0x2f]
    // 0xd60544: mov             v1.16b, v3.16b
    // 0xd60548: mov             v2.16b, v1.16b
    // 0xd6054c: ldur            d1, [fp, #-0x28]
    // 0xd60550: b               #0xd605c4
    // 0xd60554: d0 = 0.000000
    //     0xd60554: eor             v0.16b, v0.16b, v0.16b
    // 0xd60558: cmp             x1, #5
    // 0xd6055c: b.gt            #0xd605b8
    // 0xd60560: cmp             x1, #4
    // 0xd60564: b.gt            #0xd60590
    // 0xd60568: ldur            d1, [fp, #-0x28]
    // 0xd6056c: LoadField: d2 = r2->field_7
    //     0xd6056c: ldur            d2, [x2, #7]
    // 0xd60570: fadd            d3, d1, d2
    // 0xd60574: fcmp            d0, d3
    // 0xd60578: b.le            #0xd60588
    // 0xd6057c: StoreField: r0->field_2f = d3
    //     0xd6057c: stur            d3, [x0, #0x2f]
    // 0xd60580: mov             v2.16b, v3.16b
    // 0xd60584: b               #0xd605c4
    // 0xd60588: mov             v2.16b, v1.16b
    // 0xd6058c: b               #0xd605c4
    // 0xd60590: ldur            d1, [fp, #-0x28]
    // 0xd60594: LoadField: d2 = r2->field_7
    //     0xd60594: ldur            d2, [x2, #7]
    // 0xd60598: fadd            d3, d1, d2
    // 0xd6059c: fcmp            d3, d0
    // 0xd605a0: b.le            #0xd605b0
    // 0xd605a4: StoreField: r0->field_2f = d3
    //     0xd605a4: stur            d3, [x0, #0x2f]
    // 0xd605a8: mov             v2.16b, v3.16b
    // 0xd605ac: b               #0xd605c4
    // 0xd605b0: mov             v2.16b, v1.16b
    // 0xd605b4: b               #0xd605c4
    // 0xd605b8: ldur            d1, [fp, #-0x28]
    // 0xd605bc: StoreField: r0->field_2f = rZR
    //     0xd605bc: stur            xzr, [x0, #0x2f]
    // 0xd605c0: d2 = 0.000000
    //     0xd605c0: eor             v2.16b, v2.16b, v2.16b
    // 0xd605c4: fcmp            d1, d0
    // 0xd605c8: b.le            #0xd605d4
    // 0xd605cc: d1 = 1.000000
    //     0xd605cc: fmov            d1, #1.00000000
    // 0xd605d0: b               #0xd605e0
    // 0xd605d4: fcmp            d0, d1
    // 0xd605d8: b.le            #0xd605e0
    // 0xd605dc: d1 = -1.000000
    //     0xd605dc: fmov            d1, #-1.00000000
    // 0xd605e0: fcmp            d2, d0
    // 0xd605e4: b.le            #0xd605f0
    // 0xd605e8: d2 = 1.000000
    //     0xd605e8: fmov            d2, #1.00000000
    // 0xd605ec: b               #0xd605fc
    // 0xd605f0: fcmp            d0, d2
    // 0xd605f4: b.le            #0xd605fc
    // 0xd605f8: d2 = -1.000000
    //     0xd605f8: fmov            d2, #-1.00000000
    // 0xd605fc: fcmp            d1, d2
    // 0xd60600: b.eq            #0xd60620
    // 0xd60604: ldur            x2, [fp, #-0x18]
    // 0xd60608: r1 = Function '<anonymous closure>':.
    //     0xd60608: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f258] AnonymousClosure: (0xd60784), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragUpdate (0xd60348)
    //     0xd6060c: ldr             x1, [x1, #0x258]
    // 0xd60610: r0 = AllocateClosure()
    //     0xd60610: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd60614: ldur            x1, [fp, #-8]
    // 0xd60618: mov             x2, x0
    // 0xd6061c: r0 = setState()
    //     0xd6061c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd60620: ldur            x1, [fp, #-8]
    // 0xd60624: LoadField: r0 = r1->field_1f
    //     0xd60624: ldur            w0, [x1, #0x1f]
    // 0xd60628: DecompressPointer r0
    //     0xd60628: add             x0, x0, HEAP, lsl #32
    // 0xd6062c: stur            x0, [fp, #-0x10]
    // 0xd60630: LoadField: r2 = r0->field_2f
    //     0xd60630: ldur            w2, [x0, #0x2f]
    // 0xd60634: DecompressPointer r2
    //     0xd60634: add             x2, x2, HEAP, lsl #32
    // 0xd60638: cmp             w2, NULL
    // 0xd6063c: b.eq            #0xd60650
    // 0xd60640: LoadField: r3 = r2->field_7
    //     0xd60640: ldur            w3, [x2, #7]
    // 0xd60644: DecompressPointer r3
    //     0xd60644: add             x3, x3, HEAP, lsl #32
    // 0xd60648: cmp             w3, NULL
    // 0xd6064c: b.ne            #0xd606c4
    // 0xd60650: d0 = 0.000000
    //     0xd60650: eor             v0.16b, v0.16b, v0.16b
    // 0xd60654: LoadField: d1 = r1->field_2f
    //     0xd60654: ldur            d1, [x1, #0x2f]
    // 0xd60658: fcmp            d1, d0
    // 0xd6065c: b.ne            #0xd60668
    // 0xd60660: d0 = 0.000000
    //     0xd60660: eor             v0.16b, v0.16b, v0.16b
    // 0xd60664: b               #0xd6067c
    // 0xd60668: fcmp            d0, d1
    // 0xd6066c: b.le            #0xd60678
    // 0xd60670: fneg            d0, d1
    // 0xd60674: b               #0xd6067c
    // 0xd60678: mov             v0.16b, v1.16b
    // 0xd6067c: stur            d0, [fp, #-0x28]
    // 0xd60680: r0 = _overallDragAxisExtent()
    //     0xd60680: bl              #0xd60700  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_overallDragAxisExtent
    // 0xd60684: mov             v1.16b, v0.16b
    // 0xd60688: ldur            d0, [fp, #-0x28]
    // 0xd6068c: fdiv            d2, d0, d1
    // 0xd60690: r2 = inline_Allocate_Double()
    //     0xd60690: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd60694: add             x2, x2, #0x10
    //     0xd60698: cmp             x0, x2
    //     0xd6069c: b.ls            #0xd606ec
    //     0xd606a0: str             x2, [THR, #0x60]  ; THR::top
    //     0xd606a4: sub             x2, x2, #0xf
    //     0xd606a8: mov             x0, #0xe19c
    //     0xd606ac: movk            x0, #3, lsl #16
    //     0xd606b0: stur            x0, [x2, #-1]
    // 0xd606b4: dmb             ishst
    // 0xd606b8: StoreField: r2->field_7 = d2
    //     0xd606b8: stur            d2, [x2, #7]
    // 0xd606bc: ldur            x1, [fp, #-0x10]
    // 0xd606c0: r0 = value=()
    //     0xd606c0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd606c4: r0 = Null
    //     0xd606c4: mov             x0, NULL
    // 0xd606c8: LeaveFrame
    //     0xd606c8: mov             SP, fp
    //     0xd606cc: ldp             fp, lr, [SP], #0x10
    // 0xd606d0: ret
    //     0xd606d0: ret             
    // 0xd606d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd606d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd606d8: b               #0xd60368
    // 0xd606dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd606dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd606e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd606e0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd606e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd606e4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd606e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd606e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd606ec: SaveReg d2
    //     0xd606ec: str             q2, [SP, #-0x10]!
    // 0xd606f0: r0 = AllocateDouble()
    //     0xd606f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd606f4: mov             x2, x0
    // 0xd606f8: RestoreReg d2
    //     0xd606f8: ldr             q2, [SP], #0x10
    // 0xd606fc: b               #0xd606b8
  }
  get _ _overallDragAxisExtent(/* No info */) {
    // ** addr: 0xd60700, size: 0x84
    // 0xd60700: EnterFrame
    //     0xd60700: stp             fp, lr, [SP, #-0x10]!
    //     0xd60704: mov             fp, SP
    // 0xd60708: AllocStack(0x10)
    //     0xd60708: sub             SP, SP, #0x10
    // 0xd6070c: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */)
    //     0xd6070c: mov             x0, x1
    //     0xd60710: stur            x1, [fp, #-8]
    // 0xd60714: CheckStackOverflow
    //     0xd60714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60718: cmp             SP, x16
    //     0xd6071c: b.ls            #0xd60774
    // 0xd60720: LoadField: r1 = r0->field_f
    //     0xd60720: ldur            w1, [x0, #0xf]
    // 0xd60724: DecompressPointer r1
    //     0xd60724: add             x1, x1, HEAP, lsl #32
    // 0xd60728: cmp             w1, NULL
    // 0xd6072c: b.eq            #0xd6077c
    // 0xd60730: r0 = size()
    //     0xd60730: bl              #0xb7a198  ; [package:flutter/src/widgets/framework.dart] Element::size
    // 0xd60734: stur            x0, [fp, #-0x10]
    // 0xd60738: cmp             w0, NULL
    // 0xd6073c: b.eq            #0xd60780
    // 0xd60740: ldur            x1, [fp, #-8]
    // 0xd60744: r0 = _directionIsXAxis()
    //     0xd60744: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd60748: tbnz            w0, #4, #0xd6075c
    // 0xd6074c: ldur            x0, [fp, #-0x10]
    // 0xd60750: LoadField: d1 = r0->field_7
    //     0xd60750: ldur            d1, [x0, #7]
    // 0xd60754: mov             v0.16b, v1.16b
    // 0xd60758: b               #0xd60768
    // 0xd6075c: ldur            x0, [fp, #-0x10]
    // 0xd60760: LoadField: d1 = r0->field_f
    //     0xd60760: ldur            d1, [x0, #0xf]
    // 0xd60764: mov             v0.16b, v1.16b
    // 0xd60768: LeaveFrame
    //     0xd60768: mov             SP, fp
    //     0xd6076c: ldp             fp, lr, [SP], #0x10
    // 0xd60770: ret
    //     0xd60770: ret             
    // 0xd60774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd60774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd60778: b               #0xd60720
    // 0xd6077c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd6077c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd60780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd60780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd60784, size: 0x48
    // 0xd60784: EnterFrame
    //     0xd60784: stp             fp, lr, [SP, #-0x10]!
    //     0xd60788: mov             fp, SP
    // 0xd6078c: ldr             x0, [fp, #0x10]
    // 0xd60790: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd60790: ldur            w1, [x0, #0x17]
    // 0xd60794: DecompressPointer r1
    //     0xd60794: add             x1, x1, HEAP, lsl #32
    // 0xd60798: CheckStackOverflow
    //     0xd60798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6079c: cmp             SP, x16
    //     0xd607a0: b.ls            #0xd607c4
    // 0xd607a4: LoadField: r0 = r1->field_f
    //     0xd607a4: ldur            w0, [x1, #0xf]
    // 0xd607a8: DecompressPointer r0
    //     0xd607a8: add             x0, x0, HEAP, lsl #32
    // 0xd607ac: mov             x1, x0
    // 0xd607b0: r0 = _updateMoveAnimation()
    //     0xd607b0: bl              #0xd607cc  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_updateMoveAnimation
    // 0xd607b4: r0 = Null
    //     0xd607b4: mov             x0, NULL
    // 0xd607b8: LeaveFrame
    //     0xd607b8: mov             SP, fp
    //     0xd607bc: ldp             fp, lr, [SP], #0x10
    // 0xd607c0: ret
    //     0xd607c0: ret             
    // 0xd607c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd607c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd607c8: b               #0xd607a4
  }
  _ _updateMoveAnimation(/* No info */) {
    // ** addr: 0xd607cc, size: 0x150
    // 0xd607cc: EnterFrame
    //     0xd607cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd607d0: mov             fp, SP
    // 0xd607d4: AllocStack(0x20)
    //     0xd607d4: sub             SP, SP, #0x20
    // 0xd607d8: d0 = 0.000000
    //     0xd607d8: eor             v0.16b, v0.16b, v0.16b
    // 0xd607dc: mov             x0, x1
    // 0xd607e0: stur            x1, [fp, #-8]
    // 0xd607e4: CheckStackOverflow
    //     0xd607e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd607e8: cmp             SP, x16
    //     0xd607ec: b.ls            #0xd6090c
    // 0xd607f0: LoadField: d1 = r0->field_2f
    //     0xd607f0: ldur            d1, [x0, #0x2f]
    // 0xd607f4: fcmp            d1, d0
    // 0xd607f8: b.le            #0xd60804
    // 0xd607fc: d0 = 1.000000
    //     0xd607fc: fmov            d0, #1.00000000
    // 0xd60800: b               #0xd60818
    // 0xd60804: fcmp            d0, d1
    // 0xd60808: b.le            #0xd60814
    // 0xd6080c: d0 = -1.000000
    //     0xd6080c: fmov            d0, #-1.00000000
    // 0xd60810: b               #0xd60818
    // 0xd60814: mov             v0.16b, v1.16b
    // 0xd60818: mov             x1, x0
    // 0xd6081c: stur            d0, [fp, #-0x20]
    // 0xd60820: LoadField: r0 = r1->field_1f
    //     0xd60820: ldur            w0, [x1, #0x1f]
    // 0xd60824: DecompressPointer r0
    //     0xd60824: add             x0, x0, HEAP, lsl #32
    // 0xd60828: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd6082c: cmp             w0, w16
    // 0xd60830: b.ne            #0xd60840
    // 0xd60834: r2 = _moveController
    //     0xd60834: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd60838: ldr             x2, [x2, #0x218]
    // 0xd6083c: r0 = InitLateFinalInstanceField()
    //     0xd6083c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd60840: ldur            x1, [fp, #-8]
    // 0xd60844: stur            x0, [fp, #-0x10]
    // 0xd60848: r0 = _directionIsXAxis()
    //     0xd60848: bl              #0xd5f614  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_directionIsXAxis
    // 0xd6084c: tbnz            w0, #4, #0xd60880
    // 0xd60850: ldur            x0, [fp, #-8]
    // 0xd60854: ldur            d0, [fp, #-0x20]
    // 0xd60858: LoadField: r1 = r0->field_b
    //     0xd60858: ldur            w1, [x0, #0xb]
    // 0xd6085c: DecompressPointer r1
    //     0xd6085c: add             x1, x1, HEAP, lsl #32
    // 0xd60860: cmp             w1, NULL
    // 0xd60864: b.eq            #0xd60914
    // 0xd60868: r0 = Offset()
    //     0xd60868: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd6086c: ldur            d0, [fp, #-0x20]
    // 0xd60870: StoreField: r0->field_7 = d0
    //     0xd60870: stur            d0, [x0, #7]
    // 0xd60874: StoreField: r0->field_f = rZR
    //     0xd60874: stur            xzr, [x0, #0xf]
    // 0xd60878: mov             x2, x0
    // 0xd6087c: b               #0xd608ac
    // 0xd60880: ldur            x0, [fp, #-8]
    // 0xd60884: ldur            d0, [fp, #-0x20]
    // 0xd60888: LoadField: r1 = r0->field_b
    //     0xd60888: ldur            w1, [x0, #0xb]
    // 0xd6088c: DecompressPointer r1
    //     0xd6088c: add             x1, x1, HEAP, lsl #32
    // 0xd60890: cmp             w1, NULL
    // 0xd60894: b.eq            #0xd60918
    // 0xd60898: r0 = Offset()
    //     0xd60898: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd6089c: StoreField: r0->field_7 = rZR
    //     0xd6089c: stur            xzr, [x0, #7]
    // 0xd608a0: ldur            d0, [fp, #-0x20]
    // 0xd608a4: StoreField: r0->field_f = d0
    //     0xd608a4: stur            d0, [x0, #0xf]
    // 0xd608a8: mov             x2, x0
    // 0xd608ac: ldur            x0, [fp, #-8]
    // 0xd608b0: stur            x2, [fp, #-0x18]
    // 0xd608b4: r1 = <Offset>
    //     0xd608b4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xd608b8: ldr             x1, [x1, #0xa48]
    // 0xd608bc: r0 = Tween()
    //     0xd608bc: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd608c0: mov             x1, x0
    // 0xd608c4: r0 = Instance_Offset
    //     0xd608c4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd608c8: StoreField: r1->field_b = r0
    //     0xd608c8: stur            w0, [x1, #0xb]
    // 0xd608cc: ldur            x0, [fp, #-0x18]
    // 0xd608d0: StoreField: r1->field_f = r0
    //     0xd608d0: stur            w0, [x1, #0xf]
    // 0xd608d4: ldur            x2, [fp, #-0x10]
    // 0xd608d8: r0 = animate()
    //     0xd608d8: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd608dc: ldur            x1, [fp, #-8]
    // 0xd608e0: StoreField: r1->field_23 = r0
    //     0xd608e0: stur            w0, [x1, #0x23]
    //     0xd608e4: ldurb           w16, [x1, #-1]
    //     0xd608e8: ldurb           w17, [x0, #-1]
    //     0xd608ec: and             x16, x17, x16, lsr #2
    //     0xd608f0: tst             x16, HEAP, lsr #32
    //     0xd608f4: b.eq            #0xd608fc
    //     0xd608f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd608fc: r0 = Null
    //     0xd608fc: mov             x0, NULL
    // 0xd60900: LeaveFrame
    //     0xd60900: mov             SP, fp
    //     0xd60904: ldp             fp, lr, [SP], #0x10
    // 0xd60908: ret
    //     0xd60908: ret             
    // 0xd6090c: r0 = StackOverflowSharedWithFPURegs()
    //     0xd6090c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd60910: b               #0xd607f0
    // 0xd60914: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd60914: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd60918: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd60918: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xd6091c, size: 0x3c
    // 0xd6091c: EnterFrame
    //     0xd6091c: stp             fp, lr, [SP, #-0x10]!
    //     0xd60920: mov             fp, SP
    // 0xd60924: ldr             x0, [fp, #0x18]
    // 0xd60928: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd60928: ldur            w1, [x0, #0x17]
    // 0xd6092c: DecompressPointer r1
    //     0xd6092c: add             x1, x1, HEAP, lsl #32
    // 0xd60930: CheckStackOverflow
    //     0xd60930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd60934: cmp             SP, x16
    //     0xd60938: b.ls            #0xd60950
    // 0xd6093c: ldr             x2, [fp, #0x10]
    // 0xd60940: r0 = _handleDragStart()
    //     0xd60940: bl              #0xd60958  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragStart
    // 0xd60944: LeaveFrame
    //     0xd60944: mov             SP, fp
    //     0xd60948: ldp             fp, lr, [SP], #0x10
    // 0xd6094c: ret
    //     0xd6094c: ret             
    // 0xd60950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd60950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd60954: b               #0xd6093c
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0xd60958, size: 0x160
    // 0xd60958: EnterFrame
    //     0xd60958: stp             fp, lr, [SP, #-0x10]!
    //     0xd6095c: mov             fp, SP
    // 0xd60960: AllocStack(0x18)
    //     0xd60960: sub             SP, SP, #0x18
    // 0xd60964: SetupParameters(_DismissibleState this /* r1 => r1, fp-0x8 */)
    //     0xd60964: stur            x1, [fp, #-8]
    // 0xd60968: CheckStackOverflow
    //     0xd60968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6096c: cmp             SP, x16
    //     0xd60970: b.ls            #0xd60aa8
    // 0xd60974: r1 = 1
    //     0xd60974: mov             x1, #1
    // 0xd60978: r0 = AllocateContext()
    //     0xd60978: bl              #0x13de838  ; AllocateContextStub
    // 0xd6097c: mov             x2, x0
    // 0xd60980: ldur            x0, [fp, #-8]
    // 0xd60984: stur            x2, [fp, #-0x10]
    // 0xd60988: StoreField: r2->field_f = r0
    //     0xd60988: stur            w0, [x2, #0xf]
    // 0xd6098c: LoadField: r1 = r0->field_37
    //     0xd6098c: ldur            w1, [x0, #0x37]
    // 0xd60990: DecompressPointer r1
    //     0xd60990: add             x1, x1, HEAP, lsl #32
    // 0xd60994: tbnz            w1, #4, #0xd609a8
    // 0xd60998: r0 = Null
    //     0xd60998: mov             x0, NULL
    // 0xd6099c: LeaveFrame
    //     0xd6099c: mov             SP, fp
    //     0xd609a0: ldp             fp, lr, [SP], #0x10
    // 0xd609a4: ret
    //     0xd609a4: ret             
    // 0xd609a8: r1 = true
    //     0xd609a8: add             x1, NULL, #0x20  ; true
    // 0xd609ac: StoreField: r0->field_3b = r1
    //     0xd609ac: stur            w1, [x0, #0x3b]
    // 0xd609b0: mov             x1, x0
    // 0xd609b4: LoadField: r0 = r1->field_1f
    //     0xd609b4: ldur            w0, [x1, #0x1f]
    // 0xd609b8: DecompressPointer r0
    //     0xd609b8: add             x0, x0, HEAP, lsl #32
    // 0xd609bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd609c0: cmp             w0, w16
    // 0xd609c4: b.ne            #0xd609d4
    // 0xd609c8: r2 = _moveController
    //     0xd609c8: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xd609cc: ldr             x2, [x2, #0x218]
    // 0xd609d0: r0 = InitLateFinalInstanceField()
    //     0xd609d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd609d4: LoadField: r1 = r0->field_2f
    //     0xd609d4: ldur            w1, [x0, #0x2f]
    // 0xd609d8: DecompressPointer r1
    //     0xd609d8: add             x1, x1, HEAP, lsl #32
    // 0xd609dc: cmp             w1, NULL
    // 0xd609e0: b.eq            #0xd60a68
    // 0xd609e4: LoadField: r2 = r1->field_7
    //     0xd609e4: ldur            w2, [x1, #7]
    // 0xd609e8: DecompressPointer r2
    //     0xd609e8: add             x2, x2, HEAP, lsl #32
    // 0xd609ec: cmp             w2, NULL
    // 0xd609f0: b.eq            #0xd60a68
    // 0xd609f4: ldur            x2, [fp, #-8]
    // 0xd609f8: LoadField: r3 = r0->field_37
    //     0xd609f8: ldur            w3, [x0, #0x37]
    // 0xd609fc: DecompressPointer r3
    //     0xd609fc: add             x3, x3, HEAP, lsl #32
    // 0xd60a00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd60a04: cmp             w3, w16
    // 0xd60a08: b.eq            #0xd60ab0
    // 0xd60a0c: mov             x1, x2
    // 0xd60a10: stur            x3, [fp, #-0x18]
    // 0xd60a14: r0 = _overallDragAxisExtent()
    //     0xd60a14: bl              #0xd60700  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_overallDragAxisExtent
    // 0xd60a18: ldur            x0, [fp, #-0x18]
    // 0xd60a1c: LoadField: d1 = r0->field_7
    //     0xd60a1c: ldur            d1, [x0, #7]
    // 0xd60a20: fmul            d2, d1, d0
    // 0xd60a24: ldur            x0, [fp, #-8]
    // 0xd60a28: LoadField: d0 = r0->field_2f
    //     0xd60a28: ldur            d0, [x0, #0x2f]
    // 0xd60a2c: d1 = 0.000000
    //     0xd60a2c: eor             v1.16b, v1.16b, v1.16b
    // 0xd60a30: fcmp            d0, d1
    // 0xd60a34: b.le            #0xd60a40
    // 0xd60a38: d0 = 1.000000
    //     0xd60a38: fmov            d0, #1.00000000
    // 0xd60a3c: b               #0xd60a4c
    // 0xd60a40: fcmp            d1, d0
    // 0xd60a44: b.le            #0xd60a4c
    // 0xd60a48: d0 = -1.000000
    //     0xd60a48: fmov            d0, #-1.00000000
    // 0xd60a4c: fmul            d1, d2, d0
    // 0xd60a50: StoreField: r0->field_2f = d1
    //     0xd60a50: stur            d1, [x0, #0x2f]
    // 0xd60a54: LoadField: r1 = r0->field_1f
    //     0xd60a54: ldur            w1, [x0, #0x1f]
    // 0xd60a58: DecompressPointer r1
    //     0xd60a58: add             x1, x1, HEAP, lsl #32
    // 0xd60a5c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd60a5c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd60a60: r0 = stop()
    //     0xd60a60: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xd60a64: b               #0xd60a7c
    // 0xd60a68: ldur            x3, [fp, #-8]
    // 0xd60a6c: StoreField: r3->field_2f = rZR
    //     0xd60a6c: stur            xzr, [x3, #0x2f]
    // 0xd60a70: mov             x1, x0
    // 0xd60a74: r2 = 0.000000
    //     0xd60a74: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd60a78: r0 = value=()
    //     0xd60a78: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd60a7c: ldur            x2, [fp, #-0x10]
    // 0xd60a80: r1 = Function '<anonymous closure>':.
    //     0xd60a80: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f260] AnonymousClosure: (0xd60784), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDragUpdate (0xd60348)
    //     0xd60a84: ldr             x1, [x1, #0x260]
    // 0xd60a88: r0 = AllocateClosure()
    //     0xd60a88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd60a8c: ldur            x1, [fp, #-8]
    // 0xd60a90: mov             x2, x0
    // 0xd60a94: r0 = setState()
    //     0xd60a94: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd60a98: r0 = Null
    //     0xd60a98: mov             x0, NULL
    // 0xd60a9c: LeaveFrame
    //     0xd60a9c: mov             SP, fp
    //     0xd60aa0: ldp             fp, lr, [SP], #0x10
    // 0xd60aa4: ret
    //     0xd60aa4: ret             
    // 0xd60aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd60aa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd60aac: b               #0xd60974
    // 0xd60ab0: r9 = _value
    //     0xd60ab0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd60ab4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd60ab4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf82a84, size: 0xa8
    // 0xf82a84: EnterFrame
    //     0xf82a84: stp             fp, lr, [SP, #-0x10]!
    //     0xf82a88: mov             fp, SP
    // 0xf82a8c: AllocStack(0x10)
    //     0xf82a8c: sub             SP, SP, #0x10
    // 0xf82a90: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */)
    //     0xf82a90: mov             x0, x1
    //     0xf82a94: stur            x1, [fp, #-8]
    // 0xf82a98: CheckStackOverflow
    //     0xf82a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82a9c: cmp             SP, x16
    //     0xf82aa0: b.ls            #0xf82b24
    // 0xf82aa4: mov             x1, x0
    // 0xf82aa8: r0 = initState()
    //     0xf82aa8: bl              #0xf82b2c  ; [dart:mixin_deduplication] _MixinApplication210&State&TickerProviderStateMixin&AutomaticKeepAliveClientMixin::initState
    // 0xf82aac: ldur            x1, [fp, #-8]
    // 0xf82ab0: LoadField: r0 = r1->field_1f
    //     0xf82ab0: ldur            w0, [x1, #0x1f]
    // 0xf82ab4: DecompressPointer r0
    //     0xf82ab4: add             x0, x0, HEAP, lsl #32
    // 0xf82ab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf82abc: cmp             w0, w16
    // 0xf82ac0: b.ne            #0xf82ad0
    // 0xf82ac4: r2 = _moveController
    //     0xf82ac4: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0xf82ac8: ldr             x2, [x2, #0x218]
    // 0xf82acc: r0 = InitLateFinalInstanceField()
    //     0xf82acc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xf82ad0: ldur            x2, [fp, #-8]
    // 0xf82ad4: r1 = Function '_handleDismissStatusChanged@187238936':.
    //     0xf82ad4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f270] AnonymousClosure: (0xf82ba8), in [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDismissStatusChanged (0xf82be4)
    //     0xf82ad8: ldr             x1, [x1, #0x270]
    // 0xf82adc: stur            x0, [fp, #-0x10]
    // 0xf82ae0: r0 = AllocateClosure()
    //     0xf82ae0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf82ae4: ldur            x1, [fp, #-0x10]
    // 0xf82ae8: mov             x2, x0
    // 0xf82aec: r0 = addStatusListener()
    //     0xf82aec: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf82af0: ldur            x2, [fp, #-8]
    // 0xf82af4: r1 = Function '_handleDismissUpdateValueChanged@187238936':.
    //     0xf82af4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f278] AnonymousClosure: (0xf82b78), of [package:flutter/src/widgets/dismissible.dart] _DismissibleState
    //     0xf82af8: ldr             x1, [x1, #0x278]
    // 0xf82afc: r0 = AllocateClosure()
    //     0xf82afc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf82b00: ldur            x1, [fp, #-0x10]
    // 0xf82b04: mov             x2, x0
    // 0xf82b08: r0 = addListener()
    //     0xf82b08: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf82b0c: ldur            x1, [fp, #-8]
    // 0xf82b10: r0 = _updateMoveAnimation()
    //     0xf82b10: bl              #0xd607cc  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_updateMoveAnimation
    // 0xf82b14: r0 = Null
    //     0xf82b14: mov             x0, NULL
    // 0xf82b18: LeaveFrame
    //     0xf82b18: mov             SP, fp
    //     0xf82b1c: ldp             fp, lr, [SP], #0x10
    // 0xf82b20: ret
    //     0xf82b20: ret             
    // 0xf82b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82b28: b               #0xf82aa4
  }
  [closure] void _handleDismissUpdateValueChanged(dynamic) {
    // ** addr: 0xf82b78, size: 0x30
    // 0xf82b78: ldr             x1, [SP]
    // 0xf82b7c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf82b7c: ldur            w2, [x1, #0x17]
    // 0xf82b80: DecompressPointer r2
    //     0xf82b80: add             x2, x2, HEAP, lsl #32
    // 0xf82b84: LoadField: r1 = r2->field_b
    //     0xf82b84: ldur            w1, [x2, #0xb]
    // 0xf82b88: DecompressPointer r1
    //     0xf82b88: add             x1, x1, HEAP, lsl #32
    // 0xf82b8c: cmp             w1, NULL
    // 0xf82b90: b.eq            #0xf82b9c
    // 0xf82b94: r0 = Null
    //     0xf82b94: mov             x0, NULL
    // 0xf82b98: ret
    //     0xf82b98: ret             
    // 0xf82b9c: EnterFrame
    //     0xf82b9c: stp             fp, lr, [SP, #-0x10]!
    //     0xf82ba0: mov             fp, SP
    // 0xf82ba4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf82ba4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _handleDismissStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xf82ba8, size: 0x3c
    // 0xf82ba8: EnterFrame
    //     0xf82ba8: stp             fp, lr, [SP, #-0x10]!
    //     0xf82bac: mov             fp, SP
    // 0xf82bb0: ldr             x0, [fp, #0x18]
    // 0xf82bb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf82bb4: ldur            w1, [x0, #0x17]
    // 0xf82bb8: DecompressPointer r1
    //     0xf82bb8: add             x1, x1, HEAP, lsl #32
    // 0xf82bbc: CheckStackOverflow
    //     0xf82bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82bc0: cmp             SP, x16
    //     0xf82bc4: b.ls            #0xf82bdc
    // 0xf82bc8: ldr             x2, [fp, #0x10]
    // 0xf82bcc: r0 = _handleDismissStatusChanged()
    //     0xf82bcc: bl              #0xf82be4  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleDismissStatusChanged
    // 0xf82bd0: LeaveFrame
    //     0xf82bd0: mov             SP, fp
    //     0xf82bd4: ldp             fp, lr, [SP], #0x10
    // 0xf82bd8: ret
    //     0xf82bd8: ret             
    // 0xf82bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82be0: b               #0xf82bc8
  }
  _ _handleDismissStatusChanged(/* No info */) async {
    // ** addr: 0xf82be4, size: 0x88
    // 0xf82be4: EnterFrame
    //     0xf82be4: stp             fp, lr, [SP, #-0x10]!
    //     0xf82be8: mov             fp, SP
    // 0xf82bec: AllocStack(0x18)
    //     0xf82bec: sub             SP, SP, #0x18
    // 0xf82bf0: SetupParameters(_DismissibleState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xf82bf0: stur            NULL, [fp, #-8]
    //     0xf82bf4: stur            x1, [fp, #-0x10]
    //     0xf82bf8: stur            x2, [fp, #-0x18]
    // 0xf82bfc: CheckStackOverflow
    //     0xf82bfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82c00: cmp             SP, x16
    //     0xf82c04: b.ls            #0xf82c64
    // 0xf82c08: InitAsync() -> Future<void?>
    //     0xf82c08: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf82c0c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf82c10: ldur            x0, [fp, #-0x18]
    // 0xf82c14: r16 = Instance_AnimationStatus
    //     0xf82c14: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xf82c18: cmp             w0, w16
    // 0xf82c1c: b.ne            #0xf82c44
    // 0xf82c20: ldur            x0, [fp, #-0x10]
    // 0xf82c24: LoadField: r1 = r0->field_3b
    //     0xf82c24: ldur            w1, [x0, #0x3b]
    // 0xf82c28: DecompressPointer r1
    //     0xf82c28: add             x1, x1, HEAP, lsl #32
    // 0xf82c2c: tbz             w1, #4, #0xf82c44
    // 0xf82c30: mov             x1, x0
    // 0xf82c34: r0 = _handleMoveCompleted()
    //     0xf82c34: bl              #0xd6007c  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_handleMoveCompleted
    // 0xf82c38: mov             x1, x0
    // 0xf82c3c: stur            x1, [fp, #-0x18]
    // 0xf82c40: r0 = Await()
    //     0xf82c40: bl              #0x7f5c00  ; AwaitStub
    // 0xf82c44: ldur            x1, [fp, #-0x10]
    // 0xf82c48: LoadField: r0 = r1->field_f
    //     0xf82c48: ldur            w0, [x1, #0xf]
    // 0xf82c4c: DecompressPointer r0
    //     0xf82c4c: add             x0, x0, HEAP, lsl #32
    // 0xf82c50: cmp             w0, NULL
    // 0xf82c54: b.eq            #0xf82c5c
    // 0xf82c58: r0 = updateKeepAlive()
    //     0xf82c58: bl              #0xf82c6c  ; [dart:mixin_deduplication] _MixinApplication210&State&TickerProviderStateMixin&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0xf82c5c: r0 = Null
    //     0xf82c5c: mov             x0, NULL
    // 0xf82c60: r0 = ReturnAsyncNotFuture()
    //     0xf82c60: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf82c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf82c64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf82c68: b               #0xf82c08
  }
  _ _DismissibleState(/* No info */) {
    // ** addr: 0xfa39c4, size: 0x68
    // 0xfa39c4: EnterFrame
    //     0xfa39c4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa39c8: mov             fp, SP
    // 0xfa39cc: AllocStack(0x8)
    //     0xfa39cc: sub             SP, SP, #8
    // 0xfa39d0: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa39d4: r0 = false
    //     0xfa39d4: add             x0, NULL, #0x30  ; false
    // 0xfa39d8: mov             x3, x1
    // 0xfa39dc: stur            x1, [fp, #-8]
    // 0xfa39e0: StoreField: r3->field_1f = r2
    //     0xfa39e0: stur            w2, [x3, #0x1f]
    // 0xfa39e4: StoreField: r3->field_23 = r2
    //     0xfa39e4: stur            w2, [x3, #0x23]
    // 0xfa39e8: StoreField: r3->field_2f = rZR
    //     0xfa39e8: stur            xzr, [x3, #0x2f]
    // 0xfa39ec: StoreField: r3->field_37 = r0
    //     0xfa39ec: stur            w0, [x3, #0x37]
    // 0xfa39f0: StoreField: r3->field_3b = r0
    //     0xfa39f0: stur            w0, [x3, #0x3b]
    // 0xfa39f4: r1 = <State<StatefulWidget>>
    //     0xfa39f4: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa39f8: r0 = LabeledGlobalKey()
    //     0xfa39f8: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa39fc: ldur            x1, [fp, #-8]
    // 0xfa3a00: StoreField: r1->field_3f = r0
    //     0xfa3a00: stur            w0, [x1, #0x3f]
    //     0xfa3a04: ldurb           w16, [x1, #-1]
    //     0xfa3a08: ldurb           w17, [x0, #-1]
    //     0xfa3a0c: and             x16, x17, x16, lsr #2
    //     0xfa3a10: tst             x16, HEAP, lsr #32
    //     0xfa3a14: b.eq            #0xfa3a1c
    //     0xfa3a18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3a1c: r0 = Null
    //     0xfa3a1c: mov             x0, NULL
    // 0xfa3a20: LeaveFrame
    //     0xfa3a20: mov             SP, fp
    //     0xfa3a24: ldp             fp, lr, [SP], #0x10
    // 0xfa3a28: ret
    //     0xfa3a28: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10def14, size: 0x6c
    // 0x10def14: EnterFrame
    //     0x10def14: stp             fp, lr, [SP, #-0x10]!
    //     0x10def18: mov             fp, SP
    // 0x10def1c: AllocStack(0x8)
    //     0x10def1c: sub             SP, SP, #8
    // 0x10def20: SetupParameters(_DismissibleState this /* r1 => r0, fp-0x8 */)
    //     0x10def20: mov             x0, x1
    //     0x10def24: stur            x1, [fp, #-8]
    // 0x10def28: CheckStackOverflow
    //     0x10def28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10def2c: cmp             SP, x16
    //     0x10def30: b.ls            #0x10def78
    // 0x10def34: mov             x1, x0
    // 0x10def38: LoadField: r0 = r1->field_1f
    //     0x10def38: ldur            w0, [x1, #0x1f]
    // 0x10def3c: DecompressPointer r0
    //     0x10def3c: add             x0, x0, HEAP, lsl #32
    // 0x10def40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10def44: cmp             w0, w16
    // 0x10def48: b.ne            #0x10def58
    // 0x10def4c: r2 = _moveController
    //     0x10def4c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f218] Field <_DismissibleState@187238936._moveController@187238936>: late final (offset: 0x20)
    //     0x10def50: ldr             x2, [x2, #0x218]
    // 0x10def54: r0 = InitLateFinalInstanceField()
    //     0x10def54: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10def58: mov             x1, x0
    // 0x10def5c: r0 = dispose()
    //     0x10def5c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10def60: ldur            x1, [fp, #-8]
    // 0x10def64: r0 = dispose()
    //     0x10def64: bl              #0x10def80  ; [dart:mixin_deduplication] _MixinApplication209&State&TickerProviderStateMixin::dispose
    // 0x10def68: r0 = Null
    //     0x10def68: mov             x0, NULL
    // 0x10def6c: LeaveFrame
    //     0x10def6c: mov             SP, fp
    //     0x10def70: ldp             fp, lr, [SP], #0x10
    // 0x10def74: ret
    //     0x10def74: ret             
    // 0x10def78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10def78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10def7c: b               #0x10def34
  }
}

// class id: 6398, size: 0x44, field offset: 0xc
//   const constructor, 
class Dismissible extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa397c, size: 0x48
    // 0xfa397c: EnterFrame
    //     0xfa397c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3980: mov             fp, SP
    // 0xfa3984: AllocStack(0x8)
    //     0xfa3984: sub             SP, SP, #8
    // 0xfa3988: CheckStackOverflow
    //     0xfa3988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa398c: cmp             SP, x16
    //     0xfa3990: b.ls            #0xfa39bc
    // 0xfa3994: r1 = <Dismissible>
    //     0xfa3994: add             x1, PP, #0x82, lsl #12  ; [pp+0x828c0] TypeArguments: <Dismissible>
    //     0xfa3998: ldr             x1, [x1, #0x8c0]
    // 0xfa399c: r0 = _DismissibleState()
    //     0xfa399c: bl              #0xfa3a2c  ; Allocate_DismissibleStateStub -> _DismissibleState (size=0x44)
    // 0xfa39a0: mov             x1, x0
    // 0xfa39a4: stur            x0, [fp, #-8]
    // 0xfa39a8: r0 = _DismissibleState()
    //     0xfa39a8: bl              #0xfa39c4  ; [package:flutter/src/widgets/dismissible.dart] _DismissibleState::_DismissibleState
    // 0xfa39ac: ldur            x0, [fp, #-8]
    // 0xfa39b0: LeaveFrame
    //     0xfa39b0: mov             SP, fp
    //     0xfa39b4: ldp             fp, lr, [SP], #0x10
    // 0xfa39b8: ret
    //     0xfa39b8: ret             
    // 0xfa39bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa39bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa39c0: b               #0xfa3994
  }
}

// class id: 8186, size: 0x14, field offset: 0x14
enum _FlingGestureKind extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abea4, size: 0x64
    // 0x11abea4: EnterFrame
    //     0x11abea4: stp             fp, lr, [SP, #-0x10]!
    //     0x11abea8: mov             fp, SP
    // 0x11abeac: AllocStack(0x10)
    //     0x11abeac: sub             SP, SP, #0x10
    // 0x11abeb0: SetupParameters(_FlingGestureKind this /* r1 => r0, fp-0x8 */)
    //     0x11abeb0: mov             x0, x1
    //     0x11abeb4: stur            x1, [fp, #-8]
    // 0x11abeb8: CheckStackOverflow
    //     0x11abeb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abebc: cmp             SP, x16
    //     0x11abec0: b.ls            #0x11abf00
    // 0x11abec4: r1 = Null
    //     0x11abec4: mov             x1, NULL
    // 0x11abec8: r2 = 4
    //     0x11abec8: mov             x2, #4
    // 0x11abecc: r0 = AllocateArray()
    //     0x11abecc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abed0: r16 = "_FlingGestureKind."
    //     0x11abed0: add             x16, PP, #0x98, lsl #12  ; [pp+0x98d10] "_FlingGestureKind."
    //     0x11abed4: ldr             x16, [x16, #0xd10]
    // 0x11abed8: StoreField: r0->field_f = r16
    //     0x11abed8: stur            w16, [x0, #0xf]
    // 0x11abedc: ldur            x1, [fp, #-8]
    // 0x11abee0: LoadField: r2 = r1->field_f
    //     0x11abee0: ldur            w2, [x1, #0xf]
    // 0x11abee4: DecompressPointer r2
    //     0x11abee4: add             x2, x2, HEAP, lsl #32
    // 0x11abee8: StoreField: r0->field_13 = r2
    //     0x11abee8: stur            w2, [x0, #0x13]
    // 0x11abeec: str             x0, [SP]
    // 0x11abef0: r0 = _interpolate()
    //     0x11abef0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abef4: LeaveFrame
    //     0x11abef4: mov             SP, fp
    //     0x11abef8: ldp             fp, lr, [SP], #0x10
    // 0x11abefc: ret
    //     0x11abefc: ret             
    // 0x11abf00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abf00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abf04: b               #0x11abec4
  }
}

// class id: 8187, size: 0x14, field offset: 0x14
enum DismissDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abe40, size: 0x64
    // 0x11abe40: EnterFrame
    //     0x11abe40: stp             fp, lr, [SP, #-0x10]!
    //     0x11abe44: mov             fp, SP
    // 0x11abe48: AllocStack(0x10)
    //     0x11abe48: sub             SP, SP, #0x10
    // 0x11abe4c: SetupParameters(DismissDirection this /* r1 => r0, fp-0x8 */)
    //     0x11abe4c: mov             x0, x1
    //     0x11abe50: stur            x1, [fp, #-8]
    // 0x11abe54: CheckStackOverflow
    //     0x11abe54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abe58: cmp             SP, x16
    //     0x11abe5c: b.ls            #0x11abe9c
    // 0x11abe60: r1 = Null
    //     0x11abe60: mov             x1, NULL
    // 0x11abe64: r2 = 4
    //     0x11abe64: mov             x2, #4
    // 0x11abe68: r0 = AllocateArray()
    //     0x11abe68: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abe6c: r16 = "DismissDirection."
    //     0x11abe6c: add             x16, PP, #0x82, lsl #12  ; [pp+0x828c8] "DismissDirection."
    //     0x11abe70: ldr             x16, [x16, #0x8c8]
    // 0x11abe74: StoreField: r0->field_f = r16
    //     0x11abe74: stur            w16, [x0, #0xf]
    // 0x11abe78: ldur            x1, [fp, #-8]
    // 0x11abe7c: LoadField: r2 = r1->field_f
    //     0x11abe7c: ldur            w2, [x1, #0xf]
    // 0x11abe80: DecompressPointer r2
    //     0x11abe80: add             x2, x2, HEAP, lsl #32
    // 0x11abe84: StoreField: r0->field_13 = r2
    //     0x11abe84: stur            w2, [x0, #0x13]
    // 0x11abe88: str             x0, [SP]
    // 0x11abe8c: r0 = _interpolate()
    //     0x11abe8c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abe90: LeaveFrame
    //     0x11abe90: mov             SP, fp
    //     0x11abe94: ldp             fp, lr, [SP], #0x10
    // 0x11abe98: ret
    //     0x11abe98: ret             
    // 0x11abe9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abe9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abea0: b               #0x11abe60
  }
}
