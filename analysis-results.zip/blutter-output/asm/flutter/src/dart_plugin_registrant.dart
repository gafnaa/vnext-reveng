// lib: , url: package:flutter/src/dart_plugin_registrant.dart

// class id: 1048792, size: 0x8
class :: {

  static late final const String dartPluginRegistrantLibrary; // offset: 0x1110

  const String dartPluginRegistrantLibrary() {
    // ** addr: 0x13e5364, size: 0x8
    // 0x13e5364: r0 = "file:///D:/Flutter%20Project/simaster-mahasiswa/.dart_tool/flutter_build/dart_plugin_registrant.dart"
    //     0x13e5364: ldr             x0, [PP, #0x6238]  ; [pp+0x6238] "file:///D:/Flutter%20Project/simaster-mahasiswa/.dart_tool/flutter_build/dart_plugin_registrant.dart"
    // 0x13e5368: ret
    //     0x13e5368: ret             
  }
}
