// lib: , url: package:flutter/src/foundation/basic_types.dart

// class id: 1048797, size: 0x8
class :: {
}

// class id: 3243, size: 0x10, field offset: 0x8
//   const constructor, 
class Factory<X0> extends Object {
}
