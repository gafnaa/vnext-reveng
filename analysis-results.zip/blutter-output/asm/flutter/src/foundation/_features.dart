// lib: , url: package:flutter/src/foundation/_features.dart

// class id: 1048794, size: 0x8
class :: {

  static late bool isWindowingEnabled; // offset: 0x878
  static late final Set<String> debugEnabledFeatureFlags; // offset: 0x87c

  static bool isWindowingEnabled() {
    // ** addr: 0x83a3d0, size: 0x50
    // 0x83a3d0: EnterFrame
    //     0x83a3d0: stp             fp, lr, [SP, #-0x10]!
    //     0x83a3d4: mov             fp, SP
    // 0x83a3d8: CheckStackOverflow
    //     0x83a3d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83a3dc: cmp             SP, x16
    //     0x83a3e0: b.ls            #0x83a418
    // 0x83a3e4: r0 = LoadStaticField(0x87c)
    //     0x83a3e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83a3e8: ldr             x0, [x0, #0x10f8]
    // 0x83a3ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83a3f0: cmp             w0, w16
    // 0x83a3f4: b.ne            #0x83a400
    // 0x83a3f8: r2 = debugEnabledFeatureFlags
    //     0x83a3f8: ldr             x2, [PP, #0x1b90]  ; [pp+0x1b90] Field <::.debugEnabledFeatureFlags>: static late final (offset: 0x87c)
    // 0x83a3fc: r0 = InitLateFinalStaticField()
    //     0x83a3fc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x83a400: mov             x1, x0
    // 0x83a404: r2 = "windowing"
    //     0x83a404: ldr             x2, [PP, #0x1b98]  ; [pp+0x1b98] "windowing"
    // 0x83a408: r0 = contains()
    //     0x83a408: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x83a40c: LeaveFrame
    //     0x83a40c: mov             SP, fp
    //     0x83a410: ldp             fp, lr, [SP], #0x10
    // 0x83a414: ret
    //     0x83a414: ret             
    // 0x83a418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a41c: b               #0x83a3e4
  }
  static Set<String> debugEnabledFeatureFlags() {
    // ** addr: 0x83a420, size: 0x40
    // 0x83a420: EnterFrame
    //     0x83a420: stp             fp, lr, [SP, #-0x10]!
    //     0x83a424: mov             fp, SP
    // 0x83a428: CheckStackOverflow
    //     0x83a428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83a42c: cmp             SP, x16
    //     0x83a430: b.ls            #0x83a458
    // 0x83a434: r1 = ""
    //     0x83a434: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x83a438: r2 = 44
    //     0x83a438: mov             x2, #0x2c
    // 0x83a43c: r0 = _splitWithCharCode()
    //     0x83a43c: bl              #0x83a4c8  ; [dart:core] _OneByteString::_splitWithCharCode
    // 0x83a440: mov             x2, x0
    // 0x83a444: r1 = <String>
    //     0x83a444: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x83a448: r0 = LinkedHashSet.of()
    //     0x83a448: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0x83a44c: LeaveFrame
    //     0x83a44c: mov             SP, fp
    //     0x83a450: ldp             fp, lr, [SP], #0x10
    // 0x83a454: ret
    //     0x83a454: ret             
    // 0x83a458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a458: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a45c: b               #0x83a434
  }
}
