// lib: , url: package:flutter/src/foundation/_isolates_io.dart

// class id: 1048795, size: 0x8
class :: {

  static Future<Y1> compute<Y0, Y1>((dynamic, Y0) => FutureOr<Y1>, Y0, String?) async {
    // ** addr: 0x846d98, size: 0x14c
    // 0x846d98: EnterFrame
    //     0x846d98: stp             fp, lr, [SP, #-0x10]!
    //     0x846d9c: mov             fp, SP
    // 0x846da0: AllocStack(0x48)
    //     0x846da0: sub             SP, SP, #0x48
    // 0x846da4: SetupParameters(dynamic _ /* r1, fp-0x28 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x846da4: stur            NULL, [fp, #-8]
    //     0x846da8: mov             x0, #0
    //     0x846dac: add             x1, fp, w0, sxtw #2
    //     0x846db0: ldr             x1, [x1, #0x20]
    //     0x846db4: stur            x1, [fp, #-0x28]
    //     0x846db8: add             x2, fp, w0, sxtw #2
    //     0x846dbc: ldr             x2, [x2, #0x18]
    //     0x846dc0: stur            x2, [fp, #-0x20]
    //     0x846dc4: add             x3, fp, w0, sxtw #2
    //     0x846dc8: ldr             x3, [x3, #0x10]
    //     0x846dcc: stur            x3, [fp, #-0x18]
    // 0x846dd0: LoadField: r0 = r4->field_f
    //     0x846dd0: ldur            w0, [x4, #0xf]
    // 0x846dd4: cbnz            w0, #0x846de0
    // 0x846dd8: r0 = Null
    //     0x846dd8: mov             x0, NULL
    // 0x846ddc: b               #0x846df0
    // 0x846de0: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x846de0: ldur            w0, [x4, #0x17]
    // 0x846de4: add             x4, fp, w0, sxtw #2
    // 0x846de8: ldr             x4, [x4, #0x10]
    // 0x846dec: mov             x0, x4
    // 0x846df0: stur            x0, [fp, #-0x10]
    // 0x846df4: CheckStackOverflow
    //     0x846df4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846df8: cmp             SP, x16
    //     0x846dfc: b.ls            #0x846edc
    // 0x846e00: r1 = 2
    //     0x846e00: mov             x1, #2
    // 0x846e04: r0 = AllocateContext()
    //     0x846e04: bl              #0x13de838  ; AllocateContextStub
    // 0x846e08: mov             x4, x0
    // 0x846e0c: ldur            x0, [fp, #-0x28]
    // 0x846e10: stur            x4, [fp, #-0x30]
    // 0x846e14: StoreField: r4->field_f = r0
    //     0x846e14: stur            w0, [x4, #0xf]
    // 0x846e18: ldur            x0, [fp, #-0x20]
    // 0x846e1c: StoreField: r4->field_13 = r0
    //     0x846e1c: stur            w0, [x4, #0x13]
    // 0x846e20: ldur            x1, [fp, #-0x10]
    // 0x846e24: r2 = Null
    //     0x846e24: mov             x2, NULL
    // 0x846e28: r3 = <Y1>
    //     0x846e28: ldr             x3, [PP, #0x3740]  ; [pp+0x3740] TypeArguments: <Y1>
    // 0x846e2c: r0 = Null
    //     0x846e2c: mov             x0, NULL
    // 0x846e30: cmp             x2, x0
    // 0x846e34: b.ne            #0x846e40
    // 0x846e38: cmp             x1, x0
    // 0x846e3c: b.eq            #0x846e4c
    // 0x846e40: r30 = InstantiateTypeArgumentsStub
    //     0x846e40: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x846e44: LoadField: r30 = r30->field_7
    //     0x846e44: ldur            lr, [lr, #7]
    // 0x846e48: blr             lr
    // 0x846e4c: mov             x1, x0
    // 0x846e50: stur            x1, [fp, #-0x20]
    // 0x846e54: r0 = InitAsync()
    //     0x846e54: bl              #0x7f5e44  ; InitAsyncStub
    // 0x846e58: ldur            x0, [fp, #-0x18]
    // 0x846e5c: cmp             w0, NULL
    // 0x846e60: b.ne            #0x846e6c
    // 0x846e64: r4 = "compute"
    //     0x846e64: ldr             x4, [PP, #0x3748]  ; [pp+0x3748] "compute"
    // 0x846e68: b               #0x846e70
    // 0x846e6c: mov             x4, x0
    // 0x846e70: ldur            x0, [fp, #-0x10]
    // 0x846e74: mov             x1, x0
    // 0x846e78: stur            x4, [fp, #-0x18]
    // 0x846e7c: r2 = Null
    //     0x846e7c: mov             x2, NULL
    // 0x846e80: r3 = <Y1>
    //     0x846e80: ldr             x3, [PP, #0x3740]  ; [pp+0x3740] TypeArguments: <Y1>
    // 0x846e84: r0 = Null
    //     0x846e84: mov             x0, NULL
    // 0x846e88: cmp             x2, x0
    // 0x846e8c: b.ne            #0x846e98
    // 0x846e90: cmp             x1, x0
    // 0x846e94: b.eq            #0x846ea4
    // 0x846e98: r30 = InstantiateTypeArgumentsStub
    //     0x846e98: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x846e9c: LoadField: r30 = r30->field_7
    //     0x846e9c: ldur            lr, [lr, #7]
    // 0x846ea0: blr             lr
    // 0x846ea4: ldur            x2, [fp, #-0x30]
    // 0x846ea8: r1 = Function '<anonymous closure>': static.
    //     0x846ea8: ldr             x1, [PP, #0x3750]  ; [pp+0x3750] AnonymousClosure: static (0x8480b4), in [package:flutter/src/foundation/_isolates_io.dart] ::compute (0x846d98)
    // 0x846eac: stur            x0, [fp, #-0x20]
    // 0x846eb0: r0 = AllocateClosure()
    //     0x846eb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x846eb4: mov             x1, x0
    // 0x846eb8: ldur            x0, [fp, #-0x10]
    // 0x846ebc: StoreField: r1->field_b = r0
    //     0x846ebc: stur            w0, [x1, #0xb]
    // 0x846ec0: ldur            x16, [fp, #-0x20]
    // 0x846ec4: stp             x1, x16, [SP, #8]
    // 0x846ec8: ldur            x16, [fp, #-0x18]
    // 0x846ecc: str             x16, [SP]
    // 0x846ed0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x846ed0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x846ed4: r0 = run()
    //     0x846ed4: bl              #0x846ee4  ; [dart:isolate] Isolate::run
    // 0x846ed8: r0 = ReturnAsync()
    //     0x846ed8: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x846edc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846edc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846ee0: b               #0x846e00
  }
  [closure] static FutureOr<Y1> <anonymous closure>(dynamic) {
    // ** addr: 0x8480b4, size: 0x58
    // 0x8480b4: EnterFrame
    //     0x8480b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8480b8: mov             fp, SP
    // 0x8480bc: AllocStack(0x10)
    //     0x8480bc: sub             SP, SP, #0x10
    // 0x8480c0: SetupParameters([dynamic _ /* r0 */])
    //     0x8480c0: ldr             x0, [fp, #0x10]
    //     0x8480c4: ldur            w1, [x0, #0x17]
    //     0x8480c8: add             x1, x1, HEAP, lsl #32
    // 0x8480cc: CheckStackOverflow
    //     0x8480cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8480d0: cmp             SP, x16
    //     0x8480d4: b.ls            #0x848104
    // 0x8480d8: LoadField: r0 = r1->field_f
    //     0x8480d8: ldur            w0, [x1, #0xf]
    // 0x8480dc: DecompressPointer r0
    //     0x8480dc: add             x0, x0, HEAP, lsl #32
    // 0x8480e0: LoadField: r2 = r1->field_13
    //     0x8480e0: ldur            w2, [x1, #0x13]
    // 0x8480e4: DecompressPointer r2
    //     0x8480e4: add             x2, x2, HEAP, lsl #32
    // 0x8480e8: stp             x2, x0, [SP]
    // 0x8480ec: ClosureCall
    //     0x8480ec: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8480f0: ldur            x2, [x0, #0x1f]
    //     0x8480f4: blr             x2
    // 0x8480f8: LeaveFrame
    //     0x8480f8: mov             SP, fp
    //     0x8480fc: ldp             fp, lr, [SP], #0x10
    // 0x848100: ret
    //     0x848100: ret             
    // 0x848104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848108: b               #0x8480d8
  }
}
