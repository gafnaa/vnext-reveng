// lib: , url: package:flutter/src/foundation/diagnostics.dart

// class id: 1048802, size: 0x8
class :: {

  static String shortHash(Object?) {
    // ** addr: 0x858904, size: 0x78
    // 0x858904: EnterFrame
    //     0x858904: stp             fp, lr, [SP, #-0x10]!
    //     0x858908: mov             fp, SP
    // 0x85890c: AllocStack(0x8)
    //     0x85890c: sub             SP, SP, #8
    // 0x858910: CheckStackOverflow
    //     0x858910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858914: cmp             SP, x16
    //     0x858918: b.ls            #0x858974
    // 0x85891c: r0 = 60
    //     0x85891c: mov             x0, #0x3c
    // 0x858920: branchIfSmi(r1, 0x85892c)
    //     0x858920: tbz             w1, #0, #0x85892c
    // 0x858924: r0 = LoadClassIdInstr(r1)
    //     0x858924: ldur            x0, [x1, #-1]
    //     0x858928: ubfx            x0, x0, #0xc, #0x14
    // 0x85892c: str             x1, [SP]
    // 0x858930: r0 = GDT[cid_x0 + 0x70de]()
    //     0x858930: mov             x17, #0x70de
    //     0x858934: add             lr, x0, x17
    //     0x858938: ldr             lr, [x21, lr, lsl #3]
    //     0x85893c: blr             lr
    // 0x858940: r1 = LoadInt32Instr(r0)
    //     0x858940: sbfx            x1, x0, #1, #0x1f
    //     0x858944: tbz             w0, #0, #0x85894c
    //     0x858948: ldur            x1, [x0, #7]
    // 0x85894c: and             w0, w1, #0xfffff
    // 0x858950: lsl             w1, w0, #1
    // 0x858954: r0 = _toPow2String()
    //     0x858954: bl              #0x8589a8  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x858958: mov             x1, x0
    // 0x85895c: r2 = 5
    //     0x85895c: mov             x2, #5
    // 0x858960: r3 = "0"
    //     0x858960: ldr             x3, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0x858964: r0 = padLeft()
    //     0x858964: bl              #0x13db774  ; [dart:core] _OneByteString::padLeft
    // 0x858968: LeaveFrame
    //     0x858968: mov             SP, fp
    //     0x85896c: ldp             fp, lr, [SP], #0x10
    // 0x858970: ret
    //     0x858970: ret             
    // 0x858974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858978: b               #0x85891c
  }
  static String describeIdentity(Object?) {
    // ** addr: 0x1115914, size: 0x94
    // 0x1115914: EnterFrame
    //     0x1115914: stp             fp, lr, [SP, #-0x10]!
    //     0x1115918: mov             fp, SP
    // 0x111591c: AllocStack(0x18)
    //     0x111591c: sub             SP, SP, #0x18
    // 0x1115920: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x1115920: mov             x0, x1
    //     0x1115924: stur            x1, [fp, #-8]
    // 0x1115928: CheckStackOverflow
    //     0x1115928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x111592c: cmp             SP, x16
    //     0x1115930: b.ls            #0x11159a0
    // 0x1115934: r1 = Null
    //     0x1115934: mov             x1, NULL
    // 0x1115938: r2 = 6
    //     0x1115938: mov             x2, #6
    // 0x111593c: r0 = AllocateArray()
    //     0x111593c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1115940: stur            x0, [fp, #-0x10]
    // 0x1115944: r16 = "<optimized out>"
    //     0x1115944: add             x16, PP, #0xe, lsl #12  ; [pp+0xe358] "<optimized out>"
    //     0x1115948: ldr             x16, [x16, #0x358]
    // 0x111594c: StoreField: r0->field_f = r16
    //     0x111594c: stur            w16, [x0, #0xf]
    // 0x1115950: r16 = "#"
    //     0x1115950: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0x1115954: StoreField: r0->field_13 = r16
    //     0x1115954: stur            w16, [x0, #0x13]
    // 0x1115958: ldur            x1, [fp, #-8]
    // 0x111595c: r0 = shortHash()
    //     0x111595c: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0x1115960: ldur            x1, [fp, #-0x10]
    // 0x1115964: ArrayStore: r1[2] = r0  ; List_4
    //     0x1115964: add             x25, x1, #0x17
    //     0x1115968: str             w0, [x25]
    //     0x111596c: tbz             w0, #0, #0x1115988
    //     0x1115970: ldurb           w16, [x1, #-1]
    //     0x1115974: ldurb           w17, [x0, #-1]
    //     0x1115978: and             x16, x17, x16, lsr #2
    //     0x111597c: tst             x16, HEAP, lsr #32
    //     0x1115980: b.eq            #0x1115988
    //     0x1115984: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1115988: ldur            x16, [fp, #-0x10]
    // 0x111598c: str             x16, [SP]
    // 0x1115990: r0 = _interpolate()
    //     0x1115990: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115994: LeaveFrame
    //     0x1115994: mov             SP, fp
    //     0x1115998: ldp             fp, lr, [SP], #0x10
    // 0x111599c: ret
    //     0x111599c: ret             
    // 0x11159a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11159a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11159a4: b               #0x1115934
  }
}

// class id: 3210, size: 0x8, field offset: 0x8
abstract class DiagnosticsNode extends Object {

  factory _ DiagnosticsNode.message(/* No info */) {
    // ** addr: 0x82bc28, size: 0x40
    // 0x82bc28: EnterFrame
    //     0x82bc28: stp             fp, lr, [SP, #-0x10]!
    //     0x82bc2c: mov             fp, SP
    // 0x82bc30: mov             x0, x1
    // 0x82bc34: r1 = <void?>
    //     0x82bc34: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x82bc38: r0 = DiagnosticsProperty()
    //     0x82bc38: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x82bc3c: r1 = Instance__NoDefaultValue
    //     0x82bc3c: ldr             x1, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x82bc40: StoreField: r0->field_23 = r1
    //     0x82bc40: stur            w1, [x0, #0x23]
    // 0x82bc44: r1 = false
    //     0x82bc44: add             x1, NULL, #0x30  ; false
    // 0x82bc48: StoreField: r0->field_13 = r1
    //     0x82bc48: stur            w1, [x0, #0x13]
    // 0x82bc4c: r1 = true
    //     0x82bc4c: add             x1, NULL, #0x20  ; true
    // 0x82bc50: StoreField: r0->field_1b = r1
    //     0x82bc50: stur            w1, [x0, #0x1b]
    // 0x82bc54: r1 = Instance_DiagnosticLevel
    //     0x82bc54: ldr             x1, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x82bc58: StoreField: r0->field_27 = r1
    //     0x82bc58: stur            w1, [x0, #0x27]
    // 0x82bc5c: LeaveFrame
    //     0x82bc5c: mov             SP, fp
    //     0x82bc60: ldp             fp, lr, [SP], #0x10
    // 0x82bc64: ret
    //     0x82bc64: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0x1115470, size: 0x5c
    // 0x1115470: EnterFrame
    //     0x1115470: stp             fp, lr, [SP, #-0x10]!
    //     0x1115474: mov             fp, SP
    // 0x1115478: AllocStack(0x8)
    //     0x1115478: sub             SP, SP, #8
    // 0x111547c: SetupParameters(DiagnosticsNode this /* r0 */, {dynamic minLevel})
    //     0x111547c: ldur            w0, [x4, #0x13]
    //     0x1115480: sub             x1, x0, #2
    //     0x1115484: add             x0, fp, w1, sxtw #2
    //     0x1115488: ldr             x0, [x0, #0x10]
    //     0x111548c: ldur            w1, [x4, #0x1f]
    //     0x1115490: add             x1, x1, HEAP, lsl #32
    //     0x1115494: add             x16, PP, #0xe, lsl #12  ; [pp+0xe360] "minLevel"
    //     0x1115498: ldr             x16, [x16, #0x360]
    //     0x111549c: cmp             w1, w16
    //     0x11154a0: b.eq            #0x11154a4
    // 0x11154a4: CheckStackOverflow
    //     0x11154a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11154a8: cmp             SP, x16
    //     0x11154ac: b.ls            #0x11154c4
    // 0x11154b0: str             x0, [SP]
    // 0x11154b4: r0 = toString()
    //     0x11154b4: bl              #0x112b118  ; [dart:core] Object::toString
    // 0x11154b8: LeaveFrame
    //     0x11154b8: mov             SP, fp
    //     0x11154bc: ldp             fp, lr, [SP], #0x10
    // 0x11154c0: ret
    //     0x11154c0: ret             
    // 0x11154c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11154c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11154c8: b               #0x11154b0
  }
}

// class id: 3211, size: 0x10, field offset: 0x8
class DiagnosticableNode<X0 bound Diagnosticable> extends DiagnosticsNode {
}

// class id: 3213, size: 0x10, field offset: 0x10
class DiagnosticableTreeNode extends DiagnosticableNode<dynamic> {
}

// class id: 3216, size: 0x10, field offset: 0x8
class DiagnosticsBlock extends DiagnosticsNode {
}

// class id: 3218, size: 0x2c, field offset: 0x8
class DiagnosticsProperty<X0> extends DiagnosticsNode {
}

// class id: 3229, size: 0x2c, field offset: 0x2c
abstract class _NumProperty<X0 bound num> extends DiagnosticsProperty<X0 bound num> {
}

// class id: 3230, size: 0x2c, field offset: 0x2c
class IntProperty extends _NumProperty<dynamic> {
}

// class id: 3241, size: 0x8, field offset: 0x8
//   const constructor, 
class _NoDefaultValue extends Object {
}

// class id: 4645, size: 0x8, field offset: 0x8
abstract class DiagnosticableTreeMixin extends Object
    implements DiagnosticableTree {
}

// class id: 4976, size: 0x8, field offset: 0x8
abstract class Diagnosticable extends Object {
}

// class id: 5784, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DiagnosticableTree extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 8316, size: 0x14, field offset: 0x14
enum DiagnosticLevel extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a97fc, size: 0x64
    // 0x11a97fc: EnterFrame
    //     0x11a97fc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9800: mov             fp, SP
    // 0x11a9804: AllocStack(0x10)
    //     0x11a9804: sub             SP, SP, #0x10
    // 0x11a9808: SetupParameters(DiagnosticLevel this /* r1 => r0, fp-0x8 */)
    //     0x11a9808: mov             x0, x1
    //     0x11a980c: stur            x1, [fp, #-8]
    // 0x11a9810: CheckStackOverflow
    //     0x11a9810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9814: cmp             SP, x16
    //     0x11a9818: b.ls            #0x11a9858
    // 0x11a981c: r1 = Null
    //     0x11a981c: mov             x1, NULL
    // 0x11a9820: r2 = 4
    //     0x11a9820: mov             x2, #4
    // 0x11a9824: r0 = AllocateArray()
    //     0x11a9824: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9828: r16 = "DiagnosticLevel."
    //     0x11a9828: add             x16, PP, #0x11, lsl #12  ; [pp+0x110d8] "DiagnosticLevel."
    //     0x11a982c: ldr             x16, [x16, #0xd8]
    // 0x11a9830: StoreField: r0->field_f = r16
    //     0x11a9830: stur            w16, [x0, #0xf]
    // 0x11a9834: ldur            x1, [fp, #-8]
    // 0x11a9838: LoadField: r2 = r1->field_f
    //     0x11a9838: ldur            w2, [x1, #0xf]
    // 0x11a983c: DecompressPointer r2
    //     0x11a983c: add             x2, x2, HEAP, lsl #32
    // 0x11a9840: StoreField: r0->field_13 = r2
    //     0x11a9840: stur            w2, [x0, #0x13]
    // 0x11a9844: str             x0, [SP]
    // 0x11a9848: r0 = _interpolate()
    //     0x11a9848: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a984c: LeaveFrame
    //     0x11a984c: mov             SP, fp
    //     0x11a9850: ldp             fp, lr, [SP], #0x10
    // 0x11a9854: ret
    //     0x11a9854: ret             
    // 0x11a9858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a985c: b               #0x11a981c
  }
}
