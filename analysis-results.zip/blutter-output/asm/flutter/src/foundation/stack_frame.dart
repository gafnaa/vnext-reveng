// lib: , url: package:flutter/src/foundation/stack_frame.dart

// class id: 1048812, size: 0x8
class :: {
}

// class id: 3187, size: 0x34, field offset: 0x8
//   const constructor, 
class StackFrame extends Object {

  _OneByteString field_8;
  _Mint field_c;
  _OneByteString field_14;
  _OneByteString field_18;
  _Mint field_1c;
  _Mint field_24;
  _OneByteString field_2c;
  _OneByteString field_30;
  static late final RegExp _webNonDebugFramePattern; // offset: 0xbe8

  static _ fromStackString(/* No info */) {
    // ** addr: 0x82d624, size: 0x174
    // 0x82d624: EnterFrame
    //     0x82d624: stp             fp, lr, [SP, #-0x10]!
    //     0x82d628: mov             fp, SP
    // 0x82d62c: AllocStack(0x28)
    //     0x82d62c: sub             SP, SP, #0x28
    // 0x82d630: CheckStackOverflow
    //     0x82d630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d634: cmp             SP, x16
    //     0x82d638: b.ls            #0x82d790
    // 0x82d63c: r0 = trim()
    //     0x82d63c: bl              #0x808ff4  ; [dart:core] _StringBase::trim
    // 0x82d640: r1 = LoadClassIdInstr(r0)
    //     0x82d640: ldur            x1, [x0, #-1]
    //     0x82d644: ubfx            x1, x1, #0xc, #0x14
    // 0x82d648: mov             x16, x0
    // 0x82d64c: mov             x0, x1
    // 0x82d650: mov             x1, x16
    // 0x82d654: r2 = "\n"
    //     0x82d654: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82d658: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82d658: sub             lr, x0, #0xffe
    //     0x82d65c: ldr             lr, [x21, lr, lsl #3]
    //     0x82d660: blr             lr
    // 0x82d664: r1 = Function '<anonymous closure>': static.
    //     0x82d664: ldr             x1, [PP, #0xf48]  ; [pp+0xf48] AnonymousClosure: static (0x82e244), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x82d624)
    // 0x82d668: r2 = Null
    //     0x82d668: mov             x2, NULL
    // 0x82d66c: stur            x0, [fp, #-8]
    // 0x82d670: r0 = AllocateClosure()
    //     0x82d670: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x82d674: ldur            x1, [fp, #-8]
    // 0x82d678: mov             x2, x0
    // 0x82d67c: r0 = where()
    //     0x82d67c: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x82d680: r16 = <StackFrame?>
    //     0x82d680: ldr             x16, [PP, #0xf50]  ; [pp+0xf50] TypeArguments: <StackFrame?>
    // 0x82d684: stp             x0, x16, [SP, #8]
    // 0x82d688: r16 = Closure: (String) => StackFrame? from Function 'fromStackTraceLine': static.
    //     0x82d688: ldr             x16, [PP, #0xf58]  ; [pp+0xf58] Closure: (String) => StackFrame? from Function 'fromStackTraceLine': static. (0x7f2ada714798)
    // 0x82d68c: str             x16, [SP]
    // 0x82d690: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82d690: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82d694: r0 = map()
    //     0x82d694: bl              #0xb00654  ; [dart:_internal] WhereIterable::map
    // 0x82d698: r16 = <StackFrame>
    //     0x82d698: ldr             x16, [PP, #0xf60]  ; [pp+0xf60] TypeArguments: <StackFrame>
    // 0x82d69c: stp             x0, x16, [SP]
    // 0x82d6a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x82d6a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x82d6a4: r0 = whereType()
    //     0x82d6a4: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x82d6a8: mov             x3, x0
    // 0x82d6ac: stur            x3, [fp, #-0x10]
    // 0x82d6b0: LoadField: r4 = r3->field_7
    //     0x82d6b0: ldur            w4, [x3, #7]
    // 0x82d6b4: DecompressPointer r4
    //     0x82d6b4: add             x4, x4, HEAP, lsl #32
    // 0x82d6b8: mov             x0, x3
    // 0x82d6bc: stur            x4, [fp, #-8]
    // 0x82d6c0: r2 = Null
    //     0x82d6c0: mov             x2, NULL
    // 0x82d6c4: r1 = Null
    //     0x82d6c4: mov             x1, NULL
    // 0x82d6c8: cmp             w0, NULL
    // 0x82d6cc: b.eq            #0x82d758
    // 0x82d6d0: branchIfSmi(r0, 0x82d758)
    //     0x82d6d0: tbz             w0, #0, #0x82d758
    // 0x82d6d4: r3 = LoadClassIdInstr(r0)
    //     0x82d6d4: ldur            x3, [x0, #-1]
    //     0x82d6d8: ubfx            x3, x3, #0xc, #0x14
    // 0x82d6dc: r17 = 7724
    //     0x82d6dc: mov             x17, #0x1e2c
    // 0x82d6e0: cmp             x3, x17
    // 0x82d6e4: b.eq            #0x82d760
    // 0x82d6e8: r4 = LoadClassIdInstr(r0)
    //     0x82d6e8: ldur            x4, [x0, #-1]
    //     0x82d6ec: ubfx            x4, x4, #0xc, #0x14
    // 0x82d6f0: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x82d6f4: ldr             x3, [x3, #0x18]
    // 0x82d6f8: ldr             x3, [x3, x4, lsl #3]
    // 0x82d6fc: LoadField: r3 = r3->field_2b
    //     0x82d6fc: ldur            w3, [x3, #0x2b]
    // 0x82d700: DecompressPointer r3
    //     0x82d700: add             x3, x3, HEAP, lsl #32
    // 0x82d704: cmp             w3, NULL
    // 0x82d708: b.eq            #0x82d758
    // 0x82d70c: LoadField: r3 = r3->field_f
    //     0x82d70c: ldur            w3, [x3, #0xf]
    // 0x82d710: lsr             x3, x3, #3
    // 0x82d714: r17 = 7724
    //     0x82d714: mov             x17, #0x1e2c
    // 0x82d718: cmp             x3, x17
    // 0x82d71c: b.eq            #0x82d760
    // 0x82d720: r3 = SubtypeTestCache
    //     0x82d720: ldr             x3, [PP, #0xf70]  ; [pp+0xf70] SubtypeTestCache
    // 0x82d724: r30 = Subtype1TestCacheStub
    //     0x82d724: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x82d728: LoadField: r30 = r30->field_7
    //     0x82d728: ldur            lr, [lr, #7]
    // 0x82d72c: blr             lr
    // 0x82d730: cmp             w7, NULL
    // 0x82d734: b.eq            #0x82d740
    // 0x82d738: tbnz            w7, #4, #0x82d758
    // 0x82d73c: b               #0x82d760
    // 0x82d740: r8 = EfficientLengthIterable
    //     0x82d740: ldr             x8, [PP, #0xf78]  ; [pp+0xf78] Type: EfficientLengthIterable
    // 0x82d744: r3 = SubtypeTestCache
    //     0x82d744: ldr             x3, [PP, #0xf80]  ; [pp+0xf80] SubtypeTestCache
    // 0x82d748: r30 = InstanceOfStub
    //     0x82d748: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x82d74c: LoadField: r30 = r30->field_7
    //     0x82d74c: ldur            lr, [lr, #7]
    // 0x82d750: blr             lr
    // 0x82d754: b               #0x82d764
    // 0x82d758: r0 = false
    //     0x82d758: add             x0, NULL, #0x30  ; false
    // 0x82d75c: b               #0x82d764
    // 0x82d760: r0 = true
    //     0x82d760: add             x0, NULL, #0x20  ; true
    // 0x82d764: tbnz            w0, #4, #0x82d778
    // 0x82d768: ldur            x1, [fp, #-8]
    // 0x82d76c: ldur            x2, [fp, #-0x10]
    // 0x82d770: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x82d770: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x82d774: b               #0x82d784
    // 0x82d778: ldur            x1, [fp, #-8]
    // 0x82d77c: ldur            x2, [fp, #-0x10]
    // 0x82d780: r0 = _GrowableList._ofOther()
    //     0x82d780: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x82d784: LeaveFrame
    //     0x82d784: mov             SP, fp
    //     0x82d788: ldp             fp, lr, [SP], #0x10
    // 0x82d78c: ret
    //     0x82d78c: ret             
    // 0x82d790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d794: b               #0x82d63c
  }
  [closure] static StackFrame? fromStackTraceLine(dynamic, String) {
    // ** addr: 0x82d798, size: 0x30
    // 0x82d798: EnterFrame
    //     0x82d798: stp             fp, lr, [SP, #-0x10]!
    //     0x82d79c: mov             fp, SP
    // 0x82d7a0: CheckStackOverflow
    //     0x82d7a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d7a4: cmp             SP, x16
    //     0x82d7a8: b.ls            #0x82d7c0
    // 0x82d7ac: ldr             x1, [fp, #0x10]
    // 0x82d7b0: r0 = fromStackTraceLine()
    //     0x82d7b0: bl              #0x82d7c8  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackTraceLine
    // 0x82d7b4: LeaveFrame
    //     0x82d7b4: mov             SP, fp
    //     0x82d7b8: ldp             fp, lr, [SP], #0x10
    // 0x82d7bc: ret
    //     0x82d7bc: ret             
    // 0x82d7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d7c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d7c4: b               #0x82d7ac
  }
  static _ fromStackTraceLine(/* No info */) {
    // ** addr: 0x82d7c8, size: 0x620
    // 0x82d7c8: EnterFrame
    //     0x82d7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x82d7cc: mov             fp, SP
    // 0x82d7d0: AllocStack(0x88)
    //     0x82d7d0: sub             SP, SP, #0x88
    // 0x82d7d4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x82d7d4: stur            x1, [fp, #-8]
    // 0x82d7d8: CheckStackOverflow
    //     0x82d7d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d7dc: cmp             SP, x16
    //     0x82d7e0: b.ls            #0x82ddac
    // 0x82d7e4: r0 = LoadClassIdInstr(r1)
    //     0x82d7e4: ldur            x0, [x1, #-1]
    //     0x82d7e8: ubfx            x0, x0, #0xc, #0x14
    // 0x82d7ec: r16 = "<asynchronous suspension>"
    //     0x82d7ec: ldr             x16, [PP, #0xf88]  ; [pp+0xf88] "<asynchronous suspension>"
    // 0x82d7f0: stp             x16, x1, [SP]
    // 0x82d7f4: mov             lr, x0
    // 0x82d7f8: ldr             lr, [x21, lr, lsl #3]
    // 0x82d7fc: blr             lr
    // 0x82d800: tbnz            w0, #4, #0x82d814
    // 0x82d804: r0 = Instance_StackFrame
    //     0x82d804: ldr             x0, [PP, #0xf90]  ; [pp+0xf90] Obj!StackFrame@129f1e1
    // 0x82d808: LeaveFrame
    //     0x82d808: mov             SP, fp
    //     0x82d80c: ldp             fp, lr, [SP], #0x10
    // 0x82d810: ret
    //     0x82d810: ret             
    // 0x82d814: ldur            x1, [fp, #-8]
    // 0x82d818: r0 = LoadClassIdInstr(r1)
    //     0x82d818: ldur            x0, [x1, #-1]
    //     0x82d81c: ubfx            x0, x0, #0xc, #0x14
    // 0x82d820: r16 = "..."
    //     0x82d820: ldr             x16, [PP, #0xf98]  ; [pp+0xf98] "..."
    // 0x82d824: stp             x16, x1, [SP]
    // 0x82d828: mov             lr, x0
    // 0x82d82c: ldr             lr, [x21, lr, lsl #3]
    // 0x82d830: blr             lr
    // 0x82d834: tbnz            w0, #4, #0x82d848
    // 0x82d838: r0 = Instance_StackFrame
    //     0x82d838: ldr             x0, [PP, #0xfa0]  ; [pp+0xfa0] Obj!StackFrame@129f1a1
    // 0x82d83c: LeaveFrame
    //     0x82d83c: mov             SP, fp
    //     0x82d840: ldp             fp, lr, [SP], #0x10
    // 0x82d844: ret
    //     0x82d844: ret             
    // 0x82d848: ldur            x1, [fp, #-8]
    // 0x82d84c: r2 = "#"
    //     0x82d84c: ldr             x2, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0x82d850: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82d850: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82d854: r0 = startsWith()
    //     0x82d854: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0x82d858: tbz             w0, #4, #0x82d870
    // 0x82d85c: ldur            x1, [fp, #-8]
    // 0x82d860: r0 = _tryParseWebNonDebugFrame()
    //     0x82d860: bl              #0x82e094  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::_tryParseWebNonDebugFrame
    // 0x82d864: LeaveFrame
    //     0x82d864: mov             SP, fp
    //     0x82d868: ldp             fp, lr, [SP], #0x10
    // 0x82d86c: ret
    //     0x82d86c: ret             
    // 0x82d870: r16 = "^#(\\d+) +(.+) \\((.+\?):\?(\\d+){0,1}:\?(\\d+){0,1}\\)$"
    //     0x82d870: ldr             x16, [PP, #0xfa8]  ; [pp+0xfa8] "^#(\\d+) +(.+) \\((.+\?):\?(\\d+){0,1}:\?(\\d+){0,1}\\)$"
    // 0x82d874: stp             x16, NULL, [SP, #0x20]
    // 0x82d878: r16 = false
    //     0x82d878: add             x16, NULL, #0x30  ; false
    // 0x82d87c: r30 = true
    //     0x82d87c: add             lr, NULL, #0x20  ; true
    // 0x82d880: stp             lr, x16, [SP, #0x10]
    // 0x82d884: r16 = false
    //     0x82d884: add             x16, NULL, #0x30  ; false
    // 0x82d888: r30 = false
    //     0x82d888: add             lr, NULL, #0x30  ; false
    // 0x82d88c: stp             lr, x16, [SP]
    // 0x82d890: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x82d890: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x82d894: r0 = _RegExp()
    //     0x82d894: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x82d898: mov             x1, x0
    // 0x82d89c: ldur            x2, [fp, #-8]
    // 0x82d8a0: r0 = firstMatch()
    //     0x82d8a0: bl              #0x82e014  ; [dart:core] _RegExp::firstMatch
    // 0x82d8a4: stur            x0, [fp, #-0x10]
    // 0x82d8a8: cmp             w0, NULL
    // 0x82d8ac: b.eq            #0x82ddb4
    // 0x82d8b0: mov             x1, x0
    // 0x82d8b4: r2 = 4
    //     0x82d8b4: mov             x2, #4
    // 0x82d8b8: r0 = []()
    //     0x82d8b8: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82d8bc: cmp             w0, NULL
    // 0x82d8c0: b.eq            #0x82ddb8
    // 0x82d8c4: mov             x1, x0
    // 0x82d8c8: r2 = ".<anonymous closure>"
    //     0x82d8c8: ldr             x2, [PP, #0xfb0]  ; [pp+0xfb0] ".<anonymous closure>"
    // 0x82d8cc: r3 = ""
    //     0x82d8cc: ldr             x3, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82d8d0: r0 = replaceAll()
    //     0x82d8d0: bl              #0x7eb6a4  ; [dart:core] _StringBase::replaceAll
    // 0x82d8d4: mov             x1, x0
    // 0x82d8d8: r2 = "new"
    //     0x82d8d8: ldr             x2, [PP, #0xfb8]  ; [pp+0xfb8] "new"
    // 0x82d8dc: stur            x0, [fp, #-0x18]
    // 0x82d8e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82d8e0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82d8e4: r0 = startsWith()
    //     0x82d8e4: bl              #0x7ea4f0  ; [dart:core] _StringBase::startsWith
    // 0x82d8e8: tbnz            w0, #4, #0x82da14
    // 0x82d8ec: ldur            x3, [fp, #-0x18]
    // 0x82d8f0: r0 = LoadClassIdInstr(r3)
    //     0x82d8f0: ldur            x0, [x3, #-1]
    //     0x82d8f4: ubfx            x0, x0, #0xc, #0x14
    // 0x82d8f8: mov             x1, x3
    // 0x82d8fc: r2 = " "
    //     0x82d8fc: ldr             x2, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82d900: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82d900: sub             lr, x0, #0xffe
    //     0x82d904: ldr             lr, [x21, lr, lsl #3]
    //     0x82d908: blr             lr
    // 0x82d90c: LoadField: r1 = r0->field_b
    //     0x82d90c: ldur            w1, [x0, #0xb]
    // 0x82d910: r0 = LoadInt32Instr(r1)
    //     0x82d910: sbfx            x0, x1, #1, #0x1f
    // 0x82d914: cmp             x0, #1
    // 0x82d918: b.le            #0x82d970
    // 0x82d91c: ldur            x3, [fp, #-0x18]
    // 0x82d920: r0 = LoadClassIdInstr(r3)
    //     0x82d920: ldur            x0, [x3, #-1]
    //     0x82d924: ubfx            x0, x0, #0xc, #0x14
    // 0x82d928: mov             x1, x3
    // 0x82d92c: r2 = " "
    //     0x82d92c: ldr             x2, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82d930: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82d930: sub             lr, x0, #0xffe
    //     0x82d934: ldr             lr, [x21, lr, lsl #3]
    //     0x82d938: blr             lr
    // 0x82d93c: mov             x2, x0
    // 0x82d940: LoadField: r0 = r2->field_b
    //     0x82d940: ldur            w0, [x2, #0xb]
    // 0x82d944: r1 = LoadInt32Instr(r0)
    //     0x82d944: sbfx            x1, x0, #1, #0x1f
    // 0x82d948: mov             x0, x1
    // 0x82d94c: r1 = 1
    //     0x82d94c: mov             x1, #1
    // 0x82d950: cmp             x1, x0
    // 0x82d954: b.hs            #0x82ddbc
    // 0x82d958: LoadField: r0 = r2->field_f
    //     0x82d958: ldur            w0, [x2, #0xf]
    // 0x82d95c: DecompressPointer r0
    //     0x82d95c: add             x0, x0, HEAP, lsl #32
    // 0x82d960: LoadField: r1 = r0->field_13
    //     0x82d960: ldur            w1, [x0, #0x13]
    // 0x82d964: DecompressPointer r1
    //     0x82d964: add             x1, x1, HEAP, lsl #32
    // 0x82d968: mov             x3, x1
    // 0x82d96c: b               #0x82d974
    // 0x82d970: r3 = "<unknown>"
    //     0x82d970: ldr             x3, [PP, #0xfc0]  ; [pp+0xfc0] "<unknown>"
    // 0x82d974: stur            x3, [fp, #-0x20]
    // 0x82d978: r0 = LoadClassIdInstr(r3)
    //     0x82d978: ldur            x0, [x3, #-1]
    //     0x82d97c: ubfx            x0, x0, #0xc, #0x14
    // 0x82d980: mov             x1, x3
    // 0x82d984: r2 = "."
    //     0x82d984: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82d988: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82d988: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82d98c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82d98c: sub             lr, x0, #1, lsl #12
    //     0x82d990: ldr             lr, [x21, lr, lsl #3]
    //     0x82d994: blr             lr
    // 0x82d998: tbnz            w0, #4, #0x82da04
    // 0x82d99c: ldur            x1, [fp, #-0x20]
    // 0x82d9a0: r0 = LoadClassIdInstr(r1)
    //     0x82d9a0: ldur            x0, [x1, #-1]
    //     0x82d9a4: ubfx            x0, x0, #0xc, #0x14
    // 0x82d9a8: r2 = "."
    //     0x82d9a8: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82d9ac: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82d9ac: sub             lr, x0, #0xffe
    //     0x82d9b0: ldr             lr, [x21, lr, lsl #3]
    //     0x82d9b4: blr             lr
    // 0x82d9b8: mov             x2, x0
    // 0x82d9bc: LoadField: r0 = r2->field_b
    //     0x82d9bc: ldur            w0, [x2, #0xb]
    // 0x82d9c0: r3 = LoadInt32Instr(r0)
    //     0x82d9c0: sbfx            x3, x0, #1, #0x1f
    // 0x82d9c4: mov             x0, x3
    // 0x82d9c8: r1 = 0
    //     0x82d9c8: mov             x1, #0
    // 0x82d9cc: cmp             x1, x0
    // 0x82d9d0: b.hs            #0x82ddc0
    // 0x82d9d4: LoadField: r4 = r2->field_f
    //     0x82d9d4: ldur            w4, [x2, #0xf]
    // 0x82d9d8: DecompressPointer r4
    //     0x82d9d8: add             x4, x4, HEAP, lsl #32
    // 0x82d9dc: LoadField: r2 = r4->field_f
    //     0x82d9dc: ldur            w2, [x4, #0xf]
    // 0x82d9e0: DecompressPointer r2
    //     0x82d9e0: add             x2, x2, HEAP, lsl #32
    // 0x82d9e4: mov             x0, x3
    // 0x82d9e8: r1 = 1
    //     0x82d9e8: mov             x1, #1
    // 0x82d9ec: cmp             x1, x0
    // 0x82d9f0: b.hs            #0x82ddc4
    // 0x82d9f4: LoadField: r0 = r4->field_13
    //     0x82d9f4: ldur            w0, [x4, #0x13]
    // 0x82d9f8: DecompressPointer r0
    //     0x82d9f8: add             x0, x0, HEAP, lsl #32
    // 0x82d9fc: mov             x1, x2
    // 0x82da00: b               #0x82da0c
    // 0x82da04: ldur            x1, [fp, #-0x20]
    // 0x82da08: r0 = ""
    //     0x82da08: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82da0c: mov             x3, x1
    // 0x82da10: b               #0x82dab4
    // 0x82da14: ldur            x3, [fp, #-0x18]
    // 0x82da18: r0 = LoadClassIdInstr(r3)
    //     0x82da18: ldur            x0, [x3, #-1]
    //     0x82da1c: ubfx            x0, x0, #0xc, #0x14
    // 0x82da20: mov             x1, x3
    // 0x82da24: r2 = "."
    //     0x82da24: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82da28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82da28: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82da2c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82da2c: sub             lr, x0, #1, lsl #12
    //     0x82da30: ldr             lr, [x21, lr, lsl #3]
    //     0x82da34: blr             lr
    // 0x82da38: tbnz            w0, #4, #0x82daa4
    // 0x82da3c: ldur            x1, [fp, #-0x18]
    // 0x82da40: r0 = LoadClassIdInstr(r1)
    //     0x82da40: ldur            x0, [x1, #-1]
    //     0x82da44: ubfx            x0, x0, #0xc, #0x14
    // 0x82da48: r2 = "."
    //     0x82da48: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82da4c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82da4c: sub             lr, x0, #0xffe
    //     0x82da50: ldr             lr, [x21, lr, lsl #3]
    //     0x82da54: blr             lr
    // 0x82da58: mov             x2, x0
    // 0x82da5c: LoadField: r0 = r2->field_b
    //     0x82da5c: ldur            w0, [x2, #0xb]
    // 0x82da60: r3 = LoadInt32Instr(r0)
    //     0x82da60: sbfx            x3, x0, #1, #0x1f
    // 0x82da64: mov             x0, x3
    // 0x82da68: r1 = 0
    //     0x82da68: mov             x1, #0
    // 0x82da6c: cmp             x1, x0
    // 0x82da70: b.hs            #0x82ddc8
    // 0x82da74: LoadField: r4 = r2->field_f
    //     0x82da74: ldur            w4, [x2, #0xf]
    // 0x82da78: DecompressPointer r4
    //     0x82da78: add             x4, x4, HEAP, lsl #32
    // 0x82da7c: LoadField: r2 = r4->field_f
    //     0x82da7c: ldur            w2, [x4, #0xf]
    // 0x82da80: DecompressPointer r2
    //     0x82da80: add             x2, x2, HEAP, lsl #32
    // 0x82da84: mov             x0, x3
    // 0x82da88: r1 = 1
    //     0x82da88: mov             x1, #1
    // 0x82da8c: cmp             x1, x0
    // 0x82da90: b.hs            #0x82ddcc
    // 0x82da94: LoadField: r0 = r4->field_13
    //     0x82da94: ldur            w0, [x4, #0x13]
    // 0x82da98: DecompressPointer r0
    //     0x82da98: add             x0, x0, HEAP, lsl #32
    // 0x82da9c: mov             x1, x2
    // 0x82daa0: b               #0x82dab0
    // 0x82daa4: ldur            x1, [fp, #-0x18]
    // 0x82daa8: mov             x0, x1
    // 0x82daac: r1 = ""
    //     0x82daac: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82dab0: mov             x3, x1
    // 0x82dab4: ldur            x1, [fp, #-0x10]
    // 0x82dab8: stur            x3, [fp, #-0x18]
    // 0x82dabc: stur            x0, [fp, #-0x20]
    // 0x82dac0: r2 = 6
    //     0x82dac0: mov             x2, #6
    // 0x82dac4: r0 = []()
    //     0x82dac4: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dac8: cmp             w0, NULL
    // 0x82dacc: b.eq            #0x82ddd0
    // 0x82dad0: mov             x1, x0
    // 0x82dad4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82dad4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82dad8: r0 = parse()
    //     0x82dad8: bl              #0x7f6fc0  ; [dart:core] Uri::parse
    // 0x82dadc: mov             x2, x0
    // 0x82dae0: stur            x2, [fp, #-0x28]
    // 0x82dae4: r0 = LoadClassIdInstr(r2)
    //     0x82dae4: ldur            x0, [x2, #-1]
    //     0x82dae8: ubfx            x0, x0, #0xc, #0x14
    // 0x82daec: mov             x1, x2
    // 0x82daf0: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x82daf0: sub             lr, x0, #0xfe0
    //     0x82daf4: ldr             lr, [x21, lr, lsl #3]
    //     0x82daf8: blr             lr
    // 0x82dafc: ldur            x2, [fp, #-0x28]
    // 0x82db00: r0 = LoadClassIdInstr(r2)
    //     0x82db00: ldur            x0, [x2, #-1]
    //     0x82db04: ubfx            x0, x0, #0xc, #0x14
    // 0x82db08: mov             x1, x2
    // 0x82db0c: r0 = GDT[cid_x0 + -0xf55]()
    //     0x82db0c: sub             lr, x0, #0xf55
    //     0x82db10: ldr             lr, [x21, lr, lsl #3]
    //     0x82db14: blr             lr
    // 0x82db18: r1 = LoadClassIdInstr(r0)
    //     0x82db18: ldur            x1, [x0, #-1]
    //     0x82db1c: ubfx            x1, x1, #0xc, #0x14
    // 0x82db20: r16 = "dart"
    //     0x82db20: ldr             x16, [PP, #0xfd0]  ; [pp+0xfd0] "dart"
    // 0x82db24: stp             x16, x0, [SP]
    // 0x82db28: mov             x0, x1
    // 0x82db2c: mov             lr, x0
    // 0x82db30: ldr             lr, [x21, lr, lsl #3]
    // 0x82db34: blr             lr
    // 0x82db38: tbz             w0, #4, #0x82db7c
    // 0x82db3c: ldur            x2, [fp, #-0x28]
    // 0x82db40: r0 = LoadClassIdInstr(r2)
    //     0x82db40: ldur            x0, [x2, #-1]
    //     0x82db44: ubfx            x0, x0, #0xc, #0x14
    // 0x82db48: mov             x1, x2
    // 0x82db4c: r0 = GDT[cid_x0 + -0xf55]()
    //     0x82db4c: sub             lr, x0, #0xf55
    //     0x82db50: ldr             lr, [x21, lr, lsl #3]
    //     0x82db54: blr             lr
    // 0x82db58: r1 = LoadClassIdInstr(r0)
    //     0x82db58: ldur            x1, [x0, #-1]
    //     0x82db5c: ubfx            x1, x1, #0xc, #0x14
    // 0x82db60: r16 = "package"
    //     0x82db60: ldr             x16, [PP, #0xfd8]  ; [pp+0xfd8] "package"
    // 0x82db64: stp             x16, x0, [SP]
    // 0x82db68: mov             x0, x1
    // 0x82db6c: mov             lr, x0
    // 0x82db70: ldr             lr, [x21, lr, lsl #3]
    // 0x82db74: blr             lr
    // 0x82db78: tbnz            w0, #4, #0x82dc6c
    // 0x82db7c: ldur            x2, [fp, #-0x28]
    // 0x82db80: r0 = LoadClassIdInstr(r2)
    //     0x82db80: ldur            x0, [x2, #-1]
    //     0x82db84: ubfx            x0, x0, #0xc, #0x14
    // 0x82db88: mov             x1, x2
    // 0x82db8c: r0 = GDT[cid_x0 + -0xb93]()
    //     0x82db8c: sub             lr, x0, #0xb93
    //     0x82db90: ldr             lr, [x21, lr, lsl #3]
    //     0x82db94: blr             lr
    // 0x82db98: mov             x2, x0
    // 0x82db9c: LoadField: r0 = r2->field_b
    //     0x82db9c: ldur            w0, [x2, #0xb]
    // 0x82dba0: r1 = LoadInt32Instr(r0)
    //     0x82dba0: sbfx            x1, x0, #1, #0x1f
    // 0x82dba4: mov             x0, x1
    // 0x82dba8: r1 = 0
    //     0x82dba8: mov             x1, #0
    // 0x82dbac: cmp             x1, x0
    // 0x82dbb0: b.hs            #0x82ddd4
    // 0x82dbb4: LoadField: r3 = r2->field_f
    //     0x82dbb4: ldur            w3, [x2, #0xf]
    // 0x82dbb8: DecompressPointer r3
    //     0x82dbb8: add             x3, x3, HEAP, lsl #32
    // 0x82dbbc: ldur            x2, [fp, #-0x28]
    // 0x82dbc0: stur            x3, [fp, #-0x30]
    // 0x82dbc4: r0 = LoadClassIdInstr(r2)
    //     0x82dbc4: ldur            x0, [x2, #-1]
    //     0x82dbc8: ubfx            x0, x0, #0xc, #0x14
    // 0x82dbcc: mov             x1, x2
    // 0x82dbd0: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x82dbd0: sub             lr, x0, #0xfe0
    //     0x82dbd4: ldr             lr, [x21, lr, lsl #3]
    //     0x82dbd8: blr             lr
    // 0x82dbdc: mov             x3, x0
    // 0x82dbe0: ldur            x2, [fp, #-0x28]
    // 0x82dbe4: stur            x3, [fp, #-0x38]
    // 0x82dbe8: r0 = LoadClassIdInstr(r2)
    //     0x82dbe8: ldur            x0, [x2, #-1]
    //     0x82dbec: ubfx            x0, x0, #0xc, #0x14
    // 0x82dbf0: mov             x1, x2
    // 0x82dbf4: r0 = GDT[cid_x0 + -0xb93]()
    //     0x82dbf4: sub             lr, x0, #0xb93
    //     0x82dbf8: ldr             lr, [x21, lr, lsl #3]
    //     0x82dbfc: blr             lr
    // 0x82dc00: mov             x2, x0
    // 0x82dc04: LoadField: r0 = r2->field_b
    //     0x82dc04: ldur            w0, [x2, #0xb]
    // 0x82dc08: r1 = LoadInt32Instr(r0)
    //     0x82dc08: sbfx            x1, x0, #1, #0x1f
    // 0x82dc0c: mov             x0, x1
    // 0x82dc10: r1 = 0
    //     0x82dc10: mov             x1, #0
    // 0x82dc14: cmp             x1, x0
    // 0x82dc18: b.hs            #0x82ddd8
    // 0x82dc1c: LoadField: r0 = r2->field_f
    //     0x82dc1c: ldur            w0, [x2, #0xf]
    // 0x82dc20: DecompressPointer r0
    //     0x82dc20: add             x0, x0, HEAP, lsl #32
    // 0x82dc24: stur            x0, [fp, #-0x40]
    // 0x82dc28: r1 = Null
    //     0x82dc28: mov             x1, NULL
    // 0x82dc2c: r2 = 4
    //     0x82dc2c: mov             x2, #4
    // 0x82dc30: r0 = AllocateArray()
    //     0x82dc30: bl              #0x13df928  ; AllocateArrayStub
    // 0x82dc34: mov             x1, x0
    // 0x82dc38: ldur            x0, [fp, #-0x40]
    // 0x82dc3c: StoreField: r1->field_f = r0
    //     0x82dc3c: stur            w0, [x1, #0xf]
    // 0x82dc40: r16 = "/"
    //     0x82dc40: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0x82dc44: StoreField: r1->field_13 = r16
    //     0x82dc44: stur            w16, [x1, #0x13]
    // 0x82dc48: str             x1, [SP]
    // 0x82dc4c: r0 = _interpolate()
    //     0x82dc4c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82dc50: ldur            x1, [fp, #-0x38]
    // 0x82dc54: mov             x2, x0
    // 0x82dc58: r3 = ""
    //     0x82dc58: ldr             x3, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82dc5c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x82dc5c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x82dc60: r0 = replaceFirst()
    //     0x82dc60: bl              #0x82ddf4  ; [dart:core] _StringBase::replaceFirst
    // 0x82dc64: ldur            x3, [fp, #-0x30]
    // 0x82dc68: b               #0x82dc70
    // 0x82dc6c: r3 = "<unknown>"
    //     0x82dc6c: ldr             x3, [PP, #0xfc0]  ; [pp+0xfc0] "<unknown>"
    // 0x82dc70: ldur            x0, [fp, #-0x28]
    // 0x82dc74: ldur            x1, [fp, #-0x10]
    // 0x82dc78: stur            x3, [fp, #-0x30]
    // 0x82dc7c: r2 = 2
    //     0x82dc7c: mov             x2, #2
    // 0x82dc80: r0 = []()
    //     0x82dc80: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dc84: cmp             w0, NULL
    // 0x82dc88: b.eq            #0x82dddc
    // 0x82dc8c: mov             x1, x0
    // 0x82dc90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82dc90: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82dc94: r0 = parse()
    //     0x82dc94: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x82dc98: mov             x2, x0
    // 0x82dc9c: ldur            x1, [fp, #-0x28]
    // 0x82dca0: stur            x2, [fp, #-0x48]
    // 0x82dca4: r0 = LoadClassIdInstr(r1)
    //     0x82dca4: ldur            x0, [x1, #-1]
    //     0x82dca8: ubfx            x0, x0, #0xc, #0x14
    // 0x82dcac: r0 = GDT[cid_x0 + -0xf55]()
    //     0x82dcac: sub             lr, x0, #0xf55
    //     0x82dcb0: ldr             lr, [x21, lr, lsl #3]
    //     0x82dcb4: blr             lr
    // 0x82dcb8: ldur            x1, [fp, #-0x10]
    // 0x82dcbc: r2 = 8
    //     0x82dcbc: mov             x2, #8
    // 0x82dcc0: stur            x0, [fp, #-0x28]
    // 0x82dcc4: r0 = []()
    //     0x82dcc4: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dcc8: cmp             w0, NULL
    // 0x82dccc: b.ne            #0x82dcd8
    // 0x82dcd0: r0 = -1
    //     0x82dcd0: mov             x0, #-1
    // 0x82dcd4: b               #0x82dcf8
    // 0x82dcd8: ldur            x1, [fp, #-0x10]
    // 0x82dcdc: r2 = 8
    //     0x82dcdc: mov             x2, #8
    // 0x82dce0: r0 = []()
    //     0x82dce0: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dce4: cmp             w0, NULL
    // 0x82dce8: b.eq            #0x82dde0
    // 0x82dcec: mov             x1, x0
    // 0x82dcf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82dcf0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82dcf4: r0 = parse()
    //     0x82dcf4: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x82dcf8: ldur            x1, [fp, #-0x10]
    // 0x82dcfc: stur            x0, [fp, #-0x50]
    // 0x82dd00: r2 = 10
    //     0x82dd00: mov             x2, #0xa
    // 0x82dd04: r0 = []()
    //     0x82dd04: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dd08: cmp             w0, NULL
    // 0x82dd0c: b.ne            #0x82dd18
    // 0x82dd10: r7 = -1
    //     0x82dd10: mov             x7, #-1
    // 0x82dd14: b               #0x82dd3c
    // 0x82dd18: ldur            x1, [fp, #-0x10]
    // 0x82dd1c: r2 = 10
    //     0x82dd1c: mov             x2, #0xa
    // 0x82dd20: r0 = []()
    //     0x82dd20: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82dd24: cmp             w0, NULL
    // 0x82dd28: b.eq            #0x82dde4
    // 0x82dd2c: mov             x1, x0
    // 0x82dd30: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82dd30: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82dd34: r0 = parse()
    //     0x82dd34: bl              #0x8220cc  ; [dart:core] int::parse
    // 0x82dd38: mov             x7, x0
    // 0x82dd3c: ldur            x6, [fp, #-8]
    // 0x82dd40: ldur            x5, [fp, #-0x18]
    // 0x82dd44: ldur            x4, [fp, #-0x20]
    // 0x82dd48: ldur            x3, [fp, #-0x30]
    // 0x82dd4c: ldur            x2, [fp, #-0x48]
    // 0x82dd50: ldur            x1, [fp, #-0x28]
    // 0x82dd54: ldur            x0, [fp, #-0x50]
    // 0x82dd58: stur            x7, [fp, #-0x58]
    // 0x82dd5c: r0 = StackFrame()
    //     0x82dd5c: bl              #0x82dde8  ; AllocateStackFrameStub -> StackFrame (size=0x34)
    // 0x82dd60: ldur            x1, [fp, #-0x48]
    // 0x82dd64: StoreField: r0->field_b = r1
    //     0x82dd64: stur            x1, [x0, #0xb]
    // 0x82dd68: ldur            x1, [fp, #-0x58]
    // 0x82dd6c: StoreField: r0->field_23 = r1
    //     0x82dd6c: stur            x1, [x0, #0x23]
    // 0x82dd70: ldur            x1, [fp, #-0x50]
    // 0x82dd74: StoreField: r0->field_1b = r1
    //     0x82dd74: stur            x1, [x0, #0x1b]
    // 0x82dd78: ldur            x1, [fp, #-0x28]
    // 0x82dd7c: StoreField: r0->field_13 = r1
    //     0x82dd7c: stur            w1, [x0, #0x13]
    // 0x82dd80: ldur            x1, [fp, #-0x30]
    // 0x82dd84: ArrayStore: r0[0] = r1  ; List_4
    //     0x82dd84: stur            w1, [x0, #0x17]
    // 0x82dd88: ldur            x1, [fp, #-0x18]
    // 0x82dd8c: StoreField: r0->field_2b = r1
    //     0x82dd8c: stur            w1, [x0, #0x2b]
    // 0x82dd90: ldur            x1, [fp, #-0x20]
    // 0x82dd94: StoreField: r0->field_2f = r1
    //     0x82dd94: stur            w1, [x0, #0x2f]
    // 0x82dd98: ldur            x1, [fp, #-8]
    // 0x82dd9c: StoreField: r0->field_7 = r1
    //     0x82dd9c: stur            w1, [x0, #7]
    // 0x82dda0: LeaveFrame
    //     0x82dda0: mov             SP, fp
    //     0x82dda4: ldp             fp, lr, [SP], #0x10
    // 0x82dda8: ret
    //     0x82dda8: ret             
    // 0x82ddac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ddac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ddb0: b               #0x82d7e4
    // 0x82ddb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ddb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82ddb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ddb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82ddbc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddbc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddc0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddc4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddc8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddcc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddcc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82ddd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82ddd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddd4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82ddd8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82ddd8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82dddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dddc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82dde0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dde0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82dde4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82dde4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _tryParseWebNonDebugFrame(/* No info */) {
    // ** addr: 0x82e094, size: 0x15c
    // 0x82e094: EnterFrame
    //     0x82e094: stp             fp, lr, [SP, #-0x10]!
    //     0x82e098: mov             fp, SP
    // 0x82e09c: AllocStack(0x20)
    //     0x82e09c: sub             SP, SP, #0x20
    // 0x82e0a0: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x82e0a0: mov             x2, x1
    //     0x82e0a4: stur            x1, [fp, #-8]
    // 0x82e0a8: CheckStackOverflow
    //     0x82e0a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e0ac: cmp             SP, x16
    //     0x82e0b0: b.ls            #0x82e1e4
    // 0x82e0b4: r0 = LoadStaticField(0xbe8)
    //     0x82e0b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82e0b8: ldr             x0, [x0, #0x17d0]
    // 0x82e0bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82e0c0: cmp             w0, w16
    // 0x82e0c4: b.ne            #0x82e0d0
    // 0x82e0c8: r2 = _webNonDebugFramePattern
    //     0x82e0c8: ldr             x2, [PP, #0x1480]  ; [pp+0x1480] Field <StackFrame._webNonDebugFramePattern@598425567>: static late final (offset: 0xbe8)
    // 0x82e0cc: r0 = InitLateFinalStaticField()
    //     0x82e0cc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82e0d0: mov             x1, x0
    // 0x82e0d4: ldur            x2, [fp, #-8]
    // 0x82e0d8: r0 = firstMatch()
    //     0x82e0d8: bl              #0x82e014  ; [dart:core] _RegExp::firstMatch
    // 0x82e0dc: cmp             w0, NULL
    // 0x82e0e0: b.ne            #0x82e0f4
    // 0x82e0e4: r0 = Null
    //     0x82e0e4: mov             x0, NULL
    // 0x82e0e8: LeaveFrame
    //     0x82e0e8: mov             SP, fp
    //     0x82e0ec: ldp             fp, lr, [SP], #0x10
    // 0x82e0f0: ret
    //     0x82e0f0: ret             
    // 0x82e0f4: mov             x1, x0
    // 0x82e0f8: r2 = 2
    //     0x82e0f8: mov             x2, #2
    // 0x82e0fc: r0 = []()
    //     0x82e0fc: bl              #0x1292dc4  ; [dart:core] _RegExpMatch::[]
    // 0x82e100: cmp             w0, NULL
    // 0x82e104: b.eq            #0x82e1ec
    // 0x82e108: r1 = LoadClassIdInstr(r0)
    //     0x82e108: ldur            x1, [x0, #-1]
    //     0x82e10c: ubfx            x1, x1, #0xc, #0x14
    // 0x82e110: mov             x16, x0
    // 0x82e114: mov             x0, x1
    // 0x82e118: mov             x1, x16
    // 0x82e11c: r2 = "."
    //     0x82e11c: ldr             x2, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82e120: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82e120: sub             lr, x0, #0xffe
    //     0x82e124: ldr             lr, [x21, lr, lsl #3]
    //     0x82e128: blr             lr
    // 0x82e12c: stur            x0, [fp, #-0x10]
    // 0x82e130: LoadField: r1 = r0->field_b
    //     0x82e130: ldur            w1, [x0, #0xb]
    // 0x82e134: r2 = LoadInt32Instr(r1)
    //     0x82e134: sbfx            x2, x1, #1, #0x1f
    // 0x82e138: cmp             x2, #1
    // 0x82e13c: b.le            #0x82e14c
    // 0x82e140: mov             x1, x0
    // 0x82e144: r0 = first()
    //     0x82e144: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0x82e148: b               #0x82e150
    // 0x82e14c: r0 = "<unknown>"
    //     0x82e14c: ldr             x0, [PP, #0xfc0]  ; [pp+0xfc0] "<unknown>"
    // 0x82e150: ldur            x1, [fp, #-0x10]
    // 0x82e154: stur            x0, [fp, #-0x18]
    // 0x82e158: LoadField: r2 = r1->field_b
    //     0x82e158: ldur            w2, [x1, #0xb]
    // 0x82e15c: r3 = LoadInt32Instr(r2)
    //     0x82e15c: sbfx            x3, x2, #1, #0x1f
    // 0x82e160: cmp             x3, #1
    // 0x82e164: b.le            #0x82e18c
    // 0x82e168: r2 = 1
    //     0x82e168: mov             x2, #1
    // 0x82e16c: r0 = skip()
    //     0x82e16c: bl              #0xbb13c0  ; [dart:collection] ListBase::skip
    // 0x82e170: r16 = "."
    //     0x82e170: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0x82e174: str             x16, [SP]
    // 0x82e178: mov             x1, x0
    // 0x82e17c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x82e17c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x82e180: r0 = join()
    //     0x82e180: bl              #0xafe610  ; [dart:_internal] ListIterable::join
    // 0x82e184: mov             x2, x0
    // 0x82e188: b               #0x82e194
    // 0x82e18c: r0 = single()
    //     0x82e18c: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0x82e190: mov             x2, x0
    // 0x82e194: ldur            x1, [fp, #-8]
    // 0x82e198: ldur            x0, [fp, #-0x18]
    // 0x82e19c: stur            x2, [fp, #-0x10]
    // 0x82e1a0: r0 = StackFrame()
    //     0x82e1a0: bl              #0x82dde8  ; AllocateStackFrameStub -> StackFrame (size=0x34)
    // 0x82e1a4: r1 = -1
    //     0x82e1a4: mov             x1, #-1
    // 0x82e1a8: StoreField: r0->field_b = r1
    //     0x82e1a8: stur            x1, [x0, #0xb]
    // 0x82e1ac: StoreField: r0->field_23 = r1
    //     0x82e1ac: stur            x1, [x0, #0x23]
    // 0x82e1b0: StoreField: r0->field_1b = r1
    //     0x82e1b0: stur            x1, [x0, #0x1b]
    // 0x82e1b4: r1 = "<unknown>"
    //     0x82e1b4: ldr             x1, [PP, #0xfc0]  ; [pp+0xfc0] "<unknown>"
    // 0x82e1b8: StoreField: r0->field_13 = r1
    //     0x82e1b8: stur            w1, [x0, #0x13]
    // 0x82e1bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x82e1bc: stur            w1, [x0, #0x17]
    // 0x82e1c0: ldur            x1, [fp, #-0x18]
    // 0x82e1c4: StoreField: r0->field_2b = r1
    //     0x82e1c4: stur            w1, [x0, #0x2b]
    // 0x82e1c8: ldur            x1, [fp, #-0x10]
    // 0x82e1cc: StoreField: r0->field_2f = r1
    //     0x82e1cc: stur            w1, [x0, #0x2f]
    // 0x82e1d0: ldur            x1, [fp, #-8]
    // 0x82e1d4: StoreField: r0->field_7 = r1
    //     0x82e1d4: stur            w1, [x0, #7]
    // 0x82e1d8: LeaveFrame
    //     0x82e1d8: mov             SP, fp
    //     0x82e1dc: ldp             fp, lr, [SP], #0x10
    // 0x82e1e0: ret
    //     0x82e1e0: ret             
    // 0x82e1e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e1e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e1e8: b               #0x82e0b4
    // 0x82e1ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82e1ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static RegExp _webNonDebugFramePattern() {
    // ** addr: 0x82e1f0, size: 0x54
    // 0x82e1f0: EnterFrame
    //     0x82e1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x82e1f4: mov             fp, SP
    // 0x82e1f8: AllocStack(0x30)
    //     0x82e1f8: sub             SP, SP, #0x30
    // 0x82e1fc: CheckStackOverflow
    //     0x82e1fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e200: cmp             SP, x16
    //     0x82e204: b.ls            #0x82e23c
    // 0x82e208: r16 = "^\\s*at ([^\\s]+).*$"
    //     0x82e208: ldr             x16, [PP, #0x1490]  ; [pp+0x1490] "^\\s*at ([^\\s]+).*$"
    // 0x82e20c: stp             x16, NULL, [SP, #0x20]
    // 0x82e210: r16 = false
    //     0x82e210: add             x16, NULL, #0x30  ; false
    // 0x82e214: r30 = true
    //     0x82e214: add             lr, NULL, #0x20  ; true
    // 0x82e218: stp             lr, x16, [SP, #0x10]
    // 0x82e21c: r16 = false
    //     0x82e21c: add             x16, NULL, #0x30  ; false
    // 0x82e220: r30 = false
    //     0x82e220: add             lr, NULL, #0x30  ; false
    // 0x82e224: stp             lr, x16, [SP]
    // 0x82e228: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x82e228: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x82e22c: r0 = _RegExp()
    //     0x82e22c: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x82e230: LeaveFrame
    //     0x82e230: mov             SP, fp
    //     0x82e234: ldp             fp, lr, [SP], #0x10
    // 0x82e238: ret
    //     0x82e238: ret             
    // 0x82e23c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e23c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e240: b               #0x82e208
  }
  [closure] static bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x82e244, size: 0x1c
    // 0x82e244: ldr             x1, [SP]
    // 0x82e248: LoadField: r2 = r1->field_7
    //     0x82e248: ldur            w2, [x1, #7]
    // 0x82e24c: cbnz            w2, #0x82e258
    // 0x82e250: r0 = false
    //     0x82e250: add             x0, NULL, #0x30  ; false
    // 0x82e254: b               #0x82e25c
    // 0x82e258: r0 = true
    //     0x82e258: add             x0, NULL, #0x20  ; true
    // 0x82e25c: ret
    //     0x82e25c: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114aaf8, size: 0xd8
    // 0x114aaf8: EnterFrame
    //     0x114aaf8: stp             fp, lr, [SP, #-0x10]!
    //     0x114aafc: mov             fp, SP
    // 0x114ab00: AllocStack(0x28)
    //     0x114ab00: sub             SP, SP, #0x28
    // 0x114ab04: CheckStackOverflow
    //     0x114ab04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ab08: cmp             SP, x16
    //     0x114ab0c: b.ls            #0x114abc8
    // 0x114ab10: ldr             x0, [fp, #0x10]
    // 0x114ab14: LoadField: r2 = r0->field_b
    //     0x114ab14: ldur            x2, [x0, #0xb]
    // 0x114ab18: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x114ab18: ldur            w3, [x0, #0x17]
    // 0x114ab1c: DecompressPointer r3
    //     0x114ab1c: add             x3, x3, HEAP, lsl #32
    // 0x114ab20: LoadField: r4 = r0->field_1b
    //     0x114ab20: ldur            x4, [x0, #0x1b]
    // 0x114ab24: LoadField: r5 = r0->field_23
    //     0x114ab24: ldur            x5, [x0, #0x23]
    // 0x114ab28: LoadField: r6 = r0->field_2b
    //     0x114ab28: ldur            w6, [x0, #0x2b]
    // 0x114ab2c: DecompressPointer r6
    //     0x114ab2c: add             x6, x6, HEAP, lsl #32
    // 0x114ab30: LoadField: r7 = r0->field_2f
    //     0x114ab30: ldur            w7, [x0, #0x2f]
    // 0x114ab34: DecompressPointer r7
    //     0x114ab34: add             x7, x7, HEAP, lsl #32
    // 0x114ab38: LoadField: r8 = r0->field_7
    //     0x114ab38: ldur            w8, [x0, #7]
    // 0x114ab3c: DecompressPointer r8
    //     0x114ab3c: add             x8, x8, HEAP, lsl #32
    // 0x114ab40: r0 = BoxInt64Instr(r2)
    //     0x114ab40: sbfiz           x0, x2, #1, #0x1f
    //     0x114ab44: cmp             x2, x0, asr #1
    //     0x114ab48: b.eq            #0x114ab54
    //     0x114ab4c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ab50: stur            x2, [x0, #7]
    // 0x114ab54: mov             x2, x0
    // 0x114ab58: r0 = BoxInt64Instr(r4)
    //     0x114ab58: sbfiz           x0, x4, #1, #0x1f
    //     0x114ab5c: cmp             x4, x0, asr #1
    //     0x114ab60: b.eq            #0x114ab6c
    //     0x114ab64: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ab68: stur            x4, [x0, #7]
    // 0x114ab6c: mov             x4, x0
    // 0x114ab70: r0 = BoxInt64Instr(r5)
    //     0x114ab70: sbfiz           x0, x5, #1, #0x1f
    //     0x114ab74: cmp             x5, x0, asr #1
    //     0x114ab78: b.eq            #0x114ab84
    //     0x114ab7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ab80: stur            x5, [x0, #7]
    // 0x114ab84: stp             x0, x4, [SP, #0x18]
    // 0x114ab88: stp             x7, x6, [SP, #8]
    // 0x114ab8c: str             x8, [SP]
    // 0x114ab90: mov             x1, x2
    // 0x114ab94: mov             x2, x3
    // 0x114ab98: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x114ab98: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x114ab9c: ldr             x4, [x4, #0x8a0]
    // 0x114aba0: r0 = hash()
    //     0x114aba0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114aba4: mov             x2, x0
    // 0x114aba8: r0 = BoxInt64Instr(r2)
    //     0x114aba8: sbfiz           x0, x2, #1, #0x1f
    //     0x114abac: cmp             x2, x0, asr #1
    //     0x114abb0: b.eq            #0x114abbc
    //     0x114abb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114abb8: stur            x2, [x0, #7]
    // 0x114abbc: LeaveFrame
    //     0x114abbc: mov             SP, fp
    //     0x114abc0: ldp             fp, lr, [SP], #0x10
    // 0x114abc4: ret
    //     0x114abc4: ret             
    // 0x114abc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114abc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114abcc: b               #0x114ab10
  }
  _ ==(/* No info */) {
    // ** addr: 0x129585c, size: 0x1b4
    // 0x129585c: EnterFrame
    //     0x129585c: stp             fp, lr, [SP, #-0x10]!
    //     0x1295860: mov             fp, SP
    // 0x1295864: AllocStack(0x10)
    //     0x1295864: sub             SP, SP, #0x10
    // 0x1295868: CheckStackOverflow
    //     0x1295868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129586c: cmp             SP, x16
    //     0x1295870: b.ls            #0x1295a08
    // 0x1295874: ldr             x0, [fp, #0x10]
    // 0x1295878: cmp             w0, NULL
    // 0x129587c: b.ne            #0x1295890
    // 0x1295880: r0 = false
    //     0x1295880: add             x0, NULL, #0x30  ; false
    // 0x1295884: LeaveFrame
    //     0x1295884: mov             SP, fp
    //     0x1295888: ldp             fp, lr, [SP], #0x10
    // 0x129588c: ret
    //     0x129588c: ret             
    // 0x1295890: str             x0, [SP]
    // 0x1295894: r0 = runtimeType()
    //     0x1295894: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1295898: r1 = LoadClassIdInstr(r0)
    //     0x1295898: ldur            x1, [x0, #-1]
    //     0x129589c: ubfx            x1, x1, #0xc, #0x14
    // 0x12958a0: r16 = StackFrame
    //     0x12958a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xddf0] Type: StackFrame
    //     0x12958a4: ldr             x16, [x16, #0xdf0]
    // 0x12958a8: stp             x16, x0, [SP]
    // 0x12958ac: mov             x0, x1
    // 0x12958b0: mov             lr, x0
    // 0x12958b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12958b8: blr             lr
    // 0x12958bc: tbz             w0, #4, #0x12958d0
    // 0x12958c0: r0 = false
    //     0x12958c0: add             x0, NULL, #0x30  ; false
    // 0x12958c4: LeaveFrame
    //     0x12958c4: mov             SP, fp
    //     0x12958c8: ldp             fp, lr, [SP], #0x10
    // 0x12958cc: ret
    //     0x12958cc: ret             
    // 0x12958d0: ldr             x1, [fp, #0x10]
    // 0x12958d4: r0 = 60
    //     0x12958d4: mov             x0, #0x3c
    // 0x12958d8: branchIfSmi(r1, 0x12958e4)
    //     0x12958d8: tbz             w1, #0, #0x12958e4
    // 0x12958dc: r0 = LoadClassIdInstr(r1)
    //     0x12958dc: ldur            x0, [x1, #-1]
    //     0x12958e0: ubfx            x0, x0, #0xc, #0x14
    // 0x12958e4: cmp             x0, #0xc73
    // 0x12958e8: b.ne            #0x12959f8
    // 0x12958ec: ldr             x2, [fp, #0x18]
    // 0x12958f0: LoadField: r0 = r1->field_b
    //     0x12958f0: ldur            x0, [x1, #0xb]
    // 0x12958f4: LoadField: r3 = r2->field_b
    //     0x12958f4: ldur            x3, [x2, #0xb]
    // 0x12958f8: cmp             x0, x3
    // 0x12958fc: b.ne            #0x12959f8
    // 0x1295900: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1295900: ldur            w0, [x1, #0x17]
    // 0x1295904: DecompressPointer r0
    //     0x1295904: add             x0, x0, HEAP, lsl #32
    // 0x1295908: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1295908: ldur            w3, [x2, #0x17]
    // 0x129590c: DecompressPointer r3
    //     0x129590c: add             x3, x3, HEAP, lsl #32
    // 0x1295910: r4 = LoadClassIdInstr(r0)
    //     0x1295910: ldur            x4, [x0, #-1]
    //     0x1295914: ubfx            x4, x4, #0xc, #0x14
    // 0x1295918: stp             x3, x0, [SP]
    // 0x129591c: mov             x0, x4
    // 0x1295920: mov             lr, x0
    // 0x1295924: ldr             lr, [x21, lr, lsl #3]
    // 0x1295928: blr             lr
    // 0x129592c: tbnz            w0, #4, #0x12959f8
    // 0x1295930: ldr             x2, [fp, #0x18]
    // 0x1295934: ldr             x1, [fp, #0x10]
    // 0x1295938: LoadField: r0 = r1->field_1b
    //     0x1295938: ldur            x0, [x1, #0x1b]
    // 0x129593c: LoadField: r3 = r2->field_1b
    //     0x129593c: ldur            x3, [x2, #0x1b]
    // 0x1295940: cmp             x0, x3
    // 0x1295944: b.ne            #0x12959f8
    // 0x1295948: LoadField: r0 = r1->field_23
    //     0x1295948: ldur            x0, [x1, #0x23]
    // 0x129594c: LoadField: r3 = r2->field_23
    //     0x129594c: ldur            x3, [x2, #0x23]
    // 0x1295950: cmp             x0, x3
    // 0x1295954: b.ne            #0x12959f8
    // 0x1295958: LoadField: r0 = r1->field_2b
    //     0x1295958: ldur            w0, [x1, #0x2b]
    // 0x129595c: DecompressPointer r0
    //     0x129595c: add             x0, x0, HEAP, lsl #32
    // 0x1295960: LoadField: r3 = r2->field_2b
    //     0x1295960: ldur            w3, [x2, #0x2b]
    // 0x1295964: DecompressPointer r3
    //     0x1295964: add             x3, x3, HEAP, lsl #32
    // 0x1295968: r4 = LoadClassIdInstr(r0)
    //     0x1295968: ldur            x4, [x0, #-1]
    //     0x129596c: ubfx            x4, x4, #0xc, #0x14
    // 0x1295970: stp             x3, x0, [SP]
    // 0x1295974: mov             x0, x4
    // 0x1295978: mov             lr, x0
    // 0x129597c: ldr             lr, [x21, lr, lsl #3]
    // 0x1295980: blr             lr
    // 0x1295984: tbnz            w0, #4, #0x12959f8
    // 0x1295988: ldr             x2, [fp, #0x18]
    // 0x129598c: ldr             x1, [fp, #0x10]
    // 0x1295990: LoadField: r0 = r1->field_2f
    //     0x1295990: ldur            w0, [x1, #0x2f]
    // 0x1295994: DecompressPointer r0
    //     0x1295994: add             x0, x0, HEAP, lsl #32
    // 0x1295998: LoadField: r3 = r2->field_2f
    //     0x1295998: ldur            w3, [x2, #0x2f]
    // 0x129599c: DecompressPointer r3
    //     0x129599c: add             x3, x3, HEAP, lsl #32
    // 0x12959a0: r4 = LoadClassIdInstr(r0)
    //     0x12959a0: ldur            x4, [x0, #-1]
    //     0x12959a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12959a8: stp             x3, x0, [SP]
    // 0x12959ac: mov             x0, x4
    // 0x12959b0: mov             lr, x0
    // 0x12959b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12959b8: blr             lr
    // 0x12959bc: tbnz            w0, #4, #0x12959f8
    // 0x12959c0: ldr             x1, [fp, #0x18]
    // 0x12959c4: ldr             x0, [fp, #0x10]
    // 0x12959c8: LoadField: r2 = r0->field_7
    //     0x12959c8: ldur            w2, [x0, #7]
    // 0x12959cc: DecompressPointer r2
    //     0x12959cc: add             x2, x2, HEAP, lsl #32
    // 0x12959d0: LoadField: r0 = r1->field_7
    //     0x12959d0: ldur            w0, [x1, #7]
    // 0x12959d4: DecompressPointer r0
    //     0x12959d4: add             x0, x0, HEAP, lsl #32
    // 0x12959d8: r1 = LoadClassIdInstr(r2)
    //     0x12959d8: ldur            x1, [x2, #-1]
    //     0x12959dc: ubfx            x1, x1, #0xc, #0x14
    // 0x12959e0: stp             x0, x2, [SP]
    // 0x12959e4: mov             x0, x1
    // 0x12959e8: mov             lr, x0
    // 0x12959ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12959f0: blr             lr
    // 0x12959f4: b               #0x12959fc
    // 0x12959f8: r0 = false
    //     0x12959f8: add             x0, NULL, #0x30  ; false
    // 0x12959fc: LeaveFrame
    //     0x12959fc: mov             SP, fp
    //     0x1295a00: ldp             fp, lr, [SP], #0x10
    // 0x1295a04: ret
    //     0x1295a04: ret             
    // 0x1295a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1295a08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1295a0c: b               #0x1295874
  }
}
