// lib: , url: package:flutter/src/foundation/synchronous_future.dart

// class id: 1048813, size: 0x8
class :: {
}

// class id: 3186, size: 0x10, field offset: 0x8
class SynchronousFuture<X0> extends Object
    implements Future<X0> {

  _ catchError(/* No info */) {
    // ** addr: 0x12f2080, size: 0x6c
    // 0x12f2080: EnterFrame
    //     0x12f2080: stp             fp, lr, [SP, #-0x10]!
    //     0x12f2084: mov             fp, SP
    // 0x12f2088: AllocStack(0x8)
    //     0x12f2088: sub             SP, SP, #8
    // 0x12f208c: CheckStackOverflow
    //     0x12f208c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f2090: cmp             SP, x16
    //     0x12f2094: b.ls            #0x12f20e4
    // 0x12f2098: LoadField: r0 = r1->field_7
    //     0x12f2098: ldur            w0, [x1, #7]
    // 0x12f209c: DecompressPointer r0
    //     0x12f209c: add             x0, x0, HEAP, lsl #32
    // 0x12f20a0: mov             x1, x0
    // 0x12f20a4: r0 = _Future()
    //     0x12f20a4: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x12f20a8: stur            x0, [fp, #-8]
    // 0x12f20ac: StoreField: r0->field_b = rZR
    //     0x12f20ac: stur            xzr, [x0, #0xb]
    // 0x12f20b0: r0 = LoadStaticField(0x364)
    //     0x12f20b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12f20b4: ldr             x0, [x0, #0x6c8]
    // 0x12f20b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f20bc: cmp             w0, w16
    // 0x12f20c0: b.ne            #0x12f20cc
    // 0x12f20c4: r2 = _current
    //     0x12f20c4: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x12f20c8: r0 = InitLateStaticField()
    //     0x12f20c8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x12f20cc: mov             x1, x0
    // 0x12f20d0: ldur            x0, [fp, #-8]
    // 0x12f20d4: StoreField: r0->field_13 = r1
    //     0x12f20d4: stur            w1, [x0, #0x13]
    // 0x12f20d8: LeaveFrame
    //     0x12f20d8: mov             SP, fp
    //     0x12f20dc: ldp             fp, lr, [SP], #0x10
    // 0x12f20e0: ret
    //     0x12f20e0: ret             
    // 0x12f20e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f20e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f20e8: b               #0x12f2098
  }
  _ whenComplete(/* No info */) {
    // ** addr: 0x12fa998, size: 0x1b8
    // 0x12fa998: EnterFrame
    //     0x12fa998: stp             fp, lr, [SP, #-0x10]!
    //     0x12fa99c: mov             fp, SP
    // 0x12fa9a0: AllocStack(0x88)
    //     0x12fa9a0: sub             SP, SP, #0x88
    // 0x12fa9a4: SetupParameters(SynchronousFuture<X0> this /* r1 => r1, fp-0x58 */, dynamic _ /* r2 => r0, fp-0x60 */)
    //     0x12fa9a4: mov             x0, x2
    //     0x12fa9a8: stur            x1, [fp, #-0x58]
    //     0x12fa9ac: stur            x2, [fp, #-0x60]
    // 0x12fa9b0: CheckStackOverflow
    //     0x12fa9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fa9b4: cmp             SP, x16
    //     0x12fa9b8: b.ls            #0x12fab48
    // 0x12fa9bc: r1 = 1
    //     0x12fa9bc: mov             x1, #1
    // 0x12fa9c0: r0 = AllocateContext()
    //     0x12fa9c0: bl              #0x13de838  ; AllocateContextStub
    // 0x12fa9c4: mov             x2, x0
    // 0x12fa9c8: ldur            x1, [fp, #-0x58]
    // 0x12fa9cc: stur            x2, [fp, #-0x68]
    // 0x12fa9d0: StoreField: r2->field_f = r1
    //     0x12fa9d0: stur            w1, [x2, #0xf]
    // 0x12fa9d4: ldur            x16, [fp, #-0x60]
    // 0x12fa9d8: str             x16, [SP]
    // 0x12fa9dc: ldur            x0, [fp, #-0x60]
    // 0x12fa9e0: ClosureCall
    //     0x12fa9e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12fa9e4: ldur            x2, [x0, #0x1f]
    //     0x12fa9e8: blr             x2
    // 0x12fa9ec: mov             x3, x0
    // 0x12fa9f0: r2 = Null
    //     0x12fa9f0: mov             x2, NULL
    // 0x12fa9f4: r1 = Null
    //     0x12fa9f4: mov             x1, NULL
    // 0x12fa9f8: stur            x3, [fp, #-0x70]
    // 0x12fa9fc: cmp             w0, NULL
    // 0x12faa00: b.eq            #0x12faa98
    // 0x12faa04: branchIfSmi(r0, 0x12faa98)
    //     0x12faa04: tbz             w0, #0, #0x12faa98
    // 0x12faa08: r3 = LoadClassIdInstr(r0)
    //     0x12faa08: ldur            x3, [x0, #-1]
    //     0x12faa0c: ubfx            x3, x3, #0xc, #0x14
    // 0x12faa10: r17 = 7560
    //     0x12faa10: mov             x17, #0x1d88
    // 0x12faa14: cmp             x3, x17
    // 0x12faa18: b.eq            #0x12faaa0
    // 0x12faa1c: r4 = LoadClassIdInstr(r0)
    //     0x12faa1c: ldur            x4, [x0, #-1]
    //     0x12faa20: ubfx            x4, x4, #0xc, #0x14
    // 0x12faa24: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12faa28: ldr             x3, [x3, #0x18]
    // 0x12faa2c: ldr             x3, [x3, x4, lsl #3]
    // 0x12faa30: LoadField: r3 = r3->field_2b
    //     0x12faa30: ldur            w3, [x3, #0x2b]
    // 0x12faa34: DecompressPointer r3
    //     0x12faa34: add             x3, x3, HEAP, lsl #32
    // 0x12faa38: cmp             w3, NULL
    // 0x12faa3c: b.eq            #0x12faa98
    // 0x12faa40: LoadField: r3 = r3->field_f
    //     0x12faa40: ldur            w3, [x3, #0xf]
    // 0x12faa44: lsr             x3, x3, #3
    // 0x12faa48: r17 = 7560
    //     0x12faa48: mov             x17, #0x1d88
    // 0x12faa4c: cmp             x3, x17
    // 0x12faa50: b.eq            #0x12faaa0
    // 0x12faa54: r3 = SubtypeTestCache
    //     0x12faa54: add             x3, PP, #0x26, lsl #12  ; [pp+0x266a8] SubtypeTestCache
    //     0x12faa58: ldr             x3, [x3, #0x6a8]
    // 0x12faa5c: r30 = Subtype1TestCacheStub
    //     0x12faa5c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12faa60: LoadField: r30 = r30->field_7
    //     0x12faa60: ldur            lr, [lr, #7]
    // 0x12faa64: blr             lr
    // 0x12faa68: cmp             w7, NULL
    // 0x12faa6c: b.eq            #0x12faa78
    // 0x12faa70: tbnz            w7, #4, #0x12faa98
    // 0x12faa74: b               #0x12faaa0
    // 0x12faa78: r8 = Future
    //     0x12faa78: add             x8, PP, #0x26, lsl #12  ; [pp+0x266b0] Type: Future
    //     0x12faa7c: ldr             x8, [x8, #0x6b0]
    // 0x12faa80: r3 = SubtypeTestCache
    //     0x12faa80: add             x3, PP, #0x26, lsl #12  ; [pp+0x266b8] SubtypeTestCache
    //     0x12faa84: ldr             x3, [x3, #0x6b8]
    // 0x12faa88: r30 = InstanceOfStub
    //     0x12faa88: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12faa8c: LoadField: r30 = r30->field_7
    //     0x12faa8c: ldur            lr, [lr, #7]
    // 0x12faa90: blr             lr
    // 0x12faa94: b               #0x12faaa4
    // 0x12faa98: r0 = false
    //     0x12faa98: add             x0, NULL, #0x30  ; false
    // 0x12faa9c: b               #0x12faaa4
    // 0x12faaa0: r0 = true
    //     0x12faaa0: add             x0, NULL, #0x20  ; true
    // 0x12faaa4: tbnz            w0, #4, #0x12fab08
    // 0x12faaa8: ldur            x4, [fp, #-0x58]
    // 0x12faaac: ldur            x0, [fp, #-0x70]
    // 0x12faab0: LoadField: r5 = r4->field_7
    //     0x12faab0: ldur            w5, [x4, #7]
    // 0x12faab4: DecompressPointer r5
    //     0x12faab4: add             x5, x5, HEAP, lsl #32
    // 0x12faab8: ldur            x2, [fp, #-0x68]
    // 0x12faabc: mov             x3, x5
    // 0x12faac0: stur            x5, [fp, #-0x60]
    // 0x12faac4: r1 = Function '<anonymous closure>':.
    //     0x12faac4: add             x1, PP, #0x26, lsl #12  ; [pp+0x266c0] AnonymousClosure: (0x12fab50), in [package:flutter/src/foundation/synchronous_future.dart] SynchronousFuture::whenComplete (0x12fa998)
    //     0x12faac8: ldr             x1, [x1, #0x6c0]
    // 0x12faacc: r0 = AllocateClosureTA()
    //     0x12faacc: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x12faad0: ldur            x1, [fp, #-0x70]
    // 0x12faad4: r2 = LoadClassIdInstr(r1)
    //     0x12faad4: ldur            x2, [x1, #-1]
    //     0x12faad8: ubfx            x2, x2, #0xc, #0x14
    // 0x12faadc: ldur            x16, [fp, #-0x60]
    // 0x12faae0: stp             x1, x16, [SP, #8]
    // 0x12faae4: str             x0, [SP]
    // 0x12faae8: mov             x0, x2
    // 0x12faaec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12faaec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12faaf0: r0 = GDT[cid_x0 + -0xfef]()
    //     0x12faaf0: sub             lr, x0, #0xfef
    //     0x12faaf4: ldr             lr, [x21, lr, lsl #3]
    //     0x12faaf8: blr             lr
    // 0x12faafc: LeaveFrame
    //     0x12faafc: mov             SP, fp
    //     0x12fab00: ldp             fp, lr, [SP], #0x10
    // 0x12fab04: ret
    //     0x12fab04: ret             
    // 0x12fab08: ldur            x0, [fp, #-0x58]
    // 0x12fab0c: LeaveFrame
    //     0x12fab0c: mov             SP, fp
    //     0x12fab10: ldp             fp, lr, [SP], #0x10
    // 0x12fab14: ret
    //     0x12fab14: ret             
    // 0x12fab18: sub             SP, fp, #0x88
    // 0x12fab1c: ldur            x2, [fp, #-0x58]
    // 0x12fab20: LoadField: r3 = r2->field_7
    //     0x12fab20: ldur            w3, [x2, #7]
    // 0x12fab24: DecompressPointer r3
    //     0x12fab24: add             x3, x3, HEAP, lsl #32
    // 0x12fab28: str             x1, [SP]
    // 0x12fab2c: mov             x1, x3
    // 0x12fab30: mov             x2, x0
    // 0x12fab34: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12fab34: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12fab38: r0 = Future.error()
    //     0x12fab38: bl              #0x7fc9cc  ; [dart:async] Future::Future.error
    // 0x12fab3c: LeaveFrame
    //     0x12fab3c: mov             SP, fp
    //     0x12fab40: ldp             fp, lr, [SP], #0x10
    // 0x12fab44: ret
    //     0x12fab44: ret             
    // 0x12fab48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fab48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fab4c: b               #0x12fa9bc
  }
  [closure] X0 <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x12fab50, size: 0x20
    // 0x12fab50: ldr             x1, [SP, #8]
    // 0x12fab54: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x12fab54: ldur            w2, [x1, #0x17]
    // 0x12fab58: DecompressPointer r2
    //     0x12fab58: add             x2, x2, HEAP, lsl #32
    // 0x12fab5c: LoadField: r1 = r2->field_f
    //     0x12fab5c: ldur            w1, [x2, #0xf]
    // 0x12fab60: DecompressPointer r1
    //     0x12fab60: add             x1, x1, HEAP, lsl #32
    // 0x12fab64: LoadField: r0 = r1->field_b
    //     0x12fab64: ldur            w0, [x1, #0xb]
    // 0x12fab68: DecompressPointer r0
    //     0x12fab68: add             x0, x0, HEAP, lsl #32
    // 0x12fab6c: ret
    //     0x12fab6c: ret             
  }
  Future<Y0> then<Y0>(SynchronousFuture<X0>, (dynamic, X0) => FutureOr<Y0>, {Function? onError}) {
    // ** addr: 0x12fab70, size: 0x1c8
    // 0x12fab70: EnterFrame
    //     0x12fab70: stp             fp, lr, [SP, #-0x10]!
    //     0x12fab74: mov             fp, SP
    // 0x12fab78: AllocStack(0x20)
    //     0x12fab78: sub             SP, SP, #0x20
    // 0x12fab7c: SetupParameters(SynchronousFuture<X0> this /* r0 */, dynamic _ /* r2 */)
    //     0x12fab7c: ldur            w0, [x4, #0x13]
    //     0x12fab80: sub             x1, x0, #4
    //     0x12fab84: add             x0, fp, w1, sxtw #2
    //     0x12fab88: ldr             x0, [x0, #0x18]
    //     0x12fab8c: add             x2, fp, w1, sxtw #2
    //     0x12fab90: ldr             x2, [x2, #0x10]
    //     0x12fab94: ldur            w1, [x4, #0xf]
    //     0x12fab98: cbnz            w1, #0x12faba4
    //     0x12fab9c: mov             x1, NULL
    //     0x12faba0: b               #0x12fabb4
    //     0x12faba4: ldur            w1, [x4, #0x17]
    //     0x12faba8: add             x3, fp, w1, sxtw #2
    //     0x12fabac: ldr             x3, [x3, #0x10]
    //     0x12fabb0: mov             x1, x3
    //     0x12fabb4: stur            x1, [fp, #-8]
    // 0x12fabb8: CheckStackOverflow
    //     0x12fabb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fabbc: cmp             SP, x16
    //     0x12fabc0: b.ls            #0x12fad30
    // 0x12fabc4: LoadField: r3 = r0->field_b
    //     0x12fabc4: ldur            w3, [x0, #0xb]
    // 0x12fabc8: DecompressPointer r3
    //     0x12fabc8: add             x3, x3, HEAP, lsl #32
    // 0x12fabcc: stp             x3, x2, [SP]
    // 0x12fabd0: mov             x0, x2
    // 0x12fabd4: ClosureCall
    //     0x12fabd4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x12fabd8: ldur            x2, [x0, #0x1f]
    //     0x12fabdc: blr             x2
    // 0x12fabe0: ldur            x1, [fp, #-8]
    // 0x12fabe4: mov             x3, x0
    // 0x12fabe8: r2 = Null
    //     0x12fabe8: mov             x2, NULL
    // 0x12fabec: stur            x3, [fp, #-0x10]
    // 0x12fabf0: cmp             w0, NULL
    // 0x12fabf4: b.eq            #0x12fac40
    // 0x12fabf8: branchIfSmi(r0, 0x12fac40)
    //     0x12fabf8: tbz             w0, #0, #0x12fac40
    // 0x12fabfc: r3 = SubtypeTestCache
    //     0x12fabfc: add             x3, PP, #0x26, lsl #12  ; [pp+0x266c8] SubtypeTestCache
    //     0x12fac00: ldr             x3, [x3, #0x6c8]
    // 0x12fac04: r30 = Subtype4TestCacheStub
    //     0x12fac04: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0x12fac08: LoadField: r30 = r30->field_7
    //     0x12fac08: ldur            lr, [lr, #7]
    // 0x12fac0c: blr             lr
    // 0x12fac10: cmp             w7, NULL
    // 0x12fac14: b.eq            #0x12fac20
    // 0x12fac18: tbnz            w7, #4, #0x12fac40
    // 0x12fac1c: b               #0x12fac48
    // 0x12fac20: r8 = Future<Y0>
    //     0x12fac20: add             x8, PP, #0x26, lsl #12  ; [pp+0x266d0] Type: Future<Y0>
    //     0x12fac24: ldr             x8, [x8, #0x6d0]
    // 0x12fac28: r3 = SubtypeTestCache
    //     0x12fac28: add             x3, PP, #0x26, lsl #12  ; [pp+0x266d8] SubtypeTestCache
    //     0x12fac2c: ldr             x3, [x3, #0x6d8]
    // 0x12fac30: r30 = InstanceOfStub
    //     0x12fac30: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12fac34: LoadField: r30 = r30->field_7
    //     0x12fac34: ldur            lr, [lr, #7]
    // 0x12fac38: blr             lr
    // 0x12fac3c: b               #0x12fac4c
    // 0x12fac40: r0 = false
    //     0x12fac40: add             x0, NULL, #0x30  ; false
    // 0x12fac44: b               #0x12fac4c
    // 0x12fac48: r0 = true
    //     0x12fac48: add             x0, NULL, #0x20  ; true
    // 0x12fac4c: tbnz            w0, #4, #0x12fac58
    // 0x12fac50: ldur            x0, [fp, #-0x10]
    // 0x12fac54: b               #0x12fad24
    // 0x12fac58: ldur            x0, [fp, #-0x10]
    // 0x12fac5c: ldur            x1, [fp, #-8]
    // 0x12fac60: r2 = Null
    //     0x12fac60: mov             x2, NULL
    // 0x12fac64: cmp             w1, NULL
    // 0x12fac68: b.eq            #0x12fad00
    // 0x12fac6c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x12fac6c: ldur            w3, [x1, #0x17]
    // 0x12fac70: DecompressPointer r3
    //     0x12fac70: add             x3, x3, HEAP, lsl #32
    // 0x12fac74: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x12fac78: cmp             w3, w16
    // 0x12fac7c: b.eq            #0x12fad00
    // 0x12fac80: r16 = Object?
    //     0x12fac80: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x12fac84: cmp             w3, w16
    // 0x12fac88: b.eq            #0x12fad00
    // 0x12fac8c: r16 = void?
    //     0x12fac8c: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x12fac90: cmp             w3, w16
    // 0x12fac94: b.eq            #0x12fad00
    // 0x12fac98: tbnz            w0, #0, #0x12facb4
    // 0x12fac9c: r16 = int
    //     0x12fac9c: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x12faca0: cmp             w3, w16
    // 0x12faca4: b.eq            #0x12fad00
    // 0x12faca8: r16 = num
    //     0x12faca8: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x12facac: cmp             w3, w16
    // 0x12facb0: b.eq            #0x12fad00
    // 0x12facb4: r3 = SubtypeTestCache
    //     0x12facb4: add             x3, PP, #0x26, lsl #12  ; [pp+0x266e0] SubtypeTestCache
    //     0x12facb8: ldr             x3, [x3, #0x6e0]
    // 0x12facbc: r30 = Subtype6TestCacheStub
    //     0x12facbc: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x12facc0: LoadField: r30 = r30->field_7
    //     0x12facc0: ldur            lr, [lr, #7]
    // 0x12facc4: blr             lr
    // 0x12facc8: cmp             w7, NULL
    // 0x12faccc: b.eq            #0x12facd8
    // 0x12facd0: tbnz            w7, #4, #0x12facf8
    // 0x12facd4: b               #0x12fad00
    // 0x12facd8: r8 = Y0
    //     0x12facd8: add             x8, PP, #0x26, lsl #12  ; [pp+0x266e8] TypeParameter: Y0
    //     0x12facdc: ldr             x8, [x8, #0x6e8]
    // 0x12face0: r3 = SubtypeTestCache
    //     0x12face0: add             x3, PP, #0x26, lsl #12  ; [pp+0x266f0] SubtypeTestCache
    //     0x12face4: ldr             x3, [x3, #0x6f0]
    // 0x12face8: r30 = InstanceOfStub
    //     0x12face8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12facec: LoadField: r30 = r30->field_7
    //     0x12facec: ldur            lr, [lr, #7]
    // 0x12facf0: blr             lr
    // 0x12facf4: b               #0x12fad04
    // 0x12facf8: r0 = false
    //     0x12facf8: add             x0, NULL, #0x30  ; false
    // 0x12facfc: b               #0x12fad04
    // 0x12fad00: r0 = true
    //     0x12fad00: add             x0, NULL, #0x20  ; true
    // 0x12fad04: tbnz            w0, #4, #0x12fad20
    // 0x12fad08: ldur            x0, [fp, #-0x10]
    // 0x12fad0c: ldur            x1, [fp, #-8]
    // 0x12fad10: r0 = SynchronousFuture()
    //     0x12fad10: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x12fad14: ldur            x1, [fp, #-0x10]
    // 0x12fad18: StoreField: r0->field_b = r1
    //     0x12fad18: stur            w1, [x0, #0xb]
    // 0x12fad1c: b               #0x12fad24
    // 0x12fad20: r0 = Null
    //     0x12fad20: mov             x0, NULL
    // 0x12fad24: LeaveFrame
    //     0x12fad24: mov             SP, fp
    //     0x12fad28: ldp             fp, lr, [SP], #0x10
    // 0x12fad2c: ret
    //     0x12fad2c: ret             
    // 0x12fad30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fad30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fad34: b               #0x12fabc4
  }
}
