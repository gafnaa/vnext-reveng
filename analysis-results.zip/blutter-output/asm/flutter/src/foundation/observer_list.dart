// lib: , url: package:flutter/src/foundation/observer_list.dart

// class id: 1048807, size: 0x8
class :: {
}

// class id: 7683, size: 0x10, field offset: 0xc
class HashedObserverList<X0> extends Iterable<X0> {

  dynamic contains(dynamic) {
    // ** addr: 0xafcdac, size: 0x3c
    // 0xafcdac: EnterFrame
    //     0xafcdac: stp             fp, lr, [SP, #-0x10]!
    //     0xafcdb0: mov             fp, SP
    // 0xafcdb4: ldr             x2, [fp, #0x10]
    // 0xafcdb8: r1 = Function 'contains':.
    //     0xafcdb8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10e18] AnonymousClosure: (0x82e804), in [package:flutter/src/foundation/observer_list.dart] HashedObserverList::contains (0xb04088)
    //     0xafcdbc: ldr             x1, [x1, #0xe18]
    // 0xafcdc0: r0 = AllocateClosure()
    //     0xafcdc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xafcdc4: LeaveFrame
    //     0xafcdc4: mov             SP, fp
    //     0xafcdc8: ldp             fp, lr, [SP], #0x10
    // 0xafcdcc: ret
    //     0xafcdcc: ret             
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x82e804, size: 0x3c
    // 0x82e804: EnterFrame
    //     0x82e804: stp             fp, lr, [SP, #-0x10]!
    //     0x82e808: mov             fp, SP
    // 0x82e80c: ldr             x0, [fp, #0x18]
    // 0x82e810: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82e810: ldur            w1, [x0, #0x17]
    // 0x82e814: DecompressPointer r1
    //     0x82e814: add             x1, x1, HEAP, lsl #32
    // 0x82e818: CheckStackOverflow
    //     0x82e818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e81c: cmp             SP, x16
    //     0x82e820: b.ls            #0x82e838
    // 0x82e824: ldr             x2, [fp, #0x10]
    // 0x82e828: r0 = contains()
    //     0x82e828: bl              #0xb04088  ; [package:flutter/src/foundation/observer_list.dart] HashedObserverList::contains
    // 0x82e82c: LeaveFrame
    //     0x82e82c: mov             SP, fp
    //     0x82e830: ldp             fp, lr, [SP], #0x10
    // 0x82e834: ret
    //     0x82e834: ret             
    // 0x82e838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e83c: b               #0x82e824
  }
  List<X0> toList(HashedObserverList<X0>, {bool growable}) {
    // ** addr: 0x82e840, size: 0xc0
    // 0x82e840: EnterFrame
    //     0x82e840: stp             fp, lr, [SP, #-0x10]!
    //     0x82e844: mov             fp, SP
    // 0x82e848: AllocStack(0x18)
    //     0x82e848: sub             SP, SP, #0x18
    // 0x82e84c: SetupParameters(HashedObserverList<X0> this /* r3, fp-0x10 */, {dynamic growable = true /* r4, fp-0x8 */})
    //     0x82e84c: ldur            w0, [x4, #0x13]
    //     0x82e850: sub             x1, x0, #2
    //     0x82e854: add             x3, fp, w1, sxtw #2
    //     0x82e858: ldr             x3, [x3, #0x10]
    //     0x82e85c: stur            x3, [fp, #-0x10]
    //     0x82e860: ldur            w1, [x4, #0x1f]
    //     0x82e864: add             x1, x1, HEAP, lsl #32
    //     0x82e868: ldr             x16, [PP, #0x1d80]  ; [pp+0x1d80] "growable"
    //     0x82e86c: cmp             w1, w16
    //     0x82e870: b.ne            #0x82e890
    //     0x82e874: ldur            w1, [x4, #0x23]
    //     0x82e878: add             x1, x1, HEAP, lsl #32
    //     0x82e87c: sub             w2, w0, w1
    //     0x82e880: add             x0, fp, w2, sxtw #2
    //     0x82e884: ldr             x0, [x0, #8]
    //     0x82e888: mov             x4, x0
    //     0x82e88c: b               #0x82e894
    //     0x82e890: add             x4, NULL, #0x20  ; true
    //     0x82e894: stur            x4, [fp, #-8]
    // 0x82e898: CheckStackOverflow
    //     0x82e898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e89c: cmp             SP, x16
    //     0x82e8a0: b.ls            #0x82e8f8
    // 0x82e8a4: mov             x0, x4
    // 0x82e8a8: r2 = Null
    //     0x82e8a8: mov             x2, NULL
    // 0x82e8ac: r1 = Null
    //     0x82e8ac: mov             x1, NULL
    // 0x82e8b0: r4 = 60
    //     0x82e8b0: mov             x4, #0x3c
    // 0x82e8b4: branchIfSmi(r0, 0x82e8c0)
    //     0x82e8b4: tbz             w0, #0, #0x82e8c0
    // 0x82e8b8: r4 = LoadClassIdInstr(r0)
    //     0x82e8b8: ldur            x4, [x0, #-1]
    //     0x82e8bc: ubfx            x4, x4, #0xc, #0x14
    // 0x82e8c0: cmp             x4, #0x3f
    // 0x82e8c4: b.eq            #0x82e8d8
    // 0x82e8c8: r8 = bool
    //     0x82e8c8: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x82e8cc: r3 = Null
    //     0x82e8cc: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fd48] Null
    //     0x82e8d0: ldr             x3, [x3, #0xd48]
    // 0x82e8d4: r0 = bool()
    //     0x82e8d4: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x82e8d8: ldur            x16, [fp, #-8]
    // 0x82e8dc: str             x16, [SP]
    // 0x82e8e0: ldur            x1, [fp, #-0x10]
    // 0x82e8e4: r4 = const [0, 0x2, 0x1, 0x1, growable, 0x1, null]
    //     0x82e8e4: ldr             x4, [PP, #0x1418]  ; [pp+0x1418] List(7) [0, 0x2, 0x1, 0x1, "growable", 0x1, Null]
    // 0x82e8e8: r0 = toList()
    //     0x82e8e8: bl              #0xb08974  ; [package:flutter/src/foundation/observer_list.dart] HashedObserverList::toList
    // 0x82e8ec: LeaveFrame
    //     0x82e8ec: mov             SP, fp
    //     0x82e8f0: ldp             fp, lr, [SP], #0x10
    // 0x82e8f4: ret
    //     0x82e8f4: ret             
    // 0x82e8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e8f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e8fc: b               #0x82e8a4
  }
  bool contains(HashedObserverList<X0>, Object?) {
    // ** addr: 0x82e9d8, size: 0x4c
    // 0x82e9d8: EnterFrame
    //     0x82e9d8: stp             fp, lr, [SP, #-0x10]!
    //     0x82e9dc: mov             fp, SP
    // 0x82e9e0: CheckStackOverflow
    //     0x82e9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e9e4: cmp             SP, x16
    //     0x82e9e8: b.ls            #0x82ea04
    // 0x82e9ec: ldr             x1, [fp, #0x18]
    // 0x82e9f0: ldr             x2, [fp, #0x10]
    // 0x82e9f4: r0 = contains()
    //     0x82e9f4: bl              #0xb04088  ; [package:flutter/src/foundation/observer_list.dart] HashedObserverList::contains
    // 0x82e9f8: LeaveFrame
    //     0x82e9f8: mov             SP, fp
    //     0x82e9fc: ldp             fp, lr, [SP], #0x10
    // 0x82ea00: ret
    //     0x82ea00: ret             
    // 0x82ea04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ea04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ea08: b               #0x82e9ec
  }
  _ clear(/* No info */) {
    // ** addr: 0x91662c, size: 0x3c
    // 0x91662c: EnterFrame
    //     0x91662c: stp             fp, lr, [SP, #-0x10]!
    //     0x916630: mov             fp, SP
    // 0x916634: CheckStackOverflow
    //     0x916634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x916638: cmp             SP, x16
    //     0x91663c: b.ls            #0x916660
    // 0x916640: LoadField: r0 = r1->field_b
    //     0x916640: ldur            w0, [x1, #0xb]
    // 0x916644: DecompressPointer r0
    //     0x916644: add             x0, x0, HEAP, lsl #32
    // 0x916648: mov             x1, x0
    // 0x91664c: r0 = clear()
    //     0x91664c: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x916650: r0 = Null
    //     0x916650: mov             x0, NULL
    // 0x916654: LeaveFrame
    //     0x916654: mov             SP, fp
    //     0x916658: ldp             fp, lr, [SP], #0x10
    // 0x91665c: ret
    //     0x91665c: ret             
    // 0x916660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x916660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x916664: b               #0x916640
  }
  bool isNotEmpty(HashedObserverList<X0>) {
    // ** addr: 0xafbc6c, size: 0x44
    // 0xafbc6c: EnterFrame
    //     0xafbc6c: stp             fp, lr, [SP, #-0x10]!
    //     0xafbc70: mov             fp, SP
    // 0xafbc74: LoadField: r2 = r1->field_b
    //     0xafbc74: ldur            w2, [x1, #0xb]
    // 0xafbc78: DecompressPointer r2
    //     0xafbc78: add             x2, x2, HEAP, lsl #32
    // 0xafbc7c: LoadField: r1 = r2->field_13
    //     0xafbc7c: ldur            w1, [x2, #0x13]
    // 0xafbc80: r3 = LoadInt32Instr(r1)
    //     0xafbc80: sbfx            x3, x1, #1, #0x1f
    // 0xafbc84: asr             x1, x3, #1
    // 0xafbc88: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xafbc88: ldur            w3, [x2, #0x17]
    // 0xafbc8c: r2 = LoadInt32Instr(r3)
    //     0xafbc8c: sbfx            x2, x3, #1, #0x1f
    // 0xafbc90: sub             x3, x1, x2
    // 0xafbc94: cbnz            x3, #0xafbca0
    // 0xafbc98: r0 = false
    //     0xafbc98: add             x0, NULL, #0x30  ; false
    // 0xafbc9c: b               #0xafbca4
    // 0xafbca0: r0 = true
    //     0xafbca0: add             x0, NULL, #0x20  ; true
    // 0xafbca4: LeaveFrame
    //     0xafbca4: mov             SP, fp
    //     0xafbca8: ldp             fp, lr, [SP], #0x10
    // 0xafbcac: ret
    //     0xafbcac: ret             
  }
  bool isEmpty(HashedObserverList<X0>) {
    // ** addr: 0xb01e8c, size: 0x44
    // 0xb01e8c: EnterFrame
    //     0xb01e8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb01e90: mov             fp, SP
    // 0xb01e94: LoadField: r2 = r1->field_b
    //     0xb01e94: ldur            w2, [x1, #0xb]
    // 0xb01e98: DecompressPointer r2
    //     0xb01e98: add             x2, x2, HEAP, lsl #32
    // 0xb01e9c: LoadField: r1 = r2->field_13
    //     0xb01e9c: ldur            w1, [x2, #0x13]
    // 0xb01ea0: r3 = LoadInt32Instr(r1)
    //     0xb01ea0: sbfx            x3, x1, #1, #0x1f
    // 0xb01ea4: asr             x1, x3, #1
    // 0xb01ea8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xb01ea8: ldur            w3, [x2, #0x17]
    // 0xb01eac: r2 = LoadInt32Instr(r3)
    //     0xb01eac: sbfx            x2, x3, #1, #0x1f
    // 0xb01eb0: sub             x3, x1, x2
    // 0xb01eb4: cbz             x3, #0xb01ec0
    // 0xb01eb8: r0 = false
    //     0xb01eb8: add             x0, NULL, #0x30  ; false
    // 0xb01ebc: b               #0xb01ec4
    // 0xb01ec0: r0 = true
    //     0xb01ec0: add             x0, NULL, #0x20  ; true
    // 0xb01ec4: LeaveFrame
    //     0xb01ec4: mov             SP, fp
    //     0xb01ec8: ldp             fp, lr, [SP], #0x10
    // 0xb01ecc: ret
    //     0xb01ecc: ret             
  }
  bool contains(HashedObserverList<X0>, Object?) {
    // ** addr: 0xb04088, size: 0x38
    // 0xb04088: EnterFrame
    //     0xb04088: stp             fp, lr, [SP, #-0x10]!
    //     0xb0408c: mov             fp, SP
    // 0xb04090: CheckStackOverflow
    //     0xb04090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb04094: cmp             SP, x16
    //     0xb04098: b.ls            #0xb040b8
    // 0xb0409c: LoadField: r0 = r1->field_b
    //     0xb0409c: ldur            w0, [x1, #0xb]
    // 0xb040a0: DecompressPointer r0
    //     0xb040a0: add             x0, x0, HEAP, lsl #32
    // 0xb040a4: mov             x1, x0
    // 0xb040a8: r0 = containsKey()
    //     0xb040a8: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xb040ac: LeaveFrame
    //     0xb040ac: mov             SP, fp
    //     0xb040b0: ldp             fp, lr, [SP], #0x10
    // 0xb040b4: ret
    //     0xb040b4: ret             
    // 0xb040b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb040b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb040bc: b               #0xb0409c
  }
  List<X0> toList(HashedObserverList<X0>, {bool growable}) {
    // ** addr: 0xb08974, size: 0x330
    // 0xb08974: EnterFrame
    //     0xb08974: stp             fp, lr, [SP, #-0x10]!
    //     0xb08978: mov             fp, SP
    // 0xb0897c: AllocStack(0x38)
    //     0xb0897c: sub             SP, SP, #0x38
    // 0xb08980: SetupParameters(HashedObserverList<X0> this /* r1 => r0, fp-0x18 */, {dynamic growable = true /* r2, fp-0x10 */})
    //     0xb08980: mov             x0, x1
    //     0xb08984: stur            x1, [fp, #-0x18]
    //     0xb08988: ldur            w1, [x4, #0x13]
    //     0xb0898c: ldur            w2, [x4, #0x1f]
    //     0xb08990: add             x2, x2, HEAP, lsl #32
    //     0xb08994: ldr             x16, [PP, #0x1d80]  ; [pp+0x1d80] "growable"
    //     0xb08998: cmp             w2, w16
    //     0xb0899c: b.ne            #0xb089bc
    //     0xb089a0: ldur            w2, [x4, #0x23]
    //     0xb089a4: add             x2, x2, HEAP, lsl #32
    //     0xb089a8: sub             w3, w1, w2
    //     0xb089ac: add             x1, fp, w3, sxtw #2
    //     0xb089b0: ldr             x1, [x1, #8]
    //     0xb089b4: mov             x2, x1
    //     0xb089b8: b               #0xb089c0
    //     0xb089bc: add             x2, NULL, #0x20  ; true
    //     0xb089c0: stur            x2, [fp, #-0x10]
    // 0xb089c4: CheckStackOverflow
    //     0xb089c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb089c8: cmp             SP, x16
    //     0xb089cc: b.ls            #0xb08c88
    // 0xb089d0: LoadField: r3 = r0->field_b
    //     0xb089d0: ldur            w3, [x0, #0xb]
    // 0xb089d4: DecompressPointer r3
    //     0xb089d4: add             x3, x3, HEAP, lsl #32
    // 0xb089d8: stur            x3, [fp, #-8]
    // 0xb089dc: LoadField: r1 = r3->field_7
    //     0xb089dc: ldur            w1, [x3, #7]
    // 0xb089e0: DecompressPointer r1
    //     0xb089e0: add             x1, x1, HEAP, lsl #32
    // 0xb089e4: r0 = _CompactKeysIterable()
    //     0xb089e4: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xb089e8: mov             x1, x0
    // 0xb089ec: ldur            x0, [fp, #-8]
    // 0xb089f0: StoreField: r1->field_b = r0
    //     0xb089f0: stur            w0, [x1, #0xb]
    // 0xb089f4: r0 = iterator()
    //     0xb089f4: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xb089f8: mov             x3, x0
    // 0xb089fc: ldur            x0, [fp, #-0x18]
    // 0xb08a00: stur            x3, [fp, #-0x28]
    // 0xb08a04: LoadField: r4 = r0->field_7
    //     0xb08a04: ldur            w4, [x0, #7]
    // 0xb08a08: DecompressPointer r4
    //     0xb08a08: add             x4, x4, HEAP, lsl #32
    // 0xb08a0c: ldur            x0, [fp, #-8]
    // 0xb08a10: stur            x4, [fp, #-0x20]
    // 0xb08a14: LoadField: r1 = r0->field_13
    //     0xb08a14: ldur            w1, [x0, #0x13]
    // 0xb08a18: r2 = LoadInt32Instr(r1)
    //     0xb08a18: sbfx            x2, x1, #1, #0x1f
    // 0xb08a1c: asr             x1, x2, #1
    // 0xb08a20: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb08a20: ldur            w2, [x0, #0x17]
    // 0xb08a24: r0 = LoadInt32Instr(r2)
    //     0xb08a24: sbfx            x0, x2, #1, #0x1f
    // 0xb08a28: sub             x5, x1, x0
    // 0xb08a2c: ldur            x0, [fp, #-0x10]
    // 0xb08a30: stur            x5, [fp, #-0x38]
    // 0xb08a34: tbnz            w0, #4, #0xb08b6c
    // 0xb08a38: mov             x1, x4
    // 0xb08a3c: mov             x2, x5
    // 0xb08a40: r0 = _GrowableList()
    //     0xb08a40: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb08a44: mov             x2, x0
    // 0xb08a48: ldur            x0, [fp, #-0x28]
    // 0xb08a4c: stur            x2, [fp, #-0x10]
    // 0xb08a50: LoadField: r3 = r0->field_7
    //     0xb08a50: ldur            w3, [x0, #7]
    // 0xb08a54: DecompressPointer r3
    //     0xb08a54: add             x3, x3, HEAP, lsl #32
    // 0xb08a58: stur            x3, [fp, #-8]
    // 0xb08a5c: r4 = 0
    //     0xb08a5c: mov             x4, #0
    // 0xb08a60: stur            x4, [fp, #-0x30]
    // 0xb08a64: CheckStackOverflow
    //     0xb08a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb08a68: cmp             SP, x16
    //     0xb08a6c: b.ls            #0xb08c90
    // 0xb08a70: LoadField: r1 = r2->field_b
    //     0xb08a70: ldur            w1, [x2, #0xb]
    // 0xb08a74: r5 = LoadInt32Instr(r1)
    //     0xb08a74: sbfx            x5, x1, #1, #0x1f
    // 0xb08a78: cmp             x4, x5
    // 0xb08a7c: b.ge            #0xb08b64
    // 0xb08a80: mov             x1, x0
    // 0xb08a84: r0 = moveNext()
    //     0xb08a84: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xb08a88: ldur            x3, [fp, #-0x28]
    // 0xb08a8c: LoadField: r4 = r3->field_33
    //     0xb08a8c: ldur            w4, [x3, #0x33]
    // 0xb08a90: DecompressPointer r4
    //     0xb08a90: add             x4, x4, HEAP, lsl #32
    // 0xb08a94: stur            x4, [fp, #-0x18]
    // 0xb08a98: cmp             w4, NULL
    // 0xb08a9c: b.ne            #0xb08acc
    // 0xb08aa0: mov             x0, x4
    // 0xb08aa4: ldur            x2, [fp, #-8]
    // 0xb08aa8: r1 = Null
    //     0xb08aa8: mov             x1, NULL
    // 0xb08aac: cmp             w2, NULL
    // 0xb08ab0: b.eq            #0xb08acc
    // 0xb08ab4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb08ab4: ldur            w4, [x2, #0x17]
    // 0xb08ab8: DecompressPointer r4
    //     0xb08ab8: add             x4, x4, HEAP, lsl #32
    // 0xb08abc: r8 = X0
    //     0xb08abc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb08ac0: LoadField: r9 = r4->field_7
    //     0xb08ac0: ldur            x9, [x4, #7]
    // 0xb08ac4: r3 = Null
    //     0xb08ac4: ldr             x3, [PP, #0x1d88]  ; [pp+0x1d88] Null
    // 0xb08ac8: blr             x9
    // 0xb08acc: ldur            x3, [fp, #-0x10]
    // 0xb08ad0: ldur            x4, [fp, #-0x30]
    // 0xb08ad4: ldur            x0, [fp, #-0x18]
    // 0xb08ad8: ldur            x2, [fp, #-0x20]
    // 0xb08adc: r1 = Null
    //     0xb08adc: mov             x1, NULL
    // 0xb08ae0: cmp             w2, NULL
    // 0xb08ae4: b.eq            #0xb08b00
    // 0xb08ae8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb08ae8: ldur            w4, [x2, #0x17]
    // 0xb08aec: DecompressPointer r4
    //     0xb08aec: add             x4, x4, HEAP, lsl #32
    // 0xb08af0: r8 = X0
    //     0xb08af0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb08af4: LoadField: r9 = r4->field_7
    //     0xb08af4: ldur            x9, [x4, #7]
    // 0xb08af8: r3 = Null
    //     0xb08af8: ldr             x3, [PP, #0x1d98]  ; [pp+0x1d98] Null
    // 0xb08afc: blr             x9
    // 0xb08b00: ldur            x2, [fp, #-0x10]
    // 0xb08b04: LoadField: r0 = r2->field_b
    //     0xb08b04: ldur            w0, [x2, #0xb]
    // 0xb08b08: r1 = LoadInt32Instr(r0)
    //     0xb08b08: sbfx            x1, x0, #1, #0x1f
    // 0xb08b0c: mov             x0, x1
    // 0xb08b10: ldur            x1, [fp, #-0x30]
    // 0xb08b14: cmp             x1, x0
    // 0xb08b18: b.hs            #0xb08c98
    // 0xb08b1c: LoadField: r1 = r2->field_f
    //     0xb08b1c: ldur            w1, [x2, #0xf]
    // 0xb08b20: DecompressPointer r1
    //     0xb08b20: add             x1, x1, HEAP, lsl #32
    // 0xb08b24: ldur            x0, [fp, #-0x18]
    // 0xb08b28: ldur            x3, [fp, #-0x30]
    // 0xb08b2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb08b2c: add             x25, x1, x3, lsl #2
    //     0xb08b30: add             x25, x25, #0xf
    //     0xb08b34: str             w0, [x25]
    //     0xb08b38: tbz             w0, #0, #0xb08b54
    //     0xb08b3c: ldurb           w16, [x1, #-1]
    //     0xb08b40: ldurb           w17, [x0, #-1]
    //     0xb08b44: and             x16, x17, x16, lsr #2
    //     0xb08b48: tst             x16, HEAP, lsr #32
    //     0xb08b4c: b.eq            #0xb08b54
    //     0xb08b50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb08b54: add             x4, x3, #1
    // 0xb08b58: ldur            x0, [fp, #-0x28]
    // 0xb08b5c: ldur            x3, [fp, #-8]
    // 0xb08b60: b               #0xb08a60
    // 0xb08b64: mov             x0, x2
    // 0xb08b68: b               #0xb08c7c
    // 0xb08b6c: mov             x0, x3
    // 0xb08b70: lsl             x2, x5, #1
    // 0xb08b74: ldur            x1, [fp, #-0x20]
    // 0xb08b78: r0 = AllocateArray()
    //     0xb08b78: bl              #0x13df928  ; AllocateArrayStub
    // 0xb08b7c: mov             x2, x0
    // 0xb08b80: ldur            x0, [fp, #-0x28]
    // 0xb08b84: stur            x2, [fp, #-0x10]
    // 0xb08b88: LoadField: r3 = r0->field_7
    //     0xb08b88: ldur            w3, [x0, #7]
    // 0xb08b8c: DecompressPointer r3
    //     0xb08b8c: add             x3, x3, HEAP, lsl #32
    // 0xb08b90: stur            x3, [fp, #-8]
    // 0xb08b94: r5 = 0
    //     0xb08b94: mov             x5, #0
    // 0xb08b98: ldur            x4, [fp, #-0x38]
    // 0xb08b9c: stur            x5, [fp, #-0x30]
    // 0xb08ba0: CheckStackOverflow
    //     0xb08ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb08ba4: cmp             SP, x16
    //     0xb08ba8: b.ls            #0xb08c9c
    // 0xb08bac: cmp             x5, x4
    // 0xb08bb0: b.ge            #0xb08c78
    // 0xb08bb4: mov             x1, x0
    // 0xb08bb8: r0 = moveNext()
    //     0xb08bb8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xb08bbc: ldur            x3, [fp, #-0x28]
    // 0xb08bc0: LoadField: r4 = r3->field_33
    //     0xb08bc0: ldur            w4, [x3, #0x33]
    // 0xb08bc4: DecompressPointer r4
    //     0xb08bc4: add             x4, x4, HEAP, lsl #32
    // 0xb08bc8: stur            x4, [fp, #-0x18]
    // 0xb08bcc: cmp             w4, NULL
    // 0xb08bd0: b.ne            #0xb08c00
    // 0xb08bd4: mov             x0, x4
    // 0xb08bd8: ldur            x2, [fp, #-8]
    // 0xb08bdc: r1 = Null
    //     0xb08bdc: mov             x1, NULL
    // 0xb08be0: cmp             w2, NULL
    // 0xb08be4: b.eq            #0xb08c00
    // 0xb08be8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb08be8: ldur            w4, [x2, #0x17]
    // 0xb08bec: DecompressPointer r4
    //     0xb08bec: add             x4, x4, HEAP, lsl #32
    // 0xb08bf0: r8 = X0
    //     0xb08bf0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb08bf4: LoadField: r9 = r4->field_7
    //     0xb08bf4: ldur            x9, [x4, #7]
    // 0xb08bf8: r3 = Null
    //     0xb08bf8: ldr             x3, [PP, #0x1da8]  ; [pp+0x1da8] Null
    // 0xb08bfc: blr             x9
    // 0xb08c00: ldur            x3, [fp, #-0x30]
    // 0xb08c04: ldur            x0, [fp, #-0x18]
    // 0xb08c08: ldur            x2, [fp, #-0x20]
    // 0xb08c0c: r1 = Null
    //     0xb08c0c: mov             x1, NULL
    // 0xb08c10: cmp             w2, NULL
    // 0xb08c14: b.eq            #0xb08c30
    // 0xb08c18: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb08c18: ldur            w4, [x2, #0x17]
    // 0xb08c1c: DecompressPointer r4
    //     0xb08c1c: add             x4, x4, HEAP, lsl #32
    // 0xb08c20: r8 = X0
    //     0xb08c20: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb08c24: LoadField: r9 = r4->field_7
    //     0xb08c24: ldur            x9, [x4, #7]
    // 0xb08c28: r3 = Null
    //     0xb08c28: ldr             x3, [PP, #0x1db8]  ; [pp+0x1db8] Null
    // 0xb08c2c: blr             x9
    // 0xb08c30: ldur            x1, [fp, #-0x10]
    // 0xb08c34: ldur            x0, [fp, #-0x18]
    // 0xb08c38: ldur            x2, [fp, #-0x30]
    // 0xb08c3c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb08c3c: add             x25, x1, x2, lsl #2
    //     0xb08c40: add             x25, x25, #0xf
    //     0xb08c44: str             w0, [x25]
    //     0xb08c48: tbz             w0, #0, #0xb08c64
    //     0xb08c4c: ldurb           w16, [x1, #-1]
    //     0xb08c50: ldurb           w17, [x0, #-1]
    //     0xb08c54: and             x16, x17, x16, lsr #2
    //     0xb08c58: tst             x16, HEAP, lsr #32
    //     0xb08c5c: b.eq            #0xb08c64
    //     0xb08c60: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb08c64: add             x5, x2, #1
    // 0xb08c68: ldur            x0, [fp, #-0x28]
    // 0xb08c6c: ldur            x2, [fp, #-0x10]
    // 0xb08c70: ldur            x3, [fp, #-8]
    // 0xb08c74: b               #0xb08b98
    // 0xb08c78: ldur            x0, [fp, #-0x10]
    // 0xb08c7c: LeaveFrame
    //     0xb08c7c: mov             SP, fp
    //     0xb08c80: ldp             fp, lr, [SP], #0x10
    // 0xb08c84: ret
    //     0xb08c84: ret             
    // 0xb08c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb08c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb08c8c: b               #0xb089d0
    // 0xb08c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb08c90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb08c94: b               #0xb08a70
    // 0xb08c98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb08c98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb08c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb08c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb08ca0: b               #0xb08bac
  }
  get _ iterator(/* No info */) {
    // ** addr: 0xb0a79c, size: 0x54
    // 0xb0a79c: EnterFrame
    //     0xb0a79c: stp             fp, lr, [SP, #-0x10]!
    //     0xb0a7a0: mov             fp, SP
    // 0xb0a7a4: AllocStack(0x8)
    //     0xb0a7a4: sub             SP, SP, #8
    // 0xb0a7a8: CheckStackOverflow
    //     0xb0a7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb0a7ac: cmp             SP, x16
    //     0xb0a7b0: b.ls            #0xb0a7e8
    // 0xb0a7b4: LoadField: r0 = r1->field_b
    //     0xb0a7b4: ldur            w0, [x1, #0xb]
    // 0xb0a7b8: DecompressPointer r0
    //     0xb0a7b8: add             x0, x0, HEAP, lsl #32
    // 0xb0a7bc: stur            x0, [fp, #-8]
    // 0xb0a7c0: LoadField: r1 = r0->field_7
    //     0xb0a7c0: ldur            w1, [x0, #7]
    // 0xb0a7c4: DecompressPointer r1
    //     0xb0a7c4: add             x1, x1, HEAP, lsl #32
    // 0xb0a7c8: r0 = _CompactKeysIterable()
    //     0xb0a7c8: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xb0a7cc: mov             x1, x0
    // 0xb0a7d0: ldur            x0, [fp, #-8]
    // 0xb0a7d4: StoreField: r1->field_b = r0
    //     0xb0a7d4: stur            w0, [x1, #0xb]
    // 0xb0a7d8: r0 = iterator()
    //     0xb0a7d8: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xb0a7dc: LeaveFrame
    //     0xb0a7dc: mov             SP, fp
    //     0xb0a7e0: ldp             fp, lr, [SP], #0x10
    // 0xb0a7e4: ret
    //     0xb0a7e4: ret             
    // 0xb0a7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0a7e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0a7ec: b               #0xb0a7b4
  }
  _ remove(/* No info */) {
    // ** addr: 0xd00a44, size: 0x10c
    // 0xd00a44: EnterFrame
    //     0xd00a44: stp             fp, lr, [SP, #-0x10]!
    //     0xd00a48: mov             fp, SP
    // 0xd00a4c: AllocStack(0x18)
    //     0xd00a4c: sub             SP, SP, #0x18
    // 0xd00a50: SetupParameters(HashedObserverList<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xd00a50: mov             x4, x1
    //     0xd00a54: mov             x3, x2
    //     0xd00a58: stur            x1, [fp, #-8]
    //     0xd00a5c: stur            x2, [fp, #-0x10]
    // 0xd00a60: CheckStackOverflow
    //     0xd00a60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00a64: cmp             SP, x16
    //     0xd00a68: b.ls            #0xd00b48
    // 0xd00a6c: LoadField: r2 = r4->field_7
    //     0xd00a6c: ldur            w2, [x4, #7]
    // 0xd00a70: DecompressPointer r2
    //     0xd00a70: add             x2, x2, HEAP, lsl #32
    // 0xd00a74: mov             x0, x3
    // 0xd00a78: r1 = Null
    //     0xd00a78: mov             x1, NULL
    // 0xd00a7c: cmp             w2, NULL
    // 0xd00a80: b.eq            #0xd00aa0
    // 0xd00a84: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd00a84: ldur            w4, [x2, #0x17]
    // 0xd00a88: DecompressPointer r4
    //     0xd00a88: add             x4, x4, HEAP, lsl #32
    // 0xd00a8c: r8 = X0
    //     0xd00a8c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd00a90: LoadField: r9 = r4->field_7
    //     0xd00a90: ldur            x9, [x4, #7]
    // 0xd00a94: r3 = Null
    //     0xd00a94: add             x3, PP, #0x15, lsl #12  ; [pp+0x15670] Null
    //     0xd00a98: ldr             x3, [x3, #0x670]
    // 0xd00a9c: blr             x9
    // 0xd00aa0: ldur            x0, [fp, #-8]
    // 0xd00aa4: LoadField: r3 = r0->field_b
    //     0xd00aa4: ldur            w3, [x0, #0xb]
    // 0xd00aa8: DecompressPointer r3
    //     0xd00aa8: add             x3, x3, HEAP, lsl #32
    // 0xd00aac: mov             x1, x3
    // 0xd00ab0: ldur            x2, [fp, #-0x10]
    // 0xd00ab4: stur            x3, [fp, #-0x18]
    // 0xd00ab8: r0 = _getValueOrData()
    //     0xd00ab8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd00abc: ldur            x2, [fp, #-0x18]
    // 0xd00ac0: LoadField: r1 = r2->field_f
    //     0xd00ac0: ldur            w1, [x2, #0xf]
    // 0xd00ac4: DecompressPointer r1
    //     0xd00ac4: add             x1, x1, HEAP, lsl #32
    // 0xd00ac8: cmp             w1, w0
    // 0xd00acc: b.ne            #0xd00ad4
    // 0xd00ad0: r0 = Null
    //     0xd00ad0: mov             x0, NULL
    // 0xd00ad4: cmp             w0, NULL
    // 0xd00ad8: b.ne            #0xd00aec
    // 0xd00adc: r0 = false
    //     0xd00adc: add             x0, NULL, #0x30  ; false
    // 0xd00ae0: LeaveFrame
    //     0xd00ae0: mov             SP, fp
    //     0xd00ae4: ldp             fp, lr, [SP], #0x10
    // 0xd00ae8: ret
    //     0xd00ae8: ret             
    // 0xd00aec: cmp             w0, #2
    // 0xd00af0: b.ne            #0xd00b04
    // 0xd00af4: mov             x1, x2
    // 0xd00af8: ldur            x2, [fp, #-0x10]
    // 0xd00afc: r0 = remove()
    //     0xd00afc: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xd00b00: b               #0xd00b38
    // 0xd00b04: r1 = LoadInt32Instr(r0)
    //     0xd00b04: sbfx            x1, x0, #1, #0x1f
    //     0xd00b08: tbz             w0, #0, #0xd00b10
    //     0xd00b0c: ldur            x1, [x0, #7]
    // 0xd00b10: sub             x3, x1, #1
    // 0xd00b14: r0 = BoxInt64Instr(r3)
    //     0xd00b14: sbfiz           x0, x3, #1, #0x1f
    //     0xd00b18: cmp             x3, x0, asr #1
    //     0xd00b1c: b.eq            #0xd00b28
    //     0xd00b20: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd00b24: stur            x3, [x0, #7]
    // 0xd00b28: mov             x1, x2
    // 0xd00b2c: ldur            x2, [fp, #-0x10]
    // 0xd00b30: mov             x3, x0
    // 0xd00b34: r0 = []=()
    //     0xd00b34: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd00b38: r0 = true
    //     0xd00b38: add             x0, NULL, #0x20  ; true
    // 0xd00b3c: LeaveFrame
    //     0xd00b3c: mov             SP, fp
    //     0xd00b40: ldp             fp, lr, [SP], #0x10
    // 0xd00b44: ret
    //     0xd00b44: ret             
    // 0xd00b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00b4c: b               #0xd00a6c
  }
  _ add(/* No info */) {
    // ** addr: 0xd04154, size: 0x184
    // 0xd04154: EnterFrame
    //     0xd04154: stp             fp, lr, [SP, #-0x10]!
    //     0xd04158: mov             fp, SP
    // 0xd0415c: AllocStack(0x20)
    //     0xd0415c: sub             SP, SP, #0x20
    // 0xd04160: SetupParameters(HashedObserverList<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xd04160: mov             x4, x1
    //     0xd04164: mov             x3, x2
    //     0xd04168: stur            x1, [fp, #-8]
    //     0xd0416c: stur            x2, [fp, #-0x10]
    // 0xd04170: CheckStackOverflow
    //     0xd04170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04174: cmp             SP, x16
    //     0xd04178: b.ls            #0xd042d0
    // 0xd0417c: LoadField: r2 = r4->field_7
    //     0xd0417c: ldur            w2, [x4, #7]
    // 0xd04180: DecompressPointer r2
    //     0xd04180: add             x2, x2, HEAP, lsl #32
    // 0xd04184: mov             x0, x3
    // 0xd04188: r1 = Null
    //     0xd04188: mov             x1, NULL
    // 0xd0418c: cmp             w2, NULL
    // 0xd04190: b.eq            #0xd041ac
    // 0xd04194: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd04194: ldur            w4, [x2, #0x17]
    // 0xd04198: DecompressPointer r4
    //     0xd04198: add             x4, x4, HEAP, lsl #32
    // 0xd0419c: r8 = X0
    //     0xd0419c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd041a0: LoadField: r9 = r4->field_7
    //     0xd041a0: ldur            x9, [x4, #7]
    // 0xd041a4: r3 = Null
    //     0xd041a4: ldr             x3, [PP, #0x5af8]  ; [pp+0x5af8] Null
    // 0xd041a8: blr             x9
    // 0xd041ac: ldur            x0, [fp, #-8]
    // 0xd041b0: LoadField: r3 = r0->field_b
    //     0xd041b0: ldur            w3, [x0, #0xb]
    // 0xd041b4: DecompressPointer r3
    //     0xd041b4: add             x3, x3, HEAP, lsl #32
    // 0xd041b8: mov             x1, x3
    // 0xd041bc: ldur            x2, [fp, #-0x10]
    // 0xd041c0: stur            x3, [fp, #-0x18]
    // 0xd041c4: r0 = _getValueOrData()
    //     0xd041c4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd041c8: ldur            x3, [fp, #-0x18]
    // 0xd041cc: LoadField: r1 = r3->field_f
    //     0xd041cc: ldur            w1, [x3, #0xf]
    // 0xd041d0: DecompressPointer r1
    //     0xd041d0: add             x1, x1, HEAP, lsl #32
    // 0xd041d4: cmp             w1, w0
    // 0xd041d8: b.ne            #0xd041e0
    // 0xd041dc: r0 = Null
    //     0xd041dc: mov             x0, NULL
    // 0xd041e0: cmp             w0, NULL
    // 0xd041e4: b.ne            #0xd041f0
    // 0xd041e8: r0 = 0
    //     0xd041e8: mov             x0, #0
    // 0xd041ec: b               #0xd04200
    // 0xd041f0: r1 = LoadInt32Instr(r0)
    //     0xd041f0: sbfx            x1, x0, #1, #0x1f
    //     0xd041f4: tbz             w0, #0, #0xd041fc
    //     0xd041f8: ldur            x1, [x0, #7]
    // 0xd041fc: mov             x0, x1
    // 0xd04200: add             x4, x0, #1
    // 0xd04204: stur            x4, [fp, #-0x20]
    // 0xd04208: LoadField: r5 = r3->field_7
    //     0xd04208: ldur            w5, [x3, #7]
    // 0xd0420c: DecompressPointer r5
    //     0xd0420c: add             x5, x5, HEAP, lsl #32
    // 0xd04210: ldur            x0, [fp, #-0x10]
    // 0xd04214: mov             x2, x5
    // 0xd04218: stur            x5, [fp, #-8]
    // 0xd0421c: r1 = Null
    //     0xd0421c: mov             x1, NULL
    // 0xd04220: cmp             w2, NULL
    // 0xd04224: b.eq            #0xd04240
    // 0xd04228: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd04228: ldur            w4, [x2, #0x17]
    // 0xd0422c: DecompressPointer r4
    //     0xd0422c: add             x4, x4, HEAP, lsl #32
    // 0xd04230: r8 = X0
    //     0xd04230: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd04234: LoadField: r9 = r4->field_7
    //     0xd04234: ldur            x9, [x4, #7]
    // 0xd04238: r3 = Null
    //     0xd04238: ldr             x3, [PP, #0x5b08]  ; [pp+0x5b08] Null
    // 0xd0423c: blr             x9
    // 0xd04240: ldur            x2, [fp, #-0x20]
    // 0xd04244: r0 = BoxInt64Instr(r2)
    //     0xd04244: sbfiz           x0, x2, #1, #0x1f
    //     0xd04248: cmp             x2, x0, asr #1
    //     0xd0424c: b.eq            #0xd04258
    //     0xd04250: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd04254: stur            x2, [x0, #7]
    // 0xd04258: ldur            x2, [fp, #-8]
    // 0xd0425c: mov             x3, x0
    // 0xd04260: r1 = Null
    //     0xd04260: mov             x1, NULL
    // 0xd04264: stur            x3, [fp, #-8]
    // 0xd04268: cmp             w2, NULL
    // 0xd0426c: b.eq            #0xd04288
    // 0xd04270: LoadField: r4 = r2->field_1b
    //     0xd04270: ldur            w4, [x2, #0x1b]
    // 0xd04274: DecompressPointer r4
    //     0xd04274: add             x4, x4, HEAP, lsl #32
    // 0xd04278: r8 = X1
    //     0xd04278: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0xd0427c: LoadField: r9 = r4->field_7
    //     0xd0427c: ldur            x9, [x4, #7]
    // 0xd04280: r3 = Null
    //     0xd04280: ldr             x3, [PP, #0x5b18]  ; [pp+0x5b18] Null
    // 0xd04284: blr             x9
    // 0xd04288: ldur            x1, [fp, #-0x18]
    // 0xd0428c: ldur            x2, [fp, #-0x10]
    // 0xd04290: r0 = _hashCode()
    //     0xd04290: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0xd04294: mov             x2, x0
    // 0xd04298: r0 = BoxInt64Instr(r2)
    //     0xd04298: sbfiz           x0, x2, #1, #0x1f
    //     0xd0429c: cmp             x2, x0, asr #1
    //     0xd042a0: b.eq            #0xd042ac
    //     0xd042a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd042a8: stur            x2, [x0, #7]
    // 0xd042ac: ldur            x1, [fp, #-0x18]
    // 0xd042b0: ldur            x2, [fp, #-0x10]
    // 0xd042b4: ldur            x3, [fp, #-8]
    // 0xd042b8: mov             x5, x0
    // 0xd042bc: r0 = _set()
    //     0xd042bc: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xd042c0: r0 = Null
    //     0xd042c0: mov             x0, NULL
    // 0xd042c4: LeaveFrame
    //     0xd042c4: mov             SP, fp
    //     0xd042c8: ldp             fp, lr, [SP], #0x10
    // 0xd042cc: ret
    //     0xd042cc: ret             
    // 0xd042d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd042d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd042d4: b               #0xd0417c
  }
}

// class id: 7684, size: 0x18, field offset: 0xc
class ObserverList<X0> extends Iterable<X0> {

  late final HashSet<X0> _set; // offset: 0x14

  dynamic contains(dynamic) {
    // ** addr: 0xafcd70, size: 0x3c
    // 0xafcd70: EnterFrame
    //     0xafcd70: stp             fp, lr, [SP, #-0x10]!
    //     0xafcd74: mov             fp, SP
    // 0xafcd78: ldr             x2, [fp, #0x10]
    // 0xafcd7c: r1 = Function 'contains':.
    //     0xafcd7c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10e20] AnonymousClosure: (0x827d48), in [package:flutter/src/foundation/observer_list.dart] ObserverList::contains (0xb03fac)
    //     0xafcd80: ldr             x1, [x1, #0xe20]
    // 0xafcd84: r0 = AllocateClosure()
    //     0xafcd84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xafcd88: LeaveFrame
    //     0xafcd88: mov             SP, fp
    //     0xafcd8c: ldp             fp, lr, [SP], #0x10
    // 0xafcd90: ret
    //     0xafcd90: ret             
  }
  bool dyn:get:isEmpty(ObserverList<X0>) {
    // ** addr: 0x827bdc, size: 0x3c
    // 0x827bdc: ldr             x1, [SP]
    // 0x827be0: LoadField: r2 = r1->field_b
    //     0x827be0: ldur            w2, [x1, #0xb]
    // 0x827be4: DecompressPointer r2
    //     0x827be4: add             x2, x2, HEAP, lsl #32
    // 0x827be8: LoadField: r1 = r2->field_b
    //     0x827be8: ldur            w1, [x2, #0xb]
    // 0x827bec: cbz             w1, #0x827bf8
    // 0x827bf0: r0 = false
    //     0x827bf0: add             x0, NULL, #0x30  ; false
    // 0x827bf4: b               #0x827bfc
    // 0x827bf8: r0 = true
    //     0x827bf8: add             x0, NULL, #0x20  ; true
    // 0x827bfc: ret
    //     0x827bfc: ret             
  }
  List<X0> toList(ObserverList<X0>, {bool growable}) {
    // ** addr: 0x827c00, size: 0xc0
    // 0x827c00: EnterFrame
    //     0x827c00: stp             fp, lr, [SP, #-0x10]!
    //     0x827c04: mov             fp, SP
    // 0x827c08: AllocStack(0x18)
    //     0x827c08: sub             SP, SP, #0x18
    // 0x827c0c: SetupParameters(ObserverList<X0> this /* r3, fp-0x10 */, {dynamic growable = true /* r4, fp-0x8 */})
    //     0x827c0c: ldur            w0, [x4, #0x13]
    //     0x827c10: sub             x1, x0, #2
    //     0x827c14: add             x3, fp, w1, sxtw #2
    //     0x827c18: ldr             x3, [x3, #0x10]
    //     0x827c1c: stur            x3, [fp, #-0x10]
    //     0x827c20: ldur            w1, [x4, #0x1f]
    //     0x827c24: add             x1, x1, HEAP, lsl #32
    //     0x827c28: ldr             x16, [PP, #0x1d80]  ; [pp+0x1d80] "growable"
    //     0x827c2c: cmp             w1, w16
    //     0x827c30: b.ne            #0x827c50
    //     0x827c34: ldur            w1, [x4, #0x23]
    //     0x827c38: add             x1, x1, HEAP, lsl #32
    //     0x827c3c: sub             w2, w0, w1
    //     0x827c40: add             x0, fp, w2, sxtw #2
    //     0x827c44: ldr             x0, [x0, #8]
    //     0x827c48: mov             x4, x0
    //     0x827c4c: b               #0x827c54
    //     0x827c50: add             x4, NULL, #0x20  ; true
    //     0x827c54: stur            x4, [fp, #-8]
    // 0x827c58: CheckStackOverflow
    //     0x827c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827c5c: cmp             SP, x16
    //     0x827c60: b.ls            #0x827cb8
    // 0x827c64: mov             x0, x4
    // 0x827c68: r2 = Null
    //     0x827c68: mov             x2, NULL
    // 0x827c6c: r1 = Null
    //     0x827c6c: mov             x1, NULL
    // 0x827c70: r4 = 60
    //     0x827c70: mov             x4, #0x3c
    // 0x827c74: branchIfSmi(r0, 0x827c80)
    //     0x827c74: tbz             w0, #0, #0x827c80
    // 0x827c78: r4 = LoadClassIdInstr(r0)
    //     0x827c78: ldur            x4, [x0, #-1]
    //     0x827c7c: ubfx            x4, x4, #0xc, #0x14
    // 0x827c80: cmp             x4, #0x3f
    // 0x827c84: b.eq            #0x827c98
    // 0x827c88: r8 = bool
    //     0x827c88: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x827c8c: r3 = Null
    //     0x827c8c: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fd58] Null
    //     0x827c90: ldr             x3, [x3, #0xd58]
    // 0x827c94: r0 = bool()
    //     0x827c94: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x827c98: ldur            x16, [fp, #-8]
    // 0x827c9c: str             x16, [SP]
    // 0x827ca0: ldur            x1, [fp, #-0x10]
    // 0x827ca4: r4 = const [0, 0x2, 0x1, 0x1, growable, 0x1, null]
    //     0x827ca4: ldr             x4, [PP, #0x1418]  ; [pp+0x1418] List(7) [0, 0x2, 0x1, 0x1, "growable", 0x1, Null]
    // 0x827ca8: r0 = toList()
    //     0x827ca8: bl              #0xb088fc  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::toList
    // 0x827cac: LeaveFrame
    //     0x827cac: mov             SP, fp
    //     0x827cb0: ldp             fp, lr, [SP], #0x10
    // 0x827cb4: ret
    //     0x827cb4: ret             
    // 0x827cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827cb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827cbc: b               #0x827c64
  }
  bool dyn:get:isNotEmpty(ObserverList<X0>) {
    // ** addr: 0x827cd8, size: 0x3c
    // 0x827cd8: ldr             x1, [SP]
    // 0x827cdc: LoadField: r2 = r1->field_b
    //     0x827cdc: ldur            w2, [x1, #0xb]
    // 0x827ce0: DecompressPointer r2
    //     0x827ce0: add             x2, x2, HEAP, lsl #32
    // 0x827ce4: LoadField: r1 = r2->field_b
    //     0x827ce4: ldur            w1, [x2, #0xb]
    // 0x827ce8: cbnz            w1, #0x827cf4
    // 0x827cec: r0 = false
    //     0x827cec: add             x0, NULL, #0x30  ; false
    // 0x827cf0: b               #0x827cf8
    // 0x827cf4: r0 = true
    //     0x827cf4: add             x0, NULL, #0x20  ; true
    // 0x827cf8: ret
    //     0x827cf8: ret             
  }
  bool contains(ObserverList<X0>, Object?) {
    // ** addr: 0x827d14, size: 0x4c
    // 0x827d14: EnterFrame
    //     0x827d14: stp             fp, lr, [SP, #-0x10]!
    //     0x827d18: mov             fp, SP
    // 0x827d1c: CheckStackOverflow
    //     0x827d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827d20: cmp             SP, x16
    //     0x827d24: b.ls            #0x827d40
    // 0x827d28: ldr             x1, [fp, #0x18]
    // 0x827d2c: ldr             x2, [fp, #0x10]
    // 0x827d30: r0 = contains()
    //     0x827d30: bl              #0xb03fac  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x827d34: LeaveFrame
    //     0x827d34: mov             SP, fp
    //     0x827d38: ldp             fp, lr, [SP], #0x10
    // 0x827d3c: ret
    //     0x827d3c: ret             
    // 0x827d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827d44: b               #0x827d28
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x827d48, size: 0x3c
    // 0x827d48: EnterFrame
    //     0x827d48: stp             fp, lr, [SP, #-0x10]!
    //     0x827d4c: mov             fp, SP
    // 0x827d50: ldr             x0, [fp, #0x18]
    // 0x827d54: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x827d54: ldur            w1, [x0, #0x17]
    // 0x827d58: DecompressPointer r1
    //     0x827d58: add             x1, x1, HEAP, lsl #32
    // 0x827d5c: CheckStackOverflow
    //     0x827d5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827d60: cmp             SP, x16
    //     0x827d64: b.ls            #0x827d7c
    // 0x827d68: ldr             x2, [fp, #0x10]
    // 0x827d6c: r0 = contains()
    //     0x827d6c: bl              #0xb03fac  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x827d70: LeaveFrame
    //     0x827d70: mov             SP, fp
    //     0x827d74: ldp             fp, lr, [SP], #0x10
    // 0x827d78: ret
    //     0x827d78: ret             
    // 0x827d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827d80: b               #0x827d68
  }
  _ add(/* No info */) {
    // ** addr: 0x83b5e8, size: 0x130
    // 0x83b5e8: EnterFrame
    //     0x83b5e8: stp             fp, lr, [SP, #-0x10]!
    //     0x83b5ec: mov             fp, SP
    // 0x83b5f0: AllocStack(0x20)
    //     0x83b5f0: sub             SP, SP, #0x20
    // 0x83b5f4: SetupParameters(ObserverList<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x83b5f4: mov             x4, x1
    //     0x83b5f8: mov             x3, x2
    //     0x83b5fc: stur            x1, [fp, #-8]
    //     0x83b600: stur            x2, [fp, #-0x10]
    // 0x83b604: CheckStackOverflow
    //     0x83b604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83b608: cmp             SP, x16
    //     0x83b60c: b.ls            #0x83b710
    // 0x83b610: LoadField: r2 = r4->field_7
    //     0x83b610: ldur            w2, [x4, #7]
    // 0x83b614: DecompressPointer r2
    //     0x83b614: add             x2, x2, HEAP, lsl #32
    // 0x83b618: mov             x0, x3
    // 0x83b61c: r1 = Null
    //     0x83b61c: mov             x1, NULL
    // 0x83b620: cmp             w2, NULL
    // 0x83b624: b.eq            #0x83b640
    // 0x83b628: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x83b628: ldur            w4, [x2, #0x17]
    // 0x83b62c: DecompressPointer r4
    //     0x83b62c: add             x4, x4, HEAP, lsl #32
    // 0x83b630: r8 = X0
    //     0x83b630: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x83b634: LoadField: r9 = r4->field_7
    //     0x83b634: ldur            x9, [x4, #7]
    // 0x83b638: r3 = Null
    //     0x83b638: ldr             x3, [PP, #0x1dc8]  ; [pp+0x1dc8] Null
    // 0x83b63c: blr             x9
    // 0x83b640: ldur            x1, [fp, #-8]
    // 0x83b644: r0 = true
    //     0x83b644: add             x0, NULL, #0x20  ; true
    // 0x83b648: StoreField: r1->field_f = r0
    //     0x83b648: stur            w0, [x1, #0xf]
    // 0x83b64c: LoadField: r3 = r1->field_b
    //     0x83b64c: ldur            w3, [x1, #0xb]
    // 0x83b650: DecompressPointer r3
    //     0x83b650: add             x3, x3, HEAP, lsl #32
    // 0x83b654: stur            x3, [fp, #-0x18]
    // 0x83b658: LoadField: r2 = r3->field_7
    //     0x83b658: ldur            w2, [x3, #7]
    // 0x83b65c: DecompressPointer r2
    //     0x83b65c: add             x2, x2, HEAP, lsl #32
    // 0x83b660: ldur            x0, [fp, #-0x10]
    // 0x83b664: r1 = Null
    //     0x83b664: mov             x1, NULL
    // 0x83b668: cmp             w2, NULL
    // 0x83b66c: b.eq            #0x83b688
    // 0x83b670: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x83b670: ldur            w4, [x2, #0x17]
    // 0x83b674: DecompressPointer r4
    //     0x83b674: add             x4, x4, HEAP, lsl #32
    // 0x83b678: r8 = X0
    //     0x83b678: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x83b67c: LoadField: r9 = r4->field_7
    //     0x83b67c: ldur            x9, [x4, #7]
    // 0x83b680: r3 = Null
    //     0x83b680: ldr             x3, [PP, #0x1dd8]  ; [pp+0x1dd8] Null
    // 0x83b684: blr             x9
    // 0x83b688: ldur            x0, [fp, #-0x18]
    // 0x83b68c: LoadField: r1 = r0->field_b
    //     0x83b68c: ldur            w1, [x0, #0xb]
    // 0x83b690: LoadField: r2 = r0->field_f
    //     0x83b690: ldur            w2, [x0, #0xf]
    // 0x83b694: DecompressPointer r2
    //     0x83b694: add             x2, x2, HEAP, lsl #32
    // 0x83b698: LoadField: r3 = r2->field_b
    //     0x83b698: ldur            w3, [x2, #0xb]
    // 0x83b69c: r2 = LoadInt32Instr(r1)
    //     0x83b69c: sbfx            x2, x1, #1, #0x1f
    // 0x83b6a0: stur            x2, [fp, #-0x20]
    // 0x83b6a4: r1 = LoadInt32Instr(r3)
    //     0x83b6a4: sbfx            x1, x3, #1, #0x1f
    // 0x83b6a8: cmp             x2, x1
    // 0x83b6ac: b.ne            #0x83b6b8
    // 0x83b6b0: mov             x1, x0
    // 0x83b6b4: r0 = _growToNextCapacity()
    //     0x83b6b4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x83b6b8: ldur            x2, [fp, #-0x18]
    // 0x83b6bc: ldur            x3, [fp, #-0x20]
    // 0x83b6c0: add             x4, x3, #1
    // 0x83b6c4: lsl             x5, x4, #1
    // 0x83b6c8: StoreField: r2->field_b = r5
    //     0x83b6c8: stur            w5, [x2, #0xb]
    // 0x83b6cc: LoadField: r1 = r2->field_f
    //     0x83b6cc: ldur            w1, [x2, #0xf]
    // 0x83b6d0: DecompressPointer r1
    //     0x83b6d0: add             x1, x1, HEAP, lsl #32
    // 0x83b6d4: ldur            x0, [fp, #-0x10]
    // 0x83b6d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x83b6d8: add             x25, x1, x3, lsl #2
    //     0x83b6dc: add             x25, x25, #0xf
    //     0x83b6e0: str             w0, [x25]
    //     0x83b6e4: tbz             w0, #0, #0x83b700
    //     0x83b6e8: ldurb           w16, [x1, #-1]
    //     0x83b6ec: ldurb           w17, [x0, #-1]
    //     0x83b6f0: and             x16, x17, x16, lsr #2
    //     0x83b6f4: tst             x16, HEAP, lsr #32
    //     0x83b6f8: b.eq            #0x83b700
    //     0x83b6fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x83b700: r0 = Null
    //     0x83b700: mov             x0, NULL
    // 0x83b704: LeaveFrame
    //     0x83b704: mov             SP, fp
    //     0x83b708: ldp             fp, lr, [SP], #0x10
    // 0x83b70c: ret
    //     0x83b70c: ret             
    // 0x83b710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b714: b               #0x83b610
  }
  _ clear(/* No info */) {
    // ** addr: 0x9166a4, size: 0x74
    // 0x9166a4: EnterFrame
    //     0x9166a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9166a8: mov             fp, SP
    // 0x9166ac: AllocStack(0x8)
    //     0x9166ac: sub             SP, SP, #8
    // 0x9166b0: r0 = false
    //     0x9166b0: add             x0, NULL, #0x30  ; false
    // 0x9166b4: mov             x2, x1
    // 0x9166b8: stur            x1, [fp, #-8]
    // 0x9166bc: CheckStackOverflow
    //     0x9166bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9166c0: cmp             SP, x16
    //     0x9166c4: b.ls            #0x916710
    // 0x9166c8: StoreField: r2->field_f = r0
    //     0x9166c8: stur            w0, [x2, #0xf]
    // 0x9166cc: LoadField: r1 = r2->field_b
    //     0x9166cc: ldur            w1, [x2, #0xb]
    // 0x9166d0: DecompressPointer r1
    //     0x9166d0: add             x1, x1, HEAP, lsl #32
    // 0x9166d4: r0 = clear()
    //     0x9166d4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x9166d8: ldur            x1, [fp, #-8]
    // 0x9166dc: LoadField: r0 = r1->field_13
    //     0x9166dc: ldur            w0, [x1, #0x13]
    // 0x9166e0: DecompressPointer r0
    //     0x9166e0: add             x0, x0, HEAP, lsl #32
    // 0x9166e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9166e8: cmp             w0, w16
    // 0x9166ec: b.ne            #0x9166f8
    // 0x9166f0: r2 = _set
    //     0x9166f0: ldr             x2, [PP, #0x2fb8]  ; [pp+0x2fb8] Field <ObserverList._set@92023516>: late final (offset: 0x14)
    // 0x9166f4: r0 = InitLateFinalInstanceField()
    //     0x9166f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x9166f8: mov             x1, x0
    // 0x9166fc: r0 = clear()
    //     0x9166fc: bl              #0x831198  ; [dart:collection] _HashSet::clear
    // 0x916700: r0 = Null
    //     0x916700: mov             x0, NULL
    // 0x916704: LeaveFrame
    //     0x916704: mov             SP, fp
    //     0x916708: ldp             fp, lr, [SP], #0x10
    // 0x91670c: ret
    //     0x91670c: ret             
    // 0x916710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x916710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x916714: b               #0x9166c8
  }
  HashSet<X0> _set(ObserverList<X0>) {
    // ** addr: 0x916718, size: 0x3c
    // 0x916718: EnterFrame
    //     0x916718: stp             fp, lr, [SP, #-0x10]!
    //     0x91671c: mov             fp, SP
    // 0x916720: CheckStackOverflow
    //     0x916720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x916724: cmp             SP, x16
    //     0x916728: b.ls            #0x91674c
    // 0x91672c: ldr             x0, [fp, #0x10]
    // 0x916730: LoadField: r1 = r0->field_7
    //     0x916730: ldur            w1, [x0, #7]
    // 0x916734: DecompressPointer r1
    //     0x916734: add             x1, x1, HEAP, lsl #32
    // 0x916738: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x916738: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91673c: r0 = HashSet()
    //     0x91673c: bl              #0x89f690  ; [dart:collection] HashSet::HashSet
    // 0x916740: LeaveFrame
    //     0x916740: mov             SP, fp
    //     0x916744: ldp             fp, lr, [SP], #0x10
    // 0x916748: ret
    //     0x916748: ret             
    // 0x91674c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91674c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x916750: b               #0x91672c
  }
  bool contains(ObserverList<X0>, Object?) {
    // ** addr: 0xb03fac, size: 0xdc
    // 0xb03fac: EnterFrame
    //     0xb03fac: stp             fp, lr, [SP, #-0x10]!
    //     0xb03fb0: mov             fp, SP
    // 0xb03fb4: AllocStack(0x18)
    //     0xb03fb4: sub             SP, SP, #0x18
    // 0xb03fb8: SetupParameters(ObserverList<X0> this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb03fb8: mov             x0, x1
    //     0xb03fbc: stur            x1, [fp, #-0x10]
    //     0xb03fc0: stur            x2, [fp, #-0x18]
    // 0xb03fc4: CheckStackOverflow
    //     0xb03fc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb03fc8: cmp             SP, x16
    //     0xb03fcc: b.ls            #0xb04080
    // 0xb03fd0: LoadField: r3 = r0->field_b
    //     0xb03fd0: ldur            w3, [x0, #0xb]
    // 0xb03fd4: DecompressPointer r3
    //     0xb03fd4: add             x3, x3, HEAP, lsl #32
    // 0xb03fd8: stur            x3, [fp, #-8]
    // 0xb03fdc: LoadField: r1 = r3->field_b
    //     0xb03fdc: ldur            w1, [x3, #0xb]
    // 0xb03fe0: r4 = LoadInt32Instr(r1)
    //     0xb03fe0: sbfx            x4, x1, #1, #0x1f
    // 0xb03fe4: cmp             x4, #3
    // 0xb03fe8: b.ge            #0xb04000
    // 0xb03fec: mov             x1, x3
    // 0xb03ff0: r0 = contains()
    //     0xb03ff0: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0xb03ff4: LeaveFrame
    //     0xb03ff4: mov             SP, fp
    //     0xb03ff8: ldp             fp, lr, [SP], #0x10
    // 0xb03ffc: ret
    //     0xb03ffc: ret             
    // 0xb04000: LoadField: r1 = r0->field_f
    //     0xb04000: ldur            w1, [x0, #0xf]
    // 0xb04004: DecompressPointer r1
    //     0xb04004: add             x1, x1, HEAP, lsl #32
    // 0xb04008: tbnz            w1, #4, #0xb04048
    // 0xb0400c: mov             x1, x0
    // 0xb04010: LoadField: r0 = r1->field_13
    //     0xb04010: ldur            w0, [x1, #0x13]
    // 0xb04014: DecompressPointer r0
    //     0xb04014: add             x0, x0, HEAP, lsl #32
    // 0xb04018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb0401c: cmp             w0, w16
    // 0xb04020: b.ne            #0xb0402c
    // 0xb04024: r2 = _set
    //     0xb04024: ldr             x2, [PP, #0x2fb8]  ; [pp+0x2fb8] Field <ObserverList._set@92023516>: late final (offset: 0x14)
    // 0xb04028: r0 = InitLateFinalInstanceField()
    //     0xb04028: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xb0402c: mov             x1, x0
    // 0xb04030: ldur            x2, [fp, #-8]
    // 0xb04034: r0 = addAll()
    //     0xb04034: bl              #0x116d510  ; [dart:collection] _HashSet::addAll
    // 0xb04038: ldur            x1, [fp, #-0x10]
    // 0xb0403c: r0 = false
    //     0xb0403c: add             x0, NULL, #0x30  ; false
    // 0xb04040: StoreField: r1->field_f = r0
    //     0xb04040: stur            w0, [x1, #0xf]
    // 0xb04044: b               #0xb0404c
    // 0xb04048: mov             x1, x0
    // 0xb0404c: LoadField: r0 = r1->field_13
    //     0xb0404c: ldur            w0, [x1, #0x13]
    // 0xb04050: DecompressPointer r0
    //     0xb04050: add             x0, x0, HEAP, lsl #32
    // 0xb04054: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb04058: cmp             w0, w16
    // 0xb0405c: b.ne            #0xb04068
    // 0xb04060: r2 = _set
    //     0xb04060: ldr             x2, [PP, #0x2fb8]  ; [pp+0x2fb8] Field <ObserverList._set@92023516>: late final (offset: 0x14)
    // 0xb04064: r0 = InitLateFinalInstanceField()
    //     0xb04064: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xb04068: mov             x1, x0
    // 0xb0406c: ldur            x2, [fp, #-0x18]
    // 0xb04070: r0 = contains()
    //     0xb04070: bl              #0xb06504  ; [dart:collection] _HashSet::contains
    // 0xb04074: LeaveFrame
    //     0xb04074: mov             SP, fp
    //     0xb04078: ldp             fp, lr, [SP], #0x10
    // 0xb0407c: ret
    //     0xb0407c: ret             
    // 0xb04080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb04080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb04084: b               #0xb03fd0
  }
  List<X0> toList(ObserverList<X0>, {bool growable}) {
    // ** addr: 0xb088fc, size: 0x78
    // 0xb088fc: EnterFrame
    //     0xb088fc: stp             fp, lr, [SP, #-0x10]!
    //     0xb08900: mov             fp, SP
    // 0xb08904: AllocStack(0x8)
    //     0xb08904: sub             SP, SP, #8
    // 0xb08908: SetupParameters({dynamic growable = true /* r0 */})
    //     0xb08908: ldur            w0, [x4, #0x13]
    //     0xb0890c: ldur            w2, [x4, #0x1f]
    //     0xb08910: add             x2, x2, HEAP, lsl #32
    //     0xb08914: ldr             x16, [PP, #0x1d80]  ; [pp+0x1d80] "growable"
    //     0xb08918: cmp             w2, w16
    //     0xb0891c: b.ne            #0xb08938
    //     0xb08920: ldur            w2, [x4, #0x23]
    //     0xb08924: add             x2, x2, HEAP, lsl #32
    //     0xb08928: sub             w3, w0, w2
    //     0xb0892c: add             x0, fp, w3, sxtw #2
    //     0xb08930: ldr             x0, [x0, #8]
    //     0xb08934: b               #0xb0893c
    //     0xb08938: add             x0, NULL, #0x20  ; true
    // 0xb0893c: CheckStackOverflow
    //     0xb0893c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb08940: cmp             SP, x16
    //     0xb08944: b.ls            #0xb0896c
    // 0xb08948: LoadField: r2 = r1->field_b
    //     0xb08948: ldur            w2, [x1, #0xb]
    // 0xb0894c: DecompressPointer r2
    //     0xb0894c: add             x2, x2, HEAP, lsl #32
    // 0xb08950: str             x0, [SP]
    // 0xb08954: mov             x1, x2
    // 0xb08958: r4 = const [0, 0x2, 0x1, 0x1, growable, 0x1, null]
    //     0xb08958: ldr             x4, [PP, #0x1418]  ; [pp+0x1418] List(7) [0, 0x2, 0x1, 0x1, "growable", 0x1, Null]
    // 0xb0895c: r0 = toList()
    //     0xb0895c: bl              #0xbb6108  ; [dart:core] _GrowableList::toList
    // 0xb08960: LeaveFrame
    //     0xb08960: mov             SP, fp
    //     0xb08964: ldp             fp, lr, [SP], #0x10
    // 0xb08968: ret
    //     0xb08968: ret             
    // 0xb0896c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0896c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb08970: b               #0xb08948
  }
  _ remove(/* No info */) {
    // ** addr: 0xb57a2c, size: 0xc0
    // 0xb57a2c: EnterFrame
    //     0xb57a2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb57a30: mov             fp, SP
    // 0xb57a34: AllocStack(0x10)
    //     0xb57a34: sub             SP, SP, #0x10
    // 0xb57a38: SetupParameters(ObserverList<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb57a38: mov             x4, x1
    //     0xb57a3c: mov             x3, x2
    //     0xb57a40: stur            x1, [fp, #-8]
    //     0xb57a44: stur            x2, [fp, #-0x10]
    // 0xb57a48: CheckStackOverflow
    //     0xb57a48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb57a4c: cmp             SP, x16
    //     0xb57a50: b.ls            #0xb57ae4
    // 0xb57a54: LoadField: r2 = r4->field_7
    //     0xb57a54: ldur            w2, [x4, #7]
    // 0xb57a58: DecompressPointer r2
    //     0xb57a58: add             x2, x2, HEAP, lsl #32
    // 0xb57a5c: mov             x0, x3
    // 0xb57a60: r1 = Null
    //     0xb57a60: mov             x1, NULL
    // 0xb57a64: cmp             w2, NULL
    // 0xb57a68: b.eq            #0xb57a88
    // 0xb57a6c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb57a6c: ldur            w4, [x2, #0x17]
    // 0xb57a70: DecompressPointer r4
    //     0xb57a70: add             x4, x4, HEAP, lsl #32
    // 0xb57a74: r8 = X0
    //     0xb57a74: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb57a78: LoadField: r9 = r4->field_7
    //     0xb57a78: ldur            x9, [x4, #7]
    // 0xb57a7c: r3 = Null
    //     0xb57a7c: add             x3, PP, #0x85, lsl #12  ; [pp+0x85920] Null
    //     0xb57a80: ldr             x3, [x3, #0x920]
    // 0xb57a84: blr             x9
    // 0xb57a88: ldur            x0, [fp, #-8]
    // 0xb57a8c: LoadField: r1 = r0->field_b
    //     0xb57a8c: ldur            w1, [x0, #0xb]
    // 0xb57a90: DecompressPointer r1
    //     0xb57a90: add             x1, x1, HEAP, lsl #32
    // 0xb57a94: ldur            x2, [fp, #-0x10]
    // 0xb57a98: r0 = remove()
    //     0xb57a98: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xb57a9c: stur            x0, [fp, #-0x10]
    // 0xb57aa0: tbnz            w0, #4, #0xb57ad4
    // 0xb57aa4: ldur            x1, [fp, #-8]
    // 0xb57aa8: r2 = true
    //     0xb57aa8: add             x2, NULL, #0x20  ; true
    // 0xb57aac: StoreField: r1->field_f = r2
    //     0xb57aac: stur            w2, [x1, #0xf]
    // 0xb57ab0: LoadField: r0 = r1->field_13
    //     0xb57ab0: ldur            w0, [x1, #0x13]
    // 0xb57ab4: DecompressPointer r0
    //     0xb57ab4: add             x0, x0, HEAP, lsl #32
    // 0xb57ab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb57abc: cmp             w0, w16
    // 0xb57ac0: b.ne            #0xb57acc
    // 0xb57ac4: r2 = _set
    //     0xb57ac4: ldr             x2, [PP, #0x2fb8]  ; [pp+0x2fb8] Field <ObserverList._set@92023516>: late final (offset: 0x14)
    // 0xb57ac8: r0 = InitLateFinalInstanceField()
    //     0xb57ac8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xb57acc: mov             x1, x0
    // 0xb57ad0: r0 = clear()
    //     0xb57ad0: bl              #0x831198  ; [dart:collection] _HashSet::clear
    // 0xb57ad4: ldur            x0, [fp, #-0x10]
    // 0xb57ad8: LeaveFrame
    //     0xb57ad8: mov             SP, fp
    //     0xb57adc: ldp             fp, lr, [SP], #0x10
    // 0xb57ae0: ret
    //     0xb57ae0: ret             
    // 0xb57ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb57ae4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb57ae8: b               #0xb57a54
  }
}
