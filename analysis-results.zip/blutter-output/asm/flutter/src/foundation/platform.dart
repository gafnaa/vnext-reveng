// lib: , url: package:flutter/src/foundation/platform.dart

// class id: 1048809, size: 0x8
class :: {
}

// class id: 8314, size: 0x14, field offset: 0x14
enum TargetPlatform extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9860, size: 0x64
    // 0x11a9860: EnterFrame
    //     0x11a9860: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9864: mov             fp, SP
    // 0x11a9868: AllocStack(0x10)
    //     0x11a9868: sub             SP, SP, #0x10
    // 0x11a986c: SetupParameters(TargetPlatform this /* r1 => r0, fp-0x8 */)
    //     0x11a986c: mov             x0, x1
    //     0x11a9870: stur            x1, [fp, #-8]
    // 0x11a9874: CheckStackOverflow
    //     0x11a9874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9878: cmp             SP, x16
    //     0x11a987c: b.ls            #0x11a98bc
    // 0x11a9880: r1 = Null
    //     0x11a9880: mov             x1, NULL
    // 0x11a9884: r2 = 4
    //     0x11a9884: mov             x2, #4
    // 0x11a9888: r0 = AllocateArray()
    //     0x11a9888: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a988c: r16 = "TargetPlatform."
    //     0x11a988c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b68] "TargetPlatform."
    //     0x11a9890: ldr             x16, [x16, #0xb68]
    // 0x11a9894: StoreField: r0->field_f = r16
    //     0x11a9894: stur            w16, [x0, #0xf]
    // 0x11a9898: ldur            x1, [fp, #-8]
    // 0x11a989c: LoadField: r2 = r1->field_f
    //     0x11a989c: ldur            w2, [x1, #0xf]
    // 0x11a98a0: DecompressPointer r2
    //     0x11a98a0: add             x2, x2, HEAP, lsl #32
    // 0x11a98a4: StoreField: r0->field_13 = r2
    //     0x11a98a4: stur            w2, [x0, #0x13]
    // 0x11a98a8: str             x0, [SP]
    // 0x11a98ac: r0 = _interpolate()
    //     0x11a98ac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a98b0: LeaveFrame
    //     0x11a98b0: mov             SP, fp
    //     0x11a98b4: ldp             fp, lr, [SP], #0x10
    // 0x11a98b8: ret
    //     0x11a98b8: ret             
    // 0x11a98bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a98bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a98c0: b               #0x11a9880
  }
}
