// lib: , url: package:flutter/src/foundation/binding.dart

// class id: 1048798, size: 0x8
class :: {
}

// class id: 4601, size: 0x10, field offset: 0x8
abstract class BindingBase extends Object {

  _ lockEvents(/* No info */) {
    // ** addr: 0x831664, size: 0x94
    // 0x831664: EnterFrame
    //     0x831664: stp             fp, lr, [SP, #-0x10]!
    //     0x831668: mov             fp, SP
    // 0x83166c: AllocStack(0x20)
    //     0x83166c: sub             SP, SP, #0x20
    // 0x831670: SetupParameters(BindingBase this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x831670: mov             x0, x2
    //     0x831674: stur            x1, [fp, #-8]
    //     0x831678: stur            x2, [fp, #-0x10]
    // 0x83167c: CheckStackOverflow
    //     0x83167c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x831680: cmp             SP, x16
    //     0x831684: b.ls            #0x8316f0
    // 0x831688: r1 = 1
    //     0x831688: mov             x1, #1
    // 0x83168c: r0 = AllocateContext()
    //     0x83168c: bl              #0x13de838  ; AllocateContextStub
    // 0x831690: mov             x1, x0
    // 0x831694: ldur            x0, [fp, #-8]
    // 0x831698: stur            x1, [fp, #-0x18]
    // 0x83169c: StoreField: r1->field_f = r0
    //     0x83169c: stur            w0, [x1, #0xf]
    // 0x8316a0: LoadField: r2 = r0->field_7
    //     0x8316a0: ldur            x2, [x0, #7]
    // 0x8316a4: add             x3, x2, #1
    // 0x8316a8: StoreField: r0->field_7 = r3
    //     0x8316a8: stur            x3, [x0, #7]
    // 0x8316ac: ldur            x16, [fp, #-0x10]
    // 0x8316b0: str             x16, [SP]
    // 0x8316b4: ldur            x0, [fp, #-0x10]
    // 0x8316b8: ClosureCall
    //     0x8316b8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8316bc: ldur            x2, [x0, #0x1f]
    //     0x8316c0: blr             x2
    // 0x8316c4: ldur            x2, [fp, #-0x18]
    // 0x8316c8: r1 = Function '<anonymous closure>':.
    //     0x8316c8: ldr             x1, [PP, #0x7df0]  ; [pp+0x7df0] AnonymousClosure: (0x8316f8), in [package:flutter/src/foundation/binding.dart] BindingBase::lockEvents (0x831664)
    // 0x8316cc: stur            x0, [fp, #-8]
    // 0x8316d0: r0 = AllocateClosure()
    //     0x8316d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8316d4: ldur            x1, [fp, #-8]
    // 0x8316d8: mov             x2, x0
    // 0x8316dc: r0 = whenComplete()
    //     0x8316dc: bl              #0x1292f08  ; [dart:async] _Future::whenComplete
    // 0x8316e0: ldur            x0, [fp, #-8]
    // 0x8316e4: LeaveFrame
    //     0x8316e4: mov             SP, fp
    //     0x8316e8: ldp             fp, lr, [SP], #0x10
    // 0x8316ec: ret
    //     0x8316ec: ret             
    // 0x8316f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8316f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8316f4: b               #0x831688
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x8316f8, size: 0xc8
    // 0x8316f8: EnterFrame
    //     0x8316f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8316fc: mov             fp, SP
    // 0x831700: AllocStack(0x60)
    //     0x831700: sub             SP, SP, #0x60
    // 0x831704: SetupParameters([dynamic _ /* r0 */])
    //     0x831704: ldr             x0, [fp, #0x10]
    //     0x831708: ldur            w2, [x0, #0x17]
    //     0x83170c: add             x2, x2, HEAP, lsl #32
    //     0x831710: stur            x2, [fp, #-0x50]
    // 0x831714: CheckStackOverflow
    //     0x831714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x831718: cmp             SP, x16
    //     0x83171c: b.ls            #0x8317b8
    // 0x831720: LoadField: r1 = r2->field_f
    //     0x831720: ldur            w1, [x2, #0xf]
    // 0x831724: DecompressPointer r1
    //     0x831724: add             x1, x1, HEAP, lsl #32
    // 0x831728: LoadField: r0 = r1->field_7
    //     0x831728: ldur            x0, [x1, #7]
    // 0x83172c: sub             x3, x0, #1
    // 0x831730: StoreField: r1->field_7 = r3
    //     0x831730: stur            x3, [x1, #7]
    // 0x831734: cmp             x3, #0
    // 0x831738: b.gt            #0x8317a8
    // 0x83173c: r0 = unlocked()
    //     0x83173c: bl              #0x8317c0  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::unlocked
    // 0x831740: b               #0x8317a8
    // 0x831744: sub             SP, fp, #0x60
    // 0x831748: mov             x2, x0
    // 0x83174c: stur            x0, [fp, #-0x50]
    // 0x831750: mov             x0, x1
    // 0x831754: stur            x1, [fp, #-0x58]
    // 0x831758: r1 = <List<Object>>
    //     0x831758: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x83175c: r0 = ErrorDescription()
    //     0x83175c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x831760: mov             x1, x0
    // 0x831764: r2 = "while handling pending events"
    //     0x831764: ldr             x2, [PP, #0x7df8]  ; [pp+0x7df8] "while handling pending events"
    // 0x831768: r3 = Instance_DiagnosticLevel
    //     0x831768: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x83176c: stur            x0, [fp, #-0x60]
    // 0x831770: r0 = _ErrorDiagnostic()
    //     0x831770: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x831774: r0 = FlutterErrorDetails()
    //     0x831774: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x831778: mov             x1, x0
    // 0x83177c: ldur            x0, [fp, #-0x50]
    // 0x831780: StoreField: r1->field_7 = r0
    //     0x831780: stur            w0, [x1, #7]
    // 0x831784: ldur            x0, [fp, #-0x58]
    // 0x831788: StoreField: r1->field_b = r0
    //     0x831788: stur            w0, [x1, #0xb]
    // 0x83178c: r0 = "foundation"
    //     0x83178c: ldr             x0, [PP, #0x7e00]  ; [pp+0x7e00] "foundation"
    // 0x831790: StoreField: r1->field_f = r0
    //     0x831790: stur            w0, [x1, #0xf]
    // 0x831794: ldur            x0, [fp, #-0x60]
    // 0x831798: StoreField: r1->field_13 = r0
    //     0x831798: stur            w0, [x1, #0x13]
    // 0x83179c: r0 = false
    //     0x83179c: add             x0, NULL, #0x30  ; false
    // 0x8317a0: StoreField: r1->field_1b = r0
    //     0x8317a0: stur            w0, [x1, #0x1b]
    // 0x8317a4: r0 = reportError()
    //     0x8317a4: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x8317a8: r0 = Null
    //     0x8317a8: mov             x0, NULL
    // 0x8317ac: LeaveFrame
    //     0x8317ac: mov             SP, fp
    //     0x8317b0: ldp             fp, lr, [SP], #0x10
    // 0x8317b4: ret
    //     0x8317b4: ret             
    // 0x8317b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8317b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8317bc: b               #0x831720
  }
}
