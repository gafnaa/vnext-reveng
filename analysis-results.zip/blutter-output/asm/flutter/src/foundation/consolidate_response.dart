// lib: , url: package:flutter/src/foundation/consolidate_response.dart

// class id: 1048801, size: 0x8
class :: {

  static _ consolidateHttpClientResponseBytes(/* No info */) {
    // ** addr: 0x1004adc, size: 0x2c0
    // 0x1004adc: EnterFrame
    //     0x1004adc: stp             fp, lr, [SP, #-0x10]!
    //     0x1004ae0: mov             fp, SP
    // 0x1004ae4: AllocStack(0x40)
    //     0x1004ae4: sub             SP, SP, #0x40
    // 0x1004ae8: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, {dynamic onBytesReceived = Null /* r0, fp-0x8 */})
    //     0x1004ae8: stur            x1, [fp, #-0x10]
    //     0x1004aec: ldur            w0, [x4, #0x13]
    //     0x1004af0: ldur            w2, [x4, #0x1f]
    //     0x1004af4: add             x2, x2, HEAP, lsl #32
    //     0x1004af8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1faf0] "onBytesReceived"
    //     0x1004afc: ldr             x16, [x16, #0xaf0]
    //     0x1004b00: cmp             w2, w16
    //     0x1004b04: b.ne            #0x1004b20
    //     0x1004b08: ldur            w2, [x4, #0x23]
    //     0x1004b0c: add             x2, x2, HEAP, lsl #32
    //     0x1004b10: sub             w3, w0, w2
    //     0x1004b14: add             x0, fp, w3, sxtw #2
    //     0x1004b18: ldr             x0, [x0, #8]
    //     0x1004b1c: b               #0x1004b24
    //     0x1004b20: mov             x0, NULL
    //     0x1004b24: stur            x0, [fp, #-8]
    // 0x1004b28: CheckStackOverflow
    //     0x1004b28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1004b2c: cmp             SP, x16
    //     0x1004b30: b.ls            #0x1004d94
    // 0x1004b34: r1 = 7
    //     0x1004b34: mov             x1, #7
    // 0x1004b38: r0 = AllocateContext()
    //     0x1004b38: bl              #0x13de838  ; AllocateContextStub
    // 0x1004b3c: mov             x2, x0
    // 0x1004b40: ldur            x0, [fp, #-8]
    // 0x1004b44: stur            x2, [fp, #-0x18]
    // 0x1004b48: StoreField: r2->field_f = r0
    //     0x1004b48: stur            w0, [x2, #0xf]
    // 0x1004b4c: r1 = <Uint8List>
    //     0x1004b4c: add             x1, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0x1004b50: ldr             x1, [x1, #0x548]
    // 0x1004b54: r0 = Completer.sync()
    //     0x1004b54: bl              #0x847448  ; [dart:async] Completer::Completer.sync
    // 0x1004b58: mov             x1, x0
    // 0x1004b5c: ldur            x2, [fp, #-0x18]
    // 0x1004b60: stur            x1, [fp, #-8]
    // 0x1004b64: StoreField: r2->field_13 = r0
    //     0x1004b64: stur            w0, [x2, #0x13]
    //     0x1004b68: ldurb           w16, [x2, #-1]
    //     0x1004b6c: ldurb           w17, [x0, #-1]
    //     0x1004b70: and             x16, x17, x16, lsr #2
    //     0x1004b74: tst             x16, HEAP, lsr #32
    //     0x1004b78: b.eq            #0x1004b80
    //     0x1004b7c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1004b80: r0 = _OutputBuffer()
    //     0x1004b80: bl              #0x1004dc0  ; Allocate_OutputBufferStub -> _OutputBuffer (size=0x18)
    // 0x1004b84: stur            x0, [fp, #-0x20]
    // 0x1004b88: StoreField: r0->field_b = rZR
    //     0x1004b88: stur            xzr, [x0, #0xb]
    // 0x1004b8c: r1 = <List<int>>
    //     0x1004b8c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb958] TypeArguments: <List<int>>
    //     0x1004b90: ldr             x1, [x1, #0x958]
    // 0x1004b94: r2 = 0
    //     0x1004b94: mov             x2, #0
    // 0x1004b98: r0 = _GrowableList()
    //     0x1004b98: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x1004b9c: ldur            x2, [fp, #-0x20]
    // 0x1004ba0: StoreField: r2->field_7 = r0
    //     0x1004ba0: stur            w0, [x2, #7]
    //     0x1004ba4: ldurb           w16, [x2, #-1]
    //     0x1004ba8: ldurb           w17, [x0, #-1]
    //     0x1004bac: and             x16, x17, x16, lsr #2
    //     0x1004bb0: tst             x16, HEAP, lsr #32
    //     0x1004bb4: b.eq            #0x1004bbc
    //     0x1004bb8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1004bbc: mov             x0, x2
    // 0x1004bc0: ldur            x3, [fp, #-0x18]
    // 0x1004bc4: ArrayStore: r3[0] = r0  ; List_4
    //     0x1004bc4: stur            w0, [x3, #0x17]
    //     0x1004bc8: ldurb           w16, [x3, #-1]
    //     0x1004bcc: ldurb           w17, [x0, #-1]
    //     0x1004bd0: and             x16, x17, x16, lsr #2
    //     0x1004bd4: tst             x16, HEAP, lsr #32
    //     0x1004bd8: b.eq            #0x1004be0
    //     0x1004bdc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1004be0: mov             x0, x2
    // 0x1004be4: StoreField: r3->field_1b = r0
    //     0x1004be4: stur            w0, [x3, #0x1b]
    //     0x1004be8: ldurb           w16, [x3, #-1]
    //     0x1004bec: ldurb           w17, [x0, #-1]
    //     0x1004bf0: and             x16, x17, x16, lsr #2
    //     0x1004bf4: tst             x16, HEAP, lsr #32
    //     0x1004bf8: b.eq            #0x1004c00
    //     0x1004bfc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1004c00: ldur            x4, [fp, #-0x10]
    // 0x1004c04: LoadField: r0 = r4->field_b
    //     0x1004c04: ldur            w0, [x4, #0xb]
    // 0x1004c08: DecompressPointer r0
    //     0x1004c08: add             x0, x0, HEAP, lsl #32
    // 0x1004c0c: LoadField: r1 = r0->field_13
    //     0x1004c0c: ldur            w1, [x0, #0x13]
    // 0x1004c10: DecompressPointer r1
    //     0x1004c10: add             x1, x1, HEAP, lsl #32
    // 0x1004c14: LoadField: r5 = r1->field_1b
    //     0x1004c14: ldur            x5, [x1, #0x1b]
    // 0x1004c18: r0 = BoxInt64Instr(r5)
    //     0x1004c18: sbfiz           x0, x5, #1, #0x1f
    //     0x1004c1c: cmp             x5, x0, asr #1
    //     0x1004c20: b.eq            #0x1004c2c
    //     0x1004c24: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1004c28: stur            x5, [x0, #7]
    // 0x1004c2c: mov             x1, x0
    // 0x1004c30: StoreField: r3->field_1f = r0
    //     0x1004c30: stur            w0, [x3, #0x1f]
    //     0x1004c34: tbz             w0, #0, #0x1004c50
    //     0x1004c38: ldurb           w16, [x3, #-1]
    //     0x1004c3c: ldurb           w17, [x0, #-1]
    //     0x1004c40: and             x16, x17, x16, lsr #2
    //     0x1004c44: tst             x16, HEAP, lsr #32
    //     0x1004c48: b.eq            #0x1004c50
    //     0x1004c4c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1004c50: cmn             w1, #2
    // 0x1004c54: b.ne            #0x1004c5c
    // 0x1004c58: StoreField: r3->field_1f = rNULL
    //     0x1004c58: stur            NULL, [x3, #0x1f]
    // 0x1004c5c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x1004c5c: ldur            w0, [x4, #0x17]
    // 0x1004c60: DecompressPointer r0
    //     0x1004c60: add             x0, x0, HEAP, lsl #32
    // 0x1004c64: LoadField: r1 = r0->field_7
    //     0x1004c64: ldur            x1, [x0, #7]
    // 0x1004c68: cmp             x1, #1
    // 0x1004c6c: b.gt            #0x1004c80
    // 0x1004c70: cmp             x1, #0
    // 0x1004c74: b.le            #0x1004ccc
    // 0x1004c78: StoreField: r3->field_1f = rNULL
    //     0x1004c78: stur            NULL, [x3, #0x1f]
    // 0x1004c7c: b               #0x1004ccc
    // 0x1004c80: r1 = <List<int>, List<int>>
    //     0x1004c80: ldr             x1, [PP, #0x35a0]  ; [pp+0x35a0] TypeArguments: <List<int>, List<int>>
    // 0x1004c84: r0 = ZLibDecoder()
    //     0x1004c84: bl              #0x1004db4  ; AllocateZLibDecoderStub -> ZLibDecoder (size=0x20)
    // 0x1004c88: mov             x1, x0
    // 0x1004c8c: r0 = true
    //     0x1004c8c: add             x0, NULL, #0x20  ; true
    // 0x1004c90: StoreField: r1->field_b = r0
    //     0x1004c90: stur            w0, [x1, #0xb]
    // 0x1004c94: r0 = 15
    //     0x1004c94: mov             x0, #0xf
    // 0x1004c98: StoreField: r1->field_f = r0
    //     0x1004c98: stur            x0, [x1, #0xf]
    // 0x1004c9c: r0 = false
    //     0x1004c9c: add             x0, NULL, #0x30  ; false
    // 0x1004ca0: StoreField: r1->field_1b = r0
    //     0x1004ca0: stur            w0, [x1, #0x1b]
    // 0x1004ca4: ldur            x2, [fp, #-0x20]
    // 0x1004ca8: r0 = startChunkedConversion()
    //     0x1004ca8: bl              #0x121d498  ; [dart:io] ZLibDecoder::startChunkedConversion
    // 0x1004cac: ldur            x3, [fp, #-0x18]
    // 0x1004cb0: StoreField: r3->field_1b = r0
    //     0x1004cb0: stur            w0, [x3, #0x1b]
    //     0x1004cb4: ldurb           w16, [x3, #-1]
    //     0x1004cb8: ldurb           w17, [x0, #-1]
    //     0x1004cbc: and             x16, x17, x16, lsr #2
    //     0x1004cc0: tst             x16, HEAP, lsr #32
    //     0x1004cc4: b.eq            #0x1004ccc
    //     0x1004cc8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1004ccc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x1004cd0: StoreField: r3->field_23 = rZR
    //     0x1004cd0: stur            wzr, [x3, #0x23]
    // 0x1004cd4: StoreField: r3->field_27 = r0
    //     0x1004cd4: stur            w0, [x3, #0x27]
    // 0x1004cd8: mov             x2, x3
    // 0x1004cdc: r1 = Function '<anonymous closure>': static.
    //     0x1004cdc: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1faf8] AnonymousClosure: static (0x1004e68), in [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes (0x1004adc)
    //     0x1004ce0: ldr             x1, [x1, #0xaf8]
    // 0x1004ce4: r0 = AllocateClosure()
    //     0x1004ce4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1004ce8: ldur            x2, [fp, #-0x18]
    // 0x1004cec: r1 = Function '<anonymous closure>': static.
    //     0x1004cec: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fb00] AnonymousClosure: static (0x1004dcc), in [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes (0x1004adc)
    //     0x1004cf0: ldr             x1, [x1, #0xb00]
    // 0x1004cf4: stur            x0, [fp, #-0x20]
    // 0x1004cf8: r0 = AllocateClosure()
    //     0x1004cf8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1004cfc: ldur            x2, [fp, #-8]
    // 0x1004d00: r1 = Function 'completeError':.
    //     0x1004d00: add             x1, PP, #8, lsl #12  ; [pp+0x8560] AnonymousClosure: (0x7f6c60), in [dart:async] _Completer::completeError (0x7f6b94)
    //     0x1004d04: ldr             x1, [x1, #0x560]
    // 0x1004d08: stur            x0, [fp, #-0x28]
    // 0x1004d0c: r0 = AllocateClosure()
    //     0x1004d0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1004d10: ldur            x16, [fp, #-0x28]
    // 0x1004d14: stp             x0, x16, [SP, #8]
    // 0x1004d18: r16 = true
    //     0x1004d18: add             x16, NULL, #0x20  ; true
    // 0x1004d1c: str             x16, [SP]
    // 0x1004d20: ldur            x1, [fp, #-0x10]
    // 0x1004d24: ldur            x2, [fp, #-0x20]
    // 0x1004d28: r4 = const [0, 0x5, 0x3, 0x2, cancelOnError, 0x4, onDone, 0x2, onError, 0x3, null]
    //     0x1004d28: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fb08] List(11) [0, 0x5, 0x3, 0x2, "cancelOnError", 0x4, "onDone", 0x2, "onError", 0x3, Null]
    //     0x1004d2c: ldr             x4, [x4, #0xb08]
    // 0x1004d30: r0 = listen()
    //     0x1004d30: bl              #0x123bf50  ; [dart:_http] _HttpClientResponse::listen
    // 0x1004d34: ldur            x1, [fp, #-0x18]
    // 0x1004d38: LoadField: r2 = r1->field_27
    //     0x1004d38: ldur            w2, [x1, #0x27]
    // 0x1004d3c: DecompressPointer r2
    //     0x1004d3c: add             x2, x2, HEAP, lsl #32
    // 0x1004d40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1004d44: cmp             w2, w16
    // 0x1004d48: b.ne            #0x1004d80
    // 0x1004d4c: ldur            x2, [fp, #-8]
    // 0x1004d50: StoreField: r1->field_27 = r0
    //     0x1004d50: stur            w0, [x1, #0x27]
    //     0x1004d54: ldurb           w16, [x1, #-1]
    //     0x1004d58: ldurb           w17, [x0, #-1]
    //     0x1004d5c: and             x16, x17, x16, lsr #2
    //     0x1004d60: tst             x16, HEAP, lsr #32
    //     0x1004d64: b.eq            #0x1004d6c
    //     0x1004d68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1004d6c: LoadField: r0 = r2->field_b
    //     0x1004d6c: ldur            w0, [x2, #0xb]
    // 0x1004d70: DecompressPointer r0
    //     0x1004d70: add             x0, x0, HEAP, lsl #32
    // 0x1004d74: LeaveFrame
    //     0x1004d74: mov             SP, fp
    //     0x1004d78: ldp             fp, lr, [SP], #0x10
    // 0x1004d7c: ret
    //     0x1004d7c: ret             
    // 0x1004d80: r16 = "subscription"
    //     0x1004d80: add             x16, PP, #0xc, lsl #12  ; [pp+0xc118] "subscription"
    //     0x1004d84: ldr             x16, [x16, #0x118]
    // 0x1004d88: str             x16, [SP]
    // 0x1004d8c: r0 = _throwLocalAlreadyInitialized()
    //     0x1004d8c: bl              #0x82b684  ; [dart:_internal] LateError::_throwLocalAlreadyInitialized
    // 0x1004d90: brk             #0
    // 0x1004d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1004d94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1004d98: b               #0x1004b34
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x1004dcc, size: 0x9c
    // 0x1004dcc: EnterFrame
    //     0x1004dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x1004dd0: mov             fp, SP
    // 0x1004dd4: AllocStack(0x10)
    //     0x1004dd4: sub             SP, SP, #0x10
    // 0x1004dd8: SetupParameters([dynamic _ /* r0 */])
    //     0x1004dd8: ldr             x0, [fp, #0x10]
    //     0x1004ddc: ldur            w2, [x0, #0x17]
    //     0x1004de0: add             x2, x2, HEAP, lsl #32
    //     0x1004de4: stur            x2, [fp, #-8]
    // 0x1004de8: CheckStackOverflow
    //     0x1004de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1004dec: cmp             SP, x16
    //     0x1004df0: b.ls            #0x1004e5c
    // 0x1004df4: LoadField: r1 = r2->field_1b
    //     0x1004df4: ldur            w1, [x2, #0x1b]
    // 0x1004df8: DecompressPointer r1
    //     0x1004df8: add             x1, x1, HEAP, lsl #32
    // 0x1004dfc: r0 = LoadClassIdInstr(r1)
    //     0x1004dfc: ldur            x0, [x1, #-1]
    //     0x1004e00: ubfx            x0, x0, #0xc, #0x14
    // 0x1004e04: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1004e04: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1004e08: r0 = GDT[cid_x0 + 0x182be]()
    //     0x1004e08: mov             x17, #0x82be
    //     0x1004e0c: movk            x17, #1, lsl #16
    //     0x1004e10: add             lr, x0, x17
    //     0x1004e14: ldr             lr, [x21, lr, lsl #3]
    //     0x1004e18: blr             lr
    // 0x1004e1c: ldur            x0, [fp, #-8]
    // 0x1004e20: LoadField: r1 = r0->field_13
    //     0x1004e20: ldur            w1, [x0, #0x13]
    // 0x1004e24: DecompressPointer r1
    //     0x1004e24: add             x1, x1, HEAP, lsl #32
    // 0x1004e28: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1004e28: ldur            w2, [x0, #0x17]
    // 0x1004e2c: DecompressPointer r2
    //     0x1004e2c: add             x2, x2, HEAP, lsl #32
    // 0x1004e30: LoadField: r0 = r2->field_13
    //     0x1004e30: ldur            w0, [x2, #0x13]
    // 0x1004e34: DecompressPointer r0
    //     0x1004e34: add             x0, x0, HEAP, lsl #32
    // 0x1004e38: cmp             w0, NULL
    // 0x1004e3c: b.eq            #0x1004e64
    // 0x1004e40: str             x0, [SP]
    // 0x1004e44: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x1004e44: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x1004e48: r0 = complete()
    //     0x1004e48: bl              #0x128a6d4  ; [dart:async] _SyncCompleter::complete
    // 0x1004e4c: r0 = Null
    //     0x1004e4c: mov             x0, NULL
    // 0x1004e50: LeaveFrame
    //     0x1004e50: mov             SP, fp
    //     0x1004e54: ldp             fp, lr, [SP], #0x10
    // 0x1004e58: ret
    //     0x1004e58: ret             
    // 0x1004e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1004e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1004e60: b               #0x1004df4
    // 0x1004e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1004e64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static void <anonymous closure>(dynamic, List<int>) {
    // ** addr: 0x1004e68, size: 0x1bc
    // 0x1004e68: EnterFrame
    //     0x1004e68: stp             fp, lr, [SP, #-0x10]!
    //     0x1004e6c: mov             fp, SP
    // 0x1004e70: AllocStack(0x68)
    //     0x1004e70: sub             SP, SP, #0x68
    // 0x1004e74: SetupParameters([dynamic _ /* r0 */])
    //     0x1004e74: ldr             x0, [fp, #0x18]
    //     0x1004e78: ldur            w3, [x0, #0x17]
    //     0x1004e7c: add             x3, x3, HEAP, lsl #32
    //     0x1004e80: stur            x3, [fp, #-0x48]
    // 0x1004e84: CheckStackOverflow
    //     0x1004e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1004e88: cmp             SP, x16
    //     0x1004e8c: b.ls            #0x1005018
    // 0x1004e90: LoadField: r1 = r3->field_1b
    //     0x1004e90: ldur            w1, [x3, #0x1b]
    // 0x1004e94: DecompressPointer r1
    //     0x1004e94: add             x1, x1, HEAP, lsl #32
    // 0x1004e98: r0 = LoadClassIdInstr(r1)
    //     0x1004e98: ldur            x0, [x1, #-1]
    //     0x1004e9c: ubfx            x0, x0, #0xc, #0x14
    // 0x1004ea0: ldr             x2, [fp, #0x10]
    // 0x1004ea4: r0 = GDT[cid_x0 + 0x1847a]()
    //     0x1004ea4: mov             x17, #0x847a
    //     0x1004ea8: movk            x17, #1, lsl #16
    //     0x1004eac: add             lr, x0, x17
    //     0x1004eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x1004eb4: blr             lr
    // 0x1004eb8: ldur            x1, [fp, #-0x48]
    // 0x1004ebc: LoadField: r0 = r1->field_f
    //     0x1004ebc: ldur            w0, [x1, #0xf]
    // 0x1004ec0: DecompressPointer r0
    //     0x1004ec0: add             x0, x0, HEAP, lsl #32
    // 0x1004ec4: cmp             w0, NULL
    // 0x1004ec8: b.eq            #0x1004ff4
    // 0x1004ecc: ldr             x0, [fp, #0x10]
    // 0x1004ed0: LoadField: r2 = r1->field_23
    //     0x1004ed0: ldur            w2, [x1, #0x23]
    // 0x1004ed4: DecompressPointer r2
    //     0x1004ed4: add             x2, x2, HEAP, lsl #32
    // 0x1004ed8: stur            x2, [fp, #-0x50]
    // 0x1004edc: r3 = LoadClassIdInstr(r0)
    //     0x1004edc: ldur            x3, [x0, #-1]
    //     0x1004ee0: ubfx            x3, x3, #0xc, #0x14
    // 0x1004ee4: str             x0, [SP]
    // 0x1004ee8: mov             x0, x3
    // 0x1004eec: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1004eec: mov             x17, #0xf078
    //     0x1004ef0: add             lr, x0, x17
    //     0x1004ef4: ldr             lr, [x21, lr, lsl #3]
    //     0x1004ef8: blr             lr
    // 0x1004efc: mov             x1, x0
    // 0x1004f00: ldur            x0, [fp, #-0x50]
    // 0x1004f04: r2 = LoadInt32Instr(r0)
    //     0x1004f04: sbfx            x2, x0, #1, #0x1f
    //     0x1004f08: tbz             w0, #0, #0x1004f10
    //     0x1004f0c: ldur            x2, [x0, #7]
    // 0x1004f10: r0 = LoadInt32Instr(r1)
    //     0x1004f10: sbfx            x0, x1, #1, #0x1f
    //     0x1004f14: tbz             w1, #0, #0x1004f1c
    //     0x1004f18: ldur            x0, [x1, #7]
    // 0x1004f1c: add             x3, x2, x0
    // 0x1004f20: r0 = BoxInt64Instr(r3)
    //     0x1004f20: sbfiz           x0, x3, #1, #0x1f
    //     0x1004f24: cmp             x3, x0, asr #1
    //     0x1004f28: b.eq            #0x1004f34
    //     0x1004f2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1004f30: stur            x3, [x0, #7]
    // 0x1004f34: mov             x2, x0
    // 0x1004f38: ldur            x1, [fp, #-0x48]
    // 0x1004f3c: StoreField: r1->field_23 = r0
    //     0x1004f3c: stur            w0, [x1, #0x23]
    //     0x1004f40: tbz             w0, #0, #0x1004f5c
    //     0x1004f44: ldurb           w16, [x1, #-1]
    //     0x1004f48: ldurb           w17, [x0, #-1]
    //     0x1004f4c: and             x16, x17, x16, lsr #2
    //     0x1004f50: tst             x16, HEAP, lsr #32
    //     0x1004f54: b.eq            #0x1004f5c
    //     0x1004f58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1004f5c: LoadField: r3 = r1->field_f
    //     0x1004f5c: ldur            w3, [x1, #0xf]
    // 0x1004f60: DecompressPointer r3
    //     0x1004f60: add             x3, x3, HEAP, lsl #32
    // 0x1004f64: stur            x3, [fp, #-0x50]
    // 0x1004f68: LoadField: r0 = r1->field_1f
    //     0x1004f68: ldur            w0, [x1, #0x1f]
    // 0x1004f6c: DecompressPointer r0
    //     0x1004f6c: add             x0, x0, HEAP, lsl #32
    // 0x1004f70: cmp             w3, NULL
    // 0x1004f74: b.eq            #0x1005020
    // 0x1004f78: stp             x2, x3, [SP, #8]
    // 0x1004f7c: str             x0, [SP]
    // 0x1004f80: mov             x0, x3
    // 0x1004f84: ClosureCall
    //     0x1004f84: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x1004f88: ldur            x2, [x0, #0x1f]
    //     0x1004f8c: blr             x2
    // 0x1004f90: b               #0x1004ff4
    // 0x1004f94: sub             SP, fp, #0x68
    // 0x1004f98: ldur            x3, [fp, #-0x48]
    // 0x1004f9c: mov             x2, x0
    // 0x1004fa0: LoadField: r0 = r3->field_13
    //     0x1004fa0: ldur            w0, [x3, #0x13]
    // 0x1004fa4: DecompressPointer r0
    //     0x1004fa4: add             x0, x0, HEAP, lsl #32
    // 0x1004fa8: str             x1, [SP]
    // 0x1004fac: mov             x1, x0
    // 0x1004fb0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1004fb0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x1004fb4: r0 = completeError()
    //     0x1004fb4: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x1004fb8: ldur            x0, [fp, #-0x48]
    // 0x1004fbc: LoadField: r1 = r0->field_27
    //     0x1004fbc: ldur            w1, [x0, #0x27]
    // 0x1004fc0: DecompressPointer r1
    //     0x1004fc0: add             x1, x1, HEAP, lsl #32
    // 0x1004fc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1004fc8: cmp             w1, w16
    // 0x1004fcc: b.eq            #0x1005004
    // 0x1004fd0: r0 = LoadClassIdInstr(r1)
    //     0x1004fd0: ldur            x0, [x1, #-1]
    //     0x1004fd4: ubfx            x0, x0, #0xc, #0x14
    // 0x1004fd8: r0 = GDT[cid_x0 + 0x549]()
    //     0x1004fd8: add             lr, x0, #0x549
    //     0x1004fdc: ldr             lr, [x21, lr, lsl #3]
    //     0x1004fe0: blr             lr
    // 0x1004fe4: r0 = Null
    //     0x1004fe4: mov             x0, NULL
    // 0x1004fe8: LeaveFrame
    //     0x1004fe8: mov             SP, fp
    //     0x1004fec: ldp             fp, lr, [SP], #0x10
    // 0x1004ff0: ret
    //     0x1004ff0: ret             
    // 0x1004ff4: r0 = Null
    //     0x1004ff4: mov             x0, NULL
    // 0x1004ff8: LeaveFrame
    //     0x1004ff8: mov             SP, fp
    //     0x1004ffc: ldp             fp, lr, [SP], #0x10
    // 0x1005000: ret
    //     0x1005000: ret             
    // 0x1005004: r16 = "subscription"
    //     0x1005004: add             x16, PP, #0xc, lsl #12  ; [pp+0xc118] "subscription"
    //     0x1005008: ldr             x16, [x16, #0x118]
    // 0x100500c: str             x16, [SP]
    // 0x1005010: r0 = _throwLocalNotInitialized()
    //     0x1005010: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x1005014: brk             #0
    // 0x1005018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1005018: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x100501c: b               #0x1004e90
    // 0x1005020: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1005020: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 7296, size: 0x18, field offset: 0x8
class _OutputBuffer extends ByteConversionSink {

  _ add(/* No info */) {
    // ** addr: 0x80ea7c, size: 0x134
    // 0x80ea7c: EnterFrame
    //     0x80ea7c: stp             fp, lr, [SP, #-0x10]!
    //     0x80ea80: mov             fp, SP
    // 0x80ea84: AllocStack(0x28)
    //     0x80ea84: sub             SP, SP, #0x28
    // 0x80ea88: SetupParameters(_OutputBuffer this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x80ea88: mov             x4, x1
    //     0x80ea8c: mov             x3, x2
    //     0x80ea90: stur            x1, [fp, #-8]
    //     0x80ea94: stur            x2, [fp, #-0x10]
    // 0x80ea98: CheckStackOverflow
    //     0x80ea98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80ea9c: cmp             SP, x16
    //     0x80eaa0: b.ls            #0x80eba4
    // 0x80eaa4: mov             x0, x3
    // 0x80eaa8: r2 = Null
    //     0x80eaa8: mov             x2, NULL
    // 0x80eaac: r1 = Null
    //     0x80eaac: mov             x1, NULL
    // 0x80eab0: r8 = List<int>
    //     0x80eab0: ldr             x8, [PP, #0x13e8]  ; [pp+0x13e8] Type: List<int>
    // 0x80eab4: r3 = Null
    //     0x80eab4: add             x3, PP, #0x80, lsl #12  ; [pp+0x80cb0] Null
    //     0x80eab8: ldr             x3, [x3, #0xcb0]
    // 0x80eabc: r0 = List<int>()
    //     0x80eabc: bl              #0x7fd2a4  ; IsType_List<int>_Stub
    // 0x80eac0: ldur            x0, [fp, #-8]
    // 0x80eac4: LoadField: r2 = r0->field_7
    //     0x80eac4: ldur            w2, [x0, #7]
    // 0x80eac8: DecompressPointer r2
    //     0x80eac8: add             x2, x2, HEAP, lsl #32
    // 0x80eacc: stur            x2, [fp, #-0x20]
    // 0x80ead0: cmp             w2, NULL
    // 0x80ead4: b.eq            #0x80ebac
    // 0x80ead8: LoadField: r1 = r2->field_b
    //     0x80ead8: ldur            w1, [x2, #0xb]
    // 0x80eadc: LoadField: r3 = r2->field_f
    //     0x80eadc: ldur            w3, [x2, #0xf]
    // 0x80eae0: DecompressPointer r3
    //     0x80eae0: add             x3, x3, HEAP, lsl #32
    // 0x80eae4: LoadField: r4 = r3->field_b
    //     0x80eae4: ldur            w4, [x3, #0xb]
    // 0x80eae8: r3 = LoadInt32Instr(r1)
    //     0x80eae8: sbfx            x3, x1, #1, #0x1f
    // 0x80eaec: stur            x3, [fp, #-0x18]
    // 0x80eaf0: r1 = LoadInt32Instr(r4)
    //     0x80eaf0: sbfx            x1, x4, #1, #0x1f
    // 0x80eaf4: cmp             x3, x1
    // 0x80eaf8: b.ne            #0x80eb04
    // 0x80eafc: mov             x1, x2
    // 0x80eb00: r0 = _growToNextCapacity()
    //     0x80eb00: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x80eb04: ldur            x2, [fp, #-8]
    // 0x80eb08: ldur            x4, [fp, #-0x10]
    // 0x80eb0c: ldur            x0, [fp, #-0x20]
    // 0x80eb10: ldur            x3, [fp, #-0x18]
    // 0x80eb14: add             x1, x3, #1
    // 0x80eb18: lsl             x5, x1, #1
    // 0x80eb1c: StoreField: r0->field_b = r5
    //     0x80eb1c: stur            w5, [x0, #0xb]
    // 0x80eb20: LoadField: r1 = r0->field_f
    //     0x80eb20: ldur            w1, [x0, #0xf]
    // 0x80eb24: DecompressPointer r1
    //     0x80eb24: add             x1, x1, HEAP, lsl #32
    // 0x80eb28: mov             x0, x4
    // 0x80eb2c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x80eb2c: add             x25, x1, x3, lsl #2
    //     0x80eb30: add             x25, x25, #0xf
    //     0x80eb34: str             w0, [x25]
    //     0x80eb38: tbz             w0, #0, #0x80eb54
    //     0x80eb3c: ldurb           w16, [x1, #-1]
    //     0x80eb40: ldurb           w17, [x0, #-1]
    //     0x80eb44: and             x16, x17, x16, lsr #2
    //     0x80eb48: tst             x16, HEAP, lsr #32
    //     0x80eb4c: b.eq            #0x80eb54
    //     0x80eb50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x80eb54: LoadField: r1 = r2->field_b
    //     0x80eb54: ldur            x1, [x2, #0xb]
    // 0x80eb58: stur            x1, [fp, #-0x18]
    // 0x80eb5c: r0 = LoadClassIdInstr(r4)
    //     0x80eb5c: ldur            x0, [x4, #-1]
    //     0x80eb60: ubfx            x0, x0, #0xc, #0x14
    // 0x80eb64: str             x4, [SP]
    // 0x80eb68: r0 = GDT[cid_x0 + 0xf078]()
    //     0x80eb68: mov             x17, #0xf078
    //     0x80eb6c: add             lr, x0, x17
    //     0x80eb70: ldr             lr, [x21, lr, lsl #3]
    //     0x80eb74: blr             lr
    // 0x80eb78: r1 = LoadInt32Instr(r0)
    //     0x80eb78: sbfx            x1, x0, #1, #0x1f
    //     0x80eb7c: tbz             w0, #0, #0x80eb84
    //     0x80eb80: ldur            x1, [x0, #7]
    // 0x80eb84: ldur            x2, [fp, #-0x18]
    // 0x80eb88: add             x3, x2, x1
    // 0x80eb8c: ldur            x1, [fp, #-8]
    // 0x80eb90: StoreField: r1->field_b = r3
    //     0x80eb90: stur            x3, [x1, #0xb]
    // 0x80eb94: r0 = Null
    //     0x80eb94: mov             x0, NULL
    // 0x80eb98: LeaveFrame
    //     0x80eb98: mov             SP, fp
    //     0x80eb9c: ldp             fp, lr, [SP], #0x10
    // 0x80eba0: ret
    //     0x80eba0: ret             
    // 0x80eba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80eba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80eba8: b               #0x80eaa4
    // 0x80ebac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80ebac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x80ebb0, size: 0x3c
    // 0x80ebb0: EnterFrame
    //     0x80ebb0: stp             fp, lr, [SP, #-0x10]!
    //     0x80ebb4: mov             fp, SP
    // 0x80ebb8: ldr             x0, [fp, #0x18]
    // 0x80ebbc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x80ebbc: ldur            w1, [x0, #0x17]
    // 0x80ebc0: DecompressPointer r1
    //     0x80ebc0: add             x1, x1, HEAP, lsl #32
    // 0x80ebc4: CheckStackOverflow
    //     0x80ebc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80ebc8: cmp             SP, x16
    //     0x80ebcc: b.ls            #0x80ebe4
    // 0x80ebd0: ldr             x2, [fp, #0x10]
    // 0x80ebd4: r0 = add()
    //     0x80ebd4: bl              #0x80ea7c  ; [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::add
    // 0x80ebd8: LeaveFrame
    //     0x80ebd8: mov             SP, fp
    //     0x80ebdc: ldp             fp, lr, [SP], #0x10
    // 0x80ebe0: ret
    //     0x80ebe0: ret             
    // 0x80ebe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80ebe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80ebe8: b               #0x80ebd0
  }
  dynamic add(dynamic) {
    // ** addr: 0x80eda0, size: 0x24
    // 0x80eda0: EnterFrame
    //     0x80eda0: stp             fp, lr, [SP, #-0x10]!
    //     0x80eda4: mov             fp, SP
    // 0x80eda8: ldr             x2, [fp, #0x10]
    // 0x80edac: r1 = Function 'add':.
    //     0x80edac: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ca8] AnonymousClosure: (0x80ebb0), in [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::add (0x80ea7c)
    //     0x80edb0: ldr             x1, [x1, #0xca8]
    // 0x80edb4: r0 = AllocateClosure()
    //     0x80edb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x80edb8: LeaveFrame
    //     0x80edb8: mov             SP, fp
    //     0x80edbc: ldp             fp, lr, [SP], #0x10
    // 0x80edc0: ret
    //     0x80edc0: ret             
  }
  _ close(/* No info */) {
    // ** addr: 0x8141f4, size: 0x4a0
    // 0x8141f4: EnterFrame
    //     0x8141f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8141f8: mov             fp, SP
    // 0x8141fc: AllocStack(0x58)
    //     0x8141fc: sub             SP, SP, #0x58
    // 0x814200: SetupParameters(_OutputBuffer this /* r1 => r2, fp-0x8 */)
    //     0x814200: mov             x2, x1
    //     0x814204: stur            x1, [fp, #-8]
    // 0x814208: CheckStackOverflow
    //     0x814208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x81420c: cmp             SP, x16
    //     0x814210: b.ls            #0x81467c
    // 0x814214: LoadField: r0 = r2->field_13
    //     0x814214: ldur            w0, [x2, #0x13]
    // 0x814218: DecompressPointer r0
    //     0x814218: add             x0, x0, HEAP, lsl #32
    // 0x81421c: cmp             w0, NULL
    // 0x814220: b.eq            #0x814234
    // 0x814224: r0 = Null
    //     0x814224: mov             x0, NULL
    // 0x814228: LeaveFrame
    //     0x814228: mov             SP, fp
    //     0x81422c: ldp             fp, lr, [SP], #0x10
    // 0x814230: ret
    //     0x814230: ret             
    // 0x814234: LoadField: r3 = r2->field_b
    //     0x814234: ldur            x3, [x2, #0xb]
    // 0x814238: r0 = BoxInt64Instr(r3)
    //     0x814238: sbfiz           x0, x3, #1, #0x1f
    //     0x81423c: cmp             x3, x0, asr #1
    //     0x814240: b.eq            #0x81424c
    //     0x814244: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x814248: stur            x3, [x0, #7]
    // 0x81424c: mov             x4, x0
    // 0x814250: r0 = AllocateUint8Array()
    //     0x814250: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x814254: ldur            x1, [fp, #-8]
    // 0x814258: StoreField: r1->field_13 = r0
    //     0x814258: stur            w0, [x1, #0x13]
    //     0x81425c: ldurb           w16, [x1, #-1]
    //     0x814260: ldurb           w17, [x0, #-1]
    //     0x814264: and             x16, x17, x16, lsr #2
    //     0x814268: tst             x16, HEAP, lsr #32
    //     0x81426c: b.eq            #0x814274
    //     0x814270: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x814274: LoadField: r2 = r1->field_7
    //     0x814274: ldur            w2, [x1, #7]
    // 0x814278: DecompressPointer r2
    //     0x814278: add             x2, x2, HEAP, lsl #32
    // 0x81427c: stur            x2, [fp, #-0x40]
    // 0x814280: cmp             w2, NULL
    // 0x814284: b.eq            #0x814684
    // 0x814288: LoadField: r0 = r2->field_b
    //     0x814288: ldur            w0, [x2, #0xb]
    // 0x81428c: r3 = LoadInt32Instr(r0)
    //     0x81428c: sbfx            x3, x0, #1, #0x1f
    // 0x814290: stur            x3, [fp, #-0x38]
    // 0x814294: mov             x4, THR
    // 0x814298: stur            x4, [fp, #-0x30]
    // 0x81429c: r5 = 0
    //     0x81429c: mov             x5, #0
    // 0x8142a0: r0 = 0
    //     0x8142a0: mov             x0, #0
    // 0x8142a4: stur            x5, [fp, #-0x28]
    // 0x8142a8: CheckStackOverflow
    //     0x8142a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8142ac: cmp             SP, x16
    //     0x8142b0: b.ls            #0x814688
    // 0x8142b4: LoadField: r6 = r2->field_b
    //     0x8142b4: ldur            w6, [x2, #0xb]
    // 0x8142b8: r7 = LoadInt32Instr(r6)
    //     0x8142b8: sbfx            x7, x6, #1, #0x1f
    // 0x8142bc: cmp             x3, x7
    // 0x8142c0: b.ne            #0x81465c
    // 0x8142c4: cmp             x0, x7
    // 0x8142c8: b.ge            #0x814638
    // 0x8142cc: LoadField: r6 = r2->field_f
    //     0x8142cc: ldur            w6, [x2, #0xf]
    // 0x8142d0: DecompressPointer r6
    //     0x8142d0: add             x6, x6, HEAP, lsl #32
    // 0x8142d4: ArrayLoad: r7 = r6[r0]  ; Unknown_4
    //     0x8142d4: add             x16, x6, x0, lsl #2
    //     0x8142d8: ldur            w7, [x16, #0xf]
    // 0x8142dc: DecompressPointer r7
    //     0x8142dc: add             x7, x7, HEAP, lsl #32
    // 0x8142e0: stur            x7, [fp, #-0x20]
    // 0x8142e4: add             x6, x0, #1
    // 0x8142e8: stur            x6, [fp, #-0x18]
    // 0x8142ec: LoadField: r8 = r1->field_13
    //     0x8142ec: ldur            w8, [x1, #0x13]
    // 0x8142f0: DecompressPointer r8
    //     0x8142f0: add             x8, x8, HEAP, lsl #32
    // 0x8142f4: stur            x8, [fp, #-0x10]
    // 0x8142f8: cmp             w8, NULL
    // 0x8142fc: b.eq            #0x814690
    // 0x814300: r0 = LoadClassIdInstr(r7)
    //     0x814300: ldur            x0, [x7, #-1]
    //     0x814304: ubfx            x0, x0, #0xc, #0x14
    // 0x814308: str             x7, [SP]
    // 0x81430c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x81430c: mov             x17, #0xf078
    //     0x814310: add             lr, x0, x17
    //     0x814314: ldr             lr, [x21, lr, lsl #3]
    //     0x814318: blr             lr
    // 0x81431c: r1 = LoadInt32Instr(r0)
    //     0x81431c: sbfx            x1, x0, #1, #0x1f
    //     0x814320: tbz             w0, #0, #0x814328
    //     0x814324: ldur            x1, [x0, #7]
    // 0x814328: ldur            x4, [fp, #-0x28]
    // 0x81432c: add             x5, x4, x1
    // 0x814330: stur            x5, [fp, #-0x48]
    // 0x814334: tbz             x4, #0x3f, #0x814340
    // 0x814338: ldur            x6, [fp, #-0x10]
    // 0x81433c: b               #0x814364
    // 0x814340: cmp             x4, x5
    // 0x814344: b.le            #0x814350
    // 0x814348: ldur            x6, [fp, #-0x10]
    // 0x81434c: b               #0x814364
    // 0x814350: ldur            x6, [fp, #-0x10]
    // 0x814354: LoadField: r0 = r6->field_13
    //     0x814354: ldur            w0, [x6, #0x13]
    // 0x814358: r1 = LoadInt32Instr(r0)
    //     0x814358: sbfx            x1, x0, #1, #0x1f
    // 0x81435c: cmp             x5, x1
    // 0x814360: b.le            #0x814390
    // 0x814364: LoadField: r2 = r6->field_13
    //     0x814364: ldur            w2, [x6, #0x13]
    // 0x814368: r0 = BoxInt64Instr(r5)
    //     0x814368: sbfiz           x0, x5, #1, #0x1f
    //     0x81436c: cmp             x5, x0, asr #1
    //     0x814370: b.eq            #0x81437c
    //     0x814374: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x814378: stur            x5, [x0, #7]
    // 0x81437c: r3 = LoadInt32Instr(r2)
    //     0x81437c: sbfx            x3, x2, #1, #0x1f
    // 0x814380: mov             x1, x4
    // 0x814384: mov             x2, x0
    // 0x814388: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x814388: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x81438c: r0 = checkValidRange()
    //     0x81438c: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x814390: ldur            x2, [fp, #-0x20]
    // 0x814394: r0 = LoadClassIdInstr(r2)
    //     0x814394: ldur            x0, [x2, #-1]
    //     0x814398: ubfx            x0, x0, #0xc, #0x14
    // 0x81439c: sub             x16, x0, #0x70
    // 0x8143a0: cmp             x16, #0x37
    // 0x8143a4: b.hi            #0x8145bc
    // 0x8143a8: r0 = LoadClassIdInstr(r2)
    //     0x8143a8: ldur            x0, [x2, #-1]
    //     0x8143ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8143b0: mov             x1, x2
    // 0x8143b4: r0 = GDT[cid_x0 + -0x7f5]()
    //     0x8143b4: sub             lr, x0, #0x7f5
    //     0x8143b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8143bc: blr             lr
    // 0x8143c0: cmp             x0, #1
    // 0x8143c4: b.ne            #0x8145a4
    // 0x8143c8: ldur            x2, [fp, #-0x28]
    // 0x8143cc: ldur            x3, [fp, #-0x48]
    // 0x8143d0: ldur            x5, [fp, #-0x20]
    // 0x8143d4: sub             x1, x3, x2
    // 0x8143d8: stur            x1, [fp, #-0x50]
    // 0x8143dc: r0 = LoadClassIdInstr(r5)
    //     0x8143dc: ldur            x0, [x5, #-1]
    //     0x8143e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8143e4: str             x5, [SP]
    // 0x8143e8: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8143e8: mov             x17, #0xf078
    //     0x8143ec: add             lr, x0, x17
    //     0x8143f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8143f4: blr             lr
    // 0x8143f8: r1 = LoadInt32Instr(r0)
    //     0x8143f8: sbfx            x1, x0, #1, #0x1f
    //     0x8143fc: tbz             w0, #0, #0x814404
    //     0x814400: ldur            x1, [x0, #7]
    // 0x814404: ldur            x2, [fp, #-0x50]
    // 0x814408: cmp             x1, x2
    // 0x81440c: b.lt            #0x814650
    // 0x814410: cbnz            x2, #0x814420
    // 0x814414: ldur            x1, [fp, #-0x28]
    // 0x814418: ldur            x0, [fp, #-0x20]
    // 0x81441c: b               #0x8145ec
    // 0x814420: r0 = BoxInt64Instr(r2)
    //     0x814420: sbfiz           x0, x2, #1, #0x1f
    //     0x814424: cmp             x2, x0, asr #1
    //     0x814428: b.eq            #0x814434
    //     0x81442c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x814430: stur            x2, [x0, #7]
    // 0x814434: mov             x3, x0
    // 0x814438: cmp             w3, #0x800
    // 0x81443c: b.ge            #0x814538
    // 0x814440: ldur            x23, [fp, #-0x28]
    // 0x814444: ldur            x4, [fp, #-0x10]
    // 0x814448: ldur            x20, [fp, #-0x20]
    // 0x81444c: r0 = BoxInt64Instr(r23)
    //     0x81444c: sbfiz           x0, x23, #1, #0x1f
    //     0x814450: cmp             x23, x0, asr #1
    //     0x814454: b.eq            #0x814460
    //     0x814458: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x81445c: stur            x23, [x0, #7]
    // 0x814460: LoadField: r1 = r20->field_7
    //     0x814460: ldur            x1, [x20, #7]
    // 0x814464: mov             x5, x3
    // 0x814468: mov             x3, x1
    // 0x81446c: sxtw            x0, w0
    // 0x814470: add             x2, x4, x0, asr #1
    // 0x814474: add             x2, x2, #0x17
    // 0x814478: cbz             x5, #0x814530
    // 0x81447c: cmp             x2, x3
    // 0x814480: b.ls            #0x8144e8
    // 0x814484: sxtw            x5, w5
    // 0x814488: add             x16, x3, x5, asr #1
    // 0x81448c: cmp             x2, x16
    // 0x814490: b.hs            #0x8144e8
    // 0x814494: mov             x3, x16
    // 0x814498: add             x2, x2, x5, asr #1
    // 0x81449c: tbz             w5, #4, #0x8144a8
    // 0x8144a0: ldr             x16, [x3, #-8]!
    // 0x8144a4: str             x16, [x2, #-8]!
    // 0x8144a8: tbz             w5, #3, #0x8144b4
    // 0x8144ac: ldr             w16, [x3, #-4]!
    // 0x8144b0: str             w16, [x2, #-4]!
    // 0x8144b4: tbz             w5, #2, #0x8144c0
    // 0x8144b8: ldrh            w16, [x3, #-2]!
    // 0x8144bc: strh            w16, [x2, #-2]!
    // 0x8144c0: tbz             w5, #1, #0x8144cc
    // 0x8144c4: ldrb            w16, [x3, #-1]!
    // 0x8144c8: strb            w16, [x2, #-1]!
    // 0x8144cc: ands            w5, w5, #0xffffffe1
    // 0x8144d0: b.eq            #0x814530
    // 0x8144d4: ldp             x16, x17, [x3, #-0x10]!
    // 0x8144d8: stp             x16, x17, [x2, #-0x10]!
    // 0x8144dc: subs            w5, w5, #0x20
    // 0x8144e0: b.ne            #0x8144d4
    // 0x8144e4: b               #0x814530
    // 0x8144e8: tbz             w5, #4, #0x8144f4
    // 0x8144ec: ldr             x16, [x3], #8
    // 0x8144f0: str             x16, [x2], #8
    // 0x8144f4: tbz             w5, #3, #0x814500
    // 0x8144f8: ldr             w16, [x3], #4
    // 0x8144fc: str             w16, [x2], #4
    // 0x814500: tbz             w5, #2, #0x81450c
    // 0x814504: ldrh            w16, [x3], #2
    // 0x814508: strh            w16, [x2], #2
    // 0x81450c: tbz             w5, #1, #0x814518
    // 0x814510: ldrb            w16, [x3], #1
    // 0x814514: strb            w16, [x2], #1
    // 0x814518: ands            w5, w5, #0xffffffe1
    // 0x81451c: b.eq            #0x814530
    // 0x814520: ldp             x16, x17, [x3], #0x10
    // 0x814524: stp             x16, x17, [x2], #0x10
    // 0x814528: subs            w5, w5, #0x20
    // 0x81452c: b.ne            #0x814520
    // 0x814530: ldur            x24, [fp, #-0x30]
    // 0x814534: b               #0x814598
    // 0x814538: ldur            x23, [fp, #-0x28]
    // 0x81453c: ldur            x4, [fp, #-0x10]
    // 0x814540: ldur            x24, [fp, #-0x30]
    // 0x814544: ldur            x20, [fp, #-0x20]
    // 0x814548: LoadField: r0 = r4->field_7
    //     0x814548: ldur            x0, [x4, #7]
    // 0x81454c: add             x1, x0, x23
    // 0x814550: LoadField: r0 = r20->field_7
    //     0x814550: ldur            x0, [x20, #7]
    // 0x814554: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x814554: ldr             x9, [x24, #0x888]
    //     0x814558: mov             x16, x0
    //     0x81455c: mov             x0, x1
    //     0x814560: mov             x1, x16
    //     0x814564: mov             x17, fp
    //     0x814568: str             fp, [SP, #-8]!
    //     0x81456c: mov             fp, SP
    //     0x814570: and             SP, SP, #0xfffffffffffffff0
    //     0x814574: mov             x19, sp
    //     0x814578: mov             sp, SP
    //     0x81457c: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x814580: blr             x9
    //     0x814584: mov             x16, #8
    //     0x814588: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x81458c: mov             sp, x19
    //     0x814590: mov             SP, fp
    //     0x814594: ldr             fp, [SP], #8
    // 0x814598: mov             x1, x23
    // 0x81459c: mov             x0, x20
    // 0x8145a0: b               #0x8145ec
    // 0x8145a4: ldur            x23, [fp, #-0x28]
    // 0x8145a8: ldur            x4, [fp, #-0x10]
    // 0x8145ac: ldur            x3, [fp, #-0x48]
    // 0x8145b0: ldur            x24, [fp, #-0x30]
    // 0x8145b4: ldur            x20, [fp, #-0x20]
    // 0x8145b8: b               #0x8145d0
    // 0x8145bc: ldur            x23, [fp, #-0x28]
    // 0x8145c0: ldur            x4, [fp, #-0x10]
    // 0x8145c4: ldur            x3, [fp, #-0x48]
    // 0x8145c8: ldur            x24, [fp, #-0x30]
    // 0x8145cc: mov             x20, x2
    // 0x8145d0: mov             x1, x4
    // 0x8145d4: mov             x2, x23
    // 0x8145d8: mov             x5, x20
    // 0x8145dc: r6 = 0
    //     0x8145dc: mov             x6, #0
    // 0x8145e0: r0 = _slowSetRange()
    //     0x8145e0: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x8145e4: ldur            x1, [fp, #-0x28]
    // 0x8145e8: ldur            x0, [fp, #-0x20]
    // 0x8145ec: r2 = LoadClassIdInstr(r0)
    //     0x8145ec: ldur            x2, [x0, #-1]
    //     0x8145f0: ubfx            x2, x2, #0xc, #0x14
    // 0x8145f4: str             x0, [SP]
    // 0x8145f8: mov             x0, x2
    // 0x8145fc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8145fc: mov             x17, #0xf078
    //     0x814600: add             lr, x0, x17
    //     0x814604: ldr             lr, [x21, lr, lsl #3]
    //     0x814608: blr             lr
    // 0x81460c: r1 = LoadInt32Instr(r0)
    //     0x81460c: sbfx            x1, x0, #1, #0x1f
    //     0x814610: tbz             w0, #0, #0x814618
    //     0x814614: ldur            x1, [x0, #7]
    // 0x814618: ldur            x0, [fp, #-0x28]
    // 0x81461c: add             x5, x0, x1
    // 0x814620: ldur            x0, [fp, #-0x18]
    // 0x814624: ldur            x1, [fp, #-8]
    // 0x814628: ldur            x2, [fp, #-0x40]
    // 0x81462c: ldur            x4, [fp, #-0x30]
    // 0x814630: ldur            x3, [fp, #-0x38]
    // 0x814634: b               #0x8142a4
    // 0x814638: mov             x0, x1
    // 0x81463c: StoreField: r0->field_7 = rNULL
    //     0x81463c: stur            NULL, [x0, #7]
    // 0x814640: r0 = Null
    //     0x814640: mov             x0, NULL
    // 0x814644: LeaveFrame
    //     0x814644: mov             SP, fp
    //     0x814648: ldp             fp, lr, [SP], #0x10
    // 0x81464c: ret
    //     0x81464c: ret             
    // 0x814650: r0 = tooFew()
    //     0x814650: bl              #0x7e9534  ; [dart:_internal] IterableElementError::tooFew
    // 0x814654: r0 = Throw()
    //     0x814654: bl              #0x13ddb2c  ; ThrowStub
    // 0x814658: brk             #0
    // 0x81465c: mov             x0, x2
    // 0x814660: r0 = ConcurrentModificationError()
    //     0x814660: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x814664: mov             x1, x0
    // 0x814668: ldur            x0, [fp, #-0x40]
    // 0x81466c: StoreField: r1->field_b = r0
    //     0x81466c: stur            w0, [x1, #0xb]
    // 0x814670: mov             x0, x1
    // 0x814674: r0 = Throw()
    //     0x814674: bl              #0x13ddb2c  ; ThrowStub
    // 0x814678: brk             #0
    // 0x81467c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81467c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x814680: b               #0x814214
    // 0x814684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x814684: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x814688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x814688: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81468c: b               #0x8142b4
    // 0x814690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x814690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
