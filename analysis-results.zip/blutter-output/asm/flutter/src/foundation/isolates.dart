// lib: , url: package:flutter/src/foundation/isolates.dart

// class id: 1048803, size: 0x8
class :: {

  static _ compute(/* No info */) {
    // ** addr: 0x846c30, size: 0xa4
    // 0x846c30: EnterFrame
    //     0x846c30: stp             fp, lr, [SP, #-0x10]!
    //     0x846c34: mov             fp, SP
    // 0x846c38: AllocStack(0x20)
    //     0x846c38: sub             SP, SP, #0x20
    // 0x846c3c: SetupParameters(dynamic _ /* r2 */, dynamic _ /* r3 */, {dynamic debugLabel = Null /* r0 */})
    //     0x846c3c: ldur            w0, [x4, #0x13]
    //     0x846c40: sub             x1, x0, #4
    //     0x846c44: add             x2, fp, w1, sxtw #2
    //     0x846c48: ldr             x2, [x2, #0x18]
    //     0x846c4c: add             x3, fp, w1, sxtw #2
    //     0x846c50: ldr             x3, [x3, #0x10]
    //     0x846c54: ldur            w1, [x4, #0x1f]
    //     0x846c58: add             x1, x1, HEAP, lsl #32
    //     0x846c5c: ldr             x16, [PP, #0x2078]  ; [pp+0x2078] "debugLabel"
    //     0x846c60: cmp             w1, w16
    //     0x846c64: b.ne            #0x846c80
    //     0x846c68: ldur            w1, [x4, #0x23]
    //     0x846c6c: add             x1, x1, HEAP, lsl #32
    //     0x846c70: sub             w5, w0, w1
    //     0x846c74: add             x0, fp, w5, sxtw #2
    //     0x846c78: ldr             x0, [x0, #8]
    //     0x846c7c: b               #0x846c84
    //     0x846c80: mov             x0, NULL
    //     0x846c84: ldur            w1, [x4, #0xf]
    //     0x846c88: cbnz            w1, #0x846c94
    //     0x846c8c: mov             x1, NULL
    //     0x846c90: b               #0x846ca4
    //     0x846c94: ldur            w1, [x4, #0x17]
    //     0x846c98: add             x4, fp, w1, sxtw #2
    //     0x846c9c: ldr             x4, [x4, #0x10]
    //     0x846ca0: mov             x1, x4
    // 0x846ca4: CheckStackOverflow
    //     0x846ca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846ca8: cmp             SP, x16
    //     0x846cac: b.ls            #0x846ccc
    // 0x846cb0: stp             x2, x1, [SP, #0x10]
    // 0x846cb4: stp             x0, x3, [SP]
    // 0x846cb8: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x846cb8: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x846cbc: r0 = compute()
    //     0x846cbc: bl              #0x846d98  ; [package:flutter/src/foundation/_isolates_io.dart] ::compute
    // 0x846cc0: LeaveFrame
    //     0x846cc0: mov             SP, fp
    //     0x846cc4: ldp             fp, lr, [SP], #0x10
    // 0x846cc8: ret
    //     0x846cc8: ret             
    // 0x846ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846cd0: b               #0x846cb0
  }
  [closure] static Future<Y1> compute<Y0, Y1>(dynamic, (dynamic, Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) {
    // ** addr: 0x846cd4, size: 0xc4
    // 0x846cd4: EnterFrame
    //     0x846cd4: stp             fp, lr, [SP, #-0x10]!
    //     0x846cd8: mov             fp, SP
    // 0x846cdc: AllocStack(0x20)
    //     0x846cdc: sub             SP, SP, #0x20
    // 0x846ce0: SetupParameters(dynamic _ /* r2 */, dynamic _ /* r3 */, dynamic _ /* r5 */, {dynamic debugLabel = Null /* r0 */})
    //     0x846ce0: ldur            w0, [x4, #0x13]
    //     0x846ce4: sub             x1, x0, #6
    //     0x846ce8: add             x2, fp, w1, sxtw #2
    //     0x846cec: ldr             x2, [x2, #0x20]
    //     0x846cf0: add             x3, fp, w1, sxtw #2
    //     0x846cf4: ldr             x3, [x3, #0x18]
    //     0x846cf8: add             x5, fp, w1, sxtw #2
    //     0x846cfc: ldr             x5, [x5, #0x10]
    //     0x846d00: ldur            w1, [x4, #0x1f]
    //     0x846d04: add             x1, x1, HEAP, lsl #32
    //     0x846d08: ldr             x16, [PP, #0x2078]  ; [pp+0x2078] "debugLabel"
    //     0x846d0c: cmp             w1, w16
    //     0x846d10: b.ne            #0x846d2c
    //     0x846d14: ldur            w1, [x4, #0x23]
    //     0x846d18: add             x1, x1, HEAP, lsl #32
    //     0x846d1c: sub             w6, w0, w1
    //     0x846d20: add             x0, fp, w6, sxtw #2
    //     0x846d24: ldr             x0, [x0, #8]
    //     0x846d28: b               #0x846d30
    //     0x846d2c: mov             x0, NULL
    //     0x846d30: ldur            w1, [x4, #0xf]
    //     0x846d34: cbnz            w1, #0x846d40
    //     0x846d38: mov             x1, NULL
    //     0x846d3c: b               #0x846d50
    //     0x846d40: ldur            w1, [x4, #0x17]
    //     0x846d44: add             x4, fp, w1, sxtw #2
    //     0x846d48: ldr             x4, [x4, #0x10]
    //     0x846d4c: mov             x1, x4
    //     0x846d50: ldur            w4, [x2, #0xf]
    //     0x846d54: add             x4, x4, HEAP, lsl #32
    //     0x846d58: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    //     0x846d5c: cmp             w4, w16
    //     0x846d60: b.eq            #0x846d68
    //     0x846d64: mov             x1, x4
    // 0x846d68: CheckStackOverflow
    //     0x846d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846d6c: cmp             SP, x16
    //     0x846d70: b.ls            #0x846d90
    // 0x846d74: stp             x3, x1, [SP, #0x10]
    // 0x846d78: stp             x0, x5, [SP]
    // 0x846d7c: r4 = const [0x2, 0x3, 0x3, 0x2, debugLabel, 0x2, null]
    //     0x846d7c: ldr             x4, [PP, #0x35b0]  ; [pp+0x35b0] List(7) [0x2, 0x3, 0x3, 0x2, "debugLabel", 0x2, Null]
    // 0x846d80: r0 = compute()
    //     0x846d80: bl              #0x846c30  ; [package:flutter/src/foundation/isolates.dart] ::compute
    // 0x846d84: LeaveFrame
    //     0x846d84: mov             SP, fp
    //     0x846d88: ldp             fp, lr, [SP], #0x10
    // 0x846d8c: ret
    //     0x846d8c: ret             
    // 0x846d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846d90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846d94: b               #0x846d74
  }
}
