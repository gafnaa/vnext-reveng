// lib: , url: package:flutter/src/foundation/key.dart

// class id: 1048804, size: 0x8
class :: {
}

// class id: 3198, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Key extends Object {
}

// class id: 3204, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class LocalKey extends Key {
}

// class id: 3205, size: 0x10, field offset: 0x8
//   const constructor, 
class ValueKey<X0> extends LocalKey {

  _OneByteString field_c;

  _ toString(/* No info */) {
    // ** addr: 0x1115558, size: 0x1f4
    // 0x1115558: EnterFrame
    //     0x1115558: stp             fp, lr, [SP, #-0x10]!
    //     0x111555c: mov             fp, SP
    // 0x1115560: AllocStack(0x28)
    //     0x1115560: sub             SP, SP, #0x28
    // 0x1115564: CheckStackOverflow
    //     0x1115564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1115568: cmp             SP, x16
    //     0x111556c: b.ls            #0x1115744
    // 0x1115570: ldr             x0, [fp, #0x10]
    // 0x1115574: LoadField: r3 = r0->field_7
    //     0x1115574: ldur            w3, [x0, #7]
    // 0x1115578: DecompressPointer r3
    //     0x1115578: add             x3, x3, HEAP, lsl #32
    // 0x111557c: mov             x2, x3
    // 0x1115580: stur            x3, [fp, #-8]
    // 0x1115584: r1 = Null
    //     0x1115584: mov             x1, NULL
    // 0x1115588: r3 = X0
    //     0x1115588: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x111558c: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x111558c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x1115590: ldr             lr, [lr, #0xe80]
    // 0x1115594: LoadField: r30 = r30->field_7
    //     0x1115594: ldur            lr, [lr, #7]
    // 0x1115598: blr             lr
    // 0x111559c: r1 = LoadClassIdInstr(r0)
    //     0x111559c: ldur            x1, [x0, #-1]
    //     0x11155a0: ubfx            x1, x1, #0xc, #0x14
    // 0x11155a4: r16 = String
    //     0x11155a4: ldr             x16, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x11155a8: stp             x16, x0, [SP]
    // 0x11155ac: mov             x0, x1
    // 0x11155b0: mov             lr, x0
    // 0x11155b4: ldr             lr, [x21, lr, lsl #3]
    // 0x11155b8: blr             lr
    // 0x11155bc: tbnz            w0, #4, #0x1115604
    // 0x11155c0: ldr             x0, [fp, #0x10]
    // 0x11155c4: r1 = Null
    //     0x11155c4: mov             x1, NULL
    // 0x11155c8: r2 = 6
    //     0x11155c8: mov             x2, #6
    // 0x11155cc: r0 = AllocateArray()
    //     0x11155cc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11155d0: r16 = "<\'"
    //     0x11155d0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27028] "<\'"
    //     0x11155d4: ldr             x16, [x16, #0x28]
    // 0x11155d8: StoreField: r0->field_f = r16
    //     0x11155d8: stur            w16, [x0, #0xf]
    // 0x11155dc: ldr             x1, [fp, #0x10]
    // 0x11155e0: LoadField: r2 = r1->field_b
    //     0x11155e0: ldur            w2, [x1, #0xb]
    // 0x11155e4: DecompressPointer r2
    //     0x11155e4: add             x2, x2, HEAP, lsl #32
    // 0x11155e8: StoreField: r0->field_13 = r2
    //     0x11155e8: stur            w2, [x0, #0x13]
    // 0x11155ec: r16 = "\'>"
    //     0x11155ec: add             x16, PP, #0x27, lsl #12  ; [pp+0x27030] "\'>"
    //     0x11155f0: ldr             x16, [x16, #0x30]
    // 0x11155f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x11155f4: stur            w16, [x0, #0x17]
    // 0x11155f8: str             x0, [SP]
    // 0x11155fc: r0 = _interpolate()
    //     0x11155fc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115600: b               #0x111563c
    // 0x1115604: ldr             x0, [fp, #0x10]
    // 0x1115608: r1 = Null
    //     0x1115608: mov             x1, NULL
    // 0x111560c: r2 = 6
    //     0x111560c: mov             x2, #6
    // 0x1115610: r0 = AllocateArray()
    //     0x1115610: bl              #0x13df928  ; AllocateArrayStub
    // 0x1115614: r16 = "<"
    //     0x1115614: ldr             x16, [PP, #0xec0]  ; [pp+0xec0] "<"
    // 0x1115618: StoreField: r0->field_f = r16
    //     0x1115618: stur            w16, [x0, #0xf]
    // 0x111561c: ldr             x1, [fp, #0x10]
    // 0x1115620: LoadField: r2 = r1->field_b
    //     0x1115620: ldur            w2, [x1, #0xb]
    // 0x1115624: DecompressPointer r2
    //     0x1115624: add             x2, x2, HEAP, lsl #32
    // 0x1115628: StoreField: r0->field_13 = r2
    //     0x1115628: stur            w2, [x0, #0x13]
    // 0x111562c: r16 = ">"
    //     0x111562c: ldr             x16, [PP, #0xe50]  ; [pp+0xe50] ">"
    // 0x1115630: ArrayStore: r0[0] = r16  ; List_4
    //     0x1115630: stur            w16, [x0, #0x17]
    // 0x1115634: str             x0, [SP]
    // 0x1115638: r0 = _interpolate()
    //     0x1115638: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x111563c: stur            x0, [fp, #-0x10]
    // 0x1115640: ldr             x16, [fp, #0x10]
    // 0x1115644: str             x16, [SP]
    // 0x1115648: r0 = runtimeType()
    //     0x1115648: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x111564c: ldur            x2, [fp, #-8]
    // 0x1115650: r1 = Null
    //     0x1115650: mov             x1, NULL
    // 0x1115654: stur            x0, [fp, #-0x18]
    // 0x1115658: r3 = ValueKey<X0>
    //     0x1115658: add             x3, PP, #0x27, lsl #12  ; [pp+0x27038] Type: ValueKey<X0>
    //     0x111565c: ldr             x3, [x3, #0x38]
    // 0x1115660: r30 = InstantiateTypeStub
    //     0x1115660: add             lr, PP, #0x27, lsl #12  ; [pp+0x27040] Stub: InstantiateType (0x7c12bc)
    //     0x1115664: ldr             lr, [lr, #0x40]
    // 0x1115668: LoadField: r30 = r30->field_7
    //     0x1115668: ldur            lr, [lr, #7]
    // 0x111566c: blr             lr
    // 0x1115670: mov             x1, x0
    // 0x1115674: ldur            x0, [fp, #-0x18]
    // 0x1115678: r2 = LoadClassIdInstr(r0)
    //     0x1115678: ldur            x2, [x0, #-1]
    //     0x111567c: ubfx            x2, x2, #0xc, #0x14
    // 0x1115680: stp             x1, x0, [SP]
    // 0x1115684: mov             x0, x2
    // 0x1115688: mov             lr, x0
    // 0x111568c: ldr             lr, [x21, lr, lsl #3]
    // 0x1115690: blr             lr
    // 0x1115694: tbnz            w0, #4, #0x11156d4
    // 0x1115698: ldur            x0, [fp, #-0x10]
    // 0x111569c: r1 = Null
    //     0x111569c: mov             x1, NULL
    // 0x11156a0: r2 = 6
    //     0x11156a0: mov             x2, #6
    // 0x11156a4: r0 = AllocateArray()
    //     0x11156a4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11156a8: r16 = "["
    //     0x11156a8: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0x11156ac: StoreField: r0->field_f = r16
    //     0x11156ac: stur            w16, [x0, #0xf]
    // 0x11156b0: ldur            x3, [fp, #-0x10]
    // 0x11156b4: StoreField: r0->field_13 = r3
    //     0x11156b4: stur            w3, [x0, #0x13]
    // 0x11156b8: r16 = "]"
    //     0x11156b8: ldr             x16, [PP, #0x1298]  ; [pp+0x1298] "]"
    // 0x11156bc: ArrayStore: r0[0] = r16  ; List_4
    //     0x11156bc: stur            w16, [x0, #0x17]
    // 0x11156c0: str             x0, [SP]
    // 0x11156c4: r0 = _interpolate()
    //     0x11156c4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11156c8: LeaveFrame
    //     0x11156c8: mov             SP, fp
    //     0x11156cc: ldp             fp, lr, [SP], #0x10
    // 0x11156d0: ret
    //     0x11156d0: ret             
    // 0x11156d4: ldur            x3, [fp, #-0x10]
    // 0x11156d8: r1 = Null
    //     0x11156d8: mov             x1, NULL
    // 0x11156dc: r2 = 10
    //     0x11156dc: mov             x2, #0xa
    // 0x11156e0: r0 = AllocateArray()
    //     0x11156e0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11156e4: stur            x0, [fp, #-0x18]
    // 0x11156e8: r16 = "["
    //     0x11156e8: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0x11156ec: StoreField: r0->field_f = r16
    //     0x11156ec: stur            w16, [x0, #0xf]
    // 0x11156f0: ldur            x2, [fp, #-8]
    // 0x11156f4: r1 = Null
    //     0x11156f4: mov             x1, NULL
    // 0x11156f8: r3 = X0
    //     0x11156f8: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x11156fc: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x11156fc: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x1115700: ldr             lr, [lr, #0xe80]
    // 0x1115704: LoadField: r30 = r30->field_7
    //     0x1115704: ldur            lr, [lr, #7]
    // 0x1115708: blr             lr
    // 0x111570c: mov             x1, x0
    // 0x1115710: ldur            x0, [fp, #-0x18]
    // 0x1115714: StoreField: r0->field_13 = r1
    //     0x1115714: stur            w1, [x0, #0x13]
    // 0x1115718: r16 = " "
    //     0x1115718: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x111571c: ArrayStore: r0[0] = r16  ; List_4
    //     0x111571c: stur            w16, [x0, #0x17]
    // 0x1115720: ldur            x1, [fp, #-0x10]
    // 0x1115724: StoreField: r0->field_1b = r1
    //     0x1115724: stur            w1, [x0, #0x1b]
    // 0x1115728: r16 = "]"
    //     0x1115728: ldr             x16, [PP, #0x1298]  ; [pp+0x1298] "]"
    // 0x111572c: StoreField: r0->field_1f = r16
    //     0x111572c: stur            w16, [x0, #0x1f]
    // 0x1115730: str             x0, [SP]
    // 0x1115734: r0 = _interpolate()
    //     0x1115734: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115738: LeaveFrame
    //     0x1115738: mov             SP, fp
    //     0x111573c: ldp             fp, lr, [SP], #0x10
    // 0x1115740: ret
    //     0x1115740: ret             
    // 0x1115744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115744: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115748: b               #0x1115570
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114a99c, size: 0x68
    // 0x114a99c: EnterFrame
    //     0x114a99c: stp             fp, lr, [SP, #-0x10]!
    //     0x114a9a0: mov             fp, SP
    // 0x114a9a4: AllocStack(0x8)
    //     0x114a9a4: sub             SP, SP, #8
    // 0x114a9a8: CheckStackOverflow
    //     0x114a9a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114a9ac: cmp             SP, x16
    //     0x114a9b0: b.ls            #0x114a9fc
    // 0x114a9b4: ldr             x16, [fp, #0x10]
    // 0x114a9b8: str             x16, [SP]
    // 0x114a9bc: r0 = runtimeType()
    //     0x114a9bc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x114a9c0: mov             x1, x0
    // 0x114a9c4: ldr             x0, [fp, #0x10]
    // 0x114a9c8: LoadField: r2 = r0->field_b
    //     0x114a9c8: ldur            w2, [x0, #0xb]
    // 0x114a9cc: DecompressPointer r2
    //     0x114a9cc: add             x2, x2, HEAP, lsl #32
    // 0x114a9d0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x114a9d0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x114a9d4: r0 = hash()
    //     0x114a9d4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114a9d8: mov             x2, x0
    // 0x114a9dc: r0 = BoxInt64Instr(r2)
    //     0x114a9dc: sbfiz           x0, x2, #1, #0x1f
    //     0x114a9e0: cmp             x2, x0, asr #1
    //     0x114a9e4: b.eq            #0x114a9f0
    //     0x114a9e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114a9ec: stur            x2, [x0, #7]
    // 0x114a9f0: LeaveFrame
    //     0x114a9f0: mov             SP, fp
    //     0x114a9f4: ldp             fp, lr, [SP], #0x10
    // 0x114a9f8: ret
    //     0x114a9f8: ret             
    // 0x114a9fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114a9fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114aa00: b               #0x114a9b4
  }
  _ ==(/* No info */) {
    // ** addr: 0x12952c8, size: 0x11c
    // 0x12952c8: EnterFrame
    //     0x12952c8: stp             fp, lr, [SP, #-0x10]!
    //     0x12952cc: mov             fp, SP
    // 0x12952d0: AllocStack(0x10)
    //     0x12952d0: sub             SP, SP, #0x10
    // 0x12952d4: CheckStackOverflow
    //     0x12952d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12952d8: cmp             SP, x16
    //     0x12952dc: b.ls            #0x12953dc
    // 0x12952e0: ldr             x0, [fp, #0x10]
    // 0x12952e4: cmp             w0, NULL
    // 0x12952e8: b.ne            #0x12952fc
    // 0x12952ec: r0 = false
    //     0x12952ec: add             x0, NULL, #0x30  ; false
    // 0x12952f0: LeaveFrame
    //     0x12952f0: mov             SP, fp
    //     0x12952f4: ldp             fp, lr, [SP], #0x10
    // 0x12952f8: ret
    //     0x12952f8: ret             
    // 0x12952fc: ldr             x16, [fp, #0x18]
    // 0x1295300: stp             x16, x0, [SP]
    // 0x1295304: r0 = _haveSameRuntimeType()
    //     0x1295304: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1295308: tbz             w0, #4, #0x129531c
    // 0x129530c: r0 = false
    //     0x129530c: add             x0, NULL, #0x30  ; false
    // 0x1295310: LeaveFrame
    //     0x1295310: mov             SP, fp
    //     0x1295314: ldp             fp, lr, [SP], #0x10
    // 0x1295318: ret
    //     0x1295318: ret             
    // 0x129531c: ldr             x3, [fp, #0x18]
    // 0x1295320: LoadField: r2 = r3->field_7
    //     0x1295320: ldur            w2, [x3, #7]
    // 0x1295324: DecompressPointer r2
    //     0x1295324: add             x2, x2, HEAP, lsl #32
    // 0x1295328: ldr             x0, [fp, #0x10]
    // 0x129532c: r1 = Null
    //     0x129532c: mov             x1, NULL
    // 0x1295330: cmp             w0, NULL
    // 0x1295334: b.eq            #0x1295380
    // 0x1295338: branchIfSmi(r0, 0x1295380)
    //     0x1295338: tbz             w0, #0, #0x1295380
    // 0x129533c: r3 = SubtypeTestCache
    //     0x129533c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27048] SubtypeTestCache
    //     0x1295340: ldr             x3, [x3, #0x48]
    // 0x1295344: r30 = Subtype3TestCacheStub
    //     0x1295344: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x1295348: LoadField: r30 = r30->field_7
    //     0x1295348: ldur            lr, [lr, #7]
    // 0x129534c: blr             lr
    // 0x1295350: cmp             w7, NULL
    // 0x1295354: b.eq            #0x1295360
    // 0x1295358: tbnz            w7, #4, #0x1295380
    // 0x129535c: b               #0x1295388
    // 0x1295360: r8 = ValueKey<X0>
    //     0x1295360: add             x8, PP, #0x27, lsl #12  ; [pp+0x27050] Type: ValueKey<X0>
    //     0x1295364: ldr             x8, [x8, #0x50]
    // 0x1295368: r3 = SubtypeTestCache
    //     0x1295368: add             x3, PP, #0x27, lsl #12  ; [pp+0x27058] SubtypeTestCache
    //     0x129536c: ldr             x3, [x3, #0x58]
    // 0x1295370: r30 = InstanceOfStub
    //     0x1295370: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1295374: LoadField: r30 = r30->field_7
    //     0x1295374: ldur            lr, [lr, #7]
    // 0x1295378: blr             lr
    // 0x129537c: b               #0x129538c
    // 0x1295380: r0 = false
    //     0x1295380: add             x0, NULL, #0x30  ; false
    // 0x1295384: b               #0x129538c
    // 0x1295388: r0 = true
    //     0x1295388: add             x0, NULL, #0x20  ; true
    // 0x129538c: tbnz            w0, #4, #0x12953cc
    // 0x1295390: ldr             x0, [fp, #0x18]
    // 0x1295394: ldr             x1, [fp, #0x10]
    // 0x1295398: LoadField: r2 = r1->field_b
    //     0x1295398: ldur            w2, [x1, #0xb]
    // 0x129539c: DecompressPointer r2
    //     0x129539c: add             x2, x2, HEAP, lsl #32
    // 0x12953a0: LoadField: r1 = r0->field_b
    //     0x12953a0: ldur            w1, [x0, #0xb]
    // 0x12953a4: DecompressPointer r1
    //     0x12953a4: add             x1, x1, HEAP, lsl #32
    // 0x12953a8: r0 = 60
    //     0x12953a8: mov             x0, #0x3c
    // 0x12953ac: branchIfSmi(r2, 0x12953b8)
    //     0x12953ac: tbz             w2, #0, #0x12953b8
    // 0x12953b0: r0 = LoadClassIdInstr(r2)
    //     0x12953b0: ldur            x0, [x2, #-1]
    //     0x12953b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12953b8: stp             x1, x2, [SP]
    // 0x12953bc: mov             lr, x0
    // 0x12953c0: ldr             lr, [x21, lr, lsl #3]
    // 0x12953c4: blr             lr
    // 0x12953c8: b               #0x12953d0
    // 0x12953cc: r0 = false
    //     0x12953cc: add             x0, NULL, #0x30  ; false
    // 0x12953d0: LeaveFrame
    //     0x12953d0: mov             SP, fp
    //     0x12953d4: ldp             fp, lr, [SP], #0x10
    // 0x12953d8: ret
    //     0x12953d8: ret             
    // 0x12953dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12953dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12953e0: b               #0x12952e0
  }
}

// class id: 3208, size: 0x8, field offset: 0x8
class UniqueKey extends LocalKey {

  _ toString(/* No info */) {
    // ** addr: 0x11154cc, size: 0x8c
    // 0x11154cc: EnterFrame
    //     0x11154cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11154d0: mov             fp, SP
    // 0x11154d4: AllocStack(0x10)
    //     0x11154d4: sub             SP, SP, #0x10
    // 0x11154d8: CheckStackOverflow
    //     0x11154d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11154dc: cmp             SP, x16
    //     0x11154e0: b.ls            #0x1115550
    // 0x11154e4: r1 = Null
    //     0x11154e4: mov             x1, NULL
    // 0x11154e8: r2 = 6
    //     0x11154e8: mov             x2, #6
    // 0x11154ec: r0 = AllocateArray()
    //     0x11154ec: bl              #0x13df928  ; AllocateArrayStub
    // 0x11154f0: stur            x0, [fp, #-8]
    // 0x11154f4: r16 = "[#"
    //     0x11154f4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12528] "[#"
    //     0x11154f8: ldr             x16, [x16, #0x528]
    // 0x11154fc: StoreField: r0->field_f = r16
    //     0x11154fc: stur            w16, [x0, #0xf]
    // 0x1115500: ldr             x1, [fp, #0x10]
    // 0x1115504: r0 = shortHash()
    //     0x1115504: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0x1115508: ldur            x1, [fp, #-8]
    // 0x111550c: ArrayStore: r1[1] = r0  ; List_4
    //     0x111550c: add             x25, x1, #0x13
    //     0x1115510: str             w0, [x25]
    //     0x1115514: tbz             w0, #0, #0x1115530
    //     0x1115518: ldurb           w16, [x1, #-1]
    //     0x111551c: ldurb           w17, [x0, #-1]
    //     0x1115520: and             x16, x17, x16, lsr #2
    //     0x1115524: tst             x16, HEAP, lsr #32
    //     0x1115528: b.eq            #0x1115530
    //     0x111552c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1115530: ldur            x0, [fp, #-8]
    // 0x1115534: r16 = "]"
    //     0x1115534: ldr             x16, [PP, #0x1298]  ; [pp+0x1298] "]"
    // 0x1115538: ArrayStore: r0[0] = r16  ; List_4
    //     0x1115538: stur            w16, [x0, #0x17]
    // 0x111553c: str             x0, [SP]
    // 0x1115540: r0 = _interpolate()
    //     0x1115540: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115544: LeaveFrame
    //     0x1115544: mov             SP, fp
    //     0x1115548: ldp             fp, lr, [SP], #0x10
    // 0x111554c: ret
    //     0x111554c: ret             
    // 0x1115550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115554: b               #0x11154e4
  }
}
