// lib: , url: package:flutter/src/foundation/licenses.dart

// class id: 1048805, size: 0x8
class :: {
}

// class id: 3195, size: 0x8, field offset: 0x8
abstract class LicenseRegistry extends Object {

  static _ addLicense(/* No info */) {
    // ** addr: 0x8467e0, size: 0x118
    // 0x8467e0: EnterFrame
    //     0x8467e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8467e4: mov             fp, SP
    // 0x8467e8: AllocStack(0x18)
    //     0x8467e8: sub             SP, SP, #0x18
    // 0x8467ec: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x8467ec: mov             x0, x1
    //     0x8467f0: stur            x1, [fp, #-8]
    // 0x8467f4: CheckStackOverflow
    //     0x8467f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8467f8: cmp             SP, x16
    //     0x8467fc: b.ls            #0x8468f0
    // 0x846800: r1 = LoadStaticField(0x828)
    //     0x846800: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x846804: ldr             x1, [x1, #0x1050]
    // 0x846808: cmp             w1, NULL
    // 0x84680c: b.ne            #0x846830
    // 0x846810: r1 = <(dynamic this) => Stream<LicenseEntry>>
    //     0x846810: ldr             x1, [PP, #0x3a10]  ; [pp+0x3a10] TypeArguments: <(dynamic this) => Stream<LicenseEntry>>
    // 0x846814: r2 = 0
    //     0x846814: mov             x2, #0
    // 0x846818: r0 = _GrowableList()
    //     0x846818: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x84681c: mov             x2, x0
    // 0x846820: StoreStaticField(0x828, r2)
    //     0x846820: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x846824: str             x2, [x1, #0x1050]
    // 0x846828: mov             x3, x0
    // 0x84682c: b               #0x846834
    // 0x846830: mov             x3, x1
    // 0x846834: stur            x3, [fp, #-0x10]
    // 0x846838: LoadField: r2 = r3->field_7
    //     0x846838: ldur            w2, [x3, #7]
    // 0x84683c: DecompressPointer r2
    //     0x84683c: add             x2, x2, HEAP, lsl #32
    // 0x846840: ldur            x0, [fp, #-8]
    // 0x846844: r1 = Null
    //     0x846844: mov             x1, NULL
    // 0x846848: cmp             w2, NULL
    // 0x84684c: b.eq            #0x846868
    // 0x846850: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x846850: ldur            w4, [x2, #0x17]
    // 0x846854: DecompressPointer r4
    //     0x846854: add             x4, x4, HEAP, lsl #32
    // 0x846858: r8 = X0
    //     0x846858: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84685c: LoadField: r9 = r4->field_7
    //     0x84685c: ldur            x9, [x4, #7]
    // 0x846860: r3 = Null
    //     0x846860: ldr             x3, [PP, #0x3a18]  ; [pp+0x3a18] Null
    // 0x846864: blr             x9
    // 0x846868: ldur            x0, [fp, #-0x10]
    // 0x84686c: LoadField: r1 = r0->field_b
    //     0x84686c: ldur            w1, [x0, #0xb]
    // 0x846870: LoadField: r2 = r0->field_f
    //     0x846870: ldur            w2, [x0, #0xf]
    // 0x846874: DecompressPointer r2
    //     0x846874: add             x2, x2, HEAP, lsl #32
    // 0x846878: LoadField: r3 = r2->field_b
    //     0x846878: ldur            w3, [x2, #0xb]
    // 0x84687c: r2 = LoadInt32Instr(r1)
    //     0x84687c: sbfx            x2, x1, #1, #0x1f
    // 0x846880: stur            x2, [fp, #-0x18]
    // 0x846884: r1 = LoadInt32Instr(r3)
    //     0x846884: sbfx            x1, x3, #1, #0x1f
    // 0x846888: cmp             x2, x1
    // 0x84688c: b.ne            #0x846898
    // 0x846890: mov             x1, x0
    // 0x846894: r0 = _growToNextCapacity()
    //     0x846894: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x846898: ldur            x3, [fp, #-0x18]
    // 0x84689c: ldur            x2, [fp, #-0x10]
    // 0x8468a0: add             x4, x3, #1
    // 0x8468a4: lsl             x5, x4, #1
    // 0x8468a8: StoreField: r2->field_b = r5
    //     0x8468a8: stur            w5, [x2, #0xb]
    // 0x8468ac: LoadField: r1 = r2->field_f
    //     0x8468ac: ldur            w1, [x2, #0xf]
    // 0x8468b0: DecompressPointer r1
    //     0x8468b0: add             x1, x1, HEAP, lsl #32
    // 0x8468b4: ldur            x0, [fp, #-8]
    // 0x8468b8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8468b8: add             x25, x1, x3, lsl #2
    //     0x8468bc: add             x25, x25, #0xf
    //     0x8468c0: str             w0, [x25]
    //     0x8468c4: tbz             w0, #0, #0x8468e0
    //     0x8468c8: ldurb           w16, [x1, #-1]
    //     0x8468cc: ldurb           w17, [x0, #-1]
    //     0x8468d0: and             x16, x17, x16, lsr #2
    //     0x8468d4: tst             x16, HEAP, lsr #32
    //     0x8468d8: b.eq            #0x8468e0
    //     0x8468dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8468e0: r0 = Null
    //     0x8468e0: mov             x0, NULL
    // 0x8468e4: LeaveFrame
    //     0x8468e4: mov             SP, fp
    //     0x8468e8: ldp             fp, lr, [SP], #0x10
    // 0x8468ec: ret
    //     0x8468ec: ret             
    // 0x8468f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8468f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8468f4: b               #0x846800
  }
}

// class id: 3196, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class LicenseEntry extends Object {
}

// class id: 3197, size: 0x8, field offset: 0x8
//   const constructor, 
class LicenseEntryWithLineBreaks extends LicenseEntry {
}
