// lib: , url: package:flutter/src/foundation/persistent_hash_map.dart

// class id: 1048808, size: 0x8
class :: {
}

// class id: 3190, size: 0x8, field offset: 0x8
abstract class _TrieNode extends Object {
}

// class id: 3191, size: 0x14, field offset: 0x8
class _HashCollisionNode extends _TrieNode {

  _ _indexOf(/* No info */) {
    // ** addr: 0x842684, size: 0xcc
    // 0x842684: EnterFrame
    //     0x842684: stp             fp, lr, [SP, #-0x10]!
    //     0x842688: mov             fp, SP
    // 0x84268c: AllocStack(0x30)
    //     0x84268c: sub             SP, SP, #0x30
    // 0x842690: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x842690: stur            x2, [fp, #-0x20]
    // 0x842694: CheckStackOverflow
    //     0x842694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842698: cmp             SP, x16
    //     0x84269c: b.ls            #0x842740
    // 0x8426a0: LoadField: r3 = r1->field_f
    //     0x8426a0: ldur            w3, [x1, #0xf]
    // 0x8426a4: DecompressPointer r3
    //     0x8426a4: add             x3, x3, HEAP, lsl #32
    // 0x8426a8: stur            x3, [fp, #-0x18]
    // 0x8426ac: LoadField: r0 = r3->field_b
    //     0x8426ac: ldur            w0, [x3, #0xb]
    // 0x8426b0: r1 = LoadInt32Instr(r0)
    //     0x8426b0: sbfx            x1, x0, #1, #0x1f
    // 0x8426b4: stur            x1, [fp, #-0x10]
    // 0x8426b8: r4 = 0
    //     0x8426b8: mov             x4, #0
    // 0x8426bc: stur            x4, [fp, #-8]
    // 0x8426c0: CheckStackOverflow
    //     0x8426c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8426c4: cmp             SP, x16
    //     0x8426c8: b.ls            #0x842748
    // 0x8426cc: cmp             x4, x1
    // 0x8426d0: b.ge            #0x842730
    // 0x8426d4: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0x8426d4: add             x16, x3, x4, lsl #2
    //     0x8426d8: ldur            w0, [x16, #0xf]
    // 0x8426dc: DecompressPointer r0
    //     0x8426dc: add             x0, x0, HEAP, lsl #32
    // 0x8426e0: r5 = 60
    //     0x8426e0: mov             x5, #0x3c
    // 0x8426e4: branchIfSmi(r2, 0x8426f0)
    //     0x8426e4: tbz             w2, #0, #0x8426f0
    // 0x8426e8: r5 = LoadClassIdInstr(r2)
    //     0x8426e8: ldur            x5, [x2, #-1]
    //     0x8426ec: ubfx            x5, x5, #0xc, #0x14
    // 0x8426f0: stp             x0, x2, [SP]
    // 0x8426f4: mov             x0, x5
    // 0x8426f8: mov             lr, x0
    // 0x8426fc: ldr             lr, [x21, lr, lsl #3]
    // 0x842700: blr             lr
    // 0x842704: tbz             w0, #4, #0x842720
    // 0x842708: ldur            x0, [fp, #-8]
    // 0x84270c: add             x4, x0, #2
    // 0x842710: ldur            x2, [fp, #-0x20]
    // 0x842714: ldur            x3, [fp, #-0x18]
    // 0x842718: ldur            x1, [fp, #-0x10]
    // 0x84271c: b               #0x8426bc
    // 0x842720: ldur            x0, [fp, #-8]
    // 0x842724: LeaveFrame
    //     0x842724: mov             SP, fp
    //     0x842728: ldp             fp, lr, [SP], #0x10
    // 0x84272c: ret
    //     0x84272c: ret             
    // 0x842730: r0 = -1
    //     0x842730: mov             x0, #-1
    // 0x842734: LeaveFrame
    //     0x842734: mov             SP, fp
    //     0x842738: ldp             fp, lr, [SP], #0x10
    // 0x84273c: ret
    //     0x84273c: ret             
    // 0x842740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842740: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842744: b               #0x8426a0
    // 0x842748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84274c: b               #0x8426cc
  }
  _ get(/* No info */) {
    // ** addr: 0x12fb080, size: 0x88
    // 0x12fb080: EnterFrame
    //     0x12fb080: stp             fp, lr, [SP, #-0x10]!
    //     0x12fb084: mov             fp, SP
    // 0x12fb088: AllocStack(0x8)
    //     0x12fb088: sub             SP, SP, #8
    // 0x12fb08c: SetupParameters(_HashCollisionNode this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2 */)
    //     0x12fb08c: mov             x0, x2
    //     0x12fb090: mov             x2, x3
    //     0x12fb094: mov             x3, x1
    //     0x12fb098: stur            x1, [fp, #-8]
    // 0x12fb09c: CheckStackOverflow
    //     0x12fb09c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb0a0: cmp             SP, x16
    //     0x12fb0a4: b.ls            #0x12fb0fc
    // 0x12fb0a8: mov             x1, x3
    // 0x12fb0ac: r0 = _indexOf()
    //     0x12fb0ac: bl              #0x842684  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0x12fb0b0: tbz             x0, #0x3f, #0x12fb0bc
    // 0x12fb0b4: r0 = Null
    //     0x12fb0b4: mov             x0, NULL
    // 0x12fb0b8: b               #0x12fb0f0
    // 0x12fb0bc: ldur            x2, [fp, #-8]
    // 0x12fb0c0: LoadField: r3 = r2->field_f
    //     0x12fb0c0: ldur            w3, [x2, #0xf]
    // 0x12fb0c4: DecompressPointer r3
    //     0x12fb0c4: add             x3, x3, HEAP, lsl #32
    // 0x12fb0c8: add             x2, x0, #1
    // 0x12fb0cc: LoadField: r4 = r3->field_b
    //     0x12fb0cc: ldur            w4, [x3, #0xb]
    // 0x12fb0d0: r0 = LoadInt32Instr(r4)
    //     0x12fb0d0: sbfx            x0, x4, #1, #0x1f
    // 0x12fb0d4: mov             x1, x2
    // 0x12fb0d8: cmp             x1, x0
    // 0x12fb0dc: b.hs            #0x12fb104
    // 0x12fb0e0: ArrayLoad: r1 = r3[r2]  ; Unknown_4
    //     0x12fb0e0: add             x16, x3, x2, lsl #2
    //     0x12fb0e4: ldur            w1, [x16, #0xf]
    // 0x12fb0e8: DecompressPointer r1
    //     0x12fb0e8: add             x1, x1, HEAP, lsl #32
    // 0x12fb0ec: mov             x0, x1
    // 0x12fb0f0: LeaveFrame
    //     0x12fb0f0: mov             SP, fp
    //     0x12fb0f4: ldp             fp, lr, [SP], #0x10
    // 0x12fb0f8: ret
    //     0x12fb0f8: ret             
    // 0x12fb0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fb0fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fb100: b               #0x12fb0a8
    // 0x12fb104: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fb104: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  factory _ _HashCollisionNode.fromCollision(/* No info */) {
    // ** addr: 0x12fbff4, size: 0x7c
    // 0x12fbff4: EnterFrame
    //     0x12fbff4: stp             fp, lr, [SP, #-0x10]!
    //     0x12fbff8: mov             fp, SP
    // 0x12fbffc: AllocStack(0x30)
    //     0x12fbffc: sub             SP, SP, #0x30
    // 0x12fc000: SetupParameters(dynamic _ /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */, dynamic _ /* r7 => r7, fp-0x28 */)
    //     0x12fc000: mov             x4, x1
    //     0x12fc004: mov             x0, x2
    //     0x12fc008: stur            x2, [fp, #-8]
    //     0x12fc00c: stur            x3, [fp, #-0x10]
    //     0x12fc010: stur            x5, [fp, #-0x18]
    //     0x12fc014: stur            x6, [fp, #-0x20]
    //     0x12fc018: stur            x7, [fp, #-0x28]
    // 0x12fc01c: r1 = <Object?>
    //     0x12fc01c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fc020: r2 = 8
    //     0x12fc020: mov             x2, #8
    // 0x12fc024: r0 = AllocateArray()
    //     0x12fc024: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fc028: mov             x1, x0
    // 0x12fc02c: ldur            x0, [fp, #-0x10]
    // 0x12fc030: stur            x1, [fp, #-0x30]
    // 0x12fc034: StoreField: r1->field_f = r0
    //     0x12fc034: stur            w0, [x1, #0xf]
    // 0x12fc038: ldur            x0, [fp, #-0x18]
    // 0x12fc03c: StoreField: r1->field_13 = r0
    //     0x12fc03c: stur            w0, [x1, #0x13]
    // 0x12fc040: ldur            x0, [fp, #-0x20]
    // 0x12fc044: ArrayStore: r1[0] = r0  ; List_4
    //     0x12fc044: stur            w0, [x1, #0x17]
    // 0x12fc048: ldur            x0, [fp, #-0x28]
    // 0x12fc04c: StoreField: r1->field_1b = r0
    //     0x12fc04c: stur            w0, [x1, #0x1b]
    // 0x12fc050: r0 = _HashCollisionNode()
    //     0x12fc050: bl              #0x12fc070  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0x12fc054: ldur            x1, [fp, #-8]
    // 0x12fc058: StoreField: r0->field_7 = r1
    //     0x12fc058: stur            x1, [x0, #7]
    // 0x12fc05c: ldur            x1, [fp, #-0x30]
    // 0x12fc060: StoreField: r0->field_f = r1
    //     0x12fc060: stur            w1, [x0, #0xf]
    // 0x12fc064: LeaveFrame
    //     0x12fc064: mov             SP, fp
    //     0x12fc068: ldp             fp, lr, [SP], #0x10
    // 0x12fc06c: ret
    //     0x12fc06c: ret             
  }
  _ put(/* No info */) {
    // ** addr: 0x12fc07c, size: 0x310
    // 0x12fc07c: EnterFrame
    //     0x12fc07c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc080: mov             fp, SP
    // 0x12fc084: AllocStack(0x48)
    //     0x12fc084: sub             SP, SP, #0x48
    // 0x12fc088: SetupParameters(_HashCollisionNode this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x48 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r0, fp-0x20 */)
    //     0x12fc088: mov             x0, x6
    //     0x12fc08c: stur            x6, [fp, #-0x20]
    //     0x12fc090: mov             x6, x1
    //     0x12fc094: mov             x4, x2
    //     0x12fc098: stur            x1, [fp, #-8]
    //     0x12fc09c: stur            x3, [fp, #-0x10]
    //     0x12fc0a0: stur            x5, [fp, #-0x18]
    //     0x12fc0a4: stur            x2, [fp, #-0x48]
    // 0x12fc0a8: CheckStackOverflow
    //     0x12fc0a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc0ac: cmp             SP, x16
    //     0x12fc0b0: b.ls            #0x12fc370
    // 0x12fc0b4: LoadField: r1 = r6->field_7
    //     0x12fc0b4: ldur            x1, [x6, #7]
    // 0x12fc0b8: cmp             x5, x1
    // 0x12fc0bc: b.ne            #0x12fc330
    // 0x12fc0c0: mov             x1, x6
    // 0x12fc0c4: mov             x2, x3
    // 0x12fc0c8: r0 = _indexOf()
    //     0x12fc0c8: bl              #0x842684  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0x12fc0cc: cmn             x0, #1
    // 0x12fc0d0: b.eq            #0x12fc20c
    // 0x12fc0d4: ldur            x2, [fp, #-8]
    // 0x12fc0d8: LoadField: r3 = r2->field_f
    //     0x12fc0d8: ldur            w3, [x2, #0xf]
    // 0x12fc0dc: DecompressPointer r3
    //     0x12fc0dc: add             x3, x3, HEAP, lsl #32
    // 0x12fc0e0: stur            x3, [fp, #-0x40]
    // 0x12fc0e4: add             x4, x0, #1
    // 0x12fc0e8: stur            x4, [fp, #-0x38]
    // 0x12fc0ec: LoadField: r5 = r3->field_b
    //     0x12fc0ec: ldur            w5, [x3, #0xb]
    // 0x12fc0f0: stur            x5, [fp, #-0x30]
    // 0x12fc0f4: r6 = LoadInt32Instr(r5)
    //     0x12fc0f4: sbfx            x6, x5, #1, #0x1f
    // 0x12fc0f8: mov             x0, x6
    // 0x12fc0fc: mov             x1, x4
    // 0x12fc100: stur            x6, [fp, #-0x28]
    // 0x12fc104: cmp             x1, x0
    // 0x12fc108: b.hs            #0x12fc378
    // 0x12fc10c: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0x12fc10c: add             x16, x3, x4, lsl #2
    //     0x12fc110: ldur            w0, [x16, #0xf]
    // 0x12fc114: DecompressPointer r0
    //     0x12fc114: add             x0, x0, HEAP, lsl #32
    // 0x12fc118: ldur            x1, [fp, #-0x20]
    // 0x12fc11c: stp             x1, x0, [SP, #-0x10]!
    // 0x12fc120: r30 = OptimizedIdenticalWithNumberCheckStub
    //     0x12fc120: ldr             lr, [PP, #0x428]  ; [pp+0x428] Stub: OptimizedIdenticalWithNumberCheck (0x7d32ac)
    // 0x12fc124: LoadField: r30 = r30->field_7
    //     0x12fc124: ldur            lr, [lr, #7]
    // 0x12fc128: blr             lr
    // 0x12fc12c: ldp             x1, x0, [SP], #0x10
    // 0x12fc130: b.ne            #0x12fc13c
    // 0x12fc134: ldur            x0, [fp, #-8]
    // 0x12fc138: b               #0x12fc200
    // 0x12fc13c: ldur            x2, [fp, #-0x30]
    // 0x12fc140: r1 = <Object?>
    //     0x12fc140: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fc144: r0 = AllocateArray()
    //     0x12fc144: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fc148: mov             x2, x0
    // 0x12fc14c: stur            x2, [fp, #-0x30]
    // 0x12fc150: ldur            x3, [fp, #-0x40]
    // 0x12fc154: ldur            x4, [fp, #-0x28]
    // 0x12fc158: r5 = 0
    //     0x12fc158: mov             x5, #0
    // 0x12fc15c: CheckStackOverflow
    //     0x12fc15c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc160: cmp             SP, x16
    //     0x12fc164: b.ls            #0x12fc37c
    // 0x12fc168: cmp             x5, x4
    // 0x12fc16c: b.ge            #0x12fc1b4
    // 0x12fc170: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0x12fc170: add             x16, x3, x5, lsl #2
    //     0x12fc174: ldur            w0, [x16, #0xf]
    // 0x12fc178: DecompressPointer r0
    //     0x12fc178: add             x0, x0, HEAP, lsl #32
    // 0x12fc17c: mov             x1, x2
    // 0x12fc180: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12fc180: add             x25, x1, x5, lsl #2
    //     0x12fc184: add             x25, x25, #0xf
    //     0x12fc188: str             w0, [x25]
    //     0x12fc18c: tbz             w0, #0, #0x12fc1a8
    //     0x12fc190: ldurb           w16, [x1, #-1]
    //     0x12fc194: ldurb           w17, [x0, #-1]
    //     0x12fc198: and             x16, x17, x16, lsr #2
    //     0x12fc19c: tst             x16, HEAP, lsr #32
    //     0x12fc1a0: b.eq            #0x12fc1a8
    //     0x12fc1a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fc1a8: add             x0, x5, #1
    // 0x12fc1ac: mov             x5, x0
    // 0x12fc1b0: b               #0x12fc15c
    // 0x12fc1b4: ldur            x5, [fp, #-0x18]
    // 0x12fc1b8: ldur            x3, [fp, #-0x38]
    // 0x12fc1bc: mov             x1, x2
    // 0x12fc1c0: ldur            x0, [fp, #-0x20]
    // 0x12fc1c4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fc1c4: add             x25, x1, x3, lsl #2
    //     0x12fc1c8: add             x25, x25, #0xf
    //     0x12fc1cc: str             w0, [x25]
    //     0x12fc1d0: tbz             w0, #0, #0x12fc1ec
    //     0x12fc1d4: ldurb           w16, [x1, #-1]
    //     0x12fc1d8: ldurb           w17, [x0, #-1]
    //     0x12fc1dc: and             x16, x17, x16, lsr #2
    //     0x12fc1e0: tst             x16, HEAP, lsr #32
    //     0x12fc1e4: b.eq            #0x12fc1ec
    //     0x12fc1e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fc1ec: r0 = _HashCollisionNode()
    //     0x12fc1ec: bl              #0x12fc070  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0x12fc1f0: ldur            x5, [fp, #-0x18]
    // 0x12fc1f4: StoreField: r0->field_7 = r5
    //     0x12fc1f4: stur            x5, [x0, #7]
    // 0x12fc1f8: ldur            x1, [fp, #-0x30]
    // 0x12fc1fc: StoreField: r0->field_f = r1
    //     0x12fc1fc: stur            w1, [x0, #0xf]
    // 0x12fc200: LeaveFrame
    //     0x12fc200: mov             SP, fp
    //     0x12fc204: ldp             fp, lr, [SP], #0x10
    // 0x12fc208: ret
    //     0x12fc208: ret             
    // 0x12fc20c: ldur            x0, [fp, #-8]
    // 0x12fc210: ldur            x5, [fp, #-0x18]
    // 0x12fc214: LoadField: r3 = r0->field_f
    //     0x12fc214: ldur            w3, [x0, #0xf]
    // 0x12fc218: DecompressPointer r3
    //     0x12fc218: add             x3, x3, HEAP, lsl #32
    // 0x12fc21c: stur            x3, [fp, #-0x30]
    // 0x12fc220: LoadField: r0 = r3->field_b
    //     0x12fc220: ldur            w0, [x3, #0xb]
    // 0x12fc224: r4 = LoadInt32Instr(r0)
    //     0x12fc224: sbfx            x4, x0, #1, #0x1f
    // 0x12fc228: stur            x4, [fp, #-0x28]
    // 0x12fc22c: add             x0, x4, #2
    // 0x12fc230: lsl             x2, x0, #1
    // 0x12fc234: r1 = <Object?>
    //     0x12fc234: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fc238: r0 = AllocateArray()
    //     0x12fc238: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fc23c: mov             x2, x0
    // 0x12fc240: stur            x2, [fp, #-0x40]
    // 0x12fc244: ldur            x3, [fp, #-0x30]
    // 0x12fc248: ldur            x4, [fp, #-0x28]
    // 0x12fc24c: r5 = 0
    //     0x12fc24c: mov             x5, #0
    // 0x12fc250: CheckStackOverflow
    //     0x12fc250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fc254: cmp             SP, x16
    //     0x12fc258: b.ls            #0x12fc384
    // 0x12fc25c: cmp             x5, x4
    // 0x12fc260: b.ge            #0x12fc2a8
    // 0x12fc264: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0x12fc264: add             x16, x3, x5, lsl #2
    //     0x12fc268: ldur            w0, [x16, #0xf]
    // 0x12fc26c: DecompressPointer r0
    //     0x12fc26c: add             x0, x0, HEAP, lsl #32
    // 0x12fc270: mov             x1, x2
    // 0x12fc274: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12fc274: add             x25, x1, x5, lsl #2
    //     0x12fc278: add             x25, x25, #0xf
    //     0x12fc27c: str             w0, [x25]
    //     0x12fc280: tbz             w0, #0, #0x12fc29c
    //     0x12fc284: ldurb           w16, [x1, #-1]
    //     0x12fc288: ldurb           w17, [x0, #-1]
    //     0x12fc28c: and             x16, x17, x16, lsr #2
    //     0x12fc290: tst             x16, HEAP, lsr #32
    //     0x12fc294: b.eq            #0x12fc29c
    //     0x12fc298: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fc29c: add             x0, x5, #1
    // 0x12fc2a0: mov             x5, x0
    // 0x12fc2a4: b               #0x12fc250
    // 0x12fc2a8: ldur            x5, [fp, #-0x18]
    // 0x12fc2ac: mov             x1, x2
    // 0x12fc2b0: ldur            x0, [fp, #-0x10]
    // 0x12fc2b4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x12fc2b4: add             x25, x1, x4, lsl #2
    //     0x12fc2b8: add             x25, x25, #0xf
    //     0x12fc2bc: str             w0, [x25]
    //     0x12fc2c0: tbz             w0, #0, #0x12fc2dc
    //     0x12fc2c4: ldurb           w16, [x1, #-1]
    //     0x12fc2c8: ldurb           w17, [x0, #-1]
    //     0x12fc2cc: and             x16, x17, x16, lsr #2
    //     0x12fc2d0: tst             x16, HEAP, lsr #32
    //     0x12fc2d4: b.eq            #0x12fc2dc
    //     0x12fc2d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fc2dc: add             x3, x4, #1
    // 0x12fc2e0: mov             x1, x2
    // 0x12fc2e4: ldur            x0, [fp, #-0x20]
    // 0x12fc2e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fc2e8: add             x25, x1, x3, lsl #2
    //     0x12fc2ec: add             x25, x25, #0xf
    //     0x12fc2f0: str             w0, [x25]
    //     0x12fc2f4: tbz             w0, #0, #0x12fc310
    //     0x12fc2f8: ldurb           w16, [x1, #-1]
    //     0x12fc2fc: ldurb           w17, [x0, #-1]
    //     0x12fc300: and             x16, x17, x16, lsr #2
    //     0x12fc304: tst             x16, HEAP, lsr #32
    //     0x12fc308: b.eq            #0x12fc310
    //     0x12fc30c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fc310: r0 = _HashCollisionNode()
    //     0x12fc310: bl              #0x12fc070  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0x12fc314: ldur            x6, [fp, #-0x18]
    // 0x12fc318: StoreField: r0->field_7 = r6
    //     0x12fc318: stur            x6, [x0, #7]
    // 0x12fc31c: ldur            x1, [fp, #-0x40]
    // 0x12fc320: StoreField: r0->field_f = r1
    //     0x12fc320: stur            w1, [x0, #0xf]
    // 0x12fc324: LeaveFrame
    //     0x12fc324: mov             SP, fp
    //     0x12fc328: ldp             fp, lr, [SP], #0x10
    // 0x12fc32c: ret
    //     0x12fc32c: ret             
    // 0x12fc330: mov             x0, x6
    // 0x12fc334: mov             x6, x5
    // 0x12fc338: mov             x2, x4
    // 0x12fc33c: mov             x3, x1
    // 0x12fc340: mov             x5, x0
    // 0x12fc344: r1 = Null
    //     0x12fc344: mov             x1, NULL
    // 0x12fc348: r0 = _CompressedNode.single()
    //     0x12fc348: bl              #0x12fc38c  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_CompressedNode.single
    // 0x12fc34c: mov             x1, x0
    // 0x12fc350: ldur            x2, [fp, #-0x48]
    // 0x12fc354: ldur            x3, [fp, #-0x10]
    // 0x12fc358: ldur            x5, [fp, #-0x18]
    // 0x12fc35c: ldur            x6, [fp, #-0x20]
    // 0x12fc360: r0 = put()
    //     0x12fc360: bl              #0x12fb368  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0x12fc364: LeaveFrame
    //     0x12fc364: mov             SP, fp
    //     0x12fc368: ldp             fp, lr, [SP], #0x10
    // 0x12fc36c: ret
    //     0x12fc36c: ret             
    // 0x12fc370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fc370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fc374: b               #0x12fc0b4
    // 0x12fc378: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fc378: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fc37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fc37c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fc380: b               #0x12fc168
    // 0x12fc384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fc384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fc388: b               #0x12fc25c
  }
}

// class id: 3192, size: 0x14, field offset: 0x8
class _CompressedNode extends _TrieNode {

  static late final _CompressedNode empty; // offset: 0xbdc
  static late final List<Object?> _emptyArray; // offset: 0xbe0

  static _CompressedNode empty() {
    // ** addr: 0x1108c5c, size: 0x60
    // 0x1108c5c: EnterFrame
    //     0x1108c5c: stp             fp, lr, [SP, #-0x10]!
    //     0x1108c60: mov             fp, SP
    // 0x1108c64: AllocStack(0x8)
    //     0x1108c64: sub             SP, SP, #8
    // 0x1108c68: CheckStackOverflow
    //     0x1108c68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1108c6c: cmp             SP, x16
    //     0x1108c70: b.ls            #0x1108cb4
    // 0x1108c74: r0 = LoadStaticField(0xbe0)
    //     0x1108c74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1108c78: ldr             x0, [x0, #0x17c0]
    // 0x1108c7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1108c80: cmp             w0, w16
    // 0x1108c84: b.ne            #0x1108c94
    // 0x1108c88: r2 = _emptyArray
    //     0x1108c88: add             x2, PP, #0x85, lsl #12  ; [pp+0x85608] Field <_CompressedNode@596137193._emptyArray@596137193>: static late final (offset: 0xbe0)
    //     0x1108c8c: ldr             x2, [x2, #0x608]
    // 0x1108c90: r0 = InitLateFinalStaticField()
    //     0x1108c90: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x1108c94: stur            x0, [fp, #-8]
    // 0x1108c98: r0 = _CompressedNode()
    //     0x1108c98: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x1108c9c: StoreField: r0->field_7 = rZR
    //     0x1108c9c: stur            xzr, [x0, #7]
    // 0x1108ca0: ldur            x1, [fp, #-8]
    // 0x1108ca4: StoreField: r0->field_f = r1
    //     0x1108ca4: stur            w1, [x0, #0xf]
    // 0x1108ca8: LeaveFrame
    //     0x1108ca8: mov             SP, fp
    //     0x1108cac: ldp             fp, lr, [SP], #0x10
    // 0x1108cb0: ret
    //     0x1108cb0: ret             
    // 0x1108cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1108cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1108cb8: b               #0x1108c74
  }
  static List<Object?> _emptyArray() {
    // ** addr: 0x1108cc8, size: 0x20
    // 0x1108cc8: EnterFrame
    //     0x1108cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x1108ccc: mov             fp, SP
    // 0x1108cd0: r1 = <Object?>
    //     0x1108cd0: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1108cd4: r2 = 0
    //     0x1108cd4: mov             x2, #0
    // 0x1108cd8: r0 = AllocateArray()
    //     0x1108cd8: bl              #0x13df928  ; AllocateArrayStub
    // 0x1108cdc: LeaveFrame
    //     0x1108cdc: mov             SP, fp
    //     0x1108ce0: ldp             fp, lr, [SP], #0x10
    // 0x1108ce4: ret
    //     0x1108ce4: ret             
  }
  _ get(/* No info */) {
    // ** addr: 0x12fae5c, size: 0x224
    // 0x12fae5c: EnterFrame
    //     0x12fae5c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fae60: mov             fp, SP
    // 0x12fae64: AllocStack(0x30)
    //     0x12fae64: sub             SP, SP, #0x30
    // 0x12fae68: r0 = 1
    //     0x12fae68: mov             x0, #1
    // 0x12fae6c: mov             x4, x2
    // 0x12fae70: stur            x2, [fp, #-0x10]
    // 0x12fae74: stur            x3, [fp, #-0x18]
    // 0x12fae78: stur            x5, [fp, #-0x20]
    // 0x12fae7c: CheckStackOverflow
    //     0x12fae7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fae80: cmp             SP, x16
    //     0x12fae84: b.ls            #0x12fb040
    // 0x12fae88: cmp             x4, #0x3f
    // 0x12fae8c: b.hi            #0x12fb048
    // 0x12fae90: lsr             x2, x5, x4
    // 0x12fae94: ubfx            x2, x2, #0, #0x20
    // 0x12fae98: and             w6, w2, #0x1f
    // 0x12fae9c: ubfx            x6, x6, #0, #0x20
    // 0x12faea0: lsl             x2, x0, x6
    // 0x12faea4: LoadField: r0 = r1->field_7
    //     0x12faea4: ldur            x0, [x1, #7]
    // 0x12faea8: tst             x0, x2
    // 0x12faeac: b.ne            #0x12faec0
    // 0x12faeb0: r0 = Null
    //     0x12faeb0: mov             x0, NULL
    // 0x12faeb4: LeaveFrame
    //     0x12faeb4: mov             SP, fp
    //     0x12faeb8: ldp             fp, lr, [SP], #0x10
    // 0x12faebc: ret
    //     0x12faebc: ret             
    // 0x12faec0: ubfx            x2, x2, #0, #0x20
    // 0x12faec4: sub             w6, w2, #1
    // 0x12faec8: ubfx            x0, x0, #0, #0x20
    // 0x12faecc: and             x2, x0, x6
    // 0x12faed0: lsr             w0, w2, #1
    // 0x12faed4: and             w6, w0, #0x55555555
    // 0x12faed8: ubfx            x2, x2, #0, #0x20
    // 0x12faedc: ubfx            x6, x6, #0, #0x20
    // 0x12faee0: sub             x0, x2, x6
    // 0x12faee4: mov             x2, x0
    // 0x12faee8: ubfx            x2, x2, #0, #0x20
    // 0x12faeec: and             w6, w2, #0x33333333
    // 0x12faef0: lsr             x2, x0, #2
    // 0x12faef4: ubfx            x2, x2, #0, #0x20
    // 0x12faef8: and             w0, w2, #0x33333333
    // 0x12faefc: add             w2, w6, w0
    // 0x12faf00: lsr             w0, w2, #4
    // 0x12faf04: add             w6, w2, w0
    // 0x12faf08: and             w0, w6, #0xf0f0f0f
    // 0x12faf0c: lsr             w2, w0, #8
    // 0x12faf10: add             w6, w0, w2
    // 0x12faf14: lsr             w0, w6, #0x10
    // 0x12faf18: add             w2, w6, w0
    // 0x12faf1c: and             w0, w2, #0x3f
    // 0x12faf20: LoadField: r2 = r1->field_f
    //     0x12faf20: ldur            w2, [x1, #0xf]
    // 0x12faf24: DecompressPointer r2
    //     0x12faf24: add             x2, x2, HEAP, lsl #32
    // 0x12faf28: ubfx            x0, x0, #0, #0x20
    // 0x12faf2c: lsl             x6, x0, #1
    // 0x12faf30: LoadField: r0 = r2->field_b
    //     0x12faf30: ldur            w0, [x2, #0xb]
    // 0x12faf34: r7 = LoadInt32Instr(r0)
    //     0x12faf34: sbfx            x7, x0, #1, #0x1f
    // 0x12faf38: mov             x0, x7
    // 0x12faf3c: mov             x1, x6
    // 0x12faf40: cmp             x1, x0
    // 0x12faf44: b.hs            #0x12fb078
    // 0x12faf48: ArrayLoad: r8 = r2[r6]  ; Unknown_4
    //     0x12faf48: add             x16, x2, x6, lsl #2
    //     0x12faf4c: ldur            w8, [x16, #0xf]
    // 0x12faf50: DecompressPointer r8
    //     0x12faf50: add             x8, x8, HEAP, lsl #32
    // 0x12faf54: add             x9, x6, #1
    // 0x12faf58: mov             x0, x7
    // 0x12faf5c: mov             x1, x9
    // 0x12faf60: cmp             x1, x0
    // 0x12faf64: b.hs            #0x12fb07c
    // 0x12faf68: ArrayLoad: r6 = r2[r9]  ; Unknown_4
    //     0x12faf68: add             x16, x2, x9, lsl #2
    //     0x12faf6c: ldur            w6, [x16, #0xf]
    // 0x12faf70: DecompressPointer r6
    //     0x12faf70: add             x6, x6, HEAP, lsl #32
    // 0x12faf74: stur            x6, [fp, #-8]
    // 0x12faf78: cmp             w8, NULL
    // 0x12faf7c: b.ne            #0x12faff0
    // 0x12faf80: mov             x0, x6
    // 0x12faf84: r2 = Null
    //     0x12faf84: mov             x2, NULL
    // 0x12faf88: r1 = Null
    //     0x12faf88: mov             x1, NULL
    // 0x12faf8c: r4 = 60
    //     0x12faf8c: mov             x4, #0x3c
    // 0x12faf90: branchIfSmi(r0, 0x12faf9c)
    //     0x12faf90: tbz             w0, #0, #0x12faf9c
    // 0x12faf94: r4 = LoadClassIdInstr(r0)
    //     0x12faf94: ldur            x4, [x0, #-1]
    //     0x12faf98: ubfx            x4, x4, #0xc, #0x14
    // 0x12faf9c: sub             x4, x4, #0xc77
    // 0x12fafa0: cmp             x4, #2
    // 0x12fafa4: b.ls            #0x12fafbc
    // 0x12fafa8: r8 = _TrieNode
    //     0x12fafa8: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce68] Type: _TrieNode
    //     0x12fafac: ldr             x8, [x8, #0xe68]
    // 0x12fafb0: r3 = Null
    //     0x12fafb0: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ce70] Null
    //     0x12fafb4: ldr             x3, [x3, #0xe70]
    // 0x12fafb8: r0 = DefaultTypeTest()
    //     0x12fafb8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12fafbc: ldur            x0, [fp, #-0x10]
    // 0x12fafc0: add             x2, x0, #5
    // 0x12fafc4: ldur            x1, [fp, #-8]
    // 0x12fafc8: r0 = LoadClassIdInstr(r1)
    //     0x12fafc8: ldur            x0, [x1, #-1]
    //     0x12fafcc: ubfx            x0, x0, #0xc, #0x14
    // 0x12fafd0: ldur            x3, [fp, #-0x18]
    // 0x12fafd4: ldur            x5, [fp, #-0x20]
    // 0x12fafd8: r0 = GDT[cid_x0 + -0xffd]()
    //     0x12fafd8: sub             lr, x0, #0xffd
    //     0x12fafdc: ldr             lr, [x21, lr, lsl #3]
    //     0x12fafe0: blr             lr
    // 0x12fafe4: LeaveFrame
    //     0x12fafe4: mov             SP, fp
    //     0x12fafe8: ldp             fp, lr, [SP], #0x10
    // 0x12fafec: ret
    //     0x12fafec: ret             
    // 0x12faff0: mov             x0, x3
    // 0x12faff4: mov             x1, x6
    // 0x12faff8: r2 = 60
    //     0x12faff8: mov             x2, #0x3c
    // 0x12faffc: branchIfSmi(r0, 0x12fb008)
    //     0x12faffc: tbz             w0, #0, #0x12fb008
    // 0x12fb000: r2 = LoadClassIdInstr(r0)
    //     0x12fb000: ldur            x2, [x0, #-1]
    //     0x12fb004: ubfx            x2, x2, #0xc, #0x14
    // 0x12fb008: stp             x8, x0, [SP]
    // 0x12fb00c: mov             x0, x2
    // 0x12fb010: mov             lr, x0
    // 0x12fb014: ldr             lr, [x21, lr, lsl #3]
    // 0x12fb018: blr             lr
    // 0x12fb01c: tbnz            w0, #4, #0x12fb030
    // 0x12fb020: ldur            x0, [fp, #-8]
    // 0x12fb024: LeaveFrame
    //     0x12fb024: mov             SP, fp
    //     0x12fb028: ldp             fp, lr, [SP], #0x10
    // 0x12fb02c: ret
    //     0x12fb02c: ret             
    // 0x12fb030: r0 = Null
    //     0x12fb030: mov             x0, NULL
    // 0x12fb034: LeaveFrame
    //     0x12fb034: mov             SP, fp
    //     0x12fb038: ldp             fp, lr, [SP], #0x10
    // 0x12fb03c: ret
    //     0x12fb03c: ret             
    // 0x12fb040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fb040: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fb044: b               #0x12fae88
    // 0x12fb048: tbnz            x4, #0x3f, #0x12fb054
    // 0x12fb04c: mov             x2, xzr
    // 0x12fb050: b               #0x12fae94
    // 0x12fb054: str             x4, [THR, #0x8a0]  ; THR::
    // 0x12fb058: stp             x4, x5, [SP, #-0x10]!
    // 0x12fb05c: stp             x1, x3, [SP, #-0x10]!
    // 0x12fb060: SaveReg r0
    //     0x12fb060: str             x0, [SP, #-8]!
    // 0x12fb064: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fb068: r4 = 0
    //     0x12fb068: mov             x4, #0
    // 0x12fb06c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fb070: blr             lr
    // 0x12fb074: brk             #0
    // 0x12fb078: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fb078: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fb07c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fb07c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ put(/* No info */) {
    // ** addr: 0x12fb368, size: 0x8c0
    // 0x12fb368: EnterFrame
    //     0x12fb368: stp             fp, lr, [SP, #-0x10]!
    //     0x12fb36c: mov             fp, SP
    // 0x12fb370: AllocStack(0x98)
    //     0x12fb370: sub             SP, SP, #0x98
    // 0x12fb374: r0 = 1
    //     0x12fb374: mov             x0, #1
    // 0x12fb378: mov             x7, x1
    // 0x12fb37c: mov             x4, x2
    // 0x12fb380: stur            x1, [fp, #-0x38]
    // 0x12fb384: stur            x2, [fp, #-0x40]
    // 0x12fb388: stur            x3, [fp, #-0x48]
    // 0x12fb38c: stur            x5, [fp, #-0x50]
    // 0x12fb390: stur            x6, [fp, #-0x58]
    // 0x12fb394: CheckStackOverflow
    //     0x12fb394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb398: cmp             SP, x16
    //     0x12fb39c: b.ls            #0x12fbba4
    // 0x12fb3a0: cmp             x4, #0x3f
    // 0x12fb3a4: b.hi            #0x12fbbac
    // 0x12fb3a8: lsr             x1, x5, x4
    // 0x12fb3ac: ubfx            x1, x1, #0, #0x20
    // 0x12fb3b0: and             w8, w1, #0x1f
    // 0x12fb3b4: stur            x8, [fp, #-0x80]
    // 0x12fb3b8: mov             x1, x8
    // 0x12fb3bc: ubfx            x1, x1, #0, #0x20
    // 0x12fb3c0: lsl             x9, x0, x1
    // 0x12fb3c4: stur            x9, [fp, #-0x88]
    // 0x12fb3c8: LoadField: r10 = r7->field_7
    //     0x12fb3c8: ldur            x10, [x7, #7]
    // 0x12fb3cc: stur            x10, [fp, #-0x30]
    // 0x12fb3d0: mov             x0, x9
    // 0x12fb3d4: ubfx            x0, x0, #0, #0x20
    // 0x12fb3d8: sub             w1, w0, #1
    // 0x12fb3dc: mov             x0, x10
    // 0x12fb3e0: ubfx            x0, x0, #0, #0x20
    // 0x12fb3e4: and             x2, x0, x1
    // 0x12fb3e8: lsr             w0, w2, #1
    // 0x12fb3ec: and             w1, w0, #0x55555555
    // 0x12fb3f0: ubfx            x2, x2, #0, #0x20
    // 0x12fb3f4: ubfx            x1, x1, #0, #0x20
    // 0x12fb3f8: sub             x0, x2, x1
    // 0x12fb3fc: mov             x1, x0
    // 0x12fb400: ubfx            x1, x1, #0, #0x20
    // 0x12fb404: and             w2, w1, #0x33333333
    // 0x12fb408: lsr             x1, x0, #2
    // 0x12fb40c: ubfx            x1, x1, #0, #0x20
    // 0x12fb410: and             w0, w1, #0x33333333
    // 0x12fb414: add             w1, w2, w0
    // 0x12fb418: lsr             w0, w1, #4
    // 0x12fb41c: add             w2, w1, w0
    // 0x12fb420: and             w0, w2, #0xf0f0f0f
    // 0x12fb424: lsr             w1, w0, #8
    // 0x12fb428: add             w2, w0, w1
    // 0x12fb42c: lsr             w0, w2, #0x10
    // 0x12fb430: add             w1, w2, w0
    // 0x12fb434: and             w0, w1, #0x3f
    // 0x12fb438: tst             x10, x9
    // 0x12fb43c: b.eq            #0x12fb864
    // 0x12fb440: LoadField: r8 = r7->field_f
    //     0x12fb440: ldur            w8, [x7, #0xf]
    // 0x12fb444: DecompressPointer r8
    //     0x12fb444: add             x8, x8, HEAP, lsl #32
    // 0x12fb448: stur            x8, [fp, #-0x28]
    // 0x12fb44c: ubfx            x0, x0, #0, #0x20
    // 0x12fb450: lsl             x2, x0, #1
    // 0x12fb454: stur            x2, [fp, #-0x78]
    // 0x12fb458: LoadField: r9 = r8->field_b
    //     0x12fb458: ldur            w9, [x8, #0xb]
    // 0x12fb45c: stur            x9, [fp, #-0x20]
    // 0x12fb460: r11 = LoadInt32Instr(r9)
    //     0x12fb460: sbfx            x11, x9, #1, #0x1f
    // 0x12fb464: mov             x0, x11
    // 0x12fb468: mov             x1, x2
    // 0x12fb46c: stur            x11, [fp, #-0x18]
    // 0x12fb470: cmp             x1, x0
    // 0x12fb474: b.hs            #0x12fbbdc
    // 0x12fb478: ArrayLoad: r12 = r8[r2]  ; Unknown_4
    //     0x12fb478: add             x16, x8, x2, lsl #2
    //     0x12fb47c: ldur            w12, [x16, #0xf]
    // 0x12fb480: DecompressPointer r12
    //     0x12fb480: add             x12, x12, HEAP, lsl #32
    // 0x12fb484: stur            x12, [fp, #-0x70]
    // 0x12fb488: add             x13, x2, #1
    // 0x12fb48c: mov             x0, x11
    // 0x12fb490: mov             x1, x13
    // 0x12fb494: stur            x13, [fp, #-0x10]
    // 0x12fb498: cmp             x1, x0
    // 0x12fb49c: b.hs            #0x12fbbe0
    // 0x12fb4a0: ArrayLoad: r14 = r8[r13]  ; Unknown_4
    //     0x12fb4a0: add             x16, x8, x13, lsl #2
    //     0x12fb4a4: ldur            w14, [x16, #0xf]
    // 0x12fb4a8: DecompressPointer r14
    //     0x12fb4a8: add             x14, x14, HEAP, lsl #32
    // 0x12fb4ac: stur            x14, [fp, #-8]
    // 0x12fb4b0: cmp             w12, NULL
    // 0x12fb4b4: b.ne            #0x12fb614
    // 0x12fb4b8: mov             x0, x14
    // 0x12fb4bc: r2 = Null
    //     0x12fb4bc: mov             x2, NULL
    // 0x12fb4c0: r1 = Null
    //     0x12fb4c0: mov             x1, NULL
    // 0x12fb4c4: r4 = 60
    //     0x12fb4c4: mov             x4, #0x3c
    // 0x12fb4c8: branchIfSmi(r0, 0x12fb4d4)
    //     0x12fb4c8: tbz             w0, #0, #0x12fb4d4
    // 0x12fb4cc: r4 = LoadClassIdInstr(r0)
    //     0x12fb4cc: ldur            x4, [x0, #-1]
    //     0x12fb4d0: ubfx            x4, x4, #0xc, #0x14
    // 0x12fb4d4: sub             x4, x4, #0xc77
    // 0x12fb4d8: cmp             x4, #2
    // 0x12fb4dc: b.ls            #0x12fb4f4
    // 0x12fb4e0: r8 = _TrieNode
    //     0x12fb4e0: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce68] Type: _TrieNode
    //     0x12fb4e4: ldr             x8, [x8, #0xe68]
    // 0x12fb4e8: r3 = Null
    //     0x12fb4e8: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ce80] Null
    //     0x12fb4ec: ldr             x3, [x3, #0xe80]
    // 0x12fb4f0: r0 = DefaultTypeTest()
    //     0x12fb4f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12fb4f4: ldur            x1, [fp, #-0x40]
    // 0x12fb4f8: add             x2, x1, #5
    // 0x12fb4fc: ldur            x4, [fp, #-8]
    // 0x12fb500: r0 = LoadClassIdInstr(r4)
    //     0x12fb500: ldur            x0, [x4, #-1]
    //     0x12fb504: ubfx            x0, x0, #0xc, #0x14
    // 0x12fb508: mov             x1, x4
    // 0x12fb50c: ldur            x3, [fp, #-0x48]
    // 0x12fb510: ldur            x5, [fp, #-0x50]
    // 0x12fb514: ldur            x6, [fp, #-0x58]
    // 0x12fb518: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12fb518: sub             lr, x0, #1, lsl #12
    //     0x12fb51c: ldr             lr, [x21, lr, lsl #3]
    //     0x12fb520: blr             lr
    // 0x12fb524: ldur            x3, [fp, #-8]
    // 0x12fb528: stur            x0, [fp, #-0x60]
    // 0x12fb52c: cmp             w0, w3
    // 0x12fb530: b.ne            #0x12fb544
    // 0x12fb534: ldur            x0, [fp, #-0x38]
    // 0x12fb538: LeaveFrame
    //     0x12fb538: mov             SP, fp
    //     0x12fb53c: ldp             fp, lr, [SP], #0x10
    // 0x12fb540: ret
    //     0x12fb540: ret             
    // 0x12fb544: ldur            x2, [fp, #-0x20]
    // 0x12fb548: r1 = <Object?>
    //     0x12fb548: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fb54c: r0 = AllocateArray()
    //     0x12fb54c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fb550: mov             x2, x0
    // 0x12fb554: stur            x2, [fp, #-0x68]
    // 0x12fb558: ldur            x4, [fp, #-0x28]
    // 0x12fb55c: ldur            x5, [fp, #-0x18]
    // 0x12fb560: r3 = 0
    //     0x12fb560: mov             x3, #0
    // 0x12fb564: CheckStackOverflow
    //     0x12fb564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb568: cmp             SP, x16
    //     0x12fb56c: b.ls            #0x12fbbe4
    // 0x12fb570: cmp             x3, x5
    // 0x12fb574: b.ge            #0x12fb5bc
    // 0x12fb578: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0x12fb578: add             x16, x4, x3, lsl #2
    //     0x12fb57c: ldur            w0, [x16, #0xf]
    // 0x12fb580: DecompressPointer r0
    //     0x12fb580: add             x0, x0, HEAP, lsl #32
    // 0x12fb584: mov             x1, x2
    // 0x12fb588: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fb588: add             x25, x1, x3, lsl #2
    //     0x12fb58c: add             x25, x25, #0xf
    //     0x12fb590: str             w0, [x25]
    //     0x12fb594: tbz             w0, #0, #0x12fb5b0
    //     0x12fb598: ldurb           w16, [x1, #-1]
    //     0x12fb59c: ldurb           w17, [x0, #-1]
    //     0x12fb5a0: and             x16, x17, x16, lsr #2
    //     0x12fb5a4: tst             x16, HEAP, lsr #32
    //     0x12fb5a8: b.eq            #0x12fb5b0
    //     0x12fb5ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb5b0: add             x0, x3, #1
    // 0x12fb5b4: mov             x3, x0
    // 0x12fb5b8: b               #0x12fb564
    // 0x12fb5bc: ldur            x6, [fp, #-0x10]
    // 0x12fb5c0: ldur            x3, [fp, #-0x30]
    // 0x12fb5c4: mov             x1, x2
    // 0x12fb5c8: ldur            x0, [fp, #-0x60]
    // 0x12fb5cc: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12fb5cc: add             x25, x1, x6, lsl #2
    //     0x12fb5d0: add             x25, x25, #0xf
    //     0x12fb5d4: str             w0, [x25]
    //     0x12fb5d8: tbz             w0, #0, #0x12fb5f4
    //     0x12fb5dc: ldurb           w16, [x1, #-1]
    //     0x12fb5e0: ldurb           w17, [x0, #-1]
    //     0x12fb5e4: and             x16, x17, x16, lsr #2
    //     0x12fb5e8: tst             x16, HEAP, lsr #32
    //     0x12fb5ec: b.eq            #0x12fb5f4
    //     0x12fb5f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb5f4: r0 = _CompressedNode()
    //     0x12fb5f4: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x12fb5f8: ldur            x7, [fp, #-0x30]
    // 0x12fb5fc: StoreField: r0->field_7 = r7
    //     0x12fb5fc: stur            x7, [x0, #7]
    // 0x12fb600: ldur            x1, [fp, #-0x68]
    // 0x12fb604: StoreField: r0->field_f = r1
    //     0x12fb604: stur            w1, [x0, #0xf]
    // 0x12fb608: LeaveFrame
    //     0x12fb608: mov             SP, fp
    //     0x12fb60c: ldp             fp, lr, [SP], #0x10
    // 0x12fb610: ret
    //     0x12fb610: ret             
    // 0x12fb614: mov             x1, x4
    // 0x12fb618: mov             x4, x8
    // 0x12fb61c: mov             x8, x3
    // 0x12fb620: mov             x6, x13
    // 0x12fb624: mov             x7, x10
    // 0x12fb628: mov             x5, x11
    // 0x12fb62c: mov             x3, x14
    // 0x12fb630: r0 = 60
    //     0x12fb630: mov             x0, #0x3c
    // 0x12fb634: branchIfSmi(r8, 0x12fb640)
    //     0x12fb634: tbz             w8, #0, #0x12fb640
    // 0x12fb638: r0 = LoadClassIdInstr(r8)
    //     0x12fb638: ldur            x0, [x8, #-1]
    //     0x12fb63c: ubfx            x0, x0, #0xc, #0x14
    // 0x12fb640: stp             x12, x8, [SP]
    // 0x12fb644: mov             lr, x0
    // 0x12fb648: ldr             lr, [x21, lr, lsl #3]
    // 0x12fb64c: blr             lr
    // 0x12fb650: tbnz            w0, #4, #0x12fb754
    // 0x12fb654: ldur            x0, [fp, #-0x58]
    // 0x12fb658: ldur            x1, [fp, #-8]
    // 0x12fb65c: stp             x1, x0, [SP, #-0x10]!
    // 0x12fb660: r30 = OptimizedIdenticalWithNumberCheckStub
    //     0x12fb660: ldr             lr, [PP, #0x428]  ; [pp+0x428] Stub: OptimizedIdenticalWithNumberCheck (0x7d32ac)
    // 0x12fb664: LoadField: r30 = r30->field_7
    //     0x12fb664: ldur            lr, [lr, #7]
    // 0x12fb668: blr             lr
    // 0x12fb66c: ldp             x1, x0, [SP], #0x10
    // 0x12fb670: b.ne            #0x12fb67c
    // 0x12fb674: ldur            x0, [fp, #-0x38]
    // 0x12fb678: b               #0x12fb748
    // 0x12fb67c: ldur            x2, [fp, #-0x20]
    // 0x12fb680: r1 = <Object?>
    //     0x12fb680: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fb684: r0 = AllocateArray()
    //     0x12fb684: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fb688: mov             x2, x0
    // 0x12fb68c: stur            x2, [fp, #-0x60]
    // 0x12fb690: ldur            x4, [fp, #-0x28]
    // 0x12fb694: ldur            x8, [fp, #-0x18]
    // 0x12fb698: r3 = 0
    //     0x12fb698: mov             x3, #0
    // 0x12fb69c: CheckStackOverflow
    //     0x12fb69c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb6a0: cmp             SP, x16
    //     0x12fb6a4: b.ls            #0x12fbbec
    // 0x12fb6a8: cmp             x3, x8
    // 0x12fb6ac: b.ge            #0x12fb6f4
    // 0x12fb6b0: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0x12fb6b0: add             x16, x4, x3, lsl #2
    //     0x12fb6b4: ldur            w0, [x16, #0xf]
    // 0x12fb6b8: DecompressPointer r0
    //     0x12fb6b8: add             x0, x0, HEAP, lsl #32
    // 0x12fb6bc: mov             x1, x2
    // 0x12fb6c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fb6c0: add             x25, x1, x3, lsl #2
    //     0x12fb6c4: add             x25, x25, #0xf
    //     0x12fb6c8: str             w0, [x25]
    //     0x12fb6cc: tbz             w0, #0, #0x12fb6e8
    //     0x12fb6d0: ldurb           w16, [x1, #-1]
    //     0x12fb6d4: ldurb           w17, [x0, #-1]
    //     0x12fb6d8: and             x16, x17, x16, lsr #2
    //     0x12fb6dc: tst             x16, HEAP, lsr #32
    //     0x12fb6e0: b.eq            #0x12fb6e8
    //     0x12fb6e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb6e8: add             x0, x3, #1
    // 0x12fb6ec: mov             x3, x0
    // 0x12fb6f0: b               #0x12fb69c
    // 0x12fb6f4: ldur            x9, [fp, #-0x10]
    // 0x12fb6f8: ldur            x3, [fp, #-0x30]
    // 0x12fb6fc: mov             x1, x2
    // 0x12fb700: ldur            x0, [fp, #-0x58]
    // 0x12fb704: ArrayStore: r1[r9] = r0  ; List_4
    //     0x12fb704: add             x25, x1, x9, lsl #2
    //     0x12fb708: add             x25, x25, #0xf
    //     0x12fb70c: str             w0, [x25]
    //     0x12fb710: tbz             w0, #0, #0x12fb72c
    //     0x12fb714: ldurb           w16, [x1, #-1]
    //     0x12fb718: ldurb           w17, [x0, #-1]
    //     0x12fb71c: and             x16, x17, x16, lsr #2
    //     0x12fb720: tst             x16, HEAP, lsr #32
    //     0x12fb724: b.eq            #0x12fb72c
    //     0x12fb728: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb72c: r0 = _CompressedNode()
    //     0x12fb72c: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x12fb730: mov             x1, x0
    // 0x12fb734: ldur            x0, [fp, #-0x30]
    // 0x12fb738: StoreField: r1->field_7 = r0
    //     0x12fb738: stur            x0, [x1, #7]
    // 0x12fb73c: ldur            x0, [fp, #-0x60]
    // 0x12fb740: StoreField: r1->field_f = r0
    //     0x12fb740: stur            w0, [x1, #0xf]
    // 0x12fb744: mov             x0, x1
    // 0x12fb748: LeaveFrame
    //     0x12fb748: mov             SP, fp
    //     0x12fb74c: ldp             fp, lr, [SP], #0x10
    // 0x12fb750: ret
    //     0x12fb750: ret             
    // 0x12fb754: ldur            x3, [fp, #-0x40]
    // 0x12fb758: ldur            x4, [fp, #-0x28]
    // 0x12fb75c: ldur            x9, [fp, #-0x10]
    // 0x12fb760: ldur            x0, [fp, #-0x30]
    // 0x12fb764: ldur            x8, [fp, #-0x18]
    // 0x12fb768: add             x1, x3, #5
    // 0x12fb76c: ldur            x2, [fp, #-0x70]
    // 0x12fb770: ldur            x3, [fp, #-8]
    // 0x12fb774: ldur            x5, [fp, #-0x48]
    // 0x12fb778: ldur            x6, [fp, #-0x50]
    // 0x12fb77c: ldur            x7, [fp, #-0x58]
    // 0x12fb780: r0 = _resolveCollision()
    //     0x12fb780: bl              #0x12fbec8  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_resolveCollision
    // 0x12fb784: ldur            x2, [fp, #-0x20]
    // 0x12fb788: r1 = <Object?>
    //     0x12fb788: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fb78c: stur            x0, [fp, #-8]
    // 0x12fb790: r0 = AllocateArray()
    //     0x12fb790: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fb794: mov             x2, x0
    // 0x12fb798: stur            x2, [fp, #-0x20]
    // 0x12fb79c: ldur            x3, [fp, #-0x28]
    // 0x12fb7a0: ldur            x4, [fp, #-0x18]
    // 0x12fb7a4: r5 = 0
    //     0x12fb7a4: mov             x5, #0
    // 0x12fb7a8: CheckStackOverflow
    //     0x12fb7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb7ac: cmp             SP, x16
    //     0x12fb7b0: b.ls            #0x12fbbf4
    // 0x12fb7b4: cmp             x5, x4
    // 0x12fb7b8: b.ge            #0x12fb800
    // 0x12fb7bc: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0x12fb7bc: add             x16, x3, x5, lsl #2
    //     0x12fb7c0: ldur            w0, [x16, #0xf]
    // 0x12fb7c4: DecompressPointer r0
    //     0x12fb7c4: add             x0, x0, HEAP, lsl #32
    // 0x12fb7c8: mov             x1, x2
    // 0x12fb7cc: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12fb7cc: add             x25, x1, x5, lsl #2
    //     0x12fb7d0: add             x25, x25, #0xf
    //     0x12fb7d4: str             w0, [x25]
    //     0x12fb7d8: tbz             w0, #0, #0x12fb7f4
    //     0x12fb7dc: ldurb           w16, [x1, #-1]
    //     0x12fb7e0: ldurb           w17, [x0, #-1]
    //     0x12fb7e4: and             x16, x17, x16, lsr #2
    //     0x12fb7e8: tst             x16, HEAP, lsr #32
    //     0x12fb7ec: b.eq            #0x12fb7f4
    //     0x12fb7f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb7f4: add             x0, x5, #1
    // 0x12fb7f8: mov             x5, x0
    // 0x12fb7fc: b               #0x12fb7a8
    // 0x12fb800: ldur            x3, [fp, #-0x10]
    // 0x12fb804: ldur            x4, [fp, #-0x30]
    // 0x12fb808: ldur            x0, [fp, #-0x78]
    // 0x12fb80c: ArrayStore: r2[r0] = rNULL  ; Unknown_4
    //     0x12fb80c: add             x1, x2, x0, lsl #2
    //     0x12fb810: stur            NULL, [x1, #0xf]
    // 0x12fb814: mov             x1, x2
    // 0x12fb818: ldur            x0, [fp, #-8]
    // 0x12fb81c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fb81c: add             x25, x1, x3, lsl #2
    //     0x12fb820: add             x25, x25, #0xf
    //     0x12fb824: str             w0, [x25]
    //     0x12fb828: tbz             w0, #0, #0x12fb844
    //     0x12fb82c: ldurb           w16, [x1, #-1]
    //     0x12fb830: ldurb           w17, [x0, #-1]
    //     0x12fb834: and             x16, x17, x16, lsr #2
    //     0x12fb838: tst             x16, HEAP, lsr #32
    //     0x12fb83c: b.eq            #0x12fb844
    //     0x12fb840: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb844: r0 = _CompressedNode()
    //     0x12fb844: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x12fb848: ldur            x4, [fp, #-0x30]
    // 0x12fb84c: StoreField: r0->field_7 = r4
    //     0x12fb84c: stur            x4, [x0, #7]
    // 0x12fb850: ldur            x1, [fp, #-0x20]
    // 0x12fb854: StoreField: r0->field_f = r1
    //     0x12fb854: stur            w1, [x0, #0xf]
    // 0x12fb858: LeaveFrame
    //     0x12fb858: mov             SP, fp
    //     0x12fb85c: ldp             fp, lr, [SP], #0x10
    // 0x12fb860: ret
    //     0x12fb860: ret             
    // 0x12fb864: mov             x3, x4
    // 0x12fb868: mov             x4, x10
    // 0x12fb86c: asr             x1, x4, #1
    // 0x12fb870: ubfx            x1, x1, #0, #0x20
    // 0x12fb874: and             w2, w1, #0x55555555
    // 0x12fb878: ubfx            x2, x2, #0, #0x20
    // 0x12fb87c: sub             x1, x4, x2
    // 0x12fb880: mov             x2, x1
    // 0x12fb884: ubfx            x2, x2, #0, #0x20
    // 0x12fb888: and             w5, w2, #0x33333333
    // 0x12fb88c: lsr             x2, x1, #2
    // 0x12fb890: ubfx            x2, x2, #0, #0x20
    // 0x12fb894: and             w1, w2, #0x33333333
    // 0x12fb898: add             w2, w5, w1
    // 0x12fb89c: lsr             w1, w2, #4
    // 0x12fb8a0: add             w5, w2, w1
    // 0x12fb8a4: and             w1, w5, #0xf0f0f0f
    // 0x12fb8a8: lsr             w2, w1, #8
    // 0x12fb8ac: add             w5, w1, w2
    // 0x12fb8b0: lsr             w1, w5, #0x10
    // 0x12fb8b4: add             w2, w5, w1
    // 0x12fb8b8: and             w1, w2, #0x3f
    // 0x12fb8bc: cmp             w1, #0x10
    // 0x12fb8c0: b.lo            #0x12fb984
    // 0x12fb8c4: ldur            x1, [fp, #-0x38]
    // 0x12fb8c8: mov             x2, x3
    // 0x12fb8cc: r0 = _inflate()
    //     0x12fb8cc: bl              #0x12fbc28  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_inflate
    // 0x12fb8d0: stur            x0, [fp, #-0x20]
    // 0x12fb8d4: LoadField: r1 = r0->field_7
    //     0x12fb8d4: ldur            w1, [x0, #7]
    // 0x12fb8d8: DecompressPointer r1
    //     0x12fb8d8: add             x1, x1, HEAP, lsl #32
    // 0x12fb8dc: stur            x1, [fp, #-8]
    // 0x12fb8e0: r0 = LoadStaticField(0xbdc)
    //     0x12fb8e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12fb8e4: ldr             x0, [x0, #0x17b8]
    // 0x12fb8e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fb8ec: cmp             w0, w16
    // 0x12fb8f0: b.ne            #0x12fb900
    // 0x12fb8f4: r2 = empty
    //     0x12fb8f4: add             x2, PP, #0x85, lsl #12  ; [pp+0x85600] Field <_CompressedNode@596137193.empty>: static late final (offset: 0xbdc)
    //     0x12fb8f8: ldr             x2, [x2, #0x600]
    // 0x12fb8fc: r0 = InitLateFinalStaticField()
    //     0x12fb8fc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12fb900: mov             x1, x0
    // 0x12fb904: ldur            x0, [fp, #-0x40]
    // 0x12fb908: add             x2, x0, #5
    // 0x12fb90c: ldur            x3, [fp, #-0x48]
    // 0x12fb910: ldur            x5, [fp, #-0x50]
    // 0x12fb914: ldur            x6, [fp, #-0x58]
    // 0x12fb918: r0 = put()
    //     0x12fb918: bl              #0x12fb368  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0x12fb91c: mov             x3, x0
    // 0x12fb920: ldur            x2, [fp, #-8]
    // 0x12fb924: LoadField: r0 = r2->field_b
    //     0x12fb924: ldur            w0, [x2, #0xb]
    // 0x12fb928: r1 = LoadInt32Instr(r0)
    //     0x12fb928: sbfx            x1, x0, #1, #0x1f
    // 0x12fb92c: ldur            x4, [fp, #-0x80]
    // 0x12fb930: ubfx            x4, x4, #0, #0x20
    // 0x12fb934: mov             x0, x1
    // 0x12fb938: mov             x1, x4
    // 0x12fb93c: cmp             x1, x0
    // 0x12fb940: b.hs            #0x12fbbfc
    // 0x12fb944: mov             x1, x2
    // 0x12fb948: mov             x0, x3
    // 0x12fb94c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x12fb94c: add             x25, x1, x4, lsl #2
    //     0x12fb950: add             x25, x25, #0xf
    //     0x12fb954: str             w0, [x25]
    //     0x12fb958: tbz             w0, #0, #0x12fb974
    //     0x12fb95c: ldurb           w16, [x1, #-1]
    //     0x12fb960: ldurb           w17, [x0, #-1]
    //     0x12fb964: and             x16, x17, x16, lsr #2
    //     0x12fb968: tst             x16, HEAP, lsr #32
    //     0x12fb96c: b.eq            #0x12fb974
    //     0x12fb970: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb974: ldur            x0, [fp, #-0x20]
    // 0x12fb978: LeaveFrame
    //     0x12fb978: mov             SP, fp
    //     0x12fb97c: ldp             fp, lr, [SP], #0x10
    // 0x12fb980: ret
    //     0x12fb980: ret             
    // 0x12fb984: ldur            x3, [fp, #-0x38]
    // 0x12fb988: ubfx            x0, x0, #0, #0x20
    // 0x12fb98c: lsl             x5, x0, #1
    // 0x12fb990: stur            x5, [fp, #-0x40]
    // 0x12fb994: ubfx            x1, x1, #0, #0x20
    // 0x12fb998: lsl             x0, x1, #1
    // 0x12fb99c: stur            x0, [fp, #-0x18]
    // 0x12fb9a0: add             x6, x0, #2
    // 0x12fb9a4: stur            x6, [fp, #-0x10]
    // 0x12fb9a8: lsl             x2, x6, #1
    // 0x12fb9ac: r1 = <Object?>
    //     0x12fb9ac: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fb9b0: r0 = AllocateArray()
    //     0x12fb9b0: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fb9b4: mov             x2, x0
    // 0x12fb9b8: ldur            x0, [fp, #-0x38]
    // 0x12fb9bc: stur            x2, [fp, #-8]
    // 0x12fb9c0: LoadField: r3 = r0->field_f
    //     0x12fb9c0: ldur            w3, [x0, #0xf]
    // 0x12fb9c4: DecompressPointer r3
    //     0x12fb9c4: add             x3, x3, HEAP, lsl #32
    // 0x12fb9c8: LoadField: r0 = r3->field_b
    //     0x12fb9c8: ldur            w0, [x3, #0xb]
    // 0x12fb9cc: r4 = LoadInt32Instr(r0)
    //     0x12fb9cc: sbfx            x4, x0, #1, #0x1f
    // 0x12fb9d0: ldur            x5, [fp, #-0x40]
    // 0x12fb9d4: r6 = 0
    //     0x12fb9d4: mov             x6, #0
    // 0x12fb9d8: CheckStackOverflow
    //     0x12fb9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb9dc: cmp             SP, x16
    //     0x12fb9e0: b.ls            #0x12fbc00
    // 0x12fb9e4: cmp             x6, x5
    // 0x12fb9e8: b.ge            #0x12fba54
    // 0x12fb9ec: mov             x0, x4
    // 0x12fb9f0: mov             x1, x6
    // 0x12fb9f4: cmp             x1, x0
    // 0x12fb9f8: b.hs            #0x12fbc08
    // 0x12fb9fc: ArrayLoad: r7 = r3[r6]  ; Unknown_4
    //     0x12fb9fc: add             x16, x3, x6, lsl #2
    //     0x12fba00: ldur            w7, [x16, #0xf]
    // 0x12fba04: DecompressPointer r7
    //     0x12fba04: add             x7, x7, HEAP, lsl #32
    // 0x12fba08: ldur            x0, [fp, #-0x10]
    // 0x12fba0c: mov             x1, x6
    // 0x12fba10: cmp             x1, x0
    // 0x12fba14: b.hs            #0x12fbc0c
    // 0x12fba18: mov             x1, x2
    // 0x12fba1c: mov             x0, x7
    // 0x12fba20: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12fba20: add             x25, x1, x6, lsl #2
    //     0x12fba24: add             x25, x25, #0xf
    //     0x12fba28: str             w0, [x25]
    //     0x12fba2c: tbz             w0, #0, #0x12fba48
    //     0x12fba30: ldurb           w16, [x1, #-1]
    //     0x12fba34: ldurb           w17, [x0, #-1]
    //     0x12fba38: and             x16, x17, x16, lsr #2
    //     0x12fba3c: tst             x16, HEAP, lsr #32
    //     0x12fba40: b.eq            #0x12fba48
    //     0x12fba44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fba48: add             x0, x6, #1
    // 0x12fba4c: mov             x6, x0
    // 0x12fba50: b               #0x12fb9d8
    // 0x12fba54: ldur            x0, [fp, #-0x10]
    // 0x12fba58: mov             x1, x5
    // 0x12fba5c: cmp             x1, x0
    // 0x12fba60: b.hs            #0x12fbc10
    // 0x12fba64: mov             x1, x2
    // 0x12fba68: ldur            x0, [fp, #-0x48]
    // 0x12fba6c: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12fba6c: add             x25, x1, x5, lsl #2
    //     0x12fba70: add             x25, x25, #0xf
    //     0x12fba74: str             w0, [x25]
    //     0x12fba78: tbz             w0, #0, #0x12fba94
    //     0x12fba7c: ldurb           w16, [x1, #-1]
    //     0x12fba80: ldurb           w17, [x0, #-1]
    //     0x12fba84: and             x16, x17, x16, lsr #2
    //     0x12fba88: tst             x16, HEAP, lsr #32
    //     0x12fba8c: b.eq            #0x12fba94
    //     0x12fba90: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fba94: add             x4, x5, #1
    // 0x12fba98: ldur            x0, [fp, #-0x10]
    // 0x12fba9c: mov             x1, x4
    // 0x12fbaa0: cmp             x1, x0
    // 0x12fbaa4: b.hs            #0x12fbc14
    // 0x12fbaa8: mov             x1, x2
    // 0x12fbaac: ldur            x0, [fp, #-0x58]
    // 0x12fbab0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x12fbab0: add             x25, x1, x4, lsl #2
    //     0x12fbab4: add             x25, x25, #0xf
    //     0x12fbab8: str             w0, [x25]
    //     0x12fbabc: tbz             w0, #0, #0x12fbad8
    //     0x12fbac0: ldurb           w16, [x1, #-1]
    //     0x12fbac4: ldurb           w17, [x0, #-1]
    //     0x12fbac8: and             x16, x17, x16, lsr #2
    //     0x12fbacc: tst             x16, HEAP, lsr #32
    //     0x12fbad0: b.eq            #0x12fbad8
    //     0x12fbad4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fbad8: add             x0, x5, #2
    // 0x12fbadc: LoadField: r1 = r3->field_b
    //     0x12fbadc: ldur            w1, [x3, #0xb]
    // 0x12fbae0: r4 = LoadInt32Instr(r1)
    //     0x12fbae0: sbfx            x4, x1, #1, #0x1f
    // 0x12fbae4: mov             x7, x5
    // 0x12fbae8: mov             x6, x0
    // 0x12fbaec: ldur            x5, [fp, #-0x18]
    // 0x12fbaf0: CheckStackOverflow
    //     0x12fbaf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fbaf4: cmp             SP, x16
    //     0x12fbaf8: b.ls            #0x12fbc18
    // 0x12fbafc: cmp             x7, x5
    // 0x12fbb00: b.ge            #0x12fbb74
    // 0x12fbb04: mov             x0, x4
    // 0x12fbb08: mov             x1, x7
    // 0x12fbb0c: cmp             x1, x0
    // 0x12fbb10: b.hs            #0x12fbc20
    // 0x12fbb14: ArrayLoad: r8 = r3[r7]  ; Unknown_4
    //     0x12fbb14: add             x16, x3, x7, lsl #2
    //     0x12fbb18: ldur            w8, [x16, #0xf]
    // 0x12fbb1c: DecompressPointer r8
    //     0x12fbb1c: add             x8, x8, HEAP, lsl #32
    // 0x12fbb20: ldur            x0, [fp, #-0x10]
    // 0x12fbb24: mov             x1, x6
    // 0x12fbb28: cmp             x1, x0
    // 0x12fbb2c: b.hs            #0x12fbc24
    // 0x12fbb30: mov             x1, x2
    // 0x12fbb34: mov             x0, x8
    // 0x12fbb38: ArrayStore: r1[r6] = r0  ; List_4
    //     0x12fbb38: add             x25, x1, x6, lsl #2
    //     0x12fbb3c: add             x25, x25, #0xf
    //     0x12fbb40: str             w0, [x25]
    //     0x12fbb44: tbz             w0, #0, #0x12fbb60
    //     0x12fbb48: ldurb           w16, [x1, #-1]
    //     0x12fbb4c: ldurb           w17, [x0, #-1]
    //     0x12fbb50: and             x16, x17, x16, lsr #2
    //     0x12fbb54: tst             x16, HEAP, lsr #32
    //     0x12fbb58: b.eq            #0x12fbb60
    //     0x12fbb5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fbb60: add             x0, x7, #1
    // 0x12fbb64: add             x1, x6, #1
    // 0x12fbb68: mov             x7, x0
    // 0x12fbb6c: mov             x6, x1
    // 0x12fbb70: b               #0x12fbaf0
    // 0x12fbb74: ldur            x0, [fp, #-0x88]
    // 0x12fbb78: ldur            x1, [fp, #-0x30]
    // 0x12fbb7c: orr             x3, x1, x0
    // 0x12fbb80: stur            x3, [fp, #-0x10]
    // 0x12fbb84: r0 = _CompressedNode()
    //     0x12fbb84: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x12fbb88: ldur            x1, [fp, #-0x10]
    // 0x12fbb8c: StoreField: r0->field_7 = r1
    //     0x12fbb8c: stur            x1, [x0, #7]
    // 0x12fbb90: ldur            x1, [fp, #-8]
    // 0x12fbb94: StoreField: r0->field_f = r1
    //     0x12fbb94: stur            w1, [x0, #0xf]
    // 0x12fbb98: LeaveFrame
    //     0x12fbb98: mov             SP, fp
    //     0x12fbb9c: ldp             fp, lr, [SP], #0x10
    // 0x12fbba0: ret
    //     0x12fbba0: ret             
    // 0x12fbba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbba8: b               #0x12fb3a0
    // 0x12fbbac: tbnz            x4, #0x3f, #0x12fbbb8
    // 0x12fbbb0: mov             x1, xzr
    // 0x12fbbb4: b               #0x12fb3ac
    // 0x12fbbb8: str             x4, [THR, #0x8a0]  ; THR::
    // 0x12fbbbc: stp             x6, x7, [SP, #-0x10]!
    // 0x12fbbc0: stp             x4, x5, [SP, #-0x10]!
    // 0x12fbbc4: stp             x0, x3, [SP, #-0x10]!
    // 0x12fbbc8: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fbbcc: r4 = 0
    //     0x12fbbcc: mov             x4, #0
    // 0x12fbbd0: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fbbd4: blr             lr
    // 0x12fbbd8: brk             #0
    // 0x12fbbdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbbdc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbbe0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbbe0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbbe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbbe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbbe8: b               #0x12fb570
    // 0x12fbbec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbbec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbbf0: b               #0x12fb6a8
    // 0x12fbbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbbf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbbf8: b               #0x12fb7b4
    // 0x12fbbfc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbbfc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbc00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbc04: b               #0x12fb9e4
    // 0x12fbc08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc08: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc0c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc0c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc10: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc14: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbc18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbc1c: b               #0x12fbafc
    // 0x12fbc20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc20: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbc24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbc24: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _inflate(/* No info */) {
    // ** addr: 0x12fbc28, size: 0x2a0
    // 0x12fbc28: EnterFrame
    //     0x12fbc28: stp             fp, lr, [SP, #-0x10]!
    //     0x12fbc2c: mov             fp, SP
    // 0x12fbc30: AllocStack(0x50)
    //     0x12fbc30: sub             SP, SP, #0x50
    // 0x12fbc34: SetupParameters(_CompressedNode this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12fbc34: mov             x3, x1
    //     0x12fbc38: mov             x0, x2
    //     0x12fbc3c: stur            x1, [fp, #-8]
    //     0x12fbc40: stur            x2, [fp, #-0x10]
    // 0x12fbc44: CheckStackOverflow
    //     0x12fbc44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fbc48: cmp             SP, x16
    //     0x12fbc4c: b.ls            #0x12fbe78
    // 0x12fbc50: r1 = <Object?>
    //     0x12fbc50: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fbc54: r2 = 64
    //     0x12fbc54: mov             x2, #0x40
    // 0x12fbc58: r0 = AllocateArray()
    //     0x12fbc58: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fbc5c: mov             x2, x0
    // 0x12fbc60: ldur            x0, [fp, #-8]
    // 0x12fbc64: stur            x2, [fp, #-0x40]
    // 0x12fbc68: LoadField: r3 = r0->field_7
    //     0x12fbc68: ldur            x3, [x0, #7]
    // 0x12fbc6c: stur            x3, [fp, #-0x38]
    // 0x12fbc70: LoadField: r4 = r0->field_f
    //     0x12fbc70: ldur            w4, [x0, #0xf]
    // 0x12fbc74: DecompressPointer r4
    //     0x12fbc74: add             x4, x4, HEAP, lsl #32
    // 0x12fbc78: stur            x4, [fp, #-0x30]
    // 0x12fbc7c: LoadField: r0 = r4->field_b
    //     0x12fbc7c: ldur            w0, [x4, #0xb]
    // 0x12fbc80: r5 = LoadInt32Instr(r0)
    //     0x12fbc80: sbfx            x5, x0, #1, #0x1f
    // 0x12fbc84: ldur            x0, [fp, #-0x10]
    // 0x12fbc88: stur            x5, [fp, #-0x28]
    // 0x12fbc8c: add             x6, x0, #5
    // 0x12fbc90: stur            x6, [fp, #-0x20]
    // 0x12fbc94: r8 = 0
    //     0x12fbc94: mov             x8, #0
    // 0x12fbc98: r7 = 0
    //     0x12fbc98: mov             x7, #0
    // 0x12fbc9c: stur            x8, [fp, #-0x10]
    // 0x12fbca0: stur            x7, [fp, #-0x18]
    // 0x12fbca4: CheckStackOverflow
    //     0x12fbca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fbca8: cmp             SP, x16
    //     0x12fbcac: b.ls            #0x12fbe80
    // 0x12fbcb0: cmp             x7, #0x20
    // 0x12fbcb4: b.ge            #0x12fbe5c
    // 0x12fbcb8: cmp             x7, #0x3f
    // 0x12fbcbc: b.hi            #0x12fbe88
    // 0x12fbcc0: lsr             x0, x3, x7
    // 0x12fbcc4: branchIfSmi(r0, 0x12fbe34)
    //     0x12fbcc4: tbz             w0, #0, #0x12fbe34
    // 0x12fbcc8: mov             x0, x5
    // 0x12fbccc: mov             x1, x8
    // 0x12fbcd0: cmp             x1, x0
    // 0x12fbcd4: b.hs            #0x12fbebc
    // 0x12fbcd8: ArrayLoad: r0 = r4[r8]  ; Unknown_4
    //     0x12fbcd8: add             x16, x4, x8, lsl #2
    //     0x12fbcdc: ldur            w0, [x16, #0xf]
    // 0x12fbce0: DecompressPointer r0
    //     0x12fbce0: add             x0, x0, HEAP, lsl #32
    // 0x12fbce4: stur            x0, [fp, #-8]
    // 0x12fbce8: cmp             w0, NULL
    // 0x12fbcec: b.ne            #0x12fbd48
    // 0x12fbcf0: add             x9, x8, #1
    // 0x12fbcf4: mov             x0, x5
    // 0x12fbcf8: mov             x1, x9
    // 0x12fbcfc: cmp             x1, x0
    // 0x12fbd00: b.hs            #0x12fbec0
    // 0x12fbd04: ArrayLoad: r0 = r4[r9]  ; Unknown_4
    //     0x12fbd04: add             x16, x4, x9, lsl #2
    //     0x12fbd08: ldur            w0, [x16, #0xf]
    // 0x12fbd0c: DecompressPointer r0
    //     0x12fbd0c: add             x0, x0, HEAP, lsl #32
    // 0x12fbd10: mov             x1, x2
    // 0x12fbd14: ArrayStore: r1[r7] = r0  ; List_4
    //     0x12fbd14: add             x25, x1, x7, lsl #2
    //     0x12fbd18: add             x25, x25, #0xf
    //     0x12fbd1c: str             w0, [x25]
    //     0x12fbd20: tbz             w0, #0, #0x12fbd3c
    //     0x12fbd24: ldurb           w16, [x1, #-1]
    //     0x12fbd28: ldurb           w17, [x0, #-1]
    //     0x12fbd2c: and             x16, x17, x16, lsr #2
    //     0x12fbd30: tst             x16, HEAP, lsr #32
    //     0x12fbd34: b.eq            #0x12fbd3c
    //     0x12fbd38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fbd3c: mov             x0, x8
    // 0x12fbd40: mov             x2, x7
    // 0x12fbd44: b               #0x12fbe28
    // 0x12fbd48: r0 = LoadStaticField(0xbdc)
    //     0x12fbd48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12fbd4c: ldr             x0, [x0, #0x17b8]
    // 0x12fbd50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fbd54: cmp             w0, w16
    // 0x12fbd58: b.ne            #0x12fbd68
    // 0x12fbd5c: r2 = empty
    //     0x12fbd5c: add             x2, PP, #0x85, lsl #12  ; [pp+0x85600] Field <_CompressedNode@596137193.empty>: static late final (offset: 0xbdc)
    //     0x12fbd60: ldr             x2, [x2, #0x600]
    // 0x12fbd64: r0 = InitLateFinalStaticField()
    //     0x12fbd64: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12fbd68: mov             x3, x0
    // 0x12fbd6c: ldur            x2, [fp, #-0x10]
    // 0x12fbd70: ldur            x1, [fp, #-0x30]
    // 0x12fbd74: stur            x3, [fp, #-0x48]
    // 0x12fbd78: ArrayLoad: r0 = r1[r2]  ; Unknown_4
    //     0x12fbd78: add             x16, x1, x2, lsl #2
    //     0x12fbd7c: ldur            w0, [x16, #0xf]
    // 0x12fbd80: DecompressPointer r0
    //     0x12fbd80: add             x0, x0, HEAP, lsl #32
    // 0x12fbd84: r4 = 60
    //     0x12fbd84: mov             x4, #0x3c
    // 0x12fbd88: branchIfSmi(r0, 0x12fbd94)
    //     0x12fbd88: tbz             w0, #0, #0x12fbd94
    // 0x12fbd8c: r4 = LoadClassIdInstr(r0)
    //     0x12fbd8c: ldur            x4, [x0, #-1]
    //     0x12fbd90: ubfx            x4, x4, #0xc, #0x14
    // 0x12fbd94: str             x0, [SP]
    // 0x12fbd98: mov             x0, x4
    // 0x12fbd9c: r0 = GDT[cid_x0 + 0x70de]()
    //     0x12fbd9c: mov             x17, #0x70de
    //     0x12fbda0: add             lr, x0, x17
    //     0x12fbda4: ldr             lr, [x21, lr, lsl #3]
    //     0x12fbda8: blr             lr
    // 0x12fbdac: mov             x2, x0
    // 0x12fbdb0: ldur            x4, [fp, #-0x10]
    // 0x12fbdb4: add             x3, x4, #1
    // 0x12fbdb8: ldur            x0, [fp, #-0x28]
    // 0x12fbdbc: mov             x1, x3
    // 0x12fbdc0: cmp             x1, x0
    // 0x12fbdc4: b.hs            #0x12fbec4
    // 0x12fbdc8: ldur            x0, [fp, #-0x30]
    // 0x12fbdcc: ArrayLoad: r6 = r0[r3]  ; Unknown_4
    //     0x12fbdcc: add             x16, x0, x3, lsl #2
    //     0x12fbdd0: ldur            w6, [x16, #0xf]
    // 0x12fbdd4: DecompressPointer r6
    //     0x12fbdd4: add             x6, x6, HEAP, lsl #32
    // 0x12fbdd8: r5 = LoadInt32Instr(r2)
    //     0x12fbdd8: sbfx            x5, x2, #1, #0x1f
    //     0x12fbddc: tbz             w2, #0, #0x12fbde4
    //     0x12fbde0: ldur            x5, [x2, #7]
    // 0x12fbde4: ldur            x1, [fp, #-0x48]
    // 0x12fbde8: ldur            x2, [fp, #-0x20]
    // 0x12fbdec: ldur            x3, [fp, #-8]
    // 0x12fbdf0: r0 = put()
    //     0x12fbdf0: bl              #0x12fb368  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0x12fbdf4: ldur            x1, [fp, #-0x40]
    // 0x12fbdf8: ldur            x2, [fp, #-0x18]
    // 0x12fbdfc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12fbdfc: add             x25, x1, x2, lsl #2
    //     0x12fbe00: add             x25, x25, #0xf
    //     0x12fbe04: str             w0, [x25]
    //     0x12fbe08: tbz             w0, #0, #0x12fbe24
    //     0x12fbe0c: ldurb           w16, [x1, #-1]
    //     0x12fbe10: ldurb           w17, [x0, #-1]
    //     0x12fbe14: and             x16, x17, x16, lsr #2
    //     0x12fbe18: tst             x16, HEAP, lsr #32
    //     0x12fbe1c: b.eq            #0x12fbe24
    //     0x12fbe20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fbe24: ldur            x0, [fp, #-0x10]
    // 0x12fbe28: add             x1, x0, #2
    // 0x12fbe2c: mov             x8, x1
    // 0x12fbe30: b               #0x12fbe40
    // 0x12fbe34: mov             x0, x8
    // 0x12fbe38: mov             x2, x7
    // 0x12fbe3c: mov             x8, x0
    // 0x12fbe40: add             x7, x2, #1
    // 0x12fbe44: ldur            x3, [fp, #-0x38]
    // 0x12fbe48: ldur            x4, [fp, #-0x30]
    // 0x12fbe4c: ldur            x6, [fp, #-0x20]
    // 0x12fbe50: ldur            x2, [fp, #-0x40]
    // 0x12fbe54: ldur            x5, [fp, #-0x28]
    // 0x12fbe58: b               #0x12fbc9c
    // 0x12fbe5c: mov             x0, x2
    // 0x12fbe60: r0 = _FullNode()
    //     0x12fbe60: bl              #0x12fb35c  ; Allocate_FullNodeStub -> _FullNode (size=0xc)
    // 0x12fbe64: ldur            x1, [fp, #-0x40]
    // 0x12fbe68: StoreField: r0->field_7 = r1
    //     0x12fbe68: stur            w1, [x0, #7]
    // 0x12fbe6c: LeaveFrame
    //     0x12fbe6c: mov             SP, fp
    //     0x12fbe70: ldp             fp, lr, [SP], #0x10
    // 0x12fbe74: ret
    //     0x12fbe74: ret             
    // 0x12fbe78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbe78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbe7c: b               #0x12fbc50
    // 0x12fbe80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbe80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbe84: b               #0x12fbcb0
    // 0x12fbe88: tbnz            x7, #0x3f, #0x12fbe94
    // 0x12fbe8c: mov             x0, xzr
    // 0x12fbe90: b               #0x12fbcc4
    // 0x12fbe94: str             x7, [THR, #0x8a0]  ; THR::
    // 0x12fbe98: stp             x7, x8, [SP, #-0x10]!
    // 0x12fbe9c: stp             x5, x6, [SP, #-0x10]!
    // 0x12fbea0: stp             x3, x4, [SP, #-0x10]!
    // 0x12fbea4: SaveReg r2
    //     0x12fbea4: str             x2, [SP, #-8]!
    // 0x12fbea8: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fbeac: r4 = 0
    //     0x12fbeac: mov             x4, #0
    // 0x12fbeb0: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fbeb4: blr             lr
    // 0x12fbeb8: brk             #0
    // 0x12fbebc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbebc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbec0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbec0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fbec4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fbec4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _resolveCollision(/* No info */) {
    // ** addr: 0x12fbec8, size: 0x12c
    // 0x12fbec8: EnterFrame
    //     0x12fbec8: stp             fp, lr, [SP, #-0x10]!
    //     0x12fbecc: mov             fp, SP
    // 0x12fbed0: AllocStack(0x40)
    //     0x12fbed0: sub             SP, SP, #0x40
    // 0x12fbed4: SetupParameters(dynamic _ /* r2 => r6, fp-0x20 */, dynamic _ /* r6 => r5, fp-0x28 */, [dynamic _ /* fp-0x8 */, dynamic _ /* fp-0x30 */])
    //     0x12fbed4: stur            x2, [fp, #-0x10]
    //     0x12fbed8: mov             x16, x6
    //     0x12fbedc: mov             x6, x2
    //     0x12fbee0: mov             x2, x16
    //     0x12fbee4: mov             x16, x5
    //     0x12fbee8: mov             x5, x6
    //     0x12fbeec: mov             x6, x16
    //     0x12fbef0: mov             x16, x3
    //     0x12fbef4: mov             x3, x5
    //     0x12fbef8: mov             x5, x16
    //     0x12fbefc: stur            x1, [fp, #-8]
    //     0x12fbf00: stur            x5, [fp, #-0x18]
    //     0x12fbf04: stur            x6, [fp, #-0x20]
    //     0x12fbf08: stur            x2, [fp, #-0x28]
    //     0x12fbf0c: stur            x7, [fp, #-0x30]
    // 0x12fbf10: CheckStackOverflow
    //     0x12fbf10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fbf14: cmp             SP, x16
    //     0x12fbf18: b.ls            #0x12fbfec
    // 0x12fbf1c: r0 = 60
    //     0x12fbf1c: mov             x0, #0x3c
    // 0x12fbf20: branchIfSmi(r3, 0x12fbf2c)
    //     0x12fbf20: tbz             w3, #0, #0x12fbf2c
    // 0x12fbf24: r0 = LoadClassIdInstr(r3)
    //     0x12fbf24: ldur            x0, [x3, #-1]
    //     0x12fbf28: ubfx            x0, x0, #0xc, #0x14
    // 0x12fbf2c: str             x3, [SP]
    // 0x12fbf30: r0 = GDT[cid_x0 + 0x70de]()
    //     0x12fbf30: mov             x17, #0x70de
    //     0x12fbf34: add             lr, x0, x17
    //     0x12fbf38: ldr             lr, [x21, lr, lsl #3]
    //     0x12fbf3c: blr             lr
    // 0x12fbf40: r5 = LoadInt32Instr(r0)
    //     0x12fbf40: sbfx            x5, x0, #1, #0x1f
    //     0x12fbf44: tbz             w0, #0, #0x12fbf4c
    //     0x12fbf48: ldur            x5, [x0, #7]
    // 0x12fbf4c: ldur            x2, [fp, #-0x28]
    // 0x12fbf50: stur            x5, [fp, #-0x38]
    // 0x12fbf54: cmp             x5, x2
    // 0x12fbf58: b.ne            #0x12fbf78
    // 0x12fbf5c: ldur            x3, [fp, #-0x10]
    // 0x12fbf60: ldur            x5, [fp, #-0x18]
    // 0x12fbf64: ldur            x6, [fp, #-0x20]
    // 0x12fbf68: ldur            x7, [fp, #-0x30]
    // 0x12fbf6c: r1 = Null
    //     0x12fbf6c: mov             x1, NULL
    // 0x12fbf70: r0 = _HashCollisionNode.fromCollision()
    //     0x12fbf70: bl              #0x12fbff4  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_HashCollisionNode.fromCollision
    // 0x12fbf74: b               #0x12fbfe0
    // 0x12fbf78: r0 = LoadStaticField(0xbdc)
    //     0x12fbf78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12fbf7c: ldr             x0, [x0, #0x17b8]
    // 0x12fbf80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fbf84: cmp             w0, w16
    // 0x12fbf88: b.ne            #0x12fbf98
    // 0x12fbf8c: r2 = empty
    //     0x12fbf8c: add             x2, PP, #0x85, lsl #12  ; [pp+0x85600] Field <_CompressedNode@596137193.empty>: static late final (offset: 0xbdc)
    //     0x12fbf90: ldr             x2, [x2, #0x600]
    // 0x12fbf94: r0 = InitLateFinalStaticField()
    //     0x12fbf94: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12fbf98: mov             x1, x0
    // 0x12fbf9c: ldur            x2, [fp, #-8]
    // 0x12fbfa0: ldur            x3, [fp, #-0x10]
    // 0x12fbfa4: ldur            x5, [fp, #-0x38]
    // 0x12fbfa8: ldur            x6, [fp, #-0x18]
    // 0x12fbfac: r0 = put()
    //     0x12fbfac: bl              #0x12fb368  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0x12fbfb0: r1 = LoadClassIdInstr(r0)
    //     0x12fbfb0: ldur            x1, [x0, #-1]
    //     0x12fbfb4: ubfx            x1, x1, #0xc, #0x14
    // 0x12fbfb8: mov             x16, x0
    // 0x12fbfbc: mov             x0, x1
    // 0x12fbfc0: mov             x1, x16
    // 0x12fbfc4: ldur            x2, [fp, #-8]
    // 0x12fbfc8: ldur            x3, [fp, #-0x20]
    // 0x12fbfcc: ldur            x5, [fp, #-0x28]
    // 0x12fbfd0: ldur            x6, [fp, #-0x30]
    // 0x12fbfd4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12fbfd4: sub             lr, x0, #1, lsl #12
    //     0x12fbfd8: ldr             lr, [x21, lr, lsl #3]
    //     0x12fbfdc: blr             lr
    // 0x12fbfe0: LeaveFrame
    //     0x12fbfe0: mov             SP, fp
    //     0x12fbfe4: ldp             fp, lr, [SP], #0x10
    // 0x12fbfe8: ret
    //     0x12fbfe8: ret             
    // 0x12fbfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fbfec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fbff0: b               #0x12fbf1c
  }
  factory _ _CompressedNode.single(/* No info */) {
    // ** addr: 0x12fc38c, size: 0x9c
    // 0x12fc38c: EnterFrame
    //     0x12fc38c: stp             fp, lr, [SP, #-0x10]!
    //     0x12fc390: mov             fp, SP
    // 0x12fc394: AllocStack(0x18)
    //     0x12fc394: sub             SP, SP, #0x18
    // 0x12fc398: r0 = 1
    //     0x12fc398: mov             x0, #1
    // 0x12fc39c: stur            x5, [fp, #-0x10]
    // 0x12fc3a0: cmp             x2, #0x3f
    // 0x12fc3a4: b.hi            #0x12fc3fc
    // 0x12fc3a8: lsr             x1, x3, x2
    // 0x12fc3ac: ubfx            x1, x1, #0, #0x20
    // 0x12fc3b0: and             w2, w1, #0x1f
    // 0x12fc3b4: ubfx            x2, x2, #0, #0x20
    // 0x12fc3b8: lsl             x3, x0, x2
    // 0x12fc3bc: stur            x3, [fp, #-8]
    // 0x12fc3c0: r1 = <Object?>
    //     0x12fc3c0: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fc3c4: r2 = 4
    //     0x12fc3c4: mov             x2, #4
    // 0x12fc3c8: r0 = AllocateArray()
    //     0x12fc3c8: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fc3cc: mov             x1, x0
    // 0x12fc3d0: ldur            x0, [fp, #-0x10]
    // 0x12fc3d4: stur            x1, [fp, #-0x18]
    // 0x12fc3d8: StoreField: r1->field_13 = r0
    //     0x12fc3d8: stur            w0, [x1, #0x13]
    // 0x12fc3dc: r0 = _CompressedNode()
    //     0x12fc3dc: bl              #0x1108cbc  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x12fc3e0: ldur            x1, [fp, #-8]
    // 0x12fc3e4: StoreField: r0->field_7 = r1
    //     0x12fc3e4: stur            x1, [x0, #7]
    // 0x12fc3e8: ldur            x1, [fp, #-0x18]
    // 0x12fc3ec: StoreField: r0->field_f = r1
    //     0x12fc3ec: stur            w1, [x0, #0xf]
    // 0x12fc3f0: LeaveFrame
    //     0x12fc3f0: mov             SP, fp
    //     0x12fc3f4: ldp             fp, lr, [SP], #0x10
    // 0x12fc3f8: ret
    //     0x12fc3f8: ret             
    // 0x12fc3fc: tbnz            x2, #0x3f, #0x12fc408
    // 0x12fc400: mov             x1, xzr
    // 0x12fc404: b               #0x12fc3ac
    // 0x12fc408: str             x2, [THR, #0x8a0]  ; THR::
    // 0x12fc40c: stp             x3, x5, [SP, #-0x10]!
    // 0x12fc410: stp             x0, x2, [SP, #-0x10]!
    // 0x12fc414: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fc418: r4 = 0
    //     0x12fc418: mov             x4, #0
    // 0x12fc41c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fc420: blr             lr
    // 0x12fc424: brk             #0
  }
}

// class id: 3193, size: 0xc, field offset: 0x8
class _FullNode extends _TrieNode {

  _ get(/* No info */) {
    // ** addr: 0x12fad38, size: 0x124
    // 0x12fad38: EnterFrame
    //     0x12fad38: stp             fp, lr, [SP, #-0x10]!
    //     0x12fad3c: mov             fp, SP
    // 0x12fad40: AllocStack(0x20)
    //     0x12fad40: sub             SP, SP, #0x20
    // 0x12fad44: SetupParameters(dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x12fad44: mov             x4, x2
    //     0x12fad48: stur            x2, [fp, #-0x10]
    //     0x12fad4c: stur            x3, [fp, #-0x18]
    //     0x12fad50: stur            x5, [fp, #-0x20]
    // 0x12fad54: CheckStackOverflow
    //     0x12fad54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fad58: cmp             SP, x16
    //     0x12fad5c: b.ls            #0x12fae24
    // 0x12fad60: cmp             x4, #0x3f
    // 0x12fad64: b.hi            #0x12fae2c
    // 0x12fad68: lsr             x0, x5, x4
    // 0x12fad6c: ubfx            x0, x0, #0, #0x20
    // 0x12fad70: and             w2, w0, #0x1f
    // 0x12fad74: LoadField: r6 = r1->field_7
    //     0x12fad74: ldur            w6, [x1, #7]
    // 0x12fad78: DecompressPointer r6
    //     0x12fad78: add             x6, x6, HEAP, lsl #32
    // 0x12fad7c: LoadField: r0 = r6->field_b
    //     0x12fad7c: ldur            w0, [x6, #0xb]
    // 0x12fad80: r1 = LoadInt32Instr(r0)
    //     0x12fad80: sbfx            x1, x0, #1, #0x1f
    // 0x12fad84: ubfx            x2, x2, #0, #0x20
    // 0x12fad88: mov             x0, x1
    // 0x12fad8c: mov             x1, x2
    // 0x12fad90: cmp             x1, x0
    // 0x12fad94: b.hs            #0x12fae58
    // 0x12fad98: ArrayLoad: r7 = r6[r2]  ; Unknown_4
    //     0x12fad98: add             x16, x6, x2, lsl #2
    //     0x12fad9c: ldur            w7, [x16, #0xf]
    // 0x12fada0: DecompressPointer r7
    //     0x12fada0: add             x7, x7, HEAP, lsl #32
    // 0x12fada4: mov             x0, x7
    // 0x12fada8: stur            x7, [fp, #-8]
    // 0x12fadac: r2 = Null
    //     0x12fadac: mov             x2, NULL
    // 0x12fadb0: r1 = Null
    //     0x12fadb0: mov             x1, NULL
    // 0x12fadb4: r4 = 60
    //     0x12fadb4: mov             x4, #0x3c
    // 0x12fadb8: branchIfSmi(r0, 0x12fadc4)
    //     0x12fadb8: tbz             w0, #0, #0x12fadc4
    // 0x12fadbc: r4 = LoadClassIdInstr(r0)
    //     0x12fadbc: ldur            x4, [x0, #-1]
    //     0x12fadc0: ubfx            x4, x4, #0xc, #0x14
    // 0x12fadc4: sub             x4, x4, #0xc77
    // 0x12fadc8: cmp             x4, #2
    // 0x12fadcc: b.ls            #0x12fade0
    // 0x12fadd0: r8 = _TrieNode?
    //     0x12fadd0: ldr             x8, [PP, #0x2008]  ; [pp+0x2008] Type: _TrieNode?
    // 0x12fadd4: r3 = Null
    //     0x12fadd4: add             x3, PP, #0x96, lsl #12  ; [pp+0x96a40] Null
    //     0x12fadd8: ldr             x3, [x3, #0xa40]
    // 0x12faddc: r0 = DefaultNullableTypeTest()
    //     0x12faddc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x12fade0: ldur            x1, [fp, #-8]
    // 0x12fade4: cmp             w1, NULL
    // 0x12fade8: b.ne            #0x12fadf4
    // 0x12fadec: r0 = Null
    //     0x12fadec: mov             x0, NULL
    // 0x12fadf0: b               #0x12fae18
    // 0x12fadf4: ldur            x0, [fp, #-0x10]
    // 0x12fadf8: add             x2, x0, #5
    // 0x12fadfc: r0 = LoadClassIdInstr(r1)
    //     0x12fadfc: ldur            x0, [x1, #-1]
    //     0x12fae00: ubfx            x0, x0, #0xc, #0x14
    // 0x12fae04: ldur            x3, [fp, #-0x18]
    // 0x12fae08: ldur            x5, [fp, #-0x20]
    // 0x12fae0c: r0 = GDT[cid_x0 + -0xffd]()
    //     0x12fae0c: sub             lr, x0, #0xffd
    //     0x12fae10: ldr             lr, [x21, lr, lsl #3]
    //     0x12fae14: blr             lr
    // 0x12fae18: LeaveFrame
    //     0x12fae18: mov             SP, fp
    //     0x12fae1c: ldp             fp, lr, [SP], #0x10
    // 0x12fae20: ret
    //     0x12fae20: ret             
    // 0x12fae24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fae24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fae28: b               #0x12fad60
    // 0x12fae2c: tbnz            x4, #0x3f, #0x12fae38
    // 0x12fae30: mov             x0, xzr
    // 0x12fae34: b               #0x12fad6c
    // 0x12fae38: str             x4, [THR, #0x8a0]  ; THR::
    // 0x12fae3c: stp             x4, x5, [SP, #-0x10]!
    // 0x12fae40: stp             x1, x3, [SP, #-0x10]!
    // 0x12fae44: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fae48: r4 = 0
    //     0x12fae48: mov             x4, #0
    // 0x12fae4c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fae50: blr             lr
    // 0x12fae54: brk             #0
    // 0x12fae58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fae58: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ put(/* No info */) {
    // ** addr: 0x12fb108, size: 0x254
    // 0x12fb108: EnterFrame
    //     0x12fb108: stp             fp, lr, [SP, #-0x10]!
    //     0x12fb10c: mov             fp, SP
    // 0x12fb110: AllocStack(0x50)
    //     0x12fb110: sub             SP, SP, #0x50
    // 0x12fb114: SetupParameters(_FullNode this /* r1 => r7, fp-0x30 */, dynamic _ /* r2 => r4, fp-0x38 */, dynamic _ /* r3 => r3, fp-0x40 */, dynamic _ /* r5 => r5, fp-0x48 */, dynamic _ /* r6 => r6, fp-0x50 */)
    //     0x12fb114: mov             x7, x1
    //     0x12fb118: mov             x4, x2
    //     0x12fb11c: stur            x1, [fp, #-0x30]
    //     0x12fb120: stur            x2, [fp, #-0x38]
    //     0x12fb124: stur            x3, [fp, #-0x40]
    //     0x12fb128: stur            x5, [fp, #-0x48]
    //     0x12fb12c: stur            x6, [fp, #-0x50]
    // 0x12fb130: CheckStackOverflow
    //     0x12fb130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb134: cmp             SP, x16
    //     0x12fb138: b.ls            #0x12fb318
    // 0x12fb13c: cmp             x4, #0x3f
    // 0x12fb140: b.hi            #0x12fb320
    // 0x12fb144: lsr             x0, x5, x4
    // 0x12fb148: ubfx            x0, x0, #0, #0x20
    // 0x12fb14c: and             w1, w0, #0x1f
    // 0x12fb150: LoadField: r8 = r7->field_7
    //     0x12fb150: ldur            w8, [x7, #7]
    // 0x12fb154: DecompressPointer r8
    //     0x12fb154: add             x8, x8, HEAP, lsl #32
    // 0x12fb158: stur            x8, [fp, #-0x28]
    // 0x12fb15c: LoadField: r9 = r8->field_b
    //     0x12fb15c: ldur            w9, [x8, #0xb]
    // 0x12fb160: stur            x9, [fp, #-0x20]
    // 0x12fb164: r10 = LoadInt32Instr(r9)
    //     0x12fb164: sbfx            x10, x9, #1, #0x1f
    // 0x12fb168: stur            x10, [fp, #-0x18]
    // 0x12fb16c: mov             x11, x1
    // 0x12fb170: ubfx            x11, x11, #0, #0x20
    // 0x12fb174: mov             x0, x10
    // 0x12fb178: mov             x1, x11
    // 0x12fb17c: stur            x11, [fp, #-0x10]
    // 0x12fb180: cmp             x1, x0
    // 0x12fb184: b.hs            #0x12fb350
    // 0x12fb188: ArrayLoad: r12 = r8[r11]  ; Unknown_4
    //     0x12fb188: add             x16, x8, x11, lsl #2
    //     0x12fb18c: ldur            w12, [x16, #0xf]
    // 0x12fb190: DecompressPointer r12
    //     0x12fb190: add             x12, x12, HEAP, lsl #32
    // 0x12fb194: mov             x0, x12
    // 0x12fb198: stur            x12, [fp, #-8]
    // 0x12fb19c: r2 = Null
    //     0x12fb19c: mov             x2, NULL
    // 0x12fb1a0: r1 = Null
    //     0x12fb1a0: mov             x1, NULL
    // 0x12fb1a4: r4 = 60
    //     0x12fb1a4: mov             x4, #0x3c
    // 0x12fb1a8: branchIfSmi(r0, 0x12fb1b4)
    //     0x12fb1a8: tbz             w0, #0, #0x12fb1b4
    // 0x12fb1ac: r4 = LoadClassIdInstr(r0)
    //     0x12fb1ac: ldur            x4, [x0, #-1]
    //     0x12fb1b0: ubfx            x4, x4, #0xc, #0x14
    // 0x12fb1b4: sub             x4, x4, #0xc77
    // 0x12fb1b8: cmp             x4, #2
    // 0x12fb1bc: b.ls            #0x12fb1d0
    // 0x12fb1c0: r8 = _TrieNode?
    //     0x12fb1c0: ldr             x8, [PP, #0x2008]  ; [pp+0x2008] Type: _TrieNode?
    // 0x12fb1c4: r3 = Null
    //     0x12fb1c4: add             x3, PP, #0x96, lsl #12  ; [pp+0x96a50] Null
    //     0x12fb1c8: ldr             x3, [x3, #0xa50]
    // 0x12fb1cc: r0 = DefaultNullableTypeTest()
    //     0x12fb1cc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x12fb1d0: ldur            x0, [fp, #-8]
    // 0x12fb1d4: cmp             w0, NULL
    // 0x12fb1d8: b.ne            #0x12fb204
    // 0x12fb1dc: r0 = LoadStaticField(0xbdc)
    //     0x12fb1dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12fb1e0: ldr             x0, [x0, #0x17b8]
    // 0x12fb1e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fb1e8: cmp             w0, w16
    // 0x12fb1ec: b.ne            #0x12fb1fc
    // 0x12fb1f0: r2 = empty
    //     0x12fb1f0: add             x2, PP, #0x85, lsl #12  ; [pp+0x85600] Field <_CompressedNode@596137193.empty>: static late final (offset: 0xbdc)
    //     0x12fb1f4: ldr             x2, [x2, #0x600]
    // 0x12fb1f8: r0 = InitLateFinalStaticField()
    //     0x12fb1f8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12fb1fc: mov             x4, x0
    // 0x12fb200: b               #0x12fb208
    // 0x12fb204: mov             x4, x0
    // 0x12fb208: ldur            x0, [fp, #-0x38]
    // 0x12fb20c: stur            x4, [fp, #-8]
    // 0x12fb210: add             x2, x0, #5
    // 0x12fb214: r0 = LoadClassIdInstr(r4)
    //     0x12fb214: ldur            x0, [x4, #-1]
    //     0x12fb218: ubfx            x0, x0, #0xc, #0x14
    // 0x12fb21c: mov             x1, x4
    // 0x12fb220: ldur            x3, [fp, #-0x40]
    // 0x12fb224: ldur            x5, [fp, #-0x48]
    // 0x12fb228: ldur            x6, [fp, #-0x50]
    // 0x12fb22c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12fb22c: sub             lr, x0, #1, lsl #12
    //     0x12fb230: ldr             lr, [x21, lr, lsl #3]
    //     0x12fb234: blr             lr
    // 0x12fb238: mov             x3, x0
    // 0x12fb23c: ldur            x0, [fp, #-8]
    // 0x12fb240: stur            x3, [fp, #-0x40]
    // 0x12fb244: cmp             w3, w0
    // 0x12fb248: b.ne            #0x12fb254
    // 0x12fb24c: ldur            x0, [fp, #-0x30]
    // 0x12fb250: b               #0x12fb30c
    // 0x12fb254: ldur            x2, [fp, #-0x20]
    // 0x12fb258: r1 = <Object?>
    //     0x12fb258: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x12fb25c: r0 = AllocateArray()
    //     0x12fb25c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12fb260: mov             x2, x0
    // 0x12fb264: stur            x2, [fp, #-8]
    // 0x12fb268: ldur            x3, [fp, #-0x28]
    // 0x12fb26c: ldur            x4, [fp, #-0x18]
    // 0x12fb270: r5 = 0
    //     0x12fb270: mov             x5, #0
    // 0x12fb274: CheckStackOverflow
    //     0x12fb274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fb278: cmp             SP, x16
    //     0x12fb27c: b.ls            #0x12fb354
    // 0x12fb280: cmp             x5, x4
    // 0x12fb284: b.ge            #0x12fb2cc
    // 0x12fb288: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0x12fb288: add             x16, x3, x5, lsl #2
    //     0x12fb28c: ldur            w0, [x16, #0xf]
    // 0x12fb290: DecompressPointer r0
    //     0x12fb290: add             x0, x0, HEAP, lsl #32
    // 0x12fb294: mov             x1, x2
    // 0x12fb298: ArrayStore: r1[r5] = r0  ; List_4
    //     0x12fb298: add             x25, x1, x5, lsl #2
    //     0x12fb29c: add             x25, x25, #0xf
    //     0x12fb2a0: str             w0, [x25]
    //     0x12fb2a4: tbz             w0, #0, #0x12fb2c0
    //     0x12fb2a8: ldurb           w16, [x1, #-1]
    //     0x12fb2ac: ldurb           w17, [x0, #-1]
    //     0x12fb2b0: and             x16, x17, x16, lsr #2
    //     0x12fb2b4: tst             x16, HEAP, lsr #32
    //     0x12fb2b8: b.eq            #0x12fb2c0
    //     0x12fb2bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb2c0: add             x0, x5, #1
    // 0x12fb2c4: mov             x5, x0
    // 0x12fb2c8: b               #0x12fb274
    // 0x12fb2cc: ldur            x3, [fp, #-0x10]
    // 0x12fb2d0: mov             x1, x2
    // 0x12fb2d4: ldur            x0, [fp, #-0x40]
    // 0x12fb2d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12fb2d8: add             x25, x1, x3, lsl #2
    //     0x12fb2dc: add             x25, x25, #0xf
    //     0x12fb2e0: str             w0, [x25]
    //     0x12fb2e4: tbz             w0, #0, #0x12fb300
    //     0x12fb2e8: ldurb           w16, [x1, #-1]
    //     0x12fb2ec: ldurb           w17, [x0, #-1]
    //     0x12fb2f0: and             x16, x17, x16, lsr #2
    //     0x12fb2f4: tst             x16, HEAP, lsr #32
    //     0x12fb2f8: b.eq            #0x12fb300
    //     0x12fb2fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12fb300: r0 = _FullNode()
    //     0x12fb300: bl              #0x12fb35c  ; Allocate_FullNodeStub -> _FullNode (size=0xc)
    // 0x12fb304: ldur            x1, [fp, #-8]
    // 0x12fb308: StoreField: r0->field_7 = r1
    //     0x12fb308: stur            w1, [x0, #7]
    // 0x12fb30c: LeaveFrame
    //     0x12fb30c: mov             SP, fp
    //     0x12fb310: ldp             fp, lr, [SP], #0x10
    // 0x12fb314: ret
    //     0x12fb314: ret             
    // 0x12fb318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fb318: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fb31c: b               #0x12fb13c
    // 0x12fb320: tbnz            x4, #0x3f, #0x12fb32c
    // 0x12fb324: mov             x0, xzr
    // 0x12fb328: b               #0x12fb148
    // 0x12fb32c: str             x4, [THR, #0x8a0]  ; THR::
    // 0x12fb330: stp             x6, x7, [SP, #-0x10]!
    // 0x12fb334: stp             x4, x5, [SP, #-0x10]!
    // 0x12fb338: SaveReg r3
    //     0x12fb338: str             x3, [SP, #-8]!
    // 0x12fb33c: ldr             x5, [THR, #0x470]  ; THR::ArgumentErrorUnboxedInt64
    // 0x12fb340: r4 = 0
    //     0x12fb340: mov             x4, #0
    // 0x12fb344: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12fb348: blr             lr
    // 0x12fb34c: brk             #0
    // 0x12fb350: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12fb350: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12fb354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fb354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fb358: b               #0x12fb280
  }
}

// class id: 3194, size: 0x10, field offset: 0x8
//   const constructor, 
class PersistentHashMap<X0, X1> extends Object {

  X1? [](PersistentHashMap<X0, X1>, X0) {
    // ** addr: 0x8423d4, size: 0x264
    // 0x8423d4: EnterFrame
    //     0x8423d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8423d8: mov             fp, SP
    // 0x8423dc: AllocStack(0x30)
    //     0x8423dc: sub             SP, SP, #0x30
    // 0x8423e0: SetupParameters(PersistentHashMap<X0, X1> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x8423e0: mov             x4, x1
    //     0x8423e4: mov             x3, x2
    //     0x8423e8: stur            x1, [fp, #-0x10]
    //     0x8423ec: stur            x2, [fp, #-0x18]
    // 0x8423f0: CheckStackOverflow
    //     0x8423f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8423f4: cmp             SP, x16
    //     0x8423f8: b.ls            #0x842628
    // 0x8423fc: LoadField: r5 = r4->field_7
    //     0x8423fc: ldur            w5, [x4, #7]
    // 0x842400: DecompressPointer r5
    //     0x842400: add             x5, x5, HEAP, lsl #32
    // 0x842404: mov             x0, x3
    // 0x842408: mov             x2, x5
    // 0x84240c: stur            x5, [fp, #-8]
    // 0x842410: r1 = Null
    //     0x842410: mov             x1, NULL
    // 0x842414: cmp             w2, NULL
    // 0x842418: b.eq            #0x842434
    // 0x84241c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84241c: ldur            w4, [x2, #0x17]
    // 0x842420: DecompressPointer r4
    //     0x842420: add             x4, x4, HEAP, lsl #32
    // 0x842424: r8 = X0
    //     0x842424: ldr             x8, [PP, #0x1ff0]  ; [pp+0x1ff0] TypeParameter: X0
    // 0x842428: LoadField: r9 = r4->field_7
    //     0x842428: ldur            x9, [x4, #7]
    // 0x84242c: r3 = Null
    //     0x84242c: ldr             x3, [PP, #0x1ff8]  ; [pp+0x1ff8] Null
    // 0x842430: blr             x9
    // 0x842434: ldur            x0, [fp, #-0x10]
    // 0x842438: LoadField: r1 = r0->field_b
    //     0x842438: ldur            w1, [x0, #0xb]
    // 0x84243c: DecompressPointer r1
    //     0x84243c: add             x1, x1, HEAP, lsl #32
    // 0x842440: stur            x1, [fp, #-0x20]
    // 0x842444: cmp             w1, NULL
    // 0x842448: b.ne            #0x842454
    // 0x84244c: r3 = Null
    //     0x84244c: mov             x3, NULL
    // 0x842450: b               #0x8425e0
    // 0x842454: ldur            x2, [fp, #-0x18]
    // 0x842458: r0 = 60
    //     0x842458: mov             x0, #0x3c
    // 0x84245c: branchIfSmi(r2, 0x842468)
    //     0x84245c: tbz             w2, #0, #0x842468
    // 0x842460: r0 = LoadClassIdInstr(r2)
    //     0x842460: ldur            x0, [x2, #-1]
    //     0x842464: ubfx            x0, x0, #0xc, #0x14
    // 0x842468: str             x2, [SP]
    // 0x84246c: r0 = GDT[cid_x0 + 0x70de]()
    //     0x84246c: mov             x17, #0x70de
    //     0x842470: add             lr, x0, x17
    //     0x842474: ldr             lr, [x21, lr, lsl #3]
    //     0x842478: blr             lr
    // 0x84247c: mov             x1, x0
    // 0x842480: ldur            x0, [fp, #-0x20]
    // 0x842484: r2 = LoadClassIdInstr(r0)
    //     0x842484: ldur            x2, [x0, #-1]
    //     0x842488: ubfx            x2, x2, #0xc, #0x14
    // 0x84248c: cmp             x2, #0xc77
    // 0x842490: b.ne            #0x8424e4
    // 0x842494: mov             x1, x0
    // 0x842498: ldur            x2, [fp, #-0x18]
    // 0x84249c: r0 = _indexOf()
    //     0x84249c: bl              #0x842684  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0x8424a0: tbz             x0, #0x3f, #0x8424ac
    // 0x8424a4: r0 = Null
    //     0x8424a4: mov             x0, NULL
    // 0x8424a8: b               #0x8425dc
    // 0x8424ac: ldur            x3, [fp, #-0x20]
    // 0x8424b0: LoadField: r2 = r3->field_f
    //     0x8424b0: ldur            w2, [x3, #0xf]
    // 0x8424b4: DecompressPointer r2
    //     0x8424b4: add             x2, x2, HEAP, lsl #32
    // 0x8424b8: add             x3, x0, #1
    // 0x8424bc: LoadField: r0 = r2->field_b
    //     0x8424bc: ldur            w0, [x2, #0xb]
    // 0x8424c0: r1 = LoadInt32Instr(r0)
    //     0x8424c0: sbfx            x1, x0, #1, #0x1f
    // 0x8424c4: mov             x0, x1
    // 0x8424c8: mov             x1, x3
    // 0x8424cc: cmp             x1, x0
    // 0x8424d0: b.hs            #0x842630
    // 0x8424d4: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x8424d4: add             x16, x2, x3, lsl #2
    //     0x8424d8: ldur            w0, [x16, #0xf]
    // 0x8424dc: DecompressPointer r0
    //     0x8424dc: add             x0, x0, HEAP, lsl #32
    // 0x8424e0: b               #0x8425dc
    // 0x8424e4: mov             x3, x0
    // 0x8424e8: cmp             x2, #0xc79
    // 0x8424ec: b.ne            #0x8425b0
    // 0x8424f0: r5 = LoadInt32Instr(r1)
    //     0x8424f0: sbfx            x5, x1, #1, #0x1f
    //     0x8424f4: tbz             w1, #0, #0x8424fc
    //     0x8424f8: ldur            x5, [x1, #7]
    // 0x8424fc: stur            x5, [fp, #-0x28]
    // 0x842500: mov             x0, x5
    // 0x842504: ubfx            x0, x0, #0, #0x20
    // 0x842508: and             w1, w0, #0x1f
    // 0x84250c: LoadField: r2 = r3->field_7
    //     0x84250c: ldur            w2, [x3, #7]
    // 0x842510: DecompressPointer r2
    //     0x842510: add             x2, x2, HEAP, lsl #32
    // 0x842514: LoadField: r0 = r2->field_b
    //     0x842514: ldur            w0, [x2, #0xb]
    // 0x842518: r3 = LoadInt32Instr(r0)
    //     0x842518: sbfx            x3, x0, #1, #0x1f
    // 0x84251c: mov             x4, x1
    // 0x842520: ubfx            x4, x4, #0, #0x20
    // 0x842524: mov             x0, x3
    // 0x842528: mov             x1, x4
    // 0x84252c: cmp             x1, x0
    // 0x842530: b.hs            #0x842634
    // 0x842534: ArrayLoad: r3 = r2[r4]  ; Unknown_4
    //     0x842534: add             x16, x2, x4, lsl #2
    //     0x842538: ldur            w3, [x16, #0xf]
    // 0x84253c: DecompressPointer r3
    //     0x84253c: add             x3, x3, HEAP, lsl #32
    // 0x842540: mov             x0, x3
    // 0x842544: stur            x3, [fp, #-0x10]
    // 0x842548: r2 = Null
    //     0x842548: mov             x2, NULL
    // 0x84254c: r1 = Null
    //     0x84254c: mov             x1, NULL
    // 0x842550: r4 = 60
    //     0x842550: mov             x4, #0x3c
    // 0x842554: branchIfSmi(r0, 0x842560)
    //     0x842554: tbz             w0, #0, #0x842560
    // 0x842558: r4 = LoadClassIdInstr(r0)
    //     0x842558: ldur            x4, [x0, #-1]
    //     0x84255c: ubfx            x4, x4, #0xc, #0x14
    // 0x842560: sub             x4, x4, #0xc77
    // 0x842564: cmp             x4, #2
    // 0x842568: b.ls            #0x842578
    // 0x84256c: r8 = _TrieNode?
    //     0x84256c: ldr             x8, [PP, #0x2008]  ; [pp+0x2008] Type: _TrieNode?
    // 0x842570: r3 = Null
    //     0x842570: ldr             x3, [PP, #0x2010]  ; [pp+0x2010] Null
    // 0x842574: r0 = DefaultNullableTypeTest()
    //     0x842574: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x842578: ldur            x1, [fp, #-0x10]
    // 0x84257c: cmp             w1, NULL
    // 0x842580: b.ne            #0x84258c
    // 0x842584: r0 = Null
    //     0x842584: mov             x0, NULL
    // 0x842588: b               #0x8425dc
    // 0x84258c: r0 = LoadClassIdInstr(r1)
    //     0x84258c: ldur            x0, [x1, #-1]
    //     0x842590: ubfx            x0, x0, #0xc, #0x14
    // 0x842594: ldur            x3, [fp, #-0x18]
    // 0x842598: ldur            x5, [fp, #-0x28]
    // 0x84259c: r2 = 5
    //     0x84259c: mov             x2, #5
    // 0x8425a0: r0 = GDT[cid_x0 + -0xffd]()
    //     0x8425a0: sub             lr, x0, #0xffd
    //     0x8425a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8425a8: blr             lr
    // 0x8425ac: b               #0x8425dc
    // 0x8425b0: r5 = LoadInt32Instr(r1)
    //     0x8425b0: sbfx            x5, x1, #1, #0x1f
    //     0x8425b4: tbz             w1, #0, #0x8425bc
    //     0x8425b8: ldur            x5, [x1, #7]
    // 0x8425bc: r0 = LoadClassIdInstr(r3)
    //     0x8425bc: ldur            x0, [x3, #-1]
    //     0x8425c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8425c4: mov             x1, x3
    // 0x8425c8: ldur            x3, [fp, #-0x18]
    // 0x8425cc: r2 = 0
    //     0x8425cc: mov             x2, #0
    // 0x8425d0: r0 = GDT[cid_x0 + -0xffd]()
    //     0x8425d0: sub             lr, x0, #0xffd
    //     0x8425d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8425d8: blr             lr
    // 0x8425dc: mov             x3, x0
    // 0x8425e0: mov             x0, x3
    // 0x8425e4: ldur            x2, [fp, #-8]
    // 0x8425e8: stur            x3, [fp, #-0x10]
    // 0x8425ec: r1 = Null
    //     0x8425ec: mov             x1, NULL
    // 0x8425f0: cmp             w0, NULL
    // 0x8425f4: b.eq            #0x842618
    // 0x8425f8: cmp             w2, NULL
    // 0x8425fc: b.eq            #0x842618
    // 0x842600: LoadField: r4 = r2->field_1b
    //     0x842600: ldur            w4, [x2, #0x1b]
    // 0x842604: DecompressPointer r4
    //     0x842604: add             x4, x4, HEAP, lsl #32
    // 0x842608: r8 = X1?
    //     0x842608: ldr             x8, [PP, #0x2020]  ; [pp+0x2020] TypeParameter: X1?
    // 0x84260c: LoadField: r9 = r4->field_7
    //     0x84260c: ldur            x9, [x4, #7]
    // 0x842610: r3 = Null
    //     0x842610: ldr             x3, [PP, #0x2028]  ; [pp+0x2028] Null
    // 0x842614: blr             x9
    // 0x842618: ldur            x0, [fp, #-0x10]
    // 0x84261c: LeaveFrame
    //     0x84261c: mov             SP, fp
    //     0x842620: ldp             fp, lr, [SP], #0x10
    // 0x842624: ret
    //     0x842624: ret             
    // 0x842628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842628: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84262c: b               #0x8423fc
    // 0x842630: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x842630: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x842634: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x842634: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  X1? [](PersistentHashMap<X0, X1>, X0) {
    // ** addr: 0x842650, size: 0x4c
    // 0x842650: EnterFrame
    //     0x842650: stp             fp, lr, [SP, #-0x10]!
    //     0x842654: mov             fp, SP
    // 0x842658: CheckStackOverflow
    //     0x842658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84265c: cmp             SP, x16
    //     0x842660: b.ls            #0x84267c
    // 0x842664: ldr             x1, [fp, #0x18]
    // 0x842668: ldr             x2, [fp, #0x10]
    // 0x84266c: r0 = []()
    //     0x84266c: bl              #0x8423d4  ; [package:flutter/src/foundation/persistent_hash_map.dart] PersistentHashMap::[]
    // 0x842670: LeaveFrame
    //     0x842670: mov             SP, fp
    //     0x842674: ldp             fp, lr, [SP], #0x10
    // 0x842678: ret
    //     0x842678: ret             
    // 0x84267c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84267c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842680: b               #0x842664
  }
  _ put(/* No info */) {
    // ** addr: 0x1108af0, size: 0x160
    // 0x1108af0: EnterFrame
    //     0x1108af0: stp             fp, lr, [SP, #-0x10]!
    //     0x1108af4: mov             fp, SP
    // 0x1108af8: AllocStack(0x38)
    //     0x1108af8: sub             SP, SP, #0x38
    // 0x1108afc: SetupParameters(PersistentHashMap<X0, X1> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x1108afc: mov             x5, x1
    //     0x1108b00: mov             x4, x2
    //     0x1108b04: stur            x1, [fp, #-0x10]
    //     0x1108b08: stur            x2, [fp, #-0x18]
    //     0x1108b0c: stur            x3, [fp, #-0x20]
    // 0x1108b10: CheckStackOverflow
    //     0x1108b10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1108b14: cmp             SP, x16
    //     0x1108b18: b.ls            #0x1108c48
    // 0x1108b1c: LoadField: r6 = r5->field_7
    //     0x1108b1c: ldur            w6, [x5, #7]
    // 0x1108b20: DecompressPointer r6
    //     0x1108b20: add             x6, x6, HEAP, lsl #32
    // 0x1108b24: mov             x0, x4
    // 0x1108b28: mov             x2, x6
    // 0x1108b2c: stur            x6, [fp, #-8]
    // 0x1108b30: r1 = Null
    //     0x1108b30: mov             x1, NULL
    // 0x1108b34: cmp             w2, NULL
    // 0x1108b38: b.eq            #0x1108b58
    // 0x1108b3c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1108b3c: ldur            w4, [x2, #0x17]
    // 0x1108b40: DecompressPointer r4
    //     0x1108b40: add             x4, x4, HEAP, lsl #32
    // 0x1108b44: r8 = X0
    //     0x1108b44: ldr             x8, [PP, #0x1ff0]  ; [pp+0x1ff0] TypeParameter: X0
    // 0x1108b48: LoadField: r9 = r4->field_7
    //     0x1108b48: ldur            x9, [x4, #7]
    // 0x1108b4c: r3 = Null
    //     0x1108b4c: add             x3, PP, #0x85, lsl #12  ; [pp+0x855e0] Null
    //     0x1108b50: ldr             x3, [x3, #0x5e0]
    // 0x1108b54: blr             x9
    // 0x1108b58: ldur            x0, [fp, #-0x20]
    // 0x1108b5c: ldur            x2, [fp, #-8]
    // 0x1108b60: r1 = Null
    //     0x1108b60: mov             x1, NULL
    // 0x1108b64: cmp             w2, NULL
    // 0x1108b68: b.eq            #0x1108b88
    // 0x1108b6c: LoadField: r4 = r2->field_1b
    //     0x1108b6c: ldur            w4, [x2, #0x1b]
    // 0x1108b70: DecompressPointer r4
    //     0x1108b70: add             x4, x4, HEAP, lsl #32
    // 0x1108b74: r8 = X1
    //     0x1108b74: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x1108b78: LoadField: r9 = r4->field_7
    //     0x1108b78: ldur            x9, [x4, #7]
    // 0x1108b7c: r3 = Null
    //     0x1108b7c: add             x3, PP, #0x85, lsl #12  ; [pp+0x855f0] Null
    //     0x1108b80: ldr             x3, [x3, #0x5f0]
    // 0x1108b84: blr             x9
    // 0x1108b88: ldur            x0, [fp, #-0x10]
    // 0x1108b8c: LoadField: r1 = r0->field_b
    //     0x1108b8c: ldur            w1, [x0, #0xb]
    // 0x1108b90: DecompressPointer r1
    //     0x1108b90: add             x1, x1, HEAP, lsl #32
    // 0x1108b94: stur            x1, [fp, #-0x28]
    // 0x1108b98: cmp             w1, NULL
    // 0x1108b9c: b.ne            #0x1108bc8
    // 0x1108ba0: r0 = LoadStaticField(0xbdc)
    //     0x1108ba0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1108ba4: ldr             x0, [x0, #0x17b8]
    // 0x1108ba8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1108bac: cmp             w0, w16
    // 0x1108bb0: b.ne            #0x1108bc0
    // 0x1108bb4: r2 = empty
    //     0x1108bb4: add             x2, PP, #0x85, lsl #12  ; [pp+0x85600] Field <_CompressedNode@596137193.empty>: static late final (offset: 0xbdc)
    //     0x1108bb8: ldr             x2, [x2, #0x600]
    // 0x1108bbc: r0 = InitLateFinalStaticField()
    //     0x1108bbc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x1108bc0: mov             x1, x0
    // 0x1108bc4: b               #0x1108bcc
    // 0x1108bc8: ldur            x1, [fp, #-0x28]
    // 0x1108bcc: ldur            x0, [fp, #-0x28]
    // 0x1108bd0: stur            x1, [fp, #-0x30]
    // 0x1108bd4: ldur            x16, [fp, #-0x18]
    // 0x1108bd8: str             x16, [SP]
    // 0x1108bdc: r0 = hashCode()
    //     0x1108bdc: bl              #0x1159bf4  ; [dart:core] _AbstractType::hashCode
    // 0x1108be0: r5 = LoadInt32Instr(r0)
    //     0x1108be0: sbfx            x5, x0, #1, #0x1f
    // 0x1108be4: ldur            x1, [fp, #-0x30]
    // 0x1108be8: r0 = LoadClassIdInstr(r1)
    //     0x1108be8: ldur            x0, [x1, #-1]
    //     0x1108bec: ubfx            x0, x0, #0xc, #0x14
    // 0x1108bf0: ldur            x3, [fp, #-0x18]
    // 0x1108bf4: ldur            x6, [fp, #-0x20]
    // 0x1108bf8: r2 = 0
    //     0x1108bf8: mov             x2, #0
    // 0x1108bfc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1108bfc: sub             lr, x0, #1, lsl #12
    //     0x1108c00: ldr             lr, [x21, lr, lsl #3]
    //     0x1108c04: blr             lr
    // 0x1108c08: mov             x2, x0
    // 0x1108c0c: ldur            x0, [fp, #-0x28]
    // 0x1108c10: stur            x2, [fp, #-0x18]
    // 0x1108c14: cmp             w2, w0
    // 0x1108c18: b.ne            #0x1108c2c
    // 0x1108c1c: ldur            x0, [fp, #-0x10]
    // 0x1108c20: LeaveFrame
    //     0x1108c20: mov             SP, fp
    //     0x1108c24: ldp             fp, lr, [SP], #0x10
    // 0x1108c28: ret
    //     0x1108c28: ret             
    // 0x1108c2c: ldur            x1, [fp, #-8]
    // 0x1108c30: r0 = PersistentHashMap()
    //     0x1108c30: bl              #0x1108c50  ; AllocatePersistentHashMapStub -> PersistentHashMap<X0, X1> (size=0x10)
    // 0x1108c34: ldur            x1, [fp, #-0x18]
    // 0x1108c38: StoreField: r0->field_b = r1
    //     0x1108c38: stur            w1, [x0, #0xb]
    // 0x1108c3c: LeaveFrame
    //     0x1108c3c: mov             SP, fp
    //     0x1108c40: ldp             fp, lr, [SP], #0x10
    // 0x1108c44: ret
    //     0x1108c44: ret             
    // 0x1108c48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1108c48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1108c4c: b               #0x1108b1c
  }
}
