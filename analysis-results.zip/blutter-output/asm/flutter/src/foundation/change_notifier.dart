// lib: , url: package:flutter/src/foundation/change_notifier.dart

// class id: 1048799, size: 0x8
class :: {
}

// class id: 4299, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Listenable extends Object {
}

// class id: 4310, size: 0xc, field offset: 0x8
class _MergingListenable extends Listenable {

  _ removeListener(/* No info */) {
    // ** addr: 0xd012d0, size: 0x144
    // 0xd012d0: EnterFrame
    //     0xd012d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd012d4: mov             fp, SP
    // 0xd012d8: AllocStack(0x30)
    //     0xd012d8: sub             SP, SP, #0x30
    // 0xd012dc: SetupParameters(dynamic _ /* r2 => r3, fp-0x30 */)
    //     0xd012dc: mov             x3, x2
    //     0xd012e0: stur            x2, [fp, #-0x30]
    // 0xd012e4: CheckStackOverflow
    //     0xd012e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd012e8: cmp             SP, x16
    //     0xd012ec: b.ls            #0xd01404
    // 0xd012f0: LoadField: r4 = r1->field_7
    //     0xd012f0: ldur            w4, [x1, #7]
    // 0xd012f4: DecompressPointer r4
    //     0xd012f4: add             x4, x4, HEAP, lsl #32
    // 0xd012f8: stur            x4, [fp, #-0x28]
    // 0xd012fc: LoadField: r5 = r4->field_7
    //     0xd012fc: ldur            w5, [x4, #7]
    // 0xd01300: DecompressPointer r5
    //     0xd01300: add             x5, x5, HEAP, lsl #32
    // 0xd01304: stur            x5, [fp, #-0x20]
    // 0xd01308: LoadField: r0 = r4->field_b
    //     0xd01308: ldur            w0, [x4, #0xb]
    // 0xd0130c: r6 = LoadInt32Instr(r0)
    //     0xd0130c: sbfx            x6, x0, #1, #0x1f
    // 0xd01310: stur            x6, [fp, #-0x18]
    // 0xd01314: r0 = 0
    //     0xd01314: mov             x0, #0
    // 0xd01318: CheckStackOverflow
    //     0xd01318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0131c: cmp             SP, x16
    //     0xd01320: b.ls            #0xd0140c
    // 0xd01324: LoadField: r1 = r4->field_b
    //     0xd01324: ldur            w1, [x4, #0xb]
    // 0xd01328: r2 = LoadInt32Instr(r1)
    //     0xd01328: sbfx            x2, x1, #1, #0x1f
    // 0xd0132c: cmp             x6, x2
    // 0xd01330: b.ne            #0xd013e4
    // 0xd01334: cmp             x0, x2
    // 0xd01338: b.ge            #0xd013d4
    // 0xd0133c: LoadField: r1 = r4->field_f
    //     0xd0133c: ldur            w1, [x4, #0xf]
    // 0xd01340: DecompressPointer r1
    //     0xd01340: add             x1, x1, HEAP, lsl #32
    // 0xd01344: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xd01344: add             x16, x1, x0, lsl #2
    //     0xd01348: ldur            w7, [x16, #0xf]
    // 0xd0134c: DecompressPointer r7
    //     0xd0134c: add             x7, x7, HEAP, lsl #32
    // 0xd01350: stur            x7, [fp, #-0x10]
    // 0xd01354: add             x8, x0, #1
    // 0xd01358: stur            x8, [fp, #-8]
    // 0xd0135c: cmp             w7, NULL
    // 0xd01360: b.ne            #0xd01394
    // 0xd01364: mov             x0, x7
    // 0xd01368: mov             x2, x5
    // 0xd0136c: r1 = Null
    //     0xd0136c: mov             x1, NULL
    // 0xd01370: cmp             w2, NULL
    // 0xd01374: b.eq            #0xd01394
    // 0xd01378: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd01378: ldur            w4, [x2, #0x17]
    // 0xd0137c: DecompressPointer r4
    //     0xd0137c: add             x4, x4, HEAP, lsl #32
    // 0xd01380: r8 = X0
    //     0xd01380: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd01384: LoadField: r9 = r4->field_7
    //     0xd01384: ldur            x9, [x4, #7]
    // 0xd01388: r3 = Null
    //     0xd01388: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a820] Null
    //     0xd0138c: ldr             x3, [x3, #0x820]
    // 0xd01390: blr             x9
    // 0xd01394: ldur            x1, [fp, #-0x10]
    // 0xd01398: cmp             w1, NULL
    // 0xd0139c: b.eq            #0xd013bc
    // 0xd013a0: r0 = LoadClassIdInstr(r1)
    //     0xd013a0: ldur            x0, [x1, #-1]
    //     0xd013a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd013a8: ldur            x2, [fp, #-0x30]
    // 0xd013ac: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xd013ac: mov             x17, #0xe2a3
    //     0xd013b0: add             lr, x0, x17
    //     0xd013b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd013b8: blr             lr
    // 0xd013bc: ldur            x0, [fp, #-8]
    // 0xd013c0: ldur            x3, [fp, #-0x30]
    // 0xd013c4: ldur            x4, [fp, #-0x28]
    // 0xd013c8: ldur            x5, [fp, #-0x20]
    // 0xd013cc: ldur            x6, [fp, #-0x18]
    // 0xd013d0: b               #0xd01318
    // 0xd013d4: r0 = Null
    //     0xd013d4: mov             x0, NULL
    // 0xd013d8: LeaveFrame
    //     0xd013d8: mov             SP, fp
    //     0xd013dc: ldp             fp, lr, [SP], #0x10
    // 0xd013e0: ret
    //     0xd013e0: ret             
    // 0xd013e4: mov             x0, x4
    // 0xd013e8: r0 = ConcurrentModificationError()
    //     0xd013e8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd013ec: mov             x1, x0
    // 0xd013f0: ldur            x0, [fp, #-0x28]
    // 0xd013f4: StoreField: r1->field_b = r0
    //     0xd013f4: stur            w0, [x1, #0xb]
    // 0xd013f8: mov             x0, x1
    // 0xd013fc: r0 = Throw()
    //     0xd013fc: bl              #0x13ddb2c  ; ThrowStub
    // 0xd01400: brk             #0
    // 0xd01404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01408: b               #0xd012f0
    // 0xd0140c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0140c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01410: b               #0xd01324
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd04880, size: 0x144
    // 0xd04880: EnterFrame
    //     0xd04880: stp             fp, lr, [SP, #-0x10]!
    //     0xd04884: mov             fp, SP
    // 0xd04888: AllocStack(0x30)
    //     0xd04888: sub             SP, SP, #0x30
    // 0xd0488c: SetupParameters(dynamic _ /* r2 => r3, fp-0x30 */)
    //     0xd0488c: mov             x3, x2
    //     0xd04890: stur            x2, [fp, #-0x30]
    // 0xd04894: CheckStackOverflow
    //     0xd04894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04898: cmp             SP, x16
    //     0xd0489c: b.ls            #0xd049b4
    // 0xd048a0: LoadField: r4 = r1->field_7
    //     0xd048a0: ldur            w4, [x1, #7]
    // 0xd048a4: DecompressPointer r4
    //     0xd048a4: add             x4, x4, HEAP, lsl #32
    // 0xd048a8: stur            x4, [fp, #-0x28]
    // 0xd048ac: LoadField: r5 = r4->field_7
    //     0xd048ac: ldur            w5, [x4, #7]
    // 0xd048b0: DecompressPointer r5
    //     0xd048b0: add             x5, x5, HEAP, lsl #32
    // 0xd048b4: stur            x5, [fp, #-0x20]
    // 0xd048b8: LoadField: r0 = r4->field_b
    //     0xd048b8: ldur            w0, [x4, #0xb]
    // 0xd048bc: r6 = LoadInt32Instr(r0)
    //     0xd048bc: sbfx            x6, x0, #1, #0x1f
    // 0xd048c0: stur            x6, [fp, #-0x18]
    // 0xd048c4: r0 = 0
    //     0xd048c4: mov             x0, #0
    // 0xd048c8: CheckStackOverflow
    //     0xd048c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd048cc: cmp             SP, x16
    //     0xd048d0: b.ls            #0xd049bc
    // 0xd048d4: LoadField: r1 = r4->field_b
    //     0xd048d4: ldur            w1, [x4, #0xb]
    // 0xd048d8: r2 = LoadInt32Instr(r1)
    //     0xd048d8: sbfx            x2, x1, #1, #0x1f
    // 0xd048dc: cmp             x6, x2
    // 0xd048e0: b.ne            #0xd04994
    // 0xd048e4: cmp             x0, x2
    // 0xd048e8: b.ge            #0xd04984
    // 0xd048ec: LoadField: r1 = r4->field_f
    //     0xd048ec: ldur            w1, [x4, #0xf]
    // 0xd048f0: DecompressPointer r1
    //     0xd048f0: add             x1, x1, HEAP, lsl #32
    // 0xd048f4: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xd048f4: add             x16, x1, x0, lsl #2
    //     0xd048f8: ldur            w7, [x16, #0xf]
    // 0xd048fc: DecompressPointer r7
    //     0xd048fc: add             x7, x7, HEAP, lsl #32
    // 0xd04900: stur            x7, [fp, #-0x10]
    // 0xd04904: add             x8, x0, #1
    // 0xd04908: stur            x8, [fp, #-8]
    // 0xd0490c: cmp             w7, NULL
    // 0xd04910: b.ne            #0xd04944
    // 0xd04914: mov             x0, x7
    // 0xd04918: mov             x2, x5
    // 0xd0491c: r1 = Null
    //     0xd0491c: mov             x1, NULL
    // 0xd04920: cmp             w2, NULL
    // 0xd04924: b.eq            #0xd04944
    // 0xd04928: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd04928: ldur            w4, [x2, #0x17]
    // 0xd0492c: DecompressPointer r4
    //     0xd0492c: add             x4, x4, HEAP, lsl #32
    // 0xd04930: r8 = X0
    //     0xd04930: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd04934: LoadField: r9 = r4->field_7
    //     0xd04934: ldur            x9, [x4, #7]
    // 0xd04938: r3 = Null
    //     0xd04938: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a830] Null
    //     0xd0493c: ldr             x3, [x3, #0x830]
    // 0xd04940: blr             x9
    // 0xd04944: ldur            x1, [fp, #-0x10]
    // 0xd04948: cmp             w1, NULL
    // 0xd0494c: b.eq            #0xd0496c
    // 0xd04950: r0 = LoadClassIdInstr(r1)
    //     0xd04950: ldur            x0, [x1, #-1]
    //     0xd04954: ubfx            x0, x0, #0xc, #0x14
    // 0xd04958: ldur            x2, [fp, #-0x30]
    // 0xd0495c: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xd0495c: mov             x17, #0xe0ec
    //     0xd04960: add             lr, x0, x17
    //     0xd04964: ldr             lr, [x21, lr, lsl #3]
    //     0xd04968: blr             lr
    // 0xd0496c: ldur            x0, [fp, #-8]
    // 0xd04970: ldur            x3, [fp, #-0x30]
    // 0xd04974: ldur            x4, [fp, #-0x28]
    // 0xd04978: ldur            x5, [fp, #-0x20]
    // 0xd0497c: ldur            x6, [fp, #-0x18]
    // 0xd04980: b               #0xd048c8
    // 0xd04984: r0 = Null
    //     0xd04984: mov             x0, NULL
    // 0xd04988: LeaveFrame
    //     0xd04988: mov             SP, fp
    //     0xd0498c: ldp             fp, lr, [SP], #0x10
    // 0xd04990: ret
    //     0xd04990: ret             
    // 0xd04994: mov             x0, x4
    // 0xd04998: r0 = ConcurrentModificationError()
    //     0xd04998: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd0499c: mov             x1, x0
    // 0xd049a0: ldur            x0, [fp, #-0x28]
    // 0xd049a4: StoreField: r1->field_b = r0
    //     0xd049a4: stur            w0, [x1, #0xb]
    // 0xd049a8: mov             x0, x1
    // 0xd049ac: r0 = Throw()
    //     0xd049ac: bl              #0x13ddb2c  ; ThrowStub
    // 0xd049b0: brk             #0
    // 0xd049b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd049b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd049b8: b               #0xd048a0
    // 0xd049bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd049bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd049c0: b               #0xd048d4
  }
}

// class id: 4380, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ValueListenable<X0> extends Listenable {
}

// class id: 4455, size: 0x24, field offset: 0x8
class ChangeNotifier extends Object
    implements Listenable {

  static late final List<((dynamic) => void)?> _emptyListeners; // offset: 0x45c

  _ notifyListeners(/* No info */) {
    // ** addr: 0x833be0, size: 0x548
    // 0x833be0: EnterFrame
    //     0x833be0: stp             fp, lr, [SP, #-0x10]!
    //     0x833be4: mov             fp, SP
    // 0x833be8: AllocStack(0xf0)
    //     0x833be8: sub             SP, SP, #0xf0
    // 0x833bec: SetupParameters(ChangeNotifier this /* r1 => r1, fp-0x88 */)
    //     0x833bec: stur            x1, [fp, #-0x88]
    // 0x833bf0: CheckStackOverflow
    //     0x833bf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833bf4: cmp             SP, x16
    //     0x833bf8: b.ls            #0x8340ec
    // 0x833bfc: r1 = 1
    //     0x833bfc: mov             x1, #1
    // 0x833c00: r0 = AllocateContext()
    //     0x833c00: bl              #0x13de838  ; AllocateContextStub
    // 0x833c04: mov             x3, x0
    // 0x833c08: ldur            x2, [fp, #-0x88]
    // 0x833c0c: stur            x3, [fp, #-0xb8]
    // 0x833c10: StoreField: r3->field_f = r2
    //     0x833c10: stur            w2, [x3, #0xf]
    // 0x833c14: LoadField: r4 = r2->field_7
    //     0x833c14: ldur            x4, [x2, #7]
    // 0x833c18: stur            x4, [fp, #-0xb0]
    // 0x833c1c: cbnz            x4, #0x833c30
    // 0x833c20: r0 = Null
    //     0x833c20: mov             x0, NULL
    // 0x833c24: LeaveFrame
    //     0x833c24: mov             SP, fp
    //     0x833c28: ldp             fp, lr, [SP], #0x10
    // 0x833c2c: ret
    //     0x833c2c: ret             
    // 0x833c30: LoadField: r0 = r2->field_13
    //     0x833c30: ldur            x0, [x2, #0x13]
    // 0x833c34: add             x1, x0, #1
    // 0x833c38: StoreField: r2->field_13 = r1
    //     0x833c38: stur            x1, [x2, #0x13]
    // 0x833c3c: r7 = 0
    //     0x833c3c: mov             x7, #0
    // 0x833c40: r6 = Null
    //     0x833c40: mov             x6, NULL
    // 0x833c44: r5 = Null
    //     0x833c44: mov             x5, NULL
    // 0x833c48: stur            x7, [fp, #-0x98]
    // 0x833c4c: stur            x6, [fp, #-0xa0]
    // 0x833c50: stur            x5, [fp, #-0xa8]
    // 0x833c54: CheckStackOverflow
    //     0x833c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833c58: cmp             SP, x16
    //     0x833c5c: b.ls            #0x8340f4
    // 0x833c60: cmp             x7, x4
    // 0x833c64: b.ge            #0x833df0
    // 0x833c68: LoadField: r8 = r2->field_f
    //     0x833c68: ldur            w8, [x2, #0xf]
    // 0x833c6c: DecompressPointer r8
    //     0x833c6c: add             x8, x8, HEAP, lsl #32
    // 0x833c70: LoadField: r0 = r8->field_b
    //     0x833c70: ldur            w0, [x8, #0xb]
    // 0x833c74: r1 = LoadInt32Instr(r0)
    //     0x833c74: sbfx            x1, x0, #1, #0x1f
    // 0x833c78: mov             x0, x1
    // 0x833c7c: mov             x1, x7
    // 0x833c80: cmp             x1, x0
    // 0x833c84: b.hs            #0x8340fc
    // 0x833c88: ArrayLoad: r1 = r8[r7]  ; Unknown_4
    //     0x833c88: add             x16, x8, x7, lsl #2
    //     0x833c8c: ldur            w1, [x16, #0xf]
    // 0x833c90: DecompressPointer r1
    //     0x833c90: add             x1, x1, HEAP, lsl #32
    // 0x833c94: stur            x1, [fp, #-0x90]
    // 0x833c98: cmp             w1, NULL
    // 0x833c9c: b.eq            #0x833cb4
    // 0x833ca0: str             x1, [SP]
    // 0x833ca4: mov             x0, x1
    // 0x833ca8: ClosureCall
    //     0x833ca8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x833cac: ldur            x2, [x0, #0x1f]
    //     0x833cb0: blr             x2
    // 0x833cb4: ldur            x5, [fp, #-0xa8]
    // 0x833cb8: ldur            x6, [fp, #-0xa0]
    // 0x833cbc: b               #0x833dd8
    // 0x833cc0: sub             SP, fp, #0xf0
    // 0x833cc4: mov             x3, x0
    // 0x833cc8: stur            x0, [fp, #-0x90]
    // 0x833ccc: mov             x0, x1
    // 0x833cd0: stur            x1, [fp, #-0xa0]
    // 0x833cd4: r1 = Null
    //     0x833cd4: mov             x1, NULL
    // 0x833cd8: r2 = 4
    //     0x833cd8: mov             x2, #4
    // 0x833cdc: r0 = AllocateArray()
    //     0x833cdc: bl              #0x13df928  ; AllocateArrayStub
    // 0x833ce0: stur            x0, [fp, #-0xa8]
    // 0x833ce4: r16 = "while dispatching notifications for "
    //     0x833ce4: ldr             x16, [PP, #0x1ca8]  ; [pp+0x1ca8] "while dispatching notifications for "
    // 0x833ce8: StoreField: r0->field_f = r16
    //     0x833ce8: stur            w16, [x0, #0xf]
    // 0x833cec: ldur            x16, [fp, #-0x88]
    // 0x833cf0: str             x16, [SP]
    // 0x833cf4: r0 = runtimeType()
    //     0x833cf4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x833cf8: ldur            x1, [fp, #-0xa8]
    // 0x833cfc: ArrayStore: r1[1] = r0  ; List_4
    //     0x833cfc: add             x25, x1, #0x13
    //     0x833d00: str             w0, [x25]
    //     0x833d04: tbz             w0, #0, #0x833d20
    //     0x833d08: ldurb           w16, [x1, #-1]
    //     0x833d0c: ldurb           w17, [x0, #-1]
    //     0x833d10: and             x16, x17, x16, lsr #2
    //     0x833d14: tst             x16, HEAP, lsr #32
    //     0x833d18: b.eq            #0x833d20
    //     0x833d1c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x833d20: ldur            x16, [fp, #-0xa8]
    // 0x833d24: str             x16, [SP]
    // 0x833d28: r0 = _interpolate()
    //     0x833d28: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x833d2c: r1 = <List<Object>>
    //     0x833d2c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x833d30: stur            x0, [fp, #-0xa8]
    // 0x833d34: r0 = ErrorDescription()
    //     0x833d34: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x833d38: mov             x1, x0
    // 0x833d3c: ldur            x2, [fp, #-0xa8]
    // 0x833d40: r3 = Instance_DiagnosticLevel
    //     0x833d40: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x833d44: stur            x0, [fp, #-0xa8]
    // 0x833d48: r0 = _ErrorDiagnostic()
    //     0x833d48: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x833d4c: r0 = FlutterErrorDetails()
    //     0x833d4c: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x833d50: mov             x3, x0
    // 0x833d54: ldur            x0, [fp, #-0x90]
    // 0x833d58: stur            x3, [fp, #-0xc0]
    // 0x833d5c: StoreField: r3->field_7 = r0
    //     0x833d5c: stur            w0, [x3, #7]
    // 0x833d60: ldur            x4, [fp, #-0xa0]
    // 0x833d64: StoreField: r3->field_b = r4
    //     0x833d64: stur            w4, [x3, #0xb]
    // 0x833d68: r5 = "foundation library"
    //     0x833d68: ldr             x5, [PP, #0x1e40]  ; [pp+0x1e40] "foundation library"
    // 0x833d6c: StoreField: r3->field_f = r5
    //     0x833d6c: stur            w5, [x3, #0xf]
    // 0x833d70: ldur            x1, [fp, #-0xa8]
    // 0x833d74: StoreField: r3->field_13 = r1
    //     0x833d74: stur            w1, [x3, #0x13]
    // 0x833d78: ldur            x2, [fp, #-0xb8]
    // 0x833d7c: r1 = Function '<anonymous closure>':.
    //     0x833d7c: ldr             x1, [PP, #0x2110]  ; [pp+0x2110] AnonymousClosure: (0x834160), in [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::notifyListeners (0x834280)
    // 0x833d80: r0 = AllocateClosure()
    //     0x833d80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x833d84: mov             x1, x0
    // 0x833d88: ldur            x0, [fp, #-0xc0]
    // 0x833d8c: ArrayStore: r0[0] = r1  ; List_4
    //     0x833d8c: stur            w1, [x0, #0x17]
    // 0x833d90: r1 = false
    //     0x833d90: add             x1, NULL, #0x30  ; false
    // 0x833d94: StoreField: r0->field_1b = r1
    //     0x833d94: stur            w1, [x0, #0x1b]
    // 0x833d98: r0 = LoadStaticField(0x46c)
    //     0x833d98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x833d9c: ldr             x0, [x0, #0x8d8]
    // 0x833da0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x833da4: cmp             w0, w16
    // 0x833da8: b.ne            #0x833db4
    // 0x833dac: r2 = onError
    //     0x833dac: ldr             x2, [PP, #0x878]  ; [pp+0x878] Field <FlutterError.onError>: static late (offset: 0x46c)
    // 0x833db0: r0 = InitLateStaticField()
    //     0x833db0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x833db4: cmp             w0, NULL
    // 0x833db8: b.eq            #0x833dd0
    // 0x833dbc: ldur            x16, [fp, #-0xc0]
    // 0x833dc0: stp             x16, x0, [SP]
    // 0x833dc4: ClosureCall
    //     0x833dc4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x833dc8: ldur            x2, [x0, #0x1f]
    //     0x833dcc: blr             x2
    // 0x833dd0: ldur            x5, [fp, #-0xa0]
    // 0x833dd4: ldur            x6, [fp, #-0x90]
    // 0x833dd8: ldur            x0, [fp, #-0x98]
    // 0x833ddc: add             x7, x0, #1
    // 0x833de0: ldur            x2, [fp, #-0x88]
    // 0x833de4: ldur            x3, [fp, #-0xb8]
    // 0x833de8: ldur            x4, [fp, #-0xb0]
    // 0x833dec: b               #0x833c48
    // 0x833df0: mov             x3, x2
    // 0x833df4: LoadField: r0 = r3->field_13
    //     0x833df4: ldur            x0, [x3, #0x13]
    // 0x833df8: sub             x1, x0, #1
    // 0x833dfc: StoreField: r3->field_13 = r1
    //     0x833dfc: stur            x1, [x3, #0x13]
    // 0x833e00: cbnz            x1, #0x8340dc
    // 0x833e04: LoadField: r0 = r3->field_1b
    //     0x833e04: ldur            x0, [x3, #0x1b]
    // 0x833e08: cmp             x0, #0
    // 0x833e0c: b.le            #0x8340dc
    // 0x833e10: LoadField: r4 = r3->field_7
    //     0x833e10: ldur            x4, [x3, #7]
    // 0x833e14: stur            x4, [fp, #-0xc8]
    // 0x833e18: sub             x5, x4, x0
    // 0x833e1c: stur            x5, [fp, #-0xb0]
    // 0x833e20: lsl             x0, x5, #1
    // 0x833e24: LoadField: r6 = r3->field_f
    //     0x833e24: ldur            w6, [x3, #0xf]
    // 0x833e28: DecompressPointer r6
    //     0x833e28: add             x6, x6, HEAP, lsl #32
    // 0x833e2c: stur            x6, [fp, #-0x90]
    // 0x833e30: LoadField: r1 = r6->field_b
    //     0x833e30: ldur            w1, [x6, #0xb]
    // 0x833e34: r7 = LoadInt32Instr(r1)
    //     0x833e34: sbfx            x7, x1, #1, #0x1f
    // 0x833e38: stur            x7, [fp, #-0x98]
    // 0x833e3c: cmp             x0, x7
    // 0x833e40: b.gt            #0x833f70
    // 0x833e44: r0 = BoxInt64Instr(r5)
    //     0x833e44: sbfiz           x0, x5, #1, #0x1f
    //     0x833e48: cmp             x5, x0, asr #1
    //     0x833e4c: b.eq            #0x833e58
    //     0x833e50: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x833e54: stur            x5, [x0, #7]
    // 0x833e58: mov             x2, x0
    // 0x833e5c: r1 = <((dynamic this) => void?)?>
    //     0x833e5c: ldr             x1, [PP, #0x1e50]  ; [pp+0x1e50] TypeArguments: <((dynamic this) => void?)?>
    // 0x833e60: r0 = AllocateArray()
    //     0x833e60: bl              #0x13df928  ; AllocateArrayStub
    // 0x833e64: mov             x3, x0
    // 0x833e68: stur            x3, [fp, #-0xa8]
    // 0x833e6c: r7 = 0
    //     0x833e6c: mov             x7, #0
    // 0x833e70: r6 = 0
    //     0x833e70: mov             x6, #0
    // 0x833e74: ldur            x4, [fp, #-0xc8]
    // 0x833e78: ldur            x5, [fp, #-0x90]
    // 0x833e7c: stur            x7, [fp, #-0xd8]
    // 0x833e80: stur            x6, [fp, #-0xe0]
    // 0x833e84: CheckStackOverflow
    //     0x833e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833e88: cmp             SP, x16
    //     0x833e8c: b.ls            #0x834100
    // 0x833e90: cmp             x6, x4
    // 0x833e94: b.ge            #0x833f44
    // 0x833e98: ldur            x0, [fp, #-0x98]
    // 0x833e9c: mov             x1, x6
    // 0x833ea0: cmp             x1, x0
    // 0x833ea4: b.hs            #0x834108
    // 0x833ea8: ArrayLoad: r8 = r5[r6]  ; Unknown_4
    //     0x833ea8: add             x16, x5, x6, lsl #2
    //     0x833eac: ldur            w8, [x16, #0xf]
    // 0x833eb0: DecompressPointer r8
    //     0x833eb0: add             x8, x8, HEAP, lsl #32
    // 0x833eb4: stur            x8, [fp, #-0xa0]
    // 0x833eb8: cmp             w8, NULL
    // 0x833ebc: b.eq            #0x833f2c
    // 0x833ec0: add             x9, x7, #1
    // 0x833ec4: mov             x0, x8
    // 0x833ec8: stur            x9, [fp, #-0xd0]
    // 0x833ecc: r2 = Null
    //     0x833ecc: mov             x2, NULL
    // 0x833ed0: r1 = Null
    //     0x833ed0: mov             x1, NULL
    // 0x833ed4: r8 = ((dynamic this) => void?)?
    //     0x833ed4: ldr             x8, [PP, #0x1e58]  ; [pp+0x1e58] FunctionType: ((dynamic this) => void?)?
    // 0x833ed8: r3 = Null
    //     0x833ed8: ldr             x3, [PP, #0x2118]  ; [pp+0x2118] Null
    // 0x833edc: r0 = DefaultNullableTypeTest()
    //     0x833edc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x833ee0: ldur            x0, [fp, #-0xb0]
    // 0x833ee4: ldur            x1, [fp, #-0xd8]
    // 0x833ee8: cmp             x1, x0
    // 0x833eec: b.hs            #0x83410c
    // 0x833ef0: ldur            x1, [fp, #-0xa8]
    // 0x833ef4: ldur            x0, [fp, #-0xa0]
    // 0x833ef8: ldur            x2, [fp, #-0xd8]
    // 0x833efc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x833efc: add             x25, x1, x2, lsl #2
    //     0x833f00: add             x25, x25, #0xf
    //     0x833f04: str             w0, [x25]
    //     0x833f08: tbz             w0, #0, #0x833f24
    //     0x833f0c: ldurb           w16, [x1, #-1]
    //     0x833f10: ldurb           w17, [x0, #-1]
    //     0x833f14: and             x16, x17, x16, lsr #2
    //     0x833f18: tst             x16, HEAP, lsr #32
    //     0x833f1c: b.eq            #0x833f24
    //     0x833f20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x833f24: ldur            x7, [fp, #-0xd0]
    // 0x833f28: b               #0x833f34
    // 0x833f2c: mov             x2, x7
    // 0x833f30: mov             x7, x2
    // 0x833f34: ldur            x0, [fp, #-0xe0]
    // 0x833f38: add             x6, x0, #1
    // 0x833f3c: ldur            x3, [fp, #-0xa8]
    // 0x833f40: b               #0x833e74
    // 0x833f44: ldur            x3, [fp, #-0x88]
    // 0x833f48: ldur            x0, [fp, #-0xa8]
    // 0x833f4c: StoreField: r3->field_f = r0
    //     0x833f4c: stur            w0, [x3, #0xf]
    //     0x833f50: ldurb           w16, [x3, #-1]
    //     0x833f54: ldurb           w17, [x0, #-1]
    //     0x833f58: and             x16, x17, x16, lsr #2
    //     0x833f5c: tst             x16, HEAP, lsr #32
    //     0x833f60: b.eq            #0x833f68
    //     0x833f64: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x833f68: mov             x1, x3
    // 0x833f6c: b               #0x8340d0
    // 0x833f70: mov             x4, x6
    // 0x833f74: LoadField: r5 = r4->field_7
    //     0x833f74: ldur            w5, [x4, #7]
    // 0x833f78: DecompressPointer r5
    //     0x833f78: add             x5, x5, HEAP, lsl #32
    // 0x833f7c: stur            x5, [fp, #-0xa8]
    // 0x833f80: r7 = 0
    //     0x833f80: mov             x7, #0
    // 0x833f84: ldur            x6, [fp, #-0xb0]
    // 0x833f88: stur            x7, [fp, #-0xd0]
    // 0x833f8c: CheckStackOverflow
    //     0x833f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833f90: cmp             SP, x16
    //     0x833f94: b.ls            #0x834110
    // 0x833f98: cmp             x7, x6
    // 0x833f9c: b.ge            #0x8340cc
    // 0x833fa0: ldur            x0, [fp, #-0x98]
    // 0x833fa4: mov             x1, x7
    // 0x833fa8: cmp             x1, x0
    // 0x833fac: b.hs            #0x834118
    // 0x833fb0: ArrayLoad: r0 = r4[r7]  ; Unknown_4
    //     0x833fb0: add             x16, x4, x7, lsl #2
    //     0x833fb4: ldur            w0, [x16, #0xf]
    // 0x833fb8: DecompressPointer r0
    //     0x833fb8: add             x0, x0, HEAP, lsl #32
    // 0x833fbc: cmp             w0, NULL
    // 0x833fc0: b.ne            #0x8340b0
    // 0x833fc4: add             x0, x7, #1
    // 0x833fc8: mov             x8, x0
    // 0x833fcc: stur            x8, [fp, #-0xc8]
    // 0x833fd0: CheckStackOverflow
    //     0x833fd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833fd4: cmp             SP, x16
    //     0x833fd8: b.ls            #0x83411c
    // 0x833fdc: ldur            x0, [fp, #-0x98]
    // 0x833fe0: mov             x1, x8
    // 0x833fe4: cmp             x1, x0
    // 0x833fe8: b.hs            #0x834124
    // 0x833fec: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0x833fec: add             x16, x4, x8, lsl #2
    //     0x833ff0: ldur            w9, [x16, #0xf]
    // 0x833ff4: DecompressPointer r9
    //     0x833ff4: add             x9, x9, HEAP, lsl #32
    // 0x833ff8: stur            x9, [fp, #-0xa0]
    // 0x833ffc: cmp             w9, NULL
    // 0x834000: b.ne            #0x834010
    // 0x834004: add             x0, x8, #1
    // 0x834008: mov             x8, x0
    // 0x83400c: b               #0x833fcc
    // 0x834010: mov             x0, x9
    // 0x834014: mov             x2, x5
    // 0x834018: r1 = Null
    //     0x834018: mov             x1, NULL
    // 0x83401c: cmp             w2, NULL
    // 0x834020: b.eq            #0x83403c
    // 0x834024: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x834024: ldur            w4, [x2, #0x17]
    // 0x834028: DecompressPointer r4
    //     0x834028: add             x4, x4, HEAP, lsl #32
    // 0x83402c: r8 = X0
    //     0x83402c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x834030: LoadField: r9 = r4->field_7
    //     0x834030: ldur            x9, [x4, #7]
    // 0x834034: r3 = Null
    //     0x834034: ldr             x3, [PP, #0x2128]  ; [pp+0x2128] Null
    // 0x834038: blr             x9
    // 0x83403c: ldur            x1, [fp, #-0x90]
    // 0x834040: ldur            x0, [fp, #-0xa0]
    // 0x834044: ldur            x3, [fp, #-0xd0]
    // 0x834048: ArrayStore: r1[r3] = r0  ; List_4
    //     0x834048: add             x25, x1, x3, lsl #2
    //     0x83404c: add             x25, x25, #0xf
    //     0x834050: str             w0, [x25]
    //     0x834054: tbz             w0, #0, #0x834070
    //     0x834058: ldurb           w16, [x1, #-1]
    //     0x83405c: ldurb           w17, [x0, #-1]
    //     0x834060: and             x16, x17, x16, lsr #2
    //     0x834064: tst             x16, HEAP, lsr #32
    //     0x834068: b.eq            #0x834070
    //     0x83406c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x834070: ldur            x2, [fp, #-0xa8]
    // 0x834074: r0 = Null
    //     0x834074: mov             x0, NULL
    // 0x834078: r1 = Null
    //     0x834078: mov             x1, NULL
    // 0x83407c: cmp             w2, NULL
    // 0x834080: b.eq            #0x83409c
    // 0x834084: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x834084: ldur            w4, [x2, #0x17]
    // 0x834088: DecompressPointer r4
    //     0x834088: add             x4, x4, HEAP, lsl #32
    // 0x83408c: r8 = X0
    //     0x83408c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x834090: LoadField: r9 = r4->field_7
    //     0x834090: ldur            x9, [x4, #7]
    // 0x834094: r3 = Null
    //     0x834094: ldr             x3, [PP, #0x2138]  ; [pp+0x2138] Null
    // 0x834098: blr             x9
    // 0x83409c: ldur            x1, [fp, #-0x90]
    // 0x8340a0: ldur            x2, [fp, #-0xc8]
    // 0x8340a4: ArrayStore: r1[r2] = rNULL  ; Unknown_4
    //     0x8340a4: add             x3, x1, x2, lsl #2
    //     0x8340a8: stur            NULL, [x3, #0xf]
    // 0x8340ac: b               #0x8340b4
    // 0x8340b0: mov             x1, x4
    // 0x8340b4: ldur            x2, [fp, #-0xd0]
    // 0x8340b8: add             x7, x2, #1
    // 0x8340bc: ldur            x3, [fp, #-0x88]
    // 0x8340c0: mov             x4, x1
    // 0x8340c4: ldur            x5, [fp, #-0xa8]
    // 0x8340c8: b               #0x833f84
    // 0x8340cc: ldur            x1, [fp, #-0x88]
    // 0x8340d0: ldur            x2, [fp, #-0xb0]
    // 0x8340d4: StoreField: r1->field_1b = rZR
    //     0x8340d4: stur            xzr, [x1, #0x1b]
    // 0x8340d8: StoreField: r1->field_7 = r2
    //     0x8340d8: stur            x2, [x1, #7]
    // 0x8340dc: r0 = Null
    //     0x8340dc: mov             x0, NULL
    // 0x8340e0: LeaveFrame
    //     0x8340e0: mov             SP, fp
    //     0x8340e4: ldp             fp, lr, [SP], #0x10
    // 0x8340e8: ret
    //     0x8340e8: ret             
    // 0x8340ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8340ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8340f0: b               #0x833bfc
    // 0x8340f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8340f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8340f8: b               #0x833c60
    // 0x8340fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8340fc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x834100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834104: b               #0x833e90
    // 0x834108: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x834108: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x83410c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x83410c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x834110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834114: b               #0x833f98
    // 0x834118: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x834118: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x83411c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83411c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834120: b               #0x833fdc
    // 0x834124: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x834124: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void notifyListeners(dynamic) {
    // ** addr: 0x834128, size: 0x38
    // 0x834128: EnterFrame
    //     0x834128: stp             fp, lr, [SP, #-0x10]!
    //     0x83412c: mov             fp, SP
    // 0x834130: ldr             x0, [fp, #0x10]
    // 0x834134: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x834134: ldur            w1, [x0, #0x17]
    // 0x834138: DecompressPointer r1
    //     0x834138: add             x1, x1, HEAP, lsl #32
    // 0x83413c: CheckStackOverflow
    //     0x83413c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834140: cmp             SP, x16
    //     0x834144: b.ls            #0x834158
    // 0x834148: r0 = notifyListeners()
    //     0x834148: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x83414c: LeaveFrame
    //     0x83414c: mov             SP, fp
    //     0x834150: ldp             fp, lr, [SP], #0x10
    // 0x834154: ret
    //     0x834154: ret             
    // 0x834158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83415c: b               #0x834148
  }
  static List<((dynamic) => void)?> _emptyListeners() {
    // ** addr: 0x89f890, size: 0x20
    // 0x89f890: EnterFrame
    //     0x89f890: stp             fp, lr, [SP, #-0x10]!
    //     0x89f894: mov             fp, SP
    // 0x89f898: r1 = <((dynamic this) => void?)?>
    //     0x89f898: ldr             x1, [PP, #0x1e50]  ; [pp+0x1e50] TypeArguments: <((dynamic this) => void?)?>
    // 0x89f89c: r2 = 0
    //     0x89f89c: mov             x2, #0
    // 0x89f8a0: r0 = AllocateArray()
    //     0x89f8a0: bl              #0x13df928  ; AllocateArrayStub
    // 0x89f8a4: LeaveFrame
    //     0x89f8a4: mov             SP, fp
    //     0x89f8a8: ldp             fp, lr, [SP], #0x10
    // 0x89f8ac: ret
    //     0x89f8ac: ret             
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xcff968, size: 0x16c
    // 0xcff968: EnterFrame
    //     0xcff968: stp             fp, lr, [SP, #-0x10]!
    //     0xcff96c: mov             fp, SP
    // 0xcff970: AllocStack(0x28)
    //     0xcff970: sub             SP, SP, #0x28
    // 0xcff974: SetupParameters(ChangeNotifier this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcff974: mov             x3, x1
    //     0xcff978: stur            x1, [fp, #-0x10]
    //     0xcff97c: stur            x2, [fp, #-0x18]
    // 0xcff980: CheckStackOverflow
    //     0xcff980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff984: cmp             SP, x16
    //     0xcff988: b.ls            #0xcffabc
    // 0xcff98c: r4 = 0
    //     0xcff98c: mov             x4, #0
    // 0xcff990: stur            x4, [fp, #-8]
    // 0xcff994: CheckStackOverflow
    //     0xcff994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff998: cmp             SP, x16
    //     0xcff99c: b.ls            #0xcffac4
    // 0xcff9a0: LoadField: r0 = r3->field_7
    //     0xcff9a0: ldur            x0, [x3, #7]
    // 0xcff9a4: cmp             x4, x0
    // 0xcff9a8: b.ge            #0xcffaac
    // 0xcff9ac: LoadField: r5 = r3->field_f
    //     0xcff9ac: ldur            w5, [x3, #0xf]
    // 0xcff9b0: DecompressPointer r5
    //     0xcff9b0: add             x5, x5, HEAP, lsl #32
    // 0xcff9b4: LoadField: r0 = r5->field_b
    //     0xcff9b4: ldur            w0, [x5, #0xb]
    // 0xcff9b8: r1 = LoadInt32Instr(r0)
    //     0xcff9b8: sbfx            x1, x0, #1, #0x1f
    // 0xcff9bc: mov             x0, x1
    // 0xcff9c0: mov             x1, x4
    // 0xcff9c4: cmp             x1, x0
    // 0xcff9c8: b.hs            #0xcffacc
    // 0xcff9cc: ArrayLoad: r0 = r5[r4]  ; Unknown_4
    //     0xcff9cc: add             x16, x5, x4, lsl #2
    //     0xcff9d0: ldur            w0, [x16, #0xf]
    // 0xcff9d4: DecompressPointer r0
    //     0xcff9d4: add             x0, x0, HEAP, lsl #32
    // 0xcff9d8: r1 = LoadClassIdInstr(r0)
    //     0xcff9d8: ldur            x1, [x0, #-1]
    //     0xcff9dc: ubfx            x1, x1, #0xc, #0x14
    // 0xcff9e0: stp             x2, x0, [SP]
    // 0xcff9e4: mov             x0, x1
    // 0xcff9e8: mov             lr, x0
    // 0xcff9ec: ldr             lr, [x21, lr, lsl #3]
    // 0xcff9f0: blr             lr
    // 0xcff9f4: tbz             w0, #4, #0xcffa0c
    // 0xcff9f8: ldur            x3, [fp, #-8]
    // 0xcff9fc: add             x4, x3, #1
    // 0xcffa00: ldur            x3, [fp, #-0x10]
    // 0xcffa04: ldur            x2, [fp, #-0x18]
    // 0xcffa08: b               #0xcff990
    // 0xcffa0c: ldur            x4, [fp, #-0x10]
    // 0xcffa10: ldur            x3, [fp, #-8]
    // 0xcffa14: LoadField: r0 = r4->field_13
    //     0xcffa14: ldur            x0, [x4, #0x13]
    // 0xcffa18: cmp             x0, #0
    // 0xcffa1c: b.le            #0xcffa9c
    // 0xcffa20: LoadField: r5 = r4->field_f
    //     0xcffa20: ldur            w5, [x4, #0xf]
    // 0xcffa24: DecompressPointer r5
    //     0xcffa24: add             x5, x5, HEAP, lsl #32
    // 0xcffa28: stur            x5, [fp, #-0x18]
    // 0xcffa2c: LoadField: r2 = r5->field_7
    //     0xcffa2c: ldur            w2, [x5, #7]
    // 0xcffa30: DecompressPointer r2
    //     0xcffa30: add             x2, x2, HEAP, lsl #32
    // 0xcffa34: r0 = Null
    //     0xcffa34: mov             x0, NULL
    // 0xcffa38: r1 = Null
    //     0xcffa38: mov             x1, NULL
    // 0xcffa3c: cmp             w2, NULL
    // 0xcffa40: b.eq            #0xcffa60
    // 0xcffa44: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcffa44: ldur            w4, [x2, #0x17]
    // 0xcffa48: DecompressPointer r4
    //     0xcffa48: add             x4, x4, HEAP, lsl #32
    // 0xcffa4c: r8 = X0
    //     0xcffa4c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xcffa50: LoadField: r9 = r4->field_7
    //     0xcffa50: ldur            x9, [x4, #7]
    // 0xcffa54: r3 = Null
    //     0xcffa54: add             x3, PP, #0x12, lsl #12  ; [pp+0x123d8] Null
    //     0xcffa58: ldr             x3, [x3, #0x3d8]
    // 0xcffa5c: blr             x9
    // 0xcffa60: ldur            x2, [fp, #-0x18]
    // 0xcffa64: LoadField: r0 = r2->field_b
    //     0xcffa64: ldur            w0, [x2, #0xb]
    // 0xcffa68: r1 = LoadInt32Instr(r0)
    //     0xcffa68: sbfx            x1, x0, #1, #0x1f
    // 0xcffa6c: mov             x0, x1
    // 0xcffa70: ldur            x1, [fp, #-8]
    // 0xcffa74: cmp             x1, x0
    // 0xcffa78: b.hs            #0xcffad0
    // 0xcffa7c: ldur            x0, [fp, #-8]
    // 0xcffa80: ArrayStore: r2[r0] = rNULL  ; Unknown_4
    //     0xcffa80: add             x1, x2, x0, lsl #2
    //     0xcffa84: stur            NULL, [x1, #0xf]
    // 0xcffa88: ldur            x1, [fp, #-0x10]
    // 0xcffa8c: LoadField: r0 = r1->field_1b
    //     0xcffa8c: ldur            x0, [x1, #0x1b]
    // 0xcffa90: add             x2, x0, #1
    // 0xcffa94: StoreField: r1->field_1b = r2
    //     0xcffa94: stur            x2, [x1, #0x1b]
    // 0xcffa98: b               #0xcffaac
    // 0xcffa9c: mov             x1, x4
    // 0xcffaa0: mov             x0, x3
    // 0xcffaa4: mov             x2, x0
    // 0xcffaa8: r0 = _removeAt()
    //     0xcffaa8: bl              #0xcffad4  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_removeAt
    // 0xcffaac: r0 = Null
    //     0xcffaac: mov             x0, NULL
    // 0xcffab0: LeaveFrame
    //     0xcffab0: mov             SP, fp
    //     0xcffab4: ldp             fp, lr, [SP], #0x10
    // 0xcffab8: ret
    //     0xcffab8: ret             
    // 0xcffabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcffabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcffac0: b               #0xcff98c
    // 0xcffac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcffac4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcffac8: b               #0xcff9a0
    // 0xcffacc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffacc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffad0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffad0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _removeAt(/* No info */) {
    // ** addr: 0xcffad4, size: 0x318
    // 0xcffad4: EnterFrame
    //     0xcffad4: stp             fp, lr, [SP, #-0x10]!
    //     0xcffad8: mov             fp, SP
    // 0xcffadc: AllocStack(0x38)
    //     0xcffadc: sub             SP, SP, #0x38
    // 0xcffae0: SetupParameters(ChangeNotifier this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0xcffae0: mov             x4, x1
    //     0xcffae4: mov             x3, x2
    //     0xcffae8: stur            x1, [fp, #-0x20]
    //     0xcffaec: stur            x2, [fp, #-0x28]
    // 0xcffaf0: LoadField: r0 = r4->field_7
    //     0xcffaf0: ldur            x0, [x4, #7]
    // 0xcffaf4: sub             x5, x0, #1
    // 0xcffaf8: stur            x5, [fp, #-0x18]
    // 0xcffafc: StoreField: r4->field_7 = r5
    //     0xcffafc: stur            x5, [x4, #7]
    // 0xcffb00: lsl             x0, x5, #1
    // 0xcffb04: LoadField: r6 = r4->field_f
    //     0xcffb04: ldur            w6, [x4, #0xf]
    // 0xcffb08: DecompressPointer r6
    //     0xcffb08: add             x6, x6, HEAP, lsl #32
    // 0xcffb0c: stur            x6, [fp, #-0x10]
    // 0xcffb10: LoadField: r1 = r6->field_b
    //     0xcffb10: ldur            w1, [x6, #0xb]
    // 0xcffb14: r7 = LoadInt32Instr(r1)
    //     0xcffb14: sbfx            x7, x1, #1, #0x1f
    // 0xcffb18: stur            x7, [fp, #-8]
    // 0xcffb1c: cmp             x0, x7
    // 0xcffb20: b.gt            #0xcffc78
    // 0xcffb24: r0 = BoxInt64Instr(r5)
    //     0xcffb24: sbfiz           x0, x5, #1, #0x1f
    //     0xcffb28: cmp             x5, x0, asr #1
    //     0xcffb2c: b.eq            #0xcffb38
    //     0xcffb30: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xcffb34: stur            x5, [x0, #7]
    // 0xcffb38: mov             x2, x0
    // 0xcffb3c: r1 = <((dynamic this) => void?)?>
    //     0xcffb3c: ldr             x1, [PP, #0x1e50]  ; [pp+0x1e50] TypeArguments: <((dynamic this) => void?)?>
    // 0xcffb40: r0 = AllocateArray()
    //     0xcffb40: bl              #0x13df928  ; AllocateArrayStub
    // 0xcffb44: mov             x2, x0
    // 0xcffb48: ldur            x3, [fp, #-0x28]
    // 0xcffb4c: ldur            x4, [fp, #-0x10]
    // 0xcffb50: r5 = 0
    //     0xcffb50: mov             x5, #0
    // 0xcffb54: CheckStackOverflow
    //     0xcffb54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcffb58: cmp             SP, x16
    //     0xcffb5c: b.ls            #0xcffdb8
    // 0xcffb60: cmp             x5, x3
    // 0xcffb64: b.ge            #0xcffbd0
    // 0xcffb68: ldur            x0, [fp, #-8]
    // 0xcffb6c: mov             x1, x5
    // 0xcffb70: cmp             x1, x0
    // 0xcffb74: b.hs            #0xcffdc0
    // 0xcffb78: ArrayLoad: r6 = r4[r5]  ; Unknown_4
    //     0xcffb78: add             x16, x4, x5, lsl #2
    //     0xcffb7c: ldur            w6, [x16, #0xf]
    // 0xcffb80: DecompressPointer r6
    //     0xcffb80: add             x6, x6, HEAP, lsl #32
    // 0xcffb84: ldur            x0, [fp, #-0x18]
    // 0xcffb88: mov             x1, x5
    // 0xcffb8c: cmp             x1, x0
    // 0xcffb90: b.hs            #0xcffdc4
    // 0xcffb94: mov             x1, x2
    // 0xcffb98: mov             x0, x6
    // 0xcffb9c: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcffb9c: add             x25, x1, x5, lsl #2
    //     0xcffba0: add             x25, x25, #0xf
    //     0xcffba4: str             w0, [x25]
    //     0xcffba8: tbz             w0, #0, #0xcffbc4
    //     0xcffbac: ldurb           w16, [x1, #-1]
    //     0xcffbb0: ldurb           w17, [x0, #-1]
    //     0xcffbb4: and             x16, x17, x16, lsr #2
    //     0xcffbb8: tst             x16, HEAP, lsr #32
    //     0xcffbbc: b.eq            #0xcffbc4
    //     0xcffbc0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xcffbc4: add             x0, x5, #1
    // 0xcffbc8: mov             x5, x0
    // 0xcffbcc: b               #0xcffb54
    // 0xcffbd0: ldur            x5, [fp, #-0x18]
    // 0xcffbd4: CheckStackOverflow
    //     0xcffbd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcffbd8: cmp             SP, x16
    //     0xcffbdc: b.ls            #0xcffdc8
    // 0xcffbe0: cmp             x3, x5
    // 0xcffbe4: b.ge            #0xcffc50
    // 0xcffbe8: add             x6, x3, #1
    // 0xcffbec: ldur            x0, [fp, #-8]
    // 0xcffbf0: mov             x1, x6
    // 0xcffbf4: cmp             x1, x0
    // 0xcffbf8: b.hs            #0xcffdd0
    // 0xcffbfc: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0xcffbfc: add             x16, x4, x6, lsl #2
    //     0xcffc00: ldur            w7, [x16, #0xf]
    // 0xcffc04: DecompressPointer r7
    //     0xcffc04: add             x7, x7, HEAP, lsl #32
    // 0xcffc08: mov             x0, x5
    // 0xcffc0c: mov             x1, x3
    // 0xcffc10: cmp             x1, x0
    // 0xcffc14: b.hs            #0xcffdd4
    // 0xcffc18: mov             x1, x2
    // 0xcffc1c: mov             x0, x7
    // 0xcffc20: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcffc20: add             x25, x1, x3, lsl #2
    //     0xcffc24: add             x25, x25, #0xf
    //     0xcffc28: str             w0, [x25]
    //     0xcffc2c: tbz             w0, #0, #0xcffc48
    //     0xcffc30: ldurb           w16, [x1, #-1]
    //     0xcffc34: ldurb           w17, [x0, #-1]
    //     0xcffc38: and             x16, x17, x16, lsr #2
    //     0xcffc3c: tst             x16, HEAP, lsr #32
    //     0xcffc40: b.eq            #0xcffc48
    //     0xcffc44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xcffc48: mov             x3, x6
    // 0xcffc4c: b               #0xcffbd4
    // 0xcffc50: ldur            x1, [fp, #-0x20]
    // 0xcffc54: mov             x0, x2
    // 0xcffc58: StoreField: r1->field_f = r0
    //     0xcffc58: stur            w0, [x1, #0xf]
    //     0xcffc5c: ldurb           w16, [x1, #-1]
    //     0xcffc60: ldurb           w17, [x0, #-1]
    //     0xcffc64: and             x16, x17, x16, lsr #2
    //     0xcffc68: tst             x16, HEAP, lsr #32
    //     0xcffc6c: b.eq            #0xcffc74
    //     0xcffc70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcffc74: b               #0xcffda8
    // 0xcffc78: mov             x4, x6
    // 0xcffc7c: LoadField: r6 = r4->field_7
    //     0xcffc7c: ldur            w6, [x4, #7]
    // 0xcffc80: DecompressPointer r6
    //     0xcffc80: add             x6, x6, HEAP, lsl #32
    // 0xcffc84: stur            x6, [fp, #-0x38]
    // 0xcffc88: stur            x3, [fp, #-0x30]
    // 0xcffc8c: CheckStackOverflow
    //     0xcffc8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcffc90: cmp             SP, x16
    //     0xcffc94: b.ls            #0xcffdd8
    // 0xcffc98: cmp             x3, x5
    // 0xcffc9c: b.ge            #0xcffd50
    // 0xcffca0: add             x7, x3, #1
    // 0xcffca4: ldur            x0, [fp, #-8]
    // 0xcffca8: mov             x1, x7
    // 0xcffcac: stur            x7, [fp, #-0x28]
    // 0xcffcb0: cmp             x1, x0
    // 0xcffcb4: b.hs            #0xcffde0
    // 0xcffcb8: ArrayLoad: r8 = r4[r7]  ; Unknown_4
    //     0xcffcb8: add             x16, x4, x7, lsl #2
    //     0xcffcbc: ldur            w8, [x16, #0xf]
    // 0xcffcc0: DecompressPointer r8
    //     0xcffcc0: add             x8, x8, HEAP, lsl #32
    // 0xcffcc4: mov             x0, x8
    // 0xcffcc8: mov             x2, x6
    // 0xcffccc: stur            x8, [fp, #-0x20]
    // 0xcffcd0: r1 = Null
    //     0xcffcd0: mov             x1, NULL
    // 0xcffcd4: cmp             w2, NULL
    // 0xcffcd8: b.eq            #0xcffcf8
    // 0xcffcdc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcffcdc: ldur            w4, [x2, #0x17]
    // 0xcffce0: DecompressPointer r4
    //     0xcffce0: add             x4, x4, HEAP, lsl #32
    // 0xcffce4: r8 = X0
    //     0xcffce4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xcffce8: LoadField: r9 = r4->field_7
    //     0xcffce8: ldur            x9, [x4, #7]
    // 0xcffcec: r3 = Null
    //     0xcffcec: add             x3, PP, #0x12, lsl #12  ; [pp+0x123e8] Null
    //     0xcffcf0: ldr             x3, [x3, #0x3e8]
    // 0xcffcf4: blr             x9
    // 0xcffcf8: ldur            x0, [fp, #-8]
    // 0xcffcfc: ldur            x1, [fp, #-0x30]
    // 0xcffd00: cmp             x1, x0
    // 0xcffd04: b.hs            #0xcffde4
    // 0xcffd08: ldur            x1, [fp, #-0x10]
    // 0xcffd0c: ldur            x0, [fp, #-0x20]
    // 0xcffd10: ldur            x2, [fp, #-0x30]
    // 0xcffd14: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcffd14: add             x25, x1, x2, lsl #2
    //     0xcffd18: add             x25, x25, #0xf
    //     0xcffd1c: str             w0, [x25]
    //     0xcffd20: tbz             w0, #0, #0xcffd3c
    //     0xcffd24: ldurb           w16, [x1, #-1]
    //     0xcffd28: ldurb           w17, [x0, #-1]
    //     0xcffd2c: and             x16, x17, x16, lsr #2
    //     0xcffd30: tst             x16, HEAP, lsr #32
    //     0xcffd34: b.eq            #0xcffd3c
    //     0xcffd38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xcffd3c: ldur            x3, [fp, #-0x28]
    // 0xcffd40: ldur            x5, [fp, #-0x18]
    // 0xcffd44: ldur            x4, [fp, #-0x10]
    // 0xcffd48: ldur            x6, [fp, #-0x38]
    // 0xcffd4c: b               #0xcffc88
    // 0xcffd50: mov             x3, x4
    // 0xcffd54: mov             x4, x5
    // 0xcffd58: ldur            x2, [fp, #-0x38]
    // 0xcffd5c: r0 = Null
    //     0xcffd5c: mov             x0, NULL
    // 0xcffd60: r1 = Null
    //     0xcffd60: mov             x1, NULL
    // 0xcffd64: cmp             w2, NULL
    // 0xcffd68: b.eq            #0xcffd88
    // 0xcffd6c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xcffd6c: ldur            w4, [x2, #0x17]
    // 0xcffd70: DecompressPointer r4
    //     0xcffd70: add             x4, x4, HEAP, lsl #32
    // 0xcffd74: r8 = X0
    //     0xcffd74: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xcffd78: LoadField: r9 = r4->field_7
    //     0xcffd78: ldur            x9, [x4, #7]
    // 0xcffd7c: r3 = Null
    //     0xcffd7c: add             x3, PP, #0x12, lsl #12  ; [pp+0x123f8] Null
    //     0xcffd80: ldr             x3, [x3, #0x3f8]
    // 0xcffd84: blr             x9
    // 0xcffd88: ldur            x0, [fp, #-8]
    // 0xcffd8c: ldur            x1, [fp, #-0x18]
    // 0xcffd90: cmp             x1, x0
    // 0xcffd94: b.hs            #0xcffde8
    // 0xcffd98: ldur            x2, [fp, #-0x18]
    // 0xcffd9c: ldur            x1, [fp, #-0x10]
    // 0xcffda0: ArrayStore: r1[r2] = rNULL  ; Unknown_4
    //     0xcffda0: add             x3, x1, x2, lsl #2
    //     0xcffda4: stur            NULL, [x3, #0xf]
    // 0xcffda8: r0 = Null
    //     0xcffda8: mov             x0, NULL
    // 0xcffdac: LeaveFrame
    //     0xcffdac: mov             SP, fp
    //     0xcffdb0: ldp             fp, lr, [SP], #0x10
    // 0xcffdb4: ret
    //     0xcffdb4: ret             
    // 0xcffdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcffdb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcffdbc: b               #0xcffb60
    // 0xcffdc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffdc0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffdc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffdc4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffdc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcffdc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcffdcc: b               #0xcffbe0
    // 0xcffdd0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffdd0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffdd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffdd4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffdd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcffdd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcffddc: b               #0xcffc98
    // 0xcffde0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffde0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffde4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffde4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcffde8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcffde8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd038e0, size: 0x20c
    // 0xd038e0: EnterFrame
    //     0xd038e0: stp             fp, lr, [SP, #-0x10]!
    //     0xd038e4: mov             fp, SP
    // 0xd038e8: AllocStack(0x30)
    //     0xd038e8: sub             SP, SP, #0x30
    // 0xd038ec: SetupParameters(ChangeNotifier this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd038ec: mov             x3, x1
    //     0xd038f0: mov             x0, x2
    //     0xd038f4: stur            x1, [fp, #-0x10]
    //     0xd038f8: stur            x2, [fp, #-0x18]
    // 0xd038fc: LoadField: r4 = r3->field_7
    //     0xd038fc: ldur            x4, [x3, #7]
    // 0xd03900: stur            x4, [fp, #-8]
    // 0xd03904: LoadField: r5 = r3->field_f
    //     0xd03904: ldur            w5, [x3, #0xf]
    // 0xd03908: DecompressPointer r5
    //     0xd03908: add             x5, x5, HEAP, lsl #32
    // 0xd0390c: stur            x5, [fp, #-0x30]
    // 0xd03910: LoadField: r1 = r5->field_b
    //     0xd03910: ldur            w1, [x5, #0xb]
    // 0xd03914: r6 = LoadInt32Instr(r1)
    //     0xd03914: sbfx            x6, x1, #1, #0x1f
    // 0xd03918: stur            x6, [fp, #-0x28]
    // 0xd0391c: cmp             x4, x6
    // 0xd03920: b.ne            #0xd03a38
    // 0xd03924: cbnz            x4, #0xd03968
    // 0xd03928: r1 = <((dynamic this) => void?)?>
    //     0xd03928: ldr             x1, [PP, #0x1e50]  ; [pp+0x1e50] TypeArguments: <((dynamic this) => void?)?>
    // 0xd0392c: r2 = 2
    //     0xd0392c: mov             x2, #2
    // 0xd03930: r0 = AllocateArray()
    //     0xd03930: bl              #0x13df928  ; AllocateArrayStub
    // 0xd03934: mov             x1, x0
    // 0xd03938: ldur            x3, [fp, #-0x10]
    // 0xd0393c: StoreField: r3->field_f = r0
    //     0xd0393c: stur            w0, [x3, #0xf]
    //     0xd03940: ldurb           w16, [x3, #-1]
    //     0xd03944: ldurb           w17, [x0, #-1]
    //     0xd03948: and             x16, x17, x16, lsr #2
    //     0xd0394c: tst             x16, HEAP, lsr #32
    //     0xd03950: b.eq            #0xd03958
    //     0xd03954: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd03958: mov             x0, x1
    // 0xd0395c: mov             x1, x3
    // 0xd03960: ldur            x4, [fp, #-8]
    // 0xd03964: b               #0xd03a30
    // 0xd03968: lsl             x0, x6, #1
    // 0xd0396c: stur            x0, [fp, #-0x20]
    // 0xd03970: lsl             x2, x0, #1
    // 0xd03974: r1 = <((dynamic this) => void?)?>
    //     0xd03974: ldr             x1, [PP, #0x1e50]  ; [pp+0x1e50] TypeArguments: <((dynamic this) => void?)?>
    // 0xd03978: r0 = AllocateArray()
    //     0xd03978: bl              #0x13df928  ; AllocateArrayStub
    // 0xd0397c: mov             x2, x0
    // 0xd03980: ldur            x4, [fp, #-8]
    // 0xd03984: ldur            x3, [fp, #-0x30]
    // 0xd03988: r5 = 0
    //     0xd03988: mov             x5, #0
    // 0xd0398c: CheckStackOverflow
    //     0xd0398c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03990: cmp             SP, x16
    //     0xd03994: b.ls            #0xd03ad8
    // 0xd03998: cmp             x5, x4
    // 0xd0399c: b.ge            #0xd03a08
    // 0xd039a0: ldur            x0, [fp, #-0x28]
    // 0xd039a4: mov             x1, x5
    // 0xd039a8: cmp             x1, x0
    // 0xd039ac: b.hs            #0xd03ae0
    // 0xd039b0: ArrayLoad: r6 = r3[r5]  ; Unknown_4
    //     0xd039b0: add             x16, x3, x5, lsl #2
    //     0xd039b4: ldur            w6, [x16, #0xf]
    // 0xd039b8: DecompressPointer r6
    //     0xd039b8: add             x6, x6, HEAP, lsl #32
    // 0xd039bc: ldur            x0, [fp, #-0x20]
    // 0xd039c0: mov             x1, x5
    // 0xd039c4: cmp             x1, x0
    // 0xd039c8: b.hs            #0xd03ae4
    // 0xd039cc: mov             x1, x2
    // 0xd039d0: mov             x0, x6
    // 0xd039d4: ArrayStore: r1[r5] = r0  ; List_4
    //     0xd039d4: add             x25, x1, x5, lsl #2
    //     0xd039d8: add             x25, x25, #0xf
    //     0xd039dc: str             w0, [x25]
    //     0xd039e0: tbz             w0, #0, #0xd039fc
    //     0xd039e4: ldurb           w16, [x1, #-1]
    //     0xd039e8: ldurb           w17, [x0, #-1]
    //     0xd039ec: and             x16, x17, x16, lsr #2
    //     0xd039f0: tst             x16, HEAP, lsr #32
    //     0xd039f4: b.eq            #0xd039fc
    //     0xd039f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd039fc: add             x0, x5, #1
    // 0xd03a00: mov             x5, x0
    // 0xd03a04: b               #0xd0398c
    // 0xd03a08: ldur            x1, [fp, #-0x10]
    // 0xd03a0c: mov             x0, x2
    // 0xd03a10: StoreField: r1->field_f = r0
    //     0xd03a10: stur            w0, [x1, #0xf]
    //     0xd03a14: ldurb           w16, [x1, #-1]
    //     0xd03a18: ldurb           w17, [x0, #-1]
    //     0xd03a1c: and             x16, x17, x16, lsr #2
    //     0xd03a20: tst             x16, HEAP, lsr #32
    //     0xd03a24: b.eq            #0xd03a2c
    //     0xd03a28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd03a2c: mov             x0, x2
    // 0xd03a30: mov             x3, x0
    // 0xd03a34: b               #0xd03a40
    // 0xd03a38: mov             x1, x3
    // 0xd03a3c: mov             x3, x5
    // 0xd03a40: stur            x3, [fp, #-0x30]
    // 0xd03a44: add             x0, x4, #1
    // 0xd03a48: StoreField: r1->field_7 = r0
    //     0xd03a48: stur            x0, [x1, #7]
    // 0xd03a4c: LoadField: r2 = r3->field_7
    //     0xd03a4c: ldur            w2, [x3, #7]
    // 0xd03a50: DecompressPointer r2
    //     0xd03a50: add             x2, x2, HEAP, lsl #32
    // 0xd03a54: ldur            x0, [fp, #-0x18]
    // 0xd03a58: r1 = Null
    //     0xd03a58: mov             x1, NULL
    // 0xd03a5c: cmp             w2, NULL
    // 0xd03a60: b.eq            #0xd03a7c
    // 0xd03a64: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd03a64: ldur            w4, [x2, #0x17]
    // 0xd03a68: DecompressPointer r4
    //     0xd03a68: add             x4, x4, HEAP, lsl #32
    // 0xd03a6c: r8 = X0
    //     0xd03a6c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd03a70: LoadField: r9 = r4->field_7
    //     0xd03a70: ldur            x9, [x4, #7]
    // 0xd03a74: r3 = Null
    //     0xd03a74: ldr             x3, [PP, #0x2150]  ; [pp+0x2150] Null
    // 0xd03a78: blr             x9
    // 0xd03a7c: ldur            x2, [fp, #-0x30]
    // 0xd03a80: LoadField: r3 = r2->field_b
    //     0xd03a80: ldur            w3, [x2, #0xb]
    // 0xd03a84: r0 = LoadInt32Instr(r3)
    //     0xd03a84: sbfx            x0, x3, #1, #0x1f
    // 0xd03a88: ldur            x1, [fp, #-8]
    // 0xd03a8c: cmp             x1, x0
    // 0xd03a90: b.hs            #0xd03ae8
    // 0xd03a94: mov             x1, x2
    // 0xd03a98: ldur            x0, [fp, #-0x18]
    // 0xd03a9c: ldur            x2, [fp, #-8]
    // 0xd03aa0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xd03aa0: add             x25, x1, x2, lsl #2
    //     0xd03aa4: add             x25, x25, #0xf
    //     0xd03aa8: str             w0, [x25]
    //     0xd03aac: tbz             w0, #0, #0xd03ac8
    //     0xd03ab0: ldurb           w16, [x1, #-1]
    //     0xd03ab4: ldurb           w17, [x0, #-1]
    //     0xd03ab8: and             x16, x17, x16, lsr #2
    //     0xd03abc: tst             x16, HEAP, lsr #32
    //     0xd03ac0: b.eq            #0xd03ac8
    //     0xd03ac4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd03ac8: r0 = Null
    //     0xd03ac8: mov             x0, NULL
    // 0xd03acc: LeaveFrame
    //     0xd03acc: mov             SP, fp
    //     0xd03ad0: ldp             fp, lr, [SP], #0x10
    // 0xd03ad4: ret
    //     0xd03ad4: ret             
    // 0xd03ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03ad8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03adc: b               #0xd03998
    // 0xd03ae0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03ae0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd03ae4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03ae4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd03ae8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03ae8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x10ef25c, size: 0x38
    // 0x10ef25c: EnterFrame
    //     0x10ef25c: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef260: mov             fp, SP
    // 0x10ef264: ldr             x0, [fp, #0x10]
    // 0x10ef268: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10ef268: ldur            w1, [x0, #0x17]
    // 0x10ef26c: DecompressPointer r1
    //     0x10ef26c: add             x1, x1, HEAP, lsl #32
    // 0x10ef270: CheckStackOverflow
    //     0x10ef270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef274: cmp             SP, x16
    //     0x10ef278: b.ls            #0x10ef28c
    // 0x10ef27c: r0 = dispose()
    //     0x10ef27c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ef280: LeaveFrame
    //     0x10ef280: mov             SP, fp
    //     0x10ef284: ldp             fp, lr, [SP], #0x10
    // 0x10ef288: ret
    //     0x10ef288: ret             
    // 0x10ef28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef28c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef290: b               #0x10ef27c
  }
}

// class id: 4524, size: 0x2c, field offset: 0x24
class ValueNotifier<X0> extends ChangeNotifier
    implements ValueListenable<X0> {

  X0 dyn:get:value(ValueNotifier<X0>) {
    // ** addr: 0x8446a8, size: 0x28
    // 0x8446a8: ldr             x1, [SP]
    // 0x8446ac: LoadField: r0 = r1->field_27
    //     0x8446ac: ldur            w0, [x1, #0x27]
    // 0x8446b0: DecompressPointer r0
    //     0x8446b0: add             x0, x0, HEAP, lsl #32
    // 0x8446b4: ret
    //     0x8446b4: ret             
  }
  void dyn:set:value(ValueNotifier<X0>, X0) {
    // ** addr: 0x8446d0, size: 0x4c
    // 0x8446d0: EnterFrame
    //     0x8446d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8446d4: mov             fp, SP
    // 0x8446d8: CheckStackOverflow
    //     0x8446d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8446dc: cmp             SP, x16
    //     0x8446e0: b.ls            #0x8446fc
    // 0x8446e4: ldr             x1, [fp, #0x18]
    // 0x8446e8: ldr             x2, [fp, #0x10]
    // 0x8446ec: r0 = value=()
    //     0x8446ec: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x8446f0: LeaveFrame
    //     0x8446f0: mov             SP, fp
    //     0x8446f4: ldp             fp, lr, [SP], #0x10
    // 0x8446f8: ret
    //     0x8446f8: ret             
    // 0x8446fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8446fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844700: b               #0x8446e4
  }
  set void value=(ValueNotifier<X0>, X0) {
    // ** addr: 0xb68ce8, size: 0xe4
    // 0xb68ce8: EnterFrame
    //     0xb68ce8: stp             fp, lr, [SP, #-0x10]!
    //     0xb68cec: mov             fp, SP
    // 0xb68cf0: AllocStack(0x20)
    //     0xb68cf0: sub             SP, SP, #0x20
    // 0xb68cf4: SetupParameters(ValueNotifier<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb68cf4: mov             x4, x1
    //     0xb68cf8: mov             x3, x2
    //     0xb68cfc: stur            x1, [fp, #-8]
    //     0xb68d00: stur            x2, [fp, #-0x10]
    // 0xb68d04: CheckStackOverflow
    //     0xb68d04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb68d08: cmp             SP, x16
    //     0xb68d0c: b.ls            #0xb68dc4
    // 0xb68d10: LoadField: r2 = r4->field_23
    //     0xb68d10: ldur            w2, [x4, #0x23]
    // 0xb68d14: DecompressPointer r2
    //     0xb68d14: add             x2, x2, HEAP, lsl #32
    // 0xb68d18: mov             x0, x3
    // 0xb68d1c: r1 = Null
    //     0xb68d1c: mov             x1, NULL
    // 0xb68d20: cmp             w2, NULL
    // 0xb68d24: b.eq            #0xb68d40
    // 0xb68d28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb68d28: ldur            w4, [x2, #0x17]
    // 0xb68d2c: DecompressPointer r4
    //     0xb68d2c: add             x4, x4, HEAP, lsl #32
    // 0xb68d30: r8 = X0
    //     0xb68d30: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb68d34: LoadField: r9 = r4->field_7
    //     0xb68d34: ldur            x9, [x4, #7]
    // 0xb68d38: r3 = Null
    //     0xb68d38: ldr             x3, [PP, #0x3040]  ; [pp+0x3040] Null
    // 0xb68d3c: blr             x9
    // 0xb68d40: ldur            x1, [fp, #-8]
    // 0xb68d44: LoadField: r0 = r1->field_27
    //     0xb68d44: ldur            w0, [x1, #0x27]
    // 0xb68d48: DecompressPointer r0
    //     0xb68d48: add             x0, x0, HEAP, lsl #32
    // 0xb68d4c: r2 = 60
    //     0xb68d4c: mov             x2, #0x3c
    // 0xb68d50: branchIfSmi(r0, 0xb68d5c)
    //     0xb68d50: tbz             w0, #0, #0xb68d5c
    // 0xb68d54: r2 = LoadClassIdInstr(r0)
    //     0xb68d54: ldur            x2, [x0, #-1]
    //     0xb68d58: ubfx            x2, x2, #0xc, #0x14
    // 0xb68d5c: ldur            x16, [fp, #-0x10]
    // 0xb68d60: stp             x16, x0, [SP]
    // 0xb68d64: mov             x0, x2
    // 0xb68d68: mov             lr, x0
    // 0xb68d6c: ldr             lr, [x21, lr, lsl #3]
    // 0xb68d70: blr             lr
    // 0xb68d74: tbnz            w0, #4, #0xb68d88
    // 0xb68d78: r0 = Null
    //     0xb68d78: mov             x0, NULL
    // 0xb68d7c: LeaveFrame
    //     0xb68d7c: mov             SP, fp
    //     0xb68d80: ldp             fp, lr, [SP], #0x10
    // 0xb68d84: ret
    //     0xb68d84: ret             
    // 0xb68d88: ldur            x1, [fp, #-8]
    // 0xb68d8c: ldur            x0, [fp, #-0x10]
    // 0xb68d90: StoreField: r1->field_27 = r0
    //     0xb68d90: stur            w0, [x1, #0x27]
    //     0xb68d94: tbz             w0, #0, #0xb68db0
    //     0xb68d98: ldurb           w16, [x1, #-1]
    //     0xb68d9c: ldurb           w17, [x0, #-1]
    //     0xb68da0: and             x16, x17, x16, lsr #2
    //     0xb68da4: tst             x16, HEAP, lsr #32
    //     0xb68da8: b.eq            #0xb68db0
    //     0xb68dac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb68db0: r0 = notifyListeners()
    //     0xb68db0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb68db4: r0 = Null
    //     0xb68db4: mov             x0, NULL
    // 0xb68db8: LeaveFrame
    //     0xb68db8: mov             SP, fp
    //     0xb68dbc: ldp             fp, lr, [SP], #0x10
    // 0xb68dc0: ret
    //     0xb68dc0: ret             
    // 0xb68dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb68dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb68dc8: b               #0xb68d10
  }
}
