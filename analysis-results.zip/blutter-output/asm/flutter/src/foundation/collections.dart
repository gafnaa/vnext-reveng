// lib: , url: package:flutter/src/foundation/collections.dart

// class id: 1048800, size: 0x8
class :: {

  static _ listEquals(/* No info */) {
    // ** addr: 0x8595b0, size: 0x20c
    // 0x8595b0: EnterFrame
    //     0x8595b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8595b4: mov             fp, SP
    // 0x8595b8: AllocStack(0x28)
    //     0x8595b8: sub             SP, SP, #0x28
    // 0x8595bc: CheckStackOverflow
    //     0x8595bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8595c0: cmp             SP, x16
    //     0x8595c4: b.ls            #0x8597ac
    // 0x8595c8: ldr             x1, [fp, #0x18]
    // 0x8595cc: cmp             w1, NULL
    // 0x8595d0: b.ne            #0x8595f4
    // 0x8595d4: ldr             x2, [fp, #0x10]
    // 0x8595d8: cmp             w2, NULL
    // 0x8595dc: r16 = true
    //     0x8595dc: add             x16, NULL, #0x20  ; true
    // 0x8595e0: r17 = false
    //     0x8595e0: add             x17, NULL, #0x30  ; false
    // 0x8595e4: csel            x0, x16, x17, eq
    // 0x8595e8: LeaveFrame
    //     0x8595e8: mov             SP, fp
    //     0x8595ec: ldp             fp, lr, [SP], #0x10
    // 0x8595f0: ret
    //     0x8595f0: ret             
    // 0x8595f4: ldr             x2, [fp, #0x10]
    // 0x8595f8: cmp             w2, NULL
    // 0x8595fc: b.eq            #0x85966c
    // 0x859600: r0 = LoadClassIdInstr(r1)
    //     0x859600: ldur            x0, [x1, #-1]
    //     0x859604: ubfx            x0, x0, #0xc, #0x14
    // 0x859608: str             x1, [SP]
    // 0x85960c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x85960c: mov             x17, #0xf078
    //     0x859610: add             lr, x0, x17
    //     0x859614: ldr             lr, [x21, lr, lsl #3]
    //     0x859618: blr             lr
    // 0x85961c: mov             x2, x0
    // 0x859620: ldr             x1, [fp, #0x10]
    // 0x859624: stur            x2, [fp, #-8]
    // 0x859628: r0 = LoadClassIdInstr(r1)
    //     0x859628: ldur            x0, [x1, #-1]
    //     0x85962c: ubfx            x0, x0, #0xc, #0x14
    // 0x859630: str             x1, [SP]
    // 0x859634: r0 = GDT[cid_x0 + 0xf078]()
    //     0x859634: mov             x17, #0xf078
    //     0x859638: add             lr, x0, x17
    //     0x85963c: ldr             lr, [x21, lr, lsl #3]
    //     0x859640: blr             lr
    // 0x859644: mov             x1, x0
    // 0x859648: ldur            x0, [fp, #-8]
    // 0x85964c: r2 = LoadInt32Instr(r0)
    //     0x85964c: sbfx            x2, x0, #1, #0x1f
    //     0x859650: tbz             w0, #0, #0x859658
    //     0x859654: ldur            x2, [x0, #7]
    // 0x859658: r0 = LoadInt32Instr(r1)
    //     0x859658: sbfx            x0, x1, #1, #0x1f
    //     0x85965c: tbz             w1, #0, #0x859664
    //     0x859660: ldur            x0, [x1, #7]
    // 0x859664: cmp             x2, x0
    // 0x859668: b.eq            #0x85967c
    // 0x85966c: r0 = false
    //     0x85966c: add             x0, NULL, #0x30  ; false
    // 0x859670: LeaveFrame
    //     0x859670: mov             SP, fp
    //     0x859674: ldp             fp, lr, [SP], #0x10
    // 0x859678: ret
    //     0x859678: ret             
    // 0x85967c: ldr             x2, [fp, #0x18]
    // 0x859680: ldr             x1, [fp, #0x10]
    // 0x859684: cmp             w2, w1
    // 0x859688: b.ne            #0x85969c
    // 0x85968c: r0 = true
    //     0x85968c: add             x0, NULL, #0x20  ; true
    // 0x859690: LeaveFrame
    //     0x859690: mov             SP, fp
    //     0x859694: ldp             fp, lr, [SP], #0x10
    // 0x859698: ret
    //     0x859698: ret             
    // 0x85969c: r3 = 0
    //     0x85969c: mov             x3, #0
    // 0x8596a0: stur            x3, [fp, #-0x10]
    // 0x8596a4: CheckStackOverflow
    //     0x8596a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8596a8: cmp             SP, x16
    //     0x8596ac: b.ls            #0x8597b4
    // 0x8596b0: r0 = LoadClassIdInstr(r2)
    //     0x8596b0: ldur            x0, [x2, #-1]
    //     0x8596b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8596b8: str             x2, [SP]
    // 0x8596bc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8596bc: mov             x17, #0xf078
    //     0x8596c0: add             lr, x0, x17
    //     0x8596c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8596c8: blr             lr
    // 0x8596cc: r1 = LoadInt32Instr(r0)
    //     0x8596cc: sbfx            x1, x0, #1, #0x1f
    //     0x8596d0: tbz             w0, #0, #0x8596d8
    //     0x8596d4: ldur            x1, [x0, #7]
    // 0x8596d8: ldur            x2, [fp, #-0x10]
    // 0x8596dc: cmp             x2, x1
    // 0x8596e0: b.ge            #0x85979c
    // 0x8596e4: ldr             x4, [fp, #0x18]
    // 0x8596e8: ldr             x3, [fp, #0x10]
    // 0x8596ec: r0 = BoxInt64Instr(r2)
    //     0x8596ec: sbfiz           x0, x2, #1, #0x1f
    //     0x8596f0: cmp             x2, x0, asr #1
    //     0x8596f4: b.eq            #0x859700
    //     0x8596f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8596fc: stur            x2, [x0, #7]
    // 0x859700: mov             x1, x0
    // 0x859704: stur            x1, [fp, #-8]
    // 0x859708: r0 = LoadClassIdInstr(r4)
    //     0x859708: ldur            x0, [x4, #-1]
    //     0x85970c: ubfx            x0, x0, #0xc, #0x14
    // 0x859710: stp             x1, x4, [SP]
    // 0x859714: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x859714: sub             lr, x0, #0xdfd
    //     0x859718: ldr             lr, [x21, lr, lsl #3]
    //     0x85971c: blr             lr
    // 0x859720: mov             x2, x0
    // 0x859724: ldr             x1, [fp, #0x10]
    // 0x859728: stur            x2, [fp, #-0x18]
    // 0x85972c: r0 = LoadClassIdInstr(r1)
    //     0x85972c: ldur            x0, [x1, #-1]
    //     0x859730: ubfx            x0, x0, #0xc, #0x14
    // 0x859734: ldur            x16, [fp, #-8]
    // 0x859738: stp             x16, x1, [SP]
    // 0x85973c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x85973c: sub             lr, x0, #0xdfd
    //     0x859740: ldr             lr, [x21, lr, lsl #3]
    //     0x859744: blr             lr
    // 0x859748: mov             x1, x0
    // 0x85974c: ldur            x0, [fp, #-0x18]
    // 0x859750: r2 = 60
    //     0x859750: mov             x2, #0x3c
    // 0x859754: branchIfSmi(r0, 0x859760)
    //     0x859754: tbz             w0, #0, #0x859760
    // 0x859758: r2 = LoadClassIdInstr(r0)
    //     0x859758: ldur            x2, [x0, #-1]
    //     0x85975c: ubfx            x2, x2, #0xc, #0x14
    // 0x859760: stp             x1, x0, [SP]
    // 0x859764: mov             x0, x2
    // 0x859768: mov             lr, x0
    // 0x85976c: ldr             lr, [x21, lr, lsl #3]
    // 0x859770: blr             lr
    // 0x859774: tbnz            w0, #4, #0x85978c
    // 0x859778: ldur            x1, [fp, #-0x10]
    // 0x85977c: add             x3, x1, #1
    // 0x859780: ldr             x2, [fp, #0x18]
    // 0x859784: ldr             x1, [fp, #0x10]
    // 0x859788: b               #0x8596a0
    // 0x85978c: r0 = false
    //     0x85978c: add             x0, NULL, #0x30  ; false
    // 0x859790: LeaveFrame
    //     0x859790: mov             SP, fp
    //     0x859794: ldp             fp, lr, [SP], #0x10
    // 0x859798: ret
    //     0x859798: ret             
    // 0x85979c: r0 = true
    //     0x85979c: add             x0, NULL, #0x20  ; true
    // 0x8597a0: LeaveFrame
    //     0x8597a0: mov             SP, fp
    //     0x8597a4: ldp             fp, lr, [SP], #0x10
    // 0x8597a8: ret
    //     0x8597a8: ret             
    // 0x8597ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8597ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8597b0: b               #0x8595c8
    // 0x8597b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8597b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8597b8: b               #0x8596b0
  }
  static _ setEquals(/* No info */) {
    // ** addr: 0x86d470, size: 0x1d4
    // 0x86d470: EnterFrame
    //     0x86d470: stp             fp, lr, [SP, #-0x10]!
    //     0x86d474: mov             fp, SP
    // 0x86d478: AllocStack(0x10)
    //     0x86d478: sub             SP, SP, #0x10
    // 0x86d47c: CheckStackOverflow
    //     0x86d47c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86d480: cmp             SP, x16
    //     0x86d484: b.ls            #0x86d634
    // 0x86d488: ldr             x1, [fp, #0x18]
    // 0x86d48c: cmp             w1, NULL
    // 0x86d490: b.ne            #0x86d4b4
    // 0x86d494: ldr             x2, [fp, #0x10]
    // 0x86d498: cmp             w2, NULL
    // 0x86d49c: r16 = true
    //     0x86d49c: add             x16, NULL, #0x20  ; true
    // 0x86d4a0: r17 = false
    //     0x86d4a0: add             x17, NULL, #0x30  ; false
    // 0x86d4a4: csel            x0, x16, x17, eq
    // 0x86d4a8: LeaveFrame
    //     0x86d4a8: mov             SP, fp
    //     0x86d4ac: ldp             fp, lr, [SP], #0x10
    // 0x86d4b0: ret
    //     0x86d4b0: ret             
    // 0x86d4b4: ldr             x2, [fp, #0x10]
    // 0x86d4b8: cmp             w2, NULL
    // 0x86d4bc: b.eq            #0x86d52c
    // 0x86d4c0: r0 = LoadClassIdInstr(r1)
    //     0x86d4c0: ldur            x0, [x1, #-1]
    //     0x86d4c4: ubfx            x0, x0, #0xc, #0x14
    // 0x86d4c8: str             x1, [SP]
    // 0x86d4cc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x86d4cc: mov             x17, #0xf078
    //     0x86d4d0: add             lr, x0, x17
    //     0x86d4d4: ldr             lr, [x21, lr, lsl #3]
    //     0x86d4d8: blr             lr
    // 0x86d4dc: mov             x2, x0
    // 0x86d4e0: ldr             x1, [fp, #0x10]
    // 0x86d4e4: stur            x2, [fp, #-8]
    // 0x86d4e8: r0 = LoadClassIdInstr(r1)
    //     0x86d4e8: ldur            x0, [x1, #-1]
    //     0x86d4ec: ubfx            x0, x0, #0xc, #0x14
    // 0x86d4f0: str             x1, [SP]
    // 0x86d4f4: r0 = GDT[cid_x0 + 0xf078]()
    //     0x86d4f4: mov             x17, #0xf078
    //     0x86d4f8: add             lr, x0, x17
    //     0x86d4fc: ldr             lr, [x21, lr, lsl #3]
    //     0x86d500: blr             lr
    // 0x86d504: mov             x1, x0
    // 0x86d508: ldur            x0, [fp, #-8]
    // 0x86d50c: r2 = LoadInt32Instr(r0)
    //     0x86d50c: sbfx            x2, x0, #1, #0x1f
    //     0x86d510: tbz             w0, #0, #0x86d518
    //     0x86d514: ldur            x2, [x0, #7]
    // 0x86d518: r0 = LoadInt32Instr(r1)
    //     0x86d518: sbfx            x0, x1, #1, #0x1f
    //     0x86d51c: tbz             w1, #0, #0x86d524
    //     0x86d520: ldur            x0, [x1, #7]
    // 0x86d524: cmp             x2, x0
    // 0x86d528: b.eq            #0x86d53c
    // 0x86d52c: r0 = false
    //     0x86d52c: add             x0, NULL, #0x30  ; false
    // 0x86d530: LeaveFrame
    //     0x86d530: mov             SP, fp
    //     0x86d534: ldp             fp, lr, [SP], #0x10
    // 0x86d538: ret
    //     0x86d538: ret             
    // 0x86d53c: ldr             x1, [fp, #0x18]
    // 0x86d540: ldr             x2, [fp, #0x10]
    // 0x86d544: cmp             w1, w2
    // 0x86d548: b.ne            #0x86d55c
    // 0x86d54c: r0 = true
    //     0x86d54c: add             x0, NULL, #0x20  ; true
    // 0x86d550: LeaveFrame
    //     0x86d550: mov             SP, fp
    //     0x86d554: ldp             fp, lr, [SP], #0x10
    // 0x86d558: ret
    //     0x86d558: ret             
    // 0x86d55c: r0 = LoadClassIdInstr(r1)
    //     0x86d55c: ldur            x0, [x1, #-1]
    //     0x86d560: ubfx            x0, x0, #0xc, #0x14
    // 0x86d564: r0 = GDT[cid_x0 + 0x12641]()
    //     0x86d564: mov             x17, #0x2641
    //     0x86d568: movk            x17, #1, lsl #16
    //     0x86d56c: add             lr, x0, x17
    //     0x86d570: ldr             lr, [x21, lr, lsl #3]
    //     0x86d574: blr             lr
    // 0x86d578: mov             x2, x0
    // 0x86d57c: stur            x2, [fp, #-8]
    // 0x86d580: ldr             x3, [fp, #0x10]
    // 0x86d584: CheckStackOverflow
    //     0x86d584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86d588: cmp             SP, x16
    //     0x86d58c: b.ls            #0x86d63c
    // 0x86d590: r0 = LoadClassIdInstr(r2)
    //     0x86d590: ldur            x0, [x2, #-1]
    //     0x86d594: ubfx            x0, x0, #0xc, #0x14
    // 0x86d598: mov             x1, x2
    // 0x86d59c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x86d59c: mov             x17, #0x845b
    //     0x86d5a0: movk            x17, #1, lsl #16
    //     0x86d5a4: add             lr, x0, x17
    //     0x86d5a8: ldr             lr, [x21, lr, lsl #3]
    //     0x86d5ac: blr             lr
    // 0x86d5b0: tbnz            w0, #4, #0x86d624
    // 0x86d5b4: ldr             x3, [fp, #0x10]
    // 0x86d5b8: ldur            x2, [fp, #-8]
    // 0x86d5bc: r0 = LoadClassIdInstr(r2)
    //     0x86d5bc: ldur            x0, [x2, #-1]
    //     0x86d5c0: ubfx            x0, x0, #0xc, #0x14
    // 0x86d5c4: mov             x1, x2
    // 0x86d5c8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x86d5c8: mov             x17, #0x7d4c
    //     0x86d5cc: movk            x17, #1, lsl #16
    //     0x86d5d0: add             lr, x0, x17
    //     0x86d5d4: ldr             lr, [x21, lr, lsl #3]
    //     0x86d5d8: blr             lr
    // 0x86d5dc: ldr             x3, [fp, #0x10]
    // 0x86d5e0: r1 = LoadClassIdInstr(r3)
    //     0x86d5e0: ldur            x1, [x3, #-1]
    //     0x86d5e4: ubfx            x1, x1, #0xc, #0x14
    // 0x86d5e8: mov             x2, x0
    // 0x86d5ec: mov             x0, x1
    // 0x86d5f0: mov             x1, x3
    // 0x86d5f4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x86d5f4: mov             x17, #0x2929
    //     0x86d5f8: movk            x17, #1, lsl #16
    //     0x86d5fc: add             lr, x0, x17
    //     0x86d600: ldr             lr, [x21, lr, lsl #3]
    //     0x86d604: blr             lr
    // 0x86d608: tbnz            w0, #4, #0x86d614
    // 0x86d60c: ldur            x2, [fp, #-8]
    // 0x86d610: b               #0x86d580
    // 0x86d614: r0 = false
    //     0x86d614: add             x0, NULL, #0x30  ; false
    // 0x86d618: LeaveFrame
    //     0x86d618: mov             SP, fp
    //     0x86d61c: ldp             fp, lr, [SP], #0x10
    // 0x86d620: ret
    //     0x86d620: ret             
    // 0x86d624: r0 = true
    //     0x86d624: add             x0, NULL, #0x20  ; true
    // 0x86d628: LeaveFrame
    //     0x86d628: mov             SP, fp
    //     0x86d62c: ldp             fp, lr, [SP], #0x10
    // 0x86d630: ret
    //     0x86d630: ret             
    // 0x86d634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86d634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86d638: b               #0x86d488
    // 0x86d63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86d63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86d640: b               #0x86d590
  }
  static _ mergeSort(/* No info */) {
    // ** addr: 0xb374cc, size: 0x29c
    // 0xb374cc: EnterFrame
    //     0xb374cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb374d0: mov             fp, SP
    // 0xb374d4: AllocStack(0x98)
    //     0xb374d4: sub             SP, SP, #0x98
    // 0xb374d8: SetupParameters(dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xb374d8: ldur            w0, [x4, #0x13]
    //     0xb374dc: sub             x1, x0, #4
    //     0xb374e0: add             x2, fp, w1, sxtw #2
    //     0xb374e4: ldr             x2, [x2, #0x18]
    //     0xb374e8: stur            x2, [fp, #-0x18]
    //     0xb374ec: add             x3, fp, w1, sxtw #2
    //     0xb374f0: ldr             x3, [x3, #0x10]
    //     0xb374f4: stur            x3, [fp, #-0x10]
    //     0xb374f8: ldur            w0, [x4, #0xf]
    //     0xb374fc: cbnz            w0, #0xb37508
    //     0xb37500: mov             x1, NULL
    //     0xb37504: b               #0xb37514
    //     0xb37508: ldur            w0, [x4, #0x17]
    //     0xb3750c: add             x1, fp, w0, sxtw #2
    //     0xb37510: ldr             x1, [x1, #0x10]
    //     0xb37514: stur            x1, [fp, #-8]
    // 0xb37518: CheckStackOverflow
    //     0xb37518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3751c: cmp             SP, x16
    //     0xb37520: b.ls            #0xb37758
    // 0xb37524: r0 = LoadClassIdInstr(r2)
    //     0xb37524: ldur            x0, [x2, #-1]
    //     0xb37528: ubfx            x0, x0, #0xc, #0x14
    // 0xb3752c: str             x2, [SP]
    // 0xb37530: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb37530: mov             x17, #0xf078
    //     0xb37534: add             lr, x0, x17
    //     0xb37538: ldr             lr, [x21, lr, lsl #3]
    //     0xb3753c: blr             lr
    // 0xb37540: r1 = LoadInt32Instr(r0)
    //     0xb37540: sbfx            x1, x0, #1, #0x1f
    //     0xb37544: tbz             w0, #0, #0xb3754c
    //     0xb37548: ldur            x1, [x0, #7]
    // 0xb3754c: stur            x1, [fp, #-0x30]
    // 0xb37550: cmp             x1, #2
    // 0xb37554: b.ge            #0xb37568
    // 0xb37558: r0 = Null
    //     0xb37558: mov             x0, NULL
    // 0xb3755c: LeaveFrame
    //     0xb3755c: mov             SP, fp
    //     0xb37560: ldp             fp, lr, [SP], #0x10
    // 0xb37564: ret
    //     0xb37564: ret             
    // 0xb37568: cmp             x1, #0x20
    // 0xb3756c: b.ge            #0xb3759c
    // 0xb37570: ldur            x16, [fp, #-8]
    // 0xb37574: ldur            lr, [fp, #-0x18]
    // 0xb37578: stp             lr, x16, [SP, #0x10]
    // 0xb3757c: ldur            x16, [fp, #-0x10]
    // 0xb37580: stp             x1, x16, [SP]
    // 0xb37584: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xb37584: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xb37588: r0 = _insertionSort()
    //     0xb37588: bl              #0xb38004  ; [package:flutter/src/foundation/collections.dart] ::_insertionSort
    // 0xb3758c: r0 = Null
    //     0xb3758c: mov             x0, NULL
    // 0xb37590: LeaveFrame
    //     0xb37590: mov             SP, fp
    //     0xb37594: ldp             fp, lr, [SP], #0x10
    // 0xb37598: ret
    //     0xb37598: ret             
    // 0xb3759c: ldur            x2, [fp, #-0x18]
    // 0xb375a0: asr             x3, x1, #1
    // 0xb375a4: stur            x3, [fp, #-0x28]
    // 0xb375a8: sub             x4, x1, x3
    // 0xb375ac: stur            x4, [fp, #-0x20]
    // 0xb375b0: r0 = LoadClassIdInstr(r2)
    //     0xb375b0: ldur            x0, [x2, #-1]
    //     0xb375b4: ubfx            x0, x0, #0xc, #0x14
    // 0xb375b8: stp             xzr, x2, [SP]
    // 0xb375bc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb375bc: sub             lr, x0, #0xdfd
    //     0xb375c0: ldr             lr, [x21, lr, lsl #3]
    //     0xb375c4: blr             lr
    // 0xb375c8: mov             x4, x0
    // 0xb375cc: ldur            x3, [fp, #-0x20]
    // 0xb375d0: stur            x4, [fp, #-0x38]
    // 0xb375d4: r0 = BoxInt64Instr(r3)
    //     0xb375d4: sbfiz           x0, x3, #1, #0x1f
    //     0xb375d8: cmp             x3, x0, asr #1
    //     0xb375dc: b.eq            #0xb375e8
    //     0xb375e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb375e4: stur            x3, [x0, #7]
    // 0xb375e8: ldur            x1, [fp, #-8]
    // 0xb375ec: mov             x2, x0
    // 0xb375f0: r0 = AllocateArray()
    //     0xb375f0: bl              #0x13df928  ; AllocateArrayStub
    // 0xb375f4: mov             x4, x0
    // 0xb375f8: ldur            x3, [fp, #-0x38]
    // 0xb375fc: stur            x4, [fp, #-0x48]
    // 0xb37600: cmp             w3, NULL
    // 0xb37604: b.eq            #0xb3769c
    // 0xb37608: r6 = 0
    //     0xb37608: mov             x6, #0
    // 0xb3760c: ldur            x5, [fp, #-0x20]
    // 0xb37610: stur            x6, [fp, #-0x40]
    // 0xb37614: CheckStackOverflow
    //     0xb37614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37618: cmp             SP, x16
    //     0xb3761c: b.ls            #0xb37760
    // 0xb37620: cmp             x6, x5
    // 0xb37624: b.ge            #0xb3769c
    // 0xb37628: mov             x0, x3
    // 0xb3762c: ldur            x2, [fp, #-8]
    // 0xb37630: r1 = Null
    //     0xb37630: mov             x1, NULL
    // 0xb37634: cmp             w2, NULL
    // 0xb37638: b.eq            #0xb37658
    // 0xb3763c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb3763c: ldur            w4, [x2, #0x17]
    // 0xb37640: DecompressPointer r4
    //     0xb37640: add             x4, x4, HEAP, lsl #32
    // 0xb37644: r8 = X0
    //     0xb37644: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb37648: LoadField: r9 = r4->field_7
    //     0xb37648: ldur            x9, [x4, #7]
    // 0xb3764c: r3 = Null
    //     0xb3764c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe188] Null
    //     0xb37650: ldr             x3, [x3, #0x188]
    // 0xb37654: blr             x9
    // 0xb37658: ldur            x1, [fp, #-0x48]
    // 0xb3765c: ldur            x0, [fp, #-0x38]
    // 0xb37660: ldur            x2, [fp, #-0x40]
    // 0xb37664: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb37664: add             x25, x1, x2, lsl #2
    //     0xb37668: add             x25, x25, #0xf
    //     0xb3766c: str             w0, [x25]
    //     0xb37670: tbz             w0, #0, #0xb3768c
    //     0xb37674: ldurb           w16, [x1, #-1]
    //     0xb37678: ldurb           w17, [x0, #-1]
    //     0xb3767c: and             x16, x17, x16, lsr #2
    //     0xb37680: tst             x16, HEAP, lsr #32
    //     0xb37684: b.eq            #0xb3768c
    //     0xb37688: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb3768c: add             x6, x2, #1
    // 0xb37690: ldur            x3, [fp, #-0x38]
    // 0xb37694: ldur            x4, [fp, #-0x48]
    // 0xb37698: b               #0xb3760c
    // 0xb3769c: ldur            x2, [fp, #-0x28]
    // 0xb376a0: ldur            x0, [fp, #-0x20]
    // 0xb376a4: ldur            x1, [fp, #-0x30]
    // 0xb376a8: ldur            x16, [fp, #-8]
    // 0xb376ac: ldur            lr, [fp, #-0x18]
    // 0xb376b0: stp             lr, x16, [SP, #0x28]
    // 0xb376b4: ldur            x16, [fp, #-0x10]
    // 0xb376b8: stp             x2, x16, [SP, #0x18]
    // 0xb376bc: ldur            x16, [fp, #-0x48]
    // 0xb376c0: stp             x16, x1, [SP, #8]
    // 0xb376c4: str             xzr, [SP]
    // 0xb376c8: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xb376c8: add             x4, PP, #0xe, lsl #12  ; [pp+0xe198] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xb376cc: ldr             x4, [x4, #0x198]
    // 0xb376d0: r0 = _mergeSort()
    //     0xb376d0: bl              #0xb37bac  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xb376d4: ldur            x16, [fp, #-8]
    // 0xb376d8: ldur            lr, [fp, #-0x18]
    // 0xb376dc: stp             lr, x16, [SP, #0x28]
    // 0xb376e0: ldur            x16, [fp, #-0x10]
    // 0xb376e4: stp             xzr, x16, [SP, #0x18]
    // 0xb376e8: ldur            x0, [fp, #-0x28]
    // 0xb376ec: ldur            x16, [fp, #-0x18]
    // 0xb376f0: stp             x16, x0, [SP, #8]
    // 0xb376f4: ldur            x0, [fp, #-0x20]
    // 0xb376f8: str             x0, [SP]
    // 0xb376fc: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xb376fc: add             x4, PP, #0xe, lsl #12  ; [pp+0xe198] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xb37700: ldr             x4, [x4, #0x198]
    // 0xb37704: r0 = _mergeSort()
    //     0xb37704: bl              #0xb37bac  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xb37708: ldur            x16, [fp, #-8]
    // 0xb3770c: ldur            lr, [fp, #-0x10]
    // 0xb37710: stp             lr, x16, [SP, #0x40]
    // 0xb37714: ldur            x16, [fp, #-0x18]
    // 0xb37718: str             x16, [SP, #0x38]
    // 0xb3771c: ldur            x0, [fp, #-0x20]
    // 0xb37720: str             x0, [SP, #0x30]
    // 0xb37724: ldur            x1, [fp, #-0x30]
    // 0xb37728: ldur            x16, [fp, #-0x48]
    // 0xb3772c: stp             x16, x1, [SP, #0x20]
    // 0xb37730: stp             x0, xzr, [SP, #0x10]
    // 0xb37734: ldur            x16, [fp, #-0x18]
    // 0xb37738: stp             xzr, x16, [SP]
    // 0xb3773c: r4 = const [0x1, 0x9, 0x9, 0x9, null]
    //     0xb3773c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe1a0] List(5) [0x1, 0x9, 0x9, 0x9, Null]
    //     0xb37740: ldr             x4, [x4, #0x1a0]
    // 0xb37744: r0 = _merge()
    //     0xb37744: bl              #0xb37768  ; [package:flutter/src/foundation/collections.dart] ::_merge
    // 0xb37748: r0 = Null
    //     0xb37748: mov             x0, NULL
    // 0xb3774c: LeaveFrame
    //     0xb3774c: mov             SP, fp
    //     0xb37750: ldp             fp, lr, [SP], #0x10
    // 0xb37754: ret
    //     0xb37754: ret             
    // 0xb37758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3775c: b               #0xb37524
    // 0xb37760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37764: b               #0xb37620
  }
  static _ _merge(/* No info */) {
    // ** addr: 0xb37768, size: 0x444
    // 0xb37768: EnterFrame
    //     0xb37768: stp             fp, lr, [SP, #-0x10]!
    //     0xb3776c: mov             fp, SP
    // 0xb37770: AllocStack(0x50)
    //     0xb37770: sub             SP, SP, #0x50
    // 0xb37774: CheckStackOverflow
    //     0xb37774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37778: cmp             SP, x16
    //     0xb3777c: b.ls            #0xb37b98
    // 0xb37780: ldr             x2, [fp, #0x40]
    // 0xb37784: add             x3, x2, #1
    // 0xb37788: stur            x3, [fp, #-8]
    // 0xb3778c: r0 = BoxInt64Instr(r2)
    //     0xb3778c: sbfiz           x0, x2, #1, #0x1f
    //     0xb37790: cmp             x2, x0, asr #1
    //     0xb37794: b.eq            #0xb377a0
    //     0xb37798: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb3779c: stur            x2, [x0, #7]
    // 0xb377a0: ldr             x5, [fp, #0x48]
    // 0xb377a4: r1 = LoadClassIdInstr(r5)
    //     0xb377a4: ldur            x1, [x5, #-1]
    //     0xb377a8: ubfx            x1, x1, #0xc, #0x14
    // 0xb377ac: stp             x0, x5, [SP]
    // 0xb377b0: mov             x0, x1
    // 0xb377b4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb377b4: sub             lr, x0, #0xdfd
    //     0xb377b8: ldr             lr, [x21, lr, lsl #3]
    //     0xb377bc: blr             lr
    // 0xb377c0: mov             x3, x0
    // 0xb377c4: ldr             x2, [fp, #0x28]
    // 0xb377c8: stur            x3, [fp, #-0x18]
    // 0xb377cc: add             x4, x2, #1
    // 0xb377d0: stur            x4, [fp, #-0x10]
    // 0xb377d4: r0 = BoxInt64Instr(r2)
    //     0xb377d4: sbfiz           x0, x2, #1, #0x1f
    //     0xb377d8: cmp             x2, x0, asr #1
    //     0xb377dc: b.eq            #0xb377e8
    //     0xb377e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb377e4: stur            x2, [x0, #7]
    // 0xb377e8: ldr             x5, [fp, #0x30]
    // 0xb377ec: r1 = LoadClassIdInstr(r5)
    //     0xb377ec: ldur            x1, [x5, #-1]
    //     0xb377f0: ubfx            x1, x1, #0xc, #0x14
    // 0xb377f4: stp             x0, x5, [SP]
    // 0xb377f8: mov             x0, x1
    // 0xb377fc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb377fc: sub             lr, x0, #0xdfd
    //     0xb37800: ldr             lr, [x21, lr, lsl #3]
    //     0xb37804: blr             lr
    // 0xb37808: mov             x1, x0
    // 0xb3780c: ldr             x0, [fp, #0x10]
    // 0xb37810: mov             x10, x0
    // 0xb37814: ldur            x9, [fp, #-8]
    // 0xb37818: ldur            x8, [fp, #-0x10]
    // 0xb3781c: ldur            x7, [fp, #-0x18]
    // 0xb37820: mov             x6, x1
    // 0xb37824: ldr             x1, [fp, #0x48]
    // 0xb37828: ldr             x4, [fp, #0x38]
    // 0xb3782c: ldr             x5, [fp, #0x30]
    // 0xb37830: ldr             x3, [fp, #0x20]
    // 0xb37834: ldr             x2, [fp, #0x18]
    // 0xb37838: stur            x10, [fp, #-8]
    // 0xb3783c: stur            x9, [fp, #-0x10]
    // 0xb37840: stur            x8, [fp, #-0x20]
    // 0xb37844: stur            x7, [fp, #-0x18]
    // 0xb37848: stur            x6, [fp, #-0x28]
    // 0xb3784c: CheckStackOverflow
    //     0xb3784c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37850: cmp             SP, x16
    //     0xb37854: b.ls            #0xb37ba0
    // 0xb37858: ldr             x16, [fp, #0x50]
    // 0xb3785c: stp             x7, x16, [SP, #8]
    // 0xb37860: str             x6, [SP]
    // 0xb37864: ldr             x0, [fp, #0x50]
    // 0xb37868: ClosureCall
    //     0xb37868: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb3786c: ldur            x2, [x0, #0x1f]
    //     0xb37870: blr             x2
    // 0xb37874: cmp             w0, NULL
    // 0xb37878: b.eq            #0xb37ba8
    // 0xb3787c: r1 = LoadInt32Instr(r0)
    //     0xb3787c: sbfx            x1, x0, #1, #0x1f
    //     0xb37880: tbz             w0, #0, #0xb37888
    //     0xb37884: ldur            x1, [x0, #7]
    // 0xb37888: cmp             x1, #0
    // 0xb3788c: b.gt            #0xb37a10
    // 0xb37890: ldr             x3, [fp, #0x38]
    // 0xb37894: ldr             x2, [fp, #0x18]
    // 0xb37898: ldur            x5, [fp, #-8]
    // 0xb3789c: ldur            x4, [fp, #-0x10]
    // 0xb378a0: add             x6, x5, #1
    // 0xb378a4: stur            x6, [fp, #-0x30]
    // 0xb378a8: r0 = BoxInt64Instr(r5)
    //     0xb378a8: sbfiz           x0, x5, #1, #0x1f
    //     0xb378ac: cmp             x5, x0, asr #1
    //     0xb378b0: b.eq            #0xb378bc
    //     0xb378b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb378b8: stur            x5, [x0, #7]
    // 0xb378bc: r1 = LoadClassIdInstr(r2)
    //     0xb378bc: ldur            x1, [x2, #-1]
    //     0xb378c0: ubfx            x1, x1, #0xc, #0x14
    // 0xb378c4: stp             x0, x2, [SP, #8]
    // 0xb378c8: ldur            x16, [fp, #-0x18]
    // 0xb378cc: str             x16, [SP]
    // 0xb378d0: mov             x0, x1
    // 0xb378d4: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb378d4: mov             x17, #0x8dc8
    //     0xb378d8: movk            x17, #1, lsl #16
    //     0xb378dc: add             lr, x0, x17
    //     0xb378e0: ldr             lr, [x21, lr, lsl #3]
    //     0xb378e4: blr             lr
    // 0xb378e8: ldr             x2, [fp, #0x38]
    // 0xb378ec: ldur            x3, [fp, #-0x10]
    // 0xb378f0: cmp             x3, x2
    // 0xb378f4: b.eq            #0xb3794c
    // 0xb378f8: ldr             x5, [fp, #0x48]
    // 0xb378fc: add             x4, x3, #1
    // 0xb37900: stur            x4, [fp, #-0x38]
    // 0xb37904: r0 = BoxInt64Instr(r3)
    //     0xb37904: sbfiz           x0, x3, #1, #0x1f
    //     0xb37908: cmp             x3, x0, asr #1
    //     0xb3790c: b.eq            #0xb37918
    //     0xb37910: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37914: stur            x3, [x0, #7]
    // 0xb37918: r1 = LoadClassIdInstr(r5)
    //     0xb37918: ldur            x1, [x5, #-1]
    //     0xb3791c: ubfx            x1, x1, #0xc, #0x14
    // 0xb37920: stp             x0, x5, [SP]
    // 0xb37924: mov             x0, x1
    // 0xb37928: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb37928: sub             lr, x0, #0xdfd
    //     0xb3792c: ldr             lr, [x21, lr, lsl #3]
    //     0xb37930: blr             lr
    // 0xb37934: ldur            x10, [fp, #-0x30]
    // 0xb37938: ldur            x9, [fp, #-0x38]
    // 0xb3793c: ldur            x8, [fp, #-0x20]
    // 0xb37940: mov             x7, x0
    // 0xb37944: ldur            x6, [fp, #-0x28]
    // 0xb37948: b               #0xb37824
    // 0xb3794c: ldr             x4, [fp, #0x20]
    // 0xb37950: ldr             x2, [fp, #0x18]
    // 0xb37954: ldur            x5, [fp, #-0x20]
    // 0xb37958: ldur            x3, [fp, #-0x30]
    // 0xb3795c: add             x6, x3, #1
    // 0xb37960: stur            x6, [fp, #-0x38]
    // 0xb37964: r0 = BoxInt64Instr(r3)
    //     0xb37964: sbfiz           x0, x3, #1, #0x1f
    //     0xb37968: cmp             x3, x0, asr #1
    //     0xb3796c: b.eq            #0xb37978
    //     0xb37970: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37974: stur            x3, [x0, #7]
    // 0xb37978: r1 = LoadClassIdInstr(r2)
    //     0xb37978: ldur            x1, [x2, #-1]
    //     0xb3797c: ubfx            x1, x1, #0xc, #0x14
    // 0xb37980: stp             x0, x2, [SP, #8]
    // 0xb37984: ldur            x16, [fp, #-0x28]
    // 0xb37988: str             x16, [SP]
    // 0xb3798c: mov             x0, x1
    // 0xb37990: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb37990: mov             x17, #0x8dc8
    //     0xb37994: movk            x17, #1, lsl #16
    //     0xb37998: add             lr, x0, x17
    //     0xb3799c: ldr             lr, [x21, lr, lsl #3]
    //     0xb379a0: blr             lr
    // 0xb379a4: ldr             x2, [fp, #0x20]
    // 0xb379a8: ldur            x4, [fp, #-0x20]
    // 0xb379ac: sub             x0, x2, x4
    // 0xb379b0: ldur            x2, [fp, #-0x38]
    // 0xb379b4: add             x3, x2, x0
    // 0xb379b8: r0 = BoxInt64Instr(r4)
    //     0xb379b8: sbfiz           x0, x4, #1, #0x1f
    //     0xb379bc: cmp             x4, x0, asr #1
    //     0xb379c0: b.eq            #0xb379cc
    //     0xb379c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb379c8: stur            x4, [x0, #7]
    // 0xb379cc: ldr             x6, [fp, #0x18]
    // 0xb379d0: r1 = LoadClassIdInstr(r6)
    //     0xb379d0: ldur            x1, [x6, #-1]
    //     0xb379d4: ubfx            x1, x1, #0xc, #0x14
    // 0xb379d8: str             x0, [SP]
    // 0xb379dc: mov             x0, x1
    // 0xb379e0: mov             x1, x6
    // 0xb379e4: ldr             x5, [fp, #0x30]
    // 0xb379e8: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xb379e8: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xb379ec: r0 = GDT[cid_x0 + 0x18893]()
    //     0xb379ec: mov             x17, #0x8893
    //     0xb379f0: movk            x17, #1, lsl #16
    //     0xb379f4: add             lr, x0, x17
    //     0xb379f8: ldr             lr, [x21, lr, lsl #3]
    //     0xb379fc: blr             lr
    // 0xb37a00: r0 = Null
    //     0xb37a00: mov             x0, NULL
    // 0xb37a04: LeaveFrame
    //     0xb37a04: mov             SP, fp
    //     0xb37a08: ldp             fp, lr, [SP], #0x10
    // 0xb37a0c: ret
    //     0xb37a0c: ret             
    // 0xb37a10: ldr             x2, [fp, #0x20]
    // 0xb37a14: ldr             x6, [fp, #0x18]
    // 0xb37a18: ldur            x5, [fp, #-8]
    // 0xb37a1c: ldur            x3, [fp, #-0x10]
    // 0xb37a20: ldur            x4, [fp, #-0x20]
    // 0xb37a24: add             x7, x5, #1
    // 0xb37a28: stur            x7, [fp, #-0x30]
    // 0xb37a2c: r0 = BoxInt64Instr(r5)
    //     0xb37a2c: sbfiz           x0, x5, #1, #0x1f
    //     0xb37a30: cmp             x5, x0, asr #1
    //     0xb37a34: b.eq            #0xb37a40
    //     0xb37a38: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37a3c: stur            x5, [x0, #7]
    // 0xb37a40: r1 = LoadClassIdInstr(r6)
    //     0xb37a40: ldur            x1, [x6, #-1]
    //     0xb37a44: ubfx            x1, x1, #0xc, #0x14
    // 0xb37a48: stp             x0, x6, [SP, #8]
    // 0xb37a4c: ldur            x16, [fp, #-0x28]
    // 0xb37a50: str             x16, [SP]
    // 0xb37a54: mov             x0, x1
    // 0xb37a58: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb37a58: mov             x17, #0x8dc8
    //     0xb37a5c: movk            x17, #1, lsl #16
    //     0xb37a60: add             lr, x0, x17
    //     0xb37a64: ldr             lr, [x21, lr, lsl #3]
    //     0xb37a68: blr             lr
    // 0xb37a6c: ldr             x2, [fp, #0x20]
    // 0xb37a70: ldur            x3, [fp, #-0x20]
    // 0xb37a74: cmp             x3, x2
    // 0xb37a78: b.eq            #0xb37ad0
    // 0xb37a7c: ldr             x4, [fp, #0x30]
    // 0xb37a80: add             x5, x3, #1
    // 0xb37a84: stur            x5, [fp, #-8]
    // 0xb37a88: r0 = BoxInt64Instr(r3)
    //     0xb37a88: sbfiz           x0, x3, #1, #0x1f
    //     0xb37a8c: cmp             x3, x0, asr #1
    //     0xb37a90: b.eq            #0xb37a9c
    //     0xb37a94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37a98: stur            x3, [x0, #7]
    // 0xb37a9c: r1 = LoadClassIdInstr(r4)
    //     0xb37a9c: ldur            x1, [x4, #-1]
    //     0xb37aa0: ubfx            x1, x1, #0xc, #0x14
    // 0xb37aa4: stp             x0, x4, [SP]
    // 0xb37aa8: mov             x0, x1
    // 0xb37aac: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb37aac: sub             lr, x0, #0xdfd
    //     0xb37ab0: ldr             lr, [x21, lr, lsl #3]
    //     0xb37ab4: blr             lr
    // 0xb37ab8: ldur            x10, [fp, #-0x30]
    // 0xb37abc: ldur            x9, [fp, #-0x10]
    // 0xb37ac0: ldur            x8, [fp, #-8]
    // 0xb37ac4: ldur            x7, [fp, #-0x18]
    // 0xb37ac8: mov             x6, x0
    // 0xb37acc: b               #0xb37824
    // 0xb37ad0: ldr             x5, [fp, #0x38]
    // 0xb37ad4: ldr             x3, [fp, #0x18]
    // 0xb37ad8: ldur            x2, [fp, #-0x10]
    // 0xb37adc: ldur            x4, [fp, #-0x30]
    // 0xb37ae0: add             x6, x4, #1
    // 0xb37ae4: stur            x6, [fp, #-8]
    // 0xb37ae8: r0 = BoxInt64Instr(r4)
    //     0xb37ae8: sbfiz           x0, x4, #1, #0x1f
    //     0xb37aec: cmp             x4, x0, asr #1
    //     0xb37af0: b.eq            #0xb37afc
    //     0xb37af4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37af8: stur            x4, [x0, #7]
    // 0xb37afc: r1 = LoadClassIdInstr(r3)
    //     0xb37afc: ldur            x1, [x3, #-1]
    //     0xb37b00: ubfx            x1, x1, #0xc, #0x14
    // 0xb37b04: stp             x0, x3, [SP, #8]
    // 0xb37b08: ldur            x16, [fp, #-0x18]
    // 0xb37b0c: str             x16, [SP]
    // 0xb37b10: mov             x0, x1
    // 0xb37b14: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb37b14: mov             x17, #0x8dc8
    //     0xb37b18: movk            x17, #1, lsl #16
    //     0xb37b1c: add             lr, x0, x17
    //     0xb37b20: ldr             lr, [x21, lr, lsl #3]
    //     0xb37b24: blr             lr
    // 0xb37b28: ldr             x0, [fp, #0x38]
    // 0xb37b2c: ldur            x2, [fp, #-0x10]
    // 0xb37b30: sub             x1, x0, x2
    // 0xb37b34: ldur            x3, [fp, #-8]
    // 0xb37b38: add             x4, x3, x1
    // 0xb37b3c: r0 = BoxInt64Instr(r2)
    //     0xb37b3c: sbfiz           x0, x2, #1, #0x1f
    //     0xb37b40: cmp             x2, x0, asr #1
    //     0xb37b44: b.eq            #0xb37b50
    //     0xb37b48: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37b4c: stur            x2, [x0, #7]
    // 0xb37b50: ldr             x1, [fp, #0x18]
    // 0xb37b54: r2 = LoadClassIdInstr(r1)
    //     0xb37b54: ldur            x2, [x1, #-1]
    //     0xb37b58: ubfx            x2, x2, #0xc, #0x14
    // 0xb37b5c: str             x0, [SP]
    // 0xb37b60: mov             x0, x2
    // 0xb37b64: mov             x2, x3
    // 0xb37b68: mov             x3, x4
    // 0xb37b6c: ldr             x5, [fp, #0x48]
    // 0xb37b70: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xb37b70: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xb37b74: r0 = GDT[cid_x0 + 0x18893]()
    //     0xb37b74: mov             x17, #0x8893
    //     0xb37b78: movk            x17, #1, lsl #16
    //     0xb37b7c: add             lr, x0, x17
    //     0xb37b80: ldr             lr, [x21, lr, lsl #3]
    //     0xb37b84: blr             lr
    // 0xb37b88: r0 = Null
    //     0xb37b88: mov             x0, NULL
    // 0xb37b8c: LeaveFrame
    //     0xb37b8c: mov             SP, fp
    //     0xb37b90: ldp             fp, lr, [SP], #0x10
    // 0xb37b94: ret
    //     0xb37b94: ret             
    // 0xb37b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37b98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37b9c: b               #0xb37780
    // 0xb37ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37ba0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37ba4: b               #0xb37858
    // 0xb37ba8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb37ba8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _mergeSort(/* No info */) {
    // ** addr: 0xb37bac, size: 0x180
    // 0xb37bac: EnterFrame
    //     0xb37bac: stp             fp, lr, [SP, #-0x10]!
    //     0xb37bb0: mov             fp, SP
    // 0xb37bb4: AllocStack(0x78)
    //     0xb37bb4: sub             SP, SP, #0x78
    // 0xb37bb8: SetupParameters([dynamic _, dynamic _, dynamic _ /* r0 */, dynamic _ /* r1 */])
    //     0xb37bb8: ldur            w0, [x4, #0xf]
    //     0xb37bbc: cbnz            w0, #0xb37bc8
    //     0xb37bc0: mov             x2, NULL
    //     0xb37bc4: b               #0xb37bd8
    //     0xb37bc8: ldur            w0, [x4, #0x17]
    //     0xb37bcc: add             x1, fp, w0, sxtw #2
    //     0xb37bd0: ldr             x1, [x1, #0x10]
    //     0xb37bd4: mov             x2, x1
    //     0xb37bd8: ldr             x1, [fp, #0x28]
    //     0xb37bdc: ldr             x0, [fp, #0x20]
    //     0xb37be0: stur            x2, [fp, #-0x28]
    // 0xb37be4: CheckStackOverflow
    //     0xb37be4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37be8: cmp             SP, x16
    //     0xb37bec: b.ls            #0xb37d24
    // 0xb37bf0: sub             x3, x0, x1
    // 0xb37bf4: cmp             x3, #0x20
    // 0xb37bf8: b.ge            #0xb37c38
    // 0xb37bfc: ldr             x4, [fp, #0x10]
    // 0xb37c00: ldr             x16, [fp, #0x38]
    // 0xb37c04: stp             x16, x2, [SP, #0x28]
    // 0xb37c08: ldr             x16, [fp, #0x30]
    // 0xb37c0c: stp             x1, x16, [SP, #0x18]
    // 0xb37c10: ldr             x16, [fp, #0x18]
    // 0xb37c14: stp             x16, x0, [SP, #8]
    // 0xb37c18: str             x4, [SP]
    // 0xb37c1c: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xb37c1c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe198] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xb37c20: ldr             x4, [x4, #0x198]
    // 0xb37c24: r0 = _movingInsertionSort()
    //     0xb37c24: bl              #0xb37d2c  ; [package:flutter/src/foundation/collections.dart] ::_movingInsertionSort
    // 0xb37c28: r0 = Null
    //     0xb37c28: mov             x0, NULL
    // 0xb37c2c: LeaveFrame
    //     0xb37c2c: mov             SP, fp
    //     0xb37c30: ldp             fp, lr, [SP], #0x10
    // 0xb37c34: ret
    //     0xb37c34: ret             
    // 0xb37c38: ldr             x4, [fp, #0x10]
    // 0xb37c3c: asr             x5, x3, #1
    // 0xb37c40: add             x3, x1, x5
    // 0xb37c44: stur            x3, [fp, #-0x20]
    // 0xb37c48: sub             x5, x3, x1
    // 0xb37c4c: stur            x5, [fp, #-0x18]
    // 0xb37c50: sub             x6, x0, x3
    // 0xb37c54: stur            x6, [fp, #-0x10]
    // 0xb37c58: add             x7, x4, x5
    // 0xb37c5c: stur            x7, [fp, #-8]
    // 0xb37c60: ldr             x16, [fp, #0x38]
    // 0xb37c64: stp             x16, x2, [SP, #0x28]
    // 0xb37c68: ldr             x16, [fp, #0x30]
    // 0xb37c6c: stp             x3, x16, [SP, #0x18]
    // 0xb37c70: ldr             x16, [fp, #0x18]
    // 0xb37c74: stp             x16, x0, [SP, #8]
    // 0xb37c78: str             x7, [SP]
    // 0xb37c7c: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xb37c7c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe198] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xb37c80: ldr             x4, [x4, #0x198]
    // 0xb37c84: r0 = _mergeSort()
    //     0xb37c84: bl              #0xb37bac  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xb37c88: ldur            x16, [fp, #-0x28]
    // 0xb37c8c: ldr             lr, [fp, #0x38]
    // 0xb37c90: stp             lr, x16, [SP, #0x28]
    // 0xb37c94: ldr             x16, [fp, #0x30]
    // 0xb37c98: str             x16, [SP, #0x20]
    // 0xb37c9c: ldr             x0, [fp, #0x28]
    // 0xb37ca0: str             x0, [SP, #0x18]
    // 0xb37ca4: ldur            x0, [fp, #-0x20]
    // 0xb37ca8: ldr             x16, [fp, #0x38]
    // 0xb37cac: stp             x16, x0, [SP, #8]
    // 0xb37cb0: str             x0, [SP]
    // 0xb37cb4: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xb37cb4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe198] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xb37cb8: ldr             x4, [x4, #0x198]
    // 0xb37cbc: r0 = _mergeSort()
    //     0xb37cbc: bl              #0xb37bac  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xb37cc0: ldur            x0, [fp, #-0x20]
    // 0xb37cc4: ldur            x1, [fp, #-0x18]
    // 0xb37cc8: add             x2, x0, x1
    // 0xb37ccc: ldur            x1, [fp, #-0x10]
    // 0xb37cd0: ldur            x3, [fp, #-8]
    // 0xb37cd4: add             x4, x3, x1
    // 0xb37cd8: ldur            x16, [fp, #-0x28]
    // 0xb37cdc: ldr             lr, [fp, #0x30]
    // 0xb37ce0: stp             lr, x16, [SP, #0x40]
    // 0xb37ce4: ldr             x16, [fp, #0x38]
    // 0xb37ce8: stp             x0, x16, [SP, #0x30]
    // 0xb37cec: ldr             x16, [fp, #0x18]
    // 0xb37cf0: stp             x16, x2, [SP, #0x20]
    // 0xb37cf4: stp             x4, x3, [SP, #0x10]
    // 0xb37cf8: ldr             x16, [fp, #0x18]
    // 0xb37cfc: str             x16, [SP, #8]
    // 0xb37d00: ldr             x0, [fp, #0x10]
    // 0xb37d04: str             x0, [SP]
    // 0xb37d08: r4 = const [0x1, 0x9, 0x9, 0x9, null]
    //     0xb37d08: add             x4, PP, #0xe, lsl #12  ; [pp+0xe1a0] List(5) [0x1, 0x9, 0x9, 0x9, Null]
    //     0xb37d0c: ldr             x4, [x4, #0x1a0]
    // 0xb37d10: r0 = _merge()
    //     0xb37d10: bl              #0xb37768  ; [package:flutter/src/foundation/collections.dart] ::_merge
    // 0xb37d14: r0 = Null
    //     0xb37d14: mov             x0, NULL
    // 0xb37d18: LeaveFrame
    //     0xb37d18: mov             SP, fp
    //     0xb37d1c: ldp             fp, lr, [SP], #0x10
    // 0xb37d20: ret
    //     0xb37d20: ret             
    // 0xb37d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37d24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37d28: b               #0xb37bf0
  }
  static _ _movingInsertionSort(/* No info */) {
    // ** addr: 0xb37d2c, size: 0x2d8
    // 0xb37d2c: EnterFrame
    //     0xb37d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb37d30: mov             fp, SP
    // 0xb37d34: AllocStack(0x58)
    //     0xb37d34: sub             SP, SP, #0x58
    // 0xb37d38: CheckStackOverflow
    //     0xb37d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37d3c: cmp             SP, x16
    //     0xb37d40: b.ls            #0xb37fe8
    // 0xb37d44: ldr             x2, [fp, #0x28]
    // 0xb37d48: ldr             x0, [fp, #0x20]
    // 0xb37d4c: sub             x3, x0, x2
    // 0xb37d50: stur            x3, [fp, #-8]
    // 0xb37d54: cbnz            x3, #0xb37d68
    // 0xb37d58: r0 = Null
    //     0xb37d58: mov             x0, NULL
    // 0xb37d5c: LeaveFrame
    //     0xb37d5c: mov             SP, fp
    //     0xb37d60: ldp             fp, lr, [SP], #0x10
    // 0xb37d64: ret
    //     0xb37d64: ret             
    // 0xb37d68: ldr             x6, [fp, #0x38]
    // 0xb37d6c: ldr             x5, [fp, #0x18]
    // 0xb37d70: ldr             x4, [fp, #0x10]
    // 0xb37d74: r0 = BoxInt64Instr(r2)
    //     0xb37d74: sbfiz           x0, x2, #1, #0x1f
    //     0xb37d78: cmp             x2, x0, asr #1
    //     0xb37d7c: b.eq            #0xb37d88
    //     0xb37d80: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37d84: stur            x2, [x0, #7]
    // 0xb37d88: r1 = LoadClassIdInstr(r6)
    //     0xb37d88: ldur            x1, [x6, #-1]
    //     0xb37d8c: ubfx            x1, x1, #0xc, #0x14
    // 0xb37d90: stp             x0, x6, [SP]
    // 0xb37d94: mov             x0, x1
    // 0xb37d98: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb37d98: sub             lr, x0, #0xdfd
    //     0xb37d9c: ldr             lr, [x21, lr, lsl #3]
    //     0xb37da0: blr             lr
    // 0xb37da4: mov             x3, x0
    // 0xb37da8: ldr             x2, [fp, #0x10]
    // 0xb37dac: r0 = BoxInt64Instr(r2)
    //     0xb37dac: sbfiz           x0, x2, #1, #0x1f
    //     0xb37db0: cmp             x2, x0, asr #1
    //     0xb37db4: b.eq            #0xb37dc0
    //     0xb37db8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37dbc: stur            x2, [x0, #7]
    // 0xb37dc0: ldr             x5, [fp, #0x18]
    // 0xb37dc4: r1 = LoadClassIdInstr(r5)
    //     0xb37dc4: ldur            x1, [x5, #-1]
    //     0xb37dc8: ubfx            x1, x1, #0xc, #0x14
    // 0xb37dcc: stp             x0, x5, [SP, #8]
    // 0xb37dd0: str             x3, [SP]
    // 0xb37dd4: mov             x0, x1
    // 0xb37dd8: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb37dd8: mov             x17, #0x8dc8
    //     0xb37ddc: movk            x17, #1, lsl #16
    //     0xb37de0: add             lr, x0, x17
    //     0xb37de4: ldr             lr, [x21, lr, lsl #3]
    //     0xb37de8: blr             lr
    // 0xb37dec: r7 = 1
    //     0xb37dec: mov             x7, #1
    // 0xb37df0: ldr             x6, [fp, #0x38]
    // 0xb37df4: ldr             x3, [fp, #0x28]
    // 0xb37df8: ldr             x5, [fp, #0x18]
    // 0xb37dfc: ldr             x2, [fp, #0x10]
    // 0xb37e00: ldur            x4, [fp, #-8]
    // 0xb37e04: stur            x7, [fp, #-0x10]
    // 0xb37e08: CheckStackOverflow
    //     0xb37e08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37e0c: cmp             SP, x16
    //     0xb37e10: b.ls            #0xb37ff0
    // 0xb37e14: cmp             x7, x4
    // 0xb37e18: b.ge            #0xb37fd8
    // 0xb37e1c: add             x8, x3, x7
    // 0xb37e20: r0 = BoxInt64Instr(r8)
    //     0xb37e20: sbfiz           x0, x8, #1, #0x1f
    //     0xb37e24: cmp             x8, x0, asr #1
    //     0xb37e28: b.eq            #0xb37e34
    //     0xb37e2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37e30: stur            x8, [x0, #7]
    // 0xb37e34: r1 = LoadClassIdInstr(r6)
    //     0xb37e34: ldur            x1, [x6, #-1]
    //     0xb37e38: ubfx            x1, x1, #0xc, #0x14
    // 0xb37e3c: stp             x0, x6, [SP]
    // 0xb37e40: mov             x0, x1
    // 0xb37e44: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb37e44: sub             lr, x0, #0xdfd
    //     0xb37e48: ldr             lr, [x21, lr, lsl #3]
    //     0xb37e4c: blr             lr
    // 0xb37e50: mov             x4, x0
    // 0xb37e54: ldr             x2, [fp, #0x10]
    // 0xb37e58: ldur            x3, [fp, #-0x10]
    // 0xb37e5c: stur            x4, [fp, #-0x38]
    // 0xb37e60: add             x5, x2, x3
    // 0xb37e64: stur            x5, [fp, #-0x30]
    // 0xb37e68: mov             x8, x2
    // 0xb37e6c: mov             x7, x5
    // 0xb37e70: ldr             x6, [fp, #0x18]
    // 0xb37e74: stur            x8, [fp, #-0x20]
    // 0xb37e78: stur            x7, [fp, #-0x28]
    // 0xb37e7c: CheckStackOverflow
    //     0xb37e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb37e80: cmp             SP, x16
    //     0xb37e84: b.ls            #0xb37ff8
    // 0xb37e88: cmp             x8, x7
    // 0xb37e8c: b.ge            #0xb37f38
    // 0xb37e90: sub             x0, x7, x8
    // 0xb37e94: asr             x1, x0, #1
    // 0xb37e98: add             x9, x8, x1
    // 0xb37e9c: stur            x9, [fp, #-0x18]
    // 0xb37ea0: r0 = BoxInt64Instr(r9)
    //     0xb37ea0: sbfiz           x0, x9, #1, #0x1f
    //     0xb37ea4: cmp             x9, x0, asr #1
    //     0xb37ea8: b.eq            #0xb37eb4
    //     0xb37eac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37eb0: stur            x9, [x0, #7]
    // 0xb37eb4: r1 = LoadClassIdInstr(r6)
    //     0xb37eb4: ldur            x1, [x6, #-1]
    //     0xb37eb8: ubfx            x1, x1, #0xc, #0x14
    // 0xb37ebc: stp             x0, x6, [SP]
    // 0xb37ec0: mov             x0, x1
    // 0xb37ec4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb37ec4: sub             lr, x0, #0xdfd
    //     0xb37ec8: ldr             lr, [x21, lr, lsl #3]
    //     0xb37ecc: blr             lr
    // 0xb37ed0: ldr             x16, [fp, #0x30]
    // 0xb37ed4: ldur            lr, [fp, #-0x38]
    // 0xb37ed8: stp             lr, x16, [SP, #8]
    // 0xb37edc: str             x0, [SP]
    // 0xb37ee0: ldr             x0, [fp, #0x30]
    // 0xb37ee4: ClosureCall
    //     0xb37ee4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb37ee8: ldur            x2, [x0, #0x1f]
    //     0xb37eec: blr             x2
    // 0xb37ef0: cmp             w0, NULL
    // 0xb37ef4: b.eq            #0xb38000
    // 0xb37ef8: r1 = LoadInt32Instr(r0)
    //     0xb37ef8: sbfx            x1, x0, #1, #0x1f
    //     0xb37efc: tbz             w0, #0, #0xb37f04
    //     0xb37f00: ldur            x1, [x0, #7]
    // 0xb37f04: tbz             x1, #0x3f, #0xb37f14
    // 0xb37f08: ldur            x8, [fp, #-0x20]
    // 0xb37f0c: ldur            x7, [fp, #-0x18]
    // 0xb37f10: b               #0xb37f24
    // 0xb37f14: ldur            x0, [fp, #-0x18]
    // 0xb37f18: add             x1, x0, #1
    // 0xb37f1c: mov             x8, x1
    // 0xb37f20: ldur            x7, [fp, #-0x28]
    // 0xb37f24: ldr             x2, [fp, #0x10]
    // 0xb37f28: ldur            x3, [fp, #-0x10]
    // 0xb37f2c: ldur            x4, [fp, #-0x38]
    // 0xb37f30: ldur            x5, [fp, #-0x30]
    // 0xb37f34: b               #0xb37e70
    // 0xb37f38: mov             x4, x3
    // 0xb37f3c: mov             x0, x5
    // 0xb37f40: mov             x2, x8
    // 0xb37f44: add             x3, x2, #1
    // 0xb37f48: add             x5, x0, #1
    // 0xb37f4c: r0 = BoxInt64Instr(r2)
    //     0xb37f4c: sbfiz           x0, x2, #1, #0x1f
    //     0xb37f50: cmp             x2, x0, asr #1
    //     0xb37f54: b.eq            #0xb37f60
    //     0xb37f58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb37f5c: stur            x2, [x0, #7]
    // 0xb37f60: mov             x7, x0
    // 0xb37f64: stur            x7, [fp, #-0x40]
    // 0xb37f68: r0 = LoadClassIdInstr(r6)
    //     0xb37f68: ldur            x0, [x6, #-1]
    //     0xb37f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xb37f70: str             x7, [SP]
    // 0xb37f74: mov             x1, x6
    // 0xb37f78: mov             x2, x3
    // 0xb37f7c: mov             x3, x5
    // 0xb37f80: mov             x5, x6
    // 0xb37f84: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xb37f84: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xb37f88: r0 = GDT[cid_x0 + 0x18893]()
    //     0xb37f88: mov             x17, #0x8893
    //     0xb37f8c: movk            x17, #1, lsl #16
    //     0xb37f90: add             lr, x0, x17
    //     0xb37f94: ldr             lr, [x21, lr, lsl #3]
    //     0xb37f98: blr             lr
    // 0xb37f9c: ldr             x1, [fp, #0x18]
    // 0xb37fa0: r0 = LoadClassIdInstr(r1)
    //     0xb37fa0: ldur            x0, [x1, #-1]
    //     0xb37fa4: ubfx            x0, x0, #0xc, #0x14
    // 0xb37fa8: ldur            x16, [fp, #-0x40]
    // 0xb37fac: stp             x16, x1, [SP, #8]
    // 0xb37fb0: ldur            x16, [fp, #-0x38]
    // 0xb37fb4: str             x16, [SP]
    // 0xb37fb8: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb37fb8: mov             x17, #0x8dc8
    //     0xb37fbc: movk            x17, #1, lsl #16
    //     0xb37fc0: add             lr, x0, x17
    //     0xb37fc4: ldr             lr, [x21, lr, lsl #3]
    //     0xb37fc8: blr             lr
    // 0xb37fcc: ldur            x1, [fp, #-0x10]
    // 0xb37fd0: add             x7, x1, #1
    // 0xb37fd4: b               #0xb37df0
    // 0xb37fd8: r0 = Null
    //     0xb37fd8: mov             x0, NULL
    // 0xb37fdc: LeaveFrame
    //     0xb37fdc: mov             SP, fp
    //     0xb37fe0: ldp             fp, lr, [SP], #0x10
    // 0xb37fe4: ret
    //     0xb37fe4: ret             
    // 0xb37fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37fe8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37fec: b               #0xb37d44
    // 0xb37ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37ff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37ff4: b               #0xb37e14
    // 0xb37ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37ff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37ffc: b               #0xb37e88
    // 0xb38000: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb38000: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _insertionSort(/* No info */) {
    // ** addr: 0xb38004, size: 0x204
    // 0xb38004: EnterFrame
    //     0xb38004: stp             fp, lr, [SP, #-0x10]!
    //     0xb38008: mov             fp, SP
    // 0xb3800c: AllocStack(0x48)
    //     0xb3800c: sub             SP, SP, #0x48
    // 0xb38010: CheckStackOverflow
    //     0xb38010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb38014: cmp             SP, x16
    //     0xb38018: b.ls            #0xb381ec
    // 0xb3801c: r3 = 1
    //     0xb3801c: mov             x3, #1
    // 0xb38020: ldr             x5, [fp, #0x20]
    // 0xb38024: ldr             x2, [fp, #0x10]
    // 0xb38028: stur            x3, [fp, #-8]
    // 0xb3802c: CheckStackOverflow
    //     0xb3802c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb38030: cmp             SP, x16
    //     0xb38034: b.ls            #0xb381f4
    // 0xb38038: cmp             x3, x2
    // 0xb3803c: b.ge            #0xb381dc
    // 0xb38040: r0 = BoxInt64Instr(r3)
    //     0xb38040: sbfiz           x0, x3, #1, #0x1f
    //     0xb38044: cmp             x3, x0, asr #1
    //     0xb38048: b.eq            #0xb38054
    //     0xb3804c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb38050: stur            x3, [x0, #7]
    // 0xb38054: r1 = LoadClassIdInstr(r5)
    //     0xb38054: ldur            x1, [x5, #-1]
    //     0xb38058: ubfx            x1, x1, #0xc, #0x14
    // 0xb3805c: stp             x0, x5, [SP]
    // 0xb38060: mov             x0, x1
    // 0xb38064: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb38064: sub             lr, x0, #0xdfd
    //     0xb38068: ldr             lr, [x21, lr, lsl #3]
    //     0xb3806c: blr             lr
    // 0xb38070: mov             x2, x0
    // 0xb38074: stur            x2, [fp, #-0x28]
    // 0xb38078: ldur            x3, [fp, #-8]
    // 0xb3807c: r4 = 0
    //     0xb3807c: mov             x4, #0
    // 0xb38080: ldr             x5, [fp, #0x20]
    // 0xb38084: stur            x4, [fp, #-0x18]
    // 0xb38088: stur            x3, [fp, #-0x20]
    // 0xb3808c: CheckStackOverflow
    //     0xb3808c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb38090: cmp             SP, x16
    //     0xb38094: b.ls            #0xb381fc
    // 0xb38098: cmp             x4, x3
    // 0xb3809c: b.ge            #0xb3813c
    // 0xb380a0: sub             x0, x3, x4
    // 0xb380a4: asr             x1, x0, #1
    // 0xb380a8: add             x6, x4, x1
    // 0xb380ac: stur            x6, [fp, #-0x10]
    // 0xb380b0: r0 = BoxInt64Instr(r6)
    //     0xb380b0: sbfiz           x0, x6, #1, #0x1f
    //     0xb380b4: cmp             x6, x0, asr #1
    //     0xb380b8: b.eq            #0xb380c4
    //     0xb380bc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb380c0: stur            x6, [x0, #7]
    // 0xb380c4: r1 = LoadClassIdInstr(r5)
    //     0xb380c4: ldur            x1, [x5, #-1]
    //     0xb380c8: ubfx            x1, x1, #0xc, #0x14
    // 0xb380cc: stp             x0, x5, [SP]
    // 0xb380d0: mov             x0, x1
    // 0xb380d4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb380d4: sub             lr, x0, #0xdfd
    //     0xb380d8: ldr             lr, [x21, lr, lsl #3]
    //     0xb380dc: blr             lr
    // 0xb380e0: ldr             x16, [fp, #0x18]
    // 0xb380e4: ldur            lr, [fp, #-0x28]
    // 0xb380e8: stp             lr, x16, [SP, #8]
    // 0xb380ec: str             x0, [SP]
    // 0xb380f0: ldr             x0, [fp, #0x18]
    // 0xb380f4: ClosureCall
    //     0xb380f4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb380f8: ldur            x2, [x0, #0x1f]
    //     0xb380fc: blr             x2
    // 0xb38100: cmp             w0, NULL
    // 0xb38104: b.eq            #0xb38204
    // 0xb38108: r1 = LoadInt32Instr(r0)
    //     0xb38108: sbfx            x1, x0, #1, #0x1f
    //     0xb3810c: tbz             w0, #0, #0xb38114
    //     0xb38110: ldur            x1, [x0, #7]
    // 0xb38114: tbz             x1, #0x3f, #0xb38124
    // 0xb38118: ldur            x4, [fp, #-0x18]
    // 0xb3811c: ldur            x3, [fp, #-0x10]
    // 0xb38120: b               #0xb38134
    // 0xb38124: ldur            x0, [fp, #-0x10]
    // 0xb38128: add             x1, x0, #1
    // 0xb3812c: mov             x4, x1
    // 0xb38130: ldur            x3, [fp, #-0x20]
    // 0xb38134: ldur            x2, [fp, #-0x28]
    // 0xb38138: b               #0xb38080
    // 0xb3813c: mov             x2, x4
    // 0xb38140: mov             x4, x5
    // 0xb38144: ldur            x0, [fp, #-8]
    // 0xb38148: add             x3, x2, #1
    // 0xb3814c: add             x6, x0, #1
    // 0xb38150: stur            x6, [fp, #-0x10]
    // 0xb38154: r0 = BoxInt64Instr(r2)
    //     0xb38154: sbfiz           x0, x2, #1, #0x1f
    //     0xb38158: cmp             x2, x0, asr #1
    //     0xb3815c: b.eq            #0xb38168
    //     0xb38160: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb38164: stur            x2, [x0, #7]
    // 0xb38168: mov             x7, x0
    // 0xb3816c: stur            x7, [fp, #-0x30]
    // 0xb38170: r0 = LoadClassIdInstr(r4)
    //     0xb38170: ldur            x0, [x4, #-1]
    //     0xb38174: ubfx            x0, x0, #0xc, #0x14
    // 0xb38178: str             x7, [SP]
    // 0xb3817c: mov             x1, x4
    // 0xb38180: mov             x2, x3
    // 0xb38184: mov             x3, x6
    // 0xb38188: mov             x5, x4
    // 0xb3818c: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xb3818c: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xb38190: r0 = GDT[cid_x0 + 0x18893]()
    //     0xb38190: mov             x17, #0x8893
    //     0xb38194: movk            x17, #1, lsl #16
    //     0xb38198: add             lr, x0, x17
    //     0xb3819c: ldr             lr, [x21, lr, lsl #3]
    //     0xb381a0: blr             lr
    // 0xb381a4: ldr             x1, [fp, #0x20]
    // 0xb381a8: r0 = LoadClassIdInstr(r1)
    //     0xb381a8: ldur            x0, [x1, #-1]
    //     0xb381ac: ubfx            x0, x0, #0xc, #0x14
    // 0xb381b0: ldur            x16, [fp, #-0x30]
    // 0xb381b4: stp             x16, x1, [SP, #8]
    // 0xb381b8: ldur            x16, [fp, #-0x28]
    // 0xb381bc: str             x16, [SP]
    // 0xb381c0: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb381c0: mov             x17, #0x8dc8
    //     0xb381c4: movk            x17, #1, lsl #16
    //     0xb381c8: add             lr, x0, x17
    //     0xb381cc: ldr             lr, [x21, lr, lsl #3]
    //     0xb381d0: blr             lr
    // 0xb381d4: ldur            x3, [fp, #-0x10]
    // 0xb381d8: b               #0xb38020
    // 0xb381dc: r0 = Null
    //     0xb381dc: mov             x0, NULL
    // 0xb381e0: LeaveFrame
    //     0xb381e0: mov             SP, fp
    //     0xb381e4: ldp             fp, lr, [SP], #0x10
    // 0xb381e8: ret
    //     0xb381e8: ret             
    // 0xb381ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb381ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb381f0: b               #0xb3801c
    // 0xb381f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb381f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb381f8: b               #0xb38038
    // 0xb381fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb381fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb38200: b               #0xb38098
    // 0xb38204: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb38204: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ mapEquals(/* No info */) {
    // ** addr: 0xc015b8, size: 0x25c
    // 0xc015b8: EnterFrame
    //     0xc015b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc015bc: mov             fp, SP
    // 0xc015c0: AllocStack(0x28)
    //     0xc015c0: sub             SP, SP, #0x28
    // 0xc015c4: CheckStackOverflow
    //     0xc015c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc015c8: cmp             SP, x16
    //     0xc015cc: b.ls            #0xc01804
    // 0xc015d0: ldr             x1, [fp, #0x18]
    // 0xc015d4: cmp             w1, NULL
    // 0xc015d8: b.ne            #0xc015ec
    // 0xc015dc: r0 = true
    //     0xc015dc: add             x0, NULL, #0x20  ; true
    // 0xc015e0: LeaveFrame
    //     0xc015e0: mov             SP, fp
    //     0xc015e4: ldp             fp, lr, [SP], #0x10
    // 0xc015e8: ret
    //     0xc015e8: ret             
    // 0xc015ec: ldr             x2, [fp, #0x10]
    // 0xc015f0: r0 = LoadClassIdInstr(r1)
    //     0xc015f0: ldur            x0, [x1, #-1]
    //     0xc015f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc015f8: str             x1, [SP]
    // 0xc015fc: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc015fc: mov             x17, #0xf078
    //     0xc01600: add             lr, x0, x17
    //     0xc01604: ldr             lr, [x21, lr, lsl #3]
    //     0xc01608: blr             lr
    // 0xc0160c: mov             x2, x0
    // 0xc01610: ldr             x1, [fp, #0x10]
    // 0xc01614: stur            x2, [fp, #-8]
    // 0xc01618: r0 = LoadClassIdInstr(r1)
    //     0xc01618: ldur            x0, [x1, #-1]
    //     0xc0161c: ubfx            x0, x0, #0xc, #0x14
    // 0xc01620: str             x1, [SP]
    // 0xc01624: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc01624: mov             x17, #0xf078
    //     0xc01628: add             lr, x0, x17
    //     0xc0162c: ldr             lr, [x21, lr, lsl #3]
    //     0xc01630: blr             lr
    // 0xc01634: mov             x1, x0
    // 0xc01638: ldur            x0, [fp, #-8]
    // 0xc0163c: r2 = LoadInt32Instr(r0)
    //     0xc0163c: sbfx            x2, x0, #1, #0x1f
    //     0xc01640: tbz             w0, #0, #0xc01648
    //     0xc01644: ldur            x2, [x0, #7]
    // 0xc01648: r0 = LoadInt32Instr(r1)
    //     0xc01648: sbfx            x0, x1, #1, #0x1f
    //     0xc0164c: tbz             w1, #0, #0xc01654
    //     0xc01650: ldur            x0, [x1, #7]
    // 0xc01654: cmp             x2, x0
    // 0xc01658: b.eq            #0xc0166c
    // 0xc0165c: r0 = false
    //     0xc0165c: add             x0, NULL, #0x30  ; false
    // 0xc01660: LeaveFrame
    //     0xc01660: mov             SP, fp
    //     0xc01664: ldp             fp, lr, [SP], #0x10
    // 0xc01668: ret
    //     0xc01668: ret             
    // 0xc0166c: ldr             x3, [fp, #0x18]
    // 0xc01670: ldr             x2, [fp, #0x10]
    // 0xc01674: cmp             w3, w2
    // 0xc01678: b.ne            #0xc0168c
    // 0xc0167c: r0 = true
    //     0xc0167c: add             x0, NULL, #0x20  ; true
    // 0xc01680: LeaveFrame
    //     0xc01680: mov             SP, fp
    //     0xc01684: ldp             fp, lr, [SP], #0x10
    // 0xc01688: ret
    //     0xc01688: ret             
    // 0xc0168c: r0 = LoadClassIdInstr(r3)
    //     0xc0168c: ldur            x0, [x3, #-1]
    //     0xc01690: ubfx            x0, x0, #0xc, #0x14
    // 0xc01694: mov             x1, x3
    // 0xc01698: r0 = GDT[cid_x0 + 0x44d]()
    //     0xc01698: add             lr, x0, #0x44d
    //     0xc0169c: ldr             lr, [x21, lr, lsl #3]
    //     0xc016a0: blr             lr
    // 0xc016a4: r1 = LoadClassIdInstr(r0)
    //     0xc016a4: ldur            x1, [x0, #-1]
    //     0xc016a8: ubfx            x1, x1, #0xc, #0x14
    // 0xc016ac: mov             x16, x0
    // 0xc016b0: mov             x0, x1
    // 0xc016b4: mov             x1, x16
    // 0xc016b8: r0 = GDT[cid_x0 + 0x12641]()
    //     0xc016b8: mov             x17, #0x2641
    //     0xc016bc: movk            x17, #1, lsl #16
    //     0xc016c0: add             lr, x0, x17
    //     0xc016c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc016c8: blr             lr
    // 0xc016cc: mov             x2, x0
    // 0xc016d0: stur            x2, [fp, #-8]
    // 0xc016d4: ldr             x4, [fp, #0x18]
    // 0xc016d8: ldr             x3, [fp, #0x10]
    // 0xc016dc: CheckStackOverflow
    //     0xc016dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc016e0: cmp             SP, x16
    //     0xc016e4: b.ls            #0xc0180c
    // 0xc016e8: r0 = LoadClassIdInstr(r2)
    //     0xc016e8: ldur            x0, [x2, #-1]
    //     0xc016ec: ubfx            x0, x0, #0xc, #0x14
    // 0xc016f0: mov             x1, x2
    // 0xc016f4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc016f4: mov             x17, #0x845b
    //     0xc016f8: movk            x17, #1, lsl #16
    //     0xc016fc: add             lr, x0, x17
    //     0xc01700: ldr             lr, [x21, lr, lsl #3]
    //     0xc01704: blr             lr
    // 0xc01708: tbnz            w0, #4, #0xc017f4
    // 0xc0170c: ldr             x3, [fp, #0x10]
    // 0xc01710: ldur            x2, [fp, #-8]
    // 0xc01714: r0 = LoadClassIdInstr(r2)
    //     0xc01714: ldur            x0, [x2, #-1]
    //     0xc01718: ubfx            x0, x0, #0xc, #0x14
    // 0xc0171c: mov             x1, x2
    // 0xc01720: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc01720: mov             x17, #0x7d4c
    //     0xc01724: movk            x17, #1, lsl #16
    //     0xc01728: add             lr, x0, x17
    //     0xc0172c: ldr             lr, [x21, lr, lsl #3]
    //     0xc01730: blr             lr
    // 0xc01734: mov             x4, x0
    // 0xc01738: ldr             x3, [fp, #0x10]
    // 0xc0173c: stur            x4, [fp, #-0x10]
    // 0xc01740: r0 = LoadClassIdInstr(r3)
    //     0xc01740: ldur            x0, [x3, #-1]
    //     0xc01744: ubfx            x0, x0, #0xc, #0x14
    // 0xc01748: mov             x1, x3
    // 0xc0174c: mov             x2, x4
    // 0xc01750: r0 = GDT[cid_x0 + -0x104]()
    //     0xc01750: sub             lr, x0, #0x104
    //     0xc01754: ldr             lr, [x21, lr, lsl #3]
    //     0xc01758: blr             lr
    // 0xc0175c: tbnz            w0, #4, #0xc017e4
    // 0xc01760: ldr             x4, [fp, #0x18]
    // 0xc01764: ldr             x3, [fp, #0x10]
    // 0xc01768: r0 = LoadClassIdInstr(r3)
    //     0xc01768: ldur            x0, [x3, #-1]
    //     0xc0176c: ubfx            x0, x0, #0xc, #0x14
    // 0xc01770: mov             x1, x3
    // 0xc01774: ldur            x2, [fp, #-0x10]
    // 0xc01778: r0 = GDT[cid_x0 + -0xd48]()
    //     0xc01778: sub             lr, x0, #0xd48
    //     0xc0177c: ldr             lr, [x21, lr, lsl #3]
    //     0xc01780: blr             lr
    // 0xc01784: mov             x4, x0
    // 0xc01788: ldr             x3, [fp, #0x18]
    // 0xc0178c: stur            x4, [fp, #-0x18]
    // 0xc01790: r0 = LoadClassIdInstr(r3)
    //     0xc01790: ldur            x0, [x3, #-1]
    //     0xc01794: ubfx            x0, x0, #0xc, #0x14
    // 0xc01798: mov             x1, x3
    // 0xc0179c: ldur            x2, [fp, #-0x10]
    // 0xc017a0: r0 = GDT[cid_x0 + -0xd48]()
    //     0xc017a0: sub             lr, x0, #0xd48
    //     0xc017a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc017a8: blr             lr
    // 0xc017ac: mov             x1, x0
    // 0xc017b0: ldur            x0, [fp, #-0x18]
    // 0xc017b4: r2 = 60
    //     0xc017b4: mov             x2, #0x3c
    // 0xc017b8: branchIfSmi(r0, 0xc017c4)
    //     0xc017b8: tbz             w0, #0, #0xc017c4
    // 0xc017bc: r2 = LoadClassIdInstr(r0)
    //     0xc017bc: ldur            x2, [x0, #-1]
    //     0xc017c0: ubfx            x2, x2, #0xc, #0x14
    // 0xc017c4: stp             x1, x0, [SP]
    // 0xc017c8: mov             x0, x2
    // 0xc017cc: mov             lr, x0
    // 0xc017d0: ldr             lr, [x21, lr, lsl #3]
    // 0xc017d4: blr             lr
    // 0xc017d8: tbnz            w0, #4, #0xc017e4
    // 0xc017dc: ldur            x2, [fp, #-8]
    // 0xc017e0: b               #0xc016d4
    // 0xc017e4: r0 = false
    //     0xc017e4: add             x0, NULL, #0x30  ; false
    // 0xc017e8: LeaveFrame
    //     0xc017e8: mov             SP, fp
    //     0xc017ec: ldp             fp, lr, [SP], #0x10
    // 0xc017f0: ret
    //     0xc017f0: ret             
    // 0xc017f4: r0 = true
    //     0xc017f4: add             x0, NULL, #0x20  ; true
    // 0xc017f8: LeaveFrame
    //     0xc017f8: mov             SP, fp
    //     0xc017fc: ldp             fp, lr, [SP], #0x10
    // 0xc01800: ret
    //     0xc01800: ret             
    // 0xc01804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc01804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc01808: b               #0xc015d0
    // 0xc0180c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0180c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc01810: b               #0xc016e8
  }
}
