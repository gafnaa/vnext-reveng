// lib: , url: package:flutter/src/foundation/assertions.dart

// class id: 1048796, size: 0x8
class :: {

  static _ debugPrintStack(/* No info */) {
    // ** addr: 0x82c388, size: 0xec
    // 0x82c388: EnterFrame
    //     0x82c388: stp             fp, lr, [SP, #-0x10]!
    //     0x82c38c: mov             fp, SP
    // 0x82c390: AllocStack(0x10)
    //     0x82c390: sub             SP, SP, #0x10
    // 0x82c394: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x82c394: stur            x2, [fp, #-8]
    // 0x82c398: CheckStackOverflow
    //     0x82c398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c39c: cmp             SP, x16
    //     0x82c3a0: b.ls            #0x82c46c
    // 0x82c3a4: r0 = dump()
    //     0x82c3a4: bl              #0x829f00  ; [package:flutter/src/foundation/_error_dumper_io.dart] ErrorToConsoleDumper::dump
    // 0x82c3a8: ldur            x0, [fp, #-8]
    // 0x82c3ac: cmp             w0, NULL
    // 0x82c3b0: b.ne            #0x82c3bc
    // 0x82c3b4: r0 = current()
    //     0x82c3b4: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x82c3b8: b               #0x82c3dc
    // 0x82c3bc: r0 = LoadStaticField(0x470)
    //     0x82c3bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82c3c0: ldr             x0, [x0, #0x8e0]
    // 0x82c3c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82c3c8: cmp             w0, w16
    // 0x82c3cc: b.ne            #0x82c3d8
    // 0x82c3d0: r2 = demangleStackTrace
    //     0x82c3d0: ldr             x2, [PP, #0xcf8]  ; [pp+0xcf8] Field <FlutterError.demangleStackTrace>: static late (offset: 0x470)
    // 0x82c3d4: r0 = InitLateStaticField()
    //     0x82c3d4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x82c3d8: ldur            x0, [fp, #-8]
    // 0x82c3dc: r1 = LoadClassIdInstr(r0)
    //     0x82c3dc: ldur            x1, [x0, #-1]
    //     0x82c3e0: ubfx            x1, x1, #0xc, #0x14
    // 0x82c3e4: str             x0, [SP]
    // 0x82c3e8: mov             x0, x1
    // 0x82c3ec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82c3ec: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82c3f0: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x82c3f0: mov             x17, #0x91c1
    //     0x82c3f4: add             lr, x0, x17
    //     0x82c3f8: ldr             lr, [x21, lr, lsl #3]
    //     0x82c3fc: blr             lr
    // 0x82c400: mov             x1, x0
    // 0x82c404: r0 = trimRight()
    //     0x82c404: bl              #0x82c1d8  ; [dart:core] _StringBase::trimRight
    // 0x82c408: r1 = LoadClassIdInstr(r0)
    //     0x82c408: ldur            x1, [x0, #-1]
    //     0x82c40c: ubfx            x1, x1, #0xc, #0x14
    // 0x82c410: mov             x16, x0
    // 0x82c414: mov             x0, x1
    // 0x82c418: mov             x1, x16
    // 0x82c41c: r2 = "\n"
    //     0x82c41c: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82c420: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82c420: sub             lr, x0, #0xffe
    //     0x82c424: ldr             lr, [x21, lr, lsl #3]
    //     0x82c428: blr             lr
    // 0x82c42c: mov             x1, x0
    // 0x82c430: r2 = 100
    //     0x82c430: mov             x2, #0x64
    // 0x82c434: r0 = take()
    //     0x82c434: bl              #0x82e2ec  ; [dart:collection] ListBase::take
    // 0x82c438: mov             x1, x0
    // 0x82c43c: r0 = defaultStackFilter()
    //     0x82c43c: bl              #0x82c474  ; [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter
    // 0x82c440: r16 = "\n"
    //     0x82c440: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82c444: str             x16, [SP]
    // 0x82c448: mov             x1, x0
    // 0x82c44c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x82c44c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x82c450: r0 = join()
    //     0x82c450: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x82c454: mov             x1, x0
    // 0x82c458: r0 = dump()
    //     0x82c458: bl              #0x829f00  ; [package:flutter/src/foundation/_error_dumper_io.dart] ErrorToConsoleDumper::dump
    // 0x82c45c: r0 = Null
    //     0x82c45c: mov             x0, NULL
    // 0x82c460: LeaveFrame
    //     0x82c460: mov             SP, fp
    //     0x82c464: ldp             fp, lr, [SP], #0x10
    // 0x82c468: ret
    //     0x82c468: ret             
    // 0x82c46c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c46c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c470: b               #0x82c3a4
  }
}

// class id: 3236, size: 0x2c, field offset: 0x2c
abstract class _ErrorDiagnostic extends DiagnosticsProperty<dynamic> {

  List<Object> dyn:get:value(_ErrorDiagnostic) {
    // ** addr: 0x829aa8, size: 0x3c
    // 0x829aa8: ldr             x1, [SP]
    // 0x829aac: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x829aac: ldur            w0, [x1, #0x17]
    // 0x829ab0: DecompressPointer r0
    //     0x829ab0: add             x0, x0, HEAP, lsl #32
    // 0x829ab4: cmp             w0, NULL
    // 0x829ab8: b.eq            #0x829ac0
    // 0x829abc: ret
    //     0x829abc: ret             
    // 0x829ac0: EnterFrame
    //     0x829ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x829ac4: mov             fp, SP
    // 0x829ac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x829ac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ErrorDiagnostic(/* No info */) {
    // ** addr: 0x829bec, size: 0xb8
    // 0x829bec: EnterFrame
    //     0x829bec: stp             fp, lr, [SP, #-0x10]!
    //     0x829bf0: mov             fp, SP
    // 0x829bf4: AllocStack(0x20)
    //     0x829bf4: sub             SP, SP, #0x20
    // 0x829bf8: r0 = 2
    //     0x829bf8: mov             x0, #2
    // 0x829bfc: mov             x4, x2
    // 0x829c00: stur            x2, [fp, #-0x10]
    // 0x829c04: mov             x2, x0
    // 0x829c08: mov             x5, x1
    // 0x829c0c: stur            x1, [fp, #-8]
    // 0x829c10: stur            x3, [fp, #-0x18]
    // 0x829c14: r1 = Null
    //     0x829c14: mov             x1, NULL
    // 0x829c18: r0 = AllocateArray()
    //     0x829c18: bl              #0x13df928  ; AllocateArrayStub
    // 0x829c1c: mov             x2, x0
    // 0x829c20: ldur            x0, [fp, #-0x10]
    // 0x829c24: stur            x2, [fp, #-0x20]
    // 0x829c28: StoreField: r2->field_f = r0
    //     0x829c28: stur            w0, [x2, #0xf]
    // 0x829c2c: r1 = <Object>
    //     0x829c2c: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x829c30: r0 = AllocateGrowableArray()
    //     0x829c30: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x829c34: ldur            x1, [fp, #-0x20]
    // 0x829c38: StoreField: r0->field_f = r1
    //     0x829c38: stur            w1, [x0, #0xf]
    // 0x829c3c: r1 = 2
    //     0x829c3c: mov             x1, #2
    // 0x829c40: StoreField: r0->field_b = r1
    //     0x829c40: stur            w1, [x0, #0xb]
    // 0x829c44: ldur            x2, [fp, #-8]
    // 0x829c48: r1 = false
    //     0x829c48: add             x1, NULL, #0x30  ; false
    // 0x829c4c: StoreField: r2->field_13 = r1
    //     0x829c4c: stur            w1, [x2, #0x13]
    // 0x829c50: r1 = true
    //     0x829c50: add             x1, NULL, #0x20  ; true
    // 0x829c54: StoreField: r2->field_1b = r1
    //     0x829c54: stur            w1, [x2, #0x1b]
    // 0x829c58: ArrayStore: r2[0] = r0  ; List_4
    //     0x829c58: stur            w0, [x2, #0x17]
    //     0x829c5c: ldurb           w16, [x2, #-1]
    //     0x829c60: ldurb           w17, [x0, #-1]
    //     0x829c64: and             x16, x17, x16, lsr #2
    //     0x829c68: tst             x16, HEAP, lsr #32
    //     0x829c6c: b.eq            #0x829c74
    //     0x829c70: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x829c74: ldur            x0, [fp, #-0x18]
    // 0x829c78: StoreField: r2->field_27 = r0
    //     0x829c78: stur            w0, [x2, #0x27]
    //     0x829c7c: ldurb           w16, [x2, #-1]
    //     0x829c80: ldurb           w17, [x0, #-1]
    //     0x829c84: and             x16, x17, x16, lsr #2
    //     0x829c88: tst             x16, HEAP, lsr #32
    //     0x829c8c: b.eq            #0x829c94
    //     0x829c90: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x829c94: r0 = Null
    //     0x829c94: mov             x0, NULL
    // 0x829c98: LeaveFrame
    //     0x829c98: mov             SP, fp
    //     0x829c9c: ldp             fp, lr, [SP], #0x10
    // 0x829ca0: ret
    //     0x829ca0: ret             
  }
  _ valueToString(/* No info */) {
    // ** addr: 0x10ffea8, size: 0x38
    // 0x10ffea8: EnterFrame
    //     0x10ffea8: stp             fp, lr, [SP, #-0x10]!
    //     0x10ffeac: mov             fp, SP
    // 0x10ffeb0: CheckStackOverflow
    //     0x10ffeb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ffeb4: cmp             SP, x16
    //     0x10ffeb8: b.ls            #0x10ffed8
    // 0x10ffebc: r0 = value()
    //     0x10ffebc: bl              #0x11d60f4  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::value
    // 0x10ffec0: mov             x1, x0
    // 0x10ffec4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x10ffec4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x10ffec8: r0 = join()
    //     0x10ffec8: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x10ffecc: LeaveFrame
    //     0x10ffecc: mov             SP, fp
    //     0x10ffed0: ldp             fp, lr, [SP], #0x10
    // 0x10ffed4: ret
    //     0x10ffed4: ret             
    // 0x10ffed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ffed8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ffedc: b               #0x10ffebc
  }
  List<Object> value(_ErrorDiagnostic) {
    // ** addr: 0x11d60f4, size: 0x38
    // 0x11d60f4: EnterFrame
    //     0x11d60f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d60f8: mov             fp, SP
    // 0x11d60fc: CheckStackOverflow
    //     0x11d60fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d6100: cmp             SP, x16
    //     0x11d6104: b.ls            #0x11d6120
    // 0x11d6108: r0 = library()
    //     0x11d6108: bl              #0x13aeec8  ; [package:stack_trace/src/unparsed_frame.dart] UnparsedFrame::library
    // 0x11d610c: cmp             w0, NULL
    // 0x11d6110: b.eq            #0x11d6128
    // 0x11d6114: LeaveFrame
    //     0x11d6114: mov             SP, fp
    //     0x11d6118: ldp             fp, lr, [SP], #0x10
    // 0x11d611c: ret
    //     0x11d611c: ret             
    // 0x11d6120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d6120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d6124: b               #0x11d6108
    // 0x11d6128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11d6128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3237, size: 0x2c, field offset: 0x2c
class ErrorHint extends _ErrorDiagnostic {
}

// class id: 3238, size: 0x2c, field offset: 0x2c
class ErrorSummary extends _ErrorDiagnostic {
}

// class id: 3239, size: 0x2c, field offset: 0x2c
class ErrorDescription extends _ErrorDiagnostic {
}

// class id: 3244, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class StackFilter extends Object {
}

// class id: 5232, size: 0x20, field offset: 0x8
//   const constructor, 
class FlutterErrorDetails extends _MixinApplication3&Object&Diagnosticable {

  get _ summary(/* No info */) {
    // ** addr: 0x82bb9c, size: 0x8c
    // 0x82bb9c: EnterFrame
    //     0x82bb9c: stp             fp, lr, [SP, #-0x10]!
    //     0x82bba0: mov             fp, SP
    // 0x82bba4: CheckStackOverflow
    //     0x82bba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bba8: cmp             SP, x16
    //     0x82bbac: b.ls            #0x82bc1c
    // 0x82bbb0: r0 = exceptionAsString()
    //     0x82bbb0: bl              #0x82bc74  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::exceptionAsString
    // 0x82bbb4: r1 = LoadClassIdInstr(r0)
    //     0x82bbb4: ldur            x1, [x0, #-1]
    //     0x82bbb8: ubfx            x1, x1, #0xc, #0x14
    // 0x82bbbc: mov             x16, x0
    // 0x82bbc0: mov             x0, x1
    // 0x82bbc4: mov             x1, x16
    // 0x82bbc8: r2 = "\n"
    //     0x82bbc8: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82bbcc: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82bbcc: sub             lr, x0, #0xffe
    //     0x82bbd0: ldr             lr, [x21, lr, lsl #3]
    //     0x82bbd4: blr             lr
    // 0x82bbd8: mov             x2, x0
    // 0x82bbdc: LoadField: r0 = r2->field_b
    //     0x82bbdc: ldur            w0, [x2, #0xb]
    // 0x82bbe0: r1 = LoadInt32Instr(r0)
    //     0x82bbe0: sbfx            x1, x0, #1, #0x1f
    // 0x82bbe4: mov             x0, x1
    // 0x82bbe8: r1 = 0
    //     0x82bbe8: mov             x1, #0
    // 0x82bbec: cmp             x1, x0
    // 0x82bbf0: b.hs            #0x82bc24
    // 0x82bbf4: LoadField: r0 = r2->field_f
    //     0x82bbf4: ldur            w0, [x2, #0xf]
    // 0x82bbf8: DecompressPointer r0
    //     0x82bbf8: add             x0, x0, HEAP, lsl #32
    // 0x82bbfc: LoadField: r1 = r0->field_f
    //     0x82bbfc: ldur            w1, [x0, #0xf]
    // 0x82bc00: DecompressPointer r1
    //     0x82bc00: add             x1, x1, HEAP, lsl #32
    // 0x82bc04: r0 = trimLeft()
    //     0x82bc04: bl              #0x82b96c  ; [dart:core] _StringBase::trimLeft
    // 0x82bc08: r1 = Null
    //     0x82bc08: mov             x1, NULL
    // 0x82bc0c: r0 = DiagnosticsNode.message()
    //     0x82bc0c: bl              #0x82bc28  ; [package:flutter/src/foundation/diagnostics.dart] DiagnosticsNode::DiagnosticsNode.message
    // 0x82bc10: LeaveFrame
    //     0x82bc10: mov             SP, fp
    //     0x82bc14: ldp             fp, lr, [SP], #0x10
    // 0x82bc18: ret
    //     0x82bc18: ret             
    // 0x82bc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bc1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bc20: b               #0x82bbb0
    // 0x82bc24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82bc24: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ exceptionAsString(/* No info */) {
    // ** addr: 0x82bc74, size: 0x564
    // 0x82bc74: EnterFrame
    //     0x82bc74: stp             fp, lr, [SP, #-0x10]!
    //     0x82bc78: mov             fp, SP
    // 0x82bc7c: AllocStack(0x58)
    //     0x82bc7c: sub             SP, SP, #0x58
    // 0x82bc80: CheckStackOverflow
    //     0x82bc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bc84: cmp             SP, x16
    //     0x82bc88: b.ls            #0x82c1c8
    // 0x82bc8c: LoadField: r3 = r1->field_7
    //     0x82bc8c: ldur            w3, [x1, #7]
    // 0x82bc90: DecompressPointer r3
    //     0x82bc90: add             x3, x3, HEAP, lsl #32
    // 0x82bc94: mov             x0, x3
    // 0x82bc98: stur            x3, [fp, #-8]
    // 0x82bc9c: r2 = Null
    //     0x82bc9c: mov             x2, NULL
    // 0x82bca0: r1 = Null
    //     0x82bca0: mov             x1, NULL
    // 0x82bca4: cmp             w0, NULL
    // 0x82bca8: b.eq            #0x82bcdc
    // 0x82bcac: branchIfSmi(r0, 0x82bcdc)
    //     0x82bcac: tbz             w0, #0, #0x82bcdc
    // 0x82bcb0: r3 = LoadClassIdInstr(r0)
    //     0x82bcb0: ldur            x3, [x0, #-1]
    //     0x82bcb4: ubfx            x3, x3, #0xc, #0x14
    // 0x82bcb8: r17 = 7754
    //     0x82bcb8: mov             x17, #0x1e4a
    // 0x82bcbc: cmp             x3, x17
    // 0x82bcc0: b.eq            #0x82bce4
    // 0x82bcc4: r17 = 7766
    //     0x82bcc4: mov             x17, #0x1e56
    // 0x82bcc8: cmp             x3, x17
    // 0x82bccc: b.eq            #0x82bce4
    // 0x82bcd0: r17 = 7781
    //     0x82bcd0: mov             x17, #0x1e65
    // 0x82bcd4: cmp             x3, x17
    // 0x82bcd8: b.eq            #0x82bce4
    // 0x82bcdc: r0 = false
    //     0x82bcdc: add             x0, NULL, #0x30  ; false
    // 0x82bce0: b               #0x82bce8
    // 0x82bce4: r0 = true
    //     0x82bce4: add             x0, NULL, #0x20  ; true
    // 0x82bce8: tbnz            w0, #4, #0x82bfec
    // 0x82bcec: ldur            x2, [fp, #-8]
    // 0x82bcf0: r0 = LoadClassIdInstr(r2)
    //     0x82bcf0: ldur            x0, [x2, #-1]
    //     0x82bcf4: ubfx            x0, x0, #0xc, #0x14
    // 0x82bcf8: mov             x1, x2
    // 0x82bcfc: r0 = GDT[cid_x0 + -0xdd4]()
    //     0x82bcfc: sub             lr, x0, #0xdd4
    //     0x82bd00: ldr             lr, [x21, lr, lsl #3]
    //     0x82bd04: blr             lr
    // 0x82bd08: mov             x1, x0
    // 0x82bd0c: ldur            x3, [fp, #-8]
    // 0x82bd10: stur            x1, [fp, #-0x10]
    // 0x82bd14: r0 = LoadClassIdInstr(r3)
    //     0x82bd14: ldur            x0, [x3, #-1]
    //     0x82bd18: ubfx            x0, x0, #0xc, #0x14
    // 0x82bd1c: str             x3, [SP]
    // 0x82bd20: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82bd20: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82bd24: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x82bd24: mov             x17, #0x91c1
    //     0x82bd28: add             lr, x0, x17
    //     0x82bd2c: ldr             lr, [x21, lr, lsl #3]
    //     0x82bd30: blr             lr
    // 0x82bd34: mov             x2, x0
    // 0x82bd38: ldur            x1, [fp, #-0x10]
    // 0x82bd3c: stur            x2, [fp, #-0x18]
    // 0x82bd40: r0 = 60
    //     0x82bd40: mov             x0, #0x3c
    // 0x82bd44: branchIfSmi(r1, 0x82bd50)
    //     0x82bd44: tbz             w1, #0, #0x82bd50
    // 0x82bd48: r0 = LoadClassIdInstr(r1)
    //     0x82bd48: ldur            x0, [x1, #-1]
    //     0x82bd4c: ubfx            x0, x0, #0xc, #0x14
    // 0x82bd50: sub             x16, x0, #0x5e
    // 0x82bd54: cmp             x16, #1
    // 0x82bd58: b.hi            #0x82bfd4
    // 0x82bd5c: r0 = LoadClassIdInstr(r1)
    //     0x82bd5c: ldur            x0, [x1, #-1]
    //     0x82bd60: ubfx            x0, x0, #0xc, #0x14
    // 0x82bd64: stp             x2, x1, [SP]
    // 0x82bd68: mov             lr, x0
    // 0x82bd6c: ldr             lr, [x21, lr, lsl #3]
    // 0x82bd70: blr             lr
    // 0x82bd74: tbz             w0, #4, #0x82bfd4
    // 0x82bd78: ldur            x2, [fp, #-0x10]
    // 0x82bd7c: ldur            x3, [fp, #-0x18]
    // 0x82bd80: LoadField: r0 = r3->field_7
    //     0x82bd80: ldur            w0, [x3, #7]
    // 0x82bd84: LoadField: r1 = r2->field_7
    //     0x82bd84: ldur            w1, [x2, #7]
    // 0x82bd88: r4 = LoadInt32Instr(r0)
    //     0x82bd88: sbfx            x4, x0, #1, #0x1f
    // 0x82bd8c: r0 = LoadInt32Instr(r1)
    //     0x82bd8c: sbfx            x0, x1, #1, #0x1f
    // 0x82bd90: cmp             x4, x0
    // 0x82bd94: b.le            #0x82bfcc
    // 0x82bd98: sub             x5, x4, x0
    // 0x82bd9c: stur            x5, [fp, #-0x28]
    // 0x82bda0: cmp             x5, x4
    // 0x82bda4: b.ge            #0x82bdb0
    // 0x82bda8: mov             x0, x5
    // 0x82bdac: b               #0x82bdb4
    // 0x82bdb0: mov             x0, x4
    // 0x82bdb4: mov             x4, x0
    // 0x82bdb8: stur            x4, [fp, #-0x20]
    // 0x82bdbc: CheckStackOverflow
    //     0x82bdbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bdc0: cmp             SP, x16
    //     0x82bdc4: b.ls            #0x82c1d0
    // 0x82bdc8: tbnz            x4, #0x3f, #0x82be14
    // 0x82bdcc: r0 = BoxInt64Instr(r4)
    //     0x82bdcc: sbfiz           x0, x4, #1, #0x1f
    //     0x82bdd0: cmp             x4, x0, asr #1
    //     0x82bdd4: b.eq            #0x82bde0
    //     0x82bdd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82bddc: stur            x4, [x0, #7]
    // 0x82bde0: stp             x0, x3, [SP, #8]
    // 0x82bde4: str             x2, [SP]
    // 0x82bde8: r0 = _substringMatches()
    //     0x82bde8: bl              #0x7ea6d8  ; [dart:core] _StringBase::_substringMatches
    // 0x82bdec: tbz             w0, #4, #0x82be08
    // 0x82bdf0: ldur            x0, [fp, #-0x20]
    // 0x82bdf4: sub             x4, x0, #1
    // 0x82bdf8: ldur            x2, [fp, #-0x10]
    // 0x82bdfc: ldur            x3, [fp, #-0x18]
    // 0x82be00: ldur            x5, [fp, #-0x28]
    // 0x82be04: b               #0x82bdb8
    // 0x82be08: ldur            x0, [fp, #-0x20]
    // 0x82be0c: mov             x2, x0
    // 0x82be10: b               #0x82be18
    // 0x82be14: r2 = -1
    //     0x82be14: mov             x2, #-1
    // 0x82be18: ldur            x0, [fp, #-0x28]
    // 0x82be1c: cmp             x2, x0
    // 0x82be20: b.ne            #0x82bfc4
    // 0x82be24: cmp             x2, #2
    // 0x82be28: b.le            #0x82bfc4
    // 0x82be2c: sub             x3, x2, #2
    // 0x82be30: stur            x3, [fp, #-0x20]
    // 0x82be34: r0 = BoxInt64Instr(r2)
    //     0x82be34: sbfiz           x0, x2, #1, #0x1f
    //     0x82be38: cmp             x2, x0, asr #1
    //     0x82be3c: b.eq            #0x82be48
    //     0x82be40: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82be44: stur            x2, [x0, #7]
    // 0x82be48: str             x0, [SP]
    // 0x82be4c: ldur            x1, [fp, #-0x18]
    // 0x82be50: mov             x2, x3
    // 0x82be54: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x82be54: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x82be58: r0 = substring()
    //     0x82be58: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x82be5c: r1 = LoadClassIdInstr(r0)
    //     0x82be5c: ldur            x1, [x0, #-1]
    //     0x82be60: ubfx            x1, x1, #0xc, #0x14
    // 0x82be64: r16 = ": "
    //     0x82be64: ldr             x16, [PP, #0xcb0]  ; [pp+0xcb0] ": "
    // 0x82be68: stp             x16, x0, [SP]
    // 0x82be6c: mov             x0, x1
    // 0x82be70: mov             lr, x0
    // 0x82be74: ldr             lr, [x21, lr, lsl #3]
    // 0x82be78: blr             lr
    // 0x82be7c: tbnz            w0, #4, #0x82bfc4
    // 0x82be80: ldur            x2, [fp, #-0x20]
    // 0x82be84: r0 = BoxInt64Instr(r2)
    //     0x82be84: sbfiz           x0, x2, #1, #0x1f
    //     0x82be88: cmp             x2, x0, asr #1
    //     0x82be8c: b.eq            #0x82be98
    //     0x82be90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82be94: stur            x2, [x0, #7]
    // 0x82be98: str             x0, [SP]
    // 0x82be9c: ldur            x1, [fp, #-0x18]
    // 0x82bea0: r2 = 0
    //     0x82bea0: mov             x2, #0
    // 0x82bea4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x82bea4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x82bea8: r0 = substring()
    //     0x82bea8: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x82beac: mov             x3, x0
    // 0x82beb0: stur            x3, [fp, #-0x30]
    // 0x82beb4: r0 = LoadClassIdInstr(r3)
    //     0x82beb4: ldur            x0, [x3, #-1]
    //     0x82beb8: ubfx            x0, x0, #0xc, #0x14
    // 0x82bebc: mov             x1, x3
    // 0x82bec0: r2 = " Failed assertion:"
    //     0x82bec0: ldr             x2, [PP, #0xcb8]  ; [pp+0xcb8] " Failed assertion:"
    // 0x82bec4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bec4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bec8: r0 = GDT[cid_x0 + -0xffa]()
    //     0x82bec8: sub             lr, x0, #0xffa
    //     0x82becc: ldr             lr, [x21, lr, lsl #3]
    //     0x82bed0: blr             lr
    // 0x82bed4: mov             x3, x0
    // 0x82bed8: stur            x3, [fp, #-0x20]
    // 0x82bedc: tbnz            x3, #0x3f, #0x82bf7c
    // 0x82bee0: r0 = BoxInt64Instr(r3)
    //     0x82bee0: sbfiz           x0, x3, #1, #0x1f
    //     0x82bee4: cmp             x3, x0, asr #1
    //     0x82bee8: b.eq            #0x82bef4
    //     0x82beec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82bef0: stur            x3, [x0, #7]
    // 0x82bef4: str             x0, [SP]
    // 0x82bef8: ldur            x1, [fp, #-0x30]
    // 0x82befc: r2 = 0
    //     0x82befc: mov             x2, #0
    // 0x82bf00: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x82bf00: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x82bf04: r0 = substring()
    //     0x82bf04: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x82bf08: r1 = Null
    //     0x82bf08: mov             x1, NULL
    // 0x82bf0c: r2 = 6
    //     0x82bf0c: mov             x2, #6
    // 0x82bf10: stur            x0, [fp, #-0x38]
    // 0x82bf14: r0 = AllocateArray()
    //     0x82bf14: bl              #0x13df928  ; AllocateArrayStub
    // 0x82bf18: mov             x3, x0
    // 0x82bf1c: ldur            x0, [fp, #-0x38]
    // 0x82bf20: stur            x3, [fp, #-0x40]
    // 0x82bf24: StoreField: r3->field_f = r0
    //     0x82bf24: stur            w0, [x3, #0xf]
    // 0x82bf28: r16 = "\n"
    //     0x82bf28: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82bf2c: StoreField: r3->field_13 = r16
    //     0x82bf2c: stur            w16, [x3, #0x13]
    // 0x82bf30: ldur            x0, [fp, #-0x20]
    // 0x82bf34: add             x2, x0, #1
    // 0x82bf38: ldur            x1, [fp, #-0x30]
    // 0x82bf3c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bf3c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bf40: r0 = substring()
    //     0x82bf40: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x82bf44: ldur            x1, [fp, #-0x40]
    // 0x82bf48: ArrayStore: r1[2] = r0  ; List_4
    //     0x82bf48: add             x25, x1, #0x17
    //     0x82bf4c: str             w0, [x25]
    //     0x82bf50: tbz             w0, #0, #0x82bf6c
    //     0x82bf54: ldurb           w16, [x1, #-1]
    //     0x82bf58: ldurb           w17, [x0, #-1]
    //     0x82bf5c: and             x16, x17, x16, lsr #2
    //     0x82bf60: tst             x16, HEAP, lsr #32
    //     0x82bf64: b.eq            #0x82bf6c
    //     0x82bf68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82bf6c: ldur            x16, [fp, #-0x40]
    // 0x82bf70: str             x16, [SP]
    // 0x82bf74: r0 = _interpolate()
    //     0x82bf74: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82bf78: b               #0x82bf80
    // 0x82bf7c: ldur            x0, [fp, #-0x30]
    // 0x82bf80: ldur            x1, [fp, #-0x10]
    // 0x82bf84: stur            x0, [fp, #-0x30]
    // 0x82bf88: r0 = trimRight()
    //     0x82bf88: bl              #0x82c1d8  ; [dart:core] _StringBase::trimRight
    // 0x82bf8c: r1 = Null
    //     0x82bf8c: mov             x1, NULL
    // 0x82bf90: r2 = 6
    //     0x82bf90: mov             x2, #6
    // 0x82bf94: stur            x0, [fp, #-0x10]
    // 0x82bf98: r0 = AllocateArray()
    //     0x82bf98: bl              #0x13df928  ; AllocateArrayStub
    // 0x82bf9c: mov             x1, x0
    // 0x82bfa0: ldur            x0, [fp, #-0x10]
    // 0x82bfa4: StoreField: r1->field_f = r0
    //     0x82bfa4: stur            w0, [x1, #0xf]
    // 0x82bfa8: r16 = "\n"
    //     0x82bfa8: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82bfac: StoreField: r1->field_13 = r16
    //     0x82bfac: stur            w16, [x1, #0x13]
    // 0x82bfb0: ldur            x0, [fp, #-0x30]
    // 0x82bfb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x82bfb4: stur            w0, [x1, #0x17]
    // 0x82bfb8: str             x1, [SP]
    // 0x82bfbc: r0 = _interpolate()
    //     0x82bfbc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82bfc0: b               #0x82bfd8
    // 0x82bfc4: r0 = Null
    //     0x82bfc4: mov             x0, NULL
    // 0x82bfc8: b               #0x82bfd8
    // 0x82bfcc: r0 = Null
    //     0x82bfcc: mov             x0, NULL
    // 0x82bfd0: b               #0x82bfd8
    // 0x82bfd4: r0 = Null
    //     0x82bfd4: mov             x0, NULL
    // 0x82bfd8: cmp             w0, NULL
    // 0x82bfdc: b.ne            #0x82bfe4
    // 0x82bfe0: ldur            x0, [fp, #-0x18]
    // 0x82bfe4: mov             x1, x0
    // 0x82bfe8: b               #0x82c1ac
    // 0x82bfec: ldur            x3, [fp, #-8]
    // 0x82bff0: r0 = 60
    //     0x82bff0: mov             x0, #0x3c
    // 0x82bff4: branchIfSmi(r3, 0x82c000)
    //     0x82bff4: tbz             w3, #0, #0x82c000
    // 0x82bff8: r0 = LoadClassIdInstr(r3)
    //     0x82bff8: ldur            x0, [x3, #-1]
    //     0x82bffc: ubfx            x0, x0, #0xc, #0x14
    // 0x82c000: sub             x16, x0, #0x5e
    // 0x82c004: cmp             x16, #1
    // 0x82c008: b.hi            #0x82c048
    // 0x82c00c: mov             x0, x3
    // 0x82c010: r2 = Null
    //     0x82c010: mov             x2, NULL
    // 0x82c014: r1 = Null
    //     0x82c014: mov             x1, NULL
    // 0x82c018: r4 = 60
    //     0x82c018: mov             x4, #0x3c
    // 0x82c01c: branchIfSmi(r0, 0x82c028)
    //     0x82c01c: tbz             w0, #0, #0x82c028
    // 0x82c020: r4 = LoadClassIdInstr(r0)
    //     0x82c020: ldur            x4, [x0, #-1]
    //     0x82c024: ubfx            x4, x4, #0xc, #0x14
    // 0x82c028: sub             x4, x4, #0x5e
    // 0x82c02c: cmp             x4, #1
    // 0x82c030: b.ls            #0x82c040
    // 0x82c034: r8 = String
    //     0x82c034: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x82c038: r3 = Null
    //     0x82c038: ldr             x3, [PP, #0xcc0]  ; [pp+0xcc0] Null
    // 0x82c03c: r0 = String()
    //     0x82c03c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x82c040: ldur            x0, [fp, #-8]
    // 0x82c044: b               #0x82c1a8
    // 0x82c048: ldur            x0, [fp, #-8]
    // 0x82c04c: r2 = Null
    //     0x82c04c: mov             x2, NULL
    // 0x82c050: r1 = Null
    //     0x82c050: mov             x1, NULL
    // 0x82c054: cmp             w0, NULL
    // 0x82c058: b.eq            #0x82c09c
    // 0x82c05c: branchIfSmi(r0, 0x82c09c)
    //     0x82c05c: tbz             w0, #0, #0x82c09c
    // 0x82c060: r3 = LoadClassIdInstr(r0)
    //     0x82c060: ldur            x3, [x0, #-1]
    //     0x82c064: ubfx            x3, x3, #0xc, #0x14
    // 0x82c068: r17 = 7173
    //     0x82c068: mov             x17, #0x1c05
    // 0x82c06c: cmp             x3, x17
    // 0x82c070: b.eq            #0x82c0a4
    // 0x82c074: r17 = 7569
    //     0x82c074: mov             x17, #0x1d91
    // 0x82c078: cmp             x3, x17
    // 0x82c07c: b.eq            #0x82c0a4
    // 0x82c080: r17 = 7741
    //     0x82c080: mov             x17, #0x1e3d
    // 0x82c084: cmp             x3, x17
    // 0x82c088: b.eq            #0x82c0a4
    // 0x82c08c: r17 = -7745
    //     0x82c08c: mov             x17, #-0x1e41
    // 0x82c090: add             x3, x3, x17
    // 0x82c094: cmp             x3, #0x24
    // 0x82c098: b.ls            #0x82c0a4
    // 0x82c09c: r0 = false
    //     0x82c09c: add             x0, NULL, #0x30  ; false
    // 0x82c0a0: b               #0x82c0a8
    // 0x82c0a4: r0 = true
    //     0x82c0a4: add             x0, NULL, #0x20  ; true
    // 0x82c0a8: tbz             w0, #4, #0x82c14c
    // 0x82c0ac: ldur            x0, [fp, #-8]
    // 0x82c0b0: r2 = Null
    //     0x82c0b0: mov             x2, NULL
    // 0x82c0b4: r1 = Null
    //     0x82c0b4: mov             x1, NULL
    // 0x82c0b8: cmp             w0, NULL
    // 0x82c0bc: b.eq            #0x82c13c
    // 0x82c0c0: branchIfSmi(r0, 0x82c13c)
    //     0x82c0c0: tbz             w0, #0, #0x82c13c
    // 0x82c0c4: r3 = LoadClassIdInstr(r0)
    //     0x82c0c4: ldur            x3, [x0, #-1]
    //     0x82c0c8: ubfx            x3, x3, #0xc, #0x14
    // 0x82c0cc: r4 = LoadClassIdInstr(r0)
    //     0x82c0cc: ldur            x4, [x0, #-1]
    //     0x82c0d0: ubfx            x4, x4, #0xc, #0x14
    // 0x82c0d4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x82c0d8: ldr             x3, [x3, #0x18]
    // 0x82c0dc: ldr             x3, [x3, x4, lsl #3]
    // 0x82c0e0: LoadField: r3 = r3->field_2b
    //     0x82c0e0: ldur            w3, [x3, #0x2b]
    // 0x82c0e4: DecompressPointer r3
    //     0x82c0e4: add             x3, x3, HEAP, lsl #32
    // 0x82c0e8: cmp             w3, NULL
    // 0x82c0ec: b.eq            #0x82c13c
    // 0x82c0f0: LoadField: r3 = r3->field_f
    //     0x82c0f0: ldur            w3, [x3, #0xf]
    // 0x82c0f4: lsr             x3, x3, #3
    // 0x82c0f8: r17 = 7744
    //     0x82c0f8: mov             x17, #0x1e40
    // 0x82c0fc: cmp             x3, x17
    // 0x82c100: b.eq            #0x82c144
    // 0x82c104: r3 = SubtypeTestCache
    //     0x82c104: ldr             x3, [PP, #0xcd0]  ; [pp+0xcd0] SubtypeTestCache
    // 0x82c108: r30 = Subtype1TestCacheStub
    //     0x82c108: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x82c10c: LoadField: r30 = r30->field_7
    //     0x82c10c: ldur            lr, [lr, #7]
    // 0x82c110: blr             lr
    // 0x82c114: cmp             w7, NULL
    // 0x82c118: b.eq            #0x82c124
    // 0x82c11c: tbnz            w7, #4, #0x82c13c
    // 0x82c120: b               #0x82c144
    // 0x82c124: r8 = Exception
    //     0x82c124: ldr             x8, [PP, #0xcd8]  ; [pp+0xcd8] Type: Exception
    // 0x82c128: r3 = SubtypeTestCache
    //     0x82c128: ldr             x3, [PP, #0xce0]  ; [pp+0xce0] SubtypeTestCache
    // 0x82c12c: r30 = InstanceOfStub
    //     0x82c12c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x82c130: LoadField: r30 = r30->field_7
    //     0x82c130: ldur            lr, [lr, #7]
    // 0x82c134: blr             lr
    // 0x82c138: b               #0x82c148
    // 0x82c13c: r0 = false
    //     0x82c13c: add             x0, NULL, #0x30  ; false
    // 0x82c140: b               #0x82c148
    // 0x82c144: r0 = true
    //     0x82c144: add             x0, NULL, #0x20  ; true
    // 0x82c148: tbnz            w0, #4, #0x82c180
    // 0x82c14c: ldur            x0, [fp, #-8]
    // 0x82c150: r1 = 60
    //     0x82c150: mov             x1, #0x3c
    // 0x82c154: branchIfSmi(r0, 0x82c160)
    //     0x82c154: tbz             w0, #0, #0x82c160
    // 0x82c158: r1 = LoadClassIdInstr(r0)
    //     0x82c158: ldur            x1, [x0, #-1]
    //     0x82c15c: ubfx            x1, x1, #0xc, #0x14
    // 0x82c160: str             x0, [SP]
    // 0x82c164: mov             x0, x1
    // 0x82c168: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82c168: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82c16c: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x82c16c: mov             x17, #0x91c1
    //     0x82c170: add             lr, x0, x17
    //     0x82c174: ldr             lr, [x21, lr, lsl #3]
    //     0x82c178: blr             lr
    // 0x82c17c: b               #0x82c1a8
    // 0x82c180: ldur            x0, [fp, #-8]
    // 0x82c184: r1 = Null
    //     0x82c184: mov             x1, NULL
    // 0x82c188: r2 = 4
    //     0x82c188: mov             x2, #4
    // 0x82c18c: r0 = AllocateArray()
    //     0x82c18c: bl              #0x13df928  ; AllocateArrayStub
    // 0x82c190: r16 = "  "
    //     0x82c190: ldr             x16, [PP, #0xce8]  ; [pp+0xce8] "  "
    // 0x82c194: StoreField: r0->field_f = r16
    //     0x82c194: stur            w16, [x0, #0xf]
    // 0x82c198: ldur            x1, [fp, #-8]
    // 0x82c19c: StoreField: r0->field_13 = r1
    //     0x82c19c: stur            w1, [x0, #0x13]
    // 0x82c1a0: str             x0, [SP]
    // 0x82c1a4: r0 = _interpolate()
    //     0x82c1a4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82c1a8: mov             x1, x0
    // 0x82c1ac: r0 = trimRight()
    //     0x82c1ac: bl              #0x82c1d8  ; [dart:core] _StringBase::trimRight
    // 0x82c1b0: LoadField: r1 = r0->field_7
    //     0x82c1b0: ldur            w1, [x0, #7]
    // 0x82c1b4: cbnz            w1, #0x82c1bc
    // 0x82c1b8: r0 = "  <no message available>"
    //     0x82c1b8: ldr             x0, [PP, #0xcf0]  ; [pp+0xcf0] "  <no message available>"
    // 0x82c1bc: LeaveFrame
    //     0x82c1bc: mov             SP, fp
    //     0x82c1c0: ldp             fp, lr, [SP], #0x10
    // 0x82c1c4: ret
    //     0x82c1c4: ret             
    // 0x82c1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c1c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c1cc: b               #0x82bc8c
    // 0x82c1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c1d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c1d4: b               #0x82bdc8
  }
}

// class id: 7754, size: 0x10, field offset: 0xc
class FlutterError extends _MixinApplication182&Error&DiagnosticableTreeMixin
    implements AssertionError {

  static late ((dynamic, FlutterErrorDetails) => void)? onError; // offset: 0x46c
  static late (dynamic, FlutterErrorDetails) => void presentError; // offset: 0x474
  static late (dynamic, StackTrace) => StackTrace demangleStackTrace; // offset: 0x470
  static late final List<StackFilter> _stackFilters; // offset: 0x47c

  static _ reportError(/* No info */) {
    // ** addr: 0x829a24, size: 0x6c
    // 0x829a24: EnterFrame
    //     0x829a24: stp             fp, lr, [SP, #-0x10]!
    //     0x829a28: mov             fp, SP
    // 0x829a2c: AllocStack(0x18)
    //     0x829a2c: sub             SP, SP, #0x18
    // 0x829a30: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x829a30: stur            x1, [fp, #-8]
    // 0x829a34: CheckStackOverflow
    //     0x829a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829a38: cmp             SP, x16
    //     0x829a3c: b.ls            #0x829a88
    // 0x829a40: r0 = LoadStaticField(0x46c)
    //     0x829a40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x829a44: ldr             x0, [x0, #0x8d8]
    // 0x829a48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x829a4c: cmp             w0, w16
    // 0x829a50: b.ne            #0x829a5c
    // 0x829a54: r2 = onError
    //     0x829a54: ldr             x2, [PP, #0x878]  ; [pp+0x878] Field <FlutterError.onError>: static late (offset: 0x46c)
    // 0x829a58: r0 = InitLateStaticField()
    //     0x829a58: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x829a5c: cmp             w0, NULL
    // 0x829a60: b.eq            #0x829a78
    // 0x829a64: ldur            x16, [fp, #-8]
    // 0x829a68: stp             x16, x0, [SP]
    // 0x829a6c: ClosureCall
    //     0x829a6c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x829a70: ldur            x2, [x0, #0x1f]
    //     0x829a74: blr             x2
    // 0x829a78: r0 = Null
    //     0x829a78: mov             x0, NULL
    // 0x829a7c: LeaveFrame
    //     0x829a7c: mov             SP, fp
    //     0x829a80: ldp             fp, lr, [SP], #0x10
    // 0x829a84: ret
    //     0x829a84: ret             
    // 0x829a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829a88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829a8c: b               #0x829a40
  }
  static ((dynamic, FlutterErrorDetails) => void)? onError() {
    // ** addr: 0x829cbc, size: 0x48
    // 0x829cbc: EnterFrame
    //     0x829cbc: stp             fp, lr, [SP, #-0x10]!
    //     0x829cc0: mov             fp, SP
    // 0x829cc4: CheckStackOverflow
    //     0x829cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829cc8: cmp             SP, x16
    //     0x829ccc: b.ls            #0x829cfc
    // 0x829cd0: r0 = LoadStaticField(0x474)
    //     0x829cd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x829cd4: ldr             x0, [x0, #0x8e8]
    // 0x829cd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x829cdc: cmp             w0, w16
    // 0x829ce0: b.ne            #0x829cec
    // 0x829ce4: r2 = presentError
    //     0x829ce4: ldr             x2, [PP, #0x880]  ; [pp+0x880] Field <FlutterError.presentError>: static late (offset: 0x474)
    // 0x829ce8: r0 = InitLateStaticField()
    //     0x829ce8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x829cec: r0 = Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static.
    //     0x829cec: ldr             x0, [PP, #0x888]  ; [pp+0x888] Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static. (0x7f2ada710d04)
    // 0x829cf0: LeaveFrame
    //     0x829cf0: mov             SP, fp
    //     0x829cf4: ldp             fp, lr, [SP], #0x10
    // 0x829cf8: ret
    //     0x829cf8: ret             
    // 0x829cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829d00: b               #0x829cd0
  }
  [closure] static void dumpErrorToConsole(dynamic, FlutterErrorDetails, {bool forceReport}) {
    // ** addr: 0x829d04, size: 0x7c
    // 0x829d04: EnterFrame
    //     0x829d04: stp             fp, lr, [SP, #-0x10]!
    //     0x829d08: mov             fp, SP
    // 0x829d0c: AllocStack(0x8)
    //     0x829d0c: sub             SP, SP, #8
    // 0x829d10: SetupParameters(dynamic _ /* r2 */, {dynamic forceReport = false /* r0 */})
    //     0x829d10: ldur            w0, [x4, #0x13]
    //     0x829d14: sub             x1, x0, #4
    //     0x829d18: add             x2, fp, w1, sxtw #2
    //     0x829d1c: ldr             x2, [x2, #0x10]
    //     0x829d20: ldur            w1, [x4, #0x1f]
    //     0x829d24: add             x1, x1, HEAP, lsl #32
    //     0x829d28: ldr             x16, [PP, #0x890]  ; [pp+0x890] "forceReport"
    //     0x829d2c: cmp             w1, w16
    //     0x829d30: b.ne            #0x829d4c
    //     0x829d34: ldur            w1, [x4, #0x23]
    //     0x829d38: add             x1, x1, HEAP, lsl #32
    //     0x829d3c: sub             w3, w0, w1
    //     0x829d40: add             x0, fp, w3, sxtw #2
    //     0x829d44: ldr             x0, [x0, #8]
    //     0x829d48: b               #0x829d50
    //     0x829d4c: add             x0, NULL, #0x30  ; false
    // 0x829d50: CheckStackOverflow
    //     0x829d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829d54: cmp             SP, x16
    //     0x829d58: b.ls            #0x829d78
    // 0x829d5c: str             x0, [SP]
    // 0x829d60: mov             x1, x2
    // 0x829d64: r4 = const [0, 0x2, 0x1, 0x1, forceReport, 0x1, null]
    //     0x829d64: ldr             x4, [PP, #0x898]  ; [pp+0x898] List(7) [0, 0x2, 0x1, 0x1, "forceReport", 0x1, Null]
    // 0x829d68: r0 = dumpErrorToConsole()
    //     0x829d68: bl              #0x829d80  ; [package:flutter/src/foundation/assertions.dart] FlutterError::dumpErrorToConsole
    // 0x829d6c: LeaveFrame
    //     0x829d6c: mov             SP, fp
    //     0x829d70: ldp             fp, lr, [SP], #0x10
    // 0x829d74: ret
    //     0x829d74: ret             
    // 0x829d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829d78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829d7c: b               #0x829d5c
  }
  static _ dumpErrorToConsole(/* No info */) {
    // ** addr: 0x829d80, size: 0x180
    // 0x829d80: EnterFrame
    //     0x829d80: stp             fp, lr, [SP, #-0x10]!
    //     0x829d84: mov             fp, SP
    // 0x829d88: AllocStack(0x18)
    //     0x829d88: sub             SP, SP, #0x18
    // 0x829d8c: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, {dynamic forceReport = false /* r1 */})
    //     0x829d8c: mov             x0, x1
    //     0x829d90: stur            x1, [fp, #-0x10]
    //     0x829d94: ldur            w1, [x4, #0x13]
    //     0x829d98: ldur            w2, [x4, #0x1f]
    //     0x829d9c: add             x2, x2, HEAP, lsl #32
    //     0x829da0: ldr             x16, [PP, #0x890]  ; [pp+0x890] "forceReport"
    //     0x829da4: cmp             w2, w16
    //     0x829da8: b.ne            #0x829dc4
    //     0x829dac: ldur            w2, [x4, #0x23]
    //     0x829db0: add             x2, x2, HEAP, lsl #32
    //     0x829db4: sub             w3, w1, w2
    //     0x829db8: add             x1, fp, w3, sxtw #2
    //     0x829dbc: ldr             x1, [x1, #8]
    //     0x829dc0: b               #0x829dc8
    //     0x829dc4: add             x1, NULL, #0x30  ; false
    // 0x829dc8: CheckStackOverflow
    //     0x829dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829dcc: cmp             SP, x16
    //     0x829dd0: b.ls            #0x829ef8
    // 0x829dd4: LoadField: r2 = r0->field_1b
    //     0x829dd4: ldur            w2, [x0, #0x1b]
    // 0x829dd8: DecompressPointer r2
    //     0x829dd8: add             x2, x2, HEAP, lsl #32
    // 0x829ddc: eor             x3, x2, #0x10
    // 0x829de0: tbz             w3, #4, #0x829df8
    // 0x829de4: tbz             w1, #4, #0x829df8
    // 0x829de8: r0 = Null
    //     0x829de8: mov             x0, NULL
    // 0x829dec: LeaveFrame
    //     0x829dec: mov             SP, fp
    //     0x829df0: ldp             fp, lr, [SP], #0x10
    // 0x829df4: ret
    //     0x829df4: ret             
    // 0x829df8: r2 = LoadStaticField(0x478)
    //     0x829df8: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x829dfc: ldr             x2, [x2, #0x8f0]
    // 0x829e00: cbz             w2, #0x829e08
    // 0x829e04: tbnz            w1, #4, #0x829e54
    // 0x829e08: LoadField: r2 = r0->field_b
    //     0x829e08: ldur            w2, [x0, #0xb]
    // 0x829e0c: DecompressPointer r2
    //     0x829e0c: add             x2, x2, HEAP, lsl #32
    // 0x829e10: stur            x2, [fp, #-8]
    // 0x829e14: LoadField: r1 = r0->field_7
    //     0x829e14: ldur            w1, [x0, #7]
    // 0x829e18: DecompressPointer r1
    //     0x829e18: add             x1, x1, HEAP, lsl #32
    // 0x829e1c: r0 = 60
    //     0x829e1c: mov             x0, #0x3c
    // 0x829e20: branchIfSmi(r1, 0x829e2c)
    //     0x829e20: tbz             w1, #0, #0x829e2c
    // 0x829e24: r0 = LoadClassIdInstr(r1)
    //     0x829e24: ldur            x0, [x1, #-1]
    //     0x829e28: ubfx            x0, x0, #0xc, #0x14
    // 0x829e2c: str             x1, [SP]
    // 0x829e30: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x829e30: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x829e34: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x829e34: mov             x17, #0x91c1
    //     0x829e38: add             lr, x0, x17
    //     0x829e3c: ldr             lr, [x21, lr, lsl #3]
    //     0x829e40: blr             lr
    // 0x829e44: mov             x1, x0
    // 0x829e48: ldur            x2, [fp, #-8]
    // 0x829e4c: r0 = debugPrintStack()
    //     0x829e4c: bl              #0x82c388  ; [package:flutter/src/foundation/assertions.dart] ::debugPrintStack
    // 0x829e50: b               #0x829eb0
    // 0x829e54: r1 = Null
    //     0x829e54: mov             x1, NULL
    // 0x829e58: r2 = 4
    //     0x829e58: mov             x2, #4
    // 0x829e5c: r0 = AllocateArray()
    //     0x829e5c: bl              #0x13df928  ; AllocateArrayStub
    // 0x829e60: stur            x0, [fp, #-8]
    // 0x829e64: r16 = "Another exception was thrown: "
    //     0x829e64: ldr             x16, [PP, #0x8a0]  ; [pp+0x8a0] "Another exception was thrown: "
    // 0x829e68: StoreField: r0->field_f = r16
    //     0x829e68: stur            w16, [x0, #0xf]
    // 0x829e6c: ldur            x1, [fp, #-0x10]
    // 0x829e70: r0 = summary()
    //     0x829e70: bl              #0x82bb9c  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::summary
    // 0x829e74: ldur            x1, [fp, #-8]
    // 0x829e78: ArrayStore: r1[1] = r0  ; List_4
    //     0x829e78: add             x25, x1, #0x13
    //     0x829e7c: str             w0, [x25]
    //     0x829e80: tbz             w0, #0, #0x829e9c
    //     0x829e84: ldurb           w16, [x1, #-1]
    //     0x829e88: ldurb           w17, [x0, #-1]
    //     0x829e8c: and             x16, x17, x16, lsr #2
    //     0x829e90: tst             x16, HEAP, lsr #32
    //     0x829e94: b.eq            #0x829e9c
    //     0x829e98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x829e9c: ldur            x16, [fp, #-8]
    // 0x829ea0: str             x16, [SP]
    // 0x829ea4: r0 = _interpolate()
    //     0x829ea4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x829ea8: mov             x1, x0
    // 0x829eac: r0 = dump()
    //     0x829eac: bl              #0x829f00  ; [package:flutter/src/foundation/_error_dumper_io.dart] ErrorToConsoleDumper::dump
    // 0x829eb0: r3 = LoadStaticField(0x478)
    //     0x829eb0: ldr             x3, [THR, #0x78]  ; THR::field_table_values
    //     0x829eb4: ldr             x3, [x3, #0x8f0]
    // 0x829eb8: r4 = LoadInt32Instr(r3)
    //     0x829eb8: sbfx            x4, x3, #1, #0x1f
    //     0x829ebc: tbz             w3, #0, #0x829ec4
    //     0x829ec0: ldur            x4, [x3, #7]
    // 0x829ec4: add             x3, x4, #1
    // 0x829ec8: r0 = BoxInt64Instr(r3)
    //     0x829ec8: sbfiz           x0, x3, #1, #0x1f
    //     0x829ecc: cmp             x3, x0, asr #1
    //     0x829ed0: b.eq            #0x829edc
    //     0x829ed4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x829ed8: stur            x3, [x0, #7]
    // 0x829edc: mov             x2, x0
    // 0x829ee0: StoreStaticField(0x478, r2)
    //     0x829ee0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x829ee4: str             x2, [x1, #0x8f0]
    // 0x829ee8: r0 = Null
    //     0x829ee8: mov             x0, NULL
    // 0x829eec: LeaveFrame
    //     0x829eec: mov             SP, fp
    //     0x829ef0: ldp             fp, lr, [SP], #0x10
    // 0x829ef4: ret
    //     0x829ef4: ret             
    // 0x829ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829efc: b               #0x829dd4
  }
  static _ defaultStackFilter(/* No info */) {
    // ** addr: 0x82c474, size: 0x1000
    // 0x82c474: EnterFrame
    //     0x82c474: stp             fp, lr, [SP, #-0x10]!
    //     0x82c478: mov             fp, SP
    // 0x82c47c: AllocStack(0x90)
    //     0x82c47c: sub             SP, SP, #0x90
    // 0x82c480: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x82c480: mov             x0, x1
    //     0x82c484: stur            x1, [fp, #-8]
    // 0x82c488: CheckStackOverflow
    //     0x82c488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c48c: cmp             SP, x16
    //     0x82c490: b.ls            #0x82d3ec
    // 0x82c494: r1 = Null
    //     0x82c494: mov             x1, NULL
    // 0x82c498: r2 = 32
    //     0x82c498: mov             x2, #0x20
    // 0x82c49c: r0 = AllocateArray()
    //     0x82c49c: bl              #0x13df928  ; AllocateArrayStub
    // 0x82c4a0: r16 = "dart:async-patch"
    //     0x82c4a0: ldr             x16, [PP, #0xd80]  ; [pp+0xd80] "dart:async-patch"
    // 0x82c4a4: StoreField: r0->field_f = r16
    //     0x82c4a4: stur            w16, [x0, #0xf]
    // 0x82c4a8: StoreField: r0->field_13 = rZR
    //     0x82c4a8: stur            wzr, [x0, #0x13]
    // 0x82c4ac: r16 = "dart:async"
    //     0x82c4ac: ldr             x16, [PP, #0xd88]  ; [pp+0xd88] "dart:async"
    // 0x82c4b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x82c4b0: stur            w16, [x0, #0x17]
    // 0x82c4b4: StoreField: r0->field_1b = rZR
    //     0x82c4b4: stur            wzr, [x0, #0x1b]
    // 0x82c4b8: r16 = "package:stack_trace"
    //     0x82c4b8: ldr             x16, [PP, #0xd90]  ; [pp+0xd90] "package:stack_trace"
    // 0x82c4bc: StoreField: r0->field_1f = r16
    //     0x82c4bc: stur            w16, [x0, #0x1f]
    // 0x82c4c0: StoreField: r0->field_23 = rZR
    //     0x82c4c0: stur            wzr, [x0, #0x23]
    // 0x82c4c4: r16 = "class _AssertionError"
    //     0x82c4c4: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "class _AssertionError"
    // 0x82c4c8: StoreField: r0->field_27 = r16
    //     0x82c4c8: stur            w16, [x0, #0x27]
    // 0x82c4cc: StoreField: r0->field_2b = rZR
    //     0x82c4cc: stur            wzr, [x0, #0x2b]
    // 0x82c4d0: r16 = "class _FakeAsync"
    //     0x82c4d0: ldr             x16, [PP, #0xda0]  ; [pp+0xda0] "class _FakeAsync"
    // 0x82c4d4: StoreField: r0->field_2f = r16
    //     0x82c4d4: stur            w16, [x0, #0x2f]
    // 0x82c4d8: StoreField: r0->field_33 = rZR
    //     0x82c4d8: stur            wzr, [x0, #0x33]
    // 0x82c4dc: r16 = "class _FrameCallbackEntry"
    //     0x82c4dc: ldr             x16, [PP, #0xda8]  ; [pp+0xda8] "class _FrameCallbackEntry"
    // 0x82c4e0: StoreField: r0->field_37 = r16
    //     0x82c4e0: stur            w16, [x0, #0x37]
    // 0x82c4e4: StoreField: r0->field_3b = rZR
    //     0x82c4e4: stur            wzr, [x0, #0x3b]
    // 0x82c4e8: r16 = "class _Timer"
    //     0x82c4e8: ldr             x16, [PP, #0xdb0]  ; [pp+0xdb0] "class _Timer"
    // 0x82c4ec: StoreField: r0->field_3f = r16
    //     0x82c4ec: stur            w16, [x0, #0x3f]
    // 0x82c4f0: StoreField: r0->field_43 = rZR
    //     0x82c4f0: stur            wzr, [x0, #0x43]
    // 0x82c4f4: r16 = "class _RawReceivePortImpl"
    //     0x82c4f4: ldr             x16, [PP, #0xdb8]  ; [pp+0xdb8] "class _RawReceivePortImpl"
    // 0x82c4f8: StoreField: r0->field_47 = r16
    //     0x82c4f8: stur            w16, [x0, #0x47]
    // 0x82c4fc: StoreField: r0->field_4b = rZR
    //     0x82c4fc: stur            wzr, [x0, #0x4b]
    // 0x82c500: r16 = <String, int>
    //     0x82c500: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <String, int>
    // 0x82c504: stp             x0, x16, [SP]
    // 0x82c508: r0 = Map._fromLiteral()
    //     0x82c508: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x82c50c: mov             x2, x0
    // 0x82c510: ldur            x1, [fp, #-8]
    // 0x82c514: stur            x2, [fp, #-0x10]
    // 0x82c518: r0 = LoadClassIdInstr(r1)
    //     0x82c518: ldur            x0, [x1, #-1]
    //     0x82c51c: ubfx            x0, x0, #0xc, #0x14
    // 0x82c520: r16 = "\n"
    //     0x82c520: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82c524: str             x16, [SP]
    // 0x82c528: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x82c528: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x82c52c: r0 = GDT[cid_x0 + 0x12e1e]()
    //     0x82c52c: mov             x17, #0x2e1e
    //     0x82c530: movk            x17, #1, lsl #16
    //     0x82c534: add             lr, x0, x17
    //     0x82c538: ldr             lr, [x21, lr, lsl #3]
    //     0x82c53c: blr             lr
    // 0x82c540: mov             x1, x0
    // 0x82c544: r0 = fromStackString()
    //     0x82c544: bl              #0x82d624  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString
    // 0x82c548: stur            x0, [fp, #-0x30]
    // 0x82c54c: LoadField: r3 = r0->field_7
    //     0x82c54c: ldur            w3, [x0, #7]
    // 0x82c550: DecompressPointer r3
    //     0x82c550: add             x3, x3, HEAP, lsl #32
    // 0x82c554: stur            x3, [fp, #-0x28]
    // 0x82c558: r6 = 0
    //     0x82c558: mov             x6, #0
    // 0x82c55c: r5 = 0
    //     0x82c55c: mov             x5, #0
    // 0x82c560: ldur            x4, [fp, #-0x10]
    // 0x82c564: stur            x6, [fp, #-0x18]
    // 0x82c568: stur            x5, [fp, #-0x20]
    // 0x82c56c: CheckStackOverflow
    //     0x82c56c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c570: cmp             SP, x16
    //     0x82c574: b.ls            #0x82d3f4
    // 0x82c578: LoadField: r2 = r0->field_b
    //     0x82c578: ldur            w2, [x0, #0xb]
    // 0x82c57c: r7 = LoadInt32Instr(r2)
    //     0x82c57c: sbfx            x7, x2, #1, #0x1f
    // 0x82c580: stur            x7, [fp, #-0x80]
    // 0x82c584: cmp             x5, x7
    // 0x82c588: b.ge            #0x82cb84
    // 0x82c58c: LoadField: r1 = r0->field_f
    //     0x82c58c: ldur            w1, [x0, #0xf]
    // 0x82c590: DecompressPointer r1
    //     0x82c590: add             x1, x1, HEAP, lsl #32
    // 0x82c594: ArrayLoad: r7 = r1[r5]  ; Unknown_4
    //     0x82c594: add             x16, x1, x5, lsl #2
    //     0x82c598: ldur            w7, [x16, #0xf]
    // 0x82c59c: DecompressPointer r7
    //     0x82c59c: add             x7, x7, HEAP, lsl #32
    // 0x82c5a0: stur            x7, [fp, #-8]
    // 0x82c5a4: r1 = Null
    //     0x82c5a4: mov             x1, NULL
    // 0x82c5a8: r2 = 4
    //     0x82c5a8: mov             x2, #4
    // 0x82c5ac: r0 = AllocateArray()
    //     0x82c5ac: bl              #0x13df928  ; AllocateArrayStub
    // 0x82c5b0: r16 = "class "
    //     0x82c5b0: ldr             x16, [PP, #0xdc8]  ; [pp+0xdc8] "class "
    // 0x82c5b4: StoreField: r0->field_f = r16
    //     0x82c5b4: stur            w16, [x0, #0xf]
    // 0x82c5b8: ldur            x1, [fp, #-8]
    // 0x82c5bc: LoadField: r2 = r1->field_2b
    //     0x82c5bc: ldur            w2, [x1, #0x2b]
    // 0x82c5c0: DecompressPointer r2
    //     0x82c5c0: add             x2, x2, HEAP, lsl #32
    // 0x82c5c4: StoreField: r0->field_13 = r2
    //     0x82c5c4: stur            w2, [x0, #0x13]
    // 0x82c5c8: str             x0, [SP]
    // 0x82c5cc: r0 = _interpolate()
    //     0x82c5cc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82c5d0: mov             x3, x0
    // 0x82c5d4: ldur            x0, [fp, #-8]
    // 0x82c5d8: stur            x3, [fp, #-0x40]
    // 0x82c5dc: LoadField: r4 = r0->field_13
    //     0x82c5dc: ldur            w4, [x0, #0x13]
    // 0x82c5e0: DecompressPointer r4
    //     0x82c5e0: add             x4, x4, HEAP, lsl #32
    // 0x82c5e4: stur            x4, [fp, #-0x38]
    // 0x82c5e8: r1 = Null
    //     0x82c5e8: mov             x1, NULL
    // 0x82c5ec: r2 = 6
    //     0x82c5ec: mov             x2, #6
    // 0x82c5f0: r0 = AllocateArray()
    //     0x82c5f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x82c5f4: mov             x1, x0
    // 0x82c5f8: ldur            x0, [fp, #-0x38]
    // 0x82c5fc: StoreField: r1->field_f = r0
    //     0x82c5fc: stur            w0, [x1, #0xf]
    // 0x82c600: r16 = ":"
    //     0x82c600: ldr             x16, [PP, #0xdd0]  ; [pp+0xdd0] ":"
    // 0x82c604: StoreField: r1->field_13 = r16
    //     0x82c604: stur            w16, [x1, #0x13]
    // 0x82c608: ldur            x0, [fp, #-8]
    // 0x82c60c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x82c60c: ldur            w2, [x0, #0x17]
    // 0x82c610: DecompressPointer r2
    //     0x82c610: add             x2, x2, HEAP, lsl #32
    // 0x82c614: ArrayStore: r1[0] = r2  ; List_4
    //     0x82c614: stur            w2, [x1, #0x17]
    // 0x82c618: str             x1, [SP]
    // 0x82c61c: r0 = _interpolate()
    //     0x82c61c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82c620: mov             x3, x0
    // 0x82c624: ldur            x0, [fp, #-0x10]
    // 0x82c628: stur            x3, [fp, #-0x38]
    // 0x82c62c: LoadField: r4 = r0->field_f
    //     0x82c62c: ldur            w4, [x0, #0xf]
    // 0x82c630: DecompressPointer r4
    //     0x82c630: add             x4, x4, HEAP, lsl #32
    // 0x82c634: mov             x1, x0
    // 0x82c638: ldur            x2, [fp, #-0x40]
    // 0x82c63c: stur            x4, [fp, #-8]
    // 0x82c640: r0 = _getValueOrData()
    //     0x82c640: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x82c644: mov             x1, x0
    // 0x82c648: ldur            x0, [fp, #-8]
    // 0x82c64c: cmp             w0, w1
    // 0x82c650: b.eq            #0x82c8c0
    // 0x82c654: ldur            x0, [fp, #-0x30]
    // 0x82c658: ldur            x4, [fp, #-0x18]
    // 0x82c65c: ldur            x3, [fp, #-0x20]
    // 0x82c660: add             x5, x4, #1
    // 0x82c664: stur            x5, [fp, #-0x48]
    // 0x82c668: r1 = Function '<anonymous closure>': static.
    //     0x82c668: ldr             x1, [PP, #0xdd8]  ; [pp+0xdd8] AnonymousClosure: static (0x82e2b0), in [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter (0x82c474)
    // 0x82c66c: r2 = Null
    //     0x82c66c: mov             x2, NULL
    // 0x82c670: r0 = AllocateClosure()
    //     0x82c670: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x82c674: ldur            x1, [fp, #-0x10]
    // 0x82c678: ldur            x2, [fp, #-0x40]
    // 0x82c67c: mov             x3, x0
    // 0x82c680: r0 = update()
    //     0x82c680: bl              #0x82d474  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::update
    // 0x82c684: ldur            x3, [fp, #-0x30]
    // 0x82c688: LoadField: r0 = r3->field_b
    //     0x82c688: ldur            w0, [x3, #0xb]
    // 0x82c68c: r4 = LoadInt32Instr(r0)
    //     0x82c68c: sbfx            x4, x0, #1, #0x1f
    // 0x82c690: mov             x0, x4
    // 0x82c694: ldur            x1, [fp, #-0x20]
    // 0x82c698: stur            x4, [fp, #-0x70]
    // 0x82c69c: cmp             x1, x0
    // 0x82c6a0: b.hs            #0x82d3fc
    // 0x82c6a4: LoadField: r5 = r3->field_f
    //     0x82c6a4: ldur            w5, [x3, #0xf]
    // 0x82c6a8: DecompressPointer r5
    //     0x82c6a8: add             x5, x5, HEAP, lsl #32
    // 0x82c6ac: stur            x5, [fp, #-0x40]
    // 0x82c6b0: sub             x6, x4, #1
    // 0x82c6b4: ldur            x7, [fp, #-0x20]
    // 0x82c6b8: stur            x6, [fp, #-0x68]
    // 0x82c6bc: cmp             x7, x6
    // 0x82c6c0: b.ge            #0x82c89c
    // 0x82c6c4: add             x8, x7, #1
    // 0x82c6c8: stur            x8, [fp, #-0x60]
    // 0x82c6cc: sub             x0, x6, x7
    // 0x82c6d0: cmp             x8, x7
    // 0x82c6d4: b.ge            #0x82c7c4
    // 0x82c6d8: add             x1, x8, x0
    // 0x82c6dc: sub             x2, x1, #1
    // 0x82c6e0: add             x1, x7, x0
    // 0x82c6e4: sub             x0, x1, #1
    // 0x82c6e8: mov             x10, x2
    // 0x82c6ec: mov             x9, x0
    // 0x82c6f0: stur            x10, [fp, #-0x50]
    // 0x82c6f4: stur            x9, [fp, #-0x58]
    // 0x82c6f8: CheckStackOverflow
    //     0x82c6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c6fc: cmp             SP, x16
    //     0x82c700: b.ls            #0x82d400
    // 0x82c704: cmp             x10, x8
    // 0x82c708: b.lt            #0x82c89c
    // 0x82c70c: mov             x0, x4
    // 0x82c710: mov             x1, x10
    // 0x82c714: cmp             x1, x0
    // 0x82c718: b.hs            #0x82d408
    // 0x82c71c: ArrayLoad: r11 = r5[r10]  ; Unknown_4
    //     0x82c71c: add             x16, x5, x10, lsl #2
    //     0x82c720: ldur            w11, [x16, #0xf]
    // 0x82c724: DecompressPointer r11
    //     0x82c724: add             x11, x11, HEAP, lsl #32
    // 0x82c728: mov             x0, x11
    // 0x82c72c: ldur            x2, [fp, #-0x28]
    // 0x82c730: stur            x11, [fp, #-8]
    // 0x82c734: r1 = Null
    //     0x82c734: mov             x1, NULL
    // 0x82c738: cmp             w2, NULL
    // 0x82c73c: b.eq            #0x82c758
    // 0x82c740: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x82c740: ldur            w4, [x2, #0x17]
    // 0x82c744: DecompressPointer r4
    //     0x82c744: add             x4, x4, HEAP, lsl #32
    // 0x82c748: r8 = X0
    //     0x82c748: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x82c74c: LoadField: r9 = r4->field_7
    //     0x82c74c: ldur            x9, [x4, #7]
    // 0x82c750: r3 = Null
    //     0x82c750: ldr             x3, [PP, #0xde0]  ; [pp+0xde0] Null
    // 0x82c754: blr             x9
    // 0x82c758: ldur            x0, [fp, #-0x70]
    // 0x82c75c: ldur            x1, [fp, #-0x58]
    // 0x82c760: cmp             x1, x0
    // 0x82c764: b.hs            #0x82d40c
    // 0x82c768: ldur            x1, [fp, #-0x40]
    // 0x82c76c: ldur            x0, [fp, #-8]
    // 0x82c770: ldur            x2, [fp, #-0x58]
    // 0x82c774: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82c774: add             x25, x1, x2, lsl #2
    //     0x82c778: add             x25, x25, #0xf
    //     0x82c77c: str             w0, [x25]
    //     0x82c780: tbz             w0, #0, #0x82c79c
    //     0x82c784: ldurb           w16, [x1, #-1]
    //     0x82c788: ldurb           w17, [x0, #-1]
    //     0x82c78c: and             x16, x17, x16, lsr #2
    //     0x82c790: tst             x16, HEAP, lsr #32
    //     0x82c794: b.eq            #0x82c79c
    //     0x82c798: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82c79c: ldur            x0, [fp, #-0x50]
    // 0x82c7a0: sub             x10, x0, #1
    // 0x82c7a4: sub             x9, x2, #1
    // 0x82c7a8: ldur            x3, [fp, #-0x30]
    // 0x82c7ac: ldur            x7, [fp, #-0x20]
    // 0x82c7b0: ldur            x6, [fp, #-0x68]
    // 0x82c7b4: ldur            x8, [fp, #-0x60]
    // 0x82c7b8: ldur            x5, [fp, #-0x40]
    // 0x82c7bc: ldur            x4, [fp, #-0x70]
    // 0x82c7c0: b               #0x82c6f0
    // 0x82c7c4: mov             x1, x8
    // 0x82c7c8: add             x3, x1, x0
    // 0x82c7cc: stur            x3, [fp, #-0x78]
    // 0x82c7d0: mov             x6, x1
    // 0x82c7d4: ldur            x5, [fp, #-0x20]
    // 0x82c7d8: ldur            x4, [fp, #-0x40]
    // 0x82c7dc: stur            x6, [fp, #-0x50]
    // 0x82c7e0: stur            x5, [fp, #-0x58]
    // 0x82c7e4: CheckStackOverflow
    //     0x82c7e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c7e8: cmp             SP, x16
    //     0x82c7ec: b.ls            #0x82d410
    // 0x82c7f0: cmp             x6, x3
    // 0x82c7f4: b.ge            #0x82c89c
    // 0x82c7f8: ldur            x0, [fp, #-0x70]
    // 0x82c7fc: mov             x1, x6
    // 0x82c800: cmp             x1, x0
    // 0x82c804: b.hs            #0x82d418
    // 0x82c808: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x82c808: add             x16, x4, x6, lsl #2
    //     0x82c80c: ldur            w7, [x16, #0xf]
    // 0x82c810: DecompressPointer r7
    //     0x82c810: add             x7, x7, HEAP, lsl #32
    // 0x82c814: mov             x0, x7
    // 0x82c818: ldur            x2, [fp, #-0x28]
    // 0x82c81c: stur            x7, [fp, #-8]
    // 0x82c820: r1 = Null
    //     0x82c820: mov             x1, NULL
    // 0x82c824: cmp             w2, NULL
    // 0x82c828: b.eq            #0x82c844
    // 0x82c82c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x82c82c: ldur            w4, [x2, #0x17]
    // 0x82c830: DecompressPointer r4
    //     0x82c830: add             x4, x4, HEAP, lsl #32
    // 0x82c834: r8 = X0
    //     0x82c834: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x82c838: LoadField: r9 = r4->field_7
    //     0x82c838: ldur            x9, [x4, #7]
    // 0x82c83c: r3 = Null
    //     0x82c83c: ldr             x3, [PP, #0xdf0]  ; [pp+0xdf0] Null
    // 0x82c840: blr             x9
    // 0x82c844: ldur            x0, [fp, #-0x70]
    // 0x82c848: ldur            x1, [fp, #-0x58]
    // 0x82c84c: cmp             x1, x0
    // 0x82c850: b.hs            #0x82d41c
    // 0x82c854: ldur            x1, [fp, #-0x40]
    // 0x82c858: ldur            x0, [fp, #-8]
    // 0x82c85c: ldur            x2, [fp, #-0x58]
    // 0x82c860: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82c860: add             x25, x1, x2, lsl #2
    //     0x82c864: add             x25, x25, #0xf
    //     0x82c868: str             w0, [x25]
    //     0x82c86c: tbz             w0, #0, #0x82c888
    //     0x82c870: ldurb           w16, [x1, #-1]
    //     0x82c874: ldurb           w17, [x0, #-1]
    //     0x82c878: and             x16, x17, x16, lsr #2
    //     0x82c87c: tst             x16, HEAP, lsr #32
    //     0x82c880: b.eq            #0x82c888
    //     0x82c884: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82c888: ldur            x0, [fp, #-0x50]
    // 0x82c88c: add             x6, x0, #1
    // 0x82c890: add             x5, x2, #1
    // 0x82c894: ldur            x3, [fp, #-0x78]
    // 0x82c898: b               #0x82c7d8
    // 0x82c89c: ldur            x0, [fp, #-0x20]
    // 0x82c8a0: ldur            x1, [fp, #-0x30]
    // 0x82c8a4: ldur            x2, [fp, #-0x68]
    // 0x82c8a8: r0 = length=()
    //     0x82c8a8: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x82c8ac: ldur            x0, [fp, #-0x20]
    // 0x82c8b0: sub             x1, x0, #1
    // 0x82c8b4: ldur            x6, [fp, #-0x48]
    // 0x82c8b8: mov             x0, x1
    // 0x82c8bc: b               #0x82cb74
    // 0x82c8c0: ldur            x3, [fp, #-0x10]
    // 0x82c8c4: ldur            x4, [fp, #-0x18]
    // 0x82c8c8: ldur            x0, [fp, #-0x20]
    // 0x82c8cc: LoadField: r5 = r3->field_f
    //     0x82c8cc: ldur            w5, [x3, #0xf]
    // 0x82c8d0: DecompressPointer r5
    //     0x82c8d0: add             x5, x5, HEAP, lsl #32
    // 0x82c8d4: mov             x1, x3
    // 0x82c8d8: ldur            x2, [fp, #-0x38]
    // 0x82c8dc: stur            x5, [fp, #-8]
    // 0x82c8e0: r0 = _getValueOrData()
    //     0x82c8e0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x82c8e4: mov             x1, x0
    // 0x82c8e8: ldur            x0, [fp, #-8]
    // 0x82c8ec: cmp             w0, w1
    // 0x82c8f0: b.eq            #0x82cb5c
    // 0x82c8f4: ldur            x4, [fp, #-0x30]
    // 0x82c8f8: ldur            x0, [fp, #-0x18]
    // 0x82c8fc: ldur            x3, [fp, #-0x20]
    // 0x82c900: add             x5, x0, #1
    // 0x82c904: stur            x5, [fp, #-0x48]
    // 0x82c908: r1 = Function '<anonymous closure>': static.
    //     0x82c908: ldr             x1, [PP, #0xe00]  ; [pp+0xe00] AnonymousClosure: static (0x82e2b0), in [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter (0x82c474)
    // 0x82c90c: r2 = Null
    //     0x82c90c: mov             x2, NULL
    // 0x82c910: r0 = AllocateClosure()
    //     0x82c910: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x82c914: ldur            x1, [fp, #-0x10]
    // 0x82c918: ldur            x2, [fp, #-0x38]
    // 0x82c91c: mov             x3, x0
    // 0x82c920: r0 = update()
    //     0x82c920: bl              #0x82d474  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::update
    // 0x82c924: ldur            x3, [fp, #-0x30]
    // 0x82c928: LoadField: r0 = r3->field_b
    //     0x82c928: ldur            w0, [x3, #0xb]
    // 0x82c92c: r4 = LoadInt32Instr(r0)
    //     0x82c92c: sbfx            x4, x0, #1, #0x1f
    // 0x82c930: mov             x0, x4
    // 0x82c934: ldur            x1, [fp, #-0x20]
    // 0x82c938: stur            x4, [fp, #-0x70]
    // 0x82c93c: cmp             x1, x0
    // 0x82c940: b.hs            #0x82d420
    // 0x82c944: LoadField: r5 = r3->field_f
    //     0x82c944: ldur            w5, [x3, #0xf]
    // 0x82c948: DecompressPointer r5
    //     0x82c948: add             x5, x5, HEAP, lsl #32
    // 0x82c94c: stur            x5, [fp, #-0x38]
    // 0x82c950: sub             x6, x4, #1
    // 0x82c954: ldur            x7, [fp, #-0x20]
    // 0x82c958: stur            x6, [fp, #-0x68]
    // 0x82c95c: cmp             x7, x6
    // 0x82c960: b.ge            #0x82cb3c
    // 0x82c964: add             x8, x7, #1
    // 0x82c968: stur            x8, [fp, #-0x60]
    // 0x82c96c: sub             x0, x6, x7
    // 0x82c970: cmp             x8, x7
    // 0x82c974: b.ge            #0x82ca64
    // 0x82c978: add             x1, x8, x0
    // 0x82c97c: sub             x2, x1, #1
    // 0x82c980: add             x1, x7, x0
    // 0x82c984: sub             x0, x1, #1
    // 0x82c988: mov             x10, x2
    // 0x82c98c: mov             x9, x0
    // 0x82c990: stur            x10, [fp, #-0x50]
    // 0x82c994: stur            x9, [fp, #-0x58]
    // 0x82c998: CheckStackOverflow
    //     0x82c998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c99c: cmp             SP, x16
    //     0x82c9a0: b.ls            #0x82d424
    // 0x82c9a4: cmp             x10, x8
    // 0x82c9a8: b.lt            #0x82cb3c
    // 0x82c9ac: mov             x0, x4
    // 0x82c9b0: mov             x1, x10
    // 0x82c9b4: cmp             x1, x0
    // 0x82c9b8: b.hs            #0x82d42c
    // 0x82c9bc: ArrayLoad: r11 = r5[r10]  ; Unknown_4
    //     0x82c9bc: add             x16, x5, x10, lsl #2
    //     0x82c9c0: ldur            w11, [x16, #0xf]
    // 0x82c9c4: DecompressPointer r11
    //     0x82c9c4: add             x11, x11, HEAP, lsl #32
    // 0x82c9c8: mov             x0, x11
    // 0x82c9cc: ldur            x2, [fp, #-0x28]
    // 0x82c9d0: stur            x11, [fp, #-8]
    // 0x82c9d4: r1 = Null
    //     0x82c9d4: mov             x1, NULL
    // 0x82c9d8: cmp             w2, NULL
    // 0x82c9dc: b.eq            #0x82c9f8
    // 0x82c9e0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x82c9e0: ldur            w4, [x2, #0x17]
    // 0x82c9e4: DecompressPointer r4
    //     0x82c9e4: add             x4, x4, HEAP, lsl #32
    // 0x82c9e8: r8 = X0
    //     0x82c9e8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x82c9ec: LoadField: r9 = r4->field_7
    //     0x82c9ec: ldur            x9, [x4, #7]
    // 0x82c9f0: r3 = Null
    //     0x82c9f0: ldr             x3, [PP, #0xe08]  ; [pp+0xe08] Null
    // 0x82c9f4: blr             x9
    // 0x82c9f8: ldur            x0, [fp, #-0x70]
    // 0x82c9fc: ldur            x1, [fp, #-0x58]
    // 0x82ca00: cmp             x1, x0
    // 0x82ca04: b.hs            #0x82d430
    // 0x82ca08: ldur            x1, [fp, #-0x38]
    // 0x82ca0c: ldur            x0, [fp, #-8]
    // 0x82ca10: ldur            x2, [fp, #-0x58]
    // 0x82ca14: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82ca14: add             x25, x1, x2, lsl #2
    //     0x82ca18: add             x25, x25, #0xf
    //     0x82ca1c: str             w0, [x25]
    //     0x82ca20: tbz             w0, #0, #0x82ca3c
    //     0x82ca24: ldurb           w16, [x1, #-1]
    //     0x82ca28: ldurb           w17, [x0, #-1]
    //     0x82ca2c: and             x16, x17, x16, lsr #2
    //     0x82ca30: tst             x16, HEAP, lsr #32
    //     0x82ca34: b.eq            #0x82ca3c
    //     0x82ca38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82ca3c: ldur            x0, [fp, #-0x50]
    // 0x82ca40: sub             x10, x0, #1
    // 0x82ca44: sub             x9, x2, #1
    // 0x82ca48: ldur            x3, [fp, #-0x30]
    // 0x82ca4c: ldur            x7, [fp, #-0x20]
    // 0x82ca50: ldur            x6, [fp, #-0x68]
    // 0x82ca54: ldur            x8, [fp, #-0x60]
    // 0x82ca58: ldur            x5, [fp, #-0x38]
    // 0x82ca5c: ldur            x4, [fp, #-0x70]
    // 0x82ca60: b               #0x82c990
    // 0x82ca64: mov             x1, x8
    // 0x82ca68: add             x3, x1, x0
    // 0x82ca6c: stur            x3, [fp, #-0x78]
    // 0x82ca70: mov             x6, x1
    // 0x82ca74: ldur            x5, [fp, #-0x20]
    // 0x82ca78: ldur            x4, [fp, #-0x38]
    // 0x82ca7c: stur            x6, [fp, #-0x50]
    // 0x82ca80: stur            x5, [fp, #-0x58]
    // 0x82ca84: CheckStackOverflow
    //     0x82ca84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ca88: cmp             SP, x16
    //     0x82ca8c: b.ls            #0x82d434
    // 0x82ca90: cmp             x6, x3
    // 0x82ca94: b.ge            #0x82cb3c
    // 0x82ca98: ldur            x0, [fp, #-0x70]
    // 0x82ca9c: mov             x1, x6
    // 0x82caa0: cmp             x1, x0
    // 0x82caa4: b.hs            #0x82d43c
    // 0x82caa8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x82caa8: add             x16, x4, x6, lsl #2
    //     0x82caac: ldur            w7, [x16, #0xf]
    // 0x82cab0: DecompressPointer r7
    //     0x82cab0: add             x7, x7, HEAP, lsl #32
    // 0x82cab4: mov             x0, x7
    // 0x82cab8: ldur            x2, [fp, #-0x28]
    // 0x82cabc: stur            x7, [fp, #-8]
    // 0x82cac0: r1 = Null
    //     0x82cac0: mov             x1, NULL
    // 0x82cac4: cmp             w2, NULL
    // 0x82cac8: b.eq            #0x82cae4
    // 0x82cacc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x82cacc: ldur            w4, [x2, #0x17]
    // 0x82cad0: DecompressPointer r4
    //     0x82cad0: add             x4, x4, HEAP, lsl #32
    // 0x82cad4: r8 = X0
    //     0x82cad4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x82cad8: LoadField: r9 = r4->field_7
    //     0x82cad8: ldur            x9, [x4, #7]
    // 0x82cadc: r3 = Null
    //     0x82cadc: ldr             x3, [PP, #0xe18]  ; [pp+0xe18] Null
    // 0x82cae0: blr             x9
    // 0x82cae4: ldur            x0, [fp, #-0x70]
    // 0x82cae8: ldur            x1, [fp, #-0x58]
    // 0x82caec: cmp             x1, x0
    // 0x82caf0: b.hs            #0x82d440
    // 0x82caf4: ldur            x1, [fp, #-0x38]
    // 0x82caf8: ldur            x0, [fp, #-8]
    // 0x82cafc: ldur            x2, [fp, #-0x58]
    // 0x82cb00: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82cb00: add             x25, x1, x2, lsl #2
    //     0x82cb04: add             x25, x25, #0xf
    //     0x82cb08: str             w0, [x25]
    //     0x82cb0c: tbz             w0, #0, #0x82cb28
    //     0x82cb10: ldurb           w16, [x1, #-1]
    //     0x82cb14: ldurb           w17, [x0, #-1]
    //     0x82cb18: and             x16, x17, x16, lsr #2
    //     0x82cb1c: tst             x16, HEAP, lsr #32
    //     0x82cb20: b.eq            #0x82cb28
    //     0x82cb24: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82cb28: ldur            x0, [fp, #-0x50]
    // 0x82cb2c: add             x6, x0, #1
    // 0x82cb30: add             x5, x2, #1
    // 0x82cb34: ldur            x3, [fp, #-0x78]
    // 0x82cb38: b               #0x82ca78
    // 0x82cb3c: ldur            x0, [fp, #-0x20]
    // 0x82cb40: ldur            x1, [fp, #-0x30]
    // 0x82cb44: ldur            x2, [fp, #-0x68]
    // 0x82cb48: r0 = length=()
    //     0x82cb48: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x82cb4c: ldur            x1, [fp, #-0x20]
    // 0x82cb50: sub             x0, x1, #1
    // 0x82cb54: ldur            x1, [fp, #-0x48]
    // 0x82cb58: b               #0x82cb70
    // 0x82cb5c: ldur            x0, [fp, #-0x18]
    // 0x82cb60: ldur            x1, [fp, #-0x20]
    // 0x82cb64: mov             x16, x1
    // 0x82cb68: mov             x1, x0
    // 0x82cb6c: mov             x0, x16
    // 0x82cb70: mov             x6, x1
    // 0x82cb74: add             x5, x0, #1
    // 0x82cb78: ldur            x0, [fp, #-0x30]
    // 0x82cb7c: ldur            x3, [fp, #-0x28]
    // 0x82cb80: b               #0x82c560
    // 0x82cb84: mov             x0, x6
    // 0x82cb88: r1 = <String?>
    //     0x82cb88: ldr             x1, [PP, #0xe28]  ; [pp+0xe28] TypeArguments: <String?>
    // 0x82cb8c: r0 = AllocateArray()
    //     0x82cb8c: bl              #0x13df928  ; AllocateArrayStub
    // 0x82cb90: stur            x0, [fp, #-8]
    // 0x82cb94: r0 = LoadStaticField(0x47c)
    //     0x82cb94: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82cb98: ldr             x0, [x0, #0x8f8]
    // 0x82cb9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82cba0: cmp             w0, w16
    // 0x82cba4: b.ne            #0x82cbb0
    // 0x82cba8: r2 = _stackFilters
    //     0x82cba8: ldr             x2, [PP, #0xe30]  ; [pp+0xe30] Field <FlutterError._stackFilters@22022608>: static late final (offset: 0x47c)
    // 0x82cbac: r0 = InitLateFinalStaticField()
    //     0x82cbac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82cbb0: LoadField: r1 = r0->field_b
    //     0x82cbb0: ldur            w1, [x0, #0xb]
    // 0x82cbb4: r0 = LoadInt32Instr(r1)
    //     0x82cbb4: sbfx            x0, x1, #1, #0x1f
    // 0x82cbb8: cmp             x0, #0
    // 0x82cbbc: b.gt            #0x82d3d4
    // 0x82cbc0: ldur            x0, [fp, #-0x80]
    // 0x82cbc4: r1 = <String>
    //     0x82cbc4: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82cbc8: r2 = 0
    //     0x82cbc8: mov             x2, #0
    // 0x82cbcc: r0 = _GrowableList()
    //     0x82cbcc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x82cbd0: mov             x3, x0
    // 0x82cbd4: ldur            x2, [fp, #-0x80]
    // 0x82cbd8: stur            x3, [fp, #-0x28]
    // 0x82cbdc: sub             x4, x2, #1
    // 0x82cbe0: stur            x4, [fp, #-0x58]
    // 0x82cbe4: r7 = 0
    //     0x82cbe4: mov             x7, #0
    // 0x82cbe8: ldur            x6, [fp, #-0x30]
    // 0x82cbec: ldur            x5, [fp, #-8]
    // 0x82cbf0: stur            x7, [fp, #-0x50]
    // 0x82cbf4: CheckStackOverflow
    //     0x82cbf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82cbf8: cmp             SP, x16
    //     0x82cbfc: b.ls            #0x82d444
    // 0x82cc00: LoadField: r0 = r6->field_b
    //     0x82cc00: ldur            w0, [x6, #0xb]
    // 0x82cc04: r1 = LoadInt32Instr(r0)
    //     0x82cc04: sbfx            x1, x0, #1, #0x1f
    // 0x82cc08: cmp             x7, x1
    // 0x82cc0c: b.ge            #0x82ce68
    // 0x82cc10: mov             x8, x7
    // 0x82cc14: stur            x8, [fp, #-0x48]
    // 0x82cc18: CheckStackOverflow
    //     0x82cc18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82cc1c: cmp             SP, x16
    //     0x82cc20: b.ls            #0x82d44c
    // 0x82cc24: cmp             x8, x4
    // 0x82cc28: b.ge            #0x82ccb4
    // 0x82cc2c: mov             x0, x2
    // 0x82cc30: mov             x1, x8
    // 0x82cc34: cmp             x1, x0
    // 0x82cc38: b.hs            #0x82d454
    // 0x82cc3c: ArrayLoad: r9 = r5[r8]  ; Unknown_4
    //     0x82cc3c: add             x16, x5, x8, lsl #2
    //     0x82cc40: ldur            w9, [x16, #0xf]
    // 0x82cc44: DecompressPointer r9
    //     0x82cc44: add             x9, x9, HEAP, lsl #32
    // 0x82cc48: cmp             w9, NULL
    // 0x82cc4c: b.eq            #0x82ccb4
    // 0x82cc50: add             x10, x8, #1
    // 0x82cc54: mov             x0, x2
    // 0x82cc58: mov             x1, x10
    // 0x82cc5c: stur            x10, [fp, #-0x20]
    // 0x82cc60: cmp             x1, x0
    // 0x82cc64: b.hs            #0x82d458
    // 0x82cc68: ArrayLoad: r0 = r5[r10]  ; Unknown_4
    //     0x82cc68: add             x16, x5, x10, lsl #2
    //     0x82cc6c: ldur            w0, [x16, #0xf]
    // 0x82cc70: DecompressPointer r0
    //     0x82cc70: add             x0, x0, HEAP, lsl #32
    // 0x82cc74: r1 = LoadClassIdInstr(r0)
    //     0x82cc74: ldur            x1, [x0, #-1]
    //     0x82cc78: ubfx            x1, x1, #0xc, #0x14
    // 0x82cc7c: stp             x9, x0, [SP]
    // 0x82cc80: mov             x0, x1
    // 0x82cc84: mov             lr, x0
    // 0x82cc88: ldr             lr, [x21, lr, lsl #3]
    // 0x82cc8c: blr             lr
    // 0x82cc90: tbnz            w0, #4, #0x82ccb4
    // 0x82cc94: ldur            x8, [fp, #-0x20]
    // 0x82cc98: ldur            x6, [fp, #-0x30]
    // 0x82cc9c: ldur            x3, [fp, #-0x28]
    // 0x82cca0: ldur            x7, [fp, #-0x50]
    // 0x82cca4: ldur            x4, [fp, #-0x58]
    // 0x82cca8: ldur            x5, [fp, #-8]
    // 0x82ccac: ldur            x2, [fp, #-0x80]
    // 0x82ccb0: b               #0x82cc14
    // 0x82ccb4: ldur            x4, [fp, #-0x48]
    // 0x82ccb8: ldur            x3, [fp, #-8]
    // 0x82ccbc: ldur            x0, [fp, #-0x80]
    // 0x82ccc0: mov             x1, x4
    // 0x82ccc4: cmp             x1, x0
    // 0x82ccc8: b.hs            #0x82d45c
    // 0x82cccc: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0x82cccc: add             x16, x3, x4, lsl #2
    //     0x82ccd0: ldur            w0, [x16, #0xf]
    // 0x82ccd4: DecompressPointer r0
    //     0x82ccd4: add             x0, x0, HEAP, lsl #32
    // 0x82ccd8: cmp             w0, NULL
    // 0x82ccdc: b.eq            #0x82cd38
    // 0x82cce0: ldur            x0, [fp, #-0x50]
    // 0x82cce4: cmp             x4, x0
    // 0x82cce8: b.eq            #0x82cd2c
    // 0x82ccec: r1 = Null
    //     0x82ccec: mov             x1, NULL
    // 0x82ccf0: r2 = 6
    //     0x82ccf0: mov             x2, #6
    // 0x82ccf4: r0 = AllocateArray()
    //     0x82ccf4: bl              #0x13df928  ; AllocateArrayStub
    // 0x82ccf8: r16 = " ("
    //     0x82ccf8: ldr             x16, [PP, #0xe38]  ; [pp+0xe38] " ("
    // 0x82ccfc: StoreField: r0->field_f = r16
    //     0x82ccfc: stur            w16, [x0, #0xf]
    // 0x82cd00: ldur            x2, [fp, #-0x50]
    // 0x82cd04: ldur            x1, [fp, #-0x48]
    // 0x82cd08: sub             x3, x1, x2
    // 0x82cd0c: add             x2, x3, #2
    // 0x82cd10: lsl             x3, x2, #1
    // 0x82cd14: StoreField: r0->field_13 = r3
    //     0x82cd14: stur            w3, [x0, #0x13]
    // 0x82cd18: r16 = " frames)"
    //     0x82cd18: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] " frames)"
    // 0x82cd1c: ArrayStore: r0[0] = r16  ; List_4
    //     0x82cd1c: stur            w16, [x0, #0x17]
    // 0x82cd20: str             x0, [SP]
    // 0x82cd24: r0 = _interpolate()
    //     0x82cd24: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82cd28: b               #0x82cd30
    // 0x82cd2c: r0 = " (1 frame)"
    //     0x82cd2c: ldr             x0, [PP, #0xe48]  ; [pp+0xe48] " (1 frame)"
    // 0x82cd30: mov             x5, x0
    // 0x82cd34: b               #0x82cd3c
    // 0x82cd38: r5 = ""
    //     0x82cd38: ldr             x5, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82cd3c: ldur            x3, [fp, #-0x48]
    // 0x82cd40: ldur            x4, [fp, #-8]
    // 0x82cd44: stur            x5, [fp, #-0x40]
    // 0x82cd48: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0x82cd48: add             x16, x4, x3, lsl #2
    //     0x82cd4c: ldur            w0, [x16, #0xf]
    // 0x82cd50: DecompressPointer r0
    //     0x82cd50: add             x0, x0, HEAP, lsl #32
    // 0x82cd54: cmp             w0, NULL
    // 0x82cd58: b.ne            #0x82cd9c
    // 0x82cd5c: ldur            x6, [fp, #-0x30]
    // 0x82cd60: LoadField: r0 = r6->field_b
    //     0x82cd60: ldur            w0, [x6, #0xb]
    // 0x82cd64: r1 = LoadInt32Instr(r0)
    //     0x82cd64: sbfx            x1, x0, #1, #0x1f
    // 0x82cd68: mov             x0, x1
    // 0x82cd6c: mov             x1, x3
    // 0x82cd70: cmp             x1, x0
    // 0x82cd74: b.hs            #0x82d460
    // 0x82cd78: LoadField: r0 = r6->field_f
    //     0x82cd78: ldur            w0, [x6, #0xf]
    // 0x82cd7c: DecompressPointer r0
    //     0x82cd7c: add             x0, x0, HEAP, lsl #32
    // 0x82cd80: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x82cd80: add             x16, x0, x3, lsl #2
    //     0x82cd84: ldur            w1, [x16, #0xf]
    // 0x82cd88: DecompressPointer r1
    //     0x82cd88: add             x1, x1, HEAP, lsl #32
    // 0x82cd8c: LoadField: r0 = r1->field_7
    //     0x82cd8c: ldur            w0, [x1, #7]
    // 0x82cd90: DecompressPointer r0
    //     0x82cd90: add             x0, x0, HEAP, lsl #32
    // 0x82cd94: mov             x7, x0
    // 0x82cd98: b               #0x82cda4
    // 0x82cd9c: ldur            x6, [fp, #-0x30]
    // 0x82cda0: mov             x7, x0
    // 0x82cda4: ldur            x0, [fp, #-0x28]
    // 0x82cda8: stur            x7, [fp, #-0x38]
    // 0x82cdac: r1 = Null
    //     0x82cdac: mov             x1, NULL
    // 0x82cdb0: r2 = 4
    //     0x82cdb0: mov             x2, #4
    // 0x82cdb4: r0 = AllocateArray()
    //     0x82cdb4: bl              #0x13df928  ; AllocateArrayStub
    // 0x82cdb8: mov             x1, x0
    // 0x82cdbc: ldur            x0, [fp, #-0x38]
    // 0x82cdc0: StoreField: r1->field_f = r0
    //     0x82cdc0: stur            w0, [x1, #0xf]
    // 0x82cdc4: ldur            x0, [fp, #-0x40]
    // 0x82cdc8: StoreField: r1->field_13 = r0
    //     0x82cdc8: stur            w0, [x1, #0x13]
    // 0x82cdcc: str             x1, [SP]
    // 0x82cdd0: r0 = _interpolate()
    //     0x82cdd0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82cdd4: mov             x2, x0
    // 0x82cdd8: ldur            x0, [fp, #-0x28]
    // 0x82cddc: stur            x2, [fp, #-0x38]
    // 0x82cde0: LoadField: r1 = r0->field_b
    //     0x82cde0: ldur            w1, [x0, #0xb]
    // 0x82cde4: LoadField: r3 = r0->field_f
    //     0x82cde4: ldur            w3, [x0, #0xf]
    // 0x82cde8: DecompressPointer r3
    //     0x82cde8: add             x3, x3, HEAP, lsl #32
    // 0x82cdec: LoadField: r4 = r3->field_b
    //     0x82cdec: ldur            w4, [x3, #0xb]
    // 0x82cdf0: r3 = LoadInt32Instr(r1)
    //     0x82cdf0: sbfx            x3, x1, #1, #0x1f
    // 0x82cdf4: stur            x3, [fp, #-0x20]
    // 0x82cdf8: r1 = LoadInt32Instr(r4)
    //     0x82cdf8: sbfx            x1, x4, #1, #0x1f
    // 0x82cdfc: cmp             x3, x1
    // 0x82ce00: b.ne            #0x82ce0c
    // 0x82ce04: mov             x1, x0
    // 0x82ce08: r0 = _growToNextCapacity()
    //     0x82ce08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82ce0c: ldur            x3, [fp, #-0x28]
    // 0x82ce10: ldur            x4, [fp, #-0x48]
    // 0x82ce14: ldur            x2, [fp, #-0x20]
    // 0x82ce18: add             x0, x2, #1
    // 0x82ce1c: lsl             x1, x0, #1
    // 0x82ce20: StoreField: r3->field_b = r1
    //     0x82ce20: stur            w1, [x3, #0xb]
    // 0x82ce24: LoadField: r1 = r3->field_f
    //     0x82ce24: ldur            w1, [x3, #0xf]
    // 0x82ce28: DecompressPointer r1
    //     0x82ce28: add             x1, x1, HEAP, lsl #32
    // 0x82ce2c: ldur            x0, [fp, #-0x38]
    // 0x82ce30: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82ce30: add             x25, x1, x2, lsl #2
    //     0x82ce34: add             x25, x25, #0xf
    //     0x82ce38: str             w0, [x25]
    //     0x82ce3c: tbz             w0, #0, #0x82ce58
    //     0x82ce40: ldurb           w16, [x1, #-1]
    //     0x82ce44: ldurb           w17, [x0, #-1]
    //     0x82ce48: and             x16, x17, x16, lsr #2
    //     0x82ce4c: tst             x16, HEAP, lsr #32
    //     0x82ce50: b.eq            #0x82ce58
    //     0x82ce54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82ce58: add             x7, x4, #1
    // 0x82ce5c: ldur            x4, [fp, #-0x58]
    // 0x82ce60: ldur            x2, [fp, #-0x80]
    // 0x82ce64: b               #0x82cbe8
    // 0x82ce68: r1 = <String>
    //     0x82ce68: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82ce6c: r2 = 0
    //     0x82ce6c: mov             x2, #0
    // 0x82ce70: r0 = _GrowableList()
    //     0x82ce70: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x82ce74: ldur            x1, [fp, #-0x10]
    // 0x82ce78: stur            x0, [fp, #-8]
    // 0x82ce7c: r0 = entries()
    //     0x82ce7c: bl              #0x1285334  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::entries
    // 0x82ce80: mov             x1, x0
    // 0x82ce84: r0 = iterator()
    //     0x82ce84: bl              #0xb09bdc  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x82ce88: stur            x0, [fp, #-0x10]
    // 0x82ce8c: ldur            x2, [fp, #-8]
    // 0x82ce90: CheckStackOverflow
    //     0x82ce90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ce94: cmp             SP, x16
    //     0x82ce98: b.ls            #0x82d464
    // 0x82ce9c: mov             x1, x0
    // 0x82cea0: r0 = moveNext()
    //     0x82cea0: bl              #0x80261c  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x82cea4: tbnz            w0, #4, #0x82cf88
    // 0x82cea8: ldur            x1, [fp, #-0x10]
    // 0x82ceac: LoadField: r2 = r1->field_2b
    //     0x82ceac: ldur            w2, [x1, #0x2b]
    // 0x82ceb0: DecompressPointer r2
    //     0x82ceb0: add             x2, x2, HEAP, lsl #32
    // 0x82ceb4: stur            x2, [fp, #-0x30]
    // 0x82ceb8: cmp             w2, NULL
    // 0x82cebc: b.eq            #0x82d3c8
    // 0x82cec0: LoadField: r0 = r2->field_f
    //     0x82cec0: ldur            w0, [x2, #0xf]
    // 0x82cec4: DecompressPointer r0
    //     0x82cec4: add             x0, x0, HEAP, lsl #32
    // 0x82cec8: r3 = 60
    //     0x82cec8: mov             x3, #0x3c
    // 0x82cecc: branchIfSmi(r0, 0x82ced8)
    //     0x82cecc: tbz             w0, #0, #0x82ced8
    // 0x82ced0: r3 = LoadClassIdInstr(r0)
    //     0x82ced0: ldur            x3, [x0, #-1]
    //     0x82ced4: ubfx            x3, x3, #0xc, #0x14
    // 0x82ced8: stp             xzr, x0, [SP]
    // 0x82cedc: mov             x0, x3
    // 0x82cee0: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x82cee0: sub             lr, x0, #0xfe5
    //     0x82cee4: ldr             lr, [x21, lr, lsl #3]
    //     0x82cee8: blr             lr
    // 0x82ceec: tbnz            w0, #4, #0x82cf7c
    // 0x82cef0: ldur            x2, [fp, #-8]
    // 0x82cef4: ldur            x0, [fp, #-0x30]
    // 0x82cef8: LoadField: r3 = r0->field_b
    //     0x82cef8: ldur            w3, [x0, #0xb]
    // 0x82cefc: DecompressPointer r3
    //     0x82cefc: add             x3, x3, HEAP, lsl #32
    // 0x82cf00: stur            x3, [fp, #-0x38]
    // 0x82cf04: LoadField: r0 = r2->field_b
    //     0x82cf04: ldur            w0, [x2, #0xb]
    // 0x82cf08: LoadField: r1 = r2->field_f
    //     0x82cf08: ldur            w1, [x2, #0xf]
    // 0x82cf0c: DecompressPointer r1
    //     0x82cf0c: add             x1, x1, HEAP, lsl #32
    // 0x82cf10: LoadField: r4 = r1->field_b
    //     0x82cf10: ldur            w4, [x1, #0xb]
    // 0x82cf14: r5 = LoadInt32Instr(r0)
    //     0x82cf14: sbfx            x5, x0, #1, #0x1f
    // 0x82cf18: stur            x5, [fp, #-0x20]
    // 0x82cf1c: r0 = LoadInt32Instr(r4)
    //     0x82cf1c: sbfx            x0, x4, #1, #0x1f
    // 0x82cf20: cmp             x5, x0
    // 0x82cf24: b.ne            #0x82cf30
    // 0x82cf28: mov             x1, x2
    // 0x82cf2c: r0 = _growToNextCapacity()
    //     0x82cf2c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82cf30: ldur            x2, [fp, #-8]
    // 0x82cf34: ldur            x3, [fp, #-0x20]
    // 0x82cf38: add             x0, x3, #1
    // 0x82cf3c: lsl             x1, x0, #1
    // 0x82cf40: StoreField: r2->field_b = r1
    //     0x82cf40: stur            w1, [x2, #0xb]
    // 0x82cf44: LoadField: r1 = r2->field_f
    //     0x82cf44: ldur            w1, [x2, #0xf]
    // 0x82cf48: DecompressPointer r1
    //     0x82cf48: add             x1, x1, HEAP, lsl #32
    // 0x82cf4c: ldur            x0, [fp, #-0x38]
    // 0x82cf50: ArrayStore: r1[r3] = r0  ; List_4
    //     0x82cf50: add             x25, x1, x3, lsl #2
    //     0x82cf54: add             x25, x25, #0xf
    //     0x82cf58: str             w0, [x25]
    //     0x82cf5c: tbz             w0, #0, #0x82cf78
    //     0x82cf60: ldurb           w16, [x1, #-1]
    //     0x82cf64: ldurb           w17, [x0, #-1]
    //     0x82cf68: and             x16, x17, x16, lsr #2
    //     0x82cf6c: tst             x16, HEAP, lsr #32
    //     0x82cf70: b.eq            #0x82cf78
    //     0x82cf74: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82cf78: b               #0x82cf80
    // 0x82cf7c: ldur            x2, [fp, #-8]
    // 0x82cf80: ldur            x0, [fp, #-0x10]
    // 0x82cf84: b               #0x82ce90
    // 0x82cf88: ldur            x0, [fp, #-0x18]
    // 0x82cf8c: ldur            x2, [fp, #-8]
    // 0x82cf90: mov             x1, x2
    // 0x82cf94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82cf94: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82cf98: r0 = sort()
    //     0x82cf98: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x82cf9c: ldur            x0, [fp, #-0x18]
    // 0x82cfa0: cmp             x0, #1
    // 0x82cfa4: b.ne            #0x82d090
    // 0x82cfa8: ldur            x0, [fp, #-0x28]
    // 0x82cfac: r1 = Null
    //     0x82cfac: mov             x1, NULL
    // 0x82cfb0: r2 = 6
    //     0x82cfb0: mov             x2, #6
    // 0x82cfb4: r0 = AllocateArray()
    //     0x82cfb4: bl              #0x13df928  ; AllocateArrayStub
    // 0x82cfb8: stur            x0, [fp, #-0x10]
    // 0x82cfbc: r16 = "(elided one frame from "
    //     0x82cfbc: ldr             x16, [PP, #0xe58]  ; [pp+0xe58] "(elided one frame from "
    // 0x82cfc0: StoreField: r0->field_f = r16
    //     0x82cfc0: stur            w16, [x0, #0xf]
    // 0x82cfc4: ldur            x1, [fp, #-8]
    // 0x82cfc8: r0 = single()
    //     0x82cfc8: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0x82cfcc: ldur            x1, [fp, #-0x10]
    // 0x82cfd0: ArrayStore: r1[1] = r0  ; List_4
    //     0x82cfd0: add             x25, x1, #0x13
    //     0x82cfd4: str             w0, [x25]
    //     0x82cfd8: tbz             w0, #0, #0x82cff4
    //     0x82cfdc: ldurb           w16, [x1, #-1]
    //     0x82cfe0: ldurb           w17, [x0, #-1]
    //     0x82cfe4: and             x16, x17, x16, lsr #2
    //     0x82cfe8: tst             x16, HEAP, lsr #32
    //     0x82cfec: b.eq            #0x82cff4
    //     0x82cff0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82cff4: ldur            x0, [fp, #-0x10]
    // 0x82cff8: r16 = ")"
    //     0x82cff8: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x82cffc: ArrayStore: r0[0] = r16  ; List_4
    //     0x82cffc: stur            w16, [x0, #0x17]
    // 0x82d000: str             x0, [SP]
    // 0x82d004: r0 = _interpolate()
    //     0x82d004: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82d008: mov             x2, x0
    // 0x82d00c: ldur            x0, [fp, #-0x28]
    // 0x82d010: stur            x2, [fp, #-0x10]
    // 0x82d014: LoadField: r1 = r0->field_b
    //     0x82d014: ldur            w1, [x0, #0xb]
    // 0x82d018: LoadField: r3 = r0->field_f
    //     0x82d018: ldur            w3, [x0, #0xf]
    // 0x82d01c: DecompressPointer r3
    //     0x82d01c: add             x3, x3, HEAP, lsl #32
    // 0x82d020: LoadField: r4 = r3->field_b
    //     0x82d020: ldur            w4, [x3, #0xb]
    // 0x82d024: r3 = LoadInt32Instr(r1)
    //     0x82d024: sbfx            x3, x1, #1, #0x1f
    // 0x82d028: stur            x3, [fp, #-0x20]
    // 0x82d02c: r1 = LoadInt32Instr(r4)
    //     0x82d02c: sbfx            x1, x4, #1, #0x1f
    // 0x82d030: cmp             x3, x1
    // 0x82d034: b.ne            #0x82d040
    // 0x82d038: mov             x1, x0
    // 0x82d03c: r0 = _growToNextCapacity()
    //     0x82d03c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82d040: ldur            x3, [fp, #-0x28]
    // 0x82d044: ldur            x2, [fp, #-0x20]
    // 0x82d048: add             x0, x2, #1
    // 0x82d04c: lsl             x1, x0, #1
    // 0x82d050: StoreField: r3->field_b = r1
    //     0x82d050: stur            w1, [x3, #0xb]
    // 0x82d054: LoadField: r1 = r3->field_f
    //     0x82d054: ldur            w1, [x3, #0xf]
    // 0x82d058: DecompressPointer r1
    //     0x82d058: add             x1, x1, HEAP, lsl #32
    // 0x82d05c: ldur            x0, [fp, #-0x10]
    // 0x82d060: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82d060: add             x25, x1, x2, lsl #2
    //     0x82d064: add             x25, x25, #0xf
    //     0x82d068: str             w0, [x25]
    //     0x82d06c: tbz             w0, #0, #0x82d088
    //     0x82d070: ldurb           w16, [x1, #-1]
    //     0x82d074: ldurb           w17, [x0, #-1]
    //     0x82d078: and             x16, x17, x16, lsr #2
    //     0x82d07c: tst             x16, HEAP, lsr #32
    //     0x82d080: b.eq            #0x82d088
    //     0x82d084: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d088: mov             x2, x3
    // 0x82d08c: b               #0x82d3b8
    // 0x82d090: ldur            x3, [fp, #-0x28]
    // 0x82d094: cmp             x0, #1
    // 0x82d098: b.le            #0x82d3b4
    // 0x82d09c: ldur            x4, [fp, #-8]
    // 0x82d0a0: LoadField: r1 = r4->field_b
    //     0x82d0a0: ldur            w1, [x4, #0xb]
    // 0x82d0a4: r2 = LoadInt32Instr(r1)
    //     0x82d0a4: sbfx            x2, x1, #1, #0x1f
    // 0x82d0a8: cmp             x2, #1
    // 0x82d0ac: b.le            #0x82d168
    // 0x82d0b0: sub             x5, x2, #1
    // 0x82d0b4: stur            x5, [fp, #-0x20]
    // 0x82d0b8: r1 = Null
    //     0x82d0b8: mov             x1, NULL
    // 0x82d0bc: r2 = 4
    //     0x82d0bc: mov             x2, #4
    // 0x82d0c0: r0 = AllocateArray()
    //     0x82d0c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x82d0c4: stur            x0, [fp, #-0x10]
    // 0x82d0c8: r16 = "and "
    //     0x82d0c8: ldr             x16, [PP, #0xe68]  ; [pp+0xe68] "and "
    // 0x82d0cc: StoreField: r0->field_f = r16
    //     0x82d0cc: stur            w16, [x0, #0xf]
    // 0x82d0d0: ldur            x1, [fp, #-8]
    // 0x82d0d4: r0 = last()
    //     0x82d0d4: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0x82d0d8: ldur            x1, [fp, #-0x10]
    // 0x82d0dc: ArrayStore: r1[1] = r0  ; List_4
    //     0x82d0dc: add             x25, x1, #0x13
    //     0x82d0e0: str             w0, [x25]
    //     0x82d0e4: tbz             w0, #0, #0x82d100
    //     0x82d0e8: ldurb           w16, [x1, #-1]
    //     0x82d0ec: ldurb           w17, [x0, #-1]
    //     0x82d0f0: and             x16, x17, x16, lsr #2
    //     0x82d0f4: tst             x16, HEAP, lsr #32
    //     0x82d0f8: b.eq            #0x82d100
    //     0x82d0fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d100: ldur            x16, [fp, #-0x10]
    // 0x82d104: str             x16, [SP]
    // 0x82d108: r0 = _interpolate()
    //     0x82d108: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82d10c: mov             x2, x0
    // 0x82d110: ldur            x3, [fp, #-8]
    // 0x82d114: LoadField: r4 = r3->field_b
    //     0x82d114: ldur            w4, [x3, #0xb]
    // 0x82d118: r0 = LoadInt32Instr(r4)
    //     0x82d118: sbfx            x0, x4, #1, #0x1f
    // 0x82d11c: ldur            x1, [fp, #-0x20]
    // 0x82d120: cmp             x1, x0
    // 0x82d124: b.hs            #0x82d46c
    // 0x82d128: LoadField: r1 = r3->field_f
    //     0x82d128: ldur            w1, [x3, #0xf]
    // 0x82d12c: DecompressPointer r1
    //     0x82d12c: add             x1, x1, HEAP, lsl #32
    // 0x82d130: mov             x0, x2
    // 0x82d134: ldur            x2, [fp, #-0x20]
    // 0x82d138: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82d138: add             x25, x1, x2, lsl #2
    //     0x82d13c: add             x25, x25, #0xf
    //     0x82d140: str             w0, [x25]
    //     0x82d144: tbz             w0, #0, #0x82d160
    //     0x82d148: ldurb           w16, [x1, #-1]
    //     0x82d14c: ldurb           w17, [x0, #-1]
    //     0x82d150: and             x16, x17, x16, lsr #2
    //     0x82d154: tst             x16, HEAP, lsr #32
    //     0x82d158: b.eq            #0x82d160
    //     0x82d15c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d160: r0 = LoadInt32Instr(r4)
    //     0x82d160: sbfx            x0, x4, #1, #0x1f
    // 0x82d164: b               #0x82d170
    // 0x82d168: mov             x3, x4
    // 0x82d16c: r0 = LoadInt32Instr(r1)
    //     0x82d16c: sbfx            x0, x1, #1, #0x1f
    // 0x82d170: cmp             x0, #2
    // 0x82d174: b.le            #0x82d298
    // 0x82d178: ldur            x0, [fp, #-0x18]
    // 0x82d17c: ldur            x4, [fp, #-0x28]
    // 0x82d180: r1 = Null
    //     0x82d180: mov             x1, NULL
    // 0x82d184: r2 = 10
    //     0x82d184: mov             x2, #0xa
    // 0x82d188: r0 = AllocateArray()
    //     0x82d188: bl              #0x13df928  ; AllocateArrayStub
    // 0x82d18c: mov             x2, x0
    // 0x82d190: stur            x2, [fp, #-0x10]
    // 0x82d194: r16 = "(elided "
    //     0x82d194: ldr             x16, [PP, #0xe70]  ; [pp+0xe70] "(elided "
    // 0x82d198: StoreField: r2->field_f = r16
    //     0x82d198: stur            w16, [x2, #0xf]
    // 0x82d19c: ldur            x3, [fp, #-0x18]
    // 0x82d1a0: r0 = BoxInt64Instr(r3)
    //     0x82d1a0: sbfiz           x0, x3, #1, #0x1f
    //     0x82d1a4: cmp             x3, x0, asr #1
    //     0x82d1a8: b.eq            #0x82d1b4
    //     0x82d1ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82d1b0: stur            x3, [x0, #7]
    // 0x82d1b4: StoreField: r2->field_13 = r0
    //     0x82d1b4: stur            w0, [x2, #0x13]
    // 0x82d1b8: r16 = " frames from "
    //     0x82d1b8: ldr             x16, [PP, #0xe78]  ; [pp+0xe78] " frames from "
    // 0x82d1bc: ArrayStore: r2[0] = r16  ; List_4
    //     0x82d1bc: stur            w16, [x2, #0x17]
    // 0x82d1c0: r16 = ", "
    //     0x82d1c0: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0x82d1c4: str             x16, [SP]
    // 0x82d1c8: ldur            x1, [fp, #-8]
    // 0x82d1cc: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x82d1cc: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x82d1d0: r0 = join()
    //     0x82d1d0: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x82d1d4: ldur            x1, [fp, #-0x10]
    // 0x82d1d8: ArrayStore: r1[3] = r0  ; List_4
    //     0x82d1d8: add             x25, x1, #0x1b
    //     0x82d1dc: str             w0, [x25]
    //     0x82d1e0: tbz             w0, #0, #0x82d1fc
    //     0x82d1e4: ldurb           w16, [x1, #-1]
    //     0x82d1e8: ldurb           w17, [x0, #-1]
    //     0x82d1ec: and             x16, x17, x16, lsr #2
    //     0x82d1f0: tst             x16, HEAP, lsr #32
    //     0x82d1f4: b.eq            #0x82d1fc
    //     0x82d1f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d1fc: ldur            x0, [fp, #-0x10]
    // 0x82d200: r16 = ")"
    //     0x82d200: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x82d204: StoreField: r0->field_1f = r16
    //     0x82d204: stur            w16, [x0, #0x1f]
    // 0x82d208: str             x0, [SP]
    // 0x82d20c: r0 = _interpolate()
    //     0x82d20c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82d210: mov             x2, x0
    // 0x82d214: ldur            x0, [fp, #-0x28]
    // 0x82d218: stur            x2, [fp, #-0x10]
    // 0x82d21c: LoadField: r1 = r0->field_b
    //     0x82d21c: ldur            w1, [x0, #0xb]
    // 0x82d220: LoadField: r3 = r0->field_f
    //     0x82d220: ldur            w3, [x0, #0xf]
    // 0x82d224: DecompressPointer r3
    //     0x82d224: add             x3, x3, HEAP, lsl #32
    // 0x82d228: LoadField: r4 = r3->field_b
    //     0x82d228: ldur            w4, [x3, #0xb]
    // 0x82d22c: r3 = LoadInt32Instr(r1)
    //     0x82d22c: sbfx            x3, x1, #1, #0x1f
    // 0x82d230: stur            x3, [fp, #-0x20]
    // 0x82d234: r1 = LoadInt32Instr(r4)
    //     0x82d234: sbfx            x1, x4, #1, #0x1f
    // 0x82d238: cmp             x3, x1
    // 0x82d23c: b.ne            #0x82d248
    // 0x82d240: mov             x1, x0
    // 0x82d244: r0 = _growToNextCapacity()
    //     0x82d244: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82d248: ldur            x4, [fp, #-0x28]
    // 0x82d24c: ldur            x2, [fp, #-0x20]
    // 0x82d250: add             x0, x2, #1
    // 0x82d254: lsl             x1, x0, #1
    // 0x82d258: StoreField: r4->field_b = r1
    //     0x82d258: stur            w1, [x4, #0xb]
    // 0x82d25c: LoadField: r1 = r4->field_f
    //     0x82d25c: ldur            w1, [x4, #0xf]
    // 0x82d260: DecompressPointer r1
    //     0x82d260: add             x1, x1, HEAP, lsl #32
    // 0x82d264: ldur            x0, [fp, #-0x10]
    // 0x82d268: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82d268: add             x25, x1, x2, lsl #2
    //     0x82d26c: add             x25, x25, #0xf
    //     0x82d270: str             w0, [x25]
    //     0x82d274: tbz             w0, #0, #0x82d290
    //     0x82d278: ldurb           w16, [x1, #-1]
    //     0x82d27c: ldurb           w17, [x0, #-1]
    //     0x82d280: and             x16, x17, x16, lsr #2
    //     0x82d284: tst             x16, HEAP, lsr #32
    //     0x82d288: b.eq            #0x82d290
    //     0x82d28c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d290: mov             x2, x4
    // 0x82d294: b               #0x82d3b8
    // 0x82d298: ldur            x3, [fp, #-0x18]
    // 0x82d29c: ldur            x4, [fp, #-0x28]
    // 0x82d2a0: r1 = Null
    //     0x82d2a0: mov             x1, NULL
    // 0x82d2a4: r2 = 10
    //     0x82d2a4: mov             x2, #0xa
    // 0x82d2a8: r0 = AllocateArray()
    //     0x82d2a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x82d2ac: mov             x2, x0
    // 0x82d2b0: stur            x2, [fp, #-0x10]
    // 0x82d2b4: r16 = "(elided "
    //     0x82d2b4: ldr             x16, [PP, #0xe70]  ; [pp+0xe70] "(elided "
    // 0x82d2b8: StoreField: r2->field_f = r16
    //     0x82d2b8: stur            w16, [x2, #0xf]
    // 0x82d2bc: ldur            x3, [fp, #-0x18]
    // 0x82d2c0: r0 = BoxInt64Instr(r3)
    //     0x82d2c0: sbfiz           x0, x3, #1, #0x1f
    //     0x82d2c4: cmp             x3, x0, asr #1
    //     0x82d2c8: b.eq            #0x82d2d4
    //     0x82d2cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82d2d0: stur            x3, [x0, #7]
    // 0x82d2d4: StoreField: r2->field_13 = r0
    //     0x82d2d4: stur            w0, [x2, #0x13]
    // 0x82d2d8: r16 = " frames from "
    //     0x82d2d8: ldr             x16, [PP, #0xe78]  ; [pp+0xe78] " frames from "
    // 0x82d2dc: ArrayStore: r2[0] = r16  ; List_4
    //     0x82d2dc: stur            w16, [x2, #0x17]
    // 0x82d2e0: r16 = " "
    //     0x82d2e0: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82d2e4: str             x16, [SP]
    // 0x82d2e8: ldur            x1, [fp, #-8]
    // 0x82d2ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x82d2ec: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x82d2f0: r0 = join()
    //     0x82d2f0: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0x82d2f4: ldur            x1, [fp, #-0x10]
    // 0x82d2f8: ArrayStore: r1[3] = r0  ; List_4
    //     0x82d2f8: add             x25, x1, #0x1b
    //     0x82d2fc: str             w0, [x25]
    //     0x82d300: tbz             w0, #0, #0x82d31c
    //     0x82d304: ldurb           w16, [x1, #-1]
    //     0x82d308: ldurb           w17, [x0, #-1]
    //     0x82d30c: and             x16, x17, x16, lsr #2
    //     0x82d310: tst             x16, HEAP, lsr #32
    //     0x82d314: b.eq            #0x82d31c
    //     0x82d318: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d31c: ldur            x0, [fp, #-0x10]
    // 0x82d320: r16 = ")"
    //     0x82d320: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x82d324: StoreField: r0->field_1f = r16
    //     0x82d324: stur            w16, [x0, #0x1f]
    // 0x82d328: str             x0, [SP]
    // 0x82d32c: r0 = _interpolate()
    //     0x82d32c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x82d330: mov             x2, x0
    // 0x82d334: ldur            x0, [fp, #-0x28]
    // 0x82d338: stur            x2, [fp, #-8]
    // 0x82d33c: LoadField: r1 = r0->field_b
    //     0x82d33c: ldur            w1, [x0, #0xb]
    // 0x82d340: LoadField: r3 = r0->field_f
    //     0x82d340: ldur            w3, [x0, #0xf]
    // 0x82d344: DecompressPointer r3
    //     0x82d344: add             x3, x3, HEAP, lsl #32
    // 0x82d348: LoadField: r4 = r3->field_b
    //     0x82d348: ldur            w4, [x3, #0xb]
    // 0x82d34c: r3 = LoadInt32Instr(r1)
    //     0x82d34c: sbfx            x3, x1, #1, #0x1f
    // 0x82d350: stur            x3, [fp, #-0x18]
    // 0x82d354: r1 = LoadInt32Instr(r4)
    //     0x82d354: sbfx            x1, x4, #1, #0x1f
    // 0x82d358: cmp             x3, x1
    // 0x82d35c: b.ne            #0x82d368
    // 0x82d360: mov             x1, x0
    // 0x82d364: r0 = _growToNextCapacity()
    //     0x82d364: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82d368: ldur            x2, [fp, #-0x28]
    // 0x82d36c: ldur            x3, [fp, #-0x18]
    // 0x82d370: add             x0, x3, #1
    // 0x82d374: lsl             x1, x0, #1
    // 0x82d378: StoreField: r2->field_b = r1
    //     0x82d378: stur            w1, [x2, #0xb]
    // 0x82d37c: LoadField: r1 = r2->field_f
    //     0x82d37c: ldur            w1, [x2, #0xf]
    // 0x82d380: DecompressPointer r1
    //     0x82d380: add             x1, x1, HEAP, lsl #32
    // 0x82d384: ldur            x0, [fp, #-8]
    // 0x82d388: ArrayStore: r1[r3] = r0  ; List_4
    //     0x82d388: add             x25, x1, x3, lsl #2
    //     0x82d38c: add             x25, x25, #0xf
    //     0x82d390: str             w0, [x25]
    //     0x82d394: tbz             w0, #0, #0x82d3b0
    //     0x82d398: ldurb           w16, [x1, #-1]
    //     0x82d39c: ldurb           w17, [x0, #-1]
    //     0x82d3a0: and             x16, x17, x16, lsr #2
    //     0x82d3a4: tst             x16, HEAP, lsr #32
    //     0x82d3a8: b.eq            #0x82d3b0
    //     0x82d3ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82d3b0: b               #0x82d3b8
    // 0x82d3b4: mov             x2, x3
    // 0x82d3b8: mov             x0, x2
    // 0x82d3bc: LeaveFrame
    //     0x82d3bc: mov             SP, fp
    //     0x82d3c0: ldp             fp, lr, [SP], #0x10
    // 0x82d3c4: ret
    //     0x82d3c4: ret             
    // 0x82d3c8: r0 = noElement()
    //     0x82d3c8: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0x82d3cc: r0 = Throw()
    //     0x82d3cc: bl              #0x13ddb2c  ; ThrowStub
    // 0x82d3d0: brk             #0
    // 0x82d3d4: r1 = 0
    //     0x82d3d4: mov             x1, #0
    // 0x82d3d8: cmp             x1, x0
    // 0x82d3dc: b.hs            #0x82d470
    // 0x82d3e0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x82d3e0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x82d3e4: r0 = Throw()
    //     0x82d3e4: bl              #0x13ddb2c  ; ThrowStub
    // 0x82d3e8: brk             #0
    // 0x82d3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d3ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d3f0: b               #0x82c494
    // 0x82d3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d3f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d3f8: b               #0x82c578
    // 0x82d3fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d3fc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d404: b               #0x82c704
    // 0x82d408: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d408: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d40c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d40c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d414: b               #0x82c7f0
    // 0x82d418: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d418: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d41c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d41c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d420: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d420: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d428: b               #0x82c9a4
    // 0x82d42c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d42c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d430: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d430: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d438: b               #0x82ca90
    // 0x82d43c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d43c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d440: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d440: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d444: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d448: b               #0x82cc00
    // 0x82d44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d44c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d450: b               #0x82cc24
    // 0x82d454: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d454: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d458: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d458: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d45c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d45c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d460: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d460: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d468: b               #0x82ce9c
    // 0x82d46c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d46c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x82d470: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82d470: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static List<StackFilter> _stackFilters() {
    // ** addr: 0x82e260, size: 0x34
    // 0x82e260: EnterFrame
    //     0x82e260: stp             fp, lr, [SP, #-0x10]!
    //     0x82e264: mov             fp, SP
    // 0x82e268: CheckStackOverflow
    //     0x82e268: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82e26c: cmp             SP, x16
    //     0x82e270: b.ls            #0x82e28c
    // 0x82e274: r1 = <StackFilter>
    //     0x82e274: ldr             x1, [PP, #0x14b0]  ; [pp+0x14b0] TypeArguments: <StackFilter>
    // 0x82e278: r2 = 0
    //     0x82e278: mov             x2, #0
    // 0x82e27c: r0 = _GrowableList()
    //     0x82e27c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x82e280: LeaveFrame
    //     0x82e280: mov             SP, fp
    //     0x82e284: ldp             fp, lr, [SP], #0x10
    // 0x82e288: ret
    //     0x82e288: ret             
    // 0x82e28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82e28c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82e290: b               #0x82e274
  }
  [closure] static int <anonymous closure>(dynamic, int) {
    // ** addr: 0x82e2b0, size: 0x3c
    // 0x82e2b0: ldr             x2, [SP]
    // 0x82e2b4: r3 = LoadInt32Instr(r2)
    //     0x82e2b4: sbfx            x3, x2, #1, #0x1f
    //     0x82e2b8: tbz             w2, #0, #0x82e2c0
    //     0x82e2bc: ldur            x3, [x2, #7]
    // 0x82e2c0: add             x2, x3, #1
    // 0x82e2c4: r0 = BoxInt64Instr(r2)
    //     0x82e2c4: sbfiz           x0, x2, #1, #0x1f
    //     0x82e2c8: cmp             x2, x0, asr #1
    //     0x82e2cc: b.eq            #0x82e2e8
    //     0x82e2d0: stp             fp, lr, [SP, #-0x10]!
    //     0x82e2d4: mov             fp, SP
    //     0x82e2d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82e2dc: mov             SP, fp
    //     0x82e2e0: ldp             fp, lr, [SP], #0x10
    //     0x82e2e4: stur            x2, [x0, #7]
    // 0x82e2e8: ret
    //     0x82e2e8: ret             
  }
  static (dynamic, StackTrace) => StackTrace demangleStackTrace() {
    // ** addr: 0x82e54c, size: 0x8
    // 0x82e54c: r0 = Closure: (StackTrace) => StackTrace from Function '_defaultStackTraceDemangler@22022608': static.
    //     0x82e54c: ldr             x0, [PP, #0x14b8]  ; [pp+0x14b8] Closure: (StackTrace) => StackTrace from Function '_defaultStackTraceDemangler@22022608': static. (0x7f2adb2c1e90)
    // 0x82e550: ret
    //     0x82e550: ret             
  }
  static (dynamic, FlutterErrorDetails) => void presentError() {
    // ** addr: 0x82e554, size: 0x8
    // 0x82e554: r0 = Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static.
    //     0x82e554: ldr             x0, [PP, #0x888]  ; [pp+0x888] Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static. (0x7f2ada710d04)
    // 0x82e558: ret
    //     0x82e558: ret             
  }
  factory _ FlutterError(/* No info */) {
    // ** addr: 0x84eb60, size: 0x100
    // 0x84eb60: EnterFrame
    //     0x84eb60: stp             fp, lr, [SP, #-0x10]!
    //     0x84eb64: mov             fp, SP
    // 0x84eb68: AllocStack(0x30)
    //     0x84eb68: sub             SP, SP, #0x30
    // 0x84eb6c: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x84eb6c: mov             x0, x1
    //     0x84eb70: mov             x1, x2
    // 0x84eb74: CheckStackOverflow
    //     0x84eb74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84eb78: cmp             SP, x16
    //     0x84eb7c: b.ls            #0x84ec58
    // 0x84eb80: r0 = LoadClassIdInstr(r1)
    //     0x84eb80: ldur            x0, [x1, #-1]
    //     0x84eb84: ubfx            x0, x0, #0xc, #0x14
    // 0x84eb88: r2 = "\n"
    //     0x84eb88: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x84eb8c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x84eb8c: sub             lr, x0, #0xffe
    //     0x84eb90: ldr             lr, [x21, lr, lsl #3]
    //     0x84eb94: blr             lr
    // 0x84eb98: mov             x1, x0
    // 0x84eb9c: stur            x0, [fp, #-8]
    // 0x84eba0: r0 = first()
    //     0x84eba0: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0x84eba4: r1 = <List<Object>>
    //     0x84eba4: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x84eba8: stur            x0, [fp, #-0x10]
    // 0x84ebac: r0 = ErrorSummary()
    //     0x84ebac: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0x84ebb0: mov             x1, x0
    // 0x84ebb4: ldur            x2, [fp, #-0x10]
    // 0x84ebb8: r3 = Instance_DiagnosticLevel
    //     0x84ebb8: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0x84ebbc: stur            x0, [fp, #-0x10]
    // 0x84ebc0: r0 = _ErrorDiagnostic()
    //     0x84ebc0: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x84ebc4: r1 = Null
    //     0x84ebc4: mov             x1, NULL
    // 0x84ebc8: r2 = 2
    //     0x84ebc8: mov             x2, #2
    // 0x84ebcc: r0 = AllocateArray()
    //     0x84ebcc: bl              #0x13df928  ; AllocateArrayStub
    // 0x84ebd0: mov             x2, x0
    // 0x84ebd4: ldur            x0, [fp, #-0x10]
    // 0x84ebd8: stur            x2, [fp, #-0x18]
    // 0x84ebdc: StoreField: r2->field_f = r0
    //     0x84ebdc: stur            w0, [x2, #0xf]
    // 0x84ebe0: r1 = <DiagnosticsNode>
    //     0x84ebe0: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x84ebe4: r0 = AllocateGrowableArray()
    //     0x84ebe4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x84ebe8: mov             x3, x0
    // 0x84ebec: ldur            x0, [fp, #-0x18]
    // 0x84ebf0: stur            x3, [fp, #-0x10]
    // 0x84ebf4: StoreField: r3->field_f = r0
    //     0x84ebf4: stur            w0, [x3, #0xf]
    // 0x84ebf8: r0 = 2
    //     0x84ebf8: mov             x0, #2
    // 0x84ebfc: StoreField: r3->field_b = r0
    //     0x84ebfc: stur            w0, [x3, #0xb]
    // 0x84ec00: ldur            x1, [fp, #-8]
    // 0x84ec04: r2 = 1
    //     0x84ec04: mov             x2, #1
    // 0x84ec08: r0 = skip()
    //     0x84ec08: bl              #0xbb13c0  ; [dart:collection] ListBase::skip
    // 0x84ec0c: r1 = Function '<anonymous closure>': static.
    //     0x84ec0c: ldr             x1, [PP, #0x2680]  ; [pp+0x2680] AnonymousClosure: static (0x84ec60), in [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError (0x84eb60)
    // 0x84ec10: r2 = Null
    //     0x84ec10: mov             x2, NULL
    // 0x84ec14: stur            x0, [fp, #-8]
    // 0x84ec18: r0 = AllocateClosure()
    //     0x84ec18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84ec1c: r16 = <DiagnosticsNode>
    //     0x84ec1c: ldr             x16, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x84ec20: ldur            lr, [fp, #-8]
    // 0x84ec24: stp             lr, x16, [SP, #8]
    // 0x84ec28: str             x0, [SP]
    // 0x84ec2c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x84ec2c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x84ec30: r0 = map()
    //     0x84ec30: bl              #0xb00328  ; [dart:_internal] ListIterable::map
    // 0x84ec34: ldur            x1, [fp, #-0x10]
    // 0x84ec38: mov             x2, x0
    // 0x84ec3c: r0 = addAll()
    //     0x84ec3c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x84ec40: r0 = FlutterError()
    //     0x84ec40: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x84ec44: ldur            x1, [fp, #-0x10]
    // 0x84ec48: StoreField: r0->field_b = r1
    //     0x84ec48: stur            w1, [x0, #0xb]
    // 0x84ec4c: LeaveFrame
    //     0x84ec4c: mov             SP, fp
    //     0x84ec50: ldp             fp, lr, [SP], #0x10
    // 0x84ec54: ret
    //     0x84ec54: ret             
    // 0x84ec58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ec58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ec5c: b               #0x84eb80
  }
  [closure] static ErrorDescription <anonymous closure>(dynamic, String) {
    // ** addr: 0x84ec60, size: 0x4c
    // 0x84ec60: EnterFrame
    //     0x84ec60: stp             fp, lr, [SP, #-0x10]!
    //     0x84ec64: mov             fp, SP
    // 0x84ec68: AllocStack(0x8)
    //     0x84ec68: sub             SP, SP, #8
    // 0x84ec6c: CheckStackOverflow
    //     0x84ec6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ec70: cmp             SP, x16
    //     0x84ec74: b.ls            #0x84eca4
    // 0x84ec78: r1 = <List<Object>>
    //     0x84ec78: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x84ec7c: r0 = ErrorDescription()
    //     0x84ec7c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x84ec80: mov             x1, x0
    // 0x84ec84: ldr             x2, [fp, #0x10]
    // 0x84ec88: r3 = Instance_DiagnosticLevel
    //     0x84ec88: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x84ec8c: stur            x0, [fp, #-8]
    // 0x84ec90: r0 = _ErrorDiagnostic()
    //     0x84ec90: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x84ec94: ldur            x0, [fp, #-8]
    // 0x84ec98: LeaveFrame
    //     0x84ec98: mov             SP, fp
    //     0x84ec9c: ldp             fp, lr, [SP], #0x10
    // 0x84eca0: ret
    //     0x84eca0: ret             
    // 0x84eca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84eca4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84eca8: b               #0x84ec78
  }
  _ toString(/* No info */) {
    // ** addr: 0x10ffdf4, size: 0xb4
    // 0x10ffdf4: EnterFrame
    //     0x10ffdf4: stp             fp, lr, [SP, #-0x10]!
    //     0x10ffdf8: mov             fp, SP
    // 0x10ffdfc: AllocStack(0x18)
    //     0x10ffdfc: sub             SP, SP, #0x18
    // 0x10ffe00: SetupParameters(FlutterError this /* r0 */)
    //     0x10ffe00: ldur            w0, [x4, #0x13]
    //     0x10ffe04: sub             x1, x0, #2
    //     0x10ffe08: add             x0, fp, w1, sxtw #2
    //     0x10ffe0c: ldr             x0, [x0, #0x10]
    // 0x10ffe10: CheckStackOverflow
    //     0x10ffe10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ffe14: cmp             SP, x16
    //     0x10ffe18: b.ls            #0x10ffea0
    // 0x10ffe1c: LoadField: r1 = r0->field_b
    //     0x10ffe1c: ldur            w1, [x0, #0xb]
    // 0x10ffe20: DecompressPointer r1
    //     0x10ffe20: add             x1, x1, HEAP, lsl #32
    // 0x10ffe24: r16 = <_ErrorDiagnostic>
    //     0x10ffe24: add             x16, PP, #0xe, lsl #12  ; [pp+0xe368] TypeArguments: <_ErrorDiagnostic>
    //     0x10ffe28: ldr             x16, [x16, #0x368]
    // 0x10ffe2c: stp             x1, x16, [SP]
    // 0x10ffe30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x10ffe30: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x10ffe34: r0 = whereType()
    //     0x10ffe34: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x10ffe38: mov             x1, x0
    // 0x10ffe3c: stur            x0, [fp, #-8]
    // 0x10ffe40: r0 = iterator()
    //     0x10ffe40: bl              #0xb0a4d8  ; [dart:_internal] WhereTypeIterable::iterator
    // 0x10ffe44: r1 = LoadClassIdInstr(r0)
    //     0x10ffe44: ldur            x1, [x0, #-1]
    //     0x10ffe48: ubfx            x1, x1, #0xc, #0x14
    // 0x10ffe4c: mov             x16, x0
    // 0x10ffe50: mov             x0, x1
    // 0x10ffe54: mov             x1, x16
    // 0x10ffe58: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x10ffe58: mov             x17, #0x845b
    //     0x10ffe5c: movk            x17, #1, lsl #16
    //     0x10ffe60: add             lr, x0, x17
    //     0x10ffe64: ldr             lr, [x21, lr, lsl #3]
    //     0x10ffe68: blr             lr
    // 0x10ffe6c: eor             x1, x0, #0x10
    // 0x10ffe70: eor             x0, x1, #0x10
    // 0x10ffe74: tbnz            w0, #4, #0x10ffe8c
    // 0x10ffe78: ldur            x1, [fp, #-8]
    // 0x10ffe7c: r0 = first()
    //     0x10ffe7c: bl              #0xb07084  ; [dart:core] Iterable::first
    // 0x10ffe80: mov             x1, x0
    // 0x10ffe84: r0 = valueToString()
    //     0x10ffe84: bl              #0x10ffea8  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::valueToString
    // 0x10ffe88: b               #0x10ffe94
    // 0x10ffe8c: r0 = "FlutterError"
    //     0x10ffe8c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe370] "FlutterError"
    //     0x10ffe90: ldr             x0, [x0, #0x370]
    // 0x10ffe94: LeaveFrame
    //     0x10ffe94: mov             SP, fp
    //     0x10ffe98: ldp             fp, lr, [SP], #0x10
    // 0x10ffe9c: ret
    //     0x10ffe9c: ret             
    // 0x10ffea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ffea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ffea4: b               #0x10ffe1c
  }
  get _ message(/* No info */) {
    // ** addr: 0x1285214, size: 0x38
    // 0x1285214: EnterFrame
    //     0x1285214: stp             fp, lr, [SP, #-0x10]!
    //     0x1285218: mov             fp, SP
    // 0x128521c: AllocStack(0x8)
    //     0x128521c: sub             SP, SP, #8
    // 0x1285220: CheckStackOverflow
    //     0x1285220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1285224: cmp             SP, x16
    //     0x1285228: b.ls            #0x1285244
    // 0x128522c: str             x1, [SP]
    // 0x1285230: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x1285230: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x1285234: r0 = toString()
    //     0x1285234: bl              #0x10ffdf4  ; [package:flutter/src/foundation/assertions.dart] FlutterError::toString
    // 0x1285238: LeaveFrame
    //     0x1285238: mov             SP, fp
    //     0x128523c: ldp             fp, lr, [SP], #0x10
    // 0x1285240: ret
    //     0x1285240: ret             
    // 0x1285244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1285244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1285248: b               #0x128522c
  }
}
