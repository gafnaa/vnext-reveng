// lib: , url: package:flutter/src/foundation/serialization.dart

// class id: 1048811, size: 0x8
class :: {
}

// class id: 3188, size: 0x14, field offset: 0x8
class ReadBuffer extends Object {

  get _ hasRemaining(/* No info */) {
    // ** addr: 0xccecf8, size: 0x28
    // 0xccecf8: LoadField: r2 = r1->field_b
    //     0xccecf8: ldur            x2, [x1, #0xb]
    // 0xccecfc: LoadField: r3 = r1->field_7
    //     0xccecfc: ldur            w3, [x1, #7]
    // 0xcced00: DecompressPointer r3
    //     0xcced00: add             x3, x3, HEAP, lsl #32
    // 0xcced04: LoadField: r1 = r3->field_13
    //     0xcced04: ldur            w1, [x3, #0x13]
    // 0xcced08: r3 = LoadInt32Instr(r1)
    //     0xcced08: sbfx            x3, x1, #1, #0x1f
    // 0xcced0c: cmp             x2, x3
    // 0xcced10: r16 = true
    //     0xcced10: add             x16, NULL, #0x20  ; true
    // 0xcced14: r17 = false
    //     0xcced14: add             x17, NULL, #0x30  ; false
    // 0xcced18: csel            x0, x16, x17, lt
    // 0xcced1c: ret
    //     0xcced1c: ret             
  }
  _ getUint8(/* No info */) {
    // ** addr: 0xccedb8, size: 0x54
    // 0xccedb8: LoadField: r2 = r1->field_7
    //     0xccedb8: ldur            w2, [x1, #7]
    // 0xccedbc: DecompressPointer r2
    //     0xccedbc: add             x2, x2, HEAP, lsl #32
    // 0xccedc0: LoadField: r3 = r1->field_b
    //     0xccedc0: ldur            x3, [x1, #0xb]
    // 0xccedc4: add             x4, x3, #1
    // 0xccedc8: StoreField: r1->field_b = r4
    //     0xccedc8: stur            x4, [x1, #0xb]
    // 0xccedcc: LoadField: r4 = r2->field_13
    //     0xccedcc: ldur            w4, [x2, #0x13]
    // 0xccedd0: r0 = LoadInt32Instr(r4)
    //     0xccedd0: sbfx            x0, x4, #1, #0x1f
    // 0xccedd4: mov             x1, x3
    // 0xccedd8: cmp             x1, x0
    // 0xcceddc: b.hs            #0xccee00
    // 0xccede0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xccede0: ldur            w1, [x2, #0x17]
    // 0xccede4: DecompressPointer r1
    //     0xccede4: add             x1, x1, HEAP, lsl #32
    // 0xccede8: LoadField: r4 = r2->field_1b
    //     0xccede8: ldur            w4, [x2, #0x1b]
    // 0xccedec: r2 = LoadInt32Instr(r4)
    //     0xccedec: sbfx            x2, x4, #1, #0x1f
    // 0xccedf0: add             x4, x2, x3
    // 0xccedf4: LoadField: r2 = r1->field_7
    //     0xccedf4: ldur            x2, [x1, #7]
    // 0xccedf8: ldrb            w0, [x2, x4]
    // 0xccedfc: ret
    //     0xccedfc: ret             
    // 0xccee00: EnterFrame
    //     0xccee00: stp             fp, lr, [SP, #-0x10]!
    //     0xccee04: mov             fp, SP
    // 0xccee08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xccee08: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _alignTo(/* No info */) {
    // ** addr: 0xf2f648, size: 0x70
    // 0xf2f648: EnterFrame
    //     0xf2f648: stp             fp, lr, [SP, #-0x10]!
    //     0xf2f64c: mov             fp, SP
    // 0xf2f650: LoadField: r3 = r1->field_b
    //     0xf2f650: ldur            x3, [x1, #0xb]
    // 0xf2f654: cbz             x2, #0xf2f688
    // 0xf2f658: sdiv            x5, x3, x2
    // 0xf2f65c: msub            x4, x5, x2, x3
    // 0xf2f660: cmp             x4, xzr
    // 0xf2f664: b.lt            #0xf2f6a4
    // 0xf2f668: cbz             x4, #0xf2f678
    // 0xf2f66c: sub             x5, x2, x4
    // 0xf2f670: add             x2, x3, x5
    // 0xf2f674: StoreField: r1->field_b = r2
    //     0xf2f674: stur            x2, [x1, #0xb]
    // 0xf2f678: r0 = Null
    //     0xf2f678: mov             x0, NULL
    // 0xf2f67c: LeaveFrame
    //     0xf2f67c: mov             SP, fp
    //     0xf2f680: ldp             fp, lr, [SP], #0x10
    // 0xf2f684: ret
    //     0xf2f684: ret             
    // 0xf2f688: stp             x2, x3, [SP, #-0x10]!
    // 0xf2f68c: SaveReg r1
    //     0xf2f68c: str             x1, [SP, #-8]!
    // 0xf2f690: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xf2f694: r4 = 0
    //     0xf2f694: mov             x4, #0
    // 0xf2f698: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xf2f69c: blr             lr
    // 0xf2f6a0: brk             #0
    // 0xf2f6a4: cmp             x2, xzr
    // 0xf2f6a8: sub             x5, x4, x2
    // 0xf2f6ac: add             x4, x4, x2
    // 0xf2f6b0: csel            x4, x5, x4, lt
    // 0xf2f6b4: b               #0xf2f668
  }
  _ getUint8List(/* No info */) {
    // ** addr: 0xf30f40, size: 0xe0
    // 0xf30f40: EnterFrame
    //     0xf30f40: stp             fp, lr, [SP, #-0x10]!
    //     0xf30f44: mov             fp, SP
    // 0xf30f48: AllocStack(0x28)
    //     0xf30f48: sub             SP, SP, #0x28
    // 0xf30f4c: SetupParameters(ReadBuffer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xf30f4c: mov             x3, x1
    //     0xf30f50: stur            x1, [fp, #-0x10]
    //     0xf30f54: stur            x2, [fp, #-0x18]
    // 0xf30f58: CheckStackOverflow
    //     0xf30f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf30f5c: cmp             SP, x16
    //     0xf30f60: b.ls            #0xf31018
    // 0xf30f64: LoadField: r4 = r3->field_7
    //     0xf30f64: ldur            w4, [x3, #7]
    // 0xf30f68: DecompressPointer r4
    //     0xf30f68: add             x4, x4, HEAP, lsl #32
    // 0xf30f6c: stur            x4, [fp, #-8]
    // 0xf30f70: r0 = LoadClassIdInstr(r4)
    //     0xf30f70: ldur            x0, [x4, #-1]
    //     0xf30f74: ubfx            x0, x0, #0xc, #0x14
    // 0xf30f78: mov             x1, x4
    // 0xf30f7c: r0 = GDT[cid_x0 + -0xfa7]()
    //     0xf30f7c: sub             lr, x0, #0xfa7
    //     0xf30f80: ldr             lr, [x21, lr, lsl #3]
    //     0xf30f84: blr             lr
    // 0xf30f88: mov             x2, x0
    // 0xf30f8c: ldur            x0, [fp, #-8]
    // 0xf30f90: LoadField: r1 = r0->field_1b
    //     0xf30f90: ldur            w1, [x0, #0x1b]
    // 0xf30f94: ldur            x3, [fp, #-0x10]
    // 0xf30f98: LoadField: r0 = r3->field_b
    //     0xf30f98: ldur            x0, [x3, #0xb]
    // 0xf30f9c: r4 = LoadInt32Instr(r1)
    //     0xf30f9c: sbfx            x4, x1, #1, #0x1f
    // 0xf30fa0: add             x5, x4, x0
    // 0xf30fa4: ldur            x4, [fp, #-0x18]
    // 0xf30fa8: r0 = BoxInt64Instr(r4)
    //     0xf30fa8: sbfiz           x0, x4, #1, #0x1f
    //     0xf30fac: cmp             x4, x0, asr #1
    //     0xf30fb0: b.eq            #0xf30fbc
    //     0xf30fb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf30fb8: stur            x4, [x0, #7]
    // 0xf30fbc: mov             x6, x0
    // 0xf30fc0: r0 = BoxInt64Instr(r5)
    //     0xf30fc0: sbfiz           x0, x5, #1, #0x1f
    //     0xf30fc4: cmp             x5, x0, asr #1
    //     0xf30fc8: b.eq            #0xf30fd4
    //     0xf30fcc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf30fd0: stur            x5, [x0, #7]
    // 0xf30fd4: r1 = LoadClassIdInstr(r2)
    //     0xf30fd4: ldur            x1, [x2, #-1]
    //     0xf30fd8: ubfx            x1, x1, #0xc, #0x14
    // 0xf30fdc: stp             x6, x0, [SP]
    // 0xf30fe0: mov             x0, x1
    // 0xf30fe4: mov             x1, x2
    // 0xf30fe8: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0xf30fe8: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0xf30fec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xf30fec: sub             lr, x0, #1, lsl #12
    //     0xf30ff0: ldr             lr, [x21, lr, lsl #3]
    //     0xf30ff4: blr             lr
    // 0xf30ff8: ldur            x1, [fp, #-0x10]
    // 0xf30ffc: LoadField: r2 = r1->field_b
    //     0xf30ffc: ldur            x2, [x1, #0xb]
    // 0xf31000: ldur            x3, [fp, #-0x18]
    // 0xf31004: add             x4, x2, x3
    // 0xf31008: StoreField: r1->field_b = r4
    //     0xf31008: stur            x4, [x1, #0xb]
    // 0xf3100c: LeaveFrame
    //     0xf3100c: mov             SP, fp
    //     0xf31010: ldp             fp, lr, [SP], #0x10
    // 0xf31014: ret
    //     0xf31014: ret             
    // 0xf31018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf31018: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3101c: b               #0xf30f64
  }
  _ getUint16(/* No info */) {
    // ** addr: 0xf350b8, size: 0x78
    // 0xf350b8: EnterFrame
    //     0xf350b8: stp             fp, lr, [SP, #-0x10]!
    //     0xf350bc: mov             fp, SP
    // 0xf350c0: mov             x2, x1
    // 0xf350c4: LoadField: r3 = r2->field_7
    //     0xf350c4: ldur            w3, [x2, #7]
    // 0xf350c8: DecompressPointer r3
    //     0xf350c8: add             x3, x3, HEAP, lsl #32
    // 0xf350cc: LoadField: r4 = r2->field_b
    //     0xf350cc: ldur            x4, [x2, #0xb]
    // 0xf350d0: add             x1, x4, #1
    // 0xf350d4: LoadField: r5 = r3->field_13
    //     0xf350d4: ldur            w5, [x3, #0x13]
    // 0xf350d8: r6 = LoadInt32Instr(r5)
    //     0xf350d8: sbfx            x6, x5, #1, #0x1f
    // 0xf350dc: mov             x0, x6
    // 0xf350e0: cmp             x1, x0
    // 0xf350e4: b.hs            #0xf35128
    // 0xf350e8: mov             x0, x6
    // 0xf350ec: mov             x1, x4
    // 0xf350f0: cmp             x1, x0
    // 0xf350f4: b.hs            #0xf3512c
    // 0xf350f8: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xf350f8: ldur            w1, [x3, #0x17]
    // 0xf350fc: DecompressPointer r1
    //     0xf350fc: add             x1, x1, HEAP, lsl #32
    // 0xf35100: LoadField: r5 = r3->field_1b
    //     0xf35100: ldur            w5, [x3, #0x1b]
    // 0xf35104: r3 = LoadInt32Instr(r5)
    //     0xf35104: sbfx            x3, x5, #1, #0x1f
    // 0xf35108: add             x5, x3, x4
    // 0xf3510c: LoadField: r3 = r1->field_7
    //     0xf3510c: ldur            x3, [x1, #7]
    // 0xf35110: ldrh            w0, [x3, x5]
    // 0xf35114: add             x1, x4, #2
    // 0xf35118: StoreField: r2->field_b = r1
    //     0xf35118: stur            x1, [x2, #0xb]
    // 0xf3511c: LeaveFrame
    //     0xf3511c: mov             SP, fp
    //     0xf35120: ldp             fp, lr, [SP], #0x10
    // 0xf35124: ret
    //     0xf35124: ret             
    // 0xf35128: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf35128: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf3512c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf3512c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getUint32(/* No info */) {
    // ** addr: 0xf35f28, size: 0x80
    // 0xf35f28: EnterFrame
    //     0xf35f28: stp             fp, lr, [SP, #-0x10]!
    //     0xf35f2c: mov             fp, SP
    // 0xf35f30: mov             x2, x1
    // 0xf35f34: LoadField: r3 = r2->field_7
    //     0xf35f34: ldur            w3, [x2, #7]
    // 0xf35f38: DecompressPointer r3
    //     0xf35f38: add             x3, x3, HEAP, lsl #32
    // 0xf35f3c: LoadField: r4 = r2->field_b
    //     0xf35f3c: ldur            x4, [x2, #0xb]
    // 0xf35f40: add             x1, x4, #3
    // 0xf35f44: LoadField: r5 = r3->field_13
    //     0xf35f44: ldur            w5, [x3, #0x13]
    // 0xf35f48: r6 = LoadInt32Instr(r5)
    //     0xf35f48: sbfx            x6, x5, #1, #0x1f
    // 0xf35f4c: mov             x0, x6
    // 0xf35f50: cmp             x1, x0
    // 0xf35f54: b.hs            #0xf35fa0
    // 0xf35f58: mov             x0, x6
    // 0xf35f5c: mov             x1, x4
    // 0xf35f60: cmp             x1, x0
    // 0xf35f64: b.hs            #0xf35fa4
    // 0xf35f68: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xf35f68: ldur            w1, [x3, #0x17]
    // 0xf35f6c: DecompressPointer r1
    //     0xf35f6c: add             x1, x1, HEAP, lsl #32
    // 0xf35f70: LoadField: r5 = r3->field_1b
    //     0xf35f70: ldur            w5, [x3, #0x1b]
    // 0xf35f74: r3 = LoadInt32Instr(r5)
    //     0xf35f74: sbfx            x3, x5, #1, #0x1f
    // 0xf35f78: add             x5, x3, x4
    // 0xf35f7c: LoadField: r3 = r1->field_7
    //     0xf35f7c: ldur            x3, [x1, #7]
    // 0xf35f80: ldr             w1, [x3, x5]
    // 0xf35f84: add             x3, x4, #4
    // 0xf35f88: StoreField: r2->field_b = r3
    //     0xf35f88: stur            x3, [x2, #0xb]
    // 0xf35f8c: ubfx            x1, x1, #0, #0x20
    // 0xf35f90: mov             x0, x1
    // 0xf35f94: LeaveFrame
    //     0xf35f94: mov             SP, fp
    //     0xf35f98: ldp             fp, lr, [SP], #0x10
    // 0xf35f9c: ret
    //     0xf35f9c: ret             
    // 0xf35fa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf35fa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf35fa4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf35fa4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getFloat32List(/* No info */) {
    // ** addr: 0x10f83e0, size: 0xe0
    // 0x10f83e0: EnterFrame
    //     0x10f83e0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f83e4: mov             fp, SP
    // 0x10f83e8: AllocStack(0x18)
    //     0x10f83e8: sub             SP, SP, #0x18
    // 0x10f83ec: SetupParameters(ReadBuffer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f83ec: mov             x3, x1
    //     0x10f83f0: mov             x0, x2
    //     0x10f83f4: stur            x1, [fp, #-8]
    //     0x10f83f8: stur            x2, [fp, #-0x10]
    // 0x10f83fc: CheckStackOverflow
    //     0x10f83fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f8400: cmp             SP, x16
    //     0x10f8404: b.ls            #0x10f84b8
    // 0x10f8408: mov             x1, x3
    // 0x10f840c: r2 = 4
    //     0x10f840c: mov             x2, #4
    // 0x10f8410: r0 = _alignTo()
    //     0x10f8410: bl              #0xf2f648  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0x10f8414: ldur            x2, [fp, #-8]
    // 0x10f8418: LoadField: r3 = r2->field_7
    //     0x10f8418: ldur            w3, [x2, #7]
    // 0x10f841c: DecompressPointer r3
    //     0x10f841c: add             x3, x3, HEAP, lsl #32
    // 0x10f8420: stur            x3, [fp, #-0x18]
    // 0x10f8424: r0 = LoadClassIdInstr(r3)
    //     0x10f8424: ldur            x0, [x3, #-1]
    //     0x10f8428: ubfx            x0, x0, #0xc, #0x14
    // 0x10f842c: mov             x1, x3
    // 0x10f8430: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x10f8430: sub             lr, x0, #0xfa7
    //     0x10f8434: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8438: blr             lr
    // 0x10f843c: mov             x2, x0
    // 0x10f8440: ldur            x0, [fp, #-0x18]
    // 0x10f8444: LoadField: r1 = r0->field_1b
    //     0x10f8444: ldur            w1, [x0, #0x1b]
    // 0x10f8448: ldur            x4, [fp, #-8]
    // 0x10f844c: LoadField: r0 = r4->field_b
    //     0x10f844c: ldur            x0, [x4, #0xb]
    // 0x10f8450: r3 = LoadInt32Instr(r1)
    //     0x10f8450: sbfx            x3, x1, #1, #0x1f
    // 0x10f8454: add             x5, x3, x0
    // 0x10f8458: ldur            x6, [fp, #-0x10]
    // 0x10f845c: r0 = BoxInt64Instr(r6)
    //     0x10f845c: sbfiz           x0, x6, #1, #0x1f
    //     0x10f8460: cmp             x6, x0, asr #1
    //     0x10f8464: b.eq            #0x10f8470
    //     0x10f8468: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f846c: stur            x6, [x0, #7]
    // 0x10f8470: r1 = LoadClassIdInstr(r2)
    //     0x10f8470: ldur            x1, [x2, #-1]
    //     0x10f8474: ubfx            x1, x1, #0xc, #0x14
    // 0x10f8478: mov             x3, x0
    // 0x10f847c: mov             x0, x1
    // 0x10f8480: mov             x1, x2
    // 0x10f8484: mov             x2, x5
    // 0x10f8488: r0 = GDT[cid_x0 + -0xf58]()
    //     0x10f8488: sub             lr, x0, #0xf58
    //     0x10f848c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8490: blr             lr
    // 0x10f8494: ldur            x1, [fp, #-8]
    // 0x10f8498: LoadField: r2 = r1->field_b
    //     0x10f8498: ldur            x2, [x1, #0xb]
    // 0x10f849c: ldur            x3, [fp, #-0x10]
    // 0x10f84a0: lsl             x4, x3, #2
    // 0x10f84a4: add             x3, x2, x4
    // 0x10f84a8: StoreField: r1->field_b = r3
    //     0x10f84a8: stur            x3, [x1, #0xb]
    // 0x10f84ac: LeaveFrame
    //     0x10f84ac: mov             SP, fp
    //     0x10f84b0: ldp             fp, lr, [SP], #0x10
    // 0x10f84b4: ret
    //     0x10f84b4: ret             
    // 0x10f84b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f84b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f84bc: b               #0x10f8408
  }
  _ getFloat64List(/* No info */) {
    // ** addr: 0x10f84c0, size: 0xe0
    // 0x10f84c0: EnterFrame
    //     0x10f84c0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f84c4: mov             fp, SP
    // 0x10f84c8: AllocStack(0x18)
    //     0x10f84c8: sub             SP, SP, #0x18
    // 0x10f84cc: SetupParameters(ReadBuffer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f84cc: mov             x3, x1
    //     0x10f84d0: mov             x0, x2
    //     0x10f84d4: stur            x1, [fp, #-8]
    //     0x10f84d8: stur            x2, [fp, #-0x10]
    // 0x10f84dc: CheckStackOverflow
    //     0x10f84dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f84e0: cmp             SP, x16
    //     0x10f84e4: b.ls            #0x10f8598
    // 0x10f84e8: mov             x1, x3
    // 0x10f84ec: r2 = 8
    //     0x10f84ec: mov             x2, #8
    // 0x10f84f0: r0 = _alignTo()
    //     0x10f84f0: bl              #0xf2f648  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0x10f84f4: ldur            x2, [fp, #-8]
    // 0x10f84f8: LoadField: r3 = r2->field_7
    //     0x10f84f8: ldur            w3, [x2, #7]
    // 0x10f84fc: DecompressPointer r3
    //     0x10f84fc: add             x3, x3, HEAP, lsl #32
    // 0x10f8500: stur            x3, [fp, #-0x18]
    // 0x10f8504: r0 = LoadClassIdInstr(r3)
    //     0x10f8504: ldur            x0, [x3, #-1]
    //     0x10f8508: ubfx            x0, x0, #0xc, #0x14
    // 0x10f850c: mov             x1, x3
    // 0x10f8510: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x10f8510: sub             lr, x0, #0xfa7
    //     0x10f8514: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8518: blr             lr
    // 0x10f851c: mov             x2, x0
    // 0x10f8520: ldur            x0, [fp, #-0x18]
    // 0x10f8524: LoadField: r1 = r0->field_1b
    //     0x10f8524: ldur            w1, [x0, #0x1b]
    // 0x10f8528: ldur            x4, [fp, #-8]
    // 0x10f852c: LoadField: r0 = r4->field_b
    //     0x10f852c: ldur            x0, [x4, #0xb]
    // 0x10f8530: r3 = LoadInt32Instr(r1)
    //     0x10f8530: sbfx            x3, x1, #1, #0x1f
    // 0x10f8534: add             x5, x3, x0
    // 0x10f8538: ldur            x6, [fp, #-0x10]
    // 0x10f853c: r0 = BoxInt64Instr(r6)
    //     0x10f853c: sbfiz           x0, x6, #1, #0x1f
    //     0x10f8540: cmp             x6, x0, asr #1
    //     0x10f8544: b.eq            #0x10f8550
    //     0x10f8548: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f854c: stur            x6, [x0, #7]
    // 0x10f8550: r1 = LoadClassIdInstr(r2)
    //     0x10f8550: ldur            x1, [x2, #-1]
    //     0x10f8554: ubfx            x1, x1, #0xc, #0x14
    // 0x10f8558: mov             x3, x0
    // 0x10f855c: mov             x0, x1
    // 0x10f8560: mov             x1, x2
    // 0x10f8564: mov             x2, x5
    // 0x10f8568: r0 = GDT[cid_x0 + -0xf41]()
    //     0x10f8568: sub             lr, x0, #0xf41
    //     0x10f856c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8570: blr             lr
    // 0x10f8574: ldur            x1, [fp, #-8]
    // 0x10f8578: LoadField: r2 = r1->field_b
    //     0x10f8578: ldur            x2, [x1, #0xb]
    // 0x10f857c: ldur            x3, [fp, #-0x10]
    // 0x10f8580: lsl             x4, x3, #3
    // 0x10f8584: add             x3, x2, x4
    // 0x10f8588: StoreField: r1->field_b = r3
    //     0x10f8588: stur            x3, [x1, #0xb]
    // 0x10f858c: LeaveFrame
    //     0x10f858c: mov             SP, fp
    //     0x10f8590: ldp             fp, lr, [SP], #0x10
    // 0x10f8594: ret
    //     0x10f8594: ret             
    // 0x10f8598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f859c: b               #0x10f84e8
  }
  _ getInt64List(/* No info */) {
    // ** addr: 0x10f85a0, size: 0xbc
    // 0x10f85a0: EnterFrame
    //     0x10f85a0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f85a4: mov             fp, SP
    // 0x10f85a8: AllocStack(0x18)
    //     0x10f85a8: sub             SP, SP, #0x18
    // 0x10f85ac: SetupParameters(ReadBuffer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x10f85ac: mov             x0, x1
    //     0x10f85b0: mov             x3, x2
    //     0x10f85b4: stur            x1, [fp, #-8]
    //     0x10f85b8: stur            x2, [fp, #-0x10]
    // 0x10f85bc: CheckStackOverflow
    //     0x10f85bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f85c0: cmp             SP, x16
    //     0x10f85c4: b.ls            #0x10f8654
    // 0x10f85c8: mov             x1, x0
    // 0x10f85cc: r2 = 8
    //     0x10f85cc: mov             x2, #8
    // 0x10f85d0: r0 = _alignTo()
    //     0x10f85d0: bl              #0xf2f648  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0x10f85d4: ldur            x2, [fp, #-8]
    // 0x10f85d8: LoadField: r3 = r2->field_7
    //     0x10f85d8: ldur            w3, [x2, #7]
    // 0x10f85dc: DecompressPointer r3
    //     0x10f85dc: add             x3, x3, HEAP, lsl #32
    // 0x10f85e0: stur            x3, [fp, #-0x18]
    // 0x10f85e4: r0 = LoadClassIdInstr(r3)
    //     0x10f85e4: ldur            x0, [x3, #-1]
    //     0x10f85e8: ubfx            x0, x0, #0xc, #0x14
    // 0x10f85ec: mov             x1, x3
    // 0x10f85f0: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x10f85f0: sub             lr, x0, #0xfa7
    //     0x10f85f4: ldr             lr, [x21, lr, lsl #3]
    //     0x10f85f8: blr             lr
    // 0x10f85fc: mov             x1, x0
    // 0x10f8600: ldur            x0, [fp, #-0x18]
    // 0x10f8604: LoadField: r2 = r0->field_1b
    //     0x10f8604: ldur            w2, [x0, #0x1b]
    // 0x10f8608: ldur            x4, [fp, #-8]
    // 0x10f860c: LoadField: r0 = r4->field_b
    //     0x10f860c: ldur            x0, [x4, #0xb]
    // 0x10f8610: r3 = LoadInt32Instr(r2)
    //     0x10f8610: sbfx            x3, x2, #1, #0x1f
    // 0x10f8614: add             x2, x3, x0
    // 0x10f8618: r0 = LoadClassIdInstr(r1)
    //     0x10f8618: ldur            x0, [x1, #-1]
    //     0x10f861c: ubfx            x0, x0, #0xc, #0x14
    // 0x10f8620: ldur            x3, [fp, #-0x10]
    // 0x10f8624: r0 = GDT[cid_x0 + -0xadb]()
    //     0x10f8624: sub             lr, x0, #0xadb
    //     0x10f8628: ldr             lr, [x21, lr, lsl #3]
    //     0x10f862c: blr             lr
    // 0x10f8630: ldur            x1, [fp, #-8]
    // 0x10f8634: LoadField: r2 = r1->field_b
    //     0x10f8634: ldur            x2, [x1, #0xb]
    // 0x10f8638: ldur            x3, [fp, #-0x10]
    // 0x10f863c: lsl             x4, x3, #3
    // 0x10f8640: add             x3, x2, x4
    // 0x10f8644: StoreField: r1->field_b = r3
    //     0x10f8644: stur            x3, [x1, #0xb]
    // 0x10f8648: LeaveFrame
    //     0x10f8648: mov             SP, fp
    //     0x10f864c: ldp             fp, lr, [SP], #0x10
    // 0x10f8650: ret
    //     0x10f8650: ret             
    // 0x10f8654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8654: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f8658: b               #0x10f85c8
  }
  _ getInt32List(/* No info */) {
    // ** addr: 0x10f865c, size: 0xe0
    // 0x10f865c: EnterFrame
    //     0x10f865c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f8660: mov             fp, SP
    // 0x10f8664: AllocStack(0x18)
    //     0x10f8664: sub             SP, SP, #0x18
    // 0x10f8668: SetupParameters(ReadBuffer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f8668: mov             x3, x1
    //     0x10f866c: mov             x0, x2
    //     0x10f8670: stur            x1, [fp, #-8]
    //     0x10f8674: stur            x2, [fp, #-0x10]
    // 0x10f8678: CheckStackOverflow
    //     0x10f8678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f867c: cmp             SP, x16
    //     0x10f8680: b.ls            #0x10f8734
    // 0x10f8684: mov             x1, x3
    // 0x10f8688: r2 = 4
    //     0x10f8688: mov             x2, #4
    // 0x10f868c: r0 = _alignTo()
    //     0x10f868c: bl              #0xf2f648  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0x10f8690: ldur            x2, [fp, #-8]
    // 0x10f8694: LoadField: r3 = r2->field_7
    //     0x10f8694: ldur            w3, [x2, #7]
    // 0x10f8698: DecompressPointer r3
    //     0x10f8698: add             x3, x3, HEAP, lsl #32
    // 0x10f869c: stur            x3, [fp, #-0x18]
    // 0x10f86a0: r0 = LoadClassIdInstr(r3)
    //     0x10f86a0: ldur            x0, [x3, #-1]
    //     0x10f86a4: ubfx            x0, x0, #0xc, #0x14
    // 0x10f86a8: mov             x1, x3
    // 0x10f86ac: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x10f86ac: sub             lr, x0, #0xfa7
    //     0x10f86b0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f86b4: blr             lr
    // 0x10f86b8: mov             x2, x0
    // 0x10f86bc: ldur            x0, [fp, #-0x18]
    // 0x10f86c0: LoadField: r1 = r0->field_1b
    //     0x10f86c0: ldur            w1, [x0, #0x1b]
    // 0x10f86c4: ldur            x4, [fp, #-8]
    // 0x10f86c8: LoadField: r0 = r4->field_b
    //     0x10f86c8: ldur            x0, [x4, #0xb]
    // 0x10f86cc: r3 = LoadInt32Instr(r1)
    //     0x10f86cc: sbfx            x3, x1, #1, #0x1f
    // 0x10f86d0: add             x5, x3, x0
    // 0x10f86d4: ldur            x6, [fp, #-0x10]
    // 0x10f86d8: r0 = BoxInt64Instr(r6)
    //     0x10f86d8: sbfiz           x0, x6, #1, #0x1f
    //     0x10f86dc: cmp             x6, x0, asr #1
    //     0x10f86e0: b.eq            #0x10f86ec
    //     0x10f86e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f86e8: stur            x6, [x0, #7]
    // 0x10f86ec: r1 = LoadClassIdInstr(r2)
    //     0x10f86ec: ldur            x1, [x2, #-1]
    //     0x10f86f0: ubfx            x1, x1, #0xc, #0x14
    // 0x10f86f4: mov             x3, x0
    // 0x10f86f8: mov             x0, x1
    // 0x10f86fc: mov             x1, x2
    // 0x10f8700: mov             x2, x5
    // 0x10f8704: r0 = GDT[cid_x0 + -0xf5a]()
    //     0x10f8704: sub             lr, x0, #0xf5a
    //     0x10f8708: ldr             lr, [x21, lr, lsl #3]
    //     0x10f870c: blr             lr
    // 0x10f8710: ldur            x1, [fp, #-8]
    // 0x10f8714: LoadField: r2 = r1->field_b
    //     0x10f8714: ldur            x2, [x1, #0xb]
    // 0x10f8718: ldur            x3, [fp, #-0x10]
    // 0x10f871c: lsl             x4, x3, #2
    // 0x10f8720: add             x3, x2, x4
    // 0x10f8724: StoreField: r1->field_b = r3
    //     0x10f8724: stur            x3, [x1, #0xb]
    // 0x10f8728: LeaveFrame
    //     0x10f8728: mov             SP, fp
    //     0x10f872c: ldp             fp, lr, [SP], #0x10
    // 0x10f8730: ret
    //     0x10f8730: ret             
    // 0x10f8734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f8738: b               #0x10f8684
  }
  _ getFloat64(/* No info */) {
    // ** addr: 0x10f879c, size: 0xa4
    // 0x10f879c: EnterFrame
    //     0x10f879c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f87a0: mov             fp, SP
    // 0x10f87a4: AllocStack(0x8)
    //     0x10f87a4: sub             SP, SP, #8
    // 0x10f87a8: SetupParameters(ReadBuffer this /* r1 => r0, fp-0x8 */)
    //     0x10f87a8: mov             x0, x1
    //     0x10f87ac: stur            x1, [fp, #-8]
    // 0x10f87b0: CheckStackOverflow
    //     0x10f87b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f87b4: cmp             SP, x16
    //     0x10f87b8: b.ls            #0x10f8830
    // 0x10f87bc: mov             x1, x0
    // 0x10f87c0: r2 = 8
    //     0x10f87c0: mov             x2, #8
    // 0x10f87c4: r0 = _alignTo()
    //     0x10f87c4: bl              #0xf2f648  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0x10f87c8: ldur            x2, [fp, #-8]
    // 0x10f87cc: LoadField: r3 = r2->field_7
    //     0x10f87cc: ldur            w3, [x2, #7]
    // 0x10f87d0: DecompressPointer r3
    //     0x10f87d0: add             x3, x3, HEAP, lsl #32
    // 0x10f87d4: LoadField: r4 = r2->field_b
    //     0x10f87d4: ldur            x4, [x2, #0xb]
    // 0x10f87d8: add             x1, x4, #7
    // 0x10f87dc: LoadField: r5 = r3->field_13
    //     0x10f87dc: ldur            w5, [x3, #0x13]
    // 0x10f87e0: r6 = LoadInt32Instr(r5)
    //     0x10f87e0: sbfx            x6, x5, #1, #0x1f
    // 0x10f87e4: mov             x0, x6
    // 0x10f87e8: cmp             x1, x0
    // 0x10f87ec: b.hs            #0x10f8838
    // 0x10f87f0: mov             x0, x6
    // 0x10f87f4: mov             x1, x4
    // 0x10f87f8: cmp             x1, x0
    // 0x10f87fc: b.hs            #0x10f883c
    // 0x10f8800: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x10f8800: ldur            w0, [x3, #0x17]
    // 0x10f8804: DecompressPointer r0
    //     0x10f8804: add             x0, x0, HEAP, lsl #32
    // 0x10f8808: LoadField: r1 = r3->field_1b
    //     0x10f8808: ldur            w1, [x3, #0x1b]
    // 0x10f880c: r3 = LoadInt32Instr(r1)
    //     0x10f880c: sbfx            x3, x1, #1, #0x1f
    // 0x10f8810: add             x1, x3, x4
    // 0x10f8814: LoadField: r3 = r0->field_7
    //     0x10f8814: ldur            x3, [x0, #7]
    // 0x10f8818: ldr             d0, [x3, x1]
    // 0x10f881c: add             x0, x4, #8
    // 0x10f8820: StoreField: r2->field_b = r0
    //     0x10f8820: stur            x0, [x2, #0xb]
    // 0x10f8824: LeaveFrame
    //     0x10f8824: mov             SP, fp
    //     0x10f8828: ldp             fp, lr, [SP], #0x10
    // 0x10f882c: ret
    //     0x10f882c: ret             
    // 0x10f8830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f8834: b               #0x10f87bc
    // 0x10f8838: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f8838: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x10f883c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f883c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getInt64(/* No info */) {
    // ** addr: 0x10f8840, size: 0x78
    // 0x10f8840: EnterFrame
    //     0x10f8840: stp             fp, lr, [SP, #-0x10]!
    //     0x10f8844: mov             fp, SP
    // 0x10f8848: mov             x2, x1
    // 0x10f884c: LoadField: r3 = r2->field_7
    //     0x10f884c: ldur            w3, [x2, #7]
    // 0x10f8850: DecompressPointer r3
    //     0x10f8850: add             x3, x3, HEAP, lsl #32
    // 0x10f8854: LoadField: r4 = r2->field_b
    //     0x10f8854: ldur            x4, [x2, #0xb]
    // 0x10f8858: add             x1, x4, #7
    // 0x10f885c: LoadField: r5 = r3->field_13
    //     0x10f885c: ldur            w5, [x3, #0x13]
    // 0x10f8860: r6 = LoadInt32Instr(r5)
    //     0x10f8860: sbfx            x6, x5, #1, #0x1f
    // 0x10f8864: mov             x0, x6
    // 0x10f8868: cmp             x1, x0
    // 0x10f886c: b.hs            #0x10f88b0
    // 0x10f8870: mov             x0, x6
    // 0x10f8874: mov             x1, x4
    // 0x10f8878: cmp             x1, x0
    // 0x10f887c: b.hs            #0x10f88b4
    // 0x10f8880: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x10f8880: ldur            w1, [x3, #0x17]
    // 0x10f8884: DecompressPointer r1
    //     0x10f8884: add             x1, x1, HEAP, lsl #32
    // 0x10f8888: LoadField: r5 = r3->field_1b
    //     0x10f8888: ldur            w5, [x3, #0x1b]
    // 0x10f888c: r3 = LoadInt32Instr(r5)
    //     0x10f888c: sbfx            x3, x5, #1, #0x1f
    // 0x10f8890: add             x5, x3, x4
    // 0x10f8894: LoadField: r3 = r1->field_7
    //     0x10f8894: ldur            x3, [x1, #7]
    // 0x10f8898: ldr             x0, [x3, x5]
    // 0x10f889c: add             x1, x4, #8
    // 0x10f88a0: StoreField: r2->field_b = r1
    //     0x10f88a0: stur            x1, [x2, #0xb]
    // 0x10f88a4: LeaveFrame
    //     0x10f88a4: mov             SP, fp
    //     0x10f88a8: ldp             fp, lr, [SP], #0x10
    // 0x10f88ac: ret
    //     0x10f88ac: ret             
    // 0x10f88b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f88b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x10f88b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f88b4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getInt32(/* No info */) {
    // ** addr: 0x10f88b8, size: 0x80
    // 0x10f88b8: EnterFrame
    //     0x10f88b8: stp             fp, lr, [SP, #-0x10]!
    //     0x10f88bc: mov             fp, SP
    // 0x10f88c0: mov             x2, x1
    // 0x10f88c4: LoadField: r3 = r2->field_7
    //     0x10f88c4: ldur            w3, [x2, #7]
    // 0x10f88c8: DecompressPointer r3
    //     0x10f88c8: add             x3, x3, HEAP, lsl #32
    // 0x10f88cc: LoadField: r4 = r2->field_b
    //     0x10f88cc: ldur            x4, [x2, #0xb]
    // 0x10f88d0: add             x1, x4, #3
    // 0x10f88d4: LoadField: r5 = r3->field_13
    //     0x10f88d4: ldur            w5, [x3, #0x13]
    // 0x10f88d8: r6 = LoadInt32Instr(r5)
    //     0x10f88d8: sbfx            x6, x5, #1, #0x1f
    // 0x10f88dc: mov             x0, x6
    // 0x10f88e0: cmp             x1, x0
    // 0x10f88e4: b.hs            #0x10f8930
    // 0x10f88e8: mov             x0, x6
    // 0x10f88ec: mov             x1, x4
    // 0x10f88f0: cmp             x1, x0
    // 0x10f88f4: b.hs            #0x10f8934
    // 0x10f88f8: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x10f88f8: ldur            w1, [x3, #0x17]
    // 0x10f88fc: DecompressPointer r1
    //     0x10f88fc: add             x1, x1, HEAP, lsl #32
    // 0x10f8900: LoadField: r5 = r3->field_1b
    //     0x10f8900: ldur            w5, [x3, #0x1b]
    // 0x10f8904: r3 = LoadInt32Instr(r5)
    //     0x10f8904: sbfx            x3, x5, #1, #0x1f
    // 0x10f8908: add             x5, x3, x4
    // 0x10f890c: LoadField: r3 = r1->field_7
    //     0x10f890c: ldur            x3, [x1, #7]
    // 0x10f8910: ldrsw           x1, [x3, x5]
    // 0x10f8914: add             x3, x4, #4
    // 0x10f8918: StoreField: r2->field_b = r3
    //     0x10f8918: stur            x3, [x2, #0xb]
    // 0x10f891c: sxtw            x1, w1
    // 0x10f8920: mov             x0, x1
    // 0x10f8924: LeaveFrame
    //     0x10f8924: mov             SP, fp
    //     0x10f8928: ldp             fp, lr, [SP], #0x10
    // 0x10f892c: ret
    //     0x10f892c: ret             
    // 0x10f8930: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f8930: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x10f8934: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10f8934: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3189, size: 0x20, field offset: 0x8
class WriteBuffer extends Object {

  static late final Uint8List _zeroBuffer; // offset: 0xbe4

  _ done(/* No info */) {
    // ** addr: 0xd0504c, size: 0x108
    // 0xd0504c: EnterFrame
    //     0xd0504c: stp             fp, lr, [SP, #-0x10]!
    //     0xd05050: mov             fp, SP
    // 0xd05054: AllocStack(0x20)
    //     0xd05054: sub             SP, SP, #0x20
    // 0xd05058: SetupParameters(WriteBuffer this /* r1 => r1, fp-0x10 */)
    //     0xd05058: stur            x1, [fp, #-0x10]
    // 0xd0505c: CheckStackOverflow
    //     0xd0505c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd05060: cmp             SP, x16
    //     0xd05064: b.ls            #0xd0514c
    // 0xd05068: LoadField: r0 = r1->field_13
    //     0xd05068: ldur            w0, [x1, #0x13]
    // 0xd0506c: DecompressPointer r0
    //     0xd0506c: add             x0, x0, HEAP, lsl #32
    // 0xd05070: tbz             w0, #4, #0xd05100
    // 0xd05074: LoadField: r0 = r1->field_7
    //     0xd05074: ldur            w0, [x1, #7]
    // 0xd05078: DecompressPointer r0
    //     0xd05078: add             x0, x0, HEAP, lsl #32
    // 0xd0507c: stur            x0, [fp, #-8]
    // 0xd05080: r0 = _ByteBuffer()
    //     0xd05080: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xd05084: mov             x2, x0
    // 0xd05088: ldur            x0, [fp, #-8]
    // 0xd0508c: StoreField: r2->field_7 = r0
    //     0xd0508c: stur            w0, [x2, #7]
    // 0xd05090: ldur            x3, [fp, #-0x10]
    // 0xd05094: LoadField: r4 = r3->field_b
    //     0xd05094: ldur            x4, [x3, #0xb]
    // 0xd05098: r0 = BoxInt64Instr(r4)
    //     0xd05098: sbfiz           x0, x4, #1, #0x1f
    //     0xd0509c: cmp             x4, x0, asr #1
    //     0xd050a0: b.eq            #0xd050ac
    //     0xd050a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd050a8: stur            x4, [x0, #7]
    // 0xd050ac: stp             x0, xzr, [SP]
    // 0xd050b0: mov             x1, x2
    // 0xd050b4: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0xd050b4: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0xd050b8: r0 = asByteData()
    //     0xd050b8: bl              #0x13d99cc  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0xd050bc: r4 = 0
    //     0xd050bc: mov             x4, #0
    // 0xd050c0: stur            x0, [fp, #-8]
    // 0xd050c4: r0 = AllocateUint8Array()
    //     0xd050c4: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0xd050c8: ldur            x1, [fp, #-0x10]
    // 0xd050cc: StoreField: r1->field_7 = r0
    //     0xd050cc: stur            w0, [x1, #7]
    //     0xd050d0: ldurb           w16, [x1, #-1]
    //     0xd050d4: ldurb           w17, [x0, #-1]
    //     0xd050d8: and             x16, x17, x16, lsr #2
    //     0xd050dc: tst             x16, HEAP, lsr #32
    //     0xd050e0: b.eq            #0xd050e8
    //     0xd050e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd050e8: r0 = true
    //     0xd050e8: add             x0, NULL, #0x20  ; true
    // 0xd050ec: StoreField: r1->field_13 = r0
    //     0xd050ec: stur            w0, [x1, #0x13]
    // 0xd050f0: ldur            x0, [fp, #-8]
    // 0xd050f4: LeaveFrame
    //     0xd050f4: mov             SP, fp
    //     0xd050f8: ldp             fp, lr, [SP], #0x10
    // 0xd050fc: ret
    //     0xd050fc: ret             
    // 0xd05100: r1 = Null
    //     0xd05100: mov             x1, NULL
    // 0xd05104: r2 = 6
    //     0xd05104: mov             x2, #6
    // 0xd05108: r0 = AllocateArray()
    //     0xd05108: bl              #0x13df928  ; AllocateArrayStub
    // 0xd0510c: r16 = "done() must not be called more than once on the same "
    //     0xd0510c: ldr             x16, [PP, #0x4210]  ; [pp+0x4210] "done() must not be called more than once on the same "
    // 0xd05110: StoreField: r0->field_f = r16
    //     0xd05110: stur            w16, [x0, #0xf]
    // 0xd05114: r16 = WriteBuffer
    //     0xd05114: ldr             x16, [PP, #0x4218]  ; [pp+0x4218] Type: WriteBuffer
    // 0xd05118: StoreField: r0->field_13 = r16
    //     0xd05118: stur            w16, [x0, #0x13]
    // 0xd0511c: r16 = "."
    //     0xd0511c: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] "."
    // 0xd05120: ArrayStore: r0[0] = r16  ; List_4
    //     0xd05120: stur            w16, [x0, #0x17]
    // 0xd05124: str             x0, [SP]
    // 0xd05128: r0 = _interpolate()
    //     0xd05128: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xd0512c: stur            x0, [fp, #-8]
    // 0xd05130: r0 = StateError()
    //     0xd05130: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xd05134: mov             x1, x0
    // 0xd05138: ldur            x0, [fp, #-8]
    // 0xd0513c: StoreField: r1->field_b = r0
    //     0xd0513c: stur            w0, [x1, #0xb]
    // 0xd05140: mov             x0, x1
    // 0xd05144: r0 = Throw()
    //     0xd05144: bl              #0x13ddb2c  ; ThrowStub
    // 0xd05148: brk             #0
    // 0xd0514c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0514c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd05150: b               #0xd05068
  }
  factory _ WriteBuffer(/* No info */) {
    // ** addr: 0xd05154, size: 0x9c
    // 0xd05154: EnterFrame
    //     0xd05154: stp             fp, lr, [SP, #-0x10]!
    //     0xd05158: mov             fp, SP
    // 0xd0515c: AllocStack(0x28)
    //     0xd0515c: sub             SP, SP, #0x28
    // 0xd05160: CheckStackOverflow
    //     0xd05160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd05164: cmp             SP, x16
    //     0xd05168: b.ls            #0xd051e8
    // 0xd0516c: r16 = 16
    //     0xd0516c: mov             x16, #0x10
    // 0xd05170: stp             x16, NULL, [SP]
    // 0xd05174: r0 = ByteData()
    //     0xd05174: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xd05178: stur            x0, [fp, #-0x10]
    // 0xd0517c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd0517c: ldur            w1, [x0, #0x17]
    // 0xd05180: DecompressPointer r1
    //     0xd05180: add             x1, x1, HEAP, lsl #32
    // 0xd05184: stur            x1, [fp, #-8]
    // 0xd05188: r0 = _ByteBuffer()
    //     0xd05188: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0xd0518c: mov             x1, x0
    // 0xd05190: ldur            x0, [fp, #-8]
    // 0xd05194: StoreField: r1->field_7 = r0
    //     0xd05194: stur            w0, [x1, #7]
    // 0xd05198: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd05198: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd0519c: r0 = asUint8List()
    //     0xd0519c: bl              #0x13d9b38  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0xd051a0: stur            x0, [fp, #-8]
    // 0xd051a4: r0 = WriteBuffer()
    //     0xd051a4: bl              #0xd051f0  ; AllocateWriteBufferStub -> WriteBuffer (size=0x20)
    // 0xd051a8: stur            x0, [fp, #-0x18]
    // 0xd051ac: StoreField: r0->field_b = rZR
    //     0xd051ac: stur            xzr, [x0, #0xb]
    // 0xd051b0: r1 = false
    //     0xd051b0: add             x1, NULL, #0x30  ; false
    // 0xd051b4: StoreField: r0->field_13 = r1
    //     0xd051b4: stur            w1, [x0, #0x13]
    // 0xd051b8: r4 = 128
    //     0xd051b8: mov             x4, #0x80
    // 0xd051bc: r0 = AllocateUint8Array()
    //     0xd051bc: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0xd051c0: mov             x1, x0
    // 0xd051c4: ldur            x0, [fp, #-0x18]
    // 0xd051c8: StoreField: r0->field_7 = r1
    //     0xd051c8: stur            w1, [x0, #7]
    // 0xd051cc: ldur            x1, [fp, #-0x10]
    // 0xd051d0: ArrayStore: r0[0] = r1  ; List_4
    //     0xd051d0: stur            w1, [x0, #0x17]
    // 0xd051d4: ldur            x1, [fp, #-8]
    // 0xd051d8: StoreField: r0->field_1b = r1
    //     0xd051d8: stur            w1, [x0, #0x1b]
    // 0xd051dc: LeaveFrame
    //     0xd051dc: mov             SP, fp
    //     0xd051e0: ldp             fp, lr, [SP], #0x10
    // 0xd051e4: ret
    //     0xd051e4: ret             
    // 0xd051e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd051e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd051ec: b               #0xd0516c
  }
  static Uint8List _zeroBuffer() {
    // ** addr: 0xf1929c, size: 0x1c
    // 0xf1929c: EnterFrame
    //     0xf1929c: stp             fp, lr, [SP, #-0x10]!
    //     0xf192a0: mov             fp, SP
    // 0xf192a4: r4 = 16
    //     0xf192a4: mov             x4, #0x10
    // 0xf192a8: r0 = AllocateUint8Array()
    //     0xf192a8: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0xf192ac: LeaveFrame
    //     0xf192ac: mov             SP, fp
    //     0xf192b0: ldp             fp, lr, [SP], #0x10
    // 0xf192b4: ret
    //     0xf192b4: ret             
  }
  _ putInt64(/* No info */) {
    // ** addr: 0x12f2260, size: 0x90
    // 0x12f2260: EnterFrame
    //     0x12f2260: stp             fp, lr, [SP, #-0x10]!
    //     0x12f2264: mov             fp, SP
    // 0x12f2268: AllocStack(0x8)
    //     0x12f2268: sub             SP, SP, #8
    // 0x12f226c: SetupParameters(WriteBuffer this /* r1 => r3 */)
    //     0x12f226c: mov             x3, x1
    // 0x12f2270: CheckStackOverflow
    //     0x12f2270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f2274: cmp             SP, x16
    //     0x12f2278: b.ls            #0x12f22e4
    // 0x12f227c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12f227c: ldur            w4, [x3, #0x17]
    // 0x12f2280: DecompressPointer r4
    //     0x12f2280: add             x4, x4, HEAP, lsl #32
    // 0x12f2284: LoadField: r0 = r4->field_13
    //     0x12f2284: ldur            w0, [x4, #0x13]
    // 0x12f2288: r1 = LoadInt32Instr(r0)
    //     0x12f2288: sbfx            x1, x0, #1, #0x1f
    // 0x12f228c: mov             x0, x1
    // 0x12f2290: r1 = 7
    //     0x12f2290: mov             x1, #7
    // 0x12f2294: cmp             x1, x0
    // 0x12f2298: b.hs            #0x12f22ec
    // 0x12f229c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12f229c: ldur            w0, [x4, #0x17]
    // 0x12f22a0: DecompressPointer r0
    //     0x12f22a0: add             x0, x0, HEAP, lsl #32
    // 0x12f22a4: LoadField: r1 = r4->field_1b
    //     0x12f22a4: ldur            w1, [x4, #0x1b]
    // 0x12f22a8: LoadField: r4 = r0->field_7
    //     0x12f22a8: ldur            x4, [x0, #7]
    // 0x12f22ac: asr             w0, w1, #1
    // 0x12f22b0: add             x0, x4, w0, sxtw
    // 0x12f22b4: str             x2, [x0]
    // 0x12f22b8: LoadField: r2 = r3->field_1b
    //     0x12f22b8: ldur            w2, [x3, #0x1b]
    // 0x12f22bc: DecompressPointer r2
    //     0x12f22bc: add             x2, x2, HEAP, lsl #32
    // 0x12f22c0: r16 = 16
    //     0x12f22c0: mov             x16, #0x10
    // 0x12f22c4: str             x16, [SP]
    // 0x12f22c8: mov             x1, x3
    // 0x12f22cc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f22cc: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f22d0: r0 = _addAll()
    //     0x12f22d0: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f22d4: r0 = Null
    //     0x12f22d4: mov             x0, NULL
    // 0x12f22d8: LeaveFrame
    //     0x12f22d8: mov             SP, fp
    //     0x12f22dc: ldp             fp, lr, [SP], #0x10
    // 0x12f22e0: ret
    //     0x12f22e0: ret             
    // 0x12f22e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f22e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f22e8: b               #0x12f227c
    // 0x12f22ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f22ec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _addAll(/* No info */) {
    // ** addr: 0x12f22f0, size: 0x35c
    // 0x12f22f0: EnterFrame
    //     0x12f22f0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f22f4: mov             fp, SP
    // 0x12f22f8: AllocStack(0x38)
    //     0x12f22f8: sub             SP, SP, #0x38
    // 0x12f22fc: SetupParameters(WriteBuffer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, [dynamic _ = Null /* r0 */])
    //     0x12f22fc: mov             x3, x1
    //     0x12f2300: stur            x1, [fp, #-0x10]
    //     0x12f2304: stur            x2, [fp, #-0x18]
    //     0x12f2308: ldur            w0, [x4, #0x13]
    //     0x12f230c: sub             x1, x0, #4
    //     0x12f2310: cmp             w1, #2
    //     0x12f2314: b.lt            #0x12f2324
    //     0x12f2318: add             x0, fp, w1, sxtw #2
    //     0x12f231c: ldr             x0, [x0, #8]
    //     0x12f2320: b               #0x12f2328
    //     0x12f2324: mov             x0, NULL
    // 0x12f2328: CheckStackOverflow
    //     0x12f2328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f232c: cmp             SP, x16
    //     0x12f2330: b.ls            #0x12f2644
    // 0x12f2334: cmp             w0, NULL
    // 0x12f2338: b.ne            #0x12f2350
    // 0x12f233c: LoadField: r0 = r3->field_1b
    //     0x12f233c: ldur            w0, [x3, #0x1b]
    // 0x12f2340: DecompressPointer r0
    //     0x12f2340: add             x0, x0, HEAP, lsl #32
    // 0x12f2344: LoadField: r1 = r0->field_13
    //     0x12f2344: ldur            w1, [x0, #0x13]
    // 0x12f2348: r0 = LoadInt32Instr(r1)
    //     0x12f2348: sbfx            x0, x1, #1, #0x1f
    // 0x12f234c: b               #0x12f2360
    // 0x12f2350: r1 = LoadInt32Instr(r0)
    //     0x12f2350: sbfx            x1, x0, #1, #0x1f
    //     0x12f2354: tbz             w0, #0, #0x12f235c
    //     0x12f2358: ldur            x1, [x0, #7]
    // 0x12f235c: mov             x0, x1
    // 0x12f2360: LoadField: r1 = r3->field_b
    //     0x12f2360: ldur            x1, [x3, #0xb]
    // 0x12f2364: add             x4, x1, x0
    // 0x12f2368: stur            x4, [fp, #-8]
    // 0x12f236c: LoadField: r0 = r3->field_7
    //     0x12f236c: ldur            w0, [x3, #7]
    // 0x12f2370: DecompressPointer r0
    //     0x12f2370: add             x0, x0, HEAP, lsl #32
    // 0x12f2374: LoadField: r1 = r0->field_13
    //     0x12f2374: ldur            w1, [x0, #0x13]
    // 0x12f2378: r0 = LoadInt32Instr(r1)
    //     0x12f2378: sbfx            x0, x1, #1, #0x1f
    // 0x12f237c: cmp             x4, x0
    // 0x12f2380: b.lt            #0x12f23a8
    // 0x12f2384: r0 = BoxInt64Instr(r4)
    //     0x12f2384: sbfiz           x0, x4, #1, #0x1f
    //     0x12f2388: cmp             x4, x0, asr #1
    //     0x12f238c: b.eq            #0x12f2398
    //     0x12f2390: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f2394: stur            x4, [x0, #7]
    // 0x12f2398: str             x0, [SP]
    // 0x12f239c: mov             x1, x3
    // 0x12f23a0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x12f23a0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x12f23a4: r0 = _resize()
    //     0x12f23a4: bl              #0x12f264c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0x12f23a8: ldur            x4, [fp, #-0x10]
    // 0x12f23ac: LoadField: r5 = r4->field_7
    //     0x12f23ac: ldur            w5, [x4, #7]
    // 0x12f23b0: DecompressPointer r5
    //     0x12f23b0: add             x5, x5, HEAP, lsl #32
    // 0x12f23b4: stur            x5, [fp, #-0x28]
    // 0x12f23b8: LoadField: r6 = r4->field_b
    //     0x12f23b8: ldur            x6, [x4, #0xb]
    // 0x12f23bc: stur            x6, [fp, #-0x20]
    // 0x12f23c0: tbz             x6, #0x3f, #0x12f23cc
    // 0x12f23c4: ldur            x7, [fp, #-8]
    // 0x12f23c8: b               #0x12f23e8
    // 0x12f23cc: ldur            x7, [fp, #-8]
    // 0x12f23d0: cmp             x6, x7
    // 0x12f23d4: b.gt            #0x12f23e8
    // 0x12f23d8: LoadField: r0 = r5->field_13
    //     0x12f23d8: ldur            w0, [x5, #0x13]
    // 0x12f23dc: r1 = LoadInt32Instr(r0)
    //     0x12f23dc: sbfx            x1, x0, #1, #0x1f
    // 0x12f23e0: cmp             x7, x1
    // 0x12f23e4: b.le            #0x12f2414
    // 0x12f23e8: LoadField: r2 = r5->field_13
    //     0x12f23e8: ldur            w2, [x5, #0x13]
    // 0x12f23ec: r0 = BoxInt64Instr(r7)
    //     0x12f23ec: sbfiz           x0, x7, #1, #0x1f
    //     0x12f23f0: cmp             x7, x0, asr #1
    //     0x12f23f4: b.eq            #0x12f2400
    //     0x12f23f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f23fc: stur            x7, [x0, #7]
    // 0x12f2400: r3 = LoadInt32Instr(r2)
    //     0x12f2400: sbfx            x3, x2, #1, #0x1f
    // 0x12f2404: mov             x1, x6
    // 0x12f2408: mov             x2, x0
    // 0x12f240c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x12f240c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x12f2410: r0 = checkValidRange()
    //     0x12f2410: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x12f2414: ldur            x2, [fp, #-0x18]
    // 0x12f2418: r0 = LoadClassIdInstr(r2)
    //     0x12f2418: ldur            x0, [x2, #-1]
    //     0x12f241c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f2420: mov             x1, x2
    // 0x12f2424: r0 = GDT[cid_x0 + -0x7f5]()
    //     0x12f2424: sub             lr, x0, #0x7f5
    //     0x12f2428: ldr             lr, [x21, lr, lsl #3]
    //     0x12f242c: blr             lr
    // 0x12f2430: cmp             x0, #1
    // 0x12f2434: b.ne            #0x12f25fc
    // 0x12f2438: ldur            x5, [fp, #-0x18]
    // 0x12f243c: ldur            x3, [fp, #-8]
    // 0x12f2440: ldur            x2, [fp, #-0x20]
    // 0x12f2444: sub             x1, x3, x2
    // 0x12f2448: stur            x1, [fp, #-0x30]
    // 0x12f244c: r0 = LoadClassIdInstr(r5)
    //     0x12f244c: ldur            x0, [x5, #-1]
    //     0x12f2450: ubfx            x0, x0, #0xc, #0x14
    // 0x12f2454: str             x5, [SP]
    // 0x12f2458: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f2458: mov             x17, #0xf078
    //     0x12f245c: add             lr, x0, x17
    //     0x12f2460: ldr             lr, [x21, lr, lsl #3]
    //     0x12f2464: blr             lr
    // 0x12f2468: r1 = LoadInt32Instr(r0)
    //     0x12f2468: sbfx            x1, x0, #1, #0x1f
    //     0x12f246c: tbz             w0, #0, #0x12f2474
    //     0x12f2470: ldur            x1, [x0, #7]
    // 0x12f2474: ldur            x2, [fp, #-0x30]
    // 0x12f2478: cmp             x1, x2
    // 0x12f247c: b.lt            #0x12f2638
    // 0x12f2480: cbz             x2, #0x12f261c
    // 0x12f2484: r0 = BoxInt64Instr(r2)
    //     0x12f2484: sbfiz           x0, x2, #1, #0x1f
    //     0x12f2488: cmp             x2, x0, asr #1
    //     0x12f248c: b.eq            #0x12f2498
    //     0x12f2490: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f2494: stur            x2, [x0, #7]
    // 0x12f2498: mov             x3, x0
    // 0x12f249c: cmp             w3, #0x800
    // 0x12f24a0: b.ge            #0x12f2598
    // 0x12f24a4: ldur            x5, [fp, #-0x18]
    // 0x12f24a8: ldur            x6, [fp, #-0x28]
    // 0x12f24ac: ldur            x4, [fp, #-0x20]
    // 0x12f24b0: r0 = BoxInt64Instr(r4)
    //     0x12f24b0: sbfiz           x0, x4, #1, #0x1f
    //     0x12f24b4: cmp             x4, x0, asr #1
    //     0x12f24b8: b.eq            #0x12f24c4
    //     0x12f24bc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f24c0: stur            x4, [x0, #7]
    // 0x12f24c4: LoadField: r1 = r5->field_7
    //     0x12f24c4: ldur            x1, [x5, #7]
    // 0x12f24c8: mov             x4, x3
    // 0x12f24cc: mov             x3, x1
    // 0x12f24d0: sxtw            x0, w0
    // 0x12f24d4: add             x2, x6, x0, asr #1
    // 0x12f24d8: add             x2, x2, #0x17
    // 0x12f24dc: cbz             x4, #0x12f2594
    // 0x12f24e0: cmp             x2, x3
    // 0x12f24e4: b.ls            #0x12f254c
    // 0x12f24e8: sxtw            x4, w4
    // 0x12f24ec: add             x16, x3, x4, asr #1
    // 0x12f24f0: cmp             x2, x16
    // 0x12f24f4: b.hs            #0x12f254c
    // 0x12f24f8: mov             x3, x16
    // 0x12f24fc: add             x2, x2, x4, asr #1
    // 0x12f2500: tbz             w4, #4, #0x12f250c
    // 0x12f2504: ldr             x16, [x3, #-8]!
    // 0x12f2508: str             x16, [x2, #-8]!
    // 0x12f250c: tbz             w4, #3, #0x12f2518
    // 0x12f2510: ldr             w16, [x3, #-4]!
    // 0x12f2514: str             w16, [x2, #-4]!
    // 0x12f2518: tbz             w4, #2, #0x12f2524
    // 0x12f251c: ldrh            w16, [x3, #-2]!
    // 0x12f2520: strh            w16, [x2, #-2]!
    // 0x12f2524: tbz             w4, #1, #0x12f2530
    // 0x12f2528: ldrb            w16, [x3, #-1]!
    // 0x12f252c: strb            w16, [x2, #-1]!
    // 0x12f2530: ands            w4, w4, #0xffffffe1
    // 0x12f2534: b.eq            #0x12f2594
    // 0x12f2538: ldp             x16, x17, [x3, #-0x10]!
    // 0x12f253c: stp             x16, x17, [x2, #-0x10]!
    // 0x12f2540: subs            w4, w4, #0x20
    // 0x12f2544: b.ne            #0x12f2538
    // 0x12f2548: b               #0x12f2594
    // 0x12f254c: tbz             w4, #4, #0x12f2558
    // 0x12f2550: ldr             x16, [x3], #8
    // 0x12f2554: str             x16, [x2], #8
    // 0x12f2558: tbz             w4, #3, #0x12f2564
    // 0x12f255c: ldr             w16, [x3], #4
    // 0x12f2560: str             w16, [x2], #4
    // 0x12f2564: tbz             w4, #2, #0x12f2570
    // 0x12f2568: ldrh            w16, [x3], #2
    // 0x12f256c: strh            w16, [x2], #2
    // 0x12f2570: tbz             w4, #1, #0x12f257c
    // 0x12f2574: ldrb            w16, [x3], #1
    // 0x12f2578: strb            w16, [x2], #1
    // 0x12f257c: ands            w4, w4, #0xffffffe1
    // 0x12f2580: b.eq            #0x12f2594
    // 0x12f2584: ldp             x16, x17, [x3], #0x10
    // 0x12f2588: stp             x16, x17, [x2], #0x10
    // 0x12f258c: subs            w4, w4, #0x20
    // 0x12f2590: b.ne            #0x12f2584
    // 0x12f2594: b               #0x12f261c
    // 0x12f2598: ldur            x5, [fp, #-0x18]
    // 0x12f259c: ldur            x6, [fp, #-0x28]
    // 0x12f25a0: ldur            x4, [fp, #-0x20]
    // 0x12f25a4: LoadField: r0 = r6->field_7
    //     0x12f25a4: ldur            x0, [x6, #7]
    // 0x12f25a8: add             x1, x0, x4
    // 0x12f25ac: LoadField: r0 = r5->field_7
    //     0x12f25ac: ldur            x0, [x5, #7]
    // 0x12f25b0: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x12f25b0: mov             x3, THR
    //     0x12f25b4: ldr             x9, [x3, #0x888]
    //     0x12f25b8: mov             x16, x0
    //     0x12f25bc: mov             x0, x1
    //     0x12f25c0: mov             x1, x16
    //     0x12f25c4: mov             x17, fp
    //     0x12f25c8: str             fp, [SP, #-8]!
    //     0x12f25cc: mov             fp, SP
    //     0x12f25d0: and             SP, SP, #0xfffffffffffffff0
    //     0x12f25d4: mov             x19, sp
    //     0x12f25d8: mov             sp, SP
    //     0x12f25dc: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f25e0: blr             x9
    //     0x12f25e4: mov             x16, #8
    //     0x12f25e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f25ec: mov             sp, x19
    //     0x12f25f0: mov             SP, fp
    //     0x12f25f4: ldr             fp, [SP], #8
    // 0x12f25f8: b               #0x12f261c
    // 0x12f25fc: ldur            x5, [fp, #-0x18]
    // 0x12f2600: ldur            x6, [fp, #-0x28]
    // 0x12f2604: ldur            x4, [fp, #-0x20]
    // 0x12f2608: mov             x1, x6
    // 0x12f260c: mov             x2, x4
    // 0x12f2610: ldur            x3, [fp, #-8]
    // 0x12f2614: r6 = 0
    //     0x12f2614: mov             x6, #0
    // 0x12f2618: r0 = _slowSetRange()
    //     0x12f2618: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x12f261c: ldur            x1, [fp, #-0x10]
    // 0x12f2620: ldur            x0, [fp, #-8]
    // 0x12f2624: StoreField: r1->field_b = r0
    //     0x12f2624: stur            x0, [x1, #0xb]
    // 0x12f2628: r0 = Null
    //     0x12f2628: mov             x0, NULL
    // 0x12f262c: LeaveFrame
    //     0x12f262c: mov             SP, fp
    //     0x12f2630: ldp             fp, lr, [SP], #0x10
    // 0x12f2634: ret
    //     0x12f2634: ret             
    // 0x12f2638: r0 = tooFew()
    //     0x12f2638: bl              #0x7e9534  ; [dart:_internal] IterableElementError::tooFew
    // 0x12f263c: r0 = Throw()
    //     0x12f263c: bl              #0x13ddb2c  ; ThrowStub
    // 0x12f2640: brk             #0
    // 0x12f2644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f2644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f2648: b               #0x12f2334
  }
  _ _resize(/* No info */) {
    // ** addr: 0x12f264c, size: 0x250
    // 0x12f264c: EnterFrame
    //     0x12f264c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f2650: mov             fp, SP
    // 0x12f2654: AllocStack(0x30)
    //     0x12f2654: sub             SP, SP, #0x30
    // 0x12f2658: SetupParameters(WriteBuffer this /* r1 => r2, fp-0x28 */, [dynamic _ = Null /* r0 */])
    //     0x12f2658: mov             x2, x1
    //     0x12f265c: stur            x1, [fp, #-0x28]
    //     0x12f2660: ldur            w0, [x4, #0x13]
    //     0x12f2664: sub             x1, x0, #2
    //     0x12f2668: cmp             w1, #2
    //     0x12f266c: b.lt            #0x12f267c
    //     0x12f2670: add             x0, fp, w1, sxtw #2
    //     0x12f2674: ldr             x0, [x0, #8]
    //     0x12f2678: b               #0x12f2680
    //     0x12f267c: mov             x0, NULL
    // 0x12f2680: CheckStackOverflow
    //     0x12f2680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f2684: cmp             SP, x16
    //     0x12f2688: b.ls            #0x12f2894
    // 0x12f268c: LoadField: r3 = r2->field_7
    //     0x12f268c: ldur            w3, [x2, #7]
    // 0x12f2690: DecompressPointer r3
    //     0x12f2690: add             x3, x3, HEAP, lsl #32
    // 0x12f2694: stur            x3, [fp, #-0x20]
    // 0x12f2698: LoadField: r5 = r3->field_13
    //     0x12f2698: ldur            w5, [x3, #0x13]
    // 0x12f269c: stur            x5, [fp, #-0x18]
    // 0x12f26a0: r6 = LoadInt32Instr(r5)
    //     0x12f26a0: sbfx            x6, x5, #1, #0x1f
    // 0x12f26a4: stur            x6, [fp, #-0x10]
    // 0x12f26a8: lsl             x1, x6, #1
    // 0x12f26ac: cmp             w0, NULL
    // 0x12f26b0: b.ne            #0x12f26bc
    // 0x12f26b4: r0 = 0
    //     0x12f26b4: mov             x0, #0
    // 0x12f26b8: b               #0x12f26cc
    // 0x12f26bc: r4 = LoadInt32Instr(r0)
    //     0x12f26bc: sbfx            x4, x0, #1, #0x1f
    //     0x12f26c0: tbz             w0, #0, #0x12f26c8
    //     0x12f26c4: ldur            x4, [x0, #7]
    // 0x12f26c8: mov             x0, x4
    // 0x12f26cc: cmp             x0, x1
    // 0x12f26d0: csel            x7, x1, x0, lt
    // 0x12f26d4: stur            x7, [fp, #-8]
    // 0x12f26d8: r0 = BoxInt64Instr(r7)
    //     0x12f26d8: sbfiz           x0, x7, #1, #0x1f
    //     0x12f26dc: cmp             x7, x0, asr #1
    //     0x12f26e0: b.eq            #0x12f26ec
    //     0x12f26e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f26e8: stur            x7, [x0, #7]
    // 0x12f26ec: mov             x4, x0
    // 0x12f26f0: r0 = AllocateUint8Array()
    //     0x12f26f0: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x12f26f4: mov             x4, x0
    // 0x12f26f8: ldur            x0, [fp, #-0x10]
    // 0x12f26fc: stur            x4, [fp, #-0x30]
    // 0x12f2700: tbz             x0, #0x3f, #0x12f270c
    // 0x12f2704: ldur            x3, [fp, #-8]
    // 0x12f2708: b               #0x12f2718
    // 0x12f270c: ldur            x3, [fp, #-8]
    // 0x12f2710: cmp             x0, x3
    // 0x12f2714: b.le            #0x12f2728
    // 0x12f2718: ldur            x2, [fp, #-0x18]
    // 0x12f271c: r1 = 0
    //     0x12f271c: mov             x1, #0
    // 0x12f2720: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x12f2720: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x12f2724: r0 = checkValidRange()
    //     0x12f2724: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x12f2728: ldur            x2, [fp, #-0x10]
    // 0x12f272c: cbnz            x2, #0x12f2738
    // 0x12f2730: ldur            x23, [fp, #-0x30]
    // 0x12f2734: b               #0x12f2860
    // 0x12f2738: ldur            x20, [fp, #-0x18]
    // 0x12f273c: cmp             w20, #0x800
    // 0x12f2740: b.ge            #0x12f2814
    // 0x12f2744: ldur            x24, [fp, #-0x20]
    // 0x12f2748: ldur            x23, [fp, #-0x30]
    // 0x12f274c: mov             x0, x20
    // 0x12f2750: add             x25, x24, #0x17
    // 0x12f2754: add             x20, x23, #0x17
    // 0x12f2758: cbz             x0, #0x12f2810
    // 0x12f275c: cmp             x20, x25
    // 0x12f2760: b.ls            #0x12f27c8
    // 0x12f2764: sxtw            x0, w0
    // 0x12f2768: add             x16, x25, x0, asr #1
    // 0x12f276c: cmp             x20, x16
    // 0x12f2770: b.hs            #0x12f27c8
    // 0x12f2774: mov             x25, x16
    // 0x12f2778: add             x20, x20, x0, asr #1
    // 0x12f277c: tbz             w0, #4, #0x12f2788
    // 0x12f2780: ldr             x16, [x25, #-8]!
    // 0x12f2784: str             x16, [x20, #-8]!
    // 0x12f2788: tbz             w0, #3, #0x12f2794
    // 0x12f278c: ldr             w16, [x25, #-4]!
    // 0x12f2790: str             w16, [x20, #-4]!
    // 0x12f2794: tbz             w0, #2, #0x12f27a0
    // 0x12f2798: ldrh            w16, [x25, #-2]!
    // 0x12f279c: strh            w16, [x20, #-2]!
    // 0x12f27a0: tbz             w0, #1, #0x12f27ac
    // 0x12f27a4: ldrb            w16, [x25, #-1]!
    // 0x12f27a8: strb            w16, [x20, #-1]!
    // 0x12f27ac: ands            w0, w0, #0xffffffe1
    // 0x12f27b0: b.eq            #0x12f2810
    // 0x12f27b4: ldp             x16, x17, [x25, #-0x10]!
    // 0x12f27b8: stp             x16, x17, [x20, #-0x10]!
    // 0x12f27bc: subs            w0, w0, #0x20
    // 0x12f27c0: b.ne            #0x12f27b4
    // 0x12f27c4: b               #0x12f2810
    // 0x12f27c8: tbz             w0, #4, #0x12f27d4
    // 0x12f27cc: ldr             x16, [x25], #8
    // 0x12f27d0: str             x16, [x20], #8
    // 0x12f27d4: tbz             w0, #3, #0x12f27e0
    // 0x12f27d8: ldr             w16, [x25], #4
    // 0x12f27dc: str             w16, [x20], #4
    // 0x12f27e0: tbz             w0, #2, #0x12f27ec
    // 0x12f27e4: ldrh            w16, [x25], #2
    // 0x12f27e8: strh            w16, [x20], #2
    // 0x12f27ec: tbz             w0, #1, #0x12f27f8
    // 0x12f27f0: ldrb            w16, [x25], #1
    // 0x12f27f4: strb            w16, [x20], #1
    // 0x12f27f8: ands            w0, w0, #0xffffffe1
    // 0x12f27fc: b.eq            #0x12f2810
    // 0x12f2800: ldp             x16, x17, [x25], #0x10
    // 0x12f2804: stp             x16, x17, [x20], #0x10
    // 0x12f2808: subs            w0, w0, #0x20
    // 0x12f280c: b.ne            #0x12f2800
    // 0x12f2810: b               #0x12f2860
    // 0x12f2814: ldur            x24, [fp, #-0x20]
    // 0x12f2818: ldur            x23, [fp, #-0x30]
    // 0x12f281c: LoadField: r0 = r23->field_7
    //     0x12f281c: ldur            x0, [x23, #7]
    // 0x12f2820: LoadField: r1 = r24->field_7
    //     0x12f2820: ldur            x1, [x24, #7]
    // 0x12f2824: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x12f2824: mov             x20, THR
    //     0x12f2828: ldr             x9, [x20, #0x888]
    //     0x12f282c: mov             x17, fp
    //     0x12f2830: str             fp, [SP, #-8]!
    //     0x12f2834: mov             fp, SP
    //     0x12f2838: and             SP, SP, #0xfffffffffffffff0
    //     0x12f283c: mov             x19, sp
    //     0x12f2840: mov             sp, SP
    //     0x12f2844: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f2848: blr             x9
    //     0x12f284c: mov             x16, #8
    //     0x12f2850: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f2854: mov             sp, x19
    //     0x12f2858: mov             SP, fp
    //     0x12f285c: ldr             fp, [SP], #8
    // 0x12f2860: ldur            x1, [fp, #-0x28]
    // 0x12f2864: mov             x0, x23
    // 0x12f2868: StoreField: r1->field_7 = r0
    //     0x12f2868: stur            w0, [x1, #7]
    //     0x12f286c: ldurb           w16, [x1, #-1]
    //     0x12f2870: ldurb           w17, [x0, #-1]
    //     0x12f2874: and             x16, x17, x16, lsr #2
    //     0x12f2878: tst             x16, HEAP, lsr #32
    //     0x12f287c: b.eq            #0x12f2884
    //     0x12f2880: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12f2884: r0 = Null
    //     0x12f2884: mov             x0, NULL
    // 0x12f2888: LeaveFrame
    //     0x12f2888: mov             SP, fp
    //     0x12f288c: ldp             fp, lr, [SP], #0x10
    // 0x12f2890: ret
    //     0x12f2890: ret             
    // 0x12f2894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f2894: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f2898: b               #0x12f268c
  }
  _ _add(/* No info */) {
    // ** addr: 0x12f289c, size: 0xa0
    // 0x12f289c: EnterFrame
    //     0x12f289c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f28a0: mov             fp, SP
    // 0x12f28a4: AllocStack(0x10)
    //     0x12f28a4: sub             SP, SP, #0x10
    // 0x12f28a8: SetupParameters(WriteBuffer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12f28a8: mov             x0, x1
    //     0x12f28ac: stur            x1, [fp, #-8]
    //     0x12f28b0: stur            x2, [fp, #-0x10]
    // 0x12f28b4: CheckStackOverflow
    //     0x12f28b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f28b8: cmp             SP, x16
    //     0x12f28bc: b.ls            #0x12f2930
    // 0x12f28c0: LoadField: r1 = r0->field_b
    //     0x12f28c0: ldur            x1, [x0, #0xb]
    // 0x12f28c4: LoadField: r3 = r0->field_7
    //     0x12f28c4: ldur            w3, [x0, #7]
    // 0x12f28c8: DecompressPointer r3
    //     0x12f28c8: add             x3, x3, HEAP, lsl #32
    // 0x12f28cc: LoadField: r4 = r3->field_13
    //     0x12f28cc: ldur            w4, [x3, #0x13]
    // 0x12f28d0: r3 = LoadInt32Instr(r4)
    //     0x12f28d0: sbfx            x3, x4, #1, #0x1f
    // 0x12f28d4: cmp             x1, x3
    // 0x12f28d8: b.ne            #0x12f28e8
    // 0x12f28dc: mov             x1, x0
    // 0x12f28e0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12f28e0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12f28e4: r0 = _resize()
    //     0x12f28e4: bl              #0x12f264c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0x12f28e8: ldur            x3, [fp, #-8]
    // 0x12f28ec: ldur            x2, [fp, #-0x10]
    // 0x12f28f0: LoadField: r4 = r3->field_7
    //     0x12f28f0: ldur            w4, [x3, #7]
    // 0x12f28f4: DecompressPointer r4
    //     0x12f28f4: add             x4, x4, HEAP, lsl #32
    // 0x12f28f8: LoadField: r5 = r3->field_b
    //     0x12f28f8: ldur            x5, [x3, #0xb]
    // 0x12f28fc: LoadField: r6 = r4->field_13
    //     0x12f28fc: ldur            w6, [x4, #0x13]
    // 0x12f2900: r0 = LoadInt32Instr(r6)
    //     0x12f2900: sbfx            x0, x6, #1, #0x1f
    // 0x12f2904: mov             x1, x5
    // 0x12f2908: cmp             x1, x0
    // 0x12f290c: b.hs            #0x12f2938
    // 0x12f2910: ArrayStore: r4[r5] = r2  ; TypeUnknown_1
    //     0x12f2910: add             x1, x4, x5
    //     0x12f2914: strb            w2, [x1, #0x17]
    // 0x12f2918: add             x1, x5, #1
    // 0x12f291c: StoreField: r3->field_b = r1
    //     0x12f291c: stur            x1, [x3, #0xb]
    // 0x12f2920: r0 = Null
    //     0x12f2920: mov             x0, NULL
    // 0x12f2924: LeaveFrame
    //     0x12f2924: mov             SP, fp
    //     0x12f2928: ldp             fp, lr, [SP], #0x10
    // 0x12f292c: ret
    //     0x12f292c: ret             
    // 0x12f2930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f2930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f2934: b               #0x12f28c0
    // 0x12f2938: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f2938: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ putInt64List(/* No info */) {
    // ** addr: 0x12f3c3c, size: 0xe4
    // 0x12f3c3c: EnterFrame
    //     0x12f3c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f3c40: mov             fp, SP
    // 0x12f3c44: AllocStack(0x28)
    //     0x12f3c44: sub             SP, SP, #0x28
    // 0x12f3c48: SetupParameters(WriteBuffer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12f3c48: mov             x3, x1
    //     0x12f3c4c: mov             x0, x2
    //     0x12f3c50: stur            x1, [fp, #-8]
    //     0x12f3c54: stur            x2, [fp, #-0x10]
    // 0x12f3c58: CheckStackOverflow
    //     0x12f3c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f3c5c: cmp             SP, x16
    //     0x12f3c60: b.ls            #0x12f3d18
    // 0x12f3c64: mov             x1, x3
    // 0x12f3c68: r2 = 8
    //     0x12f3c68: mov             x2, #8
    // 0x12f3c6c: r0 = _alignTo()
    //     0x12f3c6c: bl              #0x12f3d20  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0x12f3c70: ldur            x2, [fp, #-0x10]
    // 0x12f3c74: r0 = LoadClassIdInstr(r2)
    //     0x12f3c74: ldur            x0, [x2, #-1]
    //     0x12f3c78: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3c7c: mov             x1, x2
    // 0x12f3c80: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x12f3c80: sub             lr, x0, #0xfa7
    //     0x12f3c84: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3c88: blr             lr
    // 0x12f3c8c: mov             x2, x0
    // 0x12f3c90: ldur            x1, [fp, #-0x10]
    // 0x12f3c94: stur            x2, [fp, #-0x18]
    // 0x12f3c98: r0 = LoadClassIdInstr(r1)
    //     0x12f3c98: ldur            x0, [x1, #-1]
    //     0x12f3c9c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3ca0: str             x1, [SP]
    // 0x12f3ca4: r0 = GDT[cid_x0 + -0xc94]()
    //     0x12f3ca4: sub             lr, x0, #0xc94
    //     0x12f3ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3cac: blr             lr
    // 0x12f3cb0: mov             x2, x0
    // 0x12f3cb4: ldur            x0, [fp, #-0x10]
    // 0x12f3cb8: LoadField: r1 = r0->field_13
    //     0x12f3cb8: ldur            w1, [x0, #0x13]
    // 0x12f3cbc: r0 = LoadInt32Instr(r1)
    //     0x12f3cbc: sbfx            x0, x1, #1, #0x1f
    // 0x12f3cc0: lsl             x3, x0, #3
    // 0x12f3cc4: r0 = BoxInt64Instr(r3)
    //     0x12f3cc4: sbfiz           x0, x3, #1, #0x1f
    //     0x12f3cc8: cmp             x3, x0, asr #1
    //     0x12f3ccc: b.eq            #0x12f3cd8
    //     0x12f3cd0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f3cd4: stur            x3, [x0, #7]
    // 0x12f3cd8: ldur            x1, [fp, #-0x18]
    // 0x12f3cdc: r3 = LoadClassIdInstr(r1)
    //     0x12f3cdc: ldur            x3, [x1, #-1]
    //     0x12f3ce0: ubfx            x3, x3, #0xc, #0x14
    // 0x12f3ce4: stp             x0, x2, [SP]
    // 0x12f3ce8: mov             x0, x3
    // 0x12f3cec: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0x12f3cec: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0x12f3cf0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f3cf0: sub             lr, x0, #1, lsl #12
    //     0x12f3cf4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3cf8: blr             lr
    // 0x12f3cfc: ldur            x1, [fp, #-8]
    // 0x12f3d00: mov             x2, x0
    // 0x12f3d04: r0 = _append()
    //     0x12f3d04: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f3d08: r0 = Null
    //     0x12f3d08: mov             x0, NULL
    // 0x12f3d0c: LeaveFrame
    //     0x12f3d0c: mov             SP, fp
    //     0x12f3d10: ldp             fp, lr, [SP], #0x10
    // 0x12f3d14: ret
    //     0x12f3d14: ret             
    // 0x12f3d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3d18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3d1c: b               #0x12f3c64
  }
  _ _alignTo(/* No info */) {
    // ** addr: 0x12f3d20, size: 0xdc
    // 0x12f3d20: EnterFrame
    //     0x12f3d20: stp             fp, lr, [SP, #-0x10]!
    //     0x12f3d24: mov             fp, SP
    // 0x12f3d28: AllocStack(0x20)
    //     0x12f3d28: sub             SP, SP, #0x20
    // 0x12f3d2c: SetupParameters(WriteBuffer this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x12f3d2c: stur            x1, [fp, #-0x10]
    //     0x12f3d30: stur            x2, [fp, #-0x18]
    // 0x12f3d34: CheckStackOverflow
    //     0x12f3d34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f3d38: cmp             SP, x16
    //     0x12f3d3c: b.ls            #0x12f3dc4
    // 0x12f3d40: LoadField: r0 = r1->field_b
    //     0x12f3d40: ldur            x0, [x1, #0xb]
    // 0x12f3d44: cbz             x2, #0x12f3dcc
    // 0x12f3d48: sdiv            x4, x0, x2
    // 0x12f3d4c: msub            x3, x4, x2, x0
    // 0x12f3d50: cmp             x3, xzr
    // 0x12f3d54: b.lt            #0x12f3de8
    // 0x12f3d58: stur            x3, [fp, #-8]
    // 0x12f3d5c: cbz             x3, #0x12f3db4
    // 0x12f3d60: r0 = LoadStaticField(0xbe4)
    //     0x12f3d60: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12f3d64: ldr             x0, [x0, #0x17c8]
    // 0x12f3d68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f3d6c: cmp             w0, w16
    // 0x12f3d70: b.ne            #0x12f3d80
    // 0x12f3d74: r2 = _zeroBuffer
    //     0x12f3d74: add             x2, PP, #0xd, lsl #12  ; [pp+0xdfd0] Field <WriteBuffer._zeroBuffer@597185525>: static late final (offset: 0xbe4)
    //     0x12f3d78: ldr             x2, [x2, #0xfd0]
    // 0x12f3d7c: r0 = InitLateFinalStaticField()
    //     0x12f3d7c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12f3d80: mov             x2, x0
    // 0x12f3d84: ldur            x0, [fp, #-0x18]
    // 0x12f3d88: ldur            x1, [fp, #-8]
    // 0x12f3d8c: sub             x3, x0, x1
    // 0x12f3d90: r0 = BoxInt64Instr(r3)
    //     0x12f3d90: sbfiz           x0, x3, #1, #0x1f
    //     0x12f3d94: cmp             x3, x0, asr #1
    //     0x12f3d98: b.eq            #0x12f3da4
    //     0x12f3d9c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f3da0: stur            x3, [x0, #7]
    // 0x12f3da4: str             x0, [SP]
    // 0x12f3da8: ldur            x1, [fp, #-0x10]
    // 0x12f3dac: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f3dac: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f3db0: r0 = _addAll()
    //     0x12f3db0: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f3db4: r0 = Null
    //     0x12f3db4: mov             x0, NULL
    // 0x12f3db8: LeaveFrame
    //     0x12f3db8: mov             SP, fp
    //     0x12f3dbc: ldp             fp, lr, [SP], #0x10
    // 0x12f3dc0: ret
    //     0x12f3dc0: ret             
    // 0x12f3dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3dc8: b               #0x12f3d40
    // 0x12f3dcc: stp             x1, x2, [SP, #-0x10]!
    // 0x12f3dd0: SaveReg r0
    //     0x12f3dd0: str             x0, [SP, #-8]!
    // 0x12f3dd4: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x12f3dd8: r4 = 0
    //     0x12f3dd8: mov             x4, #0
    // 0x12f3ddc: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x12f3de0: blr             lr
    // 0x12f3de4: brk             #0
    // 0x12f3de8: cmp             x2, xzr
    // 0x12f3dec: sub             x4, x3, x2
    // 0x12f3df0: add             x3, x3, x2
    // 0x12f3df4: csel            x3, x4, x3, lt
    // 0x12f3df8: b               #0x12f3d58
  }
  _ putInt32List(/* No info */) {
    // ** addr: 0x12f3dfc, size: 0xe4
    // 0x12f3dfc: EnterFrame
    //     0x12f3dfc: stp             fp, lr, [SP, #-0x10]!
    //     0x12f3e00: mov             fp, SP
    // 0x12f3e04: AllocStack(0x28)
    //     0x12f3e04: sub             SP, SP, #0x28
    // 0x12f3e08: SetupParameters(WriteBuffer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12f3e08: mov             x3, x1
    //     0x12f3e0c: mov             x0, x2
    //     0x12f3e10: stur            x1, [fp, #-8]
    //     0x12f3e14: stur            x2, [fp, #-0x10]
    // 0x12f3e18: CheckStackOverflow
    //     0x12f3e18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f3e1c: cmp             SP, x16
    //     0x12f3e20: b.ls            #0x12f3ed8
    // 0x12f3e24: mov             x1, x3
    // 0x12f3e28: r2 = 4
    //     0x12f3e28: mov             x2, #4
    // 0x12f3e2c: r0 = _alignTo()
    //     0x12f3e2c: bl              #0x12f3d20  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0x12f3e30: ldur            x2, [fp, #-0x10]
    // 0x12f3e34: r0 = LoadClassIdInstr(r2)
    //     0x12f3e34: ldur            x0, [x2, #-1]
    //     0x12f3e38: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3e3c: mov             x1, x2
    // 0x12f3e40: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x12f3e40: sub             lr, x0, #0xfa7
    //     0x12f3e44: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3e48: blr             lr
    // 0x12f3e4c: mov             x2, x0
    // 0x12f3e50: ldur            x1, [fp, #-0x10]
    // 0x12f3e54: stur            x2, [fp, #-0x18]
    // 0x12f3e58: r0 = LoadClassIdInstr(r1)
    //     0x12f3e58: ldur            x0, [x1, #-1]
    //     0x12f3e5c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3e60: str             x1, [SP]
    // 0x12f3e64: r0 = GDT[cid_x0 + -0xc94]()
    //     0x12f3e64: sub             lr, x0, #0xc94
    //     0x12f3e68: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3e6c: blr             lr
    // 0x12f3e70: mov             x2, x0
    // 0x12f3e74: ldur            x0, [fp, #-0x10]
    // 0x12f3e78: LoadField: r1 = r0->field_13
    //     0x12f3e78: ldur            w1, [x0, #0x13]
    // 0x12f3e7c: r0 = LoadInt32Instr(r1)
    //     0x12f3e7c: sbfx            x0, x1, #1, #0x1f
    // 0x12f3e80: lsl             x3, x0, #2
    // 0x12f3e84: r0 = BoxInt64Instr(r3)
    //     0x12f3e84: sbfiz           x0, x3, #1, #0x1f
    //     0x12f3e88: cmp             x3, x0, asr #1
    //     0x12f3e8c: b.eq            #0x12f3e98
    //     0x12f3e90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f3e94: stur            x3, [x0, #7]
    // 0x12f3e98: ldur            x1, [fp, #-0x18]
    // 0x12f3e9c: r3 = LoadClassIdInstr(r1)
    //     0x12f3e9c: ldur            x3, [x1, #-1]
    //     0x12f3ea0: ubfx            x3, x3, #0xc, #0x14
    // 0x12f3ea4: stp             x0, x2, [SP]
    // 0x12f3ea8: mov             x0, x3
    // 0x12f3eac: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0x12f3eac: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0x12f3eb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f3eb0: sub             lr, x0, #1, lsl #12
    //     0x12f3eb4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3eb8: blr             lr
    // 0x12f3ebc: ldur            x1, [fp, #-8]
    // 0x12f3ec0: mov             x2, x0
    // 0x12f3ec4: r0 = _append()
    //     0x12f3ec4: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f3ec8: r0 = Null
    //     0x12f3ec8: mov             x0, NULL
    // 0x12f3ecc: LeaveFrame
    //     0x12f3ecc: mov             SP, fp
    //     0x12f3ed0: ldp             fp, lr, [SP], #0x10
    // 0x12f3ed4: ret
    //     0x12f3ed4: ret             
    // 0x12f3ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3ed8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3edc: b               #0x12f3e24
  }
  _ _append(/* No info */) {
    // ** addr: 0x12f3ee0, size: 0x324
    // 0x12f3ee0: EnterFrame
    //     0x12f3ee0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f3ee4: mov             fp, SP
    // 0x12f3ee8: AllocStack(0x40)
    //     0x12f3ee8: sub             SP, SP, #0x40
    // 0x12f3eec: SetupParameters(WriteBuffer this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x12f3eec: mov             x3, x1
    //     0x12f3ef0: stur            x1, [fp, #-0x18]
    //     0x12f3ef4: stur            x2, [fp, #-0x20]
    // 0x12f3ef8: CheckStackOverflow
    //     0x12f3ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f3efc: cmp             SP, x16
    //     0x12f3f00: b.ls            #0x12f41fc
    // 0x12f3f04: LoadField: r0 = r3->field_b
    //     0x12f3f04: ldur            x0, [x3, #0xb]
    // 0x12f3f08: LoadField: r1 = r2->field_13
    //     0x12f3f08: ldur            w1, [x2, #0x13]
    // 0x12f3f0c: r4 = LoadInt32Instr(r1)
    //     0x12f3f0c: sbfx            x4, x1, #1, #0x1f
    // 0x12f3f10: stur            x4, [fp, #-0x10]
    // 0x12f3f14: add             x5, x0, x4
    // 0x12f3f18: stur            x5, [fp, #-8]
    // 0x12f3f1c: LoadField: r0 = r3->field_7
    //     0x12f3f1c: ldur            w0, [x3, #7]
    // 0x12f3f20: DecompressPointer r0
    //     0x12f3f20: add             x0, x0, HEAP, lsl #32
    // 0x12f3f24: LoadField: r1 = r0->field_13
    //     0x12f3f24: ldur            w1, [x0, #0x13]
    // 0x12f3f28: r0 = LoadInt32Instr(r1)
    //     0x12f3f28: sbfx            x0, x1, #1, #0x1f
    // 0x12f3f2c: cmp             x5, x0
    // 0x12f3f30: b.lt            #0x12f3f58
    // 0x12f3f34: r0 = BoxInt64Instr(r5)
    //     0x12f3f34: sbfiz           x0, x5, #1, #0x1f
    //     0x12f3f38: cmp             x5, x0, asr #1
    //     0x12f3f3c: b.eq            #0x12f3f48
    //     0x12f3f40: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f3f44: stur            x5, [x0, #7]
    // 0x12f3f48: str             x0, [SP]
    // 0x12f3f4c: mov             x1, x3
    // 0x12f3f50: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x12f3f50: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x12f3f54: r0 = _resize()
    //     0x12f3f54: bl              #0x12f264c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0x12f3f58: ldur            x4, [fp, #-0x18]
    // 0x12f3f5c: LoadField: r5 = r4->field_7
    //     0x12f3f5c: ldur            w5, [x4, #7]
    // 0x12f3f60: DecompressPointer r5
    //     0x12f3f60: add             x5, x5, HEAP, lsl #32
    // 0x12f3f64: stur            x5, [fp, #-0x30]
    // 0x12f3f68: LoadField: r6 = r4->field_b
    //     0x12f3f68: ldur            x6, [x4, #0xb]
    // 0x12f3f6c: stur            x6, [fp, #-0x28]
    // 0x12f3f70: tbz             x6, #0x3f, #0x12f3f7c
    // 0x12f3f74: ldur            x7, [fp, #-8]
    // 0x12f3f78: b               #0x12f3f98
    // 0x12f3f7c: ldur            x7, [fp, #-8]
    // 0x12f3f80: cmp             x6, x7
    // 0x12f3f84: b.gt            #0x12f3f98
    // 0x12f3f88: LoadField: r0 = r5->field_13
    //     0x12f3f88: ldur            w0, [x5, #0x13]
    // 0x12f3f8c: r1 = LoadInt32Instr(r0)
    //     0x12f3f8c: sbfx            x1, x0, #1, #0x1f
    // 0x12f3f90: cmp             x7, x1
    // 0x12f3f94: b.le            #0x12f3fc4
    // 0x12f3f98: LoadField: r2 = r5->field_13
    //     0x12f3f98: ldur            w2, [x5, #0x13]
    // 0x12f3f9c: r0 = BoxInt64Instr(r7)
    //     0x12f3f9c: sbfiz           x0, x7, #1, #0x1f
    //     0x12f3fa0: cmp             x7, x0, asr #1
    //     0x12f3fa4: b.eq            #0x12f3fb0
    //     0x12f3fa8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f3fac: stur            x7, [x0, #7]
    // 0x12f3fb0: r3 = LoadInt32Instr(r2)
    //     0x12f3fb0: sbfx            x3, x2, #1, #0x1f
    // 0x12f3fb4: mov             x1, x6
    // 0x12f3fb8: mov             x2, x0
    // 0x12f3fbc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x12f3fbc: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x12f3fc0: r0 = checkValidRange()
    //     0x12f3fc0: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x12f3fc4: ldur            x2, [fp, #-0x20]
    // 0x12f3fc8: r0 = LoadClassIdInstr(r2)
    //     0x12f3fc8: ldur            x0, [x2, #-1]
    //     0x12f3fcc: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3fd0: mov             x1, x2
    // 0x12f3fd4: r0 = GDT[cid_x0 + -0x7f5]()
    //     0x12f3fd4: sub             lr, x0, #0x7f5
    //     0x12f3fd8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3fdc: blr             lr
    // 0x12f3fe0: cmp             x0, #1
    // 0x12f3fe4: b.ne            #0x12f41ac
    // 0x12f3fe8: ldur            x5, [fp, #-0x20]
    // 0x12f3fec: ldur            x3, [fp, #-8]
    // 0x12f3ff0: ldur            x2, [fp, #-0x28]
    // 0x12f3ff4: sub             x1, x3, x2
    // 0x12f3ff8: stur            x1, [fp, #-0x38]
    // 0x12f3ffc: r0 = LoadClassIdInstr(r5)
    //     0x12f3ffc: ldur            x0, [x5, #-1]
    //     0x12f4000: ubfx            x0, x0, #0xc, #0x14
    // 0x12f4004: str             x5, [SP]
    // 0x12f4008: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f4008: mov             x17, #0xf078
    //     0x12f400c: add             lr, x0, x17
    //     0x12f4010: ldr             lr, [x21, lr, lsl #3]
    //     0x12f4014: blr             lr
    // 0x12f4018: r1 = LoadInt32Instr(r0)
    //     0x12f4018: sbfx            x1, x0, #1, #0x1f
    //     0x12f401c: tbz             w0, #0, #0x12f4024
    //     0x12f4020: ldur            x1, [x0, #7]
    // 0x12f4024: ldur            x2, [fp, #-0x38]
    // 0x12f4028: cmp             x1, x2
    // 0x12f402c: b.lt            #0x12f41f0
    // 0x12f4030: cbz             x2, #0x12f41cc
    // 0x12f4034: r0 = BoxInt64Instr(r2)
    //     0x12f4034: sbfiz           x0, x2, #1, #0x1f
    //     0x12f4038: cmp             x2, x0, asr #1
    //     0x12f403c: b.eq            #0x12f4048
    //     0x12f4040: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f4044: stur            x2, [x0, #7]
    // 0x12f4048: mov             x3, x0
    // 0x12f404c: cmp             w3, #0x800
    // 0x12f4050: b.ge            #0x12f4148
    // 0x12f4054: ldur            x5, [fp, #-0x20]
    // 0x12f4058: ldur            x6, [fp, #-0x30]
    // 0x12f405c: ldur            x4, [fp, #-0x28]
    // 0x12f4060: r0 = BoxInt64Instr(r4)
    //     0x12f4060: sbfiz           x0, x4, #1, #0x1f
    //     0x12f4064: cmp             x4, x0, asr #1
    //     0x12f4068: b.eq            #0x12f4074
    //     0x12f406c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f4070: stur            x4, [x0, #7]
    // 0x12f4074: LoadField: r1 = r5->field_7
    //     0x12f4074: ldur            x1, [x5, #7]
    // 0x12f4078: mov             x4, x3
    // 0x12f407c: mov             x3, x1
    // 0x12f4080: sxtw            x0, w0
    // 0x12f4084: add             x2, x6, x0, asr #1
    // 0x12f4088: add             x2, x2, #0x17
    // 0x12f408c: cbz             x4, #0x12f4144
    // 0x12f4090: cmp             x2, x3
    // 0x12f4094: b.ls            #0x12f40fc
    // 0x12f4098: sxtw            x4, w4
    // 0x12f409c: add             x16, x3, x4, asr #1
    // 0x12f40a0: cmp             x2, x16
    // 0x12f40a4: b.hs            #0x12f40fc
    // 0x12f40a8: mov             x3, x16
    // 0x12f40ac: add             x2, x2, x4, asr #1
    // 0x12f40b0: tbz             w4, #4, #0x12f40bc
    // 0x12f40b4: ldr             x16, [x3, #-8]!
    // 0x12f40b8: str             x16, [x2, #-8]!
    // 0x12f40bc: tbz             w4, #3, #0x12f40c8
    // 0x12f40c0: ldr             w16, [x3, #-4]!
    // 0x12f40c4: str             w16, [x2, #-4]!
    // 0x12f40c8: tbz             w4, #2, #0x12f40d4
    // 0x12f40cc: ldrh            w16, [x3, #-2]!
    // 0x12f40d0: strh            w16, [x2, #-2]!
    // 0x12f40d4: tbz             w4, #1, #0x12f40e0
    // 0x12f40d8: ldrb            w16, [x3, #-1]!
    // 0x12f40dc: strb            w16, [x2, #-1]!
    // 0x12f40e0: ands            w4, w4, #0xffffffe1
    // 0x12f40e4: b.eq            #0x12f4144
    // 0x12f40e8: ldp             x16, x17, [x3, #-0x10]!
    // 0x12f40ec: stp             x16, x17, [x2, #-0x10]!
    // 0x12f40f0: subs            w4, w4, #0x20
    // 0x12f40f4: b.ne            #0x12f40e8
    // 0x12f40f8: b               #0x12f4144
    // 0x12f40fc: tbz             w4, #4, #0x12f4108
    // 0x12f4100: ldr             x16, [x3], #8
    // 0x12f4104: str             x16, [x2], #8
    // 0x12f4108: tbz             w4, #3, #0x12f4114
    // 0x12f410c: ldr             w16, [x3], #4
    // 0x12f4110: str             w16, [x2], #4
    // 0x12f4114: tbz             w4, #2, #0x12f4120
    // 0x12f4118: ldrh            w16, [x3], #2
    // 0x12f411c: strh            w16, [x2], #2
    // 0x12f4120: tbz             w4, #1, #0x12f412c
    // 0x12f4124: ldrb            w16, [x3], #1
    // 0x12f4128: strb            w16, [x2], #1
    // 0x12f412c: ands            w4, w4, #0xffffffe1
    // 0x12f4130: b.eq            #0x12f4144
    // 0x12f4134: ldp             x16, x17, [x3], #0x10
    // 0x12f4138: stp             x16, x17, [x2], #0x10
    // 0x12f413c: subs            w4, w4, #0x20
    // 0x12f4140: b.ne            #0x12f4134
    // 0x12f4144: b               #0x12f41cc
    // 0x12f4148: ldur            x5, [fp, #-0x20]
    // 0x12f414c: ldur            x6, [fp, #-0x30]
    // 0x12f4150: ldur            x4, [fp, #-0x28]
    // 0x12f4154: LoadField: r0 = r6->field_7
    //     0x12f4154: ldur            x0, [x6, #7]
    // 0x12f4158: add             x1, x0, x4
    // 0x12f415c: LoadField: r0 = r5->field_7
    //     0x12f415c: ldur            x0, [x5, #7]
    // 0x12f4160: CallRuntime_MemoryMove(void*, const void*, size_t) -> void*
    //     0x12f4160: mov             x3, THR
    //     0x12f4164: ldr             x9, [x3, #0x888]
    //     0x12f4168: mov             x16, x0
    //     0x12f416c: mov             x0, x1
    //     0x12f4170: mov             x1, x16
    //     0x12f4174: mov             x17, fp
    //     0x12f4178: str             fp, [SP, #-8]!
    //     0x12f417c: mov             fp, SP
    //     0x12f4180: and             SP, SP, #0xfffffffffffffff0
    //     0x12f4184: mov             x19, sp
    //     0x12f4188: mov             sp, SP
    //     0x12f418c: str             x9, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f4190: blr             x9
    //     0x12f4194: mov             x16, #8
    //     0x12f4198: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f419c: mov             sp, x19
    //     0x12f41a0: mov             SP, fp
    //     0x12f41a4: ldr             fp, [SP], #8
    // 0x12f41a8: b               #0x12f41cc
    // 0x12f41ac: ldur            x5, [fp, #-0x20]
    // 0x12f41b0: ldur            x3, [fp, #-8]
    // 0x12f41b4: ldur            x6, [fp, #-0x30]
    // 0x12f41b8: ldur            x4, [fp, #-0x28]
    // 0x12f41bc: mov             x1, x6
    // 0x12f41c0: mov             x2, x4
    // 0x12f41c4: r6 = 0
    //     0x12f41c4: mov             x6, #0
    // 0x12f41c8: r0 = _slowSetRange()
    //     0x12f41c8: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x12f41cc: ldur            x0, [fp, #-0x18]
    // 0x12f41d0: ldur            x1, [fp, #-0x10]
    // 0x12f41d4: LoadField: r2 = r0->field_b
    //     0x12f41d4: ldur            x2, [x0, #0xb]
    // 0x12f41d8: add             x3, x2, x1
    // 0x12f41dc: StoreField: r0->field_b = r3
    //     0x12f41dc: stur            x3, [x0, #0xb]
    // 0x12f41e0: r0 = Null
    //     0x12f41e0: mov             x0, NULL
    // 0x12f41e4: LeaveFrame
    //     0x12f41e4: mov             SP, fp
    //     0x12f41e8: ldp             fp, lr, [SP], #0x10
    // 0x12f41ec: ret
    //     0x12f41ec: ret             
    // 0x12f41f0: r0 = tooFew()
    //     0x12f41f0: bl              #0x7e9534  ; [dart:_internal] IterableElementError::tooFew
    // 0x12f41f4: r0 = Throw()
    //     0x12f41f4: bl              #0x13ddb2c  ; ThrowStub
    // 0x12f41f8: brk             #0
    // 0x12f41fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f41fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f4200: b               #0x12f3f04
  }
  _ putUint32(/* No info */) {
    // ** addr: 0x12f429c, size: 0x94
    // 0x12f429c: EnterFrame
    //     0x12f429c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f42a0: mov             fp, SP
    // 0x12f42a4: AllocStack(0x8)
    //     0x12f42a4: sub             SP, SP, #8
    // 0x12f42a8: SetupParameters(WriteBuffer this /* r1 => r3 */)
    //     0x12f42a8: mov             x3, x1
    // 0x12f42ac: CheckStackOverflow
    //     0x12f42ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f42b0: cmp             SP, x16
    //     0x12f42b4: b.ls            #0x12f4324
    // 0x12f42b8: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12f42b8: ldur            w4, [x3, #0x17]
    // 0x12f42bc: DecompressPointer r4
    //     0x12f42bc: add             x4, x4, HEAP, lsl #32
    // 0x12f42c0: LoadField: r0 = r4->field_13
    //     0x12f42c0: ldur            w0, [x4, #0x13]
    // 0x12f42c4: r1 = LoadInt32Instr(r0)
    //     0x12f42c4: sbfx            x1, x0, #1, #0x1f
    // 0x12f42c8: mov             x0, x1
    // 0x12f42cc: r1 = 3
    //     0x12f42cc: mov             x1, #3
    // 0x12f42d0: cmp             x1, x0
    // 0x12f42d4: b.hs            #0x12f432c
    // 0x12f42d8: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12f42d8: ldur            w0, [x4, #0x17]
    // 0x12f42dc: DecompressPointer r0
    //     0x12f42dc: add             x0, x0, HEAP, lsl #32
    // 0x12f42e0: LoadField: r1 = r4->field_1b
    //     0x12f42e0: ldur            w1, [x4, #0x1b]
    // 0x12f42e4: ubfx            x2, x2, #0, #0x20
    // 0x12f42e8: LoadField: r4 = r0->field_7
    //     0x12f42e8: ldur            x4, [x0, #7]
    // 0x12f42ec: asr             w0, w1, #1
    // 0x12f42f0: add             x0, x4, w0, sxtw
    // 0x12f42f4: str             w2, [x0]
    // 0x12f42f8: LoadField: r2 = r3->field_1b
    //     0x12f42f8: ldur            w2, [x3, #0x1b]
    // 0x12f42fc: DecompressPointer r2
    //     0x12f42fc: add             x2, x2, HEAP, lsl #32
    // 0x12f4300: r16 = 8
    //     0x12f4300: mov             x16, #8
    // 0x12f4304: str             x16, [SP]
    // 0x12f4308: mov             x1, x3
    // 0x12f430c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f430c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f4310: r0 = _addAll()
    //     0x12f4310: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f4314: r0 = Null
    //     0x12f4314: mov             x0, NULL
    // 0x12f4318: LeaveFrame
    //     0x12f4318: mov             SP, fp
    //     0x12f431c: ldp             fp, lr, [SP], #0x10
    // 0x12f4320: ret
    //     0x12f4320: ret             
    // 0x12f4324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f4324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f4328: b               #0x12f42b8
    // 0x12f432c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f432c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ putUint16(/* No info */) {
    // ** addr: 0x12f4330, size: 0x90
    // 0x12f4330: EnterFrame
    //     0x12f4330: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4334: mov             fp, SP
    // 0x12f4338: AllocStack(0x8)
    //     0x12f4338: sub             SP, SP, #8
    // 0x12f433c: SetupParameters(WriteBuffer this /* r1 => r3 */)
    //     0x12f433c: mov             x3, x1
    // 0x12f4340: CheckStackOverflow
    //     0x12f4340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4344: cmp             SP, x16
    //     0x12f4348: b.ls            #0x12f43b4
    // 0x12f434c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12f434c: ldur            w4, [x3, #0x17]
    // 0x12f4350: DecompressPointer r4
    //     0x12f4350: add             x4, x4, HEAP, lsl #32
    // 0x12f4354: LoadField: r0 = r4->field_13
    //     0x12f4354: ldur            w0, [x4, #0x13]
    // 0x12f4358: r1 = LoadInt32Instr(r0)
    //     0x12f4358: sbfx            x1, x0, #1, #0x1f
    // 0x12f435c: mov             x0, x1
    // 0x12f4360: r1 = 1
    //     0x12f4360: mov             x1, #1
    // 0x12f4364: cmp             x1, x0
    // 0x12f4368: b.hs            #0x12f43bc
    // 0x12f436c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12f436c: ldur            w0, [x4, #0x17]
    // 0x12f4370: DecompressPointer r0
    //     0x12f4370: add             x0, x0, HEAP, lsl #32
    // 0x12f4374: LoadField: r1 = r4->field_1b
    //     0x12f4374: ldur            w1, [x4, #0x1b]
    // 0x12f4378: LoadField: r4 = r0->field_7
    //     0x12f4378: ldur            x4, [x0, #7]
    // 0x12f437c: asr             w0, w1, #1
    // 0x12f4380: add             x0, x4, w0, sxtw
    // 0x12f4384: strh            w2, [x0]
    // 0x12f4388: LoadField: r2 = r3->field_1b
    //     0x12f4388: ldur            w2, [x3, #0x1b]
    // 0x12f438c: DecompressPointer r2
    //     0x12f438c: add             x2, x2, HEAP, lsl #32
    // 0x12f4390: r16 = 4
    //     0x12f4390: mov             x16, #4
    // 0x12f4394: str             x16, [SP]
    // 0x12f4398: mov             x1, x3
    // 0x12f439c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f439c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f43a0: r0 = _addAll()
    //     0x12f43a0: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f43a4: r0 = Null
    //     0x12f43a4: mov             x0, NULL
    // 0x12f43a8: LeaveFrame
    //     0x12f43a8: mov             SP, fp
    //     0x12f43ac: ldp             fp, lr, [SP], #0x10
    // 0x12f43b0: ret
    //     0x12f43b0: ret             
    // 0x12f43b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f43b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f43b8: b               #0x12f434c
    // 0x12f43bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f43bc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ putInt32(/* No info */) {
    // ** addr: 0x12f43c0, size: 0x94
    // 0x12f43c0: EnterFrame
    //     0x12f43c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f43c4: mov             fp, SP
    // 0x12f43c8: AllocStack(0x8)
    //     0x12f43c8: sub             SP, SP, #8
    // 0x12f43cc: SetupParameters(WriteBuffer this /* r1 => r3 */)
    //     0x12f43cc: mov             x3, x1
    // 0x12f43d0: CheckStackOverflow
    //     0x12f43d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f43d4: cmp             SP, x16
    //     0x12f43d8: b.ls            #0x12f4448
    // 0x12f43dc: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12f43dc: ldur            w4, [x3, #0x17]
    // 0x12f43e0: DecompressPointer r4
    //     0x12f43e0: add             x4, x4, HEAP, lsl #32
    // 0x12f43e4: LoadField: r0 = r4->field_13
    //     0x12f43e4: ldur            w0, [x4, #0x13]
    // 0x12f43e8: r1 = LoadInt32Instr(r0)
    //     0x12f43e8: sbfx            x1, x0, #1, #0x1f
    // 0x12f43ec: mov             x0, x1
    // 0x12f43f0: r1 = 3
    //     0x12f43f0: mov             x1, #3
    // 0x12f43f4: cmp             x1, x0
    // 0x12f43f8: b.hs            #0x12f4450
    // 0x12f43fc: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x12f43fc: ldur            w0, [x4, #0x17]
    // 0x12f4400: DecompressPointer r0
    //     0x12f4400: add             x0, x0, HEAP, lsl #32
    // 0x12f4404: LoadField: r1 = r4->field_1b
    //     0x12f4404: ldur            w1, [x4, #0x1b]
    // 0x12f4408: sxtw            x2, w2
    // 0x12f440c: LoadField: r4 = r0->field_7
    //     0x12f440c: ldur            x4, [x0, #7]
    // 0x12f4410: asr             w0, w1, #1
    // 0x12f4414: add             x0, x4, w0, sxtw
    // 0x12f4418: str             w2, [x0]
    // 0x12f441c: LoadField: r2 = r3->field_1b
    //     0x12f441c: ldur            w2, [x3, #0x1b]
    // 0x12f4420: DecompressPointer r2
    //     0x12f4420: add             x2, x2, HEAP, lsl #32
    // 0x12f4424: r16 = 8
    //     0x12f4424: mov             x16, #8
    // 0x12f4428: str             x16, [SP]
    // 0x12f442c: mov             x1, x3
    // 0x12f4430: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f4430: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f4434: r0 = _addAll()
    //     0x12f4434: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f4438: r0 = Null
    //     0x12f4438: mov             x0, NULL
    // 0x12f443c: LeaveFrame
    //     0x12f443c: mov             SP, fp
    //     0x12f4440: ldp             fp, lr, [SP], #0x10
    // 0x12f4444: ret
    //     0x12f4444: ret             
    // 0x12f4448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f4448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f444c: b               #0x12f43dc
    // 0x12f4450: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f4450: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ putFloat64(/* No info */) {
    // ** addr: 0x12f4454, size: 0xa8
    // 0x12f4454: EnterFrame
    //     0x12f4454: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4458: mov             fp, SP
    // 0x12f445c: AllocStack(0x10)
    //     0x12f445c: sub             SP, SP, #0x10
    // 0x12f4460: SetupParameters(WriteBuffer this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0x12f4460: mov             x0, x1
    //     0x12f4464: stur            x1, [fp, #-8]
    //     0x12f4468: stur            d0, [fp, #-0x10]
    // 0x12f446c: CheckStackOverflow
    //     0x12f446c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4470: cmp             SP, x16
    //     0x12f4474: b.ls            #0x12f44f0
    // 0x12f4478: mov             x1, x0
    // 0x12f447c: r2 = 8
    //     0x12f447c: mov             x2, #8
    // 0x12f4480: r0 = _alignTo()
    //     0x12f4480: bl              #0x12f3d20  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0x12f4484: ldur            x2, [fp, #-8]
    // 0x12f4488: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x12f4488: ldur            w3, [x2, #0x17]
    // 0x12f448c: DecompressPointer r3
    //     0x12f448c: add             x3, x3, HEAP, lsl #32
    // 0x12f4490: LoadField: r0 = r3->field_13
    //     0x12f4490: ldur            w0, [x3, #0x13]
    // 0x12f4494: r1 = LoadInt32Instr(r0)
    //     0x12f4494: sbfx            x1, x0, #1, #0x1f
    // 0x12f4498: mov             x0, x1
    // 0x12f449c: r1 = 7
    //     0x12f449c: mov             x1, #7
    // 0x12f44a0: cmp             x1, x0
    // 0x12f44a4: b.hs            #0x12f44f8
    // 0x12f44a8: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x12f44a8: ldur            w0, [x3, #0x17]
    // 0x12f44ac: DecompressPointer r0
    //     0x12f44ac: add             x0, x0, HEAP, lsl #32
    // 0x12f44b0: LoadField: r1 = r3->field_1b
    //     0x12f44b0: ldur            w1, [x3, #0x1b]
    // 0x12f44b4: LoadField: r3 = r0->field_7
    //     0x12f44b4: ldur            x3, [x0, #7]
    // 0x12f44b8: ldur            d0, [fp, #-0x10]
    // 0x12f44bc: asr             w0, w1, #1
    // 0x12f44c0: add             x0, x3, w0, sxtw
    // 0x12f44c4: str             d0, [x0]
    // 0x12f44c8: LoadField: r0 = r2->field_1b
    //     0x12f44c8: ldur            w0, [x2, #0x1b]
    // 0x12f44cc: DecompressPointer r0
    //     0x12f44cc: add             x0, x0, HEAP, lsl #32
    // 0x12f44d0: mov             x1, x2
    // 0x12f44d4: mov             x2, x0
    // 0x12f44d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12f44d8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12f44dc: r0 = _addAll()
    //     0x12f44dc: bl              #0x12f22f0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0x12f44e0: r0 = Null
    //     0x12f44e0: mov             x0, NULL
    // 0x12f44e4: LeaveFrame
    //     0x12f44e4: mov             SP, fp
    //     0x12f44e8: ldp             fp, lr, [SP], #0x10
    // 0x12f44ec: ret
    //     0x12f44ec: ret             
    // 0x12f44f0: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f44f0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f44f4: b               #0x12f4478
    // 0x12f44f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f44f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}
