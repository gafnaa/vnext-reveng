// lib: , url: package:flutter/src/foundation/_error_dumper_io.dart

// class id: 1048793, size: 0x8
class :: {
}

// class id: 3245, size: 0x8, field offset: 0x8
abstract class ErrorToConsoleDumper extends Object {

  static void dump(String) {
    // ** addr: 0x829f00, size: 0x60
    // 0x829f00: EnterFrame
    //     0x829f00: stp             fp, lr, [SP, #-0x10]!
    //     0x829f04: mov             fp, SP
    // 0x829f08: AllocStack(0x10)
    //     0x829f08: sub             SP, SP, #0x10
    // 0x829f0c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x829f0c: stur            x1, [fp, #-8]
    // 0x829f10: CheckStackOverflow
    //     0x829f10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829f14: cmp             SP, x16
    //     0x829f18: b.ls            #0x829f58
    // 0x829f1c: r0 = LoadStaticField(0x7e0)
    //     0x829f1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x829f20: ldr             x0, [x0, #0xfc0]
    // 0x829f24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x829f28: cmp             w0, w16
    // 0x829f2c: b.ne            #0x829f38
    // 0x829f30: r2 = debugPrint
    //     0x829f30: ldr             x2, [PP, #0x8a8]  ; [pp+0x8a8] Field <::.debugPrint>: static late (offset: 0x7e0)
    // 0x829f34: r0 = InitLateStaticField()
    //     0x829f34: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x829f38: str             NULL, [SP]
    // 0x829f3c: ldur            x1, [fp, #-8]
    // 0x829f40: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x829f40: ldr             x4, [PP, #0x8b0]  ; [pp+0x8b0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x829f44: r0 = debugPrintThrottled()
    //     0x829f44: bl              #0x829fdc  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x829f48: r0 = Null
    //     0x829f48: mov             x0, NULL
    // 0x829f4c: LeaveFrame
    //     0x829f4c: mov             SP, fp
    //     0x829f50: ldp             fp, lr, [SP], #0x10
    // 0x829f54: ret
    //     0x829f54: ret             
    // 0x829f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829f5c: b               #0x829f1c
  }
}
