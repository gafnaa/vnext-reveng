// lib: , url: package:flutter/src/foundation/print.dart

// class id: 1048810, size: 0x8
class :: {

  static late (dynamic, String?, {int? wrapWidth}) => void debugPrint; // offset: 0x7e0
  static late final Queue<String> _debugPrintBuffer; // offset: 0x7e8
  static late final RegExp _indentPattern; // offset: 0x7f8
  static late final Stopwatch _debugPrintStopwatch; // offset: 0x7ec

  [closure] static void debugPrintThrottled(dynamic, String?, {int? wrapWidth}) {
    // ** addr: 0x829f60, size: 0x7c
    // 0x829f60: EnterFrame
    //     0x829f60: stp             fp, lr, [SP, #-0x10]!
    //     0x829f64: mov             fp, SP
    // 0x829f68: AllocStack(0x8)
    //     0x829f68: sub             SP, SP, #8
    // 0x829f6c: SetupParameters(dynamic _ /* r2 */, {dynamic wrapWidth = Null /* r0 */})
    //     0x829f6c: ldur            w0, [x4, #0x13]
    //     0x829f70: sub             x1, x0, #4
    //     0x829f74: add             x2, fp, w1, sxtw #2
    //     0x829f78: ldr             x2, [x2, #0x10]
    //     0x829f7c: ldur            w1, [x4, #0x1f]
    //     0x829f80: add             x1, x1, HEAP, lsl #32
    //     0x829f84: ldr             x16, [PP, #0x8b8]  ; [pp+0x8b8] "wrapWidth"
    //     0x829f88: cmp             w1, w16
    //     0x829f8c: b.ne            #0x829fa8
    //     0x829f90: ldur            w1, [x4, #0x23]
    //     0x829f94: add             x1, x1, HEAP, lsl #32
    //     0x829f98: sub             w3, w0, w1
    //     0x829f9c: add             x0, fp, w3, sxtw #2
    //     0x829fa0: ldr             x0, [x0, #8]
    //     0x829fa4: b               #0x829fac
    //     0x829fa8: mov             x0, NULL
    // 0x829fac: CheckStackOverflow
    //     0x829fac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829fb0: cmp             SP, x16
    //     0x829fb4: b.ls            #0x829fd4
    // 0x829fb8: str             x0, [SP]
    // 0x829fbc: mov             x1, x2
    // 0x829fc0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x829fc0: ldr             x4, [PP, #0x8b0]  ; [pp+0x8b0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x829fc4: r0 = debugPrintThrottled()
    //     0x829fc4: bl              #0x829fdc  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x829fc8: LeaveFrame
    //     0x829fc8: mov             SP, fp
    //     0x829fcc: ldp             fp, lr, [SP], #0x10
    // 0x829fd0: ret
    //     0x829fd0: ret             
    // 0x829fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829fd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829fd8: b               #0x829fb8
  }
  static _ debugPrintThrottled(/* No info */) {
    // ** addr: 0x829fdc, size: 0x198
    // 0x829fdc: EnterFrame
    //     0x829fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x829fe0: mov             fp, SP
    // 0x829fe4: AllocStack(0x30)
    //     0x829fe4: sub             SP, SP, #0x30
    // 0x829fe8: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, {dynamic wrapWidth = Null /* r0, fp-0x8 */})
    //     0x829fe8: stur            x1, [fp, #-0x10]
    //     0x829fec: ldur            w0, [x4, #0x13]
    //     0x829ff0: ldur            w2, [x4, #0x1f]
    //     0x829ff4: add             x2, x2, HEAP, lsl #32
    //     0x829ff8: ldr             x16, [PP, #0x8b8]  ; [pp+0x8b8] "wrapWidth"
    //     0x829ffc: cmp             w2, w16
    //     0x82a000: b.ne            #0x82a01c
    //     0x82a004: ldur            w2, [x4, #0x23]
    //     0x82a008: add             x2, x2, HEAP, lsl #32
    //     0x82a00c: sub             w3, w0, w2
    //     0x82a010: add             x0, fp, w3, sxtw #2
    //     0x82a014: ldr             x0, [x0, #8]
    //     0x82a018: b               #0x82a020
    //     0x82a01c: mov             x0, NULL
    //     0x82a020: stur            x0, [fp, #-8]
    // 0x82a024: CheckStackOverflow
    //     0x82a024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a028: cmp             SP, x16
    //     0x82a02c: b.ls            #0x82a16c
    // 0x82a030: r1 = 1
    //     0x82a030: mov             x1, #1
    // 0x82a034: r0 = AllocateContext()
    //     0x82a034: bl              #0x13de838  ; AllocateContextStub
    // 0x82a038: mov             x3, x0
    // 0x82a03c: ldur            x0, [fp, #-8]
    // 0x82a040: stur            x3, [fp, #-0x18]
    // 0x82a044: StoreField: r3->field_f = r0
    //     0x82a044: stur            w0, [x3, #0xf]
    // 0x82a048: ldur            x1, [fp, #-0x10]
    // 0x82a04c: cmp             w1, NULL
    // 0x82a050: b.ne            #0x82a05c
    // 0x82a054: r0 = Null
    //     0x82a054: mov             x0, NULL
    // 0x82a058: b               #0x82a074
    // 0x82a05c: r0 = LoadClassIdInstr(r1)
    //     0x82a05c: ldur            x0, [x1, #-1]
    //     0x82a060: ubfx            x0, x0, #0xc, #0x14
    // 0x82a064: r2 = "\n"
    //     0x82a064: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x82a068: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82a068: sub             lr, x0, #0xffe
    //     0x82a06c: ldr             lr, [x21, lr, lsl #3]
    //     0x82a070: blr             lr
    // 0x82a074: cmp             w0, NULL
    // 0x82a078: b.ne            #0x82a0b8
    // 0x82a07c: r0 = 2
    //     0x82a07c: mov             x0, #2
    // 0x82a080: mov             x2, x0
    // 0x82a084: r1 = Null
    //     0x82a084: mov             x1, NULL
    // 0x82a088: r0 = AllocateArray()
    //     0x82a088: bl              #0x13df928  ; AllocateArrayStub
    // 0x82a08c: stur            x0, [fp, #-8]
    // 0x82a090: r16 = "null"
    //     0x82a090: ldr             x16, [PP, #0x8c8]  ; [pp+0x8c8] "null"
    // 0x82a094: StoreField: r0->field_f = r16
    //     0x82a094: stur            w16, [x0, #0xf]
    // 0x82a098: r1 = <String>
    //     0x82a098: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82a09c: r0 = AllocateGrowableArray()
    //     0x82a09c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x82a0a0: mov             x1, x0
    // 0x82a0a4: ldur            x0, [fp, #-8]
    // 0x82a0a8: StoreField: r1->field_f = r0
    //     0x82a0a8: stur            w0, [x1, #0xf]
    // 0x82a0ac: r0 = 2
    //     0x82a0ac: mov             x0, #2
    // 0x82a0b0: StoreField: r1->field_b = r0
    //     0x82a0b0: stur            w0, [x1, #0xb]
    // 0x82a0b4: mov             x0, x1
    // 0x82a0b8: ldur            x2, [fp, #-0x18]
    // 0x82a0bc: stur            x0, [fp, #-8]
    // 0x82a0c0: LoadField: r1 = r2->field_f
    //     0x82a0c0: ldur            w1, [x2, #0xf]
    // 0x82a0c4: DecompressPointer r1
    //     0x82a0c4: add             x1, x1, HEAP, lsl #32
    // 0x82a0c8: cmp             w1, NULL
    // 0x82a0cc: b.eq            #0x82a124
    // 0x82a0d0: r0 = LoadStaticField(0x7e8)
    //     0x82a0d0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a0d4: ldr             x0, [x0, #0xfd0]
    // 0x82a0d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a0dc: cmp             w0, w16
    // 0x82a0e0: b.ne            #0x82a0ec
    // 0x82a0e4: r2 = _debugPrintBuffer
    //     0x82a0e4: ldr             x2, [PP, #0x8d8]  ; [pp+0x8d8] Field <::._debugPrintBuffer@157110992>: static late final (offset: 0x7e8)
    // 0x82a0e8: r0 = InitLateFinalStaticField()
    //     0x82a0e8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82a0ec: ldur            x2, [fp, #-0x18]
    // 0x82a0f0: r1 = Function '<anonymous closure>': static.
    //     0x82a0f0: ldr             x1, [PP, #0x8e0]  ; [pp+0x8e0] AnonymousClosure: static (0x82af28), in [package:flutter/src/foundation/print.dart] ::debugPrintThrottled (0x829fdc)
    // 0x82a0f4: stur            x0, [fp, #-0x10]
    // 0x82a0f8: r0 = AllocateClosure()
    //     0x82a0f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x82a0fc: r16 = <String>
    //     0x82a0fc: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82a100: ldur            lr, [fp, #-8]
    // 0x82a104: stp             lr, x16, [SP, #8]
    // 0x82a108: str             x0, [SP]
    // 0x82a10c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82a10c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82a110: r0 = expand()
    //     0x82a110: bl              #0x82aea0  ; [dart:collection] ListBase::expand
    // 0x82a114: ldur            x1, [fp, #-0x10]
    // 0x82a118: mov             x2, x0
    // 0x82a11c: r0 = addAll()
    //     0x82a11c: bl              #0x8d1f9c  ; [dart:collection] ListQueue::addAll
    // 0x82a120: b               #0x82a14c
    // 0x82a124: r0 = LoadStaticField(0x7e8)
    //     0x82a124: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a128: ldr             x0, [x0, #0xfd0]
    // 0x82a12c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a130: cmp             w0, w16
    // 0x82a134: b.ne            #0x82a140
    // 0x82a138: r2 = _debugPrintBuffer
    //     0x82a138: ldr             x2, [PP, #0x8d8]  ; [pp+0x8d8] Field <::._debugPrintBuffer@157110992>: static late final (offset: 0x7e8)
    // 0x82a13c: r0 = InitLateFinalStaticField()
    //     0x82a13c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82a140: mov             x1, x0
    // 0x82a144: ldur            x2, [fp, #-8]
    // 0x82a148: r0 = addAll()
    //     0x82a148: bl              #0x8d1f9c  ; [dart:collection] ListQueue::addAll
    // 0x82a14c: r0 = LoadStaticField(0x7f4)
    //     0x82a14c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a150: ldr             x0, [x0, #0xfe8]
    // 0x82a154: tbz             w0, #4, #0x82a15c
    // 0x82a158: r0 = _debugPrintTask()
    //     0x82a158: bl              #0x82a174  ; [package:flutter/src/foundation/print.dart] ::_debugPrintTask
    // 0x82a15c: r0 = Null
    //     0x82a15c: mov             x0, NULL
    // 0x82a160: LeaveFrame
    //     0x82a160: mov             SP, fp
    //     0x82a164: ldp             fp, lr, [SP], #0x10
    // 0x82a168: ret
    //     0x82a168: ret             
    // 0x82a16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a170: b               #0x82a030
  }
  static void _debugPrintTask() {
    // ** addr: 0x82a174, size: 0x260
    // 0x82a174: EnterFrame
    //     0x82a174: stp             fp, lr, [SP, #-0x10]!
    //     0x82a178: mov             fp, SP
    // 0x82a17c: AllocStack(0x20)
    //     0x82a17c: sub             SP, SP, #0x20
    // 0x82a180: CheckStackOverflow
    //     0x82a180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a184: cmp             SP, x16
    //     0x82a188: b.ls            #0x82a3c4
    // 0x82a18c: r2 = false
    //     0x82a18c: add             x2, NULL, #0x30  ; false
    // 0x82a190: StoreStaticField(0x7f4, r2)
    //     0x82a190: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a194: str             x2, [x0, #0xfe8]
    // 0x82a198: r0 = LoadStaticField(0x7ec)
    //     0x82a198: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a19c: ldr             x0, [x0, #0xfd8]
    // 0x82a1a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a1a4: cmp             w0, w16
    // 0x82a1a8: b.ne            #0x82a1b4
    // 0x82a1ac: r2 = _debugPrintStopwatch
    //     0x82a1ac: ldr             x2, [PP, #0xa78]  ; [pp+0xa78] Field <::._debugPrintStopwatch@157110992>: static late final (offset: 0x7ec)
    // 0x82a1b0: r0 = InitLateFinalStaticField()
    //     0x82a1b0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82a1b4: mov             x1, x0
    // 0x82a1b8: stur            x0, [fp, #-8]
    // 0x82a1bc: r0 = elapsed()
    //     0x82a1bc: bl              #0x82ab6c  ; [dart:core] Stopwatch::elapsed
    // 0x82a1c0: LoadField: r1 = r0->field_7
    //     0x82a1c0: ldur            x1, [x0, #7]
    // 0x82a1c4: r17 = 1000000
    //     0x82a1c4: mov             x17, #0x4240
    //     0x82a1c8: movk            x17, #0xf, lsl #16
    // 0x82a1cc: cmp             x1, x17
    // 0x82a1d0: b.le            #0x82a1f0
    // 0x82a1d4: ldur            x1, [fp, #-8]
    // 0x82a1d8: r0 = stop()
    //     0x82a1d8: bl              #0x82ab00  ; [dart:core] Stopwatch::stop
    // 0x82a1dc: ldur            x1, [fp, #-8]
    // 0x82a1e0: r0 = reset()
    //     0x82a1e0: bl              #0x82aa8c  ; [dart:core] Stopwatch::reset
    // 0x82a1e4: r2 = 0
    //     0x82a1e4: mov             x2, #0
    // 0x82a1e8: StoreStaticField(0x7e4, r2)
    //     0x82a1e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a1ec: str             x2, [x0, #0xfc8]
    // 0x82a1f0: CheckStackOverflow
    //     0x82a1f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a1f4: cmp             SP, x16
    //     0x82a1f8: b.ls            #0x82a3cc
    // 0x82a1fc: r0 = LoadStaticField(0x7e4)
    //     0x82a1fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a200: ldr             x0, [x0, #0xfc8]
    // 0x82a204: r1 = LoadInt32Instr(r0)
    //     0x82a204: sbfx            x1, x0, #1, #0x1f
    //     0x82a208: tbz             w0, #0, #0x82a210
    //     0x82a20c: ldur            x1, [x0, #7]
    // 0x82a210: cmp             x1, #3, lsl #12
    // 0x82a214: b.ge            #0x82a2cc
    // 0x82a218: r0 = LoadStaticField(0x7e8)
    //     0x82a218: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a21c: ldr             x0, [x0, #0xfd0]
    // 0x82a220: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a224: cmp             w0, w16
    // 0x82a228: b.ne            #0x82a234
    // 0x82a22c: r2 = _debugPrintBuffer
    //     0x82a22c: ldr             x2, [PP, #0x8d8]  ; [pp+0x8d8] Field <::._debugPrintBuffer@157110992>: static late final (offset: 0x7e8)
    // 0x82a230: r0 = InitLateFinalStaticField()
    //     0x82a230: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82a234: LoadField: r1 = r0->field_f
    //     0x82a234: ldur            x1, [x0, #0xf]
    // 0x82a238: ArrayLoad: r2 = r0[0]  ; List_8
    //     0x82a238: ldur            x2, [x0, #0x17]
    // 0x82a23c: cmp             x1, x2
    // 0x82a240: b.eq            #0x82a2cc
    // 0x82a244: mov             x1, x0
    // 0x82a248: r0 = removeFirst()
    //     0x82a248: bl              #0x820d24  ; [dart:collection] ListQueue::removeFirst
    // 0x82a24c: mov             x3, x0
    // 0x82a250: r0 = LoadStaticField(0x7e4)
    //     0x82a250: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a254: ldr             x0, [x0, #0xfc8]
    // 0x82a258: LoadField: r1 = r3->field_7
    //     0x82a258: ldur            w1, [x3, #7]
    // 0x82a25c: r2 = LoadInt32Instr(r0)
    //     0x82a25c: sbfx            x2, x0, #1, #0x1f
    //     0x82a260: tbz             w0, #0, #0x82a268
    //     0x82a264: ldur            x2, [x0, #7]
    // 0x82a268: r0 = LoadInt32Instr(r1)
    //     0x82a268: sbfx            x0, x1, #1, #0x1f
    // 0x82a26c: add             x4, x2, x0
    // 0x82a270: r0 = BoxInt64Instr(r4)
    //     0x82a270: sbfiz           x0, x4, #1, #0x1f
    //     0x82a274: cmp             x4, x0, asr #1
    //     0x82a278: b.eq            #0x82a284
    //     0x82a27c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82a280: stur            x4, [x0, #7]
    // 0x82a284: mov             x2, x0
    // 0x82a288: StoreStaticField(0x7e4, r2)
    //     0x82a288: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a28c: str             x2, [x0, #0xfc8]
    // 0x82a290: str             x3, [SP]
    // 0x82a294: r0 = _interpolateSingle()
    //     0x82a294: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0x82a298: stur            x0, [fp, #-0x10]
    // 0x82a29c: r0 = printToZone()
    //     0x82a29c: bl              #0x82a5c8  ; [dart:_internal] ::printToZone
    // 0x82a2a0: cmp             w0, NULL
    // 0x82a2a4: b.ne            #0x82a2b4
    // 0x82a2a8: ldur            x1, [fp, #-0x10]
    // 0x82a2ac: r0 = printToConsole()
    //     0x82a2ac: bl              #0x82a560  ; [dart:_internal] ::printToConsole
    // 0x82a2b0: b               #0x82a1f0
    // 0x82a2b4: ldur            x16, [fp, #-0x10]
    // 0x82a2b8: stp             x16, x0, [SP]
    // 0x82a2bc: ClosureCall
    //     0x82a2bc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x82a2c0: ldur            x2, [x0, #0x1f]
    //     0x82a2c4: blr             x2
    // 0x82a2c8: b               #0x82a1f0
    // 0x82a2cc: r0 = LoadStaticField(0x7e8)
    //     0x82a2cc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a2d0: ldr             x0, [x0, #0xfd0]
    // 0x82a2d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a2d8: cmp             w0, w16
    // 0x82a2dc: b.ne            #0x82a2e8
    // 0x82a2e0: r2 = _debugPrintBuffer
    //     0x82a2e0: ldr             x2, [PP, #0x8d8]  ; [pp+0x8d8] Field <::._debugPrintBuffer@157110992>: static late final (offset: 0x7e8)
    // 0x82a2e4: r0 = InitLateFinalStaticField()
    //     0x82a2e4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82a2e8: mov             x1, x0
    // 0x82a2ec: r0 = isNotEmpty()
    //     0x82a2ec: bl              #0xb6f8c8  ; [dart:collection] ListBase::isNotEmpty
    // 0x82a2f0: tbnz            w0, #4, #0x82a388
    // 0x82a2f4: r2 = true
    //     0x82a2f4: add             x2, NULL, #0x20  ; true
    // 0x82a2f8: StoreStaticField(0x7f4, r2)
    //     0x82a2f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a2fc: str             x2, [x0, #0xfe8]
    // 0x82a300: r2 = 0
    //     0x82a300: mov             x2, #0
    // 0x82a304: StoreStaticField(0x7e4, r2)
    //     0x82a304: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a308: str             x2, [x0, #0xfc8]
    // 0x82a30c: r1 = Null
    //     0x82a30c: mov             x1, NULL
    // 0x82a310: r2 = Instance_Duration
    //     0x82a310: ldr             x2, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0x82a314: r3 = Closure: () => void from Function '_debugPrintTask@157110992': static.
    //     0x82a314: ldr             x3, [PP, #0xa88]  ; [pp+0xa88] Closure: () => void from Function '_debugPrintTask@157110992': static. (0x7f2ada71143c)
    // 0x82a318: r0 = Timer()
    //     0x82a318: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0x82a31c: r0 = LoadStaticField(0x7f0)
    //     0x82a31c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a320: ldr             x0, [x0, #0xfe0]
    // 0x82a324: cmp             w0, NULL
    // 0x82a328: b.ne            #0x82a3b4
    // 0x82a32c: r1 = <void?>
    //     0x82a32c: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x82a330: r0 = _Future()
    //     0x82a330: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x82a334: stur            x0, [fp, #-0x10]
    // 0x82a338: StoreField: r0->field_b = rZR
    //     0x82a338: stur            xzr, [x0, #0xb]
    // 0x82a33c: r0 = LoadStaticField(0x364)
    //     0x82a33c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a340: ldr             x0, [x0, #0x6c8]
    // 0x82a344: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82a348: cmp             w0, w16
    // 0x82a34c: b.ne            #0x82a358
    // 0x82a350: r2 = _current
    //     0x82a350: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x82a354: r0 = InitLateStaticField()
    //     0x82a354: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x82a358: mov             x1, x0
    // 0x82a35c: ldur            x0, [fp, #-0x10]
    // 0x82a360: StoreField: r0->field_13 = r1
    //     0x82a360: stur            w1, [x0, #0x13]
    // 0x82a364: r1 = <void?>
    //     0x82a364: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x82a368: r0 = _AsyncCompleter()
    //     0x82a368: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x82a36c: mov             x1, x0
    // 0x82a370: ldur            x0, [fp, #-0x10]
    // 0x82a374: StoreField: r1->field_b = r0
    //     0x82a374: stur            w0, [x1, #0xb]
    // 0x82a378: mov             x2, x1
    // 0x82a37c: StoreStaticField(0x7f0, r2)
    //     0x82a37c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82a380: str             x2, [x0, #0xfe0]
    // 0x82a384: b               #0x82a3b4
    // 0x82a388: ldur            x1, [fp, #-8]
    // 0x82a38c: r0 = start()
    //     0x82a38c: bl              #0x82a468  ; [dart:core] Stopwatch::start
    // 0x82a390: r1 = LoadStaticField(0x7f0)
    //     0x82a390: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x82a394: ldr             x1, [x1, #0xfe0]
    // 0x82a398: cmp             w1, NULL
    // 0x82a39c: b.eq            #0x82a3a8
    // 0x82a3a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82a3a0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82a3a4: r0 = complete()
    //     0x82a3a4: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x82a3a8: r2 = Null
    //     0x82a3a8: mov             x2, NULL
    // 0x82a3ac: StoreStaticField(0x7f0, r2)
    //     0x82a3ac: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x82a3b0: str             x2, [x1, #0xfe0]
    // 0x82a3b4: r0 = Null
    //     0x82a3b4: mov             x0, NULL
    // 0x82a3b8: LeaveFrame
    //     0x82a3b8: mov             SP, fp
    //     0x82a3bc: ldp             fp, lr, [SP], #0x10
    // 0x82a3c0: ret
    //     0x82a3c0: ret             
    // 0x82a3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a3c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a3c8: b               #0x82a18c
    // 0x82a3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a3cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a3d0: b               #0x82a1fc
  }
  [closure] static void _debugPrintTask(dynamic) {
    // ** addr: 0x82a43c, size: 0x2c
    // 0x82a43c: EnterFrame
    //     0x82a43c: stp             fp, lr, [SP, #-0x10]!
    //     0x82a440: mov             fp, SP
    // 0x82a444: CheckStackOverflow
    //     0x82a444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a448: cmp             SP, x16
    //     0x82a44c: b.ls            #0x82a460
    // 0x82a450: r0 = _debugPrintTask()
    //     0x82a450: bl              #0x82a174  ; [package:flutter/src/foundation/print.dart] ::_debugPrintTask
    // 0x82a454: LeaveFrame
    //     0x82a454: mov             SP, fp
    //     0x82a458: ldp             fp, lr, [SP], #0x10
    // 0x82a45c: ret
    //     0x82a45c: ret             
    // 0x82a460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a464: b               #0x82a450
  }
  [closure] static Iterable<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x82af28, size: 0x50
    // 0x82af28: EnterFrame
    //     0x82af28: stp             fp, lr, [SP, #-0x10]!
    //     0x82af2c: mov             fp, SP
    // 0x82af30: ldr             x0, [fp, #0x18]
    // 0x82af34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82af34: ldur            w1, [x0, #0x17]
    // 0x82af38: DecompressPointer r1
    //     0x82af38: add             x1, x1, HEAP, lsl #32
    // 0x82af3c: CheckStackOverflow
    //     0x82af3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82af40: cmp             SP, x16
    //     0x82af44: b.ls            #0x82af70
    // 0x82af48: LoadField: r0 = r1->field_f
    //     0x82af48: ldur            w0, [x1, #0xf]
    // 0x82af4c: DecompressPointer r0
    //     0x82af4c: add             x0, x0, HEAP, lsl #32
    // 0x82af50: r2 = LoadInt32Instr(r0)
    //     0x82af50: sbfx            x2, x0, #1, #0x1f
    //     0x82af54: tbz             w0, #0, #0x82af5c
    //     0x82af58: ldur            x2, [x0, #7]
    // 0x82af5c: ldr             x1, [fp, #0x10]
    // 0x82af60: r0 = debugWordWrap()
    //     0x82af60: bl              #0x82af78  ; [package:flutter/src/foundation/print.dart] ::debugWordWrap
    // 0x82af64: LeaveFrame
    //     0x82af64: mov             SP, fp
    //     0x82af68: ldp             fp, lr, [SP], #0x10
    // 0x82af6c: ret
    //     0x82af6c: ret             
    // 0x82af70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82af70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82af74: b               #0x82af48
  }
  static _ debugWordWrap(/* No info */) {
    // ** addr: 0x82af78, size: 0x604
    // 0x82af78: EnterFrame
    //     0x82af78: stp             fp, lr, [SP, #-0x10]!
    //     0x82af7c: mov             fp, SP
    // 0x82af80: AllocStack(0x80)
    //     0x82af80: sub             SP, SP, #0x80
    // 0x82af84: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x82af84: mov             x0, x1
    //     0x82af88: stur            x1, [fp, #-0x10]
    //     0x82af8c: stur            x2, [fp, #-0x18]
    // 0x82af90: CheckStackOverflow
    //     0x82af90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82af94: cmp             SP, x16
    //     0x82af98: b.ls            #0x82b54c
    // 0x82af9c: LoadField: r1 = r0->field_7
    //     0x82af9c: ldur            w1, [x0, #7]
    // 0x82afa0: r3 = LoadInt32Instr(r1)
    //     0x82afa0: sbfx            x3, x1, #1, #0x1f
    // 0x82afa4: stur            x3, [fp, #-8]
    // 0x82afa8: cmp             x3, x2
    // 0x82afac: b.lt            #0x82afe4
    // 0x82afb0: mov             x1, x0
    // 0x82afb4: r0 = trimLeft()
    //     0x82afb4: bl              #0x82b96c  ; [dart:core] _StringBase::trimLeft
    // 0x82afb8: stp             xzr, x0, [SP]
    // 0x82afbc: r0 = []()
    //     0x82afbc: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0x82afc0: r1 = LoadClassIdInstr(r0)
    //     0x82afc0: ldur            x1, [x0, #-1]
    //     0x82afc4: ubfx            x1, x1, #0xc, #0x14
    // 0x82afc8: r16 = "#"
    //     0x82afc8: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0x82afcc: stp             x16, x0, [SP]
    // 0x82afd0: mov             x0, x1
    // 0x82afd4: mov             lr, x0
    // 0x82afd8: ldr             lr, [x21, lr, lsl #3]
    // 0x82afdc: blr             lr
    // 0x82afe0: tbnz            w0, #4, #0x82affc
    // 0x82afe4: ldur            x2, [fp, #-0x10]
    // 0x82afe8: r1 = <String>
    //     0x82afe8: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82afec: r0 = _GrowableList._literal1()
    //     0x82afec: bl              #0x7fa158  ; [dart:core] _GrowableList::_GrowableList._literal1
    // 0x82aff0: LeaveFrame
    //     0x82aff0: mov             SP, fp
    //     0x82aff4: ldp             fp, lr, [SP], #0x10
    // 0x82aff8: ret
    //     0x82aff8: ret             
    // 0x82affc: r1 = <String>
    //     0x82affc: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82b000: r2 = 0
    //     0x82b000: mov             x2, #0
    // 0x82b004: r0 = _GrowableList()
    //     0x82b004: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x82b008: stur            x0, [fp, #-0x20]
    // 0x82b00c: r0 = LoadStaticField(0x7f8)
    //     0x82b00c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82b010: ldr             x0, [x0, #0xff0]
    // 0x82b014: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82b018: cmp             w0, w16
    // 0x82b01c: b.ne            #0x82b028
    // 0x82b020: r2 = _indentPattern
    //     0x82b020: ldr             x2, [PP, #0x8f0]  ; [pp+0x8f0] Field <::._indentPattern@157110992>: static late final (offset: 0x7f8)
    // 0x82b024: r0 = InitLateFinalStaticField()
    //     0x82b024: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x82b028: mov             x1, x0
    // 0x82b02c: ldur            x2, [fp, #-0x10]
    // 0x82b030: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82b030: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82b034: r0 = matchAsPrefix()
    //     0x82b034: bl              #0x13da400  ; [dart:core] _RegExp::matchAsPrefix
    // 0x82b038: cmp             w0, NULL
    // 0x82b03c: b.eq            #0x82b554
    // 0x82b040: mov             x1, x0
    // 0x82b044: r2 = 0
    //     0x82b044: mov             x2, #0
    // 0x82b048: r0 = group()
    //     0x82b048: bl              #0x1292a24  ; [dart:core] _RegExpMatch::group
    // 0x82b04c: cmp             w0, NULL
    // 0x82b050: b.eq            #0x82b558
    // 0x82b054: LoadField: r1 = r0->field_7
    //     0x82b054: ldur            w1, [x0, #7]
    // 0x82b058: r2 = LoadInt32Instr(r1)
    //     0x82b058: sbfx            x2, x1, #1, #0x1f
    // 0x82b05c: r1 = " "
    //     0x82b05c: ldr             x1, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82b060: r0 = *()
    //     0x82b060: bl              #0x13da918  ; [dart:core] _OneByteString::*
    // 0x82b064: r16 = ""
    //     0x82b064: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x82b068: stp             x0, x16, [SP]
    // 0x82b06c: r0 = +()
    //     0x82b06c: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0x82b070: stur            x0, [fp, #-0x58]
    // 0x82b074: LoadField: r1 = r0->field_7
    //     0x82b074: ldur            w1, [x0, #7]
    // 0x82b078: r2 = LoadInt32Instr(r1)
    //     0x82b078: sbfx            x2, x1, #1, #0x1f
    // 0x82b07c: stur            x2, [fp, #-0x50]
    // 0x82b080: mov             x8, x2
    // 0x82b084: r11 = 0
    //     0x82b084: mov             x11, #0
    // 0x82b088: r10 = 0
    //     0x82b088: mov             x10, #0
    // 0x82b08c: r9 = false
    //     0x82b08c: add             x9, NULL, #0x30  ; false
    // 0x82b090: r7 = Instance__WordWrapParseMode
    //     0x82b090: ldr             x7, [PP, #0x908]  ; [pp+0x908] Obj!_WordWrapParseMode@12c5e61
    // 0x82b094: ldr             x6, [THR, #0x90]  ; THR::object_sentinel
    // 0x82b098: r5 = Null
    //     0x82b098: mov             x5, NULL
    // 0x82b09c: ldur            x3, [fp, #-0x18]
    // 0x82b0a0: ldur            x1, [fp, #-0x20]
    // 0x82b0a4: ldur            x4, [fp, #-8]
    // 0x82b0a8: stur            x11, [fp, #-0x30]
    // 0x82b0ac: stur            x10, [fp, #-0x38]
    // 0x82b0b0: stur            x9, [fp, #-0x40]
    // 0x82b0b4: stur            x5, [fp, #-0x48]
    // 0x82b0b8: stur            x6, [fp, #-0x60]
    // 0x82b0bc: stur            x8, [fp, #-0x68]
    // 0x82b0c0: CheckStackOverflow
    //     0x82b0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b0c4: cmp             SP, x16
    //     0x82b0c8: b.ls            #0x82b55c
    // 0x82b0cc: LoadField: r12 = r7->field_7
    //     0x82b0cc: ldur            x12, [x7, #7]
    // 0x82b0d0: cmp             x12, #1
    // 0x82b0d4: b.gt            #0x82b224
    // 0x82b0d8: cmp             x12, #0
    // 0x82b0dc: b.gt            #0x82b194
    // 0x82b0e0: mov             x6, x8
    // 0x82b0e4: stur            x6, [fp, #-0x28]
    // 0x82b0e8: CheckStackOverflow
    //     0x82b0e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b0ec: cmp             SP, x16
    //     0x82b0f0: b.ls            #0x82b564
    // 0x82b0f4: cmp             x6, x4
    // 0x82b0f8: b.ge            #0x82b168
    // 0x82b0fc: lsl             x7, x6, #1
    // 0x82b100: ldur            x16, [fp, #-0x10]
    // 0x82b104: stp             x7, x16, [SP]
    // 0x82b108: r0 = []()
    //     0x82b108: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0x82b10c: r1 = LoadClassIdInstr(r0)
    //     0x82b10c: ldur            x1, [x0, #-1]
    //     0x82b110: ubfx            x1, x1, #0xc, #0x14
    // 0x82b114: r16 = " "
    //     0x82b114: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82b118: stp             x16, x0, [SP]
    // 0x82b11c: mov             x0, x1
    // 0x82b120: mov             lr, x0
    // 0x82b124: ldr             lr, [x21, lr, lsl #3]
    // 0x82b128: blr             lr
    // 0x82b12c: tbnz            w0, #4, #0x82b160
    // 0x82b130: ldur            x0, [fp, #-0x28]
    // 0x82b134: add             x6, x0, #1
    // 0x82b138: ldur            x3, [fp, #-0x18]
    // 0x82b13c: ldur            x1, [fp, #-0x20]
    // 0x82b140: ldur            x0, [fp, #-0x58]
    // 0x82b144: ldur            x11, [fp, #-0x30]
    // 0x82b148: ldur            x10, [fp, #-0x38]
    // 0x82b14c: ldur            x9, [fp, #-0x40]
    // 0x82b150: ldur            x5, [fp, #-0x48]
    // 0x82b154: ldur            x4, [fp, #-8]
    // 0x82b158: ldur            x2, [fp, #-0x50]
    // 0x82b15c: b               #0x82b0e4
    // 0x82b160: ldur            x0, [fp, #-0x28]
    // 0x82b164: b               #0x82b16c
    // 0x82b168: mov             x0, x6
    // 0x82b16c: lsl             x1, x0, #1
    // 0x82b170: ldur            x11, [fp, #-0x30]
    // 0x82b174: ldur            x10, [fp, #-0x38]
    // 0x82b178: ldur            x9, [fp, #-0x40]
    // 0x82b17c: mov             x8, x0
    // 0x82b180: mov             x6, x1
    // 0x82b184: ldur            x5, [fp, #-0x48]
    // 0x82b188: ldur            x4, [fp, #-0x50]
    // 0x82b18c: r7 = Instance__WordWrapParseMode
    //     0x82b18c: ldr             x7, [PP, #0x910]  ; [pp+0x910] Obj!_WordWrapParseMode@12c5e41
    // 0x82b190: b               #0x82b530
    // 0x82b194: mov             x0, x8
    // 0x82b198: ldur            x3, [fp, #-8]
    // 0x82b19c: stur            x0, [fp, #-0x28]
    // 0x82b1a0: CheckStackOverflow
    //     0x82b1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b1a4: cmp             SP, x16
    //     0x82b1a8: b.ls            #0x82b56c
    // 0x82b1ac: cmp             x0, x3
    // 0x82b1b0: b.ge            #0x82b200
    // 0x82b1b4: lsl             x1, x0, #1
    // 0x82b1b8: ldur            x16, [fp, #-0x10]
    // 0x82b1bc: stp             x1, x16, [SP]
    // 0x82b1c0: r0 = []()
    //     0x82b1c0: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0x82b1c4: r1 = LoadClassIdInstr(r0)
    //     0x82b1c4: ldur            x1, [x0, #-1]
    //     0x82b1c8: ubfx            x1, x1, #0xc, #0x14
    // 0x82b1cc: r16 = " "
    //     0x82b1cc: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82b1d0: stp             x16, x0, [SP]
    // 0x82b1d4: mov             x0, x1
    // 0x82b1d8: mov             lr, x0
    // 0x82b1dc: ldr             lr, [x21, lr, lsl #3]
    // 0x82b1e0: blr             lr
    // 0x82b1e4: tbz             w0, #4, #0x82b1fc
    // 0x82b1e8: ldur            x0, [fp, #-0x28]
    // 0x82b1ec: add             x1, x0, #1
    // 0x82b1f0: mov             x0, x1
    // 0x82b1f4: ldur            x6, [fp, #-0x60]
    // 0x82b1f8: b               #0x82b198
    // 0x82b1fc: ldur            x0, [fp, #-0x28]
    // 0x82b200: ldur            x11, [fp, #-0x30]
    // 0x82b204: ldur            x10, [fp, #-0x38]
    // 0x82b208: ldur            x9, [fp, #-0x40]
    // 0x82b20c: mov             x8, x0
    // 0x82b210: ldur            x6, [fp, #-0x60]
    // 0x82b214: ldur            x5, [fp, #-0x48]
    // 0x82b218: ldur            x4, [fp, #-0x50]
    // 0x82b21c: r7 = Instance__WordWrapParseMode
    //     0x82b21c: ldr             x7, [PP, #0x918]  ; [pp+0x918] Obj!_WordWrapParseMode@12c5e21
    // 0x82b220: b               #0x82b530
    // 0x82b224: mov             x4, x3
    // 0x82b228: mov             x0, x10
    // 0x82b22c: sub             x1, x8, x0
    // 0x82b230: cmp             x1, x4
    // 0x82b234: b.le            #0x82b240
    // 0x82b238: ldur            x5, [fp, #-8]
    // 0x82b23c: b               #0x82b24c
    // 0x82b240: ldur            x5, [fp, #-8]
    // 0x82b244: cmp             x8, x5
    // 0x82b248: b.ne            #0x82b4f8
    // 0x82b24c: cmp             x1, x4
    // 0x82b250: b.le            #0x82b260
    // 0x82b254: ldur            x0, [fp, #-0x48]
    // 0x82b258: cmp             w0, NULL
    // 0x82b25c: b.ne            #0x82b268
    // 0x82b260: mov             x6, x8
    // 0x82b264: b               #0x82b270
    // 0x82b268: r1 = LoadInt32Instr(r0)
    //     0x82b268: sbfx            x1, x0, #1, #0x1f
    // 0x82b26c: mov             x6, x1
    // 0x82b270: ldur            x1, [fp, #-0x40]
    // 0x82b274: stur            x6, [fp, #-0x28]
    // 0x82b278: tbnz            w1, #4, #0x82b34c
    // 0x82b27c: ldur            x7, [fp, #-0x20]
    // 0x82b280: r0 = BoxInt64Instr(r6)
    //     0x82b280: sbfiz           x0, x6, #1, #0x1f
    //     0x82b284: cmp             x6, x0, asr #1
    //     0x82b288: b.eq            #0x82b294
    //     0x82b28c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82b290: stur            x6, [x0, #7]
    // 0x82b294: ldur            x1, [fp, #-0x30]
    // 0x82b298: mov             x2, x0
    // 0x82b29c: mov             x3, x5
    // 0x82b2a0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x82b2a0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x82b2a4: r0 = checkValidRange()
    //     0x82b2a4: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x82b2a8: ldur            x1, [fp, #-0x10]
    // 0x82b2ac: ldur            x2, [fp, #-0x30]
    // 0x82b2b0: mov             x3, x0
    // 0x82b2b4: r0 = _substringUnchecked()
    //     0x82b2b4: bl              #0x7e3ff8  ; [dart:core] _StringBase::_substringUnchecked
    // 0x82b2b8: ldur            x16, [fp, #-0x58]
    // 0x82b2bc: stp             x0, x16, [SP]
    // 0x82b2c0: r0 = +()
    //     0x82b2c0: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0x82b2c4: mov             x2, x0
    // 0x82b2c8: ldur            x0, [fp, #-0x20]
    // 0x82b2cc: stur            x2, [fp, #-0x48]
    // 0x82b2d0: LoadField: r1 = r0->field_b
    //     0x82b2d0: ldur            w1, [x0, #0xb]
    // 0x82b2d4: LoadField: r3 = r0->field_f
    //     0x82b2d4: ldur            w3, [x0, #0xf]
    // 0x82b2d8: DecompressPointer r3
    //     0x82b2d8: add             x3, x3, HEAP, lsl #32
    // 0x82b2dc: LoadField: r4 = r3->field_b
    //     0x82b2dc: ldur            w4, [x3, #0xb]
    // 0x82b2e0: r3 = LoadInt32Instr(r1)
    //     0x82b2e0: sbfx            x3, x1, #1, #0x1f
    // 0x82b2e4: stur            x3, [fp, #-0x70]
    // 0x82b2e8: r1 = LoadInt32Instr(r4)
    //     0x82b2e8: sbfx            x1, x4, #1, #0x1f
    // 0x82b2ec: cmp             x3, x1
    // 0x82b2f0: b.ne            #0x82b2fc
    // 0x82b2f4: mov             x1, x0
    // 0x82b2f8: r0 = _growToNextCapacity()
    //     0x82b2f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82b2fc: ldur            x4, [fp, #-0x20]
    // 0x82b300: ldur            x2, [fp, #-0x70]
    // 0x82b304: add             x0, x2, #1
    // 0x82b308: lsl             x1, x0, #1
    // 0x82b30c: StoreField: r4->field_b = r1
    //     0x82b30c: stur            w1, [x4, #0xb]
    // 0x82b310: LoadField: r1 = r4->field_f
    //     0x82b310: ldur            w1, [x4, #0xf]
    // 0x82b314: DecompressPointer r1
    //     0x82b314: add             x1, x1, HEAP, lsl #32
    // 0x82b318: ldur            x0, [fp, #-0x48]
    // 0x82b31c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x82b31c: add             x25, x1, x2, lsl #2
    //     0x82b320: add             x25, x25, #0xf
    //     0x82b324: str             w0, [x25]
    //     0x82b328: tbz             w0, #0, #0x82b344
    //     0x82b32c: ldurb           w16, [x1, #-1]
    //     0x82b330: ldurb           w17, [x0, #-1]
    //     0x82b334: and             x16, x17, x16, lsr #2
    //     0x82b338: tst             x16, HEAP, lsr #32
    //     0x82b33c: b.eq            #0x82b344
    //     0x82b340: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82b344: mov             x2, x4
    // 0x82b348: b               #0x82b40c
    // 0x82b34c: ldur            x4, [fp, #-0x20]
    // 0x82b350: mov             x5, x6
    // 0x82b354: r0 = BoxInt64Instr(r5)
    //     0x82b354: sbfiz           x0, x5, #1, #0x1f
    //     0x82b358: cmp             x5, x0, asr #1
    //     0x82b35c: b.eq            #0x82b368
    //     0x82b360: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82b364: stur            x5, [x0, #7]
    // 0x82b368: ldur            x1, [fp, #-0x30]
    // 0x82b36c: mov             x2, x0
    // 0x82b370: ldur            x3, [fp, #-8]
    // 0x82b374: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x82b374: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x82b378: r0 = checkValidRange()
    //     0x82b378: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x82b37c: ldur            x1, [fp, #-0x10]
    // 0x82b380: ldur            x2, [fp, #-0x30]
    // 0x82b384: mov             x3, x0
    // 0x82b388: r0 = _substringUnchecked()
    //     0x82b388: bl              #0x7e3ff8  ; [dart:core] _StringBase::_substringUnchecked
    // 0x82b38c: mov             x2, x0
    // 0x82b390: ldur            x0, [fp, #-0x20]
    // 0x82b394: stur            x2, [fp, #-0x48]
    // 0x82b398: LoadField: r1 = r0->field_b
    //     0x82b398: ldur            w1, [x0, #0xb]
    // 0x82b39c: LoadField: r3 = r0->field_f
    //     0x82b39c: ldur            w3, [x0, #0xf]
    // 0x82b3a0: DecompressPointer r3
    //     0x82b3a0: add             x3, x3, HEAP, lsl #32
    // 0x82b3a4: LoadField: r4 = r3->field_b
    //     0x82b3a4: ldur            w4, [x3, #0xb]
    // 0x82b3a8: r3 = LoadInt32Instr(r1)
    //     0x82b3a8: sbfx            x3, x1, #1, #0x1f
    // 0x82b3ac: stur            x3, [fp, #-0x70]
    // 0x82b3b0: r1 = LoadInt32Instr(r4)
    //     0x82b3b0: sbfx            x1, x4, #1, #0x1f
    // 0x82b3b4: cmp             x3, x1
    // 0x82b3b8: b.ne            #0x82b3c4
    // 0x82b3bc: mov             x1, x0
    // 0x82b3c0: r0 = _growToNextCapacity()
    //     0x82b3c0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82b3c4: ldur            x2, [fp, #-0x20]
    // 0x82b3c8: ldur            x3, [fp, #-0x70]
    // 0x82b3cc: add             x0, x3, #1
    // 0x82b3d0: lsl             x1, x0, #1
    // 0x82b3d4: StoreField: r2->field_b = r1
    //     0x82b3d4: stur            w1, [x2, #0xb]
    // 0x82b3d8: LoadField: r1 = r2->field_f
    //     0x82b3d8: ldur            w1, [x2, #0xf]
    // 0x82b3dc: DecompressPointer r1
    //     0x82b3dc: add             x1, x1, HEAP, lsl #32
    // 0x82b3e0: ldur            x0, [fp, #-0x48]
    // 0x82b3e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x82b3e4: add             x25, x1, x3, lsl #2
    //     0x82b3e8: add             x25, x25, #0xf
    //     0x82b3ec: str             w0, [x25]
    //     0x82b3f0: tbz             w0, #0, #0x82b40c
    //     0x82b3f4: ldurb           w16, [x1, #-1]
    //     0x82b3f8: ldurb           w17, [x0, #-1]
    //     0x82b3fc: and             x16, x17, x16, lsr #2
    //     0x82b400: tst             x16, HEAP, lsr #32
    //     0x82b404: b.eq            #0x82b40c
    //     0x82b408: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x82b40c: ldur            x0, [fp, #-0x28]
    // 0x82b410: ldur            x1, [fp, #-8]
    // 0x82b414: cmp             x0, x1
    // 0x82b418: b.ge            #0x82b4e8
    // 0x82b41c: ldur            x3, [fp, #-0x68]
    // 0x82b420: cmp             x0, x3
    // 0x82b424: b.ne            #0x82b4a8
    // 0x82b428: mov             x0, x3
    // 0x82b42c: stur            x0, [fp, #-0x28]
    // 0x82b430: CheckStackOverflow
    //     0x82b430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b434: cmp             SP, x16
    //     0x82b438: b.ls            #0x82b574
    // 0x82b43c: cmp             x0, x1
    // 0x82b440: b.ge            #0x82b494
    // 0x82b444: lsl             x3, x0, #1
    // 0x82b448: ldur            x16, [fp, #-0x10]
    // 0x82b44c: stp             x3, x16, [SP]
    // 0x82b450: r0 = []()
    //     0x82b450: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0x82b454: r1 = LoadClassIdInstr(r0)
    //     0x82b454: ldur            x1, [x0, #-1]
    //     0x82b458: ubfx            x1, x1, #0xc, #0x14
    // 0x82b45c: r16 = " "
    //     0x82b45c: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0x82b460: stp             x16, x0, [SP]
    // 0x82b464: mov             x0, x1
    // 0x82b468: mov             lr, x0
    // 0x82b46c: ldr             lr, [x21, lr, lsl #3]
    // 0x82b470: blr             lr
    // 0x82b474: tbnz            w0, #4, #0x82b490
    // 0x82b478: ldur            x0, [fp, #-0x28]
    // 0x82b47c: add             x1, x0, #1
    // 0x82b480: mov             x0, x1
    // 0x82b484: ldur            x2, [fp, #-0x20]
    // 0x82b488: ldur            x1, [fp, #-8]
    // 0x82b48c: b               #0x82b42c
    // 0x82b490: ldur            x0, [fp, #-0x28]
    // 0x82b494: mov             x3, x0
    // 0x82b498: mov             x1, x0
    // 0x82b49c: ldur            x2, [fp, #-0x60]
    // 0x82b4a0: r0 = Instance__WordWrapParseMode
    //     0x82b4a0: ldr             x0, [PP, #0x910]  ; [pp+0x910] Obj!_WordWrapParseMode@12c5e41
    // 0x82b4a4: b               #0x82b4c8
    // 0x82b4a8: ldur            x2, [fp, #-0x60]
    // 0x82b4ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82b4b0: cmp             w2, w16
    // 0x82b4b4: b.eq            #0x82b53c
    // 0x82b4b8: r0 = LoadInt32Instr(r2)
    //     0x82b4b8: sbfx            x0, x2, #1, #0x1f
    // 0x82b4bc: mov             x1, x3
    // 0x82b4c0: mov             x3, x0
    // 0x82b4c4: r0 = Instance__WordWrapParseMode
    //     0x82b4c4: ldr             x0, [PP, #0x918]  ; [pp+0x918] Obj!_WordWrapParseMode@12c5e21
    // 0x82b4c8: ldur            x4, [fp, #-0x50]
    // 0x82b4cc: sub             x10, x3, x4
    // 0x82b4d0: mov             x11, x3
    // 0x82b4d4: mov             x3, x1
    // 0x82b4d8: mov             x1, x0
    // 0x82b4dc: r9 = true
    //     0x82b4dc: add             x9, NULL, #0x20  ; true
    // 0x82b4e0: r0 = Null
    //     0x82b4e0: mov             x0, NULL
    // 0x82b4e4: b               #0x82b520
    // 0x82b4e8: ldur            x0, [fp, #-0x20]
    // 0x82b4ec: LeaveFrame
    //     0x82b4ec: mov             SP, fp
    //     0x82b4f0: ldp             fp, lr, [SP], #0x10
    // 0x82b4f4: ret
    //     0x82b4f4: ret             
    // 0x82b4f8: ldur            x1, [fp, #-0x40]
    // 0x82b4fc: mov             x3, x8
    // 0x82b500: ldur            x2, [fp, #-0x60]
    // 0x82b504: ldur            x4, [fp, #-0x50]
    // 0x82b508: lsl             x5, x3, #1
    // 0x82b50c: ldur            x11, [fp, #-0x30]
    // 0x82b510: mov             x10, x0
    // 0x82b514: mov             x9, x1
    // 0x82b518: mov             x0, x5
    // 0x82b51c: r1 = Instance__WordWrapParseMode
    //     0x82b51c: ldr             x1, [PP, #0x908]  ; [pp+0x908] Obj!_WordWrapParseMode@12c5e61
    // 0x82b520: mov             x8, x3
    // 0x82b524: mov             x7, x1
    // 0x82b528: mov             x6, x2
    // 0x82b52c: mov             x5, x0
    // 0x82b530: ldur            x0, [fp, #-0x58]
    // 0x82b534: mov             x2, x4
    // 0x82b538: b               #0x82b09c
    // 0x82b53c: r16 = "lastWordStart"
    //     0x82b53c: ldr             x16, [PP, #0x928]  ; [pp+0x928] "lastWordStart"
    // 0x82b540: str             x16, [SP]
    // 0x82b544: r0 = _throwLocalNotInitialized()
    //     0x82b544: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x82b548: brk             #0
    // 0x82b54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b54c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b550: b               #0x82af9c
    // 0x82b554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b554: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b558: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82b55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b55c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b560: b               #0x82b0cc
    // 0x82b564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b564: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b568: b               #0x82b0f4
    // 0x82b56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b56c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b570: b               #0x82b1ac
    // 0x82b574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b578: b               #0x82b43c
  }
  static RegExp _indentPattern() {
    // ** addr: 0x82bb14, size: 0x38
    // 0x82bb14: EnterFrame
    //     0x82bb14: stp             fp, lr, [SP, #-0x10]!
    //     0x82bb18: mov             fp, SP
    // 0x82bb1c: CheckStackOverflow
    //     0x82bb1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bb20: cmp             SP, x16
    //     0x82bb24: b.ls            #0x82bb44
    // 0x82bb28: r1 = Null
    //     0x82bb28: mov             x1, NULL
    // 0x82bb2c: r2 = "^ *(\?:[-+*] |[0-9]+[.):] )\?"
    //     0x82bb2c: ldr             x2, [PP, #0xa20]  ; [pp+0xa20] "^ *(\?:[-+*] |[0-9]+[.):] )\?"
    // 0x82bb30: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bb30: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bb34: r0 = RegExp()
    //     0x82bb34: bl              #0x7eb294  ; [dart:core] RegExp::RegExp
    // 0x82bb38: LeaveFrame
    //     0x82bb38: mov             SP, fp
    //     0x82bb3c: ldp             fp, lr, [SP], #0x10
    // 0x82bb40: ret
    //     0x82bb40: ret             
    // 0x82bb44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bb44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bb48: b               #0x82bb28
  }
  static Queue<String> _debugPrintBuffer() {
    // ** addr: 0x82bb4c, size: 0x48
    // 0x82bb4c: EnterFrame
    //     0x82bb4c: stp             fp, lr, [SP, #-0x10]!
    //     0x82bb50: mov             fp, SP
    // 0x82bb54: AllocStack(0x8)
    //     0x82bb54: sub             SP, SP, #8
    // 0x82bb58: CheckStackOverflow
    //     0x82bb58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bb5c: cmp             SP, x16
    //     0x82bb60: b.ls            #0x82bb8c
    // 0x82bb64: r1 = <String>
    //     0x82bb64: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x82bb68: r0 = ListQueue()
    //     0x82bb68: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0x82bb6c: mov             x1, x0
    // 0x82bb70: stur            x0, [fp, #-8]
    // 0x82bb74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82bb74: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82bb78: r0 = ListQueue()
    //     0x82bb78: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0x82bb7c: ldur            x0, [fp, #-8]
    // 0x82bb80: LeaveFrame
    //     0x82bb80: mov             SP, fp
    //     0x82bb84: ldp             fp, lr, [SP], #0x10
    // 0x82bb88: ret
    //     0x82bb88: ret             
    // 0x82bb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bb8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bb90: b               #0x82bb64
  }
  static (dynamic, String?, {int? wrapWidth}) => void debugPrint() {
    // ** addr: 0x82bb94, size: 0x8
    // 0x82bb94: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x82bb94: ldr             x0, [PP, #0xc98]  ; [pp+0xc98] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x7f2ada710f60)
    // 0x82bb98: ret
    //     0x82bb98: ret             
  }
}

// class id: 8313, size: 0x14, field offset: 0x14
enum _WordWrapParseMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a98c4, size: 0x64
    // 0x11a98c4: EnterFrame
    //     0x11a98c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a98c8: mov             fp, SP
    // 0x11a98cc: AllocStack(0x10)
    //     0x11a98cc: sub             SP, SP, #0x10
    // 0x11a98d0: SetupParameters(_WordWrapParseMode this /* r1 => r0, fp-0x8 */)
    //     0x11a98d0: mov             x0, x1
    //     0x11a98d4: stur            x1, [fp, #-8]
    // 0x11a98d8: CheckStackOverflow
    //     0x11a98d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a98dc: cmp             SP, x16
    //     0x11a98e0: b.ls            #0x11a9920
    // 0x11a98e4: r1 = Null
    //     0x11a98e4: mov             x1, NULL
    // 0x11a98e8: r2 = 4
    //     0x11a98e8: mov             x2, #4
    // 0x11a98ec: r0 = AllocateArray()
    //     0x11a98ec: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a98f0: r16 = "_WordWrapParseMode."
    //     0x11a98f0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e08] "_WordWrapParseMode."
    //     0x11a98f4: ldr             x16, [x16, #0xe08]
    // 0x11a98f8: StoreField: r0->field_f = r16
    //     0x11a98f8: stur            w16, [x0, #0xf]
    // 0x11a98fc: ldur            x1, [fp, #-8]
    // 0x11a9900: LoadField: r2 = r1->field_f
    //     0x11a9900: ldur            w2, [x1, #0xf]
    // 0x11a9904: DecompressPointer r2
    //     0x11a9904: add             x2, x2, HEAP, lsl #32
    // 0x11a9908: StoreField: r0->field_13 = r2
    //     0x11a9908: stur            w2, [x0, #0x13]
    // 0x11a990c: str             x0, [SP]
    // 0x11a9910: r0 = _interpolate()
    //     0x11a9910: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9914: LeaveFrame
    //     0x11a9914: mov             SP, fp
    //     0x11a9918: ldp             fp, lr, [SP], #0x10
    // 0x11a991c: ret
    //     0x11a991c: ret             
    // 0x11a9920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9920: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9924: b               #0x11a98e4
  }
}
