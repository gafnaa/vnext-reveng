// lib: , url: package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart

// class id: 1048777, size: 0x8
class :: {
}

// class id: 5495, size: 0x18, field offset: 0x14
class _CupertinoDesktopTextSelectionToolbarButtonState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde3190, size: 0x2a4
    // 0xde3190: EnterFrame
    //     0xde3190: stp             fp, lr, [SP, #-0x10]!
    //     0xde3194: mov             fp, SP
    // 0xde3198: AllocStack(0x30)
    //     0xde3198: sub             SP, SP, #0x30
    // 0xde319c: SetupParameters(_CupertinoDesktopTextSelectionToolbarButtonState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xde319c: mov             x0, x2
    //     0xde31a0: stur            x2, [fp, #-0x18]
    //     0xde31a4: mov             x2, x1
    //     0xde31a8: stur            x1, [fp, #-0x10]
    // 0xde31ac: CheckStackOverflow
    //     0xde31ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde31b0: cmp             SP, x16
    //     0xde31b4: b.ls            #0xde3424
    // 0xde31b8: LoadField: r1 = r2->field_b
    //     0xde31b8: ldur            w1, [x2, #0xb]
    // 0xde31bc: DecompressPointer r1
    //     0xde31bc: add             x1, x1, HEAP, lsl #32
    // 0xde31c0: cmp             w1, NULL
    // 0xde31c4: b.eq            #0xde342c
    // 0xde31c8: LoadField: r3 = r1->field_b
    //     0xde31c8: ldur            w3, [x1, #0xb]
    // 0xde31cc: DecompressPointer r3
    //     0xde31cc: add             x3, x3, HEAP, lsl #32
    // 0xde31d0: stur            x3, [fp, #-8]
    // 0xde31d4: LoadField: r1 = r2->field_13
    //     0xde31d4: ldur            w1, [x2, #0x13]
    // 0xde31d8: DecompressPointer r1
    //     0xde31d8: add             x1, x1, HEAP, lsl #32
    // 0xde31dc: tbnz            w1, #4, #0xde322c
    // 0xde31e0: mov             x1, x0
    // 0xde31e4: r0 = of()
    //     0xde31e4: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xde31e8: r1 = LoadClassIdInstr(r0)
    //     0xde31e8: ldur            x1, [x0, #-1]
    //     0xde31ec: ubfx            x1, x1, #0xc, #0x14
    // 0xde31f0: r17 = 4617
    //     0xde31f0: mov             x17, #0x1209
    // 0xde31f4: cmp             x1, x17
    // 0xde31f8: b.ne            #0xde3208
    // 0xde31fc: r0 = Instance_Color
    //     0xde31fc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xde3200: ldr             x0, [x0, #0xc38]
    // 0xde3204: b               #0xde3224
    // 0xde3208: LoadField: r1 = r0->field_2b
    //     0xde3208: ldur            w1, [x0, #0x2b]
    // 0xde320c: DecompressPointer r1
    //     0xde320c: add             x1, x1, HEAP, lsl #32
    // 0xde3210: LoadField: r0 = r1->field_3f
    //     0xde3210: ldur            w0, [x1, #0x3f]
    // 0xde3214: DecompressPointer r0
    //     0xde3214: add             x0, x0, HEAP, lsl #32
    // 0xde3218: LoadField: r1 = r0->field_f
    //     0xde3218: ldur            w1, [x0, #0xf]
    // 0xde321c: DecompressPointer r1
    //     0xde321c: add             x1, x1, HEAP, lsl #32
    // 0xde3220: mov             x0, x1
    // 0xde3224: mov             x1, x0
    // 0xde3228: b               #0xde3240
    // 0xde322c: ldur            x2, [fp, #-0x18]
    // 0xde3230: r1 = Instance_CupertinoDynamicColor
    //     0xde3230: add             x1, PP, #0x96, lsl #12  ; [pp+0x96028] Obj!CupertinoDynamicColor@12b3af1
    //     0xde3234: ldr             x1, [x1, #0x28]
    // 0xde3238: r0 = resolveFrom()
    //     0xde3238: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde323c: mov             x1, x0
    // 0xde3240: ldur            x2, [fp, #-0x10]
    // 0xde3244: ldur            x0, [fp, #-8]
    // 0xde3248: str             x1, [SP]
    // 0xde324c: r1 = Instance_TextStyle
    //     0xde324c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a20] Obj!TextStyle@12b0c41
    //     0xde3250: ldr             x1, [x1, #0xa20]
    // 0xde3254: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde3254: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde3258: ldr             x4, [x4, #0x7f0]
    // 0xde325c: r0 = copyWith()
    //     0xde325c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde3260: stur            x0, [fp, #-0x20]
    // 0xde3264: r0 = Text()
    //     0xde3264: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde3268: mov             x2, x0
    // 0xde326c: ldur            x0, [fp, #-8]
    // 0xde3270: stur            x2, [fp, #-0x28]
    // 0xde3274: StoreField: r2->field_b = r0
    //     0xde3274: stur            w0, [x2, #0xb]
    // 0xde3278: ldur            x0, [fp, #-0x20]
    // 0xde327c: StoreField: r2->field_13 = r0
    //     0xde327c: stur            w0, [x2, #0x13]
    // 0xde3280: r0 = Instance_TextOverflow
    //     0xde3280: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xde3284: ldr             x0, [x0, #0xc18]
    // 0xde3288: StoreField: r2->field_2b = r0
    //     0xde3288: stur            w0, [x2, #0x2b]
    // 0xde328c: ldur            x0, [fp, #-0x10]
    // 0xde3290: LoadField: r1 = r0->field_13
    //     0xde3290: ldur            w1, [x0, #0x13]
    // 0xde3294: DecompressPointer r1
    //     0xde3294: add             x1, x1, HEAP, lsl #32
    // 0xde3298: tbnz            w1, #4, #0xde32f0
    // 0xde329c: ldur            x1, [fp, #-0x18]
    // 0xde32a0: r0 = of()
    //     0xde32a0: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xde32a4: r1 = LoadClassIdInstr(r0)
    //     0xde32a4: ldur            x1, [x0, #-1]
    //     0xde32a8: ubfx            x1, x1, #0xc, #0x14
    // 0xde32ac: r17 = 4617
    //     0xde32ac: mov             x17, #0x1209
    // 0xde32b0: cmp             x1, x17
    // 0xde32b4: b.ne            #0xde32cc
    // 0xde32b8: LoadField: r1 = r0->field_27
    //     0xde32b8: ldur            w1, [x0, #0x27]
    // 0xde32bc: DecompressPointer r1
    //     0xde32bc: add             x1, x1, HEAP, lsl #32
    // 0xde32c0: LoadField: r0 = r1->field_b
    //     0xde32c0: ldur            w0, [x1, #0xb]
    // 0xde32c4: DecompressPointer r0
    //     0xde32c4: add             x0, x0, HEAP, lsl #32
    // 0xde32c8: b               #0xde32e8
    // 0xde32cc: LoadField: r1 = r0->field_2b
    //     0xde32cc: ldur            w1, [x0, #0x2b]
    // 0xde32d0: DecompressPointer r1
    //     0xde32d0: add             x1, x1, HEAP, lsl #32
    // 0xde32d4: LoadField: r0 = r1->field_3f
    //     0xde32d4: ldur            w0, [x1, #0x3f]
    // 0xde32d8: DecompressPointer r0
    //     0xde32d8: add             x0, x0, HEAP, lsl #32
    // 0xde32dc: LoadField: r1 = r0->field_b
    //     0xde32dc: ldur            w1, [x0, #0xb]
    // 0xde32e0: DecompressPointer r1
    //     0xde32e0: add             x1, x1, HEAP, lsl #32
    // 0xde32e4: mov             x0, x1
    // 0xde32e8: mov             x1, x0
    // 0xde32ec: b               #0xde32f4
    // 0xde32f0: r1 = Null
    //     0xde32f0: mov             x1, NULL
    // 0xde32f4: ldur            x2, [fp, #-0x10]
    // 0xde32f8: ldur            x0, [fp, #-0x28]
    // 0xde32fc: stur            x1, [fp, #-0x18]
    // 0xde3300: LoadField: r3 = r2->field_b
    //     0xde3300: ldur            w3, [x2, #0xb]
    // 0xde3304: DecompressPointer r3
    //     0xde3304: add             x3, x3, HEAP, lsl #32
    // 0xde3308: cmp             w3, NULL
    // 0xde330c: b.eq            #0xde3430
    // 0xde3310: LoadField: r4 = r3->field_f
    //     0xde3310: ldur            w4, [x3, #0xf]
    // 0xde3314: DecompressPointer r4
    //     0xde3314: add             x4, x4, HEAP, lsl #32
    // 0xde3318: stur            x4, [fp, #-8]
    // 0xde331c: r0 = CupertinoButton()
    //     0xde331c: bl              #0xde3458  ; AllocateCupertinoButtonStub -> CupertinoButton (size=0x5c)
    // 0xde3320: mov             x3, x0
    // 0xde3324: ldur            x0, [fp, #-0x28]
    // 0xde3328: stur            x3, [fp, #-0x20]
    // 0xde332c: StoreField: r3->field_b = r0
    //     0xde332c: stur            w0, [x3, #0xb]
    // 0xde3330: r0 = Instance_CupertinoButtonSize
    //     0xde3330: add             x0, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xde3334: ldr             x0, [x0, #0xfd8]
    // 0xde3338: StoreField: r3->field_3b = r0
    //     0xde3338: stur            w0, [x3, #0x3b]
    // 0xde333c: r0 = Instance_EdgeInsets
    //     0xde333c: add             x0, PP, #0x96, lsl #12  ; [pp+0x96038] Obj!EdgeInsets@129d4a1
    //     0xde3340: ldr             x0, [x0, #0x38]
    // 0xde3344: StoreField: r3->field_f = r0
    //     0xde3344: stur            w0, [x3, #0xf]
    // 0xde3348: ldur            x0, [fp, #-0x18]
    // 0xde334c: StoreField: r3->field_13 = r0
    //     0xde334c: stur            w0, [x3, #0x13]
    // 0xde3350: r0 = Instance_CupertinoDynamicColor
    //     0xde3350: add             x0, PP, #0x96, lsl #12  ; [pp+0x96040] Obj!CupertinoDynamicColor@12b3b71
    //     0xde3354: ldr             x0, [x0, #0x40]
    // 0xde3358: ArrayStore: r3[0] = r0  ; List_4
    //     0xde3358: stur            w0, [x3, #0x17]
    // 0xde335c: r0 = 0.000000
    //     0xde335c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xde3360: StoreField: r3->field_27 = r0
    //     0xde3360: stur            w0, [x3, #0x27]
    // 0xde3364: d0 = 0.700000
    //     0xde3364: add             x17, PP, #0x80, lsl #12  ; [pp+0x80c20] IMM: double(0.7) from 0x3fe6666666666666
    //     0xde3368: ldr             d0, [x17, #0xc20]
    // 0xde336c: StoreField: r3->field_2f = d0
    //     0xde336c: stur            d0, [x3, #0x2f]
    // 0xde3370: r0 = Instance_BorderRadius
    //     0xde3370: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e328] Obj!BorderRadius@129e2f1
    //     0xde3374: ldr             x0, [x0, #0x328]
    // 0xde3378: StoreField: r3->field_37 = r0
    //     0xde3378: stur            w0, [x3, #0x37]
    // 0xde337c: r0 = Instance_Alignment
    //     0xde337c: add             x0, PP, #0x19, lsl #12  ; [pp+0x19f88] Obj!Alignment@129e811
    //     0xde3380: ldr             x0, [x0, #0xf88]
    // 0xde3384: StoreField: r3->field_3f = r0
    //     0xde3384: stur            w0, [x3, #0x3f]
    // 0xde3388: r0 = false
    //     0xde3388: add             x0, NULL, #0x30  ; false
    // 0xde338c: StoreField: r3->field_4f = r0
    //     0xde338c: stur            w0, [x3, #0x4f]
    // 0xde3390: ldur            x0, [fp, #-8]
    // 0xde3394: StoreField: r3->field_1f = r0
    //     0xde3394: stur            w0, [x3, #0x1f]
    // 0xde3398: r0 = Instance__CupertinoButtonStyle
    //     0xde3398: add             x0, PP, #0x95, lsl #12  ; [pp+0x95fe8] Obj!_CupertinoButtonStyle@12c6021
    //     0xde339c: ldr             x0, [x0, #0xfe8]
    // 0xde33a0: StoreField: r3->field_57 = r0
    //     0xde33a0: stur            w0, [x3, #0x57]
    // 0xde33a4: ldur            x2, [fp, #-0x10]
    // 0xde33a8: r1 = Function '_onEnter@711085015':.
    //     0xde33a8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96048] AnonymousClosure: (0xde3528), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter (0xde3564)
    //     0xde33ac: ldr             x1, [x1, #0x48]
    // 0xde33b0: r0 = AllocateClosure()
    //     0xde33b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde33b4: stur            x0, [fp, #-8]
    // 0xde33b8: r0 = MouseRegion()
    //     0xde33b8: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xde33bc: mov             x3, x0
    // 0xde33c0: ldur            x0, [fp, #-8]
    // 0xde33c4: stur            x3, [fp, #-0x18]
    // 0xde33c8: StoreField: r3->field_f = r0
    //     0xde33c8: stur            w0, [x3, #0xf]
    // 0xde33cc: ldur            x2, [fp, #-0x10]
    // 0xde33d0: r1 = Function '_onExit@711085015':.
    //     0xde33d0: add             x1, PP, #0x96, lsl #12  ; [pp+0x96050] AnonymousClosure: (0xde3464), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit (0xde34a0)
    //     0xde33d4: ldr             x1, [x1, #0x50]
    // 0xde33d8: r0 = AllocateClosure()
    //     0xde33d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde33dc: mov             x1, x0
    // 0xde33e0: ldur            x0, [fp, #-0x18]
    // 0xde33e4: ArrayStore: r0[0] = r1  ; List_4
    //     0xde33e4: stur            w1, [x0, #0x17]
    // 0xde33e8: r1 = Instance__DeferringMouseCursor
    //     0xde33e8: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xde33ec: StoreField: r0->field_1b = r1
    //     0xde33ec: stur            w1, [x0, #0x1b]
    // 0xde33f0: r1 = true
    //     0xde33f0: add             x1, NULL, #0x20  ; true
    // 0xde33f4: StoreField: r0->field_1f = r1
    //     0xde33f4: stur            w1, [x0, #0x1f]
    // 0xde33f8: ldur            x1, [fp, #-0x20]
    // 0xde33fc: StoreField: r0->field_b = r1
    //     0xde33fc: stur            w1, [x0, #0xb]
    // 0xde3400: r0 = SizedBox()
    //     0xde3400: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde3404: r1 = inf
    //     0xde3404: add             x1, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xde3408: ldr             x1, [x1, #0x8a8]
    // 0xde340c: StoreField: r0->field_f = r1
    //     0xde340c: stur            w1, [x0, #0xf]
    // 0xde3410: ldur            x1, [fp, #-0x18]
    // 0xde3414: StoreField: r0->field_b = r1
    //     0xde3414: stur            w1, [x0, #0xb]
    // 0xde3418: LeaveFrame
    //     0xde3418: mov             SP, fp
    //     0xde341c: ldp             fp, lr, [SP], #0x10
    // 0xde3420: ret
    //     0xde3420: ret             
    // 0xde3424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3428: b               #0xde31b8
    // 0xde342c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde342c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde3430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde3430: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onExit(dynamic, PointerExitEvent) {
    // ** addr: 0xde3464, size: 0x3c
    // 0xde3464: EnterFrame
    //     0xde3464: stp             fp, lr, [SP, #-0x10]!
    //     0xde3468: mov             fp, SP
    // 0xde346c: ldr             x0, [fp, #0x18]
    // 0xde3470: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde3470: ldur            w1, [x0, #0x17]
    // 0xde3474: DecompressPointer r1
    //     0xde3474: add             x1, x1, HEAP, lsl #32
    // 0xde3478: CheckStackOverflow
    //     0xde3478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde347c: cmp             SP, x16
    //     0xde3480: b.ls            #0xde3498
    // 0xde3484: ldr             x2, [fp, #0x10]
    // 0xde3488: r0 = _onExit()
    //     0xde3488: bl              #0xde34a0  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit
    // 0xde348c: LeaveFrame
    //     0xde348c: mov             SP, fp
    //     0xde3490: ldp             fp, lr, [SP], #0x10
    // 0xde3494: ret
    //     0xde3494: ret             
    // 0xde3498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde349c: b               #0xde3484
  }
  _ _onExit(/* No info */) {
    // ** addr: 0xde34a0, size: 0x64
    // 0xde34a0: EnterFrame
    //     0xde34a0: stp             fp, lr, [SP, #-0x10]!
    //     0xde34a4: mov             fp, SP
    // 0xde34a8: AllocStack(0x8)
    //     0xde34a8: sub             SP, SP, #8
    // 0xde34ac: SetupParameters(_CupertinoDesktopTextSelectionToolbarButtonState this /* r1 => r1, fp-0x8 */)
    //     0xde34ac: stur            x1, [fp, #-8]
    // 0xde34b0: CheckStackOverflow
    //     0xde34b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde34b4: cmp             SP, x16
    //     0xde34b8: b.ls            #0xde34fc
    // 0xde34bc: r1 = 1
    //     0xde34bc: mov             x1, #1
    // 0xde34c0: r0 = AllocateContext()
    //     0xde34c0: bl              #0x13de838  ; AllocateContextStub
    // 0xde34c4: mov             x1, x0
    // 0xde34c8: ldur            x0, [fp, #-8]
    // 0xde34cc: StoreField: r1->field_f = r0
    //     0xde34cc: stur            w0, [x1, #0xf]
    // 0xde34d0: mov             x2, x1
    // 0xde34d4: r1 = Function '<anonymous closure>':.
    //     0xde34d4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96058] AnonymousClosure: (0xde3504), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit (0xde34a0)
    //     0xde34d8: ldr             x1, [x1, #0x58]
    // 0xde34dc: r0 = AllocateClosure()
    //     0xde34dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde34e0: ldur            x1, [fp, #-8]
    // 0xde34e4: mov             x2, x0
    // 0xde34e8: r0 = setState()
    //     0xde34e8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde34ec: r0 = Null
    //     0xde34ec: mov             x0, NULL
    // 0xde34f0: LeaveFrame
    //     0xde34f0: mov             SP, fp
    //     0xde34f4: ldp             fp, lr, [SP], #0x10
    // 0xde34f8: ret
    //     0xde34f8: ret             
    // 0xde34fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde34fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3500: b               #0xde34bc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde3504, size: 0x24
    // 0xde3504: r1 = false
    //     0xde3504: add             x1, NULL, #0x30  ; false
    // 0xde3508: ldr             x2, [SP]
    // 0xde350c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde350c: ldur            w3, [x2, #0x17]
    // 0xde3510: DecompressPointer r3
    //     0xde3510: add             x3, x3, HEAP, lsl #32
    // 0xde3514: LoadField: r2 = r3->field_f
    //     0xde3514: ldur            w2, [x3, #0xf]
    // 0xde3518: DecompressPointer r2
    //     0xde3518: add             x2, x2, HEAP, lsl #32
    // 0xde351c: StoreField: r2->field_13 = r1
    //     0xde351c: stur            w1, [x2, #0x13]
    // 0xde3520: r0 = Null
    //     0xde3520: mov             x0, NULL
    // 0xde3524: ret
    //     0xde3524: ret             
  }
  [closure] void _onEnter(dynamic, PointerEnterEvent) {
    // ** addr: 0xde3528, size: 0x3c
    // 0xde3528: EnterFrame
    //     0xde3528: stp             fp, lr, [SP, #-0x10]!
    //     0xde352c: mov             fp, SP
    // 0xde3530: ldr             x0, [fp, #0x18]
    // 0xde3534: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde3534: ldur            w1, [x0, #0x17]
    // 0xde3538: DecompressPointer r1
    //     0xde3538: add             x1, x1, HEAP, lsl #32
    // 0xde353c: CheckStackOverflow
    //     0xde353c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3540: cmp             SP, x16
    //     0xde3544: b.ls            #0xde355c
    // 0xde3548: ldr             x2, [fp, #0x10]
    // 0xde354c: r0 = _onEnter()
    //     0xde354c: bl              #0xde3564  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter
    // 0xde3550: LeaveFrame
    //     0xde3550: mov             SP, fp
    //     0xde3554: ldp             fp, lr, [SP], #0x10
    // 0xde3558: ret
    //     0xde3558: ret             
    // 0xde355c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde355c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3560: b               #0xde3548
  }
  _ _onEnter(/* No info */) {
    // ** addr: 0xde3564, size: 0x64
    // 0xde3564: EnterFrame
    //     0xde3564: stp             fp, lr, [SP, #-0x10]!
    //     0xde3568: mov             fp, SP
    // 0xde356c: AllocStack(0x8)
    //     0xde356c: sub             SP, SP, #8
    // 0xde3570: SetupParameters(_CupertinoDesktopTextSelectionToolbarButtonState this /* r1 => r1, fp-0x8 */)
    //     0xde3570: stur            x1, [fp, #-8]
    // 0xde3574: CheckStackOverflow
    //     0xde3574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3578: cmp             SP, x16
    //     0xde357c: b.ls            #0xde35c0
    // 0xde3580: r1 = 1
    //     0xde3580: mov             x1, #1
    // 0xde3584: r0 = AllocateContext()
    //     0xde3584: bl              #0x13de838  ; AllocateContextStub
    // 0xde3588: mov             x1, x0
    // 0xde358c: ldur            x0, [fp, #-8]
    // 0xde3590: StoreField: r1->field_f = r0
    //     0xde3590: stur            w0, [x1, #0xf]
    // 0xde3594: mov             x2, x1
    // 0xde3598: r1 = Function '<anonymous closure>':.
    //     0xde3598: add             x1, PP, #0x96, lsl #12  ; [pp+0x96060] AnonymousClosure: (0xde35c8), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter (0xde3564)
    //     0xde359c: ldr             x1, [x1, #0x60]
    // 0xde35a0: r0 = AllocateClosure()
    //     0xde35a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde35a4: ldur            x1, [fp, #-8]
    // 0xde35a8: mov             x2, x0
    // 0xde35ac: r0 = setState()
    //     0xde35ac: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde35b0: r0 = Null
    //     0xde35b0: mov             x0, NULL
    // 0xde35b4: LeaveFrame
    //     0xde35b4: mov             SP, fp
    //     0xde35b8: ldp             fp, lr, [SP], #0x10
    // 0xde35bc: ret
    //     0xde35bc: ret             
    // 0xde35c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde35c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde35c4: b               #0xde3580
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde35c8, size: 0x24
    // 0xde35c8: r1 = true
    //     0xde35c8: add             x1, NULL, #0x20  ; true
    // 0xde35cc: ldr             x2, [SP]
    // 0xde35d0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde35d0: ldur            w3, [x2, #0x17]
    // 0xde35d4: DecompressPointer r3
    //     0xde35d4: add             x3, x3, HEAP, lsl #32
    // 0xde35d8: LoadField: r2 = r3->field_f
    //     0xde35d8: ldur            w2, [x3, #0xf]
    // 0xde35dc: DecompressPointer r2
    //     0xde35dc: add             x2, x2, HEAP, lsl #32
    // 0xde35e0: StoreField: r2->field_13 = r1
    //     0xde35e0: stur            w1, [x2, #0x13]
    // 0xde35e4: r0 = Null
    //     0xde35e4: mov             x0, NULL
    // 0xde35e8: ret
    //     0xde35e8: ret             
  }
}

// class id: 6525, size: 0x18, field offset: 0xc
//   const constructor, 
class CupertinoDesktopTextSelectionToolbarButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa03bc, size: 0x2c
    // 0xfa03bc: EnterFrame
    //     0xfa03bc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa03c0: mov             fp, SP
    // 0xfa03c4: mov             x0, x1
    // 0xfa03c8: r1 = <CupertinoDesktopTextSelectionToolbarButton>
    //     0xfa03c8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cad8] TypeArguments: <CupertinoDesktopTextSelectionToolbarButton>
    //     0xfa03cc: ldr             x1, [x1, #0xad8]
    // 0xfa03d0: r0 = _CupertinoDesktopTextSelectionToolbarButtonState()
    //     0xfa03d0: bl              #0xfa03e8  ; Allocate_CupertinoDesktopTextSelectionToolbarButtonStateStub -> _CupertinoDesktopTextSelectionToolbarButtonState (size=0x18)
    // 0xfa03d4: r1 = false
    //     0xfa03d4: add             x1, NULL, #0x30  ; false
    // 0xfa03d8: StoreField: r0->field_13 = r1
    //     0xfa03d8: stur            w1, [x0, #0x13]
    // 0xfa03dc: LeaveFrame
    //     0xfa03dc: mov             SP, fp
    //     0xfa03e0: ldp             fp, lr, [SP], #0x10
    // 0xfa03e4: ret
    //     0xfa03e4: ret             
  }
}
