// lib: , url: package:flutter/src/cupertino/text_selection_toolbar_button.dart

// class id: 1048788, size: 0x8
class :: {
}

// class id: 4341, size: 0x14, field offset: 0xc
class _LiveTextIconPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb7509c, size: 0x528
    // 0xb7509c: EnterFrame
    //     0xb7509c: stp             fp, lr, [SP, #-0x10]!
    //     0xb750a0: mov             fp, SP
    // 0xb750a4: AllocStack(0x70)
    //     0xb750a4: sub             SP, SP, #0x70
    // 0xb750a8: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb750a8: mov             x0, x2
    //     0xb750ac: stur            x2, [fp, #-0x10]
    //     0xb750b0: stur            x3, [fp, #-0x18]
    // 0xb750b4: CheckStackOverflow
    //     0xb750b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb750b8: cmp             SP, x16
    //     0xb750bc: b.ls            #0xb75590
    // 0xb750c0: LoadField: r4 = r1->field_f
    //     0xb750c0: ldur            w4, [x1, #0xf]
    // 0xb750c4: DecompressPointer r4
    //     0xb750c4: add             x4, x4, HEAP, lsl #32
    // 0xb750c8: stur            x4, [fp, #-8]
    // 0xb750cc: LoadField: r2 = r1->field_b
    //     0xb750cc: ldur            w2, [x1, #0xb]
    // 0xb750d0: DecompressPointer r2
    //     0xb750d0: add             x2, x2, HEAP, lsl #32
    // 0xb750d4: mov             x1, x4
    // 0xb750d8: r0 = color=()
    //     0xb750d8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb750dc: ldur            x0, [fp, #-0x10]
    // 0xb750e0: LoadField: r1 = r0->field_7
    //     0xb750e0: ldur            w1, [x0, #7]
    // 0xb750e4: DecompressPointer r1
    //     0xb750e4: add             x1, x1, HEAP, lsl #32
    // 0xb750e8: cmp             w1, NULL
    // 0xb750ec: b.eq            #0xb75598
    // 0xb750f0: LoadField: r2 = r1->field_7
    //     0xb750f0: ldur            x2, [x1, #7]
    // 0xb750f4: ldr             x1, [x2]
    // 0xb750f8: cbz             x1, #0xb75510
    // 0xb750fc: ldur            x2, [fp, #-0x18]
    // 0xb75100: mov             x3, x1
    // 0xb75104: stur            x3, [fp, #-0x20]
    // 0xb75108: r1 = <Never>
    //     0xb75108: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7510c: r0 = Pointer()
    //     0xb7510c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75110: mov             x1, x0
    // 0xb75114: ldur            x0, [fp, #-0x20]
    // 0xb75118: StoreField: r1->field_7 = r0
    //     0xb75118: stur            x0, [x1, #7]
    // 0xb7511c: r0 = _save$Method$FfiNative()
    //     0xb7511c: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xb75120: ldur            x0, [fp, #-0x18]
    // 0xb75124: LoadField: d0 = r0->field_7
    //     0xb75124: ldur            d0, [x0, #7]
    // 0xb75128: stur            d0, [fp, #-0x68]
    // 0xb7512c: d1 = 2.000000
    //     0xb7512c: fmov            d1, #2.00000000
    // 0xb75130: fdiv            d2, d0, d1
    // 0xb75134: stur            d2, [fp, #-0x60]
    // 0xb75138: LoadField: d3 = r0->field_f
    //     0xb75138: ldur            d3, [x0, #0xf]
    // 0xb7513c: stur            d3, [fp, #-0x58]
    // 0xb75140: fdiv            d4, d3, d1
    // 0xb75144: ldur            x0, [fp, #-0x10]
    // 0xb75148: stur            d4, [fp, #-0x50]
    // 0xb7514c: LoadField: r1 = r0->field_7
    //     0xb7514c: ldur            w1, [x0, #7]
    // 0xb75150: DecompressPointer r1
    //     0xb75150: add             x1, x1, HEAP, lsl #32
    // 0xb75154: cmp             w1, NULL
    // 0xb75158: b.eq            #0xb7559c
    // 0xb7515c: LoadField: r2 = r1->field_7
    //     0xb7515c: ldur            x2, [x1, #7]
    // 0xb75160: ldr             x1, [x2]
    // 0xb75164: cbz             x1, #0xb75520
    // 0xb75168: mov             x2, x1
    // 0xb7516c: stur            x2, [fp, #-0x20]
    // 0xb75170: r1 = <Never>
    //     0xb75170: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75174: r0 = Pointer()
    //     0xb75174: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75178: mov             x1, x0
    // 0xb7517c: ldur            x0, [fp, #-0x20]
    // 0xb75180: StoreField: r1->field_7 = r0
    //     0xb75180: stur            x0, [x1, #7]
    // 0xb75184: ldur            d0, [fp, #-0x60]
    // 0xb75188: ldur            d1, [fp, #-0x50]
    // 0xb7518c: r0 = _translate$Method$FfiNative()
    //     0xb7518c: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xb75190: ldur            d0, [fp, #-0x68]
    // 0xb75194: fneg            d1, d0
    // 0xb75198: d0 = 2.000000
    //     0xb75198: fmov            d0, #2.00000000
    // 0xb7519c: fdiv            d2, d1, d0
    // 0xb751a0: ldur            d1, [fp, #-0x58]
    // 0xb751a4: stur            d2, [fp, #-0x60]
    // 0xb751a8: fneg            d3, d1
    // 0xb751ac: fdiv            d1, d3, d0
    // 0xb751b0: stur            d1, [fp, #-0x50]
    // 0xb751b4: r0 = _NativePath()
    //     0xb751b4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb751b8: mov             x1, x0
    // 0xb751bc: stur            x0, [fp, #-0x18]
    // 0xb751c0: r0 = __constructor$Method$FfiNative()
    //     0xb751c0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb751c4: ldur            d1, [fp, #-0x50]
    // 0xb751c8: d0 = 3.500000
    //     0xb751c8: fmov            d0, #3.50000000
    // 0xb751cc: fadd            d2, d1, d0
    // 0xb751d0: ldur            x0, [fp, #-0x18]
    // 0xb751d4: stur            d2, [fp, #-0x58]
    // 0xb751d8: LoadField: r1 = r0->field_7
    //     0xb751d8: ldur            w1, [x0, #7]
    // 0xb751dc: DecompressPointer r1
    //     0xb751dc: add             x1, x1, HEAP, lsl #32
    // 0xb751e0: cmp             w1, NULL
    // 0xb751e4: b.eq            #0xb755a0
    // 0xb751e8: LoadField: r2 = r1->field_7
    //     0xb751e8: ldur            x2, [x1, #7]
    // 0xb751ec: ldr             x1, [x2]
    // 0xb751f0: cbz             x1, #0xb75530
    // 0xb751f4: mov             x2, x1
    // 0xb751f8: stur            x2, [fp, #-0x20]
    // 0xb751fc: r1 = <Never>
    //     0xb751fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75200: r0 = Pointer()
    //     0xb75200: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75204: mov             x1, x0
    // 0xb75208: ldur            x0, [fp, #-0x20]
    // 0xb7520c: StoreField: r1->field_7 = r0
    //     0xb7520c: stur            x0, [x1, #7]
    // 0xb75210: ldur            d0, [fp, #-0x60]
    // 0xb75214: ldur            d1, [fp, #-0x58]
    // 0xb75218: r0 = _moveTo$Method$FfiNative()
    //     0xb75218: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb7521c: ldur            d1, [fp, #-0x50]
    // 0xb75220: d0 = 1.000000
    //     0xb75220: fmov            d0, #1.00000000
    // 0xb75224: fadd            d2, d1, d0
    // 0xb75228: ldur            x0, [fp, #-0x18]
    // 0xb7522c: stur            d2, [fp, #-0x58]
    // 0xb75230: LoadField: r1 = r0->field_7
    //     0xb75230: ldur            w1, [x0, #7]
    // 0xb75234: DecompressPointer r1
    //     0xb75234: add             x1, x1, HEAP, lsl #32
    // 0xb75238: cmp             w1, NULL
    // 0xb7523c: b.eq            #0xb755a4
    // 0xb75240: LoadField: r2 = r1->field_7
    //     0xb75240: ldur            x2, [x1, #7]
    // 0xb75244: ldr             x1, [x2]
    // 0xb75248: cbz             x1, #0xb75540
    // 0xb7524c: ldur            d3, [fp, #-0x60]
    // 0xb75250: mov             x2, x1
    // 0xb75254: stur            x2, [fp, #-0x20]
    // 0xb75258: r1 = <Never>
    //     0xb75258: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7525c: r0 = Pointer()
    //     0xb7525c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75260: mov             x1, x0
    // 0xb75264: ldur            x0, [fp, #-0x20]
    // 0xb75268: StoreField: r1->field_7 = r0
    //     0xb75268: stur            x0, [x1, #7]
    // 0xb7526c: ldur            d0, [fp, #-0x60]
    // 0xb75270: ldur            d1, [fp, #-0x58]
    // 0xb75274: r0 = _lineTo$Method$FfiNative()
    //     0xb75274: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb75278: ldur            d1, [fp, #-0x60]
    // 0xb7527c: d0 = 1.000000
    //     0xb7527c: fmov            d0, #1.00000000
    // 0xb75280: fadd            d2, d1, d0
    // 0xb75284: stur            d2, [fp, #-0x58]
    // 0xb75288: r0 = Offset()
    //     0xb75288: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb7528c: ldur            d0, [fp, #-0x58]
    // 0xb75290: StoreField: r0->field_7 = d0
    //     0xb75290: stur            d0, [x0, #7]
    // 0xb75294: ldur            d1, [fp, #-0x50]
    // 0xb75298: StoreField: r0->field_f = d1
    //     0xb75298: stur            d1, [x0, #0xf]
    // 0xb7529c: ldur            x1, [fp, #-0x18]
    // 0xb752a0: mov             x2, x0
    // 0xb752a4: r3 = Instance_Radius
    //     0xb752a4: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0fe8] Obj!Radius@12a7141
    //     0xb752a8: ldr             x3, [x3, #0xfe8]
    // 0xb752ac: r0 = arcToPoint()
    //     0xb752ac: bl              #0xb759f0  ; [dart:ui] _NativePath::arcToPoint
    // 0xb752b0: ldur            d0, [fp, #-0x60]
    // 0xb752b4: d1 = 3.500000
    //     0xb752b4: fmov            d1, #3.50000000
    // 0xb752b8: fadd            d2, d0, d1
    // 0xb752bc: ldur            x0, [fp, #-0x18]
    // 0xb752c0: stur            d2, [fp, #-0x58]
    // 0xb752c4: LoadField: r1 = r0->field_7
    //     0xb752c4: ldur            w1, [x0, #7]
    // 0xb752c8: DecompressPointer r1
    //     0xb752c8: add             x1, x1, HEAP, lsl #32
    // 0xb752cc: cmp             w1, NULL
    // 0xb752d0: b.eq            #0xb755a8
    // 0xb752d4: LoadField: r2 = r1->field_7
    //     0xb752d4: ldur            x2, [x1, #7]
    // 0xb752d8: ldr             x1, [x2]
    // 0xb752dc: cbz             x1, #0xb75550
    // 0xb752e0: ldur            x5, [fp, #-8]
    // 0xb752e4: mov             x2, x1
    // 0xb752e8: stur            x2, [fp, #-0x20]
    // 0xb752ec: r1 = <Never>
    //     0xb752ec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb752f0: r0 = Pointer()
    //     0xb752f0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb752f4: mov             x1, x0
    // 0xb752f8: ldur            x0, [fp, #-0x20]
    // 0xb752fc: StoreField: r1->field_7 = r0
    //     0xb752fc: stur            x0, [x1, #7]
    // 0xb75300: ldur            d0, [fp, #-0x58]
    // 0xb75304: ldur            d1, [fp, #-0x50]
    // 0xb75308: r0 = _lineTo$Method$FfiNative()
    //     0xb75308: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb7530c: r0 = Matrix4()
    //     0xb7530c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xb75310: r4 = 32
    //     0xb75310: mov             x4, #0x20
    // 0xb75314: stur            x0, [fp, #-0x28]
    // 0xb75318: r0 = AllocateFloat64Array()
    //     0xb75318: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xb7531c: mov             x2, x0
    // 0xb75320: ldur            x0, [fp, #-0x28]
    // 0xb75324: stur            x2, [fp, #-0x30]
    // 0xb75328: StoreField: r0->field_7 = r2
    //     0xb75328: stur            w2, [x0, #7]
    // 0xb7532c: mov             x1, x0
    // 0xb75330: r0 = setIdentity()
    //     0xb75330: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xb75334: ldur            x1, [fp, #-0x28]
    // 0xb75338: d0 = 1.570796
    //     0xb75338: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xb7533c: ldr             d0, [x17, #0xed8]
    // 0xb75340: r0 = rotateZ()
    //     0xb75340: bl              #0xb75838  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0xb75344: ldur            x5, [fp, #-8]
    // 0xb75348: LoadField: r0 = r5->field_7
    //     0xb75348: ldur            w0, [x5, #7]
    // 0xb7534c: DecompressPointer r0
    //     0xb7534c: add             x0, x0, HEAP, lsl #32
    // 0xb75350: stur            x0, [fp, #-0x40]
    // 0xb75354: r4 = 0
    //     0xb75354: mov             x4, #0
    // 0xb75358: ldur            x3, [fp, #-0x10]
    // 0xb7535c: ldur            x2, [fp, #-0x18]
    // 0xb75360: stur            x4, [fp, #-0x38]
    // 0xb75364: CheckStackOverflow
    //     0xb75364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb75368: cmp             SP, x16
    //     0xb7536c: b.ls            #0xb755ac
    // 0xb75370: cmp             x4, #4
    // 0xb75374: b.ge            #0xb75468
    // 0xb75378: LoadField: r6 = r5->field_b
    //     0xb75378: ldur            w6, [x5, #0xb]
    // 0xb7537c: DecompressPointer r6
    //     0xb7537c: add             x6, x6, HEAP, lsl #32
    // 0xb75380: stur            x6, [fp, #-0x28]
    // 0xb75384: LoadField: r1 = r3->field_7
    //     0xb75384: ldur            w1, [x3, #7]
    // 0xb75388: DecompressPointer r1
    //     0xb75388: add             x1, x1, HEAP, lsl #32
    // 0xb7538c: cmp             w1, NULL
    // 0xb75390: b.eq            #0xb755b4
    // 0xb75394: LoadField: r7 = r1->field_7
    //     0xb75394: ldur            x7, [x1, #7]
    // 0xb75398: ldr             x1, [x7]
    // 0xb7539c: cbz             x1, #0xb75570
    // 0xb753a0: mov             x7, x1
    // 0xb753a4: stur            x7, [fp, #-0x20]
    // 0xb753a8: r1 = <Never>
    //     0xb753a8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb753ac: r0 = Pointer()
    //     0xb753ac: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb753b0: mov             x2, x0
    // 0xb753b4: ldur            x0, [fp, #-0x20]
    // 0xb753b8: stur            x2, [fp, #-0x48]
    // 0xb753bc: StoreField: r2->field_7 = r0
    //     0xb753bc: stur            x0, [x2, #7]
    // 0xb753c0: ldur            x0, [fp, #-0x18]
    // 0xb753c4: LoadField: r1 = r0->field_7
    //     0xb753c4: ldur            w1, [x0, #7]
    // 0xb753c8: DecompressPointer r1
    //     0xb753c8: add             x1, x1, HEAP, lsl #32
    // 0xb753cc: cmp             w1, NULL
    // 0xb753d0: b.eq            #0xb755b8
    // 0xb753d4: LoadField: r3 = r1->field_7
    //     0xb753d4: ldur            x3, [x1, #7]
    // 0xb753d8: ldr             x1, [x3]
    // 0xb753dc: mov             x3, x1
    // 0xb753e0: stur            x3, [fp, #-0x20]
    // 0xb753e4: r1 = <Never>
    //     0xb753e4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb753e8: r0 = Pointer()
    //     0xb753e8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb753ec: mov             x1, x0
    // 0xb753f0: ldur            x0, [fp, #-0x20]
    // 0xb753f4: StoreField: r1->field_7 = r0
    //     0xb753f4: stur            x0, [x1, #7]
    // 0xb753f8: mov             x2, x1
    // 0xb753fc: ldur            x1, [fp, #-0x48]
    // 0xb75400: ldur            x3, [fp, #-0x28]
    // 0xb75404: ldur            x5, [fp, #-0x40]
    // 0xb75408: r0 = __drawPath$Method$FfiNative()
    //     0xb75408: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb7540c: ldur            x0, [fp, #-0x10]
    // 0xb75410: LoadField: r1 = r0->field_7
    //     0xb75410: ldur            w1, [x0, #7]
    // 0xb75414: DecompressPointer r1
    //     0xb75414: add             x1, x1, HEAP, lsl #32
    // 0xb75418: cmp             w1, NULL
    // 0xb7541c: b.eq            #0xb755bc
    // 0xb75420: LoadField: r2 = r1->field_7
    //     0xb75420: ldur            x2, [x1, #7]
    // 0xb75424: ldr             x1, [x2]
    // 0xb75428: cbz             x1, #0xb75560
    // 0xb7542c: ldur            x2, [fp, #-0x38]
    // 0xb75430: mov             x3, x1
    // 0xb75434: stur            x3, [fp, #-0x20]
    // 0xb75438: r1 = <Never>
    //     0xb75438: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7543c: r0 = Pointer()
    //     0xb7543c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75440: mov             x1, x0
    // 0xb75444: ldur            x0, [fp, #-0x20]
    // 0xb75448: StoreField: r1->field_7 = r0
    //     0xb75448: stur            x0, [x1, #7]
    // 0xb7544c: ldur            x2, [fp, #-0x30]
    // 0xb75450: r0 = __transform$Method$FfiNative()
    //     0xb75450: bl              #0xb75684  ; [dart:ui] _NativeCanvas::__transform$Method$FfiNative
    // 0xb75454: ldur            x0, [fp, #-0x38]
    // 0xb75458: add             x4, x0, #1
    // 0xb7545c: ldur            x5, [fp, #-8]
    // 0xb75460: ldur            x0, [fp, #-0x40]
    // 0xb75464: b               #0xb75358
    // 0xb75468: mov             x0, x3
    // 0xb7546c: mov             x1, x0
    // 0xb75470: ldur            x5, [fp, #-8]
    // 0xb75474: r2 = Instance_Offset
    //     0xb75474: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0ff0] Obj!Offset@12a7e51
    //     0xb75478: ldr             x2, [x2, #0xff0]
    // 0xb7547c: r3 = Instance_Offset
    //     0xb7547c: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0ff8] Obj!Offset@12a7e31
    //     0xb75480: ldr             x3, [x3, #0xff8]
    // 0xb75484: r0 = drawLine()
    //     0xb75484: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb75488: ldur            x1, [fp, #-0x10]
    // 0xb7548c: ldur            x5, [fp, #-8]
    // 0xb75490: r2 = Instance_Offset
    //     0xb75490: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa1000] Obj!Offset@12a7e11
    //     0xb75494: ldr             x2, [x2]
    // 0xb75498: r3 = Instance_Offset
    //     0xb75498: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1008] Obj!Offset@12a7df1
    //     0xb7549c: ldr             x3, [x3, #8]
    // 0xb754a0: r0 = drawLine()
    //     0xb754a0: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb754a4: ldur            x1, [fp, #-0x10]
    // 0xb754a8: ldur            x5, [fp, #-8]
    // 0xb754ac: r2 = Instance_Offset
    //     0xb754ac: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa1010] Obj!Offset@12a7dd1
    //     0xb754b0: ldr             x2, [x2, #0x10]
    // 0xb754b4: r3 = Instance_Offset
    //     0xb754b4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1018] Obj!Offset@12a7db1
    //     0xb754b8: ldr             x3, [x3, #0x18]
    // 0xb754bc: r0 = drawLine()
    //     0xb754bc: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb754c0: ldur            x0, [fp, #-0x10]
    // 0xb754c4: LoadField: r1 = r0->field_7
    //     0xb754c4: ldur            w1, [x0, #7]
    // 0xb754c8: DecompressPointer r1
    //     0xb754c8: add             x1, x1, HEAP, lsl #32
    // 0xb754cc: cmp             w1, NULL
    // 0xb754d0: b.eq            #0xb755c0
    // 0xb754d4: LoadField: r2 = r1->field_7
    //     0xb754d4: ldur            x2, [x1, #7]
    // 0xb754d8: ldr             x1, [x2]
    // 0xb754dc: cbz             x1, #0xb75580
    // 0xb754e0: mov             x2, x1
    // 0xb754e4: stur            x2, [fp, #-0x20]
    // 0xb754e8: r1 = <Never>
    //     0xb754e8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb754ec: r0 = Pointer()
    //     0xb754ec: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb754f0: mov             x1, x0
    // 0xb754f4: ldur            x0, [fp, #-0x20]
    // 0xb754f8: StoreField: r1->field_7 = r0
    //     0xb754f8: stur            x0, [x1, #7]
    // 0xb754fc: r0 = _restore$Method$FfiNative()
    //     0xb754fc: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xb75500: r0 = Null
    //     0xb75500: mov             x0, NULL
    // 0xb75504: LeaveFrame
    //     0xb75504: mov             SP, fp
    //     0xb75508: ldp             fp, lr, [SP], #0x10
    // 0xb7550c: ret
    //     0xb7550c: ret             
    // 0xb75510: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75510: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75514: str             x16, [SP]
    // 0xb75518: r0 = _throwNew()
    //     0xb75518: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7551c: brk             #0
    // 0xb75520: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75520: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75524: str             x16, [SP]
    // 0xb75528: r0 = _throwNew()
    //     0xb75528: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7552c: brk             #0
    // 0xb75530: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75530: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75534: str             x16, [SP]
    // 0xb75538: r0 = _throwNew()
    //     0xb75538: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7553c: brk             #0
    // 0xb75540: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75540: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75544: str             x16, [SP]
    // 0xb75548: r0 = _throwNew()
    //     0xb75548: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7554c: brk             #0
    // 0xb75550: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75550: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75554: str             x16, [SP]
    // 0xb75558: r0 = _throwNew()
    //     0xb75558: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7555c: brk             #0
    // 0xb75560: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75560: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75564: str             x16, [SP]
    // 0xb75568: r0 = _throwNew()
    //     0xb75568: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7556c: brk             #0
    // 0xb75570: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75570: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75574: str             x16, [SP]
    // 0xb75578: r0 = _throwNew()
    //     0xb75578: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7557c: brk             #0
    // 0xb75580: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75580: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75584: str             x16, [SP]
    // 0xb75588: r0 = _throwNew()
    //     0xb75588: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7558c: brk             #0
    // 0xb75590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb75590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb75594: b               #0xb750c0
    // 0xb75598: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb75598: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb7559c: r0 = NullErrorSharedWithFPURegs()
    //     0xb7559c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb755a0: r0 = NullErrorSharedWithFPURegs()
    //     0xb755a0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb755a4: r0 = NullErrorSharedWithFPURegs()
    //     0xb755a4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb755a8: r0 = NullErrorSharedWithFPURegs()
    //     0xb755a8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb755ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb755ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb755b0: b               #0xb75370
    // 0xb755b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb755b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb755b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb755b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb755bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb755bc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb755c0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb755c0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93138, size: 0xa0
    // 0xb93138: EnterFrame
    //     0xb93138: stp             fp, lr, [SP, #-0x10]!
    //     0xb9313c: mov             fp, SP
    // 0xb93140: AllocStack(0x20)
    //     0xb93140: sub             SP, SP, #0x20
    // 0xb93144: SetupParameters(_LiveTextIconPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93144: mov             x4, x1
    //     0xb93148: mov             x3, x2
    //     0xb9314c: stur            x1, [fp, #-8]
    //     0xb93150: stur            x2, [fp, #-0x10]
    // 0xb93154: CheckStackOverflow
    //     0xb93154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93158: cmp             SP, x16
    //     0xb9315c: b.ls            #0xb931d0
    // 0xb93160: mov             x0, x3
    // 0xb93164: r2 = Null
    //     0xb93164: mov             x2, NULL
    // 0xb93168: r1 = Null
    //     0xb93168: mov             x1, NULL
    // 0xb9316c: r4 = 60
    //     0xb9316c: mov             x4, #0x3c
    // 0xb93170: branchIfSmi(r0, 0xb9317c)
    //     0xb93170: tbz             w0, #0, #0xb9317c
    // 0xb93174: r4 = LoadClassIdInstr(r0)
    //     0xb93174: ldur            x4, [x0, #-1]
    //     0xb93178: ubfx            x4, x4, #0xc, #0x14
    // 0xb9317c: r17 = 4341
    //     0xb9317c: mov             x17, #0x10f5
    // 0xb93180: cmp             x4, x17
    // 0xb93184: b.eq            #0xb9319c
    // 0xb93188: r8 = _LiveTextIconPainter
    //     0xb93188: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0fd0] Type: _LiveTextIconPainter
    //     0xb9318c: ldr             x8, [x8, #0xfd0]
    // 0xb93190: r3 = Null
    //     0xb93190: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0fd8] Null
    //     0xb93194: ldr             x3, [x3, #0xfd8]
    // 0xb93198: r0 = DefaultTypeTest()
    //     0xb93198: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9319c: ldur            x0, [fp, #-0x10]
    // 0xb931a0: LoadField: r1 = r0->field_b
    //     0xb931a0: ldur            w1, [x0, #0xb]
    // 0xb931a4: DecompressPointer r1
    //     0xb931a4: add             x1, x1, HEAP, lsl #32
    // 0xb931a8: ldur            x0, [fp, #-8]
    // 0xb931ac: LoadField: r2 = r0->field_b
    //     0xb931ac: ldur            w2, [x0, #0xb]
    // 0xb931b0: DecompressPointer r2
    //     0xb931b0: add             x2, x2, HEAP, lsl #32
    // 0xb931b4: stp             x2, x1, [SP]
    // 0xb931b8: r0 = ==()
    //     0xb931b8: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0xb931bc: eor             x1, x0, #0x10
    // 0xb931c0: mov             x0, x1
    // 0xb931c4: LeaveFrame
    //     0xb931c4: mov             SP, fp
    //     0xb931c8: ldp             fp, lr, [SP], #0x10
    // 0xb931cc: ret
    //     0xb931cc: ret             
    // 0xb931d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb931d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb931d4: b               #0xb93160
  }
  _ _LiveTextIconPainter(/* No info */) {
    // ** addr: 0xde7670, size: 0xcc
    // 0xde7670: EnterFrame
    //     0xde7670: stp             fp, lr, [SP, #-0x10]!
    //     0xde7674: mov             fp, SP
    // 0xde7678: AllocStack(0x28)
    //     0xde7678: sub             SP, SP, #0x28
    // 0xde767c: SetupParameters(_LiveTextIconPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde767c: mov             x0, x2
    //     0xde7680: stur            x1, [fp, #-8]
    //     0xde7684: stur            x2, [fp, #-0x10]
    // 0xde7688: CheckStackOverflow
    //     0xde7688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde768c: cmp             SP, x16
    //     0xde7690: b.ls            #0xde7734
    // 0xde7694: r16 = 136
    //     0xde7694: mov             x16, #0x88
    // 0xde7698: stp             x16, NULL, [SP]
    // 0xde769c: r0 = ByteData()
    //     0xde769c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xde76a0: stur            x0, [fp, #-0x18]
    // 0xde76a4: r0 = Paint()
    //     0xde76a4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xde76a8: ldur            x1, [fp, #-0x18]
    // 0xde76ac: StoreField: r0->field_7 = r1
    //     0xde76ac: stur            w1, [x0, #7]
    // 0xde76b0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde76b0: ldur            w2, [x1, #0x17]
    // 0xde76b4: DecompressPointer r2
    //     0xde76b4: add             x2, x2, HEAP, lsl #32
    // 0xde76b8: LoadField: r1 = r2->field_7
    //     0xde76b8: ldur            x1, [x2, #7]
    // 0xde76bc: r3 = 1
    //     0xde76bc: mov             x3, #1
    // 0xde76c0: str             w3, [x1, #0x24]
    // 0xde76c4: LoadField: r1 = r2->field_7
    //     0xde76c4: ldur            x1, [x2, #7]
    // 0xde76c8: str             w3, [x1, #0x28]
    // 0xde76cc: LoadField: r1 = r2->field_7
    //     0xde76cc: ldur            x1, [x2, #7]
    // 0xde76d0: d0 = 0.000000
    //     0xde76d0: add             x17, PP, #0x92, lsl #12  ; [pp+0x926a0] IMM: 0x3f800000
    //     0xde76d4: ldr             s0, [x17, #0x6a0]
    // 0xde76d8: str             s0, [x1, #0x20]
    // 0xde76dc: LoadField: r1 = r2->field_7
    //     0xde76dc: ldur            x1, [x2, #7]
    // 0xde76e0: str             w3, [x1, #0x1c]
    // 0xde76e4: ldur            x1, [fp, #-8]
    // 0xde76e8: StoreField: r1->field_f = r0
    //     0xde76e8: stur            w0, [x1, #0xf]
    //     0xde76ec: ldurb           w16, [x1, #-1]
    //     0xde76f0: ldurb           w17, [x0, #-1]
    //     0xde76f4: and             x16, x17, x16, lsr #2
    //     0xde76f8: tst             x16, HEAP, lsr #32
    //     0xde76fc: b.eq            #0xde7704
    //     0xde7700: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde7704: ldur            x0, [fp, #-0x10]
    // 0xde7708: StoreField: r1->field_b = r0
    //     0xde7708: stur            w0, [x1, #0xb]
    //     0xde770c: ldurb           w16, [x1, #-1]
    //     0xde7710: ldurb           w17, [x0, #-1]
    //     0xde7714: and             x16, x17, x16, lsr #2
    //     0xde7718: tst             x16, HEAP, lsr #32
    //     0xde771c: b.eq            #0xde7724
    //     0xde7720: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde7724: r0 = Null
    //     0xde7724: mov             x0, NULL
    // 0xde7728: LeaveFrame
    //     0xde7728: mov             SP, fp
    //     0xde772c: ldp             fp, lr, [SP], #0x10
    // 0xde7730: ret
    //     0xde7730: ret             
    // 0xde7734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7738: b               #0xde7694
  }
}

// class id: 5482, size: 0x18, field offset: 0x14
class _CupertinoTextSelectionToolbarButtonState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde7280, size: 0x184
    // 0xde7280: EnterFrame
    //     0xde7280: stp             fp, lr, [SP, #-0x10]!
    //     0xde7284: mov             fp, SP
    // 0xde7288: AllocStack(0x48)
    //     0xde7288: sub             SP, SP, #0x48
    // 0xde728c: SetupParameters(_CupertinoTextSelectionToolbarButtonState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde728c: mov             x3, x1
    //     0xde7290: mov             x0, x2
    //     0xde7294: stur            x1, [fp, #-8]
    //     0xde7298: stur            x2, [fp, #-0x10]
    // 0xde729c: CheckStackOverflow
    //     0xde729c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde72a0: cmp             SP, x16
    //     0xde72a4: b.ls            #0xde73f8
    // 0xde72a8: mov             x1, x3
    // 0xde72ac: mov             x2, x0
    // 0xde72b0: r0 = _getContentWidget()
    //     0xde72b0: bl              #0xde7404  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_getContentWidget
    // 0xde72b4: mov             x3, x0
    // 0xde72b8: ldur            x0, [fp, #-8]
    // 0xde72bc: stur            x3, [fp, #-0x18]
    // 0xde72c0: LoadField: r1 = r0->field_13
    //     0xde72c0: ldur            w1, [x0, #0x13]
    // 0xde72c4: DecompressPointer r1
    //     0xde72c4: add             x1, x1, HEAP, lsl #32
    // 0xde72c8: tbnz            w1, #4, #0xde72e4
    // 0xde72cc: ldur            x2, [fp, #-0x10]
    // 0xde72d0: r1 = Instance_CupertinoDynamicColor
    //     0xde72d0: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fd0] Obj!CupertinoDynamicColor@12b3df1
    //     0xde72d4: ldr             x1, [x1, #0xfd0]
    // 0xde72d8: r0 = resolveFrom()
    //     0xde72d8: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde72dc: mov             x1, x0
    // 0xde72e0: b               #0xde72ec
    // 0xde72e4: r1 = Instance_Color
    //     0xde72e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xde72e8: ldr             x1, [x1, #0x810]
    // 0xde72ec: ldur            x2, [fp, #-8]
    // 0xde72f0: ldur            x0, [fp, #-0x18]
    // 0xde72f4: stur            x1, [fp, #-0x20]
    // 0xde72f8: LoadField: r3 = r2->field_b
    //     0xde72f8: ldur            w3, [x2, #0xb]
    // 0xde72fc: DecompressPointer r3
    //     0xde72fc: add             x3, x3, HEAP, lsl #32
    // 0xde7300: cmp             w3, NULL
    // 0xde7304: b.eq            #0xde7400
    // 0xde7308: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xde7308: ldur            w4, [x3, #0x17]
    // 0xde730c: DecompressPointer r4
    //     0xde730c: add             x4, x4, HEAP, lsl #32
    // 0xde7310: stur            x4, [fp, #-0x10]
    // 0xde7314: r0 = CupertinoButton()
    //     0xde7314: bl              #0xde3458  ; AllocateCupertinoButtonStub -> CupertinoButton (size=0x5c)
    // 0xde7318: mov             x1, x0
    // 0xde731c: ldur            x0, [fp, #-0x18]
    // 0xde7320: stur            x1, [fp, #-0x28]
    // 0xde7324: StoreField: r1->field_b = r0
    //     0xde7324: stur            w0, [x1, #0xb]
    // 0xde7328: r0 = Instance_CupertinoButtonSize
    //     0xde7328: add             x0, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xde732c: ldr             x0, [x0, #0xfd8]
    // 0xde7330: StoreField: r1->field_3b = r0
    //     0xde7330: stur            w0, [x1, #0x3b]
    // 0xde7334: r0 = Instance_EdgeInsets
    //     0xde7334: add             x0, PP, #0x95, lsl #12  ; [pp+0x95fe0] Obj!EdgeInsets@129d531
    //     0xde7338: ldr             x0, [x0, #0xfe0]
    // 0xde733c: StoreField: r1->field_f = r0
    //     0xde733c: stur            w0, [x1, #0xf]
    // 0xde7340: ldur            x0, [fp, #-0x20]
    // 0xde7344: StoreField: r1->field_13 = r0
    //     0xde7344: stur            w0, [x1, #0x13]
    // 0xde7348: r0 = Instance_Color
    //     0xde7348: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xde734c: ldr             x0, [x0, #0x810]
    // 0xde7350: ArrayStore: r1[0] = r0  ; List_4
    //     0xde7350: stur            w0, [x1, #0x17]
    // 0xde7354: d0 = 1.000000
    //     0xde7354: fmov            d0, #1.00000000
    // 0xde7358: StoreField: r1->field_2f = d0
    //     0xde7358: stur            d0, [x1, #0x2f]
    // 0xde735c: r0 = Instance_Alignment
    //     0xde735c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde7360: ldr             x0, [x0, #0xb80]
    // 0xde7364: StoreField: r1->field_3f = r0
    //     0xde7364: stur            w0, [x1, #0x3f]
    // 0xde7368: r0 = false
    //     0xde7368: add             x0, NULL, #0x30  ; false
    // 0xde736c: StoreField: r1->field_4f = r0
    //     0xde736c: stur            w0, [x1, #0x4f]
    // 0xde7370: ldur            x0, [fp, #-0x10]
    // 0xde7374: StoreField: r1->field_1f = r0
    //     0xde7374: stur            w0, [x1, #0x1f]
    // 0xde7378: r0 = Instance__CupertinoButtonStyle
    //     0xde7378: add             x0, PP, #0x95, lsl #12  ; [pp+0x95fe8] Obj!_CupertinoButtonStyle@12c6021
    //     0xde737c: ldr             x0, [x0, #0xfe8]
    // 0xde7380: StoreField: r1->field_57 = r0
    //     0xde7380: stur            w0, [x1, #0x57]
    // 0xde7384: r0 = GestureDetector()
    //     0xde7384: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xde7388: ldur            x2, [fp, #-8]
    // 0xde738c: r1 = Function '_onTapDown@712370134':.
    //     0xde738c: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ff0] AnonymousClosure: (0xde7acc), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapDown (0xde7b08)
    //     0xde7390: ldr             x1, [x1, #0xff0]
    // 0xde7394: stur            x0, [fp, #-0x10]
    // 0xde7398: r0 = AllocateClosure()
    //     0xde7398: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde739c: ldur            x2, [fp, #-8]
    // 0xde73a0: r1 = Function '_onTapUp@712370134':.
    //     0xde73a0: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ff8] AnonymousClosure: (0xde79f0), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapUp (0xde7a2c)
    //     0xde73a4: ldr             x1, [x1, #0xff8]
    // 0xde73a8: stur            x0, [fp, #-0x18]
    // 0xde73ac: r0 = AllocateClosure()
    //     0xde73ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde73b0: ldur            x2, [fp, #-8]
    // 0xde73b4: r1 = Function '_onTapCancel@712370134':.
    //     0xde73b4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96000] AnonymousClosure: (0xde7934), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapCancel (0xde796c)
    //     0xde73b8: ldr             x1, [x1]
    // 0xde73bc: stur            x0, [fp, #-8]
    // 0xde73c0: r0 = AllocateClosure()
    //     0xde73c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde73c4: ldur            x16, [fp, #-0x18]
    // 0xde73c8: ldur            lr, [fp, #-8]
    // 0xde73cc: stp             lr, x16, [SP, #0x10]
    // 0xde73d0: ldur            x16, [fp, #-0x28]
    // 0xde73d4: stp             x16, x0, [SP]
    // 0xde73d8: ldur            x1, [fp, #-0x10]
    // 0xde73dc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, onTapCancel, 0x3, onTapDown, 0x1, onTapUp, 0x2, null]
    //     0xde73dc: add             x4, PP, #0x96, lsl #12  ; [pp+0x96008] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "onTapCancel", 0x3, "onTapDown", 0x1, "onTapUp", 0x2, Null]
    //     0xde73e0: ldr             x4, [x4, #8]
    // 0xde73e4: r0 = GestureDetector()
    //     0xde73e4: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xde73e8: ldur            x0, [fp, #-0x10]
    // 0xde73ec: LeaveFrame
    //     0xde73ec: mov             SP, fp
    //     0xde73f0: ldp             fp, lr, [SP], #0x10
    // 0xde73f4: ret
    //     0xde73f4: ret             
    // 0xde73f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde73f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde73fc: b               #0xde72a8
    // 0xde7400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7400: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getContentWidget(/* No info */) {
    // ** addr: 0xde7404, size: 0x26c
    // 0xde7404: EnterFrame
    //     0xde7404: stp             fp, lr, [SP, #-0x10]!
    //     0xde7408: mov             fp, SP
    // 0xde740c: AllocStack(0x28)
    //     0xde740c: sub             SP, SP, #0x28
    // 0xde7410: SetupParameters(_CupertinoTextSelectionToolbarButtonState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde7410: mov             x3, x1
    //     0xde7414: mov             x0, x2
    //     0xde7418: stur            x1, [fp, #-8]
    //     0xde741c: stur            x2, [fp, #-0x10]
    // 0xde7420: CheckStackOverflow
    //     0xde7420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7424: cmp             SP, x16
    //     0xde7428: b.ls            #0xde7658
    // 0xde742c: LoadField: r1 = r3->field_b
    //     0xde742c: ldur            w1, [x3, #0xb]
    // 0xde7430: DecompressPointer r1
    //     0xde7430: add             x1, x1, HEAP, lsl #32
    // 0xde7434: cmp             w1, NULL
    // 0xde7438: b.eq            #0xde7660
    // 0xde743c: LoadField: r2 = r1->field_13
    //     0xde743c: ldur            w2, [x1, #0x13]
    // 0xde7440: DecompressPointer r2
    //     0xde7440: add             x2, x2, HEAP, lsl #32
    // 0xde7444: cmp             w2, NULL
    // 0xde7448: b.eq            #0xde745c
    // 0xde744c: mov             x0, x2
    // 0xde7450: LeaveFrame
    //     0xde7450: mov             SP, fp
    //     0xde7454: ldp             fp, lr, [SP], #0x10
    // 0xde7458: ret
    //     0xde7458: ret             
    // 0xde745c: LoadField: r2 = r1->field_f
    //     0xde745c: ldur            w2, [x1, #0xf]
    // 0xde7460: DecompressPointer r2
    //     0xde7460: add             x2, x2, HEAP, lsl #32
    // 0xde7464: cmp             w2, NULL
    // 0xde7468: b.eq            #0xde7664
    // 0xde746c: mov             x1, x0
    // 0xde7470: r0 = getButtonLabel()
    //     0xde7470: bl              #0xde7748  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::getButtonLabel
    // 0xde7474: mov             x3, x0
    // 0xde7478: ldur            x0, [fp, #-8]
    // 0xde747c: stur            x3, [fp, #-0x18]
    // 0xde7480: LoadField: r1 = r0->field_b
    //     0xde7480: ldur            w1, [x0, #0xb]
    // 0xde7484: DecompressPointer r1
    //     0xde7484: add             x1, x1, HEAP, lsl #32
    // 0xde7488: cmp             w1, NULL
    // 0xde748c: b.eq            #0xde7668
    // 0xde7490: ldur            x2, [fp, #-0x10]
    // 0xde7494: r1 = Instance_CupertinoDynamicColor
    //     0xde7494: add             x1, PP, #0x96, lsl #12  ; [pp+0x96028] Obj!CupertinoDynamicColor@12b3af1
    //     0xde7498: ldr             x1, [x1, #0x28]
    // 0xde749c: r0 = resolveFrom()
    //     0xde749c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde74a0: str             x0, [SP]
    // 0xde74a4: r1 = Instance_TextStyle
    //     0xde74a4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96030] Obj!TextStyle@12b0e01
    //     0xde74a8: ldr             x1, [x1, #0x30]
    // 0xde74ac: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde74ac: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde74b0: ldr             x4, [x4, #0x7f0]
    // 0xde74b4: r0 = copyWith()
    //     0xde74b4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde74b8: stur            x0, [fp, #-0x20]
    // 0xde74bc: r0 = Text()
    //     0xde74bc: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xde74c0: mov             x1, x0
    // 0xde74c4: ldur            x0, [fp, #-0x18]
    // 0xde74c8: StoreField: r1->field_b = r0
    //     0xde74c8: stur            w0, [x1, #0xb]
    // 0xde74cc: ldur            x0, [fp, #-0x20]
    // 0xde74d0: StoreField: r1->field_13 = r0
    //     0xde74d0: stur            w0, [x1, #0x13]
    // 0xde74d4: r0 = Instance_TextOverflow
    //     0xde74d4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xde74d8: ldr             x0, [x0, #0xc18]
    // 0xde74dc: StoreField: r1->field_2b = r0
    //     0xde74dc: stur            w0, [x1, #0x2b]
    // 0xde74e0: ldur            x0, [fp, #-8]
    // 0xde74e4: LoadField: r2 = r0->field_b
    //     0xde74e4: ldur            w2, [x0, #0xb]
    // 0xde74e8: DecompressPointer r2
    //     0xde74e8: add             x2, x2, HEAP, lsl #32
    // 0xde74ec: cmp             w2, NULL
    // 0xde74f0: b.eq            #0xde766c
    // 0xde74f4: LoadField: r0 = r2->field_f
    //     0xde74f4: ldur            w0, [x2, #0xf]
    // 0xde74f8: DecompressPointer r0
    //     0xde74f8: add             x0, x0, HEAP, lsl #32
    // 0xde74fc: cmp             w0, NULL
    // 0xde7500: b.ne            #0xde750c
    // 0xde7504: r0 = Null
    //     0xde7504: mov             x0, NULL
    // 0xde7508: b               #0xde7518
    // 0xde750c: LoadField: r2 = r0->field_b
    //     0xde750c: ldur            w2, [x0, #0xb]
    // 0xde7510: DecompressPointer r2
    //     0xde7510: add             x2, x2, HEAP, lsl #32
    // 0xde7514: mov             x0, x2
    // 0xde7518: r16 = Instance_ContextMenuButtonType
    //     0xde7518: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7f8] Obj!ContextMenuButtonType@12c3501
    //     0xde751c: ldr             x16, [x16, #0x7f8]
    // 0xde7520: cmp             w0, w16
    // 0xde7524: b.eq            #0xde75b0
    // 0xde7528: r16 = Instance_ContextMenuButtonType
    //     0xde7528: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a800] Obj!ContextMenuButtonType@12c34e1
    //     0xde752c: ldr             x16, [x16, #0x800]
    // 0xde7530: cmp             w0, w16
    // 0xde7534: b.eq            #0xde75b0
    // 0xde7538: r16 = Instance_ContextMenuButtonType
    //     0xde7538: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a808] Obj!ContextMenuButtonType@12c34c1
    //     0xde753c: ldr             x16, [x16, #0x808]
    // 0xde7540: cmp             w0, w16
    // 0xde7544: b.eq            #0xde75b0
    // 0xde7548: r16 = Instance_ContextMenuButtonType
    //     0xde7548: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a818] Obj!ContextMenuButtonType@12c3481
    //     0xde754c: ldr             x16, [x16, #0x818]
    // 0xde7550: cmp             w0, w16
    // 0xde7554: b.eq            #0xde75b0
    // 0xde7558: r16 = Instance_ContextMenuButtonType
    //     0xde7558: add             x16, PP, #0x80, lsl #12  ; [pp+0x80a28] Obj!ContextMenuButtonType@12c3521
    //     0xde755c: ldr             x16, [x16, #0xa28]
    // 0xde7560: cmp             w0, w16
    // 0xde7564: b.eq            #0xde75b0
    // 0xde7568: r16 = Instance_ContextMenuButtonType
    //     0xde7568: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a820] Obj!ContextMenuButtonType@12c3461
    //     0xde756c: ldr             x16, [x16, #0x820]
    // 0xde7570: cmp             w0, w16
    // 0xde7574: b.eq            #0xde75b0
    // 0xde7578: r16 = Instance_ContextMenuButtonType
    //     0xde7578: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a828] Obj!ContextMenuButtonType@12c3441
    //     0xde757c: ldr             x16, [x16, #0x828]
    // 0xde7580: cmp             w0, w16
    // 0xde7584: b.eq            #0xde75b0
    // 0xde7588: r16 = Instance_ContextMenuButtonType
    //     0xde7588: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a810] Obj!ContextMenuButtonType@12c34a1
    //     0xde758c: ldr             x16, [x16, #0x810]
    // 0xde7590: cmp             w0, w16
    // 0xde7594: b.eq            #0xde75b0
    // 0xde7598: r16 = Instance_ContextMenuButtonType
    //     0xde7598: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7c8] Obj!ContextMenuButtonType@12c3401
    //     0xde759c: ldr             x16, [x16, #0x7c8]
    // 0xde75a0: cmp             w0, w16
    // 0xde75a4: b.eq            #0xde75b0
    // 0xde75a8: cmp             w0, NULL
    // 0xde75ac: b.ne            #0xde75c0
    // 0xde75b0: mov             x0, x1
    // 0xde75b4: LeaveFrame
    //     0xde75b4: mov             SP, fp
    //     0xde75b8: ldp             fp, lr, [SP], #0x10
    // 0xde75bc: ret
    //     0xde75bc: ret             
    // 0xde75c0: r16 = Instance_ContextMenuButtonType
    //     0xde75c0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a830] Obj!ContextMenuButtonType@12c3421
    //     0xde75c4: ldr             x16, [x16, #0x830]
    // 0xde75c8: cmp             w0, w16
    // 0xde75cc: b.ne            #0xde7648
    // 0xde75d0: ldur            x2, [fp, #-0x10]
    // 0xde75d4: r1 = Instance_CupertinoDynamicColor
    //     0xde75d4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96028] Obj!CupertinoDynamicColor@12b3af1
    //     0xde75d8: ldr             x1, [x1, #0x28]
    // 0xde75dc: r0 = resolveFrom()
    //     0xde75dc: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde75e0: stur            x0, [fp, #-8]
    // 0xde75e4: r0 = _LiveTextIconPainter()
    //     0xde75e4: bl              #0xde773c  ; Allocate_LiveTextIconPainterStub -> _LiveTextIconPainter (size=0x14)
    // 0xde75e8: mov             x1, x0
    // 0xde75ec: ldur            x2, [fp, #-8]
    // 0xde75f0: stur            x0, [fp, #-8]
    // 0xde75f4: r0 = _LiveTextIconPainter()
    //     0xde75f4: bl              #0xde7670  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _LiveTextIconPainter::_LiveTextIconPainter
    // 0xde75f8: r0 = CustomPaint()
    //     0xde75f8: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xde75fc: mov             x1, x0
    // 0xde7600: ldur            x0, [fp, #-8]
    // 0xde7604: stur            x1, [fp, #-0x10]
    // 0xde7608: StoreField: r1->field_f = r0
    //     0xde7608: stur            w0, [x1, #0xf]
    // 0xde760c: r0 = Instance_Size
    //     0xde760c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xde7610: ArrayStore: r1[0] = r0  ; List_4
    //     0xde7610: stur            w0, [x1, #0x17]
    // 0xde7614: r0 = false
    //     0xde7614: add             x0, NULL, #0x30  ; false
    // 0xde7618: StoreField: r1->field_1b = r0
    //     0xde7618: stur            w0, [x1, #0x1b]
    // 0xde761c: StoreField: r1->field_1f = r0
    //     0xde761c: stur            w0, [x1, #0x1f]
    // 0xde7620: r0 = SizedBox()
    //     0xde7620: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde7624: r1 = 13.000000
    //     0xde7624: add             x1, PP, #0x19, lsl #12  ; [pp+0x19d68] 13
    //     0xde7628: ldr             x1, [x1, #0xd68]
    // 0xde762c: StoreField: r0->field_f = r1
    //     0xde762c: stur            w1, [x0, #0xf]
    // 0xde7630: StoreField: r0->field_13 = r1
    //     0xde7630: stur            w1, [x0, #0x13]
    // 0xde7634: ldur            x1, [fp, #-0x10]
    // 0xde7638: StoreField: r0->field_b = r1
    //     0xde7638: stur            w1, [x0, #0xb]
    // 0xde763c: LeaveFrame
    //     0xde763c: mov             SP, fp
    //     0xde7640: ldp             fp, lr, [SP], #0x10
    // 0xde7644: ret
    //     0xde7644: ret             
    // 0xde7648: r0 = Null
    //     0xde7648: mov             x0, NULL
    // 0xde764c: LeaveFrame
    //     0xde764c: mov             SP, fp
    //     0xde7650: ldp             fp, lr, [SP], #0x10
    // 0xde7654: ret
    //     0xde7654: ret             
    // 0xde7658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde765c: b               #0xde742c
    // 0xde7660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7660: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7664: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7668: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde766c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde766c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onTapCancel(dynamic) {
    // ** addr: 0xde7934, size: 0x38
    // 0xde7934: EnterFrame
    //     0xde7934: stp             fp, lr, [SP, #-0x10]!
    //     0xde7938: mov             fp, SP
    // 0xde793c: ldr             x0, [fp, #0x10]
    // 0xde7940: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde7940: ldur            w1, [x0, #0x17]
    // 0xde7944: DecompressPointer r1
    //     0xde7944: add             x1, x1, HEAP, lsl #32
    // 0xde7948: CheckStackOverflow
    //     0xde7948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde794c: cmp             SP, x16
    //     0xde7950: b.ls            #0xde7964
    // 0xde7954: r0 = _onTapCancel()
    //     0xde7954: bl              #0xde796c  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapCancel
    // 0xde7958: LeaveFrame
    //     0xde7958: mov             SP, fp
    //     0xde795c: ldp             fp, lr, [SP], #0x10
    // 0xde7960: ret
    //     0xde7960: ret             
    // 0xde7964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7968: b               #0xde7954
  }
  _ _onTapCancel(/* No info */) {
    // ** addr: 0xde796c, size: 0x64
    // 0xde796c: EnterFrame
    //     0xde796c: stp             fp, lr, [SP, #-0x10]!
    //     0xde7970: mov             fp, SP
    // 0xde7974: AllocStack(0x8)
    //     0xde7974: sub             SP, SP, #8
    // 0xde7978: SetupParameters(_CupertinoTextSelectionToolbarButtonState this /* r1 => r1, fp-0x8 */)
    //     0xde7978: stur            x1, [fp, #-8]
    // 0xde797c: CheckStackOverflow
    //     0xde797c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7980: cmp             SP, x16
    //     0xde7984: b.ls            #0xde79c8
    // 0xde7988: r1 = 1
    //     0xde7988: mov             x1, #1
    // 0xde798c: r0 = AllocateContext()
    //     0xde798c: bl              #0x13de838  ; AllocateContextStub
    // 0xde7990: mov             x1, x0
    // 0xde7994: ldur            x0, [fp, #-8]
    // 0xde7998: StoreField: r1->field_f = r0
    //     0xde7998: stur            w0, [x1, #0xf]
    // 0xde799c: mov             x2, x1
    // 0xde79a0: r1 = Function '<anonymous closure>':.
    //     0xde79a0: add             x1, PP, #0x96, lsl #12  ; [pp+0x96010] AnonymousClosure: (0xde79d0), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapCancel (0xde796c)
    //     0xde79a4: ldr             x1, [x1, #0x10]
    // 0xde79a8: r0 = AllocateClosure()
    //     0xde79a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde79ac: ldur            x1, [fp, #-8]
    // 0xde79b0: mov             x2, x0
    // 0xde79b4: r0 = setState()
    //     0xde79b4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde79b8: r0 = Null
    //     0xde79b8: mov             x0, NULL
    // 0xde79bc: LeaveFrame
    //     0xde79bc: mov             SP, fp
    //     0xde79c0: ldp             fp, lr, [SP], #0x10
    // 0xde79c4: ret
    //     0xde79c4: ret             
    // 0xde79c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde79c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde79cc: b               #0xde7988
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde79d0, size: 0x20
    // 0xde79d0: r0 = false
    //     0xde79d0: add             x0, NULL, #0x30  ; false
    // 0xde79d4: ldr             x1, [SP]
    // 0xde79d8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde79d8: ldur            w2, [x1, #0x17]
    // 0xde79dc: DecompressPointer r2
    //     0xde79dc: add             x2, x2, HEAP, lsl #32
    // 0xde79e0: LoadField: r1 = r2->field_f
    //     0xde79e0: ldur            w1, [x2, #0xf]
    // 0xde79e4: DecompressPointer r1
    //     0xde79e4: add             x1, x1, HEAP, lsl #32
    // 0xde79e8: StoreField: r1->field_13 = r0
    //     0xde79e8: stur            w0, [x1, #0x13]
    // 0xde79ec: ret
    //     0xde79ec: ret             
  }
  [closure] void _onTapUp(dynamic, TapUpDetails) {
    // ** addr: 0xde79f0, size: 0x3c
    // 0xde79f0: EnterFrame
    //     0xde79f0: stp             fp, lr, [SP, #-0x10]!
    //     0xde79f4: mov             fp, SP
    // 0xde79f8: ldr             x0, [fp, #0x18]
    // 0xde79fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde79fc: ldur            w1, [x0, #0x17]
    // 0xde7a00: DecompressPointer r1
    //     0xde7a00: add             x1, x1, HEAP, lsl #32
    // 0xde7a04: CheckStackOverflow
    //     0xde7a04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7a08: cmp             SP, x16
    //     0xde7a0c: b.ls            #0xde7a24
    // 0xde7a10: ldr             x2, [fp, #0x10]
    // 0xde7a14: r0 = _onTapUp()
    //     0xde7a14: bl              #0xde7a2c  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapUp
    // 0xde7a18: LeaveFrame
    //     0xde7a18: mov             SP, fp
    //     0xde7a1c: ldp             fp, lr, [SP], #0x10
    // 0xde7a20: ret
    //     0xde7a20: ret             
    // 0xde7a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7a24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7a28: b               #0xde7a10
  }
  _ _onTapUp(/* No info */) {
    // ** addr: 0xde7a2c, size: 0xa0
    // 0xde7a2c: EnterFrame
    //     0xde7a2c: stp             fp, lr, [SP, #-0x10]!
    //     0xde7a30: mov             fp, SP
    // 0xde7a34: AllocStack(0x10)
    //     0xde7a34: sub             SP, SP, #0x10
    // 0xde7a38: SetupParameters(_CupertinoTextSelectionToolbarButtonState this /* r1 => r1, fp-0x8 */)
    //     0xde7a38: stur            x1, [fp, #-8]
    // 0xde7a3c: CheckStackOverflow
    //     0xde7a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7a40: cmp             SP, x16
    //     0xde7a44: b.ls            #0xde7abc
    // 0xde7a48: r1 = 1
    //     0xde7a48: mov             x1, #1
    // 0xde7a4c: r0 = AllocateContext()
    //     0xde7a4c: bl              #0x13de838  ; AllocateContextStub
    // 0xde7a50: mov             x1, x0
    // 0xde7a54: ldur            x0, [fp, #-8]
    // 0xde7a58: StoreField: r1->field_f = r0
    //     0xde7a58: stur            w0, [x1, #0xf]
    // 0xde7a5c: mov             x2, x1
    // 0xde7a60: r1 = Function '<anonymous closure>':.
    //     0xde7a60: add             x1, PP, #0x96, lsl #12  ; [pp+0x96018] AnonymousClosure: (0xde79d0), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapCancel (0xde796c)
    //     0xde7a64: ldr             x1, [x1, #0x18]
    // 0xde7a68: r0 = AllocateClosure()
    //     0xde7a68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde7a6c: ldur            x1, [fp, #-8]
    // 0xde7a70: mov             x2, x0
    // 0xde7a74: r0 = setState()
    //     0xde7a74: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde7a78: ldur            x0, [fp, #-8]
    // 0xde7a7c: LoadField: r1 = r0->field_b
    //     0xde7a7c: ldur            w1, [x0, #0xb]
    // 0xde7a80: DecompressPointer r1
    //     0xde7a80: add             x1, x1, HEAP, lsl #32
    // 0xde7a84: cmp             w1, NULL
    // 0xde7a88: b.eq            #0xde7ac4
    // 0xde7a8c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xde7a8c: ldur            w0, [x1, #0x17]
    // 0xde7a90: DecompressPointer r0
    //     0xde7a90: add             x0, x0, HEAP, lsl #32
    // 0xde7a94: cmp             w0, NULL
    // 0xde7a98: b.eq            #0xde7ac8
    // 0xde7a9c: str             x0, [SP]
    // 0xde7aa0: ClosureCall
    //     0xde7aa0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde7aa4: ldur            x2, [x0, #0x1f]
    //     0xde7aa8: blr             x2
    // 0xde7aac: r0 = Null
    //     0xde7aac: mov             x0, NULL
    // 0xde7ab0: LeaveFrame
    //     0xde7ab0: mov             SP, fp
    //     0xde7ab4: ldp             fp, lr, [SP], #0x10
    // 0xde7ab8: ret
    //     0xde7ab8: ret             
    // 0xde7abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7abc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7ac0: b               #0xde7a48
    // 0xde7ac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7ac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7ac8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xde7ac8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void _onTapDown(dynamic, TapDownDetails) {
    // ** addr: 0xde7acc, size: 0x3c
    // 0xde7acc: EnterFrame
    //     0xde7acc: stp             fp, lr, [SP, #-0x10]!
    //     0xde7ad0: mov             fp, SP
    // 0xde7ad4: ldr             x0, [fp, #0x18]
    // 0xde7ad8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde7ad8: ldur            w1, [x0, #0x17]
    // 0xde7adc: DecompressPointer r1
    //     0xde7adc: add             x1, x1, HEAP, lsl #32
    // 0xde7ae0: CheckStackOverflow
    //     0xde7ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7ae4: cmp             SP, x16
    //     0xde7ae8: b.ls            #0xde7b00
    // 0xde7aec: ldr             x2, [fp, #0x10]
    // 0xde7af0: r0 = _onTapDown()
    //     0xde7af0: bl              #0xde7b08  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapDown
    // 0xde7af4: LeaveFrame
    //     0xde7af4: mov             SP, fp
    //     0xde7af8: ldp             fp, lr, [SP], #0x10
    // 0xde7afc: ret
    //     0xde7afc: ret             
    // 0xde7b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7b00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7b04: b               #0xde7aec
  }
  _ _onTapDown(/* No info */) {
    // ** addr: 0xde7b08, size: 0x64
    // 0xde7b08: EnterFrame
    //     0xde7b08: stp             fp, lr, [SP, #-0x10]!
    //     0xde7b0c: mov             fp, SP
    // 0xde7b10: AllocStack(0x8)
    //     0xde7b10: sub             SP, SP, #8
    // 0xde7b14: SetupParameters(_CupertinoTextSelectionToolbarButtonState this /* r1 => r1, fp-0x8 */)
    //     0xde7b14: stur            x1, [fp, #-8]
    // 0xde7b18: CheckStackOverflow
    //     0xde7b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7b1c: cmp             SP, x16
    //     0xde7b20: b.ls            #0xde7b64
    // 0xde7b24: r1 = 1
    //     0xde7b24: mov             x1, #1
    // 0xde7b28: r0 = AllocateContext()
    //     0xde7b28: bl              #0x13de838  ; AllocateContextStub
    // 0xde7b2c: mov             x1, x0
    // 0xde7b30: ldur            x0, [fp, #-8]
    // 0xde7b34: StoreField: r1->field_f = r0
    //     0xde7b34: stur            w0, [x1, #0xf]
    // 0xde7b38: mov             x2, x1
    // 0xde7b3c: r1 = Function '<anonymous closure>':.
    //     0xde7b3c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96020] AnonymousClosure: (0xde7b6c), in [package:flutter/src/cupertino/text_selection_toolbar_button.dart] _CupertinoTextSelectionToolbarButtonState::_onTapDown (0xde7b08)
    //     0xde7b40: ldr             x1, [x1, #0x20]
    // 0xde7b44: r0 = AllocateClosure()
    //     0xde7b44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde7b48: ldur            x1, [fp, #-8]
    // 0xde7b4c: mov             x2, x0
    // 0xde7b50: r0 = setState()
    //     0xde7b50: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde7b54: r0 = Null
    //     0xde7b54: mov             x0, NULL
    // 0xde7b58: LeaveFrame
    //     0xde7b58: mov             SP, fp
    //     0xde7b5c: ldp             fp, lr, [SP], #0x10
    // 0xde7b60: ret
    //     0xde7b60: ret             
    // 0xde7b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7b64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7b68: b               #0xde7b24
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde7b6c, size: 0x20
    // 0xde7b6c: r0 = true
    //     0xde7b6c: add             x0, NULL, #0x20  ; true
    // 0xde7b70: ldr             x1, [SP]
    // 0xde7b74: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde7b74: ldur            w2, [x1, #0x17]
    // 0xde7b78: DecompressPointer r2
    //     0xde7b78: add             x2, x2, HEAP, lsl #32
    // 0xde7b7c: LoadField: r1 = r2->field_f
    //     0xde7b7c: ldur            w1, [x2, #0xf]
    // 0xde7b80: DecompressPointer r1
    //     0xde7b80: add             x1, x1, HEAP, lsl #32
    // 0xde7b84: StoreField: r1->field_13 = r0
    //     0xde7b84: stur            w0, [x1, #0x13]
    // 0xde7b88: ret
    //     0xde7b88: ret             
  }
}

// class id: 6507, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoTextSelectionToolbarButton extends StatefulWidget {

  static _ getButtonLabel(/* No info */) {
    // ** addr: 0xde7748, size: 0x1ec
    // 0xde7748: EnterFrame
    //     0xde7748: stp             fp, lr, [SP, #-0x10]!
    //     0xde774c: mov             fp, SP
    // 0xde7750: AllocStack(0x8)
    //     0xde7750: sub             SP, SP, #8
    // 0xde7754: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xde7754: stur            x2, [fp, #-8]
    // 0xde7758: CheckStackOverflow
    //     0xde7758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde775c: cmp             SP, x16
    //     0xde7760: b.ls            #0xde792c
    // 0xde7764: LoadField: r0 = r2->field_f
    //     0xde7764: ldur            w0, [x2, #0xf]
    // 0xde7768: DecompressPointer r0
    //     0xde7768: add             x0, x0, HEAP, lsl #32
    // 0xde776c: cmp             w0, NULL
    // 0xde7770: b.eq            #0xde7780
    // 0xde7774: LeaveFrame
    //     0xde7774: mov             SP, fp
    //     0xde7778: ldp             fp, lr, [SP], #0x10
    // 0xde777c: ret
    //     0xde777c: ret             
    // 0xde7780: r0 = of()
    //     0xde7780: bl              #0xde37f4  ; [package:flutter/src/cupertino/localizations.dart] CupertinoLocalizations::of
    // 0xde7784: mov             x1, x0
    // 0xde7788: ldur            x0, [fp, #-8]
    // 0xde778c: LoadField: r2 = r0->field_b
    //     0xde778c: ldur            w2, [x0, #0xb]
    // 0xde7790: DecompressPointer r2
    //     0xde7790: add             x2, x2, HEAP, lsl #32
    // 0xde7794: r16 = Instance_ContextMenuButtonType
    //     0xde7794: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7f8] Obj!ContextMenuButtonType@12c3501
    //     0xde7798: ldr             x16, [x16, #0x7f8]
    // 0xde779c: cmp             w2, w16
    // 0xde77a0: b.ne            #0xde77c4
    // 0xde77a4: r0 = LoadClassIdInstr(r1)
    //     0xde77a4: ldur            x0, [x1, #-1]
    //     0xde77a8: ubfx            x0, x0, #0xc, #0x14
    // 0xde77ac: r0 = GDT[cid_x0 + 0x16d83]()
    //     0xde77ac: mov             x17, #0x6d83
    //     0xde77b0: movk            x17, #1, lsl #16
    //     0xde77b4: add             lr, x0, x17
    //     0xde77b8: ldr             lr, [x21, lr, lsl #3]
    //     0xde77bc: blr             lr
    // 0xde77c0: b               #0xde7920
    // 0xde77c4: r16 = Instance_ContextMenuButtonType
    //     0xde77c4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a800] Obj!ContextMenuButtonType@12c34e1
    //     0xde77c8: ldr             x16, [x16, #0x800]
    // 0xde77cc: cmp             w2, w16
    // 0xde77d0: b.ne            #0xde77f4
    // 0xde77d4: r0 = LoadClassIdInstr(r1)
    //     0xde77d4: ldur            x0, [x1, #-1]
    //     0xde77d8: ubfx            x0, x0, #0xc, #0x14
    // 0xde77dc: r0 = GDT[cid_x0 + 0x14bcf]()
    //     0xde77dc: mov             x17, #0x4bcf
    //     0xde77e0: movk            x17, #1, lsl #16
    //     0xde77e4: add             lr, x0, x17
    //     0xde77e8: ldr             lr, [x21, lr, lsl #3]
    //     0xde77ec: blr             lr
    // 0xde77f0: b               #0xde7920
    // 0xde77f4: r16 = Instance_ContextMenuButtonType
    //     0xde77f4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a808] Obj!ContextMenuButtonType@12c34c1
    //     0xde77f8: ldr             x16, [x16, #0x808]
    // 0xde77fc: cmp             w2, w16
    // 0xde7800: b.ne            #0xde7824
    // 0xde7804: r0 = LoadClassIdInstr(r1)
    //     0xde7804: ldur            x0, [x1, #-1]
    //     0xde7808: ubfx            x0, x0, #0xc, #0x14
    // 0xde780c: r0 = GDT[cid_x0 + 0x14cc7]()
    //     0xde780c: mov             x17, #0x4cc7
    //     0xde7810: movk            x17, #1, lsl #16
    //     0xde7814: add             lr, x0, x17
    //     0xde7818: ldr             lr, [x21, lr, lsl #3]
    //     0xde781c: blr             lr
    // 0xde7820: b               #0xde7920
    // 0xde7824: r16 = Instance_ContextMenuButtonType
    //     0xde7824: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a818] Obj!ContextMenuButtonType@12c3481
    //     0xde7828: ldr             x16, [x16, #0x818]
    // 0xde782c: cmp             w2, w16
    // 0xde7830: b.ne            #0xde7854
    // 0xde7834: r0 = LoadClassIdInstr(r1)
    //     0xde7834: ldur            x0, [x1, #-1]
    //     0xde7838: ubfx            x0, x0, #0xc, #0x14
    // 0xde783c: r0 = GDT[cid_x0 + 0x1664a]()
    //     0xde783c: mov             x17, #0x664a
    //     0xde7840: movk            x17, #1, lsl #16
    //     0xde7844: add             lr, x0, x17
    //     0xde7848: ldr             lr, [x21, lr, lsl #3]
    //     0xde784c: blr             lr
    // 0xde7850: b               #0xde7920
    // 0xde7854: r16 = Instance_ContextMenuButtonType
    //     0xde7854: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a820] Obj!ContextMenuButtonType@12c3461
    //     0xde7858: ldr             x16, [x16, #0x820]
    // 0xde785c: cmp             w2, w16
    // 0xde7860: b.ne            #0xde7884
    // 0xde7864: r0 = LoadClassIdInstr(r1)
    //     0xde7864: ldur            x0, [x1, #-1]
    //     0xde7868: ubfx            x0, x0, #0xc, #0x14
    // 0xde786c: r0 = GDT[cid_x0 + 0x15146]()
    //     0xde786c: mov             x17, #0x5146
    //     0xde7870: movk            x17, #1, lsl #16
    //     0xde7874: add             lr, x0, x17
    //     0xde7878: ldr             lr, [x21, lr, lsl #3]
    //     0xde787c: blr             lr
    // 0xde7880: b               #0xde7920
    // 0xde7884: r16 = Instance_ContextMenuButtonType
    //     0xde7884: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a828] Obj!ContextMenuButtonType@12c3441
    //     0xde7888: ldr             x16, [x16, #0x828]
    // 0xde788c: cmp             w2, w16
    // 0xde7890: b.ne            #0xde78b4
    // 0xde7894: r0 = LoadClassIdInstr(r1)
    //     0xde7894: ldur            x0, [x1, #-1]
    //     0xde7898: ubfx            x0, x0, #0xc, #0x14
    // 0xde789c: r0 = GDT[cid_x0 + 0x15c5e]()
    //     0xde789c: mov             x17, #0x5c5e
    //     0xde78a0: movk            x17, #1, lsl #16
    //     0xde78a4: add             lr, x0, x17
    //     0xde78a8: ldr             lr, [x21, lr, lsl #3]
    //     0xde78ac: blr             lr
    // 0xde78b0: b               #0xde7920
    // 0xde78b4: r16 = Instance_ContextMenuButtonType
    //     0xde78b4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a810] Obj!ContextMenuButtonType@12c34a1
    //     0xde78b8: ldr             x16, [x16, #0x810]
    // 0xde78bc: cmp             w2, w16
    // 0xde78c0: b.ne            #0xde78e4
    // 0xde78c4: r0 = LoadClassIdInstr(r1)
    //     0xde78c4: ldur            x0, [x1, #-1]
    //     0xde78c8: ubfx            x0, x0, #0xc, #0x14
    // 0xde78cc: r0 = GDT[cid_x0 + 0x161cb]()
    //     0xde78cc: mov             x17, #0x61cb
    //     0xde78d0: movk            x17, #1, lsl #16
    //     0xde78d4: add             lr, x0, x17
    //     0xde78d8: ldr             lr, [x21, lr, lsl #3]
    //     0xde78dc: blr             lr
    // 0xde78e0: b               #0xde7920
    // 0xde78e4: r16 = Instance_ContextMenuButtonType
    //     0xde78e4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a830] Obj!ContextMenuButtonType@12c3421
    //     0xde78e8: ldr             x16, [x16, #0x830]
    // 0xde78ec: cmp             w2, w16
    // 0xde78f0: b.eq            #0xde7914
    // 0xde78f4: r16 = Instance_ContextMenuButtonType
    //     0xde78f4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80a28] Obj!ContextMenuButtonType@12c3521
    //     0xde78f8: ldr             x16, [x16, #0xa28]
    // 0xde78fc: cmp             w2, w16
    // 0xde7900: b.eq            #0xde7914
    // 0xde7904: r16 = Instance_ContextMenuButtonType
    //     0xde7904: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7c8] Obj!ContextMenuButtonType@12c3401
    //     0xde7908: ldr             x16, [x16, #0x7c8]
    // 0xde790c: cmp             w2, w16
    // 0xde7910: b.ne            #0xde791c
    // 0xde7914: r0 = ""
    //     0xde7914: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xde7918: b               #0xde7920
    // 0xde791c: r0 = Null
    //     0xde791c: mov             x0, NULL
    // 0xde7920: LeaveFrame
    //     0xde7920: mov             SP, fp
    //     0xde7924: ldp             fp, lr, [SP], #0x10
    // 0xde7928: ret
    //     0xde7928: ret             
    // 0xde792c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde792c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7930: b               #0xde7764
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa09e8, size: 0x2c
    // 0xfa09e8: EnterFrame
    //     0xfa09e8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa09ec: mov             fp, SP
    // 0xfa09f0: mov             x0, x1
    // 0xfa09f4: r1 = <CupertinoTextSelectionToolbarButton>
    //     0xfa09f4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cad0] TypeArguments: <CupertinoTextSelectionToolbarButton>
    //     0xfa09f8: ldr             x1, [x1, #0xad0]
    // 0xfa09fc: r0 = _CupertinoTextSelectionToolbarButtonState()
    //     0xfa09fc: bl              #0xfa0a14  ; Allocate_CupertinoTextSelectionToolbarButtonStateStub -> _CupertinoTextSelectionToolbarButtonState (size=0x18)
    // 0xfa0a00: r1 = false
    //     0xfa0a00: add             x1, NULL, #0x30  ; false
    // 0xfa0a04: StoreField: r0->field_13 = r1
    //     0xfa0a04: stur            w1, [x0, #0x13]
    // 0xfa0a08: LeaveFrame
    //     0xfa0a08: mov             SP, fp
    //     0xfa0a0c: ldp             fp, lr, [SP], #0x10
    // 0xfa0a10: ret
    //     0xfa0a10: ret             
  }
}
